import lldb,json,time,pathlib,subprocess
f=pathlib.Path(__file__).resolve().parent
receipt={'schema':'mech.polybench.owned-native-route-diagnostic.v1','complete':False,'hits':{},'preflight_trace':[],'performance_observations':0}
def write(): (f/'route-trace.json').write_text(json.dumps(receipt,indent=2)+'\n')
def hit(frame,location,internal):
 bp=location.GetBreakpoint();key=str(bp.GetID());row=receipt['hits'][key];row['hit']=True;row['pc']=frame.GetPC();row['frame']=frame.GetFunctionName();bp.SetEnabled(False);write();return False
owned_process=None
owned_target=None
def _run():
 global owned_process,owned_target
 plan=json.loads((f/'plan.json').read_text());debugger=lldb.debugger;debugger.SetAsync(True)
 target=debugger.CreateTarget(plan['driver']);assert target.IsValid();launch=lldb.SBLaunchInfo([str(pathlib.Path(plan['reference_gate']).parents[0]/'not-used')])
 root=pathlib.Path.cwd();source=root/'hosts/gpu/tests/fixtures/polybench/deriche.mec';inputs=f/'deriche-inputs.json'
 launch=lldb.SBLaunchInfo([str(source),str(inputs),'5']);launch.SetWorkingDirectory(str(root));launch.SetLaunchFlags(lldb.eLaunchFlagDebug);launch.SetEnvironmentEntries(['PERF_BUILDID_DIR='+str(f/'perf-binaries')],True)
 assert launch.AddOpenFileAction(1,str(f/'driver.stdout'),False,True) and launch.AddOpenFileAction(2,str(f/'driver.stderr'),False,True)
 error=lldb.SBError();start=time.time_ns();process=target.Launch(launch,error);assert error.Success();owned_process=process;owned_target=target;pid=process.GetProcessID();receipt.update(pid=pid,driver=plan['driver'],driver_sha256=plan['driver_sha256']);write()
 mapping=pathlib.Path('/tmp')/('perf-'+str(pid)+'.map')
 while not(mapping.exists()and mapping.stat().st_mtime_ns>=start and set(plan['functions'])<=set(line.split(maxsplit=2)[2]for line in mapping.read_text().splitlines())):
  if process.GetState()==lldb.eStateStopped:assert process.Continue().Success()
  assert process.GetState()!=lldb.eStateExited
  time.sleep(.01)
 assert process.Stop().Success()
 while process.GetState()!=lldb.eStateStopped:time.sleep(.01)
 entries={}
 for line in mapping.read_text().splitlines():
  address,size,name=line.split(maxsplit=2)
  if name in plan['functions']:entries[name]=(int(address,16),int(size,16))
 assert set(entries)==set(plan['functions']);(f/'deriche.perf.map').write_text(mapping.read_text())
 for name,(address,size)in entries.items():
  bp=target.BreakpointCreateByAddress(address);assert bp.GetNumLocations()==1
  receipt['hits'][str(bp.GetID())]={'name':name,'address':address,'size':size,'hit':False};bp.SetScriptCallbackFunction('trace_route.hit')
 for name in ['prepare_numeric_generator','finish_numeric_generator','numeric_array_owner','begin_numeric_views','begin_closed_region']:
  bp=target.BreakpointCreateByRegex(name+'$');assert bp.GetNumLocations()>0
  receipt['hits'][str(bp.GetID())]={'name':name,'locations':bp.GetNumLocations(),'hit':False};bp.SetScriptCallbackFunction('trace_route.hit')
 write();debugger.SetAsync(False);assert process.Continue().Success();assert process.GetState()==lldb.eStateExited
 receipt.update(driver_exit_code=process.GetExitStatus(),complete=process.GetExitStatus()==0);write();assert receipt['complete'];print(json.dumps(receipt),flush=True)

def run():
 try: _run()
 except Exception as error:
  receipt['error']=repr(error)
  if owned_process is not None:
   lldb.debugger.SetAsync(False)
   for at in range(owned_target.GetNumBreakpoints()):owned_target.GetBreakpointAtIndex(at).SetEnabled(False)
   while owned_process.GetState()!=lldb.eStateExited:
    if owned_process.GetState()==lldb.eStateStopped:owned_process.Continue()
    else:time.sleep(.02)
   receipt['driver_exit_code']=owned_process.GetExitStatus()
   receipt['cleanup_actual_terminal']=True
  write()
  raise
