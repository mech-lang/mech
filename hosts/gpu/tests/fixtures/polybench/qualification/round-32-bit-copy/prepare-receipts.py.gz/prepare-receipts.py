import gzip,hashlib,importlib.util,json,re,shutil
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent;profile_root=folder.parent/'profile'
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;q=b.read(folder/'qualification.json');checkpoint=b.read(folder/'source-checkpoint.json');probe=b.read(folder/'training-probe.json');census=b.read(folder/'emission-census.json');profile=b.read(profile_root/'training-profile.json');rule=b.read(folder/'selection-policy.json')
assert b.compiler_fingerprint()==q['compiler_fingerprint']==checkpoint['compiler_fingerprint']==probe['compiler_fingerprint']==census['compiler_fingerprint']
assert b.digest(folder/'copy-driver')==q['driver_sha256']==probe['driver_sha256']==census['driver_sha256']
assert q['tests']==585 and len(q['checks'])==7 and all(c['exit_code']==0 for c in q['checks'])
assert len(probe['cases'])==15 and all(c['all_counters_match'] and all(v==0 for v in c['execution_counter_deltas'].values()) for c in probe['cases'].values())
assert probe['summary']['geomean_raw_speedup_vs_accepted31']>1 and census['complete'] and census['profiled_copy_function_vector_memory_ops']=={'before':0,'after':54}
assert profile['partition']=='optimization' and profile['compiler_fingerprint']==b.read(p/'round-31-frozen.json')['compiler_fingerprint']
verification=b.read(profile_root/'jit-object-byte-verification.json');sites=[s for c in verification['cases'].values() for f in c['functions'] for s in f['sampled_hot_sites']]
assert len(sites)==130 and all(s['instruction_identical'] and s['surrounding_68_bytes_identical'] for s in sites)
selection={'selected_at':b.utc(),'prospective_rule':rule,'probe_sha256':b.digest(folder/'training-probe.json'),'emission_census_sha256':b.digest(folder/'emission-census.json'),'selected_compiler_fingerprint':q['compiler_fingerprint'],'selected_driver_sha256':q['driver_sha256'],'decision':'Select unchanged qualified shared SIMD bit-copy candidate for frozen formal both-set evaluation','summary':probe['summary'],'holdout_performance_used':False};b.write(folder/'training-selection.json',selection)
dest=p/'qualification/round-32-bit-copy';dest.mkdir(parents=True,exist_ok=False)
def archive(path,name):
 raw=path.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);assert not out.exists();out.write_bytes(gzip.compress(raw,mtime=0));return {'path':str(out.relative_to(p)),'sha256':hashlib.sha256(raw).hexdigest(),'compressed_sha256':b.digest(out)}
archives={}
for base,prefix in [(folder,''),(profile_root,'baseline-profile/')]:
 for path in sorted(base.rglob('*')):
  if not path.is_file() or '__pycache__' in path.parts or path.name in ['copy-driver','current-work.json'] or path.name.endswith('-inputs.json') or 'profiles' in path.relative_to(base).parts:continue
  name=prefix+str(path.relative_to(base));archives[name]=archive(path,name)
passed=set();logs=[]
for c in q['checks']:
 names=re.findall(r'^test (.+?) \.\.\. ok$',(folder/c['name']).read_text(),re.M);passed.update(names);a=archives[c['name']];logs.append({'log':a['path'],'log_sha256':a['sha256'],'compressed_sha256':a['compressed_sha256'],'passed_tests':len(names)})
assert len(passed)==585
for name,item in profile['analysis'].items():
 for key,sha_key in [('raw_sample','compressed_sample_sha256'),('jit_map','compressed_jit_map_sha256')]:
  src=profile_root/item[key];out=p/'profiles/round-32-bit-copy'/src.name;out.parent.mkdir(parents=True,exist_ok=True);assert not out.exists();shutil.copy2(src,out);assert b.digest(out)==item[sha_key];item[key]=str(out.relative_to(p))
profile['scope']='Accepted31 optimization-only profiling selected shared numeric bank bit copies. All130 sampled instruction/windows matched actual checked JIT bytes to real Objects. No profiling or debugger times enter scores.'
for name,value in [('training-profile',profile),('training-probe',probe),('training-selection',selection),('emission-census',census)]:b.write(p/f'round-32-{name}.json',value)
b.write(p/'round-32-training-qualification.json',{'schema':'mech.polybench.training-qualification.v1','created_at':b.utc(),'scope':'Current-source correctness/features before formal timing. Candidate selected only from accepted31 optimization profiling and optimization15 replay.','source_parent':checkpoint['source_commit'],'compiler_fingerprint':q['compiler_fingerprint'],'driver_sha256':q['driver_sha256'],'versions':checkpoint['versions'],'total_unique_selected_checks':585,'checks':q['checks'],'logs':logs,'development_archives':archives,'invariants':[
 'All30 unchanged ports match29482 finite C live-outs in original/decoded artifacts and emit Objects.',
 'A shared direct Cranelift emitter copies admitted numeric banks with128-bit transfers in64-byte chunks, exact vector/scalar tails, and no read/write outside the exact spans. Partial overlaps, including self copy, retain original left-to-right scalar-unit order. Widths1/2/4/8 and unaligned spans are supported. No floating operation is introduced.',
 'Checked complete matrix maps compute every scratch result before the existing non-failing transfer to an exclusive destination bank. Existing generator prefix bank copies reuse the same emitter. Ownership, initialization, current views, source errors, finite admission, complete source prices/replay, fixed template funding and atomic publication remain.',
 'Direct speed-optimized JIT tests preserve arbitrary bits including NaN payloads and signedzero, all scalar widths, odd tails, both overlap directions and self copy. Inaccessible guard pages independently enforce exact source reads and destination stores, including zero-length null spans.',
 'Every execution counter matches accepted31 exactly on all15 optimization programs. Existing direct scalar Bool/U64/I64/F64 machinery remains maintained. IR391/work156/ABI47 retain source bills and144-byte root/80-byte numeric frames.',
 'Accepted31 profiles selected the five largest optimization medians, covering72.47% of their summed time.1099 canonical execution samples included806 resolved JIT self samples. Actual unchanged checked JIT bytes match all130 sampled hot-site instructions and surrounding68-byte windows to real Objects. The profiled Gram-Schmidt function now emits54 SIMD memory instructions versus0 before.',
 'No benchmark-name dispatch, port/input/C/flags/tolerance/finite-limit/split/objective/timing-boundary changes or holdout diagnosis. Source and driver are committed/frozen before both formal sets. Both scores must strictly improve versus accepted31 to promote; no exclusions, tolerances or timing retry.'
 ],'development_failures':[],'limitations':['CPU MINI/F64 and Object emission qualified; linked Object execution, larger datasets, accelerators, full compression/AOT and a fresh application remain unqualified.','The optimization-only probe is a small aggregate gain and retains two regressions>5%; only the full formal gate determines acceptance.']})
assert b.compiler_fingerprint()==q['compiler_fingerprint'];print(json.dumps({'checks':585,'fingerprint':q['compiler_fingerprint'],'driver':q['driver_sha256'],'probe':probe['summary'],'archives':len(archives),'verified_hot_sites':len(sites)}))
