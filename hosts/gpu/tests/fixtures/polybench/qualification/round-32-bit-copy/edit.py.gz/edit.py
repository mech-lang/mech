from pathlib import Path
root=Path.cwd();p=root/'hosts/gpu/src/native_artifact/program/codegen';folder=Path(__file__).resolve().parent
for name in ['bit_copy.rs','bit_copy_tests.rs']:(p/name).write_text((folder/name).read_text())
s=(p/'mod.rs').read_text();needle='#[cfg(feature = "canonical-native-program")]\nmod numeric_phase_maps;';assert needle in s;s=s.replace(needle,'#[cfg(feature = "canonical-native-program")]\nmod bit_copy;\n'+needle);(p/'mod.rs').write_text(s)
s=(p/'numeric_phase_maps.rs').read_text().replace('Block, InstBuilder, MemFlags, StackSlotData', 'Block, InstBuilder, StackSlotData');start=s.index('    let copy = b.create_block();');end=s.index('    if owned.is_some() {',start);s=s[:start]+'    super::bit_copy::emit(b, scratch, base, u64::from(bytes), width)?;\n'+s[end:];(p/'numeric_phase_maps.rs').write_text(s)
s=(p/'numeric_generator_arrays.rs').read_text();start=s.index('pub(super) fn copy(');end=s.index('pub(super) fn linear(',start);s=s[:start]+'''pub(super) fn copy(b: &mut FunctionBuilder<'_>, source: Value, output: Value, count: u64) -> Result<(), NativeCompileError> {
    let bytes = count.checked_mul(8).ok_or_else(|| backend("generator copy byte count overflowed"))?;
    super::super::bit_copy::emit(b, source, output, bytes, 8)
}
'''+s[end:];(p/'numeric_generator_arrays.rs').write_text(s)
s=(p/'numeric_generator.rs').read_text();needle='copy(b, old[0], destination, extents[0] * extents[1]);';assert needle in s;s=s.replace(needle,needle[:-1]+'?;');(p/'numeric_generator.rs').write_text(s)
p=root/'hosts/gpu/src/native_artifact/program/image/identity.rs';s=p.read_text();needle='pub const NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 390;';assert needle in s;s=s.replace(needle,'// IR391 shares exact bounded SIMD bit copies between checked numeric banks.\npub const NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 391;');p.write_text(s)
