import hashlib,re

def functions(asm):
 rows={};name=None
 for line in asm.splitlines():
  m=re.match(r'^[0-9a-f]+ <_(.+)>:',line)
  if m:name=m[1];rows[name]=[]
  elif name and re.match(r'^\s*[0-9a-f]+:',line):rows[name].append(line)
 return {name:{'instructions':len(lines),'disassembly_sha256':hashlib.sha256('\n'.join(lines).encode()).hexdigest()}for name,lines in rows.items()}
def matches(old,new):
 return set(old)==set(new)and all(all(new[name][key]==old[name][key]for key in ['instructions','disassembly_sha256'])for name in old)
def records(value,key):
 if isinstance(value,dict):return sum((v if k==key else records(v,key)for k,v in value.items()),[])
 if isinstance(value,list):return sum((records(v,key)for v in value),[])
 return []
def paired_loops(asm):
 funcs={};name=None
 for line in asm.splitlines():
  m=re.match(r'^[0-9a-f]+ <_(.+)>:',line)
  if m:name=m[1];funcs[name]=[];continue
  m=re.match(r'^\s*([0-9a-f]+):\s+(.*)$',line)
  if name and m:funcs[name].append((int(m[1],16),m[2].strip()))
 loops=[]
 for symbol,lines in funcs.items():
  lookup={pc:i for i,(pc,_)in enumerate(lines)}
  for at,ins in lines:
   branch=re.match(r'b\s+0x([0-9a-f]+)\s',ins)
   if not branch:continue
   header=int(branch[1],16)
   if header>=at or header not in lookup:continue
   index=lookup[header]
   if index+1>=len(lines)or not re.fullmatch(r'cmp\s+x\d+, #2',lines[index][1]):continue
   reached=re.match(r'b.hs\s+0x([0-9a-f]+)\s',lines[index+1][1])
   if not reached:continue
   start=int(reached[1],16)
   if not header<start<=at:continue
   body=[(pc,op)for pc,op in lines if start<=pc<=at]
   ops=[op.split()[0].split('.')[0]for _,op in body]
   if ops.count('fmul')==8 and ops.count('fadd')==8 and not any(op in ['mul','madd','msub','umulh','smulh','smaddl','umaddl']for op in ops):
    loops.append({'symbol':symbol,'header':hex(header),'reached_pair_body':hex(start),'backedge':hex(at),'header_instructions':[{'offset':hex(pc),'instruction':op}for pc,op in lines[index:index+2]],'instructions':len(body),'rounded_multiply':8,'rounded_add':8,'integer_index_products':0,'body':[{'offset':hex(pc),'instruction':op}for pc,op in body]})
 return loops
