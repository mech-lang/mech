"""Retain one complete formal run and apply the preregistered optimization gate."""
import gzip,importlib.util,json,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(s);s.loader.exec_module(b)
p=b.FIXTURE;plan=b.read(folder/'plan.json');f=b.read(p/'round-61-frozen.json');q=b.read(p/'round-61-training-qualification.json');audit=b.read(p/'round-61-audit.json');progress=b.read(p/'round-61-progress.json');ledger=b.read(p/'performance-acceptance.json');decision=ledger['entries'][-1];fp=b.compiler_fingerprint();gate=b.read(folder/'untimed-counter-gate.json');probe=b.read(folder/'training-probe.json')
assert b.command(['git','branch','--show-current'])=='codex/polybench-native-matrices'
assert b.command(['git','rev-parse','HEAD'])==f['source_commit']
assert fp==f['compiler_fingerprint']==q['compiler_fingerprint']==gate['compiler_fingerprint']==probe['compiler_fingerprint']
assert b.digest(q['driver'])==q['driver_sha256']==f['driver_sha256']and all(b.digest(root/name)==digest for name,digest in q['source_sha256'].items())
assert gate['passed']and gate['finite_liveouts']==17002 and all(c['all_counters_match']for c in gate['cases'].values())and all(c['all_counters_match']for c in probe['cases'].values())
assert b.read(folder/'formal-exit.json')['exit_code']==0 and audit['observations']==900 and audit['finite_liveouts']==29482 and audit['history_append_only']
assert len(b.read(p/'performance-history.json')['entries'])==62 and decision['compared_to_accepted_index']==59
accepted=decision['performance_gate']=='accepted';assert accepted==(decision['scores']['optimization']<plan['accepted_scores']['optimization'])
assert ledger['accepted_history_index']==(61 if accepted else 59)
subprocess.run(['python3',str(root/'scripts/record-polybench-acceptance.py'),'--check']+(['--require-latest-accepted']if accepted else []),check=True,capture_output=True)
qualification={'schema':'mech.polybench.optimization-qualification.v3','label':f['label'],'compiler_commit':f['source_commit'],'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'frozen_candidate_sha256':b.digest(p/'round-61-frozen.json'),'native_typed_ir_version':436,'native_work_policy_version':157,'native_abi_version':48,'dataset':'MINI','numeric_profile':'F64','comparison':{'rtol':1e-10,'atol':1e-9,'finite_required':True,'corpus_liveouts':29482},'checks':q['checks'],'broad_selected_checks':q['broad_selected_checks'],'focused_selected_checks':9,'restored_corpus':q['restored_corpus'],'both_feature_checks_passed':True,'source_sha256':q['source_sha256'],'training_qualification_sha256':b.digest(p/'round-61-training-qualification.json'),'training_selection_sha256':b.digest(p/'round-61-training-selection.json'),'training_probe_sha256':b.digest(p/'round-61-training-probe.json'),'route_census_sha256':b.digest(p/'training-experiments/ordered-dot-regression-recovery-route-census.json'),'source_work_comparison_never_reduced':True,'physical_visits':'Every execution counter exactly matches accepted59 in the untimed optimization gate and all210 probe observations. No visit or source bill reduction is proposed. All source F64 operations and rounding remain; complete point-read admission and escaping-result classification precede raw-word export, with exact original lexical prefix replay at the same current state on nonfinite results.','invariants':q['invariants'],'formal_observations':900,'audit_sha256':b.digest(p/'round-61-audit.json'),'selection_policy_sha256':b.digest(p/'performance-selection-policy-v4.json'),'promotion':'Optimization15 strictly below accepted59 only; holdout independently reported and cannot veto/select/tune/trigger rollback/retry.'}
assert not(p/'round-61-qualification.json').exists();b.write(p/'round-61-qualification.json',qualification);b.write(p/'round-61-static-telemetry.json',b.read(folder/'emission-census.json'))
dest=p/'qualification/round-61-ordered-dot-regression-recovery/formal';dest.mkdir(parents=True,exist_ok=False);archives={}
for source in sorted(folder.rglob('*')):
 if not source.is_file()or '__pycache__'in source.parts or source.name.endswith('-driver'):continue
 name=str(source.relative_to(folder));raw=source.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives[name]={'path':str(out.relative_to(p)),'sha256':b.digest(source),'compressed_sha256':b.digest(out)}
receipt={'schema':'mech.polybench.compiler-experiment-formal.v1','created_at':b.utc(),'source_commit':f['source_commit'],'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'accepted_history_index':ledger['accepted_history_index'],'promoted':accepted,'selection_policy_sha256':b.digest(p/'performance-selection-policy-v4.json'),'decision':decision,'formal_observations':900,'finite_liveouts':29482,'training_observations':210,'formal_scores':decision['scores'],'controls_vs_accepted59':audit['aggregate_controls_vs_accepted59'],'source_and_protocol_unchanged_during_formal':True,'holdout_use':'Independent generalization report; never selection, tuning or rollback.','goal':progress['goal'],'qualification_path':'round-61-qualification.json','static_telemetry_path':'round-61-static-telemetry.json','archives':archives}
b.write(p/'training-experiments/ordered-dot-regression-recovery-formal.json',receipt)
if not accepted:
 subprocess.run(['git','restore','--source='+plan['source_parent'],'--worktree','--',*plan['source_paths']],check=True)
 subprocess.run(['git','add','-A','--',*plan['source_paths']],check=True)
 assert b.compiler_fingerprint()==b.read(p/'round-59-frozen.json')['compiler_fingerprint']
state=b.read(p/'optimization-target-state.json');assert state['accepted_history_index']==59 and state['active_target']['case']=='seidel-2d'
previous_wins=state['maintained_parity_wins'];assert previous_wins==[]
if accepted:
    result=b.read(p/'round-61-optimization.json');protocol,_=b.protocol();rows=[]
    for name in protocol['optimization']:
        c=result['runs'][name]['comparisons']['kernel'];rows.append({'case':name,'mech_over_c':c['median_mech_over_c'],'mech_median_seconds':c['mech']['median_seconds'],'c_median_seconds':c['c']['median_seconds']})
    by_name={row['case']:row for row in rows}
    wins=[dict(row,attaining_history_index=61,source_commit=f['source_commit'],driver_sha256=f['driver_sha256'])for row in rows if row['mech_over_c']<=1]
    order={name:i for i,name in enumerate(protocol['optimization'])};remaining=sorted((row for row in rows if row['mech_over_c']>1),key=lambda row:(row['mech_over_c'],order[row['case']]))
    active=by_name['seidel-2d']if by_name['seidel-2d']['mech_over_c']>1 else remaining[0]if remaining else None
    state.update(accepted_history_index=61,accepted_compiler_fingerprint=fp,accepted_source_commit=f['source_commit'],accepted_driver_sha256=f['driver_sha256'],accepted_optimization_receipt='round-61-optimization.json',accepted_optimization_receipt_sha256=b.digest(p/'round-61-optimization.json'),active_target=active,maintained_parity_wins=wins,remaining_cases_by_closeness=remaining)
state.update(latest_experiment='training-experiments/ordered-dot-regression-recovery-formal.json',latest_experiment_selected=True,latest_experiment_promoted=accepted)
b.write(p/'optimization-target-state.json',state)
with(p/'README.txt').open('a')as out:
    out.write('\nOrdered-dot and productive-prefix regression recovery: formal evaluation\n\n')
    out.write(f'Exact round60 Seidel native functions/code/stack are preserved. Pure load-only prefixes which eliminate no floating checks stay on the original native path; Nussinov unproductive prefixes disappear. Shared ordered-dot loops carry stream addresses and emit two consecutive terms per trip, plus a guarded odd term. Every accumulator keeps original+0, term order and separate rounded multiply/add. No reassociation/FMA/source fee or visit change. {q["broad_selected_checks"]} broad invocations,9 focused groups,both features,all30 original/decoded/restored C cases and17002 optimization C outputs passed. Every optimization counter exactly matches accepted59.\n\n')
    out.write(f'One210-observation target-aware optimization probe selected; one frozen900-observation formal run matched29482 finite C liveouts and appended immutable history61. Optimization{decision["scores"]["optimization"]:.16f}x C; independent holdout{decision["scores"]["holdout"]:.16f}x C. Strict optimization-only decision:{decision["performance_gate"]}. Raw Mech and C/reference drift are separate in round-61-audit.json. All observations/regressions retained, no fingerprint retry/exclusion. '+('Compiler promoted to accepted61.'if accepted else'Exact accepted59 source restored solely because optimization failed its strict gate.')+' Closest-parity target/parity wins are updated only from accepted optimization receipts.\n\n')
    out.write('[Qualification](round-61-qualification.json) · [Audit](round-61-audit.json) · [Progress](round-61-progress.json) · [Complete experiment](training-experiments/ordered-dot-regression-recovery-formal.json) · [Active target](optimization-target-state.json)\n')
subprocess.run(['git','diff','--check'],check=True);subprocess.run(['git','add','--','hosts/gpu/tests/fixtures/polybench'],check=True)
message=f'Accept ordered-dot regression recovery at {decision["scores"]["optimization"]:.2f}x optimization score'if accepted else'Record ordered-dot formal result and restore accepted compiler'
subprocess.run(['git','-c','gc.auto=0','commit','-q','-m',message],check=True)
head=b.command(['git','rev-parse','HEAD']);assert b.command(['git','status','--porcelain'])==''
state=b.read(folder/'current-work.json');state.update(stage='Formal decision archived and committed; push pending',source_commit=head,compiler_fingerprint=b.compiler_fingerprint(),candidate_fingerprint=fp,accepted_round=61 if accepted else 59,accepted_scores=decision['scores']if accepted else plan['accepted_scores'],formal_history_entries=62,formal_observations=900,performance_observations=1110,live_exec_session=None,complete=True);b.write(folder/'current-work.json',state)
print(json.dumps({'head':head,'promoted':accepted,'accepted_round':state['accepted_round'],'accepted_scores':state['accepted_scores'],'formal_candidate_scores':decision['scores'],'controls':audit['aggregate_controls_vs_accepted59'],'archives_verified':len(archives),'clean':True,'goal':progress['goal']}),flush=True)
