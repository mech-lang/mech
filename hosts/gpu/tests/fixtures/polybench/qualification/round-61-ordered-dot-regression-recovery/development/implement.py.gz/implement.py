from pathlib import Path
import subprocess
base=Path('hosts/gpu/src/native_artifact/program/codegen')
p=base/'numeric_dot_core.rs';s=p.read_text();s=s.replace('        let offset = b.ins().imul(at, self.step);\n        let pointer = b.ins().iadd(self.pointer, offset);','        let pointer = at;',1)
a=s.index('    let cursor = b.declare_var(types::I64);');z=s.index('    b.switch_to_block(done);',a)
s=s[:a]+'''    let remaining = b.declare_var(types::I64);
    let sums = (0..left.len()).map(|_| b.declare_var(kind)).collect::<Vec<_>>();
    let streams = left.iter().copied().chain([right]).collect::<Vec<_>>();
    let positions = streams.iter().map(|stream| {
        let position = b.declare_var(types::I64);
        b.def_var(position, stream.pointer);
        position
    }).collect::<Vec<_>>();
    let identity = b.ins().f64const(0.0);
    let identity = if vector { b.ins().splat(kind, identity) } else { identity };
    b.def_var(remaining, count);
    for &sum in &sums { b.def_var(sum, identity); }
    // All reached source loads are admitted immutable streams. Carry addresses
    // rather than rebuilding index*stride for every term. Integer address
    // additions are modular; an unused one-past address is never dereferenced.
    let term = |b: &mut FunctionBuilder<'_>, advance: bool| {
        let rp = b.use_var(positions[left.len()]);
        let rhs = right.load(b, rp, vector);
        for (at, (&stream, &sum)) in left.iter().zip(&sums).enumerate() {
            let pointer = b.use_var(positions[at]);
            let lhs = stream.load(b, pointer, vector);
            let product = f64_arithmetic(b, NativeScalarOp::F64Mul, lhs, rhs);
            let prior = b.use_var(sum);
            let next = f64_arithmetic(b, NativeScalarOp::F64Add, prior, product);
            b.def_var(sum, next);
        }
        if advance {
            for (&position, stream) in positions.iter().zip(&streams) {
                let pointer = b.use_var(position);
                let next = b.ins().iadd(pointer, stream.step);
                b.def_var(position, next);
            }
        }
    };
    let head = b.create_block();
    let body = b.create_block();
    let tail = b.create_block();
    let last = b.create_block();
    let done = b.create_block();
    b.ins().jump(head, &[]);
    b.switch_to_block(head);
    let rest = b.use_var(remaining);
    let pair = b.ins().icmp_imm(IntCC::UnsignedGreaterThanOrEqual, rest, 2);
    b.ins().brif(pair, body, &[], tail, &[]);
    b.switch_to_block(body);
    // Each accumulator observes k, then k+1, with separate rounded operations.
    // The first complete term precedes the second; there are no partial sums.
    term(b, true);
    term(b, true);
    let next = b.ins().iadd_imm(rest, -2);
    b.def_var(remaining, next);
    b.ins().jump(head, &[]);
    b.switch_to_block(tail);
    let rest = b.use_var(remaining);
    let nonempty = b.ins().icmp_imm(IntCC::NotEqual, rest, 0);
    b.ins().brif(nonempty, last, &[], done, &[]);
    b.switch_to_block(last);
    term(b, false);
    b.ins().jump(done, &[]);
'''+s[z:];p.write_text(s)
p=base/'numeric_cell_prefix.rs';s=p.read_text();needle='    Some(Prefix {\n        first,'
new='''    // A load-only group exporting every F64 value removes no checked float
    // classification. Its speculative admission/fallback adds work and code;
    // retain the original direct native reads/control for such source regions.
    let checked_floats = reads.len() + steps.iter().filter(|(output, step)| {
        kinds[output] == Kind::F64 && matches!(step, Step::Primitive(_, _))
    }).count();
    let escaping_floats = exports.iter().filter(|output| kinds[output] == Kind::F64).count();
    if checked_floats <= escaping_floats { return None; }
'''+needle
assert needle in s;s=s.replace(needle,new,1);p.write_text(s)
p=base/'numeric_dot_core_tests.rs';s=p.read_text().replace('[0u64, 1, 2, 3, 7, 9]', '[0u64, 1, 2, 3, 4, 5, 7, 8, 9, 17]').replace('[8i64, -8, 24, -24]', '[0i64, 8, -8, 24, -24]')
a=s.index('        let groups = f\n',s.index('fn ordered_map_dot_core_ssa_'));z=s.index('        let (_module, _, assembly) = compile(f);',a)
s=s[:a]+'''        let mut groups = Vec::new();
        for block in f.layout.blocks() {
            let terms = f.layout.block_insts(block).filter(|&i| f.dfg.insts[i].opcode() == Opcode::Fmul).collect::<Vec<_>>();
            if terms.is_empty() {continue;}
            assert!(!f.layout.block_insts(block).any(|i|matches!(f.dfg.insts[i].opcode(),Opcode::Imul|Opcode::Udiv|Opcode::Sdiv)), "source stream address products/divisions disappeared from the actual term blocks");
            let mut right_uses = std::collections::BTreeMap::new();
            for &term in &terms { *right_uses.entry(f.dfg.inst_args(term)[1]).or_insert(0usize) += 1; }
            let mut uses = right_uses.values().copied().collect::<Vec<_>>();uses.sort();groups.push(uses);
            let adds = f.layout.block_insts(block).filter(|&i|f.dfg.insts[i].opcode()==Opcode::Fadd).collect::<Vec<_>>();
            assert_eq!(adds.len(),terms.len());
            if adds.len()==8 {
                for row in 0..4 { assert_eq!(f.dfg.inst_args(adds[row+4])[0],f.dfg.first_result(adds[row]), "second source term uses the first term's rounded accumulator"); }
            }
        }
        groups.sort();assert_eq!(groups,vec![vec![4],vec![4,4]], "two four-row terms plus guarded single-term tail: {}", f.display());
'''+s[z:];p.write_text(s)
p=Path('hosts/gpu/src/native_artifact/program/image/identity.rs');s=p.read_text().replace('NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 430;', 'NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 436;');assert s!=p.read_text();p.write_text(s)
p=Path('hosts/gpu/src/native_artifact/program/runtime/composition_tests/cell_prefix.rs');s=p.read_text();s+='''
#[test]
fn cell_prefix_load_only_escaping_values_keep_original_checks_and_public_errors() {
    let ordinary = source("a[r,c] + a[r,c + offset]", [2, 5]);
    let text = ordinary.replace("value := a[r,c] + a[r,c + offset]", "left := a[r,c]\\n        right := a[r,c + offset]\\n        value := ((left < right)? | true => right | false => left)");
    assert_ne!(ordinary,text);
    for artifact in artifacts(&text) {
        let catalog = mech_stdlib::source_catalog();
        let fast = JitProgramArtifact::compile(&artifact,&catalog).unwrap();
        let old = JitProgramArtifact::compile_for_test(&artifact,&catalog,OptimizationPass::CellExpressionPrefixes).unwrap();
        let metadata = fast.descriptor().metadata();
        assert!(metadata.closed_tails.regions.iter().filter_map(|r|r.numeric.as_ref()).all(|proof|numeric_cell_prefix::derive(&metadata.plan.facts(),proof).is_empty()), "two escaping loads collapse no floating classifications");
        let object = crate::native_artifact::emit_program_object(&artifact,&catalog).unwrap();
        assert!(object.metadata()["compiled_numeric_write_loops"].as_array().unwrap().iter().all(|row|row["cell_expression_prefixes"].as_array().unwrap().is_empty()), "ordinary native checks actually emitted");
        let mode=NativeProgramLimitMode::NoLimits;let memory=mode.memory_budget();
        for special in [None,Some(0x7ff0_1234_5678_9abcu64),Some(f64::INFINITY.to_bits())] {
            let mut cells=(0..10).map(|n|Data::F64(F64Bits::from_f64(n as f64/13.0))).collect::<Vec<_>>();
            if let Some(bits)=special {cells[3]=Data::F64(F64Bits::from_bits(bits));}
            for last in [5,6] {
                let args=numeric_maps::typed_arguments(&artifact,&memory,&[
                    ("input",Data::Matrix(cells.clone().into()),&[2,5]),("row",Data::U64(1),&[]),("first",Data::U64(1),&[]),("last",Data::U64(last),&[]),("offset",Data::U64(1),&[]),("gain",Data::F64(F64Bits::from_f64(9.0)),&[]),
                ]);
                for restored in [false,true] {compare(&fast,&old,&artifact,&args,&memory,mode.execution(),restored);}
            }
        }
    }
}
''';p.write_text(s)
paths=[base/'numeric_dot_core.rs',base/'numeric_dot_core_tests.rs',base/'numeric_cell_prefix.rs',p,Path('hosts/gpu/src/native_artifact/program/image/identity.rs')]
subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true',*map(str,paths)],check=True)
print('Implemented source profitability and paired carried-address ordered reductions; strengthened semantic/public checks.')
