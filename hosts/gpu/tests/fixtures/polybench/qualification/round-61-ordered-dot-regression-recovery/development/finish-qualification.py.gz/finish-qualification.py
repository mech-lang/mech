from pathlib import Path
import subprocess,sys,json
f=Path(__file__).resolve().parent
for name in ['prepare-qualification-manifest.py','emission-census.py','untimed-counter-gate.py']:
 print('Starting',name,flush=True);subprocess.run([sys.executable,str(f/name)],check=True)
r=json.loads((f/'emission-census.json').read_text());proto=json.loads((f/'prototype-result.json').read_text());assert r['passed']and proto['passed']
physical={'compiler_fingerprint':r['compiler_fingerprint'],'genuine_object_matches_prototype':True,'seidel_native_code_and_stack_match_round60':r['seidel_lowering_retained'],'unproductive_nussinov_prefix_absent':r['unproductive_prefixes_absent'],'productive_residual_prefix':proto['productive_residual_prefix'],'paired_ordered_dot_emitted':r['ordered_dot_change_emitted'],'paired_loops':r['cases']['3mm']['actors']['candidate']['ordered_dot_paired_loops'],'case_code_stack':{n:{a:{k:v[k]for k in ['code_bytes','reported_native_stack_bytes','static_instruction_count']}for a,v in c['actors'].items()}for n,c in r['cases'].items()},'no_new_fma':r['no_new_fma'],'performance_observations':0,'limit':'Static instructions include cold code and are not hardware retirement or latency claims. Preserve source arithmetic/counters; no source program change.'}
(f/'physical-transformation.json').write_text(json.dumps(physical,indent=2)+'\n')
subprocess.run([sys.executable,str(f/'preserve-qualification.py')],check=True)
