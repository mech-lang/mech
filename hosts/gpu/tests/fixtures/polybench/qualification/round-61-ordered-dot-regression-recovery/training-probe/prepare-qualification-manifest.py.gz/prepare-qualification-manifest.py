"""Assemble frozen correctness evidence before any candidate timing."""
import importlib.util
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
state=b.read(folder/'current-work.json');plan=b.read(folder/'plan.json');focused=b.read(folder/'focused-result.json');checks=b.read(folder/'qualification-checks.json');build=b.read(folder/'driver-build-result.json');fp=b.compiler_fingerprint()
assert focused['exit_code']==0 and focused['source_unchanged'] and focused['passed_tests']==[9]
assert checks['complete'] and checks['driver_build_complete'] and len(checks['checks'])==11
assert all(c['exit_code']==0 for c in checks['checks']) and all(sum(c['passed_tests'])>0 for c in checks['checks'][:9])
assert any(c['name']=='matrix-polybench.log' and c['passed_tests']==[24,30] for c in checks['checks'])
assert build['exit_code']==0 and build['source_unchanged']
assert fp==focused['compiler_fingerprint']==checks['compiler_fingerprint']==build['compiler_fingerprint']==state['compiler_fingerprint']
driver=folder/'ordered-dot-regression-recovery-complete-driver';assert b.digest(driver)==checks['driver_sha256']
output=folder/'qualification.json';assert not output.exists()
checks.update(versions=plan['versions'],source_parent=plan['source_parent'],source_uncommitted=bool(b.command(['git','status','--porcelain','--',*plan['source_paths']])),dataset='MINI',numeric_profile='F64',new_performance_samples=0,source_sha256={p:b.digest(root/p) for p in plan['source_paths']},driver_build=build,focused_checks=focused)
b.write(output,checks);print({'compiler_fingerprint':fp,'broad_checks':checks['tests'],'focused_checks':focused['passed_tests'],'driver_sha256':checks['driver_sha256'],'performance_observations':0},flush=True)
