from pathlib import Path
import importlib.util,json,os,shutil,subprocess,time,sys
sys.path.insert(0,str(Path(__file__).resolve().parent));from importlib.machinery import SourceFileLoader
st=SourceFileLoader('st',str(Path(__file__).resolve().parent/'static-tools.py')).load_module()
root=Path.cwd();f=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(s);s.loader.exec_module(b)
plan=b.read(f/'plan.json');focus=b.read(f/'focused-result.json');fp=b.compiler_fingerprint();assert focus['exit_code']==0 and focus['passed_tests']==[9]and fp==focus['compiler_fingerprint']and focus['source_unchanged']
p=f/('prototype'+('-'+sys.argv[1]if len(sys.argv)>1 else ''));p.mkdir(exist_ok=False)
for name in plan['source_paths']:
 out=p/'source'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((root/name).read_bytes())
env=os.environ.copy();target=Path('/private/tmp/mech-polybench-pr1000-target');env['CARGO_TARGET_DIR']=str(target);argv=['cargo','build','--release','-p','mech-gpu','--no-default-features','--features','canonical-native-program','--example','polybench_qualification'];started=time.monotonic()
with(p/'build.log').open('x')as log:child=subprocess.Popen(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT);print('Prototype build PID',child.pid,flush=True);code=child.wait()
b.write(p/'build.json',{'command':argv,'pid':child.pid,'exit_code':code,'compiler_fingerprint':fp,'source_unchanged':b.compiler_fingerprint()==fp,'wall_seconds':time.monotonic()-started,'performance_observations':0});assert code==0 and b.compiler_fingerprint()==fp
binary=f/'ordered-dot-regression-recovery-prototype-driver';shutil.copy2(target/'release/examples/polybench_qualification',binary)
_,cases=b.protocol();old=b.read(b.FIXTURE/'round-60-static-telemetry.json');rows={}
for name in ['seidel-2d','nussinov','3mm','cholesky']:
 config=p/f'{name}-inputs.json';b.write(config,cases[name]['inputs']);obj=p/f'{name}.o';argv=[str(binary),str(b.FIXTURE/f'{name}.mec'),str(config),'0','emit-object='+str(obj)]
 with(p/f'{name}.stdout').open('x')as out,(p/f'{name}.stderr').open('x')as err:child=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err);code=child.wait()
 assert code==0;status=json.loads((p/f'{name}.stdout').read_text().strip().splitlines()[-1]);assert status['status']=='ok'and status['mode']=='emit-object'
 asm=subprocess.check_output(['/Library/Developer/CommandLineTools/usr/bin/llvm-objdump','--disassemble','--no-show-raw-insn',str(obj)],text=True);(p/f'{name}.disasm.txt').write_text(asm);md=b.read(obj.with_suffix('.metadata.json'));fm=st.functions(asm)
 rows[name]={'code_bytes':md['code_bytes'],'reported_native_stack_bytes':md['stack_bytes'],'functions':fm,'object_sha256':b.digest(obj),'cell_expression_prefixes':st.records(md,'cell_expression_prefixes'),'ordered_dot_paired_loops':st.paired_loops(asm),'native_functions_match_round60':st.matches(old['cases'][name]['actors']['candidate']['functions'],fm),'object_executed':False}
 print(name,'code',md['code_bytes'],'stack',md['stack_bytes'],'prefixes',rows[name]['cell_expression_prefixes'],'paired loops',len(rows[name]['ordered_dot_paired_loops']),flush=True)
s=rows['seidel-2d'];n=rows['nussinov'];retained=s['native_functions_match_round60']and s['code_bytes']==old['cases']['seidel-2d']['actors']['candidate']['code_bytes']and s['reported_native_stack_bytes']==old['cases']['seidel-2d']['actors']['candidate']['reported_native_stack_bytes']
r={'schema':'mech.polybench.source-frozen-static-prototype.v1','compiler_fingerprint':fp,'driver_sha256':b.digest(binary),'cases':rows,'seidel_lowering_retained':retained,'unproductive_prefixes_absent':n['cell_expression_prefixes']==[[104,109,2,2]],'ordered_dot_change_emitted':bool(rows['3mm']['ordered_dot_paired_loops']),'source_unchanged':b.compiler_fingerprint()==fp,'performance_observations':0,'interpretation':'Actual genuine Objects retain Seidel native code/stack exactly from round60, remove unproductive Nussinov regions, and bind the shared two-term four-row loop without inner integer address products. This establishes a physical transformation, not latency or hardware retirement.'}
r['passed']=r['seidel_lowering_retained']and r['unproductive_prefixes_absent']and r['ordered_dot_change_emitted']and r['source_unchanged'];b.write(f/'prototype-result.json',r);b.write(p/'result.json',r);print(json.dumps({k:v for k,v in r.items()if k!='cases'}),flush=True)

raise SystemExit(0 if r["passed"] else 1)
