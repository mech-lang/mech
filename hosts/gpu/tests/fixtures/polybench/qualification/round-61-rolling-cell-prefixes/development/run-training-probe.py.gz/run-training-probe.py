"""Run the single planned probe; retain its exact process until terminal."""
import json,subprocess,sys,time
from pathlib import Path
folder=Path(__file__).resolve().parent
assert not (folder/'training-probe.json').exists() and not (folder/'training-probe.exit.json').exists()
q=json.loads((folder/'qualification.json').read_text())
command=[sys.executable,str(folder/'training-probe.py'),'--driver',q['driver'],'--qualification',str(folder/'qualification.json')]
started=time.monotonic()
with (folder/'training-probe.log').open('x') as log:
 child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
 print('Prospective optimization probe process',child.pid,flush=True)
 while True:
  try:code=child.wait(timeout=30);break
  except subprocess.TimeoutExpired:print('Waiting on same optimization probe process',child.pid,flush=True)
(folder/'training-probe.exit.json').write_text(json.dumps({'command':command,'pid':child.pid,'exit_code':code,'wall_seconds':time.monotonic()-started})+'\n')
print('Probe terminal exit',code,flush=True)
print('\n'.join((folder/'training-probe.log').read_text().splitlines()[-18:]),flush=True)
raise SystemExit(code)
