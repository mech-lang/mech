"""Preserve all attempted source/correctness evidence before the sole probe."""
import gzip,importlib.util,json,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(s);s.loader.exec_module(b)
p=b.FIXTURE;plan=b.read(folder/'plan.json');q=b.read(folder/'qualification.json');gate=b.read(folder/'untimed-counter-gate.json');emission=b.read(folder/'emission-census.json');fp=b.compiler_fingerprint()
assert b.command(['git','branch','--show-current'])=='codex/polybench-native-matrices'
assert q['complete']and q['driver_build_complete']and q['tests']>=780 and q['focused_checks']['passed_tests']==[11]
assert fp==q['compiler_fingerprint']==gate['compiler_fingerprint']==emission['compiler_fingerprint']
assert gate['complete']and gate['passed']and gate['finite_liveouts']==17002 and all(row['all_counters_match']for row in gate['cases'].values())
assert emission['complete']and emission['passed']and emission['cell_prefixes_emitted']and emission['no_new_fma']
assert b.digest(q['driver'])==q['driver_sha256']and len(b.read(p/'performance-history.json')['entries'])==61 and b.read(p/'performance-acceptance.json')['accepted_history_index']==59
assert not(folder/'training-probe.json').exists()
paths=plan['source_paths'];changed=subprocess.check_output(['git','diff','--name-only',plan['source_parent'],'--'],text=True).splitlines();changed+=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines();actual=sorted({name for name in changed if name.endswith(('.rs','.toml'))or Path(name).name=='Cargo.lock'})
assert set(actual)==set(paths) and len(paths)==12 and all(b.digest(root/name)==q['source_sha256'][name]for name in paths)
source_snapshot=folder/'qualified-source';source_snapshot.mkdir(exist_ok=False)
for name in paths:
 out=source_snapshot/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((root/name).read_bytes())
patch=[subprocess.check_output(['git','diff',plan['source_parent'],'--',*paths])]
for name in paths:
 if subprocess.run(['git','cat-file','-e',plan['source_parent']+':'+name],capture_output=True).returncode:
  added=subprocess.run(['git','diff','--no-index','--','/dev/null',name],capture_output=True)
  assert added.returncode==1
  patch.append(added.stdout)
(folder/'qualified-source.patch').write_bytes(b''.join(patch))
attempts=[{'path':str(f.relative_to(folder)),'sha256':b.digest(f),'result':b.read(f),'source_snapshot_files':len(list((f.parent/'source').rglob('*.rs')))}for f in sorted(folder.glob('attempt-*/*-result.json'))]
assert len(attempts)>=2 and attempts[-1]['result']['exit_code']==0 and attempts[-1]['result']['compiler_fingerprint']==fp
source_audit={'schema':'mech.polybench.rolling-cell-prefix-source-audit.v1','compiler_fingerprint':fp,'reviewed':True,'passed':True,
 'closure':'Private actual source values, definition/read-role facts, same iteration and complete source/phase/debit boundary inventory; bounded straight-line pure prefix, one escaping F64 result and one tracked matrix mutation. All reads use this array, affine independent row/column offsets with every checked integer intermediate classified.',
 'continuation':'Exact original frame/copy recipes resolve the same source carrier path to the completed matrix, unchanged row and checked column+1. No invented structural ordinal or runtime witness. Other latch predecessors invalidate. Child/loop versions, appends, other writes/maps/reductions/fallback operations decline.',
 'reuse':'Current(dr,dc) reuses previous(dr,dc+1), except current(0,-1) uses the previous completed write result. No owner/pointer is cached. First COW keeps every other cell unchanged. Current source scalar captures and pointer are reloaded normally. Stage only after finite-result validation; publish cache validity only at completed original write/no-op.',
 'admission':'Fresh points reconstruct every original checked U64 subexpression and independently admit every distinct one-based row/column before any load. The exact same-row unit-column edge inherits valid row and lower bounds, retaining upper and checked overflow guards for all column subexpressions. A miss/nonfinite result invalidates before exact lexical replay at current state. Exact center-read source value/bounds supply old-first comparison only with sole-prefix predecessor/no intervening mutation.',
 'static_axes':'Only source-static dimensions from the same entry-library witness already used by fixed_length. Appending banks never qualify. Current geometry/owner/epoch/span/capacity/schema admission remains. No global readonly/alias/alignment claim.',
 'arithmetic_and_accounting':'Original separate scalar F64 operand tree, term order and rounding through the shared emitter. No reassociation/FMA/reciprocal substitution/dependent-output SIMD. Original source work/comparison/control/visits remain exact. Bounded SSA cache is private to one numeric invocation, without new helper/frame/ABI/per-operation allocation. Existing emitted source and boundary instruction envelopes include cache code/init. No padding or reduced fees.',
 'evidence':'Eleven focused groups passed: actual emitted rolling kernel agrees with ordered reference on shapes, repeated rows/turns, fresh/reuse counts, canaries, late upper/overflow/nonfinite refusal before failing store and inactive null banks; genuine source and Object prove9-to3 recipe/center reuse; original/decoded/restored three-way cached/uncached/original exact reports/errors/payloads, aliases, no-op/COW, previous outputs, finite denials and cleanup/retry; refused nonunit columns, changed rows, wrong matrix, dynamic offsets and extra writes. Broad all30 and both features, exact17002 optimization C values/counters, genuine Objects and all attempted sources supplement these checks.',
 'policy':plan['invariants'],'performance_observations':0}
b.write(folder/'source-audit.json',source_audit)
dest=p/'qualification/round-61-rolling-cell-prefixes/development';dest.mkdir(parents=True,exist_ok=False);archives={}
for source in sorted(folder.rglob('*')):
 if not source.is_file()or '__pycache__'in source.parts or source.name.endswith('-driver'):continue
 name=str(source.relative_to(folder));raw=source.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw;archives[name]={'path':str(out.relative_to(p)),'sha256':b.digest(source),'compressed_sha256':b.digest(out)}
receipt={'schema':'mech.polybench.rolling-cell-prefixes-development.v1','created_at':b.utc(),'complete':True,'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'qualification_manifest':q,'effective_plan':plan,'selection_policy_sha256':b.digest(p/'performance-selection-policy-v4.json'),'source_parent':plan['source_parent'],'source_sha256':q['source_sha256'],'actual_changed_source_paths':actual,'profiling_basis':plan['profiling_basis'],'invariants':plan['invariants'],'counter_gate':gate,'emission_census':emission,'source_audit':source_audit,'development_attempts':attempts,'failed_attempt_logs_and_receipts_preserved':True,'performance_observations':0,'archives':archives}
b.write(p/'training-experiments/rolling-cell-prefixes-development.json',receipt);b.write(p/'training-experiments/rolling-cell-prefixes-training-schedule.json',b.read(folder/'training-probe-plan.json'));b.write(p/'training-experiments/rolling-cell-prefixes-route-census.json',gate)
subprocess.run(['git','diff','--check'],check=True);subprocess.run(['git','add','--',*paths,str(p.relative_to(root))],check=True)
r=subprocess.run(['git','-c','gc.auto=0','commit','-m','Qualify rolling point expression prefixes'],capture_output=True,text=True);(folder/'qualification-source-commit.log').write_text(r.stdout+r.stderr);assert r.returncode==0
head=b.command(['git','rev-parse','HEAD']);assert b.compiler_fingerprint()==fp and b.command(['git','status','--porcelain'])==''
b.write(folder/'qualification-source-commit.json',{'source_commit':head,'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'performance_observations':0,'archives_verified':len(archives),'clean':True})
print(json.dumps({'head':head,'compiler_fingerprint':fp,'broad_checks':q['tests'],'focused_checks':11,'changed_cases':emission['native_code_changed_cases'],'archives_verified':len(archives),'clean':True}),flush=True)
