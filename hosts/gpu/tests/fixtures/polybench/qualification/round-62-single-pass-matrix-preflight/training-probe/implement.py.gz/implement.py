from pathlib import Path
import subprocess
p=Path('hosts/gpu/src/native_artifact/program/runtime/invocation/numeric_product_epilogues.rs');s=p.read_text()
needle='            let mut domain_axes = [0usize; 2];\n';assert needle in s;s=s.replace(needle,needle+'''            // Pure source bounds are computed once for this exact geometry.
            // Reuse their replay credit; no metadata or loan survives the call.
            let mut replay = 0u64;
            let mut output_shape = None;
''',1)
s=s.replace('                let (demand, replay) = match node.kind {','                let (demand, node_replay) = match node.kind {',1)
needle='''                // Every omitted logical factory still has its original shape.
''';assert needle in s;s=s.replace(needle,'                replay = replay.checked_add(node_replay)?;\n'+needle,1)
needle='''                mech_core::shape_for_resolved_extents(
                    m.plan.values()[node.output.get() as usize].definition(),
                    &[rows, columns],
                )
                .ok()?;'''
new='''                let source_shape = mech_core::shape_for_resolved_extents(
                    m.plan.values()[node.output.get() as usize].definition(),
                    &[rows, columns],
                )
                .ok()?;
                if index + 1 == recipe.nodes.len() && node.output == recipe.output {
                    output_shape = Some(source_shape);
                }'''
assert needle in s;s=s.replace(needle,new,1)
s=s.replace('''                // No per-node replay arrays are required after this preflight.
                let _ = replay;
''','',1)
needle='''            let shape = mech_core::shape_for_resolved_extents(
                m.plan.values()[recipe.output.get() as usize].definition(),
                &[rows, columns],
            )
            .ok()?;'''
new='''            // The last-node axis equality above proves these are the same
            // extents. Only the exact same source output may reuse its shape;
            // a differently named alias retains its original validation.
            let shape = match output_shape {
                Some(shape) => shape,
                None => mech_core::shape_for_resolved_extents(
                    m.plan.values()[recipe.output.get() as usize].definition(),
                    &[rows, columns],
                ).ok()?,
            };'''
assert needle in s;s=s.replace(needle,new,1)
start=s.index('            let mut replay = 0u64;',s.index('            let mut max_elements = count;'));end=s.index('                compute = compute.checked_add(demand.work.compute)?;',start)
s=s[:start]+'''            for (index, (node, demand)) in recipe.nodes.iter().zip(&demands).enumerate() {
'''+s[end:];p.write_text(s)
p=Path('hosts/gpu/src/native_artifact/program/image/identity.rs');s=p.read_text().replace('NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 430;', 'NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 437;');assert s!=p.read_text();p.write_text(s)
subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true',str(p),'hosts/gpu/src/native_artifact/program/runtime/invocation/numeric_product_epilogues.rs'],check=True)
print('Implemented single-pass exact resource/replay planning and exact-source output shape reuse; original dot core retained.')
