from pathlib import Path
import io,tokenize
f=Path(__file__).resolve().parent;old=Path('/private/tmp/mech-polybench-optimization/round-81/ordered-dot-regression-recovery')
names=['run-qualification.py','prepare-qualification-manifest.py','emission-census.py','untimed-counter-gate.py','preserve-qualification.py','training-probe.py','run-training-probe.py','preserve-training.py','preserve-unselected.py','measure-candidate.py','audit-results.py','run-formal.py','finalize-formal.py','finish-qualification.py']
for name in names:
 s=(old/name).read_text().replace('ordered-dot-regression-recovery','single-pass-matrix-preflight').replace('round-81','round-82').replace('round-61','round-62').replace('history61','history62').replace('history61','history62')
 s=s.replace('[9]','[34]').replace("focused_selected_checks']==9", "focused_selected_checks']==34").replace("focused_checks':9", "focused_checks':34").replace("focused_selected_checks':9", "focused_selected_checks':34").replace('9 focused','34 focused').replace('Nine focused','Thirty-four focused').replace('len(paths)==11','len(paths)==10')
 ts=[]
 for t in tokenize.generate_tokens(io.StringIO(s).readline):
  if t.type==tokenize.NUMBER and t.string in ['61','62','436']:
   t=t._replace(string={'61':'62','62':'63','436':'437'}[t.string])
  ts.append(t)
 s=tokenize.untokenize(ts)
 (f/name).write_text(s)
print('Prepared formal62 / history63 scripts with exact34 focused checks and10 source paths.')
