import hashlib,re

def functions(asm):
 rows={};name=None
 for line in asm.splitlines():
  m=re.match(r'^[0-9a-f]+ <_(.+)>:',line)
  if m:name=m[1];rows[name]=[]
  elif name and re.match(r'^\s*[0-9a-f]+:',line):rows[name].append(line)
 return {name:{'instructions':len(lines),'disassembly_sha256':hashlib.sha256('\n'.join(lines).encode()).hexdigest()}for name,lines in rows.items()}
def matches(old,new):
 return set(old)==set(new)and all(all(new[name][key]==old[name][key]for key in ['instructions','disassembly_sha256'])for name in old)
def records(value,key):
 if isinstance(value,dict):return sum((v if k==key else records(v,key)for k,v in value.items()),[])
 if isinstance(value,list):return sum((records(v,key)for v in value),[])
 return []
