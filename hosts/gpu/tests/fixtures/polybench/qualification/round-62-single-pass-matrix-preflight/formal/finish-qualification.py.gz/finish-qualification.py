from pathlib import Path
import subprocess,sys,json
f=Path(__file__).resolve().parent
for name in ['prepare-qualification-manifest.py','emission-census.py','untimed-counter-gate.py']:
 print('Starting',name,flush=True);subprocess.run([sys.executable,str(f/name)],check=True)
r=json.loads((f/'emission-census.json').read_text());proto=json.loads((f/'prototype-result.json').read_text());assert r['passed']and proto['passed']
physical={'compiler_fingerprint':r['compiler_fingerprint'],'genuine_object_matches_prototype':True,'seidel_native_code_and_stack_match_round60':r['seidel_lowering_retained'],'matrix_native_code_matches_round60':r['matrix_lowering_retained'],'unproductive_nussinov_prefix_absent':r['unproductive_prefixes_absent'],'source_prefixes':proto['cases']['nussinov']['cell_expression_prefixes'],'host_preflight_reduced':r['host_preflight_reduced'],'host_assembly':r['host_assembly'],'case_code_stack':{n:{a:{k:v[k]for k in ['code_bytes','reported_native_stack_bytes','static_instruction_count']}for a,v in c['actors'].items()}for n,c in r['cases'].items()},'no_new_fma':r['no_new_fma'],'performance_observations':0,'limit':'Static host/Mech instructions are separate from hardware retirement or latency. Source arithmetic/counters remain; no source program change.'}
(f/'physical-transformation.json').write_text(json.dumps(physical,indent=2)+'\n')
subprocess.run([sys.executable,str(f/'preserve-qualification.py')],check=True)
