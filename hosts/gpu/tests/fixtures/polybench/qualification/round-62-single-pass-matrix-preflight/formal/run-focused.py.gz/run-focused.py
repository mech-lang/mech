import importlib.util,json,os,subprocess,re,time,sys
from pathlib import Path
root=Path.cwd();f=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(s);s.loader.exec_module(b)
a=f/('attempt-'+sys.argv[1]);a.mkdir(exist_ok=False);fp=b.compiler_fingerprint()
for name in b.read(f/'plan.json')['source_paths']:
 out=a/'source'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((root/name).read_bytes())
argv=['cargo','test','--release','-p','mech-gpu','--no-default-features','--features','canonical-native-program','--lib','--','cell_prefix','numeric_product_epilogues','numeric_reduction_producers','numeric_product_views','--test-threads=1'];env=os.environ.copy();env['CARGO_TARGET_DIR']='/private/tmp/mech-polybench-pr1000-target';start=time.monotonic()
b.write(f/'current-work.json',{'stage':'Complete focused single-pass matrix-preflight and productive-prefix qualification running before any timing','compiler_fingerprint':fp,'pid':os.getpid(),'complete':False})
with(a/'focused.log').open('x')as log:r=subprocess.run(argv,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt={'command':argv,'compiler_fingerprint':fp,'exit_code':r.returncode,'source_unchanged':b.compiler_fingerprint()==fp,'wall_seconds':time.monotonic()-start,'passed_tests':[int(n)for n in re.findall(r'test result: ok[.] (\d+) passed',(a/'focused.log').read_text())]};b.write(a/'focused-result.json',receipt);b.write(f/'focused-result.json',receipt)
print(json.dumps(receipt),flush=True);print('\n'.join((a/'focused.log').read_text().splitlines()[-70:]),flush=True)
raise SystemExit(r.returncode)
