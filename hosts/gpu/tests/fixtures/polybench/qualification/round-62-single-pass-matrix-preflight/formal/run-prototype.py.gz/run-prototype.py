from pathlib import Path
import importlib.util,json,os,shutil,subprocess,time,sys
sys.path.insert(0,str(Path(__file__).resolve().parent));from importlib.machinery import SourceFileLoader
st=SourceFileLoader('st',str(Path(__file__).resolve().parent/'static-tools.py')).load_module()
root=Path.cwd();f=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(s);s.loader.exec_module(b)
plan=b.read(f/'plan.json');focus=b.read(f/'focused-result.json');fp=b.compiler_fingerprint();assert focus['exit_code']==0 and focus['passed_tests']==[34]and fp==focus['compiler_fingerprint']and focus['source_unchanged']
p=f/('prototype'+('-'+sys.argv[1]if len(sys.argv)>1 else ''));p.mkdir(exist_ok=False)
for name in plan['source_paths']:
 out=p/'source'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((root/name).read_bytes())
env=os.environ.copy();target=Path('/private/tmp/mech-polybench-pr1000-target');env['CARGO_TARGET_DIR']=str(target);argv=['cargo','build','--release','-p','mech-gpu','--no-default-features','--features','canonical-native-program','--example','polybench_qualification'];started=time.monotonic()
with(p/'build.log').open('x')as log:child=subprocess.Popen(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT);print('Prototype build PID',child.pid,flush=True);code=child.wait()
b.write(p/'build.json',{'command':argv,'pid':child.pid,'exit_code':code,'compiler_fingerprint':fp,'source_unchanged':b.compiler_fingerprint()==fp,'wall_seconds':time.monotonic()-started,'performance_observations':0});assert code==0 and b.compiler_fingerprint()==fp
binary=f/'single-pass-matrix-preflight-prototype-driver';shutil.copy2(target/'release/examples/polybench_qualification',binary)
_,cases=b.protocol();old=b.read(b.FIXTURE/'round-60-static-telemetry.json');rows={}
for name in ['seidel-2d','nussinov','3mm','mvt','bicg']:
 config=p/f'{name}-inputs.json';b.write(config,cases[name]['inputs']);obj=p/f'{name}.o';argv=[str(binary),str(b.FIXTURE/f'{name}.mec'),str(config),'0','emit-object='+str(obj)]
 with(p/f'{name}.stdout').open('x')as out,(p/f'{name}.stderr').open('x')as err:child=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err);code=child.wait()
 assert code==0;status=json.loads((p/f'{name}.stdout').read_text().strip().splitlines()[-1]);assert status['status']=='ok'and status['mode']=='emit-object'
 asm=subprocess.check_output(['/Library/Developer/CommandLineTools/usr/bin/llvm-objdump','--disassemble','--no-show-raw-insn',str(obj)],text=True);(p/f'{name}.disasm.txt').write_text(asm);md=b.read(obj.with_suffix('.metadata.json'));fm=st.functions(asm)
 rows[name]={'code_bytes':md['code_bytes'],'reported_native_stack_bytes':md['stack_bytes'],'functions':fm,'object_sha256':b.digest(obj),'cell_expression_prefixes':st.records(md,'cell_expression_prefixes'),'native_functions_match_round60':st.matches(old['cases'][name]['actors']['candidate']['functions'],fm),'object_executed':False}
 print(name,'code',md['code_bytes'],'stack',md['stack_bytes'],'prefixes',rows[name]['cell_expression_prefixes'],flush=True)
s=rows['seidel-2d'];n=rows['nussinov'];retained=s['native_functions_match_round60']and s['code_bytes']==old['cases']['seidel-2d']['actors']['candidate']['code_bytes']and s['reported_native_stack_bytes']==old['cases']['seidel-2d']['actors']['candidate']['reported_native_stack_bytes']
matrix_same=all(rows[name]['native_functions_match_round60'] and rows[name]['code_bytes']==old['cases'][name]['actors']['candidate']['code_bytes'] and rows[name]['reported_native_stack_bytes']==old['cases'][name]['actors']['candidate']['reported_native_stack_bytes'] for name in ['3mm','mvt','bicg'])
def host_assembly(driver,stem):
    nm=subprocess.check_output(['/usr/bin/nm',str(driver)],text=True)
    (p/(stem+'.nm.txt')).write_text(nm)
    names=[line.split()[-1]for line in nm.splitlines()if line.split()and 'numeric_product_helper'in line.split()[-1]]
    assert names
    rows=[]
    for index,name in enumerate(names):
        text=subprocess.check_output(['/Library/Developer/CommandLineTools/usr/bin/llvm-objdump','--disassemble-symbols='+name,'--no-show-raw-insn',str(driver)],text=True)
        (p/(stem+f'-family-{index}.disasm.txt')).write_text(text)
        inst=[line for line in text.splitlines()if __import__('re').match(r'^\s*[0-9a-f]+:',line)]
        assert inst
        calls=[line.strip()for line in inst if __import__('re').search(r'\bbl\s',line)and 'source_bound'in line]
        rows.append({'symbol':name,'instructions':len(inst),'resource_bound_call_sites':len(calls),'calls':calls})
    return {'functions':rows,'instructions':sum(row['instructions']for row in rows),'resource_bound_call_sites':sum(row['resource_bound_call_sites']for row in rows)}
old_host=host_assembly(Path(plan['accepted_driver']),'accepted59-host')
new_host=host_assembly(binary,'candidate-host')
# The runtime helper is unchanged between accepted59 and the exact round60
# foundation. Compare actual host instructions; Mech kernels above are separate.
host_reduced=new_host['resource_bound_call_sites']<old_host['resource_bound_call_sites'] and new_host['instructions']<old_host['instructions']
r={'schema':'mech.polybench.source-frozen-static-prototype.v1','compiler_fingerprint':fp,'driver_sha256':b.digest(binary),'cases':rows,'seidel_lowering_retained':retained,'matrix_lowering_retained':matrix_same,'unproductive_prefixes_absent':n['cell_expression_prefixes']==[[104,109,2,2]],'host_preflight_reduced':host_reduced,'host_assembly':{'accepted59':old_host,'candidate':new_host},'source_unchanged':b.compiler_fingerprint()==fp,'performance_observations':0,'interpretation':'Exact round60 Mech native matrix/Seidel code retained. Pure resource sizing and final-source-shape reuse remove duplicate runtime preflight; actual Rust host source-bound call sites/instructions recorded separately. No schema-traversal or latency/hardware claim.'}
r['passed']=all(r[k]for k in ['seidel_lowering_retained','matrix_lowering_retained','unproductive_prefixes_absent','host_preflight_reduced','source_unchanged']);b.write(f/'prototype-result.json',r);b.write(p/'result.json',r);print(json.dumps({k:v for k,v in r.items()if k!='cases'}),flush=True)
raise SystemExit(0 if r['passed'] else 1)
