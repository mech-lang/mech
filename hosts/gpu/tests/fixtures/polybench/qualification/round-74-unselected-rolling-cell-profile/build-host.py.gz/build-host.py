from pathlib import Path
import subprocess,json,os,importlib.util,time
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
plan=b.read(folder/'plan.json');fp=b.compiler_fingerprint();assert fp==plan['compiler_fingerprint'];assert b.digest(folder/'residence.rs')==plan['host_source_sha256']
env=os.environ.copy();target=Path('/private/tmp/mech-polybench-pr1000-target');env['CARGO_TARGET_DIR']=str(target)
argv=['cargo','build','--release','-p','mech-gpu','--no-default-features','--features','canonical-native-program','--example','polybench_qualification','--message-format=json']
started=time.monotonic()
with (folder/'cargo-artifacts.jsonl').open('x') as out,(folder/'cargo-build.stderr').open('x') as err:r=subprocess.run(argv,cwd=root,env=env,stdout=out,stderr=err)
assert r.returncode==0,(folder/'cargo-build.stderr').read_text()
artifacts={}
for line in (folder/'cargo-artifacts.jsonl').read_text().splitlines():
 row=json.loads(line)
 if row.get('reason')=='compiler-artifact':
  libs=[p for p in row['filenames'] if p.endswith('.rlib')]
  if libs:artifacts[row['target']['name']]=libs[-1]
names=['serde_json','mech_core','mech_syntax','mech_engine','mech_stdlib','mech_gpu'];assert all(n in artifacts for n in names)
command=['rustc','--edition=2024','-C','opt-level=3','-D','warnings','-L','dependency='+str(target/'release/deps'),str(folder/'residence.rs'),'-o',str(folder/'residence-driver')]
for name in names:command.extend(['--extern',name+'='+artifacts[name]])
with (folder/'rustc-build.log').open('x') as out:r=subprocess.run(command,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
assert r.returncode==0,(folder/'rustc-build.log').read_text();assert b.compiler_fingerprint()==fp
receipt={'command':command,'cargo_command':argv,'exit_code':0,'wall_seconds':time.monotonic()-started,'compiler_fingerprint':fp,'source_unchanged':True,'source_sha256':b.digest(folder/'residence.rs'),'driver':str(folder/'residence-driver'),'driver_sha256':b.digest(folder/'residence-driver'),'native_source_generator':'Maintained public Cranelift JIT/Object APIs; rustc builds only the external host diagnostic wrapper.'};b.write(folder/'residence-build.json',receipt)
protocol,cases=b.protocol()
for name in plan['cases']:b.write(folder/f'{name}-inputs.json',cases[name]['inputs'])
b.write(folder/'cpu-processes.json',{'scope':plan['method'],'compiler_fingerprint':fp,'driver_sha256':receipt['driver_sha256'],'cases':{},'complete':False,'official_performance_observations':0})
print(json.dumps(receipt),flush=True)
