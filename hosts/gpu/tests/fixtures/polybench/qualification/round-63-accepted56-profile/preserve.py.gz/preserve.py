from pathlib import Path
import gzip,json,subprocess,importlib.util
root=Path.cwd();f=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);p=b.FIXTURE
r=b.read(f/'profile-result.json');v=b.read(f/'jit-object-verification.json');binding=b.read(f/'instruction-binding.json');plan=b.read(f/'plan.json');fp=b.compiler_fingerprint()
assert fp==r['compiler_fingerprint']==v['compiler_fingerprint']==plan['compiler_fingerprint']
assert r['complete'] and v['complete'] and binding['complete'] and r['source_and_history_unchanged']
assert len(b.read(p/'performance-history.json')['entries'])==57 and b.read(p/'performance-acceptance.json')['accepted_history_index']==56
assert b.command(['git','status','--porcelain'])==''
for case in plan['cases']:
 row=r['processes']['cases'][case]
 assert row['driver_exit_code']==row['sample_exit_code']==0 and row['frozen_execution_counters_match'] and row['warmup_validation']['finite'] and row['final_validation']['finite']
 assert binding['cases'][case]['complete_instruction_binding']
a=r['analysis'];m=a['mvt.sample.txt'];sites={s['offset']:s for s in m['top_jit_sites']}
assert sites[0x215c]['samples']==127 and sites[0x2164]['samples']==144 and sites[0xf98]['samples']==102
interpretation={
 'scope':'Optimization15 diagnosis only, accepted56. No holdout profiling or performance observations.',
 'sample_scope':'Warm checked-call residence includes output reset/drop. Statistical self time is not an exact formal timer fraction, hardware retired instructions/IPC/cache/traffic measurement or a speedup forecast.',
 'cases':{case:{'execution_samples':a[case+'.sample.txt']['execution_samples'],'mechanisms':a[case+'.sample.txt']['self_time_mechanisms'],'top_self_functions':a[case+'.sample.txt']['top_self_functions'][:8]}for case in plan['cases']},
 'code_binding':'All complete sampled function ranges match genuine accepted56 Objects; Corr15088B/MVT10264B/D numeric7468B/G numeric20120B are byte-identical. D caller13768B/G caller35556B differ only in one ordinary4-byte BL relocation each; actual decoded calls resolve to the same sampled PIDs captured numeric function and every other byte matches. Hot instruction/window raw equality is recorded separately from relocation binding.',
 'mvt_transpose_witness':{'header':'0xf98 cmp x15,x4','body':'0x215c mov x0,x24; 0x2160 cbz x5; 0x2164 udiv x7,x15,x5; 0x2168 cbz x5; 0x216c udiv x8,x15,x5; 0x2170 msub; 0x2174 madd; 0x2178 ldr; 0x217c str; 0x2184 backedge','three_identified_pc_samples':373,'three_identified_pc_percent':373/m['execution_samples']*100,'interpretation':'These sampled PCs belong to the per-output-cell transpose ordinal loop, which emits quotient and remainder from a dynamic output width. They locate actual physical work and do not establish exact division latency or a forecast.'},
 'remaining_families':'Correlation and MVT have22.06%/19.35% allocation self time and15.99%/10.98% schema/planning self time. Gram-Schmidt generated code80.57%, with selected evaluation/publication dominant. Durbin generated code41.18%; its new direct-dot loop is actually sampled. Independent-output SIMD projection is also reached in Gram-Schmidt.',
 'history_review':'Sole-use transpose/product views and hoisted variants were fully qualified but unselected on single optimization probes0.9957168x and0.9883821x raw speedup against accepted47. Selected row-span publication was rejected55. Neither observed source is retried.',
 'selected_next_work':'Keep existing transpose owner, preparation/finish, source fees, spans, allocation and publication. Replace the native materialized transpose ordinal loop by dynamic two-by-two exact-bit SIMD tiles with row/column induction and bounded scalar tails. This removes per-cell dynamic quotient/remainder without adding a cross-operation loan or changing source semantics. Reuse the same emitter in generator transposes.',
 'limits':'A new fully qualified source requires its own single prospective optimization probe. Formal promotion uses only optimization Mech/C. No gain or goal completion is claimed from diagnostic sampling.'}
b.write(f/'interpretation.json',interpretation)
dest=p/'qualification/round-63-accepted56-profile';dest.mkdir(parents=True,exist_ok=False);archives={}
for source in sorted(f.rglob('*')):
 if not source.is_file() or '__pycache__'in source.parts or source.name=='residence-driver':continue
 name=str(source.relative_to(f));raw=source.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives[name]={'path':str(out.relative_to(p)),'sha256':b.digest(source),'compressed_sha256':b.digest(out)}
receipt={'schema':'mech.polybench.accepted-optimization-profile-evidence.v1','created_at':b.utc(),'accepted_round':56,'accepted_source_commit':b.read(p/'round-56-frozen.json')['source_commit'],'workspace_commit':b.command(['git','rev-parse','HEAD']),'compiler_fingerprint':fp,'driver_build':b.read(f/'residence-build.json'),'plan':plan,'same_pid_verification':v,'complete_instruction_binding':binding,'profile':r,'interpretation':interpretation,'official_performance_observations':0,'performance_history_entries_unchanged':57,'archives':archives}
b.write(p/'training-experiments/accepted56-profile.json',receipt)
b.write(p/'round-56-cpu-telemetry.json',{'schema':'mech.polybench.cpu-telemetry.v2','accepted_round':56,'compiler_fingerprint':fp,'source_and_history_unchanged':True,'official_performance_observations':0,'cases':r['processes']['cases'],'analysis':a,'same_pid_jit_object_verification':v,'complete_instruction_binding':binding,'interpretation':interpretation,'evidence':'training-experiments/accepted56-profile.json'})
with(p/'README.txt').open('a')as out:out.write('\nAccepted56 optimization-only CPU profiles\n\nCurrent Correlation/MVT/Durbin/Gram-Schmidt owned-process samples have22.92%/25.38%/41.18%/80.57% generated self time. Complete sampled code binds to exact accepted56 Objects, including actual same-PID local calls. Every process reaches terminal0 with finite C outputs and exact frozen counters. MVT materialized transpose still performs dynamic quotient/remainder per output cell;373 of2258 samples hit three PCs in that loop. This motivates division-free exact-bit transpose tiles with the existing owner/admission/publication boundaries. Previously unselected view-loan and selected-publication implementations are not retried. No timing/history change or performance forecast.\n\n[CPU telemetry](round-56-cpu-telemetry.json) · [Profiles and complete code binding](training-experiments/accepted56-profile.json)\n')
subprocess.run(['git','diff','--check'],check=True)
subprocess.run(['git','add','--',str(p.relative_to(root))],check=True)
subprocess.run(['git','commit','-q','-m','Bind accepted56 CPU profiles and identify dynamic transpose divisions'],check=True)
assert b.compiler_fingerprint()==fp and b.command(['git','status','--porcelain'])==''
print(json.dumps({'head':b.command(['git','rev-parse','HEAD']),'accepted_round':56,'archives_verified':len(archives),'history_entries':57,'official_performance_observations':0,'clean':True}),flush=True)
