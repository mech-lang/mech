"""Retain every development attempt and the single qualified training probe."""
import gzip, hashlib, importlib.util
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;q=b.read(folder/'qualification.json');census=b.read(folder/'execution-route-census.json');probe=b.read(folder/'training-probe.json');fp=b.compiler_fingerprint()
assert q['complete'] and census['complete'] and probe['complete']
assert fp==q['compiler_fingerprint']==census['compiler_fingerprint']==probe['compiler_fingerprint']
assert q['driver_sha256']==census['driver_sha256']==probe['driver_sha256']
assert all(c['exit_code']==0 for c in q['checks'])
assert len(probe['cases'])==15 and sum(len(c['observations']) for c in probe['cases'].values())==210
assert probe['summary']['all_visits_match'] and probe['summary']['all_work_not_reduced']
dest=p/'qualification/round-39-numeric-composite/development';dest.mkdir(parents=True,exist_ok=False)
archives={}
paths=[x for x in folder.iterdir() if x.is_file() and x.suffix in ('.py','.json','.log','.stdout','.stderr')]
paths += [x for attempt in sorted(folder.glob('attempt-*')) for x in attempt.rglob('*') if x.is_file()]
for path in sorted(paths):
 name=str(path.relative_to(folder));raw=path.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives[name]={'path':str(out.relative_to(p)),'sha256':hashlib.sha256(raw).hexdigest(),'compressed_sha256':b.digest(out)}
failures=b.read(folder/'development-attempts.json')
invariants=[
 'All30 Mech ports, inputs, C binaries/flags, F64 MINI dataset, limits, finite tolerances, split, objective and formal timing/cache boundaries are unchanged.',
 'The existing compiler-derived LibraryCallRoute selects a numeric tuple/record constructor from the actual sealed resident CompositePack factory. Existing private-buffer and scalar routes keep priority; scalar-only and nonnumeric aggregates are excluded.',
 'Reuse Core CompositeSnapshotConstructor, current schema/key/shape validation and the shared full original-source construction/publication/replay envelope. Preserve source visits and do not reduce original work/comparison bills.',
 'Every shape comes from current admitted children. No concrete input shape, owner, value or publication authority is cached; no MINI dimensions or program names are embedded in the compiler.',
 'All finite caps, cumulative work/replay credit, caller coexistence, byte/node reservations, aliases and atomic publication remain. Unsupported or denied attempts use the original selected call. Numeric arithmetic remains in the existing Cranelift kernels.',
 'Budget tests quote the independent ordinary Canonical-route source bill: denial below that source bill preserves the cold shared ledger and prior publication, while an unfunded native envelope may correctly choose the cheaper original bill. No ledger-reset or source-cost assertion is removed.',
 'Exactly one prospective v2 optimization15 probe uses seven fresh processes per actor, alternating accepted31/candidate order. All210 observations, failures and regressions remain; no retries/exclusions.',
 'The holdout is used only for the aggregate gate after exact source/driver freeze; no holdout profiling, implementation diagnosis or per-case tuning.'
]
out=dict(q);out.update(schema='mech.polybench.training-qualification.v1',label='round39-numeric-composite',invariants=invariants,
 profiling_basis={'receipts':['training-experiments/optimization-margin-profile.json','training-experiments/composite-pack-profile.json'],'scope':'Optimization15 only, prioritized by descending accepted Mech/C ratio.','targets':{'mvt':{'accepted_mech_over_c':44.96978436870602,'generic_pack_samples':100,'execution_samples':153},'bicg':{'accepted_mech_over_c':42.71453,'generic_pack_samples':89,'execution_samples':125}},'actual_path_check':'Untimed qualified-driver debugger census must observe one numeric composite callback and zero generic canonical calls in each case, with unchanged arithmetic prepare/finish counts and all160 C liveouts checked. This is path evidence, not a timing score.'},
 total_unique_selected_checks=q['tests'],focused_selected_checks=sum(q['focused_checks']['passed_tests']),development_attempts=failures,development_archives=archives,
 limitations='F64 MINI CPU scope; short-kernel profiles are coarse. The historically exposed holdout is an aggregate acceptance control. Training selection is not a formal Mech/C result or a promotion.',training_probe_summary=probe['summary'])
for suffix,value in [('training-qualification',out),('training-probe',probe),('route-census',census),('training-selection',{'schema':'mech.polybench.training-selection.v2','compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'accepted_round':31,'policy':probe['policy'],'result':probe['summary'],'selected':probe['summary']['selected'],'formal_evaluation_started':False})]:
 path=p/f'round-39-{suffix}.json';assert not path.exists();b.write(path,value)
print({'compiler_fingerprint':fp,'archives':len(archives),'checks':q['tests'],'probe':probe['summary'],'formal_observations':0},flush=True)
