import importlib.util,json,pathlib,re,subprocess
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
protocol,cases=b.protocol();q=b.read(folder/'qualification.json');assert b.compiler_fingerprint()==q['compiler_fingerprint'];assert b.digest(folder/'rectangle-driver')==q['driver_sha256']
objects=folder/'objects';objects.mkdir(exist_ok=False)
old=pathlib.Path('/private/tmp/mech-polybench-optimization/round-31/inverse-bitcasts/objects')
def functions(asm):
 r={};name=None
 for line in asm.splitlines():
  m=re.match(r'^[0-9a-f]+ <_(.+)>:',line)
  if m:name=m[1];r[name]={'coordinate_division_ops':0,'instructions':0}
  elif name and re.match(r'^\s*[0-9a-f]+:',line):
   r[name]['instructions']+=1
   r[name]['coordinate_division_ops']+=int(bool(re.search(r'\b(?:udiv|sdiv|umulh|smulh)\s',line)))
 return r
r={'scope':'Real checked Object export for optimization15 only; no timing observations or linked Object execution.','compiler_fingerprint':q['compiler_fingerprint'],'driver_sha256':q['driver_sha256'],'cases':{}}
for name in protocol['optimization']:
 inputs=folder/f'{name}-inputs.json';b.write(inputs,cases[name]['inputs']);obj=objects/f'{name}.o'
 result=subprocess.run([str(folder/'rectangle-driver'),str(b.FIXTURE/f'{name}.mec'),str(inputs),'0',f'emit-object={obj}'],text=True,capture_output=True,check=True,timeout=180)
 status=json.loads(result.stdout.strip().splitlines()[-1]);assert status['status']=='ok' and status['mode']=='emit-object'
 metadata=b.read(obj.with_suffix('.metadata.json'))
 asm=subprocess.run(['/Library/Developer/CommandLineTools/usr/bin/llvm-objdump','--disassemble','--no-show-raw-insn',str(obj)],text=True,capture_output=True,check=True).stdout
 disasm=obj.with_suffix('.disasm.txt');disasm.write_text(asm)
 row={'code_bytes':metadata['code_bytes'],'functions':functions(asm),'object_sha256':b.digest(obj),'metadata_sha256':b.digest(obj.with_suffix('.metadata.json')),'disassembly_sha256':b.digest(disasm),'object_executed':False}
 if (old/f'{name}.metadata.json').exists():
  before=b.read(old/f'{name}.metadata.json');row['accepted31_code_bytes']=before['code_bytes'];row['code_bytes_delta']=row['code_bytes']-before['code_bytes'];row['accepted31_functions']=functions((old/f'{name}.disasm.txt').read_text())
 r['cases'][name]=row;b.write(folder/'emission-census.json',r)
 print(name,'code_bytes',row['code_bytes'],'delta',row.get('code_bytes_delta'),flush=True)
gram=r['cases']['gramschmidt'];symbol='mech_canonical_program_entry_v1_numeric_5'
assert gram['functions'][symbol]['coordinate_division_ops']<gram['accepted31_functions'][symbol]['coordinate_division_ops'],gram
r['complete']=len(r['cases'])==15;r['profiled_rectangle_coordinate_division_ops']={'before':gram['accepted31_functions'][symbol]['coordinate_division_ops'],'after':gram['functions'][symbol]['coordinate_division_ops']};assert b.compiler_fingerprint()==q['compiler_fingerprint'];b.write(folder/'emission-census.json',r);print('Profiled rectangle coordinate divisions',r['profiled_rectangle_coordinate_division_ops'],flush=True)
