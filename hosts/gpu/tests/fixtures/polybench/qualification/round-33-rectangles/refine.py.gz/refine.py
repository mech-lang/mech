from pathlib import Path
p=Path('hosts/gpu/src/native_artifact/program/codegen/numeric_map.rs');s=p.read_text();needle='''        // Visit one complete source column before the next. Direct counters
''';at=s.index(needle);start=s.rfind('    let (source_at, rectangle_row, rectangle_loop)',0,at)
old='''    let (source_at, rectangle_row, rectangle_loop) = if let Some(rectangle) = &region.rectangle {
'''
new='''    let (source_at, rectangle_row, rectangle_loop) = if let Some(rectangle) = region.rectangle.as_ref().filter(|r| r.rows == 1) {
        let inner = b.ins().iconst(types::I64, rectangle.start as i64);
        b.def_var(words[&rectangle.inner_element], inner);
        (at, Some(zero), None)
    } else if let Some(rectangle) = &region.rectangle {
'''
assert old in s;s=s.replace(old,new);p.write_text(s)
p=Path('hosts/gpu/src/native_artifact/program/codegen/numeric_map_rectangle_tests.rs');s=p.read_text();needle='''    fn new(kind: &str, range: bool, failure: bool) -> Self {
''';assert needle in s;s=s.replace(needle,needle+'''        Self::rows(kind, range, failure, 2)
    }
    fn rows(kind: &str, range: bool, failure: bool, inner_rows: usize) -> Self {
''')
s=s.replace('i <- 1u64..=2u64', 'i <- 1u64..={inner_rows}u64').replace('assert_eq!(region.rectangle.as_ref().unwrap().rows, 2);', 'assert_eq!(region.rectangle.as_ref().unwrap().rows, inner_rows as u64);')
old='''                let mech_core::ValueData::U64(word) = constant.constant().data() else {
                    panic!("U64 source literal")
                };
                captures.insert(value, b.ins().iconst(types::I64, *word as i64));
''';new='''                let word = match constant.constant().data() {
                    mech_core::ValueData::U64(word) => *word,
                    mech_core::ValueData::Bool(word) => u64::from(*word),
                    other => panic!("unexpected source literal {other:?}"),
                };
                captures.insert(value, b.ins().iconst(types::I64, word as i64));
''';assert old in s;s=s.replace(old,new)
s=s.replace('let count = 2 * items.len();','let count = self.region.rectangle.as_ref().unwrap().rows as usize * items.len();')
start=s.index('        for range in [false, true] {',s.index('fn numeric_rectangular_cursors_keep_all_widths'))
end=s.index('\n}\n#[test]',start)
old=s[start:end];new=old.replace('        for range in [false, true] {','        for rows in [1, 2] {\n        for range in [false, true] {',1).replace('Kernel::new(kind, range, false)','Kernel::rows(kind, range, false, rows)').replace('2 * items.len() * width','rows * items.len() * width').replace('2 * items.len() as u64','rows as u64 * items.len() as u64').replace('for row in 0..2 {','for row in 0..rows {');new+='\n    }';s=s[:start]+new+s[end:];p.write_text(s)
