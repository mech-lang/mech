import importlib.util,json,pathlib,shutil,subprocess
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
protocol,cases=b.protocol();checkpoint=b.read(folder/'source-checkpoint.json');assert b.compiler_fingerprint()==checkpoint['compiler_fingerprint']
old=pathlib.Path('/private/tmp/mech-polybench-optimization/round-31/native-attribution')
for name in ['dump-jit-code.py','compare-code.py']:shutil.copy2(old/name,folder/name)
spec=importlib.util.spec_from_file_location('compare',folder/'compare-code.py');compare=importlib.util.module_from_spec(spec);spec.loader.exec_module(compare)
objects=folder/'objects';objects.mkdir(exist_ok=False)
r={'scope':'Actual accepted31 checked JIT executable-page snapshots compared to corresponding real checked Objects; no timing scores.','cases':{}}
for case in b.read(folder/'training-profile.json')['cases']:
 for suffix in ['.o','.metadata.json','.disasm.txt']:shutil.copy2(pathlib.Path('/private/tmp/mech-polybench-optimization/round-31/inverse-bitcasts/objects')/(case+suffix),objects/(case+suffix))
 live=folder/'live-code'/case;live.mkdir(parents=True,exist_ok=False)
 command=(old/f'{case}-dump.lldb').read_text().replace(str(old),str(folder));(folder/f'{case}-dump.lldb').write_text(command)
 argv=['xcrun','lldb','-x','-b','--source',str(folder/f'{case}-dump.lldb'),'--','/private/tmp/mech-polybench-optimization/round-31/inverse-bitcasts/bitcast-driver',str(b.FIXTURE/f'{case}.mec'),str(folder/f'{case}-inputs.json'),'0']
 process=subprocess.run(argv,capture_output=True,text=True,check=True,timeout=120);(folder/f'{case}-lldb.log').write_text(process.stdout+process.stderr)
 results=[json.loads(line) for line in process.stdout.splitlines() if line.startswith('{') and '"values"' in line];assert len(results)==1
 result=results[0];validation=b.validate(result['values'],cases[case]['expected']);assert result['report']==b.read(b.FIXTURE/'round-31-training-probe.json')['cases'][case]['actors']['bitcast']['execution_report']
 rows=compare.compare(folder,case);sites=[s for row in rows for s in row['sampled_hot_sites']];assert all(s['instruction_identical'] and s['surrounding_68_bytes_identical'] for s in sites)
 r['cases'][case]={'full_c_validation':validation,'checked_counters_identical':True,'functions':rows};b.write(folder/'jit-object-byte-verification.json',r)
 print(case,'actual native bytes verified at',len(sites),'sampled sites',flush=True)
assert b.compiler_fingerprint()==checkpoint['compiler_fingerprint']
