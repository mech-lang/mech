from pathlib import Path
root=Path.cwd()
def replace(text,old,new):
 assert text.count(old)==1,(old[:100],text.count(old))
 return text.replace(old,new)
p=root/'hosts/gpu/src/native_artifact/program/codegen/numeric_cell_prefix.rs';s=p.read_text()
s=replace(s,'    Read { array: usize, row: u32, column: u32 },','    Read { array: usize, row: u32, column: u32 },\n    LinearRead { array: usize, index: u32 },')
a=s.index('fn supported(');z=s.index('fn plain(',a)
s=s[:a]+'''fn selected_read(facts: &NativeProgramFacts<'_>, proof: &Proof, site: usize) -> Option<(u32, Step)> {
    use mech_engine::native_artifact::NativeCollectionPrimitive as Primitive;
    let (array, output, primitive, selectors, step) = match proof.action(site)? {
        Operation::CellRead { array, row, column, output } => (
            *array, *output, Primitive::MatrixCellAccess, vec![*row, *column],
            Step::Read { array: *array, row: *row, column: *column },
        ),
        Operation::Read { array, index, output } => (
            *array, *output, Primitive::MatrixScalarAccess, vec![*index],
            Step::LinearRead { array: *array, index: *index },
        ),
        _ => return None,
    };
    let Action::LibraryCall { template, operands, output: selected } =
        facts.plan().blocks()[site].action() else { return None; };
    (proof.arrays[array].width == 8
        && facts.plan().values()[output as usize].scalar_kind() == Some(Kind::F64)
        && template.primitive() == primitive
        && selected.get() == output
        && operands.len() == selectors.len() + 1
        && operands[1..].iter().map(|v| v.get()).eq(selectors)
        && template.output().body()
            == &mech_core::SchemaBody::FloatingPoint(mech_core::FloatWidth::W64))
        .then_some((output, step))
}
'''+s[z:]
s=replace(s,'return supported(facts, proof, site);','return selected_read(facts, proof, site).is_some();')
a=s.index('            Some(Operation::CellRead {',s.index('fn find('));z=s.index('            None => match',a)
s=s[:a]+'''            Some(_) => {
                let read = selected_read(facts, proof, at)?;
                reads.push(at);
                Some(read)
            }
'''+s[z:]
s=replace(s,'            _ => return None,\n        };\n        if let Some((output, step))', '        };\n        if let Some((output, step))')
s=replace(s,'reads.len() < 2 || reads.len() > 32','reads.is_empty() || reads.len() > 32')
s=replace(s,'            Step::Read { row, column, .. } => vec![*row, *column],','            Step::Read { row, column, .. } => vec![*row, *column],\n            Step::LinearRead { index, .. } => vec![*index],')
s=replace(s,'&& matches!(proof.action(site), Some(Operation::CellRead { .. }))','&& selected_read(facts, proof, site).is_some()')
s=replace(s,'/// Evaluate only a proved prefix. Inputs are current raw source words, views\n/// are the already admitted current numeric banks (pointer, rows, columns).','''#[derive(Clone, Copy)]
struct View {
    pointer: Value,
    rows: Value,
    columns: Value,
    // Loaded only for actual source linear indexing. Cell-only regions retain
    // their existing current geometry and emit no extra shadow-word read.
    length: Option<Value>,
}
/// Evaluate only a proved prefix. Inputs are current raw source words; views
/// contain the already admitted current numeric bank and source geometry.''')
s=replace(s,'views: &BTreeMap<usize, [Value; 3]>,','views: &BTreeMap<usize, View>,')
s=replace(s,'            let [_, rows, columns] = views[array];','            let View { rows, columns, .. } = views[array];')
s=replace(s,'    }\n    let admitted = b.create_block();','''        if let Step::LinearRead { array, index } = step {
            let index = integers[index];
            if checked.insert((*array, 2, index)) {
                let ordinal = b.ins().iadd_imm(index, -1);
                let good = b.ins().icmp(
                    IntCC::UnsignedLessThan, ordinal,
                    views[array].length.expect("source linear read retains current bank length"),
                );
                valid = b.ins().band(valid, good);
            }
        }
    }
    let admitted = b.create_block();''')
s=replace(s,'                let [pointer, _, columns] = views[array];','                let View { pointer, columns, .. } = views[array];')
s=replace(s,'            Step::Primitive(op, args) => {\n                let args = args.iter().map(|v| floats[v]).collect::<Vec<_>>();','''            Step::LinearRead { array, index } => {
                let ordinal = b.ins().iadd_imm(integers[index], -1);
                let bytes = b.ins().ishl_imm(ordinal, 3);
                let address = b.ins().iadd(views[array].pointer, bytes);
                b.ins().load(
                    types::F64,
                    super::numeric_words::guarded_load_flags(options),
                    address,
                    0,
                )
            }
            Step::Primitive(op, args) => {
                let args = args.iter().map(|v| floats[v]).collect::<Vec<_>>();''')
s=replace(s,'            Step::Read { array, .. } => Some(*array),','            Step::Read { array, .. } | Step::LinearRead { array, .. } => Some(*array),')
s=replace(s,'                [\n                    words.read(b, at),\n                    words.read(b, at + 2),\n                    words.read(b, at + 3),\n                ],','''                View {
                    pointer: words.read(b, at),
                    rows: words.read(b, at + 2),
                    columns: words.read(b, at + 3),
                    length: prefix.steps.iter().any(|(_, step)|
                        matches!(step, Step::LinearRead { array: selected, .. } if *selected == array))
                        .then(|| words.read(b, at + 1)),
                },''')
p.write_text(s)
p=root/'hosts/gpu/src/native_artifact/program/image/identity.rs';s=p.read_text();s=replace(s,'= 437;','= 439;');p.write_text(s)
p=root/'hosts/gpu/src/native_artifact/program/codegen/numeric_cell_prefix_tests.rs';s=p.read_text()
s=replace(s,'        let views = BTreeMap::from([(0, [pointer, rows, columns])]);','''        let length = prefix.steps.iter().any(|(_, step)| matches!(step, Step::LinearRead { .. }))
            .then(|| b.ins().imul(rows, columns));
        let views = BTreeMap::from([(0, View { pointer, rows, columns, length })]);''')
s+='''
#[test]
fn cell_prefix_direct_single_linear_read_checks_full_index_before_load_and_preserves_bits() {
    let mut prefix = recipe(false);
    prefix.read_sites = vec![3];
    prefix.kinds.remove(&21);
    prefix.steps[3] = (20, Step::LinearRead { array: 0, index: 11 });
    prefix.steps.remove(4);
    prefix.steps[4] = (30, Step::Primitive(Op::F64Mul, vec![20, 4]));
    prefix.steps[5] = (31, Step::Primitive(Op::F64Add, vec![30, 20]));
    let (_module, kernel) = compile(prefix);
    for bits in [0, (-0.0f64).to_bits(), 1, 1.25f64.to_bits(), f64::MAX.to_bits(),
        f64::INFINITY.to_bits(), 0x7ff8_1234_5678_9abc, 0x7ff0_1234_5678_9abc] {
        let data = [bits; 6];
        for (rows, columns) in [(0, 3), (2, 3), (3, 2), (1, 6)] {
            for base in [0, 1, 2, 5, u64::MAX] {
                for offset in [0, 1, 6, u64::MAX] {
                    for scale in [0, 1, u64::MAX] {
                        let index = base.checked_mul(scale).and_then(|v| v.checked_add(offset));
                        let admitted = index.is_some_and(|v| v >= 1 && v <= rows * columns)
                            && 1u64.checked_add(offset).is_some();
                        let value = f64::from_bits(bits);
                        let expected = value * 9.0 + value;
                        let frame = [if admitted { data.as_ptr() as u64 } else { 0 },
                            rows, columns, base, 1, offset, 9.0f64.to_bits(), scale];
                        let mut out = [0xface_f00d_dead_beef; 3];
                        // SAFETY: complete successful views contain six cells. Invalid
                        // checked indices use a null bank and must refuse before loading.
                        let status = unsafe { kernel(frame.as_ptr(), out.as_mut_ptr().add(1)) };
                        let success = admitted && expected.is_finite();
                        assert_eq!(status, u64::from(!success));
                        assert_eq!(out[0], 0xface_f00d_dead_beef);
                        assert_eq!(out[2], out[0]);
                        assert_eq!(out[1], if success { expected.to_bits() } else { out[0] });
                    }
                }
            }
        }
    }
}
''';p.write_text(s)
p=root/'hosts/gpu/src/native_artifact/program/runtime/composition_tests/cell_prefix.rs';s=p.read_text()
s=replace(s,'        "(a[r,c] + a[r,c + offset]) / gain",','        "(a[r,c] + a[r,c + offset]) / gain",\n        "a[c + offset] * gain + gain",\n        "a[r,c] * gain + gain",')
s=replace(s,'    for artifact in artifacts(&source("(a[r,c] + a[r,c + offset]) / gain", [3, 4])) {','    for expression in ["(a[r,c] + a[r,c + offset]) / gain", "a[c + offset] * gain + gain"] {\n    for artifact in artifacts(&source(expression, [3, 4])) {')
s=replace(s,'}\n#[test]\nfn cell_prefix_proof_tracks', '    }\n}\n#[test]\nfn cell_prefix_proof_tracks')
s=replace(s,'    for source in cases {','    for (index, source) in cases.into_iter().enumerate() {')
a=s.index('            assert!(\n                metadata',s.index('fn cell_prefix_source_proof_declines_integer_reads_writes_and_branch_crossings'))
z=s.index('\n        }\n    }\n}',a)
s=s[:a]+'''            let prefixes = metadata.closed_tails.regions.iter()
                .filter_map(|r| r.numeric.as_ref())
                .flat_map(|p| numeric_cell_prefix::derive(&metadata.plan.facts(), p))
                .collect::<Vec<_>>();
            if index == 0 {
                assert!(prefixes.is_empty(), "integer reads cannot enter a floating expression");
            }
            for prefix in prefixes {
                // A profitable single-read suffix is valid after a write or
                // branch; neither source boundary may belong to the prefix.
                assert_eq!(prefix.read_sites.len(), 1);
                for site in prefix.sites {
                    use mech_engine::native_artifact::{NativeCollectionPrimitive as P,
                        NativeIterationAction as A, NativeIterationTerminator as T,
                        NativeMatchTerminator as B};
                    let block = &metadata.plan.blocks()[site];
                    assert!(matches!(block.terminator(), T::Scalar(B::Jump(_))));
                    assert!(match block.action() {
                        A::Scalar(_) => true,
                        A::LibraryCall { template, .. } => matches!(template.primitive(),
                            P::MatrixCellAccess | P::MatrixScalarAccess),
                        _ => false,
                    }, "no prefix contains the intervening source write or branch");
                }
            }'''+s[z:]
s=replace(s,'    for text in [text, partial] {','    let bare_linear = source("a[c + offset]", [2, 5]);\n    for text in [text, partial, bare_linear] {')
s+='''
#[test]
fn cell_prefix_source_proof_admits_single_linear_recurrences_without_crossing_writes() {
    for artifact in artifacts(include_str!("../../../../../tests/fixtures/polybench/deriche.mec")) {
        let catalog = mech_stdlib::source_catalog();
        let jit = JitProgramArtifact::compile(&artifact, &catalog).unwrap();
        let metadata = jit.descriptor().metadata();
        let prefixes = metadata.closed_tails.regions.iter()
            .filter_map(|r| r.numeric.as_ref())
            .flat_map(|p| numeric_cell_prefix::derive(&metadata.plan.facts(), p))
            .collect::<Vec<_>>();
        assert_eq!(prefixes.len(), 2, "both source causal filter orientations");
        for prefix in prefixes {
            assert_eq!(prefix.read_sites.len(), 1);
            assert_eq!(prefix.exports.len(), 1, "only the ordered recurrence result escapes");
            assert!(prefix.sites.len() >= 8);
            assert!(!prefix.sites.contains(&(prefix.next as usize)));
        }
    }
}
''';p.write_text(s)
