from pathlib import Path
import subprocess,sys,json
f=Path(__file__).resolve().parent
for name in ['prepare-qualification-manifest.py','emission-census.py','untimed-counter-gate.py']:
 print('Starting',name,flush=True);subprocess.run([sys.executable,str(f/name)],check=True)
r=json.loads((f/'emission-census.json').read_text());proto=json.loads((f/'prototype-result.json').read_text());assert r['passed'] and proto['passed']
physical={'compiler_fingerprint':r['compiler_fingerprint'],'genuine_object_matches_prototype':True,'seidel_native_code_stack_exact_round62':r['seidel_lowering_retained'],'matrix_native_code_exact_round62':r['matrix_lowering_retained'],'host_preflight_exact_round62':r['host_preflight_retained_round62'],'new_linear_recurrence_prefixes':proto['cases']['deriche']['cell_expression_prefixes'],'case_code_stack':{n:{a:{k:v[k]for k in ['code_bytes','reported_native_stack_bytes','static_instruction_count']}for a,v in c['actors'].items()}for n,c in r['cases'].items()},'no_new_fma':r['no_new_fma'],'performance_observations':0,'limit':'Static totals include cold lexical replay, not hardware retirement or latency. Original source arithmetic/counters remain.'}
(f/'physical-transformation.json').write_text(json.dumps(physical,indent=2)+'\n')
subprocess.run([sys.executable,str(f/'preserve-qualification.py')],check=True)
