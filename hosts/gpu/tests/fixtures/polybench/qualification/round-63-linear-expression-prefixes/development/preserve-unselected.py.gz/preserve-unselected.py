"""Retain the failed single probe and restore the exact accepted compiler."""
import gzip,hashlib,importlib.util,json,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent;spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;plan=b.read(folder/'plan.json');q=b.read(folder/'qualification.json');r=b.read(folder/'training-probe.json');development=b.read(p/'training-experiments/linear-expression-prefixes-development.json');fp=b.compiler_fingerprint();accepted=b.read(p/'round-59-frozen.json');ledger=b.read(p/'performance-acceptance.json')
assert r['complete'] and not r['summary']['selected'] and (r['summary']['geomean_raw_speedup_vs_accepted59']<=1 or r['summary']['active_target_raw_speedup']<=1)
assert b.read(folder/'training-probe.exit.json')['exit_code']==0 and sum(len(c['observations'])for c in r['cases'].values())==210
assert fp==r['compiler_fingerprint']==q['compiler_fingerprint']==development['compiler_fingerprint']
assert b.digest(q['driver'])==q['driver_sha256']==r['driver_sha256'] and all(b.digest(root/name)==digest for name,digest in q['source_sha256'].items())
assert all(c['all_counters_match']for c in r['cases'].values()) and b.command(['git','status','--porcelain'])==''
assert len(b.read(p/'performance-history.json')['entries'])==63 and ledger['accepted_history_index']==59
assert not(p/'round-63-frozen.json').exists()
interpretation={'scope':'Optimization15 only; one complete210-observation probe, no new formal score/holdout observations.','result':'Not selected solely because the preregistered raw optimization aggregate and active Seidel target do not both exceed1. Every observation/regression and exact source counter retained.','summary':r['summary'],'active_target_medians':r['cases']['seidel-2d']['actors'],'static_seidel':b.read(folder/'emission-census.json')['cases']['seidel-2d'],'physical_transformation':b.read(folder/'physical-transformation.json'),'next_source_investigation':'No follow-on candidate selected here. Preserve actual source/telemetry/observations and restore accepted source under the existing optimization-only gates.','mechanism':'Checked source-closed single-read F64 expressions use actual selected linear/cell recipes, current bounds and the shared column-major source address conversion, preserving strict arithmetic, lexical replay and all source counters. Exact round62 Seidel lowering and matrix preflight remain.','diagnostic_limit':'Static SSA/native loop work-removal evidence and exact Seidel code preservation are not latency claims. Every observation and actual code/stack change remains, with no noise explanation, exclusion or fingerprint retry. Accepted59 restores solely under the existing optimization/target gates.'}
b.write(folder/'unselected-interpretation.json',interpretation)
dest=p/'qualification/round-85-linear-expression-prefixes-unselected';dest.mkdir(parents=True,exist_ok=False);archives={'development/'+name:rec for name,rec in development['archives'].items()};new=0
for source in sorted(folder.rglob('*')):
 if not source.is_file() or '__pycache__'in source.parts or source.name.endswith('-driver'):continue
 name=str(source.relative_to(folder));old=development['archives'].get(name)
 if old and old['sha256']==b.digest(source):continue
 raw=source.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives['probe/'+name]={'path':str(out.relative_to(p)),'sha256':b.digest(source),'compressed_sha256':b.digest(out)};new+=1
for rec in archives.values():
 data=(p/rec['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==rec['compressed_sha256'] and hashlib.sha256(gzip.decompress(data)).hexdigest()==rec['sha256']
subprocess.run(['git','restore','--source='+plan['source_parent'],'--worktree','--',*plan['source_paths']],check=True)
subprocess.run(['git','add','-A','--',*plan['source_paths']],check=True)
restored=b.compiler_fingerprint();assert restored==accepted['compiler_fingerprint']
receipt={'schema':'mech.polybench.compiler-training-experiment.v3','created_at':b.utc(),'name':plan['name'],'complete':True,'selected':False,'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'qualified_source_commit':b.read(folder/'qualification-source-commit.json')['source_commit'],'effective_plan':plan,'qualification':q,'probe':r,'interpretation':interpretation,'development_receipt':'training-experiments/linear-expression-prefixes-development.json','archives':archives,'performance_observations':210,'formal_observations':0,'holdout_observations':0,'formal_history_entries_unchanged':63,'accepted_history_index_unchanged':59,'restored_compiler_fingerprint':restored,'accepted_scores_unchanged':plan['accepted_scores'],'no_retry_or_exclusion':True}
b.write(p/'training-experiments/linear-expression-prefixes-probe.json',receipt)
b.write(p/'training-experiments/linear-expression-prefixes-selection.json',{'schema':'mech.polybench.training-selection.v3','created_at':b.utc(),'selected':False,'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'observations':210,'summary':r['summary'],'gate_passed':True,'performance_score':'Raw equal-weight optimization15 GM accepted59/candidate medians. One prospective fresh-process probe; all observations retained.','decision':'Not selected because raw optimization aggregate and active Seidel target did not both improve. Exact accepted59 source restored. No formal run or holdout observation.','restored_compiler_fingerprint':restored,'accepted_round':59,'history_entries':63})
state=b.read(p/'optimization-target-state.json');assert state['accepted_history_index']==59 and state['active_target']['case']=='seidel-2d'
state.update(latest_experiment='training-experiments/linear-expression-prefixes-probe.json',latest_experiment_selected=False,latest_experiment_promoted=False);b.write(p/'optimization-target-state.json',state)
with(p/'README.txt').open('a')as out:
 out.write('\nChecked linear expression prefixes: unselected probe\n\n')
 out.write(f'Qualified checked single-read linear/cell expression fusion retained exact round62 Seidel machine code/stack and matrix preflight, source arithmetic/order and all counters. Full{q["tests"]} broad checks,9 focused groups,both features,all30/restored and17002 finite O C outputs passed. Its sole210-observation O-only probe returned{r["summary"]["geomean_raw_speedup_vs_accepted59"]:.16f}x raw speedup and Seidel{r["summary"]["active_target_raw_speedup"]:.16f}x raw speedup; not selected under the preregistered gate. All sources/failures/samples preserved. Accepted59 source restored; no new formal or holdout observations.\n\n')
 out.write('[Probe and restoration](training-experiments/linear-expression-prefixes-probe.json)\n')
assert len(b.read(p/'performance-history.json')['entries'])==63 and b.read(p/'performance-acceptance.json')['accepted_history_index']==59
subprocess.run(['python3',str(root/'scripts/record-polybench-acceptance.py'),'--check'],check=True,capture_output=True)
subprocess.run(['git','diff','--check'],check=True);subprocess.run(['git','add','--',str(p.relative_to(root))],check=True)
subprocess.run(['git','-c','gc.auto=0','commit','-q','-m','Retain checked linear expression probe and restore accepted compiler'],check=True)
assert b.command(['git','status','--porcelain'])=='' and b.compiler_fingerprint()==restored
head=b.command(['git','rev-parse','HEAD']);b.write(folder/'restoration.json',{'head':head,'candidate_fingerprint':fp,'restored_compiler_fingerprint':restored,'accepted_round':59,'observations':210,'history_entries':63,'archives_verified':len(archives),'new_archives':new,'clean':True})
state=b.read(folder/'current-work.json');state.update(stage='Single optimization probe not selected; exact accepted59 restored and evidence committed, push pending',complete=True,accepted_round=59,compiler_fingerprint=restored,candidate_fingerprint=fp,performance_observations=210,formal_observations=0,holdout_observations=0,history_entries=63,live_exec_session=None,source_commit=head);b.write(folder/'current-work.json',state)
print(json.dumps({'head':head,'selected':False,'raw_probe_speedup':r['summary']['geomean_raw_speedup_vs_accepted59'],'accepted_round':59,'restored_compiler_fingerprint':restored,'accepted_scores':plan['accepted_scores'],'archives_verified':len(archives),'new_archives':new,'clean':True}),flush=True)
