from pathlib import Path
import importlib.util,json,os,shutil,subprocess,time,sys
from importlib.machinery import SourceFileLoader
root=Path.cwd();f=Path(__file__).resolve().parent
st=SourceFileLoader('st',str(f/'static-tools.py')).load_module()
s=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(s);s.loader.exec_module(b)
plan=b.read(f/'plan.json');focus=b.read(f/'focused-result.json');fp=b.compiler_fingerprint()
assert focus['exit_code']==0 and focus['passed_tests']==[9] and fp==focus['compiler_fingerprint'] and focus['source_unchanged']
p=f/'prototype';p.mkdir(exist_ok=False)
for name in plan['source_paths']:
 out=p/'source'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((root/name).read_bytes())
env=os.environ.copy();target=Path('/private/tmp/mech-polybench-pr1000-target');env['CARGO_TARGET_DIR']=str(target)
argv=['cargo','build','--release','-p','mech-gpu','--no-default-features','--features','canonical-native-program','--example','polybench_qualification'];started=time.monotonic()
with(p/'build.log').open('x')as log:r=subprocess.run(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
b.write(p/'build.json',{'command':argv,'exit_code':r.returncode,'compiler_fingerprint':fp,'source_unchanged':b.compiler_fingerprint()==fp,'wall_seconds':time.monotonic()-started,'performance_observations':0})
assert r.returncode==0 and b.compiler_fingerprint()==fp
binary=f/'linear-expression-prefixes-prototype-driver';shutil.copy2(target/'release/examples/polybench_qualification',binary)
_,cases=b.protocol();old=b.read(b.FIXTURE/'round-62-static-telemetry.json');rows={}
for name in ['seidel-2d','deriche','nussinov','cholesky','3mm','mvt','bicg']:
 config=p/f'{name}-inputs.json';b.write(config,cases[name]['inputs']);obj=p/f'{name}.o';argv=[str(binary),str(b.FIXTURE/f'{name}.mec'),str(config),'0','emit-object='+str(obj)]
 with(p/f'{name}.stdout').open('x')as out,(p/f'{name}.stderr').open('x')as err:r=subprocess.run(argv,cwd=root,stdout=out,stderr=err)
 assert r.returncode==0,(p/f'{name}.stderr').read_text()
 status=json.loads((p/f'{name}.stdout').read_text().strip().splitlines()[-1]);assert status['status']=='ok' and status['mode']=='emit-object'
 asm=subprocess.check_output(['/Library/Developer/CommandLineTools/usr/bin/llvm-objdump','--disassemble','--no-show-raw-insn',str(obj)],text=True);(p/f'{name}.disasm.txt').write_text(asm)
 md=b.read(obj.with_suffix('.metadata.json'));fm=st.functions(asm);prev=old['cases'][name]['actors']['candidate']
 rows[name]={'code_bytes':md['code_bytes'],'reported_native_stack_bytes':md['stack_bytes'],'functions':fm,'object_sha256':b.digest(obj),'cell_expression_prefixes':st.records(md,'cell_expression_prefixes'),'native_functions_match_round62':st.matches(prev['functions'],fm),'object_executed':False}
 print(name,'code',prev['code_bytes'],'->',md['code_bytes'],'stack',prev['reported_native_stack_bytes'],'->',md['stack_bytes'],'prefixes',rows[name]['cell_expression_prefixes'],flush=True)
s=rows['seidel-2d'];n=rows['nussinov'];old_s=old['cases']['seidel-2d']['actors']['candidate']
retained=s['native_functions_match_round62'] and s['code_bytes']==old_s['code_bytes'] and s['reported_native_stack_bytes']==old_s['reported_native_stack_bytes']
matrix_same=all(rows[name]['native_functions_match_round62'] for name in ['3mm','mvt','bicg'])
source=Path('/private/tmp/mech-polybench-optimization/round-82/single-pass-matrix-preflight/qualified-source')
runtime='hosts/gpu/src/native_artifact/program/runtime/invocation/numeric_product_epilogues.rs'
host_same=(root/runtime).read_bytes()==(source/runtime).read_bytes()
dot='hosts/gpu/src/native_artifact/program/codegen/numeric_dot_core.rs'
# The inherited matrix preflight is byte-identical; no dot source was touched.
changed=b.command(['git','diff','--name-only']).splitlines();dot_same=not any('dot_core' in name for name in changed)
linear=rows['deriche']['cell_expression_prefixes'];admitted=len(linear)==2 and all(row[2:]==[1,1]for row in linear)
r={'schema':'mech.polybench.source-frozen-static-prototype.v1','compiler_fingerprint':fp,'driver_sha256':b.digest(binary),'cases':rows,'seidel_lowering_retained':retained,'matrix_lowering_retained':matrix_same,'unproductive_prefixes_absent':[104,109,2,2] in n['cell_expression_prefixes'] and [49,58,2,2] not in n['cell_expression_prefixes'],'host_preflight_reduced':host_same,'host_preflight_retained_round62':host_same,'original_dot_core_retained':dot_same,'linear_recurrence_prefixes_emitted':admitted,'source_unchanged':b.compiler_fingerprint()==fp,'performance_observations':0,'interpretation':'Genuine Deriche Objects contain two source-proved one-read ordered recurrence prefixes. Their actual emitter has one complete admission branch and one aggregate escaping-result guard; lexical checked replay remains. Existing round62 Seidel and matrix lowering/host preflight retained. Static totals include cold replay and do not forecast latency.'}
r['passed']=all(r[k]for k in ['seidel_lowering_retained','matrix_lowering_retained','unproductive_prefixes_absent','host_preflight_retained_round62','original_dot_core_retained','linear_recurrence_prefixes_emitted','source_unchanged'])
b.write(f/'prototype-result.json',r);b.write(p/'result.json',r);print(json.dumps({k:v for k,v in r.items()if k!='cases'}),flush=True)
raise SystemExit(0 if r['passed'] else 1)
