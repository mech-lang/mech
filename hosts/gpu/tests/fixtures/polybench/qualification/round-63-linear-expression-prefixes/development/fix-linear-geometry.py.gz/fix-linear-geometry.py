from pathlib import Path
root=Path.cwd()
def replace(text,a,b):
 assert text.count(a)==1,(a[:80],text.count(a));return text.replace(a,b)
p=root/'hosts/gpu/src/native_artifact/program/codegen/numeric_cell_prefix.rs';s=p.read_text()
s=replace(s,'LinearRead { array: usize, index: u32 },','LinearRead { array: usize, index: u32, schema: mech_core::SchemaBody },')
s=replace(s,'        Operation::Read {\n            array,\n            index,\n            output,\n        } => (', '        Operation::Read {\n            array,\n            index,\n            output,\n        } => {\n            let Action::LibraryCall { template: witness, .. } = facts.plan().blocks()[proof.arrays[*array].witness].action() else { return None; };\n            (')
s=replace(s,'                index: *index,\n            },\n        ),','                index: *index,\n                schema: witness.inputs().first()?.body().clone(),\n            },\n        )},')
s=s.replace('Step::LinearRead { array, index }','Step::LinearRead { array, index, .. }')
s=replace(s,'            Step::LinearRead { array, index, .. } => {\n                let ordinal = b.ins().iadd_imm(integers[index], -1);\n                let bytes = b.ins().ishl_imm(ordinal, 3);', """            Step::LinearRead { array, index, schema } => {
                let ordinal = b.ins().iadd_imm(integers[index], -1);
                let physical = super::numeric_words::linear_ordinal(
                    b, ordinal, views[array].rows, views[array].columns, schema,
                );
                let bytes = b.ins().ishl_imm(physical, 3);""")
p.write_text(s)
p=root/'hosts/gpu/src/native_artifact/program/codegen/numeric_cell_prefix_tests.rs';s=p.read_text()
s=replace(s,'assert_eq!(ctx.func.layout.blocks().flat_map', 'let expected_branches = if prefix.steps.iter().any(|(_, s)| matches!(s, Step::LinearRead { .. })) { 3 } else { 2 };\n    assert_eq!(ctx.func.layout.blocks().flat_map')
s=replace(s,'.count(),2,"one complete read admission and one escaping result guard");','.count(),expected_branches,"complete read admission/result guards plus general linear address conversion");')
s=replace(s,'            index: 11,\n        },','            index: 11,\n            schema: mech_core::SchemaBody::Matrix { element: Box::new(mech_core::SchemaBody::FloatingPoint(mech_core::FloatWidth::W64)), dimensions: vec![mech_core::DimensionExpr::Constant(2), mech_core::DimensionExpr::Constant(3)] },\n        },')
s=replace(s,'        let data = [bits; 6];','        let data = if bits == 0 { [0.0f64, 1.25, -4.0, 8.5, 0.125, -0.0].map(f64::to_bits) } else { [bits; 6] };')
s=replace(s,'                        let value = f64::from_bits(bits);','                        let value = if admitted {\n                            let ordinal = index.unwrap() - 1;\n                            let physical = (ordinal % rows) * columns + ordinal / rows;\n                            f64::from_bits(data[physical as usize])\n                        } else { 0.0 };')
p.write_text(s)
