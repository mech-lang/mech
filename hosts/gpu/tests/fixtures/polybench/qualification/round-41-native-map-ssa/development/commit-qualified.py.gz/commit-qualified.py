"""Commit and push the exact qualified candidate and full training evidence."""
import importlib.util,json,pathlib,subprocess
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;q=b.read(p/'round-41-training-qualification.json');selection=b.read(p/'round-41-training-selection.json');census=b.read(p/'round-41-emission-census.json');probe=b.read(p/'round-41-training-probe.json')
assert q['complete'] and census['complete'] and census['prospective_gate_passed'] and probe['complete']
assert b.compiler_fingerprint()==q['compiler_fingerprint']==selection['compiler_fingerprint']==census['compiler_fingerprint']==probe['compiler_fingerprint']
assert all(b.digest(root/path)==sha for path,sha in q['source_sha256'].items())
assert b.digest(folder/'ssa-map-driver')==q['driver_sha256']
assert b.command(['git','branch','--show-current'])=='codex/polybench-native-matrices'
assert b.command(['git','rev-parse','HEAD'])==q['source_parent']
subprocess.run(['git','diff','--check'],check=True)
subprocess.run(['git','add','--',*q['source_sha256'],str(p.relative_to(root))],check=True)
result=subprocess.run(['git','commit','-m','Compose checked numeric maps directly with native SSA values'],capture_output=True,text=True)
(folder/'source-commit.log').write_text(result.stdout+result.stderr);assert result.returncode==0,result.stderr
head=b.command(['git','rev-parse','HEAD']);assert b.command(['git','status','--porcelain'])=='' and b.compiler_fingerprint()==q['compiler_fingerprint']
branch='refs/heads/codex/polybench-native-matrices';remote=b.command(['git','ls-remote','origin',branch]).split()[0]
assert remote==q['source_parent'];subprocess.run(['git','merge-base','--is-ancestor',remote,head],check=True)
subprocess.run(['git','-c','http.version=HTTP/1.1','-c','http.postBuffer=52428800','push','origin',head+':'+branch],check=True)
assert b.command(['git','ls-remote','origin',branch]).split()[0]==head
b.write(folder/'experiment-source-commit.json',{'source_commit':head,'compiler_fingerprint':q['compiler_fingerprint'],'driver_sha256':q['driver_sha256'],'clean':True,'pushed':True,'selected':selection['selected'],'formal_observations':0})
state=b.read(folder/'current-work.json');state.update(stage='Qualified candidate source/training committed and pushed; formal gate pending' if selection['selected'] else 'Training rejected; source/evidence committed and pushed, exact accepted31 restoration pending',source_commit=head,source_committed=True,source_pushed=True,live_exec_session=None);b.write(folder/'current-work.json',state)
print(json.dumps({'source_commit':head,'pushed':True,'clean':True,'selected':selection['selected'],'formal_observations':0}),flush=True)
