"""Apply the preregistered native SSA Object gate without timing or execution."""
import hashlib,importlib.util,json,pathlib,re,subprocess
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
q=b.read(folder/'qualification.json');assert q['complete'] and b.compiler_fingerprint()==q['compiler_fingerprint'];driver=folder/'ssa-map-driver';assert b.digest(driver)==q['driver_sha256']
plan=b.read(folder/'plan.json');protocol,cases=b.protocol();objects=folder/'execution-objects';objects.mkdir(exist_ok=False);old=pathlib.Path('/private/tmp/mech-polybench-optimization/round-31/inverse-bitcasts/objects')
def instructions(asm):
 functions={};name=None
 for line in asm.splitlines():
  m=re.match(r'^[0-9a-f]+ <_(.+)>:',line)
  if m:name=m[1];functions[name]=[]
  elif name and re.match(r'^\s*[0-9a-f]+:',line):functions[name].append(line)
 return functions
def stats(lines):
 return {'instructions':len(lines),'sha256':hashlib.sha256('\n'.join(lines).encode()).hexdigest(),'stack_memory_instructions':sum(bool(re.search(r'\b(?:ldr|str|ldp|stp|ldur|stur)\s+.*\[sp(?:,|\])',line)) for line in lines),'fma':sum(bool(re.search(r'\b(?:fmadd|fmsub|fnmadd|fnmsub|fmla|fmls)\s+',line)) for line in lines)}
r={'schema':'mech.polybench.training-emission-census.v1','scope':'Optimization15 actual checked Objects, never linked or executed. Static counts are not dynamic costs or timings. Apply the unchanged prospective native SSA gate.','compiler_fingerprint':q['compiler_fingerprint'],'driver_sha256':q['driver_sha256'],'plan_sha256':b.digest(folder/'plan.json'),'cases':{},'complete':False,'new_performance_observations':0}
for name in protocol['optimization']:
 config=folder/f'{name}-inputs.json';b.write(config,cases[name]['inputs']);obj=objects/f'{name}.o'
 process=subprocess.run([str(driver),str(b.FIXTURE/f'{name}.mec'),str(config),'0','emit-object='+str(obj)],capture_output=True,text=True,check=True,timeout=180)
 result=json.loads(process.stdout.strip().splitlines()[-1]);assert result['status']=='ok' and result['mode']=='emit-object'
 metadata=b.read(obj.with_suffix('.metadata.json'));assert metadata['typed_ir_version']==406 and metadata['work_policy_version']==156 and metadata['abi_version']==47
 asm=subprocess.check_output(['/Library/Developer/CommandLineTools/usr/bin/llvm-objdump','--disassemble','--no-show-raw-insn',str(obj)],text=True);obj.with_suffix('.disasm.txt').write_text(asm)
 current=instructions(asm);before=instructions((old/f'{name}.disasm.txt').read_text());r['cases'][name]={'code_bytes':metadata['code_bytes'],'stack_bytes':metadata['stack_bytes'],'object_sha256':b.digest(obj),'metadata_sha256':b.digest(obj.with_suffix('.metadata.json')),'disassembly_sha256':b.digest(obj.with_suffix('.disasm.txt')),'functions':{k:stats(v) for k,v in current.items()},'accepted31_functions':{k:stats(v) for k,v in before.items()},'object_executed':False}
 b.write(folder/'execution-emission-census.json',r);print(name,'exported',flush=True)
gate=plan['prospective_emission_gate'];target=gate['target'];g=r['cases']['gramschmidt'];after=g['functions'][target];before=g['accepted31_functions'][target]
assert after['sha256']!=before['sha256']
assert before['instructions']==gate['native_instructions_strictly_below'] and before['stack_memory_instructions']==gate['stack_memory_instructions_strictly_below']
assert g['stack_bytes']<gate['max_stack_bytes_strictly_below'], 'The actual native stack must shrink before timing.'
assert after['instructions']<gate['native_instructions_strictly_below'], 'The profiled native function must shrink before timing.'
assert after['stack_memory_instructions']<gate['stack_memory_instructions_strictly_below'], 'The profiled function must shed stack memory operations before timing.'
assert all(sum(f['fma'] for f in row['functions'].values())==0 for row in r['cases'].values())
r['changed_cases']=[name for name,row in r['cases'].items() if row['functions']!=row['accepted31_functions']];r['complete']=len(r['cases'])==15;r['prospective_gate_passed']=True
assert b.compiler_fingerprint()==q['compiler_fingerprint'];b.write(folder/'execution-emission-census.json',r)
print(json.dumps({'complete':True,'changed_cases':r['changed_cases'],'target_before':before,'target_after':after,'stack_bytes_before':gate['max_stack_bytes_strictly_below'],'stack_bytes_after':g['stack_bytes'],'new_fma':False,'performance_observations':0}),flush=True)
