from pathlib import Path
import re
old=Path('/private/tmp/mech-polybench-optimization/round-58/typed-map-folds');f=Path(__file__).resolve().parent
names=['run-qualification.py','prepare-qualification-manifest.py','run-all-qualification.py','training-probe.py','run-training-probe.py','preserve-qualification.py','preserve-training.py','preserve-unselected.py','measure-candidate.py','run-formal.py','audit-results.py','finalize-formal.py','untimed-counter-gate.py','emission-census.py']
for name in names:
 s=(old/name).read_text();s=re.sub(r'(?<![A-Za-z0-9_])(?:53|54|55)(?![A-Za-z0-9_])',lambda m:str(int(m[0])+1),s).replace('accepted53','accepted54')
 s=s.replace('typed-map-folds','selected-map-spans').replace('typed-map-fold-route-census','selected-map-span-route-census').replace('typed_folds_emitted','selected_spans_emitted').replace('>=757','>=760').replace('len(paths)==10','len(paths)==9').replace("'native_typed_ir_version':423","'native_typed_ir_version':424").replace('IR423','IR424').replace('8.866344202351284','8.365861893301812').replace('24.816540346717115','24.599383003745523')
 s=s.replace('Typed ordered map folds','Completed selected map spans').replace('typed ordered map folds','completed selected map spans').replace('typed ordered fold transport','selected row-span publication').replace('Typed-fold probe','Selected-span probe')
 s=s.replace('The proved ordered F64 sum remains in F64 SSA until the original raw-word frame store. Every source action, term order, guard, callback, fee and visit remains; no runtime ABI or buffer changes.','Completed selected scratch is published as exact clipped physical row spans after all original checked evaluation. Source order/arithmetic, first failures, guards, callbacks, fees and visits remain; no runtime ABI or buffer change.')
 s=s.replace('Checked Objects certify ordered F64 accumulators without per-term running-sum FP/GPR round trips; no arithmetic reordering or FMA.','Checked Objects certify reached selected-publication vector-copy bodies and removal of per-cell coordinate reconstruction; source evaluation/arithmetic order is unchanged and no FMA is introduced.')
 s=s.replace('Every original source callback remains; only compiler-local ordered sum register transport changes under the unchanged issued loan.','Every original source callback remains; only completed nonfallible private publication traverses exact selected row spans under the unchanged loan.')
 s=s.replace('Source-proved ordered F64 map sums remain in F64 SSA until the original raw-word frame boundary, including standalone, phase and nested folds.','After complete checked evaluation, source-proved selected domains publish exact physical row spans with bounded integer vectors and scalar tails. All source order, arithmetic, original errors, guards, complete scratch/fallback, owners and accounting remain.')
 s=s.replace('Source-proved ordered map sums remain in F64 SSA until the existing word boundary.','Completed selected maps publish the exact selected set through physical row spans; all original source evaluation remains.')
 if name=='run-qualification.py':
  start=s.index("receipt={'scope':");end=s.index(",'compiler_fingerprint':fp",start)
  s=s[:start]+"receipt={'scope':'Selected-map completed row-span publication: runtime-bound exact old/new selected sets, all comparators and split/compound axes, widths1/2/4/8, SIMD/tails/empty/unaligned/poisoned holes/canaries, production SSA/native witnesses, original/decoded/restored public packed-kind/bit/error/finite-cap/alias/cleanup/retry tests; maintained scalar/compression/forged-loan/image/all30 finite C and both features; no performance samples'"+s[end:]
 if name=='preserve-qualification.py':
  start=s.index('source_audit={');end=s.index("\nb.write(folder/'source-audit.json'",start)
  audit={'schema':'mech.polybench.selected-map-span-source-audit.v1','compiler_fingerprint':None,'reviewed':True,'passed':True,'proof':'Existing source-derived selected axes are clipped intervals: first/count plus optional disjoint Ne tail. Their Cartesian selected set exactly equals old Selection::output_index. Full-column bands coalesce; singleton axes require only zero/one admitted cells. No new runtime proof authority.','memory':'Only completed selected scratch cells are read. Vector loops use offset<floor(bytes/16)*16 with16-byte steps, so every16-byte load/store lies wholly inside one initialized selected span. Whole-cell scalar tails stop at exact byte count. Empty intervals guard before memory/address use. Complete current spans and original scratch disjointness remain.','semantics':'All original checked map evaluation and every possible source failure precede private publication. Only final nonfallible private-store order changes to physical row spans. Old-value/simultaneous reads, arithmetic and FP order, original first failures and atomic publication remain. No source computation, source fee or visit is omitted.','ownership_and_fees':'No runtime/frame/helper/ABI/state/data buffer/allocation/owner change. Existing base==identity-source guard, full initialization for other-bank publication, exact complete fallback and all admission/replay/epoch/context rules remain. Every optimization15 execution counter exactly accepted54.','ablation':'Private SelectedMapSpans retains accepted54 per-cell publication. Existing complete publication and scratch initialization source are unchanged. Direct scalar/compression paths remain.','limits':'Genuine Object vector bodies and removed selected-coordinate work corroborate emission. Static totals include cold alternatives and are not retired hardware counts, measured memory traffic, full dynamic stack/peak RSS or a speedup prediction.'}
  s=s[:start]+'source_audit='+repr(audit)+"\nsource_audit['compiler_fingerprint']=fp"+s[end:]
 if name=='untimed-counter-gate.py':s=s.replace("['ordered_fold_bridge_sites']","['selected_span_vector_copies']")
 if name=='emission-census.py':
  start=s.index('def fold_bridges(');end=s.index("\nr={'schema'",start)
  parser=r'''def vector_copies(asm):
 rows=[];function=None;lines=asm.splitlines()
 for i,line in enumerate(lines):
  label=re.match(r'^[0-9a-f]+ <_(.+)>:',line)
  if label:function=label[1];continue
  load=re.match(r'^\s*([0-9a-f]+):\s+ldr\s+q(\d+),\s*\[x\d+(?:, [^\]]+)?\]',line)
  if not load:continue
  for later in lines[i+1:i+5]:
   if re.search(r'\b(?:b\s|ret\b|blr\b)',later):break
   if re.search(r'\bstr\s+q'+load[2]+r',\s*\[x\d+(?:, [^\]]+)?\]',later):rows.append({'function':function,'offset':load[1],'load':line,'store':later});break
 return rows
'''
  s=s[:start]+parser+s[end:]
  s=s.replace('mech.polybench.typed-map-fold-static-telemetry.v1','mech.polybench.selected-map-span-static-telemetry.v1').replace("'ordered_fold_bridge_sites':fold_bridges(asm)","'selected_span_vector_copies':vector_copies(asm),'multiply_high_sites':len(re.findall(r'\\bumulh\\b',asm))")
  start=s.index("r['selected_spans_emitted']=");end=s.index('\nr.update(complete=',start)
  s=s[:start]+"def copies(name,actor,suffix):return [site for site in r['cases'][name]['actors'][actor]['selected_span_vector_copies'] if site['function'].endswith(suffix)]\nr['selected_spans_emitted']=all(len(copies(name,'candidate',suffix))>=len(copies(name,'accepted54',suffix))+minimum for name,suffix,minimum in [('gramschmidt','numeric_5',2),('durbin','numeric_4',1)])\nr['independent_runtime_shape_kernel']='Focused production old/new selected publication functions have runtime bank pointers and axis bounds. New SSA uses I8x16 span loads/stores without Udiv/Urem coordinate reconstruction; old rectangular publication retains Udiv. Independent selected-set and old-emitter oracles, poisoned holes, canaries, exact bytes, all comparators/kinds and public original/decoded/restored cases qualify exact publication. Every source execution counter is unchanged.'"+s[end:]
  s=s.replace('Typed ordered accumulator Object evidence passed','Completed selected row-span Object evidence passed')
 (f/name).write_text(s)
for name in names:compile((f/name).read_text(),str(f/name),'exec')
print('Prepared accepted54/formal55 workflow, history55->56, >=760 broad/4 focused, exactly one210 probe and one900 formal; no timing observations.')
