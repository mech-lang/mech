"""Preserve all development evidence and qualify source before any timing."""
import gzip,importlib.util,json,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;q=b.read(folder/'qualification.json');plan=b.read(folder/'plan.json');gate=b.read(folder/'untimed-counter-gate.json');emission=b.read(folder/'emission-census.json');fp=b.compiler_fingerprint()
assert b.command(['git','branch','--show-current'])=='codex/polybench-native-matrices'
assert q['complete'] and q['driver_build_complete'] and q['tests']>=760 and q['focused_checks']['passed_tests']==[4]
assert fp==q['compiler_fingerprint']==gate['compiler_fingerprint']==emission['compiler_fingerprint']
assert gate['complete'] and gate['passed'] and gate['finite_liveouts']==17002 and all(row['all_counters_match'] for row in gate['cases'].values())
assert emission['complete'] and emission['passed'] and emission['selected_spans_emitted'] and emission['no_new_fma']
assert b.digest(q['driver'])==q['driver_sha256'] and len(b.read(p/'performance-history.json')['entries'])==55
assert b.read(p/'performance-acceptance.json')['accepted_history_index']==54 and not (folder/'training-probe.json').exists()
paths=plan['source_paths'];changed=subprocess.check_output(['git','diff','--name-only',plan['source_parent'],'--'],text=True).splitlines();changed+=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines();actual=sorted({name for name in changed if name.endswith(('.rs','.toml')) or Path(name).name=='Cargo.lock'})
assert set(actual)<=set(paths) and actual and len(paths)==9 and all(b.digest(root/name)==q['source_sha256'][name] for name in paths)
source_snapshot=folder/'qualified-source';source_snapshot.mkdir(exist_ok=False)
for name in paths:
 out=source_snapshot/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((root/name).read_bytes())
(folder/'qualified-source.patch').write_bytes(subprocess.check_output(['git','diff',plan['source_parent'],'--',*paths]))
attempts=[{'path':str(f.relative_to(folder)),'sha256':b.digest(f),'result':b.read(f),'source_snapshot_files':len(list((f.parent/'source').rglob('*.rs')))} for f in sorted(folder.glob('attempt-*/focused-result.json'))]
assert attempts and attempts[-1]['result']['exit_code']==0 and attempts[-1]['result']['compiler_fingerprint']==fp
source_audit={'schema': 'mech.polybench.selected-map-span-source-audit.v1', 'compiler_fingerprint': None, 'reviewed': True, 'passed': True, 'proof': 'Existing source-derived selected axes are clipped intervals: first/count plus optional disjoint Ne tail. Their Cartesian selected set exactly equals old Selection::output_index. Full-column bands coalesce; singleton axes require only zero/one admitted cells. No new runtime proof authority.', 'memory': 'Only completed selected scratch cells are read. Vector loops use offset<floor(bytes/16)*16 with16-byte steps, so every16-byte load/store lies wholly inside one initialized selected span. Whole-cell scalar tails stop at exact byte count. Empty intervals guard before memory/address use. Complete current spans and original scratch disjointness remain.', 'semantics': 'All original checked map evaluation and every possible source failure precede private publication. Only final nonfallible private-store order changes to physical row spans. Old-value/simultaneous reads, arithmetic and FP order, original first failures and atomic publication remain. No source computation, source fee or visit is omitted.', 'ownership_and_fees': 'No runtime/frame/helper/ABI/state/data buffer/allocation/owner change. Existing base==identity-source guard, full initialization for other-bank publication, exact complete fallback and all admission/replay/epoch/context rules remain. Every optimization15 execution counter exactly accepted54.', 'ablation': 'Private SelectedMapSpans retains accepted54 per-cell publication. Existing complete publication and scratch initialization source are unchanged. Direct scalar/compression paths remain.', 'limits': 'Genuine Object vector bodies and removed selected-coordinate work corroborate emission. Static totals include cold alternatives and are not retired hardware counts, measured memory traffic, full dynamic stack/peak RSS or a speedup prediction.'}
source_audit['compiler_fingerprint']=fp
b.write(folder/'source-audit.json',source_audit)
dest=p/'qualification/round-55-selected-map-spans/development';dest.mkdir(parents=True,exist_ok=False);archives={}
for source in sorted(folder.rglob('*')):
 if not source.is_file() or '__pycache__' in source.parts or source==Path(q['driver']):continue
 name=str(source.relative_to(folder));raw=source.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives[name]={'path':str(out.relative_to(p)),'sha256':b.digest(source),'compressed_sha256':b.digest(out)}
receipt={'schema':'mech.polybench.selected-map-spans-development.v1','created_at':b.utc(),'complete':True,'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'qualification_manifest':q,'effective_plan':plan,'selection_policy_sha256':b.digest(p/'performance-selection-policy-v4.json'),'source_parent':plan['source_parent'],'source_sha256':q['source_sha256'],'actual_changed_source_paths':actual,'profiling_basis':plan['profiling_basis'],'invariants':plan['implementation'],'counter_gate':gate,'emission_census':emission,'source_audit':source_audit,'development_attempts':attempts,'failed_attempt_logs_and_receipts_preserved':True,'performance_observations':0,'archives':archives}
b.write(p/'training-experiments/selected-map-spans-development.json',receipt)
b.write(p/'training-experiments/selected-map-spans-training-schedule.json',b.read(folder/'training-probe-plan.json'))
b.write(p/'round-55-selected-map-span-route-census.json',gate)
subprocess.run(['git','diff','--check'],check=True);subprocess.run(['git','add','--',*paths,str(p.relative_to(root))],check=True)
result=subprocess.run(['git','commit','-m','Qualify completed selected map spans before optimization selection'],capture_output=True,text=True);(folder/'qualification-source-commit.log').write_text(result.stdout+result.stderr);assert result.returncode==0
head=b.command(['git','rev-parse','HEAD']);assert b.compiler_fingerprint()==fp and b.command(['git','status','--porcelain'])==''
b.write(folder/'qualification-source-commit.json',{'source_commit':head,'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'performance_observations':0,'archives_verified':len(archives),'clean':True})
print(json.dumps({'head':head,'compiler_fingerprint':fp,'broad_checks':q['tests'],'focused_checks':4,'archives':len(archives),'performance_observations':0,'clean':True}),flush=True)
