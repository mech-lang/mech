"""One prospective optimization-only probe, matching formal process sampling."""
import argparse,importlib.util,json,math,pathlib,statistics,subprocess
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
parser=argparse.ArgumentParser();parser.add_argument('--plan-only',action='store_true');parser.add_argument('--driver',type=pathlib.Path);parser.add_argument('--qualification',type=pathlib.Path);a=parser.parse_args();protocol,cases=b.protocol()
adopted=b.read(folder/'plan.json')
policy={'schema':'mech.polybench.training-selection-policy.v3','scope':'Optimization15 only; no holdout performance or per-case diagnosis.','accepted_round':51,'samples_per_actor':7,'actors':['accepted51','candidate'],'sampling':'A new driver process for each single checked-call sample; interleave actors within each pair, alternating order by case and pair. Same cache flush, warmup, finite limits and checked-call timer as formal evaluation.','selection':'Exactly one prospective probe per fully qualified fingerprint. Select only raw equal-weight GM accepted51/candidate median-runtime speedup >1 after the preregistered untimed source/fee/visit gate. All original source work/comparison fees may increase and never decrease; physical visits remain unchanged for this transformation; every other counter must match accepted51. All210 observations/regressions retained, no retries/exclusions.','formal_gate':adopted['formal_acceptance'],'benchmark_protocol_unchanged':True,'observations':210,'adopted_policy_sha256':b.digest(b.FIXTURE/'performance-selection-policy-v4.json'),'prospective_plan_sha256':b.digest(b.FIXTURE/'training-experiments/immutable-map-read-reuse-plan.json')}

plan=[{'case':n,'pair':pair,'order':policy['actors'][((i+pair)%2):]+policy['actors'][:((i+pair)%2)]} for i,n in enumerate(protocol['optimization']) for pair in range(7)]
if a.plan_only:
 assert len(plan)==105 and sum(len(x['order']) for x in plan)==210;b.write(folder/'training-probe-plan.json',{'policy':policy,'schedule':plan,'performance_observations':0});print(json.dumps({'planned_observations':210,'programs':15,'driver_processes_per_observation':1,'performance_observations':0}));raise SystemExit(0)
assert a.driver and a.qualification
assert b.command(['git','status','--porcelain'])=='', 'Commit and push qualified source before probe.'
head=b.command(['git','rev-parse','HEAD'])
assert b.command(['git','ls-remote','origin','refs/heads/codex/polybench-native-matrices']).split()[0]==head
emission=b.read(folder/'emission-census.json');assert emission['complete'] and emission['source_unchanged'] and emission['passed'] and emission['read_reuse_emitted'] and emission['no_new_fma']
q=b.read(a.qualification);assert q['complete'] and all(c['exit_code']==0 for c in q['checks']);fp=b.compiler_fingerprint();assert fp==q['compiler_fingerprint'];assert b.digest(a.driver)==q['driver_sha256'];assert any(c['name']=='matrix-polybench.log' and c['passed_tests']==[24,30] for c in q['checks'])
gate=b.read(folder/'untimed-counter-gate.json');assert gate['complete'] and gate['passed'] and gate['compiler_fingerprint']==fp and gate['driver_sha256']==q['driver_sha256'] and gate['performance_observations']==0
output=folder/'training-probe.json';assert not output.exists(), 'Never overwrite or resume an observed probe.'
prior_paths=list(b.FIXTURE.glob('round-*-training-probe.json'))+list(pathlib.Path('/private/tmp/mech-polybench-optimization').glob('round-*/*/training-probe.json'))
for prior in prior_paths:
 assert b.read(prior).get('compiler_fingerprint')!=fp, f'This source already has an observed probe: {prior}'
actors={'accepted51':pathlib.Path(adopted['accepted_driver']),'candidate':a.driver};accepted=b.read(b.FIXTURE/'round-51-frozen.json');assert b.digest(actors['accepted51'])==accepted['driver_sha256']
b.write(folder/'selection-policy.json',policy)
def counters(report):
 prefix='NativeProgramExecutionReport { ';assert report.startswith(prefix) and report.endswith(' }');return {k:int(v) for k,v in [s.split(': ') for s in report[len(prefix):-2].split(', ')]}
r={'schema':'mech.polybench.training-probe.v3','created_at':b.utc(),'scope':policy['scope'],'policy':policy,'compiler_fingerprint':fp,'source_parent':b.command(['git','rev-parse','HEAD']),'driver_sha256':q['driver_sha256'],'samples_per_actor':7,'cases':{},'complete':False};b.write(output,r)
for row in plan:
 name=row['case'];case=cases[name];config=folder/f'{name}-inputs.json'
 if name not in r['cases']:b.write(config,case['inputs']);r['cases'][name]={'source_sha256':b.digest(b.FIXTURE/f'{name}.mec'),'observations':[]}
 for label in row['order']:
  argv=[str(actors[label]),str(b.FIXTURE/f'{name}.mec'),str(config),'1'];r['pending_observation']={'case':name,'pair':row['pair'],'actor':label,'command':argv};b.write(output,r)
  stdout=folder/f'{name}-pair{row["pair"]}-{label}.stdout';stderr=folder/f'{name}-pair{row["pair"]}-{label}.stderr'
  with stdout.open('x') as out,stderr.open('x') as err:
   child=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err);r['pending_observation']['pid']=child.pid;b.write(output,r)
   while True:
    try:code=child.wait(timeout=30);break
    except subprocess.TimeoutExpired:print('Waiting on same observed driver process',child.pid,flush=True)
  assert code==0,stderr.read_text()
  result=json.loads(stdout.read_text().strip().splitlines()[-1]);assert result['status']=='ok';sample,=result['samples_seconds'];assert math.isfinite(sample) and sample>0
  assert result['report']==gate['cases'][name]['actors'][label]['execution_report']

  observation={'pair':row['pair'],'actor':label,'seconds':sample,'driver_sha256':b.digest(actors[label]),'warmup_validation':b.validate(result['values'],case['expected']),'execution_report':result['report'],'execution_counters':counters(result['report'])};r['cases'][name]['observations'].append(observation);r.pop('pending_observation');b.write(output,r)
 if row['pair']==6:
  item=r['cases'][name];item['actors']={}
  for label in actors:
   observations=[o for o in item['observations'] if o['actor']==label];assert len(observations)==7 and all(o['execution_counters']==observations[0]['execution_counters'] for o in observations)
   values=[o['seconds'] for o in observations];item['actors'][label]={'samples_seconds':values,'median_seconds':statistics.median(values),'execution_counters':observations[0]['execution_counters'],'execution_report':observations[0]['execution_report']}
  item['speedup_vs_accepted51']=item['actors']['accepted51']['median_seconds']/item['actors']['candidate']['median_seconds'];delta={k:item['actors']['candidate']['execution_counters'][k]-v for k,v in item['actors']['accepted51']['execution_counters'].items()};item.update(execution_counter_deltas=delta,all_counters_match=all(v==0 for v in delta.values()),visits_match=delta['visits']==0,visit_changes_proved=gate['cases'][name]['visit_proof']['proved'] and delta==gate['cases'][name]['deltas'],other_counters_match=all(v==0 for k,v in delta.items() if k not in ['work','comparison_work','visits']),work_not_reduced=delta['work']>=0 and delta['comparison_work']>=0);b.write(output,r);print(name,'raw speedup',item['speedup_vs_accepted51'],flush=True)
ratios=[c['speedup_vs_accepted51'] for c in r['cases'].values()];assert len(ratios)==15
r['summary']={'count':15,'geomean_raw_speedup_vs_accepted51':b.geomean(ratios),'regressions_over_five_percent':sum(x<1/1.05 for x in ratios),'all_visits_match':all(c['visits_match'] for c in r['cases'].values()),'all_visit_changes_proved':all(c['visit_changes_proved'] for c in r['cases'].values()),'all_other_counters_match':all(c['other_counters_match'] for c in r['cases'].values()),'all_work_not_reduced':all(c['work_not_reduced'] for c in r['cases'].values())}
r['summary']['selected']=r['summary']['geomean_raw_speedup_vs_accepted51']>1 and all(r['summary'][key] for key in ['all_visit_changes_proved','all_other_counters_match','all_work_not_reduced'])
r.update(complete=True,completed_at=b.utc());assert b.compiler_fingerprint()==fp;b.write(output,r);print(json.dumps(r['summary']),flush=True)
