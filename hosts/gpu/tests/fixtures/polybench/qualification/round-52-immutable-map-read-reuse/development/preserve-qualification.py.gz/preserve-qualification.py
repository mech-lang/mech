"""Preserve all development evidence and qualify source before any timing."""
import gzip,importlib.util,json,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;q=b.read(folder/'qualification.json');plan=b.read(folder/'plan.json');gate=b.read(folder/'untimed-counter-gate.json');emission=b.read(folder/'emission-census.json');fp=b.compiler_fingerprint()
assert b.command(['git','branch','--show-current'])=='codex/polybench-native-matrices'
assert q['complete'] and q['driver_build_complete'] and q['tests']>=748 and q['focused_checks']['passed_tests']==[4]
assert fp==q['compiler_fingerprint']==gate['compiler_fingerprint']==emission['compiler_fingerprint']
assert gate['complete'] and gate['passed'] and gate['finite_liveouts']==17002 and all(row['all_counters_match'] for row in gate['cases'].values())
assert emission['complete'] and emission['passed'] and emission['read_reuse_emitted'] and emission['no_new_fma']
assert b.digest(q['driver'])==q['driver_sha256'] and len(b.read(p/'performance-history.json')['entries'])==52
assert b.read(p/'performance-acceptance.json')['accepted_history_index']==51 and not (folder/'training-probe.json').exists()
paths=plan['source_paths'];changed=subprocess.check_output(['git','diff','--name-only',plan['source_parent'],'--'],text=True).splitlines();changed+=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines();actual=sorted({name for name in changed if name.endswith(('.rs','.toml')) or Path(name).name=='Cargo.lock'})
assert set(actual)<=set(paths) and actual and len(paths)==10 and all(b.digest(root/name)==q['source_sha256'][name] for name in paths)
source_snapshot=folder/'qualified-source';source_snapshot.mkdir(exist_ok=False)
for name in paths:
 out=source_snapshot/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((root/name).read_bytes())
(folder/'qualified-source.patch').write_bytes(subprocess.check_output(['git','diff',plan['source_parent'],'--',*paths]))
attempts=[{'path':str(f.relative_to(folder)),'sha256':b.digest(f),'result':b.read(f),'source_snapshot_files':len(list((f.parent/'source').rglob('*.gz')))} for f in sorted(folder.glob('attempt-*/focused-result.json'))]
assert attempts and attempts[-1]['result']['exit_code']==0 and attempts[-1]['result']['compiler_fingerprint']==fp
source_audit={'schema':'mech.polybench.immutable-map-read-source-audit.v1','compiler_fingerprint':fp,'reviewed':True,'passed':True,'read_identity':'Only exact source matrix slot plus selector-ID vector is considered. Selectors are U64 immutable captures or the current map/rectangle elements; no dynamic selector samples or unproved aliases.','dominance_and_versions':'Trace unique source predecessors entirely inside the acyclic region to the prior successful read. Reject index definitions, publication, unknown actions, joins and cycles; the first checked load SSA word dominates any use. Cache is local to this body emission and its load still executes for every reached iteration.','failures':'Original first read remains with its bounds/error edge. Every intervening source operation and error executes in order. No reuse can make an inactive/non-dominating read visible. Focused invalid-bounds/error identity tests and maintained issued-loan/image/fallback checks pass.','bits':'Reuse unsigned word bits directly for packed kinds, including F64 signed zero/NaN/subnormal/Inf; no arithmetic transformation, reassociation or FMA.','ownership_and_fees':'All existing pinned immutable owner/shape/span/epoch, buffers, native runtime layout, source work/comparison fees, visits, caps, atomic publication and replay remain. Every optimization counter exactly equals accepted51.','ablation':'Private RepeatedMatrixReads option reaches standalone maps, phase maps and nested ordered folds. Reports are compiler-only descriptions, never serialized authority.','limitations':'Static emitted loads and instructions, not retired hardware counters or measured memory traffic. Backend may already share part of a read; actual Object differences are retained. A single prospective probe decides selection.'}
b.write(folder/'source-audit.json',source_audit)
dest=p/'qualification/round-52-immutable-map-read-reuse/development';dest.mkdir(parents=True,exist_ok=False);archives={}
for source in sorted(folder.rglob('*')):
 if not source.is_file() or '__pycache__' in source.parts or source==Path(q['driver']):continue
 name=str(source.relative_to(folder));raw=source.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives[name]={'path':str(out.relative_to(p)),'sha256':b.digest(source),'compressed_sha256':b.digest(out)}
receipt={'schema':'mech.polybench.immutable-map-read-reuse-development.v1','created_at':b.utc(),'complete':True,'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'qualification_manifest':q,'effective_plan':plan,'selection_policy_sha256':b.digest(p/'performance-selection-policy-v4.json'),'source_parent':plan['source_parent'],'source_sha256':q['source_sha256'],'actual_changed_source_paths':actual,'profiling_basis':plan['profiling_basis'],'invariants':plan['implementation'],'counter_gate':gate,'emission_census':emission,'source_audit':source_audit,'development_attempts':attempts,'failed_attempt_logs_and_receipts_preserved':True,'performance_observations':0,'archives':archives}
b.write(p/'training-experiments/immutable-map-read-reuse-development.json',receipt)
b.write(p/'training-experiments/immutable-map-read-reuse-training-schedule.json',b.read(folder/'training-probe-plan.json'))
b.write(p/'round-52-read-reuse-route-census.json',gate)
subprocess.run(['git','diff','--check'],check=True);subprocess.run(['git','add','--',*paths,str(p.relative_to(root))],check=True)
result=subprocess.run(['git','commit','-m','Qualify immutable map read reuse before optimization selection'],capture_output=True,text=True);(folder/'qualification-source-commit.log').write_text(result.stdout+result.stderr);assert result.returncode==0
head=b.command(['git','rev-parse','HEAD']);assert b.compiler_fingerprint()==fp and b.command(['git','status','--porcelain'])==''
b.write(folder/'qualification-source-commit.json',{'source_commit':head,'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'performance_observations':0,'archives_verified':len(archives),'clean':True})
print(json.dumps({'head':head,'compiler_fingerprint':fp,'broad_checks':q['tests'],'focused_checks':4,'archives':len(archives),'performance_observations':0,'clean':True}),flush=True)
