import collections,hashlib,importlib.util,json,math,pathlib,statistics,subprocess
root=pathlib.Path('/Users/cim310/.codex/worktrees/polybench-pr1000/mech');folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;f=b.read(p/'round-50-frozen.json');q=b.read(p/'round-50-training-qualification.json');protocol,cases=b.protocol()
assert b.compiler_fingerprint()==f['compiler_fingerprint']==q['compiler_fingerprint']
assert b.command(['git','rev-parse','HEAD'])==f['source_commit']
driver=pathlib.Path(q['driver'])
assert b.digest(driver)==f['driver_sha256']==q['driver_sha256']
assert b.digest('/private/tmp/mech-polybench-optimization/baseline-driver')==f['reference_driver_sha256']
counts=collections.Counter();totals={};controls={};rows={}
for partition in ['optimization','holdout']:
 receipt=b.read(p/f'round-50-{partition}.json');prior=b.read(p/f'round-48-{partition}.json')
 assert receipt['complete'] and receipt['samples_per_comparison']==5 and receipt['baseline_replay']
 assert receipt['candidate']==f and receipt['freeze_sha256']==b.digest(p/'round-50-frozen.json')
 assert set(receipt['runs'])==set(protocol[partition])
 raw=[];reference=[];c_drift=[];liveouts=0
 for name,run in receipt['runs'].items():
  assert run['source_sha256']==cases[name]['mech_sha256']
  expected=len(cases[name]['expected']);liveouts+=expected
  assert len(run['observations'])==30
  for mode in ['kernel','fresh']:
   for actor in ['mech','c','reference']:
    observations=[o for o in run['observations'] if o['actor']==actor and o['mode']==mode]
    assert len(observations)==5 and sorted(o['pair'] for o in observations)==list(range(5))
    values=[]
    for o in observations:
     assert math.isfinite(o['seconds']) and o['seconds']>0
     assert o['validation']['finite'] and o['validation']['count']==expected
     values.append(o['seconds']);counts[(partition,mode,actor)]+=1
    summary=run['comparisons'][mode][actor]
    assert summary['samples_seconds']==values and summary['median_seconds']==statistics.median(values)
   comparison=run['comparisons'][mode]
   assert comparison['median_mech_over_c']==comparison['mech']['median_seconds']/comparison['c']['median_seconds']
  current=run['comparisons']['kernel'];previous=prior['runs'][name]['comparisons']['kernel']
  raw.append(previous['mech']['median_seconds']/current['mech']['median_seconds'])
  reference.append(current['reference']['median_seconds']/previous['reference']['median_seconds'])
  c_drift.append(current['c']['median_seconds']/previous['c']['median_seconds'])
  rows[name]={'partition':partition,'mech_median_seconds':current['mech']['median_seconds'],'c_median_seconds':current['c']['median_seconds'],'mech_over_c_kernel':current['median_mech_over_c'],'accepted48_mech_over_c_kernel':previous['median_mech_over_c'],'raw_speedup_vs_accepted48':raw[-1]}
 totals[partition]={'programs':15,'liveouts':liveouts,'observations':sum(n for (part,_,_),n in counts.items() if part==partition)}
 controls[partition]={'raw_mech_speedup':b.geomean(raw),'original_reference_runtime_multiplier':b.geomean(reference),'reference_adjusted_speedup':b.geomean([x*y for x,y in zip(raw,reference)]),'c_runtime_multiplier':b.geomean(c_drift),'raw_regressions_over_five_percent_vs_accepted48':sum(x<1/1.05 for x in raw)}
assert sum(counts.values())==900 and sum(r['liveouts'] for r in totals.values())==29482
history=b.read(p/'performance-history.json');old=json.loads(subprocess.check_output(['git','show',f['source_commit']+':hosts/gpu/tests/fixtures/polybench/performance-history.json'],cwd=root,text=True))
assert history['entries'][:-1]==old['entries'] and len(history['entries'])==51
assert history['entries'][-1]['candidate']==f
subprocess.run(['python3',str(root/'scripts/record-polybench-acceptance.py'),'--check'],cwd=root,check=True,capture_output=True)
ledger=b.read(p/'performance-acceptance.json');decision=ledger['entries'][-1]
progress=b.read(p/'round-50-progress.json');assert history['entries'][-1]['aggregates']==progress['aggregates']
assert decision['compared_to_accepted_index']==48
assert (decision['performance_gate']=='accepted')==(decision['scores']['optimization']<9.401799375716326)
assert q['broad_selected_checks']>=740 and q['focused_selected_checks']==19
audit={'schema':'mech.polybench.frozen-audit.v1','created_at':b.utc(),'candidate_label':f['label'],'source_commit':f['source_commit'],'compiler_fingerprint':f['compiler_fingerprint'],'driver_sha256':f['driver_sha256'],'source_frozen_for_both_sets':True,'partitions':totals,'observations':sum(counts.values()),'counts_by_actor_mode':{'/'.join(k):v for k,v in counts.items()},'finite_liveouts':29482,'qualification_checks':q['broad_selected_checks'],'both_feature_checks_passed':True,'history_append_only':True,'history_entries':51,'performance_acceptance':decision,'aggregate_controls_vs_accepted48':controls,'holdout_use':'Reported independently; cannot veto, select, tune or trigger rollback/retry. No per-case holdout diagnosis.'}
b.write(p/'round-50-audit.json',audit);b.write(folder/'inter-round-aggregates.json',controls);b.write(folder/'formal-report-rows.json',dict(sorted(rows.items(),key=lambda pair:-pair[1]['mech_over_c_kernel'])))
b.write(p/'round-50-performance-acceptance.json',{'schema':'mech.polybench.round-performance-acceptance.v1','policy':ledger['policy'],'decision':decision,'performance_history_sha256':b.digest(p/'performance-history.json'),'interpretation':'Promote only when optimization15 kernel Mech/C is strictly below accepted48 (9.401799375716326). Holdout is independently reported and cannot veto, select, tune or trigger rollback/retry. All observations and regressions remain. Source work/comparison never decrease; every other counter, including visits, matches accepted48. Checked Objects certify guarded redundant scratch initialization; no reassociation or FMA.'})
print(json.dumps({'audit':'passed','observations':900,'scores':decision['scores'],'decision':decision['performance_gate'],'outcome':decision['run_outcome'],'accepted_index':decision['accepted_index_after_run'],'controls':controls,'goal':progress['goal']},indent=2))
