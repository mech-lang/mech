"""Preserve the single complete selected optimization probe before freeze."""
import gzip,hashlib,importlib.util,json,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;q=b.read(folder/'qualification.json');plan=b.read(folder/'plan.json');r=b.read(folder/'training-probe.json');gate=b.read(folder/'untimed-counter-gate.json');development=b.read(p/'training-experiments/compound-conditional-domains-development.json');fp=b.compiler_fingerprint()
assert r['complete'] and r['summary']['selected'] and gate['complete'] and gate['passed']
assert b.read(folder/'training-probe.exit.json')['exit_code']==0
assert fp==r['compiler_fingerprint']==q['compiler_fingerprint']==development['compiler_fingerprint']
assert sum(len(case['observations']) for case in r['cases'].values())==210 and len(r['cases'])==15
assert all(c['other_counters_match'] and c['work_not_reduced'] and c['visit_changes_proved'] for c in r['cases'].values())
assert b.digest(q['driver'])==q['driver_sha256']==r['driver_sha256'] and q['tests']>=740 and q['focused_checks']['passed_tests']==[19]
paths=plan['source_paths'];assert len(paths)==13 and all(b.digest(root/name)==q['source_sha256'][name] for name in paths)
assert len(b.read(p/'performance-history.json')['entries'])==50 and b.read(p/'performance-acceptance.json')['accepted_history_index']==48
for name in ['round-50-training-qualification.json','round-50-training-selection.json','round-50-training-probe.json','round-50-frozen.json']:assert not (p/name).exists()
dest=p/'qualification/round-50-compound-conditional-domains/training-probe';dest.mkdir(parents=True,exist_ok=False);archives={'development/'+name:rec for name,rec in development['archives'].items()}
for source in sorted(folder.rglob('*')):
 if not source.is_file() or '__pycache__' in source.parts or source==Path(q['driver']):continue
 name=str(source.relative_to(folder));raw=source.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives['probe/'+name]={'path':str(out.relative_to(p)),'sha256':b.digest(source),'compressed_sha256':b.digest(out)}
for rec in archives.values():
 data=(p/rec['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==rec['compressed_sha256'] and hashlib.sha256(gzip.decompress(data)).hexdigest()==rec['sha256']
qualification={'schema':'mech.polybench.training-qualification.v3','created_at':b.utc(),'complete':True,'compiler_fingerprint':fp,'driver':q['driver'],'driver_sha256':q['driver_sha256'],'source_parent':b.command(['git','rev-parse','HEAD']),'qualified_compiler_source_commit':b.read(folder/'qualification-source-commit.json')['source_commit'],'source_sha256':q['source_sha256'],'versions':q['versions'],'checks':q['checks'],'broad_selected_checks':q['tests'],'focused_selected_checks':19,'restored_corpus':{'programs':30,'forms':60,'finite_liveouts':58964},'development_attempts':development['development_attempts'],'development_archives':archives,'invariants':plan['implementation'],'prospective_refinements':development.get('prospective_refinements', {}),'profiling_basis':plan['profiling_basis'],'limitations':'Optimization15 diagnosis and selection only; holdout is independently reported and cannot veto, select, tune or trigger rollback/retry. All original observations remain, with no retry of an observed fingerprint. Broad/focused totals count selected test invocations and may overlap.'}
selection={'schema':'mech.polybench.training-selection.v3','created_at':b.utc(),'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'source_parent':qualification['source_parent'],'policy_sha256':b.digest(p/'training-experiments/compound-conditional-domains-plan.json'),'adopted_selection_policy_sha256':b.digest(p/'performance-selection-policy-v4.json'),'selected':True,'summary':r['summary'],'observations':210,'gate_passed':True,'performance_score':'Raw equal-weight GM accepted48/candidate medians on optimization15; one prospective fresh-process probe, all samples and regressions retained.','formal_gate':plan['formal_acceptance']}
b.write(p/'round-50-training-qualification.json',qualification);b.write(p/'round-50-training-selection.json',selection);b.write(p/'round-50-training-probe.json',r)
assert b.compiler_fingerprint()==fp
print(json.dumps({'selected':True,'summary':r['summary'],'observations':210,'archives_verified':len(archives),'source_paths':len(paths),'compiler_fingerprint':fp}),flush=True)
