"""Preserve every observation; restore accepted48 only on optimization-probe rejection."""
import gzip,hashlib,importlib.util,json,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;q=b.read(folder/'qualification.json');plan=b.read(folder/'plan.json');r=b.read(folder/'training-probe.json');gate=b.read(folder/'untimed-counter-gate.json');development=b.read(p/'training-experiments/compound-conditional-domains-development.json');fp=b.compiler_fingerprint()
assert r['complete'] and not r['summary']['selected'] and b.read(folder/'training-probe.exit.json')['exit_code']==0
assert fp==r['compiler_fingerprint']==q['compiler_fingerprint']==development['compiler_fingerprint']
assert sum(len(case['observations']) for case in r['cases'].values())==210 and len(r['cases'])==15
assert all(c['visit_changes_proved'] and c['work_not_reduced'] and c['other_counters_match'] for c in r['cases'].values())
assert b.digest(q['driver'])==q['driver_sha256']==r['driver_sha256'] and b.digest(plan['accepted_driver'])==plan['accepted_driver_sha256']
assert len(b.read(p/'performance-history.json')['entries'])==50 and b.read(p/'performance-acceptance.json')['accepted_history_index']==48
assert not (p/'round-50-frozen.json').exists() and not (p/'round-50-holdout.json').exists()
paths=plan['source_paths'];assert all(b.digest(root/name)==q['source_sha256'][name] for name in paths)
history_hash=b.digest(p/'performance-history.json');acceptance_hash=b.digest(p/'performance-acceptance.json')
dest=p/'qualification/round-50-compound-conditional-domains/unselected-probe';dest.mkdir(parents=True,exist_ok=False);archives={'development/'+name:rec for name,rec in development['archives'].items()}
for source in sorted(folder.rglob('*')):
 if not source.is_file() or '__pycache__' in source.parts or source==Path(q['driver']):continue
 name=str(source.relative_to(folder));raw=source.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives['probe/'+name]={'path':str(out.relative_to(p)),'sha256':b.digest(source),'compressed_sha256':b.digest(out)}
for rec in archives.values():
 data=(p/rec['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==rec['compressed_sha256'] and hashlib.sha256(gzip.decompress(data)).hexdigest()==rec['sha256']
speedup=r['summary']['geomean_raw_speedup_vs_accepted48']
receipt={'schema':'mech.polybench.unselected-training-probe.v1','created_at':b.utc(),'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'qualified_source_commit':b.read(folder/'qualification-source-commit.json')['source_commit'],'source_parent':plan['source_parent'],'qualification':q,'source_fee_and_visit_gate':gate,'summary':r['summary'],'observations':210,'selected':False,'accepted_round':48,'accepted_scores':plan['accepted_scores'],'holdout_performance_observations':0,'formal_performance_observations':0,'history_entries_unchanged':50,'reason':f'Single prospective optimization probe raw GM{speedup:.16f} is not strictly above1. No retry of this observed fingerprint, exclusions or holdout decision.','archives':archives,'next':'Use optimization-only profiles and actual generated work to derive a materially different experiment. No exact retry; preserve both accepted aggregate results.'}
b.write(p/'training-experiments/compound-conditional-domains-unselected-probe.json',r);b.write(p/'training-experiments/compound-conditional-domains-unselected.json',receipt)
subprocess.run(['git','restore','--source='+plan['source_parent'],'--worktree','--',*paths],check=True);subprocess.run(['git','add','-A','--',*paths],check=True)
restored=b.compiler_fingerprint();assert restored==b.read(p/'round-48-frozen.json')['compiler_fingerprint']==plan['accepted_compiler_fingerprint']
assert b.digest(p/'performance-history.json')==history_hash and b.digest(p/'performance-acceptance.json')==acceptance_hash
subprocess.run(['python3',str(root/'scripts/record-polybench-acceptance.py'),'--check','--require-latest-accepted'],check=True,capture_output=True)
with (p/'README.txt').open('a') as out:
 out.write('\nCompound conditional domains (not selected)\n\n')
 out.write(f'All{q["tests"]} broad/19 focused checks, both features, all30 C cases and restored images, and the untimed optimization15 C/source-fee/unchanged-visit/Object gate passed. Conservative source CFG identity buckets factor into source-ordered Cartesian domains, preserving unknown/fallible branches. Selected body evaluations and redundant same-bank scratch copies disappear; different-bank full publication retains initialization and partial scratch has no full-output certificate. These physical reductions do not establish a runtime gain.\n\n')
 out.write(f'The single210-observation optimization-only probe measured{speedup:.16f}x raw GM speedup versus accepted48, with {r["summary"]["regressions_over_five_percent"]} regressions over5%. It fails the prospective selection rule. All observations remain; no exact fingerprint retry and no holdout/formal timing ran. Exact accepted48 source is restored. Accepted scores remain9.401799375716326x optimization /24.666190246754944x holdout, independently reported.\n\n')
 out.write('[Unselected observations](training-experiments/compound-conditional-domains-unselected-probe.json) · [Qualification/restoration](training-experiments/compound-conditional-domains-unselected.json)\n')
subprocess.run(['git','diff','--check'],check=True);subprocess.run(['git','add','--',str(p.relative_to(root))],check=True);subprocess.run(['git','commit','-q','-m','Record compound domain probe and restore accepted48'],check=True)
head=b.command(['git','rev-parse','HEAD']);assert b.compiler_fingerprint()==restored and b.command(['git','status','--porcelain'])==''
b.write(folder/'current-work.json',{'stage':'Scratch initialization probe not selected; all210 observations retained; exact accepted48 source restored and committed, push pending','source_commit':head,'compiler_fingerprint':restored,'candidate_fingerprint':fp,'candidate_driver_sha256':q['driver_sha256'],'accepted_round':48,'accepted_scores':plan['accepted_scores'],'formal_history_entries':49,'live_exec_session':None,'next':'Use optimization-only profiles for the next materially different general compiler experiment. No exact retry, holdout diagnosis or selection.'})
print(json.dumps({'head':head,'selected':False,'probe_speedup':speedup,'observations':210,'holdout_observations':0,'archives_verified':len(archives),'accepted_round':48,'restored_exactly':True,'clean':True}),flush=True)
