"""Apply the preregistered total private map Object gate without timing or execution."""
import hashlib,importlib.util,json,pathlib,re,subprocess
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
q=b.read(folder/'qualification.json');assert q['complete'] and b.compiler_fingerprint()==q['compiler_fingerprint'];driver=folder/'private-map-driver';assert b.digest(driver)==q['driver_sha256']
plan=b.read(folder/'plan.json');protocol,cases=b.protocol();objects=folder/'execution-objects';objects.mkdir(exist_ok=False);old=pathlib.Path('/private/tmp/mech-polybench-optimization/round-31/inverse-bitcasts/objects')
def instructions(asm):
 functions={};name=None
 for line in asm.splitlines():
  m=re.match(r'^[0-9a-f]+ <_(.+)>:',line)
  if m:name=m[1];functions[name]=[]
  elif name and re.match(r'^\s*[0-9a-f]+:',line):functions[name].append(line)
 return functions
def stats(lines):
 return {'instructions':len(lines),'sha256':hashlib.sha256('\n'.join(lines).encode()).hexdigest(),'stack_memory_instructions':sum(bool(re.search(r'\b(?:ldr|str|ldp|stp|ldur|stur)\s+.*\[sp(?:,|\])',line)) for line in lines),'fma':sum(bool(re.search(r'\b(?:fmadd|fmsub|fnmadd|fnmsub|fmla|fmls)\s+',line)) for line in lines)}
r={'schema':'mech.polybench.training-emission-census.v1','scope':'Optimization15 actual checked Objects, never linked or executed. Static counts are not dynamic costs or timings. Apply the unchanged prospective total private map gate.','compiler_fingerprint':q['compiler_fingerprint'],'driver_sha256':q['driver_sha256'],'plan_sha256':b.digest(folder/'plan.json'),'cases':{},'complete':False,'new_performance_observations':0}
for name in protocol['optimization']:
 config=folder/f'{name}-inputs.json';b.write(config,cases[name]['inputs']);obj=objects/f'{name}.o'
 process=subprocess.run([str(driver),str(b.FIXTURE/f'{name}.mec'),str(config),'0','emit-object='+str(obj)],capture_output=True,text=True,check=True,timeout=180)
 result=json.loads(process.stdout.strip().splitlines()[-1]);assert result['status']=='ok' and result['mode']=='emit-object'
 metadata=b.read(obj.with_suffix('.metadata.json'));assert metadata['typed_ir_version']==407 and metadata['work_policy_version']==156 and metadata['abi_version']==47
 asm=subprocess.check_output(['/Library/Developer/CommandLineTools/usr/bin/llvm-objdump','--disassemble','--no-show-raw-insn',str(obj)],text=True);obj.with_suffix('.disasm.txt').write_text(asm)
 current=instructions(asm);before=instructions((old/f'{name}.disasm.txt').read_text());r['cases'][name]={'code_bytes':metadata['code_bytes'],'stack_bytes':metadata['stack_bytes'],'object_sha256':b.digest(obj),'metadata_sha256':b.digest(obj.with_suffix('.metadata.json')),'disassembly_sha256':b.digest(obj.with_suffix('.disasm.txt')),'functions':{k:stats(v) for k,v in current.items()},'accepted31_functions':{k:stats(v) for k,v in before.items()},'object_executed':False}
 b.write(folder/'execution-emission-census.json',r);print(name,'exported',flush=True)
gate=plan['prospective_emission_gate'];target=gate['target'];g=r['cases']['gramschmidt'];after=g['functions'][target];before=g['accepted31_functions'][target]
assert after['sha256']!=before['sha256']
metadata=b.read((objects/'gramschmidt.o').with_suffix('.metadata.json'))
function=next(f for f in metadata['compiled_numeric_functions'] if f['symbol']==target)
assert g['stack_bytes']<gate['combined_native_stack_bytes_strictly_below']
assert function['stack_bytes']<gate['profiled_function_stack_bytes_strictly_below']
source=pathlib.Path('/private/tmp/mech-polybench-optimization/round-38/hoisted-map-bounds/native-loop-census.py').read_text();needle="'loops':inner_rows,";assert needle in source
source=source.replace(needle,"'loops':inner_rows, 'all_loop_members':{lines[h][0]:[lines[i][0] for i in sorted(s)] for h,s in loops.items()}, 'instructions_by_address':{a:[op,args] for a,op,args in lines},")
ns={'__name__':'static_loop_census'};exec(compile(source,'preserved-native-loop-census.py','exec'),ns)
def copies(asm):
 census=ns['measure'](asm,target);ops=census['instructions_by_address'];members=census['all_loop_members'];found=[]
 for header,addresses in members.items():
  ins=[ops[a] for a in addresses]
  if len(ins)>12:continue
  if not any(op in ['ldr','ldur','ldp'] for op,args in ins) or not any(op in ['str','stur','stp'] for op,args in ins):continue
  if not any(op=='add' and re.search(r', #8$',args) for op,args in ins):continue
  if not any(op in ['mov','movz','cmp'] and re.search(r', #(4800|7200)$',args) for op,args in ins):continue
  found.append({'header':header,'instructions':ins})
 return found
old_copies=copies((old/'gramschmidt.disasm.txt').read_text());new_copies=copies((objects/'gramschmidt.disasm.txt').read_text())
assert len(old_copies)==gate['tight_large_payload_copy_loops_before']
assert len(new_copies)==gate['tight_large_payload_copy_loops_after'], 'The three hot large whole-map copies must disappear before timing.'
assert all(sum(f['fma'] for f in row['functions'].values())==0 for row in r['cases'].values())
r['large_copy_loops']={'accepted31':old_copies,'candidate':new_copies};r['profiled_function_stack_bytes']=function['stack_bytes']
r['changed_cases']=[name for name,row in r['cases'].items() if row['functions']!=row['accepted31_functions']];r['complete']=len(r['cases'])==15;r['prospective_gate_passed']=True
assert b.compiler_fingerprint()==q['compiler_fingerprint'];b.write(folder/'execution-emission-census.json',r)
print(json.dumps({'complete':True,'changed_cases':r['changed_cases'],'target_before':before,'target_after':after,'combined_stack_bytes_before':gate['combined_native_stack_bytes_strictly_below'],'combined_stack_bytes_after':g['stack_bytes'],'profiled_function_stack_bytes':function['stack_bytes'],'large_copy_loops_before':len(old_copies),'large_copy_loops_after':len(new_copies),'new_fma':False,'performance_observations':0}),flush=True)
