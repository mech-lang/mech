from pathlib import Path
root=Path('/Users/cim310/.codex/worktrees/polybench-pr1000/mech')
base=root/'hosts/gpu/src/native_artifact'
def edit(name,old,new,n=1):
 p=base/name;s=p.read_text();assert s.count(old)==n,(name,s.count(old),old);p.write_text(s.replace(old,new))
p='program/codegen/numeric_map.rs'
edit(p,'use crate::native_artifact::compiler::{backend, offset, primitive};','use crate::native_artifact::compiler::{backend, f64_arithmetic, offset, primitive};')
edit(p,'    counter_slot: usize,\n    exit: Block,','    counter_slot: usize,\n    typed_folds: bool,\n    exit: Block,')
edit(p,'    emit(b, frame, region, plan, &captures, complete, miss, malformed)?;','    emit(b, frame, region, plan, &captures, typed_folds, complete, miss, malformed)?;')
edit(p,'    captures: &BTreeMap<u32, Value>,\n    complete: Block,','    captures: &BTreeMap<u32, Value>,\n    typed_folds: bool,\n    complete: Block,')
edit(p,'        b, frame, region, plan, captures, None, None, complete, miss, malformed,','        b, frame, region, plan, captures, typed_folds, None, None, complete, miss, malformed,')
edit(p,'    captures: &BTreeMap<u32, Value>,\n    selection:','    captures: &BTreeMap<u32, Value>,\n    typed_folds: bool,\n    selection:')
edit(p,'''    let fold = if region.reduction.is_some() {
        let var = b.declare_var(types::I64);
        b.def_var(var, zero);
        Some(var)
    } else {
        None
    };''','''    let fold = region.reduction.as_ref().map(|_| Fold::new(b, zero, typed_folds));''')
edit(p,'                &captures,\n                index_miss,','                &captures,\n                typed_folds,\n                index_miss,')
edit(p,'''                        let prior = b.use_var(fold);
                        let next = primitive(
                            b,
                            mech_engine::native_artifact::NativeScalarOp::F64Add,
                            &[prior, result],
                            miss,
                        );
                        b.def_var(fold, next);''','''                        fold.push(b, result, miss);''')
edit(p,'        let value = b.use_var(fold);','        let value = fold.word(b);')
marker='pub(in crate::native_artifact) fn emit_entry('
helper='''/// An emission-only choice, never a runtime value or new source proof. All
/// admitted map reductions are ordered F64 sums. Keep that sum in its native
/// register class until the existing raw-word frame boundary. Source terms
/// and all their checked scalar operations retain their original word DAG.
#[derive(Clone, Copy)]
struct Fold {
    variable: Variable,
    typed: bool,
}
impl Fold {
    fn new(b: &mut FunctionBuilder<'_>, zero: Value, typed: bool) -> Self {
        let variable = b.declare_var(if typed { types::F64 } else { types::I64 });
        let initial = if typed {
            b.ins().f64const(cranelift_codegen::ir::immediates::Ieee64::with_bits(0))
        } else {
            zero
        };
        b.def_var(variable, initial);
        Self { variable, typed }
    }
    fn push(self, b: &mut FunctionBuilder<'_>, term: Value, miss: Block) {
        use mech_engine::native_artifact::NativeScalarOp::F64Add;
        let prior = b.use_var(self.variable);
        let next = if self.typed {
            let term = b.ins().bitcast(types::F64, MemFlags::new(), term);
            f64_arithmetic(b, F64Add, prior, term)
        } else {
            primitive(b, F64Add, &[prior, term], miss)
        };
        b.def_var(self.variable, next);
    }
    fn word(self, b: &mut FunctionBuilder<'_>) -> Value {
        let value = b.use_var(self.variable);
        if self.typed {
            b.ins().bitcast(types::I64, MemFlags::new(), value)
        } else {
            value
        }
    }
}

'''
edit(p,marker,helper+marker)
p='program/codegen/numeric_phase_reductions.rs'
edit(p,'    plan: &Plan,\n    miss: Block,','    plan: &Plan,\n    typed_folds: bool,\n    miss: Block,')
edit(p,'    let value = emit_from_views(b, source, plan, first, last, &matrices, &captures, miss)?;','    let value = emit_from_views(b, source, plan, first, last, &matrices, &captures, typed_folds, miss)?;')
edit(p,'    captures: &BTreeMap<u32, Value>,\n    miss: Block,','    captures: &BTreeMap<u32, Value>,\n    typed_folds: bool,\n    miss: Block,')
edit(p,'        b, region, plan, first, count, matrices, captures, None, miss,','        b, region, plan, first, count, matrices, captures, typed_folds, None, miss,')
edit(p,'    captures: &BTreeMap<u32, Value>,\n    output:','    captures: &BTreeMap<u32, Value>,\n    typed_folds: bool,\n    output:',2)
edit(p,'        b, region, plan, first, count, matrices, captures, output, None, None, miss,','        b, region, plan, first, count, matrices, captures, typed_folds, output, None, None, miss,')
edit(p,'        captures,\n        selection,','        captures,\n        typed_folds,\n        selection,')
p='program/codegen/numeric_phase_maps.rs'
edit(p,'    compound_domains: bool,\n    miss: Block,','    compound_domains: bool,\n    typed_folds: bool,\n    miss: Block,')
edit(p,'        &captures,\n        Some((scratch, capacity)),','        &captures,\n        typed_folds,\n        Some((scratch, capacity)),')
p='program/codegen/readonly_numeric.rs'
edit(p,'                    &program.metadata().plan,\n                    reduction_miss','                    &program.metadata().plan,\n                    controls.enabled(OptimizationPass::TypedMapFolds),\n                    reduction_miss')
edit(p,'                    controls.enabled(OptimizationPass::CompoundMatrixMasks),\n                    reduction_miss','                    controls.enabled(OptimizationPass::CompoundMatrixMasks),\n                    controls.enabled(OptimizationPass::TypedMapFolds),\n                    reduction_miss')
p='codegen/control/mod.rs'
edit(p,'                    plan.value_count() + iteration as usize,\n                    blocks[exit','                    plan.value_count() + iteration as usize,\n                    controls.enabled(\n                        crate::native_artifact::codegen::options::OptimizationPass::TypedMapFolds,\n                    ),\n                    blocks[exit')
p='codegen/options.rs'
edit(p,'    NumericCollections,','    NumericCollections,\n    /// Keep proved ordered map-reduction sums in F64 SSA until word publication.\n    TypedMapFolds,')
p='program/image/identity.rs'
edit(p,'pub const NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 422;','pub const NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 423;')
p='program/runtime/composition_tests/mod.rs'
edit(p,'mod numeric_map_reductions;','mod numeric_map_reductions;\nmod typed_map_folds;')
print('Applied typed accumulator emission and threaded standalone/phase/nested ablation; tests pending.')
