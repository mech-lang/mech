from pathlib import Path
import re
old=Path('/private/tmp/mech-polybench-optimization/round-56/ordered-product-four-rows');f=Path(__file__).resolve().parent
names=['run-qualification.py','prepare-qualification-manifest.py','run-all-qualification.py','training-probe.py','run-training-probe.py','preserve-qualification.py','preserve-training.py','preserve-unselected.py','measure-candidate.py','run-formal.py','audit-results.py','finalize-formal.py','untimed-counter-gate.py','emission-census.py']
for name in names:
 s=(old/name).read_text()
 s=re.sub(r'(?<![A-Za-z0-9_])(?:52|53|54)(?![A-Za-z0-9_])',lambda m:str(int(m[0])+1),s).replace('accepted52','accepted53').replace('accepted53/candidate','accepted53/candidate')
 s=s.replace('ordered-product-four-rows','typed-map-folds').replace('product-four-row-route-census','typed-map-fold-route-census').replace('four_row_tiles_emitted','typed_folds_emitted').replace('>=756','>=757').replace('len(paths)==9','len(paths)==10').replace("'native_typed_ir_version':422","'native_typed_ir_version':423").replace('IR422','IR423').replace('8.964570055711857','8.866344202351284').replace('24.520309780198453','24.816540346717115')
 s=s.replace('Four independent product rows','Typed ordered map folds').replace('four independent product rows','typed ordered map folds').replace('four-row product grouping','typed ordered fold transport').replace('Four-row product probe','Typed-fold probe')
 s=s.replace('One RHS load/k loop serves four independent ordered output rows. This changes only private native kernel execution, preserving every original source callback, logical fee and execution counter; no visits are skipped.','The proved ordered F64 sum remains in F64 SSA until the original raw-word frame store. Every source action, term order, guard, callback, fee and visit remains; no runtime ABI or buffer changes.')
 s=s.replace('Checked Objects certify one reached RHS load feeding four independent ordered product accumulators; no arithmetic reordering or FMA.','Checked Objects certify ordered F64 accumulators without per-term running-sum FP/GPR round trips; no arithmetic reordering or FMA.')
 s=s.replace('Every original source callback remains; one private RHS load/k loop serves four ordered output rows under the unchanged issued loan.','Every original source callback remains; only compiler-local ordered sum register transport changes under the unchanged issued loan.')
 s=s.replace('General F64 products group four independent output rows around one RHS load/k loop, with original per-cell arithmetic order and2/1-row tails.','Source-proved ordered F64 map sums remain in F64 SSA until the original raw-word frame boundary, including standalone, phase and nested folds.')
 s=s.replace('One RHS load/k loop feeds four independent ordered product rows.','Source-proved ordered map sums remain in F64 SSA until the existing word boundary.')
 if name=='run-qualification.py':
  start=s.index("receipt={'scope':");end=s.index(",'compiler_fingerprint':fp",start)
  s=s[:start]+"receipt={'scope':'Typed ordered F64 map-fold transport: exact old-word/default JIT bits, signed zero/subnormals/cancellation/NaN payloads, vectors/empty inputs, standalone/phase/nested folds, original/decoded/restored, caps/atomic errors/aliases/cleanup/retry and runtime-shaped Float SSA; maintained scalar/compression/forged-loan/image/all30 finite C and both features; no performance samples'"+s[end:]
 if name=='preserve-qualification.py':
  start=s.index('source_audit={');end=s.index("\nb.write(folder/'source-audit.json'",start)
  audit={'schema':'mech.polybench.typed-map-fold-source-audit.v1','compiler_fingerprint':None,'reviewed':True,'passed':True,'proof':'Only existing source-derived ordered F64 map reduction proofs reach the compiler-local fold accumulator; no new admission/type authority. All original map terms, reads, scalar DAG, conditions and errors remain.','arithmetic':'Original +0.0 and exact original ordered F64Add through common strict emitter; each original raw-word term bitcasts toF64, and final value bitcasts back only at the existing raw-word frame store. No reassociation/FMA/split sums/casts/NaN canonicalization. Exact old-word JIT and runtime-shaped production helper comparisons cover cancellation, signed zero, subnormals, infinities and NaN payloads.','ownership_and_fees':'No runtime/frame/helper/ABI/state/buffer/allocation/owner change. Existing stack frame, scratch, full current-view guards, first failures, complete replay/physical admission and atomic completion remain. Every optimization15 execution counter exactly accepted53, including work/comparison/visits.','ablation':'Private TypedMapFolds disables only compiler-local typed accumulation and retains accepted53 I64 fold on standalone, phase and nested routes. Scalar/compression paths remain.','limitations':'Genuine Object ordered-loop accumulator bridge evidence is required; static totals include cold variants and are not retired hardware instructions, measured traffic or a speedup forecast.'}
  s=s[:start]+'source_audit='+repr(audit)+"\nsource_audit['compiler_fingerprint']=fp"+s[end:]
 if name=='untimed-counter-gate.py':s=s.replace("views=emission['cases'][name]['actors']['candidate']['shared_right_load_groups']","views=emission['cases'][name]['actors']['candidate']['ordered_fold_bridge_sites']")
 if name=='emission-census.py':
  start=s.index('def reuse_groups(');end=s.index("\nr={'schema'",start)
  function=r'''def fold_bridges(asm):
 rows=[];function=None;prior=[]
 lines=asm.splitlines()
 for index,line in enumerate(lines):
  label=re.match(r'^[0-9a-f]+ <_(.+)>:',line)
  if label:function=label[1];prior=[];continue
  m=re.match(r'^\s*([0-9a-f]+):\s+fadd\s+d(\d+),\s*d(\d+),\s*d(\d+)',line)
  if not m:continue
  address,dest,left,right=m.groups()
  for lane in [left,right]:
   source=None
   for earlier in reversed(lines[max(0,index-12):index]):
    bridge=re.search(r'\bfmov\s+d'+lane+r',\s*x(\d+)\b',earlier)
    if bridge:source=(bridge[1],earlier);break
    if re.search(r'\b(?:f\w+|ldr|ldur|mov)\s+d'+lane+r'\b',earlier):break
   if not source:continue
   word,origin=source
   for later in lines[index+1:index+7]:
    if re.search(r'\b(?:b\s|ret\b|fadd\b)',later):break
    if re.search(r'\bmov\.d\s+x'+word+r',\s*v'+dest+r'\[0\]',later) or re.search(r'\bfmov\s+x'+word+r',\s*d'+dest+r'\b',later):
     rows.append({'function':function,'fadd_address':address,'word_register':'x'+word,'source_bridge':origin,'ordered_add':line,'result_bridge':later});break
 return rows
'''
  s=s[:start]+function+s[end:]
  s=s.replace("'schema':'mech.polybench.product-four-rows-static-telemetry.v1'","'schema':'mech.polybench.typed-map-fold-static-telemetry.v1'")
  s=s.replace("'shared_right_load_groups':reuse_groups(asm)","'ordered_fold_bridge_sites':fold_bridges(asm)")
  start=s.index("r['typed_folds_emitted']=");end=s.index('\nr.update(complete=',start)
  s=s[:start]+"r['typed_folds_emitted']=all(any(site['function'].endswith(suffix) for site in r['cases'][name]['actors']['accepted53']['ordered_fold_bridge_sites']) and not any(site['function'].endswith(suffix) for site in r['cases'][name]['actors']['candidate']['ordered_fold_bridge_sites']) for name,suffix in [('gramschmidt','numeric_5'),('durbin','numeric_4')])\nr['independent_runtime_shape_kernel']='Focused production Fold emission has runtime input pointer/count and raw-word result. New loop carries F64 phi, old carries I64; exact old-word JIT comparisons cover empty/cancellation/signed zero/subnormal/nonfinite payloads. All original public JIT standalone/phase/nested programs and unchanged-counter gate pass.'"+s[end:]
  s=s.replace('Shared right-load/independent-accumulator Object evidence passed','Typed ordered accumulator Object evidence passed')
 (f/name).write_text(s)
for name in names:compile((f/name).read_text(),str(f/name),'exec')
print('Prepared baseline53/formal54 workflow: history54->55, one210 probe, one900 formal; no timing observations.')
