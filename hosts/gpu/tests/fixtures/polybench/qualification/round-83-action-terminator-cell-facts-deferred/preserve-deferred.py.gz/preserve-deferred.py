from pathlib import Path
import subprocess,json,importlib.util,gzip,hashlib
root=Path.cwd();f=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
plan=b.read(f/'plan.json');paths=plan['source_paths'];fp=b.compiler_fingerprint()
assert not list(f.glob('attempt-*'))
assert not(f/'training-probe.json').exists() and not(f/'prototype-result.json').exists()
snapshot=f/'deferred-source';snapshot.mkdir(exist_ok=False)
for name in paths:
 out=snapshot/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((root/name).read_bytes())
changed=set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())
assert {name for name in changed if name.endswith('.rs')}==set(paths)
attempts=[b.read(p)for p in sorted(f.glob('attempt-*/focused-result.json'))]
b.write(f/'deferred.json',{'schema':'mech.polybench.deferred-compiler-prototype.v1','created_at':b.utc(),'compiler_fingerprint':fp,'reason':'User explicitly selected the exact round62 Seidel1.62x source as the foundation and directed fixing other optimization regressions. This R83 source only reloaded the deferred R79 prototype and retained the R82 productive-prefix rule/test; no new stable-guard proof was implemented, built, qualified or measured. Preserve this state and plan, then recover exact round62 for optimization-only Deriche profiling.','attempts':attempts,'performance_observations':0,'holdout_observations':0,'next':'Recover exact round62 source as a diagnostic foundation; identify and fix regressed optimization cases while preserving Seidel lowering. Strict optimization-only qualification/one-probe/formal gates remain.'})
p=b.FIXTURE;dest=p/'qualification/round-83-action-terminator-cell-facts-deferred';dest.mkdir(parents=True,exist_ok=False);archives={}
for source in sorted(f.rglob('*')):
 if not source.is_file() or '__pycache__'in source.parts:continue
 name=str(source.relative_to(f));raw=source.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives[name]={'path':str(out.relative_to(p)),'sha256':hashlib.sha256(raw).hexdigest(),'compressed_sha256':b.digest(out)}
tracked=[];introduced=[]
for name in paths:
 if subprocess.run(['git','cat-file','-e',plan['source_parent']+':'+name],capture_output=True).returncode==0:tracked.append(name)
 else:introduced.append(name)
subprocess.run(['git','restore','--source='+plan['source_parent'],'--worktree','--',*tracked],check=True)
untracked=set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())
for name in introduced:
 assert name in untracked and (root/name).read_bytes()==(snapshot/name).read_bytes();(root/name).unlink()
restored=b.compiler_fingerprint();assert restored==plan['accepted_compiler_fingerprint']
b.write(p/'training-experiments/action-terminator-cell-facts-deferred.json',dict(b.read(f/'deferred.json'),effective_plan=plan,archives=archives,restored_compiler_fingerprint=restored,accepted_round_unchanged=59,formal_history_entries_unchanged=63))
subprocess.run(['git','diff','--check'],check=True);subprocess.run(['git','add','--',str(p.relative_to(root))],check=True);subprocess.run(['git','-c','gc.auto=0','commit','-q','-m','Defer cell-context work to preserve the requested1.62x foundation'],check=True)
assert b.command(['git','status','--porcelain'])==''
print(json.dumps({'head':b.command(['git','rev-parse','HEAD']),'deferred_fingerprint':fp,'restored_fingerprint':restored,'archives':len(archives),'performance_observations':0}),flush=True)
