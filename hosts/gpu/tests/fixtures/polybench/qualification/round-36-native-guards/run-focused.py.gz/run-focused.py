import datetime,gzip,hashlib,importlib.util,json,os,pathlib,re,subprocess,time
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent;attempt=folder/'attempt-01';attempt.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
fp=b.compiler_fingerprint()
paths=sorted(set(subprocess.run(['git','ls-files','-mo','--exclude-standard'],capture_output=True,text=True,check=True).stdout.splitlines()))
source_paths=[p for p in paths if pathlib.Path(p).suffix in ('.rs','.toml') or pathlib.Path(p).name=='Cargo.lock']
for name in source_paths:
 target=attempt/'source'/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress((root/name).read_bytes(),mtime=0))
(attempt/'source.patch.gz').write_bytes(gzip.compress(subprocess.run(['git','diff','--binary'],capture_output=True,check=True).stdout,mtime=0))
checkpoint={'stage':'Focused native finite guards correctness build running; no performance observations','compiler_fingerprint':fp,'source_paths':source_paths,'accepted_round':31,'formal_history_entries':36,'live_exec_session':None,'pid':os.getpid(),'complete':False}
b.write(attempt/'source-checkpoint.json',checkpoint);b.write(folder/'current-work.json',checkpoint)
env=os.environ.copy();env['CARGO_TARGET_DIR']='/private/tmp/mech-polybench-pr1000-target';env['RUST_BACKTRACE']='1';env.pop('PERF_BUILDID_DIR',None)
argv=['cargo','test','--release','-p','mech-gpu','--no-default-features','--features','canonical-native-program','--lib','--','numeric_regions','numeric_binary','numeric_product','numeric_transpose','numeric_sum','native_runtime_consolidation_preserves_the_charged_layout_envelope','--test-threads=1','--nocapture']
start=time.monotonic()
with (attempt/'focused.log').open('w') as f:r=subprocess.run(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
log=(attempt/'focused.log').read_text();result={'command':argv,'exit_code':r.returncode,'wall_seconds':time.monotonic()-start,'compiler_fingerprint':fp,'passed_tests':[int(n) for n in re.findall(r'test result: ok[.] (\d+) passed',log)],'compiler_fingerprint_unchanged':b.compiler_fingerprint()==fp,'complete':True}
b.write(attempt/'focused-result.json',result);checkpoint.update(stage='Focused finite guards correctness completed' if r.returncode==0 else 'Focused finite guards correctness failed; inspect preserved attempt01',live_exec_session=None,complete=True,result=result);b.write(folder/'current-work.json',checkpoint)
print(json.dumps(result),flush=True)
raise SystemExit(r.returncode)
