import importlib.util,json,pathlib,subprocess
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
q=b.read(folder/'qualification-checks.json');checkpoint=b.read(folder/'attempt-01/source-checkpoint.json')
assert q['complete'] and q['driver_build_complete'] and q['tests']==700 and all(c['exit_code']==0 for c in q['checks'])
assert b.compiler_fingerprint()==q['compiler_fingerprint']==checkpoint['compiler_fingerprint']
assert b.digest(folder/'native-guards-driver')==q['driver_sha256']
q.update(versions={'ir':399,'work':156,'abi':47},source_parent=b.command(['git','rev-parse','HEAD']),source_uncommitted=True,dataset='MINI',numeric_profile='F64',new_performance_samples=0,source_sha256={path:b.digest(root/path) for path in checkpoint['source_paths']},driver_build=b.read(folder/'driver-build-result.json'))
b.write(folder/'qualification.json',q);b.write(folder/'source-checkpoint.json',checkpoint)
with (folder/'execution-emission-census.log').open('x') as log:
 subprocess.run(['python3',str(folder/'execution-emission-census.py')],stdout=log,stderr=subprocess.STDOUT,check=True)
assert not (folder/'training-probe.json').exists()
with (folder/'training-probe.log').open('x') as log:
 subprocess.run(['python3',str(folder/'training-probe.py')],stdout=log,stderr=subprocess.STDOUT,check=True)
print(json.dumps(b.read(folder/'training-probe.json')['summary']),flush=True)
