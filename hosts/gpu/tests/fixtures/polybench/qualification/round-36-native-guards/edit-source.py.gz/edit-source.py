from pathlib import Path
import subprocess
root=Path.cwd()
# Restore the exact single-operation payload and normal finish implementation.
p=root/'hosts/gpu/src/native_artifact/program/runtime/invocation/numeric_binary.rs'
s=subprocess.run(['git','show','f60baf055a39497400f9392e0294911becf1a697:'+str(p.relative_to(root))],capture_output=True,text=True,check=True).stdout
s=s.replace('fn fits(value:', 'pub(super) fn fits(value:').replace('fn cells(value:', 'pub(super) fn cells(value:')
s=s.replace('''        if tag == GlobalHelper::NumericBinaryFinish {
            return self.finish_numeric_binary(site, args);
        }
''','''        if tag == GlobalHelper::NumericBinaryFinish {
            if let Some(region) = self.numeric_region.take() {
                if self.numeric_binary.is_some() { return Err(invalid("overlapping matrix loans")); }
                return self.finish_numeric_region(site, args, region);
            }
            return self.finish_numeric_binary(site, args);
        }
        if args[2] == 1 { return self.prepare_numeric_region(site, args); }
''')
p.write_text(s)
p=root/'hosts/gpu/src/native_artifact/program/runtime/invocation/mod.rs';s=p.read_text().replace('''    pub(super) numeric_binary: Option<Box<numeric_binary::Pending>>,
''','''    pub(super) numeric_binary: Option<Box<numeric_binary::Pending>>,
    pub(super) numeric_region: Option<Box<numeric_regions::Region>>,
''');s=s.replace('''if self.numeric_binary.is_some() && tag != GlobalHelper::NumericBinaryFinish''','''if (self.numeric_binary.is_some() || self.numeric_region.is_some()) && tag != GlobalHelper::NumericBinaryFinish''');s=s.replace('''        if self.numeric_binary.is_some() {''','''        if self.numeric_binary.is_some() || self.numeric_region.is_some() {''');p.write_text(s)
p=root/'hosts/gpu/src/native_artifact/program/runtime/session/mod.rs';s=p.read_text().replace('''            numeric_binary: None,
''','''            numeric_binary: None,
            numeric_region: None,
''');p.write_text(s)
p=root/'hosts/gpu/src/native_artifact/program/runtime/invocation/caller_geometry/mod.rs';s=p.read_text().replace('''            || self.numeric_binary.is_some()
''','''            || self.numeric_binary.is_some()
            || self.numeric_region.is_some()
''');p.write_text(s)
p=root/'hosts/gpu/src/native_artifact/program/runtime/invocation/numeric_regions.rs';s=p.read_text().replace('use super::numeric_binary::{Pending, fits};','use super::numeric_binary::fits;').replace('NativeScalarKind, NativeScalarOp,','NativeScalarKind,')
a=s.index('// Bounds concern eligibility');z=s.index("impl Invocation<'_, '_, '_>",a);s=s[:a]+'''// Generated kernels check each produced result before a dependent operation.
// A nonfinite result cancels this private loan and replays original execution;
// no host payload scan or floating-point reassociation grants eligibility.
'''+s[z:]
s=s.replace('''            || self.numeric_binary.is_some()
''','''            || self.numeric_binary.is_some()
            || self.numeric_region.is_some()
''')
s=s.replace('''                            + core::mem::size_of::<Magnitude>()
''','')
s=s.replace('''(core::mem::size_of::<External>() + core::mem::size_of::<Magnitude>())
                            as u64''','''core::mem::size_of::<External>() as u64''')
a=s.index('''        let mut bounds = Vec::with_capacity(arity);''');z=s.index('''        let mut scratch_count = 0usize;''',a)
s=s[:a]+'''        for capture in &external {
            // Full original source funding precedes recursive canonical
            // validation. Kernel result checks replace all magnitude scans.
            if let Some(value) = &capture.value {
                if value.validate_against(&m.schemas).is_err() { return Ok(Some(0)); }
            }
        }
'''+s[z:]
s=s.replace('''self.numeric_binary = Some(Box::new(Pending::Region(region)));''','''self.numeric_region = Some(Box::new(region));''')
s=s.replace('''        pending: Box<Pending>,
    ) -> Result<Option<u64>, Error> {
        let Pending::Region(mut region) = *pending else {
            return Err(invalid("matrix region finish has individual loan"));
        };''','''        mut region: Box<Region>,
    ) -> Result<Option<u64>, Error> {''')
s=s.replace('''            || self.state.consumed
            || args != [region.frames.as_ptr() as u64, region.frames.len() as u64, 1]
''','''            || self.state.consumed
            || self.state.control.current.is_some()
            || self.numeric_binary.is_some()
            || !matches!(args[2], 1 | 2)
            || args[..2] != [region.frames.as_ptr() as u64, region.frames.len() as u64]
''')
needle='''        for (index, step) in steps.iter().enumerate() {'''
s=s.replace(needle,'''        if args[2] == 2 {
            // The generated caller abandoned a nonfinite private result.
            // No logical producer, visit or output has been settled yet.
            // Dropping the same issued loan releases every view and claim;
            // the original source entry remains fresh for ordinary replay.
            return Ok(Some(0));
        }
'''+needle,1)
p.write_text(s)
# Conditional finite-result guards are emission-only; None emits no instructions.
p=root/'hosts/gpu/src/native_artifact/program/codegen/numeric_binary.rs';s=p.read_text().replace('condcodes::IntCC','condcodes::{IntCC, FloatCC}')
anchor='''fn scalar_at('''
helper='''/// Check a just-produced F64 scalar/SIMD result before its store or use.
/// Ordinary single kernels pass None, retaining their exact original code.
pub(super) fn finite_result(b: &mut FunctionBuilder<'_>, value: Value, cancel: Option<Block>) {
    let Some(cancel) = cancel else { return; };
    let ty = b.func.dfg.value_type(value);
    let limit = b.ins().f64const(f64::MAX);
    let limit = if ty.is_vector() { b.ins().splat(ty, limit) } else { limit };
    let magnitude = b.ins().fabs(value);
    let finite = b.ins().fcmp(FloatCC::LessThanOrEqual, magnitude, limit);
    let finite = if ty.is_vector() { b.ins().vall_true(finite) } else { finite };
    let valid = b.create_block();
    b.ins().brif(finite, valid, &[], cancel, &[]);
    b.switch_to_block(valid);
}
'''
s=s.replace(anchor,helper+anchor,1)
s=s.replace('''    right_scalar: bool,
    done: Block,''','''    right_scalar: bool,
    cancel: Option<Block>,
    done: Block,''')
s=s.replace('''    let next = f64_arithmetic(b, op, a, c);
    let p = address''','''    let next = f64_arithmetic(b, op, a, c);
    finite_result(b, next, cancel);
    let p = address''')
s=s.replace('''let count = emit_kernel(b, op.kind, frame, [false; 2], error);''','''let count = emit_kernel(b, op.kind, frame, [false; 2], None, error);''')
s=s.replace('''    bank_inputs: [bool; 2],
    error: Block,''','''    bank_inputs: [bool; 2],
    cancel: Option<Block>,
    error: Block,''')
s=s.replace('''                input_columns,
                complete,''','''                input_columns,
                cancel,
                complete,''')
s=s.replace('''super::numeric_sum::emit(b, left, output, outputs, inner, axis, complete);''','''super::numeric_sum::emit(b, left, output, outputs, inner, axis, cancel, complete);''')
s=s.replace('''super::numeric_product::emit(b, left, right, output, count, columns, inner, complete);''','''super::numeric_product::emit(b, left, right, output, count, columns, inner, cancel, complete);''')
s=s.replace('''b, op, left, right, sleft, sright, output, count, scalar, rscalar, complete,''','''b, op, left, right, sleft, sright, output, count, scalar, rscalar, cancel, complete,''')
s=s.replace('''            let next = f64_arithmetic(b, op, a, c);
            let p = address''','''            let next = f64_arithmetic(b, op, a, c);
            finite_result(b, next, cancel);
            let p = address''')
p.write_text(s)
for name in ['numeric_product','numeric_sum']:
 p=root/f'hosts/gpu/src/native_artifact/program/codegen/{name}.rs';s=p.read_text().replace('use super::numeric_binary::address;','use super::numeric_binary::{address, finite_result};')
 s=s.replace('''    vector: bool,
) {''','''    vector: bool,
    cancel: Option<Block>,
) {''')
 s=s.replace('''    let result = b.use_var(accumulator);''','''    let result = b.use_var(accumulator);
    finite_result(b, result, cancel);''').replace('''    let result = b.use_var(sum);''','''    let result = b.use_var(sum);
    finite_result(b, result, cancel);''')
 s=s.replace('''    done: Block,
) {''','''    cancel: Option<Block>,
    done: Block,
) {''')
 s=s.replace('''cell(b, left, right, output, at, columns, inner, vector);''','''cell(b, left, right, output, at, columns, inner, vector, cancel);''').replace('''cell(b, input, output, at, count, inner, axis, vector);''','''cell(b, input, output, at, count, inner, axis, vector, cancel);''')
 p.write_text(s)
p=root/'hosts/gpu/src/native_artifact/program/codegen/numeric_transpose.rs';s=p.read_text().replace('use super::numeric_binary::address;','use super::numeric_binary::{address, finite_result};').replace('''    done: Block,''','''    cancel: Option<Block>,
    done: Block,''')
s=s.replace('''    b.ins().store(MemFlags::new(), word, to, 0);''','''    if cancel.is_some() {
        let value = b.ins().bitcast(types::F64, MemFlags::new(), word);
        finite_result(b, value, cancel);
    }
    b.ins().store(MemFlags::new(), word, to, 0);''');p.write_text(s)
p=root/'hosts/gpu/src/native_artifact/program/codegen/numeric_generator_arrays.rs';s=p.read_text();a=s.index('super::super::numeric_transpose::emit(');z=s.index(');',a);part=s[a:z];part=part.replace('''        complete,''','''        None,
        complete,''') if '        complete,' in part else part
# Existing generator transpose has its own done block, inspect actual last argument.
lines=part.splitlines();lines.insert(len(lines)-1,'        None,') if lines[-1].strip().endswith(',') and 'None,' not in part else None
s=s[:a]+'\n'.join(lines)+s[z:];p.write_text(s)
p=root/'hosts/gpu/src/native_artifact/program/codegen/numeric_regions.rs';s=p.read_text().replace('''    let ordinary = b.create_block();''','''    let ordinary = b.create_block();
    let cancelled = b.create_block();''',1)
s=s.replace('''super::numeric_binary::emit_kernel(b, *kind, frame, bank_inputs, error);''','''super::numeric_binary::emit_kernel(b, *kind, frame, bank_inputs, Some(cancelled), error);''')
s=s.replace('''    b.ins().jump(target, &[]);
    b.switch_to_block(ordinary);''','''    b.ins().jump(target, &[]);
    b.switch_to_block(cancelled);
    let count = b.ins().iconst(types::I64, candidate.storage_slots.len() as i64);
    let mode = b.ins().iconst(types::I64, 2);
    hooks.call(b, site, GlobalHelper::NumericBinaryFinish, [frames, count, mode], error);
    let ready = b.ins().load(types::I64, MemFlags::new(), hooks.result, 0);
    let valid = b.ins().icmp_imm(IntCC::Equal, ready, 0);
    guard(b, valid, error, crate::native_artifact::abi::STATUS_INTEGRITY);
    b.ins().jump(ordinary, &[]);
    b.switch_to_block(ordinary);''');p.write_text(s)
p=root/'hosts/gpu/src/native_artifact/program/image/identity.rs';s=p.read_text().replace('= 398;', '= 399;');p.write_text(s)
