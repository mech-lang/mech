from pathlib import Path
root=Path.cwd()
p=root/'hosts/gpu/src/native_artifact/program/codegen/numeric_generator_arrays.rs'
s=p.read_text();old='''        input_columns,
        done,
''';assert s.count(old)==1;s=s.replace(old,'''        input_columns,
        None,
        done,
''');p.write_text(s)
p=root/'hosts/gpu/src/native_artifact/program/runtime/composition_tests/observe.rs';s=p.read_text();s=s.replace('''    pub matrix_region_completions: u64,
''','''    pub matrix_region_completions: u64,
    pub matrix_region_cancellations: u64,
''',1)
needle='''    // SAFETY: unchanged arguments and result pointer from the checked entry.
    let status = unsafe { HELPER.with(Cell::get).unwrap()(context, site, op, a, b, c, out) };'''
assert s.count(needle)==1
s=s.replace(needle,'''    let cancellation = (op == GlobalHelper::NumericBinaryFinish.raw() && c == 2).then(|| {
        // Observe the real private loan before its release; no source cursor
        // or producer may have been committed by speculative native arithmetic.
        let invocation = unsafe { &*context.cast::<Invocation<'_, '_, '_>>() };
        (
            invocation.state.control.visits,
            invocation.state.control.previous,
            invocation.state.control.current,
            invocation.state.consumed,
            invocation.state.control.work.used(),
            invocation.state.library.used(),
            invocation.state.library.memory_budget().used_bytes(),
            invocation.state.library.memory_budget().retained_nodes(),
        )
    });
'''+needle)
needle='''    if op == GlobalHelper::NumericBinaryFinish.raw() && c == 1 && status == 0 {'''
assert s.count(needle)==1
s=s.replace(needle,'''    if let Some(before) = cancellation
        && status == 0
    {
        let invocation = unsafe { &*context.cast::<Invocation<'_, '_, '_>>() };
        assert_eq!(unsafe { *out }, 0);
        assert_eq!(
            (
                invocation.state.control.visits,
                invocation.state.control.previous,
                invocation.state.control.current,
                invocation.state.consumed,
                invocation.state.control.work.used(),
                invocation.state.library.used(),
            ),
            (before.0, before.1, before.2, before.3, before.4, before.5),
            "cancel must leave all logical source execution untouched"
        );
        assert!(invocation.numeric_binary.is_none() && invocation.numeric_region.is_none());
        let memory = invocation.state.library.memory_budget();
        assert!(memory.used_bytes() < before.6 && memory.retained_nodes() < before.7);
        COUNTS.with(|v| v.borrow_mut().matrix_region_cancellations += 1);
    }
'''+needle)
p.write_text(s)
p=root/'hosts/gpu/src/native_artifact/program/runtime/composition_tests/numeric_regions.rs';s=p.read_text()
s=s.replace('''    selected: bool,
) {
''','''    selected: bool,
) -> [u64; 2] {
''',1)
s=s.replace('''    let baseline = (memory.used_bytes(), memory.retained_nodes());
    for restored in [false, true] {''','''    let baseline = (memory.used_bytes(), memory.retained_nodes());
    let mut cancellations = [0; 2];
    for restored in [false, true] {''',1)
s=s.replace('''        assert_eq!(contents(&args), before);
        drop(actual);''','''        cancellations[usize::from(restored)] = counts.matrix_region_cancellations;
        assert_eq!(contents(&args), before);
        drop(actual);''',1)
s=s.replace('''    assert_eq!((memory.used_bytes(), memory.retained_nodes()), (0, 0));
}
fn compiled_pair''','''    assert_eq!((memory.used_bytes(), memory.retained_nodes()), (0, 0));
    cancellations
}
fn compiled_pair''',1)
s=s.replace('''fn numeric_regions_nonfinite_and_overflow_bounds_decline_to_maintained_kernels()''','''fn numeric_regions_nonfinite_results_cancel_to_maintained_kernels()''')
s=s.replace('''                divisor == 2.0 || divisor == -0.25,
''','''                divisor == 2.0 || divisor == -0.25 || divisor.is_infinite(),
''',1)
s=s.replace('''        if op == GlobalHelper::NumericBinaryFinish.raw() && c == 1 {''','''        if op == GlobalHelper::NumericBinaryFinish.raw() && matches!(c, 1 | 2) {''',1)
s=s.replace('''                14 => site += 1,
''','''                14 => site += 1,
                15 => invocation.state.control.current = Some(site as u32),
                16 => c = 3,
''',1)
s=s.replace('''                for case in 0..=14 {''','''                for case in 0..=16 {''',1)
# Use both a successful native loan and a genuine native-result cancellation.
s=s.replace('''            let args = numeric_maps::typed_arguments(
                &artifact,
                &memory,
                &[
                    ("left", matrix(&[1.0, 2.0, 3.0]), &[1, 3]),
                    ("right", matrix(&[0.5]), &[1, 1]),''','''            for left in [1.0, f64::INFINITY] {
            let args = numeric_maps::typed_arguments(
                &artifact,
                &memory,
                &[
                    ("left", matrix(&[left, 2.0, 3.0]), &[1, 3]),
                    ("right", matrix(&[0.5]), &[1, 1]),''',1)
needle='''            drop((prior, args));
            assert_eq!((memory.used_bytes(), memory.retained_nodes()), (0, 0));
        }
    }
}
'''
assert s.count(needle)==1;s=s.replace(needle,'''            drop((prior, args));
            assert_eq!((memory.used_bytes(), memory.retained_nodes()), (0, 0));
            }
        }
    }
}
''',1)
s += '''

#[test]
fn numeric_regions_native_result_checks_cancel_both_simd_lanes_tail_and_later_operator() {
    let source = "a := left<[f64]> + right<[f64]>\\nb := a * gain<f64>\\nb - left<[f64]>\\n";
    for artifact in artifacts(source) {
        let (native, individual) = compiled_pair(&artifact);
        for at in 0..3 {
            for bad in [f64::INFINITY, f64::from_bits(0xfff8000000000037), f64::from_bits(0x7ff0000000000042)] {
                let mut left = [1.0, -0.0, 0.5];
                left[at] = bad;
                let cancellations = compare_current_execution(
                    source, &artifact, &native, &individual,
                    &[("left",matrix(&left),&[1,3]), ("right",matrix(&[0.5]),&[1,1]),
                      ("gain",Data::F64(mech_core::snapshot::F64Bits::from_f64(2.0)),&[])], false);
                assert_eq!(cancellations,[1,1]);
            }
            let mut left = [1.0, -0.0, 0.5];
            left[at] = f64::MAX / 2.0;
            let cancellations = compare_current_execution(
                source, &artifact, &native, &individual,
                &[("left",matrix(&left),&[1,3]), ("right",matrix(&[0.5]),&[1,1]),
                  ("gain",Data::F64(mech_core::snapshot::F64Bits::from_f64(4.0)),&[])], false);
            assert_eq!(cancellations,[1,1],"second operator overflow must release the entire loan");
        }
    }
}

#[test]
fn numeric_regions_finite_cancellation_and_computed_divisors_need_no_magnitude_proof() {
    for source in [
        "a := left<[f64]> + right<[f64]>\\nb := a * 2.0\\nb + right<[f64]>\\n",
        "a := left<[f64]> + right<[f64]>\\nb := right / a\\nb * 2.0\\n",
    ] {
        for artifact in artifacts(source) {
            let (native, individual) = compiled_pair(&artifact);
            let cancellations = compare_current_execution(
                source,&artifact,&native,&individual,
                &[("left",matrix(&[f64::MAX/4.0,-0.0,f64::from_bits(1)]),&[1,3]),
                  ("right",matrix(&[-f64::MAX/8.0,-1.0,f64::from_bits(1)]),&[1,3])],true);
            assert_eq!(cancellations,[0,0]);
        }
    }
}

#[test]
fn numeric_regions_transpose_sum_and_product_nonfinite_results_replay_exact_bits() {
    let cases: &[(&str,&str,&[f64],&[u64])] = &[
        ("a := input<[f64]>'\\nb := a * 2.0\\nb + a\\n","input",&[1.0,f64::INFINITY,-0.0],&[1,3]),
        ("+> stats\\na := stats/sum/row(input<[f64]>)\\nb := a * 2.0\\nb + a\\n","input",&[f64::MAX,f64::MAX,-0.0,1.0],&[2,2]),
        ("a := input<[f64]> ** input<[f64]>\\nb := a * 2.0\\nb + a\\n","input",&[f64::MAX,0.0,0.0,1.0],&[2,2]),
    ];
    for &(source,name,values,dimensions) in cases {
        for artifact in artifacts(source) {
            let (native, individual) = compiled_pair(&artifact);
            let cancellations=compare_current_execution(source,&artifact,&native,&individual,&[(name,matrix(values),dimensions)],false);
            assert_eq!(cancellations,[1,1]);
        }
    }
}
'''
p.write_text(s)
# Record the actual payload and previous enum layouts, keeping production types unchanged.
p=root/'hosts/gpu/src/native_artifact/program/runtime/invocation/mod.rs';s=p.read_text();s+='''

#[cfg(test)]
pub(super) fn matrix_loan_layouts() -> (usize, usize, usize, usize) {
    #[allow(dead_code)]
    enum PreviousCombinedLoan {
        Single(numeric_binary::Pending),
        Region(numeric_regions::Region),
    }
    (
        core::mem::size_of::<numeric_binary::Pending>(),
        core::mem::size_of::<numeric_regions::Region>(),
        core::mem::size_of::<PreviousCombinedLoan>(),
        core::mem::size_of::<Option<Box<numeric_regions::Region>>>(),
    )
}
''';p.write_text(s)
p=root/'hosts/gpu/src/native_artifact/program/runtime/mod.rs';s=p.read_text();s=s.replace('''    eprintln!("native-layout: persistent={persistent} invocation={invocation}");''','''    eprintln!("native-layout: persistent={persistent} invocation={invocation}");
    let (single, region, previous, optional_region) = invocation::matrix_loan_layouts();
    eprintln!("matrix-loan-layout: single={single} region={region} previous-combined={previous} optional-region={optional_region}");
    assert_eq!(optional_region, core::mem::size_of::<usize>());
    assert!(single <= previous);''');p.write_text(s)
print('Qualified source edits prepared')
