use super::*;
use crate::snapshot::SequenceView;
use crate::{DimensionExpr, IntegerInterval, SchemaDraft, SchemaTableBuilder};

fn replacement_schema(width: IntegerWidth) -> (SchemaId, Arc<SchemaTable>) {
    use crate::{
        DimensionLifetime, DimensionParameterDeclaration, DimensionParameterId,
        DimensionParameterOrigin,
    };
    let mut builder = SchemaTableBuilder::new();
    let handle = builder
        .insert(
            SchemaDraft {
                body: SchemaBody::Matrix {
                    element: Box::new(SchemaBody::UnsignedInteger(width)),
                    dimensions: [
                        DimensionExpr::Constant(1),
                        DimensionExpr::Parameter(DimensionParameterId::new(0)),
                    ]
                    .into(),
                },
                dimension_parameters: [DimensionParameterDeclaration {
                    id: DimensionParameterId::new(0),
                    origin: DimensionParameterOrigin::Explicit,
                    lifetime: DimensionLifetime::Activation,
                    lower_bound: DimensionExpr::Constant(0),
                    upper_bound: None,
                }]
                .into(),
            }
            .finalize()
            .unwrap(),
        )
        .unwrap();
    let build = builder.finish().unwrap();
    (build.resolve(handle).unwrap(), Arc::new(build.table))
}

fn replacement_buffer(width: IntegerWidth, words: &[u64], capacity: usize) -> UnsignedMatrixBuffer {
    macro_rules! buffer {
        ($variant:ident, $ty:ty) => {{
            let mut buffer = Vec::with_capacity(capacity);
            buffer.extend(words.iter().map(|word| <$ty>::try_from(*word).unwrap()));
            UnsignedMatrixBuffer::$variant(buffer)
        }};
    }
    match width {
        IntegerWidth::W8 => buffer!(U8, u8),
        IntegerWidth::W16 => buffer!(U16, u16),
        IntegerWidth::W32 => buffer!(U32, u32),
        IntegerWidth::W64 => buffer!(U64, u64),
        _ => panic!("test requires packed unsigned storage"),
    }
}

fn replacement_pointer(words: SequenceView<'_>) -> usize {
    match words {
        SequenceView::U8(words) => words.as_ptr() as usize,
        SequenceView::U16(words) => words.as_ptr() as usize,
        SequenceView::U32(words) => words.as_ptr() as usize,
        SequenceView::U64(words) => words.as_ptr() as usize,
        _ => panic!("test requires packed unsigned storage"),
    }
}

#[test]
fn unsigned_reconstruction_shares_shape_without_sharing_changed_data_identity() {
    for width in [
        IntegerWidth::W8,
        IntegerWidth::W16,
        IntegerWidth::W32,
        IntegerWidth::W64,
    ] {
        for count in [0, 1, 4] {
            let (id, table) = replacement_schema(width);
            let shape = table
                .get(id)
                .unwrap()
                .instantiate_shape([count as u64].into())
                .unwrap();
            let source = Value::from_unsigned_matrix_buffer(
                id,
                shape,
                replacement_buffer(width, &[1, 2, 3, 4][..count], 17),
                table.clone(),
            )
            .unwrap();
            let alias = source.clone();
            let identity = source.frozen_storage_identity();
            let prior = source.canonical_data_draft().unwrap();
            let constructor = source
                .unsigned_matrix_replacement_constructor(table.clone())
                .unwrap();
            let words = &[9, 8, 7, 6][..count];
            let ordinary = Value::from_unsigned_matrix_buffer(
                id,
                source.shape().clone(),
                replacement_buffer(width, words, 17),
                table.clone(),
            )
            .unwrap();
            let buffer = replacement_buffer(width, words, 17);
            let pointer = replacement_pointer(buffer.elements());
            let actual = constructor.finish(buffer).unwrap();
            assert!(core::ptr::eq(source.shape(), actual.shape()));
            assert!(!core::ptr::eq(source.shape(), ordinary.shape()));
            assert_eq!(actual.schema(), source.schema());
            assert_eq!(actual.schema_key(), source.schema_key());
            assert_eq!(actual.shape(), ordinary.shape());
            assert_eq!(
                actual.canonical_data_draft().unwrap(),
                ordinary.canonical_data_draft().unwrap()
            );
            assert_eq!(
                actual.value_hash(&table).unwrap(),
                ordinary.value_hash(&table).unwrap()
            );
            assert_eq!(
                actual.retained_footprint(&table).unwrap(),
                ordinary.retained_footprint(&table).unwrap()
            );
            assert!(identity.matches(&alias));
            assert!(!identity.matches(&actual));
            assert!(!actual.shares_frozen_storage(&source));
            assert_eq!(alias.canonical_data_draft().unwrap(), prior);
            let ValueData::Matrix(matrix) = actual.data() else {
                panic!("matrix")
            };
            assert_eq!(replacement_pointer(matrix.elements()), pointer);
            assert_eq!(matrix.unsigned_buffer_capacity(), Some(17));
        }
    }
}

#[test]
fn unsigned_reconstruction_preserves_kind_cardinality_arena_errors_and_retry() {
    let (id, table) = replacement_schema(IntegerWidth::W32);
    let source = Value::from_unsigned_matrix_buffer(
        id,
        table
            .get(id)
            .unwrap()
            .instantiate_shape([3].into())
            .unwrap(),
        replacement_buffer(IntegerWidth::W32, &[1, 2, 3], 17),
        table.clone(),
    )
    .unwrap();
    let prior = source.canonical_data_draft().unwrap();
    let identity = source.frozen_storage_identity();
    let (foreign_id, foreign) = replacement_schema(IntegerWidth::W64);
    assert_eq!(
        id, foreign_id,
        "numeric ID alone must not admit a foreign arena"
    );
    assert!(matches!(
        source.unsigned_matrix_replacement_constructor(foreign),
        Err(SnapshotValueError::SnapshotSchemaTableMismatch { .. })
    ));
    for (width, count) in [
        (IntegerWidth::W32, 2),
        (IntegerWidth::W32, 4),
        (IntegerWidth::W16, 3),
    ] {
        let actual = source
            .unsigned_matrix_replacement_constructor(table.clone())
            .unwrap()
            .finish(replacement_buffer(width, &[7, 8, 9, 10][..count], 17));
        let expected = Value::from_unsigned_matrix_buffer(
            id,
            source.shape().clone(),
            replacement_buffer(width, &[7, 8, 9, 10][..count], 17),
            table.clone(),
        );
        assert_eq!(actual.unwrap_err(), expected.unwrap_err());
        assert!(identity.matches(&source));
        assert_eq!(source.canonical_data_draft().unwrap(), prior);
    }
    let actual = source
        .unsigned_matrix_replacement_constructor(table)
        .unwrap()
        .finish(replacement_buffer(IntegerWidth::W32, &[7, 8, 9], 17))
        .unwrap();
    assert!(core::ptr::eq(source.shape(), actual.shape()));
    assert!(!identity.matches(&actual));
    let (id, shape, table) = schema(SchemaBody::SignedInteger(IntegerWidth::W32), 1, 1);
    let signed = Value::from_i32_matrix(id, shape, [1].into(), table.clone()).unwrap();
    assert!(matches!(
        signed.unsigned_matrix_replacement_constructor(table),
        Err(SnapshotValueError::SnapshotSchemaDefinitionMismatch { .. })
    ));
}

#[test]
fn unsigned_reconstruction_keeps_exclusive_handoff_finite_admission_and_recovery() {
    let (id, table) = replacement_schema(IntegerWidth::W64);
    let raw = Value::from_unsigned_matrix_buffer(
        id,
        table
            .get(id)
            .unwrap()
            .instantiate_shape([3].into())
            .unwrap(),
        replacement_buffer(IntegerWidth::W64, &[1, 2, 3], 32),
        table.clone(),
    )
    .unwrap();
    let memory = crate::ManagedMemoryBudget::new(16 * 1024 * 1024);
    let mut charge = memory
        .reserve_capacity(raw.memory_budget_admission_bytes(&memory).unwrap())
        .unwrap();
    let source = raw.into_memory_budget(&mut charge).unwrap();
    drop(charge);
    let retained = (memory.used_bytes(), memory.retained_snapshot_nodes());
    let shape = source.shape.clone();
    let identity = source.frozen_storage_identity();
    let constructor = source
        .unsigned_matrix_replacement_constructor(table)
        .unwrap();
    let ValueData::Matrix(matrix) = source.data() else {
        panic!("matrix")
    };
    let pointer = replacement_pointer(matrix.elements());
    let super::super::UnsignedMatrixOwnershipTransfer::Owned(owned) =
        source.try_into_owned_unsigned_matrix(&memory).unwrap()
    else {
        panic!("retaining immutable shape must not retain source data/root")
    };
    let (mut buffer, mut admission) = owned.into_parts();
    assert_eq!(replacement_pointer(buffer.elements()), pointer);
    let UnsignedMatrixBuffer::U64(words) = &mut buffer else {
        panic!("u64")
    };
    words[1] = 99;
    let result = constructor.finish(buffer).unwrap();
    assert!(Arc::ptr_eq(&result.shape, &shape));
    assert!(!identity.matches(&result));
    let required = result.memory_budget_admission_bytes(&memory).unwrap();
    assert!(admission.capacity_bytes() >= required);
    let mut short = memory.reserve_capacity(required - 1).unwrap();
    let before = (memory.used_bytes(), memory.retained_snapshot_nodes());
    let value_identity = result.frozen_storage_identity();
    assert!(result.clone().into_memory_budget(&mut short).is_err());
    assert_eq!(
        (memory.used_bytes(), memory.retained_snapshot_nodes()),
        before
    );
    assert!(value_identity.matches(&result));
    drop(short);
    let result = result.into_memory_budget(&mut admission).unwrap();
    drop(admission);
    assert_eq!(
        (memory.used_bytes(), memory.retained_snapshot_nodes()),
        retained
    );
    let ValueData::Matrix(matrix) = result.data() else {
        panic!("matrix")
    };
    assert_eq!(replacement_pointer(matrix.elements()), pointer);
    let SequenceView::U64(words) = matrix.elements() else {
        panic!("u64")
    };
    assert_eq!(words, &[1, 99, 3]);
    drop((result, identity, value_identity, shape));
    assert_eq!(
        (memory.used_bytes(), memory.retained_snapshot_nodes()),
        (0, 0)
    );
}

fn schema(
    element: SchemaBody,
    rows: u64,
    columns: u64,
) -> (SchemaId, ShapeInstance, Arc<SchemaTable>) {
    let mut builder = SchemaTableBuilder::new();
    let handle = builder
        .insert(
            SchemaDraft {
                body: SchemaBody::Matrix {
                    element: Box::new(element),
                    dimensions: [
                        DimensionExpr::Constant(rows),
                        DimensionExpr::Constant(columns),
                    ]
                    .into(),
                },
                dimension_parameters: Box::new([]),
            }
            .finalize()
            .unwrap(),
        )
        .unwrap();
    let build = builder.finish().unwrap();
    let id = build.resolve(handle).unwrap();
    let schemas = Arc::new(build.table);
    let shape = schemas
        .get(id)
        .unwrap()
        .instantiate_shape(Box::new([]))
        .unwrap();
    (id, shape, schemas)
}

fn ordinary(
    id: SchemaId,
    cells: Box<[ValueDataDraft]>,
    schemas: &Arc<SchemaTable>,
) -> Result<Value, SnapshotValueError> {
    ValueDraft {
        schema: id,
        shape_values: Box::new([]),
        data: ValueDataDraft::Matrix(cells),
    }
    .finalize(&SnapshotValidationContext::with_shared_schemas(schemas))
}

#[test]
fn numeric_matrix_constructors_transfer_all_fourteen_buffers_with_exact_canonical_values() {
    macro_rules! check {
        ($constructor:ident, $variant:ident, $body:expr, $values:expr) => {{
            let all = $values;
            for count in [0, 1, 4] {
                let values = all[..count].to_vec().into_boxed_slice();
                let expected_cells = values
                    .iter()
                    .copied()
                    .map(ValueDataDraft::$variant)
                    .collect();
                let pointer = values.as_ptr();
                let (id, shape, schemas) = schema(
                    $body,
                    if count == 4 { 2 } else { 1 },
                    if count == 4 { 2 } else { count as u64 },
                );
                let expected = ordinary(id, expected_cells, &schemas).unwrap();
                let actual = Value::$constructor(id, shape, values, Arc::clone(&schemas)).unwrap();
                assert_eq!(actual.schema_key(), expected.schema_key());
                assert_eq!(actual.shape(), expected.shape());
                assert_eq!(
                    actual.canonical_data_draft().unwrap(),
                    expected.canonical_data_draft().unwrap()
                );
                assert_eq!(
                    actual.value_hash(&schemas).unwrap(),
                    expected.value_hash(&schemas).unwrap()
                );
                assert_eq!(
                    actual.retained_footprint(&schemas).unwrap(),
                    expected.retained_footprint(&schemas).unwrap()
                );
                let ValueData::Matrix(matrix) = actual.data() else {
                    panic!("Matrix")
                };
                let SequenceView::$variant(values) = matrix.elements() else {
                    panic!("exact packed kind")
                };
                assert_eq!(
                    values.as_ptr(),
                    pointer,
                    "no payload clone or repacking allocation"
                );
                actual.validate_against(&schemas).unwrap();
            }
        }};
    }
    macro_rules! integer {
        ($constructor:ident, $variant:ident, $kind:ident, $width:ident, $ty:ty) => {
            check!(
                $constructor,
                $variant,
                SchemaBody::$kind(IntegerWidth::$width),
                [<$ty>::MIN, 0, 1, <$ty>::MAX]
            );
        };
    }
    check!(
        from_bool_matrix,
        Bool,
        SchemaBody::Bool,
        [false, true, true, false]
    );
    integer!(from_u8_matrix, U8, UnsignedInteger, W8, u8);
    integer!(from_u16_matrix, U16, UnsignedInteger, W16, u16);
    integer!(from_u32_matrix, U32, UnsignedInteger, W32, u32);
    integer!(from_u64_matrix, U64, UnsignedInteger, W64, u64);
    integer!(from_u128_matrix, U128, UnsignedInteger, W128, u128);
    integer!(from_i8_matrix, I8, SignedInteger, W8, i8);
    integer!(from_i16_matrix, I16, SignedInteger, W16, i16);
    integer!(from_i32_matrix, I32, SignedInteger, W32, i32);
    integer!(from_i64_matrix, I64, SignedInteger, W64, i64);
    integer!(from_i128_matrix, I128, SignedInteger, W128, i128);
    check!(
        from_index_matrix,
        Index,
        SchemaBody::Index,
        [1, 2, u64::MAX - 1, u64::MAX]
    );
    check!(
        from_f32_matrix,
        F32,
        SchemaBody::FloatingPoint(FloatWidth::W32),
        [0, 0x8000_0000, 0x7fc0_0001, 0xff80_0000].map(F32Bits::from_bits)
    );
    check!(
        from_f64_matrix,
        F64,
        SchemaBody::FloatingPoint(FloatWidth::W64),
        [
            0,
            0x8000_0000_0000_0000,
            0x7ff8_0000_0000_0001,
            0xfff0_0000_0000_0000
        ]
        .map(F64Bits::from_bits)
    );
}

#[test]
fn numeric_matrix_cardinality_and_index_errors_match_ordinary_finalization() {
    let (id, shape, schemas) = schema(SchemaBody::Bool, 2, 2);
    for count in [0, 3, 5] {
        let values = vec![true; count];
        let expected = ordinary(
            id,
            values.iter().copied().map(ValueDataDraft::Bool).collect(),
            &schemas,
        )
        .unwrap_err();
        let actual =
            Value::from_bool_matrix(id, shape.clone(), values.into(), schemas.clone()).unwrap_err();
        assert_eq!(actual, expected);
    }
    for element in [
        SchemaBody::UnsignedInteger(IntegerWidth::W64),
        SchemaBody::Index,
    ] {
        let (id, shape, schemas) = schema(element.clone(), 2, 2);
        for values in [vec![], vec![1, 0, 3], vec![1, 0, 3, 4], vec![1, 2, 3, 4, 5]] {
            let index = element == SchemaBody::Index;
            if !index && values.len() == 4 {
                continue;
            }
            let expected = ordinary(
                id,
                values
                    .iter()
                    .copied()
                    .map(|n| {
                        if index {
                            ValueDataDraft::Index(n)
                        } else {
                            ValueDataDraft::U64(n)
                        }
                    })
                    .collect(),
                &schemas,
            )
            .unwrap_err();
            let actual = if index {
                Value::from_index_matrix(id, shape.clone(), values.into(), Arc::clone(&schemas))
            } else {
                Value::from_u64_matrix(id, shape.clone(), values.into(), Arc::clone(&schemas))
            }
            .unwrap_err();
            assert_eq!(actual, expected);
        }
    }
}

#[test]
fn typed_numeric_matrix_checks_kinds_constraints_and_parameter_shapes() {
    for element in [
        SchemaBody::Bool,
        SchemaBody::UnsignedInteger(IntegerWidth::W8),
        SchemaBody::String,
        SchemaBody::IntegerInterval(IntegerInterval::Unsigned {
            width: IntegerWidth::W64,
            lower: 1,
            upper: 2,
            upper_inclusive: true,
        }),
    ] {
        let (id, shape, schemas) = schema(element, 1, 2);
        assert!(matches!(
            Value::from_u64_matrix(id, shape, [1, 2].into(), Arc::clone(&schemas)),
            Err(SnapshotValueError::SnapshotSchemaDefinitionMismatch { .. })
        ));
    }
    let (id, shape, schemas) = schema(SchemaBody::UnsignedInteger(IntegerWidth::W8), 1, 2);
    assert!(matches!(
        Value::from_bool_matrix(id, shape, [false, true].into(), schemas),
        Err(SnapshotValueError::SnapshotSchemaDefinitionMismatch { .. })
    ));
    use crate::{
        DimensionLifetime, DimensionParameterDeclaration, DimensionParameterId,
        DimensionParameterOrigin,
    };
    let mut builder = SchemaTableBuilder::new();
    let handle = builder
        .insert(
            SchemaDraft {
                body: SchemaBody::Matrix {
                    element: Box::new(SchemaBody::UnsignedInteger(IntegerWidth::W64)),
                    dimensions: [
                        DimensionExpr::Constant(1),
                        DimensionExpr::Parameter(DimensionParameterId::new(0)),
                    ]
                    .into(),
                },
                dimension_parameters: [DimensionParameterDeclaration {
                    id: DimensionParameterId::new(0),
                    origin: DimensionParameterOrigin::Explicit,
                    lifetime: DimensionLifetime::Activation,
                    lower_bound: DimensionExpr::Constant(1),
                    upper_bound: Some(DimensionExpr::Constant(8)),
                }]
                .into(),
            }
            .finalize()
            .unwrap(),
        )
        .unwrap();
    let built = builder.finish().unwrap();
    let dynamic_id = built.resolve(handle).unwrap();
    let dynamic_schemas = Arc::new(built.table);
    let dynamic_shape = dynamic_schemas
        .get(dynamic_id)
        .unwrap()
        .instantiate_shape([2].into())
        .unwrap();
    let actual = Value::from_u64_matrix(
        dynamic_id,
        dynamic_shape.clone(),
        [1, 2].into(),
        Arc::clone(&dynamic_schemas),
    )
    .unwrap();
    let expected = ValueDraft {
        schema: dynamic_id,
        shape_values: [2].into(),
        data: ValueDataDraft::Matrix([ValueDataDraft::U64(1), ValueDataDraft::U64(2)].into()),
    }
    .finalize(&SnapshotValidationContext::with_shared_schemas(
        &dynamic_schemas,
    ))
    .unwrap();
    assert_eq!(
        actual.value_hash(&dynamic_schemas).unwrap(),
        expected.value_hash(&dynamic_schemas).unwrap()
    );
    // ShapeInstance carries parameter values, not a schema identity. Fixed
    // 1x2 and 2x1 schemas legitimately share an empty parameter instance.
    // A mismatched parameter COUNT is the invalid substitution to reject.
    let (id, fixed_shape, schemas) = schema(SchemaBody::UnsignedInteger(IntegerWidth::W64), 1, 2);
    assert!(Value::from_u64_matrix(id, dynamic_shape, [1, 2].into(), schemas).is_err());
    assert!(
        Value::from_u64_matrix(dynamic_id, fixed_shape, [1, 2].into(), dynamic_schemas).is_err()
    );
}

#[test]
fn borrowed_numeric_matrix_validation_rechecks_foreign_bounds_and_extent_overflow() {
    use crate::{
        DimensionLifetime, DimensionParameterDeclaration, DimensionParameterId,
        DimensionParameterOrigin,
    };
    fn parameterized(rows: u64, lower: u64, upper: Option<u64>) -> (SchemaId, Arc<SchemaTable>) {
        let mut builder = SchemaTableBuilder::new();
        let handle = builder
            .insert(
                SchemaDraft {
                    body: SchemaBody::Matrix {
                        element: Box::new(SchemaBody::UnsignedInteger(IntegerWidth::W64)),
                        dimensions: [
                            DimensionExpr::Constant(rows),
                            DimensionExpr::Parameter(DimensionParameterId::new(0)),
                        ]
                        .into(),
                    },
                    dimension_parameters: [DimensionParameterDeclaration {
                        id: DimensionParameterId::new(0),
                        origin: DimensionParameterOrigin::Explicit,
                        lifetime: DimensionLifetime::Activation,
                        lower_bound: DimensionExpr::Constant(lower),
                        upper_bound: upper.map(DimensionExpr::Constant),
                    }]
                    .into(),
                }
                .finalize()
                .unwrap(),
            )
            .unwrap();
        let built = builder.finish().unwrap();
        (built.resolve(handle).unwrap(), Arc::new(built.table))
    }
    let (foreign_id, foreign) = parameterized(1, 0, None);
    for (rows, lower, upper, parameter) in [
        (1, 2, Some(4), 1),
        (1, 2, Some(4), 5),
        (2, 0, None, u64::MAX),
    ] {
        let shape = foreign
            .get(foreign_id)
            .unwrap()
            .instantiate_shape([parameter].into())
            .unwrap();
        let (id, schemas) = parameterized(rows, lower, upper);
        let key = schemas.entry(id).unwrap().key();
        // Shape/bound/overflow errors precede payload cardinality errors.
        assert_eq!(
            Value::from_u64_matrix(id, shape, Box::new([]), schemas).unwrap_err(),
            SnapshotValueError::SnapshotSchemaDefinitionMismatch { key }
        );
    }
}

#[test]
fn borrowed_numeric_matrix_validation_resolves_original_dimension_expressions() {
    use crate::{
        DimensionLifetime, DimensionParameterDeclaration, DimensionParameterId,
        DimensionParameterOrigin,
    };
    let mut builder = SchemaTableBuilder::new();
    let handle = builder
        .insert(
            SchemaDraft {
                body: SchemaBody::Matrix {
                    element: Box::new(SchemaBody::UnsignedInteger(IntegerWidth::W64)),
                    dimensions: [
                        DimensionExpr::Constant(2),
                        DimensionExpr::Add(
                            [
                                DimensionExpr::Parameter(DimensionParameterId::new(0)),
                                DimensionExpr::Constant(1),
                            ]
                            .into(),
                        ),
                    ]
                    .into(),
                },
                dimension_parameters: [DimensionParameterDeclaration {
                    id: DimensionParameterId::new(0),
                    origin: DimensionParameterOrigin::Explicit,
                    lifetime: DimensionLifetime::Activation,
                    lower_bound: DimensionExpr::Constant(0),
                    upper_bound: Some(DimensionExpr::Constant(8)),
                }]
                .into(),
            }
            .finalize()
            .unwrap(),
        )
        .unwrap();
    let built = builder.finish().unwrap();
    let id = built.resolve(handle).unwrap();
    let schemas = Arc::new(built.table);
    for parameter in [0, 2, 8] {
        let shape = schemas
            .get(id)
            .unwrap()
            .instantiate_shape([parameter].into())
            .unwrap();
        let count = (2 * (parameter + 1)) as usize;
        let expected = ValueDraft {
            schema: id,
            shape_values: [parameter].into(),
            data: ValueDataDraft::Matrix(vec![ValueDataDraft::U64(7); count].into()),
        }
        .finalize(&SnapshotValidationContext::with_shared_schemas(&schemas))
        .unwrap();
        let actual =
            Value::from_u64_matrix(id, shape, vec![7; count].into(), Arc::clone(&schemas)).unwrap();
        assert_eq!(actual.shape(), expected.shape());
        assert_eq!(
            actual.canonical_data_draft().unwrap(),
            expected.canonical_data_draft().unwrap()
        );
        assert_eq!(
            actual.value_hash(&schemas).unwrap(),
            expected.value_hash(&schemas).unwrap()
        );
        actual.validate_against(&schemas).unwrap();
    }
}

fn prospective_owner_schema(
    dimensions: Vec<DimensionExpr>,
    parameters: Vec<crate::DimensionParameterDeclaration>,
    element: SchemaBody,
) -> (SchemaId, Arc<SchemaTable>) {
    let mut builder = SchemaTableBuilder::new();
    let handle = builder
        .insert(
            SchemaDraft {
                dimension_parameters: parameters.into_boxed_slice(),
                body: SchemaBody::Matrix {
                    element: Box::new(element),
                    dimensions: dimensions.into_boxed_slice(),
                },
            }
            .finalize()
            .unwrap(),
        )
        .unwrap();
    let built = builder.finish().unwrap();
    (built.resolve(handle).unwrap(), Arc::new(built.table))
}
fn prospective_parameter(lower: u64, upper: Option<u64>) -> crate::DimensionParameterDeclaration {
    crate::DimensionParameterDeclaration {
        id: crate::DimensionParameterId::new(0),
        origin: crate::DimensionParameterOrigin::Explicit,
        lifetime: crate::DimensionLifetime::Turn,
        lower_bound: DimensionExpr::Constant(lower),
        upper_bound: upper.map(DimensionExpr::Constant),
    }
}
#[test]
fn prospective_f64_owner_matches_complete_canonical_walk_and_real_admission() {
    for extents in [
        vec![0, 0],
        vec![0, 3],
        vec![2, 0],
        vec![1, 1],
        vec![2, 3],
        vec![4, 17],
        vec![4, 64],
        vec![2, 3, 4],
    ] {
        for dynamic in [false, true] {
            let dimensions = extents
                .iter()
                .enumerate()
                .map(|(at, &n)| {
                    if dynamic && at == 0 {
                        DimensionExpr::Parameter(crate::DimensionParameterId::new(0))
                    } else {
                        DimensionExpr::Constant(n)
                    }
                })
                .collect();
            let parameters = if dynamic {
                vec![prospective_parameter(0, Some(128))]
            } else {
                Vec::new()
            };
            let (id, table) = prospective_owner_schema(
                dimensions,
                parameters,
                SchemaBody::FloatingPoint(FloatWidth::W64),
            );
            let shape = table
                .get(id)
                .unwrap()
                .instantiate_shape(if dynamic {
                    vec![extents[0]].into()
                } else {
                    Box::new([])
                })
                .unwrap();
            let count: u64 = extents.iter().product();
            let price = Value::prospective_f64_matrix_ownership(id, &shape, count, &table).unwrap();
            let patterns = [
                0,
                1 << 63,
                0x7ff0_0000_0000_0000,
                0xfff0_0000_0000_0000,
                0x7ff8_0000_0000_0042,
                0x7ff0_0000_0000_0017,
                1,
                0x7fef_ffff_ffff_ffff,
            ];
            let cells = (0..count as usize)
                .map(|at| F64Bits::from_bits(patterns[at % patterns.len()]))
                .collect::<Vec<_>>()
                .into_boxed_slice();
            let raw = Value::from_f64_matrix(id, shape, cells, Arc::clone(&table)).unwrap();
            let generic = raw.memory_budget_ownership_by_traversal(&table).unwrap();
            assert_eq!(price, generic, "{extents:?}, dynamic={dynamic}");
            assert_eq!(price.1, 3);
            assert_eq!(raw.memory_budget_required_bytes().unwrap(), price.0);
            let memory = crate::ManagedMemoryBudget::new(16 * 1024 * 1024);
            let mut reserve = memory
                .reserve_capacity(raw.memory_budget_admission_bytes(&memory).unwrap())
                .unwrap();
            let admitted = raw.clone().into_memory_budget(&mut reserve).unwrap();
            assert_eq!(
                admitted.memory_budget_retained_bytes(&memory),
                Some(price.0)
            );
            assert_eq!(
                admitted.memory_budget_retained_nodes(&memory),
                Some(price.1)
            );
            assert_eq!(
                admitted
                    .memory_budget_ownership_by_traversal(&table)
                    .unwrap(),
                price
            );
            assert_eq!(admitted.memory_budget_required_bytes().unwrap(), price.0);
            drop((admitted, raw, reserve));
            assert_eq!(
                (memory.used_bytes(), memory.retained_snapshot_nodes()),
                (0, 0)
            );
        }
    }
}

#[test]
fn prospective_f64_owner_rejects_other_kinds_bounds_cardinality_and_overflow() {
    let element = SchemaBody::FloatingPoint(FloatWidth::W64);
    let (id, table) = prospective_owner_schema(
        vec![
            DimensionExpr::Parameter(crate::DimensionParameterId::new(0)),
            DimensionExpr::Constant(3),
        ],
        vec![prospective_parameter(2, Some(4))],
        element.clone(),
    );
    let shape = table
        .get(id)
        .unwrap()
        .instantiate_shape(vec![2].into())
        .unwrap();
    assert!(Value::prospective_f64_matrix_ownership(id, &shape, 6, &table).is_ok());
    assert!(Value::prospective_f64_matrix_ownership(id, &shape, 5, &table).is_err());
    assert!(
        Value::prospective_f64_matrix_ownership(SchemaId::new(u32::MAX), &shape, 6, &table)
            .is_err()
    );
    let (_, loose) = prospective_owner_schema(
        vec![DimensionExpr::Parameter(crate::DimensionParameterId::new(
            0,
        ))],
        vec![prospective_parameter(0, None)],
        element.clone(),
    );
    let loose_shape = loose
        .entries()
        .next()
        .unwrap()
        .schema()
        .instantiate_shape(vec![1].into())
        .unwrap();
    assert!(Value::prospective_f64_matrix_ownership(id, &loose_shape, 3, &table).is_err());
    for element in [
        SchemaBody::Bool,
        SchemaBody::FloatingPoint(FloatWidth::W32),
        SchemaBody::UnsignedInteger(IntegerWidth::W64),
    ] {
        let (id, table) = prospective_owner_schema(
            vec![DimensionExpr::Constant(2), DimensionExpr::Constant(3)],
            Vec::new(),
            element,
        );
        let shape = table
            .get(id)
            .unwrap()
            .instantiate_shape(Box::new([]))
            .unwrap();
        assert!(Value::prospective_f64_matrix_ownership(id, &shape, 6, &table).is_err());
    }
    let (id, table) = prospective_owner_schema(
        vec![DimensionExpr::Constant(u64::MAX)],
        Vec::new(),
        SchemaBody::FloatingPoint(FloatWidth::W64),
    );
    let shape = table
        .get(id)
        .unwrap()
        .instantiate_shape(Box::new([]))
        .unwrap();
    assert!(
        Value::prospective_f64_matrix_ownership(id, &shape, u64::MAX, &table).is_err(),
        "byte arithmetic cannot wrap before any payload allocation"
    );
}

#[test]
fn prospective_f64_owner_keeps_rebound_shape_and_current_schema_key_accounting() {
    let mut builder = SchemaTableBuilder::new();
    let dynamic = builder
        .insert(
            SchemaDraft {
                dimension_parameters: vec![prospective_parameter(0, None)].into(),
                body: SchemaBody::Matrix {
                    element: Box::new(SchemaBody::FloatingPoint(FloatWidth::W64)),
                    dimensions: vec![DimensionExpr::Parameter(crate::DimensionParameterId::new(
                        0,
                    ))]
                    .into(),
                },
            }
            .finalize()
            .unwrap(),
        )
        .unwrap();
    let fixed = builder
        .insert(
            SchemaDraft {
                dimension_parameters: Box::new([]),
                body: SchemaBody::Matrix {
                    element: Box::new(SchemaBody::FloatingPoint(FloatWidth::W64)),
                    dimensions: vec![DimensionExpr::Constant(4)].into(),
                },
            }
            .finalize()
            .unwrap(),
        )
        .unwrap();
    let built = builder.finish().unwrap();
    let dynamic = built.resolve(dynamic).unwrap();
    let fixed = built.resolve(fixed).unwrap();
    let table = Arc::new(built.table);
    let raw = Value::from_f64_matrix(
        dynamic,
        table
            .get(dynamic)
            .unwrap()
            .instantiate_shape(vec![4].into())
            .unwrap(),
        [0, 1 << 63, 0x7ff8_0000_0000_0042, 0x7ff0_0000_0000_0017]
            .map(F64Bits::from_bits)
            .into(),
        Arc::clone(&table),
    )
    .unwrap();
    let shape = table
        .get(fixed)
        .unwrap()
        .instantiate_shape(Box::new([]))
        .unwrap();
    let rebound = raw
        .rebind_with_context(
            fixed,
            &shape,
            &SnapshotValidationContext::with_shared_schemas(&table),
        )
        .unwrap();
    assert!(raw.shares_frozen_storage(&rebound));
    assert!(!Arc::ptr_eq(&rebound.shape, &rebound.root.data.shape));
    let generic = rebound
        .memory_budget_ownership_by_traversal(&table)
        .unwrap();
    assert_eq!(rebound.memory_budget_required_bytes().unwrap(), generic.0);
    let fresh = Value::prospective_f64_matrix_ownership(fixed, &shape, 4, &table).unwrap();
    assert!(
        generic.0 > fresh.0,
        "original shape owner remains retained through the shared payload"
    );
    let mut wrong_key = raw.clone();
    wrong_key.schema_key = SchemaKey::from_bytes([0; 32]);
    assert!(wrong_key.memory_budget_required_bytes().is_err());
}
