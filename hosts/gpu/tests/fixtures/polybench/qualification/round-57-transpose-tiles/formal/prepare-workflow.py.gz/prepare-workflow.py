from pathlib import Path
f=Path(__file__).resolve().parent;old=f.parents[1]/'round-62/ordered-map-dots'
# Adapt only experiment-owned wrappers; the shared benchmark runner and protocol remain unchanged.
s=(old/'run-qualification.py').read_text().replace('ordered-map-dots','transpose-tiles').replace('accepted54','accepted56')
a=s.index("receipt={'scope':");z=s.index('\nfor name,argv in checks:',a)
s=s[:a]+"receipt={'scope':'Exact-bit dynamic transpose tiles, empty/null/odd tails/canaries and no-division SIMD SSA; original/decoded/restored ordinal-ablation exact outputs and counters; maintained numeric/matrix/scalar/compression/type/image/protocol/all30 finite C/restored corpus and both features; no timing observations','compiler_fingerprint':fp,'checks':[]}"+s[z:]
(f/'run-qualification.py').write_text(s)
s=(old/'prepare-qualification-manifest.py').read_text().replace('ordered-map-dots','transpose-tiles').replace('==[10]','==[3]')
(f/'prepare-qualification-manifest.py').write_text(s)
s=(old/'untimed-counter-gate.py').read_text().replace('accepted54','accepted56').replace('round-54','round-56').replace('ordered-map-dots','transpose-tiles').replace("emission['ordered_dots_emitted']","emission['transpose_tiles_emitted']").replace("==56\n","==57\n")
s=s.replace("views=emission['cases'][name]['actors']['candidate']['ordered_dot_sites']","views=[]")
s=s.replace('Source-closed affine matrix reads execute strict ordered dot streams and independent output lanes after endpoint/corner guards. Original source order per output, errors, callbacks, fees, visits and full old-DAG replay remain; no new runtime ABI or buffer.','Exact-bit materialized transpose replaces ordinal quotient/remainder with bounded two-by-two tiles. Original loan preparation, callbacks, source fees, visits, allocation, spans, owners, finish, atomic publication and fallback remain; no new ABI or buffer.')
(f/'untimed-counter-gate.py').write_text(s)
s=(old/'training-probe.py').read_text().replace('accepted54','accepted56').replace('round-54','round-56').replace('ordered-map-dots','transpose-tiles').replace("emission['ordered_dots_emitted']","emission['transpose_tiles_emitted']")
(f/'training-probe.py').write_text(s)
(f/'run-training-probe.py').write_text((old/'run-training-probe.py').read_text())
print('Prepared qualification, manifest, untimed gate and one-probe wrappers; no source mutation or timing.')
