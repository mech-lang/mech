"""An unselected single probe is preserved once; restore only the planned source paths."""
import gzip,importlib.util,json,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;plan=b.read(folder/'plan.json');q=b.read(folder/'qualification.json');r=b.read(folder/'training-probe.json');fp=b.compiler_fingerprint();development=b.read(p/'training-experiments/transpose-tiles-development.json')
assert r['complete']and not r['summary']['selected']and b.read(folder/'training-probe.exit.json')['exit_code']==0
assert sum(len(c['observations'])for c in r['cases'].values())==210 and len(r['cases'])==15
assert fp==q['compiler_fingerprint']==r['compiler_fingerprint']==development['compiler_fingerprint']
assert b.digest(q['driver'])==q['driver_sha256']==r['driver_sha256']
assert len(b.read(p/'performance-history.json')['entries'])==57 and b.read(p/'performance-acceptance.json')['accepted_history_index']==56
assert all(b.digest(root/name)==digest for name,digest in q['source_sha256'].items())
dest=p/'qualification/round-57-transpose-tiles/unselected-probe';dest.mkdir(parents=True,exist_ok=False);archives={}
for source in sorted(folder.rglob('*')):
 if not source.is_file()or '__pycache__'in source.parts or source.name.endswith('-driver'):continue
 name=str(source.relative_to(folder));raw=source.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives[name]={'path':str(out.relative_to(p)),'sha256':b.digest(source),'compressed_sha256':b.digest(out)}
receipt={'schema':'mech.polybench.unselected-training-probe.v1','created_at':b.utc(),'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'qualified_source_commit':b.read(folder/'qualification-source-commit.json')['source_commit'],'source_parent':plan['source_parent'],'qualification':q,'source_fee_and_visit_gate':b.read(folder/'untimed-counter-gate.json'),'summary':r['summary'],'observations':210,'selected':False,'accepted_round':56,'accepted_scores':plan['accepted_scores'],'holdout_performance_observations':0,'formal_performance_observations':0,'history_entries_unchanged':57,'reason':'Single prospective optimization probe did not strictly improve raw equal-weight geometric mean runtime. No retry of this observed fingerprint, exclusions or holdout decision.','archives':archives,'next':'Use optimization-only source/profile evidence to choose a materially different future change; accepted56 retained.'}
b.write(p/'training-experiments/transpose-tiles-unselected.json',receipt);b.write(p/'training-experiments/transpose-tiles-unselected-probe.json',r)
subprocess.run(['git','restore','--source='+plan['source_parent'],'--worktree','--',*plan['source_paths']],check=True)
subprocess.run(['git','add','-A','--',*plan['source_paths'],'hosts/gpu/tests/fixtures/polybench'],check=True)
assert b.compiler_fingerprint()==b.read(p/'round-56-frozen.json')['compiler_fingerprint']
subprocess.run(['git','diff','--check'],check=True);subprocess.run(['git','commit','-q','-m','Preserve unselected transpose tile probe and restore accepted56'],check=True)
assert b.command(['git','status','--porcelain'])==''
b.write(folder/'current-work.json',{'stage':'Unselected one-probe candidate archived; accepted56 restored; push pending','source_commit':b.command(['git','rev-parse','HEAD']),'accepted_round':56,'accepted_scores':plan['accepted_scores'],'compiler_fingerprint':b.compiler_fingerprint(),'candidate_fingerprint':fp,'performance_observations':210,'formal_performance_observations':0,'history_entries':57,'complete':True})
print(json.dumps({'head':b.command(['git','rev-parse','HEAD']),'accepted_round':56,'summary':r['summary'],'archives_verified':len(archives),'clean':True}),flush=True)
