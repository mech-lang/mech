"""Checked optimization Objects and static transpose instruction evidence; no timings."""
import hashlib,importlib.util,json,re,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
protocol,cases=b.protocol();q=b.read(folder/'qualification.json');plan=b.read(folder/'plan.json');fp=b.compiler_fingerprint()
assert q['complete'] and fp==q['compiler_fingerprint']
actors={'accepted56':Path(plan['accepted_driver']),'candidate':Path(q['driver'])}
assert b.digest(actors['accepted56'])==plan['accepted_driver_sha256'] and b.digest(actors['candidate'])==q['driver_sha256']
objects=folder/'objects';objects.mkdir(exist_ok=False)
def functions(asm):
 rows={};name=None
 for line in asm.splitlines():
  m=re.match(r'^[0-9a-f]+ <_(.+)>:',line)
  if m:name=m[1];rows[name]=[]
  elif name and re.match(r'^\s*[0-9a-f]+:',line):rows[name].append(line)
 return {name:{'instructions':len(lines),'disassembly_sha256':hashlib.sha256('\n'.join(lines).encode()).hexdigest()}for name,lines in rows.items()}
def records(value,key):
 if isinstance(value,dict):return sum((v if k==key else records(v,key)for k,v in value.items()),[])
 if isinstance(value,list):return sum((records(v,key)for v in value),[])
 return []
r={'schema':'mech.polybench.transpose-tiles-static-telemetry.v1','scope':'Optimization15 genuine checked Object exports and static instructions only; no Object execution, performance observations, hardware retired instructions or traffic claims.','compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'cases':{},'complete':False,'performance_observations':0}
for name in protocol['optimization']:
 config=folder/f'{name}-inputs.json';b.write(config,cases[name]['inputs']);row={'actors':{}};r['cases'][name]=row
 for actor,driver in actors.items():
  obj=objects/f'{name}-{actor}.o';argv=[str(driver),str(b.FIXTURE/f'{name}.mec'),str(config),'0',f'emit-object={obj}']
  stdout=objects/f'{name}-{actor}.stdout';stderr=objects/f'{name}-{actor}.stderr'
  with stdout.open('x')as out,stderr.open('x')as err:
   child=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err);r['pending']={'case':name,'actor':actor,'pid':child.pid,'command':argv};b.write(folder/'emission-census.json',r)
   while True:
    try:code=child.wait(timeout=30);break
    except subprocess.TimeoutExpired:print('Waiting on same Object process',child.pid,flush=True)
  assert code==0,stderr.read_text();r.pop('pending');status=json.loads(stdout.read_text().strip().splitlines()[-1]);assert status['status']=='ok' and status['mode']=='emit-object'
  metadata=b.read(obj.with_suffix('.metadata.json'));asm=subprocess.run(['/Library/Developer/CommandLineTools/usr/bin/llvm-objdump','--disassemble','--no-show-raw-insn',str(obj)],text=True,capture_output=True,check=True).stdout
  disasm=obj.with_suffix('.disasm.txt');disasm.write_text(asm);fm=functions(asm);assert fm and any(v['instructions']for v in fm.values())
  row['actors'][actor]={'code_bytes':metadata['code_bytes'],'reported_native_stack_bytes':metadata['stack_bytes'],'object_file_bytes':obj.stat().st_size,'static_instruction_count':sum(v['instructions']for v in fm.values()),'functions':fm,'object_sha256':b.digest(obj),'metadata_sha256':b.digest(obj.with_suffix('.metadata.json')),'disassembly_sha256':b.digest(disasm),'object_executed':False,'native_64_lane_interleaves':[line for line in asm.splitlines()if re.search(r'\b(?:zip1|zip2|uzp1|uzp2)\.2d\b',line)],'hardware_division_sites':len(re.findall(r'\budiv\b',asm)),'integer_vector_copy_sites':[line for line in asm.splitlines()if re.search(r'\b(?:ldr|str)\s+q\d+|\b(?:zip1|zip2|uzp1|uzp2|ins|dup)\b',line)],'fused_multiply_add_instructions':len(re.findall(r'\b(?:fmadd|fmsub|fnmadd|fnmsub|fmla|fmls)\b',asm))}
  for key in ['compiled_product_epilogues','compiled_reduction_producers','masked_matrix_maps','guarded_map_initializations','compound_matrix_maps']:row['actors'][actor][key]=records(metadata,key)
 row['functions_match']=row['actors']['accepted56']['functions']==row['actors']['candidate']['functions'];row['code_bytes_match']=row['actors']['accepted56']['code_bytes']==row['actors']['candidate']['code_bytes']
 for key in ['compiled_product_epilogues','compiled_reduction_producers','masked_matrix_maps','guarded_map_initializations','compound_matrix_maps']:assert row['actors']['accepted56'][key]==row['actors']['candidate'][key]
 row['division_site_delta']=row['actors']['candidate']['hardware_division_sites']-row['actors']['accepted56']['hardware_division_sites']
 b.write(folder/'emission-census.json',r);print(name,'code',row['actors']['accepted56']['code_bytes'],'->',row['actors']['candidate']['code_bytes'],'division sites',row['division_site_delta'],flush=True)
r['native_code_changed_cases']=[name for name,row in r['cases'].items()if not row['functions_match']or not row['code_bytes_match']]
r['no_new_fma']=all(row['actors']['candidate']['fused_multiply_add_instructions']<=row['actors']['accepted56']['fused_multiply_add_instructions']for row in r['cases'].values())
r['transpose_tiles_emitted']=r['cases']['mvt']['division_site_delta']<=-2 and len(r['cases']['mvt']['actors']['candidate']['native_64_lane_interleaves'])>=2 and len(r['cases']['mvt']['actors']['candidate']['integer_vector_copy_sites'])>len(r['cases']['mvt']['actors']['accepted56']['integer_vector_copy_sites'])
r.update(complete=len(r['cases'])==15,source_unchanged=b.compiler_fingerprint()==fp)
r['passed']=r['complete']and r['source_unchanged']and r['transpose_tiles_emitted']and r['no_new_fma'];b.write(folder/'emission-census.json',r)
assert r['passed'];print('Materialized transpose Object evidence passed',flush=True)
