from pathlib import Path
root=Path.cwd();f=Path(__file__).resolve().parent
paths=__import__('json').loads((f/'plan.json').read_text())['source_paths']
for name in paths:
 p=root/name
 if p.exists():
  out=f/'source-before'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes())
p=root/'hosts/gpu/src/native_artifact/program/codegen/numeric_transpose.rs'
old=p.read_text();ordinal=old[old.index('pub(super) fn emit('):].replace('pub(super) fn emit(','pub(super) fn emit_ordinal(',1)
new='''//! Exact-bit native transpose over runtime-admitted disjoint typed banks.
//! Two-by-two integer tiles keep both source loads and output stores contiguous.
use super::numeric_binary::address;
use cranelift_codegen::ir::{Block, InstBuilder, MemFlags, Value, condcodes::IntCC, types};
use cranelift_frontend::FunctionBuilder;

fn pair(b: &mut FunctionBuilder<'_>, first: Value, second: Value) -> Value {
    let value = b.ins().splat(types::I64X2, first);
    b.ins().insertlane(value, second, 1)
}

/// One or two output rows. All accesses are inside their exact real-cell
/// rectangle; tails never read padding. The caller has validated the complete
/// geometry and disjoint spans before entering this nonfallible copy.
fn row_band(
    b: &mut FunctionBuilder<'_>,
    input: Value,
    output: Value,
    columns: Value,
    input_columns: Value,
    row: Value,
    two_rows: bool,
) {
    let source_base = address(b, input, row);
    let destination_row = b.ins().imul(row, columns);
    let destination_base = address(b, output, destination_row);
    let source_stride = b.ins().imul_imm(input_columns, 8);
    let destination_stride = b.ins().imul_imm(columns, 8);
    let column = b.declare_var(types::I64);
    let zero = b.ins().iconst(types::I64, 0);
    b.def_var(column, zero);
    let header = b.create_block();
    let tile = b.create_block();
    let tail = b.create_block();
    let single = b.create_block();
    let done = b.create_block();
    b.ins().jump(header, &[]);
    b.switch_to_block(header);
    let at = b.use_var(column);
    let remaining = b.ins().isub(columns, at);
    let two_columns = b.ins().icmp_imm(IntCC::UnsignedGreaterThanOrEqual, remaining, 2);
    b.ins().brif(two_columns, tile, &[], tail, &[]);
    b.switch_to_block(tile);
    let source_offset = b.ins().imul(at, source_stride);
    let first = b.ins().iadd(source_base, source_offset);
    let second = b.ins().iadd(first, source_stride);
    let to = address(b, destination_base, at);
    if two_rows {
        let a = b.ins().load(types::I64X2, MemFlags::new(), first, 0);
        let c = b.ins().load(types::I64X2, MemFlags::new(), second, 0);
        let a0 = b.ins().extractlane(a, 0);
        let c0 = b.ins().extractlane(c, 0);
        let low = pair(b, a0, c0);
        let a1 = b.ins().extractlane(a, 1);
        let c1 = b.ins().extractlane(c, 1);
        let high = pair(b, a1, c1);
        b.ins().store(MemFlags::new(), low, to, 0);
        let next_row = b.ins().iadd(to, destination_stride);
        b.ins().store(MemFlags::new(), high, next_row, 0);
    } else {
        let a = b.ins().load(types::I64, MemFlags::new(), first, 0);
        let c = b.ins().load(types::I64, MemFlags::new(), second, 0);
        let value = pair(b, a, c);
        b.ins().store(MemFlags::new(), value, to, 0);
    }
    let next = b.ins().iadd_imm(at, 2);
    b.def_var(column, next);
    b.ins().jump(header, &[]);
    b.switch_to_block(tail);
    let at = b.use_var(column);
    let last = b.ins().icmp(IntCC::UnsignedLessThan, at, columns);
    b.ins().brif(last, single, &[], done, &[]);
    b.switch_to_block(single);
    let source_offset = b.ins().imul(at, source_stride);
    let from = b.ins().iadd(source_base, source_offset);
    let to = address(b, destination_base, at);
    if two_rows {
        let words = b.ins().load(types::I64X2, MemFlags::new(), from, 0);
        let first = b.ins().extractlane(words, 0);
        let second = b.ins().extractlane(words, 1);
        b.ins().store(MemFlags::new(), first, to, 0);
        let next_row = b.ins().iadd(to, destination_stride);
        b.ins().store(MemFlags::new(), second, next_row, 0);
    } else {
        let word = b.ins().load(types::I64, MemFlags::new(), from, 0);
        b.ins().store(MemFlags::new(), word, to, 0);
    }
    b.ins().jump(done, &[]);
    b.switch_to_block(done);
}

pub(super) fn emit(
    b: &mut FunctionBuilder<'_>,
    input: Value,
    output: Value,
    count: Value,
    output_columns: Value,
    input_columns: Value,
    done: Block,
) {
    let start = b.create_block();
    let nonempty = b.ins().icmp_imm(IntCC::NotEqual, count, 0);
    // Empty axes may be arbitrarily large and both pointers may be null.
    // Do not derive strides or enter a row loop until count is nonzero.
    b.ins().brif(nonempty, start, &[], done, &[]);
    b.switch_to_block(start);
    let row = b.declare_var(types::I64);
    let zero = b.ins().iconst(types::I64, 0);
    b.def_var(row, zero);
    let header = b.create_block();
    let paired = b.create_block();
    let tail = b.create_block();
    let single = b.create_block();
    b.ins().jump(header, &[]);
    b.switch_to_block(header);
    let at = b.use_var(row);
    let remaining = b.ins().isub(input_columns, at);
    let two = b.ins().icmp_imm(IntCC::UnsignedGreaterThanOrEqual, remaining, 2);
    b.ins().brif(two, paired, &[], tail, &[]);
    b.switch_to_block(paired);
    row_band(b, input, output, output_columns, input_columns, at, true);
    let next = b.ins().iadd_imm(at, 2);
    b.def_var(row, next);
    b.ins().jump(header, &[]);
    b.switch_to_block(tail);
    let at = b.use_var(row);
    let last = b.ins().icmp(IntCC::UnsignedLessThan, at, input_columns);
    b.ins().brif(last, single, &[], done, &[]);
    b.switch_to_block(single);
    row_band(b, input, output, output_columns, input_columns, at, false);
    b.ins().jump(done, &[]);
}

/// Private emission ablation: the accepted ordinal transpose remains available
/// to differential tests without changing loan admission or source accounting.
'''+ordinal+'''
#[cfg(test)]
#[path = "numeric_transpose_tests.rs"]
mod tests;
'''
p.write_text(new)
p=root/'hosts/gpu/src/native_artifact/codegen/options.rs';s=p.read_text().replace('    ProductRowPairs,','    ProductRowPairs,\n    /// Copy materialized transposes in bounded exact-bit two-by-two tiles.\n    TransposeTiles,',1);p.write_text(s)
p=root/'hosts/gpu/src/native_artifact/program/codegen/numeric_binary.rs';s=p.read_text().replace('    product_row_quartets: bool,\n    error: Block,','    product_row_quartets: bool,\n    transpose_tiles: bool,\n    error: Block,',1)
oldcall='''            super::numeric_transpose::emit(
                b,
                left,
                output,
                count,
                output_columns,
                input_columns,
                complete,
            );'''
newcall='''            let emit = if transpose_tiles {
                super::numeric_transpose::emit
            } else {
                super::numeric_transpose::emit_ordinal
            };
            emit(b, left, output, count, output_columns, input_columns, complete);'''
assert oldcall in s;s=s.replace(oldcall,newcall,1);p.write_text(s)
p=root/'hosts/gpu/src/native_artifact/codegen/control/mod.rs';s=p.read_text();oldcall='''                                controls.enabled(crate::native_artifact::codegen::options::OptimizationPass::ProductRowQuartets),
                                error,''';assert oldcall in s;s=s.replace(oldcall,'''                                controls.enabled(crate::native_artifact::codegen::options::OptimizationPass::ProductRowQuartets),
                                controls.enabled(crate::native_artifact::codegen::options::OptimizationPass::TransposeTiles),
                                error,''',1);p.write_text(s)
p=root/'hosts/gpu/src/native_artifact/program/image/identity.rs';s=p.read_text();assert 'NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 425' in s;s=s.replace('NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 425','NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 426',1);p.write_text(s)
print('Implemented dynamic exact-bit transpose tiles, private binary ablation, IR426; no build started.')
