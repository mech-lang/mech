General matrix expressions, comprehensions and state machines previously spent heavily on runtime preparation, temporary Values and complete matrix passes. This PR ports all30 PolyBench/C MINI programs to idiomatic Mech and fills shared compiler gaps so the unchanged programs lower through Cranelift, reuse resident numeric kernels, emit checked Objects and match all29,482 recorded finite C liveouts. Compiler rules use source operators, liveness, geometry and ownership proofs; no benchmark names or MINI dimensions select an optimization.

The accepted compiler is **round48**, frozen source `cc89f77879dfadb22a7643dc0400522d7ff537b8`, fingerprint `ecc417a8e887b1bac94af3a6b70e447b989edbc1d620668208c25f4cd6847021` (IR415/work157/ABI48). Results and source are committed and pushed.

| Equal-weight geometric mean | Accepted47 | Accepted48 | Raw Mech speedup vs47 |
|---|---:|---:|---:|
| Optimization15 | 9.57594× C | **9.40180× C** | 0.998587× |
| Holdout15 | 27.50652× C | **24.66619× C** | 1.140726× |

Optimization raw runtime is essentially flat in the formal run; measured C runtime rose1.019964×, contributing to the primary ratio improvement. The contemporaneous original-reference-adjusted optimization speedup is1.011413×. Holdout raw Mech speedup is1.140726×, reported independently. Raw speedups since the recorded start are 83.228× optimization / 79.362× holdout. All measurements and regressions remain.

Selection follows the user-directed [v4 policy](https://github.com/mech-lang/mech/blob/be63ed00f2bb2ed7553a8ecc0e3d83701a56286e/hosts/gpu/tests/fixtures/polybench/performance-selection-policy-v4.json): optimization15 alone selects and promotes; formal promotion requires a strictly lower optimization Mech/C score. Holdout never vetoes, selects, tunes or triggers rollback/retry. Its independently evaluated below1.0× C goal remains unmet at24.66619×.

Current ordered product epilogues feed each ordered F64 product accumulator into its original scalar/exact/row/column arithmetic consumers before the final store. Product/scaling/addition intermediates have no numeric payload buffers, complete read/write passes, canonical Values or separate operator-loan boundaries on the admitted path. Original arithmetic order, resident factory geometry, complete source fees, finite caps, current owner and publication obligations remain; consumed nonfinite intermediates cancel private output and replay original execution. The ordinary fallback and frozen scalar frame prefix remain. No reassociation or FMA is introduced.

Actual fused Objects and honest physical visit reductions were verified for2mm(−3), GEMM(−3) and MVT(−2). Every optimization15 liveout matched C; source work/comparison never decreased and all other execution counters matched accepted47. The single210-observation prospective optimization probe selected at1.009350× raw GM speedup, retaining the MVT regression. The following single frozen900-observation formal run passed its audit and appended history49 without changing earlier entries.

Qualification passed **729 broad checks and eight focused groups** (selected invocations can overlap), both feature configurations, scalar/compression and shared source/type/image regressions, all30 original/decoded/restored helper forms, exact scalar/SIMD bits, projections/empty dimensions, logical/physical finite caps, aliases, atomic failures/cleanup/retry and forged image/loan checks. Source ports, input adapters/data, C binaries/flags, tolerances and timing/cache boundaries remain fixed. Development errors, unselected transpose experiments, source snapshots and all observations remain archived.

Median kernel timings, ordered by Mech/C ratio:

| Program | Set | Mech µs | C µs | Mech/C |
|---|---|---:|---:|---:|
| jacobi-1d | holdout | 184.292 | 0.500 | 368.50× |
| adi | holdout | 8,509.833 | 45.416 | 187.38× |
| ludcmp | holdout | 1,069.875 | 12.667 | 84.46× |
| lu | holdout | 660.291 | 12.083 | 54.65× |
| jacobi-2d | holdout | 312.833 | 7.833 | 39.94× |
| gramschmidt | optimization | 95.083 | 3.542 | 26.85× |
| trisolv | holdout | 25.375 | 1.084 | 23.41× |
| durbin | optimization | 28.500 | 1.334 | 21.36× |
| heat-3d | holdout | 372.167 | 17.833 | 20.87× |
| mvt | optimization | 25.208 | 1.292 | 19.51× |
| fdtd-2d | holdout | 135.500 | 6.958 | 19.47× |
| correlation | optimization | 79.834 | 4.375 | 18.25× |
| gemver | holdout | 32.958 | 1.916 | 17.20× |
| atax | optimization | 18.959 | 1.292 | 14.68× |
| bicg | optimization | 20.084 | 1.500 | 13.39× |
| gesummv | holdout | 17.791 | 1.625 | 10.95× |
| 2mm | optimization | 20.042 | 1.875 | 10.69× |
| floyd-warshall | holdout | 684.833 | 65.541 | 10.45× |
| 3mm | optimization | 23.583 | 2.542 | 9.28× |
| trmm | holdout | 28.833 | 3.166 | 9.11× |
| symm | holdout | 29.750 | 3.792 | 7.84× |
| deriche | optimization | 218.000 | 28.917 | 7.54× |
| cholesky | optimization | 52.250 | 7.083 | 7.38× |
| syrk | holdout | 36.584 | 5.333 | 6.86× |
| covariance | optimization | 30.459 | 4.542 | 6.71× |
| syr2k | holdout | 45.625 | 7.000 | 6.52× |
| nussinov | optimization | 184.292 | 29.416 | 6.27× |
| doitgen | optimization | 16.166 | 3.083 | 5.24× |
| gemm | optimization | 18.625 | 4.334 | 4.30× |
| seidel-2d | optimization | 204.500 | 108.041 | 1.89× |

[Static telemetry](https://github.com/mech-lang/mech/blob/be63ed00f2bb2ed7553a8ecc0e3d83701a56286e/hosts/gpu/tests/fixtures/polybench/round-48-static-telemetry.json) records actual checked Object code, static instructions, reported native stack, metadata and executable sections for optimization15. Fusion retains cold fallbacks and increases generated code footprint: GEMM3,424→4,216B /856→1,054instructions;2mm3,876→5,140B /969→1,285;MVT3,812→5,112B /953→1,278. Native reported stack for these changes96→112B. These are static counts, not retired instructions. Gram–Schmidt is51,620B generated code and23,072B reported native stack. An external allocation/memory probe is now building; no actual heap peak or RSS is inferred from source resource counters.

[Formal qualification](https://github.com/mech-lang/mech/blob/be63ed00f2bb2ed7553a8ecc0e3d83701a56286e/hosts/gpu/tests/fixtures/polybench/round-48-qualification.json) · [900-observation audit and controls](https://github.com/mech-lang/mech/blob/be63ed00f2bb2ed7553a8ecc0e3d83701a56286e/hosts/gpu/tests/fixtures/polybench/round-48-audit.json) · [Performance history](https://github.com/mech-lang/mech/blob/be63ed00f2bb2ed7553a8ecc0e3d83701a56286e/hosts/gpu/tests/fixtures/polybench/performance-history.json) · [Optimization observations](https://github.com/mech-lang/mech/blob/be63ed00f2bb2ed7553a8ecc0e3d83701a56286e/hosts/gpu/tests/fixtures/polybench/round-48-optimization.json) · [Independent holdout observations](https://github.com/mech-lang/mech/blob/be63ed00f2bb2ed7553a8ecc0e3d83701a56286e/hosts/gpu/tests/fixtures/polybench/round-48-holdout.json) · [Source-fee/visit gate](https://github.com/mech-lang/mech/blob/be63ed00f2bb2ed7553a8ecc0e3d83701a56286e/hosts/gpu/tests/fixtures/polybench/round-48-epilogue-route-census.json) · [Accepted experiment evidence](https://github.com/mech-lang/mech/blob/be63ed00f2bb2ed7553a8ecc0e3d83701a56286e/hosts/gpu/tests/fixtures/polybench/training-experiments/ordered-product-epilogues-accepted.json)
