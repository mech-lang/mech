"""Own-process warm CPU sampling, auxiliary to frozen performance measurements."""
import importlib.util,json,os,subprocess,time
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
plan=b.read(folder/'durbin-cpu-plan.json');build=b.read(folder/'residence-build.json');driver=Path(build['driver']);protocol,cases=b.protocol();fp=b.compiler_fingerprint();assert fp==build['compiler_fingerprint'] and build['source_unchanged'] and b.digest(driver)==build['driver_sha256'];assert set(plan['cases'])<=set(protocol['optimization'])
reference=b.read(folder.parent/'ordered-product-epilogues/untimed-counter-gate.json');static=b.read(folder/'static.json');history_hash=b.digest(b.FIXTURE/'performance-history.json');output=folder/'durbin-cpu.json';assert not output.exists()
r={'schema':'mech.polybench.warm-cpu-telemetry.v1','created_at':b.utc(),'plan':plan,'compiler_fingerprint':fp,'driver_sha256':build['driver_sha256'],'cases':{},'complete':False,'official_performance_observations':0};b.write(output,r)
for name in plan['cases']:
 config=folder/f'{name}-inputs.json';b.write(config,cases[name]['inputs'])
 obj=folder/f'{name}-residence.o';argv=[str(driver),str(b.FIXTURE/f'{name}.mec'),str(config),'0',f'emit-object={obj}'];emitted=subprocess.run(argv,text=True,capture_output=True,check=True);assert json.loads(emitted.stdout.strip().splitlines()[-1])['status']=='ok';metadata=b.read(obj.with_suffix('.metadata.json'));original=folder.parent/f'ordered-product-epilogues/objects/{name}-candidate.metadata.json';expected=b.read(original)
 for key in ['typed_ir_sha256','typed_ir_version','abi_version','work_policy_version','code_bytes','stack_bytes']:assert metadata[key]==expected[key],(name,key)
 exact_object=b.digest(obj)==b.digest(original.with_suffix('').with_suffix('.o'))
 argv=[str(driver),str(b.FIXTURE/f'{name}.mec'),str(config),str(plan['seconds_per_process'])];env=os.environ.copy();env['PERF_BUILDID_DIR']=str(folder/'perf-binaries');started=time.time_ns();start=time.monotonic()
 with (folder/f'{name}-cpu.stdout').open('x') as out,(folder/f'{name}-cpu.stderr').open('x') as err:
  child=subprocess.Popen(argv,stdout=out,stderr=err,env=env);mapping=Path(f'/tmp/perf-{child.pid}.map');prefix=mapping.read_bytes() if mapping.exists() and mapping.stat().st_mtime_ns<started else b''
  r['pending']={'case':name,'pid':child.pid,'command':argv,'stage':'sampling'};b.write(output,r);print(name,'profiling owned process',child.pid,flush=True);time.sleep(1);assert child.poll() is None
  sample=folder/f'{name}.sample.txt';sample_argv=['/usr/bin/sample',str(child.pid),str(plan['sample_seconds']),'1','-file',str(sample)];sampler=subprocess.run(sample_argv,text=True,capture_output=True);(folder/f'{name}-sample.log').write_text(sampler.stdout+sampler.stderr);r['pending'].update(stage='waiting_on_same_driver',sample_exit_code=sampler.returncode);b.write(output,r)
  while True:
   try:code=child.wait(timeout=30);break
   except subprocess.TimeoutExpired:print('Waiting on same CPU-residence process',child.pid,flush=True)
 assert code==0 and sampler.returncode==0
 assert mapping.exists() and mapping.stat().st_mtime_ns>=started
 payload=mapping.read_bytes();assert payload.startswith(prefix);jit=folder/f'{name}.perf.map';jit.write_bytes(payload[len(prefix):]);assert 'mech_canonical_program_entry_v1' in jit.read_text()
 result=json.loads((folder/f'{name}-cpu.stdout').read_text().strip().splitlines()[-1]);assert result['status']=='ok' and result['samples_seconds']==[];assert result['report']==result['residence_report']==reference['cases'][name]['actors']['candidate']['execution_report']
 r['cases'][name]={'pid':child.pid,'command':argv,'sample_command':sample_argv,'driver_exit_code':code,'sample_exit_code':sampler.returncode,'object_matches_frozen_candidate':exact_object,'native_metadata_geometry_matches':True,'residence_calls':result['residence_calls'],'residence_process_seconds':time.monotonic()-start,'warmup_validation':b.validate(result['values'],cases[name]['expected']),'final_validation':b.validate(result['final_values'],cases[name]['expected']),'execution_counters_match_frozen_candidate':True,'sample_sha256':b.digest(sample),'perf_map_sha256':b.digest(jit),'object_sha256':b.digest(obj)};r.pop('pending');b.write(output,r);print(name,'residence complete; frozen counters and finite liveouts match; exact Object',exact_object,flush=True)
analyzer=root/'scripts/analyze-polybench-samples.py';demangler=Path('/private/tmp/mech-polybench-optimization/round-02/profile-tools/target/release/polybench-profile-demangle');argv=['python3',str(analyzer),'--demangler',str(demangler),'--output',str(folder/'durbin-cpu-analysis.json'),*[arg for name in plan['cases'] for arg in ['--jit-map',f'{name}.sample.txt={folder/f"{name}.perf.map"}']],*[str(folder/f'{name}.sample.txt') for name in plan['cases']]]
with (folder/'durbin-cpu-analyzer.log').open('x') as out:completed=subprocess.run(argv,stdout=out,stderr=subprocess.STDOUT)
assert completed.returncode==0,(folder/'durbin-cpu-analyzer.log').read_text();analysis=b.read(folder/'durbin-cpu-analysis.json');r.update(complete=True,completed_at=b.utc(),analysis={name:analysis[name+'.sample.txt'] for name in plan['cases']},source_and_history_unchanged=fp==b.compiler_fingerprint() and history_hash==b.digest(b.FIXTURE/'performance-history.json'));assert r['source_and_history_unchanged'];b.write(output,r)
for name,a in r['analysis'].items():print(json.dumps({'case':name,'execution_samples':a['execution_samples'],'self_time_mechanisms':a['self_time_mechanisms'],'top_self_functions':a['top_self_functions'][:5]}),flush=True)
