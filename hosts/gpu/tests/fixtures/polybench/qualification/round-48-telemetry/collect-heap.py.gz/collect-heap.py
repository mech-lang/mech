"""Untimed optimization15 allocation telemetry; each call retains normal limits."""
import importlib.util,json,math,statistics,subprocess,time,re
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
protocol,cases=b.protocol();build=b.read(folder/'probe-build.json');assert build['exit_code']==0 and build['source_unchanged'];driver=Path(build['driver']);assert b.digest(driver)==build['driver_sha256'];fp=b.compiler_fingerprint();assert fp==build['compiler_fingerprint']==b.read(b.FIXTURE/'round-48-frozen.json')['compiler_fingerprint']
assert b.read(b.FIXTURE/'performance-acceptance.json')['accepted_history_index']==48
reference=b.read(folder.parent/'ordered-product-epilogues/untimed-counter-gate.json')
output=folder/'heap.json';assert not output.exists();history_hash=b.digest(b.FIXTURE/'performance-history.json')
r={'schema':'mech.polybench.heap-telemetry.v1','created_at':b.utc(),'scope':'Optimization15 only. Eight untimed diagnostic checked calls per case after a normal warmup; allocator instrumentation changes host costs and contributes no performance observations.','compiler_fingerprint':fp,'source_commit':b.command(['git','rev-parse','HEAD']),'probe_build':build,'cases':{},'complete':False,'official_performance_observations':0,'units':'bytes are requested Rust GlobalAlloc storage; raw macOS time maximum-resident-set-size is bytes','limits':['Requested heap excludes allocator size-class rounding, foreign malloc, executable mappings and internal transient realloc backing.','Per-call additional live requested heap excludes pre-call compilation/catalog/input storage. Absolute baseline includes the diagnostic harness.','Process maximum RSS includes startup, catalog, compiler, inputs and all diagnostic activity; it is not checked-call peak memory.','Managed admission counters include reservations/retained claims; they are not physical RSS or CPU instructions.','No diagnostic elapsed time enters the frozen benchmark or training selection.'],'pending':None};b.write(output,r)
for name in sorted(protocol['optimization'],key=lambda n:-b.read(b.FIXTURE/'round-48-optimization.json')['runs'][n]['comparisons']['kernel']['median_mech_over_c']):
 config=folder/f'{name}-inputs.json';b.write(config,cases[name]['inputs']);stdout=folder/f'{name}-heap.stdout';stderr=folder/f'{name}-heap.stderr';argv=['/usr/bin/time','-l',str(driver),str(b.FIXTURE/f'{name}.mec'),str(config),'8']
 with stdout.open('x') as out,stderr.open('x') as err:
  child=subprocess.Popen(argv,stdout=out,stderr=err);r['pending']={'case':name,'pid':child.pid,'command':argv};b.write(output,r)
  while True:
   try:code=child.wait(timeout=30);break
   except subprocess.TimeoutExpired:print('Waiting on same heap-telemetry process',child.pid,flush=True)
 assert code==0,stderr.read_text();result=json.loads(stdout.read_text().strip().splitlines()[-1]);assert result['status']=='ok',result
 assert result['allocator_self_test_passed'] and result['samples_seconds']==[] and len(result['diagnostics'])==8
 assert result['report']==reference['cases'][name]['actors']['candidate']['execution_report']
 validation=[b.validate(result['values'],cases[name]['expected'])]
 records=result['diagnostics']
 for row in records:
  validation.append(b.validate(row['values'],cases[name]['expected']))
  assert row['report']==result['report']
  assert row['managed_admission_bytes_before']==row['managed_admission_bytes_after_drop']
  assert row['peak_live_rust_requested_bytes']>=row['baseline_live_rust_requested_bytes']
  assert row['peak_additional_live_rust_requested_bytes']==row['peak_live_rust_requested_bytes']-row['baseline_live_rust_requested_bytes']
 fields=['allocation_requests','reallocation_requests','total_requested_bytes','deallocation_calls','peak_additional_live_rust_requested_bytes','retained_rust_delta_bytes','managed_admission_bytes_before','managed_admission_bytes_with_output','managed_nodes_with_output','managed_snapshot_nodes_with_output']
 summary={field:{'minimum':min(row[field] for row in records),'median':statistics.median(row[field] for row in records),'maximum':max(row[field] for row in records)} for field in fields}
 rss=re.search(r'^\s*(\d+)\s+maximum resident set size\s*$',stderr.read_text(),re.M);assert rss
 r['cases'][name]={'source_sha256':b.digest(b.FIXTURE/f'{name}.mec'),'input_sha256':b.digest(config),'stdout_sha256':b.digest(stdout),'stderr_sha256':b.digest(stderr),'command':argv,'allocator_self_test_passed':True,'calls':8,'summary':summary,'process_maximum_resident_set_size_bytes':int(rss.group(1)),'finite_validations':validation,'all_counters_match_frozen_candidate':True,'managed_cleanup_passed':True};r['pending']=None;b.write(output,r)
 print(name,'allocations',summary['allocation_requests']['median'],'requested_bytes',summary['total_requested_bytes']['median'],'peak_additional_requested_heap',summary['peak_additional_live_rust_requested_bytes']['maximum'],flush=True)
r.update(complete=len(r['cases'])==15,completed_at=b.utc(),all_finite_validations=sum(sum(v['count'] for v in c['finite_validations']) for c in r['cases'].values()),source_and_history_unchanged=fp==b.compiler_fingerprint() and history_hash==b.digest(b.FIXTURE/'performance-history.json'))
assert r['complete'] and r['source_and_history_unchanged'];b.write(output,r);print(json.dumps({'complete':True,'cases':15,'diagnostic_checked_calls':120,'formal_performance_observations':0,'finite_cell_comparisons':r['all_finite_validations']}),flush=True)
