from pathlib import Path
import json,tomllib
root=Path.cwd();folder=Path(__file__).resolve().parent;crate=folder/'probe';(crate/'src').mkdir(parents=True)
gpu=tomllib.loads((root/'hosts/gpu/Cargo.toml').read_text());workspace=tomllib.loads((root/'Cargo.toml').read_text())
lines=['[package]','name = "polybench-heap-telemetry"','version = "0.1.0"','edition = "2024"','','[workspace]','','[dependencies]']
lines.append('mech-gpu = { path = '+json.dumps(str(root/'hosts/gpu'))+', default-features = false, features = ["canonical-native-program"] }')
for name in ['mech-core','mech-engine','mech-stdlib','mech-syntax','mech-runtime','mech-build']:
 spec=gpu['dev-dependencies'][name];path=(root/'hosts/gpu'/spec['path']).resolve();lines.append(name+' = { path = '+json.dumps(str(path))+', default-features = false, features = '+json.dumps(spec['features'])+' }')
lines+=['serde_json = { version = "1.0", features = ["raw_value"] }','tempfile = "3.26.0"','','[patch.crates-io]']
for name,spec in workspace['patch']['crates-io'].items():
 assert set(spec)=={'path'};lines.append(name+' = { path = '+json.dumps(str((root/spec['path']).resolve()))+' }')
lines+=['','[profile.release]','debug = false'];(crate/'Cargo.toml').write_text('\n'.join(lines)+'\n')
source=(root/'hosts/gpu/examples/polybench_qualification.rs').read_text()
probe=r'''
mod heap_probe {
 use std::alloc::{GlobalAlloc,Layout,System};
 use std::sync::atomic::{AtomicBool,AtomicUsize,Ordering};
 static ACTIVE:AtomicBool=AtomicBool::new(false);
 static LIVE:AtomicUsize=AtomicUsize::new(0);
 static PEAK:AtomicUsize=AtomicUsize::new(0);
 static REQUESTS:AtomicUsize=AtomicUsize::new(0);
 static REALLOCS:AtomicUsize=AtomicUsize::new(0);
 static REQUESTED:AtomicUsize=AtomicUsize::new(0);
 static RELEASES:AtomicUsize=AtomicUsize::new(0);
 pub struct Allocator;
 fn add(size:usize,realloc:bool) {
  let current=LIVE.fetch_add(size,Ordering::Relaxed)+size;
  if ACTIVE.load(Ordering::Relaxed) {REQUESTS.fetch_add(1,Ordering::Relaxed);REQUESTED.fetch_add(size,Ordering::Relaxed);if realloc {REALLOCS.fetch_add(1,Ordering::Relaxed);}PEAK.fetch_max(current,Ordering::Relaxed);}
 }
 fn remove(size:usize,release:bool) {
  LIVE.fetch_sub(size,Ordering::Relaxed);
  if release && ACTIVE.load(Ordering::Relaxed) {RELEASES.fetch_add(1,Ordering::Relaxed);}
 }
 // SAFETY: all requests and layouts are forwarded unchanged to System. Atomic
 // counters describe successful requested Rust heap storage; they never access
 // allocation contents, confer ownership or affect Mech's resource admission.
 unsafe impl GlobalAlloc for Allocator {
  unsafe fn alloc(&self,l:Layout)->*mut u8 {let p=unsafe{System.alloc(l)};if !p.is_null(){add(l.size(),false);}p}
  unsafe fn alloc_zeroed(&self,l:Layout)->*mut u8 {let p=unsafe{System.alloc_zeroed(l)};if !p.is_null(){add(l.size(),false);}p}
  unsafe fn realloc(&self,p:*mut u8,l:Layout,n:usize)->*mut u8 {let q=unsafe{System.realloc(p,l,n)};if !q.is_null(){remove(l.size(),false);add(n,true);}q}
  unsafe fn dealloc(&self,p:*mut u8,l:Layout){remove(l.size(),true);unsafe{System.dealloc(p,l)}}
 }
 #[derive(Debug)]pub struct Stats {pub requests:usize,pub reallocations:usize,pub requested_bytes:usize,pub deallocations:usize,pub baseline_live:usize,pub peak_live:usize,pub ending_live:usize}
 pub fn live()->usize{LIVE.load(Ordering::Relaxed)}
 #[inline(never)]pub fn measured<T>(run:impl FnOnce()->T)->(T,Stats){
  assert!(!ACTIVE.load(Ordering::Relaxed));let baseline=live();PEAK.store(baseline,Ordering::Relaxed);REQUESTS.store(0,Ordering::Relaxed);REALLOCS.store(0,Ordering::Relaxed);REQUESTED.store(0,Ordering::Relaxed);RELEASES.store(0,Ordering::Relaxed);
  ACTIVE.store(true,Ordering::SeqCst);let result=run();ACTIVE.store(false,Ordering::SeqCst);
  let stats=Stats{requests:REQUESTS.load(Ordering::Relaxed),reallocations:REALLOCS.load(Ordering::Relaxed),requested_bytes:REQUESTED.load(Ordering::Relaxed),deallocations:RELEASES.load(Ordering::Relaxed),baseline_live:baseline,peak_live:PEAK.load(Ordering::Relaxed),ending_live:live()};(result,stats)
 }
 pub fn self_test(){
  let baseline=live();
  let (_,s)=measured(||unsafe{let l=Layout::from_size_align(4096,8).unwrap();let p=std::alloc::alloc(l);assert!(!p.is_null());p.write_volatile(7);std::hint::black_box(p);std::alloc::dealloc(p,l)});
  assert_eq!((s.requests,s.requested_bytes,s.peak_live-s.baseline_live,s.ending_live),(1,4096,4096,baseline));
  let (_,s)=measured(||unsafe{let l=Layout::from_size_align(4096,8).unwrap();let p=std::alloc::alloc(l);assert!(!p.is_null());let q=std::alloc::realloc(p,l,8192);assert!(!q.is_null());q.write_volatile(9);std::hint::black_box(q);std::alloc::dealloc(q,Layout::from_size_align(8192,8).unwrap())});
  assert_eq!((s.requests,s.reallocations,s.requested_bytes,s.peak_live-s.baseline_live,s.ending_live),(2,1,12288,8192,baseline));
  let (value,s)=measured(||vec![std::hint::black_box(1u64);64]);assert_eq!((s.requests,s.requested_bytes,s.peak_live-s.baseline_live,s.ending_live-baseline),(1,512,512,512));std::hint::black_box(&value);drop(value);assert_eq!(live(),baseline);
 }
}
#[global_allocator]static HEAP_ALLOCATOR:heap_probe::Allocator=heap_probe::Allocator;
'''
assert source.count('fn err(')==1;source=source.replace('fn err(',probe+'\nfn err(',1)
source=source.replace('fn run() -> Result<Json, String> {','fn run() -> Result<Json, String> {\n    heap_probe::self_test();',1)
start=source.index('    let mut times = Vec::new();');end=source.index('    Ok(\n',start)
replacement=r'''
    output.fill(None);
    let baseline_managed=memory.used_bytes();
    let mut diagnostics=Vec::with_capacity(samples);
    for index in 0..samples {
        output.fill(None);
        let managed_before=memory.used_bytes();
        let (result,heap)=heap_probe::measured(||jit.evaluate_into(black_box(&args),black_box(&mut output),limits,&memory));
        let current_report=result.map_err(err)?;
        let managed_with_output=memory.used_bytes();
        let retained_nodes=memory.retained_nodes();
        let snapshot_nodes=memory.retained_snapshot_nodes();
        let mut liveouts=Vec::new();
        numbers(&output.last().ok_or("no output")?.as_ref().unwrap().canonical_data_draft().map_err(err)?,&mut liveouts)?;
        output.fill(None);
        let managed_after_drop=memory.used_bytes();
        if managed_before!=baseline_managed || managed_after_drop!=baseline_managed{return Err(format!("managed cleanup drift before={managed_before} after={managed_after_drop} baseline={baseline_managed}"));}
        diagnostics.push(json!({"call":index,"allocation_requests":heap.requests,"reallocation_requests":heap.reallocations,"total_requested_bytes":heap.requested_bytes,"deallocation_calls":heap.deallocations,"baseline_live_rust_requested_bytes":heap.baseline_live,"peak_live_rust_requested_bytes":heap.peak_live,"peak_additional_live_rust_requested_bytes":heap.peak_live.saturating_sub(heap.baseline_live),"ending_live_rust_requested_bytes":heap.ending_live,"retained_rust_delta_bytes":heap.ending_live as i64-heap.baseline_live as i64,"managed_admission_bytes_before":managed_before,"managed_admission_bytes_with_output":managed_with_output,"managed_admission_bytes_after_drop":managed_after_drop,"managed_nodes_with_output":retained_nodes,"managed_snapshot_nodes_with_output":snapshot_nodes,"values":liveouts,"report":format!("{current_report:?}")}));
    }
'''
source=source[:start]+replacement+source[end:]
assert source.count('"samples_seconds":times')==1
source=source.replace('"samples_seconds":times','"samples_seconds":[],"diagnostics":diagnostics,"allocator_self_test_passed":true,"measurement_scope":"Rust GlobalAlloc requested heap bytes during evaluate_into only, excluding compilation, inputs, validation and output release; allocator rounding, foreign allocations, executable mmap and internal realloc transient backing are excluded. Diagnostic execution only; no timing samples."')
(crate/'src/main.rs').write_text(source)
print('Prepared external host-only allocator telemetry; canonical compiler sources and official driver unchanged.')
