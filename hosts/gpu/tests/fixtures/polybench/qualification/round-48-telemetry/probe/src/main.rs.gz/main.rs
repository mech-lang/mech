//! Canonical PolyBench source qualification and checked-call timing driver.
use mech_core::ReactiveInstanceId;
use mech_core::{
    ManagedMemoryBudget, MemoryBudgetLimits, Value, ValueDataDraft as Data,
    snapshot::{F64Bits, SnapshotValidationContext, ValueDraft},
};
use mech_engine::{
    CanonicalSourceFrontend, ProgramArtifact,
    resident::{ActivationFacts, CapturedValueInput, activate},
};
use mech_gpu::native_artifact::{
    JitProgramArtifact, NativeExecutionLimits, NativeProgramExecutionLimits,
};
use mech_syntax::document::{
    AstNode, DocumentId, DocumentSyntax, ParseConfig, Revision, TextSnapshot,
    parse_canonical_document,
};
use serde_json::{Value as Json, json};
use std::{hint::black_box, time::Instant};

mod heap_probe {
    use std::alloc::{GlobalAlloc, Layout, System};
    use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
    static ACTIVE: AtomicBool = AtomicBool::new(false);
    static LIVE: AtomicUsize = AtomicUsize::new(0);
    static PEAK: AtomicUsize = AtomicUsize::new(0);
    static REQUESTS: AtomicUsize = AtomicUsize::new(0);
    static REALLOCS: AtomicUsize = AtomicUsize::new(0);
    static REQUESTED: AtomicUsize = AtomicUsize::new(0);
    static RELEASES: AtomicUsize = AtomicUsize::new(0);
    pub struct Allocator;
    fn add(size: usize, realloc: bool) {
        let current = LIVE.fetch_add(size, Ordering::Relaxed) + size;
        if ACTIVE.load(Ordering::Relaxed) {
            REQUESTS.fetch_add(1, Ordering::Relaxed);
            REQUESTED.fetch_add(size, Ordering::Relaxed);
            if realloc {
                REALLOCS.fetch_add(1, Ordering::Relaxed);
            }
            PEAK.fetch_max(current, Ordering::Relaxed);
        }
    }
    fn remove(size: usize, release: bool) {
        LIVE.fetch_sub(size, Ordering::Relaxed);
        if release && ACTIVE.load(Ordering::Relaxed) {
            RELEASES.fetch_add(1, Ordering::Relaxed);
        }
    }
    // SAFETY: all requests and layouts are forwarded unchanged to System. Atomic
    // counters describe successful requested Rust heap storage; they never access
    // allocation contents, confer ownership or affect Mech's resource admission.
    unsafe impl GlobalAlloc for Allocator {
        unsafe fn alloc(&self, l: Layout) -> *mut u8 {
            let p = unsafe { System.alloc(l) };
            if !p.is_null() {
                add(l.size(), false);
            }
            p
        }
        unsafe fn alloc_zeroed(&self, l: Layout) -> *mut u8 {
            let p = unsafe { System.alloc_zeroed(l) };
            if !p.is_null() {
                add(l.size(), false);
            }
            p
        }
        unsafe fn realloc(&self, p: *mut u8, l: Layout, n: usize) -> *mut u8 {
            let q = unsafe { System.realloc(p, l, n) };
            if !q.is_null() {
                remove(l.size(), false);
                add(n, true);
            }
            q
        }
        unsafe fn dealloc(&self, p: *mut u8, l: Layout) {
            remove(l.size(), true);
            unsafe { System.dealloc(p, l) }
        }
    }
    #[derive(Debug)]
    pub struct Stats {
        pub requests: usize,
        pub reallocations: usize,
        pub requested_bytes: usize,
        pub deallocations: usize,
        pub baseline_live: usize,
        pub peak_live: usize,
        pub ending_live: usize,
    }
    pub fn live() -> usize {
        LIVE.load(Ordering::Relaxed)
    }
    #[inline(never)]
    pub fn measured<T>(run: impl FnOnce() -> T) -> (T, Stats) {
        assert!(!ACTIVE.load(Ordering::Relaxed));
        let baseline = live();
        PEAK.store(baseline, Ordering::Relaxed);
        REQUESTS.store(0, Ordering::Relaxed);
        REALLOCS.store(0, Ordering::Relaxed);
        REQUESTED.store(0, Ordering::Relaxed);
        RELEASES.store(0, Ordering::Relaxed);
        ACTIVE.store(true, Ordering::SeqCst);
        let result = run();
        ACTIVE.store(false, Ordering::SeqCst);
        let stats = Stats {
            requests: REQUESTS.load(Ordering::Relaxed),
            reallocations: REALLOCS.load(Ordering::Relaxed),
            requested_bytes: REQUESTED.load(Ordering::Relaxed),
            deallocations: RELEASES.load(Ordering::Relaxed),
            baseline_live: baseline,
            peak_live: PEAK.load(Ordering::Relaxed),
            ending_live: live(),
        };
        (result, stats)
    }
    pub fn self_test() {
        let baseline = live();
        let (_, s) = measured(|| unsafe {
            let l = Layout::from_size_align(4096, 8).unwrap();
            let p = std::alloc::alloc(l);
            assert!(!p.is_null());
            p.write_volatile(7);
            std::hint::black_box(p);
            std::alloc::dealloc(p, l)
        });
        assert_eq!(
            (
                s.requests,
                s.requested_bytes,
                s.peak_live - s.baseline_live,
                s.ending_live
            ),
            (1, 4096, 4096, baseline)
        );
        let (_, s) = measured(|| unsafe {
            let l = Layout::from_size_align(4096, 8).unwrap();
            let p = std::alloc::alloc(l);
            assert!(!p.is_null());
            let q = std::alloc::realloc(p, l, 8192);
            assert!(!q.is_null());
            q.write_volatile(9);
            std::hint::black_box(q);
            std::alloc::dealloc(q, Layout::from_size_align(8192, 8).unwrap())
        });
        assert_eq!(
            (
                s.requests,
                s.reallocations,
                s.requested_bytes,
                s.peak_live - s.baseline_live,
                s.ending_live
            ),
            (2, 1, 12288, 8192, baseline)
        );
        let (value, s) = measured(|| vec![std::hint::black_box(1u64); 64]);
        assert_eq!(
            (
                s.requests,
                s.requested_bytes,
                s.peak_live - s.baseline_live,
                s.ending_live - baseline
            ),
            (1, 512, 512, 512)
        );
        std::hint::black_box(&value);
        drop(value);
        assert_eq!(live(), baseline);
    }
}
#[global_allocator]
static HEAP_ALLOCATOR: heap_probe::Allocator = heap_probe::Allocator;

fn err(e: impl std::fmt::Debug) -> String {
    format!("{e:?}")
}
fn numbers(data: &Data, out: &mut Vec<Json>) -> Result<(), String> {
    match data {
        Data::F64(v) => out.push(if v.to_f64().is_finite() {
            json!(v.to_f64())
        } else {
            json!(format!("{}", v.to_f64()))
        }),
        Data::U64(v) => out.push(json!(v)),
        Data::I64(v) => out.push(json!(v)),
        Data::Matrix(v) | Data::Tuple(v) => {
            for x in v.iter() {
                numbers(x, out)?;
            }
        }
        _ => return Err(format!("unsupported output: {data:?}")),
    }
    Ok(())
}
fn inputs(
    artifact: &ProgramArtifact,
    config: &Json,
    memory: &ManagedMemoryBudget,
) -> Result<Vec<Value>, String> {
    artifact
        .inputs()
        .iter()
        .map(|input| {
            let name = mech_engine::decode_source_input_name(&input.name)
                .ok_or_else(|| format!("invalid source input {}", input.name))?;
            let spec = config
                .get(&name)
                .ok_or_else(|| format!("missing input {name}"))?;
            let schema = artifact.schemas().get(input.schema).unwrap();
            let (data, shape_values) = if let Some(values) = spec.get("values") {
                let data = Data::Matrix(
                    values
                        .as_array()
                        .unwrap()
                        .iter()
                        .map(|v| Data::F64(F64Bits::from_f64(v.as_f64().unwrap())))
                        .collect(),
                );
                let dims: Vec<u64> = spec["shape"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .map(|v| v.as_u64().unwrap())
                    .collect();
                let shape = mech_core::shape_for_resolved_extents(schema, &dims)
                    .map_err(err)?
                    .parameter_values()
                    .to_vec()
                    .into_boxed_slice();
                (data, shape)
            } else if spec.get("u64").is_some() {
                (
                    Data::U64(spec["u64"].as_u64().unwrap()),
                    Box::new([]) as Box<[u64]>,
                )
            } else {
                (
                    Data::F64(F64Bits::from_f64(spec.as_f64().unwrap())),
                    Box::new([]) as Box<[u64]>,
                )
            };
            let value = ValueDraft {
                schema: input.schema,
                shape_values,
                data,
            }
            .finalize(&SnapshotValidationContext::new(artifact.schemas()))
            .map_err(err)?;
            let mut reservation = memory
                .reserve_capacity(value.memory_budget_admission_bytes(memory).map_err(err)?)
                .map_err(err)?;
            value.into_memory_budget(&mut reservation).map_err(err)
        })
        .collect()
}
fn run() -> Result<Json, String> {
    heap_probe::self_test();
    let args: Vec<_> = std::env::args().collect();
    if !(3..=5).contains(&args.len()) {
        return Err(
            "usage: polybench_qualification SOURCE.mec INPUTS.json [SAMPLES] [resident-reference|emit-object=PATH]"
                .into(),
        );
    }
    if args
        .get(4)
        .is_some_and(|mode| mode != "resident-reference" && !mode.starts_with("emit-object="))
    {
        return Err("the optional mode must be resident-reference or emit-object=PATH".into());
    }
    let source = std::fs::read_to_string(&args[1]).map_err(err)?;
    let config: Json =
        serde_json::from_slice(&std::fs::read(&args[2]).map_err(err)?).map_err(err)?;
    let samples: usize = args
        .get(3)
        .map(|x| x.parse())
        .transpose()
        .map_err(err)?
        .unwrap_or(0);
    let catalog_start = Instant::now();
    let catalog = mech_stdlib::source_catalog();
    let catalog_seconds = catalog_start.elapsed().as_secs_f64();
    let start = Instant::now();
    let parsed = parse_canonical_document(
        TextSnapshot::new(DocumentId(0x504f4c59), Revision(1), source.as_str()).map_err(err)?,
        ParseConfig::default(),
    );
    if !parsed.is_strictly_clean() {
        return Err(format!("parse: {:?}", parsed.diagnostics));
    }
    let syntax = DocumentSyntax::cast(parsed.syntax()).unwrap();
    let product = CanonicalSourceFrontend
        .compile_document_with_catalog(&syntax, catalog.clone())
        .map_err(|e| format!("frontend: {e:?}"))?;
    let artifact = product
        .compile_artifact()
        .map_err(|e| format!("artifact: {e:?}"))?;
    let frontend_seconds = start.elapsed().as_secs_f64();
    if let Some(path) = args
        .get(4)
        .and_then(|mode| mode.strip_prefix("emit-object="))
    {
        if path.is_empty() {
            return Err("Object output path is empty".into());
        }
        let object =
            mech_gpu::native_artifact::emit_program_object(&artifact, &catalog).map_err(err)?;
        let path = std::path::Path::new(path);
        std::fs::write(path, object.bytes()).map_err(err)?;
        std::fs::write(
            path.with_extension("metadata.json"),
            serde_json::to_vec_pretty(&object.metadata()).map_err(err)?,
        )
        .map_err(err)?;
        return Ok(
            json!({"status":"ok","mode":"emit-object","path":path,"metadata":path.with_extension("metadata.json")}),
        );
    }
    let memory = ManagedMemoryBudget::new(2 * 1024 * 1024 * 1024);
    let args_values = inputs(&artifact, &config, &memory)?;
    if args.get(4).map(String::as_str) == Some("resident-reference") {
        let mut instance = activate(
            ReactiveInstanceId::new(0x504f4c59, 0),
            &artifact,
            &catalog,
            &ActivationFacts::default(),
        )
        .map_err(err)?;
        let captured = instance
            .plan
            .inputs
            .iter()
            .map(|input| CapturedValueInput {
                slot: input.slot,
                value: &args_values[artifact
                    .inputs()
                    .iter()
                    .position(|v| v.slot == input.artifact_slot)
                    .unwrap()],
            })
            .collect::<Vec<_>>();
        instance
            .prepare_turn_values(&captured)
            .map_err(err)?
            .publish()
            .map_err(err)?;
        let mut values = Vec::new();
        numbers(
            &instance
                .copied_output(artifact.outputs().len() - 1)
                .map_err(err)?
                .canonical_data_draft()
                .map_err(err)?,
            &mut values,
        )?;
        return Ok(
            json!({"status":"ok","mode":"resident-reference-only","frontend_seconds":frontend_seconds,"values":values}),
        );
    }
    let start = Instant::now();
    let jit = JitProgramArtifact::compile(&artifact, &catalog).map_err(|e| {
        let diagnostic = std::path::Path::new(&args[2]).with_extension("artifact-nodes.txt");
        let _ = std::fs::write(diagnostic, format!("{:#?}", artifact.nodes()));
        format!("native: {e:?}")
    })?;
    let native_seconds = start.elapsed().as_secs_f64();
    let args = args_values;
    let cap = 1_000_000_000_000_000u64;
    let limits = NativeProgramExecutionLimits {
        execution: NativeExecutionLimits {
            max_work: cap,
            max_transport_bytes: 2 * 1024 * 1024 * 1024,
            max_native_stack_bytes: 64 * 1024 * 1024,
        },
        library: MemoryBudgetLimits {
            max_output_elements: Some(100_000_000),
            max_output_bytes: Some(2 * 1024 * 1024 * 1024),
            max_temporary_bytes: Some(2 * 1024 * 1024 * 1024),
            max_cloned_bytes: Some(cap),
            max_retained_nodes: Some(100_000_000),
            max_comparison_work: Some(cap),
            max_compute_work: Some(cap),
            max_scalar_instructions: Some(cap),
            max_transfer_bytes: Some(cap),
            max_storage_buffer_bytes: Some(2 * 1024 * 1024 * 1024),
            max_storage_bindings: Some(100_000),
        },
    };
    let mut output = vec![None; artifact.outputs().len()];
    let report = jit
        .evaluate_into(&args, &mut output, limits, &memory)
        .map_err(|e| format!("execution: {e:?}"))?;
    let mut values = Vec::new();
    numbers(
        &output
            .last()
            .ok_or("no outputs")?
            .as_ref()
            .unwrap()
            .canonical_data_draft()
            .map_err(err)?,
        &mut values,
    )?;

    output.fill(None);
    let baseline_managed = memory.used_bytes();
    let mut diagnostics = Vec::with_capacity(samples);
    for index in 0..samples {
        output.fill(None);
        let managed_before = memory.used_bytes();
        let (result, heap) = heap_probe::measured(|| {
            jit.evaluate_into(black_box(&args), black_box(&mut output), limits, &memory)
        });
        let current_report = result.map_err(err)?;
        let managed_with_output = memory.used_bytes();
        let retained_nodes = memory.retained_nodes();
        let snapshot_nodes = memory.retained_snapshot_nodes();
        let mut liveouts = Vec::new();
        numbers(
            &output
                .last()
                .ok_or("no output")?
                .as_ref()
                .unwrap()
                .canonical_data_draft()
                .map_err(err)?,
            &mut liveouts,
        )?;
        output.fill(None);
        let managed_after_drop = memory.used_bytes();
        if managed_before != baseline_managed || managed_after_drop != baseline_managed {
            return Err(format!(
                "managed cleanup drift before={managed_before} after={managed_after_drop} baseline={baseline_managed}"
            ));
        }
        diagnostics.push(json!({"call":index,"allocation_requests":heap.requests,"reallocation_requests":heap.reallocations,"total_requested_bytes":heap.requested_bytes,"deallocation_calls":heap.deallocations,"baseline_live_rust_requested_bytes":heap.baseline_live,"peak_live_rust_requested_bytes":heap.peak_live,"peak_additional_live_rust_requested_bytes":heap.peak_live.saturating_sub(heap.baseline_live),"ending_live_rust_requested_bytes":heap.ending_live,"retained_rust_delta_bytes":heap.ending_live as i64-heap.baseline_live as i64,"managed_admission_bytes_before":managed_before,"managed_admission_bytes_with_output":managed_with_output,"managed_admission_bytes_after_drop":managed_after_drop,"managed_nodes_with_output":retained_nodes,"managed_snapshot_nodes_with_output":snapshot_nodes,"values":liveouts,"report":format!("{current_report:?}")}));
    }
    Ok(
        json!({"status":"ok","catalog_seconds":catalog_seconds,"frontend_seconds":frontend_seconds,"native_seconds":native_seconds,"values":values,"samples_seconds":[],"diagnostics":diagnostics,"allocator_self_test_passed":true,"measurement_scope":"Rust GlobalAlloc requested heap bytes during evaluate_into only, excluding compilation, inputs, validation and output release; allocator rounding, foreign allocations, executable mmap and internal realloc transient backing are excluded. Diagnostic execution only; no timing samples.","report":format!("{report:?}"),"inputs":artifact.inputs().iter().map(|i|&i.name).collect::<Vec<_>>() }),
    )
}
fn main() {
    let result = match std::panic::catch_unwind(run) {
        Ok(Ok(v)) => v,
        Ok(Err(e)) => json!({"status":"error","error":e}),
        Err(_) => json!({"status":"error","error":"compiler panic"}),
    };
    println!("{result}");
}
