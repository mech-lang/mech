import hashlib,json,re
from pathlib import Path
root=Path('/Users/cim310/.codex/worktrees/polybench-pr1000/mech')
fixture=root/'hosts/gpu/tests/fixtures/polybench'
suite=Path('/Users/cim310/mech-lang/benchmarks/experiments/polybench/pr1000-20261125/vendor/polybench-c-4.2.1-beta')
cases=json.loads((fixture/'cases.json').read_text())['cases']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def uncomment_c(text):
 pat=r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|/\*[\s\S]*?\*/|//[^\n]*'
 return re.sub(pat,lambda m: '\n'*m[0].count('\n') if m[0].startswith(('/*','//')) else m[0],text)
def loc(text):return sum(bool(line.strip()) for line in text.splitlines())
rows=[]
for case in cases:
 name=case['name'];m=fixture/f'{name}.mec';c=suite/case['upstream_c_path']
 assert sha(m)==case['mech_sha256'] and sha(c)==case['upstream_c_sha256']
 mt=m.read_text();ct=c.read_text();clean=uncomment_c(ct)
 matches=list(re.finditer(r'(?m)^[ \t]*(?:static\s+)?void\s+kernel_\w+\s*\(',clean));assert len(matches)==1,(name,len(matches))
 start=matches[0].start();opening=clean.index('{',matches[0].end());depth=1;end=opening+1
 while depth:
  if clean[end]=='{':depth+=1
  elif clean[end]=='}':depth-=1
  end+=1
 kernel=clean[start:end]
 code_m='\n'.join(line for line in mt.splitlines() if not line.lstrip().startswith('--'))
 a=loc(code_m);b=loc(kernel)
 rows.append({'benchmark':name,'mech_code_lines':a,'c_kernel_code_lines':b,'c_kernel_over_mech':b/a,'c_file_code_lines':loc(clean),'mech_physical_lines':len(mt.splitlines()),'c_file_physical_lines':len(ct.splitlines()),'mech_sha256':sha(m),'c_sha256':sha(c),'c_source_path':str(c),'c_kernel_first_line':clean.count('\n',0,start)+1,'c_kernel_last_line':clean.count('\n',0,end)+1})
rows.sort(key=lambda r:(-r['c_kernel_over_mech'],r['benchmark']))
totals={key:sum(r[key] for r in rows) for key in ['mech_code_lines','c_kernel_code_lines','c_file_code_lines','mech_physical_lines','c_file_physical_lines']};totals['c_kernel_over_mech']=totals['c_kernel_code_lines']/totals['mech_code_lines'];totals['c_file_over_mech']=totals['c_file_code_lines']/totals['mech_code_lines']
report={'definition':'Physical source lines containing code, excluding blank/comment-only lines, with original formatting retained. Mech includes every import, declaration, FSM, comprehension and final expression. C kernel is the complete kernel_* function, including signature, local declarations, braces and scop pragmas; excludes C init/print/main and shared headers. Full-C-file counts are also provided. All30 source hashes match the fixed benchmark corpus.','rows':rows,'totals':totals}
Path('/private/tmp/polybench-line-counts.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['definition']);print(json.dumps(totals))
print('| Program | Mech lines | C kernel lines | C / Mech |');print('|---|---:|---:|---:|')
for r in rows:print(f"| {r['benchmark']} | {r['mech_code_lines']} | {r['c_kernel_code_lines']} | {r['c_kernel_over_mech']:.2f}× |")
print(f"| **Total** | **{totals['mech_code_lines']}** | **{totals['c_kernel_code_lines']}** | **{totals['c_kernel_over_mech']:.2f}×** |")
