"""Inspect natural reduction loops in checked MVT Objects; never execute them."""
import hashlib,importlib.util,json,re
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def loops(path):
 functions={};current=None
 for line in path.read_text().splitlines():
  m=re.match(r'^[0-9a-f]+ <([^>]+)>:',line)
  if m:current=m[1];functions[current]=[];continue
  m=re.match(r'^\s*([0-9a-f]+):\s+([a-z][a-z0-9.]*)\s*(.*)$',line)
  if current and m:functions[current].append((int(m[1],16),m[2],m[3],line))
 results=[]
 for name,ins in functions.items():
  if not ins:continue
  addresses={a for a,_,_,_ in ins};leaders={ins[0][0]}
  def target(x):
   m=re.search(r'0x([0-9a-f]+)',x[2]);return int(m[1],16) if m else None
  def conditional(op):return op.startswith('b.') or op in ['cbz','cbnz','tbz','tbnz']
  def terminates(op):return op in ['b','br','ret','retab','brk','udf'] or conditional(op)
  for i,x in enumerate(ins):
   if terminates(x[1]):
    dest=target(x)
    if dest in addresses:leaders.add(dest)
    if i+1<len(ins):leaders.add(ins[i+1][0])
  blocks={};current=None
  for x in ins:
   if x[0] in leaders:current=x[0];blocks[current]=[]
   blocks[current].append(x)
  order=list(blocks);succ={}
  for i,at in enumerate(order):
   x=blocks[at][-1];op=x[1];dest=target(x);following=order[i+1:i+2]
   if op=='b':nexts=[dest]
   elif conditional(op):nexts=[dest]+following
   elif op in ['br','ret','retab','brk','udf']:nexts=[]
   else:nexts=following
   succ[at]={n for n in nexts if n in blocks}
  reachable=set();todo=[order[0]]
  while todo:
   at=todo.pop()
   if at in reachable:continue
   reachable.add(at);todo.extend(succ[at])
  pred={at:set() for at in reachable}
  for at in reachable:
   for nxt in succ[at]:pred[nxt].add(at)
  first=order[0];dom={at:({at} if at==first else set(reachable)) for at in reachable}
  changed=True
  while changed:
   changed=False
   for at in order:
    if at not in reachable or at==first:continue
    new={at}|set.intersection(*(dom[p] for p in pred[at]))
    if new!=dom[at]:dom[at]=new;changed=True
  for latch in reachable:
   for header in succ[latch]:
    if header>latch or header not in dom[latch]:continue
    nodes={header,latch};todo=[latch] if header!=latch else []
    while todo:
     at=todo.pop()
     for prior in pred[at]:
      if prior not in nodes:nodes.add(prior);todo.append(prior)
    body=sorted((x for at in nodes for x in blocks[at]),key=lambda x:x[0]);ops=[x[1] for x in body]
    if not(any(op.startswith('fmul') for op in ops) and any(op.startswith('fadd') for op in ops)):continue
    if any(op in ['blr','bl'] for op in ops) or len(body)>40:continue
    results.append({'function':name,'header':hex(header),'latch':hex(blocks[latch][-1][0]),'instructions':len(body),'udiv_instructions':sum(op=='udiv' for op in ops),'scalar_and_vector_opcodes':sorted(set(op for op in ops if op.startswith(('fmul','fadd')))),'assembly':[x[3] for x in body]})
 return results
if __name__=='__main__':
 q=b.read(folder/'qualification.json');assert b.compiler_fingerprint()==q['compiler_fingerprint']
 prior=folder.with_name('transpose-product-views')/'objects/mvt-candidate.disasm.txt';candidate=folder/'objects/mvt-candidate.disasm.txt'
 old=loops(prior);new=loops(candidate)
 assert old and new and len(old)==len(new)
 assert any(row['udiv_instructions'] for row in old) and all(row['udiv_instructions']==0 for row in new)
 report={'schema':'mech.polybench.product-geometry-emission.v1','scope':'Actual checked MVT Object natural arithmetic loops with original scalar/SIMD fmul+fadd, no helper calls and at most40 instructions. Diagnostic only, not sampled JIT attribution, linked execution or runtime prediction. Full disassembly retained.','compiler_fingerprint':q['compiler_fingerprint'],'prior_observed_fingerprint':'95bb12a9533b8bfc1d4c882997c028de7b38af122dae318f1c89ffe3bf6b1c15','prior_object_disassembly_sha256':b.digest(prior),'candidate_object_disassembly_sha256':b.digest(candidate),'prior_reduction_loops':old,'candidate_reduction_loops':new,'prior_udiv_inside_reductions':sum(row['udiv_instructions'] for row in old),'candidate_udiv_inside_reductions':sum(row['udiv_instructions'] for row in new),'pending_fields_identical_to_accepted47':b.read(folder/'focused-result.json')['pending_fields_identical_to_accepted47'],'performance_observations':0,'passed':True}
 b.write(folder/'geometry-emission.json',report)
 print(json.dumps({k:report[k] for k in ['passed','prior_udiv_inside_reductions','candidate_udiv_inside_reductions','performance_observations']}),flush=True)
