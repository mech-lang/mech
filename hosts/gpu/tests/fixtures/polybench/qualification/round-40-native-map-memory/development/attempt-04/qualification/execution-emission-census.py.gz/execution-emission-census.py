"""Inspect actual checked optimization Objects before any candidate timing."""
import hashlib,importlib.util,json,pathlib,re,subprocess
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
q=b.read(folder/'qualification.json');assert q['complete'] and b.compiler_fingerprint()==q['compiler_fingerprint'];driver=folder/'map-memory-driver';assert b.digest(driver)==q['driver_sha256']
protocol,cases=b.protocol();objects=folder/'execution-objects';objects.mkdir(exist_ok=False);old=pathlib.Path('/private/tmp/mech-polybench-optimization/round-31/inverse-bitcasts/objects')
def instructions(asm):
 functions={};name=None
 for line in asm.splitlines():
  m=re.match(r'^[0-9a-f]+ <_(.+)>:',line)
  if m:name=m[1];functions[name]=[]
  elif name and re.match(r'^\s*[0-9a-f]+:',line):functions[name].append(line)
 return functions
def stats(lines):
 return {'instructions':len(lines),'sha256':hashlib.sha256('\n'.join(lines).encode()).hexdigest(),'packed_loads':sum(bool(re.search(r'\b(?:ldr|ldp)\s+q\d+',line)) for line in lines),'packed_stores':sum(bool(re.search(r'\b(?:str|stp)\s+q\d+',line)) for line in lines),'fma':sum(bool(re.search(r'\b(?:fmadd|fmsub|fnmadd|fnmsub|fmla|fmls)\s+',line)) for line in lines)}
r={'schema':'mech.polybench.training-emission-census.v1','scope':'Real checked Object export for optimization15 only; Objects inspected, never linked/executed. No timing observations.','compiler_fingerprint':q['compiler_fingerprint'],'driver_sha256':q['driver_sha256'],'cases':{},'complete':False}
for name in protocol['optimization']:
 config=folder/f'{name}-inputs.json';b.write(config,cases[name]['inputs']);obj=objects/f'{name}.o'
 p=subprocess.run([str(driver),str(b.FIXTURE/f'{name}.mec'),str(config),'0','emit-object='+str(obj)],capture_output=True,text=True,check=True,timeout=180)
 result=json.loads(p.stdout.strip().splitlines()[-1]);assert result['status']=='ok' and result['mode']=='emit-object'
 metadata=b.read(obj.with_suffix('.metadata.json'));assert metadata['typed_ir_version']==405 and metadata['work_policy_version']==156 and metadata['abi_version']==47
 asm=subprocess.check_output(['/Library/Developer/CommandLineTools/usr/bin/llvm-objdump','--disassemble','--no-show-raw-insn',str(obj)],text=True);obj.with_suffix('.disasm.txt').write_text(asm)
 current=instructions(asm);before=instructions((old/f'{name}.disasm.txt').read_text());r['cases'][name]={'code_bytes':metadata['code_bytes'],'stack_bytes':metadata['stack_bytes'],'object_sha256':b.digest(obj),'metadata_sha256':b.digest(obj.with_suffix('.metadata.json')),'disassembly_sha256':b.digest(obj.with_suffix('.disasm.txt')),'functions':{k:stats(v) for k,v in current.items()},'accepted31_functions':{k:stats(v) for k,v in before.items()},'object_executed':False}
 b.write(folder/'execution-emission-census.json',r);print(name,'exported',flush=True)
target='mech_canonical_program_entry_v1_numeric_5';g=r['cases']['gramschmidt'];assert g['functions'][target]['sha256']!=g['accepted31_functions'][target]['sha256'];assert g['accepted31_functions'][target]['packed_loads']==g['accepted31_functions'][target]['packed_stores']==0
assert g['functions'][target]['packed_loads']>0 and g['functions'][target]['packed_stores']>0
source=pathlib.Path('/private/tmp/mech-polybench-optimization/round-38/hoisted-map-bounds/native-loop-census.py').read_text();needle="'loops':inner_rows,";assert needle in source
source=source.replace(needle,"'loops':inner_rows, 'all_loop_members':{lines[h][0]:[lines[i][0] for i in sorted(s)] for h,s in loops.items()}, 'instructions_by_address':{a:[op,args] for a,op,args in lines},")
ns={'__name__':'static_loop_census'};exec(compile(source,'preserved-native-loop-census.py','exec'),ns)
def loop_counts(asm):
 c=ns['measure'](asm,target);ops=c.pop('instructions_by_address');members=c.pop('all_loop_members');counts={}
 for h,addresses in members.items():
  for a in addresses:
   op,args=ops[a]
   if op=='cmp' and re.search(r', #(600|900)$',args):counts[str(a)]={'loop_header':h,'instruction':op+' '+args}
 c['literal_large_cell_bound_compares']=counts
 return c
before=loop_counts((old/'gramschmidt.disasm.txt').read_text());after=loop_counts((objects/'gramschmidt.disasm.txt').read_text());r['gramschmidt_loop_census']={'accepted31':before,'candidate':after}
# These literal whole-map bounds come from the closed source ranges, after
# current metadata checks. The independent guard tests establish authority.
r['literal_large_cell_compares_before']=len(before['literal_large_cell_bound_compares']);r['literal_large_cell_compares_after']=len(after['literal_large_cell_bound_compares'])
assert r['literal_large_cell_compares_after']>r['literal_large_cell_compares_before'], 'Actual map emission must retain literal source cardinality through its control frame.'
assert all(sum(f['fma'] for f in row['functions'].values())==0 for row in r['cases'].values())
r['changed_cases']=[name for name,row in r['cases'].items() if row['functions']!=row['accepted31_functions']];r['complete']=len(r['cases'])==15;r['new_performance_observations']=0
assert b.compiler_fingerprint()==q['compiler_fingerprint'];b.write(folder/'execution-emission-census.json',r)
print(json.dumps({'complete':True,'changed_cases':r['changed_cases'],'profiled_function':g['functions'][target],'literal_cell_compares_before':r['literal_large_cell_compares_before'],'literal_cell_compares_after':r['literal_large_cell_compares_after'],'new_fma':False,'performance_observations':0}),flush=True)
