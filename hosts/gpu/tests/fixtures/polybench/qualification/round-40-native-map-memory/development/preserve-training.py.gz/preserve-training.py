"""Preserve the complete qualified optimization-only map-memory experiment."""
import gzip,hashlib,importlib.util
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;q=b.read(folder/'qualification.json');census=b.read(folder/'execution-emission-census.json');probe=b.read(folder/'training-probe.json');fp=b.compiler_fingerprint()
assert q['complete'] and census['complete'] and probe['complete']
assert fp==q['compiler_fingerprint']==census['compiler_fingerprint']==probe['compiler_fingerprint'] and q['driver_sha256']==census['driver_sha256']==probe['driver_sha256']
assert all(c['exit_code']==0 for c in q['checks']);assert len(probe['cases'])==15 and sum(len(c['observations']) for c in probe['cases'].values())==210
assert probe['summary']['all_visits_match'] and probe['summary']['all_work_not_reduced']
dest=p/'qualification/round-40-native-map-memory/development';dest.mkdir(parents=True,exist_ok=False);archives={}
paths=[x for x in folder.iterdir() if x.is_file() and x.suffix in ('.py','.json','.log')]
paths += [x for a in sorted(folder.glob('attempt-*')) for x in a.rglob('*') if x.is_file()]
paths += [x for x in (folder/'execution-objects').rglob('*') if x.is_file()]
for path in sorted(paths):
 name=str(path.relative_to(folder));raw=path.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives[name]={'path':str(out.relative_to(p)),'sha256':hashlib.sha256(raw).hexdigest(),'compressed_sha256':b.digest(out)}
invariants=[
 'All30 unchanged Mech ports, fixed C binaries/flags/inputs, F64 MINI dataset, finite tolerances, limits, 15/15 split, primary objective and all timing/cache boundaries remain unchanged.',
 'Recover literal U64 range geometry from the actual sealed source cursor, guard actual current frame values once, then retain checked source start/cardinality and total element count in native SSA. Unknown/dynamic/overflow source facts retain dynamic emission. Source-language empty/backward literal rejection remains.',
 'A complete checked map still evaluates every source cell into the same private scratch bank before publication. Only the existing non-failing disjoint copy uses32-byte packed loads/stores plus exact byte tails. No FP arithmetic, reassociation, alignment promise, new owner or alias relaxation.',
 'Current loans/epochs/views, capacities, source error order, scalar Bool/U64/I64/F64 emission, finite memory/work admission, source visits, full original work/comparison bills, ordinary replay, aliases and atomic publication/retry remain.',
 'No new frame fields, helper ABI or runtime interpretation. Cranelift remains the sole Mech native generator. The source-independent packed copy is selected only at the already proved private map copy boundary.',
 'One prospective v2 optimization15 probe uses seven fresh processes per actor, interleaving accepted31/candidate with alternating pair order. Every observation, case and regression remains, without retries or exclusions.',
 'Holdout use is the aggregate acceptance gate after committed source/driver freeze. No holdout source diagnosis, profiling, per-case tuning or tolerance override.'
]
out=dict(q);out.update(schema='mech.polybench.training-qualification.v1',label='round40-native-map-memory',invariants=invariants,
 profiling_basis={'receipt':'training-experiments/native-map-memory-profile.json','scope':'Accepted31 optimization-only Gram PCs matched to checked native Object CFG loops.','target':'gramschmidt','accepted_mech_over_c':54.480156773281955,'execution_samples':225,'jit_self_samples':174,'copy_samples':31,'main_map_samples':110,'actual_codegen_check':'The exact profiled native function must change before timing, with packed private-copy loads/stores and increased source-literal large cell-bound comparisons retained in actual Object loops; no new FMA. Static counts do not establish runtime cost or input feasibility.'},
 total_unique_selected_checks=q['tests'],focused_selected_checks=sum(q['focused_checks']['passed_tests']),development_attempts=b.read(folder/'development-attempts.json'),development_archives=archives,
 limitations='F64 MINI CPU scope. The retained174 JIT samples are coarse. The historically exposed holdout is an aggregate acceptance control. Training selection is not a formal Mech/C score or promotion.',training_probe_summary=probe['summary'])
for suffix,value in [('training-qualification',out),('training-probe',probe),('emission-census',census),('training-selection',{'schema':'mech.polybench.training-selection.v2','compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'accepted_round':31,'policy':probe['policy'],'result':probe['summary'],'selected':probe['summary']['selected'],'formal_evaluation_started':False})]:
 path=p/f'round-40-{suffix}.json';assert not path.exists();b.write(path,value)
print({'compiler_fingerprint':fp,'archives':len(archives),'checks':q['tests'],'probe':probe['summary'],'formal_observations':0},flush=True)
