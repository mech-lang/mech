"""Preserve all development evidence and qualify source before any timing."""
import gzip,importlib.util,json,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;q=b.read(folder/'qualification.json');plan=b.read(folder/'plan.json');gate=b.read(folder/'untimed-counter-gate.json');emission=b.read(folder/'emission-census.json');fp=b.compiler_fingerprint()
assert b.command(['git','branch','--show-current'])=='codex/polybench-native-matrices'
assert q['complete'] and q['driver_build_complete'] and q['tests']>=744 and q['focused_checks']['passed_tests']==[19]
assert fp==q['compiler_fingerprint']==gate['compiler_fingerprint']==emission['compiler_fingerprint']
assert gate['complete'] and gate['passed'] and gate['finite_liveouts']==17002 and all(row['all_counters_match'] for row in gate['cases'].values())
assert emission['complete'] and emission['passed'] and emission['row_pairs_emitted'] and emission['no_new_fma']
assert b.digest(q['driver'])==q['driver_sha256'] and len(b.read(p/'performance-history.json')['entries'])==51
assert b.read(p/'performance-acceptance.json')['accepted_history_index']==50 and not (folder/'training-probe.json').exists()
paths=plan['source_paths'];changed=subprocess.check_output(['git','diff','--name-only',plan['source_parent'],'--'],text=True).splitlines();changed+=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines();actual=sorted({name for name in changed if name.endswith(('.rs','.toml')) or Path(name).name=='Cargo.lock'})
assert set(actual)<=set(paths) and actual and len(paths)==9 and all(b.digest(root/name)==q['source_sha256'][name] for name in paths)
source_snapshot=folder/'qualified-source';source_snapshot.mkdir(exist_ok=False)
for name in paths:
 out=source_snapshot/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((root/name).read_bytes())
(folder/'qualified-source.patch').write_bytes(subprocess.check_output(['git','diff',plan['source_parent'],'--',*paths]))
attempts=[{'path':str(f.relative_to(folder)),'sha256':b.digest(f),'result':b.read(f),'source_snapshot_files':len(list((f.parent/'source').rglob('*.gz')))} for f in sorted(folder.glob('attempt-*/focused-result.json'))]
assert attempts and attempts[-1]['result']['exit_code']==0 and attempts[-1]['result']['compiler_fingerprint']==fp
source_audit={'schema':'mech.polybench.product-row-pairs-source-audit.v1','compiler_fingerprint':fp,'reviewed':True,'passed':True,'arithmetic':'Each independent row/column-lane starts +0 and retains every original k-term separate multiply/add in order; no horizontal reduction, reassociation or FMA.','shared_work':'One actual RHS load serves two independent accumulator chains in a reached k iteration; current checked Objects include machine def/use load identities and independent add registers.','empty_and_bounds':'count0 exits before division/axis/addressing. Nonempty exact issued geometry has positive columns. Reached row/column pairs require remaining>=2; tails retain scalar paths. Per-cell source and output addresses remain within the exact prepared banks.','ownership_and_fees':'Original immutable owner/shape/issued-loan checks, full buffers/allocations, source fees, caps, prepare/finish and atomic publication unchanged. All O counters equal accepted50.','epilogues':'Each private result uses its actual row/column/index through existing epilogues. Nonfinite consumed intermediates cancel private output and replay original source with unchanged credit; output-row interleaving remains private.','ablation':'Private ProductRowPairs switch retains exact old flat product emitter for ordinary products and epilogues. No new runtime loan/frame/helper/layout or per-operation allocation.','limits_and_failure':'New ordered oracle, exact bits, row/column tails, matrix vectors, huge empty views, broadcast/overflow epilogues and finite/missing caps plus maintained physical/spent/forged frame/image/loan/interleaving/atomic cleanup/retry checks passed.','limitations':'Static instruction counts and actual shared load/accumulator identities, not retired hardware instructions or measured traffic. No runtime speedup inference before one prospective probe.'}
b.write(folder/'source-audit.json',source_audit)
dest=p/'qualification/round-51-ordered-product-row-pairs/development';dest.mkdir(parents=True,exist_ok=False);archives={}
for source in sorted(folder.rglob('*')):
 if not source.is_file() or '__pycache__' in source.parts or source==Path(q['driver']):continue
 name=str(source.relative_to(folder));raw=source.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives[name]={'path':str(out.relative_to(p)),'sha256':b.digest(source),'compressed_sha256':b.digest(out)}
receipt={'schema':'mech.polybench.ordered-product-row-pairs-development.v1','created_at':b.utc(),'complete':True,'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'qualification_manifest':q,'effective_plan':plan,'selection_policy_sha256':b.digest(p/'performance-selection-policy-v4.json'),'source_parent':plan['source_parent'],'source_sha256':q['source_sha256'],'actual_changed_source_paths':actual,'profiling_basis':plan['profiling_basis'],'invariants':plan['implementation'],'counter_gate':gate,'emission_census':emission,'source_audit':source_audit,'development_attempts':attempts,'failed_attempt_logs_and_receipts_preserved':True,'performance_observations':0,'archives':archives}
b.write(p/'training-experiments/ordered-product-row-pairs-development.json',receipt)
b.write(p/'training-experiments/ordered-product-row-pairs-training-schedule.json',b.read(folder/'training-probe-plan.json'))
b.write(p/'round-51-product-row-route-census.json',gate)
subprocess.run(['git','diff','--check'],check=True);subprocess.run(['git','add','--',*paths,str(p.relative_to(root))],check=True)
result=subprocess.run(['git','commit','-m','Qualify ordered product row pairs before optimization selection'],capture_output=True,text=True);(folder/'qualification-source-commit.log').write_text(result.stdout+result.stderr);assert result.returncode==0
head=b.command(['git','rev-parse','HEAD']);assert b.compiler_fingerprint()==fp and b.command(['git','status','--porcelain'])==''
b.write(folder/'qualification-source-commit.json',{'source_commit':head,'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'performance_observations':0,'archives_verified':len(archives),'clean':True})
print(json.dumps({'head':head,'compiler_fingerprint':fp,'broad_checks':q['tests'],'focused_checks':19,'archives':len(archives),'performance_observations':0,'clean':True}),flush=True)
