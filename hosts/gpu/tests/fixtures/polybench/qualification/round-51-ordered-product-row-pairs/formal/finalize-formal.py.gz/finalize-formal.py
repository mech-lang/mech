"""Preserve the formal run and execute the optimization-only v4 decision."""
import gzip,importlib.util,json,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;plan=b.read(folder/'plan.json');f=b.read(p/'round-51-frozen.json');q=b.read(p/'round-51-training-qualification.json');audit=b.read(p/'round-51-audit.json');progress=b.read(p/'round-51-progress.json');ledger=b.read(p/'performance-acceptance.json');decision=ledger['entries'][-1];fp=b.compiler_fingerprint()
assert b.command(['git','branch','--show-current'])=='codex/polybench-native-matrices'
assert b.command(['git','rev-parse','HEAD'])==f['source_commit']
assert fp==f['compiler_fingerprint']==q['compiler_fingerprint']
assert b.digest(q['driver'])==q['driver_sha256']==f['driver_sha256'] and all(b.digest(root/name)==digest for name,digest in q['source_sha256'].items())
assert b.read(folder/'formal-exit.json')['exit_code']==0 and audit['observations']==900 and audit['finite_liveouts']==29482 and audit['history_append_only']
assert len(b.read(p/'performance-history.json')['entries'])==52 and decision['compared_to_accepted_index']==50
accepted=decision['performance_gate']=='accepted'
assert accepted==(decision['scores']['optimization']<plan['accepted_scores']['optimization'])
assert ledger['accepted_history_index']==(51 if accepted else 50)
subprocess.run(['python3',str(root/'scripts/record-polybench-acceptance.py'),'--check']+(['--require-latest-accepted'] if accepted else []),check=True,capture_output=True)
qualification={'schema':'mech.polybench.optimization-qualification.v3','label':f['label'],'compiler_commit':f['source_commit'],'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'frozen_candidate_sha256':b.digest(p/'round-51-frozen.json'),'native_typed_ir_version':419,'native_work_policy_version':157,'native_abi_version':48,'dataset':'MINI','numeric_profile':'F64','comparison':{'rtol':1e-10,'atol':1e-9,'finite_required':True,'corpus_liveouts':29482},'checks':q['checks'],'broad_selected_checks':q['broad_selected_checks'],'focused_selected_checks':19,'restored_corpus':q['restored_corpus'],'both_feature_checks_passed':True,'source_sha256':q['source_sha256'],'training_qualification_sha256':b.digest(p/'round-51-training-qualification.json'),'training_selection_sha256':b.digest(p/'round-51-training-selection.json'),'training_probe_sha256':b.digest(p/'round-51-training-probe.json'),'route_census_sha256':b.digest(p/'round-51-product-row-route-census.json'),'source_work_comparison_never_reduced':True,'physical_visits':'Unchanged; all execution counters match accepted50 exactly. Every product output retains its original +0/k arithmetic; independent output rows share right loads and loop control.','invariants':q['invariants'],'formal_observations':900,'audit_sha256':b.digest(p/'round-51-audit.json'),'selection_policy_sha256':b.digest(p/'performance-selection-policy-v4.json'),'promotion':'Optimization15 strictly below accepted50 only; holdout independently reported and cannot veto/select/tune/trigger rollback or retry.'}
assert not (p/'round-51-qualification.json').exists();b.write(p/'round-51-qualification.json',qualification)
emission=b.read(folder/'emission-census.json');b.write(p/'round-51-static-telemetry.json',emission)
dest=p/'qualification/round-51-ordered-product-row-pairs/formal';dest.mkdir(parents=True,exist_ok=False);archives={}
for source in sorted(folder.rglob('*')):
 if not source.is_file() or '__pycache__' in source.parts or source==Path(q['driver']):continue
 name=str(source.relative_to(folder));raw=source.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives[name]={'path':str(out.relative_to(p)),'sha256':b.digest(source),'compressed_sha256':b.digest(out)}
receipt={'schema':'mech.polybench.compiler-experiment-formal.v1','created_at':b.utc(),'source_commit':f['source_commit'],'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'accepted_history_index':ledger['accepted_history_index'],'promoted':accepted,'selection_policy_sha256':b.digest(p/'performance-selection-policy-v4.json'),'decision':decision,'formal_observations':900,'finite_liveouts':29482,'training_observations':210,'formal_scores':decision['scores'],'controls_vs_accepted50':audit['aggregate_controls_vs_accepted50'],'source_and_protocol_unchanged_during_formal':True,'holdout_use':'Independent generalization report; not used for selection, tuning or rollback.','goal':progress['goal'],'qualification_path':'round-51-qualification.json','static_telemetry_path':'round-51-static-telemetry.json','archives':archives}
b.write(p/'training-experiments/ordered-product-row-pairs-formal.json',receipt)
if not accepted:
 subprocess.run(['git','restore','--source='+plan['source_parent'],'--worktree','--',*plan['source_paths']],check=True);subprocess.run(['git','add','-A','--',*plan['source_paths']],check=True)
 assert b.compiler_fingerprint()==plan['accepted_compiler_fingerprint']
with (p/'README.txt').open('a') as out:
 out.write('\nOrdered product row pairs: formal evaluation\n\n')
 out.write(f'General ordered products pair independent output rows, sharing right loads and k control while preserving each cell +0/k arithmetic, source fees, current owners, bounds, full buffers, existing epilogues and atomic completion. All{q["broad_selected_checks"]} broad/19 focused checks, both features, all30 original/decoded/restored C cases and the untimed optimization15 exact-fee/counter/Object gate passed.\n\n')
 out.write(f'One210-observation optimization-only probe selected; one frozen900-observation formal run matched29482 finite C liveouts and appended history52 without altering earlier entries. Formal optimization{decision["scores"]["optimization"]:.16f}x C, independent holdout{decision["scores"]["holdout"]:.16f}x C. V4 optimization-only decision: {decision["performance_gate"]}. Raw runtime and C/reference drift controls remain in round-51-audit.json. All observations and regressions are preserved, no retries/exclusions. '+('Compiler promoted to accepted51.' if accepted else 'Exact accepted50 compiler restored solely because optimization failed its strict formal score gate.')+'\n\n')
 out.write('[Qualification](round-51-qualification.json) · [Audit](round-51-audit.json) · [Progress](round-51-progress.json) · [Complete experiment](training-experiments/ordered-product-row-pairs-formal.json)\n')
subprocess.run(['git','diff','--check'],check=True);subprocess.run(['git','add','--','hosts/gpu/tests/fixtures/polybench'],check=True)
message=(f'Accept ordered product row pairs at {decision["scores"]["optimization"]:.2f}x optimization score' if accepted else 'Record product row pairs formal run and restore accepted50')
subprocess.run(['git','commit','-q','-m',message],check=True)
head=b.command(['git','rev-parse','HEAD']);assert b.command(['git','status','--porcelain'])==''
state=b.read(folder/'current-work.json');state.update(stage='Formal decision archived and committed; push pending',source_commit=head,compiler_fingerprint=b.compiler_fingerprint(),candidate_fingerprint=fp,accepted_round=51 if accepted else 50,accepted_scores=decision['scores'] if accepted else plan['accepted_scores'],formal_history_entries=52,formal_observations=900,performance_observations=1110,live_exec_session=None,complete=True);b.write(folder/'current-work.json',state)
print(json.dumps({'head':head,'promoted':accepted,'accepted_round':state['accepted_round'],'accepted_scores':state['accepted_scores'],'formal_candidate_scores':decision['scores'],'controls':audit['aggregate_controls_vs_accepted50'],'archives':len(archives),'clean':True,'goal':progress['goal']}),flush=True)
