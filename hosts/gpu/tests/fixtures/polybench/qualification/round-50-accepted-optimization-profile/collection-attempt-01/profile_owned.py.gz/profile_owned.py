"""Sample owned diagnostic children; capture only their named JIT code pages."""
import hashlib,json,os,pathlib,subprocess,time,lldb
folder=pathlib.Path(__file__).resolve().parent

def write(name,value):
 (folder/name).write_text(json.dumps(value,indent=2)+'\n')
def wait_for_state(process, wanted):
 while process.GetState() not in wanted:
  time.sleep(0.02)
 return process.GetState()
def run():
 plan=json.loads((folder/'plan.json').read_text());build=json.loads((folder/'residence-build.json').read_text());config=json.loads((folder/'profile-config.json').read_text())
 debugger=lldb.debugger;debugger.SetAsync(True)
 receipt={'scope':plan['method'],'compiler_fingerprint':build['compiler_fingerprint'],'driver_sha256':build['driver_sha256'],'cases':{},'complete':False,'official_performance_observations':0}
 try:
  for name in plan['cases']:
   target=debugger.CreateTarget(build['driver']);assert target.IsValid()
   stdout=folder/f'{name}-cpu.stdout';stderr=folder/f'{name}-cpu.stderr'
   launch=lldb.SBLaunchInfo([config[name]['source'],config[name]['inputs'],str(plan['seconds_per_process'])]);launch.SetWorkingDirectory(config['worktree'])
   launch.SetLaunchFlags(lldb.eLaunchFlagDebug)
   launch.SetEnvironmentEntries(['PERF_BUILDID_DIR='+str(folder/'perf-binaries')],True)
   assert launch.AddOpenFileAction(1,str(stdout),False,True) and launch.AddOpenFileAction(2,str(stderr),False,True)
   started=time.time_ns();error=lldb.SBError();process=target.Launch(launch,error);assert error.Success(),str(error)
   pid=process.GetProcessID();assert pid>0
   row={'pid':pid,'launch_error':error.GetCString(),'started_ns':started,'sample_exit_code':None,'driver_exit_code':None,'complete':False}
   receipt['cases'][name]=row;write('cpu-processes.json',receipt)
   mapping=pathlib.Path(f'/tmp/perf-{pid}.map');prefix=mapping.read_bytes() if mapping.exists() and mapping.stat().st_mtime_ns<started else b''
   while not (mapping.exists() and mapping.stat().st_mtime_ns>=started and all(symbol in mapping.read_text() for symbol in config[name]['symbols'])):
    state=process.GetState()
    if state==lldb.eStateStopped:
     resumed=process.Continue();assert resumed.Success(),str(resumed)
    assert state!=lldb.eStateExited,(name,'driver exited before JIT mappings',process.GetExitStatus(),stdout.read_text())
    time.sleep(0.02)
   time.sleep(0.5);assert process.GetState()==lldb.eStateRunning,(name,process.GetState())
   print(name,'sampling owned PID',pid,flush=True)
   sample=folder/f'{name}.sample.txt';argv=['/usr/bin/sample',str(pid),str(plan['sample_seconds']),'1','-file',str(sample)]
   sampled=subprocess.run(argv,text=True,capture_output=True);(folder/f'{name}-sample.log').write_text(sampled.stdout+sampled.stderr);row.update(sample_command=argv,sample_exit_code=sampled.returncode);write('cpu-processes.json',receipt)
   assert sampled.returncode==0,(name,sampled.stderr)
   stopped=process.Stop();assert stopped.Success(),str(stopped);assert wait_for_state(process,{lldb.eStateStopped,lldb.eStateExited})==lldb.eStateStopped
   payload=mapping.read_bytes();assert payload.startswith(prefix);fresh=payload[len(prefix):];(folder/f'{name}.perf.map').write_bytes(fresh)
   entries={}
   for line in fresh.decode().splitlines():
    address,size,symbol=line.split(maxsplit=2)
    if symbol in config[name]['symbols']:entries[symbol]=(int(address,16),int(size,16))
   assert set(entries)==set(config[name]['symbols'])
   dump=folder/'live-code'/name;dump.mkdir(parents=True,exist_ok=False);captured=[]
   for symbol,(address,size) in entries.items():
    assert 0<size<=64*1024*1024
    info=lldb.SBMemoryRegionInfo();region_error=process.GetMemoryRegionInfo(address,info)
    assert region_error.Success() and info.IsReadable() and info.IsExecutable()
    assert info.GetRegionBase()<=address and address+size<=info.GetRegionEnd()
    read_error=lldb.SBError();data=process.ReadMemory(address,size,read_error);assert read_error.Success() and len(data)==size
    out=dump/(symbol+'.bin');out.write_bytes(data)
    captured.append({'symbol':symbol,'address':address,'size':size,'sha256':hashlib.sha256(data).hexdigest(),'file':str(out),'executable_region':True})
   (dump/'jit-code.json').write_text(json.dumps({'pid':pid,'functions':captured,'read_only_code_capture':True,'same_pid_as_cpu_sample':True,'capture_after_cpu_sample':True},indent=2)+'\n')
   row.update(code_capture_same_pid=True,captured_code_bytes=sum(v['size']for v in captured));write('cpu-processes.json',receipt)
   resumed=process.Continue();assert resumed.Success(),str(resumed)
   while process.GetState()!=lldb.eStateExited:
    assert process.GetState()!=lldb.eStateStopped,(name,'unexpected stop after resume',process.GetState())
    time.sleep(0.1)
   row.update(driver_exit_code=process.GetExitStatus(),complete=True);write('cpu-processes.json',receipt);assert row['driver_exit_code']==0,(name,stderr.read_text())
   debugger.DeleteTarget(target);print(name,'same-PID code captured and driver terminal0',flush=True)
  receipt['complete']=True
 except Exception as error:
  receipt['error']=repr(error);print('Profile collection error',repr(error),flush=True)
  if 'process' in locals() and process.IsValid() and process.GetState()!=lldb.eStateExited:
   if process.GetState()==lldb.eStateStopped:process.Continue()
   while process.GetState()!=lldb.eStateExited:time.sleep(0.1)
  raise
 finally:write('cpu-processes.json',receipt)
