import importlib.util,json,os,pathlib,subprocess,time
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
plan=b.read(folder/'plan.json');build=b.read(folder/'residence-build.json');fp=b.compiler_fingerprint();protocol,cases=b.protocol();history_hash=b.digest(b.FIXTURE/'performance-history.json');assert fp==plan['compiler_fingerprint']==build['compiler_fingerprint'] and b.digest(build['driver'])==build['driver_sha256']
assert set(plan['cases'])<=set(protocol['optimization']);census=b.read(folder.parent/'compound-conditional-domains/emission-census.json')
config={'worktree':str(root)}
for name in plan['cases']:
 config[name]={'source':str(b.FIXTURE/f'{name}.mec'),'inputs':str(folder/f'{name}-inputs.json'),'symbols':list(census['cases'][name]['actors']['candidate']['functions'])}
b.write(folder/'profile-config.json',config)
argv=['xcrun','lldb','-x','-b','-o','settings set target.disable-aslr false','-o','command script import '+str(folder/'profile_owned.py'),'-o','script profile_owned.run()']
started=time.monotonic()
with (folder/'lldb-collection-attempt-02.log').open('x') as log:
 child=subprocess.Popen(argv,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 print('Owned-process CPU/code collection',child.pid,flush=True)
 while True:
  try:code=child.wait(timeout=30);break
  except subprocess.TimeoutExpired:print('Waiting on same profiler process',child.pid,flush=True)
b.write(folder/'collection-exit-attempt-02.json',{'command':argv,'pid':child.pid,'exit_code':code,'wall_seconds':time.monotonic()-started});print('Profiler terminal',code,flush=True)
print((folder/'lldb-collection-attempt-02.log').read_text()[-3500:],flush=True)
assert code==0
receipt=b.read(folder/'cpu-processes.json');assert receipt['complete'] and len(receipt['cases'])==3
reference=b.read(folder.parent/'compound-conditional-domains/untimed-counter-gate.json')
for name,row in receipt['cases'].items():
 assert row['driver_exit_code']==0 and row['sample_exit_code']==0 and row['code_capture_same_pid']
 result=json.loads((folder/f'{name}-cpu.stdout').read_text().strip().splitlines()[-1]);assert result['status']=='ok' and result['samples_seconds']==[] and result['report']==result['residence_report']==reference['cases'][name]['actors']['candidate']['execution_report']
 row.update(warmup_validation=b.validate(result['values'],cases[name]['expected']),final_validation=b.validate(result['final_values'],cases[name]['expected']),residence_calls=result['residence_calls'],frozen_execution_counters_match=True)
b.write(folder/'cpu-processes.json',receipt)
analyzer=root/'scripts/analyze-polybench-samples.py';demangler=pathlib.Path('/private/tmp/mech-polybench-optimization/round-02/profile-tools/target/release/polybench-profile-demangle');argv=['python3',str(analyzer),'--demangler',str(demangler),'--output',str(folder/'cpu-analysis.json'),*[arg for name in plan['cases'] for arg in ['--jit-map',f'{name}.sample.txt={folder/f"{name}.perf.map"}']],*[str(folder/f'{name}.sample.txt')for name in plan['cases']]]
with (folder/'cpu-analyzer.log').open('x') as out:r=subprocess.run(argv,stdout=out,stderr=subprocess.STDOUT)
assert r.returncode==0,(folder/'cpu-analyzer.log').read_text();assert fp==b.compiler_fingerprint() and history_hash==b.digest(b.FIXTURE/'performance-history.json');analysis=b.read(folder/'cpu-analysis.json');b.write(folder/'profile-result.json',{'schema':'mech.polybench.accepted-optimization-profile.v1','plan':plan,'compiler_fingerprint':fp,'driver_sha256':build['driver_sha256'],'complete':True,'official_performance_observations':0,'source_and_history_unchanged':True,'processes':receipt,'analysis':analysis})
for name in plan['cases']:
 a=analysis[name+'.sample.txt'];print(json.dumps({'case':name,'execution_samples':a['execution_samples'],'mechanisms':a['self_time_mechanisms'],'top_self':a['top_self_functions'][:5],'top_jit_sites':a.get('top_jit_sites',[])[:8]}),flush=True)
