import json,struct,pathlib,hashlib,re,importlib.util
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
result=b.read(folder/'profile-result.json');census=b.read(folder.parent/'compound-conditional-domains/emission-census.json');verification={'schema':'mech.polybench.same-pid-jit-object-verification.v1','scope':'Actual executable bytes from the same owned process sampled for CPU self time, captured only after sampling; original Object provenance exact. No timing scores or hardware retirement counts.','compiler_fingerprint':result['compiler_fingerprint'],'cases':{},'complete':False}
for case in result['plan']['cases']:
 data=(folder/f'{case}-residence.o').read_bytes();header=struct.unpack_from('<8I',data);assert header[0]==0xfeedfacf;pos=32;text=None;symtab=None
 for _ in range(header[4]):
  cmd,size=struct.unpack_from('<II',data,pos)
  if cmd==0x19:
   for i in range(struct.unpack_from('<I',data,pos+64)[0]):
    at=pos+72+80*i
    if data[at:at+16].split(b'\0',1)[0]==b'__text':text=struct.unpack_from('<QQI',data,at+32)
  if cmd==2:symtab=struct.unpack_from('<4I',data,pos+8)
  pos+=size
 assert text and symtab
 symoff,nsyms,stroff,strsize=symtab;symbols={}
 for i in range(nsyms):
  idx,typ,sect,desc,value=struct.unpack_from('<IBBHQ',data,symoff+16*i)
  if idx and sect:
   name=data[stroff+idx:stroff+strsize].split(b'\0',1)[0].decode();symbols[name]=value
 live=b.read(folder/f'live-code/{case}/jit-code.json');process=result['processes']['cases'][case];assert live['pid']==process['pid'] and live['same_pid_as_cpu_sample'] and live['capture_after_cpu_sample']
 profile=result['analysis'][case+'.sample.txt'];asm=(folder.parent/f'compound-conditional-domains/objects/{case}-candidate.disasm.txt').read_text().splitlines();native={};current=None
 for line in asm:
  m=re.match(r'^([0-9a-f]+) <_(.+)>:',line)
  if m:current=m[2];native[current]={};continue
  m=re.match(r'^\s*([0-9a-f]+):\s+(.*)$',line)
  if m and current:
   at=int(m[1],16)-symbols['_'+current];native[current][at]=m[2]
 rows=[]
 for f in live['functions']:
  start=symbols['_'+f['symbol']]-text[0];assert 0<=start and start+f['size']<=text[1]
  actual=pathlib.Path(f['file']).read_bytes();expected=data[text[2]+start:text[2]+start+f['size']];assert len(expected)==len(actual)
  diff=[i for i,(a,b) in enumerate(zip(actual,expected))if a!=b];sites=[]
  for site in profile['top_jit_sites']:
   if site['symbol']!=f['symbol']:continue
   at=site['offset'];lo=max(0,at-32);hi=min(f['size'],at+36)
   sites.append(dict(site,instruction_identical=actual[at:at+4]==expected[at:at+4],surrounding_68_bytes_identical=actual[lo:hi]==expected[lo:hi],instruction=native[f['symbol']].get(at),window=[{'offset':offset,'instruction':native[f['symbol']][offset]}for offset in range(lo,hi,4)if offset in native[f['symbol']]]))
  rows.append({'symbol':f['symbol'],'size':f['size'],'byte_identical':not diff,'differing_bytes':len(diff),'first_differences':diff[:40],'jit_sha256':hashlib.sha256(actual).hexdigest(),'object_code_sha256':hashlib.sha256(expected).hexdigest(),'sampled_hot_sites':sites})
 assert sum(len(row['sampled_hot_sites'])for row in rows)>0 and all(site['instruction_identical'] and site['surrounding_68_bytes_identical']for row in rows for site in row['sampled_hot_sites'])
 verification['cases'][case]={'pid':live['pid'],'all_sampled_instructions_and_windows_identical':True,'all_function_bytes_identical':all(row['byte_identical']for row in rows),'functions':rows};b.write(folder/'jit-object-verification.json',verification)
 print(case,'all bytes identical',verification['cases'][case]['all_function_bytes_identical'],'captured bytes',sum(row['size']for row in rows),flush=True)
 sites=sorted([site for row in rows for site in row['sampled_hot_sites']],key=lambda s:-s['samples'])
 for site in sites[:5]:
  print(json.dumps({'offset':hex(site['offset']),'samples':site['samples'],'percent':site['percent'],'instruction':site['instruction'],'window':site['window']}),flush=True)
verification.update(complete=True,source_unchanged=b.compiler_fingerprint()==result['compiler_fingerprint']);assert verification['source_unchanged'];b.write(folder/'jit-object-verification.json',verification)
