from pathlib import Path
root=Path.cwd();base=root/'hosts/gpu/src/native_artifact'
p=base/'codegen/options.rs';s=p.read_text();needle='''    NumericCollections,
''';assert s.count(needle)==1;s=s.replace(needle,needle+'''    /// Carry source-ordered rectangle coordinates through native nested loops.
    RectangularMapInduction,
''');p.write_text(s)
p=base/'program/codegen/numeric_map.rs';s=p.read_text();s=s.replace('''    plan: &Plan,
    counter_slot: usize,''','''    plan: &Plan,
    rectangular_induction: bool,
    counter_slot: usize,''',1)
s=s.replace('''emit(b, frame, region, plan, &captures, complete, miss, malformed)?;''','''emit(b, frame, region, plan, &captures, rectangular_induction, complete, miss, malformed)?;''',1)
s=s.replace('''    captures: &BTreeMap<u32, Value>,
    complete: Block,''','''    captures: &BTreeMap<u32, Value>,
    rectangular_induction: bool,
    complete: Block,''',1)
old='''    b.ins().jump(head, &[]);
    b.switch_to_block(head);
    let at = b.use_var(cursor);
    let more = b.ins().icmp(IntCC::UnsignedLessThan, at, count);
    b.ins().brif(more, body, &[], done, &[]);
    b.switch_to_block(body);
    let at = b.use_var(cursor);
    let (source_at, rectangle_row) = if let Some(rectangle) = &region.rectangle {
'''
new='''    // Preserve the source column-then-row order. A nontrivial inner range
    // carries its coordinates directly instead of reconstructing quotient and
    // remainder for every cell. Empty/one-row rectangles retain the flat loop.
    let rectangle_cursor = if rectangular_induction {
        region.rectangle.as_ref().filter(|r| r.rows > 1).map(|r| {
            let row = b.declare_var(types::I64);
            let column = b.declare_var(types::I64);
            b.def_var(column, zero);
            (row, column, r.rows, b.create_block())
        })
    } else {
        None
    };
    b.ins().jump(head, &[]);
    b.switch_to_block(head);
    if let Some((row, column, rows, inner_head)) = rectangle_cursor {
        let column_at = b.use_var(column);
        let more = b.ins().icmp(IntCC::UnsignedLessThan, column_at, source_count);
        let start_column = b.create_block();
        let next_column = b.create_block();
        b.ins().brif(more, start_column, &[], done, &[]);
        b.switch_to_block(start_column);
        b.def_var(row, zero);
        b.ins().jump(inner_head, &[]);
        b.switch_to_block(inner_head);
        let row_at = b.use_var(row);
        let more = b.ins().icmp_imm(IntCC::UnsignedLessThan, row_at, rows as i64);
        b.ins().brif(more, body, &[], next_column, &[]);
        b.switch_to_block(next_column);
        let next = b.ins().iadd_imm(column_at, 1);
        b.def_var(column, next);
        b.ins().jump(head, &[]);
    } else {
        let at = b.use_var(cursor);
        let more = b.ins().icmp(IntCC::UnsignedLessThan, at, count);
        b.ins().brif(more, body, &[], done, &[]);
    }
    b.switch_to_block(body);
    let at = b.use_var(cursor);
    let (source_at, rectangle_row) = if let Some((row, column, _, _)) = rectangle_cursor {
        let row = b.use_var(row);
        let column = b.use_var(column);
        let rectangle = region.rectangle.as_ref().unwrap();
        let inner = b.ins().iadd_imm(row, rectangle.start as i64);
        b.def_var(words[&rectangle.inner_element], inner);
        (column, Some(row))
    } else if let Some(rectangle) = &region.rectangle {
'''
assert s.count(old)==1;s=s.replace(old,new,1)
s=s.replace('''                &captures,
                index_miss,
''','''                &captures,
                rectangular_induction,
                index_miss,
''',1)
old='''    b.switch_to_block(latch);
    let next = b.ins().iadd_imm(at, 1);
    b.def_var(cursor, next);
    b.ins().jump(head, &[]);
'''
new='''    b.switch_to_block(latch);
    if let Some((row, _, _, inner_head)) = rectangle_cursor {
        let current = b.use_var(row);
        let next = b.ins().iadd_imm(current, 1);
        b.def_var(row, next);
        b.ins().jump(inner_head, &[]);
    } else {
        let next = b.ins().iadd_imm(at, 1);
        b.def_var(cursor, next);
        b.ins().jump(head, &[]);
    }
'''
assert s.count(old)==1;s=s.replace(old,new,1);p.write_text(s)
p=base/'program/codegen/numeric_phase_reductions.rs';s=p.read_text();s=s.replace('''    plan: &Plan,
    miss: Block,''','''    plan: &Plan,
    rectangular_induction: bool,
    miss: Block,''',1)
s=s.replace('''    captures: &BTreeMap<u32, Value>,
    miss: Block,''','''    captures: &BTreeMap<u32, Value>,
    rectangular_induction: bool,
    miss: Block,''',1)
s=s.replace('''    output: Option<(Value, Value)>,
    miss: Block,''','''    output: Option<(Value, Value)>,
    rectangular_induction: bool,
    miss: Block,''',1)
s=s.replace('''emit_from_views(b, source, plan, first, last, &matrices, &captures, miss)?''','''emit_from_views(b, source, plan, first, last, &matrices, &captures, rectangular_induction, miss)?''',1)
s=s.replace('''b, region, plan, first, count, matrices, captures, None, miss,''','''b, region, plan, first, count, matrices, captures, None, rectangular_induction, miss,''',1)
s=s.replace('''super::numeric_map::emit(b, frame, region, plan, captures, complete, arithmetic, miss)?;''','''super::numeric_map::emit(b, frame, region, plan, captures, rectangular_induction, complete, arithmetic, miss)?;''',1);p.write_text(s)
p=base/'program/codegen/numeric_phase_maps.rs';s=p.read_text();s=s.replace('''    plan: &Plan,
    miss: Block,''','''    plan: &Plan,
    rectangular_induction: bool,
    miss: Block,''',1).replace('''        Some((scratch, capacity)),
        miss,''','''        Some((scratch, capacity)),
        rectangular_induction,
        miss,''',1);p.write_text(s)
p=base/'program/codegen/readonly_numeric.rs';s=p.read_text()
for call in ['super::numeric_phase_reductions::emit(','super::numeric_phase_maps::emit(']:
 a=s.index(call);z=s.index(')?;',a);part=s[a:z];assert part.count('&program.metadata().plan,')==1;part=part.replace('&program.metadata().plan,','&program.metadata().plan,\n                    controls.enabled(OptimizationPass::RectangularMapInduction),');s=s[:a]+part+s[z:]
p.write_text(s)
p=base/'codegen/control/mod.rs';s=p.read_text();a=s.index('crate::native_artifact::program::codegen::numeric_map::emit_entry(');z=s.index(')?;',a);part=s[a:z];assert part.count('prepared.plan(),')==1;part=part.replace('prepared.plan(),','prepared.plan(),\n                    controls.enabled(crate::native_artifact::codegen::options::OptimizationPass::RectangularMapInduction),');s=s[:a]+part+s[z:];p.write_text(s)
p=base/'program/image/identity.rs';s=p.read_text();assert 'const PROGRAM_IR_VERSION: u64 = 390;' in s or '= 390;' in s;s=s.replace('= 390;','= 400;',1);p.write_text(s)
print('General rectangular map induction emitter prepared; no benchmark source edits')
