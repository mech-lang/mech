from pathlib import Path
p=Path('hosts/gpu/src/native_artifact/program/codegen/readonly_numeric.rs');t=p.read_text()
key='use std::collections::{BTreeMap, BTreeSet};';assert t.count(key)==1;t=t.replace(key,key+'\nuse super::numeric_cell_prefix::context::{Context as CellContext, Mode as CellMode};')
key='    pub rolling_cell_prefixes: Vec<(usize, usize, usize, usize, usize)>,\n';assert key in t;t=t.replace(key,key+'    pub cfg_cell_prefixes: Vec<(usize,usize,usize,usize)>,\n')
key='''    setup_work += b.func.dfg.num_insts() - cache_setup;
''';assert key in t;t=t.replace(key,key+'''    let cell_context=if controls.enabled(OptimizationPass::CellContextPrefixes)&&rolling_caches.len()==1 {
        let cache=&rolling_caches[0];
        cell_prefixes.iter().find(|p|p.first==cache.recipe.first).and_then(|prefix|
            CellContext::derive(b,&program.metadata().plan.facts(),proof,&region.tail,prefix,&cache.recipe)
        )
    }else{None};
''')
key='''        reused_cell_write_sources: Vec::new(),''';assert key in t;t=t.replace(key,'''        cfg_cell_prefixes: cell_context.as_ref().map(|c|vec![c.report()]).unwrap_or_default(),
'''+key)
start=t.index('    let emitted_sites = proof.sites.iter().map(');end=t.index('        let complete_pack = ',start)
t=t[:start]+'''    let mut emitted_sites=proof.sites.iter().map(|&site|(None,CellMode::Fresh,site)).chain(
        versions.iter().flat_map(|version|version.sites.iter().map(move|&site|(Some(version),CellMode::Fresh,site)))
    ).collect::<Vec<_>>();
    if let Some(context)=&cell_context {
        emitted_sites.extend(context.sites.iter().map(|&site|(None,CellMode::Ready,site)));
        emitted_sites.push((None,CellMode::Write,context.write));
    }
    for (version,cell_mode,site) in emitted_sites {
'''+t[end:]
key='''        let target = |site| {
            if let Some(block) = version.and_then(|v| v.blocks.get(&site)) {''';new='''        let target = |next| {
            if let Some(block)=cell_context.as_ref().and_then(|context|context.target(cell_mode,site,next)) {
                return block;
            }
            let site=next;
            if let Some(block) = version.and_then(|v| v.blocks.get(&site)) {''';assert key in t;t=t.replace(key,new)
key='''        b.switch_to_block(target(site as u32));
        let reduction_miss =''';new='''        b.switch_to_block(target(site as u32));
        if let Some(context)=cell_context.as_ref().filter(|context|cell_mode==CellMode::Ready&&context.first==site) {
            let before=b.func.dfg.num_insts();
            let prefix=cell_prefixes.iter().find(|p|p.first==site).expect("source-derived reusable prefix");
            let cache=rolling_caches.iter().find(|c|c.recipe.first==site).expect("source-derived reusable data");
            super::numeric_cell_prefix::emit(b,controls.options(),&words,shadow,proof,code,prefix,Some(cache),Some(true),context.slow,context.staged);
            report.source_instructions(b.func.dfg.num_insts()-before)?;
            continue;
        }
        let reduction_miss =''';assert key in t;t=t.replace(key,new)
key='''            let slow = b.create_block();
            b.set_cold_block(slow);
            for &at in &prefix.sites {''';new='''            let context=cell_context.as_ref().filter(|context|context.first==site&&cell_mode==CellMode::Fresh);
            let slow=context.map_or_else(||b.create_block(),|c|c.slow);
            b.set_cold_block(slow);
            for &at in &prefix.sites {''';assert key in t;t=t.replace(key,new)
key='''                    .find(|cache| cache.recipe.first == site),
                slow,
                target(prefix.next),''';new='''                    .find(|cache| cache.recipe.first == site),
                context.map(|_|false),
                slow,
                context.map_or_else(||target(prefix.next),|c|c.staged),''';assert key in t;t=t.replace(key,new)
key='''                if cache.recipe.first == site {
                    cache.invalidate(b);
                }''';new='''                if cache.recipe.first == site && cell_context.is_none() {
                    cache.invalidate(b);
                }''';assert key in t;t=t.replace(key,new)
key='''                        for cache in &rolling_caches {
                            cache.invalidate(b);
                        }
                        boundary::materialize(''';new='''                        if cell_context.is_none() { for cache in &rolling_caches { cache.invalidate(b); } }
                        boundary::materialize(''';assert key in t;t=t.replace(key,new)
# Only the actual two-axis CellWrite materialization branch gets a fresh tail.
anchor=t.index('let old = if let Some(old) = known_old')
a=t.index('                        b.ins().jump(done, &[]);',t.index('                        boundary::materialize(',anchor));end=a+len('                        b.ins().jump(done, &[]);')
t=t[:a]+'''                        let after_materialize=if cell_mode==CellMode::Write {
                            blocks[&cell_context.as_ref().expect("staged write context").after_write]
                        }else{done};
                        b.ins().jump(after_materialize, &[]);'''+t[end:]
key='''        for cache in &rolling_caches {
            cache.control(b, &program.metadata().plan.facts(), site);
        }''';new='''        if cell_context.is_none() {for cache in &rolling_caches {
            cache.control(b,&program.metadata().plan.facts(),site);
        }}''';assert key in t;t=t.replace(key,new)
p.write_text(t)
