"""Preserve all attempted source/correctness evidence before the sole probe."""
import gzip,importlib.util,json,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(s);s.loader.exec_module(b)
p=b.FIXTURE;plan=b.read(folder/'plan.json');q=b.read(folder/'qualification.json');gate=b.read(folder/'untimed-counter-gate.json');emission=b.read(folder/'emission-census.json');fp=b.compiler_fingerprint()
assert b.command(['git','branch','--show-current'])=='codex/polybench-native-matrices'
assert q['complete']and q['driver_build_complete']and q['tests']>=780 and q['focused_checks']['passed_tests']==[14]
assert fp==q['compiler_fingerprint']==gate['compiler_fingerprint']==emission['compiler_fingerprint']
assert gate['complete']and gate['passed']and gate['finite_liveouts']==17002 and all(row['all_counters_match']for row in gate['cases'].values())
assert emission['complete']and emission['passed']and emission['cell_prefixes_emitted']and emission['no_new_fma']
assert b.digest(q['driver'])==q['driver_sha256']and len(b.read(p/'performance-history.json')['entries'])==61 and b.read(p/'performance-acceptance.json')['accepted_history_index']==59
assert not(folder/'training-probe.json').exists()
paths=plan['source_paths'];changed=subprocess.check_output(['git','diff','--name-only',plan['source_parent'],'--'],text=True).splitlines();changed+=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines();actual=sorted({name for name in changed if name.endswith(('.rs','.toml'))or Path(name).name=='Cargo.lock'})
assert set(actual)==set(paths) and len(paths)==13 and all(b.digest(root/name)==q['source_sha256'][name]for name in paths)
source_snapshot=folder/'qualified-source';source_snapshot.mkdir(exist_ok=False)
for name in paths:
 out=source_snapshot/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((root/name).read_bytes())
patch=[subprocess.check_output(['git','diff',plan['source_parent'],'--',*paths])]
for name in paths:
 if subprocess.run(['git','cat-file','-e',plan['source_parent']+':'+name],capture_output=True).returncode:
  added=subprocess.run(['git','diff','--no-index','--','/dev/null',name],capture_output=True)
  assert added.returncode==1
  patch.append(added.stdout)
(folder/'qualified-source.patch').write_bytes(b''.join(patch))
attempts=[{'path':str(f.relative_to(folder)),'sha256':b.digest(f),'result':b.read(f),'source_snapshot_files':len(list((f.parent/'source').rglob('*.rs')))}for f in sorted(folder.glob('attempt-*/*-result.json'))]
assert len(attempts)>=1 and attempts[-1]['result']['exit_code']==0 and attempts[-1]['result']['compiler_fingerprint']==fp
source_audit={'schema':'mech.polybench.cfg-cell-context-source-audit.v1','compiler_fingerprint':fp,'reviewed':True,'passed':True,
 'closure':'Actual same-plan source values/definition/read-role queries and original frame recipes prove one finite scalar point producer, exact center source read, sole CellWrite, updated same matrix/unchanged row/checked column+1 tail. No benchmark names, fixed MINI sizes, forged ordinals or serialized execution permission. Existing scope/phase/debit boundaries are retained. Other writes/appends/maps/fallback/child loops/loop versions decline.',
 'contexts':'Source facts derive bounded copies of the root/header/dispatcher leading to the point prefix and its exact pure post-write tail. Original fresh graph remains. Initial/reentered loan enters fresh. Finite fresh/reusable evaluation defines only F64 cache data and reaches a source-write rendezvous. Original old-first/no-op/private-store paths enter reusable tail/header only after completed write/no-op. COW performs the same original helper then goes to fresh tail; original lexical evaluation and every other latch target fresh. Errors exit the loan. No cache-valid/pending/column word is read, staged, or synchronized in CFG mode; old token mode remains only for declined/disabled CFG specialization.',
 'admission':'Fresh evaluates every checked U64 subexpression and distinct source row/column before any load. Reusable context inherits unchanged row/lower validity and stable constants only from the preceding complete admission plus exact source unit-column continuation. It guards current column against the maximum checked-positive-offset overflow threshold and the current maximum source-read column against the current bank columns before loading anything. Refusal/nonfinite result reaches the unchanged original lexical source at the same current state before exports/store, preserving first source failures and NaN payloads.',
 'data_and_ownership':'Same current numeric loan validates owners/epochs/span/capacity/schema/current geometry; no pointer is cached and no global readonly/alias/alignment claim is added. Source F64 data shift across completed adjacent updates, with previous completed result supplying overwritten left cell. F64 fields are defined on successful producer and not used on fresh/COW paths before redefinition, ending helper/cold-edge live ranges. Exact already-read center supplies original write comparison/bounds. Old-first/no-op/COW ordering, immutable aliases, previous published outputs and denial/cleanup/retry stay.',
 'accounting':'Both physical header copies retain the original funding checks, exact debit and phase count update; only one is visited per logical source iteration. Original source arithmetic/term order/rounding, work/comparison/visits and all other counters unchanged; no reassociation/FMA/reciprocal substitution, bill reduction or padding. Existing independent instruction/stack/code envelopes check actual emitted graphs. No runtime helper/frame/ABI/per-op allocation addition. Cranelift remains sole Mech generator.',
 'evidence':'14 focused groups plus broad all30 original/decoded/restored and both features; actual native token/point admission and source CFG/token/original comparisons cover row/time/reset, late upper/overflow/nonfinite, no-op-before-first-COW denial, exact reports/first errors/payloads, aliases, prior outputs and retry. Source refusals and genuine CFG metadata check closure. Exact17002 optimization C values and every accepted59 counter match. Prototype and final genuine Objects are byte identical, show9-to3 reuse, zero vector stack accesses, and actual direct register work-credit compare/debit. Static totals include cold code and are not latency/hardware forecasts.',
 'policy':plan['invariants'],'performance_observations':0}
b.write(folder/'source-audit.json',source_audit)
dest=p/'qualification/round-61-control-flow-cell-cache/development';dest.mkdir(parents=True,exist_ok=False);archives={}
for source in sorted(folder.rglob('*')):
 if not source.is_file()or '__pycache__'in source.parts or source.name.endswith('-driver'):continue
 name=str(source.relative_to(folder));raw=source.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw;archives[name]={'path':str(out.relative_to(p)),'sha256':b.digest(source),'compressed_sha256':b.digest(out)}
receipt={'schema':'mech.polybench.control-flow-cell-cache-development.v1','created_at':b.utc(),'complete':True,'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'qualification_manifest':q,'effective_plan':plan,'selection_policy_sha256':b.digest(p/'performance-selection-policy-v4.json'),'source_parent':plan['source_parent'],'source_sha256':q['source_sha256'],'actual_changed_source_paths':actual,'profiling_basis':plan['profiling_basis'],'invariants':plan['invariants'],'counter_gate':gate,'emission_census':emission,'source_audit':source_audit,'development_attempts':attempts,'failed_attempt_logs_and_receipts_preserved':True,'performance_observations':0,'archives':archives}
b.write(p/'training-experiments/control-flow-cell-cache-development.json',receipt);b.write(p/'training-experiments/control-flow-cell-cache-training-schedule.json',b.read(folder/'training-probe-plan.json'));b.write(p/'training-experiments/control-flow-cell-cache-route-census.json',gate)
subprocess.run(['git','diff','--check'],check=True);subprocess.run(['git','add','--',*paths,str(p.relative_to(root))],check=True)
r=subprocess.run(['git','-c','gc.auto=0','commit','-m','Qualify CFG-encoded point cache under original source accounting'],capture_output=True,text=True);(folder/'qualification-source-commit.log').write_text(r.stdout+r.stderr);assert r.returncode==0
head=b.command(['git','rev-parse','HEAD']);assert b.compiler_fingerprint()==fp and b.command(['git','status','--porcelain'])==''
b.write(folder/'qualification-source-commit.json',{'source_commit':head,'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'performance_observations':0,'archives_verified':len(archives),'clean':True})
print(json.dumps({'head':head,'compiler_fingerprint':fp,'broad_checks':q['tests'],'focused_checks':14,'changed_cases':emission['native_code_changed_cases'],'archives_verified':len(archives),'clean':True}),flush=True)
