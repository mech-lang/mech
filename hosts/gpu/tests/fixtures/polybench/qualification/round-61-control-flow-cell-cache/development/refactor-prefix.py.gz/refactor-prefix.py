from pathlib import Path
root=Path.cwd();p=root/'hosts/gpu/src/native_artifact/program/codegen/numeric_cell_rolling.rs';t=p.read_text()
old='''        for (&id, &key) in &self.recipe.offsets {
            b.def_var(self.values[&key], reads[&id]);
        }
        b.def_var(self.result, result);
''';assert t.count(old)==1;t=t.replace(old,'        self.stage_values(b, reads, result);\n')
at=t.index('    pub fn control(')
t=t[:at]+'''    pub fn stage_values(&self,b: &mut FunctionBuilder<'_>,reads: &BTreeMap<u32,Value>,result: Value) {
        for (&id,&key) in &self.recipe.offsets { b.def_var(self.values[&key],reads[&id]); }
        b.def_var(self.result,result);
    }
    /// Entry is a CFG edge from the previous completed point, not an external
    /// scalar permission. Rows/lower bounds and constant subexpressions retain
    /// their complete previous admission. All advancing column intermediates
    /// still need their new upper/overflow admission before any load.
    pub fn ready_bounds(&self,b: &mut FunctionBuilder<'_>,column: Value,columns: Value) -> Value {
        let safe=if self.recipe.max_checked>0 {
            b.ins().icmp_imm(IntCC::UnsignedLessThanOrEqual,column,u64::MAX.wrapping_sub(self.recipe.max_checked as u64) as i64)
        }else { b.ins().iconst(types::I8,1) };
        let last=b.ins().iadd_imm(column,self.recipe.max_column);
        let fits=b.ins().icmp(IntCC::UnsignedLessThanOrEqual,last,columns);
        b.ins().band(safe,fits)
    }
'''+t[at:];p.write_text(t)
p=root/'hosts/gpu/src/native_artifact/program/codegen/numeric_cell_prefix.rs';t=p.read_text();old='''fn evaluate(
''';assert t.count(old)==1;t=t.replace(old,'''fn evaluate_mode(
''')
old='''    cache: Option<&rolling::Cache>,
) -> Evaluated {''';new='''    cache: Option<&rolling::Cache>,
    cfg_mode: Option<bool>,
) -> Evaluated {''';assert t.count(old)==1;t=t.replace(old,new)
old='''    let (reads, reused) = if let Some(cache) = cache {'''
new='''    let (reads, reused) = if let Some(ready) = cfg_mode {
        let cache=cache.expect("source-derived context has its point data");
        let reads=if ready {
            let admitted=b.create_block();
            let yes=cache.ready_bounds(b,inputs[&cache.recipe.column],views[&cache.recipe.array][2]);
            b.ins().brif(yes,admitted,&[],slow,&[]);b.switch_to_block(admitted);
            source_reads.iter().map(|&id| {
                let key=cache.recipe.offsets[&id];
                let value=if let Some(value)=cache.old_read(b,key) {value}else {
                    let row=b.ins().iadd_imm(inputs[&cache.recipe.row],key.0);
                    let column=b.ins().iadd_imm(inputs[&cache.recipe.column],key.1);
                    point_load(b,options,views[&cache.recipe.array],row,column)
                };(id,value)
            }).collect()
        }else {
            let integers=admitted_indices(b,prefix,inputs,views,slow);
            prefix.steps.iter().filter_map(|(id,step)|if let Step::Read{array,row,column}=step {Some((*id,point_load(b,options,views[array],integers[row],integers[column])))}else{None}).collect()
        };
        (reads,Some(b.ins().iconst(types::I8,i64::from(ready))))
    } else if let Some(cache) = cache {''';assert old in t;t=t.replace(old,new)
old='''        cache.stage(
            b,
            inputs[&cache.recipe.column],
            &reads,
            floats[&cache.recipe.result],
        );''';new='''        if cfg_mode.is_some() {
            cache.stage_values(b,&reads,floats[&cache.recipe.result]);
        }else {
            cache.stage(b,inputs[&cache.recipe.column],&reads,floats[&cache.recipe.result]);
        }''';assert old in t;t=t.replace(old,new)
at=t.index('pub(super) fn emit(')
t=t[:at]+'''#[cfg(all(test, feature="canonical-native-program-runtime"))]
fn evaluate(b: &mut FunctionBuilder<'_>,options: OptimizationOptions,prefix: &Prefix,inputs: &BTreeMap<u32,Value>,views: &BTreeMap<usize,[Value;3]>,slow: Block,cache: Option<&rolling::Cache>)->Evaluated {
    evaluate_mode(b,options,prefix,inputs,views,slow,cache,None)
}
'''+t[at:]
old='''    cache: Option<&rolling::Cache>,
    slow: Block,''';new='''    cache: Option<&rolling::Cache>,
    cfg_mode: Option<bool>,
    slow: Block,''';assert t.count(old)==1;t=t.replace(old,new)
old='''    let result = evaluate(b, options, prefix, &inputs, &views, slow, cache);''';new='''    let result = evaluate_mode(b, options, prefix, &inputs, &views, slow, cache, cfg_mode);''';assert old in t;t=t.replace(old,new)
t+='''\n#[path="numeric_cell_context.rs"]\npub(in crate::native_artifact) mod context;\n''';p.write_text(t)
