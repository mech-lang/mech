"""Preserve complete untimed qualification before any candidate observations."""
import gzip,hashlib,importlib.util,json,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
assert b.command(['git','branch','--show-current'])=='codex/polybench-native-matrices'
p=b.FIXTURE;q=b.read(folder/'qualification.json');plan=b.read(folder/'plan.json');gate=b.read(folder/'untimed-counter-gate.json');emission=b.read(folder/'emission-census.json');fp=b.compiler_fingerprint()
assert q['complete'] and q['driver_build_complete'] and q['tests']==729 and q['focused_checks']['passed_tests']==[8]
assert fp==q['compiler_fingerprint']==gate['compiler_fingerprint']==emission['compiler_fingerprint']
assert gate['complete'] and gate['passed'] and gate['finite_liveouts']==17002
assert emission['complete'] and emission['passed'] and emission['qualified_intermediates_elided'] and emission['no_new_fma']
assert all(row['work_not_reduced'] and row['other_counters_match'] and row['visit_proof']['proved'] for row in gate['cases'].values())
assert b.digest(q['driver'])==q['driver_sha256'] and len(b.read(p/'performance-history.json')['entries'])==48
assert b.read(p/'performance-acceptance.json')['accepted_history_index']==47
assert not (folder/'training-probe.json').exists()
paths=plan['source_paths'];changed=subprocess.check_output(['git','diff','--name-only',plan['source_parent'],'--'],text=True).splitlines();changed+=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines();actual=sorted({name for name in changed if name.endswith(('.rs','.toml')) or Path(name).name=='Cargo.lock'});assert set(actual)<=set(paths) and actual
assert all(b.digest(root/name)==q['source_sha256'][name] for name in paths)
source_snapshot=folder/'qualified-source';source_snapshot.mkdir(exist_ok=True)
for name in paths:
 out=source_snapshot/name;out.parent.mkdir(parents=True,exist_ok=True)
 if out.exists():assert out.read_bytes()==(root/name).read_bytes()
 else:out.write_bytes((root/name).read_bytes())
(folder/'qualified-source.patch').write_bytes(subprocess.check_output(['git','diff',plan['source_parent'],'--',*paths]))
refinements={}
for name in ['ordered-product-epilogues-plan.json','ordered-product-epilogues-loan-refinement.json','ordered-product-epilogues-broadcast-refinement.json','ordered-product-epilogues-transport-refinement.json']:
 f=p/'training-experiments'/name;refinements[name]={'path':str(f.relative_to(p)),'sha256':b.digest(f),'content':b.read(f)}
attempts=[{'path':str(f.relative_to(folder)),'sha256':b.digest(f),'result':b.read(f),'source_snapshot_files':len(list((f.parent/'source').rglob('*.gz')))} for f in sorted(folder.glob('attempt-*/result.json'))]
assert len(attempts)==11 and attempts[-1]['result']['compiler_fingerprint']==fp
assert attempts[-1]['result']['exit_code']==0 and attempts[-1]['result']['passed_tests']==[8]
dest=p/'qualification/round-48-ordered-product-epilogues/development';dest.mkdir(parents=True,exist_ok=False);archives={}
for source in sorted(folder.rglob('*')):
 if not source.is_file() or '__pycache__' in source.parts or source==Path(q['driver']):continue
 name=str(source.relative_to(folder));raw=source.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives[name]={'path':str(out.relative_to(p)),'sha256':b.digest(source),'compressed_sha256':b.digest(out)}
receipt={'schema':'mech.polybench.ordered-product-epilogues-development.v1','created_at':b.utc(),'complete':True,'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'qualification_manifest':q,'effective_plan':plan,'prospective_refinements':refinements,'selection_policy_sha256':b.digest(p/'performance-selection-policy-v4.json'),'source_parent':plan['source_parent'],'source_sha256':q['source_sha256'],'actual_changed_source_paths':actual,'profiling_basis':plan['profiling_basis'],'invariants':plan['implementation'],'counter_gate':{'complete':True,'passed':True,'finite_liveouts':gate['finite_liveouts'],'all_work_not_reduced':all(row['work_not_reduced'] for row in gate['cases'].values()),'all_other_counters_match':all(row['other_counters_match'] for row in gate['cases'].values()),'all_visits_proved':all(row['visit_proof']['proved'] for row in gate['cases'].values())},'emission_census':{'complete':True,'passed':True,'fused_cases':emission['view_cases'],'native_code_changed_cases':emission['native_code_changed_cases'],'all_fusions_top_level':emission['all_views_top_level'],'no_new_fma':emission['no_new_fma'],'code_change_scope_note':'All Object differences include IR/ABI identity and helper-frame changes; do not attribute unrelated code differences to actual fusion.'},'development_attempts':attempts,'broad_development_failures':[b.read(folder/'broad-attempt-01/result.json')],'failed_attempt_logs_and_receipts_preserved':True,'source_snapshot_scope':'Per-attempt snapshot availability is listed explicitly; the final qualified source is fully archived. Early compile-error logs and receipts are retained even where no full contemporaneous source snapshot exists.','performance_observations':0,'archives':archives}
b.write(p/'training-experiments/ordered-product-epilogues-development.json',receipt)
b.write(p/'training-experiments/ordered-product-epilogues-training-schedule.json',b.read(folder/'training-probe-plan.json'))
assert not (p/'round-48-epilogue-route-census.json').exists()
b.write(p/'round-48-epilogue-route-census.json',gate)
subprocess.run(['git','diff','--check'],check=True);subprocess.run(['git','add','--',*paths,str(p.relative_to(root))],check=True)
result=subprocess.run(['git','commit','-m','Qualify ordered product epilogues before optimization selection'],capture_output=True,text=True);(folder/'qualification-source-commit.log').write_text(result.stdout+result.stderr);assert result.returncode==0
head=b.command(['git','rev-parse','HEAD']);assert b.compiler_fingerprint()==fp and b.command(['git','status','--porcelain'])==''
b.write(folder/'qualification-source-commit.json',{'source_commit':head,'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'performance_observations':0,'archives_verified':len(archives),'clean':True})
print(json.dumps({'head':head,'compiler_fingerprint':fp,'broad_checks':729,'focused_groups':8,'archives':len(archives),'performance_observations':0,'clean':True}),flush=True)
