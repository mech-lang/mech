import importlib.util,json,os,re,subprocess,time
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("b",root/"scripts/benchmark-polybench.py");b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
fp=b.compiler_fingerprint();existing=list(folder.glob("attempt-*"));attempt=folder/f"attempt-{len(existing)+1:02d}";attempt.mkdir()
env=os.environ.copy();env["CARGO_TARGET_DIR"]="/private/tmp/mech-polybench-pr1000-target"
argv=["cargo","test","--release","-p","mech-gpu","--no-default-features","--features","canonical-native-program","--lib","--","numeric_product_epilogues","--nocapture","--test-threads=1"]
import gzip
plan=b.read(folder/"plan.json")
for name in plan["source_paths"]:
 source=root/name
 if source.exists():
  output=attempt/"source"/(name+".gz");output.parent.mkdir(parents=True,exist_ok=True);output.write_bytes(gzip.compress(source.read_bytes(),mtime=0))
start=time.monotonic()
with (attempt/"focused.log").open("x") as log:result=subprocess.run(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
text=(attempt/"focused.log").read_text();receipt={"command":argv,"exit_code":result.returncode,"wall_seconds":time.monotonic()-start,"compiler_fingerprint":fp,"source_unchanged":b.compiler_fingerprint()==fp,"passed_tests":[int(n) for n in re.findall(r"test result: ok[.] (\d+) passed",text)],"scope":"Untimed source proof, actual ordered scalar/SIMD execution, bank/callback census, source fees, aliases and original/decoded/restored forms; broader failure/resource qualification pending; no candidate performance observations"}
b.write(attempt/"result.json",receipt);print(json.dumps(receipt),flush=True)
assert receipt["source_unchanged"]
raise SystemExit(result.returncode)
