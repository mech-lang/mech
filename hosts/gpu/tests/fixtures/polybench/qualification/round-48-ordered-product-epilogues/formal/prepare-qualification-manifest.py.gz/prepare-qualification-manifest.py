"""Assemble verified correctness evidence before any product-epilogue timing."""
import importlib.util
from pathlib import Path

root = Path.cwd()
folder = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("b", root / "scripts/benchmark-polybench.py")
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
state = b.read(folder / "current-work.json")
focused = b.read(folder / "focused-result.json")
checks = b.read(folder / "qualification-checks.json")
build = b.read(folder / "driver-build-result.json")
fp = b.compiler_fingerprint()
assert focused["complete"] and focused["exit_code"] == 0 and focused["source_unchanged"]
assert checks["complete"] and checks["driver_build_complete"]
assert len(checks["checks"]) == 11
assert all(c["exit_code"] == 0 for c in checks["checks"])
assert all(c["passed_tests"] and sum(c["passed_tests"]) > 0 for c in checks["checks"][:9])
assert any(c["name"] == "matrix-polybench.log" and c["passed_tests"] == [24, 30] for c in checks["checks"])
assert build["exit_code"] == 0 and build["source_unchanged"]
assert fp == focused["compiler_fingerprint"] == checks["compiler_fingerprint"] == build["compiler_fingerprint"] == state["compiler_fingerprint"]
driver = folder / "ordered-product-epilogues-driver"
assert b.digest(driver) == checks["driver_sha256"]
output = folder / "qualification.json"
assert not output.exists()
checks.update(
    versions={"ir": 415, "work": 157, "abi": 48},
    source_parent=state["source_parent"],
    source_uncommitted=bool(b.command(["git", "status", "--porcelain", "--", *state["source_paths"]])),
    dataset="MINI",
    numeric_profile="F64",
    new_performance_samples=0,
    source_sha256={p: b.digest(root / p) for p in state["source_paths"]},
    driver_build=build,
    focused_checks=focused,
)
b.write(output, checks)
print({"compiler_fingerprint": fp, "broad_checks": checks["tests"], "focused_checks": focused["passed_tests"], "driver_sha256": checks["driver_sha256"], "performance_observations": 0}, flush=True)
