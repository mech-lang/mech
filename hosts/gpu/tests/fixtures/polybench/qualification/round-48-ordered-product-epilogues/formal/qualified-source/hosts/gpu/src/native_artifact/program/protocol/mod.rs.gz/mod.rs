//! Typed private helper domains. Raw u64 lanes remain the unchanged transport.
#[cfg(feature = "canonical-native-program-runtime")]
mod owner;
#[cfg(feature = "canonical-native-program-runtime")]
pub(in crate::native_artifact) use crate::native_artifact::program::protocol::owner::OwnerOperation;

/// A cold first-write request, never ownership authority. The runtime still
/// requires the current selected tree, its exact source-site last-use proof,
/// matching frozen identity, and Core's exclusive consuming transfer.
#[cfg(feature = "canonical-native-program-runtime")]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(in crate::native_artifact) enum NumericWriteHandoff {
    Established,
    RetireDeadTreePins,
}
#[cfg(feature = "canonical-native-program-runtime")]
impl NumericWriteHandoff {
    pub const fn raw(self) -> u64 {
        match self {
            Self::Established => 0,
            Self::RetireDeadTreePins => 1,
        }
    }
    pub const fn decode(value: u64) -> Option<Self> {
        if value == Self::Established.raw() {
            Some(Self::Established)
        } else if value == Self::RetireDeadTreePins.raw() {
            Some(Self::RetireDeadTreePins)
        } else {
            None
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(in crate::native_artifact) struct OutputIndex(u64);
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(in crate::native_artifact) enum GlobalHelper {
    Library,
    Move,
    Collection,
    Output(OutputIndex),
    WindowPrepare,
    WindowFinish,
    StringMapPrepare,
    StringMapFinish,
    BorrowedStringsPrepare,
    BorrowedStringFailure,
    ClosedTailBegin,
    ClosedTailEnd,
    PrefixPause,
    PrefixBorrowedResume,
    PrefixTailResume,
    PrefixScanned,
    JoinMapPrepare,
    JoinMapFinish,
    StructuralObservation,
    MapOwnerBegin,
    MapOwnerCall,
    MapOwnerEnd,
    MapOwnerSpan,
    ParallelRun,
    ParallelTake,
    ParallelYield,
    ParallelEnter,
    FrozenMapCopy,
    FrozenMapRead,
    NumericWritePrepare,
    NumericSegmentBegin,
    NumericSegmentEnd,
    AdmitMove,
    AdmitStructuralObservation,
    AdmitNumericSegmentBegin,
    MapOwnerConstructorCheck,
    BorrowedRecordMapProject,
    BorrowedRecordMapRead,
    Utf8ReadPrepare,
    Utf8ReadFinish,
    UniformFillPrepare,
    UniformFillFinish,
    NumericMapPrepare,
    NumericMapFinish,
    NumericReductionFinish,
    NumericTransposeFinish,
    NumericBinaryPrepare,
    NumericBinaryFinish,
    NumericProductPrepare,
    NumericProductFinish,
    NumericGeneratorPrepare,
    NumericGeneratorFinish,
    HistogramPrepare,
    HistogramFinish,
    WordCollectionPrepare,
    WordCollectionFinish,
    MapMatrixKey,
    MapKeys,
    MapDictionaryEnd,
    MapSeedFrame,
    MapOwnerBeginBorrowedValues,
}
impl GlobalHelper {
    // Decoding classifies only. Site, phase, lane, admission and cursor checks
    // remain at their original runtime points, including unknown output tags.
    pub const fn decode(raw: u64) -> Self {
        match raw {
            0 => Self::Library,
            1 => Self::Move,
            2 => Self::Collection,
            value if value == u64::MAX - 1 => Self::WindowPrepare,
            value if value == u64::MAX - 2 => Self::WindowFinish,
            value if value == u64::MAX - 3 => Self::StringMapPrepare,
            value if value == u64::MAX - 4 => Self::StringMapFinish,
            value if value == u64::MAX - 5 => Self::BorrowedStringsPrepare,
            value if value == u64::MAX - 6 => Self::BorrowedStringFailure,
            value if value == u64::MAX - 7 => Self::ClosedTailBegin,
            value if value == u64::MAX - 8 => Self::ClosedTailEnd,
            value if value == u64::MAX - 9 => Self::PrefixPause,
            value if value == u64::MAX - 10 => Self::PrefixBorrowedResume,
            value if value == u64::MAX - 11 => Self::PrefixTailResume,
            value if value == u64::MAX - 12 => Self::PrefixScanned,
            value if value == u64::MAX - 13 => Self::JoinMapPrepare,
            value if value == u64::MAX - 14 => Self::JoinMapFinish,
            value if value == u64::MAX - 15 => Self::StructuralObservation,
            value if value == u64::MAX - 16 => Self::MapOwnerBegin,
            value if value == u64::MAX - 17 => Self::MapOwnerCall,
            value if value == u64::MAX - 18 => Self::MapOwnerEnd,
            value if value == u64::MAX - 19 => Self::MapOwnerSpan,
            value if value == u64::MAX - 20 => Self::ParallelRun,
            value if value == u64::MAX - 21 => Self::ParallelTake,
            value if value == u64::MAX - 22 => Self::ParallelYield,
            value if value == u64::MAX - 23 => Self::ParallelEnter,
            value if value == u64::MAX - 24 => Self::FrozenMapCopy,
            value if value == u64::MAX - 25 => Self::FrozenMapRead,
            value if value == u64::MAX - 26 => Self::NumericWritePrepare,
            value if value == u64::MAX - 27 => Self::NumericSegmentBegin,
            value if value == u64::MAX - 28 => Self::NumericSegmentEnd,
            value if value == u64::MAX - 29 => Self::AdmitMove,
            value if value == u64::MAX - 30 => Self::AdmitStructuralObservation,
            value if value == u64::MAX - 31 => Self::AdmitNumericSegmentBegin,
            value if value == u64::MAX - 32 => Self::MapOwnerConstructorCheck,
            value if value == u64::MAX - 33 => Self::BorrowedRecordMapProject,
            value if value == u64::MAX - 34 => Self::BorrowedRecordMapRead,
            value if value == u64::MAX - 35 => Self::Utf8ReadPrepare,
            value if value == u64::MAX - 36 => Self::Utf8ReadFinish,
            value if value == u64::MAX - 37 => Self::UniformFillPrepare,
            value if value == u64::MAX - 38 => Self::UniformFillFinish,
            value if value == u64::MAX - 41 => Self::NumericMapPrepare,
            value if value == u64::MAX - 42 => Self::NumericMapFinish,
            value if value == u64::MAX - 52 => Self::NumericReductionFinish,
            value if value == u64::MAX - 53 => Self::NumericTransposeFinish,
            value if value == u64::MAX - 54 => Self::NumericBinaryPrepare,
            value if value == u64::MAX - 55 => Self::NumericBinaryFinish,
            value if value == u64::MAX - 58 => Self::NumericProductPrepare,
            value if value == u64::MAX - 59 => Self::NumericProductFinish,
            value if value == u64::MAX - 56 => Self::NumericGeneratorPrepare,
            value if value == u64::MAX - 57 => Self::NumericGeneratorFinish,
            value if value == u64::MAX - 39 => Self::HistogramPrepare,
            value if value == u64::MAX - 40 => Self::HistogramFinish,
            value if value == u64::MAX - 43 => Self::WordCollectionPrepare,
            value if value == u64::MAX - 44 => Self::WordCollectionFinish,
            value if value == u64::MAX - 47 => Self::MapMatrixKey,
            value if value == u64::MAX - 48 => Self::MapKeys,
            value if value == u64::MAX - 49 => Self::MapDictionaryEnd,
            value if value == u64::MAX - 50 => Self::MapSeedFrame,
            value if value == u64::MAX - 51 => Self::MapOwnerBeginBorrowedValues,
            value => Self::Output(OutputIndex(value - 3)),
        }
    }
    pub const fn raw(self) -> u64 {
        match self {
            Self::Library => 0,
            Self::Move => 1,
            Self::Collection => 2,
            Self::Output(OutputIndex(index)) => index + 3,
            Self::WindowPrepare => u64::MAX - 1,
            Self::WindowFinish => u64::MAX - 2,
            Self::StringMapPrepare => u64::MAX - 3,
            Self::StringMapFinish => u64::MAX - 4,
            Self::BorrowedStringsPrepare => u64::MAX - 5,
            Self::BorrowedStringFailure => u64::MAX - 6,
            Self::ClosedTailBegin => u64::MAX - 7,
            Self::ClosedTailEnd => u64::MAX - 8,
            Self::PrefixPause => u64::MAX - 9,
            Self::PrefixBorrowedResume => u64::MAX - 10,
            Self::PrefixTailResume => u64::MAX - 11,
            Self::PrefixScanned => u64::MAX - 12,
            Self::JoinMapPrepare => u64::MAX - 13,
            Self::JoinMapFinish => u64::MAX - 14,
            Self::StructuralObservation => u64::MAX - 15,
            Self::MapOwnerBegin => u64::MAX - 16,
            Self::MapOwnerCall => u64::MAX - 17,
            Self::MapOwnerEnd => u64::MAX - 18,
            Self::MapOwnerSpan => u64::MAX - 19,
            Self::ParallelRun => u64::MAX - 20,
            Self::ParallelTake => u64::MAX - 21,
            Self::ParallelYield => u64::MAX - 22,
            Self::ParallelEnter => u64::MAX - 23,
            Self::FrozenMapCopy => u64::MAX - 24,
            Self::FrozenMapRead => u64::MAX - 25,
            Self::NumericWritePrepare => u64::MAX - 26,
            Self::NumericSegmentBegin => u64::MAX - 27,
            Self::NumericSegmentEnd => u64::MAX - 28,
            Self::AdmitMove => u64::MAX - 29,
            Self::AdmitStructuralObservation => u64::MAX - 30,
            Self::AdmitNumericSegmentBegin => u64::MAX - 31,
            Self::MapOwnerConstructorCheck => u64::MAX - 32,
            Self::BorrowedRecordMapProject => u64::MAX - 33,
            Self::BorrowedRecordMapRead => u64::MAX - 34,
            Self::Utf8ReadPrepare => u64::MAX - 35,
            Self::Utf8ReadFinish => u64::MAX - 36,
            Self::UniformFillPrepare => u64::MAX - 37,
            Self::UniformFillFinish => u64::MAX - 38,
            Self::NumericMapPrepare => u64::MAX - 41,
            Self::NumericMapFinish => u64::MAX - 42,
            Self::NumericReductionFinish => u64::MAX - 52,
            Self::NumericTransposeFinish => u64::MAX - 53,
            Self::NumericBinaryPrepare => u64::MAX - 54,
            Self::NumericBinaryFinish => u64::MAX - 55,
            Self::NumericProductPrepare => u64::MAX - 58,
            Self::NumericProductFinish => u64::MAX - 59,
            Self::NumericGeneratorPrepare => u64::MAX - 56,
            Self::NumericGeneratorFinish => u64::MAX - 57,
            Self::HistogramPrepare => u64::MAX - 39,
            Self::HistogramFinish => u64::MAX - 40,
            Self::WordCollectionPrepare => u64::MAX - 43,
            Self::WordCollectionFinish => u64::MAX - 44,
            Self::MapMatrixKey => u64::MAX - 47,
            Self::MapKeys => u64::MAX - 48,
            Self::MapDictionaryEnd => u64::MAX - 49,
            Self::MapSeedFrame => u64::MAX - 50,
            Self::MapOwnerBeginBorrowedValues => u64::MAX - 51,
        }
    }
    #[cfg(feature = "canonical-native-program")]
    pub fn output(index: u64) -> Option<Self> {
        let raw = index.checked_add(3)?;
        match Self::decode(raw) {
            value @ Self::Output(_) => Some(value),
            _ => None,
        }
    }
}

#[cfg(feature = "canonical-native-program-runtime")]
pub(in crate::native_artifact) mod abi;

#[cfg(all(test, feature = "canonical-native-program"))]
#[test]
fn collection_helpers_have_distinct_roundtrip_codes_and_reserve_output_space() {
    let tags = [
        GlobalHelper::UniformFillPrepare,
        GlobalHelper::UniformFillFinish,
        GlobalHelper::HistogramPrepare,
        GlobalHelper::HistogramFinish,
        GlobalHelper::NumericMapPrepare,
        GlobalHelper::NumericMapFinish,
        GlobalHelper::NumericReductionFinish,
        GlobalHelper::NumericTransposeFinish,
        GlobalHelper::NumericBinaryPrepare,
        GlobalHelper::NumericBinaryFinish,
        GlobalHelper::NumericProductPrepare,
        GlobalHelper::NumericProductFinish,
        GlobalHelper::NumericGeneratorPrepare,
        GlobalHelper::NumericGeneratorFinish,
        GlobalHelper::MapMatrixKey,
        GlobalHelper::MapKeys,
        GlobalHelper::MapDictionaryEnd,
        GlobalHelper::MapSeedFrame,
        GlobalHelper::MapOwnerBeginBorrowedValues,
    ];
    let mut codes = std::collections::BTreeSet::new();
    for tag in tags {
        assert!(codes.insert(tag.raw()));
        assert_eq!(GlobalHelper::decode(tag.raw()), tag);
        assert!(GlobalHelper::output(tag.raw() - 3).is_none());
    }
}
