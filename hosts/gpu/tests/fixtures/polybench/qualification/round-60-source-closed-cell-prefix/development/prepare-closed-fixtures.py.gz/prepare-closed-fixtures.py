from pathlib import Path
import subprocess,json,os
f=Path(__file__).resolve().parent;s=(f/'corrected-cell-prefix-tests.rs').read_text()
s=s.replace('fn source(expression: &str) -> String {','fn source(expression: &str, shape: [u64; 2]) -> String {\n    let [rows,columns]=shape;')
s=s.replace('r#"#Walk','r#"+> math\n#Walk').replace('<[f64]>','<[f64]:{rows},{columns}>')
s=s.replace('        for artifact in artifacts(&source(expression)) {','        for shape in [[2,5],[5,2],[1,10]] {\n        for artifact in artifacts(&source(expression,shape)) {')
s=s.replace('            for shape in [[2, 5], [5, 2], [1, 10]] {','')
s=s.replace('artifacts(&source("(a[r,c] + a[r,c + offset]) / gain"))','artifacts(&source("(a[r,c] + a[r,c + offset]) / gain",[3,4]))')
s=s.replace('source("a[r,c] + a[r,c + offset]")','source("a[r,c] + a[r,c + offset]",[2,5])')
(f/'closed-cell-prefix-tests.rs').write_text(s)
start=s.index('format!(r#"')+len('format!(r#"');template=s[start:s.index('"#)',start)].replace('{{','{').replace('}}','}')
base=template.replace('{expression}','a[r,c] + a[r,c + offset]').replace('{rows}','2').replace('{columns}','5')
examples={'ordinary':base,'integer':base.replace('f64','u64'),'split':base.replace('value := a[r,c] + a[r,c + offset]','x := a[r,c]\n        ~changed := a\n        changed[r,c] = gain\n        value := x + changed[r,c + offset]'),'branch':base.replace('value := a[r,c] + a[r,c + offset]','x := a[r,c]\n        choice := gain > 0.0\n        value := x + (choice? | true => a[r,c + offset] | false => a[r,c])')}
for name,source in examples.items():
 path=f/f'closed-fixture-{name}.mec';path.write_text(source);env=os.environ.copy();env['MECH_SOURCE_CFG_DUMP']=str(f/f'closed-fixture-{name}-cfg.txt');r=subprocess.run([str(f/'source-plan-driver'),str(path),str(f.parent.parent/'round-70/closest-parity-first/seidel-2d-inputs.json'),'0'],env=env,text=True,capture_output=True)
 (f/f'closed-fixture-{name}-parse.stdout').write_text(r.stdout);(f/f'closed-fixture-{name}-parse.stderr').write_text(r.stderr);assert r.returncode==0 and json.loads(r.stdout.strip().splitlines()[-1])['status']=='ok',(name,r.stdout,r.stderr)
 print(name,'closed FSM canonical CFG accepted; not executed',flush=True)
