from pathlib import Path
import subprocess,json,os
f=Path(__file__).resolve().parent;root=Path.cwd();p=root/'hosts/gpu/src/native_artifact/program/runtime/composition_tests/cell_prefix.rs';s=p.read_text();a=s.index('fn source(expression: &str) -> String {');z=s.index('\n#[test]',a)
s=s[:a]+'''fn source(expression: &str) -> String {
    format!(r#"#Walk(initial<[f64]>, row<u64>, first<u64>, end<u64>, offset<u64>, gain<f64>) => <[f64]>
  | :Sweep(a<[f64]>, r<u64>, c<u64>, end<u64>, offset<u64>, gain<f64>)
  | :Done(a<[f64]>).
#Walk(initial,row,first,end,offset,gain) -> :Sweep(initial,row,first,end,offset,gain)
  :Sweep(a,r,c,end,offset,gain)
    | c >= end -> :Done(a)
    | * -> {{
        value := {expression}
        ~next := a
        next[r,c] = value
      }} -> :Sweep(next,r,c + 1u64,end,offset,gain)
  :Done(a) => a.
a := input<[f64]>
answer := #Walk(a,row<u64>,first<u64>,last<u64>,offset<u64>,gain<f64>)
(answer,a)
"#)
}
'''+s[z:]
a=s.index('    let split');z=s.index('    for source in cases {',a)
s=s[:a]+'''    let split = ordinary.replace("value := a[r,c] + a[r,c + offset]", "x := a[r,c]\\n        ~changed := a\\n        changed[r,c] = gain\\n        value := x + changed[r,c + offset]");
    let branch = ordinary.replace("value := a[r,c] + a[r,c + offset]", "x := a[r,c]\\n        choice := gain > 0.0\\n        value := x + (choice? | true => a[r,c + offset] | false => a[r,c])");
    let cases=[ordinary.replace("f64","u64"),split,branch];
'''+s[z:]
(f/'corrected-cell-prefix-tests.rs').write_text(s)
# An unchanged accepted59 public frontend host validates only source syntax/CFG;
# no new compiler is built and none of these sources is executed or timed.
template=s[s.index('format!(r#"')+len('format!(r#"'):s.index('"#)',s.index('format!(r#"'))]
template=template.replace('{{','{').replace('}}','}')
base=template.replace('{expression}','a[r,c] + a[r,c + offset]')
examples={'ordinary':base,'integer':base.replace('f64','u64'),'split':base.replace('value := a[r,c] + a[r,c + offset]','x := a[r,c]\n        ~changed := a\n        changed[r,c] = gain\n        value := x + changed[r,c + offset]'),'branch':base.replace('value := a[r,c] + a[r,c + offset]','x := a[r,c]\n        choice := gain > 0.0\n        value := x + (choice? | true => a[r,c + offset] | false => a[r,c])')}
for name,source in examples.items():
 source_path=f/f'fixture-{name}.mec';source_path.write_text(source);env=os.environ.copy();env['MECH_SOURCE_CFG_DUMP']=str(f/f'fixture-{name}-cfg.txt')
 argv=[str(f/'source-plan-driver'),str(source_path),str(f.parent.parent/'round-70/closest-parity-first/seidel-2d-inputs.json'),'0'];r=subprocess.run(argv,cwd=root,env=env,text=True,capture_output=True)
 (f/f'fixture-{name}-parse.stdout').write_text(r.stdout);(f/f'fixture-{name}-parse.stderr').write_text(r.stderr);assert r.returncode==0 and json.loads(r.stdout.strip().splitlines()[-1])['status']=='ok',(name,r.stdout,r.stderr)
 print(name,'accepted canonical frontend CFG, not executed',flush=True)
