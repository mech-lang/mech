"""One frozen formal run; retain the same process until its terminal exit."""
import json,os,subprocess,sys,time
from pathlib import Path
folder=Path(__file__).resolve().parent
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
command=[sys.executable,str(folder/'measure-candidate.py'),head]
state=json.loads((folder/'current-work.json').read_text());state.update(stage='Frozen formal evaluation running: both aggregate sets once, no Rust edits or other jobs',pid=os.getpid());(folder/'current-work.json').write_text(json.dumps(state,indent=2)+'\n')
started=time.monotonic()
with (folder/'formal-measurement.log').open('x') as log:
 child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
 print('Formal measurement process',child.pid,'source',head,flush=True)
 while True:
  try:code=child.wait(timeout=30);break
  except subprocess.TimeoutExpired:print('Waiting on same formal measurement process',child.pid,flush=True)
(folder/'formal-exit.json').write_text(json.dumps({'command':command,'pid':child.pid,'exit_code':code,'wall_seconds':time.monotonic()-started})+'\n')
print('Formal measurement terminal exit',code,flush=True)
if code:raise SystemExit(code)
result=subprocess.run([sys.executable,str(folder/'audit-results.py')],capture_output=True,text=True)
(folder/'formal-audit.log').write_text(result.stdout+result.stderr)
print(result.stdout,flush=True)
if result.returncode:print(result.stderr,flush=True)
raise SystemExit(result.returncode)
