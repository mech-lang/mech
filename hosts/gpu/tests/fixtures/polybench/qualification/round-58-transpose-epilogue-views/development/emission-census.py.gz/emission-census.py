"""Optimization-only genuine Objects and combined source-prefix/fallback evidence."""
import hashlib,importlib.util,json,re,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(s);s.loader.exec_module(b)
protocol,cases=b.protocol();q=b.read(folder/'qualification.json');plan=b.read(folder/'plan.json');fp=b.compiler_fingerprint();assert q['complete']and q['compiler_fingerprint']==fp
actors={'accepted56':Path(plan['accepted_driver']),'candidate':Path(q['driver'])};assert b.digest(actors['accepted56'])==plan['accepted_driver_sha256']and b.digest(actors['candidate'])==q['driver_sha256']
objects=folder/'objects';objects.mkdir(exist_ok=False)
def functions(asm):
 rows={};name=None
 for line in asm.splitlines():
  m=re.match(r'^[0-9a-f]+ <_(.+)>:',line)
  if m:name=m[1];rows[name]=[]
  elif name and re.match(r'^\s*[0-9a-f]+:',line):rows[name].append(line)
 return {name:{'instructions':len(lines),'disassembly_sha256':hashlib.sha256('\n'.join(lines).encode()).hexdigest()}for name,lines in rows.items()}
def records(value,key):
 if isinstance(value,dict):return sum((v if k==key else records(v,key)for k,v in value.items()),[])
 if isinstance(value,list):return sum((records(v,key)for v in value),[])
 return []
r={'schema':'mech.polybench.transpose-epilogue-view-static-telemetry.v1','scope':'Optimization15 genuine checked Object export/static instructions and source-derived recipe records only; no linked Object execution, timing observations, retired hardware counts, memory traffic or RSS claims.','compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'cases':{},'complete':False,'performance_observations':0}
for name in protocol['optimization']:
 config=folder/f'{name}-inputs.json';b.write(config,cases[name]['inputs']);row={'actors':{}};r['cases'][name]=row
 for actor,driver in actors.items():
  obj=objects/f'{name}-{actor}.o';argv=[str(driver),str(b.FIXTURE/f'{name}.mec'),str(config),'0',f'emit-object={obj}'];stdout=objects/f'{name}-{actor}.stdout';stderr=objects/f'{name}-{actor}.stderr'
  with stdout.open('x')as out,stderr.open('x')as err:
   child=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err);r['pending']={'case':name,'actor':actor,'pid':child.pid,'command':argv};b.write(folder/'emission-census.json',r)
   while True:
    try:code=child.wait(timeout=30);break
    except subprocess.TimeoutExpired:print('Waiting on same Object process',child.pid,flush=True)
  assert code==0,stderr.read_text();r.pop('pending');status=json.loads(stdout.read_text().strip().splitlines()[-1]);assert status['status']=='ok'and status['mode']=='emit-object'
  md=b.read(obj.with_suffix('.metadata.json'));asm=subprocess.run(['/Library/Developer/CommandLineTools/usr/bin/llvm-objdump','--disassemble','--no-show-raw-insn',str(obj)],text=True,capture_output=True,check=True).stdout;disasm=obj.with_suffix('.disasm.txt');disasm.write_text(asm);fm=functions(asm);assert fm and any(v['instructions']for v in fm.values())
  row['actors'][actor]={'code_bytes':md['code_bytes'],'reported_native_stack_bytes':md['stack_bytes'],'metadata_bound_bytes':md.get('native_metadata_bytes'),'object_file_bytes':obj.stat().st_size,'static_instruction_count':sum(v['instructions']for v in fm.values()),'functions':fm,'object_sha256':b.digest(obj),'metadata_sha256':b.digest(obj.with_suffix('.metadata.json')),'disassembly_sha256':b.digest(disasm),'object_executed':False,'product_epilogues':md.get('compiled_product_epilogues',[]),'reduction_producers':md.get('compiled_reduction_producers',[]),'hardware_division_sites':len(re.findall(r'\budiv\b',asm)),'fused_multiply_add_instructions':len(re.findall(r'\b(?:fmadd|fmsub|fnmadd|fnmsub|fmla|fmls)\b',asm))}
  for key in ['masked_matrix_maps','guarded_map_initializations','compound_matrix_maps']:row['actors'][actor][key]=records(md,key)
 a=row['actors']['accepted56'];c=row['actors']['candidate'];row['functions_match']=a['functions']==c['functions'];row['code_bytes_match']=a['code_bytes']==c['code_bytes']
 assert all(old in c['product_epilogues']for old in a['product_epilogues']), 'Existing suffix recipe must survive independently'
 for key in ['reduction_producers','masked_matrix_maps','guarded_map_initializations','compound_matrix_maps']:assert a[key]==c[key]
 old_entries={x['entry']for x in a['product_epilogues']};prefixes=[x for x in c['product_epilogues']if x['entry']not in old_entries]
 row['new_view_prefixes']=prefixes;proof=[]
 for prefix in prefixes:
  assert prefix['parent']is None and len(prefix['operators'])>=2 and prefix['entry']==prefix['operators'][0]
  sites=set(prefix['sites']);overlap=[old for old in a['product_epilogues']if sites.intersection(old['sites'])]
  assert all(set(old['sites'])<=sites for old in overlap), 'View must preserve the full old arithmetic suffix'
  assert all(not set(x['sites']).intersection(y['sites'])for i,x in enumerate(overlap)for y in overlap[i+1:])
  removed=len(prefix['sites'])-1-sum(len(old['sites'])-1 for old in overlap);assert removed>=1
  proof.append({'new_prefix':prefix,'retained_materialized_suffixes':overlap,'source_group_invocations':1,'proved_visit_delta':-removed,'physical_transpose_banks_removed_on_success':1,'basis':'Only new discovery is source-closed left transpose/product epilogue. All prior suffix records are retained exactly. Complete same-parent straight CFG source steps execute once for these optimization scripts; one successful combined transition replaces original source visits minus already-elided suffix visits. Ordinary paths and all original source fees remain.'})
 row['visit_proof']=proof;row['expected_visit_delta']=sum(p['proved_visit_delta']for p in proof)
 b.write(folder/'emission-census.json',r);print(name,'view prefixes',len(prefixes),'visit delta',row['expected_visit_delta'],'code',a['code_bytes'],'->',c['code_bytes'],flush=True)
r['native_code_changed_cases']=[name for name,row in r['cases'].items()if not row['functions_match']or not row['code_bytes_match']]
r['view_cases']=[name for name,row in r['cases'].items()if row['new_view_prefixes']]
r['ordinary_product_code_unchanged']=all(row['functions_match']and row['code_bytes_match']for row in r['cases'].values()if not row['new_view_prefixes'])
r['no_new_fma']=all(row['actors']['candidate']['fused_multiply_add_instructions']<=row['actors']['accepted56']['fused_multiply_add_instructions']for row in r['cases'].values())
r['transpose_prefixes_emitted']='mvt'in r['view_cases']and len(r['view_cases'])>=3
r.update(complete=len(r['cases'])==15,source_unchanged=b.compiler_fingerprint()==fp)
r['passed']=r['complete']and r['source_unchanged']and r['transpose_prefixes_emitted']and r['ordinary_product_code_unchanged']and r['no_new_fma'];b.write(folder/'emission-census.json',r);assert r['passed'];print('Combined view/epilogue Object evidence passed',r['view_cases'],flush=True)
