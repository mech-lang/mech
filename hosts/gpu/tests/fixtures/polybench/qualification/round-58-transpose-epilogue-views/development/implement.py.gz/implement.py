from pathlib import Path
import json
root=Path.cwd();f=Path(__file__).resolve().parent
for name in json.loads((f/'plan.json').read_text())['source_paths']:
 p=root/name
 if p.exists():
  out=f/'source-before'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes())
base=root/'hosts/gpu/src/native_artifact'
p=base/'program/prepare/numeric_product_epilogues.rs';s=p.read_text();s=s.replace('matches!(self.kind, Kind::Sum { .. })','matches!(self.kind, Kind::Sum { .. } | Kind::Transpose { .. })',1)
needle='''    pub fn reduction_axis(&self) -> Option<usize> {'''
methods='''    pub fn product_index(&self) -> Option<usize> {
        match self.nodes.first()?.kind {
            Kind::Product => Some(0),
            Kind::Transpose { .. } if self.nodes.get(1)?.kind == Kind::Product => Some(1),
            _ => None,
        }
    }
    pub fn transposed_left(&self) -> bool {
        self.product_index() == Some(1)
    }
    /// Original physical roots. A virtual transpose is only the product's left
    /// operand; it has no scalar cell value or separately materialized bank.
    pub fn physical_roots(&self) -> Option<[usize; 2]> {
        let first = self.nodes.first()?;
        if self.transposed_left() {
            let [Source::Node(0), Source::External(right)] = self.nodes.get(1)?.inputs else { return None; };
            let Source::External(left) = first.inputs[0] else { return None; };
            Some([left, right])
        } else {
            let [Source::External(left), Source::External(right)] = first.inputs else { return None; };
            Some([left, right])
        }
    }
'''
assert needle in s;s=s.replace(needle,methods+needle,1)
s=s.replace('fn discover(plan: &Plan, facts: &Facts<\'_>, operators: &Layout, entry: u32) -> Option<Candidate> {','fn discover(plan: &Plan, facts: &Facts<\'_>, operators: &Layout, entry: u32, view: bool) -> Option<Candidate> {',1)
old='''    if !matches!(first, Kind::Product | Kind::Elementwise(_)) {
        return None;
    }
    let product = first == Kind::Product;'''
new='''    if if view { !matches!(first, Kind::Transpose { .. }) } else { !matches!(first, Kind::Product | Kind::Elementwise(_)) } {
        return None;
    }
    let product = view || first == Kind::Product;'''
assert old in s;s=s.replace(old,new,1)
s=s.replace('''                let sum = matches!(op.kind, Kind::Sum { .. });''','''                let sum = matches!(op.kind, Kind::Sum { .. });
                let unary = sum || matches!(op.kind, Kind::Transpose { .. });''',1)
s=s.replace('operands.len() != if sum { 1 } else { 2 }','operands.len() != if unary { 1 } else { 2 }',1)
s=s.replace('''                    || (!nodes.is_empty() && product && !matches!(op.kind, Kind::Elementwise(_)))''','''                    || (!nodes.is_empty() && product && if view && nodes.len() == 1 { op.kind != Kind::Product } else { !matches!(op.kind, Kind::Elementwise(_)) })''',1)
s=s.replace('operands[if sum { 0 } else { 1 }]','operands[if unary { 0 } else { 1 }]',1)
needle='''                if sum && !matches!(left, Source::Node(_)) {'''
check='''                if view && ((nodes.len() == 1 && (left != Source::Node(0) || !matches!(right, Source::External(_))))
                    || (nodes.len() > 1 && [left, right].contains(&Source::Node(0)))) {
                    break;
                }
'''
assert needle in s;s=s.replace(needle,check+needle,1)
s=s.replace('''pub(in crate::native_artifact) fn derive(plan: &Plan, operators: &Layout) -> Vec<Candidate> {
    let mut covered''','''pub(in crate::native_artifact) fn derive(plan: &Plan, operators: &Layout) -> Vec<Candidate> {
    derive_kind(plan, operators, false)
}
pub(in crate::native_artifact) fn derive_views(plan: &Plan, operators: &Layout) -> Vec<Candidate> {
    derive_kind(plan, operators, true)
}
fn derive_kind(plan: &Plan, operators: &Layout, view: bool) -> Vec<Candidate> {
    let mut covered''',1)
s=s.replace('discover(plan, &plan.facts(), operators, u32::try_from(at).ok()?)','discover(plan, &plan.facts(), operators, u32::try_from(at).ok()?, view)',1);p.write_text(s)
p=base/'program/prepare/numeric_binary.rs';s=p.read_text();s=s.replace('''    epilogues: Box<[Option<super::numeric_product_epilogues::Candidate>]>,''','''    epilogues: Box<[Option<super::numeric_product_epilogues::Candidate>]>,
    transpose_epilogues: Box<[Option<super::numeric_product_epilogues::Candidate>]>,''',1)
s=s.replace('''            epilogues: vec![None; sites.len()].into_boxed_slice(),''','''            epilogues: vec![None; sites.len()].into_boxed_slice(),
            transpose_epilogues: vec![None; sites.len()].into_boxed_slice(),''',1)
needle='''        Ok(result)
    }
    pub fn epilogue''';replace='''        for recipe in super::numeric_product_epilogues::derive_views(plan, &result) {
            let entry = recipe.entry as usize;
            result.transpose_epilogues[entry] = Some(recipe);
        }
        Ok(result)
    }
    pub fn transpose_epilogue(&self, site: usize) -> Option<&super::numeric_product_epilogues::Candidate> {
        self.transpose_epilogues.get(site)?.as_ref()
    }
    pub fn epilogue''';assert needle in s;s=s.replace(needle,replace,1)
s=s.replace('''        self.epilogues.get(site)?.as_ref()''','''        self.transpose_epilogue(site).or_else(|| self.epilogues.get(site)?.as_ref())''',1)
s=s.replace('''        self.epilogues
            .iter()
            .flatten()''','''        self.epilogues
            .iter()
            .chain(self.transpose_epilogues.iter())
            .flatten()''',1);p.write_text(s)
p=base/'program/codegen/numeric_product_epilogues.rs';s=p.read_text();s=s.replace('mut values: Vec<Value>','mut values: Vec<Option<Value>>',1).replace('Source::Node(n) => values[n],','Source::Node(n) => values[n].expect("proved cell source excludes virtual transpose"),',1).replace('values.push(value);','values.push(Some(value));',1).replace('*values.last().unwrap()','values.last().copied().flatten().expect("final scalar cell")',1)
s=s.replace('''        self.expression(
            b,
            vec![product],''','''        // The virtual view has no per-cell scalar. Keep its node slot empty;
        // the closed source proof permits it only as the product's operand.
        let mut values = vec![None; self.recipe.product_index().expect("selected product")];
        values.push(Some(product));
        self.expression(
            b,
            values,''',1)
needle="impl Epilogue<'_> {";assert needle in s;s=s.replace(needle,needle+'''
    pub(super) fn transposed_left(&self) -> bool { self.recipe.transposed_left() }
''',1)
s=s.replace('''            && recipe.nodes.first().is_none_or(|n| n.kind != Kind::Product))''','''            && recipe.product_index().is_none())''',1);p.write_text(s)
p=base/'program/runtime/invocation/numeric_product_epilogues.rs';s=p.read_text();s=s.replace('''        let reduction_axis = recipe.reduction_axis();''','''        let reduction_axis = recipe.reduction_axis();
        let product_index = recipe.product_index();''',1)
s=s.replace('''                    Kind::Product if index == 0 => {''','''                    Kind::Transpose { .. } if recipe.transposed_left() && index == 0 => {
                        let [r, c, count] = call.f64_matrix_transpose_geometry(inputs[0])?;
                        if r.checked_mul(c)? != count { return None; }
                        (r, c, 0)
                    }
                    Kind::Product if Some(index) == product_index => {''',1)
s=s.replace('''                        if (index > 0 || reduction_axis.is_some())''','''                        if (product_index.is_some_and(|p| index > p) || reduction_axis.is_some())''',1)
s=s.replace('''                    Kind::Sum { .. } => call.f64_matrix_sum_source_bound(input_count, count)?,''','''                    Kind::Sum { .. } => call.f64_matrix_sum_source_bound(input_count, count)?,
                    Kind::Transpose { .. } => call.f64_matrix_transpose_source_bound(count)?,''',1)
s=s.replace('''                    Kind::Sum { .. } => call.f64_matrix_sum_source_bound(inputs, output)?,''','''                    Kind::Sum { .. } => call.f64_matrix_sum_source_bound(inputs, output)?,
                    Kind::Transpose { .. } => call.f64_matrix_transpose_source_bound(output)?,''',1)
s=s.replace('''        let [Source::External(left), Source::External(right)] = recipe.nodes[0].inputs else {''','''        let Some([left, right]) = recipe.physical_roots() else {''',1);p.write_text(s)
p=base/'program/codegen/numeric_product.rs';s=p.read_text();s=s.replace('''    index: Value,
    columns: Value,''','''    index: Value,
    count: Value,
    columns: Value,''',1)
s=s.replace('''    epilogue: Option<&Epilogue<'_>>,
) {
    let row''','''    epilogue: Option<&Epilogue<'_>>,
    transposed_left: bool,
) {
    let row''',1)
s=s.replace('''    let left_base = b.ins().imul(row, inner);''','''    let left_base = if transposed_left { row } else { b.ins().imul(row, inner) };''',1)
s=s.replace('''    let left_step = b.ins().iconst(types::I64, 8);''','''    let left_step = if transposed_left {
        // Only reached for a nonempty output, hence columns is nonzero.
        let rows = b.ins().udiv(count, columns);
        b.ins().imul_imm(rows, 8)
    } else { b.ins().iconst(types::I64, 8) };''',1)
s=s.replace('''        row_quartets,
        done,
    );
}
pub(super) fn emit_epilogue''','''        row_quartets,
        false,
        done,
    );
}
pub(super) fn emit_epilogue''',1)
s=s.replace('''        row_quartets,
        done,
    );
}
fn emit_body''','''        row_quartets,
        epilogue.transposed_left(),
        done,
    );
}
fn emit_body''',1)
s=s.replace('''    row_quartets: bool,
    done: Block,
) {
    if row_pairs''','''    row_quartets: bool,
    transposed_left: bool,
    done: Block,
) {
    if row_pairs''',1)
s=s.replace('''            row_quartets,
            done,
        );''','''            row_quartets,
            transposed_left,
            done,
        );''',1)
s=s.replace('''        cell(b, left, right, output, at, columns, inner, vector, epilogue);''','''        cell(b, left, right, output, at, count, columns, inner, vector, epilogue, transposed_left);''',1)
s+='''
#[cfg(test)]
#[path = "numeric_product_view_tests.rs"]
mod view_tests;
''';p.write_text(s)
p=base/'program/codegen/numeric_product_rows.rs';s=p.read_text();s=s.replace('''    epilogue: Option<&Epilogue<'_>>,
) {''','''    epilogue: Option<&Epilogue<'_>>,
    transposed_left: bool,
    rows: Value,
) {''',1)
s=s.replace('''    let left0 = b.ins().imul(row, inner);''','''    let left0 = if transposed_left { row } else { b.ins().imul(row, inner) };''',1)
s=s.replace('''        let base = b.ins().imul(r, inner);''','''        let base = if transposed_left { r } else { b.ins().imul(r, inner) };''',1)
s=s.replace('''    let left_step = b.ins().iconst(types::I64, 8);''','''    let left_step = if transposed_left { b.ins().imul_imm(rows, 8) } else { b.ins().iconst(types::I64, 8) };''',1)
s=s.replace('''    quartets: bool,
    done: Block,''','''    quartets: bool,
    transposed_left: bool,
    done: Block,''',1)
s=s.replace('''                b, left, right, output, at_row, at_column, columns, inner, step, vector, epilogue,
            );''','''                b, left, right, output, at_row, at_column, columns, inner, step, vector, epilogue, transposed_left, rows,
            );''',1);p.write_text(s)
p=base/'codegen/options.rs';s=p.read_text();s=s.replace('''    ProductEpilogues,''','''    ProductEpilogues,
    /// Consume a closed left transpose inside the existing product/epilogue loan.
    TransposeProductEpilogues,''',1);p.write_text(s)
p=base/'codegen/control/mod.rs';s=p.read_text();needle='''controls.enabled(if recipe.reduction_axis().is_some() {''';assert needle in s;s=s.replace(needle,'''controls.enabled(if recipe.transposed_left() {crate::native_artifact::codegen::options::OptimizationPass::TransposeProductEpilogues} else if recipe.reduction_axis().is_some() {''',1);p.write_text(s)
p=base/'program/image/identity.rs';s=p.read_text();assert 'NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 425' in s;p.write_text(s.replace('NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 425','NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 427',1))
p=base/'program/runtime/composition_tests/mod.rs';s=p.read_text().replace('mod numeric_product_epilogues;','mod numeric_product_epilogues;\nmod numeric_product_views;',1);p.write_text(s)
print('Implemented source-closed prefix views, independent old suffix recipes, shared product strides and existing loan geometry/bounds; no build started.')
