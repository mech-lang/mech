from pathlib import Path
f=Path(__file__).resolve().parent;old=f.parents[1]/'round-64/transpose-tiles'
s=(old/'run-qualification.py').read_text().replace('transpose-tiles','transpose-epilogue-views').replace('transpose-epilogue-views-shuffle-driver','transpose-epilogue-views-driver')
a=s.index("receipt={'scope':");z=s.index('\nfor name,argv in checks:',a)
s=s[:a]+"receipt={'scope':'Source-closed transpose operand views inside the shared product epilogue loan: dynamic strict scalar/column-SIMD/1/2/4-row kernels, root/shape/current-ownership and original source demand, independent suffix fallback, exact bits and source errors, nonfinite partial replay, finite/physical caps, all forged frame/context/image cases, aliases/atomic cleanup/retry; maintained numeric/matrix/scalar/compression/type/source/image/all30 original-decoded-restored C and both features; no timing samples','compiler_fingerprint':fp,'checks':[]}"+s[z:]
(f/'run-qualification.py').write_text(s)
s=(old/'prepare-qualification-manifest.py').read_text().replace('transpose-tiles-shuffle-driver','transpose-epilogue-views-driver').replace('==[3]','==[10]');(f/'prepare-qualification-manifest.py').write_text(s)
s=(old/'training-probe.py').read_text().replace('transpose-tiles','transpose-epilogue-views').replace("emission['transpose_tiles_emitted']","emission['transpose_prefixes_emitted']")
s=s.replace('physical visits remain unchanged for this transformation; every other counter must match accepted56','physical visits may decrease only by the independently proved source-step transition delta; every other counter must match accepted56')
(f/'training-probe.py').write_text(s);(f/'run-training-probe.py').write_text((old/'run-training-probe.py').read_text())
print('Prepared broad qualification and one-probe wrappers, fixed accepted56 controls and unchanged shared benchmark runner.')
