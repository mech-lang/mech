//! Closed view prefixes reuse the current product-epilogue loan and suffix replay.
use super::*;
use crate::native_artifact::codegen::options::OptimizationPass;
use crate::native_artifact::program::prepare::numeric_binary::Kind;
use mech_core::snapshot::F64Bits;
const EXPRESSION: &str =
    "a := left<[f64]>\nb := right<[f64]>\nc := extra<[f64]>\ns := scale<f64>\ns * (a' ** b) + c\n";
fn matrix(words: &[u64], shape: [u64; 2]) -> Data {
    Data::Matrix(
        (0..shape[0] * shape[1])
            .map(|i| Data::F64(F64Bits::from_bits(words[i as usize % words.len()])))
            .collect(),
    )
}
fn outputs(values: &[Option<Value>]) -> Vec<Data> {
    values
        .iter()
        .map(|v| v.as_ref().unwrap().canonical_data_draft().unwrap())
        .collect()
}
fn recipe(
    jit: &JitProgramArtifact,
) -> &crate::native_artifact::program::prepare::numeric_product_epilogues::Candidate {
    let m = jit.descriptor().metadata();
    (0..m.plan.blocks().len())
        .find_map(|s| m.numeric_binary.transpose_epilogue(s))
        .unwrap()
}
#[test]
fn numeric_product_views_closed_graph_and_independent_suffix_objects() {
    for source in ["a<[f64]>' ** b<[f64]>\n", EXPRESSION] {
        for artifact in artifacts(source) {
            let catalog = mech_stdlib::source_catalog();
            let jit = JitProgramArtifact::compile(&artifact, &catalog).unwrap();
            let m = jit.descriptor().metadata();
            let views = (0..m.plan.blocks().len())
                .filter_map(|s| m.numeric_binary.transpose_epilogue(s))
                .collect::<Vec<_>>();
            if views.is_empty() {
                for (i, b) in m.plan.blocks().iter().enumerate() {
                    eprintln!("{i}: {b:?}");
                }
            }
            assert_eq!(views.len(), 1, "{source}");
            let r = views[0];
            assert_eq!(r.product_index(), Some(1));
            assert!(r.transposed_left());
            assert!(r.physical_roots().is_some());
            assert!(matches!(r.nodes[0].kind, Kind::Transpose { .. }));
            assert_eq!(r.nodes[1].kind, Kind::Product);
            assert!(r.elided_values.contains(&r.nodes[0].output.get()));
            if source == EXPRESSION {
                let suffix = m.numeric_binary.epilogue(r.nodes[1].site as usize).unwrap();
                assert!(!suffix.transposed_left());
                assert_eq!(suffix.product_index(), Some(0));
            }
            let object = crate::native_artifact::emit_program_object(&artifact, &catalog).unwrap();
            assert!(
                object.metadata()["compiled_product_epilogues"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .any(|v| v["entry"].as_u64() == Some(u64::from(r.entry)))
            );
        }
    }
}
#[test]
fn numeric_product_views_decline_escaping_reused_wrong_side_or_nonproduct_views() {
    for source in [
        "t := a<[f64]>'\n(t,t ** b<[f64]>)\n",
        "a<[f64]> ** b<[f64]>'\n",
        "t := a<[f64]>'\nt + b<[f64]>\n",
        "t := a<[f64]>'\n(t ** b<[f64]>) + t\n",
        "t := a<[f64]>'\n(t ** b<[f64]>, t ** c<[f64]>)\n",
    ] {
        for artifact in artifacts(source) {
            let jit =
                JitProgramArtifact::compile(&artifact, &mech_stdlib::source_catalog()).unwrap();
            let m = jit.descriptor().metadata();
            assert!(
                (0..m.plan.blocks().len())
                    .all(|s| m.numeric_binary.transpose_epilogue(s).is_none()),
                "{source}"
            );
        }
    }
}
#[test]
fn numeric_product_views_ordered_bits_broadcasts_empty_axes_and_actual_elided_banks_restored() {
    let catalog = mech_stdlib::source_catalog();
    for artifact in artifacts(EXPRESSION) {
        let native = JitProgramArtifact::compile(&artifact, &catalog).unwrap();
        let materialized = JitProgramArtifact::compile_for_test(
            &artifact,
            &catalog,
            OptimizationPass::TransposeProductEpilogues,
        )
        .unwrap();
        let ordinary = JitProgramArtifact::compile_for_test(
            &artifact,
            &catalog,
            OptimizationPass::NumericMatrixArithmetic,
        )
        .unwrap();
        let r = recipe(&native);
        assert_eq!(r.nodes.len(), 4);
        for (left, right, extra) in [
            ([3, 2], [3, 5], [2, 5]),
            ([3, 2], [3, 5], [1, 5]),
            ([3, 2], [3, 5], [2, 1]),
            ([3, 2], [3, 5], [1, 1]),
            ([7, 5], [7, 3], [5, 3]),
            ([5, 1], [5, 1], [1, 1]),
            ([0, 3], [0, 5], [3, 5]),
            ([3, 0], [3, 5], [0, 5]),
            ([3, 2], [3, 0], [2, 0]),
        ] {
            let mode = NativeProgramLimitMode::NoLimits;
            let memory = mode.memory_budget();
            let words = [
                0.0f64.to_bits(),
                (-0.0f64).to_bits(),
                1.25f64.to_bits(),
                (-0.5f64).to_bits(),
                1,
                0x0010000000000000,
            ];
            let args = numeric_maps::typed_arguments(
                &artifact,
                &memory,
                &[
                    ("left", matrix(&words, left), &left),
                    ("right", matrix(&words, right), &right),
                    ("extra", matrix(&words, extra), &extra),
                    ("scale", Data::F64(F64Bits::from_f64(-0.75)), &[]),
                ],
            );
            let before = contents(&args);
            let baseline = (memory.used_bytes(), memory.retained_snapshot_nodes());
            let mut expected = vec![None; artifact.outputs().len()];
            ordinary
                .evaluate_into(&args, &mut expected, mode.execution(), &memory)
                .unwrap();
            let data = outputs(&expected);
            drop(expected);
            for restored in [false, true] {
                let mut output = vec![None; artifact.outputs().len()];
                let mut reference = output.clone();
                let (report, counts) = if restored {
                    observe::run_restored(&native, &args, &mut output, mode.execution(), &memory)
                } else {
                    observe::run(&native, &args, &mut output, mode.execution(), &memory)
                };
                let report = report.unwrap();
                let (reference_report, _) = observe::run(
                    &materialized,
                    &args,
                    &mut reference,
                    mode.execution(),
                    &memory,
                );
                let reference_report = reference_report.unwrap();
                assert_eq!(outputs(&output), data, "{left:?}/{right:?}/{extra:?}");
                assert_eq!(outputs(&reference), data);
                assert_eq!(
                    counts.product_epilogues,
                    vec![(r.entry as usize, 4, (left[1] * right[1]) as usize, false)]
                );
                assert!(report.work >= reference_report.work);
                assert!(report.comparison_work >= reference_report.comparison_work);
                let aliases = output.clone();
                let (retry, counts) =
                    observe::run_restored(&native, &args, &mut output, mode.execution(), &memory);
                retry.unwrap();
                assert_eq!(outputs(&output), outputs(&aliases));
                assert!(!counts.product_epilogues.is_empty());
                drop((output, reference, aliases));
                assert_eq!(
                    (memory.used_bytes(), memory.retained_snapshot_nodes()),
                    baseline
                );
            }
            assert_eq!(contents(&args), before);
            drop(args);
            assert_eq!(
                (memory.used_bytes(), memory.retained_snapshot_nodes()),
                (0, 0)
            );
        }
    }
}
#[test]
fn numeric_product_views_nonfinite_inputs_or_terms_replay_without_leaking_partial_output() {
    let catalog = mech_stdlib::source_catalog();
    for artifact in artifacts(EXPRESSION) {
        let native = JitProgramArtifact::compile(&artifact, &catalog).unwrap();
        let baseline = JitProgramArtifact::compile_for_test(
            &artifact,
            &catalog,
            OptimizationPass::TransposeProductEpilogues,
        )
        .unwrap();
        for nan in [false, true] {
            let mode = NativeProgramLimitMode::NoLimits;
            let memory = mode.memory_budget();
            let words = if nan {
                vec![1.0f64.to_bits(), 0x7ff8_1234_5678_9abc]
            } else {
                vec![f64::MAX.to_bits(), (-f64::MAX).to_bits()]
            };
            let args = numeric_maps::typed_arguments(
                &artifact,
                &memory,
                &[
                    ("left", matrix(&words, [3, 5]), &[3, 5]),
                    (
                        "right",
                        matrix(&[2.0f64.to_bits(), (-2.0f64).to_bits()], [3, 3]),
                        &[3, 3],
                    ),
                    ("extra", matrix(&[(-0.0f64).to_bits()], [5, 3]), &[5, 3]),
                    ("scale", Data::F64(F64Bits::from_f64(1.0)), &[]),
                ],
            );
            let mut actual = vec![None; artifact.outputs().len()];
            let mut expected = actual.clone();
            let (a, _) =
                observe::run_restored(&native, &args, &mut actual, mode.execution(), &memory);
            let (b, _) = observe::run(&baseline, &args, &mut expected, mode.execution(), &memory);
            a.unwrap();
            b.unwrap();
            assert_eq!(outputs(&actual), outputs(&expected));
            drop((actual, expected, args));
            assert_eq!(
                (memory.used_bytes(), memory.retained_snapshot_nodes()),
                (0, 0)
            );
        }
    }
}
