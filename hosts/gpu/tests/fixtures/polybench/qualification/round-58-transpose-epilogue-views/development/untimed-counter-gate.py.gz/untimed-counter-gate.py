"""Source work/counter conservation and proved physical visit reductions; no samples."""
import importlib.util,json,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(s);s.loader.exec_module(b)
plan=b.read(folder/'plan.json');q=b.read(folder/'qualification.json');fp=b.compiler_fingerprint();assert q['complete']and fp==q['compiler_fingerprint'];protocol,cases=b.protocol();reference=b.read(b.FIXTURE/'round-56-training-probe.json');emission=b.read(folder/'emission-census.json');assert emission['passed']and emission['transpose_prefixes_emitted']
actors={'accepted56':Path(plan['accepted_driver']),'candidate':Path(q['driver'])};assert b.digest(actors['accepted56'])==plan['accepted_driver_sha256']==b.read(b.FIXTURE/'round-56-frozen.json')['driver_sha256'];assert b.digest(actors['candidate'])==q['driver_sha256'];assert len(b.read(b.FIXTURE/'performance-history.json')['entries'])==58
output=folder/'untimed-counter-gate.json';assert not output.exists()
def counters(report):
 prefix='NativeProgramExecutionReport { ';assert report.startswith(prefix)and report.endswith(' }');return {k:int(v)for k,v in [s.split(': ')for s in report[len(prefix):-2].split(', ')]}
r={'schema':'mech.polybench.untimed-counter-gate.v3','created_at':b.utc(),'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'scope':'Optimization15 exact finite-output/source-accounting gate with source-proved physical visit reductions. No holdout diagnosis or timing samples.','plan_sha256':b.digest(b.FIXTURE/'training-experiments/transpose-epilogue-views-plan.json'),'cases':{},'complete':False,'performance_observations':0};b.write(output,r)
for index,name in enumerate(protocol['optimization']):
 config=folder/f'{name}-inputs.json';b.write(config,cases[name]['inputs']);row={'source_sha256':b.digest(b.FIXTURE/f'{name}.mec'),'inputs_sha256':b.digest(config),'actors':{}};r['cases'][name]=row
 for actor in (list(actors)if index%2==0 else list(reversed(actors))):
  argv=[str(actors[actor]),str(b.FIXTURE/f'{name}.mec'),str(config),'0'];stdout=folder/f'{name}-{actor}-untimed.stdout';stderr=folder/f'{name}-{actor}-untimed.stderr'
  with stdout.open('x')as out,stderr.open('x')as err:
   child=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err);r['pending']={'case':name,'actor':actor,'pid':child.pid,'command':argv};b.write(output,r)
   while True:
    try:code=child.wait(timeout=30);break
    except subprocess.TimeoutExpired:print('Waiting on same untimed gate process',child.pid,flush=True)
  row['actors'][actor]={'command':argv,'pid':child.pid,'exit_code':code,'stdout_sha256':b.digest(stdout),'stderr_sha256':b.digest(stderr)};r.pop('pending');b.write(output,r);assert code==0
  result=json.loads(stdout.read_text().strip().splitlines()[-1]);assert result['status']=='ok'and result['samples_seconds']==[]
  row['actors'][actor].update(counters=counters(result['report']),execution_report=result['report'],validation=b.validate(result['values'],cases[name]['expected']),timing_samples=0)
  if actor=='accepted56':assert result['report']==reference['cases'][name]['actors']['candidate']['execution_report']
 a=row['actors']['accepted56']['counters'];c=row['actors']['candidate']['counters'];assert set(a)==set(c);row['deltas']={k:c[k]-v for k,v in a.items()}
 row['all_counters_match']=all(v==0 for v in row['deltas'].values());row['work_not_reduced']=c['work']>=a['work']and c['comparison_work']>=a['comparison_work'];row['other_counters_match']=all(v==0 for k,v in row['deltas'].items()if k not in ['work','comparison_work','visits'])
 expected=emission['cases'][name]['expected_visit_delta'];row['visit_proof']={'proved':row['deltas']['visits']==expected,'kind':'source-closed-combined-transpose-product-epilogue'if expected else'unchanged','expected_delta':expected,'actual_delta':row['deltas']['visits'],'source_views':emission['cases'][name]['visit_proof'],'evidence':'Static genuine Object records identify exact complete same-parent source steps and retained old suffixes. Original operators/shape/demand/clone/retirement/replay obligations remain; only the source-proved synchronous combined control transition skips visits. No counter padding.'}
 row['passed']=row['work_not_reduced']and row['other_counters_match']and row['visit_proof']['proved'];b.write(output,r);print(name,'source fees preserved',row['work_not_reduced'],'visits',row['deltas']['visits'],'expected',expected,'passed',row['passed'],flush=True)
r.update(complete=True,completed_at=b.utc(),passed=len(r['cases'])==15 and all(row['passed']for row in r['cases'].values()),finite_liveouts=sum(row['actors']['candidate']['validation']['count']for row in r['cases'].values()),source_and_driver_unchanged=b.compiler_fingerprint()==fp and b.digest(actors['candidate'])==q['driver_sha256']);assert r['source_and_driver_unchanged'];b.write(output,r);assert r['passed'];print(json.dumps({k:r[k]for k in ['complete','passed','finite_liveouts','performance_observations']}),flush=True)
