from pathlib import Path
import subprocess
p=Path('hosts/gpu/src/native_artifact/program/codegen/readonly_numeric.rs');text=p.read_text();start=text.index('let old = if let Some(old) = known_old');at=text.index('                        b.switch_to_block(materialize);',start)+len('                        b.switch_to_block(materialize);');assert text[at:].startswith('\n                        boundary::materialize(')
text=text[:at]+'''
                        // Discard optional derived state before the original
                        // first-change helper, rather than keeping every cache
                        // float live through a cold caller-save boundary.
                        // The helper performs this same write; the next point
                        // refills through complete source admission.
                        for cache in &rolling_caches {
                            cache.invalidate(b);
                        }'''+text[at:];p.write_text(text)
p=Path('hosts/gpu/src/native_artifact/program/runtime/composition_tests/cell_prefix.rs');assert 'cell_prefix_rolling_first_change_after_noops_denial_previous_outputs_and_retry' not in p.read_text()
with p.open('a')as out:out.write(r'''

#[test]
fn cell_prefix_rolling_first_change_after_noops_denial_previous_outputs_and_retry() {
    for artifact in artifacts(&source(WINDOW,[5,8])) {
        let (fast,uncached,original)=rolling_pair(&artifact);
        let mode=NativeProgramLimitMode::NoLimits;let memory=mode.memory_budget();
        let mut cells=vec![Data::F64(F64Bits::from_f64(1.0));40];
        // Row2 has four no-op points before this right-hand cell first
        // changes an output, after the cache has already been reused.
        cells[2*8+6]=Data::F64(F64Bits::from_f64(2.0));
        let args=numeric_maps::typed_arguments(&artifact,&memory,&[("input",Data::Matrix(cells.into()),&[5,8]),("row",Data::U64(2),&[]),("first",Data::U64(2),&[]),("last",Data::U64(8),&[]),("offset",Data::U64(1),&[]),("gain",Data::F64(F64Bits::from_f64(9.0)),&[])]);
        let aliases=args.clone();let retained=(memory.used_bytes(),memory.retained_snapshot_nodes());
        for old in [&uncached,&original] {for restored in [false,true] {
            let mut outputs=vec![None;artifact.outputs().len()];let mut previous=outputs.clone();
            compare_pair(&fast,old,&args,&memory,mode.execution(),restored,&mut outputs,&mut previous);
            let published=super::ordered_map_dots::output(&outputs);
            let (a,counts)=observe::run_with_first_change_copy_limit(&fast,&args,&mut outputs,mode.execution(),&memory,restored,0);
            let (c,other)=observe::run_with_first_change_copy_limit(old,&args,&mut previous,mode.execution(),&memory,restored,0);
            assert!(a.is_err(),"copy denial occurs after original no-op points");
            assert_eq!(a.as_ref().map_err(|e|format!("{e:?}")),c.as_ref().map_err(|e|format!("{e:?}")));
            assert_eq!(counts.helpers,other.helpers);assert_eq!(counts.admits,other.admits);
            assert_eq!(super::ordered_map_dots::output(&outputs),published);
            assert_eq!(super::ordered_map_dots::output(&previous),published);
            assert_eq!(contents(&aliases),contents(&args));
            compare_pair(&fast,old,&args,&memory,mode.execution(),restored,&mut outputs,&mut previous);
            outputs.fill(None);previous.fill(None);
            assert_eq!((memory.used_bytes(),memory.retained_snapshot_nodes()),retained);
        }}
    }
}
''')
subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true',str(p),'hosts/gpu/src/native_artifact/program/codegen/numeric_cell_rolling.rs','hosts/gpu/src/native_artifact/program/codegen/readonly_numeric.rs','hosts/gpu/src/native_artifact/program/image/identity.rs'],check=True)
print('Precise CellWrite invalidation and first-change qualification source applied and formatted.')
