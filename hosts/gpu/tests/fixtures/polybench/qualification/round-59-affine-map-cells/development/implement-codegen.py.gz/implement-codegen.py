from pathlib import Path
root=Path.cwd();base=root/'hosts/gpu/src/native_artifact'
p=base/'program/codegen/numeric_map_selection.rs';s=p.read_text().replace('    full: bool,','    full: bool,\n    split: bool,').replace('            full: false,','            full: false,\n            split: comparison == Comparison::Ne,').replace('            full: true,','            full: true,\n            split: false,')
needle='    fn divisor(&self, b: &mut FunctionBuilder'
pos=s.index(needle)
s=s[:pos]+'''    fn intervals(&self, b: &mut FunctionBuilder<'_>) -> Vec<(Value, Value)> {
        let mut out = vec![(self.first, self.first_count)];
        if self.split {
            let tail = b.ins().isub(self.selected, self.first_count);
            out.push((self.second, tail));
        }
        out
    }
'''+s[pos:]
needle='    pub(in crate::native_artifact::program::codegen) fn count(&self)'
pos=s.index(needle)
s=s[:pos]+'''    /// Exact disjoint zero-based source boxes for independent cell evaluation.
    /// Axis0 is the source element (column in a rectangle), axis1 the inner row.
    /// This does not change selected publication or its initialization certificate.
    pub(in crate::native_artifact::program::codegen) fn windows(
        &self, b: &mut FunctionBuilder<'_>,
    ) -> Vec<([Value; 2], [Value; 2])> {
        let zero = b.ins().iconst(types::I64, 0);
        let one = b.ins().iconst(types::I64, 1);
        if !self.rectangular {
            let Coordinates::Single { range, .. } = &self.coordinates else { unreachable!() };
            return range.intervals(b).into_iter().map(|(first,count)| ([first,zero],[count,one])).collect();
        }
        let rows = b.ins().iconst(types::I64, self.rows as i64);
        let columns = b.ins().iconst(types::I64, self.columns as i64);
        let (row,column) = match &self.coordinates {
            Coordinates::Single { axis:Axis::Row, range } => (range.intervals(b),vec![(zero,columns)]),
            Coordinates::Single { axis:Axis::Column, range } => (vec![(zero,rows)],range.intervals(b)),
            Coordinates::Rectangle { row,column } => (row.intervals(b),column.intervals(b)),
        };
        row.into_iter().flat_map(|(r,nr)| column.iter().map(move |&(c,nc)| ([c,r],[nc,nr]))).collect()
    }
'''+s[pos:];p.write_text(s)
p=base/'program/codegen/numeric_map_dots/mod.rs';s=p.read_text().replace('mod batch;','pub(super) mod cells;\nmod windows;\nmod batch;');p.write_text(s)
p=base/'program/codegen/numeric_map_dots/streams.rs';s=p.read_text().replace('    outer_dependent: bool,','    outer_dependent: bool,\n    inner_dependent: bool,')
needle='    pub fn packed(&self, b: &mut FunctionBuilder'
pos=s.index(needle)
s=s[:pos]+'''    pub fn packed_inner(&self, b: &mut FunctionBuilder<'_>) -> Value {
        if self.inner_dependent {
            b.ins().icmp_imm(IntCC::Equal, self.inner_step, 8)
        } else {
            b.ins().iconst(types::I8, 1)
        }
    }
    pub fn cell(&self, b: &mut FunctionBuilder<'_>, inner: Value, outer: Value, vector: bool) -> Value {
        let dx = b.ins().imul(inner, self.inner_step);
        let dy = b.ins().imul(outer, self.outer_step);
        let displacement = b.ins().iadd(dx, dy);
        let pointer = b.ins().iadd(self.pointer, displacement);
        if vector && self.inner_dependent {
            b.ins().load(types::F64.by(2).unwrap(), MemFlags::new(), pointer, 0)
        } else {
            let value = b.ins().load(types::F64, MemFlags::new(), pointer, 0);
            if vector { b.ins().splat(types::F64.by(2).unwrap(), value) } else { value }
        }
    }
'''+s[pos:]
s=s.replace('        outer_dependent: operand.indices.iter().any(|i| i.dependencies[1]),','        outer_dependent: operand.indices.iter().any(|i| i.dependencies[1]),\n        inner_dependent: operand.indices.iter().any(|i| i.dependencies[0]),');p.write_text(s)
p=base/'program/codegen/numeric_map_dots/windows.rs';p.write_text(r'''//! Pure clipping of a source unsigned comparison against one current interval.
//! Returned offsets are relative to `start`; zero intervals stay empty even
//! when the unused wrapping predecessor/successor is not a source value.
use super::*;
use mech_engine::native_artifact::NativeScalarOp;
pub(super) fn comparison(
    b: &mut FunctionBuilder<'_>, op: NativeScalarOp, bound: Value, start: Value, count: Value,
) -> Vec<(Value, Value)> {
    use NativeScalarOp::*;
    let zero=b.ins().iconst(types::I64,0);
    let tail=b.ins().iadd_imm(count,-1);
    let last=b.ins().iadd(start,tail);
    let below=b.ins().icmp(IntCC::UnsignedLessThan,bound,start);
    let above=b.ins().icmp(IntCC::UnsignedGreaterThan,bound,last);
    let at_end=b.ins().icmp(IntCC::UnsignedGreaterThanOrEqual,bound,last);
    let difference=b.ins().isub(bound,start);
    let before=b.ins().select(above,count,difference);
    let before=b.ins().select(below,zero,before);
    let successor=b.ins().iadd_imm(difference,1);
    let through=b.ins().select(at_end,count,successor);
    let through=b.ins().select(below,zero,through);
    let empty=b.ins().icmp_imm(IntCC::Equal,count,0);
    let before=b.ins().select(empty,zero,before);
    let through=b.ins().select(empty,zero,through);
    let rest_before=b.ins().isub(count,before);
    let rest_through=b.ins().isub(count,through);
    match op {
        U64Lt=>vec![(zero,before)], U64Le=>vec![(zero,through)],
        U64Gt=>vec![(through,rest_through)], U64Ge=>vec![(before,rest_before)],
        U64Eq=>vec![(before,b.ins().isub(through,before))],
        U64Ne=>vec![(zero,before),(through,rest_through)],
        _=>unreachable!("proved source axis comparison"),
    }
}
''')
p=base/'program/codegen/numeric_map_dots/batch.rs';s=p.read_text();begin=s.index('    let tail = b.ins().iadd_imm(count, -1);');end=s.index('    let op = if predicate.dot_when_true',begin);s=s[:begin]+s[end:];begin=s.index('    let rest_before = b.ins().isub(count, before);');end=s.index('\n}\nfn fill',begin);s=s[:begin]+'    Ok(super::windows::comparison(b, op, bound, start, count))'+s[end:];p.write_text(s)
p=base/'program/codegen/numeric_map_dots/cells.rs';p.write_text(r'''//! Typed independent cells over proved affine streams. Complete current map
//! admission is unchanged. A failed speculative window restarts the checked
//! DAG over immutable sources; only its private disjoint scratch was touched.
use super::*;
use crate::native_artifact::program::prepare::numeric_maps::dots::{CellPath,CellProgram,CellValue};
use crate::native_artifact::program::codegen::numeric_map::selection::Selection;
use crate::native_artifact::compiler::f64_arithmetic;
use mech_engine::native_artifact::NativeScalarOp;

fn evaluate(
    b:&mut FunctionBuilder<'_>, context:&Context<'_>, path:&CellPath,
    prepared:&[streams::Prepared], x:Value,y:Value, vector:bool,
) -> Result<Value,NativeCompileError> {
    let kind=if vector {types::F64.by(2).unwrap()} else {types::F64};
    let mut values=Vec::new();
    for node in &path.values {
        let value=match *node {
            CellValue::Constant(bits)=> {
                let value=b.ins().f64const(cranelift_codegen::ir::immediates::Ieee64::with_bits(bits));
                if vector {b.ins().splat(kind,value)} else {value}
            }
            CellValue::Capture(id)=> {
                let word=*context.captures.get(&id).ok_or_else(||backend("affine cell lost current F64 capture"))?;
                let value=b.ins().bitcast(types::F64,MemFlags::new(),word);
                if vector {b.ins().splat(kind,value)} else {value}
            }
            CellValue::Read(at)=>prepared[at].cell(b,x,y,vector),
            CellValue::Unary(NativeScalarOp::F64Neg,at)=>b.ins().fneg(values[at]),
            CellValue::Unary(NativeScalarOp::F64Sqrt,at)=>b.ins().sqrt(values[at]),
            CellValue::Binary(op,[a,c])=>f64_arithmetic(b,op,values[a],values[c]),
            _=>return Err(backend("affine cell lost source-selected F64 operation")),
        };
        // Preserve all intermediate rounding and defer nonfinite payload cases
        // to the original scalar DAG. No store precedes these checks.
        super::super::numeric_product_epilogues::finite(b,value,vector,context.slow);
        values.push(value);
    }
    Ok(values[path.result])
}
fn window(
    b:&mut FunctionBuilder<'_>, context:&Context<'_>, path:&CellPath,
    matrices:&[(Value,Value,Value,Value)], first:[Value;2],counts:[Value;2],
    source_start:[Value;2],source_columns:Value,rectangular:bool,output:Value,
)->Result<(),NativeCompileError> {
    let work=b.create_block();let done=b.create_block();
    let nx=b.ins().icmp_imm(IntCC::NotEqual,counts[0],0);
    let ny=b.ins().icmp_imm(IntCC::NotEqual,counts[1],0);
    let active=b.ins().band(nx,ny);
    b.ins().brif(active,work,&[],done,&[]);b.switch_to_block(work);
    let mut prepared=Vec::new();
    for operand in &path.reads {
        let (p,n,r,c)=matrices[operand.matrix];
        prepared.push(streams::prepare(b,context,operand,[p,n,r,c],first[0],counts[0],rectangular.then_some((first[1],counts[1])))?);
    }
    let mut packed=b.ins().iconst(types::I8,1);
    for stream in &prepared {let contiguous=stream.packed_inner(b);packed=b.ins().band(packed,contiguous);}
    let column=b.ins().isub(first[0],source_start[0]);
    let row=b.ins().isub(first[1],source_start[1]);
    let row_base=b.ins().imul(row,source_columns);
    let index=b.ins().iadd(row_base,column);
    let bytes=b.ins().imul_imm(index,8);let base=b.ins().iadd(output,bytes);
    let x=b.declare_var(types::I64);let y=b.declare_var(types::I64);
    let zero=b.ins().iconst(types::I64,0);b.def_var(y,zero);
    let rows=b.create_block();let row_body=b.create_block();let head=b.create_block();
    let body=b.create_block();let pair=b.create_block();let single=b.create_block();let row_done=b.create_block();
    b.ins().jump(rows,&[]);b.switch_to_block(rows);
    let at_y=b.use_var(y);let more=b.ins().icmp(IntCC::UnsignedLessThan,at_y,counts[1]);
    b.ins().brif(more,row_body,&[],done,&[]);b.switch_to_block(row_body);
    b.def_var(x,zero);b.ins().jump(head,&[]);b.switch_to_block(head);
    let at_x=b.use_var(x);let more=b.ins().icmp(IntCC::UnsignedLessThan,at_x,counts[0]);
    b.ins().brif(more,body,&[],row_done,&[]);b.switch_to_block(body);
    let remaining=b.ins().isub(counts[0],at_x);
    let two=b.ins().icmp_imm(IntCC::UnsignedGreaterThanOrEqual,remaining,2);
    let two=b.ins().band(two,packed);b.ins().brif(two,pair,&[],single,&[]);
    for (block,vector,step) in [(pair,true,2),(single,false,1)] {
        b.switch_to_block(block);
        let result=evaluate(b,context,path,&prepared,at_x,at_y,vector)?;
        let row=b.ins().imul(at_y,source_columns);let at=b.ins().iadd(row,at_x);
        let bytes=b.ins().imul_imm(at,8);let address=b.ins().iadd(base,bytes);
        b.ins().store(MemFlags::new(),result,address,0);
        let next=b.ins().iadd_imm(at_x,step);b.def_var(x,next);b.ins().jump(head,&[]);
    }
    b.switch_to_block(row_done);let next=b.ins().iadd_imm(at_y,1);b.def_var(y,next);b.ins().jump(rows,&[]);
    b.switch_to_block(done);Ok(())
}
/// Returns in the original DAG's entry block. No runtime recipe is serialized.
pub(in crate::native_artifact::program::codegen) fn emit(
    b:&mut FunctionBuilder<'_>,frame:Value,region:&Region,plan:&Plan,captures:&BTreeMap<u32,Value>,
    matrices:&[(Value,Value,Value,Value)],start:Value,count:Value,source_count:Value,
    inner_start:Value,inner_count:Value,output:Value,selection:Option<&Selection>,
    whole_initialized:Option<Value>,complete:Block,
)->Result<(),NativeCompileError> {
    let Some(recipe)=CellProgram::derive(plan,region) else {return Ok(());};
    let slow=b.create_block();let arithmetic=b.create_block();b.append_block_param(arithmetic,types::I64);
    let context=Context {plan,captures,slow,arithmetic};
    // A speculative later decline can replay only when writes cannot change a
    // source. Keep the full-span proof even for currently empty selected arms.
    let output_bytes=b.ins().imul_imm(count,8);let output_end=b.ins().iadd(output,output_bytes);
    for (at,&(pointer,cells,_,_)) in matrices.iter().enumerate() {
        let bytes=b.ins().imul_imm(cells,i64::from(region.matrices[at].width));
        let end=b.ins().iadd(pointer,bytes);
        let before=b.ins().icmp(IntCC::UnsignedLessThanOrEqual,output_end,pointer);
        let after=b.ins().icmp(IntCC::UnsignedLessThanOrEqual,end,output);
        let disjoint=b.ins().bor(before,after);let empty=b.ins().icmp_imm(IntCC::Equal,cells,0);
        let good=b.ins().bor(empty,disjoint);require(b,good,slow);
    }
    let zero=b.ins().iconst(types::I64,0);let one=b.ins().iconst(types::I64,1);
    let rectangular=region.rectangle.is_some();
    let source_start=[start,if rectangular {inner_start} else {zero}];
    let boxes=selection.map_or_else(||vec![([zero,zero],[source_count,if rectangular {inner_count} else {one}])],|s|s.windows(b));
    for path in &recipe.paths {
        for &(offset,counts) in &boxes {
            let first=[b.ins().iadd(start,offset[0]),if rectangular {b.ins().iadd(inner_start,offset[1])} else {zero}];
            let mut windows=vec![(first,counts)];
            for predicate in &path.predicates {
                let bound=context.word(b,predicate.bound)?;
                let axis=predicate.axis as usize;let mut clipped=Vec::new();
                for (first,counts) in windows {
                    for (offset,n) in super::windows::comparison(b,predicate.op,bound,first[axis],counts[axis]) {
                        let mut new_first=first;let mut new_counts=counts;
                        new_first[axis]=b.ins().iadd(first[axis],offset);new_counts[axis]=n;
                        clipped.push((new_first,new_counts));
                    }
                }
                windows=clipped;
            }
            for (first,counts) in windows {window(b,&context,path,matrices,first,counts,source_start,source_count,rectangular,output)?;}
        }
    }
    // Same complete-prefix certificate as the checked selected map. Holes in
    // selected-only scratch never become initialized merely through fast code.
    let initialized=whole_initialized.map(|whole|b.ins().select(whole,count,zero)).unwrap_or(count);
    b.ins().store(MemFlags::new(),initialized,frame,offset_of!(Frame,next) as i32);
    b.ins().jump(complete,&[]);b.switch_to_block(arithmetic);b.ins().jump(slow,&[]);b.switch_to_block(slow);Ok(())
}
''')
# Independent emission ablation propagated through the shared standalone/phase map paths.
p=base/'codegen/options.rs';s=p.read_text().replace('    OrderedMapDots,','    OrderedMapDots,\n    /// Closed piecewise F64 cells over corner-proved immutable affine streams.\n    AffineMapCells,');p.write_text(s)
for name in ['program/codegen/numeric_map.rs','program/codegen/numeric_phase_maps.rs','program/codegen/numeric_phase_reductions.rs']:
 p=base/name;s=p.read_text().replace('    ordered_dots: bool,','    ordered_dots: bool,\n    affine_cells: bool,')
 s=s.replace('        ordered_dots,','        ordered_dots,\n        affine_cells,').replace('                ordered_dots,','                ordered_dots,\n                affine_cells,')
 # The second replacement above can match a suffix of the first indentation;
 # normalize accidental duplicate argument insertion explicitly.
 s=s.replace('                affine_cells,\n        affine_cells,','                affine_cells,')
 p.write_text(s)
p=base/'program/codegen/numeric_map.rs';s=p.read_text();needle='    // Source phi copies share a native SSA variable.';pos=s.index(needle);s=s[:pos]+'''    if affine_cells {
        super::numeric_map_dots::cells::emit(
            b, frame, region, plan, captures, &matrices, start, count,
            source_count, inner_start, inner_count, output, selection,
            whole_output_initialized, complete,
        )?;
    }
'''+s[pos:];p.write_text(s)
p=base/'codegen/control/mod.rs';s=p.read_text();needle='''                        crate::native_artifact::codegen::options::OptimizationPass::OrderedMapDots,
                    ),''';assert s.count(needle)==1;s=s.replace(needle,needle+'''
                    controls.enabled(
                        crate::native_artifact::codegen::options::OptimizationPass::AffineMapCells,
                    ),''');p.write_text(s)
p=base/'program/codegen/readonly_numeric.rs';s=p.read_text();needle='                    controls.enabled(OptimizationPass::OrderedMapDots),';assert s.count(needle)==2;s=s.replace(needle,needle+'\n                    controls.enabled(OptimizationPass::AffineMapCells),');p.write_text(s)
p=base/'program/image/identity.rs';s=p.read_text();assert 'NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 427;' in s;s=s.replace('NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 427;','NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 428;');p.write_text(s)
