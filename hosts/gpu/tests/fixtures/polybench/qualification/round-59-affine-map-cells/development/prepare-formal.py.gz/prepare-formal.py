from pathlib import Path
f=Path(__file__).resolve().parent;old=f.parents[1]/'round-65/transpose-epilogue-views'
s=(old/'preserve-training.py').read_text().replace('round-58','round-59').replace('round-56','round-58').replace('accepted56','accepted58').replace('transpose-epilogue-views','affine-map-cells').replace("q['focused_checks']['passed_tests']==[11]","q['focused_checks']['passed_tests']==[7]").replace('len(paths)==12','len(paths)==19').replace("['entries'])==58","['entries'])==59").replace("['accepted_history_index']==56","['accepted_history_index']==58").replace("'focused_selected_checks':11","'focused_selected_checks':7")
s=s.replace("assert all(c['other_counters_match'] and c['work_not_reduced'] and c['visit_changes_proved'] for c in r['cases'].values())","assert all(c['all_counters_match'] for c in r['cases'].values())")
(f/'preserve-training.py').write_text(s)
s=(old/'measure-candidate.py').read_text().replace('round-58','round-59').replace('transpose-epilogue-views','affine-map-cells').replace("['entries'])==58","['entries'])==59").replace("['accepted_history_index']==56","['accepted_history_index']==58")
(f/'measure-candidate.py').write_text(s);(f/'run-formal.py').write_text((old/'run-formal.py').read_text())
s=(old/'audit-results.py').read_text().replace('round-58','round-59').replace('round-56','round-58').replace('accepted56','accepted58').replace("['entries'])==59","['entries'])==60").replace("['history_entries':59]","['history_entries':60]").replace("'history_entries':59","'history_entries':60").replace("['compared_to_accepted_index']==56","['compared_to_accepted_index']==58").replace('8.175763531282765','8.144951071643966').replace("q['focused_selected_checks']==11","q['focused_selected_checks']==7")
a=s.index("'interpretation':");z=s.index('})\nprint',a)
s=s[:a]+"'interpretation':'Promote solely optimization15 kernel Mech/C<8.144951071643966, the accepted58 score. Holdout independently reported, never selection/tuning/veto/retry. All observations retained. Source-closed typed piecewise affine map kernels retain the original checked DAG, current immutable source loans, exact original counters/fees, scratch completion certificate and atomic publication.'"+s[z:]
(f/'audit-results.py').write_text(s)
print('Prepared selected-probe preservation and one frozen formal run/audit, conditional on selection.')
