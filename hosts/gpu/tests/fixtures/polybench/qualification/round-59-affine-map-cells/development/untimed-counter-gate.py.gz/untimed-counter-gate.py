"""Exact optimization source counters and finite C outputs; no samples."""
import importlib.util,json,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(s);s.loader.exec_module(b)
plan=b.read(folder/'plan.json');q=b.read(folder/'qualification.json');fp=b.compiler_fingerprint();assert q['complete']and fp==q['compiler_fingerprint'];protocol,cases=b.protocol();reference=b.read(b.FIXTURE/'round-58-training-probe.json');emission=b.read(folder/'emission-census.json');assert emission['passed']and emission['typed_cells_emitted']
actors={'accepted58':Path(plan['accepted_driver']),'candidate':Path(q['driver'])};assert b.digest(actors['accepted58'])==plan['accepted_driver_sha256']==b.read(b.FIXTURE/'round-58-frozen.json')['driver_sha256'];assert b.digest(actors['candidate'])==q['driver_sha256'];assert len(b.read(b.FIXTURE/'performance-history.json')['entries'])==59
output=folder/'untimed-counter-gate.json';assert not output.exists()
def counters(report):
 prefix='NativeProgramExecutionReport { ';assert report.startswith(prefix)and report.endswith(' }');return {k:int(v)for k,v in [s.split(': ')for s in report[len(prefix):-2].split(', ')]}
r={'schema':'mech.polybench.untimed-counter-gate.v3','created_at':b.utc(),'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'scope':'Optimization15 exact counters and finite C values. No source visit or bill reduction; no holdout diagnosis or performance observations.','plan_sha256':b.digest(b.FIXTURE/'training-experiments/affine-map-cells-plan.json'),'cases':{},'complete':False,'performance_observations':0};b.write(output,r)
for index,name in enumerate(protocol['optimization']):
 config=folder/f'{name}-inputs.json';b.write(config,cases[name]['inputs']);row={'source_sha256':b.digest(b.FIXTURE/f'{name}.mec'),'inputs_sha256':b.digest(config),'actors':{}};r['cases'][name]=row
 for actor in (list(actors)if index%2==0 else list(reversed(actors))):
  argv=[str(actors[actor]),str(b.FIXTURE/f'{name}.mec'),str(config),'0'];stdout=folder/f'{name}-{actor}-untimed.stdout';stderr=folder/f'{name}-{actor}-untimed.stderr'
  with stdout.open('x')as out,stderr.open('x')as err:
   child=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err);r['pending']={'case':name,'actor':actor,'pid':child.pid,'command':argv};b.write(output,r)
   while True:
    try:code=child.wait(timeout=30);break
    except subprocess.TimeoutExpired:print('Waiting on same untimed gate process',child.pid,flush=True)
  row['actors'][actor]={'command':argv,'pid':child.pid,'exit_code':code,'stdout_sha256':b.digest(stdout),'stderr_sha256':b.digest(stderr)};r.pop('pending');b.write(output,r);assert code==0
  result=json.loads(stdout.read_text().strip().splitlines()[-1]);assert result['status']=='ok'and result['samples_seconds']==[]
  row['actors'][actor].update(counters=counters(result['report']),execution_report=result['report'],validation=b.validate(result['values'],cases[name]['expected']),timing_samples=0)
  if actor=='accepted58':assert result['report']==reference['cases'][name]['actors']['candidate']['execution_report']
 a=row['actors']['accepted58']['counters'];c=row['actors']['candidate']['counters'];assert set(a)==set(c);row['deltas']={k:c[k]-v for k,v in a.items()}
 row['all_counters_match']=all(v==0 for v in row['deltas'].values());row['work_not_reduced']=c['work']>=a['work']and c['comparison_work']>=a['comparison_work'];row['other_counters_match']=all(v==0 for k,v in row['deltas'].items()if k not in ['work','comparison_work','visits']);row['visit_proof']={'proved':row['deltas']['visits']==0,'kind':'unchanged','expected_delta':0,'actual_delta':row['deltas']['visits']}
 row['passed']=row['all_counters_match'];b.write(output,r);print(name,'exact counters',row['passed'],flush=True);assert row['passed'],row['deltas']
r.update(complete=True,completed_at=b.utc(),passed=len(r['cases'])==15 and all(row['passed']for row in r['cases'].values()),finite_liveouts=sum(row['actors']['candidate']['validation']['count']for row in r['cases'].values()),source_and_driver_unchanged=b.compiler_fingerprint()==fp and b.digest(actors['candidate'])==q['driver_sha256']);assert r['source_and_driver_unchanged'];b.write(output,r);assert r['passed'];print(json.dumps({k:r[k]for k in ['complete','passed','finite_liveouts','performance_observations']}),flush=True)
