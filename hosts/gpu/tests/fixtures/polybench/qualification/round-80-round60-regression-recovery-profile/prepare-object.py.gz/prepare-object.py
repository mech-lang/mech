"""Export exact frozen qualified source as a genuine Object, without executing it."""
import importlib.util,json,subprocess
from pathlib import Path
root=Path.cwd();f=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(s);s.loader.exec_module(b)
plan=b.read(f/'plan.json');fp=b.compiler_fingerprint();assert fp==plan['compiler_fingerprint']and b.digest(plan['profiled_driver'])==plan['profiled_driver_sha256']
assert all(b.digest(root/name)==digest for name,digest in plan['source_sha256'].items());head=b.command(['git','rev-parse','HEAD']);assert b.command(['git','ls-remote','origin','refs/heads/codex/polybench-native-matrices']).split()[0]==head
assert b.command(['git','status','--porcelain'])==''
protocol,cases=b.protocol();assert len(plan['cases'])==7 and set(plan['cases'])<=set(protocol['optimization'])
census=b.read(plan['object_census']);assert plan['census_actor']=='candidate' and b.read(b.FIXTURE/'round-60-frozen.json')['compiler_fingerprint']==fp
for name in plan['cases']:
 config=f/f'{name}-inputs.json';b.write(config,cases[name]['inputs']);obj=f/f'{name}-residence.o';assert not obj.exists()
 argv=[plan['profiled_driver'],str(b.FIXTURE/f'{name}.mec'),str(config),'0',f'emit-object={obj}']
 with(f/f'{name}-object.stdout').open('x')as out,(f/f'{name}-object.stderr').open('x')as err:r=subprocess.run(argv,cwd=root,stdout=out,stderr=err)
 b.write(f/f'{name}-object-export.json',{'command':argv,'exit_code':r.returncode,'compiler_fingerprint':fp,'object_executed':False,'performance_observations':0});assert r.returncode==0
 status=json.loads((f/f'{name}-object.stdout').read_text().strip().splitlines()[-1]);assert status['status']=='ok'and status['mode']=='emit-object'
 expected=census['cases'][name]['actors']['candidate'];md=b.read(obj.with_suffix('.metadata.json'));assert md['code_bytes']==expected['code_bytes']and md['stack_bytes']==expected['reported_native_stack_bytes']
 assert b.digest(obj)==expected['object_sha256'], 'Frozen genuine Object export differs.'
 asm=subprocess.check_output(['/Library/Developer/CommandLineTools/usr/bin/llvm-objdump','--disassemble','--no-show-raw-insn',str(obj)],text=True);obj.with_suffix('.disasm.txt').write_text(asm)
 # objdump's file heading contains this diagnostic path; exact Object bytes
 # above establish provenance, and same-PID binding below checks all code.
 print(name,'exact frozen Object',md['code_bytes'],'code bytes; object was not executed',flush=True)
assert b.compiler_fingerprint()==fp
