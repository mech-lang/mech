from pathlib import Path
import importlib.util,json,shutil,subprocess
root=Path.cwd();p=root/'hosts/gpu/tests/fixtures/polybench';f=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.write(f/'preparation-attempt-01.json',{'exit_code':1,'error':"KeyError: 'driver': frozen candidate receipt has a driver digest but no path; use already qualified driver path and verify its exact frozen digest.",'source_changed':False,'performance_observations':0})
q=b.read('/private/tmp/mech-polybench-optimization/round-71/source-closed-cell-prefix/qualification.json');frozen=b.read(p/'round-60-frozen.json');assert q['compiler_fingerprint']==frozen['compiler_fingerprint']
assert b.command(['git','status','--porcelain'])==''
old=b.read(p/'round-59-optimization.json');new=b.read(p/'round-60-optimization.json');tele=b.read(p/'round-60-static-telemetry.json');rows=[]
for name,v in new['runs'].items():
 a=old['runs'][name]['comparisons']['kernel'];c=v['comparisons']['kernel'];t=tele['cases'][name]
 rows.append({'case':name,'raw_mech_runtime_multiplier':c['mech']['median_seconds']/a['mech']['median_seconds'],'accepted59_mech_us':a['mech']['median_seconds']*1e6,'round60_mech_us':c['mech']['median_seconds']*1e6,'accepted59_over_c':a['median_mech_over_c'],'round60_over_c':c['median_mech_over_c'],'native_functions_changed':not t['functions_match']})
rows.sort(key=lambda r:-r['raw_mech_runtime_multiplier'])
cases=[r['case']for r in rows if r['raw_mech_runtime_multiplier']>1.05 or r['native_functions_changed']and r['raw_mech_runtime_multiplier']>1]
assert cases==['3mm','mvt','durbin','atax','bicg','nussinov','cholesky']
base=Path('/private/tmp/mech-polybench-optimization/round-76/accepted-seidel-credit-profile')
for name in ['build-host.py','profile_owned.py','run-profile.py','collect.py','prepare-object.py','bind-call-relocations.py','verify-and-annotate.py','residence.rs']:
 shutil.copy2(base/name,f/name)
plan={'schema':'mech.polybench.optimization-regression-profile-plan.v1','created_at':b.utc(),'user_direction':'Take round60 Seidel1.66x implementation and fix other optimization cases that regressed; preserve its win.','accepted_round':59,'source_parent':b.command(['git','rev-parse','HEAD']),'foundation_source_commit':frozen['source_commit'],'compiler_fingerprint':frozen['compiler_fingerprint'],'source_sha256':q['source_sha256'],'cases':cases,'selection':'Optimization-only: all five raw runtime regressions above5percent plus both other programs whose native functions changed and regressed. No holdout diagnosis.','regression_rows':rows,'method':'Reconstitute exact previously qualified round60 source, freeze and push it as an unpromoted diagnostic foundation, use unchanged public-API warm residence host with Cranelift sole source generator, sample each owned process3seconds at1ms, capture only named executable JIT ranges after sampling in that same PID, resume to actual terminal0, validate finite C liveouts and exact frozen counters, bind instructions to exact genuine round60 Objects. No timing score or new sample of an observed fingerprint.','seconds_per_process':30,'sample_seconds':3,'object_census':str(p/'round-60-static-telemetry.json'),'census_actor':'candidate','counter_gate':'/private/tmp/mech-polybench-optimization/round-71/source-closed-cell-prefix/untimed-counter-gate.json','profiled_driver':q['driver'],'profiled_driver_sha256':frozen['driver_sha256'],'host_source_sha256':b.digest(f/'residence.rs'),'official_performance_observations':0,'holdout_profiling':False,'history_entries_unchanged':61,'hypothesis_to_check':'Bind actual time in generated kernels, checks, schema/planning, allocations and ownership on regressed O programs. Nussinov/Cholesky received short2-read point prefixes; Nussinov grew1428B and16B stack, with two escaping raw loads in each prefix. Establish whether those prefixes remove meaningful work and inspect matrix/reduction preparation on unchanged-code regressors. Select material general compiler changes from source and profiles only, preserving Seidel lowering and all accounting/numerics.','scope_limit':'Warm residence includes output drop/reset and differs from official cache-flushed samples. Samples are dependency-chain locations, not exclusive instruction cost, hardware traffic/IPC/RSS or speedup forecasts. All logs/failures preserved; no Rust edits during any owned build/test/profile/timing. Accepted ledger remains59 until a new qualified fingerprint passes existing optimization-only probe and formal gates.'}
assert Path(plan['profiled_driver']).exists() and b.digest(plan['profiled_driver'])==plan['profiled_driver_sha256']
b.write(f/'plan.json',plan);b.write(p/'training-experiments/round60-regression-recovery-profile-plan.json',plan)
for name in ['prepare-object.py','collect.py']:
 t=(f/name).read_text().replace("plan['census_actor']=='accepted59'", "plan['census_actor']=='candidate'").replace("b.FIXTURE/'round-59-frozen.json'", "b.FIXTURE/'round-60-frozen.json'").replace("['actors']['accepted59']", "['actors']['candidate']").replace("len(plan['cases'])==1", "len(plan['cases'])==7")
 (f/name).write_text(t)
for name,digest in q['source_sha256'].items():
 source=Path('/private/tmp/mech-polybench-optimization/round-71/source-closed-cell-prefix/qualified-source')/name
 assert b.digest(source)==digest
 if (root/name).exists():
  out=f/'source-before'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((root/name).read_bytes())
 (root/name).parent.mkdir(parents=True,exist_ok=True);(root/name).write_bytes(source.read_bytes())
assert b.compiler_fingerprint()==plan['compiler_fingerprint']
subprocess.run(['git','diff','--check'],check=True);subprocess.run(['git','add','--',*q['source_sha256'],str(p/'training-experiments/round60-regression-recovery-profile-plan.json')],check=True);subprocess.run(['git','-c','gc.auto=0','commit','-q','-m','Recover round60 Seidel implementation for optimization regression diagnosis'],check=True)
assert b.command(['git','status','--porcelain'])==''
print(json.dumps({'head':b.command(['git','rev-parse','HEAD']),'compiler_fingerprint':b.compiler_fingerprint(),'cases':cases,'accepted_round_unchanged':59,'performance_observations':0}),flush=True)
