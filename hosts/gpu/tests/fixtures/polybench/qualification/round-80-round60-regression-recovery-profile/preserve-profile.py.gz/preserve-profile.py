from pathlib import Path
import importlib.util,json,gzip,hashlib,subprocess
root=Path.cwd();f=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
plan=b.read(f/'plan.json');profile=b.read(f/'profile-result.json');binding=b.read(f/'instruction-binding.json');verify=b.read(f/'jit-object-verification.json');fp=b.compiler_fingerprint();p=b.FIXTURE
assert profile['complete']and binding['complete']and verify['complete']and profile['source_and_history_unchanged']and verify['source_unchanged']
assert fp==plan['compiler_fingerprint']==profile['compiler_fingerprint']==verify['compiler_fingerprint']
assert set(profile['processes']['cases'])==set(plan['cases'])and len(plan['cases'])==7
assert all(v['complete']and v['driver_exit_code']==0 and v['sample_exit_code']==0 and v['frozen_execution_counters_match']for v in profile['processes']['cases'].values())
assert all(b.digest(root/name)==digest for name,digest in plan['source_sha256'].items())
assert len(b.read(p/'performance-history.json')['entries'])==61 and b.read(p/'performance-acceptance.json')['accepted_history_index']==59
assert b.command(['git','status','--porcelain'])==''
source=f/'source-snapshot';source.mkdir(exist_ok=False)
for name in plan['source_sha256']:
 out=source/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((root/name).read_bytes())
summary={case:{k:profile['analysis'][case+'.sample.txt'].get(k)for k in ['execution_samples','self_time_mechanisms','top_self_functions','top_jit_sites']}for case in plan['cases']}
b.write(f/'profile-summary.json',summary)
dest=p/'qualification/round-80-round60-regression-recovery-profile';dest.mkdir(parents=True,exist_ok=False);archives={}
for source in sorted(f.rglob('*')):
 if not source.is_file()or '__pycache__'in source.parts or source.name=='residence-driver':continue
 raw=source.read_bytes();name=str(source.relative_to(f));out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives[name]={'path':str(out.relative_to(p)),'sha256':hashlib.sha256(raw).hexdigest(),'compressed_sha256':b.digest(out)}
receipt={'schema':'mech.polybench.optimization-regression-profile-evidence.v1','created_at':b.utc(),'compiler_fingerprint':fp,'plan':plan,'driver_build':b.read(f/'residence-build.json'),'profile':profile,'instruction_binding':binding,'jit_object_verification':verify,'summary':summary,'source_unchanged':True,'official_performance_observations':0,'holdout_observations':0,'accepted_round_unchanged':59,'history_entries_unchanged':61,'archives':archives,'interpretation':'Exact round60 source is an unpromoted foundation recovered at user direction. All sampled code is bound to its original genuine Object and all finite outputs/counters match. Regression measurements include unchanged-code programs; no noise explanation or source causality is asserted for those observations. This evidence selects subsequent material compiler work using optimization cases only. Preserve Seidel lowering and existing strict optimization-only qualification/probe/formal gates.'}
b.write(p/'training-experiments/round60-regression-recovery-profile.json',receipt)
subprocess.run(['git','diff','--check'],check=True);subprocess.run(['git','add','--',str(p.relative_to(root))],check=True);subprocess.run(['git','-c','gc.auto=0','commit','-q','-m','Profile round60 optimization regressions with exact generated code'],check=True)
assert b.command(['git','status','--porcelain'])==''and b.compiler_fingerprint()==fp
print(json.dumps({'head':b.command(['git','rev-parse','HEAD']),'compiler_fingerprint':fp,'archives':len(archives),'cases':plan['cases'],'performance_observations':0}),flush=True)
