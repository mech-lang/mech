//! Predicate outcomes held only across this exact successful source transition.
//! Descriptive Bool/CFG inventories alone never grant cross-iteration truth.
use super::*;
use mech_engine::native_artifact::{
    NativeBufferFrameOperation as Frame, NativeBufferFrames, NativeMatchValue,
    NativeStructuralObservation as Observe, NativeStructuralStep as Path,
};

#[derive(Default)]
pub(super) struct Stability {
    pub predicates: BTreeMap<usize, bool>,
    pub observations: BTreeMap<usize, (u32, bool)>,
    pub successors: BTreeMap<usize, u32>,
}
struct Transfer<'a, 'p> {
    facts: &'a NativeProgramFacts<'p>,
    frames: &'a NativeBufferFrames,
    proof: &'a Proof,
    tail: &'a NativeTailLoop,
    pre: &'a BTreeSet<usize>,
    definitions: BTreeMap<u32, usize>,
}
impl Transfer<'_, '_> {
    fn reaches(&self, start: u32, target: usize, avoid: Option<usize>) -> bool {
        let mut pending = vec![start];
        let mut seen = BTreeSet::new();
        while let Some(at) = pending.pop() {
            let site = at as usize;
            if avoid == Some(site) {
                continue;
            }
            if site == target {
                return true;
            }
            if at == self.tail.latch()
                || at == self.tail.exit()
                || !self.pre.contains(&site)
                || !seen.insert(at)
            {
                continue;
            }
            if let Ok(next) = self.facts.successors(at) {
                pending.extend(next.into_iter().flatten());
            }
        }
        false
    }
    fn available(&self, definition: usize, consumer: usize) -> bool {
        definition != consumer && !self.reaches(self.tail.header(), consumer, Some(definition))
    }
    // Actual same-plan projection steps, with current-visit availability at
    // every link. A unique definition alone does not establish that it ran.
    fn projection(&self, value: u32, consumer: usize, depth: usize) -> Option<Vec<Path>> {
        if depth > 32 {
            return None;
        }
        if value == self.tail.carrier().get() {
            return Some(Vec::new());
        }
        let [definition] = self.facts.definition_sites(value).ok()? else {
            return None;
        };
        let site = definition.site()? as usize;
        if !self.pre.contains(&site) || !self.available(site, consumer) {
            return None;
        }
        match self.facts.plan().blocks()[site].action() {
            Action::Scalar(Scalar::Copy { source, .. }) => {
                self.projection(source.get(), site, depth + 1)
            }
            Action::Structural {
                source,
                path,
                observation: Observe::U64 | Observe::CanonicalValue,
                ..
            } => {
                let mut parent = self.projection(source.get(), site, depth + 1)?;
                parent.extend_from_slice(path);
                Some(parent)
            }
            _ => None,
        }
    }
    fn stable(&self, value: u32, consumer: usize, depth: usize) -> bool {
        if depth > 48
            || value == self.tail.carrier().get()
            || value == self.tail.next().get()
            || self
                .facts
                .plan()
                .values()
                .get(value as usize)
                .and_then(|v| v.scalar_kind())
                != Some(Kind::U64)
        {
            return false;
        }
        if self
            .facts
            .plan()
            .constants()
            .iter()
            .any(|c| c.value().get() == value)
        {
            return true;
        }
        let Ok([definition]) = self.facts.definition_sites(value) else {
            return false;
        };
        let Some(site) = definition.site().map(|s| s as usize) else {
            return self
                .facts
                .plan()
                .inputs()
                .iter()
                .any(|v| v.value().get() == value);
        };
        // One immutable scalar capture is fixed for the suspended loan. The
        // selected numeric proof already validates/imports these source homes.
        if !self.proof.sites.contains(&site) {
            return true;
        }
        if !self.pre.contains(&site) || !self.available(site, consumer) {
            return false;
        }
        if let Some(path) = self.projection(value, consumer, 0) {
            return !path.is_empty()
                && super::super::rolling::resolve(
                    self.facts,
                    self.frames,
                    &self.definitions,
                    self.tail.next().get(),
                    &path,
                    0,
                ) == Some(value);
        }
        match self.facts.plan().blocks()[site].action() {
            Action::Scalar(Scalar::Copy { source, .. }) => {
                self.stable(source.get(), site, depth + 1)
            }
            Action::Scalar(Scalar::Primitive {
                op: Op::U64Add | Op::U64Sub | Op::U64Mul,
                operands,
                ..
            }) => operands
                .iter()
                .all(|v| self.stable(v.get(), site, depth + 1)),
            _ => false,
        }
    }
    fn enum_value(&self, site: usize) -> Option<(NativeMatchValue, bool)> {
        let Action::Structural {
            source,
            path,
            observation: Observe::EnumOrdinal { ordinal },
            output,
        } = self.facts.plan().blocks()[site].action()
        else {
            return None;
        };
        if !path.is_empty()
            || self.facts.plan().values()[output.get() as usize].scalar_kind() != Some(Kind::Bool)
        {
            return None;
        }
        let path = self.projection(source.get(), site, 0)?;
        let next = super::super::rolling::resolve(
            self.facts,
            self.frames,
            &self.definitions,
            self.tail.next().get(),
            &path,
            0,
        )?;
        let current_type = &self.facts.plan().values()[source.get() as usize];
        let next_type = &self.facts.plan().values()[next as usize];
        if current_type.schema() != next_type.schema()
            || !matches!(
                current_type.definition().body(),
                mech_core::SchemaBody::Enum { .. }
            )
        {
            return None;
        }
        let definition = *self.definitions.get(&next)?;
        let Frame::EnumPack {
            ordinal: packed, ..
        } = self.frames.action(definition)?.operation()
        else {
            return None;
        };
        Some((*output, packed == ordinal))
    }
}

pub(super) fn derive(
    facts: &NativeProgramFacts<'_>,
    frames: &NativeBufferFrames,
    proof: &Proof,
    tail: &NativeTailLoop,
    context: &Context,
) -> Stability {
    let mut definitions = BTreeMap::new();
    let mut post = BTreeSet::new();
    let mut at = context.write;
    loop {
        if !post.insert(at) || post.len() > 33 {
            return Stability::default();
        }
        if let Some(value) = super::super::rolling::output(facts.plan().blocks()[at].action()) {
            definitions.insert(value.get(), at);
        }
        if at == context.continuation {
            break;
        }
        let Some(next) = super::super::successor(facts, at) else {
            return Stability::default();
        };
        at = next as usize;
    }
    let pre = context
        .sites
        .iter()
        .copied()
        .filter(|site| !post.contains(site) && *site != tail.latch() as usize)
        .collect::<BTreeSet<_>>();
    let transfer = Transfer {
        facts,
        frames,
        proof,
        tail,
        pre: &pre,
        definitions,
    };
    let mut result = Stability::default();
    let mut known = BTreeMap::<u32, (NativeMatchValue, bool, usize)>::new();
    for &site in &pre {
        if let Some((value, truth)) = transfer.enum_value(site) {
            result.observations.insert(site, (value.get(), truth));
            known.insert(value.get(), (value, truth, site));
        }
        let Action::Scalar(Scalar::Primitive {
            op,
            operands,
            output,
        }) = facts.plan().blocks()[site].action()
        else {
            continue;
        };
        if !matches!(
            op,
            Op::U64Eq | Op::U64Ne | Op::U64Lt | Op::U64Le | Op::U64Gt | Op::U64Ge
        ) || !operands.iter().all(|v| transfer.stable(v.get(), site, 0))
            || transfer.reaches(tail.header(), context.first, Some(site))
        {
            continue;
        }
        let mut outcome = None;
        let mut conflict = false;
        for &branch in &pre {
            if !transfer.available(site, branch)
                || transfer.reaches(tail.header(), context.first, Some(branch))
            {
                continue;
            }
            let Some((no, yes)) = facts.boolean_branch_edges(branch as u32, *output) else {
                continue;
            };
            let false_path = transfer.reaches(no, context.first, None);
            let true_path = transfer.reaches(yes, context.first, None);
            if false_path == true_path {
                continue;
            }
            let truth = true_path;
            if outcome.is_some_and(|previous| previous != truth) {
                conflict = true;
                break;
            }
            outcome = Some(truth);
        }
        if let Some(truth) = outcome.filter(|_| !conflict) {
            result.predicates.insert(site, truth);
            known.insert(output.get(), (*output, truth, site));
        }
    }
    for &site in &pre {
        for &(value, truth, definition) in known.values() {
            if definition != site && !transfer.available(definition, site) {
                continue;
            }
            if let Some((no, yes)) = facts.boolean_branch_edges(site as u32, value) {
                result.successors.insert(site, if truth { yes } else { no });
            }
        }
    }
    result
}
