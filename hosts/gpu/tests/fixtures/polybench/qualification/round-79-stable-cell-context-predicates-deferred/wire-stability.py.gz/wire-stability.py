from pathlib import Path
root=Path.cwd(); base=root/'hosts/gpu/src/native_artifact/program/codegen'
p=base/'numeric_cell_stability.rs';s=p.read_text().replace('super::rolling::','super::super::rolling::')
s=s.replace('BTreeMap::<u32,(NativeMatchValue,bool)>::new()', 'BTreeMap::<u32,(NativeMatchValue,bool,usize)>::new()')
s=s.replace('known.insert(value.get(),(value,truth));', 'known.insert(value.get(),(value,truth,site));')
s=s.replace('known.insert(output.get(),(*output,truth));', 'known.insert(output.get(),(*output,truth,site));')
s=s.replace('for &(value,truth)in known.values() {\n            if let Some', 'for &(value,truth,definition)in known.values() {\n            if definition!=site&&!transfer.available(definition,site){continue}\n            if let Some')
p.write_text(s)
p=base/'numeric_cell_context.rs';s=p.read_text().replace('use super::*;','use super::*;\n#[path = "numeric_cell_stability.rs"]\nmod stability;',1)
s=s.replace('    pub slow: Block,\n','    pub slow: Block,\n    stability: stability::Stability,\n',1)
s=s.replace('            slow,\n','            slow,\n            stability: stability::Stability::default(),\n',1)
needle='    pub fn block(&self, mode: Mode, site: usize) -> Option<Block> {'
new='''    /// Refine only the reusable source graph. Every entry already follows the
    /// exact successful point/store/continuation; fresh and cold graphs remain.
    pub fn refine(
        &mut self,
        facts: &NativeProgramFacts<'_>,
        frames: &mech_engine::native_artifact::NativeBufferFrames,
        proof: &Proof,
        tail: &NativeTailLoop,
    ) {
        let mut stability = stability::derive(facts, frames, proof, tail, self);
        let original = self.sites.iter().copied().collect::<BTreeSet<_>>();
        let mut alive = BTreeSet::new();
        let mut pending = vec![tail.header(), self.after_write];
        while let Some(at) = pending.pop() {
            let site = at as usize;
            if !original.contains(&site) || !alive.insert(site) || site == self.first {
                continue;
            }
            let next = if let Some(&next) = stability.successors.get(&site) {
                vec![next]
            } else if let Ok(next) = facts.successors(at) {
                next.into_iter().flatten().collect()
            } else {
                return;
            };
            pending.extend(next.into_iter().filter(|&next| {
                next != self.latch || site == self.continuation
            }));
        }
        if !alive.contains(&self.first) || !alive.contains(&(self.after_write as usize)) {
            return;
        }
        self.sites.retain(|site| alive.contains(site));
        self.blocks.retain(|site, _| alive.contains(&(*site as usize)));
        stability.predicates.retain(|site, _| alive.contains(site));
        stability.observations.retain(|site, _| alive.contains(site));
        stability.successors.retain(|site, _| alive.contains(site));
        self.stability = stability;
    }
    pub fn predicate(&self, site: usize) -> Option<bool> {
        self.stability.predicates.get(&site).copied()
    }
    pub fn observation(&self, site: usize) -> Option<(u32, bool)> {
        self.stability.observations.get(&site).copied()
    }
    pub fn successor(&self, site: usize) -> Option<u32> {
        self.stability.successors.get(&site).copied()
    }
    pub fn predicates(&self) -> Vec<(usize, bool)> {
        self.stability.predicates.iter().map(|(&site, &truth)| (site, truth)).collect()
    }
    pub fn observations(&self) -> Vec<(usize, u32, bool)> {
        self.stability.observations.iter().map(|(&site, &(value, truth))| (site, value, truth)).collect()
    }
    pub fn successors(&self) -> Vec<(usize, u32)> {
        self.stability.successors.iter().map(|(&site, &next)| (site, next)).collect()
    }
'''+needle
assert needle in s;s=s.replace(needle,new,1);p.write_text(s)
p=base/'readonly_numeric.rs';s=p.read_text()
s=s.replace('    pub cfg_cell_prefixes: Vec<(usize, usize, usize, usize)>,','''    pub cfg_cell_prefixes: Vec<(usize, usize, usize, usize)>,
    pub retained_cell_predicates: Vec<(usize, bool)>,
    pub retained_cell_observations: Vec<(usize, u32, bool)>,
    pub retained_cell_successors: Vec<(usize, u32)>,''',1)
s=s.replace('    let cell_context =\n','    let mut cell_context =\n',1)
needle='    let checks = versions\n'
new='''    if controls.enabled(OptimizationPass::StableCellPredicates) {
        if let Some(context) = &mut cell_context {
            context.refine(
                &program.metadata().plan.facts(),
                &program.metadata().buffer_frames,
                proof,
                &region.tail,
            );
        }
    }
'''+needle
assert needle in s;s=s.replace(needle,new,1)
needle='        reused_cell_write_sources: Vec::new(),'
new='''        retained_cell_predicates: cell_context.as_ref().map(CellContext::predicates).unwrap_or_default(),
        retained_cell_observations: cell_context.as_ref().map(CellContext::observations).unwrap_or_default(),
        retained_cell_successors: cell_context.as_ref().map(CellContext::successors).unwrap_or_default(),
'''+needle
assert needle in s;s=s.replace(needle,new,1)
needle='        match proof.action(site) {\n            Some(Operation::Fallback)'
new='''        let ready_context = cell_context.as_ref().filter(|_| cell_mode == CellMode::Ready);
        if let Some((output, truth)) = ready_context.and_then(|context| context.observation(site)) {
            let value = b.ins().iconst(types::I64, i64::from(truth));
            words.write(b, output as usize, value);
        } else {
        match proof.action(site) {
            Some(Operation::Fallback)'''
assert needle in s;s=s.replace(needle,new,1)
needle='                    let value = if let Some(&known) = traversal.predicates.get(&site) {'
new='''                    let known = ready_context.and_then(|context| context.predicate(site))
                        .or_else(|| traversal.predicates.get(&site).copied());
                    let value = if let Some(known) = known {'''
assert needle in s;s=s.replace(needle,new,1)
needle='        if cell_context.is_none() {\n            for cache in &rolling_caches {'
assert needle in s;s=s.replace(needle,'        }\n'+needle,1)
needle='''        } else {
            terminators::emit_source_terminator(
                b,
                &words,
                code,
                site,
                controls.options(),
                traversal
                    .successors
                    .get(&site)'''
new='''        } else {
            let retained_next = ready_context.and_then(|context| context.successor(site));
            terminators::emit_source_terminator(
                b,
                &words,
                code,
                site,
                controls.options(),
                retained_next.as_ref().or_else(|| traversal
                    .successors
                    .get(&site))'''
assert needle in s;s=s.replace(needle,new,1);p.write_text(s)
print('Wired proof refinement, Ready-only folding, source graph pruning, and descriptive metadata.')
