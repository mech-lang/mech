from pathlib import Path
import importlib.util,json,os,re,shutil,subprocess,time
root=Path.cwd();f=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(s);s.loader.exec_module(b)
plan=b.read(f/'plan.json');focus=b.read(f/'focused-result.json');fp=b.compiler_fingerprint();assert focus['exit_code']==0 and focus['passed_tests']==[16] and fp==focus['compiler_fingerprint'] and focus['source_unchanged']
p=f/'prototype';p.mkdir(exist_ok=False)
for name in plan['source_paths']:
 out=p/'source'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((root/name).read_bytes())
env=os.environ.copy();target=Path('/private/tmp/mech-polybench-pr1000-target');env['CARGO_TARGET_DIR']=str(target);argv=['cargo','build','--release','-p','mech-gpu','--no-default-features','--features','canonical-native-program','--example','polybench_qualification'];started=time.monotonic()
with(p/'build.log').open('x')as log:child=subprocess.Popen(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT);print('Prototype build PID',child.pid,flush=True);code=child.wait()
b.write(p/'build.json',{'command':argv,'pid':child.pid,'exit_code':code,'compiler_fingerprint':fp,'source_unchanged':b.compiler_fingerprint()==fp,'wall_seconds':time.monotonic()-started,'performance_observations':0});assert code==0 and b.compiler_fingerprint()==fp
binary=f/'stable-cell-context-predicates-prototype-driver';shutil.copy2(target/'release/examples/polybench_qualification',binary)
_,cases=b.protocol();config=p/'seidel-2d-inputs.json';b.write(config,cases['seidel-2d']['inputs']);obj=p/'seidel-2d.o';argv=[str(binary),str(b.FIXTURE/'seidel-2d.mec'),str(config),'0','emit-object='+str(obj)]
with(p/'object.stdout').open('x')as out,(p/'object.stderr').open('x')as err:child=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err);code=child.wait()
assert code==0;status=json.loads((p/'object.stdout').read_text().strip().splitlines()[-1]);assert status['status']=='ok' and status['mode']=='emit-object'
asm=subprocess.check_output(['/Library/Developer/CommandLineTools/usr/bin/llvm-objdump','--disassemble','--no-show-raw-insn',str(obj)],text=True);(p/'seidel-2d.disasm.txt').write_text(asm);metadata=b.read(obj.with_suffix('.metadata.json'));lines=[];selected=False
for line in asm.splitlines():
 match=re.match(r'^[0-9a-f]+ <_(.+)>:',line)
 if match:selected='_numeric_'in match[1];continue
 match=re.match(r'^\s*([0-9a-f]+):\s+(.*)$',line)
 if selected and match:lines.append((int(match[1],16),match[2].strip()))
assert lines
# A target-specific static diagnostic of the unchanged78008 source loan fee.
# Compiler admission never uses this number or benchmark identity.
debits=[]
for i,(address,ins) in enumerate(lines):
 m=re.fullmatch(r'mov\s+w(\d+), #12472',ins)
 if not m or i+1>=len(lines)or not re.fullmatch(r'movk\s+w'+m[1]+r', #1, lsl #16',lines[i+1][1]):continue
 for j in range(i+2,min(i+8,len(lines))):
  n=re.fullmatch(r'sub\s+x(\d+), x(\d+), x'+m[1],lines[j][1])
  if not n:continue
  before=lines[max(0,i-4):j];after=lines[j+1:j+9]
  loads=[{'offset':hex(at),'instruction':v}for at,v in before if re.match(r'(?:ldur|ldr)\s+x'+n[2]+r', \[sp',v)]
  stores=[{'offset':hex(at),'instruction':v}for at,v in after if re.match(r'(?:stur|str)\s+x'+n[1]+r', \[sp',v)]
  point=any(re.fullmatch(r'cmp\s+x\d+, x\d+',v)for _,v in after)
  debits.append({'constant_offset':hex(address),'subtract_offset':hex(lines[j][0]),'instruction':lines[j][1],'balance_loads':loads,'balance_stores':stores,'point_compare_follows':point,'direct_register_balance':not loads and not stores,'window':[{'offset':hex(at),'instruction':v}for at,v in lines[max(0,i-3):j+9]]});break
assert debits,'Unchanged source fee could not be bound to actual debit instructions.'
point=[row for row in debits if row['point_compare_follows']];vector_stack=[{'offset':hex(at),'instruction':v}for at,v in lines if re.search(r'\b(?:ldur|stur|ldr|str|ldp|stp)\s+q\d+[^\n]*\[sp',v)]
recipes=[v for row in metadata['compiled_numeric_write_loops']for v in row['rolling_cell_prefixes']];read_proof=any(v[3]==9 and v[4]==3 for v in recipes)
retained_predicates=[v for row in metadata['compiled_numeric_write_loops']for v in row['retained_cell_predicates']]
retained_observations=[v for row in metadata['compiled_numeric_write_loops']for v in row['retained_cell_observations']]
retained_successors=[v for row in metadata['compiled_numeric_write_loops']for v in row['retained_cell_successors']]
cfg=[v for row in metadata['compiled_numeric_write_loops']for v in row['cfg_cell_prefixes']]
predicate_gate=len(retained_predicates)>=2 and bool(retained_observations) and bool(retained_successors) and bool(cfg) and all(v[2]<62 and v[3]==0 for v in cfg)
receipt={'schema':'mech.polybench.source-frozen-static-prototype.v1','compiler_fingerprint':fp,'driver_sha256':b.digest(binary),'object_sha256':b.digest(obj),'object_executed':False,'code_bytes':metadata['code_bytes'],'reported_stack_bytes':metadata['stack_bytes'],'cfg_recipes':[v for row in metadata['compiled_numeric_write_loops'] for v in row['cfg_cell_prefixes']],'rolling_recipes':recipes,'vector_stack_accesses':vector_stack,'debits':debits,'point_debits':point,'retained_predicates':retained_predicates,'retained_observations':retained_observations,'retained_successors':retained_successors,'source_predicate_gate':predicate_gate,'passed':predicate_gate and any(row['cfg_cell_prefixes'] for row in metadata['compiled_numeric_write_loops'])and bool(point)and all(row['direct_register_balance']for row in point)and not vector_stack and read_proof,'source_unchanged':b.compiler_fingerprint()==fp,'performance_observations':0,'interpretation':'Inspect actual source-fee balance storage and private source-read recipe. This is a static prototype gate, not performance qualification or a latency/hardware forecast.'}
assert receipt['source_unchanged'];b.write(f/'prototype-result.json',receipt);b.write(p/'result.json',receipt);print(json.dumps(receipt),flush=True)
