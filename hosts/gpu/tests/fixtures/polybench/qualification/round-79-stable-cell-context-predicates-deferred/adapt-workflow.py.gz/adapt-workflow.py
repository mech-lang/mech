from pathlib import Path
f=Path(__file__).resolve().parent
p=f/'run-prototype.py';s=p.read_text()
needle="receipt={'schema':'mech.polybench.source-frozen-static-prototype.v1'"
insert="""retained_predicates=[v for row in metadata['compiled_numeric_write_loops']for v in row['retained_cell_predicates']]
retained_observations=[v for row in metadata['compiled_numeric_write_loops']for v in row['retained_cell_observations']]
retained_successors=[v for row in metadata['compiled_numeric_write_loops']for v in row['retained_cell_successors']]
cfg=[v for row in metadata['compiled_numeric_write_loops']for v in row['cfg_cell_prefixes']]
predicate_gate=len(retained_predicates)>=2 and bool(retained_observations) and bool(retained_successors) and bool(cfg) and all(v[2]<62 and v[3]==0 for v in cfg)
"""
assert needle in s;s=s.replace(needle,insert+needle,1)
s=s.replace("'passed':any(row['cfg_cell_prefixes']", "'retained_predicates':retained_predicates,'retained_observations':retained_observations,'retained_successors':retained_successors,'source_predicate_gate':predicate_gate,'passed':predicate_gate and any(row['cfg_cell_prefixes']",1)
p.write_text(s)
p=f/'emission-census.py';s=p.read_text()
s=s.replace("['cfg_cell_prefixes','rolling_cell_prefixes'", "['retained_cell_predicates','retained_cell_observations','retained_cell_successors','cfg_cell_prefixes','rolling_cell_prefixes'",1)
s=s.replace("r['credit_register_gate']=prototype['passed']", "r['credit_register_gate']=prototype['passed']\nr['stable_predicates_emitted']=prototype['source_predicate_gate'] and len(target['actors']['candidate']['retained_cell_predicates'])>=2 and bool(target['actors']['candidate']['retained_cell_observations'])")
s=s.replace("r['passed']=r['cfg_contexts_emitted']", "r['passed']=r['stable_predicates_emitted'] and r['cfg_contexts_emitted']",1)
p.write_text(s)
for name in ['run-focused.py','run-qualification.py','preserve-training.py','preserve-qualification.py','preserve-unselected.py']:
 p=f/name;s=p.read_text()
 s=s.replace('Complete focused rolling point-prefix qualification','Complete focused source-stable predicate and rolling-prefix qualification')
 s=s.replace('Source-derived fresh/reusable/write CFG contexts with zero carried cache-control words', 'Source-proved unchanged U64 guard and exact nominal enum observations fold only inside the reusable source graph, with mandatory-path, exact source-transfer and current-definition-availability checks; fresh/reusable/write CFG contexts retain zero carried cache-control words')
 s=s.replace('q[\'tests\']>=780','q[\'tests\']>=785')
 s=s.replace('The bounded-cache-lifetime compiler', 'The source-stable context predicate compiler')
 s=s.replace('Actual code17152B/stack336B is larger than accepted59;', 'Actual Object code/stack and retained source predicates are recorded in the static telemetry;')
 old="'next_source_investigation':'Retain CFG foundation only as an unpromoted archive. Ready-root still recomputes source predicates whose scalar inputs are unchanged by the exact post-store carrier transition. Derive mandatory predecessor outcomes and source/structural scalar stability from actual source values/frame recipes, then fold only proved stable predicates/successors inside reusable context. Mutable matrix and advancing column predicates cannot be inherited. This differs from metadata reduction or repeated private-first. Require source/error/resource proof and actual work removal before any new-fingerprint probe.',"
 s=s.replace(old,"'next_source_investigation':'No follow-on candidate selected here. Preserve actual source/telemetry/observations and restore accepted source under the existing optimization-only gates.',")
 p.write_text(s)
p=f/'preserve-qualification.py';s=p.read_text()
s=s.replace("assert emission['complete']and emission['passed']", "assert emission['stable_predicates_emitted']and emission['complete']and emission['passed']",1)
s=s.replace("'schema':'mech.polybench.cfg-cell-context-source-audit.v1'", "'schema':'mech.polybench.stable-cell-context-source-audit.v1'",1)
needle="source_audit={'schema'"
assert needle in s
# Record the new proof independently of the retained CFG/cache foundation audit.
s=s.replace("'reviewed':True,'passed':True,", "'reviewed':True,'passed':True,\n 'stable_predicate_proof':'Only Ready context inherits outcomes. Actual U64 comparison operands must be constants, fixed unique captures, exact unchanged next-carrier source projections, or checked pure scalar derivations thereof. Every current-visit source definition must dominate its consumer. Previous comparison/branch must dominate the successful point, with exactly one Boolean successor reaching it before latch/exit. Advancing columns and matrix reads decline. Exact EnumOrdinal folding requires actual post-store EnumPack and identical nominal source Enum schema. Prune only unreachable Ready blocks; Fresh/COW/reset/error and exact original logical fees remain. Genuine Object and negative/decoded/restored tests bind actual source predicates and source graph shrinkage.',",1)
p.write_text(s)
print('Adapted workflow to require actual retained guards and reduced reusable source graph, retaining original static and correctness gates.')
