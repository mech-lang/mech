from pathlib import Path
import re
old=Path('/private/tmp/mech-polybench-optimization/round-53/immutable-map-read-reuse');f=Path(__file__).resolve().parent
names=['run-qualification.py','prepare-qualification-manifest.py','run-all-qualification.py','training-probe.py','run-training-probe.py','preserve-qualification.py','preserve-training.py','preserve-unselected.py','measure-candidate.py','run-formal.py','audit-results.py','finalize-formal.py','untimed-counter-gate.py']
for name in names:
 s=(old/name).read_text();s=re.sub(r'accepted(51|52)',lambda m:'accepted'+str(int(m[1])+1),s)
 s=re.sub(r'(?<![A-Za-z0-9_])(?:51|52|53)(?![A-Za-z0-9_])',lambda m:str(int(m[0])+1),s)
 s=s.replace('immutable-map-read-reuse','ordered-product-four-rows').replace('Immutable map read reuse','Four independent product rows').replace('immutable map read reuse','four independent product rows').replace('map read reuse','four-row product grouping').replace('read_reuse_emitted','four_row_tiles_emitted').replace('round-53-read-reuse-route-census','round-53-product-four-row-route-census').replace('>=748','>=756').replace('len(paths)==10','len(paths)==9').replace("'native_typed_ir_version':420","'native_typed_ir_version':422").replace('IR420','IR422').replace('9.096908651052887','8.964570055711857').replace('24.60099065552092','24.520309780198453')
 if name=='run-qualification.py':
  start=s.index("receipt={'scope':");end=s.index(",'compiler_fingerprint':fp",start);s=s[:start]+"receipt={'scope':'Four-row ordered product tiles: independent +0/k arithmetic, shared right loads, dynamic/fixed/vector/rectangular/tail/empty banks, original/decoded/restored epilogues, cancellation, caps/aliases/atomic cleanup; maintained scalar/compression/forged-loan/image/all30 finite C and both features; no performance samples'"+s[end:]
 if name=='preserve-qualification.py':
  start=s.index('source_audit={');end=s.index("\nb.write(folder/'source-audit.json'",start)
  audit={'schema':'mech.polybench.ordered-product-four-row-source-audit.v1','compiler_fingerprint':None,'reviewed':True,'passed':True,'geometry':'Only source-selected admitted F64 products. Empty count exits before division, either axis loop or address. Nonempty count/columns supplies rows; four rows only when remaining>=4, then2/1 tails; two columns only when remaining>=2. Existing host-checked complete input/output spans and geometry remain.','arithmetic':'One reached RHS load and k header/backedge supply4 independent ordered +0 accumulators; per-cell original multiply/add/k order stays exact, with no FMA or reassociation. Runtime-shaped Cranelift tests and old2-row/scalar oracles cover odd/rectangular/vector/empty banks and sentinels.','epilogues':'Each actual row/column/index feeds the maintained source-closed cell epilogue. Consumed nonfinite values cancel the whole private loan and replay original source. Final-only publication and all original bounds/owners/source failures remain.','ownership_and_fees':'No runtime/frame/helper/ABI/data buffer/allocation change. Original source work/comparison, visits and all other counters match accepted52 exactly. Same full issued-frame/epoch/context, replay/physical admission, atomic cleanup/alias/retry rules remain.','ablation':'Private ProductRowQuartets disables only4-row emission and retains accepted52 two-row code; ProductRowPairs still retains the original flat kernel when disabled. Direct scalar and compression paths remain.','limitations':'Actual Object def-use confirms one reached floating load feeds4 multiplies and independent add registers; static totals include cold variants and can grow. No retired hardware counts, measured memory traffic or runtime gain is inferred before the single prospective probe.'}
  s=s[:start]+'source_audit='+repr(audit)+"\nsource_audit['compiler_fingerprint']=fp"+s[end:];s=s.replace("rglob('*.gz')","rglob('*.rs')")
 if name=='untimed-counter-gate.py':
  s=s.replace("views=emission['cases'][name]['actors']['candidate']['guarded_map_initializations']","views=emission['cases'][name]['actors']['candidate']['shared_right_load_groups']")
  s=s.replace('One successful immutable checked read supplies an identical later source read on a proved unchanged dominating path. Every source fee, callback and execution counter remains unchanged; no fictitious visits or skipped original failures.','One RHS load/k loop serves four independent ordered output rows. This changes only private native kernel execution, preserving every original source callback, logical fee and execution counter; no visits are skipped.')
 if name=='audit-results.py':s=s.replace('Checked Objects certify source-derived successful read reuse and reduced duplicate checked-read emission; no arithmetic reordering or FMA.','Checked Objects certify one reached RHS load feeding four independent ordered product accumulators; no arithmetic reordering or FMA.')
 if name=='finalize-formal.py':
  s=s.replace('Every original operation/error remains; identical later reads reuse a successful immutable word under a checked dominance/scope proof.','Every original source callback remains; one private RHS load/k loop serves four ordered output rows under the unchanged issued loan.')
  s=s.replace('General map bodies reuse only successful immutable reads with exact selectors and a dominating unchanged source chain.','General F64 products group four independent output rows around one RHS load/k loop, with original per-cell arithmetic order and2/1-row tails.')
 if name=='preserve-unselected.py':
  s=s.replace('Identical later immutable matrix reads reuse a successful checked word under source dominance and stable selectors.','One RHS load/k loop feeds four independent ordered product rows.')
  s=s.replace('Map read reuse probe not selected','Four-row product probe not selected')
 (f/name).write_text(s)
# Reuse the genuine machine def-use census and require four uses rather than pairs.
s=Path('/private/tmp/mech-polybench-optimization/round-52/ordered-product-row-pairs/emission-census.py').read_text().replace('accepted50','accepted52').replace('product-row-pairs-static','product-four-rows-static')
start=s.index('def reuse_groups(');end=s.index("\nr={'schema'",start)
function=r'''def reuse_groups(asm):
 groups=[];definitions={};multiplies=[];adds=[];lines=[];local_loads=set()
 def reg(word):
  word=word.strip().strip('{} ').strip()
  m=re.fullmatch(r'(?:q|d|v)(\d+)(?:\.\w+)?(?:\[\d+\])?',word)
  return 'f'+m[1] if m else None
 def finish():
  if len(set(adds))<4:return
  for load in sorted(local_loads):
   uses=[m['line'] for m in multiplies if load in m['values']]
   if len(uses)>=4 and not re.search(r'\[(?:sp|x29)\b',load):groups.append({'shared_reached_load':load,'multiply_sites':uses,'independent_add_registers':sorted(set(adds)),'block':list(lines)})
 for line in asm.splitlines():
  m=re.match(r'^\s*([0-9a-f]+):\s+(\S+)\s*(.*)$',line)
  if not m:continue
  address,mnemonic,operands=m.groups();args=[x.strip()for x in operands.split(',')];lines.append(line)
  if mnemonic.startswith(('b.','cbz','cbnz','tbz','tbnz')) or mnemonic in ['b','blr','br','ret']:
   finish();multiplies=[];adds=[];lines=[];local_loads=set();continue
  if mnemonic.startswith('fmul') and len(args)==3:multiplies.append({'line':line,'values':[definitions.get(reg(v))for v in args[1:] if definitions.get(reg(v)) is not None]})
  if mnemonic.startswith('fadd') and args and reg(args[0]):adds.append(reg(args[0]))
  destination=reg(args[0])if args else None
  if destination and not mnemonic.startswith(('str','stur','stp','cmp','fcmp')):
   if mnemonic in ['fmov','mov','mov.16b'] and len(args)==2 and reg(args[1]) in definitions:definitions[destination]=definitions[reg(args[1])]
   else:definitions[destination]=line
   if mnemonic.startswith(('ldr','ldur','ld1r')):local_loads.add(definitions[destination])
 finish();return groups
'''
s=s[:start]+function+s[end:]
s=s.replace("'masked_matrix_maps':records(metadata,'masked_matrix_maps')","'product_epilogues':metadata.get('compiled_product_epilogues',[]),'reduction_producers':metadata.get('compiled_reduction_producers',[]),'masked_matrix_maps':records(metadata,'masked_matrix_maps')")
s=s.replace("['masked_matrix_maps','guarded_map_initializations','compound_matrix_maps']","['masked_matrix_maps','guarded_map_initializations','compound_matrix_maps','product_epilogues','reduction_producers']")
s=s.replace("r['row_pairs_emitted']=len(r['cases']['mvt']['actors']['candidate']['shared_right_load_groups'])>=2 and not r['cases']['mvt']['actors']['accepted52']['shared_right_load_groups']","r['four_row_tiles_emitted']=all(len(r['cases'][name]['actors']['candidate']['shared_right_load_groups'])>=2 and not r['cases'][name]['actors']['accepted52']['shared_right_load_groups'] for name in ['mvt','correlation'])")
s=s.replace("r['row_pairs_emitted']","r['four_row_tiles_emitted']").replace('Both two-row scalar and two-row SIMD bodies use one reached RHS load SSA value for two separate multiplies','Both four-row scalar and four-row SIMD bodies use one reached RHS load SSA value for four separate multiplies')
(f/'emission-census.py').write_text(s)
for name in names+['emission-census.py']:compile((f/name).read_text(),str(f/name),'exec')
print('Prepared qualification/probe/formal workflow against accepted52; formal index53, history53 ->54,756 broad/4 focused minimum, no timing observations.')
