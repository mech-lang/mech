from pathlib import Path
import json,shutil
root=Path.cwd();native=root/'hosts/gpu/src/native_artifact';folder=Path(__file__).resolve().parent;plan=json.loads((folder/'plan.json').read_text());backup=folder/'source-before';backup.mkdir(exist_ok=False)
for name in plan['source_paths']:
 p=root/name
 if p.exists():d=backup/name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
def edit(name,old,new):
 p=native/name;s=p.read_text();assert old in s,(name,old[:110]);p.write_text(s.replace(old,new,1))
p=native/'program/codegen/numeric_product_rows.rs';old=p.read_text();tests=old[old.index('#[cfg(test)]'):]
production=r'''//! Bounded row register tiles share RHS loads and k control. Each scalar or
//! column-SIMD accumulator keeps its original +0 and ordered dot product.
use super::*;
fn tile(
    b: &mut FunctionBuilder<'_>, left: Value, right: Value, output: Value,
    row: Value, column: Value, columns: Value, inner: Value,
    row_width: usize, vector: bool, epilogue: Option<&Epilogue<'_>>,
) {
    debug_assert!([1,2,4].contains(&row_width));
    let ty=if vector {types::F64.by(2).unwrap()}else{types::F64};
    let left0=b.ins().imul(row,inner);
    let index0=b.ins().imul(row,columns);
    let index0=b.ins().iadd(index0,column);
    let mut states=vec![(row,left0,index0)];
    let mut prior_index=index0;
    for offset in 1..row_width {
        let r=b.ins().iadd_imm(row,offset as i64);
        let base=b.ins().imul(r,inner);
        let index=b.ins().iadd(prior_index,columns);
        states.push((r,base,index));prior_index=index;
    }
    let k=b.declare_var(types::I64);
    let sums=(0..row_width).map(|_|b.declare_var(ty)).collect::<Vec<_>>();
    let zero=b.ins().iconst(types::I64,0);
    let identity=b.ins().f64const(0.0);
    let identity=if vector {b.ins().splat(ty,identity)}else{identity};
    b.def_var(k,zero);
    for &sum in &sums {b.def_var(sum,identity);}
    let header=b.create_block();let body=b.create_block();let finish=b.create_block();
    b.ins().jump(header,&[]);b.switch_to_block(header);
    let at=b.use_var(k);let more=b.ins().icmp(IntCC::UnsignedLessThan,at,inner);
    b.ins().brif(more,body,&[],finish,&[]);b.switch_to_block(body);
    let ri=b.ins().imul(at,columns);let ri=b.ins().iadd(ri,column);
    let rp=address(b,right,ri);
    // One reached RHS load feeds every independent row in this register tile.
    let rhs=b.ins().load(ty,MemFlags::new(),rp,0);
    for ((_,base,_),&sum) in states.iter().zip(&sums) {
        let li=b.ins().iadd(*base,at);let lp=address(b,left,li);
        let lhs=b.ins().load(types::F64,MemFlags::new(),lp,0);
        let lhs=if vector {b.ins().splat(ty,lhs)}else{lhs};
        let term=f64_arithmetic(b,NativeScalarOp::F64Mul,lhs,rhs);
        let prior=b.use_var(sum);let next=f64_arithmetic(b,NativeScalarOp::F64Add,prior,term);
        b.def_var(sum,next);
    }
    let advanced=b.ins().iadd_imm(at,1);b.def_var(k,advanced);b.ins().jump(header,&[]);
    b.switch_to_block(finish);
    for ((r,_,index),&sum) in states.iter().zip(&sums) {
        let result=b.use_var(sum);
        let result=if let Some(e)=epilogue {e.apply(b,result,*r,column,*index,vector)}else{result};
        let destination=address(b,output,*index);b.ins().store(MemFlags::new(),result,destination,0);
    }
}
pub(super) fn emit(
    b: &mut FunctionBuilder<'_>, left: Value, right: Value, output: Value,
    count: Value, columns: Value, inner: Value, epilogue: Option<&Epilogue<'_>>,
    quartets: bool, done: Block,
) {
    let nonempty=b.create_block();let valid=b.ins().icmp_imm(IntCC::NotEqual,count,0);
    // No division, either axis traversal or address is reached for empty output.
    b.ins().brif(valid,nonempty,&[],done,&[]);b.switch_to_block(nonempty);
    let rows=b.ins().udiv(count,columns);
    let row=b.declare_var(types::I64);let zero=b.ins().iconst(types::I64,0);b.def_var(row,zero);
    let header=b.create_block();let body=b.create_block();b.ins().jump(header,&[]);
    b.switch_to_block(header);let at_row=b.use_var(row);
    let more=b.ins().icmp(IntCC::UnsignedLessThan,at_row,rows);b.ins().brif(more,body,&[],done,&[]);
    b.switch_to_block(body);let remaining=b.ins().isub(rows,at_row);
    let mut entries=Vec::new();
    if quartets {
        let four=b.create_block();let tails=b.create_block();
        let enough=b.ins().icmp_imm(IntCC::UnsignedGreaterThanOrEqual,remaining,4);
        b.ins().brif(enough,four,&[],tails,&[]);b.switch_to_block(tails);entries.push((four,4));
    }
    let two=b.ins().icmp_imm(IntCC::UnsignedGreaterThanOrEqual,remaining,2);
    let pair=b.create_block();let single=b.create_block();b.ins().brif(two,pair,&[],single,&[]);
    entries.extend([(pair,2),(single,1)]);
    for (entry,step) in entries {
        b.switch_to_block(entry);let column=b.declare_var(types::I64);b.def_var(column,zero);
        let columns_header=b.create_block();let columns_body=b.create_block();let next_rows=b.create_block();
        b.ins().jump(columns_header,&[]);b.switch_to_block(columns_header);
        let at_column=b.use_var(column);let more=b.ins().icmp(IntCC::UnsignedLessThan,at_column,columns);
        b.ins().brif(more,columns_body,&[],next_rows,&[]);b.switch_to_block(columns_body);
        let remaining=b.ins().isub(columns,at_column);
        let two=b.ins().icmp_imm(IntCC::UnsignedGreaterThanOrEqual,remaining,2);
        let paired_columns=b.create_block();let scalar_column=b.create_block();b.ins().brif(two,paired_columns,&[],scalar_column,&[]);
        for (block,vector,width) in [(paired_columns,true,2),(scalar_column,false,1)] {
            b.switch_to_block(block);tile(b,left,right,output,at_row,at_column,columns,inner,step,vector,epilogue);
            let next=b.ins().iadd_imm(at_column,width);b.def_var(column,next);b.ins().jump(columns_header,&[]);
        }
        b.switch_to_block(next_rows);let next=b.ins().iadd_imm(at_row,step as i64);b.def_var(row,next);b.ins().jump(header,&[]);
    }
}

'''
tests=tests.replace('fn function(paired: bool) -> Function','fn function(paired: bool, quartets: bool) -> Function').replace('a[5], paired, done','a[5], paired, quartets, done').replace('let f = function(paired);','let f = function(paired, false);')
start=tests.index('    #[test]');end=tests.rfind('\n}');oldtest=tests[start:end]
newtest=oldtest.replace('numeric_product_rows_runtime_kernel_shares_right_ssa_and_keeps_order_tails_and_banks','numeric_product_quartets_runtime_kernel_shares_four_rhs_uses_order_tails_and_banks').replace('for paired in [false, true]','for paired in [true]').replace('function(paired, false)','function(paired, true)').replace('args.len() == 2 && args[0] == args[1]','args.len() == 4 && args.iter().all(|&v| v == args[0])').replace('ordered_product_rows','ordered_product_quartets').replace('rows in 0..=5u64','rows in 0..=9u64').replace('inner in 0..=5u64','inner in 0..=7u64').replace('columns in 0..=5u64','columns in 0..=7u64')
p.write_text(production+tests[:end]+'\n'+newtest+tests[end:])
name='program/codegen/numeric_product.rs'
# Thread the private emission control through all three product entry helpers.
s=(native/name).read_text();assert s.count('    row_pairs: bool,\n    done: Block,')==3;s=s.replace('    row_pairs: bool,\n    done: Block,','    row_pairs: bool,\n    row_quartets: bool,\n    done: Block,')
s=s.replace('None, row_pairs, done,','None, row_pairs, row_quartets, done,')
s=s.replace('        row_pairs,\n        done,','        row_pairs,\n        row_quartets,\n        done,')
s=s.replace('count, columns, inner, epilogue, done,','count, columns, inner, epilogue, row_quartets, done,');(native/name).write_text(s)
name='program/codegen/numeric_binary.rs'
edit(name,'    product_row_pairs: bool,\n    error: Block,','    product_row_pairs: bool,\n    product_row_quartets: bool,\n    error: Block,')
# The product call is multi-line in the maintained ordinary emitter.
p=native/name;s=p.read_text();needle='                product_row_pairs,\n                complete,';assert needle in s;s=s.replace(needle,'                product_row_pairs,\n                product_row_quartets,\n                complete,',1);p.write_text(s)
name='program/codegen/numeric_product_epilogues.rs'
edit(name,'    row_pairs: bool,\n    target: Block,','    row_pairs: bool,\n    row_quartets: bool,\n    target: Block,')
edit(name,'b, left, right, output, count, columns, inner, &epilogue, row_pairs, complete,','b, left, right, output, count, columns, inner, &epilogue, row_pairs, row_quartets, complete,')
name='codegen/control/mod.rs'
edit(name,'controls.enabled(crate::native_artifact::codegen::options::OptimizationPass::ProductRowPairs),target,error)?;','controls.enabled(crate::native_artifact::codegen::options::OptimizationPass::ProductRowPairs),controls.enabled(crate::native_artifact::codegen::options::OptimizationPass::ProductRowQuartets),target,error)?;')
edit(name,'                                controls.enabled(crate::native_artifact::codegen::options::OptimizationPass::ProductRowPairs),\n                                error,','                                controls.enabled(crate::native_artifact::codegen::options::OptimizationPass::ProductRowPairs),\n                                controls.enabled(crate::native_artifact::codegen::options::OptimizationPass::ProductRowQuartets),\n                                error,')
edit('codegen/options.rs','    ProductRowPairs,','    ProductRowPairs,\n    /// Share the same RHS and k control across four independent ordered rows.\n    ProductRowQuartets,')
edit('program/image/identity.rs','pub const NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 421;','pub const NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 422;')
edit('program/runtime/composition_tests/mod.rs','mod numeric_product_rows;','mod numeric_product_rows;\nmod numeric_product_quartets;')
# Keep the established end-to-end harness and compare specifically to accepted52's two-row emitter.
s=(native/'program/runtime/composition_tests/numeric_product_rows.rs').read_text().replace('General ordered product row pairs','Four independent ordered product rows').replace('OptimizationPass::ProductRowPairs','OptimizationPass::ProductRowQuartets').replace('fn numeric_product_rows_','fn numeric_product_quartets_')
s=s.replace('        (8, 9, 6),','        (8, 9, 6),\n        (9, 7, 5),\n        (10, 7, 1),\n        (11, 3, 7),')
s=s.replace('Some([5, 1])','Some([7, 1])').replace('Some([5, 7])','Some([7, 7])').replace('else { 0.75 }; 15]','else { 0.75 }; 21]').replace('("left", data(&a), &[5, 3])','("left", data(&a), &[7, 3])')
s=s.replace('("left", data(&vec![v; 15]), &[3, 5])','("left", data(&vec![v; 40]), &[8, 5])')
(native/'program/runtime/composition_tests/numeric_product_quartets.rs').write_text(s)
print('Wrote four-row shared kernel and private two-row ablation;4 focused tests planned. No build or timing started.')
