"""Checked optimization Objects, emitted instructions and addressing evidence."""
import hashlib,importlib.util,json,re,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
protocol,cases=b.protocol();q=b.read(folder/'qualification.json');plan=b.read(folder/'plan.json');fp=b.compiler_fingerprint()
assert q['complete'] and fp==q['compiler_fingerprint']
actors={'accepted52':Path(plan['accepted_driver']),'candidate':Path(q['driver'])}
assert b.digest(actors['accepted52'])==plan['accepted_driver_sha256'] and b.digest(actors['candidate'])==q['driver_sha256']
objects=folder/'objects';objects.mkdir(exist_ok=False)
def functions(asm):
 rows={};name=None
 for line in asm.splitlines():
  m=re.match(r'^[0-9a-f]+ <_(.+)>:',line)
  if m:name=m[1];rows[name]=[]
  elif name and re.match(r'^\s*[0-9a-f]+:',line):rows[name].append(line)
 return {name:{'instructions':len(lines),'disassembly_sha256':hashlib.sha256('\n'.join(lines).encode()).hexdigest()} for name,lines in rows.items()}
def records(value,key):
 if isinstance(value,dict):return sum((v if k==key else records(v,key) for k,v in value.items()),[])
 if isinstance(value,list):return sum((records(v,key) for v in value),[])
 return []

def reuse_groups(asm):
 groups=[];definitions={};multiplies=[];adds=[];lines=[];local_loads=set()
 def reg(word):
  word=word.strip().strip('{} ').strip()
  m=re.fullmatch(r'(?:q|d|v)(\d+)(?:\.\w+)?(?:\[\d+\])?',word)
  return 'f'+m[1] if m else None
 def finish():
  if len(set(adds))<4:return
  for load in sorted(local_loads):
   uses=[m['line'] for m in multiplies if load in m['values']]
   if len(uses)>=4 and not re.search(r'\[(?:sp|x29)\b',load):groups.append({'shared_reached_load':load,'multiply_sites':uses,'independent_add_registers':sorted(set(adds)),'block':list(lines)})
 for line in asm.splitlines():
  m=re.match(r'^\s*([0-9a-f]+):\s+(\S+)\s*(.*)$',line)
  if not m:continue
  address,mnemonic,operands=m.groups();args=[x.strip()for x in operands.split(',')];lines.append(line)
  if mnemonic.startswith(('b.','cbz','cbnz','tbz','tbnz')) or mnemonic in ['b','blr','br','ret']:
   finish();multiplies=[];adds=[];lines=[];local_loads=set();continue
  if mnemonic.startswith('fmul') and len(args)==3:multiplies.append({'line':line,'values':[definitions.get(reg(v))for v in args[1:] if definitions.get(reg(v)) is not None]})
  if mnemonic.startswith('fadd') and args and reg(args[0]):adds.append(reg(args[0]))
  destination=reg(args[0])if args else None
  if destination and not mnemonic.startswith(('str','stur','stp','cmp','fcmp')):
   if mnemonic in ['fmov','mov','mov.16b'] and len(args)==2 and reg(args[1]) in definitions:definitions[destination]=definitions[reg(args[1])]
   else:definitions[destination]=line
   if mnemonic.startswith(('ldr','ldur','ld1r')):local_loads.add(definitions[destination])
 finish();return groups

r={'schema':'mech.polybench.product-four-rows-static-telemetry.v1','scope':'Optimization15 genuine checked Object exports and emitted static instructions only. No linked Object execution, timing samples, retired hardware instructions or measured memory traffic.','compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'cases':{},'complete':False,'performance_observations':0}
for name in protocol['optimization']:
 config=folder/f'{name}-inputs.json';b.write(config,cases[name]['inputs']);row={'actors':{}};r['cases'][name]=row
 for actor,driver in actors.items():
  obj=objects/f'{name}-{actor}.o';argv=[str(driver),str(b.FIXTURE/f'{name}.mec'),str(config),'0',f'emit-object={obj}']
  stdout=objects/f'{name}-{actor}.stdout';stderr=objects/f'{name}-{actor}.stderr'
  with stdout.open('x') as out,stderr.open('x') as err:
   child=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err);r['pending']={'case':name,'actor':actor,'pid':child.pid,'command':argv};b.write(folder/'emission-census.json',r)
   while True:
    try:code=child.wait(timeout=30);break
    except subprocess.TimeoutExpired:print('Waiting on same Object process',child.pid,flush=True)
  assert code==0,stderr.read_text();r.pop('pending');status=json.loads(stdout.read_text().strip().splitlines()[-1]);assert status['status']=='ok' and status['mode']=='emit-object'
  metadata=b.read(obj.with_suffix('.metadata.json'));asm=subprocess.run(['/Library/Developer/CommandLineTools/usr/bin/llvm-objdump','--disassemble','--no-show-raw-insn',str(obj)],text=True,capture_output=True,check=True).stdout;disasm=obj.with_suffix('.disasm.txt');disasm.write_text(asm);fm=functions(asm);assert fm and any(v['instructions'] for v in fm.values())
  row['actors'][actor]={'code_bytes':metadata['code_bytes'],'reported_native_stack_bytes':metadata['stack_bytes'],'object_file_bytes':obj.stat().st_size,'static_instruction_count':sum(v['instructions'] for v in fm.values()),'functions':fm,'object_sha256':b.digest(obj),'metadata_sha256':b.digest(obj.with_suffix('.metadata.json')),'disassembly_sha256':b.digest(disasm),'object_executed':False,'shared_right_load_groups':reuse_groups(asm),'product_epilogues':metadata.get('compiled_product_epilogues',[]),'reduction_producers':metadata.get('compiled_reduction_producers',[]),'masked_matrix_maps':records(metadata,'masked_matrix_maps'),'guarded_map_initializations':records(metadata,'guarded_map_initializations'),'compound_matrix_maps':records(metadata,'compound_matrix_maps'),'hardware_division_sites':len(re.findall(r'\budiv\b',asm)),'fused_multiply_add_instructions':len(re.findall(r'\b(?:fmadd|fmsub|fnmadd|fnmsub|fmla|fmls)\b',asm))}
 row['functions_match']=row['actors']['accepted52']['functions']==row['actors']['candidate']['functions'];row['code_bytes_match']=row['actors']['accepted52']['code_bytes']==row['actors']['candidate']['code_bytes']
 for key in ['masked_matrix_maps','guarded_map_initializations','compound_matrix_maps','product_epilogues','reduction_producers']:
  assert row['actors']['accepted52'][key]==row['actors']['candidate'][key]
 row['division_site_delta']=row['actors']['candidate']['hardware_division_sites']-row['actors']['accepted52']['hardware_division_sites']
 b.write(folder/'emission-census.json',r);print(name,'code',row['actors']['accepted52']['code_bytes'],'->',row['actors']['candidate']['code_bytes'],'division site delta',row['division_site_delta'],flush=True)
r['native_code_changed_cases']=[name for name,row in r['cases'].items() if not row['functions_match'] or not row['code_bytes_match']]
r['no_new_fma']=all(row['actors']['candidate']['fused_multiply_add_instructions']<=row['actors']['accepted52']['fused_multiply_add_instructions'] for row in r['cases'].values())
r['four_row_tiles_emitted']=all(len(r['cases'][name]['actors']['candidate']['shared_right_load_groups'])>=2 and not r['cases'][name]['actors']['accepted52']['shared_right_load_groups'] for name in ['mvt','correlation'])
r['independent_runtime_shape_kernel']='Focused Cranelift kernel has six runtime word parameters. Both four-row scalar and four-row SIMD bodies use one reached RHS load SSA value for four separate multiplies and independent +0/k accumulators. Ordered scalar oracle, canary banks, empty null banks and actual original/decoded/restored programs pass; every execution counter is unchanged.'
r.update(complete=len(r['cases'])==15,source_unchanged=b.compiler_fingerprint()==fp)
r['passed']=r['complete'] and r['source_unchanged'] and r['four_row_tiles_emitted'] and r['no_new_fma'];b.write(folder/'emission-census.json',r)
assert r['passed'];print('Shared right-load/independent-accumulator Object evidence passed',flush=True)
