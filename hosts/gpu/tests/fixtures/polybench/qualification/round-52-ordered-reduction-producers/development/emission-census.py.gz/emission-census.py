"""Checked optimization Objects, emitted instructions and addressing evidence."""
import hashlib,importlib.util,json,re,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
protocol,cases=b.protocol();q=b.read(folder/'qualification.json');plan=b.read(folder/'plan.json');fp=b.compiler_fingerprint()
assert q['complete'] and fp==q['compiler_fingerprint']
actors={'accepted51':Path(plan['accepted_driver']),'candidate':Path(q['driver'])}
assert b.digest(actors['accepted51'])==plan['accepted_driver_sha256'] and b.digest(actors['candidate'])==q['driver_sha256']
objects=folder/'objects';objects.mkdir(exist_ok=False)
def functions(asm):
 rows={};name=None
 for line in asm.splitlines():
  m=re.match(r'^[0-9a-f]+ <_(.+)>:',line)
  if m:name=m[1];rows[name]=[]
  elif name and re.match(r'^\s*[0-9a-f]+:',line):rows[name].append(line)
 return {name:{'instructions':len(lines),'disassembly_sha256':hashlib.sha256('\n'.join(lines).encode()).hexdigest()} for name,lines in rows.items()}
def records(value,key):
 if isinstance(value,dict):return sum((v if k==key else records(v,key) for k,v in value.items()),[])
 if isinstance(value,list):return sum((records(v,key) for v in value),[])
 return []

r={'schema':'mech.polybench.reduction-producer-static-telemetry.v1','scope':'Optimization15 genuine checked Object exports and emitted static instructions only. No linked Object execution, timing samples, retired hardware instructions or measured memory traffic.','compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'cases':{},'complete':False,'performance_observations':0}
for name in protocol['optimization']:
 config=folder/f'{name}-inputs.json';b.write(config,cases[name]['inputs']);row={'actors':{}};r['cases'][name]=row
 for actor,driver in actors.items():
  obj=objects/f'{name}-{actor}.o';argv=[str(driver),str(b.FIXTURE/f'{name}.mec'),str(config),'0',f'emit-object={obj}']
  stdout=objects/f'{name}-{actor}.stdout';stderr=objects/f'{name}-{actor}.stderr'
  with stdout.open('x') as out,stderr.open('x') as err:
   child=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err);r['pending']={'case':name,'actor':actor,'pid':child.pid,'command':argv};b.write(folder/'emission-census.json',r)
   while True:
    try:code=child.wait(timeout=30);break
    except subprocess.TimeoutExpired:print('Waiting on same Object process',child.pid,flush=True)
  assert code==0,stderr.read_text();r.pop('pending');status=json.loads(stdout.read_text().strip().splitlines()[-1]);assert status['status']=='ok' and status['mode']=='emit-object'
  metadata=b.read(obj.with_suffix('.metadata.json'));asm=subprocess.run(['/Library/Developer/CommandLineTools/usr/bin/llvm-objdump','--disassemble','--no-show-raw-insn',str(obj)],text=True,capture_output=True,check=True).stdout;disasm=obj.with_suffix('.disasm.txt');disasm.write_text(asm);fm=functions(asm);assert fm and any(v['instructions'] for v in fm.values())
  row['actors'][actor]={'code_bytes':metadata['code_bytes'],'object_file_bytes':obj.stat().st_size,'static_instruction_count':sum(v['instructions'] for v in fm.values()),'functions':fm,'object_sha256':b.digest(obj),'metadata_sha256':b.digest(obj.with_suffix('.metadata.json')),'disassembly_sha256':b.digest(disasm),'object_executed':False,'reduction_producers':metadata.get('compiled_reduction_producers',[]),'product_epilogues':metadata.get('compiled_product_epilogues',[]),'load_instruction_sites':len(re.findall(r'\b(?:ldr|ldrb|ldrh|ldrsb|ldrsh|ldrsw|ldur|ldurb|ldurh|ldursb|ldursh|ldursw|ldp)\b',asm)),'masked_matrix_maps':records(metadata,'masked_matrix_maps'),'guarded_map_initializations':records(metadata,'guarded_map_initializations'),'compound_matrix_maps':records(metadata,'compound_matrix_maps'),'hardware_division_sites':len(re.findall(r'\budiv\b',asm)),'fused_multiply_add_instructions':len(re.findall(r'\b(?:fmadd|fmsub|fnmadd|fnmsub|fmla|fmls)\b',asm))}
 row['functions_match']=row['actors']['accepted51']['functions']==row['actors']['candidate']['functions'];row['code_bytes_match']=row['actors']['accepted51']['code_bytes']==row['actors']['candidate']['code_bytes']
 for key in ['masked_matrix_maps','guarded_map_initializations','compound_matrix_maps','product_epilogues']:
  assert row['actors']['accepted51'][key]==row['actors']['candidate'][key]
 row['division_site_delta']=row['actors']['candidate']['hardware_division_sites']-row['actors']['accepted51']['hardware_division_sites']
 b.write(folder/'emission-census.json',r);print(name,'code',row['actors']['accepted51']['code_bytes'],'->',row['actors']['candidate']['code_bytes'],'division site delta',row['division_site_delta'],flush=True)
r['native_code_changed_cases']=[name for name,row in r['cases'].items() if not row['functions_match'] or not row['code_bytes_match']]
r['no_new_fma']=all(row['actors']['candidate']['fused_multiply_add_instructions']<=row['actors']['accepted51']['fused_multiply_add_instructions'] for row in r['cases'].values())
r['reduction_producer_cases']=[name for name,row in r['cases'].items() if row['actors']['candidate']['reduction_producers']]
r['reduction_producers_emitted']=bool(r['cases']['correlation']['actors']['candidate']['reduction_producers']) and not r['cases']['correlation']['actors']['accepted51']['reduction_producers'] and not r['cases']['correlation']['functions_match']
r['source_proof']='Pure F64 source closure, exact same-parent unique-predecessor CFG, complete read-role escape/liveness proof, independently source/image-derived recipe and original factory geometry. Shared ordered sum emission receives direct rounded source terms; only the final bank is allocated/published through the existing checked loan.'
r['physical_source_work']='Complete producer matrices, their input/output passes and individual operator boundaries are absent on the admitted path. Final-only bank/helper observations and exact skipped-site counts are checked separately. Static Object totals include original fallback code; no hardware instruction or traffic claim is inferred.'
r.update(complete=len(r['cases'])==15,source_unchanged=b.compiler_fingerprint()==fp)
r['passed']=r['complete'] and r['source_unchanged'] and r['reduction_producers_emitted'] and r['no_new_fma'];b.write(folder/'emission-census.json',r)
assert r['passed'];print('Ordered reduction producer Object evidence passed',flush=True)
