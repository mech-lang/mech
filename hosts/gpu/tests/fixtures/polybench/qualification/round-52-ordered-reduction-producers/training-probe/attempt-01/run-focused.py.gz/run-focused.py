import json,os,pathlib,re,subprocess,time,importlib.util
root=pathlib.Path('/Users/cim310/.codex/worktrees/polybench-pr1000/mech');folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
fp=b.compiler_fingerprint();attempt=folder/'attempt-01';assert fp==b.read(attempt/'source-manifest.json')['compiler_fingerprint']
env=os.environ.copy();env['CARGO_TARGET_DIR']='/private/tmp/mech-polybench-pr1000-target'
argv=['cargo','test','--release','-p','mech-gpu','--no-default-features','--features','canonical-native-program','--lib','--','numeric_reduction_producers','--test-threads=1']
start=time.monotonic()
with (attempt/'focused.log').open('x') as f:r=subprocess.run(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
log=(attempt/'focused.log').read_text();result={'command':argv,'exit_code':r.returncode,'wall_seconds':time.monotonic()-start,'compiler_fingerprint':fp,'source_unchanged':b.compiler_fingerprint()==fp,'passed_tests':[int(n) for n in re.findall(r'test result: ok[.] (\d+) passed',log)]}
b.write(attempt/'focused-result.json',result)
if r.returncode==0:b.write(folder/'focused-result.json',result)
s=b.read(folder/'current-work.json');s.update(stage='Focused development complete' if r.returncode==0 else 'Focused development failure preserved',exit_code=r.returncode,live_exec_session=None);b.write(folder/'current-work.json',s)
print(json.dumps(result),flush=True);print(log[-6500:],flush=True);assert result['source_unchanged'];raise SystemExit(r.returncode)
