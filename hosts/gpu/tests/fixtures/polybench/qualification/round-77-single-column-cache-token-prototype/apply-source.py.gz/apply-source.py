from pathlib import Path
import importlib.util,subprocess
root=Path.cwd();s=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(s);s.loader.exec_module(b)
base=Path('/private/tmp/mech-polybench-optimization/round-75/bounded-cell-cache-lifetimes');q=b.read(base/'qualification.json');plan=b.read(Path(__file__).parent/'plan.json')
assert b.command(['git','status','--porcelain'])=='' and b.compiler_fingerprint()==plan['accepted_compiler_fingerprint']
for name,digest in q['source_sha256'].items():
 source=base/'qualified-source'/name;assert b.digest(source)==digest;(root/name).write_bytes(source.read_bytes())
assert b.compiler_fingerprint()==q['compiler_fingerprint']
p=root/'hosts/gpu/src/native_artifact/program/image/identity.rs';t=p.read_text();assert 'NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 432' in t;p.write_text(t.replace('NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 432','NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 433'))
p=root/'hosts/gpu/src/native_artifact/program/codegen/numeric_cell_rolling.rs';t=p.read_text()
t=t.replace('    valid: Variable,\n    pending: Variable,\n','')
t=t.replace('        let zero = b.ins().iconst(types::I8, 0);\n','')
t=t.replace('        let valid = b.declare_var(types::I8);\n        b.def_var(valid, zero);\n        let pending = b.declare_var(types::I8);\n        b.def_var(pending, zero);\n','')
t=t.replace('            valid,\n            pending,\n','')
t=t.replace('        b.def_var(self.valid, zero);\n        b.def_var(self.pending, zero);\n','')
start=t.index('        let valid = b.use_var(self.valid);');end=t.index('        if let Some(at) = self.max_checked',start)
t=t[:start]+'''        // A private token is zero or the maximum fully admitted one-based
        // source-read column, in 1..=columns. Under that invariant the two
        // wrapping decrements admit exactly 0 < token < columns, even when
        // columns is zero. No external word can manufacture a cache token.
        let last = b.use_var(self.max_column);
        let last = b.ins().iadd_imm(last, -1);
        let upper = b.ins().iadd_imm(columns, -1);
        let mut yes = b.ins().icmp(IntCC::UnsignedLessThan, last, upper);
'''+t[end:]
t=t.replace('        b.def_var(self.valid, zero);\n','')
t=t.replace('        let one = b.ins().iconst(types::I8, 1);\n        b.def_var(self.pending, one);\n','')
start=t.index('    pub fn finish_write(');end=t.index('    pub fn control(',start);t=t[:start]+t[end:]
t=t.replace('    max_column: Variable,','    // Zero is inactive. A positive token is staged immediately before the\n    // sole source write; no reuse edge exists until that write completes.\n    max_column: Variable,',1)
assert 'self.valid' not in t and 'self.pending' not in t and 'finish_write' not in t;p.write_text(t)
p=root/'hosts/gpu/src/native_artifact/program/codegen/readonly_numeric.rs';t=p.read_text();old='''                        for cache in &rolling_caches {
                            cache.finish_write(b, site);
                        }
''';assert t.count(old)==1;p.write_text(t.replace(old,''))
p=root/'hosts/gpu/src/native_artifact/program/codegen/numeric_cell_rolling_tests.rs';t=p.read_text();assert '        cache.finish_write(&mut b, 100);\n' in t;t=t.replace('        cache.finish_write(&mut b, 100);\n','');p.write_text(t)
with p.open('a')as out:out.write(r'''

#[test]
fn cell_prefix_rolling_column_token_native_guard_empty_extreme_and_checked_overflow() {
    for extra_check in [false,true] {
        let (_,mut recipe)=point();if extra_check {recipe.max_checked=2;}
        let mut module=JITModule::new(JITBuilder::new(cranelift_module::default_libcall_names()).unwrap());let mut context=module.make_context();context.func.signature=Signature {params:vec![AbiParam::new(types::I64);3],returns:vec![AbiParam::new(types::I64)],call_conv:module.isa().default_call_conv()};
        let function=module.declare_function("column_token_guard",Linkage::Export,&context.func.signature).unwrap();let mut bc=FunctionBuilderContext::new();
        {let mut b=FunctionBuilder::new(&mut context.func,&mut bc);let entry=b.create_block();b.append_block_params_for_function_params(entry);b.switch_to_block(entry);let args=b.block_params(entry).to_vec();let cache=Cache::new(&mut b,recipe);b.def_var(cache.max_column,args[0]);if let Some(at)=cache.max_checked {b.def_var(at,args[2]);}
         let admitted=cache.reusable(&mut b,args[1]);let admitted=b.ins().uextend(types::I64,admitted);b.ins().return_(&[admitted]);b.seal_all_blocks();b.finalize();}
        module.define_function(function,&mut context).unwrap();module.finalize_definitions().unwrap();
        // SAFETY: this generated leaf takes and returns words; it has no loads.
        let guard=unsafe {core::mem::transmute::<*const u8,unsafe extern "C" fn(u64,u64,u64)->u64>(module.get_finalized_function(function))};
        for columns in [0u64,1,2,3,40,u64::MAX-1,u64::MAX] {for token in [0u64,1,columns.saturating_sub(1),columns] {
            if token>columns {continue} // unreachable private token state
            for checked in [0u64,7,u64::MAX-1,u64::MAX] {
                let expected=token!=0&&token<columns&&(!extra_check||checked!=u64::MAX);
                // SAFETY: all arguments are scalar words; no source view exists.
                assert_eq!(unsafe{guard(token,columns,checked)},u64::from(expected),"token{token} columns{columns} checked{checked}");
            }
        }}
    }
}
''')
subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true',*[str(root/name)for name in plan['source_paths']]],check=True)
print('Single-column-token source and native guard qualification applied/formatted; no timing.')
