"""Preserve all development evidence and qualify source before any timing."""
import gzip,importlib.util,json,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;q=b.read(folder/'qualification.json');plan=b.read(folder/'plan.json');gate=b.read(folder/'untimed-counter-gate.json');emission=b.read(folder/'emission-census.json');fp=b.compiler_fingerprint()
assert b.command(['git','branch','--show-current'])=='codex/polybench-native-matrices'
assert q['complete'] and q['driver_build_complete'] and q['tests']>=743 and q['focused_checks']['passed_tests']==[13]
assert fp==q['compiler_fingerprint']==gate['compiler_fingerprint']==emission['compiler_fingerprint']
assert gate['complete'] and gate['passed'] and gate['finite_liveouts']==17002 and all(row['all_counters_match'] for row in gate['cases'].values())
assert emission['complete'] and emission['passed'] and emission['transpose_induction_emitted'] and emission['no_new_fma']
assert b.digest(q['driver'])==q['driver_sha256'] and len(b.read(p/'performance-history.json')['entries'])==51
assert b.read(p/'performance-acceptance.json')['accepted_history_index']==50 and not (folder/'training-probe.json').exists()
paths=plan['source_paths'];changed=subprocess.check_output(['git','diff','--name-only',plan['source_parent'],'--'],text=True).splitlines();changed+=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines();actual=sorted({name for name in changed if name.endswith(('.rs','.toml')) or Path(name).name=='Cargo.lock'})
assert set(actual)<=set(paths) and actual and len(paths)==8 and all(b.digest(root/name)==q['source_sha256'][name] for name in paths)
source_snapshot=folder/'qualified-source';source_snapshot.mkdir(exist_ok=False)
for name in paths:
 out=source_snapshot/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((root/name).read_bytes())
(folder/'qualified-source.patch').write_bytes(subprocess.check_output(['git','diff',plan['source_parent'],'--',*paths]))
attempts=[{'path':str(f.relative_to(folder)),'sha256':b.digest(f),'result':b.read(f),'source_snapshot_files':len(list((f.parent/'source').rglob('*.gz')))} for f in sorted(folder.glob('attempt-*/focused-result.json'))]
assert attempts and attempts[-1]['result']['exit_code']==0 and attempts[-1]['result']['compiler_fingerprint']==fp
source_audit={'schema':'mech.polybench.native-transpose-source-audit.v1','compiler_fingerprint':fp,'reviewed':True,'passed':True,'copy_order':'Identical output-row-major store and input-index sequence; source=(column*input_columns)+row. Dynamic induction uses no division.','empty':'Count==0 exits before either axis, including u32::MAX full-program resident axes and u64::MAX isolated null-bank axes.','address_bounds':'Nonempty product and spans validated before entry. Increment source only when next column reached; all formed source/output addresses inside admitted disjoint banks.','ownership_and_fees':'Original selected factory, current-owner validation, checked nonoverflow product/spans/nonoverlap, full scratch/allocation, source fees, prepare/finish and atomic publication unchanged. Every O counter equal accepted50.','bits':'I64 raw copies, no floating operation, reassociation or FMA.','ablation':'Default ordinary emit_selected uses induction; private pass ablation uses original emit flat loop. Existing fixed private generator retains its exact original emit API/behavior.','limits_and_failure':'New old-flat finite/missing cap, atomic alias and retry tests plus maintained numeric_binary physical denial/forged frame/loan/interleaving checks passed.','limitations':'Static instructions and structural division removal, not hardware-retired counters or measured memory traffic. No runtime-speedup inference before the single prospective probe.'}
b.write(folder/'source-audit.json',source_audit)
dest=p/'qualification/round-51-native-transpose-induction/development';dest.mkdir(parents=True,exist_ok=False);archives={}
for source in sorted(folder.rglob('*')):
 if not source.is_file() or '__pycache__' in source.parts or source==Path(q['driver']):continue
 name=str(source.relative_to(folder));raw=source.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives[name]={'path':str(out.relative_to(p)),'sha256':b.digest(source),'compressed_sha256':b.digest(out)}
receipt={'schema':'mech.polybench.native-transpose-induction-development.v1','created_at':b.utc(),'complete':True,'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'qualification_manifest':q,'effective_plan':plan,'selection_policy_sha256':b.digest(p/'performance-selection-policy-v4.json'),'source_parent':plan['source_parent'],'source_sha256':q['source_sha256'],'actual_changed_source_paths':actual,'profiling_basis':plan['profiling_basis'],'invariants':plan['implementation'],'counter_gate':gate,'emission_census':emission,'source_audit':source_audit,'development_attempts':attempts,'failed_attempt_logs_and_receipts_preserved':True,'layout_explanation':b.read(folder/'development-layout-explanation.json'),'performance_observations':0,'archives':archives}
b.write(p/'training-experiments/native-transpose-induction-development.json',receipt)
b.write(p/'training-experiments/native-transpose-induction-training-schedule.json',b.read(folder/'training-probe-plan.json'))
b.write(p/'round-51-transpose-route-census.json',gate)
subprocess.run(['git','diff','--check'],check=True);subprocess.run(['git','add','--',*paths,str(p.relative_to(root))],check=True)
result=subprocess.run(['git','commit','-m','Qualify native transpose induction before optimization selection'],capture_output=True,text=True);(folder/'qualification-source-commit.log').write_text(result.stdout+result.stderr);assert result.returncode==0
head=b.command(['git','rev-parse','HEAD']);assert b.compiler_fingerprint()==fp and b.command(['git','status','--porcelain'])==''
b.write(folder/'qualification-source-commit.json',{'source_commit':head,'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'performance_observations':0,'archives_verified':len(archives),'clean':True})
print(json.dumps({'head':head,'compiler_fingerprint':fp,'broad_checks':q['tests'],'focused_checks':13,'archives':len(archives),'performance_observations':0,'clean':True}),flush=True)
