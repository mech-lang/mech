"""Record the strict formal decision; restore accepted source after rejection."""
import gzip
import hashlib
import importlib.util
import subprocess
from pathlib import Path

root = Path.cwd()
folder = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("b", root / "scripts/benchmark-polybench.py")
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
p = b.FIXTURE
f = b.read(p / "round-43-frozen.json")
tq = b.read(p / "round-43-training-qualification.json")
audit = b.read(p / "round-43-audit.json")
decision = audit["performance_acceptance"]
g = b.read(p / "round-43-progress.json")
old = b.read(p / "round-31-progress.json")
assert b.command(["git", "rev-parse", "HEAD"]) == f["source_commit"]
assert b.command(["git", "branch", "--show-current"]) == "codex/polybench-native-matrices"
assert b.compiler_fingerprint() == f["compiler_fingerprint"] == tq["compiler_fingerprint"]
assert audit["observations"] == 900 and audit["finite_liveouts"] == 29482
assert audit["history_entries"] == len(b.read(p / "performance-history.json")["entries"]) == 44
for item in tq["development_archives"].values():
    raw = (p / item["path"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == item["compressed_sha256"]
    assert hashlib.sha256(gzip.decompress(raw)).hexdigest() == item["sha256"]
promoted = decision["performance_gate"] == "accepted"
scores = {part: g["aggregates"][part]["geomean_mech_over_c_kernel"] for part in ("optimization", "holdout")}
prior = {part: old["aggregates"][part]["geomean_mech_over_c_kernel"] for part in scores}
assert promoted == all(scores[part] < prior[part] for part in scores)
assert decision["accepted_index_after_run"] == (43 if promoted else 31)
q = {
    "schema": "mech.polybench.optimization-qualification.v1",
    "label": f["label"], "compiler_commit": f["source_commit"],
    "compiler_fingerprint": f["compiler_fingerprint"], "driver_sha256": f["driver_sha256"],
    "frozen_candidate_sha256": b.digest(p / "round-43-frozen.json"),
    "native_typed_ir_version": 408, "native_work_policy_version": 156, "native_abi_version": 47,
    "dataset": "MINI", "numeric_profile": "F64",
    "comparison": {"rtol": 1e-10, "atol": 1e-9, "finite_required": True, "live_outs_per_artifact": 29482},
    "checks": tq["checks"], "total_unique_selected_checks": tq["total_unique_selected_checks"],
    "focused_selected_checks": tq["focused_selected_checks"],
    "source_invariants": tq["invariants"], "profiling_basis": tq["profiling_basis"],
    "development_attempts": tq["development_attempts"],
    "emission_census": {"receipt_sha256": b.digest(p / "round-43-emission-census.json"), "scope": "Optimization15 actual checked Objects: remove all three large whole-map copy loops, shrink the stack and reduce conditional branches versus round42 under the unchanged prospective gate. No new FMA, Object execution or timing."},
    "training_probe": b.read(p / "round-43-training-probe.json")["summary"],
    "performance_acceptance": decision,
    "aggregate_controls_vs_accepted31": audit["aggregate_controls_vs_accepted31"],
    "scope": tq["limitations"],
    "holdout_use": "Aggregate acceptance only; no per-case diagnosis, profiling or source tuning.",
}
paths = list(tq["source_sha256"])
assert len(paths) == 10
if not promoted:
    accepted = "f60baf055a39497400f9392e0294911becf1a697"
    subprocess.run(["git", "restore", "--source=" + accepted, "--worktree", "--", *paths], check=True)
    subprocess.run(["git", "add", "-A", "--", *paths], check=True)
    fp = b.compiler_fingerprint()
    assert fp == b.read(p / "round-31-frozen.json")["compiler_fingerprint"] == "6447915ae298711f3886c6cba28e0608eb3ce59feab6287308162e45e006c895"
    assert b.digest("/private/tmp/mech-polybench-optimization/round-31/inverse-bitcasts/bitcast-driver") == b.read(p / "round-31-frozen.json")["driver_sha256"]
    q["compiler_restored_to_accepted31"] = {"restored_from_commit": accepted, "compiler_fingerprint": fp, "source_paths": paths, "versions": {"ir": 390, "work": 156, "abi": 47}, "accepted_driver_unchanged": True, "reason": "Both primary formal scores must strictly improve. A selected training probe cannot override that gate."}
else:
    fp = b.compiler_fingerprint()
    q["compiler_promoted"] = {"accepted_index": 43, "compiler_fingerprint": fp, "scores": scores}
dest = p / "qualification/round-43-guarded-map-domains/formal-run"
dest.mkdir(exist_ok=False)
archives = {}
for name in ["formal-measurement.log", "frozen-source-checkpoint.json", "source-commit.log", "experiment-source-commit.json", "inter-round-aggregates.json", "formal-report-rows.json", "measure-candidate.py", "audit-results.py", "finalize-results.py"]:
    raw = (folder / name).read_bytes()
    out = dest / (name + ".gz")
    out.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(out.read_bytes()) == raw
    archives[name] = {"path": str(out.relative_to(p)), "sha256": hashlib.sha256(raw).hexdigest(), "compressed_sha256": b.digest(out)}
q["formal_run_archives"] = archives
b.write(p / "round-43-qualification.json", q)
text = "\nRound43: native guarded map domains (" + ("accepted" if promoted else "not promoted") + ")\n\n"
text += "Source CFG totality and current geometry authorize private bounds witnesses that suppress unreachable per-read axis guards. Pure row-invariant integer/Boolean control prefixes authorize retaining the rest of an identity column only in an already initialized current private bank. Inner-, memory- and FP-dependent prefixes retain normal iteration. Full direct-bank preflight, alias separation, fallible-map scratch evaluation, FP order/bits and all original source charges remain. No source-port change, benchmark-name checks, FP arithmetic change, runtime ABI change, weaker admission, ownership relaxation or reduced source bills. "
text += f"All{tq['total_unique_selected_checks']} broad checks,{tq['focused_selected_checks']} focused checks and both feature configurations pass, including all30 finite C-liveout programs. IR408/work156/ABI47.\n\n"
probe=b.read(p/'round-43-training-probe.json');summary=probe['summary']
text += f"The single prospective v2 optimization15 probe uses seven fresh-process observations per actor in alternating accepted31/candidate order. Raw geomean speedup is{summary['geomean_raw_speedup_vs_accepted31']:.6f}x; Gram-Schmidt is{probe['cases']['gramschmidt']['speedup_vs_accepted31']:.6f}x. All210 observations and{summary['regressions_over_five_percent']} regressions>5% remain. Visits match and source work/comparison charges do not decrease. "
text += "Before timing, actual checked optimization Objects must satisfy the preregistered removal of all three hot large whole-map copy loops, a smaller stack and fewer conditional branches than round42, without new FMA. Static counts do not establish runtime cost or feasibility. Source and driver were committed/frozen before both formal sets.\n\n"
text += "| Set | Accepted31 x C | Round43 x C | Raw speedup vs31 | Reference-adjusted speedup |\n|---|---:|---:|---:|---:|\n"
for part in scores:
    c=audit['aggregate_controls_vs_accepted31'][part]
    text += f"| {part.capitalize()} | {prior[part]:.5f}x | {scores[part]:.5f}x | {c['raw_mech_speedup']:.5f}x | {c['reference_adjusted_speedup']:.5f}x |\n"
text += "\n" + ("Both primary scores strictly improve; round43 is accepted. " if promoted else "The strict two-set gate rejects this run; exact accepted31 compiler source and driver are restored. ")
text += "All900 formal observations,29482 finite liveouts,44 append-only history entries, all regressions and development stages remain. No holdout per-case diagnosis, profiling or tuning. The fixed below1.0x C holdout goal is assessed from the accepted scores, with a separate completion audit required before claiming success.\n\n"
text += "[Qualification](round-43-qualification.json) · [Frozen source](round-43-frozen.json) · [Acceptance](round-43-performance-acceptance.json) · [Optimization-only native loop profile](training-experiments/native-map-memory-profile.json)\n"
readme = p / "README.txt"
readme.write_text(readme.read_text() + text)
subprocess.run(["git", "diff", "--check"], check=True)
subprocess.run(["git", "add", "--", str(p.relative_to(root))], check=True)
message = "Record native guarded map domains benchmark results" if promoted else "Retain rejected guarded map domain timings and restore accepted compiler"
result = subprocess.run(["git", "commit", "-m", message], capture_output=True, text=True)
(folder / "results-source-commit.log").write_text(result.stdout + result.stderr)
assert result.returncode == 0, result.stderr
assert b.compiler_fingerprint() == fp and b.command(["git", "status", "--porcelain"]) == ""
head = b.command(["git", "rev-parse", "HEAD"])
b.write(folder / "current-work.json", {
    "stage": "Round43 accepted; remote PR1001 update pending" if promoted else "Round43 rejected; exact accepted31 source and driver restored",
    "live_exec_session": None, "source_commit": head, "compiler_fingerprint": fp,
    "candidate_source_commit": f["source_commit"], "candidate_driver_sha256": f["driver_sha256"],
    "accepted_round": 43 if promoted else 31, "formal_history_entries": 44,
    "measured_scores": scores, "accepted_scores": scores if promoted else prior,
    "next": "Update PR1001 only after verifying its current head; continue next optimization-only margin." if promoted else "Retain failed run. Continue optimization-only work on the largest margin using the saved profiles; no retry of this source and no holdout per-case diagnosis.",
})
print({"head": head, "accepted_round": 43 if promoted else 31, "scores": scores, "accepted_scores": scores if promoted else prior, "observations": 900, "history_entries": 44, "archives_verified": len(tq["development_archives"]) + len(archives), "working_tree_clean": True, "pushed": False}, flush=True)
