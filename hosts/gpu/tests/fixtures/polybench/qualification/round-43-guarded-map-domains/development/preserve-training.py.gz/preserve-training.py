"""Preserve every qualified total-private-map development and prospective observation."""
import gzip,hashlib,importlib.util
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;q=b.read(folder/'qualification.json');census=b.read(folder/'execution-emission-census.json');probe=b.read(folder/'training-probe.json');plan=b.read(folder/'plan.json');fp=b.compiler_fingerprint()
assert q['complete'] and census['complete'] and census['prospective_gate_passed'] and probe['complete']
assert fp==q['compiler_fingerprint']==census['compiler_fingerprint']==probe['compiler_fingerprint'] and q['driver_sha256']==census['driver_sha256']==probe['driver_sha256']
assert all(c['exit_code']==0 for c in q['checks']);assert len(probe['cases'])==15 and sum(len(c['observations']) for c in probe['cases'].values())==210
assert probe['summary']['all_visits_match'] and probe['summary']['all_work_not_reduced']
dest=p/'qualification/round-43-guarded-map-domains/development';dest.mkdir(parents=True,exist_ok=False);archives={}
paths=[x for x in folder.iterdir() if x.is_file() and x.suffix in ('.py','.json','.log')]
paths += [x for a in sorted(folder.glob('attempt-*')) for x in a.rglob('*') if x.is_file()]
paths += [x for x in (folder/'execution-objects').rglob('*') if x.is_file()]
for path in sorted(paths):
 name=str(path.relative_to(folder));raw=path.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives[name]={'path':str(out.relative_to(p)),'sha256':hashlib.sha256(raw).hexdigest(),'compressed_sha256':b.digest(out)}
attempts=[{'name':a.name,'source_checkpoint':b.read(a/'source-checkpoint.json'),'focused_result':b.read(a/'focused-result.json'),'source_archive':str(a.name)+'/source','new_performance_observations':0} for a in sorted(folder.glob('attempt-*'))]
out=dict(q);out.update(schema='mech.polybench.training-qualification.v1',label='round43-guarded-map-domains',invariants=plan['invariants']+[plan['scope'],plan['training_selection'],plan['formal_acceptance']],profiling_basis=plan['profiling_basis'],prospective_plan=plan,prospective_plan_sha256=b.digest(p/'training-experiments/guarded-map-domain-plan.json'),total_unique_selected_checks=q['tests'],focused_selected_checks=sum(q['focused_checks']['passed_tests']),development_attempts=attempts,development_archives=archives,limitations='F64 MINI CPU scope. The retained174 JIT samples are coarse. Static code counts are not dynamic costs. The historically exposed holdout is an aggregate acceptance control. Training selection is not a formal Mech/C score or promotion.',training_probe_summary=probe['summary'])
for suffix,value in [('training-qualification',out),('training-probe',probe),('emission-census',census),('training-selection',{'schema':'mech.polybench.training-selection.v2','compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'accepted_round':31,'policy':probe['policy'],'result':probe['summary'],'selected':probe['summary']['selected'],'formal_evaluation_started':False})]:
 path=p/f'round-43-{suffix}.json';assert not path.exists();b.write(path,value)
print({'compiler_fingerprint':fp,'archives':len(archives),'checks':q['tests'],'focused_checks':out['focused_selected_checks'],'probe':probe['summary'],'formal_observations':0},flush=True)
