from pathlib import Path
import json,struct,re,subprocess,hashlib
f=Path(__file__).resolve().parent;plan=json.loads((f/'plan.json').read_text());result={'schema':'mech.polybench.same-pid-complete-code-binding.v1','scope':'Every executable byte matches its genuine Object except explicitly decoded BL relocations, whose actual destinations must equal captured named JIT functions in the same PID. No code is executed from an Object.','cases':{},'complete':False}
for case in plan['cases']:
 data=(f/f'{case}-residence.o').read_bytes();h=struct.unpack_from('<8I',data);pos=32;text=None;symtab=None
 for _ in range(h[4]):
  cmd,size=struct.unpack_from('<II',data,pos)
  if cmd==0x19:
   for i in range(struct.unpack_from('<I',data,pos+64)[0]):
    at=pos+72+80*i
    if data[at:at+16].split(b'\0',1)[0]==b'__text':text=struct.unpack_from('<QQI',data,at+32)
  if cmd==2:symtab=struct.unpack_from('<4I',data,pos+8)
  pos+=size
 assert text and symtab
 symoff,nsyms,stroff,strsize=symtab;symbols={}
 for i in range(nsyms):
  idx,typ,sect,desc,value=struct.unpack_from('<IBBHQ',data,symoff+16*i)
  if idx and sect:symbols[data[stroff+idx:stroff+strsize].split(b'\0',1)[0].decode()]=value
 reloc=subprocess.check_output(['/Library/Developer/CommandLineTools/usr/bin/llvm-objdump','--macho','--reloc',str(f/f'{case}-residence.o')],text=True);(f/f'{case}-object-relocations.txt').write_text(reloc)
 in_text=False;calls=[]
 for line in reloc.splitlines():
  if line.startswith('Relocation information'):in_text='(__TEXT,__text)' in line
  if not in_text or not re.match(r'^[0-9a-f]{8}\s',line):continue
  m=re.fullmatch(r'([0-9a-f]{8})\s+True\s+long\s+True\s+BR26\s+False\s+_(\S+)',line.strip());assert m,line;calls.append((int(m[1],16),m[2]))
 live=json.loads((f/f'live-code/{case}/jit-code.json').read_text());addresses={v['symbol']:v['address']for v in live['functions']};rows=[]
 for fn in live['functions']:
  begin=symbols['_'+fn['symbol']]-text[0];expected=data[text[2]+begin:text[2]+begin+fn['size']];actual=Path(fn['file']).read_bytes();assert len(actual)==len(expected)==fn['size'];allowed=set();bindings=[]
  for offset,target in calls:
   at=offset-begin
   if not 0<=at<fn['size']:continue
   assert at%4==0 and target in addresses
   word,=struct.unpack_from('<I',actual,at);assert word&0xfc000000==0x94000000
   imm=word&0x3ffffff
   if imm&0x2000000:imm-=0x4000000
   resolved=fn['address']+at+imm*4;assert resolved==addresses[target],(case,fn['symbol'],hex(resolved),hex(addresses[target]))
   allowed.update(range(at,at+4));bindings.append({'offset':at,'target_symbol':target,'resolved_jit_address':resolved,'expected_captured_address':addresses[target],'bound':True})
  diffs=[i for i,(a,b)in enumerate(zip(actual,expected))if a!=b];assert set(diffs)<=allowed,(case,fn['symbol'],diffs)
  rows.append({'symbol':fn['symbol'],'bytes':fn['size'],'byte_identical':not diffs,'differing_bytes':len(diffs),'all_nonrelocation_bytes_identical':True,'call_bindings':bindings})
 result['cases'][case]={'pid':live['pid'],'functions':rows,'complete_instruction_binding':True};print(case,'complete code binding',[(v['symbol'],v['bytes'],v['differing_bytes'],len(v['call_bindings']))for v in rows],flush=True)
result['complete']=True;(f/'instruction-binding.json').write_text(json.dumps(result,indent=2)+'\n')
