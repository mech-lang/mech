from pathlib import Path
import gzip,json,subprocess,importlib.util
root=Path.cwd();f=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);p=b.FIXTURE
r=b.read(f/'profile-result.json');v=b.read(f/'jit-object-verification.json');binding=b.read(f/'instruction-binding.json');plan=b.read(f/'plan.json');fp=b.compiler_fingerprint()
assert fp==r['compiler_fingerprint']==v['compiler_fingerprint']==plan['compiler_fingerprint']
assert r['complete'] and v['complete'] and binding['complete'] and r['source_and_history_unchanged']
assert len(b.read(p/'performance-history.json')['entries'])==59 and b.read(p/'performance-acceptance.json')['accepted_history_index']==58
assert b.command(['git','status','--porcelain'])==''
assert b.read(f/'collection-exit.json')['exit_code']==0
for case in plan['cases']:
 row=r['processes']['cases'][case]
 assert row['driver_exit_code']==row['sample_exit_code']==0 and row['frozen_execution_counters_match'] and row['warmup_validation']['finite'] and row['final_validation']['finite']
 assert binding['cases'][case]['complete_instruction_binding']
a=r['analysis'];g=a['gramschmidt.sample.txt'];d=a['durbin.sample.txt']
assert g['execution_samples']==2297 and d['execution_samples']==1722
interpretation={
 'scope':'Optimization15 diagnosis only, accepted58. No holdout diagnosis, profiling, performance selection or new performance observations.',
 'sample_scope':'Warm checked-call residence includes output reset/drop. Sampled self time is not an exact formal timer share, retired instructions, IPC, cache/traffic, RSS or a speedup forecast.',
 'cases':{case:{'execution_samples':a[case+'.sample.txt']['execution_samples'],'mechanisms':a[case+'.sample.txt']['self_time_mechanisms'],'top_self_functions':a[case+'.sample.txt']['top_self_functions'][:8],'top_jit_sites':a[case+'.sample.txt']['top_jit_sites'][:14]} for case in plan['cases']},
 'code_binding':'All complete sampled numeric ranges are byte-identical to genuine accepted58 Objects: Durbin7468B and Gram-Schmidt20120B. Callers13768B/35556B differ only in decoded BL relocations that resolve to the captured numeric function in the same sampled PID. Every other executable byte matches. Both owned processes terminate0 and match exact frozen counters and finite warm/final C outputs.',
 'gramschmidt_mechanism':'Generated-code self time1716/2297=74.71%. next-A selected evaluation:0x3478 loop header155 samples,0x3618 checked-axis predicate221,0x3634 column source load87. Selected publication0x34ec header283 and0x35bc store137 samples. The body reconstructs checked selectors and transports F64 source values through word SSA before arithmetic. Publication is still separate.',
 'durbin_mechanism':'Generated-code self time683/1722=39.66%. Selected map evaluation header0x10ac71 samples, publication0x10dc100, ordered dot header0xa0c81. Body0x1230 old-y load38 with per-cell subtraction/axis guards. The selected prefix includes two active source branches and must not read reversed index0 at its endpoint.',
 'history_review':'Rejected38 retained per-cell source actions under a bounds predicate; rejected41 removed Frame adapter storage but retained the checked source DAG; rejected43 removed identity columns under a retained private-map path; rejected55 changed selected publication traversal. Do not retry those fingerprints or retime them.',
 'next_direction':'Derive a source-closed F64 cell expression over affine current immutable read streams. Reuse ordered-dot corner proofs to establish all checked selector subexpressions over each selected domain once, then emit typed scalar/SIMD independent cells directly into the existing private scratch. Preserve arithmetic tree, rounding, simultaneous old reads, full source fees, ordinary checked-DAG fallback and complete-before-publication. This removes per-cell source DAG/index/word transport rather than adding another bounds flag or changing publication.',
 'limits':'No gain is claimed. The next materially changed fully qualified source gets exactly one prospective optimization15 probe. Promotion uses only optimization Mech/C; holdout is report-only.'}
b.write(f/'interpretation.json',interpretation)
dest=p/'qualification/round-66-accepted58-phase-profile';dest.mkdir(parents=True,exist_ok=False);archives={}
for source in sorted(f.rglob('*')):
 if not source.is_file() or '__pycache__' in source.parts or source.name=='residence-driver':continue
 name=str(source.relative_to(f));raw=source.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives[name]={'path':str(out.relative_to(p)),'sha256':b.digest(source),'compressed_sha256':b.digest(out)}
receipt={'schema':'mech.polybench.accepted-optimization-profile-evidence.v1','created_at':b.utc(),'accepted_round':58,'accepted_source_commit':b.read(p/'round-58-frozen.json')['source_commit'],'workspace_commit':b.command(['git','rev-parse','HEAD']),'compiler_fingerprint':fp,'driver_build':b.read(f/'residence-build.json'),'plan':plan,'same_pid_verification':v,'complete_instruction_binding':binding,'profile':r,'interpretation':interpretation,'official_performance_observations':0,'performance_history_entries_unchanged':59,'archives':archives}
b.write(p/'training-experiments/accepted58-phase-profile.json',receipt)
b.write(p/'round-58-cpu-telemetry.json',{'schema':'mech.polybench.cpu-telemetry.v2','accepted_round':58,'compiler_fingerprint':fp,'source_and_history_unchanged':True,'official_performance_observations':0,'cases':r['processes']['cases'],'analysis':a,'same_pid_jit_object_verification':v,'complete_instruction_binding':binding,'interpretation':interpretation,'evidence':'training-experiments/accepted58-phase-profile.json'})
with(p/'README.txt').open('a')as out:out.write('\nAccepted58 optimization-only CPU profiles\n\nOwned Durbin/Gram-Schmidt processes completed with finite C outputs and exact frozen counters. Their generated self-time fractions are39.66%/74.71%. Complete sampled numeric code is byte-identical to genuine accepted58 Objects; caller BL relocations resolve to same-PID captured numeric functions. Selected map bodies still execute repeated checked selector and word-transport work. This motivates source-closed typed affine cell kernels within the existing scratch/admission/publication boundary. No timing/history change or speedup forecast.\n\n[CPU telemetry](round-58-cpu-telemetry.json) · [Complete profile evidence](training-experiments/accepted58-phase-profile.json)\n')
subprocess.run(['git','diff','--check'],check=True)
subprocess.run(['git','add','--',str(p.relative_to(root))],check=True)
subprocess.run(['git','-c','gc.auto=0','commit','-q','-m','Bind accepted58 map profiles to same-process generated code'],check=True)
assert b.compiler_fingerprint()==fp and b.command(['git','status','--porcelain'])==''
print(json.dumps({'head':b.command(['git','rev-parse','HEAD']),'accepted_round':58,'archives_verified':len(archives),'history_entries':59,'official_performance_observations':0,'clean':True}),flush=True)
