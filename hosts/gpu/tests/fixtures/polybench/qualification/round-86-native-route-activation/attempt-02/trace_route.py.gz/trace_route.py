import lldb,json,time,pathlib,subprocess
f=pathlib.Path(__file__).resolve().parent
receipt={'schema':'mech.polybench.owned-native-route-diagnostic.v1','complete':False,'hits':{},'preflight_trace':[],'performance_observations':0}
def write(): (f/'route-trace.json').write_text(json.dumps(receipt,indent=2)+'\n')
def hit(frame,location,internal):
 bp=location.GetBreakpoint();key=str(bp.GetID());row=receipt['hits'][key];row['hit']=True;row['pc']=frame.GetPC();row['frame']=frame.GetFunctionName();bp.SetEnabled(False);write();return False
def run():
 plan=json.loads((f/'plan.json').read_text());debugger=lldb.debugger;debugger.SetAsync(True)
 target=debugger.CreateTarget(plan['driver']);assert target.IsValid();launch=lldb.SBLaunchInfo([str(pathlib.Path(plan['reference_gate']).parents[0]/'not-used')])
 root=pathlib.Path.cwd();source=root/'hosts/gpu/tests/fixtures/polybench/deriche.mec';inputs=f/'deriche-inputs.json'
 launch=lldb.SBLaunchInfo([str(source),str(inputs),'5']);launch.SetWorkingDirectory(str(root));launch.SetLaunchFlags(lldb.eLaunchFlagDebug);launch.SetEnvironmentEntries(['PERF_BUILDID_DIR='+str(f/'perf-binaries')],True)
 assert launch.AddOpenFileAction(1,str(f/'driver.stdout'),False,True) and launch.AddOpenFileAction(2,str(f/'driver.stderr'),False,True)
 error=lldb.SBError();start=time.time_ns();process=target.Launch(launch,error);assert error.Success();pid=process.GetProcessID();receipt.update(pid=pid,driver=plan['driver'],driver_sha256=plan['driver_sha256']);write()
 mapping=pathlib.Path('/tmp')/('perf-'+str(pid)+'.map')
 while not(mapping.exists()and mapping.stat().st_mtime_ns>=start and all(name in mapping.read_text()for name in plan['functions'])):
  if process.GetState()==lldb.eStateStopped:assert process.Continue().Success()
  assert process.GetState()!=lldb.eStateExited
  time.sleep(.01)
 assert process.Stop().Success()
 while process.GetState()!=lldb.eStateStopped:time.sleep(.01)
 entries={}
 for line in mapping.read_text().splitlines():
  address,size,name=line.split(maxsplit=2)
  if name in plan['functions']:entries[name]=(int(address,16),int(size,16))
 assert set(entries)==set(plan['functions']);(f/'deriche.perf.map').write_text(mapping.read_text())
 for name,(address,size)in entries.items():
  bp=target.BreakpointCreateByAddress(address);assert bp.GetNumLocations()==1
  receipt['hits'][str(bp.GetID())]={'name':name,'address':address,'size':size,'hit':False};bp.SetScriptCallbackFunction('trace_route.hit')
 for name in ['prepare_numeric_generator','numeric_array_owner']:
  bp=target.BreakpointCreateByRegex(name+'$');assert bp.GetNumLocations()>0
  receipt['hits'][str(bp.GetID())]={'name':name,'locations':bp.GetNumLocations(),'hit':False};bp.SetScriptCallbackFunction('trace_route.hit')
 begin=target.BreakpointCreateByRegex('begin_numeric_views$');assert begin.GetNumLocations()==1
 receipt['begin_breakpoint']=begin.GetID();write();debugger.SetAsync(False);assert process.Continue().Success()
 if process.GetState()==lldb.eStateExited:
  receipt.update(begin_hit=False,driver_exit_code=process.GetExitStatus(),complete=process.GetExitStatus()==0);write();assert receipt["complete"];print(json.dumps(receipt),flush=True);return
 receipt["begin_hit"]=True
 assert process.GetState()==lldb.eStateStopped,process.GetState()
 thread=process.GetSelectedThread();frame=thread.GetFrameAtIndex(0);begin.SetEnabled(False)
 symbol=frame.GetSymbol();lo=symbol.GetStartAddress().GetLoadAddress(target);hi=symbol.GetEndAddress().GetLoadAddress(target);assert lo<=frame.GetPC()<hi
 receipt['begin_symbol']={'name':frame.GetFunctionName(),'start':lo,'end':hi};write()
 for index in range(2000):
  frame=thread.GetFrameAtIndex(0);pc=frame.GetPC()
  if not lo<=pc<hi:break
  instructions=target.ReadInstructions(frame.GetPCAddress(),1);assert instructions.GetSize()==1;inst=instructions.GetInstructionAtIndex(0)
  receipt['preflight_trace'].append({'offset':pc-lo,'mnemonic':inst.GetMnemonic(target),'operands':inst.GetOperands(target)})
  thread.StepInstruction(True);assert process.GetState()==lldb.eStateStopped
 else:raise AssertionError('preflight trace step bound exhausted')
 receipt['first_preflight_returned']=True;receipt['preflight_trace_steps']=len(receipt['preflight_trace']);write()
 assert process.Continue().Success();assert process.GetState()==lldb.eStateExited,process.GetState()
 receipt.update(driver_exit_code=process.GetExitStatus(),complete=process.GetExitStatus()==0);write();assert receipt['complete'];print(json.dumps(receipt),flush=True)
