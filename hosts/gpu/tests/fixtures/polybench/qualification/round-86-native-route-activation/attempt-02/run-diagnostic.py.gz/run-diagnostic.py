from pathlib import Path
import importlib.util,json,subprocess,time
root=Path.cwd();f=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(s);s.loader.exec_module(b)
p=b.read(f/'plan.json');fp=b.compiler_fingerprint();assert fp==p['compiler_fingerprint']and b.digest(p['driver'])==p['driver_sha256']and all(b.digest(root/n)==v for n,v in p['source_sha256'].items())
assert b.command(['git','status','--porcelain'])==''and b.command(['git','ls-remote','origin','refs/heads/codex/polybench-native-matrices']).split()[0]==b.command(['git','rev-parse','HEAD'])
_,cases=b.protocol();b.write(f/'deriche-inputs.json',cases['deriche']['inputs']);cmd=['xcrun','lldb','-x','-b','-o','settings set target.disable-aslr false','-o','command script import '+str(f/'trace_route.py'),'-o','script trace_route.run()'];started=time.monotonic()
with(f/'debugger.log').open('x')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
b.write(f/'debugger-exit.json',{'command':cmd,'exit_code':r.returncode,'wall_seconds':time.monotonic()-started,'performance_observations':0});assert r.returncode==0
r=b.read(f/'route-trace.json');assert r['complete']and r['driver_exit_code']==0
out=json.loads((f/'driver.stdout').read_text().strip().splitlines()[-1]);assert out['status']=='ok'and out['samples_seconds']==[]and out['report']==out['residence_report']==b.read(p['reference_gate'])['cases']['deriche']['actors']['candidate']['execution_report']
r.update(warmup_validation=b.validate(out['values'],cases['deriche']['expected']),final_validation=b.validate(out['final_values'],cases['deriche']['expected']),residence_calls=out['residence_calls'],source_unchanged=b.compiler_fingerprint()==fp,frozen_counters_match=True)
b.write(f/'route-trace.json',r);assert r['source_unchanged'];print(json.dumps({'hits':r['hits'],'preflight_steps':r.get('preflight_trace_steps',0),'preflight_trace':r['preflight_trace'],'complete':True,'performance_observations':0}),flush=True)
