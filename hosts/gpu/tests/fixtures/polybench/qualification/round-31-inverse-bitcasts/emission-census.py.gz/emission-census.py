import importlib.util,json,pathlib,re,subprocess
folder=pathlib.Path(__file__).resolve().parent
root=pathlib.Path('/Users/cim310/.codex/worktrees/polybench-pr1000/mech')
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
protocol,cases=b.protocol();q=b.read(folder/'qualification.json')
assert b.compiler_fingerprint()==q['compiler_fingerprint']
assert b.digest(folder/'bitcast-driver')==q['driver_sha256']
objects=folder/'objects';objects.mkdir(exist_ok=True)
old=folder.parent/'native-attribution/objects'
r={'scope':'Actual checked Object emission for optimization15 only; no timing observations and no holdout performance.','compiler_fingerprint':q['compiler_fingerprint'],'driver_sha256':q['driver_sha256'],'cases':{}}
for name in protocol['optimization']:
 inputs=folder/f'{name}-inputs.json';b.write(inputs,cases[name]['inputs'])
 obj=objects/f'{name}.o'
 command=[str(folder/'bitcast-driver'),str(b.FIXTURE/f'{name}.mec'),str(inputs),'0',f'emit-object={obj}']
 process=subprocess.run(command,text=True,capture_output=True,check=True,timeout=180)
 result=json.loads(process.stdout.strip().splitlines()[-1]);assert result['status']=='ok' and result['mode']=='emit-object'
 metadata=b.read(obj.with_suffix('.metadata.json'))
 asm=subprocess.run(['/Library/Developer/CommandLineTools/usr/bin/llvm-objdump','--disassemble','--no-show-raw-insn',str(obj)],text=True,capture_output=True,check=True).stdout
 disasm=obj.with_suffix('.disasm.txt');disasm.write_text(asm)
 root_cleanup=metadata['compiled_cfg_cleanup']
 numeric=[{'symbol':f['symbol'],'removed':f['cleanup']['inverse_bitcasts_removed'],'code_bytes':f['code_bytes']} for f in metadata['compiled_numeric_functions']]
 row={'root_removed':root_cleanup['inverse_bitcasts_removed'],'numeric_functions':numeric,'total_removed':root_cleanup['inverse_bitcasts_removed']+sum(f['removed'] for f in numeric),'code_bytes':metadata['code_bytes'],'object_sha256':b.digest(obj),'metadata_sha256':b.digest(obj.with_suffix('.metadata.json')),'disassembly_sha256':b.digest(disasm),'object_executed':False}
 if (old/f'{name}.metadata.json').exists():
  before=b.read(old/f'{name}.metadata.json')
  row['base30_code_bytes']=before['code_bytes'];row['code_bytes_delta']=row['code_bytes']-before['code_bytes']
  row['base30_root_instructions']=before['compiled_cfg_cleanup']['after_instructions'];row['candidate_root_instructions']=root_cleanup['after_instructions']
 r['cases'][name]=row;b.write(folder/'emission-census.json',r)
 print(name,'removed',row['total_removed'],'root',row['root_removed'],'code_bytes',row['code_bytes'],'delta',row.get('code_bytes_delta'),flush=True)
r['total_removed']=sum(c['total_removed'] for c in r['cases'].values());r['complete']=len(r['cases'])==15
assert b.compiler_fingerprint()==q['compiler_fingerprint'];b.write(folder/'emission-census.json',r)
