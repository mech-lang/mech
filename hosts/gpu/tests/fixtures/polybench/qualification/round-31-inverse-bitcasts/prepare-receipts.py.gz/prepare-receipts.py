import gzip,hashlib,importlib.util,json,re,shutil
from pathlib import Path
root=Path('/Users/cim310/.codex/worktrees/polybench-pr1000/mech');folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;q=b.read(folder/'qualification.json');checkpoint=b.read(folder/'source-checkpoint.json');probe=b.read(folder/'training-probe.json');profile_root=folder.parent/'native-attribution';profile=b.read(profile_root/'training-profile.json');rule=b.read(folder/'selection-policy.json');census=b.read(folder/'emission-census.json')
assert b.compiler_fingerprint()==q['compiler_fingerprint']==checkpoint['compiler_fingerprint']==probe['compiler_fingerprint']==census['compiler_fingerprint']
assert b.digest(folder/'bitcast-driver')==q['driver_sha256']==probe['driver_sha256']==census['driver_sha256']
assert len(probe['cases'])==15 and all(c['all_unrelated_counters_match'] and all(v==0 for v in c['execution_counter_deltas_vs_base30'].values()) for c in probe['cases'].values())
assert probe['summary']['geomean_raw_speedup_vs_accepted29']>1 and probe['summary']['geomean_raw_speedup_vs_base30']>1
assert len(q['checks'])==7 and all(c['exit_code']==0 for c in q['checks']) and q['tests']==582
assert census['complete'] and census['total_removed']==84
assert profile['partition']=='optimization' and profile['compiler_fingerprint']==b.read(p/'round-30-frozen.json')['compiler_fingerprint']
assert profile['driver_sha256']==b.read(p/'round-30-frozen.json')['driver_sha256']
verification=b.read(profile_root/'jit-object-byte-verification.json')
sites=[s for c in verification['cases'].values() for f in c['functions'] for s in f['sampled_hot_sites']]
assert len(sites)==136 and all(s['instruction_identical'] and s['surrounding_68_bytes_identical'] for s in sites)
selection={'selected_at':b.utc(),'prospective_rule':rule,'probe_sha256':b.digest(folder/'training-probe.json'),'emission_census_sha256':b.digest(folder/'emission-census.json'),'selected_compiler_fingerprint':q['compiler_fingerprint'],'selected_driver_sha256':q['driver_sha256'],'decision':'Select unchanged qualified inverse scalar bitcast cleanup on ordered-sum source for frozen formal both-set evaluation','summary':probe['summary'],'holdout_performance_used':False}
b.write(folder/'training-selection.json',selection)
dest=p/'qualification/round-31-inverse-bitcasts';dest.mkdir(parents=True,exist_ok=False)
def archive(path,name):
 raw=path.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);assert not out.exists();out.write_bytes(gzip.compress(raw,mtime=0));return {'path':str(out.relative_to(p)),'sha256':hashlib.sha256(raw).hexdigest(),'compressed_sha256':b.digest(out)}
archives={}
for path in sorted(folder.rglob('*')):
 if not path.is_file() or '__pycache__' in path.parts or path.name=='bitcast-driver' or path.name=='current-work.json' or path.name.endswith('-inputs.json'):continue
 name=str(path.relative_to(folder));archives[name]=archive(path,name)
for path in sorted(profile_root.rglob('*')):
 if not path.is_file() or '__pycache__' in path.parts or path.name=='object-driver' or path.name.endswith('-inputs.json') or 'profiles' in path.relative_to(profile_root).parts:continue
 name='native-attribution/'+str(path.relative_to(profile_root));archives[name]=archive(path,name)
passed=set();logs=[]
for c in q['checks']:
 names=re.findall(r'^test (.+?) \.\.\. ok$',(folder/c['name']).read_text(),re.M);passed.update(names);a=archives[c['name']];logs.append({'log':a['path'],'log_sha256':a['sha256'],'compressed_sha256':a['compressed_sha256'],'passed_tests':len(names)})
assert len(passed)==582
for name,item in profile['analysis'].items():
 for key,sha_key in [('raw_sample','compressed_sample_sha256'),('jit_map','compressed_jit_map_sha256')]:
  src=profile_root/item[key];out=p/'profiles/round-31-native-attribution'/src.name;out.parent.mkdir(parents=True,exist_ok=True);assert not out.exists();shutil.copy2(src,out);assert b.digest(out)==item[sha_key];item[key]=str(out.relative_to(p))
profile['scope']='Unpromoted round30 optimization-only profiling selected inverse scalar bitcast cleanup. Actual unchanged frozen JIT ranges are resolved from same-process maps; all sampled hot-site instructions and surrounding68-byte windows match real checked Objects. No profile/debug timings enter scores.'
for name,value in [('training-profile',profile),('training-probe',probe),('training-selection',selection),('emission-census',census)]:b.write(p/f'round-31-{name}.json',value)
b.write(p/'round-31-training-qualification.json',{'schema':'mech.polybench.training-qualification.v1','created_at':b.utc(),'scope':'Current candidate correctness/features before formal timing. Selected from round30 optimization-only full checked JIT profiles, real Object emission and all15 optimization replay. No holdout performance used.','source_parent':checkpoint['source_commit'],'compiler_fingerprint':q['compiler_fingerprint'],'driver_sha256':q['driver_sha256'],'versions':checkpoint['versions'],'total_unique_selected_checks':582,'checks':q['checks'],'logs':logs,'development_archives':archives,'invariants':[
 'All30 unchanged ports match29482 finite C live-outs in original/decoded artifacts and emit Objects.',
 'Only scalar lossless bitcast round trips with equal flags and matching original/result types are aliased to the existing source SSA value. Vector reinterpretations and mismatched flags remain. Live inner uses remain; no FP arithmetic, memory operation, branch, source error, work debit, observation or publication is moved or removed.',
 'Direct JIT tests preserve arbitrary F32/F64 bits, quiet/signaling NaN payloads, signedzero, live word stores, exact unfused multiply/add order and reached error paths. Existing direct scalar Bool/U64/I64/F64 machinery remains maintained.',
 'The same checked native Program path, exact current owners, private witness construction, finite resource admission, source prices, replay, error paths and atomic publication remain. All execution counters exactly match base30 on all15 optimization programs.',
 'Before source changes,1306 canonical execution samples included970 resolved JIT self samples. Profile selection used only the five largest optimization medians, covering75.99% of optimization summed medians. Actual unchanged frozen JIT bytes were read under LLDB and every136 sampled hot-site instruction/window matched the checked Object emission. No simplified/unchecked diagnostic is used as a benchmark.',
 'The current real Object emission removes84 inverse pairs across six optimization programs, including24 in Deriche root. Objects are inspected; linked Object execution is not claimed.',
 'The developer example can export a real checked Object and metadata before execution. Its default benchmark path is unchanged. Analyzer perf-map support preserves previous analyses and is validated against real captures and range boundaries.',
 'IR390/work156/ABI47 retain the same exact source bill and144-byte root/80-byte numeric frame. Existing ordered matrix sum source from unpromoted30 remains included.',
 'No benchmark-name dispatch, port/input/C/flags/tolerance/limit/split/objective/timing-boundary changes or holdout diagnosis. Source and driver are committed and frozen before both formal sets. Promotion requires both Mech/C scores strictly improve versus accepted29.'
 ],'development_failures':[
 'Initial focused test build found an unused Type import; removed before582 checks. Original failed build log retained.',
 'Initial profile collector expected the wrong entry symbol. The completed full checked Seidel capture was retained/audited, the symbol assertion was corrected and remaining captures ran once. Original failed collector and logs retained.'
 ],'limitations':['CPU MINI/F64 and Object emission qualified; linked Object execution, larger datasets, accelerators, full compression/AOT and a fresh application remain unqualified.','Per-case training regressions and all actor observations are retained. Training probe is not formal performance acceptance.']})
assert b.compiler_fingerprint()==q['compiler_fingerprint']
print(json.dumps({'checks':582,'fingerprint':q['compiler_fingerprint'],'driver':q['driver_sha256'],'training_raw_speedup_vs_accepted29':probe['summary']['geomean_raw_speedup_vs_accepted29'],'training_raw_speedup_vs_base30':probe['summary']['geomean_raw_speedup_vs_base30'],'profile_samples':profile['execution_samples'],'jit_samples':profile['jit_self_samples'],'verified_hot_sites':len(sites),'archives':len(archives)}))
