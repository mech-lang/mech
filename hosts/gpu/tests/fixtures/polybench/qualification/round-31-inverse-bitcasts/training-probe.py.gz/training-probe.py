import importlib.util,json,pathlib,statistics,subprocess
root=pathlib.Path('/Users/cim310/.codex/worktrees/polybench-pr1000/mech');folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
protocol,cases=b.protocol();checkpoint=b.read(folder/'source-checkpoint.json');q=b.read(folder/'qualification.json')
assert b.compiler_fingerprint()==checkpoint['compiler_fingerprint']==q['compiler_fingerprint']
assert q['tests']==582 and len(q['checks'])==7 and all(c['exit_code']==0 for c in q['checks'])
actors={'accepted29':folder.parents[1]/'round-29/transpose/transpose-only-checkpoint/transpose-driver','base30':folder.parents[1]/'round-30/sums/sum-driver','bitcast':folder/'bitcast-driver'}
assert b.digest(actors['accepted29'])==b.read(b.FIXTURE/'round-29-frozen.json')['driver_sha256']
assert b.digest(actors['bitcast'])==q['driver_sha256']
assert b.digest(actors['base30'])==b.read(b.FIXTURE/'round-30-frozen.json')['driver_sha256']
def counters(report):
 prefix='NativeProgramExecutionReport { ';assert report.startswith(prefix) and report.endswith(' }')
 pairs=[s.split(': ') for s in report[len(prefix):-2].split(', ')];assert all(len(p)==2 and p[1].isdecimal() for p in pairs)
 return {k:int(v) for k,v in pairs}
r={'schema':'mech.polybench.training-probe.v1','created_at':b.utc(),'scope':'All15 optimization programs only; seven samples per sequential actor with rotating actor order. No holdout performance. Full original source prices/replay retained; all counter deltas preserved.','compiler_fingerprint':b.compiler_fingerprint(),'source_parent':b.command(['git','rev-parse','HEAD']),'driver_sha256':q['driver_sha256'],'samples_per_actor':7,'cases':{}}
for index,name in enumerate(protocol['optimization']):
 config=folder/f'{name}-inputs.json';b.write(config,cases[name]['inputs']);observations={};order=list(actors);order=order[index%3:]+order[:index%3]
 for label in order:
  driver=actors[label];process=subprocess.run([str(driver),str(b.FIXTURE/f'{name}.mec'),str(config),'7'],text=True,capture_output=True,check=True,timeout=180)
  result=json.loads(process.stdout.strip().splitlines()[-1]);assert result['status']=='ok',result
  observations[label]={'driver_sha256':b.digest(driver),'samples_seconds':result['samples_seconds'],'median_seconds':statistics.median(result['samples_seconds']),'warmup_validation':b.validate(result['values'],cases[name]['expected']),'execution_report':result['report'],'execution_counters':counters(result['report'])}
 ratio=observations['accepted29']['median_seconds']/observations['bitcast']['median_seconds']
 base_ratio=observations['base30']['median_seconds']/observations['bitcast']['median_seconds']
 delta={k:observations['bitcast']['execution_counters'][k]-v for k,v in observations['accepted29']['execution_counters'].items()}
 ignore={'work','comparison_work','visits','transport_bytes'}
 assert all(v==0 for k,v in delta.items() if k not in ignore),(name,delta)
 base_delta={k:observations['bitcast']['execution_counters'][k]-v for k,v in observations['base30']['execution_counters'].items()}
 assert all(v==0 for v in base_delta.values()),(name,'lossless IR cleanup changed counters',base_delta)
 r['cases'][name]={'source_sha256':b.digest(b.FIXTURE/f'{name}.mec'),'actors':observations,'speedup_vs_accepted29':ratio,'speedup_vs_base30':base_ratio,'execution_counter_deltas_vs_base30':base_delta,'execution_counter_deltas':delta,'all_unrelated_counters_match':True};b.write(folder/'training-probe.json',r)
 print(name,'vs29',round(ratio,5),'x','vs30',round(base_ratio,5),'x','candidate_ms',round(observations['bitcast']['median_seconds']*1000,6),flush=True)
ratios=[c['speedup_vs_accepted29'] for c in r['cases'].values()]
r['summary']={'count':15,'geomean_raw_speedup_vs_base30':b.geomean([c['speedup_vs_base30'] for c in r['cases'].values()]),'geomean_raw_speedup_vs_accepted29':b.geomean(ratios),'regressions_over_five_percent':sum(x<1/1.05 for x in ratios),'sum_candidate_median_seconds':sum(c['actors']['bitcast']['median_seconds'] for c in r['cases'].values()),'sum_reference_median_seconds':sum(c['actors']['accepted29']['median_seconds'] for c in r['cases'].values())}
assert b.compiler_fingerprint()==checkpoint['compiler_fingerprint'];r['completed_at']=b.utc();b.write(folder/'training-probe.json',r);print(json.dumps(r['summary']),flush=True)
