import collections,gzip,hashlib,importlib.util,json,math,pathlib,subprocess,time,statistics
root=pathlib.Path('/Users/cim310/.codex/worktrees/polybench-pr1000/mech')
folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('benchmark',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE
checkpoint=b.read(folder/'source-checkpoint.json');training=b.read(p/'round-29-optimization.json')
assert b.compiler_fingerprint()==checkpoint['compiler_fingerprint']
driver=folder.parents[1]/'round-29/transpose/transpose-only-checkpoint/transpose-driver';assert b.digest(driver)==checkpoint['driver_sha256']==training['candidate']['driver_sha256']
f={'source_commit':checkpoint['source_commit'],'compiler_fingerprint':checkpoint['compiler_fingerprint'],'driver_sha256':b.digest(driver)}
protocol,cases=b.protocol()
prior_profile=b.read(p/'round-28-training-profile.json')
prior_folder=folder.parents[1]/'round-28/generators'
seconds={n:training['runs'][n]['comparisons']['kernel']['mech']['median_seconds'] for n in protocol['optimization']}
selected=sorted(seconds,key=seconds.get,reverse=True)[:5]
receipt={'schema':'mech.polybench.training-profile-collection.v1','created_at':b.utc(),'source_commit':f['source_commit'],'compiler_fingerprint':f['compiler_fingerprint'],'driver_sha256':f['driver_sha256'],'partition':'optimization','selection':'The five largest optimization-only medians from accepted round29; no holdout measurement, profile or per-case selection. No source changes; accepted source and driver identity checked.','timing_receipt_sha256':b.digest(p/'round-29-optimization.json'),'optimization_sum_median_seconds':sum(seconds.values()),'profiled_sum_median_seconds':sum(seconds[n] for n in selected),'profiled_fraction_of_training_sum':sum(seconds[n] for n in selected)/sum(seconds.values()),'method':'Call count estimates driver/cache-flush overhead from preceding completed optimization profiles and adds each current frozen kernel median, targeting16 wall seconds with margin for the fixed sample window. Counts do not enter scores. One sequential driver per case; macOS sample PID 6 1 after a 1s startup delay; any startup stacks are excluded from canonical execute attribution. Reported attribution includes only canonical execute stacks; parsing, JIT, input import, cache flush and serialization are excluded by stack. Profiled sample times do not enter benchmark scores.','cases':{}}
for name in selected:
 config=folder/f'{name}-inputs.json';b.write(config,cases[name]['inputs'])
 # Estimate only process residence, never a benchmark score: previous
 # wall-per-call minus its measured kernel median gives cache-flush/driver
 # overhead. Add the current frozen kernel median and target16 wall seconds.
 overheads=[]
 for old_name,previous in prior_profile['cases'].items():
  elapsed=previous['process_wall_seconds']
  overheads.append(max(0.000001,elapsed/previous['timed_checked_calls']-previous['profile_median_seconds']))
 overhead=statistics.median(overheads)
 estimated=overhead+seconds[name]
 count=math.ceil(16/estimated)
 prior_wall={'profile_receipt_sha256':b.digest(p/'round-28-training-profile.json'),'median_estimated_non_kernel_seconds_per_call':overhead,'current_frozen_kernel_median_seconds':seconds[name],'target_process_wall_seconds':16}
 argv=[str(driver),str(p/f'{name}.mec'),str(config),str(count)]
 with (folder/f'{name}-profile.json').open('w') as out,(folder/f'{name}-profile.stderr').open('w') as err:
  process_start=time.monotonic()
  child=subprocess.Popen(argv,stdout=out,stderr=err)
  time.sleep(1)
  assert child.poll() is None,(name,'driver ended before sample')
  raw=folder/f'{name}.sample.txt'
  sampling=subprocess.run(['/usr/bin/sample',str(child.pid),'6','1','-file',str(raw)],text=True,capture_output=True,check=True)
  (folder/f'{name}-sample.log').write_text(sampling.stdout+sampling.stderr)
  code=child.wait(timeout=600)
 assert code==0,(name,code)
 result=json.loads((folder/f'{name}-profile.json').read_text().strip().splitlines()[-1])
 assert result['status']=='ok',result
 validation=b.validate(result['values'],cases[name]['expected'])
 receipt['cases'][name]={'command':argv,'source_sha256':b.digest(p/f'{name}.mec'),'warmup_validation':validation,'execution_report':result['report'],'timed_checked_calls':count,'count_selection_reference':prior_wall,'process_wall_seconds':time.monotonic()-process_start,'profile_median_seconds':__import__('statistics').median(result['samples_seconds']),'duration_seconds':6,'nominal_sample_interval_ms':1,'raw_sample_sha256':b.digest(raw)}
 b.write(folder/'profile-collection.json',receipt)
 print(name,'profiled and validated',validation['count'],'live-outs',flush=True)
demangler=pathlib.Path('/private/tmp/mech-polybench-optimization/round-02/profile-tools/target/release/polybench-profile-demangle')
assert demangler.is_file(),demangler
subprocess.run(['python3',str(root/'scripts/analyze-polybench-samples.py'),'--demangler',str(demangler),'--output',str(folder/'profile-analysis.json'),*[str(folder/f'{n}.sample.txt') for n in selected]],check=True)
analysis=b.read(folder/'profile-analysis.json')
receipt['analysis']={}
raw_dest=folder/'profiles';raw_dest.mkdir(exist_ok=False)
weighted=collections.defaultdict(float)
for name in selected:
 raw=folder/f'{name}.sample.txt';dest=raw_dest/f'{name}.sample.txt.gz';dest.write_bytes(gzip.compress(raw.read_bytes(),mtime=0))
 row=analysis[raw.name]
 assert row['sample_sha256']==b.digest(raw)
 row.update({'raw_sample':str(dest.relative_to(folder)),'compressed_sample_sha256':b.digest(dest),'profiled_case_fraction_of_optimization_sum':seconds[name]/sum(seconds.values())})
 receipt['analysis'][name]=row
 for a in row['action_categories']:weighted[a['name']]+=seconds[name]*a['percent']/100
receipt['weighted_profiled_action_categories']=[{'name':n,'fraction_of_profiled_time':s/receipt['profiled_sum_median_seconds'],'estimated_seconds_in_training_sum':s} for n,s in sorted(weighted.items(),key=lambda x:-x[1])]
receipt['execution_samples']=sum(r['execution_samples'] for r in receipt['analysis'].values())
receipt['analyzer_sha256']=b.digest(root/'scripts/analyze-polybench-samples.py')
receipt['demangler_sha256']=b.digest(demangler)
assert b.compiler_fingerprint()==f['compiler_fingerprint']
b.write(folder/'training-profile.json',receipt)
print('profile receipt',receipt['execution_samples'],'execution samples','coverage',receipt['profiled_fraction_of_training_sum'],flush=True)
