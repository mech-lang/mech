import gzip,hashlib,importlib.util,json,re,shutil
from pathlib import Path
root=Path('/Users/cim310/.codex/worktrees/polybench-pr1000/mech');folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;q=b.read(folder/'qualification.json');checkpoint=b.read(folder/'source-checkpoint.json');probe=b.read(folder/'training-probe.json');profile=b.read(folder.parent/'profile/training-profile.json');rule=b.read(folder/'selection-policy.json')
assert b.compiler_fingerprint()==q['compiler_fingerprint']==checkpoint['compiler_fingerprint']==probe['compiler_fingerprint']
assert b.digest(folder/'sum-driver')==q['driver_sha256']==probe['driver_sha256']
assert len(probe['cases'])==15 and all(c['all_unrelated_counters_match'] for c in probe['cases'].values())
assert probe['summary']['geomean_raw_speedup_vs_accepted29']>1.0
assert len(q['checks'])==7 and all(c['exit_code']==0 for c in q['checks']) and q['tests']==579
assert profile['partition']=='optimization' and profile['compiler_fingerprint']==b.read(p/'round-29-frozen.json')['compiler_fingerprint']
selection={'selected_at':b.utc(),'prospective_rule':rule,'probe_sha256':b.digest(folder/'training-probe.json'),'selected_compiler_fingerprint':q['compiler_fingerprint'],'selected_driver_sha256':q['driver_sha256'],'decision':'Select unchanged qualified ordered-sum candidate for frozen formal both-set evaluation','summary':probe['summary'],'holdout_performance_used':False}
b.write(folder/'training-selection.json',selection)
dest=p/'qualification/round-30-sums';dest.mkdir(parents=True,exist_ok=False)
def archive(path, name):
 raw=path.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);assert not out.exists();out.write_bytes(gzip.compress(raw,mtime=0));return {'path':str(out.relative_to(p)),'sha256':hashlib.sha256(raw).hexdigest(),'compressed_sha256':b.digest(out)}
archives={}
for path in sorted(folder.iterdir()):
 if path.is_file() and path.suffix in ('.log','.json','.py','.patch') and path.name!='current-work.json' and not path.name.endswith('-inputs.json'):
  archives[path.name]=archive(path,path.name)
for name in ['profile-current.py','profiling.log','profile-analysis.json','profile-collection.json','source-checkpoint.json','training-next-action.json']:
 archives['baseline-profile/'+name]=archive(folder.parent/'profile'/name,'baseline-profile/'+name)
passed=set();logs=[]
for c in q['checks']:
 logtext=(folder/c['name']).read_text();names=re.findall(r'^test (.+?) \.\.\. ok$',logtext,re.M);passed.update(names);a=archives[c['name']];logs.append({'log':a['path'],'log_sha256':a['sha256'],'compressed_sha256':a['compressed_sha256'],'passed_tests':len(names)})
assert len(passed)==579
for name,item in profile['analysis'].items():
 src=folder.parent/'profile'/item['raw_sample'];out=p/'profiles/round-30-sums'/src.name;out.parent.mkdir(parents=True,exist_ok=True);assert not out.exists();shutil.copy2(src,out);assert b.digest(out)==item['compressed_sample_sha256'];item['raw_sample']=str(out.relative_to(p))
profile['scope']='Accepted29 optimization-only profiling used to select this compiler family. Profiles precede candidate changes and do not enter timing scores.'
b.write(p/'round-30-training-profile.json',profile);b.write(p/'round-30-training-probe.json',probe);b.write(p/'round-30-training-selection.json',selection)
b.write(p/'round-30-training-qualification.json',{'schema':'mech.polybench.training-qualification.v1','created_at':b.utc(),'scope':'Current candidate correctness/feature qualification before formal timing; source family selected from accepted29 optimization-only profiles and all15 optimization replay. No holdout performance used.','source_parent':checkpoint['source_commit'],'compiler_fingerprint':q['compiler_fingerprint'],'driver_sha256':q['driver_sha256'],'versions':checkpoint['versions'],'total_unique_selected_checks':579,'checks':q['checks'],'logs':logs,'development_archives':archives,'invariants':[
 'All30 unchanged ports match29482 finite C live-outs in original/decoded artifacts and emit Objects.',
 'Exact sealed rank2 F64 SumRows/SumColumns use shared resident geometry, the existing checked numeric-operation loan and maintained source cost envelope. Literal and dynamic axes are checked against the genuine current source owner; pure operation metadata is independently rederived on images.',
 'Every accumulator starts with positive zero and visits original terms in order. SIMD lanes compute independent outputs; no reassociation, horizontal tree or fused operation is introduced. Empty reduced axes produce typed zero. Input NaNs retain ordinary payload/error behavior through replay; generated NaNs, infinities, cancellation, overflow and signedzero match ordinary bits.',
 'The same initialized private result storage, immutable input pins, exact argument/frame/shadow/site/shape/schema checks, pointer spans/alignment/overflow/disjointness, finite work/memory/node coexistence, complete source fees,128x general replay and atomic publication remain mandatory. Row/column sums add explicit per-input native term funding.',
 'Original/decoded/restored fixed/dynamic empty/vector/rectangular shapes and odd SIMD tails are covered. Existing finite byte/node caps, physical byte refusal, malformed finish frames, callback interleaving, source errors, old output aliases, cleanup and retry tests include both sum axes.',
 'Shared unary span checking is used by transpose and sums. Existing transpose, elementwise, product, scalar, phase, generator and compression checks remain selected. No generic per-cell dispatch or allocation. IR389/work156/ABI47 preserve the144-byte root frame,80-byte numeric frame and original scalar prefix.',
 'All unrelated optimization replay counters match accepted29. Work/comparison/visit/transport deltas remain in full; conservative source envelopes are charged and ordinary prices/replay are retained.',
 'No benchmark-name dispatch, port/input changes, C changes, tolerances/limits/split/objective changes or holdout diagnosis. Commit and freeze source+driver before both formal sets; promotion requires both scores strictly improve vs accepted29.'
 ],'limitations':['Rank2 F64 sums only; other numeric families retain their maintained source paths. Input NaNs conservatively retain ordinary execution.','CPU MINI/F64, source correctness and Object emission are qualified; larger datasets, accelerators, linked Object execution, full compression/AOT and a fresh application remain unqualified.','This qualification is not a performance acceptance result.']})
assert b.compiler_fingerprint()==q['compiler_fingerprint']
print(json.dumps({'checks':579,'fingerprint':q['compiler_fingerprint'],'driver':q['driver_sha256'],'training_raw_speedup':probe['summary']['geomean_raw_speedup_vs_accepted29'],'profile_samples':profile['execution_samples'],'archives':len(archives)}))
