import gzip,hashlib,importlib.util,json,re
from pathlib import Path
root=Path('/Users/cim310/.codex/worktrees/polybench-pr1000/mech');folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;common=folder/'common-loan';probe=b.read(common/'training-probe.json');rule=b.read(common/'selection-policy.json')
keep=probe['summary']['transpose_only']['geomean_raw_speedup']>1.0
chosen=common if keep else folder/'transpose-only-checkpoint';driver=chosen/('common-loan-driver' if keep else 'transpose-driver')
q=b.read(chosen/'qualification.json');checkpoint=b.read(chosen/'source-checkpoint.json')
assert b.compiler_fingerprint()==q['compiler_fingerprint']==checkpoint['compiler_fingerprint']
assert b.digest(driver)==q['driver_sha256']
assert len(probe['cases'])==15 and probe['completed_at']
assert all(all(v==0 for v in c['execution_counter_deltas']['transpose_only'].values()) for c in probe['cases'].values())
actor='common_loan' if keep else 'transpose_only'
assert all(c['actors'][actor]['driver_sha256']==q['driver_sha256'] for c in probe['cases'].values())
raw=b.geomean([c['actors']['accepted27']['median_seconds']/c['actors'][actor]['median_seconds'] for c in probe['cases'].values()]);assert raw>1.0
checks=q['checks'];assert len(checks)==7 and all(c['exit_code']==0 for c in checks)
assert sum(sum(c['passed_tests']) for c in checks)==576
selection={'selected_at':b.utc(),'prospective_rule':rule,'four_actor_probe_sha256':b.digest(common/'training-probe.json'),'decision':'Keep shared owned numeric-loan enum' if keep else 'Restore qualified transpose-only checkpoint','selected_compiler_fingerprint':q['compiler_fingerprint'],'selected_driver_sha256':q['driver_sha256'],'selected_probe_actor':actor,'selected_raw_geomean_speedup_vs_accepted27':raw,'probe_summary':probe['summary'],'scope':'Selection uses all15 optimization cases only. All regressions and raw controls retained. No holdout performance used.'}
b.write(folder/'training-selection.json',selection)
dest=p/'qualification/round-29-transpose';dest.mkdir(parents=True,exist_ok=False)
def archive(path):
 name=path.relative_to(folder);raw=path.read_bytes();out=dest/(str(name)+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));return {'path':str(out.relative_to(p)),'sha256':hashlib.sha256(raw).hexdigest(),'compressed_sha256':b.digest(out)}
archives={}
for path in sorted(folder.rglob('*')):
 if path.is_file() and path.suffix in ('.log','.json','.py','.patch','.rs') and path.name!='current-work.json' and not path.name.endswith('-inputs.json'):
  archives[str(path.relative_to(folder))]=archive(path)
passed=set();logs=[]
logroot=common if keep else folder
for c in checks:
 raw=(logroot/c['name']).read_text();names=re.findall(r'^test (.+?) \.\.\. ok$',raw,re.M);passed.update(names);a=archives[str((logroot/c['name']).relative_to(folder))];logs.append({'log':a['path'],'log_sha256':a['sha256'],'compressed_sha256':a['compressed_sha256'],'passed_tests':len(names)})
assert len(passed)==576
b.write(p/'round-29-training-probe.json',probe);b.write(p/'round-29-training-selection.json',selection)
b.write(p/'round-29-training-qualification.json',{'schema':'mech.polybench.training-qualification.v1','created_at':b.utc(),'scope':'Selected current-source correctness and standalone feature qualification before formal timing. Holdout performance untouched.','source_parent':checkpoint['source_commit'],'compiler_fingerprint':q['compiler_fingerprint'],'driver_sha256':q['driver_sha256'],'versions':{'ir':388,'work':155,'abi':46},'total_unique_selected_checks':576,'checks':checks,'logs':logs,'development_archives':archives,'common_loan_selected':keep,'invariants':[
 'All30 unchanged ports match29482 finite C live-outs in original/decoded artifacts and emit Objects.',
 'Exact sealed F64 rank2 transpose uses maintained resident geometry and the existing checked numeric-matrix loan. Dynamic/fixed shape, empty and rectangular matrices share the same Cranelift copy emitter as inlined generators. Every F64 bit, including signed zero and quiet/signaling NaN payloads, is copied exactly.',
 'Original source work/factory/binding/visit fees and full128x general matrix replay credit are unchanged. Real current inputs are pinned; initialized private output, exact checked frame/shadow, overflow/alignment/disjointness, schema/key/shape, finite byte/node/work admission and atomic publication remain mandatory.',
 'Selected source/driver are exactly those qualified. Shared numeric-loan ownership, if selected, uses one owned enum instead of a duplicated marker, retains the same Box allocations/pins, rejects cross-kind callbacks and visits, preserves matching finish/fallback/cleanup/retry, and rejects return with an outstanding numeric loan.',
 'Original/decoded/restored tests cover fixed/dynamic empty/vector/rectangular axes, NaN payloads/infinities/signedzero, finite limits and physical memory/node refusal, forged frame fields, cross-kind callbacks, input/output alias preservation, cleanup and retry. Existing generator/native-map/scalar/compression checks remain selected.',
 'No benchmark-name dispatch, port/input changes, C changes, threshold changes, limit changes, split/objective changes or holdout diagnosis. Source and driver must be committed and frozen before both formal sets. Promotion requires both aggregate scores strictly improve vs accepted27.'
 ],'limitations':['F64 rank2 matrix transpose only; larger datasets, accelerators and linked Object execution remain unqualified.','No acceptance claim until the complete frozen two-set measurement and strict gate.']})
assert b.compiler_fingerprint()==q['compiler_fingerprint']
print(json.dumps({'checks':576,'fingerprint':q['compiler_fingerprint'],'driver':q['driver_sha256'],'common_loan_selected':keep,'training_raw_speedup_vs27':raw,'archives':len(archives)}))
