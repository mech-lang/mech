import importlib.util,json,pathlib,statistics,subprocess
root=pathlib.Path('/Users/cim310/.codex/worktrees/polybench-pr1000/mech');folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
protocol,cases=b.protocol();checkpoint=b.read(folder/'source-checkpoint.json')
assert b.compiler_fingerprint()==checkpoint['compiler_fingerprint']
checks=b.read(folder/'qualification-checks.json')['checks'];assert len(checks)==7 and all(c['exit_code']==0 for c in checks)
assert 'Finished' in (folder/'driver-build.log').read_text()
actors={'accepted27':folder.parent.parent/'round-27/numeric-closure/numeric-closure-driver','round28':folder.parent.parent/'round-28/generators/generator-driver','transpose':folder/'transpose-driver'}
for label,round_ in [('accepted27',27),('round28',28)]:assert b.digest(actors[label])==b.read(b.FIXTURE/f'round-{round_:02d}-frozen.json')['driver_sha256']
def counters(report):
 prefix='NativeProgramExecutionReport { ';assert report.startswith(prefix) and report.endswith(' }')
 pairs=[s.split(': ') for s in report[len(prefix):-2].split(', ')];assert all(len(p)==2 and p[1].isdecimal() for p in pairs)
 return {k:int(v) for k,v in pairs}
r={'schema':'mech.polybench.training-probe.v1','created_at':b.utc(),'scope':'All15 optimization programs only; sequential seven-sample actors. No holdout performance. New transpose source fees and helper changes retain every counter delta; unrelated execution counters must match.','compiler_fingerprint':b.compiler_fingerprint(),'source_parent':b.command(['git','rev-parse','HEAD']),'driver_sha256':b.digest(actors['transpose']),'samples_per_actor':7,'cases':{}}
for index,name in enumerate(protocol['optimization']):
 config=folder/f'{name}-inputs.json';b.write(config,cases[name]['inputs']);observations={};order=list(actors);order=order[index%3:]+order[:index%3]
 for label in order:
  driver=actors[label];process=subprocess.run([str(driver),str(b.FIXTURE/f'{name}.mec'),str(config),'7'],text=True,capture_output=True,check=True,timeout=180)
  result=json.loads(process.stdout.strip().splitlines()[-1]);assert result['status']=='ok',result
  observations[label]={'driver_sha256':b.digest(driver),'samples_seconds':result['samples_seconds'],'median_seconds':statistics.median(result['samples_seconds']),'warmup_validation':b.validate(result['values'],cases[name]['expected']),'execution_report':result['report'],'execution_counters':counters(result['report'])}
 ratios={ref:observations[ref]['median_seconds']/observations['transpose']['median_seconds'] for ref in ['accepted27','round28']}
 ignore={'work','comparison_work','visits','transport_bytes'}
 delta={ref:{k:observations['transpose']['execution_counters'][k]-v for k,v in observations[ref]['execution_counters'].items()} for ref in ratios}
 assert all(all(v==0 for k,v in d.items() if k not in ignore) for d in delta.values()),(name,delta)
 r['cases'][name]={'source_sha256':b.digest(b.FIXTURE/f'{name}.mec'),'actors':observations,'speedups':ratios,'execution_counter_deltas':delta,'all_unrelated_counters_match':True};b.write(folder/'training-probe.json',r)
 print(name,'vs27',round(ratios['accepted27'],4),'x','vs28',round(ratios['round28'],4),'x','candidate_ms',round(1000*observations['transpose']['median_seconds'],6),flush=True)
r['summary']={}
for ref in ['accepted27','round28']:
 ratios=[case['speedups'][ref] for case in r['cases'].values()]
 r['summary'][ref]={'count':15,'geomean_raw_speedup':b.geomean(ratios),'regressions_over_five_percent':sum(x<1/1.05 for x in ratios),'sum_candidate_median_seconds':sum(case['actors']['transpose']['median_seconds'] for case in r['cases'].values()),'sum_reference_median_seconds':sum(case['actors'][ref]['median_seconds'] for case in r['cases'].values())}
assert b.compiler_fingerprint()==checkpoint['compiler_fingerprint'];r['completed_at']=b.utc();b.write(folder/'training-probe.json',r);print(json.dumps(r['summary']),flush=True)
