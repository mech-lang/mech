//! A single owner for synchronous numeric banks. The discriminant is also the
//! global helper/visit guard: a second marker can never outlive the real loan.
use super::*;
use crate::native_artifact::program::runtime::collections::numeric_generator;

pub(in crate::native_artifact::program::runtime) enum NumericLoan {
    None,
    Matrix(Box<numeric_binary::Pending>),
    Generator(Box<numeric_generator::Loan>),
}
impl NumericLoan {
    #[inline]
    pub(in crate::native_artifact::program::runtime) fn is_active(&self) -> bool {
        !matches!(self, Self::None)
    }
    #[inline]
    pub(super) fn finish_helper(&self) -> Option<GlobalHelper> {
        match self {
            Self::None => None,
            Self::Matrix(_) => Some(GlobalHelper::NumericBinaryFinish),
            Self::Generator(_) => Some(GlobalHelper::NumericGeneratorFinish),
        }
    }
    pub(super) fn take_matrix(&mut self) -> Result<Box<numeric_binary::Pending>, Error> {
        match core::mem::replace(self, Self::None) {
            Self::Matrix(loan) => Ok(loan),
            other => {
                *self = other;
                Err(invalid("matrix finish without its numeric loan"))
            }
        }
    }
    pub(super) fn take_generator(&mut self) -> Result<Box<numeric_generator::Loan>, Error> {
        match core::mem::replace(self, Self::None) {
            Self::Generator(loan) => Ok(loan),
            other => {
                *self = other;
                Err(invalid("generator finish without its numeric loan"))
            }
        }
    }
}
