from pathlib import Path
R=Path('/Users/cim310/.codex/worktrees/polybench-pr1000/mech')
def edit(name,old,new):
 p=R/name;s=p.read_text();assert old in s,(name,old[:120]);p.write_text(s.replace(old,new,1))
# Geometry is shared with the resident factory, not invented in the compiler.
p='src/engine/src/resident/numeric/mod.rs'
edit(p,'fn transpose_snapshot(\n','''pub(in crate::resident) fn native_transpose_geometry(
    input: [usize; 2],
) -> Result<[usize; 3], ResidentKernelError> {
    let [rows, columns] = input;
    let count = rows.checked_mul(columns).ok_or(ResidentKernelError::InvalidShape)?;
    Ok([columns, rows, count])
}

fn transpose_snapshot(
''')
pth=R/p;s=pth.read_text();start=s.index('fn transpose_snapshot(');end=s.index('\nfn sum_columns(',start);part=s[start:end]
old='''    let count = rows
        .checked_mul(columns)
        .ok_or(ResidentKernelError::InvalidShape)?;
    let output_shape = resolved_snapshot_output_shape(kernel, columns, rows)?;''';assert old in part
part=part.replace(old,'''    let [output_rows, output_columns, count] = native_transpose_geometry([rows, columns])?;
    let output_shape = resolved_snapshot_output_shape(kernel, output_rows, output_columns)?;''',1);s=s[:start]+part+s[end:];pth.write_text(s)
p='src/engine/src/resident/general/native_collection_numeric_binary.rs'
edit(p,'impl NativeProgramLibraryTemplate {\n','''impl NativeProgramLibraryTemplate {
    /// Exact maintained rank-two F64 transpose, selected by its sealed factory.
    pub fn f64_matrix_transpose(&self) -> bool {
        self.primitive() == P::MatrixTranspose && self.inputs().len() == 1
            && self.inputs().iter().chain([self.output()]).all(|s|
                f64(s) && matches!(s.body(), SchemaBody::Matrix { .. }))
    }
''')
edit(p,'impl NativePreparedLibraryCall {\n','''impl NativePreparedLibraryCall {
    pub fn f64_matrix_transpose_geometry(&self, input: [usize; 2]) -> Option<[u64; 3]> {
        if !self.template().f64_matrix_transpose() || !self.supports_numeric_matrix_transpose() { return None; }
        crate::resident::numeric::native_transpose_geometry(input).ok().map(|axes| axes.map(|n| n as u64))
    }
    /// Retain full original source construction, copies, physical staging,
    /// canonical publication and ordinary replay for a typed transpose loan.
    pub fn f64_matrix_transpose_source_bound(&self, count: u64) -> Option<(ResourceDemand, u64)> {
        if !self.template().f64_matrix_transpose() || !self.supports_numeric_matrix_transpose() { return None; }
        self.f64_matrix_source_bound(count, count, 0)
    }
''')
# The existing matrix selection/cache and paired helper support unary arity.
p='hosts/gpu/src/native_artifact/program/prepare/numeric_binary.rs'
edit(p,'//! Same-plan selected matrix arithmetic;','//! Same-plan selected typed matrix operations;')
edit(p,'    Product,','    Product,\n    Transpose { input: [Option<u64>; 2] },')
edit(p,'    pub operands: [u32; 2],','    pub operands: Vec<u32>,')
edit(p,'                if operands.len() != 2','                if operands.len() != template.inputs().len()')
edit(p,'                    .or_else(|| template.f64_matrix_product().then_some(Kind::Product));','''                    .or_else(|| template.f64_matrix_product().then_some(Kind::Product))
                    .or_else(|| {
                        if !template.f64_matrix_transpose() { return None; }
                        let mech_core::SchemaBody::Matrix { dimensions, .. } = template.inputs()[0].body() else { return None; };
                        let mut input = [None; 2];
                        for (at, axis) in dimensions.iter().enumerate() {
                            if let mech_core::DimensionExpr::Constant(value) = axis { input[at] = Some(*value); }
                        }
                        Some(Kind::Transpose { input })
                    });''')
edit(p,'                    operands: [operands[0].get(), operands[1].get()],','                    operands: operands.iter().map(|v| v.get()).collect(),')
# Extend the existing ordinary staging/owner/publication protocol.
p='hosts/gpu/src/native_artifact/program/runtime/invocation/numeric_binary.rs'
edit(p,'        if args != [self.arguments as u64, 2, 0]\n            || self.argument_capacity < 2','''        let arity = op.operands.len();
        if !(1..=2).contains(&arity) { return Err(invalid("matrix operation arity is unsupported")); }
        if args != [self.arguments as u64, arity as u64, 0]
            || self.argument_capacity < arity''')
edit(p,'        let words = unsafe { [self.arguments.read(), self.arguments.add(1).read()] };','''        let mut words = [0; 2];
        unsafe { words[..arity].copy_from_slice(core::slice::from_raw_parts(self.arguments, arity)); }''')
pth=R/p;s=pth.read_text();s=s.replace('for at in 0..2 {','for at in 0..arity {')
needle='''            Kind::Product => {
                if !call.template().f64_matrix_product()''';assert needle in s
s=s.replace(needle,'''            Kind::Transpose { .. } => {
                let Some([rows, columns, count]) = call.f64_matrix_transpose_geometry(dimensions[0]) else { return Ok(Some(0)); };
                if rows.checked_mul(columns) != Some(count) { return Ok(Some(0)); }
                (rows, columns, 1, 1, dimensions[0][1] as u64)
            }
'''+needle,1)
s=s.replace('let input_count = dimensions.iter().try_fold','let input_count = dimensions[..arity].iter().try_fold',1)
s=s.replace('            Kind::Elementwise(_) => call.f64_matrix_binary_source_bound(input_count, count),','''            Kind::Elementwise(_) => call.f64_matrix_binary_source_bound(input_count, count),
            Kind::Transpose { .. } => call.f64_matrix_transpose_source_bound(count),''',1)
s=s.replace('''                if cells(&value).is_none_or(|v| v.iter().any(|x| x.to_f64().is_nan())) {''','''                if !matches!(op.kind, Kind::Transpose { .. })
                    && cells(&value).is_none_or(|v| v.iter().any(|x| x.to_f64().is_nan())) {''',1)
pth.write_text(s)
# Existing complete generators retain their own inlined transpose route.
p='hosts/gpu/src/native_artifact/program/prepare/numeric_generators.rs'
edit(p,'            if let Some(op) = binary.at(site as usize) {\n                return matches!(op.kind, numeric_binary::Kind::Elementwise(_));\n            }','''            if let Some(op) = binary.at(site as usize)
                && !matches!(op.kind, numeric_binary::Kind::Transpose { .. }) {
                return matches!(op.kind, numeric_binary::Kind::Elementwise(_));
            }''')
p='hosts/gpu/src/native_artifact/program/codegen/numeric_generator.rs'
edit(p,'} else if let Some(binary) = m.numeric_binary.at(site as usize) {','''} else if let Some(binary) = m.numeric_binary.at(site as usize)
                        .filter(|op| matches!(op.kind, crate::native_artifact::program::prepare::numeric_binary::Kind::Elementwise(_))) {''')
# One shared native transpose implementation for fixed generator banks and
# runtime-shaped ordinary matrix operations.
p='hosts/gpu/src/native_artifact/program/codegen/mod.rs';edit(p,'pub(in crate::native_artifact) mod numeric_binary;','pub(in crate::native_artifact) mod numeric_binary;\n#[cfg(feature = "canonical-native-program")]\npub(in crate::native_artifact) mod numeric_transpose;')
p='hosts/gpu/src/native_artifact/program/codegen/numeric_binary.rs'
edit(p,'    match op.kind {\n','''    match op.kind {
        Kind::Transpose { input } => {
            let source_columns = get(b, frame, offset_of!(Frame, inner));
            let mut output_columns = columns;
            let mut input_columns = source_columns;
            for (known, actual, target) in [
                (input[0], columns, &mut output_columns),
                (input[1], source_columns, &mut input_columns),
            ] {
                if let Some(known) = known {
                    let good = b.ins().icmp_imm(IntCC::Equal, actual, known as i64);
                    guard(b, good, error, crate::native_artifact::abi::STATUS_INTEGRITY);
                    *target = b.ins().iconst(types::I64, known as i64);
                }
            }
            super::numeric_transpose::emit(b, left, output, count, output_columns, input_columns, complete);
        }
''')
p='hosts/gpu/src/native_artifact/program/codegen/numeric_generator_arrays.rs';pth=R/p;s=pth.read_text();start=s.index('pub(super) fn transpose(');end=s.index('pub(super) fn binary(',start)
s=s[:start]+'''pub(super) fn transpose(
    b: &mut FunctionBuilder<'_>, output: Value, extents: [u64; 2], data: &[Value],
) {
    let done = b.create_block();
    let count = b.ins().iconst(types::I64, (extents[0] * extents[1]) as i64);
    let output_columns = b.ins().iconst(types::I64, extents[1] as i64);
    let input_columns = b.ins().iconst(types::I64, extents[0] as i64);
    super::super::numeric_transpose::emit(b, data[0], output, count, output_columns, input_columns, done);
    b.switch_to_block(done);
}
'''+s[end:];pth.write_text(s)
# Persisted signatures distinguish the new unary selection and source fees.
edit('hosts/gpu/src/native_artifact/program/image/identity.rs','pub const NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 387;','// IR388 emits typed F64 transposes through the shared matrix loan/kernel.\npub const NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 388;')
edit('hosts/gpu/src/native_artifact/program/image/identity.rs','pub const NATIVE_PROGRAM_WORK_POLICY_VERSION: u64 = 154;','// Policy155 retains complete transpose source costs and ordinary replay.\npub const NATIVE_PROGRAM_WORK_POLICY_VERSION: u64 = 155;')
edit('hosts/gpu/src/native_artifact/program/protocol/abi.rs','const VERSION: u64 = 45;','const VERSION: u64 = 46;')
edit('hosts/gpu/src/native_artifact/program/protocol/abi.rs','// ABI45 adds paired complete numeric-generator loans; the root Frame is unchanged.','// ABI45 adds paired complete numeric-generator loans; the root Frame is unchanged.\n// ABI46 admits unary transpose geometry in the same 80-byte matrix frame.')
edit('hosts/gpu/src/native_artifact/program/runtime/tests.rs','assert_eq!(VERSION, 45);','assert_eq!(VERSION, 46);')
pth=R/'hosts/gpu/src/native_artifact/program/runtime/composition_tests/mod.rs';s=pth.read_text().replace('crate::native_artifact::NATIVE_PROGRAM_WORK_POLICY_VERSION,\n                154','crate::native_artifact::NATIVE_PROGRAM_WORK_POLICY_VERSION,\n                155');pth.write_text(s)
