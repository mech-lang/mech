"""Optimization-only checked Objects; static diagnostics, zero timing samples."""
import importlib.util,json,subprocess,re,hashlib
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
protocol,cases=b.protocol();q=b.read(folder/'qualification.json');plan=b.read(folder/'plan.json');fp=b.compiler_fingerprint();assert fp==q['compiler_fingerprint'] and q['complete']
actors={'accepted48':Path(plan['accepted_driver']),'candidate':Path(q['driver'])};assert b.digest(actors['accepted48'])==plan['accepted_driver_sha256'] and b.digest(actors['candidate'])==q['driver_sha256']
objects=folder/'objects';objects.mkdir(exist_ok=False)
def functions(asm):
 rows={};name=None
 for line in asm.splitlines():
  m=re.match(r'^[0-9a-f]+ <_(.+)>:',line)
  if m:name=m[1];rows[name]=[]
  elif name and re.match(r'^\s*[0-9a-f]+:',line):rows[name].append(line)
 return {name:{'instructions':len(lines),'disassembly_sha256':hashlib.sha256('\n'.join(lines).encode()).hexdigest()} for name,lines in rows.items()}
def records(value,key):
 if isinstance(value,dict):return sum((v if k==key else records(v,key) for k,v in value.items()),[])
 if isinstance(value,list):return sum((records(v,key) for v in value),[])
 return []
r={'scope':'Optimization15 actual checked Object exports, both pinned actors; static code and guarded-copy diagnostics only. No linked Object execution or timing observations.','compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'cases':{},'complete':False,'performance_observations':0}
for name in protocol['optimization']:
 config=folder/f'{name}-inputs.json';b.write(config,cases[name]['inputs']);row={'actors':{}};r['cases'][name]=row
 for actor,driver in actors.items():
  obj=objects/f'{name}-{actor}.o';argv=[str(driver),str(b.FIXTURE/f'{name}.mec'),str(config),'0',f'emit-object={obj}']
  stdout=objects/f'{name}-{actor}.stdout';stderr=objects/f'{name}-{actor}.stderr'
  with stdout.open('x') as out,stderr.open('x') as err:
   child=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err);r['pending']={'case':name,'actor':actor,'pid':child.pid,'command':argv};b.write(folder/'emission-census.json',r)
   while True:
    try:code=child.wait(timeout=30);break
    except subprocess.TimeoutExpired:print('Waiting on same Object process',child.pid,flush=True)
  assert code==0,stderr.read_text();r.pop('pending');status=json.loads(stdout.read_text().strip().splitlines()[-1]);assert status['status']=='ok' and status['mode']=='emit-object'
  metadata=b.read(obj.with_suffix('.metadata.json'));asm=subprocess.run(['/Library/Developer/CommandLineTools/usr/bin/llvm-objdump','--disassemble','--no-show-raw-insn',str(obj)],text=True,capture_output=True,check=True).stdout;disasm=obj.with_suffix('.disasm.txt');disasm.write_text(asm);fm=functions(asm);assert fm and any(v['instructions'] for v in fm.values())
  row['actors'][actor]={'code_bytes':metadata['code_bytes'],'functions':fm,'object_sha256':b.digest(obj),'metadata_sha256':b.digest(obj.with_suffix('.metadata.json')),'disassembly_sha256':b.digest(disasm),'object_executed':False,'masked_matrix_maps':records(metadata,'masked_matrix_maps'),'guarded_map_initializations':records(metadata,'guarded_map_initializations'),'fused_multiply_add_instructions':len(re.findall(r'\b(?:fmadd|fmsub|fnmadd|fnmsub|fmla|fmls)\b',asm))}
 row['functions_match']=row['actors']['accepted48']['functions']==row['actors']['candidate']['functions'];row['code_bytes_match']=row['actors']['accepted48']['code_bytes']==row['actors']['candidate']['code_bytes'];assert row['actors']['accepted48']['masked_matrix_maps']==row['actors']['candidate']['masked_matrix_maps'];b.write(folder/'emission-census.json',r);print(name,'guarded initialization sites',len(row['actors']['candidate']['guarded_map_initializations']),'generated instructions match',row['functions_match'],flush=True)
r['native_code_changed_cases']=[name for name,row in r['cases'].items() if not row['functions_match'] or not row['code_bytes_match']]
r['guarded_cases']=[name for name,row in r['cases'].items() if row['actors']['candidate']['guarded_map_initializations']]
r['no_new_fma']=all(row['actors']['candidate']['fused_multiply_add_instructions']<=row['actors']['accepted48']['fused_multiply_add_instructions'] for row in r['cases'].values())
gram=r['cases']['gramschmidt']['actors']['candidate']['guarded_map_initializations'];r['guarded_initialization_emitted']=len(gram)==3 and sorted(row[2] for row in gram)==[4800,4800,7200] and 'gramschmidt' in r['native_code_changed_cases']
r.update(complete=len(r['cases'])==15,source_unchanged=b.compiler_fingerprint()==fp);r['passed']=r['complete'] and r['source_unchanged'] and r['guarded_initialization_emitted'] and r['no_new_fma'];b.write(folder/'emission-census.json',r);assert r['passed'];print('Guarded cases',r['guarded_cases'],'no new FMA',r['no_new_fma'],flush=True)
