import pathlib,subprocess,sys
folder=pathlib.Path(__file__).resolve().parent
for name in ['run-qualification.py','prepare-qualification-manifest.py','emission-census.py','untimed-counter-gate.py']:
 print('Starting',name,flush=True)
 result=subprocess.run([sys.executable,str(folder/name)])
 if result.returncode:raise SystemExit(result.returncode)
print('Broad qualification and untimed Object/counter gates complete; manual emitted-code/source audit and qualified-source commit remain.',flush=True)
