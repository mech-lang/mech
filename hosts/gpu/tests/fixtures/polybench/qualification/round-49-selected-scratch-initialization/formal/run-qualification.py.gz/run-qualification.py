import json,os,pathlib,re,subprocess,time,importlib.util
spec=importlib.util.spec_from_file_location('b',pathlib.Path.cwd()/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
fp=b.compiler_fingerprint()
folder=pathlib.Path(__file__).resolve().parent
root=pathlib.Path('/Users/cim310/.codex/worktrees/polybench-pr1000/mech')
env=os.environ.copy();env['CARGO_TARGET_DIR']='/private/tmp/mech-polybench-pr1000-target'
base=['cargo','test','--release','-p','mech-gpu','--no-default-features','--features','canonical-native-program']
checks=[
 ('shared-constructor-regressions.log',['cargo','test','--release','-p','mech-core','--no-default-features','--features','baselib,compiler,serde','--lib','--','composite_constructor','prepared_composite','closed_constructor','frame_recipe','--test-threads=1']),
 ('semantic-catalog-solver.log',['cargo','test','--release','-p','mech-core','--no-default-features','--features','functions','--test','type_system_catalog','--test','type_system_solver','--','--test-threads=1']),
 ('source-broadcast-regressions.log',['cargo','test','--release','-p','mech-engine','-p','mech-gpu','--no-default-features','--features','mech-gpu/canonical-native-program','--test','canonical_source_semantics','--test','canonical_source_review','--','broadcast','arithmetic','matrix','--test-threads=1']),
 ('type-image-regressions.log',['cargo','test','--release','-p','mech-engine','-p','mech-gpu','--no-default-features','--features','mech-gpu/canonical-native-program','--lib','--','program_image_read','guarded_histogram_query_schema_certificate_declines_hidden_distinct_constraints','tail_proof_keeps_nominal_enum_identity_and_validates_tag_and_projection_paths','closed_constructor','frame_recipe','--test-threads=1']),
 ('numeric-regressions.log',base+['--lib','--','numeric','rectangular_map','phase','row_block','huffman','private_publication','--test-threads=1']),
 ('matrix-polybench.log',base+['--test','canonical_artifact_matrix','--test','canonical_artifact_polybench','--','--test-threads=1']),
 ('program-regressions.log',base+['--test','canonical_artifact_program','--','buffer_frame_qualification','nested_frame_qualification','numeric_tail_qualification','numeric_write_qualification','scalar_state_qualification','scalar_record_qualification','word_read_qualification','huffman_qualification','sequence_writer_qualification','collection_qualification','packed_update_qualification','range_cursor_qualification','range_qualification','--test-threads=1']),
 ('protocol.log',base+['--lib','--','collection_helpers_have_distinct_roundtrip_codes_and_reserve_output_space','native_runtime_consolidation_preserves_the_charged_layout_envelope','--test-threads=1']),
 ('abi-layout.log',base+['--lib','--','worker_abi_keeps_the_frozen_scalar_prefix_and_disjoint_helper_lanes','ordered_product_frame_preserves_product_and_scalar_prefixes','--test-threads=1']),
 ('runtime-feature.log',['cargo','check','--release','-p','mech-gpu','--no-default-features','--features','canonical-native-program-runtime','--lib']),
 ('production-feature.log',['cargo','check','--release','-p','mech-gpu','--no-default-features','--features','canonical-native-program','--lib']),
]
assert b.read(folder/'focused-result.json')['exit_code']==0
assert fp==b.read(folder/'focused-result.json')['compiler_fingerprint']
receipt={'scope':'Source-proved selected scratch initialization, exact selected-only raw scratch completion, guarded same/different banks, original checked map/fold emission and source fees, finite/physical/cold/alias/atomic/cleanup/retry and forged-image/loan checks; scalar/compression, all30 original/decoded/restored C cases, Object emission and both features; no performance measurements','compiler_fingerprint':fp,'checks':[]}
for name,argv in checks:
 state=b.read(folder/'current-work.json');state.update(stage='Broad correctness/feature qualification running',current_check=name,pid=os.getpid(),complete=False);b.write(folder/'current-work.json',state)
 start=time.monotonic()
 with (folder/name).open('x') as f: result=subprocess.run(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 log=(folder/name).read_text()
 item={'name':name,'command':argv,'exit_code':result.returncode,'wall_seconds':time.monotonic()-start,'passed_tests':[int(n) for n in re.findall(r'test result: ok[.] (\d+) passed',log)]}
 receipt['checks'].append(item);(folder/'qualification-checks.json').write_text(json.dumps(receipt,indent=2)+'\n')
 assert b.compiler_fingerprint()==fp
 print(name,'exit',result.returncode,'passed',item['passed_tests'],flush=True)
 if result.returncode:raise SystemExit(result.returncode)

receipt['complete']=True;receipt['tests']=sum(sum(c['passed_tests']) for c in receipt['checks']);(folder/'qualification-checks.json').write_text(json.dumps(receipt,indent=2)+'\n');print('Qualification complete',receipt['tests'],flush=True)

argv=['cargo','build','--release','-p','mech-gpu','--no-default-features','--features','canonical-native-program','--example','polybench_qualification']
start=time.monotonic()
with (folder/'driver-build.log').open('x') as f: result=subprocess.run(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
b.write(folder/'driver-build-result.json',{'command':argv,'exit_code':result.returncode,'wall_seconds':time.monotonic()-start,'compiler_fingerprint':fp,'source_unchanged':b.compiler_fingerprint()==fp})
assert result.returncode==0 and b.compiler_fingerprint()==fp
import shutil
binary=folder/'selected-scratch-initialization-driver';shutil.copy2(pathlib.Path(env['CARGO_TARGET_DIR'])/'release/examples/polybench_qualification',binary)
receipt.update(driver_sha256=b.digest(binary),driver=str(binary),driver_build_complete=True)
b.write(folder/'qualification-checks.json',receipt)
print('Qualified driver built',receipt['driver_sha256'],flush=True)

state=b.read(folder/'current-work.json');state.update(stage='Broad correctness/feature qualification and driver build complete; untimed exact-counter/Object gate and fresh-process probe not yet run',live_exec_session=None,complete=True,qualification_checks=receipt['tests'],driver_sha256=receipt['driver_sha256'],next='Verify all checks and untimed optimization15 exact-counter/C/Object gate against accepted48 before any prospective probe. Commit/freeze selected source before both formal sets.');b.write(folder/'current-work.json',state)
