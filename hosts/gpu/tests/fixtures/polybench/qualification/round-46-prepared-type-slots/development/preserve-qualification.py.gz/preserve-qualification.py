import gzip,hashlib,importlib.util,json,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;q=b.read(folder/'qualification.json');plan=b.read(folder/'plan.json');gate=b.read(folder/'untimed-counter-gate.json');emission=b.read(folder/'emission-census.json');fp=b.compiler_fingerprint()
assert q['complete'] and q['driver_build_complete'] and q['tests']==713 and q['focused_checks']['passed_tests']==[12]
assert fp==q['compiler_fingerprint']==gate['compiler_fingerprint']==emission['compiler_fingerprint']
assert gate['complete'] and gate['passed'] and emission['complete'] and not emission['native_code_changed_cases'] and emission['source_unchanged']
assert b.digest(q['driver'])==q['driver_sha256'] and len(b.read(p/'performance-history.json')['entries'])==46
assert not (folder/'training-probe.json').exists()
paths=plan['source_paths'];changed=subprocess.check_output(['git','diff','--name-only',plan['source_parent'],'--'],text=True).splitlines();actual=[name for name in changed if name.endswith(('.rs','.toml')) or Path(name).name=='Cargo.lock'];assert set(actual)==set(paths)
patch=subprocess.check_output(['git','diff',plan['source_parent'],'--',*paths]);(folder/'qualified-source.patch').write_bytes(patch)
dest=p/'qualification/round-46-prepared-type-slots/development';dest.mkdir(parents=True,exist_ok=False);archives={}
for source in sorted(folder.rglob('*')):
 if not source.is_file() or '__pycache__' in source.parts or source==Path(q['driver']):continue
 name=str(source.relative_to(folder));raw=source.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives[name]={'path':str(out.relative_to(p)),'sha256':b.digest(source),'compressed_sha256':b.digest(out)}
receipt={'schema':'mech.polybench.prepared-type-slots-development.v1','created_at':b.utc(),'complete':True,'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'qualification_manifest':q,'plan_sha256':b.digest(p/'training-experiments/prepared-type-slots-plan.json'),'source_parent':plan['source_parent'],'source_sha256':q['source_sha256'],'invariants':plan['invariants'],'profiling_basis':plan['profiling_basis'],'prior_related_experiment':plan['prior_related_experiment'],'counter_gate':{'complete':gate['complete'],'passed':gate['passed'],'finite_liveouts':gate['finite_liveouts'],'all_counters_match':all(row['all_counters_match'] for row in gate['cases'].values())},'emission_census':{'complete':emission['complete'],'cases':len(emission['cases']),'native_code_changed_cases':emission['native_code_changed_cases']},'performance_observations':0,'archives':archives}
b.write(p/'training-experiments/prepared-type-slots-development.json',receipt);b.write(p/'training-experiments/prepared-type-slots-training-schedule.json',b.read(folder/'training-probe-plan.json'));b.write(p/'round-46-route-census.json',gate)
subprocess.run(['git','diff','--check'],check=True);subprocess.run(['git','add','--',*paths,str(p.relative_to(root))],check=True)
result=subprocess.run(['git','commit','-m','Reuse validated native type slots without schema rehashing'],capture_output=True,text=True);(folder/'qualification-source-commit.log').write_text(result.stdout+result.stderr);assert result.returncode==0
head=b.command(['git','rev-parse','HEAD']);assert b.compiler_fingerprint()==fp and b.command(['git','status','--porcelain'])==''
b.write(folder/'qualification-source-commit.json',{'source_commit':head,'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'performance_observations':0,'archives_verified':len(archives),'clean':True})
print(json.dumps({'head':head,'compiler_fingerprint':fp,'broad_checks':q['tests'],'focused_checks':12,'archives':len(archives),'performance_observations':0,'working_tree_clean':True}),flush=True)
