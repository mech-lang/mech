"""Fresh checked Objects for both actors; compare generated instructions."""
import importlib.util,json,subprocess,re,hashlib
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
protocol,cases=b.protocol();q=b.read(folder/'qualification.json');plan=b.read(folder/'plan.json');fp=b.compiler_fingerprint();assert fp==q['compiler_fingerprint']
actors={'accepted45':Path(plan['accepted_driver']),'candidate':Path(q['driver'])};assert b.digest(actors['accepted45'])==plan['accepted_driver_sha256'] and b.digest(actors['candidate'])==q['driver_sha256']
objects=folder/'objects';objects.mkdir(exist_ok=False)
def functions(asm):
 rows={};name=None
 for line in asm.splitlines():
  m=re.match(r'^[0-9a-f]+ <_(.+)>:',line)
  if m:name=m[1];rows[name]=[]
  elif name and re.match(r'^\s*[0-9a-f]+:',line):rows[name].append(line)
 return {name:{'instructions':len(lines),'disassembly_sha256':hashlib.sha256('\n'.join(lines).encode()).hexdigest()} for name,lines in rows.items()}
r={'scope':'Optimization15 actual checked Object exports, both exact actor drivers; no linked Object execution or timing observations.','compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'cases':{},'complete':False,'performance_observations':0}
for name in protocol['optimization']:
 config=folder/f'{name}-inputs.json';b.write(config,cases[name]['inputs']);row={'actors':{}};r['cases'][name]=row
 for actor,driver in actors.items():
  obj=objects/f'{name}-{actor}.o';argv=[str(driver),str(b.FIXTURE/f'{name}.mec'),str(config),'0',f'emit-object={obj}']
  stdout=objects/f'{name}-{actor}.stdout';stderr=objects/f'{name}-{actor}.stderr'
  with stdout.open('x') as out,stderr.open('x') as err:
   child=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err);r['pending']={'case':name,'actor':actor,'pid':child.pid,'command':argv};b.write(folder/'emission-census.json',r)
   while True:
    try:code=child.wait(timeout=30);break
    except subprocess.TimeoutExpired:print('Waiting on same Object process',child.pid,flush=True)
  assert code==0,stderr.read_text();r.pop('pending');status=json.loads(stdout.read_text().strip().splitlines()[-1]);assert status['status']=='ok' and status['mode']=='emit-object'
  metadata=b.read(obj.with_suffix('.metadata.json'));asm=subprocess.run(['/Library/Developer/CommandLineTools/usr/bin/llvm-objdump','--disassemble','--no-show-raw-insn',str(obj)],text=True,capture_output=True,check=True).stdout;disasm=obj.with_suffix('.disasm.txt');disasm.write_text(asm);function_map=functions(asm);assert function_map and any(v['instructions'] for v in function_map.values())
  row['actors'][actor]={'code_bytes':metadata['code_bytes'],'functions':function_map,'object_sha256':b.digest(obj),'metadata_sha256':b.digest(obj.with_suffix('.metadata.json')),'disassembly_sha256':b.digest(disasm),'object_executed':False}
 row['functions_match']=row['actors']['accepted45']['functions']==row['actors']['candidate']['functions'];row['code_bytes_match']=row['actors']['accepted45']['code_bytes']==row['actors']['candidate']['code_bytes'];b.write(folder/'emission-census.json',r);print(name,'generated instructions match',row['functions_match'],flush=True)
r['native_code_changed_cases']=[name for name,row in r['cases'].items() if not row['functions_match'] or not row['code_bytes_match']];r.update(complete=len(r['cases'])==15,source_unchanged=b.compiler_fingerprint()==fp);b.write(folder/'emission-census.json',r);assert not r['native_code_changed_cases'] and r['source_unchanged'];print('All15 generated function disassemblies unchanged.',flush=True)
