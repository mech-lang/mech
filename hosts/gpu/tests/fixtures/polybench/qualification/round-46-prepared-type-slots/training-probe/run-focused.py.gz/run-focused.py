import importlib.util,json,os,re,subprocess,time
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
fp=b.compiler_fingerprint();env=os.environ.copy();env['CARGO_TARGET_DIR']='/private/tmp/mech-polybench-pr1000-target'
argv=['cargo','test','--release','-p','mech-gpu','--no-default-features','--features','canonical-native-program','--lib','--','numeric_type_slots','numeric_binary','numeric_composite','composition_uses_current_schema_key_account_and_bits_on_every_visit','--test-threads=1']
state=b.read(folder/'current-work.json');state.update(stage='Focused numeric/type-slot image qualification running',compiler_fingerprint=fp,pid=os.getpid());b.write(folder/'current-work.json',state)
start=time.monotonic()
with (folder/'focused.log').open('x') as out:result=subprocess.run(argv,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
log=(folder/'focused.log').read_text();receipt={'command':argv,'exit_code':result.returncode,'wall_seconds':time.monotonic()-start,'compiler_fingerprint':fp,'source_unchanged':fp==b.compiler_fingerprint(),'passed_tests':[int(n) for n in re.findall(r'test result: ok[.] (\d+) passed',log)],'complete':True}
b.write(folder/'focused-result.json',receipt);print(json.dumps(receipt),flush=True)
assert receipt['source_unchanged'];raise SystemExit(result.returncode)
