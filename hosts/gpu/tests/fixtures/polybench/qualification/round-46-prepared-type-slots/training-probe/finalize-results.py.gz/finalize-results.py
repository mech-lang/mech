"""Keep the strict two-set decision, every observation and exact source rollback."""
import gzip,hashlib,importlib.util,json,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;f=b.read(p/'round-46-frozen.json');tq=b.read(p/'round-46-training-qualification.json');audit=b.read(p/'round-46-audit.json');g=b.read(p/'round-46-progress.json');prior=b.read(p/'round-45-progress.json');decision=audit['performance_acceptance'];plan=b.read(folder/'plan.json')
assert b.command(['git','rev-parse','HEAD'])==f['source_commit'] and b.command(['git','branch','--show-current'])=='codex/polybench-native-matrices'
assert b.compiler_fingerprint()==f['compiler_fingerprint']==tq['compiler_fingerprint']
assert audit['observations']==900 and audit['finite_liveouts']==29482 and audit['history_entries']==47 and len(b.read(p/'performance-history.json')['entries'])==47
assert b.read(folder/'formal-exit.json')['exit_code']==0
for rec in tq['development_archives'].values():
 data=(p/rec['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==rec['compressed_sha256'] and hashlib.sha256(gzip.decompress(data)).hexdigest()==rec['sha256']
scores={part:g['aggregates'][part]['geomean_mech_over_c_kernel'] for part in ['optimization','holdout']};old={part:prior['aggregates'][part]['geomean_mech_over_c_kernel'] for part in scores};assert old==plan['accepted_scores']
promoted=decision['performance_gate']=='accepted';assert promoted==all(scores[part]<old[part] for part in scores) and decision['accepted_index_after_run']==(46 if promoted else 45)
q={'schema':'mech.polybench.optimization-qualification.v3','label':f['label'],'compiler_commit':f['source_commit'],'compiler_fingerprint':f['compiler_fingerprint'],'driver_sha256':f['driver_sha256'],'frozen_candidate_sha256':b.digest(p/'round-46-frozen.json'),'native_typed_ir_version':411,'native_work_policy_version':157,'native_abi_version':47,'dataset':'MINI','numeric_profile':'F64','comparison':{'rtol':1e-10,'atol':1e-9,'finite_required':True,'corpus_liveouts':29482},'checks':tq['checks'],'broad_selected_checks':713,'focused_selected_checks':12,'restored_corpus':tq['restored_corpus'],'source_invariants':tq['invariants'],'profiling_basis':tq['profiling_basis'],'development_attempts':tq['development_attempts'],'counter_gate':{'receipt_sha256':b.digest(p/'round-46-route-census.json'),'scope':'Optimization15 finite C outputs, every execution counter and actual generated Object instructions exactly match accepted45 before any candidate timing.'},'training_probe':b.read(p/'round-46-training-probe.json')['summary'],'performance_acceptance':decision,'aggregate_controls_vs_accepted45':audit['aggregate_controls_vs_accepted45'],'scope':tq['limitations'],'holdout_use':'Aggregate acceptance only; no per-case diagnosis/profiling/tuning.'}
paths=list(tq['source_sha256']);assert len(paths)==5 and set(paths)==set(plan['source_paths'])
if not promoted:
 accepted=plan['source_parent'];subprocess.run(['git','restore','--source='+accepted,'--worktree','--',*paths],check=True);subprocess.run(['git','add','-A','--',*paths],check=True)
 fp=b.compiler_fingerprint();accepted_frozen=b.read(p/'round-45-frozen.json');assert fp==accepted_frozen['compiler_fingerprint']=='cd4d1a9f261eaa16ee9476fbb87a66d8525e7df5af851dafa2c1972867b322ae'
 assert b.digest(plan['accepted_driver'])==accepted_frozen['driver_sha256'];q['compiler_restored_to_accepted45']={'restored_from_commit':accepted,'compiler_fingerprint':fp,'source_paths':paths,'versions':{'ir':410,'work':157,'abi':47},'accepted_driver_unchanged':True,'reason':'Both primary scores must strictly improve; no training result or control adjustment overrides the gate.'}
else:
 fp=b.compiler_fingerprint();q['compiler_promoted']={'accepted_index':46,'compiler_fingerprint':fp,'scores':scores}
dest=p/'qualification/round-46-prepared-type-slots/formal-run';dest.mkdir(parents=True,exist_ok=False);archives={}
for name in ['formal-measurement.log','formal-exit.json','frozen-source-checkpoint.json','source-commit.log','experiment-source-commit.json','inter-round-aggregates.json','formal-report-rows.json','measure-candidate.py','audit-results.py','finalize-results.py','commit-qualified.py']:
 raw=(folder/name).read_bytes();out=dest/(name+'.gz');out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw;archives[name]={'path':str(out.relative_to(p)),'sha256':hashlib.sha256(raw).hexdigest(),'compressed_sha256':b.digest(out)}
q['formal_run_archives']=archives;b.write(p/'round-46-qualification.json',q)
probe=b.read(p/'round-46-training-probe.json');summary=probe['summary']
text='\nRound46: reuse existing validated native type slots ('+('accepted' if promoted else 'not promoted')+')\n\n'
text+='Numeric input validation and output retirement reuse the exact type keys already bound to their source value/transport indexes. Complete current schema ID/key, shape, account, finite/cold/replay, ownership and atomicity checks remain. No new retained cache, wire field, allocation or instruction change. All 713 broad/12 focused checks pass, including key/schema/index substitution negatives, 60 original/decoded restored forms and 58,964 finite C liveouts. Both features pass. IR411/work157/ABI47.\n\n'
text+=f"One prospective probe retained all 210 fresh-process observations: raw GM speedup versus accepted45 {summary['geomean_raw_speedup_vs_accepted45']:.6f}x; all {summary['regressions_over_five_percent']} regressions over5% remain. The untimed all15 gate verifies exact counters and native instructions. Selected source/driver were committed/pushed/frozen before both formal sets.\n\n"
text+='| Set | Accepted45 x C | Round46 x C | Raw speedup vs45 | Reference-adjusted speedup |\n|---|---:|---:|---:|---:|\n'
for part in scores:
 control=audit['aggregate_controls_vs_accepted45'][part];text+=f"| {part.capitalize()} | {old[part]:.5f}x | {scores[part]:.5f}x | {control['raw_mech_speedup']:.5f}x | {control['reference_adjusted_speedup']:.5f}x |\n"
text+='\n'+('Both primary scores strictly improve; round46 is accepted. ' if promoted else 'The strict two-set gate rejects this run; exact accepted45 source and driver are restored. ')
text+='All 900 observations, 29,482 finite liveouts, 47 append-only history entries and every regression remain. Holdout is the aggregate gate only; the below1.0x C goal requires a separate completion audit.\n\n[Qualification](round-46-qualification.json) · [Freeze](round-46-frozen.json) · [Acceptance](round-46-performance-acceptance.json) · [Development](training-experiments/prepared-type-slots-development.json)\n'
with (p/'README.txt').open('a') as out:out.write(text)
subprocess.run(['git','diff','--check'],check=True);subprocess.run(['git','add','--',str(p.relative_to(root))],check=True)
message='Record frozen prepared type-slot benchmark results' if promoted else 'Retain rejected type-slot timings and restore accepted compiler'
result=subprocess.run(['git','commit','-m',message],capture_output=True,text=True);(folder/'results-source-commit.log').write_text(result.stdout+result.stderr);assert result.returncode==0
assert b.compiler_fingerprint()==fp and b.command(['git','status','--porcelain'])=='';head=b.command(['git','rev-parse','HEAD'])
b.write(folder/'current-work.json',{'stage':'Round46 accepted; push/PR metadata pending' if promoted else 'Round46 rejected; exact accepted45 restored, push/PR metadata pending','live_exec_session':None,'source_commit':head,'compiler_fingerprint':fp,'candidate_source_commit':f['source_commit'],'candidate_driver_sha256':f['driver_sha256'],'accepted_round':46 if promoted else 45,'formal_history_entries':47,'measured_scores':scores,'accepted_scores':scores if promoted else old,'next':'Verify/push PR1001 and continue optimization-only work. Do not retry this observed fingerprint; no holdout per-case diagnosis.'})
print(json.dumps({'head':head,'accepted_round':46 if promoted else 45,'scores':scores,'accepted_scores':scores if promoted else old,'observations':900,'history_entries':47,'archives_verified':len(tq['development_archives'])+len(archives),'working_tree_clean':True,'pushed':False}),flush=True)
