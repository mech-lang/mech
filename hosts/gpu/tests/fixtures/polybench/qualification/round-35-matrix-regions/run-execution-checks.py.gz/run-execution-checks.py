import subprocess,os,json,time,importlib.util,sys
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent;stage=folder/sys.argv[1];stage.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
fp=b.compiler_fingerprint();argv=['cargo','test','--release','-p','mech-gpu','--no-default-features','--features','canonical-native-program','--lib','--','numeric_regions','numeric_binary','numeric_product','numeric_transpose','numeric_sum','--test-threads=1'];env=os.environ.copy();env['CARGO_TARGET_DIR']='/private/tmp/mech-polybench-pr1000-target';start=time.monotonic()
(stage/'source.patch').write_text(subprocess.run(['git','diff','--binary'],capture_output=True,text=True,check=True).stdout)
for name in ['program/codegen/numeric_regions.rs','program/runtime/invocation/numeric_regions.rs']:
 src=root/'hosts/gpu/src/native_artifact'/name;dst=stage/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
b.write(folder/'current-work.json',{'stage':'Whole-region execution and maintained individual matrix regression tests','compiler_fingerprint':fp,'command':argv,'log':str(stage/'focused.log'),'accepted_round':31,'new_performance_samples':0,'formal_history_entries':35})
with (stage/'focused.log').open('w') as log:r=subprocess.run(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
result={'command':argv,'compiler_fingerprint':fp,'exit_code':r.returncode,'wall_seconds':time.monotonic()-start,'source_unchanged':b.compiler_fingerprint()==fp};b.write(stage/'focused-result.json',result);print(json.dumps(result));print((stage/'focused.log').read_text()[-18000:]);raise SystemExit(r.returncode)
