import gzip,hashlib,importlib.util,json,pathlib,subprocess
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;f=b.read(p/'round-35-frozen.json');tq=b.read(p/'round-35-training-qualification.json');g=b.read(p/'round-35-progress.json');audit=b.read(p/'round-35-audit.json');decision=audit['performance_acceptance']
assert b.command(['git','rev-parse','HEAD'])==f['source_commit'] and b.compiler_fingerprint()==f['compiler_fingerprint']
assert decision['performance_gate']=='not_promoted' and decision['accepted_index_after_run']==31 and audit['observations']==900 and audit['history_entries']==36
assert len(b.read(p/'performance-history.json')['entries'])==36
q={'schema':'mech.polybench.optimization-qualification.v1','label':f['label'],'compiler_commit':f['source_commit'],'compiler_fingerprint':f['compiler_fingerprint'],'driver_sha256':f['driver_sha256'],'frozen_candidate_sha256':b.digest(p/'round-35-frozen.json'),'native_typed_ir_version':398,'native_work_policy_version':156,'native_abi_version':47,'dataset':'MINI','numeric_profile':'F64','comparison':{'rtol':1e-10,'atol':1e-9,'finite_required':True,'live_outs_per_artifact':29482},'checks':tq['checks'],'total_unique_selected_checks':697,'source_invariants':tq['invariants'],'profiling_basis':tq['profiling_basis'],'emission_census':{'receipt_sha256':b.digest(p/'round-35-emission-census.json'),'cases':15,'native_code_changed_cases':b.read(p/'round-35-emission-census.json')['native_code_changed_cases'],'scope':'Optimization15 Object inspection only; no FMA introduced.'},'training_probe':b.read(p/'round-35-training-probe.json')['summary'],'performance_acceptance':decision,'aggregate_controls_vs_accepted31':audit['aggregate_controls_vs_accepted31'],'scope':tq['limitations'],'holdout_use':'Aggregate acceptance only; no per-case diagnosis, profiling or source tuning.'}
for item in tq['development_archives'].values():
 raw=(p/item['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==item['compressed_sha256'];assert hashlib.sha256(gzip.decompress(raw)).hexdigest()==item['sha256']
paths=b.read(folder/'full-candidate-source-paths.json')['source_paths'];accepted='f60baf055a39497400f9392e0294911becf1a697'
subprocess.run(['git','restore','--source='+accepted,'--worktree','--',*paths],check=True)
# Stage removals of the candidate's new Rust modules before enumerating the
# compiler fingerprint; all other changes are retained for the results commit.
subprocess.run(['git','add','-A','--',*paths],check=True)
fp=b.compiler_fingerprint();expected=b.read(p/'round-31-frozen.json')['compiler_fingerprint'];assert fp==expected=='6447915ae298711f3886c6cba28e0608eb3ce59feab6287308162e45e006c895'
assert b.digest('/private/tmp/mech-polybench-optimization/round-31/inverse-bitcasts/bitcast-driver')==b.read(p/'round-31-frozen.json')['driver_sha256']
q['compiler_restored_to_accepted31']={'restored_from_commit':accepted,'compiler_fingerprint':fp,'source_paths':paths,'versions':{'ir':390,'work':156,'abi':47},'accepted_driver_unchanged':True,'reason':'Both formal Mech/C scores regress against accepted31. The prospective training improvement does not override the fixed formal gate.'}
formal=p/'qualification/round-35-matrix-regions/formal-run';formal.mkdir(exist_ok=False);archives={}
for name in ['formal-measurement.log','frozen-source-checkpoint.json','execution-source-commit.log','experiment-source-commit.json','full-candidate-source-paths.json','inter-round-aggregates.json','formal-report-rows.json','measure-candidate.py','audit-results.py','record-and-restore.py']:
 raw=(folder/name).read_bytes();out=formal/(name+'.gz');out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw;archives[name]={'path':str(out.relative_to(p)),'sha256':hashlib.sha256(raw).hexdigest(),'compressed_sha256':b.digest(out)}
q['formal_run_archives']=archives;b.write(p/'round-35-qualification.json',q)
text='\nRound35: complete matrix-expression loans (not promoted)\n\n'
text+='General root matrix-expression DAGs use one current checked loan and the existing ordered scalar/SIMD kernels. Private intermediates share disjoint storage; escaping values keep canonical publication. Shared Core F64 owner pricing and a singleton/live-matrix broadcast type gap are filled. All697 selected checks pass, including30 original/decoded finite C-liveout cases and both feature builds. IR398/work156/ABI47.\n\n'
text+='The one prospective optimization15 probe measured1.03552x raw geomean speedup against accepted31, with one regression>5% retained and all execution counters identical. The exact compiler and driver were committed/frozen before BOTH formal sets.\n\n'
text+='| Set | Accepted31 x C | Round35 x C | Raw speedup vs31 | Reference-adjusted speedup |\n|---|---:|---:|---:|---:|\n'
old=b.read(p/'round-31-progress.json')
for part in ['optimization','holdout']:
 controls=audit['aggregate_controls_vs_accepted31'][part]
 text+=f"| {part.capitalize()} | {old['aggregates'][part]['geomean_mech_over_c_kernel']:.5f}x | {g['aggregates'][part]['geomean_mech_over_c_kernel']:.5f}x | {controls['raw_mech_speedup']:.5f}x | {controls['reference_adjusted_speedup']:.5f}x |\n"
text+='\nBoth sets regress. No tolerance, retries or exclusions are applied. All900 observations,29482 finite C-liveouts,36 append-only history entries, failed source and raw training/formal evidence remain. Exact accepted31 compiler source and driver are restored, and no remote push is made. The below1.0x C holdout goal remains unmet. Subsequent profiling and source choices remain optimization-only.\n'
readme=p/'README.txt';readme.write_text(readme.read_text()+text)
subprocess.run(['git','diff','--check'],check=True)
subprocess.run(['git','add','--',str(p.relative_to(root))],check=True)
result=subprocess.run(['git','commit','-m','Retain rejected matrix-region results and restore accepted compiler'],capture_output=True,text=True);(folder/'results-source-commit.log').write_text(result.stdout+result.stderr);assert result.returncode==0,result.stderr
assert b.compiler_fingerprint()==expected and b.command(['git','status','--porcelain'])==''
head=b.command(['git','rev-parse','HEAD']);b.write(folder/'current-work.json',{'stage':'Rejected35 complete; accepted31 source and driver restored','live_exec_session':None,'source_commit':head,'compiler_fingerprint':expected,'accepted_round':31,'formal_history_entries':36,'rejected_source_commit':f['source_commit'],'rejected_compiler_fingerprint':f['compiler_fingerprint'],'rejected_driver_sha256':f['driver_sha256'],'rejected_scores':decision['scores'],'accepted_scores':{part:old['aggregates'][part]['geomean_mech_over_c_kernel'] for part in ['optimization','holdout']},'next':'Inspect/profiling only optimization15 for the failed region path and shared caller/publication overhead. Keep failed source/binary available, and preserve active goal below1.0x C holdout. No holdout per-case diagnosis. Do not rerun the e67d25a training probe or round35 formal run.'})
print(json.dumps({'head':head,'restored_compiler_fingerprint':expected,'accepted_round':31,'accepted_scores':{part:old['aggregates'][part]['geomean_mech_over_c_kernel'] for part in ['optimization','holdout']},'rejected_scores':decision['scores'],'observations':900,'history_entries':36,'archives_checked':len(tq['development_archives'])+len(archives),'working_tree_clean':True,'pushed':False}),flush=True)
