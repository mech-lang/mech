import gzip,hashlib,importlib.util,json,pathlib,re,subprocess
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;q=b.read(folder/'qualification.json');probe=b.read(folder/'training-probe.json');census=b.read(folder/'execution-emission-census.json');policy=b.read(folder/'selection-policy.json')
fp=b.compiler_fingerprint();assert fp==q['compiler_fingerprint']==probe['compiler_fingerprint']==census['compiler_fingerprint']
assert b.digest(folder/'matrix-regions-driver')==q['driver_sha256']==probe['driver_sha256']==census['driver_sha256']
assert q['complete'] and q['tests']==697 and len(q['checks'])==10 and all(c['exit_code']==0 for c in q['checks'])
assert probe['summary']['selected'] and len(probe['cases'])==15 and all(c['all_counters_match'] for c in probe['cases'].values())
assert census['complete'] and len(census['cases'])==15
owner=b.read(p/'training-experiments/matrix-region-ownership.json')
for path in ['src/core/src/snapshot/numeric_matrix.rs','src/core/src/snapshot/numeric_matrix_tests.rs','src/core/src/snapshot/validation.rs']:
 assert b.digest(root/path)==owner['source_sha256'][path]
selection={'schema':'mech.polybench.training-selection.v1','created_at':b.utc(),'prospective_rule':policy,'probe_sha256':b.digest(folder/'training-probe.json'),'emission_census_sha256':b.digest(folder/'execution-emission-census.json'),'selected_compiler_fingerprint':fp,'selected_driver_sha256':q['driver_sha256'],'decision':'Select unchanged qualified complete matrix-expression compiler and canonical F64 ownership pricing for frozen formal both-set evaluation.','summary':probe['summary'],'holdout_performance_used':False}
b.write(folder/'training-selection.json',selection)
paths=b.command(['git','diff','--name-only']).splitlines()+b.command(['git','ls-files','--others','--exclude-standard']).splitlines()
source_paths=sorted({path for path in paths if path.endswith(('.rs','.toml'))})
for path in source_paths:
 out=folder/'execution-stage-source'/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((root/path).read_bytes())
b.write(folder/'execution-source-paths.json',{'source_parent':b.command(['git','rev-parse','HEAD']),'compiler_fingerprint':fp,'source_paths':source_paths})
dest=p/'qualification/round-35-matrix-regions';dest.mkdir(parents=True,exist_ok=False)
files=[]
for directory in ['attempt-04-region-execution','attempt-05-region-contract','attempt-06-singleton-schemes','attempt-07-complete-staging','execution-objects','execution-stage-source']:
 files.extend(path for path in (folder/directory).rglob('*') if path.is_file() and '__pycache__' not in path.parts)
for name in ['prepare-execution-receipts.py','execution-source-paths.json','run-execution-checks.py','run-execution-qualification.py','execution-qualification-progress.log','qualification-checks.json','qualification.json','driver-build.log','driver-build-result.json','selection-policy.json','source-checkpoint.json','training-probe.py','training-probe.json','training-probe.log','training-selection.json','execution-emission-census.py','execution-emission-census.json','execution-emission-census.log','measure-candidate.py','audit-results.py']+[c['name'] for c in q['checks']]:
 files.append(folder/name)
archives={}
for path in sorted(set(files)):
 raw=path.read_bytes();name=str(path.relative_to(folder));out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives[name]={'path':str(out.relative_to(p)),'sha256':hashlib.sha256(raw).hexdigest(),'compressed_sha256':b.digest(out)}
logs=[];all_names=[]
for check in q['checks']:
 names=re.findall(r'^test (.+?) \.\.\. ok$',(folder/check['name']).read_text(),re.M)
 assert len(names)==sum(check['passed_tests']),(check['name'],len(names),check['passed_tests'])
 all_names.extend(names);item=archives[check['name']];logs.append({'log':item['path'],'log_sha256':item['sha256'],'compressed_sha256':item['compressed_sha256'],'passed_tests':len(names)})
assert len(all_names)==len(set(all_names))==697
for name,value in [('training-probe',probe),('training-selection',selection),('emission-census',census)]:b.write(p/f'round-35-{name}.json',value)
tq={'schema':'mech.polybench.training-qualification.v1','created_at':b.utc(),'scope':'General complete matrix-expression execution over existing scalar/SIMD Cranelift kernels, with exact source billing and Core F64 ownership pricing. Selected exclusively from optimization15 evidence.','source_parent':q['source_parent'],'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'versions':q['versions'],'total_unique_selected_checks':697,'checks':q['checks'],'logs':logs,'development_archives':archives,'source_paths':source_paths,'profiling_basis':{'receipt':'training-experiments/root-operator-profile.json','sha256':b.digest(p/'training-experiments/root-operator-profile.json'),'partition':'optimization','observation':'Root matrix-operator paths repeatedly prepare calls and create canonical intermediate owners; optimization-only source census found37 operators and25 private intermediates in8 programs.','limitation':'Coarse source/profile evidence is not a timing estimate.'},'prerequisites':[{'receipt':'training-experiments/matrix-region-inventory.json','sha256':b.digest(p/'training-experiments/matrix-region-inventory.json')},{'receipt':'training-experiments/matrix-region-ownership.json','sha256':b.digest(p/'training-experiments/matrix-region-ownership.json'),'current_core_source_hashes_verified':True}],'invariants':[
'Source-closed root matrix-expression DAGs derive from actual same-plan canonical calls, dominance, all semantic reads, alias escapes and disjoint bank lifetimes. All image paths independently rederive recipes; no cached pointer, live owner, permit or work credit is accepted from an image.',
'Current admission checks genuine current arena generations, type/key/account/shape, resident operation geometry, overflow and every original resource cap. It pins inputs and reserves complete coexisting source byte/node peaks, temporary metadata/data backings, prospective escaping output nodes and full ordinary replay.',
'Existing Cranelift scalar/SIMD elementwise, product, sum and transpose emitters run in source order. FP terms remain unfused and ordered. Produced1x1 bank broadcasts load the current bank. Integer magnitude bounds admit only finite intermediates; nonfinite and uncertain bounds preserve existing individual/ordinary execution.',
'Original source visits, work/comparison charges, canonical publication/retirement prices and managed copy bills are preserved. Private banks use real arena-issued virtual generations, are checked at every source read and never masquerade as canonical Values. Every training-probe execution counter matches accepted31 exactly.',
'Only escaping results receive canonical owners after arithmetic. Logical banks reuse storage only across strictly disjoint lifetimes. Ordinary terminal publication remains atomic, and all staging claims release on denial, error, malformed finish, completion and retry.',
'Only scalar captures use the native argument lane; managed captures come from checked current arena owners. The existing individual mode remains a fallback, fast scalar Bool/U64/I64/F64 execution is maintained, and invocation fields retain their charged layout envelope.',
'Core prospective F64 owner pricing validates actual schemas/shapes/counts without constructing owners or granting views. The unchanged exact generic traversal remains for rebound/nested owners. Prior independent owner tests remain applicable; current Core source hashes match their qualified stage.',
'A general singleton-matrix numeric broadcast scheme preserves both live axes of its peer and rigid input metadata. The actual failing produced1x1 source now compiles and executes without port annotations or rewrites; catalog/solver and source regressions pass.',
'697 distinct selected checks pass, including24 matrix and30 original/decoded finite C-liveout programs and Object emission. Runtime-only and compiler features pass. All15 optimization Object exports are inspected; code changes in8 programs, and no fused FP instructions are introduced.',
'No benchmark-name dispatch, Mech port/input/C binary/flag/limit/tolerance/split/objective/timing-boundary change. One prospective seven-sample optimization-only probe retains all cases and regressions. Commit/freeze source+driver before BOTH formal sets; promote only if BOTH scores strictly improve over accepted31.'],
'development_failures':['Initial expanded verification passed21 checks but exposed an ambiguous produced1x1/live-matrix source. A general source type-scheme gap was filled; the unchanged failing expression and all28 semantic catalog checks now pass.','The initial physical-refusal test used a fixed64MiB account and could not assert whole-region recovery. The test account now derives from complete declared source byte/node geometry; both refusal boundaries, atomic outputs and retry pass.','Review moved recursive validation/payload scans behind complete source funding, explicitly inventoried temporary demand/magnitude vectors, reserved canonical output node headroom, and removed unnecessary managed capture transport before the final qualified probe.'],
'limitations':['MINI/F64 CPU evidence; no larger dataset, GPU execution, linked Object or application speed claim.','This finite-bound version may decline expressions whose intermediate finiteness is unproved. Existing execution remains available; no source behavior or source fees are weakened.','One existing explicit source-plan diagnostic remains ignored because it requires an output directory; it is not a correctness or timing case.','Training improvement is not formal performance acceptance. Holdout may reject this exact candidate; no per-case holdout diagnosis or tuning.']}
b.write(p/'round-35-training-qualification.json',tq)
assert b.compiler_fingerprint()==fp
print(json.dumps({'tests':697,'archives':len(archives),'fingerprint':fp,'driver_sha256':q['driver_sha256'],'training_summary':probe['summary'],'source_paths':source_paths}),flush=True)
