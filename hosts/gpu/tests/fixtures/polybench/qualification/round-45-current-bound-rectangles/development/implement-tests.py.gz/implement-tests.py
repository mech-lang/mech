from pathlib import Path
root=Path.cwd();base='hosts/gpu/src/native_artifact/program/'
p=root/(base+'runtime/composition_tests/rectangular_numeric_maps.rs');s=p.read_text()
def replace(old,new,count=1):
 global s
 assert s.count(old)==count,(s.count(old),old[:100]);s=s.replace(old,new)
name='rectangular_numeric_maps_all_exact_kinds_keep_branches_shapes_fresh_payloads_and_empty_sources'
replace(f'fn {name}()\n{{',f'''fn {name}() {{
    exact_kinds(false);
}}
#[test]
fn rectangular_numeric_maps_current_bounds_keep_all_exact_kinds_and_empty_sources() {{
    exact_kinds(true);
}}
fn exact_kinds(current: bool) {{''')
old='''        let source = format!(
            "data := values<[{kind}]:1,3>\\n[[((j == 1u64)? | true => data[i] | false => data[4u64 - i]) | i <- 1u64..=3u64]' | j <- items<[u64]>]\\n"
        );'''
new='''        let endpoints = if current { "first..=last" } else { "1u64..=3u64" };
        let prefix = if current { "first := first<u64>\\nlast := last<u64>\\n" } else { "" };
        let source = format!(
            "{prefix}data := values<[{kind}]:1,3>\\n[[((j == 1u64)? | true => data[i] | false => data[4u64 - i]) | i <- {endpoints}]' | j <- items<[u64]>]\\n"
        );'''
replace(old,new)
replace('''                                ("values", Data::Matrix(values.into()), &[1, 3]),''','''                                ("values", Data::Matrix(values.into()), &[1, 3]),
                                ("first", Data::U64(1), &[]),
                                ("last", Data::U64(3), &[]),''')
for name,helper,newtest in [
 ('rectangular_numeric_maps_replay_partial_bounds_and_arithmetic_errors_with_finite_limits','finite_limits','rectangular_numeric_maps_current_bounds_preserve_finite_limits_and_original_errors'),
 ('rectangular_numeric_maps_reject_changed_loans_and_interleaving_then_retry','changed_loans','rectangular_numeric_maps_current_bounds_reject_changed_loans_and_allow_retry')]:
 replace(f'fn {name}() {{',f'''fn {name}() {{
    {helper}(false);
}}
#[test]
fn {newtest}() {{
    {helper}(true);
}}
fn {helper}(current: bool) {{''')
 start=s.index(f'fn {helper}(current: bool)')
 end=s.find('\n#[test]',start+1)
 if end==-1:end=len(s)
 part=s[start:end]
 needle='''    for artifact in artifacts(source) {'''
 assert part.count(needle)==1
 part=part.replace(needle,'''    let source = if current {
        format!("last := last<u64>\\n{}", source.replace("1u64..=3u64", "1u64..=last"))
    } else { source.to_owned() };
    for artifact in artifacts(&source) {''')
 if helper=='finite_limits':
  needle='''                        ("divisor", Data::U64(divisor), &[]),'''
  assert part.count(needle)==1
  part=part.replace(needle,needle+'''\n                        ("last", Data::U64(3), &[]),''')
 else:
  needle='''                    (
                        "items",
                        Data::Matrix(vec![Data::U64(1), Data::U64(2)].into()),'''
  assert part.count(needle)==1
  part=part.replace(needle,'''                    ("last", Data::U64(3), &[]),
'''+needle)
  part=part.replace('''for corrupt in [1, 3, 5, 8, 9, 14, 16, 17]''','''for corrupt in [1, 3, 5, 8, 9, 14, 16, 17, 25, 26, 27, 28]''')
 s=s[:start]+part+s[end:]
replace('''fn rectangular_numeric_maps_keep_dynamic_and_ragged_inner_ranges_on_the_original_path()''','''fn rectangular_numeric_maps_keep_outer_dependent_inner_ranges_on_the_original_path()''')
replace('''        "data := values<[f64]:1,3>\\nlast := last<u64>\\n[[data[i] | i <- 1u64..=last]' | j <- items<[u64]>]\\n",''','''        "data := values<[f64]:1,3>\\n[[data[i] | i <- j..=3u64]' | j <- items<[u64]>]\\n",''')
p.write_text(s)
# Extend the existing genuine helper instrumentation. Mutate only the exact
# invocation-owned frame, never an arbitrary or fabricated pointer.
p=root/(base+'runtime/composition_tests/numeric_maps.rs');s=p.read_text()
needle='''        if flags.corrupt == 18 {'''
assert s.count(needle)==1
s=s.replace(needle,'''        if flags.corrupt == 27 || flags.corrupt == 28 {
            let frame = unsafe { &mut *(a as *mut NativeNumericMapFrame) };
            if flags.corrupt == 27 {
                frame.rectangle_start ^= 1;
            } else {
                frame.rectangle_rows += 1;
            }
        }
'''+needle)
needle='''                counts.elements.insert(site, unsafe {'''
assert s.count(needle)==1
s=s.replace(needle,'''                if flags.corrupt == 25 || flags.corrupt == 26 {
                    let frame = unsafe { &mut *(value as *mut NativeNumericMapFrame) };
                    if flags.corrupt == 25 {
                        frame.rectangle_rows = 0;
                    } else {
                        frame.rectangle_start = u64::MAX;
                    }
                }
'''+needle)
needle='''    for name in ["gramschmidt", "cholesky", "deriche", "durbin"] {'''
assert s.count(needle)==1
s=s.replace(needle,'''    for name in ["gramschmidt", "cholesky", "deriche", "durbin", "correlation"] {''')
s=s.replace('''                if name != "deriche" {''','''                if name != "deriche" && name != "correlation" {''',1)
s=s.replace('''                if name != "cholesky" {''','''                if name != "cholesky" && name != "correlation" {''',1)
needle='''                if name == "gramschmidt" {'''
assert s.count(needle)==1
s=s.replace(needle,'''                if name == "correlation" {
                    let rectangles = jit.descriptor().metadata().numeric_maps.regions.iter()
                        .filter(|r| r.rectangle.is_some()).collect::<Vec<_>>();
                    assert_eq!(rectangles.len(), 1);
                    let region = rectangles[0];
                    assert!(matches!(region.rectangle.as_ref().unwrap().bounds,
                        crate::native_artifact::program::prepare::numeric_maps::RectangleBounds::Current { .. }));
                    assert!(counts.elements.contains_key(&u64::from(region.header)));
                    assert_eq!(counts.direct_rectangles, 1);
                    assert_eq!(counts.block_permutations, 0);
                    assert_eq!(counts.transpose_complete, 0);
                    for &site in &region.body {
                        assert!(counts.helpers.keys().all(|(at, _)| *at != u64::from(site)), "per-cell rectangle helper {site}");
                    }
                    assert!(counts.helpers.keys().all(|(at, _)| *at != u64::from(region.rectangle.as_ref().unwrap().transpose)));
                }
'''+needle)
p.write_text(s)
print('existing differential suites extended for current bounds')
