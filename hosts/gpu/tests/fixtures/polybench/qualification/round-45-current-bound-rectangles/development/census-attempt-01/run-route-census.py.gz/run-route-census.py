"""Untimed optimization-only source-fusion and execution-counter evidence."""
import importlib.util, json, re, shutil, subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
q=b.read(folder/'qualification.json');fp=b.compiler_fingerprint()
assert q['complete'] and fp==q['compiler_fingerprint'] and b.digest(q['driver'])==q['driver_sha256']
assert not (folder/'admission-census.json').exists()
accepted=Path('/private/tmp/mech-polybench-optimization/round-44/prepared-composite-binding/prepared-composite-driver')
history=b.read(b.FIXTURE/'performance-history.json')['entries'];assert len(history)==45
assert b.digest(accepted)==history[-1]['candidate']['driver_sha256']
inputs=folder/'correlation-inputs.json'
shutil.copy2(Path('/private/tmp/mech-polybench-optimization/round-45/accepted44-margin-profile/correlation-inputs.json'),inputs)
source=b.FIXTURE/'correlation.mec'
command=[q['driver'],str(source),str(inputs),'0','emit-object='+str(folder/'correlation.o')]
with (folder/'object-export.log').open('x') as log:r=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0
b.write(folder/'object-export-receipt.json',{'command':command,'exit_code':r.returncode,'object_sha256':b.digest(folder/'correlation.o'),'performance_observations':0})
with (folder/'object-read.log').open('x') as log:r=subprocess.run(['python3',str(folder/'read-correlation-image.py')],cwd=root,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0
image=b.read(folder/'correlation-image.json')['descriptor']
rectangles=[r for r in image['numeric_maps']['regions'] if r['rectangle'] is not None]
assert len(rectangles)==1
region=rectangles[0];rectangle=region['rectangle'];assert 'Current' in rectangle['bounds']
config={'scope':'Correlation optimization program only. Actual source/inputs and frozen accepted44/current qualified drivers. No kernel timing samples.','worktree':str(root),'drivers':{'accepted44':{'path':str(accepted),'sha256':b.digest(accepted),'compiler_fingerprint':history[-1]['candidate']['compiler_fingerprint']},'candidate':{'path':q['driver'],'sha256':q['driver_sha256'],'compiler_fingerprint':fp}},'cases':{actor:{'driver':driver['path'],'source':str(source),'inputs':str(inputs)} for actor,driver in [('accepted44',{'path':str(accepted)}),('candidate',{'path':q['driver']})]}}
b.write(folder/'census-config.json',config)
argv=['lldb','--batch','-o','settings set target.disable-aslr false','-o','settings set target.skip-prologue false','-o','command script import '+str(folder/'rectangle_census.py'),'-o','script rectangle_census.run()']
with (folder/'debugger-census.log').open('x') as log:r=subprocess.run(argv,cwd=root,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0
census=b.read(folder/'admission-census.json');assert census['complete']
_,cases=b.protocol();rows=census['cases']
for actor,row in rows.items():
 assert row['exit_code']==0 and row['timing_samples']==0
 row['validation']=b.validate(row['driver_values'],cases['correlation']['expected'])
 row['execution_counters']={k:int(v) for k,v in re.findall(r'([a-z_]+): (\d+)',row['execution_report'])}
assert rows['candidate']['counts_by_site']['map'][str(region['header'])]==2
inner=next(r for r in image['numeric_maps']['regions'] if r['iteration']==rectangle['inner_iteration'] and r['rectangle'] is None)
assert str(inner['header']) not in rows['candidate']['counts_by_site']['map']
assert rows['candidate']['counts_by_site']['transpose']=={}
assert all(str(site) not in rows['candidate']['counts_by_site']['generic'] for site in region['body'])
a=rows['accepted44']['execution_counters'];c=rows['candidate']['execution_counters'];deltas={k:c[k]-v for k,v in a.items()}
assert all(v==0 for k,v in deltas.items() if k not in ['work','comparison_work','visits'])
v2= deltas['visits']==0 and deltas['work']>=0 and deltas['comparison_work']>=0
census.update(compiler_fingerprint=fp,driver_sha256=q['driver_sha256'],finite_c_liveouts=rows['candidate']['validation']['count'],selected_rectangle=region,execution_counter_deltas=deltas,prospective_route_gate_passed=True,v2_counter_guard_passed=v2,performance_observations=0,interpretation='Physical control visits and work/comparison counters measure the executed implementation. Source-derived fusion eliminates repeated pure range/builder/transpose/publication paths. Their full source eligibility/replay and finite coexistence bounds remain checked; exact old counters are a separate precommitted v2 selection condition, not a correctness claim. No timing sample has been collected.')
assert fp==b.compiler_fingerprint()
b.write(folder/'execution-route-census.json',census)
print(json.dumps({'route_gate':True,'finite_c_liveouts':census['finite_c_liveouts'],'v2_counter_guard':v2,'counters':{actor:{k:r['execution_counters'][k] for k in ['work','comparison_work','visits']} for actor,r in rows.items()},'map_callbacks':{actor:r['counts_by_site']['map'] for actor,r in rows.items()},'transpose_callbacks':{actor:r['counts_by_site']['transpose'] for actor,r in rows.items()},'performance_observations':0}),flush=True)
