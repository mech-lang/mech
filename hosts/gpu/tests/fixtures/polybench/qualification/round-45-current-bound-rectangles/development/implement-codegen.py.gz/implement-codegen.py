from pathlib import Path
root=Path.cwd();base='hosts/gpu/src/native_artifact/program/'
def change(name,old,new,count=1):
 p=root/(base+name);s=p.read_text();assert s.count(old)==count,(name,s.count(old),old[:100]);p.write_text(s.replace(old,new))
change('prepare/numeric_maps.rs','''pub(in crate::native_artifact) use rectangles::Rectangle;''','''pub(in crate::native_artifact) use rectangles::{Bounds as RectangleBounds, Rectangle};''')
change('runtime/collections/numeric_rectangles.rs','''{Region, rectangles::Bounds}''','''{RectangleBounds as Bounds, Region}''')
change('codegen/numeric_map.rs','''use crate::native_artifact::program::prepare::numeric_maps::Region;''','''use crate::native_artifact::program::prepare::numeric_maps::{RectangleBounds, Region};''')
change('codegen/numeric_map.rs','''    hooks.call(b, site, GlobalHelper::NumericMapPrepare, [zero; 3], error);''','''    let args = if let Some(rectangle) = &region.rectangle {
        if let RectangleBounds::Current { operands } = rectangle.bounds {
            let mech_engine::native_artifact::NativeControlLoop::Collection(inner) =
                &plan.iterations()[rectangle.inner_iteration as usize]
            else {
                return Err(backend("current rectangle lost inner collection"));
            };
            let mech_engine::native_artifact::NativeCollectionSource::U64Range(cursor) = inner.source() else {
                return Err(backend("current rectangle lost inner range"));
            };
            if cursor.operands().map(|value| value.get()) != operands {
                return Err(backend("current rectangle endpoint inventory differs"));
            }
            let [first, last] = cursor.operands();
            [
                crate::native_artifact::control_compiler::load(b, locals, *first)?,
                crate::native_artifact::control_compiler::load(b, locals, *last)?,
                zero,
            ]
        } else {
            [zero; 3]
        }
    } else {
        [zero; 3]
    };
    hooks.call(b, site, GlobalHelper::NumericMapPrepare, args, error);''')
change('codegen/numeric_map.rs','''    let inner_count = b.ins().iconst(
        types::I64,
        region.rectangle.as_ref().map_or(1, |r| r.rows) as i64,
    );''','''    let (inner_start, inner_count) = match &region.rectangle {
        Some(rectangle) => match rectangle.bounds {
            RectangleBounds::Fixed { start, rows, .. } => (
                b.ins().iconst(types::I64, start as i64),
                b.ins().iconst(types::I64, rows as i64),
            ),
            RectangleBounds::Current { .. } => {
                let start = get(b, frame, offset_of!(Frame, rectangle_start));
                let rows = get(b, frame, offset_of!(Frame, rectangle_rows));
                let positive = b.ins().icmp_imm(IntCC::NotEqual, rows, 0);
                require(b, positive, malformed);
                let last = b.ins().iadd_imm(rows, -1);
                let (_, overflow) = b.ins().uadd_overflow(start, last);
                let good = b.ins().icmp_imm(IntCC::Equal, overflow, 0);
                require(b, good, malformed);
                (start, rows)
            }
        },
        None => (b.ins().iconst(types::I64, 0), b.ins().iconst(types::I64, 1)),
    };''')
change('codegen/numeric_map.rs','''        let rows = b.ins().iconst(types::I64, rectangle.rows as i64);
        let column = b.ins().udiv(at, rows);''','''        let column = b.ins().udiv(at, inner_count);''')
change('codegen/numeric_map.rs','''        let consumed = b.ins().imul(column, rows);''','''        let consumed = b.ins().imul(column, inner_count);''')
change('codegen/numeric_map.rs','''        let inner = b.ins().iadd_imm(row, rectangle.start as i64);''','''        let inner = b.ins().iadd(row, inner_start);''')
change('codegen/numeric_phase_reductions.rs','''    let elements = if let Some(rectangle) = &region.rectangle {
        let rows = b.ins().iconst(types::I64, rectangle.rows as i64);''','''    let (rectangle_start, rectangle_rows) = match &region.rectangle {
        Some(rectangle) => {
            let [start, _, rows] = rectangle.fixed().ok_or_else(|| backend("fixed numeric phase has current rectangle bounds"))?;
            (b.ins().iconst(types::I64, start as i64), b.ins().iconst(types::I64, rows as i64))
        }
        None => (zero, one),
    };
    for (at, word) in [
        (offset_of!(Frame, rectangle_start), rectangle_start),
        (offset_of!(Frame, rectangle_rows), rectangle_rows),
    ] {
        b.ins().store(MemFlags::new(), word, frame, at as i32);
    }
    let elements = if region.rectangle.is_some() {
        let rows = rectangle_rows;''')
# Update proof-corruption tests for explicit fixed/current source bounds.
change('runtime/composition_tests/numeric_phase_maps.rs','''map.count * map.region.rectangle.as_ref().map_or(1, |r| r.rows)''','''map.count * map.region.rectangle.as_ref().map_or(1, |r| r.fixed().unwrap()[2])''')
change('runtime/composition_tests/numeric_phase_maps.rs','''                forged.region.rectangle.as_mut().unwrap().rows += 1;''','''                let super::super::super::prepare::numeric_maps::RectangleBounds::Fixed { rows, .. } =
                    &mut forged.region.rectangle.as_mut().unwrap().bounds
                else { panic!("fixed scratch-bank map") };
                *rows += 1;''')
change('runtime/composition_tests/numeric_phase_owned_maps.rs','''actions/{i}/1/Map/replacement/source/region/rectangle/rows''','''actions/{i}/1/Map/replacement/source/region/rectangle/bounds/Fixed/rows''')
print('emitter and fixed-phase source changes written')
