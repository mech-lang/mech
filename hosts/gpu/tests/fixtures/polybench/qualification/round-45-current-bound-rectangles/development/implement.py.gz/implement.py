from pathlib import Path
root=Path.cwd()
def change(name, old, new, count=1):
 p=root/name;s=p.read_text();assert s.count(old)==count,(name,s.count(old),old[:100]);p.write_text(s.replace(old,new))
base='hosts/gpu/src/native_artifact/program/'
change(base+'prepare/numeric_rectangles.rs','''    pub start: u64,
    pub end: u64,
    /// A provisional bound, certified by the selected range factory per loan.
    pub rows: u64,
''','''    pub bounds: Bounds,
''')
change(base+'prepare/numeric_rectangles.rs','''fn constant(plan: &Plan, value: Value) -> Option<u64> {''','''/// Source facts only. Current endpoints are read afresh at the exact outer
/// header; they never become fixed scratch-bank cardinality facts.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub(in crate::native_artifact) enum Bounds {
    Fixed { start: u64, end: u64, rows: u64 },
    Current { operands: [u32; 2] },
}
impl Rectangle {
    pub fn fixed(&self) -> Option<[u64; 3]> {
        match self.bounds {
            Bounds::Fixed { start, end, rows } => Some([start, end, rows]),
            Bounds::Current { .. } => None,
        }
    }
}
fn constant(plan: &Plan, value: Value) -> Option<u64> {''')
old='''fn range(plan: &Plan, cursor: &NativeU64RangeCursor) -> Option<(u64, u64, u64)> {
    let [first, last] = cursor.operands();
    let start = constant(plan, *first)?;
    let end = constant(plan, *last)?;
    let difference = end.checked_sub(start)?;
    let rows = match cursor.template().primitive() {
        Primitive::RangeExclusive => difference,
        Primitive::RangeInclusive => difference.checked_add(1)?,
        _ => return None,
    };
    (rows != 0).then_some((start, end, rows))
}'''
new='''fn range(
    plan: &Plan,
    facts: &Facts<'_>,
    cursor: &NativeU64RangeCursor,
    initialize: u32,
    parent: Option<u32>,
) -> Option<Bounds> {
    if !matches!(cursor.template().primitive(), Primitive::RangeExclusive | Primitive::RangeInclusive) {
        return None;
    }
    let operands = cursor.operands();
    for &value in operands {
        if plan.values()[value.get() as usize].scalar_kind() != Some(NativeScalarKind::U64)
            || !immutable_before(facts, value, initialize, parent).ok()?
        {
            return None;
        }
    }
    match operands.map(|value| constant(plan, value)) {
        [Some(start), Some(end)] => {
            let difference = end.checked_sub(start)?;
            let rows = match cursor.template().primitive() {
                Primitive::RangeExclusive => difference,
                Primitive::RangeInclusive => difference.checked_add(1)?,
                _ => return None,
            };
            (rows != 0).then_some(Bounds::Fixed { start, end, rows })
        }
        _ => Some(Bounds::Current { operands: operands.map(|value| value.get()) }),
    }
}'''
change(base+'prepare/numeric_rectangles.rs',old,new)
change(base+'prepare/numeric_rectangles.rs','''    let (start, end, rows) = range(plan, cursor)?;''','''    let bounds = range(plan, facts, cursor, generator.initialize(), generator.parent())?;''')
change(base+'prepare/numeric_rectangles.rs','''        start,
        end,
        rows,
        elided_values:''','''        bounds,
        elided_values:''')
# Static phase proofs must explicitly reject current inner bounds.
change(base+'prepare/numeric_phase/matrix_maps.rs','''    let rows = region.rectangle.as_ref().map_or(1, |r| r.rows);''','''    let rows = match &region.rectangle {
        Some(rectangle) => rectangle.fixed()?[2],
        None => 1,
    };''')
change(base+'prepare/numeric_phase/matrix_map_budget.rs','''        if cursor.operands().map(|v| v.get()) != [self.first, self.last]''','''        let rows = match &self.region.rectangle {
            Some(rectangle) => rectangle.fixed()?[2],
            None => 1,
        };
        if cursor.operands().map(|v| v.get()) != [self.first, self.last]''')
change(base+'prepare/numeric_phase/matrix_map_budget.rs','''                    .checked_mul(self.region.rectangle.as_ref().map_or(1, |r| r.rows))?''','''                    .checked_mul(rows)?''')
change(base+'prepare/numeric_phase/matrix_map_budget.rs','''        if let Some(rectangle) = &self.region.rectangle {
            let NativeControlLoop''','''        if let Some(rectangle) = &self.region.rectangle {
            let [start, end, rows] = rectangle.fixed()?;
            let NativeControlLoop''')
p=root/(base+'prepare/numeric_phase/matrix_map_budget.rs');s=p.read_text().replace('rectangle.start','start').replace('rectangle.end','end').replace('rectangle.rows','rows');p.write_text(s)
change(base+'image/identity.rs','''pub const NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 409;''','''pub const NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 410;''')
# Resolve only fixed-size endpoint arithmetic before replay credit. The actual
# selected factory/schema traversal remains after unchanged setup admission.
p=root/(base+'runtime/collections/numeric_rectangles.rs');s=p.read_text()
s=s.replace('''use crate::native_artifact::program::prepare::numeric_maps::Region;''','''use crate::native_artifact::program::prepare::numeric_maps::{Region, rectangles::Bounds};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(in crate::native_artifact::program::runtime) struct Geometry {
    pub start: u64,
    pub end: u64,
    pub rows: u64,
}
pub(super) fn resolve(
    descriptor: &NativeProgramDescriptor,
    region: &Region,
    args: [u64; 3],
) -> Result<Option<Geometry>, Error> {
    let Some(rectangle) = &region.rectangle else {
        if args != [0; 3] {
            return Err(invalid("numeric map entry has unexpected endpoints"));
        }
        return Ok(Some(Geometry { start: 0, end: 0, rows: 1 }));
    };
    let NativeControlLoop::Collection(inner) =
        &descriptor.metadata().plan.iterations()[rectangle.inner_iteration as usize]
    else {
        return Err(invalid("rectangular inner source changed"));
    };
    let NativeCollectionSource::U64Range(cursor) = inner.source() else {
        return Err(invalid("rectangular inner range changed"));
    };
    if cursor.prepare() != rectangle.range_prepare {
        return Err(invalid("rectangular range prepare changed"));
    }
    let (start, end) = match rectangle.bounds {
        Bounds::Fixed { start, end, .. } => {
            if args != [0; 3] {
                return Err(invalid("fixed rectangle entry has endpoints"));
            }
            (start, end)
        }
        Bounds::Current { operands } => {
            if args[2] != 0 || cursor.operands().map(|value| value.get()) != operands {
                return Err(invalid("current rectangle endpoint transport differs"));
            }
            // These are the exact original U64 operand words, transported by
            // the source-derived emitter just as at PrepareU64Range. Their
            // immutable-before-outer proof is reconstructed on image admission.
            (args[0], args[1])
        }
    };
    let rows = (|| {
        let difference = end.checked_sub(start)?;
        let rows = match cursor.template().primitive() {
            mech_engine::native_artifact::NativeCollectionPrimitive::RangeExclusive => difference,
            mech_engine::native_artifact::NativeCollectionPrimitive::RangeInclusive => difference.checked_add(1)?,
            _ => return None,
        };
        (rows != 0).then_some(rows)
    })();
    let Some(rows) = rows else { return Ok(None) };
    if rectangle.fixed().is_some_and(|fixed| fixed != [start, end, rows]) {
        return Err(invalid("fixed rectangle cardinality differs"));
    }
    Ok(Some(Geometry { start, end, rows }))
}
''')
s=s.replace('''pub(super) fn bound(descriptor: &NativeProgramDescriptor, region: &Region) -> Option<Bound> {''','''pub(super) fn bound(
    descriptor: &NativeProgramDescriptor,
    region: &Region,
    geometry: Geometry,
) -> Option<Bound> {''')
s=s.replace('rectangle.rows','geometry.rows').replace('rectangle.start','geometry.start').replace('rectangle.end','geometry.end')
s=s.replace('''    let output = rectangle
        .rows''','''    let output = geometry
        .rows''')
s=s.replace('''    region: &Region,
    bound: &Bound,''','''    region: &Region,
    geometry: Geometry,
    bound: &Bound,''')
s=s.replace('''    if mech_core::shape_for_resolved_extents(input.definition(), &[1, geometry.rows]).is_err()
        || mech_core::shape_for_resolved_extents(''','''    if mech_core::shape_for_resolved_extents(cursor.template().output(), &[1, geometry.rows]).is_err()
        || mech_core::shape_for_resolved_extents(input.definition(), &[1, geometry.rows]).is_err()
        || transpose.template().inputs().first().is_none_or(|input| {
            mech_core::shape_for_resolved_extents(input, &[1, geometry.rows]).is_err()
        })
        || mech_core::shape_for_resolved_extents(''')
p.write_text(s)
change(base+'runtime/collections/mod.rs','''mod numeric_rectangles;''','''mod numeric_rectangles;
pub(in crate::native_artifact::program::runtime) use numeric_rectangles::Geometry as NumericRectangleGeometry;''')
p=root/(base+'runtime/collections/numeric_map.rs');s=p.read_text()
s=s.replace('''    pub matrices: [MatrixView; MAX_MATRICES],\n}''','''    pub matrices: [MatrixView; MAX_MATRICES],
    pub rectangle_start: u64,
    pub rectangle_rows: u64,
}''',1)
s=s.replace('''        retirements: &[u32],
    ) -> Result<Option<u64>, Error> {''','''        retirements: &[u32],
        args: [u64; 3],
    ) -> Result<Option<(u64, super::NumericRectangleGeometry)>, Error> {''',1)
assert 'Result<Option<(u64, super::NumericRectangleGeometry)>' in s
needle='''        let credit = (|| {
            let mut visits = 0u64;'''
assert s.count(needle)==1
s=s.replace(needle,'''        // An unused inner source must not be evaluated when the outer range
        // is empty. In particular, invalid current endpoints remain unused.
        if source.count == 0 && region.rectangle.is_some() {
            return Ok(None);
        }
        let Some(geometry) = super::numeric_rectangles::resolve(descriptor, region, args)? else {
            return Ok(None);
        };
        let credit = (|| {
            let mut visits = 0u64;''')
s=s.replace('''super::numeric_rectangles::bound(descriptor, region)?''','''super::numeric_rectangles::bound(descriptor, region, geometry)?''')
s=s.replace('''.checked_mul(region.rectangle.as_ref().map_or(1, |r| r.rows))?''','''.checked_mul(geometry.rows)?''')
s=s.replace('''        Ok(credit)
    }''','''        Ok(credit.map(|credit| (credit, geometry)))
    }''',1)
s=s.replace('''        replay_credit: u64,
    ) -> Result<Option<u64>, Error> {''','''        replay_credit: u64,
        rectangle_geometry: super::NumericRectangleGeometry,
    ) -> Result<Option<u64>, Error> {''',1)
s=s.replace('''source_count.checked_mul(region.rectangle.as_ref().map_or(1, |r| r.rows))''','''source_count.checked_mul(rectangle_geometry.rows)''')
s=s.replace('''super::numeric_rectangles::bound(ctx.descriptor(), region)''','''super::numeric_rectangles::bound(ctx.descriptor(), region, rectangle_geometry)''')
s=s.replace('''        if let Some(rectangle) = &region.rectangle {
            if builder.block_columns''','''        if region.rectangle.is_some() {
            if builder.block_columns''')
s=s.replace('''rows != rectangle.rows''','''rows != rectangle_geometry.rows''')
s=s.replace('''super::numeric_rectangles::validate(ctx, region, &rectangle)?''','''super::numeric_rectangles::validate(ctx, region, rectangle_geometry, &rectangle)?''')
s=s.replace('''            range_start,
            matrices,
        };''','''            range_start,
            matrices,
            rectangle_start: rectangle_geometry.start,
            rectangle_rows: rectangle_geometry.rows,
        };''')
s=s.replace('''            .map(|r| r.rows);''','''            .map(|_| loan.expected.rectangle_rows);''')
p.write_text(s)
p=root/(base+'runtime/invocation/numeric_map.rs');s=p.read_text()
s=s.replace('''        let replay_credit = if tag == GlobalHelper::NumericMapPrepare {''','''        let replay = if tag == GlobalHelper::NumericMapPrepare {''',1)
s=s.replace('''            let Some(credit) = self''','''            let Some((credit, geometry)) = self''',1)
s=s.replace('''.numeric_replay_credit(self.descriptor, region, self.retirements)?''','''.numeric_replay_credit(self.descriptor, region, self.retirements, args)?''',1)
s=s.replace('''            Some(credit)
        } else''','''            Some((credit, geometry))
        } else''',1)
s=s.replace('''                    if args != [0; 3] {
                        return Err(invalid("native numeric map entry has payload"));
                    }
                    collections''','''                    let (credit, geometry) = replay.unwrap();
                    collections''',1)
s=s.replace('''                            replay_credit.unwrap(),''','''                            credit,
                            geometry,''',1)
p.write_text(s)
print('source preparation and runtime edits written')
