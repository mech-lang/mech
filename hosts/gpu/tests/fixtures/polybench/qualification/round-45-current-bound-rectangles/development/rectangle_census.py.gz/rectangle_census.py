"""Debugger-only source callback census of accepted44 and the qualified current-bound rectangle candidate."""
import collections
import json
from pathlib import Path
import lldb

folder = Path(__file__).resolve().parent
hits = []
roles = {}

def on_hit(frame, location, _):
    register = frame.FindRegister('x2')
    assert register.IsValid()
    hits.append({
        'kind': roles[location.GetBreakpoint().GetID()],
        'site': register.GetValueAsUnsigned(),
        'site_register':'x2',
        'function': frame.GetFunctionName() or frame.GetSymbol().GetName(),
    })
    return False

def run():
    global hits, roles
    config = json.loads((folder/'census-config.json').read_text())
    debugger = lldb.debugger
    debugger.SetAsync(False)
    receipt = {'scope':'Correlation optimization-only accepted44/candidate callback census; zero kernel timing samples. Actual current JIT entry, numeric maps, inner transpose and collection callbacks.', 'drivers':config['drivers'], 'cases':{}, 'complete':False}
    try:
        for name,case in config['cases'].items():
            hits = []
            roles = {}
            target = debugger.CreateTarget(case['driver'])
            assert target.IsValid()
            breakpoints = {}
            for kind,pattern in [('map','numeric_map_helper$'),('transpose','runtime::invocation::.*finish_numeric_transpose$'),('collection','collection_helper$'),('generic','canonical_library_call$')]:
                bp = target.BreakpointCreateByRegex(pattern)
                assert bp.GetNumLocations()==1, (name,kind,bp.GetNumLocations())
                bp.SetScriptCallbackFunction('rectangle_census.on_hit')
                roles[bp.GetID()] = kind
                breakpoints[kind] = bp.GetNumLocations()
            out = folder/(name+'-driver.stdout')
            err = folder/(name+'-driver.stderr')
            launch = lldb.SBLaunchInfo([case['source'],case['inputs'],'0'])
            launch.SetWorkingDirectory(config['worktree'])
            assert launch.AddOpenFileAction(1,str(out),False,True)
            assert launch.AddOpenFileAction(2,str(err),False,True)
            error = lldb.SBError()
            process = target.Launch(launch,error)
            row = {'breakpoint_locations':breakpoints,'hits':hits,'launch_error':error.GetCString(),'state':process.GetState(),'exit_code':process.GetExitStatus()}
            receipt['cases'][name] = row
            (folder/'admission-census.json').write_text(json.dumps(receipt,indent=2)+'\n')
            assert error.Success(), str(error)
            assert process.GetState()==lldb.eStateExited and process.GetExitStatus()==0, row
            result = json.loads(out.read_text().strip().splitlines()[-1])
            assert result['status']=='ok' and result['samples_seconds']==[]
            row['driver_values'] = result['values']
            row['execution_report'] = result['report']
            row['timing_samples'] = 0
            row['counts_by_site'] = {kind:dict(collections.Counter(str(h['site']) for h in hits if h['kind']==kind)) for kind in ('map','transpose','collection','generic')}
            print(name,'callback counts',row['counts_by_site'])
            debugger.DeleteTarget(target)
        receipt['complete'] = True
    finally:
        (folder/'admission-census.json').write_text(json.dumps(receipt,indent=2)+'\n')
