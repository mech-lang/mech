import gzip, hashlib, importlib.util, json
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
q=b.read(folder/'qualification.json');r=b.read(folder/'execution-route-census.json');fp=b.compiler_fingerprint()
assert q['complete'] and q['tests']==709 and q['focused_checks']['passed_tests']==[91]
assert fp==q['compiler_fingerprint']==r['compiler_fingerprint']
assert b.digest(q['driver'])==q['driver_sha256']==r['driver_sha256']
assert r['prospective_route_gate_passed'] and not r['v2_counter_guard_passed'] and r['performance_observations']==0
h=b.read(b.FIXTURE/'performance-history.json')['entries'];assert len(h)==45
proposal={
 'schema':'mech.polybench.training-selection-policy-proposal.v3', 'created_at':b.utc(),
 'status':'Proposed; not adopted. No performance measurements authorized by this proposal yet.',
 'candidate_compiler_fingerprint':fp, 'candidate_driver_sha256':q['driver_sha256'],
 'reason':'The precommitted v2 counter guard rejects legitimate source-derived fusion because actual runtime control visits and work/comparison counters decrease when repeated pure range/builder/transpose/publication paths are removed. The qualified source executes the same ordered scalar body and finite C liveouts; retaining fictitious physical visits would misreport the implementation.',
 'concrete_evidence':{'broad_tests':709,'focused_tests':91,'finite_c_liveouts_for_census':784,'accepted44':{k:r['cases']['accepted44']['execution_counters'][k] for k in ['work','comparison_work','visits']},'candidate':{k:r['cases']['candidate']['execution_counters'][k] for k in ['work','comparison_work','visits']},'repeated_inner_map_callbacks_before':56,'rectangle_prepare_finish_callbacks_after':2,'inner_transpose_callbacks_before':28,'inner_transpose_callbacks_after':0,'candidate_timing_samples':0},
 'proposed_counter_gate':[
  'Before any performance probe, run an untimed optimization15 current-input C-liveout and execution-counter census against accepted44. Preserve every actual counter and delta; never fabricate or pad visits.',
  'Keep the v2 equal-visits/nondecreasing-work check for unchanged executed source paths. Permit lower visit/work/comparison counters only for a source-derived private fusion proved by the independently rederived exact descriptor, actual selected callbacks and unchanged ordered numeric body/read/branch/error semantics.',
  'Require the full original selected-factory/range/builder/transpose/source replay, physical/coexistence and finite admission bounds before lending current storage. Existing source logical floors remain. A lower actual bookkeeping counter is not permission to lower these required envelopes or skip required effects.',
  'Reject unexplained counter deltas, changed liveouts, missing source work, changed error ordering, omitted checks or weakened resource/owner/publication guarantees. All other execution/transport counters must match.',
  'Retain original/decoded/restored differential tests, all scalar bits, current input/alias checks, finite/cold/replay/shared ledger denial and retry, partial error atomicity and tampered proof/frame rejection.'
 ],
 'unchanged_training_measurement':'Exactly one prospective optimization15 probe per qualified fingerprint:7 fresh processes per actor/case, interleaved accepted44/candidate with alternating order;210 observations, no retries/exclusions. Select only raw equal-weight GM accepted44/candidate median-runtime speedup >1 after the counter proof gate.',
 'unchanged_formal_acceptance':'Commit/push and freeze exact clean selected source and driver before BOTH formal sets. All900 observations and29482 finite liveouts retained. Accept only if BOTH primary kernel GM Mech/C scores strictly improve accepted44:10.24618089248072 /38.46047945936111. Restore exact accepted44 on rejection. Controls cannot override either score.',
 'unchanged_benchmark_protocol':'No change to all30 ports/inputs, C binaries/flags, MINI F64 CPU, finite limits/tolerances, fixed15/15 split, profiling/selection on optimization15 only, cache/timing boundaries, metric/goal or prior history. No prior rejected candidate is reclassified or remeasured.',
 'requires_decision':'Whether the research selection guard should permit independently source-proved fusion with honestly lower physical control/bookkeeping counters.',
 'performance_observations':0
}
b.write(folder/'selection-policy-proposal.json',proposal)
b.write(b.FIXTURE/'training-experiments/current-bound-rectangles-selection-proposal.json',proposal)
state=b.read(folder/'current-work.json');state.update(stage='Qualified current-bound rectangle compiler and actual source census complete; v2 counter guard fails before performance sampling',live_exec_session=None,complete=True,prospective_route_gate_passed=True,v2_counter_guard_passed=False,new_performance_observations=0,next='Preserve and push the exact qualified compiler/evidence checkpoint. Resolve the proposed source-proved-fusion selection gate before any training timing. Accepted44 remains the accepted performance baseline and holdout goal is unmet.');b.write(folder/'current-work.json',state)
dest=b.FIXTURE/'qualification/round-45-current-bound-rectangles/development';dest.mkdir(parents=True,exist_ok=False)
archives={}
for path in sorted(folder.rglob('*')):
 if not path.is_file() or '__pycache__' in path.parts or path.name=='current-bound-rectangles-driver':continue
 name=str(path.relative_to(folder));raw=path.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives[name]={'path':str(out.relative_to(b.FIXTURE)),'sha256':hashlib.sha256(raw).hexdigest(),'compressed_sha256':b.digest(out)}
receipt={'schema':'mech.polybench.current-bound-rectangles-development.v1','created_at':b.utc(),'scope':'Optimization15 source-fusion qualification only; no holdout diagnosis and no candidate kernel timing samples.','compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'versions':q['versions'],'source_parent':q['source_parent'],'qualification':q,'execution_route_census':r,'selection_status':'v2 counter guard failed before timing; proposed v3 source-proof gate is not adopted.','candidate_performance_observations':0,'formal_history_entries_unchanged':45,'accepted_round':44,'accepted_scores':{part:h[-1]['aggregates'][part]['geomean_mech_over_c_kernel'] for part in ['optimization','holdout']},'archives':archives}
b.write(b.FIXTURE/'training-experiments/current-bound-rectangles-development.json',receipt)
assert fp==b.compiler_fingerprint()
print(json.dumps({'archives':len(archives),'broad':709,'focused':91,'v2_counter_guard':False,'performance_observations':0,'compiler_fingerprint':fp}))
