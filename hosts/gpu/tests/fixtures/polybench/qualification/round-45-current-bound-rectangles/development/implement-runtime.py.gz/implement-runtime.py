from pathlib import Path
root=Path.cwd()
base='hosts/gpu/src/native_artifact/program/'
p=root/(base+'runtime/collections/numeric_map.rs');s=p.read_text()
s=s.replace('''    pub matrices: [MatrixView; MAX_MATRICES],\n}''','''    pub matrices: [MatrixView; MAX_MATRICES],
    pub rectangle_start: u64,
    pub rectangle_rows: u64,
}''',1)
s=s.replace('''        retirements: &[u64],
    ) -> Result<Option<u64>, Error> {''','''        retirements: &[u64],
        args: [u64; 3],
    ) -> Result<Option<(u64, super::NumericRectangleGeometry)>, Error> {''',1)
assert 'Result<Option<(u64, super::NumericRectangleGeometry)>' in s
needle='''        let credit = (|| {
            let mut visits = 0u64;'''
assert s.count(needle)==1
s=s.replace(needle,'''        // An unused inner source must not be evaluated when the outer range
        // is empty. In particular, invalid current endpoints remain unused.
        if source.count == 0 && region.rectangle.is_some() {
            return Ok(None);
        }
        let Some(geometry) = super::numeric_rectangles::resolve(descriptor, region, args)? else {
            return Ok(None);
        };
        let credit = (|| {
            let mut visits = 0u64;''')
s=s.replace('''super::numeric_rectangles::bound(descriptor, region)?''','''super::numeric_rectangles::bound(descriptor, region, geometry)?''')
s=s.replace('''.checked_mul(region.rectangle.as_ref().map_or(1, |r| r.rows))?''','''.checked_mul(geometry.rows)?''')
s=s.replace('''        Ok(credit)
    }''','''        Ok(credit.map(|credit| (credit, geometry)))
    }''',1)
s=s.replace('''        replay_credit: u64,
    ) -> Result<Option<u64>, Error> {''','''        replay_credit: u64,
        rectangle_geometry: super::NumericRectangleGeometry,
    ) -> Result<Option<u64>, Error> {''',1)
s=s.replace('''source_count.checked_mul(region.rectangle.as_ref().map_or(1, |r| r.rows))''','''source_count.checked_mul(rectangle_geometry.rows)''')
s=s.replace('''super::numeric_rectangles::bound(ctx.descriptor(), region)''','''super::numeric_rectangles::bound(ctx.descriptor(), region, rectangle_geometry)''')
s=s.replace('''        if let Some(rectangle) = &region.rectangle {
            if builder.block_columns''','''        if region.rectangle.is_some() {
            if builder.block_columns''')
s=s.replace('''rows != rectangle.rows''','''rows != rectangle_geometry.rows''')
s=s.replace('''super::numeric_rectangles::validate(ctx, region, &rectangle)?''','''super::numeric_rectangles::validate(ctx, region, rectangle_geometry, &rectangle)?''')
s=s.replace('''            range_start,
            matrices,
        };''','''            range_start,
            matrices,
            rectangle_start: rectangle_geometry.start,
            rectangle_rows: rectangle_geometry.rows,
        };''')
s=s.replace('''            .map(|r| r.rows);''','''            .map(|_| loan.expected.rectangle_rows);''')
p.write_text(s)
p=root/(base+'runtime/invocation/numeric_map.rs');s=p.read_text()
s=s.replace('''        let replay_credit = if tag == GlobalHelper::NumericMapPrepare {''','''        let replay = if tag == GlobalHelper::NumericMapPrepare {''',1)
s=s.replace('''            let Some(credit) = self''','''            let Some((credit, geometry)) = self''',1)
s=s.replace('''.numeric_replay_credit(self.descriptor, region, self.retirements)?''','''.numeric_replay_credit(self.descriptor, region, self.retirements, args)?''',1)
s=s.replace('''            Some(credit)
        } else''','''            Some((credit, geometry))
        } else''',1)
s=s.replace('''                    if args != [0; 3] {
                        return Err(invalid("native numeric map entry has payload"));
                    }
                    collections''','''                    let (credit, geometry) = replay.unwrap();
                    collections''',1)
s=s.replace('''                            replay_credit.unwrap(),''','''                            credit,
                            geometry,''',1)
p.write_text(s)
print('source preparation and runtime edits written')
