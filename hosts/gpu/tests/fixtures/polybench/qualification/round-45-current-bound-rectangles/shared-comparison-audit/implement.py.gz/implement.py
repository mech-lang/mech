from pathlib import Path
root=Path.cwd();base='hosts/gpu/src/native_artifact/program/'
def change(name,old,new,count=1):
 p=root/(base+name);s=p.read_text();assert s.count(old)==count,(name,s.count(old),old[:100]);p.write_text(s.replace(old,new))
change('runtime/collections/mod.rs','''mod numeric_transposes;''','''mod numeric_transpose_budget;
mod numeric_transposes;''')
p=root/(base+'runtime/collections/numeric_transposes.rs');s=p.read_text();start=s.index('''        let Some((
            envelope,''');end=s.index('''        let total_temporary =''',start)
s=s[:start]+'''        let Ok(output_bytes) = builder.values.output_bytes(
            builder.payload_bytes,
            count,
            builder.values.capacity(),
            source.definition().dimension_parameters().len(),
        ) else { return Ok(None) };
        let Some(super::numeric_transpose_budget::Funding {
            envelope, temporary, cloned, compute, setup, replay, output_bound, nodes, comparison,
        }) = super::numeric_transpose_budget::bound(
            descriptor,
            projection.transpose,
            &projection.continuation,
            super::numeric_transpose_budget::Row {
                count,
                width: region.output_width,
                capacity_bytes: builder.reservation.capacity_bytes(),
                finalization_cloned: builder.values.finalization_cloned_bytes(builder.payload_bytes),
                output_bytes,
            },
        ) else { return Ok(None) };
        let Some(nodes) = prior.retained_nodes.checked_add(retained).and_then(|n| n.checked_add(nodes)) else {
            return Ok(None);
        };
'''+s[end:];p.write_text(s)
p=root/(base+'runtime/collections/numeric_rectangles.rs');s=p.read_text();s=s.replace('''    pub setup: u64,
    pub replay: u64,''','''    /// Complete selected transpose source fees for one original inner row.
    pub setup: u64,
    pub compute: u64,
    pub cloned: u64,
    pub replay: u64,''')
start=s.index('''    let mut bytes = 0u64;''');end=s.index('''    // Keep a full ordinary construction''',start)
s=s[:start]+'''    let range = metadata.calls.get(rectangle.range_prepare as usize)?.as_ref()?;
    let bytes = range.binding_metadata_bytes();
    let work = range.binding_work();
    let definition = metadata.plan.values()[metadata.plan.collections()[rectangle.inner_collection as usize].output().get() as usize].definition();
    let values = data::CollectedValues::new(definition.body());
    if values.packed_width() != Some(u64::from(region.output_width)) { return None; }
    let payload = geometry.rows.checked_mul(u64::from(region.output_width))?;
    // The ordinary growing packed bank has capacity<4*n plus its initial
    // four-word bank. This bounds both exact native and ordinary cold rows.
    // Only empty type metadata is created here; no row payload is allocated.
    let capacity = geometry.rows.checked_add(4)?.checked_mul(4)?;
    let transpose = super::numeric_transpose_budget::bound(
        descriptor,
        rectangle.transpose,
        &region.sites,
        super::numeric_transpose_budget::Row {
            count: geometry.rows,
            width: region.output_width,
            capacity_bytes: capacity.checked_mul(u64::from(region.output_width))?,
            finalization_cloned: payload,
            output_bytes: values.output_bytes(payload, geometry.rows, usize::try_from(capacity).ok()?, definition.dimension_parameters().len()).ok()?,
        },
    )?;
'''+s[end:]
old='''    Some(Bound {
        temporary,
        nodes,
        output,
        // The elided transpose retains its original conservative comparison
        // admission even when its private output is never materialized.
        comparison: output,
        setup,
        replay,
    })'''
new='''    Some(Bound {
        temporary: temporary.checked_add(transpose.temporary)?.checked_add(transpose.envelope)?,
        nodes: nodes.checked_add(transpose.nodes)?,
        output: output.max(transpose.output_bound),
        // Reuse the ordinary row price even though no transpose Value exists.
        comparison: transpose.comparison,
        setup: setup.checked_add(transpose.setup)?,
        compute: transpose.compute,
        cloned: transpose.cloned,
        replay: replay.checked_add(transpose.replay)?,
    })'''
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
p=root/(base+'runtime/collections/numeric_map.rs');s=p.read_text()
needle='''        let Some(nested_comparison) = count.checked_mul(nested.comparison) else {
            return Ok(None);
        };'''
assert s.count(needle)==1
s=s.replace(needle,needle+'''
        let Some(rectangle_comparison) = source_count.checked_mul(rectangle.comparison) else {
            return Ok(None);
        };''')
needle='''                    .checked_add(nested.compute)?,
            )?;''';assert s.count(needle)==1
s=s.replace(needle,'''                    .checked_add(nested.compute)?,
            )?.checked_add(source_count.checked_mul(rectangle.compute)?)?;''')
needle='''                .checked_add(count.checked_mul(nested.cloned)?)?;''';assert s.count(needle)==1
s=s.replace(needle,'''                .checked_add(count.checked_mul(nested.cloned)?)?
                .checked_add(source_count.checked_mul(rectangle.cloned)?)?;''')
needle='''                .checked_add(rectangle.setup)?''';assert s.count(needle)==1
s=s.replace(needle,'''                .checked_add(source_count.checked_mul(rectangle.setup)?)?''')
needle='''            || rectangle
                .comparison
                .checked_add(reduction.comparison)''';assert s.count(needle)==1
s=s.replace(needle,'''            || rectangle_comparison
                .checked_add(reduction.comparison)''')
needle='''                    || nested_comparison
                        .checked_mul(2)
                        .and_then(|n| n.checked_add(reduction.comparison))''';assert s.count(needle)==1
s=s.replace(needle,'''                    || nested_comparison
                        .checked_mul(2)
                        .and_then(|n| rectangle_comparison.checked_mul(2)?.checked_add(n))
                        .and_then(|n| n.checked_add(reduction.comparison))''')
needle='''        charge(&mut ctx.work(), setup)?;
        if !super::numeric_rectangles::validate''';assert s.count(needle)==1
s=s.replace(needle,'''        charge(&mut ctx.work(), setup)?;
        // Eliding a row's transpose cannot renew or bypass its source fee.
        // This exact shared account retains fuel for the full ordinary replay
        // if metadata validation or the checked private kernel declines.
        ctx.library().charge(0, rectangle_comparison).map_err(|error| {
            crate::native_artifact::NativeExecutionError::LibraryWork {
                phase: Phase::Setup,
                error,
            }
        })?;
        if !super::numeric_rectangles::validate''');p.write_text(s)
change('image/identity.rs','''// Policy156 retains complete ordered-sum source costs and ordinary replay.
pub const NATIVE_PROGRAM_WORK_POLICY_VERSION: u64 = 156;''','''// Policy157 retains complete rectangular row-transpose fees on the same shared
// comparison account, including current admission and failed-attempt replay.
pub const NATIVE_PROGRAM_WORK_POLICY_VERSION: u64 = 157;''')
print('shared ordinary transpose funding and rectangular comparison fees written')
