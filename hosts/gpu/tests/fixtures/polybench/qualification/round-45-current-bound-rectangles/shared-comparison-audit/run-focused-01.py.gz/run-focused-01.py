import gzip, hashlib, importlib.util, json, os, re, subprocess, time
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent;attempt=folder/'attempt-01';attempt.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
fp=b.compiler_fingerprint()
paths=sorted(set(subprocess.check_output(['git','ls-files','-mo','--exclude-standard'],text=True).splitlines()))
paths=[p for p in paths if p.endswith(('.rs','.toml')) or Path(p).name=='Cargo.lock']
source={}
for name in paths:
 raw=(root/name).read_bytes();out=attempt/'source'/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));source[name]=hashlib.sha256(raw).hexdigest()
(attempt/'source.patch.gz').write_bytes(gzip.compress(subprocess.check_output(['git','diff','--binary']),mtime=0))
state={'stage':'Spent shared comparison-fuel regression against pre-fix production code; expected failure; no timing observations','pid':os.getpid(),'live_exec_session':None,'source_parent':b.command(['git','rev-parse','HEAD']),'compiler_fingerprint':fp,'source_paths':source,'versions':{'ir':410,'work':156,'abi':47},'accepted_round':44,'formal_history_entries':45,'accepted_scores':{'optimization':10.24618089248072,'holdout':38.46047945936111},'next':'Wait for exact Cargo session. No Rust edits or concurrent builds/tests/profiles/timings. Preserve failure before correction. Confirm pre-fix shared-ledger failure; no policy adoption or performance sampling.'}
b.write(attempt/'source-checkpoint.json',state);b.write(folder/'current-work.json',state)
env=os.environ.copy();env['CARGO_TARGET_DIR']='/private/tmp/mech-polybench-pr1000-target';env['RUST_BACKTRACE']='1';env.pop('PERF_BUILDID_DIR',None)
command=['cargo','test','--release','-p','mech-gpu','--no-default-features','--features','canonical-native-program','--lib','--','rectangular_numeric_maps_spent_shared_comparison_fuel','--test-threads=1','--nocapture']
start=time.monotonic()
with (attempt/'focused.log').open('x') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
log=(attempt/'focused.log').read_text();result={'command':command,'exit_code':r.returncode,'wall_seconds':time.monotonic()-start,'compiler_fingerprint':fp,'source_unchanged':b.compiler_fingerprint()==fp,'passed_tests':[int(x) for x in re.findall(r'test result: ok[.] (\d+) passed',log)],'complete':True}
b.write(attempt/'focused-result.json',result);state.update(stage='Spent-fuel regression completed' if r.returncode==0 else 'Spent-fuel regression reproduced; preserve failure before production correction',result=result,live_exec_session=None);b.write(folder/'current-work.json',state);print(json.dumps(result),flush=True);raise SystemExit(r.returncode)
