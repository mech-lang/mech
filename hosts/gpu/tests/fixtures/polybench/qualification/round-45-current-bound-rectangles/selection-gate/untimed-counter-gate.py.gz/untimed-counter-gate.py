"""All15 source-fee/current-input gate, with no checked-call timing samples."""
import importlib.util,json,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
plan=b.read(folder/'plan.json');policy=b.read(b.FIXTURE/'training-experiments/current-bound-rectangles-training-policy-v3.json');q=b.read(b.FIXTURE/'training-experiments/current-bound-rectangles-shared-comparison.json')['qualification_manifest']
profiles=b.read('/private/tmp/mech-polybench-optimization/round-45/accepted44-long-training-profile/training-profile.json');assert profiles['complete']
fp=b.compiler_fingerprint();assert fp==q['compiler_fingerprint']==plan['compiler_fingerprint']==policy['candidate_compiler_fingerprint']
assert b.digest(b.FIXTURE/'training-experiments/current-bound-rectangles-training-policy-v3.json')==plan['policy_sha256']
protocol,cases=b.protocol();reference=b.read(b.FIXTURE/'round-44-training-probe.json')
actors={'accepted44':Path(plan['accepted_driver']),'candidate':Path(plan['candidate_driver'])}
assert all(b.digest(path)==plan[('accepted' if actor=='accepted44' else 'candidate')+'_driver_sha256'] for actor,path in actors.items())
assert len(b.read(b.FIXTURE/'performance-history.json')['entries'])==45
output=folder/'untimed-counter-gate.json';assert not output.exists()
def counters(report):
    prefix='NativeProgramExecutionReport { ';assert report.startswith(prefix) and report.endswith(' }')
    return {k:int(v) for k,v in [part.split(': ') for part in report[len(prefix):-2].split(', ')]}
proof=b.read('/private/tmp/mech-polybench-optimization/round-45/current-bound-rectangles-shared-comparison/execution-route-census.json')
old_image=Path('/private/tmp/mech-polybench-optimization/round-45/accepted44-margin-profile/correlation-image.json');new_image=Path('/private/tmp/mech-polybench-optimization/round-45/current-bound-rectangles-shared-comparison/correlation-image.json')
def prove_visit_reduction(name, row):
    if row['deltas']['visits']==0:return {'proved':True,'kind':'unchanged'}
    if name!='correlation' or row['deltas']['visits']>=0:return {'proved':False,'reason':'No matching preregistered actual callback/source proof'}
    old=b.read(old_image)['descriptor'];new=b.read(new_image)['descriptor'];region=proof['selected_rectangle'];rectangle=region['rectangle']
    assert proof['complete'] and proof['prospective_route_gate_passed'] and proof['compiler_fingerprint']==fp
    assert proof['driver_sha256']==q['driver_sha256'] and proof['performance_observations']==0
    assert old['plan']==new['plan']
    inner=next(r for r in old['numeric_maps']['regions'] if r['iteration']==rectangle['inner_iteration'])
    assert 'Current' in rectangle['bounds'] and all(region[key]==inner[key] for key in ['body','steps','reads','matrices','nested','result','input_width','output_width'])
    assert set(inner['sites'])<=set(region['sites'])
    for actor in actors:assert row['actors'][actor]['counters']==proof['cases'][actor]['execution_counters']
    assert proof['cases']['candidate']['counts_by_site']['map'][str(region['header'])]==2
    assert str(inner['header']) not in proof['cases']['candidate']['counts_by_site']['map']
    assert proof['cases']['candidate']['counts_by_site']['transpose']=={}
    return {'proved':True,'kind':'source-derived current-bound rectangle','receipt':'training-experiments/current-bound-rectangles-shared-comparison.json','old_image_sha256':b.digest(old_image),'new_image_sha256':b.digest(new_image),'source_plan_identical':True,'ordered_body_steps_reads_matrices_and_nested_regions_identical':True,'all_inner_source_sites_covered':True,'actual_callbacks':{a:proof['cases'][a]['counts_by_site'] for a in actors},'region':region}
r={'schema':'mech.polybench.untimed-counter-gate.v3','created_at':b.utc(),'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'scope':'Optimization15 current-input C-liveout and source-counter proof only. No holdout performance/source diagnosis.','policy_sha256':plan['policy_sha256'],'cases':{},'complete':False,'performance_observations':0};b.write(output,r)
for index,name in enumerate(protocol['optimization']):
    config=folder/f'{name}-inputs.json';b.write(config,cases[name]['inputs']);row={'source_sha256':b.digest(b.FIXTURE/f'{name}.mec'),'inputs_sha256':b.digest(config),'actors':{}}
    r['cases'][name]=row
    for actor in (list(actors) if index%2==0 else list(reversed(actors))):
        argv=[str(actors[actor]),str(b.FIXTURE/f'{name}.mec'),str(config),'0']
        stdout=folder/f'{name}-{actor}-untimed.stdout';stderr=folder/f'{name}-{actor}-untimed.stderr'
        with stdout.open('x') as out,stderr.open('x') as err:
            child=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err)
            r['pending']={'case':name,'actor':actor,'pid':child.pid,'command':argv};b.write(output,r)
            while True:
                try:code=child.wait(timeout=30);break
                except subprocess.TimeoutExpired:print('Waiting on same untimed gate process',child.pid,flush=True)
        row['actors'][actor]={'command':argv,'pid':child.pid,'exit_code':code,'stdout_sha256':b.digest(stdout),'stderr_sha256':b.digest(stderr)};r.pop('pending');b.write(output,r);assert code==0
        result=json.loads(stdout.read_text().strip().splitlines()[-1]);assert result['status']=='ok' and result['samples_seconds']==[]
        row['actors'][actor].update(counters=counters(result['report']),execution_report=result['report'],validation=b.validate(result['values'],cases[name]['expected']),timing_samples=0)
        if actor=='accepted44':assert result['report']==reference['cases'][name]['actors']['candidate']['execution_report']
    a=row['actors']['accepted44']['counters'];c=row['actors']['candidate']['counters'];assert set(a)==set(c)
    row['deltas']={key:c[key]-value for key,value in a.items()}
    row['work_not_reduced']=c['work']>=a['work'] and c['comparison_work']>=a['comparison_work']
    row['other_counters_match']=all(delta==0 for key,delta in row['deltas'].items() if key not in ['work','comparison_work','visits'])
    row['visit_proof']=prove_visit_reduction(name,row);row['passed']=row['work_not_reduced'] and row['other_counters_match'] and row['visit_proof']['proved'];b.write(output,r)
    print(name,'counter gate',row['passed'],'visit delta',row['deltas']['visits'],flush=True)
r.update(complete=True,completed_at=b.utc(),passed=len(r['cases'])==15 and all(row['passed'] for row in r['cases'].values()),finite_liveouts=sum(row['actors']['candidate']['validation']['count'] for row in r['cases'].values()),source_and_driver_unchanged=b.compiler_fingerprint()==fp and b.digest(actors['candidate'])==q['driver_sha256'])
assert r['source_and_driver_unchanged'];b.write(output,r);print(json.dumps({key:r[key] for key in ['complete','passed','finite_liveouts','performance_observations']}),flush=True)
