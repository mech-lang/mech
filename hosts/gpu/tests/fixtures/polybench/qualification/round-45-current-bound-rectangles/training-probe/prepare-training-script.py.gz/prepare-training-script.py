from pathlib import Path
source=Path('/private/tmp/mech-polybench-optimization/round-44/prepared-composite-binding/training-probe.py').read_text()
s=source.replace('accepted31','accepted44').replace("'accepted_round':31", "'accepted_round':44").replace('round-31/inverse-bitcasts/bitcast-driver','round-44/prepared-composite-binding/prepared-composite-driver').replace("'round-31-frozen.json'", "'round-44-frozen.json'")
start=s.index('policy=');end=s.index('\nplan=',start)
s=s[:start]+'''adopted=b.read(b.FIXTURE/'training-experiments/current-bound-rectangles-training-policy-v3.json')
policy={'schema':'mech.polybench.training-selection-policy.v3','scope':'Optimization15 only; no holdout performance or per-case diagnosis.','accepted_round':44,'samples_per_actor':7,'actors':['accepted44','candidate'],'sampling':'A new driver process for each single checked-call sample; interleave actors within each pair, alternating order by case and pair. Same cache flush, warmup, finite limits and checked-call timer as formal evaluation.','selection':'Exactly one prospective probe per fully qualified fingerprint. Select only raw equal-weight GM accepted44/candidate median-runtime speedup >1 after the preregistered untimed source/fee/visit gate. Original work/comparison fees must not decrease; visit reductions require the preserved source/callback proof. All210 observations/regressions retained, no retries/exclusions.','formal_gate':adopted['formal_acceptance'],'benchmark_protocol_unchanged':True,'observations':210,'adopted_policy_sha256':b.digest(b.FIXTURE/'training-experiments/current-bound-rectangles-training-policy-v3.json')}
'''+s[end:]
needle="output=folder/'training-probe.json';assert not output.exists(), 'Never overwrite or resume an observed probe.'"
assert s.count(needle)==1
s=s.replace(needle,"""gate=b.read(folder/'untimed-counter-gate.json');assert gate['complete'] and gate['passed'] and gate['compiler_fingerprint']==fp and gate['driver_sha256']==q['driver_sha256'] and gate['performance_observations']==0
assert b.read('/private/tmp/mech-polybench-optimization/round-45/accepted44-long-training-profile/training-profile.json')['complete']
"""+needle)
old="  process=subprocess.run(argv,capture_output=True,text=True,timeout=180);assert process.returncode==0,process.stderr\n  result=json.loads(process.stdout.strip().splitlines()[-1]);assert result['status']=='ok';sample,=result['samples_seconds'];assert math.isfinite(sample) and sample>0"
new="""  stdout=folder/f'{name}-pair{row["pair"]}-{label}.stdout';stderr=folder/f'{name}-pair{row["pair"]}-{label}.stderr'
  with stdout.open('x') as out,stderr.open('x') as err:
   child=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err);r['pending_observation']['pid']=child.pid;b.write(output,r)
   while True:
    try:code=child.wait(timeout=30);break
    except subprocess.TimeoutExpired:print('Waiting on same observed driver process',child.pid,flush=True)
  assert code==0,stderr.read_text()
  result=json.loads(stdout.read_text().strip().splitlines()[-1]);assert result['status']=='ok';sample,=result['samples_seconds'];assert math.isfinite(sample) and sample>0
  assert result['report']==gate['cases'][name]['actors'][label]['execution_report']
"""
assert s.count(old)==1;s=s.replace(old,new)
needle="item.update(execution_counter_deltas=delta,all_counters_match=all(v==0 for v in delta.values()),visits_match=delta['visits']==0,work_not_reduced=delta['work']>=0 and delta['comparison_work']>=0)"
new="item.update(execution_counter_deltas=delta,all_counters_match=all(v==0 for v in delta.values()),visits_match=delta['visits']==0,visit_changes_proved=gate['cases'][name]['visit_proof']['proved'] and delta==gate['cases'][name]['deltas'],other_counters_match=all(v==0 for k,v in delta.items() if k not in ['work','comparison_work','visits']),work_not_reduced=delta['work']>=0 and delta['comparison_work']>=0)"
assert s.count(needle)==1;s=s.replace(needle,new)
s=s.replace("'schema':'mech.polybench.training-probe.v2'", "'schema':'mech.polybench.training-probe.v3'")
start=s.index("ratios=[c['speedup_vs_accepted44']")
s=s[:start]+"""ratios=[c['speedup_vs_accepted44'] for c in r['cases'].values()];assert len(ratios)==15
r['summary']={'count':15,'geomean_raw_speedup_vs_accepted44':b.geomean(ratios),'regressions_over_five_percent':sum(x<1/1.05 for x in ratios),'all_visits_match':all(c['visits_match'] for c in r['cases'].values()),'all_visit_changes_proved':all(c['visit_changes_proved'] for c in r['cases'].values()),'all_other_counters_match':all(c['other_counters_match'] for c in r['cases'].values()),'all_work_not_reduced':all(c['work_not_reduced'] for c in r['cases'].values())}
r['summary']['selected']=r['summary']['geomean_raw_speedup_vs_accepted44']>1 and all(r['summary'][key] for key in ['all_visit_changes_proved','all_other_counters_match','all_work_not_reduced'])
r.update(complete=True,completed_at=b.utc());assert b.compiler_fingerprint()==fp;b.write(output,r);print(json.dumps(r['summary']),flush=True)
"""
folder=Path('/private/tmp/mech-polybench-optimization/round-45/current-bound-rectangles-selection');(folder/'training-probe.py').write_text(s)
