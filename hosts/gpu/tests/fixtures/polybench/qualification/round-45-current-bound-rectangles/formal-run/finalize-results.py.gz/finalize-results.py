"""Strict two-set decision, complete evidence retention and exact rollback."""
import gzip,hashlib,importlib.util,json,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;f=b.read(p/'round-45-frozen.json');tq=b.read(p/'round-45-training-qualification.json');audit=b.read(p/'round-45-audit.json');g=b.read(p/'round-45-progress.json');prior=b.read(p/'round-44-progress.json');decision=audit['performance_acceptance']
assert b.command(['git','rev-parse','HEAD'])==f['source_commit'] and b.command(['git','branch','--show-current'])=='codex/polybench-native-matrices'
assert b.compiler_fingerprint()==f['compiler_fingerprint']==tq['compiler_fingerprint']
assert audit['observations']==900 and audit['finite_liveouts']==29482 and audit['history_entries']==46
assert len(b.read(p/'performance-history.json')['entries'])==46
for rec in tq['development_archives'].values():
 data=(p/rec['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==rec['compressed_sha256'];assert hashlib.sha256(gzip.decompress(data)).hexdigest()==rec['sha256']
scores={part:g['aggregates'][part]['geomean_mech_over_c_kernel'] for part in ['optimization','holdout']};old={part:prior['aggregates'][part]['geomean_mech_over_c_kernel'] for part in scores}
promoted=decision['performance_gate']=='accepted';assert promoted==all(scores[part]<old[part] for part in scores)
assert decision['accepted_index_after_run']==(45 if promoted else 44)
q={'schema':'mech.polybench.optimization-qualification.v3','label':f['label'],'compiler_commit':f['source_commit'],'compiler_fingerprint':f['compiler_fingerprint'],'driver_sha256':f['driver_sha256'],'frozen_candidate_sha256':b.digest(p/'round-45-frozen.json'),'native_typed_ir_version':410,'native_work_policy_version':157,'native_abi_version':47,'dataset':'MINI','numeric_profile':'F64','comparison':{'rtol':1e-10,'atol':1e-9,'finite_required':True,'corpus_liveouts':29482},'checks':tq['checks'],'broad_selected_checks':712,'focused_selected_checks':102,'restored_corpus':tq['restored_corpus'],'source_invariants':tq['invariants'],'profiling_basis':tq['profiling_basis'],'development_attempts':tq['development_attempts'],'counter_gate':{'receipt_sha256':b.digest(p/'round-45-route-census.json'),'scope':'All15 untimed C/source-fee gate; only correlation visits change, with identical source plan/ordered body and actual callback proof. Work/comparison fees nondecreasing; other counters equal.'},'training_probe':b.read(p/'round-45-training-probe.json')['summary'],'performance_acceptance':decision,'aggregate_controls_vs_accepted44':audit['aggregate_controls_vs_accepted44'],'scope':tq['limitations'],'holdout_use':'Aggregate acceptance only; no per-case diagnosis/profiling/tuning.'}
paths=list(tq['source_sha256']);assert len(paths)==19
if not promoted:
 accepted='9bb8ada636a494ae45aae80b7b6b4e83aad9fcf2'
 subprocess.run(['git','restore','--source='+accepted,'--worktree','--',*paths],check=True)
 subprocess.run(['git','add','-A','--',*paths],check=True)
 fp=b.compiler_fingerprint();accepted_frozen=b.read(p/'round-44-frozen.json')
 assert fp==accepted_frozen['compiler_fingerprint']=='ce93b8e75d631d70cce83e10a4401815fd50a8572b87657ae8dcf41f599e0dfa'
 assert b.digest('/private/tmp/mech-polybench-optimization/round-44/prepared-composite-binding/prepared-composite-driver')==accepted_frozen['driver_sha256']
 q['compiler_restored_to_accepted44']={'restored_from_commit':accepted,'compiler_fingerprint':fp,'source_paths':paths,'versions':{'ir':409,'work':156,'abi':47},'accepted_driver_unchanged':True,'reason':'Both primary scores must strictly improve; no training result or control adjustment overrides this gate. The source-fee correctness audit and qualified fix remain preserved for subsequent work.'}
else:
 fp=b.compiler_fingerprint();q['compiler_promoted']={'accepted_index':45,'compiler_fingerprint':fp,'scores':scores}
dest=p/'qualification/round-45-current-bound-rectangles/formal-run';dest.mkdir(parents=True,exist_ok=False);archives={}
for name in ['formal-measurement.log','formal-exit.json','frozen-source-checkpoint.json','source-commit.log','experiment-source-commit.json','inter-round-aggregates.json','formal-report-rows.json','measure-candidate.py','audit-results.py','finalize-results.py','commit-qualified.py']:
 raw=(folder/name).read_bytes();out=dest/(name+'.gz');out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives[name]={'path':str(out.relative_to(p)),'sha256':hashlib.sha256(raw).hexdigest(),'compressed_sha256':b.digest(out)}
q['formal_run_archives']=archives;b.write(p/'round-45-qualification.json',q)
probe=b.read(p/'round-45-training-probe.json');summary=probe['summary']
text='\nRound45: current-bound rectangles with complete source fees ('+('accepted' if promoted else 'not promoted')+')\n\n'
text+='Immutable current inner bounds are certified by the genuine original range/transpose factories; the existing Cranelift body fills one row-major private bank. Shared ordinary transpose funding retains all original row fees on the same comparison account, with full finite/physical/replay/current-owner/atomicity checks. Fixed phases decline dynamic cardinality. All712 broad/102 focused checks and both features pass; restored helpers additionally validate60 original/decoded forms and58964 finite C liveouts. IR410/work157/ABI47.\n\n'
text+=f"The single prospective v3 optimization probe retains all210 fresh-process observations. Raw GM speedup versus accepted44 is{summary['geomean_raw_speedup_vs_accepted44']:.6f}x; correlation{probe['cases']['correlation']['speedup_vs_accepted44']:.6f}x. All{summary['regressions_over_five_percent']} regressions>5% remain. The untimed all15 gate proves the only physical-visit reduction, preserves all source work/comparison bills and matches every other counter. The exact source/driver were committed/pushed/frozen before both formal sets.\n\n"
text+='| Set | Accepted44 x C | Round45 x C | Raw speedup vs44 | Reference-adjusted speedup |\n|---|---:|---:|---:|---:|\n'
for part in scores:
 control=audit['aggregate_controls_vs_accepted44'][part];text+=f"| {part.capitalize()} | {old[part]:.5f}x | {scores[part]:.5f}x | {control['raw_mech_speedup']:.5f}x | {control['reference_adjusted_speedup']:.5f}x |\n"
text+='\n'+('Both primary scores strictly improve; round45 is accepted. ' if promoted else 'The strict two-set gate rejects this run; exact accepted44 source and driver are restored. ')
text+='All900 observations,29482 finite liveouts,46 append-only history entries and every regression remain. Holdout is the aggregate gate only. Below1.0x C holdout is unchanged and requires a separate completion audit.\n\n'
text+='[Qualification](round-45-qualification.json) · [Frozen source](round-45-frozen.json) · [Acceptance](round-45-performance-acceptance.json) · [Source-fee audit](training-experiments/current-bound-rectangles-shared-comparison.json)\n'
with (p/'README.txt').open('a') as out:out.write(text)
subprocess.run(['git','diff','--check'],check=True);subprocess.run(['git','add','--',str(p.relative_to(root))],check=True)
message='Record frozen current-bound rectangle benchmark results' if promoted else 'Retain rejected rectangle timings and restore accepted compiler'
result=subprocess.run(['git','commit','-m',message],capture_output=True,text=True);(folder/'results-source-commit.log').write_text(result.stdout+result.stderr);assert result.returncode==0
assert b.compiler_fingerprint()==fp and b.command(['git','status','--porcelain'])==''
head=b.command(['git','rev-parse','HEAD']);b.write(folder/'current-work.json',{'stage':'Round45 accepted; push/PR metadata pending' if promoted else 'Round45 rejected; exact accepted44 source restored, push/PR metadata pending','live_exec_session':None,'source_commit':head,'compiler_fingerprint':fp,'candidate_source_commit':f['source_commit'],'candidate_driver_sha256':f['driver_sha256'],'accepted_round':45 if promoted else 44,'formal_history_entries':46,'measured_scores':scores,'accepted_scores':scores if promoted else old,'next':'Verify/push PR1001 and continue optimization-only profiling/implementation. Do not retry this observed fingerprint; no holdout per-case diagnosis.'})
print(json.dumps({'head':head,'accepted_round':45 if promoted else 44,'scores':scores,'accepted_scores':scores if promoted else old,'observations':900,'history_entries':46,'archives_verified':len(tq['development_archives'])+len(archives),'working_tree_clean':True,'pushed':False}),flush=True)
