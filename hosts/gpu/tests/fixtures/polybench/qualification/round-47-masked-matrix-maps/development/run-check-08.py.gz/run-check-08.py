import importlib.util,json,os,re,subprocess,time
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent;attempt=folder/'attempt-08';attempt.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
fp=b.compiler_fingerprint();env=os.environ.copy();env['CARGO_TARGET_DIR']='/private/tmp/mech-polybench-pr1000-target';argv=['cargo','test','--release','-p','mech-gpu','--no-default-features','--features','canonical-native-program','--lib','--','numeric_masked_maps','--nocapture','--test-threads=1'];start=time.monotonic()
with (attempt/'proof-check.log').open('x') as log:result=subprocess.run(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
text=(attempt/'proof-check.log').read_text();r={'command':argv,'exit_code':result.returncode,'wall_seconds':time.monotonic()-start,'compiler_fingerprint':fp,'source_unchanged':b.compiler_fingerprint()==fp,'passed_tests':[int(n) for n in re.findall(r'test result: ok[.] (\d+) passed',text)],'scope':'Source proof plus selected iteration/publication differential checks; no performance measurements.'};b.write(attempt/'result.json',r);print(json.dumps(r),flush=True)
assert r['source_unchanged'];raise SystemExit(result.returncode)
