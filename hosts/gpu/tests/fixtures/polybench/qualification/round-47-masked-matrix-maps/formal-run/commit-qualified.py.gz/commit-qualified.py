import importlib.util,json,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;q=b.read(p/'round-47-training-qualification.json');s=b.read(p/'round-47-training-selection.json');r=b.read(p/'round-47-training-probe.json');gate=b.read(p/'round-47-route-census.json')
assert q['complete'] and s['selected'] and r['complete'] and gate['complete'] and gate['passed']
assert b.compiler_fingerprint()==q['compiler_fingerprint']==s['compiler_fingerprint']==r['compiler_fingerprint']==gate['compiler_fingerprint']
assert all(b.digest(root/name)==digest for name,digest in q['source_sha256'].items())
assert b.digest(q['driver'])==q['driver_sha256']
assert b.command(['git','branch','--show-current'])=='codex/polybench-native-matrices'
assert b.command(['git','rev-parse','HEAD'])==q['source_parent']
assert len(b.read(p/'performance-history.json')['entries'])==47
subprocess.run(['git','diff','--check'],check=True)
subprocess.run(['git','add','--',str(p.relative_to(root))],check=True)
result=subprocess.run(['git','commit','-m','Select source-proved masked matrix maps for frozen evaluation'],capture_output=True,text=True)
(folder/'source-commit.log').write_text(result.stdout+result.stderr);assert result.returncode==0
head=b.command(['git','rev-parse','HEAD']);assert b.command(['git','status','--porcelain'])=='' and b.compiler_fingerprint()==q['compiler_fingerprint']
branch='refs/heads/codex/polybench-native-matrices';remote=b.command(['git','ls-remote','origin',branch]).split()[0]
assert remote==q['source_parent'];subprocess.run(['git','merge-base','--is-ancestor',remote,head],check=True)
subprocess.run(['git','-c','http.version=HTTP/1.1','-c','http.postBuffer=52428800','push','origin',head+':'+branch],check=True)
assert b.command(['git','ls-remote','origin',branch]).split()[0]==head
receipt={'source_commit':head,'compiler_fingerprint':q['compiler_fingerprint'],'driver_sha256':q['driver_sha256'],'clean':True,'pushed':True,'selected':True,'formal_observations':0};b.write(folder/'experiment-source-commit.json',receipt)
b.write(folder/'current-work.json',{'stage':'Exact qualified source, gate and all210 training observations committed/pushed; formal evaluation next','source_commit':head,'compiler_fingerprint':q['compiler_fingerprint'],'driver_sha256':q['driver_sha256'],'accepted_round':45,'formal_history_entries':47,'live_exec_session':None,'next':'Freeze exact clean source/driver and run both formal sets once. No Rust edits, no overlapping builds/profiles/timings, no holdout per-case diagnosis.'})
print(json.dumps(receipt),flush=True)
