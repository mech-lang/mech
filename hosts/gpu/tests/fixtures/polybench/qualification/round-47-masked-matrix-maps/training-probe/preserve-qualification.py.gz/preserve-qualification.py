import gzip,hashlib,importlib.util,json,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;q=b.read(folder/'qualification.json');plan=b.read(folder/'plan.json');gate=b.read(folder/'untimed-counter-gate.json');emission=b.read(folder/'emission-census.json');fp=b.compiler_fingerprint()
assert q['complete'] and q['driver_build_complete'] and q['tests']==720 and q['focused_checks']['passed_tests']==[8]
assert fp==q['compiler_fingerprint']==gate['compiler_fingerprint']==emission['compiler_fingerprint']
assert gate['complete'] and gate['passed'] and emission['complete'] and emission['passed'] and emission['profiled_mask_count']>=3 and emission['source_unchanged']
assert b.digest(q['driver'])==q['driver_sha256'] and len(b.read(p/'performance-history.json')['entries'])==47
assert not (folder/'training-probe.json').exists()
paths=plan['source_paths'];changed=subprocess.check_output(['git','diff','--name-only',plan['source_parent'],'--'],text=True).splitlines();actual=[name for name in changed if name.endswith(('.rs','.toml')) or Path(name).name=='Cargo.lock'];assert set(actual)==set(paths)
patch=subprocess.check_output(['git','diff',plan['source_parent'],'--',*paths]);(folder/'qualified-source.patch').write_bytes(patch)
dest=p/'qualification/round-47-masked-matrix-maps/development';dest.mkdir(parents=True,exist_ok=False);archives={}
for source in sorted(folder.rglob('*')):
 if not source.is_file() or '__pycache__' in source.parts or source==Path(q['driver']):continue
 name=str(source.relative_to(folder));raw=source.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives[name]={'path':str(out.relative_to(p)),'sha256':b.digest(source),'compressed_sha256':b.digest(out)}
receipt={'schema':'mech.polybench.masked-matrix-maps-development.v1','created_at':b.utc(),'complete':True,'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'qualification_manifest':q,'plan_sha256':b.digest(p/'training-experiments/masked-matrix-maps-plan.json'),'source_parent':plan['source_parent'],'source_sha256':q['source_sha256'],'invariants':plan['implementation'],'profiling_basis':plan['profiling_basis'],'prior_related_experiment':plan['prior_rejected_work'],'counter_gate':{'complete':gate['complete'],'passed':gate['passed'],'finite_liveouts':gate['finite_liveouts'],'all_counters_match':all(row['all_counters_match'] for row in gate['cases'].values())},'emission_census':{'complete':emission['complete'],'passed':emission['passed'],'cases':len(emission['cases']),'native_code_changed_cases':emission['native_code_changed_cases'],'profiled_function_changed':emission['profiled_function_changed'],'profiled_mask_count':emission['profiled_mask_count'],'no_new_fma':emission['no_new_fma']},'prospective_refinements':{name:b.read(p/'training-experiments'/name) for name in ['masked-matrix-maps-publication-refinement.json','masked-matrix-maps-base-view-refinement.json']},'performance_observations':0,'archives':archives}
b.write(p/'training-experiments/masked-matrix-maps-development.json',receipt);b.write(p/'training-experiments/masked-matrix-maps-training-schedule.json',b.read(folder/'training-probe-plan.json'));b.write(p/'round-47-route-census.json',gate)
subprocess.run(['git','diff','--check'],check=True);subprocess.run(['git','add','--',*paths,str(p.relative_to(root))],check=True)
result=subprocess.run(['git','commit','-m','Qualify source-proved masked matrix evaluation before timing'],capture_output=True,text=True);(folder/'qualification-source-commit.log').write_text(result.stdout+result.stderr);assert result.returncode==0
head=b.command(['git','rev-parse','HEAD']);assert b.compiler_fingerprint()==fp and b.command(['git','status','--porcelain'])==''
b.write(folder/'qualification-source-commit.json',{'source_commit':head,'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'performance_observations':0,'archives_verified':len(archives),'clean':True})
print(json.dumps({'head':head,'compiler_fingerprint':fp,'broad_checks':q['tests'],'focused_checks':8,'archives':len(archives),'performance_observations':0,'working_tree_clean':True}),flush=True)
