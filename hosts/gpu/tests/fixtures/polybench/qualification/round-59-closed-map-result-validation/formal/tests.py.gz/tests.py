from pathlib import Path
import re
base=Path.cwd()/'hosts/gpu/src/native_artifact'
p=base/'program/codegen/numeric_map_dots/cells.rs';s=p.read_text();pattern=r'    fn function\(\) -> Function \{\n        let source = ("[^"\n]*");\n';m=re.search(pattern,s);assert m
s=s[:m.start()]+'    const SOURCE: &str = '+m[1]+';\n    fn function(source: &str) -> Function {\n'+s[m.end():]
a=s.index('        let mut module = cranelift_jit::JITModule::new(');z=s.index('        let sentinel = ',a)
setup=s[a:z].replace('context.func = function();','context.func = function(source);').replace('let asm = context.compiled_code().unwrap().vcode.as_ref().unwrap();','let asm = context.compiled_code().unwrap().vcode.as_ref().unwrap().clone();')
setup=setup.replace('        module.finalize_definitions().unwrap();','''        #[cfg(target_arch = "aarch64")]
        assert_eq!(asm.matches("umaxp").count(), 1, "one aggregate SIMD reduction: {asm}");
        module.finalize_definitions().unwrap();''')
helper='''    fn compile(source: &str) -> (cranelift_jit::JITModule, Kernel, String) {
'''+setup+'''        (module, kernel, asm)
    }
'''
s=s[:a]+'        let (_module, kernel, _assembly) = compile(SOURCE);\n'+s[z:]
pos=s.index('    #[test]\n    fn affine_map_cells_direct_dynamic_kernel');s=s[:pos]+helper+s[pos:]
# Every private output is filled before deferred validation can decline.
needle='''        assert!(out.iter().any(|&v| v != sentinel));''';assert needle in s;s=s.replace(needle,'''        assert!(out.iter().all(|&v| v != sentinel));
        for bad in [0, 3, 14] {
            a.fill(1.0);
            a[bad] = f64::from_bits(0x7ff0_0000_0000_0123);
            out.fill(sentinel);
            frame.next = 0;
            // SAFETY: exact banks; early/middle/late NaNs must survive every
            // later row and piecewise window in the aggregate result mask.
            assert_eq!(unsafe { kernel(&mut frame, a.as_ptr(), x.as_ptr(), y.as_ptr(), out.as_mut_ptr(), 3, 5, 3, 3, 5) }, 1);
            assert_eq!(frame.next, 0);
            assert!(out.iter().all(|&v| v != sentinel));
        }''')
pos=s.rfind('\n}')
s=s[:pos]+r'''
    #[test]
    fn affine_map_cells_result_boundary_accepts_finite_results_after_infinite_intermediates() {
        let source = SOURCE.replace("a[i,j] - x[i] * y[j]", "1.0 / (a[i,j] * a[i,j])");
        let (_module, kernel, _assembly) = compile(&source);
        let sentinel = 0xbad0_bad0_bad0_bad0;
        for value in [f64::MAX, f64::INFINITY, -f64::INFINITY, 1.25] {
            let a = vec![value; 15];
            let mut out = vec![sentinel; 15];
            let mut frame = Frame::default();
            // SAFETY: the sole used matrix is A. The pure scalar source can
            // return finite zero after Infinity without a language error.
            assert_eq!(unsafe { kernel(&mut frame, a.as_ptr(), core::ptr::null(), core::ptr::null(), out.as_mut_ptr(), 3, 5, 0, 0, 0) }, 0);
            assert_eq!(frame.next, 15);
            let square = std::hint::black_box(value * value);
            let expected = std::hint::black_box(1.0 / square).to_bits();
            assert!(out.iter().all(|&bits| bits == expected));
        }
    }
'''+s[pos:];p.write_text(s)
p=base/'program/runtime/composition_tests/affine_map_cells.rs';s=p.read_text();s+=r'''

#[test]
fn affine_map_cells_result_boundary_all_operators_distinct_nan_payloads_and_restored_replay() {
    for expression in [
        "-math/sqrt(1.0 / (a[i] * a[i])) + b[i]",
        "(a[i] + b[i]) * (a[i] - b[i]) / (a[i] + 1.0)",
    ] {
        let source = format!("+> math\na := left<[f64]:7,1>\nb := right<[f64]:7,1>\n[{expression} | i <- 1u64..=7u64]'\n");
        for artifact in artifacts(&source) {
            let (fast, old) = pair(&artifact);
            let mode = NativeProgramLimitMode::NoLimits;
            let memory = mode.memory_budget();
            for rotation in 0..7 {
                let words = [f64::MAX.to_bits(), f64::INFINITY.to_bits(), (-0.0f64).to_bits(), 1, 0x7ff0_0000_0000_0123, 0x7ff8_9876_5432_1234, 0xfff8_1111_2222_3333];
                let left = (0..7).map(|i|words[(i+rotation)%7]).collect::<Vec<_>>();
                let right = (0..7).map(|i|words[(i+rotation+3)%7]).collect::<Vec<_>>();
                let args = numeric_maps::typed_arguments(&artifact, &memory, &[("left",matrix(&left),&[7,1]),("right",matrix(&right),&[7,1])]);
                let before=(memory.used_bytes(),memory.retained_snapshot_nodes());
                for restored in [false,true] {
                    let mut actual=vec![None;artifact.outputs().len()];let mut expected=actual.clone();
                    compare(&fast,&old,&args,&memory,mode.execution(),restored,&mut actual,&mut expected);
                    drop((actual,expected));assert_eq!((memory.used_bytes(),memory.retained_snapshot_nodes()),before);
                }
                drop(args);assert_eq!((memory.used_bytes(),memory.retained_snapshot_nodes()),(0,0));
            }
        }
    }
}
''';p.write_text(s)
