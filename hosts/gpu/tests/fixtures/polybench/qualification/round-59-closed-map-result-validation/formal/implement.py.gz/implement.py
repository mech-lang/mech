from pathlib import Path
import json,hashlib,shutil
root=Path.cwd();f=Path(__file__).resolve().parent;old=f.parents[1]/'round-67/affine-map-cells';base=root/'hosts/gpu/src/native_artifact'
q=json.loads((old/'qualification.json').read_text())
for name,digest in q['source_sha256'].items():
 src=old/'qualified-source'/name;assert hashlib.sha256(src.read_bytes()).hexdigest()==digest
 dst=root/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
p=base/'program/codegen/numeric_product_epilogues.rs';s=p.read_text();start=s.index('pub(super) fn finite(');end=s.index('\nimpl Leaf {',start)
s=s[:start]+'''/// A lane mask for nonfinite values. Callers choose the validation boundary;
/// ordinary product/epilogue guards retain their original immediate check.
pub(super) fn nonfinite_mask(b: &mut FunctionBuilder<'_>, value: Value, vector: bool) -> Value {
    let kind = if vector { types::I64.by(2).unwrap() } else { types::I64 };
    let bits = b.ins().bitcast(kind, MemFlags::new(), value);
    let mask = b.ins().iconst(types::I64, 0x7ff0000000000000);
    let mask = if vector { b.ins().splat(kind, mask) } else { mask };
    let exponent = b.ins().band(bits, mask);
    b.ins().icmp(IntCC::Equal, exponent, mask)
}
pub(super) fn finite(b: &mut FunctionBuilder<'_>, value: Value, vector: bool, cancelled: Block) {
    let bad = nonfinite_mask(b, value, vector);
    let bad = if vector { b.ins().vany_true(bad) } else { bad };
    let good = b.create_block();
    b.ins().brif(bad, cancelled, &[], good, &[]);
    b.switch_to_block(good);
}
'''+s[end:];p.write_text(s)
p=base/'program/codegen/numeric_map_dots/streams.rs';s=p.read_text();pos=s.index('    pub fn packed_inner(');s=s[:pos]+'''    pub fn inner_invariant(&self) -> bool {
        !self.inner_dependent
    }
'''+s[pos:];p.write_text(s)
p=base/'program/codegen/numeric_map_dots/cells.rs';s=p.read_text();pos=s.index('\nfn evaluate(');s=s[:pos]+'''
/// Closed cell DAGs observe FP only through the final pushed F64 cell. Their
/// admitted operations propagate NaN; all source arithmetic and rounding still
/// execute. A finite result therefore has its exact original bits, even when
/// an intermediate Infinity becomes zero through division. Any nonfinite final
/// result replays the original word DAG before publication, preserving payloads.
/// Keep scalar/vector masks separate so no lane reduction or branch is needed
/// inside a cell, row or path. These SSA values grant no scratch certificate.
#[derive(Clone, Copy)]
struct ResultMasks {
    scalar: cranelift_frontend::Variable,
    packed: cranelift_frontend::Variable,
}
impl ResultMasks {
    fn new(b: &mut FunctionBuilder<'_>) -> Self {
        let scalar = b.declare_var(types::I8);
        let packed = b.declare_var(types::I64.by(2).unwrap());
        let zero = b.ins().iconst(types::I8, 0);
        b.def_var(scalar, zero);
        let zero = b.ins().iconst(types::I64, 0);
        let zero = b.ins().splat(types::I64.by(2).unwrap(), zero);
        b.def_var(packed, zero);
        Self { scalar, packed }
    }
    fn push(self, b: &mut FunctionBuilder<'_>, value: Value, vector: bool) {
        let bad = super::super::numeric_product_epilogues::nonfinite_mask(b, value, vector);
        let variable = if vector { self.packed } else { self.scalar };
        let previous = b.use_var(variable);
        let combined = b.ins().bor(previous, bad);
        b.def_var(variable, combined);
    }
    fn validate(self, b: &mut FunctionBuilder<'_>, slow: Block) {
        let packed = b.use_var(self.packed);
        let packed = b.ins().vany_true(packed);
        let scalar = b.use_var(self.scalar);
        let bad = b.ins().bor(scalar, packed);
        let good = b.create_block();
        b.ins().brif(bad, slow, &[], good, &[]);
        b.switch_to_block(good);
    }
}
'''+s[pos:]
s=s.replace('    prepared: &[streams::Prepared],\n    x:', '    prepared: &[streams::Prepared],\n    row_reads: &[Option<Value>],\n    x:')
s=s.replace('            CellValue::Read(at) => prepared[at].cell(b, x, y, vector),','''            CellValue::Read(at) => match row_reads[at] {
                Some(value) => if vector { b.ins().splat(kind, value) } else { value },
                None => prepared[at].cell(b, x, y, vector),
            },''')
s=s.replace('''        // Preserve all intermediate rounding and defer nonfinite payload cases
        // to the original scalar DAG. No store precedes these checks.
        super::super::numeric_product_epilogues::finite(b, value, vector, context.slow);
''','''        // The source closure rejects every FP observer except the final F64
        // push. Still emit every original operation, including unused work;
        // only speculative result validation moves to the scratch boundary.
''')
s=s.replace('    context: &Context<\'_>,\n    path: &CellPath,\n    matrices:', '    context: &Context<\'_>,\n    masks: ResultMasks,\n    path: &CellPath,\n    matrices:')
needle='''    b.switch_to_block(row_body);
    b.def_var(x, zero);''';assert needle in s
s=s.replace(needle,'''    b.switch_to_block(row_body);
    // Current row, current immutable loans, already checked complete window.
    // Do not mark memory globally readonly: the enclosing phase can publish
    // into these banks after this complete scratch map has succeeded.
    let row_reads = prepared.iter().map(|stream| {
        stream.inner_invariant().then(|| stream.cell(b, zero, at_y, false))
    }).collect::<Vec<_>>();
    b.def_var(x, zero);''')
needle='''        let result = evaluate(b, context, path, &prepared, at_x, at_y, vector)?;''';assert needle in s
s=s.replace(needle,'''        let result = evaluate(b, context, path, &prepared, &row_reads, at_x, at_y, vector)?;
        masks.push(b, result, vector);''')
needle='''    for path in paths {''';assert needle in s;s=s.replace(needle,'''    let masks = ResultMasks::new(b);
    for path in paths {''',1)
needle='''                    &context,
                    path,''';assert needle in s;s=s.replace(needle,'''                    &context,
                    masks,
                    path,''')
needle='''    // Same complete-prefix certificate as the checked selected map.''';assert needle in s;s=s.replace(needle,'''    masks.validate(b, slow);
'''+needle)
p.write_text(s)
p=base/'program/prepare/numeric_map_dots/cells.rs';s=p.read_text().replace('//! current owner, pointer, admission, scratch or publication authority.','''//! current owner, pointer, admission, scratch or publication authority.
//! The final F64 cell is the only FP observation: source control is U64-only,
//! every allowed FP primitive is total and NaN-propagating, and conversions,
//! FP predicates, extra pushes/effects or hidden checked work decline. This
//! permits result-boundary validation while retaining every source operation.''');p.write_text(s)
p=base/'program/image/identity.rs';s=p.read_text().replace('NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 428;','NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 429;');p.write_text(s)
