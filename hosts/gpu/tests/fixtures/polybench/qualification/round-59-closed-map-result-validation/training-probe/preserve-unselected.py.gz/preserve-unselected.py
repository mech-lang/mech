"""Retain the failed single probe and restore the exact accepted compiler."""
import gzip,hashlib,importlib.util,json,subprocess
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent;spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;plan=b.read(folder/'plan.json');q=b.read(folder/'qualification.json');r=b.read(folder/'training-probe.json');development=b.read(p/'training-experiments/closed-map-result-validation-development.json');fp=b.compiler_fingerprint();accepted=b.read(p/'round-58-frozen.json');ledger=b.read(p/'performance-acceptance.json')
assert r['complete'] and not r['summary']['selected'] and r['summary']['geomean_raw_speedup_vs_accepted58']<=1
assert b.read(folder/'training-probe.exit.json')['exit_code']==0 and sum(len(c['observations'])for c in r['cases'].values())==210
assert fp==r['compiler_fingerprint']==q['compiler_fingerprint']==development['compiler_fingerprint']
assert b.digest(q['driver'])==q['driver_sha256']==r['driver_sha256'] and all(b.digest(root/name)==digest for name,digest in q['source_sha256'].items())
assert all(c['all_counters_match']for c in r['cases'].values()) and b.command(['git','status','--porcelain'])==''
assert len(b.read(p/'performance-history.json')['entries'])==59 and ledger['accepted_history_index']==58
assert not(p/'round-59-frozen.json').exists()
interpretation={'scope':'Optimization15 only; one complete210-observation probe, no new formal score/holdout observations.','result':'Not selected solely because raw optimization geometric-mean speedup does not exceed1. Every observation/regression and exact source counter retained.','summary':r['summary'],'mechanism':'Closed F64 result-observer proof, aggregate final-result validation before publication and row-local invariant immutable reads; full original source arithmetic/guards/replay/resource obligations retained. Nine focused groups and broad all30/both-feature qualification plus exact optimization counters passed.','diagnostic_limit':'Static work removal and correctness do not establish speedup. No exclusion or repeat of an observed fingerprint. Restore exact accepted58; source evidence must inform the next material candidate.'}
b.write(folder/'unselected-interpretation.json',interpretation)
dest=p/'qualification/round-69-closed-map-result-validation-unselected';dest.mkdir(parents=True,exist_ok=False);archives={'development/'+name:rec for name,rec in development['archives'].items()};new=0
for source in sorted(folder.rglob('*')):
 if not source.is_file() or '__pycache__'in source.parts or source.name.endswith('-driver'):continue
 name=str(source.relative_to(folder));old=development['archives'].get(name)
 if old and old['sha256']==b.digest(source):continue
 raw=source.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives['probe/'+name]={'path':str(out.relative_to(p)),'sha256':b.digest(source),'compressed_sha256':b.digest(out)};new+=1
for rec in archives.values():
 data=(p/rec['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==rec['compressed_sha256'] and hashlib.sha256(gzip.decompress(data)).hexdigest()==rec['sha256']
subprocess.run(['git','restore','--source='+plan['source_parent'],'--worktree','--',*plan['source_paths']],check=True)
subprocess.run(['git','add','-A','--',*plan['source_paths']],check=True)
restored=b.compiler_fingerprint();assert restored==accepted['compiler_fingerprint']
receipt={'schema':'mech.polybench.compiler-training-experiment.v3','created_at':b.utc(),'name':plan['name'],'complete':True,'selected':False,'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'qualified_source_commit':b.read(folder/'qualification-source-commit.json')['source_commit'],'effective_plan':plan,'qualification':q,'probe':r,'interpretation':interpretation,'development_receipt':'training-experiments/closed-map-result-validation-development.json','archives':archives,'performance_observations':210,'formal_observations':0,'holdout_observations':0,'formal_history_entries_unchanged':59,'accepted_history_index_unchanged':58,'restored_compiler_fingerprint':restored,'accepted_scores_unchanged':plan['accepted_scores'],'no_retry_or_exclusion':True}
b.write(p/'training-experiments/closed-map-result-validation-probe.json',receipt)
b.write(p/'training-experiments/closed-map-result-validation-selection.json',{'schema':'mech.polybench.training-selection.v3','created_at':b.utc(),'selected':False,'compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'observations':210,'summary':r['summary'],'gate_passed':True,'performance_score':'Raw equal-weight optimization15 GM accepted58/candidate medians. One prospective fresh-process probe; all observations retained.','decision':'Not selected because raw optimization speedup<=1. Exact accepted58 source restored. No formal run or holdout observation.','restored_compiler_fingerprint':restored,'accepted_round':58,'history_entries':59})
with(p/'README.txt').open('a')as out:
 out.write('\nSource-closed affine F64 map kernels: unselected probe\n\n')
 out.write(f'The closed-map result-validation kernel passed{q["tests"]} broad invocations,9 focused groups, both features, all30 source forms, and an exact17002-value optimization counter gate. Genuine Objects show typed SIMD updates and complete source-fee conservation. Its single210-observation optimization-only probe returned{r["summary"]["geomean_raw_speedup_vs_accepted58"]:.16f}x raw speedup, with{r["summary"]["regressions_over_five_percent"]} regressions over5%. It was not selected. All observations and attempted sources are retained. Exact accepted58 fingerprint{restored} is restored; no formal history append or holdout observation. The recorded accepted scores remain8.144951071643966x /24.70557552923209x C.\n\n')
 out.write('[Full probe and source restoration](training-experiments/closed-map-result-validation-probe.json) · [Selection](training-experiments/closed-map-result-validation-selection.json)\n')
assert len(b.read(p/'performance-history.json')['entries'])==59 and b.read(p/'performance-acceptance.json')['accepted_history_index']==58
subprocess.run(['python3',str(root/'scripts/record-polybench-acceptance.py'),'--check','--require-latest-accepted'],check=True,capture_output=True)
subprocess.run(['git','diff','--check'],check=True);subprocess.run(['git','add','--',str(p.relative_to(root))],check=True)
subprocess.run(['git','-c','gc.auto=0','commit','-q','-m','Retain unselected result-validation probe and restore accepted58'],check=True)
assert b.command(['git','status','--porcelain'])=='' and b.compiler_fingerprint()==restored
head=b.command(['git','rev-parse','HEAD']);b.write(folder/'restoration.json',{'head':head,'candidate_fingerprint':fp,'restored_compiler_fingerprint':restored,'accepted_round':58,'observations':210,'history_entries':59,'archives_verified':len(archives),'new_archives':new,'clean':True})
state=b.read(folder/'current-work.json');state.update(stage='Single optimization probe not selected; exact accepted58 restored and evidence committed, push pending',complete=True,accepted_round=58,compiler_fingerprint=restored,candidate_fingerprint=fp,performance_observations=210,formal_observations=0,holdout_observations=0,history_entries=59,live_exec_session=None,source_commit=head);b.write(folder/'current-work.json',state)
print(json.dumps({'head':head,'selected':False,'raw_probe_speedup':r['summary']['geomean_raw_speedup_vs_accepted58'],'accepted_round':58,'restored_compiler_fingerprint':restored,'accepted_scores':plan['accepted_scores'],'archives_verified':len(archives),'new_archives':new,'clean':True}),flush=True)
