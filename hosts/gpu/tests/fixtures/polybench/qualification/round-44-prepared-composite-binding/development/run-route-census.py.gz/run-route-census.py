"""Untimed optimization-only verification of the qualified selected route."""
import collections,importlib.util,pathlib,subprocess
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
q=b.read(folder/'qualification.json');assert q['complete'] and b.compiler_fingerprint()==q['compiler_fingerprint'] and b.digest(q['driver'])==q['driver_sha256']
config=b.read('/private/tmp/mech-polybench-optimization/round-39/composite-pack-profile/census-config.json')
config.update(driver=q['driver'],driver_sha256=q['driver_sha256'],compiler_fingerprint=q['compiler_fingerprint'])
assert not (folder/'admission-census.json').exists()
b.write(folder/'census-config.json',config)
argv=['lldb','--batch','-o','settings set target.disable-aslr false','-o','settings set target.skip-prologue false','-o','command script import '+str(folder/'pack_census.py'),'-o','script pack_census.run()']
with (folder/'debugger-census.log').open('x') as log:subprocess.run(argv,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
r=b.read(folder/'admission-census.json');assert r['complete'] and r['compiler_fingerprint']==q['compiler_fingerprint'] and r['driver_sha256']==q['driver_sha256']
protocol,cases=b.protocol();liveouts=0
for name,row in r['cases'].items():
 assert row['timing_samples']==0 and row['exit_code']==0
 expected={str(site):2 for site,call in config['cases'][name]['calls'].items() if call['primitive']!={'CompositePack':2}}
 pack=[str(site) for site,call in config['cases'][name]['calls'].items() if call['primitive']=={'CompositePack':2}];assert len(pack)==1
 assert row['counts_by_site']=={'native':expected,'generic':{},'composite':{pack[0]:1}},row['counts_by_site']
 row['validation']=b.validate(row['driver_values'],cases[name]['expected']);liveouts+=row['validation']['count']
assert liveouts==160 and b.compiler_fingerprint()==q['compiler_fingerprint']
r.update(complete=True,finite_liveouts=liveouts,performance_observations=0,prospective_gate_passed=True,actual_generic_planner_bypass=True,source_visits_preserved_by_differential_tests=True,limitations='Callback-site census establishes actual selected path, not a timing score or allocation count.')
b.write(folder/'execution-route-census.json',r)
print({'census':'passed','cases':{n:v['counts_by_site'] for n,v in r['cases'].items()},'finite_liveouts':liveouts,'performance_observations':0},flush=True)
