import importlib.util,pathlib,subprocess,sys
root=pathlib.Path('/Users/cim310/.codex/worktrees/polybench-pr1000/mech');folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;q=b.read(p/'round-44-training-qualification.json');selection=b.read(p/'round-44-training-selection.json')
assert selection['selected']
assert b.compiler_fingerprint()==q['compiler_fingerprint']==selection['compiler_fingerprint']
assert b.command(['git','branch','--show-current'])=='codex/polybench-native-matrices'
assert b.command(['git','rev-parse','HEAD'])==sys.argv[1]
assert b.command(['git','status','--porcelain'])==''
driver=folder/'prepared-composite-driver'
assert b.digest(driver)==q['driver_sha256']
b.write(folder/'frozen-source-checkpoint.json',{'created_at':b.utc(),'source_commit':sys.argv[1],'compiler_fingerprint':b.compiler_fingerprint(),'driver_sha256':b.digest(driver),'qualification_sha256':b.digest(p/'round-44-training-qualification.json'),'selection_sha256':b.digest(p/'round-44-training-selection.json')})
runner=['python3',str(root/'scripts/benchmark-polybench.py')];reference=pathlib.Path('/private/tmp/mech-polybench-optimization/baseline-driver');frozen=p/'round-44-frozen.json'
assert not frozen.exists()
subprocess.run(runner+['freeze','--label','round-44-prepared-composite-binding','--driver',str(driver),'--reference-driver',str(reference),'--output',str(frozen)],cwd=root,check=True)
for part in ['optimization','holdout']:
 subprocess.run(runner+['run','--partition',part,'--driver',str(driver),'--reference-driver',str(reference),'--c-build','/private/tmp/mech-polybench-optimization/rebuilt-c','--freeze',str(frozen),'--samples','5','--output',str(p/f'round-44-{part}.json')],cwd=root,check=True)
subprocess.run(runner+['summarize','--optimization',str(p/'round-44-optimization.json'),'--holdout',str(p/'round-44-holdout.json'),'--output',str(p/'round-44-progress.json'),'--history',str(p/'performance-history.json')],cwd=root,check=True)
subprocess.run(['python3',str(root/'scripts/record-polybench-acceptance.py')],cwd=root,check=True)
assert b.compiler_fingerprint()==q['compiler_fingerprint']
