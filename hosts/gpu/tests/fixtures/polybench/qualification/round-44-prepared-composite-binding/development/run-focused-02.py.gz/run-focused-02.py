import gzip,importlib.util,json,os,pathlib,re,subprocess,time
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent;attempt=folder/'attempt-02';attempt.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);fp=b.compiler_fingerprint()
paths=sorted(set(subprocess.run(['git','ls-files','-mo','--exclude-standard'],capture_output=True,text=True,check=True).stdout.splitlines()));paths=[p for p in paths if p.endswith(('.rs','.toml')) or pathlib.Path(p).name=='Cargo.lock']
for name in paths:
 out=attempt/'source'/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress((root/name).read_bytes(),mtime=0))
(attempt/'source.patch.gz').write_bytes(gzip.compress(subprocess.run(['git','diff','--binary'],capture_output=True,check=True).stdout,mtime=0))
state={'stage':'Prepared shared composite binding focused correctness build running; no new timing observations','live_exec_session':None,'pid':os.getpid(),'source_parent':b.command(['git','rev-parse','HEAD']),'compiler_fingerprint':fp,'source_paths':paths,'versions':{'ir':409,'work':156,'abi':47},'accepted_round':31,'formal_history_entries':44,'accepted_scores':{'optimization':11.43635797708715,'holdout':39.31569548924827},'next':'Wait for this exact focused Cargo session. No Rust edits or overlapping builds/tests/profiles/timings. Preserve every failure before editing; then qualify source and both features, inspect optimization15 emission, and use one fresh-process training probe for a changed qualified source.'};b.write(attempt/'source-checkpoint.json',state);b.write(folder/'current-work.json',state)
env=os.environ.copy();env['CARGO_TARGET_DIR']='/private/tmp/mech-polybench-pr1000-target';env['RUST_BACKTRACE']='1';env.pop('PERF_BUILDID_DIR',None)
commands=[
 ['cargo','test','--release','-p','mech-core','--no-default-features','--features','baselib,compiler,serde','--lib','--','composite_constructor','prepared_composite','--test-threads=1','--nocapture'],
 ['cargo','test','--release','-p','mech-gpu','--no-default-features','--features','canonical-native-program','--lib','--','numeric_composite','numeric_binary','prepared_selected_routes','matrix_length_lowering','numeric_cold_child','numeric_interval_finite_cold_suffix','--test-threads=1','--nocapture']]
start=time.monotonic();argv=commands
with (attempt/'focused.log').open('x') as log:
 for command in commands:
  r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  if r.returncode:break
log=(attempt/'focused.log').read_text();result={'command':argv,'exit_code':r.returncode,'wall_seconds':time.monotonic()-start,'compiler_fingerprint':fp,'source_unchanged':b.compiler_fingerprint()==fp,'passed_tests':[int(x) for x in re.findall(r'test result: ok[.] (\d+) passed',log)],'complete':True};b.write(attempt/'focused-result.json',result);state.update(stage='Focused numeric composite construction checks complete' if r.returncode==0 else 'Focused numeric composite construction checks failed; preserve and inspect attempt04',live_exec_session=None,result=result);b.write(folder/'current-work.json',state);print(json.dumps(result),flush=True);raise SystemExit(r.returncode)
