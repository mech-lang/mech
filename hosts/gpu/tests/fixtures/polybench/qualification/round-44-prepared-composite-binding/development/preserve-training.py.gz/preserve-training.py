"""Retain every development source/log and the sole qualified training probe."""
import gzip,hashlib,importlib.util
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.FIXTURE;q=b.read(folder/'qualification.json');census=b.read(folder/'execution-route-census.json');probe=b.read(folder/'training-probe.json');fp=b.compiler_fingerprint()
assert q['complete'] and census['complete'] and census['prospective_gate_passed'] and probe['complete']
assert fp==q['compiler_fingerprint']==census['compiler_fingerprint']==probe['compiler_fingerprint']
assert q['driver_sha256']==census['driver_sha256']==probe['driver_sha256']
assert all(c['exit_code']==0 for c in q['checks']) and len(q['checks'])==11
assert len(probe['cases'])==15 and sum(len(c['observations']) for c in probe['cases'].values())==210
assert probe['summary']['all_visits_match'] and probe['summary']['all_work_not_reduced']
failures=[]
for attempt in sorted(folder.glob('attempt-*')):
 result=b.read(attempt/'focused-result.json');checkpoint=b.read(attempt/'source-checkpoint.json')
 assert result['complete'] and result['source_unchanged'] and result['compiler_fingerprint']==checkpoint['compiler_fingerprint']
 row={'attempt':attempt.name,'compiler_fingerprint':result['compiler_fingerprint'],'focused_result':result}
 if result['exit_code']:
  row['failure_analysis']=b.read(attempt/'failure-analysis.json')
 failures.append(row)
b.write(folder/'development-attempts.json',failures)
dest=p/'qualification/round-44-prepared-composite-binding/development';dest.mkdir(parents=True,exist_ok=False)
archives={};paths=[x for x in folder.iterdir() if x.is_file() and x.suffix in ('.py','.json','.log','.stdout','.stderr')]
paths += [x for attempt in sorted(folder.glob('attempt-*')) for x in attempt.rglob('*') if x.is_file()]
for path in sorted(paths):
 name=str(path.relative_to(folder));raw=path.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives[name]={'path':str(out.relative_to(p)),'sha256':hashlib.sha256(raw).hexdigest(),'compressed_sha256':b.digest(out)}
plan=b.read(folder/'plan.json')
invariants=plan['invariants']+[
 'The prepared Core recipe snapshots each caller-supplied current header once, then validates input shape bounds/body extents without closing schemas. Constants and repeated output axes remain live checks. The full output shape is instantiated and exact child keys/shapes remain enforced at canonical publication.',
 'Existing private-frame and scalar strategies keep priority. The actual sealed numeric CompositePack route retains all ordinary source envelopes; schema-only normalization is prepared once. No native arithmetic or FP instruction selection changes.',
 'Five new Core differential tests cover fresh rectangular/zero extents, independent parameter arenas, constants/repeated axes, arity/schema substitution, bounded input parameters, computed input overflow, declined unsupported output relations, canonicalization and exact publication bits. Every failed attempt remains; no benchmark timing preceded qualification.',
 'Exactly one prospective v2 optimization15 probe retains seven fresh processes per actor/case and all210 observations. A successful probe is not promotion; both frozen formal primary scores must strictly improve accepted31.'
]
out=dict(q);out.update(schema='mech.polybench.training-qualification.v1',label='round44-prepared-composite-binding',invariants=invariants,profiling_basis=plan['profiling_basis'],total_unique_selected_checks=q['tests'],focused_selected_checks=sum(q['focused_checks']['passed_tests']),development_attempts=failures,development_archives=archives,limitations='Fixed F64 MINI CPU scope. Short-kernel profiles are coarse. Holdout aggregate gate only; no per-case holdout diagnosis, profiling or tuning.',training_probe_summary=probe['summary'])
for suffix,value in [('training-qualification',out),('training-probe',probe),('route-census',census),('training-selection',{'schema':'mech.polybench.training-selection.v2','compiler_fingerprint':fp,'driver_sha256':q['driver_sha256'],'accepted_round':31,'policy':probe['policy'],'result':probe['summary'],'selected':probe['summary']['selected'],'formal_evaluation_started':False})]:
 path=p/f'round-44-{suffix}.json';assert not path.exists();b.write(path,value)
print({'compiler_fingerprint':fp,'archives':len(archives),'checks':q['tests'],'probe':probe['summary'],'formal_observations':0},flush=True)
