from pathlib import Path
import subprocess,json,importlib.util,gzip,hashlib
root=Path.cwd(); f=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
plan=b.read(f/'plan.json');paths=plan['source_paths'];fp=b.compiler_fingerprint()
q=b.read(f/'attempt-01/focused-result.json');assert q['exit_code']==0 and q['passed_tests']==[23] and q['source_unchanged']
assert not(f/'training-probe.json').exists()
snapshot=f/'deferred-source';snapshot.mkdir(exist_ok=False)
for name in paths:
 out=snapshot/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((root/name).read_bytes())
b.write(f/'deferred.json',{'schema':'mech.polybench.deferred-compiler-prototype.v1','created_at':b.utc(),'compiler_fingerprint':fp,'reason':'The new user brief explicitly prioritizes a larger optimization unit: exact counted children in the enclosing generator. The R87 local repeated-bound proof passed23 focused tests but does not remove per-iteration traversal/tag structure. Preserve its source and all checks unmeasured, then recover exact round62 as the counted-loop foundation.','focused':q,'performance_observations':0,'holdout_observations':0,'next':'Exact counted generator children, preserving round62 Seidel and original source accounting/error/replay semantics. Existing O-only gates remain.'})
p=b.FIXTURE;dest=p/'qualification/round-87-generator-linear-bounds-deferred';dest.mkdir(parents=True,exist_ok=False);archives={}
for source in sorted(f.rglob('*')):
 if not source.is_file() or '__pycache__'in source.parts:continue
 name=str(source.relative_to(f));raw=source.read_bytes();out=dest/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 archives[name]={'path':str(out.relative_to(p)),'sha256':hashlib.sha256(raw).hexdigest(),'compressed_sha256':b.digest(out)}
tracked=[name for name in paths if subprocess.run(['git','cat-file','-e','HEAD:'+name],capture_output=True).returncode==0]
subprocess.run(['git','restore','--source=HEAD','--worktree','--',*tracked],check=True)
for name in set(paths)-set(tracked):
 assert (root/name).read_bytes()==(snapshot/name).read_bytes();(root/name).unlink()
restored=b.compiler_fingerprint();assert restored==plan['foundation_fingerprint']
b.write(p/'training-experiments/generator-linear-bounds-deferred.json',dict(b.read(f/'deferred.json'),effective_plan=plan,archives=archives,restored_compiler_fingerprint=restored,accepted_round_unchanged=59,formal_history_entries_unchanged=63))
subprocess.run(['git','diff','--check'],check=True);subprocess.run(['git','add','--',str(p.relative_to(root))],check=True);subprocess.run(['git','-c','gc.auto=0','commit','-q','-m','Preserve unmeasured bounds prototype before counted generator work'],check=True)
assert b.command(['git','status','--porcelain'])==''
print(json.dumps({'head':b.command(['git','rev-parse','HEAD']),'deferred_fingerprint':fp,'restored_fingerprint':restored,'archives':len(archives),'performance_observations':0}),flush=True)
