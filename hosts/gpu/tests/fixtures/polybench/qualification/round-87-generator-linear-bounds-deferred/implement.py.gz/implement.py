from pathlib import Path
root=Path.cwd()
def change(path,old,new):
 p=root/path;s=p.read_text();assert s.count(old)==1,(path,old[:80],s.count(old));p.write_text(s.replace(old,new))
base='hosts/gpu/src/native_artifact/'
change(base+'codegen/options.rs','    NumericGenerators,','    NumericGenerators,\n    /// Reuse a successful current fixed-bank linear selector bound.\n    GeneratorLinearBounds,')
change(base+'program/image/identity.rs','= 437;','= 440;')
p=root/(base+'program/codegen/numeric_generator.rs');s=p.read_text()
s=s.replace('use crate::native_artifact::codegen::common::{','use crate::native_artifact::codegen::options::{OptimizationOptions, OptimizationPass};\nuse crate::native_artifact::codegen::common::{',1)
s=s.replace('mod arrays;','mod arrays;\n#[path = "numeric_generator_bounds.rs"]\npub(in crate::native_artifact) mod bounds;',1)
assert s.count("    b: &mut FunctionBuilder<'_>,\n    code: CodePlan<'_>,")==2
s=s.replace("    b: &mut FunctionBuilder<'_>,\n    code: CodePlan<'_>,","    b: &mut FunctionBuilder<'_>,\n    options: OptimizationOptions,\n    code: CodePlan<'_>,")
s=s.replace('    emit(\n        b,\n        code,','    emit(\n        b,\n        options,\n        code,',1)
s=s.replace('    let m = program.metadata();\n    let plan = &m.plan;','    let m = program.metadata();\n    let plan = &m.plan;\n    let bounds = if options.enabled(OptimizationPass::GeneratorLinearBounds) {\n        bounds::derive(plan, region, &m.closed_tails)\n    } else { bounds::Bounds::default() };',1)
old='                            plan.values()[source.get() as usize].definition().body(),\n                            bad,';assert s.count(old)==2
s=s.replace(old,'                            plan.values()[source.get() as usize].definition().body(),\n                            bounds.prior(site as usize).is_some(),\n                            bad,')
s=s.replace('plan.values()[operands[0].get() as usize].definition().body(), bad)?','plan.values()[operands[0].get() as usize].definition().body(), false, bad)?')
p.write_text(s)
change(base+'codegen/control/mod.rs','crate::native_artifact::program::codegen::numeric_generator::emit_entry(\n                    b,\n                    plan,','crate::native_artifact::program::codegen::numeric_generator::emit_entry(\n                    b,\n                    *options,\n                    plan,')
change(base+'program/runtime/composition_tests/numeric_generator_kernel.rs','        numeric_generator::emit(\n            &mut b,\n            CodePlan::Program(&prepared),','        numeric_generator::emit(\n            &mut b,\n            crate::native_artifact::codegen::options::OptimizationOptions::default(),\n            CodePlan::Program(&prepared),')
p=root/(base+'program/codegen/numeric_generator_arrays.rs');s=p.read_text();old='    schema: &mech_core::SchemaBody,\n    bad: Block,';assert s.count(old)==1;s=s.replace(old,'    schema: &mech_core::SchemaBody,\n    current_bound: bool,\n    bad: Block,')
s=s.replace('    let valid = b.ins().icmp(IntCC::UnsignedLessThan, ordinal, data[1]);\n    require(b, valid, bad);','    if !current_bound {\n        let valid = b.ins().icmp(IntCC::UnsignedLessThan, ordinal, data[1]);\n        require(b, valid, bad);\n    }',1);p.write_text(s)
