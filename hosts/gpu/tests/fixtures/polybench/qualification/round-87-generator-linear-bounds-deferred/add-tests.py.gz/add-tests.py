from pathlib import Path
p=Path.cwd()/'hosts/gpu/src/native_artifact/program/runtime/composition_tests/numeric_generator_execution.rs'
s=p.read_text()+'''
#[test]
fn numeric_generator_linear_bounds_require_current_identical_selectors_and_equal_lengths() {
    use crate::native_artifact::program::codegen::numeric_generator::bounds;
    use crate::native_artifact::program::prepare::readonly_numeric::Operation;
    let base = source();
    let positive = base.replace(":Walk(next,at + 1u64,value)", ":Walk(next,at + 1u64,source[at])");
    assert_ne!(positive, base);
    let changed = base.replace("a * source[at] + prior", "a * source[at + 1u64] + prior");
    let unequal = base.replace("=> <[f64]:3,1>", "=> <[f64]:2,1>")
        .replace("values<[f64]:3,1>", "values<[f64]:2,1>")
        .replace("j <- 1u64..=3u64", "j <- 1u64..=2u64");
    let joined = base.replace("value := a * source[at] + prior",
        "chosen := ((at > 1u64)? | true => source[at] | false => 0.0)\n        value := a * chosen + prior");
    let previous_visit = positive.replace("a * source[at] + prior", "a * prior + prior");
    for (text, expected) in [(positive, true), (changed, false), (unequal, false),
        (joined, false), (previous_visit, false)] {
        for artifact in artifacts(&text) {
            let native = JitProgramArtifact::compile(&artifact, &mech_stdlib::source_catalog()).unwrap();
            let m = native.descriptor().metadata();
            assert_eq!(m.numeric_generators.regions.len(), 1, "bounded source generator retained");
            let region = &m.numeric_generators.regions[0].region;
            let proof = bounds::derive(&m.plan, region, &m.closed_tails);
            let writes = region.children.iter().flat_map(|child|
                &m.closed_tails.regions[child.region].numeric.as_ref().unwrap().actions)
                .filter_map(|(site, op)| matches!(op, Operation::Write { .. }).then_some(*site))
                .collect::<Vec<_>>();
            assert_eq!(writes.len(), 1);
            assert_eq!(proof.prior(writes[0]).is_some(), expected,
                "same current selector/length and uninterrupted source chain are all required");
            if expected {
                assert!(region.sites.iter().filter(|&&site| proof.prior(site as usize).is_some()).count() >= 2,
                    "write and repeated post-write read reuse the first successful read bound");
                let first = proof.prior(writes[0]).unwrap();
                assert_eq!(proof.prior(first), None, "the earliest source bound is still emitted");
            }
        }
    }
}

#[test]
fn numeric_generator_linear_bounds_preserve_bits_first_errors_caps_and_restored_retry() {
    for late in [false, true] {
        let text = if late { source().replace("source[at]", "source[at + 1u64]") } else {
            source().replace(":Walk(next,at + 1u64,value)", ":Walk(next,at + 1u64,source[at])")
        };
        for artifact in artifacts(&text) {
            let catalog = mech_stdlib::source_catalog();
            let fast = JitProgramArtifact::compile(&artifact, &catalog).unwrap();
            let old = JitProgramArtifact::compile_for_test(&artifact, &catalog,
                OptimizationPass::GeneratorLinearBounds).unwrap();
            let m = fast.descriptor().metadata();
            assert_eq!(m.numeric_generators.regions.len(), 1);
            let mode = NativeProgramLimitMode::NoLimits;
            let memory = mode.memory_budget();
            for special in [1.25f64.to_bits(), 1, (-0.0f64).to_bits(), f64::MAX.to_bits(),
                f64::INFINITY.to_bits(), 0x7ff8_1234_5678_9abc, 0x7ff0_1234_5678_9abc] {
                let cells = [1.0f64.to_bits(), 2.0f64.to_bits(), special,
                    4.0f64.to_bits(), 5.0f64.to_bits(), 6.0f64.to_bits()];
                let args = numeric_maps::typed_arguments(&artifact, &memory, &[
                    ("input", super::ordered_map_dots::matrix(&cells), &[2,3]),
                    ("a", Data::F64(F64Bits::from_f64(2.0)), &[]),
                ]);
                let retained = (memory.used_bytes(), memory.retained_snapshot_nodes());
                for restored in [false, true] {
                    let mut output = vec![None; artifact.outputs().len()];
                    let mut previous = output.clone();
                    for denial in [0,1,2,3,0] {
                        let mut limits = mode.execution();
                        match denial {
                            1 => limits.library.max_compute_work = Some(1),
                            2 => limits.library.max_cloned_bytes = Some(0),
                            3 => limits.execution.max_native_stack_bytes = 1,
                            _ => {},
                        }
                        let (ok, counts) = super::ordered_map_dots::compare(&fast, &old, &args,
                            &memory, limits, restored, &mut output, &mut previous);
                        if !late && denial == 0 && special == 1.25f64.to_bits() {
                            assert!(ok); assert_eq!(finishes(&counts), 1, "actual enclosing generator executed");
                        }
                    }
                    output.fill(None);previous.fill(None);
                    assert_eq!((memory.used_bytes(), memory.retained_snapshot_nodes()), retained,
                        "private banks, aliases and rejected/retried outputs fully retire");
                }
                drop(args);
                assert_eq!((memory.used_bytes(), memory.retained_snapshot_nodes()), (0,0));
            }
        }
    }
}
'''
p.write_text(s)
