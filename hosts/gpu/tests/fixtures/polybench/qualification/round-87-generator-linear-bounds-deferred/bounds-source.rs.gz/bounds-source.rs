//! Bounds from a successful access in this current straight-line source visit.
//! This private adapter consumes the selected fixed-bank generator inventory;
//! descriptive CFG/type facts alone cannot authorize an unchecked address.
use super::*;
use mech_engine::native_artifact::{
    NativeCollectionPrimitive as Primitive, NativeMatchTerminator as Branch,
    NativeMatchValue, NativeProgramArtifactPlan as Plan, NativeScalarKind as Kind,
};
use crate::native_artifact::program::prepare::{numeric_generators, tail};

#[derive(Clone, Copy)]
struct Access {
    index: NativeMatchValue,
    count: u64,
    iteration: u32,
}
#[derive(Default)]
pub(in crate::native_artifact) struct Bounds {
    prior: BTreeMap<usize, usize>,
}
impl Bounds {
    pub(in crate::native_artifact) fn prior(&self, site: usize) -> Option<usize> {
        self.prior.get(&site).copied()
    }
}
fn access(plan: &Plan, operation: &Operation, site: usize) -> Option<Access> {
    let block = plan.blocks().get(site)?;
    let Action::LibraryCall { template, operands, output } = block.action() else { return None; };
    let (source, index) = match operation {
        Operation::Read { index, output: result, .. }
            if template.primitive() == Primitive::MatrixScalarAccess
            && output.get() == *result && operands.len() == 2
            && operands[1].get() == *index
            && plan.values()[output.get() as usize].scalar_kind() == Some(Kind::F64) =>
            (operands[0], operands[1]),
        Operation::Write { index, incoming, .. }
            if template.primitive() == Primitive::MatrixIndexedReplace
            && operands.len() == 3 && operands[2].get() == *index
            && operands[1].get() == *incoming
            && plan.values()[operands[1].get() as usize].scalar_kind() == Some(Kind::F64) =>
            (operands[0], operands[2]),
        _ => return None,
    };
    if plan.values()[index.get() as usize].scalar_kind() != Some(Kind::U64)
        || plan.facts().definition_sites(index.get()).ok()?.len() != 1 { return None; }
    let schema = plan.values()[source.get() as usize].definition().body();
    let extents = numeric_generators::matrix(schema)?;
    if template.inputs().first()?.body() != schema { return None; }
    let count = extents[0].checked_mul(extents[1])?;
    (count != 0).then_some(Access { index, count, iteration: block.iteration()? })
}

pub(in crate::native_artifact) fn derive(plan: &Plan, region: &Region, tails: &tail::Layout) -> Bounds {
    let facts = plan.facts();
    let sites = region.sites.iter().copied().collect::<BTreeSet<_>>();
    let mut accesses = BTreeMap::new();
    for child in &region.children {
        let Some(proof) = tails.regions.get(child.region).and_then(|r| r.numeric.as_ref()) else { continue; };
        for (site, operation) in &proof.actions {
            if sites.contains(&(*site as u32)) && let Some(access) = access(plan, operation, *site) {
                accesses.insert(*site, access);
            }
        }
    }
    let mut out = Bounds::default();
    for (&consumer, current) in &accesses {
        let mut at = consumer;
        let mut seen = BTreeSet::from([consumer]);
        let mut earliest = None;
        let mut bounded = false;
        for _ in 0..128 {
            let Ok([previous]) = facts.predecessors(at as u32) else { bounded = true; break; };
            let previous = *previous as usize;
            if !sites.contains(&(previous as u32)) { bounded = true; break; }
            if !seen.insert(previous) { earliest = None; bounded = false; break; }
            let block = &plan.blocks()[previous];
            if block.iteration() != Some(current.iteration)
                || !matches!(block.terminator(), Term::Scalar(Branch::Jump(next)) if next as usize == at) {
                bounded = true; break;
            }
            if let Some(prior) = accesses.get(&previous) {
                if prior.index == current.index && prior.count == current.count {
                    earliest = Some(previous);
                }
            } else {
                let pure = match block.action() {
                    Action::Scalar(Scalar::None) => true,
                    Action::Scalar(Scalar::Copy { output, .. } | Scalar::Primitive { output, .. }) =>
                        *output != current.index,
                    _ => false,
                };
                if !pure { bounded = true; break; }
            }
            at = previous;
        }
        // Keep the earliest successful guard in the complete bounded chain.
        // A cycle/overlong chain never borrows a check from a previous visit.
        if bounded && let Some(prior) = earliest { out.prior.insert(consumer, prior); }
    }
    out
}
