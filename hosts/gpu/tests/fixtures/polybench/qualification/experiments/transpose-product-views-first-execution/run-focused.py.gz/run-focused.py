import importlib.util,json,os,re,subprocess,time
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("b",root/"scripts/benchmark-polybench.py");b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
fp=b.compiler_fingerprint();existing=list(folder.glob("attempt-*"));attempt=folder/f"attempt-{len(existing)+1:02d}";attempt.mkdir()
env=os.environ.copy();env["CARGO_TARGET_DIR"]="/private/tmp/mech-polybench-pr1000-target"
argv=["cargo","test","--release","-p","mech-gpu","--no-default-features","--features","canonical-native-program","--lib","--","numeric_transpose_products","--nocapture","--test-threads=1"]
start=time.monotonic()
with (attempt/"focused.log").open("x") as log:result=subprocess.run(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
text=(attempt/"focused.log").read_text();receipt={"command":argv,"exit_code":result.returncode,"wall_seconds":time.monotonic()-start,"compiler_fingerprint":fp,"source_unchanged":b.compiler_fingerprint()==fp,"passed_tests":[int(n) for n in re.findall(r"test result: ok[.] (\d+) passed",text)],"scope":"Untimed pure source proof; native product execution unchanged; no candidate performance observations"}
b.write(attempt/"result.json",receipt);print(json.dumps(receipt),flush=True)
assert receipt["source_unchanged"]
raise SystemExit(result.returncode)
