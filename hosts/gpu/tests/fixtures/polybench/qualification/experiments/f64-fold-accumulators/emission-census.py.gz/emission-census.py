import importlib.util,json,pathlib,re,subprocess,hashlib
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
protocol,cases=b.protocol();q=b.read(folder/'qualification.json');assert b.compiler_fingerprint()==q['compiler_fingerprint'];assert b.digest(folder/'fold-driver')==q['driver_sha256']
objects=folder/'objects';objects.mkdir(exist_ok=False);old=pathlib.Path('/private/tmp/mech-polybench-optimization/round-31/inverse-bitcasts/objects')
def functions(asm):
 rows={};name=None
 for line in asm.splitlines():
  m=re.match(r'^[0-9a-f]+ <_(.+)>:',line)
  if m:name=m[1];rows[name]=[]
  elif name and re.match(r'^\s*[0-9a-f]+:',line):rows[name].append(line)
 return {name:{'instructions':len(lines),'disassembly_sha256':hashlib.sha256('\n'.join(lines).encode()).hexdigest(),'f64_integer_register_moves':sum(bool(re.search(r'\bfmov\s+(?:d[0-9]+, x[0-9]+|x[0-9]+, d[0-9]+)',line)) for line in lines),'f64_loads':sum(bool(re.search(r'\bldr\s+d[0-9]+,',line)) for line in lines),'f64_stores':sum(bool(re.search(r'\bstr\s+d[0-9]+,',line)) for line in lines),'f64_divisions':sum(bool(re.search(r'\bfdiv\s+',line)) for line in lines),'fused_f64_multiply_adds':sum(bool(re.search(r'\b(?:fmadd|fmsub|fnmadd|fnmsub|fmla|fmls)\s+',line)) for line in lines)} for name,lines in rows.items()}
r={'scope':'Real checked Object export for optimization15 only; no timing observations or linked Object execution.','compiler_fingerprint':q['compiler_fingerprint'],'driver_sha256':q['driver_sha256'],'cases':{}}
for name in protocol['optimization']:
 inputs=folder/f'{name}-inputs.json';b.write(inputs,cases[name]['inputs']);obj=objects/f'{name}.o'
 process=subprocess.run([str(folder/'fold-driver'),str(b.FIXTURE/f'{name}.mec'),str(inputs),'0',f'emit-object={obj}'],text=True,capture_output=True,check=True,timeout=180)
 status=json.loads(process.stdout.strip().splitlines()[-1]);assert status['status']=='ok' and status['mode']=='emit-object'
 metadata=b.read(obj.with_suffix('.metadata.json'))
 asm=subprocess.run(['/Library/Developer/CommandLineTools/usr/bin/llvm-objdump','--disassemble','--no-show-raw-insn',str(obj)],text=True,capture_output=True,check=True).stdout
 disasm=obj.with_suffix('.disasm.txt');disasm.write_text(asm)
 row={'code_bytes':metadata['code_bytes'],'functions':functions(asm),'object_sha256':b.digest(obj),'metadata_sha256':b.digest(obj.with_suffix('.metadata.json')),'disassembly_sha256':b.digest(disasm),'object_executed':False}
 if (old/f'{name}.metadata.json').exists():
  before=b.read(old/f'{name}.metadata.json');row['accepted31_code_bytes']=before['code_bytes'];row['code_bytes_delta']=row['code_bytes']-before['code_bytes'];row['accepted31_functions']=functions((old/f'{name}.disasm.txt').read_text())
 r['cases'][name]=row;b.write(folder/'emission-census.json',r);print(name,'code_bytes',row['code_bytes'],'delta',row.get('code_bytes_delta'),flush=True)
symbol='mech_canonical_program_entry_v1_numeric_5'
row=r['cases']['gramschmidt'];before=row['accepted31_functions'][symbol];after=row['functions'][symbol]
assert before['disassembly_sha256'] != after['disassembly_sha256']
assert after['f64_integer_register_moves'] < before['f64_integer_register_moves']
for name,row in r['cases'].items():
 old_fma=sum(f['fused_f64_multiply_adds'] for f in row['accepted31_functions'].values())
 new_fma=sum(f['fused_f64_multiply_adds'] for f in row['functions'].values())
 assert old_fma==new_fma,(name,old_fma,new_fma)
r['fused_multiply_add_counts_unchanged']=True
r['profiled_fold_function_change']={'symbol':symbol,'before':before,'after':after}
r['complete']=len(r['cases'])==15
assert b.compiler_fingerprint()==q['compiler_fingerprint']
b.write(folder/'emission-census.json',r)
print('Profiled fold function before',before,'after',after,flush=True)
