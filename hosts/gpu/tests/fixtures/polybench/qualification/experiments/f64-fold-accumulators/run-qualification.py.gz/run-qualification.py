import json,os,pathlib,re,subprocess,time
folder=pathlib.Path(__file__).resolve().parent
root=pathlib.Path('/Users/cim310/.codex/worktrees/polybench-pr1000/mech')
env=os.environ.copy();env['CARGO_TARGET_DIR']='/private/tmp/mech-polybench-pr1000-target'
base=['cargo','test','--release','-p','mech-gpu','--no-default-features','--features','canonical-native-program']
checks=[
 ('numeric-regressions.log',base+['--lib','--','numeric','phase','row_block','huffman','private_publication','--test-threads=1']),
 ('matrix-polybench.log',base+['--test','canonical_artifact_matrix','--test','canonical_artifact_polybench','--','--test-threads=1']),
 ('program-regressions.log',base+['--test','canonical_artifact_program','--','buffer_frame_qualification','nested_frame_qualification','numeric_tail_qualification','numeric_write_qualification','scalar_state_qualification','scalar_record_qualification','word_read_qualification','huffman_qualification','sequence_writer_qualification','collection_qualification','packed_update_qualification','range_cursor_qualification','range_qualification','--test-threads=1']),
 ('protocol.log',base+['--lib','--','collection_helpers_have_distinct_roundtrip_codes_and_reserve_output_space','native_runtime_consolidation_preserves_the_charged_layout_envelope','--test-threads=1']),
 ('abi-layout.log',base+['--lib','--','worker_abi_keeps_the_frozen_scalar_prefix_and_disjoint_helper_lanes','--test-threads=1']),
 ('runtime-feature.log',['cargo','check','--release','-p','mech-gpu','--no-default-features','--features','canonical-native-program-runtime','--lib']),
 ('production-feature.log',['cargo','check','--release','-p','mech-gpu','--no-default-features','--features','canonical-native-program','--lib']),
]
receipt={'scope':'correctness and feature qualification; no performance measurements','checks':[]}
for name,argv in checks:
 start=time.monotonic()
 with (folder/name).open('w') as f: result=subprocess.run(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 log=(folder/name).read_text()
 item={'name':name,'command':argv,'exit_code':result.returncode,'wall_seconds':time.monotonic()-start,'passed_tests':[int(n) for n in re.findall(r'test result: ok[.] (\d+) passed',log)]}
 receipt['checks'].append(item);(folder/'qualification-checks.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(name,'exit',result.returncode,'passed',item['passed_tests'],flush=True)
 if result.returncode:raise SystemExit(result.returncode)
