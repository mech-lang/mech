import importlib.util,json,pathlib,statistics,subprocess
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
protocol,cases=b.protocol();q=b.read(folder/'qualification.json');checkpoint=b.read(folder/'source-checkpoint.json')
assert b.compiler_fingerprint()==q['compiler_fingerprint']==checkpoint['compiler_fingerprint'];assert q['tests']==584 and all(c['exit_code']==0 for c in q['checks'])
actors={'accepted31':pathlib.Path('/private/tmp/mech-polybench-optimization/round-31/inverse-bitcasts/bitcast-driver'),'fold':folder/'fold-driver'}
assert b.digest(actors['accepted31'])==b.read(b.FIXTURE/'round-31-frozen.json')['driver_sha256'];assert b.digest(actors['fold'])==q['driver_sha256']
def counters(report):
 prefix='NativeProgramExecutionReport { ';assert report.startswith(prefix) and report.endswith(' }')
 pairs=[s.split(': ') for s in report[len(prefix):-2].split(', ')];assert all(len(p)==2 and p[1].isdecimal() for p in pairs)
 return {k:int(v) for k,v in pairs}
r={'schema':'mech.polybench.training-probe.v1','created_at':b.utc(),'scope':'Optimization15 only; seven samples per sequential actor with rotating case order. Full C warmup validation. Every execution counter must match accepted31 exactly. No holdout performance.','compiler_fingerprint':b.compiler_fingerprint(),'source_parent':b.command(['git','rev-parse','HEAD']),'driver_sha256':q['driver_sha256'],'samples_per_actor':7,'cases':{}}
for i,name in enumerate(protocol['optimization']):
 config=folder/f'{name}-inputs.json';b.write(config,cases[name]['inputs']);observations={};order=list(actors);order=order[i%2:]+order[:i%2]
 for label in order:
  process=subprocess.run([str(actors[label]),str(b.FIXTURE/f'{name}.mec'),str(config),'7'],text=True,capture_output=True,check=True,timeout=180)
  result=json.loads(process.stdout.strip().splitlines()[-1]);assert result['status']=='ok'
  observations[label]={'driver_sha256':b.digest(actors[label]),'samples_seconds':result['samples_seconds'],'median_seconds':statistics.median(result['samples_seconds']),'warmup_validation':b.validate(result['values'],cases[name]['expected']),'execution_report':result['report'],'execution_counters':counters(result['report'])}
 delta={k:observations['fold']['execution_counters'][k]-v for k,v in observations['accepted31']['execution_counters'].items()};assert all(v==0 for v in delta.values()),(name,delta)
 ratio=observations['accepted31']['median_seconds']/observations['fold']['median_seconds']
 r['cases'][name]={'source_sha256':b.digest(b.FIXTURE/f'{name}.mec'),'actors':observations,'speedup_vs_accepted31':ratio,'execution_counter_deltas':delta,'all_counters_match':True};b.write(folder/'training-probe.json',r)
 print(name,'vs31',round(ratio,5),'x','candidate_ms',round(observations['fold']['median_seconds']*1000,6),flush=True)
ratios=[c['speedup_vs_accepted31'] for c in r['cases'].values()]
r['summary']={'count':15,'geomean_raw_speedup_vs_accepted31':b.geomean(ratios),'regressions_over_five_percent':sum(x<1/1.05 for x in ratios),'sum_candidate_median_seconds':sum(c['actors']['fold']['median_seconds'] for c in r['cases'].values()),'sum_reference_median_seconds':sum(c['actors']['accepted31']['median_seconds'] for c in r['cases'].values())}
assert b.compiler_fingerprint()==q['compiler_fingerprint'];r['completed_at']=b.utc();b.write(folder/'training-probe.json',r);print(json.dumps(r['summary']),flush=True)
