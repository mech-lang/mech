import importlib.util,pathlib,json,subprocess,time,os,re
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
fp=b.compiler_fingerprint();assert b.read(folder/'ownership-focused-result.json')['exit_code']==0
core_paths=['src/core/src/snapshot/numeric_matrix.rs','src/core/src/snapshot/numeric_matrix_tests.rs','src/core/src/snapshot/validation.rs']
assert b.command(['git','diff','--',*core_paths])==(folder/'ownership-source.patch').read_text(), 'Core source changed since independent targeted tests'
env=os.environ.copy();env['CARGO_TARGET_DIR']='/private/tmp/mech-polybench-pr1000-target'
checks=[
 ('ownership-snapshot-regressions.log',['cargo','test','--release','-p','mech-core','-p','mech-gpu','--no-default-features','--features','mech-gpu/canonical-native-program','--lib','--','snapshot::validation','numeric_regions','matrix_node_footprint','--test-threads=1']),
 ('ownership-matrix-polybench.log',['cargo','test','--release','-p','mech-gpu','--no-default-features','--features','canonical-native-program','--test','canonical_artifact_matrix','--test','canonical_artifact_polybench','--','--test-threads=1']),
 ('ownership-runtime-feature.log',['cargo','check','--release','-p','mech-gpu','--no-default-features','--features','canonical-native-program-runtime','--lib']),
 ('ownership-production-feature.log',['cargo','check','--release','-p','mech-gpu','--no-default-features','--features','canonical-native-program','--lib']),
]
r={'schema':'mech.polybench.component-qualification.v1','created_at':b.utc(),'compiler_fingerprint':fp,'scope':'Source region inventory and shared Core owner pricing correctness/features; no performance measurements or complete-region execution selection.','checks':[]}
checks.sort(key=lambda c: (0 if 'feature' in c[0] else 1, c[0]))
for name,argv in checks:
 start=time.monotonic()
 with (folder/name).open('w') as log:result=subprocess.run(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 text=(folder/name).read_text();item={'name':name,'command':argv,'exit_code':result.returncode,'wall_seconds':time.monotonic()-start,'passed_tests':[int(n) for n in re.findall(r'test result: ok[.] (\d+) passed',text)]};r['checks'].append(item);b.write(folder/'component-qualification.json',r);print(name,'exit',result.returncode,'passed',item['passed_tests'],flush=True)
 assert b.compiler_fingerprint()==fp
 if result.returncode:raise SystemExit(result.returncode)
r['complete']=True;r['total_selected_checks']=sum(sum(c['passed_tests']) for c in r['checks']);b.write(folder/'component-qualification.json',r);print('Component qualification complete',r['total_selected_checks'],flush=True)
