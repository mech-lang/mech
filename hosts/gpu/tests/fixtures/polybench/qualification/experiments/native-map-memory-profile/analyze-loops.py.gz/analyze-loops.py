"""Offline PC-to-natural-loop attribution for accepted31 optimization-only Gram."""
import collections,hashlib,importlib.util,json,re
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
assert b.compiler_fingerprint()=='6447915ae298711f3886c6cba28e0608eb3ce59feab6287308162e45e006c895'
profile=Path('/private/tmp/mech-polybench-optimization/round-32/profile');receipt=b.read(profile/'training-profile.json')
assert receipt['compiler_fingerprint']==b.compiler_fingerprint() and receipt['driver_sha256']==b.digest('/private/tmp/mech-polybench-optimization/round-31/inverse-bitcasts/bitcast-driver')
spec=importlib.util.spec_from_file_location('samples',root/'scripts/analyze-polybench-samples.py');samples=importlib.util.module_from_spec(spec);spec.loader.exec_module(samples)
raw=profile/'gramschmidt.sample.txt';mapping=profile/'gramschmidt.perf.map';records=samples.parse_nodes(raw.read_text());ranges=samples.resolve_jit(records,mapping)
target='mech_canonical_program_entry_v1_numeric_5';pcs=collections.Counter()
for row in records:
 if row.get('jit_symbol')==target and row['self']:pcs[row['jit_offset']]+=row['self']
analysis=b.read(profile/'profile-analysis.json')[raw.name]
assert sum(pcs.values())==next(row['samples'] for row in analysis['jit_functions'] if row['name']==target)==174
assert analysis['sample_sha256']==b.digest(raw) and analysis['jit_map_sha256']==b.digest(mapping)
source=Path('/private/tmp/mech-polybench-optimization/round-38/hoisted-map-bounds/native-loop-census.py').read_text()
needle="'loops':inner_rows,"
assert needle in source
source=source.replace(needle,"'loops':inner_rows, 'all_loop_members':{lines[h][0]:[lines[i][0] for i in sorted(s)] for h,s in loops.items()}, 'instructions_by_address':{a:[op,args] for a,op,args in lines},")
ns={'__name__':'offline_census'};exec(compile(source,'preserved-native-loop-census.py','exec'),ns)
obj=Path('/private/tmp/mech-polybench-optimization/round-31/inverse-bitcasts/objects/gramschmidt.o');asm=obj.with_suffix('.disasm.txt')
census=ns['measure'](asm.read_text(),target)
base=next(int(m[1],16) for m in re.finditer(r'^([0-9a-f]+) <_'+target+r'>:',asm.read_text(),re.M))
assert base==0
members={int(h):set(s) for h,s in census['all_loop_members'].items()};instructions=census['instructions_by_address'];attributed=collections.Counter();outside=collections.Counter()
for offset,count in pcs.items():
 address=base+offset;assert address in instructions
 containing=[h for h,s in members.items() if address in s]
 if containing:attributed[min(containing,key=lambda h:len(members[h]))]+=count
 else:outside[address]+=count
rows=[]
for h,s in sorted(members.items()):
 ops=collections.Counter(instructions[a][0] for a in s)
 row={'header':h,'header_hex':hex(h),'static_instructions':len(s),'self_samples':attributed[h],'percent_of_jit_self':100*attributed[h]/sum(pcs.values()),'opcodes':dict(ops),'sampled_instructions':[{'offset':a,'hex':hex(a),'samples':pcs[a-base],'instruction':' '.join(instructions[a])} for a in sorted(s) if pcs[a-base]]}
 if len(s)<=16:row['all_instructions']=[{'offset':a,'instruction':' '.join(instructions[a])} for a in sorted(s)]
 rows.append(row)
rows.sort(key=lambda row:-row['self_samples'])
r={'schema':'mech.polybench.training-native-loop-profile.v1','scope':'Offline analysis of retained same-driver accepted31 optimization Gram samples. No new processes, performance samples, compiler changes or holdout diagnosis.','compiler_fingerprint':receipt['compiler_fingerprint'],'driver_sha256':receipt['driver_sha256'],'source_commit':receipt['source_commit'],'raw_sample_sha256':b.digest(raw),'map_sha256':b.digest(mapping),'object_sha256':b.digest(obj),'disassembly_sha256':b.digest(asm),'native_function':target,'execution_samples':analysis['execution_samples'],'jit_self_samples':sum(pcs.values()),'loop_attributed_samples':sum(attributed.values()),'outside_loop_samples':sum(outside.values()),'loops':rows,'outside_loop_instructions':[{'offset':a,'samples':n,'instruction':' '.join(instructions[a])} for a,n in outside.most_common()],'cfg_method':census['method'],'cautions':['PC attribution is sampled, not exact instruction cost. The174 generated-code samples are coarse; each PC is assigned to its smallest containing natural loop.','The prior round30 native-attribution capture has a different fingerprint and was inspected only to locate analysis tooling; its PCs are not used here.','No benchmark timing or acceptance score is produced.']}
b.write(folder/'loop-attribution.json',r)
print(json.dumps({'execution_samples':r['execution_samples'],'jit_self_samples':r['jit_self_samples'],'outside':r['outside_loop_samples'],'loops':[dict(header=x['header_hex'],instructions=x['static_instructions'],samples=x['self_samples'],opcodes=x['opcodes'],sampled=x['sampled_instructions'][:2]) for x in rows[:10]]},indent=2))
