//! Shared native word/field and unsigned matrix emission for numeric regions.
use crate::native_artifact::NativeCompileError;
use crate::native_artifact::codegen::common::{aggregates, ssa_words::Words};
use crate::native_artifact::codegen::control::plan::CodePlan;
use crate::native_artifact::codegen::options::{OptimizationOptions, OptimizationPass};
use crate::native_artifact::compiler::backend;
use crate::native_artifact::program::prepare::readonly_numeric::{FrameWords, Operation, Proof};
use cranelift_codegen::ir::condcodes::IntCC;
use cranelift_codegen::ir::{Block, InstBuilder, MemFlags, Value, types};
use cranelift_frontend::FunctionBuilder;
use mech_engine::native_artifact::{
    NativeBufferFrameOperation as Frame, NativeIterationAction as Action,
    NativeIterationTerminator as Term, NativeMatchAction as Scalar,
    NativeMatchTerminator as Branch,
};
use std::collections::BTreeSet;

/// The entry witness validates these exact dimensions before lending a view.
/// Replacements preserve its shape; an append changes its logical length and
/// must never use this certificate, even if an earlier schema was fixed.
pub(super) fn fixed_length(code: CodePlan<'_>, proof: &Proof, array: usize) -> Option<u64> {
    let array = proof.arrays.get(array)?;
    if array.appends {
        return None;
    }
    let Action::LibraryCall { template, .. } = code.blocks().get(array.witness)?.action() else {
        return None;
    };
    let mech_core::SchemaBody::Matrix { dimensions, .. } = template.inputs().first()?.body() else {
        return None;
    };
    if dimensions.len() != 2 {
        return None;
    }
    dimensions.iter().try_fold(1u64, |size, dimension| {
        let mech_core::DimensionExpr::Constant(value) = dimension else {
            return None;
        };
        size.checked_mul(*value)
    })
}

/// Only for a packed cell load AFTER the original logical bounds check (or
/// its current-window proof) and the row-major address translation. Entry
/// validated the exact typed slice and dimensions and retains its owner for
/// this synchronous loan. Packed reads independently check their whole window.
/// Thus this access cannot fault at this point. It is still dependent on
/// control and mutable memory: no readonly, can_move, alignment or alias claim.
pub(super) fn guarded_load_flags(options: OptimizationOptions) -> MemFlags {
    if options.enabled(OptimizationPass::GuardedNumericLoads) {
        MemFlags::new().with_notrap()
    } else {
        MemFlags::new()
    }
}

/// Read one admitted unsigned packed cell directly into its canonical word.
/// `ty` is the validated physical access type, not the result type. An I64
/// result from ULoad8/16/32 still reads exactly one, two, or four bytes.
/// Keeping extension in the memory operation avoids a separate narrow SSA
/// value whose pure extension may move across source blocks before lowering.
/// Address/selector proofs and every memory flag remain the caller's authority.
pub(in crate::native_artifact) fn load_unsigned_word(
    b: &mut FunctionBuilder<'_>,
    ty: cranelift_codegen::ir::Type,
    flags: MemFlags,
    address: Value,
    offset: i32,
) -> Value {
    match ty {
        types::I8 => b.ins().uload8(types::I64, flags, address, offset),
        types::I16 => b.ins().uload16(types::I64, flags, address, offset),
        types::I32 => b.ins().uload32(flags, address, offset),
        types::I64 => b.ins().load(types::I64, flags, address, offset),
        _ => unreachable!("unsigned word load requires a validated physical width"),
    }
}

pub(super) fn source_slots(
    code: CodePlan<'_>,
    sites: impl IntoIterator<Item = usize>,
    actions: &[(usize, Operation)],
    scratch: impl IntoIterator<Item = usize>,
) -> Result<BTreeSet<usize>, NativeCompileError> {
    let mut slots = BTreeSet::from_iter(scratch);
    for site in sites {
        match code.blocks()[site].action() {
            Action::Scalar(Scalar::Primitive {
                operands, output, ..
            }) => {
                slots.extend(operands.iter().map(|v| v.get() as usize));
                slots.insert(output.get() as usize);
            }
            Action::Scalar(Scalar::Copy { source, output }) if code.kind(*output).is_some() => {
                slots.extend([source.get() as usize, output.get() as usize]);
            }
            Action::Structural { output, .. } | Action::LibraryCall { output, .. }
                if code.kind(*output).is_some() =>
            {
                slots.insert(output.get() as usize);
            }
            _ => {}
        }
        match actions
            .iter()
            .find(|(s, _)| *s == site)
            .map(|(_, action)| action)
        {
            Some(action @ (Operation::Reduce { .. } | Operation::Map { .. })) => {
                slots.extend(action.summary_values().into_iter().map(|v| v as usize));
            }
            Some(Operation::Read { index, .. }) => {
                slots.insert(*index as usize);
            }
            Some(Operation::Write {
                index, incoming, ..
            }) => {
                slots.extend([*index as usize, *incoming as usize]);
            }
            Some(Operation::CellRead { row, column, .. }) => {
                slots.extend([*row as usize, *column as usize]);
            }
            Some(Operation::CellWrite {
                row,
                column,
                incoming,
                ..
            }) => {
                slots.extend([*row as usize, *column as usize, *incoming as usize]);
            }
            Some(Operation::Append { incoming, .. }) => {
                slots.insert(*incoming as usize);
            }
            Some(Operation::AppendLeBytes {
                incoming, count, ..
            }) => {
                slots.extend([*incoming as usize, *count as usize]);
            }
            _ => {}
        }
        if let CodePlan::Program(program) = code {
            if let Some(action) = program.metadata().scalar_aggregates.action(site) {
                aggregates::aggregate_words(
                    &program.metadata().scalar_aggregates,
                    action,
                    &mut slots,
                )
                .ok_or_else(|| backend("numeric aggregate lost exact word lanes"))?;
            }
            if let Some(frame) = program.metadata().buffer_frames.action(site) {
                match frame.operation() {
                    Frame::Pack { .. } => {
                        if let Action::LibraryCall { operands, .. } = code.blocks()[site].action() {
                            slots.extend(
                                operands
                                    .iter()
                                    .filter(|v| code.kind(**v).is_some())
                                    .map(|v| v.get() as usize),
                            );
                        }
                    }
                    Frame::Project { output, .. } if code.kind(*output).is_some() => {
                        slots.insert(output.get() as usize);
                    }
                    _ => {}
                }
            }
        }
        match code.blocks()[site].terminator() {
            Term::Scalar(Branch::Branch { condition, .. }) => {
                slots.insert(condition.get() as usize);
            }
            Term::Scalar(Branch::LiteralBranch { left, right, .. }) => {
                slots.extend([left.get() as usize, right.get() as usize]);
            }
            _ => {}
        }
    }
    Ok(slots)
}
/// Original read/write ordering, shared with the current-traversal analysis.
#[path = "numeric_prefix_words.rs"]
mod prefix;
pub(super) use prefix::entry as prefix_inputs;
pub(super) struct FrameWordMoves {
    pub assignments: Vec<(usize, usize)>,
    pub parallel: bool,
    pub constants: Vec<(usize, u64)>,
    pub comparisons: Vec<(usize, usize, u64)>,
}

/// Exact scalar lane assignments; managed fields retain their checked recipes.
pub(super) fn frame_word_moves(
    shadow: usize,
    code: CodePlan<'_>,
    site: usize,
    recipes: &[FrameWords],
) -> Result<FrameWordMoves, NativeCompileError> {
    frame_word_moves_for(shadow, code, site, recipes, None)
}

pub(super) fn frame_word_moves_for(
    shadow: usize,
    code: CodePlan<'_>,
    site: usize,
    recipes: &[FrameWords],
    variant: Option<&crate::native_artifact::program::prepare::readonly_numeric::tagged::Variant>,
) -> Result<FrameWordMoves, NativeCompileError> {
    let CodePlan::Program(program) = code else {
        return Err(backend("numeric frame lacks managed plan"));
    };
    let recipe = |value| {
        recipes
            .iter()
            .find(|f| f.value == value)
            .ok_or_else(|| backend("numeric frame lost exact scalar fields"))
    };
    let operation = program
        .metadata()
        .buffer_frames
        .action(site)
        .ok_or_else(|| backend("numeric frame lost fields"))?
        .operation();
    if let Some(prefix) = variant.and_then(|variant| variant.prefix.as_deref()) {
        if let Some(moves) = prefix::moves(shadow, code, operation, recipes, prefix)? {
            return Ok(moves);
        }
    }
    if let (
        Some(variant),
        Frame::Observe {
            source,
            path,
            observation,
            output,
        },
    ) = (variant, operation)
        && variant.contains(source.get())
        && path.is_empty()
        && let mech_engine::native_artifact::NativeStructuralObservation::EnumOrdinal { ordinal } =
            observation
    {
        return Ok(FrameWordMoves {
            assignments: Vec::new(),
            comparisons: Vec::new(),
            parallel: true,
            constants: vec![(
                output.get() as usize,
                u64::from(*ordinal == variant.ordinal),
            )],
        });
    }
    let projected = variant.and_then(|variant| {
        crate::native_artifact::program::prepare::readonly_numeric::tagged::operation(
            operation, variant,
        )
    });
    let operation = projected.as_ref().unwrap_or(operation);
    let assignments = match operation {
        Frame::EnumPack { .. } | Frame::Observe { .. } => {
            return Err(backend("tagged frame outside numeric word emitter"));
        }
        Frame::Pack { output } => {
            let Action::LibraryCall { operands, .. } = code.blocks()[site].action() else {
                return Err(backend("numeric pack lost operands"));
            };
            let mut copied = Vec::new();
            for (ordinal, operand) in operands.iter().enumerate() {
                let target = recipe(output.get())?
                    .field_slots(ordinal)
                    .collect::<Vec<_>>();
                if target.is_empty() {
                    continue;
                }
                if code.kind(*operand).is_some() {
                    if target.len() != 1 {
                        return Err(backend("numeric scalar pack span differs"));
                    }
                    copied.push((shadow + target[0], operand.get() as usize));
                } else {
                    let source = recipe(operand.get())?.scalar_slots().collect::<Vec<_>>();
                    if source.len() != target.len() {
                        return Err(backend("numeric composite pack span differs"));
                    }
                    copied.extend(
                        source
                            .into_iter()
                            .zip(target)
                            .map(|(from, to)| (shadow + to, shadow + from)),
                    );
                }
            }
            copied
        }
        Frame::Copy { source, output } => recipe(source.get())?
            .scalar_slots()
            .zip(recipe(output.get())?.scalar_slots())
            .map(|(from, to)| (shadow + to, shadow + from))
            .collect(),
        Frame::Project {
            source,
            ordinal,
            output,
        } => {
            if let Some(field) = recipe(source.get())?.fields[*ordinal] {
                vec![(output.get() as usize, shadow + field)]
            } else {
                let source = recipe(source.get())?
                    .field_slots(*ordinal)
                    .collect::<Vec<_>>();
                if source.is_empty() {
                    return Ok(FrameWordMoves {
                        assignments: Vec::new(),
                        comparisons: Vec::new(),
                        parallel: true,
                        constants: Vec::new(),
                    });
                }
                let target = recipe(output.get())?.scalar_slots().collect::<Vec<_>>();
                if source.len() != target.len() {
                    return Err(backend("numeric composite projection span differs"));
                }
                source
                    .into_iter()
                    .zip(target)
                    .map(|(from, to)| (shadow + to, shadow + from))
                    .collect()
            }
        }
    };
    // Composite spans may overlap. Match the existing read-all/write-all
    // emission, and expose that ordering to current-traversal proofs.
    Ok(FrameWordMoves {
        assignments,
        comparisons: Vec::new(),
        parallel: true,
        constants: Vec::new(),
    })
}

pub(super) fn frame_words(
    b: &mut FunctionBuilder<'_>,
    words: &Words,
    shadow: usize,
    code: CodePlan<'_>,
    site: usize,
    recipes: &[FrameWords],
    variant: Option<&crate::native_artifact::program::prepare::readonly_numeric::tagged::Variant>,
) -> Result<(), NativeCompileError> {
    let moves = frame_word_moves_for(shadow, code, site, recipes, variant)?;
    for (to, from, ordinal) in moves.comparisons {
        let tag = words.read(b, from);
        let equal = b.ins().icmp_imm(
            cranelift_codegen::ir::condcodes::IntCC::Equal,
            tag,
            ordinal as i64,
        );
        let bits = b.ins().uextend(types::I64, equal);
        words.write(b, to, bits);
    }
    for (to, bits) in moves.constants {
        let value = b.ins().iconst(types::I64, bits as i64);
        words.write(b, to, value);
    }
    let copied = moves
        .assignments
        .into_iter()
        .map(|(to, from)| (to, words.read(b, from)))
        .collect::<Vec<_>>();
    for (to, value) in copied {
        words.write(b, to, value);
    }
    Ok(())
}

/// Map an admitted zero-based logical ordinal into canonical matrix backing.
/// The original one-based bounds check must precede this shared operation.
pub(in crate::native_artifact) fn linear_ordinal(
    b: &mut FunctionBuilder<'_>,
    ordinal: Value,
    rows: Value,
    columns: Value,
    schema: &mech_core::SchemaBody,
) -> Value {
    // The same entry witness that lends this view has already checked the
    // current owner's exact schema and dimensions. A unit dimension makes
    // column-major source order identical to row-major backing order. Derive
    // this immutable fact from that witness, never from a previous view.
    let vector = matches!(schema, mech_core::SchemaBody::Matrix { dimensions, .. }
        if dimensions.len() == 2 && dimensions.iter().any(|dimension|
            matches!(dimension, mech_core::DimensionExpr::Constant(1))));
    if vector {
        ordinal
    } else {
        // Generic schemas can still carry a current row or column vector.
        // The caller has checked this admitted view's bounds, so either unit
        // dimension makes the physical ordinal identical to source order.
        let one_row = b.ins().icmp_imm(IntCC::Equal, rows, 1);
        let one_column = b.ins().icmp_imm(IntCC::Equal, columns, 1);
        let contiguous = b.ins().bor(one_row, one_column);
        let general = b.create_block();
        let done = b.create_block();
        b.append_block_param(done, types::I64);
        b.ins()
            .brif(contiguous, done, &[ordinal.into()], general, &[]);
        b.switch_to_block(general);
        let column = b.ins().udiv(ordinal, rows);
        // Bounds on the admitted view prove rows > 0. Reuse the quotient:
        // column * rows <= ordinal, so this internal remainder cannot overflow.
        // Separate urem/udiv lower to duplicate machine divisions on AArch64.
        let consumed = b.ins().imul(column, rows);
        let row = b.ins().isub(ordinal, consumed);
        let row = b.ins().imul(row, columns);
        let physical = b.ins().iadd(row, column);
        b.ins().jump(done, &[physical.into()]);
        b.switch_to_block(done);
        b.block_params(done)[0]
    }
}

/// Canonical linear selection is column-major over row-major physical storage.
/// Call only after the admitted unsigned view and one-based bounds check.
pub(super) fn linear_address(
    b: &mut FunctionBuilder<'_>,
    ordinal: Value,
    rows: Value,
    columns: Value,
    width: u8,
    schema: &mech_core::SchemaBody,
    base: impl FnOnce(&mut FunctionBuilder<'_>) -> Value,
) -> Result<(Value, cranelift_codegen::ir::Type), NativeCompileError> {
    let physical = linear_ordinal(b, ordinal, rows, columns, schema);
    element_address(b, physical, width, base)
}

/// Address an already translated physical element ordinal. A guarded vector
/// entry may supply its logical ordinal directly: for either unit dimension,
/// canonical source order and backing order are identical. Bounds still precede
/// this operation, and packed element width remains independent of geometry.
pub(super) fn element_address(
    b: &mut FunctionBuilder<'_>,
    physical: Value,
    width: u8,
    base: impl FnOnce(&mut FunctionBuilder<'_>) -> Value,
) -> Result<(Value, cranelift_codegen::ir::Type), NativeCompileError> {
    let at = b.ins().imul_imm(physical, i64::from(width));
    let base = base(b);
    let address = b.ins().iadd(base, at);
    let ty = match width {
        1 => types::I8,
        2 => types::I16,
        4 => types::I32,
        8 => types::I64,
        _ => return Err(backend("numeric load width differs")),
    };
    Ok((address, ty))
}

#[cfg(all(test, feature = "canonical-native-program"))]
#[path = "numeric_address_tests.rs"]
mod tests;

#[cfg(all(test, feature = "canonical-native-program"))]
#[path = "numeric_unsigned_load_tests.rs"]
mod unsigned_load_tests;

/// A raw native Bool store must never create an invalid Rust bool in the
/// privately owned initialized bank. Other exact scalar kinds accept all bits.
pub(super) fn guard_scalar_store(
    b: &mut FunctionBuilder<'_>,
    code: CodePlan<'_>,
    site: usize,
    incoming: Value,
    fail: Block,
) -> Result<(), NativeCompileError> {
    let Action::LibraryCall { operands, .. } = code.blocks()[site].action() else {
        return Err(backend("numeric store lost its selected scalar operation"));
    };
    if code.kind(operands[1]) == Some(mech_engine::native_artifact::NativeScalarKind::Bool) {
        let valid = b
            .ins()
            .icmp_imm(IntCC::UnsignedLessThanOrEqual, incoming, 1);
        let good = b.create_block();
        let bad = b.create_block();
        b.set_cold_block(bad);
        b.ins().brif(valid, good, &[], bad, &[]);
        b.switch_to_block(bad);
        let status = b
            .ins()
            .iconst(types::I64, crate::native_artifact::abi::STATUS_ABI as i64);
        b.ins().jump(fail, &[status.into()]);
        b.switch_to_block(good);
    }
    Ok(())
}

/// Independent one-based axes over an entry-validated canonical row-major
/// view. Check both pure axes, then compute only a physical ordinal.
/// The caller's cold block executes the original selected rejecting operation.
pub(super) fn cell_address(
    b: &mut FunctionBuilder<'_>,
    row: Value,
    column: Value,
    rows: Value,
    columns: Value,
    width: u8,
    base: Value,
    bad: Block,
) -> Result<(Value, cranelift_codegen::ir::Type), NativeCompileError> {
    let row = b.ins().iadd_imm(row, -1);
    let row_valid = b.ins().icmp(IntCC::UnsignedLessThan, row, rows);
    let column = b.ins().iadd_imm(column, -1);
    let column_valid = b.ins().icmp(IntCC::UnsignedLessThan, column, columns);
    // Both tests are pure words already available at this source operation.
    // One miss edge replays the same original operation, retaining its exact
    // axis error order. Neither an address nor a load precedes both bounds.
    let valid = b.ins().band(row_valid, column_valid);
    let good = b.create_block();
    b.ins().brif(valid, good, &[], bad, &[]);
    b.switch_to_block(good);
    cell_address_from_ordinals(b, row, column, columns, width, base)
}

/// Physical address after both zero-based axes have current-view bounds proofs.
/// The caller retains the exact typed owner and its complete pointer span.
/// No bounds, lifetime, alignment or alias authority is created here.
pub(super) fn cell_address_from_ordinals(
    b: &mut FunctionBuilder<'_>,
    row: Value,
    column: Value,
    columns: Value,
    width: u8,
    base: Value,
) -> Result<(Value, cranelift_codegen::ir::Type), NativeCompileError> {
    let start = b.ins().imul(row, columns);
    let physical = b.ins().iadd(start, column);
    element_address(b, physical, width, |_| base)
}
