"""Preserve the one qualified training experiment before accepting or rejecting it."""
import gzip
import hashlib
import importlib.util
from pathlib import Path

root = Path.cwd()
folder = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("b", root / "scripts/benchmark-polybench.py")
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
p = b.FIXTURE
q = b.read(folder / "qualification.json")
census = b.read(folder / "execution-emission-census.json")
probe = b.read(folder / "training-probe.json")
fp = b.compiler_fingerprint()
assert q["complete"] and census["complete"] and probe["complete"]
assert fp == q["compiler_fingerprint"] == census["compiler_fingerprint"] == probe["compiler_fingerprint"]
assert q["driver_sha256"] == census["driver_sha256"] == probe["driver_sha256"]
assert all(c["exit_code"] == 0 for c in q["checks"])
assert probe["summary"]["all_visits_match"] and probe["summary"]["all_work_not_reduced"]
assert len(probe["cases"]) == 15
assert sum(len(c["observations"]) for c in probe["cases"].values()) == 210
dest = p / "qualification/round-38-versioned-map-bounds/development"
dest.mkdir(parents=True, exist_ok=False)
archives = {}
paths = [x for x in folder.iterdir() if x.is_file() and x.suffix in (".py", ".json", ".log")]
paths += [x for x in (folder / "attempt-03").rglob("*") if x.is_file()]
paths += [x for x in (folder / "execution-objects").rglob("*") if x.is_file()]
for path in sorted(paths):
    name = str(path.relative_to(folder))
    raw = path.read_bytes()
    out = dest / (name + ".gz")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(out.read_bytes()) == raw
    archives[name] = {"path": str(out.relative_to(p)), "sha256": hashlib.sha256(raw).hexdigest(), "compressed_sha256": b.digest(out)}
invariants = [
    "All30 Mech ports, source inputs, C binaries/flags, F64 MINI dataset, limits, finite comparison tolerances, split, primary objective and formal timing/cache boundaries remain unchanged.",
    "General Cranelift map bounds predicates select a proved body or the unchanged checked body inside one shared native loop. No program-name checks, source rewrite, FP reassociation or FMA.",
    "Same source evaluation order, scalar operations, lazy reads, errors, current view/span/epoch guards, private output bank, native admission and exact source accounting. False range hypotheses never trigger early replay.",
    "The pass is shared by standalone maps, phase maps and nested reductions; an explicit test ablation retains the original per-read checked body. Unknown selectors keep checked reads in both paths.",
    "Prospective v2 selection uses seven fresh-process observations per actor per optimization case, interleaving accepted31 and candidate with alternating pair order. Every sample, case and regression is retained. This is the only observed probe for this source fingerprint.",
    "Holdout is reserved for the aggregate gate after source/driver freeze. No holdout implementation diagnosis, profiling or per-case tuning.",
]
out = dict(q)
out.update(
    schema="mech.polybench.training-qualification.v1",
    label="round38-versioned-map-bounds",
    invariants=invariants,
    profiling_basis={
        "receipt": "training-experiments/optimization-margin-profile.json",
        "scope": "All15 accepted31 optimization cases, descending Mech/C; no holdout profile.",
        "target": "gramschmidt",
        "accepted_mech_over_c": 54.48016,
        "execution_samples": 225,
        "hot_function_samples": 174,
        "hot_function": "mech_canonical_program_entry_v1_numeric_5",
        "actual_codegen_check": "Before timing, the actual hot function must change, preserve native loops and the original checked body, and show a bounds-proved CFG cycle that skips per-read axis comparisons. Static available-path counts are not measured runtime or path feasibility.",
    },
    total_unique_selected_checks=q["tests"],
    focused_selected_checks=sum(q["focused_checks"]["passed_tests"]),
    development_failure_receipt="training-experiments/hoisted-map-bounds-development-failure.json",
    development_archives=archives,
    limitations="F64 MINI CPU benchmark scope. Short-kernel profiles are coarse. The fixed holdout has been exposed historically and is an aggregate acceptance control. This training probe does not establish a formal Mech/C score or authorize promotion.",
    training_probe_summary=probe["summary"],
)
for suffix, value in [("training-qualification", out), ("training-probe", probe), ("emission-census", census), ("training-selection", {
    "schema": "mech.polybench.training-selection.v2",
    "compiler_fingerprint": fp,
    "driver_sha256": q["driver_sha256"],
    "accepted_round": 31,
    "policy": probe["policy"],
    "result": probe["summary"],
    "selected": probe["summary"]["selected"],
    "formal_evaluation_started": False,
})]:
    path = p / f"round-38-{suffix}.json"
    assert not path.exists()
    b.write(path, value)
print({"compiler_fingerprint": fp, "archives": len(archives), "checks": q["tests"], "probe": probe["summary"], "formal_observations": 0}, flush=True)
