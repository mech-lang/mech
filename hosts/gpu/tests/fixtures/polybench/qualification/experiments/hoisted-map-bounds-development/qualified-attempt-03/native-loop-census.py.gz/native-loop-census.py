"""Instruction CFG census of real AArch64 checked Objects, never execution."""
import re

def measure(assembly, target):
    lines = []
    active = False
    for line in assembly.splitlines():
        label = re.match(r'^[0-9a-f]+ <_(.+)>:', line)
        if label:
            active = label[1] == target
            continue
        if active:
            ins = re.match(r'^\s*([0-9a-f]+):\s+(\S+)(?:\s+(.*))?$', line)
            if ins:
                lines.append((int(ins[1],16), ins[2], ins[3] or ''))
    assert lines and len({a for a,_,_ in lines}) == len(lines)
    address = {a:i for i,(a,_,_) in enumerate(lines)}
    successors = [set() for _ in lines]
    unsupported = []
    dispatches = []
    for i,(a,op,args) in enumerate(lines):
        conditional = op.startswith('b.') or op in ('cbz','cbnz','tbz','tbnz')
        branch = op == 'b' or conditional
        if branch:
            targets = re.findall(r'0x([0-9a-f]+)', args)
            assert targets, (a,op,args)
            target_address = int(targets[-1],16)
            if target_address in address:
                successors[i].add(address[target_address])
            else:
                unsupported.append((a,op,args))
        if op == 'br':
            # Cranelift's bounded AArch64 inline jump table. Its small positive
            # signed offsets disassemble as UDF words, not executable code.
            # Validate the exact dispatch shape and bound before adding edges.
            prefix = lines[i-6:i]
            data = []
            j = i+1
            while j < len(lines) and lines[j][1] == 'udf':
                data.append(lines[j])
                j += 1
            if len(prefix) == 6 and [x[1] for x in prefix] == ['cmp','b.hs','csel','adr','ldrsw','add'] and data:
                bound = re.search(r', #(\d+)$',prefix[0][2])
                adr = re.fullmatch(r'(x\d+), #(\d+)',prefix[3][2])
                assert bound and adr and int(bound[1]) == len(data)
                assert adr[1] == args.strip()
                table = prefix[3][0] + int(adr[2])
                assert table == data[0][0] == a+4
                targets = []
                for _,_,word in data:
                    offset = int(word.removeprefix('#'),0)
                    target_address = table + offset
                    assert target_address in address and lines[address[target_address]][1] != 'udf'
                    successors[i].add(address[target_address])
                    targets.append(target_address)
                dispatches.append({'branch':a,'table':table,'bound':len(data),'targets':targets})
            else:
                unsupported.append((a,op,args))
        if op not in ('b','br','ret','retab','retaa') and i+1 < len(lines):
            successors[i].add(i+1)
    assert not unsupported, unsupported
    reachable = set()
    pending = [0]
    while pending:
        i = pending.pop()
        if i in reachable:
            continue
        reachable.add(i)
        pending.extend(successors[i])
    predecessors = [set() for _ in lines]
    for i in reachable:
        for j in successors[i]:
            predecessors[j].add(i)
    full = sum(1 << i for i in reachable)
    dominators = [full for _ in lines]
    dominators[0] = 1
    changed = True
    iterations = 0
    while changed:
        changed = False
        iterations += 1
        assert iterations <= len(lines)+1
        for i in sorted(reachable - {0}):
            pred = list(predecessors[i])
            assert pred
            result = dominators[pred[0]]
            for j in pred[1:]:
                result &= dominators[j]
            result |= 1 << i
            if result != dominators[i]:
                dominators[i] = result
                changed = True
    loops = {}
    for tail in reachable:
        for header in successors[tail]:
            if not dominators[tail] & (1 << header):
                continue
            members = {header,tail}
            pending = [tail] if tail != header else []
            while pending:
                for pred in predecessors[pending.pop()]:
                    if pred not in members:
                        members.add(pred)
                        if pred != header:
                            pending.append(pred)
            loops.setdefault(header,set()).update(members)
    inner = {h:s for h,s in loops.items() if not any(other < s for other in loops.values())}
    nodes = set().union(*inner.values()) if inner else set()
    def counters(nodes):
        return {
            'instructions':len(nodes),
            'integer_comparisons':sum(lines[i][1] in ('cmp','cmn','ccmp','ccmn') for i in nodes),
            'conditional_branches':sum(lines[i][1].startswith('b.') or lines[i][1] in ('cbz','cbnz','tbz','tbnz') for i in nodes),
        }
    def minimum_cycle(header,members):
        import heapq
        comparison=lambda i: int(lines[i][1] in ('cmp','cmn','ccmp','ccmn'))
        queue=[(comparison(header),1,header,(header,))]
        best={header:(comparison(header),1)}
        while queue:
            cost,length,node,path=heapq.heappop(queue)
            if best.get(node)!=(cost,length):
                continue
            for nxt in successors[node]:
                if nxt==header:
                    return {
                        'minimum_cycle_integer_comparisons':cost,
                        'cycle_conditional_branches':sum(lines[i][1].startswith('b.') or lines[i][1] in ('cbz','cbnz','tbz','tbnz') for i in path),
                        'cycle_instructions':length,
                        'cycle_addresses':[lines[i][0] for i in path],
                    }
                if nxt not in members:
                    continue
                score=(cost+comparison(nxt),length+1)
                if nxt not in best or score<best[nxt]:
                    best[nxt]=score
                    heapq.heappush(queue,(*score,nxt,path+(nxt,)))
        raise AssertionError('A natural loop must contain a head-to-backedge cycle')
    inner_rows=[{'header':lines[h][0],**counters(s),**minimum_cycle(h,s)} for h,s in sorted(inner.items())]
    return {
        'method':'AArch64 instruction CFG, reachable dominators and natural backedges; innermost loops contain no strict natural subloop. Static counts are not runtime percentages.',
        'instructions':len(lines), 'reachable_instructions':len(reachable),
        'natural_loops':len(loops), 'innermost_loops':len(inner),
        'innermost_union':counters(nodes),
        'loops':inner_rows,
        'minimum_cycle_comparison_sum':sum(row['minimum_cycle_integer_comparisons'] for row in inner_rows),
        'minimum_comparison_cycle_branch_sum':sum(row['cycle_conditional_branches'] for row in inner_rows),
        'cycle_limit':'Static minimum-comparison CFG cycles demonstrate an available path, not input feasibility, dynamic counts or measured speed. Differential execution proves current-input correctness and the subsequent one-probe measurements decide performance.',
        'unsupported_edges':unsupported,
        'decoded_dispatches':dispatches,
    }

if __name__ == '__main__':
    import json,sys
    from pathlib import Path
    print(json.dumps(measure(Path(sys.argv[1]).read_text(),sys.argv[2]),indent=2))
