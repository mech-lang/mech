from pathlib import Path
import subprocess

root = Path.cwd()
base = 'hosts/gpu/src/native_artifact/'
def previous(path):
    return subprocess.check_output(['git','show','19d478691e6eb5f62d6938a434ab3c4a1b6b0484:'+path],text=True)
for suffix in ['codegen/options.rs','codegen/control/mod.rs','program/codegen/numeric_phase_maps.rs','program/codegen/numeric_phase_reductions.rs','program/codegen/readonly_numeric.rs']:
    path=base+suffix
    text=previous(path).replace('RectangularMapInduction','HoistedMapBounds').replace('rectangular_induction','hoisted_bounds')
    text=text.replace('Carry source row/column coordinates in rectangular map loops.', 'Guard current readonly map selector ranges before the element loop.')
    Path(path).write_text(text)
path=Path(base+'program/codegen/numeric_map.rs')
accepted=subprocess.check_output(['git','show','c7d5c1fc209e08ef8cb3d8c83ecd47ce1f5ebe84:'+str(path)],text=True)
text=previous(str(path))
start='    let head = b.create_block();'
end='    let word = if region.range {'
text=text[:text.index(start)]+accepted[accepted.index(start):accepted.index(end,accepted.index(start))]+text[text.index(end,text.index(start)):]
start='    b.switch_to_block(latch);'
end='    b.switch_to_block(done);'
text=text[:text.index(start)]+accepted[accepted.index(start):accepted.index(end,accepted.index(start))]+text[text.index(end,text.index(start)):]
text=text.replace('rectangular_induction','hoisted_bounds')
marker='    // Source phi copies share a native SSA variable.'
insert='''    // A failed current-range guard declines this private map before source
    // settlement. Unknown selectors keep their original per-read checks.
    let hoisted_reads = if hoisted_bounds {
        super::numeric_map_bounds::emit(
            b, region, &matrices, captures, start, source_count, count, index_miss,
        )?
    } else {
        Default::default()
    };
'''
assert text.count(marker)==1
text=text.replace(marker,insert+marker)
old='            let value = emit_read(b, read, region, plan, &matrices, &words, index_miss)?;'
new='''            let value = emit_read(
                b, read, region, plan, &matrices, &words,
                hoisted_reads.contains(&read.site), index_miss,
            )?;'''
assert old in text
text=text.replace(old,new)
old='''    words: &BTreeMap<u32, Variable>,
    miss: Block,
) -> Result<Value, NativeCompileError> {'''
new=old.replace('    miss: Block,','    bounds_proven: bool,\n    miss: Block,')
assert old in text
text=text.replace(old,new)
old='''            let valid = b.ins().icmp(IntCC::UnsignedLessThan, ordinal, cells);
            require(b, valid, miss);'''
new='''            if !bounds_proven {
                let valid = b.ins().icmp(IntCC::UnsignedLessThan, ordinal, cells);
                require(b, valid, miss);
            }'''
assert old in text
text=text.replace(old,new)
old='''        [row, column] => super::numeric_words::cell_address(
            b, *row, *column, rows, columns, width, pointer, miss,
        )?,'''
new='''        [row, column] if bounds_proven => {
            let row = b.ins().iadd_imm(*row, -1);
            let column = b.ins().iadd_imm(*column, -1);
            super::numeric_words::cell_address_from_ordinals(
                b, row, column, columns, width, pointer,
            )?
        }
'''+old
assert old in text
path.write_text(text.replace(old,new))
path=Path(base+'program/codegen/numeric_words.rs')
text=subprocess.check_output(['git','show','c7d5c1fc209e08ef8cb3d8c83ecd47ce1f5ebe84:'+str(path)],text=True)
old='''    let start = b.ins().imul(row, columns);
    let physical = b.ins().iadd(start, column);
    element_address(b, physical, width, |_| base)
}'''
new='''    cell_address_from_ordinals(b, row, column, columns, width, base)
}

/// Physical address after both zero-based axes have current-view bounds proofs.
/// The caller retains the exact typed owner and its complete pointer span.
/// No bounds, lifetime, alignment or alias authority is created here.
pub(super) fn cell_address_from_ordinals(
    b: &mut FunctionBuilder<'_>,
    row: Value,
    column: Value,
    columns: Value,
    width: u8,
    base: Value,
) -> Result<(Value, cranelift_codegen::ir::Type), NativeCompileError> {
    let start = b.ins().imul(row, columns);
    let physical = b.ins().iadd(start, column);
    element_address(b, physical, width, |_| base)
}'''
assert text.count(old)==1
path.write_text(text.replace(old,new))
path=Path(base+'program/codegen/mod.rs');text=subprocess.check_output(['git','show','c7d5c1fc209e08ef8cb3d8c83ecd47ce1f5ebe84:'+str(path)],text=True);marker='pub(in crate::native_artifact) mod numeric_map;';assert marker in text;path.write_text(text.replace(marker,marker+'\nmod numeric_map_bounds;'))
path=Path(base+'program/image/identity.rs');text=subprocess.check_output(['git','show','c7d5c1fc209e08ef8cb3d8c83ecd47ce1f5ebe84:'+str(path)],text=True);assert '390' in text;path.write_text(text.replace('390','401'))
path=Path(base+'program/runtime/composition_tests/mod.rs');text=subprocess.check_output(['git','show','c7d5c1fc209e08ef8cb3d8c83ecd47ce1f5ebe84:'+str(path)],text=True);path.write_text(text+'\nmod hoisted_map_bounds;\n')
test=previous(base+'program/runtime/composition_tests/rectangular_induction.rs').replace('RectangularMapInduction','HoistedMapBounds').replace('rectangular_map_induction','numeric_map_hoisted_bounds')
test=test.replace('//! Source-ordered rectangular maps, including empty outer ranges and failures.','//! Current map bounds, checked original fallback and empty sources.')
Path(base+'program/runtime/composition_tests/hoisted_map_bounds.rs').write_text(test)
