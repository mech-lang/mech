import importlib.util,json,pathlib,shutil,subprocess
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent;diag=folder/'regression-profile';old=pathlib.Path('/private/tmp/mech-polybench-optimization/round-32/profile')
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);_,cases=b.protocol();q=b.read(folder/'qualification.json');assert b.compiler_fingerprint()==q['compiler_fingerprint']
for name in ['dump-jit-code.py','compare-code.py']:shutil.copy2(old/name,diag/name)
objects=diag/'objects';objects.mkdir(exist_ok=False)
for suffix in ['.o','.metadata.json','.disasm.txt']:shutil.copy2(folder/'objects'/('seidel-2d'+suffix),objects/('seidel-2d'+suffix))
live=diag/'live-code/seidel-2d';live.mkdir(parents=True,exist_ok=False)
b.write(diag/'training-profile.json',{'analysis':{'seidel-2d':b.read(diag/'profile.json')['analysis']}})
s=(old/'seidel-2d-dump.lldb').read_text().replace(str(old),str(diag));(diag/'dump.lldb').write_text(s)
argv=['xcrun','lldb','-x','-b','--source',str(diag/'dump.lldb'),'--',str(folder/'cell-driver'),str(b.FIXTURE/'seidel-2d.mec'),str(folder/'seidel-2d-inputs.json'),'0']
process=subprocess.run(argv,text=True,capture_output=True,check=True,timeout=120);(diag/'lldb.log').write_text(process.stdout+process.stderr)
results=[json.loads(s) for s in process.stdout.splitlines() if s.startswith('{') and '"values"' in s];assert len(results)==1;result=results[0];validation=b.validate(result['values'],cases['seidel-2d']['expected']);assert result['report']==b.read(folder/'training-probe.json')['cases']['seidel-2d']['actors']['cell']['execution_report']
spec=importlib.util.spec_from_file_location('c',diag/'compare-code.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c);rows=c.compare(diag,'seidel-2d');sites=[s for r in rows for s in r['sampled_hot_sites']];assert len(sites)==30 and all(s['instruction_identical'] and s['surrounding_68_bytes_identical'] for s in sites)
b.write(diag/'jit-object-byte-verification.json',{'scope':'Actual rejected-training candidate JIT code, read-only debugger capture; no performance scores.','validation':validation,'counters_identical':True,'verified_hot_sites':len(sites),'functions':rows});assert b.compiler_fingerprint()==q['compiler_fingerprint'];print('Verified actual native instructions at all30 sampled sites',flush=True)
