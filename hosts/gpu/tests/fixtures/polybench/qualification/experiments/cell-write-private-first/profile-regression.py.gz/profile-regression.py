import collections,gzip,importlib.util,json,math,os,pathlib,subprocess,time
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent;outdir=folder/'regression-profile';outdir.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
q=b.read(folder/'qualification.json');probe=b.read(folder/'training-probe.json');_,cases=b.protocol();assert b.compiler_fingerprint()==q['compiler_fingerprint']
name='seidel-2d';driver=folder/'cell-driver';assert b.digest(driver)==q['driver_sha256']
prior=b.read(pathlib.Path('/private/tmp/mech-polybench-optimization/round-32/profile/training-profile.json'))
overheads=[max(0.000001,c['process_wall_seconds']/c['timed_checked_calls']-c['profile_median_seconds']) for c in prior['cases'].values()]
median=probe['cases'][name]['actors']['cell']['median_seconds'];overhead=__import__('statistics').median(overheads);count=math.ceil(16/(overhead+median));inputs=folder/f'{name}-inputs.json'
argv=[str(driver),str(b.FIXTURE/f'{name}.mec'),str(inputs),str(count)];env=os.environ.copy();env['PERF_BUILDID_DIR']='1'
with (outdir/'result.json').open('w') as out,(outdir/'stderr.log').open('w') as err:
 wall=time.monotonic();start=time.time_ns();child=subprocess.Popen(argv,stdout=out,stderr=err,env=env);perf=pathlib.Path(f'/tmp/perf-{child.pid}.map');prefix=perf.read_bytes() if perf.exists() and perf.stat().st_mtime_ns<start else b''
 time.sleep(1);assert child.poll() is None
 sample=outdir/f'{name}.sample.txt';sampling=subprocess.run(['/usr/bin/sample',str(child.pid),'6','1','-file',str(sample)],text=True,capture_output=True,check=True);(outdir/'sample.log').write_text(sampling.stdout+sampling.stderr);code=child.wait(timeout=180)
assert code==0 and perf.exists() and perf.stat().st_mtime_ns>=start
payload=perf.read_bytes();assert payload.startswith(prefix);mapping=outdir/f'{name}.perf.map';mapping.write_bytes(payload[len(prefix):]);assert 'mech_canonical_program_entry_v1' in mapping.read_text()
result=b.read(outdir/'result.json');assert result['status']=='ok';validation=b.validate(result['values'],cases[name]['expected']);assert result['report']==probe['cases'][name]['actors']['cell']['execution_report']
demangler=pathlib.Path('/private/tmp/mech-polybench-optimization/round-02/profile-tools/target/release/polybench-profile-demangle')
subprocess.run(['python3',str(root/'scripts/analyze-polybench-samples.py'),'--demangler',str(demangler),'--output',str(outdir/'analysis.json'),'--jit-map',f'{sample.name}={mapping}',str(sample)],check=True)
a=b.read(outdir/'analysis.json')[sample.name]
b.write(outdir/'profile.json',{'scope':'Optimization-only diagnosis after one prospectively rejected training probe. Full checked JIT path, same source/driver. No performance score or holdout observation.','compiler_fingerprint':q['compiler_fingerprint'],'driver_sha256':q['driver_sha256'],'case':name,'pid':child.pid,'command':argv,'call_count_estimate_non_kernel_seconds':overhead,'target_process_wall_seconds':16,'process_wall_seconds':time.monotonic()-wall,'timed_checked_calls':count,'warmup_validation':validation,'counters_match_qualified_probe':True,'sample_sha256':b.digest(sample),'map_sha256':b.digest(mapping),'analysis':a})
for path in [sample,mapping]:path.with_suffix(path.suffix+'.gz').write_bytes(gzip.compress(path.read_bytes(),mtime=0))
assert b.compiler_fingerprint()==q['compiler_fingerprint'];print('Regressing optimization capture validated',a['execution_samples'],'samples',flush=True)
