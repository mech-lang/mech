from pathlib import Path
p=Path('hosts/gpu/src/native_artifact/program/codegen/readonly_numeric.rs');s=p.read_text();begin=s.index('                    Operation::CellWrite { incoming, .. } => {');start=s.index('                        let old = super::numeric_words::load_unsigned_word(',begin);end=s.index('                        b.switch_to_block(materialize);',start)
old=s[start:end]
new='''                        let private_first = controls.enabled(
                            crate::native_artifact::codegen::options::OptimizationPass::PrivateWritesFirst,
                        );
                        let done = b.create_block();
                        let store = b.create_block();
                        let materialize = b.create_block();
                        b.set_cold_block(materialize);
                        boundaries.insert(materialize);
                        if private_first {
                            // Reuse the linear-write strategy after the same
                            // axis and incoming-kind guards. A genuinely private
                            // current bank has already changed; equal stores
                            // need neither an old-cell read nor materialization.
                            let private = words.read(b, shadow + proof.private_flag(*array));
                            let shared = b.create_block();
                            b.ins().brif(private, store, &[], shared, &[]);
                            b.switch_to_block(shared);
                        }
                        let old = super::numeric_words::load_unsigned_word(
                            b,
                            ty,
                            super::numeric_words::guarded_load_flags(controls.options()),
                            address,
                            0,
                        );
                        report.typed_loads.push((site, width));
                        let changed = b.ins().icmp(IntCC::NotEqual, old, incoming);
                        if private_first {
                            // Shared equal writes retain their no-copy route.
                            b.ins().brif(changed, materialize, &[], done, &[]);
                        } else {
                            let update = b.create_block();
                            b.ins().brif(changed, update, &[], done, &[]);
                            b.switch_to_block(update);
                            let private = words.read(b, shadow + proof.private_flag(*array));
                            b.ins().brif(private, store, &[], materialize, &[]);
                        }
'''
assert 'b.ins().brif(changed, update' in old;s=s[:start]+new+s[end:];p.write_text(s)
p=Path('hosts/gpu/src/native_artifact/program/image/identity.rs');s=p.read_text();old='pub const NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 390;';assert old in s;s=s.replace(old,'// IR393 reuses private-write-first admission for two-axis cell stores.\npub const NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 393;');p.write_text(s)
p=Path('hosts/gpu/src/native_artifact/program/runtime/composition_tests/numeric_cell_write_ownership.rs');s=p.read_text()
needle='''            let object = crate::native_artifact::emit_program_object(&artifact, &catalog).unwrap();'''
assert needle in s;s=s.replace(needle,'''            let prior = JitProgramArtifact::compile_for_test(
                &artifact, &catalog, OptimizationPass::PrivateWritesFirst,
            ).unwrap();
'''+needle)
s=s.replace('''                let mut cold = fast.clone();''','''                let mut cold = fast.clone();
                let mut checked = fast.clone();''')
needle='''                    let (b, _) = observe::run(&old, &args, &mut cold, mode.execution(), &memory);''';assert needle in s;s=s.replace(needle,needle+'''
                    let (previous, _) = if restored {
                        observe::run_restored(&prior, &args, &mut checked, mode.execution(), &memory)
                    } else {
                        observe::run(&prior, &args, &mut checked, mode.execution(), &memory)
                    };
                    assert_eq!(format!("{a:?}"), format!("{previous:?}"), "private-first ablation keeps every source counter/error");
                    assert_eq!(contents(&fast), contents(&checked));''')
s=s.replace('drop((fast, cold));','drop((fast, cold, checked));')
p.write_text(s)
