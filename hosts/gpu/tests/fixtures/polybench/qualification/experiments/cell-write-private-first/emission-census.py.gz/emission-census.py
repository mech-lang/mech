import importlib.util,json,pathlib,re,subprocess,hashlib
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
protocol,cases=b.protocol();q=b.read(folder/'qualification.json');assert b.compiler_fingerprint()==q['compiler_fingerprint'];assert b.digest(folder/'cell-driver')==q['driver_sha256']
objects=folder/'objects';objects.mkdir(exist_ok=False);old=pathlib.Path('/private/tmp/mech-polybench-optimization/round-31/inverse-bitcasts/objects')
def functions(asm):
 rows={};name=None
 for line in asm.splitlines():
  m=re.match(r'^[0-9a-f]+ <_(.+)>:',line)
  if m:name=m[1];rows[name]=[]
  elif name and re.match(r'^\s*[0-9a-f]+:',line):rows[name].append(line)
 return {name:{'instructions':len(lines),'disassembly_sha256':hashlib.sha256('\n'.join(lines).encode()).hexdigest()} for name,lines in rows.items()}
r={'scope':'Real checked Object export for optimization15 only; no timing observations or linked Object execution.','compiler_fingerprint':q['compiler_fingerprint'],'driver_sha256':q['driver_sha256'],'cases':{}}
for name in protocol['optimization']:
 inputs=folder/f'{name}-inputs.json';b.write(inputs,cases[name]['inputs']);obj=objects/f'{name}.o'
 process=subprocess.run([str(folder/'cell-driver'),str(b.FIXTURE/f'{name}.mec'),str(inputs),'0',f'emit-object={obj}'],text=True,capture_output=True,check=True,timeout=180)
 status=json.loads(process.stdout.strip().splitlines()[-1]);assert status['status']=='ok' and status['mode']=='emit-object'
 metadata=b.read(obj.with_suffix('.metadata.json'))
 asm=subprocess.run(['/Library/Developer/CommandLineTools/usr/bin/llvm-objdump','--disassemble','--no-show-raw-insn',str(obj)],text=True,capture_output=True,check=True).stdout
 disasm=obj.with_suffix('.disasm.txt');disasm.write_text(asm)
 row={'code_bytes':metadata['code_bytes'],'functions':functions(asm),'object_sha256':b.digest(obj),'metadata_sha256':b.digest(obj.with_suffix('.metadata.json')),'disassembly_sha256':b.digest(disasm),'object_executed':False}
 if (old/f'{name}.metadata.json').exists():
  before=b.read(old/f'{name}.metadata.json');row['accepted31_code_bytes']=before['code_bytes'];row['code_bytes_delta']=row['code_bytes']-before['code_bytes'];row['accepted31_functions']=functions((old/f'{name}.disasm.txt').read_text())
 r['cases'][name]=row;b.write(folder/'emission-census.json',r);print(name,'code_bytes',row['code_bytes'],'delta',row.get('code_bytes_delta'),flush=True)
changed={}
for case,site in [('seidel-2d',5),('nussinov',6)]:
 symbol=f'mech_canonical_program_entry_v1_numeric_{site}';row=r['cases'][case];before=row['accepted31_functions'][symbol];after=row['functions'][symbol]
 assert before['disassembly_sha256']!=after['disassembly_sha256']
 changed[case]={'symbol':symbol,'before':before,'after':after}
r['profiled_store_functions_changed']=changed;r['complete']=len(r['cases'])==15;assert b.compiler_fingerprint()==q['compiler_fingerprint'];b.write(folder/'emission-census.json',r);print('Both profiled cell-store functions changed',flush=True)
