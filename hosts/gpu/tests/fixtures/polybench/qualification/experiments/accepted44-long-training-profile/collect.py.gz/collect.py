import importlib.util, json, math, os, subprocess, time
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
plan=b.read(folder/'plan.json');protocol,cases=b.protocol();accepted=b.read(b.FIXTURE/'round-44-frozen.json');reference=b.read(b.FIXTURE/'round-44-training-probe.json');timings=b.read(b.FIXTURE/'round-44-optimization.json');old=b.read('/private/tmp/mech-polybench-optimization/round-45/accepted44-margin-profile/training-profile.json')
driver=Path(plan['driver']);workspace_fp=b.compiler_fingerprint()
assert workspace_fp==plan['workspace_compiler_fingerprint'] and b.command(['git','status','--porcelain'])==''
assert b.digest(driver)==accepted['driver_sha256']==plan['driver_sha256']
assert accepted['compiler_fingerprint']==plan['accepted_compiler_fingerprint']
assert len(b.read(b.FIXTURE/'performance-history.json')['entries'])==45
names=plan['cases'];assert set(names)<=set(protocol['optimization']) and len(names)==3
assert names==sorted(names,key=lambda n:-timings['runs'][n]['comparisons']['kernel']['median_mech_over_c'])
r={'schema':'mech.polybench.long-training-profile.v1','created_at':b.utc(),'scope':plan['scope'],'method':plan['method'],'source_commit':accepted['source_commit'],'workspace_commit':b.command(['git','rev-parse','HEAD']),'workspace_compiler_fingerprint':workspace_fp,'accepted_compiler_fingerprint':accepted['compiler_fingerprint'],'driver_sha256':b.digest(driver),'accepted_round':44,'cases':{},'complete':False,'performance_score_observations':0}
assert not (folder/'profile-collection.json').exists();b.write(folder/'profile-collection.json',r)
for name in names:
    previous=old['cases'][name];count=math.ceil(plan['target_residence_seconds']*previous['calls_for_residence_only']/previous['process_wall_seconds'])
    inputs=folder/f'{name}-inputs.json';b.write(inputs,cases[name]['inputs'])
    argv=[str(driver),str(b.FIXTURE/f'{name}.mec'),str(inputs),str(count)]
    env=os.environ.copy();env['PERF_BUILDID_DIR']=str(folder/'perf-binaries')
    started=time.time_ns();start=time.monotonic()
    with (folder/f'{name}-driver-output.json').open('x') as out,(folder/f'{name}-driver.stderr').open('x') as err:
        child=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err,env=env)
        mapping=Path(f'/tmp/perf-{child.pid}.map');prefix=mapping.read_bytes() if mapping.exists() and mapping.stat().st_mtime_ns<started else b''
        b.write(folder/'live-process.json',{'case':name,'pid':child.pid,'stage':'sampling','command':argv,'sample_seconds':plan['sample_seconds']})
        print(name,'live profile child',child.pid,'checked calls for residence',count,flush=True)
        time.sleep(1);assert child.poll() is None
        raw=folder/f'{name}.sample.txt';sample_argv=['/usr/bin/sample',str(child.pid),str(plan['sample_seconds']),'1','-file',str(raw)]
        sampled=subprocess.run(sample_argv,text=True,capture_output=True)
        (folder/f'{name}-sample.log').write_text(sampled.stdout+sampled.stderr)
        b.write(folder/'live-process.json',{'case':name,'pid':child.pid,'stage':'waiting_on_same_driver','sample_exit_code':sampled.returncode,'command':argv})
        print(name,'sampler complete, waiting on same driver',child.pid,flush=True)
        while True:
            try:code=child.wait(timeout=30);break
            except subprocess.TimeoutExpired:print('Waiting on same live driver',child.pid,flush=True)
    row={'command':argv,'sample_command':sample_argv,'pid':child.pid,'driver_exit_code':code,'sample_exit_code':sampled.returncode,'process_wall_seconds':time.monotonic()-start,'calls_for_residence_only':count,'sample_seconds':plan['sample_seconds'],'nominal_sample_interval_ms':1,'source_sha256':b.digest(b.FIXTURE/f'{name}.mec')}
    r['cases'][name]=row;b.write(folder/'profile-collection.json',r);b.write(folder/'live-process.json',{'case':name,'pid':child.pid,'stage':'terminal','exit_code':code,'sample_exit_code':sampled.returncode})
    assert sampled.returncode==0 and code==0
    assert mapping.exists() and mapping.stat().st_mtime_ns>=started
    payload=mapping.read_bytes();assert payload.startswith(prefix)
    jit_map=folder/f'{name}.perf.map';jit_map.write_bytes(payload[len(prefix):]);assert 'mech_canonical_program_entry_v1' in jit_map.read_text()
    result=json.loads((folder/f'{name}-driver-output.json').read_text().strip().splitlines()[-1]);assert result['status']=='ok'
    row['warmup_validation']=b.validate(result['values'],cases[name]['expected'])
    row['execution_report']=result['report'];assert result['report']==reference['cases'][name]['actors']['candidate']['execution_report']
    row.update(counters_match_accepted44=True,raw_sample_sha256=b.digest(raw),jit_map_sha256=b.digest(jit_map),diagnostic_checked_call_samples=len(result['samples_seconds']))
    assert len(result['samples_seconds'])==count
    b.write(folder/'profile-collection.json',r);print(name,'complete, finite C and accepted44 counters matched',flush=True)
analyzer=root/'scripts/analyze-polybench-samples.py';demangler=Path('/private/tmp/mech-polybench-optimization/round-02/profile-tools/target/release/polybench-profile-demangle')
argv=['python3',str(analyzer),'--demangler',str(demangler),'--output',str(folder/'analysis.json'),*[arg for n in names for arg in ['--jit-map',f'{n}.sample.txt={folder/f"{n}.perf.map"}']],*[str(folder/f'{n}.sample.txt') for n in names]]
with (folder/'analyzer.log').open('x') as log:completed=subprocess.run(argv,cwd=root,stdout=log,stderr=subprocess.STDOUT)
assert completed.returncode==0
analysis=b.read(folder/'analysis.json');r['analysis']={n:analysis[n+'.sample.txt'] for n in names};r.update(analyzer_sha256=b.digest(analyzer),demangler_sha256=b.digest(demangler),complete=True)
assert workspace_fp==b.compiler_fingerprint() and b.digest(driver)==r['driver_sha256']
assert len(b.read(b.FIXTURE/'performance-history.json')['entries'])==45
b.write(folder/'training-profile.json',r)
for name,analysis in r['analysis'].items():print(json.dumps({'case':name,'execution_samples':analysis['execution_samples'],'self_time_mechanisms':analysis['self_time_mechanisms'],'top_self_functions':analysis['top_self_functions'][:5]}),flush=True)
