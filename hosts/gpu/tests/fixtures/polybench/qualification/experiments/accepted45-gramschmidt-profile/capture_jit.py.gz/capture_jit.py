"""Read only the selected generated function from our own benchmark child."""
import hashlib,json
from pathlib import Path
import lldb
def capture(debugger):
 folder=Path(__file__).resolve().parent;request=json.loads((folder/'jit-capture-request.json').read_text());result=dict(request);process=None
 debugger.SetAsync(False)
 try:
  target=debugger.CreateTarget('');error=lldb.SBError();process=target.AttachToProcessWithID(debugger.GetListener(),request['pid'],error);result['attach_error']=str(error)
  if error.Fail() or not process.IsValid():return
  read_error=lldb.SBError();data=process.ReadMemory(request['address'],request['size'],read_error);result['read_error']=str(read_error)
  if read_error.Success():
   if isinstance(data,str):data=data.encode('latin1')
   assert len(data)==request['size'];(folder/'numeric_5.jit.bin').write_bytes(data);result.update(captured=True,bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
   command=lldb.SBCommandReturnObject();start=request['address'];end=start+request['size'];debugger.GetCommandInterpreter().HandleCommand(f'disassemble --start-address {start} --end-address {end} --bytes',command);(folder/'numeric_5.jit.disasm.txt').write_text((command.GetOutput() or '')+(command.GetError() or ''));result['disassembly_succeeded']=command.Succeeded()
 except Exception as error:result['error']=repr(error)
 finally:
  if process is not None and process.IsValid() and process.GetState() not in [lldb.eStateExited,lldb.eStateDetached,lldb.eStateInvalid]:result['detach_error']=str(process.Detach())
  (folder/'jit-capture-result.json').write_text(json.dumps(result,indent=2)+'\n')
