import importlib.util,json,re
from pathlib import Path
root=Path.cwd();folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
capture=b.read(folder/'jit-capture-result.json');assert capture['captured'] and capture['detach_error']=='success'
raw=(folder/'numeric_5.jit.bin').read_bytes();assert len(raw)==capture['size'] and b.digest(folder/'numeric_5.jit.bin')==capture['sha256']
instructions={}
for line in (folder/'numeric_5.jit.disasm.txt').read_text().splitlines():
 m=re.match(r'\s*(0x[0-9a-f]+):\s+0x([0-9a-f]{8})\s+(.*)',line)
 if not m:continue
 address=int(m[1],16);offset=address-capture['address'];assert 0<=offset<len(raw) and offset%4==0
 assert int(m[2],16).to_bytes(4,'little')==raw[offset:offset+4]
 instructions[offset]={'offset':offset,'instruction':m[3].strip(),'word_hex':m[2]}
assert len(instructions)*4==len(raw) and set(instructions)==set(range(0,len(raw),4))
b.write(folder/'jit-instruction-map.json',{'pid':capture['pid'],'symbol':capture['symbol'],'address':capture['address'],'bytes':len(raw),'sha256':capture['sha256'],'all_decoded_words_match_same_process_bytes':True,'instructions':list(instructions.values())})
profile=folder/'training-profile.json'
if not profile.exists():print(json.dumps({'jit_bytes_verified':len(raw),'decoded_instructions':len(instructions),'profile_not_complete_yet':True}));raise SystemExit(0)
r=b.read(profile);assert r['complete'] and r['cases']['gramschmidt']['pid']==capture['pid']
a=r['analysis']['gramschmidt'];sites=[]
for site in a['top_jit_sites']:
 if site['symbol']!=capture['symbol']:continue
 offset=site['offset'];assert offset in instructions
 sites.append({**site,'actual_jit_instruction':instructions[offset]['instruction'],'instruction_window':[instructions[x] for x in range(max(0,offset-8),min(len(raw),offset+12),4)]})
result={'schema':'mech.polybench.same-process-jit-sites.v1','scope':'Optimization Gram-Schmidt only; actual sampled process/function bytes, no Object-byte identity assumption.','pid':capture['pid'],'driver_sha256':r['driver_sha256'],'compiler_fingerprint':r['accepted_compiler_fingerprint'],'symbol':capture['symbol'],'jit_bytes_sha256':capture['sha256'],'jit_bytes':len(raw),'decoded_instructions':len(instructions),'all_decoded_words_match_same_process_bytes':True,'execution_samples':a['execution_samples'],'jit_self_samples':a['jit_self_samples'],'jit_functions':a['jit_functions'],'sites':sites,'limitation':'Sampled positions and local instruction windows identify mechanisms; they do not establish exact cost per instruction or a speedup. Diagnostic timings never enter scores.'}
b.write(folder/'instruction-sites.json',result);print(json.dumps({'execution_samples':a['execution_samples'],'jit_self_samples':a['jit_self_samples'],'sites':[{k:v for k,v in s.items() if k!='instruction_window'} for s in sites[:12]]},indent=2))
