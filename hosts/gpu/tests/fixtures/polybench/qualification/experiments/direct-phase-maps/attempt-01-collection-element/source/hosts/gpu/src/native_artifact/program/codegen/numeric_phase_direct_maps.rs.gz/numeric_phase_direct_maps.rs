//! Compiler-local totality and current-view guards for direct whole maps.
//! No metadata flag grants ownership. The caller supplies an already admitted
//! exclusive destination; the original map recipe and emitter remain current.
use super::*;
use mech_engine::native_artifact::{
    NativeIterationAction as Action, NativeIterationTerminator as Terminator,
    NativeMatchAction as Scalar, NativeMatchTerminator as Term, NativeScalarOp as Op,
};
use std::collections::BTreeSet;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum Axis {
    Outer,
    Inner,
    Capture(u32),
    Constant(u64),
}
struct Read {
    matrix: usize,
    indices: Vec<Axis>,
    same_cell: bool,
}

// These semantic operations have no arithmetic-failure edge for admitted
// typed words. Checked integer arithmetic and narrowing conversions stay on
// the original scratch path. Emission still uses the shared scalar emitter.
fn total(op: Op) -> bool {
    use Op::*;
    matches!(
        op,
        U64BitAnd
            | U64BitOr
            | U64BitXor
            | U64BitNot
            | U64ShlWrap
            | U64ShrWrap
            | U64Clz
            | U64Ctz
            | U64WrappingAdd
            | U64WrappingSub
            | U64WrappingMul
            | U64Eq
            | U64Ne
            | U64Lt
            | U64Le
            | U64Gt
            | U64Ge
            | U8Eq
            | U8Ne
            | U8Lt
            | U8Le
            | U8Gt
            | U8Ge
            | U16Eq
            | U16Ne
            | U16Lt
            | U16Le
            | U16Gt
            | U16Ge
            | U32Eq
            | U32Ne
            | U32Lt
            | U32Le
            | U32Gt
            | U32Ge
            | I64Eq
            | I64Ne
            | I64Lt
            | I64Le
            | I64Gt
            | I64Ge
            | BoolAnd
            | BoolOr
            | BoolXor
            | BoolNot
            | BoolEq
            | BoolNe
            | F64Add
            | F64Sub
            | F64Mul
            | F64Div
            | F64Neg
            | F64Sqrt
            | F64Eq
            | F64Ne
            | F64Lt
            | F64Le
            | F64Gt
            | F64Ge
            | U64ToF64
            | I64ToF64
            | U8ToU16
            | U8ToU32
            | U8ToU64
            | U16ToU32
            | U16ToU64
            | U32ToU64
    )
}
fn root(plan: &Plan, mut value: u32) -> Option<u32> {
    let facts = plan.facts();
    let mut seen = BTreeSet::new();
    while seen.len() < 64 && seen.insert(value) {
        let definitions = facts.definition_sites(value).ok()?;
        let [definition] = definitions else {
            return Some(value);
        };
        let Some(site) = definition.site() else {
            return Some(value);
        };
        match plan.blocks().get(site as usize)?.action() {
            Action::Scalar(Scalar::Copy { source, output }) if output.get() == value => {
                value = source.get()
            }
            _ => return Some(value),
        }
    }
    None
}
fn axis(plan: &Plan, source: &MatrixMap, value: u32) -> Option<Axis> {
    let value = root(plan, value)?;
    if value == source.region.element {
        return Some(Axis::Outer);
    }
    if source
        .region
        .rectangle
        .as_ref()
        .is_some_and(|r| r.inner_element == value)
    {
        return Some(Axis::Inner);
    }
    if source.region.captures.contains(&value) {
        return Some(Axis::Capture(value));
    }
    let entry = plan
        .constants()
        .iter()
        .find(|constant| constant.value().get() == value)?;
    match entry.constant().data() {
        mech_core::ValueData::U64(n) => Some(Axis::Constant(*n)),
        _ => None,
    }
}
fn derive(plan: &Plan, source: &MatrixMap) -> Option<Vec<Read>> {
    let region = &source.region;
    if !region.range
        || region.reduction.is_some()
        || !region.nested.is_empty()
        || source.count == 0
        || source.elements == 0
    {
        return None;
    }
    for &site in &region.body {
        let block = plan.blocks().get(site as usize)?;
        if !region.reads.iter().any(|read| read.site == site) {
            match block.action() {
                Action::Scalar(Scalar::None | Scalar::Copy { .. })
                | Action::CollectionPush { .. } => {}
                Action::Scalar(Scalar::Primitive { op, .. }) if total(*op) => {}
                _ => return None,
            }
        }
        if !matches!(
            block.terminator(),
            Terminator::Scalar(Term::Jump(_) | Term::Branch { .. } | Term::LiteralBranch { .. })
        ) {
            return None;
        }
    }
    region
        .reads
        .iter()
        .map(|read| {
            let indices = read
                .indices
                .iter()
                .map(|&value| axis(plan, source, value))
                .collect::<Option<Vec<_>>>()?;
            let same_cell = match (region.rectangle.as_ref(), &indices[..]) {
                (Some(rectangle), [Axis::Inner, Axis::Outer]) => {
                    rectangle.start == 1 && source.extents == [rectangle.rows, source.count]
                }
                (None, [Axis::Outer]) => {
                    source.elements == source.count
                        && (source.extents[0] == 1 || source.extents[1] == 1)
                }
                (None, [Axis::Outer, Axis::Constant(1)]) => source.extents == [source.count, 1],
                (None, [Axis::Constant(1), Axis::Outer]) => source.extents == [1, source.count],
                _ => false,
            };
            Some(Read {
                matrix: read.matrix,
                indices,
                same_cell,
            })
        })
        .collect()
}
fn both(b: &mut FunctionBuilder<'_>, good: Value, next: Value) -> Value {
    b.ins().band(good, next)
}
fn bound(b: &mut FunctionBuilder<'_>, good: Value, lo: Value, hi: Value, extent: Value) -> Value {
    let nonzero = b.ins().icmp_imm(IntCC::NotEqual, lo, 0);
    let bounded = b.ins().icmp(IntCC::UnsignedLessThanOrEqual, hi, extent);
    let valid = both(b, nonzero, bounded);
    both(b, good, valid)
}
fn limits(
    b: &mut FunctionBuilder<'_>,
    axis: Axis,
    outer: (Value, Value),
    inner: Option<(u64, u64)>,
    captures: &BTreeMap<u32, Value>,
) -> Option<(Value, Value)> {
    match axis {
        Axis::Outer => Some(outer),
        Axis::Inner => {
            let (lo, hi) = inner?;
            Some((
                b.ins().iconst(types::I64, lo as i64),
                b.ins().iconst(types::I64, hi as i64),
            ))
        }
        Axis::Capture(value) => {
            let value = *captures.get(&value)?;
            Some((value, value))
        }
        Axis::Constant(value) => {
            let value = b.ins().iconst(types::I64, value as i64);
            Some((value, value))
        }
    }
}
pub(super) fn guard(
    b: &mut FunctionBuilder<'_>,
    source: &MatrixMap,
    plan: &Plan,
    base: Value,
    first: Value,
    matrices: &[[Value; 4]],
    captures: &BTreeMap<u32, Value>,
) -> Option<Value> {
    let reads = derive(plan, source)?;
    if matrices.len() != source.region.matrices.len() {
        return None;
    }
    let inner = if let Some(rectangle) = &source.region.rectangle {
        Some((
            rectangle.start,
            rectangle
                .start
                .checked_add(rectangle.rows.checked_sub(1)?)?,
        ))
    } else {
        None
    };
    let span = b.ins().iconst(types::I64, (source.count - 1) as i64);
    let (last, overflow) = b.ins().uadd_overflow(first, span);
    let mut allowed = b.ins().icmp_imm(IntCC::Equal, overflow, 0);
    let out_bytes = source
        .elements
        .checked_mul(u64::from(source.region.output_width))?;
    let out_bytes = b.ins().iconst(types::I64, out_bytes as i64);
    let (out_end, overflow) = b.ins().uadd_overflow(base, out_bytes);
    let valid = b.ins().icmp_imm(IntCC::Equal, overflow, 0);
    allowed = both(b, allowed, valid);
    for read in reads {
        let [pointer, cells, rows, columns] = matrices[read.matrix];
        let axes = read
            .indices
            .iter()
            .map(|&axis| limits(b, axis, (first, last), inner, captures))
            .collect::<Option<Vec<_>>>()?;
        match &axes[..] {
            [(lo, hi)] => allowed = bound(b, allowed, *lo, *hi, cells),
            [(rlo, rhi), (clo, chi)] => {
                allowed = bound(b, allowed, *rlo, *rhi, rows);
                allowed = bound(b, allowed, *clo, *chi, columns);
            }
            _ => return None,
        }
        let width = source.region.matrices[read.matrix].width;
        let width_value = b.ins().iconst(types::I64, i64::from(width));
        let (bytes, overflow) = b.ins().umul_overflow(cells, width_value);
        let valid = b.ins().icmp_imm(IntCC::Equal, overflow, 0);
        allowed = both(b, allowed, valid);
        let (end, overflow) = b.ins().uadd_overflow(pointer, bytes);
        let valid = b.ins().icmp_imm(IntCC::Equal, overflow, 0);
        allowed = both(b, allowed, valid);
        let before = b.ins().icmp(IntCC::UnsignedLessThanOrEqual, end, base);
        let after = b
            .ins()
            .icmp(IntCC::UnsignedLessThanOrEqual, out_end, pointer);
        let mut aliases = b.ins().bor(before, after);
        if read.same_cell && width == source.region.output_width {
            let same = b.ins().icmp(IntCC::Equal, pointer, base);
            let row = b
                .ins()
                .icmp_imm(IntCC::Equal, rows, source.extents[0] as i64);
            let column = b
                .ins()
                .icmp_imm(IntCC::Equal, columns, source.extents[1] as i64);
            let start = b.ins().icmp_imm(IntCC::Equal, first, 1);
            let geometry = both(b, row, column);
            let geometry = both(b, geometry, start);
            let same = both(b, same, geometry);
            aliases = b.ins().bor(aliases, same);
        }
        allowed = both(b, allowed, aliases);
    }
    Some(allowed)
}
