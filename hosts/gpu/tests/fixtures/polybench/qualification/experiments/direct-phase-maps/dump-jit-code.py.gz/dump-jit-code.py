import hashlib,json,pathlib,time,lldb
process=lldb.debugger.GetSelectedTarget().GetProcess()
assert process.GetState()==lldb.eStateStopped
pid=process.GetProcessID();path=pathlib.Path(f"/tmp/perf-{pid}.map")
assert path.exists() and path.stat().st_mtime_ns>=launch_start_ns
rows=[]
for line in path.read_text().splitlines():
    start,size,name=line.split(maxsplit=2)
    if not name.startswith("mech_canonical_program_entry_v1"):continue
    address=int(start,16);size=int(size,16)
    assert 0<size<=64*1024*1024
    info=lldb.SBMemoryRegionInfo();error=process.GetMemoryRegionInfo(address,info)
    assert error.Success() and info.IsReadable() and info.IsExecutable()
    assert info.GetRegionBase()<=address and address+size<=info.GetRegionEnd()
    error=lldb.SBError();data=process.ReadMemory(address,size,error)
    assert error.Success() and len(data)==size
    out=pathlib.Path(dump_folder)/(name+".bin");out.write_bytes(data)
    rows.append({"symbol":name,"address":address,"size":size,"sha256":hashlib.sha256(data).hexdigest(),"file":str(out),"executable_region":True})
assert rows and len({row["symbol"] for row in rows})==len(rows)
(pathlib.Path(dump_folder)/"jit-code.json").write_text(json.dumps({"pid":pid,"functions":rows,"read_only_code_capture":True},indent=2)+"\n")
print("Captured",len(rows),"JIT executable code ranges from benchmark PID",pid)
