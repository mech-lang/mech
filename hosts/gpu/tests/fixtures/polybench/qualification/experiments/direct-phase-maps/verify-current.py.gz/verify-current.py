import importlib.util,json,pathlib,subprocess
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
q=b.read(folder/'qualification.json');p=b.read(folder/'direct-profile/profile.json');assert b.compiler_fingerprint()==q['compiler_fingerprint']==p['compiler_fingerprint'];assert b.digest(folder/'direct-driver')==q['driver_sha256']==p['driver_sha256']
assert p['complete'] and p['execution_counters_match_accepted31']
live=folder/'live-code/gramschmidt';live.mkdir(parents=True,exist_ok=False)
b.write(folder/'training-profile.json',{'scope':'Optimization-only final-source checked candidate profile; no profiler times enter benchmark scores.','compiler_fingerprint':q['compiler_fingerprint'],'driver_sha256':q['driver_sha256'],'analysis':{'gramschmidt':p['analysis']},'cases':{'gramschmidt':{'warmup_validation':p['warmup_validation'],'execution_counters_match_accepted31':True}}})
argv=['xcrun','lldb','-x','-b','--source',str(folder/'gramschmidt-dump.lldb'),'--',str(folder/'direct-driver'),str(b.FIXTURE/'gramschmidt.mec'),str(folder/'gramschmidt-inputs.json'),'0'];b.write(folder/'debugger-command.json',{'command':argv,'compiler_fingerprint':q['compiler_fingerprint'],'driver_sha256':q['driver_sha256'],'read_only_code_capture':True})
with (folder/'gramschmidt-lldb.log').open('w') as log:process=subprocess.run(argv,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
text=(folder/'gramschmidt-lldb.log').read_text();results=[json.loads(line) for line in text.splitlines() if line.startswith('{') and '"values"' in line];assert len(results)==1
protocol,cases=b.protocol();validation=b.validate(results[0]['values'],cases['gramschmidt']['expected']);assert results[0]['report']==b.read(b.FIXTURE/'round-31-training-probe.json')['cases']['gramschmidt']['actors']['bitcast']['execution_report']
spec=importlib.util.spec_from_file_location('compare',folder/'compare-code.py');compare=importlib.util.module_from_spec(spec);spec.loader.exec_module(compare)
rows=compare.compare(folder,'gramschmidt');sites=[site for row in rows for site in row['sampled_hot_sites']];assert len(sites)>0 and all(site['instruction_identical'] and site['surrounding_68_bytes_identical'] for site in sites)
numeric=next(row for row in rows if row['symbol']=='mech_canonical_program_entry_v1_numeric_5');assert numeric['byte_identical']
r={'scope':'Actual final qualified checked JIT pages versus genuine Objects; no timing scores.','compiler_fingerprint':q['compiler_fingerprint'],'driver_sha256':q['driver_sha256'],'verified_hot_sites':len(sites),'full_c_warmup_validation':validation,'execution_counters_identical':True,'profiled_numeric_function_fully_byte_identical':True,'functions':rows}
b.write(folder/'jit-object-byte-verification.json',r)
assert b.compiler_fingerprint()==q['compiler_fingerprint'];print(json.dumps({'verified_hot_sites':len(sites),'all_windows_match':True,'numeric_function_all_bytes_match':True,'counters_match':True}),flush=True)
