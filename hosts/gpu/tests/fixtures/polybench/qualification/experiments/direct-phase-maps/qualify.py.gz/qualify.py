import importlib.util,json,os,pathlib,shutil,subprocess
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
fp=b.compiler_fingerprint();parent=b.command(['git','rev-parse','HEAD']);assert parent=='1e4403b4dd43f4ff4ce3d165c1ad553a4548033a'
b.write(folder/'source-checkpoint.json',{'created_at':b.utc(),'source_commit':parent,'compiler_fingerprint':fp,'versions':{'ir':396,'work':156,'abi':47},'source_uncommitted':True})
subprocess.run(['python3','-u',str(folder/'run-qualification.py')],cwd=root,check=True)
checks=b.read(folder/'qualification-checks.json')['checks'];assert len(checks)==7 and all(c['exit_code']==0 for c in checks)
assert sum(sum(c['passed_tests']) for c in checks)==585
base=['cargo','build','--release','-p','mech-gpu','--no-default-features','--features','canonical-native-program','--example','polybench_qualification']
env=os.environ.copy();env['CARGO_TARGET_DIR']='/private/tmp/mech-polybench-pr1000-target'
with (folder/'driver-build.log').open('w') as out:subprocess.run(base,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
shutil.copy2(pathlib.Path(env['CARGO_TARGET_DIR'])/'release/examples/polybench_qualification',folder/'direct-driver')
assert b.compiler_fingerprint()==fp
q={'created_at':b.utc(),'compiler_fingerprint':fp,'source_parent':parent,'versions':{'ir':396,'work':156,'abi':47},'driver_sha256':b.digest(folder/'direct-driver'),'tests':585,'checks':checks,'source_fingerprint_unchanged_through_checks':True,'scope':'Reuse guarded direct whole-map destinations; full current-source correctness/features before optimization-only replay and formal acceptance.'}
b.write(folder/'qualification.json',q);print('Qualified585 checks. Driver',q['driver_sha256'],'fingerprint',fp,flush=True)
