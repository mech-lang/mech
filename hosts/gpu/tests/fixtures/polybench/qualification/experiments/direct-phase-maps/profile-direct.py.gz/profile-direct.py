import importlib.util,json,math,os,pathlib,re,statistics,subprocess,time
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
q=b.read(folder/'qualification.json');assert b.compiler_fingerprint()==q['compiler_fingerprint'];driver=folder/'direct-driver';assert b.digest(driver)==q['driver_sha256']
profile=folder/'direct-profile';profile.mkdir(exist_ok=False);protocol,cases=b.protocol();name='gramschmidt';assert name in protocol['optimization']
old=b.read('/private/tmp/mech-polybench-optimization/round-32/profile/training-profile.json')['cases'][name]
count=math.ceil(16/(old['process_wall_seconds']/old['timed_checked_calls']))
inputs=profile/'gramschmidt-inputs.json';b.write(inputs,cases[name]['inputs']);argv=[str(driver),str(b.FIXTURE/f'{name}.mec'),str(inputs),str(count)]
env=os.environ.copy();env['PERF_BUILDID_DIR']=str(profile/'perf-binaries');start=time.monotonic();started=time.time_ns()
with (profile/'driver-output.json').open('w') as out,(profile/'driver.stderr').open('w') as err:
 child=subprocess.Popen(argv,stdout=out,stderr=err,env=env)
 mapping=pathlib.Path(f'/tmp/perf-{child.pid}.map');prefix=mapping.read_bytes() if mapping.exists() and mapping.stat().st_mtime_ns<started else b''
 b.write(profile/'live-process.json',{'pid':child.pid,'command':argv,'source_fingerprint':q['compiler_fingerprint'],'stage':'driver running before sampler'})
 print('Profile child',child.pid,'calls',count,flush=True);time.sleep(1);assert child.poll() is None
 raw=profile/'gramschmidt.sample.txt';sample=subprocess.run(['/usr/bin/sample',str(child.pid),'6','1','-file',str(raw)],text=True,capture_output=True,check=True);(profile/'sample.log').write_text(sample.stdout+sample.stderr)
 while True:
  try:code=child.wait(timeout=30);break
  except subprocess.TimeoutExpired:print('Same profile child remains live',child.pid,flush=True)
 assert code==0
assert mapping.exists() and mapping.stat().st_mtime_ns>=started;payload=mapping.read_bytes();assert payload.startswith(prefix);jit_map=profile/'gramschmidt.perf.map';jit_map.write_bytes(payload[len(prefix):])
result=json.loads((profile/'driver-output.json').read_text().strip().splitlines()[-1]);assert result['status']=='ok';validation=b.validate(result['values'],cases[name]['expected'])
reference=b.read(b.FIXTURE/'round-31-training-probe.json')['cases'][name]['actors']['bitcast']['execution_report'];assert result['report']==reference
analyzer=root/'scripts/analyze-polybench-samples.py';demangler=pathlib.Path('/private/tmp/mech-polybench-optimization/round-02/profile-tools/target/release/polybench-profile-demangle')
subprocess.run(['python3',str(analyzer),'--demangler',str(demangler),'--jit-map',f'{raw.name}={jit_map}','--output',str(profile/'analysis.json'),str(raw)],check=True)
analysis=b.read(profile/'analysis.json')[raw.name]
assert analysis['execution_samples']>0 and analysis['jit_self_samples']>0
# Identify bounded scalar copy loops in the exact checked Object. These are
# diagnostic instruction ranges, not an execution counter or benchmark score.
symbol='mech_canonical_program_entry_v1_numeric_5';lines=(folder/'objects/gramschmidt.disasm.txt').read_text().splitlines();active=False;instructions={}
for line in lines:
 label=re.match(r'^[0-9a-f]+ <_(.+)>:',line)
 if label:active=label[1]==symbol
 elif active:
  inst=re.match(r'^\s*([0-9a-f]+):\s+(\S+)\s*(.*)',line)
  if inst:instructions[int(inst[1],16)]=(inst[2],inst[3],line)
loops=[]
for address,(op,args,line) in instructions.items():
 target=re.match(r'0x([0-9a-f]+)',args)
 if op!='b.lo' or target is None:continue
 target=int(target[1],16)
 if target>=address:continue
 body=[(pc,*instructions[pc]) for pc in sorted(instructions) if target<=pc<=address]
 ops=[row[1] for row in body]
 if len(body)<=12 and 'ldr' in ops and 'str' in ops and set(ops)<=set(['ldr','str','add','sub','mov','movk','cmp','b.lo']):
  sites=[row for row in analysis['top_jit_sites'] if row['symbol']==symbol and target<=row['offset']<=address]
  loops.append({'start':target,'end':address+4,'instructions':[row[3] for row in body],'top_site_samples':sum(row['samples'] for row in sites),'top_sampled_sites':sites})
r={'schema':'mech.polybench.training-profile.v1','scope':'Optimization-only checked candidate Gram-Schmidt profile. No C/holdout timing or score; sample process timing is diagnostic only. Raw profile and same-process built-in JIT perf map retained. Object loop offsets need actual JIT byte verification before claiming instruction attribution.','source_parent':b.command(['git','rev-parse','HEAD']),'compiler_fingerprint':q['compiler_fingerprint'],'driver_sha256':q['driver_sha256'],'pid':child.pid,'driver_exit_code':code,'timed_calls_for_residence_only':count,'process_wall_seconds':time.monotonic()-start,'warmup_validation':validation,'execution_report':result['report'],'execution_counters_match_accepted31':True,'analysis':analysis,'scalar_copy_loop_candidates':loops,'raw_sample_sha256':b.digest(raw),'jit_map_sha256':b.digest(jit_map),'object_sha256':b.digest(folder/'objects/gramschmidt.o'),'analyzer_sha256':b.digest(analyzer),'demangler_sha256':b.digest(demangler),'diagnostic_environment':{'PERF_BUILDID_DIR':'compilation-time function logging only'},'complete':True}
b.write(profile/'profile.json',r);b.write(profile/'live-process.json',{'pid':child.pid,'stage':'terminal','exit_code':code});assert b.compiler_fingerprint()==q['compiler_fingerprint']
print(json.dumps({'canonical_samples':analysis['execution_samples'],'jit_self_samples':analysis['jit_self_samples'],'copy_loop_candidates':len(loops),'copy_loop_top_site_samples':[row['top_site_samples'] for row in loops],'counters_match':True}),flush=True)
