import importlib.util,json,math,os,pathlib,subprocess,time
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
plan=b.read(folder/'plan.json');protocol,cases=b.protocol();accepted=b.read(b.FIXTURE/'round-44-frozen.json');timings=b.read(b.FIXTURE/'round-44-optimization.json');reference=b.read(b.FIXTURE/'round-44-training-probe.json');driver=pathlib.Path(plan['driver'])
assert b.compiler_fingerprint()==accepted['compiler_fingerprint']==plan['compiler_fingerprint']
assert b.digest(driver)==accepted['driver_sha256']==plan['driver_sha256']
assert len(b.read(b.FIXTURE/'performance-history.json')['entries'])==45
assert b.command(['git','status','--porcelain'])==''
old=b.read('/private/tmp/mech-polybench-optimization/round-32/profile/training-profile.json')['cases']['gramschmidt'];count=math.ceil(24/(old['process_wall_seconds']/old['timed_checked_calls']))
ranking=sorted(protocol['optimization'],key=lambda n:-timings['runs'][n]['comparisons']['kernel']['median_mech_over_c'])
assert len(ranking)==15 and not (folder/'profile-collection.json').exists()
r={'schema':'mech.polybench.accepted-margin-profile.v1','created_at':b.utc(),'scope':plan['scope'],'accepted_round':44,'source_commit':accepted['source_commit'],'workspace_commit':b.command(['git','rev-parse','HEAD']),'compiler_fingerprint':accepted['compiler_fingerprint'],'driver_sha256':accepted['driver_sha256'],'method':plan['method'],'ranking':[{'name':n,'mech_over_c':timings['runs'][n]['comparisons']['kernel']['median_mech_over_c'],'mech_median_seconds':timings['runs'][n]['comparisons']['kernel']['mech']['median_seconds']} for n in ranking],'calls_per_process_for_residence_only':count,'cases':{},'complete':False}
b.write(folder/'profile-collection.json',r)
for name in ranking:
 inputs=folder/f'{name}-inputs.json';b.write(inputs,cases[name]['inputs']);argv=[str(driver),str(b.FIXTURE/f'{name}.mec'),str(inputs),str(count)];env=os.environ.copy();env['PERF_BUILDID_DIR']=str(folder/'perf-binaries');start=time.monotonic();started=time.time_ns()
 with (folder/f'{name}-driver-output.json').open('x') as out,(folder/f'{name}-driver.stderr').open('x') as err:
  child=subprocess.Popen(argv,stdout=out,stderr=err,env=env);mapping=pathlib.Path(f'/tmp/perf-{child.pid}.map');prefix=mapping.read_bytes() if mapping.exists() and mapping.stat().st_mtime_ns<started else b''
  b.write(folder/'live-process.json',{'case':name,'pid':child.pid,'stage':'live','command':argv});print(name,'profile child',child.pid,'calls',count,flush=True)
  time.sleep(1);assert child.poll() is None
  raw=folder/f'{name}.sample.txt';sample=subprocess.run(['/usr/bin/sample',str(child.pid),'12','1','-file',str(raw)],text=True,capture_output=True);(folder/f'{name}-sample.log').write_text(sample.stdout+sample.stderr)
  while True:
   try:code=child.wait(timeout=30);break
   except subprocess.TimeoutExpired:print('Waiting on same live profile child',child.pid,flush=True)
 assert sample.returncode==0 and code==0
 assert mapping.exists() and mapping.stat().st_mtime_ns>=started;payload=mapping.read_bytes();assert payload.startswith(prefix);jit_map=folder/f'{name}.perf.map';jit_map.write_bytes(payload[len(prefix):]);assert 'mech_canonical_program_entry_v1' in jit_map.read_text()
 result=json.loads((folder/f'{name}-driver-output.json').read_text().strip().splitlines()[-1]);assert result['status']=='ok';validation=b.validate(result['values'],cases[name]['expected']);assert result['report']==reference['cases'][name]['actors']['candidate']['execution_report']
 r['cases'][name]={'command':argv,'pid':child.pid,'driver_exit_code':code,'source_sha256':b.digest(b.FIXTURE/f'{name}.mec'),'warmup_validation':validation,'execution_report':result['report'],'counters_match_accepted44':True,'calls_for_residence_only':count,'process_wall_seconds':time.monotonic()-start,'sample_seconds':12,'nominal_sample_interval_ms':1,'raw_sample_sha256':b.digest(raw),'jit_map_sha256':b.digest(jit_map)}
 b.write(folder/'profile-collection.json',r);b.write(folder/'live-process.json',{'case':name,'pid':child.pid,'stage':'terminal','exit_code':code});print(name,'complete and C-validated',flush=True)
analyzer=root/'scripts/analyze-polybench-samples.py';demangler=pathlib.Path('/private/tmp/mech-polybench-optimization/round-02/profile-tools/target/release/polybench-profile-demangle')
subprocess.run(['python3',str(analyzer),'--demangler',str(demangler),'--output',str(folder/'analysis.json'),*[a for n in ranking for a in ['--jit-map',f'{n}.sample.txt={folder/f"{n}.perf.map"}']],*[str(folder/f'{n}.sample.txt') for n in ranking]],check=True)
analysis=b.read(folder/'analysis.json');r['analysis']={n:analysis[n+'.sample.txt'] for n in ranking};r['analyzer_sha256']=b.digest(analyzer);r['demangler_sha256']=b.digest(demangler);r['complete']=len(r['analysis'])==15
assert b.compiler_fingerprint()==r['compiler_fingerprint'] and b.digest(driver)==r['driver_sha256'];assert len(b.read(b.FIXTURE/'performance-history.json')['entries'])==45
b.write(folder/'training-profile.json',r)
for name,a in r['analysis'].items():print(json.dumps({'case':name,'execution_samples':a['execution_samples'],'self_time_mechanisms':a['self_time_mechanisms'],'top_self_functions':a['top_self_functions'][:5]}),flush=True)
