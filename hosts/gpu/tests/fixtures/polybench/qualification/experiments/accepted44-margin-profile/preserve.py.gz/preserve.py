import gzip, hashlib, importlib.util, json
from pathlib import Path
root = Path.cwd()
folder = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('polybench', root / 'scripts/benchmark-polybench.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
r = b.read(folder / 'training-profile.json')
assert r['complete'] and len(r['cases']) == len(r['analysis']) == 15
assert all(c['driver_exit_code'] == 0 and c['counters_match_accepted44'] and c['warmup_validation']['finite'] for c in r['cases'].values())
assert b.compiler_fingerprint() == r['compiler_fingerprint']
assert b.digest(Path('/private/tmp/mech-polybench-optimization/round-44/prepared-composite-binding/prepared-composite-driver')) == r['driver_sha256']
history = b.read(b.FIXTURE / 'performance-history.json')['entries']
assert len(history) == 45 and history[-1]['candidate']['compiler_fingerprint'] == r['compiler_fingerprint']
image = b.read(folder / 'correlation-image.json')['descriptor']
assert len(image['numeric_maps']['regions']) == 2
assert all(region['rectangle'] is None for region in image['numeric_maps']['regions'])
metadata = b.read(folder / 'correlation.metadata.json')
archive_dir = b.FIXTURE / 'qualification/experiments/accepted44-margin-profile'
archive_dir.mkdir(exist_ok=False)
archives = {}
for source in sorted(folder.rglob('*')):
    if not source.is_file() or '__pycache__' in source.parts:
        continue
    name = str(source.relative_to(folder))
    raw = source.read_bytes()
    target = archive_dir / (name + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(target.read_bytes()) == raw
    archives[name] = {'path': str(target.relative_to(b.FIXTURE)), 'sha256': hashlib.sha256(raw).hexdigest(), 'compressed_sha256': b.digest(target)}
ranked = []
for row in r['ranking']:
    a = r['analysis'][row['name']]
    ranked.append({**row, 'execution_samples': a['execution_samples'], 'self_time_mechanisms': a['self_time_mechanisms'], 'action_categories': a['action_categories'], 'top_self_functions': a['top_self_functions'][:12], 'top_inclusive_functions': a['top_inclusive_functions'][:15]})
receipt = {
    'schema': 'mech.polybench.optimization-profile-review.v1', 'created_at': b.utc(),
    'scope': r['scope'], 'source_commit': r['source_commit'], 'workspace_commit': r['workspace_commit'],
    'compiler_fingerprint': r['compiler_fingerprint'], 'driver_sha256': r['driver_sha256'],
    'accepted_round': 44, 'ranked_cases': ranked, 'new_profiles': [row['name'] for row in r['ranking']],
    'reused_profiles': [], 'all15_covered': True, 'all_new_warmups_finite_c_validated': True,
    'all_new_execution_counters_match_accepted44': True,
    'source_evidence': {'correlation_numeric_maps': image['numeric_maps'], 'correlation_object_sha256': b.digest(folder / 'correlation.o'), 'object_export_mode': 'emit-object; metadata inspection only, not object execution or performance measurement', 'correlation_inner_range_source_ids': [3, 2], 'correlation_outer_range_source_ids': [3, 2]},
    'analysis': [
        'Gram-Schmidt is the largest training ratio. 317 of349 canonical execution samples (90.83%) are self time in its generated numeric function. Prior rejected bounds/copy candidates remain preserved; an identical source candidate must not be retried.',
        'Correlation is the second-largest training ratio. Its sampled execution includes repeated collection helpers, numeric-map entry, inner transpose and row-block publication. The emitted current Object contains only the scalar deviation map and inner correlation map plus transpose; no rectangular map is selected.',
        'The rectangular-map compiler currently accepts only literal inner range bounds. Correlation uses the same original U64 inclusive range factory with literal lower bound and a current input upper bound. This prevents fusion despite the inner source being immutable across the enclosing rectangular nest.',
        'Fill this general compiler gap by admitting current immutable inner U64 range bounds, with the original selected-factory cardinality, full finite source/replay envelopes and current-owner validation. Do not alter source ports or specialize on benchmark names.',
        'Several short kernels have fewer than60 execution samples. Their percentages indicate possible mechanisms, not precise cost estimates. All15 are freshly collected under the same accepted44 driver; diagnostic times do not enter scores.'
    ],
    'constraints': [
        'Priority follows descending accepted44 Mech/C margins within optimization15. The primary metric remains the equal-weight geometric mean.',
        'No holdout per-case source diagnosis, profiling or tuning. Holdout is the unchanged aggregate acceptance gate.',
        'No change to ports, inputs, C binaries or flags, tolerances, limits, split, timing boundaries or admission/accounting guarantees.',
        'The profile process and Object export have terminated successfully. No Cargo, profiling or timing session remains live.'
    ],
    'archives': archives, 'formal_history_entries_unchanged': len(history),
    'accepted_scores': {part: history[-1]['aggregates'][part]['geomean_mech_over_c_kernel'] for part in ['optimization', 'holdout']},
    'performance_score_observations': 0
}
b.write(b.FIXTURE / 'training-experiments/accepted44-margin-profile.json', receipt)
print(json.dumps({'new_profiles': 15, 'archives': len(archives), 'formal_history_entries': len(history), 'compiler_fingerprint': r['compiler_fingerprint']}))
