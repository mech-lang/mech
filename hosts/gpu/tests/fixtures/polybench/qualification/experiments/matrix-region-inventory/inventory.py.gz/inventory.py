import importlib.util,json,pathlib,os,subprocess,shutil,hashlib,re,time
root=pathlib.Path.cwd();folder=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
fp=b.compiler_fingerprint();focused=b.read(folder/'focused-result.json');assert focused['exit_code']==0 and focused['compiler_fingerprint']==fp
base=['cargo','build','--release','-p','mech-gpu','--no-default-features','--features','canonical-native-program','--example','polybench_qualification'];env=os.environ.copy();env['CARGO_TARGET_DIR']='/private/tmp/mech-polybench-pr1000-target'
with (folder/'driver-build.log').open('w') as out:subprocess.run(base,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
driver=folder/'inventory-driver';shutil.copy2(pathlib.Path(env['CARGO_TARGET_DIR'])/'release/examples/polybench_qualification',driver)
protocol,cases=b.protocol();objects=folder/'objects';objects.mkdir(exist_ok=False);old=pathlib.Path('/private/tmp/mech-polybench-optimization/round-31/inverse-bitcasts/objects')
def functions(asm):
 rows={};name=None
 for line in asm.splitlines():
  m=re.match(r'^[0-9a-f]+ <_(.+)>:',line)
  if m:name=m[1];rows[name]=[]
  elif name and re.match(r'^\s*[0-9a-f]+:',line):rows[name].append(line)
 return {name:hashlib.sha256('\n'.join(lines).encode()).hexdigest() for name,lines in rows.items()}
r={'schema':'mech.polybench.training-matrix-region-inventory.v1','created_at':b.utc(),'scope':'Optimization15 source-only candidate and lifetime census. No timing observations or native region execution; emitted function disassemblies must remain unchanged. No holdout inspection.','compiler_fingerprint':fp,'driver_sha256':b.digest(driver),'cases':{}}
for name in protocol['optimization']:
 inputs=folder/f'{name}-inputs.json';b.write(inputs,cases[name]['inputs']);obj=objects/f'{name}.o'
 process=subprocess.run([str(driver),str(b.FIXTURE/f'{name}.mec'),str(inputs),'0',f'emit-object={obj}'],text=True,capture_output=True,check=True,timeout=180)
 result=json.loads(process.stdout.strip().splitlines()[-1]);assert result['status']=='ok' and result['mode']=='emit-object';metadata=b.read(obj.with_suffix('.metadata.json'));diag=metadata['matrix_expression_candidates'];assert not diag['selected'];candidates=diag['inventory']['candidates']
 asm=subprocess.run(['/Library/Developer/CommandLineTools/usr/bin/llvm-objdump','--disassemble','--no-show-raw-insn',str(obj)],text=True,capture_output=True,check=True).stdout;obj.with_suffix('.disasm.txt').write_text(asm)
 assert functions(asm)==functions((old/f'{name}.disasm.txt').read_text()),name
 summary=[]
 for c in candidates:
  kernels=[s['Operator'] for s in c['steps'] if 'Operator' in s]
  summary.append({'entry':c['entry'],'exit':c['exit'],'source_steps':len(c['steps']),'operators':len(kernels),'external_inputs':len(c['external']),'escaping_values':len(c['outputs']),'private_banks':len(c['private_banks']),'logical_banks':len(c['storage_slots']),'storage_slots':c['slots'],'kinds':[k['kind'] for k in kernels]})
 r['cases'][name]={'source_sha256':b.digest(b.FIXTURE/f'{name}.mec'),'object_sha256':b.digest(obj),'metadata_sha256':b.digest(obj.with_suffix('.metadata.json')),'regions':summary,'inventory':diag['inventory'],'selected':False,'generated_functions_unchanged':True};b.write(folder/'training-inventory.json',r);print(name,json.dumps(summary),flush=True)
r['complete']=True;r['cases_with_candidates']=[name for name,row in r['cases'].items() if row['regions']];r['total_operators']=sum(c['operators'] for row in r['cases'].values() for c in row['regions']);r['private_banks']=sum(c['private_banks'] for row in r['cases'].values() for c in row['regions']);r['logical_banks']=sum(c['logical_banks'] for row in r['cases'].values() for c in row['regions']);r['storage_slots']=sum(c['storage_slots'] for row in r['cases'].values() for c in row['regions']);assert b.compiler_fingerprint()==fp;b.write(folder/'training-inventory.json',r);print(json.dumps({k:r[k] for k in ['cases_with_candidates','total_operators','private_banks','logical_banks','storage_slots']}),flush=True)
