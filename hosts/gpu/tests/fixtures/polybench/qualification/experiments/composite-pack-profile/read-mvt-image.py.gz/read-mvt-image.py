import json,struct
from pathlib import Path

def decode_image(data):
 assert data.startswith(b'MECHTVI4') and len(data)<64*1024*1024
 def node(at,limit,depth=0):
  assert depth<=128 and at+5<=limit
  tag=data[at];length=int.from_bytes(data[at+1:at+5],'little');start=at+5;end=start+length;assert end<=limit
  payload=data[start:end]
  if tag in (0,1,2):assert length==0;value=[None,False,True][tag]
  elif tag in (3,4,5,6):value=int.from_bytes(payload,'little',signed=tag in (4,6))
  elif tag==7:assert length==8;value=struct.unpack('<d',payload)[0]
  elif tag==8:value=payload.decode('utf-8')
  elif tag==11:
   count=int.from_bytes(payload[:4],'little');assert count==length-4;value=list(payload[4:])
  elif tag in (9,10,12):
   count=int.from_bytes(payload[:4],'little');cursor=start+4;keys=[]
   def key(cursor):
    size=int.from_bytes(data[cursor:cursor+4],'little');cursor+=4;assert cursor+size<=end;return data[cursor:cursor+size].decode(),cursor+size
   if tag==12:
    keybytes=int.from_bytes(data[cursor:cursor+4],'little');cursor+=4;keyend=cursor+keybytes
    for _ in range(count):name,cursor=key(cursor);keys.append(name)
    assert cursor==keyend
   value=[] if tag==9 else {}
   for i in range(count):
    if tag==10:name,cursor=key(cursor)
    elif tag==12:name=keys[i]
    child,cursor=node(cursor,end,depth+1)
    if tag==9:value.append(child)
    else:assert name not in value;value[name]=child
   assert cursor==end
  else:raise ValueError(tag)
  return value,end
 value,end=node(8,len(data));assert end==len(data);return value

folder=Path(__file__).resolve().parent;old=Path('/private/tmp/mech-polybench-optimization/round-31/inverse-bitcasts/objects');metadata=json.loads((old/'mvt.metadata.json').read_text());data=(old/'mvt.o').read_bytes();header=struct.unpack_from('<8I',data);assert header[0]==0xfeedfacf;pos=32;sections=[];symtab=None
for _ in range(header[4]):
 cmd,size=struct.unpack_from('<II',data,pos)
 if cmd==0x19:
  count=struct.unpack_from('<I',data,pos+64)[0]
  for i in range(count):
   at=pos+72+80*i;sections.append({'name':data[at:at+16].split(b'\0',1)[0].decode(),'address':struct.unpack_from('<Q',data,at+32)[0],'size':struct.unpack_from('<Q',data,at+40)[0],'offset':struct.unpack_from('<I',data,at+48)[0]})
 if cmd==2:symtab=struct.unpack_from('<4I',data,pos+8)
 pos+=size
assert symtab
symoff,nsyms,stroff,strsize=symtab;symbol=None
for i in range(nsyms):
 idx,typ,sect,desc,value=struct.unpack_from('<IBBHQ',data,symoff+16*i)
 if idx and sect:
  name=data[stroff+idx:stroff+strsize].split(b'\0',1)[0].decode()
  if name=='_'+metadata['native_metadata_symbol']:symbol=(sect,value)
assert symbol
sect,address=symbol;section=sections[sect-1];offset=section['offset']+address-section['address'];payload=data[offset:offset+metadata['native_metadata_bytes']];print('metadata prefix',repr(payload[:100]));image=decode_image(payload);(folder/'mvt-image.json').write_text(json.dumps(image,indent=2)+'\n');print('top-level keys',list(image))
