//! Exact source consumer proofs before native view emission is enabled.
use super::*;
use crate::native_artifact::program::prepare::{numeric_binary::Kind, numeric_transpose_products};
use mech_engine::native_artifact::{
    NativeIterationTerminator as Terminator, NativeMatchTerminator as Term,
};

fn prove(source: &str, expected: usize, selected: Option<usize>) {
    for artifact in artifacts(source) {
        let catalog = mech_stdlib::source_catalog();
        let jit = JitProgramArtifact::compile(&artifact, &catalog).unwrap();
        let metadata = jit.descriptor().metadata();
        let plan = &metadata.plan;
        let views = numeric_transpose_products::derive(plan).unwrap();
        println!(
            "transpose/product source proof: expected {expected}, found {}",
            views.len()
        );
        assert_eq!(views.len(), expected, "{source}");
        for view in views {
            let transpose = metadata.numeric_binary.at(view.entry as usize).unwrap();
            let product = metadata.numeric_binary.at(view.product as usize).unwrap();
            assert!(matches!(transpose.kind, Kind::Transpose { .. }));
            assert_eq!(product.kind, Kind::Product);
            assert_eq!(Some(view.transposed_operand), selected);
            assert_eq!(
                view.operands[view.transposed_operand],
                transpose.operands[0]
            );
            assert_eq!(
                view.operands[1 - view.transposed_operand],
                product.operands[1 - view.transposed_operand]
            );
            assert!(view.elided_values.contains(&transpose.output));
            assert!(
                view.elided_values
                    .contains(&product.operands[view.transposed_operand])
            );
            assert!(
                view.operands
                    .iter()
                    .all(|v| !view.elided_values.contains(v))
            );
            assert_eq!(view.continuation.last(), Some(&view.product));
            assert_eq!(
                plan.blocks()[view.product as usize].terminator(),
                Terminator::Scalar(Term::Jump(view.resume))
            );
            assert_eq!(view.output, product.output);
            assert_eq!(view.parent, plan.blocks()[view.entry as usize].iteration());
        }
    }
}

#[test]
fn numeric_transpose_products_prove_original_and_decoded_both_operands_and_aliases() {
    for (source, side) in [
        ("a<[f64]>' ** b<[f64]>\n", 0),
        ("a<[f64]> ** b<[f64]>'\n", 1),
        ("a := input<[f64]>\nt := a'\nu := t\nu ** peer<[f64]>\n", 0),
        ("a<[f64]:3,5>' ** b<[f64]:3,7>\n", 0),
        ("a<[f64]:3,5> ** b<[f64]:7,5>'\n", 1),
    ] {
        prove(source, 1, Some(side));
    }
}

#[test]
fn numeric_transpose_products_decline_escapes_multiple_uses_other_consumers_and_intervening_work() {
    for source in [
        "t := a<[f64]>'\n(t, t ** b<[f64]>)\n",
        "t := a<[f64]>'\n(t ** b<[f64]>, t ** c<[f64]>)\n",
        "t := a<[f64]>'\nt ** t\n",
        "a<[f64]>' + b<[f64]>\n",
        "a<[f64]>'\n",
        "a<[f64]>' ** (b<[f64]> ** c<[f64]>)\n",
        "t := a<[f64]>'\nflag<bool>? | true => t ** b<[f64]> | false => t ** c<[f64]>\n",
    ] {
        prove(source, 0, None);
    }
}

#[test]
fn numeric_transpose_products_prove_optimization_operator_graphs_and_bound_initial_scope() {
    let fixtures =
        std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures/polybench");
    for (name, expected) in [
        ("bicg", 1),
        ("mvt", 1),
        ("covariance", 1),
        ("correlation", 1),
        ("atax", 0),
    ] {
        let source = std::fs::read_to_string(fixtures.join(format!("{name}.mec"))).unwrap();
        println!("optimization source proof {name}");
        prove(&source, expected, (expected > 0).then_some(0));
    }
}
