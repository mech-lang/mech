use serde::Deserialize;
fn main(){let a=std::env::args().collect::<Vec<_>>();let bytes=std::fs::read(&a[1]).unwrap();let mut reader=mech_engine::native_artifact::BuildOwnedImageReader::from_image(&bytes).unwrap();let value=serde_json::Value::deserialize(&mut reader).unwrap();reader.end().unwrap();std::fs::write(&a[2],serde_json::to_vec_pretty(&value).unwrap()).unwrap();}
