from pathlib import Path
import subprocess,sys
f=Path(__file__).resolve().parent
for name in ['prepare-object.py','build-host.py','collect.py','bind-call-relocations.py','verify-and-annotate.py']:
 print('Starting',name,flush=True)
 r=subprocess.run([sys.executable,str(f/name)])
 if r.returncode:raise SystemExit(r.returncode)
