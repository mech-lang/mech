from pathlib import Path
import os,subprocess,json,time,importlib.util
root=Path.cwd();folder=Path(__file__).resolve().parent;attempt=folder/'stage-c-attempt-01';spec=importlib.util.spec_from_file_location('b',root/'scripts/benchmark-polybench.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);fp=b.compiler_fingerprint();assert fp==b.read(attempt/'source-manifest.json')['compiler_fingerprint'];env=os.environ.copy();env['CARGO_TARGET_DIR']='/private/tmp/mech-polybench-pr1000-target'
argv=['cargo','check','-p','mech-gpu','--no-default-features','--features','canonical-native-program','--lib'];start=time.monotonic()
with(attempt/'emitter-check.log').open('x')as out:r=subprocess.run(argv,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
log=(attempt/'emitter-check.log').read_text();receipt={'command':argv,'exit_code':r.returncode,'wall_seconds':time.monotonic()-start,'compiler_fingerprint':fp,'source_unchanged':fp==b.compiler_fingerprint(),'performance_observations':0};b.write(attempt/'emitter-check-result.json',receipt);print(json.dumps(receipt),flush=True);print(log[-10000:],flush=True);assert receipt['source_unchanged'];raise SystemExit(r.returncode)
