from pathlib import Path
import subprocess,sys,json,shutil
f=Path(__file__).resolve().parent
r=subprocess.run([sys.executable,str(f/'run-emitter-tests-04.py')]);assert r.returncode==0
q=json.loads((f/'stage-c-attempt-04/emitter-tests-result.json').read_text());assert q['passed_tests']==[10] and q['source_unchanged'];shutil.copyfile(f/'stage-c-attempt-04/emitter-tests-result.json',f/'focused-result.json')
s=json.loads((f/'current-work.json').read_text());s.update(compiler_fingerprint=q['compiler_fingerprint'],stage='Revised feature-gated source fully focused-qualified; broad checks running',complete=False);(f/'current-work.json').write_text(json.dumps(s,indent=2)+'\n')
r=subprocess.run([sys.executable,str(f/'run-all-qualification.py')]);raise SystemExit(r.returncode)
