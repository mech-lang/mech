from pathlib import Path
import json,re
f=Path(__file__).resolve().parent;r=json.loads((f/'emission-census.json').read_text());telemetry={}
for n,c in r['cases'].items():
 telemetry[n]={a:{k:v[k] for k in ['code_bytes','static_instruction_count','reported_native_stack_bytes','object_file_bytes']}for a,v in c['actors'].items()}
print(json.dumps({'changed':r['native_code_changed_cases'],'no_new_fma':r['no_new_fma'],'telemetry':telemetry}))
for name,suffix in [('gramschmidt','numeric_5'),('durbin','numeric_4'),('cholesky','numeric_0')]:
 lines=(f/'objects'/f'{name}-candidate.disasm.txt').read_text().splitlines();fn=None;printed=0
 for i,line in enumerate(lines):
  m=re.match(r'^[0-9a-f]+ <_(.+)>:',line)
  if m:fn=m[1]
  if fn and fn.endswith(suffix) and re.search(r'\bfadd(?:\.2d)?\s+(?:d|v)',line):
   if name=='gramschmidt' and not re.search(r'\bfadd\.2d',line):continue
   print(name,fn,'\n'+'\n'.join(lines[max(0,i-9):i+10]));printed+=1
   if printed>=3:break
