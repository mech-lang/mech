from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,os,shutil,subprocess
R=Path('/Users/cim310/mech-lang/mech/benchmarks/related-post-gen');D=R/'results'
S=Path('/private/tmp/mech-related-llvm-native-image-compiler-20261107')
C=Path('/private/tmp/mech-related-boolean-chain-branches-compiler-20261107')
P=Path(__file__).parent
L=S/'benchmarks/related-post-gen/trials/llvm-native-image-20261107'
B=C/'benchmarks/related-post-gen/trials/cranelift-boolean-chain-branches-20261107'
LP=Path('/private/tmp/mech-related-llvm-native-image-cohort-20261107-v1')
BP=Path('/private/tmp/mech-related-boolean-chain-branches-cohort-20261107-v1')
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n')
def head(s):return subprocess.check_output(['git','-c','gc.auto=0','rev-parse','HEAD'],cwd=s,text=True).strip()
source=head(S);candidate=head(C)
assert source=='b638320000f7cb33837df2ee73f09221551826a0' and candidate.startswith('8571f39921')
latencies={n:read(D/n)for n in ['comparison-llvm-native-image-randomized-20261107-5000-m3.json','comparison-llvm-native-image-confirmation-20261107-5000-m3.json']}
resources=read(D/'comparison-llvm-native-image-resources-20261107-5000-m3.json')
current=read(D/'comparison-native-boolean-chain-branches-20261107-5000-m3.json')
current_resource=read(D/'comparison-native-boolean-chain-branches-resources-20261107-5000-m3.json')
def cohort(d,names):
    return dict(samples=len(d['samples']),all_outputs_exact=all(x['exact_rust_output']for x in d['samples']),post_JSON_Rust_reference=d['matched_native_reference'],whole_process_Rust_reference=d['whole_process_reference'],rows={n:d['summary'][n]for n in names})
names=['mech-ir242-reuse-4','mech-ir264-cranelift-runtime-control','mech-llvm-reuse-4','mech-llvm-after-4','mech-ir257-reuse-4']
qualification=read('/private/tmp/mech-related-llvm-native-image-tests-20261107-v4/summary.json')
restore=read('/private/tmp/mech-related-restore-instruction-phases-20261107-v2/summary.json')
report=dict(schema='mech.related-post-gen.optional-LLVM-native-image.v1',updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_commit=source,branch='codex/related-llvm-native-image-20261107',selected=False,default_backend_changed=False,LLVM_required_for_Cranelift=False,LLVM_required_at_runtime=False,LLVM_toolchain='Explicit opt/llc and native linker only when choosing the experimental LLVM Object emitter',selected_compiler='4cc266ae0d05c69432a4c15ffe99d5e586685647',default_identity='IR264/work115/ABI41/image9',experimental_identity='IR264/work115/ABI41/image10 with bound source/backend/options/toolchain/machine digest',goal_complete=False,
    latency={n:cohort(d,names)for n,d in latencies.items()},prospective_rule=read(LP/'prospective-performance-rule.json'),first_paired_analysis=read(LP/'paired-prospective-analysis.json'),confirmation_paired_analysis=read(LP/'paired-confirmation-analysis.json'),
    resources={n:resources['summary'][n]for n in ['mech-ir242-reuse-4-instrumented','mech-ir264-cranelift-runtime-control-instrumented','mech-llvm-reuse-4-instrumented','mech-llvm-after-4-instrumented','rust-ordered-ordered-mask-instrumented','rust-ordered-ordered-apple-m3-instrumented']},
    qualification=dict(native=qualification,maintained_program_semantic_comparisons=240,maintained_loader_checks=132,loader_and_finite=read('/private/tmp/mech-related-llvm-native-image-loaders-budgets-20261107-v3/summary.json'),generated_applications=read('/private/tmp/mech-related-llvm-native-image-generated-app-20261107-v4/summary.json'),scalar_rows=128,DEFLATE_rows=5,all133_nontiming_fields_and_allocations_exact=True,default26_bundle_files_exact=True,LLVM_original_decoded26_bundle_files_exact=True),
    interpretation='Genuine LLVM processing gain confirmed against fixed IR242 and identical IR264 frontend/runtime. Other-boundary noninferiority passes predeclared1% gate; whole-process superiority is not established. LLVM remains optional; no default adoption decision.',
    machine_limit_policy='Actual native text/constants plus root-plus-largest-helper stack policy; same-Object text/constants audit. Not a universal interprocedural stack analysis.',
    backend_gap_profile=dict(all4000_invocations_exact=True,scope='evaluate_into only; periodic own-process register observations, not CPU-time shares or dynamic instruction counts',query_Cranelift_instructions_static=7823,query_LLVM_instructions_static=5792,query_Cranelift_stack_observations=502,query_Cranelift_all_observations=1135,query_LLVM_stack_observations=125,query_LLVM_all_observations=582),
    restoration_exclusive_instruction_diagnostic=restore,
    IR257_fresh_recheck='Still unselected:18/31 then19/31 whole-process wins, not target superiority. Lifecycle trace finds no repeatable large join/destruction saving; no attribution of the prior1.5-1.8ms association to Boolean normalization.',
    latest973=dict(commit='7223f308e49e44d69598be73b5770a859322da51',changes_since_previous='Only documentation/evidence; production Rust/Cargo/lock/flags unchanged. R190 private-join variant rejected upstream; not adopted.'),
    remaining=['Recover backend gains in existing Cranelift/compiler without requiring external LLVM tools.','Replace repeated owned restoration materialization with a compact representation while preserving eager independent validation.','Executed proof/refusal/consumption and successful-funding-check census remains pending.','Qualify performance on general unique unordered rows before any broad parity claim.','Meet fastest eligible measured Rust at BOTH boundaries.'])
llvm_report=D/'compiler-native-llvm-native-image-20261107.json';write(llvm_report,report)
clif_report=dict(schema='mech.related-post-gen.rejected-Cranelift-Boolean-chains.v1',updated_utc=report['updated_utc'],source_commit=candidate,parent=source,branch='codex/related-boolean-chain-branches-20261107',identity='IR265/work115/ABI41/image9',selected=False,goal_complete=False,LLVM_tools_used=False,change='Distribute already executed, proven canonical AND/OR predicates into direct branches. No source work, loads, errors, finite debits or publication moved or skipped.',
    qualification=read('/private/tmp/mech-related-boolean-chain-branches-tests-20261107-v3/summary.json'),benchmark_qualification=read('/private/tmp/mech-related-boolean-chain-branches-runners-20261107-v3/summary.json'),scalar128_all_fields_exact=read('/private/tmp/mech-related-boolean-chain-branches-regressions-20261107-v3/scalar-comparison.json'),DEFLATE5_all_fields_exact=read('/private/tmp/mech-related-boolean-chain-branches-regressions-20261107-v3/one-kib-comparison.json'),
    cohort=cohort(current,['mech-ir242-reuse-4','mech-ir264-cranelift-runtime-control','mech-llvm-reuse-4','mech-ir265-reuse-4']),resources={n:current_resource['summary'][n]for n in ['mech-ir242-reuse-4-instrumented','mech-ir264-cranelift-runtime-control-instrumented','mech-llvm-reuse-4-instrumented','mech-ir265-reuse-4-instrumented']},prospective_rule=read(BP/'prospective-rule.json'),decision=read(BP/'paired-analysis.json'),
    same_binary_control_remeasurements='Fresh IR242/IR264/LLVM control measurements are not new compiler gains/regressions. Earlier cohorts and original IR242 promotion retained.',
    first_failures='V2 new semantic tests and32 outputs pass; one existing structural cleanup assertion catches unnecessary distribution of already constant predicates. V3 leaves those to the existing constant-fold pass;38 cleanup tests pass. CI harness first expected399 names instead of399+2; all actual401 names then execute and pass.',
    conclusion='Rejected:0/31 processing wins versus parent IR264; paired median+3.143%, instructions+6.06%, whole-process paired+8.983%. No unchanged rerun to seek promotion. Further work should target instruction combining/dataflow, not this branch distribution.',
    next_actions=report['remaining'])
clif_report_path=D/'compiler-native-boolean-chain-branches-20261107.json';write(clif_report_path,clif_report)

def put(root,relative,data):
    p=root/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
def copy(root,path,relative=None):
    path=Path(path);relative=relative or path.name;data=path.read_bytes()
    if path.suffix in ['.rs','.ll','.o','.mecb','.bin','.toml'] or len(data)>16000:
        relative+='.gz';data=gzip.compress(data,mtime=0)
    put(root,relative,data)
def tree(root,path,prefix):
    path=Path(path)
    if not path.exists():return
    for parent,dirs,files in os.walk(path):
        dirs[:]=sorted(x for x in dirs if x not in ['target','cargo-target','.git','__pycache__','latency','resources','edges','output-objects','llvm-build'])
        for name in sorted(files):
            f=Path(parent)/name;rel=f.relative_to(path)
            if len(rel.parts)>3:continue
            if name.endswith(('.rs','.py','.mec','.toml')) or (f.suffix=='.json'and('output'not in name and not name.startswith(('actual-','full5000.json','full5000-success.json','posts.json')))):
                copy(root,f,prefix+'/'+str(rel))
for root,rp,summary in [(L,llvm_report,report),(B,clif_report_path,clif_report)]:
    root.mkdir(parents=True,exist_ok=True);copy(root,rp,'report.json')
    write(root/'source-and-selection.json',dict(source_commit=source if root==L else candidate,parent=None if root==L else source,selected=False,selected_IR242_unchanged=True,LLVM_mandatory=False,goal_complete=False,input_sha256=current['input']['sha256']))
    for name in ['compare-implementations.py','build-compiler.py','build-dependent-compiler.py','build-host.py','build-metrics.py','measurement.rs','audit-native-link.py','experiments/check-native-link-audit.py','experiments/check_subset3.py']:
        copy(root,R/name,'recipes/'+name)
    tree(root,P,'backend-profile')
    # Host adapters/probes are compressed: they must not enter compiler source inventories.
    for mode in ['cranelift','llvm']:
        for name in ['runner.rs','build.json','native-link-proof.json','link-audit.json','summary-0.json','summary-1.json','run-0.json','run-1.json']:
            copy(root,P/mode/name,'backend-profile/'+mode+'/'+name)
    tree(root,Path('/private/tmp/mech-related-restore-instruction-phases-20261107-v2'),'restoration-phases')
    for mode in ['after-4','reuse-4'] if root==L else []:
        bundle=Path('/private/tmp/mech-related-llvm-native-image-smoke-20261107-v4')/mode/'build'
        for f in bundle.iterdir():
            if f.is_file():copy(root,f,'objects/'+mode+'/'+f.name)
        machine=next((bundle/'llvm-build').glob('mech-llvm-*'))
        for name in ['native.ll','optimized.ll','native.o','remarks.yaml','machine-facts.json']:
            copy(root,machine/name,'machine/'+mode+'/'+name)
        text=(machine/'native.ll').read_text();import re
        write(root/'machine'/mode/'definitions.json',re.findall(r'^define .*? @"([^"\n]+)"\(',text,re.M))
    if root==L:
        for f in latencies:copy(root,D/f,'cohorts/'+f)
        for f in ['comparison-llvm-native-image-resources-20261107-5000-m3.json','size-llvm-native-image-20261107.json']:copy(root,D/f,'cohorts/'+f)
        tree(root,LP,'cohorts/protocol')
        for name,p in [('build','/private/tmp/mech-related-llvm-native-image-opt-20261107-v4'),('tests','/private/tmp/mech-related-llvm-native-image-tests-20261107-v4'),('runtime','/private/tmp/mech-related-llvm-native-image-runtime-20261107-v4'),('generated','/private/tmp/mech-related-llvm-native-image-generated-app-20261107-v4'),('loaders','/private/tmp/mech-related-llvm-native-image-loaders-budgets-20261107-v3'),('regressions','/private/tmp/mech-related-llvm-native-image-regressions-20261107-v4'),('default-equivalence','/private/tmp/mech-related-llvm-native-image-default-equivalence-20261107-v4'),('decoded-equivalence','/private/tmp/mech-related-llvm-native-image-decoded-equivalence-20261107-v4'),('runtime-correctness','/private/tmp/mech-related-llvm-native-image-smoke-20261107-v4'),('explicit-M3-Rust','/private/tmp/mech-related-apple-m3-rust-controls-20261107-v1'),('IR257-lifecycle','/private/tmp/mech-related-native-lifecycle-trace-20261107-v1')]:tree(root,Path(p),name)
        copy(root,S/'hosts/gpu/src/native_artifact/program/llvm_backend/machine_facts.py','machine-reader/machine_facts.py')
        tree(root,Path('/private/tmp/mech-related-llvm-native-image-smoke-20261107-v2'),'first-image-attempts/v2')
    else:
        for f in ['comparison-native-boolean-chain-branches-20261107-5000-m3.json','comparison-native-boolean-chain-branches-resources-20261107-5000-m3.json']:copy(root,D/f,'cohorts/'+f)
        tree(root,BP,'cohorts/protocol')
        for name,p in [('build','/private/tmp/mech-related-boolean-chain-branches-opt-20261107-v3'),('tests','/private/tmp/mech-related-boolean-chain-branches-tests-20261107-v3'),('first-tests','/private/tmp/mech-related-boolean-chain-branches-tests-20261107-v2'),('runners','/private/tmp/mech-related-boolean-chain-branches-runners-20261107-v3'),('metrics','/private/tmp/mech-related-boolean-chain-branches-metrics-20261107-v3'),('regressions','/private/tmp/mech-related-boolean-chain-branches-regressions-20261107-v3')]:tree(root,Path(p),name)
        bundle=Path('/private/tmp/mech-related-boolean-chain-branches-runners-20261107-v3/build')
        for f in bundle.iterdir():
            if f.is_file():copy(root,f,'object/'+f.name)
    (root/'README.md').write_text('# '+('Optional LLVM native-image comparison'if root==L else'Rejected Cranelift Boolean-chain experiment')+'\n\nRead report.json (or report.json.gz) and source-and-selection.json. The selected IR242 compiler is unchanged; LLVM is optional. Both latency boundaries use the fastest eligible measured Rust independently. All first/adverse samples are retained. Run python3 verify.py to check file integrity, exact cohort outputs and arithmetic. Diagnostic PC observations are not CPU-time shares or dynamic instruction counts. Compressed Rust probes and manifests are evidence, not production compiler inputs. Local recipes retain exact original paths/toolchain receipts; rebuilding requires those inputs or equivalent relocated paths.\n')
    files={}
    for f in sorted(root.rglob('*')):
        if not f.is_file()or f.name=='manifest.json'or'__pycache__'in f.parts:continue
        b=f.read_bytes();decoded=gzip.decompress(b)if f.suffix=='.gz'else b
        files[str(f.relative_to(root))]=dict(bytes=len(b),sha256=sha(b),gzip=f.suffix=='.gz',decoded_bytes=len(decoded),decoded_sha256=sha(decoded))
    write(root/'manifest.json',dict(schema='mech.related-post-gen.evidence-packet.v1',source_commit=source if root==L else candidate,selected=False,goal_complete=False,files=files))
    print(root.name,len(files),'files',sum(x['bytes']for x in files.values()),'bytes',flush=True)

# Preserve ledger snapshots before reconciling their current pointers.
snap=P/'ledger-before';snap.mkdir(exist_ok=True)
for name in ['published-integrated-review-branch-20261106.json','next-related-compiler-gaps-20261106.json','compiler-branches-20261105.json','selected-speed-checkpoint-20261107.json']:
    path=D/name;old=read(path)
    if not(snap/name).exists():shutil.copyfile(path,snap/name)
    old['updated_utc']=report['updated_utc'];old['goal_complete']=False
    old['latest_backend_report']=str(llvm_report);old['latest_existing_backend_report']=str(clif_report_path)
    if 'LLVM_backend_work'in old:old.setdefault('historical_LLVM_typed_SSA_work',old['LLVM_backend_work'])
    old['LLVM_backend_work']=dict(source_commit=source,branch=report['branch'],genuine_program_executed=True,qualification_complete_with_two_inherited_GPU_failures=True,latency_cohorts=2,processing_gate_passed=True,other_boundary_noninferiority_passed=True,whole_process_superiority_established=False,selected=False,mandatory=False,report=str(llvm_report))
    old['unselected_IR265']=dict(source_commit=candidate,branch=clif_report['branch'],report=str(clif_report_path),decision='Rejected:processing+3.143% paired vsparent, whole+8.983%;3758allocations unchanged;58.159M processing instructions.')
    old['current_Rust_reference']=current['matched_native_reference'];old['current_whole_process_Rust_reference']=current['whole_process_reference']
    old.setdefault('same_binary_remeasurement_history',[])
    prior=old.get('latest_selected_remeasurement')
    if prior and prior not in old['same_binary_remeasurement_history']:old['same_binary_remeasurement_history'].append(prior)
    old['latest_selected_remeasurement']=dict(compiler='4cc266ae0d05c69432a4c15ffe99d5e586685647',executable_sha256='ff91f2ab9126e8aba3ec7577d802e443cde63da1e77a8acec1f744f3769f2e7f',same_binary_not_compiler_gain=True,cohort='comparison-native-boolean-chain-branches-20261107-5000-m3.json',timing=current['summary']['mech-ir242-reuse-4'])
    old['next_action']='Keep LLVM optional; do not adopt rejected IR265. Investigate native instruction combining and compact owned-image restoration with eager independent validation; complete executed proof/funding census.'
    old['restoration_instruction_breakdown']=dict(report='/private/tmp/mech-related-restore-instruction-phases-20261107-v2/summary.json',owned_outer_materialization_mean_instructions=51233288.571428575,reader_initialization_mean_instructions=40929,diagnostic_only=True,no_work_deferred=True)
    if 'status'in old:old['status']='active:IR242 selected; optional LLVM native execution and two processing-gain cohorts qualified; Cranelift IR265 branch experiment rejected; Rust parity unmet.'
    if name=='next-related-compiler-gaps-20261106.json':old['latest_report']=str(clif_report_path)
    write(path,old)
print('reports and ledgers reconciled; original promotion timings preserved',flush=True)
