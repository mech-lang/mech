use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::PathBuf};

const EXPECTED: &str = "{\"Cargo.toml\":\"190bd842a16300183e9f1308eb73e74b3998539c260b540dd245ba5324bb923e\",\"application.mec\":\"25f1d1e09b91d484f9f9124f4fd5e6fe89aa8976a5a6152017c56d394d69345f\",\"factory-profile.json\":\"a2ff1ef171376a65ee7377a98046b68335b5258185eef65b44455a5fe8547074\",\"native-descriptor.bin\":\"9d20562761afe016f8d1331b1e3606d84c9d5535ef208769ec33eccf5c4bb4f9\",\"native-descriptor.json\":\"7b2231f1e50b0a0a8cea998a473858e5287f5fecd7a7cb127e0db3004a46135e\",\"object-identity.bin\":\"ed4958bab1ecb471ddffee45249b3f4561981914cfa41f5fb90f3d5a8f969ffd\",\"program.mecb\":\"695245a09383ef53bbe6efd88852ea38ff35ddba632f0d5f03e6ed7a9456c33f\",\"program.o\":\"6a53c6a943919d63bebb927580a1ac88c1b92099e6063c0b59c5cb5f2ec0f201\",\"rust-toolchain.toml\":\"19219593d7dba33a75623287af94da940a93fac92eeef99e8fff9b7fd804fcf9\",\"src/main.rs\":\"5f2e16033106f40bd01171b2e245b6463f68ec5da917f9763b9a9b57f9e31a09\"}";
fn digest(bytes: &[u8]) -> String {
    Sha256::digest(bytes)
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect()
}
fn main() {
    assert_eq!(
        std::env::var("HOST").unwrap(),
        std::env::var("TARGET").unwrap(),
        "canonical native object is host-only"
    );
    let root = PathBuf::from(std::env::var_os("CARGO_MANIFEST_DIR").unwrap());
    let expected: BTreeMap<String, String> = serde_json::from_str(EXPECTED).unwrap();
    let manifest_bytes = fs::read(root.join("linked-manifest.json")).unwrap();
    let manifest: serde_json::Value = serde_json::from_slice(&manifest_bytes).unwrap();
    assert_eq!(manifest["schema"], "mech.canonical-linked-program-application.v1");
    let mut pins: BTreeMap<String, String> =
        serde_json::from_value(manifest["pins"].clone()).unwrap();
    let script = pins.remove("build.rs").expect("build script pin");
    assert_eq!(
        digest(&fs::read(root.join("build.rs")).unwrap()),
        script,
        "build script changed"
    );
    assert_eq!(pins, expected, "manifest generated-input pins changed");
    for (name, hash) in expected {
        assert_eq!(
            digest(&fs::read(root.join(&name)).unwrap()),
            hash,
            "changed generated input {name}"
        );
        println!("cargo:rerun-if-changed={name}");
    }
    println!("cargo:rerun-if-changed=linked-manifest.json");
    println!("cargo:rerun-if-changed=build.rs");
    println!("cargo:rustc-link-arg={}", root.join("program.o").display());
}
