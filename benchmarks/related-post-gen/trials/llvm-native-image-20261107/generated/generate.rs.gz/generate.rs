use mech_engine::{CanonicalSourceFrontend, ProgramArtifact};
use mech_gpu::native_artifact::{NativeProgramLimitMode, generate_linked_llvm_program_application_with_limits, generate_linked_program_application_with_limits};
use mech_syntax::document::{
    AstNode, DocumentId, DocumentSyntax, ParseConfig, Revision, TextSnapshot,
    parse_canonical_document,
};
use std::path::Path;

fn compile(text: &str) -> ProgramArtifact {
    let parsed = parse_canonical_document(
        TextSnapshot::new(DocumentId(71), Revision(1), text).unwrap(),
        ParseConfig::default(),
    );
    assert!(
        parsed.is_strictly_clean(),
        "source must parse without recovery: {:?}",
        parsed.diagnostics
    );
    CanonicalSourceFrontend
        .compile_document_with_catalog(
            &DocumentSyntax::cast(parsed.syntax()).unwrap(),
            mech_stdlib::source_catalog(),
        )
        .unwrap()
        .compile_artifact()
        .unwrap()
}
fn main() {
    let args=std::env::args().skip(1).collect::<Vec<_>>();assert_eq!(args.len(),2);
    let root=Path::new(&args[1]);std::fs::create_dir_all(root).unwrap();
    let source="value<u64> + 1u64\n";
    let original=compile(source);
    let decoded=mech_engine::decode_program_artifact_bytecode_v1(&mech_engine::encode_program_artifact_bytecode_v1(&original).unwrap()).unwrap();
    let toolchain=mech_gpu::native_artifact::NativeLlvmToolchain::new("/opt/homebrew/opt/llvm/bin");
    let catalog=mech_stdlib::source_catalog();
    for (name,artifact)in[("llvm",&original),("llvm-decoded",&decoded)] {
        generate_linked_llvm_program_application_with_limits(Path::new(&args[0]),&root.join(name),"native-app",artifact,&catalog,source.as_bytes(),NativeProgramLimitMode::NoLimits.compilation(),&toolchain).unwrap();
    }
    generate_linked_program_application_with_limits(Path::new(&args[0]),&root.join("default"),"native-app",&original,&catalog,source.as_bytes(),NativeProgramLimitMode::NoLimits.compilation()).unwrap();
    for (name,n)in[("zero",0),("forty-one",41),("near-max",u64::MAX-1),("overflow",u64::MAX)] {
      let draft=mech_core::snapshot::ValueDraft { schema:original.inputs()[0].schema,shape_values:Box::new([]),data:mech_core::ValueDataDraft::U64(n) };
      std::fs::write(root.join(format!("{name}.json")),serde_json::to_vec(&vec![draft]).unwrap()).unwrap();
      if n<u64::MAX {
        let value=mech_core::snapshot::ValueDraft { schema:original.outputs()[0].schema,shape_values:Box::new([]),data:mech_core::ValueDataDraft::U64(n+1) }.finalize(&mech_core::snapshot::SnapshotValidationContext::new(original.schemas())).unwrap();
        let bytes=value.canonical_snapshot_bytes(original.schemas()).unwrap();
        let hex=bytes.iter().map(|b|format!("{b:02x}")).collect::<String>()+"\n";
        std::fs::write(root.join(format!("{name}.expected")),hex).unwrap();
      }
    }
}
