use mech_engine::{CanonicalSourceFrontend, ProgramArtifact};
use mech_gpu::native_artifact::{NativeProgramLimitMode, emit_program_llvm_ir_with_limits};
use mech_syntax::document::{
    AstNode, DocumentId, DocumentSyntax, ParseConfig, Revision, TextSnapshot,
    parse_canonical_document,
};
use std::path::Path;

fn compile(text: &str) -> ProgramArtifact {
    let parsed = parse_canonical_document(
        TextSnapshot::new(DocumentId(71), Revision(1), text).unwrap(),
        ParseConfig::default(),
    );
    assert!(
        parsed.is_strictly_clean(),
        "source must parse without recovery: {:?}",
        parsed.diagnostics
    );
    CanonicalSourceFrontend
        .compile_document_with_catalog(
            &DocumentSyntax::cast(parsed.syntax()).unwrap(),
            mech_stdlib::source_catalog(),
        )
        .unwrap()
        .compile_artifact()
        .unwrap()
}
fn main() {
    std::thread::Builder::new().stack_size(32*1024*1024).spawn(|| {
        let a=std::env::args().skip(1).collect::<Vec<_>>();assert_eq!(a.len(),2);
        let text=std::fs::read_to_string(&a[0]).unwrap();let artifact=compile(&text);
        let llvm=emit_program_llvm_ir_with_limits(&artifact,&mech_stdlib::source_catalog(),NativeProgramLimitMode::NoLimits.compilation()).unwrap();
        std::fs::write(&a[1],llvm).unwrap();
    }).unwrap().join().unwrap();
}
