from pathlib import Path
import json,os,subprocess,time
p=Path(__file__).parent
b=json.loads((p/'build-command.json').read_text())
for name,cmd,env in [('build',b['command'],b['environment']),('trace',[b['command'][-1],'numeric_forward_windows_query_diagnostic','--test-threads=1','--nocapture'],{'MECH_FORWARD_WINDOW_TRACE':'1','MECH_FORWARD_WINDOW_QUERY_SOURCE':'/private/tmp/mech-related-conjoined-window-integration-runners-20261107-v1/reuse-4/build/source.mec'})]:
 start=time.monotonic()
 with (p/(name+'.stdout.log')).open('w') as out,(p/(name+'.stderr.log')).open('w') as err:r=subprocess.run(cmd,env={**os.environ,**env},stdout=out,stderr=err)
 (p/(name+'.json')).write_text(json.dumps(dict(command=cmd,exit=r.returncode,seconds=time.monotonic()-start,timing_excluded=True),indent=2)+'\n')
 print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
