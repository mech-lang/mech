//! Diagnostic only: bounded raw allocation stacks for one continuous post-JSON window.
//! No sampled timing is eligible for benchmark comparisons.
use std::alloc::{GlobalAlloc, Layout, System};
use std::cell::{Cell, UnsafeCell};
use std::ffi::c_void;
use std::io::Write;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};

const MAX_EVENTS: usize = 16384;
const MAX_FRAMES: usize = 256;
#[derive(Clone, Copy)]
struct Event { bytes: usize, operation: u8, thread: usize, frames: usize, stack: [usize; MAX_FRAMES] }
const EMPTY: Event = Event { bytes: 0, operation: 0, thread: 0, frames: 0, stack: [0; MAX_FRAMES] };
struct Buffer(UnsafeCell<[Event; MAX_EVENTS]>);
// Each successful atomic index owns a disjoint element; reading waits for all
// active recorders after disabling the window. No shared mutable references.
unsafe impl Sync for Buffer {}
static EVENTS: Buffer = Buffer(UnsafeCell::new([EMPTY; MAX_EVENTS]));
static ENABLED: AtomicBool = AtomicBool::new(false);
static NEXT: AtomicUsize = AtomicUsize::new(0);
static ACTIVE: AtomicUsize = AtomicUsize::new(0);
static ROOT_THREAD: AtomicUsize = AtomicUsize::new(0);
static REENTRANT: AtomicUsize = AtomicUsize::new(0);
thread_local! { static RECORDING: Cell<bool> = const { Cell::new(false) }; }
unsafe extern "C" {
    fn backtrace(buffer: *mut *mut c_void, size: i32) -> i32;
    fn pthread_self() -> *mut c_void;
    fn _dyld_get_image_header(index: u32) -> *const c_void;
}
pub struct Tracked;
unsafe impl GlobalAlloc for Tracked {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let result = unsafe { System.alloc(layout) };
        if !result.is_null() { record(layout.size(), 1); }
        result
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let result = unsafe { System.alloc_zeroed(layout) };
        if !result.is_null() { record(layout.size(), 2); }
        result
    }
    unsafe fn realloc(&self, ptr: *mut u8, old: Layout, bytes: usize) -> *mut u8 {
        let result = unsafe { System.realloc(ptr, old, bytes) };
        if !result.is_null() { record(bytes, 3); }
        result
    }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) { unsafe { System.dealloc(ptr, layout) } }
}
#[inline(never)]
fn record(bytes: usize, operation: u8) {
    if !ENABLED.load(Ordering::Acquire) { return; }
    RECORDING.with(|recording| {
        if recording.replace(true) { REENTRANT.fetch_add(1, Ordering::Relaxed); return; }
        ACTIVE.fetch_add(1, Ordering::AcqRel);
        if ENABLED.load(Ordering::Acquire) {
            let index = NEXT.fetch_add(1, Ordering::Relaxed);
            if index < MAX_EVENTS {
                let mut stack = [std::ptr::null_mut(); MAX_FRAMES];
                let frames = unsafe { backtrace(stack.as_mut_ptr(), MAX_FRAMES as i32) }.max(0) as usize;
                let event = Event { bytes, operation, thread: unsafe { pthread_self() } as usize, frames,
                    stack: std::array::from_fn(|i| stack[i] as usize) };
                // SAFETY: unique index and the fixed buffer remains alive.
                unsafe { std::ptr::addr_of_mut!((*EVENTS.0.get())[index]).write(event); }
            }
        }
        ACTIVE.fetch_sub(1, Ordering::Release);
        recording.set(false);
    });
}
pub fn prewarm() {
    let mut stack = [std::ptr::null_mut(); MAX_FRAMES];
    unsafe { backtrace(stack.as_mut_ptr(), MAX_FRAMES as i32); }
}
pub fn begin() {
    assert_eq!(NEXT.load(Ordering::Relaxed), 0);
    ROOT_THREAD.store(unsafe { pthread_self() } as usize, Ordering::Relaxed);
    ENABLED.store(true, Ordering::Release);
}
pub fn stop_and_write(path: &std::ffi::OsStr) {
    ENABLED.store(false, Ordering::Release);
    while ACTIVE.load(Ordering::Acquire) != 0 { std::hint::spin_loop(); }
    let total = NEXT.load(Ordering::Acquire);
    let count = total.min(MAX_EVENTS);
    let mut file = std::io::BufWriter::new(std::fs::File::create(path).unwrap());
    writeln!(file, "{}", serde_json::json!({"schema":"mech.allocation-stack-profile.v1","diagnostic_only":true,"timings_excluded":true,"root_thread":ROOT_THREAD.load(Ordering::Relaxed),"image_load_address":unsafe{_dyld_get_image_header(0)} as usize,"recorded":count,"requests":total,"buffer_dropped":total-count,"reentrant_dropped":REENTRANT.load(Ordering::Relaxed),"max_frames":MAX_FRAMES,"window":"One continuous post-JSON interval through native input admission, setup, output allocation, invocation/internal cleanup and RelatedPosts materialization; excludes restoration, JSON IO and post-interval destruction."})).unwrap();
    for index in 0..count {
        // SAFETY: recorders have retired; no later window can begin.
        let event = unsafe { std::ptr::addr_of!((*EVENTS.0.get())[index]).read() };
        writeln!(file, "{}", serde_json::json!({"event":index,"bytes":event.bytes,"operation":event.operation,"thread":event.thread,"stack":&event.stack[..event.frames]})).unwrap();
    }
    file.flush().unwrap();
}
