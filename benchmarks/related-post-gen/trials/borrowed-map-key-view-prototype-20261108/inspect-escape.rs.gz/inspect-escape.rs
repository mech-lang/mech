use mech_engine::{CanonicalSourceFrontend, ProgramArtifact};
use mech_gpu::native_artifact::{NativeProgramLimitMode, emit_program_object_with_limits};
use mech_syntax::document::{
    AstNode, DocumentId, DocumentSyntax, ParseConfig, Revision, TextSnapshot,
    parse_canonical_document,
};
use std::path::Path;

fn compile(text: &str) -> ProgramArtifact {
    let parsed = parse_canonical_document(
        TextSnapshot::new(DocumentId(71), Revision(1), text).unwrap(),
        ParseConfig::default(),
    );
    assert!(
        parsed.is_strictly_clean(),
        "source must parse without recovery: {:?}",
        parsed.diagnostics
    );
    CanonicalSourceFrontend
        .compile_document_with_catalog(
            &DocumentSyntax::cast(parsed.syntax()).unwrap(),
            mech_stdlib::source_catalog(),
        )
        .unwrap()
        .compile_artifact()
        .unwrap()
}
fn main() {
 let source=std::fs::read_to_string(std::env::args().nth(1).unwrap()).unwrap();
 let artifact=compile(&source);
 println!("NODES={:#?}\nSCHEMAS={:#?}",artifact.nodes(),artifact.schemas());
 println!("BINDINGS={:#?}\nSLOTS={:#?}\nCONTRACTS={:#?}",artifact.bindings(),artifact.slots(),artifact.contracts());
 println!("LOWER={:?}",mech_engine::native_artifact::lower_native_program_artifact(&artifact,&mech_stdlib::source_catalog()));
}
