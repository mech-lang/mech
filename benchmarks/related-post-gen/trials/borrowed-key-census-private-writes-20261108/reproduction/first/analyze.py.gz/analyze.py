from pathlib import Path
import json,math,random,statistics as st
P=Path(__file__).parent;D=Path('/Users/cim310/mech-lang/mech/benchmarks/related-post-gen/results')
def read(p):return json.loads(Path(p).read_text())
rule=read(P/'prospective-rule.json');lat=read(D/rule['output_latency']);res=read(D/rule['output_resources'])
def quant(a,q):
 x=(len(a)-1)*q;i=math.floor(x);j=math.ceil(x);return a[i]+(a[j]-a[i])*(x-i)
def paired(candidate,baseline,field):
 data={n:{x['sample']:x[field]for x in lat['samples']if x['variant']==n}for n in [candidate,baseline]};assert all(set(d)==set(range(31))for d in data.values());delta=[data[candidate][i]/data[baseline][i]-1 for i in range(31)];rng=random.Random(rule['bootstrap']['seed']);boots=sorted(st.median(delta[rng.randrange(31)]for _ in range(31))for _ in range(rule['bootstrap']['resamples']));return dict(candidate=candidate,baseline=baseline,wins=sum(d<0 for d in delta),pairs=31,median_paired_relative_change=st.median(delta),two_sided_95_interval=[quant(boots,.025),quant(boots,.975)],all_pair_changes=delta)
med={}
for v in read(P/'latency-config.json')['implementations']:
 if v['kind']!='mech':continue
 n=v['name'];d=lat['summary'][n];med[n]={k:st.median(x[k]for x in lat['samples']if x['variant']==n)for k in ['post_json_seconds','wall_seconds','compile_or_restore_seconds']};med[n].update(times_fastest_processing_Rust=d['post_json_over_fastest_matched_native'],times_fastest_whole_Rust=d['whole_process_over_fastest'])
resources={};resource_names=read(P/'resources-config.json');ref_names={resource_names['resource_reference'],resource_names['whole_process_resource_reference']}
for v in resource_names['implementations']:
 if v['kind']!='mech' and v['name'] not in ref_names:continue
 rows=[x for x in res['samples']if x['variant']==v['name']];r={}
 for label,field in [('restore','restore_measurement'),('post_JSON','measurement')]:
  if not all(field in x for x in rows):continue
  r[label]={k:st.median(x[field][k]for x in rows)for k in ['allocation_requests','requested_allocation_bytes','peak_live_requested_heap_bytes','peak_additional_live_requested_heap_bytes']};r[label].update({k:st.median(x[field]['hardware'][k]for x in rows)for k in ['instructions_retired','cycles']})
 r['process_resources']=res['summary'][v['name']]['process_resources_median'];resources[v['name']]=r
assert all(x['exit']==0 and x['exact_rust_output']for x in lat['samples']+res['samples'])
pairs={}
for a,b in rule['attributable_pairs']+[[rule['candidate'],rule['selected_control']],[rule['matched_parent'],rule['selected_control']],[rule['loader_candidate'],rule['selected_control']]]:
 pairs[a+' vs '+b]={f:paired(a,b,f)for f in ['post_json_seconds','wall_seconds','compile_or_restore_seconds']}
out=dict(independent_confirmation=bool(rule.get('independent_confirmation')),all_first_and_adverse_samples_retained=True,latency_exact_outputs=len(lat['samples']),resource_exact_outputs=len(res['samples']),fastest_processing_Rust=lat['matched_native_reference'],fastest_whole_Rust=lat['whole_process_reference'],medians=med,resource_medians=resources,paired_comparisons=pairs,whole_process_gate=False,selected=False,goal_complete=False)
(P/'paired-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items()if k not in ['paired_comparisons','resource_medians']},indent=2));print('PAIRED',json.dumps({k:{a:{kk:vv for kk,vv in b.items()if kk!='all_pair_changes'}for a,b in v.items()}for k,v in pairs.items()},indent=2));print('RESOURCES',json.dumps({n:d.get('post_JSON')for n,d in resources.items()},indent=2))
