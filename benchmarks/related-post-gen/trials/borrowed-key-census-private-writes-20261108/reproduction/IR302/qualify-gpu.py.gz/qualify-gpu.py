from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,time
P=Path(__file__).parent;S=Path('/private/tmp/mech-related-private-write-first-compiler-20261108')
def read(p):return json.loads(Path(p).read_text())
def run(cmd,name):
 cmd=list(map(str,cmd));t=time.monotonic();r=subprocess.run(cmd,cwd=S,capture_output=True,text=True)
 (P/(name+'.json')).write_text(json.dumps(dict(command=cmd,exit=r.returncode,seconds=time.monotonic()-t,stdout=r.stdout,stderr=r.stderr),indent=2)+'\n');print(name,r.returncode,flush=True);assert r.returncode==0,r.stdout[-6000:]+r.stderr[-6000:];return r
spec=importlib.util.spec_from_file_location('b','/Users/cim310/mech-lang/mech/benchmarks/related-post-gen/build-compiler.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
files=m.source_inventory(S);assert files==read(P/'test-source-inventory-v1.json')['files']
assert '9 passed' in read(P/'proof-contracts.json')['stdout']
assert '1 passed' in read(P/'actual-full-input-path.json')['stdout']
workflow=(S/'.github/workflows/ci-full.yml').read_text().split('- name: Inventory and execute native composition contracts',1)[1].split('- name:',1)[0]
selection=workflow.split('--lib --',1)[1].split('--list',1)[0].replace('\\',' ').split()
listed=run([P/'gpu-tests',*selection,'--list'],'ci-list');names={x.removesuffix(': test') for x in listed.stdout.splitlines()if x.endswith(': test')}
old=read('/private/tmp/mech-related-closed-composite-constructors-tests-20261108-v2/ci-list.json')['stdout'];oldnames={x.removesuffix(': test')for x in old.splitlines()if x.endswith(': test')}
assert len(oldnames)==438 and oldnames<=names
assert len(names)==446,len(names)
executed=run([P/'gpu-tests',*selection,'--test-threads=1'],'ci-execute');passed={x.removeprefix('test ').removesuffix(' ... ok')for x in executed.stdout.splitlines()if x.startswith('test ')and x.endswith(' ... ok')}
assert names==passed,(names-passed,passed-names)
(P/'ci-inventory-audit.json').write_text(json.dumps(dict(expected=len(names),listed=len(names),executed_passed=len(passed),all_names_match=True,all438parent_names_retained=True,new_names=sorted(names-oldnames)),indent=2)+'\n')
run([P/'gpu-tests','program::runtime::maps::','--test-threads=1'],'all-retained-map-contracts')
run([P/'gpu-tests','program::image::','caller_geometry::tests','--test-threads=1'],'image-and-caller-geometry-tests')
run([P/'gpu-tests','native_string_classes','unsigned_guard_facts::','modular_ranges','codegen::utf8_lookup::','codegen::utf8_histogram::','compiled_histogram_tests','--test-threads=1'],'classification-UTF8-and-range-regressions')
assert files==m.source_inventory(S)
(P/'test-source-inventory.json').write_text((P/'test-source-inventory-v1.json').read_text())
(P/'summary.json').write_text(json.dumps(dict(actual_CI_passed=len(passed),all438parent_names_retained=True,focused_contracts_passed=9,full_input_28_borrowed_zero_StringValues=True,actual_original_and_restored_outputs_exact=True,all_retained_map_image_caller_and_classification_contracts_passed=True,source_inventory_unchanged=True),indent=2)+'\n')
print('GPU qualification complete',flush=True)
