from pathlib import Path
import datetime,hashlib,importlib.util,json,os,re,shutil,subprocess,time
P=Path(__file__).parent;R=Path('/Users/cim310/mech-lang/mech/benchmarks/related-post-gen');D=R/'results'
def read(p):return json.loads(Path(p).read_text())
def write(p,d):Path(p).write_text(json.dumps(d,indent=2)+'\n')
rule=read(P/'prospective-rule.json')
spec=importlib.util.spec_from_file_location('h',R/'build-compiler.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
records=[]
for version,stem,ci in [(300,'checked-key-proof-loading',445),(301,'borrowed-key-caller-census',446),(302,'private-write-first',446)]:
 S=Path('/private/tmp/mech-related-'+stem+'-compiler-20261108');O=Path('/private/tmp/mech-related-'+stem+'-opt-20261108-v1');T=Path('/private/tmp/mech-related-'+stem+'-20261108');N=Path('/private/tmp/mech-related-'+stem+'-runners-20261108-v1')
 files=h.source_inventory(S);assert files==read(O/'source-inventory.json')['files']==read(T/'test-source-inventory.json')['files']==read(N/'runtime/source-inventory.json')['files']
 assert read(T/'summary.json')['actual_CI_passed']==ci
 for name in ['all-retained-map-contracts','image-and-caller-geometry-tests','classification-UTF8-and-range-regressions','actual-full-input-path','actual-source-proof','proof-contracts']:assert read(T/(name+'.json'))['exit']==0
 assert read(T/'control-parent-parity.json')['all_nontiming_fields_exact']
 assert read(N/'histogram-reuse/summary.json')['exact_outputs']==32
 assert not subprocess.check_output(['git','-C',str(S),'status','--porcelain'],text=True).strip()
 commit=subprocess.check_output(['git','-C',str(S),'rev-parse','HEAD'],text=True).strip();assert commit==rule['compiler_commits'][str(version)]
 records.append(dict(typed_IR=version,source=str(S),compiler_commit=commit,source_inventory_sha256=read(O/'source-inventory.json')['sha256'],every_RS_and_Cargo_manifest_matches=True,all_qualification_passed=True))
for f,n in [('latency-config.json',28),('resources-config.json',29)]:
 c=read(P/f);assert len(c['implementations'])==n
 for v in c['implementations']:assert Path(v['executable']).is_file() and os.access(v['executable'],os.X_OK)
for k in ['output_latency','output_resources']:assert not(D/rule[k]).exists(),'Cohort overwrite rejected'
write(P/'source-freeze.json',dict(compilers=records,qualification_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),rule_sha256=hashlib.sha256((P/'prospective-rule.json').read_bytes()).hexdigest()))
def quiet(label):
 assert shutil.disk_usage(P).free>=1024**3,'Need1GiBfree;deduplicated cohort payload is below100MiB'
 snap=subprocess.check_output(['ps','-axo','pid,ppid,etime,pcpu,command'],text=True);busy=[]
 for line in snap.splitlines()[1:]:
  a=line.split(None,4)
  if len(a)!=5 or int(a[0])in[os.getpid(),os.getppid()]:continue
  command=Path(a[4].split()[0]).name
  if re.fullmatch(r'rustc|cargo|clang|clang\+\+|llc|opt|sample|gzip|xz|zstd|(?:gpu|engine|mech_core|mech_engine)-tests|one-kib|scalar|runner-(?:aot|metrics|profile|pc|trace|phases)',command):busy.append(a[:2]+[a[4].split()[0]])
 assert not busy,busy
 write(P/(label+'-quiet.json'),dict(quiet=True,process_snapshot_sha256=hashlib.sha256(snap.encode()).hexdigest(),no_build_test_profile_archive_overlapped=True))
def run(cmd,label):
 cmd=list(map(str,cmd));t=time.monotonic();r=subprocess.run(cmd,capture_output=True,text=True);write(P/(label+'.json'),dict(command=cmd,exit=r.returncode,seconds=time.monotonic()-t,stdout=r.stdout,stderr=r.stderr));print(label,r.returncode,flush=True);assert r.returncode==0,r.stdout[-2500:]+r.stderr[-2500:]
quiet('latency')
run(['python3',R/'compare-implementations.py','--config',P/'latency-config.json','--input','/private/tmp/mech-related-current-input-fixtures-20261107/posts.json','--samples','31','--order','randomized','--seed',str(rule['seed']),'--deduplicate-outputs','--work',P/'latency','--output',D/rule['output_latency']],'latency-run')
lat=read(D/rule['output_latency']);res=read(P/'resources-config.json');inst=lambda n:'rust-standard-instrumented'if n=='rust'else n+'-instrumented';res['resource_reference']=inst(lat['matched_native_reference']['variant']);res['whole_process_resource_reference']=inst(lat['whole_process_reference']['variant']);write(P/'resources-config.json',res)
quiet('resources')
run(['python3',R/'compare-implementations.py','--config',P/'resources-config.json','--input','/private/tmp/mech-related-current-input-fixtures-20261107/posts.json','--samples','7','--order','randomized','--seed',str(rule['resource_seed']),'--deduplicate-outputs','--resources','--work',P/'resources','--output',D/rule['output_resources']],'resources-run')
for x in records:assert h.source_inventory(Path(x['source']))==read(Path('/private/tmp/mech-related-'+{300:'checked-key-proof-loading',301:'borrowed-key-caller-census',302:'private-write-first'}[x['typed_IR']]+'-opt-20261108-v1')/'source-inventory.json')['files']
print('Cohorts complete;no promotion decision yet',flush=True)
