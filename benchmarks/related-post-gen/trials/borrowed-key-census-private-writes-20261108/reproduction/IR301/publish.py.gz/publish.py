from pathlib import Path
import gzip,hashlib,json,subprocess,datetime
P=Path(__file__).parent;C=Path('/private/tmp/mech-related-borrowed-key-caller-census-confirmation-20261108');R=Path('/Users/cim310/mech-lang/mech/benchmarks/related-post-gen');D=R/'results';S=Path('/private/tmp/mech-related-private-write-first-compiler-20261108');DEST=S/'benchmarks/related-post-gen/trials/borrowed-key-census-private-writes-20261108'
read=lambda p:json.loads(Path(p).read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
def put(name,b):
 p=DEST/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(b,mtime=0)if name.endswith('.gz')else b)
def cp(p,name):put(name,Path(p).read_bytes())
rule=read(P/'prospective-rule.json');versions=[(300,'checked-key-proof-loading'),(301,'borrowed-key-caller-census'),(302,'private-write-first')];source_blobs=set();binaries={}
for version,stem in versions:
 source=Path('/private/tmp/mech-related-'+stem+'-compiler-20261108');O=Path('/private/tmp/mech-related-'+stem+'-opt-20261108-v1');T=Path('/private/tmp/mech-related-'+stem+'-20261108');N=Path('/private/tmp/mech-related-'+stem+'-runners-20261108-v1');Q=Path('/private/tmp/mech-related-'+stem+'-regressions-20261108-v1')
 assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==rule['compiler_commits'][str(version)]
 I=read(O/'source-inventory.json');assert I['files']==read(T/'test-source-inventory.json')['files']==read(N/'runtime/source-inventory.json')['files']
 for name,h in I['files'].items():
  b=(source/name).read_bytes();assert sha(b)==h
  if h not in source_blobs:put('compiler-source/blobs/'+h+'.gz',b);source_blobs.add(h)
 cp(O/'source-inventory.json',f'compiler-source/IR{version}-inventory.json.gz')
 for p in O.glob('*.json'):cp(p,f'compiler/IR{version}/'+p.name+'.gz')
 for p in T.glob('*.json'):cp(p,f'qualification/IR{version}/'+p.name+'.gz')
 for p in T.glob('*.py'):cp(p,f'reproduction/IR{version}/'+p.name+'.gz')
 for p in T.glob('native-profile*'):
  if p.is_file():cp(p,f'diagnostics/IR{version}/'+p.name+'.gz')
 for p in T.glob('profile-host*.json'):cp(p,f'diagnostics/IR{version}/'+p.name+'.gz')
 for p in (N/'runtime/failed-enospc').glob('*.json'):cp(p,f'qualification/IR{version}/failed-runtime-build/'+p.name+'.gz')
 for p in Q.rglob('*.json'):cp(p,f'qualification/IR{version}/scalar-DEFLATE/'+str(p.relative_to(Q))+'.gz')
 cp(Q/'run.py',f'reproduction/IR{version}/scalar-DEFLATE.py.gz')
 for p in (N/'histogram-reuse').rglob('*'):
  if p.is_file()and p.suffix in ['.json','.mec','.mecb','.rs','.o','.bin']:cp(p,f'native/IR{version}/'+str(p.relative_to(N/'histogram-reuse'))+'.gz')
 for name in ['runtime-build.json','build.json','source-inventory.json']:cp(N/'runtime'/name,f'native/IR{version}/runtime/'+name+'.gz')
 cp(N/'build-and-qualify.py',f'reproduction/IR{version}/build-and-qualify.py.gz')
 n=N/'histogram-reuse';m=read(n/'build/metadata.json');binaries[str(version)]=dict(code_bytes=m['code_bytes'],stack_bytes=m['stack_bytes'],native_functions=len(m['compiled_numeric_functions']),object_bytes=(n/'build/object.o').stat().st_size,executable_bytes=(n/'runner-aot').stat().st_size,native_metadata_bytes=(n/'build/native-metadata.bin').stat().st_size,source_sha256=sha((n/'build/source.mec').read_bytes()))
for root,label in [(P,'first'),(C,'confirmation')]:
 for p in root.glob('*.json'):cp(p,'experiment/'+label+'/'+p.name+'.gz')
 for p in root.glob('*.py'):cp(p,'reproduction/'+label+'/'+p.name+'.gz')
for metrics in ['metrics','metrics-private-write']:
 for p in (P/metrics).rglob('*'):
  if p.is_file()and p.suffix in ['.json','.rs']:cp(p,'metrics/'+metrics+'/'+str(p.relative_to(P/metrics))+'.gz')
rows=[];seen=set()
for root,label in [(P,'first'),(C,'confirmation')]:
 r=read(root/'prospective-rule.json')
 for boundary,key in [('latency','output_latency'),('resources','output_resources')]:
  f=D/r[key];cp(f,'cohorts/'+f.name+'.gz');d=read(f)
  for x in d['samples']:
   assert x['exit']==0 and x['exact_rust_output'];h=x['output_sha256'];rows.append(dict(cohort=label,boundary=boundary,sample=x['sample'],variant=x['variant'],sha256=h))
   if h not in seen:
    f=root/boundary/(x['variant']+'-'+str(x['sample'])+'.json');b=f.read_bytes();assert sha(b)==h;put('outputs/'+h+'.json.gz',b);seen.add(h)
assert len(rows)==2142
put('outputs/manifest.json',(json.dumps(dict(outputs=rows,count=len(rows),all_exact=True),indent=2)+'\n').encode())
commit=rule['compiler_commits']['302'];put('compiler-change.patch.gz',subprocess.check_output(['git','-C',str(S),'diff','31c4b5549a1e6e5714ebac928f6abdaf03a36fe4',commit,'--','.github/workflows/ci-full.yml','hosts/gpu']))
a,b=read(P/'paired-analysis.json'),read(C/'paired-analysis.json');decisions=read(P/'decisions.json')
report=dict(schema='mech.related-post-gen.borrowed-key-census-private-writes.v1',updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),compiler_commits=rule['compiler_commits'],branch='codex/related-private-write-first-20261108',identities={'300':'IR300/work118/ABI41/image11','301':'IR301/work119/ABI41/image11','302':'IR302/work119/ABI41/image11'},backend='Cranelift',source_algorithm_unchanged=True,whole_process_gate=False,goal_complete=False,first=a,confirmation=b,binaries=binaries,decisions=decisions,next=['Stage B: borrow canonical-order Map keys through length/selected reads and existing private parameter frame; pin original immutable Map independently of its retired handle.','Stage C: retain generic UTF8 nonempty seed and dictionary through lookup; distinguish immutable keyset and current value generation.','Separately derive applicability for completed-producer element-range facts into posting scatter.'])
(D/'native-borrowed-key-census-private-writes-current-20261108.json').write_text(json.dumps(report,indent=2)+'\n');put('current-report.json',(json.dumps(report,indent=2)+'\n').encode())
cp(P/'README.txt','README.md')
manifest={str(f.relative_to(DEST)):sha(f.read_bytes())for f in DEST.rglob('*')if f.is_file()and f.name!='manifest.json'};put('manifest.json',(json.dumps(dict(schema='mech.related-post-gen.retained-experiment.v1',compiler_source_commits=rule['compiler_commits'],payloads=manifest),indent=2)+'\n').encode());assert all(sha((DEST/f).read_bytes())==h for f,h in manifest.items())
print(json.dumps(dict(packet=str(DEST),payloads=len(manifest),outputs=len(rows),source_commits=rule['compiler_commits'],verified=True)))
