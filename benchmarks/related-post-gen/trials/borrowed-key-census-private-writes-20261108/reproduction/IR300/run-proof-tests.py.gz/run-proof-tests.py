from pathlib import Path
import json,os,subprocess,time
P=Path(__file__).parent
S=Path('/private/tmp/mech-related-checked-key-proof-loading-compiler-20261108')
O=Path('/private/tmp/mech-related-closed-composite-constructors-opt-20261108-v2')
build=json.loads((O/'build.json').read_text());stage=next(x for x in build['stages'] if x['crate']=='mech_gpu')
old=build['source'];cmd=[x.replace(old,str(S)) for x in stage['command']];cmd[cmd.index('--crate-type=rlib')]='--test';cmd[-1]=str(P/'gpu-tests')
for i,a in enumerate(cmd):
 if a.startswith('metadata='):cmd[i]=a+'_matrix_map_keys_proof_v1'
def run(command,name,env):
 t=time.monotonic();r=subprocess.run(command,cwd=S,env={**os.environ,**env},capture_output=True,text=True);(P/(name+'.json')).write_text(json.dumps(dict(command=command,environment=env,exit=r.returncode,seconds=time.monotonic()-t,stdout=r.stdout,stderr=r.stderr),indent=2)+'\n');print(name,r.returncode,flush=True);print((r.stdout+r.stderr)[-8000:],flush=True);assert r.returncode==0
check=cmd.copy();check[-1]=str(P/'gpu-test-check.rmeta');check+=['--emit=metadata']
run(check,'proof-test-check',{k:v.replace(old,str(S)) for k,v in stage['environment'].items()})
run(cmd,'proof-test-build',{k:v.replace(old,str(S)) for k,v in stage['environment'].items()})
run([str(P/'gpu-tests'),'matrix_map_keys','--test-threads=1','--nocapture'],'proof-contracts',{})
run([str(P/'gpu-tests'),'matrix_map_keys_selects_actual','--ignored','--test-threads=1','--nocapture'],'actual-source-proof',{'MECH_MATRIX_KEY_BENCH_SOURCE':'/private/tmp/mech-related-native-string-classification-reuse-runners-20261108-v2/histogram-reuse/build/source.mec'})

run([str(P/'gpu-tests'),'matrix_map_keys_full_input','--ignored','--test-threads=1','--nocapture'],'actual-full-input-path',{'MECH_MATRIX_KEY_BENCH_SOURCE':'/private/tmp/mech-related-native-string-classification-reuse-runners-20261108-v2/histogram-reuse/build/source.mec','MECH_MATRIX_KEY_BENCH_INPUT':'/private/tmp/mech-related-current-input-fixtures-20261107/posts.json','MECH_MATRIX_KEY_BENCH_ORACLE':'/private/tmp/mech-related-frozen-native-composition-latency-20261105-v1/related_posts_rust.json'})
