
/private/tmp/mech-related-invariant-capture-hoisting-runners-20261107-v2/reuse-4/build/object.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000000001db00 <_mech_canonical_program_entry_v1_numeric_1282>:
   1db00:      	pacibsp
   1db04:      	stp	x29, x30, [sp, #-0x10]!
   1db08:      	mov	x29, sp
   1db0c:      	stp	x27, x28, [sp, #-0x10]!
   1db10:      	stp	x25, x26, [sp, #-0x10]!
   1db14:      	stp	x23, x24, [sp, #-0x10]!
   1db18:      	stp	x21, x22, [sp, #-0x10]!
   1db1c:      	stp	x19, x20, [sp, #-0x10]!
   1db20:      	sub	sp, sp, #0x1c0
   1db24:      	mov	x19, x1
   1db28:      	stur	x2, [sp, #0x8]
   1db2c:      	ldr	x21, [x0, #0x50]
   1db30:      	str	x21, [sp, #0x1a8]
   1db34:      	ldr	x6, [x0, #0x58]
   1db38:      	ldr	x1, [x0, #0x60]
   1db3c:      	ldr	x14, [x0, #0x68]
   1db40:      	stur	x0, [sp]
   1db44:      	str	x14, [sp, #0x190]
   1db48:      	mov	x0, #0x3                ; =3
   1db4c:      	cmp	x21, #0x0
   1db50:      	b.eq	0x22520 <_mech_canonical_program_entry_v1_numeric_1282+0x4a20>
   1db54:      	mov	x0, #0x3                ; =3
   1db58:      	cmp	x6, #0x0
   1db5c:      	str	x6, [sp, #0x1a0]
   1db60:      	b.eq	0x22528 <_mech_canonical_program_entry_v1_numeric_1282+0x4a28>
   1db64:      	mov	x0, #0x3                ; =3
   1db68:      	mov	x21, x0
   1db6c:      	cmp	x1, #0x0
   1db70:      	b.eq	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1db74:      	mov	x0, x19
   1db78:      	ldr	x23, [x0, #0x4c60]
   1db7c:      	cmp	x23, #0x0
   1db80:      	mov	x26, x23
   1db84:      	b.eq	0x1dff4 <_mech_canonical_program_entry_v1_numeric_1282+0x4f4>
   1db88:      	ldr	x25, [x1, #0x10]
   1db8c:      	ldr	x3, [x0, #0x4c68]
   1db90:      	ldr	x4, [x0, #0x4c70]
   1db94:      	mov	x19, x0
   1db98:      	stur	x4, [sp, #0x98]
   1db9c:      	ldr	x22, [x25, #0xf60]
   1dba0:      	ldr	x23, [x25, #0xf70]
   1dba4:      	ldr	x20, [x1, #0xab8]
   1dba8:      	ldr	x14, [x1, #0xac0]
   1dbac:      	stur	x14, [sp, #0x60]
   1dbb0:      	ldr	x0, [x1, #0xac8]
   1dbb4:      	ldr	x0, [x1, #0xad0]
   1dbb8:      	ldr	x28, [x1, #0xad8]
   1dbbc:      	str	x28, [sp, #0x188]
   1dbc0:      	ldr	x28, [x1, #0xae0]
   1dbc4:      	str	x28, [sp, #0x180]
   1dbc8:      	ldr	x0, [x1, #0xae8]
   1dbcc:      	ldr	x0, [x1, #0xaf0]
   1dbd0:      	ldr	x28, [x1, #0xaf8]
   1dbd4:      	str	x28, [sp, #0x178]
   1dbd8:      	ldr	x28, [x1, #0xb00]
   1dbdc:      	str	x28, [sp, #0x170]
   1dbe0:      	ldr	x0, [x1, #0xb08]
   1dbe4:      	ldr	x0, [x1, #0xb10]
   1dbe8:      	ldr	x28, [x1, #0xb18]
   1dbec:      	str	x28, [sp, #0x168]
   1dbf0:      	ldr	x28, [x1, #0xb20]
   1dbf4:      	str	x28, [sp, #0x160]
   1dbf8:      	ldr	x0, [x1, #0xb28]
   1dbfc:      	ldr	x0, [x1, #0xb30]
   1dc00:      	ldr	x28, [x1, #0xb38]
   1dc04:      	str	x28, [sp, #0x158]
   1dc08:      	ldr	x28, [x1, #0xb40]
   1dc0c:      	str	x28, [sp, #0x150]
   1dc10:      	ldr	x0, [x1, #0xb48]
   1dc14:      	ldr	x0, [x1, #0xb50]
   1dc18:      	ldr	x28, [x1, #0xb58]
   1dc1c:      	str	x28, [sp, #0x148]
   1dc20:      	ldr	x28, [x1, #0xb60]
   1dc24:      	str	x28, [sp, #0x140]
   1dc28:      	ldr	x0, [x1, #0xb68]
   1dc2c:      	ldr	x0, [x1, #0xb70]
   1dc30:      	ldr	x28, [x1, #0xb78]
   1dc34:      	str	x28, [sp, #0x138]
   1dc38:      	ldr	x28, [x1, #0xb80]
   1dc3c:      	str	x28, [sp, #0x130]
   1dc40:      	ldr	x0, [x1, #0xb88]
   1dc44:      	ldr	x0, [x1, #0xb90]
   1dc48:      	ldr	x28, [x1, #0xb98]
   1dc4c:      	str	x28, [sp, #0x128]
   1dc50:      	ldr	x28, [x1, #0xba0]
   1dc54:      	str	x28, [sp, #0x120]
   1dc58:      	ldr	x0, [x1, #0xba8]
   1dc5c:      	ldr	x0, [x1, #0xbb0]
   1dc60:      	ldr	x28, [x1, #0xbb8]
   1dc64:      	str	x28, [sp, #0x118]
   1dc68:      	ldr	x28, [x1, #0xbc0]
   1dc6c:      	str	x28, [sp, #0x110]
   1dc70:      	ldr	x0, [x1, #0xbc8]
   1dc74:      	ldr	x0, [x1, #0xbd0]
   1dc78:      	ldr	x28, [x1, #0xbd8]
   1dc7c:      	str	x28, [sp, #0x108]
   1dc80:      	ldr	x0, [x1, #0xbe0]
   1dc84:      	str	x0, [sp, #0x100]
   1dc88:      	ldr	x0, [x1, #0xbe8]
   1dc8c:      	ldr	x0, [x1, #0xbf0]
   1dc90:      	ldr	x2, [x1, #0xc48]
   1dc94:      	stur	x2, [sp, #0xc8]
   1dc98:      	str	x1, [sp, #0x198]
   1dc9c:      	mov	x11, #0x0               ; =0
   1dca0:      	mov	x4, #0x1                ; =1
   1dca4:      	stur	x4, [sp, #0xa0]
   1dca8:      	mov	x5, x11
   1dcac:      	mov	x6, x11
   1dcb0:      	mov	x9, x11
   1dcb4:      	mov	x12, x11
   1dcb8:      	mov	x13, x11
   1dcbc:      	mov	x15, x11
   1dcc0:      	mov	x21, x11
   1dcc4:      	mov	x24, x11
   1dcc8:      	stur	x3, [sp, #0x90]
   1dccc:      	stur	x11, [sp, #0xb8]
   1dcd0:      	stur	x11, [sp, #0xc0]
   1dcd4:      	mov	w0, #0xc87e             ; =51326
   1dcd8:      	movk	w0, #0x1, lsl #16
   1dcdc:      	cmp	x3, x0
   1dce0:      	cset	x4, hs
   1dce4:      	ldur	x1, [sp, #0xc8]
   1dce8:      	ldur	x14, [sp, #0x60]
   1dcec:      	cmp	x14, x1
   1dcf0:      	cset	x7, ls
   1dcf4:      	sub	x8, x1, x14
   1dcf8:      	cmp	x8, #0x4
   1dcfc:      	cset	x8, hi
   1dd00:      	and	w10, w7, w8
   1dd04:      	and	w4, w4, w10
   1dd08:      	stur	x10, [sp, #0xf8]
   1dd0c:      	uxtb	w4, w4
   1dd10:      	cbnz	x4, 0x1e01c <_mech_canonical_program_entry_v1_numeric_1282+0x51c>
   1dd14:      	mov	x7, #0x0                ; =0
   1dd18:      	str	x7, [x19, #0x18]
   1dd1c:      	mov	x8, #0x1000000000000000 ; =1152921504606846976
   1dd20:      	str	x8, [x19, #0x20]
   1dd24:      	mov	x10, #0x1               ; =1
   1dd28:      	str	x10, [x19, #0x30]
   1dd2c:      	mov	x8, #0x101010101010101  ; =72340172838076673
   1dd30:      	str	x8, [x19, #0x38]
   1dd34:      	mov	x14, #0x2               ; =2
   1dd38:      	str	x14, [x19, #0x40]
   1dd3c:      	mov	x14, #0x3               ; =3
   1dd40:      	str	x14, [x19, #0x48]
   1dd44:      	mov	x14, #0x4               ; =4
   1dd48:      	str	x14, [x19, #0x50]
   1dd4c:      	mov	x14, #0xf0f0f0f0f0f0f0f ; =1085102592571150095
   1dd50:      	str	x14, [x19, #0x78]
   1dd54:      	mov	x14, #0x3333333333333333 ; =3689348814741910323
   1dd58:      	str	x14, [x19, #0x88]
   1dd5c:      	mov	x14, #0x38              ; =56
   1dd60:      	str	x14, [x19, #0x90]
   1dd64:      	mov	x0, #0x3a               ; =58
   1dd68:      	str	x0, [x19, #0x98]
   1dd6c:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   1dd70:      	str	x0, [x19, #0xb0]
   1dd74:      	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
   1dd78:      	str	x0, [x19, #0xb8]
   1dd7c:      	str	x7, [x19, #0x188]
   1dd80:      	str	x10, [x19, #0x190]
   1dd84:      	mov	x0, x26
   1dd88:      	str	x0, [x19, #0x4c60]
   1dd8c:      	str	x3, [x19, #0x4c68]
   1dd90:      	ldur	x4, [sp, #0x98]
   1dd94:      	str	x4, [x19, #0x4c70]
   1dd98:      	str	x22, [x19, #0x4f70]
   1dd9c:      	str	x23, [x19, #0x4f78]
   1dda0:      	ldur	x14, [sp, #0x60]
   1dda4:      	str	x14, [x19, #0x5a20]
   1dda8:      	str	x11, [x19, #0x5bb0]
   1ddac:      	ldur	x0, [sp, #0xa0]
   1ddb0:      	str	x0, [x19, #0x5bb8]
   1ddb4:      	str	x5, [x19, #0x5bc0]
   1ddb8:      	ldur	x4, [sp, #0x90]
   1ddbc:      	sub	x0, x4, x3
   1ddc0:      	mov	w1, #0xc87e             ; =51326
   1ddc4:      	movk	w1, #0x1, lsl #16
   1ddc8:      	msub	x0, x11, x1, x0
   1ddcc:      	str	x0, [x19, #0x5bc8]
   1ddd0:      	str	x24, [x19, #0x5bd0]
   1ddd4:      	str	x15, [x19, #0x5bd8]
   1ddd8:      	str	x6, [x19, #0x5be8]
   1dddc:      	ldur	x4, [sp, #0xb8]
   1dde0:      	str	x4, [x19, #0x5bf0]
   1dde4:      	str	x12, [x19, #0x5c00]
   1dde8:      	str	x9, [x19, #0x5c08]
   1ddec:      	str	x13, [x19, #0x5c18]
   1ddf0:      	ldur	x13, [sp, #0xc0]
   1ddf4:      	str	x13, [x19, #0x5c20]
   1ddf8:      	ldr	x0, [x19, #0x4c60]
   1ddfc:      	cmp	x0, #0x0
   1de00:      	b.eq	0x1dff4 <_mech_canonical_program_entry_v1_numeric_1282+0x4f4>
   1de04:      	ldr	x3, [x19, #0x4c68]
   1de08:      	ldr	x4, [x19, #0x4c70]
   1de0c:      	mov	x0, #0x0                ; =0
   1de10:      	str	x0, [x19, #0x4c60]
   1de14:      	mov	x0, #0x3                ; =3
   1de18:      	ldr	x10, [sp, #0x190]
   1de1c:      	cmp	x10, #0x19a
   1de20:      	b.lo	0x22530 <_mech_canonical_program_entry_v1_numeric_1282+0x4a30>
   1de24:      	ldr	x0, [x19, #0x4f70]
   1de28:      	ldr	x14, [sp, #0x198]
   1de2c:      	str	x0, [x14, #0x10]
   1de30:      	ldr	x1, [x19, #0x4f78]
   1de34:      	str	x1, [x14, #0x18]
   1de38:      	ldr	x2, [x19, #0x5a20]
   1de3c:      	str	x2, [x14, #0xac0]
   1de40:      	str	x0, [x14, #0x10]
   1de44:      	str	x1, [x14, #0x18]
   1de48:      	ldr	x0, [x19, #0x50c0]
   1de4c:      	str	x0, [x14, #0x160]
   1de50:      	ldr	x0, [x19, #0x50c8]
   1de54:      	str	x0, [x14, #0x168]
   1de58:      	ldr	x0, [x19, #0x50d0]
   1de5c:      	str	x0, [x14, #0x170]
   1de60:      	ldr	x0, [x19, #0x50d8]
   1de64:      	str	x0, [x14, #0x178]
   1de68:      	ldr	x0, [x19, #0x50e0]
   1de6c:      	str	x0, [x14, #0x180]
   1de70:      	ldr	x0, [x19, #0x50e8]
   1de74:      	str	x0, [x14, #0x188]
   1de78:      	ldr	x0, [x19, #0x50f0]
   1de7c:      	str	x0, [x14, #0x190]
   1de80:      	ldr	x0, [x19, #0x50f8]
   1de84:      	str	x0, [x14, #0x198]
   1de88:      	ldr	x0, [x19, #0x5100]
   1de8c:      	str	x0, [x14, #0x1a0]
   1de90:      	ldr	x0, [x19, #0x52a8]
   1de94:      	str	x0, [x14, #0x348]
   1de98:      	ldr	x0, [x19, #0x52b0]
   1de9c:      	str	x0, [x14, #0x350]
   1dea0:      	ldr	x0, [x19, #0x52b8]
   1dea4:      	str	x0, [x14, #0x358]
   1dea8:      	ldr	x0, [x19, #0x52c0]
   1deac:      	str	x0, [x14, #0x360]
   1deb0:      	ldr	x0, [x19, #0x52c8]
   1deb4:      	str	x0, [x14, #0x368]
   1deb8:      	ldr	x1, [x19, #0x52d0]
   1debc:      	str	x1, [x14, #0x370]
   1dec0:      	ldr	x2, [x19, #0x52d8]
   1dec4:      	str	x2, [x14, #0x378]
   1dec8:      	ldr	x5, [x19, #0x52e0]
   1decc:      	str	x5, [x14, #0x380]
   1ded0:      	ldr	x5, [x19, #0x52e8]
   1ded4:      	str	x5, [x14, #0x388]
   1ded8:      	ldr	x5, [x19, #0x55d8]
   1dedc:      	str	x5, [x14, #0x678]
   1dee0:      	ldr	x6, [x19, #0x55e0]
   1dee4:      	str	x6, [x14, #0x680]
   1dee8:      	ldr	x7, [x19, #0x55e8]
   1deec:      	str	x7, [x14, #0x688]
   1def0:      	ldr	x8, [x19, #0x55f0]
   1def4:      	str	x8, [x14, #0x690]
   1def8:      	ldr	x9, [x19, #0x55f8]
   1defc:      	str	x9, [x14, #0x698]
   1df00:      	ldr	x10, [x19, #0x5600]
   1df04:      	str	x10, [x14, #0x6a0]
   1df08:      	ldr	x11, [x19, #0x5608]
   1df0c:      	str	x11, [x14, #0x6a8]
   1df10:      	ldr	x12, [x19, #0x5610]
   1df14:      	str	x12, [x14, #0x6b0]
   1df18:      	ldr	x13, [x19, #0x57a0]
   1df1c:      	str	x13, [x14, #0x840]
   1df20:      	ldr	x15, [x19, #0x57a8]
   1df24:      	str	x15, [x14, #0x848]
   1df28:      	ldr	x15, [x19, #0x57b0]
   1df2c:      	str	x15, [x14, #0x850]
   1df30:      	ldr	x0, [x19, #0x57b8]
   1df34:      	str	x0, [x14, #0x858]
   1df38:      	ldr	x0, [x19, #0x57c0]
   1df3c:      	str	x0, [x14, #0x860]
   1df40:      	ldr	x0, [x19, #0x57c8]
   1df44:      	str	x0, [x14, #0x868]
   1df48:      	ldr	x0, [x19, #0x57d0]
   1df4c:      	str	x0, [x14, #0x870]
   1df50:      	ldr	x0, [x19, #0x57d8]
   1df54:      	str	x0, [x14, #0x878]
   1df58:      	ldr	x0, [x19, #0x5bb0]
   1df5c:      	str	x0, [x14, #0xc50]
   1df60:      	ldr	x0, [x19, #0x5bb8]
   1df64:      	str	x0, [x14, #0xc58]
   1df68:      	ldr	x0, [x19, #0x5bc0]
   1df6c:      	str	x0, [x14, #0xc60]
   1df70:      	ldr	x0, [x19, #0x5bc8]
   1df74:      	str	x0, [x14, #0xc68]
   1df78:      	ldr	x0, [x19, #0x5bd0]
   1df7c:      	str	x0, [x14, #0xc70]
   1df80:      	ldr	x0, [x19, #0x5bd8]
   1df84:      	str	x0, [x14, #0xc78]
   1df88:      	mov	x0, #0x0                ; =0
   1df8c:      	str	x0, [x14, #0xc80]
   1df90:      	ldr	x1, [x19, #0x5be8]
   1df94:      	str	x1, [x14, #0xc88]
   1df98:      	ldr	x1, [x19, #0x5bf0]
   1df9c:      	str	x1, [x14, #0xc90]
   1dfa0:      	str	x0, [x14, #0xc98]
   1dfa4:      	ldr	x1, [x19, #0x5c00]
   1dfa8:      	str	x1, [x14, #0xca0]
   1dfac:      	ldr	x1, [x19, #0x5c08]
   1dfb0:      	str	x1, [x14, #0xca8]
   1dfb4:      	str	x0, [x14, #0xcb0]
   1dfb8:      	ldr	x0, [x19, #0x5c18]
   1dfbc:      	str	x0, [x14, #0xcb8]
   1dfc0:      	ldr	x0, [x19, #0x5c20]
   1dfc4:      	str	x0, [x14, #0xcc0]
   1dfc8:      	mov	x1, #0x502              ; =1282
   1dfcc:      	mov	x2, #-0x9               ; =-9
   1dfd0:      	mov	x5, #0x1                ; =1
   1dfd4:      	ldur	x0, [sp, #0x8]
   1dfd8:      	ldr	x6, [sp, #0x1a0]
   1dfdc:      	ldr	x21, [sp, #0x1a8]
   1dfe0:      	blr	x21
   1dfe4:      	mov	x15, x0
   1dfe8:      	mov	x0, #0x2                ; =2
   1dfec:      	cmp	x15, #0x0
   1dff0:      	b.ne	0x22538 <_mech_canonical_program_entry_v1_numeric_1282+0x4a38>
   1dff4:      	mov	x1, #0x0                ; =0
   1dff8:      	mov	x0, x1
   1dffc:      	add	sp, sp, #0x1c0
   1e000:      	ldp	x19, x20, [sp], #0x10
   1e004:      	ldp	x21, x22, [sp], #0x10
   1e008:      	ldp	x23, x24, [sp], #0x10
   1e00c:      	ldp	x25, x26, [sp], #0x10
   1e010:      	ldp	x27, x28, [sp], #0x10
   1e014:      	ldp	x29, x30, [sp], #0x10
   1e018:      	retab
   1e01c:      	ldur	x4, [sp, #0x98]
   1e020:      	ldr	x10, [sp, #0x190]
   1e024:      	ldr	x14, [sp, #0x198]
   1e028:      	stur	x5, [sp, #0xa8]
   1e02c:      	cmp	x22, x23
   1e030:      	cset	x0, lo
   1e034:      	cmp	x22, x23
   1e038:      	b.lo	0x1e084 <_mech_canonical_program_entry_v1_numeric_1282+0x584>
   1e03c:      	mov	x0, #0x0                ; =0
   1e040:      	stur	x0, [sp, #0x10]
   1e044:      	mov	w0, #0xc87e             ; =51326
   1e048:      	movk	w0, #0x1, lsl #16
   1e04c:      	sub	x3, x3, x0
   1e050:      	mov	x27, x22
   1e054:      	mov	x28, x26
   1e058:      	ldur	x0, [sp, #0x10]
   1e05c:      	stur	x0, [sp, #0x68]
   1e060:      	stur	x0, [sp, #0x70]
   1e064:      	stur	x0, [sp, #0x78]
   1e068:      	stur	x0, [sp, #0x80]
   1e06c:      	stur	x22, [sp, #0x88]
   1e070:      	stur	x4, [sp, #0x98]
   1e074:      	stur	x6, [sp, #0xb0]
   1e078:      	str	x10, [sp, #0x190]
   1e07c:      	str	x14, [sp, #0x198]
   1e080:      	b	0x21a68 <_mech_canonical_program_entry_v1_numeric_1282+0x3f68>
   1e084:      	ldr	x1, [sp, #0x180]
   1e088:      	cmp	x22, x1
   1e08c:      	b.lo	0x1e2dc <_mech_canonical_program_entry_v1_numeric_1282+0x7dc>
   1e090:      	b	0x22540 <_mech_canonical_program_entry_v1_numeric_1282+0x4a40>
   1e094:      	str	x10, [sp, #0x190]
   1e098:      	str	x14, [sp, #0x198]
   1e09c:      	b	0x1e288 <_mech_canonical_program_entry_v1_numeric_1282+0x788>
   1e0a0:      	ldr	x3, [x19, #0x4c68]
   1e0a4:      	ldr	x4, [x19, #0x4c70]
   1e0a8:      	mov	x0, #0x0                ; =0
   1e0ac:      	str	x0, [x19, #0x4c60]
   1e0b0:      	mov	x0, #0x3                ; =3
   1e0b4:      	cmp	x10, #0x19a
   1e0b8:      	str	x10, [sp, #0x190]
   1e0bc:      	b.lo	0x22660 <_mech_canonical_program_entry_v1_numeric_1282+0x4b60>
   1e0c0:      	ldr	x0, [x19, #0x4f70]
   1e0c4:      	str	x0, [x14, #0x10]
   1e0c8:      	ldr	x1, [x19, #0x4f78]
   1e0cc:      	str	x1, [x14, #0x18]
   1e0d0:      	ldr	x2, [x19, #0x5a20]
   1e0d4:      	str	x2, [x14, #0xac0]
   1e0d8:      	str	x0, [x14, #0x10]
   1e0dc:      	str	x1, [x14, #0x18]
   1e0e0:      	ldr	x0, [x19, #0x50c0]
   1e0e4:      	str	x0, [x14, #0x160]
   1e0e8:      	ldr	x0, [x19, #0x50c8]
   1e0ec:      	str	x0, [x14, #0x168]
   1e0f0:      	ldr	x0, [x19, #0x50d0]
   1e0f4:      	str	x0, [x14, #0x170]
   1e0f8:      	ldr	x0, [x19, #0x50d8]
   1e0fc:      	str	x0, [x14, #0x178]
   1e100:      	ldr	x0, [x19, #0x50e0]
   1e104:      	str	x0, [x14, #0x180]
   1e108:      	ldr	x0, [x19, #0x50e8]
   1e10c:      	str	x0, [x14, #0x188]
   1e110:      	ldr	x0, [x19, #0x50f0]
   1e114:      	str	x0, [x14, #0x190]
   1e118:      	ldr	x0, [x19, #0x50f8]
   1e11c:      	str	x0, [x14, #0x198]
   1e120:      	ldr	x0, [x19, #0x5100]
   1e124:      	str	x0, [x14, #0x1a0]
   1e128:      	ldr	x0, [x19, #0x52a8]
   1e12c:      	str	x0, [x14, #0x348]
   1e130:      	ldr	x0, [x19, #0x52b0]
   1e134:      	str	x0, [x14, #0x350]
   1e138:      	ldr	x0, [x19, #0x52b8]
   1e13c:      	str	x0, [x14, #0x358]
   1e140:      	ldr	x0, [x19, #0x52c0]
   1e144:      	str	x0, [x14, #0x360]
   1e148:      	ldr	x0, [x19, #0x52c8]
   1e14c:      	str	x0, [x14, #0x368]
   1e150:      	ldr	x0, [x19, #0x52d0]
   1e154:      	str	x0, [x14, #0x370]
   1e158:      	ldr	x1, [x19, #0x52d8]
   1e15c:      	str	x1, [x14, #0x378]
   1e160:      	ldr	x2, [x19, #0x52e0]
   1e164:      	str	x2, [x14, #0x380]
   1e168:      	ldr	x5, [x19, #0x52e8]
   1e16c:      	str	x5, [x14, #0x388]
   1e170:      	ldr	x5, [x19, #0x55d8]
   1e174:      	str	x5, [x14, #0x678]
   1e178:      	ldr	x5, [x19, #0x55e0]
   1e17c:      	str	x5, [x14, #0x680]
   1e180:      	ldr	x6, [x19, #0x55e8]
   1e184:      	str	x6, [x14, #0x688]
   1e188:      	ldr	x7, [x19, #0x55f0]
   1e18c:      	str	x7, [x14, #0x690]
   1e190:      	ldr	x8, [x19, #0x55f8]
   1e194:      	str	x8, [x14, #0x698]
   1e198:      	ldr	x9, [x19, #0x5600]
   1e19c:      	str	x9, [x14, #0x6a0]
   1e1a0:      	ldr	x10, [x19, #0x5608]
   1e1a4:      	str	x10, [x14, #0x6a8]
   1e1a8:      	ldr	x11, [x19, #0x5610]
   1e1ac:      	str	x11, [x14, #0x6b0]
   1e1b0:      	ldr	x12, [x19, #0x57a0]
   1e1b4:      	str	x12, [x14, #0x840]
   1e1b8:      	ldr	x13, [x19, #0x57a8]
   1e1bc:      	str	x13, [x14, #0x848]
   1e1c0:      	ldr	x15, [x19, #0x57b0]
   1e1c4:      	str	x15, [x14, #0x850]
   1e1c8:      	ldr	x15, [x19, #0x57b8]
   1e1cc:      	str	x15, [x14, #0x858]
   1e1d0:      	ldr	x0, [x19, #0x57c0]
   1e1d4:      	str	x0, [x14, #0x860]
   1e1d8:      	ldr	x0, [x19, #0x57c8]
   1e1dc:      	str	x0, [x14, #0x868]
   1e1e0:      	ldr	x0, [x19, #0x57d0]
   1e1e4:      	str	x0, [x14, #0x870]
   1e1e8:      	ldr	x0, [x19, #0x57d8]
   1e1ec:      	str	x0, [x14, #0x878]
   1e1f0:      	ldr	x0, [x19, #0x5bb0]
   1e1f4:      	str	x0, [x14, #0xc50]
   1e1f8:      	ldr	x0, [x19, #0x5bb8]
   1e1fc:      	str	x0, [x14, #0xc58]
   1e200:      	ldr	x0, [x19, #0x5bc0]
   1e204:      	str	x0, [x14, #0xc60]
   1e208:      	ldr	x0, [x19, #0x5bc8]
   1e20c:      	str	x0, [x14, #0xc68]
   1e210:      	ldr	x0, [x19, #0x5bd0]
   1e214:      	str	x0, [x14, #0xc70]
   1e218:      	ldr	x0, [x19, #0x5bd8]
   1e21c:      	str	x0, [x14, #0xc78]
   1e220:      	mov	x0, #0x0                ; =0
   1e224:      	str	x0, [x14, #0xc80]
   1e228:      	ldr	x1, [x19, #0x5be8]
   1e22c:      	str	x1, [x14, #0xc88]
   1e230:      	ldr	x1, [x19, #0x5bf0]
   1e234:      	str	x1, [x14, #0xc90]
   1e238:      	str	x0, [x14, #0xc98]
   1e23c:      	ldr	x1, [x19, #0x5c00]
   1e240:      	str	x1, [x14, #0xca0]
   1e244:      	ldr	x1, [x19, #0x5c08]
   1e248:      	str	x1, [x14, #0xca8]
   1e24c:      	str	x0, [x14, #0xcb0]
   1e250:      	ldr	x0, [x19, #0x5c18]
   1e254:      	str	x0, [x14, #0xcb8]
   1e258:      	ldr	x0, [x19, #0x5c20]
   1e25c:      	str	x0, [x14, #0xcc0]
   1e260:      	str	x14, [sp, #0x198]
   1e264:      	mov	x1, #0x512              ; =1298
   1e268:      	mov	x2, #-0x9               ; =-9
   1e26c:      	ldr	x21, [sp, #0x1a8]
   1e270:      	ldur	x0, [sp, #0x8]
   1e274:      	mov	x5, x20
   1e278:      	ldr	x6, [sp, #0x1a0]
   1e27c:      	blr	x21
   1e280:      	cmp	x0, #0x0
   1e284:      	b.ne	0x22668 <_mech_canonical_program_entry_v1_numeric_1282+0x4b68>
   1e288:      	mov	x0, #0x3                ; =3
   1e28c:      	ldr	x15, [sp, #0x190]
   1e290:      	cmp	x15, #0x2
   1e294:      	b.lo	0x22670 <_mech_canonical_program_entry_v1_numeric_1282+0x4b70>
   1e298:      	mov	x5, #0x0                ; =0
   1e29c:      	ldr	x3, [sp, #0x198]
   1e2a0:      	str	x5, [x3]
   1e2a4:      	ldr	x0, [x19, #0x17d0]
   1e2a8:      	str	x0, [x3, #0x8]
   1e2ac:      	mov	x1, #0x512              ; =1298
   1e2b0:      	ldur	x0, [sp, #0x8]
   1e2b4:      	ldr	x6, [sp, #0x1a0]
   1e2b8:      	ldr	x21, [sp, #0x1a8]
   1e2bc:      	mov	x4, x20
   1e2c0:      	mov	x2, x5
   1e2c4:      	blr	x21
   1e2c8:      	cmp	x0, #0x0
   1e2cc:      	b.ne	0x22678 <_mech_canonical_program_entry_v1_numeric_1282+0x4b78>
   1e2d0:      	mov	x0, #0x3                ; =3
   1e2d4:      	mov	x21, x0
   1e2d8:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1e2dc:      	ldr	x2, [sp, #0x188]
   1e2e0:      	ldur	x5, [sp]
   1e2e4:      	mov	x28, x26
   1e2e8:      	stur	x6, [sp, #0xb0]
   1e2ec:      	str	x10, [sp, #0x190]
   1e2f0:      	str	x14, [sp, #0x198]
   1e2f4:      	ldr	x1, [x2, x22, lsl #3]
   1e2f8:      	add	x2, x22, #0x1
   1e2fc:      	ldr	x6, [sp, #0x180]
   1e300:      	cmp	x2, x6
   1e304:      	stur	x2, [sp, #0xe8]
   1e308:      	b.lo	0x1e584 <_mech_canonical_program_entry_v1_numeric_1282+0xa84>
   1e30c:      	b	0x22680 <_mech_canonical_program_entry_v1_numeric_1282+0x4b80>
   1e310:      	ldr	x3, [x19, #0x4c68]
   1e314:      	ldr	x4, [x19, #0x4c70]
   1e318:      	mov	x0, #0x0                ; =0
   1e31c:      	str	x0, [x19, #0x4c60]
   1e320:      	mov	x0, #0x3                ; =3
   1e324:      	ldr	x15, [sp, #0x190]
   1e328:      	cmp	x15, #0x19a
   1e32c:      	b.lo	0x227a0 <_mech_canonical_program_entry_v1_numeric_1282+0x4ca0>
   1e330:      	ldr	x0, [x19, #0x4f70]
   1e334:      	ldr	x1, [sp, #0x198]
   1e338:      	str	x0, [x1, #0x10]
   1e33c:      	ldr	x1, [x19, #0x4f78]
   1e340:      	ldr	x2, [sp, #0x198]
   1e344:      	str	x1, [x2, #0x18]
   1e348:      	ldr	x2, [x19, #0x5a20]
   1e34c:      	ldr	x5, [sp, #0x198]
   1e350:      	str	x2, [x5, #0xac0]
   1e354:      	ldr	x2, [sp, #0x198]
   1e358:      	str	x0, [x2, #0x10]
   1e35c:      	ldr	x0, [sp, #0x198]
   1e360:      	str	x1, [x0, #0x18]
   1e364:      	ldr	x0, [x19, #0x50c0]
   1e368:      	ldr	x1, [sp, #0x198]
   1e36c:      	str	x0, [x1, #0x160]
   1e370:      	ldr	x0, [x19, #0x50c8]
   1e374:      	str	x0, [x1, #0x168]
   1e378:      	ldr	x0, [x19, #0x50d0]
   1e37c:      	str	x0, [x1, #0x170]
   1e380:      	ldr	x0, [x19, #0x50d8]
   1e384:      	str	x0, [x1, #0x178]
   1e388:      	ldr	x0, [x19, #0x50e0]
   1e38c:      	str	x0, [x1, #0x180]
   1e390:      	ldr	x0, [x19, #0x50e8]
   1e394:      	str	x0, [x1, #0x188]
   1e398:      	ldr	x0, [x19, #0x50f0]
   1e39c:      	str	x0, [x5, #0x190]
   1e3a0:      	ldr	x0, [x19, #0x50f8]
   1e3a4:      	ldr	x7, [sp, #0x198]
   1e3a8:      	str	x0, [x7, #0x198]
   1e3ac:      	ldr	x0, [x19, #0x5100]
   1e3b0:      	ldr	x10, [sp, #0x198]
   1e3b4:      	str	x0, [x10, #0x1a0]
   1e3b8:      	ldr	x0, [x19, #0x52a8]
   1e3bc:      	ldr	x13, [sp, #0x198]
   1e3c0:      	str	x0, [x13, #0x348]
   1e3c4:      	ldr	x0, [x19, #0x52b0]
   1e3c8:      	str	x0, [x1, #0x350]
   1e3cc:      	ldr	x0, [x19, #0x52b8]
   1e3d0:      	str	x0, [x1, #0x358]
   1e3d4:      	ldr	x0, [x19, #0x52c0]
   1e3d8:      	str	x0, [x1, #0x360]
   1e3dc:      	ldr	x0, [x19, #0x52c8]
   1e3e0:      	str	x0, [x1, #0x368]
   1e3e4:      	ldr	x0, [x19, #0x52d0]
   1e3e8:      	str	x0, [x1, #0x370]
   1e3ec:      	ldr	x0, [x19, #0x52d8]
   1e3f0:      	str	x0, [x1, #0x378]
   1e3f4:      	ldr	x0, [x19, #0x52e0]
   1e3f8:      	str	x0, [x1, #0x380]
   1e3fc:      	ldr	x0, [x19, #0x52e8]
   1e400:      	str	x0, [x1, #0x388]
   1e404:      	ldr	x0, [x19, #0x55d8]
   1e408:      	str	x0, [x1, #0x678]
   1e40c:      	ldr	x0, [x19, #0x55e0]
   1e410:      	str	x0, [x1, #0x680]
   1e414:      	ldr	x0, [x19, #0x55e8]
   1e418:      	str	x0, [x1, #0x688]
   1e41c:      	ldr	x0, [x19, #0x55f0]
   1e420:      	str	x0, [x1, #0x690]
   1e424:      	ldr	x0, [x19, #0x55f8]
   1e428:      	str	x0, [x1, #0x698]
   1e42c:      	ldr	x1, [x19, #0x5600]
   1e430:      	ldr	x0, [sp, #0x198]
   1e434:      	str	x1, [x0, #0x6a0]
   1e438:      	ldr	x2, [x19, #0x5608]
   1e43c:      	str	x2, [x0, #0x6a8]
   1e440:      	ldr	x5, [x19, #0x5610]
   1e444:      	str	x5, [x0, #0x6b0]
   1e448:      	ldr	x5, [x19, #0x57a0]
   1e44c:      	ldr	x1, [sp, #0x198]
   1e450:      	str	x5, [x1, #0x840]
   1e454:      	ldr	x5, [x19, #0x57a8]
   1e458:      	ldr	x6, [sp, #0x198]
   1e45c:      	str	x5, [x6, #0x848]
   1e460:      	ldr	x6, [x19, #0x57b0]
   1e464:      	str	x6, [x7, #0x850]
   1e468:      	ldr	x7, [x19, #0x57b8]
   1e46c:      	str	x7, [x10, #0x858]
   1e470:      	ldr	x8, [x19, #0x57c0]
   1e474:      	str	x8, [x13, #0x860]
   1e478:      	ldr	x9, [x19, #0x57c8]
   1e47c:      	str	x9, [x0, #0x868]
   1e480:      	ldr	x10, [x19, #0x57d0]
   1e484:      	str	x10, [x0, #0x870]
   1e488:      	ldr	x11, [x19, #0x57d8]
   1e48c:      	str	x11, [x0, #0x878]
   1e490:      	ldr	x12, [x19, #0x5bb0]
   1e494:      	str	x12, [x0, #0xc50]
   1e498:      	ldr	x13, [x19, #0x5bb8]
   1e49c:      	str	x13, [x0, #0xc58]
   1e4a0:      	ldr	x14, [x19, #0x5bc0]
   1e4a4:      	str	x14, [x0, #0xc60]
   1e4a8:      	ldr	x15, [x19, #0x5bc8]
   1e4ac:      	str	x15, [x0, #0xc68]
   1e4b0:      	ldr	x0, [x19, #0x5bd0]
   1e4b4:      	str	x0, [x1, #0xc70]
   1e4b8:      	ldr	x0, [x19, #0x5bd8]
   1e4bc:      	str	x0, [x1, #0xc78]
   1e4c0:      	mov	x0, #0x0                ; =0
   1e4c4:      	str	x0, [x1, #0xc80]
   1e4c8:      	ldr	x1, [x19, #0x5be8]
   1e4cc:      	ldr	x2, [sp, #0x198]
   1e4d0:      	str	x1, [x2, #0xc88]
   1e4d4:      	ldr	x1, [x19, #0x5bf0]
   1e4d8:      	str	x1, [x2, #0xc90]
   1e4dc:      	ldr	x1, [sp, #0x198]
   1e4e0:      	str	x0, [x1, #0xc98]
   1e4e4:      	ldr	x1, [x19, #0x5c00]
   1e4e8:      	str	x1, [x2, #0xca0]
   1e4ec:      	ldr	x1, [x19, #0x5c08]
   1e4f0:      	str	x1, [x2, #0xca8]
   1e4f4:      	ldr	x1, [sp, #0x198]
   1e4f8:      	str	x0, [x1, #0xcb0]
   1e4fc:      	ldr	x0, [x19, #0x5c18]
   1e500:      	str	x0, [x1, #0xcb8]
   1e504:      	ldr	x0, [x19, #0x5c20]
   1e508:      	str	x0, [x2, #0xcc0]
   1e50c:      	mov	x1, #0x514              ; =1300
   1e510:      	mov	x2, #-0x9               ; =-9
   1e514:      	ldr	x21, [sp, #0x1a8]
   1e518:      	ldur	x0, [sp, #0x8]
   1e51c:      	mov	x5, x20
   1e520:      	ldr	x6, [sp, #0x1a0]
   1e524:      	blr	x21
   1e528:      	cmp	x0, #0x0
   1e52c:      	b.ne	0x227a8 <_mech_canonical_program_entry_v1_numeric_1282+0x4ca8>
   1e530:      	mov	x0, #0x3                ; =3
   1e534:      	ldr	x15, [sp, #0x190]
   1e538:      	cmp	x15, #0x2
   1e53c:      	b.lo	0x227b0 <_mech_canonical_program_entry_v1_numeric_1282+0x4cb0>
   1e540:      	mov	x5, #0x0                ; =0
   1e544:      	ldr	x3, [sp, #0x198]
   1e548:      	str	x5, [x3]
   1e54c:      	ldr	x0, [x19, #0x17e0]
   1e550:      	str	x0, [x3, #0x8]
   1e554:      	mov	x1, #0x514              ; =1300
   1e558:      	ldur	x0, [sp, #0x8]
   1e55c:      	ldr	x6, [sp, #0x1a0]
   1e560:      	ldr	x21, [sp, #0x1a8]
   1e564:      	mov	x4, x20
   1e568:      	mov	x2, x5
   1e56c:      	blr	x21
   1e570:      	cmp	x0, #0x0
   1e574:      	b.ne	0x227b8 <_mech_canonical_program_entry_v1_numeric_1282+0x4cb8>
   1e578:      	mov	x0, #0x3                ; =3
   1e57c:      	mov	x21, x0
   1e580:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1e584:      	ldur	x2, [sp, #0xe8]
   1e588:      	ldr	x6, [sp, #0x188]
   1e58c:      	ldr	x2, [x6, x2, lsl #3]
   1e590:      	ldr	x6, [sp, #0x170]
   1e594:      	cmp	x22, x6
   1e598:      	b.lo	0x1e814 <_mech_canonical_program_entry_v1_numeric_1282+0xd14>
   1e59c:      	b	0x227c0 <_mech_canonical_program_entry_v1_numeric_1282+0x4cc0>
   1e5a0:      	ldr	x3, [x19, #0x4c68]
   1e5a4:      	ldr	x4, [x19, #0x4c70]
   1e5a8:      	mov	x0, #0x0                ; =0
   1e5ac:      	str	x0, [x19, #0x4c60]
   1e5b0:      	mov	x0, #0x3                ; =3
   1e5b4:      	ldr	x15, [sp, #0x190]
   1e5b8:      	cmp	x15, #0x19a
   1e5bc:      	b.lo	0x228e4 <_mech_canonical_program_entry_v1_numeric_1282+0x4de4>
   1e5c0:      	ldr	x0, [x19, #0x4f70]
   1e5c4:      	ldr	x1, [sp, #0x198]
   1e5c8:      	str	x0, [x1, #0x10]
   1e5cc:      	ldr	x1, [x19, #0x4f78]
   1e5d0:      	ldr	x2, [sp, #0x198]
   1e5d4:      	str	x1, [x2, #0x18]
   1e5d8:      	ldr	x2, [x19, #0x5a20]
   1e5dc:      	ldr	x5, [sp, #0x198]
   1e5e0:      	str	x2, [x5, #0xac0]
   1e5e4:      	ldr	x2, [sp, #0x198]
   1e5e8:      	str	x0, [x2, #0x10]
   1e5ec:      	ldr	x0, [sp, #0x198]
   1e5f0:      	str	x1, [x0, #0x18]
   1e5f4:      	ldr	x0, [x19, #0x50c0]
   1e5f8:      	ldr	x1, [sp, #0x198]
   1e5fc:      	str	x0, [x1, #0x160]
   1e600:      	ldr	x0, [x19, #0x50c8]
   1e604:      	str	x0, [x1, #0x168]
   1e608:      	ldr	x0, [x19, #0x50d0]
   1e60c:      	str	x0, [x2, #0x170]
   1e610:      	ldr	x0, [x19, #0x50d8]
   1e614:      	str	x0, [x5, #0x178]
   1e618:      	ldr	x0, [x19, #0x50e0]
   1e61c:      	ldr	x8, [sp, #0x198]
   1e620:      	str	x0, [x8, #0x180]
   1e624:      	ldr	x0, [x19, #0x50e8]
   1e628:      	ldr	x11, [sp, #0x198]
   1e62c:      	str	x0, [x11, #0x188]
   1e630:      	ldr	x0, [x19, #0x50f0]
   1e634:      	ldr	x14, [sp, #0x198]
   1e638:      	str	x0, [x14, #0x190]
   1e63c:      	ldr	x0, [x19, #0x50f8]
   1e640:      	str	x0, [x1, #0x198]
   1e644:      	ldr	x0, [x19, #0x5100]
   1e648:      	str	x0, [x1, #0x1a0]
   1e64c:      	ldr	x0, [x19, #0x52a8]
   1e650:      	str	x0, [x1, #0x348]
   1e654:      	ldr	x0, [x19, #0x52b0]
   1e658:      	str	x0, [x1, #0x350]
   1e65c:      	ldr	x0, [x19, #0x52b8]
   1e660:      	str	x0, [x1, #0x358]
   1e664:      	ldr	x0, [x19, #0x52c0]
   1e668:      	str	x0, [x1, #0x360]
   1e66c:      	ldr	x0, [x19, #0x52c8]
   1e670:      	str	x0, [x1, #0x368]
   1e674:      	ldr	x0, [x19, #0x52d0]
   1e678:      	str	x0, [x1, #0x370]
   1e67c:      	ldr	x0, [x19, #0x52d8]
   1e680:      	str	x0, [x1, #0x378]
   1e684:      	ldr	x0, [x19, #0x52e0]
   1e688:      	str	x0, [x1, #0x380]
   1e68c:      	ldr	x0, [x19, #0x52e8]
   1e690:      	str	x0, [x1, #0x388]
   1e694:      	ldr	x0, [x19, #0x55d8]
   1e698:      	str	x0, [x1, #0x678]
   1e69c:      	ldr	x0, [x19, #0x55e0]
   1e6a0:      	str	x0, [x1, #0x680]
   1e6a4:      	ldr	x0, [x19, #0x55e8]
   1e6a8:      	str	x0, [x1, #0x688]
   1e6ac:      	ldr	x0, [x19, #0x55f0]
   1e6b0:      	str	x0, [x1, #0x690]
   1e6b4:      	ldr	x0, [x19, #0x55f8]
   1e6b8:      	str	x0, [x1, #0x698]
   1e6bc:      	ldr	x0, [x19, #0x5600]
   1e6c0:      	str	x0, [x2, #0x6a0]
   1e6c4:      	ldr	x0, [x19, #0x5608]
   1e6c8:      	str	x0, [x5, #0x6a8]
   1e6cc:      	ldr	x0, [x19, #0x5610]
   1e6d0:      	str	x0, [x8, #0x6b0]
   1e6d4:      	ldr	x0, [x19, #0x57a0]
   1e6d8:      	str	x0, [x11, #0x840]
   1e6dc:      	ldr	x0, [x19, #0x57a8]
   1e6e0:      	str	x0, [x14, #0x848]
   1e6e4:      	ldr	x0, [x19, #0x57b0]
   1e6e8:      	str	x0, [x1, #0x850]
   1e6ec:      	ldr	x0, [x19, #0x57b8]
   1e6f0:      	str	x0, [x1, #0x858]
   1e6f4:      	ldr	x1, [x19, #0x57c0]
   1e6f8:      	ldr	x0, [sp, #0x198]
   1e6fc:      	str	x1, [x0, #0x860]
   1e700:      	ldr	x2, [x19, #0x57c8]
   1e704:      	str	x2, [x0, #0x868]
   1e708:      	ldr	x5, [x19, #0x57d0]
   1e70c:      	str	x5, [x0, #0x870]
   1e710:      	ldr	x5, [x19, #0x57d8]
   1e714:      	str	x5, [x0, #0x878]
   1e718:      	ldr	x5, [x19, #0x5bb0]
   1e71c:      	str	x5, [x0, #0xc50]
   1e720:      	ldr	x6, [x19, #0x5bb8]
   1e724:      	str	x6, [x0, #0xc58]
   1e728:      	ldr	x7, [x19, #0x5bc0]
   1e72c:      	str	x7, [x0, #0xc60]
   1e730:      	ldr	x8, [x19, #0x5bc8]
   1e734:      	str	x8, [x0, #0xc68]
   1e738:      	ldr	x9, [x19, #0x5bd0]
   1e73c:      	str	x9, [x0, #0xc70]
   1e740:      	ldr	x10, [x19, #0x5bd8]
   1e744:      	str	x10, [x0, #0xc78]
   1e748:      	mov	x11, #0x0               ; =0
   1e74c:      	str	x11, [x0, #0xc80]
   1e750:      	ldr	x12, [x19, #0x5be8]
   1e754:      	str	x12, [x0, #0xc88]
   1e758:      	ldr	x13, [x19, #0x5bf0]
   1e75c:      	str	x13, [x0, #0xc90]
   1e760:      	str	x11, [x0, #0xc98]
   1e764:      	ldr	x15, [x19, #0x5c00]
   1e768:      	ldr	x1, [sp, #0x198]
   1e76c:      	str	x15, [x1, #0xca0]
   1e770:      	ldr	x0, [x19, #0x5c08]
   1e774:      	ldr	x5, [sp, #0x198]
   1e778:      	str	x0, [x5, #0xca8]
   1e77c:      	ldr	x6, [sp, #0x198]
   1e780:      	str	x11, [x6, #0xcb0]
   1e784:      	ldr	x0, [x19, #0x5c18]
   1e788:      	ldr	x9, [sp, #0x198]
   1e78c:      	str	x0, [x9, #0xcb8]
   1e790:      	ldr	x0, [x19, #0x5c20]
   1e794:      	ldr	x12, [sp, #0x198]
   1e798:      	str	x0, [x12, #0xcc0]
   1e79c:      	mov	x1, #0x516              ; =1302
   1e7a0:      	mov	x2, #-0x9               ; =-9
   1e7a4:      	ldr	x21, [sp, #0x1a8]
   1e7a8:      	ldur	x0, [sp, #0x8]
   1e7ac:      	mov	x5, x20
   1e7b0:      	ldr	x6, [sp, #0x1a0]
   1e7b4:      	blr	x21
   1e7b8:      	cmp	x0, #0x0
   1e7bc:      	b.ne	0x228ec <_mech_canonical_program_entry_v1_numeric_1282+0x4dec>
   1e7c0:      	mov	x0, #0x3                ; =3
   1e7c4:      	ldr	x15, [sp, #0x190]
   1e7c8:      	cmp	x15, #0x2
   1e7cc:      	b.lo	0x228f4 <_mech_canonical_program_entry_v1_numeric_1282+0x4df4>
   1e7d0:      	mov	x5, #0x0                ; =0
   1e7d4:      	ldr	x3, [sp, #0x198]
   1e7d8:      	str	x5, [x3]
   1e7dc:      	ldr	x0, [x19, #0x17f0]
   1e7e0:      	str	x0, [x3, #0x8]
   1e7e4:      	mov	x1, #0x516              ; =1302
   1e7e8:      	ldur	x0, [sp, #0x8]
   1e7ec:      	ldr	x6, [sp, #0x1a0]
   1e7f0:      	ldr	x21, [sp, #0x1a8]
   1e7f4:      	mov	x4, x20
   1e7f8:      	mov	x2, x5
   1e7fc:      	blr	x21
   1e800:      	cmp	x0, #0x0
   1e804:      	b.ne	0x228fc <_mech_canonical_program_entry_v1_numeric_1282+0x4dfc>
   1e808:      	mov	x0, #0x3                ; =3
   1e80c:      	mov	x21, x0
   1e810:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1e814:      	stur	x0, [sp, #0xf0]
   1e818:      	stur	x4, [sp, #0x98]
   1e81c:      	stur	x1, [sp, #0x18]
   1e820:      	stur	x5, [sp]
   1e824:      	mov	x26, x2
   1e828:      	ldr	x0, [sp, #0x178]
   1e82c:      	ldr	x15, [x0, x22, lsl #3]
   1e830:      	stur	x15, [sp, #0xe0]
   1e834:      	mov	w0, #0xc87e             ; =51326
   1e838:      	movk	w0, #0x1, lsl #16
   1e83c:      	sub	x3, x3, x0
   1e840:      	mov	x10, #0x0               ; =0
   1e844:      	stur	x10, [sp, #0x10]
   1e848:      	ldur	x4, [sp, #0x10]
   1e84c:      	ldur	x24, [sp, #0x10]
   1e850:      	ldur	x27, [sp, #0x10]
   1e854:      	ldur	x0, [sp, #0x10]
   1e858:      	stur	x0, [sp, #0x20]
   1e85c:      	stur	x0, [sp, #0x80]
   1e860:      	mov	w0, #0x2166             ; =8550
   1e864:      	movk	w0, #0x1, lsl #16
   1e868:      	cmp	x3, x0
   1e86c:      	b.hs	0x1ec18 <_mech_canonical_program_entry_v1_numeric_1282+0x1118>
   1e870:      	mov	x1, #0x0                ; =0
   1e874:      	str	x1, [x19, #0x18]
   1e878:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   1e87c:      	str	x0, [x19, #0x20]
   1e880:      	mov	x0, #0x1                ; =1
   1e884:      	str	x0, [x19, #0x30]
   1e888:      	mov	x2, #0x101010101010101  ; =72340172838076673
   1e88c:      	str	x2, [x19, #0x38]
   1e890:      	mov	x2, #0x2                ; =2
   1e894:      	str	x2, [x19, #0x40]
   1e898:      	stur	x2, [sp, #0xd8]
   1e89c:      	mov	x2, #0x3                ; =3
   1e8a0:      	str	x2, [x19, #0x48]
   1e8a4:      	mov	x2, #0x4                ; =4
   1e8a8:      	str	x2, [x19, #0x50]
   1e8ac:      	mov	x2, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   1e8b0:      	str	x2, [x19, #0x78]
   1e8b4:      	mov	x2, #0x3333333333333333 ; =3689348814741910323
   1e8b8:      	str	x2, [x19, #0x88]
   1e8bc:      	mov	x2, #0x38               ; =56
   1e8c0:      	str	x2, [x19, #0x90]
   1e8c4:      	mov	x2, #0x3a               ; =58
   1e8c8:      	str	x2, [x19, #0x98]
   1e8cc:      	mov	x2, #0x5555555555555555 ; =6148914691236517205
   1e8d0:      	str	x2, [x19, #0xb0]
   1e8d4:      	mov	x2, #0x3ffffffffffffff  ; =288230376151711743
   1e8d8:      	str	x2, [x19, #0xb8]
   1e8dc:      	str	x1, [x19, #0x188]
   1e8e0:      	str	x0, [x19, #0x190]
   1e8e4:      	str	x22, [x19, #0x17a0]
   1e8e8:      	str	x23, [x19, #0x17a8]
   1e8ec:      	ldur	x25, [sp, #0xf0]
   1e8f0:      	uxtb	w1, w25
   1e8f4:      	str	x1, [x19, #0x17b8]
   1e8f8:      	str	x28, [x19, #0x4c60]
   1e8fc:      	str	x3, [x19, #0x4c68]
   1e900:      	ldur	x1, [sp, #0x98]
   1e904:      	str	x1, [x19, #0x4c70]
   1e908:      	str	x22, [x19, #0x4f70]
   1e90c:      	str	x23, [x19, #0x4f78]
   1e910:      	ldur	x1, [sp, #0x18]
   1e914:      	str	x1, [x19, #0x50c0]
   1e918:      	mov	x15, x26
   1e91c:      	str	x15, [x19, #0x50c8]
   1e920:      	str	x22, [x19, #0x50d0]
   1e924:      	ldur	x26, [sp, #0xe0]
   1e928:      	str	x26, [x19, #0x50d8]
   1e92c:      	ldur	x1, [sp, #0x10]
   1e930:      	str	x1, [x19, #0x50e0]
   1e934:      	str	x27, [x19, #0x50e8]
   1e938:      	str	x24, [x19, #0x50f0]
   1e93c:      	str	x4, [x19, #0x50f8]
   1e940:      	ldur	x26, [sp, #0x80]
   1e944:      	str	x26, [x19, #0x5100]
   1e948:      	ldur	x14, [sp, #0x60]
   1e94c:      	str	x14, [x19, #0x5a20]
   1e950:      	add	x14, x11, #0x1
   1e954:      	str	x14, [x19, #0x5bb0]
   1e958:      	ldur	x26, [sp, #0xa0]
   1e95c:      	str	x26, [x19, #0x5bb8]
   1e960:      	ldur	x7, [sp, #0xa8]
   1e964:      	str	x7, [x19, #0x5bc0]
   1e968:      	ldur	x4, [sp, #0x90]
   1e96c:      	sub	x1, x4, x3
   1e970:      	mov	w2, #0xc87e             ; =51326
   1e974:      	movk	w2, #0x1, lsl #16
   1e978:      	msub	x1, x14, x2, x1
   1e97c:      	str	x1, [x19, #0x5bc8]
   1e980:      	str	x0, [x19, #0x5bd0]
   1e984:      	ldur	x20, [sp, #0x20]
   1e988:      	str	x20, [x19, #0x5bd8]
   1e98c:      	ldur	x8, [sp, #0xb0]
   1e990:      	str	x8, [x19, #0x5be8]
   1e994:      	ldur	x4, [sp, #0xb8]
   1e998:      	str	x4, [x19, #0x5bf0]
   1e99c:      	str	x12, [x19, #0x5c00]
   1e9a0:      	str	x9, [x19, #0x5c08]
   1e9a4:      	str	x13, [x19, #0x5c18]
   1e9a8:      	ldur	x13, [sp, #0xc0]
   1e9ac:      	str	x13, [x19, #0x5c20]
   1e9b0:      	ldr	x0, [x19, #0x4c60]
   1e9b4:      	cmp	x0, #0x0
   1e9b8:      	b.eq	0x1ebf0 <_mech_canonical_program_entry_v1_numeric_1282+0x10f0>
   1e9bc:      	ldr	x3, [x19, #0x4c68]
   1e9c0:      	ldr	x4, [x19, #0x4c70]
   1e9c4:      	mov	x0, #0x0                ; =0
   1e9c8:      	str	x0, [x19, #0x4c60]
   1e9cc:      	mov	x0, #0x3                ; =3
   1e9d0:      	ldr	x15, [sp, #0x190]
   1e9d4:      	mov	x21, x0
   1e9d8:      	cmp	x15, #0x19a
   1e9dc:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1e9e0:      	ldr	x0, [x19, #0x4f70]
   1e9e4:      	ldr	x8, [sp, #0x198]
   1e9e8:      	str	x0, [x8, #0x10]
   1e9ec:      	ldr	x1, [x19, #0x4f78]
   1e9f0:      	ldr	x11, [sp, #0x198]
   1e9f4:      	str	x1, [x11, #0x18]
   1e9f8:      	ldr	x2, [x19, #0x5a20]
   1e9fc:      	ldr	x14, [sp, #0x198]
   1ea00:      	str	x2, [x14, #0xac0]
   1ea04:      	ldr	x2, [sp, #0x198]
   1ea08:      	str	x0, [x2, #0x10]
   1ea0c:      	ldr	x0, [sp, #0x198]
   1ea10:      	str	x1, [x0, #0x18]
   1ea14:      	ldr	x0, [x19, #0x50c0]
   1ea18:      	ldr	x1, [sp, #0x198]
   1ea1c:      	str	x0, [x1, #0x160]
   1ea20:      	ldr	x0, [x19, #0x50c8]
   1ea24:      	str	x0, [x1, #0x168]
   1ea28:      	ldr	x0, [x19, #0x50d0]
   1ea2c:      	str	x0, [x1, #0x170]
   1ea30:      	ldr	x0, [x19, #0x50d8]
   1ea34:      	str	x0, [x1, #0x178]
   1ea38:      	ldr	x0, [x19, #0x50e0]
   1ea3c:      	str	x0, [x1, #0x180]
   1ea40:      	ldr	x0, [x19, #0x50e8]
   1ea44:      	str	x0, [x1, #0x188]
   1ea48:      	ldr	x0, [x19, #0x50f0]
   1ea4c:      	str	x0, [x1, #0x190]
   1ea50:      	ldr	x0, [x19, #0x50f8]
   1ea54:      	str	x0, [x1, #0x198]
   1ea58:      	ldr	x0, [x19, #0x5100]
   1ea5c:      	str	x0, [x1, #0x1a0]
   1ea60:      	ldr	x0, [x19, #0x52a8]
   1ea64:      	str	x0, [x1, #0x348]
   1ea68:      	ldr	x0, [x19, #0x52b0]
   1ea6c:      	str	x0, [x1, #0x350]
   1ea70:      	ldr	x0, [x19, #0x52b8]
   1ea74:      	str	x0, [x1, #0x358]
   1ea78:      	ldr	x0, [x19, #0x52c0]
   1ea7c:      	str	x0, [x1, #0x360]
   1ea80:      	ldr	x0, [x19, #0x52c8]
   1ea84:      	str	x0, [x1, #0x368]
   1ea88:      	ldr	x0, [x19, #0x52d0]
   1ea8c:      	str	x0, [x1, #0x370]
   1ea90:      	ldr	x0, [x19, #0x52d8]
   1ea94:      	ldr	x5, [sp, #0x198]
   1ea98:      	str	x0, [x5, #0x378]
   1ea9c:      	ldr	x0, [x19, #0x52e0]
   1eaa0:      	ldr	x6, [sp, #0x198]
   1eaa4:      	str	x0, [x6, #0x380]
   1eaa8:      	ldr	x0, [x19, #0x52e8]
   1eaac:      	ldr	x9, [sp, #0x198]
   1eab0:      	str	x0, [x9, #0x388]
   1eab4:      	ldr	x0, [x19, #0x55d8]
   1eab8:      	ldr	x12, [sp, #0x198]
   1eabc:      	str	x0, [x12, #0x678]
   1eac0:      	ldr	x0, [x19, #0x55e0]
   1eac4:      	ldr	x15, [sp, #0x198]
   1eac8:      	str	x0, [x15, #0x680]
   1eacc:      	ldr	x0, [x19, #0x55e8]
   1ead0:      	str	x0, [x1, #0x688]
   1ead4:      	ldr	x0, [x19, #0x55f0]
   1ead8:      	str	x0, [x1, #0x690]
   1eadc:      	ldr	x0, [x19, #0x55f8]
   1eae0:      	str	x0, [x1, #0x698]
   1eae4:      	ldr	x0, [x19, #0x5600]
   1eae8:      	str	x0, [x1, #0x6a0]
   1eaec:      	ldr	x0, [x19, #0x5608]
   1eaf0:      	str	x0, [x1, #0x6a8]
   1eaf4:      	ldr	x0, [x19, #0x5610]
   1eaf8:      	str	x0, [x1, #0x6b0]
   1eafc:      	ldr	x1, [x19, #0x57a0]
   1eb00:      	ldr	x0, [sp, #0x198]
   1eb04:      	str	x1, [x0, #0x840]
   1eb08:      	ldr	x2, [x19, #0x57a8]
   1eb0c:      	str	x2, [x0, #0x848]
   1eb10:      	ldr	x5, [x19, #0x57b0]
   1eb14:      	str	x5, [x0, #0x850]
   1eb18:      	ldr	x5, [x19, #0x57b8]
   1eb1c:      	str	x5, [x0, #0x858]
   1eb20:      	ldr	x5, [x19, #0x57c0]
   1eb24:      	str	x5, [x0, #0x860]
   1eb28:      	ldr	x6, [x19, #0x57c8]
   1eb2c:      	str	x6, [x0, #0x868]
   1eb30:      	ldr	x7, [x19, #0x57d0]
   1eb34:      	str	x7, [x0, #0x870]
   1eb38:      	ldr	x8, [x19, #0x57d8]
   1eb3c:      	str	x8, [x0, #0x878]
   1eb40:      	ldr	x9, [x19, #0x5bb0]
   1eb44:      	str	x9, [x0, #0xc50]
   1eb48:      	ldr	x10, [x19, #0x5bb8]
   1eb4c:      	str	x10, [x0, #0xc58]
   1eb50:      	ldr	x11, [x19, #0x5bc0]
   1eb54:      	ldr	x5, [sp, #0x198]
   1eb58:      	str	x11, [x5, #0xc60]
   1eb5c:      	ldr	x12, [x19, #0x5bc8]
   1eb60:      	ldr	x6, [sp, #0x198]
   1eb64:      	str	x12, [x6, #0xc68]
   1eb68:      	ldr	x13, [x19, #0x5bd0]
   1eb6c:      	ldr	x9, [sp, #0x198]
   1eb70:      	str	x13, [x9, #0xc70]
   1eb74:      	ldr	x14, [x19, #0x5bd8]
   1eb78:      	ldr	x12, [sp, #0x198]
   1eb7c:      	str	x14, [x12, #0xc78]
   1eb80:      	mov	x15, #0x0               ; =0
   1eb84:      	str	x15, [x0, #0xc80]
   1eb88:      	ldr	x0, [x19, #0x5be8]
   1eb8c:      	ldr	x1, [sp, #0x198]
   1eb90:      	str	x0, [x1, #0xc88]
   1eb94:      	ldr	x0, [x19, #0x5bf0]
   1eb98:      	str	x0, [x1, #0xc90]
   1eb9c:      	ldr	x0, [sp, #0x198]
   1eba0:      	str	x15, [x0, #0xc98]
   1eba4:      	ldr	x0, [x19, #0x5c00]
   1eba8:      	str	x0, [x1, #0xca0]
   1ebac:      	ldr	x0, [x19, #0x5c08]
   1ebb0:      	str	x0, [x1, #0xca8]
   1ebb4:      	ldr	x0, [sp, #0x198]
   1ebb8:      	str	x15, [x0, #0xcb0]
   1ebbc:      	ldr	x0, [x19, #0x5c18]
   1ebc0:      	str	x0, [x1, #0xcb8]
   1ebc4:      	ldr	x0, [x19, #0x5c20]
   1ebc8:      	str	x0, [x1, #0xcc0]
   1ebcc:      	mov	x1, #0x51f              ; =1311
   1ebd0:      	mov	x2, #-0x9               ; =-9
   1ebd4:      	mov	x5, #0x1                ; =1
   1ebd8:      	ldur	x0, [sp, #0x8]
   1ebdc:      	ldr	x6, [sp, #0x1a0]
   1ebe0:      	ldr	x21, [sp, #0x1a8]
   1ebe4:      	blr	x21
   1ebe8:      	cmp	x0, #0x0
   1ebec:      	b.ne	0x22904 <_mech_canonical_program_entry_v1_numeric_1282+0x4e04>
   1ebf0:      	mov	x0, #0x0                ; =0
   1ebf4:      	ldur	x1, [sp, #0xd8]
   1ebf8:      	add	sp, sp, #0x1c0
   1ebfc:      	ldp	x19, x20, [sp], #0x10
   1ec00:      	ldp	x21, x22, [sp], #0x10
   1ec04:      	ldp	x23, x24, [sp], #0x10
   1ec08:      	ldp	x25, x26, [sp], #0x10
   1ec0c:      	ldp	x27, x28, [sp], #0x10
   1ec10:      	ldp	x29, x30, [sp], #0x10
   1ec14:      	retab
   1ec18:      	ldur	x1, [sp, #0x18]
   1ec1c:      	stur	x4, [sp, #0x78]
   1ec20:      	mov	x15, x26
   1ec24:      	cmp	x1, x15
   1ec28:      	cset	x15, lo
   1ec2c:      	stur	x15, [sp, #0xd8]
   1ec30:      	mov	x15, x26
   1ec34:      	cmp	x1, x15
   1ec38:      	b.lo	0x1ec6c <_mech_canonical_program_entry_v1_numeric_1282+0x116c>
   1ec3c:      	mov	w0, #0x2166             ; =8550
   1ec40:      	movk	w0, #0x1, lsl #16
   1ec44:      	sub	x3, x3, x0
   1ec48:      	stur	x24, [sp, #0x70]
   1ec4c:      	stur	x27, [sp, #0x68]
   1ec50:      	stur	x1, [sp, #0x18]
   1ec54:      	mov	x15, x27
   1ec58:      	mov	x4, x1
   1ec5c:      	ldur	x2, [sp, #0x10]
   1ec60:      	ldur	x1, [sp, #0x78]
   1ec64:      	ldur	x0, [sp, #0x80]
   1ec68:      	b	0x2004c <_mech_canonical_program_entry_v1_numeric_1282+0x254c>
   1ec6c:      	ldr	x0, [sp, #0x160]
   1ec70:      	cmp	x1, x0
   1ec74:      	b.lo	0x1ef0c <_mech_canonical_program_entry_v1_numeric_1282+0x140c>
   1ec78:      	b	0x2290c <_mech_canonical_program_entry_v1_numeric_1282+0x4e0c>
   1ec7c:      	ldr	x3, [x19, #0x4c68]
   1ec80:      	ldr	x4, [x19, #0x4c70]
   1ec84:      	mov	x0, #0x0                ; =0
   1ec88:      	str	x0, [x19, #0x4c60]
   1ec8c:      	mov	x0, #0x3                ; =3
   1ec90:      	ldr	x15, [sp, #0x190]
   1ec94:      	mov	x21, x0
   1ec98:      	cmp	x15, #0x19a
   1ec9c:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1eca0:      	ldr	x0, [x19, #0x4f70]
   1eca4:      	ldr	x1, [sp, #0x198]
   1eca8:      	str	x0, [x1, #0x10]
   1ecac:      	ldr	x1, [x19, #0x4f78]
   1ecb0:      	ldr	x2, [sp, #0x198]
   1ecb4:      	str	x1, [x2, #0x18]
   1ecb8:      	ldr	x2, [x19, #0x5a20]
   1ecbc:      	ldr	x5, [sp, #0x198]
   1ecc0:      	str	x2, [x5, #0xac0]
   1ecc4:      	ldr	x2, [sp, #0x198]
   1ecc8:      	str	x0, [x2, #0x10]
   1eccc:      	ldr	x0, [sp, #0x198]
   1ecd0:      	str	x1, [x0, #0x18]
   1ecd4:      	ldr	x0, [x19, #0x50c0]
   1ecd8:      	ldr	x1, [sp, #0x198]
   1ecdc:      	str	x0, [x1, #0x160]
   1ece0:      	ldr	x0, [x19, #0x50c8]
   1ece4:      	str	x0, [x1, #0x168]
   1ece8:      	ldr	x0, [x19, #0x50d0]
   1ecec:      	str	x0, [x1, #0x170]
   1ecf0:      	ldr	x0, [x19, #0x50d8]
   1ecf4:      	str	x0, [x1, #0x178]
   1ecf8:      	ldr	x0, [x19, #0x50e0]
   1ecfc:      	str	x0, [x1, #0x180]
   1ed00:      	ldr	x0, [x19, #0x50e8]
   1ed04:      	str	x0, [x5, #0x188]
   1ed08:      	ldr	x0, [x19, #0x50f0]
   1ed0c:      	ldr	x6, [sp, #0x198]
   1ed10:      	str	x0, [x6, #0x190]
   1ed14:      	ldr	x0, [x19, #0x50f8]
   1ed18:      	ldr	x9, [sp, #0x198]
   1ed1c:      	str	x0, [x9, #0x198]
   1ed20:      	ldr	x0, [x19, #0x5100]
   1ed24:      	ldr	x12, [sp, #0x198]
   1ed28:      	str	x0, [x12, #0x1a0]
   1ed2c:      	ldr	x0, [x19, #0x52a8]
   1ed30:      	ldr	x15, [sp, #0x198]
   1ed34:      	str	x0, [x15, #0x348]
   1ed38:      	ldr	x0, [x19, #0x52b0]
   1ed3c:      	str	x0, [x1, #0x350]
   1ed40:      	ldr	x0, [x19, #0x52b8]
   1ed44:      	str	x0, [x1, #0x358]
   1ed48:      	ldr	x0, [x19, #0x52c0]
   1ed4c:      	str	x0, [x1, #0x360]
   1ed50:      	ldr	x1, [x19, #0x52c8]
   1ed54:      	ldr	x0, [sp, #0x198]
   1ed58:      	str	x1, [x0, #0x368]
   1ed5c:      	ldr	x2, [x19, #0x52d0]
   1ed60:      	str	x2, [x0, #0x370]
   1ed64:      	ldr	x5, [x19, #0x52d8]
   1ed68:      	str	x5, [x0, #0x378]
   1ed6c:      	ldr	x5, [x19, #0x52e0]
   1ed70:      	str	x5, [x0, #0x380]
   1ed74:      	ldr	x5, [x19, #0x52e8]
   1ed78:      	str	x5, [x0, #0x388]
   1ed7c:      	ldr	x6, [x19, #0x55d8]
   1ed80:      	str	x6, [x0, #0x678]
   1ed84:      	ldr	x7, [x19, #0x55e0]
   1ed88:      	str	x7, [x0, #0x680]
   1ed8c:      	ldr	x8, [x19, #0x55e8]
   1ed90:      	str	x8, [x0, #0x688]
   1ed94:      	ldr	x9, [x19, #0x55f0]
   1ed98:      	str	x9, [x0, #0x690]
   1ed9c:      	ldr	x10, [x19, #0x55f8]
   1eda0:      	str	x10, [x0, #0x698]
   1eda4:      	ldr	x11, [x19, #0x5600]
   1eda8:      	str	x11, [x0, #0x6a0]
   1edac:      	ldr	x12, [x19, #0x5608]
   1edb0:      	str	x12, [x0, #0x6a8]
   1edb4:      	ldr	x13, [x19, #0x5610]
   1edb8:      	str	x13, [x0, #0x6b0]
   1edbc:      	ldr	x14, [x19, #0x57a0]
   1edc0:      	ldr	x5, [sp, #0x198]
   1edc4:      	str	x14, [x5, #0x840]
   1edc8:      	ldr	x15, [x19, #0x57a8]
   1edcc:      	ldr	x6, [sp, #0x198]
   1edd0:      	str	x15, [x6, #0x848]
   1edd4:      	ldr	x0, [x19, #0x57b0]
   1edd8:      	ldr	x9, [sp, #0x198]
   1eddc:      	str	x0, [x9, #0x850]
   1ede0:      	ldr	x0, [x19, #0x57b8]
   1ede4:      	ldr	x12, [sp, #0x198]
   1ede8:      	str	x0, [x12, #0x858]
   1edec:      	ldr	x0, [x19, #0x57c0]
   1edf0:      	ldr	x15, [sp, #0x198]
   1edf4:      	str	x0, [x15, #0x860]
   1edf8:      	ldr	x0, [x19, #0x57c8]
   1edfc:      	ldr	x1, [sp, #0x198]
   1ee00:      	str	x0, [x1, #0x868]
   1ee04:      	ldr	x0, [x19, #0x57d0]
   1ee08:      	str	x0, [x1, #0x870]
   1ee0c:      	ldr	x0, [x19, #0x57d8]
   1ee10:      	str	x0, [x1, #0x878]
   1ee14:      	ldr	x0, [x19, #0x5bb0]
   1ee18:      	str	x0, [x1, #0xc50]
   1ee1c:      	ldr	x0, [x19, #0x5bb8]
   1ee20:      	str	x0, [x1, #0xc58]
   1ee24:      	ldr	x0, [x19, #0x5bc0]
   1ee28:      	str	x0, [x1, #0xc60]
   1ee2c:      	ldr	x0, [x19, #0x5bc8]
   1ee30:      	str	x0, [x1, #0xc68]
   1ee34:      	ldr	x0, [x19, #0x5bd0]
   1ee38:      	str	x0, [x1, #0xc70]
   1ee3c:      	ldr	x0, [x19, #0x5bd8]
   1ee40:      	str	x0, [x1, #0xc78]
   1ee44:      	mov	x0, #0x0                ; =0
   1ee48:      	str	x0, [x1, #0xc80]
   1ee4c:      	ldr	x1, [x19, #0x5be8]
   1ee50:      	ldr	x2, [sp, #0x198]
   1ee54:      	str	x1, [x2, #0xc88]
   1ee58:      	ldr	x1, [x19, #0x5bf0]
   1ee5c:      	str	x1, [x2, #0xc90]
   1ee60:      	ldr	x1, [sp, #0x198]
   1ee64:      	str	x0, [x1, #0xc98]
   1ee68:      	ldr	x1, [x19, #0x5c00]
   1ee6c:      	str	x1, [x2, #0xca0]
   1ee70:      	ldr	x1, [x19, #0x5c08]
   1ee74:      	str	x1, [x2, #0xca8]
   1ee78:      	ldr	x1, [sp, #0x198]
   1ee7c:      	str	x0, [x1, #0xcb0]
   1ee80:      	ldr	x0, [x19, #0x5c18]
   1ee84:      	str	x0, [x1, #0xcb8]
   1ee88:      	ldr	x0, [x19, #0x5c20]
   1ee8c:      	str	x0, [x5, #0xcc0]
   1ee90:      	mov	x1, #0x530              ; =1328
   1ee94:      	mov	x2, #-0x9               ; =-9
   1ee98:      	ldr	x21, [sp, #0x1a8]
   1ee9c:      	ldur	x0, [sp, #0x8]
   1eea0:      	mov	x5, x20
   1eea4:      	ldr	x6, [sp, #0x1a0]
   1eea8:      	blr	x21
   1eeac:      	cmp	x0, #0x0
   1eeb0:      	b.ne	0x22a9c <_mech_canonical_program_entry_v1_numeric_1282+0x4f9c>
   1eeb4:      	mov	x0, #0x3                ; =3
   1eeb8:      	ldr	x15, [sp, #0x190]
   1eebc:      	mov	x21, x0
   1eec0:      	cmp	x15, #0x2
   1eec4:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1eec8:      	mov	x5, #0x0                ; =0
   1eecc:      	ldr	x3, [sp, #0x198]
   1eed0:      	str	x5, [x3]
   1eed4:      	ldr	x0, [x19, #0x1890]
   1eed8:      	str	x0, [x3, #0x8]
   1eedc:      	mov	x1, #0x530              ; =1328
   1eee0:      	ldur	x0, [sp, #0x8]
   1eee4:      	ldr	x6, [sp, #0x1a0]
   1eee8:      	ldr	x21, [sp, #0x1a8]
   1eeec:      	mov	x4, x20
   1eef0:      	mov	x2, x5
   1eef4:      	blr	x21
   1eef8:      	cmp	x0, #0x0
   1eefc:      	b.ne	0x22aa4 <_mech_canonical_program_entry_v1_numeric_1282+0x4fa4>
   1ef00:      	mov	x0, #0x3                ; =3
   1ef04:      	mov	x21, x0
   1ef08:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1ef0c:      	ldr	x0, [sp, #0x168]
   1ef10:      	stur	x24, [sp, #0x70]
   1ef14:      	ldr	x2, [x0, x1, lsl #3]
   1ef18:      	add	x4, x2, #0x1
   1ef1c:      	cmp	x4, x2
   1ef20:      	b.lo	0x22aac <_mech_canonical_program_entry_v1_numeric_1282+0x4fac>
   1ef24:      	ldr	x0, [sp, #0x150]
   1ef28:      	cmp	x2, x0
   1ef2c:      	b.lo	0x1f1bc <_mech_canonical_program_entry_v1_numeric_1282+0x16bc>
   1ef30:      	b	0x22bf8 <_mech_canonical_program_entry_v1_numeric_1282+0x50f8>
   1ef34:      	ldr	x3, [x19, #0x4c68]
   1ef38:      	ldr	x4, [x19, #0x4c70]
   1ef3c:      	mov	x0, #0x0                ; =0
   1ef40:      	str	x0, [x19, #0x4c60]
   1ef44:      	mov	x0, #0x3                ; =3
   1ef48:      	ldr	x15, [sp, #0x190]
   1ef4c:      	mov	x21, x0
   1ef50:      	cmp	x15, #0x19a
   1ef54:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1ef58:      	ldr	x0, [x19, #0x4f70]
   1ef5c:      	ldr	x6, [sp, #0x198]
   1ef60:      	str	x0, [x6, #0x10]
   1ef64:      	ldr	x1, [x19, #0x4f78]
   1ef68:      	ldr	x9, [sp, #0x198]
   1ef6c:      	str	x1, [x9, #0x18]
   1ef70:      	ldr	x2, [x19, #0x5a20]
   1ef74:      	ldr	x12, [sp, #0x198]
   1ef78:      	str	x2, [x12, #0xac0]
   1ef7c:      	ldr	x14, [sp, #0x198]
   1ef80:      	str	x0, [x14, #0x10]
   1ef84:      	ldr	x0, [sp, #0x198]
   1ef88:      	str	x1, [x0, #0x18]
   1ef8c:      	ldr	x0, [x19, #0x50c0]
   1ef90:      	ldr	x1, [sp, #0x198]
   1ef94:      	str	x0, [x1, #0x160]
   1ef98:      	ldr	x0, [x19, #0x50c8]
   1ef9c:      	str	x0, [x1, #0x168]
   1efa0:      	ldr	x0, [x19, #0x50d0]
   1efa4:      	str	x0, [x1, #0x170]
   1efa8:      	ldr	x0, [x19, #0x50d8]
   1efac:      	str	x0, [x1, #0x178]
   1efb0:      	ldr	x0, [x19, #0x50e0]
   1efb4:      	str	x0, [x1, #0x180]
   1efb8:      	ldr	x0, [x19, #0x50e8]
   1efbc:      	str	x0, [x1, #0x188]
   1efc0:      	ldr	x0, [x19, #0x50f0]
   1efc4:      	str	x0, [x1, #0x190]
   1efc8:      	ldr	x0, [x19, #0x50f8]
   1efcc:      	str	x0, [x1, #0x198]
   1efd0:      	ldr	x0, [x19, #0x5100]
   1efd4:      	str	x0, [x1, #0x1a0]
   1efd8:      	ldr	x0, [x19, #0x52a8]
   1efdc:      	str	x0, [x1, #0x348]
   1efe0:      	ldr	x0, [x19, #0x52b0]
   1efe4:      	str	x0, [x1, #0x350]
   1efe8:      	ldr	x0, [x19, #0x52b8]
   1efec:      	str	x0, [x1, #0x358]
   1eff0:      	ldr	x0, [x19, #0x52c0]
   1eff4:      	str	x0, [x1, #0x360]
   1eff8:      	ldr	x0, [x19, #0x52c8]
   1effc:      	str	x0, [x1, #0x368]
   1f000:      	ldr	x0, [x19, #0x52d0]
   1f004:      	str	x0, [x1, #0x370]
   1f008:      	ldr	x0, [x19, #0x52d8]
   1f00c:      	str	x0, [x1, #0x378]
   1f010:      	ldr	x0, [x19, #0x52e0]
   1f014:      	ldr	x5, [sp, #0x198]
   1f018:      	str	x0, [x5, #0x380]
   1f01c:      	ldr	x0, [x19, #0x52e8]
   1f020:      	ldr	x7, [sp, #0x198]
   1f024:      	str	x0, [x7, #0x388]
   1f028:      	ldr	x0, [x19, #0x55d8]
   1f02c:      	ldr	x10, [sp, #0x198]
   1f030:      	str	x0, [x10, #0x678]
   1f034:      	ldr	x0, [x19, #0x55e0]
   1f038:      	ldr	x13, [sp, #0x198]
   1f03c:      	str	x0, [x13, #0x680]
   1f040:      	ldr	x0, [x19, #0x55e8]
   1f044:      	str	x0, [x1, #0x688]
   1f048:      	ldr	x0, [x19, #0x55f0]
   1f04c:      	str	x0, [x1, #0x690]
   1f050:      	ldr	x0, [x19, #0x55f8]
   1f054:      	str	x0, [x1, #0x698]
   1f058:      	ldr	x0, [x19, #0x5600]
   1f05c:      	str	x0, [x1, #0x6a0]
   1f060:      	ldr	x0, [x19, #0x5608]
   1f064:      	str	x0, [x1, #0x6a8]
   1f068:      	ldr	x0, [x19, #0x5610]
   1f06c:      	str	x0, [x1, #0x6b0]
   1f070:      	ldr	x0, [x19, #0x57a0]
   1f074:      	str	x0, [x1, #0x840]
   1f078:      	ldr	x1, [x19, #0x57a8]
   1f07c:      	ldr	x0, [sp, #0x198]
   1f080:      	str	x1, [x0, #0x848]
   1f084:      	ldr	x2, [x19, #0x57b0]
   1f088:      	str	x2, [x0, #0x850]
   1f08c:      	ldr	x5, [x19, #0x57b8]
   1f090:      	str	x5, [x0, #0x858]
   1f094:      	ldr	x5, [x19, #0x57c0]
   1f098:      	str	x5, [x0, #0x860]
   1f09c:      	ldr	x5, [x19, #0x57c8]
   1f0a0:      	str	x5, [x0, #0x868]
   1f0a4:      	ldr	x6, [x19, #0x57d0]
   1f0a8:      	str	x6, [x0, #0x870]
   1f0ac:      	ldr	x7, [x19, #0x57d8]
   1f0b0:      	str	x7, [x0, #0x878]
   1f0b4:      	ldr	x8, [x19, #0x5bb0]
   1f0b8:      	str	x8, [x0, #0xc50]
   1f0bc:      	ldr	x9, [x19, #0x5bb8]
   1f0c0:      	str	x9, [x0, #0xc58]
   1f0c4:      	ldr	x10, [x19, #0x5bc0]
   1f0c8:      	ldr	x1, [sp, #0x198]
   1f0cc:      	str	x10, [x1, #0xc60]
   1f0d0:      	ldr	x11, [x19, #0x5bc8]
   1f0d4:      	ldr	x5, [sp, #0x198]
   1f0d8:      	str	x11, [x5, #0xc68]
   1f0dc:      	ldr	x12, [x19, #0x5bd0]
   1f0e0:      	ldr	x7, [sp, #0x198]
   1f0e4:      	str	x12, [x7, #0xc70]
   1f0e8:      	ldr	x13, [x19, #0x5bd8]
   1f0ec:      	ldr	x10, [sp, #0x198]
   1f0f0:      	str	x13, [x10, #0xc78]
   1f0f4:      	mov	x14, #0x0               ; =0
   1f0f8:      	ldr	x13, [sp, #0x198]
   1f0fc:      	str	x14, [x13, #0xc80]
   1f100:      	ldr	x15, [x19, #0x5be8]
   1f104:      	str	x15, [x0, #0xc88]
   1f108:      	ldr	x0, [x19, #0x5bf0]
   1f10c:      	str	x0, [x1, #0xc90]
   1f110:      	ldr	x0, [sp, #0x198]
   1f114:      	str	x14, [x0, #0xc98]
   1f118:      	ldr	x0, [x19, #0x5c00]
   1f11c:      	str	x0, [x1, #0xca0]
   1f120:      	ldr	x0, [x19, #0x5c08]
   1f124:      	str	x0, [x1, #0xca8]
   1f128:      	ldr	x0, [sp, #0x198]
   1f12c:      	str	x14, [x0, #0xcb0]
   1f130:      	ldr	x0, [x19, #0x5c18]
   1f134:      	str	x0, [x1, #0xcb8]
   1f138:      	ldr	x0, [x19, #0x5c20]
   1f13c:      	str	x0, [x1, #0xcc0]
   1f140:      	mov	x1, #0x532              ; =1330
   1f144:      	mov	x2, #-0x9               ; =-9
   1f148:      	ldr	x21, [sp, #0x1a8]
   1f14c:      	ldur	x0, [sp, #0x8]
   1f150:      	mov	x5, x20
   1f154:      	ldr	x6, [sp, #0x1a0]
   1f158:      	blr	x21
   1f15c:      	cmp	x0, #0x0
   1f160:      	b.ne	0x22d8c <_mech_canonical_program_entry_v1_numeric_1282+0x528c>
   1f164:      	mov	x0, #0x3                ; =3
   1f168:      	ldr	x15, [sp, #0x190]
   1f16c:      	mov	x21, x0
   1f170:      	cmp	x15, #0x2
   1f174:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1f178:      	mov	x5, #0x0                ; =0
   1f17c:      	ldr	x3, [sp, #0x198]
   1f180:      	str	x5, [x3]
   1f184:      	ldr	x0, [x19, #0x18a0]
   1f188:      	str	x0, [x3, #0x8]
   1f18c:      	mov	x1, #0x532              ; =1330
   1f190:      	ldur	x0, [sp, #0x8]
   1f194:      	ldr	x6, [sp, #0x1a0]
   1f198:      	ldr	x21, [sp, #0x1a8]
   1f19c:      	mov	x4, x20
   1f1a0:      	mov	x2, x5
   1f1a4:      	blr	x21
   1f1a8:      	cmp	x0, #0x0
   1f1ac:      	b.ne	0x22d94 <_mech_canonical_program_entry_v1_numeric_1282+0x5294>
   1f1b0:      	mov	x0, #0x3                ; =3
   1f1b4:      	mov	x21, x0
   1f1b8:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1f1bc:      	ldr	x0, [sp, #0x158]
   1f1c0:      	stur	x1, [sp, #0x18]
   1f1c4:      	stur	x27, [sp, #0x68]
   1f1c8:      	ldr	x27, [x0, x2, lsl #3]
   1f1cc:      	ldr	x5, [sp, #0x150]
   1f1d0:      	cmp	x4, x5
   1f1d4:      	b.lo	0x1f460 <_mech_canonical_program_entry_v1_numeric_1282+0x1960>
   1f1d8:      	b	0x22d9c <_mech_canonical_program_entry_v1_numeric_1282+0x529c>
   1f1dc:      	ldr	x3, [x19, #0x4c68]
   1f1e0:      	ldr	x4, [x19, #0x4c70]
   1f1e4:      	mov	x0, #0x0                ; =0
   1f1e8:      	str	x0, [x19, #0x4c60]
   1f1ec:      	mov	x0, #0x3                ; =3
   1f1f0:      	ldr	x15, [sp, #0x190]
   1f1f4:      	mov	x21, x0
   1f1f8:      	cmp	x15, #0x19a
   1f1fc:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1f200:      	ldr	x0, [x19, #0x4f70]
   1f204:      	ldr	x1, [sp, #0x198]
   1f208:      	str	x0, [x1, #0x10]
   1f20c:      	ldr	x1, [x19, #0x4f78]
   1f210:      	ldr	x2, [sp, #0x198]
   1f214:      	str	x1, [x2, #0x18]
   1f218:      	ldr	x2, [x19, #0x5a20]
   1f21c:      	ldr	x5, [sp, #0x198]
   1f220:      	str	x2, [x5, #0xac0]
   1f224:      	ldr	x2, [sp, #0x198]
   1f228:      	str	x0, [x2, #0x10]
   1f22c:      	ldr	x0, [sp, #0x198]
   1f230:      	str	x1, [x0, #0x18]
   1f234:      	ldr	x0, [x19, #0x50c0]
   1f238:      	ldr	x1, [sp, #0x198]
   1f23c:      	str	x0, [x1, #0x160]
   1f240:      	ldr	x0, [x19, #0x50c8]
   1f244:      	str	x0, [x1, #0x168]
   1f248:      	ldr	x0, [x19, #0x50d0]
   1f24c:      	str	x0, [x1, #0x170]
   1f250:      	ldr	x0, [x19, #0x50d8]
   1f254:      	str	x0, [x1, #0x178]
   1f258:      	ldr	x0, [x19, #0x50e0]
   1f25c:      	str	x0, [x1, #0x180]
   1f260:      	ldr	x0, [x19, #0x50e8]
   1f264:      	str	x0, [x1, #0x188]
   1f268:      	ldr	x0, [x19, #0x50f0]
   1f26c:      	str	x0, [x1, #0x190]
   1f270:      	ldr	x0, [x19, #0x50f8]
   1f274:      	str	x0, [x5, #0x198]
   1f278:      	ldr	x0, [x19, #0x5100]
   1f27c:      	ldr	x7, [sp, #0x198]
   1f280:      	str	x0, [x7, #0x1a0]
   1f284:      	ldr	x0, [x19, #0x52a8]
   1f288:      	ldr	x10, [sp, #0x198]
   1f28c:      	str	x0, [x10, #0x348]
   1f290:      	ldr	x0, [x19, #0x52b0]
   1f294:      	ldr	x13, [sp, #0x198]
   1f298:      	str	x0, [x13, #0x350]
   1f29c:      	ldr	x0, [x19, #0x52b8]
   1f2a0:      	str	x0, [x1, #0x358]
   1f2a4:      	ldr	x0, [x19, #0x52c0]
   1f2a8:      	str	x0, [x1, #0x360]
   1f2ac:      	ldr	x0, [x19, #0x52c8]
   1f2b0:      	str	x0, [x1, #0x368]
   1f2b4:      	ldr	x0, [x19, #0x52d0]
   1f2b8:      	str	x0, [x1, #0x370]
   1f2bc:      	ldr	x0, [x19, #0x52d8]
   1f2c0:      	str	x0, [x1, #0x378]
   1f2c4:      	ldr	x0, [x19, #0x52e0]
   1f2c8:      	str	x0, [x1, #0x380]
   1f2cc:      	ldr	x0, [x19, #0x52e8]
   1f2d0:      	str	x0, [x1, #0x388]
   1f2d4:      	ldr	x0, [x19, #0x55d8]
   1f2d8:      	str	x0, [x1, #0x678]
   1f2dc:      	ldr	x0, [x19, #0x55e0]
   1f2e0:      	str	x0, [x1, #0x680]
   1f2e4:      	ldr	x0, [x19, #0x55e8]
   1f2e8:      	str	x0, [x1, #0x688]
   1f2ec:      	ldr	x1, [x19, #0x55f0]
   1f2f0:      	ldr	x0, [sp, #0x198]
   1f2f4:      	str	x1, [x0, #0x690]
   1f2f8:      	ldr	x2, [x19, #0x55f8]
   1f2fc:      	str	x2, [x0, #0x698]
   1f300:      	ldr	x5, [x19, #0x5600]
   1f304:      	str	x5, [x0, #0x6a0]
   1f308:      	ldr	x5, [x19, #0x5608]
   1f30c:      	str	x5, [x0, #0x6a8]
   1f310:      	ldr	x5, [x19, #0x5610]
   1f314:      	str	x5, [x0, #0x6b0]
   1f318:      	ldr	x6, [x19, #0x57a0]
   1f31c:      	str	x6, [x0, #0x840]
   1f320:      	ldr	x7, [x19, #0x57a8]
   1f324:      	ldr	x1, [sp, #0x198]
   1f328:      	str	x7, [x1, #0x848]
   1f32c:      	ldr	x8, [x19, #0x57b0]
   1f330:      	ldr	x5, [sp, #0x198]
   1f334:      	str	x8, [x5, #0x850]
   1f338:      	ldr	x9, [x19, #0x57b8]
   1f33c:      	ldr	x7, [sp, #0x198]
   1f340:      	str	x9, [x7, #0x858]
   1f344:      	ldr	x10, [x19, #0x57c0]
   1f348:      	ldr	x11, [sp, #0x198]
   1f34c:      	str	x10, [x11, #0x860]
   1f350:      	ldr	x11, [x19, #0x57c8]
   1f354:      	str	x11, [x13, #0x868]
   1f358:      	ldr	x12, [x19, #0x57d0]
   1f35c:      	str	x12, [x0, #0x870]
   1f360:      	ldr	x13, [x19, #0x57d8]
   1f364:      	str	x13, [x0, #0x878]
   1f368:      	ldr	x14, [x19, #0x5bb0]
   1f36c:      	str	x14, [x0, #0xc50]
   1f370:      	ldr	x15, [x19, #0x5bb8]
   1f374:      	str	x15, [x0, #0xc58]
   1f378:      	ldr	x0, [x19, #0x5bc0]
   1f37c:      	str	x0, [x1, #0xc60]
   1f380:      	ldr	x0, [x19, #0x5bc8]
   1f384:      	str	x0, [x1, #0xc68]
   1f388:      	ldr	x0, [x19, #0x5bd0]
   1f38c:      	str	x0, [x1, #0xc70]
   1f390:      	ldr	x0, [x19, #0x5bd8]
   1f394:      	str	x0, [x1, #0xc78]
   1f398:      	mov	x0, #0x0                ; =0
   1f39c:      	str	x0, [x1, #0xc80]
   1f3a0:      	ldr	x1, [x19, #0x5be8]
   1f3a4:      	ldr	x2, [sp, #0x198]
   1f3a8:      	str	x1, [x2, #0xc88]
   1f3ac:      	ldr	x1, [x19, #0x5bf0]
   1f3b0:      	str	x1, [x2, #0xc90]
   1f3b4:      	ldr	x1, [sp, #0x198]
   1f3b8:      	str	x0, [x1, #0xc98]
   1f3bc:      	ldr	x1, [x19, #0x5c00]
   1f3c0:      	str	x1, [x2, #0xca0]
   1f3c4:      	ldr	x1, [x19, #0x5c08]
   1f3c8:      	str	x1, [x2, #0xca8]
   1f3cc:      	ldr	x1, [sp, #0x198]
   1f3d0:      	str	x0, [x1, #0xcb0]
   1f3d4:      	ldr	x0, [x19, #0x5c18]
   1f3d8:      	str	x0, [x1, #0xcb8]
   1f3dc:      	ldr	x0, [x19, #0x5c20]
   1f3e0:      	str	x0, [x1, #0xcc0]
   1f3e4:      	mov	x1, #0x534              ; =1332
   1f3e8:      	mov	x2, #-0x9               ; =-9
   1f3ec:      	ldr	x21, [sp, #0x1a8]
   1f3f0:      	ldur	x0, [sp, #0x8]
   1f3f4:      	mov	x5, x20
   1f3f8:      	ldr	x6, [sp, #0x1a0]
   1f3fc:      	blr	x21
   1f400:      	cmp	x0, #0x0
   1f404:      	b.ne	0x22f40 <_mech_canonical_program_entry_v1_numeric_1282+0x5440>
   1f408:      	mov	x0, #0x3                ; =3
   1f40c:      	ldr	x15, [sp, #0x190]
   1f410:      	mov	x21, x0
   1f414:      	cmp	x15, #0x2
   1f418:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1f41c:      	mov	x5, #0x0                ; =0
   1f420:      	ldr	x3, [sp, #0x198]
   1f424:      	str	x5, [x3]
   1f428:      	ldr	x0, [x19, #0x18b0]
   1f42c:      	str	x0, [x3, #0x8]
   1f430:      	mov	x1, #0x534              ; =1332
   1f434:      	ldur	x0, [sp, #0x8]
   1f438:      	ldr	x6, [sp, #0x1a0]
   1f43c:      	ldr	x21, [sp, #0x1a8]
   1f440:      	mov	x4, x20
   1f444:      	mov	x2, x5
   1f448:      	blr	x21
   1f44c:      	cmp	x0, #0x0
   1f450:      	b.ne	0x22f48 <_mech_canonical_program_entry_v1_numeric_1282+0x5448>
   1f454:      	mov	x0, #0x3                ; =3
   1f458:      	mov	x21, x0
   1f45c:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1f460:      	ldr	x0, [sp, #0x158]
   1f464:      	ldr	x7, [x0, x4, lsl #3]
   1f468:      	mov	w0, #0x2166             ; =8550
   1f46c:      	movk	w0, #0x1, lsl #16
   1f470:      	sub	x6, x3, x0
   1f474:      	mov	x3, #0x0                ; =0
   1f478:      	ldur	x10, [sp, #0x70]
   1f47c:      	ldur	x15, [sp, #0x10]
   1f480:      	ldur	x0, [sp, #0x68]
   1f484:      	stur	x0, [sp, #0x30]
   1f488:      	ldur	x0, [sp, #0x78]
   1f48c:      	stur	x0, [sp, #0x38]
   1f490:      	ldur	x0, [sp, #0x80]
   1f494:      	stur	x0, [sp, #0x40]
   1f498:      	mov	w0, #0xdc1e             ; =56350
   1f49c:      	movk	w0, #0x2, lsl #16
   1f4a0:      	cmp	x6, x0
   1f4a4:      	b.hs	0x1f8e0 <_mech_canonical_program_entry_v1_numeric_1282+0x1de0>
   1f4a8:      	mov	x1, #0x0                ; =0
   1f4ac:      	str	x1, [x19, #0x18]
   1f4b0:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   1f4b4:      	str	x0, [x19, #0x20]
   1f4b8:      	mov	x0, #0x1                ; =1
   1f4bc:      	str	x0, [x19, #0x30]
   1f4c0:      	mov	x2, #0x101010101010101  ; =72340172838076673
   1f4c4:      	str	x2, [x19, #0x38]
   1f4c8:      	mov	x20, #0x2               ; =2
   1f4cc:      	str	x20, [x19, #0x40]
   1f4d0:      	mov	x2, #0x3                ; =3
   1f4d4:      	str	x2, [x19, #0x48]
   1f4d8:      	mov	x2, #0x4                ; =4
   1f4dc:      	str	x2, [x19, #0x50]
   1f4e0:      	mov	x2, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   1f4e4:      	str	x2, [x19, #0x78]
   1f4e8:      	mov	x2, #0x3333333333333333 ; =3689348814741910323
   1f4ec:      	str	x2, [x19, #0x88]
   1f4f0:      	mov	x2, #0x38               ; =56
   1f4f4:      	str	x2, [x19, #0x90]
   1f4f8:      	mov	x2, #0x3a               ; =58
   1f4fc:      	str	x2, [x19, #0x98]
   1f500:      	mov	x2, #0x5555555555555555 ; =6148914691236517205
   1f504:      	str	x2, [x19, #0xb0]
   1f508:      	mov	x2, #0x3ffffffffffffff  ; =288230376151711743
   1f50c:      	str	x2, [x19, #0xb8]
   1f510:      	str	x1, [x19, #0x188]
   1f514:      	str	x0, [x19, #0x190]
   1f518:      	str	x22, [x19, #0x17a0]
   1f51c:      	str	x23, [x19, #0x17a8]
   1f520:      	ldur	x25, [sp, #0xf0]
   1f524:      	uxtb	w8, w25
   1f528:      	str	x8, [x19, #0x17b8]
   1f52c:      	ldur	x5, [sp, #0x18]
   1f530:      	str	x5, [x19, #0x1858]
   1f534:      	mov	x8, x26
   1f538:      	str	x8, [x19, #0x1860]
   1f53c:      	str	x22, [x19, #0x1868]
   1f540:      	ldur	x1, [sp, #0xe0]
   1f544:      	str	x1, [x19, #0x1870]
   1f548:      	ldur	x1, [sp, #0xd8]
   1f54c:      	uxtb	w14, w1
   1f550:      	str	x14, [x19, #0x1880]
   1f554:      	str	x28, [x19, #0x4c60]
   1f558:      	str	x6, [x19, #0x4c68]
   1f55c:      	ldur	x4, [sp, #0x98]
   1f560:      	str	x4, [x19, #0x4c70]
   1f564:      	str	x22, [x19, #0x4f70]
   1f568:      	str	x23, [x19, #0x4f78]
   1f56c:      	ldur	x1, [sp, #0x18]
   1f570:      	str	x1, [x19, #0x50c0]
   1f574:      	mov	x1, x26
   1f578:      	str	x1, [x19, #0x50c8]
   1f57c:      	str	x22, [x19, #0x50d0]
   1f580:      	ldur	x1, [sp, #0xe0]
   1f584:      	str	x1, [x19, #0x50d8]
   1f588:      	ldur	x24, [sp, #0x10]
   1f58c:      	str	x24, [x19, #0x50e0]
   1f590:      	ldur	x26, [sp, #0x68]
   1f594:      	str	x26, [x19, #0x50e8]
   1f598:      	ldur	x1, [sp, #0x70]
   1f59c:      	str	x1, [x19, #0x50f0]
   1f5a0:      	ldur	x24, [sp, #0x78]
   1f5a4:      	str	x24, [x19, #0x50f8]
   1f5a8:      	ldur	x26, [sp, #0x80]
   1f5ac:      	str	x26, [x19, #0x5100]
   1f5b0:      	ldur	x24, [sp, #0x10]
   1f5b4:      	str	x24, [x19, #0x5178]
   1f5b8:      	ldur	x26, [sp, #0x68]
   1f5bc:      	str	x26, [x19, #0x5180]
   1f5c0:      	str	x1, [x19, #0x5188]
   1f5c4:      	ldur	x24, [sp, #0x78]
   1f5c8:      	str	x24, [x19, #0x5190]
   1f5cc:      	ldur	x26, [sp, #0x80]
   1f5d0:      	str	x26, [x19, #0x5198]
   1f5d4:      	str	x27, [x19, #0x52a8]
   1f5d8:      	str	x7, [x19, #0x52b0]
   1f5dc:      	str	x22, [x19, #0x52b8]
   1f5e0:      	ldur	x1, [sp, #0xe0]
   1f5e4:      	str	x1, [x19, #0x52c0]
   1f5e8:      	str	x15, [x19, #0x52c8]
   1f5ec:      	ldur	x15, [sp, #0x30]
   1f5f0:      	str	x15, [x19, #0x52d0]
   1f5f4:      	mov	x24, x10
   1f5f8:      	str	x24, [x19, #0x52d8]
   1f5fc:      	ldur	x24, [sp, #0x38]
   1f600:      	str	x24, [x19, #0x52e0]
   1f604:      	ldur	x15, [sp, #0x40]
   1f608:      	str	x15, [x19, #0x52e8]
   1f60c:      	ldur	x14, [sp, #0x60]
   1f610:      	str	x14, [x19, #0x5a20]
   1f614:      	add	x1, x11, #0x1
   1f618:      	str	x1, [x19, #0x5bb0]
   1f61c:      	ldur	x26, [sp, #0xa0]
   1f620:      	str	x26, [x19, #0x5bb8]
   1f624:      	ldur	x7, [sp, #0xa8]
   1f628:      	str	x7, [x19, #0x5bc0]
   1f62c:      	ldur	x4, [sp, #0x90]
   1f630:      	sub	x2, x4, x6
   1f634:      	mov	w4, #0xc87e             ; =51326
   1f638:      	movk	w4, #0x1, lsl #16
   1f63c:      	msub	x1, x1, x4, x2
   1f640:      	str	x1, [x19, #0x5bc8]
   1f644:      	str	x0, [x19, #0x5bd0]
   1f648:      	ldur	x14, [sp, #0x20]
   1f64c:      	str	x14, [x19, #0x5bd8]
   1f650:      	str	x0, [x19, #0x5be8]
   1f654:      	str	x3, [x19, #0x5bf0]
   1f658:      	str	x12, [x19, #0x5c00]
   1f65c:      	str	x9, [x19, #0x5c08]
   1f660:      	str	x13, [x19, #0x5c18]
   1f664:      	ldur	x13, [sp, #0xc0]
   1f668:      	str	x13, [x19, #0x5c20]
   1f66c:      	ldr	x0, [x19, #0x4c60]
   1f670:      	cmp	x0, #0x0
   1f674:      	b.eq	0x1f8b8 <_mech_canonical_program_entry_v1_numeric_1282+0x1db8>
   1f678:      	ldr	x3, [x19, #0x4c68]
   1f67c:      	ldr	x4, [x19, #0x4c70]
   1f680:      	mov	x0, #0x0                ; =0
   1f684:      	str	x0, [x19, #0x4c60]
   1f688:      	mov	x0, #0x3                ; =3
   1f68c:      	ldr	x15, [sp, #0x190]
   1f690:      	mov	x21, x0
   1f694:      	cmp	x15, #0x19a
   1f698:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1f69c:      	ldr	x0, [x19, #0x4f70]
   1f6a0:      	ldr	x15, [sp, #0x198]
   1f6a4:      	str	x0, [x15, #0x10]
   1f6a8:      	ldr	x1, [x19, #0x4f78]
   1f6ac:      	ldr	x2, [sp, #0x198]
   1f6b0:      	str	x1, [x2, #0x18]
   1f6b4:      	ldr	x2, [x19, #0x5a20]
   1f6b8:      	ldr	x5, [sp, #0x198]
   1f6bc:      	str	x2, [x5, #0xac0]
   1f6c0:      	ldr	x2, [x19, #0x5178]
   1f6c4:      	str	x2, [x5, #0x218]
   1f6c8:      	ldr	x2, [x19, #0x5180]
   1f6cc:      	str	x2, [x5, #0x220]
   1f6d0:      	ldr	x5, [x19, #0x5188]
   1f6d4:      	ldr	x2, [sp, #0x198]
   1f6d8:      	str	x5, [x2, #0x228]
   1f6dc:      	ldr	x5, [x19, #0x5190]
   1f6e0:      	str	x5, [x2, #0x230]
   1f6e4:      	ldr	x5, [x19, #0x5198]
   1f6e8:      	str	x5, [x2, #0x238]
   1f6ec:      	str	x0, [x2, #0x10]
   1f6f0:      	ldr	x0, [sp, #0x198]
   1f6f4:      	str	x1, [x0, #0x18]
   1f6f8:      	ldr	x8, [x19, #0x50c0]
   1f6fc:      	str	x8, [x0, #0x160]
   1f700:      	ldr	x9, [x19, #0x50c8]
   1f704:      	str	x9, [x0, #0x168]
   1f708:      	ldr	x10, [x19, #0x50d0]
   1f70c:      	str	x10, [x0, #0x170]
   1f710:      	ldr	x11, [x19, #0x50d8]
   1f714:      	str	x11, [x0, #0x178]
   1f718:      	ldr	x12, [x19, #0x50e0]
   1f71c:      	str	x12, [x0, #0x180]
   1f720:      	ldr	x13, [x19, #0x50e8]
   1f724:      	str	x13, [x0, #0x188]
   1f728:      	ldr	x14, [x19, #0x50f0]
   1f72c:      	str	x14, [x0, #0x190]
   1f730:      	ldr	x15, [x19, #0x50f8]
   1f734:      	ldr	x1, [sp, #0x198]
   1f738:      	str	x15, [x1, #0x198]
   1f73c:      	ldr	x0, [x19, #0x5100]
   1f740:      	ldr	x5, [sp, #0x198]
   1f744:      	str	x0, [x5, #0x1a0]
   1f748:      	ldr	x0, [x19, #0x52a8]
   1f74c:      	ldr	x7, [sp, #0x198]
   1f750:      	str	x0, [x7, #0x348]
   1f754:      	ldr	x0, [x19, #0x52b0]
   1f758:      	ldr	x10, [sp, #0x198]
   1f75c:      	str	x0, [x10, #0x350]
   1f760:      	ldr	x0, [x19, #0x52b8]
   1f764:      	ldr	x13, [sp, #0x198]
   1f768:      	str	x0, [x13, #0x358]
   1f76c:      	ldr	x0, [x19, #0x52c0]
   1f770:      	str	x0, [x1, #0x360]
   1f774:      	ldr	x0, [x19, #0x52c8]
   1f778:      	str	x0, [x1, #0x368]
   1f77c:      	ldr	x0, [x19, #0x52d0]
   1f780:      	str	x0, [x1, #0x370]
   1f784:      	ldr	x0, [x19, #0x52d8]
   1f788:      	str	x0, [x1, #0x378]
   1f78c:      	ldr	x0, [x19, #0x52e0]
   1f790:      	str	x0, [x1, #0x380]
   1f794:      	ldr	x0, [x19, #0x52e8]
   1f798:      	str	x0, [x1, #0x388]
   1f79c:      	ldr	x0, [x19, #0x55d8]
   1f7a0:      	str	x0, [x1, #0x678]
   1f7a4:      	ldr	x0, [x19, #0x55e0]
   1f7a8:      	str	x0, [x1, #0x680]
   1f7ac:      	ldr	x0, [x19, #0x55e8]
   1f7b0:      	str	x0, [x1, #0x688]
   1f7b4:      	ldr	x0, [x19, #0x55f0]
   1f7b8:      	str	x0, [x1, #0x690]
   1f7bc:      	ldr	x0, [x19, #0x55f8]
   1f7c0:      	str	x0, [x1, #0x698]
   1f7c4:      	ldr	x0, [x19, #0x5600]
   1f7c8:      	str	x0, [x1, #0x6a0]
   1f7cc:      	ldr	x0, [x19, #0x5608]
   1f7d0:      	str	x0, [x1, #0x6a8]
   1f7d4:      	ldr	x0, [x19, #0x5610]
   1f7d8:      	str	x0, [x1, #0x6b0]
   1f7dc:      	ldr	x0, [x19, #0x57a0]
   1f7e0:      	str	x0, [x1, #0x840]
   1f7e4:      	ldr	x0, [x19, #0x57a8]
   1f7e8:      	str	x0, [x1, #0x848]
   1f7ec:      	ldr	x0, [x19, #0x57b0]
   1f7f0:      	str	x0, [x1, #0x850]
   1f7f4:      	ldr	x0, [x19, #0x57b8]
   1f7f8:      	str	x0, [x5, #0x858]
   1f7fc:      	ldr	x0, [x19, #0x57c0]
   1f800:      	str	x0, [x7, #0x860]
   1f804:      	ldr	x0, [x19, #0x57c8]
   1f808:      	str	x0, [x10, #0x868]
   1f80c:      	ldr	x0, [x19, #0x57d0]
   1f810:      	str	x0, [x13, #0x870]
   1f814:      	ldr	x0, [x19, #0x57d8]
   1f818:      	str	x0, [x1, #0x878]
   1f81c:      	ldr	x0, [x19, #0x5bb0]
   1f820:      	str	x0, [x1, #0xc50]
   1f824:      	ldr	x0, [x19, #0x5bb8]
   1f828:      	str	x0, [x1, #0xc58]
   1f82c:      	ldr	x0, [x19, #0x5bc0]
   1f830:      	str	x0, [x1, #0xc60]
   1f834:      	ldr	x0, [x19, #0x5bc8]
   1f838:      	str	x0, [x1, #0xc68]
   1f83c:      	ldr	x0, [x19, #0x5bd0]
   1f840:      	str	x0, [x1, #0xc70]
   1f844:      	ldr	x0, [x19, #0x5bd8]
   1f848:      	str	x0, [x1, #0xc78]
   1f84c:      	mov	x0, #0x0                ; =0
   1f850:      	str	x0, [x1, #0xc80]
   1f854:      	ldr	x1, [x19, #0x5be8]
   1f858:      	str	x1, [x2, #0xc88]
   1f85c:      	ldr	x1, [x19, #0x5bf0]
   1f860:      	str	x1, [x2, #0xc90]
   1f864:      	ldr	x1, [sp, #0x198]
   1f868:      	str	x0, [x1, #0xc98]
   1f86c:      	ldr	x1, [x19, #0x5c00]
   1f870:      	str	x1, [x2, #0xca0]
   1f874:      	ldr	x1, [x19, #0x5c08]
   1f878:      	str	x1, [x2, #0xca8]
   1f87c:      	ldr	x1, [sp, #0x198]
   1f880:      	str	x0, [x1, #0xcb0]
   1f884:      	ldr	x0, [x19, #0x5c18]
   1f888:      	str	x0, [x1, #0xcb8]
   1f88c:      	ldr	x0, [x19, #0x5c20]
   1f890:      	str	x0, [x1, #0xcc0]
   1f894:      	mov	x1, #0x53d              ; =1341
   1f898:      	mov	x2, #-0x9               ; =-9
   1f89c:      	mov	x5, #0x1                ; =1
   1f8a0:      	ldur	x0, [sp, #0x8]
   1f8a4:      	ldr	x6, [sp, #0x1a0]
   1f8a8:      	ldr	x21, [sp, #0x1a8]
   1f8ac:      	blr	x21
   1f8b0:      	cmp	x0, #0x0
   1f8b4:      	b.ne	0x22f50 <_mech_canonical_program_entry_v1_numeric_1282+0x5450>
   1f8b8:      	mov	x0, #0x0                ; =0
   1f8bc:      	mov	x1, #0x3                ; =3
   1f8c0:      	add	sp, sp, #0x1c0
   1f8c4:      	ldp	x19, x20, [sp], #0x10
   1f8c8:      	ldp	x21, x22, [sp], #0x10
   1f8cc:      	ldp	x23, x24, [sp], #0x10
   1f8d0:      	ldp	x25, x26, [sp], #0x10
   1f8d4:      	ldp	x27, x28, [sp], #0x10
   1f8d8:      	ldp	x29, x30, [sp], #0x10
   1f8dc:      	retab
   1f8e0:      	stur	x15, [sp, #0x28]
   1f8e4:      	mov	x24, x10
   1f8e8:      	ldur	x15, [sp, #0x30]
   1f8ec:      	cmp	x27, x7
   1f8f0:      	cset	x10, lo
   1f8f4:      	cmp	x27, x7
   1f8f8:      	b.lo	0x1f930 <_mech_canonical_program_entry_v1_numeric_1282+0x1e30>
   1f8fc:      	ldur	x0, [sp, #0x40]
   1f900:      	ldur	x1, [sp, #0x38]
   1f904:      	ldur	x2, [sp, #0x28]
   1f908:      	ldur	x4, [sp, #0x40]
   1f90c:      	ldur	x5, [sp, #0x38]
   1f910:      	mov	x8, x24
   1f914:      	mov	x10, x15
   1f918:      	mov	x14, x27
   1f91c:      	str	x28, [sp, #0x1b0]
   1f920:      	ldur	x28, [sp, #0x28]
   1f924:      	stur	x28, [sp, #0x48]
   1f928:      	ldr	x28, [sp, #0x1b0]
   1f92c:      	b	0x1ffd8 <_mech_canonical_program_entry_v1_numeric_1282+0x24d8>
   1f930:      	ldr	x8, [sp, #0x140]
   1f934:      	cmp	x27, x8
   1f938:      	b.lo	0x1fbbc <_mech_canonical_program_entry_v1_numeric_1282+0x20bc>
   1f93c:      	b	0x22f58 <_mech_canonical_program_entry_v1_numeric_1282+0x5458>
   1f940:      	ldr	x3, [x19, #0x4c68]
   1f944:      	ldr	x4, [x19, #0x4c70]
   1f948:      	mov	x0, #0x0                ; =0
   1f94c:      	str	x0, [x19, #0x4c60]
   1f950:      	mov	x0, #0x3                ; =3
   1f954:      	ldr	x15, [sp, #0x190]
   1f958:      	mov	x21, x0
   1f95c:      	cmp	x15, #0x19a
   1f960:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1f964:      	ldr	x0, [x19, #0x4f70]
   1f968:      	ldr	x10, [sp, #0x198]
   1f96c:      	str	x0, [x10, #0x10]
   1f970:      	ldr	x1, [x19, #0x4f78]
   1f974:      	ldr	x13, [sp, #0x198]
   1f978:      	str	x1, [x13, #0x18]
   1f97c:      	ldr	x2, [x19, #0x5a20]
   1f980:      	ldr	x5, [sp, #0x198]
   1f984:      	str	x2, [x5, #0xac0]
   1f988:      	ldr	x2, [sp, #0x198]
   1f98c:      	str	x0, [x2, #0x10]
   1f990:      	ldr	x0, [sp, #0x198]
   1f994:      	str	x1, [x0, #0x18]
   1f998:      	ldr	x0, [x19, #0x50c0]
   1f99c:      	ldr	x1, [sp, #0x198]
   1f9a0:      	str	x0, [x1, #0x160]
   1f9a4:      	ldr	x0, [x19, #0x50c8]
   1f9a8:      	str	x0, [x1, #0x168]
   1f9ac:      	ldr	x0, [x19, #0x50d0]
   1f9b0:      	str	x0, [x1, #0x170]
   1f9b4:      	ldr	x0, [x19, #0x50d8]
   1f9b8:      	str	x0, [x1, #0x178]
   1f9bc:      	ldr	x0, [x19, #0x50e0]
   1f9c0:      	str	x0, [x1, #0x180]
   1f9c4:      	ldr	x0, [x19, #0x50e8]
   1f9c8:      	str	x0, [x1, #0x188]
   1f9cc:      	ldr	x0, [x19, #0x50f0]
   1f9d0:      	str	x0, [x1, #0x190]
   1f9d4:      	ldr	x0, [x19, #0x50f8]
   1f9d8:      	str	x0, [x1, #0x198]
   1f9dc:      	ldr	x0, [x19, #0x5100]
   1f9e0:      	str	x0, [x1, #0x1a0]
   1f9e4:      	ldr	x0, [x19, #0x52a8]
   1f9e8:      	str	x0, [x1, #0x348]
   1f9ec:      	ldr	x0, [x19, #0x52b0]
   1f9f0:      	str	x0, [x1, #0x350]
   1f9f4:      	ldr	x0, [x19, #0x52b8]
   1f9f8:      	str	x0, [x1, #0x358]
   1f9fc:      	ldr	x0, [x19, #0x52c0]
   1fa00:      	str	x0, [x1, #0x360]
   1fa04:      	ldr	x0, [x19, #0x52c8]
   1fa08:      	str	x0, [x1, #0x368]
   1fa0c:      	ldr	x0, [x19, #0x52d0]
   1fa10:      	str	x0, [x2, #0x370]
   1fa14:      	ldr	x0, [x19, #0x52d8]
   1fa18:      	str	x0, [x5, #0x378]
   1fa1c:      	ldr	x0, [x19, #0x52e0]
   1fa20:      	ldr	x8, [sp, #0x198]
   1fa24:      	str	x0, [x8, #0x380]
   1fa28:      	ldr	x0, [x19, #0x52e8]
   1fa2c:      	ldr	x11, [sp, #0x198]
   1fa30:      	str	x0, [x11, #0x388]
   1fa34:      	ldr	x0, [x19, #0x55d8]
   1fa38:      	ldr	x14, [sp, #0x198]
   1fa3c:      	str	x0, [x14, #0x678]
   1fa40:      	ldr	x0, [x19, #0x55e0]
   1fa44:      	str	x0, [x1, #0x680]
   1fa48:      	ldr	x0, [x19, #0x55e8]
   1fa4c:      	str	x0, [x1, #0x688]
   1fa50:      	ldr	x0, [x19, #0x55f0]
   1fa54:      	str	x0, [x1, #0x690]
   1fa58:      	ldr	x0, [x19, #0x55f8]
   1fa5c:      	str	x0, [x1, #0x698]
   1fa60:      	ldr	x0, [x19, #0x5600]
   1fa64:      	str	x0, [x1, #0x6a0]
   1fa68:      	ldr	x0, [x19, #0x5608]
   1fa6c:      	str	x0, [x1, #0x6a8]
   1fa70:      	ldr	x0, [x19, #0x5610]
   1fa74:      	str	x0, [x1, #0x6b0]
   1fa78:      	ldr	x0, [x19, #0x57a0]
   1fa7c:      	str	x0, [x1, #0x840]
   1fa80:      	ldr	x0, [x19, #0x57a8]
   1fa84:      	str	x0, [x1, #0x848]
   1fa88:      	ldr	x0, [x19, #0x57b0]
   1fa8c:      	str	x0, [x1, #0x850]
   1fa90:      	ldr	x1, [x19, #0x57b8]
   1fa94:      	ldr	x0, [sp, #0x198]
   1fa98:      	str	x1, [x0, #0x858]
   1fa9c:      	ldr	x2, [x19, #0x57c0]
   1faa0:      	str	x2, [x0, #0x860]
   1faa4:      	ldr	x5, [x19, #0x57c8]
   1faa8:      	str	x5, [x0, #0x868]
   1faac:      	ldr	x5, [x19, #0x57d0]
   1fab0:      	str	x5, [x0, #0x870]
   1fab4:      	ldr	x5, [x19, #0x57d8]
   1fab8:      	str	x5, [x0, #0x878]
   1fabc:      	ldr	x6, [x19, #0x5bb0]
   1fac0:      	str	x6, [x0, #0xc50]
   1fac4:      	ldr	x7, [x19, #0x5bb8]
   1fac8:      	ldr	x2, [sp, #0x198]
   1facc:      	str	x7, [x2, #0xc58]
   1fad0:      	ldr	x8, [x19, #0x5bc0]
   1fad4:      	ldr	x5, [sp, #0x198]
   1fad8:      	str	x8, [x5, #0xc60]
   1fadc:      	ldr	x9, [x19, #0x5bc8]
   1fae0:      	ldr	x8, [sp, #0x198]
   1fae4:      	str	x9, [x8, #0xc68]
   1fae8:      	ldr	x10, [x19, #0x5bd0]
   1faec:      	str	x10, [x11, #0xc70]
   1faf0:      	ldr	x11, [x19, #0x5bd8]
   1faf4:      	str	x11, [x14, #0xc78]
   1faf8:      	mov	x12, #0x0               ; =0
   1fafc:      	str	x12, [x0, #0xc80]
   1fb00:      	ldr	x13, [x19, #0x5be8]
   1fb04:      	str	x13, [x0, #0xc88]
   1fb08:      	ldr	x14, [x19, #0x5bf0]
   1fb0c:      	str	x14, [x0, #0xc90]
   1fb10:      	str	x12, [x0, #0xc98]
   1fb14:      	ldr	x0, [x19, #0x5c00]
   1fb18:      	ldr	x1, [sp, #0x198]
   1fb1c:      	str	x0, [x1, #0xca0]
   1fb20:      	ldr	x0, [x19, #0x5c08]
   1fb24:      	str	x0, [x1, #0xca8]
   1fb28:      	ldr	x0, [sp, #0x198]
   1fb2c:      	str	x12, [x0, #0xcb0]
   1fb30:      	ldr	x0, [x19, #0x5c18]
   1fb34:      	str	x0, [x1, #0xcb8]
   1fb38:      	ldr	x0, [x19, #0x5c20]
   1fb3c:      	str	x0, [x1, #0xcc0]
   1fb40:      	mov	x1, #0x54e              ; =1358
   1fb44:      	mov	x2, #-0x9               ; =-9
   1fb48:      	ldr	x21, [sp, #0x1a8]
   1fb4c:      	ldur	x0, [sp, #0x8]
   1fb50:      	mov	x5, x25
   1fb54:      	ldr	x6, [sp, #0x1a0]
   1fb58:      	blr	x21
   1fb5c:      	cmp	x0, #0x0
   1fb60:      	b.ne	0x23140 <_mech_canonical_program_entry_v1_numeric_1282+0x5640>
   1fb64:      	mov	x0, #0x3                ; =3
   1fb68:      	ldr	x15, [sp, #0x190]
   1fb6c:      	mov	x21, x0
   1fb70:      	cmp	x15, #0x2
   1fb74:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1fb78:      	mov	x5, #0x0                ; =0
   1fb7c:      	ldr	x3, [sp, #0x198]
   1fb80:      	str	x5, [x3]
   1fb84:      	ldr	x0, [x19, #0x1950]
   1fb88:      	str	x0, [x3, #0x8]
   1fb8c:      	mov	x1, #0x54e              ; =1358
   1fb90:      	ldur	x0, [sp, #0x8]
   1fb94:      	ldr	x6, [sp, #0x1a0]
   1fb98:      	ldr	x21, [sp, #0x1a8]
   1fb9c:      	mov	x4, x25
   1fba0:      	mov	x2, x5
   1fba4:      	blr	x21
   1fba8:      	cmp	x0, #0x0
   1fbac:      	b.ne	0x23148 <_mech_canonical_program_entry_v1_numeric_1282+0x5648>
   1fbb0:      	mov	x0, #0x3                ; =3
   1fbb4:      	mov	x21, x0
   1fbb8:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1fbbc:      	ldur	x0, [sp, #0x40]
   1fbc0:      	ldur	x1, [sp, #0x38]
   1fbc4:      	ldur	x2, [sp, #0x28]
   1fbc8:      	ldr	x4, [sp, #0x148]
   1fbcc:      	ldr	x14, [x4, x27, lsl #3]
   1fbd0:      	cmp	x14, x22
   1fbd4:      	b.ne	0x1fbf4 <_mech_canonical_program_entry_v1_numeric_1282+0x20f4>
   1fbd8:      	mov	x4, x0
   1fbdc:      	mov	x5, x1
   1fbe0:      	mov	x8, x24
   1fbe4:      	mov	x10, x15
   1fbe8:      	mov	x14, x27
   1fbec:      	stur	x2, [sp, #0x48]
   1fbf0:      	b	0x1ff90 <_mech_canonical_program_entry_v1_numeric_1282+0x2490>
   1fbf4:      	add	x4, x14, #0x1
   1fbf8:      	cmp	x4, x14
   1fbfc:      	b.lo	0x23150 <_mech_canonical_program_entry_v1_numeric_1282+0x5650>
   1fc00:      	ldr	x5, [sp, #0x170]
   1fc04:      	cmp	x14, x5
   1fc08:      	b.lo	0x1fe9c <_mech_canonical_program_entry_v1_numeric_1282+0x239c>
   1fc0c:      	b	0x232b4 <_mech_canonical_program_entry_v1_numeric_1282+0x57b4>
   1fc10:      	ldr	x3, [x19, #0x4c68]
   1fc14:      	ldr	x4, [x19, #0x4c70]
   1fc18:      	mov	x0, #0x0                ; =0
   1fc1c:      	str	x0, [x19, #0x4c60]
   1fc20:      	mov	x0, #0x3                ; =3
   1fc24:      	ldr	x15, [sp, #0x190]
   1fc28:      	mov	x21, x0
   1fc2c:      	cmp	x15, #0x19a
   1fc30:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1fc34:      	ldr	x0, [x19, #0x4f70]
   1fc38:      	ldr	x6, [sp, #0x198]
   1fc3c:      	str	x0, [x6, #0x10]
   1fc40:      	ldr	x1, [x19, #0x4f78]
   1fc44:      	ldr	x9, [sp, #0x198]
   1fc48:      	str	x1, [x9, #0x18]
   1fc4c:      	ldr	x2, [x19, #0x5a20]
   1fc50:      	ldr	x12, [sp, #0x198]
   1fc54:      	str	x2, [x12, #0xac0]
   1fc58:      	ldr	x14, [sp, #0x198]
   1fc5c:      	str	x0, [x14, #0x10]
   1fc60:      	ldr	x0, [sp, #0x198]
   1fc64:      	str	x1, [x0, #0x18]
   1fc68:      	ldr	x0, [x19, #0x50c0]
   1fc6c:      	ldr	x1, [sp, #0x198]
   1fc70:      	str	x0, [x1, #0x160]
   1fc74:      	ldr	x0, [x19, #0x50c8]
   1fc78:      	str	x0, [x1, #0x168]
   1fc7c:      	ldr	x0, [x19, #0x50d0]
   1fc80:      	str	x0, [x1, #0x170]
   1fc84:      	ldr	x0, [x19, #0x50d8]
   1fc88:      	str	x0, [x1, #0x178]
   1fc8c:      	ldr	x0, [x19, #0x50e0]
   1fc90:      	str	x0, [x1, #0x180]
   1fc94:      	ldr	x0, [x19, #0x50e8]
   1fc98:      	str	x0, [x1, #0x188]
   1fc9c:      	ldr	x0, [x19, #0x50f0]
   1fca0:      	str	x0, [x1, #0x190]
   1fca4:      	ldr	x0, [x19, #0x50f8]
   1fca8:      	str	x0, [x1, #0x198]
   1fcac:      	ldr	x0, [x19, #0x5100]
   1fcb0:      	str	x0, [x1, #0x1a0]
   1fcb4:      	ldr	x0, [x19, #0x52a8]
   1fcb8:      	str	x0, [x1, #0x348]
   1fcbc:      	ldr	x0, [x19, #0x52b0]
   1fcc0:      	str	x0, [x1, #0x350]
   1fcc4:      	ldr	x0, [x19, #0x52b8]
   1fcc8:      	str	x0, [x1, #0x358]
   1fccc:      	ldr	x0, [x19, #0x52c0]
   1fcd0:      	str	x0, [x1, #0x360]
   1fcd4:      	ldr	x0, [x19, #0x52c8]
   1fcd8:      	str	x0, [x1, #0x368]
   1fcdc:      	ldr	x0, [x19, #0x52d0]
   1fce0:      	str	x0, [x1, #0x370]
   1fce4:      	ldr	x0, [x19, #0x52d8]
   1fce8:      	str	x0, [x1, #0x378]
   1fcec:      	ldr	x0, [x19, #0x52e0]
   1fcf0:      	ldr	x5, [sp, #0x198]
   1fcf4:      	str	x0, [x5, #0x380]
   1fcf8:      	ldr	x1, [x19, #0x52e8]
   1fcfc:      	ldr	x7, [sp, #0x198]
   1fd00:      	str	x1, [x7, #0x388]
   1fd04:      	ldr	x2, [x19, #0x55d8]
   1fd08:      	ldr	x10, [sp, #0x198]
   1fd0c:      	str	x2, [x10, #0x678]
   1fd10:      	ldr	x5, [x19, #0x55e0]
   1fd14:      	ldr	x13, [sp, #0x198]
   1fd18:      	str	x5, [x13, #0x680]
   1fd1c:      	ldr	x5, [x19, #0x55e8]
   1fd20:      	ldr	x0, [sp, #0x198]
   1fd24:      	str	x5, [x0, #0x688]
   1fd28:      	ldr	x5, [x19, #0x55f0]
   1fd2c:      	str	x5, [x0, #0x690]
   1fd30:      	ldr	x6, [x19, #0x55f8]
   1fd34:      	str	x6, [x0, #0x698]
   1fd38:      	ldr	x7, [x19, #0x5600]
   1fd3c:      	str	x7, [x0, #0x6a0]
   1fd40:      	ldr	x8, [x19, #0x5608]
   1fd44:      	str	x8, [x0, #0x6a8]
   1fd48:      	ldr	x9, [x19, #0x5610]
   1fd4c:      	str	x9, [x0, #0x6b0]
   1fd50:      	ldr	x10, [x19, #0x57a0]
   1fd54:      	str	x10, [x0, #0x840]
   1fd58:      	ldr	x11, [x19, #0x57a8]
   1fd5c:      	str	x11, [x0, #0x848]
   1fd60:      	ldr	x12, [x19, #0x57b0]
   1fd64:      	str	x12, [x0, #0x850]
   1fd68:      	ldr	x13, [x19, #0x57b8]
   1fd6c:      	str	x13, [x0, #0x858]
   1fd70:      	ldr	x14, [x19, #0x57c0]
   1fd74:      	str	x14, [x0, #0x860]
   1fd78:      	ldr	x15, [x19, #0x57c8]
   1fd7c:      	str	x15, [x0, #0x868]
   1fd80:      	ldr	x0, [x19, #0x57d0]
   1fd84:      	ldr	x1, [sp, #0x198]
   1fd88:      	str	x0, [x1, #0x870]
   1fd8c:      	ldr	x0, [x19, #0x57d8]
   1fd90:      	str	x0, [x1, #0x878]
   1fd94:      	ldr	x0, [x19, #0x5bb0]
   1fd98:      	str	x0, [x1, #0xc50]
   1fd9c:      	ldr	x0, [x19, #0x5bb8]
   1fda0:      	str	x0, [x1, #0xc58]
   1fda4:      	ldr	x0, [x19, #0x5bc0]
   1fda8:      	str	x0, [x1, #0xc60]
   1fdac:      	ldr	x0, [x19, #0x5bc8]
   1fdb0:      	ldr	x5, [sp, #0x198]
   1fdb4:      	str	x0, [x5, #0xc68]
   1fdb8:      	ldr	x0, [x19, #0x5bd0]
   1fdbc:      	ldr	x7, [sp, #0x198]
   1fdc0:      	str	x0, [x7, #0xc70]
   1fdc4:      	ldr	x0, [x19, #0x5bd8]
   1fdc8:      	ldr	x10, [sp, #0x198]
   1fdcc:      	str	x0, [x10, #0xc78]
   1fdd0:      	mov	x0, #0x0                ; =0
   1fdd4:      	ldr	x13, [sp, #0x198]
   1fdd8:      	str	x0, [x13, #0xc80]
   1fddc:      	ldr	x1, [x19, #0x5be8]
   1fde0:      	ldr	x2, [sp, #0x198]
   1fde4:      	str	x1, [x2, #0xc88]
   1fde8:      	ldr	x1, [x19, #0x5bf0]
   1fdec:      	str	x1, [x2, #0xc90]
   1fdf0:      	ldr	x1, [sp, #0x198]
   1fdf4:      	str	x0, [x1, #0xc98]
   1fdf8:      	ldr	x1, [x19, #0x5c00]
   1fdfc:      	str	x1, [x2, #0xca0]
   1fe00:      	ldr	x1, [x19, #0x5c08]
   1fe04:      	str	x1, [x2, #0xca8]
   1fe08:      	ldr	x1, [sp, #0x198]
   1fe0c:      	str	x0, [x1, #0xcb0]
   1fe10:      	ldr	x0, [x19, #0x5c18]
   1fe14:      	str	x0, [x1, #0xcb8]
   1fe18:      	ldr	x0, [x19, #0x5c20]
   1fe1c:      	str	x0, [x1, #0xcc0]
   1fe20:      	mov	x1, #0x555              ; =1365
   1fe24:      	mov	x2, #-0x9               ; =-9
   1fe28:      	ldr	x21, [sp, #0x1a8]
   1fe2c:      	ldur	x0, [sp, #0x8]
   1fe30:      	mov	x5, x20
   1fe34:      	ldr	x6, [sp, #0x1a0]
   1fe38:      	blr	x21
   1fe3c:      	cmp	x0, #0x0
   1fe40:      	b.ne	0x23490 <_mech_canonical_program_entry_v1_numeric_1282+0x5990>
   1fe44:      	mov	x0, #0x3                ; =3
   1fe48:      	ldr	x15, [sp, #0x190]
   1fe4c:      	mov	x21, x0
   1fe50:      	cmp	x15, #0x2
   1fe54:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1fe58:      	mov	x5, #0x0                ; =0
   1fe5c:      	ldr	x3, [sp, #0x198]
   1fe60:      	str	x5, [x3]
   1fe64:      	ldr	x0, [x19, #0x1970]
   1fe68:      	str	x0, [x3, #0x8]
   1fe6c:      	mov	x1, #0x555              ; =1365
   1fe70:      	ldur	x0, [sp, #0x8]
   1fe74:      	ldr	x6, [sp, #0x1a0]
   1fe78:      	ldr	x21, [sp, #0x1a8]
   1fe7c:      	mov	x4, x20
   1fe80:      	mov	x2, x5
   1fe84:      	blr	x21
   1fe88:      	cmp	x0, #0x0
   1fe8c:      	b.ne	0x23498 <_mech_canonical_program_entry_v1_numeric_1282+0x5998>
   1fe90:      	mov	x0, #0x3                ; =3
   1fe94:      	mov	x21, x0
   1fe98:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1fe9c:      	ldr	x4, [sp, #0x178]
   1fea0:      	ldr	x4, [x4, x14, lsl #3]
   1fea4:      	ldur	x5, [sp, #0xe0]
   1fea8:      	and	x4, x5, x4
   1feac:      	fmov	d16, x4
   1feb0:      	cnt.8b	v16, v16
   1feb4:      	addv.8b	b16, v16
   1feb8:      	umov.b	w4, v16[0]
   1febc:      	eor	x14, x14, #0x3ffffffffffffff
   1fec0:      	orr	x14, x14, x4, lsl #58
   1fec4:      	cmp	x14, x0
   1fec8:      	cset	x4, hi
   1fecc:      	cmp	x14, x2
   1fed0:      	cset	x5, ne
   1fed4:      	and	w4, w4, w5
   1fed8:      	cmp	x14, x15
   1fedc:      	cset	x5, ne
   1fee0:      	and	w4, w4, w5
   1fee4:      	cmp	x14, x24
   1fee8:      	cset	x5, ne
   1feec:      	and	w4, w4, w5
   1fef0:      	cmp	x14, x1
   1fef4:      	cset	x5, ne
   1fef8:      	and	w4, w4, w5
   1fefc:      	uxtb	w4, w4
   1ff00:      	tbnz	w4, #0x0, 0x1ff1c <_mech_canonical_program_entry_v1_numeric_1282+0x241c>
   1ff04:      	mov	x4, x2
   1ff08:      	mov	x5, x15
   1ff0c:      	mov	x8, x24
   1ff10:      	mov	x10, x1
   1ff14:      	mov	x14, x0
   1ff18:      	b	0x1ff5c <_mech_canonical_program_entry_v1_numeric_1282+0x245c>
   1ff1c:      	cmp	x14, x2
   1ff20:      	csel	x4, x14, x2, hi
   1ff24:      	cmp	x14, x2
   1ff28:      	csel	x8, x14, x2, lo
   1ff2c:      	cmp	x8, x15
   1ff30:      	csel	x5, x8, x15, hi
   1ff34:      	cmp	x8, x15
   1ff38:      	csel	x10, x8, x15, lo
   1ff3c:      	cmp	x10, x24
   1ff40:      	csel	x8, x10, x24, hi
   1ff44:      	cmp	x10, x24
   1ff48:      	csel	x14, x10, x24, lo
   1ff4c:      	cmp	x14, x1
   1ff50:      	csel	x10, x14, x1, hi
   1ff54:      	cmp	x14, x1
   1ff58:      	csel	x14, x14, x1, lo
   1ff5c:      	stur	x2, [sp, #0x48]
   1ff60:      	str	x8, [sp, #0x1b0]
   1ff64:      	mov	x8, x24
   1ff68:      	ldr	x24, [sp, #0x1b0]
   1ff6c:      	mov	x2, x4
   1ff70:      	mov	x4, x0
   1ff74:      	str	x1, [sp, #0x1b0]
   1ff78:      	mov	x1, x10
   1ff7c:      	mov	x10, x15
   1ff80:      	mov	x15, x5
   1ff84:      	ldr	x5, [sp, #0x1b0]
   1ff88:      	mov	x0, x14
   1ff8c:      	mov	x14, x27
   1ff90:      	str	x10, [sp, #0x1b0]
   1ff94:      	mov	x10, x15
   1ff98:      	ldr	x15, [sp, #0x1b0]
   1ff9c:      	str	x8, [sp, #0x1b0]
   1ffa0:      	mov	x8, x24
   1ffa4:      	ldr	x24, [sp, #0x1b0]
   1ffa8:      	str	x2, [sp, #0x1b0]
   1ffac:      	ldur	x2, [sp, #0x48]
   1ffb0:      	str	x28, [sp, #0x1b8]
   1ffb4:      	ldr	x28, [sp, #0x1b0]
   1ffb8:      	stur	x28, [sp, #0x48]
   1ffbc:      	str	x1, [sp, #0x1b0]
   1ffc0:      	mov	x1, x5
   1ffc4:      	ldr	x5, [sp, #0x1b0]
   1ffc8:      	str	x0, [sp, #0x1b0]
   1ffcc:      	mov	x0, x4
   1ffd0:      	ldr	x4, [sp, #0x1b0]
   1ffd4:      	ldr	x28, [sp, #0x1b8]
   1ffd8:      	cmp	x27, x7
   1ffdc:      	b.lo	0x224ec <_mech_canonical_program_entry_v1_numeric_1282+0x49ec>
   1ffe0:      	mov	x8, #0x0                ; =0
   1ffe4:      	str	x8, [x25, #0x15d0]
   1ffe8:      	str	x8, [x25, #0x15d8]
   1ffec:      	str	x8, [x25, #0x15e0]
   1fff0:      	str	x8, [x25, #0x15e8]
   1fff4:      	str	x8, [x25, #0x15f0]
   1fff8:      	str	x8, [x25, #0x15f8]
   1fffc:      	str	x8, [x25, #0x1600]
   20000:      	str	x8, [x25, #0x1608]
   20004:      	str	x8, [x25, #0x1610]
   20008:      	str	x8, [x25, #0x1618]
   2000c:      	str	x8, [x25, #0x1620]
   20010:      	str	x8, [x25, #0x1628]
   20014:      	str	x8, [x25, #0x1630]
   20018:      	str	x8, [x25, #0x1638]
   2001c:      	str	x8, [x25, #0x1640]
   20020:      	str	x8, [x25, #0x1648]
   20024:      	str	x8, [x25, #0x1650]
   20028:      	str	x8, [x25, #0x1658]
   2002c:      	mov	w3, #0xdc1e             ; =56350
   20030:      	movk	w3, #0x2, lsl #16
   20034:      	sub	x3, x6, x3
   20038:      	mov	x8, #0x0                ; =0
   2003c:      	stur	x8, [sp, #0xb0]
   20040:      	ldur	x4, [sp, #0x18]
   20044:      	ldur	x5, [sp, #0xb0]
   20048:      	stur	x5, [sp, #0xb8]
   2004c:      	mov	x5, x26
   20050:      	ldur	x27, [sp, #0x18]
   20054:      	cmp	x27, x5
   20058:      	b.lo	0x224c0 <_mech_canonical_program_entry_v1_numeric_1282+0x49c0>
   2005c:      	mov	x0, #0x0                ; =0
   20060:      	str	x0, [x25, #0x1200]
   20064:      	str	x0, [x25, #0x1208]
   20068:      	str	x0, [x25, #0x1210]
   2006c:      	str	x0, [x25, #0x1218]
   20070:      	str	x0, [x25, #0x1220]
   20074:      	str	x0, [x25, #0x1228]
   20078:      	str	x0, [x25, #0x1230]
   2007c:      	str	x0, [x25, #0x1238]
   20080:      	str	x0, [x25, #0x1240]
   20084:      	str	x0, [x25, #0x1248]
   20088:      	str	x0, [x25, #0x1250]
   2008c:      	str	x0, [x25, #0x1258]
   20090:      	str	x0, [x25, #0x1260]
   20094:      	str	x0, [x25, #0x1268]
   20098:      	str	x0, [x25, #0x1270]
   2009c:      	str	x0, [x25, #0x1278]
   200a0:      	str	x0, [x25, #0x1280]
   200a4:      	str	x0, [x25, #0x1288]
   200a8:      	ldr	x26, [sp, #0x130]
   200ac:      	cmp	x22, x26
   200b0:      	b.lo	0x20344 <_mech_canonical_program_entry_v1_numeric_1282+0x2844>
   200b4:      	b	0x234a0 <_mech_canonical_program_entry_v1_numeric_1282+0x59a0>
   200b8:      	ldr	x3, [x19, #0x4c68]
   200bc:      	ldr	x4, [x19, #0x4c70]
   200c0:      	mov	x0, #0x0                ; =0
   200c4:      	str	x0, [x19, #0x4c60]
   200c8:      	mov	x0, #0x3                ; =3
   200cc:      	ldr	x15, [sp, #0x190]
   200d0:      	mov	x21, x0
   200d4:      	cmp	x15, #0x19a
   200d8:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   200dc:      	ldr	x0, [x19, #0x4f70]
   200e0:      	ldr	x1, [sp, #0x198]
   200e4:      	str	x0, [x1, #0x10]
   200e8:      	ldr	x1, [x19, #0x4f78]
   200ec:      	ldr	x2, [sp, #0x198]
   200f0:      	str	x1, [x2, #0x18]
   200f4:      	ldr	x2, [x19, #0x5a20]
   200f8:      	ldr	x5, [sp, #0x198]
   200fc:      	str	x2, [x5, #0xac0]
   20100:      	ldr	x2, [sp, #0x198]
   20104:      	str	x0, [x2, #0x10]
   20108:      	ldr	x0, [sp, #0x198]
   2010c:      	str	x1, [x0, #0x18]
   20110:      	ldr	x0, [x19, #0x50c0]
   20114:      	str	x0, [x5, #0x160]
   20118:      	ldr	x0, [x19, #0x50c8]
   2011c:      	ldr	x6, [sp, #0x198]
   20120:      	str	x0, [x6, #0x168]
   20124:      	ldr	x0, [x19, #0x50d0]
   20128:      	ldr	x9, [sp, #0x198]
   2012c:      	str	x0, [x9, #0x170]
   20130:      	ldr	x0, [x19, #0x50d8]
   20134:      	ldr	x12, [sp, #0x198]
   20138:      	str	x0, [x12, #0x178]
   2013c:      	ldr	x0, [x19, #0x50e0]
   20140:      	ldr	x15, [sp, #0x198]
   20144:      	str	x0, [x15, #0x180]
   20148:      	ldr	x0, [x19, #0x50e8]
   2014c:      	ldr	x1, [sp, #0x198]
   20150:      	str	x0, [x1, #0x188]
   20154:      	ldr	x0, [x19, #0x50f0]
   20158:      	str	x0, [x1, #0x190]
   2015c:      	ldr	x0, [x19, #0x50f8]
   20160:      	str	x0, [x1, #0x198]
   20164:      	ldr	x0, [x19, #0x5100]
   20168:      	str	x0, [x1, #0x1a0]
   2016c:      	ldr	x0, [x19, #0x52a8]
   20170:      	str	x0, [x1, #0x348]
   20174:      	ldr	x0, [x19, #0x52b0]
   20178:      	str	x0, [x1, #0x350]
   2017c:      	ldr	x0, [x19, #0x52b8]
   20180:      	str	x0, [x1, #0x358]
   20184:      	ldr	x0, [x19, #0x52c0]
   20188:      	str	x0, [x1, #0x360]
   2018c:      	ldr	x0, [x19, #0x52c8]
   20190:      	str	x0, [x1, #0x368]
   20194:      	ldr	x0, [x19, #0x52d0]
   20198:      	str	x0, [x1, #0x370]
   2019c:      	ldr	x0, [x19, #0x52d8]
   201a0:      	str	x0, [x1, #0x378]
   201a4:      	ldr	x0, [x19, #0x52e0]
   201a8:      	str	x0, [x1, #0x380]
   201ac:      	ldr	x1, [x19, #0x52e8]
   201b0:      	ldr	x0, [sp, #0x198]
   201b4:      	str	x1, [x0, #0x388]
   201b8:      	ldr	x2, [x19, #0x55d8]
   201bc:      	str	x2, [x0, #0x678]
   201c0:      	ldr	x5, [x19, #0x55e0]
   201c4:      	str	x5, [x0, #0x680]
   201c8:      	ldr	x5, [x19, #0x55e8]
   201cc:      	str	x5, [x0, #0x688]
   201d0:      	ldr	x5, [x19, #0x55f0]
   201d4:      	str	x5, [x6, #0x690]
   201d8:      	ldr	x6, [x19, #0x55f8]
   201dc:      	ldr	x7, [sp, #0x198]
   201e0:      	str	x6, [x7, #0x698]
   201e4:      	ldr	x7, [x19, #0x5600]
   201e8:      	str	x7, [x9, #0x6a0]
   201ec:      	ldr	x8, [x19, #0x5608]
   201f0:      	str	x8, [x12, #0x6a8]
   201f4:      	ldr	x9, [x19, #0x5610]
   201f8:      	str	x9, [x15, #0x6b0]
   201fc:      	ldr	x10, [x19, #0x57a0]
   20200:      	str	x10, [x0, #0x840]
   20204:      	ldr	x11, [x19, #0x57a8]
   20208:      	str	x11, [x0, #0x848]
   2020c:      	ldr	x12, [x19, #0x57b0]
   20210:      	str	x12, [x0, #0x850]
   20214:      	ldr	x13, [x19, #0x57b8]
   20218:      	str	x13, [x0, #0x858]
   2021c:      	ldr	x14, [x19, #0x57c0]
   20220:      	str	x14, [x0, #0x860]
   20224:      	ldr	x15, [x19, #0x57c8]
   20228:      	str	x15, [x0, #0x868]
   2022c:      	ldr	x0, [x19, #0x57d0]
   20230:      	ldr	x1, [sp, #0x198]
   20234:      	str	x0, [x1, #0x870]
   20238:      	ldr	x0, [x19, #0x57d8]
   2023c:      	str	x0, [x1, #0x878]
   20240:      	ldr	x0, [x19, #0x5bb0]
   20244:      	str	x0, [x1, #0xc50]
   20248:      	ldr	x0, [x19, #0x5bb8]
   2024c:      	str	x0, [x1, #0xc58]
   20250:      	ldr	x0, [x19, #0x5bc0]
   20254:      	str	x0, [x1, #0xc60]
   20258:      	ldr	x0, [x19, #0x5bc8]
   2025c:      	str	x0, [x1, #0xc68]
   20260:      	ldr	x0, [x19, #0x5bd0]
   20264:      	str	x0, [x1, #0xc70]
   20268:      	ldr	x0, [x19, #0x5bd8]
   2026c:      	str	x0, [x1, #0xc78]
   20270:      	mov	x0, #0x0                ; =0
   20274:      	str	x0, [x1, #0xc80]
   20278:      	ldr	x1, [x19, #0x5be8]
   2027c:      	ldr	x2, [sp, #0x198]
   20280:      	str	x1, [x2, #0xc88]
   20284:      	ldr	x1, [x19, #0x5bf0]
   20288:      	ldr	x5, [sp, #0x198]
   2028c:      	str	x1, [x5, #0xc90]
   20290:      	str	x0, [x5, #0xc98]
   20294:      	ldr	x1, [x19, #0x5c00]
   20298:      	ldr	x8, [sp, #0x198]
   2029c:      	str	x1, [x8, #0xca0]
   202a0:      	ldr	x1, [x19, #0x5c08]
   202a4:      	ldr	x11, [sp, #0x198]
   202a8:      	str	x1, [x11, #0xca8]
   202ac:      	ldr	x13, [sp, #0x198]
   202b0:      	str	x0, [x13, #0xcb0]
   202b4:      	ldr	x0, [x19, #0x5c18]
   202b8:      	ldr	x1, [sp, #0x198]
   202bc:      	str	x0, [x1, #0xcb8]
   202c0:      	ldr	x0, [x19, #0x5c20]
   202c4:      	str	x0, [x1, #0xcc0]
   202c8:      	mov	x1, #0x5e8              ; =1512
   202cc:      	mov	x2, #-0x9               ; =-9
   202d0:      	ldr	x21, [sp, #0x1a8]
   202d4:      	ldur	x0, [sp, #0x8]
   202d8:      	mov	x5, x20
   202dc:      	ldr	x6, [sp, #0x1a0]
   202e0:      	blr	x21
   202e4:      	cmp	x0, #0x0
   202e8:      	b.ne	0x235c4 <_mech_canonical_program_entry_v1_numeric_1282+0x5ac4>
   202ec:      	mov	x0, #0x3                ; =3
   202f0:      	ldr	x15, [sp, #0x190]
   202f4:      	mov	x21, x0
   202f8:      	cmp	x15, #0x2
   202fc:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   20300:      	mov	x5, #0x0                ; =0
   20304:      	ldr	x3, [sp, #0x198]
   20308:      	str	x5, [x3]
   2030c:      	ldr	x0, [x19, #0x1c00]
   20310:      	str	x0, [x3, #0x8]
   20314:      	mov	x1, #0x5e8              ; =1512
   20318:      	ldur	x0, [sp, #0x8]
   2031c:      	ldr	x6, [sp, #0x1a0]
   20320:      	ldr	x21, [sp, #0x1a8]
   20324:      	mov	x4, x20
   20328:      	mov	x2, x5
   2032c:      	blr	x21
   20330:      	cmp	x0, #0x0
   20334:      	b.ne	0x235cc <_mech_canonical_program_entry_v1_numeric_1282+0x5acc>
   20338:      	mov	x0, #0x3                ; =3
   2033c:      	mov	x21, x0
   20340:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   20344:      	ldr	x26, [sp, #0x138]
   20348:      	ldr	x15, [x26, x22, lsl #3]
   2034c:      	ldur	x0, [sp, #0xe8]
   20350:      	ldr	x26, [sp, #0x130]
   20354:      	cmp	x0, x26
   20358:      	b.lo	0x205e4 <_mech_canonical_program_entry_v1_numeric_1282+0x2ae4>
   2035c:      	b	0x235d4 <_mech_canonical_program_entry_v1_numeric_1282+0x5ad4>
   20360:      	ldr	x3, [x19, #0x4c68]
   20364:      	ldr	x4, [x19, #0x4c70]
   20368:      	mov	x0, #0x0                ; =0
   2036c:      	str	x0, [x19, #0x4c60]
   20370:      	mov	x0, #0x3                ; =3
   20374:      	ldr	x15, [sp, #0x190]
   20378:      	mov	x21, x0
   2037c:      	cmp	x15, #0x19a
   20380:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   20384:      	ldr	x0, [x19, #0x4f70]
   20388:      	ldr	x1, [sp, #0x198]
   2038c:      	str	x0, [x1, #0x10]
   20390:      	ldr	x1, [x19, #0x4f78]
   20394:      	ldr	x2, [sp, #0x198]
   20398:      	str	x1, [x2, #0x18]
   2039c:      	ldr	x2, [x19, #0x5a20]
   203a0:      	ldr	x5, [sp, #0x198]
   203a4:      	str	x2, [x5, #0xac0]
   203a8:      	ldr	x7, [sp, #0x198]
   203ac:      	str	x0, [x7, #0x10]
   203b0:      	ldr	x9, [sp, #0x198]
   203b4:      	str	x1, [x9, #0x18]
   203b8:      	ldr	x0, [x19, #0x50c0]
   203bc:      	ldr	x12, [sp, #0x198]
   203c0:      	str	x0, [x12, #0x160]
   203c4:      	ldr	x0, [x19, #0x50c8]
   203c8:      	ldr	x15, [sp, #0x198]
   203cc:      	str	x0, [x15, #0x168]
   203d0:      	ldr	x0, [x19, #0x50d0]
   203d4:      	ldr	x1, [sp, #0x198]
   203d8:      	str	x0, [x1, #0x170]
   203dc:      	ldr	x0, [x19, #0x50d8]
   203e0:      	str	x0, [x1, #0x178]
   203e4:      	ldr	x0, [x19, #0x50e0]
   203e8:      	str	x0, [x1, #0x180]
   203ec:      	ldr	x0, [x19, #0x50e8]
   203f0:      	str	x0, [x1, #0x188]
   203f4:      	ldr	x0, [x19, #0x50f0]
   203f8:      	str	x0, [x1, #0x190]
   203fc:      	ldr	x0, [x19, #0x50f8]
   20400:      	str	x0, [x1, #0x198]
   20404:      	ldr	x0, [x19, #0x5100]
   20408:      	str	x0, [x1, #0x1a0]
   2040c:      	ldr	x0, [x19, #0x52a8]
   20410:      	str	x0, [x1, #0x348]
   20414:      	ldr	x0, [x19, #0x52b0]
   20418:      	str	x0, [x1, #0x350]
   2041c:      	ldr	x0, [x19, #0x52b8]
   20420:      	str	x0, [x1, #0x358]
   20424:      	ldr	x0, [x19, #0x52c0]
   20428:      	str	x0, [x1, #0x360]
   2042c:      	ldr	x0, [x19, #0x52c8]
   20430:      	str	x0, [x1, #0x368]
   20434:      	ldr	x0, [x19, #0x52d0]
   20438:      	str	x0, [x1, #0x370]
   2043c:      	ldr	x0, [x19, #0x52d8]
   20440:      	str	x0, [x1, #0x378]
   20444:      	ldr	x0, [x19, #0x52e0]
   20448:      	str	x0, [x1, #0x380]
   2044c:      	ldr	x0, [x19, #0x52e8]
   20450:      	str	x0, [x1, #0x388]
   20454:      	ldr	x0, [x19, #0x55d8]
   20458:      	str	x0, [x5, #0x678]
   2045c:      	ldr	x0, [x19, #0x55e0]
   20460:      	ldr	x6, [sp, #0x198]
   20464:      	str	x0, [x6, #0x680]
   20468:      	ldr	x0, [x19, #0x55e8]
   2046c:      	str	x0, [x9, #0x688]
   20470:      	ldr	x0, [x19, #0x55f0]
   20474:      	str	x0, [x12, #0x690]
   20478:      	ldr	x0, [x19, #0x55f8]
   2047c:      	str	x0, [x15, #0x698]
   20480:      	ldr	x0, [x19, #0x5600]
   20484:      	str	x0, [x1, #0x6a0]
   20488:      	ldr	x0, [x19, #0x5608]
   2048c:      	str	x0, [x1, #0x6a8]
   20490:      	ldr	x1, [x19, #0x5610]
   20494:      	ldr	x0, [sp, #0x198]
   20498:      	str	x1, [x0, #0x6b0]
   2049c:      	ldr	x2, [x19, #0x57a0]
   204a0:      	str	x2, [x0, #0x840]
   204a4:      	ldr	x5, [x19, #0x57a8]
   204a8:      	str	x5, [x0, #0x848]
   204ac:      	ldr	x5, [x19, #0x57b0]
   204b0:      	str	x5, [x0, #0x850]
   204b4:      	ldr	x5, [x19, #0x57b8]
   204b8:      	str	x5, [x0, #0x858]
   204bc:      	ldr	x6, [x19, #0x57c0]
   204c0:      	str	x6, [x0, #0x860]
   204c4:      	ldr	x7, [x19, #0x57c8]
   204c8:      	str	x7, [x0, #0x868]
   204cc:      	ldr	x8, [x19, #0x57d0]
   204d0:      	str	x8, [x0, #0x870]
   204d4:      	ldr	x9, [x19, #0x57d8]
   204d8:      	str	x9, [x0, #0x878]
   204dc:      	ldr	x10, [x19, #0x5bb0]
   204e0:      	str	x10, [x0, #0xc50]
   204e4:      	ldr	x11, [x19, #0x5bb8]
   204e8:      	str	x11, [x0, #0xc58]
   204ec:      	ldr	x12, [x19, #0x5bc0]
   204f0:      	str	x12, [x0, #0xc60]
   204f4:      	ldr	x13, [x19, #0x5bc8]
   204f8:      	str	x13, [x0, #0xc68]
   204fc:      	ldr	x14, [x19, #0x5bd0]
   20500:      	str	x14, [x0, #0xc70]
   20504:      	ldr	x15, [x19, #0x5bd8]
   20508:      	ldr	x5, [sp, #0x198]
   2050c:      	str	x15, [x5, #0xc78]
   20510:      	mov	x0, #0x0                ; =0
   20514:      	ldr	x6, [sp, #0x198]
   20518:      	str	x0, [x6, #0xc80]
   2051c:      	ldr	x1, [x19, #0x5be8]
   20520:      	ldr	x9, [sp, #0x198]
   20524:      	str	x1, [x9, #0xc88]
   20528:      	ldr	x1, [x19, #0x5bf0]
   2052c:      	ldr	x12, [sp, #0x198]
   20530:      	str	x1, [x12, #0xc90]
   20534:      	ldr	x14, [sp, #0x198]
   20538:      	str	x0, [x14, #0xc98]
   2053c:      	ldr	x1, [x19, #0x5c00]
   20540:      	ldr	x2, [sp, #0x198]
   20544:      	str	x1, [x2, #0xca0]
   20548:      	ldr	x1, [x19, #0x5c08]
   2054c:      	str	x1, [x2, #0xca8]
   20550:      	ldr	x1, [sp, #0x198]
   20554:      	str	x0, [x1, #0xcb0]
   20558:      	ldr	x0, [x19, #0x5c18]
   2055c:      	str	x0, [x1, #0xcb8]
   20560:      	ldr	x0, [x19, #0x5c20]
   20564:      	str	x0, [x1, #0xcc0]
   20568:      	mov	x1, #0x5ea              ; =1514
   2056c:      	mov	x2, #-0x9               ; =-9
   20570:      	ldr	x21, [sp, #0x1a8]
   20574:      	ldur	x0, [sp, #0x8]
   20578:      	mov	x5, x20
   2057c:      	ldr	x6, [sp, #0x1a0]
   20580:      	blr	x21
   20584:      	cmp	x0, #0x0
   20588:      	b.ne	0x236fc <_mech_canonical_program_entry_v1_numeric_1282+0x5bfc>
   2058c:      	mov	x0, #0x3                ; =3
   20590:      	ldr	x15, [sp, #0x190]
   20594:      	mov	x21, x0
   20598:      	cmp	x15, #0x2
   2059c:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   205a0:      	mov	x5, #0x0                ; =0
   205a4:      	ldr	x3, [sp, #0x198]
   205a8:      	str	x5, [x3]
   205ac:      	ldr	x0, [x19, #0x1c10]
   205b0:      	str	x0, [x3, #0x8]
   205b4:      	mov	x1, #0x5ea              ; =1514
   205b8:      	ldur	x0, [sp, #0x8]
   205bc:      	ldr	x6, [sp, #0x1a0]
   205c0:      	ldr	x21, [sp, #0x1a8]
   205c4:      	mov	x4, x20
   205c8:      	mov	x2, x5
   205cc:      	blr	x21
   205d0:      	cmp	x0, #0x0
   205d4:      	b.ne	0x23704 <_mech_canonical_program_entry_v1_numeric_1282+0x5c04>
   205d8:      	mov	x0, #0x3                ; =3
   205dc:      	mov	x21, x0
   205e0:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   205e4:      	ldur	x0, [sp, #0xe8]
   205e8:      	ldr	x26, [sp, #0x138]
   205ec:      	ldr	x12, [x26, x0, lsl #3]
   205f0:      	mov	x10, #0x0               ; =0
   205f4:      	stur	x10, [sp, #0x50]
   205f8:      	mov	w0, #0x2646             ; =9798
   205fc:      	movk	w0, #0x1, lsl #16
   20600:      	cmp	x3, x0
   20604:      	cset	x0, hs
   20608:      	ldur	x26, [sp, #0xf8]
   2060c:      	and	w0, w0, w26
   20610:      	uxtb	w0, w0
   20614:      	cbnz	x0, 0x209b4 <_mech_canonical_program_entry_v1_numeric_1282+0x2eb4>
   20618:      	mov	x0, #0x0                ; =0
   2061c:      	str	x0, [x19, #0x18]
   20620:      	mov	x1, #0x1000000000000000 ; =1152921504606846976
   20624:      	str	x1, [x19, #0x20]
   20628:      	mov	x1, #0x1                ; =1
   2062c:      	str	x1, [x19, #0x30]
   20630:      	mov	x2, #0x101010101010101  ; =72340172838076673
   20634:      	str	x2, [x19, #0x38]
   20638:      	mov	x20, #0x2               ; =2
   2063c:      	str	x20, [x19, #0x40]
   20640:      	mov	x2, #0x3                ; =3
   20644:      	str	x2, [x19, #0x48]
   20648:      	mov	x2, #0x4                ; =4
   2064c:      	str	x2, [x19, #0x50]
   20650:      	stur	x2, [sp, #0xd0]
   20654:      	mov	x2, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   20658:      	str	x2, [x19, #0x78]
   2065c:      	mov	x2, #0x3333333333333333 ; =3689348814741910323
   20660:      	str	x2, [x19, #0x88]
   20664:      	mov	x2, #0x38               ; =56
   20668:      	str	x2, [x19, #0x90]
   2066c:      	mov	x2, #0x3a               ; =58
   20670:      	str	x2, [x19, #0x98]
   20674:      	mov	x2, #0x5555555555555555 ; =6148914691236517205
   20678:      	str	x2, [x19, #0xb0]
   2067c:      	mov	x2, #0x3ffffffffffffff  ; =288230376151711743
   20680:      	str	x2, [x19, #0xb8]
   20684:      	str	x0, [x19, #0x188]
   20688:      	str	x1, [x19, #0x190]
   2068c:      	str	x22, [x19, #0x17a0]
   20690:      	str	x23, [x19, #0x17a8]
   20694:      	ldur	x25, [sp, #0xf0]
   20698:      	uxtb	w2, w25
   2069c:      	str	x2, [x19, #0x17b8]
   206a0:      	str	x28, [x19, #0x4c60]
   206a4:      	str	x3, [x19, #0x4c68]
   206a8:      	ldur	x4, [sp, #0x98]
   206ac:      	str	x4, [x19, #0x4c70]
   206b0:      	str	x22, [x19, #0x4f70]
   206b4:      	str	x23, [x19, #0x4f78]
   206b8:      	str	x15, [x19, #0x55d8]
   206bc:      	str	x12, [x19, #0x55e0]
   206c0:      	str	x22, [x19, #0x55e8]
   206c4:      	ldur	x24, [sp, #0x10]
   206c8:      	str	x24, [x19, #0x55f0]
   206cc:      	ldur	x26, [sp, #0x68]
   206d0:      	str	x26, [x19, #0x55f8]
   206d4:      	ldur	x27, [sp, #0x70]
   206d8:      	str	x27, [x19, #0x5600]
   206dc:      	ldur	x24, [sp, #0x78]
   206e0:      	str	x24, [x19, #0x5608]
   206e4:      	ldur	x26, [sp, #0x80]
   206e8:      	str	x26, [x19, #0x5610]
   206ec:      	ldur	x14, [sp, #0x60]
   206f0:      	str	x14, [x19, #0x5a20]
   206f4:      	add	x2, x11, #0x1
   206f8:      	str	x2, [x19, #0x5bb0]
   206fc:      	ldur	x26, [sp, #0xa0]
   20700:      	str	x26, [x19, #0x5bb8]
   20704:      	ldur	x7, [sp, #0xa8]
   20708:      	str	x7, [x19, #0x5bc0]
   2070c:      	ldur	x4, [sp, #0x90]
   20710:      	sub	x3, x4, x3
   20714:      	mov	w4, #0xc87e             ; =51326
   20718:      	movk	w4, #0x1, lsl #16
   2071c:      	msub	x2, x2, x4, x3
   20720:      	str	x2, [x19, #0x5bc8]
   20724:      	str	x0, [x19, #0x5bd0]
   20728:      	str	x0, [x19, #0x5bd8]
   2072c:      	ldur	x8, [sp, #0xb0]
   20730:      	str	x8, [x19, #0x5be8]
   20734:      	ldur	x4, [sp, #0xb8]
   20738:      	str	x4, [x19, #0x5bf0]
   2073c:      	str	x1, [x19, #0x5c00]
   20740:      	ldur	x10, [sp, #0x50]
   20744:      	str	x10, [x19, #0x5c08]
   20748:      	str	x13, [x19, #0x5c18]
   2074c:      	ldur	x13, [sp, #0xc0]
   20750:      	str	x13, [x19, #0x5c20]
   20754:      	ldr	x0, [x19, #0x4c60]
   20758:      	cmp	x0, #0x0
   2075c:      	b.eq	0x2098c <_mech_canonical_program_entry_v1_numeric_1282+0x2e8c>
   20760:      	ldr	x3, [x19, #0x4c68]
   20764:      	ldr	x4, [x19, #0x4c70]
   20768:      	mov	x0, #0x0                ; =0
   2076c:      	str	x0, [x19, #0x4c60]
   20770:      	mov	x0, #0x3                ; =3
   20774:      	ldr	x15, [sp, #0x190]
   20778:      	mov	x21, x0
   2077c:      	cmp	x15, #0x19a
   20780:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   20784:      	ldr	x0, [x19, #0x4f70]
   20788:      	ldr	x1, [sp, #0x198]
   2078c:      	str	x0, [x1, #0x10]
   20790:      	ldr	x1, [x19, #0x4f78]
   20794:      	ldr	x2, [sp, #0x198]
   20798:      	str	x1, [x2, #0x18]
   2079c:      	ldr	x2, [x19, #0x5a20]
   207a0:      	ldr	x5, [sp, #0x198]
   207a4:      	str	x2, [x5, #0xac0]
   207a8:      	ldr	x2, [sp, #0x198]
   207ac:      	str	x0, [x2, #0x10]
   207b0:      	ldr	x0, [sp, #0x198]
   207b4:      	str	x1, [x0, #0x18]
   207b8:      	ldr	x0, [x19, #0x50c0]
   207bc:      	ldr	x1, [sp, #0x198]
   207c0:      	str	x0, [x1, #0x160]
   207c4:      	ldr	x0, [x19, #0x50c8]
   207c8:      	str	x0, [x1, #0x168]
   207cc:      	ldr	x0, [x19, #0x50d0]
   207d0:      	str	x0, [x1, #0x170]
   207d4:      	ldr	x0, [x19, #0x50d8]
   207d8:      	str	x0, [x1, #0x178]
   207dc:      	ldr	x0, [x19, #0x50e0]
   207e0:      	str	x0, [x1, #0x180]
   207e4:      	ldr	x0, [x19, #0x50e8]
   207e8:      	str	x0, [x1, #0x188]
   207ec:      	ldr	x0, [x19, #0x50f0]
   207f0:      	str	x0, [x1, #0x190]
   207f4:      	ldr	x0, [x19, #0x50f8]
   207f8:      	str	x0, [x1, #0x198]
   207fc:      	ldr	x0, [x19, #0x5100]
   20800:      	str	x0, [x1, #0x1a0]
   20804:      	ldr	x0, [x19, #0x52a8]
   20808:      	str	x0, [x1, #0x348]
   2080c:      	ldr	x0, [x19, #0x52b0]
   20810:      	str	x0, [x2, #0x350]
   20814:      	ldr	x0, [x19, #0x52b8]
   20818:      	str	x0, [x5, #0x358]
   2081c:      	ldr	x0, [x19, #0x52c0]
   20820:      	ldr	x8, [sp, #0x198]
   20824:      	str	x0, [x8, #0x360]
   20828:      	ldr	x0, [x19, #0x52c8]
   2082c:      	ldr	x11, [sp, #0x198]
   20830:      	str	x0, [x11, #0x368]
   20834:      	ldr	x0, [x19, #0x52d0]
   20838:      	ldr	x14, [sp, #0x198]
   2083c:      	str	x0, [x14, #0x370]
   20840:      	ldr	x0, [x19, #0x52d8]
   20844:      	str	x0, [x1, #0x378]
   20848:      	ldr	x0, [x19, #0x52e0]
   2084c:      	str	x0, [x1, #0x380]
   20850:      	ldr	x0, [x19, #0x52e8]
   20854:      	str	x0, [x1, #0x388]
   20858:      	ldr	x0, [x19, #0x55d8]
   2085c:      	str	x0, [x1, #0x678]
   20860:      	ldr	x0, [x19, #0x55e0]
   20864:      	str	x0, [x1, #0x680]
   20868:      	ldr	x0, [x19, #0x55e8]
   2086c:      	str	x0, [x1, #0x688]
   20870:      	ldr	x0, [x19, #0x55f0]
   20874:      	str	x0, [x1, #0x690]
   20878:      	ldr	x0, [x19, #0x55f8]
   2087c:      	str	x0, [x1, #0x698]
   20880:      	ldr	x1, [x19, #0x5600]
   20884:      	ldr	x0, [sp, #0x198]
   20888:      	str	x1, [x0, #0x6a0]
   2088c:      	ldr	x2, [x19, #0x5608]
   20890:      	str	x2, [x0, #0x6a8]
   20894:      	ldr	x5, [x19, #0x5610]
   20898:      	str	x5, [x0, #0x6b0]
   2089c:      	ldr	x5, [x19, #0x57a0]
   208a0:      	str	x5, [x0, #0x840]
   208a4:      	ldr	x5, [x19, #0x57a8]
   208a8:      	str	x5, [x0, #0x848]
   208ac:      	ldr	x6, [x19, #0x57b0]
   208b0:      	str	x6, [x0, #0x850]
   208b4:      	ldr	x7, [x19, #0x57b8]
   208b8:      	str	x7, [x0, #0x858]
   208bc:      	ldr	x8, [x19, #0x57c0]
   208c0:      	str	x8, [x0, #0x860]
   208c4:      	ldr	x9, [x19, #0x57c8]
   208c8:      	ldr	x2, [sp, #0x198]
   208cc:      	str	x9, [x2, #0x868]
   208d0:      	ldr	x10, [x19, #0x57d0]
   208d4:      	ldr	x5, [sp, #0x198]
   208d8:      	str	x10, [x5, #0x870]
   208dc:      	ldr	x11, [x19, #0x57d8]
   208e0:      	ldr	x8, [sp, #0x198]
   208e4:      	str	x11, [x8, #0x878]
   208e8:      	ldr	x12, [x19, #0x5bb0]
   208ec:      	ldr	x11, [sp, #0x198]
   208f0:      	str	x12, [x11, #0xc50]
   208f4:      	ldr	x13, [x19, #0x5bb8]
   208f8:      	str	x13, [x14, #0xc58]
   208fc:      	ldr	x14, [x19, #0x5bc0]
   20900:      	str	x14, [x0, #0xc60]
   20904:      	ldr	x15, [x19, #0x5bc8]
   20908:      	str	x15, [x0, #0xc68]
   2090c:      	ldr	x0, [x19, #0x5bd0]
   20910:      	ldr	x1, [sp, #0x198]
   20914:      	str	x0, [x1, #0xc70]
   20918:      	ldr	x0, [x19, #0x5bd8]
   2091c:      	str	x0, [x1, #0xc78]
   20920:      	mov	x0, #0x0                ; =0
   20924:      	str	x0, [x1, #0xc80]
   20928:      	ldr	x1, [x19, #0x5be8]
   2092c:      	str	x1, [x2, #0xc88]
   20930:      	ldr	x1, [x19, #0x5bf0]
   20934:      	str	x1, [x2, #0xc90]
   20938:      	ldr	x1, [sp, #0x198]
   2093c:      	str	x0, [x1, #0xc98]
   20940:      	ldr	x1, [x19, #0x5c00]
   20944:      	str	x1, [x2, #0xca0]
   20948:      	ldr	x1, [x19, #0x5c08]
   2094c:      	str	x1, [x2, #0xca8]
   20950:      	ldr	x1, [sp, #0x198]
   20954:      	str	x0, [x1, #0xcb0]
   20958:      	ldr	x0, [x19, #0x5c18]
   2095c:      	str	x0, [x1, #0xcb8]
   20960:      	ldr	x0, [x19, #0x5c20]
   20964:      	str	x0, [x1, #0xcc0]
   20968:      	mov	x1, #0x5f2              ; =1522
   2096c:      	mov	x2, #-0x9               ; =-9
   20970:      	mov	x5, #0x1                ; =1
   20974:      	ldur	x0, [sp, #0x8]
   20978:      	ldr	x6, [sp, #0x1a0]
   2097c:      	ldr	x21, [sp, #0x1a8]
   20980:      	blr	x21
   20984:      	cmp	x0, #0x0
   20988:      	b.ne	0x2370c <_mech_canonical_program_entry_v1_numeric_1282+0x5c0c>
   2098c:      	mov	x0, #0x0                ; =0
   20990:      	ldur	x1, [sp, #0xd0]
   20994:      	add	sp, sp, #0x1c0
   20998:      	ldp	x19, x20, [sp], #0x10
   2099c:      	ldp	x21, x22, [sp], #0x10
   209a0:      	ldp	x23, x24, [sp], #0x10
   209a4:      	ldp	x25, x26, [sp], #0x10
   209a8:      	ldp	x27, x28, [sp], #0x10
   209ac:      	ldp	x29, x30, [sp], #0x10
   209b0:      	retab
   209b4:      	cmp	x15, x12
   209b8:      	cset	x0, lo
   209bc:      	mov	x26, #0x1000000000000000 ; =1152921504606846976
   209c0:      	mov	x1, #0x1000000000000000 ; =1152921504606846976
   209c4:      	ldur	x8, [sp, #0x80]
   209c8:      	cmp	x8, x1
   209cc:      	cset	x1, lo
   209d0:      	and	w0, w0, w1
   209d4:      	uxtb	w24, w0
   209d8:      	tbnz	w24, #0x0, 0x20a00 <_mech_canonical_program_entry_v1_numeric_1282+0x2f00>
   209dc:      	mov	w0, #0x2646             ; =9798
   209e0:      	movk	w0, #0x1, lsl #16
   209e4:      	sub	x3, x3, x0
   209e8:      	ldur	x0, [sp, #0x80]
   209ec:      	ldur	x1, [sp, #0x10]
   209f0:      	ldur	x9, [sp, #0x78]
   209f4:      	ldur	x10, [sp, #0x70]
   209f8:      	ldur	x14, [sp, #0x68]
   209fc:      	b	0x21a08 <_mech_canonical_program_entry_v1_numeric_1282+0x3f08>
   20a00:      	add	x2, x15, #0x1
   20a04:      	cmp	x2, x15
   20a08:      	b.lo	0x23714 <_mech_canonical_program_entry_v1_numeric_1282+0x5c14>
   20a0c:      	ldr	x0, [sp, #0x120]
   20a10:      	cmp	x15, x0
   20a14:      	b.lo	0x20c9c <_mech_canonical_program_entry_v1_numeric_1282+0x319c>
   20a18:      	b	0x23844 <_mech_canonical_program_entry_v1_numeric_1282+0x5d44>
   20a1c:      	ldr	x3, [x19, #0x4c68]
   20a20:      	ldr	x4, [x19, #0x4c70]
   20a24:      	mov	x0, #0x0                ; =0
   20a28:      	str	x0, [x19, #0x4c60]
   20a2c:      	mov	x0, #0x3                ; =3
   20a30:      	ldr	x15, [sp, #0x190]
   20a34:      	mov	x21, x0
   20a38:      	cmp	x15, #0x19a
   20a3c:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   20a40:      	ldr	x0, [x19, #0x4f70]
   20a44:      	ldr	x1, [sp, #0x198]
   20a48:      	str	x0, [x1, #0x10]
   20a4c:      	ldr	x1, [x19, #0x4f78]
   20a50:      	ldr	x2, [sp, #0x198]
   20a54:      	str	x1, [x2, #0x18]
   20a58:      	ldr	x2, [x19, #0x5a20]
   20a5c:      	ldr	x5, [sp, #0x198]
   20a60:      	str	x2, [x5, #0xac0]
   20a64:      	ldr	x2, [sp, #0x198]
   20a68:      	str	x0, [x2, #0x10]
   20a6c:      	str	x1, [x2, #0x18]
   20a70:      	ldr	x0, [x19, #0x50c0]
   20a74:      	str	x0, [x5, #0x160]
   20a78:      	ldr	x0, [x19, #0x50c8]
   20a7c:      	ldr	x8, [sp, #0x198]
   20a80:      	str	x0, [x8, #0x168]
   20a84:      	ldr	x0, [x19, #0x50d0]
   20a88:      	ldr	x11, [sp, #0x198]
   20a8c:      	str	x0, [x11, #0x170]
   20a90:      	ldr	x0, [x19, #0x50d8]
   20a94:      	ldr	x14, [sp, #0x198]
   20a98:      	str	x0, [x14, #0x178]
   20a9c:      	ldr	x0, [x19, #0x50e0]
   20aa0:      	ldr	x1, [sp, #0x198]
   20aa4:      	str	x0, [x1, #0x180]
   20aa8:      	ldr	x0, [x19, #0x50e8]
   20aac:      	str	x0, [x1, #0x188]
   20ab0:      	ldr	x0, [x19, #0x50f0]
   20ab4:      	str	x0, [x1, #0x190]
   20ab8:      	ldr	x0, [x19, #0x50f8]
   20abc:      	str	x0, [x1, #0x198]
   20ac0:      	ldr	x0, [x19, #0x5100]
   20ac4:      	str	x0, [x1, #0x1a0]
   20ac8:      	ldr	x0, [x19, #0x52a8]
   20acc:      	str	x0, [x1, #0x348]
   20ad0:      	ldr	x0, [x19, #0x52b0]
   20ad4:      	str	x0, [x1, #0x350]
   20ad8:      	ldr	x0, [x19, #0x52b8]
   20adc:      	str	x0, [x1, #0x358]
   20ae0:      	ldr	x0, [x19, #0x52c0]
   20ae4:      	str	x0, [x1, #0x360]
   20ae8:      	ldr	x0, [x19, #0x52c8]
   20aec:      	str	x0, [x1, #0x368]
   20af0:      	ldr	x0, [x19, #0x52d0]
   20af4:      	str	x0, [x1, #0x370]
   20af8:      	ldr	x0, [x19, #0x52d8]
   20afc:      	str	x0, [x1, #0x378]
   20b00:      	ldr	x0, [x19, #0x52e0]
   20b04:      	str	x0, [x1, #0x380]
   20b08:      	ldr	x0, [x19, #0x52e8]
   20b0c:      	str	x0, [x1, #0x388]
   20b10:      	ldr	x0, [x19, #0x55d8]
   20b14:      	str	x0, [x1, #0x678]
   20b18:      	ldr	x0, [x19, #0x55e0]
   20b1c:      	str	x0, [x1, #0x680]
   20b20:      	ldr	x0, [x19, #0x55e8]
   20b24:      	str	x0, [x2, #0x688]
   20b28:      	ldr	x0, [x19, #0x55f0]
   20b2c:      	str	x0, [x5, #0x690]
   20b30:      	ldr	x0, [x19, #0x55f8]
   20b34:      	str	x0, [x8, #0x698]
   20b38:      	ldr	x0, [x19, #0x5600]
   20b3c:      	str	x0, [x11, #0x6a0]
   20b40:      	ldr	x0, [x19, #0x5608]
   20b44:      	str	x0, [x14, #0x6a8]
   20b48:      	ldr	x0, [x19, #0x5610]
   20b4c:      	str	x0, [x1, #0x6b0]
   20b50:      	ldr	x0, [x19, #0x57a0]
   20b54:      	str	x0, [x1, #0x840]
   20b58:      	ldr	x0, [x19, #0x57a8]
   20b5c:      	str	x0, [x1, #0x848]
   20b60:      	ldr	x0, [x19, #0x57b0]
   20b64:      	str	x0, [x1, #0x850]
   20b68:      	ldr	x0, [x19, #0x57b8]
   20b6c:      	str	x0, [x1, #0x858]
   20b70:      	ldr	x0, [x19, #0x57c0]
   20b74:      	str	x0, [x1, #0x860]
   20b78:      	ldr	x0, [x19, #0x57c8]
   20b7c:      	str	x0, [x1, #0x868]
   20b80:      	ldr	x1, [x19, #0x57d0]
   20b84:      	ldr	x0, [sp, #0x198]
   20b88:      	str	x1, [x0, #0x870]
   20b8c:      	ldr	x2, [x19, #0x57d8]
   20b90:      	str	x2, [x0, #0x878]
   20b94:      	ldr	x5, [x19, #0x5bb0]
   20b98:      	str	x5, [x0, #0xc50]
   20b9c:      	ldr	x5, [x19, #0x5bb8]
   20ba0:      	str	x5, [x0, #0xc58]
   20ba4:      	ldr	x5, [x19, #0x5bc0]
   20ba8:      	str	x5, [x0, #0xc60]
   20bac:      	ldr	x6, [x19, #0x5bc8]
   20bb0:      	str	x6, [x0, #0xc68]
   20bb4:      	ldr	x7, [x19, #0x5bd0]
   20bb8:      	str	x7, [x0, #0xc70]
   20bbc:      	ldr	x8, [x19, #0x5bd8]
   20bc0:      	str	x8, [x0, #0xc78]
   20bc4:      	mov	x9, #0x0                ; =0
   20bc8:      	str	x9, [x0, #0xc80]
   20bcc:      	ldr	x10, [x19, #0x5be8]
   20bd0:      	ldr	x2, [sp, #0x198]
   20bd4:      	str	x10, [x2, #0xc88]
   20bd8:      	ldr	x11, [x19, #0x5bf0]
   20bdc:      	ldr	x5, [sp, #0x198]
   20be0:      	str	x11, [x5, #0xc90]
   20be4:      	ldr	x7, [sp, #0x198]
   20be8:      	str	x9, [x7, #0xc98]
   20bec:      	ldr	x13, [x19, #0x5c00]
   20bf0:      	ldr	x10, [sp, #0x198]
   20bf4:      	str	x13, [x10, #0xca0]
   20bf8:      	ldr	x14, [x19, #0x5c08]
   20bfc:      	ldr	x13, [sp, #0x198]
   20c00:      	str	x14, [x13, #0xca8]
   20c04:      	ldr	x15, [sp, #0x198]
   20c08:      	str	x9, [x15, #0xcb0]
   20c0c:      	ldr	x0, [x19, #0x5c18]
   20c10:      	ldr	x1, [sp, #0x198]
   20c14:      	str	x0, [x1, #0xcb8]
   20c18:      	ldr	x0, [x19, #0x5c20]
   20c1c:      	str	x0, [x1, #0xcc0]
   20c20:      	mov	x1, #0x605              ; =1541
   20c24:      	mov	x2, #-0x9               ; =-9
   20c28:      	ldr	x21, [sp, #0x1a8]
   20c2c:      	ldur	x0, [sp, #0x8]
   20c30:      	mov	x5, x20
   20c34:      	ldr	x6, [sp, #0x1a0]
   20c38:      	blr	x21
   20c3c:      	cmp	x0, #0x0
   20c40:      	b.ne	0x239b4 <_mech_canonical_program_entry_v1_numeric_1282+0x5eb4>
   20c44:      	mov	x0, #0x3                ; =3
   20c48:      	ldr	x15, [sp, #0x190]
   20c4c:      	mov	x21, x0
   20c50:      	cmp	x15, #0x2
   20c54:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   20c58:      	mov	x5, #0x0                ; =0
   20c5c:      	ldr	x3, [sp, #0x198]
   20c60:      	str	x5, [x3]
   20c64:      	ldr	x0, [x19, #0x1cb8]
   20c68:      	str	x0, [x3, #0x8]
   20c6c:      	mov	x1, #0x605              ; =1541
   20c70:      	ldur	x0, [sp, #0x8]
   20c74:      	ldr	x6, [sp, #0x1a0]
   20c78:      	ldr	x21, [sp, #0x1a8]
   20c7c:      	mov	x4, x20
   20c80:      	mov	x2, x5
   20c84:      	blr	x21
   20c88:      	cmp	x0, #0x0
   20c8c:      	b.ne	0x239bc <_mech_canonical_program_entry_v1_numeric_1282+0x5ebc>
   20c90:      	mov	x0, #0x3                ; =3
   20c94:      	mov	x21, x0
   20c98:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   20c9c:      	ldr	x14, [sp, #0x128]
   20ca0:      	ldr	x1, [x14, x15, lsl #3]
   20ca4:      	add	x4, x1, #0x1
   20ca8:      	cmp	x4, x1
   20cac:      	b.lo	0x239c4 <_mech_canonical_program_entry_v1_numeric_1282+0x5ec4>
   20cb0:      	ldr	x0, [sp, #0x110]
   20cb4:      	cmp	x1, x0
   20cb8:      	b.lo	0x20f24 <_mech_canonical_program_entry_v1_numeric_1282+0x3424>
   20cbc:      	b	0x23af8 <_mech_canonical_program_entry_v1_numeric_1282+0x5ff8>
   20cc0:      	ldr	x3, [x19, #0x4c68]
   20cc4:      	ldr	x4, [x19, #0x4c70]
   20cc8:      	mov	x6, #0x0                ; =0
   20ccc:      	str	x6, [x19, #0x4c60]
   20cd0:      	mov	x0, #0x3                ; =3
   20cd4:      	ldr	x15, [sp, #0x190]
   20cd8:      	mov	x21, x0
   20cdc:      	cmp	x15, #0x19a
   20ce0:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   20ce4:      	ldr	x10, [x19, #0x4f70]
   20ce8:      	ldr	x0, [sp, #0x198]
   20cec:      	str	x10, [x0, #0x10]
   20cf0:      	ldr	x11, [x19, #0x4f78]
   20cf4:      	str	x11, [x0, #0x18]
   20cf8:      	ldr	x12, [x19, #0x5a20]
   20cfc:      	str	x12, [x0, #0xac0]
   20d00:      	str	x10, [x0, #0x10]
   20d04:      	str	x11, [x0, #0x18]
   20d08:      	ldr	x15, [x19, #0x50c0]
   20d0c:      	str	x15, [x0, #0x160]
   20d10:      	ldr	x0, [x19, #0x50c8]
   20d14:      	ldr	x1, [sp, #0x198]
   20d18:      	str	x0, [x1, #0x168]
   20d1c:      	ldr	x0, [x19, #0x50d0]
   20d20:      	str	x0, [x1, #0x170]
   20d24:      	ldr	x0, [x19, #0x50d8]
   20d28:      	str	x0, [x1, #0x178]
   20d2c:      	ldr	x0, [x19, #0x50e0]
   20d30:      	str	x0, [x1, #0x180]
   20d34:      	ldr	x0, [x19, #0x50e8]
   20d38:      	str	x0, [x1, #0x188]
   20d3c:      	ldr	x0, [x19, #0x50f0]
   20d40:      	str	x0, [x1, #0x190]
   20d44:      	ldr	x0, [x19, #0x50f8]
   20d48:      	str	x0, [x1, #0x198]
   20d4c:      	ldr	x0, [x19, #0x5100]
   20d50:      	str	x0, [x1, #0x1a0]
   20d54:      	ldr	x0, [x19, #0x52a8]
   20d58:      	str	x0, [x1, #0x348]
   20d5c:      	ldr	x0, [x19, #0x52b0]
   20d60:      	str	x0, [x1, #0x350]
   20d64:      	ldr	x0, [x19, #0x52b8]
   20d68:      	str	x0, [x1, #0x358]
   20d6c:      	ldr	x0, [x19, #0x52c0]
   20d70:      	ldr	x2, [sp, #0x198]
   20d74:      	str	x0, [x2, #0x360]
   20d78:      	ldr	x0, [x19, #0x52c8]
   20d7c:      	ldr	x5, [sp, #0x198]
   20d80:      	str	x0, [x5, #0x368]
   20d84:      	ldr	x0, [x19, #0x52d0]
   20d88:      	ldr	x8, [sp, #0x198]
   20d8c:      	str	x0, [x8, #0x370]
   20d90:      	ldr	x0, [x19, #0x52d8]
   20d94:      	ldr	x11, [sp, #0x198]
   20d98:      	str	x0, [x11, #0x378]
   20d9c:      	ldr	x0, [x19, #0x52e0]
   20da0:      	ldr	x14, [sp, #0x198]
   20da4:      	str	x0, [x14, #0x380]
   20da8:      	ldr	x0, [x19, #0x52e8]
   20dac:      	str	x0, [x1, #0x388]
   20db0:      	ldr	x0, [x19, #0x55d8]
   20db4:      	str	x0, [x1, #0x678]
   20db8:      	ldr	x0, [x19, #0x55e0]
   20dbc:      	str	x0, [x1, #0x680]
   20dc0:      	ldr	x0, [x19, #0x55e8]
   20dc4:      	str	x0, [x1, #0x688]
   20dc8:      	ldr	x0, [x19, #0x55f0]
   20dcc:      	str	x0, [x1, #0x690]
   20dd0:      	ldr	x0, [x19, #0x55f8]
   20dd4:      	str	x0, [x1, #0x698]
   20dd8:      	ldr	x0, [x19, #0x5600]
   20ddc:      	str	x0, [x1, #0x6a0]
   20de0:      	ldr	x0, [x19, #0x5608]
   20de4:      	str	x0, [x1, #0x6a8]
   20de8:      	ldr	x0, [x19, #0x5610]
   20dec:      	str	x0, [x1, #0x6b0]
   20df0:      	ldr	x0, [x19, #0x57a0]
   20df4:      	str	x0, [x1, #0x840]
   20df8:      	ldr	x0, [x19, #0x57a8]
   20dfc:      	str	x0, [x1, #0x848]
   20e00:      	ldr	x0, [x19, #0x57b0]
   20e04:      	str	x0, [x1, #0x850]
   20e08:      	ldr	x0, [x19, #0x57b8]
   20e0c:      	str	x0, [x1, #0x858]
   20e10:      	ldr	x0, [x19, #0x57c0]
   20e14:      	str	x0, [x1, #0x860]
   20e18:      	ldr	x0, [x19, #0x57c8]
   20e1c:      	str	x0, [x1, #0x868]
   20e20:      	ldr	x0, [x19, #0x57d0]
   20e24:      	str	x0, [x1, #0x870]
   20e28:      	ldr	x0, [x19, #0x57d8]
   20e2c:      	str	x0, [x2, #0x878]
   20e30:      	ldr	x0, [x19, #0x5bb0]
   20e34:      	str	x0, [x5, #0xc50]
   20e38:      	ldr	x0, [x19, #0x5bb8]
   20e3c:      	str	x0, [x8, #0xc58]
   20e40:      	ldr	x0, [x19, #0x5bc0]
   20e44:      	str	x0, [x11, #0xc60]
   20e48:      	ldr	x0, [x19, #0x5bc8]
   20e4c:      	str	x0, [x14, #0xc68]
   20e50:      	ldr	x0, [x19, #0x5bd0]
   20e54:      	str	x0, [x1, #0xc70]
   20e58:      	ldr	x0, [x19, #0x5bd8]
   20e5c:      	str	x0, [x1, #0xc78]
   20e60:      	mov	x0, #0x0                ; =0
   20e64:      	str	x0, [x1, #0xc80]
   20e68:      	ldr	x1, [x19, #0x5be8]
   20e6c:      	str	x1, [x2, #0xc88]
   20e70:      	ldr	x1, [x19, #0x5bf0]
   20e74:      	str	x1, [x2, #0xc90]
   20e78:      	ldr	x1, [sp, #0x198]
   20e7c:      	str	x0, [x1, #0xc98]
   20e80:      	ldr	x1, [x19, #0x5c00]
   20e84:      	str	x1, [x2, #0xca0]
   20e88:      	ldr	x1, [x19, #0x5c08]
   20e8c:      	str	x1, [x2, #0xca8]
   20e90:      	ldr	x1, [sp, #0x198]
   20e94:      	str	x0, [x1, #0xcb0]
   20e98:      	ldr	x0, [x19, #0x5c18]
   20e9c:      	str	x0, [x1, #0xcb8]
   20ea0:      	ldr	x0, [x19, #0x5c20]
   20ea4:      	str	x0, [x1, #0xcc0]
   20ea8:      	mov	x1, #0x607              ; =1543
   20eac:      	mov	x2, #-0x9               ; =-9
   20eb0:      	ldr	x21, [sp, #0x1a8]
   20eb4:      	ldur	x0, [sp, #0x8]
   20eb8:      	mov	x5, x20
   20ebc:      	ldr	x6, [sp, #0x1a0]
   20ec0:      	blr	x21
   20ec4:      	cmp	x0, #0x0
   20ec8:      	b.ne	0x23c6c <_mech_canonical_program_entry_v1_numeric_1282+0x616c>
   20ecc:      	mov	x0, #0x3                ; =3
   20ed0:      	ldr	x15, [sp, #0x190]
   20ed4:      	mov	x21, x0
   20ed8:      	cmp	x15, #0x2
   20edc:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   20ee0:      	mov	x5, #0x0                ; =0
   20ee4:      	ldr	x3, [sp, #0x198]
   20ee8:      	str	x5, [x3]
   20eec:      	ldr	x9, [x19, #0x1cc8]
   20ef0:      	str	x9, [x3, #0x8]
   20ef4:      	mov	x1, #0x607              ; =1543
   20ef8:      	ldur	x0, [sp, #0x8]
   20efc:      	ldr	x6, [sp, #0x1a0]
   20f00:      	ldr	x21, [sp, #0x1a8]
   20f04:      	mov	x4, x20
   20f08:      	mov	x2, x5
   20f0c:      	blr	x21
   20f10:      	cmp	x0, #0x0
   20f14:      	b.ne	0x23c74 <_mech_canonical_program_entry_v1_numeric_1282+0x6174>
   20f18:      	mov	x0, #0x3                ; =3
   20f1c:      	mov	x21, x0
   20f20:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   20f24:      	ldr	x0, [sp, #0x118]
   20f28:      	ldr	x27, [x0, x1, lsl #3]
   20f2c:      	ldr	x0, [sp, #0x110]
   20f30:      	cmp	x4, x0
   20f34:      	b.lo	0x211a8 <_mech_canonical_program_entry_v1_numeric_1282+0x36a8>
   20f38:      	b	0x23c7c <_mech_canonical_program_entry_v1_numeric_1282+0x617c>
   20f3c:      	ldr	x3, [x19, #0x4c68]
   20f40:      	ldr	x4, [x19, #0x4c70]
   20f44:      	mov	x10, #0x0               ; =0
   20f48:      	str	x10, [x19, #0x4c60]
   20f4c:      	mov	x0, #0x3                ; =3
   20f50:      	ldr	x15, [sp, #0x190]
   20f54:      	mov	x21, x0
   20f58:      	cmp	x15, #0x19a
   20f5c:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   20f60:      	ldr	x14, [x19, #0x4f70]
   20f64:      	ldr	x0, [sp, #0x198]
   20f68:      	str	x14, [x0, #0x10]
   20f6c:      	ldr	x15, [x19, #0x4f78]
   20f70:      	str	x15, [x0, #0x18]
   20f74:      	ldr	x0, [x19, #0x5a20]
   20f78:      	ldr	x1, [sp, #0x198]
   20f7c:      	str	x0, [x1, #0xac0]
   20f80:      	ldr	x0, [sp, #0x198]
   20f84:      	str	x14, [x0, #0x10]
   20f88:      	str	x15, [x0, #0x18]
   20f8c:      	ldr	x0, [x19, #0x50c0]
   20f90:      	str	x0, [x1, #0x160]
   20f94:      	ldr	x0, [x19, #0x50c8]
   20f98:      	str	x0, [x1, #0x168]
   20f9c:      	ldr	x0, [x19, #0x50d0]
   20fa0:      	str	x0, [x1, #0x170]
   20fa4:      	ldr	x0, [x19, #0x50d8]
   20fa8:      	str	x0, [x1, #0x178]
   20fac:      	ldr	x0, [x19, #0x50e0]
   20fb0:      	str	x0, [x1, #0x180]
   20fb4:      	ldr	x0, [x19, #0x50e8]
   20fb8:      	ldr	x5, [sp, #0x198]
   20fbc:      	str	x0, [x5, #0x188]
   20fc0:      	ldr	x0, [x19, #0x50f0]
   20fc4:      	ldr	x7, [sp, #0x198]
   20fc8:      	str	x0, [x7, #0x190]
   20fcc:      	ldr	x0, [x19, #0x50f8]
   20fd0:      	ldr	x10, [sp, #0x198]
   20fd4:      	str	x0, [x10, #0x198]
   20fd8:      	ldr	x0, [x19, #0x5100]
   20fdc:      	ldr	x13, [sp, #0x198]
   20fe0:      	str	x0, [x13, #0x1a0]
   20fe4:      	ldr	x0, [x19, #0x52a8]
   20fe8:      	str	x0, [x1, #0x348]
   20fec:      	ldr	x0, [x19, #0x52b0]
   20ff0:      	str	x0, [x1, #0x350]
   20ff4:      	ldr	x0, [x19, #0x52b8]
   20ff8:      	str	x0, [x1, #0x358]
   20ffc:      	ldr	x0, [x19, #0x52c0]
   21000:      	str	x0, [x1, #0x360]
   21004:      	ldr	x0, [x19, #0x52c8]
   21008:      	str	x0, [x1, #0x368]
   2100c:      	ldr	x0, [x19, #0x52d0]
   21010:      	str	x0, [x1, #0x370]
   21014:      	ldr	x0, [x19, #0x52d8]
   21018:      	str	x0, [x1, #0x378]
   2101c:      	ldr	x0, [x19, #0x52e0]
   21020:      	str	x0, [x1, #0x380]
   21024:      	ldr	x0, [x19, #0x52e8]
   21028:      	str	x0, [x1, #0x388]
   2102c:      	ldr	x0, [x19, #0x55d8]
   21030:      	str	x0, [x1, #0x678]
   21034:      	ldr	x0, [x19, #0x55e0]
   21038:      	str	x0, [x1, #0x680]
   2103c:      	ldr	x0, [x19, #0x55e8]
   21040:      	str	x0, [x1, #0x688]
   21044:      	ldr	x0, [x19, #0x55f0]
   21048:      	str	x0, [x1, #0x690]
   2104c:      	ldr	x0, [x19, #0x55f8]
   21050:      	str	x0, [x1, #0x698]
   21054:      	ldr	x0, [x19, #0x5600]
   21058:      	str	x0, [x1, #0x6a0]
   2105c:      	ldr	x0, [x19, #0x5608]
   21060:      	str	x0, [x1, #0x6a8]
   21064:      	ldr	x0, [x19, #0x5610]
   21068:      	str	x0, [x1, #0x6b0]
   2106c:      	ldr	x0, [x19, #0x57a0]
   21070:      	str	x0, [x5, #0x840]
   21074:      	ldr	x0, [x19, #0x57a8]
   21078:      	str	x0, [x7, #0x848]
   2107c:      	ldr	x0, [x19, #0x57b0]
   21080:      	str	x0, [x10, #0x850]
   21084:      	ldr	x0, [x19, #0x57b8]
   21088:      	str	x0, [x13, #0x858]
   2108c:      	ldr	x0, [x19, #0x57c0]
   21090:      	str	x0, [x1, #0x860]
   21094:      	ldr	x0, [x19, #0x57c8]
   21098:      	str	x0, [x1, #0x868]
   2109c:      	ldr	x0, [x19, #0x57d0]
   210a0:      	str	x0, [x1, #0x870]
   210a4:      	ldr	x0, [x19, #0x57d8]
   210a8:      	str	x0, [x1, #0x878]
   210ac:      	ldr	x0, [x19, #0x5bb0]
   210b0:      	str	x0, [x1, #0xc50]
   210b4:      	ldr	x0, [x19, #0x5bb8]
   210b8:      	str	x0, [x1, #0xc58]
   210bc:      	ldr	x0, [x19, #0x5bc0]
   210c0:      	str	x0, [x1, #0xc60]
   210c4:      	ldr	x0, [x19, #0x5bc8]
   210c8:      	str	x0, [x1, #0xc68]
   210cc:      	ldr	x0, [x19, #0x5bd0]
   210d0:      	str	x0, [x1, #0xc70]
   210d4:      	ldr	x0, [x19, #0x5bd8]
   210d8:      	str	x0, [x1, #0xc78]
   210dc:      	mov	x0, #0x0                ; =0
   210e0:      	str	x0, [x1, #0xc80]
   210e4:      	ldr	x1, [x19, #0x5be8]
   210e8:      	ldr	x2, [sp, #0x198]
   210ec:      	str	x1, [x2, #0xc88]
   210f0:      	ldr	x1, [x19, #0x5bf0]
   210f4:      	str	x1, [x2, #0xc90]
   210f8:      	ldr	x1, [sp, #0x198]
   210fc:      	str	x0, [x1, #0xc98]
   21100:      	ldr	x1, [x19, #0x5c00]
   21104:      	str	x1, [x2, #0xca0]
   21108:      	ldr	x1, [x19, #0x5c08]
   2110c:      	str	x1, [x2, #0xca8]
   21110:      	ldr	x1, [sp, #0x198]
   21114:      	str	x0, [x1, #0xcb0]
   21118:      	ldr	x5, [x19, #0x5c18]
   2111c:      	str	x5, [x2, #0xcb8]
   21120:      	ldr	x5, [x19, #0x5c20]
   21124:      	ldr	x6, [sp, #0x198]
   21128:      	str	x5, [x6, #0xcc0]
   2112c:      	mov	x1, #0x609              ; =1545
   21130:      	mov	x2, #-0x9               ; =-9
   21134:      	ldr	x21, [sp, #0x1a8]
   21138:      	ldur	x0, [sp, #0x8]
   2113c:      	mov	x5, x25
   21140:      	ldr	x6, [sp, #0x1a0]
   21144:      	blr	x21
   21148:      	cmp	x0, #0x0
   2114c:      	b.ne	0x23df4 <_mech_canonical_program_entry_v1_numeric_1282+0x62f4>
   21150:      	mov	x0, #0x3                ; =3
   21154:      	ldr	x15, [sp, #0x190]
   21158:      	mov	x21, x0
   2115c:      	cmp	x15, #0x2
   21160:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   21164:      	mov	x5, #0x0                ; =0
   21168:      	ldr	x3, [sp, #0x198]
   2116c:      	str	x5, [x3]
   21170:      	ldr	x13, [x19, #0x1cd8]
   21174:      	str	x13, [x3, #0x8]
   21178:      	mov	x1, #0x609              ; =1545
   2117c:      	ldur	x0, [sp, #0x8]
   21180:      	ldr	x6, [sp, #0x1a0]
   21184:      	ldr	x21, [sp, #0x1a8]
   21188:      	mov	x4, x25
   2118c:      	mov	x2, x5
   21190:      	blr	x21
   21194:      	cmp	x0, #0x0
   21198:      	b.ne	0x23dfc <_mech_canonical_program_entry_v1_numeric_1282+0x62fc>
   2119c:      	mov	x0, #0x3                ; =3
   211a0:      	mov	x21, x0
   211a4:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   211a8:      	ldr	x6, [sp, #0x118]
   211ac:      	ldr	x13, [x6, x4, lsl #3]
   211b0:      	mov	w0, #0x2646             ; =9798
   211b4:      	movk	w0, #0x1, lsl #16
   211b8:      	sub	x3, x3, x0
   211bc:      	mov	x2, #0x0                ; =0
   211c0:      	stur	x2, [sp, #0x58]
   211c4:      	ldur	x0, [sp, #0x80]
   211c8:      	ldur	x1, [sp, #0x10]
   211cc:      	ldur	x9, [sp, #0x78]
   211d0:      	ldur	x10, [sp, #0x70]
   211d4:      	ldur	x14, [sp, #0x68]
   211d8:      	mov	w2, #0xcb86             ; =52102
   211dc:      	movk	w2, #0x2, lsl #16
   211e0:      	cmp	x3, x2
   211e4:      	cset	x2, hs
   211e8:      	ldur	x4, [sp, #0xf8]
   211ec:      	and	w2, w2, w4
   211f0:      	uxtb	w2, w2
   211f4:      	cbnz	x2, 0x21608 <_mech_canonical_program_entry_v1_numeric_1282+0x3b08>
   211f8:      	mov	x5, #0x0                ; =0
   211fc:      	str	x5, [x19, #0x18]
   21200:      	str	x26, [x19, #0x20]
   21204:      	mov	x2, #0x1                ; =1
   21208:      	str	x2, [x19, #0x30]
   2120c:      	mov	x4, #0x101010101010101  ; =72340172838076673
   21210:      	str	x4, [x19, #0x38]
   21214:      	mov	x20, #0x2               ; =2
   21218:      	str	x20, [x19, #0x40]
   2121c:      	mov	x4, #0x3                ; =3
   21220:      	str	x4, [x19, #0x48]
   21224:      	mov	x4, #0x4                ; =4
   21228:      	str	x4, [x19, #0x50]
   2122c:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   21230:      	str	x4, [x19, #0x78]
   21234:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   21238:      	str	x4, [x19, #0x88]
   2123c:      	mov	x4, #0x38               ; =56
   21240:      	str	x4, [x19, #0x90]
   21244:      	mov	x4, #0x3a               ; =58
   21248:      	str	x4, [x19, #0x98]
   2124c:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   21250:      	str	x4, [x19, #0xb0]
   21254:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   21258:      	str	x4, [x19, #0xb8]
   2125c:      	str	x5, [x19, #0x188]
   21260:      	str	x2, [x19, #0x190]
   21264:      	str	x22, [x19, #0x17a0]
   21268:      	str	x23, [x19, #0x17a8]
   2126c:      	ldur	x25, [sp, #0xf0]
   21270:      	uxtb	w4, w25
   21274:      	str	x4, [x19, #0x17b8]
   21278:      	str	x15, [x19, #0x1c70]
   2127c:      	str	x12, [x19, #0x1c78]
   21280:      	str	x22, [x19, #0x1c80]
   21284:      	str	x24, [x19, #0x1ca8]
   21288:      	str	x28, [x19, #0x4c60]
   2128c:      	str	x3, [x19, #0x4c68]
   21290:      	ldur	x4, [sp, #0x98]
   21294:      	str	x4, [x19, #0x4c70]
   21298:      	str	x22, [x19, #0x4f70]
   2129c:      	str	x23, [x19, #0x4f78]
   212a0:      	str	x15, [x19, #0x55d8]
   212a4:      	str	x12, [x19, #0x55e0]
   212a8:      	str	x22, [x19, #0x55e8]
   212ac:      	ldur	x24, [sp, #0x10]
   212b0:      	str	x24, [x19, #0x55f0]
   212b4:      	ldur	x26, [sp, #0x68]
   212b8:      	str	x26, [x19, #0x55f8]
   212bc:      	ldur	x4, [sp, #0x70]
   212c0:      	str	x4, [x19, #0x5600]
   212c4:      	ldur	x24, [sp, #0x78]
   212c8:      	str	x24, [x19, #0x5608]
   212cc:      	ldur	x26, [sp, #0x80]
   212d0:      	str	x26, [x19, #0x5610]
   212d4:      	ldur	x24, [sp, #0x10]
   212d8:      	str	x24, [x19, #0x5680]
   212dc:      	ldur	x26, [sp, #0x68]
   212e0:      	str	x26, [x19, #0x5688]
   212e4:      	str	x4, [x19, #0x5690]
   212e8:      	ldur	x24, [sp, #0x78]
   212ec:      	str	x24, [x19, #0x5698]
   212f0:      	ldur	x26, [sp, #0x80]
   212f4:      	str	x26, [x19, #0x56a0]
   212f8:      	str	x27, [x19, #0x57a0]
   212fc:      	str	x13, [x19, #0x57a8]
   21300:      	str	x22, [x19, #0x57b0]
   21304:      	str	x1, [x19, #0x57b8]
   21308:      	str	x14, [x19, #0x57c0]
   2130c:      	str	x10, [x19, #0x57c8]
   21310:      	str	x9, [x19, #0x57d0]
   21314:      	str	x0, [x19, #0x57d8]
   21318:      	ldur	x14, [sp, #0x60]
   2131c:      	str	x14, [x19, #0x5a20]
   21320:      	add	x14, x11, #0x1
   21324:      	str	x14, [x19, #0x5bb0]
   21328:      	ldur	x26, [sp, #0xa0]
   2132c:      	str	x26, [x19, #0x5bb8]
   21330:      	ldur	x7, [sp, #0xa8]
   21334:      	str	x7, [x19, #0x5bc0]
   21338:      	ldur	x4, [sp, #0x90]
   2133c:      	sub	x0, x4, x3
   21340:      	mov	w1, #0xc87e             ; =51326
   21344:      	movk	w1, #0x1, lsl #16
   21348:      	msub	x0, x14, x1, x0
   2134c:      	str	x0, [x19, #0x5bc8]
   21350:      	str	x5, [x19, #0x5bd0]
   21354:      	str	x5, [x19, #0x5bd8]
   21358:      	ldur	x8, [sp, #0xb0]
   2135c:      	str	x8, [x19, #0x5be8]
   21360:      	ldur	x4, [sp, #0xb8]
   21364:      	str	x4, [x19, #0x5bf0]
   21368:      	str	x2, [x19, #0x5c00]
   2136c:      	ldur	x10, [sp, #0x50]
   21370:      	str	x10, [x19, #0x5c08]
   21374:      	str	x2, [x19, #0x5c18]
   21378:      	ldur	x5, [sp, #0x58]
   2137c:      	str	x5, [x19, #0x5c20]
   21380:      	ldr	x0, [x19, #0x4c60]
   21384:      	cmp	x0, #0x0
   21388:      	b.eq	0x215e0 <_mech_canonical_program_entry_v1_numeric_1282+0x3ae0>
   2138c:      	ldr	x3, [x19, #0x4c68]
   21390:      	ldr	x4, [x19, #0x4c70]
   21394:      	mov	x0, #0x0                ; =0
   21398:      	str	x0, [x19, #0x4c60]
   2139c:      	mov	x0, #0x3                ; =3
   213a0:      	ldr	x15, [sp, #0x190]
   213a4:      	mov	x21, x0
   213a8:      	cmp	x15, #0x19a
   213ac:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   213b0:      	ldr	x0, [x19, #0x4f70]
   213b4:      	ldr	x1, [sp, #0x198]
   213b8:      	str	x0, [x1, #0x10]
   213bc:      	ldr	x1, [x19, #0x4f78]
   213c0:      	ldr	x2, [sp, #0x198]
   213c4:      	str	x1, [x2, #0x18]
   213c8:      	ldr	x2, [x19, #0x5a20]
   213cc:      	ldr	x5, [sp, #0x198]
   213d0:      	str	x2, [x5, #0xac0]
   213d4:      	ldr	x2, [x19, #0x5680]
   213d8:      	str	x2, [x5, #0x720]
   213dc:      	ldr	x2, [x19, #0x5688]
   213e0:      	str	x2, [x5, #0x728]
   213e4:      	ldr	x2, [x19, #0x5690]
   213e8:      	str	x2, [x5, #0x730]
   213ec:      	ldr	x2, [x19, #0x5698]
   213f0:      	str	x2, [x5, #0x738]
   213f4:      	ldr	x2, [x19, #0x56a0]
   213f8:      	str	x2, [x5, #0x740]
   213fc:      	ldr	x2, [sp, #0x198]
   21400:      	str	x0, [x2, #0x10]
   21404:      	ldr	x0, [sp, #0x198]
   21408:      	str	x1, [x0, #0x18]
   2140c:      	ldr	x0, [x19, #0x50c0]
   21410:      	ldr	x1, [sp, #0x198]
   21414:      	str	x0, [x1, #0x160]
   21418:      	ldr	x0, [x19, #0x50c8]
   2141c:      	str	x0, [x1, #0x168]
   21420:      	ldr	x0, [x19, #0x50d0]
   21424:      	str	x0, [x1, #0x170]
   21428:      	ldr	x0, [x19, #0x50d8]
   2142c:      	str	x0, [x1, #0x178]
   21430:      	ldr	x0, [x19, #0x50e0]
   21434:      	str	x0, [x1, #0x180]
   21438:      	ldr	x0, [x19, #0x50e8]
   2143c:      	str	x0, [x1, #0x188]
   21440:      	ldr	x0, [x19, #0x50f0]
   21444:      	str	x0, [x1, #0x190]
   21448:      	ldr	x0, [x19, #0x50f8]
   2144c:      	str	x0, [x5, #0x198]
   21450:      	ldr	x0, [x19, #0x5100]
   21454:      	ldr	x7, [sp, #0x198]
   21458:      	str	x0, [x7, #0x1a0]
   2145c:      	ldr	x0, [x19, #0x52a8]
   21460:      	ldr	x10, [sp, #0x198]
   21464:      	str	x0, [x10, #0x348]
   21468:      	ldr	x0, [x19, #0x52b0]
   2146c:      	ldr	x13, [sp, #0x198]
   21470:      	str	x0, [x13, #0x350]
   21474:      	ldr	x0, [x19, #0x52b8]
   21478:      	str	x0, [x1, #0x358]
   2147c:      	ldr	x0, [x19, #0x52c0]
   21480:      	str	x0, [x1, #0x360]
   21484:      	ldr	x0, [x19, #0x52c8]
   21488:      	str	x0, [x1, #0x368]
   2148c:      	ldr	x0, [x19, #0x52d0]
   21490:      	str	x0, [x1, #0x370]
   21494:      	ldr	x0, [x19, #0x52d8]
   21498:      	str	x0, [x1, #0x378]
   2149c:      	ldr	x0, [x19, #0x52e0]
   214a0:      	str	x0, [x1, #0x380]
   214a4:      	ldr	x0, [x19, #0x52e8]
   214a8:      	str	x0, [x1, #0x388]
   214ac:      	ldr	x0, [x19, #0x55d8]
   214b0:      	str	x0, [x1, #0x678]
   214b4:      	ldr	x0, [x19, #0x55e0]
   214b8:      	str	x0, [x1, #0x680]
   214bc:      	ldr	x0, [x19, #0x55e8]
   214c0:      	str	x0, [x1, #0x688]
   214c4:      	ldr	x1, [x19, #0x55f0]
   214c8:      	ldr	x0, [sp, #0x198]
   214cc:      	str	x1, [x0, #0x690]
   214d0:      	ldr	x2, [x19, #0x55f8]
   214d4:      	str	x2, [x0, #0x698]
   214d8:      	ldr	x5, [x19, #0x5600]
   214dc:      	str	x5, [x0, #0x6a0]
   214e0:      	ldr	x5, [x19, #0x5608]
   214e4:      	str	x5, [x0, #0x6a8]
   214e8:      	ldr	x5, [x19, #0x5610]
   214ec:      	str	x5, [x0, #0x6b0]
   214f0:      	ldr	x6, [x19, #0x57a0]
   214f4:      	str	x6, [x0, #0x840]
   214f8:      	ldr	x7, [x19, #0x57a8]
   214fc:      	ldr	x1, [sp, #0x198]
   21500:      	str	x7, [x1, #0x848]
   21504:      	ldr	x8, [x19, #0x57b0]
   21508:      	ldr	x5, [sp, #0x198]
   2150c:      	str	x8, [x5, #0x850]
   21510:      	ldr	x9, [x19, #0x57b8]
   21514:      	ldr	x7, [sp, #0x198]
   21518:      	str	x9, [x7, #0x858]
   2151c:      	ldr	x10, [x19, #0x57c0]
   21520:      	ldr	x11, [sp, #0x198]
   21524:      	str	x10, [x11, #0x860]
   21528:      	ldr	x11, [x19, #0x57c8]
   2152c:      	str	x11, [x13, #0x868]
   21530:      	ldr	x12, [x19, #0x57d0]
   21534:      	str	x12, [x0, #0x870]
   21538:      	ldr	x13, [x19, #0x57d8]
   2153c:      	str	x13, [x0, #0x878]
   21540:      	ldr	x14, [x19, #0x5bb0]
   21544:      	str	x14, [x0, #0xc50]
   21548:      	ldr	x15, [x19, #0x5bb8]
   2154c:      	str	x15, [x0, #0xc58]
   21550:      	ldr	x0, [x19, #0x5bc0]
   21554:      	str	x0, [x1, #0xc60]
   21558:      	ldr	x0, [x19, #0x5bc8]
   2155c:      	str	x0, [x1, #0xc68]
   21560:      	ldr	x0, [x19, #0x5bd0]
   21564:      	str	x0, [x1, #0xc70]
   21568:      	ldr	x0, [x19, #0x5bd8]
   2156c:      	str	x0, [x1, #0xc78]
   21570:      	mov	x0, #0x0                ; =0
   21574:      	str	x0, [x1, #0xc80]
   21578:      	ldr	x1, [x19, #0x5be8]
   2157c:      	ldr	x2, [sp, #0x198]
   21580:      	str	x1, [x2, #0xc88]
   21584:      	ldr	x1, [x19, #0x5bf0]
   21588:      	str	x1, [x2, #0xc90]
   2158c:      	ldr	x1, [sp, #0x198]
   21590:      	str	x0, [x1, #0xc98]
   21594:      	ldr	x1, [x19, #0x5c00]
   21598:      	str	x1, [x2, #0xca0]
   2159c:      	ldr	x1, [x19, #0x5c08]
   215a0:      	str	x1, [x2, #0xca8]
   215a4:      	ldr	x1, [sp, #0x198]
   215a8:      	str	x0, [x1, #0xcb0]
   215ac:      	ldr	x0, [x19, #0x5c18]
   215b0:      	str	x0, [x1, #0xcb8]
   215b4:      	ldr	x0, [x19, #0x5c20]
   215b8:      	str	x0, [x1, #0xcc0]
   215bc:      	mov	x1, #0x611              ; =1553
   215c0:      	mov	x2, #-0x9               ; =-9
   215c4:      	mov	x5, #0x1                ; =1
   215c8:      	ldur	x0, [sp, #0x8]
   215cc:      	ldr	x6, [sp, #0x1a0]
   215d0:      	ldr	x21, [sp, #0x1a8]
   215d4:      	blr	x21
   215d8:      	cmp	x0, #0x0
   215dc:      	b.ne	0x23e04 <_mech_canonical_program_entry_v1_numeric_1282+0x6304>
   215e0:      	mov	x0, #0x0                ; =0
   215e4:      	mov	x1, #0x5                ; =5
   215e8:      	add	sp, sp, #0x1c0
   215ec:      	ldp	x19, x20, [sp], #0x10
   215f0:      	ldp	x21, x22, [sp], #0x10
   215f4:      	ldp	x23, x24, [sp], #0x10
   215f8:      	ldp	x25, x26, [sp], #0x10
   215fc:      	ldp	x27, x28, [sp], #0x10
   21600:      	ldp	x29, x30, [sp], #0x10
   21604:      	retab
   21608:      	cmp	x27, x13
   2160c:      	cset	x4, lo
   21610:      	cmp	x27, x13
   21614:      	b.lo	0x21620 <_mech_canonical_program_entry_v1_numeric_1282+0x3b20>
   21618:      	mov	x2, #0x0                ; =0
   2161c:      	b	0x218ac <_mech_canonical_program_entry_v1_numeric_1282+0x3dac>
   21620:      	ldr	x2, [sp, #0x100]
   21624:      	cmp	x27, x2
   21628:      	b.lo	0x218a4 <_mech_canonical_program_entry_v1_numeric_1282+0x3da4>
   2162c:      	b	0x23e0c <_mech_canonical_program_entry_v1_numeric_1282+0x630c>
   21630:      	ldr	x3, [x19, #0x4c68]
   21634:      	ldr	x4, [x19, #0x4c70]
   21638:      	mov	x0, #0x0                ; =0
   2163c:      	str	x0, [x19, #0x4c60]
   21640:      	mov	x0, #0x3                ; =3
   21644:      	ldr	x15, [sp, #0x190]
   21648:      	mov	x21, x0
   2164c:      	cmp	x15, #0x19a
   21650:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   21654:      	ldr	x0, [x19, #0x4f70]
   21658:      	ldr	x7, [sp, #0x198]
   2165c:      	str	x0, [x7, #0x10]
   21660:      	ldr	x1, [x19, #0x4f78]
   21664:      	ldr	x10, [sp, #0x198]
   21668:      	str	x1, [x10, #0x18]
   2166c:      	ldr	x2, [x19, #0x5a20]
   21670:      	ldr	x13, [sp, #0x198]
   21674:      	str	x2, [x13, #0xac0]
   21678:      	ldr	x15, [sp, #0x198]
   2167c:      	str	x0, [x15, #0x10]
   21680:      	ldr	x0, [sp, #0x198]
   21684:      	str	x1, [x0, #0x18]
   21688:      	ldr	x2, [x19, #0x50c0]
   2168c:      	str	x2, [x0, #0x160]
   21690:      	ldr	x5, [x19, #0x50c8]
   21694:      	str	x5, [x0, #0x168]
   21698:      	ldr	x5, [x19, #0x50d0]
   2169c:      	str	x5, [x0, #0x170]
   216a0:      	ldr	x5, [x19, #0x50d8]
   216a4:      	str	x5, [x0, #0x178]
   216a8:      	ldr	x6, [x19, #0x50e0]
   216ac:      	str	x6, [x0, #0x180]
   216b0:      	ldr	x7, [x19, #0x50e8]
   216b4:      	str	x7, [x0, #0x188]
   216b8:      	ldr	x8, [x19, #0x50f0]
   216bc:      	str	x8, [x0, #0x190]
   216c0:      	ldr	x9, [x19, #0x50f8]
   216c4:      	str	x9, [x0, #0x198]
   216c8:      	ldr	x10, [x19, #0x5100]
   216cc:      	str	x10, [x0, #0x1a0]
   216d0:      	ldr	x11, [x19, #0x52a8]
   216d4:      	str	x11, [x0, #0x348]
   216d8:      	ldr	x12, [x19, #0x52b0]
   216dc:      	str	x12, [x0, #0x350]
   216e0:      	ldr	x13, [x19, #0x52b8]
   216e4:      	str	x13, [x0, #0x358]
   216e8:      	ldr	x14, [x19, #0x52c0]
   216ec:      	str	x14, [x0, #0x360]
   216f0:      	ldr	x15, [x19, #0x52c8]
   216f4:      	str	x15, [x0, #0x368]
   216f8:      	ldr	x0, [x19, #0x52d0]
   216fc:      	ldr	x1, [sp, #0x198]
   21700:      	str	x0, [x1, #0x370]
   21704:      	ldr	x0, [x19, #0x52d8]
   21708:      	ldr	x2, [sp, #0x198]
   2170c:      	str	x0, [x2, #0x378]
   21710:      	ldr	x0, [x19, #0x52e0]
   21714:      	ldr	x5, [sp, #0x198]
   21718:      	str	x0, [x5, #0x380]
   2171c:      	ldr	x0, [x19, #0x52e8]
   21720:      	ldr	x8, [sp, #0x198]
   21724:      	str	x0, [x8, #0x388]
   21728:      	ldr	x0, [x19, #0x55d8]
   2172c:      	ldr	x11, [sp, #0x198]
   21730:      	str	x0, [x11, #0x678]
   21734:      	ldr	x0, [x19, #0x55e0]
   21738:      	ldr	x14, [sp, #0x198]
   2173c:      	str	x0, [x14, #0x680]
   21740:      	ldr	x0, [x19, #0x55e8]
   21744:      	str	x0, [x1, #0x688]
   21748:      	ldr	x0, [x19, #0x55f0]
   2174c:      	str	x0, [x1, #0x690]
   21750:      	ldr	x0, [x19, #0x55f8]
   21754:      	str	x0, [x1, #0x698]
   21758:      	ldr	x0, [x19, #0x5600]
   2175c:      	str	x0, [x1, #0x6a0]
   21760:      	ldr	x0, [x19, #0x5608]
   21764:      	str	x0, [x1, #0x6a8]
   21768:      	ldr	x0, [x19, #0x5610]
   2176c:      	str	x0, [x1, #0x6b0]
   21770:      	ldr	x0, [x19, #0x57a0]
   21774:      	str	x0, [x1, #0x840]
   21778:      	ldr	x0, [x19, #0x57a8]
   2177c:      	str	x0, [x1, #0x848]
   21780:      	ldr	x0, [x19, #0x57b0]
   21784:      	str	x0, [x1, #0x850]
   21788:      	ldr	x0, [x19, #0x57b8]
   2178c:      	str	x0, [x1, #0x858]
   21790:      	ldr	x0, [x19, #0x57c0]
   21794:      	str	x0, [x1, #0x860]
   21798:      	ldr	x0, [x19, #0x57c8]
   2179c:      	str	x0, [x1, #0x868]
   217a0:      	ldr	x0, [x19, #0x57d0]
   217a4:      	str	x0, [x1, #0x870]
   217a8:      	ldr	x0, [x19, #0x57d8]
   217ac:      	str	x0, [x1, #0x878]
   217b0:      	ldr	x0, [x19, #0x5bb0]
   217b4:      	str	x0, [x1, #0xc50]
   217b8:      	ldr	x0, [x19, #0x5bb8]
   217bc:      	str	x0, [x1, #0xc58]
   217c0:      	ldr	x0, [x19, #0x5bc0]
   217c4:      	str	x0, [x2, #0xc60]
   217c8:      	ldr	x0, [x19, #0x5bc8]
   217cc:      	str	x0, [x5, #0xc68]
   217d0:      	ldr	x0, [x19, #0x5bd0]
   217d4:      	str	x0, [x8, #0xc70]
   217d8:      	ldr	x0, [x19, #0x5bd8]
   217dc:      	str	x0, [x11, #0xc78]
   217e0:      	mov	x0, #0x0                ; =0
   217e4:      	str	x0, [x14, #0xc80]
   217e8:      	ldr	x1, [x19, #0x5be8]
   217ec:      	str	x1, [x2, #0xc88]
   217f0:      	ldr	x1, [x19, #0x5bf0]
   217f4:      	str	x1, [x2, #0xc90]
   217f8:      	ldr	x1, [sp, #0x198]
   217fc:      	str	x0, [x1, #0xc98]
   21800:      	ldr	x1, [x19, #0x5c00]
   21804:      	str	x1, [x2, #0xca0]
   21808:      	ldr	x1, [x19, #0x5c08]
   2180c:      	str	x1, [x2, #0xca8]
   21810:      	ldr	x1, [sp, #0x198]
   21814:      	str	x0, [x1, #0xcb0]
   21818:      	ldr	x0, [x19, #0x5c18]
   2181c:      	str	x0, [x1, #0xcb8]
   21820:      	ldr	x0, [x19, #0x5c20]
   21824:      	str	x0, [x1, #0xcc0]
   21828:      	mov	x1, #0x621              ; =1569
   2182c:      	mov	x2, #-0x9               ; =-9
   21830:      	ldr	x21, [sp, #0x1a8]
   21834:      	ldur	x0, [sp, #0x8]
   21838:      	mov	x5, x20
   2183c:      	ldr	x6, [sp, #0x1a0]
   21840:      	blr	x21
   21844:      	cmp	x0, #0x0
   21848:      	b.ne	0x23fb4 <_mech_canonical_program_entry_v1_numeric_1282+0x64b4>
   2184c:      	mov	x0, #0x3                ; =3
   21850:      	ldr	x15, [sp, #0x190]
   21854:      	mov	x21, x0
   21858:      	cmp	x15, #0x2
   2185c:      	b.lo	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   21860:      	mov	x5, #0x0                ; =0
   21864:      	ldr	x3, [sp, #0x198]
   21868:      	str	x5, [x3]
   2186c:      	ldr	x0, [x19, #0x1d68]
   21870:      	str	x0, [x3, #0x8]
   21874:      	mov	x1, #0x621              ; =1569
   21878:      	ldur	x0, [sp, #0x8]
   2187c:      	ldr	x6, [sp, #0x1a0]
   21880:      	ldr	x21, [sp, #0x1a8]
   21884:      	mov	x4, x20
   21888:      	mov	x2, x5
   2188c:      	blr	x21
   21890:      	cmp	x0, #0x0
   21894:      	b.ne	0x23fbc <_mech_canonical_program_entry_v1_numeric_1282+0x64bc>
   21898:      	mov	x0, #0x3                ; =3
   2189c:      	mov	x21, x0
   218a0:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   218a4:      	ldr	x5, [sp, #0x108]
   218a8:      	ldr	x2, [x5, x27, lsl #3]
   218ac:      	mov	x6, #0x3ffffffffffffff  ; =288230376151711743
   218b0:      	stur	x6, [sp, #0xd0]
   218b4:      	eor	x7, x2, #0x3ffffffffffffff
   218b8:      	orr	x5, x7, #0xc00000000000000
   218bc:      	cmp	x5, x0
   218c0:      	cset	x5, hi
   218c4:      	and	w4, w4, w5
   218c8:      	uxtb	w5, w4
   218cc:      	tbnz	w5, #0x0, 0x218e8 <_mech_canonical_program_entry_v1_numeric_1282+0x3de8>
   218d0:      	mov	x2, x1
   218d4:      	mov	x4, x14
   218d8:      	mov	x6, x9
   218dc:      	mov	x7, x10
   218e0:      	mov	x8, x0
   218e4:      	b	0x219ac <_mech_canonical_program_entry_v1_numeric_1282+0x3eac>
   218e8:      	cmp	x2, x22
   218ec:      	b.ne	0x21908 <_mech_canonical_program_entry_v1_numeric_1282+0x3e08>
   218f0:      	mov	x2, x1
   218f4:      	mov	x4, x14
   218f8:      	mov	x6, x9
   218fc:      	mov	x7, x10
   21900:      	mov	x8, x0
   21904:      	b	0x219ac <_mech_canonical_program_entry_v1_numeric_1282+0x3eac>
   21908:      	and	x4, x1, #0x3ffffffffffffff
   2190c:      	eor	x2, x2, #0x3ffffffffffffff
   21910:      	cmp	x2, x4
   21914:      	cset	x4, ne
   21918:      	and	x6, x14, #0x3ffffffffffffff
   2191c:      	cmp	x2, x6
   21920:      	cset	x6, ne
   21924:      	and	w4, w4, w6
   21928:      	and	x6, x10, #0x3ffffffffffffff
   2192c:      	cmp	x2, x6
   21930:      	cset	x6, ne
   21934:      	and	w4, w4, w6
   21938:      	and	x6, x9, #0x3ffffffffffffff
   2193c:      	cmp	x2, x6
   21940:      	cset	x2, ne
   21944:      	and	w2, w4, w2
   21948:      	uxtb	w2, w2
   2194c:      	tbnz	w2, #0x0, 0x21968 <_mech_canonical_program_entry_v1_numeric_1282+0x3e68>
   21950:      	mov	x2, x1
   21954:      	mov	x4, x14
   21958:      	mov	x6, x9
   2195c:      	mov	x7, x10
   21960:      	mov	x8, x0
   21964:      	b	0x219ac <_mech_canonical_program_entry_v1_numeric_1282+0x3eac>
   21968:      	orr	x4, x7, #0xc00000000000000
   2196c:      	cmp	x4, x1
   21970:      	csel	x2, x4, x1, hi
   21974:      	cmp	x4, x1
   21978:      	csel	x6, x4, x1, lo
   2197c:      	cmp	x6, x14
   21980:      	csel	x4, x6, x14, hi
   21984:      	cmp	x6, x14
   21988:      	csel	x6, x6, x14, lo
   2198c:      	cmp	x6, x10
   21990:      	csel	x7, x6, x10, hi
   21994:      	cmp	x6, x10
   21998:      	csel	x8, x6, x10, lo
   2199c:      	cmp	x8, x9
   219a0:      	csel	x6, x8, x9, hi
   219a4:      	cmp	x8, x9
   219a8:      	csel	x8, x8, x9, lo
   219ac:      	tbnz	w5, #0x0, 0x22484 <_mech_canonical_program_entry_v1_numeric_1282+0x4984>
   219b0:      	mov	x2, #0x0                ; =0
   219b4:      	str	x2, [x25, #0x1fc0]
   219b8:      	str	x2, [x25, #0x1fc8]
   219bc:      	str	x2, [x25, #0x1fd0]
   219c0:      	str	x2, [x25, #0x1fd8]
   219c4:      	str	x2, [x25, #0x1fe0]
   219c8:      	str	x2, [x25, #0x1fe8]
   219cc:      	str	x2, [x25, #0x1ff0]
   219d0:      	str	x2, [x25, #0x1ff8]
   219d4:      	str	x2, [x25, #0x2000]
   219d8:      	str	x2, [x25, #0x2008]
   219dc:      	str	x2, [x25, #0x2010]
   219e0:      	str	x2, [x25, #0x2018]
   219e4:      	str	x2, [x25, #0x2020]
   219e8:      	str	x2, [x25, #0x2028]
   219ec:      	str	x2, [x25, #0x2030]
   219f0:      	str	x2, [x25, #0x2038]
   219f4:      	mov	w2, #0xcb86             ; =52102
   219f8:      	movk	w2, #0x2, lsl #16
   219fc:      	sub	x3, x3, x2
   21a00:      	mov	x13, #0x0               ; =0
   21a04:      	stur	x13, [sp, #0xc0]
   21a08:      	tbnz	w24, #0x0, 0x22454 <_mech_canonical_program_entry_v1_numeric_1282+0x4954>
   21a0c:      	mov	x0, #0x0                ; =0
   21a10:      	str	x0, [x25, #0x1c30]
   21a14:      	str	x0, [x25, #0x1c38]
   21a18:      	str	x0, [x25, #0x1c40]
   21a1c:      	str	x0, [x25, #0x1c48]
   21a20:      	str	x0, [x25, #0x1c50]
   21a24:      	str	x0, [x25, #0x1c58]
   21a28:      	str	x0, [x25, #0x1c60]
   21a2c:      	str	x0, [x25, #0x1c68]
   21a30:      	str	x0, [x25, #0x1c70]
   21a34:      	str	x0, [x25, #0x1c78]
   21a38:      	str	x0, [x25, #0x1c80]
   21a3c:      	str	x0, [x25, #0x1c88]
   21a40:      	str	x0, [x25, #0x1c90]
   21a44:      	str	x0, [x25, #0x1c98]
   21a48:      	str	x0, [x25, #0x1ca0]
   21a4c:      	str	x0, [x25, #0x1ca8]
   21a50:      	mov	x24, #0x0               ; =0
   21a54:      	mov	x9, x24
   21a58:      	mov	x12, x24
   21a5c:      	mov	x15, x24
   21a60:      	mov	x27, x22
   21a64:      	stur	x22, [sp, #0x88]
   21a68:      	cmp	x22, x23
   21a6c:      	b.lo	0x21a78 <_mech_canonical_program_entry_v1_numeric_1282+0x3f78>
   21a70:      	add	x11, x11, #0x1
   21a74:      	b	0x22314 <_mech_canonical_program_entry_v1_numeric_1282+0x4814>
   21a78:      	cbnz	x21, 0x21c24 <_mech_canonical_program_entry_v1_numeric_1282+0x4124>
   21a7c:      	b	0x23fc4 <_mech_canonical_program_entry_v1_numeric_1282+0x64c4>
   21a80:      	ldr	x4, [sp, #0x198]
   21a84:      	str	x27, [x4, #0x10]
   21a88:      	ldr	x6, [sp, #0x198]
   21a8c:      	str	x23, [x6, #0x18]
   21a90:      	ldr	x8, [sp, #0x198]
   21a94:      	str	x27, [x8, #0x10]
   21a98:      	ldr	x10, [sp, #0x198]
   21a9c:      	str	x23, [x10, #0x18]
   21aa0:      	add	x0, x11, #0x1
   21aa4:      	ldr	x14, [sp, #0x198]
   21aa8:      	str	x0, [x14, #0xc50]
   21aac:      	ldr	x1, [sp, #0x198]
   21ab0:      	ldur	x26, [sp, #0xa0]
   21ab4:      	str	x26, [x1, #0xc58]
   21ab8:      	ldur	x7, [sp, #0xa8]
   21abc:      	str	x7, [x1, #0xc60]
   21ac0:      	ldur	x4, [sp, #0x90]
   21ac4:      	sub	x1, x4, x3
   21ac8:      	mov	w2, #0xc87e             ; =51326
   21acc:      	movk	w2, #0x1, lsl #16
   21ad0:      	msub	x0, x0, x2, x1
   21ad4:      	ldr	x1, [sp, #0x198]
   21ad8:      	str	x0, [x1, #0xc68]
   21adc:      	ldr	x0, [sp, #0x198]
   21ae0:      	str	x24, [x0, #0xc70]
   21ae4:      	str	x15, [x0, #0xc78]
   21ae8:      	mov	x5, #0x0                ; =0
   21aec:      	str	x5, [x0, #0xc80]
   21af0:      	ldur	x8, [sp, #0xb0]
   21af4:      	str	x8, [x0, #0xc88]
   21af8:      	ldur	x4, [sp, #0xb8]
   21afc:      	str	x4, [x0, #0xc90]
   21b00:      	str	x5, [x0, #0xc98]
   21b04:      	str	x12, [x0, #0xca0]
   21b08:      	str	x9, [x0, #0xca8]
   21b0c:      	str	x5, [x0, #0xcb0]
   21b10:      	str	x13, [x0, #0xcb8]
   21b14:      	ldur	x13, [sp, #0xc0]
   21b18:      	str	x13, [x0, #0xcc0]
   21b1c:      	ldur	x14, [sp, #0x60]
   21b20:      	add	x0, x14, #0x1
   21b24:      	str	x0, [x1, #0xcd0]
   21b28:      	ldur	x24, [sp, #0x10]
   21b2c:      	and	x0, x24, #0x3ffffffffffffff
   21b30:      	eor	x0, x0, #0x3ffffffffffffff
   21b34:      	str	x0, [x1, #0xcd8]
   21b38:      	mov	x1, #0x6c4              ; =1732
   21b3c:      	mov	x2, #-0x1b              ; =-27
   21b40:      	ldur	x4, [sp, #0x98]
   21b44:      	ldr	x21, [sp, #0x1a8]
   21b48:      	ldur	x0, [sp, #0x8]
   21b4c:      	ldr	x6, [sp, #0x1a0]
   21b50:      	blr	x21
   21b54:      	mov	x1, #0x2                ; =2
   21b58:      	mov	x21, x1
   21b5c:      	cmp	x0, #0x0
   21b60:      	b.ne	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   21b64:      	ldr	x3, [sp, #0x198]
   21b68:      	ldr	x3, [x3]
   21b6c:      	ldr	x1, [sp, #0x198]
   21b70:      	ldr	x4, [x1, #0x8]
   21b74:      	stur	x4, [sp, #0x98]
   21b78:      	ldr	x4, [sp, #0x198]
   21b7c:      	ldr	x20, [x4, #0xab8]
   21b80:      	ldr	x5, [sp, #0x198]
   21b84:      	ldr	x21, [x5, #0xbf8]
   21b88:      	ldr	x7, [sp, #0x198]
   21b8c:      	ldr	x1, [x7, #0xac0]
   21b90:      	ldr	x9, [sp, #0x198]
   21b94:      	ldr	x0, [x9, #0xac8]
   21b98:      	ldr	x11, [sp, #0x198]
   21b9c:      	ldr	x0, [x11, #0xad0]
   21ba0:      	ldr	x13, [sp, #0x198]
   21ba4:      	ldr	x0, [x13, #0xc48]
   21ba8:      	ldr	x15, [sp, #0x198]
   21bac:      	stur	x0, [sp, #0xc8]
   21bb0:      	ldr	x11, [x15, #0xc50]
   21bb4:      	ldr	x0, [sp, #0x198]
   21bb8:      	ldr	x26, [x0, #0xc58]
   21bbc:      	stur	x26, [sp, #0xa0]
   21bc0:      	ldr	x7, [x0, #0xc60]
   21bc4:      	stur	x7, [sp, #0xa8]
   21bc8:      	ldr	x0, [x0, #0xc68]
   21bcc:      	ldr	x2, [sp, #0x198]
   21bd0:      	ldr	x24, [x2, #0xc70]
   21bd4:      	ldr	x15, [x2, #0xc78]
   21bd8:      	ldr	x8, [x2, #0xc88]
   21bdc:      	stur	x8, [sp, #0xb0]
   21be0:      	ldr	x4, [x2, #0xc90]
   21be4:      	stur	x4, [sp, #0xb8]
   21be8:      	ldr	x12, [x2, #0xca0]
   21bec:      	ldr	x9, [x2, #0xca8]
   21bf0:      	ldr	x13, [x2, #0xcb8]
   21bf4:      	ldr	x2, [x2, #0xcc0]
   21bf8:      	stur	x2, [sp, #0xc0]
   21bfc:      	ldr	x2, [sp, #0x198]
   21c00:      	ldr	x25, [x2, #0x10]
   21c04:      	mov	x28, #0x1               ; =1
   21c08:      	str	x28, [x19, #0x4c60]
   21c0c:      	add	x0, x3, x0
   21c10:      	mov	w2, #0xc87e             ; =51326
   21c14:      	movk	w2, #0x1, lsl #16
   21c18:      	madd	x4, x11, x2, x0
   21c1c:      	stur	x4, [sp, #0x90]
   21c20:      	b	0x21c40 <_mech_canonical_program_entry_v1_numeric_1282+0x4140>
   21c24:      	ldur	x0, [sp, #0x10]
   21c28:      	and	x0, x0, #0x3ffffffffffffff
   21c2c:      	eor	x0, x0, #0x3ffffffffffffff
   21c30:      	ldur	x14, [sp, #0x60]
   21c34:      	str	x0, [x20, x14, lsl #3]
   21c38:      	add	x1, x14, #0x1
   21c3c:      	add	x11, x11, #0x1
   21c40:      	cbnz	x21, 0x21ddc <_mech_canonical_program_entry_v1_numeric_1282+0x42dc>
   21c44:      	b	0x23ff0 <_mech_canonical_program_entry_v1_numeric_1282+0x64f0>
   21c48:      	ldr	x4, [sp, #0x198]
   21c4c:      	str	x27, [x4, #0x10]
   21c50:      	ldr	x6, [sp, #0x198]
   21c54:      	str	x23, [x6, #0x18]
   21c58:      	ldr	x8, [sp, #0x198]
   21c5c:      	str	x27, [x8, #0x10]
   21c60:      	ldr	x10, [sp, #0x198]
   21c64:      	str	x23, [x10, #0x18]
   21c68:      	ldr	x14, [sp, #0x198]
   21c6c:      	str	x11, [x14, #0xc50]
   21c70:      	ldur	x26, [sp, #0xa0]
   21c74:      	str	x26, [x14, #0xc58]
   21c78:      	ldr	x0, [sp, #0x198]
   21c7c:      	ldur	x7, [sp, #0xa8]
   21c80:      	str	x7, [x0, #0xc60]
   21c84:      	ldur	x4, [sp, #0x90]
   21c88:      	sub	x10, x4, x3
   21c8c:      	mov	w14, #0xc87e            ; =51326
   21c90:      	movk	w14, #0x1, lsl #16
   21c94:      	msub	x10, x11, x14, x10
   21c98:      	str	x10, [x0, #0xc68]
   21c9c:      	str	x24, [x0, #0xc70]
   21ca0:      	str	x15, [x0, #0xc78]
   21ca4:      	mov	x5, #0x0                ; =0
   21ca8:      	str	x5, [x0, #0xc80]
   21cac:      	ldur	x8, [sp, #0xb0]
   21cb0:      	str	x8, [x0, #0xc88]
   21cb4:      	ldur	x4, [sp, #0xb8]
   21cb8:      	str	x4, [x0, #0xc90]
   21cbc:      	str	x5, [x0, #0xc98]
   21cc0:      	str	x12, [x0, #0xca0]
   21cc4:      	str	x9, [x0, #0xca8]
   21cc8:      	str	x5, [x0, #0xcb0]
   21ccc:      	str	x13, [x0, #0xcb8]
   21cd0:      	ldur	x13, [sp, #0xc0]
   21cd4:      	str	x13, [x0, #0xcc0]
   21cd8:      	add	x0, x1, #0x1
   21cdc:      	ldr	x1, [sp, #0x198]
   21ce0:      	str	x0, [x1, #0xcd0]
   21ce4:      	ldur	x26, [sp, #0x68]
   21ce8:      	and	x0, x26, #0x3ffffffffffffff
   21cec:      	eor	x0, x0, #0x3ffffffffffffff
   21cf0:      	str	x0, [x1, #0xcd8]
   21cf4:      	mov	x1, #0x6c8              ; =1736
   21cf8:      	mov	x2, #-0x1b              ; =-27
   21cfc:      	ldur	x4, [sp, #0x98]
   21d00:      	ldr	x21, [sp, #0x1a8]
   21d04:      	ldur	x0, [sp, #0x8]
   21d08:      	ldr	x6, [sp, #0x1a0]
   21d0c:      	blr	x21
   21d10:      	mov	x9, #0x2                ; =2
   21d14:      	mov	x21, x9
   21d18:      	cmp	x0, #0x0
   21d1c:      	b.ne	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   21d20:      	ldr	x3, [sp, #0x198]
   21d24:      	ldr	x3, [x3]
   21d28:      	ldr	x0, [sp, #0x198]
   21d2c:      	ldr	x4, [x0, #0x8]
   21d30:      	ldr	x2, [sp, #0x198]
   21d34:      	stur	x4, [sp, #0x98]
   21d38:      	ldr	x20, [x2, #0xab8]
   21d3c:      	ldr	x4, [sp, #0x198]
   21d40:      	ldr	x21, [x4, #0xbf8]
   21d44:      	ldr	x6, [sp, #0x198]
   21d48:      	ldr	x1, [x6, #0xac0]
   21d4c:      	ldr	x8, [sp, #0x198]
   21d50:      	ldr	x0, [x8, #0xac8]
   21d54:      	ldr	x10, [sp, #0x198]
   21d58:      	ldr	x0, [x10, #0xad0]
   21d5c:      	ldr	x12, [sp, #0x198]
   21d60:      	ldr	x0, [x12, #0xc48]
   21d64:      	ldr	x14, [sp, #0x198]
   21d68:      	stur	x0, [sp, #0xc8]
   21d6c:      	ldr	x11, [x14, #0xc50]
   21d70:      	ldr	x0, [sp, #0x198]
   21d74:      	ldr	x26, [x0, #0xc58]
   21d78:      	stur	x26, [sp, #0xa0]
   21d7c:      	ldr	x7, [x0, #0xc60]
   21d80:      	stur	x7, [sp, #0xa8]
   21d84:      	ldr	x0, [x0, #0xc68]
   21d88:      	ldr	x24, [x2, #0xc70]
   21d8c:      	ldr	x15, [x2, #0xc78]
   21d90:      	ldr	x8, [x2, #0xc88]
   21d94:      	stur	x8, [sp, #0xb0]
   21d98:      	ldr	x4, [x2, #0xc90]
   21d9c:      	stur	x4, [sp, #0xb8]
   21da0:      	ldr	x12, [x2, #0xca0]
   21da4:      	ldr	x9, [x2, #0xca8]
   21da8:      	ldr	x13, [x2, #0xcb8]
   21dac:      	ldr	x2, [x2, #0xcc0]
   21db0:      	stur	x2, [sp, #0xc0]
   21db4:      	ldr	x2, [sp, #0x198]
   21db8:      	ldr	x25, [x2, #0x10]
   21dbc:      	mov	x28, #0x1               ; =1
   21dc0:      	str	x28, [x19, #0x4c60]
   21dc4:      	add	x0, x3, x0
   21dc8:      	mov	w2, #0xc87e             ; =51326
   21dcc:      	movk	w2, #0x1, lsl #16
   21dd0:      	madd	x4, x11, x2, x0
   21dd4:      	stur	x4, [sp, #0x90]
   21dd8:      	b	0x21df0 <_mech_canonical_program_entry_v1_numeric_1282+0x42f0>
   21ddc:      	ldur	x26, [sp, #0x68]
   21de0:      	and	x0, x26, #0x3ffffffffffffff
   21de4:      	eor	x0, x0, #0x3ffffffffffffff
   21de8:      	str	x0, [x20, x1, lsl #3]
   21dec:      	add	x1, x1, #0x1
   21df0:      	cbnz	x21, 0x21f90 <_mech_canonical_program_entry_v1_numeric_1282+0x4490>
   21df4:      	b	0x2401c <_mech_canonical_program_entry_v1_numeric_1282+0x651c>
   21df8:      	ldr	x2, [sp, #0x198]
   21dfc:      	str	x27, [x2, #0x10]
   21e00:      	ldr	x4, [sp, #0x198]
   21e04:      	str	x23, [x4, #0x18]
   21e08:      	ldr	x6, [sp, #0x198]
   21e0c:      	str	x27, [x6, #0x10]
   21e10:      	ldr	x8, [sp, #0x198]
   21e14:      	str	x23, [x8, #0x18]
   21e18:      	ldr	x10, [sp, #0x198]
   21e1c:      	str	x11, [x10, #0xc50]
   21e20:      	ldr	x14, [sp, #0x198]
   21e24:      	ldur	x26, [sp, #0xa0]
   21e28:      	str	x26, [x14, #0xc58]
   21e2c:      	ldur	x7, [sp, #0xa8]
   21e30:      	str	x7, [x14, #0xc60]
   21e34:      	ldur	x4, [sp, #0x90]
   21e38:      	sub	x0, x4, x3
   21e3c:      	mov	w2, #0xc87e             ; =51326
   21e40:      	movk	w2, #0x1, lsl #16
   21e44:      	msub	x0, x11, x2, x0
   21e48:      	ldr	x2, [sp, #0x198]
   21e4c:      	str	x0, [x2, #0xc68]
   21e50:      	ldr	x0, [sp, #0x198]
   21e54:      	str	x24, [x0, #0xc70]
   21e58:      	str	x15, [x0, #0xc78]
   21e5c:      	mov	x5, #0x0                ; =0
   21e60:      	str	x5, [x0, #0xc80]
   21e64:      	ldur	x8, [sp, #0xb0]
   21e68:      	str	x8, [x0, #0xc88]
   21e6c:      	ldur	x4, [sp, #0xb8]
   21e70:      	str	x4, [x0, #0xc90]
   21e74:      	str	x5, [x0, #0xc98]
   21e78:      	str	x12, [x0, #0xca0]
   21e7c:      	str	x9, [x0, #0xca8]
   21e80:      	str	x5, [x0, #0xcb0]
   21e84:      	str	x13, [x0, #0xcb8]
   21e88:      	ldur	x13, [sp, #0xc0]
   21e8c:      	str	x13, [x0, #0xcc0]
   21e90:      	add	x0, x1, #0x1
   21e94:      	ldr	x1, [sp, #0x198]
   21e98:      	str	x0, [x1, #0xcd0]
   21e9c:      	ldur	x0, [sp, #0x70]
   21ea0:      	and	x0, x0, #0x3ffffffffffffff
   21ea4:      	eor	x0, x0, #0x3ffffffffffffff
   21ea8:      	str	x0, [x1, #0xcd8]
   21eac:      	mov	x1, #0x6cc              ; =1740
   21eb0:      	mov	x2, #-0x1b              ; =-27
   21eb4:      	ldur	x4, [sp, #0x98]
   21eb8:      	ldr	x21, [sp, #0x1a8]
   21ebc:      	ldur	x0, [sp, #0x8]
   21ec0:      	ldr	x6, [sp, #0x1a0]
   21ec4:      	blr	x21
   21ec8:      	mov	x1, #0x2                ; =2
   21ecc:      	mov	x21, x1
   21ed0:      	cmp	x0, #0x0
   21ed4:      	b.ne	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   21ed8:      	ldr	x3, [sp, #0x198]
   21edc:      	ldr	x3, [x3]
   21ee0:      	ldr	x0, [sp, #0x198]
   21ee4:      	ldr	x4, [x0, #0x8]
   21ee8:      	stur	x4, [sp, #0x98]
   21eec:      	ldr	x20, [x0, #0xab8]
   21ef0:      	ldr	x2, [sp, #0x198]
   21ef4:      	ldr	x21, [x2, #0xbf8]
   21ef8:      	ldr	x4, [sp, #0x198]
   21efc:      	ldr	x2, [x4, #0xac0]
   21f00:      	ldr	x6, [sp, #0x198]
   21f04:      	ldr	x4, [x6, #0xac8]
   21f08:      	ldr	x8, [sp, #0x198]
   21f0c:      	ldr	x4, [x8, #0xad0]
   21f10:      	ldr	x10, [sp, #0x198]
   21f14:      	ldr	x1, [x10, #0xc48]
   21f18:      	ldr	x12, [sp, #0x198]
   21f1c:      	stur	x1, [sp, #0xc8]
   21f20:      	ldr	x11, [x12, #0xc50]
   21f24:      	ldr	x14, [sp, #0x198]
   21f28:      	ldr	x26, [x14, #0xc58]
   21f2c:      	stur	x26, [sp, #0xa0]
   21f30:      	ldr	x7, [x0, #0xc60]
   21f34:      	stur	x7, [sp, #0xa8]
   21f38:      	ldr	x4, [x0, #0xc68]
   21f3c:      	ldr	x24, [x0, #0xc70]
   21f40:      	ldr	x15, [x0, #0xc78]
   21f44:      	ldr	x8, [x0, #0xc88]
   21f48:      	stur	x8, [sp, #0xb0]
   21f4c:      	ldr	x1, [x0, #0xc90]
   21f50:      	stur	x1, [sp, #0xb8]
   21f54:      	ldr	x12, [x0, #0xca0]
   21f58:      	ldr	x9, [x0, #0xca8]
   21f5c:      	ldr	x13, [x0, #0xcb8]
   21f60:      	ldr	x0, [x0, #0xcc0]
   21f64:      	stur	x0, [sp, #0xc0]
   21f68:      	ldr	x0, [sp, #0x198]
   21f6c:      	ldr	x25, [x0, #0x10]
   21f70:      	mov	x28, #0x1               ; =1
   21f74:      	str	x28, [x19, #0x4c60]
   21f78:      	add	x4, x3, x4
   21f7c:      	mov	w5, #0xc87e             ; =51326
   21f80:      	movk	w5, #0x1, lsl #16
   21f84:      	madd	x4, x11, x5, x4
   21f88:      	stur	x4, [sp, #0x90]
   21f8c:      	b	0x21fa4 <_mech_canonical_program_entry_v1_numeric_1282+0x44a4>
   21f90:      	ldur	x2, [sp, #0x70]
   21f94:      	and	x4, x2, #0x3ffffffffffffff
   21f98:      	eor	x4, x4, #0x3ffffffffffffff
   21f9c:      	str	x4, [x20, x1, lsl #3]
   21fa0:      	add	x2, x1, #0x1
   21fa4:      	cbnz	x21, 0x22144 <_mech_canonical_program_entry_v1_numeric_1282+0x4644>
   21fa8:      	b	0x24048 <_mech_canonical_program_entry_v1_numeric_1282+0x6548>
   21fac:      	ldr	x0, [sp, #0x198]
   21fb0:      	str	x27, [x0, #0x10]
   21fb4:      	ldr	x4, [sp, #0x198]
   21fb8:      	str	x23, [x4, #0x18]
   21fbc:      	str	x27, [x4, #0x10]
   21fc0:      	ldr	x6, [sp, #0x198]
   21fc4:      	str	x23, [x6, #0x18]
   21fc8:      	ldr	x8, [sp, #0x198]
   21fcc:      	str	x11, [x8, #0xc50]
   21fd0:      	ldr	x10, [sp, #0x198]
   21fd4:      	ldur	x26, [sp, #0xa0]
   21fd8:      	str	x26, [x10, #0xc58]
   21fdc:      	ldur	x7, [sp, #0xa8]
   21fe0:      	ldr	x14, [sp, #0x198]
   21fe4:      	str	x7, [x14, #0xc60]
   21fe8:      	ldur	x4, [sp, #0x90]
   21fec:      	sub	x0, x4, x3
   21ff0:      	mov	w1, #0xc87e             ; =51326
   21ff4:      	movk	w1, #0x1, lsl #16
   21ff8:      	msub	x0, x11, x1, x0
   21ffc:      	ldr	x1, [sp, #0x198]
   22000:      	str	x0, [x1, #0xc68]
   22004:      	ldr	x0, [sp, #0x198]
   22008:      	str	x24, [x0, #0xc70]
   2200c:      	str	x15, [x0, #0xc78]
   22010:      	mov	x5, #0x0                ; =0
   22014:      	str	x5, [x0, #0xc80]
   22018:      	ldur	x8, [sp, #0xb0]
   2201c:      	str	x8, [x0, #0xc88]
   22020:      	ldur	x4, [sp, #0xb8]
   22024:      	str	x4, [x0, #0xc90]
   22028:      	str	x5, [x0, #0xc98]
   2202c:      	str	x12, [x0, #0xca0]
   22030:      	str	x9, [x0, #0xca8]
   22034:      	str	x5, [x0, #0xcb0]
   22038:      	str	x13, [x0, #0xcb8]
   2203c:      	ldur	x13, [sp, #0xc0]
   22040:      	str	x13, [x0, #0xcc0]
   22044:      	add	x0, x2, #0x1
   22048:      	str	x0, [x1, #0xcd0]
   2204c:      	ldur	x24, [sp, #0x78]
   22050:      	and	x0, x24, #0x3ffffffffffffff
   22054:      	eor	x0, x0, #0x3ffffffffffffff
   22058:      	str	x0, [x1, #0xcd8]
   2205c:      	mov	x1, #0x6d0              ; =1744
   22060:      	mov	x2, #-0x1b              ; =-27
   22064:      	ldur	x4, [sp, #0x98]
   22068:      	ldr	x21, [sp, #0x1a8]
   2206c:      	ldur	x0, [sp, #0x8]
   22070:      	ldr	x6, [sp, #0x1a0]
   22074:      	blr	x21
   22078:      	mov	x1, #0x2                ; =2
   2207c:      	mov	x21, x1
   22080:      	cmp	x0, #0x0
   22084:      	b.ne	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22088:      	ldr	x3, [sp, #0x198]
   2208c:      	ldr	x3, [x3]
   22090:      	ldr	x0, [sp, #0x198]
   22094:      	ldr	x4, [x0, #0x8]
   22098:      	stur	x4, [sp, #0x98]
   2209c:      	ldr	x20, [x0, #0xab8]
   220a0:      	ldr	x21, [x0, #0xbf8]
   220a4:      	ldr	x2, [sp, #0x198]
   220a8:      	ldr	x1, [x2, #0xac0]
   220ac:      	ldr	x4, [sp, #0x198]
   220b0:      	ldr	x0, [x4, #0xac8]
   220b4:      	ldr	x6, [sp, #0x198]
   220b8:      	ldr	x0, [x6, #0xad0]
   220bc:      	ldr	x8, [sp, #0x198]
   220c0:      	ldr	x0, [x8, #0xc48]
   220c4:      	ldr	x10, [sp, #0x198]
   220c8:      	stur	x0, [sp, #0xc8]
   220cc:      	ldr	x11, [x10, #0xc50]
   220d0:      	ldr	x12, [sp, #0x198]
   220d4:      	ldr	x26, [x12, #0xc58]
   220d8:      	ldr	x14, [sp, #0x198]
   220dc:      	stur	x26, [sp, #0xa0]
   220e0:      	ldr	x7, [x14, #0xc60]
   220e4:      	ldr	x0, [sp, #0x198]
   220e8:      	stur	x7, [sp, #0xa8]
   220ec:      	ldr	x0, [x0, #0xc68]
   220f0:      	ldr	x24, [x2, #0xc70]
   220f4:      	ldr	x15, [x2, #0xc78]
   220f8:      	ldr	x8, [x2, #0xc88]
   220fc:      	stur	x8, [sp, #0xb0]
   22100:      	ldr	x4, [x2, #0xc90]
   22104:      	stur	x4, [sp, #0xb8]
   22108:      	ldr	x12, [x2, #0xca0]
   2210c:      	ldr	x9, [x2, #0xca8]
   22110:      	ldr	x13, [x2, #0xcb8]
   22114:      	ldr	x2, [x2, #0xcc0]
   22118:      	stur	x2, [sp, #0xc0]
   2211c:      	ldr	x2, [sp, #0x198]
   22120:      	ldr	x25, [x2, #0x10]
   22124:      	mov	x28, #0x1               ; =1
   22128:      	str	x28, [x19, #0x4c60]
   2212c:      	add	x0, x3, x0
   22130:      	mov	w2, #0xc87e             ; =51326
   22134:      	movk	w2, #0x1, lsl #16
   22138:      	madd	x4, x11, x2, x0
   2213c:      	stur	x4, [sp, #0x90]
   22140:      	b	0x22158 <_mech_canonical_program_entry_v1_numeric_1282+0x4658>
   22144:      	ldur	x0, [sp, #0x78]
   22148:      	and	x0, x0, #0x3ffffffffffffff
   2214c:      	eor	x0, x0, #0x3ffffffffffffff
   22150:      	str	x0, [x20, x2, lsl #3]
   22154:      	add	x1, x2, #0x1
   22158:      	cbnz	x21, 0x222fc <_mech_canonical_program_entry_v1_numeric_1282+0x47fc>
   2215c:      	b	0x24074 <_mech_canonical_program_entry_v1_numeric_1282+0x6574>
   22160:      	ldr	x0, [sp, #0x198]
   22164:      	str	x27, [x0, #0x10]
   22168:      	str	x23, [x0, #0x18]
   2216c:      	ldr	x2, [sp, #0x198]
   22170:      	str	x27, [x2, #0x10]
   22174:      	ldr	x4, [sp, #0x198]
   22178:      	str	x23, [x4, #0x18]
   2217c:      	ldr	x6, [sp, #0x198]
   22180:      	str	x11, [x6, #0xc50]
   22184:      	ldr	x8, [sp, #0x198]
   22188:      	ldur	x26, [sp, #0xa0]
   2218c:      	str	x26, [x8, #0xc58]
   22190:      	ldur	x7, [sp, #0xa8]
   22194:      	ldr	x10, [sp, #0x198]
   22198:      	str	x7, [x10, #0xc60]
   2219c:      	ldur	x4, [sp, #0x90]
   221a0:      	sub	x0, x4, x3
   221a4:      	mov	w2, #0xc87e             ; =51326
   221a8:      	movk	w2, #0x1, lsl #16
   221ac:      	msub	x0, x11, x2, x0
   221b0:      	ldr	x2, [sp, #0x198]
   221b4:      	str	x0, [x2, #0xc68]
   221b8:      	ldr	x0, [sp, #0x198]
   221bc:      	str	x24, [x0, #0xc70]
   221c0:      	str	x15, [x0, #0xc78]
   221c4:      	mov	x5, #0x0                ; =0
   221c8:      	str	x5, [x0, #0xc80]
   221cc:      	ldur	x8, [sp, #0xb0]
   221d0:      	str	x8, [x0, #0xc88]
   221d4:      	ldur	x4, [sp, #0xb8]
   221d8:      	str	x4, [x0, #0xc90]
   221dc:      	str	x5, [x0, #0xc98]
   221e0:      	str	x12, [x0, #0xca0]
   221e4:      	str	x9, [x0, #0xca8]
   221e8:      	str	x5, [x0, #0xcb0]
   221ec:      	str	x13, [x0, #0xcb8]
   221f0:      	ldur	x13, [sp, #0xc0]
   221f4:      	str	x13, [x0, #0xcc0]
   221f8:      	add	x10, x1, #0x1
   221fc:      	str	x10, [x0, #0xcd0]
   22200:      	ldur	x26, [sp, #0x80]
   22204:      	and	x11, x26, #0x3ffffffffffffff
   22208:      	eor	x11, x11, #0x3ffffffffffffff
   2220c:      	str	x11, [x0, #0xcd8]
   22210:      	mov	x1, #0x6d4              ; =1748
   22214:      	mov	x2, #-0x1b              ; =-27
   22218:      	ldur	x4, [sp, #0x98]
   2221c:      	ldr	x21, [sp, #0x1a8]
   22220:      	ldur	x0, [sp, #0x8]
   22224:      	ldr	x6, [sp, #0x1a0]
   22228:      	blr	x21
   2222c:      	mov	x9, #0x2                ; =2
   22230:      	mov	x21, x9
   22234:      	cmp	x0, #0x0
   22238:      	b.ne	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   2223c:      	ldr	x3, [sp, #0x198]
   22240:      	ldr	x3, [x3]
   22244:      	ldr	x0, [sp, #0x198]
   22248:      	ldr	x4, [x0, #0x8]
   2224c:      	stur	x4, [sp, #0x98]
   22250:      	ldr	x20, [x0, #0xab8]
   22254:      	ldr	x21, [x0, #0xbf8]
   22258:      	ldr	x14, [x0, #0xac0]
   2225c:      	ldr	x2, [sp, #0x198]
   22260:      	stur	x14, [sp, #0x60]
   22264:      	ldr	x15, [x2, #0xac8]
   22268:      	ldr	x4, [sp, #0x198]
   2226c:      	ldr	x15, [x4, #0xad0]
   22270:      	ldr	x6, [sp, #0x198]
   22274:      	ldr	x1, [x6, #0xc48]
   22278:      	ldr	x8, [sp, #0x198]
   2227c:      	stur	x1, [sp, #0xc8]
   22280:      	ldr	x11, [x8, #0xc50]
   22284:      	ldr	x10, [sp, #0x198]
   22288:      	ldr	x26, [x10, #0xc58]
   2228c:      	ldr	x12, [sp, #0x198]
   22290:      	stur	x26, [sp, #0xa0]
   22294:      	ldr	x7, [x12, #0xc60]
   22298:      	ldr	x14, [sp, #0x198]
   2229c:      	stur	x7, [sp, #0xa8]
   222a0:      	ldr	x0, [x14, #0xc68]
   222a4:      	ldr	x1, [sp, #0x198]
   222a8:      	ldr	x24, [x1, #0xc70]
   222ac:      	ldr	x15, [x1, #0xc78]
   222b0:      	ldr	x8, [x1, #0xc88]
   222b4:      	stur	x8, [sp, #0xb0]
   222b8:      	ldr	x4, [x1, #0xc90]
   222bc:      	stur	x4, [sp, #0xb8]
   222c0:      	ldr	x12, [x1, #0xca0]
   222c4:      	ldr	x9, [x1, #0xca8]
   222c8:      	ldr	x13, [x1, #0xcb8]
   222cc:      	ldr	x1, [x1, #0xcc0]
   222d0:      	stur	x1, [sp, #0xc0]
   222d4:      	ldr	x1, [sp, #0x198]
   222d8:      	ldr	x25, [x1, #0x10]
   222dc:      	mov	x28, #0x1               ; =1
   222e0:      	str	x28, [x19, #0x4c60]
   222e4:      	add	x0, x3, x0
   222e8:      	mov	w1, #0xc87e             ; =51326
   222ec:      	movk	w1, #0x1, lsl #16
   222f0:      	madd	x4, x11, x1, x0
   222f4:      	stur	x4, [sp, #0x90]
   222f8:      	b	0x22314 <_mech_canonical_program_entry_v1_numeric_1282+0x4814>
   222fc:      	ldur	x26, [sp, #0x80]
   22300:      	and	x0, x26, #0x3ffffffffffffff
   22304:      	eor	x0, x0, #0x3ffffffffffffff
   22308:      	str	x0, [x20, x1, lsl #3]
   2230c:      	add	x14, x1, #0x1
   22310:      	stur	x14, [sp, #0x60]
   22314:      	cmp	x22, x23
   22318:      	b.lo	0x2242c <_mech_canonical_program_entry_v1_numeric_1282+0x492c>
   2231c:      	mov	x0, #0x0                ; =0
   22320:      	str	x0, [x19, #0x18]
   22324:      	mov	x1, #0x1000000000000000 ; =1152921504606846976
   22328:      	str	x1, [x19, #0x20]
   2232c:      	mov	x1, #0x1                ; =1
   22330:      	str	x1, [x19, #0x30]
   22334:      	mov	x2, #0x101010101010101  ; =72340172838076673
   22338:      	str	x2, [x19, #0x38]
   2233c:      	mov	x2, #0x2                ; =2
   22340:      	str	x2, [x19, #0x40]
   22344:      	mov	x2, #0x3                ; =3
   22348:      	str	x2, [x19, #0x48]
   2234c:      	mov	x2, #0x4                ; =4
   22350:      	str	x2, [x19, #0x50]
   22354:      	mov	x2, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   22358:      	str	x2, [x19, #0x78]
   2235c:      	mov	x2, #0x3333333333333333 ; =3689348814741910323
   22360:      	str	x2, [x19, #0x88]
   22364:      	mov	x2, #0x38               ; =56
   22368:      	str	x2, [x19, #0x90]
   2236c:      	mov	x2, #0x3a               ; =58
   22370:      	str	x2, [x19, #0x98]
   22374:      	mov	x2, #0x5555555555555555 ; =6148914691236517205
   22378:      	str	x2, [x19, #0xb0]
   2237c:      	mov	x2, #0x3ffffffffffffff  ; =288230376151711743
   22380:      	str	x2, [x19, #0xb8]
   22384:      	str	x0, [x19, #0x188]
   22388:      	str	x1, [x19, #0x190]
   2238c:      	str	x28, [x19, #0x4c60]
   22390:      	str	x3, [x19, #0x4c68]
   22394:      	ldur	x4, [sp, #0x98]
   22398:      	str	x4, [x19, #0x4c70]
   2239c:      	str	x27, [x19, #0x4f70]
   223a0:      	str	x23, [x19, #0x4f78]
   223a4:      	ldur	x14, [sp, #0x60]
   223a8:      	str	x14, [x19, #0x5a20]
   223ac:      	str	x11, [x19, #0x5bb0]
   223b0:      	ldur	x26, [sp, #0xa0]
   223b4:      	str	x26, [x19, #0x5bb8]
   223b8:      	ldur	x7, [sp, #0xa8]
   223bc:      	str	x7, [x19, #0x5bc0]
   223c0:      	ldur	x4, [sp, #0x90]
   223c4:      	sub	x0, x4, x3
   223c8:      	mov	w1, #0xc87e             ; =51326
   223cc:      	movk	w1, #0x1, lsl #16
   223d0:      	msub	x0, x11, x1, x0
   223d4:      	str	x0, [x19, #0x5bc8]
   223d8:      	str	x24, [x19, #0x5bd0]
   223dc:      	str	x15, [x19, #0x5bd8]
   223e0:      	ldur	x8, [sp, #0xb0]
   223e4:      	str	x8, [x19, #0x5be8]
   223e8:      	ldur	x4, [sp, #0xb8]
   223ec:      	str	x4, [x19, #0x5bf0]
   223f0:      	str	x12, [x19, #0x5c00]
   223f4:      	str	x9, [x19, #0x5c08]
   223f8:      	str	x13, [x19, #0x5c18]
   223fc:      	ldur	x13, [sp, #0xc0]
   22400:      	str	x13, [x19, #0x5c20]
   22404:      	mov	x0, #0x0                ; =0
   22408:      	mov	x1, #0x1                ; =1
   2240c:      	add	sp, sp, #0x1c0
   22410:      	ldp	x19, x20, [sp], #0x10
   22414:      	ldp	x21, x22, [sp], #0x10
   22418:      	ldp	x23, x24, [sp], #0x10
   2241c:      	ldp	x25, x26, [sp], #0x10
   22420:      	ldp	x27, x28, [sp], #0x10
   22424:      	ldp	x29, x30, [sp], #0x10
   22428:      	retab
   2242c:      	ldur	x10, [sp, #0x88]
   22430:      	add	x22, x10, #0x1
   22434:      	cmp	x22, x10
   22438:      	b.lo	0x240a0 <_mech_canonical_program_entry_v1_numeric_1282+0x65a0>
   2243c:      	mov	x7, #0x1                ; =1
   22440:      	stur	x7, [sp, #0xa8]
   22444:      	ldur	x5, [sp, #0xa8]
   22448:      	ldur	x6, [sp, #0xb0]
   2244c:      	mov	x26, x28
   22450:      	b	0x1dcd4 <_mech_canonical_program_entry_v1_numeric_1282+0x1d4>
   22454:      	add	x2, x15, #0x1
   22458:      	cmp	x2, x15
   2245c:      	b.lo	0x241a0 <_mech_canonical_program_entry_v1_numeric_1282+0x66a0>
   22460:      	mov	x4, #0x1                ; =1
   22464:      	stur	x4, [sp, #0x50]
   22468:      	mov	x15, x2
   2246c:      	stur	x1, [sp, #0x10]
   22470:      	stur	x14, [sp, #0x68]
   22474:      	stur	x10, [sp, #0x70]
   22478:      	stur	x9, [sp, #0x78]
   2247c:      	stur	x0, [sp, #0x80]
   22480:      	b	0x205f8 <_mech_canonical_program_entry_v1_numeric_1282+0x2af8>
   22484:      	add	x0, x27, #0x1
   22488:      	cmp	x0, x27
   2248c:      	b.lo	0x242bc <_mech_canonical_program_entry_v1_numeric_1282+0x67bc>
   22490:      	mov	w14, #0xcb86            ; =52102
   22494:      	movk	w14, #0x2, lsl #16
   22498:      	sub	x3, x3, x14
   2249c:      	mov	x5, #0x1                ; =1
   224a0:      	stur	x5, [sp, #0x58]
   224a4:      	mov	x27, x0
   224a8:      	mov	x14, x4
   224ac:      	mov	x10, x7
   224b0:      	mov	x9, x6
   224b4:      	mov	x1, x2
   224b8:      	mov	x0, x8
   224bc:      	b	0x211d8 <_mech_canonical_program_entry_v1_numeric_1282+0x36d8>
   224c0:      	add	x27, x4, #0x1
   224c4:      	stur	x27, [sp, #0x18]
   224c8:      	cmp	x27, x4
   224cc:      	b.lo	0x243f8 <_mech_canonical_program_entry_v1_numeric_1282+0x68f8>
   224d0:      	mov	x14, #0x1               ; =1
   224d4:      	stur	x14, [sp, #0x20]
   224d8:      	mov	x4, x1
   224dc:      	mov	x27, x15
   224e0:      	stur	x2, [sp, #0x10]
   224e4:      	stur	x0, [sp, #0x80]
   224e8:      	b	0x1e860 <_mech_canonical_program_entry_v1_numeric_1282+0xd60>
   224ec:      	add	x27, x14, #0x1
   224f0:      	cmp	x27, x14
   224f4:      	b.lo	0x24528 <_mech_canonical_program_entry_v1_numeric_1282+0x6a28>
   224f8:      	mov	w0, #0xdc1e             ; =56350
   224fc:      	movk	w0, #0x2, lsl #16
   22500:      	sub	x6, x6, x0
   22504:      	mov	x3, #0x1                ; =1
   22508:      	stur	x4, [sp, #0x40]
   2250c:      	stur	x5, [sp, #0x38]
   22510:      	stur	x10, [sp, #0x30]
   22514:      	ldur	x15, [sp, #0x48]
   22518:      	mov	x10, x8
   2251c:      	b	0x1f498 <_mech_canonical_program_entry_v1_numeric_1282+0x1998>
   22520:      	mov	x21, x0
   22524:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22528:      	mov	x21, x0
   2252c:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22530:      	mov	x21, x0
   22534:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22538:      	mov	x21, x0
   2253c:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22540:      	mov	x1, #0x512              ; =1298
   22544:      	ldur	x5, [sp]
   22548:      	str	x1, [x5, #0x48]
   2254c:      	mov	x1, #0x0                ; =0
   22550:      	str	x1, [x19, #0x18]
   22554:      	mov	x2, #0x1000000000000000 ; =1152921504606846976
   22558:      	str	x2, [x19, #0x20]
   2255c:      	mov	x2, #0x1                ; =1
   22560:      	str	x2, [x19, #0x30]
   22564:      	mov	x5, #0x101010101010101  ; =72340172838076673
   22568:      	str	x5, [x19, #0x38]
   2256c:      	mov	x20, #0x2               ; =2
   22570:      	str	x20, [x19, #0x40]
   22574:      	mov	x5, #0x3                ; =3
   22578:      	str	x5, [x19, #0x48]
   2257c:      	mov	x7, #0x4                ; =4
   22580:      	str	x7, [x19, #0x50]
   22584:      	mov	x7, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   22588:      	str	x7, [x19, #0x78]
   2258c:      	mov	x8, #0x3333333333333333 ; =3689348814741910323
   22590:      	str	x8, [x19, #0x88]
   22594:      	mov	x5, #0x38               ; =56
   22598:      	str	x5, [x19, #0x90]
   2259c:      	mov	x5, #0x3a               ; =58
   225a0:      	str	x5, [x19, #0x98]
   225a4:      	mov	x5, #0x5555555555555555 ; =6148914691236517205
   225a8:      	str	x5, [x19, #0xb0]
   225ac:      	mov	x5, #0x3ffffffffffffff  ; =288230376151711743
   225b0:      	str	x5, [x19, #0xb8]
   225b4:      	str	x1, [x19, #0x188]
   225b8:      	str	x2, [x19, #0x190]
   225bc:      	str	x22, [x19, #0x17a0]
   225c0:      	str	x23, [x19, #0x17a8]
   225c4:      	uxtb	w0, w0
   225c8:      	str	x0, [x19, #0x17b8]
   225cc:      	add	x0, x22, #0x1
   225d0:      	str	x0, [x19, #0x17d0]
   225d4:      	mov	x28, x26
   225d8:      	str	x28, [x19, #0x4c60]
   225dc:      	mov	w0, #0xc87e             ; =51326
   225e0:      	movk	w0, #0x1, lsl #16
   225e4:      	sub	x1, x3, x0
   225e8:      	str	x1, [x19, #0x4c68]
   225ec:      	str	x4, [x19, #0x4c70]
   225f0:      	str	x22, [x19, #0x4f70]
   225f4:      	str	x23, [x19, #0x4f78]
   225f8:      	ldur	x2, [sp, #0x60]
   225fc:      	str	x2, [x19, #0x5a20]
   22600:      	add	x2, x11, #0x1
   22604:      	str	x2, [x19, #0x5bb0]
   22608:      	ldur	x26, [sp, #0xa0]
   2260c:      	str	x26, [x19, #0x5bb8]
   22610:      	ldur	x3, [sp, #0xa8]
   22614:      	str	x3, [x19, #0x5bc0]
   22618:      	ldur	x4, [sp, #0x90]
   2261c:      	sub	x1, x4, x1
   22620:      	msub	x0, x2, x0, x1
   22624:      	str	x0, [x19, #0x5bc8]
   22628:      	str	x24, [x19, #0x5bd0]
   2262c:      	str	x15, [x19, #0x5bd8]
   22630:      	str	x6, [x19, #0x5be8]
   22634:      	ldur	x4, [sp, #0xb8]
   22638:      	str	x4, [x19, #0x5bf0]
   2263c:      	str	x12, [x19, #0x5c00]
   22640:      	str	x9, [x19, #0x5c08]
   22644:      	str	x13, [x19, #0x5c18]
   22648:      	ldur	x13, [sp, #0xc0]
   2264c:      	str	x13, [x19, #0x5c20]
   22650:      	ldr	x0, [x19, #0x4c60]
   22654:      	cmp	x0, #0x0
   22658:      	b.ne	0x1e0a0 <_mech_canonical_program_entry_v1_numeric_1282+0x5a0>
   2265c:      	b	0x1e094 <_mech_canonical_program_entry_v1_numeric_1282+0x594>
   22660:      	mov	x21, x0
   22664:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22668:      	mov	x21, x20
   2266c:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22670:      	mov	x21, x0
   22674:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22678:      	mov	x21, x20
   2267c:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22680:      	mov	x2, #0x514              ; =1300
   22684:      	str	x2, [x5, #0x48]
   22688:      	mov	x2, #0x0                ; =0
   2268c:      	str	x2, [x19, #0x18]
   22690:      	mov	x5, #0x1000000000000000 ; =1152921504606846976
   22694:      	str	x5, [x19, #0x20]
   22698:      	mov	x5, #0x1                ; =1
   2269c:      	str	x5, [x19, #0x30]
   226a0:      	mov	x6, #0x101010101010101  ; =72340172838076673
   226a4:      	str	x6, [x19, #0x38]
   226a8:      	mov	x20, #0x2               ; =2
   226ac:      	str	x20, [x19, #0x40]
   226b0:      	mov	x6, #0x3                ; =3
   226b4:      	str	x6, [x19, #0x48]
   226b8:      	mov	x6, #0x4                ; =4
   226bc:      	str	x6, [x19, #0x50]
   226c0:      	mov	x6, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   226c4:      	str	x6, [x19, #0x78]
   226c8:      	mov	x6, #0x3333333333333333 ; =3689348814741910323
   226cc:      	str	x6, [x19, #0x88]
   226d0:      	mov	x6, #0x38               ; =56
   226d4:      	str	x6, [x19, #0x90]
   226d8:      	mov	x6, #0x3a               ; =58
   226dc:      	str	x6, [x19, #0x98]
   226e0:      	mov	x6, #0x5555555555555555 ; =6148914691236517205
   226e4:      	str	x6, [x19, #0xb0]
   226e8:      	mov	x6, #0x3ffffffffffffff  ; =288230376151711743
   226ec:      	str	x6, [x19, #0xb8]
   226f0:      	str	x2, [x19, #0x188]
   226f4:      	str	x5, [x19, #0x190]
   226f8:      	str	x22, [x19, #0x17a0]
   226fc:      	str	x23, [x19, #0x17a8]
   22700:      	uxtb	w8, w0
   22704:      	str	x8, [x19, #0x17b8]
   22708:      	str	x1, [x19, #0x17d8]
   2270c:      	add	x10, x22, #0x2
   22710:      	str	x10, [x19, #0x17e0]
   22714:      	str	x28, [x19, #0x4c60]
   22718:      	mov	w14, #0xc87e            ; =51326
   2271c:      	movk	w14, #0x1, lsl #16
   22720:      	sub	x0, x3, x14
   22724:      	str	x0, [x19, #0x4c68]
   22728:      	str	x4, [x19, #0x4c70]
   2272c:      	str	x22, [x19, #0x4f70]
   22730:      	str	x23, [x19, #0x4f78]
   22734:      	ldur	x5, [sp, #0x60]
   22738:      	str	x5, [x19, #0x5a20]
   2273c:      	add	x1, x11, #0x1
   22740:      	str	x1, [x19, #0x5bb0]
   22744:      	ldur	x26, [sp, #0xa0]
   22748:      	str	x26, [x19, #0x5bb8]
   2274c:      	ldur	x7, [sp, #0xa8]
   22750:      	str	x7, [x19, #0x5bc0]
   22754:      	ldur	x4, [sp, #0x90]
   22758:      	sub	x0, x4, x0
   2275c:      	msub	x0, x1, x14, x0
   22760:      	str	x0, [x19, #0x5bc8]
   22764:      	str	x24, [x19, #0x5bd0]
   22768:      	str	x15, [x19, #0x5bd8]
   2276c:      	ldur	x28, [sp, #0xb0]
   22770:      	str	x28, [x19, #0x5be8]
   22774:      	ldur	x4, [sp, #0xb8]
   22778:      	str	x4, [x19, #0x5bf0]
   2277c:      	str	x12, [x19, #0x5c00]
   22780:      	str	x9, [x19, #0x5c08]
   22784:      	str	x13, [x19, #0x5c18]
   22788:      	ldur	x13, [sp, #0xc0]
   2278c:      	str	x13, [x19, #0x5c20]
   22790:      	ldr	x0, [x19, #0x4c60]
   22794:      	cmp	x0, #0x0
   22798:      	b.ne	0x1e310 <_mech_canonical_program_entry_v1_numeric_1282+0x810>
   2279c:      	b	0x1e530 <_mech_canonical_program_entry_v1_numeric_1282+0xa30>
   227a0:      	mov	x21, x0
   227a4:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   227a8:      	mov	x21, x20
   227ac:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   227b0:      	mov	x21, x0
   227b4:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   227b8:      	mov	x21, x20
   227bc:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   227c0:      	mov	x6, #0x516              ; =1302
   227c4:      	str	x6, [x5, #0x48]
   227c8:      	mov	x5, #0x0                ; =0
   227cc:      	str	x5, [x19, #0x18]
   227d0:      	mov	x6, #0x1000000000000000 ; =1152921504606846976
   227d4:      	str	x6, [x19, #0x20]
   227d8:      	mov	x7, #0x1                ; =1
   227dc:      	str	x7, [x19, #0x30]
   227e0:      	mov	x6, #0x101010101010101  ; =72340172838076673
   227e4:      	str	x6, [x19, #0x38]
   227e8:      	mov	x20, #0x2               ; =2
   227ec:      	str	x20, [x19, #0x40]
   227f0:      	mov	x6, #0x3                ; =3
   227f4:      	str	x6, [x19, #0x48]
   227f8:      	mov	x6, #0x4                ; =4
   227fc:      	str	x6, [x19, #0x50]
   22800:      	mov	x6, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   22804:      	str	x6, [x19, #0x78]
   22808:      	mov	x6, #0x3333333333333333 ; =3689348814741910323
   2280c:      	str	x6, [x19, #0x88]
   22810:      	mov	x6, #0x38               ; =56
   22814:      	str	x6, [x19, #0x90]
   22818:      	mov	x6, #0x3a               ; =58
   2281c:      	str	x6, [x19, #0x98]
   22820:      	mov	x6, #0x5555555555555555 ; =6148914691236517205
   22824:      	str	x6, [x19, #0xb0]
   22828:      	mov	x6, #0x3ffffffffffffff  ; =288230376151711743
   2282c:      	str	x6, [x19, #0xb8]
   22830:      	str	x5, [x19, #0x188]
   22834:      	str	x7, [x19, #0x190]
   22838:      	str	x22, [x19, #0x17a0]
   2283c:      	str	x23, [x19, #0x17a8]
   22840:      	uxtb	w0, w0
   22844:      	str	x0, [x19, #0x17b8]
   22848:      	str	x1, [x19, #0x17d8]
   2284c:      	str	x2, [x19, #0x17e8]
   22850:      	ldur	x0, [sp, #0xe8]
   22854:      	str	x0, [x19, #0x17f0]
   22858:      	str	x28, [x19, #0x4c60]
   2285c:      	mov	w5, #0xc87e             ; =51326
   22860:      	movk	w5, #0x1, lsl #16
   22864:      	sub	x6, x3, x5
   22868:      	str	x6, [x19, #0x4c68]
   2286c:      	str	x4, [x19, #0x4c70]
   22870:      	str	x22, [x19, #0x4f70]
   22874:      	str	x23, [x19, #0x4f78]
   22878:      	ldur	x14, [sp, #0x60]
   2287c:      	str	x14, [x19, #0x5a20]
   22880:      	add	x10, x11, #0x1
   22884:      	str	x10, [x19, #0x5bb0]
   22888:      	ldur	x26, [sp, #0xa0]
   2288c:      	str	x26, [x19, #0x5bb8]
   22890:      	ldur	x7, [sp, #0xa8]
   22894:      	str	x7, [x19, #0x5bc0]
   22898:      	ldur	x4, [sp, #0x90]
   2289c:      	sub	x14, x4, x6
   228a0:      	msub	x14, x10, x5, x14
   228a4:      	str	x14, [x19, #0x5bc8]
   228a8:      	str	x24, [x19, #0x5bd0]
   228ac:      	str	x15, [x19, #0x5bd8]
   228b0:      	ldur	x8, [sp, #0xb0]
   228b4:      	str	x8, [x19, #0x5be8]
   228b8:      	ldur	x4, [sp, #0xb8]
   228bc:      	str	x4, [x19, #0x5bf0]
   228c0:      	str	x12, [x19, #0x5c00]
   228c4:      	str	x9, [x19, #0x5c08]
   228c8:      	str	x13, [x19, #0x5c18]
   228cc:      	ldur	x13, [sp, #0xc0]
   228d0:      	str	x13, [x19, #0x5c20]
   228d4:      	ldr	x0, [x19, #0x4c60]
   228d8:      	cmp	x0, #0x0
   228dc:      	b.ne	0x1e5a0 <_mech_canonical_program_entry_v1_numeric_1282+0xaa0>
   228e0:      	b	0x1e7c0 <_mech_canonical_program_entry_v1_numeric_1282+0xcc0>
   228e4:      	mov	x21, x0
   228e8:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   228ec:      	mov	x21, x20
   228f0:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   228f4:      	mov	x21, x0
   228f8:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   228fc:      	mov	x21, x20
   22900:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22904:      	ldur	x21, [sp, #0xd8]
   22908:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   2290c:      	mov	x0, #0x530              ; =1328
   22910:      	ldur	x2, [sp]
   22914:      	str	x0, [x2, #0x48]
   22918:      	mov	x2, #0x0                ; =0
   2291c:      	str	x2, [x19, #0x18]
   22920:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   22924:      	str	x0, [x19, #0x20]
   22928:      	mov	x0, #0x1                ; =1
   2292c:      	str	x0, [x19, #0x30]
   22930:      	mov	x4, #0x101010101010101  ; =72340172838076673
   22934:      	str	x4, [x19, #0x38]
   22938:      	mov	x20, #0x2               ; =2
   2293c:      	str	x20, [x19, #0x40]
   22940:      	mov	x4, #0x3                ; =3
   22944:      	str	x4, [x19, #0x48]
   22948:      	mov	x4, #0x4                ; =4
   2294c:      	str	x4, [x19, #0x50]
   22950:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   22954:      	str	x4, [x19, #0x78]
   22958:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   2295c:      	str	x4, [x19, #0x88]
   22960:      	mov	x4, #0x38               ; =56
   22964:      	str	x4, [x19, #0x90]
   22968:      	mov	x4, #0x3a               ; =58
   2296c:      	str	x4, [x19, #0x98]
   22970:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   22974:      	str	x4, [x19, #0xb0]
   22978:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   2297c:      	str	x4, [x19, #0xb8]
   22980:      	str	x2, [x19, #0x188]
   22984:      	str	x0, [x19, #0x190]
   22988:      	str	x22, [x19, #0x17a0]
   2298c:      	str	x23, [x19, #0x17a8]
   22990:      	ldur	x25, [sp, #0xf0]
   22994:      	uxtb	w5, w25
   22998:      	str	x5, [x19, #0x17b8]
   2299c:      	str	x1, [x19, #0x1858]
   229a0:      	mov	x15, x26
   229a4:      	str	x15, [x19, #0x1860]
   229a8:      	str	x22, [x19, #0x1868]
   229ac:      	ldur	x15, [sp, #0xe0]
   229b0:      	str	x15, [x19, #0x1870]
   229b4:      	ldur	x15, [sp, #0xd8]
   229b8:      	uxtb	w10, w15
   229bc:      	str	x10, [x19, #0x1880]
   229c0:      	add	x14, x1, #0x1
   229c4:      	str	x14, [x19, #0x1890]
   229c8:      	str	x28, [x19, #0x4c60]
   229cc:      	mov	w14, #0x2166            ; =8550
   229d0:      	movk	w14, #0x1, lsl #16
   229d4:      	sub	x14, x3, x14
   229d8:      	str	x14, [x19, #0x4c68]
   229dc:      	ldur	x4, [sp, #0x98]
   229e0:      	str	x4, [x19, #0x4c70]
   229e4:      	str	x22, [x19, #0x4f70]
   229e8:      	str	x23, [x19, #0x4f78]
   229ec:      	str	x1, [x19, #0x50c0]
   229f0:      	mov	x15, x26
   229f4:      	str	x15, [x19, #0x50c8]
   229f8:      	str	x22, [x19, #0x50d0]
   229fc:      	ldur	x15, [sp, #0xe0]
   22a00:      	str	x15, [x19, #0x50d8]
   22a04:      	ldur	x8, [sp, #0x10]
   22a08:      	str	x8, [x19, #0x50e0]
   22a0c:      	str	x27, [x19, #0x50e8]
   22a10:      	str	x24, [x19, #0x50f0]
   22a14:      	ldur	x27, [sp, #0x78]
   22a18:      	str	x27, [x19, #0x50f8]
   22a1c:      	ldur	x26, [sp, #0x80]
   22a20:      	str	x26, [x19, #0x5100]
   22a24:      	ldur	x1, [sp, #0x60]
   22a28:      	str	x1, [x19, #0x5a20]
   22a2c:      	add	x1, x11, #0x1
   22a30:      	str	x1, [x19, #0x5bb0]
   22a34:      	ldur	x26, [sp, #0xa0]
   22a38:      	str	x26, [x19, #0x5bb8]
   22a3c:      	ldur	x7, [sp, #0xa8]
   22a40:      	str	x7, [x19, #0x5bc0]
   22a44:      	ldur	x4, [sp, #0x90]
   22a48:      	sub	x2, x4, x14
   22a4c:      	mov	w3, #0xc87e             ; =51326
   22a50:      	movk	w3, #0x1, lsl #16
   22a54:      	msub	x1, x1, x3, x2
   22a58:      	str	x1, [x19, #0x5bc8]
   22a5c:      	str	x0, [x19, #0x5bd0]
   22a60:      	ldur	x14, [sp, #0x20]
   22a64:      	str	x14, [x19, #0x5bd8]
   22a68:      	ldur	x8, [sp, #0xb0]
   22a6c:      	str	x8, [x19, #0x5be8]
   22a70:      	ldur	x4, [sp, #0xb8]
   22a74:      	str	x4, [x19, #0x5bf0]
   22a78:      	str	x12, [x19, #0x5c00]
   22a7c:      	str	x9, [x19, #0x5c08]
   22a80:      	str	x13, [x19, #0x5c18]
   22a84:      	ldur	x13, [sp, #0xc0]
   22a88:      	str	x13, [x19, #0x5c20]
   22a8c:      	ldr	x0, [x19, #0x4c60]
   22a90:      	cmp	x0, #0x0
   22a94:      	b.ne	0x1ec7c <_mech_canonical_program_entry_v1_numeric_1282+0x117c>
   22a98:      	b	0x1eeb4 <_mech_canonical_program_entry_v1_numeric_1282+0x13b4>
   22a9c:      	mov	x21, x20
   22aa0:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22aa4:      	mov	x21, x20
   22aa8:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22aac:      	mov	x0, #0x531              ; =1329
   22ab0:      	ldur	x14, [sp]
   22ab4:      	str	x0, [x14, #0x48]
   22ab8:      	mov	x4, #0x0                ; =0
   22abc:      	str	x4, [x19, #0x18]
   22ac0:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   22ac4:      	str	x0, [x19, #0x20]
   22ac8:      	mov	x0, #0x1                ; =1
   22acc:      	mov	x21, x0
   22ad0:      	str	x0, [x19, #0x30]
   22ad4:      	mov	x0, #0x101010101010101  ; =72340172838076673
   22ad8:      	str	x0, [x19, #0x38]
   22adc:      	mov	x0, #0x2                ; =2
   22ae0:      	str	x0, [x19, #0x40]
   22ae4:      	mov	x0, #0x3                ; =3
   22ae8:      	str	x0, [x19, #0x48]
   22aec:      	mov	x0, #0x4                ; =4
   22af0:      	str	x0, [x19, #0x50]
   22af4:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   22af8:      	str	x0, [x19, #0x78]
   22afc:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   22b00:      	str	x0, [x19, #0x88]
   22b04:      	mov	x0, #0x38               ; =56
   22b08:      	str	x0, [x19, #0x90]
   22b0c:      	mov	x5, #0x3a               ; =58
   22b10:      	str	x5, [x19, #0x98]
   22b14:      	mov	x5, #0x5555555555555555 ; =6148914691236517205
   22b18:      	str	x5, [x19, #0xb0]
   22b1c:      	mov	x5, #0x3ffffffffffffff  ; =288230376151711743
   22b20:      	str	x5, [x19, #0xb8]
   22b24:      	str	x4, [x19, #0x188]
   22b28:      	mov	x0, x21
   22b2c:      	str	x0, [x19, #0x190]
   22b30:      	str	x22, [x19, #0x17a0]
   22b34:      	str	x23, [x19, #0x17a8]
   22b38:      	ldur	x25, [sp, #0xf0]
   22b3c:      	uxtb	w8, w25
   22b40:      	str	x8, [x19, #0x17b8]
   22b44:      	str	x1, [x19, #0x1858]
   22b48:      	mov	x15, x26
   22b4c:      	str	x15, [x19, #0x1860]
   22b50:      	str	x22, [x19, #0x1868]
   22b54:      	ldur	x15, [sp, #0xe0]
   22b58:      	str	x15, [x19, #0x1870]
   22b5c:      	ldur	x15, [sp, #0xd8]
   22b60:      	uxtb	w14, w15
   22b64:      	str	x14, [x19, #0x1880]
   22b68:      	str	x2, [x19, #0x1898]
   22b6c:      	str	x28, [x19, #0x4c60]
   22b70:      	mov	w1, #0x2166             ; =8550
   22b74:      	movk	w1, #0x1, lsl #16
   22b78:      	sub	x1, x3, x1
   22b7c:      	str	x1, [x19, #0x4c68]
   22b80:      	ldur	x4, [sp, #0x98]
   22b84:      	str	x4, [x19, #0x4c70]
   22b88:      	ldur	x14, [sp, #0x60]
   22b8c:      	str	x14, [x19, #0x5a20]
   22b90:      	add	x2, x11, #0x1
   22b94:      	str	x2, [x19, #0x5bb0]
   22b98:      	ldur	x26, [sp, #0xa0]
   22b9c:      	str	x26, [x19, #0x5bb8]
   22ba0:      	ldur	x7, [sp, #0xa8]
   22ba4:      	str	x7, [x19, #0x5bc0]
   22ba8:      	ldur	x4, [sp, #0x90]
   22bac:      	sub	x1, x4, x1
   22bb0:      	mov	w3, #0xc87e             ; =51326
   22bb4:      	movk	w3, #0x1, lsl #16
   22bb8:      	msub	x0, x2, x3, x1
   22bbc:      	str	x0, [x19, #0x5bc8]
   22bc0:      	mov	x0, x21
   22bc4:      	str	x0, [x19, #0x5bd0]
   22bc8:      	ldur	x14, [sp, #0x20]
   22bcc:      	str	x14, [x19, #0x5bd8]
   22bd0:      	ldur	x8, [sp, #0xb0]
   22bd4:      	str	x8, [x19, #0x5be8]
   22bd8:      	ldur	x4, [sp, #0xb8]
   22bdc:      	str	x4, [x19, #0x5bf0]
   22be0:      	str	x12, [x19, #0x5c00]
   22be4:      	str	x9, [x19, #0x5c08]
   22be8:      	str	x13, [x19, #0x5c18]
   22bec:      	ldur	x13, [sp, #0xc0]
   22bf0:      	str	x13, [x19, #0x5c20]
   22bf4:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22bf8:      	mov	x0, #0x532              ; =1330
   22bfc:      	ldur	x5, [sp]
   22c00:      	str	x0, [x5, #0x48]
   22c04:      	mov	x5, #0x0                ; =0
   22c08:      	str	x5, [x19, #0x18]
   22c0c:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   22c10:      	str	x0, [x19, #0x20]
   22c14:      	mov	x0, #0x1                ; =1
   22c18:      	str	x0, [x19, #0x30]
   22c1c:      	mov	x6, #0x101010101010101  ; =72340172838076673
   22c20:      	str	x6, [x19, #0x38]
   22c24:      	mov	x20, #0x2               ; =2
   22c28:      	str	x20, [x19, #0x40]
   22c2c:      	mov	x6, #0x3                ; =3
   22c30:      	str	x6, [x19, #0x48]
   22c34:      	mov	x6, #0x4                ; =4
   22c38:      	str	x6, [x19, #0x50]
   22c3c:      	mov	x6, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   22c40:      	str	x6, [x19, #0x78]
   22c44:      	mov	x6, #0x3333333333333333 ; =3689348814741910323
   22c48:      	str	x6, [x19, #0x88]
   22c4c:      	mov	x6, #0x38               ; =56
   22c50:      	str	x6, [x19, #0x90]
   22c54:      	mov	x6, #0x3a               ; =58
   22c58:      	str	x6, [x19, #0x98]
   22c5c:      	mov	x6, #0x5555555555555555 ; =6148914691236517205
   22c60:      	str	x6, [x19, #0xb0]
   22c64:      	mov	x6, #0x3ffffffffffffff  ; =288230376151711743
   22c68:      	str	x6, [x19, #0xb8]
   22c6c:      	str	x5, [x19, #0x188]
   22c70:      	str	x0, [x19, #0x190]
   22c74:      	str	x22, [x19, #0x17a0]
   22c78:      	str	x23, [x19, #0x17a8]
   22c7c:      	ldur	x25, [sp, #0xf0]
   22c80:      	uxtb	w5, w25
   22c84:      	str	x5, [x19, #0x17b8]
   22c88:      	str	x1, [x19, #0x1858]
   22c8c:      	mov	x15, x26
   22c90:      	str	x15, [x19, #0x1860]
   22c94:      	str	x22, [x19, #0x1868]
   22c98:      	ldur	x15, [sp, #0xe0]
   22c9c:      	str	x15, [x19, #0x1870]
   22ca0:      	ldur	x15, [sp, #0xd8]
   22ca4:      	uxtb	w5, w15
   22ca8:      	str	x5, [x19, #0x1880]
   22cac:      	str	x2, [x19, #0x1898]
   22cb0:      	str	x4, [x19, #0x18a0]
   22cb4:      	str	x28, [x19, #0x4c60]
   22cb8:      	mov	w2, #0x2166             ; =8550
   22cbc:      	movk	w2, #0x1, lsl #16
   22cc0:      	sub	x2, x3, x2
   22cc4:      	str	x2, [x19, #0x4c68]
   22cc8:      	ldur	x4, [sp, #0x98]
   22ccc:      	str	x4, [x19, #0x4c70]
   22cd0:      	str	x22, [x19, #0x4f70]
   22cd4:      	str	x23, [x19, #0x4f78]
   22cd8:      	str	x1, [x19, #0x50c0]
   22cdc:      	mov	x15, x26
   22ce0:      	str	x15, [x19, #0x50c8]
   22ce4:      	str	x22, [x19, #0x50d0]
   22ce8:      	ldur	x15, [sp, #0xe0]
   22cec:      	str	x15, [x19, #0x50d8]
   22cf0:      	ldur	x24, [sp, #0x10]
   22cf4:      	str	x24, [x19, #0x50e0]
   22cf8:      	str	x27, [x19, #0x50e8]
   22cfc:      	ldur	x24, [sp, #0x70]
   22d00:      	str	x24, [x19, #0x50f0]
   22d04:      	ldur	x24, [sp, #0x78]
   22d08:      	str	x24, [x19, #0x50f8]
   22d0c:      	ldur	x26, [sp, #0x80]
   22d10:      	str	x26, [x19, #0x5100]
   22d14:      	ldur	x14, [sp, #0x60]
   22d18:      	str	x14, [x19, #0x5a20]
   22d1c:      	add	x14, x11, #0x1
   22d20:      	str	x14, [x19, #0x5bb0]
   22d24:      	ldur	x26, [sp, #0xa0]
   22d28:      	str	x26, [x19, #0x5bb8]
   22d2c:      	ldur	x7, [sp, #0xa8]
   22d30:      	str	x7, [x19, #0x5bc0]
   22d34:      	ldur	x4, [sp, #0x90]
   22d38:      	sub	x1, x4, x2
   22d3c:      	mov	w2, #0xc87e             ; =51326
   22d40:      	movk	w2, #0x1, lsl #16
   22d44:      	msub	x1, x14, x2, x1
   22d48:      	str	x1, [x19, #0x5bc8]
   22d4c:      	str	x0, [x19, #0x5bd0]
   22d50:      	ldur	x14, [sp, #0x20]
   22d54:      	str	x14, [x19, #0x5bd8]
   22d58:      	ldur	x8, [sp, #0xb0]
   22d5c:      	str	x8, [x19, #0x5be8]
   22d60:      	ldur	x4, [sp, #0xb8]
   22d64:      	str	x4, [x19, #0x5bf0]
   22d68:      	str	x12, [x19, #0x5c00]
   22d6c:      	str	x9, [x19, #0x5c08]
   22d70:      	str	x13, [x19, #0x5c18]
   22d74:      	ldur	x13, [sp, #0xc0]
   22d78:      	str	x13, [x19, #0x5c20]
   22d7c:      	ldr	x0, [x19, #0x4c60]
   22d80:      	cmp	x0, #0x0
   22d84:      	b.ne	0x1ef34 <_mech_canonical_program_entry_v1_numeric_1282+0x1434>
   22d88:      	b	0x1f164 <_mech_canonical_program_entry_v1_numeric_1282+0x1664>
   22d8c:      	mov	x21, x20
   22d90:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22d94:      	mov	x21, x20
   22d98:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22d9c:      	mov	x0, #0x534              ; =1332
   22da0:      	ldur	x1, [sp]
   22da4:      	str	x0, [x1, #0x48]
   22da8:      	mov	x1, #0x0                ; =0
   22dac:      	str	x1, [x19, #0x18]
   22db0:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   22db4:      	str	x0, [x19, #0x20]
   22db8:      	mov	x0, #0x1                ; =1
   22dbc:      	str	x0, [x19, #0x30]
   22dc0:      	mov	x4, #0x101010101010101  ; =72340172838076673
   22dc4:      	str	x4, [x19, #0x38]
   22dc8:      	mov	x20, #0x2               ; =2
   22dcc:      	str	x20, [x19, #0x40]
   22dd0:      	mov	x4, #0x3                ; =3
   22dd4:      	str	x4, [x19, #0x48]
   22dd8:      	mov	x4, #0x4                ; =4
   22ddc:      	str	x4, [x19, #0x50]
   22de0:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   22de4:      	str	x4, [x19, #0x78]
   22de8:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   22dec:      	str	x4, [x19, #0x88]
   22df0:      	mov	x4, #0x38               ; =56
   22df4:      	str	x4, [x19, #0x90]
   22df8:      	mov	x4, #0x3a               ; =58
   22dfc:      	str	x4, [x19, #0x98]
   22e00:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   22e04:      	str	x4, [x19, #0xb0]
   22e08:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   22e0c:      	str	x4, [x19, #0xb8]
   22e10:      	str	x1, [x19, #0x188]
   22e14:      	str	x0, [x19, #0x190]
   22e18:      	str	x22, [x19, #0x17a0]
   22e1c:      	str	x23, [x19, #0x17a8]
   22e20:      	ldur	x25, [sp, #0xf0]
   22e24:      	uxtb	w1, w25
   22e28:      	str	x1, [x19, #0x17b8]
   22e2c:      	ldur	x1, [sp, #0x18]
   22e30:      	str	x1, [x19, #0x1858]
   22e34:      	mov	x15, x26
   22e38:      	str	x15, [x19, #0x1860]
   22e3c:      	str	x22, [x19, #0x1868]
   22e40:      	ldur	x15, [sp, #0xe0]
   22e44:      	str	x15, [x19, #0x1870]
   22e48:      	ldur	x15, [sp, #0xd8]
   22e4c:      	uxtb	w1, w15
   22e50:      	str	x1, [x19, #0x1880]
   22e54:      	str	x27, [x19, #0x18a8]
   22e58:      	add	x4, x2, #0x2
   22e5c:      	str	x4, [x19, #0x18b0]
   22e60:      	str	x28, [x19, #0x4c60]
   22e64:      	mov	w5, #0x2166             ; =8550
   22e68:      	movk	w5, #0x1, lsl #16
   22e6c:      	sub	x5, x3, x5
   22e70:      	str	x5, [x19, #0x4c68]
   22e74:      	ldur	x4, [sp, #0x98]
   22e78:      	str	x4, [x19, #0x4c70]
   22e7c:      	str	x22, [x19, #0x4f70]
   22e80:      	str	x23, [x19, #0x4f78]
   22e84:      	ldur	x27, [sp, #0x18]
   22e88:      	str	x27, [x19, #0x50c0]
   22e8c:      	mov	x15, x26
   22e90:      	str	x15, [x19, #0x50c8]
   22e94:      	str	x22, [x19, #0x50d0]
   22e98:      	ldur	x15, [sp, #0xe0]
   22e9c:      	str	x15, [x19, #0x50d8]
   22ea0:      	ldur	x24, [sp, #0x10]
   22ea4:      	str	x24, [x19, #0x50e0]
   22ea8:      	ldur	x26, [sp, #0x68]
   22eac:      	str	x26, [x19, #0x50e8]
   22eb0:      	ldur	x27, [sp, #0x70]
   22eb4:      	str	x27, [x19, #0x50f0]
   22eb8:      	ldur	x24, [sp, #0x78]
   22ebc:      	str	x24, [x19, #0x50f8]
   22ec0:      	ldur	x26, [sp, #0x80]
   22ec4:      	str	x26, [x19, #0x5100]
   22ec8:      	ldur	x14, [sp, #0x60]
   22ecc:      	str	x14, [x19, #0x5a20]
   22ed0:      	add	x1, x11, #0x1
   22ed4:      	str	x1, [x19, #0x5bb0]
   22ed8:      	ldur	x26, [sp, #0xa0]
   22edc:      	str	x26, [x19, #0x5bb8]
   22ee0:      	ldur	x7, [sp, #0xa8]
   22ee4:      	str	x7, [x19, #0x5bc0]
   22ee8:      	ldur	x4, [sp, #0x90]
   22eec:      	sub	x2, x4, x5
   22ef0:      	mov	w3, #0xc87e             ; =51326
   22ef4:      	movk	w3, #0x1, lsl #16
   22ef8:      	msub	x1, x1, x3, x2
   22efc:      	str	x1, [x19, #0x5bc8]
   22f00:      	str	x0, [x19, #0x5bd0]
   22f04:      	ldur	x14, [sp, #0x20]
   22f08:      	str	x14, [x19, #0x5bd8]
   22f0c:      	ldur	x8, [sp, #0xb0]
   22f10:      	str	x8, [x19, #0x5be8]
   22f14:      	ldur	x4, [sp, #0xb8]
   22f18:      	str	x4, [x19, #0x5bf0]
   22f1c:      	str	x12, [x19, #0x5c00]
   22f20:      	str	x9, [x19, #0x5c08]
   22f24:      	str	x13, [x19, #0x5c18]
   22f28:      	ldur	x13, [sp, #0xc0]
   22f2c:      	str	x13, [x19, #0x5c20]
   22f30:      	ldr	x0, [x19, #0x4c60]
   22f34:      	cmp	x0, #0x0
   22f38:      	b.ne	0x1f1dc <_mech_canonical_program_entry_v1_numeric_1282+0x16dc>
   22f3c:      	b	0x1f408 <_mech_canonical_program_entry_v1_numeric_1282+0x1908>
   22f40:      	mov	x21, x20
   22f44:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22f48:      	mov	x21, x20
   22f4c:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22f50:      	mov	x21, x20
   22f54:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22f58:      	mov	x0, #0x54e              ; =1358
   22f5c:      	ldur	x1, [sp]
   22f60:      	str	x0, [x1, #0x48]
   22f64:      	mov	x0, #0x0                ; =0
   22f68:      	str	x0, [x19, #0x18]
   22f6c:      	mov	x1, #0x1000000000000000 ; =1152921504606846976
   22f70:      	str	x1, [x19, #0x20]
   22f74:      	mov	x5, #0x1                ; =1
   22f78:      	str	x5, [x19, #0x30]
   22f7c:      	mov	x1, #0x101010101010101  ; =72340172838076673
   22f80:      	str	x1, [x19, #0x38]
   22f84:      	mov	x25, #0x2               ; =2
   22f88:      	str	x25, [x19, #0x40]
   22f8c:      	mov	x1, #0x3                ; =3
   22f90:      	str	x1, [x19, #0x48]
   22f94:      	mov	x1, #0x4                ; =4
   22f98:      	str	x1, [x19, #0x50]
   22f9c:      	mov	x1, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   22fa0:      	str	x1, [x19, #0x78]
   22fa4:      	mov	x1, #0x3333333333333333 ; =3689348814741910323
   22fa8:      	str	x1, [x19, #0x88]
   22fac:      	mov	x1, #0x38               ; =56
   22fb0:      	str	x1, [x19, #0x90]
   22fb4:      	mov	x1, #0x3a               ; =58
   22fb8:      	str	x1, [x19, #0x98]
   22fbc:      	mov	x1, #0x5555555555555555 ; =6148914691236517205
   22fc0:      	str	x1, [x19, #0xb0]
   22fc4:      	mov	x1, #0x3ffffffffffffff  ; =288230376151711743
   22fc8:      	str	x1, [x19, #0xb8]
   22fcc:      	str	x0, [x19, #0x188]
   22fd0:      	str	x5, [x19, #0x190]
   22fd4:      	str	x22, [x19, #0x17a0]
   22fd8:      	str	x23, [x19, #0x17a8]
   22fdc:      	ldur	x0, [sp, #0xf0]
   22fe0:      	uxtb	w0, w0
   22fe4:      	str	x0, [x19, #0x17b8]
   22fe8:      	ldur	x0, [sp, #0x18]
   22fec:      	str	x0, [x19, #0x1858]
   22ff0:      	mov	x2, x26
   22ff4:      	str	x2, [x19, #0x1860]
   22ff8:      	str	x22, [x19, #0x1868]
   22ffc:      	ldur	x14, [sp, #0xe0]
   23000:      	str	x14, [x19, #0x1870]
   23004:      	ldur	x0, [sp, #0xd8]
   23008:      	uxtb	w0, w0
   2300c:      	str	x0, [x19, #0x1880]
   23010:      	str	x27, [x19, #0x1918]
   23014:      	str	x7, [x19, #0x1920]
   23018:      	str	x22, [x19, #0x1928]
   2301c:      	ldur	x0, [sp, #0xe0]
   23020:      	str	x0, [x19, #0x1930]
   23024:      	uxtb	w0, w10
   23028:      	str	x0, [x19, #0x1940]
   2302c:      	add	x0, x27, #0x1
   23030:      	str	x0, [x19, #0x1950]
   23034:      	str	x28, [x19, #0x4c60]
   23038:      	mov	w0, #0xdc1e             ; =56350
   2303c:      	movk	w0, #0x2, lsl #16
   23040:      	sub	x4, x6, x0
   23044:      	str	x4, [x19, #0x4c68]
   23048:      	ldur	x8, [sp, #0x98]
   2304c:      	str	x8, [x19, #0x4c70]
   23050:      	str	x22, [x19, #0x4f70]
   23054:      	str	x23, [x19, #0x4f78]
   23058:      	ldur	x0, [sp, #0x18]
   2305c:      	str	x0, [x19, #0x50c0]
   23060:      	mov	x0, x26
   23064:      	str	x0, [x19, #0x50c8]
   23068:      	str	x22, [x19, #0x50d0]
   2306c:      	ldur	x0, [sp, #0xe0]
   23070:      	str	x0, [x19, #0x50d8]
   23074:      	ldur	x0, [sp, #0x10]
   23078:      	str	x0, [x19, #0x50e0]
   2307c:      	ldur	x26, [sp, #0x68]
   23080:      	str	x26, [x19, #0x50e8]
   23084:      	ldur	x0, [sp, #0x70]
   23088:      	str	x0, [x19, #0x50f0]
   2308c:      	ldur	x0, [sp, #0x78]
   23090:      	str	x0, [x19, #0x50f8]
   23094:      	ldur	x26, [sp, #0x80]
   23098:      	str	x26, [x19, #0x5100]
   2309c:      	str	x27, [x19, #0x52a8]
   230a0:      	str	x7, [x19, #0x52b0]
   230a4:      	str	x22, [x19, #0x52b8]
   230a8:      	ldur	x0, [sp, #0xe0]
   230ac:      	str	x0, [x19, #0x52c0]
   230b0:      	ldur	x2, [sp, #0x28]
   230b4:      	str	x2, [x19, #0x52c8]
   230b8:      	str	x15, [x19, #0x52d0]
   230bc:      	str	x24, [x19, #0x52d8]
   230c0:      	ldur	x1, [sp, #0x38]
   230c4:      	str	x1, [x19, #0x52e0]
   230c8:      	ldur	x0, [sp, #0x40]
   230cc:      	str	x0, [x19, #0x52e8]
   230d0:      	ldur	x14, [sp, #0x60]
   230d4:      	str	x14, [x19, #0x5a20]
   230d8:      	add	x11, x11, #0x1
   230dc:      	str	x11, [x19, #0x5bb0]
   230e0:      	ldur	x26, [sp, #0xa0]
   230e4:      	str	x26, [x19, #0x5bb8]
   230e8:      	ldur	x7, [sp, #0xa8]
   230ec:      	str	x7, [x19, #0x5bc0]
   230f0:      	ldur	x0, [sp, #0x90]
   230f4:      	sub	x14, x0, x4
   230f8:      	mov	w15, #0xc87e            ; =51326
   230fc:      	movk	w15, #0x1, lsl #16
   23100:      	msub	x14, x11, x15, x14
   23104:      	str	x14, [x19, #0x5bc8]
   23108:      	str	x5, [x19, #0x5bd0]
   2310c:      	ldur	x14, [sp, #0x20]
   23110:      	str	x14, [x19, #0x5bd8]
   23114:      	str	x5, [x19, #0x5be8]
   23118:      	str	x3, [x19, #0x5bf0]
   2311c:      	str	x12, [x19, #0x5c00]
   23120:      	str	x9, [x19, #0x5c08]
   23124:      	str	x13, [x19, #0x5c18]
   23128:      	ldur	x13, [sp, #0xc0]
   2312c:      	str	x13, [x19, #0x5c20]
   23130:      	ldr	x0, [x19, #0x4c60]
   23134:      	cmp	x0, #0x0
   23138:      	b.ne	0x1f940 <_mech_canonical_program_entry_v1_numeric_1282+0x1e40>
   2313c:      	b	0x1fb64 <_mech_canonical_program_entry_v1_numeric_1282+0x2064>
   23140:      	mov	x21, x25
   23144:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   23148:      	mov	x21, x25
   2314c:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   23150:      	mov	x0, #0x554              ; =1364
   23154:      	ldur	x1, [sp]
   23158:      	str	x0, [x1, #0x48]
   2315c:      	mov	x1, #0x0                ; =0
   23160:      	str	x1, [x19, #0x18]
   23164:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   23168:      	str	x0, [x19, #0x20]
   2316c:      	mov	x0, #0x1                ; =1
   23170:      	mov	x21, x0
   23174:      	str	x0, [x19, #0x30]
   23178:      	mov	x0, #0x101010101010101  ; =72340172838076673
   2317c:      	str	x0, [x19, #0x38]
   23180:      	mov	x0, #0x2                ; =2
   23184:      	str	x0, [x19, #0x40]
   23188:      	mov	x0, #0x3                ; =3
   2318c:      	str	x0, [x19, #0x48]
   23190:      	mov	x0, #0x4                ; =4
   23194:      	str	x0, [x19, #0x50]
   23198:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   2319c:      	str	x0, [x19, #0x78]
   231a0:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   231a4:      	str	x0, [x19, #0x88]
   231a8:      	mov	x0, #0x38               ; =56
   231ac:      	str	x0, [x19, #0x90]
   231b0:      	mov	x0, #0x3a               ; =58
   231b4:      	str	x0, [x19, #0x98]
   231b8:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   231bc:      	str	x0, [x19, #0xb0]
   231c0:      	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
   231c4:      	str	x0, [x19, #0xb8]
   231c8:      	str	x1, [x19, #0x188]
   231cc:      	mov	x0, x21
   231d0:      	str	x0, [x19, #0x190]
   231d4:      	str	x22, [x19, #0x17a0]
   231d8:      	str	x23, [x19, #0x17a8]
   231dc:      	ldur	x25, [sp, #0xf0]
   231e0:      	uxtb	w0, w25
   231e4:      	str	x0, [x19, #0x17b8]
   231e8:      	ldur	x0, [sp, #0x18]
   231ec:      	str	x0, [x19, #0x1858]
   231f0:      	mov	x15, x26
   231f4:      	str	x15, [x19, #0x1860]
   231f8:      	str	x22, [x19, #0x1868]
   231fc:      	ldur	x15, [sp, #0xe0]
   23200:      	str	x15, [x19, #0x1870]
   23204:      	ldur	x15, [sp, #0xd8]
   23208:      	uxtb	w4, w15
   2320c:      	str	x4, [x19, #0x1880]
   23210:      	str	x27, [x19, #0x1918]
   23214:      	str	x7, [x19, #0x1920]
   23218:      	str	x22, [x19, #0x1928]
   2321c:      	ldur	x15, [sp, #0xe0]
   23220:      	str	x15, [x19, #0x1930]
   23224:      	uxtb	w10, w10
   23228:      	str	x10, [x19, #0x1940]
   2322c:      	str	x14, [x19, #0x1958]
   23230:      	str	x28, [x19, #0x4c60]
   23234:      	mov	w14, #0xdc1e            ; =56350
   23238:      	movk	w14, #0x2, lsl #16
   2323c:      	sub	x14, x6, x14
   23240:      	str	x14, [x19, #0x4c68]
   23244:      	ldur	x4, [sp, #0x98]
   23248:      	str	x4, [x19, #0x4c70]
   2324c:      	ldur	x0, [sp, #0x60]
   23250:      	str	x0, [x19, #0x5a20]
   23254:      	add	x15, x11, #0x1
   23258:      	str	x15, [x19, #0x5bb0]
   2325c:      	ldur	x26, [sp, #0xa0]
   23260:      	str	x26, [x19, #0x5bb8]
   23264:      	ldur	x7, [sp, #0xa8]
   23268:      	str	x7, [x19, #0x5bc0]
   2326c:      	ldur	x4, [sp, #0x90]
   23270:      	sub	x1, x4, x14
   23274:      	mov	w2, #0xc87e             ; =51326
   23278:      	movk	w2, #0x1, lsl #16
   2327c:      	msub	x0, x15, x2, x1
   23280:      	str	x0, [x19, #0x5bc8]
   23284:      	mov	x0, x21
   23288:      	str	x0, [x19, #0x5bd0]
   2328c:      	ldur	x14, [sp, #0x20]
   23290:      	str	x14, [x19, #0x5bd8]
   23294:      	str	x0, [x19, #0x5be8]
   23298:      	str	x3, [x19, #0x5bf0]
   2329c:      	str	x12, [x19, #0x5c00]
   232a0:      	str	x9, [x19, #0x5c08]
   232a4:      	str	x13, [x19, #0x5c18]
   232a8:      	ldur	x13, [sp, #0xc0]
   232ac:      	str	x13, [x19, #0x5c20]
   232b0:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   232b4:      	mov	x5, #0x555              ; =1365
   232b8:      	ldur	x8, [sp]
   232bc:      	str	x5, [x8, #0x48]
   232c0:      	mov	x21, #0x0               ; =0
   232c4:      	str	x21, [x19, #0x18]
   232c8:      	mov	x5, #0x1000000000000000 ; =1152921504606846976
   232cc:      	str	x5, [x19, #0x20]
   232d0:      	mov	x5, #0x1                ; =1
   232d4:      	str	x5, [x19, #0x30]
   232d8:      	mov	x8, #0x101010101010101  ; =72340172838076673
   232dc:      	str	x8, [x19, #0x38]
   232e0:      	mov	x20, #0x2               ; =2
   232e4:      	str	x20, [x19, #0x40]
   232e8:      	mov	x8, #0x3                ; =3
   232ec:      	str	x8, [x19, #0x48]
   232f0:      	mov	x8, #0x4                ; =4
   232f4:      	str	x8, [x19, #0x50]
   232f8:      	mov	x8, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   232fc:      	str	x8, [x19, #0x78]
   23300:      	mov	x8, #0x3333333333333333 ; =3689348814741910323
   23304:      	str	x8, [x19, #0x88]
   23308:      	mov	x8, #0x38               ; =56
   2330c:      	str	x8, [x19, #0x90]
   23310:      	mov	x8, #0x3a               ; =58
   23314:      	str	x8, [x19, #0x98]
   23318:      	mov	x8, #0x5555555555555555 ; =6148914691236517205
   2331c:      	str	x8, [x19, #0xb0]
   23320:      	mov	x8, #0x3ffffffffffffff  ; =288230376151711743
   23324:      	str	x8, [x19, #0xb8]
   23328:      	str	x21, [x19, #0x188]
   2332c:      	str	x5, [x19, #0x190]
   23330:      	str	x22, [x19, #0x17a0]
   23334:      	str	x23, [x19, #0x17a8]
   23338:      	ldur	x25, [sp, #0xf0]
   2333c:      	uxtb	w8, w25
   23340:      	str	x8, [x19, #0x17b8]
   23344:      	ldur	x8, [sp, #0x18]
   23348:      	str	x8, [x19, #0x1858]
   2334c:      	mov	x8, x26
   23350:      	str	x8, [x19, #0x1860]
   23354:      	str	x22, [x19, #0x1868]
   23358:      	ldur	x8, [sp, #0xe0]
   2335c:      	str	x8, [x19, #0x1870]
   23360:      	ldur	x8, [sp, #0xd8]
   23364:      	uxtb	w8, w8
   23368:      	str	x8, [x19, #0x1880]
   2336c:      	str	x27, [x19, #0x1918]
   23370:      	str	x7, [x19, #0x1920]
   23374:      	str	x22, [x19, #0x1928]
   23378:      	ldur	x8, [sp, #0xe0]
   2337c:      	str	x8, [x19, #0x1930]
   23380:      	uxtb	w8, w10
   23384:      	str	x8, [x19, #0x1940]
   23388:      	str	x14, [x19, #0x1958]
   2338c:      	str	x4, [x19, #0x1970]
   23390:      	str	x28, [x19, #0x4c60]
   23394:      	mov	w4, #0xdc1e             ; =56350
   23398:      	movk	w4, #0x2, lsl #16
   2339c:      	sub	x4, x6, x4
   233a0:      	str	x4, [x19, #0x4c68]
   233a4:      	ldur	x14, [sp, #0x98]
   233a8:      	str	x14, [x19, #0x4c70]
   233ac:      	str	x22, [x19, #0x4f70]
   233b0:      	str	x23, [x19, #0x4f78]
   233b4:      	ldur	x6, [sp, #0x18]
   233b8:      	str	x6, [x19, #0x50c0]
   233bc:      	mov	x6, x26
   233c0:      	str	x6, [x19, #0x50c8]
   233c4:      	str	x22, [x19, #0x50d0]
   233c8:      	ldur	x6, [sp, #0xe0]
   233cc:      	str	x6, [x19, #0x50d8]
   233d0:      	ldur	x6, [sp, #0x10]
   233d4:      	str	x6, [x19, #0x50e0]
   233d8:      	ldur	x26, [sp, #0x68]
   233dc:      	str	x26, [x19, #0x50e8]
   233e0:      	ldur	x6, [sp, #0x70]
   233e4:      	str	x6, [x19, #0x50f0]
   233e8:      	ldur	x6, [sp, #0x78]
   233ec:      	str	x6, [x19, #0x50f8]
   233f0:      	ldur	x26, [sp, #0x80]
   233f4:      	str	x26, [x19, #0x5100]
   233f8:      	str	x27, [x19, #0x52a8]
   233fc:      	str	x7, [x19, #0x52b0]
   23400:      	str	x22, [x19, #0x52b8]
   23404:      	ldur	x6, [sp, #0xe0]
   23408:      	str	x6, [x19, #0x52c0]
   2340c:      	str	x2, [x19, #0x52c8]
   23410:      	str	x15, [x19, #0x52d0]
   23414:      	str	x24, [x19, #0x52d8]
   23418:      	str	x1, [x19, #0x52e0]
   2341c:      	str	x0, [x19, #0x52e8]
   23420:      	ldur	x14, [sp, #0x60]
   23424:      	str	x14, [x19, #0x5a20]
   23428:      	add	x0, x11, #0x1
   2342c:      	str	x0, [x19, #0x5bb0]
   23430:      	ldur	x26, [sp, #0xa0]
   23434:      	str	x26, [x19, #0x5bb8]
   23438:      	ldur	x7, [sp, #0xa8]
   2343c:      	str	x7, [x19, #0x5bc0]
   23440:      	ldur	x1, [sp, #0x90]
   23444:      	sub	x1, x1, x4
   23448:      	mov	w2, #0xc87e             ; =51326
   2344c:      	movk	w2, #0x1, lsl #16
   23450:      	msub	x0, x0, x2, x1
   23454:      	str	x0, [x19, #0x5bc8]
   23458:      	str	x5, [x19, #0x5bd0]
   2345c:      	ldur	x14, [sp, #0x20]
   23460:      	str	x14, [x19, #0x5bd8]
   23464:      	str	x5, [x19, #0x5be8]
   23468:      	str	x3, [x19, #0x5bf0]
   2346c:      	str	x12, [x19, #0x5c00]
   23470:      	str	x9, [x19, #0x5c08]
   23474:      	str	x13, [x19, #0x5c18]
   23478:      	ldur	x13, [sp, #0xc0]
   2347c:      	str	x13, [x19, #0x5c20]
   23480:      	ldr	x0, [x19, #0x4c60]
   23484:      	cmp	x0, #0x0
   23488:      	b.ne	0x1fc10 <_mech_canonical_program_entry_v1_numeric_1282+0x2110>
   2348c:      	b	0x1fe44 <_mech_canonical_program_entry_v1_numeric_1282+0x2344>
   23490:      	mov	x21, x20
   23494:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   23498:      	mov	x21, x20
   2349c:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   234a0:      	mov	x0, #0x5e8              ; =1512
   234a4:      	ldur	x1, [sp]
   234a8:      	str	x0, [x1, #0x48]
   234ac:      	mov	x0, #0x0                ; =0
   234b0:      	str	x0, [x19, #0x18]
   234b4:      	mov	x1, #0x1000000000000000 ; =1152921504606846976
   234b8:      	str	x1, [x19, #0x20]
   234bc:      	mov	x1, #0x1                ; =1
   234c0:      	str	x1, [x19, #0x30]
   234c4:      	mov	x2, #0x101010101010101  ; =72340172838076673
   234c8:      	str	x2, [x19, #0x38]
   234cc:      	mov	x20, #0x2               ; =2
   234d0:      	str	x20, [x19, #0x40]
   234d4:      	mov	x4, #0x3                ; =3
   234d8:      	str	x4, [x19, #0x48]
   234dc:      	mov	x4, #0x4                ; =4
   234e0:      	str	x4, [x19, #0x50]
   234e4:      	mov	x5, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   234e8:      	str	x5, [x19, #0x78]
   234ec:      	mov	x6, #0x3333333333333333 ; =3689348814741910323
   234f0:      	str	x6, [x19, #0x88]
   234f4:      	mov	x7, #0x38               ; =56
   234f8:      	str	x7, [x19, #0x90]
   234fc:      	mov	x8, #0x3a               ; =58
   23500:      	str	x8, [x19, #0x98]
   23504:      	mov	x10, #0x5555555555555555 ; =6148914691236517205
   23508:      	str	x10, [x19, #0xb0]
   2350c:      	mov	x10, #0x3ffffffffffffff ; =288230376151711743
   23510:      	str	x10, [x19, #0xb8]
   23514:      	str	x0, [x19, #0x188]
   23518:      	str	x1, [x19, #0x190]
   2351c:      	str	x22, [x19, #0x17a0]
   23520:      	str	x23, [x19, #0x17a8]
   23524:      	ldur	x25, [sp, #0xf0]
   23528:      	uxtb	w15, w25
   2352c:      	str	x15, [x19, #0x17b8]
   23530:      	ldur	x1, [sp, #0xe8]
   23534:      	str	x1, [x19, #0x1c00]
   23538:      	str	x28, [x19, #0x4c60]
   2353c:      	str	x3, [x19, #0x4c68]
   23540:      	ldur	x4, [sp, #0x98]
   23544:      	str	x4, [x19, #0x4c70]
   23548:      	str	x22, [x19, #0x4f70]
   2354c:      	str	x23, [x19, #0x4f78]
   23550:      	ldur	x14, [sp, #0x60]
   23554:      	str	x14, [x19, #0x5a20]
   23558:      	add	x1, x11, #0x1
   2355c:      	str	x1, [x19, #0x5bb0]
   23560:      	ldur	x26, [sp, #0xa0]
   23564:      	str	x26, [x19, #0x5bb8]
   23568:      	ldur	x7, [sp, #0xa8]
   2356c:      	str	x7, [x19, #0x5bc0]
   23570:      	ldur	x4, [sp, #0x90]
   23574:      	sub	x2, x4, x3
   23578:      	mov	w3, #0xc87e             ; =51326
   2357c:      	movk	w3, #0x1, lsl #16
   23580:      	msub	x1, x1, x3, x2
   23584:      	str	x1, [x19, #0x5bc8]
   23588:      	str	x0, [x19, #0x5bd0]
   2358c:      	str	x0, [x19, #0x5bd8]
   23590:      	ldur	x8, [sp, #0xb0]
   23594:      	str	x8, [x19, #0x5be8]
   23598:      	ldur	x4, [sp, #0xb8]
   2359c:      	str	x4, [x19, #0x5bf0]
   235a0:      	str	x12, [x19, #0x5c00]
   235a4:      	str	x9, [x19, #0x5c08]
   235a8:      	str	x13, [x19, #0x5c18]
   235ac:      	ldur	x13, [sp, #0xc0]
   235b0:      	str	x13, [x19, #0x5c20]
   235b4:      	ldr	x0, [x19, #0x4c60]
   235b8:      	cmp	x0, #0x0
   235bc:      	b.ne	0x200b8 <_mech_canonical_program_entry_v1_numeric_1282+0x25b8>
   235c0:      	b	0x202ec <_mech_canonical_program_entry_v1_numeric_1282+0x27ec>
   235c4:      	mov	x21, x20
   235c8:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   235cc:      	mov	x21, x20
   235d0:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   235d4:      	mov	x0, #0x5ea              ; =1514
   235d8:      	ldur	x8, [sp]
   235dc:      	str	x0, [x8, #0x48]
   235e0:      	mov	x0, #0x0                ; =0
   235e4:      	str	x0, [x19, #0x18]
   235e8:      	mov	x1, #0x1000000000000000 ; =1152921504606846976
   235ec:      	str	x1, [x19, #0x20]
   235f0:      	mov	x1, #0x1                ; =1
   235f4:      	str	x1, [x19, #0x30]
   235f8:      	mov	x2, #0x101010101010101  ; =72340172838076673
   235fc:      	str	x2, [x19, #0x38]
   23600:      	mov	x20, #0x2               ; =2
   23604:      	str	x20, [x19, #0x40]
   23608:      	mov	x2, #0x3                ; =3
   2360c:      	str	x2, [x19, #0x48]
   23610:      	mov	x2, #0x4                ; =4
   23614:      	str	x2, [x19, #0x50]
   23618:      	mov	x2, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   2361c:      	str	x2, [x19, #0x78]
   23620:      	mov	x2, #0x3333333333333333 ; =3689348814741910323
   23624:      	str	x2, [x19, #0x88]
   23628:      	mov	x2, #0x38               ; =56
   2362c:      	str	x2, [x19, #0x90]
   23630:      	mov	x2, #0x3a               ; =58
   23634:      	str	x2, [x19, #0x98]
   23638:      	mov	x2, #0x5555555555555555 ; =6148914691236517205
   2363c:      	str	x2, [x19, #0xb0]
   23640:      	mov	x2, #0x3ffffffffffffff  ; =288230376151711743
   23644:      	str	x2, [x19, #0xb8]
   23648:      	str	x0, [x19, #0x188]
   2364c:      	str	x1, [x19, #0x190]
   23650:      	str	x22, [x19, #0x17a0]
   23654:      	str	x23, [x19, #0x17a8]
   23658:      	ldur	x25, [sp, #0xf0]
   2365c:      	uxtb	w6, w25
   23660:      	str	x6, [x19, #0x17b8]
   23664:      	str	x15, [x19, #0x1c08]
   23668:      	add	x8, x22, #0x2
   2366c:      	str	x8, [x19, #0x1c10]
   23670:      	str	x28, [x19, #0x4c60]
   23674:      	str	x3, [x19, #0x4c68]
   23678:      	ldur	x4, [sp, #0x98]
   2367c:      	str	x4, [x19, #0x4c70]
   23680:      	str	x22, [x19, #0x4f70]
   23684:      	str	x23, [x19, #0x4f78]
   23688:      	ldur	x14, [sp, #0x60]
   2368c:      	str	x14, [x19, #0x5a20]
   23690:      	add	x15, x11, #0x1
   23694:      	str	x15, [x19, #0x5bb0]
   23698:      	ldur	x26, [sp, #0xa0]
   2369c:      	str	x26, [x19, #0x5bb8]
   236a0:      	ldur	x7, [sp, #0xa8]
   236a4:      	str	x7, [x19, #0x5bc0]
   236a8:      	ldur	x4, [sp, #0x90]
   236ac:      	sub	x1, x4, x3
   236b0:      	mov	w2, #0xc87e             ; =51326
   236b4:      	movk	w2, #0x1, lsl #16
   236b8:      	msub	x1, x15, x2, x1
   236bc:      	str	x1, [x19, #0x5bc8]
   236c0:      	str	x0, [x19, #0x5bd0]
   236c4:      	str	x0, [x19, #0x5bd8]
   236c8:      	ldur	x8, [sp, #0xb0]
   236cc:      	str	x8, [x19, #0x5be8]
   236d0:      	ldur	x4, [sp, #0xb8]
   236d4:      	str	x4, [x19, #0x5bf0]
   236d8:      	str	x12, [x19, #0x5c00]
   236dc:      	str	x9, [x19, #0x5c08]
   236e0:      	str	x13, [x19, #0x5c18]
   236e4:      	ldur	x13, [sp, #0xc0]
   236e8:      	str	x13, [x19, #0x5c20]
   236ec:      	ldr	x0, [x19, #0x4c60]
   236f0:      	cmp	x0, #0x0
   236f4:      	b.ne	0x20360 <_mech_canonical_program_entry_v1_numeric_1282+0x2860>
   236f8:      	b	0x2058c <_mech_canonical_program_entry_v1_numeric_1282+0x2a8c>
   236fc:      	mov	x21, x20
   23700:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   23704:      	mov	x21, x20
   23708:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   2370c:      	mov	x21, x20
   23710:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   23714:      	mov	x0, #0x604              ; =1540
   23718:      	ldur	x4, [sp]
   2371c:      	str	x0, [x4, #0x48]
   23720:      	mov	x1, #0x0                ; =0
   23724:      	str	x1, [x19, #0x18]
   23728:      	str	x26, [x19, #0x20]
   2372c:      	mov	x0, #0x1                ; =1
   23730:      	mov	x21, x0
   23734:      	str	x0, [x19, #0x30]
   23738:      	mov	x0, #0x101010101010101  ; =72340172838076673
   2373c:      	str	x0, [x19, #0x38]
   23740:      	mov	x0, #0x2                ; =2
   23744:      	str	x0, [x19, #0x40]
   23748:      	mov	x0, #0x3                ; =3
   2374c:      	str	x0, [x19, #0x48]
   23750:      	mov	x0, #0x4                ; =4
   23754:      	str	x0, [x19, #0x50]
   23758:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   2375c:      	str	x0, [x19, #0x78]
   23760:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   23764:      	str	x0, [x19, #0x88]
   23768:      	mov	x0, #0x38               ; =56
   2376c:      	str	x0, [x19, #0x90]
   23770:      	mov	x2, #0x3a               ; =58
   23774:      	str	x2, [x19, #0x98]
   23778:      	mov	x2, #0x5555555555555555 ; =6148914691236517205
   2377c:      	str	x2, [x19, #0xb0]
   23780:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   23784:      	str	x4, [x19, #0xb8]
   23788:      	str	x1, [x19, #0x188]
   2378c:      	mov	x0, x21
   23790:      	str	x0, [x19, #0x190]
   23794:      	str	x22, [x19, #0x17a0]
   23798:      	str	x23, [x19, #0x17a8]
   2379c:      	ldur	x25, [sp, #0xf0]
   237a0:      	uxtb	w8, w25
   237a4:      	str	x8, [x19, #0x17b8]
   237a8:      	str	x15, [x19, #0x1c70]
   237ac:      	str	x12, [x19, #0x1c78]
   237b0:      	str	x22, [x19, #0x1c80]
   237b4:      	str	x24, [x19, #0x1ca8]
   237b8:      	str	x28, [x19, #0x4c60]
   237bc:      	mov	w14, #0x2646            ; =9798
   237c0:      	movk	w14, #0x1, lsl #16
   237c4:      	sub	x14, x3, x14
   237c8:      	str	x14, [x19, #0x4c68]
   237cc:      	ldur	x4, [sp, #0x98]
   237d0:      	str	x4, [x19, #0x4c70]
   237d4:      	ldur	x0, [sp, #0x60]
   237d8:      	str	x0, [x19, #0x5a20]
   237dc:      	add	x2, x11, #0x1
   237e0:      	str	x2, [x19, #0x5bb0]
   237e4:      	ldur	x26, [sp, #0xa0]
   237e8:      	str	x26, [x19, #0x5bb8]
   237ec:      	ldur	x7, [sp, #0xa8]
   237f0:      	str	x7, [x19, #0x5bc0]
   237f4:      	ldur	x4, [sp, #0x90]
   237f8:      	sub	x3, x4, x14
   237fc:      	mov	w4, #0xc87e             ; =51326
   23800:      	movk	w4, #0x1, lsl #16
   23804:      	msub	x0, x2, x4, x3
   23808:      	str	x0, [x19, #0x5bc8]
   2380c:      	str	x1, [x19, #0x5bd0]
   23810:      	str	x1, [x19, #0x5bd8]
   23814:      	ldur	x8, [sp, #0xb0]
   23818:      	str	x8, [x19, #0x5be8]
   2381c:      	ldur	x4, [sp, #0xb8]
   23820:      	str	x4, [x19, #0x5bf0]
   23824:      	mov	x0, x21
   23828:      	str	x0, [x19, #0x5c00]
   2382c:      	ldur	x10, [sp, #0x50]
   23830:      	str	x10, [x19, #0x5c08]
   23834:      	str	x13, [x19, #0x5c18]
   23838:      	ldur	x13, [sp, #0xc0]
   2383c:      	str	x13, [x19, #0x5c20]
   23840:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   23844:      	mov	x0, #0x605              ; =1541
   23848:      	ldur	x6, [sp]
   2384c:      	str	x0, [x6, #0x48]
   23850:      	mov	x0, #0x0                ; =0
   23854:      	str	x0, [x19, #0x18]
   23858:      	str	x26, [x19, #0x20]
   2385c:      	mov	x1, #0x1                ; =1
   23860:      	str	x1, [x19, #0x30]
   23864:      	mov	x4, #0x101010101010101  ; =72340172838076673
   23868:      	str	x4, [x19, #0x38]
   2386c:      	mov	x20, #0x2               ; =2
   23870:      	str	x20, [x19, #0x40]
   23874:      	mov	x4, #0x3                ; =3
   23878:      	str	x4, [x19, #0x48]
   2387c:      	mov	x4, #0x4                ; =4
   23880:      	str	x4, [x19, #0x50]
   23884:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   23888:      	str	x4, [x19, #0x78]
   2388c:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   23890:      	str	x4, [x19, #0x88]
   23894:      	mov	x4, #0x38               ; =56
   23898:      	str	x4, [x19, #0x90]
   2389c:      	mov	x4, #0x3a               ; =58
   238a0:      	str	x4, [x19, #0x98]
   238a4:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   238a8:      	str	x4, [x19, #0xb0]
   238ac:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   238b0:      	str	x4, [x19, #0xb8]
   238b4:      	str	x0, [x19, #0x188]
   238b8:      	str	x1, [x19, #0x190]
   238bc:      	str	x22, [x19, #0x17a0]
   238c0:      	str	x23, [x19, #0x17a8]
   238c4:      	ldur	x25, [sp, #0xf0]
   238c8:      	uxtb	w4, w25
   238cc:      	str	x4, [x19, #0x17b8]
   238d0:      	str	x15, [x19, #0x1c70]
   238d4:      	str	x12, [x19, #0x1c78]
   238d8:      	str	x22, [x19, #0x1c80]
   238dc:      	str	x24, [x19, #0x1ca8]
   238e0:      	str	x2, [x19, #0x1cb8]
   238e4:      	str	x28, [x19, #0x4c60]
   238e8:      	mov	w2, #0x2646             ; =9798
   238ec:      	movk	w2, #0x1, lsl #16
   238f0:      	sub	x2, x3, x2
   238f4:      	str	x2, [x19, #0x4c68]
   238f8:      	ldur	x4, [sp, #0x98]
   238fc:      	str	x4, [x19, #0x4c70]
   23900:      	str	x22, [x19, #0x4f70]
   23904:      	str	x23, [x19, #0x4f78]
   23908:      	str	x15, [x19, #0x55d8]
   2390c:      	str	x12, [x19, #0x55e0]
   23910:      	str	x22, [x19, #0x55e8]
   23914:      	ldur	x24, [sp, #0x10]
   23918:      	str	x24, [x19, #0x55f0]
   2391c:      	ldur	x26, [sp, #0x68]
   23920:      	str	x26, [x19, #0x55f8]
   23924:      	ldur	x27, [sp, #0x70]
   23928:      	str	x27, [x19, #0x5600]
   2392c:      	ldur	x24, [sp, #0x78]
   23930:      	str	x24, [x19, #0x5608]
   23934:      	ldur	x26, [sp, #0x80]
   23938:      	str	x26, [x19, #0x5610]
   2393c:      	ldur	x14, [sp, #0x60]
   23940:      	str	x14, [x19, #0x5a20]
   23944:      	add	x8, x11, #0x1
   23948:      	str	x8, [x19, #0x5bb0]
   2394c:      	ldur	x26, [sp, #0xa0]
   23950:      	str	x26, [x19, #0x5bb8]
   23954:      	ldur	x7, [sp, #0xa8]
   23958:      	str	x7, [x19, #0x5bc0]
   2395c:      	ldur	x4, [sp, #0x90]
   23960:      	sub	x11, x4, x2
   23964:      	mov	w12, #0xc87e            ; =51326
   23968:      	movk	w12, #0x1, lsl #16
   2396c:      	msub	x11, x8, x12, x11
   23970:      	str	x11, [x19, #0x5bc8]
   23974:      	str	x0, [x19, #0x5bd0]
   23978:      	str	x0, [x19, #0x5bd8]
   2397c:      	ldur	x8, [sp, #0xb0]
   23980:      	str	x8, [x19, #0x5be8]
   23984:      	ldur	x4, [sp, #0xb8]
   23988:      	str	x4, [x19, #0x5bf0]
   2398c:      	str	x1, [x19, #0x5c00]
   23990:      	ldur	x10, [sp, #0x50]
   23994:      	str	x10, [x19, #0x5c08]
   23998:      	str	x13, [x19, #0x5c18]
   2399c:      	ldur	x13, [sp, #0xc0]
   239a0:      	str	x13, [x19, #0x5c20]
   239a4:      	ldr	x0, [x19, #0x4c60]
   239a8:      	cmp	x0, #0x0
   239ac:      	b.ne	0x20a1c <_mech_canonical_program_entry_v1_numeric_1282+0x2f1c>
   239b0:      	b	0x20c44 <_mech_canonical_program_entry_v1_numeric_1282+0x3144>
   239b4:      	mov	x21, x20
   239b8:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   239bc:      	mov	x21, x20
   239c0:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   239c4:      	mov	x0, #0x606              ; =1542
   239c8:      	ldur	x2, [sp]
   239cc:      	str	x0, [x2, #0x48]
   239d0:      	mov	x2, #0x0                ; =0
   239d4:      	str	x2, [x19, #0x18]
   239d8:      	str	x26, [x19, #0x20]
   239dc:      	mov	x0, #0x1                ; =1
   239e0:      	mov	x21, x0
   239e4:      	str	x0, [x19, #0x30]
   239e8:      	mov	x0, #0x101010101010101  ; =72340172838076673
   239ec:      	str	x0, [x19, #0x38]
   239f0:      	mov	x0, #0x2                ; =2
   239f4:      	str	x0, [x19, #0x40]
   239f8:      	mov	x0, #0x3                ; =3
   239fc:      	str	x0, [x19, #0x48]
   23a00:      	mov	x0, #0x4                ; =4
   23a04:      	str	x0, [x19, #0x50]
   23a08:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   23a0c:      	str	x0, [x19, #0x78]
   23a10:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   23a14:      	str	x0, [x19, #0x88]
   23a18:      	mov	x0, #0x38               ; =56
   23a1c:      	str	x0, [x19, #0x90]
   23a20:      	mov	x0, #0x3a               ; =58
   23a24:      	str	x0, [x19, #0x98]
   23a28:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   23a2c:      	str	x0, [x19, #0xb0]
   23a30:      	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
   23a34:      	str	x0, [x19, #0xb8]
   23a38:      	str	x2, [x19, #0x188]
   23a3c:      	mov	x0, x21
   23a40:      	str	x0, [x19, #0x190]
   23a44:      	str	x22, [x19, #0x17a0]
   23a48:      	str	x23, [x19, #0x17a8]
   23a4c:      	ldur	x25, [sp, #0xf0]
   23a50:      	uxtb	w0, w25
   23a54:      	str	x0, [x19, #0x17b8]
   23a58:      	str	x15, [x19, #0x1c70]
   23a5c:      	str	x12, [x19, #0x1c78]
   23a60:      	str	x22, [x19, #0x1c80]
   23a64:      	str	x24, [x19, #0x1ca8]
   23a68:      	str	x1, [x19, #0x1cc0]
   23a6c:      	str	x28, [x19, #0x4c60]
   23a70:      	mov	w1, #0x2646             ; =9798
   23a74:      	movk	w1, #0x1, lsl #16
   23a78:      	sub	x1, x3, x1
   23a7c:      	str	x1, [x19, #0x4c68]
   23a80:      	ldur	x4, [sp, #0x98]
   23a84:      	str	x4, [x19, #0x4c70]
   23a88:      	ldur	x14, [sp, #0x60]
   23a8c:      	str	x14, [x19, #0x5a20]
   23a90:      	add	x3, x11, #0x1
   23a94:      	str	x3, [x19, #0x5bb0]
   23a98:      	ldur	x26, [sp, #0xa0]
   23a9c:      	str	x26, [x19, #0x5bb8]
   23aa0:      	ldur	x7, [sp, #0xa8]
   23aa4:      	str	x7, [x19, #0x5bc0]
   23aa8:      	ldur	x4, [sp, #0x90]
   23aac:      	sub	x4, x4, x1
   23ab0:      	mov	w5, #0xc87e             ; =51326
   23ab4:      	movk	w5, #0x1, lsl #16
   23ab8:      	msub	x3, x3, x5, x4
   23abc:      	str	x3, [x19, #0x5bc8]
   23ac0:      	str	x2, [x19, #0x5bd0]
   23ac4:      	str	x2, [x19, #0x5bd8]
   23ac8:      	ldur	x8, [sp, #0xb0]
   23acc:      	str	x8, [x19, #0x5be8]
   23ad0:      	ldur	x4, [sp, #0xb8]
   23ad4:      	str	x4, [x19, #0x5bf0]
   23ad8:      	mov	x0, x21
   23adc:      	str	x0, [x19, #0x5c00]
   23ae0:      	ldur	x10, [sp, #0x50]
   23ae4:      	str	x10, [x19, #0x5c08]
   23ae8:      	str	x13, [x19, #0x5c18]
   23aec:      	ldur	x13, [sp, #0xc0]
   23af0:      	str	x13, [x19, #0x5c20]
   23af4:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   23af8:      	mov	x0, #0x607              ; =1543
   23afc:      	ldur	x2, [sp]
   23b00:      	str	x0, [x2, #0x48]
   23b04:      	mov	x0, #0x0                ; =0
   23b08:      	str	x0, [x19, #0x18]
   23b0c:      	str	x26, [x19, #0x20]
   23b10:      	mov	x2, #0x1                ; =1
   23b14:      	str	x2, [x19, #0x30]
   23b18:      	mov	x5, #0x101010101010101  ; =72340172838076673
   23b1c:      	str	x5, [x19, #0x38]
   23b20:      	mov	x20, #0x2               ; =2
   23b24:      	str	x20, [x19, #0x40]
   23b28:      	mov	x5, #0x3                ; =3
   23b2c:      	str	x5, [x19, #0x48]
   23b30:      	mov	x5, #0x4                ; =4
   23b34:      	str	x5, [x19, #0x50]
   23b38:      	mov	x5, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   23b3c:      	str	x5, [x19, #0x78]
   23b40:      	mov	x5, #0x3333333333333333 ; =3689348814741910323
   23b44:      	str	x5, [x19, #0x88]
   23b48:      	mov	x5, #0x38               ; =56
   23b4c:      	str	x5, [x19, #0x90]
   23b50:      	mov	x5, #0x3a               ; =58
   23b54:      	str	x5, [x19, #0x98]
   23b58:      	mov	x5, #0x5555555555555555 ; =6148914691236517205
   23b5c:      	str	x5, [x19, #0xb0]
   23b60:      	mov	x5, #0x3ffffffffffffff  ; =288230376151711743
   23b64:      	str	x5, [x19, #0xb8]
   23b68:      	str	x0, [x19, #0x188]
   23b6c:      	str	x2, [x19, #0x190]
   23b70:      	str	x22, [x19, #0x17a0]
   23b74:      	str	x23, [x19, #0x17a8]
   23b78:      	ldur	x25, [sp, #0xf0]
   23b7c:      	uxtb	w5, w25
   23b80:      	str	x5, [x19, #0x17b8]
   23b84:      	str	x15, [x19, #0x1c70]
   23b88:      	str	x12, [x19, #0x1c78]
   23b8c:      	str	x22, [x19, #0x1c80]
   23b90:      	str	x24, [x19, #0x1ca8]
   23b94:      	str	x1, [x19, #0x1cc0]
   23b98:      	str	x4, [x19, #0x1cc8]
   23b9c:      	str	x28, [x19, #0x4c60]
   23ba0:      	mov	w1, #0x2646             ; =9798
   23ba4:      	movk	w1, #0x1, lsl #16
   23ba8:      	sub	x1, x3, x1
   23bac:      	str	x1, [x19, #0x4c68]
   23bb0:      	ldur	x4, [sp, #0x98]
   23bb4:      	str	x4, [x19, #0x4c70]
   23bb8:      	str	x22, [x19, #0x4f70]
   23bbc:      	str	x23, [x19, #0x4f78]
   23bc0:      	str	x15, [x19, #0x55d8]
   23bc4:      	str	x12, [x19, #0x55e0]
   23bc8:      	str	x22, [x19, #0x55e8]
   23bcc:      	ldur	x24, [sp, #0x10]
   23bd0:      	str	x24, [x19, #0x55f0]
   23bd4:      	ldur	x26, [sp, #0x68]
   23bd8:      	str	x26, [x19, #0x55f8]
   23bdc:      	ldur	x27, [sp, #0x70]
   23be0:      	str	x27, [x19, #0x5600]
   23be4:      	ldur	x24, [sp, #0x78]
   23be8:      	str	x24, [x19, #0x5608]
   23bec:      	ldur	x26, [sp, #0x80]
   23bf0:      	str	x26, [x19, #0x5610]
   23bf4:      	ldur	x14, [sp, #0x60]
   23bf8:      	str	x14, [x19, #0x5a20]
   23bfc:      	add	x3, x11, #0x1
   23c00:      	str	x3, [x19, #0x5bb0]
   23c04:      	ldur	x26, [sp, #0xa0]
   23c08:      	str	x26, [x19, #0x5bb8]
   23c0c:      	ldur	x7, [sp, #0xa8]
   23c10:      	str	x7, [x19, #0x5bc0]
   23c14:      	ldur	x4, [sp, #0x90]
   23c18:      	sub	x1, x4, x1
   23c1c:      	mov	w4, #0xc87e             ; =51326
   23c20:      	movk	w4, #0x1, lsl #16
   23c24:      	msub	x1, x3, x4, x1
   23c28:      	str	x1, [x19, #0x5bc8]
   23c2c:      	str	x0, [x19, #0x5bd0]
   23c30:      	str	x0, [x19, #0x5bd8]
   23c34:      	ldur	x8, [sp, #0xb0]
   23c38:      	str	x8, [x19, #0x5be8]
   23c3c:      	ldur	x4, [sp, #0xb8]
   23c40:      	str	x4, [x19, #0x5bf0]
   23c44:      	str	x2, [x19, #0x5c00]
   23c48:      	ldur	x10, [sp, #0x50]
   23c4c:      	str	x10, [x19, #0x5c08]
   23c50:      	str	x13, [x19, #0x5c18]
   23c54:      	ldur	x13, [sp, #0xc0]
   23c58:      	str	x13, [x19, #0x5c20]
   23c5c:      	ldr	x3, [x19, #0x4c60]
   23c60:      	cmp	x3, #0x0
   23c64:      	b.ne	0x20cc0 <_mech_canonical_program_entry_v1_numeric_1282+0x31c0>
   23c68:      	b	0x20ecc <_mech_canonical_program_entry_v1_numeric_1282+0x33cc>
   23c6c:      	mov	x21, x20
   23c70:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   23c74:      	mov	x21, x20
   23c78:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   23c7c:      	mov	x0, #0x609              ; =1545
   23c80:      	ldur	x4, [sp]
   23c84:      	str	x0, [x4, #0x48]
   23c88:      	mov	x0, #0x0                ; =0
   23c8c:      	str	x0, [x19, #0x18]
   23c90:      	str	x26, [x19, #0x20]
   23c94:      	mov	x2, #0x1                ; =1
   23c98:      	str	x2, [x19, #0x30]
   23c9c:      	mov	x4, #0x101010101010101  ; =72340172838076673
   23ca0:      	str	x4, [x19, #0x38]
   23ca4:      	mov	x25, #0x2               ; =2
   23ca8:      	str	x25, [x19, #0x40]
   23cac:      	mov	x4, #0x3                ; =3
   23cb0:      	str	x4, [x19, #0x48]
   23cb4:      	mov	x4, #0x4                ; =4
   23cb8:      	str	x4, [x19, #0x50]
   23cbc:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   23cc0:      	str	x4, [x19, #0x78]
   23cc4:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   23cc8:      	str	x4, [x19, #0x88]
   23ccc:      	mov	x4, #0x38               ; =56
   23cd0:      	str	x4, [x19, #0x90]
   23cd4:      	mov	x4, #0x3a               ; =58
   23cd8:      	str	x4, [x19, #0x98]
   23cdc:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   23ce0:      	str	x4, [x19, #0xb0]
   23ce4:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   23ce8:      	str	x4, [x19, #0xb8]
   23cec:      	str	x0, [x19, #0x188]
   23cf0:      	str	x2, [x19, #0x190]
   23cf4:      	str	x22, [x19, #0x17a0]
   23cf8:      	str	x23, [x19, #0x17a8]
   23cfc:      	ldur	x4, [sp, #0xf0]
   23d00:      	uxtb	w4, w4
   23d04:      	str	x4, [x19, #0x17b8]
   23d08:      	str	x15, [x19, #0x1c70]
   23d0c:      	str	x12, [x19, #0x1c78]
   23d10:      	str	x22, [x19, #0x1c80]
   23d14:      	str	x24, [x19, #0x1ca8]
   23d18:      	str	x27, [x19, #0x1cd0]
   23d1c:      	add	x1, x1, #0x2
   23d20:      	str	x1, [x19, #0x1cd8]
   23d24:      	str	x28, [x19, #0x4c60]
   23d28:      	mov	w1, #0x2646             ; =9798
   23d2c:      	movk	w1, #0x1, lsl #16
   23d30:      	sub	x1, x3, x1
   23d34:      	str	x1, [x19, #0x4c68]
   23d38:      	ldur	x4, [sp, #0x98]
   23d3c:      	str	x4, [x19, #0x4c70]
   23d40:      	str	x22, [x19, #0x4f70]
   23d44:      	str	x23, [x19, #0x4f78]
   23d48:      	str	x15, [x19, #0x55d8]
   23d4c:      	str	x12, [x19, #0x55e0]
   23d50:      	str	x22, [x19, #0x55e8]
   23d54:      	ldur	x24, [sp, #0x10]
   23d58:      	str	x24, [x19, #0x55f0]
   23d5c:      	ldur	x26, [sp, #0x68]
   23d60:      	str	x26, [x19, #0x55f8]
   23d64:      	ldur	x27, [sp, #0x70]
   23d68:      	str	x27, [x19, #0x5600]
   23d6c:      	ldur	x24, [sp, #0x78]
   23d70:      	str	x24, [x19, #0x5608]
   23d74:      	ldur	x26, [sp, #0x80]
   23d78:      	str	x26, [x19, #0x5610]
   23d7c:      	ldur	x14, [sp, #0x60]
   23d80:      	str	x14, [x19, #0x5a20]
   23d84:      	add	x3, x11, #0x1
   23d88:      	str	x3, [x19, #0x5bb0]
   23d8c:      	ldur	x26, [sp, #0xa0]
   23d90:      	str	x26, [x19, #0x5bb8]
   23d94:      	ldur	x7, [sp, #0xa8]
   23d98:      	str	x7, [x19, #0x5bc0]
   23d9c:      	ldur	x4, [sp, #0x90]
   23da0:      	sub	x1, x4, x1
   23da4:      	mov	w4, #0xc87e             ; =51326
   23da8:      	movk	w4, #0x1, lsl #16
   23dac:      	msub	x1, x3, x4, x1
   23db0:      	str	x1, [x19, #0x5bc8]
   23db4:      	str	x0, [x19, #0x5bd0]
   23db8:      	str	x0, [x19, #0x5bd8]
   23dbc:      	ldur	x8, [sp, #0xb0]
   23dc0:      	str	x8, [x19, #0x5be8]
   23dc4:      	ldur	x4, [sp, #0xb8]
   23dc8:      	str	x4, [x19, #0x5bf0]
   23dcc:      	str	x2, [x19, #0x5c00]
   23dd0:      	ldur	x10, [sp, #0x50]
   23dd4:      	str	x10, [x19, #0x5c08]
   23dd8:      	str	x13, [x19, #0x5c18]
   23ddc:      	ldur	x13, [sp, #0xc0]
   23de0:      	str	x13, [x19, #0x5c20]
   23de4:      	ldr	x7, [x19, #0x4c60]
   23de8:      	cmp	x7, #0x0
   23dec:      	b.ne	0x20f3c <_mech_canonical_program_entry_v1_numeric_1282+0x343c>
   23df0:      	b	0x21150 <_mech_canonical_program_entry_v1_numeric_1282+0x3650>
   23df4:      	mov	x21, x25
   23df8:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   23dfc:      	mov	x21, x25
   23e00:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   23e04:      	mov	x21, x20
   23e08:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   23e0c:      	mov	x2, #0x621              ; =1569
   23e10:      	ldur	x5, [sp]
   23e14:      	str	x2, [x5, #0x48]
   23e18:      	mov	x5, #0x0                ; =0
   23e1c:      	str	x5, [x19, #0x18]
   23e20:      	str	x26, [x19, #0x20]
   23e24:      	mov	x2, #0x1                ; =1
   23e28:      	str	x2, [x19, #0x30]
   23e2c:      	mov	x6, #0x101010101010101  ; =72340172838076673
   23e30:      	str	x6, [x19, #0x38]
   23e34:      	mov	x20, #0x2               ; =2
   23e38:      	str	x20, [x19, #0x40]
   23e3c:      	mov	x6, #0x3                ; =3
   23e40:      	str	x6, [x19, #0x48]
   23e44:      	mov	x6, #0x4                ; =4
   23e48:      	str	x6, [x19, #0x50]
   23e4c:      	mov	x6, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   23e50:      	str	x6, [x19, #0x78]
   23e54:      	mov	x6, #0x3333333333333333 ; =3689348814741910323
   23e58:      	str	x6, [x19, #0x88]
   23e5c:      	mov	x6, #0x38               ; =56
   23e60:      	str	x6, [x19, #0x90]
   23e64:      	mov	x6, #0x3a               ; =58
   23e68:      	str	x6, [x19, #0x98]
   23e6c:      	mov	x6, #0x5555555555555555 ; =6148914691236517205
   23e70:      	str	x6, [x19, #0xb0]
   23e74:      	mov	x6, #0x3ffffffffffffff  ; =288230376151711743
   23e78:      	str	x6, [x19, #0xb8]
   23e7c:      	str	x5, [x19, #0x188]
   23e80:      	str	x2, [x19, #0x190]
   23e84:      	str	x22, [x19, #0x17a0]
   23e88:      	str	x23, [x19, #0x17a8]
   23e8c:      	ldur	x25, [sp, #0xf0]
   23e90:      	uxtb	w6, w25
   23e94:      	str	x6, [x19, #0x17b8]
   23e98:      	str	x15, [x19, #0x1c70]
   23e9c:      	str	x12, [x19, #0x1c78]
   23ea0:      	str	x22, [x19, #0x1c80]
   23ea4:      	str	x24, [x19, #0x1ca8]
   23ea8:      	str	x27, [x19, #0x1d38]
   23eac:      	str	x13, [x19, #0x1d40]
   23eb0:      	str	x22, [x19, #0x1d48]
   23eb4:      	uxtb	w4, w4
   23eb8:      	str	x4, [x19, #0x1d58]
   23ebc:      	add	x4, x27, #0x1
   23ec0:      	str	x4, [x19, #0x1d68]
   23ec4:      	str	x28, [x19, #0x4c60]
   23ec8:      	mov	w4, #0xcb86             ; =52102
   23ecc:      	movk	w4, #0x2, lsl #16
   23ed0:      	sub	x3, x3, x4
   23ed4:      	str	x3, [x19, #0x4c68]
   23ed8:      	ldur	x4, [sp, #0x98]
   23edc:      	str	x4, [x19, #0x4c70]
   23ee0:      	str	x22, [x19, #0x4f70]
   23ee4:      	str	x23, [x19, #0x4f78]
   23ee8:      	str	x15, [x19, #0x55d8]
   23eec:      	str	x12, [x19, #0x55e0]
   23ef0:      	str	x22, [x19, #0x55e8]
   23ef4:      	ldur	x24, [sp, #0x10]
   23ef8:      	str	x24, [x19, #0x55f0]
   23efc:      	ldur	x26, [sp, #0x68]
   23f00:      	str	x26, [x19, #0x55f8]
   23f04:      	ldur	x4, [sp, #0x70]
   23f08:      	str	x4, [x19, #0x5600]
   23f0c:      	ldur	x24, [sp, #0x78]
   23f10:      	str	x24, [x19, #0x5608]
   23f14:      	ldur	x26, [sp, #0x80]
   23f18:      	str	x26, [x19, #0x5610]
   23f1c:      	str	x27, [x19, #0x57a0]
   23f20:      	str	x13, [x19, #0x57a8]
   23f24:      	str	x22, [x19, #0x57b0]
   23f28:      	str	x1, [x19, #0x57b8]
   23f2c:      	str	x14, [x19, #0x57c0]
   23f30:      	str	x10, [x19, #0x57c8]
   23f34:      	str	x9, [x19, #0x57d0]
   23f38:      	str	x0, [x19, #0x57d8]
   23f3c:      	ldur	x14, [sp, #0x60]
   23f40:      	str	x14, [x19, #0x5a20]
   23f44:      	add	x0, x11, #0x1
   23f48:      	str	x0, [x19, #0x5bb0]
   23f4c:      	ldur	x26, [sp, #0xa0]
   23f50:      	str	x26, [x19, #0x5bb8]
   23f54:      	ldur	x7, [sp, #0xa8]
   23f58:      	str	x7, [x19, #0x5bc0]
   23f5c:      	ldur	x4, [sp, #0x90]
   23f60:      	sub	x1, x4, x3
   23f64:      	mov	w3, #0xc87e             ; =51326
   23f68:      	movk	w3, #0x1, lsl #16
   23f6c:      	msub	x0, x0, x3, x1
   23f70:      	str	x0, [x19, #0x5bc8]
   23f74:      	str	x5, [x19, #0x5bd0]
   23f78:      	str	x5, [x19, #0x5bd8]
   23f7c:      	ldur	x8, [sp, #0xb0]
   23f80:      	str	x8, [x19, #0x5be8]
   23f84:      	ldur	x4, [sp, #0xb8]
   23f88:      	str	x4, [x19, #0x5bf0]
   23f8c:      	str	x2, [x19, #0x5c00]
   23f90:      	ldur	x10, [sp, #0x50]
   23f94:      	str	x10, [x19, #0x5c08]
   23f98:      	str	x2, [x19, #0x5c18]
   23f9c:      	ldur	x5, [sp, #0x58]
   23fa0:      	str	x5, [x19, #0x5c20]
   23fa4:      	ldr	x0, [x19, #0x4c60]
   23fa8:      	cmp	x0, #0x0
   23fac:      	b.ne	0x21630 <_mech_canonical_program_entry_v1_numeric_1282+0x3b30>
   23fb0:      	b	0x2184c <_mech_canonical_program_entry_v1_numeric_1282+0x3d4c>
   23fb4:      	mov	x21, x20
   23fb8:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   23fbc:      	mov	x21, x20
   23fc0:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   23fc4:      	mov	x0, #0x6c4              ; =1732
   23fc8:      	ldur	x28, [sp]
   23fcc:      	str	x0, [x28, #0x48]
   23fd0:      	mov	x0, #0x0                ; =0
   23fd4:      	str	x0, [x19, #0x4c60]
   23fd8:      	mov	x0, #0x3                ; =3
   23fdc:      	mov	x21, x0
   23fe0:      	ldr	x0, [sp, #0x190]
   23fe4:      	cmp	x0, #0x19c
   23fe8:      	b.hs	0x21a80 <_mech_canonical_program_entry_v1_numeric_1282+0x3f80>
   23fec:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   23ff0:      	mov	x0, #0x6c8              ; =1736
   23ff4:      	ldur	x28, [sp]
   23ff8:      	str	x0, [x28, #0x48]
   23ffc:      	mov	x0, #0x0                ; =0
   24000:      	str	x0, [x19, #0x4c60]
   24004:      	mov	x0, #0x3                ; =3
   24008:      	mov	x21, x0
   2400c:      	ldr	x0, [sp, #0x190]
   24010:      	cmp	x0, #0x19c
   24014:      	b.hs	0x21c48 <_mech_canonical_program_entry_v1_numeric_1282+0x4148>
   24018:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   2401c:      	mov	x0, #0x6cc              ; =1740
   24020:      	ldur	x28, [sp]
   24024:      	str	x0, [x28, #0x48]
   24028:      	mov	x0, #0x0                ; =0
   2402c:      	str	x0, [x19, #0x4c60]
   24030:      	mov	x0, #0x3                ; =3
   24034:      	ldr	x7, [sp, #0x190]
   24038:      	mov	x21, x0
   2403c:      	cmp	x7, #0x19c
   24040:      	b.hs	0x21df8 <_mech_canonical_program_entry_v1_numeric_1282+0x42f8>
   24044:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   24048:      	mov	x14, #0x6d0             ; =1744
   2404c:      	ldur	x28, [sp]
   24050:      	str	x14, [x28, #0x48]
   24054:      	mov	x14, #0x0               ; =0
   24058:      	str	x14, [x19, #0x4c60]
   2405c:      	mov	x0, #0x3                ; =3
   24060:      	mov	x21, x0
   24064:      	ldr	x0, [sp, #0x190]
   24068:      	cmp	x0, #0x19c
   2406c:      	b.hs	0x21fac <_mech_canonical_program_entry_v1_numeric_1282+0x44ac>
   24070:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   24074:      	mov	x0, #0x6d4              ; =1748
   24078:      	ldur	x28, [sp]
   2407c:      	str	x0, [x28, #0x48]
   24080:      	mov	x0, #0x0                ; =0
   24084:      	str	x0, [x19, #0x4c60]
   24088:      	mov	x0, #0x3                ; =3
   2408c:      	mov	x21, x0
   24090:      	ldr	x0, [sp, #0x190]
   24094:      	cmp	x0, #0x19c
   24098:      	b.hs	0x22160 <_mech_canonical_program_entry_v1_numeric_1282+0x4660>
   2409c:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   240a0:      	mov	x5, #0x6dd              ; =1757
   240a4:      	ldur	x0, [sp]
   240a8:      	str	x5, [x0, #0x48]
   240ac:      	mov	x7, #0x0                ; =0
   240b0:      	str	x7, [x19, #0x18]
   240b4:      	mov	x8, #0x1000000000000000 ; =1152921504606846976
   240b8:      	str	x8, [x19, #0x20]
   240bc:      	mov	x0, #0x1                ; =1
   240c0:      	mov	x21, x0
   240c4:      	str	x0, [x19, #0x30]
   240c8:      	mov	x14, #0x101010101010101 ; =72340172838076673
   240cc:      	str	x14, [x19, #0x38]
   240d0:      	mov	x14, #0x2               ; =2
   240d4:      	str	x14, [x19, #0x40]
   240d8:      	mov	x14, #0x3               ; =3
   240dc:      	str	x14, [x19, #0x48]
   240e0:      	mov	x14, #0x4               ; =4
   240e4:      	str	x14, [x19, #0x50]
   240e8:      	mov	x14, #0xf0f0f0f0f0f0f0f ; =1085102592571150095
   240ec:      	str	x14, [x19, #0x78]
   240f0:      	mov	x14, #0x3333333333333333 ; =3689348814741910323
   240f4:      	str	x14, [x19, #0x88]
   240f8:      	mov	x0, #0x38               ; =56
   240fc:      	str	x0, [x19, #0x90]
   24100:      	mov	x0, #0x3a               ; =58
   24104:      	str	x0, [x19, #0x98]
   24108:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   2410c:      	str	x0, [x19, #0xb0]
   24110:      	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
   24114:      	str	x0, [x19, #0xb8]
   24118:      	str	x7, [x19, #0x188]
   2411c:      	mov	x0, x21
   24120:      	str	x0, [x19, #0x190]
   24124:      	str	x10, [x19, #0x17a0]
   24128:      	str	x23, [x19, #0x17a8]
   2412c:      	str	x28, [x19, #0x4c60]
   24130:      	str	x3, [x19, #0x4c68]
   24134:      	ldur	x4, [sp, #0x98]
   24138:      	str	x4, [x19, #0x4c70]
   2413c:      	ldur	x14, [sp, #0x60]
   24140:      	str	x14, [x19, #0x5a20]
   24144:      	str	x11, [x19, #0x5bb0]
   24148:      	ldur	x26, [sp, #0xa0]
   2414c:      	str	x26, [x19, #0x5bb8]
   24150:      	ldur	x7, [sp, #0xa8]
   24154:      	str	x7, [x19, #0x5bc0]
   24158:      	ldur	x4, [sp, #0x90]
   2415c:      	sub	x1, x4, x3
   24160:      	mov	w0, #0xc87e             ; =51326
   24164:      	movk	w0, #0x1, lsl #16
   24168:      	msub	x0, x11, x0, x1
   2416c:      	str	x0, [x19, #0x5bc8]
   24170:      	str	x24, [x19, #0x5bd0]
   24174:      	str	x15, [x19, #0x5bd8]
   24178:      	ldur	x8, [sp, #0xb0]
   2417c:      	str	x8, [x19, #0x5be8]
   24180:      	ldur	x4, [sp, #0xb8]
   24184:      	str	x4, [x19, #0x5bf0]
   24188:      	str	x12, [x19, #0x5c00]
   2418c:      	str	x9, [x19, #0x5c08]
   24190:      	str	x13, [x19, #0x5c18]
   24194:      	ldur	x13, [sp, #0xc0]
   24198:      	str	x13, [x19, #0x5c20]
   2419c:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   241a0:      	mov	x0, #0x6b0              ; =1712
   241a4:      	ldur	x1, [sp]
   241a8:      	str	x0, [x1, #0x48]
   241ac:      	mov	x1, #0x0                ; =0
   241b0:      	str	x1, [x19, #0x18]
   241b4:      	str	x26, [x19, #0x20]
   241b8:      	mov	x0, #0x1                ; =1
   241bc:      	mov	x21, x0
   241c0:      	str	x0, [x19, #0x30]
   241c4:      	mov	x0, #0x101010101010101  ; =72340172838076673
   241c8:      	str	x0, [x19, #0x38]
   241cc:      	mov	x0, #0x2                ; =2
   241d0:      	str	x0, [x19, #0x40]
   241d4:      	mov	x0, #0x3                ; =3
   241d8:      	str	x0, [x19, #0x48]
   241dc:      	mov	x0, #0x4                ; =4
   241e0:      	str	x0, [x19, #0x50]
   241e4:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   241e8:      	str	x0, [x19, #0x78]
   241ec:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   241f0:      	str	x0, [x19, #0x88]
   241f4:      	mov	x0, #0x38               ; =56
   241f8:      	str	x0, [x19, #0x90]
   241fc:      	mov	x0, #0x3a               ; =58
   24200:      	str	x0, [x19, #0x98]
   24204:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   24208:      	str	x0, [x19, #0xb0]
   2420c:      	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
   24210:      	str	x0, [x19, #0xb8]
   24214:      	str	x1, [x19, #0x188]
   24218:      	mov	x0, x21
   2421c:      	str	x0, [x19, #0x190]
   24220:      	str	x22, [x19, #0x17a0]
   24224:      	str	x23, [x19, #0x17a8]
   24228:      	ldur	x25, [sp, #0xf0]
   2422c:      	uxtb	w2, w25
   24230:      	str	x2, [x19, #0x17b8]
   24234:      	str	x15, [x19, #0x1c70]
   24238:      	str	x12, [x19, #0x1c78]
   2423c:      	str	x22, [x19, #0x1c80]
   24240:      	str	x28, [x19, #0x4c60]
   24244:      	str	x3, [x19, #0x4c68]
   24248:      	ldur	x4, [sp, #0x98]
   2424c:      	str	x4, [x19, #0x4c70]
   24250:      	ldur	x14, [sp, #0x60]
   24254:      	str	x14, [x19, #0x5a20]
   24258:      	add	x10, x11, #0x1
   2425c:      	str	x10, [x19, #0x5bb0]
   24260:      	ldur	x26, [sp, #0xa0]
   24264:      	str	x26, [x19, #0x5bb8]
   24268:      	ldur	x7, [sp, #0xa8]
   2426c:      	str	x7, [x19, #0x5bc0]
   24270:      	ldur	x4, [sp, #0x90]
   24274:      	sub	x14, x4, x3
   24278:      	mov	w15, #0xc87e            ; =51326
   2427c:      	movk	w15, #0x1, lsl #16
   24280:      	msub	x14, x10, x15, x14
   24284:      	str	x14, [x19, #0x5bc8]
   24288:      	str	x1, [x19, #0x5bd0]
   2428c:      	str	x1, [x19, #0x5bd8]
   24290:      	ldur	x8, [sp, #0xb0]
   24294:      	str	x8, [x19, #0x5be8]
   24298:      	ldur	x4, [sp, #0xb8]
   2429c:      	str	x4, [x19, #0x5bf0]
   242a0:      	str	x0, [x19, #0x5c00]
   242a4:      	ldur	x10, [sp, #0x50]
   242a8:      	str	x10, [x19, #0x5c08]
   242ac:      	str	x13, [x19, #0x5c18]
   242b0:      	ldur	x13, [sp, #0xc0]
   242b4:      	str	x13, [x19, #0x5c20]
   242b8:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   242bc:      	mov	x0, #0x6a0              ; =1696
   242c0:      	ldur	x1, [sp]
   242c4:      	str	x0, [x1, #0x48]
   242c8:      	mov	x1, #0x0                ; =0
   242cc:      	str	x1, [x19, #0x18]
   242d0:      	str	x26, [x19, #0x20]
   242d4:      	mov	x0, #0x1                ; =1
   242d8:      	mov	x21, x0
   242dc:      	str	x0, [x19, #0x30]
   242e0:      	mov	x0, #0x101010101010101  ; =72340172838076673
   242e4:      	str	x0, [x19, #0x38]
   242e8:      	mov	x0, #0x2                ; =2
   242ec:      	str	x0, [x19, #0x40]
   242f0:      	mov	x0, #0x3                ; =3
   242f4:      	str	x0, [x19, #0x48]
   242f8:      	mov	x0, #0x4                ; =4
   242fc:      	str	x0, [x19, #0x50]
   24300:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   24304:      	str	x0, [x19, #0x78]
   24308:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   2430c:      	str	x0, [x19, #0x88]
   24310:      	mov	x0, #0x38               ; =56
   24314:      	str	x0, [x19, #0x90]
   24318:      	mov	x0, #0x3a               ; =58
   2431c:      	str	x0, [x19, #0x98]
   24320:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   24324:      	str	x0, [x19, #0xb0]
   24328:      	ldur	x6, [sp, #0xd0]
   2432c:      	str	x6, [x19, #0xb8]
   24330:      	str	x1, [x19, #0x188]
   24334:      	mov	x0, x21
   24338:      	str	x0, [x19, #0x190]
   2433c:      	str	x22, [x19, #0x17a0]
   24340:      	str	x23, [x19, #0x17a8]
   24344:      	ldur	x25, [sp, #0xf0]
   24348:      	uxtb	w0, w25
   2434c:      	str	x0, [x19, #0x17b8]
   24350:      	str	x15, [x19, #0x1c70]
   24354:      	str	x12, [x19, #0x1c78]
   24358:      	str	x22, [x19, #0x1c80]
   2435c:      	str	x24, [x19, #0x1ca8]
   24360:      	str	x27, [x19, #0x1d38]
   24364:      	str	x13, [x19, #0x1d40]
   24368:      	str	x22, [x19, #0x1d48]
   2436c:      	str	x28, [x19, #0x4c60]
   24370:      	mov	w0, #0xcb86             ; =52102
   24374:      	movk	w0, #0x2, lsl #16
   24378:      	sub	x2, x3, x0
   2437c:      	str	x2, [x19, #0x4c68]
   24380:      	ldur	x4, [sp, #0x98]
   24384:      	str	x4, [x19, #0x4c70]
   24388:      	ldur	x14, [sp, #0x60]
   2438c:      	str	x14, [x19, #0x5a20]
   24390:      	add	x3, x11, #0x1
   24394:      	str	x3, [x19, #0x5bb0]
   24398:      	ldur	x26, [sp, #0xa0]
   2439c:      	str	x26, [x19, #0x5bb8]
   243a0:      	ldur	x7, [sp, #0xa8]
   243a4:      	str	x7, [x19, #0x5bc0]
   243a8:      	ldur	x4, [sp, #0x90]
   243ac:      	sub	x2, x4, x2
   243b0:      	mov	w0, #0xc87e             ; =51326
   243b4:      	movk	w0, #0x1, lsl #16
   243b8:      	msub	x0, x3, x0, x2
   243bc:      	str	x0, [x19, #0x5bc8]
   243c0:      	str	x1, [x19, #0x5bd0]
   243c4:      	str	x1, [x19, #0x5bd8]
   243c8:      	ldur	x8, [sp, #0xb0]
   243cc:      	str	x8, [x19, #0x5be8]
   243d0:      	ldur	x4, [sp, #0xb8]
   243d4:      	str	x4, [x19, #0x5bf0]
   243d8:      	mov	x0, x21
   243dc:      	str	x0, [x19, #0x5c00]
   243e0:      	ldur	x10, [sp, #0x50]
   243e4:      	str	x10, [x19, #0x5c08]
   243e8:      	str	x0, [x19, #0x5c18]
   243ec:      	ldur	x5, [sp, #0x58]
   243f0:      	str	x5, [x19, #0x5c20]
   243f4:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   243f8:      	mov	x0, #0x5df              ; =1503
   243fc:      	ldur	x1, [sp]
   24400:      	str	x0, [x1, #0x48]
   24404:      	mov	x1, #0x0                ; =0
   24408:      	str	x1, [x19, #0x18]
   2440c:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   24410:      	str	x0, [x19, #0x20]
   24414:      	mov	x0, #0x1                ; =1
   24418:      	mov	x21, x0
   2441c:      	str	x0, [x19, #0x30]
   24420:      	mov	x0, #0x101010101010101  ; =72340172838076673
   24424:      	str	x0, [x19, #0x38]
   24428:      	mov	x0, #0x2                ; =2
   2442c:      	str	x0, [x19, #0x40]
   24430:      	mov	x0, #0x3                ; =3
   24434:      	str	x0, [x19, #0x48]
   24438:      	mov	x0, #0x4                ; =4
   2443c:      	str	x0, [x19, #0x50]
   24440:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   24444:      	str	x0, [x19, #0x78]
   24448:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   2444c:      	str	x0, [x19, #0x88]
   24450:      	mov	x0, #0x38               ; =56
   24454:      	str	x0, [x19, #0x90]
   24458:      	mov	x0, #0x3a               ; =58
   2445c:      	str	x0, [x19, #0x98]
   24460:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   24464:      	str	x0, [x19, #0xb0]
   24468:      	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
   2446c:      	str	x0, [x19, #0xb8]
   24470:      	str	x1, [x19, #0x188]
   24474:      	mov	x0, x21
   24478:      	str	x0, [x19, #0x190]
   2447c:      	str	x22, [x19, #0x17a0]
   24480:      	str	x23, [x19, #0x17a8]
   24484:      	ldur	x25, [sp, #0xf0]
   24488:      	uxtb	w0, w25
   2448c:      	str	x0, [x19, #0x17b8]
   24490:      	str	x4, [x19, #0x1858]
   24494:      	mov	x15, x26
   24498:      	str	x15, [x19, #0x1860]
   2449c:      	str	x22, [x19, #0x1868]
   244a0:      	ldur	x15, [sp, #0xe0]
   244a4:      	str	x15, [x19, #0x1870]
   244a8:      	str	x28, [x19, #0x4c60]
   244ac:      	str	x3, [x19, #0x4c68]
   244b0:      	ldur	x4, [sp, #0x98]
   244b4:      	str	x4, [x19, #0x4c70]
   244b8:      	ldur	x14, [sp, #0x60]
   244bc:      	str	x14, [x19, #0x5a20]
   244c0:      	add	x1, x11, #0x1
   244c4:      	str	x1, [x19, #0x5bb0]
   244c8:      	ldur	x26, [sp, #0xa0]
   244cc:      	str	x26, [x19, #0x5bb8]
   244d0:      	ldur	x7, [sp, #0xa8]
   244d4:      	str	x7, [x19, #0x5bc0]
   244d8:      	ldur	x4, [sp, #0x90]
   244dc:      	sub	x2, x4, x3
   244e0:      	mov	w0, #0xc87e             ; =51326
   244e4:      	movk	w0, #0x1, lsl #16
   244e8:      	msub	x0, x1, x0, x2
   244ec:      	str	x0, [x19, #0x5bc8]
   244f0:      	mov	x0, x21
   244f4:      	str	x0, [x19, #0x5bd0]
   244f8:      	ldur	x14, [sp, #0x20]
   244fc:      	str	x14, [x19, #0x5bd8]
   24500:      	ldur	x8, [sp, #0xb0]
   24504:      	str	x8, [x19, #0x5be8]
   24508:      	ldur	x4, [sp, #0xb8]
   2450c:      	str	x4, [x19, #0x5bf0]
   24510:      	str	x12, [x19, #0x5c00]
   24514:      	str	x9, [x19, #0x5c08]
   24518:      	str	x13, [x19, #0x5c18]
   2451c:      	ldur	x13, [sp, #0xc0]
   24520:      	str	x13, [x19, #0x5c20]
   24524:      	b	0x24678 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   24528:      	mov	x1, #0x5cf              ; =1487
   2452c:      	ldur	x5, [sp]
   24530:      	str	x1, [x5, #0x48]
   24534:      	mov	x2, #0x0                ; =0
   24538:      	str	x2, [x19, #0x18]
   2453c:      	mov	x4, #0x1000000000000000 ; =1152921504606846976
   24540:      	str	x4, [x19, #0x20]
   24544:      	mov	x0, #0x1                ; =1
   24548:      	mov	x21, x0
   2454c:      	str	x0, [x19, #0x30]
   24550:      	mov	x5, #0x101010101010101  ; =72340172838076673
   24554:      	str	x5, [x19, #0x38]
   24558:      	mov	x8, #0x2                ; =2
   2455c:      	str	x8, [x19, #0x40]
   24560:      	mov	x8, #0x3                ; =3
   24564:      	str	x8, [x19, #0x48]
   24568:      	mov	x8, #0x4                ; =4
   2456c:      	str	x8, [x19, #0x50]
   24570:      	mov	x10, #0xf0f0f0f0f0f0f0f ; =1085102592571150095
   24574:      	str	x10, [x19, #0x78]
   24578:      	mov	x10, #0x3333333333333333 ; =3689348814741910323
   2457c:      	str	x10, [x19, #0x88]
   24580:      	mov	x15, #0x38              ; =56
   24584:      	str	x15, [x19, #0x90]
   24588:      	mov	x15, #0x3a              ; =58
   2458c:      	str	x15, [x19, #0x98]
   24590:      	mov	x15, #0x5555555555555555 ; =6148914691236517205
   24594:      	str	x15, [x19, #0xb0]
   24598:      	mov	x15, #0x3ffffffffffffff ; =288230376151711743
   2459c:      	str	x15, [x19, #0xb8]
   245a0:      	str	x2, [x19, #0x188]
   245a4:      	str	x0, [x19, #0x190]
   245a8:      	str	x22, [x19, #0x17a0]
   245ac:      	str	x23, [x19, #0x17a8]
   245b0:      	ldur	x25, [sp, #0xf0]
   245b4:      	uxtb	w0, w25
   245b8:      	str	x0, [x19, #0x17b8]
   245bc:      	ldur	x27, [sp, #0x18]
   245c0:      	str	x27, [x19, #0x1858]
   245c4:      	mov	x15, x26
   245c8:      	str	x15, [x19, #0x1860]
   245cc:      	str	x22, [x19, #0x1868]
   245d0:      	ldur	x15, [sp, #0xe0]
   245d4:      	str	x15, [x19, #0x1870]
   245d8:      	ldur	x15, [sp, #0xd8]
   245dc:      	uxtb	w0, w15
   245e0:      	str	x0, [x19, #0x1880]
   245e4:      	str	x14, [x19, #0x1918]
   245e8:      	str	x7, [x19, #0x1920]
   245ec:      	str	x22, [x19, #0x1928]
   245f0:      	ldur	x15, [sp, #0xe0]
   245f4:      	str	x15, [x19, #0x1930]
   245f8:      	str	x28, [x19, #0x4c60]
   245fc:      	mov	w0, #0xdc1e             ; =56350
   24600:      	movk	w0, #0x2, lsl #16
   24604:      	sub	x1, x6, x0
   24608:      	str	x1, [x19, #0x4c68]
   2460c:      	ldur	x4, [sp, #0x98]
   24610:      	str	x4, [x19, #0x4c70]
   24614:      	ldur	x14, [sp, #0x60]
   24618:      	str	x14, [x19, #0x5a20]
   2461c:      	add	x2, x11, #0x1
   24620:      	str	x2, [x19, #0x5bb0]
   24624:      	ldur	x26, [sp, #0xa0]
   24628:      	str	x26, [x19, #0x5bb8]
   2462c:      	ldur	x7, [sp, #0xa8]
   24630:      	str	x7, [x19, #0x5bc0]
   24634:      	ldur	x4, [sp, #0x90]
   24638:      	sub	x1, x4, x1
   2463c:      	mov	w0, #0xc87e             ; =51326
   24640:      	movk	w0, #0x1, lsl #16
   24644:      	msub	x0, x2, x0, x1
   24648:      	str	x0, [x19, #0x5bc8]
   2464c:      	mov	x0, x21
   24650:      	str	x0, [x19, #0x5bd0]
   24654:      	ldur	x14, [sp, #0x20]
   24658:      	str	x14, [x19, #0x5bd8]
   2465c:      	str	x0, [x19, #0x5be8]
   24660:      	str	x3, [x19, #0x5bf0]
   24664:      	str	x12, [x19, #0x5c00]
   24668:      	str	x9, [x19, #0x5c08]
   2466c:      	str	x13, [x19, #0x5c18]
   24670:      	ldur	x13, [sp, #0xc0]
   24674:      	str	x13, [x19, #0x5c20]
   24678:      	mov	x1, #0x0                ; =0
   2467c:      	mov	x0, x21
   24680:      	add	sp, sp, #0x1c0
   24684:      	ldp	x19, x20, [sp], #0x10
   24688:      	ldp	x21, x22, [sp], #0x10
   2468c:      	ldp	x23, x24, [sp], #0x10
   24690:      	ldp	x25, x26, [sp], #0x10
   24694:      	ldp	x27, x28, [sp], #0x10
   24698:      	ldp	x29, x30, [sp], #0x10
   2469c:      	retab
		...
