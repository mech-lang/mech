
/private/tmp/mech-related-conjoined-window-integration-runners-20261107-v1/reuse-4/build/object.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000000001db80 <_mech_canonical_program_entry_v1_numeric_1282>:
   1db80:      	pacibsp
   1db84:      	stp	x29, x30, [sp, #-0x10]!
   1db88:      	mov	x29, sp
   1db8c:      	stp	x27, x28, [sp, #-0x10]!
   1db90:      	stp	x25, x26, [sp, #-0x10]!
   1db94:      	stp	x23, x24, [sp, #-0x10]!
   1db98:      	stp	x21, x22, [sp, #-0x10]!
   1db9c:      	stp	x19, x20, [sp, #-0x10]!
   1dba0:      	sub	sp, sp, #0x1b0
   1dba4:      	stur	x2, [sp, #0x8]
   1dba8:      	ldr	x21, [x0, #0x50]
   1dbac:      	str	x21, [sp, #0x198]
   1dbb0:      	ldr	x6, [x0, #0x58]
   1dbb4:      	ldr	x2, [x0, #0x60]
   1dbb8:      	ldr	x14, [x0, #0x68]
   1dbbc:      	stur	x0, [sp]
   1dbc0:      	str	x14, [sp, #0x180]
   1dbc4:      	mov	x0, #0x3                ; =3
   1dbc8:      	cmp	x21, #0x0
   1dbcc:      	b.eq	0x22920 <_mech_canonical_program_entry_v1_numeric_1282+0x4da0>
   1dbd0:      	mov	x0, #0x3                ; =3
   1dbd4:      	cmp	x6, #0x0
   1dbd8:      	str	x6, [sp, #0x190]
   1dbdc:      	b.eq	0x22928 <_mech_canonical_program_entry_v1_numeric_1282+0x4da8>
   1dbe0:      	mov	x0, #0x3                ; =3
   1dbe4:      	stur	x0, [sp, #0xb8]
   1dbe8:      	cmp	x2, #0x0
   1dbec:      	b.eq	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   1dbf0:      	ldr	x0, [x1, #0x4c60]
   1dbf4:      	cmp	x0, #0x0
   1dbf8:      	mov	x26, x0
   1dbfc:      	b.eq	0x1e45c <_mech_canonical_program_entry_v1_numeric_1282+0x8dc>
   1dc00:      	ldr	x28, [x2, #0x10]
   1dc04:      	ldr	x0, [x1, #0x17a0]
   1dc08:      	ldr	x0, [x1, #0x17a8]
   1dc0c:      	ldr	x0, [x1, #0x17b8]
   1dc10:      	ldr	x0, [x1, #0x17d0]
   1dc14:      	ldr	x0, [x1, #0x17d8]
   1dc18:      	ldr	x0, [x1, #0x17e0]
   1dc1c:      	ldr	x0, [x1, #0x17e8]
   1dc20:      	ldr	x0, [x1, #0x17f0]
   1dc24:      	ldr	x0, [x1, #0x17f8]
   1dc28:      	ldr	x0, [x1, #0x1808]
   1dc2c:      	ldr	x0, [x1, #0x1810]
   1dc30:      	ldr	x0, [x1, #0x1818]
   1dc34:      	ldr	x0, [x1, #0x1820]
   1dc38:      	ldr	x0, [x1, #0x1858]
   1dc3c:      	ldr	x0, [x1, #0x1860]
   1dc40:      	ldr	x0, [x1, #0x1868]
   1dc44:      	ldr	x0, [x1, #0x1870]
   1dc48:      	ldr	x0, [x1, #0x1880]
   1dc4c:      	ldr	x0, [x1, #0x1890]
   1dc50:      	ldr	x0, [x1, #0x1898]
   1dc54:      	ldr	x0, [x1, #0x18a0]
   1dc58:      	ldr	x0, [x1, #0x18a8]
   1dc5c:      	ldr	x0, [x1, #0x18b0]
   1dc60:      	ldr	x0, [x1, #0x18b8]
   1dc64:      	ldr	x0, [x1, #0x18c8]
   1dc68:      	ldr	x0, [x1, #0x18d0]
   1dc6c:      	ldr	x0, [x1, #0x18d8]
   1dc70:      	ldr	x0, [x1, #0x18e0]
   1dc74:      	ldr	x0, [x1, #0x1918]
   1dc78:      	ldr	x0, [x1, #0x1920]
   1dc7c:      	ldr	x0, [x1, #0x1928]
   1dc80:      	ldr	x0, [x1, #0x1930]
   1dc84:      	ldr	x0, [x1, #0x1940]
   1dc88:      	ldr	x0, [x1, #0x1950]
   1dc8c:      	ldr	x0, [x1, #0x1958]
   1dc90:      	ldr	x0, [x1, #0x1960]
   1dc94:      	ldr	x0, [x1, #0x1970]
   1dc98:      	ldr	x0, [x1, #0x1978]
   1dc9c:      	ldr	x0, [x1, #0x1980]
   1dca0:      	ldr	x0, [x1, #0x1988]
   1dca4:      	ldr	x0, [x1, #0x1990]
   1dca8:      	ldr	x0, [x1, #0x1998]
   1dcac:      	ldr	x0, [x1, #0x19a0]
   1dcb0:      	ldr	x0, [x1, #0x19a8]
   1dcb4:      	ldr	x0, [x1, #0x19b0]
   1dcb8:      	ldr	x0, [x1, #0x19b8]
   1dcbc:      	ldr	x0, [x1, #0x19c0]
   1dcc0:      	ldr	x0, [x1, #0x19c8]
   1dcc4:      	ldr	x0, [x1, #0x19d0]
   1dcc8:      	ldr	x0, [x1, #0x19d8]
   1dccc:      	ldr	x0, [x1, #0x19e0]
   1dcd0:      	ldr	x0, [x1, #0x19e8]
   1dcd4:      	ldr	x0, [x1, #0x19f0]
   1dcd8:      	ldr	x0, [x1, #0x19f8]
   1dcdc:      	ldr	x0, [x1, #0x1a00]
   1dce0:      	ldr	x0, [x1, #0x1a08]
   1dce4:      	ldr	x0, [x1, #0x1a10]
   1dce8:      	ldr	x0, [x1, #0x1a18]
   1dcec:      	ldr	x0, [x1, #0x1a20]
   1dcf0:      	ldr	x0, [x1, #0x1a28]
   1dcf4:      	ldr	x0, [x1, #0x1a30]
   1dcf8:      	ldr	x0, [x1, #0x1a38]
   1dcfc:      	ldr	x0, [x1, #0x1a40]
   1dd00:      	ldr	x0, [x1, #0x1a48]
   1dd04:      	ldr	x0, [x1, #0x1a50]
   1dd08:      	ldr	x0, [x1, #0x1a58]
   1dd0c:      	ldr	x0, [x1, #0x1a60]
   1dd10:      	ldr	x0, [x1, #0x1a68]
   1dd14:      	ldr	x0, [x1, #0x1a78]
   1dd18:      	ldr	x0, [x1, #0x1a80]
   1dd1c:      	ldr	x0, [x1, #0x1a90]
   1dd20:      	ldr	x0, [x1, #0x1aa0]
   1dd24:      	ldr	x0, [x1, #0x1ab0]
   1dd28:      	ldr	x0, [x1, #0x1ab8]
   1dd2c:      	ldr	x0, [x1, #0x1ac0]
   1dd30:      	ldr	x0, [x1, #0x1ad0]
   1dd34:      	ldr	x0, [x1, #0x1ad8]
   1dd38:      	ldr	x0, [x1, #0x1ae8]
   1dd3c:      	ldr	x0, [x1, #0x1af0]
   1dd40:      	ldr	x0, [x1, #0x1b00]
   1dd44:      	ldr	x0, [x1, #0x1b08]
   1dd48:      	ldr	x0, [x1, #0x1b10]
   1dd4c:      	ldr	x0, [x1, #0x1b20]
   1dd50:      	ldr	x0, [x1, #0x1b28]
   1dd54:      	ldr	x0, [x1, #0x1b38]
   1dd58:      	ldr	x0, [x1, #0x1b40]
   1dd5c:      	ldr	x0, [x1, #0x1b50]
   1dd60:      	ldr	x0, [x1, #0x1b58]
   1dd64:      	ldr	x0, [x1, #0x1b60]
   1dd68:      	ldr	x0, [x1, #0x1b70]
   1dd6c:      	ldr	x0, [x1, #0x1b78]
   1dd70:      	ldr	x0, [x1, #0x1b88]
   1dd74:      	ldr	x0, [x1, #0x1b90]
   1dd78:      	ldr	x0, [x1, #0x1ba0]
   1dd7c:      	ldr	x0, [x1, #0x1ba8]
   1dd80:      	ldr	x0, [x1, #0x1bb0]
   1dd84:      	ldr	x0, [x1, #0x1bb8]
   1dd88:      	ldr	x0, [x1, #0x1bc0]
   1dd8c:      	ldr	x0, [x1, #0x1bd8]
   1dd90:      	ldr	x0, [x1, #0x1bf0]
   1dd94:      	ldr	x0, [x1, #0x1c00]
   1dd98:      	ldr	x0, [x1, #0x1c08]
   1dd9c:      	ldr	x0, [x1, #0x1c10]
   1dda0:      	ldr	x0, [x1, #0x1c18]
   1dda4:      	ldr	x0, [x1, #0x1c28]
   1dda8:      	ldr	x0, [x1, #0x1c30]
   1ddac:      	ldr	x0, [x1, #0x1c38]
   1ddb0:      	ldr	x0, [x1, #0x1c70]
   1ddb4:      	ldr	x0, [x1, #0x1c78]
   1ddb8:      	ldr	x0, [x1, #0x1c80]
   1ddbc:      	ldr	x0, [x1, #0x1c90]
   1ddc0:      	ldr	x0, [x1, #0x1c98]
   1ddc4:      	ldr	x0, [x1, #0x1ca0]
   1ddc8:      	ldr	x0, [x1, #0x1ca8]
   1ddcc:      	ldr	x0, [x1, #0x1cb8]
   1ddd0:      	ldr	x0, [x1, #0x1cc0]
   1ddd4:      	ldr	x0, [x1, #0x1cc8]
   1ddd8:      	ldr	x0, [x1, #0x1cd0]
   1dddc:      	ldr	x0, [x1, #0x1cd8]
   1dde0:      	ldr	x0, [x1, #0x1ce0]
   1dde4:      	ldr	x0, [x1, #0x1cf0]
   1dde8:      	ldr	x0, [x1, #0x1cf8]
   1ddec:      	ldr	x0, [x1, #0x1d00]
   1ddf0:      	ldr	x0, [x1, #0x1d38]
   1ddf4:      	ldr	x0, [x1, #0x1d40]
   1ddf8:      	ldr	x0, [x1, #0x1d48]
   1ddfc:      	ldr	x0, [x1, #0x1d58]
   1de00:      	ldr	x0, [x1, #0x1d60]
   1de04:      	ldr	x0, [x1, #0x1d68]
   1de08:      	ldr	x0, [x1, #0x1d70]
   1de0c:      	ldr	x0, [x1, #0x1d78]
   1de10:      	ldr	x0, [x1, #0x1d80]
   1de14:      	ldr	x0, [x1, #0x1d88]
   1de18:      	ldr	x0, [x1, #0x1d90]
   1de1c:      	ldr	x0, [x1, #0x1d98]
   1de20:      	ldr	x0, [x1, #0x1da0]
   1de24:      	ldr	x0, [x1, #0x1db0]
   1de28:      	ldr	x0, [x1, #0x1dc0]
   1de2c:      	ldr	x0, [x1, #0x1dc8]
   1de30:      	ldr	x0, [x1, #0x1dd0]
   1de34:      	ldr	x0, [x1, #0x1dd8]
   1de38:      	ldr	x0, [x1, #0x1de0]
   1de3c:      	ldr	x0, [x1, #0x1de8]
   1de40:      	ldr	x0, [x1, #0x1df0]
   1de44:      	ldr	x0, [x1, #0x1df8]
   1de48:      	ldr	x0, [x1, #0x1e00]
   1de4c:      	ldr	x0, [x1, #0x1e08]
   1de50:      	ldr	x0, [x1, #0x1e10]
   1de54:      	ldr	x0, [x1, #0x1e18]
   1de58:      	ldr	x0, [x1, #0x1e20]
   1de5c:      	ldr	x0, [x1, #0x1e28]
   1de60:      	ldr	x0, [x1, #0x1e30]
   1de64:      	ldr	x0, [x1, #0x1e38]
   1de68:      	ldr	x0, [x1, #0x1e48]
   1de6c:      	ldr	x0, [x1, #0x1e50]
   1de70:      	ldr	x0, [x1, #0x1e60]
   1de74:      	ldr	x0, [x1, #0x1e70]
   1de78:      	ldr	x0, [x1, #0x1e80]
   1de7c:      	ldr	x0, [x1, #0x1e88]
   1de80:      	ldr	x0, [x1, #0x1e90]
   1de84:      	ldr	x0, [x1, #0x1ea0]
   1de88:      	ldr	x0, [x1, #0x1ea8]
   1de8c:      	ldr	x0, [x1, #0x1eb8]
   1de90:      	ldr	x0, [x1, #0x1ec0]
   1de94:      	ldr	x0, [x1, #0x1ed0]
   1de98:      	ldr	x0, [x1, #0x1ed8]
   1de9c:      	ldr	x0, [x1, #0x1ee0]
   1dea0:      	ldr	x0, [x1, #0x1ef0]
   1dea4:      	ldr	x0, [x1, #0x1ef8]
   1dea8:      	ldr	x0, [x1, #0x1f08]
   1deac:      	ldr	x0, [x1, #0x1f10]
   1deb0:      	ldr	x0, [x1, #0x1f20]
   1deb4:      	ldr	x0, [x1, #0x1f28]
   1deb8:      	ldr	x0, [x1, #0x1f30]
   1debc:      	ldr	x0, [x1, #0x1f40]
   1dec0:      	ldr	x0, [x1, #0x1f48]
   1dec4:      	ldr	x0, [x1, #0x1f58]
   1dec8:      	ldr	x0, [x1, #0x1f60]
   1decc:      	ldr	x0, [x1, #0x1f70]
   1ded0:      	ldr	x0, [x1, #0x1f78]
   1ded4:      	ldr	x0, [x1, #0x1f80]
   1ded8:      	ldr	x0, [x1, #0x1f88]
   1dedc:      	ldr	x0, [x1, #0x1f90]
   1dee0:      	ldr	x0, [x1, #0x1fa8]
   1dee4:      	ldr	x0, [x1, #0x1fc0]
   1dee8:      	ldr	x0, [x1, #0x1fe0]
   1deec:      	ldr	x0, [x1, #0x1fe8]
   1def0:      	ldr	x0, [x1, #0x1ff0]
   1def4:      	ldr	x0, [x1, #0x2000]
   1def8:      	ldr	x0, [x1, #0x2008]
   1defc:      	ldr	x0, [x1, #0x2010]
   1df00:      	ldr	x0, [x1, #0x2020]
   1df04:      	ldr	x0, [x1, #0x2028]
   1df08:      	ldr	x0, [x1, #0x2030]
   1df0c:      	ldr	x0, [x1, #0x2040]
   1df10:      	ldr	x0, [x1, #0x2048]
   1df14:      	ldr	x0, [x1, #0x2050]
   1df18:      	ldr	x0, [x1, #0x2060]
   1df1c:      	ldr	x0, [x1, #0x2068]
   1df20:      	ldr	x0, [x1, #0x2070]
   1df24:      	ldr	x0, [x1, #0x2088]
   1df28:      	ldr	x0, [x1, #0x4638]
   1df2c:      	ldr	x0, [x1, #0x4640]
   1df30:      	ldr	x0, [x1, #0x4648]
   1df34:      	ldr	x0, [x1, #0x4650]
   1df38:      	ldr	x0, [x1, #0x4658]
   1df3c:      	ldr	x0, [x1, #0x4660]
   1df40:      	ldr	x0, [x1, #0x4668]
   1df44:      	ldr	x0, [x1, #0x4670]
   1df48:      	ldr	x0, [x1, #0x4678]
   1df4c:      	ldr	x0, [x1, #0x4680]
   1df50:      	ldr	x0, [x1, #0x4688]
   1df54:      	ldr	x0, [x1, #0x4690]
   1df58:      	ldr	x0, [x1, #0x4698]
   1df5c:      	ldr	x0, [x1, #0x46a0]
   1df60:      	ldr	x0, [x1, #0x46a8]
   1df64:      	ldr	x0, [x1, #0x46b0]
   1df68:      	ldr	x0, [x1, #0x46b8]
   1df6c:      	ldr	x0, [x1, #0x46c0]
   1df70:      	ldr	x0, [x1, #0x46c8]
   1df74:      	ldr	x0, [x1, #0x46d0]
   1df78:      	ldr	x0, [x1, #0x46d8]
   1df7c:      	ldr	x0, [x1, #0x46e0]
   1df80:      	ldr	x0, [x1, #0x46e8]
   1df84:      	ldr	x0, [x1, #0x46f0]
   1df88:      	ldr	x0, [x1, #0x46f8]
   1df8c:      	ldr	x0, [x1, #0x4700]
   1df90:      	ldr	x0, [x1, #0x4708]
   1df94:      	ldr	x0, [x1, #0x4710]
   1df98:      	ldr	x0, [x1, #0x4718]
   1df9c:      	ldr	x0, [x1, #0x4720]
   1dfa0:      	ldr	x0, [x1, #0x4728]
   1dfa4:      	ldr	x0, [x1, #0x4730]
   1dfa8:      	ldr	x0, [x1, #0x4738]
   1dfac:      	ldr	x0, [x1, #0x4740]
   1dfb0:      	ldr	x0, [x1, #0x4748]
   1dfb4:      	ldr	x0, [x1, #0x4750]
   1dfb8:      	ldr	x0, [x1, #0x4758]
   1dfbc:      	ldr	x0, [x1, #0x4760]
   1dfc0:      	ldr	x0, [x1, #0x4768]
   1dfc4:      	ldr	x0, [x1, #0x4770]
   1dfc8:      	ldr	x0, [x1, #0x4778]
   1dfcc:      	ldr	x0, [x1, #0x4780]
   1dfd0:      	ldr	x0, [x1, #0x4788]
   1dfd4:      	ldr	x0, [x1, #0x4790]
   1dfd8:      	ldr	x0, [x1, #0x4798]
   1dfdc:      	ldr	x0, [x1, #0x47a0]
   1dfe0:      	ldr	x0, [x1, #0x47a8]
   1dfe4:      	ldr	x0, [x1, #0x47b0]
   1dfe8:      	ldr	x3, [x1, #0x4c68]
   1dfec:      	ldr	x4, [x1, #0x4c70]
   1dff0:      	mov	x6, x1
   1dff4:      	stur	x4, [sp, #0x80]
   1dff8:      	ldr	x22, [x28, #0xf60]
   1dffc:      	ldr	x23, [x28, #0xf70]
   1e000:      	ldr	x21, [x2, #0xab8]
   1e004:      	ldr	x24, [x2, #0xac0]
   1e008:      	stur	x24, [sp, #0x50]
   1e00c:      	ldr	x0, [x2, #0xac8]
   1e010:      	ldr	x0, [x2, #0xad0]
   1e014:      	ldr	x0, [x2, #0xad8]
   1e018:      	str	x0, [sp, #0x178]
   1e01c:      	ldr	x0, [x2, #0xae0]
   1e020:      	str	x0, [sp, #0x170]
   1e024:      	ldr	x0, [x2, #0xae8]
   1e028:      	ldr	x0, [x2, #0xaf0]
   1e02c:      	ldr	x0, [x2, #0xaf8]
   1e030:      	str	x0, [sp, #0x168]
   1e034:      	ldr	x0, [x2, #0xb00]
   1e038:      	str	x0, [sp, #0x160]
   1e03c:      	ldr	x0, [x2, #0xb08]
   1e040:      	ldr	x0, [x2, #0xb10]
   1e044:      	ldr	x0, [x2, #0xb18]
   1e048:      	str	x0, [sp, #0x158]
   1e04c:      	ldr	x0, [x2, #0xb20]
   1e050:      	str	x0, [sp, #0x150]
   1e054:      	ldr	x0, [x2, #0xb28]
   1e058:      	ldr	x0, [x2, #0xb30]
   1e05c:      	ldr	x0, [x2, #0xb38]
   1e060:      	str	x0, [sp, #0x148]
   1e064:      	ldr	x0, [x2, #0xb40]
   1e068:      	str	x0, [sp, #0x140]
   1e06c:      	ldr	x0, [x2, #0xb48]
   1e070:      	ldr	x0, [x2, #0xb50]
   1e074:      	ldr	x0, [x2, #0xb58]
   1e078:      	str	x0, [sp, #0x138]
   1e07c:      	ldr	x0, [x2, #0xb60]
   1e080:      	str	x0, [sp, #0x130]
   1e084:      	ldr	x0, [x2, #0xb68]
   1e088:      	ldr	x0, [x2, #0xb70]
   1e08c:      	ldr	x0, [x2, #0xb78]
   1e090:      	str	x0, [sp, #0x128]
   1e094:      	ldr	x0, [x2, #0xb80]
   1e098:      	str	x0, [sp, #0x120]
   1e09c:      	ldr	x0, [x2, #0xb88]
   1e0a0:      	ldr	x0, [x2, #0xb90]
   1e0a4:      	ldr	x0, [x2, #0xb98]
   1e0a8:      	str	x0, [sp, #0x118]
   1e0ac:      	ldr	x0, [x2, #0xba0]
   1e0b0:      	str	x0, [sp, #0x110]
   1e0b4:      	ldr	x0, [x2, #0xba8]
   1e0b8:      	ldr	x0, [x2, #0xbb0]
   1e0bc:      	ldr	x0, [x2, #0xbb8]
   1e0c0:      	str	x0, [sp, #0x108]
   1e0c4:      	ldr	x0, [x2, #0xbc0]
   1e0c8:      	str	x0, [sp, #0x100]
   1e0cc:      	ldr	x0, [x2, #0xbc8]
   1e0d0:      	ldr	x0, [x2, #0xbd0]
   1e0d4:      	ldr	x0, [x2, #0xbd8]
   1e0d8:      	stur	x0, [sp, #0xf8]
   1e0dc:      	ldr	x20, [x2, #0xbe0]
   1e0e0:      	stur	x20, [sp, #0xf0]
   1e0e4:      	ldr	x0, [x2, #0xbe8]
   1e0e8:      	ldr	x0, [x2, #0xbf0]
   1e0ec:      	ldr	x1, [x2, #0xc48]
   1e0f0:      	stur	x1, [sp, #0xb0]
   1e0f4:      	str	x2, [sp, #0x188]
   1e0f8:      	mov	x8, #0x0                ; =0
   1e0fc:      	mov	x4, #0x1                ; =1
   1e100:      	stur	x4, [sp, #0x88]
   1e104:      	mov	x5, x8
   1e108:      	mov	x9, x8
   1e10c:      	mov	x11, x8
   1e110:      	mov	x12, x8
   1e114:      	mov	x13, x8
   1e118:      	mov	x14, x8
   1e11c:      	mov	x15, x8
   1e120:      	mov	x25, x8
   1e124:      	stur	x3, [sp, #0x78]
   1e128:      	stur	x8, [sp, #0xa0]
   1e12c:      	stur	x8, [sp, #0xa8]
   1e130:      	mov	w0, #0xc87e             ; =51326
   1e134:      	movk	w0, #0x1, lsl #16
   1e138:      	cmp	x3, x0
   1e13c:      	cset	x1, hs
   1e140:      	ldur	x0, [sp, #0x50]
   1e144:      	ldur	x10, [sp, #0xb0]
   1e148:      	cmp	x0, x10
   1e14c:      	cset	x0, ls
   1e150:      	ldur	x2, [sp, #0xb0]
   1e154:      	ldur	x4, [sp, #0x50]
   1e158:      	sub	x2, x2, x4
   1e15c:      	cmp	x2, #0x4
   1e160:      	cset	x2, hi
   1e164:      	and	w7, w0, w2
   1e168:      	and	w1, w1, w7
   1e16c:      	stur	x7, [sp, #0xe8]
   1e170:      	uxtb	w1, w1
   1e174:      	cbnz	x1, 0x1e484 <_mech_canonical_program_entry_v1_numeric_1282+0x904>
   1e178:      	mov	x2, #0x0                ; =0
   1e17c:      	mov	x19, x6
   1e180:      	str	x2, [x19, #0x18]
   1e184:      	mov	x4, #0x1000000000000000 ; =1152921504606846976
   1e188:      	str	x4, [x19, #0x20]
   1e18c:      	mov	x4, #0x1                ; =1
   1e190:      	str	x4, [x19, #0x30]
   1e194:      	mov	x6, #0x101010101010101  ; =72340172838076673
   1e198:      	str	x6, [x19, #0x38]
   1e19c:      	mov	x6, #0x2                ; =2
   1e1a0:      	str	x6, [x19, #0x40]
   1e1a4:      	mov	x7, #0x3                ; =3
   1e1a8:      	str	x7, [x19, #0x48]
   1e1ac:      	mov	x10, #0x4               ; =4
   1e1b0:      	str	x10, [x19, #0x50]
   1e1b4:      	mov	x10, #0xf0f0f0f0f0f0f0f ; =1085102592571150095
   1e1b8:      	str	x10, [x19, #0x78]
   1e1bc:      	mov	x10, #0x3333333333333333 ; =3689348814741910323
   1e1c0:      	str	x10, [x19, #0x88]
   1e1c4:      	mov	x14, #0x38              ; =56
   1e1c8:      	str	x14, [x19, #0x90]
   1e1cc:      	mov	x14, #0x3a              ; =58
   1e1d0:      	str	x14, [x19, #0x98]
   1e1d4:      	mov	x14, #0x5555555555555555 ; =6148914691236517205
   1e1d8:      	str	x14, [x19, #0xb0]
   1e1dc:      	mov	x14, #0x3ffffffffffffff ; =288230376151711743
   1e1e0:      	str	x14, [x19, #0xb8]
   1e1e4:      	str	x2, [x19, #0x188]
   1e1e8:      	str	x4, [x19, #0x190]
   1e1ec:      	mov	x10, x26
   1e1f0:      	str	x10, [x19, #0x4c60]
   1e1f4:      	str	x3, [x19, #0x4c68]
   1e1f8:      	ldur	x4, [sp, #0x80]
   1e1fc:      	str	x4, [x19, #0x4c70]
   1e200:      	str	x22, [x19, #0x4f70]
   1e204:      	str	x23, [x19, #0x4f78]
   1e208:      	ldur	x1, [sp, #0x50]
   1e20c:      	str	x1, [x19, #0x5a20]
   1e210:      	str	x8, [x19, #0x5bb0]
   1e214:      	ldur	x0, [sp, #0x88]
   1e218:      	str	x0, [x19, #0x5bb8]
   1e21c:      	str	x5, [x19, #0x5bc0]
   1e220:      	ldur	x4, [sp, #0x78]
   1e224:      	sub	x0, x4, x3
   1e228:      	mov	w1, #0xc87e             ; =51326
   1e22c:      	movk	w1, #0x1, lsl #16
   1e230:      	msub	x0, x8, x1, x0
   1e234:      	str	x0, [x19, #0x5bc8]
   1e238:      	str	x25, [x19, #0x5bd0]
   1e23c:      	str	x15, [x19, #0x5bd8]
   1e240:      	str	x9, [x19, #0x5be8]
   1e244:      	ldur	x4, [sp, #0xa0]
   1e248:      	str	x4, [x19, #0x5bf0]
   1e24c:      	str	x12, [x19, #0x5c00]
   1e250:      	str	x11, [x19, #0x5c08]
   1e254:      	str	x13, [x19, #0x5c18]
   1e258:      	ldur	x13, [sp, #0xa8]
   1e25c:      	str	x13, [x19, #0x5c20]
   1e260:      	ldr	x0, [x19, #0x4c60]
   1e264:      	cmp	x0, #0x0
   1e268:      	b.eq	0x1e45c <_mech_canonical_program_entry_v1_numeric_1282+0x8dc>
   1e26c:      	ldr	x3, [x19, #0x4c68]
   1e270:      	ldr	x4, [x19, #0x4c70]
   1e274:      	mov	x0, #0x0                ; =0
   1e278:      	str	x0, [x19, #0x4c60]
   1e27c:      	mov	x0, #0x3                ; =3
   1e280:      	ldr	x2, [sp, #0x180]
   1e284:      	cmp	x2, #0x19a
   1e288:      	b.lo	0x22930 <_mech_canonical_program_entry_v1_numeric_1282+0x4db0>
   1e28c:      	ldr	x0, [x19, #0x4f70]
   1e290:      	ldr	x1, [sp, #0x188]
   1e294:      	str	x0, [x1, #0x10]
   1e298:      	ldr	x2, [x19, #0x4f78]
   1e29c:      	str	x2, [x1, #0x18]
   1e2a0:      	ldr	x5, [x19, #0x5a20]
   1e2a4:      	str	x5, [x1, #0xac0]
   1e2a8:      	str	x0, [x1, #0x10]
   1e2ac:      	str	x2, [x1, #0x18]
   1e2b0:      	ldr	x0, [x19, #0x50c0]
   1e2b4:      	str	x0, [x1, #0x160]
   1e2b8:      	ldr	x0, [x19, #0x50c8]
   1e2bc:      	str	x0, [x1, #0x168]
   1e2c0:      	ldr	x0, [x19, #0x50d0]
   1e2c4:      	str	x0, [x1, #0x170]
   1e2c8:      	ldr	x0, [x19, #0x50d8]
   1e2cc:      	str	x0, [x1, #0x178]
   1e2d0:      	ldr	x0, [x19, #0x50e0]
   1e2d4:      	str	x0, [x1, #0x180]
   1e2d8:      	ldr	x0, [x19, #0x50e8]
   1e2dc:      	str	x0, [x1, #0x188]
   1e2e0:      	ldr	x0, [x19, #0x50f0]
   1e2e4:      	str	x0, [x1, #0x190]
   1e2e8:      	ldr	x0, [x19, #0x50f8]
   1e2ec:      	str	x0, [x1, #0x198]
   1e2f0:      	ldr	x0, [x19, #0x5100]
   1e2f4:      	str	x0, [x1, #0x1a0]
   1e2f8:      	ldr	x0, [x19, #0x52a8]
   1e2fc:      	str	x0, [x1, #0x348]
   1e300:      	ldr	x0, [x19, #0x52b0]
   1e304:      	str	x0, [x1, #0x350]
   1e308:      	ldr	x0, [x19, #0x52b8]
   1e30c:      	str	x0, [x1, #0x358]
   1e310:      	ldr	x0, [x19, #0x52c0]
   1e314:      	str	x0, [x1, #0x360]
   1e318:      	ldr	x0, [x19, #0x52c8]
   1e31c:      	str	x0, [x1, #0x368]
   1e320:      	ldr	x0, [x19, #0x52d0]
   1e324:      	str	x0, [x1, #0x370]
   1e328:      	ldr	x0, [x19, #0x52d8]
   1e32c:      	str	x0, [x1, #0x378]
   1e330:      	ldr	x0, [x19, #0x52e0]
   1e334:      	str	x0, [x1, #0x380]
   1e338:      	ldr	x2, [x19, #0x52e8]
   1e33c:      	str	x2, [x1, #0x388]
   1e340:      	ldr	x2, [x19, #0x55d8]
   1e344:      	str	x2, [x1, #0x678]
   1e348:      	ldr	x5, [x19, #0x55e0]
   1e34c:      	str	x5, [x1, #0x680]
   1e350:      	ldr	x5, [x19, #0x55e8]
   1e354:      	str	x5, [x1, #0x688]
   1e358:      	ldr	x5, [x19, #0x55f0]
   1e35c:      	str	x5, [x1, #0x690]
   1e360:      	ldr	x6, [x19, #0x55f8]
   1e364:      	str	x6, [x1, #0x698]
   1e368:      	ldr	x7, [x19, #0x5600]
   1e36c:      	str	x7, [x1, #0x6a0]
   1e370:      	ldr	x8, [x19, #0x5608]
   1e374:      	str	x8, [x1, #0x6a8]
   1e378:      	ldr	x9, [x19, #0x5610]
   1e37c:      	str	x9, [x1, #0x6b0]
   1e380:      	ldr	x10, [x19, #0x57a0]
   1e384:      	str	x10, [x1, #0x840]
   1e388:      	ldr	x11, [x19, #0x57a8]
   1e38c:      	str	x11, [x1, #0x848]
   1e390:      	ldr	x12, [x19, #0x57b0]
   1e394:      	str	x12, [x1, #0x850]
   1e398:      	ldr	x13, [x19, #0x57b8]
   1e39c:      	str	x13, [x1, #0x858]
   1e3a0:      	ldr	x14, [x19, #0x57c0]
   1e3a4:      	str	x14, [x1, #0x860]
   1e3a8:      	ldr	x15, [x19, #0x57c8]
   1e3ac:      	str	x15, [x1, #0x868]
   1e3b0:      	ldr	x0, [x19, #0x57d0]
   1e3b4:      	str	x0, [x1, #0x870]
   1e3b8:      	ldr	x0, [x19, #0x57d8]
   1e3bc:      	str	x0, [x1, #0x878]
   1e3c0:      	ldr	x0, [x19, #0x5bb0]
   1e3c4:      	str	x0, [x1, #0xc50]
   1e3c8:      	ldr	x0, [x19, #0x5bb8]
   1e3cc:      	str	x0, [x1, #0xc58]
   1e3d0:      	ldr	x0, [x19, #0x5bc0]
   1e3d4:      	str	x0, [x1, #0xc60]
   1e3d8:      	ldr	x0, [x19, #0x5bc8]
   1e3dc:      	str	x0, [x1, #0xc68]
   1e3e0:      	ldr	x0, [x19, #0x5bd0]
   1e3e4:      	str	x0, [x1, #0xc70]
   1e3e8:      	ldr	x0, [x19, #0x5bd8]
   1e3ec:      	str	x0, [x1, #0xc78]
   1e3f0:      	mov	x0, #0x0                ; =0
   1e3f4:      	str	x0, [x1, #0xc80]
   1e3f8:      	ldr	x2, [x19, #0x5be8]
   1e3fc:      	str	x2, [x1, #0xc88]
   1e400:      	ldr	x2, [x19, #0x5bf0]
   1e404:      	str	x2, [x1, #0xc90]
   1e408:      	str	x0, [x1, #0xc98]
   1e40c:      	ldr	x2, [x19, #0x5c00]
   1e410:      	str	x2, [x1, #0xca0]
   1e414:      	ldr	x2, [x19, #0x5c08]
   1e418:      	str	x2, [x1, #0xca8]
   1e41c:      	str	x0, [x1, #0xcb0]
   1e420:      	ldr	x0, [x19, #0x5c18]
   1e424:      	str	x0, [x1, #0xcb8]
   1e428:      	ldr	x0, [x19, #0x5c20]
   1e42c:      	str	x0, [x1, #0xcc0]
   1e430:      	mov	x1, #0x502              ; =1282
   1e434:      	mov	x2, #-0x9               ; =-9
   1e438:      	mov	x5, #0x1                ; =1
   1e43c:      	ldur	x0, [sp, #0x8]
   1e440:      	ldr	x6, [sp, #0x190]
   1e444:      	ldr	x21, [sp, #0x198]
   1e448:      	blr	x21
   1e44c:      	mov	x8, x0
   1e450:      	mov	x0, #0x2                ; =2
   1e454:      	cmp	x8, #0x0
   1e458:      	b.ne	0x22938 <_mech_canonical_program_entry_v1_numeric_1282+0x4db8>
   1e45c:      	mov	x1, #0x0                ; =0
   1e460:      	mov	x0, x1
   1e464:      	add	sp, sp, #0x1b0
   1e468:      	ldp	x19, x20, [sp], #0x10
   1e46c:      	ldp	x21, x22, [sp], #0x10
   1e470:      	ldp	x23, x24, [sp], #0x10
   1e474:      	ldp	x25, x26, [sp], #0x10
   1e478:      	ldp	x27, x28, [sp], #0x10
   1e47c:      	ldp	x29, x30, [sp], #0x10
   1e480:      	retab
   1e484:      	ldr	x1, [sp, #0x188]
   1e488:      	ldr	x2, [sp, #0x180]
   1e48c:      	ldur	x4, [sp, #0x80]
   1e490:      	mov	x10, x26
   1e494:      	mov	x19, x6
   1e498:      	stur	x5, [sp, #0x90]
   1e49c:      	cmp	x22, x23
   1e4a0:      	cset	x0, lo
   1e4a4:      	cmp	x22, x23
   1e4a8:      	b.lo	0x1e4f0 <_mech_canonical_program_entry_v1_numeric_1282+0x970>
   1e4ac:      	mov	x7, #0x0                ; =0
   1e4b0:      	stur	x7, [sp, #0x10]
   1e4b4:      	mov	w0, #0xc87e             ; =51326
   1e4b8:      	movk	w0, #0x1, lsl #16
   1e4bc:      	sub	x3, x3, x0
   1e4c0:      	mov	x24, x22
   1e4c4:      	mov	x27, x22
   1e4c8:      	ldur	x0, [sp, #0x10]
   1e4cc:      	stur	x0, [sp, #0x58]
   1e4d0:      	stur	x0, [sp, #0x60]
   1e4d4:      	stur	x0, [sp, #0x68]
   1e4d8:      	stur	x0, [sp, #0x70]
   1e4dc:      	stur	x4, [sp, #0x80]
   1e4e0:      	stur	x9, [sp, #0x98]
   1e4e4:      	str	x2, [sp, #0x180]
   1e4e8:      	str	x1, [sp, #0x188]
   1e4ec:      	b	0x21e80 <_mech_canonical_program_entry_v1_numeric_1282+0x4300>
   1e4f0:      	ldr	x5, [sp, #0x170]
   1e4f4:      	cmp	x22, x5
   1e4f8:      	b.lo	0x1e748 <_mech_canonical_program_entry_v1_numeric_1282+0xbc8>
   1e4fc:      	b	0x22940 <_mech_canonical_program_entry_v1_numeric_1282+0x4dc0>
   1e500:      	str	x2, [sp, #0x180]
   1e504:      	str	x1, [sp, #0x188]
   1e508:      	b	0x1e6f4 <_mech_canonical_program_entry_v1_numeric_1282+0xb74>
   1e50c:      	ldr	x3, [x19, #0x4c68]
   1e510:      	ldr	x4, [x19, #0x4c70]
   1e514:      	mov	x0, #0x0                ; =0
   1e518:      	str	x0, [x19, #0x4c60]
   1e51c:      	mov	x0, #0x3                ; =3
   1e520:      	cmp	x2, #0x19a
   1e524:      	str	x2, [sp, #0x180]
   1e528:      	b.lo	0x22a5c <_mech_canonical_program_entry_v1_numeric_1282+0x4edc>
   1e52c:      	ldr	x0, [x19, #0x4f70]
   1e530:      	str	x0, [x1, #0x10]
   1e534:      	ldr	x2, [x19, #0x4f78]
   1e538:      	str	x2, [x1, #0x18]
   1e53c:      	ldr	x5, [x19, #0x5a20]
   1e540:      	str	x5, [x1, #0xac0]
   1e544:      	str	x0, [x1, #0x10]
   1e548:      	str	x2, [x1, #0x18]
   1e54c:      	ldr	x0, [x19, #0x50c0]
   1e550:      	str	x0, [x1, #0x160]
   1e554:      	ldr	x0, [x19, #0x50c8]
   1e558:      	str	x0, [x1, #0x168]
   1e55c:      	ldr	x0, [x19, #0x50d0]
   1e560:      	str	x0, [x1, #0x170]
   1e564:      	ldr	x0, [x19, #0x50d8]
   1e568:      	str	x0, [x1, #0x178]
   1e56c:      	ldr	x0, [x19, #0x50e0]
   1e570:      	str	x0, [x1, #0x180]
   1e574:      	ldr	x0, [x19, #0x50e8]
   1e578:      	str	x0, [x1, #0x188]
   1e57c:      	ldr	x0, [x19, #0x50f0]
   1e580:      	str	x0, [x1, #0x190]
   1e584:      	ldr	x0, [x19, #0x50f8]
   1e588:      	str	x0, [x1, #0x198]
   1e58c:      	ldr	x0, [x19, #0x5100]
   1e590:      	str	x0, [x1, #0x1a0]
   1e594:      	ldr	x0, [x19, #0x52a8]
   1e598:      	str	x0, [x1, #0x348]
   1e59c:      	ldr	x0, [x19, #0x52b0]
   1e5a0:      	str	x0, [x1, #0x350]
   1e5a4:      	ldr	x0, [x19, #0x52b8]
   1e5a8:      	str	x0, [x1, #0x358]
   1e5ac:      	ldr	x0, [x19, #0x52c0]
   1e5b0:      	str	x0, [x1, #0x360]
   1e5b4:      	ldr	x0, [x19, #0x52c8]
   1e5b8:      	str	x0, [x1, #0x368]
   1e5bc:      	ldr	x0, [x19, #0x52d0]
   1e5c0:      	str	x0, [x1, #0x370]
   1e5c4:      	ldr	x0, [x19, #0x52d8]
   1e5c8:      	str	x0, [x1, #0x378]
   1e5cc:      	ldr	x0, [x19, #0x52e0]
   1e5d0:      	str	x0, [x1, #0x380]
   1e5d4:      	ldr	x0, [x19, #0x52e8]
   1e5d8:      	str	x0, [x1, #0x388]
   1e5dc:      	ldr	x2, [x19, #0x55d8]
   1e5e0:      	str	x2, [x1, #0x678]
   1e5e4:      	ldr	x2, [x19, #0x55e0]
   1e5e8:      	str	x2, [x1, #0x680]
   1e5ec:      	ldr	x5, [x19, #0x55e8]
   1e5f0:      	str	x5, [x1, #0x688]
   1e5f4:      	ldr	x5, [x19, #0x55f0]
   1e5f8:      	str	x5, [x1, #0x690]
   1e5fc:      	ldr	x5, [x19, #0x55f8]
   1e600:      	str	x5, [x1, #0x698]
   1e604:      	ldr	x6, [x19, #0x5600]
   1e608:      	str	x6, [x1, #0x6a0]
   1e60c:      	ldr	x7, [x19, #0x5608]
   1e610:      	str	x7, [x1, #0x6a8]
   1e614:      	ldr	x8, [x19, #0x5610]
   1e618:      	str	x8, [x1, #0x6b0]
   1e61c:      	ldr	x9, [x19, #0x57a0]
   1e620:      	str	x9, [x1, #0x840]
   1e624:      	ldr	x10, [x19, #0x57a8]
   1e628:      	str	x10, [x1, #0x848]
   1e62c:      	ldr	x11, [x19, #0x57b0]
   1e630:      	str	x11, [x1, #0x850]
   1e634:      	ldr	x12, [x19, #0x57b8]
   1e638:      	str	x12, [x1, #0x858]
   1e63c:      	ldr	x13, [x19, #0x57c0]
   1e640:      	str	x13, [x1, #0x860]
   1e644:      	ldr	x14, [x19, #0x57c8]
   1e648:      	str	x14, [x1, #0x868]
   1e64c:      	ldr	x15, [x19, #0x57d0]
   1e650:      	str	x15, [x1, #0x870]
   1e654:      	ldr	x0, [x19, #0x57d8]
   1e658:      	str	x0, [x1, #0x878]
   1e65c:      	ldr	x0, [x19, #0x5bb0]
   1e660:      	str	x0, [x1, #0xc50]
   1e664:      	ldr	x0, [x19, #0x5bb8]
   1e668:      	str	x0, [x1, #0xc58]
   1e66c:      	ldr	x0, [x19, #0x5bc0]
   1e670:      	str	x0, [x1, #0xc60]
   1e674:      	ldr	x0, [x19, #0x5bc8]
   1e678:      	str	x0, [x1, #0xc68]
   1e67c:      	ldr	x0, [x19, #0x5bd0]
   1e680:      	str	x0, [x1, #0xc70]
   1e684:      	ldr	x0, [x19, #0x5bd8]
   1e688:      	str	x0, [x1, #0xc78]
   1e68c:      	mov	x0, #0x0                ; =0
   1e690:      	str	x0, [x1, #0xc80]
   1e694:      	ldr	x2, [x19, #0x5be8]
   1e698:      	str	x2, [x1, #0xc88]
   1e69c:      	ldr	x2, [x19, #0x5bf0]
   1e6a0:      	str	x2, [x1, #0xc90]
   1e6a4:      	str	x0, [x1, #0xc98]
   1e6a8:      	ldr	x2, [x19, #0x5c00]
   1e6ac:      	str	x2, [x1, #0xca0]
   1e6b0:      	ldr	x2, [x19, #0x5c08]
   1e6b4:      	str	x2, [x1, #0xca8]
   1e6b8:      	str	x0, [x1, #0xcb0]
   1e6bc:      	ldr	x0, [x19, #0x5c18]
   1e6c0:      	str	x0, [x1, #0xcb8]
   1e6c4:      	ldr	x0, [x19, #0x5c20]
   1e6c8:      	str	x0, [x1, #0xcc0]
   1e6cc:      	str	x1, [sp, #0x188]
   1e6d0:      	mov	x1, #0x512              ; =1298
   1e6d4:      	mov	x2, #-0x9               ; =-9
   1e6d8:      	ldr	x21, [sp, #0x198]
   1e6dc:      	ldur	x0, [sp, #0x8]
   1e6e0:      	mov	x5, x20
   1e6e4:      	ldr	x6, [sp, #0x190]
   1e6e8:      	blr	x21
   1e6ec:      	cmp	x0, #0x0
   1e6f0:      	b.ne	0x22a64 <_mech_canonical_program_entry_v1_numeric_1282+0x4ee4>
   1e6f4:      	mov	x0, #0x3                ; =3
   1e6f8:      	ldr	x15, [sp, #0x180]
   1e6fc:      	cmp	x15, #0x2
   1e700:      	b.lo	0x22a6c <_mech_canonical_program_entry_v1_numeric_1282+0x4eec>
   1e704:      	mov	x5, #0x0                ; =0
   1e708:      	ldr	x3, [sp, #0x188]
   1e70c:      	str	x5, [x3]
   1e710:      	ldr	x0, [x19, #0x17d0]
   1e714:      	str	x0, [x3, #0x8]
   1e718:      	mov	x1, #0x512              ; =1298
   1e71c:      	ldur	x0, [sp, #0x8]
   1e720:      	ldr	x6, [sp, #0x190]
   1e724:      	ldr	x21, [sp, #0x198]
   1e728:      	mov	x4, x20
   1e72c:      	mov	x2, x5
   1e730:      	blr	x21
   1e734:      	cmp	x0, #0x0
   1e738:      	b.ne	0x22a74 <_mech_canonical_program_entry_v1_numeric_1282+0x4ef4>
   1e73c:      	mov	x0, #0x3                ; =3
   1e740:      	stur	x0, [sp, #0xb8]
   1e744:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   1e748:      	str	x1, [sp, #0x188]
   1e74c:      	str	x2, [sp, #0x180]
   1e750:      	stur	x9, [sp, #0x98]
   1e754:      	ldr	x2, [sp, #0x178]
   1e758:      	ldr	x1, [x2, x22, lsl #3]
   1e75c:      	add	x24, x22, #0x1
   1e760:      	ldr	x2, [sp, #0x170]
   1e764:      	cmp	x24, x2
   1e768:      	stur	x24, [sp, #0xd8]
   1e76c:      	b.lo	0x1e9e4 <_mech_canonical_program_entry_v1_numeric_1282+0xe64>
   1e770:      	b	0x22a7c <_mech_canonical_program_entry_v1_numeric_1282+0x4efc>
   1e774:      	ldr	x3, [x19, #0x4c68]
   1e778:      	ldr	x4, [x19, #0x4c70]
   1e77c:      	mov	x0, #0x0                ; =0
   1e780:      	str	x0, [x19, #0x4c60]
   1e784:      	mov	x0, #0x3                ; =3
   1e788:      	ldr	x15, [sp, #0x180]
   1e78c:      	cmp	x15, #0x19a
   1e790:      	b.lo	0x22ba0 <_mech_canonical_program_entry_v1_numeric_1282+0x5020>
   1e794:      	ldr	x0, [x19, #0x4f70]
   1e798:      	ldr	x1, [sp, #0x188]
   1e79c:      	str	x0, [x1, #0x10]
   1e7a0:      	ldr	x1, [x19, #0x4f78]
   1e7a4:      	ldr	x2, [sp, #0x188]
   1e7a8:      	str	x1, [x2, #0x18]
   1e7ac:      	ldr	x2, [x19, #0x5a20]
   1e7b0:      	ldr	x5, [sp, #0x188]
   1e7b4:      	str	x2, [x5, #0xac0]
   1e7b8:      	ldr	x2, [sp, #0x188]
   1e7bc:      	str	x0, [x2, #0x10]
   1e7c0:      	ldr	x0, [sp, #0x188]
   1e7c4:      	str	x1, [x0, #0x18]
   1e7c8:      	ldr	x0, [x19, #0x50c0]
   1e7cc:      	ldr	x1, [sp, #0x188]
   1e7d0:      	str	x0, [x1, #0x160]
   1e7d4:      	ldr	x0, [x19, #0x50c8]
   1e7d8:      	str	x0, [x1, #0x168]
   1e7dc:      	ldr	x0, [x19, #0x50d0]
   1e7e0:      	str	x0, [x1, #0x170]
   1e7e4:      	ldr	x0, [x19, #0x50d8]
   1e7e8:      	str	x0, [x1, #0x178]
   1e7ec:      	ldr	x0, [x19, #0x50e0]
   1e7f0:      	str	x0, [x1, #0x180]
   1e7f4:      	ldr	x0, [x19, #0x50e8]
   1e7f8:      	str	x0, [x1, #0x188]
   1e7fc:      	ldr	x0, [x19, #0x50f0]
   1e800:      	str	x0, [x1, #0x190]
   1e804:      	ldr	x0, [x19, #0x50f8]
   1e808:      	str	x0, [x1, #0x198]
   1e80c:      	ldr	x0, [x19, #0x5100]
   1e810:      	str	x0, [x5, #0x1a0]
   1e814:      	ldr	x0, [x19, #0x52a8]
   1e818:      	ldr	x7, [sp, #0x188]
   1e81c:      	str	x0, [x7, #0x348]
   1e820:      	ldr	x0, [x19, #0x52b0]
   1e824:      	ldr	x10, [sp, #0x188]
   1e828:      	str	x0, [x10, #0x350]
   1e82c:      	ldr	x0, [x19, #0x52b8]
   1e830:      	ldr	x13, [sp, #0x188]
   1e834:      	str	x0, [x13, #0x358]
   1e838:      	ldr	x0, [x19, #0x52c0]
   1e83c:      	str	x0, [x1, #0x360]
   1e840:      	ldr	x0, [x19, #0x52c8]
   1e844:      	str	x0, [x1, #0x368]
   1e848:      	ldr	x0, [x19, #0x52d0]
   1e84c:      	str	x0, [x1, #0x370]
   1e850:      	ldr	x0, [x19, #0x52d8]
   1e854:      	str	x0, [x1, #0x378]
   1e858:      	ldr	x0, [x19, #0x52e0]
   1e85c:      	str	x0, [x1, #0x380]
   1e860:      	ldr	x0, [x19, #0x52e8]
   1e864:      	str	x0, [x1, #0x388]
   1e868:      	ldr	x0, [x19, #0x55d8]
   1e86c:      	str	x0, [x1, #0x678]
   1e870:      	ldr	x0, [x19, #0x55e0]
   1e874:      	str	x0, [x1, #0x680]
   1e878:      	ldr	x0, [x19, #0x55e8]
   1e87c:      	str	x0, [x1, #0x688]
   1e880:      	ldr	x0, [x19, #0x55f0]
   1e884:      	str	x0, [x1, #0x690]
   1e888:      	ldr	x0, [x19, #0x55f8]
   1e88c:      	str	x0, [x1, #0x698]
   1e890:      	ldr	x0, [x19, #0x5600]
   1e894:      	str	x0, [x1, #0x6a0]
   1e898:      	ldr	x0, [x19, #0x5608]
   1e89c:      	str	x0, [x1, #0x6a8]
   1e8a0:      	ldr	x0, [x19, #0x5610]
   1e8a4:      	str	x0, [x1, #0x6b0]
   1e8a8:      	ldr	x1, [x19, #0x57a0]
   1e8ac:      	ldr	x0, [sp, #0x188]
   1e8b0:      	str	x1, [x0, #0x840]
   1e8b4:      	ldr	x2, [x19, #0x57a8]
   1e8b8:      	str	x2, [x0, #0x848]
   1e8bc:      	ldr	x5, [x19, #0x57b0]
   1e8c0:      	ldr	x1, [sp, #0x188]
   1e8c4:      	str	x5, [x1, #0x850]
   1e8c8:      	ldr	x5, [x19, #0x57b8]
   1e8cc:      	ldr	x6, [sp, #0x188]
   1e8d0:      	str	x5, [x6, #0x858]
   1e8d4:      	ldr	x5, [x19, #0x57c0]
   1e8d8:      	str	x5, [x7, #0x860]
   1e8dc:      	ldr	x6, [x19, #0x57c8]
   1e8e0:      	str	x6, [x10, #0x868]
   1e8e4:      	ldr	x7, [x19, #0x57d0]
   1e8e8:      	str	x7, [x13, #0x870]
   1e8ec:      	ldr	x8, [x19, #0x57d8]
   1e8f0:      	str	x8, [x0, #0x878]
   1e8f4:      	ldr	x9, [x19, #0x5bb0]
   1e8f8:      	str	x9, [x0, #0xc50]
   1e8fc:      	ldr	x10, [x19, #0x5bb8]
   1e900:      	str	x10, [x0, #0xc58]
   1e904:      	ldr	x11, [x19, #0x5bc0]
   1e908:      	str	x11, [x0, #0xc60]
   1e90c:      	ldr	x12, [x19, #0x5bc8]
   1e910:      	str	x12, [x0, #0xc68]
   1e914:      	ldr	x13, [x19, #0x5bd0]
   1e918:      	str	x13, [x0, #0xc70]
   1e91c:      	ldr	x14, [x19, #0x5bd8]
   1e920:      	str	x14, [x0, #0xc78]
   1e924:      	mov	x15, #0x0               ; =0
   1e928:      	str	x15, [x0, #0xc80]
   1e92c:      	ldr	x0, [x19, #0x5be8]
   1e930:      	str	x0, [x1, #0xc88]
   1e934:      	ldr	x0, [x19, #0x5bf0]
   1e938:      	str	x0, [x1, #0xc90]
   1e93c:      	ldr	x0, [sp, #0x188]
   1e940:      	str	x15, [x0, #0xc98]
   1e944:      	ldr	x0, [x19, #0x5c00]
   1e948:      	str	x0, [x1, #0xca0]
   1e94c:      	ldr	x0, [x19, #0x5c08]
   1e950:      	str	x0, [x1, #0xca8]
   1e954:      	ldr	x0, [sp, #0x188]
   1e958:      	str	x15, [x0, #0xcb0]
   1e95c:      	ldr	x0, [x19, #0x5c18]
   1e960:      	str	x0, [x1, #0xcb8]
   1e964:      	ldr	x0, [x19, #0x5c20]
   1e968:      	str	x0, [x1, #0xcc0]
   1e96c:      	mov	x1, #0x514              ; =1300
   1e970:      	mov	x2, #-0x9               ; =-9
   1e974:      	ldr	x21, [sp, #0x198]
   1e978:      	ldur	x0, [sp, #0x8]
   1e97c:      	mov	x5, x20
   1e980:      	ldr	x6, [sp, #0x190]
   1e984:      	blr	x21
   1e988:      	cmp	x0, #0x0
   1e98c:      	b.ne	0x22ba8 <_mech_canonical_program_entry_v1_numeric_1282+0x5028>
   1e990:      	mov	x0, #0x3                ; =3
   1e994:      	ldr	x15, [sp, #0x180]
   1e998:      	cmp	x15, #0x2
   1e99c:      	b.lo	0x22bb0 <_mech_canonical_program_entry_v1_numeric_1282+0x5030>
   1e9a0:      	mov	x5, #0x0                ; =0
   1e9a4:      	ldr	x3, [sp, #0x188]
   1e9a8:      	str	x5, [x3]
   1e9ac:      	ldr	x0, [x19, #0x17e0]
   1e9b0:      	str	x0, [x3, #0x8]
   1e9b4:      	mov	x1, #0x514              ; =1300
   1e9b8:      	ldur	x0, [sp, #0x8]
   1e9bc:      	ldr	x6, [sp, #0x190]
   1e9c0:      	ldr	x21, [sp, #0x198]
   1e9c4:      	mov	x4, x20
   1e9c8:      	mov	x2, x5
   1e9cc:      	blr	x21
   1e9d0:      	cmp	x0, #0x0
   1e9d4:      	b.ne	0x22bb8 <_mech_canonical_program_entry_v1_numeric_1282+0x5038>
   1e9d8:      	mov	x0, #0x3                ; =3
   1e9dc:      	stur	x0, [sp, #0xb8]
   1e9e0:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   1e9e4:      	ldr	x2, [sp, #0x178]
   1e9e8:      	ldur	x24, [sp, #0xd8]
   1e9ec:      	ldr	x2, [x2, x24, lsl #3]
   1e9f0:      	ldr	x5, [sp, #0x160]
   1e9f4:      	cmp	x22, x5
   1e9f8:      	b.lo	0x1ec68 <_mech_canonical_program_entry_v1_numeric_1282+0x10e8>
   1e9fc:      	b	0x22bc0 <_mech_canonical_program_entry_v1_numeric_1282+0x5040>
   1ea00:      	ldr	x3, [x19, #0x4c68]
   1ea04:      	ldr	x4, [x19, #0x4c70]
   1ea08:      	mov	x0, #0x0                ; =0
   1ea0c:      	str	x0, [x19, #0x4c60]
   1ea10:      	mov	x0, #0x3                ; =3
   1ea14:      	ldr	x15, [sp, #0x180]
   1ea18:      	cmp	x15, #0x19a
   1ea1c:      	b.lo	0x22ce8 <_mech_canonical_program_entry_v1_numeric_1282+0x5168>
   1ea20:      	ldr	x0, [x19, #0x4f70]
   1ea24:      	ldr	x1, [sp, #0x188]
   1ea28:      	str	x0, [x1, #0x10]
   1ea2c:      	ldr	x1, [x19, #0x4f78]
   1ea30:      	ldr	x2, [sp, #0x188]
   1ea34:      	str	x1, [x2, #0x18]
   1ea38:      	ldr	x2, [x19, #0x5a20]
   1ea3c:      	ldr	x5, [sp, #0x188]
   1ea40:      	str	x2, [x5, #0xac0]
   1ea44:      	ldr	x2, [sp, #0x188]
   1ea48:      	str	x0, [x2, #0x10]
   1ea4c:      	ldr	x0, [sp, #0x188]
   1ea50:      	str	x1, [x0, #0x18]
   1ea54:      	ldr	x0, [x19, #0x50c0]
   1ea58:      	ldr	x1, [sp, #0x188]
   1ea5c:      	str	x0, [x1, #0x160]
   1ea60:      	ldr	x0, [x19, #0x50c8]
   1ea64:      	str	x0, [x1, #0x168]
   1ea68:      	ldr	x0, [x19, #0x50d0]
   1ea6c:      	str	x0, [x1, #0x170]
   1ea70:      	ldr	x0, [x19, #0x50d8]
   1ea74:      	str	x0, [x1, #0x178]
   1ea78:      	ldr	x0, [x19, #0x50e0]
   1ea7c:      	str	x0, [x2, #0x180]
   1ea80:      	ldr	x0, [x19, #0x50e8]
   1ea84:      	str	x0, [x5, #0x188]
   1ea88:      	ldr	x0, [x19, #0x50f0]
   1ea8c:      	ldr	x8, [sp, #0x188]
   1ea90:      	str	x0, [x8, #0x190]
   1ea94:      	ldr	x0, [x19, #0x50f8]
   1ea98:      	ldr	x11, [sp, #0x188]
   1ea9c:      	str	x0, [x11, #0x198]
   1eaa0:      	ldr	x0, [x19, #0x5100]
   1eaa4:      	ldr	x14, [sp, #0x188]
   1eaa8:      	str	x0, [x14, #0x1a0]
   1eaac:      	ldr	x0, [x19, #0x52a8]
   1eab0:      	str	x0, [x1, #0x348]
   1eab4:      	ldr	x0, [x19, #0x52b0]
   1eab8:      	str	x0, [x1, #0x350]
   1eabc:      	ldr	x0, [x19, #0x52b8]
   1eac0:      	str	x0, [x1, #0x358]
   1eac4:      	ldr	x0, [x19, #0x52c0]
   1eac8:      	str	x0, [x1, #0x360]
   1eacc:      	ldr	x0, [x19, #0x52c8]
   1ead0:      	str	x0, [x1, #0x368]
   1ead4:      	ldr	x0, [x19, #0x52d0]
   1ead8:      	str	x0, [x1, #0x370]
   1eadc:      	ldr	x0, [x19, #0x52d8]
   1eae0:      	str	x0, [x1, #0x378]
   1eae4:      	ldr	x0, [x19, #0x52e0]
   1eae8:      	str	x0, [x1, #0x380]
   1eaec:      	ldr	x0, [x19, #0x52e8]
   1eaf0:      	str	x0, [x1, #0x388]
   1eaf4:      	ldr	x0, [x19, #0x55d8]
   1eaf8:      	str	x0, [x1, #0x678]
   1eafc:      	ldr	x0, [x19, #0x55e0]
   1eb00:      	str	x0, [x1, #0x680]
   1eb04:      	ldr	x0, [x19, #0x55e8]
   1eb08:      	str	x0, [x1, #0x688]
   1eb0c:      	ldr	x0, [x19, #0x55f0]
   1eb10:      	str	x0, [x1, #0x690]
   1eb14:      	ldr	x0, [x19, #0x55f8]
   1eb18:      	str	x0, [x1, #0x698]
   1eb1c:      	ldr	x0, [x19, #0x5600]
   1eb20:      	str	x0, [x1, #0x6a0]
   1eb24:      	ldr	x0, [x19, #0x5608]
   1eb28:      	str	x0, [x1, #0x6a8]
   1eb2c:      	ldr	x0, [x19, #0x5610]
   1eb30:      	str	x0, [x2, #0x6b0]
   1eb34:      	ldr	x0, [x19, #0x57a0]
   1eb38:      	str	x0, [x5, #0x840]
   1eb3c:      	ldr	x0, [x19, #0x57a8]
   1eb40:      	str	x0, [x8, #0x848]
   1eb44:      	ldr	x0, [x19, #0x57b0]
   1eb48:      	str	x0, [x11, #0x850]
   1eb4c:      	ldr	x0, [x19, #0x57b8]
   1eb50:      	str	x0, [x14, #0x858]
   1eb54:      	ldr	x0, [x19, #0x57c0]
   1eb58:      	str	x0, [x1, #0x860]
   1eb5c:      	ldr	x0, [x19, #0x57c8]
   1eb60:      	str	x0, [x1, #0x868]
   1eb64:      	ldr	x0, [x19, #0x57d0]
   1eb68:      	str	x0, [x1, #0x870]
   1eb6c:      	ldr	x1, [x19, #0x57d8]
   1eb70:      	ldr	x0, [sp, #0x188]
   1eb74:      	str	x1, [x0, #0x878]
   1eb78:      	ldr	x2, [x19, #0x5bb0]
   1eb7c:      	str	x2, [x0, #0xc50]
   1eb80:      	ldr	x5, [x19, #0x5bb8]
   1eb84:      	str	x5, [x0, #0xc58]
   1eb88:      	ldr	x5, [x19, #0x5bc0]
   1eb8c:      	str	x5, [x0, #0xc60]
   1eb90:      	ldr	x5, [x19, #0x5bc8]
   1eb94:      	str	x5, [x0, #0xc68]
   1eb98:      	ldr	x6, [x19, #0x5bd0]
   1eb9c:      	str	x6, [x0, #0xc70]
   1eba0:      	ldr	x7, [x19, #0x5bd8]
   1eba4:      	str	x7, [x0, #0xc78]
   1eba8:      	mov	x8, #0x0                ; =0
   1ebac:      	str	x8, [x0, #0xc80]
   1ebb0:      	ldr	x9, [x19, #0x5be8]
   1ebb4:      	str	x9, [x0, #0xc88]
   1ebb8:      	ldr	x10, [x19, #0x5bf0]
   1ebbc:      	str	x10, [x0, #0xc90]
   1ebc0:      	str	x8, [x0, #0xc98]
   1ebc4:      	ldr	x12, [x19, #0x5c00]
   1ebc8:      	str	x12, [x0, #0xca0]
   1ebcc:      	ldr	x13, [x19, #0x5c08]
   1ebd0:      	str	x13, [x0, #0xca8]
   1ebd4:      	str	x8, [x0, #0xcb0]
   1ebd8:      	ldr	x15, [x19, #0x5c18]
   1ebdc:      	ldr	x5, [sp, #0x188]
   1ebe0:      	str	x15, [x5, #0xcb8]
   1ebe4:      	ldr	x0, [x19, #0x5c20]
   1ebe8:      	ldr	x6, [sp, #0x188]
   1ebec:      	str	x0, [x6, #0xcc0]
   1ebf0:      	mov	x1, #0x516              ; =1302
   1ebf4:      	mov	x2, #-0x9               ; =-9
   1ebf8:      	ldr	x21, [sp, #0x198]
   1ebfc:      	ldur	x0, [sp, #0x8]
   1ec00:      	mov	x5, x20
   1ec04:      	ldr	x6, [sp, #0x190]
   1ec08:      	blr	x21
   1ec0c:      	cmp	x0, #0x0
   1ec10:      	b.ne	0x22cf0 <_mech_canonical_program_entry_v1_numeric_1282+0x5170>
   1ec14:      	mov	x0, #0x3                ; =3
   1ec18:      	ldr	x15, [sp, #0x180]
   1ec1c:      	cmp	x15, #0x2
   1ec20:      	b.lo	0x22cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x5178>
   1ec24:      	mov	x5, #0x0                ; =0
   1ec28:      	ldr	x3, [sp, #0x188]
   1ec2c:      	str	x5, [x3]
   1ec30:      	ldr	x0, [x19, #0x17f0]
   1ec34:      	str	x0, [x3, #0x8]
   1ec38:      	mov	x1, #0x516              ; =1302
   1ec3c:      	ldur	x0, [sp, #0x8]
   1ec40:      	ldr	x6, [sp, #0x190]
   1ec44:      	ldr	x21, [sp, #0x198]
   1ec48:      	mov	x4, x20
   1ec4c:      	mov	x2, x5
   1ec50:      	blr	x21
   1ec54:      	cmp	x0, #0x0
   1ec58:      	b.ne	0x22d00 <_mech_canonical_program_entry_v1_numeric_1282+0x5180>
   1ec5c:      	mov	x0, #0x3                ; =3
   1ec60:      	stur	x0, [sp, #0xb8]
   1ec64:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   1ec68:      	stur	x0, [sp, #0xe0]
   1ec6c:      	stur	x4, [sp, #0x80]
   1ec70:      	stur	x1, [sp, #0x18]
   1ec74:      	mov	x26, x2
   1ec78:      	ldr	x0, [sp, #0x168]
   1ec7c:      	ldr	x15, [x0, x22, lsl #3]
   1ec80:      	stur	x15, [sp, #0xd0]
   1ec84:      	mov	w0, #0xc87e             ; =51326
   1ec88:      	movk	w0, #0x1, lsl #16
   1ec8c:      	sub	x3, x3, x0
   1ec90:      	mov	x7, #0x0                ; =0
   1ec94:      	stur	x7, [sp, #0x10]
   1ec98:      	ldur	x2, [sp, #0x10]
   1ec9c:      	ldur	x25, [sp, #0x10]
   1eca0:      	ldur	x27, [sp, #0x10]
   1eca4:      	ldur	x0, [sp, #0x10]
   1eca8:      	stur	x0, [sp, #0x20]
   1ecac:      	stur	x0, [sp, #0x70]
   1ecb0:      	mov	w0, #0x2166             ; =8550
   1ecb4:      	movk	w0, #0x1, lsl #16
   1ecb8:      	cmp	x3, x0
   1ecbc:      	b.hs	0x1f05c <_mech_canonical_program_entry_v1_numeric_1282+0x14dc>
   1ecc0:      	mov	x1, #0x0                ; =0
   1ecc4:      	str	x1, [x19, #0x18]
   1ecc8:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   1eccc:      	str	x0, [x19, #0x20]
   1ecd0:      	mov	x0, #0x1                ; =1
   1ecd4:      	str	x0, [x19, #0x30]
   1ecd8:      	mov	x4, #0x101010101010101  ; =72340172838076673
   1ecdc:      	str	x4, [x19, #0x38]
   1ece0:      	mov	x4, #0x2                ; =2
   1ece4:      	str	x4, [x19, #0x40]
   1ece8:      	mov	x20, x4
   1ecec:      	mov	x4, #0x3                ; =3
   1ecf0:      	str	x4, [x19, #0x48]
   1ecf4:      	mov	x4, #0x4                ; =4
   1ecf8:      	str	x4, [x19, #0x50]
   1ecfc:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   1ed00:      	str	x4, [x19, #0x78]
   1ed04:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   1ed08:      	str	x4, [x19, #0x88]
   1ed0c:      	mov	x4, #0x38               ; =56
   1ed10:      	str	x4, [x19, #0x90]
   1ed14:      	mov	x4, #0x3a               ; =58
   1ed18:      	str	x4, [x19, #0x98]
   1ed1c:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   1ed20:      	str	x4, [x19, #0xb0]
   1ed24:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   1ed28:      	str	x4, [x19, #0xb8]
   1ed2c:      	str	x1, [x19, #0x188]
   1ed30:      	str	x0, [x19, #0x190]
   1ed34:      	str	x22, [x19, #0x17a0]
   1ed38:      	str	x23, [x19, #0x17a8]
   1ed3c:      	ldur	x24, [sp, #0xe0]
   1ed40:      	uxtb	w1, w24
   1ed44:      	str	x1, [x19, #0x17b8]
   1ed48:      	str	x10, [x19, #0x4c60]
   1ed4c:      	str	x3, [x19, #0x4c68]
   1ed50:      	ldur	x4, [sp, #0x80]
   1ed54:      	str	x4, [x19, #0x4c70]
   1ed58:      	str	x22, [x19, #0x4f70]
   1ed5c:      	str	x23, [x19, #0x4f78]
   1ed60:      	ldur	x1, [sp, #0x18]
   1ed64:      	str	x1, [x19, #0x50c0]
   1ed68:      	mov	x15, x26
   1ed6c:      	str	x15, [x19, #0x50c8]
   1ed70:      	str	x22, [x19, #0x50d0]
   1ed74:      	ldur	x26, [sp, #0xd0]
   1ed78:      	str	x26, [x19, #0x50d8]
   1ed7c:      	ldur	x1, [sp, #0x10]
   1ed80:      	str	x1, [x19, #0x50e0]
   1ed84:      	str	x27, [x19, #0x50e8]
   1ed88:      	str	x25, [x19, #0x50f0]
   1ed8c:      	str	x2, [x19, #0x50f8]
   1ed90:      	ldur	x26, [sp, #0x70]
   1ed94:      	str	x26, [x19, #0x5100]
   1ed98:      	ldur	x1, [sp, #0x50]
   1ed9c:      	str	x1, [x19, #0x5a20]
   1eda0:      	add	x14, x8, #0x1
   1eda4:      	str	x14, [x19, #0x5bb0]
   1eda8:      	ldur	x26, [sp, #0x88]
   1edac:      	str	x26, [x19, #0x5bb8]
   1edb0:      	ldur	x6, [sp, #0x90]
   1edb4:      	str	x6, [x19, #0x5bc0]
   1edb8:      	ldur	x4, [sp, #0x78]
   1edbc:      	sub	x15, x4, x3
   1edc0:      	mov	w1, #0xc87e             ; =51326
   1edc4:      	movk	w1, #0x1, lsl #16
   1edc8:      	msub	x14, x14, x1, x15
   1edcc:      	str	x14, [x19, #0x5bc8]
   1edd0:      	str	x0, [x19, #0x5bd0]
   1edd4:      	ldur	x21, [sp, #0x20]
   1edd8:      	str	x21, [x19, #0x5bd8]
   1eddc:      	ldur	x10, [sp, #0x98]
   1ede0:      	str	x10, [x19, #0x5be8]
   1ede4:      	ldur	x4, [sp, #0xa0]
   1ede8:      	str	x4, [x19, #0x5bf0]
   1edec:      	str	x12, [x19, #0x5c00]
   1edf0:      	str	x11, [x19, #0x5c08]
   1edf4:      	str	x13, [x19, #0x5c18]
   1edf8:      	ldur	x13, [sp, #0xa8]
   1edfc:      	str	x13, [x19, #0x5c20]
   1ee00:      	ldr	x0, [x19, #0x4c60]
   1ee04:      	cmp	x0, #0x0
   1ee08:      	b.eq	0x1f034 <_mech_canonical_program_entry_v1_numeric_1282+0x14b4>
   1ee0c:      	ldr	x3, [x19, #0x4c68]
   1ee10:      	ldr	x4, [x19, #0x4c70]
   1ee14:      	mov	x0, #0x0                ; =0
   1ee18:      	str	x0, [x19, #0x4c60]
   1ee1c:      	mov	x0, #0x3                ; =3
   1ee20:      	ldr	x15, [sp, #0x180]
   1ee24:      	stur	x0, [sp, #0xb8]
   1ee28:      	cmp	x15, #0x19a
   1ee2c:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   1ee30:      	ldr	x0, [x19, #0x4f70]
   1ee34:      	ldr	x2, [sp, #0x188]
   1ee38:      	str	x0, [x2, #0x10]
   1ee3c:      	ldr	x1, [x19, #0x4f78]
   1ee40:      	ldr	x5, [sp, #0x188]
   1ee44:      	str	x1, [x5, #0x18]
   1ee48:      	ldr	x2, [x19, #0x5a20]
   1ee4c:      	ldr	x8, [sp, #0x188]
   1ee50:      	str	x2, [x8, #0xac0]
   1ee54:      	ldr	x10, [sp, #0x188]
   1ee58:      	str	x0, [x10, #0x10]
   1ee5c:      	ldr	x12, [sp, #0x188]
   1ee60:      	str	x1, [x12, #0x18]
   1ee64:      	ldr	x0, [x19, #0x50c0]
   1ee68:      	ldr	x15, [sp, #0x188]
   1ee6c:      	str	x0, [x15, #0x160]
   1ee70:      	ldr	x0, [x19, #0x50c8]
   1ee74:      	ldr	x1, [sp, #0x188]
   1ee78:      	str	x0, [x1, #0x168]
   1ee7c:      	ldr	x0, [x19, #0x50d0]
   1ee80:      	str	x0, [x1, #0x170]
   1ee84:      	ldr	x0, [x19, #0x50d8]
   1ee88:      	str	x0, [x1, #0x178]
   1ee8c:      	ldr	x0, [x19, #0x50e0]
   1ee90:      	str	x0, [x1, #0x180]
   1ee94:      	ldr	x0, [x19, #0x50e8]
   1ee98:      	str	x0, [x1, #0x188]
   1ee9c:      	ldr	x0, [x19, #0x50f0]
   1eea0:      	str	x0, [x1, #0x190]
   1eea4:      	ldr	x0, [x19, #0x50f8]
   1eea8:      	str	x0, [x1, #0x198]
   1eeac:      	ldr	x0, [x19, #0x5100]
   1eeb0:      	str	x0, [x1, #0x1a0]
   1eeb4:      	ldr	x0, [x19, #0x52a8]
   1eeb8:      	str	x0, [x1, #0x348]
   1eebc:      	ldr	x0, [x19, #0x52b0]
   1eec0:      	str	x0, [x1, #0x350]
   1eec4:      	ldr	x0, [x19, #0x52b8]
   1eec8:      	str	x0, [x1, #0x358]
   1eecc:      	ldr	x0, [x19, #0x52c0]
   1eed0:      	str	x0, [x1, #0x360]
   1eed4:      	ldr	x0, [x19, #0x52c8]
   1eed8:      	str	x0, [x1, #0x368]
   1eedc:      	ldr	x0, [x19, #0x52d0]
   1eee0:      	str	x0, [x1, #0x370]
   1eee4:      	ldr	x0, [x19, #0x52d8]
   1eee8:      	str	x0, [x1, #0x378]
   1eeec:      	ldr	x0, [x19, #0x52e0]
   1eef0:      	str	x0, [x1, #0x380]
   1eef4:      	ldr	x0, [x19, #0x52e8]
   1eef8:      	str	x0, [x5, #0x388]
   1eefc:      	ldr	x0, [x19, #0x55d8]
   1ef00:      	ldr	x6, [sp, #0x188]
   1ef04:      	str	x0, [x6, #0x678]
   1ef08:      	ldr	x0, [x19, #0x55e0]
   1ef0c:      	ldr	x9, [sp, #0x188]
   1ef10:      	str	x0, [x9, #0x680]
   1ef14:      	ldr	x0, [x19, #0x55e8]
   1ef18:      	str	x0, [x12, #0x688]
   1ef1c:      	ldr	x0, [x19, #0x55f0]
   1ef20:      	str	x0, [x15, #0x690]
   1ef24:      	ldr	x0, [x19, #0x55f8]
   1ef28:      	str	x0, [x1, #0x698]
   1ef2c:      	ldr	x0, [x19, #0x5600]
   1ef30:      	str	x0, [x1, #0x6a0]
   1ef34:      	ldr	x0, [x19, #0x5608]
   1ef38:      	str	x0, [x1, #0x6a8]
   1ef3c:      	ldr	x0, [x19, #0x5610]
   1ef40:      	str	x0, [x1, #0x6b0]
   1ef44:      	ldr	x0, [x19, #0x57a0]
   1ef48:      	str	x0, [x1, #0x840]
   1ef4c:      	ldr	x0, [x19, #0x57a8]
   1ef50:      	str	x0, [x1, #0x848]
   1ef54:      	ldr	x0, [x19, #0x57b0]
   1ef58:      	str	x0, [x1, #0x850]
   1ef5c:      	ldr	x1, [x19, #0x57b8]
   1ef60:      	ldr	x0, [sp, #0x188]
   1ef64:      	str	x1, [x0, #0x858]
   1ef68:      	ldr	x2, [x19, #0x57c0]
   1ef6c:      	str	x2, [x0, #0x860]
   1ef70:      	ldr	x5, [x19, #0x57c8]
   1ef74:      	str	x5, [x0, #0x868]
   1ef78:      	ldr	x5, [x19, #0x57d0]
   1ef7c:      	str	x5, [x0, #0x870]
   1ef80:      	ldr	x5, [x19, #0x57d8]
   1ef84:      	str	x5, [x0, #0x878]
   1ef88:      	ldr	x6, [x19, #0x5bb0]
   1ef8c:      	str	x6, [x0, #0xc50]
   1ef90:      	ldr	x7, [x19, #0x5bb8]
   1ef94:      	str	x7, [x0, #0xc58]
   1ef98:      	ldr	x8, [x19, #0x5bc0]
   1ef9c:      	str	x8, [x0, #0xc60]
   1efa0:      	ldr	x9, [x19, #0x5bc8]
   1efa4:      	str	x9, [x0, #0xc68]
   1efa8:      	ldr	x10, [x19, #0x5bd0]
   1efac:      	ldr	x5, [sp, #0x188]
   1efb0:      	str	x10, [x5, #0xc70]
   1efb4:      	ldr	x11, [x19, #0x5bd8]
   1efb8:      	ldr	x6, [sp, #0x188]
   1efbc:      	str	x11, [x6, #0xc78]
   1efc0:      	mov	x12, #0x0               ; =0
   1efc4:      	ldr	x9, [sp, #0x188]
   1efc8:      	str	x12, [x9, #0xc80]
   1efcc:      	ldr	x13, [x19, #0x5be8]
   1efd0:      	ldr	x14, [sp, #0x188]
   1efd4:      	str	x13, [x14, #0xc88]
   1efd8:      	ldr	x14, [x19, #0x5bf0]
   1efdc:      	str	x14, [x15, #0xc90]
   1efe0:      	str	x12, [x0, #0xc98]
   1efe4:      	ldr	x0, [x19, #0x5c00]
   1efe8:      	ldr	x1, [sp, #0x188]
   1efec:      	str	x0, [x1, #0xca0]
   1eff0:      	ldr	x0, [x19, #0x5c08]
   1eff4:      	str	x0, [x1, #0xca8]
   1eff8:      	ldr	x0, [sp, #0x188]
   1effc:      	str	x12, [x0, #0xcb0]
   1f000:      	ldr	x0, [x19, #0x5c18]
   1f004:      	str	x0, [x1, #0xcb8]
   1f008:      	ldr	x0, [x19, #0x5c20]
   1f00c:      	str	x0, [x1, #0xcc0]
   1f010:      	mov	x1, #0x51f              ; =1311
   1f014:      	mov	x2, #-0x9               ; =-9
   1f018:      	mov	x5, #0x1                ; =1
   1f01c:      	ldur	x0, [sp, #0x8]
   1f020:      	ldr	x6, [sp, #0x190]
   1f024:      	ldr	x21, [sp, #0x198]
   1f028:      	blr	x21
   1f02c:      	cmp	x0, #0x0
   1f030:      	b.ne	0x22d08 <_mech_canonical_program_entry_v1_numeric_1282+0x5188>
   1f034:      	mov	x0, #0x0                ; =0
   1f038:      	mov	x1, x20
   1f03c:      	add	sp, sp, #0x1b0
   1f040:      	ldp	x19, x20, [sp], #0x10
   1f044:      	ldp	x21, x22, [sp], #0x10
   1f048:      	ldp	x23, x24, [sp], #0x10
   1f04c:      	ldp	x25, x26, [sp], #0x10
   1f050:      	ldp	x27, x28, [sp], #0x10
   1f054:      	ldp	x29, x30, [sp], #0x10
   1f058:      	retab
   1f05c:      	ldur	x1, [sp, #0x18]
   1f060:      	stur	x2, [sp, #0x68]
   1f064:      	mov	x15, x26
   1f068:      	cmp	x1, x15
   1f06c:      	cset	x15, lo
   1f070:      	stur	x15, [sp, #0xc8]
   1f074:      	mov	x15, x26
   1f078:      	cmp	x1, x15
   1f07c:      	b.lo	0x1f0b0 <_mech_canonical_program_entry_v1_numeric_1282+0x1530>
   1f080:      	mov	w0, #0x2166             ; =8550
   1f084:      	movk	w0, #0x1, lsl #16
   1f088:      	sub	x3, x3, x0
   1f08c:      	stur	x25, [sp, #0x60]
   1f090:      	stur	x27, [sp, #0x58]
   1f094:      	stur	x1, [sp, #0x18]
   1f098:      	mov	x15, x27
   1f09c:      	mov	x4, x1
   1f0a0:      	ldur	x2, [sp, #0x10]
   1f0a4:      	ldur	x1, [sp, #0x68]
   1f0a8:      	ldur	x0, [sp, #0x70]
   1f0ac:      	b	0x2045c <_mech_canonical_program_entry_v1_numeric_1282+0x28dc>
   1f0b0:      	ldr	x15, [sp, #0x150]
   1f0b4:      	cmp	x1, x15
   1f0b8:      	b.lo	0x1f350 <_mech_canonical_program_entry_v1_numeric_1282+0x17d0>
   1f0bc:      	b	0x22d10 <_mech_canonical_program_entry_v1_numeric_1282+0x5190>
   1f0c0:      	ldr	x3, [x19, #0x4c68]
   1f0c4:      	ldr	x4, [x19, #0x4c70]
   1f0c8:      	mov	x0, #0x0                ; =0
   1f0cc:      	str	x0, [x19, #0x4c60]
   1f0d0:      	mov	x0, #0x3                ; =3
   1f0d4:      	ldr	x15, [sp, #0x180]
   1f0d8:      	stur	x0, [sp, #0xb8]
   1f0dc:      	cmp	x15, #0x19a
   1f0e0:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   1f0e4:      	ldr	x0, [x19, #0x4f70]
   1f0e8:      	ldr	x1, [sp, #0x188]
   1f0ec:      	str	x0, [x1, #0x10]
   1f0f0:      	ldr	x1, [x19, #0x4f78]
   1f0f4:      	ldr	x2, [sp, #0x188]
   1f0f8:      	str	x1, [x2, #0x18]
   1f0fc:      	ldr	x2, [x19, #0x5a20]
   1f100:      	ldr	x5, [sp, #0x188]
   1f104:      	str	x2, [x5, #0xac0]
   1f108:      	ldr	x2, [sp, #0x188]
   1f10c:      	str	x0, [x2, #0x10]
   1f110:      	ldr	x0, [sp, #0x188]
   1f114:      	str	x1, [x0, #0x18]
   1f118:      	ldr	x0, [x19, #0x50c0]
   1f11c:      	ldr	x1, [sp, #0x188]
   1f120:      	str	x0, [x1, #0x160]
   1f124:      	ldr	x0, [x19, #0x50c8]
   1f128:      	str	x0, [x1, #0x168]
   1f12c:      	ldr	x0, [x19, #0x50d0]
   1f130:      	str	x0, [x1, #0x170]
   1f134:      	ldr	x0, [x19, #0x50d8]
   1f138:      	str	x0, [x1, #0x178]
   1f13c:      	ldr	x0, [x19, #0x50e0]
   1f140:      	str	x0, [x1, #0x180]
   1f144:      	ldr	x0, [x19, #0x50e8]
   1f148:      	str	x0, [x1, #0x188]
   1f14c:      	ldr	x0, [x19, #0x50f0]
   1f150:      	str	x0, [x1, #0x190]
   1f154:      	ldr	x0, [x19, #0x50f8]
   1f158:      	str	x0, [x5, #0x198]
   1f15c:      	ldr	x0, [x19, #0x5100]
   1f160:      	ldr	x6, [sp, #0x188]
   1f164:      	str	x0, [x6, #0x1a0]
   1f168:      	ldr	x0, [x19, #0x52a8]
   1f16c:      	ldr	x9, [sp, #0x188]
   1f170:      	str	x0, [x9, #0x348]
   1f174:      	ldr	x0, [x19, #0x52b0]
   1f178:      	ldr	x12, [sp, #0x188]
   1f17c:      	str	x0, [x12, #0x350]
   1f180:      	ldr	x0, [x19, #0x52b8]
   1f184:      	ldr	x15, [sp, #0x188]
   1f188:      	str	x0, [x15, #0x358]
   1f18c:      	ldr	x0, [x19, #0x52c0]
   1f190:      	str	x0, [x1, #0x360]
   1f194:      	ldr	x0, [x19, #0x52c8]
   1f198:      	str	x0, [x1, #0x368]
   1f19c:      	ldr	x0, [x19, #0x52d0]
   1f1a0:      	str	x0, [x1, #0x370]
   1f1a4:      	ldr	x0, [x19, #0x52d8]
   1f1a8:      	str	x0, [x1, #0x378]
   1f1ac:      	ldr	x1, [x19, #0x52e0]
   1f1b0:      	ldr	x0, [sp, #0x188]
   1f1b4:      	str	x1, [x0, #0x380]
   1f1b8:      	ldr	x2, [x19, #0x52e8]
   1f1bc:      	str	x2, [x0, #0x388]
   1f1c0:      	ldr	x5, [x19, #0x55d8]
   1f1c4:      	str	x5, [x0, #0x678]
   1f1c8:      	ldr	x5, [x19, #0x55e0]
   1f1cc:      	str	x5, [x0, #0x680]
   1f1d0:      	ldr	x5, [x19, #0x55e8]
   1f1d4:      	str	x5, [x0, #0x688]
   1f1d8:      	ldr	x6, [x19, #0x55f0]
   1f1dc:      	str	x6, [x0, #0x690]
   1f1e0:      	ldr	x7, [x19, #0x55f8]
   1f1e4:      	str	x7, [x0, #0x698]
   1f1e8:      	ldr	x8, [x19, #0x5600]
   1f1ec:      	str	x8, [x0, #0x6a0]
   1f1f0:      	ldr	x9, [x19, #0x5608]
   1f1f4:      	str	x9, [x0, #0x6a8]
   1f1f8:      	ldr	x10, [x19, #0x5610]
   1f1fc:      	str	x10, [x0, #0x6b0]
   1f200:      	ldr	x11, [x19, #0x57a0]
   1f204:      	str	x11, [x0, #0x840]
   1f208:      	ldr	x12, [x19, #0x57a8]
   1f20c:      	str	x12, [x0, #0x848]
   1f210:      	ldr	x13, [x19, #0x57b0]
   1f214:      	ldr	x5, [sp, #0x188]
   1f218:      	str	x13, [x5, #0x850]
   1f21c:      	ldr	x14, [x19, #0x57b8]
   1f220:      	ldr	x6, [sp, #0x188]
   1f224:      	str	x14, [x6, #0x858]
   1f228:      	ldr	x15, [x19, #0x57c0]
   1f22c:      	ldr	x9, [sp, #0x188]
   1f230:      	str	x15, [x9, #0x860]
   1f234:      	ldr	x0, [x19, #0x57c8]
   1f238:      	ldr	x12, [sp, #0x188]
   1f23c:      	str	x0, [x12, #0x868]
   1f240:      	ldr	x0, [x19, #0x57d0]
   1f244:      	ldr	x15, [sp, #0x188]
   1f248:      	str	x0, [x15, #0x870]
   1f24c:      	ldr	x0, [x19, #0x57d8]
   1f250:      	ldr	x1, [sp, #0x188]
   1f254:      	str	x0, [x1, #0x878]
   1f258:      	ldr	x0, [x19, #0x5bb0]
   1f25c:      	str	x0, [x1, #0xc50]
   1f260:      	ldr	x0, [x19, #0x5bb8]
   1f264:      	str	x0, [x1, #0xc58]
   1f268:      	ldr	x0, [x19, #0x5bc0]
   1f26c:      	str	x0, [x1, #0xc60]
   1f270:      	ldr	x0, [x19, #0x5bc8]
   1f274:      	str	x0, [x1, #0xc68]
   1f278:      	ldr	x0, [x19, #0x5bd0]
   1f27c:      	str	x0, [x1, #0xc70]
   1f280:      	ldr	x0, [x19, #0x5bd8]
   1f284:      	str	x0, [x1, #0xc78]
   1f288:      	mov	x0, #0x0                ; =0
   1f28c:      	str	x0, [x1, #0xc80]
   1f290:      	ldr	x1, [x19, #0x5be8]
   1f294:      	ldr	x2, [sp, #0x188]
   1f298:      	str	x1, [x2, #0xc88]
   1f29c:      	ldr	x1, [x19, #0x5bf0]
   1f2a0:      	str	x1, [x2, #0xc90]
   1f2a4:      	ldr	x1, [sp, #0x188]
   1f2a8:      	str	x0, [x1, #0xc98]
   1f2ac:      	ldr	x1, [x19, #0x5c00]
   1f2b0:      	str	x1, [x2, #0xca0]
   1f2b4:      	ldr	x1, [x19, #0x5c08]
   1f2b8:      	str	x1, [x2, #0xca8]
   1f2bc:      	ldr	x1, [sp, #0x188]
   1f2c0:      	str	x0, [x1, #0xcb0]
   1f2c4:      	ldr	x0, [x19, #0x5c18]
   1f2c8:      	str	x0, [x1, #0xcb8]
   1f2cc:      	ldr	x0, [x19, #0x5c20]
   1f2d0:      	str	x0, [x1, #0xcc0]
   1f2d4:      	mov	x1, #0x530              ; =1328
   1f2d8:      	mov	x2, #-0x9               ; =-9
   1f2dc:      	ldr	x21, [sp, #0x198]
   1f2e0:      	ldur	x0, [sp, #0x8]
   1f2e4:      	mov	x5, x20
   1f2e8:      	ldr	x6, [sp, #0x190]
   1f2ec:      	blr	x21
   1f2f0:      	cmp	x0, #0x0
   1f2f4:      	b.ne	0x22ea0 <_mech_canonical_program_entry_v1_numeric_1282+0x5320>
   1f2f8:      	mov	x0, #0x3                ; =3
   1f2fc:      	ldr	x15, [sp, #0x180]
   1f300:      	stur	x0, [sp, #0xb8]
   1f304:      	cmp	x15, #0x2
   1f308:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   1f30c:      	mov	x5, #0x0                ; =0
   1f310:      	ldr	x3, [sp, #0x188]
   1f314:      	str	x5, [x3]
   1f318:      	ldr	x0, [x19, #0x1890]
   1f31c:      	str	x0, [x3, #0x8]
   1f320:      	mov	x1, #0x530              ; =1328
   1f324:      	ldur	x0, [sp, #0x8]
   1f328:      	ldr	x6, [sp, #0x190]
   1f32c:      	ldr	x21, [sp, #0x198]
   1f330:      	mov	x4, x20
   1f334:      	mov	x2, x5
   1f338:      	blr	x21
   1f33c:      	cmp	x0, #0x0
   1f340:      	b.ne	0x22ea8 <_mech_canonical_program_entry_v1_numeric_1282+0x5328>
   1f344:      	mov	x0, #0x3                ; =3
   1f348:      	stur	x0, [sp, #0xb8]
   1f34c:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   1f350:      	ldr	x0, [sp, #0x158]
   1f354:      	stur	x25, [sp, #0x60]
   1f358:      	ldr	x2, [x0, x1, lsl #3]
   1f35c:      	add	x4, x2, #0x1
   1f360:      	cmp	x4, x2
   1f364:      	b.lo	0x22eb0 <_mech_canonical_program_entry_v1_numeric_1282+0x5330>
   1f368:      	ldr	x0, [sp, #0x140]
   1f36c:      	cmp	x2, x0
   1f370:      	b.lo	0x1f5f8 <_mech_canonical_program_entry_v1_numeric_1282+0x1a78>
   1f374:      	b	0x22ffc <_mech_canonical_program_entry_v1_numeric_1282+0x547c>
   1f378:      	ldr	x3, [x19, #0x4c68]
   1f37c:      	ldr	x4, [x19, #0x4c70]
   1f380:      	mov	x0, #0x0                ; =0
   1f384:      	str	x0, [x19, #0x4c60]
   1f388:      	mov	x0, #0x3                ; =3
   1f38c:      	ldr	x15, [sp, #0x180]
   1f390:      	stur	x0, [sp, #0xb8]
   1f394:      	cmp	x15, #0x19a
   1f398:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   1f39c:      	ldr	x0, [x19, #0x4f70]
   1f3a0:      	ldr	x1, [sp, #0x188]
   1f3a4:      	str	x0, [x1, #0x10]
   1f3a8:      	ldr	x1, [x19, #0x4f78]
   1f3ac:      	ldr	x5, [sp, #0x188]
   1f3b0:      	str	x1, [x5, #0x18]
   1f3b4:      	ldr	x2, [x19, #0x5a20]
   1f3b8:      	ldr	x6, [sp, #0x188]
   1f3bc:      	str	x2, [x6, #0xac0]
   1f3c0:      	ldr	x8, [sp, #0x188]
   1f3c4:      	str	x0, [x8, #0x10]
   1f3c8:      	ldr	x10, [sp, #0x188]
   1f3cc:      	str	x1, [x10, #0x18]
   1f3d0:      	ldr	x0, [x19, #0x50c0]
   1f3d4:      	ldr	x13, [sp, #0x188]
   1f3d8:      	str	x0, [x13, #0x160]
   1f3dc:      	ldr	x0, [x19, #0x50c8]
   1f3e0:      	ldr	x1, [sp, #0x188]
   1f3e4:      	str	x0, [x1, #0x168]
   1f3e8:      	ldr	x0, [x19, #0x50d0]
   1f3ec:      	str	x0, [x1, #0x170]
   1f3f0:      	ldr	x0, [x19, #0x50d8]
   1f3f4:      	str	x0, [x1, #0x178]
   1f3f8:      	ldr	x0, [x19, #0x50e0]
   1f3fc:      	str	x0, [x1, #0x180]
   1f400:      	ldr	x0, [x19, #0x50e8]
   1f404:      	str	x0, [x1, #0x188]
   1f408:      	ldr	x0, [x19, #0x50f0]
   1f40c:      	str	x0, [x1, #0x190]
   1f410:      	ldr	x0, [x19, #0x50f8]
   1f414:      	str	x0, [x1, #0x198]
   1f418:      	ldr	x0, [x19, #0x5100]
   1f41c:      	str	x0, [x1, #0x1a0]
   1f420:      	ldr	x0, [x19, #0x52a8]
   1f424:      	str	x0, [x1, #0x348]
   1f428:      	ldr	x0, [x19, #0x52b0]
   1f42c:      	str	x0, [x1, #0x350]
   1f430:      	ldr	x0, [x19, #0x52b8]
   1f434:      	str	x0, [x1, #0x358]
   1f438:      	ldr	x0, [x19, #0x52c0]
   1f43c:      	str	x0, [x1, #0x360]
   1f440:      	ldr	x0, [x19, #0x52c8]
   1f444:      	str	x0, [x1, #0x368]
   1f448:      	ldr	x0, [x19, #0x52d0]
   1f44c:      	str	x0, [x1, #0x370]
   1f450:      	ldr	x0, [x19, #0x52d8]
   1f454:      	str	x0, [x1, #0x378]
   1f458:      	ldr	x0, [x19, #0x52e0]
   1f45c:      	str	x0, [x1, #0x380]
   1f460:      	ldr	x0, [x19, #0x52e8]
   1f464:      	str	x0, [x1, #0x388]
   1f468:      	ldr	x0, [x19, #0x55d8]
   1f46c:      	str	x0, [x5, #0x678]
   1f470:      	ldr	x0, [x19, #0x55e0]
   1f474:      	ldr	x7, [sp, #0x188]
   1f478:      	str	x0, [x7, #0x680]
   1f47c:      	ldr	x0, [x19, #0x55e8]
   1f480:      	str	x0, [x10, #0x688]
   1f484:      	ldr	x0, [x19, #0x55f0]
   1f488:      	str	x0, [x13, #0x690]
   1f48c:      	ldr	x0, [x19, #0x55f8]
   1f490:      	str	x0, [x1, #0x698]
   1f494:      	ldr	x0, [x19, #0x5600]
   1f498:      	str	x0, [x1, #0x6a0]
   1f49c:      	ldr	x0, [x19, #0x5608]
   1f4a0:      	str	x0, [x1, #0x6a8]
   1f4a4:      	ldr	x0, [x19, #0x5610]
   1f4a8:      	str	x0, [x1, #0x6b0]
   1f4ac:      	ldr	x0, [x19, #0x57a0]
   1f4b0:      	str	x0, [x1, #0x840]
   1f4b4:      	ldr	x0, [x19, #0x57a8]
   1f4b8:      	str	x0, [x1, #0x848]
   1f4bc:      	ldr	x0, [x19, #0x57b0]
   1f4c0:      	str	x0, [x1, #0x850]
   1f4c4:      	ldr	x0, [x19, #0x57b8]
   1f4c8:      	str	x0, [x1, #0x858]
   1f4cc:      	ldr	x1, [x19, #0x57c0]
   1f4d0:      	ldr	x0, [sp, #0x188]
   1f4d4:      	str	x1, [x0, #0x860]
   1f4d8:      	ldr	x2, [x19, #0x57c8]
   1f4dc:      	str	x2, [x0, #0x868]
   1f4e0:      	ldr	x5, [x19, #0x57d0]
   1f4e4:      	str	x5, [x0, #0x870]
   1f4e8:      	ldr	x5, [x19, #0x57d8]
   1f4ec:      	str	x5, [x0, #0x878]
   1f4f0:      	ldr	x5, [x19, #0x5bb0]
   1f4f4:      	str	x5, [x0, #0xc50]
   1f4f8:      	ldr	x6, [x19, #0x5bb8]
   1f4fc:      	str	x6, [x0, #0xc58]
   1f500:      	ldr	x7, [x19, #0x5bc0]
   1f504:      	str	x7, [x0, #0xc60]
   1f508:      	ldr	x8, [x19, #0x5bc8]
   1f50c:      	str	x8, [x0, #0xc68]
   1f510:      	ldr	x9, [x19, #0x5bd0]
   1f514:      	ldr	x1, [sp, #0x188]
   1f518:      	str	x9, [x1, #0xc70]
   1f51c:      	ldr	x10, [x19, #0x5bd8]
   1f520:      	ldr	x5, [sp, #0x188]
   1f524:      	str	x10, [x5, #0xc78]
   1f528:      	mov	x11, #0x0               ; =0
   1f52c:      	ldr	x7, [sp, #0x188]
   1f530:      	str	x11, [x7, #0xc80]
   1f534:      	ldr	x12, [x19, #0x5be8]
   1f538:      	ldr	x10, [sp, #0x188]
   1f53c:      	str	x12, [x10, #0xc88]
   1f540:      	ldr	x13, [x19, #0x5bf0]
   1f544:      	ldr	x14, [sp, #0x188]
   1f548:      	str	x13, [x14, #0xc90]
   1f54c:      	ldr	x15, [sp, #0x188]
   1f550:      	str	x11, [x15, #0xc98]
   1f554:      	ldr	x15, [x19, #0x5c00]
   1f558:      	str	x15, [x0, #0xca0]
   1f55c:      	ldr	x0, [x19, #0x5c08]
   1f560:      	str	x0, [x1, #0xca8]
   1f564:      	ldr	x0, [sp, #0x188]
   1f568:      	str	x11, [x0, #0xcb0]
   1f56c:      	ldr	x0, [x19, #0x5c18]
   1f570:      	str	x0, [x1, #0xcb8]
   1f574:      	ldr	x0, [x19, #0x5c20]
   1f578:      	str	x0, [x1, #0xcc0]
   1f57c:      	mov	x1, #0x532              ; =1330
   1f580:      	mov	x2, #-0x9               ; =-9
   1f584:      	ldr	x21, [sp, #0x198]
   1f588:      	ldur	x0, [sp, #0x8]
   1f58c:      	mov	x5, x20
   1f590:      	ldr	x6, [sp, #0x190]
   1f594:      	blr	x21
   1f598:      	cmp	x0, #0x0
   1f59c:      	b.ne	0x23190 <_mech_canonical_program_entry_v1_numeric_1282+0x5610>
   1f5a0:      	mov	x0, #0x3                ; =3
   1f5a4:      	ldr	x15, [sp, #0x180]
   1f5a8:      	stur	x0, [sp, #0xb8]
   1f5ac:      	cmp	x15, #0x2
   1f5b0:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   1f5b4:      	mov	x5, #0x0                ; =0
   1f5b8:      	ldr	x3, [sp, #0x188]
   1f5bc:      	str	x5, [x3]
   1f5c0:      	ldr	x0, [x19, #0x18a0]
   1f5c4:      	str	x0, [x3, #0x8]
   1f5c8:      	mov	x1, #0x532              ; =1330
   1f5cc:      	ldur	x0, [sp, #0x8]
   1f5d0:      	ldr	x6, [sp, #0x190]
   1f5d4:      	ldr	x21, [sp, #0x198]
   1f5d8:      	mov	x4, x20
   1f5dc:      	mov	x2, x5
   1f5e0:      	blr	x21
   1f5e4:      	cmp	x0, #0x0
   1f5e8:      	b.ne	0x23198 <_mech_canonical_program_entry_v1_numeric_1282+0x5618>
   1f5ec:      	mov	x0, #0x3                ; =3
   1f5f0:      	stur	x0, [sp, #0xb8]
   1f5f4:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   1f5f8:      	ldr	x0, [sp, #0x148]
   1f5fc:      	stur	x1, [sp, #0x18]
   1f600:      	stur	x27, [sp, #0x58]
   1f604:      	ldr	x27, [x0, x2, lsl #3]
   1f608:      	ldr	x0, [sp, #0x140]
   1f60c:      	cmp	x4, x0
   1f610:      	b.lo	0x1f898 <_mech_canonical_program_entry_v1_numeric_1282+0x1d18>
   1f614:      	b	0x231a0 <_mech_canonical_program_entry_v1_numeric_1282+0x5620>
   1f618:      	ldr	x3, [x19, #0x4c68]
   1f61c:      	ldr	x4, [x19, #0x4c70]
   1f620:      	mov	x0, #0x0                ; =0
   1f624:      	str	x0, [x19, #0x4c60]
   1f628:      	mov	x0, #0x3                ; =3
   1f62c:      	ldr	x15, [sp, #0x180]
   1f630:      	stur	x0, [sp, #0xb8]
   1f634:      	cmp	x15, #0x19a
   1f638:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   1f63c:      	ldr	x0, [x19, #0x4f70]
   1f640:      	ldr	x1, [sp, #0x188]
   1f644:      	str	x0, [x1, #0x10]
   1f648:      	ldr	x1, [x19, #0x4f78]
   1f64c:      	ldr	x2, [sp, #0x188]
   1f650:      	str	x1, [x2, #0x18]
   1f654:      	ldr	x2, [x19, #0x5a20]
   1f658:      	ldr	x5, [sp, #0x188]
   1f65c:      	str	x2, [x5, #0xac0]
   1f660:      	ldr	x2, [sp, #0x188]
   1f664:      	str	x0, [x2, #0x10]
   1f668:      	ldr	x0, [sp, #0x188]
   1f66c:      	str	x1, [x0, #0x18]
   1f670:      	ldr	x0, [x19, #0x50c0]
   1f674:      	ldr	x1, [sp, #0x188]
   1f678:      	str	x0, [x1, #0x160]
   1f67c:      	ldr	x0, [x19, #0x50c8]
   1f680:      	str	x0, [x1, #0x168]
   1f684:      	ldr	x0, [x19, #0x50d0]
   1f688:      	str	x0, [x1, #0x170]
   1f68c:      	ldr	x0, [x19, #0x50d8]
   1f690:      	str	x0, [x1, #0x178]
   1f694:      	ldr	x0, [x19, #0x50e0]
   1f698:      	str	x0, [x1, #0x180]
   1f69c:      	ldr	x0, [x19, #0x50e8]
   1f6a0:      	str	x0, [x1, #0x188]
   1f6a4:      	ldr	x0, [x19, #0x50f0]
   1f6a8:      	str	x0, [x1, #0x190]
   1f6ac:      	ldr	x0, [x19, #0x50f8]
   1f6b0:      	str	x0, [x1, #0x198]
   1f6b4:      	ldr	x0, [x19, #0x5100]
   1f6b8:      	str	x0, [x1, #0x1a0]
   1f6bc:      	ldr	x0, [x19, #0x52a8]
   1f6c0:      	str	x0, [x5, #0x348]
   1f6c4:      	ldr	x0, [x19, #0x52b0]
   1f6c8:      	ldr	x7, [sp, #0x188]
   1f6cc:      	str	x0, [x7, #0x350]
   1f6d0:      	ldr	x0, [x19, #0x52b8]
   1f6d4:      	ldr	x10, [sp, #0x188]
   1f6d8:      	str	x0, [x10, #0x358]
   1f6dc:      	ldr	x0, [x19, #0x52c0]
   1f6e0:      	ldr	x13, [sp, #0x188]
   1f6e4:      	str	x0, [x13, #0x360]
   1f6e8:      	ldr	x0, [x19, #0x52c8]
   1f6ec:      	str	x0, [x1, #0x368]
   1f6f0:      	ldr	x0, [x19, #0x52d0]
   1f6f4:      	str	x0, [x1, #0x370]
   1f6f8:      	ldr	x0, [x19, #0x52d8]
   1f6fc:      	str	x0, [x1, #0x378]
   1f700:      	ldr	x0, [x19, #0x52e0]
   1f704:      	str	x0, [x1, #0x380]
   1f708:      	ldr	x0, [x19, #0x52e8]
   1f70c:      	str	x0, [x1, #0x388]
   1f710:      	ldr	x0, [x19, #0x55d8]
   1f714:      	str	x0, [x1, #0x678]
   1f718:      	ldr	x0, [x19, #0x55e0]
   1f71c:      	str	x0, [x1, #0x680]
   1f720:      	ldr	x0, [x19, #0x55e8]
   1f724:      	str	x0, [x1, #0x688]
   1f728:      	ldr	x0, [x19, #0x55f0]
   1f72c:      	str	x0, [x1, #0x690]
   1f730:      	ldr	x0, [x19, #0x55f8]
   1f734:      	str	x0, [x1, #0x698]
   1f738:      	ldr	x0, [x19, #0x5600]
   1f73c:      	str	x0, [x1, #0x6a0]
   1f740:      	ldr	x1, [x19, #0x5608]
   1f744:      	ldr	x0, [sp, #0x188]
   1f748:      	str	x1, [x0, #0x6a8]
   1f74c:      	ldr	x2, [x19, #0x5610]
   1f750:      	str	x2, [x0, #0x6b0]
   1f754:      	ldr	x5, [x19, #0x57a0]
   1f758:      	str	x5, [x0, #0x840]
   1f75c:      	ldr	x5, [x19, #0x57a8]
   1f760:      	str	x5, [x0, #0x848]
   1f764:      	ldr	x5, [x19, #0x57b0]
   1f768:      	str	x5, [x0, #0x850]
   1f76c:      	ldr	x6, [x19, #0x57b8]
   1f770:      	ldr	x1, [sp, #0x188]
   1f774:      	str	x6, [x1, #0x858]
   1f778:      	ldr	x7, [x19, #0x57c0]
   1f77c:      	ldr	x5, [sp, #0x188]
   1f780:      	str	x7, [x5, #0x860]
   1f784:      	ldr	x8, [x19, #0x57c8]
   1f788:      	ldr	x7, [sp, #0x188]
   1f78c:      	str	x8, [x7, #0x868]
   1f790:      	ldr	x9, [x19, #0x57d0]
   1f794:      	str	x9, [x10, #0x870]
   1f798:      	ldr	x10, [x19, #0x57d8]
   1f79c:      	str	x10, [x13, #0x878]
   1f7a0:      	ldr	x11, [x19, #0x5bb0]
   1f7a4:      	str	x11, [x0, #0xc50]
   1f7a8:      	ldr	x12, [x19, #0x5bb8]
   1f7ac:      	str	x12, [x0, #0xc58]
   1f7b0:      	ldr	x13, [x19, #0x5bc0]
   1f7b4:      	str	x13, [x0, #0xc60]
   1f7b8:      	ldr	x14, [x19, #0x5bc8]
   1f7bc:      	str	x14, [x0, #0xc68]
   1f7c0:      	ldr	x15, [x19, #0x5bd0]
   1f7c4:      	str	x15, [x0, #0xc70]
   1f7c8:      	ldr	x0, [x19, #0x5bd8]
   1f7cc:      	str	x0, [x1, #0xc78]
   1f7d0:      	mov	x0, #0x0                ; =0
   1f7d4:      	str	x0, [x1, #0xc80]
   1f7d8:      	ldr	x1, [x19, #0x5be8]
   1f7dc:      	ldr	x2, [sp, #0x188]
   1f7e0:      	str	x1, [x2, #0xc88]
   1f7e4:      	ldr	x1, [x19, #0x5bf0]
   1f7e8:      	str	x1, [x2, #0xc90]
   1f7ec:      	ldr	x1, [sp, #0x188]
   1f7f0:      	str	x0, [x1, #0xc98]
   1f7f4:      	ldr	x1, [x19, #0x5c00]
   1f7f8:      	str	x1, [x2, #0xca0]
   1f7fc:      	ldr	x1, [x19, #0x5c08]
   1f800:      	str	x1, [x2, #0xca8]
   1f804:      	ldr	x1, [sp, #0x188]
   1f808:      	str	x0, [x1, #0xcb0]
   1f80c:      	ldr	x0, [x19, #0x5c18]
   1f810:      	str	x0, [x1, #0xcb8]
   1f814:      	ldr	x0, [x19, #0x5c20]
   1f818:      	str	x0, [x1, #0xcc0]
   1f81c:      	mov	x1, #0x534              ; =1332
   1f820:      	mov	x2, #-0x9               ; =-9
   1f824:      	ldr	x21, [sp, #0x198]
   1f828:      	ldur	x0, [sp, #0x8]
   1f82c:      	mov	x5, x20
   1f830:      	ldr	x6, [sp, #0x190]
   1f834:      	blr	x21
   1f838:      	cmp	x0, #0x0
   1f83c:      	b.ne	0x23344 <_mech_canonical_program_entry_v1_numeric_1282+0x57c4>
   1f840:      	mov	x0, #0x3                ; =3
   1f844:      	ldr	x15, [sp, #0x180]
   1f848:      	stur	x0, [sp, #0xb8]
   1f84c:      	cmp	x15, #0x2
   1f850:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   1f854:      	mov	x5, #0x0                ; =0
   1f858:      	ldr	x3, [sp, #0x188]
   1f85c:      	str	x5, [x3]
   1f860:      	ldr	x0, [x19, #0x18b0]
   1f864:      	str	x0, [x3, #0x8]
   1f868:      	mov	x1, #0x534              ; =1332
   1f86c:      	ldur	x0, [sp, #0x8]
   1f870:      	ldr	x6, [sp, #0x190]
   1f874:      	ldr	x21, [sp, #0x198]
   1f878:      	mov	x4, x20
   1f87c:      	mov	x2, x5
   1f880:      	blr	x21
   1f884:      	cmp	x0, #0x0
   1f888:      	b.ne	0x2334c <_mech_canonical_program_entry_v1_numeric_1282+0x57cc>
   1f88c:      	mov	x0, #0x3                ; =3
   1f890:      	stur	x0, [sp, #0xb8]
   1f894:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   1f898:      	ldr	x5, [sp, #0x148]
   1f89c:      	ldr	x5, [x5, x4, lsl #3]
   1f8a0:      	mov	w0, #0x2166             ; =8550
   1f8a4:      	movk	w0, #0x1, lsl #16
   1f8a8:      	sub	x9, x3, x0
   1f8ac:      	mov	x3, #0x0                ; =0
   1f8b0:      	ldur	x6, [sp, #0x60]
   1f8b4:      	ldur	x7, [sp, #0x58]
   1f8b8:      	ldur	x15, [sp, #0x10]
   1f8bc:      	ldur	x0, [sp, #0x68]
   1f8c0:      	stur	x0, [sp, #0x28]
   1f8c4:      	ldur	x0, [sp, #0x70]
   1f8c8:      	stur	x0, [sp, #0x30]
   1f8cc:      	mov	w0, #0xdc1e             ; =56350
   1f8d0:      	movk	w0, #0x2, lsl #16
   1f8d4:      	cmp	x9, x0
   1f8d8:      	b.hs	0x1fd14 <_mech_canonical_program_entry_v1_numeric_1282+0x2194>
   1f8dc:      	mov	x1, #0x0                ; =0
   1f8e0:      	str	x1, [x19, #0x18]
   1f8e4:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   1f8e8:      	str	x0, [x19, #0x20]
   1f8ec:      	mov	x0, #0x1                ; =1
   1f8f0:      	str	x0, [x19, #0x30]
   1f8f4:      	mov	x2, #0x101010101010101  ; =72340172838076673
   1f8f8:      	str	x2, [x19, #0x38]
   1f8fc:      	mov	x20, #0x2               ; =2
   1f900:      	str	x20, [x19, #0x40]
   1f904:      	mov	x2, #0x3                ; =3
   1f908:      	str	x2, [x19, #0x48]
   1f90c:      	mov	x2, #0x4                ; =4
   1f910:      	str	x2, [x19, #0x50]
   1f914:      	mov	x2, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   1f918:      	str	x2, [x19, #0x78]
   1f91c:      	mov	x2, #0x3333333333333333 ; =3689348814741910323
   1f920:      	str	x2, [x19, #0x88]
   1f924:      	mov	x2, #0x38               ; =56
   1f928:      	str	x2, [x19, #0x90]
   1f92c:      	mov	x2, #0x3a               ; =58
   1f930:      	str	x2, [x19, #0x98]
   1f934:      	mov	x2, #0x5555555555555555 ; =6148914691236517205
   1f938:      	str	x2, [x19, #0xb0]
   1f93c:      	mov	x2, #0x3ffffffffffffff  ; =288230376151711743
   1f940:      	str	x2, [x19, #0xb8]
   1f944:      	str	x1, [x19, #0x188]
   1f948:      	str	x0, [x19, #0x190]
   1f94c:      	str	x22, [x19, #0x17a0]
   1f950:      	str	x23, [x19, #0x17a8]
   1f954:      	ldur	x24, [sp, #0xe0]
   1f958:      	uxtb	w4, w24
   1f95c:      	str	x4, [x19, #0x17b8]
   1f960:      	ldur	x1, [sp, #0x18]
   1f964:      	str	x1, [x19, #0x1858]
   1f968:      	mov	x1, x26
   1f96c:      	str	x1, [x19, #0x1860]
   1f970:      	str	x22, [x19, #0x1868]
   1f974:      	ldur	x14, [sp, #0xd0]
   1f978:      	str	x14, [x19, #0x1870]
   1f97c:      	ldur	x1, [sp, #0xc8]
   1f980:      	uxtb	w14, w1
   1f984:      	str	x14, [x19, #0x1880]
   1f988:      	str	x10, [x19, #0x4c60]
   1f98c:      	str	x9, [x19, #0x4c68]
   1f990:      	ldur	x4, [sp, #0x80]
   1f994:      	str	x4, [x19, #0x4c70]
   1f998:      	str	x22, [x19, #0x4f70]
   1f99c:      	str	x23, [x19, #0x4f78]
   1f9a0:      	ldur	x10, [sp, #0x18]
   1f9a4:      	str	x10, [x19, #0x50c0]
   1f9a8:      	mov	x14, x26
   1f9ac:      	str	x14, [x19, #0x50c8]
   1f9b0:      	str	x22, [x19, #0x50d0]
   1f9b4:      	ldur	x1, [sp, #0xd0]
   1f9b8:      	str	x1, [x19, #0x50d8]
   1f9bc:      	ldur	x25, [sp, #0x10]
   1f9c0:      	str	x25, [x19, #0x50e0]
   1f9c4:      	ldur	x24, [sp, #0x58]
   1f9c8:      	str	x24, [x19, #0x50e8]
   1f9cc:      	ldur	x1, [sp, #0x60]
   1f9d0:      	str	x1, [x19, #0x50f0]
   1f9d4:      	ldur	x25, [sp, #0x68]
   1f9d8:      	str	x25, [x19, #0x50f8]
   1f9dc:      	ldur	x26, [sp, #0x70]
   1f9e0:      	str	x26, [x19, #0x5100]
   1f9e4:      	ldur	x25, [sp, #0x10]
   1f9e8:      	str	x25, [x19, #0x5178]
   1f9ec:      	str	x24, [x19, #0x5180]
   1f9f0:      	ldur	x1, [sp, #0x60]
   1f9f4:      	str	x1, [x19, #0x5188]
   1f9f8:      	ldur	x25, [sp, #0x68]
   1f9fc:      	str	x25, [x19, #0x5190]
   1fa00:      	str	x26, [x19, #0x5198]
   1fa04:      	str	x27, [x19, #0x52a8]
   1fa08:      	str	x5, [x19, #0x52b0]
   1fa0c:      	str	x22, [x19, #0x52b8]
   1fa10:      	ldur	x1, [sp, #0xd0]
   1fa14:      	str	x1, [x19, #0x52c0]
   1fa18:      	str	x15, [x19, #0x52c8]
   1fa1c:      	mov	x15, x7
   1fa20:      	str	x15, [x19, #0x52d0]
   1fa24:      	mov	x25, x6
   1fa28:      	str	x25, [x19, #0x52d8]
   1fa2c:      	ldur	x25, [sp, #0x28]
   1fa30:      	str	x25, [x19, #0x52e0]
   1fa34:      	ldur	x15, [sp, #0x30]
   1fa38:      	str	x15, [x19, #0x52e8]
   1fa3c:      	ldur	x1, [sp, #0x50]
   1fa40:      	str	x1, [x19, #0x5a20]
   1fa44:      	add	x1, x8, #0x1
   1fa48:      	str	x1, [x19, #0x5bb0]
   1fa4c:      	ldur	x26, [sp, #0x88]
   1fa50:      	str	x26, [x19, #0x5bb8]
   1fa54:      	ldur	x6, [sp, #0x90]
   1fa58:      	str	x6, [x19, #0x5bc0]
   1fa5c:      	ldur	x4, [sp, #0x78]
   1fa60:      	sub	x2, x4, x9
   1fa64:      	mov	w4, #0xc87e             ; =51326
   1fa68:      	movk	w4, #0x1, lsl #16
   1fa6c:      	msub	x1, x1, x4, x2
   1fa70:      	str	x1, [x19, #0x5bc8]
   1fa74:      	str	x0, [x19, #0x5bd0]
   1fa78:      	ldur	x24, [sp, #0x20]
   1fa7c:      	str	x24, [x19, #0x5bd8]
   1fa80:      	str	x0, [x19, #0x5be8]
   1fa84:      	str	x3, [x19, #0x5bf0]
   1fa88:      	str	x12, [x19, #0x5c00]
   1fa8c:      	str	x11, [x19, #0x5c08]
   1fa90:      	str	x13, [x19, #0x5c18]
   1fa94:      	ldur	x13, [sp, #0xa8]
   1fa98:      	str	x13, [x19, #0x5c20]
   1fa9c:      	ldr	x0, [x19, #0x4c60]
   1faa0:      	cmp	x0, #0x0
   1faa4:      	b.eq	0x1fcec <_mech_canonical_program_entry_v1_numeric_1282+0x216c>
   1faa8:      	ldr	x3, [x19, #0x4c68]
   1faac:      	ldr	x4, [x19, #0x4c70]
   1fab0:      	mov	x0, #0x0                ; =0
   1fab4:      	str	x0, [x19, #0x4c60]
   1fab8:      	mov	x0, #0x3                ; =3
   1fabc:      	ldr	x15, [sp, #0x180]
   1fac0:      	stur	x0, [sp, #0xb8]
   1fac4:      	cmp	x15, #0x19a
   1fac8:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   1facc:      	ldr	x0, [x19, #0x4f70]
   1fad0:      	ldr	x9, [sp, #0x188]
   1fad4:      	str	x0, [x9, #0x10]
   1fad8:      	ldr	x1, [x19, #0x4f78]
   1fadc:      	ldr	x12, [sp, #0x188]
   1fae0:      	str	x1, [x12, #0x18]
   1fae4:      	ldr	x2, [x19, #0x5a20]
   1fae8:      	ldr	x15, [sp, #0x188]
   1faec:      	str	x2, [x15, #0xac0]
   1faf0:      	ldr	x2, [x19, #0x5178]
   1faf4:      	ldr	x5, [sp, #0x188]
   1faf8:      	str	x2, [x5, #0x218]
   1fafc:      	ldr	x2, [x19, #0x5180]
   1fb00:      	str	x2, [x5, #0x220]
   1fb04:      	ldr	x2, [x19, #0x5188]
   1fb08:      	str	x2, [x5, #0x228]
   1fb0c:      	ldr	x2, [x19, #0x5190]
   1fb10:      	str	x2, [x5, #0x230]
   1fb14:      	ldr	x2, [x19, #0x5198]
   1fb18:      	str	x2, [x5, #0x238]
   1fb1c:      	ldr	x2, [sp, #0x188]
   1fb20:      	str	x0, [x2, #0x10]
   1fb24:      	ldr	x0, [sp, #0x188]
   1fb28:      	str	x1, [x0, #0x18]
   1fb2c:      	ldr	x5, [x19, #0x50c0]
   1fb30:      	str	x5, [x0, #0x160]
   1fb34:      	ldr	x6, [x19, #0x50c8]
   1fb38:      	str	x6, [x0, #0x168]
   1fb3c:      	ldr	x7, [x19, #0x50d0]
   1fb40:      	str	x7, [x0, #0x170]
   1fb44:      	ldr	x8, [x19, #0x50d8]
   1fb48:      	str	x8, [x0, #0x178]
   1fb4c:      	ldr	x9, [x19, #0x50e0]
   1fb50:      	str	x9, [x0, #0x180]
   1fb54:      	ldr	x10, [x19, #0x50e8]
   1fb58:      	str	x10, [x0, #0x188]
   1fb5c:      	ldr	x11, [x19, #0x50f0]
   1fb60:      	str	x11, [x0, #0x190]
   1fb64:      	ldr	x12, [x19, #0x50f8]
   1fb68:      	str	x12, [x0, #0x198]
   1fb6c:      	ldr	x13, [x19, #0x5100]
   1fb70:      	str	x13, [x0, #0x1a0]
   1fb74:      	ldr	x14, [x19, #0x52a8]
   1fb78:      	ldr	x1, [sp, #0x188]
   1fb7c:      	str	x14, [x1, #0x348]
   1fb80:      	ldr	x15, [x19, #0x52b0]
   1fb84:      	ldr	x5, [sp, #0x188]
   1fb88:      	str	x15, [x5, #0x350]
   1fb8c:      	ldr	x0, [x19, #0x52b8]
   1fb90:      	ldr	x7, [sp, #0x188]
   1fb94:      	str	x0, [x7, #0x358]
   1fb98:      	ldr	x0, [x19, #0x52c0]
   1fb9c:      	ldr	x10, [sp, #0x188]
   1fba0:      	str	x0, [x10, #0x360]
   1fba4:      	ldr	x0, [x19, #0x52c8]
   1fba8:      	ldr	x13, [sp, #0x188]
   1fbac:      	str	x0, [x13, #0x368]
   1fbb0:      	ldr	x0, [x19, #0x52d0]
   1fbb4:      	str	x0, [x1, #0x370]
   1fbb8:      	ldr	x0, [x19, #0x52d8]
   1fbbc:      	str	x0, [x1, #0x378]
   1fbc0:      	ldr	x0, [x19, #0x52e0]
   1fbc4:      	str	x0, [x1, #0x380]
   1fbc8:      	ldr	x0, [x19, #0x52e8]
   1fbcc:      	str	x0, [x1, #0x388]
   1fbd0:      	ldr	x0, [x19, #0x55d8]
   1fbd4:      	str	x0, [x1, #0x678]
   1fbd8:      	ldr	x0, [x19, #0x55e0]
   1fbdc:      	str	x0, [x1, #0x680]
   1fbe0:      	ldr	x0, [x19, #0x55e8]
   1fbe4:      	str	x0, [x1, #0x688]
   1fbe8:      	ldr	x0, [x19, #0x55f0]
   1fbec:      	str	x0, [x1, #0x690]
   1fbf0:      	ldr	x0, [x19, #0x55f8]
   1fbf4:      	str	x0, [x1, #0x698]
   1fbf8:      	ldr	x0, [x19, #0x5600]
   1fbfc:      	str	x0, [x1, #0x6a0]
   1fc00:      	ldr	x0, [x19, #0x5608]
   1fc04:      	str	x0, [x1, #0x6a8]
   1fc08:      	ldr	x0, [x19, #0x5610]
   1fc0c:      	str	x0, [x1, #0x6b0]
   1fc10:      	ldr	x0, [x19, #0x57a0]
   1fc14:      	str	x0, [x1, #0x840]
   1fc18:      	ldr	x0, [x19, #0x57a8]
   1fc1c:      	str	x0, [x1, #0x848]
   1fc20:      	ldr	x0, [x19, #0x57b0]
   1fc24:      	str	x0, [x1, #0x850]
   1fc28:      	ldr	x0, [x19, #0x57b8]
   1fc2c:      	str	x0, [x1, #0x858]
   1fc30:      	ldr	x0, [x19, #0x57c0]
   1fc34:      	str	x0, [x1, #0x860]
   1fc38:      	ldr	x0, [x19, #0x57c8]
   1fc3c:      	str	x0, [x5, #0x868]
   1fc40:      	ldr	x0, [x19, #0x57d0]
   1fc44:      	str	x0, [x7, #0x870]
   1fc48:      	ldr	x0, [x19, #0x57d8]
   1fc4c:      	str	x0, [x10, #0x878]
   1fc50:      	ldr	x0, [x19, #0x5bb0]
   1fc54:      	str	x0, [x13, #0xc50]
   1fc58:      	ldr	x0, [x19, #0x5bb8]
   1fc5c:      	str	x0, [x1, #0xc58]
   1fc60:      	ldr	x0, [x19, #0x5bc0]
   1fc64:      	str	x0, [x1, #0xc60]
   1fc68:      	ldr	x0, [x19, #0x5bc8]
   1fc6c:      	str	x0, [x1, #0xc68]
   1fc70:      	ldr	x0, [x19, #0x5bd0]
   1fc74:      	str	x0, [x1, #0xc70]
   1fc78:      	ldr	x0, [x19, #0x5bd8]
   1fc7c:      	str	x0, [x1, #0xc78]
   1fc80:      	mov	x0, #0x0                ; =0
   1fc84:      	str	x0, [x1, #0xc80]
   1fc88:      	ldr	x1, [x19, #0x5be8]
   1fc8c:      	str	x1, [x2, #0xc88]
   1fc90:      	ldr	x1, [x19, #0x5bf0]
   1fc94:      	str	x1, [x2, #0xc90]
   1fc98:      	ldr	x1, [sp, #0x188]
   1fc9c:      	str	x0, [x1, #0xc98]
   1fca0:      	ldr	x1, [x19, #0x5c00]
   1fca4:      	str	x1, [x2, #0xca0]
   1fca8:      	ldr	x1, [x19, #0x5c08]
   1fcac:      	str	x1, [x2, #0xca8]
   1fcb0:      	ldr	x1, [sp, #0x188]
   1fcb4:      	str	x0, [x1, #0xcb0]
   1fcb8:      	ldr	x0, [x19, #0x5c18]
   1fcbc:      	str	x0, [x1, #0xcb8]
   1fcc0:      	ldr	x0, [x19, #0x5c20]
   1fcc4:      	str	x0, [x1, #0xcc0]
   1fcc8:      	mov	x1, #0x53d              ; =1341
   1fccc:      	mov	x2, #-0x9               ; =-9
   1fcd0:      	mov	x5, #0x1                ; =1
   1fcd4:      	ldur	x0, [sp, #0x8]
   1fcd8:      	ldr	x6, [sp, #0x190]
   1fcdc:      	ldr	x21, [sp, #0x198]
   1fce0:      	blr	x21
   1fce4:      	cmp	x0, #0x0
   1fce8:      	b.ne	0x23354 <_mech_canonical_program_entry_v1_numeric_1282+0x57d4>
   1fcec:      	mov	x0, #0x0                ; =0
   1fcf0:      	mov	x1, #0x3                ; =3
   1fcf4:      	add	sp, sp, #0x1b0
   1fcf8:      	ldp	x19, x20, [sp], #0x10
   1fcfc:      	ldp	x21, x22, [sp], #0x10
   1fd00:      	ldp	x23, x24, [sp], #0x10
   1fd04:      	ldp	x25, x26, [sp], #0x10
   1fd08:      	ldp	x27, x28, [sp], #0x10
   1fd0c:      	ldp	x29, x30, [sp], #0x10
   1fd10:      	retab
   1fd14:      	mov	x25, x6
   1fd18:      	mov	x2, x15
   1fd1c:      	mov	x15, x7
   1fd20:      	cmp	x27, x5
   1fd24:      	cset	x7, lo
   1fd28:      	cmp	x27, x5
   1fd2c:      	b.lo	0x1fd54 <_mech_canonical_program_entry_v1_numeric_1282+0x21d4>
   1fd30:      	ldur	x0, [sp, #0x30]
   1fd34:      	ldur	x1, [sp, #0x28]
   1fd38:      	mov	x4, x27
   1fd3c:      	ldur	x6, [sp, #0x30]
   1fd40:      	ldur	x7, [sp, #0x28]
   1fd44:      	mov	x20, x25
   1fd48:      	mov	x24, x15
   1fd4c:      	stur	x2, [sp, #0x38]
   1fd50:      	b	0x203e8 <_mech_canonical_program_entry_v1_numeric_1282+0x2868>
   1fd54:      	ldr	x1, [sp, #0x130]
   1fd58:      	cmp	x27, x1
   1fd5c:      	b.lo	0x1ffdc <_mech_canonical_program_entry_v1_numeric_1282+0x245c>
   1fd60:      	b	0x2335c <_mech_canonical_program_entry_v1_numeric_1282+0x57dc>
   1fd64:      	ldr	x3, [x19, #0x4c68]
   1fd68:      	ldr	x4, [x19, #0x4c70]
   1fd6c:      	mov	x0, #0x0                ; =0
   1fd70:      	str	x0, [x19, #0x4c60]
   1fd74:      	mov	x0, #0x3                ; =3
   1fd78:      	ldr	x15, [sp, #0x180]
   1fd7c:      	stur	x0, [sp, #0xb8]
   1fd80:      	cmp	x15, #0x19a
   1fd84:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   1fd88:      	ldr	x0, [x19, #0x4f70]
   1fd8c:      	ldr	x5, [sp, #0x188]
   1fd90:      	str	x0, [x5, #0x10]
   1fd94:      	ldr	x1, [x19, #0x4f78]
   1fd98:      	ldr	x7, [sp, #0x188]
   1fd9c:      	str	x1, [x7, #0x18]
   1fda0:      	ldr	x2, [x19, #0x5a20]
   1fda4:      	ldr	x10, [sp, #0x188]
   1fda8:      	str	x2, [x10, #0xac0]
   1fdac:      	ldr	x12, [sp, #0x188]
   1fdb0:      	str	x0, [x12, #0x10]
   1fdb4:      	ldr	x14, [sp, #0x188]
   1fdb8:      	str	x1, [x14, #0x18]
   1fdbc:      	ldr	x0, [x19, #0x50c0]
   1fdc0:      	ldr	x1, [sp, #0x188]
   1fdc4:      	str	x0, [x1, #0x160]
   1fdc8:      	ldr	x0, [x19, #0x50c8]
   1fdcc:      	str	x0, [x1, #0x168]
   1fdd0:      	ldr	x0, [x19, #0x50d0]
   1fdd4:      	str	x0, [x1, #0x170]
   1fdd8:      	ldr	x0, [x19, #0x50d8]
   1fddc:      	str	x0, [x1, #0x178]
   1fde0:      	ldr	x0, [x19, #0x50e0]
   1fde4:      	str	x0, [x1, #0x180]
   1fde8:      	ldr	x0, [x19, #0x50e8]
   1fdec:      	str	x0, [x1, #0x188]
   1fdf0:      	ldr	x0, [x19, #0x50f0]
   1fdf4:      	str	x0, [x1, #0x190]
   1fdf8:      	ldr	x0, [x19, #0x50f8]
   1fdfc:      	str	x0, [x1, #0x198]
   1fe00:      	ldr	x0, [x19, #0x5100]
   1fe04:      	str	x0, [x1, #0x1a0]
   1fe08:      	ldr	x0, [x19, #0x52a8]
   1fe0c:      	str	x0, [x1, #0x348]
   1fe10:      	ldr	x0, [x19, #0x52b0]
   1fe14:      	str	x0, [x1, #0x350]
   1fe18:      	ldr	x0, [x19, #0x52b8]
   1fe1c:      	str	x0, [x1, #0x358]
   1fe20:      	ldr	x0, [x19, #0x52c0]
   1fe24:      	str	x0, [x1, #0x360]
   1fe28:      	ldr	x0, [x19, #0x52c8]
   1fe2c:      	str	x0, [x1, #0x368]
   1fe30:      	ldr	x0, [x19, #0x52d0]
   1fe34:      	str	x0, [x1, #0x370]
   1fe38:      	ldr	x0, [x19, #0x52d8]
   1fe3c:      	str	x0, [x1, #0x378]
   1fe40:      	ldr	x0, [x19, #0x52e0]
   1fe44:      	ldr	x2, [sp, #0x188]
   1fe48:      	str	x0, [x2, #0x380]
   1fe4c:      	ldr	x0, [x19, #0x52e8]
   1fe50:      	str	x0, [x5, #0x388]
   1fe54:      	ldr	x0, [x19, #0x55d8]
   1fe58:      	ldr	x8, [sp, #0x188]
   1fe5c:      	str	x0, [x8, #0x678]
   1fe60:      	ldr	x0, [x19, #0x55e0]
   1fe64:      	ldr	x11, [sp, #0x188]
   1fe68:      	str	x0, [x11, #0x680]
   1fe6c:      	ldr	x0, [x19, #0x55e8]
   1fe70:      	str	x0, [x14, #0x688]
   1fe74:      	ldr	x0, [x19, #0x55f0]
   1fe78:      	str	x0, [x1, #0x690]
   1fe7c:      	ldr	x0, [x19, #0x55f8]
   1fe80:      	str	x0, [x1, #0x698]
   1fe84:      	ldr	x0, [x19, #0x5600]
   1fe88:      	str	x0, [x1, #0x6a0]
   1fe8c:      	ldr	x0, [x19, #0x5608]
   1fe90:      	str	x0, [x1, #0x6a8]
   1fe94:      	ldr	x0, [x19, #0x5610]
   1fe98:      	str	x0, [x1, #0x6b0]
   1fe9c:      	ldr	x0, [x19, #0x57a0]
   1fea0:      	str	x0, [x1, #0x840]
   1fea4:      	ldr	x0, [x19, #0x57a8]
   1fea8:      	str	x0, [x1, #0x848]
   1feac:      	ldr	x0, [x19, #0x57b0]
   1feb0:      	str	x0, [x1, #0x850]
   1feb4:      	ldr	x0, [x19, #0x57b8]
   1feb8:      	str	x0, [x1, #0x858]
   1febc:      	ldr	x0, [x19, #0x57c0]
   1fec0:      	str	x0, [x1, #0x860]
   1fec4:      	ldr	x0, [x19, #0x57c8]
   1fec8:      	str	x0, [x1, #0x868]
   1fecc:      	ldr	x1, [x19, #0x57d0]
   1fed0:      	ldr	x0, [sp, #0x188]
   1fed4:      	str	x1, [x0, #0x870]
   1fed8:      	ldr	x2, [x19, #0x57d8]
   1fedc:      	str	x2, [x0, #0x878]
   1fee0:      	ldr	x5, [x19, #0x5bb0]
   1fee4:      	str	x5, [x0, #0xc50]
   1fee8:      	ldr	x5, [x19, #0x5bb8]
   1feec:      	str	x5, [x0, #0xc58]
   1fef0:      	ldr	x5, [x19, #0x5bc0]
   1fef4:      	str	x5, [x0, #0xc60]
   1fef8:      	ldr	x6, [x19, #0x5bc8]
   1fefc:      	ldr	x2, [sp, #0x188]
   1ff00:      	str	x6, [x2, #0xc68]
   1ff04:      	ldr	x7, [x19, #0x5bd0]
   1ff08:      	ldr	x5, [sp, #0x188]
   1ff0c:      	str	x7, [x5, #0xc70]
   1ff10:      	ldr	x8, [x19, #0x5bd8]
   1ff14:      	ldr	x9, [sp, #0x188]
   1ff18:      	str	x8, [x9, #0xc78]
   1ff1c:      	mov	x9, #0x0                ; =0
   1ff20:      	str	x9, [x11, #0xc80]
   1ff24:      	ldr	x10, [x19, #0x5be8]
   1ff28:      	str	x10, [x14, #0xc88]
   1ff2c:      	ldr	x11, [x19, #0x5bf0]
   1ff30:      	str	x11, [x0, #0xc90]
   1ff34:      	str	x9, [x0, #0xc98]
   1ff38:      	ldr	x13, [x19, #0x5c00]
   1ff3c:      	str	x13, [x0, #0xca0]
   1ff40:      	ldr	x14, [x19, #0x5c08]
   1ff44:      	str	x14, [x0, #0xca8]
   1ff48:      	str	x9, [x0, #0xcb0]
   1ff4c:      	ldr	x0, [x19, #0x5c18]
   1ff50:      	ldr	x1, [sp, #0x188]
   1ff54:      	str	x0, [x1, #0xcb8]
   1ff58:      	ldr	x0, [x19, #0x5c20]
   1ff5c:      	str	x0, [x1, #0xcc0]
   1ff60:      	mov	x1, #0x54e              ; =1358
   1ff64:      	mov	x2, #-0x9               ; =-9
   1ff68:      	ldr	x21, [sp, #0x198]
   1ff6c:      	ldur	x0, [sp, #0x8]
   1ff70:      	mov	x5, x24
   1ff74:      	ldr	x6, [sp, #0x190]
   1ff78:      	blr	x21
   1ff7c:      	cmp	x0, #0x0
   1ff80:      	b.ne	0x2353c <_mech_canonical_program_entry_v1_numeric_1282+0x59bc>
   1ff84:      	mov	x0, #0x3                ; =3
   1ff88:      	ldr	x15, [sp, #0x180]
   1ff8c:      	stur	x0, [sp, #0xb8]
   1ff90:      	cmp	x15, #0x2
   1ff94:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   1ff98:      	mov	x5, #0x0                ; =0
   1ff9c:      	ldr	x3, [sp, #0x188]
   1ffa0:      	str	x5, [x3]
   1ffa4:      	ldr	x0, [x19, #0x1950]
   1ffa8:      	str	x0, [x3, #0x8]
   1ffac:      	mov	x1, #0x54e              ; =1358
   1ffb0:      	ldur	x0, [sp, #0x8]
   1ffb4:      	ldr	x6, [sp, #0x190]
   1ffb8:      	ldr	x21, [sp, #0x198]
   1ffbc:      	mov	x4, x24
   1ffc0:      	mov	x2, x5
   1ffc4:      	blr	x21
   1ffc8:      	cmp	x0, #0x0
   1ffcc:      	b.ne	0x23544 <_mech_canonical_program_entry_v1_numeric_1282+0x59c4>
   1ffd0:      	mov	x0, #0x3                ; =3
   1ffd4:      	stur	x0, [sp, #0xb8]
   1ffd8:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   1ffdc:      	ldur	x0, [sp, #0x30]
   1ffe0:      	ldur	x1, [sp, #0x28]
   1ffe4:      	ldr	x4, [sp, #0x138]
   1ffe8:      	ldr	x24, [x4, x27, lsl #3]
   1ffec:      	cmp	x24, x22
   1fff0:      	b.ne	0x20010 <_mech_canonical_program_entry_v1_numeric_1282+0x2490>
   1fff4:      	mov	x4, x27
   1fff8:      	mov	x6, x0
   1fffc:      	mov	x7, x1
   20000:      	mov	x20, x25
   20004:      	mov	x24, x15
   20008:      	stur	x2, [sp, #0x38]
   2000c:      	b	0x203a0 <_mech_canonical_program_entry_v1_numeric_1282+0x2820>
   20010:      	add	x4, x24, #0x1
   20014:      	cmp	x4, x24
   20018:      	b.lo	0x2354c <_mech_canonical_program_entry_v1_numeric_1282+0x59cc>
   2001c:      	ldr	x6, [sp, #0x160]
   20020:      	cmp	x24, x6
   20024:      	b.lo	0x202b0 <_mech_canonical_program_entry_v1_numeric_1282+0x2730>
   20028:      	b	0x236b0 <_mech_canonical_program_entry_v1_numeric_1282+0x5b30>
   2002c:      	ldr	x3, [x19, #0x4c68]
   20030:      	ldr	x4, [x19, #0x4c70]
   20034:      	mov	x0, #0x0                ; =0
   20038:      	str	x0, [x19, #0x4c60]
   2003c:      	mov	x0, #0x3                ; =3
   20040:      	ldr	x15, [sp, #0x180]
   20044:      	stur	x0, [sp, #0xb8]
   20048:      	cmp	x15, #0x19a
   2004c:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   20050:      	ldr	x0, [x19, #0x4f70]
   20054:      	ldr	x1, [sp, #0x188]
   20058:      	str	x0, [x1, #0x10]
   2005c:      	ldr	x1, [x19, #0x4f78]
   20060:      	ldr	x5, [sp, #0x188]
   20064:      	str	x1, [x5, #0x18]
   20068:      	ldr	x2, [x19, #0x5a20]
   2006c:      	ldr	x6, [sp, #0x188]
   20070:      	str	x2, [x6, #0xac0]
   20074:      	ldr	x8, [sp, #0x188]
   20078:      	str	x0, [x8, #0x10]
   2007c:      	ldr	x10, [sp, #0x188]
   20080:      	str	x1, [x10, #0x18]
   20084:      	ldr	x0, [x19, #0x50c0]
   20088:      	ldr	x13, [sp, #0x188]
   2008c:      	str	x0, [x13, #0x160]
   20090:      	ldr	x0, [x19, #0x50c8]
   20094:      	ldr	x1, [sp, #0x188]
   20098:      	str	x0, [x1, #0x168]
   2009c:      	ldr	x0, [x19, #0x50d0]
   200a0:      	str	x0, [x1, #0x170]
   200a4:      	ldr	x0, [x19, #0x50d8]
   200a8:      	str	x0, [x1, #0x178]
   200ac:      	ldr	x0, [x19, #0x50e0]
   200b0:      	str	x0, [x1, #0x180]
   200b4:      	ldr	x0, [x19, #0x50e8]
   200b8:      	str	x0, [x1, #0x188]
   200bc:      	ldr	x0, [x19, #0x50f0]
   200c0:      	str	x0, [x1, #0x190]
   200c4:      	ldr	x0, [x19, #0x50f8]
   200c8:      	str	x0, [x1, #0x198]
   200cc:      	ldr	x0, [x19, #0x5100]
   200d0:      	str	x0, [x1, #0x1a0]
   200d4:      	ldr	x0, [x19, #0x52a8]
   200d8:      	str	x0, [x1, #0x348]
   200dc:      	ldr	x0, [x19, #0x52b0]
   200e0:      	str	x0, [x1, #0x350]
   200e4:      	ldr	x0, [x19, #0x52b8]
   200e8:      	str	x0, [x1, #0x358]
   200ec:      	ldr	x0, [x19, #0x52c0]
   200f0:      	str	x0, [x1, #0x360]
   200f4:      	ldr	x0, [x19, #0x52c8]
   200f8:      	str	x0, [x1, #0x368]
   200fc:      	ldr	x0, [x19, #0x52d0]
   20100:      	str	x0, [x1, #0x370]
   20104:      	ldr	x0, [x19, #0x52d8]
   20108:      	str	x0, [x1, #0x378]
   2010c:      	ldr	x0, [x19, #0x52e0]
   20110:      	str	x0, [x1, #0x380]
   20114:      	ldr	x0, [x19, #0x52e8]
   20118:      	str	x0, [x1, #0x388]
   2011c:      	ldr	x0, [x19, #0x55d8]
   20120:      	str	x0, [x5, #0x678]
   20124:      	ldr	x0, [x19, #0x55e0]
   20128:      	ldr	x7, [sp, #0x188]
   2012c:      	str	x0, [x7, #0x680]
   20130:      	ldr	x1, [x19, #0x55e8]
   20134:      	str	x1, [x10, #0x688]
   20138:      	ldr	x2, [x19, #0x55f0]
   2013c:      	str	x2, [x13, #0x690]
   20140:      	ldr	x5, [x19, #0x55f8]
   20144:      	ldr	x0, [sp, #0x188]
   20148:      	str	x5, [x0, #0x698]
   2014c:      	ldr	x5, [x19, #0x5600]
   20150:      	str	x5, [x0, #0x6a0]
   20154:      	ldr	x5, [x19, #0x5608]
   20158:      	str	x5, [x0, #0x6a8]
   2015c:      	ldr	x6, [x19, #0x5610]
   20160:      	str	x6, [x0, #0x6b0]
   20164:      	ldr	x7, [x19, #0x57a0]
   20168:      	str	x7, [x0, #0x840]
   2016c:      	ldr	x8, [x19, #0x57a8]
   20170:      	str	x8, [x0, #0x848]
   20174:      	ldr	x9, [x19, #0x57b0]
   20178:      	str	x9, [x0, #0x850]
   2017c:      	ldr	x10, [x19, #0x57b8]
   20180:      	str	x10, [x0, #0x858]
   20184:      	ldr	x11, [x19, #0x57c0]
   20188:      	str	x11, [x0, #0x860]
   2018c:      	ldr	x12, [x19, #0x57c8]
   20190:      	str	x12, [x0, #0x868]
   20194:      	ldr	x13, [x19, #0x57d0]
   20198:      	str	x13, [x0, #0x870]
   2019c:      	ldr	x14, [x19, #0x57d8]
   201a0:      	str	x14, [x0, #0x878]
   201a4:      	ldr	x15, [x19, #0x5bb0]
   201a8:      	str	x15, [x0, #0xc50]
   201ac:      	ldr	x0, [x19, #0x5bb8]
   201b0:      	ldr	x1, [sp, #0x188]
   201b4:      	str	x0, [x1, #0xc58]
   201b8:      	ldr	x0, [x19, #0x5bc0]
   201bc:      	str	x0, [x1, #0xc60]
   201c0:      	ldr	x0, [x19, #0x5bc8]
   201c4:      	str	x0, [x1, #0xc68]
   201c8:      	ldr	x0, [x19, #0x5bd0]
   201cc:      	str	x0, [x1, #0xc70]
   201d0:      	ldr	x0, [x19, #0x5bd8]
   201d4:      	ldr	x5, [sp, #0x188]
   201d8:      	str	x0, [x5, #0xc78]
   201dc:      	mov	x0, #0x0                ; =0
   201e0:      	ldr	x7, [sp, #0x188]
   201e4:      	str	x0, [x7, #0xc80]
   201e8:      	ldr	x1, [x19, #0x5be8]
   201ec:      	ldr	x10, [sp, #0x188]
   201f0:      	str	x1, [x10, #0xc88]
   201f4:      	ldr	x1, [x19, #0x5bf0]
   201f8:      	ldr	x13, [sp, #0x188]
   201fc:      	str	x1, [x13, #0xc90]
   20200:      	ldr	x15, [sp, #0x188]
   20204:      	str	x0, [x15, #0xc98]
   20208:      	ldr	x1, [x19, #0x5c00]
   2020c:      	ldr	x2, [sp, #0x188]
   20210:      	str	x1, [x2, #0xca0]
   20214:      	ldr	x1, [x19, #0x5c08]
   20218:      	str	x1, [x2, #0xca8]
   2021c:      	ldr	x1, [sp, #0x188]
   20220:      	str	x0, [x1, #0xcb0]
   20224:      	ldr	x0, [x19, #0x5c18]
   20228:      	str	x0, [x1, #0xcb8]
   2022c:      	ldr	x0, [x19, #0x5c20]
   20230:      	str	x0, [x1, #0xcc0]
   20234:      	mov	x1, #0x555              ; =1365
   20238:      	mov	x2, #-0x9               ; =-9
   2023c:      	ldr	x21, [sp, #0x198]
   20240:      	ldur	x0, [sp, #0x8]
   20244:      	mov	x5, x20
   20248:      	ldr	x6, [sp, #0x190]
   2024c:      	blr	x21
   20250:      	cmp	x0, #0x0
   20254:      	b.ne	0x2388c <_mech_canonical_program_entry_v1_numeric_1282+0x5d0c>
   20258:      	mov	x0, #0x3                ; =3
   2025c:      	ldr	x15, [sp, #0x180]
   20260:      	stur	x0, [sp, #0xb8]
   20264:      	cmp	x15, #0x2
   20268:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   2026c:      	mov	x5, #0x0                ; =0
   20270:      	ldr	x3, [sp, #0x188]
   20274:      	str	x5, [x3]
   20278:      	ldr	x0, [x19, #0x1970]
   2027c:      	str	x0, [x3, #0x8]
   20280:      	mov	x1, #0x555              ; =1365
   20284:      	ldur	x0, [sp, #0x8]
   20288:      	ldr	x6, [sp, #0x190]
   2028c:      	ldr	x21, [sp, #0x198]
   20290:      	mov	x4, x20
   20294:      	mov	x2, x5
   20298:      	blr	x21
   2029c:      	cmp	x0, #0x0
   202a0:      	b.ne	0x23894 <_mech_canonical_program_entry_v1_numeric_1282+0x5d14>
   202a4:      	mov	x0, #0x3                ; =3
   202a8:      	stur	x0, [sp, #0xb8]
   202ac:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   202b0:      	ldr	x4, [sp, #0x168]
   202b4:      	ldr	x4, [x4, x24, lsl #3]
   202b8:      	ldur	x6, [sp, #0xd0]
   202bc:      	and	x4, x6, x4
   202c0:      	fmov	d16, x4
   202c4:      	cnt.8b	v16, v16
   202c8:      	addv.8b	b16, v16
   202cc:      	umov.b	w4, v16[0]
   202d0:      	eor	x6, x24, #0x3ffffffffffffff
   202d4:      	orr	x4, x6, x4, lsl #58
   202d8:      	cmp	x4, x0
   202dc:      	cset	x6, hi
   202e0:      	cmp	x4, x2
   202e4:      	cset	x7, ne
   202e8:      	and	w6, w6, w7
   202ec:      	cmp	x4, x15
   202f0:      	cset	x7, ne
   202f4:      	and	w6, w6, w7
   202f8:      	cmp	x4, x25
   202fc:      	cset	x7, ne
   20300:      	and	w6, w6, w7
   20304:      	cmp	x4, x1
   20308:      	cset	x7, ne
   2030c:      	and	w6, w6, w7
   20310:      	uxtb	w6, w6
   20314:      	tbnz	w6, #0x0, 0x20330 <_mech_canonical_program_entry_v1_numeric_1282+0x27b0>
   20318:      	mov	x4, x15
   2031c:      	mov	x6, x2
   20320:      	mov	x7, x25
   20324:      	mov	x20, x1
   20328:      	mov	x24, x0
   2032c:      	b	0x20370 <_mech_canonical_program_entry_v1_numeric_1282+0x27f0>
   20330:      	cmp	x4, x2
   20334:      	csel	x6, x4, x2, hi
   20338:      	cmp	x4, x2
   2033c:      	csel	x7, x4, x2, lo
   20340:      	cmp	x7, x15
   20344:      	csel	x4, x7, x15, hi
   20348:      	cmp	x7, x15
   2034c:      	csel	x20, x7, x15, lo
   20350:      	cmp	x20, x25
   20354:      	csel	x7, x20, x25, hi
   20358:      	cmp	x20, x25
   2035c:      	csel	x24, x20, x25, lo
   20360:      	cmp	x24, x1
   20364:      	csel	x20, x24, x1, hi
   20368:      	cmp	x24, x1
   2036c:      	csel	x24, x24, x1, lo
   20370:      	stur	x2, [sp, #0x38]
   20374:      	mov	x2, x6
   20378:      	mov	x6, x0
   2037c:      	str	x1, [sp, #0x1a0]
   20380:      	mov	x1, x20
   20384:      	mov	x20, x25
   20388:      	mov	x25, x7
   2038c:      	ldr	x7, [sp, #0x1a0]
   20390:      	mov	x0, x24
   20394:      	mov	x24, x15
   20398:      	mov	x15, x4
   2039c:      	mov	x4, x27
   203a0:      	str	x20, [sp, #0x1a0]
   203a4:      	mov	x20, x25
   203a8:      	ldr	x25, [sp, #0x1a0]
   203ac:      	str	x15, [sp, #0x1a0]
   203b0:      	mov	x15, x24
   203b4:      	ldr	x24, [sp, #0x1a0]
   203b8:      	str	x2, [sp, #0x1a0]
   203bc:      	ldur	x2, [sp, #0x38]
   203c0:      	str	x28, [sp, #0x1a8]
   203c4:      	ldr	x28, [sp, #0x1a0]
   203c8:      	stur	x28, [sp, #0x38]
   203cc:      	str	x1, [sp, #0x1a0]
   203d0:      	mov	x1, x7
   203d4:      	ldr	x7, [sp, #0x1a0]
   203d8:      	str	x0, [sp, #0x1a0]
   203dc:      	mov	x0, x6
   203e0:      	ldr	x6, [sp, #0x1a0]
   203e4:      	ldr	x28, [sp, #0x1a8]
   203e8:      	cmp	x27, x5
   203ec:      	b.lo	0x228ec <_mech_canonical_program_entry_v1_numeric_1282+0x4d6c>
   203f0:      	mov	x5, #0x0                ; =0
   203f4:      	str	x5, [x28, #0x15d0]
   203f8:      	str	x5, [x28, #0x15d8]
   203fc:      	str	x5, [x28, #0x15e0]
   20400:      	str	x5, [x28, #0x15e8]
   20404:      	str	x5, [x28, #0x15f0]
   20408:      	str	x5, [x28, #0x15f8]
   2040c:      	str	x5, [x28, #0x1600]
   20410:      	str	x5, [x28, #0x1608]
   20414:      	str	x5, [x28, #0x1610]
   20418:      	str	x5, [x28, #0x1618]
   2041c:      	str	x5, [x28, #0x1620]
   20420:      	str	x5, [x28, #0x1628]
   20424:      	str	x5, [x28, #0x1630]
   20428:      	str	x5, [x28, #0x1638]
   2042c:      	str	x5, [x28, #0x1640]
   20430:      	str	x5, [x28, #0x1648]
   20434:      	str	x5, [x28, #0x1650]
   20438:      	str	x5, [x28, #0x1658]
   2043c:      	mov	w3, #0xdc1e             ; =56350
   20440:      	movk	w3, #0x2, lsl #16
   20444:      	sub	x3, x9, x3
   20448:      	mov	x4, #0x0                ; =0
   2044c:      	stur	x4, [sp, #0x98]
   20450:      	ldur	x4, [sp, #0x18]
   20454:      	ldur	x5, [sp, #0x98]
   20458:      	stur	x5, [sp, #0xa0]
   2045c:      	mov	x5, x26
   20460:      	ldur	x27, [sp, #0x18]
   20464:      	cmp	x27, x5
   20468:      	b.lo	0x228c0 <_mech_canonical_program_entry_v1_numeric_1282+0x4d40>
   2046c:      	mov	x0, #0x0                ; =0
   20470:      	str	x0, [x28, #0x1200]
   20474:      	str	x0, [x28, #0x1208]
   20478:      	str	x0, [x28, #0x1210]
   2047c:      	str	x0, [x28, #0x1218]
   20480:      	str	x0, [x28, #0x1220]
   20484:      	str	x0, [x28, #0x1228]
   20488:      	str	x0, [x28, #0x1230]
   2048c:      	str	x0, [x28, #0x1238]
   20490:      	str	x0, [x28, #0x1240]
   20494:      	str	x0, [x28, #0x1248]
   20498:      	str	x0, [x28, #0x1250]
   2049c:      	str	x0, [x28, #0x1258]
   204a0:      	str	x0, [x28, #0x1260]
   204a4:      	str	x0, [x28, #0x1268]
   204a8:      	str	x0, [x28, #0x1270]
   204ac:      	str	x0, [x28, #0x1278]
   204b0:      	str	x0, [x28, #0x1280]
   204b4:      	str	x0, [x28, #0x1288]
   204b8:      	ldr	x26, [sp, #0x120]
   204bc:      	cmp	x22, x26
   204c0:      	b.lo	0x20750 <_mech_canonical_program_entry_v1_numeric_1282+0x2bd0>
   204c4:      	b	0x2389c <_mech_canonical_program_entry_v1_numeric_1282+0x5d1c>
   204c8:      	ldr	x3, [x19, #0x4c68]
   204cc:      	ldr	x4, [x19, #0x4c70]
   204d0:      	mov	x0, #0x0                ; =0
   204d4:      	str	x0, [x19, #0x4c60]
   204d8:      	mov	x0, #0x3                ; =3
   204dc:      	ldr	x15, [sp, #0x180]
   204e0:      	stur	x0, [sp, #0xb8]
   204e4:      	cmp	x15, #0x19a
   204e8:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   204ec:      	ldr	x0, [x19, #0x4f70]
   204f0:      	ldr	x1, [sp, #0x188]
   204f4:      	str	x0, [x1, #0x10]
   204f8:      	ldr	x1, [x19, #0x4f78]
   204fc:      	ldr	x2, [sp, #0x188]
   20500:      	str	x1, [x2, #0x18]
   20504:      	ldr	x2, [x19, #0x5a20]
   20508:      	ldr	x5, [sp, #0x188]
   2050c:      	str	x2, [x5, #0xac0]
   20510:      	ldr	x2, [sp, #0x188]
   20514:      	str	x0, [x2, #0x10]
   20518:      	ldr	x0, [sp, #0x188]
   2051c:      	str	x1, [x0, #0x18]
   20520:      	ldr	x0, [x19, #0x50c0]
   20524:      	ldr	x1, [sp, #0x188]
   20528:      	str	x0, [x1, #0x160]
   2052c:      	ldr	x0, [x19, #0x50c8]
   20530:      	str	x0, [x1, #0x168]
   20534:      	ldr	x0, [x19, #0x50d0]
   20538:      	str	x0, [x5, #0x170]
   2053c:      	ldr	x0, [x19, #0x50d8]
   20540:      	ldr	x6, [sp, #0x188]
   20544:      	str	x0, [x6, #0x178]
   20548:      	ldr	x0, [x19, #0x50e0]
   2054c:      	ldr	x9, [sp, #0x188]
   20550:      	str	x0, [x9, #0x180]
   20554:      	ldr	x0, [x19, #0x50e8]
   20558:      	ldr	x12, [sp, #0x188]
   2055c:      	str	x0, [x12, #0x188]
   20560:      	ldr	x0, [x19, #0x50f0]
   20564:      	ldr	x15, [sp, #0x188]
   20568:      	str	x0, [x15, #0x190]
   2056c:      	ldr	x0, [x19, #0x50f8]
   20570:      	str	x0, [x1, #0x198]
   20574:      	ldr	x0, [x19, #0x5100]
   20578:      	str	x0, [x1, #0x1a0]
   2057c:      	ldr	x0, [x19, #0x52a8]
   20580:      	str	x0, [x1, #0x348]
   20584:      	ldr	x0, [x19, #0x52b0]
   20588:      	str	x0, [x1, #0x350]
   2058c:      	ldr	x0, [x19, #0x52b8]
   20590:      	str	x0, [x1, #0x358]
   20594:      	ldr	x0, [x19, #0x52c0]
   20598:      	str	x0, [x1, #0x360]
   2059c:      	ldr	x0, [x19, #0x52c8]
   205a0:      	str	x0, [x1, #0x368]
   205a4:      	ldr	x0, [x19, #0x52d0]
   205a8:      	str	x0, [x1, #0x370]
   205ac:      	ldr	x0, [x19, #0x52d8]
   205b0:      	str	x0, [x1, #0x378]
   205b4:      	ldr	x0, [x19, #0x52e0]
   205b8:      	str	x0, [x1, #0x380]
   205bc:      	ldr	x0, [x19, #0x52e8]
   205c0:      	str	x0, [x1, #0x388]
   205c4:      	ldr	x0, [x19, #0x55d8]
   205c8:      	str	x0, [x1, #0x678]
   205cc:      	ldr	x0, [x19, #0x55e0]
   205d0:      	str	x0, [x1, #0x680]
   205d4:      	ldr	x1, [x19, #0x55e8]
   205d8:      	ldr	x0, [sp, #0x188]
   205dc:      	str	x1, [x0, #0x688]
   205e0:      	ldr	x2, [x19, #0x55f0]
   205e4:      	str	x2, [x0, #0x690]
   205e8:      	ldr	x5, [x19, #0x55f8]
   205ec:      	str	x5, [x0, #0x698]
   205f0:      	ldr	x5, [x19, #0x5600]
   205f4:      	str	x5, [x6, #0x6a0]
   205f8:      	ldr	x5, [x19, #0x5608]
   205fc:      	str	x5, [x6, #0x6a8]
   20600:      	ldr	x6, [x19, #0x5610]
   20604:      	str	x6, [x9, #0x6b0]
   20608:      	ldr	x7, [x19, #0x57a0]
   2060c:      	str	x7, [x12, #0x840]
   20610:      	ldr	x8, [x19, #0x57a8]
   20614:      	str	x8, [x15, #0x848]
   20618:      	ldr	x9, [x19, #0x57b0]
   2061c:      	str	x9, [x0, #0x850]
   20620:      	ldr	x10, [x19, #0x57b8]
   20624:      	str	x10, [x0, #0x858]
   20628:      	ldr	x11, [x19, #0x57c0]
   2062c:      	str	x11, [x0, #0x860]
   20630:      	ldr	x12, [x19, #0x57c8]
   20634:      	str	x12, [x0, #0x868]
   20638:      	ldr	x13, [x19, #0x57d0]
   2063c:      	str	x13, [x0, #0x870]
   20640:      	ldr	x14, [x19, #0x57d8]
   20644:      	str	x14, [x0, #0x878]
   20648:      	ldr	x15, [x19, #0x5bb0]
   2064c:      	str	x15, [x0, #0xc50]
   20650:      	ldr	x0, [x19, #0x5bb8]
   20654:      	ldr	x1, [sp, #0x188]
   20658:      	str	x0, [x1, #0xc58]
   2065c:      	ldr	x0, [x19, #0x5bc0]
   20660:      	str	x0, [x1, #0xc60]
   20664:      	ldr	x0, [x19, #0x5bc8]
   20668:      	str	x0, [x1, #0xc68]
   2066c:      	ldr	x0, [x19, #0x5bd0]
   20670:      	str	x0, [x1, #0xc70]
   20674:      	ldr	x0, [x19, #0x5bd8]
   20678:      	str	x0, [x1, #0xc78]
   2067c:      	mov	x0, #0x0                ; =0
   20680:      	str	x0, [x1, #0xc80]
   20684:      	ldr	x1, [x19, #0x5be8]
   20688:      	ldr	x2, [sp, #0x188]
   2068c:      	str	x1, [x2, #0xc88]
   20690:      	ldr	x1, [x19, #0x5bf0]
   20694:      	str	x1, [x2, #0xc90]
   20698:      	ldr	x1, [sp, #0x188]
   2069c:      	str	x0, [x1, #0xc98]
   206a0:      	ldr	x1, [x19, #0x5c00]
   206a4:      	str	x1, [x2, #0xca0]
   206a8:      	ldr	x1, [x19, #0x5c08]
   206ac:      	ldr	x5, [sp, #0x188]
   206b0:      	str	x1, [x5, #0xca8]
   206b4:      	ldr	x7, [sp, #0x188]
   206b8:      	str	x0, [x7, #0xcb0]
   206bc:      	ldr	x0, [x19, #0x5c18]
   206c0:      	ldr	x10, [sp, #0x188]
   206c4:      	str	x0, [x10, #0xcb8]
   206c8:      	ldr	x0, [x19, #0x5c20]
   206cc:      	ldr	x13, [sp, #0x188]
   206d0:      	str	x0, [x13, #0xcc0]
   206d4:      	mov	x1, #0x5e8              ; =1512
   206d8:      	mov	x2, #-0x9               ; =-9
   206dc:      	ldr	x21, [sp, #0x198]
   206e0:      	ldur	x0, [sp, #0x8]
   206e4:      	mov	x5, x20
   206e8:      	ldr	x6, [sp, #0x190]
   206ec:      	blr	x21
   206f0:      	cmp	x0, #0x0
   206f4:      	b.ne	0x239c0 <_mech_canonical_program_entry_v1_numeric_1282+0x5e40>
   206f8:      	mov	x0, #0x3                ; =3
   206fc:      	ldr	x15, [sp, #0x180]
   20700:      	stur	x0, [sp, #0xb8]
   20704:      	cmp	x15, #0x2
   20708:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   2070c:      	mov	x5, #0x0                ; =0
   20710:      	ldr	x3, [sp, #0x188]
   20714:      	str	x5, [x3]
   20718:      	ldr	x0, [x19, #0x1c00]
   2071c:      	str	x0, [x3, #0x8]
   20720:      	mov	x1, #0x5e8              ; =1512
   20724:      	ldur	x0, [sp, #0x8]
   20728:      	ldr	x6, [sp, #0x190]
   2072c:      	ldr	x21, [sp, #0x198]
   20730:      	mov	x4, x20
   20734:      	mov	x2, x5
   20738:      	blr	x21
   2073c:      	cmp	x0, #0x0
   20740:      	b.ne	0x239c8 <_mech_canonical_program_entry_v1_numeric_1282+0x5e48>
   20744:      	mov	x0, #0x3                ; =3
   20748:      	stur	x0, [sp, #0xb8]
   2074c:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   20750:      	ldr	x26, [sp, #0x128]
   20754:      	ldr	x15, [x26, x22, lsl #3]
   20758:      	ldur	x24, [sp, #0xd8]
   2075c:      	ldr	x26, [sp, #0x120]
   20760:      	cmp	x24, x26
   20764:      	b.lo	0x209f0 <_mech_canonical_program_entry_v1_numeric_1282+0x2e70>
   20768:      	b	0x239d0 <_mech_canonical_program_entry_v1_numeric_1282+0x5e50>
   2076c:      	ldr	x3, [x19, #0x4c68]
   20770:      	ldr	x4, [x19, #0x4c70]
   20774:      	mov	x0, #0x0                ; =0
   20778:      	str	x0, [x19, #0x4c60]
   2077c:      	mov	x0, #0x3                ; =3
   20780:      	ldr	x15, [sp, #0x180]
   20784:      	stur	x0, [sp, #0xb8]
   20788:      	cmp	x15, #0x19a
   2078c:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   20790:      	ldr	x0, [x19, #0x4f70]
   20794:      	ldr	x1, [sp, #0x188]
   20798:      	str	x0, [x1, #0x10]
   2079c:      	ldr	x1, [x19, #0x4f78]
   207a0:      	ldr	x2, [sp, #0x188]
   207a4:      	str	x1, [x2, #0x18]
   207a8:      	ldr	x2, [x19, #0x5a20]
   207ac:      	ldr	x5, [sp, #0x188]
   207b0:      	str	x2, [x5, #0xac0]
   207b4:      	ldr	x2, [sp, #0x188]
   207b8:      	str	x0, [x2, #0x10]
   207bc:      	str	x1, [x5, #0x18]
   207c0:      	ldr	x0, [x19, #0x50c0]
   207c4:      	ldr	x6, [sp, #0x188]
   207c8:      	str	x0, [x6, #0x160]
   207cc:      	ldr	x0, [x19, #0x50c8]
   207d0:      	ldr	x9, [sp, #0x188]
   207d4:      	str	x0, [x9, #0x168]
   207d8:      	ldr	x0, [x19, #0x50d0]
   207dc:      	ldr	x12, [sp, #0x188]
   207e0:      	str	x0, [x12, #0x170]
   207e4:      	ldr	x0, [x19, #0x50d8]
   207e8:      	ldr	x15, [sp, #0x188]
   207ec:      	str	x0, [x15, #0x178]
   207f0:      	ldr	x0, [x19, #0x50e0]
   207f4:      	ldr	x1, [sp, #0x188]
   207f8:      	str	x0, [x1, #0x180]
   207fc:      	ldr	x0, [x19, #0x50e8]
   20800:      	str	x0, [x1, #0x188]
   20804:      	ldr	x0, [x19, #0x50f0]
   20808:      	str	x0, [x1, #0x190]
   2080c:      	ldr	x0, [x19, #0x50f8]
   20810:      	str	x0, [x1, #0x198]
   20814:      	ldr	x0, [x19, #0x5100]
   20818:      	str	x0, [x1, #0x1a0]
   2081c:      	ldr	x0, [x19, #0x52a8]
   20820:      	str	x0, [x1, #0x348]
   20824:      	ldr	x0, [x19, #0x52b0]
   20828:      	str	x0, [x1, #0x350]
   2082c:      	ldr	x0, [x19, #0x52b8]
   20830:      	str	x0, [x1, #0x358]
   20834:      	ldr	x0, [x19, #0x52c0]
   20838:      	str	x0, [x1, #0x360]
   2083c:      	ldr	x0, [x19, #0x52c8]
   20840:      	str	x0, [x1, #0x368]
   20844:      	ldr	x0, [x19, #0x52d0]
   20848:      	str	x0, [x1, #0x370]
   2084c:      	ldr	x0, [x19, #0x52d8]
   20850:      	str	x0, [x1, #0x378]
   20854:      	ldr	x0, [x19, #0x52e0]
   20858:      	str	x0, [x1, #0x380]
   2085c:      	ldr	x0, [x19, #0x52e8]
   20860:      	str	x0, [x1, #0x388]
   20864:      	ldr	x0, [x19, #0x55d8]
   20868:      	str	x0, [x1, #0x678]
   2086c:      	ldr	x0, [x19, #0x55e0]
   20870:      	str	x0, [x1, #0x680]
   20874:      	ldr	x0, [x19, #0x55e8]
   20878:      	str	x0, [x5, #0x688]
   2087c:      	ldr	x0, [x19, #0x55f0]
   20880:      	str	x0, [x6, #0x690]
   20884:      	ldr	x0, [x19, #0x55f8]
   20888:      	str	x0, [x9, #0x698]
   2088c:      	ldr	x0, [x19, #0x5600]
   20890:      	str	x0, [x12, #0x6a0]
   20894:      	ldr	x0, [x19, #0x5608]
   20898:      	str	x0, [x15, #0x6a8]
   2089c:      	ldr	x0, [x19, #0x5610]
   208a0:      	str	x0, [x1, #0x6b0]
   208a4:      	ldr	x0, [x19, #0x57a0]
   208a8:      	str	x0, [x1, #0x840]
   208ac:      	ldr	x0, [x19, #0x57a8]
   208b0:      	str	x0, [x1, #0x848]
   208b4:      	ldr	x1, [x19, #0x57b0]
   208b8:      	ldr	x0, [sp, #0x188]
   208bc:      	str	x1, [x0, #0x850]
   208c0:      	ldr	x2, [x19, #0x57b8]
   208c4:      	str	x2, [x0, #0x858]
   208c8:      	ldr	x5, [x19, #0x57c0]
   208cc:      	str	x5, [x0, #0x860]
   208d0:      	ldr	x5, [x19, #0x57c8]
   208d4:      	str	x5, [x0, #0x868]
   208d8:      	ldr	x5, [x19, #0x57d0]
   208dc:      	str	x5, [x0, #0x870]
   208e0:      	ldr	x6, [x19, #0x57d8]
   208e4:      	str	x6, [x0, #0x878]
   208e8:      	ldr	x7, [x19, #0x5bb0]
   208ec:      	str	x7, [x0, #0xc50]
   208f0:      	ldr	x8, [x19, #0x5bb8]
   208f4:      	str	x8, [x0, #0xc58]
   208f8:      	ldr	x9, [x19, #0x5bc0]
   208fc:      	str	x9, [x0, #0xc60]
   20900:      	ldr	x10, [x19, #0x5bc8]
   20904:      	str	x10, [x0, #0xc68]
   20908:      	ldr	x11, [x19, #0x5bd0]
   2090c:      	str	x11, [x0, #0xc70]
   20910:      	ldr	x12, [x19, #0x5bd8]
   20914:      	str	x12, [x0, #0xc78]
   20918:      	mov	x13, #0x0               ; =0
   2091c:      	str	x13, [x0, #0xc80]
   20920:      	ldr	x14, [x19, #0x5be8]
   20924:      	ldr	x5, [sp, #0x188]
   20928:      	str	x14, [x5, #0xc88]
   2092c:      	ldr	x15, [x19, #0x5bf0]
   20930:      	ldr	x6, [sp, #0x188]
   20934:      	str	x15, [x6, #0xc90]
   20938:      	ldr	x8, [sp, #0x188]
   2093c:      	str	x13, [x8, #0xc98]
   20940:      	ldr	x0, [x19, #0x5c00]
   20944:      	ldr	x11, [sp, #0x188]
   20948:      	str	x0, [x11, #0xca0]
   2094c:      	ldr	x0, [x19, #0x5c08]
   20950:      	ldr	x14, [sp, #0x188]
   20954:      	str	x0, [x14, #0xca8]
   20958:      	ldr	x0, [sp, #0x188]
   2095c:      	str	x13, [x0, #0xcb0]
   20960:      	ldr	x0, [x19, #0x5c18]
   20964:      	ldr	x1, [sp, #0x188]
   20968:      	str	x0, [x1, #0xcb8]
   2096c:      	ldr	x0, [x19, #0x5c20]
   20970:      	str	x0, [x1, #0xcc0]
   20974:      	mov	x1, #0x5ea              ; =1514
   20978:      	mov	x2, #-0x9               ; =-9
   2097c:      	ldr	x21, [sp, #0x198]
   20980:      	ldur	x0, [sp, #0x8]
   20984:      	mov	x5, x20
   20988:      	ldr	x6, [sp, #0x190]
   2098c:      	blr	x21
   20990:      	cmp	x0, #0x0
   20994:      	b.ne	0x23af8 <_mech_canonical_program_entry_v1_numeric_1282+0x5f78>
   20998:      	mov	x0, #0x3                ; =3
   2099c:      	ldr	x15, [sp, #0x180]
   209a0:      	stur	x0, [sp, #0xb8]
   209a4:      	cmp	x15, #0x2
   209a8:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   209ac:      	mov	x5, #0x0                ; =0
   209b0:      	ldr	x3, [sp, #0x188]
   209b4:      	str	x5, [x3]
   209b8:      	ldr	x0, [x19, #0x1c10]
   209bc:      	str	x0, [x3, #0x8]
   209c0:      	mov	x1, #0x5ea              ; =1514
   209c4:      	ldur	x0, [sp, #0x8]
   209c8:      	ldr	x6, [sp, #0x190]
   209cc:      	ldr	x21, [sp, #0x198]
   209d0:      	mov	x4, x20
   209d4:      	mov	x2, x5
   209d8:      	blr	x21
   209dc:      	cmp	x0, #0x0
   209e0:      	b.ne	0x23b00 <_mech_canonical_program_entry_v1_numeric_1282+0x5f80>
   209e4:      	mov	x0, #0x3                ; =3
   209e8:      	stur	x0, [sp, #0xb8]
   209ec:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   209f0:      	ldur	x24, [sp, #0xd8]
   209f4:      	ldr	x26, [sp, #0x128]
   209f8:      	ldr	x12, [x26, x24, lsl #3]
   209fc:      	mov	x7, #0x0                ; =0
   20a00:      	stur	x7, [sp, #0x40]
   20a04:      	mov	w0, #0x2646             ; =9798
   20a08:      	movk	w0, #0x1, lsl #16
   20a0c:      	cmp	x3, x0
   20a10:      	cset	x0, hs
   20a14:      	ldur	x26, [sp, #0xe8]
   20a18:      	and	w0, w0, w26
   20a1c:      	uxtb	w0, w0
   20a20:      	cbnz	x0, 0x20dc0 <_mech_canonical_program_entry_v1_numeric_1282+0x3240>
   20a24:      	mov	x0, #0x0                ; =0
   20a28:      	str	x0, [x19, #0x18]
   20a2c:      	mov	x1, #0x1000000000000000 ; =1152921504606846976
   20a30:      	str	x1, [x19, #0x20]
   20a34:      	mov	x1, #0x1                ; =1
   20a38:      	str	x1, [x19, #0x30]
   20a3c:      	mov	x2, #0x101010101010101  ; =72340172838076673
   20a40:      	str	x2, [x19, #0x38]
   20a44:      	mov	x20, #0x2               ; =2
   20a48:      	str	x20, [x19, #0x40]
   20a4c:      	mov	x2, #0x3                ; =3
   20a50:      	str	x2, [x19, #0x48]
   20a54:      	mov	x2, #0x4                ; =4
   20a58:      	str	x2, [x19, #0x50]
   20a5c:      	mov	x28, x2
   20a60:      	mov	x2, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   20a64:      	str	x2, [x19, #0x78]
   20a68:      	mov	x2, #0x3333333333333333 ; =3689348814741910323
   20a6c:      	str	x2, [x19, #0x88]
   20a70:      	mov	x2, #0x38               ; =56
   20a74:      	str	x2, [x19, #0x90]
   20a78:      	mov	x2, #0x3a               ; =58
   20a7c:      	str	x2, [x19, #0x98]
   20a80:      	mov	x2, #0x5555555555555555 ; =6148914691236517205
   20a84:      	str	x2, [x19, #0xb0]
   20a88:      	mov	x2, #0x3ffffffffffffff  ; =288230376151711743
   20a8c:      	str	x2, [x19, #0xb8]
   20a90:      	str	x0, [x19, #0x188]
   20a94:      	str	x1, [x19, #0x190]
   20a98:      	str	x22, [x19, #0x17a0]
   20a9c:      	str	x23, [x19, #0x17a8]
   20aa0:      	ldur	x24, [sp, #0xe0]
   20aa4:      	uxtb	w2, w24
   20aa8:      	str	x2, [x19, #0x17b8]
   20aac:      	str	x10, [x19, #0x4c60]
   20ab0:      	str	x3, [x19, #0x4c68]
   20ab4:      	ldur	x4, [sp, #0x80]
   20ab8:      	str	x4, [x19, #0x4c70]
   20abc:      	str	x22, [x19, #0x4f70]
   20ac0:      	str	x23, [x19, #0x4f78]
   20ac4:      	str	x15, [x19, #0x55d8]
   20ac8:      	str	x12, [x19, #0x55e0]
   20acc:      	str	x22, [x19, #0x55e8]
   20ad0:      	ldur	x25, [sp, #0x10]
   20ad4:      	str	x25, [x19, #0x55f0]
   20ad8:      	ldur	x24, [sp, #0x58]
   20adc:      	str	x24, [x19, #0x55f8]
   20ae0:      	ldur	x27, [sp, #0x60]
   20ae4:      	str	x27, [x19, #0x5600]
   20ae8:      	ldur	x25, [sp, #0x68]
   20aec:      	str	x25, [x19, #0x5608]
   20af0:      	ldur	x26, [sp, #0x70]
   20af4:      	str	x26, [x19, #0x5610]
   20af8:      	ldur	x2, [sp, #0x50]
   20afc:      	str	x2, [x19, #0x5a20]
   20b00:      	add	x14, x8, #0x1
   20b04:      	str	x14, [x19, #0x5bb0]
   20b08:      	ldur	x26, [sp, #0x88]
   20b0c:      	str	x26, [x19, #0x5bb8]
   20b10:      	ldur	x6, [sp, #0x90]
   20b14:      	str	x6, [x19, #0x5bc0]
   20b18:      	ldur	x4, [sp, #0x78]
   20b1c:      	sub	x2, x4, x3
   20b20:      	mov	w3, #0xc87e             ; =51326
   20b24:      	movk	w3, #0x1, lsl #16
   20b28:      	msub	x2, x14, x3, x2
   20b2c:      	str	x2, [x19, #0x5bc8]
   20b30:      	str	x0, [x19, #0x5bd0]
   20b34:      	str	x0, [x19, #0x5bd8]
   20b38:      	ldur	x10, [sp, #0x98]
   20b3c:      	str	x10, [x19, #0x5be8]
   20b40:      	ldur	x4, [sp, #0xa0]
   20b44:      	str	x4, [x19, #0x5bf0]
   20b48:      	str	x1, [x19, #0x5c00]
   20b4c:      	ldur	x7, [sp, #0x40]
   20b50:      	str	x7, [x19, #0x5c08]
   20b54:      	str	x13, [x19, #0x5c18]
   20b58:      	ldur	x13, [sp, #0xa8]
   20b5c:      	str	x13, [x19, #0x5c20]
   20b60:      	ldr	x0, [x19, #0x4c60]
   20b64:      	cmp	x0, #0x0
   20b68:      	b.eq	0x20d98 <_mech_canonical_program_entry_v1_numeric_1282+0x3218>
   20b6c:      	ldr	x3, [x19, #0x4c68]
   20b70:      	ldr	x4, [x19, #0x4c70]
   20b74:      	mov	x0, #0x0                ; =0
   20b78:      	str	x0, [x19, #0x4c60]
   20b7c:      	mov	x0, #0x3                ; =3
   20b80:      	ldr	x15, [sp, #0x180]
   20b84:      	stur	x0, [sp, #0xb8]
   20b88:      	cmp	x15, #0x19a
   20b8c:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   20b90:      	ldr	x0, [x19, #0x4f70]
   20b94:      	ldr	x1, [sp, #0x188]
   20b98:      	str	x0, [x1, #0x10]
   20b9c:      	ldr	x1, [x19, #0x4f78]
   20ba0:      	ldr	x2, [sp, #0x188]
   20ba4:      	str	x1, [x2, #0x18]
   20ba8:      	ldr	x2, [x19, #0x5a20]
   20bac:      	ldr	x5, [sp, #0x188]
   20bb0:      	str	x2, [x5, #0xac0]
   20bb4:      	ldr	x2, [sp, #0x188]
   20bb8:      	str	x0, [x2, #0x10]
   20bbc:      	ldr	x0, [sp, #0x188]
   20bc0:      	str	x1, [x0, #0x18]
   20bc4:      	ldr	x0, [x19, #0x50c0]
   20bc8:      	ldr	x1, [sp, #0x188]
   20bcc:      	str	x0, [x1, #0x160]
   20bd0:      	ldr	x0, [x19, #0x50c8]
   20bd4:      	str	x0, [x1, #0x168]
   20bd8:      	ldr	x0, [x19, #0x50d0]
   20bdc:      	str	x0, [x1, #0x170]
   20be0:      	ldr	x0, [x19, #0x50d8]
   20be4:      	str	x0, [x1, #0x178]
   20be8:      	ldr	x0, [x19, #0x50e0]
   20bec:      	str	x0, [x1, #0x180]
   20bf0:      	ldr	x0, [x19, #0x50e8]
   20bf4:      	str	x0, [x1, #0x188]
   20bf8:      	ldr	x0, [x19, #0x50f0]
   20bfc:      	str	x0, [x1, #0x190]
   20c00:      	ldr	x0, [x19, #0x50f8]
   20c04:      	str	x0, [x1, #0x198]
   20c08:      	ldr	x0, [x19, #0x5100]
   20c0c:      	str	x0, [x1, #0x1a0]
   20c10:      	ldr	x0, [x19, #0x52a8]
   20c14:      	str	x0, [x1, #0x348]
   20c18:      	ldr	x0, [x19, #0x52b0]
   20c1c:      	str	x0, [x1, #0x350]
   20c20:      	ldr	x0, [x19, #0x52b8]
   20c24:      	str	x0, [x1, #0x358]
   20c28:      	ldr	x0, [x19, #0x52c0]
   20c2c:      	str	x0, [x2, #0x360]
   20c30:      	ldr	x0, [x19, #0x52c8]
   20c34:      	str	x0, [x5, #0x368]
   20c38:      	ldr	x0, [x19, #0x52d0]
   20c3c:      	ldr	x8, [sp, #0x188]
   20c40:      	str	x0, [x8, #0x370]
   20c44:      	ldr	x0, [x19, #0x52d8]
   20c48:      	ldr	x11, [sp, #0x188]
   20c4c:      	str	x0, [x11, #0x378]
   20c50:      	ldr	x0, [x19, #0x52e0]
   20c54:      	ldr	x14, [sp, #0x188]
   20c58:      	str	x0, [x14, #0x380]
   20c5c:      	ldr	x0, [x19, #0x52e8]
   20c60:      	str	x0, [x1, #0x388]
   20c64:      	ldr	x0, [x19, #0x55d8]
   20c68:      	str	x0, [x1, #0x678]
   20c6c:      	ldr	x0, [x19, #0x55e0]
   20c70:      	str	x0, [x1, #0x680]
   20c74:      	ldr	x0, [x19, #0x55e8]
   20c78:      	str	x0, [x1, #0x688]
   20c7c:      	ldr	x0, [x19, #0x55f0]
   20c80:      	str	x0, [x1, #0x690]
   20c84:      	ldr	x0, [x19, #0x55f8]
   20c88:      	str	x0, [x1, #0x698]
   20c8c:      	ldr	x0, [x19, #0x5600]
   20c90:      	str	x0, [x1, #0x6a0]
   20c94:      	ldr	x0, [x19, #0x5608]
   20c98:      	str	x0, [x1, #0x6a8]
   20c9c:      	ldr	x0, [x19, #0x5610]
   20ca0:      	str	x0, [x1, #0x6b0]
   20ca4:      	ldr	x1, [x19, #0x57a0]
   20ca8:      	ldr	x0, [sp, #0x188]
   20cac:      	str	x1, [x0, #0x840]
   20cb0:      	ldr	x2, [x19, #0x57a8]
   20cb4:      	str	x2, [x0, #0x848]
   20cb8:      	ldr	x5, [x19, #0x57b0]
   20cbc:      	str	x5, [x0, #0x850]
   20cc0:      	ldr	x5, [x19, #0x57b8]
   20cc4:      	str	x5, [x0, #0x858]
   20cc8:      	ldr	x5, [x19, #0x57c0]
   20ccc:      	str	x5, [x0, #0x860]
   20cd0:      	ldr	x6, [x19, #0x57c8]
   20cd4:      	str	x6, [x0, #0x868]
   20cd8:      	ldr	x7, [x19, #0x57d0]
   20cdc:      	str	x7, [x0, #0x870]
   20ce0:      	ldr	x8, [x19, #0x57d8]
   20ce4:      	ldr	x2, [sp, #0x188]
   20ce8:      	str	x8, [x2, #0x878]
   20cec:      	ldr	x9, [x19, #0x5bb0]
   20cf0:      	ldr	x5, [sp, #0x188]
   20cf4:      	str	x9, [x5, #0xc50]
   20cf8:      	ldr	x10, [x19, #0x5bb8]
   20cfc:      	ldr	x8, [sp, #0x188]
   20d00:      	str	x10, [x8, #0xc58]
   20d04:      	ldr	x11, [x19, #0x5bc0]
   20d08:      	ldr	x12, [sp, #0x188]
   20d0c:      	str	x11, [x12, #0xc60]
   20d10:      	ldr	x12, [x19, #0x5bc8]
   20d14:      	str	x12, [x14, #0xc68]
   20d18:      	ldr	x13, [x19, #0x5bd0]
   20d1c:      	str	x13, [x0, #0xc70]
   20d20:      	ldr	x14, [x19, #0x5bd8]
   20d24:      	str	x14, [x0, #0xc78]
   20d28:      	mov	x15, #0x0               ; =0
   20d2c:      	str	x15, [x0, #0xc80]
   20d30:      	ldr	x0, [x19, #0x5be8]
   20d34:      	ldr	x1, [sp, #0x188]
   20d38:      	str	x0, [x1, #0xc88]
   20d3c:      	ldr	x0, [x19, #0x5bf0]
   20d40:      	str	x0, [x1, #0xc90]
   20d44:      	ldr	x0, [sp, #0x188]
   20d48:      	str	x15, [x0, #0xc98]
   20d4c:      	ldr	x0, [x19, #0x5c00]
   20d50:      	str	x0, [x1, #0xca0]
   20d54:      	ldr	x0, [x19, #0x5c08]
   20d58:      	str	x0, [x1, #0xca8]
   20d5c:      	ldr	x0, [sp, #0x188]
   20d60:      	str	x15, [x0, #0xcb0]
   20d64:      	ldr	x0, [x19, #0x5c18]
   20d68:      	str	x0, [x1, #0xcb8]
   20d6c:      	ldr	x0, [x19, #0x5c20]
   20d70:      	str	x0, [x1, #0xcc0]
   20d74:      	mov	x1, #0x5f2              ; =1522
   20d78:      	mov	x2, #-0x9               ; =-9
   20d7c:      	mov	x5, #0x1                ; =1
   20d80:      	ldur	x0, [sp, #0x8]
   20d84:      	ldr	x6, [sp, #0x190]
   20d88:      	ldr	x21, [sp, #0x198]
   20d8c:      	blr	x21
   20d90:      	cmp	x0, #0x0
   20d94:      	b.ne	0x23b08 <_mech_canonical_program_entry_v1_numeric_1282+0x5f88>
   20d98:      	mov	x0, #0x0                ; =0
   20d9c:      	mov	x1, x28
   20da0:      	add	sp, sp, #0x1b0
   20da4:      	ldp	x19, x20, [sp], #0x10
   20da8:      	ldp	x21, x22, [sp], #0x10
   20dac:      	ldp	x23, x24, [sp], #0x10
   20db0:      	ldp	x25, x26, [sp], #0x10
   20db4:      	ldp	x27, x28, [sp], #0x10
   20db8:      	ldp	x29, x30, [sp], #0x10
   20dbc:      	retab
   20dc0:      	cmp	x15, x12
   20dc4:      	cset	x0, lo
   20dc8:      	mov	x26, #0x1000000000000000 ; =1152921504606846976
   20dcc:      	mov	x1, #0x1000000000000000 ; =1152921504606846976
   20dd0:      	ldur	x2, [sp, #0x70]
   20dd4:      	cmp	x2, x1
   20dd8:      	cset	x1, lo
   20ddc:      	and	w0, w0, w1
   20de0:      	uxtb	w25, w0
   20de4:      	tbnz	w25, #0x0, 0x20e0c <_mech_canonical_program_entry_v1_numeric_1282+0x328c>
   20de8:      	mov	w0, #0x2646             ; =9798
   20dec:      	movk	w0, #0x1, lsl #16
   20df0:      	sub	x3, x3, x0
   20df4:      	ldur	x0, [sp, #0x58]
   20df8:      	ldur	x1, [sp, #0x10]
   20dfc:      	ldur	x7, [sp, #0x60]
   20e00:      	ldur	x11, [sp, #0x68]
   20e04:      	ldur	x24, [sp, #0x70]
   20e08:      	b	0x21e20 <_mech_canonical_program_entry_v1_numeric_1282+0x42a0>
   20e0c:      	add	x2, x15, #0x1
   20e10:      	cmp	x2, x15
   20e14:      	b.lo	0x23b10 <_mech_canonical_program_entry_v1_numeric_1282+0x5f90>
   20e18:      	ldr	x0, [sp, #0x110]
   20e1c:      	cmp	x15, x0
   20e20:      	b.lo	0x210a8 <_mech_canonical_program_entry_v1_numeric_1282+0x3528>
   20e24:      	b	0x23c40 <_mech_canonical_program_entry_v1_numeric_1282+0x60c0>
   20e28:      	ldr	x3, [x19, #0x4c68]
   20e2c:      	ldr	x4, [x19, #0x4c70]
   20e30:      	mov	x0, #0x0                ; =0
   20e34:      	str	x0, [x19, #0x4c60]
   20e38:      	mov	x0, #0x3                ; =3
   20e3c:      	ldr	x15, [sp, #0x180]
   20e40:      	stur	x0, [sp, #0xb8]
   20e44:      	cmp	x15, #0x19a
   20e48:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   20e4c:      	ldr	x0, [x19, #0x4f70]
   20e50:      	ldr	x1, [sp, #0x188]
   20e54:      	str	x0, [x1, #0x10]
   20e58:      	ldr	x1, [x19, #0x4f78]
   20e5c:      	ldr	x2, [sp, #0x188]
   20e60:      	str	x1, [x2, #0x18]
   20e64:      	ldr	x2, [x19, #0x5a20]
   20e68:      	ldr	x5, [sp, #0x188]
   20e6c:      	str	x2, [x5, #0xac0]
   20e70:      	ldr	x2, [sp, #0x188]
   20e74:      	str	x0, [x2, #0x10]
   20e78:      	ldr	x0, [sp, #0x188]
   20e7c:      	str	x1, [x0, #0x18]
   20e80:      	ldr	x0, [x19, #0x50c0]
   20e84:      	ldr	x1, [sp, #0x188]
   20e88:      	str	x0, [x1, #0x160]
   20e8c:      	ldr	x0, [x19, #0x50c8]
   20e90:      	str	x0, [x2, #0x168]
   20e94:      	ldr	x0, [x19, #0x50d0]
   20e98:      	str	x0, [x5, #0x170]
   20e9c:      	ldr	x0, [x19, #0x50d8]
   20ea0:      	ldr	x8, [sp, #0x188]
   20ea4:      	str	x0, [x8, #0x178]
   20ea8:      	ldr	x0, [x19, #0x50e0]
   20eac:      	ldr	x11, [sp, #0x188]
   20eb0:      	str	x0, [x11, #0x180]
   20eb4:      	ldr	x0, [x19, #0x50e8]
   20eb8:      	ldr	x14, [sp, #0x188]
   20ebc:      	str	x0, [x14, #0x188]
   20ec0:      	ldr	x0, [x19, #0x50f0]
   20ec4:      	str	x0, [x1, #0x190]
   20ec8:      	ldr	x0, [x19, #0x50f8]
   20ecc:      	str	x0, [x1, #0x198]
   20ed0:      	ldr	x0, [x19, #0x5100]
   20ed4:      	str	x0, [x1, #0x1a0]
   20ed8:      	ldr	x0, [x19, #0x52a8]
   20edc:      	str	x0, [x1, #0x348]
   20ee0:      	ldr	x0, [x19, #0x52b0]
   20ee4:      	str	x0, [x1, #0x350]
   20ee8:      	ldr	x0, [x19, #0x52b8]
   20eec:      	str	x0, [x1, #0x358]
   20ef0:      	ldr	x0, [x19, #0x52c0]
   20ef4:      	str	x0, [x1, #0x360]
   20ef8:      	ldr	x0, [x19, #0x52c8]
   20efc:      	str	x0, [x1, #0x368]
   20f00:      	ldr	x0, [x19, #0x52d0]
   20f04:      	str	x0, [x1, #0x370]
   20f08:      	ldr	x0, [x19, #0x52d8]
   20f0c:      	str	x0, [x1, #0x378]
   20f10:      	ldr	x0, [x19, #0x52e0]
   20f14:      	str	x0, [x1, #0x380]
   20f18:      	ldr	x0, [x19, #0x52e8]
   20f1c:      	str	x0, [x1, #0x388]
   20f20:      	ldr	x0, [x19, #0x55d8]
   20f24:      	str	x0, [x1, #0x678]
   20f28:      	ldr	x0, [x19, #0x55e0]
   20f2c:      	str	x0, [x1, #0x680]
   20f30:      	ldr	x0, [x19, #0x55e8]
   20f34:      	str	x0, [x1, #0x688]
   20f38:      	ldr	x0, [x19, #0x55f0]
   20f3c:      	str	x0, [x1, #0x690]
   20f40:      	ldr	x0, [x19, #0x55f8]
   20f44:      	str	x0, [x2, #0x698]
   20f48:      	ldr	x0, [x19, #0x5600]
   20f4c:      	str	x0, [x5, #0x6a0]
   20f50:      	ldr	x0, [x19, #0x5608]
   20f54:      	str	x0, [x8, #0x6a8]
   20f58:      	ldr	x0, [x19, #0x5610]
   20f5c:      	str	x0, [x11, #0x6b0]
   20f60:      	ldr	x0, [x19, #0x57a0]
   20f64:      	str	x0, [x14, #0x840]
   20f68:      	ldr	x0, [x19, #0x57a8]
   20f6c:      	str	x0, [x1, #0x848]
   20f70:      	ldr	x0, [x19, #0x57b0]
   20f74:      	str	x0, [x1, #0x850]
   20f78:      	ldr	x0, [x19, #0x57b8]
   20f7c:      	str	x0, [x1, #0x858]
   20f80:      	ldr	x0, [x19, #0x57c0]
   20f84:      	str	x0, [x1, #0x860]
   20f88:      	ldr	x0, [x19, #0x57c8]
   20f8c:      	str	x0, [x1, #0x868]
   20f90:      	ldr	x0, [x19, #0x57d0]
   20f94:      	str	x0, [x1, #0x870]
   20f98:      	ldr	x0, [x19, #0x57d8]
   20f9c:      	str	x0, [x1, #0x878]
   20fa0:      	ldr	x0, [x19, #0x5bb0]
   20fa4:      	str	x0, [x1, #0xc50]
   20fa8:      	ldr	x1, [x19, #0x5bb8]
   20fac:      	ldr	x0, [sp, #0x188]
   20fb0:      	str	x1, [x0, #0xc58]
   20fb4:      	ldr	x2, [x19, #0x5bc0]
   20fb8:      	str	x2, [x0, #0xc60]
   20fbc:      	ldr	x5, [x19, #0x5bc8]
   20fc0:      	str	x5, [x0, #0xc68]
   20fc4:      	ldr	x5, [x19, #0x5bd0]
   20fc8:      	str	x5, [x0, #0xc70]
   20fcc:      	ldr	x5, [x19, #0x5bd8]
   20fd0:      	str	x5, [x0, #0xc78]
   20fd4:      	mov	x6, #0x0                ; =0
   20fd8:      	str	x6, [x0, #0xc80]
   20fdc:      	ldr	x7, [x19, #0x5be8]
   20fe0:      	str	x7, [x0, #0xc88]
   20fe4:      	ldr	x8, [x19, #0x5bf0]
   20fe8:      	str	x8, [x0, #0xc90]
   20fec:      	ldr	x1, [sp, #0x188]
   20ff0:      	str	x6, [x1, #0xc98]
   20ff4:      	ldr	x10, [x19, #0x5c00]
   20ff8:      	ldr	x5, [sp, #0x188]
   20ffc:      	str	x10, [x5, #0xca0]
   21000:      	ldr	x11, [x19, #0x5c08]
   21004:      	ldr	x7, [sp, #0x188]
   21008:      	str	x11, [x7, #0xca8]
   2100c:      	ldr	x9, [sp, #0x188]
   21010:      	str	x6, [x9, #0xcb0]
   21014:      	ldr	x13, [x19, #0x5c18]
   21018:      	ldr	x12, [sp, #0x188]
   2101c:      	str	x13, [x12, #0xcb8]
   21020:      	ldr	x14, [x19, #0x5c20]
   21024:      	ldr	x15, [sp, #0x188]
   21028:      	str	x14, [x15, #0xcc0]
   2102c:      	mov	x1, #0x605              ; =1541
   21030:      	mov	x2, #-0x9               ; =-9
   21034:      	ldr	x21, [sp, #0x198]
   21038:      	ldur	x0, [sp, #0x8]
   2103c:      	mov	x5, x20
   21040:      	ldr	x6, [sp, #0x190]
   21044:      	blr	x21
   21048:      	cmp	x0, #0x0
   2104c:      	b.ne	0x23db0 <_mech_canonical_program_entry_v1_numeric_1282+0x6230>
   21050:      	mov	x0, #0x3                ; =3
   21054:      	ldr	x15, [sp, #0x180]
   21058:      	stur	x0, [sp, #0xb8]
   2105c:      	cmp	x15, #0x2
   21060:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   21064:      	mov	x5, #0x0                ; =0
   21068:      	ldr	x3, [sp, #0x188]
   2106c:      	str	x5, [x3]
   21070:      	ldr	x0, [x19, #0x1cb8]
   21074:      	str	x0, [x3, #0x8]
   21078:      	mov	x1, #0x605              ; =1541
   2107c:      	ldur	x0, [sp, #0x8]
   21080:      	ldr	x6, [sp, #0x190]
   21084:      	ldr	x21, [sp, #0x198]
   21088:      	mov	x4, x20
   2108c:      	mov	x2, x5
   21090:      	blr	x21
   21094:      	cmp	x0, #0x0
   21098:      	b.ne	0x23db8 <_mech_canonical_program_entry_v1_numeric_1282+0x6238>
   2109c:      	mov	x0, #0x3                ; =3
   210a0:      	stur	x0, [sp, #0xb8]
   210a4:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   210a8:      	ldr	x6, [sp, #0x118]
   210ac:      	ldr	x1, [x6, x15, lsl #3]
   210b0:      	add	x2, x1, #0x1
   210b4:      	cmp	x2, x1
   210b8:      	b.lo	0x23dc0 <_mech_canonical_program_entry_v1_numeric_1282+0x6240>
   210bc:      	ldr	x0, [sp, #0x100]
   210c0:      	cmp	x1, x0
   210c4:      	b.lo	0x21338 <_mech_canonical_program_entry_v1_numeric_1282+0x37b8>
   210c8:      	b	0x23ef4 <_mech_canonical_program_entry_v1_numeric_1282+0x6374>
   210cc:      	ldr	x3, [x19, #0x4c68]
   210d0:      	ldr	x4, [x19, #0x4c70]
   210d4:      	mov	x5, #0x0                ; =0
   210d8:      	str	x5, [x19, #0x4c60]
   210dc:      	mov	x0, #0x3                ; =3
   210e0:      	ldr	x15, [sp, #0x180]
   210e4:      	stur	x0, [sp, #0xb8]
   210e8:      	cmp	x15, #0x19a
   210ec:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   210f0:      	ldr	x7, [x19, #0x4f70]
   210f4:      	ldr	x10, [sp, #0x188]
   210f8:      	str	x7, [x10, #0x10]
   210fc:      	ldr	x8, [x19, #0x4f78]
   21100:      	ldr	x13, [sp, #0x188]
   21104:      	str	x8, [x13, #0x18]
   21108:      	ldr	x9, [x19, #0x5a20]
   2110c:      	ldr	x0, [sp, #0x188]
   21110:      	str	x9, [x0, #0xac0]
   21114:      	str	x7, [x0, #0x10]
   21118:      	str	x8, [x0, #0x18]
   2111c:      	ldr	x12, [x19, #0x50c0]
   21120:      	str	x12, [x0, #0x160]
   21124:      	ldr	x13, [x19, #0x50c8]
   21128:      	str	x13, [x0, #0x168]
   2112c:      	ldr	x14, [x19, #0x50d0]
   21130:      	str	x14, [x0, #0x170]
   21134:      	ldr	x15, [x19, #0x50d8]
   21138:      	str	x15, [x0, #0x178]
   2113c:      	ldr	x0, [x19, #0x50e0]
   21140:      	ldr	x1, [sp, #0x188]
   21144:      	str	x0, [x1, #0x180]
   21148:      	ldr	x0, [x19, #0x50e8]
   2114c:      	str	x0, [x1, #0x188]
   21150:      	ldr	x0, [x19, #0x50f0]
   21154:      	str	x0, [x1, #0x190]
   21158:      	ldr	x0, [x19, #0x50f8]
   2115c:      	str	x0, [x1, #0x198]
   21160:      	ldr	x0, [x19, #0x5100]
   21164:      	str	x0, [x1, #0x1a0]
   21168:      	ldr	x0, [x19, #0x52a8]
   2116c:      	str	x0, [x1, #0x348]
   21170:      	ldr	x0, [x19, #0x52b0]
   21174:      	str	x0, [x1, #0x350]
   21178:      	ldr	x0, [x19, #0x52b8]
   2117c:      	str	x0, [x1, #0x358]
   21180:      	ldr	x0, [x19, #0x52c0]
   21184:      	str	x0, [x1, #0x360]
   21188:      	ldr	x0, [x19, #0x52c8]
   2118c:      	str	x0, [x1, #0x368]
   21190:      	ldr	x0, [x19, #0x52d0]
   21194:      	ldr	x2, [sp, #0x188]
   21198:      	str	x0, [x2, #0x370]
   2119c:      	ldr	x0, [x19, #0x52d8]
   211a0:      	ldr	x5, [sp, #0x188]
   211a4:      	str	x0, [x5, #0x378]
   211a8:      	ldr	x0, [x19, #0x52e0]
   211ac:      	ldr	x8, [sp, #0x188]
   211b0:      	str	x0, [x8, #0x380]
   211b4:      	ldr	x0, [x19, #0x52e8]
   211b8:      	ldr	x11, [sp, #0x188]
   211bc:      	str	x0, [x11, #0x388]
   211c0:      	ldr	x0, [x19, #0x55d8]
   211c4:      	ldr	x14, [sp, #0x188]
   211c8:      	str	x0, [x14, #0x678]
   211cc:      	ldr	x0, [x19, #0x55e0]
   211d0:      	str	x0, [x1, #0x680]
   211d4:      	ldr	x0, [x19, #0x55e8]
   211d8:      	str	x0, [x1, #0x688]
   211dc:      	ldr	x0, [x19, #0x55f0]
   211e0:      	str	x0, [x1, #0x690]
   211e4:      	ldr	x0, [x19, #0x55f8]
   211e8:      	str	x0, [x1, #0x698]
   211ec:      	ldr	x0, [x19, #0x5600]
   211f0:      	str	x0, [x1, #0x6a0]
   211f4:      	ldr	x0, [x19, #0x5608]
   211f8:      	str	x0, [x1, #0x6a8]
   211fc:      	ldr	x0, [x19, #0x5610]
   21200:      	str	x0, [x1, #0x6b0]
   21204:      	ldr	x0, [x19, #0x57a0]
   21208:      	str	x0, [x1, #0x840]
   2120c:      	ldr	x0, [x19, #0x57a8]
   21210:      	str	x0, [x1, #0x848]
   21214:      	ldr	x0, [x19, #0x57b0]
   21218:      	str	x0, [x1, #0x850]
   2121c:      	ldr	x0, [x19, #0x57b8]
   21220:      	str	x0, [x1, #0x858]
   21224:      	ldr	x0, [x19, #0x57c0]
   21228:      	str	x0, [x1, #0x860]
   2122c:      	ldr	x0, [x19, #0x57c8]
   21230:      	str	x0, [x1, #0x868]
   21234:      	ldr	x0, [x19, #0x57d0]
   21238:      	str	x0, [x1, #0x870]
   2123c:      	ldr	x0, [x19, #0x57d8]
   21240:      	str	x0, [x1, #0x878]
   21244:      	ldr	x0, [x19, #0x5bb0]
   21248:      	str	x0, [x1, #0xc50]
   2124c:      	ldr	x0, [x19, #0x5bb8]
   21250:      	str	x0, [x2, #0xc58]
   21254:      	ldr	x0, [x19, #0x5bc0]
   21258:      	str	x0, [x5, #0xc60]
   2125c:      	ldr	x0, [x19, #0x5bc8]
   21260:      	str	x0, [x8, #0xc68]
   21264:      	ldr	x0, [x19, #0x5bd0]
   21268:      	str	x0, [x11, #0xc70]
   2126c:      	ldr	x0, [x19, #0x5bd8]
   21270:      	str	x0, [x14, #0xc78]
   21274:      	mov	x0, #0x0                ; =0
   21278:      	str	x0, [x1, #0xc80]
   2127c:      	ldr	x1, [x19, #0x5be8]
   21280:      	str	x1, [x2, #0xc88]
   21284:      	ldr	x1, [x19, #0x5bf0]
   21288:      	str	x1, [x2, #0xc90]
   2128c:      	ldr	x1, [sp, #0x188]
   21290:      	str	x0, [x1, #0xc98]
   21294:      	ldr	x1, [x19, #0x5c00]
   21298:      	str	x1, [x2, #0xca0]
   2129c:      	ldr	x1, [x19, #0x5c08]
   212a0:      	str	x1, [x2, #0xca8]
   212a4:      	ldr	x1, [sp, #0x188]
   212a8:      	str	x0, [x1, #0xcb0]
   212ac:      	ldr	x0, [x19, #0x5c18]
   212b0:      	str	x0, [x1, #0xcb8]
   212b4:      	ldr	x0, [x19, #0x5c20]
   212b8:      	str	x0, [x1, #0xcc0]
   212bc:      	mov	x1, #0x607              ; =1543
   212c0:      	mov	x2, #-0x9               ; =-9
   212c4:      	ldr	x21, [sp, #0x198]
   212c8:      	ldur	x0, [sp, #0x8]
   212cc:      	mov	x5, x20
   212d0:      	ldr	x6, [sp, #0x190]
   212d4:      	blr	x21
   212d8:      	cmp	x0, #0x0
   212dc:      	b.ne	0x24068 <_mech_canonical_program_entry_v1_numeric_1282+0x64e8>
   212e0:      	mov	x0, #0x3                ; =3
   212e4:      	ldr	x15, [sp, #0x180]
   212e8:      	stur	x0, [sp, #0xb8]
   212ec:      	cmp	x15, #0x2
   212f0:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   212f4:      	mov	x5, #0x0                ; =0
   212f8:      	ldr	x3, [sp, #0x188]
   212fc:      	str	x5, [x3]
   21300:      	ldr	x6, [x19, #0x1cc8]
   21304:      	str	x6, [x3, #0x8]
   21308:      	mov	x1, #0x607              ; =1543
   2130c:      	ldur	x0, [sp, #0x8]
   21310:      	ldr	x6, [sp, #0x190]
   21314:      	ldr	x21, [sp, #0x198]
   21318:      	mov	x4, x20
   2131c:      	mov	x2, x5
   21320:      	blr	x21
   21324:      	cmp	x0, #0x0
   21328:      	b.ne	0x24070 <_mech_canonical_program_entry_v1_numeric_1282+0x64f0>
   2132c:      	mov	x0, #0x3                ; =3
   21330:      	stur	x0, [sp, #0xb8]
   21334:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   21338:      	ldr	x0, [sp, #0x108]
   2133c:      	ldr	x27, [x0, x1, lsl #3]
   21340:      	ldr	x0, [sp, #0x100]
   21344:      	cmp	x2, x0
   21348:      	b.lo	0x215b8 <_mech_canonical_program_entry_v1_numeric_1282+0x3a38>
   2134c:      	b	0x24078 <_mech_canonical_program_entry_v1_numeric_1282+0x64f8>
   21350:      	ldr	x3, [x19, #0x4c68]
   21354:      	ldr	x4, [x19, #0x4c70]
   21358:      	mov	x7, #0x0                ; =0
   2135c:      	str	x7, [x19, #0x4c60]
   21360:      	mov	x0, #0x3                ; =3
   21364:      	ldr	x15, [sp, #0x180]
   21368:      	stur	x0, [sp, #0xb8]
   2136c:      	cmp	x15, #0x19a
   21370:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   21374:      	ldr	x11, [x19, #0x4f70]
   21378:      	ldr	x0, [sp, #0x188]
   2137c:      	str	x11, [x0, #0x10]
   21380:      	ldr	x12, [x19, #0x4f78]
   21384:      	str	x12, [x0, #0x18]
   21388:      	ldr	x13, [x19, #0x5a20]
   2138c:      	str	x13, [x0, #0xac0]
   21390:      	str	x11, [x0, #0x10]
   21394:      	str	x12, [x0, #0x18]
   21398:      	ldr	x0, [x19, #0x50c0]
   2139c:      	ldr	x1, [sp, #0x188]
   213a0:      	str	x0, [x1, #0x160]
   213a4:      	ldr	x0, [x19, #0x50c8]
   213a8:      	str	x0, [x1, #0x168]
   213ac:      	ldr	x0, [x19, #0x50d0]
   213b0:      	str	x0, [x1, #0x170]
   213b4:      	ldr	x0, [x19, #0x50d8]
   213b8:      	str	x0, [x1, #0x178]
   213bc:      	ldr	x0, [x19, #0x50e0]
   213c0:      	str	x0, [x1, #0x180]
   213c4:      	ldr	x0, [x19, #0x50e8]
   213c8:      	str	x0, [x1, #0x188]
   213cc:      	ldr	x0, [x19, #0x50f0]
   213d0:      	str	x0, [x1, #0x190]
   213d4:      	ldr	x0, [x19, #0x50f8]
   213d8:      	ldr	x5, [sp, #0x188]
   213dc:      	str	x0, [x5, #0x198]
   213e0:      	ldr	x0, [x19, #0x5100]
   213e4:      	ldr	x7, [sp, #0x188]
   213e8:      	str	x0, [x7, #0x1a0]
   213ec:      	ldr	x0, [x19, #0x52a8]
   213f0:      	ldr	x10, [sp, #0x188]
   213f4:      	str	x0, [x10, #0x348]
   213f8:      	ldr	x0, [x19, #0x52b0]
   213fc:      	ldr	x13, [sp, #0x188]
   21400:      	str	x0, [x13, #0x350]
   21404:      	ldr	x0, [x19, #0x52b8]
   21408:      	str	x0, [x1, #0x358]
   2140c:      	ldr	x0, [x19, #0x52c0]
   21410:      	str	x0, [x1, #0x360]
   21414:      	ldr	x0, [x19, #0x52c8]
   21418:      	str	x0, [x1, #0x368]
   2141c:      	ldr	x0, [x19, #0x52d0]
   21420:      	str	x0, [x1, #0x370]
   21424:      	ldr	x0, [x19, #0x52d8]
   21428:      	str	x0, [x1, #0x378]
   2142c:      	ldr	x0, [x19, #0x52e0]
   21430:      	str	x0, [x1, #0x380]
   21434:      	ldr	x0, [x19, #0x52e8]
   21438:      	str	x0, [x1, #0x388]
   2143c:      	ldr	x0, [x19, #0x55d8]
   21440:      	str	x0, [x1, #0x678]
   21444:      	ldr	x0, [x19, #0x55e0]
   21448:      	str	x0, [x1, #0x680]
   2144c:      	ldr	x0, [x19, #0x55e8]
   21450:      	str	x0, [x1, #0x688]
   21454:      	ldr	x0, [x19, #0x55f0]
   21458:      	str	x0, [x1, #0x690]
   2145c:      	ldr	x0, [x19, #0x55f8]
   21460:      	str	x0, [x1, #0x698]
   21464:      	ldr	x0, [x19, #0x5600]
   21468:      	str	x0, [x1, #0x6a0]
   2146c:      	ldr	x0, [x19, #0x5608]
   21470:      	str	x0, [x1, #0x6a8]
   21474:      	ldr	x0, [x19, #0x5610]
   21478:      	str	x0, [x1, #0x6b0]
   2147c:      	ldr	x0, [x19, #0x57a0]
   21480:      	str	x0, [x1, #0x840]
   21484:      	ldr	x0, [x19, #0x57a8]
   21488:      	str	x0, [x1, #0x848]
   2148c:      	ldr	x0, [x19, #0x57b0]
   21490:      	str	x0, [x5, #0x850]
   21494:      	ldr	x0, [x19, #0x57b8]
   21498:      	str	x0, [x7, #0x858]
   2149c:      	ldr	x0, [x19, #0x57c0]
   214a0:      	str	x0, [x10, #0x860]
   214a4:      	ldr	x0, [x19, #0x57c8]
   214a8:      	str	x0, [x13, #0x868]
   214ac:      	ldr	x0, [x19, #0x57d0]
   214b0:      	str	x0, [x1, #0x870]
   214b4:      	ldr	x0, [x19, #0x57d8]
   214b8:      	str	x0, [x1, #0x878]
   214bc:      	ldr	x0, [x19, #0x5bb0]
   214c0:      	str	x0, [x1, #0xc50]
   214c4:      	ldr	x0, [x19, #0x5bb8]
   214c8:      	str	x0, [x1, #0xc58]
   214cc:      	ldr	x0, [x19, #0x5bc0]
   214d0:      	str	x0, [x1, #0xc60]
   214d4:      	ldr	x0, [x19, #0x5bc8]
   214d8:      	str	x0, [x1, #0xc68]
   214dc:      	ldr	x0, [x19, #0x5bd0]
   214e0:      	str	x0, [x1, #0xc70]
   214e4:      	ldr	x0, [x19, #0x5bd8]
   214e8:      	str	x0, [x1, #0xc78]
   214ec:      	mov	x0, #0x0                ; =0
   214f0:      	str	x0, [x1, #0xc80]
   214f4:      	ldr	x1, [x19, #0x5be8]
   214f8:      	ldr	x2, [sp, #0x188]
   214fc:      	str	x1, [x2, #0xc88]
   21500:      	ldr	x1, [x19, #0x5bf0]
   21504:      	str	x1, [x2, #0xc90]
   21508:      	ldr	x1, [sp, #0x188]
   2150c:      	str	x0, [x1, #0xc98]
   21510:      	ldr	x1, [x19, #0x5c00]
   21514:      	str	x1, [x2, #0xca0]
   21518:      	ldr	x1, [x19, #0x5c08]
   2151c:      	str	x1, [x2, #0xca8]
   21520:      	ldr	x1, [sp, #0x188]
   21524:      	str	x0, [x1, #0xcb0]
   21528:      	ldr	x0, [x19, #0x5c18]
   2152c:      	str	x0, [x1, #0xcb8]
   21530:      	ldr	x1, [x19, #0x5c20]
   21534:      	ldr	x0, [sp, #0x188]
   21538:      	str	x1, [x0, #0xcc0]
   2153c:      	mov	x1, #0x609              ; =1545
   21540:      	mov	x2, #-0x9               ; =-9
   21544:      	ldr	x7, [sp, #0x198]
   21548:      	ldur	x0, [sp, #0x8]
   2154c:      	mov	x5, x21
   21550:      	ldr	x6, [sp, #0x190]
   21554:      	blr	x7
   21558:      	cmp	x0, #0x0
   2155c:      	b.ne	0x241f0 <_mech_canonical_program_entry_v1_numeric_1282+0x6670>
   21560:      	mov	x0, #0x3                ; =3
   21564:      	ldr	x15, [sp, #0x180]
   21568:      	stur	x0, [sp, #0xb8]
   2156c:      	cmp	x15, #0x2
   21570:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   21574:      	mov	x5, #0x0                ; =0
   21578:      	ldr	x3, [sp, #0x188]
   2157c:      	str	x5, [x3]
   21580:      	ldr	x10, [x19, #0x1cd8]
   21584:      	str	x10, [x3, #0x8]
   21588:      	mov	x1, #0x609              ; =1545
   2158c:      	ldur	x0, [sp, #0x8]
   21590:      	ldr	x6, [sp, #0x190]
   21594:      	ldr	x7, [sp, #0x198]
   21598:      	mov	x4, x21
   2159c:      	mov	x2, x5
   215a0:      	blr	x7
   215a4:      	cmp	x0, #0x0
   215a8:      	b.ne	0x241f8 <_mech_canonical_program_entry_v1_numeric_1282+0x6678>
   215ac:      	mov	x0, #0x3                ; =3
   215b0:      	stur	x0, [sp, #0xb8]
   215b4:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   215b8:      	ldr	x0, [sp, #0x108]
   215bc:      	ldr	x13, [x0, x2, lsl #3]
   215c0:      	mov	w0, #0x2646             ; =9798
   215c4:      	movk	w0, #0x1, lsl #16
   215c8:      	sub	x3, x3, x0
   215cc:      	mov	x2, #0x0                ; =0
   215d0:      	stur	x2, [sp, #0x48]
   215d4:      	ldur	x0, [sp, #0x58]
   215d8:      	ldur	x1, [sp, #0x10]
   215dc:      	ldur	x7, [sp, #0x60]
   215e0:      	ldur	x11, [sp, #0x68]
   215e4:      	ldur	x24, [sp, #0x70]
   215e8:      	mov	w2, #0xcb86             ; =52102
   215ec:      	movk	w2, #0x2, lsl #16
   215f0:      	cmp	x3, x2
   215f4:      	cset	x2, hs
   215f8:      	ldur	x4, [sp, #0xe8]
   215fc:      	and	w2, w2, w4
   21600:      	uxtb	w2, w2
   21604:      	cbnz	x2, 0x21a14 <_mech_canonical_program_entry_v1_numeric_1282+0x3e94>
   21608:      	mov	x5, #0x0                ; =0
   2160c:      	str	x5, [x19, #0x18]
   21610:      	str	x26, [x19, #0x20]
   21614:      	mov	x2, #0x1                ; =1
   21618:      	str	x2, [x19, #0x30]
   2161c:      	mov	x4, #0x101010101010101  ; =72340172838076673
   21620:      	str	x4, [x19, #0x38]
   21624:      	mov	x20, #0x2               ; =2
   21628:      	str	x20, [x19, #0x40]
   2162c:      	mov	x4, #0x3                ; =3
   21630:      	str	x4, [x19, #0x48]
   21634:      	mov	x4, #0x4                ; =4
   21638:      	str	x4, [x19, #0x50]
   2163c:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   21640:      	str	x4, [x19, #0x78]
   21644:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   21648:      	str	x4, [x19, #0x88]
   2164c:      	mov	x4, #0x38               ; =56
   21650:      	str	x4, [x19, #0x90]
   21654:      	mov	x4, #0x3a               ; =58
   21658:      	str	x4, [x19, #0x98]
   2165c:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   21660:      	str	x4, [x19, #0xb0]
   21664:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   21668:      	str	x4, [x19, #0xb8]
   2166c:      	str	x5, [x19, #0x188]
   21670:      	str	x2, [x19, #0x190]
   21674:      	str	x22, [x19, #0x17a0]
   21678:      	str	x23, [x19, #0x17a8]
   2167c:      	ldur	x4, [sp, #0xe0]
   21680:      	uxtb	w4, w4
   21684:      	str	x4, [x19, #0x17b8]
   21688:      	str	x15, [x19, #0x1c70]
   2168c:      	str	x12, [x19, #0x1c78]
   21690:      	str	x22, [x19, #0x1c80]
   21694:      	str	x25, [x19, #0x1ca8]
   21698:      	str	x10, [x19, #0x4c60]
   2169c:      	str	x3, [x19, #0x4c68]
   216a0:      	ldur	x4, [sp, #0x80]
   216a4:      	str	x4, [x19, #0x4c70]
   216a8:      	str	x22, [x19, #0x4f70]
   216ac:      	str	x23, [x19, #0x4f78]
   216b0:      	str	x15, [x19, #0x55d8]
   216b4:      	str	x12, [x19, #0x55e0]
   216b8:      	str	x22, [x19, #0x55e8]
   216bc:      	ldur	x25, [sp, #0x10]
   216c0:      	str	x25, [x19, #0x55f0]
   216c4:      	ldur	x4, [sp, #0x58]
   216c8:      	str	x4, [x19, #0x55f8]
   216cc:      	ldur	x4, [sp, #0x60]
   216d0:      	str	x4, [x19, #0x5600]
   216d4:      	ldur	x25, [sp, #0x68]
   216d8:      	str	x25, [x19, #0x5608]
   216dc:      	ldur	x26, [sp, #0x70]
   216e0:      	str	x26, [x19, #0x5610]
   216e4:      	ldur	x25, [sp, #0x10]
   216e8:      	str	x25, [x19, #0x5680]
   216ec:      	ldur	x4, [sp, #0x58]
   216f0:      	str	x4, [x19, #0x5688]
   216f4:      	ldur	x4, [sp, #0x60]
   216f8:      	str	x4, [x19, #0x5690]
   216fc:      	ldur	x25, [sp, #0x68]
   21700:      	str	x25, [x19, #0x5698]
   21704:      	str	x26, [x19, #0x56a0]
   21708:      	str	x27, [x19, #0x57a0]
   2170c:      	str	x13, [x19, #0x57a8]
   21710:      	str	x22, [x19, #0x57b0]
   21714:      	str	x1, [x19, #0x57b8]
   21718:      	str	x0, [x19, #0x57c0]
   2171c:      	str	x7, [x19, #0x57c8]
   21720:      	str	x11, [x19, #0x57d0]
   21724:      	str	x24, [x19, #0x57d8]
   21728:      	ldur	x1, [sp, #0x50]
   2172c:      	str	x1, [x19, #0x5a20]
   21730:      	add	x11, x8, #0x1
   21734:      	str	x11, [x19, #0x5bb0]
   21738:      	ldur	x26, [sp, #0x88]
   2173c:      	str	x26, [x19, #0x5bb8]
   21740:      	ldur	x6, [sp, #0x90]
   21744:      	str	x6, [x19, #0x5bc0]
   21748:      	ldur	x4, [sp, #0x78]
   2174c:      	sub	x14, x4, x3
   21750:      	mov	w15, #0xc87e            ; =51326
   21754:      	movk	w15, #0x1, lsl #16
   21758:      	msub	x14, x11, x15, x14
   2175c:      	str	x14, [x19, #0x5bc8]
   21760:      	str	x5, [x19, #0x5bd0]
   21764:      	str	x5, [x19, #0x5bd8]
   21768:      	ldur	x10, [sp, #0x98]
   2176c:      	str	x10, [x19, #0x5be8]
   21770:      	ldur	x4, [sp, #0xa0]
   21774:      	str	x4, [x19, #0x5bf0]
   21778:      	str	x2, [x19, #0x5c00]
   2177c:      	ldur	x7, [sp, #0x40]
   21780:      	str	x7, [x19, #0x5c08]
   21784:      	str	x2, [x19, #0x5c18]
   21788:      	ldur	x5, [sp, #0x48]
   2178c:      	str	x5, [x19, #0x5c20]
   21790:      	ldr	x0, [x19, #0x4c60]
   21794:      	cmp	x0, #0x0
   21798:      	b.eq	0x219ec <_mech_canonical_program_entry_v1_numeric_1282+0x3e6c>
   2179c:      	ldr	x3, [x19, #0x4c68]
   217a0:      	ldr	x4, [x19, #0x4c70]
   217a4:      	mov	x0, #0x0                ; =0
   217a8:      	str	x0, [x19, #0x4c60]
   217ac:      	mov	x0, #0x3                ; =3
   217b0:      	ldr	x15, [sp, #0x180]
   217b4:      	stur	x0, [sp, #0xb8]
   217b8:      	cmp	x15, #0x19a
   217bc:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   217c0:      	ldr	x0, [x19, #0x4f70]
   217c4:      	ldr	x12, [sp, #0x188]
   217c8:      	str	x0, [x12, #0x10]
   217cc:      	ldr	x1, [x19, #0x4f78]
   217d0:      	ldr	x15, [sp, #0x188]
   217d4:      	str	x1, [x15, #0x18]
   217d8:      	ldr	x2, [x19, #0x5a20]
   217dc:      	ldr	x5, [sp, #0x188]
   217e0:      	str	x2, [x5, #0xac0]
   217e4:      	ldr	x2, [x19, #0x5680]
   217e8:      	str	x2, [x5, #0x720]
   217ec:      	ldr	x2, [x19, #0x5688]
   217f0:      	str	x2, [x5, #0x728]
   217f4:      	ldr	x2, [x19, #0x5690]
   217f8:      	str	x2, [x5, #0x730]
   217fc:      	ldr	x2, [x19, #0x5698]
   21800:      	str	x2, [x5, #0x738]
   21804:      	ldr	x2, [x19, #0x56a0]
   21808:      	str	x2, [x5, #0x740]
   2180c:      	ldr	x2, [sp, #0x188]
   21810:      	str	x0, [x2, #0x10]
   21814:      	ldr	x0, [sp, #0x188]
   21818:      	str	x1, [x0, #0x18]
   2181c:      	ldr	x0, [x19, #0x50c0]
   21820:      	ldr	x1, [sp, #0x188]
   21824:      	str	x0, [x1, #0x160]
   21828:      	ldr	x0, [x19, #0x50c8]
   2182c:      	str	x0, [x1, #0x168]
   21830:      	ldr	x0, [x19, #0x50d0]
   21834:      	str	x0, [x1, #0x170]
   21838:      	ldr	x0, [x19, #0x50d8]
   2183c:      	str	x0, [x1, #0x178]
   21840:      	ldr	x0, [x19, #0x50e0]
   21844:      	str	x0, [x1, #0x180]
   21848:      	ldr	x0, [x19, #0x50e8]
   2184c:      	str	x0, [x1, #0x188]
   21850:      	ldr	x0, [x19, #0x50f0]
   21854:      	str	x0, [x1, #0x190]
   21858:      	ldr	x0, [x19, #0x50f8]
   2185c:      	str	x0, [x1, #0x198]
   21860:      	ldr	x0, [x19, #0x5100]
   21864:      	str	x0, [x1, #0x1a0]
   21868:      	ldr	x0, [x19, #0x52a8]
   2186c:      	str	x0, [x5, #0x348]
   21870:      	ldr	x0, [x19, #0x52b0]
   21874:      	ldr	x7, [sp, #0x188]
   21878:      	str	x0, [x7, #0x350]
   2187c:      	ldr	x0, [x19, #0x52b8]
   21880:      	ldr	x10, [sp, #0x188]
   21884:      	str	x0, [x10, #0x358]
   21888:      	ldr	x0, [x19, #0x52c0]
   2188c:      	ldr	x13, [sp, #0x188]
   21890:      	str	x0, [x13, #0x360]
   21894:      	ldr	x0, [x19, #0x52c8]
   21898:      	str	x0, [x1, #0x368]
   2189c:      	ldr	x0, [x19, #0x52d0]
   218a0:      	str	x0, [x1, #0x370]
   218a4:      	ldr	x0, [x19, #0x52d8]
   218a8:      	str	x0, [x1, #0x378]
   218ac:      	ldr	x0, [x19, #0x52e0]
   218b0:      	str	x0, [x1, #0x380]
   218b4:      	ldr	x0, [x19, #0x52e8]
   218b8:      	str	x0, [x1, #0x388]
   218bc:      	ldr	x0, [x19, #0x55d8]
   218c0:      	str	x0, [x1, #0x678]
   218c4:      	ldr	x0, [x19, #0x55e0]
   218c8:      	str	x0, [x1, #0x680]
   218cc:      	ldr	x0, [x19, #0x55e8]
   218d0:      	str	x0, [x1, #0x688]
   218d4:      	ldr	x0, [x19, #0x55f0]
   218d8:      	str	x0, [x1, #0x690]
   218dc:      	ldr	x0, [x19, #0x55f8]
   218e0:      	str	x0, [x1, #0x698]
   218e4:      	ldr	x0, [x19, #0x5600]
   218e8:      	str	x0, [x1, #0x6a0]
   218ec:      	ldr	x1, [x19, #0x5608]
   218f0:      	ldr	x0, [sp, #0x188]
   218f4:      	str	x1, [x0, #0x6a8]
   218f8:      	ldr	x2, [x19, #0x5610]
   218fc:      	str	x2, [x0, #0x6b0]
   21900:      	ldr	x5, [x19, #0x57a0]
   21904:      	str	x5, [x0, #0x840]
   21908:      	ldr	x5, [x19, #0x57a8]
   2190c:      	str	x5, [x0, #0x848]
   21910:      	ldr	x5, [x19, #0x57b0]
   21914:      	str	x5, [x0, #0x850]
   21918:      	ldr	x6, [x19, #0x57b8]
   2191c:      	ldr	x1, [sp, #0x188]
   21920:      	str	x6, [x1, #0x858]
   21924:      	ldr	x7, [x19, #0x57c0]
   21928:      	ldr	x5, [sp, #0x188]
   2192c:      	str	x7, [x5, #0x860]
   21930:      	ldr	x8, [x19, #0x57c8]
   21934:      	ldr	x7, [sp, #0x188]
   21938:      	str	x8, [x7, #0x868]
   2193c:      	ldr	x9, [x19, #0x57d0]
   21940:      	str	x9, [x10, #0x870]
   21944:      	ldr	x10, [x19, #0x57d8]
   21948:      	str	x10, [x13, #0x878]
   2194c:      	ldr	x11, [x19, #0x5bb0]
   21950:      	str	x11, [x0, #0xc50]
   21954:      	ldr	x12, [x19, #0x5bb8]
   21958:      	str	x12, [x0, #0xc58]
   2195c:      	ldr	x13, [x19, #0x5bc0]
   21960:      	str	x13, [x0, #0xc60]
   21964:      	ldr	x14, [x19, #0x5bc8]
   21968:      	str	x14, [x0, #0xc68]
   2196c:      	ldr	x15, [x19, #0x5bd0]
   21970:      	str	x15, [x0, #0xc70]
   21974:      	ldr	x0, [x19, #0x5bd8]
   21978:      	str	x0, [x1, #0xc78]
   2197c:      	mov	x0, #0x0                ; =0
   21980:      	str	x0, [x1, #0xc80]
   21984:      	ldr	x1, [x19, #0x5be8]
   21988:      	ldr	x2, [sp, #0x188]
   2198c:      	str	x1, [x2, #0xc88]
   21990:      	ldr	x1, [x19, #0x5bf0]
   21994:      	str	x1, [x2, #0xc90]
   21998:      	ldr	x1, [sp, #0x188]
   2199c:      	str	x0, [x1, #0xc98]
   219a0:      	ldr	x1, [x19, #0x5c00]
   219a4:      	str	x1, [x2, #0xca0]
   219a8:      	ldr	x1, [x19, #0x5c08]
   219ac:      	str	x1, [x2, #0xca8]
   219b0:      	ldr	x1, [sp, #0x188]
   219b4:      	str	x0, [x1, #0xcb0]
   219b8:      	ldr	x0, [x19, #0x5c18]
   219bc:      	str	x0, [x1, #0xcb8]
   219c0:      	ldr	x0, [x19, #0x5c20]
   219c4:      	str	x0, [x1, #0xcc0]
   219c8:      	mov	x1, #0x611              ; =1553
   219cc:      	mov	x2, #-0x9               ; =-9
   219d0:      	mov	x5, #0x1                ; =1
   219d4:      	ldur	x0, [sp, #0x8]
   219d8:      	ldr	x6, [sp, #0x190]
   219dc:      	ldr	x21, [sp, #0x198]
   219e0:      	blr	x21
   219e4:      	cmp	x0, #0x0
   219e8:      	b.ne	0x24200 <_mech_canonical_program_entry_v1_numeric_1282+0x6680>
   219ec:      	mov	x0, #0x0                ; =0
   219f0:      	mov	x1, #0x5                ; =5
   219f4:      	add	sp, sp, #0x1b0
   219f8:      	ldp	x19, x20, [sp], #0x10
   219fc:      	ldp	x21, x22, [sp], #0x10
   21a00:      	ldp	x23, x24, [sp], #0x10
   21a04:      	ldp	x25, x26, [sp], #0x10
   21a08:      	ldp	x27, x28, [sp], #0x10
   21a0c:      	ldp	x29, x30, [sp], #0x10
   21a10:      	retab
   21a14:      	cmp	x27, x13
   21a18:      	cset	x4, lo
   21a1c:      	cmp	x27, x13
   21a20:      	b.lo	0x21a2c <_mech_canonical_program_entry_v1_numeric_1282+0x3eac>
   21a24:      	mov	x2, #0x0                ; =0
   21a28:      	b	0x21cc4 <_mech_canonical_program_entry_v1_numeric_1282+0x4144>
   21a2c:      	ldur	x2, [sp, #0xf0]
   21a30:      	cmp	x27, x2
   21a34:      	b.lo	0x21cbc <_mech_canonical_program_entry_v1_numeric_1282+0x413c>
   21a38:      	b	0x24208 <_mech_canonical_program_entry_v1_numeric_1282+0x6688>
   21a3c:      	ldr	x3, [x19, #0x4c68]
   21a40:      	ldr	x4, [x19, #0x4c70]
   21a44:      	mov	x0, #0x0                ; =0
   21a48:      	str	x0, [x19, #0x4c60]
   21a4c:      	mov	x0, #0x3                ; =3
   21a50:      	ldr	x15, [sp, #0x180]
   21a54:      	stur	x0, [sp, #0xb8]
   21a58:      	cmp	x15, #0x19a
   21a5c:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   21a60:      	ldr	x0, [x19, #0x4f70]
   21a64:      	ldr	x1, [sp, #0x188]
   21a68:      	str	x0, [x1, #0x10]
   21a6c:      	ldr	x1, [x19, #0x4f78]
   21a70:      	ldr	x5, [sp, #0x188]
   21a74:      	str	x1, [x5, #0x18]
   21a78:      	ldr	x2, [x19, #0x5a20]
   21a7c:      	ldr	x7, [sp, #0x188]
   21a80:      	str	x2, [x7, #0xac0]
   21a84:      	ldr	x9, [sp, #0x188]
   21a88:      	str	x0, [x9, #0x10]
   21a8c:      	ldr	x11, [sp, #0x188]
   21a90:      	str	x1, [x11, #0x18]
   21a94:      	ldr	x0, [x19, #0x50c0]
   21a98:      	ldr	x14, [sp, #0x188]
   21a9c:      	str	x0, [x14, #0x160]
   21aa0:      	ldr	x0, [x19, #0x50c8]
   21aa4:      	ldr	x1, [sp, #0x188]
   21aa8:      	str	x0, [x1, #0x168]
   21aac:      	ldr	x1, [x19, #0x50d0]
   21ab0:      	ldr	x0, [sp, #0x188]
   21ab4:      	str	x1, [x0, #0x170]
   21ab8:      	ldr	x2, [x19, #0x50d8]
   21abc:      	str	x2, [x0, #0x178]
   21ac0:      	ldr	x5, [x19, #0x50e0]
   21ac4:      	str	x5, [x0, #0x180]
   21ac8:      	ldr	x5, [x19, #0x50e8]
   21acc:      	str	x5, [x0, #0x188]
   21ad0:      	ldr	x5, [x19, #0x50f0]
   21ad4:      	str	x5, [x0, #0x190]
   21ad8:      	ldr	x6, [x19, #0x50f8]
   21adc:      	str	x6, [x0, #0x198]
   21ae0:      	ldr	x7, [x19, #0x5100]
   21ae4:      	str	x7, [x0, #0x1a0]
   21ae8:      	ldr	x8, [x19, #0x52a8]
   21aec:      	str	x8, [x0, #0x348]
   21af0:      	ldr	x9, [x19, #0x52b0]
   21af4:      	str	x9, [x0, #0x350]
   21af8:      	ldr	x10, [x19, #0x52b8]
   21afc:      	str	x10, [x0, #0x358]
   21b00:      	ldr	x11, [x19, #0x52c0]
   21b04:      	str	x11, [x0, #0x360]
   21b08:      	ldr	x12, [x19, #0x52c8]
   21b0c:      	str	x12, [x0, #0x368]
   21b10:      	ldr	x13, [x19, #0x52d0]
   21b14:      	str	x13, [x0, #0x370]
   21b18:      	ldr	x14, [x19, #0x52d8]
   21b1c:      	str	x14, [x0, #0x378]
   21b20:      	ldr	x15, [x19, #0x52e0]
   21b24:      	str	x15, [x0, #0x380]
   21b28:      	ldr	x0, [x19, #0x52e8]
   21b2c:      	ldr	x2, [sp, #0x188]
   21b30:      	str	x0, [x2, #0x388]
   21b34:      	ldr	x0, [x19, #0x55d8]
   21b38:      	ldr	x5, [sp, #0x188]
   21b3c:      	str	x0, [x5, #0x678]
   21b40:      	ldr	x0, [x19, #0x55e0]
   21b44:      	ldr	x8, [sp, #0x188]
   21b48:      	str	x0, [x8, #0x680]
   21b4c:      	ldr	x0, [x19, #0x55e8]
   21b50:      	ldr	x11, [sp, #0x188]
   21b54:      	str	x0, [x11, #0x688]
   21b58:      	ldr	x0, [x19, #0x55f0]
   21b5c:      	ldr	x14, [sp, #0x188]
   21b60:      	str	x0, [x14, #0x690]
   21b64:      	ldr	x0, [x19, #0x55f8]
   21b68:      	ldr	x1, [sp, #0x188]
   21b6c:      	str	x0, [x1, #0x698]
   21b70:      	ldr	x0, [x19, #0x5600]
   21b74:      	str	x0, [x1, #0x6a0]
   21b78:      	ldr	x0, [x19, #0x5608]
   21b7c:      	str	x0, [x1, #0x6a8]
   21b80:      	ldr	x0, [x19, #0x5610]
   21b84:      	str	x0, [x1, #0x6b0]
   21b88:      	ldr	x0, [x19, #0x57a0]
   21b8c:      	str	x0, [x1, #0x840]
   21b90:      	ldr	x0, [x19, #0x57a8]
   21b94:      	str	x0, [x1, #0x848]
   21b98:      	ldr	x0, [x19, #0x57b0]
   21b9c:      	str	x0, [x1, #0x850]
   21ba0:      	ldr	x0, [x19, #0x57b8]
   21ba4:      	str	x0, [x1, #0x858]
   21ba8:      	ldr	x0, [x19, #0x57c0]
   21bac:      	str	x0, [x1, #0x860]
   21bb0:      	ldr	x0, [x19, #0x57c8]
   21bb4:      	str	x0, [x1, #0x868]
   21bb8:      	ldr	x0, [x19, #0x57d0]
   21bbc:      	str	x0, [x1, #0x870]
   21bc0:      	ldr	x0, [x19, #0x57d8]
   21bc4:      	str	x0, [x1, #0x878]
   21bc8:      	ldr	x0, [x19, #0x5bb0]
   21bcc:      	str	x0, [x1, #0xc50]
   21bd0:      	ldr	x0, [x19, #0x5bb8]
   21bd4:      	str	x0, [x1, #0xc58]
   21bd8:      	ldr	x0, [x19, #0x5bc0]
   21bdc:      	str	x0, [x1, #0xc60]
   21be0:      	ldr	x0, [x19, #0x5bc8]
   21be4:      	str	x0, [x1, #0xc68]
   21be8:      	ldr	x0, [x19, #0x5bd0]
   21bec:      	str	x0, [x2, #0xc70]
   21bf0:      	ldr	x0, [x19, #0x5bd8]
   21bf4:      	str	x0, [x5, #0xc78]
   21bf8:      	mov	x0, #0x0                ; =0
   21bfc:      	str	x0, [x8, #0xc80]
   21c00:      	ldr	x1, [x19, #0x5be8]
   21c04:      	str	x1, [x11, #0xc88]
   21c08:      	ldr	x1, [x19, #0x5bf0]
   21c0c:      	str	x1, [x14, #0xc90]
   21c10:      	ldr	x1, [sp, #0x188]
   21c14:      	str	x0, [x1, #0xc98]
   21c18:      	ldr	x1, [x19, #0x5c00]
   21c1c:      	str	x1, [x2, #0xca0]
   21c20:      	ldr	x1, [x19, #0x5c08]
   21c24:      	str	x1, [x2, #0xca8]
   21c28:      	ldr	x1, [sp, #0x188]
   21c2c:      	str	x0, [x1, #0xcb0]
   21c30:      	ldr	x0, [x19, #0x5c18]
   21c34:      	str	x0, [x1, #0xcb8]
   21c38:      	ldr	x0, [x19, #0x5c20]
   21c3c:      	str	x0, [x1, #0xcc0]
   21c40:      	mov	x1, #0x621              ; =1569
   21c44:      	mov	x2, #-0x9               ; =-9
   21c48:      	ldr	x21, [sp, #0x198]
   21c4c:      	ldur	x0, [sp, #0x8]
   21c50:      	mov	x5, x20
   21c54:      	ldr	x6, [sp, #0x190]
   21c58:      	blr	x21
   21c5c:      	cmp	x0, #0x0
   21c60:      	b.ne	0x243b0 <_mech_canonical_program_entry_v1_numeric_1282+0x6830>
   21c64:      	mov	x0, #0x3                ; =3
   21c68:      	ldr	x15, [sp, #0x180]
   21c6c:      	stur	x0, [sp, #0xb8]
   21c70:      	cmp	x15, #0x2
   21c74:      	b.lo	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   21c78:      	mov	x5, #0x0                ; =0
   21c7c:      	ldr	x3, [sp, #0x188]
   21c80:      	str	x5, [x3]
   21c84:      	ldr	x0, [x19, #0x1d68]
   21c88:      	str	x0, [x3, #0x8]
   21c8c:      	mov	x1, #0x621              ; =1569
   21c90:      	ldur	x0, [sp, #0x8]
   21c94:      	ldr	x6, [sp, #0x190]
   21c98:      	ldr	x21, [sp, #0x198]
   21c9c:      	mov	x4, x20
   21ca0:      	mov	x2, x5
   21ca4:      	blr	x21
   21ca8:      	cmp	x0, #0x0
   21cac:      	b.ne	0x243b8 <_mech_canonical_program_entry_v1_numeric_1282+0x6838>
   21cb0:      	mov	x0, #0x3                ; =3
   21cb4:      	stur	x0, [sp, #0xb8]
   21cb8:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   21cbc:      	ldur	x5, [sp, #0xf8]
   21cc0:      	ldr	x2, [x5, x27, lsl #3]
   21cc4:      	mov	x9, #0x3ffffffffffffff  ; =288230376151711743
   21cc8:      	stur	x9, [sp, #0xc0]
   21ccc:      	eor	x6, x2, #0x3ffffffffffffff
   21cd0:      	orr	x9, x6, #0xc00000000000000
   21cd4:      	cmp	x9, x24
   21cd8:      	cset	x9, hi
   21cdc:      	and	w9, w4, w9
   21ce0:      	uxtb	w5, w9
   21ce4:      	tbnz	w5, #0x0, 0x21d00 <_mech_canonical_program_entry_v1_numeric_1282+0x4180>
   21ce8:      	mov	x2, x1
   21cec:      	mov	x4, x0
   21cf0:      	mov	x6, x7
   21cf4:      	mov	x9, x11
   21cf8:      	mov	x20, x24
   21cfc:      	b	0x21dc4 <_mech_canonical_program_entry_v1_numeric_1282+0x4244>
   21d00:      	cmp	x2, x22
   21d04:      	b.ne	0x21d20 <_mech_canonical_program_entry_v1_numeric_1282+0x41a0>
   21d08:      	mov	x2, x1
   21d0c:      	mov	x4, x0
   21d10:      	mov	x6, x7
   21d14:      	mov	x9, x11
   21d18:      	mov	x20, x24
   21d1c:      	b	0x21dc4 <_mech_canonical_program_entry_v1_numeric_1282+0x4244>
   21d20:      	and	x4, x1, #0x3ffffffffffffff
   21d24:      	eor	x2, x2, #0x3ffffffffffffff
   21d28:      	cmp	x2, x4
   21d2c:      	cset	x4, ne
   21d30:      	and	x9, x0, #0x3ffffffffffffff
   21d34:      	cmp	x2, x9
   21d38:      	cset	x9, ne
   21d3c:      	and	w4, w4, w9
   21d40:      	and	x9, x7, #0x3ffffffffffffff
   21d44:      	cmp	x2, x9
   21d48:      	cset	x9, ne
   21d4c:      	and	w4, w4, w9
   21d50:      	and	x9, x11, #0x3ffffffffffffff
   21d54:      	cmp	x2, x9
   21d58:      	cset	x2, ne
   21d5c:      	and	w2, w4, w2
   21d60:      	uxtb	w2, w2
   21d64:      	tbnz	w2, #0x0, 0x21d80 <_mech_canonical_program_entry_v1_numeric_1282+0x4200>
   21d68:      	mov	x2, x1
   21d6c:      	mov	x4, x0
   21d70:      	mov	x6, x7
   21d74:      	mov	x9, x11
   21d78:      	mov	x20, x24
   21d7c:      	b	0x21dc4 <_mech_canonical_program_entry_v1_numeric_1282+0x4244>
   21d80:      	orr	x9, x6, #0xc00000000000000
   21d84:      	cmp	x9, x1
   21d88:      	csel	x2, x9, x1, hi
   21d8c:      	cmp	x9, x1
   21d90:      	csel	x9, x9, x1, lo
   21d94:      	cmp	x9, x0
   21d98:      	csel	x4, x9, x0, hi
   21d9c:      	cmp	x9, x0
   21da0:      	csel	x9, x9, x0, lo
   21da4:      	cmp	x9, x7
   21da8:      	csel	x6, x9, x7, hi
   21dac:      	cmp	x9, x7
   21db0:      	csel	x20, x9, x7, lo
   21db4:      	cmp	x20, x11
   21db8:      	csel	x9, x20, x11, hi
   21dbc:      	cmp	x20, x11
   21dc0:      	csel	x20, x20, x11, lo
   21dc4:      	tbnz	w5, #0x0, 0x22884 <_mech_canonical_program_entry_v1_numeric_1282+0x4d04>
   21dc8:      	mov	x2, #0x0                ; =0
   21dcc:      	str	x2, [x28, #0x1fc0]
   21dd0:      	str	x2, [x28, #0x1fc8]
   21dd4:      	str	x2, [x28, #0x1fd0]
   21dd8:      	str	x2, [x28, #0x1fd8]
   21ddc:      	str	x2, [x28, #0x1fe0]
   21de0:      	str	x2, [x28, #0x1fe8]
   21de4:      	str	x2, [x28, #0x1ff0]
   21de8:      	str	x2, [x28, #0x1ff8]
   21dec:      	str	x2, [x28, #0x2000]
   21df0:      	str	x2, [x28, #0x2008]
   21df4:      	str	x2, [x28, #0x2010]
   21df8:      	str	x2, [x28, #0x2018]
   21dfc:      	str	x2, [x28, #0x2020]
   21e00:      	str	x2, [x28, #0x2028]
   21e04:      	str	x2, [x28, #0x2030]
   21e08:      	str	x2, [x28, #0x2038]
   21e0c:      	mov	w2, #0xcb86             ; =52102
   21e10:      	movk	w2, #0x2, lsl #16
   21e14:      	sub	x3, x3, x2
   21e18:      	mov	x13, #0x0               ; =0
   21e1c:      	stur	x13, [sp, #0xa8]
   21e20:      	tbnz	w25, #0x0, 0x22854 <_mech_canonical_program_entry_v1_numeric_1282+0x4cd4>
   21e24:      	mov	x0, #0x0                ; =0
   21e28:      	str	x0, [x28, #0x1c30]
   21e2c:      	str	x0, [x28, #0x1c38]
   21e30:      	str	x0, [x28, #0x1c40]
   21e34:      	str	x0, [x28, #0x1c48]
   21e38:      	str	x0, [x28, #0x1c50]
   21e3c:      	str	x0, [x28, #0x1c58]
   21e40:      	str	x0, [x28, #0x1c60]
   21e44:      	str	x0, [x28, #0x1c68]
   21e48:      	str	x0, [x28, #0x1c70]
   21e4c:      	str	x0, [x28, #0x1c78]
   21e50:      	str	x0, [x28, #0x1c80]
   21e54:      	str	x0, [x28, #0x1c88]
   21e58:      	str	x0, [x28, #0x1c90]
   21e5c:      	str	x0, [x28, #0x1c98]
   21e60:      	str	x0, [x28, #0x1ca0]
   21e64:      	str	x0, [x28, #0x1ca8]
   21e68:      	mov	x25, #0x0               ; =0
   21e6c:      	mov	x11, x25
   21e70:      	mov	x12, x25
   21e74:      	mov	x15, x25
   21e78:      	mov	x24, x22
   21e7c:      	mov	x27, x22
   21e80:      	cmp	x22, x23
   21e84:      	b.lo	0x21e90 <_mech_canonical_program_entry_v1_numeric_1282+0x4310>
   21e88:      	add	x8, x8, #0x1
   21e8c:      	b	0x22714 <_mech_canonical_program_entry_v1_numeric_1282+0x4b94>
   21e90:      	cbnz	x14, 0x22040 <_mech_canonical_program_entry_v1_numeric_1282+0x44c0>
   21e94:      	b	0x243c0 <_mech_canonical_program_entry_v1_numeric_1282+0x6840>
   21e98:      	ldr	x0, [sp, #0x188]
   21e9c:      	str	x27, [x0, #0x10]
   21ea0:      	str	x23, [x0, #0x18]
   21ea4:      	ldr	x2, [sp, #0x188]
   21ea8:      	str	x27, [x2, #0x10]
   21eac:      	ldr	x4, [sp, #0x188]
   21eb0:      	str	x23, [x4, #0x18]
   21eb4:      	add	x0, x8, #0x1
   21eb8:      	ldr	x7, [sp, #0x188]
   21ebc:      	str	x0, [x7, #0xc50]
   21ec0:      	ldr	x9, [sp, #0x188]
   21ec4:      	ldur	x26, [sp, #0x88]
   21ec8:      	str	x26, [x9, #0xc58]
   21ecc:      	ldur	x6, [sp, #0x90]
   21ed0:      	ldr	x14, [sp, #0x188]
   21ed4:      	str	x6, [x14, #0xc60]
   21ed8:      	ldur	x4, [sp, #0x78]
   21edc:      	sub	x1, x4, x3
   21ee0:      	mov	w2, #0xc87e             ; =51326
   21ee4:      	movk	w2, #0x1, lsl #16
   21ee8:      	msub	x0, x0, x2, x1
   21eec:      	ldr	x1, [sp, #0x188]
   21ef0:      	str	x0, [x1, #0xc68]
   21ef4:      	ldr	x0, [sp, #0x188]
   21ef8:      	str	x25, [x0, #0xc70]
   21efc:      	str	x15, [x0, #0xc78]
   21f00:      	mov	x5, #0x0                ; =0
   21f04:      	str	x5, [x0, #0xc80]
   21f08:      	ldur	x10, [sp, #0x98]
   21f0c:      	str	x10, [x0, #0xc88]
   21f10:      	ldur	x4, [sp, #0xa0]
   21f14:      	str	x4, [x0, #0xc90]
   21f18:      	str	x5, [x0, #0xc98]
   21f1c:      	str	x12, [x0, #0xca0]
   21f20:      	str	x11, [x0, #0xca8]
   21f24:      	str	x5, [x0, #0xcb0]
   21f28:      	str	x13, [x0, #0xcb8]
   21f2c:      	ldur	x13, [sp, #0xa8]
   21f30:      	str	x13, [x0, #0xcc0]
   21f34:      	ldur	x1, [sp, #0x50]
   21f38:      	add	x0, x1, #0x1
   21f3c:      	ldr	x1, [sp, #0x188]
   21f40:      	str	x0, [x1, #0xcd0]
   21f44:      	ldur	x25, [sp, #0x10]
   21f48:      	and	x0, x25, #0x3ffffffffffffff
   21f4c:      	eor	x0, x0, #0x3ffffffffffffff
   21f50:      	str	x0, [x1, #0xcd8]
   21f54:      	mov	x1, #0x6c4              ; =1732
   21f58:      	mov	x2, #-0x1b              ; =-27
   21f5c:      	ldur	x4, [sp, #0x80]
   21f60:      	ldr	x21, [sp, #0x198]
   21f64:      	ldur	x0, [sp, #0x8]
   21f68:      	ldr	x6, [sp, #0x190]
   21f6c:      	blr	x21
   21f70:      	mov	x1, #0x2                ; =2
   21f74:      	stur	x1, [sp, #0xb8]
   21f78:      	cmp	x0, #0x0
   21f7c:      	b.ne	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   21f80:      	ldr	x3, [sp, #0x188]
   21f84:      	ldr	x3, [x3]
   21f88:      	ldr	x0, [sp, #0x188]
   21f8c:      	ldr	x4, [x0, #0x8]
   21f90:      	stur	x4, [sp, #0x80]
   21f94:      	ldr	x21, [x0, #0xab8]
   21f98:      	ldr	x14, [x0, #0xbf8]
   21f9c:      	ldr	x1, [sp, #0x188]
   21fa0:      	ldr	x1, [x1, #0xac0]
   21fa4:      	ldr	x4, [sp, #0x188]
   21fa8:      	ldr	x0, [x4, #0xac8]
   21fac:      	ldr	x5, [sp, #0x188]
   21fb0:      	ldr	x0, [x5, #0xad0]
   21fb4:      	ldr	x7, [sp, #0x188]
   21fb8:      	ldr	x0, [x7, #0xc48]
   21fbc:      	ldr	x9, [sp, #0x188]
   21fc0:      	stur	x0, [sp, #0xb0]
   21fc4:      	ldr	x8, [x9, #0xc50]
   21fc8:      	ldr	x11, [sp, #0x188]
   21fcc:      	ldr	x26, [x11, #0xc58]
   21fd0:      	ldr	x13, [sp, #0x188]
   21fd4:      	stur	x26, [sp, #0x88]
   21fd8:      	ldr	x6, [x13, #0xc60]
   21fdc:      	ldr	x15, [sp, #0x188]
   21fe0:      	stur	x6, [sp, #0x90]
   21fe4:      	ldr	x0, [x15, #0xc68]
   21fe8:      	ldr	x2, [sp, #0x188]
   21fec:      	ldr	x25, [x2, #0xc70]
   21ff0:      	ldr	x15, [x2, #0xc78]
   21ff4:      	ldr	x10, [x2, #0xc88]
   21ff8:      	stur	x10, [sp, #0x98]
   21ffc:      	ldr	x4, [x2, #0xc90]
   22000:      	stur	x4, [sp, #0xa0]
   22004:      	ldr	x12, [x2, #0xca0]
   22008:      	ldr	x11, [x2, #0xca8]
   2200c:      	ldr	x13, [x2, #0xcb8]
   22010:      	ldr	x2, [x2, #0xcc0]
   22014:      	stur	x2, [sp, #0xa8]
   22018:      	ldr	x2, [sp, #0x188]
   2201c:      	ldr	x28, [x2, #0x10]
   22020:      	mov	x10, #0x1               ; =1
   22024:      	str	x10, [x19, #0x4c60]
   22028:      	add	x0, x3, x0
   2202c:      	mov	w2, #0xc87e             ; =51326
   22030:      	movk	w2, #0x1, lsl #16
   22034:      	madd	x4, x8, x2, x0
   22038:      	stur	x4, [sp, #0x78]
   2203c:      	b	0x2205c <_mech_canonical_program_entry_v1_numeric_1282+0x44dc>
   22040:      	ldur	x0, [sp, #0x10]
   22044:      	and	x0, x0, #0x3ffffffffffffff
   22048:      	eor	x0, x0, #0x3ffffffffffffff
   2204c:      	ldur	x1, [sp, #0x50]
   22050:      	str	x0, [x21, x1, lsl #3]
   22054:      	add	x1, x1, #0x1
   22058:      	add	x8, x8, #0x1
   2205c:      	cbnz	x14, 0x221f4 <_mech_canonical_program_entry_v1_numeric_1282+0x4674>
   22060:      	b	0x243ec <_mech_canonical_program_entry_v1_numeric_1282+0x686c>
   22064:      	ldr	x0, [sp, #0x188]
   22068:      	str	x27, [x0, #0x10]
   2206c:      	str	x23, [x0, #0x18]
   22070:      	ldr	x2, [sp, #0x188]
   22074:      	str	x27, [x2, #0x10]
   22078:      	ldr	x4, [sp, #0x188]
   2207c:      	str	x23, [x4, #0x18]
   22080:      	ldr	x6, [sp, #0x188]
   22084:      	str	x8, [x6, #0xc50]
   22088:      	ldr	x9, [sp, #0x188]
   2208c:      	ldur	x26, [sp, #0x88]
   22090:      	str	x26, [x9, #0xc58]
   22094:      	ldur	x6, [sp, #0x90]
   22098:      	ldr	x10, [sp, #0x188]
   2209c:      	str	x6, [x10, #0xc60]
   220a0:      	ldur	x4, [sp, #0x78]
   220a4:      	sub	x7, x4, x3
   220a8:      	mov	w9, #0xc87e             ; =51326
   220ac:      	movk	w9, #0x1, lsl #16
   220b0:      	msub	x7, x8, x9, x7
   220b4:      	str	x7, [x0, #0xc68]
   220b8:      	str	x25, [x0, #0xc70]
   220bc:      	str	x15, [x0, #0xc78]
   220c0:      	mov	x5, #0x0                ; =0
   220c4:      	str	x5, [x0, #0xc80]
   220c8:      	ldur	x10, [sp, #0x98]
   220cc:      	str	x10, [x0, #0xc88]
   220d0:      	ldur	x4, [sp, #0xa0]
   220d4:      	str	x4, [x0, #0xc90]
   220d8:      	str	x5, [x0, #0xc98]
   220dc:      	str	x12, [x0, #0xca0]
   220e0:      	str	x11, [x0, #0xca8]
   220e4:      	str	x5, [x0, #0xcb0]
   220e8:      	str	x13, [x0, #0xcb8]
   220ec:      	ldur	x13, [sp, #0xa8]
   220f0:      	str	x13, [x0, #0xcc0]
   220f4:      	add	x0, x1, #0x1
   220f8:      	ldr	x1, [sp, #0x188]
   220fc:      	str	x0, [x1, #0xcd0]
   22100:      	ldur	x15, [sp, #0x58]
   22104:      	and	x0, x15, #0x3ffffffffffffff
   22108:      	eor	x0, x0, #0x3ffffffffffffff
   2210c:      	str	x0, [x1, #0xcd8]
   22110:      	mov	x1, #0x6c8              ; =1736
   22114:      	mov	x2, #-0x1b              ; =-27
   22118:      	ldur	x4, [sp, #0x80]
   2211c:      	ldr	x21, [sp, #0x198]
   22120:      	ldur	x0, [sp, #0x8]
   22124:      	ldr	x6, [sp, #0x190]
   22128:      	blr	x21
   2212c:      	mov	x2, #0x2                ; =2
   22130:      	stur	x2, [sp, #0xb8]
   22134:      	cmp	x0, #0x0
   22138:      	b.ne	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   2213c:      	ldr	x3, [sp, #0x188]
   22140:      	ldr	x3, [x3]
   22144:      	ldr	x0, [sp, #0x188]
   22148:      	ldr	x4, [x0, #0x8]
   2214c:      	stur	x4, [sp, #0x80]
   22150:      	ldr	x21, [x0, #0xab8]
   22154:      	ldr	x14, [x0, #0xbf8]
   22158:      	ldr	x1, [x0, #0xac0]
   2215c:      	ldr	x2, [sp, #0x188]
   22160:      	ldr	x0, [x2, #0xac8]
   22164:      	ldr	x4, [sp, #0x188]
   22168:      	ldr	x0, [x4, #0xad0]
   2216c:      	ldr	x6, [sp, #0x188]
   22170:      	ldr	x10, [x6, #0xc48]
   22174:      	ldr	x8, [sp, #0x188]
   22178:      	stur	x10, [sp, #0xb0]
   2217c:      	ldr	x8, [x8, #0xc50]
   22180:      	ldr	x10, [sp, #0x188]
   22184:      	ldr	x26, [x10, #0xc58]
   22188:      	ldr	x12, [sp, #0x188]
   2218c:      	stur	x26, [sp, #0x88]
   22190:      	ldr	x6, [x12, #0xc60]
   22194:      	ldr	x15, [sp, #0x188]
   22198:      	stur	x6, [sp, #0x90]
   2219c:      	ldr	x0, [x15, #0xc68]
   221a0:      	ldr	x25, [x2, #0xc70]
   221a4:      	ldr	x15, [x2, #0xc78]
   221a8:      	ldr	x10, [x2, #0xc88]
   221ac:      	stur	x10, [sp, #0x98]
   221b0:      	ldr	x4, [x2, #0xc90]
   221b4:      	stur	x4, [sp, #0xa0]
   221b8:      	ldr	x12, [x2, #0xca0]
   221bc:      	ldr	x11, [x2, #0xca8]
   221c0:      	ldr	x13, [x2, #0xcb8]
   221c4:      	ldr	x2, [x2, #0xcc0]
   221c8:      	stur	x2, [sp, #0xa8]
   221cc:      	ldr	x2, [sp, #0x188]
   221d0:      	ldr	x28, [x2, #0x10]
   221d4:      	mov	x10, #0x1               ; =1
   221d8:      	str	x10, [x19, #0x4c60]
   221dc:      	add	x0, x3, x0
   221e0:      	mov	w2, #0xc87e             ; =51326
   221e4:      	movk	w2, #0x1, lsl #16
   221e8:      	madd	x4, x8, x2, x0
   221ec:      	stur	x4, [sp, #0x78]
   221f0:      	b	0x22208 <_mech_canonical_program_entry_v1_numeric_1282+0x4688>
   221f4:      	ldur	x0, [sp, #0x58]
   221f8:      	and	x0, x0, #0x3ffffffffffffff
   221fc:      	eor	x0, x0, #0x3ffffffffffffff
   22200:      	str	x0, [x21, x1, lsl #3]
   22204:      	add	x1, x1, #0x1
   22208:      	cbnz	x14, 0x223a0 <_mech_canonical_program_entry_v1_numeric_1282+0x4820>
   2220c:      	b	0x24418 <_mech_canonical_program_entry_v1_numeric_1282+0x6898>
   22210:      	ldr	x0, [sp, #0x188]
   22214:      	str	x27, [x0, #0x10]
   22218:      	str	x23, [x0, #0x18]
   2221c:      	str	x27, [x0, #0x10]
   22220:      	ldr	x2, [sp, #0x188]
   22224:      	str	x23, [x2, #0x18]
   22228:      	ldr	x4, [sp, #0x188]
   2222c:      	str	x8, [x4, #0xc50]
   22230:      	ldr	x6, [sp, #0x188]
   22234:      	ldur	x26, [sp, #0x88]
   22238:      	str	x26, [x6, #0xc58]
   2223c:      	ldur	x6, [sp, #0x90]
   22240:      	ldr	x9, [sp, #0x188]
   22244:      	str	x6, [x9, #0xc60]
   22248:      	ldur	x4, [sp, #0x78]
   2224c:      	sub	x0, x4, x3
   22250:      	mov	w2, #0xc87e             ; =51326
   22254:      	movk	w2, #0x1, lsl #16
   22258:      	msub	x0, x8, x2, x0
   2225c:      	ldr	x14, [sp, #0x188]
   22260:      	str	x0, [x14, #0xc68]
   22264:      	ldr	x0, [sp, #0x188]
   22268:      	str	x25, [x0, #0xc70]
   2226c:      	str	x15, [x0, #0xc78]
   22270:      	mov	x5, #0x0                ; =0
   22274:      	str	x5, [x0, #0xc80]
   22278:      	ldur	x10, [sp, #0x98]
   2227c:      	str	x10, [x0, #0xc88]
   22280:      	ldur	x4, [sp, #0xa0]
   22284:      	str	x4, [x0, #0xc90]
   22288:      	str	x5, [x0, #0xc98]
   2228c:      	str	x12, [x0, #0xca0]
   22290:      	str	x11, [x0, #0xca8]
   22294:      	str	x5, [x0, #0xcb0]
   22298:      	str	x13, [x0, #0xcb8]
   2229c:      	ldur	x13, [sp, #0xa8]
   222a0:      	str	x13, [x0, #0xcc0]
   222a4:      	add	x0, x1, #0x1
   222a8:      	ldr	x1, [sp, #0x188]
   222ac:      	str	x0, [x1, #0xcd0]
   222b0:      	ldur	x0, [sp, #0x60]
   222b4:      	and	x0, x0, #0x3ffffffffffffff
   222b8:      	eor	x0, x0, #0x3ffffffffffffff
   222bc:      	str	x0, [x1, #0xcd8]
   222c0:      	mov	x1, #0x6cc              ; =1740
   222c4:      	mov	x2, #-0x1b              ; =-27
   222c8:      	ldur	x4, [sp, #0x80]
   222cc:      	ldr	x21, [sp, #0x198]
   222d0:      	ldur	x0, [sp, #0x8]
   222d4:      	ldr	x6, [sp, #0x190]
   222d8:      	blr	x21
   222dc:      	mov	x1, #0x2                ; =2
   222e0:      	stur	x1, [sp, #0xb8]
   222e4:      	cmp	x0, #0x0
   222e8:      	b.ne	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   222ec:      	ldr	x3, [sp, #0x188]
   222f0:      	ldr	x3, [x3]
   222f4:      	ldr	x0, [sp, #0x188]
   222f8:      	ldr	x4, [x0, #0x8]
   222fc:      	stur	x4, [sp, #0x80]
   22300:      	ldr	x21, [x0, #0xab8]
   22304:      	ldr	x14, [x0, #0xbf8]
   22308:      	ldr	x1, [x0, #0xac0]
   2230c:      	ldr	x0, [x0, #0xac8]
   22310:      	ldr	x2, [sp, #0x188]
   22314:      	ldr	x0, [x2, #0xad0]
   22318:      	ldr	x4, [sp, #0x188]
   2231c:      	ldr	x0, [x4, #0xc48]
   22320:      	ldr	x6, [sp, #0x188]
   22324:      	stur	x0, [sp, #0xb0]
   22328:      	ldr	x8, [x6, #0xc50]
   2232c:      	ldr	x9, [sp, #0x188]
   22330:      	ldr	x26, [x9, #0xc58]
   22334:      	ldr	x10, [sp, #0x188]
   22338:      	stur	x26, [sp, #0x88]
   2233c:      	ldr	x6, [x10, #0xc60]
   22340:      	ldr	x12, [sp, #0x188]
   22344:      	stur	x6, [sp, #0x90]
   22348:      	ldr	x0, [x12, #0xc68]
   2234c:      	ldr	x15, [sp, #0x188]
   22350:      	ldr	x25, [x15, #0xc70]
   22354:      	ldr	x15, [x2, #0xc78]
   22358:      	ldr	x10, [x2, #0xc88]
   2235c:      	stur	x10, [sp, #0x98]
   22360:      	ldr	x4, [x2, #0xc90]
   22364:      	stur	x4, [sp, #0xa0]
   22368:      	ldr	x12, [x2, #0xca0]
   2236c:      	ldr	x11, [x2, #0xca8]
   22370:      	ldr	x13, [x2, #0xcb8]
   22374:      	ldr	x10, [x2, #0xcc0]
   22378:      	stur	x10, [sp, #0xa8]
   2237c:      	ldr	x28, [x2, #0x10]
   22380:      	mov	x10, #0x1               ; =1
   22384:      	str	x10, [x19, #0x4c60]
   22388:      	add	x0, x3, x0
   2238c:      	mov	w2, #0xc87e             ; =51326
   22390:      	movk	w2, #0x1, lsl #16
   22394:      	madd	x4, x8, x2, x0
   22398:      	stur	x4, [sp, #0x78]
   2239c:      	b	0x223b4 <_mech_canonical_program_entry_v1_numeric_1282+0x4834>
   223a0:      	ldur	x0, [sp, #0x60]
   223a4:      	and	x2, x0, #0x3ffffffffffffff
   223a8:      	eor	x2, x2, #0x3ffffffffffffff
   223ac:      	str	x2, [x21, x1, lsl #3]
   223b0:      	add	x1, x1, #0x1
   223b4:      	cbnz	x14, 0x22550 <_mech_canonical_program_entry_v1_numeric_1282+0x49d0>
   223b8:      	b	0x24444 <_mech_canonical_program_entry_v1_numeric_1282+0x68c4>
   223bc:      	ldr	x0, [sp, #0x188]
   223c0:      	str	x27, [x0, #0x10]
   223c4:      	str	x23, [x0, #0x18]
   223c8:      	str	x27, [x0, #0x10]
   223cc:      	str	x23, [x0, #0x18]
   223d0:      	ldr	x2, [sp, #0x188]
   223d4:      	str	x8, [x2, #0xc50]
   223d8:      	ldr	x4, [sp, #0x188]
   223dc:      	ldur	x26, [sp, #0x88]
   223e0:      	str	x26, [x4, #0xc58]
   223e4:      	ldur	x6, [sp, #0x90]
   223e8:      	ldr	x7, [sp, #0x188]
   223ec:      	str	x6, [x7, #0xc60]
   223f0:      	ldur	x4, [sp, #0x78]
   223f4:      	sub	x0, x4, x3
   223f8:      	mov	w2, #0xc87e             ; =51326
   223fc:      	movk	w2, #0x1, lsl #16
   22400:      	msub	x0, x8, x2, x0
   22404:      	ldr	x14, [sp, #0x188]
   22408:      	str	x0, [x14, #0xc68]
   2240c:      	str	x25, [x14, #0xc70]
   22410:      	ldr	x0, [sp, #0x188]
   22414:      	str	x15, [x0, #0xc78]
   22418:      	mov	x5, #0x0                ; =0
   2241c:      	str	x5, [x0, #0xc80]
   22420:      	ldur	x10, [sp, #0x98]
   22424:      	str	x10, [x0, #0xc88]
   22428:      	ldur	x4, [sp, #0xa0]
   2242c:      	str	x4, [x0, #0xc90]
   22430:      	str	x5, [x0, #0xc98]
   22434:      	str	x12, [x0, #0xca0]
   22438:      	str	x11, [x0, #0xca8]
   2243c:      	str	x5, [x0, #0xcb0]
   22440:      	str	x13, [x0, #0xcb8]
   22444:      	ldur	x13, [sp, #0xa8]
   22448:      	str	x13, [x0, #0xcc0]
   2244c:      	add	x0, x1, #0x1
   22450:      	ldr	x1, [sp, #0x188]
   22454:      	str	x0, [x1, #0xcd0]
   22458:      	ldur	x25, [sp, #0x68]
   2245c:      	and	x0, x25, #0x3ffffffffffffff
   22460:      	eor	x0, x0, #0x3ffffffffffffff
   22464:      	str	x0, [x1, #0xcd8]
   22468:      	mov	x1, #0x6d0              ; =1744
   2246c:      	mov	x2, #-0x1b              ; =-27
   22470:      	ldur	x4, [sp, #0x80]
   22474:      	ldr	x21, [sp, #0x198]
   22478:      	ldur	x0, [sp, #0x8]
   2247c:      	ldr	x6, [sp, #0x190]
   22480:      	blr	x21
   22484:      	mov	x1, #0x2                ; =2
   22488:      	stur	x1, [sp, #0xb8]
   2248c:      	cmp	x0, #0x0
   22490:      	b.ne	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   22494:      	ldr	x3, [sp, #0x188]
   22498:      	ldr	x3, [x3]
   2249c:      	ldr	x0, [sp, #0x188]
   224a0:      	ldr	x4, [x0, #0x8]
   224a4:      	stur	x4, [sp, #0x80]
   224a8:      	ldr	x21, [x0, #0xab8]
   224ac:      	ldr	x14, [x0, #0xbf8]
   224b0:      	ldr	x1, [x0, #0xac0]
   224b4:      	ldr	x0, [x0, #0xac8]
   224b8:      	ldr	x0, [sp, #0x188]
   224bc:      	ldr	x0, [x0, #0xad0]
   224c0:      	ldr	x2, [sp, #0x188]
   224c4:      	ldr	x0, [x2, #0xc48]
   224c8:      	ldr	x4, [sp, #0x188]
   224cc:      	stur	x0, [sp, #0xb0]
   224d0:      	ldr	x8, [x4, #0xc50]
   224d4:      	ldr	x6, [sp, #0x188]
   224d8:      	ldr	x26, [x6, #0xc58]
   224dc:      	ldr	x9, [sp, #0x188]
   224e0:      	stur	x26, [sp, #0x88]
   224e4:      	ldr	x6, [x9, #0xc60]
   224e8:      	ldr	x10, [sp, #0x188]
   224ec:      	stur	x6, [sp, #0x90]
   224f0:      	ldr	x0, [x10, #0xc68]
   224f4:      	ldr	x12, [sp, #0x188]
   224f8:      	ldr	x25, [x12, #0xc70]
   224fc:      	ldr	x15, [sp, #0x188]
   22500:      	ldr	x15, [x15, #0xc78]
   22504:      	ldr	x10, [x2, #0xc88]
   22508:      	stur	x10, [sp, #0x98]
   2250c:      	ldr	x4, [x2, #0xc90]
   22510:      	stur	x4, [sp, #0xa0]
   22514:      	ldr	x12, [x2, #0xca0]
   22518:      	ldr	x11, [x2, #0xca8]
   2251c:      	ldr	x13, [x2, #0xcb8]
   22520:      	ldr	x2, [x2, #0xcc0]
   22524:      	stur	x2, [sp, #0xa8]
   22528:      	ldr	x2, [sp, #0x188]
   2252c:      	ldr	x28, [x2, #0x10]
   22530:      	mov	x10, #0x1               ; =1
   22534:      	str	x10, [x19, #0x4c60]
   22538:      	add	x0, x3, x0
   2253c:      	mov	w2, #0xc87e             ; =51326
   22540:      	movk	w2, #0x1, lsl #16
   22544:      	madd	x4, x8, x2, x0
   22548:      	stur	x4, [sp, #0x78]
   2254c:      	b	0x22564 <_mech_canonical_program_entry_v1_numeric_1282+0x49e4>
   22550:      	ldur	x0, [sp, #0x68]
   22554:      	and	x0, x0, #0x3ffffffffffffff
   22558:      	eor	x0, x0, #0x3ffffffffffffff
   2255c:      	str	x0, [x21, x1, lsl #3]
   22560:      	add	x1, x1, #0x1
   22564:      	cbnz	x14, 0x226fc <_mech_canonical_program_entry_v1_numeric_1282+0x4b7c>
   22568:      	b	0x24470 <_mech_canonical_program_entry_v1_numeric_1282+0x68f0>
   2256c:      	ldr	x0, [sp, #0x188]
   22570:      	str	x27, [x0, #0x10]
   22574:      	str	x23, [x0, #0x18]
   22578:      	str	x27, [x0, #0x10]
   2257c:      	str	x23, [x0, #0x18]
   22580:      	str	x8, [x0, #0xc50]
   22584:      	ldr	x2, [sp, #0x188]
   22588:      	ldur	x26, [sp, #0x88]
   2258c:      	str	x26, [x2, #0xc58]
   22590:      	ldr	x4, [sp, #0x188]
   22594:      	ldur	x6, [sp, #0x90]
   22598:      	str	x6, [x4, #0xc60]
   2259c:      	ldur	x4, [sp, #0x78]
   225a0:      	sub	x0, x4, x3
   225a4:      	mov	w2, #0xc87e             ; =51326
   225a8:      	movk	w2, #0x1, lsl #16
   225ac:      	msub	x0, x8, x2, x0
   225b0:      	ldr	x10, [sp, #0x188]
   225b4:      	str	x0, [x10, #0xc68]
   225b8:      	ldr	x14, [sp, #0x188]
   225bc:      	str	x25, [x14, #0xc70]
   225c0:      	str	x15, [x14, #0xc78]
   225c4:      	mov	x5, #0x0                ; =0
   225c8:      	ldr	x0, [sp, #0x188]
   225cc:      	str	x5, [x0, #0xc80]
   225d0:      	ldur	x10, [sp, #0x98]
   225d4:      	str	x10, [x0, #0xc88]
   225d8:      	ldur	x4, [sp, #0xa0]
   225dc:      	str	x4, [x0, #0xc90]
   225e0:      	str	x5, [x0, #0xc98]
   225e4:      	str	x12, [x0, #0xca0]
   225e8:      	str	x11, [x0, #0xca8]
   225ec:      	str	x5, [x0, #0xcb0]
   225f0:      	str	x13, [x0, #0xcb8]
   225f4:      	ldur	x13, [sp, #0xa8]
   225f8:      	str	x13, [x0, #0xcc0]
   225fc:      	add	x7, x1, #0x1
   22600:      	str	x7, [x0, #0xcd0]
   22604:      	ldur	x26, [sp, #0x70]
   22608:      	and	x8, x26, #0x3ffffffffffffff
   2260c:      	eor	x8, x8, #0x3ffffffffffffff
   22610:      	str	x8, [x0, #0xcd8]
   22614:      	mov	x1, #0x6d4              ; =1748
   22618:      	mov	x2, #-0x1b              ; =-27
   2261c:      	ldur	x4, [sp, #0x80]
   22620:      	ldr	x21, [sp, #0x198]
   22624:      	ldur	x0, [sp, #0x8]
   22628:      	ldr	x6, [sp, #0x190]
   2262c:      	blr	x21
   22630:      	mov	x2, #0x2                ; =2
   22634:      	stur	x2, [sp, #0xb8]
   22638:      	cmp	x0, #0x0
   2263c:      	b.ne	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   22640:      	ldr	x3, [sp, #0x188]
   22644:      	ldr	x3, [x3]
   22648:      	ldr	x0, [sp, #0x188]
   2264c:      	ldr	x4, [x0, #0x8]
   22650:      	stur	x4, [sp, #0x80]
   22654:      	ldr	x21, [x0, #0xab8]
   22658:      	ldr	x14, [x0, #0xbf8]
   2265c:      	ldr	x1, [x0, #0xac0]
   22660:      	stur	x1, [sp, #0x50]
   22664:      	ldr	x12, [x0, #0xac8]
   22668:      	ldr	x12, [x0, #0xad0]
   2266c:      	ldr	x1, [x0, #0xc48]
   22670:      	ldr	x2, [sp, #0x188]
   22674:      	stur	x1, [sp, #0xb0]
   22678:      	ldr	x8, [x2, #0xc50]
   2267c:      	ldr	x4, [sp, #0x188]
   22680:      	ldr	x26, [x4, #0xc58]
   22684:      	ldr	x6, [sp, #0x188]
   22688:      	stur	x26, [sp, #0x88]
   2268c:      	ldr	x6, [x6, #0xc60]
   22690:      	ldr	x9, [sp, #0x188]
   22694:      	stur	x6, [sp, #0x90]
   22698:      	ldr	x0, [x9, #0xc68]
   2269c:      	ldr	x10, [sp, #0x188]
   226a0:      	ldr	x25, [x10, #0xc70]
   226a4:      	ldr	x12, [sp, #0x188]
   226a8:      	ldr	x15, [x12, #0xc78]
   226ac:      	ldr	x1, [sp, #0x188]
   226b0:      	ldr	x10, [x1, #0xc88]
   226b4:      	stur	x10, [sp, #0x98]
   226b8:      	ldr	x4, [x1, #0xc90]
   226bc:      	stur	x4, [sp, #0xa0]
   226c0:      	ldr	x12, [x1, #0xca0]
   226c4:      	ldr	x11, [x1, #0xca8]
   226c8:      	ldr	x13, [x1, #0xcb8]
   226cc:      	ldr	x1, [x1, #0xcc0]
   226d0:      	stur	x1, [sp, #0xa8]
   226d4:      	ldr	x1, [sp, #0x188]
   226d8:      	ldr	x28, [x1, #0x10]
   226dc:      	mov	x10, #0x1               ; =1
   226e0:      	str	x10, [x19, #0x4c60]
   226e4:      	add	x0, x3, x0
   226e8:      	mov	w1, #0xc87e             ; =51326
   226ec:      	movk	w1, #0x1, lsl #16
   226f0:      	madd	x4, x8, x1, x0
   226f4:      	stur	x4, [sp, #0x78]
   226f8:      	b	0x22714 <_mech_canonical_program_entry_v1_numeric_1282+0x4b94>
   226fc:      	ldur	x26, [sp, #0x70]
   22700:      	and	x0, x26, #0x3ffffffffffffff
   22704:      	eor	x0, x0, #0x3ffffffffffffff
   22708:      	str	x0, [x21, x1, lsl #3]
   2270c:      	add	x1, x1, #0x1
   22710:      	stur	x1, [sp, #0x50]
   22714:      	cmp	x22, x23
   22718:      	b.lo	0x2282c <_mech_canonical_program_entry_v1_numeric_1282+0x4cac>
   2271c:      	mov	x0, #0x0                ; =0
   22720:      	str	x0, [x19, #0x18]
   22724:      	mov	x1, #0x1000000000000000 ; =1152921504606846976
   22728:      	str	x1, [x19, #0x20]
   2272c:      	mov	x1, #0x1                ; =1
   22730:      	str	x1, [x19, #0x30]
   22734:      	mov	x2, #0x101010101010101  ; =72340172838076673
   22738:      	str	x2, [x19, #0x38]
   2273c:      	mov	x2, #0x2                ; =2
   22740:      	str	x2, [x19, #0x40]
   22744:      	mov	x2, #0x3                ; =3
   22748:      	str	x2, [x19, #0x48]
   2274c:      	mov	x2, #0x4                ; =4
   22750:      	str	x2, [x19, #0x50]
   22754:      	mov	x2, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   22758:      	str	x2, [x19, #0x78]
   2275c:      	mov	x2, #0x3333333333333333 ; =3689348814741910323
   22760:      	str	x2, [x19, #0x88]
   22764:      	mov	x2, #0x38               ; =56
   22768:      	str	x2, [x19, #0x90]
   2276c:      	mov	x2, #0x3a               ; =58
   22770:      	str	x2, [x19, #0x98]
   22774:      	mov	x2, #0x5555555555555555 ; =6148914691236517205
   22778:      	str	x2, [x19, #0xb0]
   2277c:      	mov	x2, #0x3ffffffffffffff  ; =288230376151711743
   22780:      	str	x2, [x19, #0xb8]
   22784:      	str	x0, [x19, #0x188]
   22788:      	str	x1, [x19, #0x190]
   2278c:      	str	x10, [x19, #0x4c60]
   22790:      	str	x3, [x19, #0x4c68]
   22794:      	ldur	x4, [sp, #0x80]
   22798:      	str	x4, [x19, #0x4c70]
   2279c:      	str	x27, [x19, #0x4f70]
   227a0:      	str	x23, [x19, #0x4f78]
   227a4:      	ldur	x1, [sp, #0x50]
   227a8:      	str	x1, [x19, #0x5a20]
   227ac:      	str	x8, [x19, #0x5bb0]
   227b0:      	ldur	x26, [sp, #0x88]
   227b4:      	str	x26, [x19, #0x5bb8]
   227b8:      	ldur	x6, [sp, #0x90]
   227bc:      	str	x6, [x19, #0x5bc0]
   227c0:      	ldur	x4, [sp, #0x78]
   227c4:      	sub	x0, x4, x3
   227c8:      	mov	w1, #0xc87e             ; =51326
   227cc:      	movk	w1, #0x1, lsl #16
   227d0:      	msub	x0, x8, x1, x0
   227d4:      	str	x0, [x19, #0x5bc8]
   227d8:      	str	x25, [x19, #0x5bd0]
   227dc:      	str	x15, [x19, #0x5bd8]
   227e0:      	ldur	x10, [sp, #0x98]
   227e4:      	str	x10, [x19, #0x5be8]
   227e8:      	ldur	x4, [sp, #0xa0]
   227ec:      	str	x4, [x19, #0x5bf0]
   227f0:      	str	x12, [x19, #0x5c00]
   227f4:      	str	x11, [x19, #0x5c08]
   227f8:      	str	x13, [x19, #0x5c18]
   227fc:      	ldur	x13, [sp, #0xa8]
   22800:      	str	x13, [x19, #0x5c20]
   22804:      	mov	x0, #0x0                ; =0
   22808:      	mov	x1, #0x1                ; =1
   2280c:      	add	sp, sp, #0x1b0
   22810:      	ldp	x19, x20, [sp], #0x10
   22814:      	ldp	x21, x22, [sp], #0x10
   22818:      	ldp	x23, x24, [sp], #0x10
   2281c:      	ldp	x25, x26, [sp], #0x10
   22820:      	ldp	x27, x28, [sp], #0x10
   22824:      	ldp	x29, x30, [sp], #0x10
   22828:      	retab
   2282c:      	add	x22, x24, #0x1
   22830:      	cmp	x22, x24
   22834:      	b.lo	0x2449c <_mech_canonical_program_entry_v1_numeric_1282+0x691c>
   22838:      	mov	x6, #0x1                ; =1
   2283c:      	stur	x6, [sp, #0x90]
   22840:      	ldur	x5, [sp, #0x90]
   22844:      	mov	x6, x19
   22848:      	ldur	x9, [sp, #0x98]
   2284c:      	mov	x26, x10
   22850:      	b	0x1e130 <_mech_canonical_program_entry_v1_numeric_1282+0x5b0>
   22854:      	add	x2, x15, #0x1
   22858:      	cmp	x2, x15
   2285c:      	b.lo	0x2459c <_mech_canonical_program_entry_v1_numeric_1282+0x6a1c>
   22860:      	mov	x4, #0x1                ; =1
   22864:      	stur	x4, [sp, #0x40]
   22868:      	mov	x15, x2
   2286c:      	stur	x1, [sp, #0x10]
   22870:      	stur	x0, [sp, #0x58]
   22874:      	stur	x7, [sp, #0x60]
   22878:      	stur	x11, [sp, #0x68]
   2287c:      	stur	x24, [sp, #0x70]
   22880:      	b	0x20a04 <_mech_canonical_program_entry_v1_numeric_1282+0x2e84>
   22884:      	add	x0, x27, #0x1
   22888:      	cmp	x0, x27
   2288c:      	b.lo	0x246bc <_mech_canonical_program_entry_v1_numeric_1282+0x6b3c>
   22890:      	mov	w11, #0xcb86            ; =52102
   22894:      	movk	w11, #0x2, lsl #16
   22898:      	sub	x3, x3, x11
   2289c:      	mov	x5, #0x1                ; =1
   228a0:      	stur	x5, [sp, #0x48]
   228a4:      	mov	x27, x0
   228a8:      	mov	x24, x20
   228ac:      	mov	x11, x9
   228b0:      	mov	x7, x6
   228b4:      	mov	x1, x2
   228b8:      	mov	x0, x4
   228bc:      	b	0x215e8 <_mech_canonical_program_entry_v1_numeric_1282+0x3a68>
   228c0:      	add	x27, x4, #0x1
   228c4:      	stur	x27, [sp, #0x18]
   228c8:      	cmp	x27, x4
   228cc:      	b.lo	0x247f8 <_mech_canonical_program_entry_v1_numeric_1282+0x6c78>
   228d0:      	mov	x24, #0x1               ; =1
   228d4:      	stur	x24, [sp, #0x20]
   228d8:      	stur	x0, [sp, #0x70]
   228dc:      	stur	x2, [sp, #0x10]
   228e0:      	mov	x27, x15
   228e4:      	mov	x2, x1
   228e8:      	b	0x1ecb0 <_mech_canonical_program_entry_v1_numeric_1282+0x1130>
   228ec:      	add	x27, x4, #0x1
   228f0:      	cmp	x27, x4
   228f4:      	b.lo	0x24928 <_mech_canonical_program_entry_v1_numeric_1282+0x6da8>
   228f8:      	mov	w0, #0xdc1e             ; =56350
   228fc:      	movk	w0, #0x2, lsl #16
   22900:      	sub	x9, x9, x0
   22904:      	mov	x3, #0x1                ; =1
   22908:      	stur	x6, [sp, #0x30]
   2290c:      	stur	x7, [sp, #0x28]
   22910:      	ldur	x15, [sp, #0x38]
   22914:      	mov	x7, x24
   22918:      	mov	x6, x20
   2291c:      	b	0x1f8cc <_mech_canonical_program_entry_v1_numeric_1282+0x1d4c>
   22920:      	stur	x0, [sp, #0xb8]
   22924:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   22928:      	stur	x0, [sp, #0xb8]
   2292c:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   22930:      	stur	x0, [sp, #0xb8]
   22934:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   22938:      	stur	x0, [sp, #0xb8]
   2293c:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   22940:      	mov	x5, #0x512              ; =1298
   22944:      	ldur	x6, [sp]
   22948:      	str	x5, [x6, #0x48]
   2294c:      	mov	x5, #0x0                ; =0
   22950:      	str	x5, [x19, #0x18]
   22954:      	mov	x6, #0x1000000000000000 ; =1152921504606846976
   22958:      	str	x6, [x19, #0x20]
   2295c:      	mov	x6, #0x1                ; =1
   22960:      	str	x6, [x19, #0x30]
   22964:      	mov	x7, #0x101010101010101  ; =72340172838076673
   22968:      	str	x7, [x19, #0x38]
   2296c:      	mov	x20, #0x2               ; =2
   22970:      	str	x20, [x19, #0x40]
   22974:      	mov	x7, #0x3                ; =3
   22978:      	str	x7, [x19, #0x48]
   2297c:      	mov	x7, #0x4                ; =4
   22980:      	str	x7, [x19, #0x50]
   22984:      	mov	x7, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   22988:      	str	x7, [x19, #0x78]
   2298c:      	mov	x7, #0x3333333333333333 ; =3689348814741910323
   22990:      	str	x7, [x19, #0x88]
   22994:      	mov	x7, #0x38               ; =56
   22998:      	str	x7, [x19, #0x90]
   2299c:      	mov	x7, #0x3a               ; =58
   229a0:      	str	x7, [x19, #0x98]
   229a4:      	mov	x14, #0x5555555555555555 ; =6148914691236517205
   229a8:      	str	x14, [x19, #0xb0]
   229ac:      	mov	x14, #0x3ffffffffffffff ; =288230376151711743
   229b0:      	str	x14, [x19, #0xb8]
   229b4:      	str	x5, [x19, #0x188]
   229b8:      	str	x6, [x19, #0x190]
   229bc:      	str	x22, [x19, #0x17a0]
   229c0:      	str	x23, [x19, #0x17a8]
   229c4:      	uxtb	w14, w0
   229c8:      	str	x14, [x19, #0x17b8]
   229cc:      	add	x0, x22, #0x1
   229d0:      	str	x0, [x19, #0x17d0]
   229d4:      	str	x10, [x19, #0x4c60]
   229d8:      	mov	w0, #0xc87e             ; =51326
   229dc:      	movk	w0, #0x1, lsl #16
   229e0:      	sub	x3, x3, x0
   229e4:      	str	x3, [x19, #0x4c68]
   229e8:      	str	x4, [x19, #0x4c70]
   229ec:      	str	x22, [x19, #0x4f70]
   229f0:      	str	x23, [x19, #0x4f78]
   229f4:      	ldur	x4, [sp, #0x50]
   229f8:      	str	x4, [x19, #0x5a20]
   229fc:      	add	x4, x8, #0x1
   22a00:      	str	x4, [x19, #0x5bb0]
   22a04:      	ldur	x26, [sp, #0x88]
   22a08:      	str	x26, [x19, #0x5bb8]
   22a0c:      	ldur	x10, [sp, #0x90]
   22a10:      	str	x10, [x19, #0x5bc0]
   22a14:      	ldur	x5, [sp, #0x78]
   22a18:      	sub	x3, x5, x3
   22a1c:      	msub	x0, x4, x0, x3
   22a20:      	str	x0, [x19, #0x5bc8]
   22a24:      	str	x25, [x19, #0x5bd0]
   22a28:      	str	x15, [x19, #0x5bd8]
   22a2c:      	str	x9, [x19, #0x5be8]
   22a30:      	ldur	x4, [sp, #0xa0]
   22a34:      	str	x4, [x19, #0x5bf0]
   22a38:      	str	x12, [x19, #0x5c00]
   22a3c:      	str	x11, [x19, #0x5c08]
   22a40:      	str	x13, [x19, #0x5c18]
   22a44:      	ldur	x13, [sp, #0xa8]
   22a48:      	str	x13, [x19, #0x5c20]
   22a4c:      	ldr	x0, [x19, #0x4c60]
   22a50:      	cmp	x0, #0x0
   22a54:      	b.ne	0x1e50c <_mech_canonical_program_entry_v1_numeric_1282+0x98c>
   22a58:      	b	0x1e500 <_mech_canonical_program_entry_v1_numeric_1282+0x980>
   22a5c:      	stur	x0, [sp, #0xb8]
   22a60:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   22a64:      	stur	x20, [sp, #0xb8]
   22a68:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   22a6c:      	stur	x0, [sp, #0xb8]
   22a70:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   22a74:      	stur	x20, [sp, #0xb8]
   22a78:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   22a7c:      	mov	x2, #0x514              ; =1300
   22a80:      	ldur	x5, [sp]
   22a84:      	str	x2, [x5, #0x48]
   22a88:      	mov	x2, #0x0                ; =0
   22a8c:      	str	x2, [x19, #0x18]
   22a90:      	mov	x5, #0x1000000000000000 ; =1152921504606846976
   22a94:      	str	x5, [x19, #0x20]
   22a98:      	mov	x5, #0x1                ; =1
   22a9c:      	str	x5, [x19, #0x30]
   22aa0:      	mov	x6, #0x101010101010101  ; =72340172838076673
   22aa4:      	str	x6, [x19, #0x38]
   22aa8:      	mov	x20, #0x2               ; =2
   22aac:      	str	x20, [x19, #0x40]
   22ab0:      	mov	x6, #0x3                ; =3
   22ab4:      	str	x6, [x19, #0x48]
   22ab8:      	mov	x6, #0x4                ; =4
   22abc:      	str	x6, [x19, #0x50]
   22ac0:      	mov	x6, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   22ac4:      	str	x6, [x19, #0x78]
   22ac8:      	mov	x6, #0x3333333333333333 ; =3689348814741910323
   22acc:      	str	x6, [x19, #0x88]
   22ad0:      	mov	x6, #0x38               ; =56
   22ad4:      	str	x6, [x19, #0x90]
   22ad8:      	mov	x6, #0x3a               ; =58
   22adc:      	str	x6, [x19, #0x98]
   22ae0:      	mov	x6, #0x5555555555555555 ; =6148914691236517205
   22ae4:      	str	x6, [x19, #0xb0]
   22ae8:      	mov	x6, #0x3ffffffffffffff  ; =288230376151711743
   22aec:      	str	x6, [x19, #0xb8]
   22af0:      	str	x2, [x19, #0x188]
   22af4:      	str	x5, [x19, #0x190]
   22af8:      	str	x22, [x19, #0x17a0]
   22afc:      	str	x23, [x19, #0x17a8]
   22b00:      	uxtb	w5, w0
   22b04:      	str	x5, [x19, #0x17b8]
   22b08:      	str	x1, [x19, #0x17d8]
   22b0c:      	add	x7, x22, #0x2
   22b10:      	str	x7, [x19, #0x17e0]
   22b14:      	str	x10, [x19, #0x4c60]
   22b18:      	mov	w9, #0xc87e             ; =51326
   22b1c:      	movk	w9, #0x1, lsl #16
   22b20:      	sub	x10, x3, x9
   22b24:      	str	x10, [x19, #0x4c68]
   22b28:      	str	x4, [x19, #0x4c70]
   22b2c:      	str	x22, [x19, #0x4f70]
   22b30:      	str	x23, [x19, #0x4f78]
   22b34:      	ldur	x1, [sp, #0x50]
   22b38:      	str	x1, [x19, #0x5a20]
   22b3c:      	add	x14, x8, #0x1
   22b40:      	str	x14, [x19, #0x5bb0]
   22b44:      	ldur	x26, [sp, #0x88]
   22b48:      	str	x26, [x19, #0x5bb8]
   22b4c:      	ldur	x6, [sp, #0x90]
   22b50:      	str	x6, [x19, #0x5bc0]
   22b54:      	ldur	x4, [sp, #0x78]
   22b58:      	sub	x0, x4, x10
   22b5c:      	msub	x0, x14, x9, x0
   22b60:      	str	x0, [x19, #0x5bc8]
   22b64:      	str	x25, [x19, #0x5bd0]
   22b68:      	str	x15, [x19, #0x5bd8]
   22b6c:      	ldur	x10, [sp, #0x98]
   22b70:      	str	x10, [x19, #0x5be8]
   22b74:      	ldur	x4, [sp, #0xa0]
   22b78:      	str	x4, [x19, #0x5bf0]
   22b7c:      	str	x12, [x19, #0x5c00]
   22b80:      	str	x11, [x19, #0x5c08]
   22b84:      	str	x13, [x19, #0x5c18]
   22b88:      	ldur	x13, [sp, #0xa8]
   22b8c:      	str	x13, [x19, #0x5c20]
   22b90:      	ldr	x0, [x19, #0x4c60]
   22b94:      	cmp	x0, #0x0
   22b98:      	b.ne	0x1e774 <_mech_canonical_program_entry_v1_numeric_1282+0xbf4>
   22b9c:      	b	0x1e990 <_mech_canonical_program_entry_v1_numeric_1282+0xe10>
   22ba0:      	stur	x0, [sp, #0xb8]
   22ba4:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   22ba8:      	stur	x20, [sp, #0xb8]
   22bac:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   22bb0:      	stur	x0, [sp, #0xb8]
   22bb4:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   22bb8:      	stur	x20, [sp, #0xb8]
   22bbc:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   22bc0:      	mov	x5, #0x516              ; =1302
   22bc4:      	ldur	x6, [sp]
   22bc8:      	str	x5, [x6, #0x48]
   22bcc:      	mov	x5, #0x0                ; =0
   22bd0:      	str	x5, [x19, #0x18]
   22bd4:      	mov	x6, #0x1000000000000000 ; =1152921504606846976
   22bd8:      	str	x6, [x19, #0x20]
   22bdc:      	mov	x6, #0x1                ; =1
   22be0:      	str	x6, [x19, #0x30]
   22be4:      	mov	x7, #0x101010101010101  ; =72340172838076673
   22be8:      	str	x7, [x19, #0x38]
   22bec:      	mov	x20, #0x2               ; =2
   22bf0:      	str	x20, [x19, #0x40]
   22bf4:      	mov	x7, #0x3                ; =3
   22bf8:      	str	x7, [x19, #0x48]
   22bfc:      	mov	x7, #0x4                ; =4
   22c00:      	str	x7, [x19, #0x50]
   22c04:      	mov	x7, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   22c08:      	str	x7, [x19, #0x78]
   22c0c:      	mov	x7, #0x3333333333333333 ; =3689348814741910323
   22c10:      	str	x7, [x19, #0x88]
   22c14:      	mov	x7, #0x38               ; =56
   22c18:      	str	x7, [x19, #0x90]
   22c1c:      	mov	x7, #0x3a               ; =58
   22c20:      	str	x7, [x19, #0x98]
   22c24:      	mov	x7, #0x5555555555555555 ; =6148914691236517205
   22c28:      	str	x7, [x19, #0xb0]
   22c2c:      	mov	x7, #0x3ffffffffffffff  ; =288230376151711743
   22c30:      	str	x7, [x19, #0xb8]
   22c34:      	str	x5, [x19, #0x188]
   22c38:      	str	x6, [x19, #0x190]
   22c3c:      	str	x22, [x19, #0x17a0]
   22c40:      	str	x23, [x19, #0x17a8]
   22c44:      	uxtb	w0, w0
   22c48:      	str	x0, [x19, #0x17b8]
   22c4c:      	str	x1, [x19, #0x17d8]
   22c50:      	str	x2, [x19, #0x17e8]
   22c54:      	ldur	x24, [sp, #0xd8]
   22c58:      	str	x24, [x19, #0x17f0]
   22c5c:      	str	x10, [x19, #0x4c60]
   22c60:      	mov	w2, #0xc87e             ; =51326
   22c64:      	movk	w2, #0x1, lsl #16
   22c68:      	sub	x3, x3, x2
   22c6c:      	str	x3, [x19, #0x4c68]
   22c70:      	str	x4, [x19, #0x4c70]
   22c74:      	str	x22, [x19, #0x4f70]
   22c78:      	str	x23, [x19, #0x4f78]
   22c7c:      	ldur	x1, [sp, #0x50]
   22c80:      	str	x1, [x19, #0x5a20]
   22c84:      	add	x7, x8, #0x1
   22c88:      	str	x7, [x19, #0x5bb0]
   22c8c:      	ldur	x26, [sp, #0x88]
   22c90:      	str	x26, [x19, #0x5bb8]
   22c94:      	ldur	x6, [sp, #0x90]
   22c98:      	str	x6, [x19, #0x5bc0]
   22c9c:      	ldur	x4, [sp, #0x78]
   22ca0:      	sub	x10, x4, x3
   22ca4:      	msub	x10, x7, x2, x10
   22ca8:      	str	x10, [x19, #0x5bc8]
   22cac:      	str	x25, [x19, #0x5bd0]
   22cb0:      	str	x15, [x19, #0x5bd8]
   22cb4:      	ldur	x10, [sp, #0x98]
   22cb8:      	str	x10, [x19, #0x5be8]
   22cbc:      	ldur	x4, [sp, #0xa0]
   22cc0:      	str	x4, [x19, #0x5bf0]
   22cc4:      	str	x12, [x19, #0x5c00]
   22cc8:      	str	x11, [x19, #0x5c08]
   22ccc:      	str	x13, [x19, #0x5c18]
   22cd0:      	ldur	x13, [sp, #0xa8]
   22cd4:      	str	x13, [x19, #0x5c20]
   22cd8:      	ldr	x0, [x19, #0x4c60]
   22cdc:      	cmp	x0, #0x0
   22ce0:      	b.ne	0x1ea00 <_mech_canonical_program_entry_v1_numeric_1282+0xe80>
   22ce4:      	b	0x1ec14 <_mech_canonical_program_entry_v1_numeric_1282+0x1094>
   22ce8:      	stur	x0, [sp, #0xb8]
   22cec:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   22cf0:      	stur	x20, [sp, #0xb8]
   22cf4:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   22cf8:      	stur	x0, [sp, #0xb8]
   22cfc:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   22d00:      	stur	x20, [sp, #0xb8]
   22d04:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   22d08:      	stur	x20, [sp, #0xb8]
   22d0c:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   22d10:      	mov	x0, #0x530              ; =1328
   22d14:      	ldur	x2, [sp]
   22d18:      	str	x0, [x2, #0x48]
   22d1c:      	mov	x2, #0x0                ; =0
   22d20:      	str	x2, [x19, #0x18]
   22d24:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   22d28:      	str	x0, [x19, #0x20]
   22d2c:      	mov	x0, #0x1                ; =1
   22d30:      	str	x0, [x19, #0x30]
   22d34:      	mov	x4, #0x101010101010101  ; =72340172838076673
   22d38:      	str	x4, [x19, #0x38]
   22d3c:      	mov	x20, #0x2               ; =2
   22d40:      	str	x20, [x19, #0x40]
   22d44:      	mov	x4, #0x3                ; =3
   22d48:      	str	x4, [x19, #0x48]
   22d4c:      	mov	x4, #0x4                ; =4
   22d50:      	str	x4, [x19, #0x50]
   22d54:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   22d58:      	str	x4, [x19, #0x78]
   22d5c:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   22d60:      	str	x4, [x19, #0x88]
   22d64:      	mov	x4, #0x38               ; =56
   22d68:      	str	x4, [x19, #0x90]
   22d6c:      	mov	x4, #0x3a               ; =58
   22d70:      	str	x4, [x19, #0x98]
   22d74:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   22d78:      	str	x4, [x19, #0xb0]
   22d7c:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   22d80:      	str	x4, [x19, #0xb8]
   22d84:      	str	x2, [x19, #0x188]
   22d88:      	str	x0, [x19, #0x190]
   22d8c:      	str	x22, [x19, #0x17a0]
   22d90:      	str	x23, [x19, #0x17a8]
   22d94:      	ldur	x24, [sp, #0xe0]
   22d98:      	uxtb	w2, w24
   22d9c:      	str	x2, [x19, #0x17b8]
   22da0:      	str	x1, [x19, #0x1858]
   22da4:      	mov	x15, x26
   22da8:      	str	x15, [x19, #0x1860]
   22dac:      	str	x22, [x19, #0x1868]
   22db0:      	ldur	x15, [sp, #0xd0]
   22db4:      	str	x15, [x19, #0x1870]
   22db8:      	ldur	x15, [sp, #0xc8]
   22dbc:      	uxtb	w7, w15
   22dc0:      	str	x7, [x19, #0x1880]
   22dc4:      	add	x9, x1, #0x1
   22dc8:      	str	x9, [x19, #0x1890]
   22dcc:      	str	x10, [x19, #0x4c60]
   22dd0:      	mov	w10, #0x2166            ; =8550
   22dd4:      	movk	w10, #0x1, lsl #16
   22dd8:      	sub	x10, x3, x10
   22ddc:      	str	x10, [x19, #0x4c68]
   22de0:      	ldur	x4, [sp, #0x80]
   22de4:      	str	x4, [x19, #0x4c70]
   22de8:      	str	x22, [x19, #0x4f70]
   22dec:      	str	x23, [x19, #0x4f78]
   22df0:      	str	x1, [x19, #0x50c0]
   22df4:      	mov	x15, x26
   22df8:      	str	x15, [x19, #0x50c8]
   22dfc:      	str	x22, [x19, #0x50d0]
   22e00:      	ldur	x15, [sp, #0xd0]
   22e04:      	str	x15, [x19, #0x50d8]
   22e08:      	ldur	x2, [sp, #0x10]
   22e0c:      	str	x2, [x19, #0x50e0]
   22e10:      	str	x27, [x19, #0x50e8]
   22e14:      	str	x25, [x19, #0x50f0]
   22e18:      	ldur	x27, [sp, #0x68]
   22e1c:      	str	x27, [x19, #0x50f8]
   22e20:      	ldur	x26, [sp, #0x70]
   22e24:      	str	x26, [x19, #0x5100]
   22e28:      	ldur	x1, [sp, #0x50]
   22e2c:      	str	x1, [x19, #0x5a20]
   22e30:      	add	x1, x8, #0x1
   22e34:      	str	x1, [x19, #0x5bb0]
   22e38:      	ldur	x26, [sp, #0x88]
   22e3c:      	str	x26, [x19, #0x5bb8]
   22e40:      	ldur	x6, [sp, #0x90]
   22e44:      	str	x6, [x19, #0x5bc0]
   22e48:      	ldur	x4, [sp, #0x78]
   22e4c:      	sub	x2, x4, x10
   22e50:      	mov	w3, #0xc87e             ; =51326
   22e54:      	movk	w3, #0x1, lsl #16
   22e58:      	msub	x1, x1, x3, x2
   22e5c:      	str	x1, [x19, #0x5bc8]
   22e60:      	str	x0, [x19, #0x5bd0]
   22e64:      	ldur	x24, [sp, #0x20]
   22e68:      	str	x24, [x19, #0x5bd8]
   22e6c:      	ldur	x10, [sp, #0x98]
   22e70:      	str	x10, [x19, #0x5be8]
   22e74:      	ldur	x4, [sp, #0xa0]
   22e78:      	str	x4, [x19, #0x5bf0]
   22e7c:      	str	x12, [x19, #0x5c00]
   22e80:      	str	x11, [x19, #0x5c08]
   22e84:      	str	x13, [x19, #0x5c18]
   22e88:      	ldur	x13, [sp, #0xa8]
   22e8c:      	str	x13, [x19, #0x5c20]
   22e90:      	ldr	x0, [x19, #0x4c60]
   22e94:      	cmp	x0, #0x0
   22e98:      	b.ne	0x1f0c0 <_mech_canonical_program_entry_v1_numeric_1282+0x1540>
   22e9c:      	b	0x1f2f8 <_mech_canonical_program_entry_v1_numeric_1282+0x1778>
   22ea0:      	stur	x20, [sp, #0xb8]
   22ea4:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   22ea8:      	stur	x20, [sp, #0xb8]
   22eac:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   22eb0:      	mov	x0, #0x531              ; =1329
   22eb4:      	ldur	x9, [sp]
   22eb8:      	str	x0, [x9, #0x48]
   22ebc:      	mov	x4, #0x0                ; =0
   22ec0:      	str	x4, [x19, #0x18]
   22ec4:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   22ec8:      	str	x0, [x19, #0x20]
   22ecc:      	mov	x0, #0x1                ; =1
   22ed0:      	stur	x0, [sp, #0xb8]
   22ed4:      	str	x0, [x19, #0x30]
   22ed8:      	mov	x0, #0x101010101010101  ; =72340172838076673
   22edc:      	str	x0, [x19, #0x38]
   22ee0:      	mov	x0, #0x2                ; =2
   22ee4:      	str	x0, [x19, #0x40]
   22ee8:      	mov	x0, #0x3                ; =3
   22eec:      	str	x0, [x19, #0x48]
   22ef0:      	mov	x0, #0x4                ; =4
   22ef4:      	str	x0, [x19, #0x50]
   22ef8:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   22efc:      	str	x0, [x19, #0x78]
   22f00:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   22f04:      	str	x0, [x19, #0x88]
   22f08:      	mov	x0, #0x38               ; =56
   22f0c:      	str	x0, [x19, #0x90]
   22f10:      	mov	x0, #0x3a               ; =58
   22f14:      	str	x0, [x19, #0x98]
   22f18:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   22f1c:      	str	x0, [x19, #0xb0]
   22f20:      	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
   22f24:      	str	x0, [x19, #0xb8]
   22f28:      	str	x4, [x19, #0x188]
   22f2c:      	ldur	x0, [sp, #0xb8]
   22f30:      	str	x0, [x19, #0x190]
   22f34:      	str	x22, [x19, #0x17a0]
   22f38:      	str	x23, [x19, #0x17a8]
   22f3c:      	ldur	x24, [sp, #0xe0]
   22f40:      	uxtb	w5, w24
   22f44:      	str	x5, [x19, #0x17b8]
   22f48:      	str	x1, [x19, #0x1858]
   22f4c:      	mov	x15, x26
   22f50:      	str	x15, [x19, #0x1860]
   22f54:      	str	x22, [x19, #0x1868]
   22f58:      	ldur	x15, [sp, #0xd0]
   22f5c:      	str	x15, [x19, #0x1870]
   22f60:      	ldur	x15, [sp, #0xc8]
   22f64:      	uxtb	w14, w15
   22f68:      	str	x14, [x19, #0x1880]
   22f6c:      	str	x2, [x19, #0x1898]
   22f70:      	str	x10, [x19, #0x4c60]
   22f74:      	mov	w14, #0x2166            ; =8550
   22f78:      	movk	w14, #0x1, lsl #16
   22f7c:      	sub	x14, x3, x14
   22f80:      	str	x14, [x19, #0x4c68]
   22f84:      	ldur	x4, [sp, #0x80]
   22f88:      	str	x4, [x19, #0x4c70]
   22f8c:      	ldur	x1, [sp, #0x50]
   22f90:      	str	x1, [x19, #0x5a20]
   22f94:      	add	x1, x8, #0x1
   22f98:      	str	x1, [x19, #0x5bb0]
   22f9c:      	ldur	x26, [sp, #0x88]
   22fa0:      	str	x26, [x19, #0x5bb8]
   22fa4:      	ldur	x6, [sp, #0x90]
   22fa8:      	str	x6, [x19, #0x5bc0]
   22fac:      	ldur	x4, [sp, #0x78]
   22fb0:      	sub	x2, x4, x14
   22fb4:      	mov	w3, #0xc87e             ; =51326
   22fb8:      	movk	w3, #0x1, lsl #16
   22fbc:      	msub	x0, x1, x3, x2
   22fc0:      	str	x0, [x19, #0x5bc8]
   22fc4:      	ldur	x0, [sp, #0xb8]
   22fc8:      	str	x0, [x19, #0x5bd0]
   22fcc:      	ldur	x24, [sp, #0x20]
   22fd0:      	str	x24, [x19, #0x5bd8]
   22fd4:      	ldur	x10, [sp, #0x98]
   22fd8:      	str	x10, [x19, #0x5be8]
   22fdc:      	ldur	x4, [sp, #0xa0]
   22fe0:      	str	x4, [x19, #0x5bf0]
   22fe4:      	str	x12, [x19, #0x5c00]
   22fe8:      	str	x11, [x19, #0x5c08]
   22fec:      	str	x13, [x19, #0x5c18]
   22ff0:      	ldur	x13, [sp, #0xa8]
   22ff4:      	str	x13, [x19, #0x5c20]
   22ff8:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   22ffc:      	mov	x0, #0x532              ; =1330
   23000:      	ldur	x15, [sp]
   23004:      	str	x0, [x15, #0x48]
   23008:      	mov	x5, #0x0                ; =0
   2300c:      	str	x5, [x19, #0x18]
   23010:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   23014:      	str	x0, [x19, #0x20]
   23018:      	mov	x0, #0x1                ; =1
   2301c:      	str	x0, [x19, #0x30]
   23020:      	mov	x6, #0x101010101010101  ; =72340172838076673
   23024:      	str	x6, [x19, #0x38]
   23028:      	mov	x20, #0x2               ; =2
   2302c:      	str	x20, [x19, #0x40]
   23030:      	mov	x6, #0x3                ; =3
   23034:      	str	x6, [x19, #0x48]
   23038:      	mov	x6, #0x4                ; =4
   2303c:      	str	x6, [x19, #0x50]
   23040:      	mov	x6, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   23044:      	str	x6, [x19, #0x78]
   23048:      	mov	x6, #0x3333333333333333 ; =3689348814741910323
   2304c:      	str	x6, [x19, #0x88]
   23050:      	mov	x6, #0x38               ; =56
   23054:      	str	x6, [x19, #0x90]
   23058:      	mov	x6, #0x3a               ; =58
   2305c:      	str	x6, [x19, #0x98]
   23060:      	mov	x6, #0x5555555555555555 ; =6148914691236517205
   23064:      	str	x6, [x19, #0xb0]
   23068:      	mov	x6, #0x3ffffffffffffff  ; =288230376151711743
   2306c:      	str	x6, [x19, #0xb8]
   23070:      	str	x5, [x19, #0x188]
   23074:      	str	x0, [x19, #0x190]
   23078:      	str	x22, [x19, #0x17a0]
   2307c:      	str	x23, [x19, #0x17a8]
   23080:      	ldur	x24, [sp, #0xe0]
   23084:      	uxtb	w5, w24
   23088:      	str	x5, [x19, #0x17b8]
   2308c:      	str	x1, [x19, #0x1858]
   23090:      	mov	x15, x26
   23094:      	str	x15, [x19, #0x1860]
   23098:      	str	x22, [x19, #0x1868]
   2309c:      	ldur	x15, [sp, #0xd0]
   230a0:      	str	x15, [x19, #0x1870]
   230a4:      	ldur	x15, [sp, #0xc8]
   230a8:      	uxtb	w5, w15
   230ac:      	str	x5, [x19, #0x1880]
   230b0:      	str	x2, [x19, #0x1898]
   230b4:      	str	x4, [x19, #0x18a0]
   230b8:      	str	x10, [x19, #0x4c60]
   230bc:      	mov	w2, #0x2166             ; =8550
   230c0:      	movk	w2, #0x1, lsl #16
   230c4:      	sub	x2, x3, x2
   230c8:      	str	x2, [x19, #0x4c68]
   230cc:      	ldur	x4, [sp, #0x80]
   230d0:      	str	x4, [x19, #0x4c70]
   230d4:      	str	x22, [x19, #0x4f70]
   230d8:      	str	x23, [x19, #0x4f78]
   230dc:      	str	x1, [x19, #0x50c0]
   230e0:      	mov	x15, x26
   230e4:      	str	x15, [x19, #0x50c8]
   230e8:      	str	x22, [x19, #0x50d0]
   230ec:      	ldur	x15, [sp, #0xd0]
   230f0:      	str	x15, [x19, #0x50d8]
   230f4:      	ldur	x25, [sp, #0x10]
   230f8:      	str	x25, [x19, #0x50e0]
   230fc:      	str	x27, [x19, #0x50e8]
   23100:      	ldur	x25, [sp, #0x60]
   23104:      	str	x25, [x19, #0x50f0]
   23108:      	ldur	x25, [sp, #0x68]
   2310c:      	str	x25, [x19, #0x50f8]
   23110:      	ldur	x26, [sp, #0x70]
   23114:      	str	x26, [x19, #0x5100]
   23118:      	ldur	x1, [sp, #0x50]
   2311c:      	str	x1, [x19, #0x5a20]
   23120:      	add	x10, x8, #0x1
   23124:      	str	x10, [x19, #0x5bb0]
   23128:      	ldur	x26, [sp, #0x88]
   2312c:      	str	x26, [x19, #0x5bb8]
   23130:      	ldur	x6, [sp, #0x90]
   23134:      	str	x6, [x19, #0x5bc0]
   23138:      	ldur	x4, [sp, #0x78]
   2313c:      	sub	x14, x4, x2
   23140:      	mov	w15, #0xc87e            ; =51326
   23144:      	movk	w15, #0x1, lsl #16
   23148:      	msub	x14, x10, x15, x14
   2314c:      	str	x14, [x19, #0x5bc8]
   23150:      	str	x0, [x19, #0x5bd0]
   23154:      	ldur	x24, [sp, #0x20]
   23158:      	str	x24, [x19, #0x5bd8]
   2315c:      	ldur	x10, [sp, #0x98]
   23160:      	str	x10, [x19, #0x5be8]
   23164:      	ldur	x4, [sp, #0xa0]
   23168:      	str	x4, [x19, #0x5bf0]
   2316c:      	str	x12, [x19, #0x5c00]
   23170:      	str	x11, [x19, #0x5c08]
   23174:      	str	x13, [x19, #0x5c18]
   23178:      	ldur	x13, [sp, #0xa8]
   2317c:      	str	x13, [x19, #0x5c20]
   23180:      	ldr	x0, [x19, #0x4c60]
   23184:      	cmp	x0, #0x0
   23188:      	b.ne	0x1f378 <_mech_canonical_program_entry_v1_numeric_1282+0x17f8>
   2318c:      	b	0x1f5a0 <_mech_canonical_program_entry_v1_numeric_1282+0x1a20>
   23190:      	stur	x20, [sp, #0xb8]
   23194:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   23198:      	stur	x20, [sp, #0xb8]
   2319c:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   231a0:      	mov	x0, #0x534              ; =1332
   231a4:      	ldur	x1, [sp]
   231a8:      	str	x0, [x1, #0x48]
   231ac:      	mov	x1, #0x0                ; =0
   231b0:      	str	x1, [x19, #0x18]
   231b4:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   231b8:      	str	x0, [x19, #0x20]
   231bc:      	mov	x0, #0x1                ; =1
   231c0:      	str	x0, [x19, #0x30]
   231c4:      	mov	x4, #0x101010101010101  ; =72340172838076673
   231c8:      	str	x4, [x19, #0x38]
   231cc:      	mov	x20, #0x2               ; =2
   231d0:      	str	x20, [x19, #0x40]
   231d4:      	mov	x4, #0x3                ; =3
   231d8:      	str	x4, [x19, #0x48]
   231dc:      	mov	x4, #0x4                ; =4
   231e0:      	str	x4, [x19, #0x50]
   231e4:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   231e8:      	str	x4, [x19, #0x78]
   231ec:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   231f0:      	str	x4, [x19, #0x88]
   231f4:      	mov	x4, #0x38               ; =56
   231f8:      	str	x4, [x19, #0x90]
   231fc:      	mov	x4, #0x3a               ; =58
   23200:      	str	x4, [x19, #0x98]
   23204:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   23208:      	str	x4, [x19, #0xb0]
   2320c:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   23210:      	str	x4, [x19, #0xb8]
   23214:      	str	x1, [x19, #0x188]
   23218:      	str	x0, [x19, #0x190]
   2321c:      	str	x22, [x19, #0x17a0]
   23220:      	str	x23, [x19, #0x17a8]
   23224:      	ldur	x24, [sp, #0xe0]
   23228:      	uxtb	w1, w24
   2322c:      	str	x1, [x19, #0x17b8]
   23230:      	ldur	x15, [sp, #0x18]
   23234:      	str	x15, [x19, #0x1858]
   23238:      	mov	x15, x26
   2323c:      	str	x15, [x19, #0x1860]
   23240:      	str	x22, [x19, #0x1868]
   23244:      	ldur	x15, [sp, #0xd0]
   23248:      	str	x15, [x19, #0x1870]
   2324c:      	ldur	x15, [sp, #0xc8]
   23250:      	uxtb	w1, w15
   23254:      	str	x1, [x19, #0x1880]
   23258:      	str	x27, [x19, #0x18a8]
   2325c:      	add	x1, x2, #0x2
   23260:      	str	x1, [x19, #0x18b0]
   23264:      	str	x10, [x19, #0x4c60]
   23268:      	mov	w2, #0x2166             ; =8550
   2326c:      	movk	w2, #0x1, lsl #16
   23270:      	sub	x2, x3, x2
   23274:      	str	x2, [x19, #0x4c68]
   23278:      	ldur	x4, [sp, #0x80]
   2327c:      	str	x4, [x19, #0x4c70]
   23280:      	str	x22, [x19, #0x4f70]
   23284:      	str	x23, [x19, #0x4f78]
   23288:      	ldur	x27, [sp, #0x18]
   2328c:      	str	x27, [x19, #0x50c0]
   23290:      	mov	x15, x26
   23294:      	str	x15, [x19, #0x50c8]
   23298:      	str	x22, [x19, #0x50d0]
   2329c:      	ldur	x15, [sp, #0xd0]
   232a0:      	str	x15, [x19, #0x50d8]
   232a4:      	ldur	x25, [sp, #0x10]
   232a8:      	str	x25, [x19, #0x50e0]
   232ac:      	ldur	x24, [sp, #0x58]
   232b0:      	str	x24, [x19, #0x50e8]
   232b4:      	ldur	x27, [sp, #0x60]
   232b8:      	str	x27, [x19, #0x50f0]
   232bc:      	ldur	x25, [sp, #0x68]
   232c0:      	str	x25, [x19, #0x50f8]
   232c4:      	ldur	x26, [sp, #0x70]
   232c8:      	str	x26, [x19, #0x5100]
   232cc:      	ldur	x1, [sp, #0x50]
   232d0:      	str	x1, [x19, #0x5a20]
   232d4:      	add	x1, x8, #0x1
   232d8:      	str	x1, [x19, #0x5bb0]
   232dc:      	ldur	x26, [sp, #0x88]
   232e0:      	str	x26, [x19, #0x5bb8]
   232e4:      	ldur	x6, [sp, #0x90]
   232e8:      	str	x6, [x19, #0x5bc0]
   232ec:      	ldur	x4, [sp, #0x78]
   232f0:      	sub	x2, x4, x2
   232f4:      	mov	w3, #0xc87e             ; =51326
   232f8:      	movk	w3, #0x1, lsl #16
   232fc:      	msub	x1, x1, x3, x2
   23300:      	str	x1, [x19, #0x5bc8]
   23304:      	str	x0, [x19, #0x5bd0]
   23308:      	ldur	x24, [sp, #0x20]
   2330c:      	str	x24, [x19, #0x5bd8]
   23310:      	ldur	x10, [sp, #0x98]
   23314:      	str	x10, [x19, #0x5be8]
   23318:      	ldur	x4, [sp, #0xa0]
   2331c:      	str	x4, [x19, #0x5bf0]
   23320:      	str	x12, [x19, #0x5c00]
   23324:      	str	x11, [x19, #0x5c08]
   23328:      	str	x13, [x19, #0x5c18]
   2332c:      	ldur	x13, [sp, #0xa8]
   23330:      	str	x13, [x19, #0x5c20]
   23334:      	ldr	x0, [x19, #0x4c60]
   23338:      	cmp	x0, #0x0
   2333c:      	b.ne	0x1f618 <_mech_canonical_program_entry_v1_numeric_1282+0x1a98>
   23340:      	b	0x1f840 <_mech_canonical_program_entry_v1_numeric_1282+0x1cc0>
   23344:      	stur	x20, [sp, #0xb8]
   23348:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   2334c:      	stur	x20, [sp, #0xb8]
   23350:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   23354:      	stur	x20, [sp, #0xb8]
   23358:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   2335c:      	mov	x0, #0x54e              ; =1358
   23360:      	ldur	x1, [sp]
   23364:      	str	x0, [x1, #0x48]
   23368:      	mov	x0, #0x0                ; =0
   2336c:      	str	x0, [x19, #0x18]
   23370:      	mov	x1, #0x1000000000000000 ; =1152921504606846976
   23374:      	str	x1, [x19, #0x20]
   23378:      	mov	x6, #0x1                ; =1
   2337c:      	str	x6, [x19, #0x30]
   23380:      	mov	x1, #0x101010101010101  ; =72340172838076673
   23384:      	str	x1, [x19, #0x38]
   23388:      	mov	x24, #0x2               ; =2
   2338c:      	str	x24, [x19, #0x40]
   23390:      	mov	x1, #0x3                ; =3
   23394:      	str	x1, [x19, #0x48]
   23398:      	mov	x1, #0x4                ; =4
   2339c:      	str	x1, [x19, #0x50]
   233a0:      	mov	x1, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   233a4:      	str	x1, [x19, #0x78]
   233a8:      	mov	x1, #0x3333333333333333 ; =3689348814741910323
   233ac:      	str	x1, [x19, #0x88]
   233b0:      	mov	x1, #0x38               ; =56
   233b4:      	str	x1, [x19, #0x90]
   233b8:      	mov	x1, #0x3a               ; =58
   233bc:      	str	x1, [x19, #0x98]
   233c0:      	mov	x1, #0x5555555555555555 ; =6148914691236517205
   233c4:      	str	x1, [x19, #0xb0]
   233c8:      	mov	x1, #0x3ffffffffffffff  ; =288230376151711743
   233cc:      	str	x1, [x19, #0xb8]
   233d0:      	str	x0, [x19, #0x188]
   233d4:      	str	x6, [x19, #0x190]
   233d8:      	str	x22, [x19, #0x17a0]
   233dc:      	str	x23, [x19, #0x17a8]
   233e0:      	ldur	x0, [sp, #0xe0]
   233e4:      	uxtb	w0, w0
   233e8:      	str	x0, [x19, #0x17b8]
   233ec:      	ldur	x0, [sp, #0x18]
   233f0:      	str	x0, [x19, #0x1858]
   233f4:      	mov	x0, x26
   233f8:      	str	x0, [x19, #0x1860]
   233fc:      	str	x22, [x19, #0x1868]
   23400:      	ldur	x14, [sp, #0xd0]
   23404:      	str	x14, [x19, #0x1870]
   23408:      	ldur	x0, [sp, #0xc8]
   2340c:      	uxtb	w0, w0
   23410:      	str	x0, [x19, #0x1880]
   23414:      	str	x27, [x19, #0x1918]
   23418:      	str	x5, [x19, #0x1920]
   2341c:      	str	x22, [x19, #0x1928]
   23420:      	str	x14, [x19, #0x1930]
   23424:      	uxtb	w0, w7
   23428:      	str	x0, [x19, #0x1940]
   2342c:      	add	x0, x27, #0x1
   23430:      	str	x0, [x19, #0x1950]
   23434:      	str	x10, [x19, #0x4c60]
   23438:      	mov	w0, #0xdc1e             ; =56350
   2343c:      	movk	w0, #0x2, lsl #16
   23440:      	sub	x4, x9, x0
   23444:      	str	x4, [x19, #0x4c68]
   23448:      	ldur	x7, [sp, #0x80]
   2344c:      	str	x7, [x19, #0x4c70]
   23450:      	str	x22, [x19, #0x4f70]
   23454:      	str	x23, [x19, #0x4f78]
   23458:      	ldur	x0, [sp, #0x18]
   2345c:      	str	x0, [x19, #0x50c0]
   23460:      	mov	x0, x26
   23464:      	str	x0, [x19, #0x50c8]
   23468:      	str	x22, [x19, #0x50d0]
   2346c:      	ldur	x0, [sp, #0xd0]
   23470:      	str	x0, [x19, #0x50d8]
   23474:      	ldur	x0, [sp, #0x10]
   23478:      	str	x0, [x19, #0x50e0]
   2347c:      	ldur	x0, [sp, #0x58]
   23480:      	str	x0, [x19, #0x50e8]
   23484:      	ldur	x0, [sp, #0x60]
   23488:      	str	x0, [x19, #0x50f0]
   2348c:      	ldur	x14, [sp, #0x68]
   23490:      	str	x14, [x19, #0x50f8]
   23494:      	ldur	x26, [sp, #0x70]
   23498:      	str	x26, [x19, #0x5100]
   2349c:      	str	x27, [x19, #0x52a8]
   234a0:      	str	x5, [x19, #0x52b0]
   234a4:      	str	x22, [x19, #0x52b8]
   234a8:      	ldur	x0, [sp, #0xd0]
   234ac:      	str	x0, [x19, #0x52c0]
   234b0:      	str	x2, [x19, #0x52c8]
   234b4:      	str	x15, [x19, #0x52d0]
   234b8:      	str	x25, [x19, #0x52d8]
   234bc:      	ldur	x1, [sp, #0x28]
   234c0:      	str	x1, [x19, #0x52e0]
   234c4:      	ldur	x0, [sp, #0x30]
   234c8:      	str	x0, [x19, #0x52e8]
   234cc:      	ldur	x1, [sp, #0x50]
   234d0:      	str	x1, [x19, #0x5a20]
   234d4:      	add	x8, x8, #0x1
   234d8:      	str	x8, [x19, #0x5bb0]
   234dc:      	ldur	x26, [sp, #0x88]
   234e0:      	str	x26, [x19, #0x5bb8]
   234e4:      	ldur	x0, [sp, #0x90]
   234e8:      	str	x0, [x19, #0x5bc0]
   234ec:      	ldur	x0, [sp, #0x78]
   234f0:      	sub	x14, x0, x4
   234f4:      	mov	w15, #0xc87e            ; =51326
   234f8:      	movk	w15, #0x1, lsl #16
   234fc:      	msub	x14, x8, x15, x14
   23500:      	str	x14, [x19, #0x5bc8]
   23504:      	str	x6, [x19, #0x5bd0]
   23508:      	ldur	x0, [sp, #0x20]
   2350c:      	str	x0, [x19, #0x5bd8]
   23510:      	str	x6, [x19, #0x5be8]
   23514:      	str	x3, [x19, #0x5bf0]
   23518:      	str	x12, [x19, #0x5c00]
   2351c:      	str	x11, [x19, #0x5c08]
   23520:      	str	x13, [x19, #0x5c18]
   23524:      	ldur	x13, [sp, #0xa8]
   23528:      	str	x13, [x19, #0x5c20]
   2352c:      	ldr	x0, [x19, #0x4c60]
   23530:      	cmp	x0, #0x0
   23534:      	b.ne	0x1fd64 <_mech_canonical_program_entry_v1_numeric_1282+0x21e4>
   23538:      	b	0x1ff84 <_mech_canonical_program_entry_v1_numeric_1282+0x2404>
   2353c:      	stur	x24, [sp, #0xb8]
   23540:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   23544:      	stur	x24, [sp, #0xb8]
   23548:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   2354c:      	mov	x0, #0x554              ; =1364
   23550:      	ldur	x14, [sp]
   23554:      	str	x0, [x14, #0x48]
   23558:      	mov	x1, #0x0                ; =0
   2355c:      	str	x1, [x19, #0x18]
   23560:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   23564:      	str	x0, [x19, #0x20]
   23568:      	mov	x0, #0x1                ; =1
   2356c:      	stur	x0, [sp, #0xb8]
   23570:      	str	x0, [x19, #0x30]
   23574:      	mov	x0, #0x101010101010101  ; =72340172838076673
   23578:      	str	x0, [x19, #0x38]
   2357c:      	mov	x0, #0x2                ; =2
   23580:      	str	x0, [x19, #0x40]
   23584:      	mov	x0, #0x3                ; =3
   23588:      	str	x0, [x19, #0x48]
   2358c:      	mov	x0, #0x4                ; =4
   23590:      	str	x0, [x19, #0x50]
   23594:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   23598:      	str	x0, [x19, #0x78]
   2359c:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   235a0:      	str	x0, [x19, #0x88]
   235a4:      	mov	x0, #0x38               ; =56
   235a8:      	str	x0, [x19, #0x90]
   235ac:      	mov	x0, #0x3a               ; =58
   235b0:      	str	x0, [x19, #0x98]
   235b4:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   235b8:      	str	x0, [x19, #0xb0]
   235bc:      	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
   235c0:      	str	x0, [x19, #0xb8]
   235c4:      	str	x1, [x19, #0x188]
   235c8:      	ldur	x0, [sp, #0xb8]
   235cc:      	str	x0, [x19, #0x190]
   235d0:      	str	x22, [x19, #0x17a0]
   235d4:      	str	x23, [x19, #0x17a8]
   235d8:      	ldur	x0, [sp, #0xe0]
   235dc:      	uxtb	w0, w0
   235e0:      	str	x0, [x19, #0x17b8]
   235e4:      	ldur	x0, [sp, #0x18]
   235e8:      	str	x0, [x19, #0x1858]
   235ec:      	mov	x15, x26
   235f0:      	str	x15, [x19, #0x1860]
   235f4:      	str	x22, [x19, #0x1868]
   235f8:      	ldur	x15, [sp, #0xd0]
   235fc:      	str	x15, [x19, #0x1870]
   23600:      	ldur	x15, [sp, #0xc8]
   23604:      	uxtb	w1, w15
   23608:      	str	x1, [x19, #0x1880]
   2360c:      	str	x27, [x19, #0x1918]
   23610:      	str	x5, [x19, #0x1920]
   23614:      	str	x22, [x19, #0x1928]
   23618:      	ldur	x15, [sp, #0xd0]
   2361c:      	str	x15, [x19, #0x1930]
   23620:      	uxtb	w6, w7
   23624:      	str	x6, [x19, #0x1940]
   23628:      	str	x24, [x19, #0x1958]
   2362c:      	str	x10, [x19, #0x4c60]
   23630:      	mov	w10, #0xdc1e            ; =56350
   23634:      	movk	w10, #0x2, lsl #16
   23638:      	sub	x9, x9, x10
   2363c:      	str	x9, [x19, #0x4c68]
   23640:      	ldur	x4, [sp, #0x80]
   23644:      	str	x4, [x19, #0x4c70]
   23648:      	ldur	x1, [sp, #0x50]
   2364c:      	str	x1, [x19, #0x5a20]
   23650:      	add	x14, x8, #0x1
   23654:      	str	x14, [x19, #0x5bb0]
   23658:      	ldur	x26, [sp, #0x88]
   2365c:      	str	x26, [x19, #0x5bb8]
   23660:      	ldur	x6, [sp, #0x90]
   23664:      	str	x6, [x19, #0x5bc0]
   23668:      	ldur	x4, [sp, #0x78]
   2366c:      	sub	x15, x4, x9
   23670:      	mov	w1, #0xc87e             ; =51326
   23674:      	movk	w1, #0x1, lsl #16
   23678:      	msub	x15, x14, x1, x15
   2367c:      	str	x15, [x19, #0x5bc8]
   23680:      	ldur	x0, [sp, #0xb8]
   23684:      	str	x0, [x19, #0x5bd0]
   23688:      	ldur	x24, [sp, #0x20]
   2368c:      	str	x24, [x19, #0x5bd8]
   23690:      	str	x0, [x19, #0x5be8]
   23694:      	str	x3, [x19, #0x5bf0]
   23698:      	str	x12, [x19, #0x5c00]
   2369c:      	str	x11, [x19, #0x5c08]
   236a0:      	str	x13, [x19, #0x5c18]
   236a4:      	ldur	x13, [sp, #0xa8]
   236a8:      	str	x13, [x19, #0x5c20]
   236ac:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   236b0:      	mov	x6, #0x555              ; =1365
   236b4:      	ldur	x14, [sp]
   236b8:      	str	x6, [x14, #0x48]
   236bc:      	mov	x14, #0x0               ; =0
   236c0:      	str	x14, [x19, #0x18]
   236c4:      	mov	x6, #0x1000000000000000 ; =1152921504606846976
   236c8:      	str	x6, [x19, #0x20]
   236cc:      	mov	x6, #0x1                ; =1
   236d0:      	str	x6, [x19, #0x30]
   236d4:      	mov	x20, #0x101010101010101 ; =72340172838076673
   236d8:      	str	x20, [x19, #0x38]
   236dc:      	mov	x20, #0x2               ; =2
   236e0:      	str	x20, [x19, #0x40]
   236e4:      	mov	x21, #0x3               ; =3
   236e8:      	str	x21, [x19, #0x48]
   236ec:      	mov	x21, #0x4               ; =4
   236f0:      	str	x21, [x19, #0x50]
   236f4:      	mov	x21, #0xf0f0f0f0f0f0f0f ; =1085102592571150095
   236f8:      	str	x21, [x19, #0x78]
   236fc:      	mov	x21, #0x3333333333333333 ; =3689348814741910323
   23700:      	str	x21, [x19, #0x88]
   23704:      	mov	x21, #0x38              ; =56
   23708:      	str	x21, [x19, #0x90]
   2370c:      	mov	x21, #0x3a              ; =58
   23710:      	str	x21, [x19, #0x98]
   23714:      	mov	x21, #0x5555555555555555 ; =6148914691236517205
   23718:      	str	x21, [x19, #0xb0]
   2371c:      	mov	x21, #0x3ffffffffffffff ; =288230376151711743
   23720:      	str	x21, [x19, #0xb8]
   23724:      	str	x14, [x19, #0x188]
   23728:      	str	x6, [x19, #0x190]
   2372c:      	str	x22, [x19, #0x17a0]
   23730:      	str	x23, [x19, #0x17a8]
   23734:      	ldur	x14, [sp, #0xe0]
   23738:      	uxtb	w14, w14
   2373c:      	str	x14, [x19, #0x17b8]
   23740:      	ldur	x14, [sp, #0x18]
   23744:      	str	x14, [x19, #0x1858]
   23748:      	mov	x14, x26
   2374c:      	str	x14, [x19, #0x1860]
   23750:      	str	x22, [x19, #0x1868]
   23754:      	ldur	x14, [sp, #0xd0]
   23758:      	str	x14, [x19, #0x1870]
   2375c:      	ldur	x14, [sp, #0xc8]
   23760:      	uxtb	w14, w14
   23764:      	str	x14, [x19, #0x1880]
   23768:      	str	x27, [x19, #0x1918]
   2376c:      	str	x5, [x19, #0x1920]
   23770:      	str	x22, [x19, #0x1928]
   23774:      	ldur	x14, [sp, #0xd0]
   23778:      	str	x14, [x19, #0x1930]
   2377c:      	uxtb	w7, w7
   23780:      	str	x7, [x19, #0x1940]
   23784:      	str	x24, [x19, #0x1958]
   23788:      	str	x4, [x19, #0x1970]
   2378c:      	str	x10, [x19, #0x4c60]
   23790:      	mov	w4, #0xdc1e             ; =56350
   23794:      	movk	w4, #0x2, lsl #16
   23798:      	sub	x4, x9, x4
   2379c:      	str	x4, [x19, #0x4c68]
   237a0:      	ldur	x7, [sp, #0x80]
   237a4:      	str	x7, [x19, #0x4c70]
   237a8:      	str	x22, [x19, #0x4f70]
   237ac:      	str	x23, [x19, #0x4f78]
   237b0:      	ldur	x7, [sp, #0x18]
   237b4:      	str	x7, [x19, #0x50c0]
   237b8:      	mov	x7, x26
   237bc:      	str	x7, [x19, #0x50c8]
   237c0:      	str	x22, [x19, #0x50d0]
   237c4:      	ldur	x7, [sp, #0xd0]
   237c8:      	str	x7, [x19, #0x50d8]
   237cc:      	ldur	x7, [sp, #0x10]
   237d0:      	str	x7, [x19, #0x50e0]
   237d4:      	ldur	x24, [sp, #0x58]
   237d8:      	str	x24, [x19, #0x50e8]
   237dc:      	ldur	x7, [sp, #0x60]
   237e0:      	str	x7, [x19, #0x50f0]
   237e4:      	ldur	x14, [sp, #0x68]
   237e8:      	str	x14, [x19, #0x50f8]
   237ec:      	ldur	x26, [sp, #0x70]
   237f0:      	str	x26, [x19, #0x5100]
   237f4:      	str	x27, [x19, #0x52a8]
   237f8:      	str	x5, [x19, #0x52b0]
   237fc:      	str	x22, [x19, #0x52b8]
   23800:      	ldur	x5, [sp, #0xd0]
   23804:      	str	x5, [x19, #0x52c0]
   23808:      	str	x2, [x19, #0x52c8]
   2380c:      	str	x15, [x19, #0x52d0]
   23810:      	str	x25, [x19, #0x52d8]
   23814:      	str	x1, [x19, #0x52e0]
   23818:      	str	x0, [x19, #0x52e8]
   2381c:      	ldur	x1, [sp, #0x50]
   23820:      	str	x1, [x19, #0x5a20]
   23824:      	add	x0, x8, #0x1
   23828:      	str	x0, [x19, #0x5bb0]
   2382c:      	ldur	x26, [sp, #0x88]
   23830:      	str	x26, [x19, #0x5bb8]
   23834:      	ldur	x1, [sp, #0x90]
   23838:      	str	x1, [x19, #0x5bc0]
   2383c:      	ldur	x1, [sp, #0x78]
   23840:      	sub	x1, x1, x4
   23844:      	mov	w2, #0xc87e             ; =51326
   23848:      	movk	w2, #0x1, lsl #16
   2384c:      	msub	x0, x0, x2, x1
   23850:      	str	x0, [x19, #0x5bc8]
   23854:      	str	x6, [x19, #0x5bd0]
   23858:      	ldur	x24, [sp, #0x20]
   2385c:      	str	x24, [x19, #0x5bd8]
   23860:      	str	x6, [x19, #0x5be8]
   23864:      	str	x3, [x19, #0x5bf0]
   23868:      	str	x12, [x19, #0x5c00]
   2386c:      	str	x11, [x19, #0x5c08]
   23870:      	str	x13, [x19, #0x5c18]
   23874:      	ldur	x13, [sp, #0xa8]
   23878:      	str	x13, [x19, #0x5c20]
   2387c:      	ldr	x0, [x19, #0x4c60]
   23880:      	cmp	x0, #0x0
   23884:      	b.ne	0x2002c <_mech_canonical_program_entry_v1_numeric_1282+0x24ac>
   23888:      	b	0x20258 <_mech_canonical_program_entry_v1_numeric_1282+0x26d8>
   2388c:      	stur	x20, [sp, #0xb8]
   23890:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   23894:      	stur	x20, [sp, #0xb8]
   23898:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   2389c:      	mov	x0, #0x5e8              ; =1512
   238a0:      	ldur	x1, [sp]
   238a4:      	str	x0, [x1, #0x48]
   238a8:      	mov	x0, #0x0                ; =0
   238ac:      	str	x0, [x19, #0x18]
   238b0:      	mov	x1, #0x1000000000000000 ; =1152921504606846976
   238b4:      	str	x1, [x19, #0x20]
   238b8:      	mov	x1, #0x1                ; =1
   238bc:      	str	x1, [x19, #0x30]
   238c0:      	mov	x2, #0x101010101010101  ; =72340172838076673
   238c4:      	str	x2, [x19, #0x38]
   238c8:      	mov	x20, #0x2               ; =2
   238cc:      	str	x20, [x19, #0x40]
   238d0:      	mov	x2, #0x3                ; =3
   238d4:      	str	x2, [x19, #0x48]
   238d8:      	mov	x2, #0x4                ; =4
   238dc:      	str	x2, [x19, #0x50]
   238e0:      	mov	x2, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   238e4:      	str	x2, [x19, #0x78]
   238e8:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   238ec:      	str	x4, [x19, #0x88]
   238f0:      	mov	x4, #0x38               ; =56
   238f4:      	str	x4, [x19, #0x90]
   238f8:      	mov	x5, #0x3a               ; =58
   238fc:      	str	x5, [x19, #0x98]
   23900:      	mov	x6, #0x5555555555555555 ; =6148914691236517205
   23904:      	str	x6, [x19, #0xb0]
   23908:      	mov	x7, #0x3ffffffffffffff  ; =288230376151711743
   2390c:      	str	x7, [x19, #0xb8]
   23910:      	str	x0, [x19, #0x188]
   23914:      	str	x1, [x19, #0x190]
   23918:      	str	x22, [x19, #0x17a0]
   2391c:      	str	x23, [x19, #0x17a8]
   23920:      	ldur	x24, [sp, #0xe0]
   23924:      	uxtb	w14, w24
   23928:      	str	x14, [x19, #0x17b8]
   2392c:      	ldur	x24, [sp, #0xd8]
   23930:      	str	x24, [x19, #0x1c00]
   23934:      	str	x10, [x19, #0x4c60]
   23938:      	str	x3, [x19, #0x4c68]
   2393c:      	ldur	x4, [sp, #0x80]
   23940:      	str	x4, [x19, #0x4c70]
   23944:      	str	x22, [x19, #0x4f70]
   23948:      	str	x23, [x19, #0x4f78]
   2394c:      	ldur	x1, [sp, #0x50]
   23950:      	str	x1, [x19, #0x5a20]
   23954:      	add	x1, x8, #0x1
   23958:      	str	x1, [x19, #0x5bb0]
   2395c:      	ldur	x26, [sp, #0x88]
   23960:      	str	x26, [x19, #0x5bb8]
   23964:      	ldur	x6, [sp, #0x90]
   23968:      	str	x6, [x19, #0x5bc0]
   2396c:      	ldur	x4, [sp, #0x78]
   23970:      	sub	x2, x4, x3
   23974:      	mov	w3, #0xc87e             ; =51326
   23978:      	movk	w3, #0x1, lsl #16
   2397c:      	msub	x1, x1, x3, x2
   23980:      	str	x1, [x19, #0x5bc8]
   23984:      	str	x0, [x19, #0x5bd0]
   23988:      	str	x0, [x19, #0x5bd8]
   2398c:      	ldur	x10, [sp, #0x98]
   23990:      	str	x10, [x19, #0x5be8]
   23994:      	ldur	x4, [sp, #0xa0]
   23998:      	str	x4, [x19, #0x5bf0]
   2399c:      	str	x12, [x19, #0x5c00]
   239a0:      	str	x11, [x19, #0x5c08]
   239a4:      	str	x13, [x19, #0x5c18]
   239a8:      	ldur	x13, [sp, #0xa8]
   239ac:      	str	x13, [x19, #0x5c20]
   239b0:      	ldr	x0, [x19, #0x4c60]
   239b4:      	cmp	x0, #0x0
   239b8:      	b.ne	0x204c8 <_mech_canonical_program_entry_v1_numeric_1282+0x2948>
   239bc:      	b	0x206f8 <_mech_canonical_program_entry_v1_numeric_1282+0x2b78>
   239c0:      	stur	x20, [sp, #0xb8]
   239c4:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   239c8:      	stur	x20, [sp, #0xb8]
   239cc:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   239d0:      	mov	x0, #0x5ea              ; =1514
   239d4:      	ldur	x2, [sp]
   239d8:      	str	x0, [x2, #0x48]
   239dc:      	mov	x0, #0x0                ; =0
   239e0:      	str	x0, [x19, #0x18]
   239e4:      	mov	x1, #0x1000000000000000 ; =1152921504606846976
   239e8:      	str	x1, [x19, #0x20]
   239ec:      	mov	x1, #0x1                ; =1
   239f0:      	str	x1, [x19, #0x30]
   239f4:      	mov	x2, #0x101010101010101  ; =72340172838076673
   239f8:      	str	x2, [x19, #0x38]
   239fc:      	mov	x20, #0x2               ; =2
   23a00:      	str	x20, [x19, #0x40]
   23a04:      	mov	x2, #0x3                ; =3
   23a08:      	str	x2, [x19, #0x48]
   23a0c:      	mov	x2, #0x4                ; =4
   23a10:      	str	x2, [x19, #0x50]
   23a14:      	mov	x2, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   23a18:      	str	x2, [x19, #0x78]
   23a1c:      	mov	x2, #0x3333333333333333 ; =3689348814741910323
   23a20:      	str	x2, [x19, #0x88]
   23a24:      	mov	x2, #0x38               ; =56
   23a28:      	str	x2, [x19, #0x90]
   23a2c:      	mov	x2, #0x3a               ; =58
   23a30:      	str	x2, [x19, #0x98]
   23a34:      	mov	x2, #0x5555555555555555 ; =6148914691236517205
   23a38:      	str	x2, [x19, #0xb0]
   23a3c:      	mov	x2, #0x3ffffffffffffff  ; =288230376151711743
   23a40:      	str	x2, [x19, #0xb8]
   23a44:      	str	x0, [x19, #0x188]
   23a48:      	str	x1, [x19, #0x190]
   23a4c:      	str	x22, [x19, #0x17a0]
   23a50:      	str	x23, [x19, #0x17a8]
   23a54:      	ldur	x24, [sp, #0xe0]
   23a58:      	uxtb	w4, w24
   23a5c:      	str	x4, [x19, #0x17b8]
   23a60:      	str	x15, [x19, #0x1c08]
   23a64:      	add	x5, x22, #0x2
   23a68:      	str	x5, [x19, #0x1c10]
   23a6c:      	str	x10, [x19, #0x4c60]
   23a70:      	str	x3, [x19, #0x4c68]
   23a74:      	ldur	x4, [sp, #0x80]
   23a78:      	str	x4, [x19, #0x4c70]
   23a7c:      	str	x22, [x19, #0x4f70]
   23a80:      	str	x23, [x19, #0x4f78]
   23a84:      	ldur	x1, [sp, #0x50]
   23a88:      	str	x1, [x19, #0x5a20]
   23a8c:      	add	x14, x8, #0x1
   23a90:      	str	x14, [x19, #0x5bb0]
   23a94:      	ldur	x26, [sp, #0x88]
   23a98:      	str	x26, [x19, #0x5bb8]
   23a9c:      	ldur	x6, [sp, #0x90]
   23aa0:      	str	x6, [x19, #0x5bc0]
   23aa4:      	ldur	x4, [sp, #0x78]
   23aa8:      	sub	x15, x4, x3
   23aac:      	mov	w1, #0xc87e             ; =51326
   23ab0:      	movk	w1, #0x1, lsl #16
   23ab4:      	msub	x15, x14, x1, x15
   23ab8:      	str	x15, [x19, #0x5bc8]
   23abc:      	str	x0, [x19, #0x5bd0]
   23ac0:      	str	x0, [x19, #0x5bd8]
   23ac4:      	ldur	x10, [sp, #0x98]
   23ac8:      	str	x10, [x19, #0x5be8]
   23acc:      	ldur	x4, [sp, #0xa0]
   23ad0:      	str	x4, [x19, #0x5bf0]
   23ad4:      	str	x12, [x19, #0x5c00]
   23ad8:      	str	x11, [x19, #0x5c08]
   23adc:      	str	x13, [x19, #0x5c18]
   23ae0:      	ldur	x13, [sp, #0xa8]
   23ae4:      	str	x13, [x19, #0x5c20]
   23ae8:      	ldr	x0, [x19, #0x4c60]
   23aec:      	cmp	x0, #0x0
   23af0:      	b.ne	0x2076c <_mech_canonical_program_entry_v1_numeric_1282+0x2bec>
   23af4:      	b	0x20998 <_mech_canonical_program_entry_v1_numeric_1282+0x2e18>
   23af8:      	stur	x20, [sp, #0xb8]
   23afc:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   23b00:      	stur	x20, [sp, #0xb8]
   23b04:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   23b08:      	stur	x20, [sp, #0xb8]
   23b0c:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   23b10:      	mov	x0, #0x604              ; =1540
   23b14:      	ldur	x1, [sp]
   23b18:      	str	x0, [x1, #0x48]
   23b1c:      	mov	x1, #0x0                ; =0
   23b20:      	str	x1, [x19, #0x18]
   23b24:      	str	x26, [x19, #0x20]
   23b28:      	mov	x0, #0x1                ; =1
   23b2c:      	stur	x0, [sp, #0xb8]
   23b30:      	str	x0, [x19, #0x30]
   23b34:      	mov	x0, #0x101010101010101  ; =72340172838076673
   23b38:      	str	x0, [x19, #0x38]
   23b3c:      	mov	x0, #0x2                ; =2
   23b40:      	str	x0, [x19, #0x40]
   23b44:      	mov	x0, #0x3                ; =3
   23b48:      	str	x0, [x19, #0x48]
   23b4c:      	mov	x0, #0x4                ; =4
   23b50:      	str	x0, [x19, #0x50]
   23b54:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   23b58:      	str	x0, [x19, #0x78]
   23b5c:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   23b60:      	str	x0, [x19, #0x88]
   23b64:      	mov	x0, #0x38               ; =56
   23b68:      	str	x0, [x19, #0x90]
   23b6c:      	mov	x0, #0x3a               ; =58
   23b70:      	str	x0, [x19, #0x98]
   23b74:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   23b78:      	str	x0, [x19, #0xb0]
   23b7c:      	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
   23b80:      	str	x0, [x19, #0xb8]
   23b84:      	str	x1, [x19, #0x188]
   23b88:      	ldur	x0, [sp, #0xb8]
   23b8c:      	str	x0, [x19, #0x190]
   23b90:      	str	x22, [x19, #0x17a0]
   23b94:      	str	x23, [x19, #0x17a8]
   23b98:      	ldur	x24, [sp, #0xe0]
   23b9c:      	uxtb	w5, w24
   23ba0:      	str	x5, [x19, #0x17b8]
   23ba4:      	str	x15, [x19, #0x1c70]
   23ba8:      	str	x12, [x19, #0x1c78]
   23bac:      	str	x22, [x19, #0x1c80]
   23bb0:      	str	x25, [x19, #0x1ca8]
   23bb4:      	str	x10, [x19, #0x4c60]
   23bb8:      	mov	w11, #0x2646            ; =9798
   23bbc:      	movk	w11, #0x1, lsl #16
   23bc0:      	sub	x11, x3, x11
   23bc4:      	str	x11, [x19, #0x4c68]
   23bc8:      	ldur	x4, [sp, #0x80]
   23bcc:      	str	x4, [x19, #0x4c70]
   23bd0:      	ldur	x0, [sp, #0x50]
   23bd4:      	str	x0, [x19, #0x5a20]
   23bd8:      	add	x14, x8, #0x1
   23bdc:      	str	x14, [x19, #0x5bb0]
   23be0:      	ldur	x26, [sp, #0x88]
   23be4:      	str	x26, [x19, #0x5bb8]
   23be8:      	ldur	x6, [sp, #0x90]
   23bec:      	str	x6, [x19, #0x5bc0]
   23bf0:      	ldur	x4, [sp, #0x78]
   23bf4:      	sub	x2, x4, x11
   23bf8:      	mov	w3, #0xc87e             ; =51326
   23bfc:      	movk	w3, #0x1, lsl #16
   23c00:      	msub	x0, x14, x3, x2
   23c04:      	str	x0, [x19, #0x5bc8]
   23c08:      	str	x1, [x19, #0x5bd0]
   23c0c:      	str	x1, [x19, #0x5bd8]
   23c10:      	ldur	x10, [sp, #0x98]
   23c14:      	str	x10, [x19, #0x5be8]
   23c18:      	ldur	x4, [sp, #0xa0]
   23c1c:      	str	x4, [x19, #0x5bf0]
   23c20:      	ldur	x0, [sp, #0xb8]
   23c24:      	str	x0, [x19, #0x5c00]
   23c28:      	ldur	x7, [sp, #0x40]
   23c2c:      	str	x7, [x19, #0x5c08]
   23c30:      	str	x13, [x19, #0x5c18]
   23c34:      	ldur	x13, [sp, #0xa8]
   23c38:      	str	x13, [x19, #0x5c20]
   23c3c:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   23c40:      	mov	x0, #0x605              ; =1541
   23c44:      	ldur	x1, [sp]
   23c48:      	str	x0, [x1, #0x48]
   23c4c:      	mov	x0, #0x0                ; =0
   23c50:      	str	x0, [x19, #0x18]
   23c54:      	str	x26, [x19, #0x20]
   23c58:      	mov	x1, #0x1                ; =1
   23c5c:      	str	x1, [x19, #0x30]
   23c60:      	mov	x4, #0x101010101010101  ; =72340172838076673
   23c64:      	str	x4, [x19, #0x38]
   23c68:      	mov	x20, #0x2               ; =2
   23c6c:      	str	x20, [x19, #0x40]
   23c70:      	mov	x4, #0x3                ; =3
   23c74:      	str	x4, [x19, #0x48]
   23c78:      	mov	x4, #0x4                ; =4
   23c7c:      	str	x4, [x19, #0x50]
   23c80:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   23c84:      	str	x4, [x19, #0x78]
   23c88:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   23c8c:      	str	x4, [x19, #0x88]
   23c90:      	mov	x4, #0x38               ; =56
   23c94:      	str	x4, [x19, #0x90]
   23c98:      	mov	x4, #0x3a               ; =58
   23c9c:      	str	x4, [x19, #0x98]
   23ca0:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   23ca4:      	str	x4, [x19, #0xb0]
   23ca8:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   23cac:      	str	x4, [x19, #0xb8]
   23cb0:      	str	x0, [x19, #0x188]
   23cb4:      	str	x1, [x19, #0x190]
   23cb8:      	str	x22, [x19, #0x17a0]
   23cbc:      	str	x23, [x19, #0x17a8]
   23cc0:      	ldur	x24, [sp, #0xe0]
   23cc4:      	uxtb	w4, w24
   23cc8:      	str	x4, [x19, #0x17b8]
   23ccc:      	str	x15, [x19, #0x1c70]
   23cd0:      	str	x12, [x19, #0x1c78]
   23cd4:      	str	x22, [x19, #0x1c80]
   23cd8:      	str	x25, [x19, #0x1ca8]
   23cdc:      	str	x2, [x19, #0x1cb8]
   23ce0:      	str	x10, [x19, #0x4c60]
   23ce4:      	mov	w2, #0x2646             ; =9798
   23ce8:      	movk	w2, #0x1, lsl #16
   23cec:      	sub	x2, x3, x2
   23cf0:      	str	x2, [x19, #0x4c68]
   23cf4:      	ldur	x4, [sp, #0x80]
   23cf8:      	str	x4, [x19, #0x4c70]
   23cfc:      	str	x22, [x19, #0x4f70]
   23d00:      	str	x23, [x19, #0x4f78]
   23d04:      	str	x15, [x19, #0x55d8]
   23d08:      	str	x12, [x19, #0x55e0]
   23d0c:      	str	x22, [x19, #0x55e8]
   23d10:      	ldur	x25, [sp, #0x10]
   23d14:      	str	x25, [x19, #0x55f0]
   23d18:      	ldur	x24, [sp, #0x58]
   23d1c:      	str	x24, [x19, #0x55f8]
   23d20:      	ldur	x27, [sp, #0x60]
   23d24:      	str	x27, [x19, #0x5600]
   23d28:      	ldur	x25, [sp, #0x68]
   23d2c:      	str	x25, [x19, #0x5608]
   23d30:      	ldur	x26, [sp, #0x70]
   23d34:      	str	x26, [x19, #0x5610]
   23d38:      	ldur	x3, [sp, #0x50]
   23d3c:      	str	x3, [x19, #0x5a20]
   23d40:      	add	x5, x8, #0x1
   23d44:      	str	x5, [x19, #0x5bb0]
   23d48:      	ldur	x26, [sp, #0x88]
   23d4c:      	str	x26, [x19, #0x5bb8]
   23d50:      	ldur	x6, [sp, #0x90]
   23d54:      	str	x6, [x19, #0x5bc0]
   23d58:      	ldur	x4, [sp, #0x78]
   23d5c:      	sub	x8, x4, x2
   23d60:      	mov	w9, #0xc87e             ; =51326
   23d64:      	movk	w9, #0x1, lsl #16
   23d68:      	msub	x8, x5, x9, x8
   23d6c:      	str	x8, [x19, #0x5bc8]
   23d70:      	str	x0, [x19, #0x5bd0]
   23d74:      	str	x0, [x19, #0x5bd8]
   23d78:      	ldur	x10, [sp, #0x98]
   23d7c:      	str	x10, [x19, #0x5be8]
   23d80:      	ldur	x4, [sp, #0xa0]
   23d84:      	str	x4, [x19, #0x5bf0]
   23d88:      	str	x1, [x19, #0x5c00]
   23d8c:      	ldur	x7, [sp, #0x40]
   23d90:      	str	x7, [x19, #0x5c08]
   23d94:      	str	x13, [x19, #0x5c18]
   23d98:      	ldur	x13, [sp, #0xa8]
   23d9c:      	str	x13, [x19, #0x5c20]
   23da0:      	ldr	x0, [x19, #0x4c60]
   23da4:      	cmp	x0, #0x0
   23da8:      	b.ne	0x20e28 <_mech_canonical_program_entry_v1_numeric_1282+0x32a8>
   23dac:      	b	0x21050 <_mech_canonical_program_entry_v1_numeric_1282+0x34d0>
   23db0:      	stur	x20, [sp, #0xb8]
   23db4:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   23db8:      	stur	x20, [sp, #0xb8]
   23dbc:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   23dc0:      	mov	x0, #0x606              ; =1542
   23dc4:      	ldur	x2, [sp]
   23dc8:      	str	x0, [x2, #0x48]
   23dcc:      	mov	x2, #0x0                ; =0
   23dd0:      	str	x2, [x19, #0x18]
   23dd4:      	str	x26, [x19, #0x20]
   23dd8:      	mov	x0, #0x1                ; =1
   23ddc:      	stur	x0, [sp, #0xb8]
   23de0:      	str	x0, [x19, #0x30]
   23de4:      	mov	x0, #0x101010101010101  ; =72340172838076673
   23de8:      	str	x0, [x19, #0x38]
   23dec:      	mov	x0, #0x2                ; =2
   23df0:      	str	x0, [x19, #0x40]
   23df4:      	mov	x0, #0x3                ; =3
   23df8:      	str	x0, [x19, #0x48]
   23dfc:      	mov	x0, #0x4                ; =4
   23e00:      	str	x0, [x19, #0x50]
   23e04:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   23e08:      	str	x0, [x19, #0x78]
   23e0c:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   23e10:      	str	x0, [x19, #0x88]
   23e14:      	mov	x0, #0x38               ; =56
   23e18:      	str	x0, [x19, #0x90]
   23e1c:      	mov	x0, #0x3a               ; =58
   23e20:      	str	x0, [x19, #0x98]
   23e24:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   23e28:      	str	x0, [x19, #0xb0]
   23e2c:      	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
   23e30:      	str	x0, [x19, #0xb8]
   23e34:      	str	x2, [x19, #0x188]
   23e38:      	ldur	x0, [sp, #0xb8]
   23e3c:      	str	x0, [x19, #0x190]
   23e40:      	str	x22, [x19, #0x17a0]
   23e44:      	str	x23, [x19, #0x17a8]
   23e48:      	ldur	x24, [sp, #0xe0]
   23e4c:      	uxtb	w0, w24
   23e50:      	str	x0, [x19, #0x17b8]
   23e54:      	str	x15, [x19, #0x1c70]
   23e58:      	str	x12, [x19, #0x1c78]
   23e5c:      	str	x22, [x19, #0x1c80]
   23e60:      	str	x25, [x19, #0x1ca8]
   23e64:      	str	x1, [x19, #0x1cc0]
   23e68:      	str	x10, [x19, #0x4c60]
   23e6c:      	mov	w1, #0x2646             ; =9798
   23e70:      	movk	w1, #0x1, lsl #16
   23e74:      	sub	x1, x3, x1
   23e78:      	str	x1, [x19, #0x4c68]
   23e7c:      	ldur	x4, [sp, #0x80]
   23e80:      	str	x4, [x19, #0x4c70]
   23e84:      	ldur	x0, [sp, #0x50]
   23e88:      	str	x0, [x19, #0x5a20]
   23e8c:      	add	x3, x8, #0x1
   23e90:      	str	x3, [x19, #0x5bb0]
   23e94:      	ldur	x26, [sp, #0x88]
   23e98:      	str	x26, [x19, #0x5bb8]
   23e9c:      	ldur	x6, [sp, #0x90]
   23ea0:      	str	x6, [x19, #0x5bc0]
   23ea4:      	ldur	x4, [sp, #0x78]
   23ea8:      	sub	x1, x4, x1
   23eac:      	mov	w4, #0xc87e             ; =51326
   23eb0:      	movk	w4, #0x1, lsl #16
   23eb4:      	msub	x0, x3, x4, x1
   23eb8:      	str	x0, [x19, #0x5bc8]
   23ebc:      	str	x2, [x19, #0x5bd0]
   23ec0:      	str	x2, [x19, #0x5bd8]
   23ec4:      	ldur	x10, [sp, #0x98]
   23ec8:      	str	x10, [x19, #0x5be8]
   23ecc:      	ldur	x4, [sp, #0xa0]
   23ed0:      	str	x4, [x19, #0x5bf0]
   23ed4:      	ldur	x0, [sp, #0xb8]
   23ed8:      	str	x0, [x19, #0x5c00]
   23edc:      	ldur	x7, [sp, #0x40]
   23ee0:      	str	x7, [x19, #0x5c08]
   23ee4:      	str	x13, [x19, #0x5c18]
   23ee8:      	ldur	x13, [sp, #0xa8]
   23eec:      	str	x13, [x19, #0x5c20]
   23ef0:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   23ef4:      	mov	x14, #0x607             ; =1543
   23ef8:      	ldur	x0, [sp]
   23efc:      	str	x14, [x0, #0x48]
   23f00:      	mov	x14, #0x0               ; =0
   23f04:      	str	x14, [x19, #0x18]
   23f08:      	str	x26, [x19, #0x20]
   23f0c:      	mov	x0, #0x1                ; =1
   23f10:      	str	x0, [x19, #0x30]
   23f14:      	mov	x4, #0x101010101010101  ; =72340172838076673
   23f18:      	str	x4, [x19, #0x38]
   23f1c:      	mov	x20, #0x2               ; =2
   23f20:      	str	x20, [x19, #0x40]
   23f24:      	mov	x4, #0x3                ; =3
   23f28:      	str	x4, [x19, #0x48]
   23f2c:      	mov	x4, #0x4                ; =4
   23f30:      	str	x4, [x19, #0x50]
   23f34:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   23f38:      	str	x4, [x19, #0x78]
   23f3c:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   23f40:      	str	x4, [x19, #0x88]
   23f44:      	mov	x4, #0x38               ; =56
   23f48:      	str	x4, [x19, #0x90]
   23f4c:      	mov	x4, #0x3a               ; =58
   23f50:      	str	x4, [x19, #0x98]
   23f54:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   23f58:      	str	x4, [x19, #0xb0]
   23f5c:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   23f60:      	str	x4, [x19, #0xb8]
   23f64:      	str	x14, [x19, #0x188]
   23f68:      	str	x0, [x19, #0x190]
   23f6c:      	str	x22, [x19, #0x17a0]
   23f70:      	str	x23, [x19, #0x17a8]
   23f74:      	ldur	x24, [sp, #0xe0]
   23f78:      	uxtb	w4, w24
   23f7c:      	str	x4, [x19, #0x17b8]
   23f80:      	str	x15, [x19, #0x1c70]
   23f84:      	str	x12, [x19, #0x1c78]
   23f88:      	str	x22, [x19, #0x1c80]
   23f8c:      	str	x25, [x19, #0x1ca8]
   23f90:      	str	x1, [x19, #0x1cc0]
   23f94:      	str	x2, [x19, #0x1cc8]
   23f98:      	str	x10, [x19, #0x4c60]
   23f9c:      	mov	w1, #0x2646             ; =9798
   23fa0:      	movk	w1, #0x1, lsl #16
   23fa4:      	sub	x1, x3, x1
   23fa8:      	str	x1, [x19, #0x4c68]
   23fac:      	ldur	x4, [sp, #0x80]
   23fb0:      	str	x4, [x19, #0x4c70]
   23fb4:      	str	x22, [x19, #0x4f70]
   23fb8:      	str	x23, [x19, #0x4f78]
   23fbc:      	str	x15, [x19, #0x55d8]
   23fc0:      	str	x12, [x19, #0x55e0]
   23fc4:      	str	x22, [x19, #0x55e8]
   23fc8:      	ldur	x25, [sp, #0x10]
   23fcc:      	str	x25, [x19, #0x55f0]
   23fd0:      	ldur	x24, [sp, #0x58]
   23fd4:      	str	x24, [x19, #0x55f8]
   23fd8:      	ldur	x27, [sp, #0x60]
   23fdc:      	str	x27, [x19, #0x5600]
   23fe0:      	ldur	x25, [sp, #0x68]
   23fe4:      	str	x25, [x19, #0x5608]
   23fe8:      	ldur	x26, [sp, #0x70]
   23fec:      	str	x26, [x19, #0x5610]
   23ff0:      	ldur	x11, [sp, #0x50]
   23ff4:      	str	x11, [x19, #0x5a20]
   23ff8:      	add	x2, x8, #0x1
   23ffc:      	str	x2, [x19, #0x5bb0]
   24000:      	ldur	x26, [sp, #0x88]
   24004:      	str	x26, [x19, #0x5bb8]
   24008:      	ldur	x6, [sp, #0x90]
   2400c:      	str	x6, [x19, #0x5bc0]
   24010:      	ldur	x4, [sp, #0x78]
   24014:      	sub	x1, x4, x1
   24018:      	mov	w3, #0xc87e             ; =51326
   2401c:      	movk	w3, #0x1, lsl #16
   24020:      	msub	x1, x2, x3, x1
   24024:      	str	x1, [x19, #0x5bc8]
   24028:      	str	x14, [x19, #0x5bd0]
   2402c:      	str	x14, [x19, #0x5bd8]
   24030:      	ldur	x10, [sp, #0x98]
   24034:      	str	x10, [x19, #0x5be8]
   24038:      	ldur	x4, [sp, #0xa0]
   2403c:      	str	x4, [x19, #0x5bf0]
   24040:      	str	x0, [x19, #0x5c00]
   24044:      	ldur	x7, [sp, #0x40]
   24048:      	str	x7, [x19, #0x5c08]
   2404c:      	str	x13, [x19, #0x5c18]
   24050:      	ldur	x13, [sp, #0xa8]
   24054:      	str	x13, [x19, #0x5c20]
   24058:      	ldr	x0, [x19, #0x4c60]
   2405c:      	cmp	x0, #0x0
   24060:      	b.ne	0x210cc <_mech_canonical_program_entry_v1_numeric_1282+0x354c>
   24064:      	b	0x212e0 <_mech_canonical_program_entry_v1_numeric_1282+0x3760>
   24068:      	stur	x20, [sp, #0xb8]
   2406c:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   24070:      	stur	x20, [sp, #0xb8]
   24074:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   24078:      	mov	x0, #0x609              ; =1545
   2407c:      	ldur	x2, [sp]
   24080:      	str	x0, [x2, #0x48]
   24084:      	mov	x0, #0x0                ; =0
   24088:      	str	x0, [x19, #0x18]
   2408c:      	str	x26, [x19, #0x20]
   24090:      	mov	x2, #0x1                ; =1
   24094:      	str	x2, [x19, #0x30]
   24098:      	mov	x4, #0x101010101010101  ; =72340172838076673
   2409c:      	str	x4, [x19, #0x38]
   240a0:      	mov	x21, #0x2               ; =2
   240a4:      	str	x21, [x19, #0x40]
   240a8:      	mov	x4, #0x3                ; =3
   240ac:      	str	x4, [x19, #0x48]
   240b0:      	mov	x4, #0x4                ; =4
   240b4:      	str	x4, [x19, #0x50]
   240b8:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   240bc:      	str	x4, [x19, #0x78]
   240c0:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   240c4:      	str	x4, [x19, #0x88]
   240c8:      	mov	x4, #0x38               ; =56
   240cc:      	str	x4, [x19, #0x90]
   240d0:      	mov	x4, #0x3a               ; =58
   240d4:      	str	x4, [x19, #0x98]
   240d8:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   240dc:      	str	x4, [x19, #0xb0]
   240e0:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   240e4:      	str	x4, [x19, #0xb8]
   240e8:      	str	x0, [x19, #0x188]
   240ec:      	str	x2, [x19, #0x190]
   240f0:      	str	x22, [x19, #0x17a0]
   240f4:      	str	x23, [x19, #0x17a8]
   240f8:      	ldur	x24, [sp, #0xe0]
   240fc:      	uxtb	w4, w24
   24100:      	str	x4, [x19, #0x17b8]
   24104:      	str	x15, [x19, #0x1c70]
   24108:      	str	x12, [x19, #0x1c78]
   2410c:      	str	x22, [x19, #0x1c80]
   24110:      	str	x25, [x19, #0x1ca8]
   24114:      	str	x27, [x19, #0x1cd0]
   24118:      	add	x1, x1, #0x2
   2411c:      	str	x1, [x19, #0x1cd8]
   24120:      	str	x10, [x19, #0x4c60]
   24124:      	mov	w1, #0x2646             ; =9798
   24128:      	movk	w1, #0x1, lsl #16
   2412c:      	sub	x1, x3, x1
   24130:      	str	x1, [x19, #0x4c68]
   24134:      	ldur	x4, [sp, #0x80]
   24138:      	str	x4, [x19, #0x4c70]
   2413c:      	str	x22, [x19, #0x4f70]
   24140:      	str	x23, [x19, #0x4f78]
   24144:      	str	x15, [x19, #0x55d8]
   24148:      	str	x12, [x19, #0x55e0]
   2414c:      	str	x22, [x19, #0x55e8]
   24150:      	ldur	x25, [sp, #0x10]
   24154:      	str	x25, [x19, #0x55f0]
   24158:      	ldur	x24, [sp, #0x58]
   2415c:      	str	x24, [x19, #0x55f8]
   24160:      	ldur	x27, [sp, #0x60]
   24164:      	str	x27, [x19, #0x5600]
   24168:      	ldur	x25, [sp, #0x68]
   2416c:      	str	x25, [x19, #0x5608]
   24170:      	ldur	x26, [sp, #0x70]
   24174:      	str	x26, [x19, #0x5610]
   24178:      	ldur	x3, [sp, #0x50]
   2417c:      	str	x3, [x19, #0x5a20]
   24180:      	add	x3, x8, #0x1
   24184:      	str	x3, [x19, #0x5bb0]
   24188:      	ldur	x26, [sp, #0x88]
   2418c:      	str	x26, [x19, #0x5bb8]
   24190:      	ldur	x6, [sp, #0x90]
   24194:      	str	x6, [x19, #0x5bc0]
   24198:      	ldur	x4, [sp, #0x78]
   2419c:      	sub	x1, x4, x1
   241a0:      	mov	w4, #0xc87e             ; =51326
   241a4:      	movk	w4, #0x1, lsl #16
   241a8:      	msub	x1, x3, x4, x1
   241ac:      	str	x1, [x19, #0x5bc8]
   241b0:      	str	x0, [x19, #0x5bd0]
   241b4:      	str	x0, [x19, #0x5bd8]
   241b8:      	ldur	x10, [sp, #0x98]
   241bc:      	str	x10, [x19, #0x5be8]
   241c0:      	ldur	x4, [sp, #0xa0]
   241c4:      	str	x4, [x19, #0x5bf0]
   241c8:      	str	x2, [x19, #0x5c00]
   241cc:      	ldur	x7, [sp, #0x40]
   241d0:      	str	x7, [x19, #0x5c08]
   241d4:      	str	x13, [x19, #0x5c18]
   241d8:      	ldur	x13, [sp, #0xa8]
   241dc:      	str	x13, [x19, #0x5c20]
   241e0:      	ldr	x4, [x19, #0x4c60]
   241e4:      	cmp	x4, #0x0
   241e8:      	b.ne	0x21350 <_mech_canonical_program_entry_v1_numeric_1282+0x37d0>
   241ec:      	b	0x21560 <_mech_canonical_program_entry_v1_numeric_1282+0x39e0>
   241f0:      	stur	x21, [sp, #0xb8]
   241f4:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   241f8:      	stur	x21, [sp, #0xb8]
   241fc:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   24200:      	stur	x20, [sp, #0xb8]
   24204:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   24208:      	mov	x2, #0x621              ; =1569
   2420c:      	ldur	x5, [sp]
   24210:      	str	x2, [x5, #0x48]
   24214:      	mov	x5, #0x0                ; =0
   24218:      	str	x5, [x19, #0x18]
   2421c:      	str	x26, [x19, #0x20]
   24220:      	mov	x2, #0x1                ; =1
   24224:      	str	x2, [x19, #0x30]
   24228:      	mov	x6, #0x101010101010101  ; =72340172838076673
   2422c:      	str	x6, [x19, #0x38]
   24230:      	mov	x20, #0x2               ; =2
   24234:      	str	x20, [x19, #0x40]
   24238:      	mov	x6, #0x3                ; =3
   2423c:      	str	x6, [x19, #0x48]
   24240:      	mov	x6, #0x4                ; =4
   24244:      	str	x6, [x19, #0x50]
   24248:      	mov	x6, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   2424c:      	str	x6, [x19, #0x78]
   24250:      	mov	x6, #0x3333333333333333 ; =3689348814741910323
   24254:      	str	x6, [x19, #0x88]
   24258:      	mov	x6, #0x38               ; =56
   2425c:      	str	x6, [x19, #0x90]
   24260:      	mov	x6, #0x3a               ; =58
   24264:      	str	x6, [x19, #0x98]
   24268:      	mov	x6, #0x5555555555555555 ; =6148914691236517205
   2426c:      	str	x6, [x19, #0xb0]
   24270:      	mov	x6, #0x3ffffffffffffff  ; =288230376151711743
   24274:      	str	x6, [x19, #0xb8]
   24278:      	str	x5, [x19, #0x188]
   2427c:      	str	x2, [x19, #0x190]
   24280:      	str	x22, [x19, #0x17a0]
   24284:      	str	x23, [x19, #0x17a8]
   24288:      	ldur	x6, [sp, #0xe0]
   2428c:      	uxtb	w6, w6
   24290:      	str	x6, [x19, #0x17b8]
   24294:      	str	x15, [x19, #0x1c70]
   24298:      	str	x12, [x19, #0x1c78]
   2429c:      	str	x22, [x19, #0x1c80]
   242a0:      	str	x25, [x19, #0x1ca8]
   242a4:      	str	x27, [x19, #0x1d38]
   242a8:      	str	x13, [x19, #0x1d40]
   242ac:      	str	x22, [x19, #0x1d48]
   242b0:      	uxtb	w14, w4
   242b4:      	str	x14, [x19, #0x1d58]
   242b8:      	add	x4, x27, #0x1
   242bc:      	str	x4, [x19, #0x1d68]
   242c0:      	str	x10, [x19, #0x4c60]
   242c4:      	mov	w4, #0xcb86             ; =52102
   242c8:      	movk	w4, #0x2, lsl #16
   242cc:      	sub	x3, x3, x4
   242d0:      	str	x3, [x19, #0x4c68]
   242d4:      	ldur	x4, [sp, #0x80]
   242d8:      	str	x4, [x19, #0x4c70]
   242dc:      	str	x22, [x19, #0x4f70]
   242e0:      	str	x23, [x19, #0x4f78]
   242e4:      	str	x15, [x19, #0x55d8]
   242e8:      	str	x12, [x19, #0x55e0]
   242ec:      	str	x22, [x19, #0x55e8]
   242f0:      	ldur	x25, [sp, #0x10]
   242f4:      	str	x25, [x19, #0x55f0]
   242f8:      	ldur	x4, [sp, #0x58]
   242fc:      	str	x4, [x19, #0x55f8]
   24300:      	ldur	x4, [sp, #0x60]
   24304:      	str	x4, [x19, #0x5600]
   24308:      	ldur	x25, [sp, #0x68]
   2430c:      	str	x25, [x19, #0x5608]
   24310:      	ldur	x26, [sp, #0x70]
   24314:      	str	x26, [x19, #0x5610]
   24318:      	str	x27, [x19, #0x57a0]
   2431c:      	str	x13, [x19, #0x57a8]
   24320:      	str	x22, [x19, #0x57b0]
   24324:      	str	x1, [x19, #0x57b8]
   24328:      	str	x0, [x19, #0x57c0]
   2432c:      	str	x7, [x19, #0x57c8]
   24330:      	str	x11, [x19, #0x57d0]
   24334:      	str	x24, [x19, #0x57d8]
   24338:      	ldur	x1, [sp, #0x50]
   2433c:      	str	x1, [x19, #0x5a20]
   24340:      	add	x0, x8, #0x1
   24344:      	str	x0, [x19, #0x5bb0]
   24348:      	ldur	x26, [sp, #0x88]
   2434c:      	str	x26, [x19, #0x5bb8]
   24350:      	ldur	x6, [sp, #0x90]
   24354:      	str	x6, [x19, #0x5bc0]
   24358:      	ldur	x4, [sp, #0x78]
   2435c:      	sub	x1, x4, x3
   24360:      	mov	w3, #0xc87e             ; =51326
   24364:      	movk	w3, #0x1, lsl #16
   24368:      	msub	x0, x0, x3, x1
   2436c:      	str	x0, [x19, #0x5bc8]
   24370:      	str	x5, [x19, #0x5bd0]
   24374:      	str	x5, [x19, #0x5bd8]
   24378:      	ldur	x10, [sp, #0x98]
   2437c:      	str	x10, [x19, #0x5be8]
   24380:      	ldur	x4, [sp, #0xa0]
   24384:      	str	x4, [x19, #0x5bf0]
   24388:      	str	x2, [x19, #0x5c00]
   2438c:      	ldur	x7, [sp, #0x40]
   24390:      	str	x7, [x19, #0x5c08]
   24394:      	str	x2, [x19, #0x5c18]
   24398:      	ldur	x5, [sp, #0x48]
   2439c:      	str	x5, [x19, #0x5c20]
   243a0:      	ldr	x0, [x19, #0x4c60]
   243a4:      	cmp	x0, #0x0
   243a8:      	b.ne	0x21a3c <_mech_canonical_program_entry_v1_numeric_1282+0x3ebc>
   243ac:      	b	0x21c64 <_mech_canonical_program_entry_v1_numeric_1282+0x40e4>
   243b0:      	stur	x20, [sp, #0xb8]
   243b4:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   243b8:      	stur	x20, [sp, #0xb8]
   243bc:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   243c0:      	mov	x0, #0x6c4              ; =1732
   243c4:      	ldur	x1, [sp]
   243c8:      	str	x0, [x1, #0x48]
   243cc:      	mov	x0, #0x0                ; =0
   243d0:      	str	x0, [x19, #0x4c60]
   243d4:      	mov	x0, #0x3                ; =3
   243d8:      	stur	x0, [sp, #0xb8]
   243dc:      	ldr	x0, [sp, #0x180]
   243e0:      	cmp	x0, #0x19c
   243e4:      	b.hs	0x21e98 <_mech_canonical_program_entry_v1_numeric_1282+0x4318>
   243e8:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   243ec:      	mov	x0, #0x6c8              ; =1736
   243f0:      	ldur	x2, [sp]
   243f4:      	str	x0, [x2, #0x48]
   243f8:      	mov	x0, #0x0                ; =0
   243fc:      	str	x0, [x19, #0x4c60]
   24400:      	mov	x0, #0x3                ; =3
   24404:      	stur	x0, [sp, #0xb8]
   24408:      	ldr	x0, [sp, #0x180]
   2440c:      	cmp	x0, #0x19c
   24410:      	b.hs	0x22064 <_mech_canonical_program_entry_v1_numeric_1282+0x44e4>
   24414:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   24418:      	mov	x0, #0x6cc              ; =1740
   2441c:      	ldur	x2, [sp]
   24420:      	str	x0, [x2, #0x48]
   24424:      	mov	x0, #0x0                ; =0
   24428:      	str	x0, [x19, #0x4c60]
   2442c:      	mov	x0, #0x3                ; =3
   24430:      	ldr	x2, [sp, #0x180]
   24434:      	stur	x0, [sp, #0xb8]
   24438:      	cmp	x2, #0x19c
   2443c:      	b.hs	0x22210 <_mech_canonical_program_entry_v1_numeric_1282+0x4690>
   24440:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   24444:      	mov	x9, #0x6d0              ; =1744
   24448:      	ldur	x0, [sp]
   2444c:      	str	x9, [x0, #0x48]
   24450:      	mov	x9, #0x0                ; =0
   24454:      	str	x9, [x19, #0x4c60]
   24458:      	mov	x0, #0x3                ; =3
   2445c:      	stur	x0, [sp, #0xb8]
   24460:      	ldr	x0, [sp, #0x180]
   24464:      	cmp	x0, #0x19c
   24468:      	b.hs	0x223bc <_mech_canonical_program_entry_v1_numeric_1282+0x483c>
   2446c:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   24470:      	mov	x0, #0x6d4              ; =1748
   24474:      	ldur	x2, [sp]
   24478:      	str	x0, [x2, #0x48]
   2447c:      	mov	x0, #0x0                ; =0
   24480:      	str	x0, [x19, #0x4c60]
   24484:      	mov	x0, #0x3                ; =3
   24488:      	stur	x0, [sp, #0xb8]
   2448c:      	ldr	x0, [sp, #0x180]
   24490:      	cmp	x0, #0x19c
   24494:      	b.hs	0x2256c <_mech_canonical_program_entry_v1_numeric_1282+0x49ec>
   24498:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   2449c:      	mov	x2, #0x6dd              ; =1757
   244a0:      	ldur	x0, [sp]
   244a4:      	str	x2, [x0, #0x48]
   244a8:      	mov	x4, #0x0                ; =0
   244ac:      	str	x4, [x19, #0x18]
   244b0:      	mov	x5, #0x1000000000000000 ; =1152921504606846976
   244b4:      	str	x5, [x19, #0x20]
   244b8:      	mov	x0, #0x1                ; =1
   244bc:      	stur	x0, [sp, #0xb8]
   244c0:      	str	x0, [x19, #0x30]
   244c4:      	mov	x6, #0x101010101010101  ; =72340172838076673
   244c8:      	str	x6, [x19, #0x38]
   244cc:      	mov	x7, #0x2                ; =2
   244d0:      	str	x7, [x19, #0x40]
   244d4:      	mov	x9, #0x3                ; =3
   244d8:      	str	x9, [x19, #0x48]
   244dc:      	mov	x9, #0x4                ; =4
   244e0:      	str	x9, [x19, #0x50]
   244e4:      	mov	x14, #0xf0f0f0f0f0f0f0f ; =1085102592571150095
   244e8:      	str	x14, [x19, #0x78]
   244ec:      	mov	x14, #0x3333333333333333 ; =3689348814741910323
   244f0:      	str	x14, [x19, #0x88]
   244f4:      	mov	x14, #0x38              ; =56
   244f8:      	str	x14, [x19, #0x90]
   244fc:      	mov	x14, #0x3a              ; =58
   24500:      	str	x14, [x19, #0x98]
   24504:      	mov	x14, #0x5555555555555555 ; =6148914691236517205
   24508:      	str	x14, [x19, #0xb0]
   2450c:      	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
   24510:      	str	x0, [x19, #0xb8]
   24514:      	str	x4, [x19, #0x188]
   24518:      	ldur	x0, [sp, #0xb8]
   2451c:      	str	x0, [x19, #0x190]
   24520:      	str	x24, [x19, #0x17a0]
   24524:      	str	x23, [x19, #0x17a8]
   24528:      	str	x10, [x19, #0x4c60]
   2452c:      	str	x3, [x19, #0x4c68]
   24530:      	ldur	x4, [sp, #0x80]
   24534:      	str	x4, [x19, #0x4c70]
   24538:      	ldur	x1, [sp, #0x50]
   2453c:      	str	x1, [x19, #0x5a20]
   24540:      	str	x8, [x19, #0x5bb0]
   24544:      	ldur	x26, [sp, #0x88]
   24548:      	str	x26, [x19, #0x5bb8]
   2454c:      	ldur	x6, [sp, #0x90]
   24550:      	str	x6, [x19, #0x5bc0]
   24554:      	ldur	x4, [sp, #0x78]
   24558:      	sub	x1, x4, x3
   2455c:      	mov	w0, #0xc87e             ; =51326
   24560:      	movk	w0, #0x1, lsl #16
   24564:      	msub	x0, x8, x0, x1
   24568:      	str	x0, [x19, #0x5bc8]
   2456c:      	str	x25, [x19, #0x5bd0]
   24570:      	str	x15, [x19, #0x5bd8]
   24574:      	ldur	x10, [sp, #0x98]
   24578:      	str	x10, [x19, #0x5be8]
   2457c:      	ldur	x4, [sp, #0xa0]
   24580:      	str	x4, [x19, #0x5bf0]
   24584:      	str	x12, [x19, #0x5c00]
   24588:      	str	x11, [x19, #0x5c08]
   2458c:      	str	x13, [x19, #0x5c18]
   24590:      	ldur	x13, [sp, #0xa8]
   24594:      	str	x13, [x19, #0x5c20]
   24598:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   2459c:      	mov	x0, #0x6b0              ; =1712
   245a0:      	ldur	x1, [sp]
   245a4:      	str	x0, [x1, #0x48]
   245a8:      	mov	x1, #0x0                ; =0
   245ac:      	str	x1, [x19, #0x18]
   245b0:      	str	x26, [x19, #0x20]
   245b4:      	mov	x0, #0x1                ; =1
   245b8:      	stur	x0, [sp, #0xb8]
   245bc:      	str	x0, [x19, #0x30]
   245c0:      	mov	x0, #0x101010101010101  ; =72340172838076673
   245c4:      	str	x0, [x19, #0x38]
   245c8:      	mov	x0, #0x2                ; =2
   245cc:      	str	x0, [x19, #0x40]
   245d0:      	mov	x0, #0x3                ; =3
   245d4:      	str	x0, [x19, #0x48]
   245d8:      	mov	x0, #0x4                ; =4
   245dc:      	str	x0, [x19, #0x50]
   245e0:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   245e4:      	str	x0, [x19, #0x78]
   245e8:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   245ec:      	str	x0, [x19, #0x88]
   245f0:      	mov	x0, #0x38               ; =56
   245f4:      	str	x0, [x19, #0x90]
   245f8:      	mov	x0, #0x3a               ; =58
   245fc:      	str	x0, [x19, #0x98]
   24600:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   24604:      	str	x0, [x19, #0xb0]
   24608:      	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
   2460c:      	str	x0, [x19, #0xb8]
   24610:      	str	x1, [x19, #0x188]
   24614:      	ldur	x0, [sp, #0xb8]
   24618:      	str	x0, [x19, #0x190]
   2461c:      	str	x22, [x19, #0x17a0]
   24620:      	str	x23, [x19, #0x17a8]
   24624:      	ldur	x24, [sp, #0xe0]
   24628:      	uxtb	w0, w24
   2462c:      	str	x0, [x19, #0x17b8]
   24630:      	str	x15, [x19, #0x1c70]
   24634:      	str	x12, [x19, #0x1c78]
   24638:      	str	x22, [x19, #0x1c80]
   2463c:      	str	x10, [x19, #0x4c60]
   24640:      	str	x3, [x19, #0x4c68]
   24644:      	ldur	x4, [sp, #0x80]
   24648:      	str	x4, [x19, #0x4c70]
   2464c:      	ldur	x2, [sp, #0x50]
   24650:      	str	x2, [x19, #0x5a20]
   24654:      	add	x7, x8, #0x1
   24658:      	str	x7, [x19, #0x5bb0]
   2465c:      	ldur	x26, [sp, #0x88]
   24660:      	str	x26, [x19, #0x5bb8]
   24664:      	ldur	x6, [sp, #0x90]
   24668:      	str	x6, [x19, #0x5bc0]
   2466c:      	ldur	x4, [sp, #0x78]
   24670:      	sub	x10, x4, x3
   24674:      	mov	w11, #0xc87e            ; =51326
   24678:      	movk	w11, #0x1, lsl #16
   2467c:      	msub	x10, x7, x11, x10
   24680:      	str	x10, [x19, #0x5bc8]
   24684:      	str	x1, [x19, #0x5bd0]
   24688:      	str	x1, [x19, #0x5bd8]
   2468c:      	ldur	x10, [sp, #0x98]
   24690:      	str	x10, [x19, #0x5be8]
   24694:      	ldur	x4, [sp, #0xa0]
   24698:      	str	x4, [x19, #0x5bf0]
   2469c:      	ldur	x0, [sp, #0xb8]
   246a0:      	str	x0, [x19, #0x5c00]
   246a4:      	ldur	x7, [sp, #0x40]
   246a8:      	str	x7, [x19, #0x5c08]
   246ac:      	str	x13, [x19, #0x5c18]
   246b0:      	ldur	x13, [sp, #0xa8]
   246b4:      	str	x13, [x19, #0x5c20]
   246b8:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   246bc:      	mov	x0, #0x6a0              ; =1696
   246c0:      	ldur	x1, [sp]
   246c4:      	str	x0, [x1, #0x48]
   246c8:      	mov	x1, #0x0                ; =0
   246cc:      	str	x1, [x19, #0x18]
   246d0:      	str	x26, [x19, #0x20]
   246d4:      	mov	x0, #0x1                ; =1
   246d8:      	stur	x0, [sp, #0xb8]
   246dc:      	str	x0, [x19, #0x30]
   246e0:      	mov	x0, #0x101010101010101  ; =72340172838076673
   246e4:      	str	x0, [x19, #0x38]
   246e8:      	mov	x0, #0x2                ; =2
   246ec:      	str	x0, [x19, #0x40]
   246f0:      	mov	x0, #0x3                ; =3
   246f4:      	str	x0, [x19, #0x48]
   246f8:      	mov	x0, #0x4                ; =4
   246fc:      	str	x0, [x19, #0x50]
   24700:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   24704:      	str	x0, [x19, #0x78]
   24708:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   2470c:      	str	x0, [x19, #0x88]
   24710:      	mov	x0, #0x38               ; =56
   24714:      	str	x0, [x19, #0x90]
   24718:      	mov	x0, #0x3a               ; =58
   2471c:      	str	x0, [x19, #0x98]
   24720:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   24724:      	str	x0, [x19, #0xb0]
   24728:      	ldur	x9, [sp, #0xc0]
   2472c:      	str	x9, [x19, #0xb8]
   24730:      	str	x1, [x19, #0x188]
   24734:      	ldur	x0, [sp, #0xb8]
   24738:      	str	x0, [x19, #0x190]
   2473c:      	str	x22, [x19, #0x17a0]
   24740:      	str	x23, [x19, #0x17a8]
   24744:      	ldur	x24, [sp, #0xe0]
   24748:      	uxtb	w0, w24
   2474c:      	str	x0, [x19, #0x17b8]
   24750:      	str	x15, [x19, #0x1c70]
   24754:      	str	x12, [x19, #0x1c78]
   24758:      	str	x22, [x19, #0x1c80]
   2475c:      	str	x25, [x19, #0x1ca8]
   24760:      	str	x27, [x19, #0x1d38]
   24764:      	str	x13, [x19, #0x1d40]
   24768:      	str	x22, [x19, #0x1d48]
   2476c:      	str	x10, [x19, #0x4c60]
   24770:      	mov	w0, #0xcb86             ; =52102
   24774:      	movk	w0, #0x2, lsl #16
   24778:      	sub	x2, x3, x0
   2477c:      	str	x2, [x19, #0x4c68]
   24780:      	ldur	x4, [sp, #0x80]
   24784:      	str	x4, [x19, #0x4c70]
   24788:      	ldur	x13, [sp, #0x50]
   2478c:      	str	x13, [x19, #0x5a20]
   24790:      	add	x3, x8, #0x1
   24794:      	str	x3, [x19, #0x5bb0]
   24798:      	ldur	x26, [sp, #0x88]
   2479c:      	str	x26, [x19, #0x5bb8]
   247a0:      	ldur	x6, [sp, #0x90]
   247a4:      	str	x6, [x19, #0x5bc0]
   247a8:      	ldur	x4, [sp, #0x78]
   247ac:      	sub	x2, x4, x2
   247b0:      	mov	w0, #0xc87e             ; =51326
   247b4:      	movk	w0, #0x1, lsl #16
   247b8:      	msub	x0, x3, x0, x2
   247bc:      	str	x0, [x19, #0x5bc8]
   247c0:      	str	x1, [x19, #0x5bd0]
   247c4:      	str	x1, [x19, #0x5bd8]
   247c8:      	ldur	x10, [sp, #0x98]
   247cc:      	str	x10, [x19, #0x5be8]
   247d0:      	ldur	x4, [sp, #0xa0]
   247d4:      	str	x4, [x19, #0x5bf0]
   247d8:      	ldur	x0, [sp, #0xb8]
   247dc:      	str	x0, [x19, #0x5c00]
   247e0:      	ldur	x7, [sp, #0x40]
   247e4:      	str	x7, [x19, #0x5c08]
   247e8:      	str	x0, [x19, #0x5c18]
   247ec:      	ldur	x5, [sp, #0x48]
   247f0:      	str	x5, [x19, #0x5c20]
   247f4:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   247f8:      	mov	x14, #0x5df             ; =1503
   247fc:      	ldur	x0, [sp]
   24800:      	str	x14, [x0, #0x48]
   24804:      	mov	x15, #0x0               ; =0
   24808:      	str	x15, [x19, #0x18]
   2480c:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   24810:      	str	x0, [x19, #0x20]
   24814:      	mov	x0, #0x1                ; =1
   24818:      	stur	x0, [sp, #0xb8]
   2481c:      	str	x0, [x19, #0x30]
   24820:      	mov	x0, #0x101010101010101  ; =72340172838076673
   24824:      	str	x0, [x19, #0x38]
   24828:      	mov	x0, #0x2                ; =2
   2482c:      	str	x0, [x19, #0x40]
   24830:      	mov	x0, #0x3                ; =3
   24834:      	str	x0, [x19, #0x48]
   24838:      	mov	x0, #0x4                ; =4
   2483c:      	str	x0, [x19, #0x50]
   24840:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   24844:      	str	x0, [x19, #0x78]
   24848:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   2484c:      	str	x0, [x19, #0x88]
   24850:      	mov	x0, #0x38               ; =56
   24854:      	str	x0, [x19, #0x90]
   24858:      	mov	x0, #0x3a               ; =58
   2485c:      	str	x0, [x19, #0x98]
   24860:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   24864:      	str	x0, [x19, #0xb0]
   24868:      	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
   2486c:      	str	x0, [x19, #0xb8]
   24870:      	str	x15, [x19, #0x188]
   24874:      	ldur	x0, [sp, #0xb8]
   24878:      	str	x0, [x19, #0x190]
   2487c:      	str	x22, [x19, #0x17a0]
   24880:      	str	x23, [x19, #0x17a8]
   24884:      	ldur	x24, [sp, #0xe0]
   24888:      	uxtb	w0, w24
   2488c:      	str	x0, [x19, #0x17b8]
   24890:      	str	x4, [x19, #0x1858]
   24894:      	mov	x15, x26
   24898:      	str	x15, [x19, #0x1860]
   2489c:      	str	x22, [x19, #0x1868]
   248a0:      	ldur	x15, [sp, #0xd0]
   248a4:      	str	x15, [x19, #0x1870]
   248a8:      	str	x10, [x19, #0x4c60]
   248ac:      	str	x3, [x19, #0x4c68]
   248b0:      	ldur	x4, [sp, #0x80]
   248b4:      	str	x4, [x19, #0x4c70]
   248b8:      	ldur	x1, [sp, #0x50]
   248bc:      	str	x1, [x19, #0x5a20]
   248c0:      	add	x1, x8, #0x1
   248c4:      	str	x1, [x19, #0x5bb0]
   248c8:      	ldur	x26, [sp, #0x88]
   248cc:      	str	x26, [x19, #0x5bb8]
   248d0:      	ldur	x6, [sp, #0x90]
   248d4:      	str	x6, [x19, #0x5bc0]
   248d8:      	ldur	x4, [sp, #0x78]
   248dc:      	sub	x2, x4, x3
   248e0:      	mov	w0, #0xc87e             ; =51326
   248e4:      	movk	w0, #0x1, lsl #16
   248e8:      	msub	x0, x1, x0, x2
   248ec:      	str	x0, [x19, #0x5bc8]
   248f0:      	ldur	x0, [sp, #0xb8]
   248f4:      	str	x0, [x19, #0x5bd0]
   248f8:      	ldur	x24, [sp, #0x20]
   248fc:      	str	x24, [x19, #0x5bd8]
   24900:      	ldur	x10, [sp, #0x98]
   24904:      	str	x10, [x19, #0x5be8]
   24908:      	ldur	x4, [sp, #0xa0]
   2490c:      	str	x4, [x19, #0x5bf0]
   24910:      	str	x12, [x19, #0x5c00]
   24914:      	str	x11, [x19, #0x5c08]
   24918:      	str	x13, [x19, #0x5c18]
   2491c:      	ldur	x13, [sp, #0xa8]
   24920:      	str	x13, [x19, #0x5c20]
   24924:      	b	0x24a78 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
   24928:      	mov	x0, #0x5cf              ; =1487
   2492c:      	ldur	x1, [sp]
   24930:      	str	x0, [x1, #0x48]
   24934:      	mov	x1, #0x0                ; =0
   24938:      	str	x1, [x19, #0x18]
   2493c:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   24940:      	str	x0, [x19, #0x20]
   24944:      	mov	x0, #0x1                ; =1
   24948:      	stur	x0, [sp, #0xb8]
   2494c:      	str	x0, [x19, #0x30]
   24950:      	mov	x2, #0x101010101010101  ; =72340172838076673
   24954:      	str	x2, [x19, #0x38]
   24958:      	mov	x6, #0x2                ; =2
   2495c:      	str	x6, [x19, #0x40]
   24960:      	mov	x6, #0x3                ; =3
   24964:      	str	x6, [x19, #0x48]
   24968:      	mov	x6, #0x4                ; =4
   2496c:      	str	x6, [x19, #0x50]
   24970:      	mov	x6, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   24974:      	str	x6, [x19, #0x78]
   24978:      	mov	x7, #0x3333333333333333 ; =3689348814741910323
   2497c:      	str	x7, [x19, #0x88]
   24980:      	mov	x14, #0x38              ; =56
   24984:      	str	x14, [x19, #0x90]
   24988:      	mov	x14, #0x3a              ; =58
   2498c:      	str	x14, [x19, #0x98]
   24990:      	mov	x14, #0x5555555555555555 ; =6148914691236517205
   24994:      	str	x14, [x19, #0xb0]
   24998:      	mov	x14, #0x3ffffffffffffff ; =288230376151711743
   2499c:      	str	x14, [x19, #0xb8]
   249a0:      	str	x1, [x19, #0x188]
   249a4:      	str	x0, [x19, #0x190]
   249a8:      	str	x22, [x19, #0x17a0]
   249ac:      	str	x23, [x19, #0x17a8]
   249b0:      	ldur	x24, [sp, #0xe0]
   249b4:      	uxtb	w0, w24
   249b8:      	str	x0, [x19, #0x17b8]
   249bc:      	ldur	x27, [sp, #0x18]
   249c0:      	str	x27, [x19, #0x1858]
   249c4:      	mov	x15, x26
   249c8:      	str	x15, [x19, #0x1860]
   249cc:      	str	x22, [x19, #0x1868]
   249d0:      	ldur	x15, [sp, #0xd0]
   249d4:      	str	x15, [x19, #0x1870]
   249d8:      	ldur	x15, [sp, #0xc8]
   249dc:      	uxtb	w0, w15
   249e0:      	str	x0, [x19, #0x1880]
   249e4:      	str	x4, [x19, #0x1918]
   249e8:      	str	x5, [x19, #0x1920]
   249ec:      	str	x22, [x19, #0x1928]
   249f0:      	ldur	x15, [sp, #0xd0]
   249f4:      	str	x15, [x19, #0x1930]
   249f8:      	str	x10, [x19, #0x4c60]
   249fc:      	mov	w0, #0xdc1e             ; =56350
   24a00:      	movk	w0, #0x2, lsl #16
   24a04:      	sub	x1, x9, x0
   24a08:      	str	x1, [x19, #0x4c68]
   24a0c:      	ldur	x4, [sp, #0x80]
   24a10:      	str	x4, [x19, #0x4c70]
   24a14:      	ldur	x0, [sp, #0x50]
   24a18:      	str	x0, [x19, #0x5a20]
   24a1c:      	add	x2, x8, #0x1
   24a20:      	str	x2, [x19, #0x5bb0]
   24a24:      	ldur	x26, [sp, #0x88]
   24a28:      	str	x26, [x19, #0x5bb8]
   24a2c:      	ldur	x6, [sp, #0x90]
   24a30:      	str	x6, [x19, #0x5bc0]
   24a34:      	ldur	x4, [sp, #0x78]
   24a38:      	sub	x1, x4, x1
   24a3c:      	mov	w0, #0xc87e             ; =51326
   24a40:      	movk	w0, #0x1, lsl #16
   24a44:      	msub	x0, x2, x0, x1
   24a48:      	str	x0, [x19, #0x5bc8]
   24a4c:      	ldur	x0, [sp, #0xb8]
   24a50:      	str	x0, [x19, #0x5bd0]
   24a54:      	ldur	x24, [sp, #0x20]
   24a58:      	str	x24, [x19, #0x5bd8]
   24a5c:      	str	x0, [x19, #0x5be8]
   24a60:      	str	x3, [x19, #0x5bf0]
   24a64:      	str	x12, [x19, #0x5c00]
   24a68:      	str	x11, [x19, #0x5c08]
   24a6c:      	str	x13, [x19, #0x5c18]
   24a70:      	ldur	x13, [sp, #0xa8]
   24a74:      	str	x13, [x19, #0x5c20]
   24a78:      	mov	x1, #0x0                ; =0
   24a7c:      	ldur	x0, [sp, #0xb8]
   24a80:      	add	sp, sp, #0x1b0
   24a84:      	ldp	x19, x20, [sp], #0x10
   24a88:      	ldp	x21, x22, [sp], #0x10
   24a8c:      	ldp	x23, x24, [sp], #0x10
   24a90:      	ldp	x25, x26, [sp], #0x10
   24a94:      	ldp	x27, x28, [sp], #0x10
   24a98:      	ldp	x29, x30, [sp], #0x10
   24a9c:      	retab
		...
