
/private/tmp/mech-related-movable-capture-reads-runners-20261107-v3/reuse-4/build/object.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000000001e180 <_mech_canonical_program_entry_v1_numeric_1282>:
   1e180:      	pacibsp
   1e184:      	stp	x29, x30, [sp, #-0x10]!
   1e188:      	mov	x29, sp
   1e18c:      	stp	x27, x28, [sp, #-0x10]!
   1e190:      	stp	x25, x26, [sp, #-0x10]!
   1e194:      	stp	x23, x24, [sp, #-0x10]!
   1e198:      	stp	x21, x22, [sp, #-0x10]!
   1e19c:      	stp	x19, x20, [sp, #-0x10]!
   1e1a0:      	sub	sp, sp, #0x1b0
   1e1a4:      	mov	x8, x1
   1e1a8:      	stur	x2, [sp, #0x8]
   1e1ac:      	ldr	x21, [x0, #0x50]
   1e1b0:      	str	x21, [sp, #0x1a0]
   1e1b4:      	ldr	x6, [x0, #0x58]
   1e1b8:      	ldr	x1, [x0, #0x60]
   1e1bc:      	ldr	x27, [x0, #0x68]
   1e1c0:      	stur	x0, [sp]
   1e1c4:      	str	x27, [sp, #0x188]
   1e1c8:      	mov	x0, #0x3                ; =3
   1e1cc:      	cmp	x21, #0x0
   1e1d0:      	b.eq	0x22ca4 <_mech_canonical_program_entry_v1_numeric_1282+0x4b24>
   1e1d4:      	mov	x0, #0x3                ; =3
   1e1d8:      	cmp	x6, #0x0
   1e1dc:      	str	x6, [sp, #0x198]
   1e1e0:      	b.eq	0x22cac <_mech_canonical_program_entry_v1_numeric_1282+0x4b2c>
   1e1e4:      	mov	x0, #0x3                ; =3
   1e1e8:      	mov	x21, x0
   1e1ec:      	cmp	x1, #0x0
   1e1f0:      	b.eq	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   1e1f4:      	mov	x0, x8
   1e1f8:      	ldr	x23, [x0, #0x4c60]
   1e1fc:      	cmp	x23, #0x0
   1e200:      	stur	x23, [sp, #0x78]
   1e204:      	b.eq	0x1e680 <_mech_canonical_program_entry_v1_numeric_1282+0x500>
   1e208:      	ldr	x24, [x1, #0x10]
   1e20c:      	ldr	x3, [x0, #0x4c68]
   1e210:      	ldr	x4, [x0, #0x4c70]
   1e214:      	mov	x8, x0
   1e218:      	stur	x4, [sp, #0x80]
   1e21c:      	ldr	x22, [x24, #0xf60]
   1e220:      	ldr	x0, [x24, #0xf70]
   1e224:      	str	x0, [sp, #0x180]
   1e228:      	ldr	x21, [x1, #0xab8]
   1e22c:      	ldr	x14, [x1, #0xac0]
   1e230:      	stur	x14, [sp, #0x48]
   1e234:      	ldr	x0, [x1, #0xac8]
   1e238:      	ldr	x0, [x1, #0xad0]
   1e23c:      	ldr	x27, [x1, #0xad8]
   1e240:      	str	x27, [sp, #0x178]
   1e244:      	ldr	x27, [x1, #0xae0]
   1e248:      	str	x27, [sp, #0x170]
   1e24c:      	ldr	x0, [x1, #0xae8]
   1e250:      	ldr	x0, [x1, #0xaf0]
   1e254:      	ldr	x27, [x1, #0xaf8]
   1e258:      	str	x27, [sp, #0x168]
   1e25c:      	ldr	x27, [x1, #0xb00]
   1e260:      	str	x27, [sp, #0x160]
   1e264:      	ldr	x0, [x1, #0xb08]
   1e268:      	ldr	x0, [x1, #0xb10]
   1e26c:      	ldr	x27, [x1, #0xb18]
   1e270:      	str	x27, [sp, #0x158]
   1e274:      	ldr	x27, [x1, #0xb20]
   1e278:      	str	x27, [sp, #0x150]
   1e27c:      	ldr	x0, [x1, #0xb28]
   1e280:      	ldr	x0, [x1, #0xb30]
   1e284:      	ldr	x27, [x1, #0xb38]
   1e288:      	str	x27, [sp, #0x148]
   1e28c:      	ldr	x27, [x1, #0xb40]
   1e290:      	str	x27, [sp, #0x140]
   1e294:      	ldr	x0, [x1, #0xb48]
   1e298:      	ldr	x0, [x1, #0xb50]
   1e29c:      	ldr	x27, [x1, #0xb58]
   1e2a0:      	str	x27, [sp, #0x138]
   1e2a4:      	ldr	x27, [x1, #0xb60]
   1e2a8:      	str	x27, [sp, #0x130]
   1e2ac:      	ldr	x0, [x1, #0xb68]
   1e2b0:      	ldr	x0, [x1, #0xb70]
   1e2b4:      	ldr	x27, [x1, #0xb78]
   1e2b8:      	str	x27, [sp, #0x128]
   1e2bc:      	ldr	x27, [x1, #0xb80]
   1e2c0:      	str	x27, [sp, #0x120]
   1e2c4:      	ldr	x0, [x1, #0xb88]
   1e2c8:      	ldr	x0, [x1, #0xb90]
   1e2cc:      	ldr	x27, [x1, #0xb98]
   1e2d0:      	str	x27, [sp, #0x118]
   1e2d4:      	ldr	x27, [x1, #0xba0]
   1e2d8:      	str	x27, [sp, #0x110]
   1e2dc:      	ldr	x0, [x1, #0xba8]
   1e2e0:      	ldr	x0, [x1, #0xbb0]
   1e2e4:      	ldr	x20, [x1, #0xbb8]
   1e2e8:      	str	x20, [sp, #0x108]
   1e2ec:      	ldr	x27, [x1, #0xbc0]
   1e2f0:      	str	x27, [sp, #0x100]
   1e2f4:      	ldr	x0, [x1, #0xbc8]
   1e2f8:      	ldr	x0, [x1, #0xbd0]
   1e2fc:      	ldr	x27, [x1, #0xbd8]
   1e300:      	stur	x27, [sp, #0xf8]
   1e304:      	ldr	x23, [x1, #0xbe0]
   1e308:      	stur	x23, [sp, #0xf0]
   1e30c:      	ldr	x0, [x1, #0xbe8]
   1e310:      	ldr	x0, [x1, #0xbf0]
   1e314:      	ldr	x0, [x1, #0xc48]
   1e318:      	stur	x0, [sp, #0xa8]
   1e31c:      	str	x1, [sp, #0x190]
   1e320:      	mov	x11, #0x0               ; =0
   1e324:      	mov	x4, #0x1                ; =1
   1e328:      	stur	x4, [sp, #0x88]
   1e32c:      	mov	x0, x11
   1e330:      	mov	x2, x11
   1e334:      	mov	x6, x11
   1e338:      	mov	x9, x11
   1e33c:      	mov	x10, x11
   1e340:      	mov	x12, x11
   1e344:      	mov	x13, x11
   1e348:      	mov	x15, x11
   1e34c:      	mov	x23, x11
   1e350:      	mov	x27, x11
   1e354:      	stur	x3, [sp, #0x70]
   1e358:      	mov	w1, #0xc87e             ; =51326
   1e35c:      	movk	w1, #0x1, lsl #16
   1e360:      	cmp	x3, x1
   1e364:      	cset	x1, hs
   1e368:      	ldur	x4, [sp, #0xa8]
   1e36c:      	ldur	x5, [sp, #0x48]
   1e370:      	cmp	x5, x4
   1e374:      	cset	x4, ls
   1e378:      	ldur	x7, [sp, #0x48]
   1e37c:      	ldur	x14, [sp, #0xa8]
   1e380:      	sub	x5, x14, x7
   1e384:      	cmp	x5, #0x4
   1e388:      	cset	x5, hi
   1e38c:      	and	w14, w4, w5
   1e390:      	and	w1, w1, w14
   1e394:      	stur	x14, [sp, #0xe8]
   1e398:      	uxtb	w1, w1
   1e39c:      	cbnz	x1, 0x1e6a8 <_mech_canonical_program_entry_v1_numeric_1282+0x528>
   1e3a0:      	mov	x1, #0x0                ; =0
   1e3a4:      	mov	x19, x8
   1e3a8:      	str	x1, [x19, #0x18]
   1e3ac:      	mov	x4, #0x1000000000000000 ; =1152921504606846976
   1e3b0:      	str	x4, [x19, #0x20]
   1e3b4:      	mov	x4, #0x1                ; =1
   1e3b8:      	str	x4, [x19, #0x30]
   1e3bc:      	mov	x5, #0x101010101010101  ; =72340172838076673
   1e3c0:      	str	x5, [x19, #0x38]
   1e3c4:      	mov	x5, #0x2                ; =2
   1e3c8:      	str	x5, [x19, #0x40]
   1e3cc:      	mov	x5, #0x3                ; =3
   1e3d0:      	str	x5, [x19, #0x48]
   1e3d4:      	mov	x5, #0x4                ; =4
   1e3d8:      	str	x5, [x19, #0x50]
   1e3dc:      	mov	x5, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   1e3e0:      	str	x5, [x19, #0x78]
   1e3e4:      	mov	x5, #0x3333333333333333 ; =3689348814741910323
   1e3e8:      	str	x5, [x19, #0x88]
   1e3ec:      	mov	x5, #0x38               ; =56
   1e3f0:      	str	x5, [x19, #0x90]
   1e3f4:      	mov	x5, #0x3a               ; =58
   1e3f8:      	str	x5, [x19, #0x98]
   1e3fc:      	mov	x5, #0x5555555555555555 ; =6148914691236517205
   1e400:      	str	x5, [x19, #0xb0]
   1e404:      	mov	x5, #0x3ffffffffffffff  ; =288230376151711743
   1e408:      	str	x5, [x19, #0xb8]
   1e40c:      	str	x1, [x19, #0x188]
   1e410:      	str	x4, [x19, #0x190]
   1e414:      	ldur	x1, [sp, #0x78]
   1e418:      	str	x1, [x19, #0x4c60]
   1e41c:      	str	x3, [x19, #0x4c68]
   1e420:      	ldur	x7, [sp, #0x80]
   1e424:      	str	x7, [x19, #0x4c70]
   1e428:      	str	x22, [x19, #0x4f70]
   1e42c:      	ldr	x22, [sp, #0x180]
   1e430:      	str	x22, [x19, #0x4f78]
   1e434:      	ldur	x1, [sp, #0x48]
   1e438:      	str	x1, [x19, #0x5a20]
   1e43c:      	str	x11, [x19, #0x5bb0]
   1e440:      	ldur	x1, [sp, #0x88]
   1e444:      	str	x1, [x19, #0x5bb8]
   1e448:      	str	x0, [x19, #0x5bc0]
   1e44c:      	ldur	x4, [sp, #0x70]
   1e450:      	sub	x14, x4, x3
   1e454:      	mov	w0, #0xc87e             ; =51326
   1e458:      	movk	w0, #0x1, lsl #16
   1e45c:      	msub	x14, x11, x0, x14
   1e460:      	str	x14, [x19, #0x5bc8]
   1e464:      	str	x10, [x19, #0x5bd0]
   1e468:      	str	x15, [x19, #0x5bd8]
   1e46c:      	str	x6, [x19, #0x5be8]
   1e470:      	str	x13, [x19, #0x5bf0]
   1e474:      	str	x12, [x19, #0x5c00]
   1e478:      	str	x9, [x19, #0x5c08]
   1e47c:      	str	x23, [x19, #0x5c18]
   1e480:      	str	x2, [x19, #0x5c20]
   1e484:      	ldr	x0, [x19, #0x4c60]
   1e488:      	cmp	x0, #0x0
   1e48c:      	b.eq	0x1e680 <_mech_canonical_program_entry_v1_numeric_1282+0x500>
   1e490:      	ldr	x3, [x19, #0x4c68]
   1e494:      	ldr	x4, [x19, #0x4c70]
   1e498:      	mov	x0, #0x0                ; =0
   1e49c:      	str	x0, [x19, #0x4c60]
   1e4a0:      	mov	x0, #0x3                ; =3
   1e4a4:      	ldr	x27, [sp, #0x188]
   1e4a8:      	cmp	x27, #0x19a
   1e4ac:      	b.lo	0x22cb4 <_mech_canonical_program_entry_v1_numeric_1282+0x4b34>
   1e4b0:      	ldr	x0, [x19, #0x4f70]
   1e4b4:      	ldr	x14, [sp, #0x190]
   1e4b8:      	str	x0, [x14, #0x10]
   1e4bc:      	ldr	x1, [x19, #0x4f78]
   1e4c0:      	str	x1, [x14, #0x18]
   1e4c4:      	ldr	x2, [x19, #0x5a20]
   1e4c8:      	str	x2, [x14, #0xac0]
   1e4cc:      	str	x0, [x14, #0x10]
   1e4d0:      	str	x1, [x14, #0x18]
   1e4d4:      	ldr	x0, [x19, #0x50c0]
   1e4d8:      	str	x0, [x14, #0x160]
   1e4dc:      	ldr	x0, [x19, #0x50c8]
   1e4e0:      	str	x0, [x14, #0x168]
   1e4e4:      	ldr	x0, [x19, #0x50d0]
   1e4e8:      	str	x0, [x14, #0x170]
   1e4ec:      	ldr	x0, [x19, #0x50d8]
   1e4f0:      	str	x0, [x14, #0x178]
   1e4f4:      	ldr	x0, [x19, #0x50e0]
   1e4f8:      	str	x0, [x14, #0x180]
   1e4fc:      	ldr	x0, [x19, #0x50e8]
   1e500:      	str	x0, [x14, #0x188]
   1e504:      	ldr	x0, [x19, #0x50f0]
   1e508:      	str	x0, [x14, #0x190]
   1e50c:      	ldr	x0, [x19, #0x50f8]
   1e510:      	str	x0, [x14, #0x198]
   1e514:      	ldr	x0, [x19, #0x5100]
   1e518:      	str	x0, [x14, #0x1a0]
   1e51c:      	ldr	x0, [x19, #0x52a8]
   1e520:      	str	x0, [x14, #0x348]
   1e524:      	ldr	x0, [x19, #0x52b0]
   1e528:      	str	x0, [x14, #0x350]
   1e52c:      	ldr	x0, [x19, #0x52b8]
   1e530:      	str	x0, [x14, #0x358]
   1e534:      	ldr	x0, [x19, #0x52c0]
   1e538:      	str	x0, [x14, #0x360]
   1e53c:      	ldr	x0, [x19, #0x52c8]
   1e540:      	str	x0, [x14, #0x368]
   1e544:      	ldr	x0, [x19, #0x52d0]
   1e548:      	str	x0, [x14, #0x370]
   1e54c:      	ldr	x0, [x19, #0x52d8]
   1e550:      	str	x0, [x14, #0x378]
   1e554:      	ldr	x0, [x19, #0x52e0]
   1e558:      	str	x0, [x14, #0x380]
   1e55c:      	ldr	x0, [x19, #0x52e8]
   1e560:      	str	x0, [x14, #0x388]
   1e564:      	ldr	x0, [x19, #0x55d8]
   1e568:      	str	x0, [x14, #0x678]
   1e56c:      	ldr	x0, [x19, #0x55e0]
   1e570:      	str	x0, [x14, #0x680]
   1e574:      	ldr	x0, [x19, #0x55e8]
   1e578:      	str	x0, [x14, #0x688]
   1e57c:      	ldr	x0, [x19, #0x55f0]
   1e580:      	str	x0, [x14, #0x690]
   1e584:      	ldr	x0, [x19, #0x55f8]
   1e588:      	str	x0, [x14, #0x698]
   1e58c:      	ldr	x0, [x19, #0x5600]
   1e590:      	str	x0, [x14, #0x6a0]
   1e594:      	ldr	x0, [x19, #0x5608]
   1e598:      	str	x0, [x14, #0x6a8]
   1e59c:      	ldr	x0, [x19, #0x5610]
   1e5a0:      	str	x0, [x14, #0x6b0]
   1e5a4:      	ldr	x0, [x19, #0x57a0]
   1e5a8:      	str	x0, [x14, #0x840]
   1e5ac:      	ldr	x0, [x19, #0x57a8]
   1e5b0:      	str	x0, [x14, #0x848]
   1e5b4:      	ldr	x0, [x19, #0x57b0]
   1e5b8:      	str	x0, [x14, #0x850]
   1e5bc:      	ldr	x1, [x19, #0x57b8]
   1e5c0:      	str	x1, [x14, #0x858]
   1e5c4:      	ldr	x2, [x19, #0x57c0]
   1e5c8:      	str	x2, [x14, #0x860]
   1e5cc:      	ldr	x5, [x19, #0x57c8]
   1e5d0:      	str	x5, [x14, #0x868]
   1e5d4:      	ldr	x5, [x19, #0x57d0]
   1e5d8:      	str	x5, [x14, #0x870]
   1e5dc:      	ldr	x5, [x19, #0x57d8]
   1e5e0:      	str	x5, [x14, #0x878]
   1e5e4:      	ldr	x6, [x19, #0x5bb0]
   1e5e8:      	str	x6, [x14, #0xc50]
   1e5ec:      	ldr	x7, [x19, #0x5bb8]
   1e5f0:      	str	x7, [x14, #0xc58]
   1e5f4:      	ldr	x8, [x19, #0x5bc0]
   1e5f8:      	str	x8, [x14, #0xc60]
   1e5fc:      	ldr	x9, [x19, #0x5bc8]
   1e600:      	str	x9, [x14, #0xc68]
   1e604:      	ldr	x10, [x19, #0x5bd0]
   1e608:      	str	x10, [x14, #0xc70]
   1e60c:      	ldr	x11, [x19, #0x5bd8]
   1e610:      	str	x11, [x14, #0xc78]
   1e614:      	mov	x12, #0x0               ; =0
   1e618:      	str	x12, [x14, #0xc80]
   1e61c:      	ldr	x13, [x19, #0x5be8]
   1e620:      	str	x13, [x14, #0xc88]
   1e624:      	ldr	x15, [x19, #0x5bf0]
   1e628:      	str	x15, [x14, #0xc90]
   1e62c:      	str	x12, [x14, #0xc98]
   1e630:      	ldr	x0, [x19, #0x5c00]
   1e634:      	str	x0, [x14, #0xca0]
   1e638:      	ldr	x0, [x19, #0x5c08]
   1e63c:      	str	x0, [x14, #0xca8]
   1e640:      	str	x12, [x14, #0xcb0]
   1e644:      	ldr	x0, [x19, #0x5c18]
   1e648:      	str	x0, [x14, #0xcb8]
   1e64c:      	ldr	x0, [x19, #0x5c20]
   1e650:      	str	x0, [x14, #0xcc0]
   1e654:      	mov	x1, #0x502              ; =1282
   1e658:      	mov	x2, #-0x9               ; =-9
   1e65c:      	mov	x5, #0x1                ; =1
   1e660:      	ldur	x0, [sp, #0x8]
   1e664:      	ldr	x6, [sp, #0x198]
   1e668:      	ldr	x21, [sp, #0x1a0]
   1e66c:      	blr	x21
   1e670:      	mov	x2, x0
   1e674:      	mov	x0, #0x2                ; =2
   1e678:      	cmp	x2, #0x0
   1e67c:      	b.ne	0x22cbc <_mech_canonical_program_entry_v1_numeric_1282+0x4b3c>
   1e680:      	mov	x1, #0x0                ; =0
   1e684:      	mov	x0, x1
   1e688:      	add	sp, sp, #0x1b0
   1e68c:      	ldp	x19, x20, [sp], #0x10
   1e690:      	ldp	x21, x22, [sp], #0x10
   1e694:      	ldp	x23, x24, [sp], #0x10
   1e698:      	ldp	x25, x26, [sp], #0x10
   1e69c:      	ldp	x27, x28, [sp], #0x10
   1e6a0:      	ldp	x29, x30, [sp], #0x10
   1e6a4:      	retab
   1e6a8:      	ldur	x7, [sp, #0x80]
   1e6ac:      	ldr	x14, [sp, #0x190]
   1e6b0:      	mov	x19, x8
   1e6b4:      	ldr	x1, [sp, #0x180]
   1e6b8:      	cmp	x22, x1
   1e6bc:      	cset	x1, lo
   1e6c0:      	ldr	x4, [sp, #0x180]
   1e6c4:      	cmp	x22, x4
   1e6c8:      	b.lo	0x1e714 <_mech_canonical_program_entry_v1_numeric_1282+0x594>
   1e6cc:      	mov	x1, #0x0                ; =0
   1e6d0:      	stur	x1, [sp, #0x10]
   1e6d4:      	mov	w1, #0xc87e             ; =51326
   1e6d8:      	movk	w1, #0x1, lsl #16
   1e6dc:      	sub	x3, x3, x1
   1e6e0:      	mov	x26, x22
   1e6e4:      	mov	x28, x22
   1e6e8:      	ldur	x1, [sp, #0x10]
   1e6ec:      	stur	x1, [sp, #0x50]
   1e6f0:      	stur	x1, [sp, #0x58]
   1e6f4:      	stur	x1, [sp, #0x60]
   1e6f8:      	stur	x1, [sp, #0x68]
   1e6fc:      	stur	x7, [sp, #0x80]
   1e700:      	stur	x0, [sp, #0x90]
   1e704:      	stur	x6, [sp, #0x98]
   1e708:      	stur	x13, [sp, #0xa0]
   1e70c:      	str	x14, [sp, #0x190]
   1e710:      	b	0x2223c <_mech_canonical_program_entry_v1_numeric_1282+0x40bc>
   1e714:      	ldr	x4, [sp, #0x170]
   1e718:      	cmp	x22, x4
   1e71c:      	b.lo	0x1e968 <_mech_canonical_program_entry_v1_numeric_1282+0x7e8>
   1e720:      	b	0x22cc4 <_mech_canonical_program_entry_v1_numeric_1282+0x4b44>
   1e724:      	str	x14, [sp, #0x190]
   1e728:      	b	0x1e914 <_mech_canonical_program_entry_v1_numeric_1282+0x794>
   1e72c:      	ldr	x3, [x19, #0x4c68]
   1e730:      	ldr	x4, [x19, #0x4c70]
   1e734:      	mov	x0, #0x0                ; =0
   1e738:      	str	x0, [x19, #0x4c60]
   1e73c:      	mov	x0, #0x3                ; =3
   1e740:      	ldr	x7, [sp, #0x188]
   1e744:      	cmp	x7, #0x19a
   1e748:      	b.lo	0x22de0 <_mech_canonical_program_entry_v1_numeric_1282+0x4c60>
   1e74c:      	ldr	x0, [x19, #0x4f70]
   1e750:      	str	x0, [x14, #0x10]
   1e754:      	ldr	x1, [x19, #0x4f78]
   1e758:      	str	x1, [x14, #0x18]
   1e75c:      	ldr	x2, [x19, #0x5a20]
   1e760:      	str	x2, [x14, #0xac0]
   1e764:      	str	x0, [x14, #0x10]
   1e768:      	str	x1, [x14, #0x18]
   1e76c:      	ldr	x0, [x19, #0x50c0]
   1e770:      	str	x0, [x14, #0x160]
   1e774:      	ldr	x0, [x19, #0x50c8]
   1e778:      	str	x0, [x14, #0x168]
   1e77c:      	ldr	x0, [x19, #0x50d0]
   1e780:      	str	x0, [x14, #0x170]
   1e784:      	ldr	x0, [x19, #0x50d8]
   1e788:      	str	x0, [x14, #0x178]
   1e78c:      	ldr	x0, [x19, #0x50e0]
   1e790:      	str	x0, [x14, #0x180]
   1e794:      	ldr	x0, [x19, #0x50e8]
   1e798:      	str	x0, [x14, #0x188]
   1e79c:      	ldr	x0, [x19, #0x50f0]
   1e7a0:      	str	x0, [x14, #0x190]
   1e7a4:      	ldr	x0, [x19, #0x50f8]
   1e7a8:      	str	x0, [x14, #0x198]
   1e7ac:      	ldr	x0, [x19, #0x5100]
   1e7b0:      	str	x0, [x14, #0x1a0]
   1e7b4:      	ldr	x0, [x19, #0x52a8]
   1e7b8:      	str	x0, [x14, #0x348]
   1e7bc:      	ldr	x0, [x19, #0x52b0]
   1e7c0:      	str	x0, [x14, #0x350]
   1e7c4:      	ldr	x0, [x19, #0x52b8]
   1e7c8:      	str	x0, [x14, #0x358]
   1e7cc:      	ldr	x0, [x19, #0x52c0]
   1e7d0:      	str	x0, [x14, #0x360]
   1e7d4:      	ldr	x0, [x19, #0x52c8]
   1e7d8:      	str	x0, [x14, #0x368]
   1e7dc:      	ldr	x0, [x19, #0x52d0]
   1e7e0:      	str	x0, [x14, #0x370]
   1e7e4:      	ldr	x0, [x19, #0x52d8]
   1e7e8:      	str	x0, [x14, #0x378]
   1e7ec:      	ldr	x0, [x19, #0x52e0]
   1e7f0:      	str	x0, [x14, #0x380]
   1e7f4:      	ldr	x0, [x19, #0x52e8]
   1e7f8:      	str	x0, [x14, #0x388]
   1e7fc:      	ldr	x0, [x19, #0x55d8]
   1e800:      	str	x0, [x14, #0x678]
   1e804:      	ldr	x0, [x19, #0x55e0]
   1e808:      	str	x0, [x14, #0x680]
   1e80c:      	ldr	x0, [x19, #0x55e8]
   1e810:      	str	x0, [x14, #0x688]
   1e814:      	ldr	x0, [x19, #0x55f0]
   1e818:      	str	x0, [x14, #0x690]
   1e81c:      	ldr	x0, [x19, #0x55f8]
   1e820:      	str	x0, [x14, #0x698]
   1e824:      	ldr	x0, [x19, #0x5600]
   1e828:      	str	x0, [x14, #0x6a0]
   1e82c:      	ldr	x0, [x19, #0x5608]
   1e830:      	str	x0, [x14, #0x6a8]
   1e834:      	ldr	x0, [x19, #0x5610]
   1e838:      	str	x0, [x14, #0x6b0]
   1e83c:      	ldr	x0, [x19, #0x57a0]
   1e840:      	str	x0, [x14, #0x840]
   1e844:      	ldr	x0, [x19, #0x57a8]
   1e848:      	str	x0, [x14, #0x848]
   1e84c:      	ldr	x0, [x19, #0x57b0]
   1e850:      	str	x0, [x14, #0x850]
   1e854:      	ldr	x0, [x19, #0x57b8]
   1e858:      	str	x0, [x14, #0x858]
   1e85c:      	ldr	x1, [x19, #0x57c0]
   1e860:      	str	x1, [x14, #0x860]
   1e864:      	ldr	x2, [x19, #0x57c8]
   1e868:      	str	x2, [x14, #0x868]
   1e86c:      	ldr	x5, [x19, #0x57d0]
   1e870:      	str	x5, [x14, #0x870]
   1e874:      	ldr	x5, [x19, #0x57d8]
   1e878:      	str	x5, [x14, #0x878]
   1e87c:      	ldr	x5, [x19, #0x5bb0]
   1e880:      	str	x5, [x14, #0xc50]
   1e884:      	ldr	x6, [x19, #0x5bb8]
   1e888:      	str	x6, [x14, #0xc58]
   1e88c:      	ldr	x7, [x19, #0x5bc0]
   1e890:      	str	x7, [x14, #0xc60]
   1e894:      	ldr	x8, [x19, #0x5bc8]
   1e898:      	str	x8, [x14, #0xc68]
   1e89c:      	ldr	x9, [x19, #0x5bd0]
   1e8a0:      	str	x9, [x14, #0xc70]
   1e8a4:      	ldr	x10, [x19, #0x5bd8]
   1e8a8:      	str	x10, [x14, #0xc78]
   1e8ac:      	mov	x11, #0x0               ; =0
   1e8b0:      	str	x11, [x14, #0xc80]
   1e8b4:      	ldr	x12, [x19, #0x5be8]
   1e8b8:      	str	x12, [x14, #0xc88]
   1e8bc:      	ldr	x13, [x19, #0x5bf0]
   1e8c0:      	str	x13, [x14, #0xc90]
   1e8c4:      	str	x11, [x14, #0xc98]
   1e8c8:      	ldr	x15, [x19, #0x5c00]
   1e8cc:      	str	x15, [x14, #0xca0]
   1e8d0:      	ldr	x0, [x19, #0x5c08]
   1e8d4:      	str	x0, [x14, #0xca8]
   1e8d8:      	str	x11, [x14, #0xcb0]
   1e8dc:      	ldr	x0, [x19, #0x5c18]
   1e8e0:      	str	x0, [x14, #0xcb8]
   1e8e4:      	ldr	x0, [x19, #0x5c20]
   1e8e8:      	str	x0, [x14, #0xcc0]
   1e8ec:      	str	x14, [sp, #0x190]
   1e8f0:      	mov	x1, #0x512              ; =1298
   1e8f4:      	mov	x2, #-0x9               ; =-9
   1e8f8:      	ldr	x21, [sp, #0x1a0]
   1e8fc:      	ldur	x0, [sp, #0x8]
   1e900:      	mov	x5, x20
   1e904:      	ldr	x6, [sp, #0x198]
   1e908:      	blr	x21
   1e90c:      	cmp	x0, #0x0
   1e910:      	b.ne	0x22de8 <_mech_canonical_program_entry_v1_numeric_1282+0x4c68>
   1e914:      	mov	x0, #0x3                ; =3
   1e918:      	ldr	x7, [sp, #0x188]
   1e91c:      	cmp	x7, #0x2
   1e920:      	b.lo	0x22df0 <_mech_canonical_program_entry_v1_numeric_1282+0x4c70>
   1e924:      	mov	x5, #0x0                ; =0
   1e928:      	ldr	x3, [sp, #0x190]
   1e92c:      	str	x5, [x3]
   1e930:      	ldr	x0, [x19, #0x17d0]
   1e934:      	str	x0, [x3, #0x8]
   1e938:      	mov	x1, #0x512              ; =1298
   1e93c:      	ldur	x0, [sp, #0x8]
   1e940:      	ldr	x6, [sp, #0x198]
   1e944:      	ldr	x21, [sp, #0x1a0]
   1e948:      	mov	x4, x20
   1e94c:      	mov	x2, x5
   1e950:      	blr	x21
   1e954:      	cmp	x0, #0x0
   1e958:      	b.ne	0x22df8 <_mech_canonical_program_entry_v1_numeric_1282+0x4c78>
   1e95c:      	mov	x0, #0x3                ; =3
   1e960:      	mov	x21, x0
   1e964:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   1e968:      	stur	x0, [sp, #0x90]
   1e96c:      	stur	x13, [sp, #0xa0]
   1e970:      	str	x14, [sp, #0x190]
   1e974:      	add	x0, x22, #0x1
   1e978:      	ldr	x4, [sp, #0x170]
   1e97c:      	cmp	x0, x4
   1e980:      	b.lo	0x1ebec <_mech_canonical_program_entry_v1_numeric_1282+0xa6c>
   1e984:      	b	0x22e00 <_mech_canonical_program_entry_v1_numeric_1282+0x4c80>
   1e988:      	ldr	x3, [x19, #0x4c68]
   1e98c:      	ldr	x4, [x19, #0x4c70]
   1e990:      	mov	x0, #0x0                ; =0
   1e994:      	str	x0, [x19, #0x4c60]
   1e998:      	mov	x0, #0x3                ; =3
   1e99c:      	ldr	x7, [sp, #0x188]
   1e9a0:      	cmp	x7, #0x19a
   1e9a4:      	b.lo	0x22f48 <_mech_canonical_program_entry_v1_numeric_1282+0x4dc8>
   1e9a8:      	ldr	x0, [x19, #0x4f70]
   1e9ac:      	ldr	x1, [sp, #0x190]
   1e9b0:      	str	x0, [x1, #0x10]
   1e9b4:      	ldr	x1, [x19, #0x4f78]
   1e9b8:      	ldr	x2, [sp, #0x190]
   1e9bc:      	str	x1, [x2, #0x18]
   1e9c0:      	ldr	x2, [x19, #0x5a20]
   1e9c4:      	ldr	x5, [sp, #0x190]
   1e9c8:      	str	x2, [x5, #0xac0]
   1e9cc:      	ldr	x2, [sp, #0x190]
   1e9d0:      	str	x0, [x2, #0x10]
   1e9d4:      	ldr	x0, [sp, #0x190]
   1e9d8:      	str	x1, [x0, #0x18]
   1e9dc:      	ldr	x0, [x19, #0x50c0]
   1e9e0:      	ldr	x1, [sp, #0x190]
   1e9e4:      	str	x0, [x1, #0x160]
   1e9e8:      	ldr	x0, [x19, #0x50c8]
   1e9ec:      	str	x0, [x1, #0x168]
   1e9f0:      	ldr	x0, [x19, #0x50d0]
   1e9f4:      	str	x0, [x1, #0x170]
   1e9f8:      	ldr	x0, [x19, #0x50d8]
   1e9fc:      	str	x0, [x1, #0x178]
   1ea00:      	ldr	x0, [x19, #0x50e0]
   1ea04:      	str	x0, [x1, #0x180]
   1ea08:      	ldr	x0, [x19, #0x50e8]
   1ea0c:      	str	x0, [x1, #0x188]
   1ea10:      	ldr	x0, [x19, #0x50f0]
   1ea14:      	str	x0, [x1, #0x190]
   1ea18:      	ldr	x0, [x19, #0x50f8]
   1ea1c:      	str	x0, [x1, #0x198]
   1ea20:      	ldr	x0, [x19, #0x5100]
   1ea24:      	str	x0, [x1, #0x1a0]
   1ea28:      	ldr	x0, [x19, #0x52a8]
   1ea2c:      	str	x0, [x5, #0x348]
   1ea30:      	ldr	x0, [x19, #0x52b0]
   1ea34:      	ldr	x6, [sp, #0x190]
   1ea38:      	str	x0, [x6, #0x350]
   1ea3c:      	ldr	x0, [x19, #0x52b8]
   1ea40:      	ldr	x9, [sp, #0x190]
   1ea44:      	str	x0, [x9, #0x358]
   1ea48:      	ldr	x0, [x19, #0x52c0]
   1ea4c:      	ldr	x12, [sp, #0x190]
   1ea50:      	str	x0, [x12, #0x360]
   1ea54:      	ldr	x0, [x19, #0x52c8]
   1ea58:      	ldr	x15, [sp, #0x190]
   1ea5c:      	str	x0, [x15, #0x368]
   1ea60:      	ldr	x0, [x19, #0x52d0]
   1ea64:      	str	x0, [x1, #0x370]
   1ea68:      	ldr	x0, [x19, #0x52d8]
   1ea6c:      	str	x0, [x1, #0x378]
   1ea70:      	ldr	x0, [x19, #0x52e0]
   1ea74:      	str	x0, [x1, #0x380]
   1ea78:      	ldr	x0, [x19, #0x52e8]
   1ea7c:      	str	x0, [x1, #0x388]
   1ea80:      	ldr	x0, [x19, #0x55d8]
   1ea84:      	str	x0, [x1, #0x678]
   1ea88:      	ldr	x0, [x19, #0x55e0]
   1ea8c:      	str	x0, [x1, #0x680]
   1ea90:      	ldr	x0, [x19, #0x55e8]
   1ea94:      	str	x0, [x1, #0x688]
   1ea98:      	ldr	x0, [x19, #0x55f0]
   1ea9c:      	str	x0, [x1, #0x690]
   1eaa0:      	ldr	x0, [x19, #0x55f8]
   1eaa4:      	str	x0, [x1, #0x698]
   1eaa8:      	ldr	x0, [x19, #0x5600]
   1eaac:      	str	x0, [x1, #0x6a0]
   1eab0:      	ldr	x0, [x19, #0x5608]
   1eab4:      	str	x0, [x1, #0x6a8]
   1eab8:      	ldr	x0, [x19, #0x5610]
   1eabc:      	str	x0, [x1, #0x6b0]
   1eac0:      	ldr	x0, [x19, #0x57a0]
   1eac4:      	str	x0, [x1, #0x840]
   1eac8:      	ldr	x0, [x19, #0x57a8]
   1eacc:      	str	x0, [x1, #0x848]
   1ead0:      	ldr	x0, [x19, #0x57b0]
   1ead4:      	str	x0, [x1, #0x850]
   1ead8:      	ldr	x0, [x19, #0x57b8]
   1eadc:      	str	x0, [x1, #0x858]
   1eae0:      	ldr	x0, [x19, #0x57c0]
   1eae4:      	str	x0, [x5, #0x860]
   1eae8:      	ldr	x0, [x19, #0x57c8]
   1eaec:      	str	x0, [x6, #0x868]
   1eaf0:      	ldr	x0, [x19, #0x57d0]
   1eaf4:      	str	x0, [x9, #0x870]
   1eaf8:      	ldr	x0, [x19, #0x57d8]
   1eafc:      	str	x0, [x12, #0x878]
   1eb00:      	ldr	x0, [x19, #0x5bb0]
   1eb04:      	str	x0, [x15, #0xc50]
   1eb08:      	ldr	x0, [x19, #0x5bb8]
   1eb0c:      	str	x0, [x1, #0xc58]
   1eb10:      	ldr	x1, [x19, #0x5bc0]
   1eb14:      	ldr	x0, [sp, #0x190]
   1eb18:      	str	x1, [x0, #0xc60]
   1eb1c:      	ldr	x2, [x19, #0x5bc8]
   1eb20:      	str	x2, [x0, #0xc68]
   1eb24:      	ldr	x5, [x19, #0x5bd0]
   1eb28:      	str	x5, [x0, #0xc70]
   1eb2c:      	ldr	x5, [x19, #0x5bd8]
   1eb30:      	str	x5, [x0, #0xc78]
   1eb34:      	mov	x5, #0x0                ; =0
   1eb38:      	str	x5, [x0, #0xc80]
   1eb3c:      	ldr	x6, [x19, #0x5be8]
   1eb40:      	str	x6, [x0, #0xc88]
   1eb44:      	ldr	x7, [x19, #0x5bf0]
   1eb48:      	str	x7, [x0, #0xc90]
   1eb4c:      	str	x5, [x0, #0xc98]
   1eb50:      	ldr	x9, [x19, #0x5c00]
   1eb54:      	str	x9, [x0, #0xca0]
   1eb58:      	ldr	x10, [x19, #0x5c08]
   1eb5c:      	str	x10, [x0, #0xca8]
   1eb60:      	str	x5, [x0, #0xcb0]
   1eb64:      	ldr	x12, [x19, #0x5c18]
   1eb68:      	str	x12, [x0, #0xcb8]
   1eb6c:      	ldr	x13, [x19, #0x5c20]
   1eb70:      	str	x13, [x0, #0xcc0]
   1eb74:      	mov	x1, #0x514              ; =1300
   1eb78:      	mov	x2, #-0x9               ; =-9
   1eb7c:      	ldr	x21, [sp, #0x1a0]
   1eb80:      	ldur	x0, [sp, #0x8]
   1eb84:      	mov	x5, x20
   1eb88:      	ldr	x6, [sp, #0x198]
   1eb8c:      	blr	x21
   1eb90:      	cmp	x0, #0x0
   1eb94:      	b.ne	0x22f50 <_mech_canonical_program_entry_v1_numeric_1282+0x4dd0>
   1eb98:      	mov	x0, #0x3                ; =3
   1eb9c:      	ldr	x7, [sp, #0x188]
   1eba0:      	cmp	x7, #0x2
   1eba4:      	b.lo	0x22f58 <_mech_canonical_program_entry_v1_numeric_1282+0x4dd8>
   1eba8:      	mov	x5, #0x0                ; =0
   1ebac:      	ldr	x3, [sp, #0x190]
   1ebb0:      	str	x5, [x3]
   1ebb4:      	ldr	x0, [x19, #0x17e0]
   1ebb8:      	str	x0, [x3, #0x8]
   1ebbc:      	mov	x1, #0x514              ; =1300
   1ebc0:      	ldur	x0, [sp, #0x8]
   1ebc4:      	ldr	x6, [sp, #0x198]
   1ebc8:      	ldr	x21, [sp, #0x1a0]
   1ebcc:      	mov	x4, x20
   1ebd0:      	mov	x2, x5
   1ebd4:      	blr	x21
   1ebd8:      	cmp	x0, #0x0
   1ebdc:      	b.ne	0x22f60 <_mech_canonical_program_entry_v1_numeric_1282+0x4de0>
   1ebe0:      	mov	x0, #0x3                ; =3
   1ebe4:      	mov	x21, x0
   1ebe8:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   1ebec:      	stur	x6, [sp, #0x98]
   1ebf0:      	ldr	x4, [sp, #0x160]
   1ebf4:      	cmp	x22, x4
   1ebf8:      	b.lo	0x1ee74 <_mech_canonical_program_entry_v1_numeric_1282+0xcf4>
   1ebfc:      	b	0x22f68 <_mech_canonical_program_entry_v1_numeric_1282+0x4de8>
   1ec00:      	ldr	x3, [x19, #0x4c68]
   1ec04:      	ldr	x4, [x19, #0x4c70]
   1ec08:      	mov	x15, #0x0               ; =0
   1ec0c:      	str	x15, [x19, #0x4c60]
   1ec10:      	mov	x0, #0x3                ; =3
   1ec14:      	ldr	x7, [sp, #0x188]
   1ec18:      	cmp	x7, #0x19a
   1ec1c:      	b.lo	0x230c4 <_mech_canonical_program_entry_v1_numeric_1282+0x4f44>
   1ec20:      	ldr	x0, [x19, #0x4f70]
   1ec24:      	ldr	x1, [sp, #0x190]
   1ec28:      	str	x0, [x1, #0x10]
   1ec2c:      	ldr	x1, [x19, #0x4f78]
   1ec30:      	ldr	x2, [sp, #0x190]
   1ec34:      	str	x1, [x2, #0x18]
   1ec38:      	ldr	x2, [x19, #0x5a20]
   1ec3c:      	ldr	x5, [sp, #0x190]
   1ec40:      	str	x2, [x5, #0xac0]
   1ec44:      	ldr	x2, [sp, #0x190]
   1ec48:      	str	x0, [x2, #0x10]
   1ec4c:      	ldr	x0, [sp, #0x190]
   1ec50:      	str	x1, [x0, #0x18]
   1ec54:      	ldr	x0, [x19, #0x50c0]
   1ec58:      	ldr	x1, [sp, #0x190]
   1ec5c:      	str	x0, [x1, #0x160]
   1ec60:      	ldr	x0, [x19, #0x50c8]
   1ec64:      	str	x0, [x1, #0x168]
   1ec68:      	ldr	x0, [x19, #0x50d0]
   1ec6c:      	str	x0, [x1, #0x170]
   1ec70:      	ldr	x0, [x19, #0x50d8]
   1ec74:      	str	x0, [x5, #0x178]
   1ec78:      	ldr	x0, [x19, #0x50e0]
   1ec7c:      	ldr	x6, [sp, #0x190]
   1ec80:      	str	x0, [x6, #0x180]
   1ec84:      	ldr	x0, [x19, #0x50e8]
   1ec88:      	ldr	x9, [sp, #0x190]
   1ec8c:      	str	x0, [x9, #0x188]
   1ec90:      	ldr	x0, [x19, #0x50f0]
   1ec94:      	ldr	x12, [sp, #0x190]
   1ec98:      	str	x0, [x12, #0x190]
   1ec9c:      	ldr	x0, [x19, #0x50f8]
   1eca0:      	ldr	x15, [sp, #0x190]
   1eca4:      	str	x0, [x15, #0x198]
   1eca8:      	ldr	x0, [x19, #0x5100]
   1ecac:      	str	x0, [x1, #0x1a0]
   1ecb0:      	ldr	x0, [x19, #0x52a8]
   1ecb4:      	str	x0, [x1, #0x348]
   1ecb8:      	ldr	x0, [x19, #0x52b0]
   1ecbc:      	str	x0, [x1, #0x350]
   1ecc0:      	ldr	x0, [x19, #0x52b8]
   1ecc4:      	str	x0, [x1, #0x358]
   1ecc8:      	ldr	x0, [x19, #0x52c0]
   1eccc:      	str	x0, [x1, #0x360]
   1ecd0:      	ldr	x0, [x19, #0x52c8]
   1ecd4:      	str	x0, [x1, #0x368]
   1ecd8:      	ldr	x0, [x19, #0x52d0]
   1ecdc:      	str	x0, [x1, #0x370]
   1ece0:      	ldr	x0, [x19, #0x52d8]
   1ece4:      	str	x0, [x1, #0x378]
   1ece8:      	ldr	x0, [x19, #0x52e0]
   1ecec:      	str	x0, [x1, #0x380]
   1ecf0:      	ldr	x0, [x19, #0x52e8]
   1ecf4:      	str	x0, [x1, #0x388]
   1ecf8:      	ldr	x0, [x19, #0x55d8]
   1ecfc:      	str	x0, [x1, #0x678]
   1ed00:      	ldr	x0, [x19, #0x55e0]
   1ed04:      	str	x0, [x1, #0x680]
   1ed08:      	ldr	x0, [x19, #0x55e8]
   1ed0c:      	str	x0, [x1, #0x688]
   1ed10:      	ldr	x0, [x19, #0x55f0]
   1ed14:      	str	x0, [x1, #0x690]
   1ed18:      	ldr	x0, [x19, #0x55f8]
   1ed1c:      	str	x0, [x1, #0x698]
   1ed20:      	ldr	x0, [x19, #0x5600]
   1ed24:      	str	x0, [x1, #0x6a0]
   1ed28:      	ldr	x0, [x19, #0x5608]
   1ed2c:      	str	x0, [x5, #0x6a8]
   1ed30:      	ldr	x0, [x19, #0x5610]
   1ed34:      	str	x0, [x6, #0x6b0]
   1ed38:      	ldr	x0, [x19, #0x57a0]
   1ed3c:      	str	x0, [x9, #0x840]
   1ed40:      	ldr	x0, [x19, #0x57a8]
   1ed44:      	str	x0, [x12, #0x848]
   1ed48:      	ldr	x0, [x19, #0x57b0]
   1ed4c:      	str	x0, [x15, #0x850]
   1ed50:      	ldr	x0, [x19, #0x57b8]
   1ed54:      	str	x0, [x1, #0x858]
   1ed58:      	ldr	x0, [x19, #0x57c0]
   1ed5c:      	str	x0, [x1, #0x860]
   1ed60:      	ldr	x0, [x19, #0x57c8]
   1ed64:      	str	x0, [x1, #0x868]
   1ed68:      	ldr	x0, [x19, #0x57d0]
   1ed6c:      	str	x0, [x1, #0x870]
   1ed70:      	ldr	x0, [x19, #0x57d8]
   1ed74:      	str	x0, [x1, #0x878]
   1ed78:      	ldr	x0, [x19, #0x5bb0]
   1ed7c:      	str	x0, [x1, #0xc50]
   1ed80:      	ldr	x0, [x19, #0x5bb8]
   1ed84:      	str	x0, [x1, #0xc58]
   1ed88:      	ldr	x0, [x19, #0x5bc0]
   1ed8c:      	str	x0, [x1, #0xc60]
   1ed90:      	ldr	x0, [x19, #0x5bc8]
   1ed94:      	str	x0, [x1, #0xc68]
   1ed98:      	ldr	x0, [x19, #0x5bd0]
   1ed9c:      	str	x0, [x1, #0xc70]
   1eda0:      	ldr	x0, [x19, #0x5bd8]
   1eda4:      	str	x0, [x1, #0xc78]
   1eda8:      	mov	x1, #0x0                ; =0
   1edac:      	ldr	x0, [sp, #0x190]
   1edb0:      	str	x1, [x0, #0xc80]
   1edb4:      	ldr	x2, [x19, #0x5be8]
   1edb8:      	str	x2, [x0, #0xc88]
   1edbc:      	ldr	x5, [x19, #0x5bf0]
   1edc0:      	str	x5, [x0, #0xc90]
   1edc4:      	str	x1, [x0, #0xc98]
   1edc8:      	ldr	x5, [x19, #0x5c00]
   1edcc:      	str	x5, [x0, #0xca0]
   1edd0:      	ldr	x6, [x19, #0x5c08]
   1edd4:      	ldr	x2, [sp, #0x190]
   1edd8:      	str	x6, [x2, #0xca8]
   1eddc:      	ldr	x5, [sp, #0x190]
   1ede0:      	str	x1, [x5, #0xcb0]
   1ede4:      	ldr	x8, [x19, #0x5c18]
   1ede8:      	ldr	x7, [sp, #0x190]
   1edec:      	str	x8, [x7, #0xcb8]
   1edf0:      	ldr	x9, [x19, #0x5c20]
   1edf4:      	ldr	x10, [sp, #0x190]
   1edf8:      	str	x9, [x10, #0xcc0]
   1edfc:      	mov	x1, #0x516              ; =1302
   1ee00:      	mov	x2, #-0x9               ; =-9
   1ee04:      	ldr	x21, [sp, #0x1a0]
   1ee08:      	ldur	x0, [sp, #0x8]
   1ee0c:      	mov	x5, x20
   1ee10:      	ldr	x6, [sp, #0x198]
   1ee14:      	blr	x21
   1ee18:      	cmp	x0, #0x0
   1ee1c:      	b.ne	0x230cc <_mech_canonical_program_entry_v1_numeric_1282+0x4f4c>
   1ee20:      	mov	x0, #0x3                ; =3
   1ee24:      	ldr	x7, [sp, #0x188]
   1ee28:      	cmp	x7, #0x2
   1ee2c:      	b.lo	0x230d4 <_mech_canonical_program_entry_v1_numeric_1282+0x4f54>
   1ee30:      	mov	x5, #0x0                ; =0
   1ee34:      	ldr	x3, [sp, #0x190]
   1ee38:      	str	x5, [x3]
   1ee3c:      	ldr	x0, [x19, #0x17f0]
   1ee40:      	str	x0, [x3, #0x8]
   1ee44:      	mov	x1, #0x516              ; =1302
   1ee48:      	ldur	x0, [sp, #0x8]
   1ee4c:      	ldr	x6, [sp, #0x198]
   1ee50:      	ldr	x21, [sp, #0x1a0]
   1ee54:      	mov	x4, x20
   1ee58:      	mov	x2, x5
   1ee5c:      	blr	x21
   1ee60:      	cmp	x0, #0x0
   1ee64:      	b.ne	0x230dc <_mech_canonical_program_entry_v1_numeric_1282+0x4f5c>
   1ee68:      	mov	x0, #0x3                ; =3
   1ee6c:      	mov	x21, x0
   1ee70:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   1ee74:      	stur	x7, [sp, #0x80]
   1ee78:      	stur	x0, [sp, #0xd8]
   1ee7c:      	stur	x1, [sp, #0xe0]
   1ee80:      	mov	w0, #0xc87e             ; =51326
   1ee84:      	movk	w0, #0x1, lsl #16
   1ee88:      	sub	x3, x3, x0
   1ee8c:      	ldr	x0, [sp, #0x170]
   1ee90:      	sub	x0, x0, #0x1
   1ee94:      	mov	x10, #0x0               ; =0
   1ee98:      	ldr	x1, [sp, #0x170]
   1ee9c:      	stur	x10, [sp, #0x10]
   1eea0:      	cmp	x1, xzr
   1eea4:      	csel	x0, x0, x10, ne
   1eea8:      	cmp	x22, x0
   1eeac:      	stur	x0, [sp, #0xd0]
   1eeb0:      	csel	x0, x22, x0, lo
   1eeb4:      	ldr	x20, [sp, #0x178]
   1eeb8:      	ldr	x15, [x20, x0, lsl #3]
   1eebc:      	stur	x15, [sp, #0x18]
   1eec0:      	ldur	x25, [sp, #0x10]
   1eec4:      	ldur	x26, [sp, #0x10]
   1eec8:      	ldur	x28, [sp, #0x10]
   1eecc:      	ldur	x0, [sp, #0x10]
   1eed0:      	stur	x0, [sp, #0x20]
   1eed4:      	stur	x0, [sp, #0x68]
   1eed8:      	mov	w0, #0x2166             ; =8550
   1eedc:      	movk	w0, #0x1, lsl #16
   1eee0:      	cmp	x3, x0
   1eee4:      	b.hs	0x1f2ac <_mech_canonical_program_entry_v1_numeric_1282+0x112c>
   1eee8:      	mov	x1, #0x0                ; =0
   1eeec:      	str	x1, [x19, #0x18]
   1eef0:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   1eef4:      	str	x0, [x19, #0x20]
   1eef8:      	mov	x0, #0x1                ; =1
   1eefc:      	str	x0, [x19, #0x30]
   1ef00:      	mov	x4, #0x101010101010101  ; =72340172838076673
   1ef04:      	str	x4, [x19, #0x38]
   1ef08:      	mov	x4, #0x2                ; =2
   1ef0c:      	str	x4, [x19, #0x40]
   1ef10:      	stur	x4, [sp, #0xc8]
   1ef14:      	mov	x4, #0x3                ; =3
   1ef18:      	str	x4, [x19, #0x48]
   1ef1c:      	mov	x4, #0x4                ; =4
   1ef20:      	str	x4, [x19, #0x50]
   1ef24:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   1ef28:      	str	x4, [x19, #0x78]
   1ef2c:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   1ef30:      	str	x4, [x19, #0x88]
   1ef34:      	mov	x4, #0x38               ; =56
   1ef38:      	str	x4, [x19, #0x90]
   1ef3c:      	mov	x4, #0x3a               ; =58
   1ef40:      	str	x4, [x19, #0x98]
   1ef44:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   1ef48:      	str	x4, [x19, #0xb0]
   1ef4c:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   1ef50:      	str	x4, [x19, #0xb8]
   1ef54:      	str	x1, [x19, #0x188]
   1ef58:      	str	x0, [x19, #0x190]
   1ef5c:      	str	x22, [x19, #0x17a0]
   1ef60:      	ldr	x4, [sp, #0x180]
   1ef64:      	str	x4, [x19, #0x17a8]
   1ef68:      	ldur	x24, [sp, #0xe0]
   1ef6c:      	uxtb	w4, w24
   1ef70:      	str	x4, [x19, #0x17b8]
   1ef74:      	ldur	x14, [sp, #0x78]
   1ef78:      	str	x14, [x19, #0x4c60]
   1ef7c:      	str	x3, [x19, #0x4c68]
   1ef80:      	ldur	x4, [sp, #0x80]
   1ef84:      	str	x4, [x19, #0x4c70]
   1ef88:      	str	x22, [x19, #0x4f70]
   1ef8c:      	ldr	x4, [sp, #0x180]
   1ef90:      	str	x4, [x19, #0x4f78]
   1ef94:      	ldur	x15, [sp, #0x18]
   1ef98:      	str	x15, [x19, #0x50c0]
   1ef9c:      	ldur	x4, [sp, #0xd8]
   1efa0:      	ldur	x5, [sp, #0xd0]
   1efa4:      	cmp	x4, x5
   1efa8:      	csel	x4, x4, x5, lo
   1efac:      	ldr	x20, [sp, #0x178]
   1efb0:      	ldr	x4, [x20, x4, lsl #3]
   1efb4:      	str	x4, [x19, #0x50c8]
   1efb8:      	str	x22, [x19, #0x50d0]
   1efbc:      	ldr	x27, [sp, #0x160]
   1efc0:      	sub	x4, x27, #0x1
   1efc4:      	cmp	x27, xzr
   1efc8:      	csel	x1, x4, x1, ne
   1efcc:      	cmp	x22, x1
   1efd0:      	csel	x4, x22, x1, lo
   1efd4:      	ldr	x27, [sp, #0x168]
   1efd8:      	ldr	x4, [x27, x4, lsl #3]
   1efdc:      	str	x4, [x19, #0x50d8]
   1efe0:      	ldur	x10, [sp, #0x10]
   1efe4:      	str	x10, [x19, #0x50e0]
   1efe8:      	str	x26, [x19, #0x50e8]
   1efec:      	str	x28, [x19, #0x50f0]
   1eff0:      	str	x25, [x19, #0x50f8]
   1eff4:      	ldur	x28, [sp, #0x68]
   1eff8:      	str	x28, [x19, #0x5100]
   1effc:      	ldur	x1, [sp, #0x48]
   1f000:      	str	x1, [x19, #0x5a20]
   1f004:      	add	x10, x11, #0x1
   1f008:      	str	x10, [x19, #0x5bb0]
   1f00c:      	ldur	x25, [sp, #0x88]
   1f010:      	str	x25, [x19, #0x5bb8]
   1f014:      	ldur	x13, [sp, #0x90]
   1f018:      	str	x13, [x19, #0x5bc0]
   1f01c:      	ldur	x5, [sp, #0x70]
   1f020:      	sub	x13, x5, x3
   1f024:      	mov	w14, #0xc87e            ; =51326
   1f028:      	movk	w14, #0x1, lsl #16
   1f02c:      	msub	x13, x10, x14, x13
   1f030:      	str	x13, [x19, #0x5bc8]
   1f034:      	str	x0, [x19, #0x5bd0]
   1f038:      	ldur	x21, [sp, #0x20]
   1f03c:      	str	x21, [x19, #0x5bd8]
   1f040:      	ldur	x0, [sp, #0x98]
   1f044:      	str	x0, [x19, #0x5be8]
   1f048:      	ldur	x6, [sp, #0xa0]
   1f04c:      	str	x6, [x19, #0x5bf0]
   1f050:      	str	x12, [x19, #0x5c00]
   1f054:      	str	x9, [x19, #0x5c08]
   1f058:      	str	x23, [x19, #0x5c18]
   1f05c:      	str	x2, [x19, #0x5c20]
   1f060:      	ldr	x0, [x19, #0x4c60]
   1f064:      	cmp	x0, #0x0
   1f068:      	b.eq	0x1f284 <_mech_canonical_program_entry_v1_numeric_1282+0x1104>
   1f06c:      	ldr	x3, [x19, #0x4c68]
   1f070:      	ldr	x4, [x19, #0x4c70]
   1f074:      	mov	x0, #0x0                ; =0
   1f078:      	str	x0, [x19, #0x4c60]
   1f07c:      	mov	x0, #0x3                ; =3
   1f080:      	ldr	x7, [sp, #0x188]
   1f084:      	mov	x21, x0
   1f088:      	cmp	x7, #0x19a
   1f08c:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   1f090:      	ldr	x0, [x19, #0x4f70]
   1f094:      	ldr	x1, [sp, #0x190]
   1f098:      	str	x0, [x1, #0x10]
   1f09c:      	ldr	x1, [x19, #0x4f78]
   1f0a0:      	ldr	x2, [sp, #0x190]
   1f0a4:      	str	x1, [x2, #0x18]
   1f0a8:      	ldr	x2, [x19, #0x5a20]
   1f0ac:      	ldr	x5, [sp, #0x190]
   1f0b0:      	str	x2, [x5, #0xac0]
   1f0b4:      	ldr	x2, [sp, #0x190]
   1f0b8:      	str	x0, [x2, #0x10]
   1f0bc:      	ldr	x0, [sp, #0x190]
   1f0c0:      	str	x1, [x0, #0x18]
   1f0c4:      	ldr	x0, [x19, #0x50c0]
   1f0c8:      	ldr	x1, [sp, #0x190]
   1f0cc:      	str	x0, [x1, #0x160]
   1f0d0:      	ldr	x0, [x19, #0x50c8]
   1f0d4:      	str	x0, [x1, #0x168]
   1f0d8:      	ldr	x0, [x19, #0x50d0]
   1f0dc:      	str	x0, [x1, #0x170]
   1f0e0:      	ldr	x0, [x19, #0x50d8]
   1f0e4:      	str	x0, [x1, #0x178]
   1f0e8:      	ldr	x0, [x19, #0x50e0]
   1f0ec:      	str	x0, [x1, #0x180]
   1f0f0:      	ldr	x0, [x19, #0x50e8]
   1f0f4:      	str	x0, [x1, #0x188]
   1f0f8:      	ldr	x0, [x19, #0x50f0]
   1f0fc:      	str	x0, [x1, #0x190]
   1f100:      	ldr	x0, [x19, #0x50f8]
   1f104:      	str	x0, [x1, #0x198]
   1f108:      	ldr	x0, [x19, #0x5100]
   1f10c:      	str	x0, [x1, #0x1a0]
   1f110:      	ldr	x0, [x19, #0x52a8]
   1f114:      	str	x0, [x1, #0x348]
   1f118:      	ldr	x0, [x19, #0x52b0]
   1f11c:      	str	x0, [x1, #0x350]
   1f120:      	ldr	x0, [x19, #0x52b8]
   1f124:      	str	x0, [x5, #0x358]
   1f128:      	ldr	x0, [x19, #0x52c0]
   1f12c:      	ldr	x6, [sp, #0x190]
   1f130:      	str	x0, [x6, #0x360]
   1f134:      	ldr	x0, [x19, #0x52c8]
   1f138:      	ldr	x9, [sp, #0x190]
   1f13c:      	str	x0, [x9, #0x368]
   1f140:      	ldr	x0, [x19, #0x52d0]
   1f144:      	ldr	x12, [sp, #0x190]
   1f148:      	str	x0, [x12, #0x370]
   1f14c:      	ldr	x0, [x19, #0x52d8]
   1f150:      	ldr	x15, [sp, #0x190]
   1f154:      	str	x0, [x15, #0x378]
   1f158:      	ldr	x0, [x19, #0x52e0]
   1f15c:      	str	x0, [x1, #0x380]
   1f160:      	ldr	x0, [x19, #0x52e8]
   1f164:      	str	x0, [x1, #0x388]
   1f168:      	ldr	x0, [x19, #0x55d8]
   1f16c:      	str	x0, [x1, #0x678]
   1f170:      	ldr	x0, [x19, #0x55e0]
   1f174:      	str	x0, [x1, #0x680]
   1f178:      	ldr	x0, [x19, #0x55e8]
   1f17c:      	str	x0, [x1, #0x688]
   1f180:      	ldr	x0, [x19, #0x55f0]
   1f184:      	str	x0, [x1, #0x690]
   1f188:      	ldr	x0, [x19, #0x55f8]
   1f18c:      	str	x0, [x1, #0x698]
   1f190:      	ldr	x0, [x19, #0x5600]
   1f194:      	str	x0, [x1, #0x6a0]
   1f198:      	ldr	x0, [x19, #0x5608]
   1f19c:      	str	x0, [x1, #0x6a8]
   1f1a0:      	ldr	x0, [x19, #0x5610]
   1f1a4:      	str	x0, [x1, #0x6b0]
   1f1a8:      	ldr	x0, [x19, #0x57a0]
   1f1ac:      	str	x0, [x1, #0x840]
   1f1b0:      	ldr	x0, [x19, #0x57a8]
   1f1b4:      	str	x0, [x1, #0x848]
   1f1b8:      	ldr	x0, [x19, #0x57b0]
   1f1bc:      	str	x0, [x1, #0x850]
   1f1c0:      	ldr	x0, [x19, #0x57b8]
   1f1c4:      	str	x0, [x1, #0x858]
   1f1c8:      	ldr	x0, [x19, #0x57c0]
   1f1cc:      	str	x0, [x1, #0x860]
   1f1d0:      	ldr	x1, [x19, #0x57c8]
   1f1d4:      	ldr	x0, [sp, #0x190]
   1f1d8:      	str	x1, [x0, #0x868]
   1f1dc:      	ldr	x2, [x19, #0x57d0]
   1f1e0:      	str	x2, [x5, #0x870]
   1f1e4:      	ldr	x5, [x19, #0x57d8]
   1f1e8:      	str	x5, [x6, #0x878]
   1f1ec:      	ldr	x5, [x19, #0x5bb0]
   1f1f0:      	str	x5, [x9, #0xc50]
   1f1f4:      	ldr	x5, [x19, #0x5bb8]
   1f1f8:      	str	x5, [x12, #0xc58]
   1f1fc:      	ldr	x6, [x19, #0x5bc0]
   1f200:      	str	x6, [x15, #0xc60]
   1f204:      	ldr	x7, [x19, #0x5bc8]
   1f208:      	str	x7, [x0, #0xc68]
   1f20c:      	ldr	x8, [x19, #0x5bd0]
   1f210:      	str	x8, [x0, #0xc70]
   1f214:      	ldr	x9, [x19, #0x5bd8]
   1f218:      	str	x9, [x0, #0xc78]
   1f21c:      	mov	x10, #0x0               ; =0
   1f220:      	str	x10, [x0, #0xc80]
   1f224:      	ldr	x11, [x19, #0x5be8]
   1f228:      	str	x11, [x0, #0xc88]
   1f22c:      	ldr	x12, [x19, #0x5bf0]
   1f230:      	str	x12, [x0, #0xc90]
   1f234:      	str	x10, [x0, #0xc98]
   1f238:      	ldr	x14, [x19, #0x5c00]
   1f23c:      	str	x14, [x0, #0xca0]
   1f240:      	ldr	x15, [x19, #0x5c08]
   1f244:      	str	x15, [x0, #0xca8]
   1f248:      	str	x10, [x0, #0xcb0]
   1f24c:      	ldr	x0, [x19, #0x5c18]
   1f250:      	ldr	x1, [sp, #0x190]
   1f254:      	str	x0, [x1, #0xcb8]
   1f258:      	ldr	x0, [x19, #0x5c20]
   1f25c:      	str	x0, [x1, #0xcc0]
   1f260:      	mov	x1, #0x51f              ; =1311
   1f264:      	mov	x2, #-0x9               ; =-9
   1f268:      	mov	x5, #0x1                ; =1
   1f26c:      	ldur	x0, [sp, #0x8]
   1f270:      	ldr	x6, [sp, #0x198]
   1f274:      	ldr	x21, [sp, #0x1a0]
   1f278:      	blr	x21
   1f27c:      	cmp	x0, #0x0
   1f280:      	b.ne	0x230e4 <_mech_canonical_program_entry_v1_numeric_1282+0x4f64>
   1f284:      	mov	x0, #0x0                ; =0
   1f288:      	ldur	x1, [sp, #0xc8]
   1f28c:      	add	sp, sp, #0x1b0
   1f290:      	ldp	x19, x20, [sp], #0x10
   1f294:      	ldp	x21, x22, [sp], #0x10
   1f298:      	ldp	x23, x24, [sp], #0x10
   1f29c:      	ldp	x25, x26, [sp], #0x10
   1f2a0:      	ldp	x27, x28, [sp], #0x10
   1f2a4:      	ldp	x29, x30, [sp], #0x10
   1f2a8:      	retab
   1f2ac:      	stur	x25, [sp, #0x60]
   1f2b0:      	ldur	x0, [sp, #0xd0]
   1f2b4:      	ldur	x1, [sp, #0xd8]
   1f2b8:      	cmp	x1, x0
   1f2bc:      	csel	x0, x1, x0, lo
   1f2c0:      	ldr	x20, [sp, #0x178]
   1f2c4:      	ldr	x25, [x20, x0, lsl #3]
   1f2c8:      	ldur	x15, [sp, #0x18]
   1f2cc:      	cmp	x15, x25
   1f2d0:      	cset	x15, lo
   1f2d4:      	ldur	x0, [sp, #0x18]
   1f2d8:      	cmp	x0, x25
   1f2dc:      	b.lo	0x1f314 <_mech_canonical_program_entry_v1_numeric_1282+0x1194>
   1f2e0:      	mov	w0, #0x2166             ; =8550
   1f2e4:      	movk	w0, #0x1, lsl #16
   1f2e8:      	sub	x3, x3, x0
   1f2ec:      	stur	x25, [sp, #0xc8]
   1f2f0:      	stur	x28, [sp, #0x58]
   1f2f4:      	stur	x26, [sp, #0x50]
   1f2f8:      	ldur	x15, [sp, #0x10]
   1f2fc:      	mov	x10, x26
   1f300:      	mov	x26, x28
   1f304:      	ldur	x28, [sp, #0x60]
   1f308:      	ldur	x7, [sp, #0x18]
   1f30c:      	ldur	x1, [sp, #0x68]
   1f310:      	b	0x20750 <_mech_canonical_program_entry_v1_numeric_1282+0x25d0>
   1f314:      	ldr	x0, [sp, #0x150]
   1f318:      	ldur	x10, [sp, #0x18]
   1f31c:      	cmp	x10, x0
   1f320:      	b.lo	0x1f5b0 <_mech_canonical_program_entry_v1_numeric_1282+0x1430>
   1f324:      	b	0x230ec <_mech_canonical_program_entry_v1_numeric_1282+0x4f6c>
   1f328:      	ldr	x3, [x19, #0x4c68]
   1f32c:      	ldr	x4, [x19, #0x4c70]
   1f330:      	mov	x0, #0x0                ; =0
   1f334:      	str	x0, [x19, #0x4c60]
   1f338:      	mov	x0, #0x3                ; =3
   1f33c:      	ldr	x7, [sp, #0x188]
   1f340:      	mov	x21, x0
   1f344:      	cmp	x7, #0x19a
   1f348:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   1f34c:      	ldr	x0, [x19, #0x4f70]
   1f350:      	ldr	x1, [sp, #0x190]
   1f354:      	str	x0, [x1, #0x10]
   1f358:      	ldr	x1, [x19, #0x4f78]
   1f35c:      	ldr	x2, [sp, #0x190]
   1f360:      	str	x1, [x2, #0x18]
   1f364:      	ldr	x2, [x19, #0x5a20]
   1f368:      	ldr	x5, [sp, #0x190]
   1f36c:      	str	x2, [x5, #0xac0]
   1f370:      	str	x0, [x5, #0x10]
   1f374:      	ldr	x6, [sp, #0x190]
   1f378:      	str	x1, [x6, #0x18]
   1f37c:      	ldr	x0, [x19, #0x50c0]
   1f380:      	ldr	x9, [sp, #0x190]
   1f384:      	str	x0, [x9, #0x160]
   1f388:      	ldr	x0, [x19, #0x50c8]
   1f38c:      	ldr	x12, [sp, #0x190]
   1f390:      	str	x0, [x12, #0x168]
   1f394:      	ldr	x0, [x19, #0x50d0]
   1f398:      	ldr	x15, [sp, #0x190]
   1f39c:      	str	x0, [x15, #0x170]
   1f3a0:      	ldr	x0, [x19, #0x50d8]
   1f3a4:      	ldr	x1, [sp, #0x190]
   1f3a8:      	str	x0, [x1, #0x178]
   1f3ac:      	ldr	x0, [x19, #0x50e0]
   1f3b0:      	str	x0, [x1, #0x180]
   1f3b4:      	ldr	x0, [x19, #0x50e8]
   1f3b8:      	str	x0, [x1, #0x188]
   1f3bc:      	ldr	x0, [x19, #0x50f0]
   1f3c0:      	str	x0, [x1, #0x190]
   1f3c4:      	ldr	x0, [x19, #0x50f8]
   1f3c8:      	str	x0, [x1, #0x198]
   1f3cc:      	ldr	x0, [x19, #0x5100]
   1f3d0:      	str	x0, [x1, #0x1a0]
   1f3d4:      	ldr	x0, [x19, #0x52a8]
   1f3d8:      	str	x0, [x1, #0x348]
   1f3dc:      	ldr	x0, [x19, #0x52b0]
   1f3e0:      	str	x0, [x1, #0x350]
   1f3e4:      	ldr	x0, [x19, #0x52b8]
   1f3e8:      	str	x0, [x1, #0x358]
   1f3ec:      	ldr	x0, [x19, #0x52c0]
   1f3f0:      	str	x0, [x1, #0x360]
   1f3f4:      	ldr	x0, [x19, #0x52c8]
   1f3f8:      	str	x0, [x1, #0x368]
   1f3fc:      	ldr	x0, [x19, #0x52d0]
   1f400:      	str	x0, [x1, #0x370]
   1f404:      	ldr	x1, [x19, #0x52d8]
   1f408:      	ldr	x0, [sp, #0x190]
   1f40c:      	str	x1, [x0, #0x378]
   1f410:      	ldr	x2, [x19, #0x52e0]
   1f414:      	str	x2, [x0, #0x380]
   1f418:      	ldr	x5, [x19, #0x52e8]
   1f41c:      	str	x5, [x0, #0x388]
   1f420:      	ldr	x5, [x19, #0x55d8]
   1f424:      	str	x5, [x0, #0x678]
   1f428:      	ldr	x5, [x19, #0x55e0]
   1f42c:      	str	x5, [x6, #0x680]
   1f430:      	ldr	x6, [x19, #0x55e8]
   1f434:      	ldr	x7, [sp, #0x190]
   1f438:      	str	x6, [x7, #0x688]
   1f43c:      	ldr	x7, [x19, #0x55f0]
   1f440:      	str	x7, [x9, #0x690]
   1f444:      	ldr	x8, [x19, #0x55f8]
   1f448:      	str	x8, [x12, #0x698]
   1f44c:      	ldr	x9, [x19, #0x5600]
   1f450:      	str	x9, [x15, #0x6a0]
   1f454:      	ldr	x10, [x19, #0x5608]
   1f458:      	str	x10, [x0, #0x6a8]
   1f45c:      	ldr	x11, [x19, #0x5610]
   1f460:      	str	x11, [x0, #0x6b0]
   1f464:      	ldr	x12, [x19, #0x57a0]
   1f468:      	str	x12, [x0, #0x840]
   1f46c:      	ldr	x13, [x19, #0x57a8]
   1f470:      	str	x13, [x0, #0x848]
   1f474:      	ldr	x14, [x19, #0x57b0]
   1f478:      	str	x14, [x0, #0x850]
   1f47c:      	ldr	x15, [x19, #0x57b8]
   1f480:      	str	x15, [x0, #0x858]
   1f484:      	ldr	x0, [x19, #0x57c0]
   1f488:      	ldr	x1, [sp, #0x190]
   1f48c:      	str	x0, [x1, #0x860]
   1f490:      	ldr	x0, [x19, #0x57c8]
   1f494:      	str	x0, [x1, #0x868]
   1f498:      	ldr	x0, [x19, #0x57d0]
   1f49c:      	str	x0, [x1, #0x870]
   1f4a0:      	ldr	x0, [x19, #0x57d8]
   1f4a4:      	str	x0, [x1, #0x878]
   1f4a8:      	ldr	x0, [x19, #0x5bb0]
   1f4ac:      	str	x0, [x1, #0xc50]
   1f4b0:      	ldr	x0, [x19, #0x5bb8]
   1f4b4:      	str	x0, [x1, #0xc58]
   1f4b8:      	ldr	x0, [x19, #0x5bc0]
   1f4bc:      	str	x0, [x1, #0xc60]
   1f4c0:      	ldr	x0, [x19, #0x5bc8]
   1f4c4:      	str	x0, [x1, #0xc68]
   1f4c8:      	ldr	x0, [x19, #0x5bd0]
   1f4cc:      	str	x0, [x1, #0xc70]
   1f4d0:      	ldr	x0, [x19, #0x5bd8]
   1f4d4:      	str	x0, [x1, #0xc78]
   1f4d8:      	mov	x0, #0x0                ; =0
   1f4dc:      	ldr	x5, [sp, #0x190]
   1f4e0:      	str	x0, [x5, #0xc80]
   1f4e4:      	ldr	x1, [x19, #0x5be8]
   1f4e8:      	ldr	x6, [sp, #0x190]
   1f4ec:      	str	x1, [x6, #0xc88]
   1f4f0:      	ldr	x1, [x19, #0x5bf0]
   1f4f4:      	ldr	x9, [sp, #0x190]
   1f4f8:      	str	x1, [x9, #0xc90]
   1f4fc:      	ldr	x11, [sp, #0x190]
   1f500:      	str	x0, [x11, #0xc98]
   1f504:      	ldr	x1, [x19, #0x5c00]
   1f508:      	ldr	x14, [sp, #0x190]
   1f50c:      	str	x1, [x14, #0xca0]
   1f510:      	ldr	x1, [x19, #0x5c08]
   1f514:      	ldr	x2, [sp, #0x190]
   1f518:      	str	x1, [x2, #0xca8]
   1f51c:      	ldr	x1, [sp, #0x190]
   1f520:      	str	x0, [x1, #0xcb0]
   1f524:      	ldr	x0, [x19, #0x5c18]
   1f528:      	str	x0, [x1, #0xcb8]
   1f52c:      	ldr	x0, [x19, #0x5c20]
   1f530:      	str	x0, [x1, #0xcc0]
   1f534:      	mov	x1, #0x530              ; =1328
   1f538:      	mov	x2, #-0x9               ; =-9
   1f53c:      	ldr	x21, [sp, #0x1a0]
   1f540:      	ldur	x0, [sp, #0x8]
   1f544:      	mov	x5, x20
   1f548:      	ldr	x6, [sp, #0x198]
   1f54c:      	blr	x21
   1f550:      	cmp	x0, #0x0
   1f554:      	b.ne	0x23298 <_mech_canonical_program_entry_v1_numeric_1282+0x5118>
   1f558:      	mov	x0, #0x3                ; =3
   1f55c:      	ldr	x7, [sp, #0x188]
   1f560:      	mov	x21, x0
   1f564:      	cmp	x7, #0x2
   1f568:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   1f56c:      	mov	x5, #0x0                ; =0
   1f570:      	ldr	x3, [sp, #0x190]
   1f574:      	str	x5, [x3]
   1f578:      	ldr	x0, [x19, #0x1890]
   1f57c:      	str	x0, [x3, #0x8]
   1f580:      	mov	x1, #0x530              ; =1328
   1f584:      	ldur	x0, [sp, #0x8]
   1f588:      	ldr	x6, [sp, #0x198]
   1f58c:      	ldr	x21, [sp, #0x1a0]
   1f590:      	mov	x4, x20
   1f594:      	mov	x2, x5
   1f598:      	blr	x21
   1f59c:      	cmp	x0, #0x0
   1f5a0:      	b.ne	0x232a0 <_mech_canonical_program_entry_v1_numeric_1282+0x5120>
   1f5a4:      	mov	x0, #0x3                ; =3
   1f5a8:      	mov	x21, x0
   1f5ac:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   1f5b0:      	stur	x28, [sp, #0x58]
   1f5b4:      	stur	x25, [sp, #0xc8]
   1f5b8:      	ldr	x0, [sp, #0x150]
   1f5bc:      	sub	x0, x0, #0x1
   1f5c0:      	mov	x1, #0x0                ; =0
   1f5c4:      	ldr	x4, [sp, #0x150]
   1f5c8:      	cmp	x4, xzr
   1f5cc:      	csel	x0, x0, x1, ne
   1f5d0:      	ldur	x1, [sp, #0x18]
   1f5d4:      	cmp	x1, x0
   1f5d8:      	csel	x0, x1, x0, lo
   1f5dc:      	ldr	x4, [sp, #0x158]
   1f5e0:      	ldr	x1, [x4, x0, lsl #3]
   1f5e4:      	add	x0, x1, #0x1
   1f5e8:      	cmp	x0, x1
   1f5ec:      	b.lo	0x232a8 <_mech_canonical_program_entry_v1_numeric_1282+0x5128>
   1f5f0:      	stur	x15, [sp, #0xc0]
   1f5f4:      	ldr	x7, [sp, #0x140]
   1f5f8:      	cmp	x1, x7
   1f5fc:      	b.lo	0x1f884 <_mech_canonical_program_entry_v1_numeric_1282+0x1704>
   1f600:      	b	0x23414 <_mech_canonical_program_entry_v1_numeric_1282+0x5294>
   1f604:      	ldr	x3, [x19, #0x4c68]
   1f608:      	ldr	x4, [x19, #0x4c70]
   1f60c:      	mov	x0, #0x0                ; =0
   1f610:      	str	x0, [x19, #0x4c60]
   1f614:      	mov	x0, #0x3                ; =3
   1f618:      	ldr	x7, [sp, #0x188]
   1f61c:      	mov	x21, x0
   1f620:      	cmp	x7, #0x19a
   1f624:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   1f628:      	ldr	x0, [x19, #0x4f70]
   1f62c:      	ldr	x1, [sp, #0x190]
   1f630:      	str	x0, [x1, #0x10]
   1f634:      	ldr	x1, [x19, #0x4f78]
   1f638:      	ldr	x2, [sp, #0x190]
   1f63c:      	str	x1, [x2, #0x18]
   1f640:      	ldr	x2, [x19, #0x5a20]
   1f644:      	ldr	x5, [sp, #0x190]
   1f648:      	str	x2, [x5, #0xac0]
   1f64c:      	ldr	x2, [sp, #0x190]
   1f650:      	str	x0, [x2, #0x10]
   1f654:      	ldr	x0, [sp, #0x190]
   1f658:      	str	x1, [x0, #0x18]
   1f65c:      	ldr	x0, [x19, #0x50c0]
   1f660:      	ldr	x1, [sp, #0x190]
   1f664:      	str	x0, [x1, #0x160]
   1f668:      	ldr	x0, [x19, #0x50c8]
   1f66c:      	str	x0, [x1, #0x168]
   1f670:      	ldr	x0, [x19, #0x50d0]
   1f674:      	str	x0, [x1, #0x170]
   1f678:      	ldr	x0, [x19, #0x50d8]
   1f67c:      	str	x0, [x5, #0x178]
   1f680:      	ldr	x0, [x19, #0x50e0]
   1f684:      	ldr	x7, [sp, #0x190]
   1f688:      	str	x0, [x7, #0x180]
   1f68c:      	ldr	x0, [x19, #0x50e8]
   1f690:      	ldr	x10, [sp, #0x190]
   1f694:      	str	x0, [x10, #0x188]
   1f698:      	ldr	x0, [x19, #0x50f0]
   1f69c:      	ldr	x13, [sp, #0x190]
   1f6a0:      	str	x0, [x13, #0x190]
   1f6a4:      	ldr	x0, [x19, #0x50f8]
   1f6a8:      	str	x0, [x1, #0x198]
   1f6ac:      	ldr	x0, [x19, #0x5100]
   1f6b0:      	str	x0, [x1, #0x1a0]
   1f6b4:      	ldr	x0, [x19, #0x52a8]
   1f6b8:      	str	x0, [x1, #0x348]
   1f6bc:      	ldr	x0, [x19, #0x52b0]
   1f6c0:      	str	x0, [x1, #0x350]
   1f6c4:      	ldr	x0, [x19, #0x52b8]
   1f6c8:      	str	x0, [x1, #0x358]
   1f6cc:      	ldr	x0, [x19, #0x52c0]
   1f6d0:      	str	x0, [x1, #0x360]
   1f6d4:      	ldr	x0, [x19, #0x52c8]
   1f6d8:      	str	x0, [x1, #0x368]
   1f6dc:      	ldr	x0, [x19, #0x52d0]
   1f6e0:      	str	x0, [x1, #0x370]
   1f6e4:      	ldr	x0, [x19, #0x52d8]
   1f6e8:      	str	x0, [x1, #0x378]
   1f6ec:      	ldr	x0, [x19, #0x52e0]
   1f6f0:      	str	x0, [x1, #0x380]
   1f6f4:      	ldr	x0, [x19, #0x52e8]
   1f6f8:      	str	x0, [x1, #0x388]
   1f6fc:      	ldr	x0, [x19, #0x55d8]
   1f700:      	str	x0, [x1, #0x678]
   1f704:      	ldr	x0, [x19, #0x55e0]
   1f708:      	str	x0, [x1, #0x680]
   1f70c:      	ldr	x0, [x19, #0x55e8]
   1f710:      	str	x0, [x1, #0x688]
   1f714:      	ldr	x0, [x19, #0x55f0]
   1f718:      	str	x0, [x1, #0x690]
   1f71c:      	ldr	x0, [x19, #0x55f8]
   1f720:      	str	x0, [x1, #0x698]
   1f724:      	ldr	x1, [x19, #0x5600]
   1f728:      	str	x1, [x2, #0x6a0]
   1f72c:      	ldr	x2, [x19, #0x5608]
   1f730:      	str	x2, [x5, #0x6a8]
   1f734:      	ldr	x5, [x19, #0x5610]
   1f738:      	str	x5, [x7, #0x6b0]
   1f73c:      	ldr	x5, [x19, #0x57a0]
   1f740:      	str	x5, [x10, #0x840]
   1f744:      	ldr	x5, [x19, #0x57a8]
   1f748:      	str	x5, [x13, #0x848]
   1f74c:      	ldr	x6, [x19, #0x57b0]
   1f750:      	ldr	x0, [sp, #0x190]
   1f754:      	str	x6, [x0, #0x850]
   1f758:      	ldr	x7, [x19, #0x57b8]
   1f75c:      	str	x7, [x0, #0x858]
   1f760:      	ldr	x8, [x19, #0x57c0]
   1f764:      	str	x8, [x0, #0x860]
   1f768:      	ldr	x9, [x19, #0x57c8]
   1f76c:      	str	x9, [x0, #0x868]
   1f770:      	ldr	x10, [x19, #0x57d0]
   1f774:      	str	x10, [x0, #0x870]
   1f778:      	ldr	x11, [x19, #0x57d8]
   1f77c:      	str	x11, [x0, #0x878]
   1f780:      	ldr	x12, [x19, #0x5bb0]
   1f784:      	str	x12, [x0, #0xc50]
   1f788:      	ldr	x13, [x19, #0x5bb8]
   1f78c:      	str	x13, [x0, #0xc58]
   1f790:      	ldr	x14, [x19, #0x5bc0]
   1f794:      	str	x14, [x0, #0xc60]
   1f798:      	ldr	x15, [x19, #0x5bc8]
   1f79c:      	str	x15, [x0, #0xc68]
   1f7a0:      	ldr	x0, [x19, #0x5bd0]
   1f7a4:      	ldr	x1, [sp, #0x190]
   1f7a8:      	str	x0, [x1, #0xc70]
   1f7ac:      	ldr	x0, [x19, #0x5bd8]
   1f7b0:      	str	x0, [x1, #0xc78]
   1f7b4:      	mov	x0, #0x0                ; =0
   1f7b8:      	str	x0, [x1, #0xc80]
   1f7bc:      	ldr	x1, [x19, #0x5be8]
   1f7c0:      	ldr	x2, [sp, #0x190]
   1f7c4:      	str	x1, [x2, #0xc88]
   1f7c8:      	ldr	x1, [x19, #0x5bf0]
   1f7cc:      	str	x1, [x2, #0xc90]
   1f7d0:      	ldr	x1, [sp, #0x190]
   1f7d4:      	str	x0, [x1, #0xc98]
   1f7d8:      	ldr	x1, [x19, #0x5c00]
   1f7dc:      	str	x1, [x2, #0xca0]
   1f7e0:      	ldr	x1, [x19, #0x5c08]
   1f7e4:      	ldr	x5, [sp, #0x190]
   1f7e8:      	str	x1, [x5, #0xca8]
   1f7ec:      	str	x0, [x5, #0xcb0]
   1f7f0:      	ldr	x0, [x19, #0x5c18]
   1f7f4:      	ldr	x8, [sp, #0x190]
   1f7f8:      	str	x0, [x8, #0xcb8]
   1f7fc:      	ldr	x0, [x19, #0x5c20]
   1f800:      	ldr	x11, [sp, #0x190]
   1f804:      	str	x0, [x11, #0xcc0]
   1f808:      	mov	x1, #0x532              ; =1330
   1f80c:      	mov	x2, #-0x9               ; =-9
   1f810:      	ldr	x21, [sp, #0x1a0]
   1f814:      	ldur	x0, [sp, #0x8]
   1f818:      	mov	x5, x20
   1f81c:      	ldr	x6, [sp, #0x198]
   1f820:      	blr	x21
   1f824:      	cmp	x0, #0x0
   1f828:      	b.ne	0x235d0 <_mech_canonical_program_entry_v1_numeric_1282+0x5450>
   1f82c:      	mov	x0, #0x3                ; =3
   1f830:      	ldr	x7, [sp, #0x188]
   1f834:      	mov	x21, x0
   1f838:      	cmp	x7, #0x2
   1f83c:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   1f840:      	mov	x5, #0x0                ; =0
   1f844:      	ldr	x3, [sp, #0x190]
   1f848:      	str	x5, [x3]
   1f84c:      	ldr	x0, [x19, #0x18a0]
   1f850:      	str	x0, [x3, #0x8]
   1f854:      	mov	x1, #0x532              ; =1330
   1f858:      	ldur	x0, [sp, #0x8]
   1f85c:      	ldr	x6, [sp, #0x198]
   1f860:      	ldr	x21, [sp, #0x1a0]
   1f864:      	mov	x4, x20
   1f868:      	mov	x2, x5
   1f86c:      	blr	x21
   1f870:      	cmp	x0, #0x0
   1f874:      	b.ne	0x235d8 <_mech_canonical_program_entry_v1_numeric_1282+0x5458>
   1f878:      	mov	x0, #0x3                ; =3
   1f87c:      	mov	x21, x0
   1f880:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   1f884:      	stur	x26, [sp, #0x50]
   1f888:      	ldr	x4, [sp, #0x140]
   1f88c:      	cmp	x0, x4
   1f890:      	b.lo	0x1fb28 <_mech_canonical_program_entry_v1_numeric_1282+0x19a8>
   1f894:      	b	0x235e0 <_mech_canonical_program_entry_v1_numeric_1282+0x5460>
   1f898:      	ldr	x3, [x19, #0x4c68]
   1f89c:      	ldr	x4, [x19, #0x4c70]
   1f8a0:      	mov	x0, #0x0                ; =0
   1f8a4:      	str	x0, [x19, #0x4c60]
   1f8a8:      	mov	x0, #0x3                ; =3
   1f8ac:      	ldr	x7, [sp, #0x188]
   1f8b0:      	mov	x21, x0
   1f8b4:      	cmp	x7, #0x19a
   1f8b8:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   1f8bc:      	ldr	x0, [x19, #0x4f70]
   1f8c0:      	ldr	x1, [sp, #0x190]
   1f8c4:      	str	x0, [x1, #0x10]
   1f8c8:      	ldr	x1, [x19, #0x4f78]
   1f8cc:      	ldr	x2, [sp, #0x190]
   1f8d0:      	str	x1, [x2, #0x18]
   1f8d4:      	ldr	x2, [x19, #0x5a20]
   1f8d8:      	ldr	x5, [sp, #0x190]
   1f8dc:      	str	x2, [x5, #0xac0]
   1f8e0:      	ldr	x2, [sp, #0x190]
   1f8e4:      	str	x0, [x2, #0x10]
   1f8e8:      	ldr	x0, [sp, #0x190]
   1f8ec:      	str	x1, [x0, #0x18]
   1f8f0:      	ldr	x0, [x19, #0x50c0]
   1f8f4:      	ldr	x1, [sp, #0x190]
   1f8f8:      	str	x0, [x1, #0x160]
   1f8fc:      	ldr	x0, [x19, #0x50c8]
   1f900:      	str	x0, [x1, #0x168]
   1f904:      	ldr	x0, [x19, #0x50d0]
   1f908:      	str	x0, [x1, #0x170]
   1f90c:      	ldr	x0, [x19, #0x50d8]
   1f910:      	str	x0, [x1, #0x178]
   1f914:      	ldr	x0, [x19, #0x50e0]
   1f918:      	str	x0, [x1, #0x180]
   1f91c:      	ldr	x0, [x19, #0x50e8]
   1f920:      	str	x0, [x1, #0x188]
   1f924:      	ldr	x0, [x19, #0x50f0]
   1f928:      	str	x0, [x1, #0x190]
   1f92c:      	ldr	x0, [x19, #0x50f8]
   1f930:      	str	x0, [x1, #0x198]
   1f934:      	ldr	x0, [x19, #0x5100]
   1f938:      	str	x0, [x1, #0x1a0]
   1f93c:      	ldr	x0, [x19, #0x52a8]
   1f940:      	str	x0, [x1, #0x348]
   1f944:      	ldr	x0, [x19, #0x52b0]
   1f948:      	str	x0, [x1, #0x350]
   1f94c:      	ldr	x0, [x19, #0x52b8]
   1f950:      	str	x0, [x5, #0x358]
   1f954:      	ldr	x0, [x19, #0x52c0]
   1f958:      	ldr	x6, [sp, #0x190]
   1f95c:      	str	x0, [x6, #0x360]
   1f960:      	ldr	x1, [x19, #0x52c8]
   1f964:      	ldr	x9, [sp, #0x190]
   1f968:      	str	x1, [x9, #0x368]
   1f96c:      	ldr	x2, [x19, #0x52d0]
   1f970:      	ldr	x12, [sp, #0x190]
   1f974:      	str	x2, [x12, #0x370]
   1f978:      	ldr	x5, [x19, #0x52d8]
   1f97c:      	ldr	x15, [sp, #0x190]
   1f980:      	str	x5, [x15, #0x378]
   1f984:      	ldr	x5, [x19, #0x52e0]
   1f988:      	ldr	x0, [sp, #0x190]
   1f98c:      	str	x5, [x0, #0x380]
   1f990:      	ldr	x5, [x19, #0x52e8]
   1f994:      	str	x5, [x0, #0x388]
   1f998:      	ldr	x6, [x19, #0x55d8]
   1f99c:      	str	x6, [x0, #0x678]
   1f9a0:      	ldr	x7, [x19, #0x55e0]
   1f9a4:      	str	x7, [x0, #0x680]
   1f9a8:      	ldr	x8, [x19, #0x55e8]
   1f9ac:      	str	x8, [x0, #0x688]
   1f9b0:      	ldr	x9, [x19, #0x55f0]
   1f9b4:      	str	x9, [x0, #0x690]
   1f9b8:      	ldr	x10, [x19, #0x55f8]
   1f9bc:      	str	x10, [x0, #0x698]
   1f9c0:      	ldr	x11, [x19, #0x5600]
   1f9c4:      	str	x11, [x0, #0x6a0]
   1f9c8:      	ldr	x12, [x19, #0x5608]
   1f9cc:      	str	x12, [x0, #0x6a8]
   1f9d0:      	ldr	x13, [x19, #0x5610]
   1f9d4:      	str	x13, [x0, #0x6b0]
   1f9d8:      	ldr	x14, [x19, #0x57a0]
   1f9dc:      	str	x14, [x0, #0x840]
   1f9e0:      	ldr	x15, [x19, #0x57a8]
   1f9e4:      	str	x15, [x0, #0x848]
   1f9e8:      	ldr	x0, [x19, #0x57b0]
   1f9ec:      	ldr	x1, [sp, #0x190]
   1f9f0:      	str	x0, [x1, #0x850]
   1f9f4:      	ldr	x0, [x19, #0x57b8]
   1f9f8:      	str	x0, [x1, #0x858]
   1f9fc:      	ldr	x0, [x19, #0x57c0]
   1fa00:      	str	x0, [x1, #0x860]
   1fa04:      	ldr	x0, [x19, #0x57c8]
   1fa08:      	str	x0, [x1, #0x868]
   1fa0c:      	ldr	x0, [x19, #0x57d0]
   1fa10:      	ldr	x5, [sp, #0x190]
   1fa14:      	str	x0, [x5, #0x870]
   1fa18:      	ldr	x0, [x19, #0x57d8]
   1fa1c:      	ldr	x6, [sp, #0x190]
   1fa20:      	str	x0, [x6, #0x878]
   1fa24:      	ldr	x0, [x19, #0x5bb0]
   1fa28:      	ldr	x9, [sp, #0x190]
   1fa2c:      	str	x0, [x9, #0xc50]
   1fa30:      	ldr	x0, [x19, #0x5bb8]
   1fa34:      	ldr	x12, [sp, #0x190]
   1fa38:      	str	x0, [x12, #0xc58]
   1fa3c:      	ldr	x0, [x19, #0x5bc0]
   1fa40:      	ldr	x15, [sp, #0x190]
   1fa44:      	str	x0, [x15, #0xc60]
   1fa48:      	ldr	x0, [x19, #0x5bc8]
   1fa4c:      	str	x0, [x1, #0xc68]
   1fa50:      	ldr	x0, [x19, #0x5bd0]
   1fa54:      	str	x0, [x1, #0xc70]
   1fa58:      	ldr	x0, [x19, #0x5bd8]
   1fa5c:      	str	x0, [x1, #0xc78]
   1fa60:      	mov	x0, #0x0                ; =0
   1fa64:      	str	x0, [x1, #0xc80]
   1fa68:      	ldr	x1, [x19, #0x5be8]
   1fa6c:      	ldr	x2, [sp, #0x190]
   1fa70:      	str	x1, [x2, #0xc88]
   1fa74:      	ldr	x1, [x19, #0x5bf0]
   1fa78:      	str	x1, [x2, #0xc90]
   1fa7c:      	ldr	x1, [sp, #0x190]
   1fa80:      	str	x0, [x1, #0xc98]
   1fa84:      	ldr	x1, [x19, #0x5c00]
   1fa88:      	str	x1, [x2, #0xca0]
   1fa8c:      	ldr	x1, [x19, #0x5c08]
   1fa90:      	str	x1, [x2, #0xca8]
   1fa94:      	ldr	x1, [sp, #0x190]
   1fa98:      	str	x0, [x1, #0xcb0]
   1fa9c:      	ldr	x0, [x19, #0x5c18]
   1faa0:      	str	x0, [x1, #0xcb8]
   1faa4:      	ldr	x0, [x19, #0x5c20]
   1faa8:      	str	x0, [x1, #0xcc0]
   1faac:      	mov	x1, #0x534              ; =1332
   1fab0:      	mov	x2, #-0x9               ; =-9
   1fab4:      	ldr	x21, [sp, #0x1a0]
   1fab8:      	ldur	x0, [sp, #0x8]
   1fabc:      	mov	x5, x20
   1fac0:      	ldr	x6, [sp, #0x198]
   1fac4:      	blr	x21
   1fac8:      	cmp	x0, #0x0
   1facc:      	b.ne	0x237c0 <_mech_canonical_program_entry_v1_numeric_1282+0x5640>
   1fad0:      	mov	x0, #0x3                ; =3
   1fad4:      	ldr	x7, [sp, #0x188]
   1fad8:      	mov	x21, x0
   1fadc:      	cmp	x7, #0x2
   1fae0:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   1fae4:      	mov	x5, #0x0                ; =0
   1fae8:      	ldr	x3, [sp, #0x190]
   1faec:      	str	x5, [x3]
   1faf0:      	ldr	x0, [x19, #0x18b0]
   1faf4:      	str	x0, [x3, #0x8]
   1faf8:      	mov	x1, #0x534              ; =1332
   1fafc:      	ldur	x0, [sp, #0x8]
   1fb00:      	ldr	x6, [sp, #0x198]
   1fb04:      	ldr	x21, [sp, #0x1a0]
   1fb08:      	mov	x4, x20
   1fb0c:      	mov	x2, x5
   1fb10:      	blr	x21
   1fb14:      	cmp	x0, #0x0
   1fb18:      	b.ne	0x237c8 <_mech_canonical_program_entry_v1_numeric_1282+0x5648>
   1fb1c:      	mov	x0, #0x3                ; =3
   1fb20:      	mov	x21, x0
   1fb24:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   1fb28:      	mov	w4, #0x2166             ; =8550
   1fb2c:      	movk	w4, #0x1, lsl #16
   1fb30:      	sub	x13, x3, x4
   1fb34:      	ldr	x3, [sp, #0x140]
   1fb38:      	sub	x3, x3, #0x1
   1fb3c:      	mov	x6, #0x0                ; =0
   1fb40:      	ldr	x4, [sp, #0x140]
   1fb44:      	stur	x6, [sp, #0x30]
   1fb48:      	cmp	x4, xzr
   1fb4c:      	csel	x14, x3, x6, ne
   1fb50:      	cmp	x1, x14
   1fb54:      	csel	x1, x1, x14, lo
   1fb58:      	ldr	x3, [sp, #0x148]
   1fb5c:      	ldr	x7, [x3, x1, lsl #3]
   1fb60:      	ldur	x10, [sp, #0x50]
   1fb64:      	ldur	x15, [sp, #0x10]
   1fb68:      	ldur	x26, [sp, #0x58]
   1fb6c:      	ldur	x28, [sp, #0x60]
   1fb70:      	ldur	x1, [sp, #0x68]
   1fb74:      	stur	x1, [sp, #0x28]
   1fb78:      	mov	w1, #0xdc1e             ; =56350
   1fb7c:      	movk	w1, #0x2, lsl #16
   1fb80:      	cmp	x13, x1
   1fb84:      	b.hs	0x1ffe0 <_mech_canonical_program_entry_v1_numeric_1282+0x1e60>
   1fb88:      	mov	x1, #0x0                ; =0
   1fb8c:      	str	x1, [x19, #0x18]
   1fb90:      	mov	x3, #0x1000000000000000 ; =1152921504606846976
   1fb94:      	str	x3, [x19, #0x20]
   1fb98:      	mov	x3, #0x1                ; =1
   1fb9c:      	str	x3, [x19, #0x30]
   1fba0:      	mov	x4, #0x101010101010101  ; =72340172838076673
   1fba4:      	str	x4, [x19, #0x38]
   1fba8:      	mov	x20, #0x2               ; =2
   1fbac:      	str	x20, [x19, #0x40]
   1fbb0:      	mov	x5, #0x3                ; =3
   1fbb4:      	str	x5, [x19, #0x48]
   1fbb8:      	mov	x6, #0x4                ; =4
   1fbbc:      	str	x6, [x19, #0x50]
   1fbc0:      	mov	x8, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   1fbc4:      	str	x8, [x19, #0x78]
   1fbc8:      	mov	x8, #0x3333333333333333 ; =3689348814741910323
   1fbcc:      	str	x8, [x19, #0x88]
   1fbd0:      	mov	x4, #0x38               ; =56
   1fbd4:      	str	x4, [x19, #0x90]
   1fbd8:      	mov	x4, #0x3a               ; =58
   1fbdc:      	str	x4, [x19, #0x98]
   1fbe0:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   1fbe4:      	str	x4, [x19, #0xb0]
   1fbe8:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   1fbec:      	str	x4, [x19, #0xb8]
   1fbf0:      	str	x1, [x19, #0x188]
   1fbf4:      	str	x3, [x19, #0x190]
   1fbf8:      	str	x22, [x19, #0x17a0]
   1fbfc:      	ldr	x4, [sp, #0x180]
   1fc00:      	str	x4, [x19, #0x17a8]
   1fc04:      	ldur	x24, [sp, #0xe0]
   1fc08:      	uxtb	w4, w24
   1fc0c:      	str	x4, [x19, #0x17b8]
   1fc10:      	ldur	x4, [sp, #0x18]
   1fc14:      	str	x4, [x19, #0x1858]
   1fc18:      	ldur	x4, [sp, #0xc8]
   1fc1c:      	str	x4, [x19, #0x1860]
   1fc20:      	str	x22, [x19, #0x1868]
   1fc24:      	ldr	x27, [sp, #0x160]
   1fc28:      	sub	x4, x27, #0x1
   1fc2c:      	cmp	x27, xzr
   1fc30:      	csel	x1, x4, x1, ne
   1fc34:      	cmp	x22, x1
   1fc38:      	csel	x1, x22, x1, lo
   1fc3c:      	ldr	x27, [sp, #0x168]
   1fc40:      	ldr	x1, [x27, x1, lsl #3]
   1fc44:      	str	x1, [x19, #0x1870]
   1fc48:      	ldur	x4, [sp, #0xc0]
   1fc4c:      	uxtb	w4, w4
   1fc50:      	str	x4, [x19, #0x1880]
   1fc54:      	ldur	x4, [sp, #0x78]
   1fc58:      	str	x4, [x19, #0x4c60]
   1fc5c:      	str	x13, [x19, #0x4c68]
   1fc60:      	ldur	x4, [sp, #0x80]
   1fc64:      	str	x4, [x19, #0x4c70]
   1fc68:      	str	x22, [x19, #0x4f70]
   1fc6c:      	ldr	x4, [sp, #0x180]
   1fc70:      	str	x4, [x19, #0x4f78]
   1fc74:      	ldur	x4, [sp, #0x18]
   1fc78:      	str	x4, [x19, #0x50c0]
   1fc7c:      	ldur	x4, [sp, #0xc8]
   1fc80:      	str	x4, [x19, #0x50c8]
   1fc84:      	str	x22, [x19, #0x50d0]
   1fc88:      	str	x1, [x19, #0x50d8]
   1fc8c:      	ldur	x4, [sp, #0x10]
   1fc90:      	str	x4, [x19, #0x50e0]
   1fc94:      	ldur	x25, [sp, #0x50]
   1fc98:      	str	x25, [x19, #0x50e8]
   1fc9c:      	ldur	x4, [sp, #0x58]
   1fca0:      	str	x4, [x19, #0x50f0]
   1fca4:      	ldur	x8, [sp, #0x60]
   1fca8:      	str	x8, [x19, #0x50f8]
   1fcac:      	ldur	x25, [sp, #0x68]
   1fcb0:      	str	x25, [x19, #0x5100]
   1fcb4:      	ldur	x4, [sp, #0x10]
   1fcb8:      	str	x4, [x19, #0x5178]
   1fcbc:      	ldur	x25, [sp, #0x50]
   1fcc0:      	str	x25, [x19, #0x5180]
   1fcc4:      	ldur	x4, [sp, #0x58]
   1fcc8:      	str	x4, [x19, #0x5188]
   1fccc:      	ldur	x4, [sp, #0x60]
   1fcd0:      	str	x4, [x19, #0x5190]
   1fcd4:      	ldur	x25, [sp, #0x68]
   1fcd8:      	str	x25, [x19, #0x5198]
   1fcdc:      	str	x7, [x19, #0x52a8]
   1fce0:      	cmp	x0, x14
   1fce4:      	csel	x0, x0, x14, lo
   1fce8:      	ldr	x21, [sp, #0x148]
   1fcec:      	ldr	x0, [x21, x0, lsl #3]
   1fcf0:      	str	x0, [x19, #0x52b0]
   1fcf4:      	str	x22, [x19, #0x52b8]
   1fcf8:      	str	x1, [x19, #0x52c0]
   1fcfc:      	str	x15, [x19, #0x52c8]
   1fd00:      	str	x10, [x19, #0x52d0]
   1fd04:      	str	x26, [x19, #0x52d8]
   1fd08:      	str	x28, [x19, #0x52e0]
   1fd0c:      	ldur	x28, [sp, #0x28]
   1fd10:      	str	x28, [x19, #0x52e8]
   1fd14:      	ldur	x4, [sp, #0x48]
   1fd18:      	str	x4, [x19, #0x5a20]
   1fd1c:      	add	x0, x11, #0x1
   1fd20:      	str	x0, [x19, #0x5bb0]
   1fd24:      	ldur	x25, [sp, #0x88]
   1fd28:      	str	x25, [x19, #0x5bb8]
   1fd2c:      	ldur	x1, [sp, #0x90]
   1fd30:      	str	x1, [x19, #0x5bc0]
   1fd34:      	ldur	x5, [sp, #0x70]
   1fd38:      	sub	x1, x5, x13
   1fd3c:      	mov	w4, #0xc87e             ; =51326
   1fd40:      	movk	w4, #0x1, lsl #16
   1fd44:      	msub	x0, x0, x4, x1
   1fd48:      	str	x0, [x19, #0x5bc8]
   1fd4c:      	str	x3, [x19, #0x5bd0]
   1fd50:      	ldur	x27, [sp, #0x20]
   1fd54:      	str	x27, [x19, #0x5bd8]
   1fd58:      	str	x3, [x19, #0x5be8]
   1fd5c:      	ldur	x6, [sp, #0x30]
   1fd60:      	str	x6, [x19, #0x5bf0]
   1fd64:      	str	x12, [x19, #0x5c00]
   1fd68:      	str	x9, [x19, #0x5c08]
   1fd6c:      	str	x23, [x19, #0x5c18]
   1fd70:      	str	x2, [x19, #0x5c20]
   1fd74:      	ldr	x4, [x19, #0x4c60]
   1fd78:      	cmp	x4, #0x0
   1fd7c:      	b.eq	0x1ffb8 <_mech_canonical_program_entry_v1_numeric_1282+0x1e38>
   1fd80:      	ldr	x3, [x19, #0x4c68]
   1fd84:      	ldr	x4, [x19, #0x4c70]
   1fd88:      	mov	x7, #0x0                ; =0
   1fd8c:      	str	x7, [x19, #0x4c60]
   1fd90:      	mov	x0, #0x3                ; =3
   1fd94:      	ldr	x7, [sp, #0x188]
   1fd98:      	mov	x21, x0
   1fd9c:      	cmp	x7, #0x19a
   1fda0:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   1fda4:      	ldr	x11, [x19, #0x4f70]
   1fda8:      	ldr	x0, [sp, #0x190]
   1fdac:      	str	x11, [x0, #0x10]
   1fdb0:      	ldr	x12, [x19, #0x4f78]
   1fdb4:      	str	x12, [x0, #0x18]
   1fdb8:      	ldr	x13, [x19, #0x5a20]
   1fdbc:      	str	x13, [x0, #0xac0]
   1fdc0:      	ldr	x14, [x19, #0x5178]
   1fdc4:      	str	x14, [x0, #0x218]
   1fdc8:      	ldr	x15, [x19, #0x5180]
   1fdcc:      	str	x15, [x0, #0x220]
   1fdd0:      	ldr	x0, [x19, #0x5188]
   1fdd4:      	ldr	x1, [sp, #0x190]
   1fdd8:      	str	x0, [x1, #0x228]
   1fddc:      	ldr	x0, [x19, #0x5190]
   1fde0:      	str	x0, [x1, #0x230]
   1fde4:      	ldr	x0, [x19, #0x5198]
   1fde8:      	str	x0, [x1, #0x238]
   1fdec:      	ldr	x0, [sp, #0x190]
   1fdf0:      	str	x11, [x0, #0x10]
   1fdf4:      	str	x12, [x0, #0x18]
   1fdf8:      	ldr	x0, [x19, #0x50c0]
   1fdfc:      	str	x0, [x1, #0x160]
   1fe00:      	ldr	x0, [x19, #0x50c8]
   1fe04:      	str	x0, [x1, #0x168]
   1fe08:      	ldr	x0, [x19, #0x50d0]
   1fe0c:      	str	x0, [x1, #0x170]
   1fe10:      	ldr	x0, [x19, #0x50d8]
   1fe14:      	str	x0, [x1, #0x178]
   1fe18:      	ldr	x0, [x19, #0x50e0]
   1fe1c:      	str	x0, [x1, #0x180]
   1fe20:      	ldr	x0, [x19, #0x50e8]
   1fe24:      	str	x0, [x1, #0x188]
   1fe28:      	ldr	x0, [x19, #0x50f0]
   1fe2c:      	str	x0, [x1, #0x190]
   1fe30:      	ldr	x0, [x19, #0x50f8]
   1fe34:      	ldr	x2, [sp, #0x190]
   1fe38:      	str	x0, [x2, #0x198]
   1fe3c:      	ldr	x0, [x19, #0x5100]
   1fe40:      	ldr	x5, [sp, #0x190]
   1fe44:      	str	x0, [x5, #0x1a0]
   1fe48:      	ldr	x0, [x19, #0x52a8]
   1fe4c:      	ldr	x8, [sp, #0x190]
   1fe50:      	str	x0, [x8, #0x348]
   1fe54:      	ldr	x0, [x19, #0x52b0]
   1fe58:      	ldr	x11, [sp, #0x190]
   1fe5c:      	str	x0, [x11, #0x350]
   1fe60:      	ldr	x0, [x19, #0x52b8]
   1fe64:      	ldr	x14, [sp, #0x190]
   1fe68:      	str	x0, [x14, #0x358]
   1fe6c:      	ldr	x0, [x19, #0x52c0]
   1fe70:      	str	x0, [x1, #0x360]
   1fe74:      	ldr	x0, [x19, #0x52c8]
   1fe78:      	str	x0, [x1, #0x368]
   1fe7c:      	ldr	x0, [x19, #0x52d0]
   1fe80:      	str	x0, [x1, #0x370]
   1fe84:      	ldr	x0, [x19, #0x52d8]
   1fe88:      	str	x0, [x1, #0x378]
   1fe8c:      	ldr	x0, [x19, #0x52e0]
   1fe90:      	str	x0, [x1, #0x380]
   1fe94:      	ldr	x0, [x19, #0x52e8]
   1fe98:      	str	x0, [x1, #0x388]
   1fe9c:      	ldr	x0, [x19, #0x55d8]
   1fea0:      	str	x0, [x1, #0x678]
   1fea4:      	ldr	x0, [x19, #0x55e0]
   1fea8:      	str	x0, [x1, #0x680]
   1feac:      	ldr	x0, [x19, #0x55e8]
   1feb0:      	str	x0, [x1, #0x688]
   1feb4:      	ldr	x0, [x19, #0x55f0]
   1feb8:      	str	x0, [x1, #0x690]
   1febc:      	ldr	x0, [x19, #0x55f8]
   1fec0:      	str	x0, [x1, #0x698]
   1fec4:      	ldr	x0, [x19, #0x5600]
   1fec8:      	str	x0, [x1, #0x6a0]
   1fecc:      	ldr	x0, [x19, #0x5608]
   1fed0:      	str	x0, [x1, #0x6a8]
   1fed4:      	ldr	x0, [x19, #0x5610]
   1fed8:      	str	x0, [x1, #0x6b0]
   1fedc:      	ldr	x0, [x19, #0x57a0]
   1fee0:      	str	x0, [x1, #0x840]
   1fee4:      	ldr	x0, [x19, #0x57a8]
   1fee8:      	str	x0, [x1, #0x848]
   1feec:      	ldr	x0, [x19, #0x57b0]
   1fef0:      	str	x0, [x2, #0x850]
   1fef4:      	ldr	x0, [x19, #0x57b8]
   1fef8:      	str	x0, [x5, #0x858]
   1fefc:      	ldr	x0, [x19, #0x57c0]
   1ff00:      	str	x0, [x8, #0x860]
   1ff04:      	ldr	x0, [x19, #0x57c8]
   1ff08:      	str	x0, [x11, #0x868]
   1ff0c:      	ldr	x0, [x19, #0x57d0]
   1ff10:      	str	x0, [x14, #0x870]
   1ff14:      	ldr	x0, [x19, #0x57d8]
   1ff18:      	str	x0, [x1, #0x878]
   1ff1c:      	ldr	x0, [x19, #0x5bb0]
   1ff20:      	str	x0, [x1, #0xc50]
   1ff24:      	ldr	x0, [x19, #0x5bb8]
   1ff28:      	str	x0, [x1, #0xc58]
   1ff2c:      	ldr	x0, [x19, #0x5bc0]
   1ff30:      	str	x0, [x1, #0xc60]
   1ff34:      	ldr	x0, [x19, #0x5bc8]
   1ff38:      	str	x0, [x1, #0xc68]
   1ff3c:      	ldr	x0, [x19, #0x5bd0]
   1ff40:      	str	x0, [x1, #0xc70]
   1ff44:      	ldr	x0, [x19, #0x5bd8]
   1ff48:      	str	x0, [x1, #0xc78]
   1ff4c:      	mov	x0, #0x0                ; =0
   1ff50:      	str	x0, [x1, #0xc80]
   1ff54:      	ldr	x1, [x19, #0x5be8]
   1ff58:      	str	x1, [x2, #0xc88]
   1ff5c:      	ldr	x1, [x19, #0x5bf0]
   1ff60:      	str	x1, [x2, #0xc90]
   1ff64:      	ldr	x1, [sp, #0x190]
   1ff68:      	str	x0, [x1, #0xc98]
   1ff6c:      	ldr	x2, [x19, #0x5c00]
   1ff70:      	str	x2, [x1, #0xca0]
   1ff74:      	ldr	x5, [x19, #0x5c08]
   1ff78:      	str	x5, [x1, #0xca8]
   1ff7c:      	str	x0, [x1, #0xcb0]
   1ff80:      	ldr	x5, [x19, #0x5c18]
   1ff84:      	ldr	x0, [sp, #0x190]
   1ff88:      	str	x5, [x0, #0xcb8]
   1ff8c:      	ldr	x6, [x19, #0x5c20]
   1ff90:      	str	x6, [x0, #0xcc0]
   1ff94:      	mov	x1, #0x53d              ; =1341
   1ff98:      	mov	x2, #-0x9               ; =-9
   1ff9c:      	mov	x5, #0x1                ; =1
   1ffa0:      	ldur	x0, [sp, #0x8]
   1ffa4:      	ldr	x6, [sp, #0x198]
   1ffa8:      	ldr	x21, [sp, #0x1a0]
   1ffac:      	blr	x21
   1ffb0:      	cmp	x0, #0x0
   1ffb4:      	b.ne	0x237d0 <_mech_canonical_program_entry_v1_numeric_1282+0x5650>
   1ffb8:      	mov	x0, #0x0                ; =0
   1ffbc:      	mov	x1, #0x3                ; =3
   1ffc0:      	add	sp, sp, #0x1b0
   1ffc4:      	ldp	x19, x20, [sp], #0x10
   1ffc8:      	ldp	x21, x22, [sp], #0x10
   1ffcc:      	ldp	x23, x24, [sp], #0x10
   1ffd0:      	ldp	x25, x26, [sp], #0x10
   1ffd4:      	ldp	x27, x28, [sp], #0x10
   1ffd8:      	ldp	x29, x30, [sp], #0x10
   1ffdc:      	retab
   1ffe0:      	cmp	x0, x14
   1ffe4:      	csel	x1, x0, x14, lo
   1ffe8:      	ldr	x3, [sp, #0x148]
   1ffec:      	ldr	x3, [x3, x1, lsl #3]
   1fff0:      	cmp	x7, x3
   1fff4:      	cset	x6, lo
   1fff8:      	cmp	x7, x3
   1fffc:      	b.lo	0x20020 <_mech_canonical_program_entry_v1_numeric_1282+0x1ea0>
   20000:      	ldur	x1, [sp, #0x28]
   20004:      	ldur	x4, [sp, #0x28]
   20008:      	mov	x5, x28
   2000c:      	mov	x6, x7
   20010:      	mov	x8, x26
   20014:      	mov	x20, x10
   20018:      	mov	x25, x15
   2001c:      	b	0x206e0 <_mech_canonical_program_entry_v1_numeric_1282+0x2560>
   20020:      	ldr	x4, [sp, #0x130]
   20024:      	cmp	x7, x4
   20028:      	b.lo	0x202c0 <_mech_canonical_program_entry_v1_numeric_1282+0x2140>
   2002c:      	b	0x237d8 <_mech_canonical_program_entry_v1_numeric_1282+0x5658>
   20030:      	ldr	x3, [x19, #0x4c68]
   20034:      	ldr	x4, [x19, #0x4c70]
   20038:      	mov	x0, #0x0                ; =0
   2003c:      	str	x0, [x19, #0x4c60]
   20040:      	mov	x0, #0x3                ; =3
   20044:      	ldr	x7, [sp, #0x188]
   20048:      	mov	x21, x0
   2004c:      	cmp	x7, #0x19a
   20050:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   20054:      	ldr	x0, [x19, #0x4f70]
   20058:      	ldr	x1, [sp, #0x190]
   2005c:      	str	x0, [x1, #0x10]
   20060:      	ldr	x1, [x19, #0x4f78]
   20064:      	ldr	x2, [sp, #0x190]
   20068:      	str	x1, [x2, #0x18]
   2006c:      	ldr	x2, [x19, #0x5a20]
   20070:      	ldr	x5, [sp, #0x190]
   20074:      	str	x2, [x5, #0xac0]
   20078:      	ldr	x2, [sp, #0x190]
   2007c:      	str	x0, [x2, #0x10]
   20080:      	ldr	x0, [sp, #0x190]
   20084:      	str	x1, [x0, #0x18]
   20088:      	ldr	x0, [x19, #0x50c0]
   2008c:      	ldr	x1, [sp, #0x190]
   20090:      	str	x0, [x1, #0x160]
   20094:      	ldr	x0, [x19, #0x50c8]
   20098:      	str	x0, [x1, #0x168]
   2009c:      	ldr	x0, [x19, #0x50d0]
   200a0:      	str	x0, [x1, #0x170]
   200a4:      	ldr	x0, [x19, #0x50d8]
   200a8:      	str	x0, [x1, #0x178]
   200ac:      	ldr	x0, [x19, #0x50e0]
   200b0:      	str	x0, [x1, #0x180]
   200b4:      	ldr	x0, [x19, #0x50e8]
   200b8:      	str	x0, [x1, #0x188]
   200bc:      	ldr	x0, [x19, #0x50f0]
   200c0:      	str	x0, [x1, #0x190]
   200c4:      	ldr	x0, [x19, #0x50f8]
   200c8:      	str	x0, [x1, #0x198]
   200cc:      	ldr	x0, [x19, #0x5100]
   200d0:      	str	x0, [x1, #0x1a0]
   200d4:      	ldr	x0, [x19, #0x52a8]
   200d8:      	str	x0, [x1, #0x348]
   200dc:      	ldr	x0, [x19, #0x52b0]
   200e0:      	str	x0, [x1, #0x350]
   200e4:      	ldr	x0, [x19, #0x52b8]
   200e8:      	str	x0, [x5, #0x358]
   200ec:      	ldr	x0, [x19, #0x52c0]
   200f0:      	ldr	x6, [sp, #0x190]
   200f4:      	str	x0, [x6, #0x360]
   200f8:      	ldr	x1, [x19, #0x52c8]
   200fc:      	ldr	x9, [sp, #0x190]
   20100:      	str	x1, [x9, #0x368]
   20104:      	ldr	x2, [x19, #0x52d0]
   20108:      	ldr	x12, [sp, #0x190]
   2010c:      	str	x2, [x12, #0x370]
   20110:      	ldr	x5, [x19, #0x52d8]
   20114:      	ldr	x15, [sp, #0x190]
   20118:      	str	x5, [x15, #0x378]
   2011c:      	ldr	x5, [x19, #0x52e0]
   20120:      	ldr	x0, [sp, #0x190]
   20124:      	str	x5, [x0, #0x380]
   20128:      	ldr	x5, [x19, #0x52e8]
   2012c:      	str	x5, [x0, #0x388]
   20130:      	ldr	x6, [x19, #0x55d8]
   20134:      	str	x6, [x0, #0x678]
   20138:      	ldr	x7, [x19, #0x55e0]
   2013c:      	str	x7, [x0, #0x680]
   20140:      	ldr	x8, [x19, #0x55e8]
   20144:      	str	x8, [x0, #0x688]
   20148:      	ldr	x9, [x19, #0x55f0]
   2014c:      	str	x9, [x0, #0x690]
   20150:      	ldr	x10, [x19, #0x55f8]
   20154:      	str	x10, [x0, #0x698]
   20158:      	ldr	x11, [x19, #0x5600]
   2015c:      	str	x11, [x0, #0x6a0]
   20160:      	ldr	x12, [x19, #0x5608]
   20164:      	str	x12, [x0, #0x6a8]
   20168:      	ldr	x13, [x19, #0x5610]
   2016c:      	str	x13, [x0, #0x6b0]
   20170:      	ldr	x14, [x19, #0x57a0]
   20174:      	str	x14, [x0, #0x840]
   20178:      	ldr	x15, [x19, #0x57a8]
   2017c:      	str	x15, [x0, #0x848]
   20180:      	ldr	x0, [x19, #0x57b0]
   20184:      	ldr	x1, [sp, #0x190]
   20188:      	str	x0, [x1, #0x850]
   2018c:      	ldr	x0, [x19, #0x57b8]
   20190:      	str	x0, [x1, #0x858]
   20194:      	ldr	x0, [x19, #0x57c0]
   20198:      	str	x0, [x1, #0x860]
   2019c:      	ldr	x0, [x19, #0x57c8]
   201a0:      	str	x0, [x1, #0x868]
   201a4:      	ldr	x0, [x19, #0x57d0]
   201a8:      	ldr	x5, [sp, #0x190]
   201ac:      	str	x0, [x5, #0x870]
   201b0:      	ldr	x0, [x19, #0x57d8]
   201b4:      	ldr	x6, [sp, #0x190]
   201b8:      	str	x0, [x6, #0x878]
   201bc:      	ldr	x0, [x19, #0x5bb0]
   201c0:      	ldr	x9, [sp, #0x190]
   201c4:      	str	x0, [x9, #0xc50]
   201c8:      	ldr	x0, [x19, #0x5bb8]
   201cc:      	ldr	x12, [sp, #0x190]
   201d0:      	str	x0, [x12, #0xc58]
   201d4:      	ldr	x0, [x19, #0x5bc0]
   201d8:      	ldr	x15, [sp, #0x190]
   201dc:      	str	x0, [x15, #0xc60]
   201e0:      	ldr	x0, [x19, #0x5bc8]
   201e4:      	str	x0, [x1, #0xc68]
   201e8:      	ldr	x0, [x19, #0x5bd0]
   201ec:      	str	x0, [x1, #0xc70]
   201f0:      	ldr	x0, [x19, #0x5bd8]
   201f4:      	str	x0, [x1, #0xc78]
   201f8:      	mov	x0, #0x0                ; =0
   201fc:      	str	x0, [x1, #0xc80]
   20200:      	ldr	x1, [x19, #0x5be8]
   20204:      	ldr	x2, [sp, #0x190]
   20208:      	str	x1, [x2, #0xc88]
   2020c:      	ldr	x1, [x19, #0x5bf0]
   20210:      	str	x1, [x2, #0xc90]
   20214:      	ldr	x1, [sp, #0x190]
   20218:      	str	x0, [x1, #0xc98]
   2021c:      	ldr	x1, [x19, #0x5c00]
   20220:      	str	x1, [x2, #0xca0]
   20224:      	ldr	x1, [x19, #0x5c08]
   20228:      	str	x1, [x2, #0xca8]
   2022c:      	ldr	x1, [sp, #0x190]
   20230:      	str	x0, [x1, #0xcb0]
   20234:      	ldr	x0, [x19, #0x5c18]
   20238:      	str	x0, [x1, #0xcb8]
   2023c:      	ldr	x0, [x19, #0x5c20]
   20240:      	str	x0, [x1, #0xcc0]
   20244:      	mov	x1, #0x54e              ; =1358
   20248:      	mov	x2, #-0x9               ; =-9
   2024c:      	ldr	x21, [sp, #0x1a0]
   20250:      	ldur	x0, [sp, #0x8]
   20254:      	mov	x5, x20
   20258:      	ldr	x6, [sp, #0x198]
   2025c:      	blr	x21
   20260:      	cmp	x0, #0x0
   20264:      	b.ne	0x239d4 <_mech_canonical_program_entry_v1_numeric_1282+0x5854>
   20268:      	mov	x0, #0x3                ; =3
   2026c:      	ldr	x7, [sp, #0x188]
   20270:      	mov	x21, x0
   20274:      	cmp	x7, #0x2
   20278:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   2027c:      	mov	x5, #0x0                ; =0
   20280:      	ldr	x3, [sp, #0x190]
   20284:      	str	x5, [x3]
   20288:      	ldr	x0, [x19, #0x1950]
   2028c:      	str	x0, [x3, #0x8]
   20290:      	mov	x1, #0x54e              ; =1358
   20294:      	ldur	x0, [sp, #0x8]
   20298:      	ldr	x6, [sp, #0x198]
   2029c:      	ldr	x21, [sp, #0x1a0]
   202a0:      	mov	x4, x20
   202a4:      	mov	x2, x5
   202a8:      	blr	x21
   202ac:      	cmp	x0, #0x0
   202b0:      	b.ne	0x239dc <_mech_canonical_program_entry_v1_numeric_1282+0x585c>
   202b4:      	mov	x0, #0x3                ; =3
   202b8:      	mov	x21, x0
   202bc:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   202c0:      	ldur	x1, [sp, #0x28]
   202c4:      	ldr	x4, [sp, #0x130]
   202c8:      	sub	x4, x4, #0x1
   202cc:      	mov	x5, #0x0                ; =0
   202d0:      	ldr	x8, [sp, #0x130]
   202d4:      	cmp	x8, xzr
   202d8:      	csel	x4, x4, x5, ne
   202dc:      	cmp	x7, x4
   202e0:      	csel	x5, x7, x4, lo
   202e4:      	ldr	x4, [sp, #0x138]
   202e8:      	ldr	x25, [x4, x5, lsl #3]
   202ec:      	cmp	x25, x22
   202f0:      	b.ne	0x20310 <_mech_canonical_program_entry_v1_numeric_1282+0x2190>
   202f4:      	mov	x4, x1
   202f8:      	mov	x5, x28
   202fc:      	mov	x6, x7
   20300:      	mov	x8, x26
   20304:      	mov	x20, x10
   20308:      	mov	x25, x15
   2030c:      	b	0x206a4 <_mech_canonical_program_entry_v1_numeric_1282+0x2524>
   20310:      	add	x8, x25, #0x1
   20314:      	cmp	x8, x25
   20318:      	b.lo	0x239e4 <_mech_canonical_program_entry_v1_numeric_1282+0x5864>
   2031c:      	ldr	x4, [sp, #0x160]
   20320:      	cmp	x25, x4
   20324:      	b.lo	0x20590 <_mech_canonical_program_entry_v1_numeric_1282+0x2410>
   20328:      	b	0x23b64 <_mech_canonical_program_entry_v1_numeric_1282+0x59e4>
   2032c:      	ldr	x3, [x19, #0x4c68]
   20330:      	ldr	x4, [x19, #0x4c70]
   20334:      	mov	x0, #0x0                ; =0
   20338:      	str	x0, [x19, #0x4c60]
   2033c:      	mov	x0, #0x3                ; =3
   20340:      	ldr	x7, [sp, #0x188]
   20344:      	mov	x21, x0
   20348:      	cmp	x7, #0x19a
   2034c:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   20350:      	ldr	x1, [x19, #0x4f70]
   20354:      	ldr	x0, [sp, #0x190]
   20358:      	str	x1, [x0, #0x10]
   2035c:      	ldr	x2, [x19, #0x4f78]
   20360:      	str	x2, [x0, #0x18]
   20364:      	ldr	x5, [x19, #0x5a20]
   20368:      	str	x5, [x0, #0xac0]
   2036c:      	str	x1, [x0, #0x10]
   20370:      	str	x2, [x0, #0x18]
   20374:      	ldr	x6, [x19, #0x50c0]
   20378:      	str	x6, [x0, #0x160]
   2037c:      	ldr	x7, [x19, #0x50c8]
   20380:      	str	x7, [x0, #0x168]
   20384:      	ldr	x8, [x19, #0x50d0]
   20388:      	str	x8, [x0, #0x170]
   2038c:      	ldr	x9, [x19, #0x50d8]
   20390:      	str	x9, [x0, #0x178]
   20394:      	ldr	x10, [x19, #0x50e0]
   20398:      	str	x10, [x0, #0x180]
   2039c:      	ldr	x11, [x19, #0x50e8]
   203a0:      	str	x11, [x0, #0x188]
   203a4:      	ldr	x12, [x19, #0x50f0]
   203a8:      	ldr	x2, [sp, #0x190]
   203ac:      	str	x12, [x2, #0x190]
   203b0:      	ldr	x13, [x19, #0x50f8]
   203b4:      	ldr	x5, [sp, #0x190]
   203b8:      	str	x13, [x5, #0x198]
   203bc:      	ldr	x14, [x19, #0x5100]
   203c0:      	ldr	x8, [sp, #0x190]
   203c4:      	str	x14, [x8, #0x1a0]
   203c8:      	ldr	x15, [x19, #0x52a8]
   203cc:      	ldr	x11, [sp, #0x190]
   203d0:      	str	x15, [x11, #0x348]
   203d4:      	ldr	x0, [x19, #0x52b0]
   203d8:      	ldr	x14, [sp, #0x190]
   203dc:      	str	x0, [x14, #0x350]
   203e0:      	ldr	x0, [x19, #0x52b8]
   203e4:      	ldr	x1, [sp, #0x190]
   203e8:      	str	x0, [x1, #0x358]
   203ec:      	ldr	x0, [x19, #0x52c0]
   203f0:      	str	x0, [x1, #0x360]
   203f4:      	ldr	x0, [x19, #0x52c8]
   203f8:      	str	x0, [x1, #0x368]
   203fc:      	ldr	x0, [x19, #0x52d0]
   20400:      	str	x0, [x1, #0x370]
   20404:      	ldr	x0, [x19, #0x52d8]
   20408:      	str	x0, [x1, #0x378]
   2040c:      	ldr	x0, [x19, #0x52e0]
   20410:      	str	x0, [x1, #0x380]
   20414:      	ldr	x0, [x19, #0x52e8]
   20418:      	str	x0, [x1, #0x388]
   2041c:      	ldr	x0, [x19, #0x55d8]
   20420:      	str	x0, [x1, #0x678]
   20424:      	ldr	x0, [x19, #0x55e0]
   20428:      	str	x0, [x1, #0x680]
   2042c:      	ldr	x0, [x19, #0x55e8]
   20430:      	str	x0, [x1, #0x688]
   20434:      	ldr	x0, [x19, #0x55f0]
   20438:      	str	x0, [x1, #0x690]
   2043c:      	ldr	x0, [x19, #0x55f8]
   20440:      	str	x0, [x1, #0x698]
   20444:      	ldr	x0, [x19, #0x5600]
   20448:      	str	x0, [x1, #0x6a0]
   2044c:      	ldr	x0, [x19, #0x5608]
   20450:      	str	x0, [x1, #0x6a8]
   20454:      	ldr	x0, [x19, #0x5610]
   20458:      	str	x0, [x1, #0x6b0]
   2045c:      	ldr	x0, [x19, #0x57a0]
   20460:      	str	x0, [x1, #0x840]
   20464:      	ldr	x0, [x19, #0x57a8]
   20468:      	str	x0, [x2, #0x848]
   2046c:      	ldr	x0, [x19, #0x57b0]
   20470:      	str	x0, [x5, #0x850]
   20474:      	ldr	x0, [x19, #0x57b8]
   20478:      	str	x0, [x8, #0x858]
   2047c:      	ldr	x0, [x19, #0x57c0]
   20480:      	str	x0, [x11, #0x860]
   20484:      	ldr	x0, [x19, #0x57c8]
   20488:      	str	x0, [x14, #0x868]
   2048c:      	ldr	x0, [x19, #0x57d0]
   20490:      	str	x0, [x1, #0x870]
   20494:      	ldr	x0, [x19, #0x57d8]
   20498:      	str	x0, [x1, #0x878]
   2049c:      	ldr	x0, [x19, #0x5bb0]
   204a0:      	str	x0, [x1, #0xc50]
   204a4:      	ldr	x0, [x19, #0x5bb8]
   204a8:      	str	x0, [x1, #0xc58]
   204ac:      	ldr	x0, [x19, #0x5bc0]
   204b0:      	str	x0, [x1, #0xc60]
   204b4:      	ldr	x0, [x19, #0x5bc8]
   204b8:      	str	x0, [x1, #0xc68]
   204bc:      	ldr	x0, [x19, #0x5bd0]
   204c0:      	str	x0, [x1, #0xc70]
   204c4:      	ldr	x0, [x19, #0x5bd8]
   204c8:      	str	x0, [x1, #0xc78]
   204cc:      	mov	x0, #0x0                ; =0
   204d0:      	str	x0, [x1, #0xc80]
   204d4:      	ldr	x1, [x19, #0x5be8]
   204d8:      	str	x1, [x2, #0xc88]
   204dc:      	ldr	x1, [x19, #0x5bf0]
   204e0:      	str	x1, [x2, #0xc90]
   204e4:      	ldr	x1, [sp, #0x190]
   204e8:      	str	x0, [x1, #0xc98]
   204ec:      	ldr	x1, [x19, #0x5c00]
   204f0:      	str	x1, [x2, #0xca0]
   204f4:      	ldr	x1, [x19, #0x5c08]
   204f8:      	str	x1, [x2, #0xca8]
   204fc:      	ldr	x1, [sp, #0x190]
   20500:      	str	x0, [x1, #0xcb0]
   20504:      	ldr	x0, [x19, #0x5c18]
   20508:      	str	x0, [x1, #0xcb8]
   2050c:      	ldr	x0, [x19, #0x5c20]
   20510:      	str	x0, [x1, #0xcc0]
   20514:      	mov	x1, #0x555              ; =1365
   20518:      	mov	x2, #-0x9               ; =-9
   2051c:      	ldr	x21, [sp, #0x1a0]
   20520:      	ldur	x0, [sp, #0x8]
   20524:      	mov	x5, x20
   20528:      	ldr	x6, [sp, #0x198]
   2052c:      	blr	x21
   20530:      	cmp	x0, #0x0
   20534:      	b.ne	0x23d5c <_mech_canonical_program_entry_v1_numeric_1282+0x5bdc>
   20538:      	mov	x0, #0x3                ; =3
   2053c:      	ldr	x7, [sp, #0x188]
   20540:      	mov	x21, x0
   20544:      	cmp	x7, #0x2
   20548:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   2054c:      	mov	x5, #0x0                ; =0
   20550:      	ldr	x3, [sp, #0x190]
   20554:      	str	x5, [x3]
   20558:      	ldr	x0, [x19, #0x1970]
   2055c:      	str	x0, [x3, #0x8]
   20560:      	mov	x1, #0x555              ; =1365
   20564:      	ldur	x0, [sp, #0x8]
   20568:      	ldr	x6, [sp, #0x198]
   2056c:      	ldr	x21, [sp, #0x1a0]
   20570:      	mov	x4, x20
   20574:      	mov	x2, x5
   20578:      	blr	x21
   2057c:      	cmp	x0, #0x0
   20580:      	b.ne	0x23d64 <_mech_canonical_program_entry_v1_numeric_1282+0x5be4>
   20584:      	mov	x0, #0x3                ; =3
   20588:      	mov	x21, x0
   2058c:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   20590:      	ldr	x8, [sp, #0x160]
   20594:      	sub	x4, x8, #0x1
   20598:      	mov	x5, #0x0                ; =0
   2059c:      	ldr	x6, [sp, #0x160]
   205a0:      	cmp	x6, xzr
   205a4:      	csel	x4, x4, x5, ne
   205a8:      	cmp	x22, x4
   205ac:      	csel	x5, x22, x4, lo
   205b0:      	ldr	x6, [sp, #0x168]
   205b4:      	ldr	x5, [x6, x5, lsl #3]
   205b8:      	cmp	x25, x4
   205bc:      	csel	x4, x25, x4, lo
   205c0:      	ldr	x4, [x6, x4, lsl #3]
   205c4:      	and	x4, x5, x4
   205c8:      	fmov	d0, x4
   205cc:      	cnt.8b	v0, v0
   205d0:      	addv.8b	b0, v0
   205d4:      	umov.b	w4, v0[0]
   205d8:      	eor	x5, x25, #0x3ffffffffffffff
   205dc:      	orr	x6, x5, x4, lsl #58
   205e0:      	cmp	x6, x1
   205e4:      	cset	x4, hi
   205e8:      	cmp	x6, x15
   205ec:      	cset	x5, ne
   205f0:      	and	w4, w4, w5
   205f4:      	cmp	x6, x10
   205f8:      	cset	x5, ne
   205fc:      	and	w4, w4, w5
   20600:      	cmp	x6, x26
   20604:      	cset	x5, ne
   20608:      	and	w4, w4, w5
   2060c:      	cmp	x6, x28
   20610:      	cset	x5, ne
   20614:      	and	w4, w4, w5
   20618:      	uxtb	w4, w4
   2061c:      	tbnz	w4, #0x0, 0x20638 <_mech_canonical_program_entry_v1_numeric_1282+0x24b8>
   20620:      	mov	x4, x10
   20624:      	mov	x5, x26
   20628:      	mov	x6, x28
   2062c:      	mov	x8, x15
   20630:      	mov	x25, x1
   20634:      	b	0x20678 <_mech_canonical_program_entry_v1_numeric_1282+0x24f8>
   20638:      	cmp	x6, x15
   2063c:      	csel	x8, x6, x15, hi
   20640:      	cmp	x6, x15
   20644:      	csel	x5, x6, x15, lo
   20648:      	cmp	x5, x10
   2064c:      	csel	x4, x5, x10, hi
   20650:      	cmp	x5, x10
   20654:      	csel	x6, x5, x10, lo
   20658:      	cmp	x6, x26
   2065c:      	csel	x5, x6, x26, hi
   20660:      	cmp	x6, x26
   20664:      	csel	x20, x6, x26, lo
   20668:      	cmp	x20, x28
   2066c:      	csel	x6, x20, x28, hi
   20670:      	cmp	x20, x28
   20674:      	csel	x25, x20, x28, lo
   20678:      	mov	x20, x10
   2067c:      	mov	x10, x4
   20680:      	mov	x4, x1
   20684:      	mov	x1, x25
   20688:      	mov	x25, x15
   2068c:      	mov	x15, x8
   20690:      	mov	x8, x26
   20694:      	mov	x26, x5
   20698:      	mov	x5, x28
   2069c:      	mov	x28, x6
   206a0:      	mov	x6, x7
   206a4:      	str	x15, [sp, #0x1a8]
   206a8:      	mov	x15, x25
   206ac:      	ldr	x25, [sp, #0x1a8]
   206b0:      	str	x10, [sp, #0x1a8]
   206b4:      	mov	x10, x20
   206b8:      	ldr	x20, [sp, #0x1a8]
   206bc:      	str	x8, [sp, #0x1a8]
   206c0:      	mov	x8, x26
   206c4:      	ldr	x26, [sp, #0x1a8]
   206c8:      	str	x5, [sp, #0x1a8]
   206cc:      	mov	x5, x28
   206d0:      	ldr	x28, [sp, #0x1a8]
   206d4:      	str	x1, [sp, #0x1a8]
   206d8:      	mov	x1, x4
   206dc:      	ldr	x4, [sp, #0x1a8]
   206e0:      	cmp	x7, x3
   206e4:      	b.lo	0x22c6c <_mech_canonical_program_entry_v1_numeric_1282+0x4aec>
   206e8:      	mov	x0, #0x0                ; =0
   206ec:      	str	x0, [x24, #0x15d0]
   206f0:      	str	x0, [x24, #0x15d8]
   206f4:      	str	x0, [x24, #0x15e0]
   206f8:      	str	x0, [x24, #0x15e8]
   206fc:      	str	x0, [x24, #0x15f0]
   20700:      	str	x0, [x24, #0x15f8]
   20704:      	str	x0, [x24, #0x1600]
   20708:      	str	x0, [x24, #0x1608]
   2070c:      	str	x0, [x24, #0x1610]
   20710:      	str	x0, [x24, #0x1618]
   20714:      	str	x0, [x24, #0x1620]
   20718:      	str	x0, [x24, #0x1628]
   2071c:      	str	x0, [x24, #0x1630]
   20720:      	str	x0, [x24, #0x1638]
   20724:      	str	x0, [x24, #0x1640]
   20728:      	str	x0, [x24, #0x1648]
   2072c:      	str	x0, [x24, #0x1650]
   20730:      	str	x0, [x24, #0x1658]
   20734:      	mov	w0, #0xdc1e             ; =56350
   20738:      	movk	w0, #0x2, lsl #16
   2073c:      	sub	x3, x13, x0
   20740:      	mov	x0, #0x0                ; =0
   20744:      	stur	x0, [sp, #0x98]
   20748:      	ldur	x7, [sp, #0x18]
   2074c:      	stur	x0, [sp, #0xa0]
   20750:      	ldur	x0, [sp, #0xc8]
   20754:      	ldur	x4, [sp, #0x18]
   20758:      	cmp	x4, x0
   2075c:      	b.lo	0x22c3c <_mech_canonical_program_entry_v1_numeric_1282+0x4abc>
   20760:      	mov	x0, #0x0                ; =0
   20764:      	str	x0, [x24, #0x1200]
   20768:      	str	x0, [x24, #0x1208]
   2076c:      	str	x0, [x24, #0x1210]
   20770:      	str	x0, [x24, #0x1218]
   20774:      	str	x0, [x24, #0x1220]
   20778:      	str	x0, [x24, #0x1228]
   2077c:      	str	x0, [x24, #0x1230]
   20780:      	str	x0, [x24, #0x1238]
   20784:      	str	x0, [x24, #0x1240]
   20788:      	str	x0, [x24, #0x1248]
   2078c:      	str	x0, [x24, #0x1250]
   20790:      	str	x0, [x24, #0x1258]
   20794:      	str	x0, [x24, #0x1260]
   20798:      	str	x0, [x24, #0x1268]
   2079c:      	str	x0, [x24, #0x1270]
   207a0:      	str	x0, [x24, #0x1278]
   207a4:      	str	x0, [x24, #0x1280]
   207a8:      	str	x0, [x24, #0x1288]
   207ac:      	ldr	x25, [sp, #0x120]
   207b0:      	cmp	x22, x25
   207b4:      	b.lo	0x20a28 <_mech_canonical_program_entry_v1_numeric_1282+0x28a8>
   207b8:      	b	0x23d6c <_mech_canonical_program_entry_v1_numeric_1282+0x5bec>
   207bc:      	ldr	x3, [x19, #0x4c68]
   207c0:      	ldr	x4, [x19, #0x4c70]
   207c4:      	mov	x0, #0x0                ; =0
   207c8:      	str	x0, [x19, #0x4c60]
   207cc:      	mov	x0, #0x3                ; =3
   207d0:      	ldr	x7, [sp, #0x188]
   207d4:      	mov	x21, x0
   207d8:      	cmp	x7, #0x19a
   207dc:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   207e0:      	ldr	x5, [x19, #0x4f70]
   207e4:      	ldr	x0, [sp, #0x190]
   207e8:      	str	x5, [x0, #0x10]
   207ec:      	ldr	x6, [x19, #0x4f78]
   207f0:      	str	x6, [x0, #0x18]
   207f4:      	ldr	x7, [x19, #0x5a20]
   207f8:      	str	x7, [x0, #0xac0]
   207fc:      	str	x5, [x0, #0x10]
   20800:      	str	x6, [x0, #0x18]
   20804:      	ldr	x9, [x19, #0x50c0]
   20808:      	str	x9, [x0, #0x160]
   2080c:      	ldr	x10, [x19, #0x50c8]
   20810:      	str	x10, [x0, #0x168]
   20814:      	ldr	x11, [x19, #0x50d0]
   20818:      	str	x11, [x0, #0x170]
   2081c:      	ldr	x12, [x19, #0x50d8]
   20820:      	str	x12, [x0, #0x178]
   20824:      	ldr	x13, [x19, #0x50e0]
   20828:      	str	x13, [x0, #0x180]
   2082c:      	ldr	x14, [x19, #0x50e8]
   20830:      	str	x14, [x0, #0x188]
   20834:      	ldr	x15, [x19, #0x50f0]
   20838:      	str	x15, [x0, #0x190]
   2083c:      	ldr	x0, [x19, #0x50f8]
   20840:      	ldr	x1, [sp, #0x190]
   20844:      	str	x0, [x1, #0x198]
   20848:      	ldr	x0, [x19, #0x5100]
   2084c:      	str	x0, [x1, #0x1a0]
   20850:      	ldr	x0, [x19, #0x52a8]
   20854:      	ldr	x5, [sp, #0x190]
   20858:      	str	x0, [x5, #0x348]
   2085c:      	ldr	x0, [x19, #0x52b0]
   20860:      	ldr	x7, [sp, #0x190]
   20864:      	str	x0, [x7, #0x350]
   20868:      	ldr	x0, [x19, #0x52b8]
   2086c:      	ldr	x10, [sp, #0x190]
   20870:      	str	x0, [x10, #0x358]
   20874:      	ldr	x0, [x19, #0x52c0]
   20878:      	ldr	x13, [sp, #0x190]
   2087c:      	str	x0, [x13, #0x360]
   20880:      	ldr	x0, [x19, #0x52c8]
   20884:      	str	x0, [x1, #0x368]
   20888:      	ldr	x0, [x19, #0x52d0]
   2088c:      	str	x0, [x1, #0x370]
   20890:      	ldr	x0, [x19, #0x52d8]
   20894:      	str	x0, [x1, #0x378]
   20898:      	ldr	x0, [x19, #0x52e0]
   2089c:      	str	x0, [x1, #0x380]
   208a0:      	ldr	x0, [x19, #0x52e8]
   208a4:      	str	x0, [x1, #0x388]
   208a8:      	ldr	x0, [x19, #0x55d8]
   208ac:      	str	x0, [x1, #0x678]
   208b0:      	ldr	x0, [x19, #0x55e0]
   208b4:      	str	x0, [x1, #0x680]
   208b8:      	ldr	x0, [x19, #0x55e8]
   208bc:      	str	x0, [x1, #0x688]
   208c0:      	ldr	x0, [x19, #0x55f0]
   208c4:      	str	x0, [x1, #0x690]
   208c8:      	ldr	x0, [x19, #0x55f8]
   208cc:      	str	x0, [x1, #0x698]
   208d0:      	ldr	x0, [x19, #0x5600]
   208d4:      	str	x0, [x1, #0x6a0]
   208d8:      	ldr	x0, [x19, #0x5608]
   208dc:      	str	x0, [x1, #0x6a8]
   208e0:      	ldr	x0, [x19, #0x5610]
   208e4:      	str	x0, [x1, #0x6b0]
   208e8:      	ldr	x0, [x19, #0x57a0]
   208ec:      	str	x0, [x1, #0x840]
   208f0:      	ldr	x0, [x19, #0x57a8]
   208f4:      	str	x0, [x1, #0x848]
   208f8:      	ldr	x0, [x19, #0x57b0]
   208fc:      	str	x0, [x1, #0x850]
   20900:      	ldr	x0, [x19, #0x57b8]
   20904:      	str	x0, [x1, #0x858]
   20908:      	ldr	x0, [x19, #0x57c0]
   2090c:      	str	x0, [x5, #0x860]
   20910:      	ldr	x0, [x19, #0x57c8]
   20914:      	str	x0, [x7, #0x868]
   20918:      	ldr	x0, [x19, #0x57d0]
   2091c:      	str	x0, [x10, #0x870]
   20920:      	ldr	x0, [x19, #0x57d8]
   20924:      	str	x0, [x13, #0x878]
   20928:      	ldr	x0, [x19, #0x5bb0]
   2092c:      	str	x0, [x1, #0xc50]
   20930:      	ldr	x0, [x19, #0x5bb8]
   20934:      	str	x0, [x1, #0xc58]
   20938:      	ldr	x0, [x19, #0x5bc0]
   2093c:      	str	x0, [x1, #0xc60]
   20940:      	ldr	x0, [x19, #0x5bc8]
   20944:      	str	x0, [x1, #0xc68]
   20948:      	ldr	x0, [x19, #0x5bd0]
   2094c:      	str	x0, [x1, #0xc70]
   20950:      	ldr	x0, [x19, #0x5bd8]
   20954:      	str	x0, [x1, #0xc78]
   20958:      	mov	x0, #0x0                ; =0
   2095c:      	str	x0, [x1, #0xc80]
   20960:      	ldr	x1, [x19, #0x5be8]
   20964:      	ldr	x2, [sp, #0x190]
   20968:      	str	x1, [x2, #0xc88]
   2096c:      	ldr	x1, [x19, #0x5bf0]
   20970:      	str	x1, [x2, #0xc90]
   20974:      	ldr	x1, [sp, #0x190]
   20978:      	str	x0, [x1, #0xc98]
   2097c:      	ldr	x1, [x19, #0x5c00]
   20980:      	str	x1, [x2, #0xca0]
   20984:      	ldr	x1, [x19, #0x5c08]
   20988:      	str	x1, [x2, #0xca8]
   2098c:      	ldr	x1, [sp, #0x190]
   20990:      	str	x0, [x1, #0xcb0]
   20994:      	ldr	x0, [x19, #0x5c18]
   20998:      	str	x0, [x1, #0xcb8]
   2099c:      	ldr	x0, [x19, #0x5c20]
   209a0:      	str	x0, [x1, #0xcc0]
   209a4:      	mov	x1, #0x5e8              ; =1512
   209a8:      	mov	x2, #-0x9               ; =-9
   209ac:      	ldr	x21, [sp, #0x1a0]
   209b0:      	ldur	x0, [sp, #0x8]
   209b4:      	mov	x5, x27
   209b8:      	ldr	x6, [sp, #0x198]
   209bc:      	blr	x21
   209c0:      	cmp	x0, #0x0
   209c4:      	b.ne	0x23e98 <_mech_canonical_program_entry_v1_numeric_1282+0x5d18>
   209c8:      	mov	x0, #0x3                ; =3
   209cc:      	ldr	x7, [sp, #0x188]
   209d0:      	mov	x21, x0
   209d4:      	cmp	x7, #0x2
   209d8:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   209dc:      	mov	x5, #0x0                ; =0
   209e0:      	ldr	x3, [sp, #0x190]
   209e4:      	str	x5, [x3]
   209e8:      	ldr	x3, [x19, #0x1c00]
   209ec:      	ldr	x10, [sp, #0x190]
   209f0:      	str	x3, [x10, #0x8]
   209f4:      	mov	x1, #0x5e8              ; =1512
   209f8:      	ldur	x0, [sp, #0x8]
   209fc:      	ldr	x3, [sp, #0x190]
   20a00:      	ldr	x6, [sp, #0x198]
   20a04:      	ldr	x21, [sp, #0x1a0]
   20a08:      	mov	x4, x27
   20a0c:      	mov	x2, x5
   20a10:      	blr	x21
   20a14:      	cmp	x0, #0x0
   20a18:      	b.ne	0x23ea0 <_mech_canonical_program_entry_v1_numeric_1282+0x5d20>
   20a1c:      	mov	x0, #0x3                ; =3
   20a20:      	mov	x21, x0
   20a24:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   20a28:      	ldur	x0, [sp, #0xd8]
   20a2c:      	ldr	x25, [sp, #0x120]
   20a30:      	cmp	x0, x25
   20a34:      	b.lo	0x20cc0 <_mech_canonical_program_entry_v1_numeric_1282+0x2b40>
   20a38:      	b	0x23ea8 <_mech_canonical_program_entry_v1_numeric_1282+0x5d28>
   20a3c:      	ldr	x3, [x19, #0x4c68]
   20a40:      	ldr	x4, [x19, #0x4c70]
   20a44:      	mov	x0, #0x0                ; =0
   20a48:      	str	x0, [x19, #0x4c60]
   20a4c:      	mov	x0, #0x3                ; =3
   20a50:      	ldr	x7, [sp, #0x188]
   20a54:      	mov	x21, x0
   20a58:      	cmp	x7, #0x19a
   20a5c:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   20a60:      	ldr	x0, [x19, #0x4f70]
   20a64:      	ldr	x1, [sp, #0x190]
   20a68:      	str	x0, [x1, #0x10]
   20a6c:      	ldr	x1, [x19, #0x4f78]
   20a70:      	ldr	x2, [sp, #0x190]
   20a74:      	str	x1, [x2, #0x18]
   20a78:      	ldr	x2, [x19, #0x5a20]
   20a7c:      	ldr	x5, [sp, #0x190]
   20a80:      	str	x2, [x5, #0xac0]
   20a84:      	ldr	x2, [sp, #0x190]
   20a88:      	str	x0, [x2, #0x10]
   20a8c:      	ldr	x0, [sp, #0x190]
   20a90:      	str	x1, [x0, #0x18]
   20a94:      	ldr	x5, [x19, #0x50c0]
   20a98:      	str	x5, [x0, #0x160]
   20a9c:      	ldr	x5, [x19, #0x50c8]
   20aa0:      	str	x5, [x0, #0x168]
   20aa4:      	ldr	x5, [x19, #0x50d0]
   20aa8:      	str	x5, [x0, #0x170]
   20aac:      	ldr	x6, [x19, #0x50d8]
   20ab0:      	str	x6, [x0, #0x178]
   20ab4:      	ldr	x7, [x19, #0x50e0]
   20ab8:      	ldr	x5, [sp, #0x190]
   20abc:      	str	x7, [x5, #0x180]
   20ac0:      	ldr	x8, [x19, #0x50e8]
   20ac4:      	ldr	x6, [sp, #0x190]
   20ac8:      	str	x8, [x6, #0x188]
   20acc:      	ldr	x9, [x19, #0x50f0]
   20ad0:      	ldr	x10, [sp, #0x190]
   20ad4:      	str	x9, [x10, #0x190]
   20ad8:      	ldr	x10, [x19, #0x50f8]
   20adc:      	ldr	x12, [sp, #0x190]
   20ae0:      	str	x10, [x12, #0x198]
   20ae4:      	ldr	x11, [x19, #0x5100]
   20ae8:      	ldr	x15, [sp, #0x190]
   20aec:      	str	x11, [x15, #0x1a0]
   20af0:      	ldr	x12, [x19, #0x52a8]
   20af4:      	str	x12, [x0, #0x348]
   20af8:      	ldr	x13, [x19, #0x52b0]
   20afc:      	str	x13, [x0, #0x350]
   20b00:      	ldr	x14, [x19, #0x52b8]
   20b04:      	str	x14, [x0, #0x358]
   20b08:      	ldr	x15, [x19, #0x52c0]
   20b0c:      	str	x15, [x0, #0x360]
   20b10:      	ldr	x0, [x19, #0x52c8]
   20b14:      	ldr	x1, [sp, #0x190]
   20b18:      	str	x0, [x1, #0x368]
   20b1c:      	ldr	x0, [x19, #0x52d0]
   20b20:      	str	x0, [x1, #0x370]
   20b24:      	ldr	x0, [x19, #0x52d8]
   20b28:      	str	x0, [x1, #0x378]
   20b2c:      	ldr	x0, [x19, #0x52e0]
   20b30:      	str	x0, [x1, #0x380]
   20b34:      	ldr	x0, [x19, #0x52e8]
   20b38:      	str	x0, [x1, #0x388]
   20b3c:      	ldr	x0, [x19, #0x55d8]
   20b40:      	str	x0, [x1, #0x678]
   20b44:      	ldr	x0, [x19, #0x55e0]
   20b48:      	str	x0, [x1, #0x680]
   20b4c:      	ldr	x0, [x19, #0x55e8]
   20b50:      	str	x0, [x1, #0x688]
   20b54:      	ldr	x0, [x19, #0x55f0]
   20b58:      	str	x0, [x1, #0x690]
   20b5c:      	ldr	x0, [x19, #0x55f8]
   20b60:      	str	x0, [x1, #0x698]
   20b64:      	ldr	x0, [x19, #0x5600]
   20b68:      	str	x0, [x1, #0x6a0]
   20b6c:      	ldr	x0, [x19, #0x5608]
   20b70:      	str	x0, [x1, #0x6a8]
   20b74:      	ldr	x0, [x19, #0x5610]
   20b78:      	str	x0, [x5, #0x6b0]
   20b7c:      	ldr	x0, [x19, #0x57a0]
   20b80:      	str	x0, [x6, #0x840]
   20b84:      	ldr	x0, [x19, #0x57a8]
   20b88:      	ldr	x9, [sp, #0x190]
   20b8c:      	str	x0, [x9, #0x848]
   20b90:      	ldr	x0, [x19, #0x57b0]
   20b94:      	ldr	x12, [sp, #0x190]
   20b98:      	str	x0, [x12, #0x850]
   20b9c:      	ldr	x0, [x19, #0x57b8]
   20ba0:      	ldr	x15, [sp, #0x190]
   20ba4:      	str	x0, [x15, #0x858]
   20ba8:      	ldr	x0, [x19, #0x57c0]
   20bac:      	str	x0, [x1, #0x860]
   20bb0:      	ldr	x0, [x19, #0x57c8]
   20bb4:      	str	x0, [x1, #0x868]
   20bb8:      	ldr	x0, [x19, #0x57d0]
   20bbc:      	str	x0, [x1, #0x870]
   20bc0:      	ldr	x0, [x19, #0x57d8]
   20bc4:      	str	x0, [x1, #0x878]
   20bc8:      	ldr	x0, [x19, #0x5bb0]
   20bcc:      	str	x0, [x1, #0xc50]
   20bd0:      	ldr	x0, [x19, #0x5bb8]
   20bd4:      	str	x0, [x1, #0xc58]
   20bd8:      	ldr	x0, [x19, #0x5bc0]
   20bdc:      	str	x0, [x1, #0xc60]
   20be0:      	ldr	x0, [x19, #0x5bc8]
   20be4:      	str	x0, [x1, #0xc68]
   20be8:      	ldr	x0, [x19, #0x5bd0]
   20bec:      	str	x0, [x1, #0xc70]
   20bf0:      	ldr	x0, [x19, #0x5bd8]
   20bf4:      	str	x0, [x1, #0xc78]
   20bf8:      	mov	x0, #0x0                ; =0
   20bfc:      	str	x0, [x1, #0xc80]
   20c00:      	ldr	x1, [x19, #0x5be8]
   20c04:      	str	x1, [x2, #0xc88]
   20c08:      	ldr	x1, [x19, #0x5bf0]
   20c0c:      	str	x1, [x2, #0xc90]
   20c10:      	ldr	x1, [sp, #0x190]
   20c14:      	str	x0, [x1, #0xc98]
   20c18:      	ldr	x1, [x19, #0x5c00]
   20c1c:      	str	x1, [x2, #0xca0]
   20c20:      	ldr	x1, [x19, #0x5c08]
   20c24:      	str	x1, [x2, #0xca8]
   20c28:      	ldr	x1, [sp, #0x190]
   20c2c:      	str	x0, [x1, #0xcb0]
   20c30:      	ldr	x0, [x19, #0x5c18]
   20c34:      	str	x0, [x5, #0xcb8]
   20c38:      	ldr	x0, [x19, #0x5c20]
   20c3c:      	ldr	x7, [sp, #0x190]
   20c40:      	str	x0, [x7, #0xcc0]
   20c44:      	mov	x1, #0x5ea              ; =1514
   20c48:      	mov	x2, #-0x9               ; =-9
   20c4c:      	ldr	x21, [sp, #0x1a0]
   20c50:      	ldur	x0, [sp, #0x8]
   20c54:      	mov	x5, x20
   20c58:      	ldr	x6, [sp, #0x198]
   20c5c:      	blr	x21
   20c60:      	cmp	x0, #0x0
   20c64:      	b.ne	0x23ff8 <_mech_canonical_program_entry_v1_numeric_1282+0x5e78>
   20c68:      	mov	x0, #0x3                ; =3
   20c6c:      	ldr	x7, [sp, #0x188]
   20c70:      	mov	x21, x0
   20c74:      	cmp	x7, #0x2
   20c78:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   20c7c:      	mov	x5, #0x0                ; =0
   20c80:      	ldr	x3, [sp, #0x190]
   20c84:      	str	x5, [x3]
   20c88:      	ldr	x0, [x19, #0x1c10]
   20c8c:      	str	x0, [x3, #0x8]
   20c90:      	mov	x1, #0x5ea              ; =1514
   20c94:      	ldur	x0, [sp, #0x8]
   20c98:      	ldr	x6, [sp, #0x198]
   20c9c:      	ldr	x21, [sp, #0x1a0]
   20ca0:      	mov	x4, x20
   20ca4:      	mov	x2, x5
   20ca8:      	blr	x21
   20cac:      	cmp	x0, #0x0
   20cb0:      	b.ne	0x24000 <_mech_canonical_program_entry_v1_numeric_1282+0x5e80>
   20cb4:      	mov	x0, #0x3                ; =3
   20cb8:      	mov	x21, x0
   20cbc:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   20cc0:      	ldr	x25, [sp, #0x120]
   20cc4:      	sub	x9, x25, #0x1
   20cc8:      	mov	x15, #0x0               ; =0
   20ccc:      	stur	x15, [sp, #0x38]
   20cd0:      	cmp	x25, xzr
   20cd4:      	csel	x14, x9, x15, ne
   20cd8:      	cmp	x22, x14
   20cdc:      	stur	x14, [sp, #0xb8]
   20ce0:      	csel	x12, x22, x14, lo
   20ce4:      	ldr	x25, [sp, #0x128]
   20ce8:      	ldr	x12, [x25, x12, lsl #3]
   20cec:      	mov	w13, #0x2646            ; =9798
   20cf0:      	movk	w13, #0x1, lsl #16
   20cf4:      	cmp	x3, x13
   20cf8:      	cset	x15, hs
   20cfc:      	ldur	x1, [sp, #0xe8]
   20d00:      	and	w13, w15, w1
   20d04:      	uxtb	w13, w13
   20d08:      	cbnz	x13, 0x210b4 <_mech_canonical_program_entry_v1_numeric_1282+0x2f34>
   20d0c:      	mov	x14, #0x0               ; =0
   20d10:      	str	x14, [x19, #0x18]
   20d14:      	mov	x15, #0x1000000000000000 ; =1152921504606846976
   20d18:      	str	x15, [x19, #0x20]
   20d1c:      	mov	x0, #0x1                ; =1
   20d20:      	str	x0, [x19, #0x30]
   20d24:      	mov	x1, #0x101010101010101  ; =72340172838076673
   20d28:      	str	x1, [x19, #0x38]
   20d2c:      	mov	x20, #0x2               ; =2
   20d30:      	str	x20, [x19, #0x40]
   20d34:      	mov	x1, #0x3                ; =3
   20d38:      	str	x1, [x19, #0x48]
   20d3c:      	mov	x1, #0x4                ; =4
   20d40:      	str	x1, [x19, #0x50]
   20d44:      	mov	x27, x1
   20d48:      	mov	x1, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   20d4c:      	str	x1, [x19, #0x78]
   20d50:      	mov	x1, #0x3333333333333333 ; =3689348814741910323
   20d54:      	str	x1, [x19, #0x88]
   20d58:      	mov	x1, #0x38               ; =56
   20d5c:      	str	x1, [x19, #0x90]
   20d60:      	mov	x1, #0x3a               ; =58
   20d64:      	str	x1, [x19, #0x98]
   20d68:      	mov	x1, #0x5555555555555555 ; =6148914691236517205
   20d6c:      	str	x1, [x19, #0xb0]
   20d70:      	mov	x1, #0x3ffffffffffffff  ; =288230376151711743
   20d74:      	str	x1, [x19, #0xb8]
   20d78:      	str	x14, [x19, #0x188]
   20d7c:      	str	x0, [x19, #0x190]
   20d80:      	str	x22, [x19, #0x17a0]
   20d84:      	ldr	x1, [sp, #0x180]
   20d88:      	str	x1, [x19, #0x17a8]
   20d8c:      	ldur	x24, [sp, #0xe0]
   20d90:      	uxtb	w1, w24
   20d94:      	str	x1, [x19, #0x17b8]
   20d98:      	ldur	x13, [sp, #0x78]
   20d9c:      	str	x13, [x19, #0x4c60]
   20da0:      	str	x3, [x19, #0x4c68]
   20da4:      	ldur	x4, [sp, #0x80]
   20da8:      	str	x4, [x19, #0x4c70]
   20dac:      	str	x22, [x19, #0x4f70]
   20db0:      	ldr	x1, [sp, #0x180]
   20db4:      	str	x1, [x19, #0x4f78]
   20db8:      	str	x12, [x19, #0x55d8]
   20dbc:      	ldur	x1, [sp, #0xb8]
   20dc0:      	ldur	x4, [sp, #0xd8]
   20dc4:      	cmp	x4, x1
   20dc8:      	csel	x1, x4, x1, lo
   20dcc:      	ldr	x25, [sp, #0x128]
   20dd0:      	ldr	x1, [x25, x1, lsl #3]
   20dd4:      	str	x1, [x19, #0x55e0]
   20dd8:      	str	x22, [x19, #0x55e8]
   20ddc:      	ldur	x10, [sp, #0x10]
   20de0:      	str	x10, [x19, #0x55f0]
   20de4:      	ldur	x25, [sp, #0x50]
   20de8:      	str	x25, [x19, #0x55f8]
   20dec:      	ldur	x26, [sp, #0x58]
   20df0:      	str	x26, [x19, #0x5600]
   20df4:      	ldur	x28, [sp, #0x60]
   20df8:      	str	x28, [x19, #0x5608]
   20dfc:      	ldur	x25, [sp, #0x68]
   20e00:      	str	x25, [x19, #0x5610]
   20e04:      	ldur	x1, [sp, #0x48]
   20e08:      	str	x1, [x19, #0x5a20]
   20e0c:      	add	x1, x11, #0x1
   20e10:      	str	x1, [x19, #0x5bb0]
   20e14:      	ldur	x25, [sp, #0x88]
   20e18:      	str	x25, [x19, #0x5bb8]
   20e1c:      	ldur	x13, [sp, #0x90]
   20e20:      	str	x13, [x19, #0x5bc0]
   20e24:      	ldur	x5, [sp, #0x70]
   20e28:      	sub	x3, x5, x3
   20e2c:      	mov	w4, #0xc87e             ; =51326
   20e30:      	movk	w4, #0x1, lsl #16
   20e34:      	msub	x1, x1, x4, x3
   20e38:      	str	x1, [x19, #0x5bc8]
   20e3c:      	str	x14, [x19, #0x5bd0]
   20e40:      	str	x14, [x19, #0x5bd8]
   20e44:      	ldur	x10, [sp, #0x98]
   20e48:      	str	x10, [x19, #0x5be8]
   20e4c:      	ldur	x6, [sp, #0xa0]
   20e50:      	str	x6, [x19, #0x5bf0]
   20e54:      	str	x0, [x19, #0x5c00]
   20e58:      	ldur	x14, [sp, #0x38]
   20e5c:      	str	x14, [x19, #0x5c08]
   20e60:      	str	x23, [x19, #0x5c18]
   20e64:      	str	x2, [x19, #0x5c20]
   20e68:      	ldr	x0, [x19, #0x4c60]
   20e6c:      	cmp	x0, #0x0
   20e70:      	b.eq	0x2108c <_mech_canonical_program_entry_v1_numeric_1282+0x2f0c>
   20e74:      	ldr	x3, [x19, #0x4c68]
   20e78:      	ldr	x4, [x19, #0x4c70]
   20e7c:      	mov	x0, #0x0                ; =0
   20e80:      	str	x0, [x19, #0x4c60]
   20e84:      	mov	x0, #0x3                ; =3
   20e88:      	ldr	x7, [sp, #0x188]
   20e8c:      	mov	x21, x0
   20e90:      	cmp	x7, #0x19a
   20e94:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   20e98:      	ldr	x5, [x19, #0x4f70]
   20e9c:      	ldr	x9, [sp, #0x190]
   20ea0:      	str	x5, [x9, #0x10]
   20ea4:      	ldr	x6, [x19, #0x4f78]
   20ea8:      	ldr	x12, [sp, #0x190]
   20eac:      	str	x6, [x12, #0x18]
   20eb0:      	ldr	x7, [x19, #0x5a20]
   20eb4:      	ldr	x15, [sp, #0x190]
   20eb8:      	str	x7, [x15, #0xac0]
   20ebc:      	ldr	x0, [sp, #0x190]
   20ec0:      	str	x5, [x0, #0x10]
   20ec4:      	str	x6, [x0, #0x18]
   20ec8:      	ldr	x8, [x19, #0x50c0]
   20ecc:      	str	x8, [x0, #0x160]
   20ed0:      	ldr	x9, [x19, #0x50c8]
   20ed4:      	str	x9, [x0, #0x168]
   20ed8:      	ldr	x10, [x19, #0x50d0]
   20edc:      	str	x10, [x0, #0x170]
   20ee0:      	ldr	x11, [x19, #0x50d8]
   20ee4:      	str	x11, [x0, #0x178]
   20ee8:      	ldr	x12, [x19, #0x50e0]
   20eec:      	str	x12, [x0, #0x180]
   20ef0:      	ldr	x13, [x19, #0x50e8]
   20ef4:      	str	x13, [x0, #0x188]
   20ef8:      	ldr	x14, [x19, #0x50f0]
   20efc:      	str	x14, [x0, #0x190]
   20f00:      	ldr	x15, [x19, #0x50f8]
   20f04:      	str	x15, [x0, #0x198]
   20f08:      	ldr	x0, [x19, #0x5100]
   20f0c:      	ldr	x1, [sp, #0x190]
   20f10:      	str	x0, [x1, #0x1a0]
   20f14:      	ldr	x0, [x19, #0x52a8]
   20f18:      	str	x0, [x1, #0x348]
   20f1c:      	ldr	x0, [x19, #0x52b0]
   20f20:      	str	x0, [x1, #0x350]
   20f24:      	ldr	x0, [x19, #0x52b8]
   20f28:      	str	x0, [x1, #0x358]
   20f2c:      	ldr	x0, [x19, #0x52c0]
   20f30:      	str	x0, [x1, #0x360]
   20f34:      	ldr	x0, [x19, #0x52c8]
   20f38:      	str	x0, [x1, #0x368]
   20f3c:      	ldr	x0, [x19, #0x52d0]
   20f40:      	str	x0, [x1, #0x370]
   20f44:      	ldr	x0, [x19, #0x52d8]
   20f48:      	ldr	x5, [sp, #0x190]
   20f4c:      	str	x0, [x5, #0x378]
   20f50:      	ldr	x0, [x19, #0x52e0]
   20f54:      	ldr	x7, [sp, #0x190]
   20f58:      	str	x0, [x7, #0x380]
   20f5c:      	ldr	x0, [x19, #0x52e8]
   20f60:      	ldr	x10, [sp, #0x190]
   20f64:      	str	x0, [x10, #0x388]
   20f68:      	ldr	x0, [x19, #0x55d8]
   20f6c:      	ldr	x13, [sp, #0x190]
   20f70:      	str	x0, [x13, #0x678]
   20f74:      	ldr	x0, [x19, #0x55e0]
   20f78:      	str	x0, [x1, #0x680]
   20f7c:      	ldr	x0, [x19, #0x55e8]
   20f80:      	str	x0, [x1, #0x688]
   20f84:      	ldr	x0, [x19, #0x55f0]
   20f88:      	str	x0, [x1, #0x690]
   20f8c:      	ldr	x0, [x19, #0x55f8]
   20f90:      	str	x0, [x1, #0x698]
   20f94:      	ldr	x0, [x19, #0x5600]
   20f98:      	str	x0, [x1, #0x6a0]
   20f9c:      	ldr	x0, [x19, #0x5608]
   20fa0:      	str	x0, [x1, #0x6a8]
   20fa4:      	ldr	x0, [x19, #0x5610]
   20fa8:      	str	x0, [x1, #0x6b0]
   20fac:      	ldr	x0, [x19, #0x57a0]
   20fb0:      	str	x0, [x1, #0x840]
   20fb4:      	ldr	x0, [x19, #0x57a8]
   20fb8:      	str	x0, [x1, #0x848]
   20fbc:      	ldr	x0, [x19, #0x57b0]
   20fc0:      	str	x0, [x1, #0x850]
   20fc4:      	ldr	x0, [x19, #0x57b8]
   20fc8:      	str	x0, [x1, #0x858]
   20fcc:      	ldr	x0, [x19, #0x57c0]
   20fd0:      	str	x0, [x1, #0x860]
   20fd4:      	ldr	x0, [x19, #0x57c8]
   20fd8:      	str	x0, [x1, #0x868]
   20fdc:      	ldr	x0, [x19, #0x57d0]
   20fe0:      	str	x0, [x1, #0x870]
   20fe4:      	ldr	x0, [x19, #0x57d8]
   20fe8:      	str	x0, [x1, #0x878]
   20fec:      	ldr	x0, [x19, #0x5bb0]
   20ff0:      	str	x0, [x1, #0xc50]
   20ff4:      	ldr	x0, [x19, #0x5bb8]
   20ff8:      	str	x0, [x1, #0xc58]
   20ffc:      	ldr	x0, [x19, #0x5bc0]
   21000:      	str	x0, [x5, #0xc60]
   21004:      	ldr	x0, [x19, #0x5bc8]
   21008:      	str	x0, [x7, #0xc68]
   2100c:      	ldr	x0, [x19, #0x5bd0]
   21010:      	str	x0, [x10, #0xc70]
   21014:      	ldr	x0, [x19, #0x5bd8]
   21018:      	str	x0, [x13, #0xc78]
   2101c:      	mov	x0, #0x0                ; =0
   21020:      	str	x0, [x1, #0xc80]
   21024:      	ldr	x1, [x19, #0x5be8]
   21028:      	ldr	x2, [sp, #0x190]
   2102c:      	str	x1, [x2, #0xc88]
   21030:      	ldr	x1, [x19, #0x5bf0]
   21034:      	str	x1, [x2, #0xc90]
   21038:      	ldr	x1, [sp, #0x190]
   2103c:      	str	x0, [x1, #0xc98]
   21040:      	ldr	x1, [x19, #0x5c00]
   21044:      	str	x1, [x2, #0xca0]
   21048:      	ldr	x1, [x19, #0x5c08]
   2104c:      	str	x1, [x2, #0xca8]
   21050:      	ldr	x1, [sp, #0x190]
   21054:      	str	x0, [x1, #0xcb0]
   21058:      	ldr	x0, [x19, #0x5c18]
   2105c:      	str	x0, [x1, #0xcb8]
   21060:      	ldr	x0, [x19, #0x5c20]
   21064:      	str	x0, [x1, #0xcc0]
   21068:      	mov	x1, #0x5f2              ; =1522
   2106c:      	mov	x2, #-0x9               ; =-9
   21070:      	mov	x5, #0x1                ; =1
   21074:      	ldur	x0, [sp, #0x8]
   21078:      	ldr	x6, [sp, #0x198]
   2107c:      	ldr	x21, [sp, #0x1a0]
   21080:      	blr	x21
   21084:      	cmp	x0, #0x0
   21088:      	b.ne	0x24008 <_mech_canonical_program_entry_v1_numeric_1282+0x5e88>
   2108c:      	mov	x0, #0x0                ; =0
   21090:      	mov	x1, x27
   21094:      	add	sp, sp, #0x1b0
   21098:      	ldp	x19, x20, [sp], #0x10
   2109c:      	ldp	x21, x22, [sp], #0x10
   210a0:      	ldp	x23, x24, [sp], #0x10
   210a4:      	ldp	x25, x26, [sp], #0x10
   210a8:      	ldp	x27, x28, [sp], #0x10
   210ac:      	ldp	x29, x30, [sp], #0x10
   210b0:      	retab
   210b4:      	ldur	x0, [sp, #0xd8]
   210b8:      	ldur	x14, [sp, #0xb8]
   210bc:      	cmp	x0, x14
   210c0:      	csel	x13, x0, x14, lo
   210c4:      	ldr	x25, [sp, #0x128]
   210c8:      	ldr	x9, [x25, x13, lsl #3]
   210cc:      	cmp	x12, x9
   210d0:      	cset	x13, lo
   210d4:      	mov	x1, #0x1000000000000000 ; =1152921504606846976
   210d8:      	mov	x14, #0x1000000000000000 ; =1152921504606846976
   210dc:      	ldur	x25, [sp, #0x68]
   210e0:      	cmp	x25, x14
   210e4:      	cset	x15, lo
   210e8:      	and	w14, w13, w15
   210ec:      	uxtb	w10, w14
   210f0:      	tbnz	w10, #0x0, 0x21118 <_mech_canonical_program_entry_v1_numeric_1282+0x2f98>
   210f4:      	mov	w0, #0x2646             ; =9798
   210f8:      	movk	w0, #0x1, lsl #16
   210fc:      	sub	x3, x3, x0
   21100:      	ldur	x0, [sp, #0x60]
   21104:      	ldur	x14, [sp, #0x10]
   21108:      	ldur	x15, [sp, #0x50]
   2110c:      	ldur	x26, [sp, #0x58]
   21110:      	ldur	x28, [sp, #0x68]
   21114:      	b	0x221dc <_mech_canonical_program_entry_v1_numeric_1282+0x405c>
   21118:      	add	x0, x12, #0x1
   2111c:      	cmp	x0, x12
   21120:      	b.lo	0x24010 <_mech_canonical_program_entry_v1_numeric_1282+0x5e90>
   21124:      	ldr	x28, [sp, #0x110]
   21128:      	cmp	x12, x28
   2112c:      	b.lo	0x213c4 <_mech_canonical_program_entry_v1_numeric_1282+0x3244>
   21130:      	b	0x24144 <_mech_canonical_program_entry_v1_numeric_1282+0x5fc4>
   21134:      	ldr	x3, [x19, #0x4c68]
   21138:      	ldr	x4, [x19, #0x4c70]
   2113c:      	mov	x0, #0x0                ; =0
   21140:      	str	x0, [x19, #0x4c60]
   21144:      	mov	x0, #0x3                ; =3
   21148:      	ldr	x7, [sp, #0x188]
   2114c:      	mov	x21, x0
   21150:      	cmp	x7, #0x19a
   21154:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   21158:      	ldr	x0, [x19, #0x4f70]
   2115c:      	ldr	x1, [sp, #0x190]
   21160:      	str	x0, [x1, #0x10]
   21164:      	ldr	x1, [x19, #0x4f78]
   21168:      	ldr	x2, [sp, #0x190]
   2116c:      	str	x1, [x2, #0x18]
   21170:      	ldr	x2, [x19, #0x5a20]
   21174:      	ldr	x5, [sp, #0x190]
   21178:      	str	x2, [x5, #0xac0]
   2117c:      	ldr	x2, [sp, #0x190]
   21180:      	str	x0, [x2, #0x10]
   21184:      	ldr	x0, [sp, #0x190]
   21188:      	str	x1, [x0, #0x18]
   2118c:      	ldr	x0, [x19, #0x50c0]
   21190:      	ldr	x1, [sp, #0x190]
   21194:      	str	x0, [x1, #0x160]
   21198:      	ldr	x1, [x19, #0x50c8]
   2119c:      	ldr	x0, [sp, #0x190]
   211a0:      	str	x1, [x0, #0x168]
   211a4:      	ldr	x2, [x19, #0x50d0]
   211a8:      	ldr	x1, [sp, #0x190]
   211ac:      	str	x2, [x1, #0x170]
   211b0:      	ldr	x5, [x19, #0x50d8]
   211b4:      	ldr	x6, [sp, #0x190]
   211b8:      	str	x5, [x6, #0x178]
   211bc:      	ldr	x5, [x19, #0x50e0]
   211c0:      	ldr	x7, [sp, #0x190]
   211c4:      	str	x5, [x7, #0x180]
   211c8:      	ldr	x5, [x19, #0x50e8]
   211cc:      	ldr	x10, [sp, #0x190]
   211d0:      	str	x5, [x10, #0x188]
   211d4:      	ldr	x6, [x19, #0x50f0]
   211d8:      	ldr	x13, [sp, #0x190]
   211dc:      	str	x6, [x13, #0x190]
   211e0:      	ldr	x7, [x19, #0x50f8]
   211e4:      	str	x7, [x0, #0x198]
   211e8:      	ldr	x8, [x19, #0x5100]
   211ec:      	str	x8, [x0, #0x1a0]
   211f0:      	ldr	x9, [x19, #0x52a8]
   211f4:      	str	x9, [x0, #0x348]
   211f8:      	ldr	x10, [x19, #0x52b0]
   211fc:      	str	x10, [x0, #0x350]
   21200:      	ldr	x11, [x19, #0x52b8]
   21204:      	str	x11, [x0, #0x358]
   21208:      	ldr	x12, [x19, #0x52c0]
   2120c:      	str	x12, [x0, #0x360]
   21210:      	ldr	x13, [x19, #0x52c8]
   21214:      	str	x13, [x0, #0x368]
   21218:      	ldr	x14, [x19, #0x52d0]
   2121c:      	str	x14, [x0, #0x370]
   21220:      	ldr	x15, [x19, #0x52d8]
   21224:      	str	x15, [x0, #0x378]
   21228:      	ldr	x0, [x19, #0x52e0]
   2122c:      	str	x0, [x1, #0x380]
   21230:      	ldr	x0, [x19, #0x52e8]
   21234:      	str	x0, [x1, #0x388]
   21238:      	ldr	x0, [x19, #0x55d8]
   2123c:      	str	x0, [x1, #0x678]
   21240:      	ldr	x0, [x19, #0x55e0]
   21244:      	str	x0, [x1, #0x680]
   21248:      	ldr	x0, [x19, #0x55e8]
   2124c:      	str	x0, [x1, #0x688]
   21250:      	ldr	x0, [x19, #0x55f0]
   21254:      	str	x0, [x1, #0x690]
   21258:      	ldr	x0, [x19, #0x55f8]
   2125c:      	str	x0, [x1, #0x698]
   21260:      	ldr	x0, [x19, #0x5600]
   21264:      	str	x0, [x1, #0x6a0]
   21268:      	ldr	x0, [x19, #0x5608]
   2126c:      	ldr	x5, [sp, #0x190]
   21270:      	str	x0, [x5, #0x6a8]
   21274:      	ldr	x0, [x19, #0x5610]
   21278:      	ldr	x7, [sp, #0x190]
   2127c:      	str	x0, [x7, #0x6b0]
   21280:      	ldr	x0, [x19, #0x57a0]
   21284:      	ldr	x10, [sp, #0x190]
   21288:      	str	x0, [x10, #0x840]
   2128c:      	ldr	x0, [x19, #0x57a8]
   21290:      	ldr	x13, [sp, #0x190]
   21294:      	str	x0, [x13, #0x848]
   21298:      	ldr	x0, [x19, #0x57b0]
   2129c:      	str	x0, [x1, #0x850]
   212a0:      	ldr	x0, [x19, #0x57b8]
   212a4:      	str	x0, [x1, #0x858]
   212a8:      	ldr	x0, [x19, #0x57c0]
   212ac:      	str	x0, [x1, #0x860]
   212b0:      	ldr	x0, [x19, #0x57c8]
   212b4:      	str	x0, [x1, #0x868]
   212b8:      	ldr	x0, [x19, #0x57d0]
   212bc:      	str	x0, [x1, #0x870]
   212c0:      	ldr	x0, [x19, #0x57d8]
   212c4:      	str	x0, [x1, #0x878]
   212c8:      	ldr	x0, [x19, #0x5bb0]
   212cc:      	str	x0, [x1, #0xc50]
   212d0:      	ldr	x0, [x19, #0x5bb8]
   212d4:      	str	x0, [x1, #0xc58]
   212d8:      	ldr	x0, [x19, #0x5bc0]
   212dc:      	str	x0, [x1, #0xc60]
   212e0:      	ldr	x0, [x19, #0x5bc8]
   212e4:      	str	x0, [x1, #0xc68]
   212e8:      	ldr	x0, [x19, #0x5bd0]
   212ec:      	str	x0, [x1, #0xc70]
   212f0:      	ldr	x0, [x19, #0x5bd8]
   212f4:      	str	x0, [x1, #0xc78]
   212f8:      	mov	x0, #0x0                ; =0
   212fc:      	str	x0, [x1, #0xc80]
   21300:      	ldr	x1, [x19, #0x5be8]
   21304:      	ldr	x2, [sp, #0x190]
   21308:      	str	x1, [x2, #0xc88]
   2130c:      	ldr	x1, [x19, #0x5bf0]
   21310:      	str	x1, [x2, #0xc90]
   21314:      	ldr	x1, [sp, #0x190]
   21318:      	str	x0, [x1, #0xc98]
   2131c:      	ldr	x1, [x19, #0x5c00]
   21320:      	str	x1, [x2, #0xca0]
   21324:      	ldr	x1, [x19, #0x5c08]
   21328:      	str	x1, [x5, #0xca8]
   2132c:      	str	x0, [x5, #0xcb0]
   21330:      	ldr	x0, [x19, #0x5c18]
   21334:      	ldr	x8, [sp, #0x190]
   21338:      	str	x0, [x8, #0xcb8]
   2133c:      	ldr	x0, [x19, #0x5c20]
   21340:      	ldr	x11, [sp, #0x190]
   21344:      	str	x0, [x11, #0xcc0]
   21348:      	mov	x1, #0x605              ; =1541
   2134c:      	mov	x2, #-0x9               ; =-9
   21350:      	ldr	x21, [sp, #0x1a0]
   21354:      	ldur	x0, [sp, #0x8]
   21358:      	mov	x5, x20
   2135c:      	ldr	x6, [sp, #0x198]
   21360:      	blr	x21
   21364:      	cmp	x0, #0x0
   21368:      	b.ne	0x242bc <_mech_canonical_program_entry_v1_numeric_1282+0x613c>
   2136c:      	mov	x0, #0x3                ; =3
   21370:      	ldr	x7, [sp, #0x188]
   21374:      	mov	x21, x0
   21378:      	cmp	x7, #0x2
   2137c:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   21380:      	mov	x5, #0x0                ; =0
   21384:      	ldr	x3, [sp, #0x190]
   21388:      	str	x5, [x3]
   2138c:      	ldr	x0, [x19, #0x1cb8]
   21390:      	str	x0, [x3, #0x8]
   21394:      	mov	x1, #0x605              ; =1541
   21398:      	ldur	x0, [sp, #0x8]
   2139c:      	ldr	x6, [sp, #0x198]
   213a0:      	ldr	x21, [sp, #0x1a0]
   213a4:      	mov	x4, x20
   213a8:      	mov	x2, x5
   213ac:      	blr	x21
   213b0:      	cmp	x0, #0x0
   213b4:      	b.ne	0x242c4 <_mech_canonical_program_entry_v1_numeric_1282+0x6144>
   213b8:      	mov	x0, #0x3                ; =3
   213bc:      	mov	x21, x0
   213c0:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   213c4:      	ldr	x28, [sp, #0x110]
   213c8:      	sub	x0, x28, #0x1
   213cc:      	mov	x4, #0x0                ; =0
   213d0:      	cmp	x28, xzr
   213d4:      	csel	x4, x0, x4, ne
   213d8:      	cmp	x12, x4
   213dc:      	csel	x4, x12, x4, lo
   213e0:      	ldr	x28, [sp, #0x118]
   213e4:      	ldr	x14, [x28, x4, lsl #3]
   213e8:      	add	x25, x14, #0x1
   213ec:      	cmp	x25, x14
   213f0:      	b.lo	0x242cc <_mech_canonical_program_entry_v1_numeric_1282+0x614c>
   213f4:      	ldr	x28, [sp, #0x100]
   213f8:      	cmp	x14, x28
   213fc:      	b.lo	0x2168c <_mech_canonical_program_entry_v1_numeric_1282+0x350c>
   21400:      	b	0x24404 <_mech_canonical_program_entry_v1_numeric_1282+0x6284>
   21404:      	ldr	x3, [x19, #0x4c68]
   21408:      	ldr	x4, [x19, #0x4c70]
   2140c:      	mov	x0, #0x0                ; =0
   21410:      	str	x0, [x19, #0x4c60]
   21414:      	mov	x0, #0x3                ; =3
   21418:      	ldr	x7, [sp, #0x188]
   2141c:      	mov	x21, x0
   21420:      	cmp	x7, #0x19a
   21424:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   21428:      	ldr	x0, [x19, #0x4f70]
   2142c:      	ldr	x12, [sp, #0x190]
   21430:      	str	x0, [x12, #0x10]
   21434:      	ldr	x1, [x19, #0x4f78]
   21438:      	ldr	x15, [sp, #0x190]
   2143c:      	str	x1, [x15, #0x18]
   21440:      	ldr	x2, [x19, #0x5a20]
   21444:      	ldr	x5, [sp, #0x190]
   21448:      	str	x2, [x5, #0xac0]
   2144c:      	ldr	x2, [sp, #0x190]
   21450:      	str	x0, [x2, #0x10]
   21454:      	ldr	x0, [sp, #0x190]
   21458:      	str	x1, [x0, #0x18]
   2145c:      	ldr	x0, [x19, #0x50c0]
   21460:      	ldr	x1, [sp, #0x190]
   21464:      	str	x0, [x1, #0x160]
   21468:      	ldr	x0, [x19, #0x50c8]
   2146c:      	str	x0, [x1, #0x168]
   21470:      	ldr	x0, [x19, #0x50d0]
   21474:      	str	x0, [x1, #0x170]
   21478:      	ldr	x0, [x19, #0x50d8]
   2147c:      	str	x0, [x1, #0x178]
   21480:      	ldr	x0, [x19, #0x50e0]
   21484:      	str	x0, [x1, #0x180]
   21488:      	ldr	x0, [x19, #0x50e8]
   2148c:      	str	x0, [x1, #0x188]
   21490:      	ldr	x0, [x19, #0x50f0]
   21494:      	str	x0, [x1, #0x190]
   21498:      	ldr	x0, [x19, #0x50f8]
   2149c:      	str	x0, [x1, #0x198]
   214a0:      	ldr	x0, [x19, #0x5100]
   214a4:      	str	x0, [x1, #0x1a0]
   214a8:      	ldr	x0, [x19, #0x52a8]
   214ac:      	str	x0, [x1, #0x348]
   214b0:      	ldr	x0, [x19, #0x52b0]
   214b4:      	str	x0, [x1, #0x350]
   214b8:      	ldr	x0, [x19, #0x52b8]
   214bc:      	str	x0, [x1, #0x358]
   214c0:      	ldr	x0, [x19, #0x52c0]
   214c4:      	str	x0, [x1, #0x360]
   214c8:      	ldr	x0, [x19, #0x52c8]
   214cc:      	str	x0, [x1, #0x368]
   214d0:      	ldr	x0, [x19, #0x52d0]
   214d4:      	str	x0, [x5, #0x370]
   214d8:      	ldr	x0, [x19, #0x52d8]
   214dc:      	ldr	x7, [sp, #0x190]
   214e0:      	str	x0, [x7, #0x378]
   214e4:      	ldr	x1, [x19, #0x52e0]
   214e8:      	ldr	x10, [sp, #0x190]
   214ec:      	str	x1, [x10, #0x380]
   214f0:      	ldr	x2, [x19, #0x52e8]
   214f4:      	ldr	x13, [sp, #0x190]
   214f8:      	str	x2, [x13, #0x388]
   214fc:      	ldr	x5, [x19, #0x55d8]
   21500:      	ldr	x0, [sp, #0x190]
   21504:      	str	x5, [x0, #0x678]
   21508:      	ldr	x5, [x19, #0x55e0]
   2150c:      	str	x5, [x0, #0x680]
   21510:      	ldr	x5, [x19, #0x55e8]
   21514:      	str	x5, [x0, #0x688]
   21518:      	ldr	x6, [x19, #0x55f0]
   2151c:      	str	x6, [x0, #0x690]
   21520:      	ldr	x7, [x19, #0x55f8]
   21524:      	str	x7, [x0, #0x698]
   21528:      	ldr	x8, [x19, #0x5600]
   2152c:      	str	x8, [x0, #0x6a0]
   21530:      	ldr	x9, [x19, #0x5608]
   21534:      	str	x9, [x0, #0x6a8]
   21538:      	ldr	x10, [x19, #0x5610]
   2153c:      	str	x10, [x0, #0x6b0]
   21540:      	ldr	x11, [x19, #0x57a0]
   21544:      	str	x11, [x0, #0x840]
   21548:      	ldr	x12, [x19, #0x57a8]
   2154c:      	str	x12, [x0, #0x848]
   21550:      	ldr	x13, [x19, #0x57b0]
   21554:      	str	x13, [x0, #0x850]
   21558:      	ldr	x14, [x19, #0x57b8]
   2155c:      	str	x14, [x0, #0x858]
   21560:      	ldr	x15, [x19, #0x57c0]
   21564:      	str	x15, [x0, #0x860]
   21568:      	ldr	x0, [x19, #0x57c8]
   2156c:      	ldr	x1, [sp, #0x190]
   21570:      	str	x0, [x1, #0x868]
   21574:      	ldr	x0, [x19, #0x57d0]
   21578:      	str	x0, [x1, #0x870]
   2157c:      	ldr	x0, [x19, #0x57d8]
   21580:      	str	x0, [x1, #0x878]
   21584:      	ldr	x0, [x19, #0x5bb0]
   21588:      	str	x0, [x1, #0xc50]
   2158c:      	ldr	x0, [x19, #0x5bb8]
   21590:      	ldr	x5, [sp, #0x190]
   21594:      	str	x0, [x5, #0xc58]
   21598:      	ldr	x0, [x19, #0x5bc0]
   2159c:      	ldr	x7, [sp, #0x190]
   215a0:      	str	x0, [x7, #0xc60]
   215a4:      	ldr	x0, [x19, #0x5bc8]
   215a8:      	ldr	x10, [sp, #0x190]
   215ac:      	str	x0, [x10, #0xc68]
   215b0:      	ldr	x0, [x19, #0x5bd0]
   215b4:      	ldr	x13, [sp, #0x190]
   215b8:      	str	x0, [x13, #0xc70]
   215bc:      	ldr	x0, [x19, #0x5bd8]
   215c0:      	str	x0, [x1, #0xc78]
   215c4:      	mov	x0, #0x0                ; =0
   215c8:      	str	x0, [x1, #0xc80]
   215cc:      	ldr	x1, [x19, #0x5be8]
   215d0:      	ldr	x2, [sp, #0x190]
   215d4:      	str	x1, [x2, #0xc88]
   215d8:      	ldr	x1, [x19, #0x5bf0]
   215dc:      	str	x1, [x2, #0xc90]
   215e0:      	ldr	x1, [sp, #0x190]
   215e4:      	str	x0, [x1, #0xc98]
   215e8:      	ldr	x1, [x19, #0x5c00]
   215ec:      	str	x1, [x2, #0xca0]
   215f0:      	ldr	x1, [x19, #0x5c08]
   215f4:      	str	x1, [x2, #0xca8]
   215f8:      	ldr	x1, [sp, #0x190]
   215fc:      	str	x0, [x1, #0xcb0]
   21600:      	ldr	x0, [x19, #0x5c18]
   21604:      	str	x0, [x1, #0xcb8]
   21608:      	ldr	x0, [x19, #0x5c20]
   2160c:      	str	x0, [x1, #0xcc0]
   21610:      	mov	x1, #0x607              ; =1543
   21614:      	mov	x2, #-0x9               ; =-9
   21618:      	ldr	x21, [sp, #0x1a0]
   2161c:      	ldur	x0, [sp, #0x8]
   21620:      	mov	x5, x20
   21624:      	ldr	x6, [sp, #0x198]
   21628:      	blr	x21
   2162c:      	cmp	x0, #0x0
   21630:      	b.ne	0x24580 <_mech_canonical_program_entry_v1_numeric_1282+0x6400>
   21634:      	mov	x0, #0x3                ; =3
   21638:      	ldr	x7, [sp, #0x188]
   2163c:      	mov	x21, x0
   21640:      	cmp	x7, #0x2
   21644:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   21648:      	mov	x5, #0x0                ; =0
   2164c:      	ldr	x3, [sp, #0x190]
   21650:      	str	x5, [x3]
   21654:      	ldr	x0, [x19, #0x1cc8]
   21658:      	str	x0, [x3, #0x8]
   2165c:      	mov	x1, #0x607              ; =1543
   21660:      	ldur	x0, [sp, #0x8]
   21664:      	ldr	x6, [sp, #0x198]
   21668:      	ldr	x21, [sp, #0x1a0]
   2166c:      	mov	x4, x20
   21670:      	mov	x2, x5
   21674:      	blr	x21
   21678:      	cmp	x0, #0x0
   2167c:      	b.ne	0x24588 <_mech_canonical_program_entry_v1_numeric_1282+0x6408>
   21680:      	mov	x0, #0x3                ; =3
   21684:      	mov	x21, x0
   21688:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   2168c:      	ldr	x28, [sp, #0x100]
   21690:      	cmp	x25, x28
   21694:      	b.lo	0x21928 <_mech_canonical_program_entry_v1_numeric_1282+0x37a8>
   21698:      	b	0x24590 <_mech_canonical_program_entry_v1_numeric_1282+0x6410>
   2169c:      	ldr	x3, [x19, #0x4c68]
   216a0:      	ldr	x4, [x19, #0x4c70]
   216a4:      	mov	x0, #0x0                ; =0
   216a8:      	str	x0, [x19, #0x4c60]
   216ac:      	mov	x0, #0x3                ; =3
   216b0:      	ldr	x7, [sp, #0x188]
   216b4:      	mov	x21, x0
   216b8:      	cmp	x7, #0x19a
   216bc:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   216c0:      	ldr	x0, [x19, #0x4f70]
   216c4:      	ldr	x1, [sp, #0x190]
   216c8:      	str	x0, [x1, #0x10]
   216cc:      	ldr	x1, [x19, #0x4f78]
   216d0:      	ldr	x2, [sp, #0x190]
   216d4:      	str	x1, [x2, #0x18]
   216d8:      	ldr	x2, [x19, #0x5a20]
   216dc:      	ldr	x5, [sp, #0x190]
   216e0:      	str	x2, [x5, #0xac0]
   216e4:      	ldr	x2, [sp, #0x190]
   216e8:      	str	x0, [x2, #0x10]
   216ec:      	ldr	x0, [sp, #0x190]
   216f0:      	str	x1, [x0, #0x18]
   216f4:      	ldr	x0, [x19, #0x50c0]
   216f8:      	ldr	x1, [sp, #0x190]
   216fc:      	str	x0, [x1, #0x160]
   21700:      	ldr	x0, [x19, #0x50c8]
   21704:      	str	x0, [x1, #0x168]
   21708:      	ldr	x0, [x19, #0x50d0]
   2170c:      	str	x0, [x1, #0x170]
   21710:      	ldr	x0, [x19, #0x50d8]
   21714:      	str	x0, [x1, #0x178]
   21718:      	ldr	x0, [x19, #0x50e0]
   2171c:      	str	x0, [x2, #0x180]
   21720:      	ldr	x0, [x19, #0x50e8]
   21724:      	str	x0, [x5, #0x188]
   21728:      	ldr	x0, [x19, #0x50f0]
   2172c:      	ldr	x8, [sp, #0x190]
   21730:      	str	x0, [x8, #0x190]
   21734:      	ldr	x0, [x19, #0x50f8]
   21738:      	ldr	x11, [sp, #0x190]
   2173c:      	str	x0, [x11, #0x198]
   21740:      	ldr	x0, [x19, #0x5100]
   21744:      	ldr	x14, [sp, #0x190]
   21748:      	str	x0, [x14, #0x1a0]
   2174c:      	ldr	x0, [x19, #0x52a8]
   21750:      	str	x0, [x1, #0x348]
   21754:      	ldr	x1, [x19, #0x52b0]
   21758:      	ldr	x0, [sp, #0x190]
   2175c:      	str	x1, [x0, #0x350]
   21760:      	ldr	x2, [x19, #0x52b8]
   21764:      	str	x2, [x0, #0x358]
   21768:      	ldr	x5, [x19, #0x52c0]
   2176c:      	str	x5, [x0, #0x360]
   21770:      	ldr	x5, [x19, #0x52c8]
   21774:      	str	x5, [x0, #0x368]
   21778:      	ldr	x5, [x19, #0x52d0]
   2177c:      	str	x5, [x0, #0x370]
   21780:      	ldr	x6, [x19, #0x52d8]
   21784:      	str	x6, [x0, #0x378]
   21788:      	ldr	x7, [x19, #0x52e0]
   2178c:      	str	x7, [x0, #0x380]
   21790:      	ldr	x8, [x19, #0x52e8]
   21794:      	str	x8, [x0, #0x388]
   21798:      	ldr	x9, [x19, #0x55d8]
   2179c:      	str	x9, [x0, #0x678]
   217a0:      	ldr	x10, [x19, #0x55e0]
   217a4:      	str	x10, [x0, #0x680]
   217a8:      	ldr	x11, [x19, #0x55e8]
   217ac:      	str	x11, [x0, #0x688]
   217b0:      	ldr	x12, [x19, #0x55f0]
   217b4:      	str	x12, [x0, #0x690]
   217b8:      	ldr	x13, [x19, #0x55f8]
   217bc:      	str	x13, [x0, #0x698]
   217c0:      	ldr	x14, [x19, #0x5600]
   217c4:      	str	x14, [x0, #0x6a0]
   217c8:      	ldr	x15, [x19, #0x5608]
   217cc:      	str	x15, [x0, #0x6a8]
   217d0:      	ldr	x0, [x19, #0x5610]
   217d4:      	ldr	x2, [sp, #0x190]
   217d8:      	str	x0, [x2, #0x6b0]
   217dc:      	ldr	x0, [x19, #0x57a0]
   217e0:      	ldr	x5, [sp, #0x190]
   217e4:      	str	x0, [x5, #0x840]
   217e8:      	ldr	x0, [x19, #0x57a8]
   217ec:      	ldr	x8, [sp, #0x190]
   217f0:      	str	x0, [x8, #0x848]
   217f4:      	ldr	x0, [x19, #0x57b0]
   217f8:      	ldr	x11, [sp, #0x190]
   217fc:      	str	x0, [x11, #0x850]
   21800:      	ldr	x0, [x19, #0x57b8]
   21804:      	ldr	x14, [sp, #0x190]
   21808:      	str	x0, [x14, #0x858]
   2180c:      	ldr	x0, [x19, #0x57c0]
   21810:      	ldr	x1, [sp, #0x190]
   21814:      	str	x0, [x1, #0x860]
   21818:      	ldr	x0, [x19, #0x57c8]
   2181c:      	str	x0, [x1, #0x868]
   21820:      	ldr	x0, [x19, #0x57d0]
   21824:      	str	x0, [x1, #0x870]
   21828:      	ldr	x0, [x19, #0x57d8]
   2182c:      	str	x0, [x1, #0x878]
   21830:      	ldr	x0, [x19, #0x5bb0]
   21834:      	str	x0, [x1, #0xc50]
   21838:      	ldr	x0, [x19, #0x5bb8]
   2183c:      	str	x0, [x1, #0xc58]
   21840:      	ldr	x0, [x19, #0x5bc0]
   21844:      	str	x0, [x1, #0xc60]
   21848:      	ldr	x0, [x19, #0x5bc8]
   2184c:      	str	x0, [x1, #0xc68]
   21850:      	ldr	x0, [x19, #0x5bd0]
   21854:      	str	x0, [x1, #0xc70]
   21858:      	ldr	x0, [x19, #0x5bd8]
   2185c:      	str	x0, [x1, #0xc78]
   21860:      	mov	x0, #0x0                ; =0
   21864:      	str	x0, [x1, #0xc80]
   21868:      	ldr	x1, [x19, #0x5be8]
   2186c:      	str	x1, [x2, #0xc88]
   21870:      	ldr	x1, [x19, #0x5bf0]
   21874:      	str	x1, [x2, #0xc90]
   21878:      	ldr	x1, [sp, #0x190]
   2187c:      	str	x0, [x1, #0xc98]
   21880:      	ldr	x1, [x19, #0x5c00]
   21884:      	str	x1, [x2, #0xca0]
   21888:      	ldr	x1, [x19, #0x5c08]
   2188c:      	str	x1, [x2, #0xca8]
   21890:      	ldr	x1, [sp, #0x190]
   21894:      	str	x0, [x1, #0xcb0]
   21898:      	ldr	x0, [x19, #0x5c18]
   2189c:      	str	x0, [x5, #0xcb8]
   218a0:      	ldr	x0, [x19, #0x5c20]
   218a4:      	ldr	x6, [sp, #0x190]
   218a8:      	str	x0, [x6, #0xcc0]
   218ac:      	mov	x1, #0x609              ; =1545
   218b0:      	mov	x2, #-0x9               ; =-9
   218b4:      	ldr	x21, [sp, #0x1a0]
   218b8:      	ldur	x0, [sp, #0x8]
   218bc:      	mov	x5, x20
   218c0:      	ldr	x6, [sp, #0x198]
   218c4:      	blr	x21
   218c8:      	cmp	x0, #0x0
   218cc:      	b.ne	0x24730 <_mech_canonical_program_entry_v1_numeric_1282+0x65b0>
   218d0:      	mov	x0, #0x3                ; =3
   218d4:      	ldr	x7, [sp, #0x188]
   218d8:      	mov	x21, x0
   218dc:      	cmp	x7, #0x2
   218e0:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   218e4:      	mov	x5, #0x0                ; =0
   218e8:      	ldr	x3, [sp, #0x190]
   218ec:      	str	x5, [x3]
   218f0:      	ldr	x0, [x19, #0x1cd8]
   218f4:      	str	x0, [x3, #0x8]
   218f8:      	mov	x1, #0x609              ; =1545
   218fc:      	ldur	x0, [sp, #0x8]
   21900:      	ldr	x6, [sp, #0x198]
   21904:      	ldr	x21, [sp, #0x1a0]
   21908:      	mov	x4, x20
   2190c:      	mov	x2, x5
   21910:      	blr	x21
   21914:      	cmp	x0, #0x0
   21918:      	b.ne	0x24738 <_mech_canonical_program_entry_v1_numeric_1282+0x65b8>
   2191c:      	mov	x0, #0x3                ; =3
   21920:      	mov	x21, x0
   21924:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   21928:      	mov	w0, #0x2646             ; =9798
   2192c:      	movk	w0, #0x1, lsl #16
   21930:      	sub	x2, x3, x0
   21934:      	ldr	x28, [sp, #0x100]
   21938:      	sub	x0, x28, #0x1
   2193c:      	mov	x4, #0x0                ; =0
   21940:      	stur	x4, [sp, #0x40]
   21944:      	cmp	x28, xzr
   21948:      	csel	x7, x0, x4, ne
   2194c:      	cmp	x14, x7
   21950:      	csel	x0, x14, x7, lo
   21954:      	ldr	x28, [sp, #0x108]
   21958:      	ldr	x3, [x28, x0, lsl #3]
   2195c:      	ldur	x0, [sp, #0x60]
   21960:      	ldur	x14, [sp, #0x10]
   21964:      	ldur	x15, [sp, #0x50]
   21968:      	ldur	x26, [sp, #0x58]
   2196c:      	ldur	x28, [sp, #0x68]
   21970:      	mov	w4, #0xcb86             ; =52102
   21974:      	movk	w4, #0x2, lsl #16
   21978:      	cmp	x2, x4
   2197c:      	cset	x4, hs
   21980:      	ldur	x5, [sp, #0xe8]
   21984:      	and	w4, w4, w5
   21988:      	uxtb	w4, w4
   2198c:      	cbnz	x4, 0x21d9c <_mech_canonical_program_entry_v1_numeric_1282+0x3c1c>
   21990:      	mov	x13, #0x0               ; =0
   21994:      	str	x13, [x19, #0x18]
   21998:      	str	x1, [x19, #0x20]
   2199c:      	mov	x5, #0x1                ; =1
   219a0:      	str	x5, [x19, #0x30]
   219a4:      	mov	x6, #0x101010101010101  ; =72340172838076673
   219a8:      	str	x6, [x19, #0x38]
   219ac:      	mov	x20, #0x2               ; =2
   219b0:      	str	x20, [x19, #0x40]
   219b4:      	mov	x8, #0x3                ; =3
   219b8:      	str	x8, [x19, #0x48]
   219bc:      	mov	x8, #0x4                ; =4
   219c0:      	str	x8, [x19, #0x50]
   219c4:      	mov	x1, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   219c8:      	str	x1, [x19, #0x78]
   219cc:      	mov	x1, #0x3333333333333333 ; =3689348814741910323
   219d0:      	str	x1, [x19, #0x88]
   219d4:      	mov	x1, #0x38               ; =56
   219d8:      	str	x1, [x19, #0x90]
   219dc:      	mov	x1, #0x3a               ; =58
   219e0:      	str	x1, [x19, #0x98]
   219e4:      	mov	x1, #0x5555555555555555 ; =6148914691236517205
   219e8:      	str	x1, [x19, #0xb0]
   219ec:      	mov	x1, #0x3ffffffffffffff  ; =288230376151711743
   219f0:      	str	x1, [x19, #0xb8]
   219f4:      	str	x13, [x19, #0x188]
   219f8:      	str	x5, [x19, #0x190]
   219fc:      	str	x22, [x19, #0x17a0]
   21a00:      	ldr	x8, [sp, #0x180]
   21a04:      	str	x8, [x19, #0x17a8]
   21a08:      	ldur	x24, [sp, #0xe0]
   21a0c:      	uxtb	w1, w24
   21a10:      	str	x1, [x19, #0x17b8]
   21a14:      	str	x12, [x19, #0x1c70]
   21a18:      	str	x9, [x19, #0x1c78]
   21a1c:      	str	x22, [x19, #0x1c80]
   21a20:      	str	x10, [x19, #0x1ca8]
   21a24:      	ldur	x23, [sp, #0x78]
   21a28:      	str	x23, [x19, #0x4c60]
   21a2c:      	str	x2, [x19, #0x4c68]
   21a30:      	ldur	x4, [sp, #0x80]
   21a34:      	str	x4, [x19, #0x4c70]
   21a38:      	str	x22, [x19, #0x4f70]
   21a3c:      	ldr	x1, [sp, #0x180]
   21a40:      	str	x1, [x19, #0x4f78]
   21a44:      	str	x12, [x19, #0x55d8]
   21a48:      	str	x9, [x19, #0x55e0]
   21a4c:      	str	x22, [x19, #0x55e8]
   21a50:      	ldur	x10, [sp, #0x10]
   21a54:      	str	x10, [x19, #0x55f0]
   21a58:      	ldur	x1, [sp, #0x50]
   21a5c:      	str	x1, [x19, #0x55f8]
   21a60:      	ldur	x1, [sp, #0x58]
   21a64:      	str	x1, [x19, #0x5600]
   21a68:      	ldur	x1, [sp, #0x60]
   21a6c:      	str	x1, [x19, #0x5608]
   21a70:      	ldur	x1, [sp, #0x68]
   21a74:      	str	x1, [x19, #0x5610]
   21a78:      	str	x10, [x19, #0x5680]
   21a7c:      	ldur	x1, [sp, #0x50]
   21a80:      	str	x1, [x19, #0x5688]
   21a84:      	ldur	x1, [sp, #0x58]
   21a88:      	str	x1, [x19, #0x5690]
   21a8c:      	ldur	x1, [sp, #0x60]
   21a90:      	str	x1, [x19, #0x5698]
   21a94:      	ldur	x1, [sp, #0x68]
   21a98:      	str	x1, [x19, #0x56a0]
   21a9c:      	str	x3, [x19, #0x57a0]
   21aa0:      	cmp	x25, x7
   21aa4:      	csel	x1, x25, x7, lo
   21aa8:      	ldr	x3, [sp, #0x108]
   21aac:      	ldr	x1, [x3, x1, lsl #3]
   21ab0:      	str	x1, [x19, #0x57a8]
   21ab4:      	str	x22, [x19, #0x57b0]
   21ab8:      	str	x14, [x19, #0x57b8]
   21abc:      	str	x15, [x19, #0x57c0]
   21ac0:      	str	x26, [x19, #0x57c8]
   21ac4:      	str	x0, [x19, #0x57d0]
   21ac8:      	str	x28, [x19, #0x57d8]
   21acc:      	ldur	x0, [sp, #0x48]
   21ad0:      	str	x0, [x19, #0x5a20]
   21ad4:      	add	x0, x11, #0x1
   21ad8:      	str	x0, [x19, #0x5bb0]
   21adc:      	ldur	x25, [sp, #0x88]
   21ae0:      	str	x25, [x19, #0x5bb8]
   21ae4:      	ldur	x3, [sp, #0x90]
   21ae8:      	str	x3, [x19, #0x5bc0]
   21aec:      	ldur	x1, [sp, #0x70]
   21af0:      	sub	x1, x1, x2
   21af4:      	mov	w2, #0xc87e             ; =51326
   21af8:      	movk	w2, #0x1, lsl #16
   21afc:      	msub	x0, x0, x2, x1
   21b00:      	str	x0, [x19, #0x5bc8]
   21b04:      	str	x13, [x19, #0x5bd0]
   21b08:      	str	x13, [x19, #0x5bd8]
   21b0c:      	ldur	x23, [sp, #0x98]
   21b10:      	str	x23, [x19, #0x5be8]
   21b14:      	ldur	x6, [sp, #0xa0]
   21b18:      	str	x6, [x19, #0x5bf0]
   21b1c:      	str	x5, [x19, #0x5c00]
   21b20:      	ldur	x14, [sp, #0x38]
   21b24:      	str	x14, [x19, #0x5c08]
   21b28:      	str	x5, [x19, #0x5c18]
   21b2c:      	ldur	x7, [sp, #0x40]
   21b30:      	str	x7, [x19, #0x5c20]
   21b34:      	ldr	x1, [x19, #0x4c60]
   21b38:      	cmp	x1, #0x0
   21b3c:      	b.eq	0x21d74 <_mech_canonical_program_entry_v1_numeric_1282+0x3bf4>
   21b40:      	ldr	x3, [x19, #0x4c68]
   21b44:      	ldr	x4, [x19, #0x4c70]
   21b48:      	mov	x5, #0x0                ; =0
   21b4c:      	str	x5, [x19, #0x4c60]
   21b50:      	mov	x0, #0x3                ; =3
   21b54:      	ldr	x7, [sp, #0x188]
   21b58:      	mov	x21, x0
   21b5c:      	cmp	x7, #0x19a
   21b60:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   21b64:      	ldr	x8, [x19, #0x4f70]
   21b68:      	ldr	x0, [sp, #0x190]
   21b6c:      	str	x8, [x0, #0x10]
   21b70:      	ldr	x9, [x19, #0x4f78]
   21b74:      	str	x9, [x0, #0x18]
   21b78:      	ldr	x10, [x19, #0x5a20]
   21b7c:      	str	x10, [x0, #0xac0]
   21b80:      	ldr	x11, [x19, #0x5680]
   21b84:      	str	x11, [x0, #0x720]
   21b88:      	ldr	x12, [x19, #0x5688]
   21b8c:      	str	x12, [x0, #0x728]
   21b90:      	ldr	x13, [x19, #0x5690]
   21b94:      	str	x13, [x0, #0x730]
   21b98:      	ldr	x14, [x19, #0x5698]
   21b9c:      	str	x14, [x0, #0x738]
   21ba0:      	ldr	x15, [x19, #0x56a0]
   21ba4:      	str	x15, [x0, #0x740]
   21ba8:      	str	x8, [x0, #0x10]
   21bac:      	str	x9, [x0, #0x18]
   21bb0:      	ldr	x0, [x19, #0x50c0]
   21bb4:      	ldr	x1, [sp, #0x190]
   21bb8:      	str	x0, [x1, #0x160]
   21bbc:      	ldr	x0, [x19, #0x50c8]
   21bc0:      	str	x0, [x1, #0x168]
   21bc4:      	ldr	x0, [x19, #0x50d0]
   21bc8:      	str	x0, [x1, #0x170]
   21bcc:      	ldr	x0, [x19, #0x50d8]
   21bd0:      	str	x0, [x1, #0x178]
   21bd4:      	ldr	x0, [x19, #0x50e0]
   21bd8:      	ldr	x5, [sp, #0x190]
   21bdc:      	str	x0, [x5, #0x180]
   21be0:      	ldr	x0, [x19, #0x50e8]
   21be4:      	ldr	x7, [sp, #0x190]
   21be8:      	str	x0, [x7, #0x188]
   21bec:      	ldr	x0, [x19, #0x50f0]
   21bf0:      	ldr	x10, [sp, #0x190]
   21bf4:      	str	x0, [x10, #0x190]
   21bf8:      	ldr	x0, [x19, #0x50f8]
   21bfc:      	ldr	x13, [sp, #0x190]
   21c00:      	str	x0, [x13, #0x198]
   21c04:      	ldr	x0, [x19, #0x5100]
   21c08:      	str	x0, [x1, #0x1a0]
   21c0c:      	ldr	x0, [x19, #0x52a8]
   21c10:      	str	x0, [x1, #0x348]
   21c14:      	ldr	x0, [x19, #0x52b0]
   21c18:      	str	x0, [x1, #0x350]
   21c1c:      	ldr	x0, [x19, #0x52b8]
   21c20:      	str	x0, [x1, #0x358]
   21c24:      	ldr	x0, [x19, #0x52c0]
   21c28:      	str	x0, [x1, #0x360]
   21c2c:      	ldr	x0, [x19, #0x52c8]
   21c30:      	str	x0, [x1, #0x368]
   21c34:      	ldr	x0, [x19, #0x52d0]
   21c38:      	str	x0, [x1, #0x370]
   21c3c:      	ldr	x0, [x19, #0x52d8]
   21c40:      	str	x0, [x1, #0x378]
   21c44:      	ldr	x0, [x19, #0x52e0]
   21c48:      	str	x0, [x1, #0x380]
   21c4c:      	ldr	x0, [x19, #0x52e8]
   21c50:      	str	x0, [x1, #0x388]
   21c54:      	ldr	x0, [x19, #0x55d8]
   21c58:      	str	x0, [x1, #0x678]
   21c5c:      	ldr	x0, [x19, #0x55e0]
   21c60:      	str	x0, [x1, #0x680]
   21c64:      	ldr	x0, [x19, #0x55e8]
   21c68:      	str	x0, [x1, #0x688]
   21c6c:      	ldr	x0, [x19, #0x55f0]
   21c70:      	str	x0, [x1, #0x690]
   21c74:      	ldr	x0, [x19, #0x55f8]
   21c78:      	str	x0, [x1, #0x698]
   21c7c:      	ldr	x0, [x19, #0x5600]
   21c80:      	str	x0, [x1, #0x6a0]
   21c84:      	ldr	x0, [x19, #0x5608]
   21c88:      	str	x0, [x1, #0x6a8]
   21c8c:      	ldr	x0, [x19, #0x5610]
   21c90:      	str	x0, [x5, #0x6b0]
   21c94:      	ldr	x0, [x19, #0x57a0]
   21c98:      	str	x0, [x7, #0x840]
   21c9c:      	ldr	x0, [x19, #0x57a8]
   21ca0:      	str	x0, [x10, #0x848]
   21ca4:      	ldr	x0, [x19, #0x57b0]
   21ca8:      	str	x0, [x13, #0x850]
   21cac:      	ldr	x0, [x19, #0x57b8]
   21cb0:      	str	x0, [x1, #0x858]
   21cb4:      	ldr	x0, [x19, #0x57c0]
   21cb8:      	str	x0, [x1, #0x860]
   21cbc:      	ldr	x0, [x19, #0x57c8]
   21cc0:      	str	x0, [x1, #0x868]
   21cc4:      	ldr	x0, [x19, #0x57d0]
   21cc8:      	str	x0, [x1, #0x870]
   21ccc:      	ldr	x0, [x19, #0x57d8]
   21cd0:      	str	x0, [x1, #0x878]
   21cd4:      	ldr	x0, [x19, #0x5bb0]
   21cd8:      	str	x0, [x1, #0xc50]
   21cdc:      	ldr	x0, [x19, #0x5bb8]
   21ce0:      	str	x0, [x1, #0xc58]
   21ce4:      	ldr	x0, [x19, #0x5bc0]
   21ce8:      	str	x0, [x1, #0xc60]
   21cec:      	ldr	x0, [x19, #0x5bc8]
   21cf0:      	str	x0, [x1, #0xc68]
   21cf4:      	ldr	x0, [x19, #0x5bd0]
   21cf8:      	str	x0, [x1, #0xc70]
   21cfc:      	ldr	x0, [x19, #0x5bd8]
   21d00:      	str	x0, [x1, #0xc78]
   21d04:      	mov	x0, #0x0                ; =0
   21d08:      	str	x0, [x1, #0xc80]
   21d0c:      	ldr	x1, [x19, #0x5be8]
   21d10:      	ldr	x2, [sp, #0x190]
   21d14:      	str	x1, [x2, #0xc88]
   21d18:      	ldr	x1, [x19, #0x5bf0]
   21d1c:      	str	x1, [x2, #0xc90]
   21d20:      	ldr	x1, [sp, #0x190]
   21d24:      	str	x0, [x1, #0xc98]
   21d28:      	ldr	x1, [x19, #0x5c00]
   21d2c:      	str	x1, [x2, #0xca0]
   21d30:      	ldr	x1, [x19, #0x5c08]
   21d34:      	str	x1, [x2, #0xca8]
   21d38:      	str	x0, [x2, #0xcb0]
   21d3c:      	ldr	x2, [x19, #0x5c18]
   21d40:      	str	x2, [x5, #0xcb8]
   21d44:      	ldr	x5, [x19, #0x5c20]
   21d48:      	ldr	x8, [sp, #0x190]
   21d4c:      	str	x5, [x8, #0xcc0]
   21d50:      	mov	x1, #0x611              ; =1553
   21d54:      	mov	x2, #-0x9               ; =-9
   21d58:      	mov	x5, #0x1                ; =1
   21d5c:      	ldur	x0, [sp, #0x8]
   21d60:      	ldr	x6, [sp, #0x198]
   21d64:      	ldr	x21, [sp, #0x1a0]
   21d68:      	blr	x21
   21d6c:      	cmp	x0, #0x0
   21d70:      	b.ne	0x24740 <_mech_canonical_program_entry_v1_numeric_1282+0x65c0>
   21d74:      	mov	x0, #0x0                ; =0
   21d78:      	mov	x1, #0x5                ; =5
   21d7c:      	add	sp, sp, #0x1b0
   21d80:      	ldp	x19, x20, [sp], #0x10
   21d84:      	ldp	x21, x22, [sp], #0x10
   21d88:      	ldp	x23, x24, [sp], #0x10
   21d8c:      	ldp	x25, x26, [sp], #0x10
   21d90:      	ldp	x27, x28, [sp], #0x10
   21d94:      	ldp	x29, x30, [sp], #0x10
   21d98:      	retab
   21d9c:      	cmp	x25, x7
   21da0:      	csel	x4, x25, x7, lo
   21da4:      	ldr	x5, [sp, #0x108]
   21da8:      	ldr	x5, [x5, x4, lsl #3]
   21dac:      	cmp	x3, x5
   21db0:      	cset	x13, lo
   21db4:      	cmp	x3, x5
   21db8:      	b.lo	0x21dc4 <_mech_canonical_program_entry_v1_numeric_1282+0x3c44>
   21dbc:      	mov	x8, #0x0                ; =0
   21dc0:      	b	0x22080 <_mech_canonical_program_entry_v1_numeric_1282+0x3f00>
   21dc4:      	ldur	x4, [sp, #0xf0]
   21dc8:      	cmp	x3, x4
   21dcc:      	b.lo	0x2205c <_mech_canonical_program_entry_v1_numeric_1282+0x3edc>
   21dd0:      	b	0x24748 <_mech_canonical_program_entry_v1_numeric_1282+0x65c8>
   21dd4:      	ldr	x3, [x19, #0x4c68]
   21dd8:      	ldr	x4, [x19, #0x4c70]
   21ddc:      	mov	x0, #0x0                ; =0
   21de0:      	str	x0, [x19, #0x4c60]
   21de4:      	mov	x0, #0x3                ; =3
   21de8:      	ldr	x7, [sp, #0x188]
   21dec:      	mov	x21, x0
   21df0:      	cmp	x7, #0x19a
   21df4:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   21df8:      	ldr	x0, [x19, #0x4f70]
   21dfc:      	ldr	x1, [sp, #0x190]
   21e00:      	str	x0, [x1, #0x10]
   21e04:      	ldr	x1, [x19, #0x4f78]
   21e08:      	ldr	x2, [sp, #0x190]
   21e0c:      	str	x1, [x2, #0x18]
   21e10:      	ldr	x2, [x19, #0x5a20]
   21e14:      	ldr	x5, [sp, #0x190]
   21e18:      	str	x2, [x5, #0xac0]
   21e1c:      	ldr	x2, [sp, #0x190]
   21e20:      	str	x0, [x2, #0x10]
   21e24:      	ldr	x0, [sp, #0x190]
   21e28:      	str	x1, [x0, #0x18]
   21e2c:      	ldr	x0, [x19, #0x50c0]
   21e30:      	ldr	x1, [sp, #0x190]
   21e34:      	str	x0, [x1, #0x160]
   21e38:      	ldr	x0, [x19, #0x50c8]
   21e3c:      	str	x0, [x1, #0x168]
   21e40:      	ldr	x0, [x19, #0x50d0]
   21e44:      	str	x0, [x1, #0x170]
   21e48:      	ldr	x0, [x19, #0x50d8]
   21e4c:      	str	x0, [x1, #0x178]
   21e50:      	ldr	x0, [x19, #0x50e0]
   21e54:      	str	x0, [x1, #0x180]
   21e58:      	ldr	x0, [x19, #0x50e8]
   21e5c:      	str	x0, [x1, #0x188]
   21e60:      	ldr	x0, [x19, #0x50f0]
   21e64:      	str	x0, [x1, #0x190]
   21e68:      	ldr	x0, [x19, #0x50f8]
   21e6c:      	str	x0, [x1, #0x198]
   21e70:      	ldr	x0, [x19, #0x5100]
   21e74:      	str	x0, [x1, #0x1a0]
   21e78:      	ldr	x0, [x19, #0x52a8]
   21e7c:      	str	x0, [x1, #0x348]
   21e80:      	ldr	x0, [x19, #0x52b0]
   21e84:      	str	x0, [x1, #0x350]
   21e88:      	ldr	x0, [x19, #0x52b8]
   21e8c:      	str	x0, [x2, #0x358]
   21e90:      	ldr	x0, [x19, #0x52c0]
   21e94:      	str	x0, [x5, #0x360]
   21e98:      	ldr	x0, [x19, #0x52c8]
   21e9c:      	ldr	x8, [sp, #0x190]
   21ea0:      	str	x0, [x8, #0x368]
   21ea4:      	ldr	x0, [x19, #0x52d0]
   21ea8:      	ldr	x11, [sp, #0x190]
   21eac:      	str	x0, [x11, #0x370]
   21eb0:      	ldr	x0, [x19, #0x52d8]
   21eb4:      	ldr	x14, [sp, #0x190]
   21eb8:      	str	x0, [x14, #0x378]
   21ebc:      	ldr	x0, [x19, #0x52e0]
   21ec0:      	str	x0, [x1, #0x380]
   21ec4:      	ldr	x0, [x19, #0x52e8]
   21ec8:      	str	x0, [x1, #0x388]
   21ecc:      	ldr	x0, [x19, #0x55d8]
   21ed0:      	str	x0, [x1, #0x678]
   21ed4:      	ldr	x0, [x19, #0x55e0]
   21ed8:      	str	x0, [x1, #0x680]
   21edc:      	ldr	x0, [x19, #0x55e8]
   21ee0:      	str	x0, [x1, #0x688]
   21ee4:      	ldr	x0, [x19, #0x55f0]
   21ee8:      	str	x0, [x1, #0x690]
   21eec:      	ldr	x0, [x19, #0x55f8]
   21ef0:      	str	x0, [x1, #0x698]
   21ef4:      	ldr	x1, [x19, #0x5600]
   21ef8:      	ldr	x0, [sp, #0x190]
   21efc:      	str	x1, [x0, #0x6a0]
   21f00:      	ldr	x2, [x19, #0x5608]
   21f04:      	str	x2, [x0, #0x6a8]
   21f08:      	ldr	x5, [x19, #0x5610]
   21f0c:      	str	x5, [x0, #0x6b0]
   21f10:      	ldr	x5, [x19, #0x57a0]
   21f14:      	str	x5, [x0, #0x840]
   21f18:      	ldr	x5, [x19, #0x57a8]
   21f1c:      	str	x5, [x0, #0x848]
   21f20:      	ldr	x6, [x19, #0x57b0]
   21f24:      	str	x6, [x0, #0x850]
   21f28:      	ldr	x7, [x19, #0x57b8]
   21f2c:      	str	x7, [x0, #0x858]
   21f30:      	ldr	x8, [x19, #0x57c0]
   21f34:      	str	x8, [x0, #0x860]
   21f38:      	ldr	x9, [x19, #0x57c8]
   21f3c:      	str	x9, [x0, #0x868]
   21f40:      	ldr	x10, [x19, #0x57d0]
   21f44:      	ldr	x2, [sp, #0x190]
   21f48:      	str	x10, [x2, #0x870]
   21f4c:      	ldr	x11, [x19, #0x57d8]
   21f50:      	ldr	x5, [sp, #0x190]
   21f54:      	str	x11, [x5, #0x878]
   21f58:      	ldr	x12, [x19, #0x5bb0]
   21f5c:      	ldr	x8, [sp, #0x190]
   21f60:      	str	x12, [x8, #0xc50]
   21f64:      	ldr	x13, [x19, #0x5bb8]
   21f68:      	ldr	x11, [sp, #0x190]
   21f6c:      	str	x13, [x11, #0xc58]
   21f70:      	ldr	x14, [x19, #0x5bc0]
   21f74:      	ldr	x15, [sp, #0x190]
   21f78:      	str	x14, [x15, #0xc60]
   21f7c:      	ldr	x15, [x19, #0x5bc8]
   21f80:      	str	x15, [x0, #0xc68]
   21f84:      	ldr	x0, [x19, #0x5bd0]
   21f88:      	ldr	x1, [sp, #0x190]
   21f8c:      	str	x0, [x1, #0xc70]
   21f90:      	ldr	x0, [x19, #0x5bd8]
   21f94:      	str	x0, [x1, #0xc78]
   21f98:      	mov	x0, #0x0                ; =0
   21f9c:      	str	x0, [x1, #0xc80]
   21fa0:      	ldr	x1, [x19, #0x5be8]
   21fa4:      	str	x1, [x2, #0xc88]
   21fa8:      	ldr	x1, [x19, #0x5bf0]
   21fac:      	str	x1, [x2, #0xc90]
   21fb0:      	ldr	x1, [sp, #0x190]
   21fb4:      	str	x0, [x1, #0xc98]
   21fb8:      	ldr	x1, [x19, #0x5c00]
   21fbc:      	str	x1, [x2, #0xca0]
   21fc0:      	ldr	x1, [x19, #0x5c08]
   21fc4:      	str	x1, [x2, #0xca8]
   21fc8:      	ldr	x1, [sp, #0x190]
   21fcc:      	str	x0, [x1, #0xcb0]
   21fd0:      	ldr	x0, [x19, #0x5c18]
   21fd4:      	str	x0, [x1, #0xcb8]
   21fd8:      	ldr	x0, [x19, #0x5c20]
   21fdc:      	str	x0, [x1, #0xcc0]
   21fe0:      	mov	x1, #0x621              ; =1569
   21fe4:      	mov	x2, #-0x9               ; =-9
   21fe8:      	ldr	x21, [sp, #0x1a0]
   21fec:      	ldur	x0, [sp, #0x8]
   21ff0:      	mov	x5, x20
   21ff4:      	ldr	x6, [sp, #0x198]
   21ff8:      	blr	x21
   21ffc:      	cmp	x0, #0x0
   22000:      	b.ne	0x248fc <_mech_canonical_program_entry_v1_numeric_1282+0x677c>
   22004:      	mov	x0, #0x3                ; =3
   22008:      	ldr	x7, [sp, #0x188]
   2200c:      	mov	x21, x0
   22010:      	cmp	x7, #0x2
   22014:      	b.lo	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   22018:      	mov	x5, #0x0                ; =0
   2201c:      	ldr	x3, [sp, #0x190]
   22020:      	str	x5, [x3]
   22024:      	ldr	x0, [x19, #0x1d68]
   22028:      	str	x0, [x3, #0x8]
   2202c:      	mov	x1, #0x621              ; =1569
   22030:      	ldur	x0, [sp, #0x8]
   22034:      	ldr	x6, [sp, #0x198]
   22038:      	ldr	x21, [sp, #0x1a0]
   2203c:      	mov	x4, x20
   22040:      	mov	x2, x5
   22044:      	blr	x21
   22048:      	cmp	x0, #0x0
   2204c:      	b.ne	0x24904 <_mech_canonical_program_entry_v1_numeric_1282+0x6784>
   22050:      	mov	x0, #0x3                ; =3
   22054:      	mov	x21, x0
   22058:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   2205c:      	sub	x6, x4, #0x1
   22060:      	mov	x8, #0x0                ; =0
   22064:      	cmp	x4, xzr
   22068:      	stur	x4, [sp, #0xf0]
   2206c:      	csel	x4, x6, x8, ne
   22070:      	cmp	x3, x4
   22074:      	csel	x6, x3, x4, lo
   22078:      	ldur	x4, [sp, #0xf8]
   2207c:      	ldr	x8, [x4, x6, lsl #3]
   22080:      	mov	x20, #0x3ffffffffffffff ; =288230376151711743
   22084:      	stur	x20, [sp, #0xb0]
   22088:      	eor	x20, x8, #0x3ffffffffffffff
   2208c:      	orr	x4, x20, #0xc00000000000000
   22090:      	cmp	x4, x28
   22094:      	cset	x4, hi
   22098:      	and	w4, w13, w4
   2209c:      	uxtb	w13, w4
   220a0:      	tbnz	w13, #0x0, 0x220bc <_mech_canonical_program_entry_v1_numeric_1282+0x3f3c>
   220a4:      	mov	x4, x0
   220a8:      	mov	x6, x26
   220ac:      	mov	x8, x14
   220b0:      	mov	x20, x15
   220b4:      	mov	x23, x28
   220b8:      	b	0x22180 <_mech_canonical_program_entry_v1_numeric_1282+0x4000>
   220bc:      	cmp	x8, x22
   220c0:      	b.ne	0x220dc <_mech_canonical_program_entry_v1_numeric_1282+0x3f5c>
   220c4:      	mov	x4, x0
   220c8:      	mov	x6, x26
   220cc:      	mov	x8, x14
   220d0:      	mov	x20, x15
   220d4:      	mov	x23, x28
   220d8:      	b	0x22180 <_mech_canonical_program_entry_v1_numeric_1282+0x4000>
   220dc:      	and	x6, x14, #0x3ffffffffffffff
   220e0:      	eor	x4, x8, #0x3ffffffffffffff
   220e4:      	cmp	x4, x6
   220e8:      	cset	x6, ne
   220ec:      	and	x8, x15, #0x3ffffffffffffff
   220f0:      	cmp	x4, x8
   220f4:      	cset	x8, ne
   220f8:      	and	w6, w6, w8
   220fc:      	and	x8, x26, #0x3ffffffffffffff
   22100:      	cmp	x4, x8
   22104:      	cset	x8, ne
   22108:      	and	w6, w6, w8
   2210c:      	and	x8, x0, #0x3ffffffffffffff
   22110:      	cmp	x4, x8
   22114:      	cset	x4, ne
   22118:      	and	w4, w6, w4
   2211c:      	uxtb	w4, w4
   22120:      	tbnz	w4, #0x0, 0x2213c <_mech_canonical_program_entry_v1_numeric_1282+0x3fbc>
   22124:      	mov	x4, x0
   22128:      	mov	x6, x26
   2212c:      	mov	x8, x14
   22130:      	mov	x20, x15
   22134:      	mov	x23, x28
   22138:      	b	0x22180 <_mech_canonical_program_entry_v1_numeric_1282+0x4000>
   2213c:      	orr	x4, x20, #0xc00000000000000
   22140:      	cmp	x4, x14
   22144:      	csel	x8, x4, x14, hi
   22148:      	cmp	x4, x14
   2214c:      	csel	x4, x4, x14, lo
   22150:      	cmp	x4, x15
   22154:      	csel	x20, x4, x15, hi
   22158:      	cmp	x4, x15
   2215c:      	csel	x4, x4, x15, lo
   22160:      	cmp	x4, x26
   22164:      	csel	x6, x4, x26, hi
   22168:      	cmp	x4, x26
   2216c:      	csel	x23, x4, x26, lo
   22170:      	cmp	x23, x0
   22174:      	csel	x4, x23, x0, hi
   22178:      	cmp	x23, x0
   2217c:      	csel	x23, x23, x0, lo
   22180:      	tbnz	w13, #0x0, 0x22c00 <_mech_canonical_program_entry_v1_numeric_1282+0x4a80>
   22184:      	mov	x13, #0x0               ; =0
   22188:      	str	x13, [x24, #0x1fc0]
   2218c:      	str	x13, [x24, #0x1fc8]
   22190:      	str	x13, [x24, #0x1fd0]
   22194:      	str	x13, [x24, #0x1fd8]
   22198:      	str	x13, [x24, #0x1fe0]
   2219c:      	str	x13, [x24, #0x1fe8]
   221a0:      	str	x13, [x24, #0x1ff0]
   221a4:      	str	x13, [x24, #0x1ff8]
   221a8:      	str	x13, [x24, #0x2000]
   221ac:      	str	x13, [x24, #0x2008]
   221b0:      	str	x13, [x24, #0x2010]
   221b4:      	str	x13, [x24, #0x2018]
   221b8:      	str	x13, [x24, #0x2020]
   221bc:      	str	x13, [x24, #0x2028]
   221c0:      	str	x13, [x24, #0x2030]
   221c4:      	str	x13, [x24, #0x2038]
   221c8:      	mov	w3, #0xcb86             ; =52102
   221cc:      	movk	w3, #0x2, lsl #16
   221d0:      	sub	x3, x2, x3
   221d4:      	mov	x23, #0x0               ; =0
   221d8:      	mov	x2, x23
   221dc:      	tbnz	w10, #0x0, 0x22bd0 <_mech_canonical_program_entry_v1_numeric_1282+0x4a50>
   221e0:      	mov	x0, #0x0                ; =0
   221e4:      	str	x0, [x24, #0x1c30]
   221e8:      	str	x0, [x24, #0x1c38]
   221ec:      	str	x0, [x24, #0x1c40]
   221f0:      	str	x0, [x24, #0x1c48]
   221f4:      	str	x0, [x24, #0x1c50]
   221f8:      	str	x0, [x24, #0x1c58]
   221fc:      	str	x0, [x24, #0x1c60]
   22200:      	str	x0, [x24, #0x1c68]
   22204:      	str	x0, [x24, #0x1c70]
   22208:      	str	x0, [x24, #0x1c78]
   2220c:      	str	x0, [x24, #0x1c80]
   22210:      	str	x0, [x24, #0x1c88]
   22214:      	str	x0, [x24, #0x1c90]
   22218:      	str	x0, [x24, #0x1c98]
   2221c:      	str	x0, [x24, #0x1ca0]
   22220:      	str	x0, [x24, #0x1ca8]
   22224:      	mov	x10, #0x0               ; =0
   22228:      	mov	x9, x10
   2222c:      	mov	x12, x10
   22230:      	mov	x15, x10
   22234:      	mov	x26, x22
   22238:      	mov	x28, x22
   2223c:      	ldr	x4, [sp, #0x180]
   22240:      	cmp	x22, x4
   22244:      	b.lo	0x22250 <_mech_canonical_program_entry_v1_numeric_1282+0x40d0>
   22248:      	add	x11, x11, #0x1
   2224c:      	b	0x22a88 <_mech_canonical_program_entry_v1_numeric_1282+0x4908>
   22250:      	cbnz	x27, 0x223e8 <_mech_canonical_program_entry_v1_numeric_1282+0x4268>
   22254:      	b	0x2490c <_mech_canonical_program_entry_v1_numeric_1282+0x678c>
   22258:      	ldr	x0, [sp, #0x190]
   2225c:      	str	x28, [x0, #0x10]
   22260:      	ldr	x0, [sp, #0x180]
   22264:      	ldr	x1, [sp, #0x190]
   22268:      	str	x0, [x1, #0x18]
   2226c:      	ldr	x0, [sp, #0x190]
   22270:      	str	x28, [x0, #0x10]
   22274:      	ldr	x0, [sp, #0x180]
   22278:      	str	x0, [x1, #0x18]
   2227c:      	add	x11, x11, #0x1
   22280:      	ldr	x0, [sp, #0x190]
   22284:      	str	x11, [x0, #0xc50]
   22288:      	ldur	x25, [sp, #0x88]
   2228c:      	str	x25, [x0, #0xc58]
   22290:      	ldur	x13, [sp, #0x90]
   22294:      	str	x13, [x0, #0xc60]
   22298:      	ldur	x5, [sp, #0x70]
   2229c:      	sub	x13, x5, x3
   222a0:      	mov	w14, #0xc87e            ; =51326
   222a4:      	movk	w14, #0x1, lsl #16
   222a8:      	msub	x13, x11, x14, x13
   222ac:      	str	x13, [x0, #0xc68]
   222b0:      	str	x10, [x0, #0xc70]
   222b4:      	str	x15, [x0, #0xc78]
   222b8:      	mov	x5, #0x0                ; =0
   222bc:      	str	x5, [x0, #0xc80]
   222c0:      	ldur	x0, [sp, #0x98]
   222c4:      	str	x0, [x1, #0xc88]
   222c8:      	ldr	x0, [sp, #0x190]
   222cc:      	ldur	x6, [sp, #0xa0]
   222d0:      	str	x6, [x0, #0xc90]
   222d4:      	str	x5, [x0, #0xc98]
   222d8:      	str	x12, [x0, #0xca0]
   222dc:      	str	x9, [x0, #0xca8]
   222e0:      	str	x5, [x0, #0xcb0]
   222e4:      	str	x23, [x0, #0xcb8]
   222e8:      	str	x2, [x1, #0xcc0]
   222ec:      	ldur	x2, [sp, #0x48]
   222f0:      	add	x0, x2, #0x1
   222f4:      	ldr	x4, [sp, #0x190]
   222f8:      	str	x0, [x4, #0xcd0]
   222fc:      	ldur	x10, [sp, #0x10]
   22300:      	and	x0, x10, #0x3ffffffffffffff
   22304:      	eor	x0, x0, #0x3ffffffffffffff
   22308:      	ldr	x8, [sp, #0x190]
   2230c:      	str	x0, [x8, #0xcd8]
   22310:      	mov	x1, #0x6c4              ; =1732
   22314:      	mov	x2, #-0x1b              ; =-27
   22318:      	ldur	x4, [sp, #0x80]
   2231c:      	ldr	x21, [sp, #0x1a0]
   22320:      	ldur	x0, [sp, #0x8]
   22324:      	ldr	x6, [sp, #0x198]
   22328:      	blr	x21
   2232c:      	mov	x7, #0x2                ; =2
   22330:      	mov	x21, x7
   22334:      	cmp	x0, #0x0
   22338:      	b.ne	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   2233c:      	ldr	x3, [sp, #0x190]
   22340:      	ldr	x3, [x3]
   22344:      	ldr	x0, [sp, #0x190]
   22348:      	ldr	x4, [x0, #0x8]
   2234c:      	stur	x4, [sp, #0x80]
   22350:      	ldr	x21, [x0, #0xab8]
   22354:      	ldr	x27, [x0, #0xbf8]
   22358:      	ldr	x1, [x0, #0xac0]
   2235c:      	ldr	x0, [x0, #0xac8]
   22360:      	ldr	x0, [sp, #0x190]
   22364:      	ldr	x0, [x0, #0xad0]
   22368:      	ldr	x0, [sp, #0x190]
   2236c:      	ldr	x0, [x0, #0xc48]
   22370:      	stur	x0, [sp, #0xa8]
   22374:      	ldr	x0, [sp, #0x190]
   22378:      	ldr	x11, [x0, #0xc50]
   2237c:      	ldr	x25, [x0, #0xc58]
   22380:      	stur	x25, [sp, #0x88]
   22384:      	ldr	x13, [x0, #0xc60]
   22388:      	stur	x13, [sp, #0x90]
   2238c:      	ldr	x0, [x0, #0xc68]
   22390:      	ldr	x2, [sp, #0x190]
   22394:      	ldr	x10, [x2, #0xc70]
   22398:      	ldr	x15, [x2, #0xc78]
   2239c:      	ldr	x23, [x2, #0xc88]
   223a0:      	stur	x23, [sp, #0x98]
   223a4:      	ldr	x6, [x2, #0xc90]
   223a8:      	stur	x6, [sp, #0xa0]
   223ac:      	ldr	x12, [x2, #0xca0]
   223b0:      	ldr	x9, [x2, #0xca8]
   223b4:      	ldr	x23, [x2, #0xcb8]
   223b8:      	ldr	x2, [x2, #0xcc0]
   223bc:      	ldr	x4, [sp, #0x190]
   223c0:      	ldr	x24, [x4, #0x10]
   223c4:      	mov	x4, #0x1                ; =1
   223c8:      	stur	x4, [sp, #0x78]
   223cc:      	str	x4, [x19, #0x4c60]
   223d0:      	add	x0, x3, x0
   223d4:      	mov	w4, #0xc87e             ; =51326
   223d8:      	movk	w4, #0x1, lsl #16
   223dc:      	madd	x5, x11, x4, x0
   223e0:      	stur	x5, [sp, #0x70]
   223e4:      	b	0x22404 <_mech_canonical_program_entry_v1_numeric_1282+0x4284>
   223e8:      	ldur	x0, [sp, #0x10]
   223ec:      	and	x0, x0, #0x3ffffffffffffff
   223f0:      	eor	x0, x0, #0x3ffffffffffffff
   223f4:      	ldur	x1, [sp, #0x48]
   223f8:      	str	x0, [x21, x1, lsl #3]
   223fc:      	add	x1, x1, #0x1
   22400:      	add	x11, x11, #0x1
   22404:      	cbnz	x27, 0x22588 <_mech_canonical_program_entry_v1_numeric_1282+0x4408>
   22408:      	b	0x24938 <_mech_canonical_program_entry_v1_numeric_1282+0x67b8>
   2240c:      	ldr	x0, [sp, #0x190]
   22410:      	str	x28, [x0, #0x10]
   22414:      	ldr	x0, [sp, #0x180]
   22418:      	ldr	x4, [sp, #0x190]
   2241c:      	str	x0, [x4, #0x18]
   22420:      	ldr	x0, [sp, #0x190]
   22424:      	str	x28, [x0, #0x10]
   22428:      	ldr	x0, [sp, #0x180]
   2242c:      	str	x0, [x4, #0x18]
   22430:      	ldr	x0, [sp, #0x190]
   22434:      	str	x11, [x0, #0xc50]
   22438:      	ldur	x25, [sp, #0x88]
   2243c:      	str	x25, [x0, #0xc58]
   22440:      	ldur	x13, [sp, #0x90]
   22444:      	str	x13, [x0, #0xc60]
   22448:      	ldur	x5, [sp, #0x70]
   2244c:      	sub	x0, x5, x3
   22450:      	mov	w4, #0xc87e             ; =51326
   22454:      	movk	w4, #0x1, lsl #16
   22458:      	msub	x0, x11, x4, x0
   2245c:      	ldr	x4, [sp, #0x190]
   22460:      	str	x0, [x4, #0xc68]
   22464:      	ldr	x0, [sp, #0x190]
   22468:      	str	x10, [x0, #0xc70]
   2246c:      	str	x15, [x0, #0xc78]
   22470:      	mov	x5, #0x0                ; =0
   22474:      	str	x5, [x0, #0xc80]
   22478:      	ldur	x0, [sp, #0x98]
   2247c:      	str	x0, [x4, #0xc88]
   22480:      	ldr	x0, [sp, #0x190]
   22484:      	ldur	x6, [sp, #0xa0]
   22488:      	str	x6, [x0, #0xc90]
   2248c:      	str	x5, [x0, #0xc98]
   22490:      	str	x12, [x0, #0xca0]
   22494:      	str	x9, [x0, #0xca8]
   22498:      	str	x5, [x0, #0xcb0]
   2249c:      	str	x23, [x0, #0xcb8]
   224a0:      	str	x2, [x0, #0xcc0]
   224a4:      	add	x0, x1, #0x1
   224a8:      	str	x0, [x4, #0xcd0]
   224ac:      	ldur	x25, [sp, #0x50]
   224b0:      	and	x1, x25, #0x3ffffffffffffff
   224b4:      	eor	x1, x1, #0x3ffffffffffffff
   224b8:      	ldr	x7, [sp, #0x190]
   224bc:      	str	x1, [x7, #0xcd8]
   224c0:      	mov	x1, #0x6c8              ; =1736
   224c4:      	mov	x2, #-0x1b              ; =-27
   224c8:      	ldur	x4, [sp, #0x80]
   224cc:      	ldr	x21, [sp, #0x1a0]
   224d0:      	ldur	x0, [sp, #0x8]
   224d4:      	ldr	x6, [sp, #0x198]
   224d8:      	blr	x21
   224dc:      	mov	x1, #0x2                ; =2
   224e0:      	mov	x21, x1
   224e4:      	cmp	x0, #0x0
   224e8:      	b.ne	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   224ec:      	ldr	x3, [sp, #0x190]
   224f0:      	ldr	x3, [x3]
   224f4:      	ldr	x0, [sp, #0x190]
   224f8:      	ldr	x4, [x0, #0x8]
   224fc:      	stur	x4, [sp, #0x80]
   22500:      	ldr	x21, [x0, #0xab8]
   22504:      	ldr	x27, [x0, #0xbf8]
   22508:      	ldr	x1, [x0, #0xac0]
   2250c:      	ldr	x5, [x0, #0xac8]
   22510:      	ldr	x5, [x0, #0xad0]
   22514:      	ldr	x0, [x0, #0xc48]
   22518:      	stur	x0, [sp, #0xa8]
   2251c:      	ldr	x0, [sp, #0x190]
   22520:      	ldr	x11, [x0, #0xc50]
   22524:      	ldr	x25, [x0, #0xc58]
   22528:      	stur	x25, [sp, #0x88]
   2252c:      	ldr	x13, [x0, #0xc60]
   22530:      	stur	x13, [sp, #0x90]
   22534:      	ldr	x5, [x0, #0xc68]
   22538:      	ldr	x10, [x0, #0xc70]
   2253c:      	ldr	x15, [x0, #0xc78]
   22540:      	ldr	x23, [x0, #0xc88]
   22544:      	stur	x23, [sp, #0x98]
   22548:      	ldr	x6, [x0, #0xc90]
   2254c:      	stur	x6, [sp, #0xa0]
   22550:      	ldr	x12, [x0, #0xca0]
   22554:      	ldr	x9, [x0, #0xca8]
   22558:      	ldr	x23, [x0, #0xcb8]
   2255c:      	ldr	x2, [x0, #0xcc0]
   22560:      	ldr	x24, [x0, #0x10]
   22564:      	mov	x13, #0x1               ; =1
   22568:      	stur	x13, [sp, #0x78]
   2256c:      	str	x13, [x19, #0x4c60]
   22570:      	add	x6, x3, x5
   22574:      	mov	w7, #0xc87e             ; =51326
   22578:      	movk	w7, #0x1, lsl #16
   2257c:      	madd	x5, x11, x7, x6
   22580:      	stur	x5, [sp, #0x70]
   22584:      	b	0x2259c <_mech_canonical_program_entry_v1_numeric_1282+0x441c>
   22588:      	ldur	x25, [sp, #0x50]
   2258c:      	and	x7, x25, #0x3ffffffffffffff
   22590:      	eor	x7, x7, #0x3ffffffffffffff
   22594:      	str	x7, [x21, x1, lsl #3]
   22598:      	add	x1, x1, #0x1
   2259c:      	cbnz	x27, 0x22728 <_mech_canonical_program_entry_v1_numeric_1282+0x45a8>
   225a0:      	b	0x24964 <_mech_canonical_program_entry_v1_numeric_1282+0x67e4>
   225a4:      	ldr	x0, [sp, #0x190]
   225a8:      	str	x28, [x0, #0x10]
   225ac:      	ldr	x4, [sp, #0x180]
   225b0:      	str	x4, [x0, #0x18]
   225b4:      	str	x28, [x0, #0x10]
   225b8:      	ldr	x7, [sp, #0x180]
   225bc:      	str	x7, [x0, #0x18]
   225c0:      	str	x11, [x0, #0xc50]
   225c4:      	ldur	x25, [sp, #0x88]
   225c8:      	str	x25, [x0, #0xc58]
   225cc:      	ldur	x13, [sp, #0x90]
   225d0:      	str	x13, [x0, #0xc60]
   225d4:      	ldur	x5, [sp, #0x70]
   225d8:      	sub	x0, x5, x3
   225dc:      	mov	w4, #0xc87e             ; =51326
   225e0:      	movk	w4, #0x1, lsl #16
   225e4:      	msub	x0, x11, x4, x0
   225e8:      	ldr	x4, [sp, #0x190]
   225ec:      	str	x0, [x4, #0xc68]
   225f0:      	ldr	x0, [sp, #0x190]
   225f4:      	str	x10, [x0, #0xc70]
   225f8:      	str	x15, [x0, #0xc78]
   225fc:      	mov	x5, #0x0                ; =0
   22600:      	str	x5, [x0, #0xc80]
   22604:      	ldur	x0, [sp, #0x98]
   22608:      	str	x0, [x4, #0xc88]
   2260c:      	ldr	x0, [sp, #0x190]
   22610:      	ldur	x6, [sp, #0xa0]
   22614:      	str	x6, [x0, #0xc90]
   22618:      	str	x5, [x0, #0xc98]
   2261c:      	str	x12, [x0, #0xca0]
   22620:      	str	x9, [x0, #0xca8]
   22624:      	str	x5, [x0, #0xcb0]
   22628:      	str	x23, [x0, #0xcb8]
   2262c:      	str	x2, [x0, #0xcc0]
   22630:      	add	x0, x1, #0x1
   22634:      	ldr	x1, [sp, #0x190]
   22638:      	str	x0, [x1, #0xcd0]
   2263c:      	ldur	x0, [sp, #0x58]
   22640:      	and	x0, x0, #0x3ffffffffffffff
   22644:      	eor	x0, x0, #0x3ffffffffffffff
   22648:      	ldr	x6, [sp, #0x190]
   2264c:      	str	x0, [x6, #0xcd8]
   22650:      	mov	x1, #0x6cc              ; =1740
   22654:      	mov	x2, #-0x1b              ; =-27
   22658:      	ldur	x4, [sp, #0x80]
   2265c:      	ldr	x21, [sp, #0x1a0]
   22660:      	ldur	x0, [sp, #0x8]
   22664:      	ldr	x6, [sp, #0x198]
   22668:      	blr	x21
   2266c:      	mov	x1, #0x2                ; =2
   22670:      	mov	x21, x1
   22674:      	cmp	x0, #0x0
   22678:      	b.ne	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   2267c:      	ldr	x3, [sp, #0x190]
   22680:      	ldr	x3, [x3]
   22684:      	ldr	x0, [sp, #0x190]
   22688:      	ldr	x4, [x0, #0x8]
   2268c:      	stur	x4, [sp, #0x80]
   22690:      	ldr	x21, [x0, #0xab8]
   22694:      	ldr	x27, [x0, #0xbf8]
   22698:      	ldr	x1, [x0, #0xac0]
   2269c:      	ldr	x0, [x0, #0xac8]
   226a0:      	ldr	x0, [sp, #0x190]
   226a4:      	ldr	x0, [x0, #0xad0]
   226a8:      	ldr	x0, [sp, #0x190]
   226ac:      	ldr	x0, [x0, #0xc48]
   226b0:      	stur	x0, [sp, #0xa8]
   226b4:      	ldr	x0, [sp, #0x190]
   226b8:      	ldr	x11, [x0, #0xc50]
   226bc:      	ldr	x25, [x0, #0xc58]
   226c0:      	stur	x25, [sp, #0x88]
   226c4:      	ldr	x13, [x0, #0xc60]
   226c8:      	stur	x13, [sp, #0x90]
   226cc:      	ldr	x0, [x0, #0xc68]
   226d0:      	ldr	x2, [sp, #0x190]
   226d4:      	ldr	x10, [x2, #0xc70]
   226d8:      	ldr	x15, [x2, #0xc78]
   226dc:      	ldr	x23, [x2, #0xc88]
   226e0:      	stur	x23, [sp, #0x98]
   226e4:      	ldr	x6, [x2, #0xc90]
   226e8:      	stur	x6, [sp, #0xa0]
   226ec:      	ldr	x12, [x2, #0xca0]
   226f0:      	ldr	x9, [x2, #0xca8]
   226f4:      	ldr	x23, [x2, #0xcb8]
   226f8:      	ldr	x2, [x2, #0xcc0]
   226fc:      	ldr	x4, [sp, #0x190]
   22700:      	ldr	x24, [x4, #0x10]
   22704:      	mov	x4, #0x1                ; =1
   22708:      	stur	x4, [sp, #0x78]
   2270c:      	str	x4, [x19, #0x4c60]
   22710:      	add	x0, x3, x0
   22714:      	mov	w4, #0xc87e             ; =51326
   22718:      	movk	w4, #0x1, lsl #16
   2271c:      	madd	x5, x11, x4, x0
   22720:      	stur	x5, [sp, #0x70]
   22724:      	b	0x2273c <_mech_canonical_program_entry_v1_numeric_1282+0x45bc>
   22728:      	ldur	x0, [sp, #0x58]
   2272c:      	and	x0, x0, #0x3ffffffffffffff
   22730:      	eor	x0, x0, #0x3ffffffffffffff
   22734:      	str	x0, [x21, x1, lsl #3]
   22738:      	add	x1, x1, #0x1
   2273c:      	cbnz	x27, 0x228c8 <_mech_canonical_program_entry_v1_numeric_1282+0x4748>
   22740:      	b	0x24990 <_mech_canonical_program_entry_v1_numeric_1282+0x6810>
   22744:      	ldr	x0, [sp, #0x190]
   22748:      	str	x28, [x0, #0x10]
   2274c:      	ldr	x0, [sp, #0x180]
   22750:      	ldr	x4, [sp, #0x190]
   22754:      	str	x0, [x4, #0x18]
   22758:      	ldr	x0, [sp, #0x190]
   2275c:      	str	x28, [x0, #0x10]
   22760:      	ldr	x0, [sp, #0x180]
   22764:      	str	x0, [x4, #0x18]
   22768:      	ldr	x0, [sp, #0x190]
   2276c:      	str	x11, [x0, #0xc50]
   22770:      	ldur	x25, [sp, #0x88]
   22774:      	str	x25, [x0, #0xc58]
   22778:      	ldur	x13, [sp, #0x90]
   2277c:      	str	x13, [x0, #0xc60]
   22780:      	ldur	x5, [sp, #0x70]
   22784:      	sub	x4, x5, x3
   22788:      	mov	w5, #0xc87e             ; =51326
   2278c:      	movk	w5, #0x1, lsl #16
   22790:      	msub	x4, x11, x5, x4
   22794:      	str	x4, [x0, #0xc68]
   22798:      	str	x10, [x0, #0xc70]
   2279c:      	str	x15, [x0, #0xc78]
   227a0:      	mov	x5, #0x0                ; =0
   227a4:      	str	x5, [x0, #0xc80]
   227a8:      	ldur	x0, [sp, #0x98]
   227ac:      	ldr	x4, [sp, #0x190]
   227b0:      	str	x0, [x4, #0xc88]
   227b4:      	ldr	x0, [sp, #0x190]
   227b8:      	ldur	x6, [sp, #0xa0]
   227bc:      	str	x6, [x0, #0xc90]
   227c0:      	str	x5, [x0, #0xc98]
   227c4:      	str	x12, [x0, #0xca0]
   227c8:      	str	x9, [x0, #0xca8]
   227cc:      	str	x5, [x0, #0xcb0]
   227d0:      	str	x23, [x0, #0xcb8]
   227d4:      	str	x2, [x0, #0xcc0]
   227d8:      	add	x13, x1, #0x1
   227dc:      	str	x13, [x0, #0xcd0]
   227e0:      	ldur	x0, [sp, #0x60]
   227e4:      	and	x14, x0, #0x3ffffffffffffff
   227e8:      	eor	x14, x14, #0x3ffffffffffffff
   227ec:      	str	x14, [x4, #0xcd8]
   227f0:      	mov	x1, #0x6d0              ; =1744
   227f4:      	mov	x2, #-0x1b              ; =-27
   227f8:      	ldur	x4, [sp, #0x80]
   227fc:      	ldr	x21, [sp, #0x1a0]
   22800:      	ldur	x0, [sp, #0x8]
   22804:      	ldr	x6, [sp, #0x198]
   22808:      	blr	x21
   2280c:      	mov	x8, #0x2                ; =2
   22810:      	mov	x21, x8
   22814:      	cmp	x0, #0x0
   22818:      	b.ne	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   2281c:      	ldr	x3, [sp, #0x190]
   22820:      	ldr	x3, [x3]
   22824:      	ldr	x14, [sp, #0x190]
   22828:      	ldr	x4, [x14, #0x8]
   2282c:      	ldr	x0, [sp, #0x190]
   22830:      	stur	x4, [sp, #0x80]
   22834:      	ldr	x21, [x0, #0xab8]
   22838:      	ldr	x27, [x0, #0xbf8]
   2283c:      	ldr	x13, [x0, #0xac0]
   22840:      	ldr	x0, [x0, #0xac8]
   22844:      	ldr	x0, [sp, #0x190]
   22848:      	ldr	x0, [x0, #0xad0]
   2284c:      	ldr	x0, [sp, #0x190]
   22850:      	ldr	x1, [x0, #0xc48]
   22854:      	stur	x1, [sp, #0xa8]
   22858:      	ldr	x11, [x0, #0xc50]
   2285c:      	ldr	x25, [x0, #0xc58]
   22860:      	stur	x25, [sp, #0x88]
   22864:      	ldr	x0, [x0, #0xc60]
   22868:      	stur	x0, [sp, #0x90]
   2286c:      	ldr	x0, [sp, #0x190]
   22870:      	ldr	x0, [x0, #0xc68]
   22874:      	ldr	x1, [sp, #0x190]
   22878:      	ldr	x10, [x1, #0xc70]
   2287c:      	ldr	x15, [x1, #0xc78]
   22880:      	ldr	x23, [x1, #0xc88]
   22884:      	stur	x23, [sp, #0x98]
   22888:      	ldr	x6, [x1, #0xc90]
   2288c:      	stur	x6, [sp, #0xa0]
   22890:      	ldr	x12, [x1, #0xca0]
   22894:      	ldr	x9, [x1, #0xca8]
   22898:      	ldr	x23, [x1, #0xcb8]
   2289c:      	ldr	x2, [x1, #0xcc0]
   228a0:      	ldr	x24, [x1, #0x10]
   228a4:      	mov	x1, #0x1                ; =1
   228a8:      	stur	x1, [sp, #0x78]
   228ac:      	str	x1, [x19, #0x4c60]
   228b0:      	add	x0, x3, x0
   228b4:      	mov	w1, #0xc87e             ; =51326
   228b8:      	movk	w1, #0x1, lsl #16
   228bc:      	madd	x5, x11, x1, x0
   228c0:      	stur	x5, [sp, #0x70]
   228c4:      	b	0x228dc <_mech_canonical_program_entry_v1_numeric_1282+0x475c>
   228c8:      	ldur	x13, [sp, #0x60]
   228cc:      	and	x0, x13, #0x3ffffffffffffff
   228d0:      	eor	x0, x0, #0x3ffffffffffffff
   228d4:      	str	x0, [x21, x1, lsl #3]
   228d8:      	add	x13, x1, #0x1
   228dc:      	cbnz	x27, 0x22a70 <_mech_canonical_program_entry_v1_numeric_1282+0x48f0>
   228e0:      	b	0x249bc <_mech_canonical_program_entry_v1_numeric_1282+0x683c>
   228e4:      	ldr	x0, [sp, #0x190]
   228e8:      	str	x28, [x0, #0x10]
   228ec:      	ldr	x0, [sp, #0x180]
   228f0:      	ldr	x1, [sp, #0x190]
   228f4:      	str	x0, [x1, #0x18]
   228f8:      	ldr	x0, [sp, #0x190]
   228fc:      	str	x28, [x0, #0x10]
   22900:      	ldr	x0, [sp, #0x180]
   22904:      	str	x0, [x1, #0x18]
   22908:      	ldr	x0, [sp, #0x190]
   2290c:      	str	x11, [x0, #0xc50]
   22910:      	ldur	x25, [sp, #0x88]
   22914:      	str	x25, [x0, #0xc58]
   22918:      	ldur	x4, [sp, #0x90]
   2291c:      	str	x4, [x0, #0xc60]
   22920:      	ldur	x5, [sp, #0x70]
   22924:      	sub	x0, x5, x3
   22928:      	mov	w1, #0xc87e             ; =51326
   2292c:      	movk	w1, #0x1, lsl #16
   22930:      	msub	x0, x11, x1, x0
   22934:      	ldr	x1, [sp, #0x190]
   22938:      	str	x0, [x1, #0xc68]
   2293c:      	ldr	x0, [sp, #0x190]
   22940:      	str	x10, [x0, #0xc70]
   22944:      	str	x15, [x0, #0xc78]
   22948:      	mov	x5, #0x0                ; =0
   2294c:      	str	x5, [x0, #0xc80]
   22950:      	ldur	x0, [sp, #0x98]
   22954:      	str	x0, [x1, #0xc88]
   22958:      	ldr	x0, [sp, #0x190]
   2295c:      	ldur	x6, [sp, #0xa0]
   22960:      	str	x6, [x0, #0xc90]
   22964:      	str	x5, [x0, #0xc98]
   22968:      	str	x12, [x0, #0xca0]
   2296c:      	str	x9, [x0, #0xca8]
   22970:      	str	x5, [x0, #0xcb0]
   22974:      	str	x23, [x0, #0xcb8]
   22978:      	str	x2, [x0, #0xcc0]
   2297c:      	add	x0, x13, #0x1
   22980:      	str	x0, [x1, #0xcd0]
   22984:      	ldur	x25, [sp, #0x68]
   22988:      	and	x0, x25, #0x3ffffffffffffff
   2298c:      	eor	x0, x0, #0x3ffffffffffffff
   22990:      	str	x0, [x1, #0xcd8]
   22994:      	mov	x1, #0x6d4              ; =1748
   22998:      	mov	x2, #-0x1b              ; =-27
   2299c:      	ldur	x4, [sp, #0x80]
   229a0:      	ldr	x21, [sp, #0x1a0]
   229a4:      	ldur	x0, [sp, #0x8]
   229a8:      	ldr	x6, [sp, #0x198]
   229ac:      	blr	x21
   229b0:      	mov	x1, #0x2                ; =2
   229b4:      	mov	x21, x1
   229b8:      	cmp	x0, #0x0
   229bc:      	b.ne	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   229c0:      	ldr	x3, [sp, #0x190]
   229c4:      	ldr	x3, [x3]
   229c8:      	ldr	x12, [sp, #0x190]
   229cc:      	ldr	x4, [x12, #0x8]
   229d0:      	ldr	x14, [sp, #0x190]
   229d4:      	stur	x4, [sp, #0x80]
   229d8:      	ldr	x21, [x14, #0xab8]
   229dc:      	ldr	x0, [sp, #0x190]
   229e0:      	ldr	x27, [x0, #0xbf8]
   229e4:      	ldr	x2, [x0, #0xac0]
   229e8:      	stur	x2, [sp, #0x48]
   229ec:      	ldr	x0, [x0, #0xac8]
   229f0:      	ldr	x0, [sp, #0x190]
   229f4:      	ldr	x0, [x0, #0xad0]
   229f8:      	ldr	x0, [sp, #0x190]
   229fc:      	ldr	x1, [x0, #0xc48]
   22a00:      	stur	x1, [sp, #0xa8]
   22a04:      	ldr	x11, [x0, #0xc50]
   22a08:      	ldr	x25, [x0, #0xc58]
   22a0c:      	stur	x25, [sp, #0x88]
   22a10:      	ldr	x13, [x0, #0xc60]
   22a14:      	stur	x13, [sp, #0x90]
   22a18:      	ldr	x0, [x0, #0xc68]
   22a1c:      	ldr	x1, [sp, #0x190]
   22a20:      	ldr	x10, [x1, #0xc70]
   22a24:      	ldr	x15, [x1, #0xc78]
   22a28:      	ldr	x23, [x1, #0xc88]
   22a2c:      	stur	x23, [sp, #0x98]
   22a30:      	ldr	x6, [x1, #0xc90]
   22a34:      	stur	x6, [sp, #0xa0]
   22a38:      	ldr	x12, [x1, #0xca0]
   22a3c:      	ldr	x9, [x1, #0xca8]
   22a40:      	ldr	x23, [x1, #0xcb8]
   22a44:      	ldr	x2, [x1, #0xcc0]
   22a48:      	ldr	x24, [x1, #0x10]
   22a4c:      	mov	x13, #0x1               ; =1
   22a50:      	stur	x13, [sp, #0x78]
   22a54:      	str	x13, [x19, #0x4c60]
   22a58:      	add	x0, x3, x0
   22a5c:      	mov	w1, #0xc87e             ; =51326
   22a60:      	movk	w1, #0x1, lsl #16
   22a64:      	madd	x5, x11, x1, x0
   22a68:      	stur	x5, [sp, #0x70]
   22a6c:      	b	0x22a88 <_mech_canonical_program_entry_v1_numeric_1282+0x4908>
   22a70:      	ldur	x25, [sp, #0x68]
   22a74:      	and	x0, x25, #0x3ffffffffffffff
   22a78:      	eor	x0, x0, #0x3ffffffffffffff
   22a7c:      	str	x0, [x21, x13, lsl #3]
   22a80:      	add	x0, x13, #0x1
   22a84:      	stur	x0, [sp, #0x48]
   22a88:      	ldr	x0, [sp, #0x180]
   22a8c:      	cmp	x22, x0
   22a90:      	b.lo	0x22ba8 <_mech_canonical_program_entry_v1_numeric_1282+0x4a28>
   22a94:      	mov	x8, #0x0                ; =0
   22a98:      	str	x8, [x19, #0x18]
   22a9c:      	mov	x13, #0x1000000000000000 ; =1152921504606846976
   22aa0:      	str	x13, [x19, #0x20]
   22aa4:      	mov	x13, #0x1               ; =1
   22aa8:      	str	x13, [x19, #0x30]
   22aac:      	mov	x14, #0x101010101010101 ; =72340172838076673
   22ab0:      	str	x14, [x19, #0x38]
   22ab4:      	mov	x14, #0x2               ; =2
   22ab8:      	str	x14, [x19, #0x40]
   22abc:      	mov	x14, #0x3               ; =3
   22ac0:      	str	x14, [x19, #0x48]
   22ac4:      	mov	x14, #0x4               ; =4
   22ac8:      	str	x14, [x19, #0x50]
   22acc:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   22ad0:      	str	x0, [x19, #0x78]
   22ad4:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   22ad8:      	str	x0, [x19, #0x88]
   22adc:      	mov	x0, #0x38               ; =56
   22ae0:      	str	x0, [x19, #0x90]
   22ae4:      	mov	x0, #0x3a               ; =58
   22ae8:      	str	x0, [x19, #0x98]
   22aec:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   22af0:      	str	x0, [x19, #0xb0]
   22af4:      	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
   22af8:      	str	x0, [x19, #0xb8]
   22afc:      	str	x8, [x19, #0x188]
   22b00:      	str	x13, [x19, #0x190]
   22b04:      	ldur	x0, [sp, #0x78]
   22b08:      	str	x0, [x19, #0x4c60]
   22b0c:      	str	x3, [x19, #0x4c68]
   22b10:      	ldur	x4, [sp, #0x80]
   22b14:      	str	x4, [x19, #0x4c70]
   22b18:      	str	x28, [x19, #0x4f70]
   22b1c:      	ldr	x22, [sp, #0x180]
   22b20:      	str	x22, [x19, #0x4f78]
   22b24:      	ldur	x1, [sp, #0x48]
   22b28:      	str	x1, [x19, #0x5a20]
   22b2c:      	str	x11, [x19, #0x5bb0]
   22b30:      	ldur	x25, [sp, #0x88]
   22b34:      	str	x25, [x19, #0x5bb8]
   22b38:      	ldur	x13, [sp, #0x90]
   22b3c:      	str	x13, [x19, #0x5bc0]
   22b40:      	ldur	x5, [sp, #0x70]
   22b44:      	sub	x0, x5, x3
   22b48:      	mov	w1, #0xc87e             ; =51326
   22b4c:      	movk	w1, #0x1, lsl #16
   22b50:      	msub	x0, x11, x1, x0
   22b54:      	str	x0, [x19, #0x5bc8]
   22b58:      	str	x10, [x19, #0x5bd0]
   22b5c:      	str	x15, [x19, #0x5bd8]
   22b60:      	ldur	x0, [sp, #0x98]
   22b64:      	str	x0, [x19, #0x5be8]
   22b68:      	ldur	x6, [sp, #0xa0]
   22b6c:      	str	x6, [x19, #0x5bf0]
   22b70:      	str	x12, [x19, #0x5c00]
   22b74:      	str	x9, [x19, #0x5c08]
   22b78:      	str	x23, [x19, #0x5c18]
   22b7c:      	str	x2, [x19, #0x5c20]
   22b80:      	mov	x0, #0x0                ; =0
   22b84:      	mov	x1, #0x1                ; =1
   22b88:      	add	sp, sp, #0x1b0
   22b8c:      	ldp	x19, x20, [sp], #0x10
   22b90:      	ldp	x21, x22, [sp], #0x10
   22b94:      	ldp	x23, x24, [sp], #0x10
   22b98:      	ldp	x25, x26, [sp], #0x10
   22b9c:      	ldp	x27, x28, [sp], #0x10
   22ba0:      	ldp	x29, x30, [sp], #0x10
   22ba4:      	retab
   22ba8:      	add	x22, x26, #0x1
   22bac:      	cmp	x22, x26
   22bb0:      	b.lo	0x249e8 <_mech_canonical_program_entry_v1_numeric_1282+0x6868>
   22bb4:      	mov	x13, #0x1               ; =1
   22bb8:      	stur	x13, [sp, #0x90]
   22bbc:      	ldur	x0, [sp, #0x90]
   22bc0:      	ldur	x6, [sp, #0x98]
   22bc4:      	mov	x8, x19
   22bc8:      	ldur	x13, [sp, #0xa0]
   22bcc:      	b	0x1e358 <_mech_canonical_program_entry_v1_numeric_1282+0x1d8>
   22bd0:      	add	x4, x12, #0x1
   22bd4:      	cmp	x4, x12
   22bd8:      	b.lo	0x24aec <_mech_canonical_program_entry_v1_numeric_1282+0x696c>
   22bdc:      	mov	x1, #0x1                ; =1
   22be0:      	stur	x1, [sp, #0x38]
   22be4:      	mov	x12, x4
   22be8:      	stur	x14, [sp, #0x10]
   22bec:      	stur	x15, [sp, #0x50]
   22bf0:      	stur	x26, [sp, #0x58]
   22bf4:      	stur	x0, [sp, #0x60]
   22bf8:      	stur	x28, [sp, #0x68]
   22bfc:      	b	0x20cec <_mech_canonical_program_entry_v1_numeric_1282+0x2b6c>
   22c00:      	add	x13, x3, #0x1
   22c04:      	cmp	x13, x3
   22c08:      	b.lo	0x24c10 <_mech_canonical_program_entry_v1_numeric_1282+0x6a90>
   22c0c:      	mov	w0, #0xcb86             ; =52102
   22c10:      	movk	w0, #0x2, lsl #16
   22c14:      	sub	x2, x2, x0
   22c18:      	mov	x0, #0x1                ; =1
   22c1c:      	stur	x0, [sp, #0x40]
   22c20:      	mov	x0, x4
   22c24:      	mov	x3, x13
   22c28:      	mov	x14, x8
   22c2c:      	mov	x15, x20
   22c30:      	mov	x26, x6
   22c34:      	mov	x28, x23
   22c38:      	b	0x21970 <_mech_canonical_program_entry_v1_numeric_1282+0x37f0>
   22c3c:      	add	x0, x7, #0x1
   22c40:      	stur	x0, [sp, #0x18]
   22c44:      	cmp	x0, x7
   22c48:      	b.lo	0x24d54 <_mech_canonical_program_entry_v1_numeric_1282+0x6bd4>
   22c4c:      	mov	x0, #0x1                ; =1
   22c50:      	stur	x0, [sp, #0x20]
   22c54:      	stur	x1, [sp, #0x68]
   22c58:      	stur	x15, [sp, #0x10]
   22c5c:      	mov	x25, x28
   22c60:      	mov	x28, x26
   22c64:      	mov	x26, x10
   22c68:      	b	0x1eed8 <_mech_canonical_program_entry_v1_numeric_1282+0xd58>
   22c6c:      	add	x7, x6, #0x1
   22c70:      	cmp	x7, x6
   22c74:      	b.lo	0x24ea4 <_mech_canonical_program_entry_v1_numeric_1282+0x6d24>
   22c78:      	mov	w1, #0xdc1e             ; =56350
   22c7c:      	movk	w1, #0x2, lsl #16
   22c80:      	sub	x13, x13, x1
   22c84:      	mov	x6, #0x1                ; =1
   22c88:      	stur	x6, [sp, #0x30]
   22c8c:      	mov	x10, x20
   22c90:      	mov	x15, x25
   22c94:      	mov	x26, x8
   22c98:      	mov	x28, x5
   22c9c:      	stur	x4, [sp, #0x28]
   22ca0:      	b	0x1fb78 <_mech_canonical_program_entry_v1_numeric_1282+0x19f8>
   22ca4:      	mov	x21, x0
   22ca8:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   22cac:      	mov	x21, x0
   22cb0:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   22cb4:      	mov	x21, x0
   22cb8:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   22cbc:      	mov	x21, x0
   22cc0:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   22cc4:      	mov	x4, #0x512              ; =1298
   22cc8:      	ldur	x5, [sp]
   22ccc:      	str	x4, [x5, #0x48]
   22cd0:      	mov	x8, #0x0                ; =0
   22cd4:      	str	x8, [x19, #0x18]
   22cd8:      	mov	x4, #0x1000000000000000 ; =1152921504606846976
   22cdc:      	str	x4, [x19, #0x20]
   22ce0:      	mov	x4, #0x1                ; =1
   22ce4:      	str	x4, [x19, #0x30]
   22ce8:      	mov	x5, #0x101010101010101  ; =72340172838076673
   22cec:      	str	x5, [x19, #0x38]
   22cf0:      	mov	x20, #0x2               ; =2
   22cf4:      	str	x20, [x19, #0x40]
   22cf8:      	mov	x5, #0x3                ; =3
   22cfc:      	str	x5, [x19, #0x48]
   22d00:      	mov	x5, #0x4                ; =4
   22d04:      	str	x5, [x19, #0x50]
   22d08:      	mov	x5, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   22d0c:      	str	x5, [x19, #0x78]
   22d10:      	mov	x5, #0x3333333333333333 ; =3689348814741910323
   22d14:      	str	x5, [x19, #0x88]
   22d18:      	mov	x5, #0x38               ; =56
   22d1c:      	str	x5, [x19, #0x90]
   22d20:      	mov	x5, #0x3a               ; =58
   22d24:      	str	x5, [x19, #0x98]
   22d28:      	mov	x5, #0x5555555555555555 ; =6148914691236517205
   22d2c:      	str	x5, [x19, #0xb0]
   22d30:      	mov	x5, #0x3ffffffffffffff  ; =288230376151711743
   22d34:      	str	x5, [x19, #0xb8]
   22d38:      	str	x8, [x19, #0x188]
   22d3c:      	str	x4, [x19, #0x190]
   22d40:      	str	x22, [x19, #0x17a0]
   22d44:      	ldr	x8, [sp, #0x180]
   22d48:      	str	x8, [x19, #0x17a8]
   22d4c:      	uxtb	w4, w1
   22d50:      	str	x4, [x19, #0x17b8]
   22d54:      	add	x4, x22, #0x1
   22d58:      	str	x4, [x19, #0x17d0]
   22d5c:      	ldur	x1, [sp, #0x78]
   22d60:      	str	x1, [x19, #0x4c60]
   22d64:      	mov	w5, #0xc87e             ; =51326
   22d68:      	movk	w5, #0x1, lsl #16
   22d6c:      	sub	x8, x3, x5
   22d70:      	str	x8, [x19, #0x4c68]
   22d74:      	str	x7, [x19, #0x4c70]
   22d78:      	str	x22, [x19, #0x4f70]
   22d7c:      	ldr	x22, [sp, #0x180]
   22d80:      	str	x22, [x19, #0x4f78]
   22d84:      	ldur	x1, [sp, #0x48]
   22d88:      	str	x1, [x19, #0x5a20]
   22d8c:      	add	x11, x11, #0x1
   22d90:      	str	x11, [x19, #0x5bb0]
   22d94:      	ldur	x25, [sp, #0x88]
   22d98:      	str	x25, [x19, #0x5bb8]
   22d9c:      	str	x0, [x19, #0x5bc0]
   22da0:      	ldur	x0, [sp, #0x70]
   22da4:      	sub	x0, x0, x8
   22da8:      	msub	x0, x11, x5, x0
   22dac:      	str	x0, [x19, #0x5bc8]
   22db0:      	str	x10, [x19, #0x5bd0]
   22db4:      	str	x15, [x19, #0x5bd8]
   22db8:      	str	x6, [x19, #0x5be8]
   22dbc:      	str	x13, [x19, #0x5bf0]
   22dc0:      	str	x12, [x19, #0x5c00]
   22dc4:      	str	x9, [x19, #0x5c08]
   22dc8:      	str	x23, [x19, #0x5c18]
   22dcc:      	str	x2, [x19, #0x5c20]
   22dd0:      	ldr	x0, [x19, #0x4c60]
   22dd4:      	cmp	x0, #0x0
   22dd8:      	b.ne	0x1e72c <_mech_canonical_program_entry_v1_numeric_1282+0x5ac>
   22ddc:      	b	0x1e724 <_mech_canonical_program_entry_v1_numeric_1282+0x5a4>
   22de0:      	mov	x21, x0
   22de4:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   22de8:      	mov	x21, x20
   22dec:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   22df0:      	mov	x21, x0
   22df4:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   22df8:      	mov	x21, x20
   22dfc:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   22e00:      	mov	x0, #0x514              ; =1300
   22e04:      	ldur	x4, [sp]
   22e08:      	str	x0, [x4, #0x48]
   22e0c:      	mov	x0, #0x0                ; =0
   22e10:      	str	x0, [x19, #0x18]
   22e14:      	mov	x4, #0x1000000000000000 ; =1152921504606846976
   22e18:      	str	x4, [x19, #0x20]
   22e1c:      	mov	x4, #0x1                ; =1
   22e20:      	str	x4, [x19, #0x30]
   22e24:      	mov	x5, #0x101010101010101  ; =72340172838076673
   22e28:      	str	x5, [x19, #0x38]
   22e2c:      	mov	x20, #0x2               ; =2
   22e30:      	str	x20, [x19, #0x40]
   22e34:      	mov	x5, #0x3                ; =3
   22e38:      	str	x5, [x19, #0x48]
   22e3c:      	mov	x5, #0x4                ; =4
   22e40:      	str	x5, [x19, #0x50]
   22e44:      	mov	x5, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   22e48:      	str	x5, [x19, #0x78]
   22e4c:      	mov	x5, #0x3333333333333333 ; =3689348814741910323
   22e50:      	str	x5, [x19, #0x88]
   22e54:      	mov	x5, #0x38               ; =56
   22e58:      	str	x5, [x19, #0x90]
   22e5c:      	mov	x5, #0x3a               ; =58
   22e60:      	str	x5, [x19, #0x98]
   22e64:      	mov	x5, #0x5555555555555555 ; =6148914691236517205
   22e68:      	str	x5, [x19, #0xb0]
   22e6c:      	mov	x5, #0x3ffffffffffffff  ; =288230376151711743
   22e70:      	str	x5, [x19, #0xb8]
   22e74:      	str	x0, [x19, #0x188]
   22e78:      	str	x4, [x19, #0x190]
   22e7c:      	str	x22, [x19, #0x17a0]
   22e80:      	ldr	x4, [sp, #0x180]
   22e84:      	str	x4, [x19, #0x17a8]
   22e88:      	uxtb	w1, w1
   22e8c:      	str	x1, [x19, #0x17b8]
   22e90:      	ldr	x27, [sp, #0x170]
   22e94:      	sub	x1, x27, #0x1
   22e98:      	cmp	x27, xzr
   22e9c:      	csel	x0, x1, x0, ne
   22ea0:      	cmp	x22, x0
   22ea4:      	csel	x0, x22, x0, lo
   22ea8:      	ldr	x27, [sp, #0x178]
   22eac:      	ldr	x0, [x27, x0, lsl #3]
   22eb0:      	str	x0, [x19, #0x17d8]
   22eb4:      	add	x0, x22, #0x2
   22eb8:      	str	x0, [x19, #0x17e0]
   22ebc:      	ldur	x0, [sp, #0x78]
   22ec0:      	str	x0, [x19, #0x4c60]
   22ec4:      	mov	w0, #0xc87e             ; =51326
   22ec8:      	movk	w0, #0x1, lsl #16
   22ecc:      	sub	x1, x3, x0
   22ed0:      	str	x1, [x19, #0x4c68]
   22ed4:      	str	x7, [x19, #0x4c70]
   22ed8:      	str	x22, [x19, #0x4f70]
   22edc:      	ldr	x22, [sp, #0x180]
   22ee0:      	str	x22, [x19, #0x4f78]
   22ee4:      	ldur	x3, [sp, #0x48]
   22ee8:      	str	x3, [x19, #0x5a20]
   22eec:      	add	x4, x11, #0x1
   22ef0:      	str	x4, [x19, #0x5bb0]
   22ef4:      	ldur	x25, [sp, #0x88]
   22ef8:      	str	x25, [x19, #0x5bb8]
   22efc:      	ldur	x7, [sp, #0x90]
   22f00:      	str	x7, [x19, #0x5bc0]
   22f04:      	ldur	x5, [sp, #0x70]
   22f08:      	sub	x7, x5, x1
   22f0c:      	msub	x7, x4, x0, x7
   22f10:      	str	x7, [x19, #0x5bc8]
   22f14:      	str	x10, [x19, #0x5bd0]
   22f18:      	str	x15, [x19, #0x5bd8]
   22f1c:      	str	x6, [x19, #0x5be8]
   22f20:      	ldur	x8, [sp, #0xa0]
   22f24:      	str	x8, [x19, #0x5bf0]
   22f28:      	str	x12, [x19, #0x5c00]
   22f2c:      	str	x9, [x19, #0x5c08]
   22f30:      	str	x23, [x19, #0x5c18]
   22f34:      	str	x2, [x19, #0x5c20]
   22f38:      	ldr	x0, [x19, #0x4c60]
   22f3c:      	cmp	x0, #0x0
   22f40:      	b.ne	0x1e988 <_mech_canonical_program_entry_v1_numeric_1282+0x808>
   22f44:      	b	0x1eb98 <_mech_canonical_program_entry_v1_numeric_1282+0xa18>
   22f48:      	mov	x21, x0
   22f4c:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   22f50:      	mov	x21, x20
   22f54:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   22f58:      	mov	x21, x0
   22f5c:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   22f60:      	mov	x21, x20
   22f64:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   22f68:      	mov	x4, #0x516              ; =1302
   22f6c:      	ldur	x5, [sp]
   22f70:      	str	x4, [x5, #0x48]
   22f74:      	mov	x6, #0x0                ; =0
   22f78:      	str	x6, [x19, #0x18]
   22f7c:      	mov	x4, #0x1000000000000000 ; =1152921504606846976
   22f80:      	str	x4, [x19, #0x20]
   22f84:      	mov	x4, #0x1                ; =1
   22f88:      	str	x4, [x19, #0x30]
   22f8c:      	mov	x5, #0x101010101010101  ; =72340172838076673
   22f90:      	str	x5, [x19, #0x38]
   22f94:      	mov	x20, #0x2               ; =2
   22f98:      	str	x20, [x19, #0x40]
   22f9c:      	mov	x5, #0x3                ; =3
   22fa0:      	str	x5, [x19, #0x48]
   22fa4:      	mov	x5, #0x4                ; =4
   22fa8:      	str	x5, [x19, #0x50]
   22fac:      	mov	x5, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   22fb0:      	str	x5, [x19, #0x78]
   22fb4:      	mov	x5, #0x3333333333333333 ; =3689348814741910323
   22fb8:      	str	x5, [x19, #0x88]
   22fbc:      	mov	x5, #0x38               ; =56
   22fc0:      	str	x5, [x19, #0x90]
   22fc4:      	mov	x5, #0x3a               ; =58
   22fc8:      	str	x5, [x19, #0x98]
   22fcc:      	mov	x5, #0x5555555555555555 ; =6148914691236517205
   22fd0:      	str	x5, [x19, #0xb0]
   22fd4:      	mov	x5, #0x3ffffffffffffff  ; =288230376151711743
   22fd8:      	str	x5, [x19, #0xb8]
   22fdc:      	str	x6, [x19, #0x188]
   22fe0:      	str	x4, [x19, #0x190]
   22fe4:      	str	x22, [x19, #0x17a0]
   22fe8:      	ldr	x4, [sp, #0x180]
   22fec:      	str	x4, [x19, #0x17a8]
   22ff0:      	uxtb	w1, w1
   22ff4:      	str	x1, [x19, #0x17b8]
   22ff8:      	ldr	x27, [sp, #0x170]
   22ffc:      	sub	x1, x27, #0x1
   23000:      	cmp	x27, xzr
   23004:      	csel	x1, x1, x6, ne
   23008:      	cmp	x22, x1
   2300c:      	csel	x4, x22, x1, lo
   23010:      	ldr	x8, [sp, #0x178]
   23014:      	ldr	x4, [x8, x4, lsl #3]
   23018:      	str	x4, [x19, #0x17d8]
   2301c:      	cmp	x0, x1
   23020:      	csel	x1, x0, x1, lo
   23024:      	ldr	x13, [sp, #0x178]
   23028:      	ldr	x1, [x13, x1, lsl #3]
   2302c:      	str	x1, [x19, #0x17e8]
   23030:      	str	x0, [x19, #0x17f0]
   23034:      	ldur	x0, [sp, #0x78]
   23038:      	str	x0, [x19, #0x4c60]
   2303c:      	mov	w0, #0xc87e             ; =51326
   23040:      	movk	w0, #0x1, lsl #16
   23044:      	sub	x1, x3, x0
   23048:      	str	x1, [x19, #0x4c68]
   2304c:      	str	x7, [x19, #0x4c70]
   23050:      	str	x22, [x19, #0x4f70]
   23054:      	ldr	x22, [sp, #0x180]
   23058:      	str	x22, [x19, #0x4f78]
   2305c:      	ldur	x3, [sp, #0x48]
   23060:      	str	x3, [x19, #0x5a20]
   23064:      	add	x3, x11, #0x1
   23068:      	str	x3, [x19, #0x5bb0]
   2306c:      	ldur	x25, [sp, #0x88]
   23070:      	str	x25, [x19, #0x5bb8]
   23074:      	ldur	x13, [sp, #0x90]
   23078:      	str	x13, [x19, #0x5bc0]
   2307c:      	ldur	x5, [sp, #0x70]
   23080:      	sub	x4, x5, x1
   23084:      	msub	x3, x3, x0, x4
   23088:      	str	x3, [x19, #0x5bc8]
   2308c:      	str	x10, [x19, #0x5bd0]
   23090:      	str	x15, [x19, #0x5bd8]
   23094:      	ldur	x4, [sp, #0x98]
   23098:      	str	x4, [x19, #0x5be8]
   2309c:      	ldur	x6, [sp, #0xa0]
   230a0:      	str	x6, [x19, #0x5bf0]
   230a4:      	str	x12, [x19, #0x5c00]
   230a8:      	str	x9, [x19, #0x5c08]
   230ac:      	str	x23, [x19, #0x5c18]
   230b0:      	str	x2, [x19, #0x5c20]
   230b4:      	ldr	x12, [x19, #0x4c60]
   230b8:      	cmp	x12, #0x0
   230bc:      	b.ne	0x1ec00 <_mech_canonical_program_entry_v1_numeric_1282+0xa80>
   230c0:      	b	0x1ee20 <_mech_canonical_program_entry_v1_numeric_1282+0xca0>
   230c4:      	mov	x21, x0
   230c8:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   230cc:      	mov	x21, x20
   230d0:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   230d4:      	mov	x21, x0
   230d8:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   230dc:      	mov	x21, x20
   230e0:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   230e4:      	ldur	x21, [sp, #0xc8]
   230e8:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   230ec:      	mov	x0, #0x530              ; =1328
   230f0:      	ldur	x1, [sp]
   230f4:      	str	x0, [x1, #0x48]
   230f8:      	mov	x1, #0x0                ; =0
   230fc:      	str	x1, [x19, #0x18]
   23100:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   23104:      	str	x0, [x19, #0x20]
   23108:      	mov	x0, #0x1                ; =1
   2310c:      	str	x0, [x19, #0x30]
   23110:      	mov	x4, #0x101010101010101  ; =72340172838076673
   23114:      	str	x4, [x19, #0x38]
   23118:      	mov	x20, #0x2               ; =2
   2311c:      	str	x20, [x19, #0x40]
   23120:      	mov	x4, #0x3                ; =3
   23124:      	str	x4, [x19, #0x48]
   23128:      	mov	x4, #0x4                ; =4
   2312c:      	str	x4, [x19, #0x50]
   23130:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   23134:      	str	x4, [x19, #0x78]
   23138:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   2313c:      	str	x4, [x19, #0x88]
   23140:      	mov	x4, #0x38               ; =56
   23144:      	str	x4, [x19, #0x90]
   23148:      	mov	x4, #0x3a               ; =58
   2314c:      	str	x4, [x19, #0x98]
   23150:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   23154:      	str	x4, [x19, #0xb0]
   23158:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   2315c:      	str	x4, [x19, #0xb8]
   23160:      	str	x1, [x19, #0x188]
   23164:      	str	x0, [x19, #0x190]
   23168:      	str	x22, [x19, #0x17a0]
   2316c:      	ldr	x4, [sp, #0x180]
   23170:      	str	x4, [x19, #0x17a8]
   23174:      	ldur	x24, [sp, #0xe0]
   23178:      	uxtb	w4, w24
   2317c:      	str	x4, [x19, #0x17b8]
   23180:      	ldur	x4, [sp, #0x18]
   23184:      	str	x4, [x19, #0x1858]
   23188:      	str	x25, [x19, #0x1860]
   2318c:      	str	x22, [x19, #0x1868]
   23190:      	ldr	x27, [sp, #0x160]
   23194:      	sub	x5, x27, #0x1
   23198:      	cmp	x27, xzr
   2319c:      	csel	x6, x5, x1, ne
   231a0:      	cmp	x22, x6
   231a4:      	csel	x7, x22, x6, lo
   231a8:      	ldr	x27, [sp, #0x168]
   231ac:      	ldr	x7, [x27, x7, lsl #3]
   231b0:      	str	x7, [x19, #0x1870]
   231b4:      	uxtb	w8, w15
   231b8:      	str	x8, [x19, #0x1880]
   231bc:      	ldur	x15, [sp, #0x18]
   231c0:      	add	x10, x15, #0x1
   231c4:      	str	x10, [x19, #0x1890]
   231c8:      	ldur	x6, [sp, #0x78]
   231cc:      	str	x6, [x19, #0x4c60]
   231d0:      	mov	w13, #0x2166            ; =8550
   231d4:      	movk	w13, #0x1, lsl #16
   231d8:      	sub	x13, x3, x13
   231dc:      	str	x13, [x19, #0x4c68]
   231e0:      	ldur	x4, [sp, #0x80]
   231e4:      	str	x4, [x19, #0x4c70]
   231e8:      	str	x22, [x19, #0x4f70]
   231ec:      	ldr	x1, [sp, #0x180]
   231f0:      	str	x1, [x19, #0x4f78]
   231f4:      	str	x15, [x19, #0x50c0]
   231f8:      	str	x25, [x19, #0x50c8]
   231fc:      	str	x22, [x19, #0x50d0]
   23200:      	str	x7, [x19, #0x50d8]
   23204:      	ldur	x10, [sp, #0x10]
   23208:      	str	x10, [x19, #0x50e0]
   2320c:      	str	x26, [x19, #0x50e8]
   23210:      	str	x28, [x19, #0x50f0]
   23214:      	ldur	x26, [sp, #0x60]
   23218:      	str	x26, [x19, #0x50f8]
   2321c:      	ldur	x25, [sp, #0x68]
   23220:      	str	x25, [x19, #0x5100]
   23224:      	ldur	x1, [sp, #0x48]
   23228:      	str	x1, [x19, #0x5a20]
   2322c:      	add	x1, x11, #0x1
   23230:      	str	x1, [x19, #0x5bb0]
   23234:      	ldur	x25, [sp, #0x88]
   23238:      	str	x25, [x19, #0x5bb8]
   2323c:      	ldur	x10, [sp, #0x90]
   23240:      	str	x10, [x19, #0x5bc0]
   23244:      	ldur	x5, [sp, #0x70]
   23248:      	sub	x3, x5, x13
   2324c:      	mov	w4, #0xc87e             ; =51326
   23250:      	movk	w4, #0x1, lsl #16
   23254:      	msub	x1, x1, x4, x3
   23258:      	str	x1, [x19, #0x5bc8]
   2325c:      	str	x0, [x19, #0x5bd0]
   23260:      	ldur	x27, [sp, #0x20]
   23264:      	str	x27, [x19, #0x5bd8]
   23268:      	ldur	x7, [sp, #0x98]
   2326c:      	str	x7, [x19, #0x5be8]
   23270:      	ldur	x6, [sp, #0xa0]
   23274:      	str	x6, [x19, #0x5bf0]
   23278:      	str	x12, [x19, #0x5c00]
   2327c:      	str	x9, [x19, #0x5c08]
   23280:      	str	x23, [x19, #0x5c18]
   23284:      	str	x2, [x19, #0x5c20]
   23288:      	ldr	x0, [x19, #0x4c60]
   2328c:      	cmp	x0, #0x0
   23290:      	b.ne	0x1f328 <_mech_canonical_program_entry_v1_numeric_1282+0x11a8>
   23294:      	b	0x1f558 <_mech_canonical_program_entry_v1_numeric_1282+0x13d8>
   23298:      	mov	x21, x20
   2329c:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   232a0:      	mov	x21, x20
   232a4:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   232a8:      	mov	x0, #0x531              ; =1329
   232ac:      	ldur	x4, [sp]
   232b0:      	str	x0, [x4, #0x48]
   232b4:      	mov	x7, #0x0                ; =0
   232b8:      	str	x7, [x19, #0x18]
   232bc:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   232c0:      	str	x0, [x19, #0x20]
   232c4:      	mov	x0, #0x1                ; =1
   232c8:      	mov	x21, x0
   232cc:      	str	x0, [x19, #0x30]
   232d0:      	mov	x0, #0x101010101010101  ; =72340172838076673
   232d4:      	str	x0, [x19, #0x38]
   232d8:      	mov	x0, #0x2                ; =2
   232dc:      	str	x0, [x19, #0x40]
   232e0:      	mov	x0, #0x3                ; =3
   232e4:      	str	x0, [x19, #0x48]
   232e8:      	mov	x0, #0x4                ; =4
   232ec:      	str	x0, [x19, #0x50]
   232f0:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   232f4:      	str	x0, [x19, #0x78]
   232f8:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   232fc:      	str	x0, [x19, #0x88]
   23300:      	mov	x0, #0x38               ; =56
   23304:      	str	x0, [x19, #0x90]
   23308:      	mov	x4, #0x3a               ; =58
   2330c:      	str	x4, [x19, #0x98]
   23310:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   23314:      	str	x4, [x19, #0xb0]
   23318:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   2331c:      	str	x4, [x19, #0xb8]
   23320:      	str	x7, [x19, #0x188]
   23324:      	mov	x0, x21
   23328:      	str	x0, [x19, #0x190]
   2332c:      	str	x22, [x19, #0x17a0]
   23330:      	ldr	x0, [sp, #0x180]
   23334:      	str	x0, [x19, #0x17a8]
   23338:      	ldur	x24, [sp, #0xe0]
   2333c:      	uxtb	w8, w24
   23340:      	str	x8, [x19, #0x17b8]
   23344:      	ldur	x0, [sp, #0x18]
   23348:      	str	x0, [x19, #0x1858]
   2334c:      	ldur	x0, [sp, #0xc8]
   23350:      	str	x0, [x19, #0x1860]
   23354:      	str	x22, [x19, #0x1868]
   23358:      	ldr	x27, [sp, #0x160]
   2335c:      	sub	x13, x27, #0x1
   23360:      	cmp	x27, xzr
   23364:      	csel	x13, x13, x7, ne
   23368:      	cmp	x22, x13
   2336c:      	csel	x14, x22, x13, lo
   23370:      	ldr	x27, [sp, #0x168]
   23374:      	ldr	x14, [x27, x14, lsl #3]
   23378:      	str	x14, [x19, #0x1870]
   2337c:      	uxtb	w15, w15
   23380:      	str	x15, [x19, #0x1880]
   23384:      	str	x1, [x19, #0x1898]
   23388:      	ldur	x0, [sp, #0x78]
   2338c:      	str	x0, [x19, #0x4c60]
   23390:      	mov	w1, #0x2166             ; =8550
   23394:      	movk	w1, #0x1, lsl #16
   23398:      	sub	x1, x3, x1
   2339c:      	str	x1, [x19, #0x4c68]
   233a0:      	ldur	x4, [sp, #0x80]
   233a4:      	str	x4, [x19, #0x4c70]
   233a8:      	ldur	x0, [sp, #0x48]
   233ac:      	str	x0, [x19, #0x5a20]
   233b0:      	add	x3, x11, #0x1
   233b4:      	str	x3, [x19, #0x5bb0]
   233b8:      	ldur	x25, [sp, #0x88]
   233bc:      	str	x25, [x19, #0x5bb8]
   233c0:      	ldur	x13, [sp, #0x90]
   233c4:      	str	x13, [x19, #0x5bc0]
   233c8:      	ldur	x5, [sp, #0x70]
   233cc:      	sub	x1, x5, x1
   233d0:      	mov	w4, #0xc87e             ; =51326
   233d4:      	movk	w4, #0x1, lsl #16
   233d8:      	msub	x0, x3, x4, x1
   233dc:      	str	x0, [x19, #0x5bc8]
   233e0:      	mov	x0, x21
   233e4:      	str	x0, [x19, #0x5bd0]
   233e8:      	ldur	x27, [sp, #0x20]
   233ec:      	str	x27, [x19, #0x5bd8]
   233f0:      	ldur	x0, [sp, #0x98]
   233f4:      	str	x0, [x19, #0x5be8]
   233f8:      	ldur	x6, [sp, #0xa0]
   233fc:      	str	x6, [x19, #0x5bf0]
   23400:      	str	x12, [x19, #0x5c00]
   23404:      	str	x9, [x19, #0x5c08]
   23408:      	str	x23, [x19, #0x5c18]
   2340c:      	str	x2, [x19, #0x5c20]
   23410:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   23414:      	mov	x4, #0x532              ; =1330
   23418:      	ldur	x5, [sp]
   2341c:      	str	x4, [x5, #0x48]
   23420:      	mov	x8, #0x0                ; =0
   23424:      	str	x8, [x19, #0x18]
   23428:      	mov	x4, #0x1000000000000000 ; =1152921504606846976
   2342c:      	str	x4, [x19, #0x20]
   23430:      	mov	x7, #0x1                ; =1
   23434:      	str	x7, [x19, #0x30]
   23438:      	mov	x4, #0x101010101010101  ; =72340172838076673
   2343c:      	str	x4, [x19, #0x38]
   23440:      	mov	x20, #0x2               ; =2
   23444:      	str	x20, [x19, #0x40]
   23448:      	mov	x4, #0x3                ; =3
   2344c:      	str	x4, [x19, #0x48]
   23450:      	mov	x4, #0x4                ; =4
   23454:      	str	x4, [x19, #0x50]
   23458:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   2345c:      	str	x4, [x19, #0x78]
   23460:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   23464:      	str	x4, [x19, #0x88]
   23468:      	mov	x4, #0x38               ; =56
   2346c:      	str	x4, [x19, #0x90]
   23470:      	mov	x4, #0x3a               ; =58
   23474:      	str	x4, [x19, #0x98]
   23478:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   2347c:      	str	x4, [x19, #0xb0]
   23480:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   23484:      	str	x4, [x19, #0xb8]
   23488:      	str	x8, [x19, #0x188]
   2348c:      	str	x7, [x19, #0x190]
   23490:      	str	x22, [x19, #0x17a0]
   23494:      	ldr	x4, [sp, #0x180]
   23498:      	str	x4, [x19, #0x17a8]
   2349c:      	ldur	x24, [sp, #0xe0]
   234a0:      	uxtb	w4, w24
   234a4:      	str	x4, [x19, #0x17b8]
   234a8:      	ldur	x15, [sp, #0x18]
   234ac:      	str	x15, [x19, #0x1858]
   234b0:      	ldur	x4, [sp, #0xc8]
   234b4:      	str	x4, [x19, #0x1860]
   234b8:      	str	x22, [x19, #0x1868]
   234bc:      	ldr	x27, [sp, #0x160]
   234c0:      	sub	x4, x27, #0x1
   234c4:      	cmp	x27, xzr
   234c8:      	csel	x4, x4, x8, ne
   234cc:      	cmp	x22, x4
   234d0:      	csel	x4, x22, x4, lo
   234d4:      	ldr	x27, [sp, #0x168]
   234d8:      	ldr	x4, [x27, x4, lsl #3]
   234dc:      	str	x4, [x19, #0x1870]
   234e0:      	ldur	x15, [sp, #0xc0]
   234e4:      	uxtb	w5, w15
   234e8:      	str	x5, [x19, #0x1880]
   234ec:      	str	x1, [x19, #0x1898]
   234f0:      	str	x0, [x19, #0x18a0]
   234f4:      	ldur	x0, [sp, #0x78]
   234f8:      	str	x0, [x19, #0x4c60]
   234fc:      	mov	w5, #0x2166             ; =8550
   23500:      	movk	w5, #0x1, lsl #16
   23504:      	sub	x3, x3, x5
   23508:      	str	x3, [x19, #0x4c68]
   2350c:      	ldur	x0, [sp, #0x80]
   23510:      	str	x0, [x19, #0x4c70]
   23514:      	str	x22, [x19, #0x4f70]
   23518:      	ldr	x0, [sp, #0x180]
   2351c:      	str	x0, [x19, #0x4f78]
   23520:      	ldur	x15, [sp, #0x18]
   23524:      	str	x15, [x19, #0x50c0]
   23528:      	ldur	x8, [sp, #0xc8]
   2352c:      	str	x8, [x19, #0x50c8]
   23530:      	str	x22, [x19, #0x50d0]
   23534:      	str	x4, [x19, #0x50d8]
   23538:      	ldur	x10, [sp, #0x10]
   2353c:      	str	x10, [x19, #0x50e0]
   23540:      	str	x26, [x19, #0x50e8]
   23544:      	ldur	x26, [sp, #0x58]
   23548:      	str	x26, [x19, #0x50f0]
   2354c:      	ldur	x28, [sp, #0x60]
   23550:      	str	x28, [x19, #0x50f8]
   23554:      	ldur	x25, [sp, #0x68]
   23558:      	str	x25, [x19, #0x5100]
   2355c:      	ldur	x0, [sp, #0x48]
   23560:      	str	x0, [x19, #0x5a20]
   23564:      	add	x0, x11, #0x1
   23568:      	str	x0, [x19, #0x5bb0]
   2356c:      	ldur	x25, [sp, #0x88]
   23570:      	str	x25, [x19, #0x5bb8]
   23574:      	ldur	x13, [sp, #0x90]
   23578:      	str	x13, [x19, #0x5bc0]
   2357c:      	ldur	x5, [sp, #0x70]
   23580:      	sub	x1, x5, x3
   23584:      	mov	w3, #0xc87e             ; =51326
   23588:      	movk	w3, #0x1, lsl #16
   2358c:      	msub	x0, x0, x3, x1
   23590:      	str	x0, [x19, #0x5bc8]
   23594:      	str	x7, [x19, #0x5bd0]
   23598:      	ldur	x27, [sp, #0x20]
   2359c:      	str	x27, [x19, #0x5bd8]
   235a0:      	ldur	x1, [sp, #0x98]
   235a4:      	str	x1, [x19, #0x5be8]
   235a8:      	ldur	x6, [sp, #0xa0]
   235ac:      	str	x6, [x19, #0x5bf0]
   235b0:      	str	x12, [x19, #0x5c00]
   235b4:      	str	x9, [x19, #0x5c08]
   235b8:      	str	x23, [x19, #0x5c18]
   235bc:      	str	x2, [x19, #0x5c20]
   235c0:      	ldr	x0, [x19, #0x4c60]
   235c4:      	cmp	x0, #0x0
   235c8:      	b.ne	0x1f604 <_mech_canonical_program_entry_v1_numeric_1282+0x1484>
   235cc:      	b	0x1f82c <_mech_canonical_program_entry_v1_numeric_1282+0x16ac>
   235d0:      	mov	x21, x20
   235d4:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   235d8:      	mov	x21, x20
   235dc:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   235e0:      	mov	x0, #0x534              ; =1332
   235e4:      	ldur	x4, [sp]
   235e8:      	str	x0, [x4, #0x48]
   235ec:      	mov	x7, #0x0                ; =0
   235f0:      	str	x7, [x19, #0x18]
   235f4:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   235f8:      	str	x0, [x19, #0x20]
   235fc:      	mov	x0, #0x1                ; =1
   23600:      	str	x0, [x19, #0x30]
   23604:      	mov	x4, #0x101010101010101  ; =72340172838076673
   23608:      	str	x4, [x19, #0x38]
   2360c:      	mov	x20, #0x2               ; =2
   23610:      	str	x20, [x19, #0x40]
   23614:      	mov	x4, #0x3                ; =3
   23618:      	str	x4, [x19, #0x48]
   2361c:      	mov	x4, #0x4                ; =4
   23620:      	str	x4, [x19, #0x50]
   23624:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   23628:      	str	x4, [x19, #0x78]
   2362c:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   23630:      	str	x4, [x19, #0x88]
   23634:      	mov	x4, #0x38               ; =56
   23638:      	str	x4, [x19, #0x90]
   2363c:      	mov	x4, #0x3a               ; =58
   23640:      	str	x4, [x19, #0x98]
   23644:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   23648:      	str	x4, [x19, #0xb0]
   2364c:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   23650:      	str	x4, [x19, #0xb8]
   23654:      	str	x7, [x19, #0x188]
   23658:      	str	x0, [x19, #0x190]
   2365c:      	str	x22, [x19, #0x17a0]
   23660:      	ldr	x4, [sp, #0x180]
   23664:      	str	x4, [x19, #0x17a8]
   23668:      	ldur	x24, [sp, #0xe0]
   2366c:      	uxtb	w4, w24
   23670:      	str	x4, [x19, #0x17b8]
   23674:      	ldur	x15, [sp, #0x18]
   23678:      	str	x15, [x19, #0x1858]
   2367c:      	ldur	x4, [sp, #0xc8]
   23680:      	str	x4, [x19, #0x1860]
   23684:      	str	x22, [x19, #0x1868]
   23688:      	ldr	x27, [sp, #0x160]
   2368c:      	sub	x4, x27, #0x1
   23690:      	cmp	x27, xzr
   23694:      	csel	x5, x4, x7, ne
   23698:      	cmp	x22, x5
   2369c:      	csel	x6, x22, x5, lo
   236a0:      	ldr	x27, [sp, #0x168]
   236a4:      	ldr	x6, [x27, x6, lsl #3]
   236a8:      	str	x6, [x19, #0x1870]
   236ac:      	ldur	x4, [sp, #0xc0]
   236b0:      	uxtb	w8, w4
   236b4:      	str	x8, [x19, #0x1880]
   236b8:      	ldr	x21, [sp, #0x140]
   236bc:      	sub	x8, x21, #0x1
   236c0:      	cmp	x21, xzr
   236c4:      	csel	x10, x8, x7, ne
   236c8:      	cmp	x1, x10
   236cc:      	csel	x10, x1, x10, lo
   236d0:      	ldr	x21, [sp, #0x148]
   236d4:      	ldr	x10, [x21, x10, lsl #3]
   236d8:      	str	x10, [x19, #0x18a8]
   236dc:      	add	x13, x1, #0x2
   236e0:      	str	x13, [x19, #0x18b0]
   236e4:      	ldur	x1, [sp, #0x78]
   236e8:      	str	x1, [x19, #0x4c60]
   236ec:      	mov	w13, #0x2166            ; =8550
   236f0:      	movk	w13, #0x1, lsl #16
   236f4:      	sub	x13, x3, x13
   236f8:      	str	x13, [x19, #0x4c68]
   236fc:      	ldur	x4, [sp, #0x80]
   23700:      	str	x4, [x19, #0x4c70]
   23704:      	str	x22, [x19, #0x4f70]
   23708:      	ldr	x7, [sp, #0x180]
   2370c:      	str	x7, [x19, #0x4f78]
   23710:      	str	x15, [x19, #0x50c0]
   23714:      	ldur	x1, [sp, #0xc8]
   23718:      	str	x1, [x19, #0x50c8]
   2371c:      	str	x22, [x19, #0x50d0]
   23720:      	str	x6, [x19, #0x50d8]
   23724:      	ldur	x10, [sp, #0x10]
   23728:      	str	x10, [x19, #0x50e0]
   2372c:      	ldur	x25, [sp, #0x50]
   23730:      	str	x25, [x19, #0x50e8]
   23734:      	ldur	x26, [sp, #0x58]
   23738:      	str	x26, [x19, #0x50f0]
   2373c:      	ldur	x28, [sp, #0x60]
   23740:      	str	x28, [x19, #0x50f8]
   23744:      	ldur	x25, [sp, #0x68]
   23748:      	str	x25, [x19, #0x5100]
   2374c:      	ldur	x1, [sp, #0x48]
   23750:      	str	x1, [x19, #0x5a20]
   23754:      	add	x1, x11, #0x1
   23758:      	str	x1, [x19, #0x5bb0]
   2375c:      	ldur	x25, [sp, #0x88]
   23760:      	str	x25, [x19, #0x5bb8]
   23764:      	ldur	x3, [sp, #0x90]
   23768:      	str	x3, [x19, #0x5bc0]
   2376c:      	ldur	x5, [sp, #0x70]
   23770:      	sub	x3, x5, x13
   23774:      	mov	w4, #0xc87e             ; =51326
   23778:      	movk	w4, #0x1, lsl #16
   2377c:      	msub	x1, x1, x4, x3
   23780:      	str	x1, [x19, #0x5bc8]
   23784:      	str	x0, [x19, #0x5bd0]
   23788:      	ldur	x27, [sp, #0x20]
   2378c:      	str	x27, [x19, #0x5bd8]
   23790:      	ldur	x0, [sp, #0x98]
   23794:      	str	x0, [x19, #0x5be8]
   23798:      	ldur	x6, [sp, #0xa0]
   2379c:      	str	x6, [x19, #0x5bf0]
   237a0:      	str	x12, [x19, #0x5c00]
   237a4:      	str	x9, [x19, #0x5c08]
   237a8:      	str	x23, [x19, #0x5c18]
   237ac:      	str	x2, [x19, #0x5c20]
   237b0:      	ldr	x0, [x19, #0x4c60]
   237b4:      	cmp	x0, #0x0
   237b8:      	b.ne	0x1f898 <_mech_canonical_program_entry_v1_numeric_1282+0x1718>
   237bc:      	b	0x1fad0 <_mech_canonical_program_entry_v1_numeric_1282+0x1950>
   237c0:      	mov	x21, x20
   237c4:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   237c8:      	mov	x21, x20
   237cc:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   237d0:      	mov	x21, x20
   237d4:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   237d8:      	mov	x0, #0x54e              ; =1358
   237dc:      	ldur	x1, [sp]
   237e0:      	str	x0, [x1, #0x48]
   237e4:      	mov	x1, #0x0                ; =0
   237e8:      	str	x1, [x19, #0x18]
   237ec:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   237f0:      	str	x0, [x19, #0x20]
   237f4:      	mov	x0, #0x1                ; =1
   237f8:      	str	x0, [x19, #0x30]
   237fc:      	mov	x4, #0x101010101010101  ; =72340172838076673
   23800:      	str	x4, [x19, #0x38]
   23804:      	mov	x20, #0x2               ; =2
   23808:      	str	x20, [x19, #0x40]
   2380c:      	mov	x4, #0x3                ; =3
   23810:      	str	x4, [x19, #0x48]
   23814:      	mov	x4, #0x4                ; =4
   23818:      	str	x4, [x19, #0x50]
   2381c:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   23820:      	str	x4, [x19, #0x78]
   23824:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   23828:      	str	x4, [x19, #0x88]
   2382c:      	mov	x4, #0x38               ; =56
   23830:      	str	x4, [x19, #0x90]
   23834:      	mov	x4, #0x3a               ; =58
   23838:      	str	x4, [x19, #0x98]
   2383c:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   23840:      	str	x4, [x19, #0xb0]
   23844:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   23848:      	str	x4, [x19, #0xb8]
   2384c:      	str	x1, [x19, #0x188]
   23850:      	str	x0, [x19, #0x190]
   23854:      	str	x22, [x19, #0x17a0]
   23858:      	ldr	x4, [sp, #0x180]
   2385c:      	str	x4, [x19, #0x17a8]
   23860:      	ldur	x24, [sp, #0xe0]
   23864:      	uxtb	w4, w24
   23868:      	str	x4, [x19, #0x17b8]
   2386c:      	ldur	x4, [sp, #0x18]
   23870:      	str	x4, [x19, #0x1858]
   23874:      	ldur	x4, [sp, #0xc8]
   23878:      	str	x4, [x19, #0x1860]
   2387c:      	str	x22, [x19, #0x1868]
   23880:      	ldr	x27, [sp, #0x160]
   23884:      	sub	x4, x27, #0x1
   23888:      	cmp	x27, xzr
   2388c:      	csel	x1, x4, x1, ne
   23890:      	cmp	x22, x1
   23894:      	csel	x1, x22, x1, lo
   23898:      	ldr	x27, [sp, #0x168]
   2389c:      	ldr	x1, [x27, x1, lsl #3]
   238a0:      	str	x1, [x19, #0x1870]
   238a4:      	ldur	x4, [sp, #0xc0]
   238a8:      	uxtb	w4, w4
   238ac:      	str	x4, [x19, #0x1880]
   238b0:      	str	x7, [x19, #0x1918]
   238b4:      	str	x3, [x19, #0x1920]
   238b8:      	str	x22, [x19, #0x1928]
   238bc:      	str	x1, [x19, #0x1930]
   238c0:      	uxtb	w4, w6
   238c4:      	str	x4, [x19, #0x1940]
   238c8:      	add	x4, x7, #0x1
   238cc:      	str	x4, [x19, #0x1950]
   238d0:      	ldur	x4, [sp, #0x78]
   238d4:      	str	x4, [x19, #0x4c60]
   238d8:      	mov	w4, #0xdc1e             ; =56350
   238dc:      	movk	w4, #0x2, lsl #16
   238e0:      	sub	x4, x13, x4
   238e4:      	str	x4, [x19, #0x4c68]
   238e8:      	ldur	x13, [sp, #0x80]
   238ec:      	str	x13, [x19, #0x4c70]
   238f0:      	str	x22, [x19, #0x4f70]
   238f4:      	ldr	x13, [sp, #0x180]
   238f8:      	str	x13, [x19, #0x4f78]
   238fc:      	ldur	x5, [sp, #0x18]
   23900:      	str	x5, [x19, #0x50c0]
   23904:      	ldur	x5, [sp, #0xc8]
   23908:      	str	x5, [x19, #0x50c8]
   2390c:      	str	x22, [x19, #0x50d0]
   23910:      	str	x1, [x19, #0x50d8]
   23914:      	ldur	x5, [sp, #0x10]
   23918:      	str	x5, [x19, #0x50e0]
   2391c:      	ldur	x25, [sp, #0x50]
   23920:      	str	x25, [x19, #0x50e8]
   23924:      	ldur	x5, [sp, #0x58]
   23928:      	str	x5, [x19, #0x50f0]
   2392c:      	ldur	x5, [sp, #0x60]
   23930:      	str	x5, [x19, #0x50f8]
   23934:      	ldur	x25, [sp, #0x68]
   23938:      	str	x25, [x19, #0x5100]
   2393c:      	str	x7, [x19, #0x52a8]
   23940:      	str	x3, [x19, #0x52b0]
   23944:      	str	x22, [x19, #0x52b8]
   23948:      	str	x1, [x19, #0x52c0]
   2394c:      	str	x15, [x19, #0x52c8]
   23950:      	str	x10, [x19, #0x52d0]
   23954:      	str	x26, [x19, #0x52d8]
   23958:      	str	x28, [x19, #0x52e0]
   2395c:      	ldur	x1, [sp, #0x28]
   23960:      	str	x1, [x19, #0x52e8]
   23964:      	ldur	x13, [sp, #0x48]
   23968:      	str	x13, [x19, #0x5a20]
   2396c:      	add	x1, x11, #0x1
   23970:      	str	x1, [x19, #0x5bb0]
   23974:      	ldur	x25, [sp, #0x88]
   23978:      	str	x25, [x19, #0x5bb8]
   2397c:      	ldur	x13, [sp, #0x90]
   23980:      	str	x13, [x19, #0x5bc0]
   23984:      	ldur	x5, [sp, #0x70]
   23988:      	sub	x3, x5, x4
   2398c:      	mov	w4, #0xc87e             ; =51326
   23990:      	movk	w4, #0x1, lsl #16
   23994:      	msub	x1, x1, x4, x3
   23998:      	str	x1, [x19, #0x5bc8]
   2399c:      	str	x0, [x19, #0x5bd0]
   239a0:      	ldur	x27, [sp, #0x20]
   239a4:      	str	x27, [x19, #0x5bd8]
   239a8:      	str	x0, [x19, #0x5be8]
   239ac:      	ldur	x6, [sp, #0x30]
   239b0:      	str	x6, [x19, #0x5bf0]
   239b4:      	str	x12, [x19, #0x5c00]
   239b8:      	str	x9, [x19, #0x5c08]
   239bc:      	str	x23, [x19, #0x5c18]
   239c0:      	str	x2, [x19, #0x5c20]
   239c4:      	ldr	x0, [x19, #0x4c60]
   239c8:      	cmp	x0, #0x0
   239cc:      	b.ne	0x20030 <_mech_canonical_program_entry_v1_numeric_1282+0x1eb0>
   239d0:      	b	0x20268 <_mech_canonical_program_entry_v1_numeric_1282+0x20e8>
   239d4:      	mov	x21, x20
   239d8:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   239dc:      	mov	x21, x20
   239e0:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   239e4:      	mov	x0, #0x554              ; =1364
   239e8:      	ldur	x1, [sp]
   239ec:      	str	x0, [x1, #0x48]
   239f0:      	mov	x1, #0x0                ; =0
   239f4:      	str	x1, [x19, #0x18]
   239f8:      	mov	x4, #0x1000000000000000 ; =1152921504606846976
   239fc:      	str	x4, [x19, #0x20]
   23a00:      	mov	x0, #0x1                ; =1
   23a04:      	mov	x21, x0
   23a08:      	str	x0, [x19, #0x30]
   23a0c:      	mov	x4, #0x101010101010101  ; =72340172838076673
   23a10:      	str	x4, [x19, #0x38]
   23a14:      	mov	x4, #0x2                ; =2
   23a18:      	str	x4, [x19, #0x40]
   23a1c:      	mov	x5, #0x3                ; =3
   23a20:      	str	x5, [x19, #0x48]
   23a24:      	mov	x8, #0x4                ; =4
   23a28:      	str	x8, [x19, #0x50]
   23a2c:      	mov	x8, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   23a30:      	str	x8, [x19, #0x78]
   23a34:      	mov	x8, #0x3333333333333333 ; =3689348814741910323
   23a38:      	str	x8, [x19, #0x88]
   23a3c:      	mov	x10, #0x38              ; =56
   23a40:      	str	x10, [x19, #0x90]
   23a44:      	mov	x10, #0x3a              ; =58
   23a48:      	str	x10, [x19, #0x98]
   23a4c:      	mov	x14, #0x5555555555555555 ; =6148914691236517205
   23a50:      	str	x14, [x19, #0xb0]
   23a54:      	mov	x14, #0x3ffffffffffffff ; =288230376151711743
   23a58:      	str	x14, [x19, #0xb8]
   23a5c:      	str	x1, [x19, #0x188]
   23a60:      	str	x0, [x19, #0x190]
   23a64:      	str	x22, [x19, #0x17a0]
   23a68:      	ldr	x0, [sp, #0x180]
   23a6c:      	str	x0, [x19, #0x17a8]
   23a70:      	ldur	x24, [sp, #0xe0]
   23a74:      	uxtb	w0, w24
   23a78:      	str	x0, [x19, #0x17b8]
   23a7c:      	ldur	x15, [sp, #0x18]
   23a80:      	str	x15, [x19, #0x1858]
   23a84:      	ldur	x0, [sp, #0xc8]
   23a88:      	str	x0, [x19, #0x1860]
   23a8c:      	str	x22, [x19, #0x1868]
   23a90:      	ldr	x27, [sp, #0x160]
   23a94:      	sub	x4, x27, #0x1
   23a98:      	cmp	x27, xzr
   23a9c:      	csel	x1, x4, x1, ne
   23aa0:      	cmp	x22, x1
   23aa4:      	csel	x0, x22, x1, lo
   23aa8:      	ldr	x27, [sp, #0x168]
   23aac:      	ldr	x1, [x27, x0, lsl #3]
   23ab0:      	str	x1, [x19, #0x1870]
   23ab4:      	ldur	x0, [sp, #0xc0]
   23ab8:      	uxtb	w0, w0
   23abc:      	str	x0, [x19, #0x1880]
   23ac0:      	str	x7, [x19, #0x1918]
   23ac4:      	str	x3, [x19, #0x1920]
   23ac8:      	str	x22, [x19, #0x1928]
   23acc:      	str	x1, [x19, #0x1930]
   23ad0:      	uxtb	w0, w6
   23ad4:      	str	x0, [x19, #0x1940]
   23ad8:      	str	x25, [x19, #0x1958]
   23adc:      	ldur	x0, [sp, #0x78]
   23ae0:      	str	x0, [x19, #0x4c60]
   23ae4:      	mov	w1, #0xdc1e             ; =56350
   23ae8:      	movk	w1, #0x2, lsl #16
   23aec:      	sub	x1, x13, x1
   23af0:      	str	x1, [x19, #0x4c68]
   23af4:      	ldur	x4, [sp, #0x80]
   23af8:      	str	x4, [x19, #0x4c70]
   23afc:      	ldur	x0, [sp, #0x48]
   23b00:      	str	x0, [x19, #0x5a20]
   23b04:      	add	x3, x11, #0x1
   23b08:      	str	x3, [x19, #0x5bb0]
   23b0c:      	ldur	x25, [sp, #0x88]
   23b10:      	str	x25, [x19, #0x5bb8]
   23b14:      	ldur	x13, [sp, #0x90]
   23b18:      	str	x13, [x19, #0x5bc0]
   23b1c:      	ldur	x5, [sp, #0x70]
   23b20:      	sub	x1, x5, x1
   23b24:      	mov	w4, #0xc87e             ; =51326
   23b28:      	movk	w4, #0x1, lsl #16
   23b2c:      	msub	x0, x3, x4, x1
   23b30:      	str	x0, [x19, #0x5bc8]
   23b34:      	mov	x0, x21
   23b38:      	str	x0, [x19, #0x5bd0]
   23b3c:      	ldur	x27, [sp, #0x20]
   23b40:      	str	x27, [x19, #0x5bd8]
   23b44:      	str	x0, [x19, #0x5be8]
   23b48:      	ldur	x6, [sp, #0x30]
   23b4c:      	str	x6, [x19, #0x5bf0]
   23b50:      	str	x12, [x19, #0x5c00]
   23b54:      	str	x9, [x19, #0x5c08]
   23b58:      	str	x23, [x19, #0x5c18]
   23b5c:      	str	x2, [x19, #0x5c20]
   23b60:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   23b64:      	mov	x0, #0x555              ; =1365
   23b68:      	ldur	x4, [sp]
   23b6c:      	str	x0, [x4, #0x48]
   23b70:      	mov	x14, #0x0               ; =0
   23b74:      	str	x14, [x19, #0x18]
   23b78:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   23b7c:      	str	x0, [x19, #0x20]
   23b80:      	mov	x0, #0x1                ; =1
   23b84:      	str	x0, [x19, #0x30]
   23b88:      	mov	x4, #0x101010101010101  ; =72340172838076673
   23b8c:      	str	x4, [x19, #0x38]
   23b90:      	mov	x20, #0x2               ; =2
   23b94:      	str	x20, [x19, #0x40]
   23b98:      	mov	x4, #0x3                ; =3
   23b9c:      	str	x4, [x19, #0x48]
   23ba0:      	mov	x4, #0x4                ; =4
   23ba4:      	str	x4, [x19, #0x50]
   23ba8:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   23bac:      	str	x4, [x19, #0x78]
   23bb0:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   23bb4:      	str	x4, [x19, #0x88]
   23bb8:      	mov	x4, #0x38               ; =56
   23bbc:      	str	x4, [x19, #0x90]
   23bc0:      	mov	x4, #0x3a               ; =58
   23bc4:      	str	x4, [x19, #0x98]
   23bc8:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   23bcc:      	str	x4, [x19, #0xb0]
   23bd0:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   23bd4:      	str	x4, [x19, #0xb8]
   23bd8:      	str	x14, [x19, #0x188]
   23bdc:      	str	x0, [x19, #0x190]
   23be0:      	str	x22, [x19, #0x17a0]
   23be4:      	ldr	x4, [sp, #0x180]
   23be8:      	str	x4, [x19, #0x17a8]
   23bec:      	ldur	x24, [sp, #0xe0]
   23bf0:      	uxtb	w4, w24
   23bf4:      	str	x4, [x19, #0x17b8]
   23bf8:      	ldur	x4, [sp, #0x18]
   23bfc:      	str	x4, [x19, #0x1858]
   23c00:      	ldur	x4, [sp, #0xc8]
   23c04:      	str	x4, [x19, #0x1860]
   23c08:      	str	x22, [x19, #0x1868]
   23c0c:      	ldr	x27, [sp, #0x160]
   23c10:      	sub	x4, x27, #0x1
   23c14:      	cmp	x27, xzr
   23c18:      	csel	x14, x4, x14, ne
   23c1c:      	cmp	x22, x14
   23c20:      	csel	x14, x22, x14, lo
   23c24:      	ldr	x27, [sp, #0x168]
   23c28:      	ldr	x14, [x27, x14, lsl #3]
   23c2c:      	str	x14, [x19, #0x1870]
   23c30:      	ldur	x4, [sp, #0xc0]
   23c34:      	uxtb	w4, w4
   23c38:      	str	x4, [x19, #0x1880]
   23c3c:      	str	x7, [x19, #0x1918]
   23c40:      	str	x3, [x19, #0x1920]
   23c44:      	str	x22, [x19, #0x1928]
   23c48:      	str	x14, [x19, #0x1930]
   23c4c:      	uxtb	w4, w6
   23c50:      	str	x4, [x19, #0x1940]
   23c54:      	str	x25, [x19, #0x1958]
   23c58:      	str	x8, [x19, #0x1970]
   23c5c:      	ldur	x8, [sp, #0x78]
   23c60:      	str	x8, [x19, #0x4c60]
   23c64:      	mov	w4, #0xdc1e             ; =56350
   23c68:      	movk	w4, #0x2, lsl #16
   23c6c:      	sub	x4, x13, x4
   23c70:      	str	x4, [x19, #0x4c68]
   23c74:      	ldur	x5, [sp, #0x80]
   23c78:      	str	x5, [x19, #0x4c70]
   23c7c:      	str	x22, [x19, #0x4f70]
   23c80:      	ldr	x5, [sp, #0x180]
   23c84:      	str	x5, [x19, #0x4f78]
   23c88:      	ldur	x5, [sp, #0x18]
   23c8c:      	str	x5, [x19, #0x50c0]
   23c90:      	ldur	x5, [sp, #0xc8]
   23c94:      	str	x5, [x19, #0x50c8]
   23c98:      	str	x22, [x19, #0x50d0]
   23c9c:      	str	x14, [x19, #0x50d8]
   23ca0:      	ldur	x5, [sp, #0x10]
   23ca4:      	str	x5, [x19, #0x50e0]
   23ca8:      	ldur	x25, [sp, #0x50]
   23cac:      	str	x25, [x19, #0x50e8]
   23cb0:      	ldur	x5, [sp, #0x58]
   23cb4:      	str	x5, [x19, #0x50f0]
   23cb8:      	ldur	x5, [sp, #0x60]
   23cbc:      	str	x5, [x19, #0x50f8]
   23cc0:      	ldur	x25, [sp, #0x68]
   23cc4:      	str	x25, [x19, #0x5100]
   23cc8:      	str	x7, [x19, #0x52a8]
   23ccc:      	str	x3, [x19, #0x52b0]
   23cd0:      	str	x22, [x19, #0x52b8]
   23cd4:      	str	x14, [x19, #0x52c0]
   23cd8:      	str	x15, [x19, #0x52c8]
   23cdc:      	str	x10, [x19, #0x52d0]
   23ce0:      	str	x26, [x19, #0x52d8]
   23ce4:      	str	x28, [x19, #0x52e0]
   23ce8:      	str	x1, [x19, #0x52e8]
   23cec:      	ldur	x1, [sp, #0x48]
   23cf0:      	str	x1, [x19, #0x5a20]
   23cf4:      	add	x1, x11, #0x1
   23cf8:      	str	x1, [x19, #0x5bb0]
   23cfc:      	ldur	x25, [sp, #0x88]
   23d00:      	str	x25, [x19, #0x5bb8]
   23d04:      	ldur	x13, [sp, #0x90]
   23d08:      	str	x13, [x19, #0x5bc0]
   23d0c:      	ldur	x5, [sp, #0x70]
   23d10:      	sub	x3, x5, x4
   23d14:      	mov	w4, #0xc87e             ; =51326
   23d18:      	movk	w4, #0x1, lsl #16
   23d1c:      	msub	x1, x1, x4, x3
   23d20:      	str	x1, [x19, #0x5bc8]
   23d24:      	str	x0, [x19, #0x5bd0]
   23d28:      	ldur	x27, [sp, #0x20]
   23d2c:      	str	x27, [x19, #0x5bd8]
   23d30:      	str	x0, [x19, #0x5be8]
   23d34:      	ldur	x6, [sp, #0x30]
   23d38:      	str	x6, [x19, #0x5bf0]
   23d3c:      	str	x12, [x19, #0x5c00]
   23d40:      	str	x9, [x19, #0x5c08]
   23d44:      	str	x23, [x19, #0x5c18]
   23d48:      	str	x2, [x19, #0x5c20]
   23d4c:      	ldr	x0, [x19, #0x4c60]
   23d50:      	cmp	x0, #0x0
   23d54:      	b.ne	0x2032c <_mech_canonical_program_entry_v1_numeric_1282+0x21ac>
   23d58:      	b	0x20538 <_mech_canonical_program_entry_v1_numeric_1282+0x23b8>
   23d5c:      	mov	x21, x20
   23d60:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   23d64:      	mov	x21, x20
   23d68:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   23d6c:      	mov	x0, #0x5e8              ; =1512
   23d70:      	ldur	x1, [sp]
   23d74:      	str	x0, [x1, #0x48]
   23d78:      	mov	x0, #0x0                ; =0
   23d7c:      	str	x0, [x19, #0x18]
   23d80:      	mov	x1, #0x1000000000000000 ; =1152921504606846976
   23d84:      	str	x1, [x19, #0x20]
   23d88:      	mov	x1, #0x1                ; =1
   23d8c:      	str	x1, [x19, #0x30]
   23d90:      	mov	x4, #0x101010101010101  ; =72340172838076673
   23d94:      	str	x4, [x19, #0x38]
   23d98:      	mov	x27, #0x2               ; =2
   23d9c:      	str	x27, [x19, #0x40]
   23da0:      	mov	x4, #0x3                ; =3
   23da4:      	str	x4, [x19, #0x48]
   23da8:      	mov	x4, #0x4                ; =4
   23dac:      	str	x4, [x19, #0x50]
   23db0:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   23db4:      	str	x4, [x19, #0x78]
   23db8:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   23dbc:      	str	x4, [x19, #0x88]
   23dc0:      	mov	x4, #0x38               ; =56
   23dc4:      	str	x4, [x19, #0x90]
   23dc8:      	mov	x4, #0x3a               ; =58
   23dcc:      	str	x4, [x19, #0x98]
   23dd0:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   23dd4:      	str	x4, [x19, #0xb0]
   23dd8:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   23ddc:      	str	x4, [x19, #0xb8]
   23de0:      	str	x0, [x19, #0x188]
   23de4:      	str	x1, [x19, #0x190]
   23de8:      	str	x22, [x19, #0x17a0]
   23dec:      	ldr	x1, [sp, #0x180]
   23df0:      	str	x1, [x19, #0x17a8]
   23df4:      	ldur	x24, [sp, #0xe0]
   23df8:      	uxtb	w1, w24
   23dfc:      	str	x1, [x19, #0x17b8]
   23e00:      	ldur	x1, [sp, #0xd8]
   23e04:      	str	x1, [x19, #0x1c00]
   23e08:      	ldur	x1, [sp, #0x78]
   23e0c:      	str	x1, [x19, #0x4c60]
   23e10:      	str	x3, [x19, #0x4c68]
   23e14:      	ldur	x4, [sp, #0x80]
   23e18:      	str	x4, [x19, #0x4c70]
   23e1c:      	str	x22, [x19, #0x4f70]
   23e20:      	ldr	x22, [sp, #0x180]
   23e24:      	str	x22, [x19, #0x4f78]
   23e28:      	ldur	x1, [sp, #0x48]
   23e2c:      	str	x1, [x19, #0x5a20]
   23e30:      	add	x1, x11, #0x1
   23e34:      	str	x1, [x19, #0x5bb0]
   23e38:      	ldur	x25, [sp, #0x88]
   23e3c:      	str	x25, [x19, #0x5bb8]
   23e40:      	ldur	x13, [sp, #0x90]
   23e44:      	str	x13, [x19, #0x5bc0]
   23e48:      	ldur	x5, [sp, #0x70]
   23e4c:      	sub	x3, x5, x3
   23e50:      	mov	w4, #0xc87e             ; =51326
   23e54:      	movk	w4, #0x1, lsl #16
   23e58:      	msub	x1, x1, x4, x3
   23e5c:      	str	x1, [x19, #0x5bc8]
   23e60:      	str	x0, [x19, #0x5bd0]
   23e64:      	str	x0, [x19, #0x5bd8]
   23e68:      	ldur	x14, [sp, #0x98]
   23e6c:      	str	x14, [x19, #0x5be8]
   23e70:      	ldur	x6, [sp, #0xa0]
   23e74:      	str	x6, [x19, #0x5bf0]
   23e78:      	str	x12, [x19, #0x5c00]
   23e7c:      	str	x9, [x19, #0x5c08]
   23e80:      	str	x23, [x19, #0x5c18]
   23e84:      	str	x2, [x19, #0x5c20]
   23e88:      	ldr	x0, [x19, #0x4c60]
   23e8c:      	cmp	x0, #0x0
   23e90:      	b.ne	0x207bc <_mech_canonical_program_entry_v1_numeric_1282+0x263c>
   23e94:      	b	0x209c8 <_mech_canonical_program_entry_v1_numeric_1282+0x2848>
   23e98:      	mov	x21, x27
   23e9c:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   23ea0:      	mov	x21, x27
   23ea4:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   23ea8:      	mov	x13, #0x5ea             ; =1514
   23eac:      	ldur	x7, [sp]
   23eb0:      	str	x13, [x7, #0x48]
   23eb4:      	mov	x14, #0x0               ; =0
   23eb8:      	str	x14, [x19, #0x18]
   23ebc:      	mov	x15, #0x1000000000000000 ; =1152921504606846976
   23ec0:      	str	x15, [x19, #0x20]
   23ec4:      	mov	x0, #0x1                ; =1
   23ec8:      	str	x0, [x19, #0x30]
   23ecc:      	mov	x1, #0x101010101010101  ; =72340172838076673
   23ed0:      	str	x1, [x19, #0x38]
   23ed4:      	mov	x20, #0x2               ; =2
   23ed8:      	str	x20, [x19, #0x40]
   23edc:      	mov	x1, #0x3                ; =3
   23ee0:      	str	x1, [x19, #0x48]
   23ee4:      	mov	x1, #0x4                ; =4
   23ee8:      	str	x1, [x19, #0x50]
   23eec:      	mov	x1, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   23ef0:      	str	x1, [x19, #0x78]
   23ef4:      	mov	x1, #0x3333333333333333 ; =3689348814741910323
   23ef8:      	str	x1, [x19, #0x88]
   23efc:      	mov	x1, #0x38               ; =56
   23f00:      	str	x1, [x19, #0x90]
   23f04:      	mov	x1, #0x3a               ; =58
   23f08:      	str	x1, [x19, #0x98]
   23f0c:      	mov	x1, #0x5555555555555555 ; =6148914691236517205
   23f10:      	str	x1, [x19, #0xb0]
   23f14:      	mov	x1, #0x3ffffffffffffff  ; =288230376151711743
   23f18:      	str	x1, [x19, #0xb8]
   23f1c:      	str	x14, [x19, #0x188]
   23f20:      	str	x0, [x19, #0x190]
   23f24:      	str	x22, [x19, #0x17a0]
   23f28:      	ldr	x0, [sp, #0x180]
   23f2c:      	str	x0, [x19, #0x17a8]
   23f30:      	ldur	x24, [sp, #0xe0]
   23f34:      	uxtb	w0, w24
   23f38:      	str	x0, [x19, #0x17b8]
   23f3c:      	ldr	x25, [sp, #0x120]
   23f40:      	sub	x0, x25, #0x1
   23f44:      	cmp	x25, xzr
   23f48:      	csel	x0, x0, x14, ne
   23f4c:      	cmp	x22, x0
   23f50:      	csel	x0, x22, x0, lo
   23f54:      	ldr	x25, [sp, #0x128]
   23f58:      	ldr	x0, [x25, x0, lsl #3]
   23f5c:      	str	x0, [x19, #0x1c08]
   23f60:      	add	x0, x22, #0x2
   23f64:      	str	x0, [x19, #0x1c10]
   23f68:      	ldur	x0, [sp, #0x78]
   23f6c:      	str	x0, [x19, #0x4c60]
   23f70:      	str	x3, [x19, #0x4c68]
   23f74:      	ldur	x4, [sp, #0x80]
   23f78:      	str	x4, [x19, #0x4c70]
   23f7c:      	str	x22, [x19, #0x4f70]
   23f80:      	ldr	x22, [sp, #0x180]
   23f84:      	str	x22, [x19, #0x4f78]
   23f88:      	ldur	x0, [sp, #0x48]
   23f8c:      	str	x0, [x19, #0x5a20]
   23f90:      	add	x0, x11, #0x1
   23f94:      	str	x0, [x19, #0x5bb0]
   23f98:      	ldur	x25, [sp, #0x88]
   23f9c:      	str	x25, [x19, #0x5bb8]
   23fa0:      	ldur	x13, [sp, #0x90]
   23fa4:      	str	x13, [x19, #0x5bc0]
   23fa8:      	ldur	x5, [sp, #0x70]
   23fac:      	sub	x1, x5, x3
   23fb0:      	mov	w3, #0xc87e             ; =51326
   23fb4:      	movk	w3, #0x1, lsl #16
   23fb8:      	msub	x0, x0, x3, x1
   23fbc:      	str	x0, [x19, #0x5bc8]
   23fc0:      	str	x14, [x19, #0x5bd0]
   23fc4:      	str	x14, [x19, #0x5bd8]
   23fc8:      	ldur	x0, [sp, #0x98]
   23fcc:      	str	x0, [x19, #0x5be8]
   23fd0:      	ldur	x6, [sp, #0xa0]
   23fd4:      	str	x6, [x19, #0x5bf0]
   23fd8:      	str	x12, [x19, #0x5c00]
   23fdc:      	str	x9, [x19, #0x5c08]
   23fe0:      	str	x23, [x19, #0x5c18]
   23fe4:      	str	x2, [x19, #0x5c20]
   23fe8:      	ldr	x0, [x19, #0x4c60]
   23fec:      	cmp	x0, #0x0
   23ff0:      	b.ne	0x20a3c <_mech_canonical_program_entry_v1_numeric_1282+0x28bc>
   23ff4:      	b	0x20c68 <_mech_canonical_program_entry_v1_numeric_1282+0x2ae8>
   23ff8:      	mov	x21, x20
   23ffc:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   24000:      	mov	x21, x20
   24004:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   24008:      	mov	x21, x20
   2400c:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   24010:      	mov	x0, #0x604              ; =1540
   24014:      	ldur	x4, [sp]
   24018:      	str	x0, [x4, #0x48]
   2401c:      	mov	x7, #0x0                ; =0
   24020:      	str	x7, [x19, #0x18]
   24024:      	str	x1, [x19, #0x20]
   24028:      	mov	x0, #0x1                ; =1
   2402c:      	mov	x21, x0
   24030:      	str	x0, [x19, #0x30]
   24034:      	mov	x0, #0x101010101010101  ; =72340172838076673
   24038:      	str	x0, [x19, #0x38]
   2403c:      	mov	x0, #0x2                ; =2
   24040:      	str	x0, [x19, #0x40]
   24044:      	mov	x0, #0x3                ; =3
   24048:      	str	x0, [x19, #0x48]
   2404c:      	mov	x0, #0x4                ; =4
   24050:      	str	x0, [x19, #0x50]
   24054:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   24058:      	str	x0, [x19, #0x78]
   2405c:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   24060:      	str	x0, [x19, #0x88]
   24064:      	mov	x0, #0x38               ; =56
   24068:      	str	x0, [x19, #0x90]
   2406c:      	mov	x0, #0x3a               ; =58
   24070:      	str	x0, [x19, #0x98]
   24074:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   24078:      	str	x0, [x19, #0xb0]
   2407c:      	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
   24080:      	str	x0, [x19, #0xb8]
   24084:      	str	x7, [x19, #0x188]
   24088:      	mov	x0, x21
   2408c:      	str	x0, [x19, #0x190]
   24090:      	str	x22, [x19, #0x17a0]
   24094:      	ldr	x13, [sp, #0x180]
   24098:      	str	x13, [x19, #0x17a8]
   2409c:      	ldur	x24, [sp, #0xe0]
   240a0:      	uxtb	w0, w24
   240a4:      	str	x0, [x19, #0x17b8]
   240a8:      	str	x12, [x19, #0x1c70]
   240ac:      	str	x9, [x19, #0x1c78]
   240b0:      	str	x22, [x19, #0x1c80]
   240b4:      	str	x10, [x19, #0x1ca8]
   240b8:      	ldur	x0, [sp, #0x78]
   240bc:      	str	x0, [x19, #0x4c60]
   240c0:      	mov	w1, #0x2646             ; =9798
   240c4:      	movk	w1, #0x1, lsl #16
   240c8:      	sub	x1, x3, x1
   240cc:      	str	x1, [x19, #0x4c68]
   240d0:      	ldur	x4, [sp, #0x80]
   240d4:      	str	x4, [x19, #0x4c70]
   240d8:      	ldur	x3, [sp, #0x48]
   240dc:      	str	x3, [x19, #0x5a20]
   240e0:      	add	x3, x11, #0x1
   240e4:      	str	x3, [x19, #0x5bb0]
   240e8:      	ldur	x25, [sp, #0x88]
   240ec:      	str	x25, [x19, #0x5bb8]
   240f0:      	ldur	x13, [sp, #0x90]
   240f4:      	str	x13, [x19, #0x5bc0]
   240f8:      	ldur	x5, [sp, #0x70]
   240fc:      	sub	x1, x5, x1
   24100:      	mov	w4, #0xc87e             ; =51326
   24104:      	movk	w4, #0x1, lsl #16
   24108:      	msub	x0, x3, x4, x1
   2410c:      	str	x0, [x19, #0x5bc8]
   24110:      	str	x7, [x19, #0x5bd0]
   24114:      	str	x7, [x19, #0x5bd8]
   24118:      	ldur	x0, [sp, #0x98]
   2411c:      	str	x0, [x19, #0x5be8]
   24120:      	ldur	x6, [sp, #0xa0]
   24124:      	str	x6, [x19, #0x5bf0]
   24128:      	mov	x0, x21
   2412c:      	str	x0, [x19, #0x5c00]
   24130:      	ldur	x14, [sp, #0x38]
   24134:      	str	x14, [x19, #0x5c08]
   24138:      	str	x23, [x19, #0x5c18]
   2413c:      	str	x2, [x19, #0x5c20]
   24140:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   24144:      	mov	x4, #0x605              ; =1541
   24148:      	ldur	x5, [sp]
   2414c:      	str	x4, [x5, #0x48]
   24150:      	mov	x7, #0x0                ; =0
   24154:      	str	x7, [x19, #0x18]
   24158:      	str	x1, [x19, #0x20]
   2415c:      	mov	x13, #0x1               ; =1
   24160:      	str	x13, [x19, #0x30]
   24164:      	mov	x5, #0x101010101010101  ; =72340172838076673
   24168:      	str	x5, [x19, #0x38]
   2416c:      	mov	x20, #0x2               ; =2
   24170:      	str	x20, [x19, #0x40]
   24174:      	mov	x8, #0x3                ; =3
   24178:      	str	x8, [x19, #0x48]
   2417c:      	mov	x8, #0x4                ; =4
   24180:      	str	x8, [x19, #0x50]
   24184:      	mov	x14, #0xf0f0f0f0f0f0f0f ; =1085102592571150095
   24188:      	str	x14, [x19, #0x78]
   2418c:      	mov	x14, #0x3333333333333333 ; =3689348814741910323
   24190:      	str	x14, [x19, #0x88]
   24194:      	mov	x14, #0x38              ; =56
   24198:      	str	x14, [x19, #0x90]
   2419c:      	mov	x14, #0x3a              ; =58
   241a0:      	str	x14, [x19, #0x98]
   241a4:      	mov	x14, #0x5555555555555555 ; =6148914691236517205
   241a8:      	str	x14, [x19, #0xb0]
   241ac:      	mov	x14, #0x3ffffffffffffff ; =288230376151711743
   241b0:      	str	x14, [x19, #0xb8]
   241b4:      	str	x7, [x19, #0x188]
   241b8:      	str	x13, [x19, #0x190]
   241bc:      	str	x22, [x19, #0x17a0]
   241c0:      	ldr	x14, [sp, #0x180]
   241c4:      	str	x14, [x19, #0x17a8]
   241c8:      	ldur	x24, [sp, #0xe0]
   241cc:      	uxtb	w1, w24
   241d0:      	str	x1, [x19, #0x17b8]
   241d4:      	str	x12, [x19, #0x1c70]
   241d8:      	str	x9, [x19, #0x1c78]
   241dc:      	str	x22, [x19, #0x1c80]
   241e0:      	str	x10, [x19, #0x1ca8]
   241e4:      	str	x0, [x19, #0x1cb8]
   241e8:      	ldur	x0, [sp, #0x78]
   241ec:      	str	x0, [x19, #0x4c60]
   241f0:      	mov	w0, #0x2646             ; =9798
   241f4:      	movk	w0, #0x1, lsl #16
   241f8:      	sub	x0, x3, x0
   241fc:      	str	x0, [x19, #0x4c68]
   24200:      	ldur	x4, [sp, #0x80]
   24204:      	str	x4, [x19, #0x4c70]
   24208:      	str	x22, [x19, #0x4f70]
   2420c:      	ldr	x1, [sp, #0x180]
   24210:      	str	x1, [x19, #0x4f78]
   24214:      	str	x12, [x19, #0x55d8]
   24218:      	str	x9, [x19, #0x55e0]
   2421c:      	str	x22, [x19, #0x55e8]
   24220:      	ldur	x10, [sp, #0x10]
   24224:      	str	x10, [x19, #0x55f0]
   24228:      	ldur	x25, [sp, #0x50]
   2422c:      	str	x25, [x19, #0x55f8]
   24230:      	ldur	x26, [sp, #0x58]
   24234:      	str	x26, [x19, #0x5600]
   24238:      	ldur	x28, [sp, #0x60]
   2423c:      	str	x28, [x19, #0x5608]
   24240:      	ldur	x25, [sp, #0x68]
   24244:      	str	x25, [x19, #0x5610]
   24248:      	ldur	x15, [sp, #0x48]
   2424c:      	str	x15, [x19, #0x5a20]
   24250:      	add	x1, x11, #0x1
   24254:      	str	x1, [x19, #0x5bb0]
   24258:      	ldur	x25, [sp, #0x88]
   2425c:      	str	x25, [x19, #0x5bb8]
   24260:      	ldur	x3, [sp, #0x90]
   24264:      	str	x3, [x19, #0x5bc0]
   24268:      	ldur	x5, [sp, #0x70]
   2426c:      	sub	x0, x5, x0
   24270:      	mov	w3, #0xc87e             ; =51326
   24274:      	movk	w3, #0x1, lsl #16
   24278:      	msub	x0, x1, x3, x0
   2427c:      	str	x0, [x19, #0x5bc8]
   24280:      	str	x7, [x19, #0x5bd0]
   24284:      	str	x7, [x19, #0x5bd8]
   24288:      	ldur	x0, [sp, #0x98]
   2428c:      	str	x0, [x19, #0x5be8]
   24290:      	ldur	x6, [sp, #0xa0]
   24294:      	str	x6, [x19, #0x5bf0]
   24298:      	str	x13, [x19, #0x5c00]
   2429c:      	ldur	x14, [sp, #0x38]
   242a0:      	str	x14, [x19, #0x5c08]
   242a4:      	str	x23, [x19, #0x5c18]
   242a8:      	str	x2, [x19, #0x5c20]
   242ac:      	ldr	x0, [x19, #0x4c60]
   242b0:      	cmp	x0, #0x0
   242b4:      	b.ne	0x21134 <_mech_canonical_program_entry_v1_numeric_1282+0x2fb4>
   242b8:      	b	0x2136c <_mech_canonical_program_entry_v1_numeric_1282+0x31ec>
   242bc:      	mov	x21, x20
   242c0:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   242c4:      	mov	x21, x20
   242c8:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   242cc:      	mov	x4, #0x606              ; =1542
   242d0:      	ldur	x0, [sp]
   242d4:      	str	x4, [x0, #0x48]
   242d8:      	mov	x7, #0x0                ; =0
   242dc:      	str	x7, [x19, #0x18]
   242e0:      	str	x1, [x19, #0x20]
   242e4:      	mov	x0, #0x1                ; =1
   242e8:      	mov	x21, x0
   242ec:      	str	x0, [x19, #0x30]
   242f0:      	mov	x8, #0x101010101010101  ; =72340172838076673
   242f4:      	str	x8, [x19, #0x38]
   242f8:      	mov	x13, #0x2               ; =2
   242fc:      	str	x13, [x19, #0x40]
   24300:      	mov	x13, #0x3               ; =3
   24304:      	str	x13, [x19, #0x48]
   24308:      	mov	x13, #0x4               ; =4
   2430c:      	str	x13, [x19, #0x50]
   24310:      	mov	x13, #0xf0f0f0f0f0f0f0f ; =1085102592571150095
   24314:      	str	x13, [x19, #0x78]
   24318:      	mov	x13, #0x3333333333333333 ; =3689348814741910323
   2431c:      	str	x13, [x19, #0x88]
   24320:      	mov	x15, #0x38              ; =56
   24324:      	str	x15, [x19, #0x90]
   24328:      	mov	x15, #0x3a              ; =58
   2432c:      	str	x15, [x19, #0x98]
   24330:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   24334:      	str	x0, [x19, #0xb0]
   24338:      	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
   2433c:      	str	x0, [x19, #0xb8]
   24340:      	str	x7, [x19, #0x188]
   24344:      	mov	x0, x21
   24348:      	str	x0, [x19, #0x190]
   2434c:      	str	x22, [x19, #0x17a0]
   24350:      	ldr	x0, [sp, #0x180]
   24354:      	str	x0, [x19, #0x17a8]
   24358:      	ldur	x24, [sp, #0xe0]
   2435c:      	uxtb	w0, w24
   24360:      	str	x0, [x19, #0x17b8]
   24364:      	str	x12, [x19, #0x1c70]
   24368:      	str	x9, [x19, #0x1c78]
   2436c:      	str	x22, [x19, #0x1c80]
   24370:      	str	x10, [x19, #0x1ca8]
   24374:      	str	x14, [x19, #0x1cc0]
   24378:      	ldur	x0, [sp, #0x78]
   2437c:      	str	x0, [x19, #0x4c60]
   24380:      	mov	w1, #0x2646             ; =9798
   24384:      	movk	w1, #0x1, lsl #16
   24388:      	sub	x1, x3, x1
   2438c:      	str	x1, [x19, #0x4c68]
   24390:      	ldur	x4, [sp, #0x80]
   24394:      	str	x4, [x19, #0x4c70]
   24398:      	ldur	x0, [sp, #0x48]
   2439c:      	str	x0, [x19, #0x5a20]
   243a0:      	add	x3, x11, #0x1
   243a4:      	str	x3, [x19, #0x5bb0]
   243a8:      	ldur	x25, [sp, #0x88]
   243ac:      	str	x25, [x19, #0x5bb8]
   243b0:      	ldur	x13, [sp, #0x90]
   243b4:      	str	x13, [x19, #0x5bc0]
   243b8:      	ldur	x5, [sp, #0x70]
   243bc:      	sub	x1, x5, x1
   243c0:      	mov	w4, #0xc87e             ; =51326
   243c4:      	movk	w4, #0x1, lsl #16
   243c8:      	msub	x0, x3, x4, x1
   243cc:      	str	x0, [x19, #0x5bc8]
   243d0:      	str	x7, [x19, #0x5bd0]
   243d4:      	str	x7, [x19, #0x5bd8]
   243d8:      	ldur	x0, [sp, #0x98]
   243dc:      	str	x0, [x19, #0x5be8]
   243e0:      	ldur	x6, [sp, #0xa0]
   243e4:      	str	x6, [x19, #0x5bf0]
   243e8:      	mov	x0, x21
   243ec:      	str	x0, [x19, #0x5c00]
   243f0:      	ldur	x14, [sp, #0x38]
   243f4:      	str	x14, [x19, #0x5c08]
   243f8:      	str	x23, [x19, #0x5c18]
   243fc:      	str	x2, [x19, #0x5c20]
   24400:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   24404:      	mov	x0, #0x607              ; =1543
   24408:      	ldur	x4, [sp]
   2440c:      	str	x0, [x4, #0x48]
   24410:      	mov	x0, #0x0                ; =0
   24414:      	str	x0, [x19, #0x18]
   24418:      	str	x1, [x19, #0x20]
   2441c:      	mov	x1, #0x1                ; =1
   24420:      	str	x1, [x19, #0x30]
   24424:      	mov	x4, #0x101010101010101  ; =72340172838076673
   24428:      	str	x4, [x19, #0x38]
   2442c:      	mov	x20, #0x2               ; =2
   24430:      	str	x20, [x19, #0x40]
   24434:      	mov	x4, #0x3                ; =3
   24438:      	str	x4, [x19, #0x48]
   2443c:      	mov	x4, #0x4                ; =4
   24440:      	str	x4, [x19, #0x50]
   24444:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   24448:      	str	x4, [x19, #0x78]
   2444c:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   24450:      	str	x4, [x19, #0x88]
   24454:      	mov	x4, #0x38               ; =56
   24458:      	str	x4, [x19, #0x90]
   2445c:      	mov	x4, #0x3a               ; =58
   24460:      	str	x4, [x19, #0x98]
   24464:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   24468:      	str	x4, [x19, #0xb0]
   2446c:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   24470:      	str	x4, [x19, #0xb8]
   24474:      	str	x0, [x19, #0x188]
   24478:      	str	x1, [x19, #0x190]
   2447c:      	str	x22, [x19, #0x17a0]
   24480:      	ldr	x4, [sp, #0x180]
   24484:      	str	x4, [x19, #0x17a8]
   24488:      	ldur	x24, [sp, #0xe0]
   2448c:      	uxtb	w4, w24
   24490:      	str	x4, [x19, #0x17b8]
   24494:      	str	x12, [x19, #0x1c70]
   24498:      	str	x9, [x19, #0x1c78]
   2449c:      	str	x22, [x19, #0x1c80]
   244a0:      	str	x10, [x19, #0x1ca8]
   244a4:      	str	x14, [x19, #0x1cc0]
   244a8:      	str	x25, [x19, #0x1cc8]
   244ac:      	ldur	x4, [sp, #0x78]
   244b0:      	str	x4, [x19, #0x4c60]
   244b4:      	mov	w13, #0x2646            ; =9798
   244b8:      	movk	w13, #0x1, lsl #16
   244bc:      	sub	x13, x3, x13
   244c0:      	str	x13, [x19, #0x4c68]
   244c4:      	ldur	x4, [sp, #0x80]
   244c8:      	str	x4, [x19, #0x4c70]
   244cc:      	str	x22, [x19, #0x4f70]
   244d0:      	ldr	x5, [sp, #0x180]
   244d4:      	str	x5, [x19, #0x4f78]
   244d8:      	str	x12, [x19, #0x55d8]
   244dc:      	str	x9, [x19, #0x55e0]
   244e0:      	str	x22, [x19, #0x55e8]
   244e4:      	ldur	x10, [sp, #0x10]
   244e8:      	str	x10, [x19, #0x55f0]
   244ec:      	ldur	x25, [sp, #0x50]
   244f0:      	str	x25, [x19, #0x55f8]
   244f4:      	ldur	x26, [sp, #0x58]
   244f8:      	str	x26, [x19, #0x5600]
   244fc:      	ldur	x28, [sp, #0x60]
   24500:      	str	x28, [x19, #0x5608]
   24504:      	ldur	x25, [sp, #0x68]
   24508:      	str	x25, [x19, #0x5610]
   2450c:      	ldur	x3, [sp, #0x48]
   24510:      	str	x3, [x19, #0x5a20]
   24514:      	add	x3, x11, #0x1
   24518:      	str	x3, [x19, #0x5bb0]
   2451c:      	ldur	x25, [sp, #0x88]
   24520:      	str	x25, [x19, #0x5bb8]
   24524:      	ldur	x4, [sp, #0x90]
   24528:      	str	x4, [x19, #0x5bc0]
   2452c:      	ldur	x5, [sp, #0x70]
   24530:      	sub	x4, x5, x13
   24534:      	mov	w5, #0xc87e             ; =51326
   24538:      	movk	w5, #0x1, lsl #16
   2453c:      	msub	x3, x3, x5, x4
   24540:      	str	x3, [x19, #0x5bc8]
   24544:      	str	x0, [x19, #0x5bd0]
   24548:      	str	x0, [x19, #0x5bd8]
   2454c:      	ldur	x0, [sp, #0x98]
   24550:      	str	x0, [x19, #0x5be8]
   24554:      	ldur	x6, [sp, #0xa0]
   24558:      	str	x6, [x19, #0x5bf0]
   2455c:      	str	x1, [x19, #0x5c00]
   24560:      	ldur	x14, [sp, #0x38]
   24564:      	str	x14, [x19, #0x5c08]
   24568:      	str	x23, [x19, #0x5c18]
   2456c:      	str	x2, [x19, #0x5c20]
   24570:      	ldr	x0, [x19, #0x4c60]
   24574:      	cmp	x0, #0x0
   24578:      	b.ne	0x21404 <_mech_canonical_program_entry_v1_numeric_1282+0x3284>
   2457c:      	b	0x21634 <_mech_canonical_program_entry_v1_numeric_1282+0x34b4>
   24580:      	mov	x21, x20
   24584:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   24588:      	mov	x21, x20
   2458c:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   24590:      	mov	x0, #0x609              ; =1545
   24594:      	ldur	x4, [sp]
   24598:      	str	x0, [x4, #0x48]
   2459c:      	mov	x0, #0x0                ; =0
   245a0:      	str	x0, [x19, #0x18]
   245a4:      	str	x1, [x19, #0x20]
   245a8:      	mov	x1, #0x1                ; =1
   245ac:      	str	x1, [x19, #0x30]
   245b0:      	mov	x4, #0x101010101010101  ; =72340172838076673
   245b4:      	str	x4, [x19, #0x38]
   245b8:      	mov	x20, #0x2               ; =2
   245bc:      	str	x20, [x19, #0x40]
   245c0:      	mov	x4, #0x3                ; =3
   245c4:      	str	x4, [x19, #0x48]
   245c8:      	mov	x4, #0x4                ; =4
   245cc:      	str	x4, [x19, #0x50]
   245d0:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   245d4:      	str	x4, [x19, #0x78]
   245d8:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   245dc:      	str	x4, [x19, #0x88]
   245e0:      	mov	x4, #0x38               ; =56
   245e4:      	str	x4, [x19, #0x90]
   245e8:      	mov	x4, #0x3a               ; =58
   245ec:      	str	x4, [x19, #0x98]
   245f0:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   245f4:      	str	x4, [x19, #0xb0]
   245f8:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   245fc:      	str	x4, [x19, #0xb8]
   24600:      	str	x0, [x19, #0x188]
   24604:      	str	x1, [x19, #0x190]
   24608:      	str	x22, [x19, #0x17a0]
   2460c:      	ldr	x4, [sp, #0x180]
   24610:      	str	x4, [x19, #0x17a8]
   24614:      	ldur	x24, [sp, #0xe0]
   24618:      	uxtb	w7, w24
   2461c:      	str	x7, [x19, #0x17b8]
   24620:      	str	x12, [x19, #0x1c70]
   24624:      	str	x9, [x19, #0x1c78]
   24628:      	str	x22, [x19, #0x1c80]
   2462c:      	str	x10, [x19, #0x1ca8]
   24630:      	ldr	x28, [sp, #0x100]
   24634:      	sub	x13, x28, #0x1
   24638:      	cmp	x28, xzr
   2463c:      	csel	x13, x13, x0, ne
   24640:      	cmp	x14, x13
   24644:      	csel	x15, x14, x13, lo
   24648:      	ldr	x28, [sp, #0x108]
   2464c:      	ldr	x15, [x28, x15, lsl #3]
   24650:      	str	x15, [x19, #0x1cd0]
   24654:      	add	x15, x14, #0x2
   24658:      	str	x15, [x19, #0x1cd8]
   2465c:      	ldur	x7, [sp, #0x78]
   24660:      	str	x7, [x19, #0x4c60]
   24664:      	mov	w4, #0x2646             ; =9798
   24668:      	movk	w4, #0x1, lsl #16
   2466c:      	sub	x3, x3, x4
   24670:      	str	x3, [x19, #0x4c68]
   24674:      	ldur	x4, [sp, #0x80]
   24678:      	str	x4, [x19, #0x4c70]
   2467c:      	str	x22, [x19, #0x4f70]
   24680:      	ldr	x4, [sp, #0x180]
   24684:      	str	x4, [x19, #0x4f78]
   24688:      	str	x12, [x19, #0x55d8]
   2468c:      	str	x9, [x19, #0x55e0]
   24690:      	str	x22, [x19, #0x55e8]
   24694:      	ldur	x10, [sp, #0x10]
   24698:      	str	x10, [x19, #0x55f0]
   2469c:      	ldur	x25, [sp, #0x50]
   246a0:      	str	x25, [x19, #0x55f8]
   246a4:      	ldur	x26, [sp, #0x58]
   246a8:      	str	x26, [x19, #0x5600]
   246ac:      	ldur	x28, [sp, #0x60]
   246b0:      	str	x28, [x19, #0x5608]
   246b4:      	ldur	x25, [sp, #0x68]
   246b8:      	str	x25, [x19, #0x5610]
   246bc:      	ldur	x4, [sp, #0x48]
   246c0:      	str	x4, [x19, #0x5a20]
   246c4:      	add	x4, x11, #0x1
   246c8:      	str	x4, [x19, #0x5bb0]
   246cc:      	ldur	x25, [sp, #0x88]
   246d0:      	str	x25, [x19, #0x5bb8]
   246d4:      	ldur	x13, [sp, #0x90]
   246d8:      	str	x13, [x19, #0x5bc0]
   246dc:      	ldur	x5, [sp, #0x70]
   246e0:      	sub	x3, x5, x3
   246e4:      	mov	w5, #0xc87e             ; =51326
   246e8:      	movk	w5, #0x1, lsl #16
   246ec:      	msub	x3, x4, x5, x3
   246f0:      	str	x3, [x19, #0x5bc8]
   246f4:      	str	x0, [x19, #0x5bd0]
   246f8:      	str	x0, [x19, #0x5bd8]
   246fc:      	ldur	x4, [sp, #0x98]
   24700:      	str	x4, [x19, #0x5be8]
   24704:      	ldur	x6, [sp, #0xa0]
   24708:      	str	x6, [x19, #0x5bf0]
   2470c:      	str	x1, [x19, #0x5c00]
   24710:      	ldur	x14, [sp, #0x38]
   24714:      	str	x14, [x19, #0x5c08]
   24718:      	str	x23, [x19, #0x5c18]
   2471c:      	str	x2, [x19, #0x5c20]
   24720:      	ldr	x0, [x19, #0x4c60]
   24724:      	cmp	x0, #0x0
   24728:      	b.ne	0x2169c <_mech_canonical_program_entry_v1_numeric_1282+0x351c>
   2472c:      	b	0x218d0 <_mech_canonical_program_entry_v1_numeric_1282+0x3750>
   24730:      	mov	x21, x20
   24734:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   24738:      	mov	x21, x20
   2473c:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   24740:      	mov	x21, x20
   24744:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   24748:      	mov	x4, #0x621              ; =1569
   2474c:      	ldur	x23, [sp]
   24750:      	str	x4, [x23, #0x48]
   24754:      	mov	x7, #0x0                ; =0
   24758:      	str	x7, [x19, #0x18]
   2475c:      	str	x1, [x19, #0x20]
   24760:      	mov	x1, #0x1                ; =1
   24764:      	str	x1, [x19, #0x30]
   24768:      	mov	x4, #0x101010101010101  ; =72340172838076673
   2476c:      	str	x4, [x19, #0x38]
   24770:      	mov	x20, #0x2               ; =2
   24774:      	str	x20, [x19, #0x40]
   24778:      	mov	x4, #0x3                ; =3
   2477c:      	str	x4, [x19, #0x48]
   24780:      	mov	x4, #0x4                ; =4
   24784:      	str	x4, [x19, #0x50]
   24788:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   2478c:      	str	x4, [x19, #0x78]
   24790:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   24794:      	str	x4, [x19, #0x88]
   24798:      	mov	x4, #0x38               ; =56
   2479c:      	str	x4, [x19, #0x90]
   247a0:      	mov	x4, #0x3a               ; =58
   247a4:      	str	x4, [x19, #0x98]
   247a8:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   247ac:      	str	x4, [x19, #0xb0]
   247b0:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   247b4:      	str	x4, [x19, #0xb8]
   247b8:      	str	x7, [x19, #0x188]
   247bc:      	str	x1, [x19, #0x190]
   247c0:      	str	x22, [x19, #0x17a0]
   247c4:      	ldr	x4, [sp, #0x180]
   247c8:      	str	x4, [x19, #0x17a8]
   247cc:      	ldur	x24, [sp, #0xe0]
   247d0:      	uxtb	w4, w24
   247d4:      	str	x4, [x19, #0x17b8]
   247d8:      	str	x12, [x19, #0x1c70]
   247dc:      	str	x9, [x19, #0x1c78]
   247e0:      	str	x22, [x19, #0x1c80]
   247e4:      	str	x10, [x19, #0x1ca8]
   247e8:      	str	x3, [x19, #0x1d38]
   247ec:      	str	x5, [x19, #0x1d40]
   247f0:      	str	x22, [x19, #0x1d48]
   247f4:      	uxtb	w4, w13
   247f8:      	str	x4, [x19, #0x1d58]
   247fc:      	add	x4, x3, #0x1
   24800:      	str	x4, [x19, #0x1d68]
   24804:      	ldur	x23, [sp, #0x78]
   24808:      	str	x23, [x19, #0x4c60]
   2480c:      	mov	w4, #0xcb86             ; =52102
   24810:      	movk	w4, #0x2, lsl #16
   24814:      	sub	x2, x2, x4
   24818:      	str	x2, [x19, #0x4c68]
   2481c:      	ldur	x4, [sp, #0x80]
   24820:      	str	x4, [x19, #0x4c70]
   24824:      	str	x22, [x19, #0x4f70]
   24828:      	ldr	x4, [sp, #0x180]
   2482c:      	str	x4, [x19, #0x4f78]
   24830:      	str	x12, [x19, #0x55d8]
   24834:      	str	x9, [x19, #0x55e0]
   24838:      	str	x22, [x19, #0x55e8]
   2483c:      	ldur	x10, [sp, #0x10]
   24840:      	str	x10, [x19, #0x55f0]
   24844:      	ldur	x25, [sp, #0x50]
   24848:      	str	x25, [x19, #0x55f8]
   2484c:      	ldur	x4, [sp, #0x58]
   24850:      	str	x4, [x19, #0x5600]
   24854:      	ldur	x4, [sp, #0x60]
   24858:      	str	x4, [x19, #0x5608]
   2485c:      	ldur	x25, [sp, #0x68]
   24860:      	str	x25, [x19, #0x5610]
   24864:      	str	x3, [x19, #0x57a0]
   24868:      	str	x5, [x19, #0x57a8]
   2486c:      	str	x22, [x19, #0x57b0]
   24870:      	str	x14, [x19, #0x57b8]
   24874:      	str	x15, [x19, #0x57c0]
   24878:      	str	x26, [x19, #0x57c8]
   2487c:      	str	x0, [x19, #0x57d0]
   24880:      	str	x28, [x19, #0x57d8]
   24884:      	ldur	x0, [sp, #0x48]
   24888:      	str	x0, [x19, #0x5a20]
   2488c:      	add	x0, x11, #0x1
   24890:      	str	x0, [x19, #0x5bb0]
   24894:      	ldur	x25, [sp, #0x88]
   24898:      	str	x25, [x19, #0x5bb8]
   2489c:      	ldur	x13, [sp, #0x90]
   248a0:      	str	x13, [x19, #0x5bc0]
   248a4:      	ldur	x5, [sp, #0x70]
   248a8:      	sub	x2, x5, x2
   248ac:      	mov	w3, #0xc87e             ; =51326
   248b0:      	movk	w3, #0x1, lsl #16
   248b4:      	msub	x0, x0, x3, x2
   248b8:      	str	x0, [x19, #0x5bc8]
   248bc:      	str	x7, [x19, #0x5bd0]
   248c0:      	str	x7, [x19, #0x5bd8]
   248c4:      	ldur	x23, [sp, #0x98]
   248c8:      	str	x23, [x19, #0x5be8]
   248cc:      	ldur	x6, [sp, #0xa0]
   248d0:      	str	x6, [x19, #0x5bf0]
   248d4:      	str	x1, [x19, #0x5c00]
   248d8:      	ldur	x14, [sp, #0x38]
   248dc:      	str	x14, [x19, #0x5c08]
   248e0:      	str	x1, [x19, #0x5c18]
   248e4:      	ldur	x7, [sp, #0x40]
   248e8:      	str	x7, [x19, #0x5c20]
   248ec:      	ldr	x0, [x19, #0x4c60]
   248f0:      	cmp	x0, #0x0
   248f4:      	b.ne	0x21dd4 <_mech_canonical_program_entry_v1_numeric_1282+0x3c54>
   248f8:      	b	0x22004 <_mech_canonical_program_entry_v1_numeric_1282+0x3e84>
   248fc:      	mov	x21, x20
   24900:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   24904:      	mov	x21, x20
   24908:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   2490c:      	mov	x1, #0x6c4              ; =1732
   24910:      	ldur	x0, [sp]
   24914:      	str	x1, [x0, #0x48]
   24918:      	mov	x4, #0x0                ; =0
   2491c:      	str	x4, [x19, #0x4c60]
   24920:      	mov	x0, #0x3                ; =3
   24924:      	ldr	x7, [sp, #0x188]
   24928:      	mov	x21, x0
   2492c:      	cmp	x7, #0x19c
   24930:      	b.hs	0x22258 <_mech_canonical_program_entry_v1_numeric_1282+0x40d8>
   24934:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   24938:      	mov	x0, #0x6c8              ; =1736
   2493c:      	ldur	x5, [sp]
   24940:      	str	x0, [x5, #0x48]
   24944:      	mov	x0, #0x0                ; =0
   24948:      	str	x0, [x19, #0x4c60]
   2494c:      	mov	x0, #0x3                ; =3
   24950:      	ldr	x7, [sp, #0x188]
   24954:      	mov	x21, x0
   24958:      	cmp	x7, #0x19c
   2495c:      	b.hs	0x2240c <_mech_canonical_program_entry_v1_numeric_1282+0x428c>
   24960:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   24964:      	mov	x14, #0x6cc             ; =1740
   24968:      	ldur	x0, [sp]
   2496c:      	str	x14, [x0, #0x48]
   24970:      	mov	x0, #0x0                ; =0
   24974:      	str	x0, [x19, #0x4c60]
   24978:      	mov	x0, #0x3                ; =3
   2497c:      	ldr	x7, [sp, #0x188]
   24980:      	mov	x21, x0
   24984:      	cmp	x7, #0x19c
   24988:      	b.hs	0x225a4 <_mech_canonical_program_entry_v1_numeric_1282+0x4424>
   2498c:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   24990:      	mov	x0, #0x6d0              ; =1744
   24994:      	ldur	x4, [sp]
   24998:      	str	x0, [x4, #0x48]
   2499c:      	mov	x0, #0x0                ; =0
   249a0:      	str	x0, [x19, #0x4c60]
   249a4:      	mov	x0, #0x3                ; =3
   249a8:      	ldr	x7, [sp, #0x188]
   249ac:      	mov	x21, x0
   249b0:      	cmp	x7, #0x19c
   249b4:      	b.hs	0x22744 <_mech_canonical_program_entry_v1_numeric_1282+0x45c4>
   249b8:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   249bc:      	mov	x0, #0x6d4              ; =1748
   249c0:      	ldur	x4, [sp]
   249c4:      	str	x0, [x4, #0x48]
   249c8:      	mov	x0, #0x0                ; =0
   249cc:      	str	x0, [x19, #0x4c60]
   249d0:      	mov	x0, #0x3                ; =3
   249d4:      	ldr	x7, [sp, #0x188]
   249d8:      	mov	x21, x0
   249dc:      	cmp	x7, #0x19c
   249e0:      	b.hs	0x228e4 <_mech_canonical_program_entry_v1_numeric_1282+0x4764>
   249e4:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   249e8:      	mov	x0, #0x6dd              ; =1757
   249ec:      	ldur	x1, [sp]
   249f0:      	str	x0, [x1, #0x48]
   249f4:      	mov	x1, #0x0                ; =0
   249f8:      	str	x1, [x19, #0x18]
   249fc:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   24a00:      	str	x0, [x19, #0x20]
   24a04:      	mov	x0, #0x1                ; =1
   24a08:      	mov	x21, x0
   24a0c:      	str	x0, [x19, #0x30]
   24a10:      	mov	x0, #0x101010101010101  ; =72340172838076673
   24a14:      	str	x0, [x19, #0x38]
   24a18:      	mov	x0, #0x2                ; =2
   24a1c:      	str	x0, [x19, #0x40]
   24a20:      	mov	x0, #0x3                ; =3
   24a24:      	str	x0, [x19, #0x48]
   24a28:      	mov	x0, #0x4                ; =4
   24a2c:      	str	x0, [x19, #0x50]
   24a30:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   24a34:      	str	x0, [x19, #0x78]
   24a38:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   24a3c:      	str	x0, [x19, #0x88]
   24a40:      	mov	x0, #0x38               ; =56
   24a44:      	str	x0, [x19, #0x90]
   24a48:      	mov	x0, #0x3a               ; =58
   24a4c:      	str	x0, [x19, #0x98]
   24a50:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   24a54:      	str	x0, [x19, #0xb0]
   24a58:      	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
   24a5c:      	str	x0, [x19, #0xb8]
   24a60:      	str	x1, [x19, #0x188]
   24a64:      	mov	x0, x21
   24a68:      	str	x0, [x19, #0x190]
   24a6c:      	str	x26, [x19, #0x17a0]
   24a70:      	ldr	x22, [sp, #0x180]
   24a74:      	str	x22, [x19, #0x17a8]
   24a78:      	ldur	x0, [sp, #0x78]
   24a7c:      	str	x0, [x19, #0x4c60]
   24a80:      	str	x3, [x19, #0x4c68]
   24a84:      	ldur	x4, [sp, #0x80]
   24a88:      	str	x4, [x19, #0x4c70]
   24a8c:      	ldur	x0, [sp, #0x48]
   24a90:      	str	x0, [x19, #0x5a20]
   24a94:      	str	x11, [x19, #0x5bb0]
   24a98:      	ldur	x25, [sp, #0x88]
   24a9c:      	str	x25, [x19, #0x5bb8]
   24aa0:      	ldur	x13, [sp, #0x90]
   24aa4:      	str	x13, [x19, #0x5bc0]
   24aa8:      	ldur	x5, [sp, #0x70]
   24aac:      	sub	x8, x5, x3
   24ab0:      	mov	w13, #0xc87e            ; =51326
   24ab4:      	movk	w13, #0x1, lsl #16
   24ab8:      	msub	x8, x11, x13, x8
   24abc:      	str	x8, [x19, #0x5bc8]
   24ac0:      	str	x10, [x19, #0x5bd0]
   24ac4:      	str	x15, [x19, #0x5bd8]
   24ac8:      	ldur	x0, [sp, #0x98]
   24acc:      	str	x0, [x19, #0x5be8]
   24ad0:      	ldur	x6, [sp, #0xa0]
   24ad4:      	str	x6, [x19, #0x5bf0]
   24ad8:      	str	x12, [x19, #0x5c00]
   24adc:      	str	x9, [x19, #0x5c08]
   24ae0:      	str	x23, [x19, #0x5c18]
   24ae4:      	str	x2, [x19, #0x5c20]
   24ae8:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   24aec:      	mov	x0, #0x6b0              ; =1712
   24af0:      	ldur	x4, [sp]
   24af4:      	str	x0, [x4, #0x48]
   24af8:      	mov	x7, #0x0                ; =0
   24afc:      	str	x7, [x19, #0x18]
   24b00:      	str	x1, [x19, #0x20]
   24b04:      	mov	x0, #0x1                ; =1
   24b08:      	mov	x21, x0
   24b0c:      	str	x0, [x19, #0x30]
   24b10:      	mov	x0, #0x101010101010101  ; =72340172838076673
   24b14:      	str	x0, [x19, #0x38]
   24b18:      	mov	x0, #0x2                ; =2
   24b1c:      	str	x0, [x19, #0x40]
   24b20:      	mov	x0, #0x3                ; =3
   24b24:      	str	x0, [x19, #0x48]
   24b28:      	mov	x0, #0x4                ; =4
   24b2c:      	str	x0, [x19, #0x50]
   24b30:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   24b34:      	str	x0, [x19, #0x78]
   24b38:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   24b3c:      	str	x0, [x19, #0x88]
   24b40:      	mov	x0, #0x38               ; =56
   24b44:      	str	x0, [x19, #0x90]
   24b48:      	mov	x0, #0x3a               ; =58
   24b4c:      	str	x0, [x19, #0x98]
   24b50:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   24b54:      	str	x0, [x19, #0xb0]
   24b58:      	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
   24b5c:      	str	x0, [x19, #0xb8]
   24b60:      	str	x7, [x19, #0x188]
   24b64:      	mov	x0, x21
   24b68:      	str	x0, [x19, #0x190]
   24b6c:      	str	x22, [x19, #0x17a0]
   24b70:      	ldr	x0, [sp, #0x180]
   24b74:      	str	x0, [x19, #0x17a8]
   24b78:      	ldur	x24, [sp, #0xe0]
   24b7c:      	uxtb	w0, w24
   24b80:      	str	x0, [x19, #0x17b8]
   24b84:      	str	x12, [x19, #0x1c70]
   24b88:      	str	x9, [x19, #0x1c78]
   24b8c:      	str	x22, [x19, #0x1c80]
   24b90:      	ldur	x4, [sp, #0x78]
   24b94:      	str	x4, [x19, #0x4c60]
   24b98:      	str	x3, [x19, #0x4c68]
   24b9c:      	ldur	x4, [sp, #0x80]
   24ba0:      	str	x4, [x19, #0x4c70]
   24ba4:      	ldur	x4, [sp, #0x48]
   24ba8:      	str	x4, [x19, #0x5a20]
   24bac:      	add	x1, x11, #0x1
   24bb0:      	str	x1, [x19, #0x5bb0]
   24bb4:      	ldur	x25, [sp, #0x88]
   24bb8:      	str	x25, [x19, #0x5bb8]
   24bbc:      	ldur	x13, [sp, #0x90]
   24bc0:      	str	x13, [x19, #0x5bc0]
   24bc4:      	ldur	x5, [sp, #0x70]
   24bc8:      	sub	x3, x5, x3
   24bcc:      	mov	w0, #0xc87e             ; =51326
   24bd0:      	movk	w0, #0x1, lsl #16
   24bd4:      	msub	x0, x1, x0, x3
   24bd8:      	str	x0, [x19, #0x5bc8]
   24bdc:      	str	x7, [x19, #0x5bd0]
   24be0:      	str	x7, [x19, #0x5bd8]
   24be4:      	ldur	x0, [sp, #0x98]
   24be8:      	str	x0, [x19, #0x5be8]
   24bec:      	ldur	x6, [sp, #0xa0]
   24bf0:      	str	x6, [x19, #0x5bf0]
   24bf4:      	mov	x0, x21
   24bf8:      	str	x0, [x19, #0x5c00]
   24bfc:      	ldur	x14, [sp, #0x38]
   24c00:      	str	x14, [x19, #0x5c08]
   24c04:      	str	x23, [x19, #0x5c18]
   24c08:      	str	x2, [x19, #0x5c20]
   24c0c:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   24c10:      	mov	x8, #0x6a0              ; =1696
   24c14:      	ldur	x23, [sp]
   24c18:      	str	x8, [x23, #0x48]
   24c1c:      	mov	x13, #0x0               ; =0
   24c20:      	str	x13, [x19, #0x18]
   24c24:      	str	x1, [x19, #0x20]
   24c28:      	mov	x0, #0x1                ; =1
   24c2c:      	mov	x21, x0
   24c30:      	str	x0, [x19, #0x30]
   24c34:      	mov	x14, #0x101010101010101 ; =72340172838076673
   24c38:      	str	x14, [x19, #0x38]
   24c3c:      	mov	x14, #0x2               ; =2
   24c40:      	str	x14, [x19, #0x40]
   24c44:      	mov	x14, #0x3               ; =3
   24c48:      	str	x14, [x19, #0x48]
   24c4c:      	mov	x15, #0x4               ; =4
   24c50:      	str	x15, [x19, #0x50]
   24c54:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   24c58:      	str	x0, [x19, #0x78]
   24c5c:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   24c60:      	str	x0, [x19, #0x88]
   24c64:      	mov	x0, #0x38               ; =56
   24c68:      	str	x0, [x19, #0x90]
   24c6c:      	mov	x0, #0x3a               ; =58
   24c70:      	str	x0, [x19, #0x98]
   24c74:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   24c78:      	str	x0, [x19, #0xb0]
   24c7c:      	ldur	x20, [sp, #0xb0]
   24c80:      	str	x20, [x19, #0xb8]
   24c84:      	str	x13, [x19, #0x188]
   24c88:      	mov	x0, x21
   24c8c:      	str	x0, [x19, #0x190]
   24c90:      	str	x22, [x19, #0x17a0]
   24c94:      	ldr	x0, [sp, #0x180]
   24c98:      	str	x0, [x19, #0x17a8]
   24c9c:      	ldur	x24, [sp, #0xe0]
   24ca0:      	uxtb	w0, w24
   24ca4:      	str	x0, [x19, #0x17b8]
   24ca8:      	str	x12, [x19, #0x1c70]
   24cac:      	str	x9, [x19, #0x1c78]
   24cb0:      	str	x22, [x19, #0x1c80]
   24cb4:      	str	x10, [x19, #0x1ca8]
   24cb8:      	str	x3, [x19, #0x1d38]
   24cbc:      	str	x5, [x19, #0x1d40]
   24cc0:      	str	x22, [x19, #0x1d48]
   24cc4:      	ldur	x23, [sp, #0x78]
   24cc8:      	str	x23, [x19, #0x4c60]
   24ccc:      	mov	w0, #0xcb86             ; =52102
   24cd0:      	movk	w0, #0x2, lsl #16
   24cd4:      	sub	x1, x2, x0
   24cd8:      	str	x1, [x19, #0x4c68]
   24cdc:      	ldur	x4, [sp, #0x80]
   24ce0:      	str	x4, [x19, #0x4c70]
   24ce4:      	ldur	x2, [sp, #0x48]
   24ce8:      	str	x2, [x19, #0x5a20]
   24cec:      	add	x2, x11, #0x1
   24cf0:      	str	x2, [x19, #0x5bb0]
   24cf4:      	ldur	x25, [sp, #0x88]
   24cf8:      	str	x25, [x19, #0x5bb8]
   24cfc:      	ldur	x4, [sp, #0x90]
   24d00:      	str	x4, [x19, #0x5bc0]
   24d04:      	ldur	x5, [sp, #0x70]
   24d08:      	sub	x1, x5, x1
   24d0c:      	mov	w0, #0xc87e             ; =51326
   24d10:      	movk	w0, #0x1, lsl #16
   24d14:      	msub	x0, x2, x0, x1
   24d18:      	str	x0, [x19, #0x5bc8]
   24d1c:      	str	x13, [x19, #0x5bd0]
   24d20:      	str	x13, [x19, #0x5bd8]
   24d24:      	ldur	x23, [sp, #0x98]
   24d28:      	str	x23, [x19, #0x5be8]
   24d2c:      	ldur	x6, [sp, #0xa0]
   24d30:      	str	x6, [x19, #0x5bf0]
   24d34:      	mov	x0, x21
   24d38:      	str	x0, [x19, #0x5c00]
   24d3c:      	ldur	x14, [sp, #0x38]
   24d40:      	str	x14, [x19, #0x5c08]
   24d44:      	str	x0, [x19, #0x5c18]
   24d48:      	ldur	x7, [sp, #0x40]
   24d4c:      	str	x7, [x19, #0x5c20]
   24d50:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   24d54:      	mov	x0, #0x5df              ; =1503
   24d58:      	ldur	x1, [sp]
   24d5c:      	str	x0, [x1, #0x48]
   24d60:      	mov	x1, #0x0                ; =0
   24d64:      	str	x1, [x19, #0x18]
   24d68:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   24d6c:      	str	x0, [x19, #0x20]
   24d70:      	mov	x0, #0x1                ; =1
   24d74:      	mov	x21, x0
   24d78:      	str	x0, [x19, #0x30]
   24d7c:      	mov	x0, #0x101010101010101  ; =72340172838076673
   24d80:      	str	x0, [x19, #0x38]
   24d84:      	mov	x0, #0x2                ; =2
   24d88:      	str	x0, [x19, #0x40]
   24d8c:      	mov	x4, #0x3                ; =3
   24d90:      	str	x4, [x19, #0x48]
   24d94:      	mov	x4, #0x4                ; =4
   24d98:      	str	x4, [x19, #0x50]
   24d9c:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   24da0:      	str	x4, [x19, #0x78]
   24da4:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   24da8:      	str	x4, [x19, #0x88]
   24dac:      	mov	x5, #0x38               ; =56
   24db0:      	str	x5, [x19, #0x90]
   24db4:      	mov	x6, #0x3a               ; =58
   24db8:      	str	x6, [x19, #0x98]
   24dbc:      	mov	x8, #0x5555555555555555 ; =6148914691236517205
   24dc0:      	str	x8, [x19, #0xb0]
   24dc4:      	mov	x8, #0x3ffffffffffffff  ; =288230376151711743
   24dc8:      	str	x8, [x19, #0xb8]
   24dcc:      	str	x1, [x19, #0x188]
   24dd0:      	mov	x0, x21
   24dd4:      	str	x0, [x19, #0x190]
   24dd8:      	str	x22, [x19, #0x17a0]
   24ddc:      	ldr	x0, [sp, #0x180]
   24de0:      	str	x0, [x19, #0x17a8]
   24de4:      	ldur	x24, [sp, #0xe0]
   24de8:      	uxtb	w13, w24
   24dec:      	str	x13, [x19, #0x17b8]
   24df0:      	str	x7, [x19, #0x1858]
   24df4:      	ldur	x0, [sp, #0xc8]
   24df8:      	str	x0, [x19, #0x1860]
   24dfc:      	str	x22, [x19, #0x1868]
   24e00:      	ldr	x27, [sp, #0x160]
   24e04:      	sub	x0, x27, #0x1
   24e08:      	cmp	x27, xzr
   24e0c:      	csel	x0, x0, x1, ne
   24e10:      	cmp	x22, x0
   24e14:      	csel	x0, x22, x0, lo
   24e18:      	ldr	x27, [sp, #0x168]
   24e1c:      	ldr	x0, [x27, x0, lsl #3]
   24e20:      	str	x0, [x19, #0x1870]
   24e24:      	ldur	x0, [sp, #0x78]
   24e28:      	str	x0, [x19, #0x4c60]
   24e2c:      	str	x3, [x19, #0x4c68]
   24e30:      	ldur	x4, [sp, #0x80]
   24e34:      	str	x4, [x19, #0x4c70]
   24e38:      	ldur	x0, [sp, #0x48]
   24e3c:      	str	x0, [x19, #0x5a20]
   24e40:      	add	x1, x11, #0x1
   24e44:      	str	x1, [x19, #0x5bb0]
   24e48:      	ldur	x25, [sp, #0x88]
   24e4c:      	str	x25, [x19, #0x5bb8]
   24e50:      	ldur	x13, [sp, #0x90]
   24e54:      	str	x13, [x19, #0x5bc0]
   24e58:      	ldur	x5, [sp, #0x70]
   24e5c:      	sub	x3, x5, x3
   24e60:      	mov	w0, #0xc87e             ; =51326
   24e64:      	movk	w0, #0x1, lsl #16
   24e68:      	msub	x0, x1, x0, x3
   24e6c:      	str	x0, [x19, #0x5bc8]
   24e70:      	mov	x0, x21
   24e74:      	str	x0, [x19, #0x5bd0]
   24e78:      	ldur	x27, [sp, #0x20]
   24e7c:      	str	x27, [x19, #0x5bd8]
   24e80:      	ldur	x14, [sp, #0x98]
   24e84:      	str	x14, [x19, #0x5be8]
   24e88:      	ldur	x6, [sp, #0xa0]
   24e8c:      	str	x6, [x19, #0x5bf0]
   24e90:      	str	x12, [x19, #0x5c00]
   24e94:      	str	x9, [x19, #0x5c08]
   24e98:      	str	x23, [x19, #0x5c18]
   24e9c:      	str	x2, [x19, #0x5c20]
   24ea0:      	b	0x25018 <_mech_canonical_program_entry_v1_numeric_1282+0x6e98>
   24ea4:      	mov	x0, #0x5cf              ; =1487
   24ea8:      	ldur	x1, [sp]
   24eac:      	str	x0, [x1, #0x48]
   24eb0:      	mov	x1, #0x0                ; =0
   24eb4:      	str	x1, [x19, #0x18]
   24eb8:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   24ebc:      	str	x0, [x19, #0x20]
   24ec0:      	mov	x0, #0x1                ; =1
   24ec4:      	mov	x21, x0
   24ec8:      	str	x0, [x19, #0x30]
   24ecc:      	mov	x0, #0x101010101010101  ; =72340172838076673
   24ed0:      	str	x0, [x19, #0x38]
   24ed4:      	mov	x0, #0x2                ; =2
   24ed8:      	str	x0, [x19, #0x40]
   24edc:      	mov	x0, #0x3                ; =3
   24ee0:      	str	x0, [x19, #0x48]
   24ee4:      	mov	x0, #0x4                ; =4
   24ee8:      	str	x0, [x19, #0x50]
   24eec:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   24ef0:      	str	x0, [x19, #0x78]
   24ef4:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   24ef8:      	str	x0, [x19, #0x88]
   24efc:      	mov	x0, #0x38               ; =56
   24f00:      	str	x0, [x19, #0x90]
   24f04:      	mov	x0, #0x3a               ; =58
   24f08:      	str	x0, [x19, #0x98]
   24f0c:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   24f10:      	str	x0, [x19, #0xb0]
   24f14:      	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
   24f18:      	str	x0, [x19, #0xb8]
   24f1c:      	str	x1, [x19, #0x188]
   24f20:      	mov	x0, x21
   24f24:      	str	x0, [x19, #0x190]
   24f28:      	str	x22, [x19, #0x17a0]
   24f2c:      	ldr	x0, [sp, #0x180]
   24f30:      	str	x0, [x19, #0x17a8]
   24f34:      	ldur	x24, [sp, #0xe0]
   24f38:      	uxtb	w0, w24
   24f3c:      	str	x0, [x19, #0x17b8]
   24f40:      	ldur	x15, [sp, #0x18]
   24f44:      	str	x15, [x19, #0x1858]
   24f48:      	ldur	x14, [sp, #0xc8]
   24f4c:      	str	x14, [x19, #0x1860]
   24f50:      	str	x22, [x19, #0x1868]
   24f54:      	ldr	x27, [sp, #0x160]
   24f58:      	sub	x4, x27, #0x1
   24f5c:      	cmp	x27, xzr
   24f60:      	csel	x4, x4, x1, ne
   24f64:      	cmp	x22, x4
   24f68:      	csel	x5, x22, x4, lo
   24f6c:      	ldr	x27, [sp, #0x168]
   24f70:      	ldr	x5, [x27, x5, lsl #3]
   24f74:      	str	x5, [x19, #0x1870]
   24f78:      	ldur	x0, [sp, #0xc0]
   24f7c:      	uxtb	w7, w0
   24f80:      	str	x7, [x19, #0x1880]
   24f84:      	str	x6, [x19, #0x1918]
   24f88:      	str	x3, [x19, #0x1920]
   24f8c:      	str	x22, [x19, #0x1928]
   24f90:      	str	x5, [x19, #0x1930]
   24f94:      	ldur	x0, [sp, #0x78]
   24f98:      	str	x0, [x19, #0x4c60]
   24f9c:      	mov	w14, #0xdc1e            ; =56350
   24fa0:      	movk	w14, #0x2, lsl #16
   24fa4:      	sub	x13, x13, x14
   24fa8:      	str	x13, [x19, #0x4c68]
   24fac:      	ldur	x4, [sp, #0x80]
   24fb0:      	str	x4, [x19, #0x4c70]
   24fb4:      	ldur	x0, [sp, #0x48]
   24fb8:      	str	x0, [x19, #0x5a20]
   24fbc:      	add	x15, x11, #0x1
   24fc0:      	str	x15, [x19, #0x5bb0]
   24fc4:      	ldur	x25, [sp, #0x88]
   24fc8:      	str	x25, [x19, #0x5bb8]
   24fcc:      	ldur	x0, [sp, #0x90]
   24fd0:      	str	x0, [x19, #0x5bc0]
   24fd4:      	ldur	x5, [sp, #0x70]
   24fd8:      	sub	x1, x5, x13
   24fdc:      	mov	w0, #0xc87e             ; =51326
   24fe0:      	movk	w0, #0x1, lsl #16
   24fe4:      	msub	x0, x15, x0, x1
   24fe8:      	str	x0, [x19, #0x5bc8]
   24fec:      	mov	x0, x21
   24ff0:      	str	x0, [x19, #0x5bd0]
   24ff4:      	ldur	x27, [sp, #0x20]
   24ff8:      	str	x27, [x19, #0x5bd8]
   24ffc:      	str	x0, [x19, #0x5be8]
   25000:      	ldur	x6, [sp, #0x30]
   25004:      	str	x6, [x19, #0x5bf0]
   25008:      	str	x12, [x19, #0x5c00]
   2500c:      	str	x9, [x19, #0x5c08]
   25010:      	str	x23, [x19, #0x5c18]
   25014:      	str	x2, [x19, #0x5c20]
   25018:      	mov	x1, #0x0                ; =0
   2501c:      	mov	x0, x21
   25020:      	add	sp, sp, #0x1b0
   25024:      	ldp	x19, x20, [sp], #0x10
   25028:      	ldp	x21, x22, [sp], #0x10
   2502c:      	ldp	x23, x24, [sp], #0x10
   25030:      	ldp	x25, x26, [sp], #0x10
   25034:      	ldp	x27, x28, [sp], #0x10
   25038:      	ldp	x29, x30, [sp], #0x10
   2503c:      	retab
		...
