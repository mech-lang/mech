
/private/tmp/mech-related-initialized-homes-integration-runners-20261107-v1/reuse-4/build/object.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000000001d180 <_mech_canonical_program_entry_v1_numeric_1282>:
   1d180:      	pacibsp
   1d184:      	stp	x29, x30, [sp, #-0x10]!
   1d188:      	mov	x29, sp
   1d18c:      	stp	x27, x28, [sp, #-0x10]!
   1d190:      	stp	x25, x26, [sp, #-0x10]!
   1d194:      	stp	x23, x24, [sp, #-0x10]!
   1d198:      	stp	x21, x22, [sp, #-0x10]!
   1d19c:      	stp	x19, x20, [sp, #-0x10]!
   1d1a0:      	sub	sp, sp, #0x1c0
   1d1a4:      	mov	x19, x1
   1d1a8:      	stur	x2, [sp, #0x8]
   1d1ac:      	ldr	x21, [x0, #0x50]
   1d1b0:      	str	x21, [sp, #0x1a8]
   1d1b4:      	ldr	x6, [x0, #0x58]
   1d1b8:      	ldr	x1, [x0, #0x60]
   1d1bc:      	ldr	x14, [x0, #0x68]
   1d1c0:      	stur	x0, [sp]
   1d1c4:      	str	x14, [sp, #0x190]
   1d1c8:      	mov	x0, #0x3                ; =3
   1d1cc:      	cmp	x21, #0x0
   1d1d0:      	b.eq	0x21ba0 <_mech_canonical_program_entry_v1_numeric_1282+0x4a20>
   1d1d4:      	mov	x0, #0x3                ; =3
   1d1d8:      	cmp	x6, #0x0
   1d1dc:      	str	x6, [sp, #0x1a0]
   1d1e0:      	b.eq	0x21ba8 <_mech_canonical_program_entry_v1_numeric_1282+0x4a28>
   1d1e4:      	mov	x0, #0x3                ; =3
   1d1e8:      	mov	x21, x0
   1d1ec:      	cmp	x1, #0x0
   1d1f0:      	b.eq	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1d1f4:      	mov	x0, x19
   1d1f8:      	ldr	x23, [x0, #0x4c60]
   1d1fc:      	cmp	x23, #0x0
   1d200:      	mov	x26, x23
   1d204:      	b.eq	0x1d674 <_mech_canonical_program_entry_v1_numeric_1282+0x4f4>
   1d208:      	ldr	x25, [x1, #0x10]
   1d20c:      	ldr	x3, [x0, #0x4c68]
   1d210:      	ldr	x4, [x0, #0x4c70]
   1d214:      	mov	x19, x0
   1d218:      	stur	x4, [sp, #0x98]
   1d21c:      	ldr	x22, [x25, #0xf60]
   1d220:      	ldr	x23, [x25, #0xf70]
   1d224:      	ldr	x20, [x1, #0xab8]
   1d228:      	ldr	x14, [x1, #0xac0]
   1d22c:      	stur	x14, [sp, #0x60]
   1d230:      	ldr	x0, [x1, #0xac8]
   1d234:      	ldr	x0, [x1, #0xad0]
   1d238:      	ldr	x28, [x1, #0xad8]
   1d23c:      	str	x28, [sp, #0x188]
   1d240:      	ldr	x28, [x1, #0xae0]
   1d244:      	str	x28, [sp, #0x180]
   1d248:      	ldr	x0, [x1, #0xae8]
   1d24c:      	ldr	x0, [x1, #0xaf0]
   1d250:      	ldr	x28, [x1, #0xaf8]
   1d254:      	str	x28, [sp, #0x178]
   1d258:      	ldr	x28, [x1, #0xb00]
   1d25c:      	str	x28, [sp, #0x170]
   1d260:      	ldr	x0, [x1, #0xb08]
   1d264:      	ldr	x0, [x1, #0xb10]
   1d268:      	ldr	x28, [x1, #0xb18]
   1d26c:      	str	x28, [sp, #0x168]
   1d270:      	ldr	x28, [x1, #0xb20]
   1d274:      	str	x28, [sp, #0x160]
   1d278:      	ldr	x0, [x1, #0xb28]
   1d27c:      	ldr	x0, [x1, #0xb30]
   1d280:      	ldr	x28, [x1, #0xb38]
   1d284:      	str	x28, [sp, #0x158]
   1d288:      	ldr	x28, [x1, #0xb40]
   1d28c:      	str	x28, [sp, #0x150]
   1d290:      	ldr	x0, [x1, #0xb48]
   1d294:      	ldr	x0, [x1, #0xb50]
   1d298:      	ldr	x28, [x1, #0xb58]
   1d29c:      	str	x28, [sp, #0x148]
   1d2a0:      	ldr	x28, [x1, #0xb60]
   1d2a4:      	str	x28, [sp, #0x140]
   1d2a8:      	ldr	x0, [x1, #0xb68]
   1d2ac:      	ldr	x0, [x1, #0xb70]
   1d2b0:      	ldr	x28, [x1, #0xb78]
   1d2b4:      	str	x28, [sp, #0x138]
   1d2b8:      	ldr	x28, [x1, #0xb80]
   1d2bc:      	str	x28, [sp, #0x130]
   1d2c0:      	ldr	x0, [x1, #0xb88]
   1d2c4:      	ldr	x0, [x1, #0xb90]
   1d2c8:      	ldr	x28, [x1, #0xb98]
   1d2cc:      	str	x28, [sp, #0x128]
   1d2d0:      	ldr	x28, [x1, #0xba0]
   1d2d4:      	str	x28, [sp, #0x120]
   1d2d8:      	ldr	x0, [x1, #0xba8]
   1d2dc:      	ldr	x0, [x1, #0xbb0]
   1d2e0:      	ldr	x28, [x1, #0xbb8]
   1d2e4:      	str	x28, [sp, #0x118]
   1d2e8:      	ldr	x28, [x1, #0xbc0]
   1d2ec:      	str	x28, [sp, #0x110]
   1d2f0:      	ldr	x0, [x1, #0xbc8]
   1d2f4:      	ldr	x0, [x1, #0xbd0]
   1d2f8:      	ldr	x28, [x1, #0xbd8]
   1d2fc:      	str	x28, [sp, #0x108]
   1d300:      	ldr	x0, [x1, #0xbe0]
   1d304:      	str	x0, [sp, #0x100]
   1d308:      	ldr	x0, [x1, #0xbe8]
   1d30c:      	ldr	x0, [x1, #0xbf0]
   1d310:      	ldr	x2, [x1, #0xc48]
   1d314:      	stur	x2, [sp, #0xc8]
   1d318:      	str	x1, [sp, #0x198]
   1d31c:      	mov	x11, #0x0               ; =0
   1d320:      	mov	x4, #0x1                ; =1
   1d324:      	stur	x4, [sp, #0xa0]
   1d328:      	mov	x5, x11
   1d32c:      	mov	x6, x11
   1d330:      	mov	x9, x11
   1d334:      	mov	x12, x11
   1d338:      	mov	x13, x11
   1d33c:      	mov	x15, x11
   1d340:      	mov	x21, x11
   1d344:      	mov	x24, x11
   1d348:      	stur	x3, [sp, #0x90]
   1d34c:      	stur	x11, [sp, #0xb8]
   1d350:      	stur	x11, [sp, #0xc0]
   1d354:      	mov	w0, #0xc87e             ; =51326
   1d358:      	movk	w0, #0x1, lsl #16
   1d35c:      	cmp	x3, x0
   1d360:      	cset	x4, hs
   1d364:      	ldur	x1, [sp, #0xc8]
   1d368:      	ldur	x14, [sp, #0x60]
   1d36c:      	cmp	x14, x1
   1d370:      	cset	x7, ls
   1d374:      	sub	x8, x1, x14
   1d378:      	cmp	x8, #0x4
   1d37c:      	cset	x8, hi
   1d380:      	and	w10, w7, w8
   1d384:      	and	w4, w4, w10
   1d388:      	stur	x10, [sp, #0xf8]
   1d38c:      	uxtb	w4, w4
   1d390:      	cbnz	x4, 0x1d69c <_mech_canonical_program_entry_v1_numeric_1282+0x51c>
   1d394:      	mov	x7, #0x0                ; =0
   1d398:      	str	x7, [x19, #0x18]
   1d39c:      	mov	x8, #0x1000000000000000 ; =1152921504606846976
   1d3a0:      	str	x8, [x19, #0x20]
   1d3a4:      	mov	x10, #0x1               ; =1
   1d3a8:      	str	x10, [x19, #0x30]
   1d3ac:      	mov	x8, #0x101010101010101  ; =72340172838076673
   1d3b0:      	str	x8, [x19, #0x38]
   1d3b4:      	mov	x14, #0x2               ; =2
   1d3b8:      	str	x14, [x19, #0x40]
   1d3bc:      	mov	x14, #0x3               ; =3
   1d3c0:      	str	x14, [x19, #0x48]
   1d3c4:      	mov	x14, #0x4               ; =4
   1d3c8:      	str	x14, [x19, #0x50]
   1d3cc:      	mov	x14, #0xf0f0f0f0f0f0f0f ; =1085102592571150095
   1d3d0:      	str	x14, [x19, #0x78]
   1d3d4:      	mov	x14, #0x3333333333333333 ; =3689348814741910323
   1d3d8:      	str	x14, [x19, #0x88]
   1d3dc:      	mov	x14, #0x38              ; =56
   1d3e0:      	str	x14, [x19, #0x90]
   1d3e4:      	mov	x0, #0x3a               ; =58
   1d3e8:      	str	x0, [x19, #0x98]
   1d3ec:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   1d3f0:      	str	x0, [x19, #0xb0]
   1d3f4:      	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
   1d3f8:      	str	x0, [x19, #0xb8]
   1d3fc:      	str	x7, [x19, #0x188]
   1d400:      	str	x10, [x19, #0x190]
   1d404:      	mov	x0, x26
   1d408:      	str	x0, [x19, #0x4c60]
   1d40c:      	str	x3, [x19, #0x4c68]
   1d410:      	ldur	x4, [sp, #0x98]
   1d414:      	str	x4, [x19, #0x4c70]
   1d418:      	str	x22, [x19, #0x4f70]
   1d41c:      	str	x23, [x19, #0x4f78]
   1d420:      	ldur	x14, [sp, #0x60]
   1d424:      	str	x14, [x19, #0x5a20]
   1d428:      	str	x11, [x19, #0x5bb0]
   1d42c:      	ldur	x0, [sp, #0xa0]
   1d430:      	str	x0, [x19, #0x5bb8]
   1d434:      	str	x5, [x19, #0x5bc0]
   1d438:      	ldur	x4, [sp, #0x90]
   1d43c:      	sub	x0, x4, x3
   1d440:      	mov	w1, #0xc87e             ; =51326
   1d444:      	movk	w1, #0x1, lsl #16
   1d448:      	msub	x0, x11, x1, x0
   1d44c:      	str	x0, [x19, #0x5bc8]
   1d450:      	str	x24, [x19, #0x5bd0]
   1d454:      	str	x15, [x19, #0x5bd8]
   1d458:      	str	x6, [x19, #0x5be8]
   1d45c:      	ldur	x4, [sp, #0xb8]
   1d460:      	str	x4, [x19, #0x5bf0]
   1d464:      	str	x12, [x19, #0x5c00]
   1d468:      	str	x9, [x19, #0x5c08]
   1d46c:      	str	x13, [x19, #0x5c18]
   1d470:      	ldur	x13, [sp, #0xc0]
   1d474:      	str	x13, [x19, #0x5c20]
   1d478:      	ldr	x0, [x19, #0x4c60]
   1d47c:      	cmp	x0, #0x0
   1d480:      	b.eq	0x1d674 <_mech_canonical_program_entry_v1_numeric_1282+0x4f4>
   1d484:      	ldr	x3, [x19, #0x4c68]
   1d488:      	ldr	x4, [x19, #0x4c70]
   1d48c:      	mov	x0, #0x0                ; =0
   1d490:      	str	x0, [x19, #0x4c60]
   1d494:      	mov	x0, #0x3                ; =3
   1d498:      	ldr	x10, [sp, #0x190]
   1d49c:      	cmp	x10, #0x19a
   1d4a0:      	b.lo	0x21bb0 <_mech_canonical_program_entry_v1_numeric_1282+0x4a30>
   1d4a4:      	ldr	x0, [x19, #0x4f70]
   1d4a8:      	ldr	x14, [sp, #0x198]
   1d4ac:      	str	x0, [x14, #0x10]
   1d4b0:      	ldr	x1, [x19, #0x4f78]
   1d4b4:      	str	x1, [x14, #0x18]
   1d4b8:      	ldr	x2, [x19, #0x5a20]
   1d4bc:      	str	x2, [x14, #0xac0]
   1d4c0:      	str	x0, [x14, #0x10]
   1d4c4:      	str	x1, [x14, #0x18]
   1d4c8:      	ldr	x0, [x19, #0x50c0]
   1d4cc:      	str	x0, [x14, #0x160]
   1d4d0:      	ldr	x0, [x19, #0x50c8]
   1d4d4:      	str	x0, [x14, #0x168]
   1d4d8:      	ldr	x0, [x19, #0x50d0]
   1d4dc:      	str	x0, [x14, #0x170]
   1d4e0:      	ldr	x0, [x19, #0x50d8]
   1d4e4:      	str	x0, [x14, #0x178]
   1d4e8:      	ldr	x0, [x19, #0x50e0]
   1d4ec:      	str	x0, [x14, #0x180]
   1d4f0:      	ldr	x0, [x19, #0x50e8]
   1d4f4:      	str	x0, [x14, #0x188]
   1d4f8:      	ldr	x0, [x19, #0x50f0]
   1d4fc:      	str	x0, [x14, #0x190]
   1d500:      	ldr	x0, [x19, #0x50f8]
   1d504:      	str	x0, [x14, #0x198]
   1d508:      	ldr	x0, [x19, #0x5100]
   1d50c:      	str	x0, [x14, #0x1a0]
   1d510:      	ldr	x0, [x19, #0x52a8]
   1d514:      	str	x0, [x14, #0x348]
   1d518:      	ldr	x0, [x19, #0x52b0]
   1d51c:      	str	x0, [x14, #0x350]
   1d520:      	ldr	x0, [x19, #0x52b8]
   1d524:      	str	x0, [x14, #0x358]
   1d528:      	ldr	x0, [x19, #0x52c0]
   1d52c:      	str	x0, [x14, #0x360]
   1d530:      	ldr	x0, [x19, #0x52c8]
   1d534:      	str	x0, [x14, #0x368]
   1d538:      	ldr	x1, [x19, #0x52d0]
   1d53c:      	str	x1, [x14, #0x370]
   1d540:      	ldr	x2, [x19, #0x52d8]
   1d544:      	str	x2, [x14, #0x378]
   1d548:      	ldr	x5, [x19, #0x52e0]
   1d54c:      	str	x5, [x14, #0x380]
   1d550:      	ldr	x5, [x19, #0x52e8]
   1d554:      	str	x5, [x14, #0x388]
   1d558:      	ldr	x5, [x19, #0x55d8]
   1d55c:      	str	x5, [x14, #0x678]
   1d560:      	ldr	x6, [x19, #0x55e0]
   1d564:      	str	x6, [x14, #0x680]
   1d568:      	ldr	x7, [x19, #0x55e8]
   1d56c:      	str	x7, [x14, #0x688]
   1d570:      	ldr	x8, [x19, #0x55f0]
   1d574:      	str	x8, [x14, #0x690]
   1d578:      	ldr	x9, [x19, #0x55f8]
   1d57c:      	str	x9, [x14, #0x698]
   1d580:      	ldr	x10, [x19, #0x5600]
   1d584:      	str	x10, [x14, #0x6a0]
   1d588:      	ldr	x11, [x19, #0x5608]
   1d58c:      	str	x11, [x14, #0x6a8]
   1d590:      	ldr	x12, [x19, #0x5610]
   1d594:      	str	x12, [x14, #0x6b0]
   1d598:      	ldr	x13, [x19, #0x57a0]
   1d59c:      	str	x13, [x14, #0x840]
   1d5a0:      	ldr	x15, [x19, #0x57a8]
   1d5a4:      	str	x15, [x14, #0x848]
   1d5a8:      	ldr	x15, [x19, #0x57b0]
   1d5ac:      	str	x15, [x14, #0x850]
   1d5b0:      	ldr	x0, [x19, #0x57b8]
   1d5b4:      	str	x0, [x14, #0x858]
   1d5b8:      	ldr	x0, [x19, #0x57c0]
   1d5bc:      	str	x0, [x14, #0x860]
   1d5c0:      	ldr	x0, [x19, #0x57c8]
   1d5c4:      	str	x0, [x14, #0x868]
   1d5c8:      	ldr	x0, [x19, #0x57d0]
   1d5cc:      	str	x0, [x14, #0x870]
   1d5d0:      	ldr	x0, [x19, #0x57d8]
   1d5d4:      	str	x0, [x14, #0x878]
   1d5d8:      	ldr	x0, [x19, #0x5bb0]
   1d5dc:      	str	x0, [x14, #0xc50]
   1d5e0:      	ldr	x0, [x19, #0x5bb8]
   1d5e4:      	str	x0, [x14, #0xc58]
   1d5e8:      	ldr	x0, [x19, #0x5bc0]
   1d5ec:      	str	x0, [x14, #0xc60]
   1d5f0:      	ldr	x0, [x19, #0x5bc8]
   1d5f4:      	str	x0, [x14, #0xc68]
   1d5f8:      	ldr	x0, [x19, #0x5bd0]
   1d5fc:      	str	x0, [x14, #0xc70]
   1d600:      	ldr	x0, [x19, #0x5bd8]
   1d604:      	str	x0, [x14, #0xc78]
   1d608:      	mov	x0, #0x0                ; =0
   1d60c:      	str	x0, [x14, #0xc80]
   1d610:      	ldr	x1, [x19, #0x5be8]
   1d614:      	str	x1, [x14, #0xc88]
   1d618:      	ldr	x1, [x19, #0x5bf0]
   1d61c:      	str	x1, [x14, #0xc90]
   1d620:      	str	x0, [x14, #0xc98]
   1d624:      	ldr	x1, [x19, #0x5c00]
   1d628:      	str	x1, [x14, #0xca0]
   1d62c:      	ldr	x1, [x19, #0x5c08]
   1d630:      	str	x1, [x14, #0xca8]
   1d634:      	str	x0, [x14, #0xcb0]
   1d638:      	ldr	x0, [x19, #0x5c18]
   1d63c:      	str	x0, [x14, #0xcb8]
   1d640:      	ldr	x0, [x19, #0x5c20]
   1d644:      	str	x0, [x14, #0xcc0]
   1d648:      	mov	x1, #0x502              ; =1282
   1d64c:      	mov	x2, #-0x9               ; =-9
   1d650:      	mov	x5, #0x1                ; =1
   1d654:      	ldur	x0, [sp, #0x8]
   1d658:      	ldr	x6, [sp, #0x1a0]
   1d65c:      	ldr	x21, [sp, #0x1a8]
   1d660:      	blr	x21
   1d664:      	mov	x15, x0
   1d668:      	mov	x0, #0x2                ; =2
   1d66c:      	cmp	x15, #0x0
   1d670:      	b.ne	0x21bb8 <_mech_canonical_program_entry_v1_numeric_1282+0x4a38>
   1d674:      	mov	x1, #0x0                ; =0
   1d678:      	mov	x0, x1
   1d67c:      	add	sp, sp, #0x1c0
   1d680:      	ldp	x19, x20, [sp], #0x10
   1d684:      	ldp	x21, x22, [sp], #0x10
   1d688:      	ldp	x23, x24, [sp], #0x10
   1d68c:      	ldp	x25, x26, [sp], #0x10
   1d690:      	ldp	x27, x28, [sp], #0x10
   1d694:      	ldp	x29, x30, [sp], #0x10
   1d698:      	retab
   1d69c:      	ldur	x4, [sp, #0x98]
   1d6a0:      	ldr	x10, [sp, #0x190]
   1d6a4:      	ldr	x14, [sp, #0x198]
   1d6a8:      	stur	x5, [sp, #0xa8]
   1d6ac:      	cmp	x22, x23
   1d6b0:      	cset	x0, lo
   1d6b4:      	cmp	x22, x23
   1d6b8:      	b.lo	0x1d704 <_mech_canonical_program_entry_v1_numeric_1282+0x584>
   1d6bc:      	mov	x0, #0x0                ; =0
   1d6c0:      	stur	x0, [sp, #0x10]
   1d6c4:      	mov	w0, #0xc87e             ; =51326
   1d6c8:      	movk	w0, #0x1, lsl #16
   1d6cc:      	sub	x3, x3, x0
   1d6d0:      	mov	x27, x22
   1d6d4:      	mov	x28, x26
   1d6d8:      	ldur	x0, [sp, #0x10]
   1d6dc:      	stur	x0, [sp, #0x68]
   1d6e0:      	stur	x0, [sp, #0x70]
   1d6e4:      	stur	x0, [sp, #0x78]
   1d6e8:      	stur	x0, [sp, #0x80]
   1d6ec:      	stur	x22, [sp, #0x88]
   1d6f0:      	stur	x4, [sp, #0x98]
   1d6f4:      	stur	x6, [sp, #0xb0]
   1d6f8:      	str	x10, [sp, #0x190]
   1d6fc:      	str	x14, [sp, #0x198]
   1d700:      	b	0x210e8 <_mech_canonical_program_entry_v1_numeric_1282+0x3f68>
   1d704:      	ldr	x1, [sp, #0x180]
   1d708:      	cmp	x22, x1
   1d70c:      	b.lo	0x1d95c <_mech_canonical_program_entry_v1_numeric_1282+0x7dc>
   1d710:      	b	0x21bc0 <_mech_canonical_program_entry_v1_numeric_1282+0x4a40>
   1d714:      	str	x10, [sp, #0x190]
   1d718:      	str	x14, [sp, #0x198]
   1d71c:      	b	0x1d908 <_mech_canonical_program_entry_v1_numeric_1282+0x788>
   1d720:      	ldr	x3, [x19, #0x4c68]
   1d724:      	ldr	x4, [x19, #0x4c70]
   1d728:      	mov	x0, #0x0                ; =0
   1d72c:      	str	x0, [x19, #0x4c60]
   1d730:      	mov	x0, #0x3                ; =3
   1d734:      	cmp	x10, #0x19a
   1d738:      	str	x10, [sp, #0x190]
   1d73c:      	b.lo	0x21ce0 <_mech_canonical_program_entry_v1_numeric_1282+0x4b60>
   1d740:      	ldr	x0, [x19, #0x4f70]
   1d744:      	str	x0, [x14, #0x10]
   1d748:      	ldr	x1, [x19, #0x4f78]
   1d74c:      	str	x1, [x14, #0x18]
   1d750:      	ldr	x2, [x19, #0x5a20]
   1d754:      	str	x2, [x14, #0xac0]
   1d758:      	str	x0, [x14, #0x10]
   1d75c:      	str	x1, [x14, #0x18]
   1d760:      	ldr	x0, [x19, #0x50c0]
   1d764:      	str	x0, [x14, #0x160]
   1d768:      	ldr	x0, [x19, #0x50c8]
   1d76c:      	str	x0, [x14, #0x168]
   1d770:      	ldr	x0, [x19, #0x50d0]
   1d774:      	str	x0, [x14, #0x170]
   1d778:      	ldr	x0, [x19, #0x50d8]
   1d77c:      	str	x0, [x14, #0x178]
   1d780:      	ldr	x0, [x19, #0x50e0]
   1d784:      	str	x0, [x14, #0x180]
   1d788:      	ldr	x0, [x19, #0x50e8]
   1d78c:      	str	x0, [x14, #0x188]
   1d790:      	ldr	x0, [x19, #0x50f0]
   1d794:      	str	x0, [x14, #0x190]
   1d798:      	ldr	x0, [x19, #0x50f8]
   1d79c:      	str	x0, [x14, #0x198]
   1d7a0:      	ldr	x0, [x19, #0x5100]
   1d7a4:      	str	x0, [x14, #0x1a0]
   1d7a8:      	ldr	x0, [x19, #0x52a8]
   1d7ac:      	str	x0, [x14, #0x348]
   1d7b0:      	ldr	x0, [x19, #0x52b0]
   1d7b4:      	str	x0, [x14, #0x350]
   1d7b8:      	ldr	x0, [x19, #0x52b8]
   1d7bc:      	str	x0, [x14, #0x358]
   1d7c0:      	ldr	x0, [x19, #0x52c0]
   1d7c4:      	str	x0, [x14, #0x360]
   1d7c8:      	ldr	x0, [x19, #0x52c8]
   1d7cc:      	str	x0, [x14, #0x368]
   1d7d0:      	ldr	x0, [x19, #0x52d0]
   1d7d4:      	str	x0, [x14, #0x370]
   1d7d8:      	ldr	x1, [x19, #0x52d8]
   1d7dc:      	str	x1, [x14, #0x378]
   1d7e0:      	ldr	x2, [x19, #0x52e0]
   1d7e4:      	str	x2, [x14, #0x380]
   1d7e8:      	ldr	x5, [x19, #0x52e8]
   1d7ec:      	str	x5, [x14, #0x388]
   1d7f0:      	ldr	x5, [x19, #0x55d8]
   1d7f4:      	str	x5, [x14, #0x678]
   1d7f8:      	ldr	x5, [x19, #0x55e0]
   1d7fc:      	str	x5, [x14, #0x680]
   1d800:      	ldr	x6, [x19, #0x55e8]
   1d804:      	str	x6, [x14, #0x688]
   1d808:      	ldr	x7, [x19, #0x55f0]
   1d80c:      	str	x7, [x14, #0x690]
   1d810:      	ldr	x8, [x19, #0x55f8]
   1d814:      	str	x8, [x14, #0x698]
   1d818:      	ldr	x9, [x19, #0x5600]
   1d81c:      	str	x9, [x14, #0x6a0]
   1d820:      	ldr	x10, [x19, #0x5608]
   1d824:      	str	x10, [x14, #0x6a8]
   1d828:      	ldr	x11, [x19, #0x5610]
   1d82c:      	str	x11, [x14, #0x6b0]
   1d830:      	ldr	x12, [x19, #0x57a0]
   1d834:      	str	x12, [x14, #0x840]
   1d838:      	ldr	x13, [x19, #0x57a8]
   1d83c:      	str	x13, [x14, #0x848]
   1d840:      	ldr	x15, [x19, #0x57b0]
   1d844:      	str	x15, [x14, #0x850]
   1d848:      	ldr	x15, [x19, #0x57b8]
   1d84c:      	str	x15, [x14, #0x858]
   1d850:      	ldr	x0, [x19, #0x57c0]
   1d854:      	str	x0, [x14, #0x860]
   1d858:      	ldr	x0, [x19, #0x57c8]
   1d85c:      	str	x0, [x14, #0x868]
   1d860:      	ldr	x0, [x19, #0x57d0]
   1d864:      	str	x0, [x14, #0x870]
   1d868:      	ldr	x0, [x19, #0x57d8]
   1d86c:      	str	x0, [x14, #0x878]
   1d870:      	ldr	x0, [x19, #0x5bb0]
   1d874:      	str	x0, [x14, #0xc50]
   1d878:      	ldr	x0, [x19, #0x5bb8]
   1d87c:      	str	x0, [x14, #0xc58]
   1d880:      	ldr	x0, [x19, #0x5bc0]
   1d884:      	str	x0, [x14, #0xc60]
   1d888:      	ldr	x0, [x19, #0x5bc8]
   1d88c:      	str	x0, [x14, #0xc68]
   1d890:      	ldr	x0, [x19, #0x5bd0]
   1d894:      	str	x0, [x14, #0xc70]
   1d898:      	ldr	x0, [x19, #0x5bd8]
   1d89c:      	str	x0, [x14, #0xc78]
   1d8a0:      	mov	x0, #0x0                ; =0
   1d8a4:      	str	x0, [x14, #0xc80]
   1d8a8:      	ldr	x1, [x19, #0x5be8]
   1d8ac:      	str	x1, [x14, #0xc88]
   1d8b0:      	ldr	x1, [x19, #0x5bf0]
   1d8b4:      	str	x1, [x14, #0xc90]
   1d8b8:      	str	x0, [x14, #0xc98]
   1d8bc:      	ldr	x1, [x19, #0x5c00]
   1d8c0:      	str	x1, [x14, #0xca0]
   1d8c4:      	ldr	x1, [x19, #0x5c08]
   1d8c8:      	str	x1, [x14, #0xca8]
   1d8cc:      	str	x0, [x14, #0xcb0]
   1d8d0:      	ldr	x0, [x19, #0x5c18]
   1d8d4:      	str	x0, [x14, #0xcb8]
   1d8d8:      	ldr	x0, [x19, #0x5c20]
   1d8dc:      	str	x0, [x14, #0xcc0]
   1d8e0:      	str	x14, [sp, #0x198]
   1d8e4:      	mov	x1, #0x512              ; =1298
   1d8e8:      	mov	x2, #-0x9               ; =-9
   1d8ec:      	ldr	x21, [sp, #0x1a8]
   1d8f0:      	ldur	x0, [sp, #0x8]
   1d8f4:      	mov	x5, x20
   1d8f8:      	ldr	x6, [sp, #0x1a0]
   1d8fc:      	blr	x21
   1d900:      	cmp	x0, #0x0
   1d904:      	b.ne	0x21ce8 <_mech_canonical_program_entry_v1_numeric_1282+0x4b68>
   1d908:      	mov	x0, #0x3                ; =3
   1d90c:      	ldr	x15, [sp, #0x190]
   1d910:      	cmp	x15, #0x2
   1d914:      	b.lo	0x21cf0 <_mech_canonical_program_entry_v1_numeric_1282+0x4b70>
   1d918:      	mov	x5, #0x0                ; =0
   1d91c:      	ldr	x3, [sp, #0x198]
   1d920:      	str	x5, [x3]
   1d924:      	ldr	x0, [x19, #0x17d0]
   1d928:      	str	x0, [x3, #0x8]
   1d92c:      	mov	x1, #0x512              ; =1298
   1d930:      	ldur	x0, [sp, #0x8]
   1d934:      	ldr	x6, [sp, #0x1a0]
   1d938:      	ldr	x21, [sp, #0x1a8]
   1d93c:      	mov	x4, x20
   1d940:      	mov	x2, x5
   1d944:      	blr	x21
   1d948:      	cmp	x0, #0x0
   1d94c:      	b.ne	0x21cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x4b78>
   1d950:      	mov	x0, #0x3                ; =3
   1d954:      	mov	x21, x0
   1d958:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1d95c:      	ldr	x2, [sp, #0x188]
   1d960:      	ldur	x5, [sp]
   1d964:      	mov	x28, x26
   1d968:      	stur	x6, [sp, #0xb0]
   1d96c:      	str	x10, [sp, #0x190]
   1d970:      	str	x14, [sp, #0x198]
   1d974:      	ldr	x1, [x2, x22, lsl #3]
   1d978:      	add	x2, x22, #0x1
   1d97c:      	ldr	x6, [sp, #0x180]
   1d980:      	cmp	x2, x6
   1d984:      	stur	x2, [sp, #0xe8]
   1d988:      	b.lo	0x1dc04 <_mech_canonical_program_entry_v1_numeric_1282+0xa84>
   1d98c:      	b	0x21d00 <_mech_canonical_program_entry_v1_numeric_1282+0x4b80>
   1d990:      	ldr	x3, [x19, #0x4c68]
   1d994:      	ldr	x4, [x19, #0x4c70]
   1d998:      	mov	x0, #0x0                ; =0
   1d99c:      	str	x0, [x19, #0x4c60]
   1d9a0:      	mov	x0, #0x3                ; =3
   1d9a4:      	ldr	x15, [sp, #0x190]
   1d9a8:      	cmp	x15, #0x19a
   1d9ac:      	b.lo	0x21e20 <_mech_canonical_program_entry_v1_numeric_1282+0x4ca0>
   1d9b0:      	ldr	x0, [x19, #0x4f70]
   1d9b4:      	ldr	x1, [sp, #0x198]
   1d9b8:      	str	x0, [x1, #0x10]
   1d9bc:      	ldr	x1, [x19, #0x4f78]
   1d9c0:      	ldr	x2, [sp, #0x198]
   1d9c4:      	str	x1, [x2, #0x18]
   1d9c8:      	ldr	x2, [x19, #0x5a20]
   1d9cc:      	ldr	x5, [sp, #0x198]
   1d9d0:      	str	x2, [x5, #0xac0]
   1d9d4:      	ldr	x2, [sp, #0x198]
   1d9d8:      	str	x0, [x2, #0x10]
   1d9dc:      	ldr	x0, [sp, #0x198]
   1d9e0:      	str	x1, [x0, #0x18]
   1d9e4:      	ldr	x0, [x19, #0x50c0]
   1d9e8:      	ldr	x1, [sp, #0x198]
   1d9ec:      	str	x0, [x1, #0x160]
   1d9f0:      	ldr	x0, [x19, #0x50c8]
   1d9f4:      	str	x0, [x1, #0x168]
   1d9f8:      	ldr	x0, [x19, #0x50d0]
   1d9fc:      	str	x0, [x1, #0x170]
   1da00:      	ldr	x0, [x19, #0x50d8]
   1da04:      	str	x0, [x1, #0x178]
   1da08:      	ldr	x0, [x19, #0x50e0]
   1da0c:      	str	x0, [x1, #0x180]
   1da10:      	ldr	x0, [x19, #0x50e8]
   1da14:      	str	x0, [x1, #0x188]
   1da18:      	ldr	x0, [x19, #0x50f0]
   1da1c:      	str	x0, [x5, #0x190]
   1da20:      	ldr	x0, [x19, #0x50f8]
   1da24:      	ldr	x7, [sp, #0x198]
   1da28:      	str	x0, [x7, #0x198]
   1da2c:      	ldr	x0, [x19, #0x5100]
   1da30:      	ldr	x10, [sp, #0x198]
   1da34:      	str	x0, [x10, #0x1a0]
   1da38:      	ldr	x0, [x19, #0x52a8]
   1da3c:      	ldr	x13, [sp, #0x198]
   1da40:      	str	x0, [x13, #0x348]
   1da44:      	ldr	x0, [x19, #0x52b0]
   1da48:      	str	x0, [x1, #0x350]
   1da4c:      	ldr	x0, [x19, #0x52b8]
   1da50:      	str	x0, [x1, #0x358]
   1da54:      	ldr	x0, [x19, #0x52c0]
   1da58:      	str	x0, [x1, #0x360]
   1da5c:      	ldr	x0, [x19, #0x52c8]
   1da60:      	str	x0, [x1, #0x368]
   1da64:      	ldr	x0, [x19, #0x52d0]
   1da68:      	str	x0, [x1, #0x370]
   1da6c:      	ldr	x0, [x19, #0x52d8]
   1da70:      	str	x0, [x1, #0x378]
   1da74:      	ldr	x0, [x19, #0x52e0]
   1da78:      	str	x0, [x1, #0x380]
   1da7c:      	ldr	x0, [x19, #0x52e8]
   1da80:      	str	x0, [x1, #0x388]
   1da84:      	ldr	x0, [x19, #0x55d8]
   1da88:      	str	x0, [x1, #0x678]
   1da8c:      	ldr	x0, [x19, #0x55e0]
   1da90:      	str	x0, [x1, #0x680]
   1da94:      	ldr	x0, [x19, #0x55e8]
   1da98:      	str	x0, [x1, #0x688]
   1da9c:      	ldr	x0, [x19, #0x55f0]
   1daa0:      	str	x0, [x1, #0x690]
   1daa4:      	ldr	x0, [x19, #0x55f8]
   1daa8:      	str	x0, [x1, #0x698]
   1daac:      	ldr	x1, [x19, #0x5600]
   1dab0:      	ldr	x0, [sp, #0x198]
   1dab4:      	str	x1, [x0, #0x6a0]
   1dab8:      	ldr	x2, [x19, #0x5608]
   1dabc:      	str	x2, [x0, #0x6a8]
   1dac0:      	ldr	x5, [x19, #0x5610]
   1dac4:      	str	x5, [x0, #0x6b0]
   1dac8:      	ldr	x5, [x19, #0x57a0]
   1dacc:      	ldr	x1, [sp, #0x198]
   1dad0:      	str	x5, [x1, #0x840]
   1dad4:      	ldr	x5, [x19, #0x57a8]
   1dad8:      	ldr	x6, [sp, #0x198]
   1dadc:      	str	x5, [x6, #0x848]
   1dae0:      	ldr	x6, [x19, #0x57b0]
   1dae4:      	str	x6, [x7, #0x850]
   1dae8:      	ldr	x7, [x19, #0x57b8]
   1daec:      	str	x7, [x10, #0x858]
   1daf0:      	ldr	x8, [x19, #0x57c0]
   1daf4:      	str	x8, [x13, #0x860]
   1daf8:      	ldr	x9, [x19, #0x57c8]
   1dafc:      	str	x9, [x0, #0x868]
   1db00:      	ldr	x10, [x19, #0x57d0]
   1db04:      	str	x10, [x0, #0x870]
   1db08:      	ldr	x11, [x19, #0x57d8]
   1db0c:      	str	x11, [x0, #0x878]
   1db10:      	ldr	x12, [x19, #0x5bb0]
   1db14:      	str	x12, [x0, #0xc50]
   1db18:      	ldr	x13, [x19, #0x5bb8]
   1db1c:      	str	x13, [x0, #0xc58]
   1db20:      	ldr	x14, [x19, #0x5bc0]
   1db24:      	str	x14, [x0, #0xc60]
   1db28:      	ldr	x15, [x19, #0x5bc8]
   1db2c:      	str	x15, [x0, #0xc68]
   1db30:      	ldr	x0, [x19, #0x5bd0]
   1db34:      	str	x0, [x1, #0xc70]
   1db38:      	ldr	x0, [x19, #0x5bd8]
   1db3c:      	str	x0, [x1, #0xc78]
   1db40:      	mov	x0, #0x0                ; =0
   1db44:      	str	x0, [x1, #0xc80]
   1db48:      	ldr	x1, [x19, #0x5be8]
   1db4c:      	ldr	x2, [sp, #0x198]
   1db50:      	str	x1, [x2, #0xc88]
   1db54:      	ldr	x1, [x19, #0x5bf0]
   1db58:      	str	x1, [x2, #0xc90]
   1db5c:      	ldr	x1, [sp, #0x198]
   1db60:      	str	x0, [x1, #0xc98]
   1db64:      	ldr	x1, [x19, #0x5c00]
   1db68:      	str	x1, [x2, #0xca0]
   1db6c:      	ldr	x1, [x19, #0x5c08]
   1db70:      	str	x1, [x2, #0xca8]
   1db74:      	ldr	x1, [sp, #0x198]
   1db78:      	str	x0, [x1, #0xcb0]
   1db7c:      	ldr	x0, [x19, #0x5c18]
   1db80:      	str	x0, [x1, #0xcb8]
   1db84:      	ldr	x0, [x19, #0x5c20]
   1db88:      	str	x0, [x2, #0xcc0]
   1db8c:      	mov	x1, #0x514              ; =1300
   1db90:      	mov	x2, #-0x9               ; =-9
   1db94:      	ldr	x21, [sp, #0x1a8]
   1db98:      	ldur	x0, [sp, #0x8]
   1db9c:      	mov	x5, x20
   1dba0:      	ldr	x6, [sp, #0x1a0]
   1dba4:      	blr	x21
   1dba8:      	cmp	x0, #0x0
   1dbac:      	b.ne	0x21e28 <_mech_canonical_program_entry_v1_numeric_1282+0x4ca8>
   1dbb0:      	mov	x0, #0x3                ; =3
   1dbb4:      	ldr	x15, [sp, #0x190]
   1dbb8:      	cmp	x15, #0x2
   1dbbc:      	b.lo	0x21e30 <_mech_canonical_program_entry_v1_numeric_1282+0x4cb0>
   1dbc0:      	mov	x5, #0x0                ; =0
   1dbc4:      	ldr	x3, [sp, #0x198]
   1dbc8:      	str	x5, [x3]
   1dbcc:      	ldr	x0, [x19, #0x17e0]
   1dbd0:      	str	x0, [x3, #0x8]
   1dbd4:      	mov	x1, #0x514              ; =1300
   1dbd8:      	ldur	x0, [sp, #0x8]
   1dbdc:      	ldr	x6, [sp, #0x1a0]
   1dbe0:      	ldr	x21, [sp, #0x1a8]
   1dbe4:      	mov	x4, x20
   1dbe8:      	mov	x2, x5
   1dbec:      	blr	x21
   1dbf0:      	cmp	x0, #0x0
   1dbf4:      	b.ne	0x21e38 <_mech_canonical_program_entry_v1_numeric_1282+0x4cb8>
   1dbf8:      	mov	x0, #0x3                ; =3
   1dbfc:      	mov	x21, x0
   1dc00:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1dc04:      	ldur	x2, [sp, #0xe8]
   1dc08:      	ldr	x6, [sp, #0x188]
   1dc0c:      	ldr	x2, [x6, x2, lsl #3]
   1dc10:      	ldr	x6, [sp, #0x170]
   1dc14:      	cmp	x22, x6
   1dc18:      	b.lo	0x1de94 <_mech_canonical_program_entry_v1_numeric_1282+0xd14>
   1dc1c:      	b	0x21e40 <_mech_canonical_program_entry_v1_numeric_1282+0x4cc0>
   1dc20:      	ldr	x3, [x19, #0x4c68]
   1dc24:      	ldr	x4, [x19, #0x4c70]
   1dc28:      	mov	x0, #0x0                ; =0
   1dc2c:      	str	x0, [x19, #0x4c60]
   1dc30:      	mov	x0, #0x3                ; =3
   1dc34:      	ldr	x15, [sp, #0x190]
   1dc38:      	cmp	x15, #0x19a
   1dc3c:      	b.lo	0x21f64 <_mech_canonical_program_entry_v1_numeric_1282+0x4de4>
   1dc40:      	ldr	x0, [x19, #0x4f70]
   1dc44:      	ldr	x1, [sp, #0x198]
   1dc48:      	str	x0, [x1, #0x10]
   1dc4c:      	ldr	x1, [x19, #0x4f78]
   1dc50:      	ldr	x2, [sp, #0x198]
   1dc54:      	str	x1, [x2, #0x18]
   1dc58:      	ldr	x2, [x19, #0x5a20]
   1dc5c:      	ldr	x5, [sp, #0x198]
   1dc60:      	str	x2, [x5, #0xac0]
   1dc64:      	ldr	x2, [sp, #0x198]
   1dc68:      	str	x0, [x2, #0x10]
   1dc6c:      	ldr	x0, [sp, #0x198]
   1dc70:      	str	x1, [x0, #0x18]
   1dc74:      	ldr	x0, [x19, #0x50c0]
   1dc78:      	ldr	x1, [sp, #0x198]
   1dc7c:      	str	x0, [x1, #0x160]
   1dc80:      	ldr	x0, [x19, #0x50c8]
   1dc84:      	str	x0, [x1, #0x168]
   1dc88:      	ldr	x0, [x19, #0x50d0]
   1dc8c:      	str	x0, [x2, #0x170]
   1dc90:      	ldr	x0, [x19, #0x50d8]
   1dc94:      	str	x0, [x5, #0x178]
   1dc98:      	ldr	x0, [x19, #0x50e0]
   1dc9c:      	ldr	x8, [sp, #0x198]
   1dca0:      	str	x0, [x8, #0x180]
   1dca4:      	ldr	x0, [x19, #0x50e8]
   1dca8:      	ldr	x11, [sp, #0x198]
   1dcac:      	str	x0, [x11, #0x188]
   1dcb0:      	ldr	x0, [x19, #0x50f0]
   1dcb4:      	ldr	x14, [sp, #0x198]
   1dcb8:      	str	x0, [x14, #0x190]
   1dcbc:      	ldr	x0, [x19, #0x50f8]
   1dcc0:      	str	x0, [x1, #0x198]
   1dcc4:      	ldr	x0, [x19, #0x5100]
   1dcc8:      	str	x0, [x1, #0x1a0]
   1dccc:      	ldr	x0, [x19, #0x52a8]
   1dcd0:      	str	x0, [x1, #0x348]
   1dcd4:      	ldr	x0, [x19, #0x52b0]
   1dcd8:      	str	x0, [x1, #0x350]
   1dcdc:      	ldr	x0, [x19, #0x52b8]
   1dce0:      	str	x0, [x1, #0x358]
   1dce4:      	ldr	x0, [x19, #0x52c0]
   1dce8:      	str	x0, [x1, #0x360]
   1dcec:      	ldr	x0, [x19, #0x52c8]
   1dcf0:      	str	x0, [x1, #0x368]
   1dcf4:      	ldr	x0, [x19, #0x52d0]
   1dcf8:      	str	x0, [x1, #0x370]
   1dcfc:      	ldr	x0, [x19, #0x52d8]
   1dd00:      	str	x0, [x1, #0x378]
   1dd04:      	ldr	x0, [x19, #0x52e0]
   1dd08:      	str	x0, [x1, #0x380]
   1dd0c:      	ldr	x0, [x19, #0x52e8]
   1dd10:      	str	x0, [x1, #0x388]
   1dd14:      	ldr	x0, [x19, #0x55d8]
   1dd18:      	str	x0, [x1, #0x678]
   1dd1c:      	ldr	x0, [x19, #0x55e0]
   1dd20:      	str	x0, [x1, #0x680]
   1dd24:      	ldr	x0, [x19, #0x55e8]
   1dd28:      	str	x0, [x1, #0x688]
   1dd2c:      	ldr	x0, [x19, #0x55f0]
   1dd30:      	str	x0, [x1, #0x690]
   1dd34:      	ldr	x0, [x19, #0x55f8]
   1dd38:      	str	x0, [x1, #0x698]
   1dd3c:      	ldr	x0, [x19, #0x5600]
   1dd40:      	str	x0, [x2, #0x6a0]
   1dd44:      	ldr	x0, [x19, #0x5608]
   1dd48:      	str	x0, [x5, #0x6a8]
   1dd4c:      	ldr	x0, [x19, #0x5610]
   1dd50:      	str	x0, [x8, #0x6b0]
   1dd54:      	ldr	x0, [x19, #0x57a0]
   1dd58:      	str	x0, [x11, #0x840]
   1dd5c:      	ldr	x0, [x19, #0x57a8]
   1dd60:      	str	x0, [x14, #0x848]
   1dd64:      	ldr	x0, [x19, #0x57b0]
   1dd68:      	str	x0, [x1, #0x850]
   1dd6c:      	ldr	x0, [x19, #0x57b8]
   1dd70:      	str	x0, [x1, #0x858]
   1dd74:      	ldr	x1, [x19, #0x57c0]
   1dd78:      	ldr	x0, [sp, #0x198]
   1dd7c:      	str	x1, [x0, #0x860]
   1dd80:      	ldr	x2, [x19, #0x57c8]
   1dd84:      	str	x2, [x0, #0x868]
   1dd88:      	ldr	x5, [x19, #0x57d0]
   1dd8c:      	str	x5, [x0, #0x870]
   1dd90:      	ldr	x5, [x19, #0x57d8]
   1dd94:      	str	x5, [x0, #0x878]
   1dd98:      	ldr	x5, [x19, #0x5bb0]
   1dd9c:      	str	x5, [x0, #0xc50]
   1dda0:      	ldr	x6, [x19, #0x5bb8]
   1dda4:      	str	x6, [x0, #0xc58]
   1dda8:      	ldr	x7, [x19, #0x5bc0]
   1ddac:      	str	x7, [x0, #0xc60]
   1ddb0:      	ldr	x8, [x19, #0x5bc8]
   1ddb4:      	str	x8, [x0, #0xc68]
   1ddb8:      	ldr	x9, [x19, #0x5bd0]
   1ddbc:      	str	x9, [x0, #0xc70]
   1ddc0:      	ldr	x10, [x19, #0x5bd8]
   1ddc4:      	str	x10, [x0, #0xc78]
   1ddc8:      	mov	x11, #0x0               ; =0
   1ddcc:      	str	x11, [x0, #0xc80]
   1ddd0:      	ldr	x12, [x19, #0x5be8]
   1ddd4:      	str	x12, [x0, #0xc88]
   1ddd8:      	ldr	x13, [x19, #0x5bf0]
   1dddc:      	str	x13, [x0, #0xc90]
   1dde0:      	str	x11, [x0, #0xc98]
   1dde4:      	ldr	x15, [x19, #0x5c00]
   1dde8:      	ldr	x1, [sp, #0x198]
   1ddec:      	str	x15, [x1, #0xca0]
   1ddf0:      	ldr	x0, [x19, #0x5c08]
   1ddf4:      	ldr	x5, [sp, #0x198]
   1ddf8:      	str	x0, [x5, #0xca8]
   1ddfc:      	ldr	x6, [sp, #0x198]
   1de00:      	str	x11, [x6, #0xcb0]
   1de04:      	ldr	x0, [x19, #0x5c18]
   1de08:      	ldr	x9, [sp, #0x198]
   1de0c:      	str	x0, [x9, #0xcb8]
   1de10:      	ldr	x0, [x19, #0x5c20]
   1de14:      	ldr	x12, [sp, #0x198]
   1de18:      	str	x0, [x12, #0xcc0]
   1de1c:      	mov	x1, #0x516              ; =1302
   1de20:      	mov	x2, #-0x9               ; =-9
   1de24:      	ldr	x21, [sp, #0x1a8]
   1de28:      	ldur	x0, [sp, #0x8]
   1de2c:      	mov	x5, x20
   1de30:      	ldr	x6, [sp, #0x1a0]
   1de34:      	blr	x21
   1de38:      	cmp	x0, #0x0
   1de3c:      	b.ne	0x21f6c <_mech_canonical_program_entry_v1_numeric_1282+0x4dec>
   1de40:      	mov	x0, #0x3                ; =3
   1de44:      	ldr	x15, [sp, #0x190]
   1de48:      	cmp	x15, #0x2
   1de4c:      	b.lo	0x21f74 <_mech_canonical_program_entry_v1_numeric_1282+0x4df4>
   1de50:      	mov	x5, #0x0                ; =0
   1de54:      	ldr	x3, [sp, #0x198]
   1de58:      	str	x5, [x3]
   1de5c:      	ldr	x0, [x19, #0x17f0]
   1de60:      	str	x0, [x3, #0x8]
   1de64:      	mov	x1, #0x516              ; =1302
   1de68:      	ldur	x0, [sp, #0x8]
   1de6c:      	ldr	x6, [sp, #0x1a0]
   1de70:      	ldr	x21, [sp, #0x1a8]
   1de74:      	mov	x4, x20
   1de78:      	mov	x2, x5
   1de7c:      	blr	x21
   1de80:      	cmp	x0, #0x0
   1de84:      	b.ne	0x21f7c <_mech_canonical_program_entry_v1_numeric_1282+0x4dfc>
   1de88:      	mov	x0, #0x3                ; =3
   1de8c:      	mov	x21, x0
   1de90:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1de94:      	stur	x0, [sp, #0xf0]
   1de98:      	stur	x4, [sp, #0x98]
   1de9c:      	stur	x1, [sp, #0x18]
   1dea0:      	stur	x5, [sp]
   1dea4:      	mov	x26, x2
   1dea8:      	ldr	x0, [sp, #0x178]
   1deac:      	ldr	x15, [x0, x22, lsl #3]
   1deb0:      	stur	x15, [sp, #0xe0]
   1deb4:      	mov	w0, #0xc87e             ; =51326
   1deb8:      	movk	w0, #0x1, lsl #16
   1debc:      	sub	x3, x3, x0
   1dec0:      	mov	x10, #0x0               ; =0
   1dec4:      	stur	x10, [sp, #0x10]
   1dec8:      	ldur	x4, [sp, #0x10]
   1decc:      	ldur	x24, [sp, #0x10]
   1ded0:      	ldur	x27, [sp, #0x10]
   1ded4:      	ldur	x0, [sp, #0x10]
   1ded8:      	stur	x0, [sp, #0x20]
   1dedc:      	stur	x0, [sp, #0x80]
   1dee0:      	mov	w0, #0x2166             ; =8550
   1dee4:      	movk	w0, #0x1, lsl #16
   1dee8:      	cmp	x3, x0
   1deec:      	b.hs	0x1e298 <_mech_canonical_program_entry_v1_numeric_1282+0x1118>
   1def0:      	mov	x1, #0x0                ; =0
   1def4:      	str	x1, [x19, #0x18]
   1def8:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   1defc:      	str	x0, [x19, #0x20]
   1df00:      	mov	x0, #0x1                ; =1
   1df04:      	str	x0, [x19, #0x30]
   1df08:      	mov	x2, #0x101010101010101  ; =72340172838076673
   1df0c:      	str	x2, [x19, #0x38]
   1df10:      	mov	x2, #0x2                ; =2
   1df14:      	str	x2, [x19, #0x40]
   1df18:      	stur	x2, [sp, #0xd8]
   1df1c:      	mov	x2, #0x3                ; =3
   1df20:      	str	x2, [x19, #0x48]
   1df24:      	mov	x2, #0x4                ; =4
   1df28:      	str	x2, [x19, #0x50]
   1df2c:      	mov	x2, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   1df30:      	str	x2, [x19, #0x78]
   1df34:      	mov	x2, #0x3333333333333333 ; =3689348814741910323
   1df38:      	str	x2, [x19, #0x88]
   1df3c:      	mov	x2, #0x38               ; =56
   1df40:      	str	x2, [x19, #0x90]
   1df44:      	mov	x2, #0x3a               ; =58
   1df48:      	str	x2, [x19, #0x98]
   1df4c:      	mov	x2, #0x5555555555555555 ; =6148914691236517205
   1df50:      	str	x2, [x19, #0xb0]
   1df54:      	mov	x2, #0x3ffffffffffffff  ; =288230376151711743
   1df58:      	str	x2, [x19, #0xb8]
   1df5c:      	str	x1, [x19, #0x188]
   1df60:      	str	x0, [x19, #0x190]
   1df64:      	str	x22, [x19, #0x17a0]
   1df68:      	str	x23, [x19, #0x17a8]
   1df6c:      	ldur	x25, [sp, #0xf0]
   1df70:      	uxtb	w1, w25
   1df74:      	str	x1, [x19, #0x17b8]
   1df78:      	str	x28, [x19, #0x4c60]
   1df7c:      	str	x3, [x19, #0x4c68]
   1df80:      	ldur	x1, [sp, #0x98]
   1df84:      	str	x1, [x19, #0x4c70]
   1df88:      	str	x22, [x19, #0x4f70]
   1df8c:      	str	x23, [x19, #0x4f78]
   1df90:      	ldur	x1, [sp, #0x18]
   1df94:      	str	x1, [x19, #0x50c0]
   1df98:      	mov	x15, x26
   1df9c:      	str	x15, [x19, #0x50c8]
   1dfa0:      	str	x22, [x19, #0x50d0]
   1dfa4:      	ldur	x26, [sp, #0xe0]
   1dfa8:      	str	x26, [x19, #0x50d8]
   1dfac:      	ldur	x1, [sp, #0x10]
   1dfb0:      	str	x1, [x19, #0x50e0]
   1dfb4:      	str	x27, [x19, #0x50e8]
   1dfb8:      	str	x24, [x19, #0x50f0]
   1dfbc:      	str	x4, [x19, #0x50f8]
   1dfc0:      	ldur	x26, [sp, #0x80]
   1dfc4:      	str	x26, [x19, #0x5100]
   1dfc8:      	ldur	x14, [sp, #0x60]
   1dfcc:      	str	x14, [x19, #0x5a20]
   1dfd0:      	add	x14, x11, #0x1
   1dfd4:      	str	x14, [x19, #0x5bb0]
   1dfd8:      	ldur	x26, [sp, #0xa0]
   1dfdc:      	str	x26, [x19, #0x5bb8]
   1dfe0:      	ldur	x7, [sp, #0xa8]
   1dfe4:      	str	x7, [x19, #0x5bc0]
   1dfe8:      	ldur	x4, [sp, #0x90]
   1dfec:      	sub	x1, x4, x3
   1dff0:      	mov	w2, #0xc87e             ; =51326
   1dff4:      	movk	w2, #0x1, lsl #16
   1dff8:      	msub	x1, x14, x2, x1
   1dffc:      	str	x1, [x19, #0x5bc8]
   1e000:      	str	x0, [x19, #0x5bd0]
   1e004:      	ldur	x20, [sp, #0x20]
   1e008:      	str	x20, [x19, #0x5bd8]
   1e00c:      	ldur	x8, [sp, #0xb0]
   1e010:      	str	x8, [x19, #0x5be8]
   1e014:      	ldur	x4, [sp, #0xb8]
   1e018:      	str	x4, [x19, #0x5bf0]
   1e01c:      	str	x12, [x19, #0x5c00]
   1e020:      	str	x9, [x19, #0x5c08]
   1e024:      	str	x13, [x19, #0x5c18]
   1e028:      	ldur	x13, [sp, #0xc0]
   1e02c:      	str	x13, [x19, #0x5c20]
   1e030:      	ldr	x0, [x19, #0x4c60]
   1e034:      	cmp	x0, #0x0
   1e038:      	b.eq	0x1e270 <_mech_canonical_program_entry_v1_numeric_1282+0x10f0>
   1e03c:      	ldr	x3, [x19, #0x4c68]
   1e040:      	ldr	x4, [x19, #0x4c70]
   1e044:      	mov	x0, #0x0                ; =0
   1e048:      	str	x0, [x19, #0x4c60]
   1e04c:      	mov	x0, #0x3                ; =3
   1e050:      	ldr	x15, [sp, #0x190]
   1e054:      	mov	x21, x0
   1e058:      	cmp	x15, #0x19a
   1e05c:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1e060:      	ldr	x0, [x19, #0x4f70]
   1e064:      	ldr	x8, [sp, #0x198]
   1e068:      	str	x0, [x8, #0x10]
   1e06c:      	ldr	x1, [x19, #0x4f78]
   1e070:      	ldr	x11, [sp, #0x198]
   1e074:      	str	x1, [x11, #0x18]
   1e078:      	ldr	x2, [x19, #0x5a20]
   1e07c:      	ldr	x14, [sp, #0x198]
   1e080:      	str	x2, [x14, #0xac0]
   1e084:      	ldr	x2, [sp, #0x198]
   1e088:      	str	x0, [x2, #0x10]
   1e08c:      	ldr	x0, [sp, #0x198]
   1e090:      	str	x1, [x0, #0x18]
   1e094:      	ldr	x0, [x19, #0x50c0]
   1e098:      	ldr	x1, [sp, #0x198]
   1e09c:      	str	x0, [x1, #0x160]
   1e0a0:      	ldr	x0, [x19, #0x50c8]
   1e0a4:      	str	x0, [x1, #0x168]
   1e0a8:      	ldr	x0, [x19, #0x50d0]
   1e0ac:      	str	x0, [x1, #0x170]
   1e0b0:      	ldr	x0, [x19, #0x50d8]
   1e0b4:      	str	x0, [x1, #0x178]
   1e0b8:      	ldr	x0, [x19, #0x50e0]
   1e0bc:      	str	x0, [x1, #0x180]
   1e0c0:      	ldr	x0, [x19, #0x50e8]
   1e0c4:      	str	x0, [x1, #0x188]
   1e0c8:      	ldr	x0, [x19, #0x50f0]
   1e0cc:      	str	x0, [x1, #0x190]
   1e0d0:      	ldr	x0, [x19, #0x50f8]
   1e0d4:      	str	x0, [x1, #0x198]
   1e0d8:      	ldr	x0, [x19, #0x5100]
   1e0dc:      	str	x0, [x1, #0x1a0]
   1e0e0:      	ldr	x0, [x19, #0x52a8]
   1e0e4:      	str	x0, [x1, #0x348]
   1e0e8:      	ldr	x0, [x19, #0x52b0]
   1e0ec:      	str	x0, [x1, #0x350]
   1e0f0:      	ldr	x0, [x19, #0x52b8]
   1e0f4:      	str	x0, [x1, #0x358]
   1e0f8:      	ldr	x0, [x19, #0x52c0]
   1e0fc:      	str	x0, [x1, #0x360]
   1e100:      	ldr	x0, [x19, #0x52c8]
   1e104:      	str	x0, [x1, #0x368]
   1e108:      	ldr	x0, [x19, #0x52d0]
   1e10c:      	str	x0, [x1, #0x370]
   1e110:      	ldr	x0, [x19, #0x52d8]
   1e114:      	ldr	x5, [sp, #0x198]
   1e118:      	str	x0, [x5, #0x378]
   1e11c:      	ldr	x0, [x19, #0x52e0]
   1e120:      	ldr	x6, [sp, #0x198]
   1e124:      	str	x0, [x6, #0x380]
   1e128:      	ldr	x0, [x19, #0x52e8]
   1e12c:      	ldr	x9, [sp, #0x198]
   1e130:      	str	x0, [x9, #0x388]
   1e134:      	ldr	x0, [x19, #0x55d8]
   1e138:      	ldr	x12, [sp, #0x198]
   1e13c:      	str	x0, [x12, #0x678]
   1e140:      	ldr	x0, [x19, #0x55e0]
   1e144:      	ldr	x15, [sp, #0x198]
   1e148:      	str	x0, [x15, #0x680]
   1e14c:      	ldr	x0, [x19, #0x55e8]
   1e150:      	str	x0, [x1, #0x688]
   1e154:      	ldr	x0, [x19, #0x55f0]
   1e158:      	str	x0, [x1, #0x690]
   1e15c:      	ldr	x0, [x19, #0x55f8]
   1e160:      	str	x0, [x1, #0x698]
   1e164:      	ldr	x0, [x19, #0x5600]
   1e168:      	str	x0, [x1, #0x6a0]
   1e16c:      	ldr	x0, [x19, #0x5608]
   1e170:      	str	x0, [x1, #0x6a8]
   1e174:      	ldr	x0, [x19, #0x5610]
   1e178:      	str	x0, [x1, #0x6b0]
   1e17c:      	ldr	x1, [x19, #0x57a0]
   1e180:      	ldr	x0, [sp, #0x198]
   1e184:      	str	x1, [x0, #0x840]
   1e188:      	ldr	x2, [x19, #0x57a8]
   1e18c:      	str	x2, [x0, #0x848]
   1e190:      	ldr	x5, [x19, #0x57b0]
   1e194:      	str	x5, [x0, #0x850]
   1e198:      	ldr	x5, [x19, #0x57b8]
   1e19c:      	str	x5, [x0, #0x858]
   1e1a0:      	ldr	x5, [x19, #0x57c0]
   1e1a4:      	str	x5, [x0, #0x860]
   1e1a8:      	ldr	x6, [x19, #0x57c8]
   1e1ac:      	str	x6, [x0, #0x868]
   1e1b0:      	ldr	x7, [x19, #0x57d0]
   1e1b4:      	str	x7, [x0, #0x870]
   1e1b8:      	ldr	x8, [x19, #0x57d8]
   1e1bc:      	str	x8, [x0, #0x878]
   1e1c0:      	ldr	x9, [x19, #0x5bb0]
   1e1c4:      	str	x9, [x0, #0xc50]
   1e1c8:      	ldr	x10, [x19, #0x5bb8]
   1e1cc:      	str	x10, [x0, #0xc58]
   1e1d0:      	ldr	x11, [x19, #0x5bc0]
   1e1d4:      	ldr	x5, [sp, #0x198]
   1e1d8:      	str	x11, [x5, #0xc60]
   1e1dc:      	ldr	x12, [x19, #0x5bc8]
   1e1e0:      	ldr	x6, [sp, #0x198]
   1e1e4:      	str	x12, [x6, #0xc68]
   1e1e8:      	ldr	x13, [x19, #0x5bd0]
   1e1ec:      	ldr	x9, [sp, #0x198]
   1e1f0:      	str	x13, [x9, #0xc70]
   1e1f4:      	ldr	x14, [x19, #0x5bd8]
   1e1f8:      	ldr	x12, [sp, #0x198]
   1e1fc:      	str	x14, [x12, #0xc78]
   1e200:      	mov	x15, #0x0               ; =0
   1e204:      	str	x15, [x0, #0xc80]
   1e208:      	ldr	x0, [x19, #0x5be8]
   1e20c:      	ldr	x1, [sp, #0x198]
   1e210:      	str	x0, [x1, #0xc88]
   1e214:      	ldr	x0, [x19, #0x5bf0]
   1e218:      	str	x0, [x1, #0xc90]
   1e21c:      	ldr	x0, [sp, #0x198]
   1e220:      	str	x15, [x0, #0xc98]
   1e224:      	ldr	x0, [x19, #0x5c00]
   1e228:      	str	x0, [x1, #0xca0]
   1e22c:      	ldr	x0, [x19, #0x5c08]
   1e230:      	str	x0, [x1, #0xca8]
   1e234:      	ldr	x0, [sp, #0x198]
   1e238:      	str	x15, [x0, #0xcb0]
   1e23c:      	ldr	x0, [x19, #0x5c18]
   1e240:      	str	x0, [x1, #0xcb8]
   1e244:      	ldr	x0, [x19, #0x5c20]
   1e248:      	str	x0, [x1, #0xcc0]
   1e24c:      	mov	x1, #0x51f              ; =1311
   1e250:      	mov	x2, #-0x9               ; =-9
   1e254:      	mov	x5, #0x1                ; =1
   1e258:      	ldur	x0, [sp, #0x8]
   1e25c:      	ldr	x6, [sp, #0x1a0]
   1e260:      	ldr	x21, [sp, #0x1a8]
   1e264:      	blr	x21
   1e268:      	cmp	x0, #0x0
   1e26c:      	b.ne	0x21f84 <_mech_canonical_program_entry_v1_numeric_1282+0x4e04>
   1e270:      	mov	x0, #0x0                ; =0
   1e274:      	ldur	x1, [sp, #0xd8]
   1e278:      	add	sp, sp, #0x1c0
   1e27c:      	ldp	x19, x20, [sp], #0x10
   1e280:      	ldp	x21, x22, [sp], #0x10
   1e284:      	ldp	x23, x24, [sp], #0x10
   1e288:      	ldp	x25, x26, [sp], #0x10
   1e28c:      	ldp	x27, x28, [sp], #0x10
   1e290:      	ldp	x29, x30, [sp], #0x10
   1e294:      	retab
   1e298:      	ldur	x1, [sp, #0x18]
   1e29c:      	stur	x4, [sp, #0x78]
   1e2a0:      	mov	x15, x26
   1e2a4:      	cmp	x1, x15
   1e2a8:      	cset	x15, lo
   1e2ac:      	stur	x15, [sp, #0xd8]
   1e2b0:      	mov	x15, x26
   1e2b4:      	cmp	x1, x15
   1e2b8:      	b.lo	0x1e2ec <_mech_canonical_program_entry_v1_numeric_1282+0x116c>
   1e2bc:      	mov	w0, #0x2166             ; =8550
   1e2c0:      	movk	w0, #0x1, lsl #16
   1e2c4:      	sub	x3, x3, x0
   1e2c8:      	stur	x24, [sp, #0x70]
   1e2cc:      	stur	x27, [sp, #0x68]
   1e2d0:      	stur	x1, [sp, #0x18]
   1e2d4:      	mov	x15, x27
   1e2d8:      	mov	x4, x1
   1e2dc:      	ldur	x2, [sp, #0x10]
   1e2e0:      	ldur	x1, [sp, #0x78]
   1e2e4:      	ldur	x0, [sp, #0x80]
   1e2e8:      	b	0x1f6cc <_mech_canonical_program_entry_v1_numeric_1282+0x254c>
   1e2ec:      	ldr	x0, [sp, #0x160]
   1e2f0:      	cmp	x1, x0
   1e2f4:      	b.lo	0x1e58c <_mech_canonical_program_entry_v1_numeric_1282+0x140c>
   1e2f8:      	b	0x21f8c <_mech_canonical_program_entry_v1_numeric_1282+0x4e0c>
   1e2fc:      	ldr	x3, [x19, #0x4c68]
   1e300:      	ldr	x4, [x19, #0x4c70]
   1e304:      	mov	x0, #0x0                ; =0
   1e308:      	str	x0, [x19, #0x4c60]
   1e30c:      	mov	x0, #0x3                ; =3
   1e310:      	ldr	x15, [sp, #0x190]
   1e314:      	mov	x21, x0
   1e318:      	cmp	x15, #0x19a
   1e31c:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1e320:      	ldr	x0, [x19, #0x4f70]
   1e324:      	ldr	x1, [sp, #0x198]
   1e328:      	str	x0, [x1, #0x10]
   1e32c:      	ldr	x1, [x19, #0x4f78]
   1e330:      	ldr	x2, [sp, #0x198]
   1e334:      	str	x1, [x2, #0x18]
   1e338:      	ldr	x2, [x19, #0x5a20]
   1e33c:      	ldr	x5, [sp, #0x198]
   1e340:      	str	x2, [x5, #0xac0]
   1e344:      	ldr	x2, [sp, #0x198]
   1e348:      	str	x0, [x2, #0x10]
   1e34c:      	ldr	x0, [sp, #0x198]
   1e350:      	str	x1, [x0, #0x18]
   1e354:      	ldr	x0, [x19, #0x50c0]
   1e358:      	ldr	x1, [sp, #0x198]
   1e35c:      	str	x0, [x1, #0x160]
   1e360:      	ldr	x0, [x19, #0x50c8]
   1e364:      	str	x0, [x1, #0x168]
   1e368:      	ldr	x0, [x19, #0x50d0]
   1e36c:      	str	x0, [x1, #0x170]
   1e370:      	ldr	x0, [x19, #0x50d8]
   1e374:      	str	x0, [x1, #0x178]
   1e378:      	ldr	x0, [x19, #0x50e0]
   1e37c:      	str	x0, [x1, #0x180]
   1e380:      	ldr	x0, [x19, #0x50e8]
   1e384:      	str	x0, [x5, #0x188]
   1e388:      	ldr	x0, [x19, #0x50f0]
   1e38c:      	ldr	x6, [sp, #0x198]
   1e390:      	str	x0, [x6, #0x190]
   1e394:      	ldr	x0, [x19, #0x50f8]
   1e398:      	ldr	x9, [sp, #0x198]
   1e39c:      	str	x0, [x9, #0x198]
   1e3a0:      	ldr	x0, [x19, #0x5100]
   1e3a4:      	ldr	x12, [sp, #0x198]
   1e3a8:      	str	x0, [x12, #0x1a0]
   1e3ac:      	ldr	x0, [x19, #0x52a8]
   1e3b0:      	ldr	x15, [sp, #0x198]
   1e3b4:      	str	x0, [x15, #0x348]
   1e3b8:      	ldr	x0, [x19, #0x52b0]
   1e3bc:      	str	x0, [x1, #0x350]
   1e3c0:      	ldr	x0, [x19, #0x52b8]
   1e3c4:      	str	x0, [x1, #0x358]
   1e3c8:      	ldr	x0, [x19, #0x52c0]
   1e3cc:      	str	x0, [x1, #0x360]
   1e3d0:      	ldr	x1, [x19, #0x52c8]
   1e3d4:      	ldr	x0, [sp, #0x198]
   1e3d8:      	str	x1, [x0, #0x368]
   1e3dc:      	ldr	x2, [x19, #0x52d0]
   1e3e0:      	str	x2, [x0, #0x370]
   1e3e4:      	ldr	x5, [x19, #0x52d8]
   1e3e8:      	str	x5, [x0, #0x378]
   1e3ec:      	ldr	x5, [x19, #0x52e0]
   1e3f0:      	str	x5, [x0, #0x380]
   1e3f4:      	ldr	x5, [x19, #0x52e8]
   1e3f8:      	str	x5, [x0, #0x388]
   1e3fc:      	ldr	x6, [x19, #0x55d8]
   1e400:      	str	x6, [x0, #0x678]
   1e404:      	ldr	x7, [x19, #0x55e0]
   1e408:      	str	x7, [x0, #0x680]
   1e40c:      	ldr	x8, [x19, #0x55e8]
   1e410:      	str	x8, [x0, #0x688]
   1e414:      	ldr	x9, [x19, #0x55f0]
   1e418:      	str	x9, [x0, #0x690]
   1e41c:      	ldr	x10, [x19, #0x55f8]
   1e420:      	str	x10, [x0, #0x698]
   1e424:      	ldr	x11, [x19, #0x5600]
   1e428:      	str	x11, [x0, #0x6a0]
   1e42c:      	ldr	x12, [x19, #0x5608]
   1e430:      	str	x12, [x0, #0x6a8]
   1e434:      	ldr	x13, [x19, #0x5610]
   1e438:      	str	x13, [x0, #0x6b0]
   1e43c:      	ldr	x14, [x19, #0x57a0]
   1e440:      	ldr	x5, [sp, #0x198]
   1e444:      	str	x14, [x5, #0x840]
   1e448:      	ldr	x15, [x19, #0x57a8]
   1e44c:      	ldr	x6, [sp, #0x198]
   1e450:      	str	x15, [x6, #0x848]
   1e454:      	ldr	x0, [x19, #0x57b0]
   1e458:      	ldr	x9, [sp, #0x198]
   1e45c:      	str	x0, [x9, #0x850]
   1e460:      	ldr	x0, [x19, #0x57b8]
   1e464:      	ldr	x12, [sp, #0x198]
   1e468:      	str	x0, [x12, #0x858]
   1e46c:      	ldr	x0, [x19, #0x57c0]
   1e470:      	ldr	x15, [sp, #0x198]
   1e474:      	str	x0, [x15, #0x860]
   1e478:      	ldr	x0, [x19, #0x57c8]
   1e47c:      	ldr	x1, [sp, #0x198]
   1e480:      	str	x0, [x1, #0x868]
   1e484:      	ldr	x0, [x19, #0x57d0]
   1e488:      	str	x0, [x1, #0x870]
   1e48c:      	ldr	x0, [x19, #0x57d8]
   1e490:      	str	x0, [x1, #0x878]
   1e494:      	ldr	x0, [x19, #0x5bb0]
   1e498:      	str	x0, [x1, #0xc50]
   1e49c:      	ldr	x0, [x19, #0x5bb8]
   1e4a0:      	str	x0, [x1, #0xc58]
   1e4a4:      	ldr	x0, [x19, #0x5bc0]
   1e4a8:      	str	x0, [x1, #0xc60]
   1e4ac:      	ldr	x0, [x19, #0x5bc8]
   1e4b0:      	str	x0, [x1, #0xc68]
   1e4b4:      	ldr	x0, [x19, #0x5bd0]
   1e4b8:      	str	x0, [x1, #0xc70]
   1e4bc:      	ldr	x0, [x19, #0x5bd8]
   1e4c0:      	str	x0, [x1, #0xc78]
   1e4c4:      	mov	x0, #0x0                ; =0
   1e4c8:      	str	x0, [x1, #0xc80]
   1e4cc:      	ldr	x1, [x19, #0x5be8]
   1e4d0:      	ldr	x2, [sp, #0x198]
   1e4d4:      	str	x1, [x2, #0xc88]
   1e4d8:      	ldr	x1, [x19, #0x5bf0]
   1e4dc:      	str	x1, [x2, #0xc90]
   1e4e0:      	ldr	x1, [sp, #0x198]
   1e4e4:      	str	x0, [x1, #0xc98]
   1e4e8:      	ldr	x1, [x19, #0x5c00]
   1e4ec:      	str	x1, [x2, #0xca0]
   1e4f0:      	ldr	x1, [x19, #0x5c08]
   1e4f4:      	str	x1, [x2, #0xca8]
   1e4f8:      	ldr	x1, [sp, #0x198]
   1e4fc:      	str	x0, [x1, #0xcb0]
   1e500:      	ldr	x0, [x19, #0x5c18]
   1e504:      	str	x0, [x1, #0xcb8]
   1e508:      	ldr	x0, [x19, #0x5c20]
   1e50c:      	str	x0, [x5, #0xcc0]
   1e510:      	mov	x1, #0x530              ; =1328
   1e514:      	mov	x2, #-0x9               ; =-9
   1e518:      	ldr	x21, [sp, #0x1a8]
   1e51c:      	ldur	x0, [sp, #0x8]
   1e520:      	mov	x5, x20
   1e524:      	ldr	x6, [sp, #0x1a0]
   1e528:      	blr	x21
   1e52c:      	cmp	x0, #0x0
   1e530:      	b.ne	0x2211c <_mech_canonical_program_entry_v1_numeric_1282+0x4f9c>
   1e534:      	mov	x0, #0x3                ; =3
   1e538:      	ldr	x15, [sp, #0x190]
   1e53c:      	mov	x21, x0
   1e540:      	cmp	x15, #0x2
   1e544:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1e548:      	mov	x5, #0x0                ; =0
   1e54c:      	ldr	x3, [sp, #0x198]
   1e550:      	str	x5, [x3]
   1e554:      	ldr	x0, [x19, #0x1890]
   1e558:      	str	x0, [x3, #0x8]
   1e55c:      	mov	x1, #0x530              ; =1328
   1e560:      	ldur	x0, [sp, #0x8]
   1e564:      	ldr	x6, [sp, #0x1a0]
   1e568:      	ldr	x21, [sp, #0x1a8]
   1e56c:      	mov	x4, x20
   1e570:      	mov	x2, x5
   1e574:      	blr	x21
   1e578:      	cmp	x0, #0x0
   1e57c:      	b.ne	0x22124 <_mech_canonical_program_entry_v1_numeric_1282+0x4fa4>
   1e580:      	mov	x0, #0x3                ; =3
   1e584:      	mov	x21, x0
   1e588:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1e58c:      	ldr	x0, [sp, #0x168]
   1e590:      	stur	x24, [sp, #0x70]
   1e594:      	ldr	x2, [x0, x1, lsl #3]
   1e598:      	add	x4, x2, #0x1
   1e59c:      	cmp	x4, x2
   1e5a0:      	b.lo	0x2212c <_mech_canonical_program_entry_v1_numeric_1282+0x4fac>
   1e5a4:      	ldr	x0, [sp, #0x150]
   1e5a8:      	cmp	x2, x0
   1e5ac:      	b.lo	0x1e83c <_mech_canonical_program_entry_v1_numeric_1282+0x16bc>
   1e5b0:      	b	0x22278 <_mech_canonical_program_entry_v1_numeric_1282+0x50f8>
   1e5b4:      	ldr	x3, [x19, #0x4c68]
   1e5b8:      	ldr	x4, [x19, #0x4c70]
   1e5bc:      	mov	x0, #0x0                ; =0
   1e5c0:      	str	x0, [x19, #0x4c60]
   1e5c4:      	mov	x0, #0x3                ; =3
   1e5c8:      	ldr	x15, [sp, #0x190]
   1e5cc:      	mov	x21, x0
   1e5d0:      	cmp	x15, #0x19a
   1e5d4:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1e5d8:      	ldr	x0, [x19, #0x4f70]
   1e5dc:      	ldr	x6, [sp, #0x198]
   1e5e0:      	str	x0, [x6, #0x10]
   1e5e4:      	ldr	x1, [x19, #0x4f78]
   1e5e8:      	ldr	x9, [sp, #0x198]
   1e5ec:      	str	x1, [x9, #0x18]
   1e5f0:      	ldr	x2, [x19, #0x5a20]
   1e5f4:      	ldr	x12, [sp, #0x198]
   1e5f8:      	str	x2, [x12, #0xac0]
   1e5fc:      	ldr	x14, [sp, #0x198]
   1e600:      	str	x0, [x14, #0x10]
   1e604:      	ldr	x0, [sp, #0x198]
   1e608:      	str	x1, [x0, #0x18]
   1e60c:      	ldr	x0, [x19, #0x50c0]
   1e610:      	ldr	x1, [sp, #0x198]
   1e614:      	str	x0, [x1, #0x160]
   1e618:      	ldr	x0, [x19, #0x50c8]
   1e61c:      	str	x0, [x1, #0x168]
   1e620:      	ldr	x0, [x19, #0x50d0]
   1e624:      	str	x0, [x1, #0x170]
   1e628:      	ldr	x0, [x19, #0x50d8]
   1e62c:      	str	x0, [x1, #0x178]
   1e630:      	ldr	x0, [x19, #0x50e0]
   1e634:      	str	x0, [x1, #0x180]
   1e638:      	ldr	x0, [x19, #0x50e8]
   1e63c:      	str	x0, [x1, #0x188]
   1e640:      	ldr	x0, [x19, #0x50f0]
   1e644:      	str	x0, [x1, #0x190]
   1e648:      	ldr	x0, [x19, #0x50f8]
   1e64c:      	str	x0, [x1, #0x198]
   1e650:      	ldr	x0, [x19, #0x5100]
   1e654:      	str	x0, [x1, #0x1a0]
   1e658:      	ldr	x0, [x19, #0x52a8]
   1e65c:      	str	x0, [x1, #0x348]
   1e660:      	ldr	x0, [x19, #0x52b0]
   1e664:      	str	x0, [x1, #0x350]
   1e668:      	ldr	x0, [x19, #0x52b8]
   1e66c:      	str	x0, [x1, #0x358]
   1e670:      	ldr	x0, [x19, #0x52c0]
   1e674:      	str	x0, [x1, #0x360]
   1e678:      	ldr	x0, [x19, #0x52c8]
   1e67c:      	str	x0, [x1, #0x368]
   1e680:      	ldr	x0, [x19, #0x52d0]
   1e684:      	str	x0, [x1, #0x370]
   1e688:      	ldr	x0, [x19, #0x52d8]
   1e68c:      	str	x0, [x1, #0x378]
   1e690:      	ldr	x0, [x19, #0x52e0]
   1e694:      	ldr	x5, [sp, #0x198]
   1e698:      	str	x0, [x5, #0x380]
   1e69c:      	ldr	x0, [x19, #0x52e8]
   1e6a0:      	ldr	x7, [sp, #0x198]
   1e6a4:      	str	x0, [x7, #0x388]
   1e6a8:      	ldr	x0, [x19, #0x55d8]
   1e6ac:      	ldr	x10, [sp, #0x198]
   1e6b0:      	str	x0, [x10, #0x678]
   1e6b4:      	ldr	x0, [x19, #0x55e0]
   1e6b8:      	ldr	x13, [sp, #0x198]
   1e6bc:      	str	x0, [x13, #0x680]
   1e6c0:      	ldr	x0, [x19, #0x55e8]
   1e6c4:      	str	x0, [x1, #0x688]
   1e6c8:      	ldr	x0, [x19, #0x55f0]
   1e6cc:      	str	x0, [x1, #0x690]
   1e6d0:      	ldr	x0, [x19, #0x55f8]
   1e6d4:      	str	x0, [x1, #0x698]
   1e6d8:      	ldr	x0, [x19, #0x5600]
   1e6dc:      	str	x0, [x1, #0x6a0]
   1e6e0:      	ldr	x0, [x19, #0x5608]
   1e6e4:      	str	x0, [x1, #0x6a8]
   1e6e8:      	ldr	x0, [x19, #0x5610]
   1e6ec:      	str	x0, [x1, #0x6b0]
   1e6f0:      	ldr	x0, [x19, #0x57a0]
   1e6f4:      	str	x0, [x1, #0x840]
   1e6f8:      	ldr	x1, [x19, #0x57a8]
   1e6fc:      	ldr	x0, [sp, #0x198]
   1e700:      	str	x1, [x0, #0x848]
   1e704:      	ldr	x2, [x19, #0x57b0]
   1e708:      	str	x2, [x0, #0x850]
   1e70c:      	ldr	x5, [x19, #0x57b8]
   1e710:      	str	x5, [x0, #0x858]
   1e714:      	ldr	x5, [x19, #0x57c0]
   1e718:      	str	x5, [x0, #0x860]
   1e71c:      	ldr	x5, [x19, #0x57c8]
   1e720:      	str	x5, [x0, #0x868]
   1e724:      	ldr	x6, [x19, #0x57d0]
   1e728:      	str	x6, [x0, #0x870]
   1e72c:      	ldr	x7, [x19, #0x57d8]
   1e730:      	str	x7, [x0, #0x878]
   1e734:      	ldr	x8, [x19, #0x5bb0]
   1e738:      	str	x8, [x0, #0xc50]
   1e73c:      	ldr	x9, [x19, #0x5bb8]
   1e740:      	str	x9, [x0, #0xc58]
   1e744:      	ldr	x10, [x19, #0x5bc0]
   1e748:      	ldr	x1, [sp, #0x198]
   1e74c:      	str	x10, [x1, #0xc60]
   1e750:      	ldr	x11, [x19, #0x5bc8]
   1e754:      	ldr	x5, [sp, #0x198]
   1e758:      	str	x11, [x5, #0xc68]
   1e75c:      	ldr	x12, [x19, #0x5bd0]
   1e760:      	ldr	x7, [sp, #0x198]
   1e764:      	str	x12, [x7, #0xc70]
   1e768:      	ldr	x13, [x19, #0x5bd8]
   1e76c:      	ldr	x10, [sp, #0x198]
   1e770:      	str	x13, [x10, #0xc78]
   1e774:      	mov	x14, #0x0               ; =0
   1e778:      	ldr	x13, [sp, #0x198]
   1e77c:      	str	x14, [x13, #0xc80]
   1e780:      	ldr	x15, [x19, #0x5be8]
   1e784:      	str	x15, [x0, #0xc88]
   1e788:      	ldr	x0, [x19, #0x5bf0]
   1e78c:      	str	x0, [x1, #0xc90]
   1e790:      	ldr	x0, [sp, #0x198]
   1e794:      	str	x14, [x0, #0xc98]
   1e798:      	ldr	x0, [x19, #0x5c00]
   1e79c:      	str	x0, [x1, #0xca0]
   1e7a0:      	ldr	x0, [x19, #0x5c08]
   1e7a4:      	str	x0, [x1, #0xca8]
   1e7a8:      	ldr	x0, [sp, #0x198]
   1e7ac:      	str	x14, [x0, #0xcb0]
   1e7b0:      	ldr	x0, [x19, #0x5c18]
   1e7b4:      	str	x0, [x1, #0xcb8]
   1e7b8:      	ldr	x0, [x19, #0x5c20]
   1e7bc:      	str	x0, [x1, #0xcc0]
   1e7c0:      	mov	x1, #0x532              ; =1330
   1e7c4:      	mov	x2, #-0x9               ; =-9
   1e7c8:      	ldr	x21, [sp, #0x1a8]
   1e7cc:      	ldur	x0, [sp, #0x8]
   1e7d0:      	mov	x5, x20
   1e7d4:      	ldr	x6, [sp, #0x1a0]
   1e7d8:      	blr	x21
   1e7dc:      	cmp	x0, #0x0
   1e7e0:      	b.ne	0x2240c <_mech_canonical_program_entry_v1_numeric_1282+0x528c>
   1e7e4:      	mov	x0, #0x3                ; =3
   1e7e8:      	ldr	x15, [sp, #0x190]
   1e7ec:      	mov	x21, x0
   1e7f0:      	cmp	x15, #0x2
   1e7f4:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1e7f8:      	mov	x5, #0x0                ; =0
   1e7fc:      	ldr	x3, [sp, #0x198]
   1e800:      	str	x5, [x3]
   1e804:      	ldr	x0, [x19, #0x18a0]
   1e808:      	str	x0, [x3, #0x8]
   1e80c:      	mov	x1, #0x532              ; =1330
   1e810:      	ldur	x0, [sp, #0x8]
   1e814:      	ldr	x6, [sp, #0x1a0]
   1e818:      	ldr	x21, [sp, #0x1a8]
   1e81c:      	mov	x4, x20
   1e820:      	mov	x2, x5
   1e824:      	blr	x21
   1e828:      	cmp	x0, #0x0
   1e82c:      	b.ne	0x22414 <_mech_canonical_program_entry_v1_numeric_1282+0x5294>
   1e830:      	mov	x0, #0x3                ; =3
   1e834:      	mov	x21, x0
   1e838:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1e83c:      	ldr	x0, [sp, #0x158]
   1e840:      	stur	x1, [sp, #0x18]
   1e844:      	stur	x27, [sp, #0x68]
   1e848:      	ldr	x27, [x0, x2, lsl #3]
   1e84c:      	ldr	x5, [sp, #0x150]
   1e850:      	cmp	x4, x5
   1e854:      	b.lo	0x1eae0 <_mech_canonical_program_entry_v1_numeric_1282+0x1960>
   1e858:      	b	0x2241c <_mech_canonical_program_entry_v1_numeric_1282+0x529c>
   1e85c:      	ldr	x3, [x19, #0x4c68]
   1e860:      	ldr	x4, [x19, #0x4c70]
   1e864:      	mov	x0, #0x0                ; =0
   1e868:      	str	x0, [x19, #0x4c60]
   1e86c:      	mov	x0, #0x3                ; =3
   1e870:      	ldr	x15, [sp, #0x190]
   1e874:      	mov	x21, x0
   1e878:      	cmp	x15, #0x19a
   1e87c:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1e880:      	ldr	x0, [x19, #0x4f70]
   1e884:      	ldr	x1, [sp, #0x198]
   1e888:      	str	x0, [x1, #0x10]
   1e88c:      	ldr	x1, [x19, #0x4f78]
   1e890:      	ldr	x2, [sp, #0x198]
   1e894:      	str	x1, [x2, #0x18]
   1e898:      	ldr	x2, [x19, #0x5a20]
   1e89c:      	ldr	x5, [sp, #0x198]
   1e8a0:      	str	x2, [x5, #0xac0]
   1e8a4:      	ldr	x2, [sp, #0x198]
   1e8a8:      	str	x0, [x2, #0x10]
   1e8ac:      	ldr	x0, [sp, #0x198]
   1e8b0:      	str	x1, [x0, #0x18]
   1e8b4:      	ldr	x0, [x19, #0x50c0]
   1e8b8:      	ldr	x1, [sp, #0x198]
   1e8bc:      	str	x0, [x1, #0x160]
   1e8c0:      	ldr	x0, [x19, #0x50c8]
   1e8c4:      	str	x0, [x1, #0x168]
   1e8c8:      	ldr	x0, [x19, #0x50d0]
   1e8cc:      	str	x0, [x1, #0x170]
   1e8d0:      	ldr	x0, [x19, #0x50d8]
   1e8d4:      	str	x0, [x1, #0x178]
   1e8d8:      	ldr	x0, [x19, #0x50e0]
   1e8dc:      	str	x0, [x1, #0x180]
   1e8e0:      	ldr	x0, [x19, #0x50e8]
   1e8e4:      	str	x0, [x1, #0x188]
   1e8e8:      	ldr	x0, [x19, #0x50f0]
   1e8ec:      	str	x0, [x1, #0x190]
   1e8f0:      	ldr	x0, [x19, #0x50f8]
   1e8f4:      	str	x0, [x5, #0x198]
   1e8f8:      	ldr	x0, [x19, #0x5100]
   1e8fc:      	ldr	x7, [sp, #0x198]
   1e900:      	str	x0, [x7, #0x1a0]
   1e904:      	ldr	x0, [x19, #0x52a8]
   1e908:      	ldr	x10, [sp, #0x198]
   1e90c:      	str	x0, [x10, #0x348]
   1e910:      	ldr	x0, [x19, #0x52b0]
   1e914:      	ldr	x13, [sp, #0x198]
   1e918:      	str	x0, [x13, #0x350]
   1e91c:      	ldr	x0, [x19, #0x52b8]
   1e920:      	str	x0, [x1, #0x358]
   1e924:      	ldr	x0, [x19, #0x52c0]
   1e928:      	str	x0, [x1, #0x360]
   1e92c:      	ldr	x0, [x19, #0x52c8]
   1e930:      	str	x0, [x1, #0x368]
   1e934:      	ldr	x0, [x19, #0x52d0]
   1e938:      	str	x0, [x1, #0x370]
   1e93c:      	ldr	x0, [x19, #0x52d8]
   1e940:      	str	x0, [x1, #0x378]
   1e944:      	ldr	x0, [x19, #0x52e0]
   1e948:      	str	x0, [x1, #0x380]
   1e94c:      	ldr	x0, [x19, #0x52e8]
   1e950:      	str	x0, [x1, #0x388]
   1e954:      	ldr	x0, [x19, #0x55d8]
   1e958:      	str	x0, [x1, #0x678]
   1e95c:      	ldr	x0, [x19, #0x55e0]
   1e960:      	str	x0, [x1, #0x680]
   1e964:      	ldr	x0, [x19, #0x55e8]
   1e968:      	str	x0, [x1, #0x688]
   1e96c:      	ldr	x1, [x19, #0x55f0]
   1e970:      	ldr	x0, [sp, #0x198]
   1e974:      	str	x1, [x0, #0x690]
   1e978:      	ldr	x2, [x19, #0x55f8]
   1e97c:      	str	x2, [x0, #0x698]
   1e980:      	ldr	x5, [x19, #0x5600]
   1e984:      	str	x5, [x0, #0x6a0]
   1e988:      	ldr	x5, [x19, #0x5608]
   1e98c:      	str	x5, [x0, #0x6a8]
   1e990:      	ldr	x5, [x19, #0x5610]
   1e994:      	str	x5, [x0, #0x6b0]
   1e998:      	ldr	x6, [x19, #0x57a0]
   1e99c:      	str	x6, [x0, #0x840]
   1e9a0:      	ldr	x7, [x19, #0x57a8]
   1e9a4:      	ldr	x1, [sp, #0x198]
   1e9a8:      	str	x7, [x1, #0x848]
   1e9ac:      	ldr	x8, [x19, #0x57b0]
   1e9b0:      	ldr	x5, [sp, #0x198]
   1e9b4:      	str	x8, [x5, #0x850]
   1e9b8:      	ldr	x9, [x19, #0x57b8]
   1e9bc:      	ldr	x7, [sp, #0x198]
   1e9c0:      	str	x9, [x7, #0x858]
   1e9c4:      	ldr	x10, [x19, #0x57c0]
   1e9c8:      	ldr	x11, [sp, #0x198]
   1e9cc:      	str	x10, [x11, #0x860]
   1e9d0:      	ldr	x11, [x19, #0x57c8]
   1e9d4:      	str	x11, [x13, #0x868]
   1e9d8:      	ldr	x12, [x19, #0x57d0]
   1e9dc:      	str	x12, [x0, #0x870]
   1e9e0:      	ldr	x13, [x19, #0x57d8]
   1e9e4:      	str	x13, [x0, #0x878]
   1e9e8:      	ldr	x14, [x19, #0x5bb0]
   1e9ec:      	str	x14, [x0, #0xc50]
   1e9f0:      	ldr	x15, [x19, #0x5bb8]
   1e9f4:      	str	x15, [x0, #0xc58]
   1e9f8:      	ldr	x0, [x19, #0x5bc0]
   1e9fc:      	str	x0, [x1, #0xc60]
   1ea00:      	ldr	x0, [x19, #0x5bc8]
   1ea04:      	str	x0, [x1, #0xc68]
   1ea08:      	ldr	x0, [x19, #0x5bd0]
   1ea0c:      	str	x0, [x1, #0xc70]
   1ea10:      	ldr	x0, [x19, #0x5bd8]
   1ea14:      	str	x0, [x1, #0xc78]
   1ea18:      	mov	x0, #0x0                ; =0
   1ea1c:      	str	x0, [x1, #0xc80]
   1ea20:      	ldr	x1, [x19, #0x5be8]
   1ea24:      	ldr	x2, [sp, #0x198]
   1ea28:      	str	x1, [x2, #0xc88]
   1ea2c:      	ldr	x1, [x19, #0x5bf0]
   1ea30:      	str	x1, [x2, #0xc90]
   1ea34:      	ldr	x1, [sp, #0x198]
   1ea38:      	str	x0, [x1, #0xc98]
   1ea3c:      	ldr	x1, [x19, #0x5c00]
   1ea40:      	str	x1, [x2, #0xca0]
   1ea44:      	ldr	x1, [x19, #0x5c08]
   1ea48:      	str	x1, [x2, #0xca8]
   1ea4c:      	ldr	x1, [sp, #0x198]
   1ea50:      	str	x0, [x1, #0xcb0]
   1ea54:      	ldr	x0, [x19, #0x5c18]
   1ea58:      	str	x0, [x1, #0xcb8]
   1ea5c:      	ldr	x0, [x19, #0x5c20]
   1ea60:      	str	x0, [x1, #0xcc0]
   1ea64:      	mov	x1, #0x534              ; =1332
   1ea68:      	mov	x2, #-0x9               ; =-9
   1ea6c:      	ldr	x21, [sp, #0x1a8]
   1ea70:      	ldur	x0, [sp, #0x8]
   1ea74:      	mov	x5, x20
   1ea78:      	ldr	x6, [sp, #0x1a0]
   1ea7c:      	blr	x21
   1ea80:      	cmp	x0, #0x0
   1ea84:      	b.ne	0x225c0 <_mech_canonical_program_entry_v1_numeric_1282+0x5440>
   1ea88:      	mov	x0, #0x3                ; =3
   1ea8c:      	ldr	x15, [sp, #0x190]
   1ea90:      	mov	x21, x0
   1ea94:      	cmp	x15, #0x2
   1ea98:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1ea9c:      	mov	x5, #0x0                ; =0
   1eaa0:      	ldr	x3, [sp, #0x198]
   1eaa4:      	str	x5, [x3]
   1eaa8:      	ldr	x0, [x19, #0x18b0]
   1eaac:      	str	x0, [x3, #0x8]
   1eab0:      	mov	x1, #0x534              ; =1332
   1eab4:      	ldur	x0, [sp, #0x8]
   1eab8:      	ldr	x6, [sp, #0x1a0]
   1eabc:      	ldr	x21, [sp, #0x1a8]
   1eac0:      	mov	x4, x20
   1eac4:      	mov	x2, x5
   1eac8:      	blr	x21
   1eacc:      	cmp	x0, #0x0
   1ead0:      	b.ne	0x225c8 <_mech_canonical_program_entry_v1_numeric_1282+0x5448>
   1ead4:      	mov	x0, #0x3                ; =3
   1ead8:      	mov	x21, x0
   1eadc:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1eae0:      	ldr	x0, [sp, #0x158]
   1eae4:      	ldr	x7, [x0, x4, lsl #3]
   1eae8:      	mov	w0, #0x2166             ; =8550
   1eaec:      	movk	w0, #0x1, lsl #16
   1eaf0:      	sub	x6, x3, x0
   1eaf4:      	mov	x3, #0x0                ; =0
   1eaf8:      	ldur	x10, [sp, #0x70]
   1eafc:      	ldur	x15, [sp, #0x10]
   1eb00:      	ldur	x0, [sp, #0x68]
   1eb04:      	stur	x0, [sp, #0x30]
   1eb08:      	ldur	x0, [sp, #0x78]
   1eb0c:      	stur	x0, [sp, #0x38]
   1eb10:      	ldur	x0, [sp, #0x80]
   1eb14:      	stur	x0, [sp, #0x40]
   1eb18:      	mov	w0, #0xdc1e             ; =56350
   1eb1c:      	movk	w0, #0x2, lsl #16
   1eb20:      	cmp	x6, x0
   1eb24:      	b.hs	0x1ef60 <_mech_canonical_program_entry_v1_numeric_1282+0x1de0>
   1eb28:      	mov	x1, #0x0                ; =0
   1eb2c:      	str	x1, [x19, #0x18]
   1eb30:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   1eb34:      	str	x0, [x19, #0x20]
   1eb38:      	mov	x0, #0x1                ; =1
   1eb3c:      	str	x0, [x19, #0x30]
   1eb40:      	mov	x2, #0x101010101010101  ; =72340172838076673
   1eb44:      	str	x2, [x19, #0x38]
   1eb48:      	mov	x20, #0x2               ; =2
   1eb4c:      	str	x20, [x19, #0x40]
   1eb50:      	mov	x2, #0x3                ; =3
   1eb54:      	str	x2, [x19, #0x48]
   1eb58:      	mov	x2, #0x4                ; =4
   1eb5c:      	str	x2, [x19, #0x50]
   1eb60:      	mov	x2, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   1eb64:      	str	x2, [x19, #0x78]
   1eb68:      	mov	x2, #0x3333333333333333 ; =3689348814741910323
   1eb6c:      	str	x2, [x19, #0x88]
   1eb70:      	mov	x2, #0x38               ; =56
   1eb74:      	str	x2, [x19, #0x90]
   1eb78:      	mov	x2, #0x3a               ; =58
   1eb7c:      	str	x2, [x19, #0x98]
   1eb80:      	mov	x2, #0x5555555555555555 ; =6148914691236517205
   1eb84:      	str	x2, [x19, #0xb0]
   1eb88:      	mov	x2, #0x3ffffffffffffff  ; =288230376151711743
   1eb8c:      	str	x2, [x19, #0xb8]
   1eb90:      	str	x1, [x19, #0x188]
   1eb94:      	str	x0, [x19, #0x190]
   1eb98:      	str	x22, [x19, #0x17a0]
   1eb9c:      	str	x23, [x19, #0x17a8]
   1eba0:      	ldur	x25, [sp, #0xf0]
   1eba4:      	uxtb	w8, w25
   1eba8:      	str	x8, [x19, #0x17b8]
   1ebac:      	ldur	x5, [sp, #0x18]
   1ebb0:      	str	x5, [x19, #0x1858]
   1ebb4:      	mov	x8, x26
   1ebb8:      	str	x8, [x19, #0x1860]
   1ebbc:      	str	x22, [x19, #0x1868]
   1ebc0:      	ldur	x1, [sp, #0xe0]
   1ebc4:      	str	x1, [x19, #0x1870]
   1ebc8:      	ldur	x1, [sp, #0xd8]
   1ebcc:      	uxtb	w14, w1
   1ebd0:      	str	x14, [x19, #0x1880]
   1ebd4:      	str	x28, [x19, #0x4c60]
   1ebd8:      	str	x6, [x19, #0x4c68]
   1ebdc:      	ldur	x4, [sp, #0x98]
   1ebe0:      	str	x4, [x19, #0x4c70]
   1ebe4:      	str	x22, [x19, #0x4f70]
   1ebe8:      	str	x23, [x19, #0x4f78]
   1ebec:      	ldur	x1, [sp, #0x18]
   1ebf0:      	str	x1, [x19, #0x50c0]
   1ebf4:      	mov	x1, x26
   1ebf8:      	str	x1, [x19, #0x50c8]
   1ebfc:      	str	x22, [x19, #0x50d0]
   1ec00:      	ldur	x1, [sp, #0xe0]
   1ec04:      	str	x1, [x19, #0x50d8]
   1ec08:      	ldur	x24, [sp, #0x10]
   1ec0c:      	str	x24, [x19, #0x50e0]
   1ec10:      	ldur	x26, [sp, #0x68]
   1ec14:      	str	x26, [x19, #0x50e8]
   1ec18:      	ldur	x1, [sp, #0x70]
   1ec1c:      	str	x1, [x19, #0x50f0]
   1ec20:      	ldur	x24, [sp, #0x78]
   1ec24:      	str	x24, [x19, #0x50f8]
   1ec28:      	ldur	x26, [sp, #0x80]
   1ec2c:      	str	x26, [x19, #0x5100]
   1ec30:      	ldur	x24, [sp, #0x10]
   1ec34:      	str	x24, [x19, #0x5178]
   1ec38:      	ldur	x26, [sp, #0x68]
   1ec3c:      	str	x26, [x19, #0x5180]
   1ec40:      	str	x1, [x19, #0x5188]
   1ec44:      	ldur	x24, [sp, #0x78]
   1ec48:      	str	x24, [x19, #0x5190]
   1ec4c:      	ldur	x26, [sp, #0x80]
   1ec50:      	str	x26, [x19, #0x5198]
   1ec54:      	str	x27, [x19, #0x52a8]
   1ec58:      	str	x7, [x19, #0x52b0]
   1ec5c:      	str	x22, [x19, #0x52b8]
   1ec60:      	ldur	x1, [sp, #0xe0]
   1ec64:      	str	x1, [x19, #0x52c0]
   1ec68:      	str	x15, [x19, #0x52c8]
   1ec6c:      	ldur	x15, [sp, #0x30]
   1ec70:      	str	x15, [x19, #0x52d0]
   1ec74:      	mov	x24, x10
   1ec78:      	str	x24, [x19, #0x52d8]
   1ec7c:      	ldur	x24, [sp, #0x38]
   1ec80:      	str	x24, [x19, #0x52e0]
   1ec84:      	ldur	x15, [sp, #0x40]
   1ec88:      	str	x15, [x19, #0x52e8]
   1ec8c:      	ldur	x14, [sp, #0x60]
   1ec90:      	str	x14, [x19, #0x5a20]
   1ec94:      	add	x1, x11, #0x1
   1ec98:      	str	x1, [x19, #0x5bb0]
   1ec9c:      	ldur	x26, [sp, #0xa0]
   1eca0:      	str	x26, [x19, #0x5bb8]
   1eca4:      	ldur	x7, [sp, #0xa8]
   1eca8:      	str	x7, [x19, #0x5bc0]
   1ecac:      	ldur	x4, [sp, #0x90]
   1ecb0:      	sub	x2, x4, x6
   1ecb4:      	mov	w4, #0xc87e             ; =51326
   1ecb8:      	movk	w4, #0x1, lsl #16
   1ecbc:      	msub	x1, x1, x4, x2
   1ecc0:      	str	x1, [x19, #0x5bc8]
   1ecc4:      	str	x0, [x19, #0x5bd0]
   1ecc8:      	ldur	x14, [sp, #0x20]
   1eccc:      	str	x14, [x19, #0x5bd8]
   1ecd0:      	str	x0, [x19, #0x5be8]
   1ecd4:      	str	x3, [x19, #0x5bf0]
   1ecd8:      	str	x12, [x19, #0x5c00]
   1ecdc:      	str	x9, [x19, #0x5c08]
   1ece0:      	str	x13, [x19, #0x5c18]
   1ece4:      	ldur	x13, [sp, #0xc0]
   1ece8:      	str	x13, [x19, #0x5c20]
   1ecec:      	ldr	x0, [x19, #0x4c60]
   1ecf0:      	cmp	x0, #0x0
   1ecf4:      	b.eq	0x1ef38 <_mech_canonical_program_entry_v1_numeric_1282+0x1db8>
   1ecf8:      	ldr	x3, [x19, #0x4c68]
   1ecfc:      	ldr	x4, [x19, #0x4c70]
   1ed00:      	mov	x0, #0x0                ; =0
   1ed04:      	str	x0, [x19, #0x4c60]
   1ed08:      	mov	x0, #0x3                ; =3
   1ed0c:      	ldr	x15, [sp, #0x190]
   1ed10:      	mov	x21, x0
   1ed14:      	cmp	x15, #0x19a
   1ed18:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1ed1c:      	ldr	x0, [x19, #0x4f70]
   1ed20:      	ldr	x15, [sp, #0x198]
   1ed24:      	str	x0, [x15, #0x10]
   1ed28:      	ldr	x1, [x19, #0x4f78]
   1ed2c:      	ldr	x2, [sp, #0x198]
   1ed30:      	str	x1, [x2, #0x18]
   1ed34:      	ldr	x2, [x19, #0x5a20]
   1ed38:      	ldr	x5, [sp, #0x198]
   1ed3c:      	str	x2, [x5, #0xac0]
   1ed40:      	ldr	x2, [x19, #0x5178]
   1ed44:      	str	x2, [x5, #0x218]
   1ed48:      	ldr	x2, [x19, #0x5180]
   1ed4c:      	str	x2, [x5, #0x220]
   1ed50:      	ldr	x5, [x19, #0x5188]
   1ed54:      	ldr	x2, [sp, #0x198]
   1ed58:      	str	x5, [x2, #0x228]
   1ed5c:      	ldr	x5, [x19, #0x5190]
   1ed60:      	str	x5, [x2, #0x230]
   1ed64:      	ldr	x5, [x19, #0x5198]
   1ed68:      	str	x5, [x2, #0x238]
   1ed6c:      	str	x0, [x2, #0x10]
   1ed70:      	ldr	x0, [sp, #0x198]
   1ed74:      	str	x1, [x0, #0x18]
   1ed78:      	ldr	x8, [x19, #0x50c0]
   1ed7c:      	str	x8, [x0, #0x160]
   1ed80:      	ldr	x9, [x19, #0x50c8]
   1ed84:      	str	x9, [x0, #0x168]
   1ed88:      	ldr	x10, [x19, #0x50d0]
   1ed8c:      	str	x10, [x0, #0x170]
   1ed90:      	ldr	x11, [x19, #0x50d8]
   1ed94:      	str	x11, [x0, #0x178]
   1ed98:      	ldr	x12, [x19, #0x50e0]
   1ed9c:      	str	x12, [x0, #0x180]
   1eda0:      	ldr	x13, [x19, #0x50e8]
   1eda4:      	str	x13, [x0, #0x188]
   1eda8:      	ldr	x14, [x19, #0x50f0]
   1edac:      	str	x14, [x0, #0x190]
   1edb0:      	ldr	x15, [x19, #0x50f8]
   1edb4:      	ldr	x1, [sp, #0x198]
   1edb8:      	str	x15, [x1, #0x198]
   1edbc:      	ldr	x0, [x19, #0x5100]
   1edc0:      	ldr	x5, [sp, #0x198]
   1edc4:      	str	x0, [x5, #0x1a0]
   1edc8:      	ldr	x0, [x19, #0x52a8]
   1edcc:      	ldr	x7, [sp, #0x198]
   1edd0:      	str	x0, [x7, #0x348]
   1edd4:      	ldr	x0, [x19, #0x52b0]
   1edd8:      	ldr	x10, [sp, #0x198]
   1eddc:      	str	x0, [x10, #0x350]
   1ede0:      	ldr	x0, [x19, #0x52b8]
   1ede4:      	ldr	x13, [sp, #0x198]
   1ede8:      	str	x0, [x13, #0x358]
   1edec:      	ldr	x0, [x19, #0x52c0]
   1edf0:      	str	x0, [x1, #0x360]
   1edf4:      	ldr	x0, [x19, #0x52c8]
   1edf8:      	str	x0, [x1, #0x368]
   1edfc:      	ldr	x0, [x19, #0x52d0]
   1ee00:      	str	x0, [x1, #0x370]
   1ee04:      	ldr	x0, [x19, #0x52d8]
   1ee08:      	str	x0, [x1, #0x378]
   1ee0c:      	ldr	x0, [x19, #0x52e0]
   1ee10:      	str	x0, [x1, #0x380]
   1ee14:      	ldr	x0, [x19, #0x52e8]
   1ee18:      	str	x0, [x1, #0x388]
   1ee1c:      	ldr	x0, [x19, #0x55d8]
   1ee20:      	str	x0, [x1, #0x678]
   1ee24:      	ldr	x0, [x19, #0x55e0]
   1ee28:      	str	x0, [x1, #0x680]
   1ee2c:      	ldr	x0, [x19, #0x55e8]
   1ee30:      	str	x0, [x1, #0x688]
   1ee34:      	ldr	x0, [x19, #0x55f0]
   1ee38:      	str	x0, [x1, #0x690]
   1ee3c:      	ldr	x0, [x19, #0x55f8]
   1ee40:      	str	x0, [x1, #0x698]
   1ee44:      	ldr	x0, [x19, #0x5600]
   1ee48:      	str	x0, [x1, #0x6a0]
   1ee4c:      	ldr	x0, [x19, #0x5608]
   1ee50:      	str	x0, [x1, #0x6a8]
   1ee54:      	ldr	x0, [x19, #0x5610]
   1ee58:      	str	x0, [x1, #0x6b0]
   1ee5c:      	ldr	x0, [x19, #0x57a0]
   1ee60:      	str	x0, [x1, #0x840]
   1ee64:      	ldr	x0, [x19, #0x57a8]
   1ee68:      	str	x0, [x1, #0x848]
   1ee6c:      	ldr	x0, [x19, #0x57b0]
   1ee70:      	str	x0, [x1, #0x850]
   1ee74:      	ldr	x0, [x19, #0x57b8]
   1ee78:      	str	x0, [x5, #0x858]
   1ee7c:      	ldr	x0, [x19, #0x57c0]
   1ee80:      	str	x0, [x7, #0x860]
   1ee84:      	ldr	x0, [x19, #0x57c8]
   1ee88:      	str	x0, [x10, #0x868]
   1ee8c:      	ldr	x0, [x19, #0x57d0]
   1ee90:      	str	x0, [x13, #0x870]
   1ee94:      	ldr	x0, [x19, #0x57d8]
   1ee98:      	str	x0, [x1, #0x878]
   1ee9c:      	ldr	x0, [x19, #0x5bb0]
   1eea0:      	str	x0, [x1, #0xc50]
   1eea4:      	ldr	x0, [x19, #0x5bb8]
   1eea8:      	str	x0, [x1, #0xc58]
   1eeac:      	ldr	x0, [x19, #0x5bc0]
   1eeb0:      	str	x0, [x1, #0xc60]
   1eeb4:      	ldr	x0, [x19, #0x5bc8]
   1eeb8:      	str	x0, [x1, #0xc68]
   1eebc:      	ldr	x0, [x19, #0x5bd0]
   1eec0:      	str	x0, [x1, #0xc70]
   1eec4:      	ldr	x0, [x19, #0x5bd8]
   1eec8:      	str	x0, [x1, #0xc78]
   1eecc:      	mov	x0, #0x0                ; =0
   1eed0:      	str	x0, [x1, #0xc80]
   1eed4:      	ldr	x1, [x19, #0x5be8]
   1eed8:      	str	x1, [x2, #0xc88]
   1eedc:      	ldr	x1, [x19, #0x5bf0]
   1eee0:      	str	x1, [x2, #0xc90]
   1eee4:      	ldr	x1, [sp, #0x198]
   1eee8:      	str	x0, [x1, #0xc98]
   1eeec:      	ldr	x1, [x19, #0x5c00]
   1eef0:      	str	x1, [x2, #0xca0]
   1eef4:      	ldr	x1, [x19, #0x5c08]
   1eef8:      	str	x1, [x2, #0xca8]
   1eefc:      	ldr	x1, [sp, #0x198]
   1ef00:      	str	x0, [x1, #0xcb0]
   1ef04:      	ldr	x0, [x19, #0x5c18]
   1ef08:      	str	x0, [x1, #0xcb8]
   1ef0c:      	ldr	x0, [x19, #0x5c20]
   1ef10:      	str	x0, [x1, #0xcc0]
   1ef14:      	mov	x1, #0x53d              ; =1341
   1ef18:      	mov	x2, #-0x9               ; =-9
   1ef1c:      	mov	x5, #0x1                ; =1
   1ef20:      	ldur	x0, [sp, #0x8]
   1ef24:      	ldr	x6, [sp, #0x1a0]
   1ef28:      	ldr	x21, [sp, #0x1a8]
   1ef2c:      	blr	x21
   1ef30:      	cmp	x0, #0x0
   1ef34:      	b.ne	0x225d0 <_mech_canonical_program_entry_v1_numeric_1282+0x5450>
   1ef38:      	mov	x0, #0x0                ; =0
   1ef3c:      	mov	x1, #0x3                ; =3
   1ef40:      	add	sp, sp, #0x1c0
   1ef44:      	ldp	x19, x20, [sp], #0x10
   1ef48:      	ldp	x21, x22, [sp], #0x10
   1ef4c:      	ldp	x23, x24, [sp], #0x10
   1ef50:      	ldp	x25, x26, [sp], #0x10
   1ef54:      	ldp	x27, x28, [sp], #0x10
   1ef58:      	ldp	x29, x30, [sp], #0x10
   1ef5c:      	retab
   1ef60:      	stur	x15, [sp, #0x28]
   1ef64:      	mov	x24, x10
   1ef68:      	ldur	x15, [sp, #0x30]
   1ef6c:      	cmp	x27, x7
   1ef70:      	cset	x10, lo
   1ef74:      	cmp	x27, x7
   1ef78:      	b.lo	0x1efb0 <_mech_canonical_program_entry_v1_numeric_1282+0x1e30>
   1ef7c:      	ldur	x0, [sp, #0x40]
   1ef80:      	ldur	x1, [sp, #0x38]
   1ef84:      	ldur	x2, [sp, #0x28]
   1ef88:      	ldur	x4, [sp, #0x40]
   1ef8c:      	ldur	x5, [sp, #0x38]
   1ef90:      	mov	x8, x24
   1ef94:      	mov	x10, x15
   1ef98:      	mov	x14, x27
   1ef9c:      	str	x28, [sp, #0x1b0]
   1efa0:      	ldur	x28, [sp, #0x28]
   1efa4:      	stur	x28, [sp, #0x48]
   1efa8:      	ldr	x28, [sp, #0x1b0]
   1efac:      	b	0x1f658 <_mech_canonical_program_entry_v1_numeric_1282+0x24d8>
   1efb0:      	ldr	x8, [sp, #0x140]
   1efb4:      	cmp	x27, x8
   1efb8:      	b.lo	0x1f23c <_mech_canonical_program_entry_v1_numeric_1282+0x20bc>
   1efbc:      	b	0x225d8 <_mech_canonical_program_entry_v1_numeric_1282+0x5458>
   1efc0:      	ldr	x3, [x19, #0x4c68]
   1efc4:      	ldr	x4, [x19, #0x4c70]
   1efc8:      	mov	x0, #0x0                ; =0
   1efcc:      	str	x0, [x19, #0x4c60]
   1efd0:      	mov	x0, #0x3                ; =3
   1efd4:      	ldr	x15, [sp, #0x190]
   1efd8:      	mov	x21, x0
   1efdc:      	cmp	x15, #0x19a
   1efe0:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1efe4:      	ldr	x0, [x19, #0x4f70]
   1efe8:      	ldr	x10, [sp, #0x198]
   1efec:      	str	x0, [x10, #0x10]
   1eff0:      	ldr	x1, [x19, #0x4f78]
   1eff4:      	ldr	x13, [sp, #0x198]
   1eff8:      	str	x1, [x13, #0x18]
   1effc:      	ldr	x2, [x19, #0x5a20]
   1f000:      	ldr	x5, [sp, #0x198]
   1f004:      	str	x2, [x5, #0xac0]
   1f008:      	ldr	x2, [sp, #0x198]
   1f00c:      	str	x0, [x2, #0x10]
   1f010:      	ldr	x0, [sp, #0x198]
   1f014:      	str	x1, [x0, #0x18]
   1f018:      	ldr	x0, [x19, #0x50c0]
   1f01c:      	ldr	x1, [sp, #0x198]
   1f020:      	str	x0, [x1, #0x160]
   1f024:      	ldr	x0, [x19, #0x50c8]
   1f028:      	str	x0, [x1, #0x168]
   1f02c:      	ldr	x0, [x19, #0x50d0]
   1f030:      	str	x0, [x1, #0x170]
   1f034:      	ldr	x0, [x19, #0x50d8]
   1f038:      	str	x0, [x1, #0x178]
   1f03c:      	ldr	x0, [x19, #0x50e0]
   1f040:      	str	x0, [x1, #0x180]
   1f044:      	ldr	x0, [x19, #0x50e8]
   1f048:      	str	x0, [x1, #0x188]
   1f04c:      	ldr	x0, [x19, #0x50f0]
   1f050:      	str	x0, [x1, #0x190]
   1f054:      	ldr	x0, [x19, #0x50f8]
   1f058:      	str	x0, [x1, #0x198]
   1f05c:      	ldr	x0, [x19, #0x5100]
   1f060:      	str	x0, [x1, #0x1a0]
   1f064:      	ldr	x0, [x19, #0x52a8]
   1f068:      	str	x0, [x1, #0x348]
   1f06c:      	ldr	x0, [x19, #0x52b0]
   1f070:      	str	x0, [x1, #0x350]
   1f074:      	ldr	x0, [x19, #0x52b8]
   1f078:      	str	x0, [x1, #0x358]
   1f07c:      	ldr	x0, [x19, #0x52c0]
   1f080:      	str	x0, [x1, #0x360]
   1f084:      	ldr	x0, [x19, #0x52c8]
   1f088:      	str	x0, [x1, #0x368]
   1f08c:      	ldr	x0, [x19, #0x52d0]
   1f090:      	str	x0, [x2, #0x370]
   1f094:      	ldr	x0, [x19, #0x52d8]
   1f098:      	str	x0, [x5, #0x378]
   1f09c:      	ldr	x0, [x19, #0x52e0]
   1f0a0:      	ldr	x8, [sp, #0x198]
   1f0a4:      	str	x0, [x8, #0x380]
   1f0a8:      	ldr	x0, [x19, #0x52e8]
   1f0ac:      	ldr	x11, [sp, #0x198]
   1f0b0:      	str	x0, [x11, #0x388]
   1f0b4:      	ldr	x0, [x19, #0x55d8]
   1f0b8:      	ldr	x14, [sp, #0x198]
   1f0bc:      	str	x0, [x14, #0x678]
   1f0c0:      	ldr	x0, [x19, #0x55e0]
   1f0c4:      	str	x0, [x1, #0x680]
   1f0c8:      	ldr	x0, [x19, #0x55e8]
   1f0cc:      	str	x0, [x1, #0x688]
   1f0d0:      	ldr	x0, [x19, #0x55f0]
   1f0d4:      	str	x0, [x1, #0x690]
   1f0d8:      	ldr	x0, [x19, #0x55f8]
   1f0dc:      	str	x0, [x1, #0x698]
   1f0e0:      	ldr	x0, [x19, #0x5600]
   1f0e4:      	str	x0, [x1, #0x6a0]
   1f0e8:      	ldr	x0, [x19, #0x5608]
   1f0ec:      	str	x0, [x1, #0x6a8]
   1f0f0:      	ldr	x0, [x19, #0x5610]
   1f0f4:      	str	x0, [x1, #0x6b0]
   1f0f8:      	ldr	x0, [x19, #0x57a0]
   1f0fc:      	str	x0, [x1, #0x840]
   1f100:      	ldr	x0, [x19, #0x57a8]
   1f104:      	str	x0, [x1, #0x848]
   1f108:      	ldr	x0, [x19, #0x57b0]
   1f10c:      	str	x0, [x1, #0x850]
   1f110:      	ldr	x1, [x19, #0x57b8]
   1f114:      	ldr	x0, [sp, #0x198]
   1f118:      	str	x1, [x0, #0x858]
   1f11c:      	ldr	x2, [x19, #0x57c0]
   1f120:      	str	x2, [x0, #0x860]
   1f124:      	ldr	x5, [x19, #0x57c8]
   1f128:      	str	x5, [x0, #0x868]
   1f12c:      	ldr	x5, [x19, #0x57d0]
   1f130:      	str	x5, [x0, #0x870]
   1f134:      	ldr	x5, [x19, #0x57d8]
   1f138:      	str	x5, [x0, #0x878]
   1f13c:      	ldr	x6, [x19, #0x5bb0]
   1f140:      	str	x6, [x0, #0xc50]
   1f144:      	ldr	x7, [x19, #0x5bb8]
   1f148:      	ldr	x2, [sp, #0x198]
   1f14c:      	str	x7, [x2, #0xc58]
   1f150:      	ldr	x8, [x19, #0x5bc0]
   1f154:      	ldr	x5, [sp, #0x198]
   1f158:      	str	x8, [x5, #0xc60]
   1f15c:      	ldr	x9, [x19, #0x5bc8]
   1f160:      	ldr	x8, [sp, #0x198]
   1f164:      	str	x9, [x8, #0xc68]
   1f168:      	ldr	x10, [x19, #0x5bd0]
   1f16c:      	str	x10, [x11, #0xc70]
   1f170:      	ldr	x11, [x19, #0x5bd8]
   1f174:      	str	x11, [x14, #0xc78]
   1f178:      	mov	x12, #0x0               ; =0
   1f17c:      	str	x12, [x0, #0xc80]
   1f180:      	ldr	x13, [x19, #0x5be8]
   1f184:      	str	x13, [x0, #0xc88]
   1f188:      	ldr	x14, [x19, #0x5bf0]
   1f18c:      	str	x14, [x0, #0xc90]
   1f190:      	str	x12, [x0, #0xc98]
   1f194:      	ldr	x0, [x19, #0x5c00]
   1f198:      	ldr	x1, [sp, #0x198]
   1f19c:      	str	x0, [x1, #0xca0]
   1f1a0:      	ldr	x0, [x19, #0x5c08]
   1f1a4:      	str	x0, [x1, #0xca8]
   1f1a8:      	ldr	x0, [sp, #0x198]
   1f1ac:      	str	x12, [x0, #0xcb0]
   1f1b0:      	ldr	x0, [x19, #0x5c18]
   1f1b4:      	str	x0, [x1, #0xcb8]
   1f1b8:      	ldr	x0, [x19, #0x5c20]
   1f1bc:      	str	x0, [x1, #0xcc0]
   1f1c0:      	mov	x1, #0x54e              ; =1358
   1f1c4:      	mov	x2, #-0x9               ; =-9
   1f1c8:      	ldr	x21, [sp, #0x1a8]
   1f1cc:      	ldur	x0, [sp, #0x8]
   1f1d0:      	mov	x5, x25
   1f1d4:      	ldr	x6, [sp, #0x1a0]
   1f1d8:      	blr	x21
   1f1dc:      	cmp	x0, #0x0
   1f1e0:      	b.ne	0x227c0 <_mech_canonical_program_entry_v1_numeric_1282+0x5640>
   1f1e4:      	mov	x0, #0x3                ; =3
   1f1e8:      	ldr	x15, [sp, #0x190]
   1f1ec:      	mov	x21, x0
   1f1f0:      	cmp	x15, #0x2
   1f1f4:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1f1f8:      	mov	x5, #0x0                ; =0
   1f1fc:      	ldr	x3, [sp, #0x198]
   1f200:      	str	x5, [x3]
   1f204:      	ldr	x0, [x19, #0x1950]
   1f208:      	str	x0, [x3, #0x8]
   1f20c:      	mov	x1, #0x54e              ; =1358
   1f210:      	ldur	x0, [sp, #0x8]
   1f214:      	ldr	x6, [sp, #0x1a0]
   1f218:      	ldr	x21, [sp, #0x1a8]
   1f21c:      	mov	x4, x25
   1f220:      	mov	x2, x5
   1f224:      	blr	x21
   1f228:      	cmp	x0, #0x0
   1f22c:      	b.ne	0x227c8 <_mech_canonical_program_entry_v1_numeric_1282+0x5648>
   1f230:      	mov	x0, #0x3                ; =3
   1f234:      	mov	x21, x0
   1f238:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1f23c:      	ldur	x0, [sp, #0x40]
   1f240:      	ldur	x1, [sp, #0x38]
   1f244:      	ldur	x2, [sp, #0x28]
   1f248:      	ldr	x4, [sp, #0x148]
   1f24c:      	ldr	x14, [x4, x27, lsl #3]
   1f250:      	cmp	x14, x22
   1f254:      	b.ne	0x1f274 <_mech_canonical_program_entry_v1_numeric_1282+0x20f4>
   1f258:      	mov	x4, x0
   1f25c:      	mov	x5, x1
   1f260:      	mov	x8, x24
   1f264:      	mov	x10, x15
   1f268:      	mov	x14, x27
   1f26c:      	stur	x2, [sp, #0x48]
   1f270:      	b	0x1f610 <_mech_canonical_program_entry_v1_numeric_1282+0x2490>
   1f274:      	add	x4, x14, #0x1
   1f278:      	cmp	x4, x14
   1f27c:      	b.lo	0x227d0 <_mech_canonical_program_entry_v1_numeric_1282+0x5650>
   1f280:      	ldr	x5, [sp, #0x170]
   1f284:      	cmp	x14, x5
   1f288:      	b.lo	0x1f51c <_mech_canonical_program_entry_v1_numeric_1282+0x239c>
   1f28c:      	b	0x22934 <_mech_canonical_program_entry_v1_numeric_1282+0x57b4>
   1f290:      	ldr	x3, [x19, #0x4c68]
   1f294:      	ldr	x4, [x19, #0x4c70]
   1f298:      	mov	x0, #0x0                ; =0
   1f29c:      	str	x0, [x19, #0x4c60]
   1f2a0:      	mov	x0, #0x3                ; =3
   1f2a4:      	ldr	x15, [sp, #0x190]
   1f2a8:      	mov	x21, x0
   1f2ac:      	cmp	x15, #0x19a
   1f2b0:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1f2b4:      	ldr	x0, [x19, #0x4f70]
   1f2b8:      	ldr	x6, [sp, #0x198]
   1f2bc:      	str	x0, [x6, #0x10]
   1f2c0:      	ldr	x1, [x19, #0x4f78]
   1f2c4:      	ldr	x9, [sp, #0x198]
   1f2c8:      	str	x1, [x9, #0x18]
   1f2cc:      	ldr	x2, [x19, #0x5a20]
   1f2d0:      	ldr	x12, [sp, #0x198]
   1f2d4:      	str	x2, [x12, #0xac0]
   1f2d8:      	ldr	x14, [sp, #0x198]
   1f2dc:      	str	x0, [x14, #0x10]
   1f2e0:      	ldr	x0, [sp, #0x198]
   1f2e4:      	str	x1, [x0, #0x18]
   1f2e8:      	ldr	x0, [x19, #0x50c0]
   1f2ec:      	ldr	x1, [sp, #0x198]
   1f2f0:      	str	x0, [x1, #0x160]
   1f2f4:      	ldr	x0, [x19, #0x50c8]
   1f2f8:      	str	x0, [x1, #0x168]
   1f2fc:      	ldr	x0, [x19, #0x50d0]
   1f300:      	str	x0, [x1, #0x170]
   1f304:      	ldr	x0, [x19, #0x50d8]
   1f308:      	str	x0, [x1, #0x178]
   1f30c:      	ldr	x0, [x19, #0x50e0]
   1f310:      	str	x0, [x1, #0x180]
   1f314:      	ldr	x0, [x19, #0x50e8]
   1f318:      	str	x0, [x1, #0x188]
   1f31c:      	ldr	x0, [x19, #0x50f0]
   1f320:      	str	x0, [x1, #0x190]
   1f324:      	ldr	x0, [x19, #0x50f8]
   1f328:      	str	x0, [x1, #0x198]
   1f32c:      	ldr	x0, [x19, #0x5100]
   1f330:      	str	x0, [x1, #0x1a0]
   1f334:      	ldr	x0, [x19, #0x52a8]
   1f338:      	str	x0, [x1, #0x348]
   1f33c:      	ldr	x0, [x19, #0x52b0]
   1f340:      	str	x0, [x1, #0x350]
   1f344:      	ldr	x0, [x19, #0x52b8]
   1f348:      	str	x0, [x1, #0x358]
   1f34c:      	ldr	x0, [x19, #0x52c0]
   1f350:      	str	x0, [x1, #0x360]
   1f354:      	ldr	x0, [x19, #0x52c8]
   1f358:      	str	x0, [x1, #0x368]
   1f35c:      	ldr	x0, [x19, #0x52d0]
   1f360:      	str	x0, [x1, #0x370]
   1f364:      	ldr	x0, [x19, #0x52d8]
   1f368:      	str	x0, [x1, #0x378]
   1f36c:      	ldr	x0, [x19, #0x52e0]
   1f370:      	ldr	x5, [sp, #0x198]
   1f374:      	str	x0, [x5, #0x380]
   1f378:      	ldr	x1, [x19, #0x52e8]
   1f37c:      	ldr	x7, [sp, #0x198]
   1f380:      	str	x1, [x7, #0x388]
   1f384:      	ldr	x2, [x19, #0x55d8]
   1f388:      	ldr	x10, [sp, #0x198]
   1f38c:      	str	x2, [x10, #0x678]
   1f390:      	ldr	x5, [x19, #0x55e0]
   1f394:      	ldr	x13, [sp, #0x198]
   1f398:      	str	x5, [x13, #0x680]
   1f39c:      	ldr	x5, [x19, #0x55e8]
   1f3a0:      	ldr	x0, [sp, #0x198]
   1f3a4:      	str	x5, [x0, #0x688]
   1f3a8:      	ldr	x5, [x19, #0x55f0]
   1f3ac:      	str	x5, [x0, #0x690]
   1f3b0:      	ldr	x6, [x19, #0x55f8]
   1f3b4:      	str	x6, [x0, #0x698]
   1f3b8:      	ldr	x7, [x19, #0x5600]
   1f3bc:      	str	x7, [x0, #0x6a0]
   1f3c0:      	ldr	x8, [x19, #0x5608]
   1f3c4:      	str	x8, [x0, #0x6a8]
   1f3c8:      	ldr	x9, [x19, #0x5610]
   1f3cc:      	str	x9, [x0, #0x6b0]
   1f3d0:      	ldr	x10, [x19, #0x57a0]
   1f3d4:      	str	x10, [x0, #0x840]
   1f3d8:      	ldr	x11, [x19, #0x57a8]
   1f3dc:      	str	x11, [x0, #0x848]
   1f3e0:      	ldr	x12, [x19, #0x57b0]
   1f3e4:      	str	x12, [x0, #0x850]
   1f3e8:      	ldr	x13, [x19, #0x57b8]
   1f3ec:      	str	x13, [x0, #0x858]
   1f3f0:      	ldr	x14, [x19, #0x57c0]
   1f3f4:      	str	x14, [x0, #0x860]
   1f3f8:      	ldr	x15, [x19, #0x57c8]
   1f3fc:      	str	x15, [x0, #0x868]
   1f400:      	ldr	x0, [x19, #0x57d0]
   1f404:      	ldr	x1, [sp, #0x198]
   1f408:      	str	x0, [x1, #0x870]
   1f40c:      	ldr	x0, [x19, #0x57d8]
   1f410:      	str	x0, [x1, #0x878]
   1f414:      	ldr	x0, [x19, #0x5bb0]
   1f418:      	str	x0, [x1, #0xc50]
   1f41c:      	ldr	x0, [x19, #0x5bb8]
   1f420:      	str	x0, [x1, #0xc58]
   1f424:      	ldr	x0, [x19, #0x5bc0]
   1f428:      	str	x0, [x1, #0xc60]
   1f42c:      	ldr	x0, [x19, #0x5bc8]
   1f430:      	ldr	x5, [sp, #0x198]
   1f434:      	str	x0, [x5, #0xc68]
   1f438:      	ldr	x0, [x19, #0x5bd0]
   1f43c:      	ldr	x7, [sp, #0x198]
   1f440:      	str	x0, [x7, #0xc70]
   1f444:      	ldr	x0, [x19, #0x5bd8]
   1f448:      	ldr	x10, [sp, #0x198]
   1f44c:      	str	x0, [x10, #0xc78]
   1f450:      	mov	x0, #0x0                ; =0
   1f454:      	ldr	x13, [sp, #0x198]
   1f458:      	str	x0, [x13, #0xc80]
   1f45c:      	ldr	x1, [x19, #0x5be8]
   1f460:      	ldr	x2, [sp, #0x198]
   1f464:      	str	x1, [x2, #0xc88]
   1f468:      	ldr	x1, [x19, #0x5bf0]
   1f46c:      	str	x1, [x2, #0xc90]
   1f470:      	ldr	x1, [sp, #0x198]
   1f474:      	str	x0, [x1, #0xc98]
   1f478:      	ldr	x1, [x19, #0x5c00]
   1f47c:      	str	x1, [x2, #0xca0]
   1f480:      	ldr	x1, [x19, #0x5c08]
   1f484:      	str	x1, [x2, #0xca8]
   1f488:      	ldr	x1, [sp, #0x198]
   1f48c:      	str	x0, [x1, #0xcb0]
   1f490:      	ldr	x0, [x19, #0x5c18]
   1f494:      	str	x0, [x1, #0xcb8]
   1f498:      	ldr	x0, [x19, #0x5c20]
   1f49c:      	str	x0, [x1, #0xcc0]
   1f4a0:      	mov	x1, #0x555              ; =1365
   1f4a4:      	mov	x2, #-0x9               ; =-9
   1f4a8:      	ldr	x21, [sp, #0x1a8]
   1f4ac:      	ldur	x0, [sp, #0x8]
   1f4b0:      	mov	x5, x20
   1f4b4:      	ldr	x6, [sp, #0x1a0]
   1f4b8:      	blr	x21
   1f4bc:      	cmp	x0, #0x0
   1f4c0:      	b.ne	0x22b10 <_mech_canonical_program_entry_v1_numeric_1282+0x5990>
   1f4c4:      	mov	x0, #0x3                ; =3
   1f4c8:      	ldr	x15, [sp, #0x190]
   1f4cc:      	mov	x21, x0
   1f4d0:      	cmp	x15, #0x2
   1f4d4:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1f4d8:      	mov	x5, #0x0                ; =0
   1f4dc:      	ldr	x3, [sp, #0x198]
   1f4e0:      	str	x5, [x3]
   1f4e4:      	ldr	x0, [x19, #0x1970]
   1f4e8:      	str	x0, [x3, #0x8]
   1f4ec:      	mov	x1, #0x555              ; =1365
   1f4f0:      	ldur	x0, [sp, #0x8]
   1f4f4:      	ldr	x6, [sp, #0x1a0]
   1f4f8:      	ldr	x21, [sp, #0x1a8]
   1f4fc:      	mov	x4, x20
   1f500:      	mov	x2, x5
   1f504:      	blr	x21
   1f508:      	cmp	x0, #0x0
   1f50c:      	b.ne	0x22b18 <_mech_canonical_program_entry_v1_numeric_1282+0x5998>
   1f510:      	mov	x0, #0x3                ; =3
   1f514:      	mov	x21, x0
   1f518:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1f51c:      	ldr	x4, [sp, #0x178]
   1f520:      	ldr	x4, [x4, x14, lsl #3]
   1f524:      	ldur	x5, [sp, #0xe0]
   1f528:      	and	x4, x5, x4
   1f52c:      	fmov	d16, x4
   1f530:      	cnt.8b	v16, v16
   1f534:      	addv.8b	b16, v16
   1f538:      	umov.b	w4, v16[0]
   1f53c:      	eor	x14, x14, #0x3ffffffffffffff
   1f540:      	orr	x14, x14, x4, lsl #58
   1f544:      	cmp	x14, x0
   1f548:      	cset	x4, hi
   1f54c:      	cmp	x14, x2
   1f550:      	cset	x5, ne
   1f554:      	and	w4, w4, w5
   1f558:      	cmp	x14, x15
   1f55c:      	cset	x5, ne
   1f560:      	and	w4, w4, w5
   1f564:      	cmp	x14, x24
   1f568:      	cset	x5, ne
   1f56c:      	and	w4, w4, w5
   1f570:      	cmp	x14, x1
   1f574:      	cset	x5, ne
   1f578:      	and	w4, w4, w5
   1f57c:      	uxtb	w4, w4
   1f580:      	tbnz	w4, #0x0, 0x1f59c <_mech_canonical_program_entry_v1_numeric_1282+0x241c>
   1f584:      	mov	x4, x2
   1f588:      	mov	x5, x15
   1f58c:      	mov	x8, x24
   1f590:      	mov	x10, x1
   1f594:      	mov	x14, x0
   1f598:      	b	0x1f5dc <_mech_canonical_program_entry_v1_numeric_1282+0x245c>
   1f59c:      	cmp	x14, x2
   1f5a0:      	csel	x4, x14, x2, hi
   1f5a4:      	cmp	x14, x2
   1f5a8:      	csel	x8, x14, x2, lo
   1f5ac:      	cmp	x8, x15
   1f5b0:      	csel	x5, x8, x15, hi
   1f5b4:      	cmp	x8, x15
   1f5b8:      	csel	x10, x8, x15, lo
   1f5bc:      	cmp	x10, x24
   1f5c0:      	csel	x8, x10, x24, hi
   1f5c4:      	cmp	x10, x24
   1f5c8:      	csel	x14, x10, x24, lo
   1f5cc:      	cmp	x14, x1
   1f5d0:      	csel	x10, x14, x1, hi
   1f5d4:      	cmp	x14, x1
   1f5d8:      	csel	x14, x14, x1, lo
   1f5dc:      	stur	x2, [sp, #0x48]
   1f5e0:      	str	x8, [sp, #0x1b0]
   1f5e4:      	mov	x8, x24
   1f5e8:      	ldr	x24, [sp, #0x1b0]
   1f5ec:      	mov	x2, x4
   1f5f0:      	mov	x4, x0
   1f5f4:      	str	x1, [sp, #0x1b0]
   1f5f8:      	mov	x1, x10
   1f5fc:      	mov	x10, x15
   1f600:      	mov	x15, x5
   1f604:      	ldr	x5, [sp, #0x1b0]
   1f608:      	mov	x0, x14
   1f60c:      	mov	x14, x27
   1f610:      	str	x10, [sp, #0x1b0]
   1f614:      	mov	x10, x15
   1f618:      	ldr	x15, [sp, #0x1b0]
   1f61c:      	str	x8, [sp, #0x1b0]
   1f620:      	mov	x8, x24
   1f624:      	ldr	x24, [sp, #0x1b0]
   1f628:      	str	x2, [sp, #0x1b0]
   1f62c:      	ldur	x2, [sp, #0x48]
   1f630:      	str	x28, [sp, #0x1b8]
   1f634:      	ldr	x28, [sp, #0x1b0]
   1f638:      	stur	x28, [sp, #0x48]
   1f63c:      	str	x1, [sp, #0x1b0]
   1f640:      	mov	x1, x5
   1f644:      	ldr	x5, [sp, #0x1b0]
   1f648:      	str	x0, [sp, #0x1b0]
   1f64c:      	mov	x0, x4
   1f650:      	ldr	x4, [sp, #0x1b0]
   1f654:      	ldr	x28, [sp, #0x1b8]
   1f658:      	cmp	x27, x7
   1f65c:      	b.lo	0x21b6c <_mech_canonical_program_entry_v1_numeric_1282+0x49ec>
   1f660:      	mov	x8, #0x0                ; =0
   1f664:      	str	x8, [x25, #0x15d0]
   1f668:      	str	x8, [x25, #0x15d8]
   1f66c:      	str	x8, [x25, #0x15e0]
   1f670:      	str	x8, [x25, #0x15e8]
   1f674:      	str	x8, [x25, #0x15f0]
   1f678:      	str	x8, [x25, #0x15f8]
   1f67c:      	str	x8, [x25, #0x1600]
   1f680:      	str	x8, [x25, #0x1608]
   1f684:      	str	x8, [x25, #0x1610]
   1f688:      	str	x8, [x25, #0x1618]
   1f68c:      	str	x8, [x25, #0x1620]
   1f690:      	str	x8, [x25, #0x1628]
   1f694:      	str	x8, [x25, #0x1630]
   1f698:      	str	x8, [x25, #0x1638]
   1f69c:      	str	x8, [x25, #0x1640]
   1f6a0:      	str	x8, [x25, #0x1648]
   1f6a4:      	str	x8, [x25, #0x1650]
   1f6a8:      	str	x8, [x25, #0x1658]
   1f6ac:      	mov	w3, #0xdc1e             ; =56350
   1f6b0:      	movk	w3, #0x2, lsl #16
   1f6b4:      	sub	x3, x6, x3
   1f6b8:      	mov	x8, #0x0                ; =0
   1f6bc:      	stur	x8, [sp, #0xb0]
   1f6c0:      	ldur	x4, [sp, #0x18]
   1f6c4:      	ldur	x5, [sp, #0xb0]
   1f6c8:      	stur	x5, [sp, #0xb8]
   1f6cc:      	mov	x5, x26
   1f6d0:      	ldur	x27, [sp, #0x18]
   1f6d4:      	cmp	x27, x5
   1f6d8:      	b.lo	0x21b40 <_mech_canonical_program_entry_v1_numeric_1282+0x49c0>
   1f6dc:      	mov	x0, #0x0                ; =0
   1f6e0:      	str	x0, [x25, #0x1200]
   1f6e4:      	str	x0, [x25, #0x1208]
   1f6e8:      	str	x0, [x25, #0x1210]
   1f6ec:      	str	x0, [x25, #0x1218]
   1f6f0:      	str	x0, [x25, #0x1220]
   1f6f4:      	str	x0, [x25, #0x1228]
   1f6f8:      	str	x0, [x25, #0x1230]
   1f6fc:      	str	x0, [x25, #0x1238]
   1f700:      	str	x0, [x25, #0x1240]
   1f704:      	str	x0, [x25, #0x1248]
   1f708:      	str	x0, [x25, #0x1250]
   1f70c:      	str	x0, [x25, #0x1258]
   1f710:      	str	x0, [x25, #0x1260]
   1f714:      	str	x0, [x25, #0x1268]
   1f718:      	str	x0, [x25, #0x1270]
   1f71c:      	str	x0, [x25, #0x1278]
   1f720:      	str	x0, [x25, #0x1280]
   1f724:      	str	x0, [x25, #0x1288]
   1f728:      	ldr	x26, [sp, #0x130]
   1f72c:      	cmp	x22, x26
   1f730:      	b.lo	0x1f9c4 <_mech_canonical_program_entry_v1_numeric_1282+0x2844>
   1f734:      	b	0x22b20 <_mech_canonical_program_entry_v1_numeric_1282+0x59a0>
   1f738:      	ldr	x3, [x19, #0x4c68]
   1f73c:      	ldr	x4, [x19, #0x4c70]
   1f740:      	mov	x0, #0x0                ; =0
   1f744:      	str	x0, [x19, #0x4c60]
   1f748:      	mov	x0, #0x3                ; =3
   1f74c:      	ldr	x15, [sp, #0x190]
   1f750:      	mov	x21, x0
   1f754:      	cmp	x15, #0x19a
   1f758:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1f75c:      	ldr	x0, [x19, #0x4f70]
   1f760:      	ldr	x1, [sp, #0x198]
   1f764:      	str	x0, [x1, #0x10]
   1f768:      	ldr	x1, [x19, #0x4f78]
   1f76c:      	ldr	x2, [sp, #0x198]
   1f770:      	str	x1, [x2, #0x18]
   1f774:      	ldr	x2, [x19, #0x5a20]
   1f778:      	ldr	x5, [sp, #0x198]
   1f77c:      	str	x2, [x5, #0xac0]
   1f780:      	ldr	x2, [sp, #0x198]
   1f784:      	str	x0, [x2, #0x10]
   1f788:      	ldr	x0, [sp, #0x198]
   1f78c:      	str	x1, [x0, #0x18]
   1f790:      	ldr	x0, [x19, #0x50c0]
   1f794:      	str	x0, [x5, #0x160]
   1f798:      	ldr	x0, [x19, #0x50c8]
   1f79c:      	ldr	x6, [sp, #0x198]
   1f7a0:      	str	x0, [x6, #0x168]
   1f7a4:      	ldr	x0, [x19, #0x50d0]
   1f7a8:      	ldr	x9, [sp, #0x198]
   1f7ac:      	str	x0, [x9, #0x170]
   1f7b0:      	ldr	x0, [x19, #0x50d8]
   1f7b4:      	ldr	x12, [sp, #0x198]
   1f7b8:      	str	x0, [x12, #0x178]
   1f7bc:      	ldr	x0, [x19, #0x50e0]
   1f7c0:      	ldr	x15, [sp, #0x198]
   1f7c4:      	str	x0, [x15, #0x180]
   1f7c8:      	ldr	x0, [x19, #0x50e8]
   1f7cc:      	ldr	x1, [sp, #0x198]
   1f7d0:      	str	x0, [x1, #0x188]
   1f7d4:      	ldr	x0, [x19, #0x50f0]
   1f7d8:      	str	x0, [x1, #0x190]
   1f7dc:      	ldr	x0, [x19, #0x50f8]
   1f7e0:      	str	x0, [x1, #0x198]
   1f7e4:      	ldr	x0, [x19, #0x5100]
   1f7e8:      	str	x0, [x1, #0x1a0]
   1f7ec:      	ldr	x0, [x19, #0x52a8]
   1f7f0:      	str	x0, [x1, #0x348]
   1f7f4:      	ldr	x0, [x19, #0x52b0]
   1f7f8:      	str	x0, [x1, #0x350]
   1f7fc:      	ldr	x0, [x19, #0x52b8]
   1f800:      	str	x0, [x1, #0x358]
   1f804:      	ldr	x0, [x19, #0x52c0]
   1f808:      	str	x0, [x1, #0x360]
   1f80c:      	ldr	x0, [x19, #0x52c8]
   1f810:      	str	x0, [x1, #0x368]
   1f814:      	ldr	x0, [x19, #0x52d0]
   1f818:      	str	x0, [x1, #0x370]
   1f81c:      	ldr	x0, [x19, #0x52d8]
   1f820:      	str	x0, [x1, #0x378]
   1f824:      	ldr	x0, [x19, #0x52e0]
   1f828:      	str	x0, [x1, #0x380]
   1f82c:      	ldr	x1, [x19, #0x52e8]
   1f830:      	ldr	x0, [sp, #0x198]
   1f834:      	str	x1, [x0, #0x388]
   1f838:      	ldr	x2, [x19, #0x55d8]
   1f83c:      	str	x2, [x0, #0x678]
   1f840:      	ldr	x5, [x19, #0x55e0]
   1f844:      	str	x5, [x0, #0x680]
   1f848:      	ldr	x5, [x19, #0x55e8]
   1f84c:      	str	x5, [x0, #0x688]
   1f850:      	ldr	x5, [x19, #0x55f0]
   1f854:      	str	x5, [x6, #0x690]
   1f858:      	ldr	x6, [x19, #0x55f8]
   1f85c:      	ldr	x7, [sp, #0x198]
   1f860:      	str	x6, [x7, #0x698]
   1f864:      	ldr	x7, [x19, #0x5600]
   1f868:      	str	x7, [x9, #0x6a0]
   1f86c:      	ldr	x8, [x19, #0x5608]
   1f870:      	str	x8, [x12, #0x6a8]
   1f874:      	ldr	x9, [x19, #0x5610]
   1f878:      	str	x9, [x15, #0x6b0]
   1f87c:      	ldr	x10, [x19, #0x57a0]
   1f880:      	str	x10, [x0, #0x840]
   1f884:      	ldr	x11, [x19, #0x57a8]
   1f888:      	str	x11, [x0, #0x848]
   1f88c:      	ldr	x12, [x19, #0x57b0]
   1f890:      	str	x12, [x0, #0x850]
   1f894:      	ldr	x13, [x19, #0x57b8]
   1f898:      	str	x13, [x0, #0x858]
   1f89c:      	ldr	x14, [x19, #0x57c0]
   1f8a0:      	str	x14, [x0, #0x860]
   1f8a4:      	ldr	x15, [x19, #0x57c8]
   1f8a8:      	str	x15, [x0, #0x868]
   1f8ac:      	ldr	x0, [x19, #0x57d0]
   1f8b0:      	ldr	x1, [sp, #0x198]
   1f8b4:      	str	x0, [x1, #0x870]
   1f8b8:      	ldr	x0, [x19, #0x57d8]
   1f8bc:      	str	x0, [x1, #0x878]
   1f8c0:      	ldr	x0, [x19, #0x5bb0]
   1f8c4:      	str	x0, [x1, #0xc50]
   1f8c8:      	ldr	x0, [x19, #0x5bb8]
   1f8cc:      	str	x0, [x1, #0xc58]
   1f8d0:      	ldr	x0, [x19, #0x5bc0]
   1f8d4:      	str	x0, [x1, #0xc60]
   1f8d8:      	ldr	x0, [x19, #0x5bc8]
   1f8dc:      	str	x0, [x1, #0xc68]
   1f8e0:      	ldr	x0, [x19, #0x5bd0]
   1f8e4:      	str	x0, [x1, #0xc70]
   1f8e8:      	ldr	x0, [x19, #0x5bd8]
   1f8ec:      	str	x0, [x1, #0xc78]
   1f8f0:      	mov	x0, #0x0                ; =0
   1f8f4:      	str	x0, [x1, #0xc80]
   1f8f8:      	ldr	x1, [x19, #0x5be8]
   1f8fc:      	ldr	x2, [sp, #0x198]
   1f900:      	str	x1, [x2, #0xc88]
   1f904:      	ldr	x1, [x19, #0x5bf0]
   1f908:      	ldr	x5, [sp, #0x198]
   1f90c:      	str	x1, [x5, #0xc90]
   1f910:      	str	x0, [x5, #0xc98]
   1f914:      	ldr	x1, [x19, #0x5c00]
   1f918:      	ldr	x8, [sp, #0x198]
   1f91c:      	str	x1, [x8, #0xca0]
   1f920:      	ldr	x1, [x19, #0x5c08]
   1f924:      	ldr	x11, [sp, #0x198]
   1f928:      	str	x1, [x11, #0xca8]
   1f92c:      	ldr	x13, [sp, #0x198]
   1f930:      	str	x0, [x13, #0xcb0]
   1f934:      	ldr	x0, [x19, #0x5c18]
   1f938:      	ldr	x1, [sp, #0x198]
   1f93c:      	str	x0, [x1, #0xcb8]
   1f940:      	ldr	x0, [x19, #0x5c20]
   1f944:      	str	x0, [x1, #0xcc0]
   1f948:      	mov	x1, #0x5e8              ; =1512
   1f94c:      	mov	x2, #-0x9               ; =-9
   1f950:      	ldr	x21, [sp, #0x1a8]
   1f954:      	ldur	x0, [sp, #0x8]
   1f958:      	mov	x5, x20
   1f95c:      	ldr	x6, [sp, #0x1a0]
   1f960:      	blr	x21
   1f964:      	cmp	x0, #0x0
   1f968:      	b.ne	0x22c44 <_mech_canonical_program_entry_v1_numeric_1282+0x5ac4>
   1f96c:      	mov	x0, #0x3                ; =3
   1f970:      	ldr	x15, [sp, #0x190]
   1f974:      	mov	x21, x0
   1f978:      	cmp	x15, #0x2
   1f97c:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1f980:      	mov	x5, #0x0                ; =0
   1f984:      	ldr	x3, [sp, #0x198]
   1f988:      	str	x5, [x3]
   1f98c:      	ldr	x0, [x19, #0x1c00]
   1f990:      	str	x0, [x3, #0x8]
   1f994:      	mov	x1, #0x5e8              ; =1512
   1f998:      	ldur	x0, [sp, #0x8]
   1f99c:      	ldr	x6, [sp, #0x1a0]
   1f9a0:      	ldr	x21, [sp, #0x1a8]
   1f9a4:      	mov	x4, x20
   1f9a8:      	mov	x2, x5
   1f9ac:      	blr	x21
   1f9b0:      	cmp	x0, #0x0
   1f9b4:      	b.ne	0x22c4c <_mech_canonical_program_entry_v1_numeric_1282+0x5acc>
   1f9b8:      	mov	x0, #0x3                ; =3
   1f9bc:      	mov	x21, x0
   1f9c0:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1f9c4:      	ldr	x26, [sp, #0x138]
   1f9c8:      	ldr	x15, [x26, x22, lsl #3]
   1f9cc:      	ldur	x0, [sp, #0xe8]
   1f9d0:      	ldr	x26, [sp, #0x130]
   1f9d4:      	cmp	x0, x26
   1f9d8:      	b.lo	0x1fc64 <_mech_canonical_program_entry_v1_numeric_1282+0x2ae4>
   1f9dc:      	b	0x22c54 <_mech_canonical_program_entry_v1_numeric_1282+0x5ad4>
   1f9e0:      	ldr	x3, [x19, #0x4c68]
   1f9e4:      	ldr	x4, [x19, #0x4c70]
   1f9e8:      	mov	x0, #0x0                ; =0
   1f9ec:      	str	x0, [x19, #0x4c60]
   1f9f0:      	mov	x0, #0x3                ; =3
   1f9f4:      	ldr	x15, [sp, #0x190]
   1f9f8:      	mov	x21, x0
   1f9fc:      	cmp	x15, #0x19a
   1fa00:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1fa04:      	ldr	x0, [x19, #0x4f70]
   1fa08:      	ldr	x1, [sp, #0x198]
   1fa0c:      	str	x0, [x1, #0x10]
   1fa10:      	ldr	x1, [x19, #0x4f78]
   1fa14:      	ldr	x2, [sp, #0x198]
   1fa18:      	str	x1, [x2, #0x18]
   1fa1c:      	ldr	x2, [x19, #0x5a20]
   1fa20:      	ldr	x5, [sp, #0x198]
   1fa24:      	str	x2, [x5, #0xac0]
   1fa28:      	ldr	x7, [sp, #0x198]
   1fa2c:      	str	x0, [x7, #0x10]
   1fa30:      	ldr	x9, [sp, #0x198]
   1fa34:      	str	x1, [x9, #0x18]
   1fa38:      	ldr	x0, [x19, #0x50c0]
   1fa3c:      	ldr	x12, [sp, #0x198]
   1fa40:      	str	x0, [x12, #0x160]
   1fa44:      	ldr	x0, [x19, #0x50c8]
   1fa48:      	ldr	x15, [sp, #0x198]
   1fa4c:      	str	x0, [x15, #0x168]
   1fa50:      	ldr	x0, [x19, #0x50d0]
   1fa54:      	ldr	x1, [sp, #0x198]
   1fa58:      	str	x0, [x1, #0x170]
   1fa5c:      	ldr	x0, [x19, #0x50d8]
   1fa60:      	str	x0, [x1, #0x178]
   1fa64:      	ldr	x0, [x19, #0x50e0]
   1fa68:      	str	x0, [x1, #0x180]
   1fa6c:      	ldr	x0, [x19, #0x50e8]
   1fa70:      	str	x0, [x1, #0x188]
   1fa74:      	ldr	x0, [x19, #0x50f0]
   1fa78:      	str	x0, [x1, #0x190]
   1fa7c:      	ldr	x0, [x19, #0x50f8]
   1fa80:      	str	x0, [x1, #0x198]
   1fa84:      	ldr	x0, [x19, #0x5100]
   1fa88:      	str	x0, [x1, #0x1a0]
   1fa8c:      	ldr	x0, [x19, #0x52a8]
   1fa90:      	str	x0, [x1, #0x348]
   1fa94:      	ldr	x0, [x19, #0x52b0]
   1fa98:      	str	x0, [x1, #0x350]
   1fa9c:      	ldr	x0, [x19, #0x52b8]
   1faa0:      	str	x0, [x1, #0x358]
   1faa4:      	ldr	x0, [x19, #0x52c0]
   1faa8:      	str	x0, [x1, #0x360]
   1faac:      	ldr	x0, [x19, #0x52c8]
   1fab0:      	str	x0, [x1, #0x368]
   1fab4:      	ldr	x0, [x19, #0x52d0]
   1fab8:      	str	x0, [x1, #0x370]
   1fabc:      	ldr	x0, [x19, #0x52d8]
   1fac0:      	str	x0, [x1, #0x378]
   1fac4:      	ldr	x0, [x19, #0x52e0]
   1fac8:      	str	x0, [x1, #0x380]
   1facc:      	ldr	x0, [x19, #0x52e8]
   1fad0:      	str	x0, [x1, #0x388]
   1fad4:      	ldr	x0, [x19, #0x55d8]
   1fad8:      	str	x0, [x5, #0x678]
   1fadc:      	ldr	x0, [x19, #0x55e0]
   1fae0:      	ldr	x6, [sp, #0x198]
   1fae4:      	str	x0, [x6, #0x680]
   1fae8:      	ldr	x0, [x19, #0x55e8]
   1faec:      	str	x0, [x9, #0x688]
   1faf0:      	ldr	x0, [x19, #0x55f0]
   1faf4:      	str	x0, [x12, #0x690]
   1faf8:      	ldr	x0, [x19, #0x55f8]
   1fafc:      	str	x0, [x15, #0x698]
   1fb00:      	ldr	x0, [x19, #0x5600]
   1fb04:      	str	x0, [x1, #0x6a0]
   1fb08:      	ldr	x0, [x19, #0x5608]
   1fb0c:      	str	x0, [x1, #0x6a8]
   1fb10:      	ldr	x1, [x19, #0x5610]
   1fb14:      	ldr	x0, [sp, #0x198]
   1fb18:      	str	x1, [x0, #0x6b0]
   1fb1c:      	ldr	x2, [x19, #0x57a0]
   1fb20:      	str	x2, [x0, #0x840]
   1fb24:      	ldr	x5, [x19, #0x57a8]
   1fb28:      	str	x5, [x0, #0x848]
   1fb2c:      	ldr	x5, [x19, #0x57b0]
   1fb30:      	str	x5, [x0, #0x850]
   1fb34:      	ldr	x5, [x19, #0x57b8]
   1fb38:      	str	x5, [x0, #0x858]
   1fb3c:      	ldr	x6, [x19, #0x57c0]
   1fb40:      	str	x6, [x0, #0x860]
   1fb44:      	ldr	x7, [x19, #0x57c8]
   1fb48:      	str	x7, [x0, #0x868]
   1fb4c:      	ldr	x8, [x19, #0x57d0]
   1fb50:      	str	x8, [x0, #0x870]
   1fb54:      	ldr	x9, [x19, #0x57d8]
   1fb58:      	str	x9, [x0, #0x878]
   1fb5c:      	ldr	x10, [x19, #0x5bb0]
   1fb60:      	str	x10, [x0, #0xc50]
   1fb64:      	ldr	x11, [x19, #0x5bb8]
   1fb68:      	str	x11, [x0, #0xc58]
   1fb6c:      	ldr	x12, [x19, #0x5bc0]
   1fb70:      	str	x12, [x0, #0xc60]
   1fb74:      	ldr	x13, [x19, #0x5bc8]
   1fb78:      	str	x13, [x0, #0xc68]
   1fb7c:      	ldr	x14, [x19, #0x5bd0]
   1fb80:      	str	x14, [x0, #0xc70]
   1fb84:      	ldr	x15, [x19, #0x5bd8]
   1fb88:      	ldr	x5, [sp, #0x198]
   1fb8c:      	str	x15, [x5, #0xc78]
   1fb90:      	mov	x0, #0x0                ; =0
   1fb94:      	ldr	x6, [sp, #0x198]
   1fb98:      	str	x0, [x6, #0xc80]
   1fb9c:      	ldr	x1, [x19, #0x5be8]
   1fba0:      	ldr	x9, [sp, #0x198]
   1fba4:      	str	x1, [x9, #0xc88]
   1fba8:      	ldr	x1, [x19, #0x5bf0]
   1fbac:      	ldr	x12, [sp, #0x198]
   1fbb0:      	str	x1, [x12, #0xc90]
   1fbb4:      	ldr	x14, [sp, #0x198]
   1fbb8:      	str	x0, [x14, #0xc98]
   1fbbc:      	ldr	x1, [x19, #0x5c00]
   1fbc0:      	ldr	x2, [sp, #0x198]
   1fbc4:      	str	x1, [x2, #0xca0]
   1fbc8:      	ldr	x1, [x19, #0x5c08]
   1fbcc:      	str	x1, [x2, #0xca8]
   1fbd0:      	ldr	x1, [sp, #0x198]
   1fbd4:      	str	x0, [x1, #0xcb0]
   1fbd8:      	ldr	x0, [x19, #0x5c18]
   1fbdc:      	str	x0, [x1, #0xcb8]
   1fbe0:      	ldr	x0, [x19, #0x5c20]
   1fbe4:      	str	x0, [x1, #0xcc0]
   1fbe8:      	mov	x1, #0x5ea              ; =1514
   1fbec:      	mov	x2, #-0x9               ; =-9
   1fbf0:      	ldr	x21, [sp, #0x1a8]
   1fbf4:      	ldur	x0, [sp, #0x8]
   1fbf8:      	mov	x5, x20
   1fbfc:      	ldr	x6, [sp, #0x1a0]
   1fc00:      	blr	x21
   1fc04:      	cmp	x0, #0x0
   1fc08:      	b.ne	0x22d7c <_mech_canonical_program_entry_v1_numeric_1282+0x5bfc>
   1fc0c:      	mov	x0, #0x3                ; =3
   1fc10:      	ldr	x15, [sp, #0x190]
   1fc14:      	mov	x21, x0
   1fc18:      	cmp	x15, #0x2
   1fc1c:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1fc20:      	mov	x5, #0x0                ; =0
   1fc24:      	ldr	x3, [sp, #0x198]
   1fc28:      	str	x5, [x3]
   1fc2c:      	ldr	x0, [x19, #0x1c10]
   1fc30:      	str	x0, [x3, #0x8]
   1fc34:      	mov	x1, #0x5ea              ; =1514
   1fc38:      	ldur	x0, [sp, #0x8]
   1fc3c:      	ldr	x6, [sp, #0x1a0]
   1fc40:      	ldr	x21, [sp, #0x1a8]
   1fc44:      	mov	x4, x20
   1fc48:      	mov	x2, x5
   1fc4c:      	blr	x21
   1fc50:      	cmp	x0, #0x0
   1fc54:      	b.ne	0x22d84 <_mech_canonical_program_entry_v1_numeric_1282+0x5c04>
   1fc58:      	mov	x0, #0x3                ; =3
   1fc5c:      	mov	x21, x0
   1fc60:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1fc64:      	ldur	x0, [sp, #0xe8]
   1fc68:      	ldr	x26, [sp, #0x138]
   1fc6c:      	ldr	x12, [x26, x0, lsl #3]
   1fc70:      	mov	x10, #0x0               ; =0
   1fc74:      	stur	x10, [sp, #0x50]
   1fc78:      	mov	w0, #0x2646             ; =9798
   1fc7c:      	movk	w0, #0x1, lsl #16
   1fc80:      	cmp	x3, x0
   1fc84:      	cset	x0, hs
   1fc88:      	ldur	x26, [sp, #0xf8]
   1fc8c:      	and	w0, w0, w26
   1fc90:      	uxtb	w0, w0
   1fc94:      	cbnz	x0, 0x20034 <_mech_canonical_program_entry_v1_numeric_1282+0x2eb4>
   1fc98:      	mov	x0, #0x0                ; =0
   1fc9c:      	str	x0, [x19, #0x18]
   1fca0:      	mov	x1, #0x1000000000000000 ; =1152921504606846976
   1fca4:      	str	x1, [x19, #0x20]
   1fca8:      	mov	x1, #0x1                ; =1
   1fcac:      	str	x1, [x19, #0x30]
   1fcb0:      	mov	x2, #0x101010101010101  ; =72340172838076673
   1fcb4:      	str	x2, [x19, #0x38]
   1fcb8:      	mov	x20, #0x2               ; =2
   1fcbc:      	str	x20, [x19, #0x40]
   1fcc0:      	mov	x2, #0x3                ; =3
   1fcc4:      	str	x2, [x19, #0x48]
   1fcc8:      	mov	x2, #0x4                ; =4
   1fccc:      	str	x2, [x19, #0x50]
   1fcd0:      	stur	x2, [sp, #0xd0]
   1fcd4:      	mov	x2, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   1fcd8:      	str	x2, [x19, #0x78]
   1fcdc:      	mov	x2, #0x3333333333333333 ; =3689348814741910323
   1fce0:      	str	x2, [x19, #0x88]
   1fce4:      	mov	x2, #0x38               ; =56
   1fce8:      	str	x2, [x19, #0x90]
   1fcec:      	mov	x2, #0x3a               ; =58
   1fcf0:      	str	x2, [x19, #0x98]
   1fcf4:      	mov	x2, #0x5555555555555555 ; =6148914691236517205
   1fcf8:      	str	x2, [x19, #0xb0]
   1fcfc:      	mov	x2, #0x3ffffffffffffff  ; =288230376151711743
   1fd00:      	str	x2, [x19, #0xb8]
   1fd04:      	str	x0, [x19, #0x188]
   1fd08:      	str	x1, [x19, #0x190]
   1fd0c:      	str	x22, [x19, #0x17a0]
   1fd10:      	str	x23, [x19, #0x17a8]
   1fd14:      	ldur	x25, [sp, #0xf0]
   1fd18:      	uxtb	w2, w25
   1fd1c:      	str	x2, [x19, #0x17b8]
   1fd20:      	str	x28, [x19, #0x4c60]
   1fd24:      	str	x3, [x19, #0x4c68]
   1fd28:      	ldur	x4, [sp, #0x98]
   1fd2c:      	str	x4, [x19, #0x4c70]
   1fd30:      	str	x22, [x19, #0x4f70]
   1fd34:      	str	x23, [x19, #0x4f78]
   1fd38:      	str	x15, [x19, #0x55d8]
   1fd3c:      	str	x12, [x19, #0x55e0]
   1fd40:      	str	x22, [x19, #0x55e8]
   1fd44:      	ldur	x24, [sp, #0x10]
   1fd48:      	str	x24, [x19, #0x55f0]
   1fd4c:      	ldur	x26, [sp, #0x68]
   1fd50:      	str	x26, [x19, #0x55f8]
   1fd54:      	ldur	x27, [sp, #0x70]
   1fd58:      	str	x27, [x19, #0x5600]
   1fd5c:      	ldur	x24, [sp, #0x78]
   1fd60:      	str	x24, [x19, #0x5608]
   1fd64:      	ldur	x26, [sp, #0x80]
   1fd68:      	str	x26, [x19, #0x5610]
   1fd6c:      	ldur	x14, [sp, #0x60]
   1fd70:      	str	x14, [x19, #0x5a20]
   1fd74:      	add	x2, x11, #0x1
   1fd78:      	str	x2, [x19, #0x5bb0]
   1fd7c:      	ldur	x26, [sp, #0xa0]
   1fd80:      	str	x26, [x19, #0x5bb8]
   1fd84:      	ldur	x7, [sp, #0xa8]
   1fd88:      	str	x7, [x19, #0x5bc0]
   1fd8c:      	ldur	x4, [sp, #0x90]
   1fd90:      	sub	x3, x4, x3
   1fd94:      	mov	w4, #0xc87e             ; =51326
   1fd98:      	movk	w4, #0x1, lsl #16
   1fd9c:      	msub	x2, x2, x4, x3
   1fda0:      	str	x2, [x19, #0x5bc8]
   1fda4:      	str	x0, [x19, #0x5bd0]
   1fda8:      	str	x0, [x19, #0x5bd8]
   1fdac:      	ldur	x8, [sp, #0xb0]
   1fdb0:      	str	x8, [x19, #0x5be8]
   1fdb4:      	ldur	x4, [sp, #0xb8]
   1fdb8:      	str	x4, [x19, #0x5bf0]
   1fdbc:      	str	x1, [x19, #0x5c00]
   1fdc0:      	ldur	x10, [sp, #0x50]
   1fdc4:      	str	x10, [x19, #0x5c08]
   1fdc8:      	str	x13, [x19, #0x5c18]
   1fdcc:      	ldur	x13, [sp, #0xc0]
   1fdd0:      	str	x13, [x19, #0x5c20]
   1fdd4:      	ldr	x0, [x19, #0x4c60]
   1fdd8:      	cmp	x0, #0x0
   1fddc:      	b.eq	0x2000c <_mech_canonical_program_entry_v1_numeric_1282+0x2e8c>
   1fde0:      	ldr	x3, [x19, #0x4c68]
   1fde4:      	ldr	x4, [x19, #0x4c70]
   1fde8:      	mov	x0, #0x0                ; =0
   1fdec:      	str	x0, [x19, #0x4c60]
   1fdf0:      	mov	x0, #0x3                ; =3
   1fdf4:      	ldr	x15, [sp, #0x190]
   1fdf8:      	mov	x21, x0
   1fdfc:      	cmp	x15, #0x19a
   1fe00:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   1fe04:      	ldr	x0, [x19, #0x4f70]
   1fe08:      	ldr	x1, [sp, #0x198]
   1fe0c:      	str	x0, [x1, #0x10]
   1fe10:      	ldr	x1, [x19, #0x4f78]
   1fe14:      	ldr	x2, [sp, #0x198]
   1fe18:      	str	x1, [x2, #0x18]
   1fe1c:      	ldr	x2, [x19, #0x5a20]
   1fe20:      	ldr	x5, [sp, #0x198]
   1fe24:      	str	x2, [x5, #0xac0]
   1fe28:      	ldr	x2, [sp, #0x198]
   1fe2c:      	str	x0, [x2, #0x10]
   1fe30:      	ldr	x0, [sp, #0x198]
   1fe34:      	str	x1, [x0, #0x18]
   1fe38:      	ldr	x0, [x19, #0x50c0]
   1fe3c:      	ldr	x1, [sp, #0x198]
   1fe40:      	str	x0, [x1, #0x160]
   1fe44:      	ldr	x0, [x19, #0x50c8]
   1fe48:      	str	x0, [x1, #0x168]
   1fe4c:      	ldr	x0, [x19, #0x50d0]
   1fe50:      	str	x0, [x1, #0x170]
   1fe54:      	ldr	x0, [x19, #0x50d8]
   1fe58:      	str	x0, [x1, #0x178]
   1fe5c:      	ldr	x0, [x19, #0x50e0]
   1fe60:      	str	x0, [x1, #0x180]
   1fe64:      	ldr	x0, [x19, #0x50e8]
   1fe68:      	str	x0, [x1, #0x188]
   1fe6c:      	ldr	x0, [x19, #0x50f0]
   1fe70:      	str	x0, [x1, #0x190]
   1fe74:      	ldr	x0, [x19, #0x50f8]
   1fe78:      	str	x0, [x1, #0x198]
   1fe7c:      	ldr	x0, [x19, #0x5100]
   1fe80:      	str	x0, [x1, #0x1a0]
   1fe84:      	ldr	x0, [x19, #0x52a8]
   1fe88:      	str	x0, [x1, #0x348]
   1fe8c:      	ldr	x0, [x19, #0x52b0]
   1fe90:      	str	x0, [x2, #0x350]
   1fe94:      	ldr	x0, [x19, #0x52b8]
   1fe98:      	str	x0, [x5, #0x358]
   1fe9c:      	ldr	x0, [x19, #0x52c0]
   1fea0:      	ldr	x8, [sp, #0x198]
   1fea4:      	str	x0, [x8, #0x360]
   1fea8:      	ldr	x0, [x19, #0x52c8]
   1feac:      	ldr	x11, [sp, #0x198]
   1feb0:      	str	x0, [x11, #0x368]
   1feb4:      	ldr	x0, [x19, #0x52d0]
   1feb8:      	ldr	x14, [sp, #0x198]
   1febc:      	str	x0, [x14, #0x370]
   1fec0:      	ldr	x0, [x19, #0x52d8]
   1fec4:      	str	x0, [x1, #0x378]
   1fec8:      	ldr	x0, [x19, #0x52e0]
   1fecc:      	str	x0, [x1, #0x380]
   1fed0:      	ldr	x0, [x19, #0x52e8]
   1fed4:      	str	x0, [x1, #0x388]
   1fed8:      	ldr	x0, [x19, #0x55d8]
   1fedc:      	str	x0, [x1, #0x678]
   1fee0:      	ldr	x0, [x19, #0x55e0]
   1fee4:      	str	x0, [x1, #0x680]
   1fee8:      	ldr	x0, [x19, #0x55e8]
   1feec:      	str	x0, [x1, #0x688]
   1fef0:      	ldr	x0, [x19, #0x55f0]
   1fef4:      	str	x0, [x1, #0x690]
   1fef8:      	ldr	x0, [x19, #0x55f8]
   1fefc:      	str	x0, [x1, #0x698]
   1ff00:      	ldr	x1, [x19, #0x5600]
   1ff04:      	ldr	x0, [sp, #0x198]
   1ff08:      	str	x1, [x0, #0x6a0]
   1ff0c:      	ldr	x2, [x19, #0x5608]
   1ff10:      	str	x2, [x0, #0x6a8]
   1ff14:      	ldr	x5, [x19, #0x5610]
   1ff18:      	str	x5, [x0, #0x6b0]
   1ff1c:      	ldr	x5, [x19, #0x57a0]
   1ff20:      	str	x5, [x0, #0x840]
   1ff24:      	ldr	x5, [x19, #0x57a8]
   1ff28:      	str	x5, [x0, #0x848]
   1ff2c:      	ldr	x6, [x19, #0x57b0]
   1ff30:      	str	x6, [x0, #0x850]
   1ff34:      	ldr	x7, [x19, #0x57b8]
   1ff38:      	str	x7, [x0, #0x858]
   1ff3c:      	ldr	x8, [x19, #0x57c0]
   1ff40:      	str	x8, [x0, #0x860]
   1ff44:      	ldr	x9, [x19, #0x57c8]
   1ff48:      	ldr	x2, [sp, #0x198]
   1ff4c:      	str	x9, [x2, #0x868]
   1ff50:      	ldr	x10, [x19, #0x57d0]
   1ff54:      	ldr	x5, [sp, #0x198]
   1ff58:      	str	x10, [x5, #0x870]
   1ff5c:      	ldr	x11, [x19, #0x57d8]
   1ff60:      	ldr	x8, [sp, #0x198]
   1ff64:      	str	x11, [x8, #0x878]
   1ff68:      	ldr	x12, [x19, #0x5bb0]
   1ff6c:      	ldr	x11, [sp, #0x198]
   1ff70:      	str	x12, [x11, #0xc50]
   1ff74:      	ldr	x13, [x19, #0x5bb8]
   1ff78:      	str	x13, [x14, #0xc58]
   1ff7c:      	ldr	x14, [x19, #0x5bc0]
   1ff80:      	str	x14, [x0, #0xc60]
   1ff84:      	ldr	x15, [x19, #0x5bc8]
   1ff88:      	str	x15, [x0, #0xc68]
   1ff8c:      	ldr	x0, [x19, #0x5bd0]
   1ff90:      	ldr	x1, [sp, #0x198]
   1ff94:      	str	x0, [x1, #0xc70]
   1ff98:      	ldr	x0, [x19, #0x5bd8]
   1ff9c:      	str	x0, [x1, #0xc78]
   1ffa0:      	mov	x0, #0x0                ; =0
   1ffa4:      	str	x0, [x1, #0xc80]
   1ffa8:      	ldr	x1, [x19, #0x5be8]
   1ffac:      	str	x1, [x2, #0xc88]
   1ffb0:      	ldr	x1, [x19, #0x5bf0]
   1ffb4:      	str	x1, [x2, #0xc90]
   1ffb8:      	ldr	x1, [sp, #0x198]
   1ffbc:      	str	x0, [x1, #0xc98]
   1ffc0:      	ldr	x1, [x19, #0x5c00]
   1ffc4:      	str	x1, [x2, #0xca0]
   1ffc8:      	ldr	x1, [x19, #0x5c08]
   1ffcc:      	str	x1, [x2, #0xca8]
   1ffd0:      	ldr	x1, [sp, #0x198]
   1ffd4:      	str	x0, [x1, #0xcb0]
   1ffd8:      	ldr	x0, [x19, #0x5c18]
   1ffdc:      	str	x0, [x1, #0xcb8]
   1ffe0:      	ldr	x0, [x19, #0x5c20]
   1ffe4:      	str	x0, [x1, #0xcc0]
   1ffe8:      	mov	x1, #0x5f2              ; =1522
   1ffec:      	mov	x2, #-0x9               ; =-9
   1fff0:      	mov	x5, #0x1                ; =1
   1fff4:      	ldur	x0, [sp, #0x8]
   1fff8:      	ldr	x6, [sp, #0x1a0]
   1fffc:      	ldr	x21, [sp, #0x1a8]
   20000:      	blr	x21
   20004:      	cmp	x0, #0x0
   20008:      	b.ne	0x22d8c <_mech_canonical_program_entry_v1_numeric_1282+0x5c0c>
   2000c:      	mov	x0, #0x0                ; =0
   20010:      	ldur	x1, [sp, #0xd0]
   20014:      	add	sp, sp, #0x1c0
   20018:      	ldp	x19, x20, [sp], #0x10
   2001c:      	ldp	x21, x22, [sp], #0x10
   20020:      	ldp	x23, x24, [sp], #0x10
   20024:      	ldp	x25, x26, [sp], #0x10
   20028:      	ldp	x27, x28, [sp], #0x10
   2002c:      	ldp	x29, x30, [sp], #0x10
   20030:      	retab
   20034:      	cmp	x15, x12
   20038:      	cset	x0, lo
   2003c:      	mov	x26, #0x1000000000000000 ; =1152921504606846976
   20040:      	mov	x1, #0x1000000000000000 ; =1152921504606846976
   20044:      	ldur	x8, [sp, #0x80]
   20048:      	cmp	x8, x1
   2004c:      	cset	x1, lo
   20050:      	and	w0, w0, w1
   20054:      	uxtb	w24, w0
   20058:      	tbnz	w24, #0x0, 0x20080 <_mech_canonical_program_entry_v1_numeric_1282+0x2f00>
   2005c:      	mov	w0, #0x2646             ; =9798
   20060:      	movk	w0, #0x1, lsl #16
   20064:      	sub	x3, x3, x0
   20068:      	ldur	x0, [sp, #0x80]
   2006c:      	ldur	x1, [sp, #0x10]
   20070:      	ldur	x9, [sp, #0x78]
   20074:      	ldur	x10, [sp, #0x70]
   20078:      	ldur	x14, [sp, #0x68]
   2007c:      	b	0x21088 <_mech_canonical_program_entry_v1_numeric_1282+0x3f08>
   20080:      	add	x2, x15, #0x1
   20084:      	cmp	x2, x15
   20088:      	b.lo	0x22d94 <_mech_canonical_program_entry_v1_numeric_1282+0x5c14>
   2008c:      	ldr	x0, [sp, #0x120]
   20090:      	cmp	x15, x0
   20094:      	b.lo	0x2031c <_mech_canonical_program_entry_v1_numeric_1282+0x319c>
   20098:      	b	0x22ec4 <_mech_canonical_program_entry_v1_numeric_1282+0x5d44>
   2009c:      	ldr	x3, [x19, #0x4c68]
   200a0:      	ldr	x4, [x19, #0x4c70]
   200a4:      	mov	x0, #0x0                ; =0
   200a8:      	str	x0, [x19, #0x4c60]
   200ac:      	mov	x0, #0x3                ; =3
   200b0:      	ldr	x15, [sp, #0x190]
   200b4:      	mov	x21, x0
   200b8:      	cmp	x15, #0x19a
   200bc:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   200c0:      	ldr	x0, [x19, #0x4f70]
   200c4:      	ldr	x1, [sp, #0x198]
   200c8:      	str	x0, [x1, #0x10]
   200cc:      	ldr	x1, [x19, #0x4f78]
   200d0:      	ldr	x2, [sp, #0x198]
   200d4:      	str	x1, [x2, #0x18]
   200d8:      	ldr	x2, [x19, #0x5a20]
   200dc:      	ldr	x5, [sp, #0x198]
   200e0:      	str	x2, [x5, #0xac0]
   200e4:      	ldr	x2, [sp, #0x198]
   200e8:      	str	x0, [x2, #0x10]
   200ec:      	str	x1, [x2, #0x18]
   200f0:      	ldr	x0, [x19, #0x50c0]
   200f4:      	str	x0, [x5, #0x160]
   200f8:      	ldr	x0, [x19, #0x50c8]
   200fc:      	ldr	x8, [sp, #0x198]
   20100:      	str	x0, [x8, #0x168]
   20104:      	ldr	x0, [x19, #0x50d0]
   20108:      	ldr	x11, [sp, #0x198]
   2010c:      	str	x0, [x11, #0x170]
   20110:      	ldr	x0, [x19, #0x50d8]
   20114:      	ldr	x14, [sp, #0x198]
   20118:      	str	x0, [x14, #0x178]
   2011c:      	ldr	x0, [x19, #0x50e0]
   20120:      	ldr	x1, [sp, #0x198]
   20124:      	str	x0, [x1, #0x180]
   20128:      	ldr	x0, [x19, #0x50e8]
   2012c:      	str	x0, [x1, #0x188]
   20130:      	ldr	x0, [x19, #0x50f0]
   20134:      	str	x0, [x1, #0x190]
   20138:      	ldr	x0, [x19, #0x50f8]
   2013c:      	str	x0, [x1, #0x198]
   20140:      	ldr	x0, [x19, #0x5100]
   20144:      	str	x0, [x1, #0x1a0]
   20148:      	ldr	x0, [x19, #0x52a8]
   2014c:      	str	x0, [x1, #0x348]
   20150:      	ldr	x0, [x19, #0x52b0]
   20154:      	str	x0, [x1, #0x350]
   20158:      	ldr	x0, [x19, #0x52b8]
   2015c:      	str	x0, [x1, #0x358]
   20160:      	ldr	x0, [x19, #0x52c0]
   20164:      	str	x0, [x1, #0x360]
   20168:      	ldr	x0, [x19, #0x52c8]
   2016c:      	str	x0, [x1, #0x368]
   20170:      	ldr	x0, [x19, #0x52d0]
   20174:      	str	x0, [x1, #0x370]
   20178:      	ldr	x0, [x19, #0x52d8]
   2017c:      	str	x0, [x1, #0x378]
   20180:      	ldr	x0, [x19, #0x52e0]
   20184:      	str	x0, [x1, #0x380]
   20188:      	ldr	x0, [x19, #0x52e8]
   2018c:      	str	x0, [x1, #0x388]
   20190:      	ldr	x0, [x19, #0x55d8]
   20194:      	str	x0, [x1, #0x678]
   20198:      	ldr	x0, [x19, #0x55e0]
   2019c:      	str	x0, [x1, #0x680]
   201a0:      	ldr	x0, [x19, #0x55e8]
   201a4:      	str	x0, [x2, #0x688]
   201a8:      	ldr	x0, [x19, #0x55f0]
   201ac:      	str	x0, [x5, #0x690]
   201b0:      	ldr	x0, [x19, #0x55f8]
   201b4:      	str	x0, [x8, #0x698]
   201b8:      	ldr	x0, [x19, #0x5600]
   201bc:      	str	x0, [x11, #0x6a0]
   201c0:      	ldr	x0, [x19, #0x5608]
   201c4:      	str	x0, [x14, #0x6a8]
   201c8:      	ldr	x0, [x19, #0x5610]
   201cc:      	str	x0, [x1, #0x6b0]
   201d0:      	ldr	x0, [x19, #0x57a0]
   201d4:      	str	x0, [x1, #0x840]
   201d8:      	ldr	x0, [x19, #0x57a8]
   201dc:      	str	x0, [x1, #0x848]
   201e0:      	ldr	x0, [x19, #0x57b0]
   201e4:      	str	x0, [x1, #0x850]
   201e8:      	ldr	x0, [x19, #0x57b8]
   201ec:      	str	x0, [x1, #0x858]
   201f0:      	ldr	x0, [x19, #0x57c0]
   201f4:      	str	x0, [x1, #0x860]
   201f8:      	ldr	x0, [x19, #0x57c8]
   201fc:      	str	x0, [x1, #0x868]
   20200:      	ldr	x1, [x19, #0x57d0]
   20204:      	ldr	x0, [sp, #0x198]
   20208:      	str	x1, [x0, #0x870]
   2020c:      	ldr	x2, [x19, #0x57d8]
   20210:      	str	x2, [x0, #0x878]
   20214:      	ldr	x5, [x19, #0x5bb0]
   20218:      	str	x5, [x0, #0xc50]
   2021c:      	ldr	x5, [x19, #0x5bb8]
   20220:      	str	x5, [x0, #0xc58]
   20224:      	ldr	x5, [x19, #0x5bc0]
   20228:      	str	x5, [x0, #0xc60]
   2022c:      	ldr	x6, [x19, #0x5bc8]
   20230:      	str	x6, [x0, #0xc68]
   20234:      	ldr	x7, [x19, #0x5bd0]
   20238:      	str	x7, [x0, #0xc70]
   2023c:      	ldr	x8, [x19, #0x5bd8]
   20240:      	str	x8, [x0, #0xc78]
   20244:      	mov	x9, #0x0                ; =0
   20248:      	str	x9, [x0, #0xc80]
   2024c:      	ldr	x10, [x19, #0x5be8]
   20250:      	ldr	x2, [sp, #0x198]
   20254:      	str	x10, [x2, #0xc88]
   20258:      	ldr	x11, [x19, #0x5bf0]
   2025c:      	ldr	x5, [sp, #0x198]
   20260:      	str	x11, [x5, #0xc90]
   20264:      	ldr	x7, [sp, #0x198]
   20268:      	str	x9, [x7, #0xc98]
   2026c:      	ldr	x13, [x19, #0x5c00]
   20270:      	ldr	x10, [sp, #0x198]
   20274:      	str	x13, [x10, #0xca0]
   20278:      	ldr	x14, [x19, #0x5c08]
   2027c:      	ldr	x13, [sp, #0x198]
   20280:      	str	x14, [x13, #0xca8]
   20284:      	ldr	x15, [sp, #0x198]
   20288:      	str	x9, [x15, #0xcb0]
   2028c:      	ldr	x0, [x19, #0x5c18]
   20290:      	ldr	x1, [sp, #0x198]
   20294:      	str	x0, [x1, #0xcb8]
   20298:      	ldr	x0, [x19, #0x5c20]
   2029c:      	str	x0, [x1, #0xcc0]
   202a0:      	mov	x1, #0x605              ; =1541
   202a4:      	mov	x2, #-0x9               ; =-9
   202a8:      	ldr	x21, [sp, #0x1a8]
   202ac:      	ldur	x0, [sp, #0x8]
   202b0:      	mov	x5, x20
   202b4:      	ldr	x6, [sp, #0x1a0]
   202b8:      	blr	x21
   202bc:      	cmp	x0, #0x0
   202c0:      	b.ne	0x23034 <_mech_canonical_program_entry_v1_numeric_1282+0x5eb4>
   202c4:      	mov	x0, #0x3                ; =3
   202c8:      	ldr	x15, [sp, #0x190]
   202cc:      	mov	x21, x0
   202d0:      	cmp	x15, #0x2
   202d4:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   202d8:      	mov	x5, #0x0                ; =0
   202dc:      	ldr	x3, [sp, #0x198]
   202e0:      	str	x5, [x3]
   202e4:      	ldr	x0, [x19, #0x1cb8]
   202e8:      	str	x0, [x3, #0x8]
   202ec:      	mov	x1, #0x605              ; =1541
   202f0:      	ldur	x0, [sp, #0x8]
   202f4:      	ldr	x6, [sp, #0x1a0]
   202f8:      	ldr	x21, [sp, #0x1a8]
   202fc:      	mov	x4, x20
   20300:      	mov	x2, x5
   20304:      	blr	x21
   20308:      	cmp	x0, #0x0
   2030c:      	b.ne	0x2303c <_mech_canonical_program_entry_v1_numeric_1282+0x5ebc>
   20310:      	mov	x0, #0x3                ; =3
   20314:      	mov	x21, x0
   20318:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   2031c:      	ldr	x14, [sp, #0x128]
   20320:      	ldr	x1, [x14, x15, lsl #3]
   20324:      	add	x4, x1, #0x1
   20328:      	cmp	x4, x1
   2032c:      	b.lo	0x23044 <_mech_canonical_program_entry_v1_numeric_1282+0x5ec4>
   20330:      	ldr	x0, [sp, #0x110]
   20334:      	cmp	x1, x0
   20338:      	b.lo	0x205a4 <_mech_canonical_program_entry_v1_numeric_1282+0x3424>
   2033c:      	b	0x23178 <_mech_canonical_program_entry_v1_numeric_1282+0x5ff8>
   20340:      	ldr	x3, [x19, #0x4c68]
   20344:      	ldr	x4, [x19, #0x4c70]
   20348:      	mov	x6, #0x0                ; =0
   2034c:      	str	x6, [x19, #0x4c60]
   20350:      	mov	x0, #0x3                ; =3
   20354:      	ldr	x15, [sp, #0x190]
   20358:      	mov	x21, x0
   2035c:      	cmp	x15, #0x19a
   20360:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   20364:      	ldr	x10, [x19, #0x4f70]
   20368:      	ldr	x0, [sp, #0x198]
   2036c:      	str	x10, [x0, #0x10]
   20370:      	ldr	x11, [x19, #0x4f78]
   20374:      	str	x11, [x0, #0x18]
   20378:      	ldr	x12, [x19, #0x5a20]
   2037c:      	str	x12, [x0, #0xac0]
   20380:      	str	x10, [x0, #0x10]
   20384:      	str	x11, [x0, #0x18]
   20388:      	ldr	x15, [x19, #0x50c0]
   2038c:      	str	x15, [x0, #0x160]
   20390:      	ldr	x0, [x19, #0x50c8]
   20394:      	ldr	x1, [sp, #0x198]
   20398:      	str	x0, [x1, #0x168]
   2039c:      	ldr	x0, [x19, #0x50d0]
   203a0:      	str	x0, [x1, #0x170]
   203a4:      	ldr	x0, [x19, #0x50d8]
   203a8:      	str	x0, [x1, #0x178]
   203ac:      	ldr	x0, [x19, #0x50e0]
   203b0:      	str	x0, [x1, #0x180]
   203b4:      	ldr	x0, [x19, #0x50e8]
   203b8:      	str	x0, [x1, #0x188]
   203bc:      	ldr	x0, [x19, #0x50f0]
   203c0:      	str	x0, [x1, #0x190]
   203c4:      	ldr	x0, [x19, #0x50f8]
   203c8:      	str	x0, [x1, #0x198]
   203cc:      	ldr	x0, [x19, #0x5100]
   203d0:      	str	x0, [x1, #0x1a0]
   203d4:      	ldr	x0, [x19, #0x52a8]
   203d8:      	str	x0, [x1, #0x348]
   203dc:      	ldr	x0, [x19, #0x52b0]
   203e0:      	str	x0, [x1, #0x350]
   203e4:      	ldr	x0, [x19, #0x52b8]
   203e8:      	str	x0, [x1, #0x358]
   203ec:      	ldr	x0, [x19, #0x52c0]
   203f0:      	ldr	x2, [sp, #0x198]
   203f4:      	str	x0, [x2, #0x360]
   203f8:      	ldr	x0, [x19, #0x52c8]
   203fc:      	ldr	x5, [sp, #0x198]
   20400:      	str	x0, [x5, #0x368]
   20404:      	ldr	x0, [x19, #0x52d0]
   20408:      	ldr	x8, [sp, #0x198]
   2040c:      	str	x0, [x8, #0x370]
   20410:      	ldr	x0, [x19, #0x52d8]
   20414:      	ldr	x11, [sp, #0x198]
   20418:      	str	x0, [x11, #0x378]
   2041c:      	ldr	x0, [x19, #0x52e0]
   20420:      	ldr	x14, [sp, #0x198]
   20424:      	str	x0, [x14, #0x380]
   20428:      	ldr	x0, [x19, #0x52e8]
   2042c:      	str	x0, [x1, #0x388]
   20430:      	ldr	x0, [x19, #0x55d8]
   20434:      	str	x0, [x1, #0x678]
   20438:      	ldr	x0, [x19, #0x55e0]
   2043c:      	str	x0, [x1, #0x680]
   20440:      	ldr	x0, [x19, #0x55e8]
   20444:      	str	x0, [x1, #0x688]
   20448:      	ldr	x0, [x19, #0x55f0]
   2044c:      	str	x0, [x1, #0x690]
   20450:      	ldr	x0, [x19, #0x55f8]
   20454:      	str	x0, [x1, #0x698]
   20458:      	ldr	x0, [x19, #0x5600]
   2045c:      	str	x0, [x1, #0x6a0]
   20460:      	ldr	x0, [x19, #0x5608]
   20464:      	str	x0, [x1, #0x6a8]
   20468:      	ldr	x0, [x19, #0x5610]
   2046c:      	str	x0, [x1, #0x6b0]
   20470:      	ldr	x0, [x19, #0x57a0]
   20474:      	str	x0, [x1, #0x840]
   20478:      	ldr	x0, [x19, #0x57a8]
   2047c:      	str	x0, [x1, #0x848]
   20480:      	ldr	x0, [x19, #0x57b0]
   20484:      	str	x0, [x1, #0x850]
   20488:      	ldr	x0, [x19, #0x57b8]
   2048c:      	str	x0, [x1, #0x858]
   20490:      	ldr	x0, [x19, #0x57c0]
   20494:      	str	x0, [x1, #0x860]
   20498:      	ldr	x0, [x19, #0x57c8]
   2049c:      	str	x0, [x1, #0x868]
   204a0:      	ldr	x0, [x19, #0x57d0]
   204a4:      	str	x0, [x1, #0x870]
   204a8:      	ldr	x0, [x19, #0x57d8]
   204ac:      	str	x0, [x2, #0x878]
   204b0:      	ldr	x0, [x19, #0x5bb0]
   204b4:      	str	x0, [x5, #0xc50]
   204b8:      	ldr	x0, [x19, #0x5bb8]
   204bc:      	str	x0, [x8, #0xc58]
   204c0:      	ldr	x0, [x19, #0x5bc0]
   204c4:      	str	x0, [x11, #0xc60]
   204c8:      	ldr	x0, [x19, #0x5bc8]
   204cc:      	str	x0, [x14, #0xc68]
   204d0:      	ldr	x0, [x19, #0x5bd0]
   204d4:      	str	x0, [x1, #0xc70]
   204d8:      	ldr	x0, [x19, #0x5bd8]
   204dc:      	str	x0, [x1, #0xc78]
   204e0:      	mov	x0, #0x0                ; =0
   204e4:      	str	x0, [x1, #0xc80]
   204e8:      	ldr	x1, [x19, #0x5be8]
   204ec:      	str	x1, [x2, #0xc88]
   204f0:      	ldr	x1, [x19, #0x5bf0]
   204f4:      	str	x1, [x2, #0xc90]
   204f8:      	ldr	x1, [sp, #0x198]
   204fc:      	str	x0, [x1, #0xc98]
   20500:      	ldr	x1, [x19, #0x5c00]
   20504:      	str	x1, [x2, #0xca0]
   20508:      	ldr	x1, [x19, #0x5c08]
   2050c:      	str	x1, [x2, #0xca8]
   20510:      	ldr	x1, [sp, #0x198]
   20514:      	str	x0, [x1, #0xcb0]
   20518:      	ldr	x0, [x19, #0x5c18]
   2051c:      	str	x0, [x1, #0xcb8]
   20520:      	ldr	x0, [x19, #0x5c20]
   20524:      	str	x0, [x1, #0xcc0]
   20528:      	mov	x1, #0x607              ; =1543
   2052c:      	mov	x2, #-0x9               ; =-9
   20530:      	ldr	x21, [sp, #0x1a8]
   20534:      	ldur	x0, [sp, #0x8]
   20538:      	mov	x5, x20
   2053c:      	ldr	x6, [sp, #0x1a0]
   20540:      	blr	x21
   20544:      	cmp	x0, #0x0
   20548:      	b.ne	0x232ec <_mech_canonical_program_entry_v1_numeric_1282+0x616c>
   2054c:      	mov	x0, #0x3                ; =3
   20550:      	ldr	x15, [sp, #0x190]
   20554:      	mov	x21, x0
   20558:      	cmp	x15, #0x2
   2055c:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   20560:      	mov	x5, #0x0                ; =0
   20564:      	ldr	x3, [sp, #0x198]
   20568:      	str	x5, [x3]
   2056c:      	ldr	x9, [x19, #0x1cc8]
   20570:      	str	x9, [x3, #0x8]
   20574:      	mov	x1, #0x607              ; =1543
   20578:      	ldur	x0, [sp, #0x8]
   2057c:      	ldr	x6, [sp, #0x1a0]
   20580:      	ldr	x21, [sp, #0x1a8]
   20584:      	mov	x4, x20
   20588:      	mov	x2, x5
   2058c:      	blr	x21
   20590:      	cmp	x0, #0x0
   20594:      	b.ne	0x232f4 <_mech_canonical_program_entry_v1_numeric_1282+0x6174>
   20598:      	mov	x0, #0x3                ; =3
   2059c:      	mov	x21, x0
   205a0:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   205a4:      	ldr	x0, [sp, #0x118]
   205a8:      	ldr	x27, [x0, x1, lsl #3]
   205ac:      	ldr	x0, [sp, #0x110]
   205b0:      	cmp	x4, x0
   205b4:      	b.lo	0x20828 <_mech_canonical_program_entry_v1_numeric_1282+0x36a8>
   205b8:      	b	0x232fc <_mech_canonical_program_entry_v1_numeric_1282+0x617c>
   205bc:      	ldr	x3, [x19, #0x4c68]
   205c0:      	ldr	x4, [x19, #0x4c70]
   205c4:      	mov	x10, #0x0               ; =0
   205c8:      	str	x10, [x19, #0x4c60]
   205cc:      	mov	x0, #0x3                ; =3
   205d0:      	ldr	x15, [sp, #0x190]
   205d4:      	mov	x21, x0
   205d8:      	cmp	x15, #0x19a
   205dc:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   205e0:      	ldr	x14, [x19, #0x4f70]
   205e4:      	ldr	x0, [sp, #0x198]
   205e8:      	str	x14, [x0, #0x10]
   205ec:      	ldr	x15, [x19, #0x4f78]
   205f0:      	str	x15, [x0, #0x18]
   205f4:      	ldr	x0, [x19, #0x5a20]
   205f8:      	ldr	x1, [sp, #0x198]
   205fc:      	str	x0, [x1, #0xac0]
   20600:      	ldr	x0, [sp, #0x198]
   20604:      	str	x14, [x0, #0x10]
   20608:      	str	x15, [x0, #0x18]
   2060c:      	ldr	x0, [x19, #0x50c0]
   20610:      	str	x0, [x1, #0x160]
   20614:      	ldr	x0, [x19, #0x50c8]
   20618:      	str	x0, [x1, #0x168]
   2061c:      	ldr	x0, [x19, #0x50d0]
   20620:      	str	x0, [x1, #0x170]
   20624:      	ldr	x0, [x19, #0x50d8]
   20628:      	str	x0, [x1, #0x178]
   2062c:      	ldr	x0, [x19, #0x50e0]
   20630:      	str	x0, [x1, #0x180]
   20634:      	ldr	x0, [x19, #0x50e8]
   20638:      	ldr	x5, [sp, #0x198]
   2063c:      	str	x0, [x5, #0x188]
   20640:      	ldr	x0, [x19, #0x50f0]
   20644:      	ldr	x7, [sp, #0x198]
   20648:      	str	x0, [x7, #0x190]
   2064c:      	ldr	x0, [x19, #0x50f8]
   20650:      	ldr	x10, [sp, #0x198]
   20654:      	str	x0, [x10, #0x198]
   20658:      	ldr	x0, [x19, #0x5100]
   2065c:      	ldr	x13, [sp, #0x198]
   20660:      	str	x0, [x13, #0x1a0]
   20664:      	ldr	x0, [x19, #0x52a8]
   20668:      	str	x0, [x1, #0x348]
   2066c:      	ldr	x0, [x19, #0x52b0]
   20670:      	str	x0, [x1, #0x350]
   20674:      	ldr	x0, [x19, #0x52b8]
   20678:      	str	x0, [x1, #0x358]
   2067c:      	ldr	x0, [x19, #0x52c0]
   20680:      	str	x0, [x1, #0x360]
   20684:      	ldr	x0, [x19, #0x52c8]
   20688:      	str	x0, [x1, #0x368]
   2068c:      	ldr	x0, [x19, #0x52d0]
   20690:      	str	x0, [x1, #0x370]
   20694:      	ldr	x0, [x19, #0x52d8]
   20698:      	str	x0, [x1, #0x378]
   2069c:      	ldr	x0, [x19, #0x52e0]
   206a0:      	str	x0, [x1, #0x380]
   206a4:      	ldr	x0, [x19, #0x52e8]
   206a8:      	str	x0, [x1, #0x388]
   206ac:      	ldr	x0, [x19, #0x55d8]
   206b0:      	str	x0, [x1, #0x678]
   206b4:      	ldr	x0, [x19, #0x55e0]
   206b8:      	str	x0, [x1, #0x680]
   206bc:      	ldr	x0, [x19, #0x55e8]
   206c0:      	str	x0, [x1, #0x688]
   206c4:      	ldr	x0, [x19, #0x55f0]
   206c8:      	str	x0, [x1, #0x690]
   206cc:      	ldr	x0, [x19, #0x55f8]
   206d0:      	str	x0, [x1, #0x698]
   206d4:      	ldr	x0, [x19, #0x5600]
   206d8:      	str	x0, [x1, #0x6a0]
   206dc:      	ldr	x0, [x19, #0x5608]
   206e0:      	str	x0, [x1, #0x6a8]
   206e4:      	ldr	x0, [x19, #0x5610]
   206e8:      	str	x0, [x1, #0x6b0]
   206ec:      	ldr	x0, [x19, #0x57a0]
   206f0:      	str	x0, [x5, #0x840]
   206f4:      	ldr	x0, [x19, #0x57a8]
   206f8:      	str	x0, [x7, #0x848]
   206fc:      	ldr	x0, [x19, #0x57b0]
   20700:      	str	x0, [x10, #0x850]
   20704:      	ldr	x0, [x19, #0x57b8]
   20708:      	str	x0, [x13, #0x858]
   2070c:      	ldr	x0, [x19, #0x57c0]
   20710:      	str	x0, [x1, #0x860]
   20714:      	ldr	x0, [x19, #0x57c8]
   20718:      	str	x0, [x1, #0x868]
   2071c:      	ldr	x0, [x19, #0x57d0]
   20720:      	str	x0, [x1, #0x870]
   20724:      	ldr	x0, [x19, #0x57d8]
   20728:      	str	x0, [x1, #0x878]
   2072c:      	ldr	x0, [x19, #0x5bb0]
   20730:      	str	x0, [x1, #0xc50]
   20734:      	ldr	x0, [x19, #0x5bb8]
   20738:      	str	x0, [x1, #0xc58]
   2073c:      	ldr	x0, [x19, #0x5bc0]
   20740:      	str	x0, [x1, #0xc60]
   20744:      	ldr	x0, [x19, #0x5bc8]
   20748:      	str	x0, [x1, #0xc68]
   2074c:      	ldr	x0, [x19, #0x5bd0]
   20750:      	str	x0, [x1, #0xc70]
   20754:      	ldr	x0, [x19, #0x5bd8]
   20758:      	str	x0, [x1, #0xc78]
   2075c:      	mov	x0, #0x0                ; =0
   20760:      	str	x0, [x1, #0xc80]
   20764:      	ldr	x1, [x19, #0x5be8]
   20768:      	ldr	x2, [sp, #0x198]
   2076c:      	str	x1, [x2, #0xc88]
   20770:      	ldr	x1, [x19, #0x5bf0]
   20774:      	str	x1, [x2, #0xc90]
   20778:      	ldr	x1, [sp, #0x198]
   2077c:      	str	x0, [x1, #0xc98]
   20780:      	ldr	x1, [x19, #0x5c00]
   20784:      	str	x1, [x2, #0xca0]
   20788:      	ldr	x1, [x19, #0x5c08]
   2078c:      	str	x1, [x2, #0xca8]
   20790:      	ldr	x1, [sp, #0x198]
   20794:      	str	x0, [x1, #0xcb0]
   20798:      	ldr	x5, [x19, #0x5c18]
   2079c:      	str	x5, [x2, #0xcb8]
   207a0:      	ldr	x5, [x19, #0x5c20]
   207a4:      	ldr	x6, [sp, #0x198]
   207a8:      	str	x5, [x6, #0xcc0]
   207ac:      	mov	x1, #0x609              ; =1545
   207b0:      	mov	x2, #-0x9               ; =-9
   207b4:      	ldr	x21, [sp, #0x1a8]
   207b8:      	ldur	x0, [sp, #0x8]
   207bc:      	mov	x5, x25
   207c0:      	ldr	x6, [sp, #0x1a0]
   207c4:      	blr	x21
   207c8:      	cmp	x0, #0x0
   207cc:      	b.ne	0x23474 <_mech_canonical_program_entry_v1_numeric_1282+0x62f4>
   207d0:      	mov	x0, #0x3                ; =3
   207d4:      	ldr	x15, [sp, #0x190]
   207d8:      	mov	x21, x0
   207dc:      	cmp	x15, #0x2
   207e0:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   207e4:      	mov	x5, #0x0                ; =0
   207e8:      	ldr	x3, [sp, #0x198]
   207ec:      	str	x5, [x3]
   207f0:      	ldr	x13, [x19, #0x1cd8]
   207f4:      	str	x13, [x3, #0x8]
   207f8:      	mov	x1, #0x609              ; =1545
   207fc:      	ldur	x0, [sp, #0x8]
   20800:      	ldr	x6, [sp, #0x1a0]
   20804:      	ldr	x21, [sp, #0x1a8]
   20808:      	mov	x4, x25
   2080c:      	mov	x2, x5
   20810:      	blr	x21
   20814:      	cmp	x0, #0x0
   20818:      	b.ne	0x2347c <_mech_canonical_program_entry_v1_numeric_1282+0x62fc>
   2081c:      	mov	x0, #0x3                ; =3
   20820:      	mov	x21, x0
   20824:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   20828:      	ldr	x6, [sp, #0x118]
   2082c:      	ldr	x13, [x6, x4, lsl #3]
   20830:      	mov	w0, #0x2646             ; =9798
   20834:      	movk	w0, #0x1, lsl #16
   20838:      	sub	x3, x3, x0
   2083c:      	mov	x2, #0x0                ; =0
   20840:      	stur	x2, [sp, #0x58]
   20844:      	ldur	x0, [sp, #0x80]
   20848:      	ldur	x1, [sp, #0x10]
   2084c:      	ldur	x9, [sp, #0x78]
   20850:      	ldur	x10, [sp, #0x70]
   20854:      	ldur	x14, [sp, #0x68]
   20858:      	mov	w2, #0xcb86             ; =52102
   2085c:      	movk	w2, #0x2, lsl #16
   20860:      	cmp	x3, x2
   20864:      	cset	x2, hs
   20868:      	ldur	x4, [sp, #0xf8]
   2086c:      	and	w2, w2, w4
   20870:      	uxtb	w2, w2
   20874:      	cbnz	x2, 0x20c88 <_mech_canonical_program_entry_v1_numeric_1282+0x3b08>
   20878:      	mov	x5, #0x0                ; =0
   2087c:      	str	x5, [x19, #0x18]
   20880:      	str	x26, [x19, #0x20]
   20884:      	mov	x2, #0x1                ; =1
   20888:      	str	x2, [x19, #0x30]
   2088c:      	mov	x4, #0x101010101010101  ; =72340172838076673
   20890:      	str	x4, [x19, #0x38]
   20894:      	mov	x20, #0x2               ; =2
   20898:      	str	x20, [x19, #0x40]
   2089c:      	mov	x4, #0x3                ; =3
   208a0:      	str	x4, [x19, #0x48]
   208a4:      	mov	x4, #0x4                ; =4
   208a8:      	str	x4, [x19, #0x50]
   208ac:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   208b0:      	str	x4, [x19, #0x78]
   208b4:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   208b8:      	str	x4, [x19, #0x88]
   208bc:      	mov	x4, #0x38               ; =56
   208c0:      	str	x4, [x19, #0x90]
   208c4:      	mov	x4, #0x3a               ; =58
   208c8:      	str	x4, [x19, #0x98]
   208cc:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   208d0:      	str	x4, [x19, #0xb0]
   208d4:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   208d8:      	str	x4, [x19, #0xb8]
   208dc:      	str	x5, [x19, #0x188]
   208e0:      	str	x2, [x19, #0x190]
   208e4:      	str	x22, [x19, #0x17a0]
   208e8:      	str	x23, [x19, #0x17a8]
   208ec:      	ldur	x25, [sp, #0xf0]
   208f0:      	uxtb	w4, w25
   208f4:      	str	x4, [x19, #0x17b8]
   208f8:      	str	x15, [x19, #0x1c70]
   208fc:      	str	x12, [x19, #0x1c78]
   20900:      	str	x22, [x19, #0x1c80]
   20904:      	str	x24, [x19, #0x1ca8]
   20908:      	str	x28, [x19, #0x4c60]
   2090c:      	str	x3, [x19, #0x4c68]
   20910:      	ldur	x4, [sp, #0x98]
   20914:      	str	x4, [x19, #0x4c70]
   20918:      	str	x22, [x19, #0x4f70]
   2091c:      	str	x23, [x19, #0x4f78]
   20920:      	str	x15, [x19, #0x55d8]
   20924:      	str	x12, [x19, #0x55e0]
   20928:      	str	x22, [x19, #0x55e8]
   2092c:      	ldur	x24, [sp, #0x10]
   20930:      	str	x24, [x19, #0x55f0]
   20934:      	ldur	x26, [sp, #0x68]
   20938:      	str	x26, [x19, #0x55f8]
   2093c:      	ldur	x4, [sp, #0x70]
   20940:      	str	x4, [x19, #0x5600]
   20944:      	ldur	x24, [sp, #0x78]
   20948:      	str	x24, [x19, #0x5608]
   2094c:      	ldur	x26, [sp, #0x80]
   20950:      	str	x26, [x19, #0x5610]
   20954:      	ldur	x24, [sp, #0x10]
   20958:      	str	x24, [x19, #0x5680]
   2095c:      	ldur	x26, [sp, #0x68]
   20960:      	str	x26, [x19, #0x5688]
   20964:      	str	x4, [x19, #0x5690]
   20968:      	ldur	x24, [sp, #0x78]
   2096c:      	str	x24, [x19, #0x5698]
   20970:      	ldur	x26, [sp, #0x80]
   20974:      	str	x26, [x19, #0x56a0]
   20978:      	str	x27, [x19, #0x57a0]
   2097c:      	str	x13, [x19, #0x57a8]
   20980:      	str	x22, [x19, #0x57b0]
   20984:      	str	x1, [x19, #0x57b8]
   20988:      	str	x14, [x19, #0x57c0]
   2098c:      	str	x10, [x19, #0x57c8]
   20990:      	str	x9, [x19, #0x57d0]
   20994:      	str	x0, [x19, #0x57d8]
   20998:      	ldur	x14, [sp, #0x60]
   2099c:      	str	x14, [x19, #0x5a20]
   209a0:      	add	x14, x11, #0x1
   209a4:      	str	x14, [x19, #0x5bb0]
   209a8:      	ldur	x26, [sp, #0xa0]
   209ac:      	str	x26, [x19, #0x5bb8]
   209b0:      	ldur	x7, [sp, #0xa8]
   209b4:      	str	x7, [x19, #0x5bc0]
   209b8:      	ldur	x4, [sp, #0x90]
   209bc:      	sub	x0, x4, x3
   209c0:      	mov	w1, #0xc87e             ; =51326
   209c4:      	movk	w1, #0x1, lsl #16
   209c8:      	msub	x0, x14, x1, x0
   209cc:      	str	x0, [x19, #0x5bc8]
   209d0:      	str	x5, [x19, #0x5bd0]
   209d4:      	str	x5, [x19, #0x5bd8]
   209d8:      	ldur	x8, [sp, #0xb0]
   209dc:      	str	x8, [x19, #0x5be8]
   209e0:      	ldur	x4, [sp, #0xb8]
   209e4:      	str	x4, [x19, #0x5bf0]
   209e8:      	str	x2, [x19, #0x5c00]
   209ec:      	ldur	x10, [sp, #0x50]
   209f0:      	str	x10, [x19, #0x5c08]
   209f4:      	str	x2, [x19, #0x5c18]
   209f8:      	ldur	x5, [sp, #0x58]
   209fc:      	str	x5, [x19, #0x5c20]
   20a00:      	ldr	x0, [x19, #0x4c60]
   20a04:      	cmp	x0, #0x0
   20a08:      	b.eq	0x20c60 <_mech_canonical_program_entry_v1_numeric_1282+0x3ae0>
   20a0c:      	ldr	x3, [x19, #0x4c68]
   20a10:      	ldr	x4, [x19, #0x4c70]
   20a14:      	mov	x0, #0x0                ; =0
   20a18:      	str	x0, [x19, #0x4c60]
   20a1c:      	mov	x0, #0x3                ; =3
   20a20:      	ldr	x15, [sp, #0x190]
   20a24:      	mov	x21, x0
   20a28:      	cmp	x15, #0x19a
   20a2c:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   20a30:      	ldr	x0, [x19, #0x4f70]
   20a34:      	ldr	x1, [sp, #0x198]
   20a38:      	str	x0, [x1, #0x10]
   20a3c:      	ldr	x1, [x19, #0x4f78]
   20a40:      	ldr	x2, [sp, #0x198]
   20a44:      	str	x1, [x2, #0x18]
   20a48:      	ldr	x2, [x19, #0x5a20]
   20a4c:      	ldr	x5, [sp, #0x198]
   20a50:      	str	x2, [x5, #0xac0]
   20a54:      	ldr	x2, [x19, #0x5680]
   20a58:      	str	x2, [x5, #0x720]
   20a5c:      	ldr	x2, [x19, #0x5688]
   20a60:      	str	x2, [x5, #0x728]
   20a64:      	ldr	x2, [x19, #0x5690]
   20a68:      	str	x2, [x5, #0x730]
   20a6c:      	ldr	x2, [x19, #0x5698]
   20a70:      	str	x2, [x5, #0x738]
   20a74:      	ldr	x2, [x19, #0x56a0]
   20a78:      	str	x2, [x5, #0x740]
   20a7c:      	ldr	x2, [sp, #0x198]
   20a80:      	str	x0, [x2, #0x10]
   20a84:      	ldr	x0, [sp, #0x198]
   20a88:      	str	x1, [x0, #0x18]
   20a8c:      	ldr	x0, [x19, #0x50c0]
   20a90:      	ldr	x1, [sp, #0x198]
   20a94:      	str	x0, [x1, #0x160]
   20a98:      	ldr	x0, [x19, #0x50c8]
   20a9c:      	str	x0, [x1, #0x168]
   20aa0:      	ldr	x0, [x19, #0x50d0]
   20aa4:      	str	x0, [x1, #0x170]
   20aa8:      	ldr	x0, [x19, #0x50d8]
   20aac:      	str	x0, [x1, #0x178]
   20ab0:      	ldr	x0, [x19, #0x50e0]
   20ab4:      	str	x0, [x1, #0x180]
   20ab8:      	ldr	x0, [x19, #0x50e8]
   20abc:      	str	x0, [x1, #0x188]
   20ac0:      	ldr	x0, [x19, #0x50f0]
   20ac4:      	str	x0, [x1, #0x190]
   20ac8:      	ldr	x0, [x19, #0x50f8]
   20acc:      	str	x0, [x5, #0x198]
   20ad0:      	ldr	x0, [x19, #0x5100]
   20ad4:      	ldr	x7, [sp, #0x198]
   20ad8:      	str	x0, [x7, #0x1a0]
   20adc:      	ldr	x0, [x19, #0x52a8]
   20ae0:      	ldr	x10, [sp, #0x198]
   20ae4:      	str	x0, [x10, #0x348]
   20ae8:      	ldr	x0, [x19, #0x52b0]
   20aec:      	ldr	x13, [sp, #0x198]
   20af0:      	str	x0, [x13, #0x350]
   20af4:      	ldr	x0, [x19, #0x52b8]
   20af8:      	str	x0, [x1, #0x358]
   20afc:      	ldr	x0, [x19, #0x52c0]
   20b00:      	str	x0, [x1, #0x360]
   20b04:      	ldr	x0, [x19, #0x52c8]
   20b08:      	str	x0, [x1, #0x368]
   20b0c:      	ldr	x0, [x19, #0x52d0]
   20b10:      	str	x0, [x1, #0x370]
   20b14:      	ldr	x0, [x19, #0x52d8]
   20b18:      	str	x0, [x1, #0x378]
   20b1c:      	ldr	x0, [x19, #0x52e0]
   20b20:      	str	x0, [x1, #0x380]
   20b24:      	ldr	x0, [x19, #0x52e8]
   20b28:      	str	x0, [x1, #0x388]
   20b2c:      	ldr	x0, [x19, #0x55d8]
   20b30:      	str	x0, [x1, #0x678]
   20b34:      	ldr	x0, [x19, #0x55e0]
   20b38:      	str	x0, [x1, #0x680]
   20b3c:      	ldr	x0, [x19, #0x55e8]
   20b40:      	str	x0, [x1, #0x688]
   20b44:      	ldr	x1, [x19, #0x55f0]
   20b48:      	ldr	x0, [sp, #0x198]
   20b4c:      	str	x1, [x0, #0x690]
   20b50:      	ldr	x2, [x19, #0x55f8]
   20b54:      	str	x2, [x0, #0x698]
   20b58:      	ldr	x5, [x19, #0x5600]
   20b5c:      	str	x5, [x0, #0x6a0]
   20b60:      	ldr	x5, [x19, #0x5608]
   20b64:      	str	x5, [x0, #0x6a8]
   20b68:      	ldr	x5, [x19, #0x5610]
   20b6c:      	str	x5, [x0, #0x6b0]
   20b70:      	ldr	x6, [x19, #0x57a0]
   20b74:      	str	x6, [x0, #0x840]
   20b78:      	ldr	x7, [x19, #0x57a8]
   20b7c:      	ldr	x1, [sp, #0x198]
   20b80:      	str	x7, [x1, #0x848]
   20b84:      	ldr	x8, [x19, #0x57b0]
   20b88:      	ldr	x5, [sp, #0x198]
   20b8c:      	str	x8, [x5, #0x850]
   20b90:      	ldr	x9, [x19, #0x57b8]
   20b94:      	ldr	x7, [sp, #0x198]
   20b98:      	str	x9, [x7, #0x858]
   20b9c:      	ldr	x10, [x19, #0x57c0]
   20ba0:      	ldr	x11, [sp, #0x198]
   20ba4:      	str	x10, [x11, #0x860]
   20ba8:      	ldr	x11, [x19, #0x57c8]
   20bac:      	str	x11, [x13, #0x868]
   20bb0:      	ldr	x12, [x19, #0x57d0]
   20bb4:      	str	x12, [x0, #0x870]
   20bb8:      	ldr	x13, [x19, #0x57d8]
   20bbc:      	str	x13, [x0, #0x878]
   20bc0:      	ldr	x14, [x19, #0x5bb0]
   20bc4:      	str	x14, [x0, #0xc50]
   20bc8:      	ldr	x15, [x19, #0x5bb8]
   20bcc:      	str	x15, [x0, #0xc58]
   20bd0:      	ldr	x0, [x19, #0x5bc0]
   20bd4:      	str	x0, [x1, #0xc60]
   20bd8:      	ldr	x0, [x19, #0x5bc8]
   20bdc:      	str	x0, [x1, #0xc68]
   20be0:      	ldr	x0, [x19, #0x5bd0]
   20be4:      	str	x0, [x1, #0xc70]
   20be8:      	ldr	x0, [x19, #0x5bd8]
   20bec:      	str	x0, [x1, #0xc78]
   20bf0:      	mov	x0, #0x0                ; =0
   20bf4:      	str	x0, [x1, #0xc80]
   20bf8:      	ldr	x1, [x19, #0x5be8]
   20bfc:      	ldr	x2, [sp, #0x198]
   20c00:      	str	x1, [x2, #0xc88]
   20c04:      	ldr	x1, [x19, #0x5bf0]
   20c08:      	str	x1, [x2, #0xc90]
   20c0c:      	ldr	x1, [sp, #0x198]
   20c10:      	str	x0, [x1, #0xc98]
   20c14:      	ldr	x1, [x19, #0x5c00]
   20c18:      	str	x1, [x2, #0xca0]
   20c1c:      	ldr	x1, [x19, #0x5c08]
   20c20:      	str	x1, [x2, #0xca8]
   20c24:      	ldr	x1, [sp, #0x198]
   20c28:      	str	x0, [x1, #0xcb0]
   20c2c:      	ldr	x0, [x19, #0x5c18]
   20c30:      	str	x0, [x1, #0xcb8]
   20c34:      	ldr	x0, [x19, #0x5c20]
   20c38:      	str	x0, [x1, #0xcc0]
   20c3c:      	mov	x1, #0x611              ; =1553
   20c40:      	mov	x2, #-0x9               ; =-9
   20c44:      	mov	x5, #0x1                ; =1
   20c48:      	ldur	x0, [sp, #0x8]
   20c4c:      	ldr	x6, [sp, #0x1a0]
   20c50:      	ldr	x21, [sp, #0x1a8]
   20c54:      	blr	x21
   20c58:      	cmp	x0, #0x0
   20c5c:      	b.ne	0x23484 <_mech_canonical_program_entry_v1_numeric_1282+0x6304>
   20c60:      	mov	x0, #0x0                ; =0
   20c64:      	mov	x1, #0x5                ; =5
   20c68:      	add	sp, sp, #0x1c0
   20c6c:      	ldp	x19, x20, [sp], #0x10
   20c70:      	ldp	x21, x22, [sp], #0x10
   20c74:      	ldp	x23, x24, [sp], #0x10
   20c78:      	ldp	x25, x26, [sp], #0x10
   20c7c:      	ldp	x27, x28, [sp], #0x10
   20c80:      	ldp	x29, x30, [sp], #0x10
   20c84:      	retab
   20c88:      	cmp	x27, x13
   20c8c:      	cset	x4, lo
   20c90:      	cmp	x27, x13
   20c94:      	b.lo	0x20ca0 <_mech_canonical_program_entry_v1_numeric_1282+0x3b20>
   20c98:      	mov	x2, #0x0                ; =0
   20c9c:      	b	0x20f2c <_mech_canonical_program_entry_v1_numeric_1282+0x3dac>
   20ca0:      	ldr	x2, [sp, #0x100]
   20ca4:      	cmp	x27, x2
   20ca8:      	b.lo	0x20f24 <_mech_canonical_program_entry_v1_numeric_1282+0x3da4>
   20cac:      	b	0x2348c <_mech_canonical_program_entry_v1_numeric_1282+0x630c>
   20cb0:      	ldr	x3, [x19, #0x4c68]
   20cb4:      	ldr	x4, [x19, #0x4c70]
   20cb8:      	mov	x0, #0x0                ; =0
   20cbc:      	str	x0, [x19, #0x4c60]
   20cc0:      	mov	x0, #0x3                ; =3
   20cc4:      	ldr	x15, [sp, #0x190]
   20cc8:      	mov	x21, x0
   20ccc:      	cmp	x15, #0x19a
   20cd0:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   20cd4:      	ldr	x0, [x19, #0x4f70]
   20cd8:      	ldr	x7, [sp, #0x198]
   20cdc:      	str	x0, [x7, #0x10]
   20ce0:      	ldr	x1, [x19, #0x4f78]
   20ce4:      	ldr	x10, [sp, #0x198]
   20ce8:      	str	x1, [x10, #0x18]
   20cec:      	ldr	x2, [x19, #0x5a20]
   20cf0:      	ldr	x13, [sp, #0x198]
   20cf4:      	str	x2, [x13, #0xac0]
   20cf8:      	ldr	x15, [sp, #0x198]
   20cfc:      	str	x0, [x15, #0x10]
   20d00:      	ldr	x0, [sp, #0x198]
   20d04:      	str	x1, [x0, #0x18]
   20d08:      	ldr	x2, [x19, #0x50c0]
   20d0c:      	str	x2, [x0, #0x160]
   20d10:      	ldr	x5, [x19, #0x50c8]
   20d14:      	str	x5, [x0, #0x168]
   20d18:      	ldr	x5, [x19, #0x50d0]
   20d1c:      	str	x5, [x0, #0x170]
   20d20:      	ldr	x5, [x19, #0x50d8]
   20d24:      	str	x5, [x0, #0x178]
   20d28:      	ldr	x6, [x19, #0x50e0]
   20d2c:      	str	x6, [x0, #0x180]
   20d30:      	ldr	x7, [x19, #0x50e8]
   20d34:      	str	x7, [x0, #0x188]
   20d38:      	ldr	x8, [x19, #0x50f0]
   20d3c:      	str	x8, [x0, #0x190]
   20d40:      	ldr	x9, [x19, #0x50f8]
   20d44:      	str	x9, [x0, #0x198]
   20d48:      	ldr	x10, [x19, #0x5100]
   20d4c:      	str	x10, [x0, #0x1a0]
   20d50:      	ldr	x11, [x19, #0x52a8]
   20d54:      	str	x11, [x0, #0x348]
   20d58:      	ldr	x12, [x19, #0x52b0]
   20d5c:      	str	x12, [x0, #0x350]
   20d60:      	ldr	x13, [x19, #0x52b8]
   20d64:      	str	x13, [x0, #0x358]
   20d68:      	ldr	x14, [x19, #0x52c0]
   20d6c:      	str	x14, [x0, #0x360]
   20d70:      	ldr	x15, [x19, #0x52c8]
   20d74:      	str	x15, [x0, #0x368]
   20d78:      	ldr	x0, [x19, #0x52d0]
   20d7c:      	ldr	x1, [sp, #0x198]
   20d80:      	str	x0, [x1, #0x370]
   20d84:      	ldr	x0, [x19, #0x52d8]
   20d88:      	ldr	x2, [sp, #0x198]
   20d8c:      	str	x0, [x2, #0x378]
   20d90:      	ldr	x0, [x19, #0x52e0]
   20d94:      	ldr	x5, [sp, #0x198]
   20d98:      	str	x0, [x5, #0x380]
   20d9c:      	ldr	x0, [x19, #0x52e8]
   20da0:      	ldr	x8, [sp, #0x198]
   20da4:      	str	x0, [x8, #0x388]
   20da8:      	ldr	x0, [x19, #0x55d8]
   20dac:      	ldr	x11, [sp, #0x198]
   20db0:      	str	x0, [x11, #0x678]
   20db4:      	ldr	x0, [x19, #0x55e0]
   20db8:      	ldr	x14, [sp, #0x198]
   20dbc:      	str	x0, [x14, #0x680]
   20dc0:      	ldr	x0, [x19, #0x55e8]
   20dc4:      	str	x0, [x1, #0x688]
   20dc8:      	ldr	x0, [x19, #0x55f0]
   20dcc:      	str	x0, [x1, #0x690]
   20dd0:      	ldr	x0, [x19, #0x55f8]
   20dd4:      	str	x0, [x1, #0x698]
   20dd8:      	ldr	x0, [x19, #0x5600]
   20ddc:      	str	x0, [x1, #0x6a0]
   20de0:      	ldr	x0, [x19, #0x5608]
   20de4:      	str	x0, [x1, #0x6a8]
   20de8:      	ldr	x0, [x19, #0x5610]
   20dec:      	str	x0, [x1, #0x6b0]
   20df0:      	ldr	x0, [x19, #0x57a0]
   20df4:      	str	x0, [x1, #0x840]
   20df8:      	ldr	x0, [x19, #0x57a8]
   20dfc:      	str	x0, [x1, #0x848]
   20e00:      	ldr	x0, [x19, #0x57b0]
   20e04:      	str	x0, [x1, #0x850]
   20e08:      	ldr	x0, [x19, #0x57b8]
   20e0c:      	str	x0, [x1, #0x858]
   20e10:      	ldr	x0, [x19, #0x57c0]
   20e14:      	str	x0, [x1, #0x860]
   20e18:      	ldr	x0, [x19, #0x57c8]
   20e1c:      	str	x0, [x1, #0x868]
   20e20:      	ldr	x0, [x19, #0x57d0]
   20e24:      	str	x0, [x1, #0x870]
   20e28:      	ldr	x0, [x19, #0x57d8]
   20e2c:      	str	x0, [x1, #0x878]
   20e30:      	ldr	x0, [x19, #0x5bb0]
   20e34:      	str	x0, [x1, #0xc50]
   20e38:      	ldr	x0, [x19, #0x5bb8]
   20e3c:      	str	x0, [x1, #0xc58]
   20e40:      	ldr	x0, [x19, #0x5bc0]
   20e44:      	str	x0, [x2, #0xc60]
   20e48:      	ldr	x0, [x19, #0x5bc8]
   20e4c:      	str	x0, [x5, #0xc68]
   20e50:      	ldr	x0, [x19, #0x5bd0]
   20e54:      	str	x0, [x8, #0xc70]
   20e58:      	ldr	x0, [x19, #0x5bd8]
   20e5c:      	str	x0, [x11, #0xc78]
   20e60:      	mov	x0, #0x0                ; =0
   20e64:      	str	x0, [x14, #0xc80]
   20e68:      	ldr	x1, [x19, #0x5be8]
   20e6c:      	str	x1, [x2, #0xc88]
   20e70:      	ldr	x1, [x19, #0x5bf0]
   20e74:      	str	x1, [x2, #0xc90]
   20e78:      	ldr	x1, [sp, #0x198]
   20e7c:      	str	x0, [x1, #0xc98]
   20e80:      	ldr	x1, [x19, #0x5c00]
   20e84:      	str	x1, [x2, #0xca0]
   20e88:      	ldr	x1, [x19, #0x5c08]
   20e8c:      	str	x1, [x2, #0xca8]
   20e90:      	ldr	x1, [sp, #0x198]
   20e94:      	str	x0, [x1, #0xcb0]
   20e98:      	ldr	x0, [x19, #0x5c18]
   20e9c:      	str	x0, [x1, #0xcb8]
   20ea0:      	ldr	x0, [x19, #0x5c20]
   20ea4:      	str	x0, [x1, #0xcc0]
   20ea8:      	mov	x1, #0x621              ; =1569
   20eac:      	mov	x2, #-0x9               ; =-9
   20eb0:      	ldr	x21, [sp, #0x1a8]
   20eb4:      	ldur	x0, [sp, #0x8]
   20eb8:      	mov	x5, x20
   20ebc:      	ldr	x6, [sp, #0x1a0]
   20ec0:      	blr	x21
   20ec4:      	cmp	x0, #0x0
   20ec8:      	b.ne	0x23634 <_mech_canonical_program_entry_v1_numeric_1282+0x64b4>
   20ecc:      	mov	x0, #0x3                ; =3
   20ed0:      	ldr	x15, [sp, #0x190]
   20ed4:      	mov	x21, x0
   20ed8:      	cmp	x15, #0x2
   20edc:      	b.lo	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   20ee0:      	mov	x5, #0x0                ; =0
   20ee4:      	ldr	x3, [sp, #0x198]
   20ee8:      	str	x5, [x3]
   20eec:      	ldr	x0, [x19, #0x1d68]
   20ef0:      	str	x0, [x3, #0x8]
   20ef4:      	mov	x1, #0x621              ; =1569
   20ef8:      	ldur	x0, [sp, #0x8]
   20efc:      	ldr	x6, [sp, #0x1a0]
   20f00:      	ldr	x21, [sp, #0x1a8]
   20f04:      	mov	x4, x20
   20f08:      	mov	x2, x5
   20f0c:      	blr	x21
   20f10:      	cmp	x0, #0x0
   20f14:      	b.ne	0x2363c <_mech_canonical_program_entry_v1_numeric_1282+0x64bc>
   20f18:      	mov	x0, #0x3                ; =3
   20f1c:      	mov	x21, x0
   20f20:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   20f24:      	ldr	x5, [sp, #0x108]
   20f28:      	ldr	x2, [x5, x27, lsl #3]
   20f2c:      	mov	x6, #0x3ffffffffffffff  ; =288230376151711743
   20f30:      	stur	x6, [sp, #0xd0]
   20f34:      	eor	x7, x2, #0x3ffffffffffffff
   20f38:      	orr	x5, x7, #0xc00000000000000
   20f3c:      	cmp	x5, x0
   20f40:      	cset	x5, hi
   20f44:      	and	w4, w4, w5
   20f48:      	uxtb	w5, w4
   20f4c:      	tbnz	w5, #0x0, 0x20f68 <_mech_canonical_program_entry_v1_numeric_1282+0x3de8>
   20f50:      	mov	x2, x1
   20f54:      	mov	x4, x14
   20f58:      	mov	x6, x9
   20f5c:      	mov	x7, x10
   20f60:      	mov	x8, x0
   20f64:      	b	0x2102c <_mech_canonical_program_entry_v1_numeric_1282+0x3eac>
   20f68:      	cmp	x2, x22
   20f6c:      	b.ne	0x20f88 <_mech_canonical_program_entry_v1_numeric_1282+0x3e08>
   20f70:      	mov	x2, x1
   20f74:      	mov	x4, x14
   20f78:      	mov	x6, x9
   20f7c:      	mov	x7, x10
   20f80:      	mov	x8, x0
   20f84:      	b	0x2102c <_mech_canonical_program_entry_v1_numeric_1282+0x3eac>
   20f88:      	and	x4, x1, #0x3ffffffffffffff
   20f8c:      	eor	x2, x2, #0x3ffffffffffffff
   20f90:      	cmp	x2, x4
   20f94:      	cset	x4, ne
   20f98:      	and	x6, x14, #0x3ffffffffffffff
   20f9c:      	cmp	x2, x6
   20fa0:      	cset	x6, ne
   20fa4:      	and	w4, w4, w6
   20fa8:      	and	x6, x10, #0x3ffffffffffffff
   20fac:      	cmp	x2, x6
   20fb0:      	cset	x6, ne
   20fb4:      	and	w4, w4, w6
   20fb8:      	and	x6, x9, #0x3ffffffffffffff
   20fbc:      	cmp	x2, x6
   20fc0:      	cset	x2, ne
   20fc4:      	and	w2, w4, w2
   20fc8:      	uxtb	w2, w2
   20fcc:      	tbnz	w2, #0x0, 0x20fe8 <_mech_canonical_program_entry_v1_numeric_1282+0x3e68>
   20fd0:      	mov	x2, x1
   20fd4:      	mov	x4, x14
   20fd8:      	mov	x6, x9
   20fdc:      	mov	x7, x10
   20fe0:      	mov	x8, x0
   20fe4:      	b	0x2102c <_mech_canonical_program_entry_v1_numeric_1282+0x3eac>
   20fe8:      	orr	x4, x7, #0xc00000000000000
   20fec:      	cmp	x4, x1
   20ff0:      	csel	x2, x4, x1, hi
   20ff4:      	cmp	x4, x1
   20ff8:      	csel	x6, x4, x1, lo
   20ffc:      	cmp	x6, x14
   21000:      	csel	x4, x6, x14, hi
   21004:      	cmp	x6, x14
   21008:      	csel	x6, x6, x14, lo
   2100c:      	cmp	x6, x10
   21010:      	csel	x7, x6, x10, hi
   21014:      	cmp	x6, x10
   21018:      	csel	x8, x6, x10, lo
   2101c:      	cmp	x8, x9
   21020:      	csel	x6, x8, x9, hi
   21024:      	cmp	x8, x9
   21028:      	csel	x8, x8, x9, lo
   2102c:      	tbnz	w5, #0x0, 0x21b04 <_mech_canonical_program_entry_v1_numeric_1282+0x4984>
   21030:      	mov	x2, #0x0                ; =0
   21034:      	str	x2, [x25, #0x1fc0]
   21038:      	str	x2, [x25, #0x1fc8]
   2103c:      	str	x2, [x25, #0x1fd0]
   21040:      	str	x2, [x25, #0x1fd8]
   21044:      	str	x2, [x25, #0x1fe0]
   21048:      	str	x2, [x25, #0x1fe8]
   2104c:      	str	x2, [x25, #0x1ff0]
   21050:      	str	x2, [x25, #0x1ff8]
   21054:      	str	x2, [x25, #0x2000]
   21058:      	str	x2, [x25, #0x2008]
   2105c:      	str	x2, [x25, #0x2010]
   21060:      	str	x2, [x25, #0x2018]
   21064:      	str	x2, [x25, #0x2020]
   21068:      	str	x2, [x25, #0x2028]
   2106c:      	str	x2, [x25, #0x2030]
   21070:      	str	x2, [x25, #0x2038]
   21074:      	mov	w2, #0xcb86             ; =52102
   21078:      	movk	w2, #0x2, lsl #16
   2107c:      	sub	x3, x3, x2
   21080:      	mov	x13, #0x0               ; =0
   21084:      	stur	x13, [sp, #0xc0]
   21088:      	tbnz	w24, #0x0, 0x21ad4 <_mech_canonical_program_entry_v1_numeric_1282+0x4954>
   2108c:      	mov	x0, #0x0                ; =0
   21090:      	str	x0, [x25, #0x1c30]
   21094:      	str	x0, [x25, #0x1c38]
   21098:      	str	x0, [x25, #0x1c40]
   2109c:      	str	x0, [x25, #0x1c48]
   210a0:      	str	x0, [x25, #0x1c50]
   210a4:      	str	x0, [x25, #0x1c58]
   210a8:      	str	x0, [x25, #0x1c60]
   210ac:      	str	x0, [x25, #0x1c68]
   210b0:      	str	x0, [x25, #0x1c70]
   210b4:      	str	x0, [x25, #0x1c78]
   210b8:      	str	x0, [x25, #0x1c80]
   210bc:      	str	x0, [x25, #0x1c88]
   210c0:      	str	x0, [x25, #0x1c90]
   210c4:      	str	x0, [x25, #0x1c98]
   210c8:      	str	x0, [x25, #0x1ca0]
   210cc:      	str	x0, [x25, #0x1ca8]
   210d0:      	mov	x24, #0x0               ; =0
   210d4:      	mov	x9, x24
   210d8:      	mov	x12, x24
   210dc:      	mov	x15, x24
   210e0:      	mov	x27, x22
   210e4:      	stur	x22, [sp, #0x88]
   210e8:      	cmp	x22, x23
   210ec:      	b.lo	0x210f8 <_mech_canonical_program_entry_v1_numeric_1282+0x3f78>
   210f0:      	add	x11, x11, #0x1
   210f4:      	b	0x21994 <_mech_canonical_program_entry_v1_numeric_1282+0x4814>
   210f8:      	cbnz	x21, 0x212a4 <_mech_canonical_program_entry_v1_numeric_1282+0x4124>
   210fc:      	b	0x23644 <_mech_canonical_program_entry_v1_numeric_1282+0x64c4>
   21100:      	ldr	x4, [sp, #0x198]
   21104:      	str	x27, [x4, #0x10]
   21108:      	ldr	x6, [sp, #0x198]
   2110c:      	str	x23, [x6, #0x18]
   21110:      	ldr	x8, [sp, #0x198]
   21114:      	str	x27, [x8, #0x10]
   21118:      	ldr	x10, [sp, #0x198]
   2111c:      	str	x23, [x10, #0x18]
   21120:      	add	x0, x11, #0x1
   21124:      	ldr	x14, [sp, #0x198]
   21128:      	str	x0, [x14, #0xc50]
   2112c:      	ldr	x1, [sp, #0x198]
   21130:      	ldur	x26, [sp, #0xa0]
   21134:      	str	x26, [x1, #0xc58]
   21138:      	ldur	x7, [sp, #0xa8]
   2113c:      	str	x7, [x1, #0xc60]
   21140:      	ldur	x4, [sp, #0x90]
   21144:      	sub	x1, x4, x3
   21148:      	mov	w2, #0xc87e             ; =51326
   2114c:      	movk	w2, #0x1, lsl #16
   21150:      	msub	x0, x0, x2, x1
   21154:      	ldr	x1, [sp, #0x198]
   21158:      	str	x0, [x1, #0xc68]
   2115c:      	ldr	x0, [sp, #0x198]
   21160:      	str	x24, [x0, #0xc70]
   21164:      	str	x15, [x0, #0xc78]
   21168:      	mov	x5, #0x0                ; =0
   2116c:      	str	x5, [x0, #0xc80]
   21170:      	ldur	x8, [sp, #0xb0]
   21174:      	str	x8, [x0, #0xc88]
   21178:      	ldur	x4, [sp, #0xb8]
   2117c:      	str	x4, [x0, #0xc90]
   21180:      	str	x5, [x0, #0xc98]
   21184:      	str	x12, [x0, #0xca0]
   21188:      	str	x9, [x0, #0xca8]
   2118c:      	str	x5, [x0, #0xcb0]
   21190:      	str	x13, [x0, #0xcb8]
   21194:      	ldur	x13, [sp, #0xc0]
   21198:      	str	x13, [x0, #0xcc0]
   2119c:      	ldur	x14, [sp, #0x60]
   211a0:      	add	x0, x14, #0x1
   211a4:      	str	x0, [x1, #0xcd0]
   211a8:      	ldur	x24, [sp, #0x10]
   211ac:      	and	x0, x24, #0x3ffffffffffffff
   211b0:      	eor	x0, x0, #0x3ffffffffffffff
   211b4:      	str	x0, [x1, #0xcd8]
   211b8:      	mov	x1, #0x6c4              ; =1732
   211bc:      	mov	x2, #-0x1b              ; =-27
   211c0:      	ldur	x4, [sp, #0x98]
   211c4:      	ldr	x21, [sp, #0x1a8]
   211c8:      	ldur	x0, [sp, #0x8]
   211cc:      	ldr	x6, [sp, #0x1a0]
   211d0:      	blr	x21
   211d4:      	mov	x1, #0x2                ; =2
   211d8:      	mov	x21, x1
   211dc:      	cmp	x0, #0x0
   211e0:      	b.ne	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   211e4:      	ldr	x3, [sp, #0x198]
   211e8:      	ldr	x3, [x3]
   211ec:      	ldr	x1, [sp, #0x198]
   211f0:      	ldr	x4, [x1, #0x8]
   211f4:      	stur	x4, [sp, #0x98]
   211f8:      	ldr	x4, [sp, #0x198]
   211fc:      	ldr	x20, [x4, #0xab8]
   21200:      	ldr	x5, [sp, #0x198]
   21204:      	ldr	x21, [x5, #0xbf8]
   21208:      	ldr	x7, [sp, #0x198]
   2120c:      	ldr	x1, [x7, #0xac0]
   21210:      	ldr	x9, [sp, #0x198]
   21214:      	ldr	x0, [x9, #0xac8]
   21218:      	ldr	x11, [sp, #0x198]
   2121c:      	ldr	x0, [x11, #0xad0]
   21220:      	ldr	x13, [sp, #0x198]
   21224:      	ldr	x0, [x13, #0xc48]
   21228:      	ldr	x15, [sp, #0x198]
   2122c:      	stur	x0, [sp, #0xc8]
   21230:      	ldr	x11, [x15, #0xc50]
   21234:      	ldr	x0, [sp, #0x198]
   21238:      	ldr	x26, [x0, #0xc58]
   2123c:      	stur	x26, [sp, #0xa0]
   21240:      	ldr	x7, [x0, #0xc60]
   21244:      	stur	x7, [sp, #0xa8]
   21248:      	ldr	x0, [x0, #0xc68]
   2124c:      	ldr	x2, [sp, #0x198]
   21250:      	ldr	x24, [x2, #0xc70]
   21254:      	ldr	x15, [x2, #0xc78]
   21258:      	ldr	x8, [x2, #0xc88]
   2125c:      	stur	x8, [sp, #0xb0]
   21260:      	ldr	x4, [x2, #0xc90]
   21264:      	stur	x4, [sp, #0xb8]
   21268:      	ldr	x12, [x2, #0xca0]
   2126c:      	ldr	x9, [x2, #0xca8]
   21270:      	ldr	x13, [x2, #0xcb8]
   21274:      	ldr	x2, [x2, #0xcc0]
   21278:      	stur	x2, [sp, #0xc0]
   2127c:      	ldr	x2, [sp, #0x198]
   21280:      	ldr	x25, [x2, #0x10]
   21284:      	mov	x28, #0x1               ; =1
   21288:      	str	x28, [x19, #0x4c60]
   2128c:      	add	x0, x3, x0
   21290:      	mov	w2, #0xc87e             ; =51326
   21294:      	movk	w2, #0x1, lsl #16
   21298:      	madd	x4, x11, x2, x0
   2129c:      	stur	x4, [sp, #0x90]
   212a0:      	b	0x212c0 <_mech_canonical_program_entry_v1_numeric_1282+0x4140>
   212a4:      	ldur	x0, [sp, #0x10]
   212a8:      	and	x0, x0, #0x3ffffffffffffff
   212ac:      	eor	x0, x0, #0x3ffffffffffffff
   212b0:      	ldur	x14, [sp, #0x60]
   212b4:      	str	x0, [x20, x14, lsl #3]
   212b8:      	add	x1, x14, #0x1
   212bc:      	add	x11, x11, #0x1
   212c0:      	cbnz	x21, 0x2145c <_mech_canonical_program_entry_v1_numeric_1282+0x42dc>
   212c4:      	b	0x23670 <_mech_canonical_program_entry_v1_numeric_1282+0x64f0>
   212c8:      	ldr	x4, [sp, #0x198]
   212cc:      	str	x27, [x4, #0x10]
   212d0:      	ldr	x6, [sp, #0x198]
   212d4:      	str	x23, [x6, #0x18]
   212d8:      	ldr	x8, [sp, #0x198]
   212dc:      	str	x27, [x8, #0x10]
   212e0:      	ldr	x10, [sp, #0x198]
   212e4:      	str	x23, [x10, #0x18]
   212e8:      	ldr	x14, [sp, #0x198]
   212ec:      	str	x11, [x14, #0xc50]
   212f0:      	ldur	x26, [sp, #0xa0]
   212f4:      	str	x26, [x14, #0xc58]
   212f8:      	ldr	x0, [sp, #0x198]
   212fc:      	ldur	x7, [sp, #0xa8]
   21300:      	str	x7, [x0, #0xc60]
   21304:      	ldur	x4, [sp, #0x90]
   21308:      	sub	x10, x4, x3
   2130c:      	mov	w14, #0xc87e            ; =51326
   21310:      	movk	w14, #0x1, lsl #16
   21314:      	msub	x10, x11, x14, x10
   21318:      	str	x10, [x0, #0xc68]
   2131c:      	str	x24, [x0, #0xc70]
   21320:      	str	x15, [x0, #0xc78]
   21324:      	mov	x5, #0x0                ; =0
   21328:      	str	x5, [x0, #0xc80]
   2132c:      	ldur	x8, [sp, #0xb0]
   21330:      	str	x8, [x0, #0xc88]
   21334:      	ldur	x4, [sp, #0xb8]
   21338:      	str	x4, [x0, #0xc90]
   2133c:      	str	x5, [x0, #0xc98]
   21340:      	str	x12, [x0, #0xca0]
   21344:      	str	x9, [x0, #0xca8]
   21348:      	str	x5, [x0, #0xcb0]
   2134c:      	str	x13, [x0, #0xcb8]
   21350:      	ldur	x13, [sp, #0xc0]
   21354:      	str	x13, [x0, #0xcc0]
   21358:      	add	x0, x1, #0x1
   2135c:      	ldr	x1, [sp, #0x198]
   21360:      	str	x0, [x1, #0xcd0]
   21364:      	ldur	x26, [sp, #0x68]
   21368:      	and	x0, x26, #0x3ffffffffffffff
   2136c:      	eor	x0, x0, #0x3ffffffffffffff
   21370:      	str	x0, [x1, #0xcd8]
   21374:      	mov	x1, #0x6c8              ; =1736
   21378:      	mov	x2, #-0x1b              ; =-27
   2137c:      	ldur	x4, [sp, #0x98]
   21380:      	ldr	x21, [sp, #0x1a8]
   21384:      	ldur	x0, [sp, #0x8]
   21388:      	ldr	x6, [sp, #0x1a0]
   2138c:      	blr	x21
   21390:      	mov	x9, #0x2                ; =2
   21394:      	mov	x21, x9
   21398:      	cmp	x0, #0x0
   2139c:      	b.ne	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   213a0:      	ldr	x3, [sp, #0x198]
   213a4:      	ldr	x3, [x3]
   213a8:      	ldr	x0, [sp, #0x198]
   213ac:      	ldr	x4, [x0, #0x8]
   213b0:      	ldr	x2, [sp, #0x198]
   213b4:      	stur	x4, [sp, #0x98]
   213b8:      	ldr	x20, [x2, #0xab8]
   213bc:      	ldr	x4, [sp, #0x198]
   213c0:      	ldr	x21, [x4, #0xbf8]
   213c4:      	ldr	x6, [sp, #0x198]
   213c8:      	ldr	x1, [x6, #0xac0]
   213cc:      	ldr	x8, [sp, #0x198]
   213d0:      	ldr	x0, [x8, #0xac8]
   213d4:      	ldr	x10, [sp, #0x198]
   213d8:      	ldr	x0, [x10, #0xad0]
   213dc:      	ldr	x12, [sp, #0x198]
   213e0:      	ldr	x0, [x12, #0xc48]
   213e4:      	ldr	x14, [sp, #0x198]
   213e8:      	stur	x0, [sp, #0xc8]
   213ec:      	ldr	x11, [x14, #0xc50]
   213f0:      	ldr	x0, [sp, #0x198]
   213f4:      	ldr	x26, [x0, #0xc58]
   213f8:      	stur	x26, [sp, #0xa0]
   213fc:      	ldr	x7, [x0, #0xc60]
   21400:      	stur	x7, [sp, #0xa8]
   21404:      	ldr	x0, [x0, #0xc68]
   21408:      	ldr	x24, [x2, #0xc70]
   2140c:      	ldr	x15, [x2, #0xc78]
   21410:      	ldr	x8, [x2, #0xc88]
   21414:      	stur	x8, [sp, #0xb0]
   21418:      	ldr	x4, [x2, #0xc90]
   2141c:      	stur	x4, [sp, #0xb8]
   21420:      	ldr	x12, [x2, #0xca0]
   21424:      	ldr	x9, [x2, #0xca8]
   21428:      	ldr	x13, [x2, #0xcb8]
   2142c:      	ldr	x2, [x2, #0xcc0]
   21430:      	stur	x2, [sp, #0xc0]
   21434:      	ldr	x2, [sp, #0x198]
   21438:      	ldr	x25, [x2, #0x10]
   2143c:      	mov	x28, #0x1               ; =1
   21440:      	str	x28, [x19, #0x4c60]
   21444:      	add	x0, x3, x0
   21448:      	mov	w2, #0xc87e             ; =51326
   2144c:      	movk	w2, #0x1, lsl #16
   21450:      	madd	x4, x11, x2, x0
   21454:      	stur	x4, [sp, #0x90]
   21458:      	b	0x21470 <_mech_canonical_program_entry_v1_numeric_1282+0x42f0>
   2145c:      	ldur	x26, [sp, #0x68]
   21460:      	and	x0, x26, #0x3ffffffffffffff
   21464:      	eor	x0, x0, #0x3ffffffffffffff
   21468:      	str	x0, [x20, x1, lsl #3]
   2146c:      	add	x1, x1, #0x1
   21470:      	cbnz	x21, 0x21610 <_mech_canonical_program_entry_v1_numeric_1282+0x4490>
   21474:      	b	0x2369c <_mech_canonical_program_entry_v1_numeric_1282+0x651c>
   21478:      	ldr	x2, [sp, #0x198]
   2147c:      	str	x27, [x2, #0x10]
   21480:      	ldr	x4, [sp, #0x198]
   21484:      	str	x23, [x4, #0x18]
   21488:      	ldr	x6, [sp, #0x198]
   2148c:      	str	x27, [x6, #0x10]
   21490:      	ldr	x8, [sp, #0x198]
   21494:      	str	x23, [x8, #0x18]
   21498:      	ldr	x10, [sp, #0x198]
   2149c:      	str	x11, [x10, #0xc50]
   214a0:      	ldr	x14, [sp, #0x198]
   214a4:      	ldur	x26, [sp, #0xa0]
   214a8:      	str	x26, [x14, #0xc58]
   214ac:      	ldur	x7, [sp, #0xa8]
   214b0:      	str	x7, [x14, #0xc60]
   214b4:      	ldur	x4, [sp, #0x90]
   214b8:      	sub	x0, x4, x3
   214bc:      	mov	w2, #0xc87e             ; =51326
   214c0:      	movk	w2, #0x1, lsl #16
   214c4:      	msub	x0, x11, x2, x0
   214c8:      	ldr	x2, [sp, #0x198]
   214cc:      	str	x0, [x2, #0xc68]
   214d0:      	ldr	x0, [sp, #0x198]
   214d4:      	str	x24, [x0, #0xc70]
   214d8:      	str	x15, [x0, #0xc78]
   214dc:      	mov	x5, #0x0                ; =0
   214e0:      	str	x5, [x0, #0xc80]
   214e4:      	ldur	x8, [sp, #0xb0]
   214e8:      	str	x8, [x0, #0xc88]
   214ec:      	ldur	x4, [sp, #0xb8]
   214f0:      	str	x4, [x0, #0xc90]
   214f4:      	str	x5, [x0, #0xc98]
   214f8:      	str	x12, [x0, #0xca0]
   214fc:      	str	x9, [x0, #0xca8]
   21500:      	str	x5, [x0, #0xcb0]
   21504:      	str	x13, [x0, #0xcb8]
   21508:      	ldur	x13, [sp, #0xc0]
   2150c:      	str	x13, [x0, #0xcc0]
   21510:      	add	x0, x1, #0x1
   21514:      	ldr	x1, [sp, #0x198]
   21518:      	str	x0, [x1, #0xcd0]
   2151c:      	ldur	x0, [sp, #0x70]
   21520:      	and	x0, x0, #0x3ffffffffffffff
   21524:      	eor	x0, x0, #0x3ffffffffffffff
   21528:      	str	x0, [x1, #0xcd8]
   2152c:      	mov	x1, #0x6cc              ; =1740
   21530:      	mov	x2, #-0x1b              ; =-27
   21534:      	ldur	x4, [sp, #0x98]
   21538:      	ldr	x21, [sp, #0x1a8]
   2153c:      	ldur	x0, [sp, #0x8]
   21540:      	ldr	x6, [sp, #0x1a0]
   21544:      	blr	x21
   21548:      	mov	x1, #0x2                ; =2
   2154c:      	mov	x21, x1
   21550:      	cmp	x0, #0x0
   21554:      	b.ne	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   21558:      	ldr	x3, [sp, #0x198]
   2155c:      	ldr	x3, [x3]
   21560:      	ldr	x0, [sp, #0x198]
   21564:      	ldr	x4, [x0, #0x8]
   21568:      	stur	x4, [sp, #0x98]
   2156c:      	ldr	x20, [x0, #0xab8]
   21570:      	ldr	x2, [sp, #0x198]
   21574:      	ldr	x21, [x2, #0xbf8]
   21578:      	ldr	x4, [sp, #0x198]
   2157c:      	ldr	x2, [x4, #0xac0]
   21580:      	ldr	x6, [sp, #0x198]
   21584:      	ldr	x4, [x6, #0xac8]
   21588:      	ldr	x8, [sp, #0x198]
   2158c:      	ldr	x4, [x8, #0xad0]
   21590:      	ldr	x10, [sp, #0x198]
   21594:      	ldr	x1, [x10, #0xc48]
   21598:      	ldr	x12, [sp, #0x198]
   2159c:      	stur	x1, [sp, #0xc8]
   215a0:      	ldr	x11, [x12, #0xc50]
   215a4:      	ldr	x14, [sp, #0x198]
   215a8:      	ldr	x26, [x14, #0xc58]
   215ac:      	stur	x26, [sp, #0xa0]
   215b0:      	ldr	x7, [x0, #0xc60]
   215b4:      	stur	x7, [sp, #0xa8]
   215b8:      	ldr	x4, [x0, #0xc68]
   215bc:      	ldr	x24, [x0, #0xc70]
   215c0:      	ldr	x15, [x0, #0xc78]
   215c4:      	ldr	x8, [x0, #0xc88]
   215c8:      	stur	x8, [sp, #0xb0]
   215cc:      	ldr	x1, [x0, #0xc90]
   215d0:      	stur	x1, [sp, #0xb8]
   215d4:      	ldr	x12, [x0, #0xca0]
   215d8:      	ldr	x9, [x0, #0xca8]
   215dc:      	ldr	x13, [x0, #0xcb8]
   215e0:      	ldr	x0, [x0, #0xcc0]
   215e4:      	stur	x0, [sp, #0xc0]
   215e8:      	ldr	x0, [sp, #0x198]
   215ec:      	ldr	x25, [x0, #0x10]
   215f0:      	mov	x28, #0x1               ; =1
   215f4:      	str	x28, [x19, #0x4c60]
   215f8:      	add	x4, x3, x4
   215fc:      	mov	w5, #0xc87e             ; =51326
   21600:      	movk	w5, #0x1, lsl #16
   21604:      	madd	x4, x11, x5, x4
   21608:      	stur	x4, [sp, #0x90]
   2160c:      	b	0x21624 <_mech_canonical_program_entry_v1_numeric_1282+0x44a4>
   21610:      	ldur	x2, [sp, #0x70]
   21614:      	and	x4, x2, #0x3ffffffffffffff
   21618:      	eor	x4, x4, #0x3ffffffffffffff
   2161c:      	str	x4, [x20, x1, lsl #3]
   21620:      	add	x2, x1, #0x1
   21624:      	cbnz	x21, 0x217c4 <_mech_canonical_program_entry_v1_numeric_1282+0x4644>
   21628:      	b	0x236c8 <_mech_canonical_program_entry_v1_numeric_1282+0x6548>
   2162c:      	ldr	x0, [sp, #0x198]
   21630:      	str	x27, [x0, #0x10]
   21634:      	ldr	x4, [sp, #0x198]
   21638:      	str	x23, [x4, #0x18]
   2163c:      	str	x27, [x4, #0x10]
   21640:      	ldr	x6, [sp, #0x198]
   21644:      	str	x23, [x6, #0x18]
   21648:      	ldr	x8, [sp, #0x198]
   2164c:      	str	x11, [x8, #0xc50]
   21650:      	ldr	x10, [sp, #0x198]
   21654:      	ldur	x26, [sp, #0xa0]
   21658:      	str	x26, [x10, #0xc58]
   2165c:      	ldur	x7, [sp, #0xa8]
   21660:      	ldr	x14, [sp, #0x198]
   21664:      	str	x7, [x14, #0xc60]
   21668:      	ldur	x4, [sp, #0x90]
   2166c:      	sub	x0, x4, x3
   21670:      	mov	w1, #0xc87e             ; =51326
   21674:      	movk	w1, #0x1, lsl #16
   21678:      	msub	x0, x11, x1, x0
   2167c:      	ldr	x1, [sp, #0x198]
   21680:      	str	x0, [x1, #0xc68]
   21684:      	ldr	x0, [sp, #0x198]
   21688:      	str	x24, [x0, #0xc70]
   2168c:      	str	x15, [x0, #0xc78]
   21690:      	mov	x5, #0x0                ; =0
   21694:      	str	x5, [x0, #0xc80]
   21698:      	ldur	x8, [sp, #0xb0]
   2169c:      	str	x8, [x0, #0xc88]
   216a0:      	ldur	x4, [sp, #0xb8]
   216a4:      	str	x4, [x0, #0xc90]
   216a8:      	str	x5, [x0, #0xc98]
   216ac:      	str	x12, [x0, #0xca0]
   216b0:      	str	x9, [x0, #0xca8]
   216b4:      	str	x5, [x0, #0xcb0]
   216b8:      	str	x13, [x0, #0xcb8]
   216bc:      	ldur	x13, [sp, #0xc0]
   216c0:      	str	x13, [x0, #0xcc0]
   216c4:      	add	x0, x2, #0x1
   216c8:      	str	x0, [x1, #0xcd0]
   216cc:      	ldur	x24, [sp, #0x78]
   216d0:      	and	x0, x24, #0x3ffffffffffffff
   216d4:      	eor	x0, x0, #0x3ffffffffffffff
   216d8:      	str	x0, [x1, #0xcd8]
   216dc:      	mov	x1, #0x6d0              ; =1744
   216e0:      	mov	x2, #-0x1b              ; =-27
   216e4:      	ldur	x4, [sp, #0x98]
   216e8:      	ldr	x21, [sp, #0x1a8]
   216ec:      	ldur	x0, [sp, #0x8]
   216f0:      	ldr	x6, [sp, #0x1a0]
   216f4:      	blr	x21
   216f8:      	mov	x1, #0x2                ; =2
   216fc:      	mov	x21, x1
   21700:      	cmp	x0, #0x0
   21704:      	b.ne	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   21708:      	ldr	x3, [sp, #0x198]
   2170c:      	ldr	x3, [x3]
   21710:      	ldr	x0, [sp, #0x198]
   21714:      	ldr	x4, [x0, #0x8]
   21718:      	stur	x4, [sp, #0x98]
   2171c:      	ldr	x20, [x0, #0xab8]
   21720:      	ldr	x21, [x0, #0xbf8]
   21724:      	ldr	x2, [sp, #0x198]
   21728:      	ldr	x1, [x2, #0xac0]
   2172c:      	ldr	x4, [sp, #0x198]
   21730:      	ldr	x0, [x4, #0xac8]
   21734:      	ldr	x6, [sp, #0x198]
   21738:      	ldr	x0, [x6, #0xad0]
   2173c:      	ldr	x8, [sp, #0x198]
   21740:      	ldr	x0, [x8, #0xc48]
   21744:      	ldr	x10, [sp, #0x198]
   21748:      	stur	x0, [sp, #0xc8]
   2174c:      	ldr	x11, [x10, #0xc50]
   21750:      	ldr	x12, [sp, #0x198]
   21754:      	ldr	x26, [x12, #0xc58]
   21758:      	ldr	x14, [sp, #0x198]
   2175c:      	stur	x26, [sp, #0xa0]
   21760:      	ldr	x7, [x14, #0xc60]
   21764:      	ldr	x0, [sp, #0x198]
   21768:      	stur	x7, [sp, #0xa8]
   2176c:      	ldr	x0, [x0, #0xc68]
   21770:      	ldr	x24, [x2, #0xc70]
   21774:      	ldr	x15, [x2, #0xc78]
   21778:      	ldr	x8, [x2, #0xc88]
   2177c:      	stur	x8, [sp, #0xb0]
   21780:      	ldr	x4, [x2, #0xc90]
   21784:      	stur	x4, [sp, #0xb8]
   21788:      	ldr	x12, [x2, #0xca0]
   2178c:      	ldr	x9, [x2, #0xca8]
   21790:      	ldr	x13, [x2, #0xcb8]
   21794:      	ldr	x2, [x2, #0xcc0]
   21798:      	stur	x2, [sp, #0xc0]
   2179c:      	ldr	x2, [sp, #0x198]
   217a0:      	ldr	x25, [x2, #0x10]
   217a4:      	mov	x28, #0x1               ; =1
   217a8:      	str	x28, [x19, #0x4c60]
   217ac:      	add	x0, x3, x0
   217b0:      	mov	w2, #0xc87e             ; =51326
   217b4:      	movk	w2, #0x1, lsl #16
   217b8:      	madd	x4, x11, x2, x0
   217bc:      	stur	x4, [sp, #0x90]
   217c0:      	b	0x217d8 <_mech_canonical_program_entry_v1_numeric_1282+0x4658>
   217c4:      	ldur	x0, [sp, #0x78]
   217c8:      	and	x0, x0, #0x3ffffffffffffff
   217cc:      	eor	x0, x0, #0x3ffffffffffffff
   217d0:      	str	x0, [x20, x2, lsl #3]
   217d4:      	add	x1, x2, #0x1
   217d8:      	cbnz	x21, 0x2197c <_mech_canonical_program_entry_v1_numeric_1282+0x47fc>
   217dc:      	b	0x236f4 <_mech_canonical_program_entry_v1_numeric_1282+0x6574>
   217e0:      	ldr	x0, [sp, #0x198]
   217e4:      	str	x27, [x0, #0x10]
   217e8:      	str	x23, [x0, #0x18]
   217ec:      	ldr	x2, [sp, #0x198]
   217f0:      	str	x27, [x2, #0x10]
   217f4:      	ldr	x4, [sp, #0x198]
   217f8:      	str	x23, [x4, #0x18]
   217fc:      	ldr	x6, [sp, #0x198]
   21800:      	str	x11, [x6, #0xc50]
   21804:      	ldr	x8, [sp, #0x198]
   21808:      	ldur	x26, [sp, #0xa0]
   2180c:      	str	x26, [x8, #0xc58]
   21810:      	ldur	x7, [sp, #0xa8]
   21814:      	ldr	x10, [sp, #0x198]
   21818:      	str	x7, [x10, #0xc60]
   2181c:      	ldur	x4, [sp, #0x90]
   21820:      	sub	x0, x4, x3
   21824:      	mov	w2, #0xc87e             ; =51326
   21828:      	movk	w2, #0x1, lsl #16
   2182c:      	msub	x0, x11, x2, x0
   21830:      	ldr	x2, [sp, #0x198]
   21834:      	str	x0, [x2, #0xc68]
   21838:      	ldr	x0, [sp, #0x198]
   2183c:      	str	x24, [x0, #0xc70]
   21840:      	str	x15, [x0, #0xc78]
   21844:      	mov	x5, #0x0                ; =0
   21848:      	str	x5, [x0, #0xc80]
   2184c:      	ldur	x8, [sp, #0xb0]
   21850:      	str	x8, [x0, #0xc88]
   21854:      	ldur	x4, [sp, #0xb8]
   21858:      	str	x4, [x0, #0xc90]
   2185c:      	str	x5, [x0, #0xc98]
   21860:      	str	x12, [x0, #0xca0]
   21864:      	str	x9, [x0, #0xca8]
   21868:      	str	x5, [x0, #0xcb0]
   2186c:      	str	x13, [x0, #0xcb8]
   21870:      	ldur	x13, [sp, #0xc0]
   21874:      	str	x13, [x0, #0xcc0]
   21878:      	add	x10, x1, #0x1
   2187c:      	str	x10, [x0, #0xcd0]
   21880:      	ldur	x26, [sp, #0x80]
   21884:      	and	x11, x26, #0x3ffffffffffffff
   21888:      	eor	x11, x11, #0x3ffffffffffffff
   2188c:      	str	x11, [x0, #0xcd8]
   21890:      	mov	x1, #0x6d4              ; =1748
   21894:      	mov	x2, #-0x1b              ; =-27
   21898:      	ldur	x4, [sp, #0x98]
   2189c:      	ldr	x21, [sp, #0x1a8]
   218a0:      	ldur	x0, [sp, #0x8]
   218a4:      	ldr	x6, [sp, #0x1a0]
   218a8:      	blr	x21
   218ac:      	mov	x9, #0x2                ; =2
   218b0:      	mov	x21, x9
   218b4:      	cmp	x0, #0x0
   218b8:      	b.ne	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   218bc:      	ldr	x3, [sp, #0x198]
   218c0:      	ldr	x3, [x3]
   218c4:      	ldr	x0, [sp, #0x198]
   218c8:      	ldr	x4, [x0, #0x8]
   218cc:      	stur	x4, [sp, #0x98]
   218d0:      	ldr	x20, [x0, #0xab8]
   218d4:      	ldr	x21, [x0, #0xbf8]
   218d8:      	ldr	x14, [x0, #0xac0]
   218dc:      	ldr	x2, [sp, #0x198]
   218e0:      	stur	x14, [sp, #0x60]
   218e4:      	ldr	x15, [x2, #0xac8]
   218e8:      	ldr	x4, [sp, #0x198]
   218ec:      	ldr	x15, [x4, #0xad0]
   218f0:      	ldr	x6, [sp, #0x198]
   218f4:      	ldr	x1, [x6, #0xc48]
   218f8:      	ldr	x8, [sp, #0x198]
   218fc:      	stur	x1, [sp, #0xc8]
   21900:      	ldr	x11, [x8, #0xc50]
   21904:      	ldr	x10, [sp, #0x198]
   21908:      	ldr	x26, [x10, #0xc58]
   2190c:      	ldr	x12, [sp, #0x198]
   21910:      	stur	x26, [sp, #0xa0]
   21914:      	ldr	x7, [x12, #0xc60]
   21918:      	ldr	x14, [sp, #0x198]
   2191c:      	stur	x7, [sp, #0xa8]
   21920:      	ldr	x0, [x14, #0xc68]
   21924:      	ldr	x1, [sp, #0x198]
   21928:      	ldr	x24, [x1, #0xc70]
   2192c:      	ldr	x15, [x1, #0xc78]
   21930:      	ldr	x8, [x1, #0xc88]
   21934:      	stur	x8, [sp, #0xb0]
   21938:      	ldr	x4, [x1, #0xc90]
   2193c:      	stur	x4, [sp, #0xb8]
   21940:      	ldr	x12, [x1, #0xca0]
   21944:      	ldr	x9, [x1, #0xca8]
   21948:      	ldr	x13, [x1, #0xcb8]
   2194c:      	ldr	x1, [x1, #0xcc0]
   21950:      	stur	x1, [sp, #0xc0]
   21954:      	ldr	x1, [sp, #0x198]
   21958:      	ldr	x25, [x1, #0x10]
   2195c:      	mov	x28, #0x1               ; =1
   21960:      	str	x28, [x19, #0x4c60]
   21964:      	add	x0, x3, x0
   21968:      	mov	w1, #0xc87e             ; =51326
   2196c:      	movk	w1, #0x1, lsl #16
   21970:      	madd	x4, x11, x1, x0
   21974:      	stur	x4, [sp, #0x90]
   21978:      	b	0x21994 <_mech_canonical_program_entry_v1_numeric_1282+0x4814>
   2197c:      	ldur	x26, [sp, #0x80]
   21980:      	and	x0, x26, #0x3ffffffffffffff
   21984:      	eor	x0, x0, #0x3ffffffffffffff
   21988:      	str	x0, [x20, x1, lsl #3]
   2198c:      	add	x14, x1, #0x1
   21990:      	stur	x14, [sp, #0x60]
   21994:      	cmp	x22, x23
   21998:      	b.lo	0x21aac <_mech_canonical_program_entry_v1_numeric_1282+0x492c>
   2199c:      	mov	x0, #0x0                ; =0
   219a0:      	str	x0, [x19, #0x18]
   219a4:      	mov	x1, #0x1000000000000000 ; =1152921504606846976
   219a8:      	str	x1, [x19, #0x20]
   219ac:      	mov	x1, #0x1                ; =1
   219b0:      	str	x1, [x19, #0x30]
   219b4:      	mov	x2, #0x101010101010101  ; =72340172838076673
   219b8:      	str	x2, [x19, #0x38]
   219bc:      	mov	x2, #0x2                ; =2
   219c0:      	str	x2, [x19, #0x40]
   219c4:      	mov	x2, #0x3                ; =3
   219c8:      	str	x2, [x19, #0x48]
   219cc:      	mov	x2, #0x4                ; =4
   219d0:      	str	x2, [x19, #0x50]
   219d4:      	mov	x2, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   219d8:      	str	x2, [x19, #0x78]
   219dc:      	mov	x2, #0x3333333333333333 ; =3689348814741910323
   219e0:      	str	x2, [x19, #0x88]
   219e4:      	mov	x2, #0x38               ; =56
   219e8:      	str	x2, [x19, #0x90]
   219ec:      	mov	x2, #0x3a               ; =58
   219f0:      	str	x2, [x19, #0x98]
   219f4:      	mov	x2, #0x5555555555555555 ; =6148914691236517205
   219f8:      	str	x2, [x19, #0xb0]
   219fc:      	mov	x2, #0x3ffffffffffffff  ; =288230376151711743
   21a00:      	str	x2, [x19, #0xb8]
   21a04:      	str	x0, [x19, #0x188]
   21a08:      	str	x1, [x19, #0x190]
   21a0c:      	str	x28, [x19, #0x4c60]
   21a10:      	str	x3, [x19, #0x4c68]
   21a14:      	ldur	x4, [sp, #0x98]
   21a18:      	str	x4, [x19, #0x4c70]
   21a1c:      	str	x27, [x19, #0x4f70]
   21a20:      	str	x23, [x19, #0x4f78]
   21a24:      	ldur	x14, [sp, #0x60]
   21a28:      	str	x14, [x19, #0x5a20]
   21a2c:      	str	x11, [x19, #0x5bb0]
   21a30:      	ldur	x26, [sp, #0xa0]
   21a34:      	str	x26, [x19, #0x5bb8]
   21a38:      	ldur	x7, [sp, #0xa8]
   21a3c:      	str	x7, [x19, #0x5bc0]
   21a40:      	ldur	x4, [sp, #0x90]
   21a44:      	sub	x0, x4, x3
   21a48:      	mov	w1, #0xc87e             ; =51326
   21a4c:      	movk	w1, #0x1, lsl #16
   21a50:      	msub	x0, x11, x1, x0
   21a54:      	str	x0, [x19, #0x5bc8]
   21a58:      	str	x24, [x19, #0x5bd0]
   21a5c:      	str	x15, [x19, #0x5bd8]
   21a60:      	ldur	x8, [sp, #0xb0]
   21a64:      	str	x8, [x19, #0x5be8]
   21a68:      	ldur	x4, [sp, #0xb8]
   21a6c:      	str	x4, [x19, #0x5bf0]
   21a70:      	str	x12, [x19, #0x5c00]
   21a74:      	str	x9, [x19, #0x5c08]
   21a78:      	str	x13, [x19, #0x5c18]
   21a7c:      	ldur	x13, [sp, #0xc0]
   21a80:      	str	x13, [x19, #0x5c20]
   21a84:      	mov	x0, #0x0                ; =0
   21a88:      	mov	x1, #0x1                ; =1
   21a8c:      	add	sp, sp, #0x1c0
   21a90:      	ldp	x19, x20, [sp], #0x10
   21a94:      	ldp	x21, x22, [sp], #0x10
   21a98:      	ldp	x23, x24, [sp], #0x10
   21a9c:      	ldp	x25, x26, [sp], #0x10
   21aa0:      	ldp	x27, x28, [sp], #0x10
   21aa4:      	ldp	x29, x30, [sp], #0x10
   21aa8:      	retab
   21aac:      	ldur	x10, [sp, #0x88]
   21ab0:      	add	x22, x10, #0x1
   21ab4:      	cmp	x22, x10
   21ab8:      	b.lo	0x23720 <_mech_canonical_program_entry_v1_numeric_1282+0x65a0>
   21abc:      	mov	x7, #0x1                ; =1
   21ac0:      	stur	x7, [sp, #0xa8]
   21ac4:      	ldur	x5, [sp, #0xa8]
   21ac8:      	ldur	x6, [sp, #0xb0]
   21acc:      	mov	x26, x28
   21ad0:      	b	0x1d354 <_mech_canonical_program_entry_v1_numeric_1282+0x1d4>
   21ad4:      	add	x2, x15, #0x1
   21ad8:      	cmp	x2, x15
   21adc:      	b.lo	0x23820 <_mech_canonical_program_entry_v1_numeric_1282+0x66a0>
   21ae0:      	mov	x4, #0x1                ; =1
   21ae4:      	stur	x4, [sp, #0x50]
   21ae8:      	mov	x15, x2
   21aec:      	stur	x1, [sp, #0x10]
   21af0:      	stur	x14, [sp, #0x68]
   21af4:      	stur	x10, [sp, #0x70]
   21af8:      	stur	x9, [sp, #0x78]
   21afc:      	stur	x0, [sp, #0x80]
   21b00:      	b	0x1fc78 <_mech_canonical_program_entry_v1_numeric_1282+0x2af8>
   21b04:      	add	x0, x27, #0x1
   21b08:      	cmp	x0, x27
   21b0c:      	b.lo	0x2393c <_mech_canonical_program_entry_v1_numeric_1282+0x67bc>
   21b10:      	mov	w14, #0xcb86            ; =52102
   21b14:      	movk	w14, #0x2, lsl #16
   21b18:      	sub	x3, x3, x14
   21b1c:      	mov	x5, #0x1                ; =1
   21b20:      	stur	x5, [sp, #0x58]
   21b24:      	mov	x27, x0
   21b28:      	mov	x14, x4
   21b2c:      	mov	x10, x7
   21b30:      	mov	x9, x6
   21b34:      	mov	x1, x2
   21b38:      	mov	x0, x8
   21b3c:      	b	0x20858 <_mech_canonical_program_entry_v1_numeric_1282+0x36d8>
   21b40:      	add	x27, x4, #0x1
   21b44:      	stur	x27, [sp, #0x18]
   21b48:      	cmp	x27, x4
   21b4c:      	b.lo	0x23a78 <_mech_canonical_program_entry_v1_numeric_1282+0x68f8>
   21b50:      	mov	x14, #0x1               ; =1
   21b54:      	stur	x14, [sp, #0x20]
   21b58:      	mov	x4, x1
   21b5c:      	mov	x27, x15
   21b60:      	stur	x2, [sp, #0x10]
   21b64:      	stur	x0, [sp, #0x80]
   21b68:      	b	0x1dee0 <_mech_canonical_program_entry_v1_numeric_1282+0xd60>
   21b6c:      	add	x27, x14, #0x1
   21b70:      	cmp	x27, x14
   21b74:      	b.lo	0x23ba8 <_mech_canonical_program_entry_v1_numeric_1282+0x6a28>
   21b78:      	mov	w0, #0xdc1e             ; =56350
   21b7c:      	movk	w0, #0x2, lsl #16
   21b80:      	sub	x6, x6, x0
   21b84:      	mov	x3, #0x1                ; =1
   21b88:      	stur	x4, [sp, #0x40]
   21b8c:      	stur	x5, [sp, #0x38]
   21b90:      	stur	x10, [sp, #0x30]
   21b94:      	ldur	x15, [sp, #0x48]
   21b98:      	mov	x10, x8
   21b9c:      	b	0x1eb18 <_mech_canonical_program_entry_v1_numeric_1282+0x1998>
   21ba0:      	mov	x21, x0
   21ba4:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   21ba8:      	mov	x21, x0
   21bac:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   21bb0:      	mov	x21, x0
   21bb4:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   21bb8:      	mov	x21, x0
   21bbc:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   21bc0:      	mov	x1, #0x512              ; =1298
   21bc4:      	ldur	x5, [sp]
   21bc8:      	str	x1, [x5, #0x48]
   21bcc:      	mov	x1, #0x0                ; =0
   21bd0:      	str	x1, [x19, #0x18]
   21bd4:      	mov	x2, #0x1000000000000000 ; =1152921504606846976
   21bd8:      	str	x2, [x19, #0x20]
   21bdc:      	mov	x2, #0x1                ; =1
   21be0:      	str	x2, [x19, #0x30]
   21be4:      	mov	x5, #0x101010101010101  ; =72340172838076673
   21be8:      	str	x5, [x19, #0x38]
   21bec:      	mov	x20, #0x2               ; =2
   21bf0:      	str	x20, [x19, #0x40]
   21bf4:      	mov	x5, #0x3                ; =3
   21bf8:      	str	x5, [x19, #0x48]
   21bfc:      	mov	x7, #0x4                ; =4
   21c00:      	str	x7, [x19, #0x50]
   21c04:      	mov	x7, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   21c08:      	str	x7, [x19, #0x78]
   21c0c:      	mov	x8, #0x3333333333333333 ; =3689348814741910323
   21c10:      	str	x8, [x19, #0x88]
   21c14:      	mov	x5, #0x38               ; =56
   21c18:      	str	x5, [x19, #0x90]
   21c1c:      	mov	x5, #0x3a               ; =58
   21c20:      	str	x5, [x19, #0x98]
   21c24:      	mov	x5, #0x5555555555555555 ; =6148914691236517205
   21c28:      	str	x5, [x19, #0xb0]
   21c2c:      	mov	x5, #0x3ffffffffffffff  ; =288230376151711743
   21c30:      	str	x5, [x19, #0xb8]
   21c34:      	str	x1, [x19, #0x188]
   21c38:      	str	x2, [x19, #0x190]
   21c3c:      	str	x22, [x19, #0x17a0]
   21c40:      	str	x23, [x19, #0x17a8]
   21c44:      	uxtb	w0, w0
   21c48:      	str	x0, [x19, #0x17b8]
   21c4c:      	add	x0, x22, #0x1
   21c50:      	str	x0, [x19, #0x17d0]
   21c54:      	mov	x28, x26
   21c58:      	str	x28, [x19, #0x4c60]
   21c5c:      	mov	w0, #0xc87e             ; =51326
   21c60:      	movk	w0, #0x1, lsl #16
   21c64:      	sub	x1, x3, x0
   21c68:      	str	x1, [x19, #0x4c68]
   21c6c:      	str	x4, [x19, #0x4c70]
   21c70:      	str	x22, [x19, #0x4f70]
   21c74:      	str	x23, [x19, #0x4f78]
   21c78:      	ldur	x2, [sp, #0x60]
   21c7c:      	str	x2, [x19, #0x5a20]
   21c80:      	add	x2, x11, #0x1
   21c84:      	str	x2, [x19, #0x5bb0]
   21c88:      	ldur	x26, [sp, #0xa0]
   21c8c:      	str	x26, [x19, #0x5bb8]
   21c90:      	ldur	x3, [sp, #0xa8]
   21c94:      	str	x3, [x19, #0x5bc0]
   21c98:      	ldur	x4, [sp, #0x90]
   21c9c:      	sub	x1, x4, x1
   21ca0:      	msub	x0, x2, x0, x1
   21ca4:      	str	x0, [x19, #0x5bc8]
   21ca8:      	str	x24, [x19, #0x5bd0]
   21cac:      	str	x15, [x19, #0x5bd8]
   21cb0:      	str	x6, [x19, #0x5be8]
   21cb4:      	ldur	x4, [sp, #0xb8]
   21cb8:      	str	x4, [x19, #0x5bf0]
   21cbc:      	str	x12, [x19, #0x5c00]
   21cc0:      	str	x9, [x19, #0x5c08]
   21cc4:      	str	x13, [x19, #0x5c18]
   21cc8:      	ldur	x13, [sp, #0xc0]
   21ccc:      	str	x13, [x19, #0x5c20]
   21cd0:      	ldr	x0, [x19, #0x4c60]
   21cd4:      	cmp	x0, #0x0
   21cd8:      	b.ne	0x1d720 <_mech_canonical_program_entry_v1_numeric_1282+0x5a0>
   21cdc:      	b	0x1d714 <_mech_canonical_program_entry_v1_numeric_1282+0x594>
   21ce0:      	mov	x21, x0
   21ce4:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   21ce8:      	mov	x21, x20
   21cec:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   21cf0:      	mov	x21, x0
   21cf4:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   21cf8:      	mov	x21, x20
   21cfc:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   21d00:      	mov	x2, #0x514              ; =1300
   21d04:      	str	x2, [x5, #0x48]
   21d08:      	mov	x2, #0x0                ; =0
   21d0c:      	str	x2, [x19, #0x18]
   21d10:      	mov	x5, #0x1000000000000000 ; =1152921504606846976
   21d14:      	str	x5, [x19, #0x20]
   21d18:      	mov	x5, #0x1                ; =1
   21d1c:      	str	x5, [x19, #0x30]
   21d20:      	mov	x6, #0x101010101010101  ; =72340172838076673
   21d24:      	str	x6, [x19, #0x38]
   21d28:      	mov	x20, #0x2               ; =2
   21d2c:      	str	x20, [x19, #0x40]
   21d30:      	mov	x6, #0x3                ; =3
   21d34:      	str	x6, [x19, #0x48]
   21d38:      	mov	x6, #0x4                ; =4
   21d3c:      	str	x6, [x19, #0x50]
   21d40:      	mov	x6, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   21d44:      	str	x6, [x19, #0x78]
   21d48:      	mov	x6, #0x3333333333333333 ; =3689348814741910323
   21d4c:      	str	x6, [x19, #0x88]
   21d50:      	mov	x6, #0x38               ; =56
   21d54:      	str	x6, [x19, #0x90]
   21d58:      	mov	x6, #0x3a               ; =58
   21d5c:      	str	x6, [x19, #0x98]
   21d60:      	mov	x6, #0x5555555555555555 ; =6148914691236517205
   21d64:      	str	x6, [x19, #0xb0]
   21d68:      	mov	x6, #0x3ffffffffffffff  ; =288230376151711743
   21d6c:      	str	x6, [x19, #0xb8]
   21d70:      	str	x2, [x19, #0x188]
   21d74:      	str	x5, [x19, #0x190]
   21d78:      	str	x22, [x19, #0x17a0]
   21d7c:      	str	x23, [x19, #0x17a8]
   21d80:      	uxtb	w8, w0
   21d84:      	str	x8, [x19, #0x17b8]
   21d88:      	str	x1, [x19, #0x17d8]
   21d8c:      	add	x10, x22, #0x2
   21d90:      	str	x10, [x19, #0x17e0]
   21d94:      	str	x28, [x19, #0x4c60]
   21d98:      	mov	w14, #0xc87e            ; =51326
   21d9c:      	movk	w14, #0x1, lsl #16
   21da0:      	sub	x0, x3, x14
   21da4:      	str	x0, [x19, #0x4c68]
   21da8:      	str	x4, [x19, #0x4c70]
   21dac:      	str	x22, [x19, #0x4f70]
   21db0:      	str	x23, [x19, #0x4f78]
   21db4:      	ldur	x5, [sp, #0x60]
   21db8:      	str	x5, [x19, #0x5a20]
   21dbc:      	add	x1, x11, #0x1
   21dc0:      	str	x1, [x19, #0x5bb0]
   21dc4:      	ldur	x26, [sp, #0xa0]
   21dc8:      	str	x26, [x19, #0x5bb8]
   21dcc:      	ldur	x7, [sp, #0xa8]
   21dd0:      	str	x7, [x19, #0x5bc0]
   21dd4:      	ldur	x4, [sp, #0x90]
   21dd8:      	sub	x0, x4, x0
   21ddc:      	msub	x0, x1, x14, x0
   21de0:      	str	x0, [x19, #0x5bc8]
   21de4:      	str	x24, [x19, #0x5bd0]
   21de8:      	str	x15, [x19, #0x5bd8]
   21dec:      	ldur	x28, [sp, #0xb0]
   21df0:      	str	x28, [x19, #0x5be8]
   21df4:      	ldur	x4, [sp, #0xb8]
   21df8:      	str	x4, [x19, #0x5bf0]
   21dfc:      	str	x12, [x19, #0x5c00]
   21e00:      	str	x9, [x19, #0x5c08]
   21e04:      	str	x13, [x19, #0x5c18]
   21e08:      	ldur	x13, [sp, #0xc0]
   21e0c:      	str	x13, [x19, #0x5c20]
   21e10:      	ldr	x0, [x19, #0x4c60]
   21e14:      	cmp	x0, #0x0
   21e18:      	b.ne	0x1d990 <_mech_canonical_program_entry_v1_numeric_1282+0x810>
   21e1c:      	b	0x1dbb0 <_mech_canonical_program_entry_v1_numeric_1282+0xa30>
   21e20:      	mov	x21, x0
   21e24:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   21e28:      	mov	x21, x20
   21e2c:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   21e30:      	mov	x21, x0
   21e34:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   21e38:      	mov	x21, x20
   21e3c:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   21e40:      	mov	x6, #0x516              ; =1302
   21e44:      	str	x6, [x5, #0x48]
   21e48:      	mov	x5, #0x0                ; =0
   21e4c:      	str	x5, [x19, #0x18]
   21e50:      	mov	x6, #0x1000000000000000 ; =1152921504606846976
   21e54:      	str	x6, [x19, #0x20]
   21e58:      	mov	x7, #0x1                ; =1
   21e5c:      	str	x7, [x19, #0x30]
   21e60:      	mov	x6, #0x101010101010101  ; =72340172838076673
   21e64:      	str	x6, [x19, #0x38]
   21e68:      	mov	x20, #0x2               ; =2
   21e6c:      	str	x20, [x19, #0x40]
   21e70:      	mov	x6, #0x3                ; =3
   21e74:      	str	x6, [x19, #0x48]
   21e78:      	mov	x6, #0x4                ; =4
   21e7c:      	str	x6, [x19, #0x50]
   21e80:      	mov	x6, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   21e84:      	str	x6, [x19, #0x78]
   21e88:      	mov	x6, #0x3333333333333333 ; =3689348814741910323
   21e8c:      	str	x6, [x19, #0x88]
   21e90:      	mov	x6, #0x38               ; =56
   21e94:      	str	x6, [x19, #0x90]
   21e98:      	mov	x6, #0x3a               ; =58
   21e9c:      	str	x6, [x19, #0x98]
   21ea0:      	mov	x6, #0x5555555555555555 ; =6148914691236517205
   21ea4:      	str	x6, [x19, #0xb0]
   21ea8:      	mov	x6, #0x3ffffffffffffff  ; =288230376151711743
   21eac:      	str	x6, [x19, #0xb8]
   21eb0:      	str	x5, [x19, #0x188]
   21eb4:      	str	x7, [x19, #0x190]
   21eb8:      	str	x22, [x19, #0x17a0]
   21ebc:      	str	x23, [x19, #0x17a8]
   21ec0:      	uxtb	w0, w0
   21ec4:      	str	x0, [x19, #0x17b8]
   21ec8:      	str	x1, [x19, #0x17d8]
   21ecc:      	str	x2, [x19, #0x17e8]
   21ed0:      	ldur	x0, [sp, #0xe8]
   21ed4:      	str	x0, [x19, #0x17f0]
   21ed8:      	str	x28, [x19, #0x4c60]
   21edc:      	mov	w5, #0xc87e             ; =51326
   21ee0:      	movk	w5, #0x1, lsl #16
   21ee4:      	sub	x6, x3, x5
   21ee8:      	str	x6, [x19, #0x4c68]
   21eec:      	str	x4, [x19, #0x4c70]
   21ef0:      	str	x22, [x19, #0x4f70]
   21ef4:      	str	x23, [x19, #0x4f78]
   21ef8:      	ldur	x14, [sp, #0x60]
   21efc:      	str	x14, [x19, #0x5a20]
   21f00:      	add	x10, x11, #0x1
   21f04:      	str	x10, [x19, #0x5bb0]
   21f08:      	ldur	x26, [sp, #0xa0]
   21f0c:      	str	x26, [x19, #0x5bb8]
   21f10:      	ldur	x7, [sp, #0xa8]
   21f14:      	str	x7, [x19, #0x5bc0]
   21f18:      	ldur	x4, [sp, #0x90]
   21f1c:      	sub	x14, x4, x6
   21f20:      	msub	x14, x10, x5, x14
   21f24:      	str	x14, [x19, #0x5bc8]
   21f28:      	str	x24, [x19, #0x5bd0]
   21f2c:      	str	x15, [x19, #0x5bd8]
   21f30:      	ldur	x8, [sp, #0xb0]
   21f34:      	str	x8, [x19, #0x5be8]
   21f38:      	ldur	x4, [sp, #0xb8]
   21f3c:      	str	x4, [x19, #0x5bf0]
   21f40:      	str	x12, [x19, #0x5c00]
   21f44:      	str	x9, [x19, #0x5c08]
   21f48:      	str	x13, [x19, #0x5c18]
   21f4c:      	ldur	x13, [sp, #0xc0]
   21f50:      	str	x13, [x19, #0x5c20]
   21f54:      	ldr	x0, [x19, #0x4c60]
   21f58:      	cmp	x0, #0x0
   21f5c:      	b.ne	0x1dc20 <_mech_canonical_program_entry_v1_numeric_1282+0xaa0>
   21f60:      	b	0x1de40 <_mech_canonical_program_entry_v1_numeric_1282+0xcc0>
   21f64:      	mov	x21, x0
   21f68:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   21f6c:      	mov	x21, x20
   21f70:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   21f74:      	mov	x21, x0
   21f78:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   21f7c:      	mov	x21, x20
   21f80:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   21f84:      	ldur	x21, [sp, #0xd8]
   21f88:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   21f8c:      	mov	x0, #0x530              ; =1328
   21f90:      	ldur	x2, [sp]
   21f94:      	str	x0, [x2, #0x48]
   21f98:      	mov	x2, #0x0                ; =0
   21f9c:      	str	x2, [x19, #0x18]
   21fa0:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   21fa4:      	str	x0, [x19, #0x20]
   21fa8:      	mov	x0, #0x1                ; =1
   21fac:      	str	x0, [x19, #0x30]
   21fb0:      	mov	x4, #0x101010101010101  ; =72340172838076673
   21fb4:      	str	x4, [x19, #0x38]
   21fb8:      	mov	x20, #0x2               ; =2
   21fbc:      	str	x20, [x19, #0x40]
   21fc0:      	mov	x4, #0x3                ; =3
   21fc4:      	str	x4, [x19, #0x48]
   21fc8:      	mov	x4, #0x4                ; =4
   21fcc:      	str	x4, [x19, #0x50]
   21fd0:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   21fd4:      	str	x4, [x19, #0x78]
   21fd8:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   21fdc:      	str	x4, [x19, #0x88]
   21fe0:      	mov	x4, #0x38               ; =56
   21fe4:      	str	x4, [x19, #0x90]
   21fe8:      	mov	x4, #0x3a               ; =58
   21fec:      	str	x4, [x19, #0x98]
   21ff0:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   21ff4:      	str	x4, [x19, #0xb0]
   21ff8:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   21ffc:      	str	x4, [x19, #0xb8]
   22000:      	str	x2, [x19, #0x188]
   22004:      	str	x0, [x19, #0x190]
   22008:      	str	x22, [x19, #0x17a0]
   2200c:      	str	x23, [x19, #0x17a8]
   22010:      	ldur	x25, [sp, #0xf0]
   22014:      	uxtb	w5, w25
   22018:      	str	x5, [x19, #0x17b8]
   2201c:      	str	x1, [x19, #0x1858]
   22020:      	mov	x15, x26
   22024:      	str	x15, [x19, #0x1860]
   22028:      	str	x22, [x19, #0x1868]
   2202c:      	ldur	x15, [sp, #0xe0]
   22030:      	str	x15, [x19, #0x1870]
   22034:      	ldur	x15, [sp, #0xd8]
   22038:      	uxtb	w10, w15
   2203c:      	str	x10, [x19, #0x1880]
   22040:      	add	x14, x1, #0x1
   22044:      	str	x14, [x19, #0x1890]
   22048:      	str	x28, [x19, #0x4c60]
   2204c:      	mov	w14, #0x2166            ; =8550
   22050:      	movk	w14, #0x1, lsl #16
   22054:      	sub	x14, x3, x14
   22058:      	str	x14, [x19, #0x4c68]
   2205c:      	ldur	x4, [sp, #0x98]
   22060:      	str	x4, [x19, #0x4c70]
   22064:      	str	x22, [x19, #0x4f70]
   22068:      	str	x23, [x19, #0x4f78]
   2206c:      	str	x1, [x19, #0x50c0]
   22070:      	mov	x15, x26
   22074:      	str	x15, [x19, #0x50c8]
   22078:      	str	x22, [x19, #0x50d0]
   2207c:      	ldur	x15, [sp, #0xe0]
   22080:      	str	x15, [x19, #0x50d8]
   22084:      	ldur	x8, [sp, #0x10]
   22088:      	str	x8, [x19, #0x50e0]
   2208c:      	str	x27, [x19, #0x50e8]
   22090:      	str	x24, [x19, #0x50f0]
   22094:      	ldur	x27, [sp, #0x78]
   22098:      	str	x27, [x19, #0x50f8]
   2209c:      	ldur	x26, [sp, #0x80]
   220a0:      	str	x26, [x19, #0x5100]
   220a4:      	ldur	x1, [sp, #0x60]
   220a8:      	str	x1, [x19, #0x5a20]
   220ac:      	add	x1, x11, #0x1
   220b0:      	str	x1, [x19, #0x5bb0]
   220b4:      	ldur	x26, [sp, #0xa0]
   220b8:      	str	x26, [x19, #0x5bb8]
   220bc:      	ldur	x7, [sp, #0xa8]
   220c0:      	str	x7, [x19, #0x5bc0]
   220c4:      	ldur	x4, [sp, #0x90]
   220c8:      	sub	x2, x4, x14
   220cc:      	mov	w3, #0xc87e             ; =51326
   220d0:      	movk	w3, #0x1, lsl #16
   220d4:      	msub	x1, x1, x3, x2
   220d8:      	str	x1, [x19, #0x5bc8]
   220dc:      	str	x0, [x19, #0x5bd0]
   220e0:      	ldur	x14, [sp, #0x20]
   220e4:      	str	x14, [x19, #0x5bd8]
   220e8:      	ldur	x8, [sp, #0xb0]
   220ec:      	str	x8, [x19, #0x5be8]
   220f0:      	ldur	x4, [sp, #0xb8]
   220f4:      	str	x4, [x19, #0x5bf0]
   220f8:      	str	x12, [x19, #0x5c00]
   220fc:      	str	x9, [x19, #0x5c08]
   22100:      	str	x13, [x19, #0x5c18]
   22104:      	ldur	x13, [sp, #0xc0]
   22108:      	str	x13, [x19, #0x5c20]
   2210c:      	ldr	x0, [x19, #0x4c60]
   22110:      	cmp	x0, #0x0
   22114:      	b.ne	0x1e2fc <_mech_canonical_program_entry_v1_numeric_1282+0x117c>
   22118:      	b	0x1e534 <_mech_canonical_program_entry_v1_numeric_1282+0x13b4>
   2211c:      	mov	x21, x20
   22120:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22124:      	mov	x21, x20
   22128:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   2212c:      	mov	x0, #0x531              ; =1329
   22130:      	ldur	x14, [sp]
   22134:      	str	x0, [x14, #0x48]
   22138:      	mov	x4, #0x0                ; =0
   2213c:      	str	x4, [x19, #0x18]
   22140:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   22144:      	str	x0, [x19, #0x20]
   22148:      	mov	x0, #0x1                ; =1
   2214c:      	mov	x21, x0
   22150:      	str	x0, [x19, #0x30]
   22154:      	mov	x0, #0x101010101010101  ; =72340172838076673
   22158:      	str	x0, [x19, #0x38]
   2215c:      	mov	x0, #0x2                ; =2
   22160:      	str	x0, [x19, #0x40]
   22164:      	mov	x0, #0x3                ; =3
   22168:      	str	x0, [x19, #0x48]
   2216c:      	mov	x0, #0x4                ; =4
   22170:      	str	x0, [x19, #0x50]
   22174:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   22178:      	str	x0, [x19, #0x78]
   2217c:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   22180:      	str	x0, [x19, #0x88]
   22184:      	mov	x0, #0x38               ; =56
   22188:      	str	x0, [x19, #0x90]
   2218c:      	mov	x5, #0x3a               ; =58
   22190:      	str	x5, [x19, #0x98]
   22194:      	mov	x5, #0x5555555555555555 ; =6148914691236517205
   22198:      	str	x5, [x19, #0xb0]
   2219c:      	mov	x5, #0x3ffffffffffffff  ; =288230376151711743
   221a0:      	str	x5, [x19, #0xb8]
   221a4:      	str	x4, [x19, #0x188]
   221a8:      	mov	x0, x21
   221ac:      	str	x0, [x19, #0x190]
   221b0:      	str	x22, [x19, #0x17a0]
   221b4:      	str	x23, [x19, #0x17a8]
   221b8:      	ldur	x25, [sp, #0xf0]
   221bc:      	uxtb	w8, w25
   221c0:      	str	x8, [x19, #0x17b8]
   221c4:      	str	x1, [x19, #0x1858]
   221c8:      	mov	x15, x26
   221cc:      	str	x15, [x19, #0x1860]
   221d0:      	str	x22, [x19, #0x1868]
   221d4:      	ldur	x15, [sp, #0xe0]
   221d8:      	str	x15, [x19, #0x1870]
   221dc:      	ldur	x15, [sp, #0xd8]
   221e0:      	uxtb	w14, w15
   221e4:      	str	x14, [x19, #0x1880]
   221e8:      	str	x2, [x19, #0x1898]
   221ec:      	str	x28, [x19, #0x4c60]
   221f0:      	mov	w1, #0x2166             ; =8550
   221f4:      	movk	w1, #0x1, lsl #16
   221f8:      	sub	x1, x3, x1
   221fc:      	str	x1, [x19, #0x4c68]
   22200:      	ldur	x4, [sp, #0x98]
   22204:      	str	x4, [x19, #0x4c70]
   22208:      	ldur	x14, [sp, #0x60]
   2220c:      	str	x14, [x19, #0x5a20]
   22210:      	add	x2, x11, #0x1
   22214:      	str	x2, [x19, #0x5bb0]
   22218:      	ldur	x26, [sp, #0xa0]
   2221c:      	str	x26, [x19, #0x5bb8]
   22220:      	ldur	x7, [sp, #0xa8]
   22224:      	str	x7, [x19, #0x5bc0]
   22228:      	ldur	x4, [sp, #0x90]
   2222c:      	sub	x1, x4, x1
   22230:      	mov	w3, #0xc87e             ; =51326
   22234:      	movk	w3, #0x1, lsl #16
   22238:      	msub	x0, x2, x3, x1
   2223c:      	str	x0, [x19, #0x5bc8]
   22240:      	mov	x0, x21
   22244:      	str	x0, [x19, #0x5bd0]
   22248:      	ldur	x14, [sp, #0x20]
   2224c:      	str	x14, [x19, #0x5bd8]
   22250:      	ldur	x8, [sp, #0xb0]
   22254:      	str	x8, [x19, #0x5be8]
   22258:      	ldur	x4, [sp, #0xb8]
   2225c:      	str	x4, [x19, #0x5bf0]
   22260:      	str	x12, [x19, #0x5c00]
   22264:      	str	x9, [x19, #0x5c08]
   22268:      	str	x13, [x19, #0x5c18]
   2226c:      	ldur	x13, [sp, #0xc0]
   22270:      	str	x13, [x19, #0x5c20]
   22274:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22278:      	mov	x0, #0x532              ; =1330
   2227c:      	ldur	x5, [sp]
   22280:      	str	x0, [x5, #0x48]
   22284:      	mov	x5, #0x0                ; =0
   22288:      	str	x5, [x19, #0x18]
   2228c:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   22290:      	str	x0, [x19, #0x20]
   22294:      	mov	x0, #0x1                ; =1
   22298:      	str	x0, [x19, #0x30]
   2229c:      	mov	x6, #0x101010101010101  ; =72340172838076673
   222a0:      	str	x6, [x19, #0x38]
   222a4:      	mov	x20, #0x2               ; =2
   222a8:      	str	x20, [x19, #0x40]
   222ac:      	mov	x6, #0x3                ; =3
   222b0:      	str	x6, [x19, #0x48]
   222b4:      	mov	x6, #0x4                ; =4
   222b8:      	str	x6, [x19, #0x50]
   222bc:      	mov	x6, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   222c0:      	str	x6, [x19, #0x78]
   222c4:      	mov	x6, #0x3333333333333333 ; =3689348814741910323
   222c8:      	str	x6, [x19, #0x88]
   222cc:      	mov	x6, #0x38               ; =56
   222d0:      	str	x6, [x19, #0x90]
   222d4:      	mov	x6, #0x3a               ; =58
   222d8:      	str	x6, [x19, #0x98]
   222dc:      	mov	x6, #0x5555555555555555 ; =6148914691236517205
   222e0:      	str	x6, [x19, #0xb0]
   222e4:      	mov	x6, #0x3ffffffffffffff  ; =288230376151711743
   222e8:      	str	x6, [x19, #0xb8]
   222ec:      	str	x5, [x19, #0x188]
   222f0:      	str	x0, [x19, #0x190]
   222f4:      	str	x22, [x19, #0x17a0]
   222f8:      	str	x23, [x19, #0x17a8]
   222fc:      	ldur	x25, [sp, #0xf0]
   22300:      	uxtb	w5, w25
   22304:      	str	x5, [x19, #0x17b8]
   22308:      	str	x1, [x19, #0x1858]
   2230c:      	mov	x15, x26
   22310:      	str	x15, [x19, #0x1860]
   22314:      	str	x22, [x19, #0x1868]
   22318:      	ldur	x15, [sp, #0xe0]
   2231c:      	str	x15, [x19, #0x1870]
   22320:      	ldur	x15, [sp, #0xd8]
   22324:      	uxtb	w5, w15
   22328:      	str	x5, [x19, #0x1880]
   2232c:      	str	x2, [x19, #0x1898]
   22330:      	str	x4, [x19, #0x18a0]
   22334:      	str	x28, [x19, #0x4c60]
   22338:      	mov	w2, #0x2166             ; =8550
   2233c:      	movk	w2, #0x1, lsl #16
   22340:      	sub	x2, x3, x2
   22344:      	str	x2, [x19, #0x4c68]
   22348:      	ldur	x4, [sp, #0x98]
   2234c:      	str	x4, [x19, #0x4c70]
   22350:      	str	x22, [x19, #0x4f70]
   22354:      	str	x23, [x19, #0x4f78]
   22358:      	str	x1, [x19, #0x50c0]
   2235c:      	mov	x15, x26
   22360:      	str	x15, [x19, #0x50c8]
   22364:      	str	x22, [x19, #0x50d0]
   22368:      	ldur	x15, [sp, #0xe0]
   2236c:      	str	x15, [x19, #0x50d8]
   22370:      	ldur	x24, [sp, #0x10]
   22374:      	str	x24, [x19, #0x50e0]
   22378:      	str	x27, [x19, #0x50e8]
   2237c:      	ldur	x24, [sp, #0x70]
   22380:      	str	x24, [x19, #0x50f0]
   22384:      	ldur	x24, [sp, #0x78]
   22388:      	str	x24, [x19, #0x50f8]
   2238c:      	ldur	x26, [sp, #0x80]
   22390:      	str	x26, [x19, #0x5100]
   22394:      	ldur	x14, [sp, #0x60]
   22398:      	str	x14, [x19, #0x5a20]
   2239c:      	add	x14, x11, #0x1
   223a0:      	str	x14, [x19, #0x5bb0]
   223a4:      	ldur	x26, [sp, #0xa0]
   223a8:      	str	x26, [x19, #0x5bb8]
   223ac:      	ldur	x7, [sp, #0xa8]
   223b0:      	str	x7, [x19, #0x5bc0]
   223b4:      	ldur	x4, [sp, #0x90]
   223b8:      	sub	x1, x4, x2
   223bc:      	mov	w2, #0xc87e             ; =51326
   223c0:      	movk	w2, #0x1, lsl #16
   223c4:      	msub	x1, x14, x2, x1
   223c8:      	str	x1, [x19, #0x5bc8]
   223cc:      	str	x0, [x19, #0x5bd0]
   223d0:      	ldur	x14, [sp, #0x20]
   223d4:      	str	x14, [x19, #0x5bd8]
   223d8:      	ldur	x8, [sp, #0xb0]
   223dc:      	str	x8, [x19, #0x5be8]
   223e0:      	ldur	x4, [sp, #0xb8]
   223e4:      	str	x4, [x19, #0x5bf0]
   223e8:      	str	x12, [x19, #0x5c00]
   223ec:      	str	x9, [x19, #0x5c08]
   223f0:      	str	x13, [x19, #0x5c18]
   223f4:      	ldur	x13, [sp, #0xc0]
   223f8:      	str	x13, [x19, #0x5c20]
   223fc:      	ldr	x0, [x19, #0x4c60]
   22400:      	cmp	x0, #0x0
   22404:      	b.ne	0x1e5b4 <_mech_canonical_program_entry_v1_numeric_1282+0x1434>
   22408:      	b	0x1e7e4 <_mech_canonical_program_entry_v1_numeric_1282+0x1664>
   2240c:      	mov	x21, x20
   22410:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22414:      	mov	x21, x20
   22418:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   2241c:      	mov	x0, #0x534              ; =1332
   22420:      	ldur	x1, [sp]
   22424:      	str	x0, [x1, #0x48]
   22428:      	mov	x1, #0x0                ; =0
   2242c:      	str	x1, [x19, #0x18]
   22430:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   22434:      	str	x0, [x19, #0x20]
   22438:      	mov	x0, #0x1                ; =1
   2243c:      	str	x0, [x19, #0x30]
   22440:      	mov	x4, #0x101010101010101  ; =72340172838076673
   22444:      	str	x4, [x19, #0x38]
   22448:      	mov	x20, #0x2               ; =2
   2244c:      	str	x20, [x19, #0x40]
   22450:      	mov	x4, #0x3                ; =3
   22454:      	str	x4, [x19, #0x48]
   22458:      	mov	x4, #0x4                ; =4
   2245c:      	str	x4, [x19, #0x50]
   22460:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   22464:      	str	x4, [x19, #0x78]
   22468:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   2246c:      	str	x4, [x19, #0x88]
   22470:      	mov	x4, #0x38               ; =56
   22474:      	str	x4, [x19, #0x90]
   22478:      	mov	x4, #0x3a               ; =58
   2247c:      	str	x4, [x19, #0x98]
   22480:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   22484:      	str	x4, [x19, #0xb0]
   22488:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   2248c:      	str	x4, [x19, #0xb8]
   22490:      	str	x1, [x19, #0x188]
   22494:      	str	x0, [x19, #0x190]
   22498:      	str	x22, [x19, #0x17a0]
   2249c:      	str	x23, [x19, #0x17a8]
   224a0:      	ldur	x25, [sp, #0xf0]
   224a4:      	uxtb	w1, w25
   224a8:      	str	x1, [x19, #0x17b8]
   224ac:      	ldur	x1, [sp, #0x18]
   224b0:      	str	x1, [x19, #0x1858]
   224b4:      	mov	x15, x26
   224b8:      	str	x15, [x19, #0x1860]
   224bc:      	str	x22, [x19, #0x1868]
   224c0:      	ldur	x15, [sp, #0xe0]
   224c4:      	str	x15, [x19, #0x1870]
   224c8:      	ldur	x15, [sp, #0xd8]
   224cc:      	uxtb	w1, w15
   224d0:      	str	x1, [x19, #0x1880]
   224d4:      	str	x27, [x19, #0x18a8]
   224d8:      	add	x4, x2, #0x2
   224dc:      	str	x4, [x19, #0x18b0]
   224e0:      	str	x28, [x19, #0x4c60]
   224e4:      	mov	w5, #0x2166             ; =8550
   224e8:      	movk	w5, #0x1, lsl #16
   224ec:      	sub	x5, x3, x5
   224f0:      	str	x5, [x19, #0x4c68]
   224f4:      	ldur	x4, [sp, #0x98]
   224f8:      	str	x4, [x19, #0x4c70]
   224fc:      	str	x22, [x19, #0x4f70]
   22500:      	str	x23, [x19, #0x4f78]
   22504:      	ldur	x27, [sp, #0x18]
   22508:      	str	x27, [x19, #0x50c0]
   2250c:      	mov	x15, x26
   22510:      	str	x15, [x19, #0x50c8]
   22514:      	str	x22, [x19, #0x50d0]
   22518:      	ldur	x15, [sp, #0xe0]
   2251c:      	str	x15, [x19, #0x50d8]
   22520:      	ldur	x24, [sp, #0x10]
   22524:      	str	x24, [x19, #0x50e0]
   22528:      	ldur	x26, [sp, #0x68]
   2252c:      	str	x26, [x19, #0x50e8]
   22530:      	ldur	x27, [sp, #0x70]
   22534:      	str	x27, [x19, #0x50f0]
   22538:      	ldur	x24, [sp, #0x78]
   2253c:      	str	x24, [x19, #0x50f8]
   22540:      	ldur	x26, [sp, #0x80]
   22544:      	str	x26, [x19, #0x5100]
   22548:      	ldur	x14, [sp, #0x60]
   2254c:      	str	x14, [x19, #0x5a20]
   22550:      	add	x1, x11, #0x1
   22554:      	str	x1, [x19, #0x5bb0]
   22558:      	ldur	x26, [sp, #0xa0]
   2255c:      	str	x26, [x19, #0x5bb8]
   22560:      	ldur	x7, [sp, #0xa8]
   22564:      	str	x7, [x19, #0x5bc0]
   22568:      	ldur	x4, [sp, #0x90]
   2256c:      	sub	x2, x4, x5
   22570:      	mov	w3, #0xc87e             ; =51326
   22574:      	movk	w3, #0x1, lsl #16
   22578:      	msub	x1, x1, x3, x2
   2257c:      	str	x1, [x19, #0x5bc8]
   22580:      	str	x0, [x19, #0x5bd0]
   22584:      	ldur	x14, [sp, #0x20]
   22588:      	str	x14, [x19, #0x5bd8]
   2258c:      	ldur	x8, [sp, #0xb0]
   22590:      	str	x8, [x19, #0x5be8]
   22594:      	ldur	x4, [sp, #0xb8]
   22598:      	str	x4, [x19, #0x5bf0]
   2259c:      	str	x12, [x19, #0x5c00]
   225a0:      	str	x9, [x19, #0x5c08]
   225a4:      	str	x13, [x19, #0x5c18]
   225a8:      	ldur	x13, [sp, #0xc0]
   225ac:      	str	x13, [x19, #0x5c20]
   225b0:      	ldr	x0, [x19, #0x4c60]
   225b4:      	cmp	x0, #0x0
   225b8:      	b.ne	0x1e85c <_mech_canonical_program_entry_v1_numeric_1282+0x16dc>
   225bc:      	b	0x1ea88 <_mech_canonical_program_entry_v1_numeric_1282+0x1908>
   225c0:      	mov	x21, x20
   225c4:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   225c8:      	mov	x21, x20
   225cc:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   225d0:      	mov	x21, x20
   225d4:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   225d8:      	mov	x0, #0x54e              ; =1358
   225dc:      	ldur	x1, [sp]
   225e0:      	str	x0, [x1, #0x48]
   225e4:      	mov	x0, #0x0                ; =0
   225e8:      	str	x0, [x19, #0x18]
   225ec:      	mov	x1, #0x1000000000000000 ; =1152921504606846976
   225f0:      	str	x1, [x19, #0x20]
   225f4:      	mov	x5, #0x1                ; =1
   225f8:      	str	x5, [x19, #0x30]
   225fc:      	mov	x1, #0x101010101010101  ; =72340172838076673
   22600:      	str	x1, [x19, #0x38]
   22604:      	mov	x25, #0x2               ; =2
   22608:      	str	x25, [x19, #0x40]
   2260c:      	mov	x1, #0x3                ; =3
   22610:      	str	x1, [x19, #0x48]
   22614:      	mov	x1, #0x4                ; =4
   22618:      	str	x1, [x19, #0x50]
   2261c:      	mov	x1, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   22620:      	str	x1, [x19, #0x78]
   22624:      	mov	x1, #0x3333333333333333 ; =3689348814741910323
   22628:      	str	x1, [x19, #0x88]
   2262c:      	mov	x1, #0x38               ; =56
   22630:      	str	x1, [x19, #0x90]
   22634:      	mov	x1, #0x3a               ; =58
   22638:      	str	x1, [x19, #0x98]
   2263c:      	mov	x1, #0x5555555555555555 ; =6148914691236517205
   22640:      	str	x1, [x19, #0xb0]
   22644:      	mov	x1, #0x3ffffffffffffff  ; =288230376151711743
   22648:      	str	x1, [x19, #0xb8]
   2264c:      	str	x0, [x19, #0x188]
   22650:      	str	x5, [x19, #0x190]
   22654:      	str	x22, [x19, #0x17a0]
   22658:      	str	x23, [x19, #0x17a8]
   2265c:      	ldur	x0, [sp, #0xf0]
   22660:      	uxtb	w0, w0
   22664:      	str	x0, [x19, #0x17b8]
   22668:      	ldur	x0, [sp, #0x18]
   2266c:      	str	x0, [x19, #0x1858]
   22670:      	mov	x2, x26
   22674:      	str	x2, [x19, #0x1860]
   22678:      	str	x22, [x19, #0x1868]
   2267c:      	ldur	x14, [sp, #0xe0]
   22680:      	str	x14, [x19, #0x1870]
   22684:      	ldur	x0, [sp, #0xd8]
   22688:      	uxtb	w0, w0
   2268c:      	str	x0, [x19, #0x1880]
   22690:      	str	x27, [x19, #0x1918]
   22694:      	str	x7, [x19, #0x1920]
   22698:      	str	x22, [x19, #0x1928]
   2269c:      	ldur	x0, [sp, #0xe0]
   226a0:      	str	x0, [x19, #0x1930]
   226a4:      	uxtb	w0, w10
   226a8:      	str	x0, [x19, #0x1940]
   226ac:      	add	x0, x27, #0x1
   226b0:      	str	x0, [x19, #0x1950]
   226b4:      	str	x28, [x19, #0x4c60]
   226b8:      	mov	w0, #0xdc1e             ; =56350
   226bc:      	movk	w0, #0x2, lsl #16
   226c0:      	sub	x4, x6, x0
   226c4:      	str	x4, [x19, #0x4c68]
   226c8:      	ldur	x8, [sp, #0x98]
   226cc:      	str	x8, [x19, #0x4c70]
   226d0:      	str	x22, [x19, #0x4f70]
   226d4:      	str	x23, [x19, #0x4f78]
   226d8:      	ldur	x0, [sp, #0x18]
   226dc:      	str	x0, [x19, #0x50c0]
   226e0:      	mov	x0, x26
   226e4:      	str	x0, [x19, #0x50c8]
   226e8:      	str	x22, [x19, #0x50d0]
   226ec:      	ldur	x0, [sp, #0xe0]
   226f0:      	str	x0, [x19, #0x50d8]
   226f4:      	ldur	x0, [sp, #0x10]
   226f8:      	str	x0, [x19, #0x50e0]
   226fc:      	ldur	x26, [sp, #0x68]
   22700:      	str	x26, [x19, #0x50e8]
   22704:      	ldur	x0, [sp, #0x70]
   22708:      	str	x0, [x19, #0x50f0]
   2270c:      	ldur	x0, [sp, #0x78]
   22710:      	str	x0, [x19, #0x50f8]
   22714:      	ldur	x26, [sp, #0x80]
   22718:      	str	x26, [x19, #0x5100]
   2271c:      	str	x27, [x19, #0x52a8]
   22720:      	str	x7, [x19, #0x52b0]
   22724:      	str	x22, [x19, #0x52b8]
   22728:      	ldur	x0, [sp, #0xe0]
   2272c:      	str	x0, [x19, #0x52c0]
   22730:      	ldur	x2, [sp, #0x28]
   22734:      	str	x2, [x19, #0x52c8]
   22738:      	str	x15, [x19, #0x52d0]
   2273c:      	str	x24, [x19, #0x52d8]
   22740:      	ldur	x1, [sp, #0x38]
   22744:      	str	x1, [x19, #0x52e0]
   22748:      	ldur	x0, [sp, #0x40]
   2274c:      	str	x0, [x19, #0x52e8]
   22750:      	ldur	x14, [sp, #0x60]
   22754:      	str	x14, [x19, #0x5a20]
   22758:      	add	x11, x11, #0x1
   2275c:      	str	x11, [x19, #0x5bb0]
   22760:      	ldur	x26, [sp, #0xa0]
   22764:      	str	x26, [x19, #0x5bb8]
   22768:      	ldur	x7, [sp, #0xa8]
   2276c:      	str	x7, [x19, #0x5bc0]
   22770:      	ldur	x0, [sp, #0x90]
   22774:      	sub	x14, x0, x4
   22778:      	mov	w15, #0xc87e            ; =51326
   2277c:      	movk	w15, #0x1, lsl #16
   22780:      	msub	x14, x11, x15, x14
   22784:      	str	x14, [x19, #0x5bc8]
   22788:      	str	x5, [x19, #0x5bd0]
   2278c:      	ldur	x14, [sp, #0x20]
   22790:      	str	x14, [x19, #0x5bd8]
   22794:      	str	x5, [x19, #0x5be8]
   22798:      	str	x3, [x19, #0x5bf0]
   2279c:      	str	x12, [x19, #0x5c00]
   227a0:      	str	x9, [x19, #0x5c08]
   227a4:      	str	x13, [x19, #0x5c18]
   227a8:      	ldur	x13, [sp, #0xc0]
   227ac:      	str	x13, [x19, #0x5c20]
   227b0:      	ldr	x0, [x19, #0x4c60]
   227b4:      	cmp	x0, #0x0
   227b8:      	b.ne	0x1efc0 <_mech_canonical_program_entry_v1_numeric_1282+0x1e40>
   227bc:      	b	0x1f1e4 <_mech_canonical_program_entry_v1_numeric_1282+0x2064>
   227c0:      	mov	x21, x25
   227c4:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   227c8:      	mov	x21, x25
   227cc:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   227d0:      	mov	x0, #0x554              ; =1364
   227d4:      	ldur	x1, [sp]
   227d8:      	str	x0, [x1, #0x48]
   227dc:      	mov	x1, #0x0                ; =0
   227e0:      	str	x1, [x19, #0x18]
   227e4:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   227e8:      	str	x0, [x19, #0x20]
   227ec:      	mov	x0, #0x1                ; =1
   227f0:      	mov	x21, x0
   227f4:      	str	x0, [x19, #0x30]
   227f8:      	mov	x0, #0x101010101010101  ; =72340172838076673
   227fc:      	str	x0, [x19, #0x38]
   22800:      	mov	x0, #0x2                ; =2
   22804:      	str	x0, [x19, #0x40]
   22808:      	mov	x0, #0x3                ; =3
   2280c:      	str	x0, [x19, #0x48]
   22810:      	mov	x0, #0x4                ; =4
   22814:      	str	x0, [x19, #0x50]
   22818:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   2281c:      	str	x0, [x19, #0x78]
   22820:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   22824:      	str	x0, [x19, #0x88]
   22828:      	mov	x0, #0x38               ; =56
   2282c:      	str	x0, [x19, #0x90]
   22830:      	mov	x0, #0x3a               ; =58
   22834:      	str	x0, [x19, #0x98]
   22838:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   2283c:      	str	x0, [x19, #0xb0]
   22840:      	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
   22844:      	str	x0, [x19, #0xb8]
   22848:      	str	x1, [x19, #0x188]
   2284c:      	mov	x0, x21
   22850:      	str	x0, [x19, #0x190]
   22854:      	str	x22, [x19, #0x17a0]
   22858:      	str	x23, [x19, #0x17a8]
   2285c:      	ldur	x25, [sp, #0xf0]
   22860:      	uxtb	w0, w25
   22864:      	str	x0, [x19, #0x17b8]
   22868:      	ldur	x0, [sp, #0x18]
   2286c:      	str	x0, [x19, #0x1858]
   22870:      	mov	x15, x26
   22874:      	str	x15, [x19, #0x1860]
   22878:      	str	x22, [x19, #0x1868]
   2287c:      	ldur	x15, [sp, #0xe0]
   22880:      	str	x15, [x19, #0x1870]
   22884:      	ldur	x15, [sp, #0xd8]
   22888:      	uxtb	w4, w15
   2288c:      	str	x4, [x19, #0x1880]
   22890:      	str	x27, [x19, #0x1918]
   22894:      	str	x7, [x19, #0x1920]
   22898:      	str	x22, [x19, #0x1928]
   2289c:      	ldur	x15, [sp, #0xe0]
   228a0:      	str	x15, [x19, #0x1930]
   228a4:      	uxtb	w10, w10
   228a8:      	str	x10, [x19, #0x1940]
   228ac:      	str	x14, [x19, #0x1958]
   228b0:      	str	x28, [x19, #0x4c60]
   228b4:      	mov	w14, #0xdc1e            ; =56350
   228b8:      	movk	w14, #0x2, lsl #16
   228bc:      	sub	x14, x6, x14
   228c0:      	str	x14, [x19, #0x4c68]
   228c4:      	ldur	x4, [sp, #0x98]
   228c8:      	str	x4, [x19, #0x4c70]
   228cc:      	ldur	x0, [sp, #0x60]
   228d0:      	str	x0, [x19, #0x5a20]
   228d4:      	add	x15, x11, #0x1
   228d8:      	str	x15, [x19, #0x5bb0]
   228dc:      	ldur	x26, [sp, #0xa0]
   228e0:      	str	x26, [x19, #0x5bb8]
   228e4:      	ldur	x7, [sp, #0xa8]
   228e8:      	str	x7, [x19, #0x5bc0]
   228ec:      	ldur	x4, [sp, #0x90]
   228f0:      	sub	x1, x4, x14
   228f4:      	mov	w2, #0xc87e             ; =51326
   228f8:      	movk	w2, #0x1, lsl #16
   228fc:      	msub	x0, x15, x2, x1
   22900:      	str	x0, [x19, #0x5bc8]
   22904:      	mov	x0, x21
   22908:      	str	x0, [x19, #0x5bd0]
   2290c:      	ldur	x14, [sp, #0x20]
   22910:      	str	x14, [x19, #0x5bd8]
   22914:      	str	x0, [x19, #0x5be8]
   22918:      	str	x3, [x19, #0x5bf0]
   2291c:      	str	x12, [x19, #0x5c00]
   22920:      	str	x9, [x19, #0x5c08]
   22924:      	str	x13, [x19, #0x5c18]
   22928:      	ldur	x13, [sp, #0xc0]
   2292c:      	str	x13, [x19, #0x5c20]
   22930:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22934:      	mov	x5, #0x555              ; =1365
   22938:      	ldur	x8, [sp]
   2293c:      	str	x5, [x8, #0x48]
   22940:      	mov	x21, #0x0               ; =0
   22944:      	str	x21, [x19, #0x18]
   22948:      	mov	x5, #0x1000000000000000 ; =1152921504606846976
   2294c:      	str	x5, [x19, #0x20]
   22950:      	mov	x5, #0x1                ; =1
   22954:      	str	x5, [x19, #0x30]
   22958:      	mov	x8, #0x101010101010101  ; =72340172838076673
   2295c:      	str	x8, [x19, #0x38]
   22960:      	mov	x20, #0x2               ; =2
   22964:      	str	x20, [x19, #0x40]
   22968:      	mov	x8, #0x3                ; =3
   2296c:      	str	x8, [x19, #0x48]
   22970:      	mov	x8, #0x4                ; =4
   22974:      	str	x8, [x19, #0x50]
   22978:      	mov	x8, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   2297c:      	str	x8, [x19, #0x78]
   22980:      	mov	x8, #0x3333333333333333 ; =3689348814741910323
   22984:      	str	x8, [x19, #0x88]
   22988:      	mov	x8, #0x38               ; =56
   2298c:      	str	x8, [x19, #0x90]
   22990:      	mov	x8, #0x3a               ; =58
   22994:      	str	x8, [x19, #0x98]
   22998:      	mov	x8, #0x5555555555555555 ; =6148914691236517205
   2299c:      	str	x8, [x19, #0xb0]
   229a0:      	mov	x8, #0x3ffffffffffffff  ; =288230376151711743
   229a4:      	str	x8, [x19, #0xb8]
   229a8:      	str	x21, [x19, #0x188]
   229ac:      	str	x5, [x19, #0x190]
   229b0:      	str	x22, [x19, #0x17a0]
   229b4:      	str	x23, [x19, #0x17a8]
   229b8:      	ldur	x25, [sp, #0xf0]
   229bc:      	uxtb	w8, w25
   229c0:      	str	x8, [x19, #0x17b8]
   229c4:      	ldur	x8, [sp, #0x18]
   229c8:      	str	x8, [x19, #0x1858]
   229cc:      	mov	x8, x26
   229d0:      	str	x8, [x19, #0x1860]
   229d4:      	str	x22, [x19, #0x1868]
   229d8:      	ldur	x8, [sp, #0xe0]
   229dc:      	str	x8, [x19, #0x1870]
   229e0:      	ldur	x8, [sp, #0xd8]
   229e4:      	uxtb	w8, w8
   229e8:      	str	x8, [x19, #0x1880]
   229ec:      	str	x27, [x19, #0x1918]
   229f0:      	str	x7, [x19, #0x1920]
   229f4:      	str	x22, [x19, #0x1928]
   229f8:      	ldur	x8, [sp, #0xe0]
   229fc:      	str	x8, [x19, #0x1930]
   22a00:      	uxtb	w8, w10
   22a04:      	str	x8, [x19, #0x1940]
   22a08:      	str	x14, [x19, #0x1958]
   22a0c:      	str	x4, [x19, #0x1970]
   22a10:      	str	x28, [x19, #0x4c60]
   22a14:      	mov	w4, #0xdc1e             ; =56350
   22a18:      	movk	w4, #0x2, lsl #16
   22a1c:      	sub	x4, x6, x4
   22a20:      	str	x4, [x19, #0x4c68]
   22a24:      	ldur	x14, [sp, #0x98]
   22a28:      	str	x14, [x19, #0x4c70]
   22a2c:      	str	x22, [x19, #0x4f70]
   22a30:      	str	x23, [x19, #0x4f78]
   22a34:      	ldur	x6, [sp, #0x18]
   22a38:      	str	x6, [x19, #0x50c0]
   22a3c:      	mov	x6, x26
   22a40:      	str	x6, [x19, #0x50c8]
   22a44:      	str	x22, [x19, #0x50d0]
   22a48:      	ldur	x6, [sp, #0xe0]
   22a4c:      	str	x6, [x19, #0x50d8]
   22a50:      	ldur	x6, [sp, #0x10]
   22a54:      	str	x6, [x19, #0x50e0]
   22a58:      	ldur	x26, [sp, #0x68]
   22a5c:      	str	x26, [x19, #0x50e8]
   22a60:      	ldur	x6, [sp, #0x70]
   22a64:      	str	x6, [x19, #0x50f0]
   22a68:      	ldur	x6, [sp, #0x78]
   22a6c:      	str	x6, [x19, #0x50f8]
   22a70:      	ldur	x26, [sp, #0x80]
   22a74:      	str	x26, [x19, #0x5100]
   22a78:      	str	x27, [x19, #0x52a8]
   22a7c:      	str	x7, [x19, #0x52b0]
   22a80:      	str	x22, [x19, #0x52b8]
   22a84:      	ldur	x6, [sp, #0xe0]
   22a88:      	str	x6, [x19, #0x52c0]
   22a8c:      	str	x2, [x19, #0x52c8]
   22a90:      	str	x15, [x19, #0x52d0]
   22a94:      	str	x24, [x19, #0x52d8]
   22a98:      	str	x1, [x19, #0x52e0]
   22a9c:      	str	x0, [x19, #0x52e8]
   22aa0:      	ldur	x14, [sp, #0x60]
   22aa4:      	str	x14, [x19, #0x5a20]
   22aa8:      	add	x0, x11, #0x1
   22aac:      	str	x0, [x19, #0x5bb0]
   22ab0:      	ldur	x26, [sp, #0xa0]
   22ab4:      	str	x26, [x19, #0x5bb8]
   22ab8:      	ldur	x7, [sp, #0xa8]
   22abc:      	str	x7, [x19, #0x5bc0]
   22ac0:      	ldur	x1, [sp, #0x90]
   22ac4:      	sub	x1, x1, x4
   22ac8:      	mov	w2, #0xc87e             ; =51326
   22acc:      	movk	w2, #0x1, lsl #16
   22ad0:      	msub	x0, x0, x2, x1
   22ad4:      	str	x0, [x19, #0x5bc8]
   22ad8:      	str	x5, [x19, #0x5bd0]
   22adc:      	ldur	x14, [sp, #0x20]
   22ae0:      	str	x14, [x19, #0x5bd8]
   22ae4:      	str	x5, [x19, #0x5be8]
   22ae8:      	str	x3, [x19, #0x5bf0]
   22aec:      	str	x12, [x19, #0x5c00]
   22af0:      	str	x9, [x19, #0x5c08]
   22af4:      	str	x13, [x19, #0x5c18]
   22af8:      	ldur	x13, [sp, #0xc0]
   22afc:      	str	x13, [x19, #0x5c20]
   22b00:      	ldr	x0, [x19, #0x4c60]
   22b04:      	cmp	x0, #0x0
   22b08:      	b.ne	0x1f290 <_mech_canonical_program_entry_v1_numeric_1282+0x2110>
   22b0c:      	b	0x1f4c4 <_mech_canonical_program_entry_v1_numeric_1282+0x2344>
   22b10:      	mov	x21, x20
   22b14:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22b18:      	mov	x21, x20
   22b1c:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22b20:      	mov	x0, #0x5e8              ; =1512
   22b24:      	ldur	x1, [sp]
   22b28:      	str	x0, [x1, #0x48]
   22b2c:      	mov	x0, #0x0                ; =0
   22b30:      	str	x0, [x19, #0x18]
   22b34:      	mov	x1, #0x1000000000000000 ; =1152921504606846976
   22b38:      	str	x1, [x19, #0x20]
   22b3c:      	mov	x1, #0x1                ; =1
   22b40:      	str	x1, [x19, #0x30]
   22b44:      	mov	x2, #0x101010101010101  ; =72340172838076673
   22b48:      	str	x2, [x19, #0x38]
   22b4c:      	mov	x20, #0x2               ; =2
   22b50:      	str	x20, [x19, #0x40]
   22b54:      	mov	x4, #0x3                ; =3
   22b58:      	str	x4, [x19, #0x48]
   22b5c:      	mov	x4, #0x4                ; =4
   22b60:      	str	x4, [x19, #0x50]
   22b64:      	mov	x5, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   22b68:      	str	x5, [x19, #0x78]
   22b6c:      	mov	x6, #0x3333333333333333 ; =3689348814741910323
   22b70:      	str	x6, [x19, #0x88]
   22b74:      	mov	x7, #0x38               ; =56
   22b78:      	str	x7, [x19, #0x90]
   22b7c:      	mov	x8, #0x3a               ; =58
   22b80:      	str	x8, [x19, #0x98]
   22b84:      	mov	x10, #0x5555555555555555 ; =6148914691236517205
   22b88:      	str	x10, [x19, #0xb0]
   22b8c:      	mov	x10, #0x3ffffffffffffff ; =288230376151711743
   22b90:      	str	x10, [x19, #0xb8]
   22b94:      	str	x0, [x19, #0x188]
   22b98:      	str	x1, [x19, #0x190]
   22b9c:      	str	x22, [x19, #0x17a0]
   22ba0:      	str	x23, [x19, #0x17a8]
   22ba4:      	ldur	x25, [sp, #0xf0]
   22ba8:      	uxtb	w15, w25
   22bac:      	str	x15, [x19, #0x17b8]
   22bb0:      	ldur	x1, [sp, #0xe8]
   22bb4:      	str	x1, [x19, #0x1c00]
   22bb8:      	str	x28, [x19, #0x4c60]
   22bbc:      	str	x3, [x19, #0x4c68]
   22bc0:      	ldur	x4, [sp, #0x98]
   22bc4:      	str	x4, [x19, #0x4c70]
   22bc8:      	str	x22, [x19, #0x4f70]
   22bcc:      	str	x23, [x19, #0x4f78]
   22bd0:      	ldur	x14, [sp, #0x60]
   22bd4:      	str	x14, [x19, #0x5a20]
   22bd8:      	add	x1, x11, #0x1
   22bdc:      	str	x1, [x19, #0x5bb0]
   22be0:      	ldur	x26, [sp, #0xa0]
   22be4:      	str	x26, [x19, #0x5bb8]
   22be8:      	ldur	x7, [sp, #0xa8]
   22bec:      	str	x7, [x19, #0x5bc0]
   22bf0:      	ldur	x4, [sp, #0x90]
   22bf4:      	sub	x2, x4, x3
   22bf8:      	mov	w3, #0xc87e             ; =51326
   22bfc:      	movk	w3, #0x1, lsl #16
   22c00:      	msub	x1, x1, x3, x2
   22c04:      	str	x1, [x19, #0x5bc8]
   22c08:      	str	x0, [x19, #0x5bd0]
   22c0c:      	str	x0, [x19, #0x5bd8]
   22c10:      	ldur	x8, [sp, #0xb0]
   22c14:      	str	x8, [x19, #0x5be8]
   22c18:      	ldur	x4, [sp, #0xb8]
   22c1c:      	str	x4, [x19, #0x5bf0]
   22c20:      	str	x12, [x19, #0x5c00]
   22c24:      	str	x9, [x19, #0x5c08]
   22c28:      	str	x13, [x19, #0x5c18]
   22c2c:      	ldur	x13, [sp, #0xc0]
   22c30:      	str	x13, [x19, #0x5c20]
   22c34:      	ldr	x0, [x19, #0x4c60]
   22c38:      	cmp	x0, #0x0
   22c3c:      	b.ne	0x1f738 <_mech_canonical_program_entry_v1_numeric_1282+0x25b8>
   22c40:      	b	0x1f96c <_mech_canonical_program_entry_v1_numeric_1282+0x27ec>
   22c44:      	mov	x21, x20
   22c48:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22c4c:      	mov	x21, x20
   22c50:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22c54:      	mov	x0, #0x5ea              ; =1514
   22c58:      	ldur	x8, [sp]
   22c5c:      	str	x0, [x8, #0x48]
   22c60:      	mov	x0, #0x0                ; =0
   22c64:      	str	x0, [x19, #0x18]
   22c68:      	mov	x1, #0x1000000000000000 ; =1152921504606846976
   22c6c:      	str	x1, [x19, #0x20]
   22c70:      	mov	x1, #0x1                ; =1
   22c74:      	str	x1, [x19, #0x30]
   22c78:      	mov	x2, #0x101010101010101  ; =72340172838076673
   22c7c:      	str	x2, [x19, #0x38]
   22c80:      	mov	x20, #0x2               ; =2
   22c84:      	str	x20, [x19, #0x40]
   22c88:      	mov	x2, #0x3                ; =3
   22c8c:      	str	x2, [x19, #0x48]
   22c90:      	mov	x2, #0x4                ; =4
   22c94:      	str	x2, [x19, #0x50]
   22c98:      	mov	x2, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   22c9c:      	str	x2, [x19, #0x78]
   22ca0:      	mov	x2, #0x3333333333333333 ; =3689348814741910323
   22ca4:      	str	x2, [x19, #0x88]
   22ca8:      	mov	x2, #0x38               ; =56
   22cac:      	str	x2, [x19, #0x90]
   22cb0:      	mov	x2, #0x3a               ; =58
   22cb4:      	str	x2, [x19, #0x98]
   22cb8:      	mov	x2, #0x5555555555555555 ; =6148914691236517205
   22cbc:      	str	x2, [x19, #0xb0]
   22cc0:      	mov	x2, #0x3ffffffffffffff  ; =288230376151711743
   22cc4:      	str	x2, [x19, #0xb8]
   22cc8:      	str	x0, [x19, #0x188]
   22ccc:      	str	x1, [x19, #0x190]
   22cd0:      	str	x22, [x19, #0x17a0]
   22cd4:      	str	x23, [x19, #0x17a8]
   22cd8:      	ldur	x25, [sp, #0xf0]
   22cdc:      	uxtb	w6, w25
   22ce0:      	str	x6, [x19, #0x17b8]
   22ce4:      	str	x15, [x19, #0x1c08]
   22ce8:      	add	x8, x22, #0x2
   22cec:      	str	x8, [x19, #0x1c10]
   22cf0:      	str	x28, [x19, #0x4c60]
   22cf4:      	str	x3, [x19, #0x4c68]
   22cf8:      	ldur	x4, [sp, #0x98]
   22cfc:      	str	x4, [x19, #0x4c70]
   22d00:      	str	x22, [x19, #0x4f70]
   22d04:      	str	x23, [x19, #0x4f78]
   22d08:      	ldur	x14, [sp, #0x60]
   22d0c:      	str	x14, [x19, #0x5a20]
   22d10:      	add	x15, x11, #0x1
   22d14:      	str	x15, [x19, #0x5bb0]
   22d18:      	ldur	x26, [sp, #0xa0]
   22d1c:      	str	x26, [x19, #0x5bb8]
   22d20:      	ldur	x7, [sp, #0xa8]
   22d24:      	str	x7, [x19, #0x5bc0]
   22d28:      	ldur	x4, [sp, #0x90]
   22d2c:      	sub	x1, x4, x3
   22d30:      	mov	w2, #0xc87e             ; =51326
   22d34:      	movk	w2, #0x1, lsl #16
   22d38:      	msub	x1, x15, x2, x1
   22d3c:      	str	x1, [x19, #0x5bc8]
   22d40:      	str	x0, [x19, #0x5bd0]
   22d44:      	str	x0, [x19, #0x5bd8]
   22d48:      	ldur	x8, [sp, #0xb0]
   22d4c:      	str	x8, [x19, #0x5be8]
   22d50:      	ldur	x4, [sp, #0xb8]
   22d54:      	str	x4, [x19, #0x5bf0]
   22d58:      	str	x12, [x19, #0x5c00]
   22d5c:      	str	x9, [x19, #0x5c08]
   22d60:      	str	x13, [x19, #0x5c18]
   22d64:      	ldur	x13, [sp, #0xc0]
   22d68:      	str	x13, [x19, #0x5c20]
   22d6c:      	ldr	x0, [x19, #0x4c60]
   22d70:      	cmp	x0, #0x0
   22d74:      	b.ne	0x1f9e0 <_mech_canonical_program_entry_v1_numeric_1282+0x2860>
   22d78:      	b	0x1fc0c <_mech_canonical_program_entry_v1_numeric_1282+0x2a8c>
   22d7c:      	mov	x21, x20
   22d80:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22d84:      	mov	x21, x20
   22d88:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22d8c:      	mov	x21, x20
   22d90:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22d94:      	mov	x0, #0x604              ; =1540
   22d98:      	ldur	x4, [sp]
   22d9c:      	str	x0, [x4, #0x48]
   22da0:      	mov	x1, #0x0                ; =0
   22da4:      	str	x1, [x19, #0x18]
   22da8:      	str	x26, [x19, #0x20]
   22dac:      	mov	x0, #0x1                ; =1
   22db0:      	mov	x21, x0
   22db4:      	str	x0, [x19, #0x30]
   22db8:      	mov	x0, #0x101010101010101  ; =72340172838076673
   22dbc:      	str	x0, [x19, #0x38]
   22dc0:      	mov	x0, #0x2                ; =2
   22dc4:      	str	x0, [x19, #0x40]
   22dc8:      	mov	x0, #0x3                ; =3
   22dcc:      	str	x0, [x19, #0x48]
   22dd0:      	mov	x0, #0x4                ; =4
   22dd4:      	str	x0, [x19, #0x50]
   22dd8:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   22ddc:      	str	x0, [x19, #0x78]
   22de0:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   22de4:      	str	x0, [x19, #0x88]
   22de8:      	mov	x0, #0x38               ; =56
   22dec:      	str	x0, [x19, #0x90]
   22df0:      	mov	x2, #0x3a               ; =58
   22df4:      	str	x2, [x19, #0x98]
   22df8:      	mov	x2, #0x5555555555555555 ; =6148914691236517205
   22dfc:      	str	x2, [x19, #0xb0]
   22e00:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   22e04:      	str	x4, [x19, #0xb8]
   22e08:      	str	x1, [x19, #0x188]
   22e0c:      	mov	x0, x21
   22e10:      	str	x0, [x19, #0x190]
   22e14:      	str	x22, [x19, #0x17a0]
   22e18:      	str	x23, [x19, #0x17a8]
   22e1c:      	ldur	x25, [sp, #0xf0]
   22e20:      	uxtb	w8, w25
   22e24:      	str	x8, [x19, #0x17b8]
   22e28:      	str	x15, [x19, #0x1c70]
   22e2c:      	str	x12, [x19, #0x1c78]
   22e30:      	str	x22, [x19, #0x1c80]
   22e34:      	str	x24, [x19, #0x1ca8]
   22e38:      	str	x28, [x19, #0x4c60]
   22e3c:      	mov	w14, #0x2646            ; =9798
   22e40:      	movk	w14, #0x1, lsl #16
   22e44:      	sub	x14, x3, x14
   22e48:      	str	x14, [x19, #0x4c68]
   22e4c:      	ldur	x4, [sp, #0x98]
   22e50:      	str	x4, [x19, #0x4c70]
   22e54:      	ldur	x0, [sp, #0x60]
   22e58:      	str	x0, [x19, #0x5a20]
   22e5c:      	add	x2, x11, #0x1
   22e60:      	str	x2, [x19, #0x5bb0]
   22e64:      	ldur	x26, [sp, #0xa0]
   22e68:      	str	x26, [x19, #0x5bb8]
   22e6c:      	ldur	x7, [sp, #0xa8]
   22e70:      	str	x7, [x19, #0x5bc0]
   22e74:      	ldur	x4, [sp, #0x90]
   22e78:      	sub	x3, x4, x14
   22e7c:      	mov	w4, #0xc87e             ; =51326
   22e80:      	movk	w4, #0x1, lsl #16
   22e84:      	msub	x0, x2, x4, x3
   22e88:      	str	x0, [x19, #0x5bc8]
   22e8c:      	str	x1, [x19, #0x5bd0]
   22e90:      	str	x1, [x19, #0x5bd8]
   22e94:      	ldur	x8, [sp, #0xb0]
   22e98:      	str	x8, [x19, #0x5be8]
   22e9c:      	ldur	x4, [sp, #0xb8]
   22ea0:      	str	x4, [x19, #0x5bf0]
   22ea4:      	mov	x0, x21
   22ea8:      	str	x0, [x19, #0x5c00]
   22eac:      	ldur	x10, [sp, #0x50]
   22eb0:      	str	x10, [x19, #0x5c08]
   22eb4:      	str	x13, [x19, #0x5c18]
   22eb8:      	ldur	x13, [sp, #0xc0]
   22ebc:      	str	x13, [x19, #0x5c20]
   22ec0:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   22ec4:      	mov	x0, #0x605              ; =1541
   22ec8:      	ldur	x6, [sp]
   22ecc:      	str	x0, [x6, #0x48]
   22ed0:      	mov	x0, #0x0                ; =0
   22ed4:      	str	x0, [x19, #0x18]
   22ed8:      	str	x26, [x19, #0x20]
   22edc:      	mov	x1, #0x1                ; =1
   22ee0:      	str	x1, [x19, #0x30]
   22ee4:      	mov	x4, #0x101010101010101  ; =72340172838076673
   22ee8:      	str	x4, [x19, #0x38]
   22eec:      	mov	x20, #0x2               ; =2
   22ef0:      	str	x20, [x19, #0x40]
   22ef4:      	mov	x4, #0x3                ; =3
   22ef8:      	str	x4, [x19, #0x48]
   22efc:      	mov	x4, #0x4                ; =4
   22f00:      	str	x4, [x19, #0x50]
   22f04:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   22f08:      	str	x4, [x19, #0x78]
   22f0c:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   22f10:      	str	x4, [x19, #0x88]
   22f14:      	mov	x4, #0x38               ; =56
   22f18:      	str	x4, [x19, #0x90]
   22f1c:      	mov	x4, #0x3a               ; =58
   22f20:      	str	x4, [x19, #0x98]
   22f24:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   22f28:      	str	x4, [x19, #0xb0]
   22f2c:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   22f30:      	str	x4, [x19, #0xb8]
   22f34:      	str	x0, [x19, #0x188]
   22f38:      	str	x1, [x19, #0x190]
   22f3c:      	str	x22, [x19, #0x17a0]
   22f40:      	str	x23, [x19, #0x17a8]
   22f44:      	ldur	x25, [sp, #0xf0]
   22f48:      	uxtb	w4, w25
   22f4c:      	str	x4, [x19, #0x17b8]
   22f50:      	str	x15, [x19, #0x1c70]
   22f54:      	str	x12, [x19, #0x1c78]
   22f58:      	str	x22, [x19, #0x1c80]
   22f5c:      	str	x24, [x19, #0x1ca8]
   22f60:      	str	x2, [x19, #0x1cb8]
   22f64:      	str	x28, [x19, #0x4c60]
   22f68:      	mov	w2, #0x2646             ; =9798
   22f6c:      	movk	w2, #0x1, lsl #16
   22f70:      	sub	x2, x3, x2
   22f74:      	str	x2, [x19, #0x4c68]
   22f78:      	ldur	x4, [sp, #0x98]
   22f7c:      	str	x4, [x19, #0x4c70]
   22f80:      	str	x22, [x19, #0x4f70]
   22f84:      	str	x23, [x19, #0x4f78]
   22f88:      	str	x15, [x19, #0x55d8]
   22f8c:      	str	x12, [x19, #0x55e0]
   22f90:      	str	x22, [x19, #0x55e8]
   22f94:      	ldur	x24, [sp, #0x10]
   22f98:      	str	x24, [x19, #0x55f0]
   22f9c:      	ldur	x26, [sp, #0x68]
   22fa0:      	str	x26, [x19, #0x55f8]
   22fa4:      	ldur	x27, [sp, #0x70]
   22fa8:      	str	x27, [x19, #0x5600]
   22fac:      	ldur	x24, [sp, #0x78]
   22fb0:      	str	x24, [x19, #0x5608]
   22fb4:      	ldur	x26, [sp, #0x80]
   22fb8:      	str	x26, [x19, #0x5610]
   22fbc:      	ldur	x14, [sp, #0x60]
   22fc0:      	str	x14, [x19, #0x5a20]
   22fc4:      	add	x8, x11, #0x1
   22fc8:      	str	x8, [x19, #0x5bb0]
   22fcc:      	ldur	x26, [sp, #0xa0]
   22fd0:      	str	x26, [x19, #0x5bb8]
   22fd4:      	ldur	x7, [sp, #0xa8]
   22fd8:      	str	x7, [x19, #0x5bc0]
   22fdc:      	ldur	x4, [sp, #0x90]
   22fe0:      	sub	x11, x4, x2
   22fe4:      	mov	w12, #0xc87e            ; =51326
   22fe8:      	movk	w12, #0x1, lsl #16
   22fec:      	msub	x11, x8, x12, x11
   22ff0:      	str	x11, [x19, #0x5bc8]
   22ff4:      	str	x0, [x19, #0x5bd0]
   22ff8:      	str	x0, [x19, #0x5bd8]
   22ffc:      	ldur	x8, [sp, #0xb0]
   23000:      	str	x8, [x19, #0x5be8]
   23004:      	ldur	x4, [sp, #0xb8]
   23008:      	str	x4, [x19, #0x5bf0]
   2300c:      	str	x1, [x19, #0x5c00]
   23010:      	ldur	x10, [sp, #0x50]
   23014:      	str	x10, [x19, #0x5c08]
   23018:      	str	x13, [x19, #0x5c18]
   2301c:      	ldur	x13, [sp, #0xc0]
   23020:      	str	x13, [x19, #0x5c20]
   23024:      	ldr	x0, [x19, #0x4c60]
   23028:      	cmp	x0, #0x0
   2302c:      	b.ne	0x2009c <_mech_canonical_program_entry_v1_numeric_1282+0x2f1c>
   23030:      	b	0x202c4 <_mech_canonical_program_entry_v1_numeric_1282+0x3144>
   23034:      	mov	x21, x20
   23038:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   2303c:      	mov	x21, x20
   23040:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   23044:      	mov	x0, #0x606              ; =1542
   23048:      	ldur	x2, [sp]
   2304c:      	str	x0, [x2, #0x48]
   23050:      	mov	x2, #0x0                ; =0
   23054:      	str	x2, [x19, #0x18]
   23058:      	str	x26, [x19, #0x20]
   2305c:      	mov	x0, #0x1                ; =1
   23060:      	mov	x21, x0
   23064:      	str	x0, [x19, #0x30]
   23068:      	mov	x0, #0x101010101010101  ; =72340172838076673
   2306c:      	str	x0, [x19, #0x38]
   23070:      	mov	x0, #0x2                ; =2
   23074:      	str	x0, [x19, #0x40]
   23078:      	mov	x0, #0x3                ; =3
   2307c:      	str	x0, [x19, #0x48]
   23080:      	mov	x0, #0x4                ; =4
   23084:      	str	x0, [x19, #0x50]
   23088:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   2308c:      	str	x0, [x19, #0x78]
   23090:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   23094:      	str	x0, [x19, #0x88]
   23098:      	mov	x0, #0x38               ; =56
   2309c:      	str	x0, [x19, #0x90]
   230a0:      	mov	x0, #0x3a               ; =58
   230a4:      	str	x0, [x19, #0x98]
   230a8:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   230ac:      	str	x0, [x19, #0xb0]
   230b0:      	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
   230b4:      	str	x0, [x19, #0xb8]
   230b8:      	str	x2, [x19, #0x188]
   230bc:      	mov	x0, x21
   230c0:      	str	x0, [x19, #0x190]
   230c4:      	str	x22, [x19, #0x17a0]
   230c8:      	str	x23, [x19, #0x17a8]
   230cc:      	ldur	x25, [sp, #0xf0]
   230d0:      	uxtb	w0, w25
   230d4:      	str	x0, [x19, #0x17b8]
   230d8:      	str	x15, [x19, #0x1c70]
   230dc:      	str	x12, [x19, #0x1c78]
   230e0:      	str	x22, [x19, #0x1c80]
   230e4:      	str	x24, [x19, #0x1ca8]
   230e8:      	str	x1, [x19, #0x1cc0]
   230ec:      	str	x28, [x19, #0x4c60]
   230f0:      	mov	w1, #0x2646             ; =9798
   230f4:      	movk	w1, #0x1, lsl #16
   230f8:      	sub	x1, x3, x1
   230fc:      	str	x1, [x19, #0x4c68]
   23100:      	ldur	x4, [sp, #0x98]
   23104:      	str	x4, [x19, #0x4c70]
   23108:      	ldur	x14, [sp, #0x60]
   2310c:      	str	x14, [x19, #0x5a20]
   23110:      	add	x3, x11, #0x1
   23114:      	str	x3, [x19, #0x5bb0]
   23118:      	ldur	x26, [sp, #0xa0]
   2311c:      	str	x26, [x19, #0x5bb8]
   23120:      	ldur	x7, [sp, #0xa8]
   23124:      	str	x7, [x19, #0x5bc0]
   23128:      	ldur	x4, [sp, #0x90]
   2312c:      	sub	x4, x4, x1
   23130:      	mov	w5, #0xc87e             ; =51326
   23134:      	movk	w5, #0x1, lsl #16
   23138:      	msub	x3, x3, x5, x4
   2313c:      	str	x3, [x19, #0x5bc8]
   23140:      	str	x2, [x19, #0x5bd0]
   23144:      	str	x2, [x19, #0x5bd8]
   23148:      	ldur	x8, [sp, #0xb0]
   2314c:      	str	x8, [x19, #0x5be8]
   23150:      	ldur	x4, [sp, #0xb8]
   23154:      	str	x4, [x19, #0x5bf0]
   23158:      	mov	x0, x21
   2315c:      	str	x0, [x19, #0x5c00]
   23160:      	ldur	x10, [sp, #0x50]
   23164:      	str	x10, [x19, #0x5c08]
   23168:      	str	x13, [x19, #0x5c18]
   2316c:      	ldur	x13, [sp, #0xc0]
   23170:      	str	x13, [x19, #0x5c20]
   23174:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   23178:      	mov	x0, #0x607              ; =1543
   2317c:      	ldur	x2, [sp]
   23180:      	str	x0, [x2, #0x48]
   23184:      	mov	x0, #0x0                ; =0
   23188:      	str	x0, [x19, #0x18]
   2318c:      	str	x26, [x19, #0x20]
   23190:      	mov	x2, #0x1                ; =1
   23194:      	str	x2, [x19, #0x30]
   23198:      	mov	x5, #0x101010101010101  ; =72340172838076673
   2319c:      	str	x5, [x19, #0x38]
   231a0:      	mov	x20, #0x2               ; =2
   231a4:      	str	x20, [x19, #0x40]
   231a8:      	mov	x5, #0x3                ; =3
   231ac:      	str	x5, [x19, #0x48]
   231b0:      	mov	x5, #0x4                ; =4
   231b4:      	str	x5, [x19, #0x50]
   231b8:      	mov	x5, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   231bc:      	str	x5, [x19, #0x78]
   231c0:      	mov	x5, #0x3333333333333333 ; =3689348814741910323
   231c4:      	str	x5, [x19, #0x88]
   231c8:      	mov	x5, #0x38               ; =56
   231cc:      	str	x5, [x19, #0x90]
   231d0:      	mov	x5, #0x3a               ; =58
   231d4:      	str	x5, [x19, #0x98]
   231d8:      	mov	x5, #0x5555555555555555 ; =6148914691236517205
   231dc:      	str	x5, [x19, #0xb0]
   231e0:      	mov	x5, #0x3ffffffffffffff  ; =288230376151711743
   231e4:      	str	x5, [x19, #0xb8]
   231e8:      	str	x0, [x19, #0x188]
   231ec:      	str	x2, [x19, #0x190]
   231f0:      	str	x22, [x19, #0x17a0]
   231f4:      	str	x23, [x19, #0x17a8]
   231f8:      	ldur	x25, [sp, #0xf0]
   231fc:      	uxtb	w5, w25
   23200:      	str	x5, [x19, #0x17b8]
   23204:      	str	x15, [x19, #0x1c70]
   23208:      	str	x12, [x19, #0x1c78]
   2320c:      	str	x22, [x19, #0x1c80]
   23210:      	str	x24, [x19, #0x1ca8]
   23214:      	str	x1, [x19, #0x1cc0]
   23218:      	str	x4, [x19, #0x1cc8]
   2321c:      	str	x28, [x19, #0x4c60]
   23220:      	mov	w1, #0x2646             ; =9798
   23224:      	movk	w1, #0x1, lsl #16
   23228:      	sub	x1, x3, x1
   2322c:      	str	x1, [x19, #0x4c68]
   23230:      	ldur	x4, [sp, #0x98]
   23234:      	str	x4, [x19, #0x4c70]
   23238:      	str	x22, [x19, #0x4f70]
   2323c:      	str	x23, [x19, #0x4f78]
   23240:      	str	x15, [x19, #0x55d8]
   23244:      	str	x12, [x19, #0x55e0]
   23248:      	str	x22, [x19, #0x55e8]
   2324c:      	ldur	x24, [sp, #0x10]
   23250:      	str	x24, [x19, #0x55f0]
   23254:      	ldur	x26, [sp, #0x68]
   23258:      	str	x26, [x19, #0x55f8]
   2325c:      	ldur	x27, [sp, #0x70]
   23260:      	str	x27, [x19, #0x5600]
   23264:      	ldur	x24, [sp, #0x78]
   23268:      	str	x24, [x19, #0x5608]
   2326c:      	ldur	x26, [sp, #0x80]
   23270:      	str	x26, [x19, #0x5610]
   23274:      	ldur	x14, [sp, #0x60]
   23278:      	str	x14, [x19, #0x5a20]
   2327c:      	add	x3, x11, #0x1
   23280:      	str	x3, [x19, #0x5bb0]
   23284:      	ldur	x26, [sp, #0xa0]
   23288:      	str	x26, [x19, #0x5bb8]
   2328c:      	ldur	x7, [sp, #0xa8]
   23290:      	str	x7, [x19, #0x5bc0]
   23294:      	ldur	x4, [sp, #0x90]
   23298:      	sub	x1, x4, x1
   2329c:      	mov	w4, #0xc87e             ; =51326
   232a0:      	movk	w4, #0x1, lsl #16
   232a4:      	msub	x1, x3, x4, x1
   232a8:      	str	x1, [x19, #0x5bc8]
   232ac:      	str	x0, [x19, #0x5bd0]
   232b0:      	str	x0, [x19, #0x5bd8]
   232b4:      	ldur	x8, [sp, #0xb0]
   232b8:      	str	x8, [x19, #0x5be8]
   232bc:      	ldur	x4, [sp, #0xb8]
   232c0:      	str	x4, [x19, #0x5bf0]
   232c4:      	str	x2, [x19, #0x5c00]
   232c8:      	ldur	x10, [sp, #0x50]
   232cc:      	str	x10, [x19, #0x5c08]
   232d0:      	str	x13, [x19, #0x5c18]
   232d4:      	ldur	x13, [sp, #0xc0]
   232d8:      	str	x13, [x19, #0x5c20]
   232dc:      	ldr	x3, [x19, #0x4c60]
   232e0:      	cmp	x3, #0x0
   232e4:      	b.ne	0x20340 <_mech_canonical_program_entry_v1_numeric_1282+0x31c0>
   232e8:      	b	0x2054c <_mech_canonical_program_entry_v1_numeric_1282+0x33cc>
   232ec:      	mov	x21, x20
   232f0:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   232f4:      	mov	x21, x20
   232f8:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   232fc:      	mov	x0, #0x609              ; =1545
   23300:      	ldur	x4, [sp]
   23304:      	str	x0, [x4, #0x48]
   23308:      	mov	x0, #0x0                ; =0
   2330c:      	str	x0, [x19, #0x18]
   23310:      	str	x26, [x19, #0x20]
   23314:      	mov	x2, #0x1                ; =1
   23318:      	str	x2, [x19, #0x30]
   2331c:      	mov	x4, #0x101010101010101  ; =72340172838076673
   23320:      	str	x4, [x19, #0x38]
   23324:      	mov	x25, #0x2               ; =2
   23328:      	str	x25, [x19, #0x40]
   2332c:      	mov	x4, #0x3                ; =3
   23330:      	str	x4, [x19, #0x48]
   23334:      	mov	x4, #0x4                ; =4
   23338:      	str	x4, [x19, #0x50]
   2333c:      	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   23340:      	str	x4, [x19, #0x78]
   23344:      	mov	x4, #0x3333333333333333 ; =3689348814741910323
   23348:      	str	x4, [x19, #0x88]
   2334c:      	mov	x4, #0x38               ; =56
   23350:      	str	x4, [x19, #0x90]
   23354:      	mov	x4, #0x3a               ; =58
   23358:      	str	x4, [x19, #0x98]
   2335c:      	mov	x4, #0x5555555555555555 ; =6148914691236517205
   23360:      	str	x4, [x19, #0xb0]
   23364:      	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
   23368:      	str	x4, [x19, #0xb8]
   2336c:      	str	x0, [x19, #0x188]
   23370:      	str	x2, [x19, #0x190]
   23374:      	str	x22, [x19, #0x17a0]
   23378:      	str	x23, [x19, #0x17a8]
   2337c:      	ldur	x4, [sp, #0xf0]
   23380:      	uxtb	w4, w4
   23384:      	str	x4, [x19, #0x17b8]
   23388:      	str	x15, [x19, #0x1c70]
   2338c:      	str	x12, [x19, #0x1c78]
   23390:      	str	x22, [x19, #0x1c80]
   23394:      	str	x24, [x19, #0x1ca8]
   23398:      	str	x27, [x19, #0x1cd0]
   2339c:      	add	x1, x1, #0x2
   233a0:      	str	x1, [x19, #0x1cd8]
   233a4:      	str	x28, [x19, #0x4c60]
   233a8:      	mov	w1, #0x2646             ; =9798
   233ac:      	movk	w1, #0x1, lsl #16
   233b0:      	sub	x1, x3, x1
   233b4:      	str	x1, [x19, #0x4c68]
   233b8:      	ldur	x4, [sp, #0x98]
   233bc:      	str	x4, [x19, #0x4c70]
   233c0:      	str	x22, [x19, #0x4f70]
   233c4:      	str	x23, [x19, #0x4f78]
   233c8:      	str	x15, [x19, #0x55d8]
   233cc:      	str	x12, [x19, #0x55e0]
   233d0:      	str	x22, [x19, #0x55e8]
   233d4:      	ldur	x24, [sp, #0x10]
   233d8:      	str	x24, [x19, #0x55f0]
   233dc:      	ldur	x26, [sp, #0x68]
   233e0:      	str	x26, [x19, #0x55f8]
   233e4:      	ldur	x27, [sp, #0x70]
   233e8:      	str	x27, [x19, #0x5600]
   233ec:      	ldur	x24, [sp, #0x78]
   233f0:      	str	x24, [x19, #0x5608]
   233f4:      	ldur	x26, [sp, #0x80]
   233f8:      	str	x26, [x19, #0x5610]
   233fc:      	ldur	x14, [sp, #0x60]
   23400:      	str	x14, [x19, #0x5a20]
   23404:      	add	x3, x11, #0x1
   23408:      	str	x3, [x19, #0x5bb0]
   2340c:      	ldur	x26, [sp, #0xa0]
   23410:      	str	x26, [x19, #0x5bb8]
   23414:      	ldur	x7, [sp, #0xa8]
   23418:      	str	x7, [x19, #0x5bc0]
   2341c:      	ldur	x4, [sp, #0x90]
   23420:      	sub	x1, x4, x1
   23424:      	mov	w4, #0xc87e             ; =51326
   23428:      	movk	w4, #0x1, lsl #16
   2342c:      	msub	x1, x3, x4, x1
   23430:      	str	x1, [x19, #0x5bc8]
   23434:      	str	x0, [x19, #0x5bd0]
   23438:      	str	x0, [x19, #0x5bd8]
   2343c:      	ldur	x8, [sp, #0xb0]
   23440:      	str	x8, [x19, #0x5be8]
   23444:      	ldur	x4, [sp, #0xb8]
   23448:      	str	x4, [x19, #0x5bf0]
   2344c:      	str	x2, [x19, #0x5c00]
   23450:      	ldur	x10, [sp, #0x50]
   23454:      	str	x10, [x19, #0x5c08]
   23458:      	str	x13, [x19, #0x5c18]
   2345c:      	ldur	x13, [sp, #0xc0]
   23460:      	str	x13, [x19, #0x5c20]
   23464:      	ldr	x7, [x19, #0x4c60]
   23468:      	cmp	x7, #0x0
   2346c:      	b.ne	0x205bc <_mech_canonical_program_entry_v1_numeric_1282+0x343c>
   23470:      	b	0x207d0 <_mech_canonical_program_entry_v1_numeric_1282+0x3650>
   23474:      	mov	x21, x25
   23478:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   2347c:      	mov	x21, x25
   23480:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   23484:      	mov	x21, x20
   23488:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   2348c:      	mov	x2, #0x621              ; =1569
   23490:      	ldur	x5, [sp]
   23494:      	str	x2, [x5, #0x48]
   23498:      	mov	x5, #0x0                ; =0
   2349c:      	str	x5, [x19, #0x18]
   234a0:      	str	x26, [x19, #0x20]
   234a4:      	mov	x2, #0x1                ; =1
   234a8:      	str	x2, [x19, #0x30]
   234ac:      	mov	x6, #0x101010101010101  ; =72340172838076673
   234b0:      	str	x6, [x19, #0x38]
   234b4:      	mov	x20, #0x2               ; =2
   234b8:      	str	x20, [x19, #0x40]
   234bc:      	mov	x6, #0x3                ; =3
   234c0:      	str	x6, [x19, #0x48]
   234c4:      	mov	x6, #0x4                ; =4
   234c8:      	str	x6, [x19, #0x50]
   234cc:      	mov	x6, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   234d0:      	str	x6, [x19, #0x78]
   234d4:      	mov	x6, #0x3333333333333333 ; =3689348814741910323
   234d8:      	str	x6, [x19, #0x88]
   234dc:      	mov	x6, #0x38               ; =56
   234e0:      	str	x6, [x19, #0x90]
   234e4:      	mov	x6, #0x3a               ; =58
   234e8:      	str	x6, [x19, #0x98]
   234ec:      	mov	x6, #0x5555555555555555 ; =6148914691236517205
   234f0:      	str	x6, [x19, #0xb0]
   234f4:      	mov	x6, #0x3ffffffffffffff  ; =288230376151711743
   234f8:      	str	x6, [x19, #0xb8]
   234fc:      	str	x5, [x19, #0x188]
   23500:      	str	x2, [x19, #0x190]
   23504:      	str	x22, [x19, #0x17a0]
   23508:      	str	x23, [x19, #0x17a8]
   2350c:      	ldur	x25, [sp, #0xf0]
   23510:      	uxtb	w6, w25
   23514:      	str	x6, [x19, #0x17b8]
   23518:      	str	x15, [x19, #0x1c70]
   2351c:      	str	x12, [x19, #0x1c78]
   23520:      	str	x22, [x19, #0x1c80]
   23524:      	str	x24, [x19, #0x1ca8]
   23528:      	str	x27, [x19, #0x1d38]
   2352c:      	str	x13, [x19, #0x1d40]
   23530:      	str	x22, [x19, #0x1d48]
   23534:      	uxtb	w4, w4
   23538:      	str	x4, [x19, #0x1d58]
   2353c:      	add	x4, x27, #0x1
   23540:      	str	x4, [x19, #0x1d68]
   23544:      	str	x28, [x19, #0x4c60]
   23548:      	mov	w4, #0xcb86             ; =52102
   2354c:      	movk	w4, #0x2, lsl #16
   23550:      	sub	x3, x3, x4
   23554:      	str	x3, [x19, #0x4c68]
   23558:      	ldur	x4, [sp, #0x98]
   2355c:      	str	x4, [x19, #0x4c70]
   23560:      	str	x22, [x19, #0x4f70]
   23564:      	str	x23, [x19, #0x4f78]
   23568:      	str	x15, [x19, #0x55d8]
   2356c:      	str	x12, [x19, #0x55e0]
   23570:      	str	x22, [x19, #0x55e8]
   23574:      	ldur	x24, [sp, #0x10]
   23578:      	str	x24, [x19, #0x55f0]
   2357c:      	ldur	x26, [sp, #0x68]
   23580:      	str	x26, [x19, #0x55f8]
   23584:      	ldur	x4, [sp, #0x70]
   23588:      	str	x4, [x19, #0x5600]
   2358c:      	ldur	x24, [sp, #0x78]
   23590:      	str	x24, [x19, #0x5608]
   23594:      	ldur	x26, [sp, #0x80]
   23598:      	str	x26, [x19, #0x5610]
   2359c:      	str	x27, [x19, #0x57a0]
   235a0:      	str	x13, [x19, #0x57a8]
   235a4:      	str	x22, [x19, #0x57b0]
   235a8:      	str	x1, [x19, #0x57b8]
   235ac:      	str	x14, [x19, #0x57c0]
   235b0:      	str	x10, [x19, #0x57c8]
   235b4:      	str	x9, [x19, #0x57d0]
   235b8:      	str	x0, [x19, #0x57d8]
   235bc:      	ldur	x14, [sp, #0x60]
   235c0:      	str	x14, [x19, #0x5a20]
   235c4:      	add	x0, x11, #0x1
   235c8:      	str	x0, [x19, #0x5bb0]
   235cc:      	ldur	x26, [sp, #0xa0]
   235d0:      	str	x26, [x19, #0x5bb8]
   235d4:      	ldur	x7, [sp, #0xa8]
   235d8:      	str	x7, [x19, #0x5bc0]
   235dc:      	ldur	x4, [sp, #0x90]
   235e0:      	sub	x1, x4, x3
   235e4:      	mov	w3, #0xc87e             ; =51326
   235e8:      	movk	w3, #0x1, lsl #16
   235ec:      	msub	x0, x0, x3, x1
   235f0:      	str	x0, [x19, #0x5bc8]
   235f4:      	str	x5, [x19, #0x5bd0]
   235f8:      	str	x5, [x19, #0x5bd8]
   235fc:      	ldur	x8, [sp, #0xb0]
   23600:      	str	x8, [x19, #0x5be8]
   23604:      	ldur	x4, [sp, #0xb8]
   23608:      	str	x4, [x19, #0x5bf0]
   2360c:      	str	x2, [x19, #0x5c00]
   23610:      	ldur	x10, [sp, #0x50]
   23614:      	str	x10, [x19, #0x5c08]
   23618:      	str	x2, [x19, #0x5c18]
   2361c:      	ldur	x5, [sp, #0x58]
   23620:      	str	x5, [x19, #0x5c20]
   23624:      	ldr	x0, [x19, #0x4c60]
   23628:      	cmp	x0, #0x0
   2362c:      	b.ne	0x20cb0 <_mech_canonical_program_entry_v1_numeric_1282+0x3b30>
   23630:      	b	0x20ecc <_mech_canonical_program_entry_v1_numeric_1282+0x3d4c>
   23634:      	mov	x21, x20
   23638:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   2363c:      	mov	x21, x20
   23640:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   23644:      	mov	x0, #0x6c4              ; =1732
   23648:      	ldur	x28, [sp]
   2364c:      	str	x0, [x28, #0x48]
   23650:      	mov	x0, #0x0                ; =0
   23654:      	str	x0, [x19, #0x4c60]
   23658:      	mov	x0, #0x3                ; =3
   2365c:      	mov	x21, x0
   23660:      	ldr	x0, [sp, #0x190]
   23664:      	cmp	x0, #0x19c
   23668:      	b.hs	0x21100 <_mech_canonical_program_entry_v1_numeric_1282+0x3f80>
   2366c:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   23670:      	mov	x0, #0x6c8              ; =1736
   23674:      	ldur	x28, [sp]
   23678:      	str	x0, [x28, #0x48]
   2367c:      	mov	x0, #0x0                ; =0
   23680:      	str	x0, [x19, #0x4c60]
   23684:      	mov	x0, #0x3                ; =3
   23688:      	mov	x21, x0
   2368c:      	ldr	x0, [sp, #0x190]
   23690:      	cmp	x0, #0x19c
   23694:      	b.hs	0x212c8 <_mech_canonical_program_entry_v1_numeric_1282+0x4148>
   23698:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   2369c:      	mov	x0, #0x6cc              ; =1740
   236a0:      	ldur	x28, [sp]
   236a4:      	str	x0, [x28, #0x48]
   236a8:      	mov	x0, #0x0                ; =0
   236ac:      	str	x0, [x19, #0x4c60]
   236b0:      	mov	x0, #0x3                ; =3
   236b4:      	ldr	x7, [sp, #0x190]
   236b8:      	mov	x21, x0
   236bc:      	cmp	x7, #0x19c
   236c0:      	b.hs	0x21478 <_mech_canonical_program_entry_v1_numeric_1282+0x42f8>
   236c4:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   236c8:      	mov	x14, #0x6d0             ; =1744
   236cc:      	ldur	x28, [sp]
   236d0:      	str	x14, [x28, #0x48]
   236d4:      	mov	x14, #0x0               ; =0
   236d8:      	str	x14, [x19, #0x4c60]
   236dc:      	mov	x0, #0x3                ; =3
   236e0:      	mov	x21, x0
   236e4:      	ldr	x0, [sp, #0x190]
   236e8:      	cmp	x0, #0x19c
   236ec:      	b.hs	0x2162c <_mech_canonical_program_entry_v1_numeric_1282+0x44ac>
   236f0:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   236f4:      	mov	x0, #0x6d4              ; =1748
   236f8:      	ldur	x28, [sp]
   236fc:      	str	x0, [x28, #0x48]
   23700:      	mov	x0, #0x0                ; =0
   23704:      	str	x0, [x19, #0x4c60]
   23708:      	mov	x0, #0x3                ; =3
   2370c:      	mov	x21, x0
   23710:      	ldr	x0, [sp, #0x190]
   23714:      	cmp	x0, #0x19c
   23718:      	b.hs	0x217e0 <_mech_canonical_program_entry_v1_numeric_1282+0x4660>
   2371c:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   23720:      	mov	x5, #0x6dd              ; =1757
   23724:      	ldur	x0, [sp]
   23728:      	str	x5, [x0, #0x48]
   2372c:      	mov	x7, #0x0                ; =0
   23730:      	str	x7, [x19, #0x18]
   23734:      	mov	x8, #0x1000000000000000 ; =1152921504606846976
   23738:      	str	x8, [x19, #0x20]
   2373c:      	mov	x0, #0x1                ; =1
   23740:      	mov	x21, x0
   23744:      	str	x0, [x19, #0x30]
   23748:      	mov	x14, #0x101010101010101 ; =72340172838076673
   2374c:      	str	x14, [x19, #0x38]
   23750:      	mov	x14, #0x2               ; =2
   23754:      	str	x14, [x19, #0x40]
   23758:      	mov	x14, #0x3               ; =3
   2375c:      	str	x14, [x19, #0x48]
   23760:      	mov	x14, #0x4               ; =4
   23764:      	str	x14, [x19, #0x50]
   23768:      	mov	x14, #0xf0f0f0f0f0f0f0f ; =1085102592571150095
   2376c:      	str	x14, [x19, #0x78]
   23770:      	mov	x14, #0x3333333333333333 ; =3689348814741910323
   23774:      	str	x14, [x19, #0x88]
   23778:      	mov	x0, #0x38               ; =56
   2377c:      	str	x0, [x19, #0x90]
   23780:      	mov	x0, #0x3a               ; =58
   23784:      	str	x0, [x19, #0x98]
   23788:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   2378c:      	str	x0, [x19, #0xb0]
   23790:      	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
   23794:      	str	x0, [x19, #0xb8]
   23798:      	str	x7, [x19, #0x188]
   2379c:      	mov	x0, x21
   237a0:      	str	x0, [x19, #0x190]
   237a4:      	str	x10, [x19, #0x17a0]
   237a8:      	str	x23, [x19, #0x17a8]
   237ac:      	str	x28, [x19, #0x4c60]
   237b0:      	str	x3, [x19, #0x4c68]
   237b4:      	ldur	x4, [sp, #0x98]
   237b8:      	str	x4, [x19, #0x4c70]
   237bc:      	ldur	x14, [sp, #0x60]
   237c0:      	str	x14, [x19, #0x5a20]
   237c4:      	str	x11, [x19, #0x5bb0]
   237c8:      	ldur	x26, [sp, #0xa0]
   237cc:      	str	x26, [x19, #0x5bb8]
   237d0:      	ldur	x7, [sp, #0xa8]
   237d4:      	str	x7, [x19, #0x5bc0]
   237d8:      	ldur	x4, [sp, #0x90]
   237dc:      	sub	x1, x4, x3
   237e0:      	mov	w0, #0xc87e             ; =51326
   237e4:      	movk	w0, #0x1, lsl #16
   237e8:      	msub	x0, x11, x0, x1
   237ec:      	str	x0, [x19, #0x5bc8]
   237f0:      	str	x24, [x19, #0x5bd0]
   237f4:      	str	x15, [x19, #0x5bd8]
   237f8:      	ldur	x8, [sp, #0xb0]
   237fc:      	str	x8, [x19, #0x5be8]
   23800:      	ldur	x4, [sp, #0xb8]
   23804:      	str	x4, [x19, #0x5bf0]
   23808:      	str	x12, [x19, #0x5c00]
   2380c:      	str	x9, [x19, #0x5c08]
   23810:      	str	x13, [x19, #0x5c18]
   23814:      	ldur	x13, [sp, #0xc0]
   23818:      	str	x13, [x19, #0x5c20]
   2381c:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   23820:      	mov	x0, #0x6b0              ; =1712
   23824:      	ldur	x1, [sp]
   23828:      	str	x0, [x1, #0x48]
   2382c:      	mov	x1, #0x0                ; =0
   23830:      	str	x1, [x19, #0x18]
   23834:      	str	x26, [x19, #0x20]
   23838:      	mov	x0, #0x1                ; =1
   2383c:      	mov	x21, x0
   23840:      	str	x0, [x19, #0x30]
   23844:      	mov	x0, #0x101010101010101  ; =72340172838076673
   23848:      	str	x0, [x19, #0x38]
   2384c:      	mov	x0, #0x2                ; =2
   23850:      	str	x0, [x19, #0x40]
   23854:      	mov	x0, #0x3                ; =3
   23858:      	str	x0, [x19, #0x48]
   2385c:      	mov	x0, #0x4                ; =4
   23860:      	str	x0, [x19, #0x50]
   23864:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   23868:      	str	x0, [x19, #0x78]
   2386c:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   23870:      	str	x0, [x19, #0x88]
   23874:      	mov	x0, #0x38               ; =56
   23878:      	str	x0, [x19, #0x90]
   2387c:      	mov	x0, #0x3a               ; =58
   23880:      	str	x0, [x19, #0x98]
   23884:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   23888:      	str	x0, [x19, #0xb0]
   2388c:      	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
   23890:      	str	x0, [x19, #0xb8]
   23894:      	str	x1, [x19, #0x188]
   23898:      	mov	x0, x21
   2389c:      	str	x0, [x19, #0x190]
   238a0:      	str	x22, [x19, #0x17a0]
   238a4:      	str	x23, [x19, #0x17a8]
   238a8:      	ldur	x25, [sp, #0xf0]
   238ac:      	uxtb	w2, w25
   238b0:      	str	x2, [x19, #0x17b8]
   238b4:      	str	x15, [x19, #0x1c70]
   238b8:      	str	x12, [x19, #0x1c78]
   238bc:      	str	x22, [x19, #0x1c80]
   238c0:      	str	x28, [x19, #0x4c60]
   238c4:      	str	x3, [x19, #0x4c68]
   238c8:      	ldur	x4, [sp, #0x98]
   238cc:      	str	x4, [x19, #0x4c70]
   238d0:      	ldur	x14, [sp, #0x60]
   238d4:      	str	x14, [x19, #0x5a20]
   238d8:      	add	x10, x11, #0x1
   238dc:      	str	x10, [x19, #0x5bb0]
   238e0:      	ldur	x26, [sp, #0xa0]
   238e4:      	str	x26, [x19, #0x5bb8]
   238e8:      	ldur	x7, [sp, #0xa8]
   238ec:      	str	x7, [x19, #0x5bc0]
   238f0:      	ldur	x4, [sp, #0x90]
   238f4:      	sub	x14, x4, x3
   238f8:      	mov	w15, #0xc87e            ; =51326
   238fc:      	movk	w15, #0x1, lsl #16
   23900:      	msub	x14, x10, x15, x14
   23904:      	str	x14, [x19, #0x5bc8]
   23908:      	str	x1, [x19, #0x5bd0]
   2390c:      	str	x1, [x19, #0x5bd8]
   23910:      	ldur	x8, [sp, #0xb0]
   23914:      	str	x8, [x19, #0x5be8]
   23918:      	ldur	x4, [sp, #0xb8]
   2391c:      	str	x4, [x19, #0x5bf0]
   23920:      	str	x0, [x19, #0x5c00]
   23924:      	ldur	x10, [sp, #0x50]
   23928:      	str	x10, [x19, #0x5c08]
   2392c:      	str	x13, [x19, #0x5c18]
   23930:      	ldur	x13, [sp, #0xc0]
   23934:      	str	x13, [x19, #0x5c20]
   23938:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   2393c:      	mov	x0, #0x6a0              ; =1696
   23940:      	ldur	x1, [sp]
   23944:      	str	x0, [x1, #0x48]
   23948:      	mov	x1, #0x0                ; =0
   2394c:      	str	x1, [x19, #0x18]
   23950:      	str	x26, [x19, #0x20]
   23954:      	mov	x0, #0x1                ; =1
   23958:      	mov	x21, x0
   2395c:      	str	x0, [x19, #0x30]
   23960:      	mov	x0, #0x101010101010101  ; =72340172838076673
   23964:      	str	x0, [x19, #0x38]
   23968:      	mov	x0, #0x2                ; =2
   2396c:      	str	x0, [x19, #0x40]
   23970:      	mov	x0, #0x3                ; =3
   23974:      	str	x0, [x19, #0x48]
   23978:      	mov	x0, #0x4                ; =4
   2397c:      	str	x0, [x19, #0x50]
   23980:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   23984:      	str	x0, [x19, #0x78]
   23988:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   2398c:      	str	x0, [x19, #0x88]
   23990:      	mov	x0, #0x38               ; =56
   23994:      	str	x0, [x19, #0x90]
   23998:      	mov	x0, #0x3a               ; =58
   2399c:      	str	x0, [x19, #0x98]
   239a0:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   239a4:      	str	x0, [x19, #0xb0]
   239a8:      	ldur	x6, [sp, #0xd0]
   239ac:      	str	x6, [x19, #0xb8]
   239b0:      	str	x1, [x19, #0x188]
   239b4:      	mov	x0, x21
   239b8:      	str	x0, [x19, #0x190]
   239bc:      	str	x22, [x19, #0x17a0]
   239c0:      	str	x23, [x19, #0x17a8]
   239c4:      	ldur	x25, [sp, #0xf0]
   239c8:      	uxtb	w0, w25
   239cc:      	str	x0, [x19, #0x17b8]
   239d0:      	str	x15, [x19, #0x1c70]
   239d4:      	str	x12, [x19, #0x1c78]
   239d8:      	str	x22, [x19, #0x1c80]
   239dc:      	str	x24, [x19, #0x1ca8]
   239e0:      	str	x27, [x19, #0x1d38]
   239e4:      	str	x13, [x19, #0x1d40]
   239e8:      	str	x22, [x19, #0x1d48]
   239ec:      	str	x28, [x19, #0x4c60]
   239f0:      	mov	w0, #0xcb86             ; =52102
   239f4:      	movk	w0, #0x2, lsl #16
   239f8:      	sub	x2, x3, x0
   239fc:      	str	x2, [x19, #0x4c68]
   23a00:      	ldur	x4, [sp, #0x98]
   23a04:      	str	x4, [x19, #0x4c70]
   23a08:      	ldur	x14, [sp, #0x60]
   23a0c:      	str	x14, [x19, #0x5a20]
   23a10:      	add	x3, x11, #0x1
   23a14:      	str	x3, [x19, #0x5bb0]
   23a18:      	ldur	x26, [sp, #0xa0]
   23a1c:      	str	x26, [x19, #0x5bb8]
   23a20:      	ldur	x7, [sp, #0xa8]
   23a24:      	str	x7, [x19, #0x5bc0]
   23a28:      	ldur	x4, [sp, #0x90]
   23a2c:      	sub	x2, x4, x2
   23a30:      	mov	w0, #0xc87e             ; =51326
   23a34:      	movk	w0, #0x1, lsl #16
   23a38:      	msub	x0, x3, x0, x2
   23a3c:      	str	x0, [x19, #0x5bc8]
   23a40:      	str	x1, [x19, #0x5bd0]
   23a44:      	str	x1, [x19, #0x5bd8]
   23a48:      	ldur	x8, [sp, #0xb0]
   23a4c:      	str	x8, [x19, #0x5be8]
   23a50:      	ldur	x4, [sp, #0xb8]
   23a54:      	str	x4, [x19, #0x5bf0]
   23a58:      	mov	x0, x21
   23a5c:      	str	x0, [x19, #0x5c00]
   23a60:      	ldur	x10, [sp, #0x50]
   23a64:      	str	x10, [x19, #0x5c08]
   23a68:      	str	x0, [x19, #0x5c18]
   23a6c:      	ldur	x5, [sp, #0x58]
   23a70:      	str	x5, [x19, #0x5c20]
   23a74:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   23a78:      	mov	x0, #0x5df              ; =1503
   23a7c:      	ldur	x1, [sp]
   23a80:      	str	x0, [x1, #0x48]
   23a84:      	mov	x1, #0x0                ; =0
   23a88:      	str	x1, [x19, #0x18]
   23a8c:      	mov	x0, #0x1000000000000000 ; =1152921504606846976
   23a90:      	str	x0, [x19, #0x20]
   23a94:      	mov	x0, #0x1                ; =1
   23a98:      	mov	x21, x0
   23a9c:      	str	x0, [x19, #0x30]
   23aa0:      	mov	x0, #0x101010101010101  ; =72340172838076673
   23aa4:      	str	x0, [x19, #0x38]
   23aa8:      	mov	x0, #0x2                ; =2
   23aac:      	str	x0, [x19, #0x40]
   23ab0:      	mov	x0, #0x3                ; =3
   23ab4:      	str	x0, [x19, #0x48]
   23ab8:      	mov	x0, #0x4                ; =4
   23abc:      	str	x0, [x19, #0x50]
   23ac0:      	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
   23ac4:      	str	x0, [x19, #0x78]
   23ac8:      	mov	x0, #0x3333333333333333 ; =3689348814741910323
   23acc:      	str	x0, [x19, #0x88]
   23ad0:      	mov	x0, #0x38               ; =56
   23ad4:      	str	x0, [x19, #0x90]
   23ad8:      	mov	x0, #0x3a               ; =58
   23adc:      	str	x0, [x19, #0x98]
   23ae0:      	mov	x0, #0x5555555555555555 ; =6148914691236517205
   23ae4:      	str	x0, [x19, #0xb0]
   23ae8:      	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
   23aec:      	str	x0, [x19, #0xb8]
   23af0:      	str	x1, [x19, #0x188]
   23af4:      	mov	x0, x21
   23af8:      	str	x0, [x19, #0x190]
   23afc:      	str	x22, [x19, #0x17a0]
   23b00:      	str	x23, [x19, #0x17a8]
   23b04:      	ldur	x25, [sp, #0xf0]
   23b08:      	uxtb	w0, w25
   23b0c:      	str	x0, [x19, #0x17b8]
   23b10:      	str	x4, [x19, #0x1858]
   23b14:      	mov	x15, x26
   23b18:      	str	x15, [x19, #0x1860]
   23b1c:      	str	x22, [x19, #0x1868]
   23b20:      	ldur	x15, [sp, #0xe0]
   23b24:      	str	x15, [x19, #0x1870]
   23b28:      	str	x28, [x19, #0x4c60]
   23b2c:      	str	x3, [x19, #0x4c68]
   23b30:      	ldur	x4, [sp, #0x98]
   23b34:      	str	x4, [x19, #0x4c70]
   23b38:      	ldur	x14, [sp, #0x60]
   23b3c:      	str	x14, [x19, #0x5a20]
   23b40:      	add	x1, x11, #0x1
   23b44:      	str	x1, [x19, #0x5bb0]
   23b48:      	ldur	x26, [sp, #0xa0]
   23b4c:      	str	x26, [x19, #0x5bb8]
   23b50:      	ldur	x7, [sp, #0xa8]
   23b54:      	str	x7, [x19, #0x5bc0]
   23b58:      	ldur	x4, [sp, #0x90]
   23b5c:      	sub	x2, x4, x3
   23b60:      	mov	w0, #0xc87e             ; =51326
   23b64:      	movk	w0, #0x1, lsl #16
   23b68:      	msub	x0, x1, x0, x2
   23b6c:      	str	x0, [x19, #0x5bc8]
   23b70:      	mov	x0, x21
   23b74:      	str	x0, [x19, #0x5bd0]
   23b78:      	ldur	x14, [sp, #0x20]
   23b7c:      	str	x14, [x19, #0x5bd8]
   23b80:      	ldur	x8, [sp, #0xb0]
   23b84:      	str	x8, [x19, #0x5be8]
   23b88:      	ldur	x4, [sp, #0xb8]
   23b8c:      	str	x4, [x19, #0x5bf0]
   23b90:      	str	x12, [x19, #0x5c00]
   23b94:      	str	x9, [x19, #0x5c08]
   23b98:      	str	x13, [x19, #0x5c18]
   23b9c:      	ldur	x13, [sp, #0xc0]
   23ba0:      	str	x13, [x19, #0x5c20]
   23ba4:      	b	0x23cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6b78>
   23ba8:      	mov	x1, #0x5cf              ; =1487
   23bac:      	ldur	x5, [sp]
   23bb0:      	str	x1, [x5, #0x48]
   23bb4:      	mov	x2, #0x0                ; =0
   23bb8:      	str	x2, [x19, #0x18]
   23bbc:      	mov	x4, #0x1000000000000000 ; =1152921504606846976
   23bc0:      	str	x4, [x19, #0x20]
   23bc4:      	mov	x0, #0x1                ; =1
   23bc8:      	mov	x21, x0
   23bcc:      	str	x0, [x19, #0x30]
   23bd0:      	mov	x5, #0x101010101010101  ; =72340172838076673
   23bd4:      	str	x5, [x19, #0x38]
   23bd8:      	mov	x8, #0x2                ; =2
   23bdc:      	str	x8, [x19, #0x40]
   23be0:      	mov	x8, #0x3                ; =3
   23be4:      	str	x8, [x19, #0x48]
   23be8:      	mov	x8, #0x4                ; =4
   23bec:      	str	x8, [x19, #0x50]
   23bf0:      	mov	x10, #0xf0f0f0f0f0f0f0f ; =1085102592571150095
   23bf4:      	str	x10, [x19, #0x78]
   23bf8:      	mov	x10, #0x3333333333333333 ; =3689348814741910323
   23bfc:      	str	x10, [x19, #0x88]
   23c00:      	mov	x15, #0x38              ; =56
   23c04:      	str	x15, [x19, #0x90]
   23c08:      	mov	x15, #0x3a              ; =58
   23c0c:      	str	x15, [x19, #0x98]
   23c10:      	mov	x15, #0x5555555555555555 ; =6148914691236517205
   23c14:      	str	x15, [x19, #0xb0]
   23c18:      	mov	x15, #0x3ffffffffffffff ; =288230376151711743
   23c1c:      	str	x15, [x19, #0xb8]
   23c20:      	str	x2, [x19, #0x188]
   23c24:      	str	x0, [x19, #0x190]
   23c28:      	str	x22, [x19, #0x17a0]
   23c2c:      	str	x23, [x19, #0x17a8]
   23c30:      	ldur	x25, [sp, #0xf0]
   23c34:      	uxtb	w0, w25
   23c38:      	str	x0, [x19, #0x17b8]
   23c3c:      	ldur	x27, [sp, #0x18]
   23c40:      	str	x27, [x19, #0x1858]
   23c44:      	mov	x15, x26
   23c48:      	str	x15, [x19, #0x1860]
   23c4c:      	str	x22, [x19, #0x1868]
   23c50:      	ldur	x15, [sp, #0xe0]
   23c54:      	str	x15, [x19, #0x1870]
   23c58:      	ldur	x15, [sp, #0xd8]
   23c5c:      	uxtb	w0, w15
   23c60:      	str	x0, [x19, #0x1880]
   23c64:      	str	x14, [x19, #0x1918]
   23c68:      	str	x7, [x19, #0x1920]
   23c6c:      	str	x22, [x19, #0x1928]
   23c70:      	ldur	x15, [sp, #0xe0]
   23c74:      	str	x15, [x19, #0x1930]
   23c78:      	str	x28, [x19, #0x4c60]
   23c7c:      	mov	w0, #0xdc1e             ; =56350
   23c80:      	movk	w0, #0x2, lsl #16
   23c84:      	sub	x1, x6, x0
   23c88:      	str	x1, [x19, #0x4c68]
   23c8c:      	ldur	x4, [sp, #0x98]
   23c90:      	str	x4, [x19, #0x4c70]
   23c94:      	ldur	x14, [sp, #0x60]
   23c98:      	str	x14, [x19, #0x5a20]
   23c9c:      	add	x2, x11, #0x1
   23ca0:      	str	x2, [x19, #0x5bb0]
   23ca4:      	ldur	x26, [sp, #0xa0]
   23ca8:      	str	x26, [x19, #0x5bb8]
   23cac:      	ldur	x7, [sp, #0xa8]
   23cb0:      	str	x7, [x19, #0x5bc0]
   23cb4:      	ldur	x4, [sp, #0x90]
   23cb8:      	sub	x1, x4, x1
   23cbc:      	mov	w0, #0xc87e             ; =51326
   23cc0:      	movk	w0, #0x1, lsl #16
   23cc4:      	msub	x0, x2, x0, x1
   23cc8:      	str	x0, [x19, #0x5bc8]
   23ccc:      	mov	x0, x21
   23cd0:      	str	x0, [x19, #0x5bd0]
   23cd4:      	ldur	x14, [sp, #0x20]
   23cd8:      	str	x14, [x19, #0x5bd8]
   23cdc:      	str	x0, [x19, #0x5be8]
   23ce0:      	str	x3, [x19, #0x5bf0]
   23ce4:      	str	x12, [x19, #0x5c00]
   23ce8:      	str	x9, [x19, #0x5c08]
   23cec:      	str	x13, [x19, #0x5c18]
   23cf0:      	ldur	x13, [sp, #0xc0]
   23cf4:      	str	x13, [x19, #0x5c20]
   23cf8:      	mov	x1, #0x0                ; =0
   23cfc:      	mov	x0, x21
   23d00:      	add	sp, sp, #0x1c0
   23d04:      	ldp	x19, x20, [sp], #0x10
   23d08:      	ldp	x21, x22, [sp], #0x10
   23d0c:      	ldp	x23, x24, [sp], #0x10
   23d10:      	ldp	x25, x26, [sp], #0x10
   23d14:      	ldp	x27, x28, [sp], #0x10
   23d18:      	ldp	x29, x30, [sp], #0x10
   23d1c:      	retab
		...
