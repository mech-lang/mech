target triple = "arm64-apple-macosx15.0.0"
declare void @escape(ptr)
define i64 @leaf(i64 %a) #0 {
entry:
  %v = add i64 %a, 7
  ret i64 %v
}
define double @floating(double %a, double %b) #0 {
entry:
  %v = fadd double %a, %b
  ret double %v
}
define i64 @with_stack(i64 %a) #0 {
entry:
  %buf = alloca [64 x i64], align 16
  store i64 %a, ptr %buf, align 16
  call void @escape(ptr %buf)
  %v = load i64, ptr %buf, align 16
  ret i64 %v
}
attributes #0 = { nounwind noredzone "frame-pointer"="none" }
