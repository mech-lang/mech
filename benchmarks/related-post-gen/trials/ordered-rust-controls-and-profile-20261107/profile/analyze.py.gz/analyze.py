from pathlib import Path
import json,hashlib,struct,collections,bisect,importlib.util
P=Path(__file__).parent;R=Path('/Users/cim310/mech-lang/mech/benchmarks/related-post-gen')
spec=importlib.util.spec_from_file_location('audit',R/'audit-native-link.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
results={}
for label in ['selected-ir242','candidate-ir264']:
 p=P/label;run=json.loads((p/'run.json').read_text());assert run['exit']==0 and run['iterations']==1500 and run['every_iteration_indices_exact'];stats=run['stats'];data,sections,symbols=a.macho(p/'runner-profile')
 offset=32;base=None
 for _ in range(struct.unpack_from('<I',data,16)[0]):
  cmd,size=struct.unpack_from('<II',data,offset)
  if cmd==25 and data[offset+8:offset+24].rstrip(b'\0')==b'__TEXT':base=struct.unpack_from('<Q',data,offset+24)[0]
  offset+=size
 assert base is not None
 text=next(s for s in sections if s['name']=='__text');symbols=sorted([s for s in symbols if s['section']and sections[s['section']-1]['name']=='__text'],key=lambda s:s['value']);starts=[s['value']for s in symbols]
 resolved={}
 for line in(p/'output.json.samples.bin.symbols.tsv').read_text().splitlines():
  pc,_,_,image,symbol=line.split('\t',4);resolved[int(pc,16)]=(image,symbol)
 allcounts=collections.Counter();running=collections.Counter();states=collections.Counter();phases=set();pcs=collections.defaultdict(collections.Counter);threads=collections.defaultdict(collections.Counter);categories=collections.Counter();unknown=0
 raw=(p/'output.json.samples.bin').read_bytes();assert len(raw)==stats['records']*88
 for ns,thread,pc,lr,sp,fp,phase,state,user_us,system_us,tid in struct.iter_unpack('<11Q',raw):
  assert phase&1 and 1<=phase<=2999;phases.add(phase);states[state]+=1;address=pc-stats['image_base']+base;symbol=None;at=0
  if text['address']<=address<text['address']+text['size']:
   i=bisect.bisect_right(starts,address)-1
   if i>=0:s=symbols[i];symbol=s['name'];at=address-s['value']
  if symbol is None:
   image,symbol=resolved.get(pc,('-','-'));symbol=str(Path(image).name)+':'+symbol
   if symbol=='-:-':unknown+=1
  allcounts[symbol]+=1
  if state==1:
   running[symbol]+=1;threads[tid][symbol]+=1
   if symbol.startswith('_mech_canonical_program_entry_v1'):pcs[symbol][at]+=1;categories['native_program']+=1
   elif text['address']<=address<text['address']+text['size']:categories['host_executable']+=1
   else:categories['external_image_or_unknown']+=1
 result=dict(schema='mech.related-post-gen.post-json-all-thread-pc.v1',variant=label,profile_timings_excluded=True,correct_evaluations=1500,native_Object_text_unchanged=True,sampler=stats,all_records_in_one_active_post_JSON_epoch=True,observed_epochs=len(phases),run_state_counts=dict(states),running_observations=sum(running.values()),running_categories=dict(categories),unresolved_observations=unknown,all_top_symbols=allcounts.most_common(60),running_top_symbols=running.most_common(60),running_native_function_observations={k:sum(v.values())for k,v in pcs.items()},running_native_pc_offsets={k:dict(v)for k,v in pcs.items()},running_threads={str(t):dict(total=sum(v.values()),top=v.most_common(8))for t,v in threads.items()},limitations=['These are statistical register observations, not retired instructions or precise CPU-time shares. Running state is sampled from Mach THREAD_BASIC_INFO; transient/disappearing workers may be absent.','Every observation has the same odd epoch before/after capture; clone, verification, JSON output and teardown are outside the gate. Program restore and original JSON parse happen once, before profiling.','Per-thread cumulative CPU counters are captured for provenance but not converted to function-time weights: short-lived workers and first observations would bias such estimates.','All executable/profile elapsed and memory readings are excluded from eligible performance/resource comparisons. No user thread is suspended.'])
 (p/'summary.json').write_text(json.dumps(result,indent=2)+'\n');results[label]=result
 print(label,json.dumps(dict(records=stats['records'],run_states=dict(states),running=sum(running.values()),running_categories=dict(categories),top=running.most_common(12),native=result['running_native_function_observations'])),flush=True)
(P/'summary.json').write_text(json.dumps(dict(schema='mech.related-post-gen.current-post-json-all-thread-profile.v1',rows=results),indent=2)+'\n')
