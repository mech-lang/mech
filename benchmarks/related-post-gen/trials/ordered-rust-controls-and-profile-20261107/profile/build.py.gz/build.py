from pathlib import Path
import subprocess,hashlib,json,time,os
P=Path(__file__).parent;R=Path('/Users/cim310/mech-lang/mech/benchmarks/related-post-gen');OLD=Path('/private/tmp/mech-related-invariant-capture-all-thread-profile-20261107-v1/selected-ir242/runner.rs')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sampler=(R/'results/native-fixed-frame-arenas-20261106/post-json-pc-profile/sampler.c').read_text()
sampler=sampler.replace('#define CAPACITY 60000','#define CAPACITY 200000').replace('uint64_t at_ns, thread, pc, lr, sp, fp, phase;','uint64_t at_ns, thread, pc, lr, sp, fp, phase, run_state, user_us, system_us, tid;').replace('15000000000ULL','120000000000ULL')
needle='''    record->thread = target;
    record->pc ='''
repl='''    thread_basic_info_data_t basic = {0};
    mach_msg_type_number_t basic_count = THREAD_BASIC_INFO_COUNT;
    if (thread_info(target, THREAD_BASIC_INFO, (thread_info_t)&basic, &basic_count) == KERN_SUCCESS) {
        record->run_state = (uint64_t)basic.run_state;
        record->user_us = (uint64_t)basic.user_time.seconds * 1000000ULL + (uint64_t)basic.user_time.microseconds;
        record->system_us = (uint64_t)basic.system_time.seconds * 1000000ULL + (uint64_t)basic.system_time.microseconds;
    }
    thread_identifier_info_data_t identifier = {0};
    mach_msg_type_number_t identifier_count = THREAD_IDENTIFIER_INFO_COUNT;
    if (thread_info(target, THREAD_IDENTIFIER_INFO, (thread_info_t)&identifier, &identifier_count) == KERN_SUCCESS) {
        record->tid = identifier.thread_id;
    }
    record->thread = target;
    record->pc ='''
assert sampler.count(needle)==1;sampler=sampler.replace(needle,repl);(P/'sampler.c').write_text(sampler)
def run(cmd,path):
 start=time.monotonic();r=subprocess.run(list(map(str,cmd)),capture_output=True,text=True,env={**os.environ,'RUSTC_BOOTSTRAP':'1'});v=dict(command=list(map(str,cmd)),exit=r.returncode,seconds=time.monotonic()-start,stdout=r.stdout,stderr=r.stderr,profile_timings_excluded=True);path.write_text(json.dumps(v,indent=2)+'\n');assert r.returncode==0,r.stdout+r.stderr
run(['cc','-O3','-Wall','-Wextra','-Werror','-c',P/'sampler.c','-o',P/'sampler.o'],P/'sampler-build.json')
rows={}
for label,bundle in [('selected-ir242','/private/tmp/mech-related-conjoined-window-integration-runners-20261107-v1/reuse-4'),('candidate-ir264','/private/tmp/mech-related-forward-read-windows-runners-20261107-v8/reuse-4')]:
 B=Path(bundle);p=P/label;p.mkdir(exist_ok=True);(p/'build').symlink_to(B/'build',target_is_directory=True)
 source=OLD.read_text().replace('Diagnostic main-thread sampling','Diagnostic post-JSON all-thread sampling')
 source=source.replace('assert_eq!(unsafe { sam_init() }, 0','assert_eq!(unsafe { mpc_init() }, 0').replace('unsafe { sam_enable(1) };','assert_eq!(unsafe { mpc_phase(1) }, sample as u64 * 2 + 1);\n        unsafe { mpc_enable(1) };').replace('unsafe { sam_enable(0) };','assert_eq!(unsafe { mpc_phase(0) }, sample as u64 * 2 + 2);\n        unsafe { mpc_enable(0) };')
 source=source.replace('    let symbols = std::ffi::CString::new(format!("{}.symbols.tsv", args[2])).unwrap();\n','').replace('sam_finish(binary.as_ptr(),stats.as_ptr(),symbols.as_ptr())','mpc_finish(binary.as_ptr(),stats.as_ptr())')
 source=source[:source.index('unsafe extern "C" {')]+'''unsafe extern "C" {
    fn mpc_init() -> i32;
    fn mpc_enable(active:i32);
    fn mpc_phase(active:i32) -> u64;
    fn mpc_finish(binary:*const std::ffi::c_char,stats:*const std::ffi::c_char) -> i32;
}
'''
 assert 'sam_enable'not in source and 'sam_finish'not in source
 (p/'runner.rs').write_text(source)
 b=json.loads((B/'runner-aot.build.json').read_text());cmd=b['command'][:]
 src=b['source_path'];assert cmd.count(src)==1;cmd[cmd.index(src)]=str(p/'runner.rs');idx=cmd.index('-o');cmd[idx+1]=str(p/'runner-profile');cmd[1:1]=['-C','link-arg='+str(P/'sampler.o')]
 run(cmd,p/'build.json')
 run(['python3',R/'audit-native-link.py','--object',p/'build/object.o','--executable',p/'runner-profile','--output',p/'native-link-audit.json'],p/'audit-run.json')
 a=json.loads((p/'native-link-audit.json').read_text());old=json.loads((B/'native-link-audit.json').read_text());assert a['status']==old['status']=='passed' and a['normalized_text_sha256']==old['normalized_text_sha256']
 rows[label]=dict(original_bundle=str(B),source_sha256=sha(p/'build/source.mec'),original_executable_sha256=sha(B/'runner-aot'),profile_source_sha256=sha(p/'runner.rs'),profile_executable_sha256=sha(p/'runner-profile'),native_Object_text_unchanged=True,record_bytes=88,all_thread_capture=True,phase_gate_excludes_driver_clone_verification_and_teardown=True,profile_timings_excluded=True)
 (P/'builds.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,'profile built; native text unchanged',flush=True)
