from pathlib import Path
import subprocess,time,json,hashlib,os,re
P=Path(__file__).parent;INPUT=Path('/private/tmp/mech-related-current-input-fixtures-20261107/posts.json');ORACLE=Path('/private/tmp/mech-related-frozen-native-composition-latency-20261105-v1/related_posts_rust.json');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
snapshot=subprocess.check_output(['ps','-axo','pid,ppid,etime,pcpu,command'],text=True);own={os.getpid(),os.getppid()};busy=[]
for line in snapshot.splitlines()[1:]:
 a=line.split(None,4)
 if len(a)!=5 or int(a[0])in own:continue
 if re.search(r'(?:^|/)(?:rustc|cargo|clang|clang\+\+|sample)(?:\s|$)',a[4])or re.search(r'/mech_gpu-tests(?:\s|$)|/one-kib(?:\s|$)|/runner-(?:aot|metrics|profile)(?:\s|$)|compare-implementations\.py|build-metrics\.py',a[4]):busy.append(line)
assert not busy,busy
(P/'quiet-start-gate.json').write_text(json.dumps(dict(quiet=True,process_snapshot=snapshot,profile_timings_excluded=True,scope='Exact continuous post-JSON phase; task threads except sampler, with run-state metadata. Program/JSON template restored once; clone/verification/teardown gate closed.'),indent=2)+'\n')
rows={}
for name in ['selected-ir242','candidate-ir264']:
 p=P/name;cmd=[str(p/'runner-profile'),str(p/'build/source.mec'),str(INPUT),str(p/'output.json'),'1500'];start=time.monotonic()
 with (p/'stdout.log').open('w')as out,(p/'stderr.log').open('w')as err:r=subprocess.run(cmd,stdout=out,stderr=err,timeout=120)
 output=[json.loads(s)for s in(p/'stdout.log').read_text().splitlines()if s.startswith('{')];stats=json.loads((p/'output.json.sampler.json').read_text())if(p/'output.json.sampler.json').exists()else None
 receipt=dict(command=cmd,exit=r.returncode,diagnostic_seconds=time.monotonic()-start,iterations=len(output),input_sha256=sha(INPUT),oracle_sha256=sha(ORACLE),binary_sha256=sha(p/'runner-profile'),timings_excluded=True,stats=stats)
 (p/'run.json').write_text(json.dumps(receipt,indent=2)+'\n');assert r.returncode==0 and len(output)==1500,(name,receipt,(p/'stderr.log').read_text());assert json.loads((p/'output.json').read_text())==json.loads(ORACLE.read_text())
 assert stats['record_bytes']==88 and stats['last_phase_epoch']==3000 and stats['full']==0 and stats['suspended']==0 and stats['resumed']==0 and stats['records']>0
 receipt.update(every_iteration_indices_exact=True,first_last_full_json_exact=True,phase_gate_excludes_clone_verification_teardown=True);(p/'run.json').write_text(json.dumps(receipt,indent=2)+'\n');rows[name]=receipt
 print(name,'1500 exact evaluations;',stats['records'],'timer-gated thread observations',flush=True)
(P/'capture-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
