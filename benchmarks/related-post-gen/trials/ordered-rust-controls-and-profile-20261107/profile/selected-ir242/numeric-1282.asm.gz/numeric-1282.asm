
/private/tmp/mech-related-current-post-json-all-thread-profile-20261107-v1/selected-ir242/runner-profile:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001005e1680 <_mech_canonical_program_entry_v1_numeric_1282>:
1005e1680: d503237f    	pacibsp
1005e1684: a9bf7bfd    	stp	x29, x30, [sp, #-0x10]!
1005e1688: 910003fd    	mov	x29, sp
1005e168c: a9bf73fb    	stp	x27, x28, [sp, #-0x10]!
1005e1690: a9bf6bf9    	stp	x25, x26, [sp, #-0x10]!
1005e1694: a9bf63f7    	stp	x23, x24, [sp, #-0x10]!
1005e1698: a9bf5bf5    	stp	x21, x22, [sp, #-0x10]!
1005e169c: a9bf53f3    	stp	x19, x20, [sp, #-0x10]!
1005e16a0: d106c3ff    	sub	sp, sp, #0x1b0
1005e16a4: f80083e2    	stur	x2, [sp, #0x8]
1005e16a8: f9402815    	ldr	x21, [x0, #0x50]
1005e16ac: f900cff5    	str	x21, [sp, #0x198]
1005e16b0: f9402c06    	ldr	x6, [x0, #0x58]
1005e16b4: f9403002    	ldr	x2, [x0, #0x60]
1005e16b8: f940340e    	ldr	x14, [x0, #0x68]
1005e16bc: f80003e0    	stur	x0, [sp]
1005e16c0: f900c3ee    	str	x14, [sp, #0x180]
1005e16c4: d2800060    	mov	x0, #0x3                ; =3
1005e16c8: f10002bf    	cmp	x21, #0x0
1005e16cc: 54026aa0    	b.eq	0x1005e6420 <_mech_canonical_program_entry_v1_numeric_1282+0x4da0>
1005e16d0: d2800060    	mov	x0, #0x3                ; =3
1005e16d4: f10000df    	cmp	x6, #0x0
1005e16d8: f900cbe6    	str	x6, [sp, #0x190]
1005e16dc: 54026a60    	b.eq	0x1005e6428 <_mech_canonical_program_entry_v1_numeric_1282+0x4da8>
1005e16e0: d2800060    	mov	x0, #0x3                ; =3
1005e16e4: f80b83e0    	stur	x0, [sp, #0xb8]
1005e16e8: f100005f    	cmp	x2, #0x0
1005e16ec: 54037460    	b.eq	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e16f0: f9663020    	ldr	x0, [x1, #0x4c60]
1005e16f4: f100001f    	cmp	x0, #0x0
1005e16f8: aa0003fa    	mov	x26, x0
1005e16fc: 54004300    	b.eq	0x1005e1f5c <_mech_canonical_program_entry_v1_numeric_1282+0x8dc>
1005e1700: f940085c    	ldr	x28, [x2, #0x10]
1005e1704: f94bd020    	ldr	x0, [x1, #0x17a0]
1005e1708: f94bd420    	ldr	x0, [x1, #0x17a8]
1005e170c: f94bdc20    	ldr	x0, [x1, #0x17b8]
1005e1710: f94be820    	ldr	x0, [x1, #0x17d0]
1005e1714: f94bec20    	ldr	x0, [x1, #0x17d8]
1005e1718: f94bf020    	ldr	x0, [x1, #0x17e0]
1005e171c: f94bf420    	ldr	x0, [x1, #0x17e8]
1005e1720: f94bf820    	ldr	x0, [x1, #0x17f0]
1005e1724: f94bfc20    	ldr	x0, [x1, #0x17f8]
1005e1728: f94c0420    	ldr	x0, [x1, #0x1808]
1005e172c: f94c0820    	ldr	x0, [x1, #0x1810]
1005e1730: f94c0c20    	ldr	x0, [x1, #0x1818]
1005e1734: f94c1020    	ldr	x0, [x1, #0x1820]
1005e1738: f94c2c20    	ldr	x0, [x1, #0x1858]
1005e173c: f94c3020    	ldr	x0, [x1, #0x1860]
1005e1740: f94c3420    	ldr	x0, [x1, #0x1868]
1005e1744: f94c3820    	ldr	x0, [x1, #0x1870]
1005e1748: f94c4020    	ldr	x0, [x1, #0x1880]
1005e174c: f94c4820    	ldr	x0, [x1, #0x1890]
1005e1750: f94c4c20    	ldr	x0, [x1, #0x1898]
1005e1754: f94c5020    	ldr	x0, [x1, #0x18a0]
1005e1758: f94c5420    	ldr	x0, [x1, #0x18a8]
1005e175c: f94c5820    	ldr	x0, [x1, #0x18b0]
1005e1760: f94c5c20    	ldr	x0, [x1, #0x18b8]
1005e1764: f94c6420    	ldr	x0, [x1, #0x18c8]
1005e1768: f94c6820    	ldr	x0, [x1, #0x18d0]
1005e176c: f94c6c20    	ldr	x0, [x1, #0x18d8]
1005e1770: f94c7020    	ldr	x0, [x1, #0x18e0]
1005e1774: f94c8c20    	ldr	x0, [x1, #0x1918]
1005e1778: f94c9020    	ldr	x0, [x1, #0x1920]
1005e177c: f94c9420    	ldr	x0, [x1, #0x1928]
1005e1780: f94c9820    	ldr	x0, [x1, #0x1930]
1005e1784: f94ca020    	ldr	x0, [x1, #0x1940]
1005e1788: f94ca820    	ldr	x0, [x1, #0x1950]
1005e178c: f94cac20    	ldr	x0, [x1, #0x1958]
1005e1790: f94cb020    	ldr	x0, [x1, #0x1960]
1005e1794: f94cb820    	ldr	x0, [x1, #0x1970]
1005e1798: f94cbc20    	ldr	x0, [x1, #0x1978]
1005e179c: f94cc020    	ldr	x0, [x1, #0x1980]
1005e17a0: f94cc420    	ldr	x0, [x1, #0x1988]
1005e17a4: f94cc820    	ldr	x0, [x1, #0x1990]
1005e17a8: f94ccc20    	ldr	x0, [x1, #0x1998]
1005e17ac: f94cd020    	ldr	x0, [x1, #0x19a0]
1005e17b0: f94cd420    	ldr	x0, [x1, #0x19a8]
1005e17b4: f94cd820    	ldr	x0, [x1, #0x19b0]
1005e17b8: f94cdc20    	ldr	x0, [x1, #0x19b8]
1005e17bc: f94ce020    	ldr	x0, [x1, #0x19c0]
1005e17c0: f94ce420    	ldr	x0, [x1, #0x19c8]
1005e17c4: f94ce820    	ldr	x0, [x1, #0x19d0]
1005e17c8: f94cec20    	ldr	x0, [x1, #0x19d8]
1005e17cc: f94cf020    	ldr	x0, [x1, #0x19e0]
1005e17d0: f94cf420    	ldr	x0, [x1, #0x19e8]
1005e17d4: f94cf820    	ldr	x0, [x1, #0x19f0]
1005e17d8: f94cfc20    	ldr	x0, [x1, #0x19f8]
1005e17dc: f94d0020    	ldr	x0, [x1, #0x1a00]
1005e17e0: f94d0420    	ldr	x0, [x1, #0x1a08]
1005e17e4: f94d0820    	ldr	x0, [x1, #0x1a10]
1005e17e8: f94d0c20    	ldr	x0, [x1, #0x1a18]
1005e17ec: f94d1020    	ldr	x0, [x1, #0x1a20]
1005e17f0: f94d1420    	ldr	x0, [x1, #0x1a28]
1005e17f4: f94d1820    	ldr	x0, [x1, #0x1a30]
1005e17f8: f94d1c20    	ldr	x0, [x1, #0x1a38]
1005e17fc: f94d2020    	ldr	x0, [x1, #0x1a40]
1005e1800: f94d2420    	ldr	x0, [x1, #0x1a48]
1005e1804: f94d2820    	ldr	x0, [x1, #0x1a50]
1005e1808: f94d2c20    	ldr	x0, [x1, #0x1a58]
1005e180c: f94d3020    	ldr	x0, [x1, #0x1a60]
1005e1810: f94d3420    	ldr	x0, [x1, #0x1a68]
1005e1814: f94d3c20    	ldr	x0, [x1, #0x1a78]
1005e1818: f94d4020    	ldr	x0, [x1, #0x1a80]
1005e181c: f94d4820    	ldr	x0, [x1, #0x1a90]
1005e1820: f94d5020    	ldr	x0, [x1, #0x1aa0]
1005e1824: f94d5820    	ldr	x0, [x1, #0x1ab0]
1005e1828: f94d5c20    	ldr	x0, [x1, #0x1ab8]
1005e182c: f94d6020    	ldr	x0, [x1, #0x1ac0]
1005e1830: f94d6820    	ldr	x0, [x1, #0x1ad0]
1005e1834: f94d6c20    	ldr	x0, [x1, #0x1ad8]
1005e1838: f94d7420    	ldr	x0, [x1, #0x1ae8]
1005e183c: f94d7820    	ldr	x0, [x1, #0x1af0]
1005e1840: f94d8020    	ldr	x0, [x1, #0x1b00]
1005e1844: f94d8420    	ldr	x0, [x1, #0x1b08]
1005e1848: f94d8820    	ldr	x0, [x1, #0x1b10]
1005e184c: f94d9020    	ldr	x0, [x1, #0x1b20]
1005e1850: f94d9420    	ldr	x0, [x1, #0x1b28]
1005e1854: f94d9c20    	ldr	x0, [x1, #0x1b38]
1005e1858: f94da020    	ldr	x0, [x1, #0x1b40]
1005e185c: f94da820    	ldr	x0, [x1, #0x1b50]
1005e1860: f94dac20    	ldr	x0, [x1, #0x1b58]
1005e1864: f94db020    	ldr	x0, [x1, #0x1b60]
1005e1868: f94db820    	ldr	x0, [x1, #0x1b70]
1005e186c: f94dbc20    	ldr	x0, [x1, #0x1b78]
1005e1870: f94dc420    	ldr	x0, [x1, #0x1b88]
1005e1874: f94dc820    	ldr	x0, [x1, #0x1b90]
1005e1878: f94dd020    	ldr	x0, [x1, #0x1ba0]
1005e187c: f94dd420    	ldr	x0, [x1, #0x1ba8]
1005e1880: f94dd820    	ldr	x0, [x1, #0x1bb0]
1005e1884: f94ddc20    	ldr	x0, [x1, #0x1bb8]
1005e1888: f94de020    	ldr	x0, [x1, #0x1bc0]
1005e188c: f94dec20    	ldr	x0, [x1, #0x1bd8]
1005e1890: f94df820    	ldr	x0, [x1, #0x1bf0]
1005e1894: f94e0020    	ldr	x0, [x1, #0x1c00]
1005e1898: f94e0420    	ldr	x0, [x1, #0x1c08]
1005e189c: f94e0820    	ldr	x0, [x1, #0x1c10]
1005e18a0: f94e0c20    	ldr	x0, [x1, #0x1c18]
1005e18a4: f94e1420    	ldr	x0, [x1, #0x1c28]
1005e18a8: f94e1820    	ldr	x0, [x1, #0x1c30]
1005e18ac: f94e1c20    	ldr	x0, [x1, #0x1c38]
1005e18b0: f94e3820    	ldr	x0, [x1, #0x1c70]
1005e18b4: f94e3c20    	ldr	x0, [x1, #0x1c78]
1005e18b8: f94e4020    	ldr	x0, [x1, #0x1c80]
1005e18bc: f94e4820    	ldr	x0, [x1, #0x1c90]
1005e18c0: f94e4c20    	ldr	x0, [x1, #0x1c98]
1005e18c4: f94e5020    	ldr	x0, [x1, #0x1ca0]
1005e18c8: f94e5420    	ldr	x0, [x1, #0x1ca8]
1005e18cc: f94e5c20    	ldr	x0, [x1, #0x1cb8]
1005e18d0: f94e6020    	ldr	x0, [x1, #0x1cc0]
1005e18d4: f94e6420    	ldr	x0, [x1, #0x1cc8]
1005e18d8: f94e6820    	ldr	x0, [x1, #0x1cd0]
1005e18dc: f94e6c20    	ldr	x0, [x1, #0x1cd8]
1005e18e0: f94e7020    	ldr	x0, [x1, #0x1ce0]
1005e18e4: f94e7820    	ldr	x0, [x1, #0x1cf0]
1005e18e8: f94e7c20    	ldr	x0, [x1, #0x1cf8]
1005e18ec: f94e8020    	ldr	x0, [x1, #0x1d00]
1005e18f0: f94e9c20    	ldr	x0, [x1, #0x1d38]
1005e18f4: f94ea020    	ldr	x0, [x1, #0x1d40]
1005e18f8: f94ea420    	ldr	x0, [x1, #0x1d48]
1005e18fc: f94eac20    	ldr	x0, [x1, #0x1d58]
1005e1900: f94eb020    	ldr	x0, [x1, #0x1d60]
1005e1904: f94eb420    	ldr	x0, [x1, #0x1d68]
1005e1908: f94eb820    	ldr	x0, [x1, #0x1d70]
1005e190c: f94ebc20    	ldr	x0, [x1, #0x1d78]
1005e1910: f94ec020    	ldr	x0, [x1, #0x1d80]
1005e1914: f94ec420    	ldr	x0, [x1, #0x1d88]
1005e1918: f94ec820    	ldr	x0, [x1, #0x1d90]
1005e191c: f94ecc20    	ldr	x0, [x1, #0x1d98]
1005e1920: f94ed020    	ldr	x0, [x1, #0x1da0]
1005e1924: f94ed820    	ldr	x0, [x1, #0x1db0]
1005e1928: f94ee020    	ldr	x0, [x1, #0x1dc0]
1005e192c: f94ee420    	ldr	x0, [x1, #0x1dc8]
1005e1930: f94ee820    	ldr	x0, [x1, #0x1dd0]
1005e1934: f94eec20    	ldr	x0, [x1, #0x1dd8]
1005e1938: f94ef020    	ldr	x0, [x1, #0x1de0]
1005e193c: f94ef420    	ldr	x0, [x1, #0x1de8]
1005e1940: f94ef820    	ldr	x0, [x1, #0x1df0]
1005e1944: f94efc20    	ldr	x0, [x1, #0x1df8]
1005e1948: f94f0020    	ldr	x0, [x1, #0x1e00]
1005e194c: f94f0420    	ldr	x0, [x1, #0x1e08]
1005e1950: f94f0820    	ldr	x0, [x1, #0x1e10]
1005e1954: f94f0c20    	ldr	x0, [x1, #0x1e18]
1005e1958: f94f1020    	ldr	x0, [x1, #0x1e20]
1005e195c: f94f1420    	ldr	x0, [x1, #0x1e28]
1005e1960: f94f1820    	ldr	x0, [x1, #0x1e30]
1005e1964: f94f1c20    	ldr	x0, [x1, #0x1e38]
1005e1968: f94f2420    	ldr	x0, [x1, #0x1e48]
1005e196c: f94f2820    	ldr	x0, [x1, #0x1e50]
1005e1970: f94f3020    	ldr	x0, [x1, #0x1e60]
1005e1974: f94f3820    	ldr	x0, [x1, #0x1e70]
1005e1978: f94f4020    	ldr	x0, [x1, #0x1e80]
1005e197c: f94f4420    	ldr	x0, [x1, #0x1e88]
1005e1980: f94f4820    	ldr	x0, [x1, #0x1e90]
1005e1984: f94f5020    	ldr	x0, [x1, #0x1ea0]
1005e1988: f94f5420    	ldr	x0, [x1, #0x1ea8]
1005e198c: f94f5c20    	ldr	x0, [x1, #0x1eb8]
1005e1990: f94f6020    	ldr	x0, [x1, #0x1ec0]
1005e1994: f94f6820    	ldr	x0, [x1, #0x1ed0]
1005e1998: f94f6c20    	ldr	x0, [x1, #0x1ed8]
1005e199c: f94f7020    	ldr	x0, [x1, #0x1ee0]
1005e19a0: f94f7820    	ldr	x0, [x1, #0x1ef0]
1005e19a4: f94f7c20    	ldr	x0, [x1, #0x1ef8]
1005e19a8: f94f8420    	ldr	x0, [x1, #0x1f08]
1005e19ac: f94f8820    	ldr	x0, [x1, #0x1f10]
1005e19b0: f94f9020    	ldr	x0, [x1, #0x1f20]
1005e19b4: f94f9420    	ldr	x0, [x1, #0x1f28]
1005e19b8: f94f9820    	ldr	x0, [x1, #0x1f30]
1005e19bc: f94fa020    	ldr	x0, [x1, #0x1f40]
1005e19c0: f94fa420    	ldr	x0, [x1, #0x1f48]
1005e19c4: f94fac20    	ldr	x0, [x1, #0x1f58]
1005e19c8: f94fb020    	ldr	x0, [x1, #0x1f60]
1005e19cc: f94fb820    	ldr	x0, [x1, #0x1f70]
1005e19d0: f94fbc20    	ldr	x0, [x1, #0x1f78]
1005e19d4: f94fc020    	ldr	x0, [x1, #0x1f80]
1005e19d8: f94fc420    	ldr	x0, [x1, #0x1f88]
1005e19dc: f94fc820    	ldr	x0, [x1, #0x1f90]
1005e19e0: f94fd420    	ldr	x0, [x1, #0x1fa8]
1005e19e4: f94fe020    	ldr	x0, [x1, #0x1fc0]
1005e19e8: f94ff020    	ldr	x0, [x1, #0x1fe0]
1005e19ec: f94ff420    	ldr	x0, [x1, #0x1fe8]
1005e19f0: f94ff820    	ldr	x0, [x1, #0x1ff0]
1005e19f4: f9500020    	ldr	x0, [x1, #0x2000]
1005e19f8: f9500420    	ldr	x0, [x1, #0x2008]
1005e19fc: f9500820    	ldr	x0, [x1, #0x2010]
1005e1a00: f9501020    	ldr	x0, [x1, #0x2020]
1005e1a04: f9501420    	ldr	x0, [x1, #0x2028]
1005e1a08: f9501820    	ldr	x0, [x1, #0x2030]
1005e1a0c: f9502020    	ldr	x0, [x1, #0x2040]
1005e1a10: f9502420    	ldr	x0, [x1, #0x2048]
1005e1a14: f9502820    	ldr	x0, [x1, #0x2050]
1005e1a18: f9503020    	ldr	x0, [x1, #0x2060]
1005e1a1c: f9503420    	ldr	x0, [x1, #0x2068]
1005e1a20: f9503820    	ldr	x0, [x1, #0x2070]
1005e1a24: f9504420    	ldr	x0, [x1, #0x2088]
1005e1a28: f9631c20    	ldr	x0, [x1, #0x4638]
1005e1a2c: f9632020    	ldr	x0, [x1, #0x4640]
1005e1a30: f9632420    	ldr	x0, [x1, #0x4648]
1005e1a34: f9632820    	ldr	x0, [x1, #0x4650]
1005e1a38: f9632c20    	ldr	x0, [x1, #0x4658]
1005e1a3c: f9633020    	ldr	x0, [x1, #0x4660]
1005e1a40: f9633420    	ldr	x0, [x1, #0x4668]
1005e1a44: f9633820    	ldr	x0, [x1, #0x4670]
1005e1a48: f9633c20    	ldr	x0, [x1, #0x4678]
1005e1a4c: f9634020    	ldr	x0, [x1, #0x4680]
1005e1a50: f9634420    	ldr	x0, [x1, #0x4688]
1005e1a54: f9634820    	ldr	x0, [x1, #0x4690]
1005e1a58: f9634c20    	ldr	x0, [x1, #0x4698]
1005e1a5c: f9635020    	ldr	x0, [x1, #0x46a0]
1005e1a60: f9635420    	ldr	x0, [x1, #0x46a8]
1005e1a64: f9635820    	ldr	x0, [x1, #0x46b0]
1005e1a68: f9635c20    	ldr	x0, [x1, #0x46b8]
1005e1a6c: f9636020    	ldr	x0, [x1, #0x46c0]
1005e1a70: f9636420    	ldr	x0, [x1, #0x46c8]
1005e1a74: f9636820    	ldr	x0, [x1, #0x46d0]
1005e1a78: f9636c20    	ldr	x0, [x1, #0x46d8]
1005e1a7c: f9637020    	ldr	x0, [x1, #0x46e0]
1005e1a80: f9637420    	ldr	x0, [x1, #0x46e8]
1005e1a84: f9637820    	ldr	x0, [x1, #0x46f0]
1005e1a88: f9637c20    	ldr	x0, [x1, #0x46f8]
1005e1a8c: f9638020    	ldr	x0, [x1, #0x4700]
1005e1a90: f9638420    	ldr	x0, [x1, #0x4708]
1005e1a94: f9638820    	ldr	x0, [x1, #0x4710]
1005e1a98: f9638c20    	ldr	x0, [x1, #0x4718]
1005e1a9c: f9639020    	ldr	x0, [x1, #0x4720]
1005e1aa0: f9639420    	ldr	x0, [x1, #0x4728]
1005e1aa4: f9639820    	ldr	x0, [x1, #0x4730]
1005e1aa8: f9639c20    	ldr	x0, [x1, #0x4738]
1005e1aac: f963a020    	ldr	x0, [x1, #0x4740]
1005e1ab0: f963a420    	ldr	x0, [x1, #0x4748]
1005e1ab4: f963a820    	ldr	x0, [x1, #0x4750]
1005e1ab8: f963ac20    	ldr	x0, [x1, #0x4758]
1005e1abc: f963b020    	ldr	x0, [x1, #0x4760]
1005e1ac0: f963b420    	ldr	x0, [x1, #0x4768]
1005e1ac4: f963b820    	ldr	x0, [x1, #0x4770]
1005e1ac8: f963bc20    	ldr	x0, [x1, #0x4778]
1005e1acc: f963c020    	ldr	x0, [x1, #0x4780]
1005e1ad0: f963c420    	ldr	x0, [x1, #0x4788]
1005e1ad4: f963c820    	ldr	x0, [x1, #0x4790]
1005e1ad8: f963cc20    	ldr	x0, [x1, #0x4798]
1005e1adc: f963d020    	ldr	x0, [x1, #0x47a0]
1005e1ae0: f963d420    	ldr	x0, [x1, #0x47a8]
1005e1ae4: f963d820    	ldr	x0, [x1, #0x47b0]
1005e1ae8: f9663423    	ldr	x3, [x1, #0x4c68]
1005e1aec: f9663824    	ldr	x4, [x1, #0x4c70]
1005e1af0: aa0103e6    	mov	x6, x1
1005e1af4: f80803e4    	stur	x4, [sp, #0x80]
1005e1af8: f947b396    	ldr	x22, [x28, #0xf60]
1005e1afc: f947bb97    	ldr	x23, [x28, #0xf70]
1005e1b00: f9455c55    	ldr	x21, [x2, #0xab8]
1005e1b04: f9456058    	ldr	x24, [x2, #0xac0]
1005e1b08: f80503f8    	stur	x24, [sp, #0x50]
1005e1b0c: f9456440    	ldr	x0, [x2, #0xac8]
1005e1b10: f9456840    	ldr	x0, [x2, #0xad0]
1005e1b14: f9456c40    	ldr	x0, [x2, #0xad8]
1005e1b18: f900bfe0    	str	x0, [sp, #0x178]
1005e1b1c: f9457040    	ldr	x0, [x2, #0xae0]
1005e1b20: f900bbe0    	str	x0, [sp, #0x170]
1005e1b24: f9457440    	ldr	x0, [x2, #0xae8]
1005e1b28: f9457840    	ldr	x0, [x2, #0xaf0]
1005e1b2c: f9457c40    	ldr	x0, [x2, #0xaf8]
1005e1b30: f900b7e0    	str	x0, [sp, #0x168]
1005e1b34: f9458040    	ldr	x0, [x2, #0xb00]
1005e1b38: f900b3e0    	str	x0, [sp, #0x160]
1005e1b3c: f9458440    	ldr	x0, [x2, #0xb08]
1005e1b40: f9458840    	ldr	x0, [x2, #0xb10]
1005e1b44: f9458c40    	ldr	x0, [x2, #0xb18]
1005e1b48: f900afe0    	str	x0, [sp, #0x158]
1005e1b4c: f9459040    	ldr	x0, [x2, #0xb20]
1005e1b50: f900abe0    	str	x0, [sp, #0x150]
1005e1b54: f9459440    	ldr	x0, [x2, #0xb28]
1005e1b58: f9459840    	ldr	x0, [x2, #0xb30]
1005e1b5c: f9459c40    	ldr	x0, [x2, #0xb38]
1005e1b60: f900a7e0    	str	x0, [sp, #0x148]
1005e1b64: f945a040    	ldr	x0, [x2, #0xb40]
1005e1b68: f900a3e0    	str	x0, [sp, #0x140]
1005e1b6c: f945a440    	ldr	x0, [x2, #0xb48]
1005e1b70: f945a840    	ldr	x0, [x2, #0xb50]
1005e1b74: f945ac40    	ldr	x0, [x2, #0xb58]
1005e1b78: f9009fe0    	str	x0, [sp, #0x138]
1005e1b7c: f945b040    	ldr	x0, [x2, #0xb60]
1005e1b80: f9009be0    	str	x0, [sp, #0x130]
1005e1b84: f945b440    	ldr	x0, [x2, #0xb68]
1005e1b88: f945b840    	ldr	x0, [x2, #0xb70]
1005e1b8c: f945bc40    	ldr	x0, [x2, #0xb78]
1005e1b90: f90097e0    	str	x0, [sp, #0x128]
1005e1b94: f945c040    	ldr	x0, [x2, #0xb80]
1005e1b98: f90093e0    	str	x0, [sp, #0x120]
1005e1b9c: f945c440    	ldr	x0, [x2, #0xb88]
1005e1ba0: f945c840    	ldr	x0, [x2, #0xb90]
1005e1ba4: f945cc40    	ldr	x0, [x2, #0xb98]
1005e1ba8: f9008fe0    	str	x0, [sp, #0x118]
1005e1bac: f945d040    	ldr	x0, [x2, #0xba0]
1005e1bb0: f9008be0    	str	x0, [sp, #0x110]
1005e1bb4: f945d440    	ldr	x0, [x2, #0xba8]
1005e1bb8: f945d840    	ldr	x0, [x2, #0xbb0]
1005e1bbc: f945dc40    	ldr	x0, [x2, #0xbb8]
1005e1bc0: f90087e0    	str	x0, [sp, #0x108]
1005e1bc4: f945e040    	ldr	x0, [x2, #0xbc0]
1005e1bc8: f90083e0    	str	x0, [sp, #0x100]
1005e1bcc: f945e440    	ldr	x0, [x2, #0xbc8]
1005e1bd0: f945e840    	ldr	x0, [x2, #0xbd0]
1005e1bd4: f945ec40    	ldr	x0, [x2, #0xbd8]
1005e1bd8: f80f83e0    	stur	x0, [sp, #0xf8]
1005e1bdc: f945f054    	ldr	x20, [x2, #0xbe0]
1005e1be0: f80f03f4    	stur	x20, [sp, #0xf0]
1005e1be4: f945f440    	ldr	x0, [x2, #0xbe8]
1005e1be8: f945f840    	ldr	x0, [x2, #0xbf0]
1005e1bec: f9462441    	ldr	x1, [x2, #0xc48]
1005e1bf0: f80b03e1    	stur	x1, [sp, #0xb0]
1005e1bf4: f900c7e2    	str	x2, [sp, #0x188]
1005e1bf8: d2800008    	mov	x8, #0x0                ; =0
1005e1bfc: d2800024    	mov	x4, #0x1                ; =1
1005e1c00: f80883e4    	stur	x4, [sp, #0x88]
1005e1c04: aa0803e5    	mov	x5, x8
1005e1c08: aa0803e9    	mov	x9, x8
1005e1c0c: aa0803eb    	mov	x11, x8
1005e1c10: aa0803ec    	mov	x12, x8
1005e1c14: aa0803ed    	mov	x13, x8
1005e1c18: aa0803ee    	mov	x14, x8
1005e1c1c: aa0803ef    	mov	x15, x8
1005e1c20: aa0803f9    	mov	x25, x8
1005e1c24: f80783e3    	stur	x3, [sp, #0x78]
1005e1c28: f80a03e8    	stur	x8, [sp, #0xa0]
1005e1c2c: f80a83e8    	stur	x8, [sp, #0xa8]
1005e1c30: 52990fc0    	mov	w0, #0xc87e             ; =51326
1005e1c34: 72a00020    	movk	w0, #0x1, lsl #16
1005e1c38: eb00007f    	cmp	x3, x0
1005e1c3c: 9a9f37e1    	cset	x1, hs
1005e1c40: f84503e0    	ldur	x0, [sp, #0x50]
1005e1c44: f84b03ea    	ldur	x10, [sp, #0xb0]
1005e1c48: eb0a001f    	cmp	x0, x10
1005e1c4c: 9a9f87e0    	cset	x0, ls
1005e1c50: f84b03e2    	ldur	x2, [sp, #0xb0]
1005e1c54: f84503e4    	ldur	x4, [sp, #0x50]
1005e1c58: cb040042    	sub	x2, x2, x4
1005e1c5c: f100105f    	cmp	x2, #0x4
1005e1c60: 9a9f97e2    	cset	x2, hi
1005e1c64: 0a020007    	and	w7, w0, w2
1005e1c68: 0a070021    	and	w1, w1, w7
1005e1c6c: f80e83e7    	stur	x7, [sp, #0xe8]
1005e1c70: 53001c21    	uxtb	w1, w1
1005e1c74: b5001881    	cbnz	x1, 0x1005e1f84 <_mech_canonical_program_entry_v1_numeric_1282+0x904>
1005e1c78: d2800002    	mov	x2, #0x0                ; =0
1005e1c7c: aa0603f3    	mov	x19, x6
1005e1c80: f9000e62    	str	x2, [x19, #0x18]
1005e1c84: d2e20004    	mov	x4, #0x1000000000000000 ; =1152921504606846976
1005e1c88: f9001264    	str	x4, [x19, #0x20]
1005e1c8c: d2800024    	mov	x4, #0x1                ; =1
1005e1c90: f9001a64    	str	x4, [x19, #0x30]
1005e1c94: b200c3e6    	mov	x6, #0x101010101010101  ; =72340172838076673
1005e1c98: f9001e66    	str	x6, [x19, #0x38]
1005e1c9c: d2800046    	mov	x6, #0x2                ; =2
1005e1ca0: f9002266    	str	x6, [x19, #0x40]
1005e1ca4: d2800067    	mov	x7, #0x3                ; =3
1005e1ca8: f9002667    	str	x7, [x19, #0x48]
1005e1cac: d280008a    	mov	x10, #0x4               ; =4
1005e1cb0: f9002a6a    	str	x10, [x19, #0x50]
1005e1cb4: b200cfea    	mov	x10, #0xf0f0f0f0f0f0f0f ; =1085102592571150095
1005e1cb8: f9003e6a    	str	x10, [x19, #0x78]
1005e1cbc: b200e7ea    	mov	x10, #0x3333333333333333 ; =3689348814741910323
1005e1cc0: f900466a    	str	x10, [x19, #0x88]
1005e1cc4: d280070e    	mov	x14, #0x38              ; =56
1005e1cc8: f9004a6e    	str	x14, [x19, #0x90]
1005e1ccc: d280074e    	mov	x14, #0x3a              ; =58
1005e1cd0: f9004e6e    	str	x14, [x19, #0x98]
1005e1cd4: b200f3ee    	mov	x14, #0x5555555555555555 ; =6148914691236517205
1005e1cd8: f9005a6e    	str	x14, [x19, #0xb0]
1005e1cdc: 92ff800e    	mov	x14, #0x3ffffffffffffff ; =288230376151711743
1005e1ce0: f9005e6e    	str	x14, [x19, #0xb8]
1005e1ce4: f900c662    	str	x2, [x19, #0x188]
1005e1ce8: f900ca64    	str	x4, [x19, #0x190]
1005e1cec: aa1a03ea    	mov	x10, x26
1005e1cf0: f926326a    	str	x10, [x19, #0x4c60]
1005e1cf4: f9263663    	str	x3, [x19, #0x4c68]
1005e1cf8: f84803e4    	ldur	x4, [sp, #0x80]
1005e1cfc: f9263a64    	str	x4, [x19, #0x4c70]
1005e1d00: f927ba76    	str	x22, [x19, #0x4f70]
1005e1d04: f927be77    	str	x23, [x19, #0x4f78]
1005e1d08: f84503e1    	ldur	x1, [sp, #0x50]
1005e1d0c: f92d1261    	str	x1, [x19, #0x5a20]
1005e1d10: f92dda68    	str	x8, [x19, #0x5bb0]
1005e1d14: f84883e0    	ldur	x0, [sp, #0x88]
1005e1d18: f92dde60    	str	x0, [x19, #0x5bb8]
1005e1d1c: f92de265    	str	x5, [x19, #0x5bc0]
1005e1d20: f84783e4    	ldur	x4, [sp, #0x78]
1005e1d24: cb030080    	sub	x0, x4, x3
1005e1d28: 52990fc1    	mov	w1, #0xc87e             ; =51326
1005e1d2c: 72a00021    	movk	w1, #0x1, lsl #16
1005e1d30: 9b018100    	msub	x0, x8, x1, x0
1005e1d34: f92de660    	str	x0, [x19, #0x5bc8]
1005e1d38: f92dea79    	str	x25, [x19, #0x5bd0]
1005e1d3c: f92dee6f    	str	x15, [x19, #0x5bd8]
1005e1d40: f92df669    	str	x9, [x19, #0x5be8]
1005e1d44: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e1d48: f92dfa64    	str	x4, [x19, #0x5bf0]
1005e1d4c: f92e026c    	str	x12, [x19, #0x5c00]
1005e1d50: f92e066b    	str	x11, [x19, #0x5c08]
1005e1d54: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e1d58: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e1d5c: f92e126d    	str	x13, [x19, #0x5c20]
1005e1d60: f9663260    	ldr	x0, [x19, #0x4c60]
1005e1d64: f100001f    	cmp	x0, #0x0
1005e1d68: 54000fa0    	b.eq	0x1005e1f5c <_mech_canonical_program_entry_v1_numeric_1282+0x8dc>
1005e1d6c: f9663663    	ldr	x3, [x19, #0x4c68]
1005e1d70: f9663a64    	ldr	x4, [x19, #0x4c70]
1005e1d74: d2800000    	mov	x0, #0x0                ; =0
1005e1d78: f9263260    	str	x0, [x19, #0x4c60]
1005e1d7c: d2800060    	mov	x0, #0x3                ; =3
1005e1d80: f940c3e2    	ldr	x2, [sp, #0x180]
1005e1d84: f106685f    	cmp	x2, #0x19a
1005e1d88: 54023543    	b.lo	0x1005e6430 <_mech_canonical_program_entry_v1_numeric_1282+0x4db0>
1005e1d8c: f967ba60    	ldr	x0, [x19, #0x4f70]
1005e1d90: f940c7e1    	ldr	x1, [sp, #0x188]
1005e1d94: f9000820    	str	x0, [x1, #0x10]
1005e1d98: f967be62    	ldr	x2, [x19, #0x4f78]
1005e1d9c: f9000c22    	str	x2, [x1, #0x18]
1005e1da0: f96d1265    	ldr	x5, [x19, #0x5a20]
1005e1da4: f9056025    	str	x5, [x1, #0xac0]
1005e1da8: f9000820    	str	x0, [x1, #0x10]
1005e1dac: f9000c22    	str	x2, [x1, #0x18]
1005e1db0: f9686260    	ldr	x0, [x19, #0x50c0]
1005e1db4: f900b020    	str	x0, [x1, #0x160]
1005e1db8: f9686660    	ldr	x0, [x19, #0x50c8]
1005e1dbc: f900b420    	str	x0, [x1, #0x168]
1005e1dc0: f9686a60    	ldr	x0, [x19, #0x50d0]
1005e1dc4: f900b820    	str	x0, [x1, #0x170]
1005e1dc8: f9686e60    	ldr	x0, [x19, #0x50d8]
1005e1dcc: f900bc20    	str	x0, [x1, #0x178]
1005e1dd0: f9687260    	ldr	x0, [x19, #0x50e0]
1005e1dd4: f900c020    	str	x0, [x1, #0x180]
1005e1dd8: f9687660    	ldr	x0, [x19, #0x50e8]
1005e1ddc: f900c420    	str	x0, [x1, #0x188]
1005e1de0: f9687a60    	ldr	x0, [x19, #0x50f0]
1005e1de4: f900c820    	str	x0, [x1, #0x190]
1005e1de8: f9687e60    	ldr	x0, [x19, #0x50f8]
1005e1dec: f900cc20    	str	x0, [x1, #0x198]
1005e1df0: f9688260    	ldr	x0, [x19, #0x5100]
1005e1df4: f900d020    	str	x0, [x1, #0x1a0]
1005e1df8: f9695660    	ldr	x0, [x19, #0x52a8]
1005e1dfc: f901a420    	str	x0, [x1, #0x348]
1005e1e00: f9695a60    	ldr	x0, [x19, #0x52b0]
1005e1e04: f901a820    	str	x0, [x1, #0x350]
1005e1e08: f9695e60    	ldr	x0, [x19, #0x52b8]
1005e1e0c: f901ac20    	str	x0, [x1, #0x358]
1005e1e10: f9696260    	ldr	x0, [x19, #0x52c0]
1005e1e14: f901b020    	str	x0, [x1, #0x360]
1005e1e18: f9696660    	ldr	x0, [x19, #0x52c8]
1005e1e1c: f901b420    	str	x0, [x1, #0x368]
1005e1e20: f9696a60    	ldr	x0, [x19, #0x52d0]
1005e1e24: f901b820    	str	x0, [x1, #0x370]
1005e1e28: f9696e60    	ldr	x0, [x19, #0x52d8]
1005e1e2c: f901bc20    	str	x0, [x1, #0x378]
1005e1e30: f9697260    	ldr	x0, [x19, #0x52e0]
1005e1e34: f901c020    	str	x0, [x1, #0x380]
1005e1e38: f9697662    	ldr	x2, [x19, #0x52e8]
1005e1e3c: f901c422    	str	x2, [x1, #0x388]
1005e1e40: f96aee62    	ldr	x2, [x19, #0x55d8]
1005e1e44: f9033c22    	str	x2, [x1, #0x678]
1005e1e48: f96af265    	ldr	x5, [x19, #0x55e0]
1005e1e4c: f9034025    	str	x5, [x1, #0x680]
1005e1e50: f96af665    	ldr	x5, [x19, #0x55e8]
1005e1e54: f9034425    	str	x5, [x1, #0x688]
1005e1e58: f96afa65    	ldr	x5, [x19, #0x55f0]
1005e1e5c: f9034825    	str	x5, [x1, #0x690]
1005e1e60: f96afe66    	ldr	x6, [x19, #0x55f8]
1005e1e64: f9034c26    	str	x6, [x1, #0x698]
1005e1e68: f96b0267    	ldr	x7, [x19, #0x5600]
1005e1e6c: f9035027    	str	x7, [x1, #0x6a0]
1005e1e70: f96b0668    	ldr	x8, [x19, #0x5608]
1005e1e74: f9035428    	str	x8, [x1, #0x6a8]
1005e1e78: f96b0a69    	ldr	x9, [x19, #0x5610]
1005e1e7c: f9035829    	str	x9, [x1, #0x6b0]
1005e1e80: f96bd26a    	ldr	x10, [x19, #0x57a0]
1005e1e84: f904202a    	str	x10, [x1, #0x840]
1005e1e88: f96bd66b    	ldr	x11, [x19, #0x57a8]
1005e1e8c: f904242b    	str	x11, [x1, #0x848]
1005e1e90: f96bda6c    	ldr	x12, [x19, #0x57b0]
1005e1e94: f904282c    	str	x12, [x1, #0x850]
1005e1e98: f96bde6d    	ldr	x13, [x19, #0x57b8]
1005e1e9c: f9042c2d    	str	x13, [x1, #0x858]
1005e1ea0: f96be26e    	ldr	x14, [x19, #0x57c0]
1005e1ea4: f904302e    	str	x14, [x1, #0x860]
1005e1ea8: f96be66f    	ldr	x15, [x19, #0x57c8]
1005e1eac: f904342f    	str	x15, [x1, #0x868]
1005e1eb0: f96bea60    	ldr	x0, [x19, #0x57d0]
1005e1eb4: f9043820    	str	x0, [x1, #0x870]
1005e1eb8: f96bee60    	ldr	x0, [x19, #0x57d8]
1005e1ebc: f9043c20    	str	x0, [x1, #0x878]
1005e1ec0: f96dda60    	ldr	x0, [x19, #0x5bb0]
1005e1ec4: f9062820    	str	x0, [x1, #0xc50]
1005e1ec8: f96dde60    	ldr	x0, [x19, #0x5bb8]
1005e1ecc: f9062c20    	str	x0, [x1, #0xc58]
1005e1ed0: f96de260    	ldr	x0, [x19, #0x5bc0]
1005e1ed4: f9063020    	str	x0, [x1, #0xc60]
1005e1ed8: f96de660    	ldr	x0, [x19, #0x5bc8]
1005e1edc: f9063420    	str	x0, [x1, #0xc68]
1005e1ee0: f96dea60    	ldr	x0, [x19, #0x5bd0]
1005e1ee4: f9063820    	str	x0, [x1, #0xc70]
1005e1ee8: f96dee60    	ldr	x0, [x19, #0x5bd8]
1005e1eec: f9063c20    	str	x0, [x1, #0xc78]
1005e1ef0: d2800000    	mov	x0, #0x0                ; =0
1005e1ef4: f9064020    	str	x0, [x1, #0xc80]
1005e1ef8: f96df662    	ldr	x2, [x19, #0x5be8]
1005e1efc: f9064422    	str	x2, [x1, #0xc88]
1005e1f00: f96dfa62    	ldr	x2, [x19, #0x5bf0]
1005e1f04: f9064822    	str	x2, [x1, #0xc90]
1005e1f08: f9064c20    	str	x0, [x1, #0xc98]
1005e1f0c: f96e0262    	ldr	x2, [x19, #0x5c00]
1005e1f10: f9065022    	str	x2, [x1, #0xca0]
1005e1f14: f96e0662    	ldr	x2, [x19, #0x5c08]
1005e1f18: f9065422    	str	x2, [x1, #0xca8]
1005e1f1c: f9065820    	str	x0, [x1, #0xcb0]
1005e1f20: f96e0e60    	ldr	x0, [x19, #0x5c18]
1005e1f24: f9065c20    	str	x0, [x1, #0xcb8]
1005e1f28: f96e1260    	ldr	x0, [x19, #0x5c20]
1005e1f2c: f9066020    	str	x0, [x1, #0xcc0]
1005e1f30: d280a041    	mov	x1, #0x502              ; =1282
1005e1f34: 92800102    	mov	x2, #-0x9               ; =-9
1005e1f38: d2800025    	mov	x5, #0x1                ; =1
1005e1f3c: f84083e0    	ldur	x0, [sp, #0x8]
1005e1f40: f940cbe6    	ldr	x6, [sp, #0x190]
1005e1f44: f940cff5    	ldr	x21, [sp, #0x198]
1005e1f48: d63f02a0    	blr	x21
1005e1f4c: aa0003e8    	mov	x8, x0
1005e1f50: d2800040    	mov	x0, #0x2                ; =2
1005e1f54: f100011f    	cmp	x8, #0x0
1005e1f58: 54022701    	b.ne	0x1005e6438 <_mech_canonical_program_entry_v1_numeric_1282+0x4db8>
1005e1f5c: d2800001    	mov	x1, #0x0                ; =0
1005e1f60: aa0103e0    	mov	x0, x1
1005e1f64: 9106c3ff    	add	sp, sp, #0x1b0
1005e1f68: a8c153f3    	ldp	x19, x20, [sp], #0x10
1005e1f6c: a8c15bf5    	ldp	x21, x22, [sp], #0x10
1005e1f70: a8c163f7    	ldp	x23, x24, [sp], #0x10
1005e1f74: a8c16bf9    	ldp	x25, x26, [sp], #0x10
1005e1f78: a8c173fb    	ldp	x27, x28, [sp], #0x10
1005e1f7c: a8c17bfd    	ldp	x29, x30, [sp], #0x10
1005e1f80: d65f0fff    	retab
1005e1f84: f940c7e1    	ldr	x1, [sp, #0x188]
1005e1f88: f940c3e2    	ldr	x2, [sp, #0x180]
1005e1f8c: f84803e4    	ldur	x4, [sp, #0x80]
1005e1f90: aa1a03ea    	mov	x10, x26
1005e1f94: aa0603f3    	mov	x19, x6
1005e1f98: f80903e5    	stur	x5, [sp, #0x90]
1005e1f9c: eb1702df    	cmp	x22, x23
1005e1fa0: 9a9f27e0    	cset	x0, lo
1005e1fa4: eb1702df    	cmp	x22, x23
1005e1fa8: 54000243    	b.lo	0x1005e1ff0 <_mech_canonical_program_entry_v1_numeric_1282+0x970>
1005e1fac: d2800007    	mov	x7, #0x0                ; =0
1005e1fb0: f80103e7    	stur	x7, [sp, #0x10]
1005e1fb4: 52990fc0    	mov	w0, #0xc87e             ; =51326
1005e1fb8: 72a00020    	movk	w0, #0x1, lsl #16
1005e1fbc: cb000063    	sub	x3, x3, x0
1005e1fc0: aa1603f8    	mov	x24, x22
1005e1fc4: aa1603fb    	mov	x27, x22
1005e1fc8: f84103e0    	ldur	x0, [sp, #0x10]
1005e1fcc: f80583e0    	stur	x0, [sp, #0x58]
1005e1fd0: f80603e0    	stur	x0, [sp, #0x60]
1005e1fd4: f80683e0    	stur	x0, [sp, #0x68]
1005e1fd8: f80703e0    	stur	x0, [sp, #0x70]
1005e1fdc: f80803e4    	stur	x4, [sp, #0x80]
1005e1fe0: f80983e9    	stur	x9, [sp, #0x98]
1005e1fe4: f900c3e2    	str	x2, [sp, #0x180]
1005e1fe8: f900c7e1    	str	x1, [sp, #0x188]
1005e1fec: 14000e65    	b	0x1005e5980 <_mech_canonical_program_entry_v1_numeric_1282+0x4300>
1005e1ff0: f940bbe5    	ldr	x5, [sp, #0x170]
1005e1ff4: eb0502df    	cmp	x22, x5
1005e1ff8: 54001283    	b.lo	0x1005e2248 <_mech_canonical_program_entry_v1_numeric_1282+0xbc8>
1005e1ffc: 14001111    	b	0x1005e6440 <_mech_canonical_program_entry_v1_numeric_1282+0x4dc0>
1005e2000: f900c3e2    	str	x2, [sp, #0x180]
1005e2004: f900c7e1    	str	x1, [sp, #0x188]
1005e2008: 1400007b    	b	0x1005e21f4 <_mech_canonical_program_entry_v1_numeric_1282+0xb74>
1005e200c: f9663663    	ldr	x3, [x19, #0x4c68]
1005e2010: f9663a64    	ldr	x4, [x19, #0x4c70]
1005e2014: d2800000    	mov	x0, #0x0                ; =0
1005e2018: f9263260    	str	x0, [x19, #0x4c60]
1005e201c: d2800060    	mov	x0, #0x3                ; =3
1005e2020: f106685f    	cmp	x2, #0x19a
1005e2024: f900c3e2    	str	x2, [sp, #0x180]
1005e2028: 540229a3    	b.lo	0x1005e655c <_mech_canonical_program_entry_v1_numeric_1282+0x4edc>
1005e202c: f967ba60    	ldr	x0, [x19, #0x4f70]
1005e2030: f9000820    	str	x0, [x1, #0x10]
1005e2034: f967be62    	ldr	x2, [x19, #0x4f78]
1005e2038: f9000c22    	str	x2, [x1, #0x18]
1005e203c: f96d1265    	ldr	x5, [x19, #0x5a20]
1005e2040: f9056025    	str	x5, [x1, #0xac0]
1005e2044: f9000820    	str	x0, [x1, #0x10]
1005e2048: f9000c22    	str	x2, [x1, #0x18]
1005e204c: f9686260    	ldr	x0, [x19, #0x50c0]
1005e2050: f900b020    	str	x0, [x1, #0x160]
1005e2054: f9686660    	ldr	x0, [x19, #0x50c8]
1005e2058: f900b420    	str	x0, [x1, #0x168]
1005e205c: f9686a60    	ldr	x0, [x19, #0x50d0]
1005e2060: f900b820    	str	x0, [x1, #0x170]
1005e2064: f9686e60    	ldr	x0, [x19, #0x50d8]
1005e2068: f900bc20    	str	x0, [x1, #0x178]
1005e206c: f9687260    	ldr	x0, [x19, #0x50e0]
1005e2070: f900c020    	str	x0, [x1, #0x180]
1005e2074: f9687660    	ldr	x0, [x19, #0x50e8]
1005e2078: f900c420    	str	x0, [x1, #0x188]
1005e207c: f9687a60    	ldr	x0, [x19, #0x50f0]
1005e2080: f900c820    	str	x0, [x1, #0x190]
1005e2084: f9687e60    	ldr	x0, [x19, #0x50f8]
1005e2088: f900cc20    	str	x0, [x1, #0x198]
1005e208c: f9688260    	ldr	x0, [x19, #0x5100]
1005e2090: f900d020    	str	x0, [x1, #0x1a0]
1005e2094: f9695660    	ldr	x0, [x19, #0x52a8]
1005e2098: f901a420    	str	x0, [x1, #0x348]
1005e209c: f9695a60    	ldr	x0, [x19, #0x52b0]
1005e20a0: f901a820    	str	x0, [x1, #0x350]
1005e20a4: f9695e60    	ldr	x0, [x19, #0x52b8]
1005e20a8: f901ac20    	str	x0, [x1, #0x358]
1005e20ac: f9696260    	ldr	x0, [x19, #0x52c0]
1005e20b0: f901b020    	str	x0, [x1, #0x360]
1005e20b4: f9696660    	ldr	x0, [x19, #0x52c8]
1005e20b8: f901b420    	str	x0, [x1, #0x368]
1005e20bc: f9696a60    	ldr	x0, [x19, #0x52d0]
1005e20c0: f901b820    	str	x0, [x1, #0x370]
1005e20c4: f9696e60    	ldr	x0, [x19, #0x52d8]
1005e20c8: f901bc20    	str	x0, [x1, #0x378]
1005e20cc: f9697260    	ldr	x0, [x19, #0x52e0]
1005e20d0: f901c020    	str	x0, [x1, #0x380]
1005e20d4: f9697660    	ldr	x0, [x19, #0x52e8]
1005e20d8: f901c420    	str	x0, [x1, #0x388]
1005e20dc: f96aee62    	ldr	x2, [x19, #0x55d8]
1005e20e0: f9033c22    	str	x2, [x1, #0x678]
1005e20e4: f96af262    	ldr	x2, [x19, #0x55e0]
1005e20e8: f9034022    	str	x2, [x1, #0x680]
1005e20ec: f96af665    	ldr	x5, [x19, #0x55e8]
1005e20f0: f9034425    	str	x5, [x1, #0x688]
1005e20f4: f96afa65    	ldr	x5, [x19, #0x55f0]
1005e20f8: f9034825    	str	x5, [x1, #0x690]
1005e20fc: f96afe65    	ldr	x5, [x19, #0x55f8]
1005e2100: f9034c25    	str	x5, [x1, #0x698]
1005e2104: f96b0266    	ldr	x6, [x19, #0x5600]
1005e2108: f9035026    	str	x6, [x1, #0x6a0]
1005e210c: f96b0667    	ldr	x7, [x19, #0x5608]
1005e2110: f9035427    	str	x7, [x1, #0x6a8]
1005e2114: f96b0a68    	ldr	x8, [x19, #0x5610]
1005e2118: f9035828    	str	x8, [x1, #0x6b0]
1005e211c: f96bd269    	ldr	x9, [x19, #0x57a0]
1005e2120: f9042029    	str	x9, [x1, #0x840]
1005e2124: f96bd66a    	ldr	x10, [x19, #0x57a8]
1005e2128: f904242a    	str	x10, [x1, #0x848]
1005e212c: f96bda6b    	ldr	x11, [x19, #0x57b0]
1005e2130: f904282b    	str	x11, [x1, #0x850]
1005e2134: f96bde6c    	ldr	x12, [x19, #0x57b8]
1005e2138: f9042c2c    	str	x12, [x1, #0x858]
1005e213c: f96be26d    	ldr	x13, [x19, #0x57c0]
1005e2140: f904302d    	str	x13, [x1, #0x860]
1005e2144: f96be66e    	ldr	x14, [x19, #0x57c8]
1005e2148: f904342e    	str	x14, [x1, #0x868]
1005e214c: f96bea6f    	ldr	x15, [x19, #0x57d0]
1005e2150: f904382f    	str	x15, [x1, #0x870]
1005e2154: f96bee60    	ldr	x0, [x19, #0x57d8]
1005e2158: f9043c20    	str	x0, [x1, #0x878]
1005e215c: f96dda60    	ldr	x0, [x19, #0x5bb0]
1005e2160: f9062820    	str	x0, [x1, #0xc50]
1005e2164: f96dde60    	ldr	x0, [x19, #0x5bb8]
1005e2168: f9062c20    	str	x0, [x1, #0xc58]
1005e216c: f96de260    	ldr	x0, [x19, #0x5bc0]
1005e2170: f9063020    	str	x0, [x1, #0xc60]
1005e2174: f96de660    	ldr	x0, [x19, #0x5bc8]
1005e2178: f9063420    	str	x0, [x1, #0xc68]
1005e217c: f96dea60    	ldr	x0, [x19, #0x5bd0]
1005e2180: f9063820    	str	x0, [x1, #0xc70]
1005e2184: f96dee60    	ldr	x0, [x19, #0x5bd8]
1005e2188: f9063c20    	str	x0, [x1, #0xc78]
1005e218c: d2800000    	mov	x0, #0x0                ; =0
1005e2190: f9064020    	str	x0, [x1, #0xc80]
1005e2194: f96df662    	ldr	x2, [x19, #0x5be8]
1005e2198: f9064422    	str	x2, [x1, #0xc88]
1005e219c: f96dfa62    	ldr	x2, [x19, #0x5bf0]
1005e21a0: f9064822    	str	x2, [x1, #0xc90]
1005e21a4: f9064c20    	str	x0, [x1, #0xc98]
1005e21a8: f96e0262    	ldr	x2, [x19, #0x5c00]
1005e21ac: f9065022    	str	x2, [x1, #0xca0]
1005e21b0: f96e0662    	ldr	x2, [x19, #0x5c08]
1005e21b4: f9065422    	str	x2, [x1, #0xca8]
1005e21b8: f9065820    	str	x0, [x1, #0xcb0]
1005e21bc: f96e0e60    	ldr	x0, [x19, #0x5c18]
1005e21c0: f9065c20    	str	x0, [x1, #0xcb8]
1005e21c4: f96e1260    	ldr	x0, [x19, #0x5c20]
1005e21c8: f9066020    	str	x0, [x1, #0xcc0]
1005e21cc: f900c7e1    	str	x1, [sp, #0x188]
1005e21d0: d280a241    	mov	x1, #0x512              ; =1298
1005e21d4: 92800102    	mov	x2, #-0x9               ; =-9
1005e21d8: f940cff5    	ldr	x21, [sp, #0x198]
1005e21dc: f84083e0    	ldur	x0, [sp, #0x8]
1005e21e0: aa1403e5    	mov	x5, x20
1005e21e4: f940cbe6    	ldr	x6, [sp, #0x190]
1005e21e8: d63f02a0    	blr	x21
1005e21ec: f100001f    	cmp	x0, #0x0
1005e21f0: 54021ba1    	b.ne	0x1005e6564 <_mech_canonical_program_entry_v1_numeric_1282+0x4ee4>
1005e21f4: d2800060    	mov	x0, #0x3                ; =3
1005e21f8: f940c3ef    	ldr	x15, [sp, #0x180]
1005e21fc: f10009ff    	cmp	x15, #0x2
1005e2200: 54021b63    	b.lo	0x1005e656c <_mech_canonical_program_entry_v1_numeric_1282+0x4eec>
1005e2204: d2800005    	mov	x5, #0x0                ; =0
1005e2208: f940c7e3    	ldr	x3, [sp, #0x188]
1005e220c: f9000065    	str	x5, [x3]
1005e2210: f94bea60    	ldr	x0, [x19, #0x17d0]
1005e2214: f9000460    	str	x0, [x3, #0x8]
1005e2218: d280a241    	mov	x1, #0x512              ; =1298
1005e221c: f84083e0    	ldur	x0, [sp, #0x8]
1005e2220: f940cbe6    	ldr	x6, [sp, #0x190]
1005e2224: f940cff5    	ldr	x21, [sp, #0x198]
1005e2228: aa1403e4    	mov	x4, x20
1005e222c: aa0503e2    	mov	x2, x5
1005e2230: d63f02a0    	blr	x21
1005e2234: f100001f    	cmp	x0, #0x0
1005e2238: 540219e1    	b.ne	0x1005e6574 <_mech_canonical_program_entry_v1_numeric_1282+0x4ef4>
1005e223c: d2800060    	mov	x0, #0x3                ; =3
1005e2240: f80b83e0    	stur	x0, [sp, #0xb8]
1005e2244: 140018cd    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e2248: f900c7e1    	str	x1, [sp, #0x188]
1005e224c: f900c3e2    	str	x2, [sp, #0x180]
1005e2250: f80983e9    	stur	x9, [sp, #0x98]
1005e2254: f940bfe2    	ldr	x2, [sp, #0x178]
1005e2258: f8767841    	ldr	x1, [x2, x22, lsl #3]
1005e225c: 910006d8    	add	x24, x22, #0x1
1005e2260: f940bbe2    	ldr	x2, [sp, #0x170]
1005e2264: eb02031f    	cmp	x24, x2
1005e2268: f80d83f8    	stur	x24, [sp, #0xd8]
1005e226c: 540013c3    	b.lo	0x1005e24e4 <_mech_canonical_program_entry_v1_numeric_1282+0xe64>
1005e2270: 140010c3    	b	0x1005e657c <_mech_canonical_program_entry_v1_numeric_1282+0x4efc>
1005e2274: f9663663    	ldr	x3, [x19, #0x4c68]
1005e2278: f9663a64    	ldr	x4, [x19, #0x4c70]
1005e227c: d2800000    	mov	x0, #0x0                ; =0
1005e2280: f9263260    	str	x0, [x19, #0x4c60]
1005e2284: d2800060    	mov	x0, #0x3                ; =3
1005e2288: f940c3ef    	ldr	x15, [sp, #0x180]
1005e228c: f10669ff    	cmp	x15, #0x19a
1005e2290: 54022083    	b.lo	0x1005e66a0 <_mech_canonical_program_entry_v1_numeric_1282+0x5020>
1005e2294: f967ba60    	ldr	x0, [x19, #0x4f70]
1005e2298: f940c7e1    	ldr	x1, [sp, #0x188]
1005e229c: f9000820    	str	x0, [x1, #0x10]
1005e22a0: f967be61    	ldr	x1, [x19, #0x4f78]
1005e22a4: f940c7e2    	ldr	x2, [sp, #0x188]
1005e22a8: f9000c41    	str	x1, [x2, #0x18]
1005e22ac: f96d1262    	ldr	x2, [x19, #0x5a20]
1005e22b0: f940c7e5    	ldr	x5, [sp, #0x188]
1005e22b4: f90560a2    	str	x2, [x5, #0xac0]
1005e22b8: f940c7e2    	ldr	x2, [sp, #0x188]
1005e22bc: f9000840    	str	x0, [x2, #0x10]
1005e22c0: f940c7e0    	ldr	x0, [sp, #0x188]
1005e22c4: f9000c01    	str	x1, [x0, #0x18]
1005e22c8: f9686260    	ldr	x0, [x19, #0x50c0]
1005e22cc: f940c7e1    	ldr	x1, [sp, #0x188]
1005e22d0: f900b020    	str	x0, [x1, #0x160]
1005e22d4: f9686660    	ldr	x0, [x19, #0x50c8]
1005e22d8: f900b420    	str	x0, [x1, #0x168]
1005e22dc: f9686a60    	ldr	x0, [x19, #0x50d0]
1005e22e0: f900b820    	str	x0, [x1, #0x170]
1005e22e4: f9686e60    	ldr	x0, [x19, #0x50d8]
1005e22e8: f900bc20    	str	x0, [x1, #0x178]
1005e22ec: f9687260    	ldr	x0, [x19, #0x50e0]
1005e22f0: f900c020    	str	x0, [x1, #0x180]
1005e22f4: f9687660    	ldr	x0, [x19, #0x50e8]
1005e22f8: f900c420    	str	x0, [x1, #0x188]
1005e22fc: f9687a60    	ldr	x0, [x19, #0x50f0]
1005e2300: f900c820    	str	x0, [x1, #0x190]
1005e2304: f9687e60    	ldr	x0, [x19, #0x50f8]
1005e2308: f900cc20    	str	x0, [x1, #0x198]
1005e230c: f9688260    	ldr	x0, [x19, #0x5100]
1005e2310: f900d0a0    	str	x0, [x5, #0x1a0]
1005e2314: f9695660    	ldr	x0, [x19, #0x52a8]
1005e2318: f940c7e7    	ldr	x7, [sp, #0x188]
1005e231c: f901a4e0    	str	x0, [x7, #0x348]
1005e2320: f9695a60    	ldr	x0, [x19, #0x52b0]
1005e2324: f940c7ea    	ldr	x10, [sp, #0x188]
1005e2328: f901a940    	str	x0, [x10, #0x350]
1005e232c: f9695e60    	ldr	x0, [x19, #0x52b8]
1005e2330: f940c7ed    	ldr	x13, [sp, #0x188]
1005e2334: f901ada0    	str	x0, [x13, #0x358]
1005e2338: f9696260    	ldr	x0, [x19, #0x52c0]
1005e233c: f901b020    	str	x0, [x1, #0x360]
1005e2340: f9696660    	ldr	x0, [x19, #0x52c8]
1005e2344: f901b420    	str	x0, [x1, #0x368]
1005e2348: f9696a60    	ldr	x0, [x19, #0x52d0]
1005e234c: f901b820    	str	x0, [x1, #0x370]
1005e2350: f9696e60    	ldr	x0, [x19, #0x52d8]
1005e2354: f901bc20    	str	x0, [x1, #0x378]
1005e2358: f9697260    	ldr	x0, [x19, #0x52e0]
1005e235c: f901c020    	str	x0, [x1, #0x380]
1005e2360: f9697660    	ldr	x0, [x19, #0x52e8]
1005e2364: f901c420    	str	x0, [x1, #0x388]
1005e2368: f96aee60    	ldr	x0, [x19, #0x55d8]
1005e236c: f9033c20    	str	x0, [x1, #0x678]
1005e2370: f96af260    	ldr	x0, [x19, #0x55e0]
1005e2374: f9034020    	str	x0, [x1, #0x680]
1005e2378: f96af660    	ldr	x0, [x19, #0x55e8]
1005e237c: f9034420    	str	x0, [x1, #0x688]
1005e2380: f96afa60    	ldr	x0, [x19, #0x55f0]
1005e2384: f9034820    	str	x0, [x1, #0x690]
1005e2388: f96afe60    	ldr	x0, [x19, #0x55f8]
1005e238c: f9034c20    	str	x0, [x1, #0x698]
1005e2390: f96b0260    	ldr	x0, [x19, #0x5600]
1005e2394: f9035020    	str	x0, [x1, #0x6a0]
1005e2398: f96b0660    	ldr	x0, [x19, #0x5608]
1005e239c: f9035420    	str	x0, [x1, #0x6a8]
1005e23a0: f96b0a60    	ldr	x0, [x19, #0x5610]
1005e23a4: f9035820    	str	x0, [x1, #0x6b0]
1005e23a8: f96bd261    	ldr	x1, [x19, #0x57a0]
1005e23ac: f940c7e0    	ldr	x0, [sp, #0x188]
1005e23b0: f9042001    	str	x1, [x0, #0x840]
1005e23b4: f96bd662    	ldr	x2, [x19, #0x57a8]
1005e23b8: f9042402    	str	x2, [x0, #0x848]
1005e23bc: f96bda65    	ldr	x5, [x19, #0x57b0]
1005e23c0: f940c7e1    	ldr	x1, [sp, #0x188]
1005e23c4: f9042825    	str	x5, [x1, #0x850]
1005e23c8: f96bde65    	ldr	x5, [x19, #0x57b8]
1005e23cc: f940c7e6    	ldr	x6, [sp, #0x188]
1005e23d0: f9042cc5    	str	x5, [x6, #0x858]
1005e23d4: f96be265    	ldr	x5, [x19, #0x57c0]
1005e23d8: f90430e5    	str	x5, [x7, #0x860]
1005e23dc: f96be666    	ldr	x6, [x19, #0x57c8]
1005e23e0: f9043546    	str	x6, [x10, #0x868]
1005e23e4: f96bea67    	ldr	x7, [x19, #0x57d0]
1005e23e8: f90439a7    	str	x7, [x13, #0x870]
1005e23ec: f96bee68    	ldr	x8, [x19, #0x57d8]
1005e23f0: f9043c08    	str	x8, [x0, #0x878]
1005e23f4: f96dda69    	ldr	x9, [x19, #0x5bb0]
1005e23f8: f9062809    	str	x9, [x0, #0xc50]
1005e23fc: f96dde6a    	ldr	x10, [x19, #0x5bb8]
1005e2400: f9062c0a    	str	x10, [x0, #0xc58]
1005e2404: f96de26b    	ldr	x11, [x19, #0x5bc0]
1005e2408: f906300b    	str	x11, [x0, #0xc60]
1005e240c: f96de66c    	ldr	x12, [x19, #0x5bc8]
1005e2410: f906340c    	str	x12, [x0, #0xc68]
1005e2414: f96dea6d    	ldr	x13, [x19, #0x5bd0]
1005e2418: f906380d    	str	x13, [x0, #0xc70]
1005e241c: f96dee6e    	ldr	x14, [x19, #0x5bd8]
1005e2420: f9063c0e    	str	x14, [x0, #0xc78]
1005e2424: d280000f    	mov	x15, #0x0               ; =0
1005e2428: f906400f    	str	x15, [x0, #0xc80]
1005e242c: f96df660    	ldr	x0, [x19, #0x5be8]
1005e2430: f9064420    	str	x0, [x1, #0xc88]
1005e2434: f96dfa60    	ldr	x0, [x19, #0x5bf0]
1005e2438: f9064820    	str	x0, [x1, #0xc90]
1005e243c: f940c7e0    	ldr	x0, [sp, #0x188]
1005e2440: f9064c0f    	str	x15, [x0, #0xc98]
1005e2444: f96e0260    	ldr	x0, [x19, #0x5c00]
1005e2448: f9065020    	str	x0, [x1, #0xca0]
1005e244c: f96e0660    	ldr	x0, [x19, #0x5c08]
1005e2450: f9065420    	str	x0, [x1, #0xca8]
1005e2454: f940c7e0    	ldr	x0, [sp, #0x188]
1005e2458: f906580f    	str	x15, [x0, #0xcb0]
1005e245c: f96e0e60    	ldr	x0, [x19, #0x5c18]
1005e2460: f9065c20    	str	x0, [x1, #0xcb8]
1005e2464: f96e1260    	ldr	x0, [x19, #0x5c20]
1005e2468: f9066020    	str	x0, [x1, #0xcc0]
1005e246c: d280a281    	mov	x1, #0x514              ; =1300
1005e2470: 92800102    	mov	x2, #-0x9               ; =-9
1005e2474: f940cff5    	ldr	x21, [sp, #0x198]
1005e2478: f84083e0    	ldur	x0, [sp, #0x8]
1005e247c: aa1403e5    	mov	x5, x20
1005e2480: f940cbe6    	ldr	x6, [sp, #0x190]
1005e2484: d63f02a0    	blr	x21
1005e2488: f100001f    	cmp	x0, #0x0
1005e248c: 540210e1    	b.ne	0x1005e66a8 <_mech_canonical_program_entry_v1_numeric_1282+0x5028>
1005e2490: d2800060    	mov	x0, #0x3                ; =3
1005e2494: f940c3ef    	ldr	x15, [sp, #0x180]
1005e2498: f10009ff    	cmp	x15, #0x2
1005e249c: 540210a3    	b.lo	0x1005e66b0 <_mech_canonical_program_entry_v1_numeric_1282+0x5030>
1005e24a0: d2800005    	mov	x5, #0x0                ; =0
1005e24a4: f940c7e3    	ldr	x3, [sp, #0x188]
1005e24a8: f9000065    	str	x5, [x3]
1005e24ac: f94bf260    	ldr	x0, [x19, #0x17e0]
1005e24b0: f9000460    	str	x0, [x3, #0x8]
1005e24b4: d280a281    	mov	x1, #0x514              ; =1300
1005e24b8: f84083e0    	ldur	x0, [sp, #0x8]
1005e24bc: f940cbe6    	ldr	x6, [sp, #0x190]
1005e24c0: f940cff5    	ldr	x21, [sp, #0x198]
1005e24c4: aa1403e4    	mov	x4, x20
1005e24c8: aa0503e2    	mov	x2, x5
1005e24cc: d63f02a0    	blr	x21
1005e24d0: f100001f    	cmp	x0, #0x0
1005e24d4: 54020f21    	b.ne	0x1005e66b8 <_mech_canonical_program_entry_v1_numeric_1282+0x5038>
1005e24d8: d2800060    	mov	x0, #0x3                ; =3
1005e24dc: f80b83e0    	stur	x0, [sp, #0xb8]
1005e24e0: 14001826    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e24e4: f940bfe2    	ldr	x2, [sp, #0x178]
1005e24e8: f84d83f8    	ldur	x24, [sp, #0xd8]
1005e24ec: f8787842    	ldr	x2, [x2, x24, lsl #3]
1005e24f0: f940b3e5    	ldr	x5, [sp, #0x160]
1005e24f4: eb0502df    	cmp	x22, x5
1005e24f8: 54001383    	b.lo	0x1005e2768 <_mech_canonical_program_entry_v1_numeric_1282+0x10e8>
1005e24fc: 14001071    	b	0x1005e66c0 <_mech_canonical_program_entry_v1_numeric_1282+0x5040>
1005e2500: f9663663    	ldr	x3, [x19, #0x4c68]
1005e2504: f9663a64    	ldr	x4, [x19, #0x4c70]
1005e2508: d2800000    	mov	x0, #0x0                ; =0
1005e250c: f9263260    	str	x0, [x19, #0x4c60]
1005e2510: d2800060    	mov	x0, #0x3                ; =3
1005e2514: f940c3ef    	ldr	x15, [sp, #0x180]
1005e2518: f10669ff    	cmp	x15, #0x19a
1005e251c: 54021663    	b.lo	0x1005e67e8 <_mech_canonical_program_entry_v1_numeric_1282+0x5168>
1005e2520: f967ba60    	ldr	x0, [x19, #0x4f70]
1005e2524: f940c7e1    	ldr	x1, [sp, #0x188]
1005e2528: f9000820    	str	x0, [x1, #0x10]
1005e252c: f967be61    	ldr	x1, [x19, #0x4f78]
1005e2530: f940c7e2    	ldr	x2, [sp, #0x188]
1005e2534: f9000c41    	str	x1, [x2, #0x18]
1005e2538: f96d1262    	ldr	x2, [x19, #0x5a20]
1005e253c: f940c7e5    	ldr	x5, [sp, #0x188]
1005e2540: f90560a2    	str	x2, [x5, #0xac0]
1005e2544: f940c7e2    	ldr	x2, [sp, #0x188]
1005e2548: f9000840    	str	x0, [x2, #0x10]
1005e254c: f940c7e0    	ldr	x0, [sp, #0x188]
1005e2550: f9000c01    	str	x1, [x0, #0x18]
1005e2554: f9686260    	ldr	x0, [x19, #0x50c0]
1005e2558: f940c7e1    	ldr	x1, [sp, #0x188]
1005e255c: f900b020    	str	x0, [x1, #0x160]
1005e2560: f9686660    	ldr	x0, [x19, #0x50c8]
1005e2564: f900b420    	str	x0, [x1, #0x168]
1005e2568: f9686a60    	ldr	x0, [x19, #0x50d0]
1005e256c: f900b820    	str	x0, [x1, #0x170]
1005e2570: f9686e60    	ldr	x0, [x19, #0x50d8]
1005e2574: f900bc20    	str	x0, [x1, #0x178]
1005e2578: f9687260    	ldr	x0, [x19, #0x50e0]
1005e257c: f900c040    	str	x0, [x2, #0x180]
1005e2580: f9687660    	ldr	x0, [x19, #0x50e8]
1005e2584: f900c4a0    	str	x0, [x5, #0x188]
1005e2588: f9687a60    	ldr	x0, [x19, #0x50f0]
1005e258c: f940c7e8    	ldr	x8, [sp, #0x188]
1005e2590: f900c900    	str	x0, [x8, #0x190]
1005e2594: f9687e60    	ldr	x0, [x19, #0x50f8]
1005e2598: f940c7eb    	ldr	x11, [sp, #0x188]
1005e259c: f900cd60    	str	x0, [x11, #0x198]
1005e25a0: f9688260    	ldr	x0, [x19, #0x5100]
1005e25a4: f940c7ee    	ldr	x14, [sp, #0x188]
1005e25a8: f900d1c0    	str	x0, [x14, #0x1a0]
1005e25ac: f9695660    	ldr	x0, [x19, #0x52a8]
1005e25b0: f901a420    	str	x0, [x1, #0x348]
1005e25b4: f9695a60    	ldr	x0, [x19, #0x52b0]
1005e25b8: f901a820    	str	x0, [x1, #0x350]
1005e25bc: f9695e60    	ldr	x0, [x19, #0x52b8]
1005e25c0: f901ac20    	str	x0, [x1, #0x358]
1005e25c4: f9696260    	ldr	x0, [x19, #0x52c0]
1005e25c8: f901b020    	str	x0, [x1, #0x360]
1005e25cc: f9696660    	ldr	x0, [x19, #0x52c8]
1005e25d0: f901b420    	str	x0, [x1, #0x368]
1005e25d4: f9696a60    	ldr	x0, [x19, #0x52d0]
1005e25d8: f901b820    	str	x0, [x1, #0x370]
1005e25dc: f9696e60    	ldr	x0, [x19, #0x52d8]
1005e25e0: f901bc20    	str	x0, [x1, #0x378]
1005e25e4: f9697260    	ldr	x0, [x19, #0x52e0]
1005e25e8: f901c020    	str	x0, [x1, #0x380]
1005e25ec: f9697660    	ldr	x0, [x19, #0x52e8]
1005e25f0: f901c420    	str	x0, [x1, #0x388]
1005e25f4: f96aee60    	ldr	x0, [x19, #0x55d8]
1005e25f8: f9033c20    	str	x0, [x1, #0x678]
1005e25fc: f96af260    	ldr	x0, [x19, #0x55e0]
1005e2600: f9034020    	str	x0, [x1, #0x680]
1005e2604: f96af660    	ldr	x0, [x19, #0x55e8]
1005e2608: f9034420    	str	x0, [x1, #0x688]
1005e260c: f96afa60    	ldr	x0, [x19, #0x55f0]
1005e2610: f9034820    	str	x0, [x1, #0x690]
1005e2614: f96afe60    	ldr	x0, [x19, #0x55f8]
1005e2618: f9034c20    	str	x0, [x1, #0x698]
1005e261c: f96b0260    	ldr	x0, [x19, #0x5600]
1005e2620: f9035020    	str	x0, [x1, #0x6a0]
1005e2624: f96b0660    	ldr	x0, [x19, #0x5608]
1005e2628: f9035420    	str	x0, [x1, #0x6a8]
1005e262c: f96b0a60    	ldr	x0, [x19, #0x5610]
1005e2630: f9035840    	str	x0, [x2, #0x6b0]
1005e2634: f96bd260    	ldr	x0, [x19, #0x57a0]
1005e2638: f90420a0    	str	x0, [x5, #0x840]
1005e263c: f96bd660    	ldr	x0, [x19, #0x57a8]
1005e2640: f9042500    	str	x0, [x8, #0x848]
1005e2644: f96bda60    	ldr	x0, [x19, #0x57b0]
1005e2648: f9042960    	str	x0, [x11, #0x850]
1005e264c: f96bde60    	ldr	x0, [x19, #0x57b8]
1005e2650: f9042dc0    	str	x0, [x14, #0x858]
1005e2654: f96be260    	ldr	x0, [x19, #0x57c0]
1005e2658: f9043020    	str	x0, [x1, #0x860]
1005e265c: f96be660    	ldr	x0, [x19, #0x57c8]
1005e2660: f9043420    	str	x0, [x1, #0x868]
1005e2664: f96bea60    	ldr	x0, [x19, #0x57d0]
1005e2668: f9043820    	str	x0, [x1, #0x870]
1005e266c: f96bee61    	ldr	x1, [x19, #0x57d8]
1005e2670: f940c7e0    	ldr	x0, [sp, #0x188]
1005e2674: f9043c01    	str	x1, [x0, #0x878]
1005e2678: f96dda62    	ldr	x2, [x19, #0x5bb0]
1005e267c: f9062802    	str	x2, [x0, #0xc50]
1005e2680: f96dde65    	ldr	x5, [x19, #0x5bb8]
1005e2684: f9062c05    	str	x5, [x0, #0xc58]
1005e2688: f96de265    	ldr	x5, [x19, #0x5bc0]
1005e268c: f9063005    	str	x5, [x0, #0xc60]
1005e2690: f96de665    	ldr	x5, [x19, #0x5bc8]
1005e2694: f9063405    	str	x5, [x0, #0xc68]
1005e2698: f96dea66    	ldr	x6, [x19, #0x5bd0]
1005e269c: f9063806    	str	x6, [x0, #0xc70]
1005e26a0: f96dee67    	ldr	x7, [x19, #0x5bd8]
1005e26a4: f9063c07    	str	x7, [x0, #0xc78]
1005e26a8: d2800008    	mov	x8, #0x0                ; =0
1005e26ac: f9064008    	str	x8, [x0, #0xc80]
1005e26b0: f96df669    	ldr	x9, [x19, #0x5be8]
1005e26b4: f9064409    	str	x9, [x0, #0xc88]
1005e26b8: f96dfa6a    	ldr	x10, [x19, #0x5bf0]
1005e26bc: f906480a    	str	x10, [x0, #0xc90]
1005e26c0: f9064c08    	str	x8, [x0, #0xc98]
1005e26c4: f96e026c    	ldr	x12, [x19, #0x5c00]
1005e26c8: f906500c    	str	x12, [x0, #0xca0]
1005e26cc: f96e066d    	ldr	x13, [x19, #0x5c08]
1005e26d0: f906540d    	str	x13, [x0, #0xca8]
1005e26d4: f9065808    	str	x8, [x0, #0xcb0]
1005e26d8: f96e0e6f    	ldr	x15, [x19, #0x5c18]
1005e26dc: f940c7e5    	ldr	x5, [sp, #0x188]
1005e26e0: f9065caf    	str	x15, [x5, #0xcb8]
1005e26e4: f96e1260    	ldr	x0, [x19, #0x5c20]
1005e26e8: f940c7e6    	ldr	x6, [sp, #0x188]
1005e26ec: f90660c0    	str	x0, [x6, #0xcc0]
1005e26f0: d280a2c1    	mov	x1, #0x516              ; =1302
1005e26f4: 92800102    	mov	x2, #-0x9               ; =-9
1005e26f8: f940cff5    	ldr	x21, [sp, #0x198]
1005e26fc: f84083e0    	ldur	x0, [sp, #0x8]
1005e2700: aa1403e5    	mov	x5, x20
1005e2704: f940cbe6    	ldr	x6, [sp, #0x190]
1005e2708: d63f02a0    	blr	x21
1005e270c: f100001f    	cmp	x0, #0x0
1005e2710: 54020701    	b.ne	0x1005e67f0 <_mech_canonical_program_entry_v1_numeric_1282+0x5170>
1005e2714: d2800060    	mov	x0, #0x3                ; =3
1005e2718: f940c3ef    	ldr	x15, [sp, #0x180]
1005e271c: f10009ff    	cmp	x15, #0x2
1005e2720: 540206c3    	b.lo	0x1005e67f8 <_mech_canonical_program_entry_v1_numeric_1282+0x5178>
1005e2724: d2800005    	mov	x5, #0x0                ; =0
1005e2728: f940c7e3    	ldr	x3, [sp, #0x188]
1005e272c: f9000065    	str	x5, [x3]
1005e2730: f94bfa60    	ldr	x0, [x19, #0x17f0]
1005e2734: f9000460    	str	x0, [x3, #0x8]
1005e2738: d280a2c1    	mov	x1, #0x516              ; =1302
1005e273c: f84083e0    	ldur	x0, [sp, #0x8]
1005e2740: f940cbe6    	ldr	x6, [sp, #0x190]
1005e2744: f940cff5    	ldr	x21, [sp, #0x198]
1005e2748: aa1403e4    	mov	x4, x20
1005e274c: aa0503e2    	mov	x2, x5
1005e2750: d63f02a0    	blr	x21
1005e2754: f100001f    	cmp	x0, #0x0
1005e2758: 54020541    	b.ne	0x1005e6800 <_mech_canonical_program_entry_v1_numeric_1282+0x5180>
1005e275c: d2800060    	mov	x0, #0x3                ; =3
1005e2760: f80b83e0    	stur	x0, [sp, #0xb8]
1005e2764: 14001785    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e2768: f80e03e0    	stur	x0, [sp, #0xe0]
1005e276c: f80803e4    	stur	x4, [sp, #0x80]
1005e2770: f80183e1    	stur	x1, [sp, #0x18]
1005e2774: aa0203fa    	mov	x26, x2
1005e2778: f940b7e0    	ldr	x0, [sp, #0x168]
1005e277c: f876780f    	ldr	x15, [x0, x22, lsl #3]
1005e2780: f80d03ef    	stur	x15, [sp, #0xd0]
1005e2784: 52990fc0    	mov	w0, #0xc87e             ; =51326
1005e2788: 72a00020    	movk	w0, #0x1, lsl #16
1005e278c: cb000063    	sub	x3, x3, x0
1005e2790: d2800007    	mov	x7, #0x0                ; =0
1005e2794: f80103e7    	stur	x7, [sp, #0x10]
1005e2798: f84103e2    	ldur	x2, [sp, #0x10]
1005e279c: f84103f9    	ldur	x25, [sp, #0x10]
1005e27a0: f84103fb    	ldur	x27, [sp, #0x10]
1005e27a4: f84103e0    	ldur	x0, [sp, #0x10]
1005e27a8: f80203e0    	stur	x0, [sp, #0x20]
1005e27ac: f80703e0    	stur	x0, [sp, #0x70]
1005e27b0: 52842cc0    	mov	w0, #0x2166             ; =8550
1005e27b4: 72a00020    	movk	w0, #0x1, lsl #16
1005e27b8: eb00007f    	cmp	x3, x0
1005e27bc: 54001d02    	b.hs	0x1005e2b5c <_mech_canonical_program_entry_v1_numeric_1282+0x14dc>
1005e27c0: d2800001    	mov	x1, #0x0                ; =0
1005e27c4: f9000e61    	str	x1, [x19, #0x18]
1005e27c8: d2e20000    	mov	x0, #0x1000000000000000 ; =1152921504606846976
1005e27cc: f9001260    	str	x0, [x19, #0x20]
1005e27d0: d2800020    	mov	x0, #0x1                ; =1
1005e27d4: f9001a60    	str	x0, [x19, #0x30]
1005e27d8: b200c3e4    	mov	x4, #0x101010101010101  ; =72340172838076673
1005e27dc: f9001e64    	str	x4, [x19, #0x38]
1005e27e0: d2800044    	mov	x4, #0x2                ; =2
1005e27e4: f9002264    	str	x4, [x19, #0x40]
1005e27e8: aa0403f4    	mov	x20, x4
1005e27ec: d2800064    	mov	x4, #0x3                ; =3
1005e27f0: f9002664    	str	x4, [x19, #0x48]
1005e27f4: d2800084    	mov	x4, #0x4                ; =4
1005e27f8: f9002a64    	str	x4, [x19, #0x50]
1005e27fc: b200cfe4    	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e2800: f9003e64    	str	x4, [x19, #0x78]
1005e2804: b200e7e4    	mov	x4, #0x3333333333333333 ; =3689348814741910323
1005e2808: f9004664    	str	x4, [x19, #0x88]
1005e280c: d2800704    	mov	x4, #0x38               ; =56
1005e2810: f9004a64    	str	x4, [x19, #0x90]
1005e2814: d2800744    	mov	x4, #0x3a               ; =58
1005e2818: f9004e64    	str	x4, [x19, #0x98]
1005e281c: b200f3e4    	mov	x4, #0x5555555555555555 ; =6148914691236517205
1005e2820: f9005a64    	str	x4, [x19, #0xb0]
1005e2824: 92ff8004    	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
1005e2828: f9005e64    	str	x4, [x19, #0xb8]
1005e282c: f900c661    	str	x1, [x19, #0x188]
1005e2830: f900ca60    	str	x0, [x19, #0x190]
1005e2834: f90bd276    	str	x22, [x19, #0x17a0]
1005e2838: f90bd677    	str	x23, [x19, #0x17a8]
1005e283c: f84e03f8    	ldur	x24, [sp, #0xe0]
1005e2840: 53001f01    	uxtb	w1, w24
1005e2844: f90bde61    	str	x1, [x19, #0x17b8]
1005e2848: f926326a    	str	x10, [x19, #0x4c60]
1005e284c: f9263663    	str	x3, [x19, #0x4c68]
1005e2850: f84803e4    	ldur	x4, [sp, #0x80]
1005e2854: f9263a64    	str	x4, [x19, #0x4c70]
1005e2858: f927ba76    	str	x22, [x19, #0x4f70]
1005e285c: f927be77    	str	x23, [x19, #0x4f78]
1005e2860: f84183e1    	ldur	x1, [sp, #0x18]
1005e2864: f9286261    	str	x1, [x19, #0x50c0]
1005e2868: aa1a03ef    	mov	x15, x26
1005e286c: f928666f    	str	x15, [x19, #0x50c8]
1005e2870: f9286a76    	str	x22, [x19, #0x50d0]
1005e2874: f84d03fa    	ldur	x26, [sp, #0xd0]
1005e2878: f9286e7a    	str	x26, [x19, #0x50d8]
1005e287c: f84103e1    	ldur	x1, [sp, #0x10]
1005e2880: f9287261    	str	x1, [x19, #0x50e0]
1005e2884: f928767b    	str	x27, [x19, #0x50e8]
1005e2888: f9287a79    	str	x25, [x19, #0x50f0]
1005e288c: f9287e62    	str	x2, [x19, #0x50f8]
1005e2890: f84703fa    	ldur	x26, [sp, #0x70]
1005e2894: f928827a    	str	x26, [x19, #0x5100]
1005e2898: f84503e1    	ldur	x1, [sp, #0x50]
1005e289c: f92d1261    	str	x1, [x19, #0x5a20]
1005e28a0: 9100050e    	add	x14, x8, #0x1
1005e28a4: f92dda6e    	str	x14, [x19, #0x5bb0]
1005e28a8: f84883fa    	ldur	x26, [sp, #0x88]
1005e28ac: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e28b0: f84903e6    	ldur	x6, [sp, #0x90]
1005e28b4: f92de266    	str	x6, [x19, #0x5bc0]
1005e28b8: f84783e4    	ldur	x4, [sp, #0x78]
1005e28bc: cb03008f    	sub	x15, x4, x3
1005e28c0: 52990fc1    	mov	w1, #0xc87e             ; =51326
1005e28c4: 72a00021    	movk	w1, #0x1, lsl #16
1005e28c8: 9b01bdce    	msub	x14, x14, x1, x15
1005e28cc: f92de66e    	str	x14, [x19, #0x5bc8]
1005e28d0: f92dea60    	str	x0, [x19, #0x5bd0]
1005e28d4: f84203f5    	ldur	x21, [sp, #0x20]
1005e28d8: f92dee75    	str	x21, [x19, #0x5bd8]
1005e28dc: f84983ea    	ldur	x10, [sp, #0x98]
1005e28e0: f92df66a    	str	x10, [x19, #0x5be8]
1005e28e4: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e28e8: f92dfa64    	str	x4, [x19, #0x5bf0]
1005e28ec: f92e026c    	str	x12, [x19, #0x5c00]
1005e28f0: f92e066b    	str	x11, [x19, #0x5c08]
1005e28f4: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e28f8: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e28fc: f92e126d    	str	x13, [x19, #0x5c20]
1005e2900: f9663260    	ldr	x0, [x19, #0x4c60]
1005e2904: f100001f    	cmp	x0, #0x0
1005e2908: 54001160    	b.eq	0x1005e2b34 <_mech_canonical_program_entry_v1_numeric_1282+0x14b4>
1005e290c: f9663663    	ldr	x3, [x19, #0x4c68]
1005e2910: f9663a64    	ldr	x4, [x19, #0x4c70]
1005e2914: d2800000    	mov	x0, #0x0                ; =0
1005e2918: f9263260    	str	x0, [x19, #0x4c60]
1005e291c: d2800060    	mov	x0, #0x3                ; =3
1005e2920: f940c3ef    	ldr	x15, [sp, #0x180]
1005e2924: f80b83e0    	stur	x0, [sp, #0xb8]
1005e2928: f10669ff    	cmp	x15, #0x19a
1005e292c: 5402e263    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e2930: f967ba60    	ldr	x0, [x19, #0x4f70]
1005e2934: f940c7e2    	ldr	x2, [sp, #0x188]
1005e2938: f9000840    	str	x0, [x2, #0x10]
1005e293c: f967be61    	ldr	x1, [x19, #0x4f78]
1005e2940: f940c7e5    	ldr	x5, [sp, #0x188]
1005e2944: f9000ca1    	str	x1, [x5, #0x18]
1005e2948: f96d1262    	ldr	x2, [x19, #0x5a20]
1005e294c: f940c7e8    	ldr	x8, [sp, #0x188]
1005e2950: f9056102    	str	x2, [x8, #0xac0]
1005e2954: f940c7ea    	ldr	x10, [sp, #0x188]
1005e2958: f9000940    	str	x0, [x10, #0x10]
1005e295c: f940c7ec    	ldr	x12, [sp, #0x188]
1005e2960: f9000d81    	str	x1, [x12, #0x18]
1005e2964: f9686260    	ldr	x0, [x19, #0x50c0]
1005e2968: f940c7ef    	ldr	x15, [sp, #0x188]
1005e296c: f900b1e0    	str	x0, [x15, #0x160]
1005e2970: f9686660    	ldr	x0, [x19, #0x50c8]
1005e2974: f940c7e1    	ldr	x1, [sp, #0x188]
1005e2978: f900b420    	str	x0, [x1, #0x168]
1005e297c: f9686a60    	ldr	x0, [x19, #0x50d0]
1005e2980: f900b820    	str	x0, [x1, #0x170]
1005e2984: f9686e60    	ldr	x0, [x19, #0x50d8]
1005e2988: f900bc20    	str	x0, [x1, #0x178]
1005e298c: f9687260    	ldr	x0, [x19, #0x50e0]
1005e2990: f900c020    	str	x0, [x1, #0x180]
1005e2994: f9687660    	ldr	x0, [x19, #0x50e8]
1005e2998: f900c420    	str	x0, [x1, #0x188]
1005e299c: f9687a60    	ldr	x0, [x19, #0x50f0]
1005e29a0: f900c820    	str	x0, [x1, #0x190]
1005e29a4: f9687e60    	ldr	x0, [x19, #0x50f8]
1005e29a8: f900cc20    	str	x0, [x1, #0x198]
1005e29ac: f9688260    	ldr	x0, [x19, #0x5100]
1005e29b0: f900d020    	str	x0, [x1, #0x1a0]
1005e29b4: f9695660    	ldr	x0, [x19, #0x52a8]
1005e29b8: f901a420    	str	x0, [x1, #0x348]
1005e29bc: f9695a60    	ldr	x0, [x19, #0x52b0]
1005e29c0: f901a820    	str	x0, [x1, #0x350]
1005e29c4: f9695e60    	ldr	x0, [x19, #0x52b8]
1005e29c8: f901ac20    	str	x0, [x1, #0x358]
1005e29cc: f9696260    	ldr	x0, [x19, #0x52c0]
1005e29d0: f901b020    	str	x0, [x1, #0x360]
1005e29d4: f9696660    	ldr	x0, [x19, #0x52c8]
1005e29d8: f901b420    	str	x0, [x1, #0x368]
1005e29dc: f9696a60    	ldr	x0, [x19, #0x52d0]
1005e29e0: f901b820    	str	x0, [x1, #0x370]
1005e29e4: f9696e60    	ldr	x0, [x19, #0x52d8]
1005e29e8: f901bc20    	str	x0, [x1, #0x378]
1005e29ec: f9697260    	ldr	x0, [x19, #0x52e0]
1005e29f0: f901c020    	str	x0, [x1, #0x380]
1005e29f4: f9697660    	ldr	x0, [x19, #0x52e8]
1005e29f8: f901c4a0    	str	x0, [x5, #0x388]
1005e29fc: f96aee60    	ldr	x0, [x19, #0x55d8]
1005e2a00: f940c7e6    	ldr	x6, [sp, #0x188]
1005e2a04: f9033cc0    	str	x0, [x6, #0x678]
1005e2a08: f96af260    	ldr	x0, [x19, #0x55e0]
1005e2a0c: f940c7e9    	ldr	x9, [sp, #0x188]
1005e2a10: f9034120    	str	x0, [x9, #0x680]
1005e2a14: f96af660    	ldr	x0, [x19, #0x55e8]
1005e2a18: f9034580    	str	x0, [x12, #0x688]
1005e2a1c: f96afa60    	ldr	x0, [x19, #0x55f0]
1005e2a20: f90349e0    	str	x0, [x15, #0x690]
1005e2a24: f96afe60    	ldr	x0, [x19, #0x55f8]
1005e2a28: f9034c20    	str	x0, [x1, #0x698]
1005e2a2c: f96b0260    	ldr	x0, [x19, #0x5600]
1005e2a30: f9035020    	str	x0, [x1, #0x6a0]
1005e2a34: f96b0660    	ldr	x0, [x19, #0x5608]
1005e2a38: f9035420    	str	x0, [x1, #0x6a8]
1005e2a3c: f96b0a60    	ldr	x0, [x19, #0x5610]
1005e2a40: f9035820    	str	x0, [x1, #0x6b0]
1005e2a44: f96bd260    	ldr	x0, [x19, #0x57a0]
1005e2a48: f9042020    	str	x0, [x1, #0x840]
1005e2a4c: f96bd660    	ldr	x0, [x19, #0x57a8]
1005e2a50: f9042420    	str	x0, [x1, #0x848]
1005e2a54: f96bda60    	ldr	x0, [x19, #0x57b0]
1005e2a58: f9042820    	str	x0, [x1, #0x850]
1005e2a5c: f96bde61    	ldr	x1, [x19, #0x57b8]
1005e2a60: f940c7e0    	ldr	x0, [sp, #0x188]
1005e2a64: f9042c01    	str	x1, [x0, #0x858]
1005e2a68: f96be262    	ldr	x2, [x19, #0x57c0]
1005e2a6c: f9043002    	str	x2, [x0, #0x860]
1005e2a70: f96be665    	ldr	x5, [x19, #0x57c8]
1005e2a74: f9043405    	str	x5, [x0, #0x868]
1005e2a78: f96bea65    	ldr	x5, [x19, #0x57d0]
1005e2a7c: f9043805    	str	x5, [x0, #0x870]
1005e2a80: f96bee65    	ldr	x5, [x19, #0x57d8]
1005e2a84: f9043c05    	str	x5, [x0, #0x878]
1005e2a88: f96dda66    	ldr	x6, [x19, #0x5bb0]
1005e2a8c: f9062806    	str	x6, [x0, #0xc50]
1005e2a90: f96dde67    	ldr	x7, [x19, #0x5bb8]
1005e2a94: f9062c07    	str	x7, [x0, #0xc58]
1005e2a98: f96de268    	ldr	x8, [x19, #0x5bc0]
1005e2a9c: f9063008    	str	x8, [x0, #0xc60]
1005e2aa0: f96de669    	ldr	x9, [x19, #0x5bc8]
1005e2aa4: f9063409    	str	x9, [x0, #0xc68]
1005e2aa8: f96dea6a    	ldr	x10, [x19, #0x5bd0]
1005e2aac: f940c7e5    	ldr	x5, [sp, #0x188]
1005e2ab0: f90638aa    	str	x10, [x5, #0xc70]
1005e2ab4: f96dee6b    	ldr	x11, [x19, #0x5bd8]
1005e2ab8: f940c7e6    	ldr	x6, [sp, #0x188]
1005e2abc: f9063ccb    	str	x11, [x6, #0xc78]
1005e2ac0: d280000c    	mov	x12, #0x0               ; =0
1005e2ac4: f940c7e9    	ldr	x9, [sp, #0x188]
1005e2ac8: f906412c    	str	x12, [x9, #0xc80]
1005e2acc: f96df66d    	ldr	x13, [x19, #0x5be8]
1005e2ad0: f940c7ee    	ldr	x14, [sp, #0x188]
1005e2ad4: f90645cd    	str	x13, [x14, #0xc88]
1005e2ad8: f96dfa6e    	ldr	x14, [x19, #0x5bf0]
1005e2adc: f90649ee    	str	x14, [x15, #0xc90]
1005e2ae0: f9064c0c    	str	x12, [x0, #0xc98]
1005e2ae4: f96e0260    	ldr	x0, [x19, #0x5c00]
1005e2ae8: f940c7e1    	ldr	x1, [sp, #0x188]
1005e2aec: f9065020    	str	x0, [x1, #0xca0]
1005e2af0: f96e0660    	ldr	x0, [x19, #0x5c08]
1005e2af4: f9065420    	str	x0, [x1, #0xca8]
1005e2af8: f940c7e0    	ldr	x0, [sp, #0x188]
1005e2afc: f906580c    	str	x12, [x0, #0xcb0]
1005e2b00: f96e0e60    	ldr	x0, [x19, #0x5c18]
1005e2b04: f9065c20    	str	x0, [x1, #0xcb8]
1005e2b08: f96e1260    	ldr	x0, [x19, #0x5c20]
1005e2b0c: f9066020    	str	x0, [x1, #0xcc0]
1005e2b10: d280a3e1    	mov	x1, #0x51f              ; =1311
1005e2b14: 92800102    	mov	x2, #-0x9               ; =-9
1005e2b18: d2800025    	mov	x5, #0x1                ; =1
1005e2b1c: f84083e0    	ldur	x0, [sp, #0x8]
1005e2b20: f940cbe6    	ldr	x6, [sp, #0x190]
1005e2b24: f940cff5    	ldr	x21, [sp, #0x198]
1005e2b28: d63f02a0    	blr	x21
1005e2b2c: f100001f    	cmp	x0, #0x0
1005e2b30: 5401e6c1    	b.ne	0x1005e6808 <_mech_canonical_program_entry_v1_numeric_1282+0x5188>
1005e2b34: d2800000    	mov	x0, #0x0                ; =0
1005e2b38: aa1403e1    	mov	x1, x20
1005e2b3c: 9106c3ff    	add	sp, sp, #0x1b0
1005e2b40: a8c153f3    	ldp	x19, x20, [sp], #0x10
1005e2b44: a8c15bf5    	ldp	x21, x22, [sp], #0x10
1005e2b48: a8c163f7    	ldp	x23, x24, [sp], #0x10
1005e2b4c: a8c16bf9    	ldp	x25, x26, [sp], #0x10
1005e2b50: a8c173fb    	ldp	x27, x28, [sp], #0x10
1005e2b54: a8c17bfd    	ldp	x29, x30, [sp], #0x10
1005e2b58: d65f0fff    	retab
1005e2b5c: f84183e1    	ldur	x1, [sp, #0x18]
1005e2b60: f80683e2    	stur	x2, [sp, #0x68]
1005e2b64: aa1a03ef    	mov	x15, x26
1005e2b68: eb0f003f    	cmp	x1, x15
1005e2b6c: 9a9f27ef    	cset	x15, lo
1005e2b70: f80c83ef    	stur	x15, [sp, #0xc8]
1005e2b74: aa1a03ef    	mov	x15, x26
1005e2b78: eb0f003f    	cmp	x1, x15
1005e2b7c: 540001a3    	b.lo	0x1005e2bb0 <_mech_canonical_program_entry_v1_numeric_1282+0x1530>
1005e2b80: 52842cc0    	mov	w0, #0x2166             ; =8550
1005e2b84: 72a00020    	movk	w0, #0x1, lsl #16
1005e2b88: cb000063    	sub	x3, x3, x0
1005e2b8c: f80603f9    	stur	x25, [sp, #0x60]
1005e2b90: f80583fb    	stur	x27, [sp, #0x58]
1005e2b94: f80183e1    	stur	x1, [sp, #0x18]
1005e2b98: aa1b03ef    	mov	x15, x27
1005e2b9c: aa0103e4    	mov	x4, x1
1005e2ba0: f84103e2    	ldur	x2, [sp, #0x10]
1005e2ba4: f84683e1    	ldur	x1, [sp, #0x68]
1005e2ba8: f84703e0    	ldur	x0, [sp, #0x70]
1005e2bac: 140004ec    	b	0x1005e3f5c <_mech_canonical_program_entry_v1_numeric_1282+0x28dc>
1005e2bb0: f940abef    	ldr	x15, [sp, #0x150]
1005e2bb4: eb0f003f    	cmp	x1, x15
1005e2bb8: 540014c3    	b.lo	0x1005e2e50 <_mech_canonical_program_entry_v1_numeric_1282+0x17d0>
1005e2bbc: 14000f15    	b	0x1005e6810 <_mech_canonical_program_entry_v1_numeric_1282+0x5190>
1005e2bc0: f9663663    	ldr	x3, [x19, #0x4c68]
1005e2bc4: f9663a64    	ldr	x4, [x19, #0x4c70]
1005e2bc8: d2800000    	mov	x0, #0x0                ; =0
1005e2bcc: f9263260    	str	x0, [x19, #0x4c60]
1005e2bd0: d2800060    	mov	x0, #0x3                ; =3
1005e2bd4: f940c3ef    	ldr	x15, [sp, #0x180]
1005e2bd8: f80b83e0    	stur	x0, [sp, #0xb8]
1005e2bdc: f10669ff    	cmp	x15, #0x19a
1005e2be0: 5402ccc3    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e2be4: f967ba60    	ldr	x0, [x19, #0x4f70]
1005e2be8: f940c7e1    	ldr	x1, [sp, #0x188]
1005e2bec: f9000820    	str	x0, [x1, #0x10]
1005e2bf0: f967be61    	ldr	x1, [x19, #0x4f78]
1005e2bf4: f940c7e2    	ldr	x2, [sp, #0x188]
1005e2bf8: f9000c41    	str	x1, [x2, #0x18]
1005e2bfc: f96d1262    	ldr	x2, [x19, #0x5a20]
1005e2c00: f940c7e5    	ldr	x5, [sp, #0x188]
1005e2c04: f90560a2    	str	x2, [x5, #0xac0]
1005e2c08: f940c7e2    	ldr	x2, [sp, #0x188]
1005e2c0c: f9000840    	str	x0, [x2, #0x10]
1005e2c10: f940c7e0    	ldr	x0, [sp, #0x188]
1005e2c14: f9000c01    	str	x1, [x0, #0x18]
1005e2c18: f9686260    	ldr	x0, [x19, #0x50c0]
1005e2c1c: f940c7e1    	ldr	x1, [sp, #0x188]
1005e2c20: f900b020    	str	x0, [x1, #0x160]
1005e2c24: f9686660    	ldr	x0, [x19, #0x50c8]
1005e2c28: f900b420    	str	x0, [x1, #0x168]
1005e2c2c: f9686a60    	ldr	x0, [x19, #0x50d0]
1005e2c30: f900b820    	str	x0, [x1, #0x170]
1005e2c34: f9686e60    	ldr	x0, [x19, #0x50d8]
1005e2c38: f900bc20    	str	x0, [x1, #0x178]
1005e2c3c: f9687260    	ldr	x0, [x19, #0x50e0]
1005e2c40: f900c020    	str	x0, [x1, #0x180]
1005e2c44: f9687660    	ldr	x0, [x19, #0x50e8]
1005e2c48: f900c420    	str	x0, [x1, #0x188]
1005e2c4c: f9687a60    	ldr	x0, [x19, #0x50f0]
1005e2c50: f900c820    	str	x0, [x1, #0x190]
1005e2c54: f9687e60    	ldr	x0, [x19, #0x50f8]
1005e2c58: f900cca0    	str	x0, [x5, #0x198]
1005e2c5c: f9688260    	ldr	x0, [x19, #0x5100]
1005e2c60: f940c7e6    	ldr	x6, [sp, #0x188]
1005e2c64: f900d0c0    	str	x0, [x6, #0x1a0]
1005e2c68: f9695660    	ldr	x0, [x19, #0x52a8]
1005e2c6c: f940c7e9    	ldr	x9, [sp, #0x188]
1005e2c70: f901a520    	str	x0, [x9, #0x348]
1005e2c74: f9695a60    	ldr	x0, [x19, #0x52b0]
1005e2c78: f940c7ec    	ldr	x12, [sp, #0x188]
1005e2c7c: f901a980    	str	x0, [x12, #0x350]
1005e2c80: f9695e60    	ldr	x0, [x19, #0x52b8]
1005e2c84: f940c7ef    	ldr	x15, [sp, #0x188]
1005e2c88: f901ade0    	str	x0, [x15, #0x358]
1005e2c8c: f9696260    	ldr	x0, [x19, #0x52c0]
1005e2c90: f901b020    	str	x0, [x1, #0x360]
1005e2c94: f9696660    	ldr	x0, [x19, #0x52c8]
1005e2c98: f901b420    	str	x0, [x1, #0x368]
1005e2c9c: f9696a60    	ldr	x0, [x19, #0x52d0]
1005e2ca0: f901b820    	str	x0, [x1, #0x370]
1005e2ca4: f9696e60    	ldr	x0, [x19, #0x52d8]
1005e2ca8: f901bc20    	str	x0, [x1, #0x378]
1005e2cac: f9697261    	ldr	x1, [x19, #0x52e0]
1005e2cb0: f940c7e0    	ldr	x0, [sp, #0x188]
1005e2cb4: f901c001    	str	x1, [x0, #0x380]
1005e2cb8: f9697662    	ldr	x2, [x19, #0x52e8]
1005e2cbc: f901c402    	str	x2, [x0, #0x388]
1005e2cc0: f96aee65    	ldr	x5, [x19, #0x55d8]
1005e2cc4: f9033c05    	str	x5, [x0, #0x678]
1005e2cc8: f96af265    	ldr	x5, [x19, #0x55e0]
1005e2ccc: f9034005    	str	x5, [x0, #0x680]
1005e2cd0: f96af665    	ldr	x5, [x19, #0x55e8]
1005e2cd4: f9034405    	str	x5, [x0, #0x688]
1005e2cd8: f96afa66    	ldr	x6, [x19, #0x55f0]
1005e2cdc: f9034806    	str	x6, [x0, #0x690]
1005e2ce0: f96afe67    	ldr	x7, [x19, #0x55f8]
1005e2ce4: f9034c07    	str	x7, [x0, #0x698]
1005e2ce8: f96b0268    	ldr	x8, [x19, #0x5600]
1005e2cec: f9035008    	str	x8, [x0, #0x6a0]
1005e2cf0: f96b0669    	ldr	x9, [x19, #0x5608]
1005e2cf4: f9035409    	str	x9, [x0, #0x6a8]
1005e2cf8: f96b0a6a    	ldr	x10, [x19, #0x5610]
1005e2cfc: f903580a    	str	x10, [x0, #0x6b0]
1005e2d00: f96bd26b    	ldr	x11, [x19, #0x57a0]
1005e2d04: f904200b    	str	x11, [x0, #0x840]
1005e2d08: f96bd66c    	ldr	x12, [x19, #0x57a8]
1005e2d0c: f904240c    	str	x12, [x0, #0x848]
1005e2d10: f96bda6d    	ldr	x13, [x19, #0x57b0]
1005e2d14: f940c7e5    	ldr	x5, [sp, #0x188]
1005e2d18: f90428ad    	str	x13, [x5, #0x850]
1005e2d1c: f96bde6e    	ldr	x14, [x19, #0x57b8]
1005e2d20: f940c7e6    	ldr	x6, [sp, #0x188]
1005e2d24: f9042cce    	str	x14, [x6, #0x858]
1005e2d28: f96be26f    	ldr	x15, [x19, #0x57c0]
1005e2d2c: f940c7e9    	ldr	x9, [sp, #0x188]
1005e2d30: f904312f    	str	x15, [x9, #0x860]
1005e2d34: f96be660    	ldr	x0, [x19, #0x57c8]
1005e2d38: f940c7ec    	ldr	x12, [sp, #0x188]
1005e2d3c: f9043580    	str	x0, [x12, #0x868]
1005e2d40: f96bea60    	ldr	x0, [x19, #0x57d0]
1005e2d44: f940c7ef    	ldr	x15, [sp, #0x188]
1005e2d48: f90439e0    	str	x0, [x15, #0x870]
1005e2d4c: f96bee60    	ldr	x0, [x19, #0x57d8]
1005e2d50: f940c7e1    	ldr	x1, [sp, #0x188]
1005e2d54: f9043c20    	str	x0, [x1, #0x878]
1005e2d58: f96dda60    	ldr	x0, [x19, #0x5bb0]
1005e2d5c: f9062820    	str	x0, [x1, #0xc50]
1005e2d60: f96dde60    	ldr	x0, [x19, #0x5bb8]
1005e2d64: f9062c20    	str	x0, [x1, #0xc58]
1005e2d68: f96de260    	ldr	x0, [x19, #0x5bc0]
1005e2d6c: f9063020    	str	x0, [x1, #0xc60]
1005e2d70: f96de660    	ldr	x0, [x19, #0x5bc8]
1005e2d74: f9063420    	str	x0, [x1, #0xc68]
1005e2d78: f96dea60    	ldr	x0, [x19, #0x5bd0]
1005e2d7c: f9063820    	str	x0, [x1, #0xc70]
1005e2d80: f96dee60    	ldr	x0, [x19, #0x5bd8]
1005e2d84: f9063c20    	str	x0, [x1, #0xc78]
1005e2d88: d2800000    	mov	x0, #0x0                ; =0
1005e2d8c: f9064020    	str	x0, [x1, #0xc80]
1005e2d90: f96df661    	ldr	x1, [x19, #0x5be8]
1005e2d94: f940c7e2    	ldr	x2, [sp, #0x188]
1005e2d98: f9064441    	str	x1, [x2, #0xc88]
1005e2d9c: f96dfa61    	ldr	x1, [x19, #0x5bf0]
1005e2da0: f9064841    	str	x1, [x2, #0xc90]
1005e2da4: f940c7e1    	ldr	x1, [sp, #0x188]
1005e2da8: f9064c20    	str	x0, [x1, #0xc98]
1005e2dac: f96e0261    	ldr	x1, [x19, #0x5c00]
1005e2db0: f9065041    	str	x1, [x2, #0xca0]
1005e2db4: f96e0661    	ldr	x1, [x19, #0x5c08]
1005e2db8: f9065441    	str	x1, [x2, #0xca8]
1005e2dbc: f940c7e1    	ldr	x1, [sp, #0x188]
1005e2dc0: f9065820    	str	x0, [x1, #0xcb0]
1005e2dc4: f96e0e60    	ldr	x0, [x19, #0x5c18]
1005e2dc8: f9065c20    	str	x0, [x1, #0xcb8]
1005e2dcc: f96e1260    	ldr	x0, [x19, #0x5c20]
1005e2dd0: f9066020    	str	x0, [x1, #0xcc0]
1005e2dd4: d280a601    	mov	x1, #0x530              ; =1328
1005e2dd8: 92800102    	mov	x2, #-0x9               ; =-9
1005e2ddc: f940cff5    	ldr	x21, [sp, #0x198]
1005e2de0: f84083e0    	ldur	x0, [sp, #0x8]
1005e2de4: aa1403e5    	mov	x5, x20
1005e2de8: f940cbe6    	ldr	x6, [sp, #0x190]
1005e2dec: d63f02a0    	blr	x21
1005e2df0: f100001f    	cmp	x0, #0x0
1005e2df4: 5401dd61    	b.ne	0x1005e69a0 <_mech_canonical_program_entry_v1_numeric_1282+0x5320>
1005e2df8: d2800060    	mov	x0, #0x3                ; =3
1005e2dfc: f940c3ef    	ldr	x15, [sp, #0x180]
1005e2e00: f80b83e0    	stur	x0, [sp, #0xb8]
1005e2e04: f10009ff    	cmp	x15, #0x2
1005e2e08: 5402bb83    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e2e0c: d2800005    	mov	x5, #0x0                ; =0
1005e2e10: f940c7e3    	ldr	x3, [sp, #0x188]
1005e2e14: f9000065    	str	x5, [x3]
1005e2e18: f94c4a60    	ldr	x0, [x19, #0x1890]
1005e2e1c: f9000460    	str	x0, [x3, #0x8]
1005e2e20: d280a601    	mov	x1, #0x530              ; =1328
1005e2e24: f84083e0    	ldur	x0, [sp, #0x8]
1005e2e28: f940cbe6    	ldr	x6, [sp, #0x190]
1005e2e2c: f940cff5    	ldr	x21, [sp, #0x198]
1005e2e30: aa1403e4    	mov	x4, x20
1005e2e34: aa0503e2    	mov	x2, x5
1005e2e38: d63f02a0    	blr	x21
1005e2e3c: f100001f    	cmp	x0, #0x0
1005e2e40: 5401db41    	b.ne	0x1005e69a8 <_mech_canonical_program_entry_v1_numeric_1282+0x5328>
1005e2e44: d2800060    	mov	x0, #0x3                ; =3
1005e2e48: f80b83e0    	stur	x0, [sp, #0xb8]
1005e2e4c: 140015cb    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e2e50: f940afe0    	ldr	x0, [sp, #0x158]
1005e2e54: f80603f9    	stur	x25, [sp, #0x60]
1005e2e58: f8617802    	ldr	x2, [x0, x1, lsl #3]
1005e2e5c: 91000444    	add	x4, x2, #0x1
1005e2e60: eb02009f    	cmp	x4, x2
1005e2e64: 5401da63    	b.lo	0x1005e69b0 <_mech_canonical_program_entry_v1_numeric_1282+0x5330>
1005e2e68: f940a3e0    	ldr	x0, [sp, #0x140]
1005e2e6c: eb00005f    	cmp	x2, x0
1005e2e70: 54001443    	b.lo	0x1005e30f8 <_mech_canonical_program_entry_v1_numeric_1282+0x1a78>
1005e2e74: 14000f22    	b	0x1005e6afc <_mech_canonical_program_entry_v1_numeric_1282+0x547c>
1005e2e78: f9663663    	ldr	x3, [x19, #0x4c68]
1005e2e7c: f9663a64    	ldr	x4, [x19, #0x4c70]
1005e2e80: d2800000    	mov	x0, #0x0                ; =0
1005e2e84: f9263260    	str	x0, [x19, #0x4c60]
1005e2e88: d2800060    	mov	x0, #0x3                ; =3
1005e2e8c: f940c3ef    	ldr	x15, [sp, #0x180]
1005e2e90: f80b83e0    	stur	x0, [sp, #0xb8]
1005e2e94: f10669ff    	cmp	x15, #0x19a
1005e2e98: 5402b703    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e2e9c: f967ba60    	ldr	x0, [x19, #0x4f70]
1005e2ea0: f940c7e1    	ldr	x1, [sp, #0x188]
1005e2ea4: f9000820    	str	x0, [x1, #0x10]
1005e2ea8: f967be61    	ldr	x1, [x19, #0x4f78]
1005e2eac: f940c7e5    	ldr	x5, [sp, #0x188]
1005e2eb0: f9000ca1    	str	x1, [x5, #0x18]
1005e2eb4: f96d1262    	ldr	x2, [x19, #0x5a20]
1005e2eb8: f940c7e6    	ldr	x6, [sp, #0x188]
1005e2ebc: f90560c2    	str	x2, [x6, #0xac0]
1005e2ec0: f940c7e8    	ldr	x8, [sp, #0x188]
1005e2ec4: f9000900    	str	x0, [x8, #0x10]
1005e2ec8: f940c7ea    	ldr	x10, [sp, #0x188]
1005e2ecc: f9000d41    	str	x1, [x10, #0x18]
1005e2ed0: f9686260    	ldr	x0, [x19, #0x50c0]
1005e2ed4: f940c7ed    	ldr	x13, [sp, #0x188]
1005e2ed8: f900b1a0    	str	x0, [x13, #0x160]
1005e2edc: f9686660    	ldr	x0, [x19, #0x50c8]
1005e2ee0: f940c7e1    	ldr	x1, [sp, #0x188]
1005e2ee4: f900b420    	str	x0, [x1, #0x168]
1005e2ee8: f9686a60    	ldr	x0, [x19, #0x50d0]
1005e2eec: f900b820    	str	x0, [x1, #0x170]
1005e2ef0: f9686e60    	ldr	x0, [x19, #0x50d8]
1005e2ef4: f900bc20    	str	x0, [x1, #0x178]
1005e2ef8: f9687260    	ldr	x0, [x19, #0x50e0]
1005e2efc: f900c020    	str	x0, [x1, #0x180]
1005e2f00: f9687660    	ldr	x0, [x19, #0x50e8]
1005e2f04: f900c420    	str	x0, [x1, #0x188]
1005e2f08: f9687a60    	ldr	x0, [x19, #0x50f0]
1005e2f0c: f900c820    	str	x0, [x1, #0x190]
1005e2f10: f9687e60    	ldr	x0, [x19, #0x50f8]
1005e2f14: f900cc20    	str	x0, [x1, #0x198]
1005e2f18: f9688260    	ldr	x0, [x19, #0x5100]
1005e2f1c: f900d020    	str	x0, [x1, #0x1a0]
1005e2f20: f9695660    	ldr	x0, [x19, #0x52a8]
1005e2f24: f901a420    	str	x0, [x1, #0x348]
1005e2f28: f9695a60    	ldr	x0, [x19, #0x52b0]
1005e2f2c: f901a820    	str	x0, [x1, #0x350]
1005e2f30: f9695e60    	ldr	x0, [x19, #0x52b8]
1005e2f34: f901ac20    	str	x0, [x1, #0x358]
1005e2f38: f9696260    	ldr	x0, [x19, #0x52c0]
1005e2f3c: f901b020    	str	x0, [x1, #0x360]
1005e2f40: f9696660    	ldr	x0, [x19, #0x52c8]
1005e2f44: f901b420    	str	x0, [x1, #0x368]
1005e2f48: f9696a60    	ldr	x0, [x19, #0x52d0]
1005e2f4c: f901b820    	str	x0, [x1, #0x370]
1005e2f50: f9696e60    	ldr	x0, [x19, #0x52d8]
1005e2f54: f901bc20    	str	x0, [x1, #0x378]
1005e2f58: f9697260    	ldr	x0, [x19, #0x52e0]
1005e2f5c: f901c020    	str	x0, [x1, #0x380]
1005e2f60: f9697660    	ldr	x0, [x19, #0x52e8]
1005e2f64: f901c420    	str	x0, [x1, #0x388]
1005e2f68: f96aee60    	ldr	x0, [x19, #0x55d8]
1005e2f6c: f9033ca0    	str	x0, [x5, #0x678]
1005e2f70: f96af260    	ldr	x0, [x19, #0x55e0]
1005e2f74: f940c7e7    	ldr	x7, [sp, #0x188]
1005e2f78: f90340e0    	str	x0, [x7, #0x680]
1005e2f7c: f96af660    	ldr	x0, [x19, #0x55e8]
1005e2f80: f9034540    	str	x0, [x10, #0x688]
1005e2f84: f96afa60    	ldr	x0, [x19, #0x55f0]
1005e2f88: f90349a0    	str	x0, [x13, #0x690]
1005e2f8c: f96afe60    	ldr	x0, [x19, #0x55f8]
1005e2f90: f9034c20    	str	x0, [x1, #0x698]
1005e2f94: f96b0260    	ldr	x0, [x19, #0x5600]
1005e2f98: f9035020    	str	x0, [x1, #0x6a0]
1005e2f9c: f96b0660    	ldr	x0, [x19, #0x5608]
1005e2fa0: f9035420    	str	x0, [x1, #0x6a8]
1005e2fa4: f96b0a60    	ldr	x0, [x19, #0x5610]
1005e2fa8: f9035820    	str	x0, [x1, #0x6b0]
1005e2fac: f96bd260    	ldr	x0, [x19, #0x57a0]
1005e2fb0: f9042020    	str	x0, [x1, #0x840]
1005e2fb4: f96bd660    	ldr	x0, [x19, #0x57a8]
1005e2fb8: f9042420    	str	x0, [x1, #0x848]
1005e2fbc: f96bda60    	ldr	x0, [x19, #0x57b0]
1005e2fc0: f9042820    	str	x0, [x1, #0x850]
1005e2fc4: f96bde60    	ldr	x0, [x19, #0x57b8]
1005e2fc8: f9042c20    	str	x0, [x1, #0x858]
1005e2fcc: f96be261    	ldr	x1, [x19, #0x57c0]
1005e2fd0: f940c7e0    	ldr	x0, [sp, #0x188]
1005e2fd4: f9043001    	str	x1, [x0, #0x860]
1005e2fd8: f96be662    	ldr	x2, [x19, #0x57c8]
1005e2fdc: f9043402    	str	x2, [x0, #0x868]
1005e2fe0: f96bea65    	ldr	x5, [x19, #0x57d0]
1005e2fe4: f9043805    	str	x5, [x0, #0x870]
1005e2fe8: f96bee65    	ldr	x5, [x19, #0x57d8]
1005e2fec: f9043c05    	str	x5, [x0, #0x878]
1005e2ff0: f96dda65    	ldr	x5, [x19, #0x5bb0]
1005e2ff4: f9062805    	str	x5, [x0, #0xc50]
1005e2ff8: f96dde66    	ldr	x6, [x19, #0x5bb8]
1005e2ffc: f9062c06    	str	x6, [x0, #0xc58]
1005e3000: f96de267    	ldr	x7, [x19, #0x5bc0]
1005e3004: f9063007    	str	x7, [x0, #0xc60]
1005e3008: f96de668    	ldr	x8, [x19, #0x5bc8]
1005e300c: f9063408    	str	x8, [x0, #0xc68]
1005e3010: f96dea69    	ldr	x9, [x19, #0x5bd0]
1005e3014: f940c7e1    	ldr	x1, [sp, #0x188]
1005e3018: f9063829    	str	x9, [x1, #0xc70]
1005e301c: f96dee6a    	ldr	x10, [x19, #0x5bd8]
1005e3020: f940c7e5    	ldr	x5, [sp, #0x188]
1005e3024: f9063caa    	str	x10, [x5, #0xc78]
1005e3028: d280000b    	mov	x11, #0x0               ; =0
1005e302c: f940c7e7    	ldr	x7, [sp, #0x188]
1005e3030: f90640eb    	str	x11, [x7, #0xc80]
1005e3034: f96df66c    	ldr	x12, [x19, #0x5be8]
1005e3038: f940c7ea    	ldr	x10, [sp, #0x188]
1005e303c: f906454c    	str	x12, [x10, #0xc88]
1005e3040: f96dfa6d    	ldr	x13, [x19, #0x5bf0]
1005e3044: f940c7ee    	ldr	x14, [sp, #0x188]
1005e3048: f90649cd    	str	x13, [x14, #0xc90]
1005e304c: f940c7ef    	ldr	x15, [sp, #0x188]
1005e3050: f9064deb    	str	x11, [x15, #0xc98]
1005e3054: f96e026f    	ldr	x15, [x19, #0x5c00]
1005e3058: f906500f    	str	x15, [x0, #0xca0]
1005e305c: f96e0660    	ldr	x0, [x19, #0x5c08]
1005e3060: f9065420    	str	x0, [x1, #0xca8]
1005e3064: f940c7e0    	ldr	x0, [sp, #0x188]
1005e3068: f906580b    	str	x11, [x0, #0xcb0]
1005e306c: f96e0e60    	ldr	x0, [x19, #0x5c18]
1005e3070: f9065c20    	str	x0, [x1, #0xcb8]
1005e3074: f96e1260    	ldr	x0, [x19, #0x5c20]
1005e3078: f9066020    	str	x0, [x1, #0xcc0]
1005e307c: d280a641    	mov	x1, #0x532              ; =1330
1005e3080: 92800102    	mov	x2, #-0x9               ; =-9
1005e3084: f940cff5    	ldr	x21, [sp, #0x198]
1005e3088: f84083e0    	ldur	x0, [sp, #0x8]
1005e308c: aa1403e5    	mov	x5, x20
1005e3090: f940cbe6    	ldr	x6, [sp, #0x190]
1005e3094: d63f02a0    	blr	x21
1005e3098: f100001f    	cmp	x0, #0x0
1005e309c: 5401dfa1    	b.ne	0x1005e6c90 <_mech_canonical_program_entry_v1_numeric_1282+0x5610>
1005e30a0: d2800060    	mov	x0, #0x3                ; =3
1005e30a4: f940c3ef    	ldr	x15, [sp, #0x180]
1005e30a8: f80b83e0    	stur	x0, [sp, #0xb8]
1005e30ac: f10009ff    	cmp	x15, #0x2
1005e30b0: 5402a643    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e30b4: d2800005    	mov	x5, #0x0                ; =0
1005e30b8: f940c7e3    	ldr	x3, [sp, #0x188]
1005e30bc: f9000065    	str	x5, [x3]
1005e30c0: f94c5260    	ldr	x0, [x19, #0x18a0]
1005e30c4: f9000460    	str	x0, [x3, #0x8]
1005e30c8: d280a641    	mov	x1, #0x532              ; =1330
1005e30cc: f84083e0    	ldur	x0, [sp, #0x8]
1005e30d0: f940cbe6    	ldr	x6, [sp, #0x190]
1005e30d4: f940cff5    	ldr	x21, [sp, #0x198]
1005e30d8: aa1403e4    	mov	x4, x20
1005e30dc: aa0503e2    	mov	x2, x5
1005e30e0: d63f02a0    	blr	x21
1005e30e4: f100001f    	cmp	x0, #0x0
1005e30e8: 5401dd81    	b.ne	0x1005e6c98 <_mech_canonical_program_entry_v1_numeric_1282+0x5618>
1005e30ec: d2800060    	mov	x0, #0x3                ; =3
1005e30f0: f80b83e0    	stur	x0, [sp, #0xb8]
1005e30f4: 14001521    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e30f8: f940a7e0    	ldr	x0, [sp, #0x148]
1005e30fc: f80183e1    	stur	x1, [sp, #0x18]
1005e3100: f80583fb    	stur	x27, [sp, #0x58]
1005e3104: f862781b    	ldr	x27, [x0, x2, lsl #3]
1005e3108: f940a3e0    	ldr	x0, [sp, #0x140]
1005e310c: eb00009f    	cmp	x4, x0
1005e3110: 54001443    	b.lo	0x1005e3398 <_mech_canonical_program_entry_v1_numeric_1282+0x1d18>
1005e3114: 14000ee3    	b	0x1005e6ca0 <_mech_canonical_program_entry_v1_numeric_1282+0x5620>
1005e3118: f9663663    	ldr	x3, [x19, #0x4c68]
1005e311c: f9663a64    	ldr	x4, [x19, #0x4c70]
1005e3120: d2800000    	mov	x0, #0x0                ; =0
1005e3124: f9263260    	str	x0, [x19, #0x4c60]
1005e3128: d2800060    	mov	x0, #0x3                ; =3
1005e312c: f940c3ef    	ldr	x15, [sp, #0x180]
1005e3130: f80b83e0    	stur	x0, [sp, #0xb8]
1005e3134: f10669ff    	cmp	x15, #0x19a
1005e3138: 5402a203    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e313c: f967ba60    	ldr	x0, [x19, #0x4f70]
1005e3140: f940c7e1    	ldr	x1, [sp, #0x188]
1005e3144: f9000820    	str	x0, [x1, #0x10]
1005e3148: f967be61    	ldr	x1, [x19, #0x4f78]
1005e314c: f940c7e2    	ldr	x2, [sp, #0x188]
1005e3150: f9000c41    	str	x1, [x2, #0x18]
1005e3154: f96d1262    	ldr	x2, [x19, #0x5a20]
1005e3158: f940c7e5    	ldr	x5, [sp, #0x188]
1005e315c: f90560a2    	str	x2, [x5, #0xac0]
1005e3160: f940c7e2    	ldr	x2, [sp, #0x188]
1005e3164: f9000840    	str	x0, [x2, #0x10]
1005e3168: f940c7e0    	ldr	x0, [sp, #0x188]
1005e316c: f9000c01    	str	x1, [x0, #0x18]
1005e3170: f9686260    	ldr	x0, [x19, #0x50c0]
1005e3174: f940c7e1    	ldr	x1, [sp, #0x188]
1005e3178: f900b020    	str	x0, [x1, #0x160]
1005e317c: f9686660    	ldr	x0, [x19, #0x50c8]
1005e3180: f900b420    	str	x0, [x1, #0x168]
1005e3184: f9686a60    	ldr	x0, [x19, #0x50d0]
1005e3188: f900b820    	str	x0, [x1, #0x170]
1005e318c: f9686e60    	ldr	x0, [x19, #0x50d8]
1005e3190: f900bc20    	str	x0, [x1, #0x178]
1005e3194: f9687260    	ldr	x0, [x19, #0x50e0]
1005e3198: f900c020    	str	x0, [x1, #0x180]
1005e319c: f9687660    	ldr	x0, [x19, #0x50e8]
1005e31a0: f900c420    	str	x0, [x1, #0x188]
1005e31a4: f9687a60    	ldr	x0, [x19, #0x50f0]
1005e31a8: f900c820    	str	x0, [x1, #0x190]
1005e31ac: f9687e60    	ldr	x0, [x19, #0x50f8]
1005e31b0: f900cc20    	str	x0, [x1, #0x198]
1005e31b4: f9688260    	ldr	x0, [x19, #0x5100]
1005e31b8: f900d020    	str	x0, [x1, #0x1a0]
1005e31bc: f9695660    	ldr	x0, [x19, #0x52a8]
1005e31c0: f901a4a0    	str	x0, [x5, #0x348]
1005e31c4: f9695a60    	ldr	x0, [x19, #0x52b0]
1005e31c8: f940c7e7    	ldr	x7, [sp, #0x188]
1005e31cc: f901a8e0    	str	x0, [x7, #0x350]
1005e31d0: f9695e60    	ldr	x0, [x19, #0x52b8]
1005e31d4: f940c7ea    	ldr	x10, [sp, #0x188]
1005e31d8: f901ad40    	str	x0, [x10, #0x358]
1005e31dc: f9696260    	ldr	x0, [x19, #0x52c0]
1005e31e0: f940c7ed    	ldr	x13, [sp, #0x188]
1005e31e4: f901b1a0    	str	x0, [x13, #0x360]
1005e31e8: f9696660    	ldr	x0, [x19, #0x52c8]
1005e31ec: f901b420    	str	x0, [x1, #0x368]
1005e31f0: f9696a60    	ldr	x0, [x19, #0x52d0]
1005e31f4: f901b820    	str	x0, [x1, #0x370]
1005e31f8: f9696e60    	ldr	x0, [x19, #0x52d8]
1005e31fc: f901bc20    	str	x0, [x1, #0x378]
1005e3200: f9697260    	ldr	x0, [x19, #0x52e0]
1005e3204: f901c020    	str	x0, [x1, #0x380]
1005e3208: f9697660    	ldr	x0, [x19, #0x52e8]
1005e320c: f901c420    	str	x0, [x1, #0x388]
1005e3210: f96aee60    	ldr	x0, [x19, #0x55d8]
1005e3214: f9033c20    	str	x0, [x1, #0x678]
1005e3218: f96af260    	ldr	x0, [x19, #0x55e0]
1005e321c: f9034020    	str	x0, [x1, #0x680]
1005e3220: f96af660    	ldr	x0, [x19, #0x55e8]
1005e3224: f9034420    	str	x0, [x1, #0x688]
1005e3228: f96afa60    	ldr	x0, [x19, #0x55f0]
1005e322c: f9034820    	str	x0, [x1, #0x690]
1005e3230: f96afe60    	ldr	x0, [x19, #0x55f8]
1005e3234: f9034c20    	str	x0, [x1, #0x698]
1005e3238: f96b0260    	ldr	x0, [x19, #0x5600]
1005e323c: f9035020    	str	x0, [x1, #0x6a0]
1005e3240: f96b0661    	ldr	x1, [x19, #0x5608]
1005e3244: f940c7e0    	ldr	x0, [sp, #0x188]
1005e3248: f9035401    	str	x1, [x0, #0x6a8]
1005e324c: f96b0a62    	ldr	x2, [x19, #0x5610]
1005e3250: f9035802    	str	x2, [x0, #0x6b0]
1005e3254: f96bd265    	ldr	x5, [x19, #0x57a0]
1005e3258: f9042005    	str	x5, [x0, #0x840]
1005e325c: f96bd665    	ldr	x5, [x19, #0x57a8]
1005e3260: f9042405    	str	x5, [x0, #0x848]
1005e3264: f96bda65    	ldr	x5, [x19, #0x57b0]
1005e3268: f9042805    	str	x5, [x0, #0x850]
1005e326c: f96bde66    	ldr	x6, [x19, #0x57b8]
1005e3270: f940c7e1    	ldr	x1, [sp, #0x188]
1005e3274: f9042c26    	str	x6, [x1, #0x858]
1005e3278: f96be267    	ldr	x7, [x19, #0x57c0]
1005e327c: f940c7e5    	ldr	x5, [sp, #0x188]
1005e3280: f90430a7    	str	x7, [x5, #0x860]
1005e3284: f96be668    	ldr	x8, [x19, #0x57c8]
1005e3288: f940c7e7    	ldr	x7, [sp, #0x188]
1005e328c: f90434e8    	str	x8, [x7, #0x868]
1005e3290: f96bea69    	ldr	x9, [x19, #0x57d0]
1005e3294: f9043949    	str	x9, [x10, #0x870]
1005e3298: f96bee6a    	ldr	x10, [x19, #0x57d8]
1005e329c: f9043daa    	str	x10, [x13, #0x878]
1005e32a0: f96dda6b    	ldr	x11, [x19, #0x5bb0]
1005e32a4: f906280b    	str	x11, [x0, #0xc50]
1005e32a8: f96dde6c    	ldr	x12, [x19, #0x5bb8]
1005e32ac: f9062c0c    	str	x12, [x0, #0xc58]
1005e32b0: f96de26d    	ldr	x13, [x19, #0x5bc0]
1005e32b4: f906300d    	str	x13, [x0, #0xc60]
1005e32b8: f96de66e    	ldr	x14, [x19, #0x5bc8]
1005e32bc: f906340e    	str	x14, [x0, #0xc68]
1005e32c0: f96dea6f    	ldr	x15, [x19, #0x5bd0]
1005e32c4: f906380f    	str	x15, [x0, #0xc70]
1005e32c8: f96dee60    	ldr	x0, [x19, #0x5bd8]
1005e32cc: f9063c20    	str	x0, [x1, #0xc78]
1005e32d0: d2800000    	mov	x0, #0x0                ; =0
1005e32d4: f9064020    	str	x0, [x1, #0xc80]
1005e32d8: f96df661    	ldr	x1, [x19, #0x5be8]
1005e32dc: f940c7e2    	ldr	x2, [sp, #0x188]
1005e32e0: f9064441    	str	x1, [x2, #0xc88]
1005e32e4: f96dfa61    	ldr	x1, [x19, #0x5bf0]
1005e32e8: f9064841    	str	x1, [x2, #0xc90]
1005e32ec: f940c7e1    	ldr	x1, [sp, #0x188]
1005e32f0: f9064c20    	str	x0, [x1, #0xc98]
1005e32f4: f96e0261    	ldr	x1, [x19, #0x5c00]
1005e32f8: f9065041    	str	x1, [x2, #0xca0]
1005e32fc: f96e0661    	ldr	x1, [x19, #0x5c08]
1005e3300: f9065441    	str	x1, [x2, #0xca8]
1005e3304: f940c7e1    	ldr	x1, [sp, #0x188]
1005e3308: f9065820    	str	x0, [x1, #0xcb0]
1005e330c: f96e0e60    	ldr	x0, [x19, #0x5c18]
1005e3310: f9065c20    	str	x0, [x1, #0xcb8]
1005e3314: f96e1260    	ldr	x0, [x19, #0x5c20]
1005e3318: f9066020    	str	x0, [x1, #0xcc0]
1005e331c: d280a681    	mov	x1, #0x534              ; =1332
1005e3320: 92800102    	mov	x2, #-0x9               ; =-9
1005e3324: f940cff5    	ldr	x21, [sp, #0x198]
1005e3328: f84083e0    	ldur	x0, [sp, #0x8]
1005e332c: aa1403e5    	mov	x5, x20
1005e3330: f940cbe6    	ldr	x6, [sp, #0x190]
1005e3334: d63f02a0    	blr	x21
1005e3338: f100001f    	cmp	x0, #0x0
1005e333c: 5401d841    	b.ne	0x1005e6e44 <_mech_canonical_program_entry_v1_numeric_1282+0x57c4>
1005e3340: d2800060    	mov	x0, #0x3                ; =3
1005e3344: f940c3ef    	ldr	x15, [sp, #0x180]
1005e3348: f80b83e0    	stur	x0, [sp, #0xb8]
1005e334c: f10009ff    	cmp	x15, #0x2
1005e3350: 54029143    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e3354: d2800005    	mov	x5, #0x0                ; =0
1005e3358: f940c7e3    	ldr	x3, [sp, #0x188]
1005e335c: f9000065    	str	x5, [x3]
1005e3360: f94c5a60    	ldr	x0, [x19, #0x18b0]
1005e3364: f9000460    	str	x0, [x3, #0x8]
1005e3368: d280a681    	mov	x1, #0x534              ; =1332
1005e336c: f84083e0    	ldur	x0, [sp, #0x8]
1005e3370: f940cbe6    	ldr	x6, [sp, #0x190]
1005e3374: f940cff5    	ldr	x21, [sp, #0x198]
1005e3378: aa1403e4    	mov	x4, x20
1005e337c: aa0503e2    	mov	x2, x5
1005e3380: d63f02a0    	blr	x21
1005e3384: f100001f    	cmp	x0, #0x0
1005e3388: 5401d621    	b.ne	0x1005e6e4c <_mech_canonical_program_entry_v1_numeric_1282+0x57cc>
1005e338c: d2800060    	mov	x0, #0x3                ; =3
1005e3390: f80b83e0    	stur	x0, [sp, #0xb8]
1005e3394: 14001479    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e3398: f940a7e5    	ldr	x5, [sp, #0x148]
1005e339c: f86478a5    	ldr	x5, [x5, x4, lsl #3]
1005e33a0: 52842cc0    	mov	w0, #0x2166             ; =8550
1005e33a4: 72a00020    	movk	w0, #0x1, lsl #16
1005e33a8: cb000069    	sub	x9, x3, x0
1005e33ac: d2800003    	mov	x3, #0x0                ; =0
1005e33b0: f84603e6    	ldur	x6, [sp, #0x60]
1005e33b4: f84583e7    	ldur	x7, [sp, #0x58]
1005e33b8: f84103ef    	ldur	x15, [sp, #0x10]
1005e33bc: f84683e0    	ldur	x0, [sp, #0x68]
1005e33c0: f80283e0    	stur	x0, [sp, #0x28]
1005e33c4: f84703e0    	ldur	x0, [sp, #0x70]
1005e33c8: f80303e0    	stur	x0, [sp, #0x30]
1005e33cc: 529b83c0    	mov	w0, #0xdc1e             ; =56350
1005e33d0: 72a00040    	movk	w0, #0x2, lsl #16
1005e33d4: eb00013f    	cmp	x9, x0
1005e33d8: 540021e2    	b.hs	0x1005e3814 <_mech_canonical_program_entry_v1_numeric_1282+0x2194>
1005e33dc: d2800001    	mov	x1, #0x0                ; =0
1005e33e0: f9000e61    	str	x1, [x19, #0x18]
1005e33e4: d2e20000    	mov	x0, #0x1000000000000000 ; =1152921504606846976
1005e33e8: f9001260    	str	x0, [x19, #0x20]
1005e33ec: d2800020    	mov	x0, #0x1                ; =1
1005e33f0: f9001a60    	str	x0, [x19, #0x30]
1005e33f4: b200c3e2    	mov	x2, #0x101010101010101  ; =72340172838076673
1005e33f8: f9001e62    	str	x2, [x19, #0x38]
1005e33fc: d2800054    	mov	x20, #0x2               ; =2
1005e3400: f9002274    	str	x20, [x19, #0x40]
1005e3404: d2800062    	mov	x2, #0x3                ; =3
1005e3408: f9002662    	str	x2, [x19, #0x48]
1005e340c: d2800082    	mov	x2, #0x4                ; =4
1005e3410: f9002a62    	str	x2, [x19, #0x50]
1005e3414: b200cfe2    	mov	x2, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e3418: f9003e62    	str	x2, [x19, #0x78]
1005e341c: b200e7e2    	mov	x2, #0x3333333333333333 ; =3689348814741910323
1005e3420: f9004662    	str	x2, [x19, #0x88]
1005e3424: d2800702    	mov	x2, #0x38               ; =56
1005e3428: f9004a62    	str	x2, [x19, #0x90]
1005e342c: d2800742    	mov	x2, #0x3a               ; =58
1005e3430: f9004e62    	str	x2, [x19, #0x98]
1005e3434: b200f3e2    	mov	x2, #0x5555555555555555 ; =6148914691236517205
1005e3438: f9005a62    	str	x2, [x19, #0xb0]
1005e343c: 92ff8002    	mov	x2, #0x3ffffffffffffff  ; =288230376151711743
1005e3440: f9005e62    	str	x2, [x19, #0xb8]
1005e3444: f900c661    	str	x1, [x19, #0x188]
1005e3448: f900ca60    	str	x0, [x19, #0x190]
1005e344c: f90bd276    	str	x22, [x19, #0x17a0]
1005e3450: f90bd677    	str	x23, [x19, #0x17a8]
1005e3454: f84e03f8    	ldur	x24, [sp, #0xe0]
1005e3458: 53001f04    	uxtb	w4, w24
1005e345c: f90bde64    	str	x4, [x19, #0x17b8]
1005e3460: f84183e1    	ldur	x1, [sp, #0x18]
1005e3464: f90c2e61    	str	x1, [x19, #0x1858]
1005e3468: aa1a03e1    	mov	x1, x26
1005e346c: f90c3261    	str	x1, [x19, #0x1860]
1005e3470: f90c3676    	str	x22, [x19, #0x1868]
1005e3474: f84d03ee    	ldur	x14, [sp, #0xd0]
1005e3478: f90c3a6e    	str	x14, [x19, #0x1870]
1005e347c: f84c83e1    	ldur	x1, [sp, #0xc8]
1005e3480: 53001c2e    	uxtb	w14, w1
1005e3484: f90c426e    	str	x14, [x19, #0x1880]
1005e3488: f926326a    	str	x10, [x19, #0x4c60]
1005e348c: f9263669    	str	x9, [x19, #0x4c68]
1005e3490: f84803e4    	ldur	x4, [sp, #0x80]
1005e3494: f9263a64    	str	x4, [x19, #0x4c70]
1005e3498: f927ba76    	str	x22, [x19, #0x4f70]
1005e349c: f927be77    	str	x23, [x19, #0x4f78]
1005e34a0: f84183ea    	ldur	x10, [sp, #0x18]
1005e34a4: f928626a    	str	x10, [x19, #0x50c0]
1005e34a8: aa1a03ee    	mov	x14, x26
1005e34ac: f928666e    	str	x14, [x19, #0x50c8]
1005e34b0: f9286a76    	str	x22, [x19, #0x50d0]
1005e34b4: f84d03e1    	ldur	x1, [sp, #0xd0]
1005e34b8: f9286e61    	str	x1, [x19, #0x50d8]
1005e34bc: f84103f9    	ldur	x25, [sp, #0x10]
1005e34c0: f9287279    	str	x25, [x19, #0x50e0]
1005e34c4: f84583f8    	ldur	x24, [sp, #0x58]
1005e34c8: f9287678    	str	x24, [x19, #0x50e8]
1005e34cc: f84603e1    	ldur	x1, [sp, #0x60]
1005e34d0: f9287a61    	str	x1, [x19, #0x50f0]
1005e34d4: f84683f9    	ldur	x25, [sp, #0x68]
1005e34d8: f9287e79    	str	x25, [x19, #0x50f8]
1005e34dc: f84703fa    	ldur	x26, [sp, #0x70]
1005e34e0: f928827a    	str	x26, [x19, #0x5100]
1005e34e4: f84103f9    	ldur	x25, [sp, #0x10]
1005e34e8: f928be79    	str	x25, [x19, #0x5178]
1005e34ec: f928c278    	str	x24, [x19, #0x5180]
1005e34f0: f84603e1    	ldur	x1, [sp, #0x60]
1005e34f4: f928c661    	str	x1, [x19, #0x5188]
1005e34f8: f84683f9    	ldur	x25, [sp, #0x68]
1005e34fc: f928ca79    	str	x25, [x19, #0x5190]
1005e3500: f928ce7a    	str	x26, [x19, #0x5198]
1005e3504: f929567b    	str	x27, [x19, #0x52a8]
1005e3508: f9295a65    	str	x5, [x19, #0x52b0]
1005e350c: f9295e76    	str	x22, [x19, #0x52b8]
1005e3510: f84d03e1    	ldur	x1, [sp, #0xd0]
1005e3514: f9296261    	str	x1, [x19, #0x52c0]
1005e3518: f929666f    	str	x15, [x19, #0x52c8]
1005e351c: aa0703ef    	mov	x15, x7
1005e3520: f9296a6f    	str	x15, [x19, #0x52d0]
1005e3524: aa0603f9    	mov	x25, x6
1005e3528: f9296e79    	str	x25, [x19, #0x52d8]
1005e352c: f84283f9    	ldur	x25, [sp, #0x28]
1005e3530: f9297279    	str	x25, [x19, #0x52e0]
1005e3534: f84303ef    	ldur	x15, [sp, #0x30]
1005e3538: f929766f    	str	x15, [x19, #0x52e8]
1005e353c: f84503e1    	ldur	x1, [sp, #0x50]
1005e3540: f92d1261    	str	x1, [x19, #0x5a20]
1005e3544: 91000501    	add	x1, x8, #0x1
1005e3548: f92dda61    	str	x1, [x19, #0x5bb0]
1005e354c: f84883fa    	ldur	x26, [sp, #0x88]
1005e3550: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e3554: f84903e6    	ldur	x6, [sp, #0x90]
1005e3558: f92de266    	str	x6, [x19, #0x5bc0]
1005e355c: f84783e4    	ldur	x4, [sp, #0x78]
1005e3560: cb090082    	sub	x2, x4, x9
1005e3564: 52990fc4    	mov	w4, #0xc87e             ; =51326
1005e3568: 72a00024    	movk	w4, #0x1, lsl #16
1005e356c: 9b048821    	msub	x1, x1, x4, x2
1005e3570: f92de661    	str	x1, [x19, #0x5bc8]
1005e3574: f92dea60    	str	x0, [x19, #0x5bd0]
1005e3578: f84203f8    	ldur	x24, [sp, #0x20]
1005e357c: f92dee78    	str	x24, [x19, #0x5bd8]
1005e3580: f92df660    	str	x0, [x19, #0x5be8]
1005e3584: f92dfa63    	str	x3, [x19, #0x5bf0]
1005e3588: f92e026c    	str	x12, [x19, #0x5c00]
1005e358c: f92e066b    	str	x11, [x19, #0x5c08]
1005e3590: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e3594: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e3598: f92e126d    	str	x13, [x19, #0x5c20]
1005e359c: f9663260    	ldr	x0, [x19, #0x4c60]
1005e35a0: f100001f    	cmp	x0, #0x0
1005e35a4: 54001240    	b.eq	0x1005e37ec <_mech_canonical_program_entry_v1_numeric_1282+0x216c>
1005e35a8: f9663663    	ldr	x3, [x19, #0x4c68]
1005e35ac: f9663a64    	ldr	x4, [x19, #0x4c70]
1005e35b0: d2800000    	mov	x0, #0x0                ; =0
1005e35b4: f9263260    	str	x0, [x19, #0x4c60]
1005e35b8: d2800060    	mov	x0, #0x3                ; =3
1005e35bc: f940c3ef    	ldr	x15, [sp, #0x180]
1005e35c0: f80b83e0    	stur	x0, [sp, #0xb8]
1005e35c4: f10669ff    	cmp	x15, #0x19a
1005e35c8: 54027d83    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e35cc: f967ba60    	ldr	x0, [x19, #0x4f70]
1005e35d0: f940c7e9    	ldr	x9, [sp, #0x188]
1005e35d4: f9000920    	str	x0, [x9, #0x10]
1005e35d8: f967be61    	ldr	x1, [x19, #0x4f78]
1005e35dc: f940c7ec    	ldr	x12, [sp, #0x188]
1005e35e0: f9000d81    	str	x1, [x12, #0x18]
1005e35e4: f96d1262    	ldr	x2, [x19, #0x5a20]
1005e35e8: f940c7ef    	ldr	x15, [sp, #0x188]
1005e35ec: f90561e2    	str	x2, [x15, #0xac0]
1005e35f0: f968be62    	ldr	x2, [x19, #0x5178]
1005e35f4: f940c7e5    	ldr	x5, [sp, #0x188]
1005e35f8: f9010ca2    	str	x2, [x5, #0x218]
1005e35fc: f968c262    	ldr	x2, [x19, #0x5180]
1005e3600: f90110a2    	str	x2, [x5, #0x220]
1005e3604: f968c662    	ldr	x2, [x19, #0x5188]
1005e3608: f90114a2    	str	x2, [x5, #0x228]
1005e360c: f968ca62    	ldr	x2, [x19, #0x5190]
1005e3610: f90118a2    	str	x2, [x5, #0x230]
1005e3614: f968ce62    	ldr	x2, [x19, #0x5198]
1005e3618: f9011ca2    	str	x2, [x5, #0x238]
1005e361c: f940c7e2    	ldr	x2, [sp, #0x188]
1005e3620: f9000840    	str	x0, [x2, #0x10]
1005e3624: f940c7e0    	ldr	x0, [sp, #0x188]
1005e3628: f9000c01    	str	x1, [x0, #0x18]
1005e362c: f9686265    	ldr	x5, [x19, #0x50c0]
1005e3630: f900b005    	str	x5, [x0, #0x160]
1005e3634: f9686666    	ldr	x6, [x19, #0x50c8]
1005e3638: f900b406    	str	x6, [x0, #0x168]
1005e363c: f9686a67    	ldr	x7, [x19, #0x50d0]
1005e3640: f900b807    	str	x7, [x0, #0x170]
1005e3644: f9686e68    	ldr	x8, [x19, #0x50d8]
1005e3648: f900bc08    	str	x8, [x0, #0x178]
1005e364c: f9687269    	ldr	x9, [x19, #0x50e0]
1005e3650: f900c009    	str	x9, [x0, #0x180]
1005e3654: f968766a    	ldr	x10, [x19, #0x50e8]
1005e3658: f900c40a    	str	x10, [x0, #0x188]
1005e365c: f9687a6b    	ldr	x11, [x19, #0x50f0]
1005e3660: f900c80b    	str	x11, [x0, #0x190]
1005e3664: f9687e6c    	ldr	x12, [x19, #0x50f8]
1005e3668: f900cc0c    	str	x12, [x0, #0x198]
1005e366c: f968826d    	ldr	x13, [x19, #0x5100]
1005e3670: f900d00d    	str	x13, [x0, #0x1a0]
1005e3674: f969566e    	ldr	x14, [x19, #0x52a8]
1005e3678: f940c7e1    	ldr	x1, [sp, #0x188]
1005e367c: f901a42e    	str	x14, [x1, #0x348]
1005e3680: f9695a6f    	ldr	x15, [x19, #0x52b0]
1005e3684: f940c7e5    	ldr	x5, [sp, #0x188]
1005e3688: f901a8af    	str	x15, [x5, #0x350]
1005e368c: f9695e60    	ldr	x0, [x19, #0x52b8]
1005e3690: f940c7e7    	ldr	x7, [sp, #0x188]
1005e3694: f901ace0    	str	x0, [x7, #0x358]
1005e3698: f9696260    	ldr	x0, [x19, #0x52c0]
1005e369c: f940c7ea    	ldr	x10, [sp, #0x188]
1005e36a0: f901b140    	str	x0, [x10, #0x360]
1005e36a4: f9696660    	ldr	x0, [x19, #0x52c8]
1005e36a8: f940c7ed    	ldr	x13, [sp, #0x188]
1005e36ac: f901b5a0    	str	x0, [x13, #0x368]
1005e36b0: f9696a60    	ldr	x0, [x19, #0x52d0]
1005e36b4: f901b820    	str	x0, [x1, #0x370]
1005e36b8: f9696e60    	ldr	x0, [x19, #0x52d8]
1005e36bc: f901bc20    	str	x0, [x1, #0x378]
1005e36c0: f9697260    	ldr	x0, [x19, #0x52e0]
1005e36c4: f901c020    	str	x0, [x1, #0x380]
1005e36c8: f9697660    	ldr	x0, [x19, #0x52e8]
1005e36cc: f901c420    	str	x0, [x1, #0x388]
1005e36d0: f96aee60    	ldr	x0, [x19, #0x55d8]
1005e36d4: f9033c20    	str	x0, [x1, #0x678]
1005e36d8: f96af260    	ldr	x0, [x19, #0x55e0]
1005e36dc: f9034020    	str	x0, [x1, #0x680]
1005e36e0: f96af660    	ldr	x0, [x19, #0x55e8]
1005e36e4: f9034420    	str	x0, [x1, #0x688]
1005e36e8: f96afa60    	ldr	x0, [x19, #0x55f0]
1005e36ec: f9034820    	str	x0, [x1, #0x690]
1005e36f0: f96afe60    	ldr	x0, [x19, #0x55f8]
1005e36f4: f9034c20    	str	x0, [x1, #0x698]
1005e36f8: f96b0260    	ldr	x0, [x19, #0x5600]
1005e36fc: f9035020    	str	x0, [x1, #0x6a0]
1005e3700: f96b0660    	ldr	x0, [x19, #0x5608]
1005e3704: f9035420    	str	x0, [x1, #0x6a8]
1005e3708: f96b0a60    	ldr	x0, [x19, #0x5610]
1005e370c: f9035820    	str	x0, [x1, #0x6b0]
1005e3710: f96bd260    	ldr	x0, [x19, #0x57a0]
1005e3714: f9042020    	str	x0, [x1, #0x840]
1005e3718: f96bd660    	ldr	x0, [x19, #0x57a8]
1005e371c: f9042420    	str	x0, [x1, #0x848]
1005e3720: f96bda60    	ldr	x0, [x19, #0x57b0]
1005e3724: f9042820    	str	x0, [x1, #0x850]
1005e3728: f96bde60    	ldr	x0, [x19, #0x57b8]
1005e372c: f9042c20    	str	x0, [x1, #0x858]
1005e3730: f96be260    	ldr	x0, [x19, #0x57c0]
1005e3734: f9043020    	str	x0, [x1, #0x860]
1005e3738: f96be660    	ldr	x0, [x19, #0x57c8]
1005e373c: f90434a0    	str	x0, [x5, #0x868]
1005e3740: f96bea60    	ldr	x0, [x19, #0x57d0]
1005e3744: f90438e0    	str	x0, [x7, #0x870]
1005e3748: f96bee60    	ldr	x0, [x19, #0x57d8]
1005e374c: f9043d40    	str	x0, [x10, #0x878]
1005e3750: f96dda60    	ldr	x0, [x19, #0x5bb0]
1005e3754: f90629a0    	str	x0, [x13, #0xc50]
1005e3758: f96dde60    	ldr	x0, [x19, #0x5bb8]
1005e375c: f9062c20    	str	x0, [x1, #0xc58]
1005e3760: f96de260    	ldr	x0, [x19, #0x5bc0]
1005e3764: f9063020    	str	x0, [x1, #0xc60]
1005e3768: f96de660    	ldr	x0, [x19, #0x5bc8]
1005e376c: f9063420    	str	x0, [x1, #0xc68]
1005e3770: f96dea60    	ldr	x0, [x19, #0x5bd0]
1005e3774: f9063820    	str	x0, [x1, #0xc70]
1005e3778: f96dee60    	ldr	x0, [x19, #0x5bd8]
1005e377c: f9063c20    	str	x0, [x1, #0xc78]
1005e3780: d2800000    	mov	x0, #0x0                ; =0
1005e3784: f9064020    	str	x0, [x1, #0xc80]
1005e3788: f96df661    	ldr	x1, [x19, #0x5be8]
1005e378c: f9064441    	str	x1, [x2, #0xc88]
1005e3790: f96dfa61    	ldr	x1, [x19, #0x5bf0]
1005e3794: f9064841    	str	x1, [x2, #0xc90]
1005e3798: f940c7e1    	ldr	x1, [sp, #0x188]
1005e379c: f9064c20    	str	x0, [x1, #0xc98]
1005e37a0: f96e0261    	ldr	x1, [x19, #0x5c00]
1005e37a4: f9065041    	str	x1, [x2, #0xca0]
1005e37a8: f96e0661    	ldr	x1, [x19, #0x5c08]
1005e37ac: f9065441    	str	x1, [x2, #0xca8]
1005e37b0: f940c7e1    	ldr	x1, [sp, #0x188]
1005e37b4: f9065820    	str	x0, [x1, #0xcb0]
1005e37b8: f96e0e60    	ldr	x0, [x19, #0x5c18]
1005e37bc: f9065c20    	str	x0, [x1, #0xcb8]
1005e37c0: f96e1260    	ldr	x0, [x19, #0x5c20]
1005e37c4: f9066020    	str	x0, [x1, #0xcc0]
1005e37c8: d280a7a1    	mov	x1, #0x53d              ; =1341
1005e37cc: 92800102    	mov	x2, #-0x9               ; =-9
1005e37d0: d2800025    	mov	x5, #0x1                ; =1
1005e37d4: f84083e0    	ldur	x0, [sp, #0x8]
1005e37d8: f940cbe6    	ldr	x6, [sp, #0x190]
1005e37dc: f940cff5    	ldr	x21, [sp, #0x198]
1005e37e0: d63f02a0    	blr	x21
1005e37e4: f100001f    	cmp	x0, #0x0
1005e37e8: 5401b361    	b.ne	0x1005e6e54 <_mech_canonical_program_entry_v1_numeric_1282+0x57d4>
1005e37ec: d2800000    	mov	x0, #0x0                ; =0
1005e37f0: d2800061    	mov	x1, #0x3                ; =3
1005e37f4: 9106c3ff    	add	sp, sp, #0x1b0
1005e37f8: a8c153f3    	ldp	x19, x20, [sp], #0x10
1005e37fc: a8c15bf5    	ldp	x21, x22, [sp], #0x10
1005e3800: a8c163f7    	ldp	x23, x24, [sp], #0x10
1005e3804: a8c16bf9    	ldp	x25, x26, [sp], #0x10
1005e3808: a8c173fb    	ldp	x27, x28, [sp], #0x10
1005e380c: a8c17bfd    	ldp	x29, x30, [sp], #0x10
1005e3810: d65f0fff    	retab
1005e3814: aa0603f9    	mov	x25, x6
1005e3818: aa0f03e2    	mov	x2, x15
1005e381c: aa0703ef    	mov	x15, x7
1005e3820: eb05037f    	cmp	x27, x5
1005e3824: 9a9f27e7    	cset	x7, lo
1005e3828: eb05037f    	cmp	x27, x5
1005e382c: 54000143    	b.lo	0x1005e3854 <_mech_canonical_program_entry_v1_numeric_1282+0x21d4>
1005e3830: f84303e0    	ldur	x0, [sp, #0x30]
1005e3834: f84283e1    	ldur	x1, [sp, #0x28]
1005e3838: aa1b03e4    	mov	x4, x27
1005e383c: f84303e6    	ldur	x6, [sp, #0x30]
1005e3840: f84283e7    	ldur	x7, [sp, #0x28]
1005e3844: aa1903f4    	mov	x20, x25
1005e3848: aa0f03f8    	mov	x24, x15
1005e384c: f80383e2    	stur	x2, [sp, #0x38]
1005e3850: 140001a6    	b	0x1005e3ee8 <_mech_canonical_program_entry_v1_numeric_1282+0x2868>
1005e3854: f9409be1    	ldr	x1, [sp, #0x130]
1005e3858: eb01037f    	cmp	x27, x1
1005e385c: 54001403    	b.lo	0x1005e3adc <_mech_canonical_program_entry_v1_numeric_1282+0x245c>
1005e3860: 14000d7f    	b	0x1005e6e5c <_mech_canonical_program_entry_v1_numeric_1282+0x57dc>
1005e3864: f9663663    	ldr	x3, [x19, #0x4c68]
1005e3868: f9663a64    	ldr	x4, [x19, #0x4c70]
1005e386c: d2800000    	mov	x0, #0x0                ; =0
1005e3870: f9263260    	str	x0, [x19, #0x4c60]
1005e3874: d2800060    	mov	x0, #0x3                ; =3
1005e3878: f940c3ef    	ldr	x15, [sp, #0x180]
1005e387c: f80b83e0    	stur	x0, [sp, #0xb8]
1005e3880: f10669ff    	cmp	x15, #0x19a
1005e3884: 540267a3    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e3888: f967ba60    	ldr	x0, [x19, #0x4f70]
1005e388c: f940c7e5    	ldr	x5, [sp, #0x188]
1005e3890: f90008a0    	str	x0, [x5, #0x10]
1005e3894: f967be61    	ldr	x1, [x19, #0x4f78]
1005e3898: f940c7e7    	ldr	x7, [sp, #0x188]
1005e389c: f9000ce1    	str	x1, [x7, #0x18]
1005e38a0: f96d1262    	ldr	x2, [x19, #0x5a20]
1005e38a4: f940c7ea    	ldr	x10, [sp, #0x188]
1005e38a8: f9056142    	str	x2, [x10, #0xac0]
1005e38ac: f940c7ec    	ldr	x12, [sp, #0x188]
1005e38b0: f9000980    	str	x0, [x12, #0x10]
1005e38b4: f940c7ee    	ldr	x14, [sp, #0x188]
1005e38b8: f9000dc1    	str	x1, [x14, #0x18]
1005e38bc: f9686260    	ldr	x0, [x19, #0x50c0]
1005e38c0: f940c7e1    	ldr	x1, [sp, #0x188]
1005e38c4: f900b020    	str	x0, [x1, #0x160]
1005e38c8: f9686660    	ldr	x0, [x19, #0x50c8]
1005e38cc: f900b420    	str	x0, [x1, #0x168]
1005e38d0: f9686a60    	ldr	x0, [x19, #0x50d0]
1005e38d4: f900b820    	str	x0, [x1, #0x170]
1005e38d8: f9686e60    	ldr	x0, [x19, #0x50d8]
1005e38dc: f900bc20    	str	x0, [x1, #0x178]
1005e38e0: f9687260    	ldr	x0, [x19, #0x50e0]
1005e38e4: f900c020    	str	x0, [x1, #0x180]
1005e38e8: f9687660    	ldr	x0, [x19, #0x50e8]
1005e38ec: f900c420    	str	x0, [x1, #0x188]
1005e38f0: f9687a60    	ldr	x0, [x19, #0x50f0]
1005e38f4: f900c820    	str	x0, [x1, #0x190]
1005e38f8: f9687e60    	ldr	x0, [x19, #0x50f8]
1005e38fc: f900cc20    	str	x0, [x1, #0x198]
1005e3900: f9688260    	ldr	x0, [x19, #0x5100]
1005e3904: f900d020    	str	x0, [x1, #0x1a0]
1005e3908: f9695660    	ldr	x0, [x19, #0x52a8]
1005e390c: f901a420    	str	x0, [x1, #0x348]
1005e3910: f9695a60    	ldr	x0, [x19, #0x52b0]
1005e3914: f901a820    	str	x0, [x1, #0x350]
1005e3918: f9695e60    	ldr	x0, [x19, #0x52b8]
1005e391c: f901ac20    	str	x0, [x1, #0x358]
1005e3920: f9696260    	ldr	x0, [x19, #0x52c0]
1005e3924: f901b020    	str	x0, [x1, #0x360]
1005e3928: f9696660    	ldr	x0, [x19, #0x52c8]
1005e392c: f901b420    	str	x0, [x1, #0x368]
1005e3930: f9696a60    	ldr	x0, [x19, #0x52d0]
1005e3934: f901b820    	str	x0, [x1, #0x370]
1005e3938: f9696e60    	ldr	x0, [x19, #0x52d8]
1005e393c: f901bc20    	str	x0, [x1, #0x378]
1005e3940: f9697260    	ldr	x0, [x19, #0x52e0]
1005e3944: f940c7e2    	ldr	x2, [sp, #0x188]
1005e3948: f901c040    	str	x0, [x2, #0x380]
1005e394c: f9697660    	ldr	x0, [x19, #0x52e8]
1005e3950: f901c4a0    	str	x0, [x5, #0x388]
1005e3954: f96aee60    	ldr	x0, [x19, #0x55d8]
1005e3958: f940c7e8    	ldr	x8, [sp, #0x188]
1005e395c: f9033d00    	str	x0, [x8, #0x678]
1005e3960: f96af260    	ldr	x0, [x19, #0x55e0]
1005e3964: f940c7eb    	ldr	x11, [sp, #0x188]
1005e3968: f9034160    	str	x0, [x11, #0x680]
1005e396c: f96af660    	ldr	x0, [x19, #0x55e8]
1005e3970: f90345c0    	str	x0, [x14, #0x688]
1005e3974: f96afa60    	ldr	x0, [x19, #0x55f0]
1005e3978: f9034820    	str	x0, [x1, #0x690]
1005e397c: f96afe60    	ldr	x0, [x19, #0x55f8]
1005e3980: f9034c20    	str	x0, [x1, #0x698]
1005e3984: f96b0260    	ldr	x0, [x19, #0x5600]
1005e3988: f9035020    	str	x0, [x1, #0x6a0]
1005e398c: f96b0660    	ldr	x0, [x19, #0x5608]
1005e3990: f9035420    	str	x0, [x1, #0x6a8]
1005e3994: f96b0a60    	ldr	x0, [x19, #0x5610]
1005e3998: f9035820    	str	x0, [x1, #0x6b0]
1005e399c: f96bd260    	ldr	x0, [x19, #0x57a0]
1005e39a0: f9042020    	str	x0, [x1, #0x840]
1005e39a4: f96bd660    	ldr	x0, [x19, #0x57a8]
1005e39a8: f9042420    	str	x0, [x1, #0x848]
1005e39ac: f96bda60    	ldr	x0, [x19, #0x57b0]
1005e39b0: f9042820    	str	x0, [x1, #0x850]
1005e39b4: f96bde60    	ldr	x0, [x19, #0x57b8]
1005e39b8: f9042c20    	str	x0, [x1, #0x858]
1005e39bc: f96be260    	ldr	x0, [x19, #0x57c0]
1005e39c0: f9043020    	str	x0, [x1, #0x860]
1005e39c4: f96be660    	ldr	x0, [x19, #0x57c8]
1005e39c8: f9043420    	str	x0, [x1, #0x868]
1005e39cc: f96bea61    	ldr	x1, [x19, #0x57d0]
1005e39d0: f940c7e0    	ldr	x0, [sp, #0x188]
1005e39d4: f9043801    	str	x1, [x0, #0x870]
1005e39d8: f96bee62    	ldr	x2, [x19, #0x57d8]
1005e39dc: f9043c02    	str	x2, [x0, #0x878]
1005e39e0: f96dda65    	ldr	x5, [x19, #0x5bb0]
1005e39e4: f9062805    	str	x5, [x0, #0xc50]
1005e39e8: f96dde65    	ldr	x5, [x19, #0x5bb8]
1005e39ec: f9062c05    	str	x5, [x0, #0xc58]
1005e39f0: f96de265    	ldr	x5, [x19, #0x5bc0]
1005e39f4: f9063005    	str	x5, [x0, #0xc60]
1005e39f8: f96de666    	ldr	x6, [x19, #0x5bc8]
1005e39fc: f940c7e2    	ldr	x2, [sp, #0x188]
1005e3a00: f9063446    	str	x6, [x2, #0xc68]
1005e3a04: f96dea67    	ldr	x7, [x19, #0x5bd0]
1005e3a08: f940c7e5    	ldr	x5, [sp, #0x188]
1005e3a0c: f90638a7    	str	x7, [x5, #0xc70]
1005e3a10: f96dee68    	ldr	x8, [x19, #0x5bd8]
1005e3a14: f940c7e9    	ldr	x9, [sp, #0x188]
1005e3a18: f9063d28    	str	x8, [x9, #0xc78]
1005e3a1c: d2800009    	mov	x9, #0x0                ; =0
1005e3a20: f9064169    	str	x9, [x11, #0xc80]
1005e3a24: f96df66a    	ldr	x10, [x19, #0x5be8]
1005e3a28: f90645ca    	str	x10, [x14, #0xc88]
1005e3a2c: f96dfa6b    	ldr	x11, [x19, #0x5bf0]
1005e3a30: f906480b    	str	x11, [x0, #0xc90]
1005e3a34: f9064c09    	str	x9, [x0, #0xc98]
1005e3a38: f96e026d    	ldr	x13, [x19, #0x5c00]
1005e3a3c: f906500d    	str	x13, [x0, #0xca0]
1005e3a40: f96e066e    	ldr	x14, [x19, #0x5c08]
1005e3a44: f906540e    	str	x14, [x0, #0xca8]
1005e3a48: f9065809    	str	x9, [x0, #0xcb0]
1005e3a4c: f96e0e60    	ldr	x0, [x19, #0x5c18]
1005e3a50: f940c7e1    	ldr	x1, [sp, #0x188]
1005e3a54: f9065c20    	str	x0, [x1, #0xcb8]
1005e3a58: f96e1260    	ldr	x0, [x19, #0x5c20]
1005e3a5c: f9066020    	str	x0, [x1, #0xcc0]
1005e3a60: d280a9c1    	mov	x1, #0x54e              ; =1358
1005e3a64: 92800102    	mov	x2, #-0x9               ; =-9
1005e3a68: f940cff5    	ldr	x21, [sp, #0x198]
1005e3a6c: f84083e0    	ldur	x0, [sp, #0x8]
1005e3a70: aa1803e5    	mov	x5, x24
1005e3a74: f940cbe6    	ldr	x6, [sp, #0x190]
1005e3a78: d63f02a0    	blr	x21
1005e3a7c: f100001f    	cmp	x0, #0x0
1005e3a80: 5401ade1    	b.ne	0x1005e703c <_mech_canonical_program_entry_v1_numeric_1282+0x59bc>
1005e3a84: d2800060    	mov	x0, #0x3                ; =3
1005e3a88: f940c3ef    	ldr	x15, [sp, #0x180]
1005e3a8c: f80b83e0    	stur	x0, [sp, #0xb8]
1005e3a90: f10009ff    	cmp	x15, #0x2
1005e3a94: 54025723    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e3a98: d2800005    	mov	x5, #0x0                ; =0
1005e3a9c: f940c7e3    	ldr	x3, [sp, #0x188]
1005e3aa0: f9000065    	str	x5, [x3]
1005e3aa4: f94caa60    	ldr	x0, [x19, #0x1950]
1005e3aa8: f9000460    	str	x0, [x3, #0x8]
1005e3aac: d280a9c1    	mov	x1, #0x54e              ; =1358
1005e3ab0: f84083e0    	ldur	x0, [sp, #0x8]
1005e3ab4: f940cbe6    	ldr	x6, [sp, #0x190]
1005e3ab8: f940cff5    	ldr	x21, [sp, #0x198]
1005e3abc: aa1803e4    	mov	x4, x24
1005e3ac0: aa0503e2    	mov	x2, x5
1005e3ac4: d63f02a0    	blr	x21
1005e3ac8: f100001f    	cmp	x0, #0x0
1005e3acc: 5401abc1    	b.ne	0x1005e7044 <_mech_canonical_program_entry_v1_numeric_1282+0x59c4>
1005e3ad0: d2800060    	mov	x0, #0x3                ; =3
1005e3ad4: f80b83e0    	stur	x0, [sp, #0xb8]
1005e3ad8: 140012a8    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e3adc: f84303e0    	ldur	x0, [sp, #0x30]
1005e3ae0: f84283e1    	ldur	x1, [sp, #0x28]
1005e3ae4: f9409fe4    	ldr	x4, [sp, #0x138]
1005e3ae8: f87b7898    	ldr	x24, [x4, x27, lsl #3]
1005e3aec: eb16031f    	cmp	x24, x22
1005e3af0: 54000101    	b.ne	0x1005e3b10 <_mech_canonical_program_entry_v1_numeric_1282+0x2490>
1005e3af4: aa1b03e4    	mov	x4, x27
1005e3af8: aa0003e6    	mov	x6, x0
1005e3afc: aa0103e7    	mov	x7, x1
1005e3b00: aa1903f4    	mov	x20, x25
1005e3b04: aa0f03f8    	mov	x24, x15
1005e3b08: f80383e2    	stur	x2, [sp, #0x38]
1005e3b0c: 140000e5    	b	0x1005e3ea0 <_mech_canonical_program_entry_v1_numeric_1282+0x2820>
1005e3b10: 91000704    	add	x4, x24, #0x1
1005e3b14: eb18009f    	cmp	x4, x24
1005e3b18: 5401a9a3    	b.lo	0x1005e704c <_mech_canonical_program_entry_v1_numeric_1282+0x59cc>
1005e3b1c: f940b3e6    	ldr	x6, [sp, #0x160]
1005e3b20: eb06031f    	cmp	x24, x6
1005e3b24: 54001463    	b.lo	0x1005e3db0 <_mech_canonical_program_entry_v1_numeric_1282+0x2730>
1005e3b28: 14000da2    	b	0x1005e71b0 <_mech_canonical_program_entry_v1_numeric_1282+0x5b30>
1005e3b2c: f9663663    	ldr	x3, [x19, #0x4c68]
1005e3b30: f9663a64    	ldr	x4, [x19, #0x4c70]
1005e3b34: d2800000    	mov	x0, #0x0                ; =0
1005e3b38: f9263260    	str	x0, [x19, #0x4c60]
1005e3b3c: d2800060    	mov	x0, #0x3                ; =3
1005e3b40: f940c3ef    	ldr	x15, [sp, #0x180]
1005e3b44: f80b83e0    	stur	x0, [sp, #0xb8]
1005e3b48: f10669ff    	cmp	x15, #0x19a
1005e3b4c: 54025163    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e3b50: f967ba60    	ldr	x0, [x19, #0x4f70]
1005e3b54: f940c7e1    	ldr	x1, [sp, #0x188]
1005e3b58: f9000820    	str	x0, [x1, #0x10]
1005e3b5c: f967be61    	ldr	x1, [x19, #0x4f78]
1005e3b60: f940c7e5    	ldr	x5, [sp, #0x188]
1005e3b64: f9000ca1    	str	x1, [x5, #0x18]
1005e3b68: f96d1262    	ldr	x2, [x19, #0x5a20]
1005e3b6c: f940c7e6    	ldr	x6, [sp, #0x188]
1005e3b70: f90560c2    	str	x2, [x6, #0xac0]
1005e3b74: f940c7e8    	ldr	x8, [sp, #0x188]
1005e3b78: f9000900    	str	x0, [x8, #0x10]
1005e3b7c: f940c7ea    	ldr	x10, [sp, #0x188]
1005e3b80: f9000d41    	str	x1, [x10, #0x18]
1005e3b84: f9686260    	ldr	x0, [x19, #0x50c0]
1005e3b88: f940c7ed    	ldr	x13, [sp, #0x188]
1005e3b8c: f900b1a0    	str	x0, [x13, #0x160]
1005e3b90: f9686660    	ldr	x0, [x19, #0x50c8]
1005e3b94: f940c7e1    	ldr	x1, [sp, #0x188]
1005e3b98: f900b420    	str	x0, [x1, #0x168]
1005e3b9c: f9686a60    	ldr	x0, [x19, #0x50d0]
1005e3ba0: f900b820    	str	x0, [x1, #0x170]
1005e3ba4: f9686e60    	ldr	x0, [x19, #0x50d8]
1005e3ba8: f900bc20    	str	x0, [x1, #0x178]
1005e3bac: f9687260    	ldr	x0, [x19, #0x50e0]
1005e3bb0: f900c020    	str	x0, [x1, #0x180]
1005e3bb4: f9687660    	ldr	x0, [x19, #0x50e8]
1005e3bb8: f900c420    	str	x0, [x1, #0x188]
1005e3bbc: f9687a60    	ldr	x0, [x19, #0x50f0]
1005e3bc0: f900c820    	str	x0, [x1, #0x190]
1005e3bc4: f9687e60    	ldr	x0, [x19, #0x50f8]
1005e3bc8: f900cc20    	str	x0, [x1, #0x198]
1005e3bcc: f9688260    	ldr	x0, [x19, #0x5100]
1005e3bd0: f900d020    	str	x0, [x1, #0x1a0]
1005e3bd4: f9695660    	ldr	x0, [x19, #0x52a8]
1005e3bd8: f901a420    	str	x0, [x1, #0x348]
1005e3bdc: f9695a60    	ldr	x0, [x19, #0x52b0]
1005e3be0: f901a820    	str	x0, [x1, #0x350]
1005e3be4: f9695e60    	ldr	x0, [x19, #0x52b8]
1005e3be8: f901ac20    	str	x0, [x1, #0x358]
1005e3bec: f9696260    	ldr	x0, [x19, #0x52c0]
1005e3bf0: f901b020    	str	x0, [x1, #0x360]
1005e3bf4: f9696660    	ldr	x0, [x19, #0x52c8]
1005e3bf8: f901b420    	str	x0, [x1, #0x368]
1005e3bfc: f9696a60    	ldr	x0, [x19, #0x52d0]
1005e3c00: f901b820    	str	x0, [x1, #0x370]
1005e3c04: f9696e60    	ldr	x0, [x19, #0x52d8]
1005e3c08: f901bc20    	str	x0, [x1, #0x378]
1005e3c0c: f9697260    	ldr	x0, [x19, #0x52e0]
1005e3c10: f901c020    	str	x0, [x1, #0x380]
1005e3c14: f9697660    	ldr	x0, [x19, #0x52e8]
1005e3c18: f901c420    	str	x0, [x1, #0x388]
1005e3c1c: f96aee60    	ldr	x0, [x19, #0x55d8]
1005e3c20: f9033ca0    	str	x0, [x5, #0x678]
1005e3c24: f96af260    	ldr	x0, [x19, #0x55e0]
1005e3c28: f940c7e7    	ldr	x7, [sp, #0x188]
1005e3c2c: f90340e0    	str	x0, [x7, #0x680]
1005e3c30: f96af661    	ldr	x1, [x19, #0x55e8]
1005e3c34: f9034541    	str	x1, [x10, #0x688]
1005e3c38: f96afa62    	ldr	x2, [x19, #0x55f0]
1005e3c3c: f90349a2    	str	x2, [x13, #0x690]
1005e3c40: f96afe65    	ldr	x5, [x19, #0x55f8]
1005e3c44: f940c7e0    	ldr	x0, [sp, #0x188]
1005e3c48: f9034c05    	str	x5, [x0, #0x698]
1005e3c4c: f96b0265    	ldr	x5, [x19, #0x5600]
1005e3c50: f9035005    	str	x5, [x0, #0x6a0]
1005e3c54: f96b0665    	ldr	x5, [x19, #0x5608]
1005e3c58: f9035405    	str	x5, [x0, #0x6a8]
1005e3c5c: f96b0a66    	ldr	x6, [x19, #0x5610]
1005e3c60: f9035806    	str	x6, [x0, #0x6b0]
1005e3c64: f96bd267    	ldr	x7, [x19, #0x57a0]
1005e3c68: f9042007    	str	x7, [x0, #0x840]
1005e3c6c: f96bd668    	ldr	x8, [x19, #0x57a8]
1005e3c70: f9042408    	str	x8, [x0, #0x848]
1005e3c74: f96bda69    	ldr	x9, [x19, #0x57b0]
1005e3c78: f9042809    	str	x9, [x0, #0x850]
1005e3c7c: f96bde6a    	ldr	x10, [x19, #0x57b8]
1005e3c80: f9042c0a    	str	x10, [x0, #0x858]
1005e3c84: f96be26b    	ldr	x11, [x19, #0x57c0]
1005e3c88: f904300b    	str	x11, [x0, #0x860]
1005e3c8c: f96be66c    	ldr	x12, [x19, #0x57c8]
1005e3c90: f904340c    	str	x12, [x0, #0x868]
1005e3c94: f96bea6d    	ldr	x13, [x19, #0x57d0]
1005e3c98: f904380d    	str	x13, [x0, #0x870]
1005e3c9c: f96bee6e    	ldr	x14, [x19, #0x57d8]
1005e3ca0: f9043c0e    	str	x14, [x0, #0x878]
1005e3ca4: f96dda6f    	ldr	x15, [x19, #0x5bb0]
1005e3ca8: f906280f    	str	x15, [x0, #0xc50]
1005e3cac: f96dde60    	ldr	x0, [x19, #0x5bb8]
1005e3cb0: f940c7e1    	ldr	x1, [sp, #0x188]
1005e3cb4: f9062c20    	str	x0, [x1, #0xc58]
1005e3cb8: f96de260    	ldr	x0, [x19, #0x5bc0]
1005e3cbc: f9063020    	str	x0, [x1, #0xc60]
1005e3cc0: f96de660    	ldr	x0, [x19, #0x5bc8]
1005e3cc4: f9063420    	str	x0, [x1, #0xc68]
1005e3cc8: f96dea60    	ldr	x0, [x19, #0x5bd0]
1005e3ccc: f9063820    	str	x0, [x1, #0xc70]
1005e3cd0: f96dee60    	ldr	x0, [x19, #0x5bd8]
1005e3cd4: f940c7e5    	ldr	x5, [sp, #0x188]
1005e3cd8: f9063ca0    	str	x0, [x5, #0xc78]
1005e3cdc: d2800000    	mov	x0, #0x0                ; =0
1005e3ce0: f940c7e7    	ldr	x7, [sp, #0x188]
1005e3ce4: f90640e0    	str	x0, [x7, #0xc80]
1005e3ce8: f96df661    	ldr	x1, [x19, #0x5be8]
1005e3cec: f940c7ea    	ldr	x10, [sp, #0x188]
1005e3cf0: f9064541    	str	x1, [x10, #0xc88]
1005e3cf4: f96dfa61    	ldr	x1, [x19, #0x5bf0]
1005e3cf8: f940c7ed    	ldr	x13, [sp, #0x188]
1005e3cfc: f90649a1    	str	x1, [x13, #0xc90]
1005e3d00: f940c7ef    	ldr	x15, [sp, #0x188]
1005e3d04: f9064de0    	str	x0, [x15, #0xc98]
1005e3d08: f96e0261    	ldr	x1, [x19, #0x5c00]
1005e3d0c: f940c7e2    	ldr	x2, [sp, #0x188]
1005e3d10: f9065041    	str	x1, [x2, #0xca0]
1005e3d14: f96e0661    	ldr	x1, [x19, #0x5c08]
1005e3d18: f9065441    	str	x1, [x2, #0xca8]
1005e3d1c: f940c7e1    	ldr	x1, [sp, #0x188]
1005e3d20: f9065820    	str	x0, [x1, #0xcb0]
1005e3d24: f96e0e60    	ldr	x0, [x19, #0x5c18]
1005e3d28: f9065c20    	str	x0, [x1, #0xcb8]
1005e3d2c: f96e1260    	ldr	x0, [x19, #0x5c20]
1005e3d30: f9066020    	str	x0, [x1, #0xcc0]
1005e3d34: d280aaa1    	mov	x1, #0x555              ; =1365
1005e3d38: 92800102    	mov	x2, #-0x9               ; =-9
1005e3d3c: f940cff5    	ldr	x21, [sp, #0x198]
1005e3d40: f84083e0    	ldur	x0, [sp, #0x8]
1005e3d44: aa1403e5    	mov	x5, x20
1005e3d48: f940cbe6    	ldr	x6, [sp, #0x190]
1005e3d4c: d63f02a0    	blr	x21
1005e3d50: f100001f    	cmp	x0, #0x0
1005e3d54: 5401b1c1    	b.ne	0x1005e738c <_mech_canonical_program_entry_v1_numeric_1282+0x5d0c>
1005e3d58: d2800060    	mov	x0, #0x3                ; =3
1005e3d5c: f940c3ef    	ldr	x15, [sp, #0x180]
1005e3d60: f80b83e0    	stur	x0, [sp, #0xb8]
1005e3d64: f10009ff    	cmp	x15, #0x2
1005e3d68: 54024083    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e3d6c: d2800005    	mov	x5, #0x0                ; =0
1005e3d70: f940c7e3    	ldr	x3, [sp, #0x188]
1005e3d74: f9000065    	str	x5, [x3]
1005e3d78: f94cba60    	ldr	x0, [x19, #0x1970]
1005e3d7c: f9000460    	str	x0, [x3, #0x8]
1005e3d80: d280aaa1    	mov	x1, #0x555              ; =1365
1005e3d84: f84083e0    	ldur	x0, [sp, #0x8]
1005e3d88: f940cbe6    	ldr	x6, [sp, #0x190]
1005e3d8c: f940cff5    	ldr	x21, [sp, #0x198]
1005e3d90: aa1403e4    	mov	x4, x20
1005e3d94: aa0503e2    	mov	x2, x5
1005e3d98: d63f02a0    	blr	x21
1005e3d9c: f100001f    	cmp	x0, #0x0
1005e3da0: 5401afa1    	b.ne	0x1005e7394 <_mech_canonical_program_entry_v1_numeric_1282+0x5d14>
1005e3da4: d2800060    	mov	x0, #0x3                ; =3
1005e3da8: f80b83e0    	stur	x0, [sp, #0xb8]
1005e3dac: 140011f3    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e3db0: f940b7e4    	ldr	x4, [sp, #0x168]
1005e3db4: f8787884    	ldr	x4, [x4, x24, lsl #3]
1005e3db8: f84d03e6    	ldur	x6, [sp, #0xd0]
1005e3dbc: 8a0400c4    	and	x4, x6, x4
1005e3dc0: 9e670090    	fmov	d16, x4
1005e3dc4: 0e205a10    	cnt.8b	v16, v16
1005e3dc8: 0e31ba10    	addv.8b	b16, v16
1005e3dcc: 0e013e04    	umov.b	w4, v16[0]
1005e3dd0: d240e706    	eor	x6, x24, #0x3ffffffffffffff
1005e3dd4: aa04e8c4    	orr	x4, x6, x4, lsl #58
1005e3dd8: eb00009f    	cmp	x4, x0
1005e3ddc: 9a9f97e6    	cset	x6, hi
1005e3de0: eb02009f    	cmp	x4, x2
1005e3de4: 9a9f07e7    	cset	x7, ne
1005e3de8: 0a0700c6    	and	w6, w6, w7
1005e3dec: eb0f009f    	cmp	x4, x15
1005e3df0: 9a9f07e7    	cset	x7, ne
1005e3df4: 0a0700c6    	and	w6, w6, w7
1005e3df8: eb19009f    	cmp	x4, x25
1005e3dfc: 9a9f07e7    	cset	x7, ne
1005e3e00: 0a0700c6    	and	w6, w6, w7
1005e3e04: eb01009f    	cmp	x4, x1
1005e3e08: 9a9f07e7    	cset	x7, ne
1005e3e0c: 0a0700c6    	and	w6, w6, w7
1005e3e10: 53001cc6    	uxtb	w6, w6
1005e3e14: 370000e6    	tbnz	w6, #0x0, 0x1005e3e30 <_mech_canonical_program_entry_v1_numeric_1282+0x27b0>
1005e3e18: aa0f03e4    	mov	x4, x15
1005e3e1c: aa0203e6    	mov	x6, x2
1005e3e20: aa1903e7    	mov	x7, x25
1005e3e24: aa0103f4    	mov	x20, x1
1005e3e28: aa0003f8    	mov	x24, x0
1005e3e2c: 14000011    	b	0x1005e3e70 <_mech_canonical_program_entry_v1_numeric_1282+0x27f0>
1005e3e30: eb02009f    	cmp	x4, x2
1005e3e34: 9a828086    	csel	x6, x4, x2, hi
1005e3e38: eb02009f    	cmp	x4, x2
1005e3e3c: 9a823087    	csel	x7, x4, x2, lo
1005e3e40: eb0f00ff    	cmp	x7, x15
1005e3e44: 9a8f80e4    	csel	x4, x7, x15, hi
1005e3e48: eb0f00ff    	cmp	x7, x15
1005e3e4c: 9a8f30f4    	csel	x20, x7, x15, lo
1005e3e50: eb19029f    	cmp	x20, x25
1005e3e54: 9a998287    	csel	x7, x20, x25, hi
1005e3e58: eb19029f    	cmp	x20, x25
1005e3e5c: 9a993298    	csel	x24, x20, x25, lo
1005e3e60: eb01031f    	cmp	x24, x1
1005e3e64: 9a818314    	csel	x20, x24, x1, hi
1005e3e68: eb01031f    	cmp	x24, x1
1005e3e6c: 9a813318    	csel	x24, x24, x1, lo
1005e3e70: f80383e2    	stur	x2, [sp, #0x38]
1005e3e74: aa0603e2    	mov	x2, x6
1005e3e78: aa0003e6    	mov	x6, x0
1005e3e7c: f900d3e1    	str	x1, [sp, #0x1a0]
1005e3e80: aa1403e1    	mov	x1, x20
1005e3e84: aa1903f4    	mov	x20, x25
1005e3e88: aa0703f9    	mov	x25, x7
1005e3e8c: f940d3e7    	ldr	x7, [sp, #0x1a0]
1005e3e90: aa1803e0    	mov	x0, x24
1005e3e94: aa0f03f8    	mov	x24, x15
1005e3e98: aa0403ef    	mov	x15, x4
1005e3e9c: aa1b03e4    	mov	x4, x27
1005e3ea0: f900d3f4    	str	x20, [sp, #0x1a0]
1005e3ea4: aa1903f4    	mov	x20, x25
1005e3ea8: f940d3f9    	ldr	x25, [sp, #0x1a0]
1005e3eac: f900d3ef    	str	x15, [sp, #0x1a0]
1005e3eb0: aa1803ef    	mov	x15, x24
1005e3eb4: f940d3f8    	ldr	x24, [sp, #0x1a0]
1005e3eb8: f900d3e2    	str	x2, [sp, #0x1a0]
1005e3ebc: f84383e2    	ldur	x2, [sp, #0x38]
1005e3ec0: f900d7fc    	str	x28, [sp, #0x1a8]
1005e3ec4: f940d3fc    	ldr	x28, [sp, #0x1a0]
1005e3ec8: f80383fc    	stur	x28, [sp, #0x38]
1005e3ecc: f900d3e1    	str	x1, [sp, #0x1a0]
1005e3ed0: aa0703e1    	mov	x1, x7
1005e3ed4: f940d3e7    	ldr	x7, [sp, #0x1a0]
1005e3ed8: f900d3e0    	str	x0, [sp, #0x1a0]
1005e3edc: aa0603e0    	mov	x0, x6
1005e3ee0: f940d3e6    	ldr	x6, [sp, #0x1a0]
1005e3ee4: f940d7fc    	ldr	x28, [sp, #0x1a8]
1005e3ee8: eb05037f    	cmp	x27, x5
1005e3eec: 54012803    	b.lo	0x1005e63ec <_mech_canonical_program_entry_v1_numeric_1282+0x4d6c>
1005e3ef0: d2800005    	mov	x5, #0x0                ; =0
1005e3ef4: f90aeb85    	str	x5, [x28, #0x15d0]
1005e3ef8: f90aef85    	str	x5, [x28, #0x15d8]
1005e3efc: f90af385    	str	x5, [x28, #0x15e0]
1005e3f00: f90af785    	str	x5, [x28, #0x15e8]
1005e3f04: f90afb85    	str	x5, [x28, #0x15f0]
1005e3f08: f90aff85    	str	x5, [x28, #0x15f8]
1005e3f0c: f90b0385    	str	x5, [x28, #0x1600]
1005e3f10: f90b0785    	str	x5, [x28, #0x1608]
1005e3f14: f90b0b85    	str	x5, [x28, #0x1610]
1005e3f18: f90b0f85    	str	x5, [x28, #0x1618]
1005e3f1c: f90b1385    	str	x5, [x28, #0x1620]
1005e3f20: f90b1785    	str	x5, [x28, #0x1628]
1005e3f24: f90b1b85    	str	x5, [x28, #0x1630]
1005e3f28: f90b1f85    	str	x5, [x28, #0x1638]
1005e3f2c: f90b2385    	str	x5, [x28, #0x1640]
1005e3f30: f90b2785    	str	x5, [x28, #0x1648]
1005e3f34: f90b2b85    	str	x5, [x28, #0x1650]
1005e3f38: f90b2f85    	str	x5, [x28, #0x1658]
1005e3f3c: 529b83c3    	mov	w3, #0xdc1e             ; =56350
1005e3f40: 72a00043    	movk	w3, #0x2, lsl #16
1005e3f44: cb030123    	sub	x3, x9, x3
1005e3f48: d2800004    	mov	x4, #0x0                ; =0
1005e3f4c: f80983e4    	stur	x4, [sp, #0x98]
1005e3f50: f84183e4    	ldur	x4, [sp, #0x18]
1005e3f54: f84983e5    	ldur	x5, [sp, #0x98]
1005e3f58: f80a03e5    	stur	x5, [sp, #0xa0]
1005e3f5c: aa1a03e5    	mov	x5, x26
1005e3f60: f84183fb    	ldur	x27, [sp, #0x18]
1005e3f64: eb05037f    	cmp	x27, x5
1005e3f68: 540122c3    	b.lo	0x1005e63c0 <_mech_canonical_program_entry_v1_numeric_1282+0x4d40>
1005e3f6c: d2800000    	mov	x0, #0x0                ; =0
1005e3f70: f9090380    	str	x0, [x28, #0x1200]
1005e3f74: f9090780    	str	x0, [x28, #0x1208]
1005e3f78: f9090b80    	str	x0, [x28, #0x1210]
1005e3f7c: f9090f80    	str	x0, [x28, #0x1218]
1005e3f80: f9091380    	str	x0, [x28, #0x1220]
1005e3f84: f9091780    	str	x0, [x28, #0x1228]
1005e3f88: f9091b80    	str	x0, [x28, #0x1230]
1005e3f8c: f9091f80    	str	x0, [x28, #0x1238]
1005e3f90: f9092380    	str	x0, [x28, #0x1240]
1005e3f94: f9092780    	str	x0, [x28, #0x1248]
1005e3f98: f9092b80    	str	x0, [x28, #0x1250]
1005e3f9c: f9092f80    	str	x0, [x28, #0x1258]
1005e3fa0: f9093380    	str	x0, [x28, #0x1260]
1005e3fa4: f9093780    	str	x0, [x28, #0x1268]
1005e3fa8: f9093b80    	str	x0, [x28, #0x1270]
1005e3fac: f9093f80    	str	x0, [x28, #0x1278]
1005e3fb0: f9094380    	str	x0, [x28, #0x1280]
1005e3fb4: f9094780    	str	x0, [x28, #0x1288]
1005e3fb8: f94093fa    	ldr	x26, [sp, #0x120]
1005e3fbc: eb1a02df    	cmp	x22, x26
1005e3fc0: 54001483    	b.lo	0x1005e4250 <_mech_canonical_program_entry_v1_numeric_1282+0x2bd0>
1005e3fc4: 14000cf6    	b	0x1005e739c <_mech_canonical_program_entry_v1_numeric_1282+0x5d1c>
1005e3fc8: f9663663    	ldr	x3, [x19, #0x4c68]
1005e3fcc: f9663a64    	ldr	x4, [x19, #0x4c70]
1005e3fd0: d2800000    	mov	x0, #0x0                ; =0
1005e3fd4: f9263260    	str	x0, [x19, #0x4c60]
1005e3fd8: d2800060    	mov	x0, #0x3                ; =3
1005e3fdc: f940c3ef    	ldr	x15, [sp, #0x180]
1005e3fe0: f80b83e0    	stur	x0, [sp, #0xb8]
1005e3fe4: f10669ff    	cmp	x15, #0x19a
1005e3fe8: 54022c83    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e3fec: f967ba60    	ldr	x0, [x19, #0x4f70]
1005e3ff0: f940c7e1    	ldr	x1, [sp, #0x188]
1005e3ff4: f9000820    	str	x0, [x1, #0x10]
1005e3ff8: f967be61    	ldr	x1, [x19, #0x4f78]
1005e3ffc: f940c7e2    	ldr	x2, [sp, #0x188]
1005e4000: f9000c41    	str	x1, [x2, #0x18]
1005e4004: f96d1262    	ldr	x2, [x19, #0x5a20]
1005e4008: f940c7e5    	ldr	x5, [sp, #0x188]
1005e400c: f90560a2    	str	x2, [x5, #0xac0]
1005e4010: f940c7e2    	ldr	x2, [sp, #0x188]
1005e4014: f9000840    	str	x0, [x2, #0x10]
1005e4018: f940c7e0    	ldr	x0, [sp, #0x188]
1005e401c: f9000c01    	str	x1, [x0, #0x18]
1005e4020: f9686260    	ldr	x0, [x19, #0x50c0]
1005e4024: f940c7e1    	ldr	x1, [sp, #0x188]
1005e4028: f900b020    	str	x0, [x1, #0x160]
1005e402c: f9686660    	ldr	x0, [x19, #0x50c8]
1005e4030: f900b420    	str	x0, [x1, #0x168]
1005e4034: f9686a60    	ldr	x0, [x19, #0x50d0]
1005e4038: f900b8a0    	str	x0, [x5, #0x170]
1005e403c: f9686e60    	ldr	x0, [x19, #0x50d8]
1005e4040: f940c7e6    	ldr	x6, [sp, #0x188]
1005e4044: f900bcc0    	str	x0, [x6, #0x178]
1005e4048: f9687260    	ldr	x0, [x19, #0x50e0]
1005e404c: f940c7e9    	ldr	x9, [sp, #0x188]
1005e4050: f900c120    	str	x0, [x9, #0x180]
1005e4054: f9687660    	ldr	x0, [x19, #0x50e8]
1005e4058: f940c7ec    	ldr	x12, [sp, #0x188]
1005e405c: f900c580    	str	x0, [x12, #0x188]
1005e4060: f9687a60    	ldr	x0, [x19, #0x50f0]
1005e4064: f940c7ef    	ldr	x15, [sp, #0x188]
1005e4068: f900c9e0    	str	x0, [x15, #0x190]
1005e406c: f9687e60    	ldr	x0, [x19, #0x50f8]
1005e4070: f900cc20    	str	x0, [x1, #0x198]
1005e4074: f9688260    	ldr	x0, [x19, #0x5100]
1005e4078: f900d020    	str	x0, [x1, #0x1a0]
1005e407c: f9695660    	ldr	x0, [x19, #0x52a8]
1005e4080: f901a420    	str	x0, [x1, #0x348]
1005e4084: f9695a60    	ldr	x0, [x19, #0x52b0]
1005e4088: f901a820    	str	x0, [x1, #0x350]
1005e408c: f9695e60    	ldr	x0, [x19, #0x52b8]
1005e4090: f901ac20    	str	x0, [x1, #0x358]
1005e4094: f9696260    	ldr	x0, [x19, #0x52c0]
1005e4098: f901b020    	str	x0, [x1, #0x360]
1005e409c: f9696660    	ldr	x0, [x19, #0x52c8]
1005e40a0: f901b420    	str	x0, [x1, #0x368]
1005e40a4: f9696a60    	ldr	x0, [x19, #0x52d0]
1005e40a8: f901b820    	str	x0, [x1, #0x370]
1005e40ac: f9696e60    	ldr	x0, [x19, #0x52d8]
1005e40b0: f901bc20    	str	x0, [x1, #0x378]
1005e40b4: f9697260    	ldr	x0, [x19, #0x52e0]
1005e40b8: f901c020    	str	x0, [x1, #0x380]
1005e40bc: f9697660    	ldr	x0, [x19, #0x52e8]
1005e40c0: f901c420    	str	x0, [x1, #0x388]
1005e40c4: f96aee60    	ldr	x0, [x19, #0x55d8]
1005e40c8: f9033c20    	str	x0, [x1, #0x678]
1005e40cc: f96af260    	ldr	x0, [x19, #0x55e0]
1005e40d0: f9034020    	str	x0, [x1, #0x680]
1005e40d4: f96af661    	ldr	x1, [x19, #0x55e8]
1005e40d8: f940c7e0    	ldr	x0, [sp, #0x188]
1005e40dc: f9034401    	str	x1, [x0, #0x688]
1005e40e0: f96afa62    	ldr	x2, [x19, #0x55f0]
1005e40e4: f9034802    	str	x2, [x0, #0x690]
1005e40e8: f96afe65    	ldr	x5, [x19, #0x55f8]
1005e40ec: f9034c05    	str	x5, [x0, #0x698]
1005e40f0: f96b0265    	ldr	x5, [x19, #0x5600]
1005e40f4: f90350c5    	str	x5, [x6, #0x6a0]
1005e40f8: f96b0665    	ldr	x5, [x19, #0x5608]
1005e40fc: f90354c5    	str	x5, [x6, #0x6a8]
1005e4100: f96b0a66    	ldr	x6, [x19, #0x5610]
1005e4104: f9035926    	str	x6, [x9, #0x6b0]
1005e4108: f96bd267    	ldr	x7, [x19, #0x57a0]
1005e410c: f9042187    	str	x7, [x12, #0x840]
1005e4110: f96bd668    	ldr	x8, [x19, #0x57a8]
1005e4114: f90425e8    	str	x8, [x15, #0x848]
1005e4118: f96bda69    	ldr	x9, [x19, #0x57b0]
1005e411c: f9042809    	str	x9, [x0, #0x850]
1005e4120: f96bde6a    	ldr	x10, [x19, #0x57b8]
1005e4124: f9042c0a    	str	x10, [x0, #0x858]
1005e4128: f96be26b    	ldr	x11, [x19, #0x57c0]
1005e412c: f904300b    	str	x11, [x0, #0x860]
1005e4130: f96be66c    	ldr	x12, [x19, #0x57c8]
1005e4134: f904340c    	str	x12, [x0, #0x868]
1005e4138: f96bea6d    	ldr	x13, [x19, #0x57d0]
1005e413c: f904380d    	str	x13, [x0, #0x870]
1005e4140: f96bee6e    	ldr	x14, [x19, #0x57d8]
1005e4144: f9043c0e    	str	x14, [x0, #0x878]
1005e4148: f96dda6f    	ldr	x15, [x19, #0x5bb0]
1005e414c: f906280f    	str	x15, [x0, #0xc50]
1005e4150: f96dde60    	ldr	x0, [x19, #0x5bb8]
1005e4154: f940c7e1    	ldr	x1, [sp, #0x188]
1005e4158: f9062c20    	str	x0, [x1, #0xc58]
1005e415c: f96de260    	ldr	x0, [x19, #0x5bc0]
1005e4160: f9063020    	str	x0, [x1, #0xc60]
1005e4164: f96de660    	ldr	x0, [x19, #0x5bc8]
1005e4168: f9063420    	str	x0, [x1, #0xc68]
1005e416c: f96dea60    	ldr	x0, [x19, #0x5bd0]
1005e4170: f9063820    	str	x0, [x1, #0xc70]
1005e4174: f96dee60    	ldr	x0, [x19, #0x5bd8]
1005e4178: f9063c20    	str	x0, [x1, #0xc78]
1005e417c: d2800000    	mov	x0, #0x0                ; =0
1005e4180: f9064020    	str	x0, [x1, #0xc80]
1005e4184: f96df661    	ldr	x1, [x19, #0x5be8]
1005e4188: f940c7e2    	ldr	x2, [sp, #0x188]
1005e418c: f9064441    	str	x1, [x2, #0xc88]
1005e4190: f96dfa61    	ldr	x1, [x19, #0x5bf0]
1005e4194: f9064841    	str	x1, [x2, #0xc90]
1005e4198: f940c7e1    	ldr	x1, [sp, #0x188]
1005e419c: f9064c20    	str	x0, [x1, #0xc98]
1005e41a0: f96e0261    	ldr	x1, [x19, #0x5c00]
1005e41a4: f9065041    	str	x1, [x2, #0xca0]
1005e41a8: f96e0661    	ldr	x1, [x19, #0x5c08]
1005e41ac: f940c7e5    	ldr	x5, [sp, #0x188]
1005e41b0: f90654a1    	str	x1, [x5, #0xca8]
1005e41b4: f940c7e7    	ldr	x7, [sp, #0x188]
1005e41b8: f90658e0    	str	x0, [x7, #0xcb0]
1005e41bc: f96e0e60    	ldr	x0, [x19, #0x5c18]
1005e41c0: f940c7ea    	ldr	x10, [sp, #0x188]
1005e41c4: f9065d40    	str	x0, [x10, #0xcb8]
1005e41c8: f96e1260    	ldr	x0, [x19, #0x5c20]
1005e41cc: f940c7ed    	ldr	x13, [sp, #0x188]
1005e41d0: f90661a0    	str	x0, [x13, #0xcc0]
1005e41d4: d280bd01    	mov	x1, #0x5e8              ; =1512
1005e41d8: 92800102    	mov	x2, #-0x9               ; =-9
1005e41dc: f940cff5    	ldr	x21, [sp, #0x198]
1005e41e0: f84083e0    	ldur	x0, [sp, #0x8]
1005e41e4: aa1403e5    	mov	x5, x20
1005e41e8: f940cbe6    	ldr	x6, [sp, #0x190]
1005e41ec: d63f02a0    	blr	x21
1005e41f0: f100001f    	cmp	x0, #0x0
1005e41f4: 54019661    	b.ne	0x1005e74c0 <_mech_canonical_program_entry_v1_numeric_1282+0x5e40>
1005e41f8: d2800060    	mov	x0, #0x3                ; =3
1005e41fc: f940c3ef    	ldr	x15, [sp, #0x180]
1005e4200: f80b83e0    	stur	x0, [sp, #0xb8]
1005e4204: f10009ff    	cmp	x15, #0x2
1005e4208: 54021b83    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e420c: d2800005    	mov	x5, #0x0                ; =0
1005e4210: f940c7e3    	ldr	x3, [sp, #0x188]
1005e4214: f9000065    	str	x5, [x3]
1005e4218: f94e0260    	ldr	x0, [x19, #0x1c00]
1005e421c: f9000460    	str	x0, [x3, #0x8]
1005e4220: d280bd01    	mov	x1, #0x5e8              ; =1512
1005e4224: f84083e0    	ldur	x0, [sp, #0x8]
1005e4228: f940cbe6    	ldr	x6, [sp, #0x190]
1005e422c: f940cff5    	ldr	x21, [sp, #0x198]
1005e4230: aa1403e4    	mov	x4, x20
1005e4234: aa0503e2    	mov	x2, x5
1005e4238: d63f02a0    	blr	x21
1005e423c: f100001f    	cmp	x0, #0x0
1005e4240: 54019441    	b.ne	0x1005e74c8 <_mech_canonical_program_entry_v1_numeric_1282+0x5e48>
1005e4244: d2800060    	mov	x0, #0x3                ; =3
1005e4248: f80b83e0    	stur	x0, [sp, #0xb8]
1005e424c: 140010cb    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e4250: f94097fa    	ldr	x26, [sp, #0x128]
1005e4254: f8767b4f    	ldr	x15, [x26, x22, lsl #3]
1005e4258: f84d83f8    	ldur	x24, [sp, #0xd8]
1005e425c: f94093fa    	ldr	x26, [sp, #0x120]
1005e4260: eb1a031f    	cmp	x24, x26
1005e4264: 54001463    	b.lo	0x1005e44f0 <_mech_canonical_program_entry_v1_numeric_1282+0x2e70>
1005e4268: 14000c9a    	b	0x1005e74d0 <_mech_canonical_program_entry_v1_numeric_1282+0x5e50>
1005e426c: f9663663    	ldr	x3, [x19, #0x4c68]
1005e4270: f9663a64    	ldr	x4, [x19, #0x4c70]
1005e4274: d2800000    	mov	x0, #0x0                ; =0
1005e4278: f9263260    	str	x0, [x19, #0x4c60]
1005e427c: d2800060    	mov	x0, #0x3                ; =3
1005e4280: f940c3ef    	ldr	x15, [sp, #0x180]
1005e4284: f80b83e0    	stur	x0, [sp, #0xb8]
1005e4288: f10669ff    	cmp	x15, #0x19a
1005e428c: 54021763    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e4290: f967ba60    	ldr	x0, [x19, #0x4f70]
1005e4294: f940c7e1    	ldr	x1, [sp, #0x188]
1005e4298: f9000820    	str	x0, [x1, #0x10]
1005e429c: f967be61    	ldr	x1, [x19, #0x4f78]
1005e42a0: f940c7e2    	ldr	x2, [sp, #0x188]
1005e42a4: f9000c41    	str	x1, [x2, #0x18]
1005e42a8: f96d1262    	ldr	x2, [x19, #0x5a20]
1005e42ac: f940c7e5    	ldr	x5, [sp, #0x188]
1005e42b0: f90560a2    	str	x2, [x5, #0xac0]
1005e42b4: f940c7e2    	ldr	x2, [sp, #0x188]
1005e42b8: f9000840    	str	x0, [x2, #0x10]
1005e42bc: f9000ca1    	str	x1, [x5, #0x18]
1005e42c0: f9686260    	ldr	x0, [x19, #0x50c0]
1005e42c4: f940c7e6    	ldr	x6, [sp, #0x188]
1005e42c8: f900b0c0    	str	x0, [x6, #0x160]
1005e42cc: f9686660    	ldr	x0, [x19, #0x50c8]
1005e42d0: f940c7e9    	ldr	x9, [sp, #0x188]
1005e42d4: f900b520    	str	x0, [x9, #0x168]
1005e42d8: f9686a60    	ldr	x0, [x19, #0x50d0]
1005e42dc: f940c7ec    	ldr	x12, [sp, #0x188]
1005e42e0: f900b980    	str	x0, [x12, #0x170]
1005e42e4: f9686e60    	ldr	x0, [x19, #0x50d8]
1005e42e8: f940c7ef    	ldr	x15, [sp, #0x188]
1005e42ec: f900bde0    	str	x0, [x15, #0x178]
1005e42f0: f9687260    	ldr	x0, [x19, #0x50e0]
1005e42f4: f940c7e1    	ldr	x1, [sp, #0x188]
1005e42f8: f900c020    	str	x0, [x1, #0x180]
1005e42fc: f9687660    	ldr	x0, [x19, #0x50e8]
1005e4300: f900c420    	str	x0, [x1, #0x188]
1005e4304: f9687a60    	ldr	x0, [x19, #0x50f0]
1005e4308: f900c820    	str	x0, [x1, #0x190]
1005e430c: f9687e60    	ldr	x0, [x19, #0x50f8]
1005e4310: f900cc20    	str	x0, [x1, #0x198]
1005e4314: f9688260    	ldr	x0, [x19, #0x5100]
1005e4318: f900d020    	str	x0, [x1, #0x1a0]
1005e431c: f9695660    	ldr	x0, [x19, #0x52a8]
1005e4320: f901a420    	str	x0, [x1, #0x348]
1005e4324: f9695a60    	ldr	x0, [x19, #0x52b0]
1005e4328: f901a820    	str	x0, [x1, #0x350]
1005e432c: f9695e60    	ldr	x0, [x19, #0x52b8]
1005e4330: f901ac20    	str	x0, [x1, #0x358]
1005e4334: f9696260    	ldr	x0, [x19, #0x52c0]
1005e4338: f901b020    	str	x0, [x1, #0x360]
1005e433c: f9696660    	ldr	x0, [x19, #0x52c8]
1005e4340: f901b420    	str	x0, [x1, #0x368]
1005e4344: f9696a60    	ldr	x0, [x19, #0x52d0]
1005e4348: f901b820    	str	x0, [x1, #0x370]
1005e434c: f9696e60    	ldr	x0, [x19, #0x52d8]
1005e4350: f901bc20    	str	x0, [x1, #0x378]
1005e4354: f9697260    	ldr	x0, [x19, #0x52e0]
1005e4358: f901c020    	str	x0, [x1, #0x380]
1005e435c: f9697660    	ldr	x0, [x19, #0x52e8]
1005e4360: f901c420    	str	x0, [x1, #0x388]
1005e4364: f96aee60    	ldr	x0, [x19, #0x55d8]
1005e4368: f9033c20    	str	x0, [x1, #0x678]
1005e436c: f96af260    	ldr	x0, [x19, #0x55e0]
1005e4370: f9034020    	str	x0, [x1, #0x680]
1005e4374: f96af660    	ldr	x0, [x19, #0x55e8]
1005e4378: f90344a0    	str	x0, [x5, #0x688]
1005e437c: f96afa60    	ldr	x0, [x19, #0x55f0]
1005e4380: f90348c0    	str	x0, [x6, #0x690]
1005e4384: f96afe60    	ldr	x0, [x19, #0x55f8]
1005e4388: f9034d20    	str	x0, [x9, #0x698]
1005e438c: f96b0260    	ldr	x0, [x19, #0x5600]
1005e4390: f9035180    	str	x0, [x12, #0x6a0]
1005e4394: f96b0660    	ldr	x0, [x19, #0x5608]
1005e4398: f90355e0    	str	x0, [x15, #0x6a8]
1005e439c: f96b0a60    	ldr	x0, [x19, #0x5610]
1005e43a0: f9035820    	str	x0, [x1, #0x6b0]
1005e43a4: f96bd260    	ldr	x0, [x19, #0x57a0]
1005e43a8: f9042020    	str	x0, [x1, #0x840]
1005e43ac: f96bd660    	ldr	x0, [x19, #0x57a8]
1005e43b0: f9042420    	str	x0, [x1, #0x848]
1005e43b4: f96bda61    	ldr	x1, [x19, #0x57b0]
1005e43b8: f940c7e0    	ldr	x0, [sp, #0x188]
1005e43bc: f9042801    	str	x1, [x0, #0x850]
1005e43c0: f96bde62    	ldr	x2, [x19, #0x57b8]
1005e43c4: f9042c02    	str	x2, [x0, #0x858]
1005e43c8: f96be265    	ldr	x5, [x19, #0x57c0]
1005e43cc: f9043005    	str	x5, [x0, #0x860]
1005e43d0: f96be665    	ldr	x5, [x19, #0x57c8]
1005e43d4: f9043405    	str	x5, [x0, #0x868]
1005e43d8: f96bea65    	ldr	x5, [x19, #0x57d0]
1005e43dc: f9043805    	str	x5, [x0, #0x870]
1005e43e0: f96bee66    	ldr	x6, [x19, #0x57d8]
1005e43e4: f9043c06    	str	x6, [x0, #0x878]
1005e43e8: f96dda67    	ldr	x7, [x19, #0x5bb0]
1005e43ec: f9062807    	str	x7, [x0, #0xc50]
1005e43f0: f96dde68    	ldr	x8, [x19, #0x5bb8]
1005e43f4: f9062c08    	str	x8, [x0, #0xc58]
1005e43f8: f96de269    	ldr	x9, [x19, #0x5bc0]
1005e43fc: f9063009    	str	x9, [x0, #0xc60]
1005e4400: f96de66a    	ldr	x10, [x19, #0x5bc8]
1005e4404: f906340a    	str	x10, [x0, #0xc68]
1005e4408: f96dea6b    	ldr	x11, [x19, #0x5bd0]
1005e440c: f906380b    	str	x11, [x0, #0xc70]
1005e4410: f96dee6c    	ldr	x12, [x19, #0x5bd8]
1005e4414: f9063c0c    	str	x12, [x0, #0xc78]
1005e4418: d280000d    	mov	x13, #0x0               ; =0
1005e441c: f906400d    	str	x13, [x0, #0xc80]
1005e4420: f96df66e    	ldr	x14, [x19, #0x5be8]
1005e4424: f940c7e5    	ldr	x5, [sp, #0x188]
1005e4428: f90644ae    	str	x14, [x5, #0xc88]
1005e442c: f96dfa6f    	ldr	x15, [x19, #0x5bf0]
1005e4430: f940c7e6    	ldr	x6, [sp, #0x188]
1005e4434: f90648cf    	str	x15, [x6, #0xc90]
1005e4438: f940c7e8    	ldr	x8, [sp, #0x188]
1005e443c: f9064d0d    	str	x13, [x8, #0xc98]
1005e4440: f96e0260    	ldr	x0, [x19, #0x5c00]
1005e4444: f940c7eb    	ldr	x11, [sp, #0x188]
1005e4448: f9065160    	str	x0, [x11, #0xca0]
1005e444c: f96e0660    	ldr	x0, [x19, #0x5c08]
1005e4450: f940c7ee    	ldr	x14, [sp, #0x188]
1005e4454: f90655c0    	str	x0, [x14, #0xca8]
1005e4458: f940c7e0    	ldr	x0, [sp, #0x188]
1005e445c: f906580d    	str	x13, [x0, #0xcb0]
1005e4460: f96e0e60    	ldr	x0, [x19, #0x5c18]
1005e4464: f940c7e1    	ldr	x1, [sp, #0x188]
1005e4468: f9065c20    	str	x0, [x1, #0xcb8]
1005e446c: f96e1260    	ldr	x0, [x19, #0x5c20]
1005e4470: f9066020    	str	x0, [x1, #0xcc0]
1005e4474: d280bd41    	mov	x1, #0x5ea              ; =1514
1005e4478: 92800102    	mov	x2, #-0x9               ; =-9
1005e447c: f940cff5    	ldr	x21, [sp, #0x198]
1005e4480: f84083e0    	ldur	x0, [sp, #0x8]
1005e4484: aa1403e5    	mov	x5, x20
1005e4488: f940cbe6    	ldr	x6, [sp, #0x190]
1005e448c: d63f02a0    	blr	x21
1005e4490: f100001f    	cmp	x0, #0x0
1005e4494: 54018b21    	b.ne	0x1005e75f8 <_mech_canonical_program_entry_v1_numeric_1282+0x5f78>
1005e4498: d2800060    	mov	x0, #0x3                ; =3
1005e449c: f940c3ef    	ldr	x15, [sp, #0x180]
1005e44a0: f80b83e0    	stur	x0, [sp, #0xb8]
1005e44a4: f10009ff    	cmp	x15, #0x2
1005e44a8: 54020683    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e44ac: d2800005    	mov	x5, #0x0                ; =0
1005e44b0: f940c7e3    	ldr	x3, [sp, #0x188]
1005e44b4: f9000065    	str	x5, [x3]
1005e44b8: f94e0a60    	ldr	x0, [x19, #0x1c10]
1005e44bc: f9000460    	str	x0, [x3, #0x8]
1005e44c0: d280bd41    	mov	x1, #0x5ea              ; =1514
1005e44c4: f84083e0    	ldur	x0, [sp, #0x8]
1005e44c8: f940cbe6    	ldr	x6, [sp, #0x190]
1005e44cc: f940cff5    	ldr	x21, [sp, #0x198]
1005e44d0: aa1403e4    	mov	x4, x20
1005e44d4: aa0503e2    	mov	x2, x5
1005e44d8: d63f02a0    	blr	x21
1005e44dc: f100001f    	cmp	x0, #0x0
1005e44e0: 54018901    	b.ne	0x1005e7600 <_mech_canonical_program_entry_v1_numeric_1282+0x5f80>
1005e44e4: d2800060    	mov	x0, #0x3                ; =3
1005e44e8: f80b83e0    	stur	x0, [sp, #0xb8]
1005e44ec: 14001023    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e44f0: f84d83f8    	ldur	x24, [sp, #0xd8]
1005e44f4: f94097fa    	ldr	x26, [sp, #0x128]
1005e44f8: f8787b4c    	ldr	x12, [x26, x24, lsl #3]
1005e44fc: d2800007    	mov	x7, #0x0                ; =0
1005e4500: f80403e7    	stur	x7, [sp, #0x40]
1005e4504: 5284c8c0    	mov	w0, #0x2646             ; =9798
1005e4508: 72a00020    	movk	w0, #0x1, lsl #16
1005e450c: eb00007f    	cmp	x3, x0
1005e4510: 9a9f37e0    	cset	x0, hs
1005e4514: f84e83fa    	ldur	x26, [sp, #0xe8]
1005e4518: 0a1a0000    	and	w0, w0, w26
1005e451c: 53001c00    	uxtb	w0, w0
1005e4520: b5001d00    	cbnz	x0, 0x1005e48c0 <_mech_canonical_program_entry_v1_numeric_1282+0x3240>
1005e4524: d2800000    	mov	x0, #0x0                ; =0
1005e4528: f9000e60    	str	x0, [x19, #0x18]
1005e452c: d2e20001    	mov	x1, #0x1000000000000000 ; =1152921504606846976
1005e4530: f9001261    	str	x1, [x19, #0x20]
1005e4534: d2800021    	mov	x1, #0x1                ; =1
1005e4538: f9001a61    	str	x1, [x19, #0x30]
1005e453c: b200c3e2    	mov	x2, #0x101010101010101  ; =72340172838076673
1005e4540: f9001e62    	str	x2, [x19, #0x38]
1005e4544: d2800054    	mov	x20, #0x2               ; =2
1005e4548: f9002274    	str	x20, [x19, #0x40]
1005e454c: d2800062    	mov	x2, #0x3                ; =3
1005e4550: f9002662    	str	x2, [x19, #0x48]
1005e4554: d2800082    	mov	x2, #0x4                ; =4
1005e4558: f9002a62    	str	x2, [x19, #0x50]
1005e455c: aa0203fc    	mov	x28, x2
1005e4560: b200cfe2    	mov	x2, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e4564: f9003e62    	str	x2, [x19, #0x78]
1005e4568: b200e7e2    	mov	x2, #0x3333333333333333 ; =3689348814741910323
1005e456c: f9004662    	str	x2, [x19, #0x88]
1005e4570: d2800702    	mov	x2, #0x38               ; =56
1005e4574: f9004a62    	str	x2, [x19, #0x90]
1005e4578: d2800742    	mov	x2, #0x3a               ; =58
1005e457c: f9004e62    	str	x2, [x19, #0x98]
1005e4580: b200f3e2    	mov	x2, #0x5555555555555555 ; =6148914691236517205
1005e4584: f9005a62    	str	x2, [x19, #0xb0]
1005e4588: 92ff8002    	mov	x2, #0x3ffffffffffffff  ; =288230376151711743
1005e458c: f9005e62    	str	x2, [x19, #0xb8]
1005e4590: f900c660    	str	x0, [x19, #0x188]
1005e4594: f900ca61    	str	x1, [x19, #0x190]
1005e4598: f90bd276    	str	x22, [x19, #0x17a0]
1005e459c: f90bd677    	str	x23, [x19, #0x17a8]
1005e45a0: f84e03f8    	ldur	x24, [sp, #0xe0]
1005e45a4: 53001f02    	uxtb	w2, w24
1005e45a8: f90bde62    	str	x2, [x19, #0x17b8]
1005e45ac: f926326a    	str	x10, [x19, #0x4c60]
1005e45b0: f9263663    	str	x3, [x19, #0x4c68]
1005e45b4: f84803e4    	ldur	x4, [sp, #0x80]
1005e45b8: f9263a64    	str	x4, [x19, #0x4c70]
1005e45bc: f927ba76    	str	x22, [x19, #0x4f70]
1005e45c0: f927be77    	str	x23, [x19, #0x4f78]
1005e45c4: f92aee6f    	str	x15, [x19, #0x55d8]
1005e45c8: f92af26c    	str	x12, [x19, #0x55e0]
1005e45cc: f92af676    	str	x22, [x19, #0x55e8]
1005e45d0: f84103f9    	ldur	x25, [sp, #0x10]
1005e45d4: f92afa79    	str	x25, [x19, #0x55f0]
1005e45d8: f84583f8    	ldur	x24, [sp, #0x58]
1005e45dc: f92afe78    	str	x24, [x19, #0x55f8]
1005e45e0: f84603fb    	ldur	x27, [sp, #0x60]
1005e45e4: f92b027b    	str	x27, [x19, #0x5600]
1005e45e8: f84683f9    	ldur	x25, [sp, #0x68]
1005e45ec: f92b0679    	str	x25, [x19, #0x5608]
1005e45f0: f84703fa    	ldur	x26, [sp, #0x70]
1005e45f4: f92b0a7a    	str	x26, [x19, #0x5610]
1005e45f8: f84503e2    	ldur	x2, [sp, #0x50]
1005e45fc: f92d1262    	str	x2, [x19, #0x5a20]
1005e4600: 9100050e    	add	x14, x8, #0x1
1005e4604: f92dda6e    	str	x14, [x19, #0x5bb0]
1005e4608: f84883fa    	ldur	x26, [sp, #0x88]
1005e460c: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e4610: f84903e6    	ldur	x6, [sp, #0x90]
1005e4614: f92de266    	str	x6, [x19, #0x5bc0]
1005e4618: f84783e4    	ldur	x4, [sp, #0x78]
1005e461c: cb030082    	sub	x2, x4, x3
1005e4620: 52990fc3    	mov	w3, #0xc87e             ; =51326
1005e4624: 72a00023    	movk	w3, #0x1, lsl #16
1005e4628: 9b0389c2    	msub	x2, x14, x3, x2
1005e462c: f92de662    	str	x2, [x19, #0x5bc8]
1005e4630: f92dea60    	str	x0, [x19, #0x5bd0]
1005e4634: f92dee60    	str	x0, [x19, #0x5bd8]
1005e4638: f84983ea    	ldur	x10, [sp, #0x98]
1005e463c: f92df66a    	str	x10, [x19, #0x5be8]
1005e4640: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e4644: f92dfa64    	str	x4, [x19, #0x5bf0]
1005e4648: f92e0261    	str	x1, [x19, #0x5c00]
1005e464c: f84403e7    	ldur	x7, [sp, #0x40]
1005e4650: f92e0667    	str	x7, [x19, #0x5c08]
1005e4654: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e4658: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e465c: f92e126d    	str	x13, [x19, #0x5c20]
1005e4660: f9663260    	ldr	x0, [x19, #0x4c60]
1005e4664: f100001f    	cmp	x0, #0x0
1005e4668: 54001180    	b.eq	0x1005e4898 <_mech_canonical_program_entry_v1_numeric_1282+0x3218>
1005e466c: f9663663    	ldr	x3, [x19, #0x4c68]
1005e4670: f9663a64    	ldr	x4, [x19, #0x4c70]
1005e4674: d2800000    	mov	x0, #0x0                ; =0
1005e4678: f9263260    	str	x0, [x19, #0x4c60]
1005e467c: d2800060    	mov	x0, #0x3                ; =3
1005e4680: f940c3ef    	ldr	x15, [sp, #0x180]
1005e4684: f80b83e0    	stur	x0, [sp, #0xb8]
1005e4688: f10669ff    	cmp	x15, #0x19a
1005e468c: 5401f763    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e4690: f967ba60    	ldr	x0, [x19, #0x4f70]
1005e4694: f940c7e1    	ldr	x1, [sp, #0x188]
1005e4698: f9000820    	str	x0, [x1, #0x10]
1005e469c: f967be61    	ldr	x1, [x19, #0x4f78]
1005e46a0: f940c7e2    	ldr	x2, [sp, #0x188]
1005e46a4: f9000c41    	str	x1, [x2, #0x18]
1005e46a8: f96d1262    	ldr	x2, [x19, #0x5a20]
1005e46ac: f940c7e5    	ldr	x5, [sp, #0x188]
1005e46b0: f90560a2    	str	x2, [x5, #0xac0]
1005e46b4: f940c7e2    	ldr	x2, [sp, #0x188]
1005e46b8: f9000840    	str	x0, [x2, #0x10]
1005e46bc: f940c7e0    	ldr	x0, [sp, #0x188]
1005e46c0: f9000c01    	str	x1, [x0, #0x18]
1005e46c4: f9686260    	ldr	x0, [x19, #0x50c0]
1005e46c8: f940c7e1    	ldr	x1, [sp, #0x188]
1005e46cc: f900b020    	str	x0, [x1, #0x160]
1005e46d0: f9686660    	ldr	x0, [x19, #0x50c8]
1005e46d4: f900b420    	str	x0, [x1, #0x168]
1005e46d8: f9686a60    	ldr	x0, [x19, #0x50d0]
1005e46dc: f900b820    	str	x0, [x1, #0x170]
1005e46e0: f9686e60    	ldr	x0, [x19, #0x50d8]
1005e46e4: f900bc20    	str	x0, [x1, #0x178]
1005e46e8: f9687260    	ldr	x0, [x19, #0x50e0]
1005e46ec: f900c020    	str	x0, [x1, #0x180]
1005e46f0: f9687660    	ldr	x0, [x19, #0x50e8]
1005e46f4: f900c420    	str	x0, [x1, #0x188]
1005e46f8: f9687a60    	ldr	x0, [x19, #0x50f0]
1005e46fc: f900c820    	str	x0, [x1, #0x190]
1005e4700: f9687e60    	ldr	x0, [x19, #0x50f8]
1005e4704: f900cc20    	str	x0, [x1, #0x198]
1005e4708: f9688260    	ldr	x0, [x19, #0x5100]
1005e470c: f900d020    	str	x0, [x1, #0x1a0]
1005e4710: f9695660    	ldr	x0, [x19, #0x52a8]
1005e4714: f901a420    	str	x0, [x1, #0x348]
1005e4718: f9695a60    	ldr	x0, [x19, #0x52b0]
1005e471c: f901a820    	str	x0, [x1, #0x350]
1005e4720: f9695e60    	ldr	x0, [x19, #0x52b8]
1005e4724: f901ac20    	str	x0, [x1, #0x358]
1005e4728: f9696260    	ldr	x0, [x19, #0x52c0]
1005e472c: f901b040    	str	x0, [x2, #0x360]
1005e4730: f9696660    	ldr	x0, [x19, #0x52c8]
1005e4734: f901b4a0    	str	x0, [x5, #0x368]
1005e4738: f9696a60    	ldr	x0, [x19, #0x52d0]
1005e473c: f940c7e8    	ldr	x8, [sp, #0x188]
1005e4740: f901b900    	str	x0, [x8, #0x370]
1005e4744: f9696e60    	ldr	x0, [x19, #0x52d8]
1005e4748: f940c7eb    	ldr	x11, [sp, #0x188]
1005e474c: f901bd60    	str	x0, [x11, #0x378]
1005e4750: f9697260    	ldr	x0, [x19, #0x52e0]
1005e4754: f940c7ee    	ldr	x14, [sp, #0x188]
1005e4758: f901c1c0    	str	x0, [x14, #0x380]
1005e475c: f9697660    	ldr	x0, [x19, #0x52e8]
1005e4760: f901c420    	str	x0, [x1, #0x388]
1005e4764: f96aee60    	ldr	x0, [x19, #0x55d8]
1005e4768: f9033c20    	str	x0, [x1, #0x678]
1005e476c: f96af260    	ldr	x0, [x19, #0x55e0]
1005e4770: f9034020    	str	x0, [x1, #0x680]
1005e4774: f96af660    	ldr	x0, [x19, #0x55e8]
1005e4778: f9034420    	str	x0, [x1, #0x688]
1005e477c: f96afa60    	ldr	x0, [x19, #0x55f0]
1005e4780: f9034820    	str	x0, [x1, #0x690]
1005e4784: f96afe60    	ldr	x0, [x19, #0x55f8]
1005e4788: f9034c20    	str	x0, [x1, #0x698]
1005e478c: f96b0260    	ldr	x0, [x19, #0x5600]
1005e4790: f9035020    	str	x0, [x1, #0x6a0]
1005e4794: f96b0660    	ldr	x0, [x19, #0x5608]
1005e4798: f9035420    	str	x0, [x1, #0x6a8]
1005e479c: f96b0a60    	ldr	x0, [x19, #0x5610]
1005e47a0: f9035820    	str	x0, [x1, #0x6b0]
1005e47a4: f96bd261    	ldr	x1, [x19, #0x57a0]
1005e47a8: f940c7e0    	ldr	x0, [sp, #0x188]
1005e47ac: f9042001    	str	x1, [x0, #0x840]
1005e47b0: f96bd662    	ldr	x2, [x19, #0x57a8]
1005e47b4: f9042402    	str	x2, [x0, #0x848]
1005e47b8: f96bda65    	ldr	x5, [x19, #0x57b0]
1005e47bc: f9042805    	str	x5, [x0, #0x850]
1005e47c0: f96bde65    	ldr	x5, [x19, #0x57b8]
1005e47c4: f9042c05    	str	x5, [x0, #0x858]
1005e47c8: f96be265    	ldr	x5, [x19, #0x57c0]
1005e47cc: f9043005    	str	x5, [x0, #0x860]
1005e47d0: f96be666    	ldr	x6, [x19, #0x57c8]
1005e47d4: f9043406    	str	x6, [x0, #0x868]
1005e47d8: f96bea67    	ldr	x7, [x19, #0x57d0]
1005e47dc: f9043807    	str	x7, [x0, #0x870]
1005e47e0: f96bee68    	ldr	x8, [x19, #0x57d8]
1005e47e4: f940c7e2    	ldr	x2, [sp, #0x188]
1005e47e8: f9043c48    	str	x8, [x2, #0x878]
1005e47ec: f96dda69    	ldr	x9, [x19, #0x5bb0]
1005e47f0: f940c7e5    	ldr	x5, [sp, #0x188]
1005e47f4: f90628a9    	str	x9, [x5, #0xc50]
1005e47f8: f96dde6a    	ldr	x10, [x19, #0x5bb8]
1005e47fc: f940c7e8    	ldr	x8, [sp, #0x188]
1005e4800: f9062d0a    	str	x10, [x8, #0xc58]
1005e4804: f96de26b    	ldr	x11, [x19, #0x5bc0]
1005e4808: f940c7ec    	ldr	x12, [sp, #0x188]
1005e480c: f906318b    	str	x11, [x12, #0xc60]
1005e4810: f96de66c    	ldr	x12, [x19, #0x5bc8]
1005e4814: f90635cc    	str	x12, [x14, #0xc68]
1005e4818: f96dea6d    	ldr	x13, [x19, #0x5bd0]
1005e481c: f906380d    	str	x13, [x0, #0xc70]
1005e4820: f96dee6e    	ldr	x14, [x19, #0x5bd8]
1005e4824: f9063c0e    	str	x14, [x0, #0xc78]
1005e4828: d280000f    	mov	x15, #0x0               ; =0
1005e482c: f906400f    	str	x15, [x0, #0xc80]
1005e4830: f96df660    	ldr	x0, [x19, #0x5be8]
1005e4834: f940c7e1    	ldr	x1, [sp, #0x188]
1005e4838: f9064420    	str	x0, [x1, #0xc88]
1005e483c: f96dfa60    	ldr	x0, [x19, #0x5bf0]
1005e4840: f9064820    	str	x0, [x1, #0xc90]
1005e4844: f940c7e0    	ldr	x0, [sp, #0x188]
1005e4848: f9064c0f    	str	x15, [x0, #0xc98]
1005e484c: f96e0260    	ldr	x0, [x19, #0x5c00]
1005e4850: f9065020    	str	x0, [x1, #0xca0]
1005e4854: f96e0660    	ldr	x0, [x19, #0x5c08]
1005e4858: f9065420    	str	x0, [x1, #0xca8]
1005e485c: f940c7e0    	ldr	x0, [sp, #0x188]
1005e4860: f906580f    	str	x15, [x0, #0xcb0]
1005e4864: f96e0e60    	ldr	x0, [x19, #0x5c18]
1005e4868: f9065c20    	str	x0, [x1, #0xcb8]
1005e486c: f96e1260    	ldr	x0, [x19, #0x5c20]
1005e4870: f9066020    	str	x0, [x1, #0xcc0]
1005e4874: d280be41    	mov	x1, #0x5f2              ; =1522
1005e4878: 92800102    	mov	x2, #-0x9               ; =-9
1005e487c: d2800025    	mov	x5, #0x1                ; =1
1005e4880: f84083e0    	ldur	x0, [sp, #0x8]
1005e4884: f940cbe6    	ldr	x6, [sp, #0x190]
1005e4888: f940cff5    	ldr	x21, [sp, #0x198]
1005e488c: d63f02a0    	blr	x21
1005e4890: f100001f    	cmp	x0, #0x0
1005e4894: 54016ba1    	b.ne	0x1005e7608 <_mech_canonical_program_entry_v1_numeric_1282+0x5f88>
1005e4898: d2800000    	mov	x0, #0x0                ; =0
1005e489c: aa1c03e1    	mov	x1, x28
1005e48a0: 9106c3ff    	add	sp, sp, #0x1b0
1005e48a4: a8c153f3    	ldp	x19, x20, [sp], #0x10
1005e48a8: a8c15bf5    	ldp	x21, x22, [sp], #0x10
1005e48ac: a8c163f7    	ldp	x23, x24, [sp], #0x10
1005e48b0: a8c16bf9    	ldp	x25, x26, [sp], #0x10
1005e48b4: a8c173fb    	ldp	x27, x28, [sp], #0x10
1005e48b8: a8c17bfd    	ldp	x29, x30, [sp], #0x10
1005e48bc: d65f0fff    	retab
1005e48c0: eb0c01ff    	cmp	x15, x12
1005e48c4: 9a9f27e0    	cset	x0, lo
1005e48c8: d2e2001a    	mov	x26, #0x1000000000000000 ; =1152921504606846976
1005e48cc: d2e20001    	mov	x1, #0x1000000000000000 ; =1152921504606846976
1005e48d0: f84703e2    	ldur	x2, [sp, #0x70]
1005e48d4: eb01005f    	cmp	x2, x1
1005e48d8: 9a9f27e1    	cset	x1, lo
1005e48dc: 0a010000    	and	w0, w0, w1
1005e48e0: 53001c19    	uxtb	w25, w0
1005e48e4: 37000159    	tbnz	w25, #0x0, 0x1005e490c <_mech_canonical_program_entry_v1_numeric_1282+0x328c>
1005e48e8: 5284c8c0    	mov	w0, #0x2646             ; =9798
1005e48ec: 72a00020    	movk	w0, #0x1, lsl #16
1005e48f0: cb000063    	sub	x3, x3, x0
1005e48f4: f84583e0    	ldur	x0, [sp, #0x58]
1005e48f8: f84103e1    	ldur	x1, [sp, #0x10]
1005e48fc: f84603e7    	ldur	x7, [sp, #0x60]
1005e4900: f84683eb    	ldur	x11, [sp, #0x68]
1005e4904: f84703f8    	ldur	x24, [sp, #0x70]
1005e4908: 14000406    	b	0x1005e5920 <_mech_canonical_program_entry_v1_numeric_1282+0x42a0>
1005e490c: 910005e2    	add	x2, x15, #0x1
1005e4910: eb0f005f    	cmp	x2, x15
1005e4914: 540167e3    	b.lo	0x1005e7610 <_mech_canonical_program_entry_v1_numeric_1282+0x5f90>
1005e4918: f9408be0    	ldr	x0, [sp, #0x110]
1005e491c: eb0001ff    	cmp	x15, x0
1005e4920: 54001443    	b.lo	0x1005e4ba8 <_mech_canonical_program_entry_v1_numeric_1282+0x3528>
1005e4924: 14000b87    	b	0x1005e7740 <_mech_canonical_program_entry_v1_numeric_1282+0x60c0>
1005e4928: f9663663    	ldr	x3, [x19, #0x4c68]
1005e492c: f9663a64    	ldr	x4, [x19, #0x4c70]
1005e4930: d2800000    	mov	x0, #0x0                ; =0
1005e4934: f9263260    	str	x0, [x19, #0x4c60]
1005e4938: d2800060    	mov	x0, #0x3                ; =3
1005e493c: f940c3ef    	ldr	x15, [sp, #0x180]
1005e4940: f80b83e0    	stur	x0, [sp, #0xb8]
1005e4944: f10669ff    	cmp	x15, #0x19a
1005e4948: 5401e183    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e494c: f967ba60    	ldr	x0, [x19, #0x4f70]
1005e4950: f940c7e1    	ldr	x1, [sp, #0x188]
1005e4954: f9000820    	str	x0, [x1, #0x10]
1005e4958: f967be61    	ldr	x1, [x19, #0x4f78]
1005e495c: f940c7e2    	ldr	x2, [sp, #0x188]
1005e4960: f9000c41    	str	x1, [x2, #0x18]
1005e4964: f96d1262    	ldr	x2, [x19, #0x5a20]
1005e4968: f940c7e5    	ldr	x5, [sp, #0x188]
1005e496c: f90560a2    	str	x2, [x5, #0xac0]
1005e4970: f940c7e2    	ldr	x2, [sp, #0x188]
1005e4974: f9000840    	str	x0, [x2, #0x10]
1005e4978: f940c7e0    	ldr	x0, [sp, #0x188]
1005e497c: f9000c01    	str	x1, [x0, #0x18]
1005e4980: f9686260    	ldr	x0, [x19, #0x50c0]
1005e4984: f940c7e1    	ldr	x1, [sp, #0x188]
1005e4988: f900b020    	str	x0, [x1, #0x160]
1005e498c: f9686660    	ldr	x0, [x19, #0x50c8]
1005e4990: f900b440    	str	x0, [x2, #0x168]
1005e4994: f9686a60    	ldr	x0, [x19, #0x50d0]
1005e4998: f900b8a0    	str	x0, [x5, #0x170]
1005e499c: f9686e60    	ldr	x0, [x19, #0x50d8]
1005e49a0: f940c7e8    	ldr	x8, [sp, #0x188]
1005e49a4: f900bd00    	str	x0, [x8, #0x178]
1005e49a8: f9687260    	ldr	x0, [x19, #0x50e0]
1005e49ac: f940c7eb    	ldr	x11, [sp, #0x188]
1005e49b0: f900c160    	str	x0, [x11, #0x180]
1005e49b4: f9687660    	ldr	x0, [x19, #0x50e8]
1005e49b8: f940c7ee    	ldr	x14, [sp, #0x188]
1005e49bc: f900c5c0    	str	x0, [x14, #0x188]
1005e49c0: f9687a60    	ldr	x0, [x19, #0x50f0]
1005e49c4: f900c820    	str	x0, [x1, #0x190]
1005e49c8: f9687e60    	ldr	x0, [x19, #0x50f8]
1005e49cc: f900cc20    	str	x0, [x1, #0x198]
1005e49d0: f9688260    	ldr	x0, [x19, #0x5100]
1005e49d4: f900d020    	str	x0, [x1, #0x1a0]
1005e49d8: f9695660    	ldr	x0, [x19, #0x52a8]
1005e49dc: f901a420    	str	x0, [x1, #0x348]
1005e49e0: f9695a60    	ldr	x0, [x19, #0x52b0]
1005e49e4: f901a820    	str	x0, [x1, #0x350]
1005e49e8: f9695e60    	ldr	x0, [x19, #0x52b8]
1005e49ec: f901ac20    	str	x0, [x1, #0x358]
1005e49f0: f9696260    	ldr	x0, [x19, #0x52c0]
1005e49f4: f901b020    	str	x0, [x1, #0x360]
1005e49f8: f9696660    	ldr	x0, [x19, #0x52c8]
1005e49fc: f901b420    	str	x0, [x1, #0x368]
1005e4a00: f9696a60    	ldr	x0, [x19, #0x52d0]
1005e4a04: f901b820    	str	x0, [x1, #0x370]
1005e4a08: f9696e60    	ldr	x0, [x19, #0x52d8]
1005e4a0c: f901bc20    	str	x0, [x1, #0x378]
1005e4a10: f9697260    	ldr	x0, [x19, #0x52e0]
1005e4a14: f901c020    	str	x0, [x1, #0x380]
1005e4a18: f9697660    	ldr	x0, [x19, #0x52e8]
1005e4a1c: f901c420    	str	x0, [x1, #0x388]
1005e4a20: f96aee60    	ldr	x0, [x19, #0x55d8]
1005e4a24: f9033c20    	str	x0, [x1, #0x678]
1005e4a28: f96af260    	ldr	x0, [x19, #0x55e0]
1005e4a2c: f9034020    	str	x0, [x1, #0x680]
1005e4a30: f96af660    	ldr	x0, [x19, #0x55e8]
1005e4a34: f9034420    	str	x0, [x1, #0x688]
1005e4a38: f96afa60    	ldr	x0, [x19, #0x55f0]
1005e4a3c: f9034820    	str	x0, [x1, #0x690]
1005e4a40: f96afe60    	ldr	x0, [x19, #0x55f8]
1005e4a44: f9034c40    	str	x0, [x2, #0x698]
1005e4a48: f96b0260    	ldr	x0, [x19, #0x5600]
1005e4a4c: f90350a0    	str	x0, [x5, #0x6a0]
1005e4a50: f96b0660    	ldr	x0, [x19, #0x5608]
1005e4a54: f9035500    	str	x0, [x8, #0x6a8]
1005e4a58: f96b0a60    	ldr	x0, [x19, #0x5610]
1005e4a5c: f9035960    	str	x0, [x11, #0x6b0]
1005e4a60: f96bd260    	ldr	x0, [x19, #0x57a0]
1005e4a64: f90421c0    	str	x0, [x14, #0x840]
1005e4a68: f96bd660    	ldr	x0, [x19, #0x57a8]
1005e4a6c: f9042420    	str	x0, [x1, #0x848]
1005e4a70: f96bda60    	ldr	x0, [x19, #0x57b0]
1005e4a74: f9042820    	str	x0, [x1, #0x850]
1005e4a78: f96bde60    	ldr	x0, [x19, #0x57b8]
1005e4a7c: f9042c20    	str	x0, [x1, #0x858]
1005e4a80: f96be260    	ldr	x0, [x19, #0x57c0]
1005e4a84: f9043020    	str	x0, [x1, #0x860]
1005e4a88: f96be660    	ldr	x0, [x19, #0x57c8]
1005e4a8c: f9043420    	str	x0, [x1, #0x868]
1005e4a90: f96bea60    	ldr	x0, [x19, #0x57d0]
1005e4a94: f9043820    	str	x0, [x1, #0x870]
1005e4a98: f96bee60    	ldr	x0, [x19, #0x57d8]
1005e4a9c: f9043c20    	str	x0, [x1, #0x878]
1005e4aa0: f96dda60    	ldr	x0, [x19, #0x5bb0]
1005e4aa4: f9062820    	str	x0, [x1, #0xc50]
1005e4aa8: f96dde61    	ldr	x1, [x19, #0x5bb8]
1005e4aac: f940c7e0    	ldr	x0, [sp, #0x188]
1005e4ab0: f9062c01    	str	x1, [x0, #0xc58]
1005e4ab4: f96de262    	ldr	x2, [x19, #0x5bc0]
1005e4ab8: f9063002    	str	x2, [x0, #0xc60]
1005e4abc: f96de665    	ldr	x5, [x19, #0x5bc8]
1005e4ac0: f9063405    	str	x5, [x0, #0xc68]
1005e4ac4: f96dea65    	ldr	x5, [x19, #0x5bd0]
1005e4ac8: f9063805    	str	x5, [x0, #0xc70]
1005e4acc: f96dee65    	ldr	x5, [x19, #0x5bd8]
1005e4ad0: f9063c05    	str	x5, [x0, #0xc78]
1005e4ad4: d2800006    	mov	x6, #0x0                ; =0
1005e4ad8: f9064006    	str	x6, [x0, #0xc80]
1005e4adc: f96df667    	ldr	x7, [x19, #0x5be8]
1005e4ae0: f9064407    	str	x7, [x0, #0xc88]
1005e4ae4: f96dfa68    	ldr	x8, [x19, #0x5bf0]
1005e4ae8: f9064808    	str	x8, [x0, #0xc90]
1005e4aec: f940c7e1    	ldr	x1, [sp, #0x188]
1005e4af0: f9064c26    	str	x6, [x1, #0xc98]
1005e4af4: f96e026a    	ldr	x10, [x19, #0x5c00]
1005e4af8: f940c7e5    	ldr	x5, [sp, #0x188]
1005e4afc: f90650aa    	str	x10, [x5, #0xca0]
1005e4b00: f96e066b    	ldr	x11, [x19, #0x5c08]
1005e4b04: f940c7e7    	ldr	x7, [sp, #0x188]
1005e4b08: f90654eb    	str	x11, [x7, #0xca8]
1005e4b0c: f940c7e9    	ldr	x9, [sp, #0x188]
1005e4b10: f9065926    	str	x6, [x9, #0xcb0]
1005e4b14: f96e0e6d    	ldr	x13, [x19, #0x5c18]
1005e4b18: f940c7ec    	ldr	x12, [sp, #0x188]
1005e4b1c: f9065d8d    	str	x13, [x12, #0xcb8]
1005e4b20: f96e126e    	ldr	x14, [x19, #0x5c20]
1005e4b24: f940c7ef    	ldr	x15, [sp, #0x188]
1005e4b28: f90661ee    	str	x14, [x15, #0xcc0]
1005e4b2c: d280c0a1    	mov	x1, #0x605              ; =1541
1005e4b30: 92800102    	mov	x2, #-0x9               ; =-9
1005e4b34: f940cff5    	ldr	x21, [sp, #0x198]
1005e4b38: f84083e0    	ldur	x0, [sp, #0x8]
1005e4b3c: aa1403e5    	mov	x5, x20
1005e4b40: f940cbe6    	ldr	x6, [sp, #0x190]
1005e4b44: d63f02a0    	blr	x21
1005e4b48: f100001f    	cmp	x0, #0x0
1005e4b4c: 54016b21    	b.ne	0x1005e78b0 <_mech_canonical_program_entry_v1_numeric_1282+0x6230>
1005e4b50: d2800060    	mov	x0, #0x3                ; =3
1005e4b54: f940c3ef    	ldr	x15, [sp, #0x180]
1005e4b58: f80b83e0    	stur	x0, [sp, #0xb8]
1005e4b5c: f10009ff    	cmp	x15, #0x2
1005e4b60: 5401d0c3    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e4b64: d2800005    	mov	x5, #0x0                ; =0
1005e4b68: f940c7e3    	ldr	x3, [sp, #0x188]
1005e4b6c: f9000065    	str	x5, [x3]
1005e4b70: f94e5e60    	ldr	x0, [x19, #0x1cb8]
1005e4b74: f9000460    	str	x0, [x3, #0x8]
1005e4b78: d280c0a1    	mov	x1, #0x605              ; =1541
1005e4b7c: f84083e0    	ldur	x0, [sp, #0x8]
1005e4b80: f940cbe6    	ldr	x6, [sp, #0x190]
1005e4b84: f940cff5    	ldr	x21, [sp, #0x198]
1005e4b88: aa1403e4    	mov	x4, x20
1005e4b8c: aa0503e2    	mov	x2, x5
1005e4b90: d63f02a0    	blr	x21
1005e4b94: f100001f    	cmp	x0, #0x0
1005e4b98: 54016901    	b.ne	0x1005e78b8 <_mech_canonical_program_entry_v1_numeric_1282+0x6238>
1005e4b9c: d2800060    	mov	x0, #0x3                ; =3
1005e4ba0: f80b83e0    	stur	x0, [sp, #0xb8]
1005e4ba4: 14000e75    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e4ba8: f9408fe6    	ldr	x6, [sp, #0x118]
1005e4bac: f86f78c1    	ldr	x1, [x6, x15, lsl #3]
1005e4bb0: 91000422    	add	x2, x1, #0x1
1005e4bb4: eb01005f    	cmp	x2, x1
1005e4bb8: 54016843    	b.lo	0x1005e78c0 <_mech_canonical_program_entry_v1_numeric_1282+0x6240>
1005e4bbc: f94083e0    	ldr	x0, [sp, #0x100]
1005e4bc0: eb00003f    	cmp	x1, x0
1005e4bc4: 540013a3    	b.lo	0x1005e4e38 <_mech_canonical_program_entry_v1_numeric_1282+0x37b8>
1005e4bc8: 14000b8b    	b	0x1005e79f4 <_mech_canonical_program_entry_v1_numeric_1282+0x6374>
1005e4bcc: f9663663    	ldr	x3, [x19, #0x4c68]
1005e4bd0: f9663a64    	ldr	x4, [x19, #0x4c70]
1005e4bd4: d2800005    	mov	x5, #0x0                ; =0
1005e4bd8: f9263265    	str	x5, [x19, #0x4c60]
1005e4bdc: d2800060    	mov	x0, #0x3                ; =3
1005e4be0: f940c3ef    	ldr	x15, [sp, #0x180]
1005e4be4: f80b83e0    	stur	x0, [sp, #0xb8]
1005e4be8: f10669ff    	cmp	x15, #0x19a
1005e4bec: 5401cc63    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e4bf0: f967ba67    	ldr	x7, [x19, #0x4f70]
1005e4bf4: f940c7ea    	ldr	x10, [sp, #0x188]
1005e4bf8: f9000947    	str	x7, [x10, #0x10]
1005e4bfc: f967be68    	ldr	x8, [x19, #0x4f78]
1005e4c00: f940c7ed    	ldr	x13, [sp, #0x188]
1005e4c04: f9000da8    	str	x8, [x13, #0x18]
1005e4c08: f96d1269    	ldr	x9, [x19, #0x5a20]
1005e4c0c: f940c7e0    	ldr	x0, [sp, #0x188]
1005e4c10: f9056009    	str	x9, [x0, #0xac0]
1005e4c14: f9000807    	str	x7, [x0, #0x10]
1005e4c18: f9000c08    	str	x8, [x0, #0x18]
1005e4c1c: f968626c    	ldr	x12, [x19, #0x50c0]
1005e4c20: f900b00c    	str	x12, [x0, #0x160]
1005e4c24: f968666d    	ldr	x13, [x19, #0x50c8]
1005e4c28: f900b40d    	str	x13, [x0, #0x168]
1005e4c2c: f9686a6e    	ldr	x14, [x19, #0x50d0]
1005e4c30: f900b80e    	str	x14, [x0, #0x170]
1005e4c34: f9686e6f    	ldr	x15, [x19, #0x50d8]
1005e4c38: f900bc0f    	str	x15, [x0, #0x178]
1005e4c3c: f9687260    	ldr	x0, [x19, #0x50e0]
1005e4c40: f940c7e1    	ldr	x1, [sp, #0x188]
1005e4c44: f900c020    	str	x0, [x1, #0x180]
1005e4c48: f9687660    	ldr	x0, [x19, #0x50e8]
1005e4c4c: f900c420    	str	x0, [x1, #0x188]
1005e4c50: f9687a60    	ldr	x0, [x19, #0x50f0]
1005e4c54: f900c820    	str	x0, [x1, #0x190]
1005e4c58: f9687e60    	ldr	x0, [x19, #0x50f8]
1005e4c5c: f900cc20    	str	x0, [x1, #0x198]
1005e4c60: f9688260    	ldr	x0, [x19, #0x5100]
1005e4c64: f900d020    	str	x0, [x1, #0x1a0]
1005e4c68: f9695660    	ldr	x0, [x19, #0x52a8]
1005e4c6c: f901a420    	str	x0, [x1, #0x348]
1005e4c70: f9695a60    	ldr	x0, [x19, #0x52b0]
1005e4c74: f901a820    	str	x0, [x1, #0x350]
1005e4c78: f9695e60    	ldr	x0, [x19, #0x52b8]
1005e4c7c: f901ac20    	str	x0, [x1, #0x358]
1005e4c80: f9696260    	ldr	x0, [x19, #0x52c0]
1005e4c84: f901b020    	str	x0, [x1, #0x360]
1005e4c88: f9696660    	ldr	x0, [x19, #0x52c8]
1005e4c8c: f901b420    	str	x0, [x1, #0x368]
1005e4c90: f9696a60    	ldr	x0, [x19, #0x52d0]
1005e4c94: f940c7e2    	ldr	x2, [sp, #0x188]
1005e4c98: f901b840    	str	x0, [x2, #0x370]
1005e4c9c: f9696e60    	ldr	x0, [x19, #0x52d8]
1005e4ca0: f940c7e5    	ldr	x5, [sp, #0x188]
1005e4ca4: f901bca0    	str	x0, [x5, #0x378]
1005e4ca8: f9697260    	ldr	x0, [x19, #0x52e0]
1005e4cac: f940c7e8    	ldr	x8, [sp, #0x188]
1005e4cb0: f901c100    	str	x0, [x8, #0x380]
1005e4cb4: f9697660    	ldr	x0, [x19, #0x52e8]
1005e4cb8: f940c7eb    	ldr	x11, [sp, #0x188]
1005e4cbc: f901c560    	str	x0, [x11, #0x388]
1005e4cc0: f96aee60    	ldr	x0, [x19, #0x55d8]
1005e4cc4: f940c7ee    	ldr	x14, [sp, #0x188]
1005e4cc8: f9033dc0    	str	x0, [x14, #0x678]
1005e4ccc: f96af260    	ldr	x0, [x19, #0x55e0]
1005e4cd0: f9034020    	str	x0, [x1, #0x680]
1005e4cd4: f96af660    	ldr	x0, [x19, #0x55e8]
1005e4cd8: f9034420    	str	x0, [x1, #0x688]
1005e4cdc: f96afa60    	ldr	x0, [x19, #0x55f0]
1005e4ce0: f9034820    	str	x0, [x1, #0x690]
1005e4ce4: f96afe60    	ldr	x0, [x19, #0x55f8]
1005e4ce8: f9034c20    	str	x0, [x1, #0x698]
1005e4cec: f96b0260    	ldr	x0, [x19, #0x5600]
1005e4cf0: f9035020    	str	x0, [x1, #0x6a0]
1005e4cf4: f96b0660    	ldr	x0, [x19, #0x5608]
1005e4cf8: f9035420    	str	x0, [x1, #0x6a8]
1005e4cfc: f96b0a60    	ldr	x0, [x19, #0x5610]
1005e4d00: f9035820    	str	x0, [x1, #0x6b0]
1005e4d04: f96bd260    	ldr	x0, [x19, #0x57a0]
1005e4d08: f9042020    	str	x0, [x1, #0x840]
1005e4d0c: f96bd660    	ldr	x0, [x19, #0x57a8]
1005e4d10: f9042420    	str	x0, [x1, #0x848]
1005e4d14: f96bda60    	ldr	x0, [x19, #0x57b0]
1005e4d18: f9042820    	str	x0, [x1, #0x850]
1005e4d1c: f96bde60    	ldr	x0, [x19, #0x57b8]
1005e4d20: f9042c20    	str	x0, [x1, #0x858]
1005e4d24: f96be260    	ldr	x0, [x19, #0x57c0]
1005e4d28: f9043020    	str	x0, [x1, #0x860]
1005e4d2c: f96be660    	ldr	x0, [x19, #0x57c8]
1005e4d30: f9043420    	str	x0, [x1, #0x868]
1005e4d34: f96bea60    	ldr	x0, [x19, #0x57d0]
1005e4d38: f9043820    	str	x0, [x1, #0x870]
1005e4d3c: f96bee60    	ldr	x0, [x19, #0x57d8]
1005e4d40: f9043c20    	str	x0, [x1, #0x878]
1005e4d44: f96dda60    	ldr	x0, [x19, #0x5bb0]
1005e4d48: f9062820    	str	x0, [x1, #0xc50]
1005e4d4c: f96dde60    	ldr	x0, [x19, #0x5bb8]
1005e4d50: f9062c40    	str	x0, [x2, #0xc58]
1005e4d54: f96de260    	ldr	x0, [x19, #0x5bc0]
1005e4d58: f90630a0    	str	x0, [x5, #0xc60]
1005e4d5c: f96de660    	ldr	x0, [x19, #0x5bc8]
1005e4d60: f9063500    	str	x0, [x8, #0xc68]
1005e4d64: f96dea60    	ldr	x0, [x19, #0x5bd0]
1005e4d68: f9063960    	str	x0, [x11, #0xc70]
1005e4d6c: f96dee60    	ldr	x0, [x19, #0x5bd8]
1005e4d70: f9063dc0    	str	x0, [x14, #0xc78]
1005e4d74: d2800000    	mov	x0, #0x0                ; =0
1005e4d78: f9064020    	str	x0, [x1, #0xc80]
1005e4d7c: f96df661    	ldr	x1, [x19, #0x5be8]
1005e4d80: f9064441    	str	x1, [x2, #0xc88]
1005e4d84: f96dfa61    	ldr	x1, [x19, #0x5bf0]
1005e4d88: f9064841    	str	x1, [x2, #0xc90]
1005e4d8c: f940c7e1    	ldr	x1, [sp, #0x188]
1005e4d90: f9064c20    	str	x0, [x1, #0xc98]
1005e4d94: f96e0261    	ldr	x1, [x19, #0x5c00]
1005e4d98: f9065041    	str	x1, [x2, #0xca0]
1005e4d9c: f96e0661    	ldr	x1, [x19, #0x5c08]
1005e4da0: f9065441    	str	x1, [x2, #0xca8]
1005e4da4: f940c7e1    	ldr	x1, [sp, #0x188]
1005e4da8: f9065820    	str	x0, [x1, #0xcb0]
1005e4dac: f96e0e60    	ldr	x0, [x19, #0x5c18]
1005e4db0: f9065c20    	str	x0, [x1, #0xcb8]
1005e4db4: f96e1260    	ldr	x0, [x19, #0x5c20]
1005e4db8: f9066020    	str	x0, [x1, #0xcc0]
1005e4dbc: d280c0e1    	mov	x1, #0x607              ; =1543
1005e4dc0: 92800102    	mov	x2, #-0x9               ; =-9
1005e4dc4: f940cff5    	ldr	x21, [sp, #0x198]
1005e4dc8: f84083e0    	ldur	x0, [sp, #0x8]
1005e4dcc: aa1403e5    	mov	x5, x20
1005e4dd0: f940cbe6    	ldr	x6, [sp, #0x190]
1005e4dd4: d63f02a0    	blr	x21
1005e4dd8: f100001f    	cmp	x0, #0x0
1005e4ddc: 54016c61    	b.ne	0x1005e7b68 <_mech_canonical_program_entry_v1_numeric_1282+0x64e8>
1005e4de0: d2800060    	mov	x0, #0x3                ; =3
1005e4de4: f940c3ef    	ldr	x15, [sp, #0x180]
1005e4de8: f80b83e0    	stur	x0, [sp, #0xb8]
1005e4dec: f10009ff    	cmp	x15, #0x2
1005e4df0: 5401bc43    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e4df4: d2800005    	mov	x5, #0x0                ; =0
1005e4df8: f940c7e3    	ldr	x3, [sp, #0x188]
1005e4dfc: f9000065    	str	x5, [x3]
1005e4e00: f94e6666    	ldr	x6, [x19, #0x1cc8]
1005e4e04: f9000466    	str	x6, [x3, #0x8]
1005e4e08: d280c0e1    	mov	x1, #0x607              ; =1543
1005e4e0c: f84083e0    	ldur	x0, [sp, #0x8]
1005e4e10: f940cbe6    	ldr	x6, [sp, #0x190]
1005e4e14: f940cff5    	ldr	x21, [sp, #0x198]
1005e4e18: aa1403e4    	mov	x4, x20
1005e4e1c: aa0503e2    	mov	x2, x5
1005e4e20: d63f02a0    	blr	x21
1005e4e24: f100001f    	cmp	x0, #0x0
1005e4e28: 54016a41    	b.ne	0x1005e7b70 <_mech_canonical_program_entry_v1_numeric_1282+0x64f0>
1005e4e2c: d2800060    	mov	x0, #0x3                ; =3
1005e4e30: f80b83e0    	stur	x0, [sp, #0xb8]
1005e4e34: 14000dd1    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e4e38: f94087e0    	ldr	x0, [sp, #0x108]
1005e4e3c: f861781b    	ldr	x27, [x0, x1, lsl #3]
1005e4e40: f94083e0    	ldr	x0, [sp, #0x100]
1005e4e44: eb00005f    	cmp	x2, x0
1005e4e48: 54001383    	b.lo	0x1005e50b8 <_mech_canonical_program_entry_v1_numeric_1282+0x3a38>
1005e4e4c: 14000b4b    	b	0x1005e7b78 <_mech_canonical_program_entry_v1_numeric_1282+0x64f8>
1005e4e50: f9663663    	ldr	x3, [x19, #0x4c68]
1005e4e54: f9663a64    	ldr	x4, [x19, #0x4c70]
1005e4e58: d2800007    	mov	x7, #0x0                ; =0
1005e4e5c: f9263267    	str	x7, [x19, #0x4c60]
1005e4e60: d2800060    	mov	x0, #0x3                ; =3
1005e4e64: f940c3ef    	ldr	x15, [sp, #0x180]
1005e4e68: f80b83e0    	stur	x0, [sp, #0xb8]
1005e4e6c: f10669ff    	cmp	x15, #0x19a
1005e4e70: 5401b843    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e4e74: f967ba6b    	ldr	x11, [x19, #0x4f70]
1005e4e78: f940c7e0    	ldr	x0, [sp, #0x188]
1005e4e7c: f900080b    	str	x11, [x0, #0x10]
1005e4e80: f967be6c    	ldr	x12, [x19, #0x4f78]
1005e4e84: f9000c0c    	str	x12, [x0, #0x18]
1005e4e88: f96d126d    	ldr	x13, [x19, #0x5a20]
1005e4e8c: f905600d    	str	x13, [x0, #0xac0]
1005e4e90: f900080b    	str	x11, [x0, #0x10]
1005e4e94: f9000c0c    	str	x12, [x0, #0x18]
1005e4e98: f9686260    	ldr	x0, [x19, #0x50c0]
1005e4e9c: f940c7e1    	ldr	x1, [sp, #0x188]
1005e4ea0: f900b020    	str	x0, [x1, #0x160]
1005e4ea4: f9686660    	ldr	x0, [x19, #0x50c8]
1005e4ea8: f900b420    	str	x0, [x1, #0x168]
1005e4eac: f9686a60    	ldr	x0, [x19, #0x50d0]
1005e4eb0: f900b820    	str	x0, [x1, #0x170]
1005e4eb4: f9686e60    	ldr	x0, [x19, #0x50d8]
1005e4eb8: f900bc20    	str	x0, [x1, #0x178]
1005e4ebc: f9687260    	ldr	x0, [x19, #0x50e0]
1005e4ec0: f900c020    	str	x0, [x1, #0x180]
1005e4ec4: f9687660    	ldr	x0, [x19, #0x50e8]
1005e4ec8: f900c420    	str	x0, [x1, #0x188]
1005e4ecc: f9687a60    	ldr	x0, [x19, #0x50f0]
1005e4ed0: f900c820    	str	x0, [x1, #0x190]
1005e4ed4: f9687e60    	ldr	x0, [x19, #0x50f8]
1005e4ed8: f940c7e5    	ldr	x5, [sp, #0x188]
1005e4edc: f900cca0    	str	x0, [x5, #0x198]
1005e4ee0: f9688260    	ldr	x0, [x19, #0x5100]
1005e4ee4: f940c7e7    	ldr	x7, [sp, #0x188]
1005e4ee8: f900d0e0    	str	x0, [x7, #0x1a0]
1005e4eec: f9695660    	ldr	x0, [x19, #0x52a8]
1005e4ef0: f940c7ea    	ldr	x10, [sp, #0x188]
1005e4ef4: f901a540    	str	x0, [x10, #0x348]
1005e4ef8: f9695a60    	ldr	x0, [x19, #0x52b0]
1005e4efc: f940c7ed    	ldr	x13, [sp, #0x188]
1005e4f00: f901a9a0    	str	x0, [x13, #0x350]
1005e4f04: f9695e60    	ldr	x0, [x19, #0x52b8]
1005e4f08: f901ac20    	str	x0, [x1, #0x358]
1005e4f0c: f9696260    	ldr	x0, [x19, #0x52c0]
1005e4f10: f901b020    	str	x0, [x1, #0x360]
1005e4f14: f9696660    	ldr	x0, [x19, #0x52c8]
1005e4f18: f901b420    	str	x0, [x1, #0x368]
1005e4f1c: f9696a60    	ldr	x0, [x19, #0x52d0]
1005e4f20: f901b820    	str	x0, [x1, #0x370]
1005e4f24: f9696e60    	ldr	x0, [x19, #0x52d8]
1005e4f28: f901bc20    	str	x0, [x1, #0x378]
1005e4f2c: f9697260    	ldr	x0, [x19, #0x52e0]
1005e4f30: f901c020    	str	x0, [x1, #0x380]
1005e4f34: f9697660    	ldr	x0, [x19, #0x52e8]
1005e4f38: f901c420    	str	x0, [x1, #0x388]
1005e4f3c: f96aee60    	ldr	x0, [x19, #0x55d8]
1005e4f40: f9033c20    	str	x0, [x1, #0x678]
1005e4f44: f96af260    	ldr	x0, [x19, #0x55e0]
1005e4f48: f9034020    	str	x0, [x1, #0x680]
1005e4f4c: f96af660    	ldr	x0, [x19, #0x55e8]
1005e4f50: f9034420    	str	x0, [x1, #0x688]
1005e4f54: f96afa60    	ldr	x0, [x19, #0x55f0]
1005e4f58: f9034820    	str	x0, [x1, #0x690]
1005e4f5c: f96afe60    	ldr	x0, [x19, #0x55f8]
1005e4f60: f9034c20    	str	x0, [x1, #0x698]
1005e4f64: f96b0260    	ldr	x0, [x19, #0x5600]
1005e4f68: f9035020    	str	x0, [x1, #0x6a0]
1005e4f6c: f96b0660    	ldr	x0, [x19, #0x5608]
1005e4f70: f9035420    	str	x0, [x1, #0x6a8]
1005e4f74: f96b0a60    	ldr	x0, [x19, #0x5610]
1005e4f78: f9035820    	str	x0, [x1, #0x6b0]
1005e4f7c: f96bd260    	ldr	x0, [x19, #0x57a0]
1005e4f80: f9042020    	str	x0, [x1, #0x840]
1005e4f84: f96bd660    	ldr	x0, [x19, #0x57a8]
1005e4f88: f9042420    	str	x0, [x1, #0x848]
1005e4f8c: f96bda60    	ldr	x0, [x19, #0x57b0]
1005e4f90: f90428a0    	str	x0, [x5, #0x850]
1005e4f94: f96bde60    	ldr	x0, [x19, #0x57b8]
1005e4f98: f9042ce0    	str	x0, [x7, #0x858]
1005e4f9c: f96be260    	ldr	x0, [x19, #0x57c0]
1005e4fa0: f9043140    	str	x0, [x10, #0x860]
1005e4fa4: f96be660    	ldr	x0, [x19, #0x57c8]
1005e4fa8: f90435a0    	str	x0, [x13, #0x868]
1005e4fac: f96bea60    	ldr	x0, [x19, #0x57d0]
1005e4fb0: f9043820    	str	x0, [x1, #0x870]
1005e4fb4: f96bee60    	ldr	x0, [x19, #0x57d8]
1005e4fb8: f9043c20    	str	x0, [x1, #0x878]
1005e4fbc: f96dda60    	ldr	x0, [x19, #0x5bb0]
1005e4fc0: f9062820    	str	x0, [x1, #0xc50]
1005e4fc4: f96dde60    	ldr	x0, [x19, #0x5bb8]
1005e4fc8: f9062c20    	str	x0, [x1, #0xc58]
1005e4fcc: f96de260    	ldr	x0, [x19, #0x5bc0]
1005e4fd0: f9063020    	str	x0, [x1, #0xc60]
1005e4fd4: f96de660    	ldr	x0, [x19, #0x5bc8]
1005e4fd8: f9063420    	str	x0, [x1, #0xc68]
1005e4fdc: f96dea60    	ldr	x0, [x19, #0x5bd0]
1005e4fe0: f9063820    	str	x0, [x1, #0xc70]
1005e4fe4: f96dee60    	ldr	x0, [x19, #0x5bd8]
1005e4fe8: f9063c20    	str	x0, [x1, #0xc78]
1005e4fec: d2800000    	mov	x0, #0x0                ; =0
1005e4ff0: f9064020    	str	x0, [x1, #0xc80]
1005e4ff4: f96df661    	ldr	x1, [x19, #0x5be8]
1005e4ff8: f940c7e2    	ldr	x2, [sp, #0x188]
1005e4ffc: f9064441    	str	x1, [x2, #0xc88]
1005e5000: f96dfa61    	ldr	x1, [x19, #0x5bf0]
1005e5004: f9064841    	str	x1, [x2, #0xc90]
1005e5008: f940c7e1    	ldr	x1, [sp, #0x188]
1005e500c: f9064c20    	str	x0, [x1, #0xc98]
1005e5010: f96e0261    	ldr	x1, [x19, #0x5c00]
1005e5014: f9065041    	str	x1, [x2, #0xca0]
1005e5018: f96e0661    	ldr	x1, [x19, #0x5c08]
1005e501c: f9065441    	str	x1, [x2, #0xca8]
1005e5020: f940c7e1    	ldr	x1, [sp, #0x188]
1005e5024: f9065820    	str	x0, [x1, #0xcb0]
1005e5028: f96e0e60    	ldr	x0, [x19, #0x5c18]
1005e502c: f9065c20    	str	x0, [x1, #0xcb8]
1005e5030: f96e1261    	ldr	x1, [x19, #0x5c20]
1005e5034: f940c7e0    	ldr	x0, [sp, #0x188]
1005e5038: f9066001    	str	x1, [x0, #0xcc0]
1005e503c: d280c121    	mov	x1, #0x609              ; =1545
1005e5040: 92800102    	mov	x2, #-0x9               ; =-9
1005e5044: f940cfe7    	ldr	x7, [sp, #0x198]
1005e5048: f84083e0    	ldur	x0, [sp, #0x8]
1005e504c: aa1503e5    	mov	x5, x21
1005e5050: f940cbe6    	ldr	x6, [sp, #0x190]
1005e5054: d63f00e0    	blr	x7
1005e5058: f100001f    	cmp	x0, #0x0
1005e505c: 540164a1    	b.ne	0x1005e7cf0 <_mech_canonical_program_entry_v1_numeric_1282+0x6670>
1005e5060: d2800060    	mov	x0, #0x3                ; =3
1005e5064: f940c3ef    	ldr	x15, [sp, #0x180]
1005e5068: f80b83e0    	stur	x0, [sp, #0xb8]
1005e506c: f10009ff    	cmp	x15, #0x2
1005e5070: 5401a843    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e5074: d2800005    	mov	x5, #0x0                ; =0
1005e5078: f940c7e3    	ldr	x3, [sp, #0x188]
1005e507c: f9000065    	str	x5, [x3]
1005e5080: f94e6e6a    	ldr	x10, [x19, #0x1cd8]
1005e5084: f900046a    	str	x10, [x3, #0x8]
1005e5088: d280c121    	mov	x1, #0x609              ; =1545
1005e508c: f84083e0    	ldur	x0, [sp, #0x8]
1005e5090: f940cbe6    	ldr	x6, [sp, #0x190]
1005e5094: f940cfe7    	ldr	x7, [sp, #0x198]
1005e5098: aa1503e4    	mov	x4, x21
1005e509c: aa0503e2    	mov	x2, x5
1005e50a0: d63f00e0    	blr	x7
1005e50a4: f100001f    	cmp	x0, #0x0
1005e50a8: 54016281    	b.ne	0x1005e7cf8 <_mech_canonical_program_entry_v1_numeric_1282+0x6678>
1005e50ac: d2800060    	mov	x0, #0x3                ; =3
1005e50b0: f80b83e0    	stur	x0, [sp, #0xb8]
1005e50b4: 14000d31    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e50b8: f94087e0    	ldr	x0, [sp, #0x108]
1005e50bc: f862780d    	ldr	x13, [x0, x2, lsl #3]
1005e50c0: 5284c8c0    	mov	w0, #0x2646             ; =9798
1005e50c4: 72a00020    	movk	w0, #0x1, lsl #16
1005e50c8: cb000063    	sub	x3, x3, x0
1005e50cc: d2800002    	mov	x2, #0x0                ; =0
1005e50d0: f80483e2    	stur	x2, [sp, #0x48]
1005e50d4: f84583e0    	ldur	x0, [sp, #0x58]
1005e50d8: f84103e1    	ldur	x1, [sp, #0x10]
1005e50dc: f84603e7    	ldur	x7, [sp, #0x60]
1005e50e0: f84683eb    	ldur	x11, [sp, #0x68]
1005e50e4: f84703f8    	ldur	x24, [sp, #0x70]
1005e50e8: 529970c2    	mov	w2, #0xcb86             ; =52102
1005e50ec: 72a00042    	movk	w2, #0x2, lsl #16
1005e50f0: eb02007f    	cmp	x3, x2
1005e50f4: 9a9f37e2    	cset	x2, hs
1005e50f8: f84e83e4    	ldur	x4, [sp, #0xe8]
1005e50fc: 0a040042    	and	w2, w2, w4
1005e5100: 53001c42    	uxtb	w2, w2
1005e5104: b5002082    	cbnz	x2, 0x1005e5514 <_mech_canonical_program_entry_v1_numeric_1282+0x3e94>
1005e5108: d2800005    	mov	x5, #0x0                ; =0
1005e510c: f9000e65    	str	x5, [x19, #0x18]
1005e5110: f900127a    	str	x26, [x19, #0x20]
1005e5114: d2800022    	mov	x2, #0x1                ; =1
1005e5118: f9001a62    	str	x2, [x19, #0x30]
1005e511c: b200c3e4    	mov	x4, #0x101010101010101  ; =72340172838076673
1005e5120: f9001e64    	str	x4, [x19, #0x38]
1005e5124: d2800054    	mov	x20, #0x2               ; =2
1005e5128: f9002274    	str	x20, [x19, #0x40]
1005e512c: d2800064    	mov	x4, #0x3                ; =3
1005e5130: f9002664    	str	x4, [x19, #0x48]
1005e5134: d2800084    	mov	x4, #0x4                ; =4
1005e5138: f9002a64    	str	x4, [x19, #0x50]
1005e513c: b200cfe4    	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e5140: f9003e64    	str	x4, [x19, #0x78]
1005e5144: b200e7e4    	mov	x4, #0x3333333333333333 ; =3689348814741910323
1005e5148: f9004664    	str	x4, [x19, #0x88]
1005e514c: d2800704    	mov	x4, #0x38               ; =56
1005e5150: f9004a64    	str	x4, [x19, #0x90]
1005e5154: d2800744    	mov	x4, #0x3a               ; =58
1005e5158: f9004e64    	str	x4, [x19, #0x98]
1005e515c: b200f3e4    	mov	x4, #0x5555555555555555 ; =6148914691236517205
1005e5160: f9005a64    	str	x4, [x19, #0xb0]
1005e5164: 92ff8004    	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
1005e5168: f9005e64    	str	x4, [x19, #0xb8]
1005e516c: f900c665    	str	x5, [x19, #0x188]
1005e5170: f900ca62    	str	x2, [x19, #0x190]
1005e5174: f90bd276    	str	x22, [x19, #0x17a0]
1005e5178: f90bd677    	str	x23, [x19, #0x17a8]
1005e517c: f84e03e4    	ldur	x4, [sp, #0xe0]
1005e5180: 53001c84    	uxtb	w4, w4
1005e5184: f90bde64    	str	x4, [x19, #0x17b8]
1005e5188: f90e3a6f    	str	x15, [x19, #0x1c70]
1005e518c: f90e3e6c    	str	x12, [x19, #0x1c78]
1005e5190: f90e4276    	str	x22, [x19, #0x1c80]
1005e5194: f90e5679    	str	x25, [x19, #0x1ca8]
1005e5198: f926326a    	str	x10, [x19, #0x4c60]
1005e519c: f9263663    	str	x3, [x19, #0x4c68]
1005e51a0: f84803e4    	ldur	x4, [sp, #0x80]
1005e51a4: f9263a64    	str	x4, [x19, #0x4c70]
1005e51a8: f927ba76    	str	x22, [x19, #0x4f70]
1005e51ac: f927be77    	str	x23, [x19, #0x4f78]
1005e51b0: f92aee6f    	str	x15, [x19, #0x55d8]
1005e51b4: f92af26c    	str	x12, [x19, #0x55e0]
1005e51b8: f92af676    	str	x22, [x19, #0x55e8]
1005e51bc: f84103f9    	ldur	x25, [sp, #0x10]
1005e51c0: f92afa79    	str	x25, [x19, #0x55f0]
1005e51c4: f84583e4    	ldur	x4, [sp, #0x58]
1005e51c8: f92afe64    	str	x4, [x19, #0x55f8]
1005e51cc: f84603e4    	ldur	x4, [sp, #0x60]
1005e51d0: f92b0264    	str	x4, [x19, #0x5600]
1005e51d4: f84683f9    	ldur	x25, [sp, #0x68]
1005e51d8: f92b0679    	str	x25, [x19, #0x5608]
1005e51dc: f84703fa    	ldur	x26, [sp, #0x70]
1005e51e0: f92b0a7a    	str	x26, [x19, #0x5610]
1005e51e4: f84103f9    	ldur	x25, [sp, #0x10]
1005e51e8: f92b4279    	str	x25, [x19, #0x5680]
1005e51ec: f84583e4    	ldur	x4, [sp, #0x58]
1005e51f0: f92b4664    	str	x4, [x19, #0x5688]
1005e51f4: f84603e4    	ldur	x4, [sp, #0x60]
1005e51f8: f92b4a64    	str	x4, [x19, #0x5690]
1005e51fc: f84683f9    	ldur	x25, [sp, #0x68]
1005e5200: f92b4e79    	str	x25, [x19, #0x5698]
1005e5204: f92b527a    	str	x26, [x19, #0x56a0]
1005e5208: f92bd27b    	str	x27, [x19, #0x57a0]
1005e520c: f92bd66d    	str	x13, [x19, #0x57a8]
1005e5210: f92bda76    	str	x22, [x19, #0x57b0]
1005e5214: f92bde61    	str	x1, [x19, #0x57b8]
1005e5218: f92be260    	str	x0, [x19, #0x57c0]
1005e521c: f92be667    	str	x7, [x19, #0x57c8]
1005e5220: f92bea6b    	str	x11, [x19, #0x57d0]
1005e5224: f92bee78    	str	x24, [x19, #0x57d8]
1005e5228: f84503e1    	ldur	x1, [sp, #0x50]
1005e522c: f92d1261    	str	x1, [x19, #0x5a20]
1005e5230: 9100050b    	add	x11, x8, #0x1
1005e5234: f92dda6b    	str	x11, [x19, #0x5bb0]
1005e5238: f84883fa    	ldur	x26, [sp, #0x88]
1005e523c: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e5240: f84903e6    	ldur	x6, [sp, #0x90]
1005e5244: f92de266    	str	x6, [x19, #0x5bc0]
1005e5248: f84783e4    	ldur	x4, [sp, #0x78]
1005e524c: cb03008e    	sub	x14, x4, x3
1005e5250: 52990fcf    	mov	w15, #0xc87e            ; =51326
1005e5254: 72a0002f    	movk	w15, #0x1, lsl #16
1005e5258: 9b0fb96e    	msub	x14, x11, x15, x14
1005e525c: f92de66e    	str	x14, [x19, #0x5bc8]
1005e5260: f92dea65    	str	x5, [x19, #0x5bd0]
1005e5264: f92dee65    	str	x5, [x19, #0x5bd8]
1005e5268: f84983ea    	ldur	x10, [sp, #0x98]
1005e526c: f92df66a    	str	x10, [x19, #0x5be8]
1005e5270: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e5274: f92dfa64    	str	x4, [x19, #0x5bf0]
1005e5278: f92e0262    	str	x2, [x19, #0x5c00]
1005e527c: f84403e7    	ldur	x7, [sp, #0x40]
1005e5280: f92e0667    	str	x7, [x19, #0x5c08]
1005e5284: f92e0e62    	str	x2, [x19, #0x5c18]
1005e5288: f84483e5    	ldur	x5, [sp, #0x48]
1005e528c: f92e1265    	str	x5, [x19, #0x5c20]
1005e5290: f9663260    	ldr	x0, [x19, #0x4c60]
1005e5294: f100001f    	cmp	x0, #0x0
1005e5298: 540012a0    	b.eq	0x1005e54ec <_mech_canonical_program_entry_v1_numeric_1282+0x3e6c>
1005e529c: f9663663    	ldr	x3, [x19, #0x4c68]
1005e52a0: f9663a64    	ldr	x4, [x19, #0x4c70]
1005e52a4: d2800000    	mov	x0, #0x0                ; =0
1005e52a8: f9263260    	str	x0, [x19, #0x4c60]
1005e52ac: d2800060    	mov	x0, #0x3                ; =3
1005e52b0: f940c3ef    	ldr	x15, [sp, #0x180]
1005e52b4: f80b83e0    	stur	x0, [sp, #0xb8]
1005e52b8: f10669ff    	cmp	x15, #0x19a
1005e52bc: 540195e3    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e52c0: f967ba60    	ldr	x0, [x19, #0x4f70]
1005e52c4: f940c7ec    	ldr	x12, [sp, #0x188]
1005e52c8: f9000980    	str	x0, [x12, #0x10]
1005e52cc: f967be61    	ldr	x1, [x19, #0x4f78]
1005e52d0: f940c7ef    	ldr	x15, [sp, #0x188]
1005e52d4: f9000de1    	str	x1, [x15, #0x18]
1005e52d8: f96d1262    	ldr	x2, [x19, #0x5a20]
1005e52dc: f940c7e5    	ldr	x5, [sp, #0x188]
1005e52e0: f90560a2    	str	x2, [x5, #0xac0]
1005e52e4: f96b4262    	ldr	x2, [x19, #0x5680]
1005e52e8: f90390a2    	str	x2, [x5, #0x720]
1005e52ec: f96b4662    	ldr	x2, [x19, #0x5688]
1005e52f0: f90394a2    	str	x2, [x5, #0x728]
1005e52f4: f96b4a62    	ldr	x2, [x19, #0x5690]
1005e52f8: f90398a2    	str	x2, [x5, #0x730]
1005e52fc: f96b4e62    	ldr	x2, [x19, #0x5698]
1005e5300: f9039ca2    	str	x2, [x5, #0x738]
1005e5304: f96b5262    	ldr	x2, [x19, #0x56a0]
1005e5308: f903a0a2    	str	x2, [x5, #0x740]
1005e530c: f940c7e2    	ldr	x2, [sp, #0x188]
1005e5310: f9000840    	str	x0, [x2, #0x10]
1005e5314: f940c7e0    	ldr	x0, [sp, #0x188]
1005e5318: f9000c01    	str	x1, [x0, #0x18]
1005e531c: f9686260    	ldr	x0, [x19, #0x50c0]
1005e5320: f940c7e1    	ldr	x1, [sp, #0x188]
1005e5324: f900b020    	str	x0, [x1, #0x160]
1005e5328: f9686660    	ldr	x0, [x19, #0x50c8]
1005e532c: f900b420    	str	x0, [x1, #0x168]
1005e5330: f9686a60    	ldr	x0, [x19, #0x50d0]
1005e5334: f900b820    	str	x0, [x1, #0x170]
1005e5338: f9686e60    	ldr	x0, [x19, #0x50d8]
1005e533c: f900bc20    	str	x0, [x1, #0x178]
1005e5340: f9687260    	ldr	x0, [x19, #0x50e0]
1005e5344: f900c020    	str	x0, [x1, #0x180]
1005e5348: f9687660    	ldr	x0, [x19, #0x50e8]
1005e534c: f900c420    	str	x0, [x1, #0x188]
1005e5350: f9687a60    	ldr	x0, [x19, #0x50f0]
1005e5354: f900c820    	str	x0, [x1, #0x190]
1005e5358: f9687e60    	ldr	x0, [x19, #0x50f8]
1005e535c: f900cc20    	str	x0, [x1, #0x198]
1005e5360: f9688260    	ldr	x0, [x19, #0x5100]
1005e5364: f900d020    	str	x0, [x1, #0x1a0]
1005e5368: f9695660    	ldr	x0, [x19, #0x52a8]
1005e536c: f901a4a0    	str	x0, [x5, #0x348]
1005e5370: f9695a60    	ldr	x0, [x19, #0x52b0]
1005e5374: f940c7e7    	ldr	x7, [sp, #0x188]
1005e5378: f901a8e0    	str	x0, [x7, #0x350]
1005e537c: f9695e60    	ldr	x0, [x19, #0x52b8]
1005e5380: f940c7ea    	ldr	x10, [sp, #0x188]
1005e5384: f901ad40    	str	x0, [x10, #0x358]
1005e5388: f9696260    	ldr	x0, [x19, #0x52c0]
1005e538c: f940c7ed    	ldr	x13, [sp, #0x188]
1005e5390: f901b1a0    	str	x0, [x13, #0x360]
1005e5394: f9696660    	ldr	x0, [x19, #0x52c8]
1005e5398: f901b420    	str	x0, [x1, #0x368]
1005e539c: f9696a60    	ldr	x0, [x19, #0x52d0]
1005e53a0: f901b820    	str	x0, [x1, #0x370]
1005e53a4: f9696e60    	ldr	x0, [x19, #0x52d8]
1005e53a8: f901bc20    	str	x0, [x1, #0x378]
1005e53ac: f9697260    	ldr	x0, [x19, #0x52e0]
1005e53b0: f901c020    	str	x0, [x1, #0x380]
1005e53b4: f9697660    	ldr	x0, [x19, #0x52e8]
1005e53b8: f901c420    	str	x0, [x1, #0x388]
1005e53bc: f96aee60    	ldr	x0, [x19, #0x55d8]
1005e53c0: f9033c20    	str	x0, [x1, #0x678]
1005e53c4: f96af260    	ldr	x0, [x19, #0x55e0]
1005e53c8: f9034020    	str	x0, [x1, #0x680]
1005e53cc: f96af660    	ldr	x0, [x19, #0x55e8]
1005e53d0: f9034420    	str	x0, [x1, #0x688]
1005e53d4: f96afa60    	ldr	x0, [x19, #0x55f0]
1005e53d8: f9034820    	str	x0, [x1, #0x690]
1005e53dc: f96afe60    	ldr	x0, [x19, #0x55f8]
1005e53e0: f9034c20    	str	x0, [x1, #0x698]
1005e53e4: f96b0260    	ldr	x0, [x19, #0x5600]
1005e53e8: f9035020    	str	x0, [x1, #0x6a0]
1005e53ec: f96b0661    	ldr	x1, [x19, #0x5608]
1005e53f0: f940c7e0    	ldr	x0, [sp, #0x188]
1005e53f4: f9035401    	str	x1, [x0, #0x6a8]
1005e53f8: f96b0a62    	ldr	x2, [x19, #0x5610]
1005e53fc: f9035802    	str	x2, [x0, #0x6b0]
1005e5400: f96bd265    	ldr	x5, [x19, #0x57a0]
1005e5404: f9042005    	str	x5, [x0, #0x840]
1005e5408: f96bd665    	ldr	x5, [x19, #0x57a8]
1005e540c: f9042405    	str	x5, [x0, #0x848]
1005e5410: f96bda65    	ldr	x5, [x19, #0x57b0]
1005e5414: f9042805    	str	x5, [x0, #0x850]
1005e5418: f96bde66    	ldr	x6, [x19, #0x57b8]
1005e541c: f940c7e1    	ldr	x1, [sp, #0x188]
1005e5420: f9042c26    	str	x6, [x1, #0x858]
1005e5424: f96be267    	ldr	x7, [x19, #0x57c0]
1005e5428: f940c7e5    	ldr	x5, [sp, #0x188]
1005e542c: f90430a7    	str	x7, [x5, #0x860]
1005e5430: f96be668    	ldr	x8, [x19, #0x57c8]
1005e5434: f940c7e7    	ldr	x7, [sp, #0x188]
1005e5438: f90434e8    	str	x8, [x7, #0x868]
1005e543c: f96bea69    	ldr	x9, [x19, #0x57d0]
1005e5440: f9043949    	str	x9, [x10, #0x870]
1005e5444: f96bee6a    	ldr	x10, [x19, #0x57d8]
1005e5448: f9043daa    	str	x10, [x13, #0x878]
1005e544c: f96dda6b    	ldr	x11, [x19, #0x5bb0]
1005e5450: f906280b    	str	x11, [x0, #0xc50]
1005e5454: f96dde6c    	ldr	x12, [x19, #0x5bb8]
1005e5458: f9062c0c    	str	x12, [x0, #0xc58]
1005e545c: f96de26d    	ldr	x13, [x19, #0x5bc0]
1005e5460: f906300d    	str	x13, [x0, #0xc60]
1005e5464: f96de66e    	ldr	x14, [x19, #0x5bc8]
1005e5468: f906340e    	str	x14, [x0, #0xc68]
1005e546c: f96dea6f    	ldr	x15, [x19, #0x5bd0]
1005e5470: f906380f    	str	x15, [x0, #0xc70]
1005e5474: f96dee60    	ldr	x0, [x19, #0x5bd8]
1005e5478: f9063c20    	str	x0, [x1, #0xc78]
1005e547c: d2800000    	mov	x0, #0x0                ; =0
1005e5480: f9064020    	str	x0, [x1, #0xc80]
1005e5484: f96df661    	ldr	x1, [x19, #0x5be8]
1005e5488: f940c7e2    	ldr	x2, [sp, #0x188]
1005e548c: f9064441    	str	x1, [x2, #0xc88]
1005e5490: f96dfa61    	ldr	x1, [x19, #0x5bf0]
1005e5494: f9064841    	str	x1, [x2, #0xc90]
1005e5498: f940c7e1    	ldr	x1, [sp, #0x188]
1005e549c: f9064c20    	str	x0, [x1, #0xc98]
1005e54a0: f96e0261    	ldr	x1, [x19, #0x5c00]
1005e54a4: f9065041    	str	x1, [x2, #0xca0]
1005e54a8: f96e0661    	ldr	x1, [x19, #0x5c08]
1005e54ac: f9065441    	str	x1, [x2, #0xca8]
1005e54b0: f940c7e1    	ldr	x1, [sp, #0x188]
1005e54b4: f9065820    	str	x0, [x1, #0xcb0]
1005e54b8: f96e0e60    	ldr	x0, [x19, #0x5c18]
1005e54bc: f9065c20    	str	x0, [x1, #0xcb8]
1005e54c0: f96e1260    	ldr	x0, [x19, #0x5c20]
1005e54c4: f9066020    	str	x0, [x1, #0xcc0]
1005e54c8: d280c221    	mov	x1, #0x611              ; =1553
1005e54cc: 92800102    	mov	x2, #-0x9               ; =-9
1005e54d0: d2800025    	mov	x5, #0x1                ; =1
1005e54d4: f84083e0    	ldur	x0, [sp, #0x8]
1005e54d8: f940cbe6    	ldr	x6, [sp, #0x190]
1005e54dc: f940cff5    	ldr	x21, [sp, #0x198]
1005e54e0: d63f02a0    	blr	x21
1005e54e4: f100001f    	cmp	x0, #0x0
1005e54e8: 540140c1    	b.ne	0x1005e7d00 <_mech_canonical_program_entry_v1_numeric_1282+0x6680>
1005e54ec: d2800000    	mov	x0, #0x0                ; =0
1005e54f0: d28000a1    	mov	x1, #0x5                ; =5
1005e54f4: 9106c3ff    	add	sp, sp, #0x1b0
1005e54f8: a8c153f3    	ldp	x19, x20, [sp], #0x10
1005e54fc: a8c15bf5    	ldp	x21, x22, [sp], #0x10
1005e5500: a8c163f7    	ldp	x23, x24, [sp], #0x10
1005e5504: a8c16bf9    	ldp	x25, x26, [sp], #0x10
1005e5508: a8c173fb    	ldp	x27, x28, [sp], #0x10
1005e550c: a8c17bfd    	ldp	x29, x30, [sp], #0x10
1005e5510: d65f0fff    	retab
1005e5514: eb0d037f    	cmp	x27, x13
1005e5518: 9a9f27e4    	cset	x4, lo
1005e551c: eb0d037f    	cmp	x27, x13
1005e5520: 54000063    	b.lo	0x1005e552c <_mech_canonical_program_entry_v1_numeric_1282+0x3eac>
1005e5524: d2800002    	mov	x2, #0x0                ; =0
1005e5528: 140000a7    	b	0x1005e57c4 <_mech_canonical_program_entry_v1_numeric_1282+0x4144>
1005e552c: f84f03e2    	ldur	x2, [sp, #0xf0]
1005e5530: eb02037f    	cmp	x27, x2
1005e5534: 54001443    	b.lo	0x1005e57bc <_mech_canonical_program_entry_v1_numeric_1282+0x413c>
1005e5538: 140009f4    	b	0x1005e7d08 <_mech_canonical_program_entry_v1_numeric_1282+0x6688>
1005e553c: f9663663    	ldr	x3, [x19, #0x4c68]
1005e5540: f9663a64    	ldr	x4, [x19, #0x4c70]
1005e5544: d2800000    	mov	x0, #0x0                ; =0
1005e5548: f9263260    	str	x0, [x19, #0x4c60]
1005e554c: d2800060    	mov	x0, #0x3                ; =3
1005e5550: f940c3ef    	ldr	x15, [sp, #0x180]
1005e5554: f80b83e0    	stur	x0, [sp, #0xb8]
1005e5558: f10669ff    	cmp	x15, #0x19a
1005e555c: 540180e3    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e5560: f967ba60    	ldr	x0, [x19, #0x4f70]
1005e5564: f940c7e1    	ldr	x1, [sp, #0x188]
1005e5568: f9000820    	str	x0, [x1, #0x10]
1005e556c: f967be61    	ldr	x1, [x19, #0x4f78]
1005e5570: f940c7e5    	ldr	x5, [sp, #0x188]
1005e5574: f9000ca1    	str	x1, [x5, #0x18]
1005e5578: f96d1262    	ldr	x2, [x19, #0x5a20]
1005e557c: f940c7e7    	ldr	x7, [sp, #0x188]
1005e5580: f90560e2    	str	x2, [x7, #0xac0]
1005e5584: f940c7e9    	ldr	x9, [sp, #0x188]
1005e5588: f9000920    	str	x0, [x9, #0x10]
1005e558c: f940c7eb    	ldr	x11, [sp, #0x188]
1005e5590: f9000d61    	str	x1, [x11, #0x18]
1005e5594: f9686260    	ldr	x0, [x19, #0x50c0]
1005e5598: f940c7ee    	ldr	x14, [sp, #0x188]
1005e559c: f900b1c0    	str	x0, [x14, #0x160]
1005e55a0: f9686660    	ldr	x0, [x19, #0x50c8]
1005e55a4: f940c7e1    	ldr	x1, [sp, #0x188]
1005e55a8: f900b420    	str	x0, [x1, #0x168]
1005e55ac: f9686a61    	ldr	x1, [x19, #0x50d0]
1005e55b0: f940c7e0    	ldr	x0, [sp, #0x188]
1005e55b4: f900b801    	str	x1, [x0, #0x170]
1005e55b8: f9686e62    	ldr	x2, [x19, #0x50d8]
1005e55bc: f900bc02    	str	x2, [x0, #0x178]
1005e55c0: f9687265    	ldr	x5, [x19, #0x50e0]
1005e55c4: f900c005    	str	x5, [x0, #0x180]
1005e55c8: f9687665    	ldr	x5, [x19, #0x50e8]
1005e55cc: f900c405    	str	x5, [x0, #0x188]
1005e55d0: f9687a65    	ldr	x5, [x19, #0x50f0]
1005e55d4: f900c805    	str	x5, [x0, #0x190]
1005e55d8: f9687e66    	ldr	x6, [x19, #0x50f8]
1005e55dc: f900cc06    	str	x6, [x0, #0x198]
1005e55e0: f9688267    	ldr	x7, [x19, #0x5100]
1005e55e4: f900d007    	str	x7, [x0, #0x1a0]
1005e55e8: f9695668    	ldr	x8, [x19, #0x52a8]
1005e55ec: f901a408    	str	x8, [x0, #0x348]
1005e55f0: f9695a69    	ldr	x9, [x19, #0x52b0]
1005e55f4: f901a809    	str	x9, [x0, #0x350]
1005e55f8: f9695e6a    	ldr	x10, [x19, #0x52b8]
1005e55fc: f901ac0a    	str	x10, [x0, #0x358]
1005e5600: f969626b    	ldr	x11, [x19, #0x52c0]
1005e5604: f901b00b    	str	x11, [x0, #0x360]
1005e5608: f969666c    	ldr	x12, [x19, #0x52c8]
1005e560c: f901b40c    	str	x12, [x0, #0x368]
1005e5610: f9696a6d    	ldr	x13, [x19, #0x52d0]
1005e5614: f901b80d    	str	x13, [x0, #0x370]
1005e5618: f9696e6e    	ldr	x14, [x19, #0x52d8]
1005e561c: f901bc0e    	str	x14, [x0, #0x378]
1005e5620: f969726f    	ldr	x15, [x19, #0x52e0]
1005e5624: f901c00f    	str	x15, [x0, #0x380]
1005e5628: f9697660    	ldr	x0, [x19, #0x52e8]
1005e562c: f940c7e2    	ldr	x2, [sp, #0x188]
1005e5630: f901c440    	str	x0, [x2, #0x388]
1005e5634: f96aee60    	ldr	x0, [x19, #0x55d8]
1005e5638: f940c7e5    	ldr	x5, [sp, #0x188]
1005e563c: f9033ca0    	str	x0, [x5, #0x678]
1005e5640: f96af260    	ldr	x0, [x19, #0x55e0]
1005e5644: f940c7e8    	ldr	x8, [sp, #0x188]
1005e5648: f9034100    	str	x0, [x8, #0x680]
1005e564c: f96af660    	ldr	x0, [x19, #0x55e8]
1005e5650: f940c7eb    	ldr	x11, [sp, #0x188]
1005e5654: f9034560    	str	x0, [x11, #0x688]
1005e5658: f96afa60    	ldr	x0, [x19, #0x55f0]
1005e565c: f940c7ee    	ldr	x14, [sp, #0x188]
1005e5660: f90349c0    	str	x0, [x14, #0x690]
1005e5664: f96afe60    	ldr	x0, [x19, #0x55f8]
1005e5668: f940c7e1    	ldr	x1, [sp, #0x188]
1005e566c: f9034c20    	str	x0, [x1, #0x698]
1005e5670: f96b0260    	ldr	x0, [x19, #0x5600]
1005e5674: f9035020    	str	x0, [x1, #0x6a0]
1005e5678: f96b0660    	ldr	x0, [x19, #0x5608]
1005e567c: f9035420    	str	x0, [x1, #0x6a8]
1005e5680: f96b0a60    	ldr	x0, [x19, #0x5610]
1005e5684: f9035820    	str	x0, [x1, #0x6b0]
1005e5688: f96bd260    	ldr	x0, [x19, #0x57a0]
1005e568c: f9042020    	str	x0, [x1, #0x840]
1005e5690: f96bd660    	ldr	x0, [x19, #0x57a8]
1005e5694: f9042420    	str	x0, [x1, #0x848]
1005e5698: f96bda60    	ldr	x0, [x19, #0x57b0]
1005e569c: f9042820    	str	x0, [x1, #0x850]
1005e56a0: f96bde60    	ldr	x0, [x19, #0x57b8]
1005e56a4: f9042c20    	str	x0, [x1, #0x858]
1005e56a8: f96be260    	ldr	x0, [x19, #0x57c0]
1005e56ac: f9043020    	str	x0, [x1, #0x860]
1005e56b0: f96be660    	ldr	x0, [x19, #0x57c8]
1005e56b4: f9043420    	str	x0, [x1, #0x868]
1005e56b8: f96bea60    	ldr	x0, [x19, #0x57d0]
1005e56bc: f9043820    	str	x0, [x1, #0x870]
1005e56c0: f96bee60    	ldr	x0, [x19, #0x57d8]
1005e56c4: f9043c20    	str	x0, [x1, #0x878]
1005e56c8: f96dda60    	ldr	x0, [x19, #0x5bb0]
1005e56cc: f9062820    	str	x0, [x1, #0xc50]
1005e56d0: f96dde60    	ldr	x0, [x19, #0x5bb8]
1005e56d4: f9062c20    	str	x0, [x1, #0xc58]
1005e56d8: f96de260    	ldr	x0, [x19, #0x5bc0]
1005e56dc: f9063020    	str	x0, [x1, #0xc60]
1005e56e0: f96de660    	ldr	x0, [x19, #0x5bc8]
1005e56e4: f9063420    	str	x0, [x1, #0xc68]
1005e56e8: f96dea60    	ldr	x0, [x19, #0x5bd0]
1005e56ec: f9063840    	str	x0, [x2, #0xc70]
1005e56f0: f96dee60    	ldr	x0, [x19, #0x5bd8]
1005e56f4: f9063ca0    	str	x0, [x5, #0xc78]
1005e56f8: d2800000    	mov	x0, #0x0                ; =0
1005e56fc: f9064100    	str	x0, [x8, #0xc80]
1005e5700: f96df661    	ldr	x1, [x19, #0x5be8]
1005e5704: f9064561    	str	x1, [x11, #0xc88]
1005e5708: f96dfa61    	ldr	x1, [x19, #0x5bf0]
1005e570c: f90649c1    	str	x1, [x14, #0xc90]
1005e5710: f940c7e1    	ldr	x1, [sp, #0x188]
1005e5714: f9064c20    	str	x0, [x1, #0xc98]
1005e5718: f96e0261    	ldr	x1, [x19, #0x5c00]
1005e571c: f9065041    	str	x1, [x2, #0xca0]
1005e5720: f96e0661    	ldr	x1, [x19, #0x5c08]
1005e5724: f9065441    	str	x1, [x2, #0xca8]
1005e5728: f940c7e1    	ldr	x1, [sp, #0x188]
1005e572c: f9065820    	str	x0, [x1, #0xcb0]
1005e5730: f96e0e60    	ldr	x0, [x19, #0x5c18]
1005e5734: f9065c20    	str	x0, [x1, #0xcb8]
1005e5738: f96e1260    	ldr	x0, [x19, #0x5c20]
1005e573c: f9066020    	str	x0, [x1, #0xcc0]
1005e5740: d280c421    	mov	x1, #0x621              ; =1569
1005e5744: 92800102    	mov	x2, #-0x9               ; =-9
1005e5748: f940cff5    	ldr	x21, [sp, #0x198]
1005e574c: f84083e0    	ldur	x0, [sp, #0x8]
1005e5750: aa1403e5    	mov	x5, x20
1005e5754: f940cbe6    	ldr	x6, [sp, #0x190]
1005e5758: d63f02a0    	blr	x21
1005e575c: f100001f    	cmp	x0, #0x0
1005e5760: 54013a81    	b.ne	0x1005e7eb0 <_mech_canonical_program_entry_v1_numeric_1282+0x6830>
1005e5764: d2800060    	mov	x0, #0x3                ; =3
1005e5768: f940c3ef    	ldr	x15, [sp, #0x180]
1005e576c: f80b83e0    	stur	x0, [sp, #0xb8]
1005e5770: f10009ff    	cmp	x15, #0x2
1005e5774: 54017023    	b.lo	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e5778: d2800005    	mov	x5, #0x0                ; =0
1005e577c: f940c7e3    	ldr	x3, [sp, #0x188]
1005e5780: f9000065    	str	x5, [x3]
1005e5784: f94eb660    	ldr	x0, [x19, #0x1d68]
1005e5788: f9000460    	str	x0, [x3, #0x8]
1005e578c: d280c421    	mov	x1, #0x621              ; =1569
1005e5790: f84083e0    	ldur	x0, [sp, #0x8]
1005e5794: f940cbe6    	ldr	x6, [sp, #0x190]
1005e5798: f940cff5    	ldr	x21, [sp, #0x198]
1005e579c: aa1403e4    	mov	x4, x20
1005e57a0: aa0503e2    	mov	x2, x5
1005e57a4: d63f02a0    	blr	x21
1005e57a8: f100001f    	cmp	x0, #0x0
1005e57ac: 54013861    	b.ne	0x1005e7eb8 <_mech_canonical_program_entry_v1_numeric_1282+0x6838>
1005e57b0: d2800060    	mov	x0, #0x3                ; =3
1005e57b4: f80b83e0    	stur	x0, [sp, #0xb8]
1005e57b8: 14000b70    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e57bc: f84f83e5    	ldur	x5, [sp, #0xf8]
1005e57c0: f87b78a2    	ldr	x2, [x5, x27, lsl #3]
1005e57c4: 92ff8009    	mov	x9, #0x3ffffffffffffff  ; =288230376151711743
1005e57c8: f80c03e9    	stur	x9, [sp, #0xc0]
1005e57cc: d240e446    	eor	x6, x2, #0x3ffffffffffffff
1005e57d0: b24604c9    	orr	x9, x6, #0xc00000000000000
1005e57d4: eb18013f    	cmp	x9, x24
1005e57d8: 9a9f97e9    	cset	x9, hi
1005e57dc: 0a090089    	and	w9, w4, w9
1005e57e0: 53001d25    	uxtb	w5, w9
1005e57e4: 370000e5    	tbnz	w5, #0x0, 0x1005e5800 <_mech_canonical_program_entry_v1_numeric_1282+0x4180>
1005e57e8: aa0103e2    	mov	x2, x1
1005e57ec: aa0003e4    	mov	x4, x0
1005e57f0: aa0703e6    	mov	x6, x7
1005e57f4: aa0b03e9    	mov	x9, x11
1005e57f8: aa1803f4    	mov	x20, x24
1005e57fc: 14000032    	b	0x1005e58c4 <_mech_canonical_program_entry_v1_numeric_1282+0x4244>
1005e5800: eb16005f    	cmp	x2, x22
1005e5804: 540000e1    	b.ne	0x1005e5820 <_mech_canonical_program_entry_v1_numeric_1282+0x41a0>
1005e5808: aa0103e2    	mov	x2, x1
1005e580c: aa0003e4    	mov	x4, x0
1005e5810: aa0703e6    	mov	x6, x7
1005e5814: aa0b03e9    	mov	x9, x11
1005e5818: aa1803f4    	mov	x20, x24
1005e581c: 1400002a    	b	0x1005e58c4 <_mech_canonical_program_entry_v1_numeric_1282+0x4244>
1005e5820: 9240e424    	and	x4, x1, #0x3ffffffffffffff
1005e5824: d240e442    	eor	x2, x2, #0x3ffffffffffffff
1005e5828: eb04005f    	cmp	x2, x4
1005e582c: 9a9f07e4    	cset	x4, ne
1005e5830: 9240e409    	and	x9, x0, #0x3ffffffffffffff
1005e5834: eb09005f    	cmp	x2, x9
1005e5838: 9a9f07e9    	cset	x9, ne
1005e583c: 0a090084    	and	w4, w4, w9
1005e5840: 9240e4e9    	and	x9, x7, #0x3ffffffffffffff
1005e5844: eb09005f    	cmp	x2, x9
1005e5848: 9a9f07e9    	cset	x9, ne
1005e584c: 0a090084    	and	w4, w4, w9
1005e5850: 9240e569    	and	x9, x11, #0x3ffffffffffffff
1005e5854: eb09005f    	cmp	x2, x9
1005e5858: 9a9f07e2    	cset	x2, ne
1005e585c: 0a020082    	and	w2, w4, w2
1005e5860: 53001c42    	uxtb	w2, w2
1005e5864: 370000e2    	tbnz	w2, #0x0, 0x1005e5880 <_mech_canonical_program_entry_v1_numeric_1282+0x4200>
1005e5868: aa0103e2    	mov	x2, x1
1005e586c: aa0003e4    	mov	x4, x0
1005e5870: aa0703e6    	mov	x6, x7
1005e5874: aa0b03e9    	mov	x9, x11
1005e5878: aa1803f4    	mov	x20, x24
1005e587c: 14000012    	b	0x1005e58c4 <_mech_canonical_program_entry_v1_numeric_1282+0x4244>
1005e5880: b24604c9    	orr	x9, x6, #0xc00000000000000
1005e5884: eb01013f    	cmp	x9, x1
1005e5888: 9a818122    	csel	x2, x9, x1, hi
1005e588c: eb01013f    	cmp	x9, x1
1005e5890: 9a813129    	csel	x9, x9, x1, lo
1005e5894: eb00013f    	cmp	x9, x0
1005e5898: 9a808124    	csel	x4, x9, x0, hi
1005e589c: eb00013f    	cmp	x9, x0
1005e58a0: 9a803129    	csel	x9, x9, x0, lo
1005e58a4: eb07013f    	cmp	x9, x7
1005e58a8: 9a878126    	csel	x6, x9, x7, hi
1005e58ac: eb07013f    	cmp	x9, x7
1005e58b0: 9a873134    	csel	x20, x9, x7, lo
1005e58b4: eb0b029f    	cmp	x20, x11
1005e58b8: 9a8b8289    	csel	x9, x20, x11, hi
1005e58bc: eb0b029f    	cmp	x20, x11
1005e58c0: 9a8b3294    	csel	x20, x20, x11, lo
1005e58c4: 37005605    	tbnz	w5, #0x0, 0x1005e6384 <_mech_canonical_program_entry_v1_numeric_1282+0x4d04>
1005e58c8: d2800002    	mov	x2, #0x0                ; =0
1005e58cc: f90fe382    	str	x2, [x28, #0x1fc0]
1005e58d0: f90fe782    	str	x2, [x28, #0x1fc8]
1005e58d4: f90feb82    	str	x2, [x28, #0x1fd0]
1005e58d8: f90fef82    	str	x2, [x28, #0x1fd8]
1005e58dc: f90ff382    	str	x2, [x28, #0x1fe0]
1005e58e0: f90ff782    	str	x2, [x28, #0x1fe8]
1005e58e4: f90ffb82    	str	x2, [x28, #0x1ff0]
1005e58e8: f90fff82    	str	x2, [x28, #0x1ff8]
1005e58ec: f9100382    	str	x2, [x28, #0x2000]
1005e58f0: f9100782    	str	x2, [x28, #0x2008]
1005e58f4: f9100b82    	str	x2, [x28, #0x2010]
1005e58f8: f9100f82    	str	x2, [x28, #0x2018]
1005e58fc: f9101382    	str	x2, [x28, #0x2020]
1005e5900: f9101782    	str	x2, [x28, #0x2028]
1005e5904: f9101b82    	str	x2, [x28, #0x2030]
1005e5908: f9101f82    	str	x2, [x28, #0x2038]
1005e590c: 529970c2    	mov	w2, #0xcb86             ; =52102
1005e5910: 72a00042    	movk	w2, #0x2, lsl #16
1005e5914: cb020063    	sub	x3, x3, x2
1005e5918: d280000d    	mov	x13, #0x0               ; =0
1005e591c: f80a83ed    	stur	x13, [sp, #0xa8]
1005e5920: 370051b9    	tbnz	w25, #0x0, 0x1005e6354 <_mech_canonical_program_entry_v1_numeric_1282+0x4cd4>
1005e5924: d2800000    	mov	x0, #0x0                ; =0
1005e5928: f90e1b80    	str	x0, [x28, #0x1c30]
1005e592c: f90e1f80    	str	x0, [x28, #0x1c38]
1005e5930: f90e2380    	str	x0, [x28, #0x1c40]
1005e5934: f90e2780    	str	x0, [x28, #0x1c48]
1005e5938: f90e2b80    	str	x0, [x28, #0x1c50]
1005e593c: f90e2f80    	str	x0, [x28, #0x1c58]
1005e5940: f90e3380    	str	x0, [x28, #0x1c60]
1005e5944: f90e3780    	str	x0, [x28, #0x1c68]
1005e5948: f90e3b80    	str	x0, [x28, #0x1c70]
1005e594c: f90e3f80    	str	x0, [x28, #0x1c78]
1005e5950: f90e4380    	str	x0, [x28, #0x1c80]
1005e5954: f90e4780    	str	x0, [x28, #0x1c88]
1005e5958: f90e4b80    	str	x0, [x28, #0x1c90]
1005e595c: f90e4f80    	str	x0, [x28, #0x1c98]
1005e5960: f90e5380    	str	x0, [x28, #0x1ca0]
1005e5964: f90e5780    	str	x0, [x28, #0x1ca8]
1005e5968: d2800019    	mov	x25, #0x0               ; =0
1005e596c: aa1903eb    	mov	x11, x25
1005e5970: aa1903ec    	mov	x12, x25
1005e5974: aa1903ef    	mov	x15, x25
1005e5978: aa1603f8    	mov	x24, x22
1005e597c: aa1603fb    	mov	x27, x22
1005e5980: eb1702df    	cmp	x22, x23
1005e5984: 54000063    	b.lo	0x1005e5990 <_mech_canonical_program_entry_v1_numeric_1282+0x4310>
1005e5988: 91000508    	add	x8, x8, #0x1
1005e598c: 14000222    	b	0x1005e6214 <_mech_canonical_program_entry_v1_numeric_1282+0x4b94>
1005e5990: b5000d8e    	cbnz	x14, 0x1005e5b40 <_mech_canonical_program_entry_v1_numeric_1282+0x44c0>
1005e5994: 1400094b    	b	0x1005e7ec0 <_mech_canonical_program_entry_v1_numeric_1282+0x6840>
1005e5998: f940c7e0    	ldr	x0, [sp, #0x188]
1005e599c: f900081b    	str	x27, [x0, #0x10]
1005e59a0: f9000c17    	str	x23, [x0, #0x18]
1005e59a4: f940c7e2    	ldr	x2, [sp, #0x188]
1005e59a8: f900085b    	str	x27, [x2, #0x10]
1005e59ac: f940c7e4    	ldr	x4, [sp, #0x188]
1005e59b0: f9000c97    	str	x23, [x4, #0x18]
1005e59b4: 91000500    	add	x0, x8, #0x1
1005e59b8: f940c7e7    	ldr	x7, [sp, #0x188]
1005e59bc: f90628e0    	str	x0, [x7, #0xc50]
1005e59c0: f940c7e9    	ldr	x9, [sp, #0x188]
1005e59c4: f84883fa    	ldur	x26, [sp, #0x88]
1005e59c8: f9062d3a    	str	x26, [x9, #0xc58]
1005e59cc: f84903e6    	ldur	x6, [sp, #0x90]
1005e59d0: f940c7ee    	ldr	x14, [sp, #0x188]
1005e59d4: f90631c6    	str	x6, [x14, #0xc60]
1005e59d8: f84783e4    	ldur	x4, [sp, #0x78]
1005e59dc: cb030081    	sub	x1, x4, x3
1005e59e0: 52990fc2    	mov	w2, #0xc87e             ; =51326
1005e59e4: 72a00022    	movk	w2, #0x1, lsl #16
1005e59e8: 9b028400    	msub	x0, x0, x2, x1
1005e59ec: f940c7e1    	ldr	x1, [sp, #0x188]
1005e59f0: f9063420    	str	x0, [x1, #0xc68]
1005e59f4: f940c7e0    	ldr	x0, [sp, #0x188]
1005e59f8: f9063819    	str	x25, [x0, #0xc70]
1005e59fc: f9063c0f    	str	x15, [x0, #0xc78]
1005e5a00: d2800005    	mov	x5, #0x0                ; =0
1005e5a04: f9064005    	str	x5, [x0, #0xc80]
1005e5a08: f84983ea    	ldur	x10, [sp, #0x98]
1005e5a0c: f906440a    	str	x10, [x0, #0xc88]
1005e5a10: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e5a14: f9064804    	str	x4, [x0, #0xc90]
1005e5a18: f9064c05    	str	x5, [x0, #0xc98]
1005e5a1c: f906500c    	str	x12, [x0, #0xca0]
1005e5a20: f906540b    	str	x11, [x0, #0xca8]
1005e5a24: f9065805    	str	x5, [x0, #0xcb0]
1005e5a28: f9065c0d    	str	x13, [x0, #0xcb8]
1005e5a2c: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e5a30: f906600d    	str	x13, [x0, #0xcc0]
1005e5a34: f84503e1    	ldur	x1, [sp, #0x50]
1005e5a38: 91000420    	add	x0, x1, #0x1
1005e5a3c: f940c7e1    	ldr	x1, [sp, #0x188]
1005e5a40: f9066820    	str	x0, [x1, #0xcd0]
1005e5a44: f84103f9    	ldur	x25, [sp, #0x10]
1005e5a48: 9240e720    	and	x0, x25, #0x3ffffffffffffff
1005e5a4c: d240e400    	eor	x0, x0, #0x3ffffffffffffff
1005e5a50: f9066c20    	str	x0, [x1, #0xcd8]
1005e5a54: d280d881    	mov	x1, #0x6c4              ; =1732
1005e5a58: 92800342    	mov	x2, #-0x1b              ; =-27
1005e5a5c: f84803e4    	ldur	x4, [sp, #0x80]
1005e5a60: f940cff5    	ldr	x21, [sp, #0x198]
1005e5a64: f84083e0    	ldur	x0, [sp, #0x8]
1005e5a68: f940cbe6    	ldr	x6, [sp, #0x190]
1005e5a6c: d63f02a0    	blr	x21
1005e5a70: d2800041    	mov	x1, #0x2                ; =2
1005e5a74: f80b83e1    	stur	x1, [sp, #0xb8]
1005e5a78: f100001f    	cmp	x0, #0x0
1005e5a7c: 540157e1    	b.ne	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e5a80: f940c7e3    	ldr	x3, [sp, #0x188]
1005e5a84: f9400063    	ldr	x3, [x3]
1005e5a88: f940c7e0    	ldr	x0, [sp, #0x188]
1005e5a8c: f9400404    	ldr	x4, [x0, #0x8]
1005e5a90: f80803e4    	stur	x4, [sp, #0x80]
1005e5a94: f9455c15    	ldr	x21, [x0, #0xab8]
1005e5a98: f945fc0e    	ldr	x14, [x0, #0xbf8]
1005e5a9c: f940c7e1    	ldr	x1, [sp, #0x188]
1005e5aa0: f9456021    	ldr	x1, [x1, #0xac0]
1005e5aa4: f940c7e4    	ldr	x4, [sp, #0x188]
1005e5aa8: f9456480    	ldr	x0, [x4, #0xac8]
1005e5aac: f940c7e5    	ldr	x5, [sp, #0x188]
1005e5ab0: f94568a0    	ldr	x0, [x5, #0xad0]
1005e5ab4: f940c7e7    	ldr	x7, [sp, #0x188]
1005e5ab8: f94624e0    	ldr	x0, [x7, #0xc48]
1005e5abc: f940c7e9    	ldr	x9, [sp, #0x188]
1005e5ac0: f80b03e0    	stur	x0, [sp, #0xb0]
1005e5ac4: f9462928    	ldr	x8, [x9, #0xc50]
1005e5ac8: f940c7eb    	ldr	x11, [sp, #0x188]
1005e5acc: f9462d7a    	ldr	x26, [x11, #0xc58]
1005e5ad0: f940c7ed    	ldr	x13, [sp, #0x188]
1005e5ad4: f80883fa    	stur	x26, [sp, #0x88]
1005e5ad8: f94631a6    	ldr	x6, [x13, #0xc60]
1005e5adc: f940c7ef    	ldr	x15, [sp, #0x188]
1005e5ae0: f80903e6    	stur	x6, [sp, #0x90]
1005e5ae4: f94635e0    	ldr	x0, [x15, #0xc68]
1005e5ae8: f940c7e2    	ldr	x2, [sp, #0x188]
1005e5aec: f9463859    	ldr	x25, [x2, #0xc70]
1005e5af0: f9463c4f    	ldr	x15, [x2, #0xc78]
1005e5af4: f946444a    	ldr	x10, [x2, #0xc88]
1005e5af8: f80983ea    	stur	x10, [sp, #0x98]
1005e5afc: f9464844    	ldr	x4, [x2, #0xc90]
1005e5b00: f80a03e4    	stur	x4, [sp, #0xa0]
1005e5b04: f946504c    	ldr	x12, [x2, #0xca0]
1005e5b08: f946544b    	ldr	x11, [x2, #0xca8]
1005e5b0c: f9465c4d    	ldr	x13, [x2, #0xcb8]
1005e5b10: f9466042    	ldr	x2, [x2, #0xcc0]
1005e5b14: f80a83e2    	stur	x2, [sp, #0xa8]
1005e5b18: f940c7e2    	ldr	x2, [sp, #0x188]
1005e5b1c: f940085c    	ldr	x28, [x2, #0x10]
1005e5b20: d280002a    	mov	x10, #0x1               ; =1
1005e5b24: f926326a    	str	x10, [x19, #0x4c60]
1005e5b28: 8b000060    	add	x0, x3, x0
1005e5b2c: 52990fc2    	mov	w2, #0xc87e             ; =51326
1005e5b30: 72a00022    	movk	w2, #0x1, lsl #16
1005e5b34: 9b020104    	madd	x4, x8, x2, x0
1005e5b38: f80783e4    	stur	x4, [sp, #0x78]
1005e5b3c: 14000008    	b	0x1005e5b5c <_mech_canonical_program_entry_v1_numeric_1282+0x44dc>
1005e5b40: f84103e0    	ldur	x0, [sp, #0x10]
1005e5b44: 9240e400    	and	x0, x0, #0x3ffffffffffffff
1005e5b48: d240e400    	eor	x0, x0, #0x3ffffffffffffff
1005e5b4c: f84503e1    	ldur	x1, [sp, #0x50]
1005e5b50: f8217aa0    	str	x0, [x21, x1, lsl #3]
1005e5b54: 91000421    	add	x1, x1, #0x1
1005e5b58: 91000508    	add	x8, x8, #0x1
1005e5b5c: b5000cce    	cbnz	x14, 0x1005e5cf4 <_mech_canonical_program_entry_v1_numeric_1282+0x4674>
1005e5b60: 140008e3    	b	0x1005e7eec <_mech_canonical_program_entry_v1_numeric_1282+0x686c>
1005e5b64: f940c7e0    	ldr	x0, [sp, #0x188]
1005e5b68: f900081b    	str	x27, [x0, #0x10]
1005e5b6c: f9000c17    	str	x23, [x0, #0x18]
1005e5b70: f940c7e2    	ldr	x2, [sp, #0x188]
1005e5b74: f900085b    	str	x27, [x2, #0x10]
1005e5b78: f940c7e4    	ldr	x4, [sp, #0x188]
1005e5b7c: f9000c97    	str	x23, [x4, #0x18]
1005e5b80: f940c7e6    	ldr	x6, [sp, #0x188]
1005e5b84: f90628c8    	str	x8, [x6, #0xc50]
1005e5b88: f940c7e9    	ldr	x9, [sp, #0x188]
1005e5b8c: f84883fa    	ldur	x26, [sp, #0x88]
1005e5b90: f9062d3a    	str	x26, [x9, #0xc58]
1005e5b94: f84903e6    	ldur	x6, [sp, #0x90]
1005e5b98: f940c7ea    	ldr	x10, [sp, #0x188]
1005e5b9c: f9063146    	str	x6, [x10, #0xc60]
1005e5ba0: f84783e4    	ldur	x4, [sp, #0x78]
1005e5ba4: cb030087    	sub	x7, x4, x3
1005e5ba8: 52990fc9    	mov	w9, #0xc87e             ; =51326
1005e5bac: 72a00029    	movk	w9, #0x1, lsl #16
1005e5bb0: 9b099d07    	msub	x7, x8, x9, x7
1005e5bb4: f9063407    	str	x7, [x0, #0xc68]
1005e5bb8: f9063819    	str	x25, [x0, #0xc70]
1005e5bbc: f9063c0f    	str	x15, [x0, #0xc78]
1005e5bc0: d2800005    	mov	x5, #0x0                ; =0
1005e5bc4: f9064005    	str	x5, [x0, #0xc80]
1005e5bc8: f84983ea    	ldur	x10, [sp, #0x98]
1005e5bcc: f906440a    	str	x10, [x0, #0xc88]
1005e5bd0: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e5bd4: f9064804    	str	x4, [x0, #0xc90]
1005e5bd8: f9064c05    	str	x5, [x0, #0xc98]
1005e5bdc: f906500c    	str	x12, [x0, #0xca0]
1005e5be0: f906540b    	str	x11, [x0, #0xca8]
1005e5be4: f9065805    	str	x5, [x0, #0xcb0]
1005e5be8: f9065c0d    	str	x13, [x0, #0xcb8]
1005e5bec: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e5bf0: f906600d    	str	x13, [x0, #0xcc0]
1005e5bf4: 91000420    	add	x0, x1, #0x1
1005e5bf8: f940c7e1    	ldr	x1, [sp, #0x188]
1005e5bfc: f9066820    	str	x0, [x1, #0xcd0]
1005e5c00: f84583ef    	ldur	x15, [sp, #0x58]
1005e5c04: 9240e5e0    	and	x0, x15, #0x3ffffffffffffff
1005e5c08: d240e400    	eor	x0, x0, #0x3ffffffffffffff
1005e5c0c: f9066c20    	str	x0, [x1, #0xcd8]
1005e5c10: d280d901    	mov	x1, #0x6c8              ; =1736
1005e5c14: 92800342    	mov	x2, #-0x1b              ; =-27
1005e5c18: f84803e4    	ldur	x4, [sp, #0x80]
1005e5c1c: f940cff5    	ldr	x21, [sp, #0x198]
1005e5c20: f84083e0    	ldur	x0, [sp, #0x8]
1005e5c24: f940cbe6    	ldr	x6, [sp, #0x190]
1005e5c28: d63f02a0    	blr	x21
1005e5c2c: d2800042    	mov	x2, #0x2                ; =2
1005e5c30: f80b83e2    	stur	x2, [sp, #0xb8]
1005e5c34: f100001f    	cmp	x0, #0x0
1005e5c38: 54014a01    	b.ne	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e5c3c: f940c7e3    	ldr	x3, [sp, #0x188]
1005e5c40: f9400063    	ldr	x3, [x3]
1005e5c44: f940c7e0    	ldr	x0, [sp, #0x188]
1005e5c48: f9400404    	ldr	x4, [x0, #0x8]
1005e5c4c: f80803e4    	stur	x4, [sp, #0x80]
1005e5c50: f9455c15    	ldr	x21, [x0, #0xab8]
1005e5c54: f945fc0e    	ldr	x14, [x0, #0xbf8]
1005e5c58: f9456001    	ldr	x1, [x0, #0xac0]
1005e5c5c: f940c7e2    	ldr	x2, [sp, #0x188]
1005e5c60: f9456440    	ldr	x0, [x2, #0xac8]
1005e5c64: f940c7e4    	ldr	x4, [sp, #0x188]
1005e5c68: f9456880    	ldr	x0, [x4, #0xad0]
1005e5c6c: f940c7e6    	ldr	x6, [sp, #0x188]
1005e5c70: f94624ca    	ldr	x10, [x6, #0xc48]
1005e5c74: f940c7e8    	ldr	x8, [sp, #0x188]
1005e5c78: f80b03ea    	stur	x10, [sp, #0xb0]
1005e5c7c: f9462908    	ldr	x8, [x8, #0xc50]
1005e5c80: f940c7ea    	ldr	x10, [sp, #0x188]
1005e5c84: f9462d5a    	ldr	x26, [x10, #0xc58]
1005e5c88: f940c7ec    	ldr	x12, [sp, #0x188]
1005e5c8c: f80883fa    	stur	x26, [sp, #0x88]
1005e5c90: f9463186    	ldr	x6, [x12, #0xc60]
1005e5c94: f940c7ef    	ldr	x15, [sp, #0x188]
1005e5c98: f80903e6    	stur	x6, [sp, #0x90]
1005e5c9c: f94635e0    	ldr	x0, [x15, #0xc68]
1005e5ca0: f9463859    	ldr	x25, [x2, #0xc70]
1005e5ca4: f9463c4f    	ldr	x15, [x2, #0xc78]
1005e5ca8: f946444a    	ldr	x10, [x2, #0xc88]
1005e5cac: f80983ea    	stur	x10, [sp, #0x98]
1005e5cb0: f9464844    	ldr	x4, [x2, #0xc90]
1005e5cb4: f80a03e4    	stur	x4, [sp, #0xa0]
1005e5cb8: f946504c    	ldr	x12, [x2, #0xca0]
1005e5cbc: f946544b    	ldr	x11, [x2, #0xca8]
1005e5cc0: f9465c4d    	ldr	x13, [x2, #0xcb8]
1005e5cc4: f9466042    	ldr	x2, [x2, #0xcc0]
1005e5cc8: f80a83e2    	stur	x2, [sp, #0xa8]
1005e5ccc: f940c7e2    	ldr	x2, [sp, #0x188]
1005e5cd0: f940085c    	ldr	x28, [x2, #0x10]
1005e5cd4: d280002a    	mov	x10, #0x1               ; =1
1005e5cd8: f926326a    	str	x10, [x19, #0x4c60]
1005e5cdc: 8b000060    	add	x0, x3, x0
1005e5ce0: 52990fc2    	mov	w2, #0xc87e             ; =51326
1005e5ce4: 72a00022    	movk	w2, #0x1, lsl #16
1005e5ce8: 9b020104    	madd	x4, x8, x2, x0
1005e5cec: f80783e4    	stur	x4, [sp, #0x78]
1005e5cf0: 14000006    	b	0x1005e5d08 <_mech_canonical_program_entry_v1_numeric_1282+0x4688>
1005e5cf4: f84583e0    	ldur	x0, [sp, #0x58]
1005e5cf8: 9240e400    	and	x0, x0, #0x3ffffffffffffff
1005e5cfc: d240e400    	eor	x0, x0, #0x3ffffffffffffff
1005e5d00: f8217aa0    	str	x0, [x21, x1, lsl #3]
1005e5d04: 91000421    	add	x1, x1, #0x1
1005e5d08: b5000cce    	cbnz	x14, 0x1005e5ea0 <_mech_canonical_program_entry_v1_numeric_1282+0x4820>
1005e5d0c: 14000883    	b	0x1005e7f18 <_mech_canonical_program_entry_v1_numeric_1282+0x6898>
1005e5d10: f940c7e0    	ldr	x0, [sp, #0x188]
1005e5d14: f900081b    	str	x27, [x0, #0x10]
1005e5d18: f9000c17    	str	x23, [x0, #0x18]
1005e5d1c: f900081b    	str	x27, [x0, #0x10]
1005e5d20: f940c7e2    	ldr	x2, [sp, #0x188]
1005e5d24: f9000c57    	str	x23, [x2, #0x18]
1005e5d28: f940c7e4    	ldr	x4, [sp, #0x188]
1005e5d2c: f9062888    	str	x8, [x4, #0xc50]
1005e5d30: f940c7e6    	ldr	x6, [sp, #0x188]
1005e5d34: f84883fa    	ldur	x26, [sp, #0x88]
1005e5d38: f9062cda    	str	x26, [x6, #0xc58]
1005e5d3c: f84903e6    	ldur	x6, [sp, #0x90]
1005e5d40: f940c7e9    	ldr	x9, [sp, #0x188]
1005e5d44: f9063126    	str	x6, [x9, #0xc60]
1005e5d48: f84783e4    	ldur	x4, [sp, #0x78]
1005e5d4c: cb030080    	sub	x0, x4, x3
1005e5d50: 52990fc2    	mov	w2, #0xc87e             ; =51326
1005e5d54: 72a00022    	movk	w2, #0x1, lsl #16
1005e5d58: 9b028100    	msub	x0, x8, x2, x0
1005e5d5c: f940c7ee    	ldr	x14, [sp, #0x188]
1005e5d60: f90635c0    	str	x0, [x14, #0xc68]
1005e5d64: f940c7e0    	ldr	x0, [sp, #0x188]
1005e5d68: f9063819    	str	x25, [x0, #0xc70]
1005e5d6c: f9063c0f    	str	x15, [x0, #0xc78]
1005e5d70: d2800005    	mov	x5, #0x0                ; =0
1005e5d74: f9064005    	str	x5, [x0, #0xc80]
1005e5d78: f84983ea    	ldur	x10, [sp, #0x98]
1005e5d7c: f906440a    	str	x10, [x0, #0xc88]
1005e5d80: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e5d84: f9064804    	str	x4, [x0, #0xc90]
1005e5d88: f9064c05    	str	x5, [x0, #0xc98]
1005e5d8c: f906500c    	str	x12, [x0, #0xca0]
1005e5d90: f906540b    	str	x11, [x0, #0xca8]
1005e5d94: f9065805    	str	x5, [x0, #0xcb0]
1005e5d98: f9065c0d    	str	x13, [x0, #0xcb8]
1005e5d9c: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e5da0: f906600d    	str	x13, [x0, #0xcc0]
1005e5da4: 91000420    	add	x0, x1, #0x1
1005e5da8: f940c7e1    	ldr	x1, [sp, #0x188]
1005e5dac: f9066820    	str	x0, [x1, #0xcd0]
1005e5db0: f84603e0    	ldur	x0, [sp, #0x60]
1005e5db4: 9240e400    	and	x0, x0, #0x3ffffffffffffff
1005e5db8: d240e400    	eor	x0, x0, #0x3ffffffffffffff
1005e5dbc: f9066c20    	str	x0, [x1, #0xcd8]
1005e5dc0: d280d981    	mov	x1, #0x6cc              ; =1740
1005e5dc4: 92800342    	mov	x2, #-0x1b              ; =-27
1005e5dc8: f84803e4    	ldur	x4, [sp, #0x80]
1005e5dcc: f940cff5    	ldr	x21, [sp, #0x198]
1005e5dd0: f84083e0    	ldur	x0, [sp, #0x8]
1005e5dd4: f940cbe6    	ldr	x6, [sp, #0x190]
1005e5dd8: d63f02a0    	blr	x21
1005e5ddc: d2800041    	mov	x1, #0x2                ; =2
1005e5de0: f80b83e1    	stur	x1, [sp, #0xb8]
1005e5de4: f100001f    	cmp	x0, #0x0
1005e5de8: 54013c81    	b.ne	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e5dec: f940c7e3    	ldr	x3, [sp, #0x188]
1005e5df0: f9400063    	ldr	x3, [x3]
1005e5df4: f940c7e0    	ldr	x0, [sp, #0x188]
1005e5df8: f9400404    	ldr	x4, [x0, #0x8]
1005e5dfc: f80803e4    	stur	x4, [sp, #0x80]
1005e5e00: f9455c15    	ldr	x21, [x0, #0xab8]
1005e5e04: f945fc0e    	ldr	x14, [x0, #0xbf8]
1005e5e08: f9456001    	ldr	x1, [x0, #0xac0]
1005e5e0c: f9456400    	ldr	x0, [x0, #0xac8]
1005e5e10: f940c7e2    	ldr	x2, [sp, #0x188]
1005e5e14: f9456840    	ldr	x0, [x2, #0xad0]
1005e5e18: f940c7e4    	ldr	x4, [sp, #0x188]
1005e5e1c: f9462480    	ldr	x0, [x4, #0xc48]
1005e5e20: f940c7e6    	ldr	x6, [sp, #0x188]
1005e5e24: f80b03e0    	stur	x0, [sp, #0xb0]
1005e5e28: f94628c8    	ldr	x8, [x6, #0xc50]
1005e5e2c: f940c7e9    	ldr	x9, [sp, #0x188]
1005e5e30: f9462d3a    	ldr	x26, [x9, #0xc58]
1005e5e34: f940c7ea    	ldr	x10, [sp, #0x188]
1005e5e38: f80883fa    	stur	x26, [sp, #0x88]
1005e5e3c: f9463146    	ldr	x6, [x10, #0xc60]
1005e5e40: f940c7ec    	ldr	x12, [sp, #0x188]
1005e5e44: f80903e6    	stur	x6, [sp, #0x90]
1005e5e48: f9463580    	ldr	x0, [x12, #0xc68]
1005e5e4c: f940c7ef    	ldr	x15, [sp, #0x188]
1005e5e50: f94639f9    	ldr	x25, [x15, #0xc70]
1005e5e54: f9463c4f    	ldr	x15, [x2, #0xc78]
1005e5e58: f946444a    	ldr	x10, [x2, #0xc88]
1005e5e5c: f80983ea    	stur	x10, [sp, #0x98]
1005e5e60: f9464844    	ldr	x4, [x2, #0xc90]
1005e5e64: f80a03e4    	stur	x4, [sp, #0xa0]
1005e5e68: f946504c    	ldr	x12, [x2, #0xca0]
1005e5e6c: f946544b    	ldr	x11, [x2, #0xca8]
1005e5e70: f9465c4d    	ldr	x13, [x2, #0xcb8]
1005e5e74: f946604a    	ldr	x10, [x2, #0xcc0]
1005e5e78: f80a83ea    	stur	x10, [sp, #0xa8]
1005e5e7c: f940085c    	ldr	x28, [x2, #0x10]
1005e5e80: d280002a    	mov	x10, #0x1               ; =1
1005e5e84: f926326a    	str	x10, [x19, #0x4c60]
1005e5e88: 8b000060    	add	x0, x3, x0
1005e5e8c: 52990fc2    	mov	w2, #0xc87e             ; =51326
1005e5e90: 72a00022    	movk	w2, #0x1, lsl #16
1005e5e94: 9b020104    	madd	x4, x8, x2, x0
1005e5e98: f80783e4    	stur	x4, [sp, #0x78]
1005e5e9c: 14000006    	b	0x1005e5eb4 <_mech_canonical_program_entry_v1_numeric_1282+0x4834>
1005e5ea0: f84603e0    	ldur	x0, [sp, #0x60]
1005e5ea4: 9240e402    	and	x2, x0, #0x3ffffffffffffff
1005e5ea8: d240e442    	eor	x2, x2, #0x3ffffffffffffff
1005e5eac: f8217aa2    	str	x2, [x21, x1, lsl #3]
1005e5eb0: 91000421    	add	x1, x1, #0x1
1005e5eb4: b5000cee    	cbnz	x14, 0x1005e6050 <_mech_canonical_program_entry_v1_numeric_1282+0x49d0>
1005e5eb8: 14000823    	b	0x1005e7f44 <_mech_canonical_program_entry_v1_numeric_1282+0x68c4>
1005e5ebc: f940c7e0    	ldr	x0, [sp, #0x188]
1005e5ec0: f900081b    	str	x27, [x0, #0x10]
1005e5ec4: f9000c17    	str	x23, [x0, #0x18]
1005e5ec8: f900081b    	str	x27, [x0, #0x10]
1005e5ecc: f9000c17    	str	x23, [x0, #0x18]
1005e5ed0: f940c7e2    	ldr	x2, [sp, #0x188]
1005e5ed4: f9062848    	str	x8, [x2, #0xc50]
1005e5ed8: f940c7e4    	ldr	x4, [sp, #0x188]
1005e5edc: f84883fa    	ldur	x26, [sp, #0x88]
1005e5ee0: f9062c9a    	str	x26, [x4, #0xc58]
1005e5ee4: f84903e6    	ldur	x6, [sp, #0x90]
1005e5ee8: f940c7e7    	ldr	x7, [sp, #0x188]
1005e5eec: f90630e6    	str	x6, [x7, #0xc60]
1005e5ef0: f84783e4    	ldur	x4, [sp, #0x78]
1005e5ef4: cb030080    	sub	x0, x4, x3
1005e5ef8: 52990fc2    	mov	w2, #0xc87e             ; =51326
1005e5efc: 72a00022    	movk	w2, #0x1, lsl #16
1005e5f00: 9b028100    	msub	x0, x8, x2, x0
1005e5f04: f940c7ee    	ldr	x14, [sp, #0x188]
1005e5f08: f90635c0    	str	x0, [x14, #0xc68]
1005e5f0c: f90639d9    	str	x25, [x14, #0xc70]
1005e5f10: f940c7e0    	ldr	x0, [sp, #0x188]
1005e5f14: f9063c0f    	str	x15, [x0, #0xc78]
1005e5f18: d2800005    	mov	x5, #0x0                ; =0
1005e5f1c: f9064005    	str	x5, [x0, #0xc80]
1005e5f20: f84983ea    	ldur	x10, [sp, #0x98]
1005e5f24: f906440a    	str	x10, [x0, #0xc88]
1005e5f28: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e5f2c: f9064804    	str	x4, [x0, #0xc90]
1005e5f30: f9064c05    	str	x5, [x0, #0xc98]
1005e5f34: f906500c    	str	x12, [x0, #0xca0]
1005e5f38: f906540b    	str	x11, [x0, #0xca8]
1005e5f3c: f9065805    	str	x5, [x0, #0xcb0]
1005e5f40: f9065c0d    	str	x13, [x0, #0xcb8]
1005e5f44: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e5f48: f906600d    	str	x13, [x0, #0xcc0]
1005e5f4c: 91000420    	add	x0, x1, #0x1
1005e5f50: f940c7e1    	ldr	x1, [sp, #0x188]
1005e5f54: f9066820    	str	x0, [x1, #0xcd0]
1005e5f58: f84683f9    	ldur	x25, [sp, #0x68]
1005e5f5c: 9240e720    	and	x0, x25, #0x3ffffffffffffff
1005e5f60: d240e400    	eor	x0, x0, #0x3ffffffffffffff
1005e5f64: f9066c20    	str	x0, [x1, #0xcd8]
1005e5f68: d280da01    	mov	x1, #0x6d0              ; =1744
1005e5f6c: 92800342    	mov	x2, #-0x1b              ; =-27
1005e5f70: f84803e4    	ldur	x4, [sp, #0x80]
1005e5f74: f940cff5    	ldr	x21, [sp, #0x198]
1005e5f78: f84083e0    	ldur	x0, [sp, #0x8]
1005e5f7c: f940cbe6    	ldr	x6, [sp, #0x190]
1005e5f80: d63f02a0    	blr	x21
1005e5f84: d2800041    	mov	x1, #0x2                ; =2
1005e5f88: f80b83e1    	stur	x1, [sp, #0xb8]
1005e5f8c: f100001f    	cmp	x0, #0x0
1005e5f90: 54012f41    	b.ne	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e5f94: f940c7e3    	ldr	x3, [sp, #0x188]
1005e5f98: f9400063    	ldr	x3, [x3]
1005e5f9c: f940c7e0    	ldr	x0, [sp, #0x188]
1005e5fa0: f9400404    	ldr	x4, [x0, #0x8]
1005e5fa4: f80803e4    	stur	x4, [sp, #0x80]
1005e5fa8: f9455c15    	ldr	x21, [x0, #0xab8]
1005e5fac: f945fc0e    	ldr	x14, [x0, #0xbf8]
1005e5fb0: f9456001    	ldr	x1, [x0, #0xac0]
1005e5fb4: f9456400    	ldr	x0, [x0, #0xac8]
1005e5fb8: f940c7e0    	ldr	x0, [sp, #0x188]
1005e5fbc: f9456800    	ldr	x0, [x0, #0xad0]
1005e5fc0: f940c7e2    	ldr	x2, [sp, #0x188]
1005e5fc4: f9462440    	ldr	x0, [x2, #0xc48]
1005e5fc8: f940c7e4    	ldr	x4, [sp, #0x188]
1005e5fcc: f80b03e0    	stur	x0, [sp, #0xb0]
1005e5fd0: f9462888    	ldr	x8, [x4, #0xc50]
1005e5fd4: f940c7e6    	ldr	x6, [sp, #0x188]
1005e5fd8: f9462cda    	ldr	x26, [x6, #0xc58]
1005e5fdc: f940c7e9    	ldr	x9, [sp, #0x188]
1005e5fe0: f80883fa    	stur	x26, [sp, #0x88]
1005e5fe4: f9463126    	ldr	x6, [x9, #0xc60]
1005e5fe8: f940c7ea    	ldr	x10, [sp, #0x188]
1005e5fec: f80903e6    	stur	x6, [sp, #0x90]
1005e5ff0: f9463540    	ldr	x0, [x10, #0xc68]
1005e5ff4: f940c7ec    	ldr	x12, [sp, #0x188]
1005e5ff8: f9463999    	ldr	x25, [x12, #0xc70]
1005e5ffc: f940c7ef    	ldr	x15, [sp, #0x188]
1005e6000: f9463def    	ldr	x15, [x15, #0xc78]
1005e6004: f946444a    	ldr	x10, [x2, #0xc88]
1005e6008: f80983ea    	stur	x10, [sp, #0x98]
1005e600c: f9464844    	ldr	x4, [x2, #0xc90]
1005e6010: f80a03e4    	stur	x4, [sp, #0xa0]
1005e6014: f946504c    	ldr	x12, [x2, #0xca0]
1005e6018: f946544b    	ldr	x11, [x2, #0xca8]
1005e601c: f9465c4d    	ldr	x13, [x2, #0xcb8]
1005e6020: f9466042    	ldr	x2, [x2, #0xcc0]
1005e6024: f80a83e2    	stur	x2, [sp, #0xa8]
1005e6028: f940c7e2    	ldr	x2, [sp, #0x188]
1005e602c: f940085c    	ldr	x28, [x2, #0x10]
1005e6030: d280002a    	mov	x10, #0x1               ; =1
1005e6034: f926326a    	str	x10, [x19, #0x4c60]
1005e6038: 8b000060    	add	x0, x3, x0
1005e603c: 52990fc2    	mov	w2, #0xc87e             ; =51326
1005e6040: 72a00022    	movk	w2, #0x1, lsl #16
1005e6044: 9b020104    	madd	x4, x8, x2, x0
1005e6048: f80783e4    	stur	x4, [sp, #0x78]
1005e604c: 14000006    	b	0x1005e6064 <_mech_canonical_program_entry_v1_numeric_1282+0x49e4>
1005e6050: f84683e0    	ldur	x0, [sp, #0x68]
1005e6054: 9240e400    	and	x0, x0, #0x3ffffffffffffff
1005e6058: d240e400    	eor	x0, x0, #0x3ffffffffffffff
1005e605c: f8217aa0    	str	x0, [x21, x1, lsl #3]
1005e6060: 91000421    	add	x1, x1, #0x1
1005e6064: b5000cce    	cbnz	x14, 0x1005e61fc <_mech_canonical_program_entry_v1_numeric_1282+0x4b7c>
1005e6068: 140007c2    	b	0x1005e7f70 <_mech_canonical_program_entry_v1_numeric_1282+0x68f0>
1005e606c: f940c7e0    	ldr	x0, [sp, #0x188]
1005e6070: f900081b    	str	x27, [x0, #0x10]
1005e6074: f9000c17    	str	x23, [x0, #0x18]
1005e6078: f900081b    	str	x27, [x0, #0x10]
1005e607c: f9000c17    	str	x23, [x0, #0x18]
1005e6080: f9062808    	str	x8, [x0, #0xc50]
1005e6084: f940c7e2    	ldr	x2, [sp, #0x188]
1005e6088: f84883fa    	ldur	x26, [sp, #0x88]
1005e608c: f9062c5a    	str	x26, [x2, #0xc58]
1005e6090: f940c7e4    	ldr	x4, [sp, #0x188]
1005e6094: f84903e6    	ldur	x6, [sp, #0x90]
1005e6098: f9063086    	str	x6, [x4, #0xc60]
1005e609c: f84783e4    	ldur	x4, [sp, #0x78]
1005e60a0: cb030080    	sub	x0, x4, x3
1005e60a4: 52990fc2    	mov	w2, #0xc87e             ; =51326
1005e60a8: 72a00022    	movk	w2, #0x1, lsl #16
1005e60ac: 9b028100    	msub	x0, x8, x2, x0
1005e60b0: f940c7ea    	ldr	x10, [sp, #0x188]
1005e60b4: f9063540    	str	x0, [x10, #0xc68]
1005e60b8: f940c7ee    	ldr	x14, [sp, #0x188]
1005e60bc: f90639d9    	str	x25, [x14, #0xc70]
1005e60c0: f9063dcf    	str	x15, [x14, #0xc78]
1005e60c4: d2800005    	mov	x5, #0x0                ; =0
1005e60c8: f940c7e0    	ldr	x0, [sp, #0x188]
1005e60cc: f9064005    	str	x5, [x0, #0xc80]
1005e60d0: f84983ea    	ldur	x10, [sp, #0x98]
1005e60d4: f906440a    	str	x10, [x0, #0xc88]
1005e60d8: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e60dc: f9064804    	str	x4, [x0, #0xc90]
1005e60e0: f9064c05    	str	x5, [x0, #0xc98]
1005e60e4: f906500c    	str	x12, [x0, #0xca0]
1005e60e8: f906540b    	str	x11, [x0, #0xca8]
1005e60ec: f9065805    	str	x5, [x0, #0xcb0]
1005e60f0: f9065c0d    	str	x13, [x0, #0xcb8]
1005e60f4: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e60f8: f906600d    	str	x13, [x0, #0xcc0]
1005e60fc: 91000427    	add	x7, x1, #0x1
1005e6100: f9066807    	str	x7, [x0, #0xcd0]
1005e6104: f84703fa    	ldur	x26, [sp, #0x70]
1005e6108: 9240e748    	and	x8, x26, #0x3ffffffffffffff
1005e610c: d240e508    	eor	x8, x8, #0x3ffffffffffffff
1005e6110: f9066c08    	str	x8, [x0, #0xcd8]
1005e6114: d280da81    	mov	x1, #0x6d4              ; =1748
1005e6118: 92800342    	mov	x2, #-0x1b              ; =-27
1005e611c: f84803e4    	ldur	x4, [sp, #0x80]
1005e6120: f940cff5    	ldr	x21, [sp, #0x198]
1005e6124: f84083e0    	ldur	x0, [sp, #0x8]
1005e6128: f940cbe6    	ldr	x6, [sp, #0x190]
1005e612c: d63f02a0    	blr	x21
1005e6130: d2800042    	mov	x2, #0x2                ; =2
1005e6134: f80b83e2    	stur	x2, [sp, #0xb8]
1005e6138: f100001f    	cmp	x0, #0x0
1005e613c: 540121e1    	b.ne	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e6140: f940c7e3    	ldr	x3, [sp, #0x188]
1005e6144: f9400063    	ldr	x3, [x3]
1005e6148: f940c7e0    	ldr	x0, [sp, #0x188]
1005e614c: f9400404    	ldr	x4, [x0, #0x8]
1005e6150: f80803e4    	stur	x4, [sp, #0x80]
1005e6154: f9455c15    	ldr	x21, [x0, #0xab8]
1005e6158: f945fc0e    	ldr	x14, [x0, #0xbf8]
1005e615c: f9456001    	ldr	x1, [x0, #0xac0]
1005e6160: f80503e1    	stur	x1, [sp, #0x50]
1005e6164: f945640c    	ldr	x12, [x0, #0xac8]
1005e6168: f945680c    	ldr	x12, [x0, #0xad0]
1005e616c: f9462401    	ldr	x1, [x0, #0xc48]
1005e6170: f940c7e2    	ldr	x2, [sp, #0x188]
1005e6174: f80b03e1    	stur	x1, [sp, #0xb0]
1005e6178: f9462848    	ldr	x8, [x2, #0xc50]
1005e617c: f940c7e4    	ldr	x4, [sp, #0x188]
1005e6180: f9462c9a    	ldr	x26, [x4, #0xc58]
1005e6184: f940c7e6    	ldr	x6, [sp, #0x188]
1005e6188: f80883fa    	stur	x26, [sp, #0x88]
1005e618c: f94630c6    	ldr	x6, [x6, #0xc60]
1005e6190: f940c7e9    	ldr	x9, [sp, #0x188]
1005e6194: f80903e6    	stur	x6, [sp, #0x90]
1005e6198: f9463520    	ldr	x0, [x9, #0xc68]
1005e619c: f940c7ea    	ldr	x10, [sp, #0x188]
1005e61a0: f9463959    	ldr	x25, [x10, #0xc70]
1005e61a4: f940c7ec    	ldr	x12, [sp, #0x188]
1005e61a8: f9463d8f    	ldr	x15, [x12, #0xc78]
1005e61ac: f940c7e1    	ldr	x1, [sp, #0x188]
1005e61b0: f946442a    	ldr	x10, [x1, #0xc88]
1005e61b4: f80983ea    	stur	x10, [sp, #0x98]
1005e61b8: f9464824    	ldr	x4, [x1, #0xc90]
1005e61bc: f80a03e4    	stur	x4, [sp, #0xa0]
1005e61c0: f946502c    	ldr	x12, [x1, #0xca0]
1005e61c4: f946542b    	ldr	x11, [x1, #0xca8]
1005e61c8: f9465c2d    	ldr	x13, [x1, #0xcb8]
1005e61cc: f9466021    	ldr	x1, [x1, #0xcc0]
1005e61d0: f80a83e1    	stur	x1, [sp, #0xa8]
1005e61d4: f940c7e1    	ldr	x1, [sp, #0x188]
1005e61d8: f940083c    	ldr	x28, [x1, #0x10]
1005e61dc: d280002a    	mov	x10, #0x1               ; =1
1005e61e0: f926326a    	str	x10, [x19, #0x4c60]
1005e61e4: 8b000060    	add	x0, x3, x0
1005e61e8: 52990fc1    	mov	w1, #0xc87e             ; =51326
1005e61ec: 72a00021    	movk	w1, #0x1, lsl #16
1005e61f0: 9b010104    	madd	x4, x8, x1, x0
1005e61f4: f80783e4    	stur	x4, [sp, #0x78]
1005e61f8: 14000007    	b	0x1005e6214 <_mech_canonical_program_entry_v1_numeric_1282+0x4b94>
1005e61fc: f84703fa    	ldur	x26, [sp, #0x70]
1005e6200: 9240e740    	and	x0, x26, #0x3ffffffffffffff
1005e6204: d240e400    	eor	x0, x0, #0x3ffffffffffffff
1005e6208: f8217aa0    	str	x0, [x21, x1, lsl #3]
1005e620c: 91000421    	add	x1, x1, #0x1
1005e6210: f80503e1    	stur	x1, [sp, #0x50]
1005e6214: eb1702df    	cmp	x22, x23
1005e6218: 540008a3    	b.lo	0x1005e632c <_mech_canonical_program_entry_v1_numeric_1282+0x4cac>
1005e621c: d2800000    	mov	x0, #0x0                ; =0
1005e6220: f9000e60    	str	x0, [x19, #0x18]
1005e6224: d2e20001    	mov	x1, #0x1000000000000000 ; =1152921504606846976
1005e6228: f9001261    	str	x1, [x19, #0x20]
1005e622c: d2800021    	mov	x1, #0x1                ; =1
1005e6230: f9001a61    	str	x1, [x19, #0x30]
1005e6234: b200c3e2    	mov	x2, #0x101010101010101  ; =72340172838076673
1005e6238: f9001e62    	str	x2, [x19, #0x38]
1005e623c: d2800042    	mov	x2, #0x2                ; =2
1005e6240: f9002262    	str	x2, [x19, #0x40]
1005e6244: d2800062    	mov	x2, #0x3                ; =3
1005e6248: f9002662    	str	x2, [x19, #0x48]
1005e624c: d2800082    	mov	x2, #0x4                ; =4
1005e6250: f9002a62    	str	x2, [x19, #0x50]
1005e6254: b200cfe2    	mov	x2, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e6258: f9003e62    	str	x2, [x19, #0x78]
1005e625c: b200e7e2    	mov	x2, #0x3333333333333333 ; =3689348814741910323
1005e6260: f9004662    	str	x2, [x19, #0x88]
1005e6264: d2800702    	mov	x2, #0x38               ; =56
1005e6268: f9004a62    	str	x2, [x19, #0x90]
1005e626c: d2800742    	mov	x2, #0x3a               ; =58
1005e6270: f9004e62    	str	x2, [x19, #0x98]
1005e6274: b200f3e2    	mov	x2, #0x5555555555555555 ; =6148914691236517205
1005e6278: f9005a62    	str	x2, [x19, #0xb0]
1005e627c: 92ff8002    	mov	x2, #0x3ffffffffffffff  ; =288230376151711743
1005e6280: f9005e62    	str	x2, [x19, #0xb8]
1005e6284: f900c660    	str	x0, [x19, #0x188]
1005e6288: f900ca61    	str	x1, [x19, #0x190]
1005e628c: f926326a    	str	x10, [x19, #0x4c60]
1005e6290: f9263663    	str	x3, [x19, #0x4c68]
1005e6294: f84803e4    	ldur	x4, [sp, #0x80]
1005e6298: f9263a64    	str	x4, [x19, #0x4c70]
1005e629c: f927ba7b    	str	x27, [x19, #0x4f70]
1005e62a0: f927be77    	str	x23, [x19, #0x4f78]
1005e62a4: f84503e1    	ldur	x1, [sp, #0x50]
1005e62a8: f92d1261    	str	x1, [x19, #0x5a20]
1005e62ac: f92dda68    	str	x8, [x19, #0x5bb0]
1005e62b0: f84883fa    	ldur	x26, [sp, #0x88]
1005e62b4: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e62b8: f84903e6    	ldur	x6, [sp, #0x90]
1005e62bc: f92de266    	str	x6, [x19, #0x5bc0]
1005e62c0: f84783e4    	ldur	x4, [sp, #0x78]
1005e62c4: cb030080    	sub	x0, x4, x3
1005e62c8: 52990fc1    	mov	w1, #0xc87e             ; =51326
1005e62cc: 72a00021    	movk	w1, #0x1, lsl #16
1005e62d0: 9b018100    	msub	x0, x8, x1, x0
1005e62d4: f92de660    	str	x0, [x19, #0x5bc8]
1005e62d8: f92dea79    	str	x25, [x19, #0x5bd0]
1005e62dc: f92dee6f    	str	x15, [x19, #0x5bd8]
1005e62e0: f84983ea    	ldur	x10, [sp, #0x98]
1005e62e4: f92df66a    	str	x10, [x19, #0x5be8]
1005e62e8: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e62ec: f92dfa64    	str	x4, [x19, #0x5bf0]
1005e62f0: f92e026c    	str	x12, [x19, #0x5c00]
1005e62f4: f92e066b    	str	x11, [x19, #0x5c08]
1005e62f8: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e62fc: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e6300: f92e126d    	str	x13, [x19, #0x5c20]
1005e6304: d2800000    	mov	x0, #0x0                ; =0
1005e6308: d2800021    	mov	x1, #0x1                ; =1
1005e630c: 9106c3ff    	add	sp, sp, #0x1b0
1005e6310: a8c153f3    	ldp	x19, x20, [sp], #0x10
1005e6314: a8c15bf5    	ldp	x21, x22, [sp], #0x10
1005e6318: a8c163f7    	ldp	x23, x24, [sp], #0x10
1005e631c: a8c16bf9    	ldp	x25, x26, [sp], #0x10
1005e6320: a8c173fb    	ldp	x27, x28, [sp], #0x10
1005e6324: a8c17bfd    	ldp	x29, x30, [sp], #0x10
1005e6328: d65f0fff    	retab
1005e632c: 91000716    	add	x22, x24, #0x1
1005e6330: eb1802df    	cmp	x22, x24
1005e6334: 5400e343    	b.lo	0x1005e7f9c <_mech_canonical_program_entry_v1_numeric_1282+0x691c>
1005e6338: d2800026    	mov	x6, #0x1                ; =1
1005e633c: f80903e6    	stur	x6, [sp, #0x90]
1005e6340: f84903e5    	ldur	x5, [sp, #0x90]
1005e6344: aa1303e6    	mov	x6, x19
1005e6348: f84983e9    	ldur	x9, [sp, #0x98]
1005e634c: aa0a03fa    	mov	x26, x10
1005e6350: 17ffee38    	b	0x1005e1c30 <_mech_canonical_program_entry_v1_numeric_1282+0x5b0>
1005e6354: 910005e2    	add	x2, x15, #0x1
1005e6358: eb0f005f    	cmp	x2, x15
1005e635c: 5400ea03    	b.lo	0x1005e809c <_mech_canonical_program_entry_v1_numeric_1282+0x6a1c>
1005e6360: d2800024    	mov	x4, #0x1                ; =1
1005e6364: f80403e4    	stur	x4, [sp, #0x40]
1005e6368: aa0203ef    	mov	x15, x2
1005e636c: f80103e1    	stur	x1, [sp, #0x10]
1005e6370: f80583e0    	stur	x0, [sp, #0x58]
1005e6374: f80603e7    	stur	x7, [sp, #0x60]
1005e6378: f80683eb    	stur	x11, [sp, #0x68]
1005e637c: f80703f8    	stur	x24, [sp, #0x70]
1005e6380: 17fff861    	b	0x1005e4504 <_mech_canonical_program_entry_v1_numeric_1282+0x2e84>
1005e6384: 91000760    	add	x0, x27, #0x1
1005e6388: eb1b001f    	cmp	x0, x27
1005e638c: 5400f183    	b.lo	0x1005e81bc <_mech_canonical_program_entry_v1_numeric_1282+0x6b3c>
1005e6390: 529970cb    	mov	w11, #0xcb86            ; =52102
1005e6394: 72a0004b    	movk	w11, #0x2, lsl #16
1005e6398: cb0b0063    	sub	x3, x3, x11
1005e639c: d2800025    	mov	x5, #0x1                ; =1
1005e63a0: f80483e5    	stur	x5, [sp, #0x48]
1005e63a4: aa0003fb    	mov	x27, x0
1005e63a8: aa1403f8    	mov	x24, x20
1005e63ac: aa0903eb    	mov	x11, x9
1005e63b0: aa0603e7    	mov	x7, x6
1005e63b4: aa0203e1    	mov	x1, x2
1005e63b8: aa0403e0    	mov	x0, x4
1005e63bc: 17fffb4b    	b	0x1005e50e8 <_mech_canonical_program_entry_v1_numeric_1282+0x3a68>
1005e63c0: 9100049b    	add	x27, x4, #0x1
1005e63c4: f80183fb    	stur	x27, [sp, #0x18]
1005e63c8: eb04037f    	cmp	x27, x4
1005e63cc: 5400f963    	b.lo	0x1005e82f8 <_mech_canonical_program_entry_v1_numeric_1282+0x6c78>
1005e63d0: d2800038    	mov	x24, #0x1               ; =1
1005e63d4: f80203f8    	stur	x24, [sp, #0x20]
1005e63d8: f80703e0    	stur	x0, [sp, #0x70]
1005e63dc: f80103e2    	stur	x2, [sp, #0x10]
1005e63e0: aa0f03fb    	mov	x27, x15
1005e63e4: aa0103e2    	mov	x2, x1
1005e63e8: 17fff0f2    	b	0x1005e27b0 <_mech_canonical_program_entry_v1_numeric_1282+0x1130>
1005e63ec: 9100049b    	add	x27, x4, #0x1
1005e63f0: eb04037f    	cmp	x27, x4
1005e63f4: 540101a3    	b.lo	0x1005e8428 <_mech_canonical_program_entry_v1_numeric_1282+0x6da8>
1005e63f8: 529b83c0    	mov	w0, #0xdc1e             ; =56350
1005e63fc: 72a00040    	movk	w0, #0x2, lsl #16
1005e6400: cb000129    	sub	x9, x9, x0
1005e6404: d2800023    	mov	x3, #0x1                ; =1
1005e6408: f80303e6    	stur	x6, [sp, #0x30]
1005e640c: f80283e7    	stur	x7, [sp, #0x28]
1005e6410: f84383ef    	ldur	x15, [sp, #0x38]
1005e6414: aa1803e7    	mov	x7, x24
1005e6418: aa1403e6    	mov	x6, x20
1005e641c: 17fff3ec    	b	0x1005e33cc <_mech_canonical_program_entry_v1_numeric_1282+0x1d4c>
1005e6420: f80b83e0    	stur	x0, [sp, #0xb8]
1005e6424: 14000855    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e6428: f80b83e0    	stur	x0, [sp, #0xb8]
1005e642c: 14000853    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e6430: f80b83e0    	stur	x0, [sp, #0xb8]
1005e6434: 14000851    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e6438: f80b83e0    	stur	x0, [sp, #0xb8]
1005e643c: 1400084f    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e6440: d280a245    	mov	x5, #0x512              ; =1298
1005e6444: f84003e6    	ldur	x6, [sp]
1005e6448: f90024c5    	str	x5, [x6, #0x48]
1005e644c: d2800005    	mov	x5, #0x0                ; =0
1005e6450: f9000e65    	str	x5, [x19, #0x18]
1005e6454: d2e20006    	mov	x6, #0x1000000000000000 ; =1152921504606846976
1005e6458: f9001266    	str	x6, [x19, #0x20]
1005e645c: d2800026    	mov	x6, #0x1                ; =1
1005e6460: f9001a66    	str	x6, [x19, #0x30]
1005e6464: b200c3e7    	mov	x7, #0x101010101010101  ; =72340172838076673
1005e6468: f9001e67    	str	x7, [x19, #0x38]
1005e646c: d2800054    	mov	x20, #0x2               ; =2
1005e6470: f9002274    	str	x20, [x19, #0x40]
1005e6474: d2800067    	mov	x7, #0x3                ; =3
1005e6478: f9002667    	str	x7, [x19, #0x48]
1005e647c: d2800087    	mov	x7, #0x4                ; =4
1005e6480: f9002a67    	str	x7, [x19, #0x50]
1005e6484: b200cfe7    	mov	x7, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e6488: f9003e67    	str	x7, [x19, #0x78]
1005e648c: b200e7e7    	mov	x7, #0x3333333333333333 ; =3689348814741910323
1005e6490: f9004667    	str	x7, [x19, #0x88]
1005e6494: d2800707    	mov	x7, #0x38               ; =56
1005e6498: f9004a67    	str	x7, [x19, #0x90]
1005e649c: d2800747    	mov	x7, #0x3a               ; =58
1005e64a0: f9004e67    	str	x7, [x19, #0x98]
1005e64a4: b200f3ee    	mov	x14, #0x5555555555555555 ; =6148914691236517205
1005e64a8: f9005a6e    	str	x14, [x19, #0xb0]
1005e64ac: 92ff800e    	mov	x14, #0x3ffffffffffffff ; =288230376151711743
1005e64b0: f9005e6e    	str	x14, [x19, #0xb8]
1005e64b4: f900c665    	str	x5, [x19, #0x188]
1005e64b8: f900ca66    	str	x6, [x19, #0x190]
1005e64bc: f90bd276    	str	x22, [x19, #0x17a0]
1005e64c0: f90bd677    	str	x23, [x19, #0x17a8]
1005e64c4: 53001c0e    	uxtb	w14, w0
1005e64c8: f90bde6e    	str	x14, [x19, #0x17b8]
1005e64cc: 910006c0    	add	x0, x22, #0x1
1005e64d0: f90bea60    	str	x0, [x19, #0x17d0]
1005e64d4: f926326a    	str	x10, [x19, #0x4c60]
1005e64d8: 52990fc0    	mov	w0, #0xc87e             ; =51326
1005e64dc: 72a00020    	movk	w0, #0x1, lsl #16
1005e64e0: cb000063    	sub	x3, x3, x0
1005e64e4: f9263663    	str	x3, [x19, #0x4c68]
1005e64e8: f9263a64    	str	x4, [x19, #0x4c70]
1005e64ec: f927ba76    	str	x22, [x19, #0x4f70]
1005e64f0: f927be77    	str	x23, [x19, #0x4f78]
1005e64f4: f84503e4    	ldur	x4, [sp, #0x50]
1005e64f8: f92d1264    	str	x4, [x19, #0x5a20]
1005e64fc: 91000504    	add	x4, x8, #0x1
1005e6500: f92dda64    	str	x4, [x19, #0x5bb0]
1005e6504: f84883fa    	ldur	x26, [sp, #0x88]
1005e6508: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e650c: f84903ea    	ldur	x10, [sp, #0x90]
1005e6510: f92de26a    	str	x10, [x19, #0x5bc0]
1005e6514: f84783e5    	ldur	x5, [sp, #0x78]
1005e6518: cb0300a3    	sub	x3, x5, x3
1005e651c: 9b008c80    	msub	x0, x4, x0, x3
1005e6520: f92de660    	str	x0, [x19, #0x5bc8]
1005e6524: f92dea79    	str	x25, [x19, #0x5bd0]
1005e6528: f92dee6f    	str	x15, [x19, #0x5bd8]
1005e652c: f92df669    	str	x9, [x19, #0x5be8]
1005e6530: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e6534: f92dfa64    	str	x4, [x19, #0x5bf0]
1005e6538: f92e026c    	str	x12, [x19, #0x5c00]
1005e653c: f92e066b    	str	x11, [x19, #0x5c08]
1005e6540: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e6544: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e6548: f92e126d    	str	x13, [x19, #0x5c20]
1005e654c: f9663260    	ldr	x0, [x19, #0x4c60]
1005e6550: f100001f    	cmp	x0, #0x0
1005e6554: 54fdd5c1    	b.ne	0x1005e200c <_mech_canonical_program_entry_v1_numeric_1282+0x98c>
1005e6558: 17ffeeaa    	b	0x1005e2000 <_mech_canonical_program_entry_v1_numeric_1282+0x980>
1005e655c: f80b83e0    	stur	x0, [sp, #0xb8]
1005e6560: 14000806    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e6564: f80b83f4    	stur	x20, [sp, #0xb8]
1005e6568: 14000804    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e656c: f80b83e0    	stur	x0, [sp, #0xb8]
1005e6570: 14000802    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e6574: f80b83f4    	stur	x20, [sp, #0xb8]
1005e6578: 14000800    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e657c: d280a282    	mov	x2, #0x514              ; =1300
1005e6580: f84003e5    	ldur	x5, [sp]
1005e6584: f90024a2    	str	x2, [x5, #0x48]
1005e6588: d2800002    	mov	x2, #0x0                ; =0
1005e658c: f9000e62    	str	x2, [x19, #0x18]
1005e6590: d2e20005    	mov	x5, #0x1000000000000000 ; =1152921504606846976
1005e6594: f9001265    	str	x5, [x19, #0x20]
1005e6598: d2800025    	mov	x5, #0x1                ; =1
1005e659c: f9001a65    	str	x5, [x19, #0x30]
1005e65a0: b200c3e6    	mov	x6, #0x101010101010101  ; =72340172838076673
1005e65a4: f9001e66    	str	x6, [x19, #0x38]
1005e65a8: d2800054    	mov	x20, #0x2               ; =2
1005e65ac: f9002274    	str	x20, [x19, #0x40]
1005e65b0: d2800066    	mov	x6, #0x3                ; =3
1005e65b4: f9002666    	str	x6, [x19, #0x48]
1005e65b8: d2800086    	mov	x6, #0x4                ; =4
1005e65bc: f9002a66    	str	x6, [x19, #0x50]
1005e65c0: b200cfe6    	mov	x6, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e65c4: f9003e66    	str	x6, [x19, #0x78]
1005e65c8: b200e7e6    	mov	x6, #0x3333333333333333 ; =3689348814741910323
1005e65cc: f9004666    	str	x6, [x19, #0x88]
1005e65d0: d2800706    	mov	x6, #0x38               ; =56
1005e65d4: f9004a66    	str	x6, [x19, #0x90]
1005e65d8: d2800746    	mov	x6, #0x3a               ; =58
1005e65dc: f9004e66    	str	x6, [x19, #0x98]
1005e65e0: b200f3e6    	mov	x6, #0x5555555555555555 ; =6148914691236517205
1005e65e4: f9005a66    	str	x6, [x19, #0xb0]
1005e65e8: 92ff8006    	mov	x6, #0x3ffffffffffffff  ; =288230376151711743
1005e65ec: f9005e66    	str	x6, [x19, #0xb8]
1005e65f0: f900c662    	str	x2, [x19, #0x188]
1005e65f4: f900ca65    	str	x5, [x19, #0x190]
1005e65f8: f90bd276    	str	x22, [x19, #0x17a0]
1005e65fc: f90bd677    	str	x23, [x19, #0x17a8]
1005e6600: 53001c05    	uxtb	w5, w0
1005e6604: f90bde65    	str	x5, [x19, #0x17b8]
1005e6608: f90bee61    	str	x1, [x19, #0x17d8]
1005e660c: 91000ac7    	add	x7, x22, #0x2
1005e6610: f90bf267    	str	x7, [x19, #0x17e0]
1005e6614: f926326a    	str	x10, [x19, #0x4c60]
1005e6618: 52990fc9    	mov	w9, #0xc87e             ; =51326
1005e661c: 72a00029    	movk	w9, #0x1, lsl #16
1005e6620: cb09006a    	sub	x10, x3, x9
1005e6624: f926366a    	str	x10, [x19, #0x4c68]
1005e6628: f9263a64    	str	x4, [x19, #0x4c70]
1005e662c: f927ba76    	str	x22, [x19, #0x4f70]
1005e6630: f927be77    	str	x23, [x19, #0x4f78]
1005e6634: f84503e1    	ldur	x1, [sp, #0x50]
1005e6638: f92d1261    	str	x1, [x19, #0x5a20]
1005e663c: 9100050e    	add	x14, x8, #0x1
1005e6640: f92dda6e    	str	x14, [x19, #0x5bb0]
1005e6644: f84883fa    	ldur	x26, [sp, #0x88]
1005e6648: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e664c: f84903e6    	ldur	x6, [sp, #0x90]
1005e6650: f92de266    	str	x6, [x19, #0x5bc0]
1005e6654: f84783e4    	ldur	x4, [sp, #0x78]
1005e6658: cb0a0080    	sub	x0, x4, x10
1005e665c: 9b0981c0    	msub	x0, x14, x9, x0
1005e6660: f92de660    	str	x0, [x19, #0x5bc8]
1005e6664: f92dea79    	str	x25, [x19, #0x5bd0]
1005e6668: f92dee6f    	str	x15, [x19, #0x5bd8]
1005e666c: f84983ea    	ldur	x10, [sp, #0x98]
1005e6670: f92df66a    	str	x10, [x19, #0x5be8]
1005e6674: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e6678: f92dfa64    	str	x4, [x19, #0x5bf0]
1005e667c: f92e026c    	str	x12, [x19, #0x5c00]
1005e6680: f92e066b    	str	x11, [x19, #0x5c08]
1005e6684: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e6688: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e668c: f92e126d    	str	x13, [x19, #0x5c20]
1005e6690: f9663260    	ldr	x0, [x19, #0x4c60]
1005e6694: f100001f    	cmp	x0, #0x0
1005e6698: 54fddee1    	b.ne	0x1005e2274 <_mech_canonical_program_entry_v1_numeric_1282+0xbf4>
1005e669c: 17ffef7d    	b	0x1005e2490 <_mech_canonical_program_entry_v1_numeric_1282+0xe10>
1005e66a0: f80b83e0    	stur	x0, [sp, #0xb8]
1005e66a4: 140007b5    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e66a8: f80b83f4    	stur	x20, [sp, #0xb8]
1005e66ac: 140007b3    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e66b0: f80b83e0    	stur	x0, [sp, #0xb8]
1005e66b4: 140007b1    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e66b8: f80b83f4    	stur	x20, [sp, #0xb8]
1005e66bc: 140007af    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e66c0: d280a2c5    	mov	x5, #0x516              ; =1302
1005e66c4: f84003e6    	ldur	x6, [sp]
1005e66c8: f90024c5    	str	x5, [x6, #0x48]
1005e66cc: d2800005    	mov	x5, #0x0                ; =0
1005e66d0: f9000e65    	str	x5, [x19, #0x18]
1005e66d4: d2e20006    	mov	x6, #0x1000000000000000 ; =1152921504606846976
1005e66d8: f9001266    	str	x6, [x19, #0x20]
1005e66dc: d2800026    	mov	x6, #0x1                ; =1
1005e66e0: f9001a66    	str	x6, [x19, #0x30]
1005e66e4: b200c3e7    	mov	x7, #0x101010101010101  ; =72340172838076673
1005e66e8: f9001e67    	str	x7, [x19, #0x38]
1005e66ec: d2800054    	mov	x20, #0x2               ; =2
1005e66f0: f9002274    	str	x20, [x19, #0x40]
1005e66f4: d2800067    	mov	x7, #0x3                ; =3
1005e66f8: f9002667    	str	x7, [x19, #0x48]
1005e66fc: d2800087    	mov	x7, #0x4                ; =4
1005e6700: f9002a67    	str	x7, [x19, #0x50]
1005e6704: b200cfe7    	mov	x7, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e6708: f9003e67    	str	x7, [x19, #0x78]
1005e670c: b200e7e7    	mov	x7, #0x3333333333333333 ; =3689348814741910323
1005e6710: f9004667    	str	x7, [x19, #0x88]
1005e6714: d2800707    	mov	x7, #0x38               ; =56
1005e6718: f9004a67    	str	x7, [x19, #0x90]
1005e671c: d2800747    	mov	x7, #0x3a               ; =58
1005e6720: f9004e67    	str	x7, [x19, #0x98]
1005e6724: b200f3e7    	mov	x7, #0x5555555555555555 ; =6148914691236517205
1005e6728: f9005a67    	str	x7, [x19, #0xb0]
1005e672c: 92ff8007    	mov	x7, #0x3ffffffffffffff  ; =288230376151711743
1005e6730: f9005e67    	str	x7, [x19, #0xb8]
1005e6734: f900c665    	str	x5, [x19, #0x188]
1005e6738: f900ca66    	str	x6, [x19, #0x190]
1005e673c: f90bd276    	str	x22, [x19, #0x17a0]
1005e6740: f90bd677    	str	x23, [x19, #0x17a8]
1005e6744: 53001c00    	uxtb	w0, w0
1005e6748: f90bde60    	str	x0, [x19, #0x17b8]
1005e674c: f90bee61    	str	x1, [x19, #0x17d8]
1005e6750: f90bf662    	str	x2, [x19, #0x17e8]
1005e6754: f84d83f8    	ldur	x24, [sp, #0xd8]
1005e6758: f90bfa78    	str	x24, [x19, #0x17f0]
1005e675c: f926326a    	str	x10, [x19, #0x4c60]
1005e6760: 52990fc2    	mov	w2, #0xc87e             ; =51326
1005e6764: 72a00022    	movk	w2, #0x1, lsl #16
1005e6768: cb020063    	sub	x3, x3, x2
1005e676c: f9263663    	str	x3, [x19, #0x4c68]
1005e6770: f9263a64    	str	x4, [x19, #0x4c70]
1005e6774: f927ba76    	str	x22, [x19, #0x4f70]
1005e6778: f927be77    	str	x23, [x19, #0x4f78]
1005e677c: f84503e1    	ldur	x1, [sp, #0x50]
1005e6780: f92d1261    	str	x1, [x19, #0x5a20]
1005e6784: 91000507    	add	x7, x8, #0x1
1005e6788: f92dda67    	str	x7, [x19, #0x5bb0]
1005e678c: f84883fa    	ldur	x26, [sp, #0x88]
1005e6790: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e6794: f84903e6    	ldur	x6, [sp, #0x90]
1005e6798: f92de266    	str	x6, [x19, #0x5bc0]
1005e679c: f84783e4    	ldur	x4, [sp, #0x78]
1005e67a0: cb03008a    	sub	x10, x4, x3
1005e67a4: 9b02a8ea    	msub	x10, x7, x2, x10
1005e67a8: f92de66a    	str	x10, [x19, #0x5bc8]
1005e67ac: f92dea79    	str	x25, [x19, #0x5bd0]
1005e67b0: f92dee6f    	str	x15, [x19, #0x5bd8]
1005e67b4: f84983ea    	ldur	x10, [sp, #0x98]
1005e67b8: f92df66a    	str	x10, [x19, #0x5be8]
1005e67bc: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e67c0: f92dfa64    	str	x4, [x19, #0x5bf0]
1005e67c4: f92e026c    	str	x12, [x19, #0x5c00]
1005e67c8: f92e066b    	str	x11, [x19, #0x5c08]
1005e67cc: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e67d0: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e67d4: f92e126d    	str	x13, [x19, #0x5c20]
1005e67d8: f9663260    	ldr	x0, [x19, #0x4c60]
1005e67dc: f100001f    	cmp	x0, #0x0
1005e67e0: 54fde901    	b.ne	0x1005e2500 <_mech_canonical_program_entry_v1_numeric_1282+0xe80>
1005e67e4: 17ffefcc    	b	0x1005e2714 <_mech_canonical_program_entry_v1_numeric_1282+0x1094>
1005e67e8: f80b83e0    	stur	x0, [sp, #0xb8]
1005e67ec: 14000763    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e67f0: f80b83f4    	stur	x20, [sp, #0xb8]
1005e67f4: 14000761    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e67f8: f80b83e0    	stur	x0, [sp, #0xb8]
1005e67fc: 1400075f    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e6800: f80b83f4    	stur	x20, [sp, #0xb8]
1005e6804: 1400075d    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e6808: f80b83f4    	stur	x20, [sp, #0xb8]
1005e680c: 1400075b    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e6810: d280a600    	mov	x0, #0x530              ; =1328
1005e6814: f84003e2    	ldur	x2, [sp]
1005e6818: f9002440    	str	x0, [x2, #0x48]
1005e681c: d2800002    	mov	x2, #0x0                ; =0
1005e6820: f9000e62    	str	x2, [x19, #0x18]
1005e6824: d2e20000    	mov	x0, #0x1000000000000000 ; =1152921504606846976
1005e6828: f9001260    	str	x0, [x19, #0x20]
1005e682c: d2800020    	mov	x0, #0x1                ; =1
1005e6830: f9001a60    	str	x0, [x19, #0x30]
1005e6834: b200c3e4    	mov	x4, #0x101010101010101  ; =72340172838076673
1005e6838: f9001e64    	str	x4, [x19, #0x38]
1005e683c: d2800054    	mov	x20, #0x2               ; =2
1005e6840: f9002274    	str	x20, [x19, #0x40]
1005e6844: d2800064    	mov	x4, #0x3                ; =3
1005e6848: f9002664    	str	x4, [x19, #0x48]
1005e684c: d2800084    	mov	x4, #0x4                ; =4
1005e6850: f9002a64    	str	x4, [x19, #0x50]
1005e6854: b200cfe4    	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e6858: f9003e64    	str	x4, [x19, #0x78]
1005e685c: b200e7e4    	mov	x4, #0x3333333333333333 ; =3689348814741910323
1005e6860: f9004664    	str	x4, [x19, #0x88]
1005e6864: d2800704    	mov	x4, #0x38               ; =56
1005e6868: f9004a64    	str	x4, [x19, #0x90]
1005e686c: d2800744    	mov	x4, #0x3a               ; =58
1005e6870: f9004e64    	str	x4, [x19, #0x98]
1005e6874: b200f3e4    	mov	x4, #0x5555555555555555 ; =6148914691236517205
1005e6878: f9005a64    	str	x4, [x19, #0xb0]
1005e687c: 92ff8004    	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
1005e6880: f9005e64    	str	x4, [x19, #0xb8]
1005e6884: f900c662    	str	x2, [x19, #0x188]
1005e6888: f900ca60    	str	x0, [x19, #0x190]
1005e688c: f90bd276    	str	x22, [x19, #0x17a0]
1005e6890: f90bd677    	str	x23, [x19, #0x17a8]
1005e6894: f84e03f8    	ldur	x24, [sp, #0xe0]
1005e6898: 53001f02    	uxtb	w2, w24
1005e689c: f90bde62    	str	x2, [x19, #0x17b8]
1005e68a0: f90c2e61    	str	x1, [x19, #0x1858]
1005e68a4: aa1a03ef    	mov	x15, x26
1005e68a8: f90c326f    	str	x15, [x19, #0x1860]
1005e68ac: f90c3676    	str	x22, [x19, #0x1868]
1005e68b0: f84d03ef    	ldur	x15, [sp, #0xd0]
1005e68b4: f90c3a6f    	str	x15, [x19, #0x1870]
1005e68b8: f84c83ef    	ldur	x15, [sp, #0xc8]
1005e68bc: 53001de7    	uxtb	w7, w15
1005e68c0: f90c4267    	str	x7, [x19, #0x1880]
1005e68c4: 91000429    	add	x9, x1, #0x1
1005e68c8: f90c4a69    	str	x9, [x19, #0x1890]
1005e68cc: f926326a    	str	x10, [x19, #0x4c60]
1005e68d0: 52842cca    	mov	w10, #0x2166            ; =8550
1005e68d4: 72a0002a    	movk	w10, #0x1, lsl #16
1005e68d8: cb0a006a    	sub	x10, x3, x10
1005e68dc: f926366a    	str	x10, [x19, #0x4c68]
1005e68e0: f84803e4    	ldur	x4, [sp, #0x80]
1005e68e4: f9263a64    	str	x4, [x19, #0x4c70]
1005e68e8: f927ba76    	str	x22, [x19, #0x4f70]
1005e68ec: f927be77    	str	x23, [x19, #0x4f78]
1005e68f0: f9286261    	str	x1, [x19, #0x50c0]
1005e68f4: aa1a03ef    	mov	x15, x26
1005e68f8: f928666f    	str	x15, [x19, #0x50c8]
1005e68fc: f9286a76    	str	x22, [x19, #0x50d0]
1005e6900: f84d03ef    	ldur	x15, [sp, #0xd0]
1005e6904: f9286e6f    	str	x15, [x19, #0x50d8]
1005e6908: f84103e2    	ldur	x2, [sp, #0x10]
1005e690c: f9287262    	str	x2, [x19, #0x50e0]
1005e6910: f928767b    	str	x27, [x19, #0x50e8]
1005e6914: f9287a79    	str	x25, [x19, #0x50f0]
1005e6918: f84683fb    	ldur	x27, [sp, #0x68]
1005e691c: f9287e7b    	str	x27, [x19, #0x50f8]
1005e6920: f84703fa    	ldur	x26, [sp, #0x70]
1005e6924: f928827a    	str	x26, [x19, #0x5100]
1005e6928: f84503e1    	ldur	x1, [sp, #0x50]
1005e692c: f92d1261    	str	x1, [x19, #0x5a20]
1005e6930: 91000501    	add	x1, x8, #0x1
1005e6934: f92dda61    	str	x1, [x19, #0x5bb0]
1005e6938: f84883fa    	ldur	x26, [sp, #0x88]
1005e693c: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e6940: f84903e6    	ldur	x6, [sp, #0x90]
1005e6944: f92de266    	str	x6, [x19, #0x5bc0]
1005e6948: f84783e4    	ldur	x4, [sp, #0x78]
1005e694c: cb0a0082    	sub	x2, x4, x10
1005e6950: 52990fc3    	mov	w3, #0xc87e             ; =51326
1005e6954: 72a00023    	movk	w3, #0x1, lsl #16
1005e6958: 9b038821    	msub	x1, x1, x3, x2
1005e695c: f92de661    	str	x1, [x19, #0x5bc8]
1005e6960: f92dea60    	str	x0, [x19, #0x5bd0]
1005e6964: f84203f8    	ldur	x24, [sp, #0x20]
1005e6968: f92dee78    	str	x24, [x19, #0x5bd8]
1005e696c: f84983ea    	ldur	x10, [sp, #0x98]
1005e6970: f92df66a    	str	x10, [x19, #0x5be8]
1005e6974: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e6978: f92dfa64    	str	x4, [x19, #0x5bf0]
1005e697c: f92e026c    	str	x12, [x19, #0x5c00]
1005e6980: f92e066b    	str	x11, [x19, #0x5c08]
1005e6984: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e6988: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e698c: f92e126d    	str	x13, [x19, #0x5c20]
1005e6990: f9663260    	ldr	x0, [x19, #0x4c60]
1005e6994: f100001f    	cmp	x0, #0x0
1005e6998: 54fe1141    	b.ne	0x1005e2bc0 <_mech_canonical_program_entry_v1_numeric_1282+0x1540>
1005e699c: 17fff117    	b	0x1005e2df8 <_mech_canonical_program_entry_v1_numeric_1282+0x1778>
1005e69a0: f80b83f4    	stur	x20, [sp, #0xb8]
1005e69a4: 140006f5    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e69a8: f80b83f4    	stur	x20, [sp, #0xb8]
1005e69ac: 140006f3    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e69b0: d280a620    	mov	x0, #0x531              ; =1329
1005e69b4: f84003e9    	ldur	x9, [sp]
1005e69b8: f9002520    	str	x0, [x9, #0x48]
1005e69bc: d2800004    	mov	x4, #0x0                ; =0
1005e69c0: f9000e64    	str	x4, [x19, #0x18]
1005e69c4: d2e20000    	mov	x0, #0x1000000000000000 ; =1152921504606846976
1005e69c8: f9001260    	str	x0, [x19, #0x20]
1005e69cc: d2800020    	mov	x0, #0x1                ; =1
1005e69d0: f80b83e0    	stur	x0, [sp, #0xb8]
1005e69d4: f9001a60    	str	x0, [x19, #0x30]
1005e69d8: b200c3e0    	mov	x0, #0x101010101010101  ; =72340172838076673
1005e69dc: f9001e60    	str	x0, [x19, #0x38]
1005e69e0: d2800040    	mov	x0, #0x2                ; =2
1005e69e4: f9002260    	str	x0, [x19, #0x40]
1005e69e8: d2800060    	mov	x0, #0x3                ; =3
1005e69ec: f9002660    	str	x0, [x19, #0x48]
1005e69f0: d2800080    	mov	x0, #0x4                ; =4
1005e69f4: f9002a60    	str	x0, [x19, #0x50]
1005e69f8: b200cfe0    	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e69fc: f9003e60    	str	x0, [x19, #0x78]
1005e6a00: b200e7e0    	mov	x0, #0x3333333333333333 ; =3689348814741910323
1005e6a04: f9004660    	str	x0, [x19, #0x88]
1005e6a08: d2800700    	mov	x0, #0x38               ; =56
1005e6a0c: f9004a60    	str	x0, [x19, #0x90]
1005e6a10: d2800740    	mov	x0, #0x3a               ; =58
1005e6a14: f9004e60    	str	x0, [x19, #0x98]
1005e6a18: b200f3e0    	mov	x0, #0x5555555555555555 ; =6148914691236517205
1005e6a1c: f9005a60    	str	x0, [x19, #0xb0]
1005e6a20: 92ff8000    	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
1005e6a24: f9005e60    	str	x0, [x19, #0xb8]
1005e6a28: f900c664    	str	x4, [x19, #0x188]
1005e6a2c: f84b83e0    	ldur	x0, [sp, #0xb8]
1005e6a30: f900ca60    	str	x0, [x19, #0x190]
1005e6a34: f90bd276    	str	x22, [x19, #0x17a0]
1005e6a38: f90bd677    	str	x23, [x19, #0x17a8]
1005e6a3c: f84e03f8    	ldur	x24, [sp, #0xe0]
1005e6a40: 53001f05    	uxtb	w5, w24
1005e6a44: f90bde65    	str	x5, [x19, #0x17b8]
1005e6a48: f90c2e61    	str	x1, [x19, #0x1858]
1005e6a4c: aa1a03ef    	mov	x15, x26
1005e6a50: f90c326f    	str	x15, [x19, #0x1860]
1005e6a54: f90c3676    	str	x22, [x19, #0x1868]
1005e6a58: f84d03ef    	ldur	x15, [sp, #0xd0]
1005e6a5c: f90c3a6f    	str	x15, [x19, #0x1870]
1005e6a60: f84c83ef    	ldur	x15, [sp, #0xc8]
1005e6a64: 53001dee    	uxtb	w14, w15
1005e6a68: f90c426e    	str	x14, [x19, #0x1880]
1005e6a6c: f90c4e62    	str	x2, [x19, #0x1898]
1005e6a70: f926326a    	str	x10, [x19, #0x4c60]
1005e6a74: 52842cce    	mov	w14, #0x2166            ; =8550
1005e6a78: 72a0002e    	movk	w14, #0x1, lsl #16
1005e6a7c: cb0e006e    	sub	x14, x3, x14
1005e6a80: f926366e    	str	x14, [x19, #0x4c68]
1005e6a84: f84803e4    	ldur	x4, [sp, #0x80]
1005e6a88: f9263a64    	str	x4, [x19, #0x4c70]
1005e6a8c: f84503e1    	ldur	x1, [sp, #0x50]
1005e6a90: f92d1261    	str	x1, [x19, #0x5a20]
1005e6a94: 91000501    	add	x1, x8, #0x1
1005e6a98: f92dda61    	str	x1, [x19, #0x5bb0]
1005e6a9c: f84883fa    	ldur	x26, [sp, #0x88]
1005e6aa0: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e6aa4: f84903e6    	ldur	x6, [sp, #0x90]
1005e6aa8: f92de266    	str	x6, [x19, #0x5bc0]
1005e6aac: f84783e4    	ldur	x4, [sp, #0x78]
1005e6ab0: cb0e0082    	sub	x2, x4, x14
1005e6ab4: 52990fc3    	mov	w3, #0xc87e             ; =51326
1005e6ab8: 72a00023    	movk	w3, #0x1, lsl #16
1005e6abc: 9b038820    	msub	x0, x1, x3, x2
1005e6ac0: f92de660    	str	x0, [x19, #0x5bc8]
1005e6ac4: f84b83e0    	ldur	x0, [sp, #0xb8]
1005e6ac8: f92dea60    	str	x0, [x19, #0x5bd0]
1005e6acc: f84203f8    	ldur	x24, [sp, #0x20]
1005e6ad0: f92dee78    	str	x24, [x19, #0x5bd8]
1005e6ad4: f84983ea    	ldur	x10, [sp, #0x98]
1005e6ad8: f92df66a    	str	x10, [x19, #0x5be8]
1005e6adc: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e6ae0: f92dfa64    	str	x4, [x19, #0x5bf0]
1005e6ae4: f92e026c    	str	x12, [x19, #0x5c00]
1005e6ae8: f92e066b    	str	x11, [x19, #0x5c08]
1005e6aec: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e6af0: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e6af4: f92e126d    	str	x13, [x19, #0x5c20]
1005e6af8: 140006a0    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e6afc: d280a640    	mov	x0, #0x532              ; =1330
1005e6b00: f84003ef    	ldur	x15, [sp]
1005e6b04: f90025e0    	str	x0, [x15, #0x48]
1005e6b08: d2800005    	mov	x5, #0x0                ; =0
1005e6b0c: f9000e65    	str	x5, [x19, #0x18]
1005e6b10: d2e20000    	mov	x0, #0x1000000000000000 ; =1152921504606846976
1005e6b14: f9001260    	str	x0, [x19, #0x20]
1005e6b18: d2800020    	mov	x0, #0x1                ; =1
1005e6b1c: f9001a60    	str	x0, [x19, #0x30]
1005e6b20: b200c3e6    	mov	x6, #0x101010101010101  ; =72340172838076673
1005e6b24: f9001e66    	str	x6, [x19, #0x38]
1005e6b28: d2800054    	mov	x20, #0x2               ; =2
1005e6b2c: f9002274    	str	x20, [x19, #0x40]
1005e6b30: d2800066    	mov	x6, #0x3                ; =3
1005e6b34: f9002666    	str	x6, [x19, #0x48]
1005e6b38: d2800086    	mov	x6, #0x4                ; =4
1005e6b3c: f9002a66    	str	x6, [x19, #0x50]
1005e6b40: b200cfe6    	mov	x6, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e6b44: f9003e66    	str	x6, [x19, #0x78]
1005e6b48: b200e7e6    	mov	x6, #0x3333333333333333 ; =3689348814741910323
1005e6b4c: f9004666    	str	x6, [x19, #0x88]
1005e6b50: d2800706    	mov	x6, #0x38               ; =56
1005e6b54: f9004a66    	str	x6, [x19, #0x90]
1005e6b58: d2800746    	mov	x6, #0x3a               ; =58
1005e6b5c: f9004e66    	str	x6, [x19, #0x98]
1005e6b60: b200f3e6    	mov	x6, #0x5555555555555555 ; =6148914691236517205
1005e6b64: f9005a66    	str	x6, [x19, #0xb0]
1005e6b68: 92ff8006    	mov	x6, #0x3ffffffffffffff  ; =288230376151711743
1005e6b6c: f9005e66    	str	x6, [x19, #0xb8]
1005e6b70: f900c665    	str	x5, [x19, #0x188]
1005e6b74: f900ca60    	str	x0, [x19, #0x190]
1005e6b78: f90bd276    	str	x22, [x19, #0x17a0]
1005e6b7c: f90bd677    	str	x23, [x19, #0x17a8]
1005e6b80: f84e03f8    	ldur	x24, [sp, #0xe0]
1005e6b84: 53001f05    	uxtb	w5, w24
1005e6b88: f90bde65    	str	x5, [x19, #0x17b8]
1005e6b8c: f90c2e61    	str	x1, [x19, #0x1858]
1005e6b90: aa1a03ef    	mov	x15, x26
1005e6b94: f90c326f    	str	x15, [x19, #0x1860]
1005e6b98: f90c3676    	str	x22, [x19, #0x1868]
1005e6b9c: f84d03ef    	ldur	x15, [sp, #0xd0]
1005e6ba0: f90c3a6f    	str	x15, [x19, #0x1870]
1005e6ba4: f84c83ef    	ldur	x15, [sp, #0xc8]
1005e6ba8: 53001de5    	uxtb	w5, w15
1005e6bac: f90c4265    	str	x5, [x19, #0x1880]
1005e6bb0: f90c4e62    	str	x2, [x19, #0x1898]
1005e6bb4: f90c5264    	str	x4, [x19, #0x18a0]
1005e6bb8: f926326a    	str	x10, [x19, #0x4c60]
1005e6bbc: 52842cc2    	mov	w2, #0x2166             ; =8550
1005e6bc0: 72a00022    	movk	w2, #0x1, lsl #16
1005e6bc4: cb020062    	sub	x2, x3, x2
1005e6bc8: f9263662    	str	x2, [x19, #0x4c68]
1005e6bcc: f84803e4    	ldur	x4, [sp, #0x80]
1005e6bd0: f9263a64    	str	x4, [x19, #0x4c70]
1005e6bd4: f927ba76    	str	x22, [x19, #0x4f70]
1005e6bd8: f927be77    	str	x23, [x19, #0x4f78]
1005e6bdc: f9286261    	str	x1, [x19, #0x50c0]
1005e6be0: aa1a03ef    	mov	x15, x26
1005e6be4: f928666f    	str	x15, [x19, #0x50c8]
1005e6be8: f9286a76    	str	x22, [x19, #0x50d0]
1005e6bec: f84d03ef    	ldur	x15, [sp, #0xd0]
1005e6bf0: f9286e6f    	str	x15, [x19, #0x50d8]
1005e6bf4: f84103f9    	ldur	x25, [sp, #0x10]
1005e6bf8: f9287279    	str	x25, [x19, #0x50e0]
1005e6bfc: f928767b    	str	x27, [x19, #0x50e8]
1005e6c00: f84603f9    	ldur	x25, [sp, #0x60]
1005e6c04: f9287a79    	str	x25, [x19, #0x50f0]
1005e6c08: f84683f9    	ldur	x25, [sp, #0x68]
1005e6c0c: f9287e79    	str	x25, [x19, #0x50f8]
1005e6c10: f84703fa    	ldur	x26, [sp, #0x70]
1005e6c14: f928827a    	str	x26, [x19, #0x5100]
1005e6c18: f84503e1    	ldur	x1, [sp, #0x50]
1005e6c1c: f92d1261    	str	x1, [x19, #0x5a20]
1005e6c20: 9100050a    	add	x10, x8, #0x1
1005e6c24: f92dda6a    	str	x10, [x19, #0x5bb0]
1005e6c28: f84883fa    	ldur	x26, [sp, #0x88]
1005e6c2c: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e6c30: f84903e6    	ldur	x6, [sp, #0x90]
1005e6c34: f92de266    	str	x6, [x19, #0x5bc0]
1005e6c38: f84783e4    	ldur	x4, [sp, #0x78]
1005e6c3c: cb02008e    	sub	x14, x4, x2
1005e6c40: 52990fcf    	mov	w15, #0xc87e            ; =51326
1005e6c44: 72a0002f    	movk	w15, #0x1, lsl #16
1005e6c48: 9b0fb94e    	msub	x14, x10, x15, x14
1005e6c4c: f92de66e    	str	x14, [x19, #0x5bc8]
1005e6c50: f92dea60    	str	x0, [x19, #0x5bd0]
1005e6c54: f84203f8    	ldur	x24, [sp, #0x20]
1005e6c58: f92dee78    	str	x24, [x19, #0x5bd8]
1005e6c5c: f84983ea    	ldur	x10, [sp, #0x98]
1005e6c60: f92df66a    	str	x10, [x19, #0x5be8]
1005e6c64: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e6c68: f92dfa64    	str	x4, [x19, #0x5bf0]
1005e6c6c: f92e026c    	str	x12, [x19, #0x5c00]
1005e6c70: f92e066b    	str	x11, [x19, #0x5c08]
1005e6c74: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e6c78: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e6c7c: f92e126d    	str	x13, [x19, #0x5c20]
1005e6c80: f9663260    	ldr	x0, [x19, #0x4c60]
1005e6c84: f100001f    	cmp	x0, #0x0
1005e6c88: 54fe0f81    	b.ne	0x1005e2e78 <_mech_canonical_program_entry_v1_numeric_1282+0x17f8>
1005e6c8c: 17fff105    	b	0x1005e30a0 <_mech_canonical_program_entry_v1_numeric_1282+0x1a20>
1005e6c90: f80b83f4    	stur	x20, [sp, #0xb8]
1005e6c94: 14000639    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e6c98: f80b83f4    	stur	x20, [sp, #0xb8]
1005e6c9c: 14000637    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e6ca0: d280a680    	mov	x0, #0x534              ; =1332
1005e6ca4: f84003e1    	ldur	x1, [sp]
1005e6ca8: f9002420    	str	x0, [x1, #0x48]
1005e6cac: d2800001    	mov	x1, #0x0                ; =0
1005e6cb0: f9000e61    	str	x1, [x19, #0x18]
1005e6cb4: d2e20000    	mov	x0, #0x1000000000000000 ; =1152921504606846976
1005e6cb8: f9001260    	str	x0, [x19, #0x20]
1005e6cbc: d2800020    	mov	x0, #0x1                ; =1
1005e6cc0: f9001a60    	str	x0, [x19, #0x30]
1005e6cc4: b200c3e4    	mov	x4, #0x101010101010101  ; =72340172838076673
1005e6cc8: f9001e64    	str	x4, [x19, #0x38]
1005e6ccc: d2800054    	mov	x20, #0x2               ; =2
1005e6cd0: f9002274    	str	x20, [x19, #0x40]
1005e6cd4: d2800064    	mov	x4, #0x3                ; =3
1005e6cd8: f9002664    	str	x4, [x19, #0x48]
1005e6cdc: d2800084    	mov	x4, #0x4                ; =4
1005e6ce0: f9002a64    	str	x4, [x19, #0x50]
1005e6ce4: b200cfe4    	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e6ce8: f9003e64    	str	x4, [x19, #0x78]
1005e6cec: b200e7e4    	mov	x4, #0x3333333333333333 ; =3689348814741910323
1005e6cf0: f9004664    	str	x4, [x19, #0x88]
1005e6cf4: d2800704    	mov	x4, #0x38               ; =56
1005e6cf8: f9004a64    	str	x4, [x19, #0x90]
1005e6cfc: d2800744    	mov	x4, #0x3a               ; =58
1005e6d00: f9004e64    	str	x4, [x19, #0x98]
1005e6d04: b200f3e4    	mov	x4, #0x5555555555555555 ; =6148914691236517205
1005e6d08: f9005a64    	str	x4, [x19, #0xb0]
1005e6d0c: 92ff8004    	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
1005e6d10: f9005e64    	str	x4, [x19, #0xb8]
1005e6d14: f900c661    	str	x1, [x19, #0x188]
1005e6d18: f900ca60    	str	x0, [x19, #0x190]
1005e6d1c: f90bd276    	str	x22, [x19, #0x17a0]
1005e6d20: f90bd677    	str	x23, [x19, #0x17a8]
1005e6d24: f84e03f8    	ldur	x24, [sp, #0xe0]
1005e6d28: 53001f01    	uxtb	w1, w24
1005e6d2c: f90bde61    	str	x1, [x19, #0x17b8]
1005e6d30: f84183ef    	ldur	x15, [sp, #0x18]
1005e6d34: f90c2e6f    	str	x15, [x19, #0x1858]
1005e6d38: aa1a03ef    	mov	x15, x26
1005e6d3c: f90c326f    	str	x15, [x19, #0x1860]
1005e6d40: f90c3676    	str	x22, [x19, #0x1868]
1005e6d44: f84d03ef    	ldur	x15, [sp, #0xd0]
1005e6d48: f90c3a6f    	str	x15, [x19, #0x1870]
1005e6d4c: f84c83ef    	ldur	x15, [sp, #0xc8]
1005e6d50: 53001de1    	uxtb	w1, w15
1005e6d54: f90c4261    	str	x1, [x19, #0x1880]
1005e6d58: f90c567b    	str	x27, [x19, #0x18a8]
1005e6d5c: 91000841    	add	x1, x2, #0x2
1005e6d60: f90c5a61    	str	x1, [x19, #0x18b0]
1005e6d64: f926326a    	str	x10, [x19, #0x4c60]
1005e6d68: 52842cc2    	mov	w2, #0x2166             ; =8550
1005e6d6c: 72a00022    	movk	w2, #0x1, lsl #16
1005e6d70: cb020062    	sub	x2, x3, x2
1005e6d74: f9263662    	str	x2, [x19, #0x4c68]
1005e6d78: f84803e4    	ldur	x4, [sp, #0x80]
1005e6d7c: f9263a64    	str	x4, [x19, #0x4c70]
1005e6d80: f927ba76    	str	x22, [x19, #0x4f70]
1005e6d84: f927be77    	str	x23, [x19, #0x4f78]
1005e6d88: f84183fb    	ldur	x27, [sp, #0x18]
1005e6d8c: f928627b    	str	x27, [x19, #0x50c0]
1005e6d90: aa1a03ef    	mov	x15, x26
1005e6d94: f928666f    	str	x15, [x19, #0x50c8]
1005e6d98: f9286a76    	str	x22, [x19, #0x50d0]
1005e6d9c: f84d03ef    	ldur	x15, [sp, #0xd0]
1005e6da0: f9286e6f    	str	x15, [x19, #0x50d8]
1005e6da4: f84103f9    	ldur	x25, [sp, #0x10]
1005e6da8: f9287279    	str	x25, [x19, #0x50e0]
1005e6dac: f84583f8    	ldur	x24, [sp, #0x58]
1005e6db0: f9287678    	str	x24, [x19, #0x50e8]
1005e6db4: f84603fb    	ldur	x27, [sp, #0x60]
1005e6db8: f9287a7b    	str	x27, [x19, #0x50f0]
1005e6dbc: f84683f9    	ldur	x25, [sp, #0x68]
1005e6dc0: f9287e79    	str	x25, [x19, #0x50f8]
1005e6dc4: f84703fa    	ldur	x26, [sp, #0x70]
1005e6dc8: f928827a    	str	x26, [x19, #0x5100]
1005e6dcc: f84503e1    	ldur	x1, [sp, #0x50]
1005e6dd0: f92d1261    	str	x1, [x19, #0x5a20]
1005e6dd4: 91000501    	add	x1, x8, #0x1
1005e6dd8: f92dda61    	str	x1, [x19, #0x5bb0]
1005e6ddc: f84883fa    	ldur	x26, [sp, #0x88]
1005e6de0: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e6de4: f84903e6    	ldur	x6, [sp, #0x90]
1005e6de8: f92de266    	str	x6, [x19, #0x5bc0]
1005e6dec: f84783e4    	ldur	x4, [sp, #0x78]
1005e6df0: cb020082    	sub	x2, x4, x2
1005e6df4: 52990fc3    	mov	w3, #0xc87e             ; =51326
1005e6df8: 72a00023    	movk	w3, #0x1, lsl #16
1005e6dfc: 9b038821    	msub	x1, x1, x3, x2
1005e6e00: f92de661    	str	x1, [x19, #0x5bc8]
1005e6e04: f92dea60    	str	x0, [x19, #0x5bd0]
1005e6e08: f84203f8    	ldur	x24, [sp, #0x20]
1005e6e0c: f92dee78    	str	x24, [x19, #0x5bd8]
1005e6e10: f84983ea    	ldur	x10, [sp, #0x98]
1005e6e14: f92df66a    	str	x10, [x19, #0x5be8]
1005e6e18: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e6e1c: f92dfa64    	str	x4, [x19, #0x5bf0]
1005e6e20: f92e026c    	str	x12, [x19, #0x5c00]
1005e6e24: f92e066b    	str	x11, [x19, #0x5c08]
1005e6e28: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e6e2c: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e6e30: f92e126d    	str	x13, [x19, #0x5c20]
1005e6e34: f9663260    	ldr	x0, [x19, #0x4c60]
1005e6e38: f100001f    	cmp	x0, #0x0
1005e6e3c: 54fe16e1    	b.ne	0x1005e3118 <_mech_canonical_program_entry_v1_numeric_1282+0x1a98>
1005e6e40: 17fff140    	b	0x1005e3340 <_mech_canonical_program_entry_v1_numeric_1282+0x1cc0>
1005e6e44: f80b83f4    	stur	x20, [sp, #0xb8]
1005e6e48: 140005cc    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e6e4c: f80b83f4    	stur	x20, [sp, #0xb8]
1005e6e50: 140005ca    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e6e54: f80b83f4    	stur	x20, [sp, #0xb8]
1005e6e58: 140005c8    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e6e5c: d280a9c0    	mov	x0, #0x54e              ; =1358
1005e6e60: f84003e1    	ldur	x1, [sp]
1005e6e64: f9002420    	str	x0, [x1, #0x48]
1005e6e68: d2800000    	mov	x0, #0x0                ; =0
1005e6e6c: f9000e60    	str	x0, [x19, #0x18]
1005e6e70: d2e20001    	mov	x1, #0x1000000000000000 ; =1152921504606846976
1005e6e74: f9001261    	str	x1, [x19, #0x20]
1005e6e78: d2800026    	mov	x6, #0x1                ; =1
1005e6e7c: f9001a66    	str	x6, [x19, #0x30]
1005e6e80: b200c3e1    	mov	x1, #0x101010101010101  ; =72340172838076673
1005e6e84: f9001e61    	str	x1, [x19, #0x38]
1005e6e88: d2800058    	mov	x24, #0x2               ; =2
1005e6e8c: f9002278    	str	x24, [x19, #0x40]
1005e6e90: d2800061    	mov	x1, #0x3                ; =3
1005e6e94: f9002661    	str	x1, [x19, #0x48]
1005e6e98: d2800081    	mov	x1, #0x4                ; =4
1005e6e9c: f9002a61    	str	x1, [x19, #0x50]
1005e6ea0: b200cfe1    	mov	x1, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e6ea4: f9003e61    	str	x1, [x19, #0x78]
1005e6ea8: b200e7e1    	mov	x1, #0x3333333333333333 ; =3689348814741910323
1005e6eac: f9004661    	str	x1, [x19, #0x88]
1005e6eb0: d2800701    	mov	x1, #0x38               ; =56
1005e6eb4: f9004a61    	str	x1, [x19, #0x90]
1005e6eb8: d2800741    	mov	x1, #0x3a               ; =58
1005e6ebc: f9004e61    	str	x1, [x19, #0x98]
1005e6ec0: b200f3e1    	mov	x1, #0x5555555555555555 ; =6148914691236517205
1005e6ec4: f9005a61    	str	x1, [x19, #0xb0]
1005e6ec8: 92ff8001    	mov	x1, #0x3ffffffffffffff  ; =288230376151711743
1005e6ecc: f9005e61    	str	x1, [x19, #0xb8]
1005e6ed0: f900c660    	str	x0, [x19, #0x188]
1005e6ed4: f900ca66    	str	x6, [x19, #0x190]
1005e6ed8: f90bd276    	str	x22, [x19, #0x17a0]
1005e6edc: f90bd677    	str	x23, [x19, #0x17a8]
1005e6ee0: f84e03e0    	ldur	x0, [sp, #0xe0]
1005e6ee4: 53001c00    	uxtb	w0, w0
1005e6ee8: f90bde60    	str	x0, [x19, #0x17b8]
1005e6eec: f84183e0    	ldur	x0, [sp, #0x18]
1005e6ef0: f90c2e60    	str	x0, [x19, #0x1858]
1005e6ef4: aa1a03e0    	mov	x0, x26
1005e6ef8: f90c3260    	str	x0, [x19, #0x1860]
1005e6efc: f90c3676    	str	x22, [x19, #0x1868]
1005e6f00: f84d03ee    	ldur	x14, [sp, #0xd0]
1005e6f04: f90c3a6e    	str	x14, [x19, #0x1870]
1005e6f08: f84c83e0    	ldur	x0, [sp, #0xc8]
1005e6f0c: 53001c00    	uxtb	w0, w0
1005e6f10: f90c4260    	str	x0, [x19, #0x1880]
1005e6f14: f90c8e7b    	str	x27, [x19, #0x1918]
1005e6f18: f90c9265    	str	x5, [x19, #0x1920]
1005e6f1c: f90c9676    	str	x22, [x19, #0x1928]
1005e6f20: f90c9a6e    	str	x14, [x19, #0x1930]
1005e6f24: 53001ce0    	uxtb	w0, w7
1005e6f28: f90ca260    	str	x0, [x19, #0x1940]
1005e6f2c: 91000760    	add	x0, x27, #0x1
1005e6f30: f90caa60    	str	x0, [x19, #0x1950]
1005e6f34: f926326a    	str	x10, [x19, #0x4c60]
1005e6f38: 529b83c0    	mov	w0, #0xdc1e             ; =56350
1005e6f3c: 72a00040    	movk	w0, #0x2, lsl #16
1005e6f40: cb000124    	sub	x4, x9, x0
1005e6f44: f9263664    	str	x4, [x19, #0x4c68]
1005e6f48: f84803e7    	ldur	x7, [sp, #0x80]
1005e6f4c: f9263a67    	str	x7, [x19, #0x4c70]
1005e6f50: f927ba76    	str	x22, [x19, #0x4f70]
1005e6f54: f927be77    	str	x23, [x19, #0x4f78]
1005e6f58: f84183e0    	ldur	x0, [sp, #0x18]
1005e6f5c: f9286260    	str	x0, [x19, #0x50c0]
1005e6f60: aa1a03e0    	mov	x0, x26
1005e6f64: f9286660    	str	x0, [x19, #0x50c8]
1005e6f68: f9286a76    	str	x22, [x19, #0x50d0]
1005e6f6c: f84d03e0    	ldur	x0, [sp, #0xd0]
1005e6f70: f9286e60    	str	x0, [x19, #0x50d8]
1005e6f74: f84103e0    	ldur	x0, [sp, #0x10]
1005e6f78: f9287260    	str	x0, [x19, #0x50e0]
1005e6f7c: f84583e0    	ldur	x0, [sp, #0x58]
1005e6f80: f9287660    	str	x0, [x19, #0x50e8]
1005e6f84: f84603e0    	ldur	x0, [sp, #0x60]
1005e6f88: f9287a60    	str	x0, [x19, #0x50f0]
1005e6f8c: f84683ee    	ldur	x14, [sp, #0x68]
1005e6f90: f9287e6e    	str	x14, [x19, #0x50f8]
1005e6f94: f84703fa    	ldur	x26, [sp, #0x70]
1005e6f98: f928827a    	str	x26, [x19, #0x5100]
1005e6f9c: f929567b    	str	x27, [x19, #0x52a8]
1005e6fa0: f9295a65    	str	x5, [x19, #0x52b0]
1005e6fa4: f9295e76    	str	x22, [x19, #0x52b8]
1005e6fa8: f84d03e0    	ldur	x0, [sp, #0xd0]
1005e6fac: f9296260    	str	x0, [x19, #0x52c0]
1005e6fb0: f9296662    	str	x2, [x19, #0x52c8]
1005e6fb4: f9296a6f    	str	x15, [x19, #0x52d0]
1005e6fb8: f9296e79    	str	x25, [x19, #0x52d8]
1005e6fbc: f84283e1    	ldur	x1, [sp, #0x28]
1005e6fc0: f9297261    	str	x1, [x19, #0x52e0]
1005e6fc4: f84303e0    	ldur	x0, [sp, #0x30]
1005e6fc8: f9297660    	str	x0, [x19, #0x52e8]
1005e6fcc: f84503e1    	ldur	x1, [sp, #0x50]
1005e6fd0: f92d1261    	str	x1, [x19, #0x5a20]
1005e6fd4: 91000508    	add	x8, x8, #0x1
1005e6fd8: f92dda68    	str	x8, [x19, #0x5bb0]
1005e6fdc: f84883fa    	ldur	x26, [sp, #0x88]
1005e6fe0: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e6fe4: f84903e0    	ldur	x0, [sp, #0x90]
1005e6fe8: f92de260    	str	x0, [x19, #0x5bc0]
1005e6fec: f84783e0    	ldur	x0, [sp, #0x78]
1005e6ff0: cb04000e    	sub	x14, x0, x4
1005e6ff4: 52990fcf    	mov	w15, #0xc87e            ; =51326
1005e6ff8: 72a0002f    	movk	w15, #0x1, lsl #16
1005e6ffc: 9b0fb90e    	msub	x14, x8, x15, x14
1005e7000: f92de66e    	str	x14, [x19, #0x5bc8]
1005e7004: f92dea66    	str	x6, [x19, #0x5bd0]
1005e7008: f84203e0    	ldur	x0, [sp, #0x20]
1005e700c: f92dee60    	str	x0, [x19, #0x5bd8]
1005e7010: f92df666    	str	x6, [x19, #0x5be8]
1005e7014: f92dfa63    	str	x3, [x19, #0x5bf0]
1005e7018: f92e026c    	str	x12, [x19, #0x5c00]
1005e701c: f92e066b    	str	x11, [x19, #0x5c08]
1005e7020: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e7024: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e7028: f92e126d    	str	x13, [x19, #0x5c20]
1005e702c: f9663260    	ldr	x0, [x19, #0x4c60]
1005e7030: f100001f    	cmp	x0, #0x0
1005e7034: 54fe4181    	b.ne	0x1005e3864 <_mech_canonical_program_entry_v1_numeric_1282+0x21e4>
1005e7038: 17fff293    	b	0x1005e3a84 <_mech_canonical_program_entry_v1_numeric_1282+0x2404>
1005e703c: f80b83f8    	stur	x24, [sp, #0xb8]
1005e7040: 1400054e    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e7044: f80b83f8    	stur	x24, [sp, #0xb8]
1005e7048: 1400054c    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e704c: d280aa80    	mov	x0, #0x554              ; =1364
1005e7050: f84003ee    	ldur	x14, [sp]
1005e7054: f90025c0    	str	x0, [x14, #0x48]
1005e7058: d2800001    	mov	x1, #0x0                ; =0
1005e705c: f9000e61    	str	x1, [x19, #0x18]
1005e7060: d2e20000    	mov	x0, #0x1000000000000000 ; =1152921504606846976
1005e7064: f9001260    	str	x0, [x19, #0x20]
1005e7068: d2800020    	mov	x0, #0x1                ; =1
1005e706c: f80b83e0    	stur	x0, [sp, #0xb8]
1005e7070: f9001a60    	str	x0, [x19, #0x30]
1005e7074: b200c3e0    	mov	x0, #0x101010101010101  ; =72340172838076673
1005e7078: f9001e60    	str	x0, [x19, #0x38]
1005e707c: d2800040    	mov	x0, #0x2                ; =2
1005e7080: f9002260    	str	x0, [x19, #0x40]
1005e7084: d2800060    	mov	x0, #0x3                ; =3
1005e7088: f9002660    	str	x0, [x19, #0x48]
1005e708c: d2800080    	mov	x0, #0x4                ; =4
1005e7090: f9002a60    	str	x0, [x19, #0x50]
1005e7094: b200cfe0    	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e7098: f9003e60    	str	x0, [x19, #0x78]
1005e709c: b200e7e0    	mov	x0, #0x3333333333333333 ; =3689348814741910323
1005e70a0: f9004660    	str	x0, [x19, #0x88]
1005e70a4: d2800700    	mov	x0, #0x38               ; =56
1005e70a8: f9004a60    	str	x0, [x19, #0x90]
1005e70ac: d2800740    	mov	x0, #0x3a               ; =58
1005e70b0: f9004e60    	str	x0, [x19, #0x98]
1005e70b4: b200f3e0    	mov	x0, #0x5555555555555555 ; =6148914691236517205
1005e70b8: f9005a60    	str	x0, [x19, #0xb0]
1005e70bc: 92ff8000    	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
1005e70c0: f9005e60    	str	x0, [x19, #0xb8]
1005e70c4: f900c661    	str	x1, [x19, #0x188]
1005e70c8: f84b83e0    	ldur	x0, [sp, #0xb8]
1005e70cc: f900ca60    	str	x0, [x19, #0x190]
1005e70d0: f90bd276    	str	x22, [x19, #0x17a0]
1005e70d4: f90bd677    	str	x23, [x19, #0x17a8]
1005e70d8: f84e03e0    	ldur	x0, [sp, #0xe0]
1005e70dc: 53001c00    	uxtb	w0, w0
1005e70e0: f90bde60    	str	x0, [x19, #0x17b8]
1005e70e4: f84183e0    	ldur	x0, [sp, #0x18]
1005e70e8: f90c2e60    	str	x0, [x19, #0x1858]
1005e70ec: aa1a03ef    	mov	x15, x26
1005e70f0: f90c326f    	str	x15, [x19, #0x1860]
1005e70f4: f90c3676    	str	x22, [x19, #0x1868]
1005e70f8: f84d03ef    	ldur	x15, [sp, #0xd0]
1005e70fc: f90c3a6f    	str	x15, [x19, #0x1870]
1005e7100: f84c83ef    	ldur	x15, [sp, #0xc8]
1005e7104: 53001de1    	uxtb	w1, w15
1005e7108: f90c4261    	str	x1, [x19, #0x1880]
1005e710c: f90c8e7b    	str	x27, [x19, #0x1918]
1005e7110: f90c9265    	str	x5, [x19, #0x1920]
1005e7114: f90c9676    	str	x22, [x19, #0x1928]
1005e7118: f84d03ef    	ldur	x15, [sp, #0xd0]
1005e711c: f90c9a6f    	str	x15, [x19, #0x1930]
1005e7120: 53001ce6    	uxtb	w6, w7
1005e7124: f90ca266    	str	x6, [x19, #0x1940]
1005e7128: f90cae78    	str	x24, [x19, #0x1958]
1005e712c: f926326a    	str	x10, [x19, #0x4c60]
1005e7130: 529b83ca    	mov	w10, #0xdc1e            ; =56350
1005e7134: 72a0004a    	movk	w10, #0x2, lsl #16
1005e7138: cb0a0129    	sub	x9, x9, x10
1005e713c: f9263669    	str	x9, [x19, #0x4c68]
1005e7140: f84803e4    	ldur	x4, [sp, #0x80]
1005e7144: f9263a64    	str	x4, [x19, #0x4c70]
1005e7148: f84503e1    	ldur	x1, [sp, #0x50]
1005e714c: f92d1261    	str	x1, [x19, #0x5a20]
1005e7150: 9100050e    	add	x14, x8, #0x1
1005e7154: f92dda6e    	str	x14, [x19, #0x5bb0]
1005e7158: f84883fa    	ldur	x26, [sp, #0x88]
1005e715c: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e7160: f84903e6    	ldur	x6, [sp, #0x90]
1005e7164: f92de266    	str	x6, [x19, #0x5bc0]
1005e7168: f84783e4    	ldur	x4, [sp, #0x78]
1005e716c: cb09008f    	sub	x15, x4, x9
1005e7170: 52990fc1    	mov	w1, #0xc87e             ; =51326
1005e7174: 72a00021    	movk	w1, #0x1, lsl #16
1005e7178: 9b01bdcf    	msub	x15, x14, x1, x15
1005e717c: f92de66f    	str	x15, [x19, #0x5bc8]
1005e7180: f84b83e0    	ldur	x0, [sp, #0xb8]
1005e7184: f92dea60    	str	x0, [x19, #0x5bd0]
1005e7188: f84203f8    	ldur	x24, [sp, #0x20]
1005e718c: f92dee78    	str	x24, [x19, #0x5bd8]
1005e7190: f92df660    	str	x0, [x19, #0x5be8]
1005e7194: f92dfa63    	str	x3, [x19, #0x5bf0]
1005e7198: f92e026c    	str	x12, [x19, #0x5c00]
1005e719c: f92e066b    	str	x11, [x19, #0x5c08]
1005e71a0: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e71a4: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e71a8: f92e126d    	str	x13, [x19, #0x5c20]
1005e71ac: 140004f3    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e71b0: d280aaa6    	mov	x6, #0x555              ; =1365
1005e71b4: f84003ee    	ldur	x14, [sp]
1005e71b8: f90025c6    	str	x6, [x14, #0x48]
1005e71bc: d280000e    	mov	x14, #0x0               ; =0
1005e71c0: f9000e6e    	str	x14, [x19, #0x18]
1005e71c4: d2e20006    	mov	x6, #0x1000000000000000 ; =1152921504606846976
1005e71c8: f9001266    	str	x6, [x19, #0x20]
1005e71cc: d2800026    	mov	x6, #0x1                ; =1
1005e71d0: f9001a66    	str	x6, [x19, #0x30]
1005e71d4: b200c3f4    	mov	x20, #0x101010101010101 ; =72340172838076673
1005e71d8: f9001e74    	str	x20, [x19, #0x38]
1005e71dc: d2800054    	mov	x20, #0x2               ; =2
1005e71e0: f9002274    	str	x20, [x19, #0x40]
1005e71e4: d2800075    	mov	x21, #0x3               ; =3
1005e71e8: f9002675    	str	x21, [x19, #0x48]
1005e71ec: d2800095    	mov	x21, #0x4               ; =4
1005e71f0: f9002a75    	str	x21, [x19, #0x50]
1005e71f4: b200cff5    	mov	x21, #0xf0f0f0f0f0f0f0f ; =1085102592571150095
1005e71f8: f9003e75    	str	x21, [x19, #0x78]
1005e71fc: b200e7f5    	mov	x21, #0x3333333333333333 ; =3689348814741910323
1005e7200: f9004675    	str	x21, [x19, #0x88]
1005e7204: d2800715    	mov	x21, #0x38              ; =56
1005e7208: f9004a75    	str	x21, [x19, #0x90]
1005e720c: d2800755    	mov	x21, #0x3a              ; =58
1005e7210: f9004e75    	str	x21, [x19, #0x98]
1005e7214: b200f3f5    	mov	x21, #0x5555555555555555 ; =6148914691236517205
1005e7218: f9005a75    	str	x21, [x19, #0xb0]
1005e721c: 92ff8015    	mov	x21, #0x3ffffffffffffff ; =288230376151711743
1005e7220: f9005e75    	str	x21, [x19, #0xb8]
1005e7224: f900c66e    	str	x14, [x19, #0x188]
1005e7228: f900ca66    	str	x6, [x19, #0x190]
1005e722c: f90bd276    	str	x22, [x19, #0x17a0]
1005e7230: f90bd677    	str	x23, [x19, #0x17a8]
1005e7234: f84e03ee    	ldur	x14, [sp, #0xe0]
1005e7238: 53001dce    	uxtb	w14, w14
1005e723c: f90bde6e    	str	x14, [x19, #0x17b8]
1005e7240: f84183ee    	ldur	x14, [sp, #0x18]
1005e7244: f90c2e6e    	str	x14, [x19, #0x1858]
1005e7248: aa1a03ee    	mov	x14, x26
1005e724c: f90c326e    	str	x14, [x19, #0x1860]
1005e7250: f90c3676    	str	x22, [x19, #0x1868]
1005e7254: f84d03ee    	ldur	x14, [sp, #0xd0]
1005e7258: f90c3a6e    	str	x14, [x19, #0x1870]
1005e725c: f84c83ee    	ldur	x14, [sp, #0xc8]
1005e7260: 53001dce    	uxtb	w14, w14
1005e7264: f90c426e    	str	x14, [x19, #0x1880]
1005e7268: f90c8e7b    	str	x27, [x19, #0x1918]
1005e726c: f90c9265    	str	x5, [x19, #0x1920]
1005e7270: f90c9676    	str	x22, [x19, #0x1928]
1005e7274: f84d03ee    	ldur	x14, [sp, #0xd0]
1005e7278: f90c9a6e    	str	x14, [x19, #0x1930]
1005e727c: 53001ce7    	uxtb	w7, w7
1005e7280: f90ca267    	str	x7, [x19, #0x1940]
1005e7284: f90cae78    	str	x24, [x19, #0x1958]
1005e7288: f90cba64    	str	x4, [x19, #0x1970]
1005e728c: f926326a    	str	x10, [x19, #0x4c60]
1005e7290: 529b83c4    	mov	w4, #0xdc1e             ; =56350
1005e7294: 72a00044    	movk	w4, #0x2, lsl #16
1005e7298: cb040124    	sub	x4, x9, x4
1005e729c: f9263664    	str	x4, [x19, #0x4c68]
1005e72a0: f84803e7    	ldur	x7, [sp, #0x80]
1005e72a4: f9263a67    	str	x7, [x19, #0x4c70]
1005e72a8: f927ba76    	str	x22, [x19, #0x4f70]
1005e72ac: f927be77    	str	x23, [x19, #0x4f78]
1005e72b0: f84183e7    	ldur	x7, [sp, #0x18]
1005e72b4: f9286267    	str	x7, [x19, #0x50c0]
1005e72b8: aa1a03e7    	mov	x7, x26
1005e72bc: f9286667    	str	x7, [x19, #0x50c8]
1005e72c0: f9286a76    	str	x22, [x19, #0x50d0]
1005e72c4: f84d03e7    	ldur	x7, [sp, #0xd0]
1005e72c8: f9286e67    	str	x7, [x19, #0x50d8]
1005e72cc: f84103e7    	ldur	x7, [sp, #0x10]
1005e72d0: f9287267    	str	x7, [x19, #0x50e0]
1005e72d4: f84583f8    	ldur	x24, [sp, #0x58]
1005e72d8: f9287678    	str	x24, [x19, #0x50e8]
1005e72dc: f84603e7    	ldur	x7, [sp, #0x60]
1005e72e0: f9287a67    	str	x7, [x19, #0x50f0]
1005e72e4: f84683ee    	ldur	x14, [sp, #0x68]
1005e72e8: f9287e6e    	str	x14, [x19, #0x50f8]
1005e72ec: f84703fa    	ldur	x26, [sp, #0x70]
1005e72f0: f928827a    	str	x26, [x19, #0x5100]
1005e72f4: f929567b    	str	x27, [x19, #0x52a8]
1005e72f8: f9295a65    	str	x5, [x19, #0x52b0]
1005e72fc: f9295e76    	str	x22, [x19, #0x52b8]
1005e7300: f84d03e5    	ldur	x5, [sp, #0xd0]
1005e7304: f9296265    	str	x5, [x19, #0x52c0]
1005e7308: f9296662    	str	x2, [x19, #0x52c8]
1005e730c: f9296a6f    	str	x15, [x19, #0x52d0]
1005e7310: f9296e79    	str	x25, [x19, #0x52d8]
1005e7314: f9297261    	str	x1, [x19, #0x52e0]
1005e7318: f9297660    	str	x0, [x19, #0x52e8]
1005e731c: f84503e1    	ldur	x1, [sp, #0x50]
1005e7320: f92d1261    	str	x1, [x19, #0x5a20]
1005e7324: 91000500    	add	x0, x8, #0x1
1005e7328: f92dda60    	str	x0, [x19, #0x5bb0]
1005e732c: f84883fa    	ldur	x26, [sp, #0x88]
1005e7330: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e7334: f84903e1    	ldur	x1, [sp, #0x90]
1005e7338: f92de261    	str	x1, [x19, #0x5bc0]
1005e733c: f84783e1    	ldur	x1, [sp, #0x78]
1005e7340: cb040021    	sub	x1, x1, x4
1005e7344: 52990fc2    	mov	w2, #0xc87e             ; =51326
1005e7348: 72a00022    	movk	w2, #0x1, lsl #16
1005e734c: 9b028400    	msub	x0, x0, x2, x1
1005e7350: f92de660    	str	x0, [x19, #0x5bc8]
1005e7354: f92dea66    	str	x6, [x19, #0x5bd0]
1005e7358: f84203f8    	ldur	x24, [sp, #0x20]
1005e735c: f92dee78    	str	x24, [x19, #0x5bd8]
1005e7360: f92df666    	str	x6, [x19, #0x5be8]
1005e7364: f92dfa63    	str	x3, [x19, #0x5bf0]
1005e7368: f92e026c    	str	x12, [x19, #0x5c00]
1005e736c: f92e066b    	str	x11, [x19, #0x5c08]
1005e7370: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e7374: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e7378: f92e126d    	str	x13, [x19, #0x5c20]
1005e737c: f9663260    	ldr	x0, [x19, #0x4c60]
1005e7380: f100001f    	cmp	x0, #0x0
1005e7384: 54fe3d41    	b.ne	0x1005e3b2c <_mech_canonical_program_entry_v1_numeric_1282+0x24ac>
1005e7388: 17fff274    	b	0x1005e3d58 <_mech_canonical_program_entry_v1_numeric_1282+0x26d8>
1005e738c: f80b83f4    	stur	x20, [sp, #0xb8]
1005e7390: 1400047a    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e7394: f80b83f4    	stur	x20, [sp, #0xb8]
1005e7398: 14000478    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e739c: d280bd00    	mov	x0, #0x5e8              ; =1512
1005e73a0: f84003e1    	ldur	x1, [sp]
1005e73a4: f9002420    	str	x0, [x1, #0x48]
1005e73a8: d2800000    	mov	x0, #0x0                ; =0
1005e73ac: f9000e60    	str	x0, [x19, #0x18]
1005e73b0: d2e20001    	mov	x1, #0x1000000000000000 ; =1152921504606846976
1005e73b4: f9001261    	str	x1, [x19, #0x20]
1005e73b8: d2800021    	mov	x1, #0x1                ; =1
1005e73bc: f9001a61    	str	x1, [x19, #0x30]
1005e73c0: b200c3e2    	mov	x2, #0x101010101010101  ; =72340172838076673
1005e73c4: f9001e62    	str	x2, [x19, #0x38]
1005e73c8: d2800054    	mov	x20, #0x2               ; =2
1005e73cc: f9002274    	str	x20, [x19, #0x40]
1005e73d0: d2800062    	mov	x2, #0x3                ; =3
1005e73d4: f9002662    	str	x2, [x19, #0x48]
1005e73d8: d2800082    	mov	x2, #0x4                ; =4
1005e73dc: f9002a62    	str	x2, [x19, #0x50]
1005e73e0: b200cfe2    	mov	x2, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e73e4: f9003e62    	str	x2, [x19, #0x78]
1005e73e8: b200e7e4    	mov	x4, #0x3333333333333333 ; =3689348814741910323
1005e73ec: f9004664    	str	x4, [x19, #0x88]
1005e73f0: d2800704    	mov	x4, #0x38               ; =56
1005e73f4: f9004a64    	str	x4, [x19, #0x90]
1005e73f8: d2800745    	mov	x5, #0x3a               ; =58
1005e73fc: f9004e65    	str	x5, [x19, #0x98]
1005e7400: b200f3e6    	mov	x6, #0x5555555555555555 ; =6148914691236517205
1005e7404: f9005a66    	str	x6, [x19, #0xb0]
1005e7408: 92ff8007    	mov	x7, #0x3ffffffffffffff  ; =288230376151711743
1005e740c: f9005e67    	str	x7, [x19, #0xb8]
1005e7410: f900c660    	str	x0, [x19, #0x188]
1005e7414: f900ca61    	str	x1, [x19, #0x190]
1005e7418: f90bd276    	str	x22, [x19, #0x17a0]
1005e741c: f90bd677    	str	x23, [x19, #0x17a8]
1005e7420: f84e03f8    	ldur	x24, [sp, #0xe0]
1005e7424: 53001f0e    	uxtb	w14, w24
1005e7428: f90bde6e    	str	x14, [x19, #0x17b8]
1005e742c: f84d83f8    	ldur	x24, [sp, #0xd8]
1005e7430: f90e0278    	str	x24, [x19, #0x1c00]
1005e7434: f926326a    	str	x10, [x19, #0x4c60]
1005e7438: f9263663    	str	x3, [x19, #0x4c68]
1005e743c: f84803e4    	ldur	x4, [sp, #0x80]
1005e7440: f9263a64    	str	x4, [x19, #0x4c70]
1005e7444: f927ba76    	str	x22, [x19, #0x4f70]
1005e7448: f927be77    	str	x23, [x19, #0x4f78]
1005e744c: f84503e1    	ldur	x1, [sp, #0x50]
1005e7450: f92d1261    	str	x1, [x19, #0x5a20]
1005e7454: 91000501    	add	x1, x8, #0x1
1005e7458: f92dda61    	str	x1, [x19, #0x5bb0]
1005e745c: f84883fa    	ldur	x26, [sp, #0x88]
1005e7460: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e7464: f84903e6    	ldur	x6, [sp, #0x90]
1005e7468: f92de266    	str	x6, [x19, #0x5bc0]
1005e746c: f84783e4    	ldur	x4, [sp, #0x78]
1005e7470: cb030082    	sub	x2, x4, x3
1005e7474: 52990fc3    	mov	w3, #0xc87e             ; =51326
1005e7478: 72a00023    	movk	w3, #0x1, lsl #16
1005e747c: 9b038821    	msub	x1, x1, x3, x2
1005e7480: f92de661    	str	x1, [x19, #0x5bc8]
1005e7484: f92dea60    	str	x0, [x19, #0x5bd0]
1005e7488: f92dee60    	str	x0, [x19, #0x5bd8]
1005e748c: f84983ea    	ldur	x10, [sp, #0x98]
1005e7490: f92df66a    	str	x10, [x19, #0x5be8]
1005e7494: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e7498: f92dfa64    	str	x4, [x19, #0x5bf0]
1005e749c: f92e026c    	str	x12, [x19, #0x5c00]
1005e74a0: f92e066b    	str	x11, [x19, #0x5c08]
1005e74a4: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e74a8: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e74ac: f92e126d    	str	x13, [x19, #0x5c20]
1005e74b0: f9663260    	ldr	x0, [x19, #0x4c60]
1005e74b4: f100001f    	cmp	x0, #0x0
1005e74b8: 54fe5881    	b.ne	0x1005e3fc8 <_mech_canonical_program_entry_v1_numeric_1282+0x2948>
1005e74bc: 17fff34f    	b	0x1005e41f8 <_mech_canonical_program_entry_v1_numeric_1282+0x2b78>
1005e74c0: f80b83f4    	stur	x20, [sp, #0xb8]
1005e74c4: 1400042d    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e74c8: f80b83f4    	stur	x20, [sp, #0xb8]
1005e74cc: 1400042b    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e74d0: d280bd40    	mov	x0, #0x5ea              ; =1514
1005e74d4: f84003e2    	ldur	x2, [sp]
1005e74d8: f9002440    	str	x0, [x2, #0x48]
1005e74dc: d2800000    	mov	x0, #0x0                ; =0
1005e74e0: f9000e60    	str	x0, [x19, #0x18]
1005e74e4: d2e20001    	mov	x1, #0x1000000000000000 ; =1152921504606846976
1005e74e8: f9001261    	str	x1, [x19, #0x20]
1005e74ec: d2800021    	mov	x1, #0x1                ; =1
1005e74f0: f9001a61    	str	x1, [x19, #0x30]
1005e74f4: b200c3e2    	mov	x2, #0x101010101010101  ; =72340172838076673
1005e74f8: f9001e62    	str	x2, [x19, #0x38]
1005e74fc: d2800054    	mov	x20, #0x2               ; =2
1005e7500: f9002274    	str	x20, [x19, #0x40]
1005e7504: d2800062    	mov	x2, #0x3                ; =3
1005e7508: f9002662    	str	x2, [x19, #0x48]
1005e750c: d2800082    	mov	x2, #0x4                ; =4
1005e7510: f9002a62    	str	x2, [x19, #0x50]
1005e7514: b200cfe2    	mov	x2, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e7518: f9003e62    	str	x2, [x19, #0x78]
1005e751c: b200e7e2    	mov	x2, #0x3333333333333333 ; =3689348814741910323
1005e7520: f9004662    	str	x2, [x19, #0x88]
1005e7524: d2800702    	mov	x2, #0x38               ; =56
1005e7528: f9004a62    	str	x2, [x19, #0x90]
1005e752c: d2800742    	mov	x2, #0x3a               ; =58
1005e7530: f9004e62    	str	x2, [x19, #0x98]
1005e7534: b200f3e2    	mov	x2, #0x5555555555555555 ; =6148914691236517205
1005e7538: f9005a62    	str	x2, [x19, #0xb0]
1005e753c: 92ff8002    	mov	x2, #0x3ffffffffffffff  ; =288230376151711743
1005e7540: f9005e62    	str	x2, [x19, #0xb8]
1005e7544: f900c660    	str	x0, [x19, #0x188]
1005e7548: f900ca61    	str	x1, [x19, #0x190]
1005e754c: f90bd276    	str	x22, [x19, #0x17a0]
1005e7550: f90bd677    	str	x23, [x19, #0x17a8]
1005e7554: f84e03f8    	ldur	x24, [sp, #0xe0]
1005e7558: 53001f04    	uxtb	w4, w24
1005e755c: f90bde64    	str	x4, [x19, #0x17b8]
1005e7560: f90e066f    	str	x15, [x19, #0x1c08]
1005e7564: 91000ac5    	add	x5, x22, #0x2
1005e7568: f90e0a65    	str	x5, [x19, #0x1c10]
1005e756c: f926326a    	str	x10, [x19, #0x4c60]
1005e7570: f9263663    	str	x3, [x19, #0x4c68]
1005e7574: f84803e4    	ldur	x4, [sp, #0x80]
1005e7578: f9263a64    	str	x4, [x19, #0x4c70]
1005e757c: f927ba76    	str	x22, [x19, #0x4f70]
1005e7580: f927be77    	str	x23, [x19, #0x4f78]
1005e7584: f84503e1    	ldur	x1, [sp, #0x50]
1005e7588: f92d1261    	str	x1, [x19, #0x5a20]
1005e758c: 9100050e    	add	x14, x8, #0x1
1005e7590: f92dda6e    	str	x14, [x19, #0x5bb0]
1005e7594: f84883fa    	ldur	x26, [sp, #0x88]
1005e7598: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e759c: f84903e6    	ldur	x6, [sp, #0x90]
1005e75a0: f92de266    	str	x6, [x19, #0x5bc0]
1005e75a4: f84783e4    	ldur	x4, [sp, #0x78]
1005e75a8: cb03008f    	sub	x15, x4, x3
1005e75ac: 52990fc1    	mov	w1, #0xc87e             ; =51326
1005e75b0: 72a00021    	movk	w1, #0x1, lsl #16
1005e75b4: 9b01bdcf    	msub	x15, x14, x1, x15
1005e75b8: f92de66f    	str	x15, [x19, #0x5bc8]
1005e75bc: f92dea60    	str	x0, [x19, #0x5bd0]
1005e75c0: f92dee60    	str	x0, [x19, #0x5bd8]
1005e75c4: f84983ea    	ldur	x10, [sp, #0x98]
1005e75c8: f92df66a    	str	x10, [x19, #0x5be8]
1005e75cc: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e75d0: f92dfa64    	str	x4, [x19, #0x5bf0]
1005e75d4: f92e026c    	str	x12, [x19, #0x5c00]
1005e75d8: f92e066b    	str	x11, [x19, #0x5c08]
1005e75dc: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e75e0: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e75e4: f92e126d    	str	x13, [x19, #0x5c20]
1005e75e8: f9663260    	ldr	x0, [x19, #0x4c60]
1005e75ec: f100001f    	cmp	x0, #0x0
1005e75f0: 54fe63e1    	b.ne	0x1005e426c <_mech_canonical_program_entry_v1_numeric_1282+0x2bec>
1005e75f4: 17fff3a9    	b	0x1005e4498 <_mech_canonical_program_entry_v1_numeric_1282+0x2e18>
1005e75f8: f80b83f4    	stur	x20, [sp, #0xb8]
1005e75fc: 140003df    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e7600: f80b83f4    	stur	x20, [sp, #0xb8]
1005e7604: 140003dd    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e7608: f80b83f4    	stur	x20, [sp, #0xb8]
1005e760c: 140003db    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e7610: d280c080    	mov	x0, #0x604              ; =1540
1005e7614: f84003e1    	ldur	x1, [sp]
1005e7618: f9002420    	str	x0, [x1, #0x48]
1005e761c: d2800001    	mov	x1, #0x0                ; =0
1005e7620: f9000e61    	str	x1, [x19, #0x18]
1005e7624: f900127a    	str	x26, [x19, #0x20]
1005e7628: d2800020    	mov	x0, #0x1                ; =1
1005e762c: f80b83e0    	stur	x0, [sp, #0xb8]
1005e7630: f9001a60    	str	x0, [x19, #0x30]
1005e7634: b200c3e0    	mov	x0, #0x101010101010101  ; =72340172838076673
1005e7638: f9001e60    	str	x0, [x19, #0x38]
1005e763c: d2800040    	mov	x0, #0x2                ; =2
1005e7640: f9002260    	str	x0, [x19, #0x40]
1005e7644: d2800060    	mov	x0, #0x3                ; =3
1005e7648: f9002660    	str	x0, [x19, #0x48]
1005e764c: d2800080    	mov	x0, #0x4                ; =4
1005e7650: f9002a60    	str	x0, [x19, #0x50]
1005e7654: b200cfe0    	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e7658: f9003e60    	str	x0, [x19, #0x78]
1005e765c: b200e7e0    	mov	x0, #0x3333333333333333 ; =3689348814741910323
1005e7660: f9004660    	str	x0, [x19, #0x88]
1005e7664: d2800700    	mov	x0, #0x38               ; =56
1005e7668: f9004a60    	str	x0, [x19, #0x90]
1005e766c: d2800740    	mov	x0, #0x3a               ; =58
1005e7670: f9004e60    	str	x0, [x19, #0x98]
1005e7674: b200f3e0    	mov	x0, #0x5555555555555555 ; =6148914691236517205
1005e7678: f9005a60    	str	x0, [x19, #0xb0]
1005e767c: 92ff8000    	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
1005e7680: f9005e60    	str	x0, [x19, #0xb8]
1005e7684: f900c661    	str	x1, [x19, #0x188]
1005e7688: f84b83e0    	ldur	x0, [sp, #0xb8]
1005e768c: f900ca60    	str	x0, [x19, #0x190]
1005e7690: f90bd276    	str	x22, [x19, #0x17a0]
1005e7694: f90bd677    	str	x23, [x19, #0x17a8]
1005e7698: f84e03f8    	ldur	x24, [sp, #0xe0]
1005e769c: 53001f05    	uxtb	w5, w24
1005e76a0: f90bde65    	str	x5, [x19, #0x17b8]
1005e76a4: f90e3a6f    	str	x15, [x19, #0x1c70]
1005e76a8: f90e3e6c    	str	x12, [x19, #0x1c78]
1005e76ac: f90e4276    	str	x22, [x19, #0x1c80]
1005e76b0: f90e5679    	str	x25, [x19, #0x1ca8]
1005e76b4: f926326a    	str	x10, [x19, #0x4c60]
1005e76b8: 5284c8cb    	mov	w11, #0x2646            ; =9798
1005e76bc: 72a0002b    	movk	w11, #0x1, lsl #16
1005e76c0: cb0b006b    	sub	x11, x3, x11
1005e76c4: f926366b    	str	x11, [x19, #0x4c68]
1005e76c8: f84803e4    	ldur	x4, [sp, #0x80]
1005e76cc: f9263a64    	str	x4, [x19, #0x4c70]
1005e76d0: f84503e0    	ldur	x0, [sp, #0x50]
1005e76d4: f92d1260    	str	x0, [x19, #0x5a20]
1005e76d8: 9100050e    	add	x14, x8, #0x1
1005e76dc: f92dda6e    	str	x14, [x19, #0x5bb0]
1005e76e0: f84883fa    	ldur	x26, [sp, #0x88]
1005e76e4: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e76e8: f84903e6    	ldur	x6, [sp, #0x90]
1005e76ec: f92de266    	str	x6, [x19, #0x5bc0]
1005e76f0: f84783e4    	ldur	x4, [sp, #0x78]
1005e76f4: cb0b0082    	sub	x2, x4, x11
1005e76f8: 52990fc3    	mov	w3, #0xc87e             ; =51326
1005e76fc: 72a00023    	movk	w3, #0x1, lsl #16
1005e7700: 9b0389c0    	msub	x0, x14, x3, x2
1005e7704: f92de660    	str	x0, [x19, #0x5bc8]
1005e7708: f92dea61    	str	x1, [x19, #0x5bd0]
1005e770c: f92dee61    	str	x1, [x19, #0x5bd8]
1005e7710: f84983ea    	ldur	x10, [sp, #0x98]
1005e7714: f92df66a    	str	x10, [x19, #0x5be8]
1005e7718: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e771c: f92dfa64    	str	x4, [x19, #0x5bf0]
1005e7720: f84b83e0    	ldur	x0, [sp, #0xb8]
1005e7724: f92e0260    	str	x0, [x19, #0x5c00]
1005e7728: f84403e7    	ldur	x7, [sp, #0x40]
1005e772c: f92e0667    	str	x7, [x19, #0x5c08]
1005e7730: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e7734: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e7738: f92e126d    	str	x13, [x19, #0x5c20]
1005e773c: 1400038f    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e7740: d280c0a0    	mov	x0, #0x605              ; =1541
1005e7744: f84003e1    	ldur	x1, [sp]
1005e7748: f9002420    	str	x0, [x1, #0x48]
1005e774c: d2800000    	mov	x0, #0x0                ; =0
1005e7750: f9000e60    	str	x0, [x19, #0x18]
1005e7754: f900127a    	str	x26, [x19, #0x20]
1005e7758: d2800021    	mov	x1, #0x1                ; =1
1005e775c: f9001a61    	str	x1, [x19, #0x30]
1005e7760: b200c3e4    	mov	x4, #0x101010101010101  ; =72340172838076673
1005e7764: f9001e64    	str	x4, [x19, #0x38]
1005e7768: d2800054    	mov	x20, #0x2               ; =2
1005e776c: f9002274    	str	x20, [x19, #0x40]
1005e7770: d2800064    	mov	x4, #0x3                ; =3
1005e7774: f9002664    	str	x4, [x19, #0x48]
1005e7778: d2800084    	mov	x4, #0x4                ; =4
1005e777c: f9002a64    	str	x4, [x19, #0x50]
1005e7780: b200cfe4    	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e7784: f9003e64    	str	x4, [x19, #0x78]
1005e7788: b200e7e4    	mov	x4, #0x3333333333333333 ; =3689348814741910323
1005e778c: f9004664    	str	x4, [x19, #0x88]
1005e7790: d2800704    	mov	x4, #0x38               ; =56
1005e7794: f9004a64    	str	x4, [x19, #0x90]
1005e7798: d2800744    	mov	x4, #0x3a               ; =58
1005e779c: f9004e64    	str	x4, [x19, #0x98]
1005e77a0: b200f3e4    	mov	x4, #0x5555555555555555 ; =6148914691236517205
1005e77a4: f9005a64    	str	x4, [x19, #0xb0]
1005e77a8: 92ff8004    	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
1005e77ac: f9005e64    	str	x4, [x19, #0xb8]
1005e77b0: f900c660    	str	x0, [x19, #0x188]
1005e77b4: f900ca61    	str	x1, [x19, #0x190]
1005e77b8: f90bd276    	str	x22, [x19, #0x17a0]
1005e77bc: f90bd677    	str	x23, [x19, #0x17a8]
1005e77c0: f84e03f8    	ldur	x24, [sp, #0xe0]
1005e77c4: 53001f04    	uxtb	w4, w24
1005e77c8: f90bde64    	str	x4, [x19, #0x17b8]
1005e77cc: f90e3a6f    	str	x15, [x19, #0x1c70]
1005e77d0: f90e3e6c    	str	x12, [x19, #0x1c78]
1005e77d4: f90e4276    	str	x22, [x19, #0x1c80]
1005e77d8: f90e5679    	str	x25, [x19, #0x1ca8]
1005e77dc: f90e5e62    	str	x2, [x19, #0x1cb8]
1005e77e0: f926326a    	str	x10, [x19, #0x4c60]
1005e77e4: 5284c8c2    	mov	w2, #0x2646             ; =9798
1005e77e8: 72a00022    	movk	w2, #0x1, lsl #16
1005e77ec: cb020062    	sub	x2, x3, x2
1005e77f0: f9263662    	str	x2, [x19, #0x4c68]
1005e77f4: f84803e4    	ldur	x4, [sp, #0x80]
1005e77f8: f9263a64    	str	x4, [x19, #0x4c70]
1005e77fc: f927ba76    	str	x22, [x19, #0x4f70]
1005e7800: f927be77    	str	x23, [x19, #0x4f78]
1005e7804: f92aee6f    	str	x15, [x19, #0x55d8]
1005e7808: f92af26c    	str	x12, [x19, #0x55e0]
1005e780c: f92af676    	str	x22, [x19, #0x55e8]
1005e7810: f84103f9    	ldur	x25, [sp, #0x10]
1005e7814: f92afa79    	str	x25, [x19, #0x55f0]
1005e7818: f84583f8    	ldur	x24, [sp, #0x58]
1005e781c: f92afe78    	str	x24, [x19, #0x55f8]
1005e7820: f84603fb    	ldur	x27, [sp, #0x60]
1005e7824: f92b027b    	str	x27, [x19, #0x5600]
1005e7828: f84683f9    	ldur	x25, [sp, #0x68]
1005e782c: f92b0679    	str	x25, [x19, #0x5608]
1005e7830: f84703fa    	ldur	x26, [sp, #0x70]
1005e7834: f92b0a7a    	str	x26, [x19, #0x5610]
1005e7838: f84503e3    	ldur	x3, [sp, #0x50]
1005e783c: f92d1263    	str	x3, [x19, #0x5a20]
1005e7840: 91000505    	add	x5, x8, #0x1
1005e7844: f92dda65    	str	x5, [x19, #0x5bb0]
1005e7848: f84883fa    	ldur	x26, [sp, #0x88]
1005e784c: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e7850: f84903e6    	ldur	x6, [sp, #0x90]
1005e7854: f92de266    	str	x6, [x19, #0x5bc0]
1005e7858: f84783e4    	ldur	x4, [sp, #0x78]
1005e785c: cb020088    	sub	x8, x4, x2
1005e7860: 52990fc9    	mov	w9, #0xc87e             ; =51326
1005e7864: 72a00029    	movk	w9, #0x1, lsl #16
1005e7868: 9b09a0a8    	msub	x8, x5, x9, x8
1005e786c: f92de668    	str	x8, [x19, #0x5bc8]
1005e7870: f92dea60    	str	x0, [x19, #0x5bd0]
1005e7874: f92dee60    	str	x0, [x19, #0x5bd8]
1005e7878: f84983ea    	ldur	x10, [sp, #0x98]
1005e787c: f92df66a    	str	x10, [x19, #0x5be8]
1005e7880: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e7884: f92dfa64    	str	x4, [x19, #0x5bf0]
1005e7888: f92e0261    	str	x1, [x19, #0x5c00]
1005e788c: f84403e7    	ldur	x7, [sp, #0x40]
1005e7890: f92e0667    	str	x7, [x19, #0x5c08]
1005e7894: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e7898: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e789c: f92e126d    	str	x13, [x19, #0x5c20]
1005e78a0: f9663260    	ldr	x0, [x19, #0x4c60]
1005e78a4: f100001f    	cmp	x0, #0x0
1005e78a8: 54fe8401    	b.ne	0x1005e4928 <_mech_canonical_program_entry_v1_numeric_1282+0x32a8>
1005e78ac: 17fff4a9    	b	0x1005e4b50 <_mech_canonical_program_entry_v1_numeric_1282+0x34d0>
1005e78b0: f80b83f4    	stur	x20, [sp, #0xb8]
1005e78b4: 14000331    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e78b8: f80b83f4    	stur	x20, [sp, #0xb8]
1005e78bc: 1400032f    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e78c0: d280c0c0    	mov	x0, #0x606              ; =1542
1005e78c4: f84003e2    	ldur	x2, [sp]
1005e78c8: f9002440    	str	x0, [x2, #0x48]
1005e78cc: d2800002    	mov	x2, #0x0                ; =0
1005e78d0: f9000e62    	str	x2, [x19, #0x18]
1005e78d4: f900127a    	str	x26, [x19, #0x20]
1005e78d8: d2800020    	mov	x0, #0x1                ; =1
1005e78dc: f80b83e0    	stur	x0, [sp, #0xb8]
1005e78e0: f9001a60    	str	x0, [x19, #0x30]
1005e78e4: b200c3e0    	mov	x0, #0x101010101010101  ; =72340172838076673
1005e78e8: f9001e60    	str	x0, [x19, #0x38]
1005e78ec: d2800040    	mov	x0, #0x2                ; =2
1005e78f0: f9002260    	str	x0, [x19, #0x40]
1005e78f4: d2800060    	mov	x0, #0x3                ; =3
1005e78f8: f9002660    	str	x0, [x19, #0x48]
1005e78fc: d2800080    	mov	x0, #0x4                ; =4
1005e7900: f9002a60    	str	x0, [x19, #0x50]
1005e7904: b200cfe0    	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e7908: f9003e60    	str	x0, [x19, #0x78]
1005e790c: b200e7e0    	mov	x0, #0x3333333333333333 ; =3689348814741910323
1005e7910: f9004660    	str	x0, [x19, #0x88]
1005e7914: d2800700    	mov	x0, #0x38               ; =56
1005e7918: f9004a60    	str	x0, [x19, #0x90]
1005e791c: d2800740    	mov	x0, #0x3a               ; =58
1005e7920: f9004e60    	str	x0, [x19, #0x98]
1005e7924: b200f3e0    	mov	x0, #0x5555555555555555 ; =6148914691236517205
1005e7928: f9005a60    	str	x0, [x19, #0xb0]
1005e792c: 92ff8000    	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
1005e7930: f9005e60    	str	x0, [x19, #0xb8]
1005e7934: f900c662    	str	x2, [x19, #0x188]
1005e7938: f84b83e0    	ldur	x0, [sp, #0xb8]
1005e793c: f900ca60    	str	x0, [x19, #0x190]
1005e7940: f90bd276    	str	x22, [x19, #0x17a0]
1005e7944: f90bd677    	str	x23, [x19, #0x17a8]
1005e7948: f84e03f8    	ldur	x24, [sp, #0xe0]
1005e794c: 53001f00    	uxtb	w0, w24
1005e7950: f90bde60    	str	x0, [x19, #0x17b8]
1005e7954: f90e3a6f    	str	x15, [x19, #0x1c70]
1005e7958: f90e3e6c    	str	x12, [x19, #0x1c78]
1005e795c: f90e4276    	str	x22, [x19, #0x1c80]
1005e7960: f90e5679    	str	x25, [x19, #0x1ca8]
1005e7964: f90e6261    	str	x1, [x19, #0x1cc0]
1005e7968: f926326a    	str	x10, [x19, #0x4c60]
1005e796c: 5284c8c1    	mov	w1, #0x2646             ; =9798
1005e7970: 72a00021    	movk	w1, #0x1, lsl #16
1005e7974: cb010061    	sub	x1, x3, x1
1005e7978: f9263661    	str	x1, [x19, #0x4c68]
1005e797c: f84803e4    	ldur	x4, [sp, #0x80]
1005e7980: f9263a64    	str	x4, [x19, #0x4c70]
1005e7984: f84503e0    	ldur	x0, [sp, #0x50]
1005e7988: f92d1260    	str	x0, [x19, #0x5a20]
1005e798c: 91000503    	add	x3, x8, #0x1
1005e7990: f92dda63    	str	x3, [x19, #0x5bb0]
1005e7994: f84883fa    	ldur	x26, [sp, #0x88]
1005e7998: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e799c: f84903e6    	ldur	x6, [sp, #0x90]
1005e79a0: f92de266    	str	x6, [x19, #0x5bc0]
1005e79a4: f84783e4    	ldur	x4, [sp, #0x78]
1005e79a8: cb010081    	sub	x1, x4, x1
1005e79ac: 52990fc4    	mov	w4, #0xc87e             ; =51326
1005e79b0: 72a00024    	movk	w4, #0x1, lsl #16
1005e79b4: 9b048460    	msub	x0, x3, x4, x1
1005e79b8: f92de660    	str	x0, [x19, #0x5bc8]
1005e79bc: f92dea62    	str	x2, [x19, #0x5bd0]
1005e79c0: f92dee62    	str	x2, [x19, #0x5bd8]
1005e79c4: f84983ea    	ldur	x10, [sp, #0x98]
1005e79c8: f92df66a    	str	x10, [x19, #0x5be8]
1005e79cc: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e79d0: f92dfa64    	str	x4, [x19, #0x5bf0]
1005e79d4: f84b83e0    	ldur	x0, [sp, #0xb8]
1005e79d8: f92e0260    	str	x0, [x19, #0x5c00]
1005e79dc: f84403e7    	ldur	x7, [sp, #0x40]
1005e79e0: f92e0667    	str	x7, [x19, #0x5c08]
1005e79e4: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e79e8: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e79ec: f92e126d    	str	x13, [x19, #0x5c20]
1005e79f0: 140002e2    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e79f4: d280c0ee    	mov	x14, #0x607             ; =1543
1005e79f8: f84003e0    	ldur	x0, [sp]
1005e79fc: f900240e    	str	x14, [x0, #0x48]
1005e7a00: d280000e    	mov	x14, #0x0               ; =0
1005e7a04: f9000e6e    	str	x14, [x19, #0x18]
1005e7a08: f900127a    	str	x26, [x19, #0x20]
1005e7a0c: d2800020    	mov	x0, #0x1                ; =1
1005e7a10: f9001a60    	str	x0, [x19, #0x30]
1005e7a14: b200c3e4    	mov	x4, #0x101010101010101  ; =72340172838076673
1005e7a18: f9001e64    	str	x4, [x19, #0x38]
1005e7a1c: d2800054    	mov	x20, #0x2               ; =2
1005e7a20: f9002274    	str	x20, [x19, #0x40]
1005e7a24: d2800064    	mov	x4, #0x3                ; =3
1005e7a28: f9002664    	str	x4, [x19, #0x48]
1005e7a2c: d2800084    	mov	x4, #0x4                ; =4
1005e7a30: f9002a64    	str	x4, [x19, #0x50]
1005e7a34: b200cfe4    	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e7a38: f9003e64    	str	x4, [x19, #0x78]
1005e7a3c: b200e7e4    	mov	x4, #0x3333333333333333 ; =3689348814741910323
1005e7a40: f9004664    	str	x4, [x19, #0x88]
1005e7a44: d2800704    	mov	x4, #0x38               ; =56
1005e7a48: f9004a64    	str	x4, [x19, #0x90]
1005e7a4c: d2800744    	mov	x4, #0x3a               ; =58
1005e7a50: f9004e64    	str	x4, [x19, #0x98]
1005e7a54: b200f3e4    	mov	x4, #0x5555555555555555 ; =6148914691236517205
1005e7a58: f9005a64    	str	x4, [x19, #0xb0]
1005e7a5c: 92ff8004    	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
1005e7a60: f9005e64    	str	x4, [x19, #0xb8]
1005e7a64: f900c66e    	str	x14, [x19, #0x188]
1005e7a68: f900ca60    	str	x0, [x19, #0x190]
1005e7a6c: f90bd276    	str	x22, [x19, #0x17a0]
1005e7a70: f90bd677    	str	x23, [x19, #0x17a8]
1005e7a74: f84e03f8    	ldur	x24, [sp, #0xe0]
1005e7a78: 53001f04    	uxtb	w4, w24
1005e7a7c: f90bde64    	str	x4, [x19, #0x17b8]
1005e7a80: f90e3a6f    	str	x15, [x19, #0x1c70]
1005e7a84: f90e3e6c    	str	x12, [x19, #0x1c78]
1005e7a88: f90e4276    	str	x22, [x19, #0x1c80]
1005e7a8c: f90e5679    	str	x25, [x19, #0x1ca8]
1005e7a90: f90e6261    	str	x1, [x19, #0x1cc0]
1005e7a94: f90e6662    	str	x2, [x19, #0x1cc8]
1005e7a98: f926326a    	str	x10, [x19, #0x4c60]
1005e7a9c: 5284c8c1    	mov	w1, #0x2646             ; =9798
1005e7aa0: 72a00021    	movk	w1, #0x1, lsl #16
1005e7aa4: cb010061    	sub	x1, x3, x1
1005e7aa8: f9263661    	str	x1, [x19, #0x4c68]
1005e7aac: f84803e4    	ldur	x4, [sp, #0x80]
1005e7ab0: f9263a64    	str	x4, [x19, #0x4c70]
1005e7ab4: f927ba76    	str	x22, [x19, #0x4f70]
1005e7ab8: f927be77    	str	x23, [x19, #0x4f78]
1005e7abc: f92aee6f    	str	x15, [x19, #0x55d8]
1005e7ac0: f92af26c    	str	x12, [x19, #0x55e0]
1005e7ac4: f92af676    	str	x22, [x19, #0x55e8]
1005e7ac8: f84103f9    	ldur	x25, [sp, #0x10]
1005e7acc: f92afa79    	str	x25, [x19, #0x55f0]
1005e7ad0: f84583f8    	ldur	x24, [sp, #0x58]
1005e7ad4: f92afe78    	str	x24, [x19, #0x55f8]
1005e7ad8: f84603fb    	ldur	x27, [sp, #0x60]
1005e7adc: f92b027b    	str	x27, [x19, #0x5600]
1005e7ae0: f84683f9    	ldur	x25, [sp, #0x68]
1005e7ae4: f92b0679    	str	x25, [x19, #0x5608]
1005e7ae8: f84703fa    	ldur	x26, [sp, #0x70]
1005e7aec: f92b0a7a    	str	x26, [x19, #0x5610]
1005e7af0: f84503eb    	ldur	x11, [sp, #0x50]
1005e7af4: f92d126b    	str	x11, [x19, #0x5a20]
1005e7af8: 91000502    	add	x2, x8, #0x1
1005e7afc: f92dda62    	str	x2, [x19, #0x5bb0]
1005e7b00: f84883fa    	ldur	x26, [sp, #0x88]
1005e7b04: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e7b08: f84903e6    	ldur	x6, [sp, #0x90]
1005e7b0c: f92de266    	str	x6, [x19, #0x5bc0]
1005e7b10: f84783e4    	ldur	x4, [sp, #0x78]
1005e7b14: cb010081    	sub	x1, x4, x1
1005e7b18: 52990fc3    	mov	w3, #0xc87e             ; =51326
1005e7b1c: 72a00023    	movk	w3, #0x1, lsl #16
1005e7b20: 9b038441    	msub	x1, x2, x3, x1
1005e7b24: f92de661    	str	x1, [x19, #0x5bc8]
1005e7b28: f92dea6e    	str	x14, [x19, #0x5bd0]
1005e7b2c: f92dee6e    	str	x14, [x19, #0x5bd8]
1005e7b30: f84983ea    	ldur	x10, [sp, #0x98]
1005e7b34: f92df66a    	str	x10, [x19, #0x5be8]
1005e7b38: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e7b3c: f92dfa64    	str	x4, [x19, #0x5bf0]
1005e7b40: f92e0260    	str	x0, [x19, #0x5c00]
1005e7b44: f84403e7    	ldur	x7, [sp, #0x40]
1005e7b48: f92e0667    	str	x7, [x19, #0x5c08]
1005e7b4c: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e7b50: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e7b54: f92e126d    	str	x13, [x19, #0x5c20]
1005e7b58: f9663260    	ldr	x0, [x19, #0x4c60]
1005e7b5c: f100001f    	cmp	x0, #0x0
1005e7b60: 54fe8361    	b.ne	0x1005e4bcc <_mech_canonical_program_entry_v1_numeric_1282+0x354c>
1005e7b64: 17fff49f    	b	0x1005e4de0 <_mech_canonical_program_entry_v1_numeric_1282+0x3760>
1005e7b68: f80b83f4    	stur	x20, [sp, #0xb8]
1005e7b6c: 14000283    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e7b70: f80b83f4    	stur	x20, [sp, #0xb8]
1005e7b74: 14000281    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e7b78: d280c120    	mov	x0, #0x609              ; =1545
1005e7b7c: f84003e2    	ldur	x2, [sp]
1005e7b80: f9002440    	str	x0, [x2, #0x48]
1005e7b84: d2800000    	mov	x0, #0x0                ; =0
1005e7b88: f9000e60    	str	x0, [x19, #0x18]
1005e7b8c: f900127a    	str	x26, [x19, #0x20]
1005e7b90: d2800022    	mov	x2, #0x1                ; =1
1005e7b94: f9001a62    	str	x2, [x19, #0x30]
1005e7b98: b200c3e4    	mov	x4, #0x101010101010101  ; =72340172838076673
1005e7b9c: f9001e64    	str	x4, [x19, #0x38]
1005e7ba0: d2800055    	mov	x21, #0x2               ; =2
1005e7ba4: f9002275    	str	x21, [x19, #0x40]
1005e7ba8: d2800064    	mov	x4, #0x3                ; =3
1005e7bac: f9002664    	str	x4, [x19, #0x48]
1005e7bb0: d2800084    	mov	x4, #0x4                ; =4
1005e7bb4: f9002a64    	str	x4, [x19, #0x50]
1005e7bb8: b200cfe4    	mov	x4, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e7bbc: f9003e64    	str	x4, [x19, #0x78]
1005e7bc0: b200e7e4    	mov	x4, #0x3333333333333333 ; =3689348814741910323
1005e7bc4: f9004664    	str	x4, [x19, #0x88]
1005e7bc8: d2800704    	mov	x4, #0x38               ; =56
1005e7bcc: f9004a64    	str	x4, [x19, #0x90]
1005e7bd0: d2800744    	mov	x4, #0x3a               ; =58
1005e7bd4: f9004e64    	str	x4, [x19, #0x98]
1005e7bd8: b200f3e4    	mov	x4, #0x5555555555555555 ; =6148914691236517205
1005e7bdc: f9005a64    	str	x4, [x19, #0xb0]
1005e7be0: 92ff8004    	mov	x4, #0x3ffffffffffffff  ; =288230376151711743
1005e7be4: f9005e64    	str	x4, [x19, #0xb8]
1005e7be8: f900c660    	str	x0, [x19, #0x188]
1005e7bec: f900ca62    	str	x2, [x19, #0x190]
1005e7bf0: f90bd276    	str	x22, [x19, #0x17a0]
1005e7bf4: f90bd677    	str	x23, [x19, #0x17a8]
1005e7bf8: f84e03f8    	ldur	x24, [sp, #0xe0]
1005e7bfc: 53001f04    	uxtb	w4, w24
1005e7c00: f90bde64    	str	x4, [x19, #0x17b8]
1005e7c04: f90e3a6f    	str	x15, [x19, #0x1c70]
1005e7c08: f90e3e6c    	str	x12, [x19, #0x1c78]
1005e7c0c: f90e4276    	str	x22, [x19, #0x1c80]
1005e7c10: f90e5679    	str	x25, [x19, #0x1ca8]
1005e7c14: f90e6a7b    	str	x27, [x19, #0x1cd0]
1005e7c18: 91000821    	add	x1, x1, #0x2
1005e7c1c: f90e6e61    	str	x1, [x19, #0x1cd8]
1005e7c20: f926326a    	str	x10, [x19, #0x4c60]
1005e7c24: 5284c8c1    	mov	w1, #0x2646             ; =9798
1005e7c28: 72a00021    	movk	w1, #0x1, lsl #16
1005e7c2c: cb010061    	sub	x1, x3, x1
1005e7c30: f9263661    	str	x1, [x19, #0x4c68]
1005e7c34: f84803e4    	ldur	x4, [sp, #0x80]
1005e7c38: f9263a64    	str	x4, [x19, #0x4c70]
1005e7c3c: f927ba76    	str	x22, [x19, #0x4f70]
1005e7c40: f927be77    	str	x23, [x19, #0x4f78]
1005e7c44: f92aee6f    	str	x15, [x19, #0x55d8]
1005e7c48: f92af26c    	str	x12, [x19, #0x55e0]
1005e7c4c: f92af676    	str	x22, [x19, #0x55e8]
1005e7c50: f84103f9    	ldur	x25, [sp, #0x10]
1005e7c54: f92afa79    	str	x25, [x19, #0x55f0]
1005e7c58: f84583f8    	ldur	x24, [sp, #0x58]
1005e7c5c: f92afe78    	str	x24, [x19, #0x55f8]
1005e7c60: f84603fb    	ldur	x27, [sp, #0x60]
1005e7c64: f92b027b    	str	x27, [x19, #0x5600]
1005e7c68: f84683f9    	ldur	x25, [sp, #0x68]
1005e7c6c: f92b0679    	str	x25, [x19, #0x5608]
1005e7c70: f84703fa    	ldur	x26, [sp, #0x70]
1005e7c74: f92b0a7a    	str	x26, [x19, #0x5610]
1005e7c78: f84503e3    	ldur	x3, [sp, #0x50]
1005e7c7c: f92d1263    	str	x3, [x19, #0x5a20]
1005e7c80: 91000503    	add	x3, x8, #0x1
1005e7c84: f92dda63    	str	x3, [x19, #0x5bb0]
1005e7c88: f84883fa    	ldur	x26, [sp, #0x88]
1005e7c8c: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e7c90: f84903e6    	ldur	x6, [sp, #0x90]
1005e7c94: f92de266    	str	x6, [x19, #0x5bc0]
1005e7c98: f84783e4    	ldur	x4, [sp, #0x78]
1005e7c9c: cb010081    	sub	x1, x4, x1
1005e7ca0: 52990fc4    	mov	w4, #0xc87e             ; =51326
1005e7ca4: 72a00024    	movk	w4, #0x1, lsl #16
1005e7ca8: 9b048461    	msub	x1, x3, x4, x1
1005e7cac: f92de661    	str	x1, [x19, #0x5bc8]
1005e7cb0: f92dea60    	str	x0, [x19, #0x5bd0]
1005e7cb4: f92dee60    	str	x0, [x19, #0x5bd8]
1005e7cb8: f84983ea    	ldur	x10, [sp, #0x98]
1005e7cbc: f92df66a    	str	x10, [x19, #0x5be8]
1005e7cc0: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e7cc4: f92dfa64    	str	x4, [x19, #0x5bf0]
1005e7cc8: f92e0262    	str	x2, [x19, #0x5c00]
1005e7ccc: f84403e7    	ldur	x7, [sp, #0x40]
1005e7cd0: f92e0667    	str	x7, [x19, #0x5c08]
1005e7cd4: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e7cd8: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e7cdc: f92e126d    	str	x13, [x19, #0x5c20]
1005e7ce0: f9663264    	ldr	x4, [x19, #0x4c60]
1005e7ce4: f100009f    	cmp	x4, #0x0
1005e7ce8: 54fe8b41    	b.ne	0x1005e4e50 <_mech_canonical_program_entry_v1_numeric_1282+0x37d0>
1005e7cec: 17fff4dd    	b	0x1005e5060 <_mech_canonical_program_entry_v1_numeric_1282+0x39e0>
1005e7cf0: f80b83f5    	stur	x21, [sp, #0xb8]
1005e7cf4: 14000221    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e7cf8: f80b83f5    	stur	x21, [sp, #0xb8]
1005e7cfc: 1400021f    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e7d00: f80b83f4    	stur	x20, [sp, #0xb8]
1005e7d04: 1400021d    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e7d08: d280c422    	mov	x2, #0x621              ; =1569
1005e7d0c: f84003e5    	ldur	x5, [sp]
1005e7d10: f90024a2    	str	x2, [x5, #0x48]
1005e7d14: d2800005    	mov	x5, #0x0                ; =0
1005e7d18: f9000e65    	str	x5, [x19, #0x18]
1005e7d1c: f900127a    	str	x26, [x19, #0x20]
1005e7d20: d2800022    	mov	x2, #0x1                ; =1
1005e7d24: f9001a62    	str	x2, [x19, #0x30]
1005e7d28: b200c3e6    	mov	x6, #0x101010101010101  ; =72340172838076673
1005e7d2c: f9001e66    	str	x6, [x19, #0x38]
1005e7d30: d2800054    	mov	x20, #0x2               ; =2
1005e7d34: f9002274    	str	x20, [x19, #0x40]
1005e7d38: d2800066    	mov	x6, #0x3                ; =3
1005e7d3c: f9002666    	str	x6, [x19, #0x48]
1005e7d40: d2800086    	mov	x6, #0x4                ; =4
1005e7d44: f9002a66    	str	x6, [x19, #0x50]
1005e7d48: b200cfe6    	mov	x6, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e7d4c: f9003e66    	str	x6, [x19, #0x78]
1005e7d50: b200e7e6    	mov	x6, #0x3333333333333333 ; =3689348814741910323
1005e7d54: f9004666    	str	x6, [x19, #0x88]
1005e7d58: d2800706    	mov	x6, #0x38               ; =56
1005e7d5c: f9004a66    	str	x6, [x19, #0x90]
1005e7d60: d2800746    	mov	x6, #0x3a               ; =58
1005e7d64: f9004e66    	str	x6, [x19, #0x98]
1005e7d68: b200f3e6    	mov	x6, #0x5555555555555555 ; =6148914691236517205
1005e7d6c: f9005a66    	str	x6, [x19, #0xb0]
1005e7d70: 92ff8006    	mov	x6, #0x3ffffffffffffff  ; =288230376151711743
1005e7d74: f9005e66    	str	x6, [x19, #0xb8]
1005e7d78: f900c665    	str	x5, [x19, #0x188]
1005e7d7c: f900ca62    	str	x2, [x19, #0x190]
1005e7d80: f90bd276    	str	x22, [x19, #0x17a0]
1005e7d84: f90bd677    	str	x23, [x19, #0x17a8]
1005e7d88: f84e03e6    	ldur	x6, [sp, #0xe0]
1005e7d8c: 53001cc6    	uxtb	w6, w6
1005e7d90: f90bde66    	str	x6, [x19, #0x17b8]
1005e7d94: f90e3a6f    	str	x15, [x19, #0x1c70]
1005e7d98: f90e3e6c    	str	x12, [x19, #0x1c78]
1005e7d9c: f90e4276    	str	x22, [x19, #0x1c80]
1005e7da0: f90e5679    	str	x25, [x19, #0x1ca8]
1005e7da4: f90e9e7b    	str	x27, [x19, #0x1d38]
1005e7da8: f90ea26d    	str	x13, [x19, #0x1d40]
1005e7dac: f90ea676    	str	x22, [x19, #0x1d48]
1005e7db0: 53001c8e    	uxtb	w14, w4
1005e7db4: f90eae6e    	str	x14, [x19, #0x1d58]
1005e7db8: 91000764    	add	x4, x27, #0x1
1005e7dbc: f90eb664    	str	x4, [x19, #0x1d68]
1005e7dc0: f926326a    	str	x10, [x19, #0x4c60]
1005e7dc4: 529970c4    	mov	w4, #0xcb86             ; =52102
1005e7dc8: 72a00044    	movk	w4, #0x2, lsl #16
1005e7dcc: cb040063    	sub	x3, x3, x4
1005e7dd0: f9263663    	str	x3, [x19, #0x4c68]
1005e7dd4: f84803e4    	ldur	x4, [sp, #0x80]
1005e7dd8: f9263a64    	str	x4, [x19, #0x4c70]
1005e7ddc: f927ba76    	str	x22, [x19, #0x4f70]
1005e7de0: f927be77    	str	x23, [x19, #0x4f78]
1005e7de4: f92aee6f    	str	x15, [x19, #0x55d8]
1005e7de8: f92af26c    	str	x12, [x19, #0x55e0]
1005e7dec: f92af676    	str	x22, [x19, #0x55e8]
1005e7df0: f84103f9    	ldur	x25, [sp, #0x10]
1005e7df4: f92afa79    	str	x25, [x19, #0x55f0]
1005e7df8: f84583e4    	ldur	x4, [sp, #0x58]
1005e7dfc: f92afe64    	str	x4, [x19, #0x55f8]
1005e7e00: f84603e4    	ldur	x4, [sp, #0x60]
1005e7e04: f92b0264    	str	x4, [x19, #0x5600]
1005e7e08: f84683f9    	ldur	x25, [sp, #0x68]
1005e7e0c: f92b0679    	str	x25, [x19, #0x5608]
1005e7e10: f84703fa    	ldur	x26, [sp, #0x70]
1005e7e14: f92b0a7a    	str	x26, [x19, #0x5610]
1005e7e18: f92bd27b    	str	x27, [x19, #0x57a0]
1005e7e1c: f92bd66d    	str	x13, [x19, #0x57a8]
1005e7e20: f92bda76    	str	x22, [x19, #0x57b0]
1005e7e24: f92bde61    	str	x1, [x19, #0x57b8]
1005e7e28: f92be260    	str	x0, [x19, #0x57c0]
1005e7e2c: f92be667    	str	x7, [x19, #0x57c8]
1005e7e30: f92bea6b    	str	x11, [x19, #0x57d0]
1005e7e34: f92bee78    	str	x24, [x19, #0x57d8]
1005e7e38: f84503e1    	ldur	x1, [sp, #0x50]
1005e7e3c: f92d1261    	str	x1, [x19, #0x5a20]
1005e7e40: 91000500    	add	x0, x8, #0x1
1005e7e44: f92dda60    	str	x0, [x19, #0x5bb0]
1005e7e48: f84883fa    	ldur	x26, [sp, #0x88]
1005e7e4c: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e7e50: f84903e6    	ldur	x6, [sp, #0x90]
1005e7e54: f92de266    	str	x6, [x19, #0x5bc0]
1005e7e58: f84783e4    	ldur	x4, [sp, #0x78]
1005e7e5c: cb030081    	sub	x1, x4, x3
1005e7e60: 52990fc3    	mov	w3, #0xc87e             ; =51326
1005e7e64: 72a00023    	movk	w3, #0x1, lsl #16
1005e7e68: 9b038400    	msub	x0, x0, x3, x1
1005e7e6c: f92de660    	str	x0, [x19, #0x5bc8]
1005e7e70: f92dea65    	str	x5, [x19, #0x5bd0]
1005e7e74: f92dee65    	str	x5, [x19, #0x5bd8]
1005e7e78: f84983ea    	ldur	x10, [sp, #0x98]
1005e7e7c: f92df66a    	str	x10, [x19, #0x5be8]
1005e7e80: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e7e84: f92dfa64    	str	x4, [x19, #0x5bf0]
1005e7e88: f92e0262    	str	x2, [x19, #0x5c00]
1005e7e8c: f84403e7    	ldur	x7, [sp, #0x40]
1005e7e90: f92e0667    	str	x7, [x19, #0x5c08]
1005e7e94: f92e0e62    	str	x2, [x19, #0x5c18]
1005e7e98: f84483e5    	ldur	x5, [sp, #0x48]
1005e7e9c: f92e1265    	str	x5, [x19, #0x5c20]
1005e7ea0: f9663260    	ldr	x0, [x19, #0x4c60]
1005e7ea4: f100001f    	cmp	x0, #0x0
1005e7ea8: 54feb4a1    	b.ne	0x1005e553c <_mech_canonical_program_entry_v1_numeric_1282+0x3ebc>
1005e7eac: 17fff62e    	b	0x1005e5764 <_mech_canonical_program_entry_v1_numeric_1282+0x40e4>
1005e7eb0: f80b83f4    	stur	x20, [sp, #0xb8]
1005e7eb4: 140001b1    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e7eb8: f80b83f4    	stur	x20, [sp, #0xb8]
1005e7ebc: 140001af    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e7ec0: d280d880    	mov	x0, #0x6c4              ; =1732
1005e7ec4: f84003e1    	ldur	x1, [sp]
1005e7ec8: f9002420    	str	x0, [x1, #0x48]
1005e7ecc: d2800000    	mov	x0, #0x0                ; =0
1005e7ed0: f9263260    	str	x0, [x19, #0x4c60]
1005e7ed4: d2800060    	mov	x0, #0x3                ; =3
1005e7ed8: f80b83e0    	stur	x0, [sp, #0xb8]
1005e7edc: f940c3e0    	ldr	x0, [sp, #0x180]
1005e7ee0: f106701f    	cmp	x0, #0x19c
1005e7ee4: 54fed5a2    	b.hs	0x1005e5998 <_mech_canonical_program_entry_v1_numeric_1282+0x4318>
1005e7ee8: 140001a4    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e7eec: d280d900    	mov	x0, #0x6c8              ; =1736
1005e7ef0: f84003e2    	ldur	x2, [sp]
1005e7ef4: f9002440    	str	x0, [x2, #0x48]
1005e7ef8: d2800000    	mov	x0, #0x0                ; =0
1005e7efc: f9263260    	str	x0, [x19, #0x4c60]
1005e7f00: d2800060    	mov	x0, #0x3                ; =3
1005e7f04: f80b83e0    	stur	x0, [sp, #0xb8]
1005e7f08: f940c3e0    	ldr	x0, [sp, #0x180]
1005e7f0c: f106701f    	cmp	x0, #0x19c
1005e7f10: 54fee2a2    	b.hs	0x1005e5b64 <_mech_canonical_program_entry_v1_numeric_1282+0x44e4>
1005e7f14: 14000199    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e7f18: d280d980    	mov	x0, #0x6cc              ; =1740
1005e7f1c: f84003e2    	ldur	x2, [sp]
1005e7f20: f9002440    	str	x0, [x2, #0x48]
1005e7f24: d2800000    	mov	x0, #0x0                ; =0
1005e7f28: f9263260    	str	x0, [x19, #0x4c60]
1005e7f2c: d2800060    	mov	x0, #0x3                ; =3
1005e7f30: f940c3e2    	ldr	x2, [sp, #0x180]
1005e7f34: f80b83e0    	stur	x0, [sp, #0xb8]
1005e7f38: f106705f    	cmp	x2, #0x19c
1005e7f3c: 54feeea2    	b.hs	0x1005e5d10 <_mech_canonical_program_entry_v1_numeric_1282+0x4690>
1005e7f40: 1400018e    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e7f44: d280da09    	mov	x9, #0x6d0              ; =1744
1005e7f48: f84003e0    	ldur	x0, [sp]
1005e7f4c: f9002409    	str	x9, [x0, #0x48]
1005e7f50: d2800009    	mov	x9, #0x0                ; =0
1005e7f54: f9263269    	str	x9, [x19, #0x4c60]
1005e7f58: d2800060    	mov	x0, #0x3                ; =3
1005e7f5c: f80b83e0    	stur	x0, [sp, #0xb8]
1005e7f60: f940c3e0    	ldr	x0, [sp, #0x180]
1005e7f64: f106701f    	cmp	x0, #0x19c
1005e7f68: 54fefaa2    	b.hs	0x1005e5ebc <_mech_canonical_program_entry_v1_numeric_1282+0x483c>
1005e7f6c: 14000183    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e7f70: d280da80    	mov	x0, #0x6d4              ; =1748
1005e7f74: f84003e2    	ldur	x2, [sp]
1005e7f78: f9002440    	str	x0, [x2, #0x48]
1005e7f7c: d2800000    	mov	x0, #0x0                ; =0
1005e7f80: f9263260    	str	x0, [x19, #0x4c60]
1005e7f84: d2800060    	mov	x0, #0x3                ; =3
1005e7f88: f80b83e0    	stur	x0, [sp, #0xb8]
1005e7f8c: f940c3e0    	ldr	x0, [sp, #0x180]
1005e7f90: f106701f    	cmp	x0, #0x19c
1005e7f94: 54ff06c2    	b.hs	0x1005e606c <_mech_canonical_program_entry_v1_numeric_1282+0x49ec>
1005e7f98: 14000178    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e7f9c: d280dba2    	mov	x2, #0x6dd              ; =1757
1005e7fa0: f84003e0    	ldur	x0, [sp]
1005e7fa4: f9002402    	str	x2, [x0, #0x48]
1005e7fa8: d2800004    	mov	x4, #0x0                ; =0
1005e7fac: f9000e64    	str	x4, [x19, #0x18]
1005e7fb0: d2e20005    	mov	x5, #0x1000000000000000 ; =1152921504606846976
1005e7fb4: f9001265    	str	x5, [x19, #0x20]
1005e7fb8: d2800020    	mov	x0, #0x1                ; =1
1005e7fbc: f80b83e0    	stur	x0, [sp, #0xb8]
1005e7fc0: f9001a60    	str	x0, [x19, #0x30]
1005e7fc4: b200c3e6    	mov	x6, #0x101010101010101  ; =72340172838076673
1005e7fc8: f9001e66    	str	x6, [x19, #0x38]
1005e7fcc: d2800047    	mov	x7, #0x2                ; =2
1005e7fd0: f9002267    	str	x7, [x19, #0x40]
1005e7fd4: d2800069    	mov	x9, #0x3                ; =3
1005e7fd8: f9002669    	str	x9, [x19, #0x48]
1005e7fdc: d2800089    	mov	x9, #0x4                ; =4
1005e7fe0: f9002a69    	str	x9, [x19, #0x50]
1005e7fe4: b200cfee    	mov	x14, #0xf0f0f0f0f0f0f0f ; =1085102592571150095
1005e7fe8: f9003e6e    	str	x14, [x19, #0x78]
1005e7fec: b200e7ee    	mov	x14, #0x3333333333333333 ; =3689348814741910323
1005e7ff0: f900466e    	str	x14, [x19, #0x88]
1005e7ff4: d280070e    	mov	x14, #0x38              ; =56
1005e7ff8: f9004a6e    	str	x14, [x19, #0x90]
1005e7ffc: d280074e    	mov	x14, #0x3a              ; =58
1005e8000: f9004e6e    	str	x14, [x19, #0x98]
1005e8004: b200f3ee    	mov	x14, #0x5555555555555555 ; =6148914691236517205
1005e8008: f9005a6e    	str	x14, [x19, #0xb0]
1005e800c: 92ff8000    	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
1005e8010: f9005e60    	str	x0, [x19, #0xb8]
1005e8014: f900c664    	str	x4, [x19, #0x188]
1005e8018: f84b83e0    	ldur	x0, [sp, #0xb8]
1005e801c: f900ca60    	str	x0, [x19, #0x190]
1005e8020: f90bd278    	str	x24, [x19, #0x17a0]
1005e8024: f90bd677    	str	x23, [x19, #0x17a8]
1005e8028: f926326a    	str	x10, [x19, #0x4c60]
1005e802c: f9263663    	str	x3, [x19, #0x4c68]
1005e8030: f84803e4    	ldur	x4, [sp, #0x80]
1005e8034: f9263a64    	str	x4, [x19, #0x4c70]
1005e8038: f84503e1    	ldur	x1, [sp, #0x50]
1005e803c: f92d1261    	str	x1, [x19, #0x5a20]
1005e8040: f92dda68    	str	x8, [x19, #0x5bb0]
1005e8044: f84883fa    	ldur	x26, [sp, #0x88]
1005e8048: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e804c: f84903e6    	ldur	x6, [sp, #0x90]
1005e8050: f92de266    	str	x6, [x19, #0x5bc0]
1005e8054: f84783e4    	ldur	x4, [sp, #0x78]
1005e8058: cb030081    	sub	x1, x4, x3
1005e805c: 52990fc0    	mov	w0, #0xc87e             ; =51326
1005e8060: 72a00020    	movk	w0, #0x1, lsl #16
1005e8064: 9b008500    	msub	x0, x8, x0, x1
1005e8068: f92de660    	str	x0, [x19, #0x5bc8]
1005e806c: f92dea79    	str	x25, [x19, #0x5bd0]
1005e8070: f92dee6f    	str	x15, [x19, #0x5bd8]
1005e8074: f84983ea    	ldur	x10, [sp, #0x98]
1005e8078: f92df66a    	str	x10, [x19, #0x5be8]
1005e807c: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e8080: f92dfa64    	str	x4, [x19, #0x5bf0]
1005e8084: f92e026c    	str	x12, [x19, #0x5c00]
1005e8088: f92e066b    	str	x11, [x19, #0x5c08]
1005e808c: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e8090: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e8094: f92e126d    	str	x13, [x19, #0x5c20]
1005e8098: 14000138    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e809c: d280d600    	mov	x0, #0x6b0              ; =1712
1005e80a0: f84003e1    	ldur	x1, [sp]
1005e80a4: f9002420    	str	x0, [x1, #0x48]
1005e80a8: d2800001    	mov	x1, #0x0                ; =0
1005e80ac: f9000e61    	str	x1, [x19, #0x18]
1005e80b0: f900127a    	str	x26, [x19, #0x20]
1005e80b4: d2800020    	mov	x0, #0x1                ; =1
1005e80b8: f80b83e0    	stur	x0, [sp, #0xb8]
1005e80bc: f9001a60    	str	x0, [x19, #0x30]
1005e80c0: b200c3e0    	mov	x0, #0x101010101010101  ; =72340172838076673
1005e80c4: f9001e60    	str	x0, [x19, #0x38]
1005e80c8: d2800040    	mov	x0, #0x2                ; =2
1005e80cc: f9002260    	str	x0, [x19, #0x40]
1005e80d0: d2800060    	mov	x0, #0x3                ; =3
1005e80d4: f9002660    	str	x0, [x19, #0x48]
1005e80d8: d2800080    	mov	x0, #0x4                ; =4
1005e80dc: f9002a60    	str	x0, [x19, #0x50]
1005e80e0: b200cfe0    	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e80e4: f9003e60    	str	x0, [x19, #0x78]
1005e80e8: b200e7e0    	mov	x0, #0x3333333333333333 ; =3689348814741910323
1005e80ec: f9004660    	str	x0, [x19, #0x88]
1005e80f0: d2800700    	mov	x0, #0x38               ; =56
1005e80f4: f9004a60    	str	x0, [x19, #0x90]
1005e80f8: d2800740    	mov	x0, #0x3a               ; =58
1005e80fc: f9004e60    	str	x0, [x19, #0x98]
1005e8100: b200f3e0    	mov	x0, #0x5555555555555555 ; =6148914691236517205
1005e8104: f9005a60    	str	x0, [x19, #0xb0]
1005e8108: 92ff8000    	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
1005e810c: f9005e60    	str	x0, [x19, #0xb8]
1005e8110: f900c661    	str	x1, [x19, #0x188]
1005e8114: f84b83e0    	ldur	x0, [sp, #0xb8]
1005e8118: f900ca60    	str	x0, [x19, #0x190]
1005e811c: f90bd276    	str	x22, [x19, #0x17a0]
1005e8120: f90bd677    	str	x23, [x19, #0x17a8]
1005e8124: f84e03f8    	ldur	x24, [sp, #0xe0]
1005e8128: 53001f00    	uxtb	w0, w24
1005e812c: f90bde60    	str	x0, [x19, #0x17b8]
1005e8130: f90e3a6f    	str	x15, [x19, #0x1c70]
1005e8134: f90e3e6c    	str	x12, [x19, #0x1c78]
1005e8138: f90e4276    	str	x22, [x19, #0x1c80]
1005e813c: f926326a    	str	x10, [x19, #0x4c60]
1005e8140: f9263663    	str	x3, [x19, #0x4c68]
1005e8144: f84803e4    	ldur	x4, [sp, #0x80]
1005e8148: f9263a64    	str	x4, [x19, #0x4c70]
1005e814c: f84503e2    	ldur	x2, [sp, #0x50]
1005e8150: f92d1262    	str	x2, [x19, #0x5a20]
1005e8154: 91000507    	add	x7, x8, #0x1
1005e8158: f92dda67    	str	x7, [x19, #0x5bb0]
1005e815c: f84883fa    	ldur	x26, [sp, #0x88]
1005e8160: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e8164: f84903e6    	ldur	x6, [sp, #0x90]
1005e8168: f92de266    	str	x6, [x19, #0x5bc0]
1005e816c: f84783e4    	ldur	x4, [sp, #0x78]
1005e8170: cb03008a    	sub	x10, x4, x3
1005e8174: 52990fcb    	mov	w11, #0xc87e            ; =51326
1005e8178: 72a0002b    	movk	w11, #0x1, lsl #16
1005e817c: 9b0ba8ea    	msub	x10, x7, x11, x10
1005e8180: f92de66a    	str	x10, [x19, #0x5bc8]
1005e8184: f92dea61    	str	x1, [x19, #0x5bd0]
1005e8188: f92dee61    	str	x1, [x19, #0x5bd8]
1005e818c: f84983ea    	ldur	x10, [sp, #0x98]
1005e8190: f92df66a    	str	x10, [x19, #0x5be8]
1005e8194: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e8198: f92dfa64    	str	x4, [x19, #0x5bf0]
1005e819c: f84b83e0    	ldur	x0, [sp, #0xb8]
1005e81a0: f92e0260    	str	x0, [x19, #0x5c00]
1005e81a4: f84403e7    	ldur	x7, [sp, #0x40]
1005e81a8: f92e0667    	str	x7, [x19, #0x5c08]
1005e81ac: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e81b0: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e81b4: f92e126d    	str	x13, [x19, #0x5c20]
1005e81b8: 140000f0    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e81bc: d280d400    	mov	x0, #0x6a0              ; =1696
1005e81c0: f84003e1    	ldur	x1, [sp]
1005e81c4: f9002420    	str	x0, [x1, #0x48]
1005e81c8: d2800001    	mov	x1, #0x0                ; =0
1005e81cc: f9000e61    	str	x1, [x19, #0x18]
1005e81d0: f900127a    	str	x26, [x19, #0x20]
1005e81d4: d2800020    	mov	x0, #0x1                ; =1
1005e81d8: f80b83e0    	stur	x0, [sp, #0xb8]
1005e81dc: f9001a60    	str	x0, [x19, #0x30]
1005e81e0: b200c3e0    	mov	x0, #0x101010101010101  ; =72340172838076673
1005e81e4: f9001e60    	str	x0, [x19, #0x38]
1005e81e8: d2800040    	mov	x0, #0x2                ; =2
1005e81ec: f9002260    	str	x0, [x19, #0x40]
1005e81f0: d2800060    	mov	x0, #0x3                ; =3
1005e81f4: f9002660    	str	x0, [x19, #0x48]
1005e81f8: d2800080    	mov	x0, #0x4                ; =4
1005e81fc: f9002a60    	str	x0, [x19, #0x50]
1005e8200: b200cfe0    	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e8204: f9003e60    	str	x0, [x19, #0x78]
1005e8208: b200e7e0    	mov	x0, #0x3333333333333333 ; =3689348814741910323
1005e820c: f9004660    	str	x0, [x19, #0x88]
1005e8210: d2800700    	mov	x0, #0x38               ; =56
1005e8214: f9004a60    	str	x0, [x19, #0x90]
1005e8218: d2800740    	mov	x0, #0x3a               ; =58
1005e821c: f9004e60    	str	x0, [x19, #0x98]
1005e8220: b200f3e0    	mov	x0, #0x5555555555555555 ; =6148914691236517205
1005e8224: f9005a60    	str	x0, [x19, #0xb0]
1005e8228: f84c03e9    	ldur	x9, [sp, #0xc0]
1005e822c: f9005e69    	str	x9, [x19, #0xb8]
1005e8230: f900c661    	str	x1, [x19, #0x188]
1005e8234: f84b83e0    	ldur	x0, [sp, #0xb8]
1005e8238: f900ca60    	str	x0, [x19, #0x190]
1005e823c: f90bd276    	str	x22, [x19, #0x17a0]
1005e8240: f90bd677    	str	x23, [x19, #0x17a8]
1005e8244: f84e03f8    	ldur	x24, [sp, #0xe0]
1005e8248: 53001f00    	uxtb	w0, w24
1005e824c: f90bde60    	str	x0, [x19, #0x17b8]
1005e8250: f90e3a6f    	str	x15, [x19, #0x1c70]
1005e8254: f90e3e6c    	str	x12, [x19, #0x1c78]
1005e8258: f90e4276    	str	x22, [x19, #0x1c80]
1005e825c: f90e5679    	str	x25, [x19, #0x1ca8]
1005e8260: f90e9e7b    	str	x27, [x19, #0x1d38]
1005e8264: f90ea26d    	str	x13, [x19, #0x1d40]
1005e8268: f90ea676    	str	x22, [x19, #0x1d48]
1005e826c: f926326a    	str	x10, [x19, #0x4c60]
1005e8270: 529970c0    	mov	w0, #0xcb86             ; =52102
1005e8274: 72a00040    	movk	w0, #0x2, lsl #16
1005e8278: cb000062    	sub	x2, x3, x0
1005e827c: f9263662    	str	x2, [x19, #0x4c68]
1005e8280: f84803e4    	ldur	x4, [sp, #0x80]
1005e8284: f9263a64    	str	x4, [x19, #0x4c70]
1005e8288: f84503ed    	ldur	x13, [sp, #0x50]
1005e828c: f92d126d    	str	x13, [x19, #0x5a20]
1005e8290: 91000503    	add	x3, x8, #0x1
1005e8294: f92dda63    	str	x3, [x19, #0x5bb0]
1005e8298: f84883fa    	ldur	x26, [sp, #0x88]
1005e829c: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e82a0: f84903e6    	ldur	x6, [sp, #0x90]
1005e82a4: f92de266    	str	x6, [x19, #0x5bc0]
1005e82a8: f84783e4    	ldur	x4, [sp, #0x78]
1005e82ac: cb020082    	sub	x2, x4, x2
1005e82b0: 52990fc0    	mov	w0, #0xc87e             ; =51326
1005e82b4: 72a00020    	movk	w0, #0x1, lsl #16
1005e82b8: 9b008860    	msub	x0, x3, x0, x2
1005e82bc: f92de660    	str	x0, [x19, #0x5bc8]
1005e82c0: f92dea61    	str	x1, [x19, #0x5bd0]
1005e82c4: f92dee61    	str	x1, [x19, #0x5bd8]
1005e82c8: f84983ea    	ldur	x10, [sp, #0x98]
1005e82cc: f92df66a    	str	x10, [x19, #0x5be8]
1005e82d0: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e82d4: f92dfa64    	str	x4, [x19, #0x5bf0]
1005e82d8: f84b83e0    	ldur	x0, [sp, #0xb8]
1005e82dc: f92e0260    	str	x0, [x19, #0x5c00]
1005e82e0: f84403e7    	ldur	x7, [sp, #0x40]
1005e82e4: f92e0667    	str	x7, [x19, #0x5c08]
1005e82e8: f92e0e60    	str	x0, [x19, #0x5c18]
1005e82ec: f84483e5    	ldur	x5, [sp, #0x48]
1005e82f0: f92e1265    	str	x5, [x19, #0x5c20]
1005e82f4: 140000a1    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e82f8: d280bbee    	mov	x14, #0x5df             ; =1503
1005e82fc: f84003e0    	ldur	x0, [sp]
1005e8300: f900240e    	str	x14, [x0, #0x48]
1005e8304: d280000f    	mov	x15, #0x0               ; =0
1005e8308: f9000e6f    	str	x15, [x19, #0x18]
1005e830c: d2e20000    	mov	x0, #0x1000000000000000 ; =1152921504606846976
1005e8310: f9001260    	str	x0, [x19, #0x20]
1005e8314: d2800020    	mov	x0, #0x1                ; =1
1005e8318: f80b83e0    	stur	x0, [sp, #0xb8]
1005e831c: f9001a60    	str	x0, [x19, #0x30]
1005e8320: b200c3e0    	mov	x0, #0x101010101010101  ; =72340172838076673
1005e8324: f9001e60    	str	x0, [x19, #0x38]
1005e8328: d2800040    	mov	x0, #0x2                ; =2
1005e832c: f9002260    	str	x0, [x19, #0x40]
1005e8330: d2800060    	mov	x0, #0x3                ; =3
1005e8334: f9002660    	str	x0, [x19, #0x48]
1005e8338: d2800080    	mov	x0, #0x4                ; =4
1005e833c: f9002a60    	str	x0, [x19, #0x50]
1005e8340: b200cfe0    	mov	x0, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e8344: f9003e60    	str	x0, [x19, #0x78]
1005e8348: b200e7e0    	mov	x0, #0x3333333333333333 ; =3689348814741910323
1005e834c: f9004660    	str	x0, [x19, #0x88]
1005e8350: d2800700    	mov	x0, #0x38               ; =56
1005e8354: f9004a60    	str	x0, [x19, #0x90]
1005e8358: d2800740    	mov	x0, #0x3a               ; =58
1005e835c: f9004e60    	str	x0, [x19, #0x98]
1005e8360: b200f3e0    	mov	x0, #0x5555555555555555 ; =6148914691236517205
1005e8364: f9005a60    	str	x0, [x19, #0xb0]
1005e8368: 92ff8000    	mov	x0, #0x3ffffffffffffff  ; =288230376151711743
1005e836c: f9005e60    	str	x0, [x19, #0xb8]
1005e8370: f900c66f    	str	x15, [x19, #0x188]
1005e8374: f84b83e0    	ldur	x0, [sp, #0xb8]
1005e8378: f900ca60    	str	x0, [x19, #0x190]
1005e837c: f90bd276    	str	x22, [x19, #0x17a0]
1005e8380: f90bd677    	str	x23, [x19, #0x17a8]
1005e8384: f84e03f8    	ldur	x24, [sp, #0xe0]
1005e8388: 53001f00    	uxtb	w0, w24
1005e838c: f90bde60    	str	x0, [x19, #0x17b8]
1005e8390: f90c2e64    	str	x4, [x19, #0x1858]
1005e8394: aa1a03ef    	mov	x15, x26
1005e8398: f90c326f    	str	x15, [x19, #0x1860]
1005e839c: f90c3676    	str	x22, [x19, #0x1868]
1005e83a0: f84d03ef    	ldur	x15, [sp, #0xd0]
1005e83a4: f90c3a6f    	str	x15, [x19, #0x1870]
1005e83a8: f926326a    	str	x10, [x19, #0x4c60]
1005e83ac: f9263663    	str	x3, [x19, #0x4c68]
1005e83b0: f84803e4    	ldur	x4, [sp, #0x80]
1005e83b4: f9263a64    	str	x4, [x19, #0x4c70]
1005e83b8: f84503e1    	ldur	x1, [sp, #0x50]
1005e83bc: f92d1261    	str	x1, [x19, #0x5a20]
1005e83c0: 91000501    	add	x1, x8, #0x1
1005e83c4: f92dda61    	str	x1, [x19, #0x5bb0]
1005e83c8: f84883fa    	ldur	x26, [sp, #0x88]
1005e83cc: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e83d0: f84903e6    	ldur	x6, [sp, #0x90]
1005e83d4: f92de266    	str	x6, [x19, #0x5bc0]
1005e83d8: f84783e4    	ldur	x4, [sp, #0x78]
1005e83dc: cb030082    	sub	x2, x4, x3
1005e83e0: 52990fc0    	mov	w0, #0xc87e             ; =51326
1005e83e4: 72a00020    	movk	w0, #0x1, lsl #16
1005e83e8: 9b008820    	msub	x0, x1, x0, x2
1005e83ec: f92de660    	str	x0, [x19, #0x5bc8]
1005e83f0: f84b83e0    	ldur	x0, [sp, #0xb8]
1005e83f4: f92dea60    	str	x0, [x19, #0x5bd0]
1005e83f8: f84203f8    	ldur	x24, [sp, #0x20]
1005e83fc: f92dee78    	str	x24, [x19, #0x5bd8]
1005e8400: f84983ea    	ldur	x10, [sp, #0x98]
1005e8404: f92df66a    	str	x10, [x19, #0x5be8]
1005e8408: f84a03e4    	ldur	x4, [sp, #0xa0]
1005e840c: f92dfa64    	str	x4, [x19, #0x5bf0]
1005e8410: f92e026c    	str	x12, [x19, #0x5c00]
1005e8414: f92e066b    	str	x11, [x19, #0x5c08]
1005e8418: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e841c: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e8420: f92e126d    	str	x13, [x19, #0x5c20]
1005e8424: 14000055    	b	0x1005e8578 <_mech_canonical_program_entry_v1_numeric_1282+0x6ef8>
1005e8428: d280b9e0    	mov	x0, #0x5cf              ; =1487
1005e842c: f84003e1    	ldur	x1, [sp]
1005e8430: f9002420    	str	x0, [x1, #0x48]
1005e8434: d2800001    	mov	x1, #0x0                ; =0
1005e8438: f9000e61    	str	x1, [x19, #0x18]
1005e843c: d2e20000    	mov	x0, #0x1000000000000000 ; =1152921504606846976
1005e8440: f9001260    	str	x0, [x19, #0x20]
1005e8444: d2800020    	mov	x0, #0x1                ; =1
1005e8448: f80b83e0    	stur	x0, [sp, #0xb8]
1005e844c: f9001a60    	str	x0, [x19, #0x30]
1005e8450: b200c3e2    	mov	x2, #0x101010101010101  ; =72340172838076673
1005e8454: f9001e62    	str	x2, [x19, #0x38]
1005e8458: d2800046    	mov	x6, #0x2                ; =2
1005e845c: f9002266    	str	x6, [x19, #0x40]
1005e8460: d2800066    	mov	x6, #0x3                ; =3
1005e8464: f9002666    	str	x6, [x19, #0x48]
1005e8468: d2800086    	mov	x6, #0x4                ; =4
1005e846c: f9002a66    	str	x6, [x19, #0x50]
1005e8470: b200cfe6    	mov	x6, #0xf0f0f0f0f0f0f0f  ; =1085102592571150095
1005e8474: f9003e66    	str	x6, [x19, #0x78]
1005e8478: b200e7e7    	mov	x7, #0x3333333333333333 ; =3689348814741910323
1005e847c: f9004667    	str	x7, [x19, #0x88]
1005e8480: d280070e    	mov	x14, #0x38              ; =56
1005e8484: f9004a6e    	str	x14, [x19, #0x90]
1005e8488: d280074e    	mov	x14, #0x3a              ; =58
1005e848c: f9004e6e    	str	x14, [x19, #0x98]
1005e8490: b200f3ee    	mov	x14, #0x5555555555555555 ; =6148914691236517205
1005e8494: f9005a6e    	str	x14, [x19, #0xb0]
1005e8498: 92ff800e    	mov	x14, #0x3ffffffffffffff ; =288230376151711743
1005e849c: f9005e6e    	str	x14, [x19, #0xb8]
1005e84a0: f900c661    	str	x1, [x19, #0x188]
1005e84a4: f900ca60    	str	x0, [x19, #0x190]
1005e84a8: f90bd276    	str	x22, [x19, #0x17a0]
1005e84ac: f90bd677    	str	x23, [x19, #0x17a8]
1005e84b0: f84e03f8    	ldur	x24, [sp, #0xe0]
1005e84b4: 53001f00    	uxtb	w0, w24
1005e84b8: f90bde60    	str	x0, [x19, #0x17b8]
1005e84bc: f84183fb    	ldur	x27, [sp, #0x18]
1005e84c0: f90c2e7b    	str	x27, [x19, #0x1858]
1005e84c4: aa1a03ef    	mov	x15, x26
1005e84c8: f90c326f    	str	x15, [x19, #0x1860]
1005e84cc: f90c3676    	str	x22, [x19, #0x1868]
1005e84d0: f84d03ef    	ldur	x15, [sp, #0xd0]
1005e84d4: f90c3a6f    	str	x15, [x19, #0x1870]
1005e84d8: f84c83ef    	ldur	x15, [sp, #0xc8]
1005e84dc: 53001de0    	uxtb	w0, w15
1005e84e0: f90c4260    	str	x0, [x19, #0x1880]
1005e84e4: f90c8e64    	str	x4, [x19, #0x1918]
1005e84e8: f90c9265    	str	x5, [x19, #0x1920]
1005e84ec: f90c9676    	str	x22, [x19, #0x1928]
1005e84f0: f84d03ef    	ldur	x15, [sp, #0xd0]
1005e84f4: f90c9a6f    	str	x15, [x19, #0x1930]
1005e84f8: f926326a    	str	x10, [x19, #0x4c60]
1005e84fc: 529b83c0    	mov	w0, #0xdc1e             ; =56350
1005e8500: 72a00040    	movk	w0, #0x2, lsl #16
1005e8504: cb000121    	sub	x1, x9, x0
1005e8508: f9263661    	str	x1, [x19, #0x4c68]
1005e850c: f84803e4    	ldur	x4, [sp, #0x80]
1005e8510: f9263a64    	str	x4, [x19, #0x4c70]
1005e8514: f84503e0    	ldur	x0, [sp, #0x50]
1005e8518: f92d1260    	str	x0, [x19, #0x5a20]
1005e851c: 91000502    	add	x2, x8, #0x1
1005e8520: f92dda62    	str	x2, [x19, #0x5bb0]
1005e8524: f84883fa    	ldur	x26, [sp, #0x88]
1005e8528: f92dde7a    	str	x26, [x19, #0x5bb8]
1005e852c: f84903e6    	ldur	x6, [sp, #0x90]
1005e8530: f92de266    	str	x6, [x19, #0x5bc0]
1005e8534: f84783e4    	ldur	x4, [sp, #0x78]
1005e8538: cb010081    	sub	x1, x4, x1
1005e853c: 52990fc0    	mov	w0, #0xc87e             ; =51326
1005e8540: 72a00020    	movk	w0, #0x1, lsl #16
1005e8544: 9b008440    	msub	x0, x2, x0, x1
1005e8548: f92de660    	str	x0, [x19, #0x5bc8]
1005e854c: f84b83e0    	ldur	x0, [sp, #0xb8]
1005e8550: f92dea60    	str	x0, [x19, #0x5bd0]
1005e8554: f84203f8    	ldur	x24, [sp, #0x20]
1005e8558: f92dee78    	str	x24, [x19, #0x5bd8]
1005e855c: f92df660    	str	x0, [x19, #0x5be8]
1005e8560: f92dfa63    	str	x3, [x19, #0x5bf0]
1005e8564: f92e026c    	str	x12, [x19, #0x5c00]
1005e8568: f92e066b    	str	x11, [x19, #0x5c08]
1005e856c: f92e0e6d    	str	x13, [x19, #0x5c18]
1005e8570: f84a83ed    	ldur	x13, [sp, #0xa8]
1005e8574: f92e126d    	str	x13, [x19, #0x5c20]
1005e8578: d2800001    	mov	x1, #0x0                ; =0
1005e857c: f84b83e0    	ldur	x0, [sp, #0xb8]
1005e8580: 9106c3ff    	add	sp, sp, #0x1b0
1005e8584: a8c153f3    	ldp	x19, x20, [sp], #0x10
1005e8588: a8c15bf5    	ldp	x21, x22, [sp], #0x10
1005e858c: a8c163f7    	ldp	x23, x24, [sp], #0x10
1005e8590: a8c16bf9    	ldp	x25, x26, [sp], #0x10
1005e8594: a8c173fb    	ldp	x27, x28, [sp], #0x10
1005e8598: a8c17bfd    	ldp	x29, x30, [sp], #0x10
1005e859c: d65f0fff    	retab
		...
