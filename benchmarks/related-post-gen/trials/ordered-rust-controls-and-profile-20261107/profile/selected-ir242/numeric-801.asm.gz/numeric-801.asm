
/private/tmp/mech-related-current-post-json-all-thread-profile-20261107-v1/selected-ir242/runner-profile:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001005d0980 <_mech_canonical_program_entry_v1_numeric_801>:
1005d0980: d503237f    	pacibsp
1005d0984: a9bf7bfd    	stp	x29, x30, [sp, #-0x10]!
1005d0988: 910003fd    	mov	x29, sp
1005d098c: a9bf73fb    	stp	x27, x28, [sp, #-0x10]!
1005d0990: a9bf6bf9    	stp	x25, x26, [sp, #-0x10]!
1005d0994: a9bf63f7    	stp	x23, x24, [sp, #-0x10]!
1005d0998: a9bf5bf5    	stp	x21, x22, [sp, #-0x10]!
1005d099c: a9bf53f3    	stp	x19, x20, [sp, #-0x10]!
1005d09a0: d10503ff    	sub	sp, sp, #0x140
1005d09a4: f80003e2    	stur	x2, [sp]
1005d09a8: f9402805    	ldr	x5, [x0, #0x50]
1005d09ac: f9402c06    	ldr	x6, [x0, #0x58]
1005d09b0: f9403002    	ldr	x2, [x0, #0x60]
1005d09b4: f9403403    	ldr	x3, [x0, #0x68]
1005d09b8: aa0003f6    	mov	x22, x0
1005d09bc: f90093e3    	str	x3, [sp, #0x120]
1005d09c0: d2800060    	mov	x0, #0x3                ; =3
1005d09c4: f10000bf    	cmp	x5, #0x0
1005d09c8: f9009fe5    	str	x5, [sp, #0x138]
1005d09cc: 54012c40    	b.eq	0x1005d2f54 <_mech_canonical_program_entry_v1_numeric_801+0x25d4>
1005d09d0: d2800060    	mov	x0, #0x3                ; =3
1005d09d4: f10000df    	cmp	x6, #0x0
1005d09d8: f9009be6    	str	x6, [sp, #0x130]
1005d09dc: 54012c00    	b.eq	0x1005d2f5c <_mech_canonical_program_entry_v1_numeric_801+0x25dc>
1005d09e0: d2800060    	mov	x0, #0x3                ; =3
1005d09e4: f80983e0    	stur	x0, [sp, #0x98]
1005d09e8: f100005f    	cmp	x2, #0x0
1005d09ec: 54024ee0    	b.eq	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d09f0: f965c42b    	ldr	x11, [x1, #0x4b88]
1005d09f4: f100017f    	cmp	x11, #0x0
1005d09f8: 540022c0    	b.eq	0x1005d0e50 <_mech_canonical_program_entry_v1_numeric_801+0x4d0>
1005d09fc: f9400840    	ldr	x0, [x2, #0x10]
1005d0a00: f9478823    	ldr	x3, [x1, #0xf10]
1005d0a04: f9478c23    	ldr	x3, [x1, #0xf18]
1005d0a08: f9479823    	ldr	x3, [x1, #0xf30]
1005d0a0c: f947a023    	ldr	x3, [x1, #0xf40]
1005d0a10: f947a423    	ldr	x3, [x1, #0xf48]
1005d0a14: f947a823    	ldr	x3, [x1, #0xf50]
1005d0a18: f947ac23    	ldr	x3, [x1, #0xf58]
1005d0a1c: f947b423    	ldr	x3, [x1, #0xf68]
1005d0a20: f947b823    	ldr	x3, [x1, #0xf70]
1005d0a24: f947d423    	ldr	x3, [x1, #0xfa8]
1005d0a28: f947d823    	ldr	x3, [x1, #0xfb0]
1005d0a2c: f947e023    	ldr	x3, [x1, #0xfc0]
1005d0a30: f947e423    	ldr	x3, [x1, #0xfc8]
1005d0a34: f947ec23    	ldr	x3, [x1, #0xfd8]
1005d0a38: f947f423    	ldr	x3, [x1, #0xfe8]
1005d0a3c: f947f823    	ldr	x3, [x1, #0xff0]
1005d0a40: f947fc23    	ldr	x3, [x1, #0xff8]
1005d0a44: f9481823    	ldr	x3, [x1, #0x1030]
1005d0a48: f9481c23    	ldr	x3, [x1, #0x1038]
1005d0a4c: f9482023    	ldr	x3, [x1, #0x1040]
1005d0a50: f9482823    	ldr	x3, [x1, #0x1050]
1005d0a54: f9482c23    	ldr	x3, [x1, #0x1058]
1005d0a58: f9483423    	ldr	x3, [x1, #0x1068]
1005d0a5c: f9483c23    	ldr	x3, [x1, #0x1078]
1005d0a60: f9484023    	ldr	x3, [x1, #0x1080]
1005d0a64: f9484423    	ldr	x3, [x1, #0x1088]
1005d0a68: f9484823    	ldr	x3, [x1, #0x1090]
1005d0a6c: f9486423    	ldr	x3, [x1, #0x10c8]
1005d0a70: f9486823    	ldr	x3, [x1, #0x10d0]
1005d0a74: f9486c23    	ldr	x3, [x1, #0x10d8]
1005d0a78: f9487023    	ldr	x3, [x1, #0x10e0]
1005d0a7c: f9487823    	ldr	x3, [x1, #0x10f0]
1005d0a80: f9487c23    	ldr	x3, [x1, #0x10f8]
1005d0a84: f9488423    	ldr	x3, [x1, #0x1108]
1005d0a88: f9488c23    	ldr	x3, [x1, #0x1118]
1005d0a8c: f9489023    	ldr	x3, [x1, #0x1120]
1005d0a90: f9489423    	ldr	x3, [x1, #0x1128]
1005d0a94: f9489823    	ldr	x3, [x1, #0x1130]
1005d0a98: f9489c23    	ldr	x3, [x1, #0x1138]
1005d0a9c: f948b823    	ldr	x3, [x1, #0x1170]
1005d0aa0: f948bc23    	ldr	x3, [x1, #0x1178]
1005d0aa4: f948c023    	ldr	x3, [x1, #0x1180]
1005d0aa8: f948c423    	ldr	x3, [x1, #0x1188]
1005d0aac: f948c823    	ldr	x3, [x1, #0x1190]
1005d0ab0: f948d023    	ldr	x3, [x1, #0x11a0]
1005d0ab4: f948d823    	ldr	x3, [x1, #0x11b0]
1005d0ab8: f948dc23    	ldr	x3, [x1, #0x11b8]
1005d0abc: f948e023    	ldr	x3, [x1, #0x11c0]
1005d0ac0: f948e423    	ldr	x3, [x1, #0x11c8]
1005d0ac4: f948e823    	ldr	x3, [x1, #0x11d0]
1005d0ac8: f948ec23    	ldr	x3, [x1, #0x11d8]
1005d0acc: f948f023    	ldr	x3, [x1, #0x11e0]
1005d0ad0: f948f423    	ldr	x3, [x1, #0x11e8]
1005d0ad4: f948f823    	ldr	x3, [x1, #0x11f0]
1005d0ad8: f948fc23    	ldr	x3, [x1, #0x11f8]
1005d0adc: f9490023    	ldr	x3, [x1, #0x1200]
1005d0ae0: f9490423    	ldr	x3, [x1, #0x1208]
1005d0ae4: f9490823    	ldr	x3, [x1, #0x1210]
1005d0ae8: f9490c23    	ldr	x3, [x1, #0x1218]
1005d0aec: f9491023    	ldr	x3, [x1, #0x1220]
1005d0af0: f9491423    	ldr	x3, [x1, #0x1228]
1005d0af4: f9491823    	ldr	x3, [x1, #0x1230]
1005d0af8: f9491c23    	ldr	x3, [x1, #0x1238]
1005d0afc: f9492023    	ldr	x3, [x1, #0x1240]
1005d0b00: f9492423    	ldr	x3, [x1, #0x1248]
1005d0b04: f9492823    	ldr	x3, [x1, #0x1250]
1005d0b08: f9492c23    	ldr	x3, [x1, #0x1258]
1005d0b0c: f9493023    	ldr	x3, [x1, #0x1260]
1005d0b10: f9493423    	ldr	x3, [x1, #0x1268]
1005d0b14: f9493823    	ldr	x3, [x1, #0x1270]
1005d0b18: f9493c23    	ldr	x3, [x1, #0x1278]
1005d0b1c: f9494823    	ldr	x3, [x1, #0x1290]
1005d0b20: f9495423    	ldr	x3, [x1, #0x12a8]
1005d0b24: f9496023    	ldr	x3, [x1, #0x12c0]
1005d0b28: f9496c23    	ldr	x3, [x1, #0x12d8]
1005d0b2c: f9497823    	ldr	x3, [x1, #0x12f0]
1005d0b30: f9498423    	ldr	x3, [x1, #0x1308]
1005d0b34: f965c823    	ldr	x3, [x1, #0x4b90]
1005d0b38: f965cc24    	ldr	x4, [x1, #0x4b98]
1005d0b3c: aa0103e7    	mov	x7, x1
1005d0b40: f80183e4    	stur	x4, [sp, #0x18]
1005d0b44: f943f014    	ldr	x20, [x0, #0x7e0]
1005d0b48: f943f81b    	ldr	x27, [x0, #0x7f0]
1005d0b4c: f941384f    	ldr	x15, [x2, #0x270]
1005d0b50: f80903ef    	stur	x15, [sp, #0x90]
1005d0b54: f9413c55    	ldr	x21, [x2, #0x278]
1005d0b58: f80783f5    	stur	x21, [sp, #0x78]
1005d0b5c: f9414041    	ldr	x1, [x2, #0x280]
1005d0b60: f9414441    	ldr	x1, [x2, #0x288]
1005d0b64: f9414841    	ldr	x1, [x2, #0x290]
1005d0b68: f80703e1    	stur	x1, [sp, #0x70]
1005d0b6c: f9414c55    	ldr	x21, [x2, #0x298]
1005d0b70: f80083f5    	stur	x21, [sp, #0x8]
1005d0b74: f9415041    	ldr	x1, [x2, #0x2a0]
1005d0b78: f9415441    	ldr	x1, [x2, #0x2a8]
1005d0b7c: f9415841    	ldr	x1, [x2, #0x2b0]
1005d0b80: f9008fe1    	str	x1, [sp, #0x118]
1005d0b84: f9415c41    	ldr	x1, [x2, #0x2b8]
1005d0b88: f9008be1    	str	x1, [sp, #0x110]
1005d0b8c: f9416041    	ldr	x1, [x2, #0x2c0]
1005d0b90: f90087e1    	str	x1, [sp, #0x108]
1005d0b94: f9416441    	ldr	x1, [x2, #0x2c8]
1005d0b98: f90083e1    	str	x1, [sp, #0x100]
1005d0b9c: f9416841    	ldr	x1, [x2, #0x2d0]
1005d0ba0: f80f83e1    	stur	x1, [sp, #0xf8]
1005d0ba4: f9416c41    	ldr	x1, [x2, #0x2d8]
1005d0ba8: f80f03e1    	stur	x1, [sp, #0xf0]
1005d0bac: f9417041    	ldr	x1, [x2, #0x2e0]
1005d0bb0: f9417441    	ldr	x1, [x2, #0x2e8]
1005d0bb4: f9418841    	ldr	x1, [x2, #0x310]
1005d0bb8: f80803e1    	stur	x1, [sp, #0x80]
1005d0bbc: f9418c41    	ldr	x1, [x2, #0x318]
1005d0bc0: f80603e1    	stur	x1, [sp, #0x60]
1005d0bc4: f90097e2    	str	x2, [sp, #0x128]
1005d0bc8: d2800002    	mov	x2, #0x0                ; =0
1005d0bcc: d2800024    	mov	x4, #0x1                ; =1
1005d0bd0: f80203e4    	stur	x4, [sp, #0x20]
1005d0bd4: aa0203e6    	mov	x6, x2
1005d0bd8: aa0203e8    	mov	x8, x2
1005d0bdc: aa0203e9    	mov	x9, x2
1005d0be0: aa0203ea    	mov	x10, x2
1005d0be4: aa0203ec    	mov	x12, x2
1005d0be8: aa0203ed    	mov	x13, x2
1005d0bec: aa0203ee    	mov	x14, x2
1005d0bf0: aa0203f7    	mov	x23, x2
1005d0bf4: aa0203fc    	mov	x28, x2
1005d0bf8: f80103e3    	stur	x3, [sp, #0x10]
1005d0bfc: f80683e2    	stur	x2, [sp, #0x68]
1005d0c00: f80883e2    	stur	x2, [sp, #0x88]
1005d0c04: d29e9381    	mov	x1, #0xf49c             ; =62620
1005d0c08: eb01007f    	cmp	x3, x1
1005d0c0c: 9a9f37e1    	cset	x1, hs
1005d0c10: f84803e4    	ldur	x4, [sp, #0x80]
1005d0c14: f84783f5    	ldur	x21, [sp, #0x78]
1005d0c18: eb0402bf    	cmp	x21, x4
1005d0c1c: 9a9f87e4    	cset	x4, ls
1005d0c20: f84803e5    	ldur	x5, [sp, #0x80]
1005d0c24: cb1500a5    	sub	x5, x5, x21
1005d0c28: f10000bf    	cmp	x5, #0x0
1005d0c2c: 9a9f07e5    	cset	x5, ne
1005d0c30: 0a050084    	and	w4, w4, w5
1005d0c34: aa0403ef    	mov	x15, x4
1005d0c38: 0a0f0024    	and	w4, w1, w15
1005d0c3c: f80e83ef    	stur	x15, [sp, #0xe8]
1005d0c40: 53001c84    	uxtb	w4, w4
1005d0c44: b50011a4    	cbnz	x4, 0x1005d0e78 <_mech_canonical_program_entry_v1_numeric_801+0x4f8>
1005d0c48: d2800024    	mov	x4, #0x1                ; =1
1005d0c4c: aa0703f3    	mov	x19, x7
1005d0c50: f9001a64    	str	x4, [x19, #0x30]
1005d0c54: d2800045    	mov	x5, #0x2                ; =2
1005d0c58: f9002265    	str	x5, [x19, #0x40]
1005d0c5c: d2800065    	mov	x5, #0x3                ; =3
1005d0c60: f9002665    	str	x5, [x19, #0x48]
1005d0c64: d28000c7    	mov	x7, #0x6                ; =6
1005d0c68: f9003267    	str	x7, [x19, #0x60]
1005d0c6c: d2800307    	mov	x7, #0x18               ; =24
1005d0c70: f9004267    	str	x7, [x19, #0x80]
1005d0c74: d280000f    	mov	x15, #0x0               ; =0
1005d0c78: f900c66f    	str	x15, [x19, #0x188]
1005d0c7c: f900ca64    	str	x4, [x19, #0x190]
1005d0c80: f925c66b    	str	x11, [x19, #0x4b88]
1005d0c84: f925ca63    	str	x3, [x19, #0x4b90]
1005d0c88: f84183e4    	ldur	x4, [sp, #0x18]
1005d0c8c: f925ce64    	str	x4, [x19, #0x4b98]
1005d0c90: f927ba74    	str	x20, [x19, #0x4f70]
1005d0c94: f927be7b    	str	x27, [x19, #0x4f78]
1005d0c98: f84783f5    	ldur	x21, [sp, #0x78]
1005d0c9c: f928ee75    	str	x21, [x19, #0x51d8]
1005d0ca0: f84083f5    	ldur	x21, [sp, #0x8]
1005d0ca4: f928fe75    	str	x21, [x19, #0x51f8]
1005d0ca8: f9294262    	str	x2, [x19, #0x5280]
1005d0cac: f84203e1    	ldur	x1, [sp, #0x20]
1005d0cb0: f9294661    	str	x1, [x19, #0x5288]
1005d0cb4: f9294a66    	str	x6, [x19, #0x5290]
1005d0cb8: f84103e6    	ldur	x6, [sp, #0x10]
1005d0cbc: cb0300c0    	sub	x0, x6, x3
1005d0cc0: d29e9381    	mov	x1, #0xf49c             ; =62620
1005d0cc4: 9b018040    	msub	x0, x2, x1, x0
1005d0cc8: f9294e60    	str	x0, [x19, #0x5298]
1005d0ccc: f929526c    	str	x12, [x19, #0x52a0]
1005d0cd0: f929566a    	str	x10, [x19, #0x52a8]
1005d0cd4: f9295e68    	str	x8, [x19, #0x52b8]
1005d0cd8: f929627c    	str	x28, [x19, #0x52c0]
1005d0cdc: f9296a69    	str	x9, [x19, #0x52d0]
1005d0ce0: f9296e77    	str	x23, [x19, #0x52d8]
1005d0ce4: f929766e    	str	x14, [x19, #0x52e8]
1005d0ce8: f9297a6d    	str	x13, [x19, #0x52f0]
1005d0cec: f965c660    	ldr	x0, [x19, #0x4b88]
1005d0cf0: f100001f    	cmp	x0, #0x0
1005d0cf4: 54000ae0    	b.eq	0x1005d0e50 <_mech_canonical_program_entry_v1_numeric_801+0x4d0>
1005d0cf8: f965ca63    	ldr	x3, [x19, #0x4b90]
1005d0cfc: f965ce64    	ldr	x4, [x19, #0x4b98]
1005d0d00: d2800000    	mov	x0, #0x0                ; =0
1005d0d04: f925c660    	str	x0, [x19, #0x4b88]
1005d0d08: d2800060    	mov	x0, #0x3                ; =3
1005d0d0c: f94093e7    	ldr	x7, [sp, #0x120]
1005d0d10: f101d0ff    	cmp	x7, #0x74
1005d0d14: 54011283    	b.lo	0x1005d2f64 <_mech_canonical_program_entry_v1_numeric_801+0x25e4>
1005d0d18: f967ba60    	ldr	x0, [x19, #0x4f70]
1005d0d1c: f94097e1    	ldr	x1, [sp, #0x128]
1005d0d20: f9000820    	str	x0, [x1, #0x10]
1005d0d24: f967be62    	ldr	x2, [x19, #0x4f78]
1005d0d28: f9000c22    	str	x2, [x1, #0x18]
1005d0d2c: f968ee65    	ldr	x5, [x19, #0x51d8]
1005d0d30: f9013c25    	str	x5, [x1, #0x278]
1005d0d34: f968fe65    	ldr	x5, [x19, #0x51f8]
1005d0d38: f9014c25    	str	x5, [x1, #0x298]
1005d0d3c: f9000820    	str	x0, [x1, #0x10]
1005d0d40: f9000c22    	str	x2, [x1, #0x18]
1005d0d44: f967da60    	ldr	x0, [x19, #0x4fb0]
1005d0d48: f9002820    	str	x0, [x1, #0x50]
1005d0d4c: f967de60    	ldr	x0, [x19, #0x4fb8]
1005d0d50: f9002c20    	str	x0, [x1, #0x58]
1005d0d54: f9680260    	ldr	x0, [x19, #0x5000]
1005d0d58: f9005020    	str	x0, [x1, #0xa0]
1005d0d5c: f9680660    	ldr	x0, [x19, #0x5008]
1005d0d60: f9005420    	str	x0, [x1, #0xa8]
1005d0d64: f9680a60    	ldr	x0, [x19, #0x5010]
1005d0d68: f9005820    	str	x0, [x1, #0xb0]
1005d0d6c: f9683a60    	ldr	x0, [x19, #0x5070]
1005d0d70: f9008820    	str	x0, [x1, #0x110]
1005d0d74: f9683e60    	ldr	x0, [x19, #0x5078]
1005d0d78: f9008c20    	str	x0, [x1, #0x118]
1005d0d7c: f9684260    	ldr	x0, [x19, #0x5080]
1005d0d80: f9009020    	str	x0, [x1, #0x120]
1005d0d84: f9684660    	ldr	x0, [x19, #0x5088]
1005d0d88: f9009420    	str	x0, [x1, #0x128]
1005d0d8c: f9688260    	ldr	x0, [x19, #0x5100]
1005d0d90: f900d020    	str	x0, [x1, #0x1a0]
1005d0d94: f9688660    	ldr	x0, [x19, #0x5108]
1005d0d98: f900d420    	str	x0, [x1, #0x1a8]
1005d0d9c: f9688a60    	ldr	x0, [x19, #0x5110]
1005d0da0: f900d820    	str	x0, [x1, #0x1b0]
1005d0da4: f9688e60    	ldr	x0, [x19, #0x5118]
1005d0da8: f900dc20    	str	x0, [x1, #0x1b8]
1005d0dac: f9689260    	ldr	x0, [x19, #0x5120]
1005d0db0: f900e020    	str	x0, [x1, #0x1c0]
1005d0db4: f9694260    	ldr	x0, [x19, #0x5280]
1005d0db8: f9019020    	str	x0, [x1, #0x320]
1005d0dbc: f9694660    	ldr	x0, [x19, #0x5288]
1005d0dc0: f9019420    	str	x0, [x1, #0x328]
1005d0dc4: f9694a60    	ldr	x0, [x19, #0x5290]
1005d0dc8: f9019820    	str	x0, [x1, #0x330]
1005d0dcc: f9694e60    	ldr	x0, [x19, #0x5298]
1005d0dd0: f9019c20    	str	x0, [x1, #0x338]
1005d0dd4: f9695260    	ldr	x0, [x19, #0x52a0]
1005d0dd8: f901a020    	str	x0, [x1, #0x340]
1005d0ddc: f9695660    	ldr	x0, [x19, #0x52a8]
1005d0de0: f901a420    	str	x0, [x1, #0x348]
1005d0de4: d2800000    	mov	x0, #0x0                ; =0
1005d0de8: f901a820    	str	x0, [x1, #0x350]
1005d0dec: f9695e62    	ldr	x2, [x19, #0x52b8]
1005d0df0: f901ac22    	str	x2, [x1, #0x358]
1005d0df4: f9696262    	ldr	x2, [x19, #0x52c0]
1005d0df8: f901b022    	str	x2, [x1, #0x360]
1005d0dfc: f901b420    	str	x0, [x1, #0x368]
1005d0e00: f9696a65    	ldr	x5, [x19, #0x52d0]
1005d0e04: f901b825    	str	x5, [x1, #0x370]
1005d0e08: f9696e65    	ldr	x5, [x19, #0x52d8]
1005d0e0c: f901bc25    	str	x5, [x1, #0x378]
1005d0e10: f901c020    	str	x0, [x1, #0x380]
1005d0e14: f9697666    	ldr	x6, [x19, #0x52e8]
1005d0e18: f901c426    	str	x6, [x1, #0x388]
1005d0e1c: f9697a67    	ldr	x7, [x19, #0x52f0]
1005d0e20: f901c827    	str	x7, [x1, #0x390]
1005d0e24: d2806421    	mov	x1, #0x321              ; =801
1005d0e28: 92800102    	mov	x2, #-0x9               ; =-9
1005d0e2c: d2800025    	mov	x5, #0x1                ; =1
1005d0e30: f84003e0    	ldur	x0, [sp]
1005d0e34: f9409be6    	ldr	x6, [sp, #0x130]
1005d0e38: f9409fe7    	ldr	x7, [sp, #0x138]
1005d0e3c: d63f00e0    	blr	x7
1005d0e40: aa0003e4    	mov	x4, x0
1005d0e44: d2800040    	mov	x0, #0x2                ; =2
1005d0e48: f100009f    	cmp	x4, #0x0
1005d0e4c: 54010901    	b.ne	0x1005d2f6c <_mech_canonical_program_entry_v1_numeric_801+0x25ec>
1005d0e50: d2800001    	mov	x1, #0x0                ; =0
1005d0e54: aa0103e0    	mov	x0, x1
1005d0e58: 910503ff    	add	sp, sp, #0x140
1005d0e5c: a8c153f3    	ldp	x19, x20, [sp], #0x10
1005d0e60: a8c15bf5    	ldp	x21, x22, [sp], #0x10
1005d0e64: a8c163f7    	ldp	x23, x24, [sp], #0x10
1005d0e68: a8c16bf9    	ldp	x25, x26, [sp], #0x10
1005d0e6c: a8c173fb    	ldp	x27, x28, [sp], #0x10
1005d0e70: a8c17bfd    	ldp	x29, x30, [sp], #0x10
1005d0e74: d65f0fff    	retab
1005d0e78: aa0703f3    	mov	x19, x7
1005d0e7c: f94093e7    	ldr	x7, [sp, #0x120]
1005d0e80: f84183e4    	ldur	x4, [sp, #0x18]
1005d0e84: f94097e1    	ldr	x1, [sp, #0x128]
1005d0e88: eb1b029f    	cmp	x20, x27
1005d0e8c: 9a9f27e5    	cset	x5, lo
1005d0e90: f80e03e5    	stur	x5, [sp, #0xe0]
1005d0e94: eb1b029f    	cmp	x20, x27
1005d0e98: 54000163    	b.lo	0x1005d0ec4 <_mech_canonical_program_entry_v1_numeric_801+0x544>
1005d0e9c: 91000442    	add	x2, x2, #0x1
1005d0ea0: d29e9385    	mov	x5, #0xf49c             ; =62620
1005d0ea4: cb050063    	sub	x3, x3, x5
1005d0ea8: f90097e1    	str	x1, [sp, #0x128]
1005d0eac: f90093e7    	str	x7, [sp, #0x120]
1005d0eb0: f80283e6    	stur	x6, [sp, #0x28]
1005d0eb4: aa1603fa    	mov	x26, x22
1005d0eb8: aa1403f6    	mov	x22, x20
1005d0ebc: aa1403f5    	mov	x21, x20
1005d0ec0: 14000751    	b	0x1005d2c04 <_mech_canonical_program_entry_v1_numeric_801+0x2284>
1005d0ec4: f9408be5    	ldr	x5, [sp, #0x110]
1005d0ec8: eb05029f    	cmp	x20, x5
1005d0ecc: 54000dc3    	b.lo	0x1005d1084 <_mech_canonical_program_entry_v1_numeric_801+0x704>
1005d0ed0: 14000829    	b	0x1005d2f74 <_mech_canonical_program_entry_v1_numeric_801+0x25f4>
1005d0ed4: f90093e7    	str	x7, [sp, #0x120]
1005d0ed8: f90097e1    	str	x1, [sp, #0x128]
1005d0edc: 14000055    	b	0x1005d1030 <_mech_canonical_program_entry_v1_numeric_801+0x6b0>
1005d0ee0: f965ca63    	ldr	x3, [x19, #0x4b90]
1005d0ee4: f965ce64    	ldr	x4, [x19, #0x4b98]
1005d0ee8: d2800005    	mov	x5, #0x0                ; =0
1005d0eec: f925c665    	str	x5, [x19, #0x4b88]
1005d0ef0: d2800060    	mov	x0, #0x3                ; =3
1005d0ef4: f101d0ff    	cmp	x7, #0x74
1005d0ef8: f90093e7    	str	x7, [sp, #0x120]
1005d0efc: 54010aa3    	b.lo	0x1005d3050 <_mech_canonical_program_entry_v1_numeric_801+0x26d0>
1005d0f00: f967ba68    	ldr	x8, [x19, #0x4f70]
1005d0f04: f9000828    	str	x8, [x1, #0x10]
1005d0f08: f967be69    	ldr	x9, [x19, #0x4f78]
1005d0f0c: f9000c29    	str	x9, [x1, #0x18]
1005d0f10: f968ee6a    	ldr	x10, [x19, #0x51d8]
1005d0f14: f9013c2a    	str	x10, [x1, #0x278]
1005d0f18: f968fe6b    	ldr	x11, [x19, #0x51f8]
1005d0f1c: f9014c2b    	str	x11, [x1, #0x298]
1005d0f20: f9000828    	str	x8, [x1, #0x10]
1005d0f24: f9000c29    	str	x9, [x1, #0x18]
1005d0f28: f967da6e    	ldr	x14, [x19, #0x4fb0]
1005d0f2c: f900282e    	str	x14, [x1, #0x50]
1005d0f30: f967de6f    	ldr	x15, [x19, #0x4fb8]
1005d0f34: f9002c2f    	str	x15, [x1, #0x58]
1005d0f38: f9680260    	ldr	x0, [x19, #0x5000]
1005d0f3c: f9005020    	str	x0, [x1, #0xa0]
1005d0f40: f9680660    	ldr	x0, [x19, #0x5008]
1005d0f44: f9005420    	str	x0, [x1, #0xa8]
1005d0f48: f9680a60    	ldr	x0, [x19, #0x5010]
1005d0f4c: f9005820    	str	x0, [x1, #0xb0]
1005d0f50: f9683a60    	ldr	x0, [x19, #0x5070]
1005d0f54: f9008820    	str	x0, [x1, #0x110]
1005d0f58: f9683e60    	ldr	x0, [x19, #0x5078]
1005d0f5c: f9008c20    	str	x0, [x1, #0x118]
1005d0f60: f9684260    	ldr	x0, [x19, #0x5080]
1005d0f64: f9009020    	str	x0, [x1, #0x120]
1005d0f68: f9684660    	ldr	x0, [x19, #0x5088]
1005d0f6c: f9009420    	str	x0, [x1, #0x128]
1005d0f70: f9688260    	ldr	x0, [x19, #0x5100]
1005d0f74: f900d020    	str	x0, [x1, #0x1a0]
1005d0f78: f9688660    	ldr	x0, [x19, #0x5108]
1005d0f7c: f900d420    	str	x0, [x1, #0x1a8]
1005d0f80: f9688a60    	ldr	x0, [x19, #0x5110]
1005d0f84: f900d820    	str	x0, [x1, #0x1b0]
1005d0f88: f9688e60    	ldr	x0, [x19, #0x5118]
1005d0f8c: f900dc20    	str	x0, [x1, #0x1b8]
1005d0f90: f9689260    	ldr	x0, [x19, #0x5120]
1005d0f94: f900e020    	str	x0, [x1, #0x1c0]
1005d0f98: f9694260    	ldr	x0, [x19, #0x5280]
1005d0f9c: f9019020    	str	x0, [x1, #0x320]
1005d0fa0: f9694660    	ldr	x0, [x19, #0x5288]
1005d0fa4: f9019420    	str	x0, [x1, #0x328]
1005d0fa8: f9694a60    	ldr	x0, [x19, #0x5290]
1005d0fac: f9019820    	str	x0, [x1, #0x330]
1005d0fb0: f9694e60    	ldr	x0, [x19, #0x5298]
1005d0fb4: f9019c20    	str	x0, [x1, #0x338]
1005d0fb8: f9695260    	ldr	x0, [x19, #0x52a0]
1005d0fbc: f901a020    	str	x0, [x1, #0x340]
1005d0fc0: f9695660    	ldr	x0, [x19, #0x52a8]
1005d0fc4: f901a420    	str	x0, [x1, #0x348]
1005d0fc8: d2800000    	mov	x0, #0x0                ; =0
1005d0fcc: f901a820    	str	x0, [x1, #0x350]
1005d0fd0: f9695e62    	ldr	x2, [x19, #0x52b8]
1005d0fd4: f901ac22    	str	x2, [x1, #0x358]
1005d0fd8: f9696262    	ldr	x2, [x19, #0x52c0]
1005d0fdc: f901b022    	str	x2, [x1, #0x360]
1005d0fe0: f901b420    	str	x0, [x1, #0x368]
1005d0fe4: f9696a62    	ldr	x2, [x19, #0x52d0]
1005d0fe8: f901b822    	str	x2, [x1, #0x370]
1005d0fec: f9696e62    	ldr	x2, [x19, #0x52d8]
1005d0ff0: f901bc22    	str	x2, [x1, #0x378]
1005d0ff4: f901c020    	str	x0, [x1, #0x380]
1005d0ff8: f9697660    	ldr	x0, [x19, #0x52e8]
1005d0ffc: f901c420    	str	x0, [x1, #0x388]
1005d1000: f9697a60    	ldr	x0, [x19, #0x52f0]
1005d1004: f901c820    	str	x0, [x1, #0x390]
1005d1008: f90097e1    	str	x1, [sp, #0x128]
1005d100c: d2806621    	mov	x1, #0x331              ; =817
1005d1010: 92800102    	mov	x2, #-0x9               ; =-9
1005d1014: f9409fe7    	ldr	x7, [sp, #0x138]
1005d1018: f84003e0    	ldur	x0, [sp]
1005d101c: aa1503e5    	mov	x5, x21
1005d1020: f9409be6    	ldr	x6, [sp, #0x130]
1005d1024: d63f00e0    	blr	x7
1005d1028: f100001f    	cmp	x0, #0x0
1005d102c: 54010161    	b.ne	0x1005d3058 <_mech_canonical_program_entry_v1_numeric_801+0x26d8>
1005d1030: d2800060    	mov	x0, #0x3                ; =3
1005d1034: f94093e5    	ldr	x5, [sp, #0x120]
1005d1038: f10008bf    	cmp	x5, #0x2
1005d103c: 54010123    	b.lo	0x1005d3060 <_mech_canonical_program_entry_v1_numeric_801+0x26e0>
1005d1040: d2800005    	mov	x5, #0x0                ; =0
1005d1044: f94097e3    	ldr	x3, [sp, #0x128]
1005d1048: f9000065    	str	x5, [x3]
1005d104c: f947a260    	ldr	x0, [x19, #0xf40]
1005d1050: f9000460    	str	x0, [x3, #0x8]
1005d1054: d2806621    	mov	x1, #0x331              ; =817
1005d1058: f84003e0    	ldur	x0, [sp]
1005d105c: f9409be6    	ldr	x6, [sp, #0x130]
1005d1060: f9409fe7    	ldr	x7, [sp, #0x138]
1005d1064: aa1503e4    	mov	x4, x21
1005d1068: aa0503e2    	mov	x2, x5
1005d106c: d63f00e0    	blr	x7
1005d1070: f100001f    	cmp	x0, #0x0
1005d1074: 5400ffa1    	b.ne	0x1005d3068 <_mech_canonical_program_entry_v1_numeric_801+0x26e8>
1005d1078: d2800060    	mov	x0, #0x3                ; =3
1005d107c: f80983e0    	stur	x0, [sp, #0x98]
1005d1080: 140010d2    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d1084: f90097e1    	str	x1, [sp, #0x128]
1005d1088: f90093e7    	str	x7, [sp, #0x120]
1005d108c: f80283e6    	stur	x6, [sp, #0x28]
1005d1090: aa1603fa    	mov	x26, x22
1005d1094: f94087e1    	ldr	x1, [sp, #0x108]
1005d1098: f100043f    	cmp	x1, #0x1
1005d109c: 9a9f17e1    	cset	x1, eq
1005d10a0: f94083e5    	ldr	x5, [sp, #0x100]
1005d10a4: f10004bf    	cmp	x5, #0x1
1005d10a8: 9a9f17e5    	cset	x5, eq
1005d10ac: 2a050021    	orr	w1, w1, w5
1005d10b0: 53001c25    	uxtb	w5, w1
1005d10b4: b4000085    	cbz	x5, 0x1005d10c4 <_mech_canonical_program_entry_v1_numeric_801+0x744>
1005d10b8: aa1403e5    	mov	x5, x20
1005d10bc: f9408fe6    	ldr	x6, [sp, #0x118]
1005d10c0: 14000009    	b	0x1005d10e4 <_mech_canonical_program_entry_v1_numeric_801+0x764>
1005d10c4: f94087e5    	ldr	x5, [sp, #0x108]
1005d10c8: b4021945    	cbz	x5, 0x1005d53f0 <_mech_canonical_program_entry_v1_numeric_801+0x4a70>
1005d10cc: 9ac50a85    	udiv	x5, x20, x5
1005d10d0: f94087e6    	ldr	x6, [sp, #0x108]
1005d10d4: 9b06d0a6    	msub	x6, x5, x6, x20
1005d10d8: f94083e7    	ldr	x7, [sp, #0x100]
1005d10dc: 9b0714c5    	madd	x5, x6, x7, x5
1005d10e0: f9408fe6    	ldr	x6, [sp, #0x118]
1005d10e4: f86578d9    	ldr	x25, [x6, x5, lsl #3]
1005d10e8: f9008fe6    	str	x6, [sp, #0x118]
1005d10ec: 91000685    	add	x5, x20, #0x1
1005d10f0: f9408be6    	ldr	x6, [sp, #0x110]
1005d10f4: eb0600bf    	cmp	x5, x6
1005d10f8: 54000e83    	b.lo	0x1005d12c8 <_mech_canonical_program_entry_v1_numeric_801+0x948>
1005d10fc: 140007dd    	b	0x1005d3070 <_mech_canonical_program_entry_v1_numeric_801+0x26f0>
1005d1100: f965ca63    	ldr	x3, [x19, #0x4b90]
1005d1104: f965ce64    	ldr	x4, [x19, #0x4b98]
1005d1108: d2800000    	mov	x0, #0x0                ; =0
1005d110c: f925c660    	str	x0, [x19, #0x4b88]
1005d1110: d2800060    	mov	x0, #0x3                ; =3
1005d1114: f94093e5    	ldr	x5, [sp, #0x120]
1005d1118: f101d0bf    	cmp	x5, #0x74
1005d111c: 540101a3    	b.lo	0x1005d3150 <_mech_canonical_program_entry_v1_numeric_801+0x27d0>
1005d1120: f967ba60    	ldr	x0, [x19, #0x4f70]
1005d1124: f94097e1    	ldr	x1, [sp, #0x128]
1005d1128: f9000820    	str	x0, [x1, #0x10]
1005d112c: f967be61    	ldr	x1, [x19, #0x4f78]
1005d1130: f94097e2    	ldr	x2, [sp, #0x128]
1005d1134: f9000c41    	str	x1, [x2, #0x18]
1005d1138: f968ee62    	ldr	x2, [x19, #0x51d8]
1005d113c: f94097e5    	ldr	x5, [sp, #0x128]
1005d1140: f9013ca2    	str	x2, [x5, #0x278]
1005d1144: f968fe62    	ldr	x2, [x19, #0x51f8]
1005d1148: f9014ca2    	str	x2, [x5, #0x298]
1005d114c: f94097e2    	ldr	x2, [sp, #0x128]
1005d1150: f9000840    	str	x0, [x2, #0x10]
1005d1154: f94097e0    	ldr	x0, [sp, #0x128]
1005d1158: f9000c01    	str	x1, [x0, #0x18]
1005d115c: f967da60    	ldr	x0, [x19, #0x4fb0]
1005d1160: f94097e1    	ldr	x1, [sp, #0x128]
1005d1164: f9002820    	str	x0, [x1, #0x50]
1005d1168: f967de60    	ldr	x0, [x19, #0x4fb8]
1005d116c: f9002c20    	str	x0, [x1, #0x58]
1005d1170: f9680260    	ldr	x0, [x19, #0x5000]
1005d1174: f9005020    	str	x0, [x1, #0xa0]
1005d1178: f9680660    	ldr	x0, [x19, #0x5008]
1005d117c: f9005420    	str	x0, [x1, #0xa8]
1005d1180: f9680a60    	ldr	x0, [x19, #0x5010]
1005d1184: f9005820    	str	x0, [x1, #0xb0]
1005d1188: f9683a60    	ldr	x0, [x19, #0x5070]
1005d118c: f9008820    	str	x0, [x1, #0x110]
1005d1190: f9683e60    	ldr	x0, [x19, #0x5078]
1005d1194: f9008c20    	str	x0, [x1, #0x118]
1005d1198: f9684260    	ldr	x0, [x19, #0x5080]
1005d119c: f9009020    	str	x0, [x1, #0x120]
1005d11a0: f9684660    	ldr	x0, [x19, #0x5088]
1005d11a4: f9009420    	str	x0, [x1, #0x128]
1005d11a8: f9688260    	ldr	x0, [x19, #0x5100]
1005d11ac: f900d0a0    	str	x0, [x5, #0x1a0]
1005d11b0: f9688660    	ldr	x0, [x19, #0x5108]
1005d11b4: f94097e7    	ldr	x7, [sp, #0x128]
1005d11b8: f900d4e0    	str	x0, [x7, #0x1a8]
1005d11bc: f9688a60    	ldr	x0, [x19, #0x5110]
1005d11c0: f94097ea    	ldr	x10, [sp, #0x128]
1005d11c4: f900d940    	str	x0, [x10, #0x1b0]
1005d11c8: f9688e60    	ldr	x0, [x19, #0x5118]
1005d11cc: f94097ed    	ldr	x13, [sp, #0x128]
1005d11d0: f900dda0    	str	x0, [x13, #0x1b8]
1005d11d4: f9689260    	ldr	x0, [x19, #0x5120]
1005d11d8: f900e020    	str	x0, [x1, #0x1c0]
1005d11dc: f9694260    	ldr	x0, [x19, #0x5280]
1005d11e0: f9019020    	str	x0, [x1, #0x320]
1005d11e4: f9694661    	ldr	x1, [x19, #0x5288]
1005d11e8: f94097e0    	ldr	x0, [sp, #0x128]
1005d11ec: f9019401    	str	x1, [x0, #0x328]
1005d11f0: f9694a62    	ldr	x2, [x19, #0x5290]
1005d11f4: f9019802    	str	x2, [x0, #0x330]
1005d11f8: f9694e65    	ldr	x5, [x19, #0x5298]
1005d11fc: f9019c05    	str	x5, [x0, #0x338]
1005d1200: f9695265    	ldr	x5, [x19, #0x52a0]
1005d1204: f901a005    	str	x5, [x0, #0x340]
1005d1208: f9695665    	ldr	x5, [x19, #0x52a8]
1005d120c: f901a405    	str	x5, [x0, #0x348]
1005d1210: d2800006    	mov	x6, #0x0                ; =0
1005d1214: f901a806    	str	x6, [x0, #0x350]
1005d1218: f9695e67    	ldr	x7, [x19, #0x52b8]
1005d121c: f901ac07    	str	x7, [x0, #0x358]
1005d1220: f9696268    	ldr	x8, [x19, #0x52c0]
1005d1224: f901b008    	str	x8, [x0, #0x360]
1005d1228: f901b406    	str	x6, [x0, #0x368]
1005d122c: f9696a6a    	ldr	x10, [x19, #0x52d0]
1005d1230: f901b80a    	str	x10, [x0, #0x370]
1005d1234: f9696e6b    	ldr	x11, [x19, #0x52d8]
1005d1238: f901bc0b    	str	x11, [x0, #0x378]
1005d123c: f901c006    	str	x6, [x0, #0x380]
1005d1240: f969766d    	ldr	x13, [x19, #0x52e8]
1005d1244: f901c40d    	str	x13, [x0, #0x388]
1005d1248: f9697a6e    	ldr	x14, [x19, #0x52f0]
1005d124c: f901c80e    	str	x14, [x0, #0x390]
1005d1250: d2806661    	mov	x1, #0x333              ; =819
1005d1254: 92800102    	mov	x2, #-0x9               ; =-9
1005d1258: f9409fe7    	ldr	x7, [sp, #0x138]
1005d125c: f84003e0    	ldur	x0, [sp]
1005d1260: aa1503e5    	mov	x5, x21
1005d1264: f9409be6    	ldr	x6, [sp, #0x130]
1005d1268: d63f00e0    	blr	x7
1005d126c: f100001f    	cmp	x0, #0x0
1005d1270: 5400f741    	b.ne	0x1005d3158 <_mech_canonical_program_entry_v1_numeric_801+0x27d8>
1005d1274: d2800060    	mov	x0, #0x3                ; =3
1005d1278: f94093e5    	ldr	x5, [sp, #0x120]
1005d127c: f10008bf    	cmp	x5, #0x2
1005d1280: 5400f703    	b.lo	0x1005d3160 <_mech_canonical_program_entry_v1_numeric_801+0x27e0>
1005d1284: d2800005    	mov	x5, #0x0                ; =0
1005d1288: f94097e3    	ldr	x3, [sp, #0x128]
1005d128c: f9000065    	str	x5, [x3]
1005d1290: f947aa60    	ldr	x0, [x19, #0xf50]
1005d1294: f9000460    	str	x0, [x3, #0x8]
1005d1298: d2806661    	mov	x1, #0x333              ; =819
1005d129c: f84003e0    	ldur	x0, [sp]
1005d12a0: f9409be6    	ldr	x6, [sp, #0x130]
1005d12a4: f9409fe7    	ldr	x7, [sp, #0x138]
1005d12a8: aa1503e4    	mov	x4, x21
1005d12ac: aa0503e2    	mov	x2, x5
1005d12b0: d63f00e0    	blr	x7
1005d12b4: f100001f    	cmp	x0, #0x0
1005d12b8: 5400f581    	b.ne	0x1005d3168 <_mech_canonical_program_entry_v1_numeric_801+0x27e8>
1005d12bc: d2800060    	mov	x0, #0x3                ; =3
1005d12c0: f80983e0    	stur	x0, [sp, #0x98]
1005d12c4: 14001041    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d12c8: f80183e4    	stur	x4, [sp, #0x18]
1005d12cc: 53001c21    	uxtb	w1, w1
1005d12d0: b4000061    	cbz	x1, 0x1005d12dc <_mech_canonical_program_entry_v1_numeric_801+0x95c>
1005d12d4: f9408fe1    	ldr	x1, [sp, #0x118]
1005d12d8: 14000009    	b	0x1005d12fc <_mech_canonical_program_entry_v1_numeric_801+0x97c>
1005d12dc: f94087e1    	ldr	x1, [sp, #0x108]
1005d12e0: b40208a1    	cbz	x1, 0x1005d53f4 <_mech_canonical_program_entry_v1_numeric_801+0x4a74>
1005d12e4: 9ac108a1    	udiv	x1, x5, x1
1005d12e8: f94087e4    	ldr	x4, [sp, #0x108]
1005d12ec: 9b049424    	msub	x4, x1, x4, x5
1005d12f0: f94083e5    	ldr	x5, [sp, #0x100]
1005d12f4: 9b050485    	madd	x5, x4, x5, x1
1005d12f8: f9408fe1    	ldr	x1, [sp, #0x118]
1005d12fc: f8657838    	ldr	x24, [x1, x5, lsl #3]
1005d1300: d29e9381    	mov	x1, #0xf49c             ; =62620
1005d1304: cb010063    	sub	x3, x3, x1
1005d1308: d280002f    	mov	x15, #0x1               ; =1
1005d130c: f80303ef    	stur	x15, [sp, #0x30]
1005d1310: 91000442    	add	x2, x2, #0x1
1005d1314: d2800005    	mov	x5, #0x0                ; =0
1005d1318: f80383e5    	stur	x5, [sp, #0x38]
1005d131c: d2980b81    	mov	x1, #0xc05c             ; =49244
1005d1320: eb01007f    	cmp	x3, x1
1005d1324: 9a9f37e1    	cset	x1, hs
1005d1328: f84e83e4    	ldur	x4, [sp, #0xe8]
1005d132c: 0a040021    	and	w1, w1, w4
1005d1330: 53001c21    	uxtb	w1, w1
1005d1334: b5001461    	cbnz	x1, 0x1005d15c0 <_mech_canonical_program_entry_v1_numeric_801+0xc40>
1005d1338: d2800020    	mov	x0, #0x1                ; =1
1005d133c: f9001a60    	str	x0, [x19, #0x30]
1005d1340: d2800041    	mov	x1, #0x2                ; =2
1005d1344: f9002261    	str	x1, [x19, #0x40]
1005d1348: aa0103f6    	mov	x22, x1
1005d134c: d2800061    	mov	x1, #0x3                ; =3
1005d1350: f9002661    	str	x1, [x19, #0x48]
1005d1354: d28000c1    	mov	x1, #0x6                ; =6
1005d1358: f9003261    	str	x1, [x19, #0x60]
1005d135c: d2800301    	mov	x1, #0x18               ; =24
1005d1360: f9004261    	str	x1, [x19, #0x80]
1005d1364: d2800001    	mov	x1, #0x0                ; =0
1005d1368: f900c661    	str	x1, [x19, #0x188]
1005d136c: f900ca60    	str	x0, [x19, #0x190]
1005d1370: f9078a74    	str	x20, [x19, #0xf10]
1005d1374: f9078e7b    	str	x27, [x19, #0xf18]
1005d1378: f84e03e0    	ldur	x0, [sp, #0xe0]
1005d137c: 53001c00    	uxtb	w0, w0
1005d1380: f9079a60    	str	x0, [x19, #0xf30]
1005d1384: f925c66b    	str	x11, [x19, #0x4b88]
1005d1388: f925ca63    	str	x3, [x19, #0x4b90]
1005d138c: f84183e4    	ldur	x4, [sp, #0x18]
1005d1390: f925ce64    	str	x4, [x19, #0x4b98]
1005d1394: f927ba74    	str	x20, [x19, #0x4f70]
1005d1398: f927be7b    	str	x27, [x19, #0x4f78]
1005d139c: f927da79    	str	x25, [x19, #0x4fb0]
1005d13a0: f927de78    	str	x24, [x19, #0x4fb8]
1005d13a4: f84783f5    	ldur	x21, [sp, #0x78]
1005d13a8: f928ee75    	str	x21, [x19, #0x51d8]
1005d13ac: f84083f5    	ldur	x21, [sp, #0x8]
1005d13b0: f928fe75    	str	x21, [x19, #0x51f8]
1005d13b4: f9294262    	str	x2, [x19, #0x5280]
1005d13b8: f84203ea    	ldur	x10, [sp, #0x20]
1005d13bc: f929466a    	str	x10, [x19, #0x5288]
1005d13c0: f84283e0    	ldur	x0, [sp, #0x28]
1005d13c4: f9294a60    	str	x0, [x19, #0x5290]
1005d13c8: f84103e1    	ldur	x1, [sp, #0x10]
1005d13cc: cb030020    	sub	x0, x1, x3
1005d13d0: d29e9381    	mov	x1, #0xf49c             ; =62620
1005d13d4: 9b018040    	msub	x0, x2, x1, x0
1005d13d8: f9294e60    	str	x0, [x19, #0x5298]
1005d13dc: f84303e1    	ldur	x1, [sp, #0x30]
1005d13e0: f9295261    	str	x1, [x19, #0x52a0]
1005d13e4: f84383e5    	ldur	x5, [sp, #0x38]
1005d13e8: f9295665    	str	x5, [x19, #0x52a8]
1005d13ec: f9295e68    	str	x8, [x19, #0x52b8]
1005d13f0: f929627c    	str	x28, [x19, #0x52c0]
1005d13f4: f9296a69    	str	x9, [x19, #0x52d0]
1005d13f8: f9296e77    	str	x23, [x19, #0x52d8]
1005d13fc: f929766e    	str	x14, [x19, #0x52e8]
1005d1400: f9297a6d    	str	x13, [x19, #0x52f0]
1005d1404: f965c669    	ldr	x9, [x19, #0x4b88]
1005d1408: f100013f    	cmp	x9, #0x0
1005d140c: 54000c60    	b.eq	0x1005d1598 <_mech_canonical_program_entry_v1_numeric_801+0xc18>
1005d1410: f965ca63    	ldr	x3, [x19, #0x4b90]
1005d1414: f965ce64    	ldr	x4, [x19, #0x4b98]
1005d1418: d280000c    	mov	x12, #0x0               ; =0
1005d141c: f925c66c    	str	x12, [x19, #0x4b88]
1005d1420: d2800060    	mov	x0, #0x3                ; =3
1005d1424: f94093e5    	ldr	x5, [sp, #0x120]
1005d1428: f80983e0    	stur	x0, [sp, #0x98]
1005d142c: f101d0bf    	cmp	x5, #0x74
1005d1430: 5401fcc3    	b.lo	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d1434: f967ba60    	ldr	x0, [x19, #0x4f70]
1005d1438: f94097e1    	ldr	x1, [sp, #0x128]
1005d143c: f9000820    	str	x0, [x1, #0x10]
1005d1440: f967be61    	ldr	x1, [x19, #0x4f78]
1005d1444: f94097e2    	ldr	x2, [sp, #0x128]
1005d1448: f9000c41    	str	x1, [x2, #0x18]
1005d144c: f968ee62    	ldr	x2, [x19, #0x51d8]
1005d1450: f94097e5    	ldr	x5, [sp, #0x128]
1005d1454: f9013ca2    	str	x2, [x5, #0x278]
1005d1458: f968fe62    	ldr	x2, [x19, #0x51f8]
1005d145c: f9014ca2    	str	x2, [x5, #0x298]
1005d1460: f94097e2    	ldr	x2, [sp, #0x128]
1005d1464: f9000840    	str	x0, [x2, #0x10]
1005d1468: f94097e0    	ldr	x0, [sp, #0x128]
1005d146c: f9000c01    	str	x1, [x0, #0x18]
1005d1470: f967da60    	ldr	x0, [x19, #0x4fb0]
1005d1474: f94097e1    	ldr	x1, [sp, #0x128]
1005d1478: f9002820    	str	x0, [x1, #0x50]
1005d147c: f967de60    	ldr	x0, [x19, #0x4fb8]
1005d1480: f9002c20    	str	x0, [x1, #0x58]
1005d1484: f9680260    	ldr	x0, [x19, #0x5000]
1005d1488: f9005020    	str	x0, [x1, #0xa0]
1005d148c: f9680660    	ldr	x0, [x19, #0x5008]
1005d1490: f90054a0    	str	x0, [x5, #0xa8]
1005d1494: f9680a60    	ldr	x0, [x19, #0x5010]
1005d1498: f94097e6    	ldr	x6, [sp, #0x128]
1005d149c: f90058c0    	str	x0, [x6, #0xb0]
1005d14a0: f9683a60    	ldr	x0, [x19, #0x5070]
1005d14a4: f94097e9    	ldr	x9, [sp, #0x128]
1005d14a8: f9008920    	str	x0, [x9, #0x110]
1005d14ac: f9683e60    	ldr	x0, [x19, #0x5078]
1005d14b0: f94097ec    	ldr	x12, [sp, #0x128]
1005d14b4: f9008d80    	str	x0, [x12, #0x118]
1005d14b8: f9684260    	ldr	x0, [x19, #0x5080]
1005d14bc: f94097ef    	ldr	x15, [sp, #0x128]
1005d14c0: f90091e0    	str	x0, [x15, #0x120]
1005d14c4: f9684660    	ldr	x0, [x19, #0x5088]
1005d14c8: f9009420    	str	x0, [x1, #0x128]
1005d14cc: f9688260    	ldr	x0, [x19, #0x5100]
1005d14d0: f900d020    	str	x0, [x1, #0x1a0]
1005d14d4: f9688660    	ldr	x0, [x19, #0x5108]
1005d14d8: f900d420    	str	x0, [x1, #0x1a8]
1005d14dc: f9688a60    	ldr	x0, [x19, #0x5110]
1005d14e0: f900d820    	str	x0, [x1, #0x1b0]
1005d14e4: f9688e60    	ldr	x0, [x19, #0x5118]
1005d14e8: f900dc20    	str	x0, [x1, #0x1b8]
1005d14ec: f9689260    	ldr	x0, [x19, #0x5120]
1005d14f0: f900e020    	str	x0, [x1, #0x1c0]
1005d14f4: f9694260    	ldr	x0, [x19, #0x5280]
1005d14f8: f9019020    	str	x0, [x1, #0x320]
1005d14fc: f9694660    	ldr	x0, [x19, #0x5288]
1005d1500: f9019420    	str	x0, [x1, #0x328]
1005d1504: f9694a60    	ldr	x0, [x19, #0x5290]
1005d1508: f9019820    	str	x0, [x1, #0x330]
1005d150c: f9694e60    	ldr	x0, [x19, #0x5298]
1005d1510: f9019c20    	str	x0, [x1, #0x338]
1005d1514: f9695260    	ldr	x0, [x19, #0x52a0]
1005d1518: f901a020    	str	x0, [x1, #0x340]
1005d151c: f9695660    	ldr	x0, [x19, #0x52a8]
1005d1520: f901a420    	str	x0, [x1, #0x348]
1005d1524: d2800000    	mov	x0, #0x0                ; =0
1005d1528: f901a820    	str	x0, [x1, #0x350]
1005d152c: f9695e61    	ldr	x1, [x19, #0x52b8]
1005d1530: f901ac41    	str	x1, [x2, #0x358]
1005d1534: f9696261    	ldr	x1, [x19, #0x52c0]
1005d1538: f901b041    	str	x1, [x2, #0x360]
1005d153c: f94097e1    	ldr	x1, [sp, #0x128]
1005d1540: f901b420    	str	x0, [x1, #0x368]
1005d1544: f9696a61    	ldr	x1, [x19, #0x52d0]
1005d1548: f901b841    	str	x1, [x2, #0x370]
1005d154c: f9696e61    	ldr	x1, [x19, #0x52d8]
1005d1550: f901bca1    	str	x1, [x5, #0x378]
1005d1554: f94097e7    	ldr	x7, [sp, #0x128]
1005d1558: f901c0e0    	str	x0, [x7, #0x380]
1005d155c: f9697660    	ldr	x0, [x19, #0x52e8]
1005d1560: f94097ea    	ldr	x10, [sp, #0x128]
1005d1564: f901c540    	str	x0, [x10, #0x388]
1005d1568: f9697a60    	ldr	x0, [x19, #0x52f0]
1005d156c: f94097ed    	ldr	x13, [sp, #0x128]
1005d1570: f901c9a0    	str	x0, [x13, #0x390]
1005d1574: d2806741    	mov	x1, #0x33a              ; =826
1005d1578: 92800102    	mov	x2, #-0x9               ; =-9
1005d157c: d2800025    	mov	x5, #0x1                ; =1
1005d1580: f84003e0    	ldur	x0, [sp]
1005d1584: f9409be6    	ldr	x6, [sp, #0x130]
1005d1588: f9409fe7    	ldr	x7, [sp, #0x138]
1005d158c: d63f00e0    	blr	x7
1005d1590: f100001f    	cmp	x0, #0x0
1005d1594: 5400dee1    	b.ne	0x1005d3170 <_mech_canonical_program_entry_v1_numeric_801+0x27f0>
1005d1598: d2800000    	mov	x0, #0x0                ; =0
1005d159c: aa1603e1    	mov	x1, x22
1005d15a0: 910503ff    	add	sp, sp, #0x140
1005d15a4: a8c153f3    	ldp	x19, x20, [sp], #0x10
1005d15a8: a8c15bf5    	ldp	x21, x22, [sp], #0x10
1005d15ac: a8c163f7    	ldp	x23, x24, [sp], #0x10
1005d15b0: a8c16bf9    	ldp	x25, x26, [sp], #0x10
1005d15b4: a8c173fb    	ldp	x27, x28, [sp], #0x10
1005d15b8: a8c17bfd    	ldp	x29, x30, [sp], #0x10
1005d15bc: d65f0fff    	retab
1005d15c0: f84303e1    	ldur	x1, [sp, #0x30]
1005d15c4: f84183e4    	ldur	x4, [sp, #0x18]
1005d15c8: 91000f25    	add	x5, x25, #0x3
1005d15cc: aa0503ef    	mov	x15, x5
1005d15d0: eb1901ff    	cmp	x15, x25
1005d15d4: f80d83ef    	stur	x15, [sp, #0xd8]
1005d15d8: 5400dd03    	b.lo	0x1005d3178 <_mech_canonical_program_entry_v1_numeric_801+0x27f8>
1005d15dc: f80303e1    	stur	x1, [sp, #0x30]
1005d15e0: f84d83e5    	ldur	x5, [sp, #0xd8]
1005d15e4: eb1800bf    	cmp	x5, x24
1005d15e8: 9a9f27e1    	cset	x1, lo
1005d15ec: f84d83e6    	ldur	x6, [sp, #0xd8]
1005d15f0: f80d03e1    	stur	x1, [sp, #0xd0]
1005d15f4: eb1800df    	cmp	x6, x24
1005d15f8: 54000083    	b.lo	0x1005d1608 <_mech_canonical_program_entry_v1_numeric_801+0xc88>
1005d15fc: d2980b81    	mov	x1, #0xc05c             ; =49244
1005d1600: cb010063    	sub	x3, x3, x1
1005d1604: 14000574    	b	0x1005d2bd4 <_mech_canonical_program_entry_v1_numeric_801+0x2254>
1005d1608: d2980b81    	mov	x1, #0xc05c             ; =49244
1005d160c: cb010063    	sub	x3, x3, x1
1005d1610: d280002f    	mov	x15, #0x1               ; =1
1005d1614: f80403ef    	stur	x15, [sp, #0x40]
1005d1618: 91000721    	add	x1, x25, #0x1
1005d161c: f80c83e1    	stur	x1, [sp, #0xc8]
1005d1620: d2800005    	mov	x5, #0x0                ; =0
1005d1624: f80483e5    	stur	x5, [sp, #0x48]
1005d1628: f84c83fc    	ldur	x28, [sp, #0xc8]
1005d162c: d2990e81    	mov	x1, #0xc874             ; =51316
1005d1630: eb01007f    	cmp	x3, x1
1005d1634: 9a9f37e1    	cset	x1, hs
1005d1638: f84e83e5    	ldur	x5, [sp, #0xe8]
1005d163c: 0a050021    	and	w1, w1, w5
1005d1640: 53001c21    	uxtb	w1, w1
1005d1644: b5001561    	cbnz	x1, 0x1005d18f0 <_mech_canonical_program_entry_v1_numeric_801+0xf70>
1005d1648: d2800020    	mov	x0, #0x1                ; =1
1005d164c: f9001a60    	str	x0, [x19, #0x30]
1005d1650: d2800055    	mov	x21, #0x2               ; =2
1005d1654: f9002275    	str	x21, [x19, #0x40]
1005d1658: d2800061    	mov	x1, #0x3                ; =3
1005d165c: f9002661    	str	x1, [x19, #0x48]
1005d1660: d28000c1    	mov	x1, #0x6                ; =6
1005d1664: f9003261    	str	x1, [x19, #0x60]
1005d1668: d2800301    	mov	x1, #0x18               ; =24
1005d166c: f9004261    	str	x1, [x19, #0x80]
1005d1670: d2800001    	mov	x1, #0x0                ; =0
1005d1674: f900c661    	str	x1, [x19, #0x188]
1005d1678: f900ca60    	str	x0, [x19, #0x190]
1005d167c: f9078a74    	str	x20, [x19, #0xf10]
1005d1680: f9078e7b    	str	x27, [x19, #0xf18]
1005d1684: f84e03e0    	ldur	x0, [sp, #0xe0]
1005d1688: 53001c00    	uxtb	w0, w0
1005d168c: f9079a60    	str	x0, [x19, #0xf30]
1005d1690: f907d679    	str	x25, [x19, #0xfa8]
1005d1694: f907da78    	str	x24, [x19, #0xfb0]
1005d1698: f84d03e0    	ldur	x0, [sp, #0xd0]
1005d169c: 53001c05    	uxtb	w5, w0
1005d16a0: f907e665    	str	x5, [x19, #0xfc8]
1005d16a4: f925c66b    	str	x11, [x19, #0x4b88]
1005d16a8: f925ca63    	str	x3, [x19, #0x4b90]
1005d16ac: f925ce64    	str	x4, [x19, #0x4b98]
1005d16b0: f927ba74    	str	x20, [x19, #0x4f70]
1005d16b4: f927be7b    	str	x27, [x19, #0x4f78]
1005d16b8: f927da79    	str	x25, [x19, #0x4fb0]
1005d16bc: f927de78    	str	x24, [x19, #0x4fb8]
1005d16c0: f9280279    	str	x25, [x19, #0x5000]
1005d16c4: f928067c    	str	x28, [x19, #0x5008]
1005d16c8: f9280a78    	str	x24, [x19, #0x5010]
1005d16cc: f84783e0    	ldur	x0, [sp, #0x78]
1005d16d0: f928ee60    	str	x0, [x19, #0x51d8]
1005d16d4: f84083e0    	ldur	x0, [sp, #0x8]
1005d16d8: f928fe60    	str	x0, [x19, #0x51f8]
1005d16dc: f9294262    	str	x2, [x19, #0x5280]
1005d16e0: f84203e0    	ldur	x0, [sp, #0x20]
1005d16e4: f9294660    	str	x0, [x19, #0x5288]
1005d16e8: f84283e0    	ldur	x0, [sp, #0x28]
1005d16ec: f9294a60    	str	x0, [x19, #0x5290]
1005d16f0: f84103e1    	ldur	x1, [sp, #0x10]
1005d16f4: cb030020    	sub	x0, x1, x3
1005d16f8: d29e9381    	mov	x1, #0xf49c             ; =62620
1005d16fc: 9b018040    	msub	x0, x2, x1, x0
1005d1700: f9294e60    	str	x0, [x19, #0x5298]
1005d1704: f84303e5    	ldur	x5, [sp, #0x30]
1005d1708: f9295265    	str	x5, [x19, #0x52a0]
1005d170c: f84383e0    	ldur	x0, [sp, #0x38]
1005d1710: f9295660    	str	x0, [x19, #0x52a8]
1005d1714: f84403e8    	ldur	x8, [sp, #0x40]
1005d1718: f9295e68    	str	x8, [x19, #0x52b8]
1005d171c: f84483e5    	ldur	x5, [sp, #0x48]
1005d1720: f9296265    	str	x5, [x19, #0x52c0]
1005d1724: f9296a69    	str	x9, [x19, #0x52d0]
1005d1728: f9296e77    	str	x23, [x19, #0x52d8]
1005d172c: f929766e    	str	x14, [x19, #0x52e8]
1005d1730: f9297a6d    	str	x13, [x19, #0x52f0]
1005d1734: f965c660    	ldr	x0, [x19, #0x4b88]
1005d1738: f100001f    	cmp	x0, #0x0
1005d173c: 54000c60    	b.eq	0x1005d18c8 <_mech_canonical_program_entry_v1_numeric_801+0xf48>
1005d1740: f965ca63    	ldr	x3, [x19, #0x4b90]
1005d1744: f965ce64    	ldr	x4, [x19, #0x4b98]
1005d1748: d2800000    	mov	x0, #0x0                ; =0
1005d174c: f925c660    	str	x0, [x19, #0x4b88]
1005d1750: d2800060    	mov	x0, #0x3                ; =3
1005d1754: f94093e5    	ldr	x5, [sp, #0x120]
1005d1758: f80983e0    	stur	x0, [sp, #0x98]
1005d175c: f101d0bf    	cmp	x5, #0x74
1005d1760: 5401e343    	b.lo	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d1764: f967ba60    	ldr	x0, [x19, #0x4f70]
1005d1768: f94097e1    	ldr	x1, [sp, #0x128]
1005d176c: f9000820    	str	x0, [x1, #0x10]
1005d1770: f967be61    	ldr	x1, [x19, #0x4f78]
1005d1774: f94097e2    	ldr	x2, [sp, #0x128]
1005d1778: f9000c41    	str	x1, [x2, #0x18]
1005d177c: f968ee62    	ldr	x2, [x19, #0x51d8]
1005d1780: f94097e5    	ldr	x5, [sp, #0x128]
1005d1784: f9013ca2    	str	x2, [x5, #0x278]
1005d1788: f968fe62    	ldr	x2, [x19, #0x51f8]
1005d178c: f9014ca2    	str	x2, [x5, #0x298]
1005d1790: f94097e2    	ldr	x2, [sp, #0x128]
1005d1794: f9000840    	str	x0, [x2, #0x10]
1005d1798: f94097e0    	ldr	x0, [sp, #0x128]
1005d179c: f9000c01    	str	x1, [x0, #0x18]
1005d17a0: f967da60    	ldr	x0, [x19, #0x4fb0]
1005d17a4: f94097e1    	ldr	x1, [sp, #0x128]
1005d17a8: f9002820    	str	x0, [x1, #0x50]
1005d17ac: f967de60    	ldr	x0, [x19, #0x4fb8]
1005d17b0: f9002c40    	str	x0, [x2, #0x58]
1005d17b4: f9680260    	ldr	x0, [x19, #0x5000]
1005d17b8: f90050a0    	str	x0, [x5, #0xa0]
1005d17bc: f9680660    	ldr	x0, [x19, #0x5008]
1005d17c0: f94097e8    	ldr	x8, [sp, #0x128]
1005d17c4: f9005500    	str	x0, [x8, #0xa8]
1005d17c8: f9680a60    	ldr	x0, [x19, #0x5010]
1005d17cc: f94097eb    	ldr	x11, [sp, #0x128]
1005d17d0: f9005960    	str	x0, [x11, #0xb0]
1005d17d4: f9683a60    	ldr	x0, [x19, #0x5070]
1005d17d8: f94097ee    	ldr	x14, [sp, #0x128]
1005d17dc: f90089c0    	str	x0, [x14, #0x110]
1005d17e0: f9683e60    	ldr	x0, [x19, #0x5078]
1005d17e4: f9008c20    	str	x0, [x1, #0x118]
1005d17e8: f9684260    	ldr	x0, [x19, #0x5080]
1005d17ec: f9009020    	str	x0, [x1, #0x120]
1005d17f0: f9684660    	ldr	x0, [x19, #0x5088]
1005d17f4: f9009420    	str	x0, [x1, #0x128]
1005d17f8: f9688260    	ldr	x0, [x19, #0x5100]
1005d17fc: f900d020    	str	x0, [x1, #0x1a0]
1005d1800: f9688660    	ldr	x0, [x19, #0x5108]
1005d1804: f900d420    	str	x0, [x1, #0x1a8]
1005d1808: f9688a60    	ldr	x0, [x19, #0x5110]
1005d180c: f900d820    	str	x0, [x1, #0x1b0]
1005d1810: f9688e60    	ldr	x0, [x19, #0x5118]
1005d1814: f900dc20    	str	x0, [x1, #0x1b8]
1005d1818: f9689260    	ldr	x0, [x19, #0x5120]
1005d181c: f900e020    	str	x0, [x1, #0x1c0]
1005d1820: f9694260    	ldr	x0, [x19, #0x5280]
1005d1824: f9019020    	str	x0, [x1, #0x320]
1005d1828: f9694660    	ldr	x0, [x19, #0x5288]
1005d182c: f9019420    	str	x0, [x1, #0x328]
1005d1830: f9694a60    	ldr	x0, [x19, #0x5290]
1005d1834: f9019820    	str	x0, [x1, #0x330]
1005d1838: f9694e60    	ldr	x0, [x19, #0x5298]
1005d183c: f9019c20    	str	x0, [x1, #0x338]
1005d1840: f9695260    	ldr	x0, [x19, #0x52a0]
1005d1844: f901a020    	str	x0, [x1, #0x340]
1005d1848: f9695660    	ldr	x0, [x19, #0x52a8]
1005d184c: f901a420    	str	x0, [x1, #0x348]
1005d1850: d2800000    	mov	x0, #0x0                ; =0
1005d1854: f901a820    	str	x0, [x1, #0x350]
1005d1858: f9695e61    	ldr	x1, [x19, #0x52b8]
1005d185c: f901ac41    	str	x1, [x2, #0x358]
1005d1860: f9696261    	ldr	x1, [x19, #0x52c0]
1005d1864: f901b041    	str	x1, [x2, #0x360]
1005d1868: f901b4a0    	str	x0, [x5, #0x368]
1005d186c: f9696a61    	ldr	x1, [x19, #0x52d0]
1005d1870: f94097e7    	ldr	x7, [sp, #0x128]
1005d1874: f901b8e1    	str	x1, [x7, #0x370]
1005d1878: f9696e62    	ldr	x2, [x19, #0x52d8]
1005d187c: f94097ea    	ldr	x10, [sp, #0x128]
1005d1880: f901bd42    	str	x2, [x10, #0x378]
1005d1884: f94097ec    	ldr	x12, [sp, #0x128]
1005d1888: f901c180    	str	x0, [x12, #0x380]
1005d188c: f9697665    	ldr	x5, [x19, #0x52e8]
1005d1890: f94097ef    	ldr	x15, [sp, #0x128]
1005d1894: f901c5e5    	str	x5, [x15, #0x388]
1005d1898: f9697a65    	ldr	x5, [x19, #0x52f0]
1005d189c: f94097e0    	ldr	x0, [sp, #0x128]
1005d18a0: f901c805    	str	x5, [x0, #0x390]
1005d18a4: d2806a21    	mov	x1, #0x351              ; =849
1005d18a8: 92800102    	mov	x2, #-0x9               ; =-9
1005d18ac: d2800025    	mov	x5, #0x1                ; =1
1005d18b0: f84003e0    	ldur	x0, [sp]
1005d18b4: f9409be6    	ldr	x6, [sp, #0x130]
1005d18b8: f9409fe7    	ldr	x7, [sp, #0x138]
1005d18bc: d63f00e0    	blr	x7
1005d18c0: f100001f    	cmp	x0, #0x0
1005d18c4: 5400cc21    	b.ne	0x1005d3248 <_mech_canonical_program_entry_v1_numeric_801+0x28c8>
1005d18c8: d2800000    	mov	x0, #0x0                ; =0
1005d18cc: d2800061    	mov	x1, #0x3                ; =3
1005d18d0: 910503ff    	add	sp, sp, #0x140
1005d18d4: a8c153f3    	ldp	x19, x20, [sp], #0x10
1005d18d8: a8c15bf5    	ldp	x21, x22, [sp], #0x10
1005d18dc: a8c163f7    	ldp	x23, x24, [sp], #0x10
1005d18e0: a8c16bf9    	ldp	x25, x26, [sp], #0x10
1005d18e4: a8c173fb    	ldp	x27, x28, [sp], #0x10
1005d18e8: a8c17bfd    	ldp	x29, x30, [sp], #0x10
1005d18ec: d65f0fff    	retab
1005d18f0: d2800055    	mov	x21, #0x2               ; =2
1005d18f4: f80c03f5    	stur	x21, [sp, #0xc0]
1005d18f8: 91000b81    	add	x1, x28, #0x2
1005d18fc: eb1c003f    	cmp	x1, x28
1005d1900: 5400ca83    	b.lo	0x1005d3250 <_mech_canonical_program_entry_v1_numeric_801+0x28d0>
1005d1904: 91000b81    	add	x1, x28, #0x2
1005d1908: aa0103ef    	mov	x15, x1
1005d190c: eb1801ff    	cmp	x15, x24
1005d1910: f80b83ef    	stur	x15, [sp, #0xb8]
1005d1914: 9a9f27f5    	cset	x21, lo
1005d1918: f84b83e1    	ldur	x1, [sp, #0xb8]
1005d191c: aa1503e6    	mov	x6, x21
1005d1920: eb18003f    	cmp	x1, x24
1005d1924: 54000083    	b.lo	0x1005d1934 <_mech_canonical_program_entry_v1_numeric_801+0xfb4>
1005d1928: d2990e81    	mov	x1, #0xc874             ; =51316
1005d192c: cb010063    	sub	x3, x3, x1
1005d1930: 1400049d    	b	0x1005d2ba4 <_mech_canonical_program_entry_v1_numeric_801+0x2224>
1005d1934: d2990e8c    	mov	x12, #0xc874            ; =51316
1005d1938: cb0c0063    	sub	x3, x3, x12
1005d193c: d2800021    	mov	x1, #0x1                ; =1
1005d1940: f80503e1    	stur	x1, [sp, #0x50]
1005d1944: 9100078c    	add	x12, x28, #0x1
1005d1948: f80b03ec    	stur	x12, [sp, #0xb0]
1005d194c: d280000c    	mov	x12, #0x0               ; =0
1005d1950: f80583ec    	stur	x12, [sp, #0x58]
1005d1954: f84b03f7    	ldur	x23, [sp, #0xb0]
1005d1958: d29a118c    	mov	x12, #0xd08c            ; =53388
1005d195c: eb0c007f    	cmp	x3, x12
1005d1960: 9a9f37ef    	cset	x15, hs
1005d1964: f84e83e5    	ldur	x5, [sp, #0xe8]
1005d1968: 0a0501ef    	and	w15, w15, w5
1005d196c: 53001def    	uxtb	w15, w15
1005d1970: b50016ef    	cbnz	x15, 0x1005d1c4c <_mech_canonical_program_entry_v1_numeric_801+0x12cc>
1005d1974: d280002f    	mov	x15, #0x1               ; =1
1005d1978: f9001a6f    	str	x15, [x19, #0x30]
1005d197c: f84c03e0    	ldur	x0, [sp, #0xc0]
1005d1980: f9002260    	str	x0, [x19, #0x40]
1005d1984: d2800060    	mov	x0, #0x3                ; =3
1005d1988: f9002660    	str	x0, [x19, #0x48]
1005d198c: d28000c0    	mov	x0, #0x6                ; =6
1005d1990: f9003260    	str	x0, [x19, #0x60]
1005d1994: d2800300    	mov	x0, #0x18               ; =24
1005d1998: f9004260    	str	x0, [x19, #0x80]
1005d199c: d2800000    	mov	x0, #0x0                ; =0
1005d19a0: f900c660    	str	x0, [x19, #0x188]
1005d19a4: f900ca6f    	str	x15, [x19, #0x190]
1005d19a8: f9078a74    	str	x20, [x19, #0xf10]
1005d19ac: f9078e7b    	str	x27, [x19, #0xf18]
1005d19b0: f84e03e0    	ldur	x0, [sp, #0xe0]
1005d19b4: 53001c00    	uxtb	w0, w0
1005d19b8: f9079a60    	str	x0, [x19, #0xf30]
1005d19bc: f907d679    	str	x25, [x19, #0xfa8]
1005d19c0: f907da78    	str	x24, [x19, #0xfb0]
1005d19c4: f84d03e0    	ldur	x0, [sp, #0xd0]
1005d19c8: 53001c00    	uxtb	w0, w0
1005d19cc: f907e660    	str	x0, [x19, #0xfc8]
1005d19d0: f9081a79    	str	x25, [x19, #0x1030]
1005d19d4: f9081e7c    	str	x28, [x19, #0x1038]
1005d19d8: f9082278    	str	x24, [x19, #0x1040]
1005d19dc: aa0603fa    	mov	x26, x6
1005d19e0: 53001f40    	uxtb	w0, w26
1005d19e4: f9082e60    	str	x0, [x19, #0x1058]
1005d19e8: f925c66b    	str	x11, [x19, #0x4b88]
1005d19ec: f925ca63    	str	x3, [x19, #0x4b90]
1005d19f0: f925ce64    	str	x4, [x19, #0x4b98]
1005d19f4: f927ba74    	str	x20, [x19, #0x4f70]
1005d19f8: f927be7b    	str	x27, [x19, #0x4f78]
1005d19fc: f927da79    	str	x25, [x19, #0x4fb0]
1005d1a00: f927de78    	str	x24, [x19, #0x4fb8]
1005d1a04: f9280279    	str	x25, [x19, #0x5000]
1005d1a08: f928067c    	str	x28, [x19, #0x5008]
1005d1a0c: f9280a78    	str	x24, [x19, #0x5010]
1005d1a10: f9283a79    	str	x25, [x19, #0x5070]
1005d1a14: f9283e7c    	str	x28, [x19, #0x5078]
1005d1a18: f9284277    	str	x23, [x19, #0x5080]
1005d1a1c: f9284678    	str	x24, [x19, #0x5088]
1005d1a20: f84783f5    	ldur	x21, [sp, #0x78]
1005d1a24: f928ee75    	str	x21, [x19, #0x51d8]
1005d1a28: f84083f5    	ldur	x21, [sp, #0x8]
1005d1a2c: f928fe75    	str	x21, [x19, #0x51f8]
1005d1a30: f9294262    	str	x2, [x19, #0x5280]
1005d1a34: f84203e0    	ldur	x0, [sp, #0x20]
1005d1a38: f9294660    	str	x0, [x19, #0x5288]
1005d1a3c: f84283e9    	ldur	x9, [sp, #0x28]
1005d1a40: f9294a69    	str	x9, [x19, #0x5290]
1005d1a44: f84103e1    	ldur	x1, [sp, #0x10]
1005d1a48: cb030020    	sub	x0, x1, x3
1005d1a4c: d29e9381    	mov	x1, #0xf49c             ; =62620
1005d1a50: 9b018040    	msub	x0, x2, x1, x0
1005d1a54: f9294e60    	str	x0, [x19, #0x5298]
1005d1a58: f84303e5    	ldur	x5, [sp, #0x30]
1005d1a5c: f9295265    	str	x5, [x19, #0x52a0]
1005d1a60: f84383e9    	ldur	x9, [sp, #0x38]
1005d1a64: f9295669    	str	x9, [x19, #0x52a8]
1005d1a68: f84403ef    	ldur	x15, [sp, #0x40]
1005d1a6c: f9295e6f    	str	x15, [x19, #0x52b8]
1005d1a70: f84483e8    	ldur	x8, [sp, #0x48]
1005d1a74: f9296268    	str	x8, [x19, #0x52c0]
1005d1a78: f84503e1    	ldur	x1, [sp, #0x50]
1005d1a7c: f9296a61    	str	x1, [x19, #0x52d0]
1005d1a80: f84583ec    	ldur	x12, [sp, #0x58]
1005d1a84: f9296e6c    	str	x12, [x19, #0x52d8]
1005d1a88: f929766e    	str	x14, [x19, #0x52e8]
1005d1a8c: f9297a6d    	str	x13, [x19, #0x52f0]
1005d1a90: f965c660    	ldr	x0, [x19, #0x4b88]
1005d1a94: f100001f    	cmp	x0, #0x0
1005d1a98: 54000c60    	b.eq	0x1005d1c24 <_mech_canonical_program_entry_v1_numeric_801+0x12a4>
1005d1a9c: f965ca63    	ldr	x3, [x19, #0x4b90]
1005d1aa0: f965ce64    	ldr	x4, [x19, #0x4b98]
1005d1aa4: d2800000    	mov	x0, #0x0                ; =0
1005d1aa8: f925c660    	str	x0, [x19, #0x4b88]
1005d1aac: d2800060    	mov	x0, #0x3                ; =3
1005d1ab0: f94093e5    	ldr	x5, [sp, #0x120]
1005d1ab4: f80983e0    	stur	x0, [sp, #0x98]
1005d1ab8: f101d0bf    	cmp	x5, #0x74
1005d1abc: 5401c863    	b.lo	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d1ac0: f967ba65    	ldr	x5, [x19, #0x4f70]
1005d1ac4: f94097e6    	ldr	x6, [sp, #0x128]
1005d1ac8: f90008c5    	str	x5, [x6, #0x10]
1005d1acc: f967be66    	ldr	x6, [x19, #0x4f78]
1005d1ad0: f94097e8    	ldr	x8, [sp, #0x128]
1005d1ad4: f9000d06    	str	x6, [x8, #0x18]
1005d1ad8: f968ee67    	ldr	x7, [x19, #0x51d8]
1005d1adc: f94097eb    	ldr	x11, [sp, #0x128]
1005d1ae0: f9013d67    	str	x7, [x11, #0x278]
1005d1ae4: f968fe67    	ldr	x7, [x19, #0x51f8]
1005d1ae8: f94097ee    	ldr	x14, [sp, #0x128]
1005d1aec: f9014dc7    	str	x7, [x14, #0x298]
1005d1af0: f94097e0    	ldr	x0, [sp, #0x128]
1005d1af4: f9000805    	str	x5, [x0, #0x10]
1005d1af8: f9000c06    	str	x6, [x0, #0x18]
1005d1afc: f967da69    	ldr	x9, [x19, #0x4fb0]
1005d1b00: f9002809    	str	x9, [x0, #0x50]
1005d1b04: f967de6a    	ldr	x10, [x19, #0x4fb8]
1005d1b08: f9002c0a    	str	x10, [x0, #0x58]
1005d1b0c: f968026b    	ldr	x11, [x19, #0x5000]
1005d1b10: f900500b    	str	x11, [x0, #0xa0]
1005d1b14: f968066c    	ldr	x12, [x19, #0x5008]
1005d1b18: f900540c    	str	x12, [x0, #0xa8]
1005d1b1c: f9680a6d    	ldr	x13, [x19, #0x5010]
1005d1b20: f900580d    	str	x13, [x0, #0xb0]
1005d1b24: f9683a6e    	ldr	x14, [x19, #0x5070]
1005d1b28: f900880e    	str	x14, [x0, #0x110]
1005d1b2c: f9683e6f    	ldr	x15, [x19, #0x5078]
1005d1b30: f9008c0f    	str	x15, [x0, #0x118]
1005d1b34: f9684260    	ldr	x0, [x19, #0x5080]
1005d1b38: f94097e1    	ldr	x1, [sp, #0x128]
1005d1b3c: f9009020    	str	x0, [x1, #0x120]
1005d1b40: f9684660    	ldr	x0, [x19, #0x5088]
1005d1b44: f9009420    	str	x0, [x1, #0x128]
1005d1b48: f9688260    	ldr	x0, [x19, #0x5100]
1005d1b4c: f900d020    	str	x0, [x1, #0x1a0]
1005d1b50: f9688660    	ldr	x0, [x19, #0x5108]
1005d1b54: f900d420    	str	x0, [x1, #0x1a8]
1005d1b58: f9688a60    	ldr	x0, [x19, #0x5110]
1005d1b5c: f900d820    	str	x0, [x1, #0x1b0]
1005d1b60: f9688e60    	ldr	x0, [x19, #0x5118]
1005d1b64: f900dc20    	str	x0, [x1, #0x1b8]
1005d1b68: f9689260    	ldr	x0, [x19, #0x5120]
1005d1b6c: f900e020    	str	x0, [x1, #0x1c0]
1005d1b70: f9694260    	ldr	x0, [x19, #0x5280]
1005d1b74: f9019020    	str	x0, [x1, #0x320]
1005d1b78: f9694660    	ldr	x0, [x19, #0x5288]
1005d1b7c: f94097e5    	ldr	x5, [sp, #0x128]
1005d1b80: f90194a0    	str	x0, [x5, #0x328]
1005d1b84: f9694a60    	ldr	x0, [x19, #0x5290]
1005d1b88: f94097e6    	ldr	x6, [sp, #0x128]
1005d1b8c: f90198c0    	str	x0, [x6, #0x330]
1005d1b90: f9694e60    	ldr	x0, [x19, #0x5298]
1005d1b94: f94097e9    	ldr	x9, [sp, #0x128]
1005d1b98: f9019d20    	str	x0, [x9, #0x338]
1005d1b9c: f9695260    	ldr	x0, [x19, #0x52a0]
1005d1ba0: f94097ec    	ldr	x12, [sp, #0x128]
1005d1ba4: f901a180    	str	x0, [x12, #0x340]
1005d1ba8: f9695660    	ldr	x0, [x19, #0x52a8]
1005d1bac: f94097ef    	ldr	x15, [sp, #0x128]
1005d1bb0: f901a5e0    	str	x0, [x15, #0x348]
1005d1bb4: d2800000    	mov	x0, #0x0                ; =0
1005d1bb8: f901a820    	str	x0, [x1, #0x350]
1005d1bbc: f9695e61    	ldr	x1, [x19, #0x52b8]
1005d1bc0: f94097e2    	ldr	x2, [sp, #0x128]
1005d1bc4: f901ac41    	str	x1, [x2, #0x358]
1005d1bc8: f9696261    	ldr	x1, [x19, #0x52c0]
1005d1bcc: f901b041    	str	x1, [x2, #0x360]
1005d1bd0: f94097e1    	ldr	x1, [sp, #0x128]
1005d1bd4: f901b420    	str	x0, [x1, #0x368]
1005d1bd8: f9696a61    	ldr	x1, [x19, #0x52d0]
1005d1bdc: f901b841    	str	x1, [x2, #0x370]
1005d1be0: f9696e61    	ldr	x1, [x19, #0x52d8]
1005d1be4: f901bc41    	str	x1, [x2, #0x378]
1005d1be8: f94097e1    	ldr	x1, [sp, #0x128]
1005d1bec: f901c020    	str	x0, [x1, #0x380]
1005d1bf0: f9697660    	ldr	x0, [x19, #0x52e8]
1005d1bf4: f901c420    	str	x0, [x1, #0x388]
1005d1bf8: f9697a60    	ldr	x0, [x19, #0x52f0]
1005d1bfc: f901c820    	str	x0, [x1, #0x390]
1005d1c00: d2806d41    	mov	x1, #0x36a              ; =874
1005d1c04: 92800102    	mov	x2, #-0x9               ; =-9
1005d1c08: d2800025    	mov	x5, #0x1                ; =1
1005d1c0c: f84003e0    	ldur	x0, [sp]
1005d1c10: f9409be6    	ldr	x6, [sp, #0x130]
1005d1c14: f9409fe7    	ldr	x7, [sp, #0x138]
1005d1c18: d63f00e0    	blr	x7
1005d1c1c: f100001f    	cmp	x0, #0x0
1005d1c20: 5400b941    	b.ne	0x1005d3348 <_mech_canonical_program_entry_v1_numeric_801+0x29c8>
1005d1c24: d2800000    	mov	x0, #0x0                ; =0
1005d1c28: d2800081    	mov	x1, #0x4                ; =4
1005d1c2c: 910503ff    	add	sp, sp, #0x140
1005d1c30: a8c153f3    	ldp	x19, x20, [sp], #0x10
1005d1c34: a8c15bf5    	ldp	x21, x22, [sp], #0x10
1005d1c38: a8c163f7    	ldp	x23, x24, [sp], #0x10
1005d1c3c: a8c16bf9    	ldp	x25, x26, [sp], #0x10
1005d1c40: a8c173fb    	ldp	x27, x28, [sp], #0x10
1005d1c44: a8c17bfd    	ldp	x29, x30, [sp], #0x10
1005d1c48: d65f0fff    	retab
1005d1c4c: 910006f5    	add	x21, x23, #0x1
1005d1c50: eb1702bf    	cmp	x21, x23
1005d1c54: f80a83f5    	stur	x21, [sp, #0xa8]
1005d1c58: 5400b7e3    	b.lo	0x1005d3354 <_mech_canonical_program_entry_v1_numeric_801+0x29d4>
1005d1c5c: aa0603f5    	mov	x21, x6
1005d1c60: f84a83ef    	ldur	x15, [sp, #0xa8]
1005d1c64: eb1801ff    	cmp	x15, x24
1005d1c68: 9a9f27e1    	cset	x1, lo
1005d1c6c: f80a03e1    	stur	x1, [sp, #0xa0]
1005d1c70: f84a83e1    	ldur	x1, [sp, #0xa8]
1005d1c74: eb18003f    	cmp	x1, x24
1005d1c78: 54000083    	b.lo	0x1005d1c88 <_mech_canonical_program_entry_v1_numeric_801+0x1308>
1005d1c7c: d29a1181    	mov	x1, #0xd08c             ; =53388
1005d1c80: cb010063    	sub	x3, x3, x1
1005d1c84: 140003ba    	b	0x1005d2b6c <_mech_canonical_program_entry_v1_numeric_801+0x21ec>
1005d1c88: d29a1181    	mov	x1, #0xd08c             ; =53388
1005d1c8c: cb010063    	sub	x3, x3, x1
1005d1c90: d2800026    	mov	x6, #0x1                ; =1
1005d1c94: aa0603ea    	mov	x10, x6
1005d1c98: d2800001    	mov	x1, #0x0                ; =0
1005d1c9c: aa0103e7    	mov	x7, x1
1005d1ca0: f84a83f6    	ldur	x22, [sp, #0xa8]
1005d1ca4: 52834f81    	mov	w1, #0x1a7c             ; =6780
1005d1ca8: 72a00021    	movk	w1, #0x1, lsl #16
1005d1cac: eb01007f    	cmp	x3, x1
1005d1cb0: 9a9f37e1    	cset	x1, hs
1005d1cb4: f84e83e5    	ldur	x5, [sp, #0xe8]
1005d1cb8: 0a050021    	and	w1, w1, w5
1005d1cbc: f84083e5    	ldur	x5, [sp, #0x8]
1005d1cc0: f84603ec    	ldur	x12, [sp, #0x60]
1005d1cc4: eb0c00bf    	cmp	x5, x12
1005d1cc8: 9a9f87e5    	cset	x5, ls
1005d1ccc: f84083e6    	ldur	x6, [sp, #0x8]
1005d1cd0: cb060186    	sub	x6, x12, x6
1005d1cd4: f10000df    	cmp	x6, #0x0
1005d1cd8: 9a9f07e6    	cset	x6, ne
1005d1cdc: 0a0600a5    	and	w5, w5, w6
1005d1ce0: 0a050021    	and	w1, w1, w5
1005d1ce4: 53001c21    	uxtb	w1, w1
1005d1ce8: b50018a1    	cbnz	x1, 0x1005d1ffc <_mech_canonical_program_entry_v1_numeric_801+0x167c>
1005d1cec: d2800020    	mov	x0, #0x1                ; =1
1005d1cf0: f9001a60    	str	x0, [x19, #0x30]
1005d1cf4: f84c03ed    	ldur	x13, [sp, #0xc0]
1005d1cf8: f900226d    	str	x13, [x19, #0x40]
1005d1cfc: d2800061    	mov	x1, #0x3                ; =3
1005d1d00: f9002661    	str	x1, [x19, #0x48]
1005d1d04: d28000c1    	mov	x1, #0x6                ; =6
1005d1d08: f9003261    	str	x1, [x19, #0x60]
1005d1d0c: d2800301    	mov	x1, #0x18               ; =24
1005d1d10: f9004261    	str	x1, [x19, #0x80]
1005d1d14: d2800001    	mov	x1, #0x0                ; =0
1005d1d18: f900c661    	str	x1, [x19, #0x188]
1005d1d1c: f900ca60    	str	x0, [x19, #0x190]
1005d1d20: f9078a74    	str	x20, [x19, #0xf10]
1005d1d24: f9078e7b    	str	x27, [x19, #0xf18]
1005d1d28: f84e03e0    	ldur	x0, [sp, #0xe0]
1005d1d2c: 53001c01    	uxtb	w1, w0
1005d1d30: f9079a61    	str	x1, [x19, #0xf30]
1005d1d34: f907d679    	str	x25, [x19, #0xfa8]
1005d1d38: f907da78    	str	x24, [x19, #0xfb0]
1005d1d3c: f84d03e0    	ldur	x0, [sp, #0xd0]
1005d1d40: 53001c05    	uxtb	w5, w0
1005d1d44: f907e665    	str	x5, [x19, #0xfc8]
1005d1d48: f9081a79    	str	x25, [x19, #0x1030]
1005d1d4c: f9081e7c    	str	x28, [x19, #0x1038]
1005d1d50: f9082278    	str	x24, [x19, #0x1040]
1005d1d54: 53001ea8    	uxtb	w8, w21
1005d1d58: f9082e68    	str	x8, [x19, #0x1058]
1005d1d5c: f9086679    	str	x25, [x19, #0x10c8]
1005d1d60: f9086a7c    	str	x28, [x19, #0x10d0]
1005d1d64: f9086e77    	str	x23, [x19, #0x10d8]
1005d1d68: f9087278    	str	x24, [x19, #0x10e0]
1005d1d6c: f84a03e9    	ldur	x9, [sp, #0xa0]
1005d1d70: 53001d2d    	uxtb	w13, w9
1005d1d74: f9087e6d    	str	x13, [x19, #0x10f8]
1005d1d78: f925c66b    	str	x11, [x19, #0x4b88]
1005d1d7c: f925ca63    	str	x3, [x19, #0x4b90]
1005d1d80: f925ce64    	str	x4, [x19, #0x4b98]
1005d1d84: f927ba74    	str	x20, [x19, #0x4f70]
1005d1d88: f927be7b    	str	x27, [x19, #0x4f78]
1005d1d8c: f927da79    	str	x25, [x19, #0x4fb0]
1005d1d90: f927de78    	str	x24, [x19, #0x4fb8]
1005d1d94: f9280279    	str	x25, [x19, #0x5000]
1005d1d98: f928067c    	str	x28, [x19, #0x5008]
1005d1d9c: f9280a78    	str	x24, [x19, #0x5010]
1005d1da0: f9283a79    	str	x25, [x19, #0x5070]
1005d1da4: f9283e7c    	str	x28, [x19, #0x5078]
1005d1da8: f9284277    	str	x23, [x19, #0x5080]
1005d1dac: f9284678    	str	x24, [x19, #0x5088]
1005d1db0: f9288279    	str	x25, [x19, #0x5100]
1005d1db4: f928867c    	str	x28, [x19, #0x5108]
1005d1db8: f9288a77    	str	x23, [x19, #0x5110]
1005d1dbc: f9288e76    	str	x22, [x19, #0x5118]
1005d1dc0: f9289278    	str	x24, [x19, #0x5120]
1005d1dc4: f84783f5    	ldur	x21, [sp, #0x78]
1005d1dc8: f928ee75    	str	x21, [x19, #0x51d8]
1005d1dcc: f84083f5    	ldur	x21, [sp, #0x8]
1005d1dd0: f928fe75    	str	x21, [x19, #0x51f8]
1005d1dd4: f9294262    	str	x2, [x19, #0x5280]
1005d1dd8: f84203ed    	ldur	x13, [sp, #0x20]
1005d1ddc: f929466d    	str	x13, [x19, #0x5288]
1005d1de0: f84283ee    	ldur	x14, [sp, #0x28]
1005d1de4: f9294a6e    	str	x14, [x19, #0x5290]
1005d1de8: f84103e1    	ldur	x1, [sp, #0x10]
1005d1dec: cb030020    	sub	x0, x1, x3
1005d1df0: d29e9381    	mov	x1, #0xf49c             ; =62620
1005d1df4: 9b018040    	msub	x0, x2, x1, x0
1005d1df8: f9294e60    	str	x0, [x19, #0x5298]
1005d1dfc: f84303e5    	ldur	x5, [sp, #0x30]
1005d1e00: f9295265    	str	x5, [x19, #0x52a0]
1005d1e04: f84383e9    	ldur	x9, [sp, #0x38]
1005d1e08: f9295669    	str	x9, [x19, #0x52a8]
1005d1e0c: f84403ef    	ldur	x15, [sp, #0x40]
1005d1e10: f9295e6f    	str	x15, [x19, #0x52b8]
1005d1e14: f84483e8    	ldur	x8, [sp, #0x48]
1005d1e18: f9296268    	str	x8, [x19, #0x52c0]
1005d1e1c: f84503ed    	ldur	x13, [sp, #0x50]
1005d1e20: f9296a6d    	str	x13, [x19, #0x52d0]
1005d1e24: f84583e1    	ldur	x1, [sp, #0x58]
1005d1e28: f9296e61    	str	x1, [x19, #0x52d8]
1005d1e2c: aa0a03e6    	mov	x6, x10
1005d1e30: f9297666    	str	x6, [x19, #0x52e8]
1005d1e34: aa0703ee    	mov	x14, x7
1005d1e38: f9297a6e    	str	x14, [x19, #0x52f0]
1005d1e3c: f965c660    	ldr	x0, [x19, #0x4b88]
1005d1e40: f100001f    	cmp	x0, #0x0
1005d1e44: 54000c80    	b.eq	0x1005d1fd4 <_mech_canonical_program_entry_v1_numeric_801+0x1654>
1005d1e48: f965ca63    	ldr	x3, [x19, #0x4b90]
1005d1e4c: f965ce64    	ldr	x4, [x19, #0x4b98]
1005d1e50: d2800000    	mov	x0, #0x0                ; =0
1005d1e54: f925c660    	str	x0, [x19, #0x4b88]
1005d1e58: d2800060    	mov	x0, #0x3                ; =3
1005d1e5c: f94093e5    	ldr	x5, [sp, #0x120]
1005d1e60: f80983e0    	stur	x0, [sp, #0x98]
1005d1e64: f101d0bf    	cmp	x5, #0x74
1005d1e68: 5401ab03    	b.lo	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d1e6c: f967ba60    	ldr	x0, [x19, #0x4f70]
1005d1e70: f94097e1    	ldr	x1, [sp, #0x128]
1005d1e74: f9000820    	str	x0, [x1, #0x10]
1005d1e78: f967be61    	ldr	x1, [x19, #0x4f78]
1005d1e7c: f94097e2    	ldr	x2, [sp, #0x128]
1005d1e80: f9000c41    	str	x1, [x2, #0x18]
1005d1e84: f968ee62    	ldr	x2, [x19, #0x51d8]
1005d1e88: f94097e5    	ldr	x5, [sp, #0x128]
1005d1e8c: f9013ca2    	str	x2, [x5, #0x278]
1005d1e90: f968fe62    	ldr	x2, [x19, #0x51f8]
1005d1e94: f9014ca2    	str	x2, [x5, #0x298]
1005d1e98: f94097e2    	ldr	x2, [sp, #0x128]
1005d1e9c: f9000840    	str	x0, [x2, #0x10]
1005d1ea0: f9000c41    	str	x1, [x2, #0x18]
1005d1ea4: f967da60    	ldr	x0, [x19, #0x4fb0]
1005d1ea8: f90028a0    	str	x0, [x5, #0x50]
1005d1eac: f967de60    	ldr	x0, [x19, #0x4fb8]
1005d1eb0: f94097e7    	ldr	x7, [sp, #0x128]
1005d1eb4: f9002ce0    	str	x0, [x7, #0x58]
1005d1eb8: f9680260    	ldr	x0, [x19, #0x5000]
1005d1ebc: f94097ea    	ldr	x10, [sp, #0x128]
1005d1ec0: f9005140    	str	x0, [x10, #0xa0]
1005d1ec4: f9680660    	ldr	x0, [x19, #0x5008]
1005d1ec8: f94097ed    	ldr	x13, [sp, #0x128]
1005d1ecc: f90055a0    	str	x0, [x13, #0xa8]
1005d1ed0: f9680a61    	ldr	x1, [x19, #0x5010]
1005d1ed4: f94097e0    	ldr	x0, [sp, #0x128]
1005d1ed8: f9005801    	str	x1, [x0, #0xb0]
1005d1edc: f9683a62    	ldr	x2, [x19, #0x5070]
1005d1ee0: f9008802    	str	x2, [x0, #0x110]
1005d1ee4: f9683e65    	ldr	x5, [x19, #0x5078]
1005d1ee8: f9008c05    	str	x5, [x0, #0x118]
1005d1eec: f9684265    	ldr	x5, [x19, #0x5080]
1005d1ef0: f9009005    	str	x5, [x0, #0x120]
1005d1ef4: f9684665    	ldr	x5, [x19, #0x5088]
1005d1ef8: f9009405    	str	x5, [x0, #0x128]
1005d1efc: f9688266    	ldr	x6, [x19, #0x5100]
1005d1f00: f900d006    	str	x6, [x0, #0x1a0]
1005d1f04: f9688667    	ldr	x7, [x19, #0x5108]
1005d1f08: f900d407    	str	x7, [x0, #0x1a8]
1005d1f0c: f9688a68    	ldr	x8, [x19, #0x5110]
1005d1f10: f900d808    	str	x8, [x0, #0x1b0]
1005d1f14: f9688e69    	ldr	x9, [x19, #0x5118]
1005d1f18: f900dc09    	str	x9, [x0, #0x1b8]
1005d1f1c: f968926a    	ldr	x10, [x19, #0x5120]
1005d1f20: f900e00a    	str	x10, [x0, #0x1c0]
1005d1f24: f969426b    	ldr	x11, [x19, #0x5280]
1005d1f28: f901900b    	str	x11, [x0, #0x320]
1005d1f2c: f969466c    	ldr	x12, [x19, #0x5288]
1005d1f30: f901940c    	str	x12, [x0, #0x328]
1005d1f34: f9694a6d    	ldr	x13, [x19, #0x5290]
1005d1f38: f901980d    	str	x13, [x0, #0x330]
1005d1f3c: f9694e6e    	ldr	x14, [x19, #0x5298]
1005d1f40: f9019c0e    	str	x14, [x0, #0x338]
1005d1f44: f969526f    	ldr	x15, [x19, #0x52a0]
1005d1f48: f901a00f    	str	x15, [x0, #0x340]
1005d1f4c: f9695660    	ldr	x0, [x19, #0x52a8]
1005d1f50: f94097e1    	ldr	x1, [sp, #0x128]
1005d1f54: f901a420    	str	x0, [x1, #0x348]
1005d1f58: d2800000    	mov	x0, #0x0                ; =0
1005d1f5c: f901a820    	str	x0, [x1, #0x350]
1005d1f60: f9695e61    	ldr	x1, [x19, #0x52b8]
1005d1f64: f94097e5    	ldr	x5, [sp, #0x128]
1005d1f68: f901aca1    	str	x1, [x5, #0x358]
1005d1f6c: f9696261    	ldr	x1, [x19, #0x52c0]
1005d1f70: f94097e7    	ldr	x7, [sp, #0x128]
1005d1f74: f901b0e1    	str	x1, [x7, #0x360]
1005d1f78: f94097e9    	ldr	x9, [sp, #0x128]
1005d1f7c: f901b520    	str	x0, [x9, #0x368]
1005d1f80: f9696a61    	ldr	x1, [x19, #0x52d0]
1005d1f84: f94097ec    	ldr	x12, [sp, #0x128]
1005d1f88: f901b981    	str	x1, [x12, #0x370]
1005d1f8c: f9696e61    	ldr	x1, [x19, #0x52d8]
1005d1f90: f94097ef    	ldr	x15, [sp, #0x128]
1005d1f94: f901bde1    	str	x1, [x15, #0x378]
1005d1f98: f94097e1    	ldr	x1, [sp, #0x128]
1005d1f9c: f901c020    	str	x0, [x1, #0x380]
1005d1fa0: f9697660    	ldr	x0, [x19, #0x52e8]
1005d1fa4: f901c420    	str	x0, [x1, #0x388]
1005d1fa8: f9697a60    	ldr	x0, [x19, #0x52f0]
1005d1fac: f901c820    	str	x0, [x1, #0x390]
1005d1fb0: d28070a1    	mov	x1, #0x385              ; =901
1005d1fb4: 92800102    	mov	x2, #-0x9               ; =-9
1005d1fb8: d2800025    	mov	x5, #0x1                ; =1
1005d1fbc: f84003e0    	ldur	x0, [sp]
1005d1fc0: f9409be6    	ldr	x6, [sp, #0x130]
1005d1fc4: f9409fe7    	ldr	x7, [sp, #0x138]
1005d1fc8: d63f00e0    	blr	x7
1005d1fcc: f100001f    	cmp	x0, #0x0
1005d1fd0: 5400a501    	b.ne	0x1005d3470 <_mech_canonical_program_entry_v1_numeric_801+0x2af0>
1005d1fd4: d2800000    	mov	x0, #0x0                ; =0
1005d1fd8: d28000a1    	mov	x1, #0x5                ; =5
1005d1fdc: 910503ff    	add	sp, sp, #0x140
1005d1fe0: a8c153f3    	ldp	x19, x20, [sp], #0x10
1005d1fe4: a8c15bf5    	ldp	x21, x22, [sp], #0x10
1005d1fe8: a8c163f7    	ldp	x23, x24, [sp], #0x10
1005d1fec: a8c16bf9    	ldp	x25, x26, [sp], #0x10
1005d1ff0: a8c173fb    	ldp	x27, x28, [sp], #0x10
1005d1ff4: a8c17bfd    	ldp	x29, x30, [sp], #0x10
1005d1ff8: d65f0fff    	retab
1005d1ffc: aa0a03e6    	mov	x6, x10
1005d2000: f84a03e9    	ldur	x9, [sp, #0xa0]
1005d2004: aa0703ee    	mov	x14, x7
1005d2008: eb1802df    	cmp	x22, x24
1005d200c: 9a9f27e7    	cset	x7, lo
1005d2010: eb1802df    	cmp	x22, x24
1005d2014: 54000103    	b.lo	0x1005d2034 <_mech_canonical_program_entry_v1_numeric_801+0x16b4>
1005d2018: 52834f81    	mov	w1, #0x1a7c             ; =6780
1005d201c: 72a00021    	movk	w1, #0x1, lsl #16
1005d2020: cb010063    	sub	x3, x3, x1
1005d2024: aa1603e1    	mov	x1, x22
1005d2028: f80603ec    	stur	x12, [sp, #0x60]
1005d202c: f80a03e9    	stur	x9, [sp, #0xa0]
1005d2030: 140002c0    	b	0x1005d2b30 <_mech_canonical_program_entry_v1_numeric_801+0x21b0>
1005d2034: f84f03e1    	ldur	x1, [sp, #0xf0]
1005d2038: eb01033f    	cmp	x25, x1
1005d203c: 54000f23    	b.lo	0x1005d2220 <_mech_canonical_program_entry_v1_numeric_801+0x18a0>
1005d2040: 1400050f    	b	0x1005d347c <_mech_canonical_program_entry_v1_numeric_801+0x2afc>
1005d2044: f965ca63    	ldr	x3, [x19, #0x4b90]
1005d2048: f965ce64    	ldr	x4, [x19, #0x4b98]
1005d204c: d2800000    	mov	x0, #0x0                ; =0
1005d2050: f925c660    	str	x0, [x19, #0x4b88]
1005d2054: d2800060    	mov	x0, #0x3                ; =3
1005d2058: f94093e5    	ldr	x5, [sp, #0x120]
1005d205c: f80983e0    	stur	x0, [sp, #0x98]
1005d2060: f101d0bf    	cmp	x5, #0x74
1005d2064: 54019b23    	b.lo	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d2068: f967ba60    	ldr	x0, [x19, #0x4f70]
1005d206c: f94097e1    	ldr	x1, [sp, #0x128]
1005d2070: f9000820    	str	x0, [x1, #0x10]
1005d2074: f967be61    	ldr	x1, [x19, #0x4f78]
1005d2078: f94097e2    	ldr	x2, [sp, #0x128]
1005d207c: f9000c41    	str	x1, [x2, #0x18]
1005d2080: f968ee62    	ldr	x2, [x19, #0x51d8]
1005d2084: f94097e5    	ldr	x5, [sp, #0x128]
1005d2088: f9013ca2    	str	x2, [x5, #0x278]
1005d208c: f968fe62    	ldr	x2, [x19, #0x51f8]
1005d2090: f9014ca2    	str	x2, [x5, #0x298]
1005d2094: f94097e2    	ldr	x2, [sp, #0x128]
1005d2098: f9000840    	str	x0, [x2, #0x10]
1005d209c: f94097e0    	ldr	x0, [sp, #0x128]
1005d20a0: f9000c01    	str	x1, [x0, #0x18]
1005d20a4: f967da65    	ldr	x5, [x19, #0x4fb0]
1005d20a8: f9002805    	str	x5, [x0, #0x50]
1005d20ac: f967de65    	ldr	x5, [x19, #0x4fb8]
1005d20b0: f9002c05    	str	x5, [x0, #0x58]
1005d20b4: f9680265    	ldr	x5, [x19, #0x5000]
1005d20b8: f9005005    	str	x5, [x0, #0xa0]
1005d20bc: f9680666    	ldr	x6, [x19, #0x5008]
1005d20c0: f9005406    	str	x6, [x0, #0xa8]
1005d20c4: f9680a67    	ldr	x7, [x19, #0x5010]
1005d20c8: f9005807    	str	x7, [x0, #0xb0]
1005d20cc: f9683a68    	ldr	x8, [x19, #0x5070]
1005d20d0: f9008808    	str	x8, [x0, #0x110]
1005d20d4: f9683e69    	ldr	x9, [x19, #0x5078]
1005d20d8: f9008c09    	str	x9, [x0, #0x118]
1005d20dc: f968426a    	ldr	x10, [x19, #0x5080]
1005d20e0: f94097e5    	ldr	x5, [sp, #0x128]
1005d20e4: f90090aa    	str	x10, [x5, #0x120]
1005d20e8: f968466b    	ldr	x11, [x19, #0x5088]
1005d20ec: f94097e6    	ldr	x6, [sp, #0x128]
1005d20f0: f90094cb    	str	x11, [x6, #0x128]
1005d20f4: f968826c    	ldr	x12, [x19, #0x5100]
1005d20f8: f94097e9    	ldr	x9, [sp, #0x128]
1005d20fc: f900d12c    	str	x12, [x9, #0x1a0]
1005d2100: f968866d    	ldr	x13, [x19, #0x5108]
1005d2104: f94097ec    	ldr	x12, [sp, #0x128]
1005d2108: f900d58d    	str	x13, [x12, #0x1a8]
1005d210c: f9688a6e    	ldr	x14, [x19, #0x5110]
1005d2110: f94097ef    	ldr	x15, [sp, #0x128]
1005d2114: f900d9ee    	str	x14, [x15, #0x1b0]
1005d2118: f9688e6f    	ldr	x15, [x19, #0x5118]
1005d211c: f900dc0f    	str	x15, [x0, #0x1b8]
1005d2120: f9689260    	ldr	x0, [x19, #0x5120]
1005d2124: f94097e1    	ldr	x1, [sp, #0x128]
1005d2128: f900e020    	str	x0, [x1, #0x1c0]
1005d212c: f9694260    	ldr	x0, [x19, #0x5280]
1005d2130: f9019020    	str	x0, [x1, #0x320]
1005d2134: f9694660    	ldr	x0, [x19, #0x5288]
1005d2138: f9019420    	str	x0, [x1, #0x328]
1005d213c: f9694a60    	ldr	x0, [x19, #0x5290]
1005d2140: f9019820    	str	x0, [x1, #0x330]
1005d2144: f9694e60    	ldr	x0, [x19, #0x5298]
1005d2148: f9019c20    	str	x0, [x1, #0x338]
1005d214c: f9695260    	ldr	x0, [x19, #0x52a0]
1005d2150: f901a020    	str	x0, [x1, #0x340]
1005d2154: f9695660    	ldr	x0, [x19, #0x52a8]
1005d2158: f901a420    	str	x0, [x1, #0x348]
1005d215c: d2800000    	mov	x0, #0x0                ; =0
1005d2160: f901a820    	str	x0, [x1, #0x350]
1005d2164: f9695e61    	ldr	x1, [x19, #0x52b8]
1005d2168: f901ac41    	str	x1, [x2, #0x358]
1005d216c: f9696261    	ldr	x1, [x19, #0x52c0]
1005d2170: f901b041    	str	x1, [x2, #0x360]
1005d2174: f94097e1    	ldr	x1, [sp, #0x128]
1005d2178: f901b420    	str	x0, [x1, #0x368]
1005d217c: f9696a61    	ldr	x1, [x19, #0x52d0]
1005d2180: f901b841    	str	x1, [x2, #0x370]
1005d2184: f9696e61    	ldr	x1, [x19, #0x52d8]
1005d2188: f901bc41    	str	x1, [x2, #0x378]
1005d218c: f94097e1    	ldr	x1, [sp, #0x128]
1005d2190: f901c020    	str	x0, [x1, #0x380]
1005d2194: f9697660    	ldr	x0, [x19, #0x52e8]
1005d2198: f901c420    	str	x0, [x1, #0x388]
1005d219c: f9697a60    	ldr	x0, [x19, #0x52f0]
1005d21a0: f901c820    	str	x0, [x1, #0x390]
1005d21a4: d28072e1    	mov	x1, #0x397              ; =919
1005d21a8: 92800102    	mov	x2, #-0x9               ; =-9
1005d21ac: f9409fe7    	ldr	x7, [sp, #0x138]
1005d21b0: f84003e0    	ldur	x0, [sp]
1005d21b4: f84c03e5    	ldur	x5, [sp, #0xc0]
1005d21b8: f9409be6    	ldr	x6, [sp, #0x130]
1005d21bc: d63f00e0    	blr	x7
1005d21c0: f100001f    	cmp	x0, #0x0
1005d21c4: 5400a221    	b.ne	0x1005d3608 <_mech_canonical_program_entry_v1_numeric_801+0x2c88>
1005d21c8: d2800060    	mov	x0, #0x3                ; =3
1005d21cc: f94093e5    	ldr	x5, [sp, #0x120]
1005d21d0: f80983e0    	stur	x0, [sp, #0x98]
1005d21d4: f10008bf    	cmp	x5, #0x2
1005d21d8: 54018f83    	b.lo	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d21dc: d2800005    	mov	x5, #0x0                ; =0
1005d21e0: f94097e3    	ldr	x3, [sp, #0x128]
1005d21e4: f9000065    	str	x5, [x3]
1005d21e8: f948da60    	ldr	x0, [x19, #0x11b0]
1005d21ec: f9000460    	str	x0, [x3, #0x8]
1005d21f0: d28072e1    	mov	x1, #0x397              ; =919
1005d21f4: f84003e0    	ldur	x0, [sp]
1005d21f8: f9409be6    	ldr	x6, [sp, #0x130]
1005d21fc: f9409fe7    	ldr	x7, [sp, #0x138]
1005d2200: f84c03e4    	ldur	x4, [sp, #0xc0]
1005d2204: aa0503e2    	mov	x2, x5
1005d2208: d63f00e0    	blr	x7
1005d220c: f100001f    	cmp	x0, #0x0
1005d2210: 5400a021    	b.ne	0x1005d3614 <_mech_canonical_program_entry_v1_numeric_801+0x2c94>
1005d2214: d2800060    	mov	x0, #0x3                ; =3
1005d2218: f80983e0    	stur	x0, [sp, #0x98]
1005d221c: 14000c6b    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d2220: f84f83ed    	ldur	x13, [sp, #0xf8]
1005d2224: f87979af    	ldr	x15, [x13, x25, lsl #3]
1005d2228: eb01039f    	cmp	x28, x1
1005d222c: 54000f83    	b.lo	0x1005d241c <_mech_canonical_program_entry_v1_numeric_801+0x1a9c>
1005d2230: 140004fc    	b	0x1005d3620 <_mech_canonical_program_entry_v1_numeric_801+0x2ca0>
1005d2234: f965ca63    	ldr	x3, [x19, #0x4b90]
1005d2238: f965ce64    	ldr	x4, [x19, #0x4b98]
1005d223c: d2800000    	mov	x0, #0x0                ; =0
1005d2240: f925c660    	str	x0, [x19, #0x4b88]
1005d2244: d2800060    	mov	x0, #0x3                ; =3
1005d2248: f94093e5    	ldr	x5, [sp, #0x120]
1005d224c: f80983e0    	stur	x0, [sp, #0x98]
1005d2250: f101d0bf    	cmp	x5, #0x74
1005d2254: 54018ba3    	b.lo	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d2258: f967ba60    	ldr	x0, [x19, #0x4f70]
1005d225c: f94097e2    	ldr	x2, [sp, #0x128]
1005d2260: f9000840    	str	x0, [x2, #0x10]
1005d2264: f967be61    	ldr	x1, [x19, #0x4f78]
1005d2268: f94097e5    	ldr	x5, [sp, #0x128]
1005d226c: f9000ca1    	str	x1, [x5, #0x18]
1005d2270: f968ee62    	ldr	x2, [x19, #0x51d8]
1005d2274: f94097e8    	ldr	x8, [sp, #0x128]
1005d2278: f9013d02    	str	x2, [x8, #0x278]
1005d227c: f968fe62    	ldr	x2, [x19, #0x51f8]
1005d2280: f94097eb    	ldr	x11, [sp, #0x128]
1005d2284: f9014d62    	str	x2, [x11, #0x298]
1005d2288: f94097ed    	ldr	x13, [sp, #0x128]
1005d228c: f90009a0    	str	x0, [x13, #0x10]
1005d2290: f94097ef    	ldr	x15, [sp, #0x128]
1005d2294: f9000de1    	str	x1, [x15, #0x18]
1005d2298: f967da61    	ldr	x1, [x19, #0x4fb0]
1005d229c: f94097e0    	ldr	x0, [sp, #0x128]
1005d22a0: f9002801    	str	x1, [x0, #0x50]
1005d22a4: f967de62    	ldr	x2, [x19, #0x4fb8]
1005d22a8: f9002c02    	str	x2, [x0, #0x58]
1005d22ac: f9680265    	ldr	x5, [x19, #0x5000]
1005d22b0: f9005005    	str	x5, [x0, #0xa0]
1005d22b4: f9680665    	ldr	x5, [x19, #0x5008]
1005d22b8: f9005405    	str	x5, [x0, #0xa8]
1005d22bc: f9680a65    	ldr	x5, [x19, #0x5010]
1005d22c0: f9005805    	str	x5, [x0, #0xb0]
1005d22c4: f9683a66    	ldr	x6, [x19, #0x5070]
1005d22c8: f9008806    	str	x6, [x0, #0x110]
1005d22cc: f9683e67    	ldr	x7, [x19, #0x5078]
1005d22d0: f9008c07    	str	x7, [x0, #0x118]
1005d22d4: f9684268    	ldr	x8, [x19, #0x5080]
1005d22d8: f9009008    	str	x8, [x0, #0x120]
1005d22dc: f9684669    	ldr	x9, [x19, #0x5088]
1005d22e0: f9009409    	str	x9, [x0, #0x128]
1005d22e4: f968826a    	ldr	x10, [x19, #0x5100]
1005d22e8: f900d00a    	str	x10, [x0, #0x1a0]
1005d22ec: f968866b    	ldr	x11, [x19, #0x5108]
1005d22f0: f900d40b    	str	x11, [x0, #0x1a8]
1005d22f4: f9688a6c    	ldr	x12, [x19, #0x5110]
1005d22f8: f900d80c    	str	x12, [x0, #0x1b0]
1005d22fc: f9688e6d    	ldr	x13, [x19, #0x5118]
1005d2300: f900dc0d    	str	x13, [x0, #0x1b8]
1005d2304: f968926e    	ldr	x14, [x19, #0x5120]
1005d2308: f900e00e    	str	x14, [x0, #0x1c0]
1005d230c: f969426f    	ldr	x15, [x19, #0x5280]
1005d2310: f901900f    	str	x15, [x0, #0x320]
1005d2314: f9694660    	ldr	x0, [x19, #0x5288]
1005d2318: f94097e1    	ldr	x1, [sp, #0x128]
1005d231c: f9019420    	str	x0, [x1, #0x328]
1005d2320: f9694a60    	ldr	x0, [x19, #0x5290]
1005d2324: f94097e5    	ldr	x5, [sp, #0x128]
1005d2328: f90198a0    	str	x0, [x5, #0x330]
1005d232c: f9694e60    	ldr	x0, [x19, #0x5298]
1005d2330: f94097e6    	ldr	x6, [sp, #0x128]
1005d2334: f9019cc0    	str	x0, [x6, #0x338]
1005d2338: f9695260    	ldr	x0, [x19, #0x52a0]
1005d233c: f94097e9    	ldr	x9, [sp, #0x128]
1005d2340: f901a120    	str	x0, [x9, #0x340]
1005d2344: f9695660    	ldr	x0, [x19, #0x52a8]
1005d2348: f94097ec    	ldr	x12, [sp, #0x128]
1005d234c: f901a580    	str	x0, [x12, #0x348]
1005d2350: d2800000    	mov	x0, #0x0                ; =0
1005d2354: f94097ef    	ldr	x15, [sp, #0x128]
1005d2358: f901a9e0    	str	x0, [x15, #0x350]
1005d235c: f9695e61    	ldr	x1, [x19, #0x52b8]
1005d2360: f94097e2    	ldr	x2, [sp, #0x128]
1005d2364: f901ac41    	str	x1, [x2, #0x358]
1005d2368: f9696261    	ldr	x1, [x19, #0x52c0]
1005d236c: f901b041    	str	x1, [x2, #0x360]
1005d2370: f94097e1    	ldr	x1, [sp, #0x128]
1005d2374: f901b420    	str	x0, [x1, #0x368]
1005d2378: f9696a61    	ldr	x1, [x19, #0x52d0]
1005d237c: f901b841    	str	x1, [x2, #0x370]
1005d2380: f9696e61    	ldr	x1, [x19, #0x52d8]
1005d2384: f901bc41    	str	x1, [x2, #0x378]
1005d2388: f94097e1    	ldr	x1, [sp, #0x128]
1005d238c: f901c020    	str	x0, [x1, #0x380]
1005d2390: f9697660    	ldr	x0, [x19, #0x52e8]
1005d2394: f901c420    	str	x0, [x1, #0x388]
1005d2398: f9697a60    	ldr	x0, [x19, #0x52f0]
1005d239c: f901c820    	str	x0, [x1, #0x390]
1005d23a0: d2807321    	mov	x1, #0x399              ; =921
1005d23a4: 92800102    	mov	x2, #-0x9               ; =-9
1005d23a8: f9409fe7    	ldr	x7, [sp, #0x138]
1005d23ac: f84003e0    	ldur	x0, [sp]
1005d23b0: f84c03e5    	ldur	x5, [sp, #0xc0]
1005d23b4: f9409be6    	ldr	x6, [sp, #0x130]
1005d23b8: d63f00e0    	blr	x7
1005d23bc: f100001f    	cmp	x0, #0x0
1005d23c0: 54009f81    	b.ne	0x1005d37b0 <_mech_canonical_program_entry_v1_numeric_801+0x2e30>
1005d23c4: d2800060    	mov	x0, #0x3                ; =3
1005d23c8: f94093e5    	ldr	x5, [sp, #0x120]
1005d23cc: f80983e0    	stur	x0, [sp, #0x98]
1005d23d0: f10008bf    	cmp	x5, #0x2
1005d23d4: 54017fa3    	b.lo	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d23d8: d2800005    	mov	x5, #0x0                ; =0
1005d23dc: f94097e3    	ldr	x3, [sp, #0x128]
1005d23e0: f9000065    	str	x5, [x3]
1005d23e4: f948e260    	ldr	x0, [x19, #0x11c0]
1005d23e8: f9000460    	str	x0, [x3, #0x8]
1005d23ec: d2807321    	mov	x1, #0x399              ; =921
1005d23f0: f84003e0    	ldur	x0, [sp]
1005d23f4: f9409be6    	ldr	x6, [sp, #0x130]
1005d23f8: f9409fe7    	ldr	x7, [sp, #0x138]
1005d23fc: f84c03e4    	ldur	x4, [sp, #0xc0]
1005d2400: aa0503e2    	mov	x2, x5
1005d2404: d63f00e0    	blr	x7
1005d2408: f100001f    	cmp	x0, #0x0
1005d240c: 54009d81    	b.ne	0x1005d37bc <_mech_canonical_program_entry_v1_numeric_801+0x2e3c>
1005d2410: d2800060    	mov	x0, #0x3                ; =3
1005d2414: f80983e0    	stur	x0, [sp, #0x98]
1005d2418: 14000bec    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d241c: f87c79aa    	ldr	x10, [x13, x28, lsl #3]
1005d2420: eb0102ff    	cmp	x23, x1
1005d2424: 54000fa3    	b.lo	0x1005d2618 <_mech_canonical_program_entry_v1_numeric_801+0x1c98>
1005d2428: 140004e8    	b	0x1005d37c8 <_mech_canonical_program_entry_v1_numeric_801+0x2e48>
1005d242c: f965ca63    	ldr	x3, [x19, #0x4b90]
1005d2430: f965ce64    	ldr	x4, [x19, #0x4b98]
1005d2434: d2800000    	mov	x0, #0x0                ; =0
1005d2438: f925c660    	str	x0, [x19, #0x4b88]
1005d243c: d2800060    	mov	x0, #0x3                ; =3
1005d2440: f94093e5    	ldr	x5, [sp, #0x120]
1005d2444: f80983e0    	stur	x0, [sp, #0x98]
1005d2448: f101d0bf    	cmp	x5, #0x74
1005d244c: 54017be3    	b.lo	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d2450: f967ba60    	ldr	x0, [x19, #0x4f70]
1005d2454: f94097e1    	ldr	x1, [sp, #0x128]
1005d2458: f9000820    	str	x0, [x1, #0x10]
1005d245c: f967be61    	ldr	x1, [x19, #0x4f78]
1005d2460: f94097e2    	ldr	x2, [sp, #0x128]
1005d2464: f9000c41    	str	x1, [x2, #0x18]
1005d2468: f968ee62    	ldr	x2, [x19, #0x51d8]
1005d246c: f94097e5    	ldr	x5, [sp, #0x128]
1005d2470: f9013ca2    	str	x2, [x5, #0x278]
1005d2474: f968fe62    	ldr	x2, [x19, #0x51f8]
1005d2478: f9014ca2    	str	x2, [x5, #0x298]
1005d247c: f94097e2    	ldr	x2, [sp, #0x128]
1005d2480: f9000840    	str	x0, [x2, #0x10]
1005d2484: f94097e0    	ldr	x0, [sp, #0x128]
1005d2488: f9000c01    	str	x1, [x0, #0x18]
1005d248c: f967da60    	ldr	x0, [x19, #0x4fb0]
1005d2490: f94097e1    	ldr	x1, [sp, #0x128]
1005d2494: f9002820    	str	x0, [x1, #0x50]
1005d2498: f967de61    	ldr	x1, [x19, #0x4fb8]
1005d249c: f94097e0    	ldr	x0, [sp, #0x128]
1005d24a0: f9002c01    	str	x1, [x0, #0x58]
1005d24a4: f9680262    	ldr	x2, [x19, #0x5000]
1005d24a8: f9005002    	str	x2, [x0, #0xa0]
1005d24ac: f9680665    	ldr	x5, [x19, #0x5008]
1005d24b0: f94097e1    	ldr	x1, [sp, #0x128]
1005d24b4: f9005425    	str	x5, [x1, #0xa8]
1005d24b8: f9680a65    	ldr	x5, [x19, #0x5010]
1005d24bc: f94097e6    	ldr	x6, [sp, #0x128]
1005d24c0: f90058c5    	str	x5, [x6, #0xb0]
1005d24c4: f9683a65    	ldr	x5, [x19, #0x5070]
1005d24c8: f94097e7    	ldr	x7, [sp, #0x128]
1005d24cc: f90088e5    	str	x5, [x7, #0x110]
1005d24d0: f9683e66    	ldr	x6, [x19, #0x5078]
1005d24d4: f94097ea    	ldr	x10, [sp, #0x128]
1005d24d8: f9008d46    	str	x6, [x10, #0x118]
1005d24dc: f9684267    	ldr	x7, [x19, #0x5080]
1005d24e0: f94097ed    	ldr	x13, [sp, #0x128]
1005d24e4: f90091a7    	str	x7, [x13, #0x120]
1005d24e8: f9684668    	ldr	x8, [x19, #0x5088]
1005d24ec: f9009408    	str	x8, [x0, #0x128]
1005d24f0: f9688269    	ldr	x9, [x19, #0x5100]
1005d24f4: f900d009    	str	x9, [x0, #0x1a0]
1005d24f8: f968866a    	ldr	x10, [x19, #0x5108]
1005d24fc: f900d40a    	str	x10, [x0, #0x1a8]
1005d2500: f9688a6b    	ldr	x11, [x19, #0x5110]
1005d2504: f900d80b    	str	x11, [x0, #0x1b0]
1005d2508: f9688e6c    	ldr	x12, [x19, #0x5118]
1005d250c: f900dc0c    	str	x12, [x0, #0x1b8]
1005d2510: f968926d    	ldr	x13, [x19, #0x5120]
1005d2514: f900e00d    	str	x13, [x0, #0x1c0]
1005d2518: f969426e    	ldr	x14, [x19, #0x5280]
1005d251c: f901900e    	str	x14, [x0, #0x320]
1005d2520: f969466f    	ldr	x15, [x19, #0x5288]
1005d2524: f901940f    	str	x15, [x0, #0x328]
1005d2528: f9694a60    	ldr	x0, [x19, #0x5290]
1005d252c: f9019820    	str	x0, [x1, #0x330]
1005d2530: f9694e60    	ldr	x0, [x19, #0x5298]
1005d2534: f9019c20    	str	x0, [x1, #0x338]
1005d2538: f9695260    	ldr	x0, [x19, #0x52a0]
1005d253c: f901a020    	str	x0, [x1, #0x340]
1005d2540: f9695660    	ldr	x0, [x19, #0x52a8]
1005d2544: f901a420    	str	x0, [x1, #0x348]
1005d2548: d2800000    	mov	x0, #0x0                ; =0
1005d254c: f901a820    	str	x0, [x1, #0x350]
1005d2550: f9695e61    	ldr	x1, [x19, #0x52b8]
1005d2554: f94097e2    	ldr	x2, [sp, #0x128]
1005d2558: f901ac41    	str	x1, [x2, #0x358]
1005d255c: f9696261    	ldr	x1, [x19, #0x52c0]
1005d2560: f901b041    	str	x1, [x2, #0x360]
1005d2564: f94097e1    	ldr	x1, [sp, #0x128]
1005d2568: f901b420    	str	x0, [x1, #0x368]
1005d256c: f9696a61    	ldr	x1, [x19, #0x52d0]
1005d2570: f901b841    	str	x1, [x2, #0x370]
1005d2574: f9696e61    	ldr	x1, [x19, #0x52d8]
1005d2578: f94097e5    	ldr	x5, [sp, #0x128]
1005d257c: f901bca1    	str	x1, [x5, #0x378]
1005d2580: f901c0a0    	str	x0, [x5, #0x380]
1005d2584: f9697660    	ldr	x0, [x19, #0x52e8]
1005d2588: f94097e8    	ldr	x8, [sp, #0x128]
1005d258c: f901c500    	str	x0, [x8, #0x388]
1005d2590: f9697a60    	ldr	x0, [x19, #0x52f0]
1005d2594: f94097eb    	ldr	x11, [sp, #0x128]
1005d2598: f901c960    	str	x0, [x11, #0x390]
1005d259c: d2807361    	mov	x1, #0x39b              ; =923
1005d25a0: 92800102    	mov	x2, #-0x9               ; =-9
1005d25a4: f9409fe7    	ldr	x7, [sp, #0x138]
1005d25a8: f84003e0    	ldur	x0, [sp]
1005d25ac: f84c03e5    	ldur	x5, [sp, #0xc0]
1005d25b0: f9409be6    	ldr	x6, [sp, #0x130]
1005d25b4: d63f00e0    	blr	x7
1005d25b8: f100001f    	cmp	x0, #0x0
1005d25bc: 54009d01    	b.ne	0x1005d395c <_mech_canonical_program_entry_v1_numeric_801+0x2fdc>
1005d25c0: d2800060    	mov	x0, #0x3                ; =3
1005d25c4: f94093e5    	ldr	x5, [sp, #0x120]
1005d25c8: f80983e0    	stur	x0, [sp, #0x98]
1005d25cc: f10008bf    	cmp	x5, #0x2
1005d25d0: 54016fc3    	b.lo	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d25d4: d2800005    	mov	x5, #0x0                ; =0
1005d25d8: f94097e3    	ldr	x3, [sp, #0x128]
1005d25dc: f9000065    	str	x5, [x3]
1005d25e0: f948ea60    	ldr	x0, [x19, #0x11d0]
1005d25e4: f9000460    	str	x0, [x3, #0x8]
1005d25e8: d2807361    	mov	x1, #0x39b              ; =923
1005d25ec: f84003e0    	ldur	x0, [sp]
1005d25f0: f9409be6    	ldr	x6, [sp, #0x130]
1005d25f4: f9409fe7    	ldr	x7, [sp, #0x138]
1005d25f8: f84c03e4    	ldur	x4, [sp, #0xc0]
1005d25fc: aa0503e2    	mov	x2, x5
1005d2600: d63f00e0    	blr	x7
1005d2604: f100001f    	cmp	x0, #0x0
1005d2608: 54009b01    	b.ne	0x1005d3968 <_mech_canonical_program_entry_v1_numeric_801+0x2fe8>
1005d260c: d2800060    	mov	x0, #0x3                ; =3
1005d2610: f80983e0    	stur	x0, [sp, #0x98]
1005d2614: 14000b6d    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d2618: f87779a8    	ldr	x8, [x13, x23, lsl #3]
1005d261c: eb0102df    	cmp	x22, x1
1005d2620: f80f03e1    	stur	x1, [sp, #0xf0]
1005d2624: 54000f63    	b.lo	0x1005d2810 <_mech_canonical_program_entry_v1_numeric_801+0x1e90>
1005d2628: 140004d3    	b	0x1005d3974 <_mech_canonical_program_entry_v1_numeric_801+0x2ff4>
1005d262c: f965ca63    	ldr	x3, [x19, #0x4b90]
1005d2630: f965ce64    	ldr	x4, [x19, #0x4b98]
1005d2634: d2800000    	mov	x0, #0x0                ; =0
1005d2638: f925c660    	str	x0, [x19, #0x4b88]
1005d263c: d2800060    	mov	x0, #0x3                ; =3
1005d2640: f94093e5    	ldr	x5, [sp, #0x120]
1005d2644: f80983e0    	stur	x0, [sp, #0x98]
1005d2648: f101d0bf    	cmp	x5, #0x74
1005d264c: 54016be3    	b.lo	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d2650: f967ba60    	ldr	x0, [x19, #0x4f70]
1005d2654: f94097ef    	ldr	x15, [sp, #0x128]
1005d2658: f90009e0    	str	x0, [x15, #0x10]
1005d265c: f967be61    	ldr	x1, [x19, #0x4f78]
1005d2660: f94097e2    	ldr	x2, [sp, #0x128]
1005d2664: f9000c41    	str	x1, [x2, #0x18]
1005d2668: f968ee62    	ldr	x2, [x19, #0x51d8]
1005d266c: f94097e5    	ldr	x5, [sp, #0x128]
1005d2670: f9013ca2    	str	x2, [x5, #0x278]
1005d2674: f968fe62    	ldr	x2, [x19, #0x51f8]
1005d2678: f9014ca2    	str	x2, [x5, #0x298]
1005d267c: f94097e2    	ldr	x2, [sp, #0x128]
1005d2680: f9000840    	str	x0, [x2, #0x10]
1005d2684: f94097e0    	ldr	x0, [sp, #0x128]
1005d2688: f9000c01    	str	x1, [x0, #0x18]
1005d268c: f967da60    	ldr	x0, [x19, #0x4fb0]
1005d2690: f94097e1    	ldr	x1, [sp, #0x128]
1005d2694: f9002820    	str	x0, [x1, #0x50]
1005d2698: f967de61    	ldr	x1, [x19, #0x4fb8]
1005d269c: f94097e0    	ldr	x0, [sp, #0x128]
1005d26a0: f9002c01    	str	x1, [x0, #0x58]
1005d26a4: f9680262    	ldr	x2, [x19, #0x5000]
1005d26a8: f9005002    	str	x2, [x0, #0xa0]
1005d26ac: f9680665    	ldr	x5, [x19, #0x5008]
1005d26b0: f9005405    	str	x5, [x0, #0xa8]
1005d26b4: f9680a65    	ldr	x5, [x19, #0x5010]
1005d26b8: f9005805    	str	x5, [x0, #0xb0]
1005d26bc: f9683a65    	ldr	x5, [x19, #0x5070]
1005d26c0: f9008805    	str	x5, [x0, #0x110]
1005d26c4: f9683e66    	ldr	x6, [x19, #0x5078]
1005d26c8: f9008c06    	str	x6, [x0, #0x118]
1005d26cc: f9684267    	ldr	x7, [x19, #0x5080]
1005d26d0: f9009007    	str	x7, [x0, #0x120]
1005d26d4: f9684668    	ldr	x8, [x19, #0x5088]
1005d26d8: f9009408    	str	x8, [x0, #0x128]
1005d26dc: f9688269    	ldr	x9, [x19, #0x5100]
1005d26e0: f900d009    	str	x9, [x0, #0x1a0]
1005d26e4: f968866a    	ldr	x10, [x19, #0x5108]
1005d26e8: f900d40a    	str	x10, [x0, #0x1a8]
1005d26ec: f9688a6b    	ldr	x11, [x19, #0x5110]
1005d26f0: f94097e1    	ldr	x1, [sp, #0x128]
1005d26f4: f900d82b    	str	x11, [x1, #0x1b0]
1005d26f8: f9688e6c    	ldr	x12, [x19, #0x5118]
1005d26fc: f94097e5    	ldr	x5, [sp, #0x128]
1005d2700: f900dcac    	str	x12, [x5, #0x1b8]
1005d2704: f968926d    	ldr	x13, [x19, #0x5120]
1005d2708: f94097e7    	ldr	x7, [sp, #0x128]
1005d270c: f900e0ed    	str	x13, [x7, #0x1c0]
1005d2710: f969426e    	ldr	x14, [x19, #0x5280]
1005d2714: f94097ea    	ldr	x10, [sp, #0x128]
1005d2718: f901914e    	str	x14, [x10, #0x320]
1005d271c: f969466f    	ldr	x15, [x19, #0x5288]
1005d2720: f94097ed    	ldr	x13, [sp, #0x128]
1005d2724: f90195af    	str	x15, [x13, #0x328]
1005d2728: f9694a60    	ldr	x0, [x19, #0x5290]
1005d272c: f9019820    	str	x0, [x1, #0x330]
1005d2730: f9694e60    	ldr	x0, [x19, #0x5298]
1005d2734: f9019c20    	str	x0, [x1, #0x338]
1005d2738: f9695260    	ldr	x0, [x19, #0x52a0]
1005d273c: f901a020    	str	x0, [x1, #0x340]
1005d2740: f9695660    	ldr	x0, [x19, #0x52a8]
1005d2744: f901a420    	str	x0, [x1, #0x348]
1005d2748: d2800000    	mov	x0, #0x0                ; =0
1005d274c: f901a820    	str	x0, [x1, #0x350]
1005d2750: f9695e61    	ldr	x1, [x19, #0x52b8]
1005d2754: f94097e2    	ldr	x2, [sp, #0x128]
1005d2758: f901ac41    	str	x1, [x2, #0x358]
1005d275c: f9696261    	ldr	x1, [x19, #0x52c0]
1005d2760: f901b041    	str	x1, [x2, #0x360]
1005d2764: f94097e1    	ldr	x1, [sp, #0x128]
1005d2768: f901b420    	str	x0, [x1, #0x368]
1005d276c: f9696a61    	ldr	x1, [x19, #0x52d0]
1005d2770: f901b841    	str	x1, [x2, #0x370]
1005d2774: f9696e61    	ldr	x1, [x19, #0x52d8]
1005d2778: f901bc41    	str	x1, [x2, #0x378]
1005d277c: f94097e1    	ldr	x1, [sp, #0x128]
1005d2780: f901c020    	str	x0, [x1, #0x380]
1005d2784: f9697660    	ldr	x0, [x19, #0x52e8]
1005d2788: f901c420    	str	x0, [x1, #0x388]
1005d278c: f9697a60    	ldr	x0, [x19, #0x52f0]
1005d2790: f901c820    	str	x0, [x1, #0x390]
1005d2794: d28073a1    	mov	x1, #0x39d              ; =925
1005d2798: 92800102    	mov	x2, #-0x9               ; =-9
1005d279c: f9409fe7    	ldr	x7, [sp, #0x138]
1005d27a0: f84003e0    	ldur	x0, [sp]
1005d27a4: f84c03e5    	ldur	x5, [sp, #0xc0]
1005d27a8: f9409be6    	ldr	x6, [sp, #0x130]
1005d27ac: d63f00e0    	blr	x7
1005d27b0: f100001f    	cmp	x0, #0x0
1005d27b4: 54009ac1    	b.ne	0x1005d3b0c <_mech_canonical_program_entry_v1_numeric_801+0x318c>
1005d27b8: d2800060    	mov	x0, #0x3                ; =3
1005d27bc: f94093e5    	ldr	x5, [sp, #0x120]
1005d27c0: f80983e0    	stur	x0, [sp, #0x98]
1005d27c4: f10008bf    	cmp	x5, #0x2
1005d27c8: 54016003    	b.lo	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d27cc: d2800005    	mov	x5, #0x0                ; =0
1005d27d0: f94097e3    	ldr	x3, [sp, #0x128]
1005d27d4: f9000065    	str	x5, [x3]
1005d27d8: f948f260    	ldr	x0, [x19, #0x11e0]
1005d27dc: f9000460    	str	x0, [x3, #0x8]
1005d27e0: d28073a1    	mov	x1, #0x39d              ; =925
1005d27e4: f84003e0    	ldur	x0, [sp]
1005d27e8: f9409be6    	ldr	x6, [sp, #0x130]
1005d27ec: f9409fe7    	ldr	x7, [sp, #0x138]
1005d27f0: f84c03e4    	ldur	x4, [sp, #0xc0]
1005d27f4: aa0503e2    	mov	x2, x5
1005d27f8: d63f00e0    	blr	x7
1005d27fc: f100001f    	cmp	x0, #0x0
1005d2800: 540098c1    	b.ne	0x1005d3b18 <_mech_canonical_program_entry_v1_numeric_801+0x3198>
1005d2804: d2800060    	mov	x0, #0x3                ; =3
1005d2808: f80983e0    	stur	x0, [sp, #0x98]
1005d280c: 14000aef    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d2810: f87679a5    	ldr	x5, [x13, x22, lsl #3]
1005d2814: f80f83ed    	stur	x13, [sp, #0xf8]
1005d2818: f100015f    	cmp	x10, #0x0
1005d281c: 54009840    	b.eq	0x1005d3b24 <_mech_canonical_program_entry_v1_numeric_801+0x31a4>
1005d2820: d1000541    	sub	x1, x10, #0x1
1005d2824: 9bc17d4d    	umulh	x13, x10, x1
1005d2828: f10001bf    	cmp	x13, #0x0
1005d282c: 5400a241    	b.ne	0x1005d3c74 <_mech_canonical_program_entry_v1_numeric_801+0x32f4>
1005d2830: 9b017d41    	mul	x1, x10, x1
1005d2834: d341fc21    	lsr	x1, x1, #1
1005d2838: 8b0101ea    	add	x10, x15, x1
1005d283c: eb0f015f    	cmp	x10, x15
1005d2840: 5400ac43    	b.lo	0x1005d3dc8 <_mech_canonical_program_entry_v1_numeric_801+0x3448>
1005d2844: f100011f    	cmp	x8, #0x0
1005d2848: 5400b680    	b.eq	0x1005d3f18 <_mech_canonical_program_entry_v1_numeric_801+0x3598>
1005d284c: d100050f    	sub	x15, x8, #0x1
1005d2850: 9bcf7d0d    	umulh	x13, x8, x15
1005d2854: f10001bf    	cmp	x13, #0x0
1005d2858: 5400c061    	b.ne	0x1005d4064 <_mech_canonical_program_entry_v1_numeric_801+0x36e4>
1005d285c: f100091f    	cmp	x8, #0x2
1005d2860: 5400caa3    	b.lo	0x1005d41b4 <_mech_canonical_program_entry_v1_numeric_801+0x3834>
1005d2864: 9b0f7d01    	mul	x1, x8, x15
1005d2868: d100090d    	sub	x13, x8, #0x2
1005d286c: 9bcd7c2d    	umulh	x13, x1, x13
1005d2870: f10001bf    	cmp	x13, #0x0
1005d2874: 5400d481    	b.ne	0x1005d4304 <_mech_canonical_program_entry_v1_numeric_801+0x3984>
1005d2878: d1000908    	sub	x8, x8, #0x2
1005d287c: 9b087c21    	mul	x1, x1, x8
1005d2880: d2955568    	mov	x8, #0xaaab             ; =43691
1005d2884: f2b55548    	movk	x8, #0xaaaa, lsl #16
1005d2888: f2d55548    	movk	x8, #0xaaaa, lsl #32
1005d288c: f2f55548    	movk	x8, #0xaaaa, lsl #48
1005d2890: 9bc87c21    	umulh	x1, x1, x8
1005d2894: d342fc21    	lsr	x1, x1, #2
1005d2898: 8b010148    	add	x8, x10, x1
1005d289c: eb0a011f    	cmp	x8, x10
1005d28a0: 5400ddc3    	b.lo	0x1005d4458 <_mech_canonical_program_entry_v1_numeric_801+0x3ad8>
1005d28a4: f10000bf    	cmp	x5, #0x0
1005d28a8: 5400e7e0    	b.eq	0x1005d45a4 <_mech_canonical_program_entry_v1_numeric_801+0x3c24>
1005d28ac: d10004aa    	sub	x10, x5, #0x1
1005d28b0: 9bca7ca1    	umulh	x1, x5, x10
1005d28b4: f100003f    	cmp	x1, #0x0
1005d28b8: 5400f1a1    	b.ne	0x1005d46ec <_mech_canonical_program_entry_v1_numeric_801+0x3d6c>
1005d28bc: f10008bf    	cmp	x5, #0x2
1005d28c0: 5400fbc3    	b.lo	0x1005d4838 <_mech_canonical_program_entry_v1_numeric_801+0x3eb8>
1005d28c4: 9b0a7caa    	mul	x10, x5, x10
1005d28c8: d10008ad    	sub	x13, x5, #0x2
1005d28cc: 9bcd7d4d    	umulh	x13, x10, x13
1005d28d0: f10001bf    	cmp	x13, #0x0
1005d28d4: 540105a1    	b.ne	0x1005d4988 <_mech_canonical_program_entry_v1_numeric_801+0x4008>
1005d28d8: f10008bf    	cmp	x5, #0x2
1005d28dc: 54010fe9    	b.ls	0x1005d4ad8 <_mech_canonical_program_entry_v1_numeric_801+0x4158>
1005d28e0: d10008a1    	sub	x1, x5, #0x2
1005d28e4: 9b017d41    	mul	x1, x10, x1
1005d28e8: d1000ca5    	sub	x5, x5, #0x3
1005d28ec: 9bc57c2a    	umulh	x10, x1, x5
1005d28f0: f100015f    	cmp	x10, #0x0
1005d28f4: 540119a1    	b.ne	0x1005d4c28 <_mech_canonical_program_entry_v1_numeric_801+0x42a8>
1005d28f8: 9b057c21    	mul	x1, x1, x5
1005d28fc: d2955565    	mov	x5, #0xaaab             ; =43691
1005d2900: f2b55545    	movk	x5, #0xaaaa, lsl #16
1005d2904: f2d55545    	movk	x5, #0xaaaa, lsl #32
1005d2908: f2f55545    	movk	x5, #0xaaaa, lsl #48
1005d290c: 9bc57c21    	umulh	x1, x1, x5
1005d2910: d344fc21    	lsr	x1, x1, #4
1005d2914: 8b01010a    	add	x10, x8, x1
1005d2918: eb08015f    	cmp	x10, x8
1005d291c: 540122c3    	b.lo	0x1005d4d74 <_mech_canonical_program_entry_v1_numeric_801+0x43f4>
1005d2920: f80a03e9    	stur	x9, [sp, #0xa0]
1005d2924: f84683ed    	ldur	x13, [sp, #0x68]
1005d2928: b5000eed    	cbnz	x13, 0x1005d2b04 <_mech_canonical_program_entry_v1_numeric_801+0x2184>
1005d292c: 14000964    	b	0x1005d4ebc <_mech_canonical_program_entry_v1_numeric_801+0x453c>
1005d2930: f94097e0    	ldr	x0, [sp, #0x128]
1005d2934: f9000814    	str	x20, [x0, #0x10]
1005d2938: f9000c1b    	str	x27, [x0, #0x18]
1005d293c: f9000814    	str	x20, [x0, #0x10]
1005d2940: f94097e1    	ldr	x1, [sp, #0x128]
1005d2944: f9000c3b    	str	x27, [x1, #0x18]
1005d2948: f94097e5    	ldr	x5, [sp, #0x128]
1005d294c: f90028b9    	str	x25, [x5, #0x50]
1005d2950: f9002cb8    	str	x24, [x5, #0x58]
1005d2954: f94097e7    	ldr	x7, [sp, #0x128]
1005d2958: f90050f9    	str	x25, [x7, #0xa0]
1005d295c: f94097e9    	ldr	x9, [sp, #0x128]
1005d2960: f900553c    	str	x28, [x9, #0xa8]
1005d2964: f94097eb    	ldr	x11, [sp, #0x128]
1005d2968: f9005978    	str	x24, [x11, #0xb0]
1005d296c: f94097ed    	ldr	x13, [sp, #0x128]
1005d2970: f90089b9    	str	x25, [x13, #0x110]
1005d2974: f94097ef    	ldr	x15, [sp, #0x128]
1005d2978: f9008dfc    	str	x28, [x15, #0x118]
1005d297c: f9009017    	str	x23, [x0, #0x120]
1005d2980: f9009418    	str	x24, [x0, #0x128]
1005d2984: f900d019    	str	x25, [x0, #0x1a0]
1005d2988: f900d41c    	str	x28, [x0, #0x1a8]
1005d298c: f900d817    	str	x23, [x0, #0x1b0]
1005d2990: f900dc16    	str	x22, [x0, #0x1b8]
1005d2994: f900e018    	str	x24, [x0, #0x1c0]
1005d2998: f9019002    	str	x2, [x0, #0x320]
1005d299c: f84203ed    	ldur	x13, [sp, #0x20]
1005d29a0: f901940d    	str	x13, [x0, #0x328]
1005d29a4: f84283e0    	ldur	x0, [sp, #0x28]
1005d29a8: f9019820    	str	x0, [x1, #0x330]
1005d29ac: 52834f80    	mov	w0, #0x1a7c             ; =6780
1005d29b0: 72a00020    	movk	w0, #0x1, lsl #16
1005d29b4: cb000063    	sub	x3, x3, x0
1005d29b8: f84103e1    	ldur	x1, [sp, #0x10]
1005d29bc: cb030020    	sub	x0, x1, x3
1005d29c0: d29e9381    	mov	x1, #0xf49c             ; =62620
1005d29c4: 9b018040    	msub	x0, x2, x1, x0
1005d29c8: f94097e1    	ldr	x1, [sp, #0x128]
1005d29cc: f9019c20    	str	x0, [x1, #0x338]
1005d29d0: f94097e0    	ldr	x0, [sp, #0x128]
1005d29d4: f84303e5    	ldur	x5, [sp, #0x30]
1005d29d8: f901a005    	str	x5, [x0, #0x340]
1005d29dc: f84383e9    	ldur	x9, [sp, #0x38]
1005d29e0: f901a409    	str	x9, [x0, #0x348]
1005d29e4: d2800005    	mov	x5, #0x0                ; =0
1005d29e8: f901a805    	str	x5, [x0, #0x350]
1005d29ec: f84403ef    	ldur	x15, [sp, #0x40]
1005d29f0: f901ac0f    	str	x15, [x0, #0x358]
1005d29f4: f84483e8    	ldur	x8, [sp, #0x48]
1005d29f8: f901b008    	str	x8, [x0, #0x360]
1005d29fc: f901b405    	str	x5, [x0, #0x368]
1005d2a00: f84503ed    	ldur	x13, [sp, #0x50]
1005d2a04: f901b80d    	str	x13, [x0, #0x370]
1005d2a08: f84583e1    	ldur	x1, [sp, #0x58]
1005d2a0c: f901bc01    	str	x1, [x0, #0x378]
1005d2a10: f901c005    	str	x5, [x0, #0x380]
1005d2a14: f94097e1    	ldr	x1, [sp, #0x128]
1005d2a18: f901c426    	str	x6, [x1, #0x388]
1005d2a1c: f94097e6    	ldr	x6, [sp, #0x128]
1005d2a20: f901c8ce    	str	x14, [x6, #0x390]
1005d2a24: f84083e0    	ldur	x0, [sp, #0x8]
1005d2a28: 91000407    	add	x7, x0, #0x1
1005d2a2c: f901d0c7    	str	x7, [x6, #0x3a0]
1005d2a30: f94097e8    	ldr	x8, [sp, #0x128]
1005d2a34: f901d50a    	str	x10, [x8, #0x3a8]
1005d2a38: d2807601    	mov	x1, #0x3b0              ; =944
1005d2a3c: 92800342    	mov	x2, #-0x1b              ; =-27
1005d2a40: f9409fe7    	ldr	x7, [sp, #0x138]
1005d2a44: f84003e0    	ldur	x0, [sp]
1005d2a48: f9409be6    	ldr	x6, [sp, #0x130]
1005d2a4c: d63f00e0    	blr	x7
1005d2a50: f100001f    	cmp	x0, #0x0
1005d2a54: 54012481    	b.ne	0x1005d4ee4 <_mech_canonical_program_entry_v1_numeric_801+0x4564>
1005d2a58: f94097e3    	ldr	x3, [sp, #0x128]
1005d2a5c: f9400063    	ldr	x3, [x3]
1005d2a60: f94097e0    	ldr	x0, [sp, #0x128]
1005d2a64: f9400404    	ldr	x4, [x0, #0x8]
1005d2a68: f941480f    	ldr	x15, [x0, #0x290]
1005d2a6c: f9417c0d    	ldr	x13, [x0, #0x2f8]
1005d2a70: f80683ed    	stur	x13, [sp, #0x68]
1005d2a74: f9414c0d    	ldr	x13, [x0, #0x298]
1005d2a78: f80083ed    	stur	x13, [sp, #0x8]
1005d2a7c: f941500c    	ldr	x12, [x0, #0x2a0]
1005d2a80: f941540c    	ldr	x12, [x0, #0x2a8]
1005d2a84: f9418c0c    	ldr	x12, [x0, #0x318]
1005d2a88: f80603ec    	stur	x12, [sp, #0x60]
1005d2a8c: f9419002    	ldr	x2, [x0, #0x320]
1005d2a90: f941940d    	ldr	x13, [x0, #0x328]
1005d2a94: f80203ed    	stur	x13, [sp, #0x20]
1005d2a98: f941980e    	ldr	x14, [x0, #0x330]
1005d2a9c: f80283ee    	stur	x14, [sp, #0x28]
1005d2aa0: f9419c0c    	ldr	x12, [x0, #0x338]
1005d2aa4: f941a005    	ldr	x5, [x0, #0x340]
1005d2aa8: f80303e5    	stur	x5, [sp, #0x30]
1005d2aac: f941a409    	ldr	x9, [x0, #0x348]
1005d2ab0: f80383e9    	stur	x9, [sp, #0x38]
1005d2ab4: f941ac05    	ldr	x5, [x0, #0x358]
1005d2ab8: f80403e5    	stur	x5, [sp, #0x40]
1005d2abc: f941b008    	ldr	x8, [x0, #0x360]
1005d2ac0: f80483e8    	stur	x8, [sp, #0x48]
1005d2ac4: f941b80d    	ldr	x13, [x0, #0x370]
1005d2ac8: f80503ed    	stur	x13, [sp, #0x50]
1005d2acc: f941bc01    	ldr	x1, [x0, #0x378]
1005d2ad0: f80583e1    	stur	x1, [sp, #0x58]
1005d2ad4: f941c406    	ldr	x6, [x0, #0x388]
1005d2ad8: f941c80e    	ldr	x14, [x0, #0x390]
1005d2adc: f9400800    	ldr	x0, [x0, #0x10]
1005d2ae0: d280002b    	mov	x11, #0x1               ; =1
1005d2ae4: f925c66b    	str	x11, [x19, #0x4b88]
1005d2ae8: 8b0c006d    	add	x13, x3, x12
1005d2aec: d29e9381    	mov	x1, #0xf49c             ; =62620
1005d2af0: 9b013441    	madd	x1, x2, x1, x13
1005d2af4: f80103e1    	stur	x1, [sp, #0x10]
1005d2af8: aa1603e1    	mov	x1, x22
1005d2afc: f80703ef    	stur	x15, [sp, #0x70]
1005d2b00: 1400000c    	b	0x1005d2b30 <_mech_canonical_program_entry_v1_numeric_801+0x21b0>
1005d2b04: f84083e1    	ldur	x1, [sp, #0x8]
1005d2b08: f84703ef    	ldur	x15, [sp, #0x70]
1005d2b0c: f80603ec    	stur	x12, [sp, #0x60]
1005d2b10: f80683ed    	stur	x13, [sp, #0x68]
1005d2b14: f82179ea    	str	x10, [x15, x1, lsl #3]
1005d2b18: 91000421    	add	x1, x1, #0x1
1005d2b1c: f80083e1    	stur	x1, [sp, #0x8]
1005d2b20: 52834f8f    	mov	w15, #0x1a7c            ; =6780
1005d2b24: 72a0002f    	movk	w15, #0x1, lsl #16
1005d2b28: cb0f0063    	sub	x3, x3, x15
1005d2b2c: aa1603e1    	mov	x1, x22
1005d2b30: eb1802df    	cmp	x22, x24
1005d2b34: 54001f63    	b.lo	0x1005d2f20 <_mech_canonical_program_entry_v1_numeric_801+0x25a0>
1005d2b38: d2800001    	mov	x1, #0x0                ; =0
1005d2b3c: f9058001    	str	x1, [x0, #0xb00]
1005d2b40: f9058401    	str	x1, [x0, #0xb08]
1005d2b44: f9058801    	str	x1, [x0, #0xb10]
1005d2b48: f9058c01    	str	x1, [x0, #0xb18]
1005d2b4c: f9059001    	str	x1, [x0, #0xb20]
1005d2b50: f9059401    	str	x1, [x0, #0xb28]
1005d2b54: f9059801    	str	x1, [x0, #0xb30]
1005d2b58: f9059c01    	str	x1, [x0, #0xb38]
1005d2b5c: f905a001    	str	x1, [x0, #0xb40]
1005d2b60: f905a401    	str	x1, [x0, #0xb48]
1005d2b64: d280000e    	mov	x14, #0x0               ; =0
1005d2b68: aa0e03ed    	mov	x13, x14
1005d2b6c: f84a83e5    	ldur	x5, [sp, #0xa8]
1005d2b70: eb1800bf    	cmp	x5, x24
1005d2b74: 54001be3    	b.lo	0x1005d2ef0 <_mech_canonical_program_entry_v1_numeric_801+0x2570>
1005d2b78: d2800001    	mov	x1, #0x0                ; =0
1005d2b7c: f904f001    	str	x1, [x0, #0x9e0]
1005d2b80: f904f401    	str	x1, [x0, #0x9e8]
1005d2b84: f904f801    	str	x1, [x0, #0x9f0]
1005d2b88: f904fc01    	str	x1, [x0, #0x9f8]
1005d2b8c: f9050001    	str	x1, [x0, #0xa00]
1005d2b90: f9050401    	str	x1, [x0, #0xa08]
1005d2b94: f9050801    	str	x1, [x0, #0xa10]
1005d2b98: f9050c01    	str	x1, [x0, #0xa18]
1005d2b9c: d2800009    	mov	x9, #0x0                ; =0
1005d2ba0: aa0903f7    	mov	x23, x9
1005d2ba4: f84b83e1    	ldur	x1, [sp, #0xb8]
1005d2ba8: eb18003f    	cmp	x1, x24
1005d2bac: 540018c3    	b.lo	0x1005d2ec4 <_mech_canonical_program_entry_v1_numeric_801+0x2544>
1005d2bb0: d2800005    	mov	x5, #0x0                ; =0
1005d2bb4: f9048005    	str	x5, [x0, #0x900]
1005d2bb8: f9048405    	str	x5, [x0, #0x908]
1005d2bbc: f9048805    	str	x5, [x0, #0x910]
1005d2bc0: f9048c05    	str	x5, [x0, #0x918]
1005d2bc4: f9049005    	str	x5, [x0, #0x920]
1005d2bc8: f9049405    	str	x5, [x0, #0x928]
1005d2bcc: d2800008    	mov	x8, #0x0                ; =0
1005d2bd0: aa0803fc    	mov	x28, x8
1005d2bd4: f84d83e1    	ldur	x1, [sp, #0xd8]
1005d2bd8: eb18003f    	cmp	x1, x24
1005d2bdc: 540015c3    	b.lo	0x1005d2e94 <_mech_canonical_program_entry_v1_numeric_801+0x2514>
1005d2be0: d2800001    	mov	x1, #0x0                ; =0
1005d2be4: f9043001    	str	x1, [x0, #0x860]
1005d2be8: f9043401    	str	x1, [x0, #0x868]
1005d2bec: f9043801    	str	x1, [x0, #0x870]
1005d2bf0: f9043c01    	str	x1, [x0, #0x878]
1005d2bf4: d280000c    	mov	x12, #0x0               ; =0
1005d2bf8: aa0c03ea    	mov	x10, x12
1005d2bfc: aa1403f5    	mov	x21, x20
1005d2c00: aa1403f6    	mov	x22, x20
1005d2c04: eb1b029f    	cmp	x20, x27
1005d2c08: 54000083    	b.lo	0x1005d2c18 <_mech_canonical_program_entry_v1_numeric_801+0x2298>
1005d2c0c: f84903e7    	ldur	x7, [sp, #0x90]
1005d2c10: f84883ef    	ldur	x15, [sp, #0x88]
1005d2c14: 14000064    	b	0x1005d2da4 <_mech_canonical_program_entry_v1_numeric_801+0x2424>
1005d2c18: f84883ef    	ldur	x15, [sp, #0x88]
1005d2c1c: b5000b6f    	cbnz	x15, 0x1005d2d88 <_mech_canonical_program_entry_v1_numeric_801+0x2408>
1005d2c20: 140008b4    	b	0x1005d4ef0 <_mech_canonical_program_entry_v1_numeric_801+0x4570>
1005d2c24: f94097e0    	ldr	x0, [sp, #0x128]
1005d2c28: f9000815    	str	x21, [x0, #0x10]
1005d2c2c: f9000c1b    	str	x27, [x0, #0x18]
1005d2c30: f9000815    	str	x21, [x0, #0x10]
1005d2c34: f9000c1b    	str	x27, [x0, #0x18]
1005d2c38: f9019002    	str	x2, [x0, #0x320]
1005d2c3c: f84203e0    	ldur	x0, [sp, #0x20]
1005d2c40: f94097e1    	ldr	x1, [sp, #0x128]
1005d2c44: f9019420    	str	x0, [x1, #0x328]
1005d2c48: f94097e0    	ldr	x0, [sp, #0x128]
1005d2c4c: f84283ef    	ldur	x15, [sp, #0x28]
1005d2c50: f901980f    	str	x15, [x0, #0x330]
1005d2c54: f84103e1    	ldur	x1, [sp, #0x10]
1005d2c58: cb030020    	sub	x0, x1, x3
1005d2c5c: d29e9381    	mov	x1, #0xf49c             ; =62620
1005d2c60: 9b018040    	msub	x0, x2, x1, x0
1005d2c64: f94097e1    	ldr	x1, [sp, #0x128]
1005d2c68: f9019c20    	str	x0, [x1, #0x338]
1005d2c6c: f94097e0    	ldr	x0, [sp, #0x128]
1005d2c70: f901a00c    	str	x12, [x0, #0x340]
1005d2c74: f901a42a    	str	x10, [x1, #0x348]
1005d2c78: d2800005    	mov	x5, #0x0                ; =0
1005d2c7c: f94097e6    	ldr	x6, [sp, #0x128]
1005d2c80: f901a8c5    	str	x5, [x6, #0x350]
1005d2c84: f901acc8    	str	x8, [x6, #0x358]
1005d2c88: f94097e8    	ldr	x8, [sp, #0x128]
1005d2c8c: f901b11c    	str	x28, [x8, #0x360]
1005d2c90: f94097ea    	ldr	x10, [sp, #0x128]
1005d2c94: f901b545    	str	x5, [x10, #0x368]
1005d2c98: f94097ec    	ldr	x12, [sp, #0x128]
1005d2c9c: f901b989    	str	x9, [x12, #0x370]
1005d2ca0: f94097ef    	ldr	x15, [sp, #0x128]
1005d2ca4: f901bdf7    	str	x23, [x15, #0x378]
1005d2ca8: f901c005    	str	x5, [x0, #0x380]
1005d2cac: f901c40e    	str	x14, [x0, #0x388]
1005d2cb0: f901c80d    	str	x13, [x0, #0x390]
1005d2cb4: f84783e0    	ldur	x0, [sp, #0x78]
1005d2cb8: 91000400    	add	x0, x0, #0x1
1005d2cbc: f901d020    	str	x0, [x1, #0x3a0]
1005d2cc0: f84083e0    	ldur	x0, [sp, #0x8]
1005d2cc4: f901d420    	str	x0, [x1, #0x3a8]
1005d2cc8: d2807f41    	mov	x1, #0x3fa              ; =1018
1005d2ccc: 92800342    	mov	x2, #-0x1b              ; =-27
1005d2cd0: f9409fe7    	ldr	x7, [sp, #0x138]
1005d2cd4: f84003e0    	ldur	x0, [sp]
1005d2cd8: f9409be6    	ldr	x6, [sp, #0x130]
1005d2cdc: d63f00e0    	blr	x7
1005d2ce0: d2800041    	mov	x1, #0x2                ; =2
1005d2ce4: f80983e1    	stur	x1, [sp, #0x98]
1005d2ce8: f100001f    	cmp	x0, #0x0
1005d2cec: 540136e1    	b.ne	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d2cf0: f94097e3    	ldr	x3, [sp, #0x128]
1005d2cf4: f9400063    	ldr	x3, [x3]
1005d2cf8: f94097e0    	ldr	x0, [sp, #0x128]
1005d2cfc: f9400404    	ldr	x4, [x0, #0x8]
1005d2d00: f9413807    	ldr	x7, [x0, #0x270]
1005d2d04: f941780f    	ldr	x15, [x0, #0x2f0]
1005d2d08: f9413c08    	ldr	x8, [x0, #0x278]
1005d2d0c: f80783e8    	stur	x8, [sp, #0x78]
1005d2d10: f9414002    	ldr	x2, [x0, #0x280]
1005d2d14: f9414402    	ldr	x2, [x0, #0x288]
1005d2d18: f9418800    	ldr	x0, [x0, #0x310]
1005d2d1c: f80803e0    	stur	x0, [sp, #0x80]
1005d2d20: f94097e0    	ldr	x0, [sp, #0x128]
1005d2d24: f9419002    	ldr	x2, [x0, #0x320]
1005d2d28: f941940d    	ldr	x13, [x0, #0x328]
1005d2d2c: f80203ed    	stur	x13, [sp, #0x20]
1005d2d30: f941980e    	ldr	x14, [x0, #0x330]
1005d2d34: f80283ee    	stur	x14, [sp, #0x28]
1005d2d38: f9419c05    	ldr	x5, [x0, #0x338]
1005d2d3c: f941a00c    	ldr	x12, [x0, #0x340]
1005d2d40: f941a40a    	ldr	x10, [x0, #0x348]
1005d2d44: f941ac08    	ldr	x8, [x0, #0x358]
1005d2d48: f94097e1    	ldr	x1, [sp, #0x128]
1005d2d4c: f941b03c    	ldr	x28, [x1, #0x360]
1005d2d50: f94097e6    	ldr	x6, [sp, #0x128]
1005d2d54: f941b8c9    	ldr	x9, [x6, #0x370]
1005d2d58: f941bcd7    	ldr	x23, [x6, #0x378]
1005d2d5c: f94097eb    	ldr	x11, [sp, #0x128]
1005d2d60: f941c56e    	ldr	x14, [x11, #0x388]
1005d2d64: f941c96d    	ldr	x13, [x11, #0x390]
1005d2d68: f9400960    	ldr	x0, [x11, #0x10]
1005d2d6c: d280002b    	mov	x11, #0x1               ; =1
1005d2d70: f925c66b    	str	x11, [x19, #0x4b88]
1005d2d74: 8b050065    	add	x5, x3, x5
1005d2d78: d29e9386    	mov	x6, #0xf49c             ; =62620
1005d2d7c: 9b061441    	madd	x1, x2, x6, x5
1005d2d80: f80103e1    	stur	x1, [sp, #0x10]
1005d2d84: 14000008    	b	0x1005d2da4 <_mech_canonical_program_entry_v1_numeric_801+0x2424>
1005d2d88: f84083e1    	ldur	x1, [sp, #0x8]
1005d2d8c: f84783e5    	ldur	x5, [sp, #0x78]
1005d2d90: f84903e7    	ldur	x7, [sp, #0x90]
1005d2d94: f82578e1    	str	x1, [x7, x5, lsl #3]
1005d2d98: f84783e1    	ldur	x1, [sp, #0x78]
1005d2d9c: 91000421    	add	x1, x1, #0x1
1005d2da0: f80783e1    	stur	x1, [sp, #0x78]
1005d2da4: eb1b029f    	cmp	x20, x27
1005d2da8: 540005e3    	b.lo	0x1005d2e64 <_mech_canonical_program_entry_v1_numeric_801+0x24e4>
1005d2dac: d2800020    	mov	x0, #0x1                ; =1
1005d2db0: f9001a60    	str	x0, [x19, #0x30]
1005d2db4: d2800041    	mov	x1, #0x2                ; =2
1005d2db8: f9002261    	str	x1, [x19, #0x40]
1005d2dbc: d2800061    	mov	x1, #0x3                ; =3
1005d2dc0: f9002661    	str	x1, [x19, #0x48]
1005d2dc4: d2800001    	mov	x1, #0x0                ; =0
1005d2dc8: f900c661    	str	x1, [x19, #0x188]
1005d2dcc: f900ca60    	str	x0, [x19, #0x190]
1005d2dd0: f925c66b    	str	x11, [x19, #0x4b88]
1005d2dd4: f925ca63    	str	x3, [x19, #0x4b90]
1005d2dd8: f925ce64    	str	x4, [x19, #0x4b98]
1005d2ddc: f927ba75    	str	x21, [x19, #0x4f70]
1005d2de0: f927be7b    	str	x27, [x19, #0x4f78]
1005d2de4: f84783f5    	ldur	x21, [sp, #0x78]
1005d2de8: f928ee75    	str	x21, [x19, #0x51d8]
1005d2dec: f84083f5    	ldur	x21, [sp, #0x8]
1005d2df0: f928fe75    	str	x21, [x19, #0x51f8]
1005d2df4: f9294262    	str	x2, [x19, #0x5280]
1005d2df8: f84203e4    	ldur	x4, [sp, #0x20]
1005d2dfc: f9294664    	str	x4, [x19, #0x5288]
1005d2e00: f84283e0    	ldur	x0, [sp, #0x28]
1005d2e04: f9294a60    	str	x0, [x19, #0x5290]
1005d2e08: f84103e1    	ldur	x1, [sp, #0x10]
1005d2e0c: cb030020    	sub	x0, x1, x3
1005d2e10: d29e9381    	mov	x1, #0xf49c             ; =62620
1005d2e14: 9b018040    	msub	x0, x2, x1, x0
1005d2e18: f9294e60    	str	x0, [x19, #0x5298]
1005d2e1c: f929526c    	str	x12, [x19, #0x52a0]
1005d2e20: f929566a    	str	x10, [x19, #0x52a8]
1005d2e24: f9295e68    	str	x8, [x19, #0x52b8]
1005d2e28: f929627c    	str	x28, [x19, #0x52c0]
1005d2e2c: f9296a69    	str	x9, [x19, #0x52d0]
1005d2e30: f9296e77    	str	x23, [x19, #0x52d8]
1005d2e34: f929766e    	str	x14, [x19, #0x52e8]
1005d2e38: f9297a6d    	str	x13, [x19, #0x52f0]
1005d2e3c: d2800000    	mov	x0, #0x0                ; =0
1005d2e40: d2800021    	mov	x1, #0x1                ; =1
1005d2e44: 910503ff    	add	sp, sp, #0x140
1005d2e48: a8c153f3    	ldp	x19, x20, [sp], #0x10
1005d2e4c: a8c15bf5    	ldp	x21, x22, [sp], #0x10
1005d2e50: a8c163f7    	ldp	x23, x24, [sp], #0x10
1005d2e54: a8c16bf9    	ldp	x25, x26, [sp], #0x10
1005d2e58: a8c173fb    	ldp	x27, x28, [sp], #0x10
1005d2e5c: a8c17bfd    	ldp	x29, x30, [sp], #0x10
1005d2e60: d65f0fff    	retab
1005d2e64: 910006d4    	add	x20, x22, #0x1
1005d2e68: eb16029f    	cmp	x20, x22
1005d2e6c: 54010563    	b.lo	0x1005d4f18 <_mech_canonical_program_entry_v1_numeric_801+0x4598>
1005d2e70: d2800021    	mov	x1, #0x1                ; =1
1005d2e74: f80283e1    	stur	x1, [sp, #0x28]
1005d2e78: f80903e7    	stur	x7, [sp, #0x90]
1005d2e7c: f80883ef    	stur	x15, [sp, #0x88]
1005d2e80: f80183e4    	stur	x4, [sp, #0x18]
1005d2e84: aa1a03f6    	mov	x22, x26
1005d2e88: aa1303e7    	mov	x7, x19
1005d2e8c: f84283e6    	ldur	x6, [sp, #0x28]
1005d2e90: 17fff75d    	b	0x1005d0c04 <_mech_canonical_program_entry_v1_numeric_801+0x284>
1005d2e94: f84903e7    	ldur	x7, [sp, #0x90]
1005d2e98: f84883ef    	ldur	x15, [sp, #0x88]
1005d2e9c: 91000721    	add	x1, x25, #0x1
1005d2ea0: eb19003f    	cmp	x1, x25
1005d2ea4: 54010943    	b.lo	0x1005d4fcc <_mech_canonical_program_entry_v1_numeric_801+0x464c>
1005d2ea8: d2800025    	mov	x5, #0x1                ; =1
1005d2eac: f80383e5    	stur	x5, [sp, #0x38]
1005d2eb0: aa0103f9    	mov	x25, x1
1005d2eb4: f80183e4    	stur	x4, [sp, #0x18]
1005d2eb8: f80883ef    	stur	x15, [sp, #0x88]
1005d2ebc: f80903e7    	stur	x7, [sp, #0x90]
1005d2ec0: 17fff917    	b	0x1005d131c <_mech_canonical_program_entry_v1_numeric_801+0x99c>
1005d2ec4: f84903e7    	ldur	x7, [sp, #0x90]
1005d2ec8: f84883ef    	ldur	x15, [sp, #0x88]
1005d2ecc: 91000781    	add	x1, x28, #0x1
1005d2ed0: eb1c003f    	cmp	x1, x28
1005d2ed4: 54010e43    	b.lo	0x1005d509c <_mech_canonical_program_entry_v1_numeric_801+0x471c>
1005d2ed8: d2800028    	mov	x8, #0x1                ; =1
1005d2edc: f80483e8    	stur	x8, [sp, #0x48]
1005d2ee0: aa0103fc    	mov	x28, x1
1005d2ee4: f80883ef    	stur	x15, [sp, #0x88]
1005d2ee8: f80903e7    	stur	x7, [sp, #0x90]
1005d2eec: 17fff9d0    	b	0x1005d162c <_mech_canonical_program_entry_v1_numeric_801+0xcac>
1005d2ef0: f84903e7    	ldur	x7, [sp, #0x90]
1005d2ef4: f84883ef    	ldur	x15, [sp, #0x88]
1005d2ef8: 910006e1    	add	x1, x23, #0x1
1005d2efc: eb17003f    	cmp	x1, x23
1005d2f00: 54011463    	b.lo	0x1005d518c <_mech_canonical_program_entry_v1_numeric_801+0x480c>
1005d2f04: d2800025    	mov	x5, #0x1                ; =1
1005d2f08: f80583e5    	stur	x5, [sp, #0x58]
1005d2f0c: aa1503e6    	mov	x6, x21
1005d2f10: aa0103f7    	mov	x23, x1
1005d2f14: f80883ef    	stur	x15, [sp, #0x88]
1005d2f18: f80903e7    	stur	x7, [sp, #0x90]
1005d2f1c: 17fffa8f    	b	0x1005d1958 <_mech_canonical_program_entry_v1_numeric_801+0xfd8>
1005d2f20: f84903e7    	ldur	x7, [sp, #0x90]
1005d2f24: f84883ef    	ldur	x15, [sp, #0x88]
1005d2f28: 91000436    	add	x22, x1, #0x1
1005d2f2c: eb0102df    	cmp	x22, x1
1005d2f30: 54011b63    	b.lo	0x1005d529c <_mech_canonical_program_entry_v1_numeric_801+0x491c>
1005d2f34: f84a03e5    	ldur	x5, [sp, #0xa0]
1005d2f38: d280002e    	mov	x14, #0x1               ; =1
1005d2f3c: f80a03e5    	stur	x5, [sp, #0xa0]
1005d2f40: f80903e7    	stur	x7, [sp, #0x90]
1005d2f44: f80883ef    	stur	x15, [sp, #0x88]
1005d2f48: aa0603ea    	mov	x10, x6
1005d2f4c: aa0e03e7    	mov	x7, x14
1005d2f50: 17fffb55    	b	0x1005d1ca4 <_mech_canonical_program_entry_v1_numeric_801+0x1324>
1005d2f54: f80983e0    	stur	x0, [sp, #0x98]
1005d2f58: 1400091c    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d2f5c: f80983e0    	stur	x0, [sp, #0x98]
1005d2f60: 1400091a    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d2f64: f80983e0    	stur	x0, [sp, #0x98]
1005d2f68: 14000918    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d2f6c: f80983e0    	stur	x0, [sp, #0x98]
1005d2f70: 14000916    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d2f74: d2806620    	mov	x0, #0x331              ; =817
1005d2f78: aa1603fa    	mov	x26, x22
1005d2f7c: f9002740    	str	x0, [x26, #0x48]
1005d2f80: d2800020    	mov	x0, #0x1                ; =1
1005d2f84: f9001a60    	str	x0, [x19, #0x30]
1005d2f88: d2800055    	mov	x21, #0x2               ; =2
1005d2f8c: f9002275    	str	x21, [x19, #0x40]
1005d2f90: d2800065    	mov	x5, #0x3                ; =3
1005d2f94: f9002665    	str	x5, [x19, #0x48]
1005d2f98: d28000c5    	mov	x5, #0x6                ; =6
1005d2f9c: f9003265    	str	x5, [x19, #0x60]
1005d2fa0: d2800305    	mov	x5, #0x18               ; =24
1005d2fa4: f9004265    	str	x5, [x19, #0x80]
1005d2fa8: d2800005    	mov	x5, #0x0                ; =0
1005d2fac: f900c665    	str	x5, [x19, #0x188]
1005d2fb0: f900ca60    	str	x0, [x19, #0x190]
1005d2fb4: f9078a74    	str	x20, [x19, #0xf10]
1005d2fb8: f9078e7b    	str	x27, [x19, #0xf18]
1005d2fbc: f84e03e0    	ldur	x0, [sp, #0xe0]
1005d2fc0: 53001c00    	uxtb	w0, w0
1005d2fc4: f9079a60    	str	x0, [x19, #0xf30]
1005d2fc8: 91000680    	add	x0, x20, #0x1
1005d2fcc: f907a260    	str	x0, [x19, #0xf40]
1005d2fd0: f925c66b    	str	x11, [x19, #0x4b88]
1005d2fd4: d29e9380    	mov	x0, #0xf49c             ; =62620
1005d2fd8: cb000063    	sub	x3, x3, x0
1005d2fdc: f925ca63    	str	x3, [x19, #0x4b90]
1005d2fe0: f925ce64    	str	x4, [x19, #0x4b98]
1005d2fe4: f927ba74    	str	x20, [x19, #0x4f70]
1005d2fe8: f927be7b    	str	x27, [x19, #0x4f78]
1005d2fec: f84783e4    	ldur	x4, [sp, #0x78]
1005d2ff0: f928ee64    	str	x4, [x19, #0x51d8]
1005d2ff4: f84083e4    	ldur	x4, [sp, #0x8]
1005d2ff8: f928fe64    	str	x4, [x19, #0x51f8]
1005d2ffc: 91000442    	add	x2, x2, #0x1
1005d3000: f9294262    	str	x2, [x19, #0x5280]
1005d3004: f84203e4    	ldur	x4, [sp, #0x20]
1005d3008: f9294664    	str	x4, [x19, #0x5288]
1005d300c: f9294a66    	str	x6, [x19, #0x5290]
1005d3010: f84103eb    	ldur	x11, [sp, #0x10]
1005d3014: cb030163    	sub	x3, x11, x3
1005d3018: 9b008c40    	msub	x0, x2, x0, x3
1005d301c: f9294e60    	str	x0, [x19, #0x5298]
1005d3020: f929526c    	str	x12, [x19, #0x52a0]
1005d3024: f929566a    	str	x10, [x19, #0x52a8]
1005d3028: f9295e68    	str	x8, [x19, #0x52b8]
1005d302c: f929627c    	str	x28, [x19, #0x52c0]
1005d3030: f9296a69    	str	x9, [x19, #0x52d0]
1005d3034: f9296e77    	str	x23, [x19, #0x52d8]
1005d3038: f929766e    	str	x14, [x19, #0x52e8]
1005d303c: f9297a6d    	str	x13, [x19, #0x52f0]
1005d3040: f965c662    	ldr	x2, [x19, #0x4b88]
1005d3044: f100005f    	cmp	x2, #0x0
1005d3048: 54fef4c1    	b.ne	0x1005d0ee0 <_mech_canonical_program_entry_v1_numeric_801+0x560>
1005d304c: 17fff7a2    	b	0x1005d0ed4 <_mech_canonical_program_entry_v1_numeric_801+0x554>
1005d3050: f80983e0    	stur	x0, [sp, #0x98]
1005d3054: 140008dd    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d3058: f80983f5    	stur	x21, [sp, #0x98]
1005d305c: 140008db    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d3060: f80983e0    	stur	x0, [sp, #0x98]
1005d3064: 140008d9    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d3068: f80983f5    	stur	x21, [sp, #0x98]
1005d306c: 140008d7    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d3070: d2806665    	mov	x5, #0x333              ; =819
1005d3074: f9002745    	str	x5, [x26, #0x48]
1005d3078: d2800025    	mov	x5, #0x1                ; =1
1005d307c: f9001a65    	str	x5, [x19, #0x30]
1005d3080: d2800055    	mov	x21, #0x2               ; =2
1005d3084: f9002275    	str	x21, [x19, #0x40]
1005d3088: d2800067    	mov	x7, #0x3                ; =3
1005d308c: f9002667    	str	x7, [x19, #0x48]
1005d3090: d28000cf    	mov	x15, #0x6               ; =6
1005d3094: f900326f    	str	x15, [x19, #0x60]
1005d3098: d280030f    	mov	x15, #0x18              ; =24
1005d309c: f900426f    	str	x15, [x19, #0x80]
1005d30a0: d280000f    	mov	x15, #0x0               ; =0
1005d30a4: f900c66f    	str	x15, [x19, #0x188]
1005d30a8: f900ca65    	str	x5, [x19, #0x190]
1005d30ac: f9078a74    	str	x20, [x19, #0xf10]
1005d30b0: f9078e7b    	str	x27, [x19, #0xf18]
1005d30b4: f84e03e5    	ldur	x5, [sp, #0xe0]
1005d30b8: 53001caf    	uxtb	w15, w5
1005d30bc: f9079a6f    	str	x15, [x19, #0xf30]
1005d30c0: f907a679    	str	x25, [x19, #0xf48]
1005d30c4: 91000a80    	add	x0, x20, #0x2
1005d30c8: f907aa60    	str	x0, [x19, #0xf50]
1005d30cc: f925c66b    	str	x11, [x19, #0x4b88]
1005d30d0: d29e9380    	mov	x0, #0xf49c             ; =62620
1005d30d4: cb000061    	sub	x1, x3, x0
1005d30d8: f925ca61    	str	x1, [x19, #0x4b90]
1005d30dc: f925ce64    	str	x4, [x19, #0x4b98]
1005d30e0: f927ba74    	str	x20, [x19, #0x4f70]
1005d30e4: f927be7b    	str	x27, [x19, #0x4f78]
1005d30e8: f84783e3    	ldur	x3, [sp, #0x78]
1005d30ec: f928ee63    	str	x3, [x19, #0x51d8]
1005d30f0: f84083eb    	ldur	x11, [sp, #0x8]
1005d30f4: f928fe6b    	str	x11, [x19, #0x51f8]
1005d30f8: 91000442    	add	x2, x2, #0x1
1005d30fc: f9294262    	str	x2, [x19, #0x5280]
1005d3100: f84203e3    	ldur	x3, [sp, #0x20]
1005d3104: f9294663    	str	x3, [x19, #0x5288]
1005d3108: f84283e3    	ldur	x3, [sp, #0x28]
1005d310c: f9294a63    	str	x3, [x19, #0x5290]
1005d3110: f84103e3    	ldur	x3, [sp, #0x10]
1005d3114: cb010061    	sub	x1, x3, x1
1005d3118: 9b008440    	msub	x0, x2, x0, x1
1005d311c: f9294e60    	str	x0, [x19, #0x5298]
1005d3120: f929526c    	str	x12, [x19, #0x52a0]
1005d3124: f929566a    	str	x10, [x19, #0x52a8]
1005d3128: f9295e68    	str	x8, [x19, #0x52b8]
1005d312c: f929627c    	str	x28, [x19, #0x52c0]
1005d3130: f9296a69    	str	x9, [x19, #0x52d0]
1005d3134: f9296e77    	str	x23, [x19, #0x52d8]
1005d3138: f929766e    	str	x14, [x19, #0x52e8]
1005d313c: f9297a6d    	str	x13, [x19, #0x52f0]
1005d3140: f965c660    	ldr	x0, [x19, #0x4b88]
1005d3144: f100001f    	cmp	x0, #0x0
1005d3148: 54fefdc1    	b.ne	0x1005d1100 <_mech_canonical_program_entry_v1_numeric_801+0x780>
1005d314c: 17fff84a    	b	0x1005d1274 <_mech_canonical_program_entry_v1_numeric_801+0x8f4>
1005d3150: f80983e0    	stur	x0, [sp, #0x98]
1005d3154: 1400089d    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d3158: f80983f5    	stur	x21, [sp, #0x98]
1005d315c: 1400089b    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d3160: f80983e0    	stur	x0, [sp, #0x98]
1005d3164: 14000899    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d3168: f80983f5    	stur	x21, [sp, #0x98]
1005d316c: 14000897    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d3170: f80983f6    	stur	x22, [sp, #0x98]
1005d3174: 14000895    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d3178: d2806865    	mov	x5, #0x343              ; =835
1005d317c: f9002745    	str	x5, [x26, #0x48]
1005d3180: d2800020    	mov	x0, #0x1                ; =1
1005d3184: f80983e0    	stur	x0, [sp, #0x98]
1005d3188: f9001a60    	str	x0, [x19, #0x30]
1005d318c: d2800045    	mov	x5, #0x2                ; =2
1005d3190: f9002265    	str	x5, [x19, #0x40]
1005d3194: d2800065    	mov	x5, #0x3                ; =3
1005d3198: f9002665    	str	x5, [x19, #0x48]
1005d319c: d28000c6    	mov	x6, #0x6                ; =6
1005d31a0: f9003266    	str	x6, [x19, #0x60]
1005d31a4: d2800307    	mov	x7, #0x18               ; =24
1005d31a8: f9004267    	str	x7, [x19, #0x80]
1005d31ac: d280000a    	mov	x10, #0x0               ; =0
1005d31b0: f900c66a    	str	x10, [x19, #0x188]
1005d31b4: f900ca60    	str	x0, [x19, #0x190]
1005d31b8: f9078a74    	str	x20, [x19, #0xf10]
1005d31bc: f9078e7b    	str	x27, [x19, #0xf18]
1005d31c0: f84e03f4    	ldur	x20, [sp, #0xe0]
1005d31c4: 53001e8c    	uxtb	w12, w20
1005d31c8: f9079a6c    	str	x12, [x19, #0xf30]
1005d31cc: f907d679    	str	x25, [x19, #0xfa8]
1005d31d0: f907da78    	str	x24, [x19, #0xfb0]
1005d31d4: f925c66b    	str	x11, [x19, #0x4b88]
1005d31d8: d2980b80    	mov	x0, #0xc05c             ; =49244
1005d31dc: cb000063    	sub	x3, x3, x0
1005d31e0: f925ca63    	str	x3, [x19, #0x4b90]
1005d31e4: f925ce64    	str	x4, [x19, #0x4b98]
1005d31e8: f84783f5    	ldur	x21, [sp, #0x78]
1005d31ec: f928ee75    	str	x21, [x19, #0x51d8]
1005d31f0: f84083f5    	ldur	x21, [sp, #0x8]
1005d31f4: f928fe75    	str	x21, [x19, #0x51f8]
1005d31f8: f9294262    	str	x2, [x19, #0x5280]
1005d31fc: f84203e0    	ldur	x0, [sp, #0x20]
1005d3200: f9294660    	str	x0, [x19, #0x5288]
1005d3204: f84283e4    	ldur	x4, [sp, #0x28]
1005d3208: f9294a64    	str	x4, [x19, #0x5290]
1005d320c: f84103e0    	ldur	x0, [sp, #0x10]
1005d3210: cb030003    	sub	x3, x0, x3
1005d3214: d29e9380    	mov	x0, #0xf49c             ; =62620
1005d3218: 9b008c40    	msub	x0, x2, x0, x3
1005d321c: f9294e60    	str	x0, [x19, #0x5298]
1005d3220: f9295261    	str	x1, [x19, #0x52a0]
1005d3224: f84383e6    	ldur	x6, [sp, #0x38]
1005d3228: f9295666    	str	x6, [x19, #0x52a8]
1005d322c: f9295e68    	str	x8, [x19, #0x52b8]
1005d3230: f929627c    	str	x28, [x19, #0x52c0]
1005d3234: f9296a69    	str	x9, [x19, #0x52d0]
1005d3238: f9296e77    	str	x23, [x19, #0x52d8]
1005d323c: f929766e    	str	x14, [x19, #0x52e8]
1005d3240: f9297a6d    	str	x13, [x19, #0x52f0]
1005d3244: 14000861    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d3248: f80983f5    	stur	x21, [sp, #0x98]
1005d324c: 1400085f    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d3250: d2806b60    	mov	x0, #0x35b              ; =859
1005d3254: f9002740    	str	x0, [x26, #0x48]
1005d3258: d2800020    	mov	x0, #0x1                ; =1
1005d325c: f80983e0    	stur	x0, [sp, #0x98]
1005d3260: f9001a60    	str	x0, [x19, #0x30]
1005d3264: f84c03f5    	ldur	x21, [sp, #0xc0]
1005d3268: f9002275    	str	x21, [x19, #0x40]
1005d326c: d2800060    	mov	x0, #0x3                ; =3
1005d3270: f9002660    	str	x0, [x19, #0x48]
1005d3274: d28000c0    	mov	x0, #0x6                ; =6
1005d3278: f9003260    	str	x0, [x19, #0x60]
1005d327c: d2800300    	mov	x0, #0x18               ; =24
1005d3280: f9004260    	str	x0, [x19, #0x80]
1005d3284: d2800000    	mov	x0, #0x0                ; =0
1005d3288: f900c660    	str	x0, [x19, #0x188]
1005d328c: f84983e0    	ldur	x0, [sp, #0x98]
1005d3290: f900ca60    	str	x0, [x19, #0x190]
1005d3294: f9078a74    	str	x20, [x19, #0xf10]
1005d3298: f9078e7b    	str	x27, [x19, #0xf18]
1005d329c: f84e03f4    	ldur	x20, [sp, #0xe0]
1005d32a0: 53001e80    	uxtb	w0, w20
1005d32a4: f9079a60    	str	x0, [x19, #0xf30]
1005d32a8: f907d679    	str	x25, [x19, #0xfa8]
1005d32ac: f907da78    	str	x24, [x19, #0xfb0]
1005d32b0: f84d03f4    	ldur	x20, [sp, #0xd0]
1005d32b4: 53001e80    	uxtb	w0, w20
1005d32b8: f907e660    	str	x0, [x19, #0xfc8]
1005d32bc: f9081a79    	str	x25, [x19, #0x1030]
1005d32c0: f9081e7c    	str	x28, [x19, #0x1038]
1005d32c4: f9082278    	str	x24, [x19, #0x1040]
1005d32c8: f925c66b    	str	x11, [x19, #0x4b88]
1005d32cc: d2990e80    	mov	x0, #0xc874             ; =51316
1005d32d0: cb000061    	sub	x1, x3, x0
1005d32d4: f925ca61    	str	x1, [x19, #0x4b90]
1005d32d8: f925ce64    	str	x4, [x19, #0x4b98]
1005d32dc: f84783f5    	ldur	x21, [sp, #0x78]
1005d32e0: f928ee75    	str	x21, [x19, #0x51d8]
1005d32e4: f84083f5    	ldur	x21, [sp, #0x8]
1005d32e8: f928fe75    	str	x21, [x19, #0x51f8]
1005d32ec: f9294262    	str	x2, [x19, #0x5280]
1005d32f0: f84203e5    	ldur	x5, [sp, #0x20]
1005d32f4: f9294665    	str	x5, [x19, #0x5288]
1005d32f8: f84283e0    	ldur	x0, [sp, #0x28]
1005d32fc: f9294a60    	str	x0, [x19, #0x5290]
1005d3300: f84103e0    	ldur	x0, [sp, #0x10]
1005d3304: cb010001    	sub	x1, x0, x1
1005d3308: d29e9380    	mov	x0, #0xf49c             ; =62620
1005d330c: 9b008440    	msub	x0, x2, x0, x1
1005d3310: f9294e60    	str	x0, [x19, #0x5298]
1005d3314: f84303e5    	ldur	x5, [sp, #0x30]
1005d3318: f9295265    	str	x5, [x19, #0x52a0]
1005d331c: f84383e0    	ldur	x0, [sp, #0x38]
1005d3320: f9295660    	str	x0, [x19, #0x52a8]
1005d3324: f84403ef    	ldur	x15, [sp, #0x40]
1005d3328: f9295e6f    	str	x15, [x19, #0x52b8]
1005d332c: f84483e8    	ldur	x8, [sp, #0x48]
1005d3330: f9296268    	str	x8, [x19, #0x52c0]
1005d3334: f9296a69    	str	x9, [x19, #0x52d0]
1005d3338: f9296e77    	str	x23, [x19, #0x52d8]
1005d333c: f929766e    	str	x14, [x19, #0x52e8]
1005d3340: f9297a6d    	str	x13, [x19, #0x52f0]
1005d3344: 14000821    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d3348: f84c03e0    	ldur	x0, [sp, #0xc0]
1005d334c: f80983e0    	stur	x0, [sp, #0x98]
1005d3350: 1400081e    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d3354: d2806ea0    	mov	x0, #0x375              ; =885
1005d3358: f9002740    	str	x0, [x26, #0x48]
1005d335c: d2800020    	mov	x0, #0x1                ; =1
1005d3360: f80983e0    	stur	x0, [sp, #0x98]
1005d3364: f9001a60    	str	x0, [x19, #0x30]
1005d3368: f84c03e0    	ldur	x0, [sp, #0xc0]
1005d336c: f9002260    	str	x0, [x19, #0x40]
1005d3370: d2800060    	mov	x0, #0x3                ; =3
1005d3374: f9002660    	str	x0, [x19, #0x48]
1005d3378: d28000c0    	mov	x0, #0x6                ; =6
1005d337c: f9003260    	str	x0, [x19, #0x60]
1005d3380: d2800300    	mov	x0, #0x18               ; =24
1005d3384: f9004260    	str	x0, [x19, #0x80]
1005d3388: d2800000    	mov	x0, #0x0                ; =0
1005d338c: f900c660    	str	x0, [x19, #0x188]
1005d3390: f84983e0    	ldur	x0, [sp, #0x98]
1005d3394: f900ca60    	str	x0, [x19, #0x190]
1005d3398: f9078a74    	str	x20, [x19, #0xf10]
1005d339c: f9078e7b    	str	x27, [x19, #0xf18]
1005d33a0: f84e03f4    	ldur	x20, [sp, #0xe0]
1005d33a4: 53001e81    	uxtb	w1, w20
1005d33a8: f9079a61    	str	x1, [x19, #0xf30]
1005d33ac: f907d679    	str	x25, [x19, #0xfa8]
1005d33b0: f907da78    	str	x24, [x19, #0xfb0]
1005d33b4: f84d03f4    	ldur	x20, [sp, #0xd0]
1005d33b8: 53001e85    	uxtb	w5, w20
1005d33bc: f907e665    	str	x5, [x19, #0xfc8]
1005d33c0: f9081a79    	str	x25, [x19, #0x1030]
1005d33c4: f9081e7c    	str	x28, [x19, #0x1038]
1005d33c8: f9082278    	str	x24, [x19, #0x1040]
1005d33cc: aa0603f5    	mov	x21, x6
1005d33d0: 53001ea8    	uxtb	w8, w21
1005d33d4: f9082e68    	str	x8, [x19, #0x1058]
1005d33d8: f9086679    	str	x25, [x19, #0x10c8]
1005d33dc: f9086a7c    	str	x28, [x19, #0x10d0]
1005d33e0: f9086e77    	str	x23, [x19, #0x10d8]
1005d33e4: f9087278    	str	x24, [x19, #0x10e0]
1005d33e8: f925c66b    	str	x11, [x19, #0x4b88]
1005d33ec: d29a118f    	mov	x15, #0xd08c            ; =53388
1005d33f0: cb0f006f    	sub	x15, x3, x15
1005d33f4: f925ca6f    	str	x15, [x19, #0x4b90]
1005d33f8: f925ce64    	str	x4, [x19, #0x4b98]
1005d33fc: f84783f5    	ldur	x21, [sp, #0x78]
1005d3400: f928ee75    	str	x21, [x19, #0x51d8]
1005d3404: f84083f5    	ldur	x21, [sp, #0x8]
1005d3408: f928fe75    	str	x21, [x19, #0x51f8]
1005d340c: f9294262    	str	x2, [x19, #0x5280]
1005d3410: f84203e0    	ldur	x0, [sp, #0x20]
1005d3414: f9294660    	str	x0, [x19, #0x5288]
1005d3418: f84283e0    	ldur	x0, [sp, #0x28]
1005d341c: f9294a60    	str	x0, [x19, #0x5290]
1005d3420: f84103e1    	ldur	x1, [sp, #0x10]
1005d3424: cb0f0021    	sub	x1, x1, x15
1005d3428: d29e9380    	mov	x0, #0xf49c             ; =62620
1005d342c: 9b008440    	msub	x0, x2, x0, x1
1005d3430: f9294e60    	str	x0, [x19, #0x5298]
1005d3434: f84303e5    	ldur	x5, [sp, #0x30]
1005d3438: f9295265    	str	x5, [x19, #0x52a0]
1005d343c: f84383e9    	ldur	x9, [sp, #0x38]
1005d3440: f9295669    	str	x9, [x19, #0x52a8]
1005d3444: f84403ef    	ldur	x15, [sp, #0x40]
1005d3448: f9295e6f    	str	x15, [x19, #0x52b8]
1005d344c: f84483e8    	ldur	x8, [sp, #0x48]
1005d3450: f9296268    	str	x8, [x19, #0x52c0]
1005d3454: f84503e9    	ldur	x9, [sp, #0x50]
1005d3458: f9296a69    	str	x9, [x19, #0x52d0]
1005d345c: f84583e1    	ldur	x1, [sp, #0x58]
1005d3460: f9296e61    	str	x1, [x19, #0x52d8]
1005d3464: f929766e    	str	x14, [x19, #0x52e8]
1005d3468: f9297a6d    	str	x13, [x19, #0x52f0]
1005d346c: 140007d7    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d3470: f84c03e0    	ldur	x0, [sp, #0xc0]
1005d3474: f80983e0    	stur	x0, [sp, #0x98]
1005d3478: 140007d4    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d347c: d28072e0    	mov	x0, #0x397              ; =919
1005d3480: f9002740    	str	x0, [x26, #0x48]
1005d3484: d2800020    	mov	x0, #0x1                ; =1
1005d3488: f9001a60    	str	x0, [x19, #0x30]
1005d348c: f84c03ed    	ldur	x13, [sp, #0xc0]
1005d3490: f900226d    	str	x13, [x19, #0x40]
1005d3494: d2800061    	mov	x1, #0x3                ; =3
1005d3498: f9002661    	str	x1, [x19, #0x48]
1005d349c: d28000c1    	mov	x1, #0x6                ; =6
1005d34a0: f9003261    	str	x1, [x19, #0x60]
1005d34a4: d2800301    	mov	x1, #0x18               ; =24
1005d34a8: f9004261    	str	x1, [x19, #0x80]
1005d34ac: d2800001    	mov	x1, #0x0                ; =0
1005d34b0: f900c661    	str	x1, [x19, #0x188]
1005d34b4: f900ca60    	str	x0, [x19, #0x190]
1005d34b8: f9078a74    	str	x20, [x19, #0xf10]
1005d34bc: f9078e7b    	str	x27, [x19, #0xf18]
1005d34c0: f84e03e0    	ldur	x0, [sp, #0xe0]
1005d34c4: 53001c00    	uxtb	w0, w0
1005d34c8: f9079a60    	str	x0, [x19, #0xf30]
1005d34cc: f907d679    	str	x25, [x19, #0xfa8]
1005d34d0: f907da78    	str	x24, [x19, #0xfb0]
1005d34d4: f84d03e0    	ldur	x0, [sp, #0xd0]
1005d34d8: 53001c05    	uxtb	w5, w0
1005d34dc: f907e665    	str	x5, [x19, #0xfc8]
1005d34e0: f9081a79    	str	x25, [x19, #0x1030]
1005d34e4: f9081e7c    	str	x28, [x19, #0x1038]
1005d34e8: f9082278    	str	x24, [x19, #0x1040]
1005d34ec: 53001ea8    	uxtb	w8, w21
1005d34f0: f9082e68    	str	x8, [x19, #0x1058]
1005d34f4: f9086679    	str	x25, [x19, #0x10c8]
1005d34f8: f9086a7c    	str	x28, [x19, #0x10d0]
1005d34fc: f9086e77    	str	x23, [x19, #0x10d8]
1005d3500: f9087278    	str	x24, [x19, #0x10e0]
1005d3504: 53001d2c    	uxtb	w12, w9
1005d3508: f9087e6c    	str	x12, [x19, #0x10f8]
1005d350c: f908ba79    	str	x25, [x19, #0x1170]
1005d3510: f908be7c    	str	x28, [x19, #0x1178]
1005d3514: f908c277    	str	x23, [x19, #0x1180]
1005d3518: f908c676    	str	x22, [x19, #0x1188]
1005d351c: f908ca78    	str	x24, [x19, #0x1190]
1005d3520: 53001ce0    	uxtb	w0, w7
1005d3524: f908d260    	str	x0, [x19, #0x11a0]
1005d3528: f84c83ea    	ldur	x10, [sp, #0xc8]
1005d352c: f908da6a    	str	x10, [x19, #0x11b0]
1005d3530: f925c66b    	str	x11, [x19, #0x4b88]
1005d3534: 52834f80    	mov	w0, #0x1a7c             ; =6780
1005d3538: 72a00020    	movk	w0, #0x1, lsl #16
1005d353c: cb000060    	sub	x0, x3, x0
1005d3540: f925ca60    	str	x0, [x19, #0x4b90]
1005d3544: f925ce64    	str	x4, [x19, #0x4b98]
1005d3548: f927ba74    	str	x20, [x19, #0x4f70]
1005d354c: f927be7b    	str	x27, [x19, #0x4f78]
1005d3550: f927da79    	str	x25, [x19, #0x4fb0]
1005d3554: f927de78    	str	x24, [x19, #0x4fb8]
1005d3558: f9280279    	str	x25, [x19, #0x5000]
1005d355c: f928067c    	str	x28, [x19, #0x5008]
1005d3560: f9280a78    	str	x24, [x19, #0x5010]
1005d3564: f9283a79    	str	x25, [x19, #0x5070]
1005d3568: f9283e7c    	str	x28, [x19, #0x5078]
1005d356c: f9284277    	str	x23, [x19, #0x5080]
1005d3570: f9284678    	str	x24, [x19, #0x5088]
1005d3574: f9288279    	str	x25, [x19, #0x5100]
1005d3578: f928867c    	str	x28, [x19, #0x5108]
1005d357c: f9288a77    	str	x23, [x19, #0x5110]
1005d3580: f9288e76    	str	x22, [x19, #0x5118]
1005d3584: f9289278    	str	x24, [x19, #0x5120]
1005d3588: f84783f5    	ldur	x21, [sp, #0x78]
1005d358c: f928ee75    	str	x21, [x19, #0x51d8]
1005d3590: f84083f5    	ldur	x21, [sp, #0x8]
1005d3594: f928fe75    	str	x21, [x19, #0x51f8]
1005d3598: f9294262    	str	x2, [x19, #0x5280]
1005d359c: f84203ed    	ldur	x13, [sp, #0x20]
1005d35a0: f929466d    	str	x13, [x19, #0x5288]
1005d35a4: f84283e1    	ldur	x1, [sp, #0x28]
1005d35a8: f9294a61    	str	x1, [x19, #0x5290]
1005d35ac: f84103e1    	ldur	x1, [sp, #0x10]
1005d35b0: cb000020    	sub	x0, x1, x0
1005d35b4: d29e9381    	mov	x1, #0xf49c             ; =62620
1005d35b8: 9b018040    	msub	x0, x2, x1, x0
1005d35bc: f9294e60    	str	x0, [x19, #0x5298]
1005d35c0: f84303e5    	ldur	x5, [sp, #0x30]
1005d35c4: f9295265    	str	x5, [x19, #0x52a0]
1005d35c8: f84383e9    	ldur	x9, [sp, #0x38]
1005d35cc: f9295669    	str	x9, [x19, #0x52a8]
1005d35d0: f84403ef    	ldur	x15, [sp, #0x40]
1005d35d4: f9295e6f    	str	x15, [x19, #0x52b8]
1005d35d8: f84483e8    	ldur	x8, [sp, #0x48]
1005d35dc: f9296268    	str	x8, [x19, #0x52c0]
1005d35e0: f84503ed    	ldur	x13, [sp, #0x50]
1005d35e4: f9296a6d    	str	x13, [x19, #0x52d0]
1005d35e8: f84583e1    	ldur	x1, [sp, #0x58]
1005d35ec: f9296e61    	str	x1, [x19, #0x52d8]
1005d35f0: f9297666    	str	x6, [x19, #0x52e8]
1005d35f4: f9297a6e    	str	x14, [x19, #0x52f0]
1005d35f8: f965c660    	ldr	x0, [x19, #0x4b88]
1005d35fc: f100001f    	cmp	x0, #0x0
1005d3600: 54ff5221    	b.ne	0x1005d2044 <_mech_canonical_program_entry_v1_numeric_801+0x16c4>
1005d3604: 17fffaf1    	b	0x1005d21c8 <_mech_canonical_program_entry_v1_numeric_801+0x1848>
1005d3608: f84c03e0    	ldur	x0, [sp, #0xc0]
1005d360c: f80983e0    	stur	x0, [sp, #0x98]
1005d3610: 1400076e    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d3614: f84c03e0    	ldur	x0, [sp, #0xc0]
1005d3618: f80983e0    	stur	x0, [sp, #0x98]
1005d361c: 1400076b    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d3620: d2807320    	mov	x0, #0x399              ; =921
1005d3624: f9002740    	str	x0, [x26, #0x48]
1005d3628: d2800020    	mov	x0, #0x1                ; =1
1005d362c: f9001a60    	str	x0, [x19, #0x30]
1005d3630: f84c03ed    	ldur	x13, [sp, #0xc0]
1005d3634: f900226d    	str	x13, [x19, #0x40]
1005d3638: d2800061    	mov	x1, #0x3                ; =3
1005d363c: f9002661    	str	x1, [x19, #0x48]
1005d3640: d28000c1    	mov	x1, #0x6                ; =6
1005d3644: f9003261    	str	x1, [x19, #0x60]
1005d3648: d2800301    	mov	x1, #0x18               ; =24
1005d364c: f9004261    	str	x1, [x19, #0x80]
1005d3650: d2800001    	mov	x1, #0x0                ; =0
1005d3654: f900c661    	str	x1, [x19, #0x188]
1005d3658: f900ca60    	str	x0, [x19, #0x190]
1005d365c: f9078a74    	str	x20, [x19, #0xf10]
1005d3660: f9078e7b    	str	x27, [x19, #0xf18]
1005d3664: f84e03e0    	ldur	x0, [sp, #0xe0]
1005d3668: 53001c00    	uxtb	w0, w0
1005d366c: f9079a60    	str	x0, [x19, #0xf30]
1005d3670: f907d679    	str	x25, [x19, #0xfa8]
1005d3674: f907da78    	str	x24, [x19, #0xfb0]
1005d3678: f84d03e0    	ldur	x0, [sp, #0xd0]
1005d367c: 53001c00    	uxtb	w0, w0
1005d3680: f907e660    	str	x0, [x19, #0xfc8]
1005d3684: f9081a79    	str	x25, [x19, #0x1030]
1005d3688: f9081e7c    	str	x28, [x19, #0x1038]
1005d368c: f9082278    	str	x24, [x19, #0x1040]
1005d3690: 53001ea5    	uxtb	w5, w21
1005d3694: f9082e65    	str	x5, [x19, #0x1058]
1005d3698: f9086679    	str	x25, [x19, #0x10c8]
1005d369c: f9086a7c    	str	x28, [x19, #0x10d0]
1005d36a0: f9086e77    	str	x23, [x19, #0x10d8]
1005d36a4: f9087278    	str	x24, [x19, #0x10e0]
1005d36a8: 53001d29    	uxtb	w9, w9
1005d36ac: f9087e69    	str	x9, [x19, #0x10f8]
1005d36b0: f908ba79    	str	x25, [x19, #0x1170]
1005d36b4: f908be7c    	str	x28, [x19, #0x1178]
1005d36b8: f908c277    	str	x23, [x19, #0x1180]
1005d36bc: f908c676    	str	x22, [x19, #0x1188]
1005d36c0: f908ca78    	str	x24, [x19, #0x1190]
1005d36c4: 53001ce0    	uxtb	w0, w7
1005d36c8: f908d260    	str	x0, [x19, #0x11a0]
1005d36cc: f908de6f    	str	x15, [x19, #0x11b8]
1005d36d0: f84b03ec    	ldur	x12, [sp, #0xb0]
1005d36d4: f908e26c    	str	x12, [x19, #0x11c0]
1005d36d8: f925c66b    	str	x11, [x19, #0x4b88]
1005d36dc: 52834f80    	mov	w0, #0x1a7c             ; =6780
1005d36e0: 72a00020    	movk	w0, #0x1, lsl #16
1005d36e4: cb000060    	sub	x0, x3, x0
1005d36e8: f925ca60    	str	x0, [x19, #0x4b90]
1005d36ec: f925ce64    	str	x4, [x19, #0x4b98]
1005d36f0: f927ba74    	str	x20, [x19, #0x4f70]
1005d36f4: f927be7b    	str	x27, [x19, #0x4f78]
1005d36f8: f927da79    	str	x25, [x19, #0x4fb0]
1005d36fc: f927de78    	str	x24, [x19, #0x4fb8]
1005d3700: f9280279    	str	x25, [x19, #0x5000]
1005d3704: f928067c    	str	x28, [x19, #0x5008]
1005d3708: f9280a78    	str	x24, [x19, #0x5010]
1005d370c: f9283a79    	str	x25, [x19, #0x5070]
1005d3710: f9283e7c    	str	x28, [x19, #0x5078]
1005d3714: f9284277    	str	x23, [x19, #0x5080]
1005d3718: f9284678    	str	x24, [x19, #0x5088]
1005d371c: f9288279    	str	x25, [x19, #0x5100]
1005d3720: f928867c    	str	x28, [x19, #0x5108]
1005d3724: f9288a77    	str	x23, [x19, #0x5110]
1005d3728: f9288e76    	str	x22, [x19, #0x5118]
1005d372c: f9289278    	str	x24, [x19, #0x5120]
1005d3730: f84783f5    	ldur	x21, [sp, #0x78]
1005d3734: f928ee75    	str	x21, [x19, #0x51d8]
1005d3738: f84083f5    	ldur	x21, [sp, #0x8]
1005d373c: f928fe75    	str	x21, [x19, #0x51f8]
1005d3740: f9294262    	str	x2, [x19, #0x5280]
1005d3744: f84203ed    	ldur	x13, [sp, #0x20]
1005d3748: f929466d    	str	x13, [x19, #0x5288]
1005d374c: f84283e1    	ldur	x1, [sp, #0x28]
1005d3750: f9294a61    	str	x1, [x19, #0x5290]
1005d3754: f84103e1    	ldur	x1, [sp, #0x10]
1005d3758: cb000020    	sub	x0, x1, x0
1005d375c: d29e9381    	mov	x1, #0xf49c             ; =62620
1005d3760: 9b018040    	msub	x0, x2, x1, x0
1005d3764: f9294e60    	str	x0, [x19, #0x5298]
1005d3768: f84303e5    	ldur	x5, [sp, #0x30]
1005d376c: f9295265    	str	x5, [x19, #0x52a0]
1005d3770: f84383e9    	ldur	x9, [sp, #0x38]
1005d3774: f9295669    	str	x9, [x19, #0x52a8]
1005d3778: f84403ef    	ldur	x15, [sp, #0x40]
1005d377c: f9295e6f    	str	x15, [x19, #0x52b8]
1005d3780: f84483e8    	ldur	x8, [sp, #0x48]
1005d3784: f9296268    	str	x8, [x19, #0x52c0]
1005d3788: f84503ed    	ldur	x13, [sp, #0x50]
1005d378c: f9296a6d    	str	x13, [x19, #0x52d0]
1005d3790: f84583e1    	ldur	x1, [sp, #0x58]
1005d3794: f9296e61    	str	x1, [x19, #0x52d8]
1005d3798: f9297666    	str	x6, [x19, #0x52e8]
1005d379c: f9297a6e    	str	x14, [x19, #0x52f0]
1005d37a0: f965c660    	ldr	x0, [x19, #0x4b88]
1005d37a4: f100001f    	cmp	x0, #0x0
1005d37a8: 54ff5461    	b.ne	0x1005d2234 <_mech_canonical_program_entry_v1_numeric_801+0x18b4>
1005d37ac: 17fffb06    	b	0x1005d23c4 <_mech_canonical_program_entry_v1_numeric_801+0x1a44>
1005d37b0: f84c03e0    	ldur	x0, [sp, #0xc0]
1005d37b4: f80983e0    	stur	x0, [sp, #0x98]
1005d37b8: 14000704    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d37bc: f84c03e0    	ldur	x0, [sp, #0xc0]
1005d37c0: f80983e0    	stur	x0, [sp, #0x98]
1005d37c4: 14000701    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d37c8: d2807360    	mov	x0, #0x39b              ; =923
1005d37cc: f9002740    	str	x0, [x26, #0x48]
1005d37d0: d2800020    	mov	x0, #0x1                ; =1
1005d37d4: f9001a60    	str	x0, [x19, #0x30]
1005d37d8: f84c03ed    	ldur	x13, [sp, #0xc0]
1005d37dc: f900226d    	str	x13, [x19, #0x40]
1005d37e0: d2800061    	mov	x1, #0x3                ; =3
1005d37e4: f9002661    	str	x1, [x19, #0x48]
1005d37e8: d28000c1    	mov	x1, #0x6                ; =6
1005d37ec: f9003261    	str	x1, [x19, #0x60]
1005d37f0: d2800301    	mov	x1, #0x18               ; =24
1005d37f4: f9004261    	str	x1, [x19, #0x80]
1005d37f8: d2800001    	mov	x1, #0x0                ; =0
1005d37fc: f900c661    	str	x1, [x19, #0x188]
1005d3800: f900ca60    	str	x0, [x19, #0x190]
1005d3804: f9078a74    	str	x20, [x19, #0xf10]
1005d3808: f9078e7b    	str	x27, [x19, #0xf18]
1005d380c: f84e03e0    	ldur	x0, [sp, #0xe0]
1005d3810: 53001c00    	uxtb	w0, w0
1005d3814: f9079a60    	str	x0, [x19, #0xf30]
1005d3818: f907d679    	str	x25, [x19, #0xfa8]
1005d381c: f907da78    	str	x24, [x19, #0xfb0]
1005d3820: f84d03e0    	ldur	x0, [sp, #0xd0]
1005d3824: 53001c00    	uxtb	w0, w0
1005d3828: f907e660    	str	x0, [x19, #0xfc8]
1005d382c: f9081a79    	str	x25, [x19, #0x1030]
1005d3830: f9081e7c    	str	x28, [x19, #0x1038]
1005d3834: f9082278    	str	x24, [x19, #0x1040]
1005d3838: 53001ea5    	uxtb	w5, w21
1005d383c: f9082e65    	str	x5, [x19, #0x1058]
1005d3840: f9086679    	str	x25, [x19, #0x10c8]
1005d3844: f9086a7c    	str	x28, [x19, #0x10d0]
1005d3848: f9086e77    	str	x23, [x19, #0x10d8]
1005d384c: f9087278    	str	x24, [x19, #0x10e0]
1005d3850: 53001d28    	uxtb	w8, w9
1005d3854: f9087e68    	str	x8, [x19, #0x10f8]
1005d3858: f908ba79    	str	x25, [x19, #0x1170]
1005d385c: f908be7c    	str	x28, [x19, #0x1178]
1005d3860: f908c277    	str	x23, [x19, #0x1180]
1005d3864: f908c676    	str	x22, [x19, #0x1188]
1005d3868: f908ca78    	str	x24, [x19, #0x1190]
1005d386c: 53001ced    	uxtb	w13, w7
1005d3870: f908d26d    	str	x13, [x19, #0x11a0]
1005d3874: f908de6f    	str	x15, [x19, #0x11b8]
1005d3878: f908e66a    	str	x10, [x19, #0x11c8]
1005d387c: f84a83f5    	ldur	x21, [sp, #0xa8]
1005d3880: f908ea75    	str	x21, [x19, #0x11d0]
1005d3884: f925c66b    	str	x11, [x19, #0x4b88]
1005d3888: 52834f80    	mov	w0, #0x1a7c             ; =6780
1005d388c: 72a00020    	movk	w0, #0x1, lsl #16
1005d3890: cb000060    	sub	x0, x3, x0
1005d3894: f925ca60    	str	x0, [x19, #0x4b90]
1005d3898: f925ce64    	str	x4, [x19, #0x4b98]
1005d389c: f927ba74    	str	x20, [x19, #0x4f70]
1005d38a0: f927be7b    	str	x27, [x19, #0x4f78]
1005d38a4: f927da79    	str	x25, [x19, #0x4fb0]
1005d38a8: f927de78    	str	x24, [x19, #0x4fb8]
1005d38ac: f9280279    	str	x25, [x19, #0x5000]
1005d38b0: f928067c    	str	x28, [x19, #0x5008]
1005d38b4: f9280a78    	str	x24, [x19, #0x5010]
1005d38b8: f9283a79    	str	x25, [x19, #0x5070]
1005d38bc: f9283e7c    	str	x28, [x19, #0x5078]
1005d38c0: f9284277    	str	x23, [x19, #0x5080]
1005d38c4: f9284678    	str	x24, [x19, #0x5088]
1005d38c8: f9288279    	str	x25, [x19, #0x5100]
1005d38cc: f928867c    	str	x28, [x19, #0x5108]
1005d38d0: f9288a77    	str	x23, [x19, #0x5110]
1005d38d4: f9288e76    	str	x22, [x19, #0x5118]
1005d38d8: f9289278    	str	x24, [x19, #0x5120]
1005d38dc: f84783f5    	ldur	x21, [sp, #0x78]
1005d38e0: f928ee75    	str	x21, [x19, #0x51d8]
1005d38e4: f84083f5    	ldur	x21, [sp, #0x8]
1005d38e8: f928fe75    	str	x21, [x19, #0x51f8]
1005d38ec: f9294262    	str	x2, [x19, #0x5280]
1005d38f0: f84203ed    	ldur	x13, [sp, #0x20]
1005d38f4: f929466d    	str	x13, [x19, #0x5288]
1005d38f8: f84283e1    	ldur	x1, [sp, #0x28]
1005d38fc: f9294a61    	str	x1, [x19, #0x5290]
1005d3900: f84103e1    	ldur	x1, [sp, #0x10]
1005d3904: cb000020    	sub	x0, x1, x0
1005d3908: d29e9381    	mov	x1, #0xf49c             ; =62620
1005d390c: 9b018040    	msub	x0, x2, x1, x0
1005d3910: f9294e60    	str	x0, [x19, #0x5298]
1005d3914: f84303e5    	ldur	x5, [sp, #0x30]
1005d3918: f9295265    	str	x5, [x19, #0x52a0]
1005d391c: f84383e9    	ldur	x9, [sp, #0x38]
1005d3920: f9295669    	str	x9, [x19, #0x52a8]
1005d3924: f84403ef    	ldur	x15, [sp, #0x40]
1005d3928: f9295e6f    	str	x15, [x19, #0x52b8]
1005d392c: f84483e8    	ldur	x8, [sp, #0x48]
1005d3930: f9296268    	str	x8, [x19, #0x52c0]
1005d3934: f84503ed    	ldur	x13, [sp, #0x50]
1005d3938: f9296a6d    	str	x13, [x19, #0x52d0]
1005d393c: f84583e1    	ldur	x1, [sp, #0x58]
1005d3940: f9296e61    	str	x1, [x19, #0x52d8]
1005d3944: f9297666    	str	x6, [x19, #0x52e8]
1005d3948: f9297a6e    	str	x14, [x19, #0x52f0]
1005d394c: f965c660    	ldr	x0, [x19, #0x4b88]
1005d3950: f100001f    	cmp	x0, #0x0
1005d3954: 54ff56c1    	b.ne	0x1005d242c <_mech_canonical_program_entry_v1_numeric_801+0x1aac>
1005d3958: 17fffb1a    	b	0x1005d25c0 <_mech_canonical_program_entry_v1_numeric_801+0x1c40>
1005d395c: f84c03e0    	ldur	x0, [sp, #0xc0]
1005d3960: f80983e0    	stur	x0, [sp, #0x98]
1005d3964: 14000699    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d3968: f84c03e0    	ldur	x0, [sp, #0xc0]
1005d396c: f80983e0    	stur	x0, [sp, #0x98]
1005d3970: 14000696    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d3974: d28073a0    	mov	x0, #0x39d              ; =925
1005d3978: f9002740    	str	x0, [x26, #0x48]
1005d397c: d2800020    	mov	x0, #0x1                ; =1
1005d3980: f9001a60    	str	x0, [x19, #0x30]
1005d3984: f84c03ed    	ldur	x13, [sp, #0xc0]
1005d3988: f900226d    	str	x13, [x19, #0x40]
1005d398c: d2800061    	mov	x1, #0x3                ; =3
1005d3990: f9002661    	str	x1, [x19, #0x48]
1005d3994: d28000c1    	mov	x1, #0x6                ; =6
1005d3998: f9003261    	str	x1, [x19, #0x60]
1005d399c: d2800301    	mov	x1, #0x18               ; =24
1005d39a0: f9004261    	str	x1, [x19, #0x80]
1005d39a4: d2800001    	mov	x1, #0x0                ; =0
1005d39a8: f900c661    	str	x1, [x19, #0x188]
1005d39ac: f900ca60    	str	x0, [x19, #0x190]
1005d39b0: f9078a74    	str	x20, [x19, #0xf10]
1005d39b4: f9078e7b    	str	x27, [x19, #0xf18]
1005d39b8: f84e03e0    	ldur	x0, [sp, #0xe0]
1005d39bc: 53001c00    	uxtb	w0, w0
1005d39c0: f9079a60    	str	x0, [x19, #0xf30]
1005d39c4: f907d679    	str	x25, [x19, #0xfa8]
1005d39c8: f907da78    	str	x24, [x19, #0xfb0]
1005d39cc: f84d03e0    	ldur	x0, [sp, #0xd0]
1005d39d0: 53001c00    	uxtb	w0, w0
1005d39d4: f907e660    	str	x0, [x19, #0xfc8]
1005d39d8: f9081a79    	str	x25, [x19, #0x1030]
1005d39dc: f9081e7c    	str	x28, [x19, #0x1038]
1005d39e0: f9082278    	str	x24, [x19, #0x1040]
1005d39e4: 53001ea1    	uxtb	w1, w21
1005d39e8: f9082e61    	str	x1, [x19, #0x1058]
1005d39ec: f9086679    	str	x25, [x19, #0x10c8]
1005d39f0: f9086a7c    	str	x28, [x19, #0x10d0]
1005d39f4: f9086e77    	str	x23, [x19, #0x10d8]
1005d39f8: f9087278    	str	x24, [x19, #0x10e0]
1005d39fc: 53001d29    	uxtb	w9, w9
1005d3a00: f9087e69    	str	x9, [x19, #0x10f8]
1005d3a04: f908ba79    	str	x25, [x19, #0x1170]
1005d3a08: f908be7c    	str	x28, [x19, #0x1178]
1005d3a0c: f908c277    	str	x23, [x19, #0x1180]
1005d3a10: f908c676    	str	x22, [x19, #0x1188]
1005d3a14: f908ca78    	str	x24, [x19, #0x1190]
1005d3a18: 53001cec    	uxtb	w12, w7
1005d3a1c: f908d26c    	str	x12, [x19, #0x11a0]
1005d3a20: f908de6f    	str	x15, [x19, #0x11b8]
1005d3a24: f908e66a    	str	x10, [x19, #0x11c8]
1005d3a28: f908ee68    	str	x8, [x19, #0x11d8]
1005d3a2c: 910006c0    	add	x0, x22, #0x1
1005d3a30: f908f260    	str	x0, [x19, #0x11e0]
1005d3a34: f925c66b    	str	x11, [x19, #0x4b88]
1005d3a38: 52834f80    	mov	w0, #0x1a7c             ; =6780
1005d3a3c: 72a00020    	movk	w0, #0x1, lsl #16
1005d3a40: cb000060    	sub	x0, x3, x0
1005d3a44: f925ca60    	str	x0, [x19, #0x4b90]
1005d3a48: f925ce64    	str	x4, [x19, #0x4b98]
1005d3a4c: f927ba74    	str	x20, [x19, #0x4f70]
1005d3a50: f927be7b    	str	x27, [x19, #0x4f78]
1005d3a54: f927da79    	str	x25, [x19, #0x4fb0]
1005d3a58: f927de78    	str	x24, [x19, #0x4fb8]
1005d3a5c: f9280279    	str	x25, [x19, #0x5000]
1005d3a60: f928067c    	str	x28, [x19, #0x5008]
1005d3a64: f9280a78    	str	x24, [x19, #0x5010]
1005d3a68: f9283a79    	str	x25, [x19, #0x5070]
1005d3a6c: f9283e7c    	str	x28, [x19, #0x5078]
1005d3a70: f9284277    	str	x23, [x19, #0x5080]
1005d3a74: f9284678    	str	x24, [x19, #0x5088]
1005d3a78: f9288279    	str	x25, [x19, #0x5100]
1005d3a7c: f928867c    	str	x28, [x19, #0x5108]
1005d3a80: f9288a77    	str	x23, [x19, #0x5110]
1005d3a84: f9288e76    	str	x22, [x19, #0x5118]
1005d3a88: f9289278    	str	x24, [x19, #0x5120]
1005d3a8c: f84783f5    	ldur	x21, [sp, #0x78]
1005d3a90: f928ee75    	str	x21, [x19, #0x51d8]
1005d3a94: f84083f5    	ldur	x21, [sp, #0x8]
1005d3a98: f928fe75    	str	x21, [x19, #0x51f8]
1005d3a9c: f9294262    	str	x2, [x19, #0x5280]
1005d3aa0: f84203ed    	ldur	x13, [sp, #0x20]
1005d3aa4: f929466d    	str	x13, [x19, #0x5288]
1005d3aa8: f84283e1    	ldur	x1, [sp, #0x28]
1005d3aac: f9294a61    	str	x1, [x19, #0x5290]
1005d3ab0: f84103e1    	ldur	x1, [sp, #0x10]
1005d3ab4: cb000020    	sub	x0, x1, x0
1005d3ab8: d29e9381    	mov	x1, #0xf49c             ; =62620
1005d3abc: 9b018040    	msub	x0, x2, x1, x0
1005d3ac0: f9294e60    	str	x0, [x19, #0x5298]
1005d3ac4: f84303e5    	ldur	x5, [sp, #0x30]
1005d3ac8: f9295265    	str	x5, [x19, #0x52a0]
1005d3acc: f84383e9    	ldur	x9, [sp, #0x38]
1005d3ad0: f9295669    	str	x9, [x19, #0x52a8]
1005d3ad4: f84403ef    	ldur	x15, [sp, #0x40]
1005d3ad8: f9295e6f    	str	x15, [x19, #0x52b8]
1005d3adc: f84483e8    	ldur	x8, [sp, #0x48]
1005d3ae0: f9296268    	str	x8, [x19, #0x52c0]
1005d3ae4: f84503ed    	ldur	x13, [sp, #0x50]
1005d3ae8: f9296a6d    	str	x13, [x19, #0x52d0]
1005d3aec: f84583e1    	ldur	x1, [sp, #0x58]
1005d3af0: f9296e61    	str	x1, [x19, #0x52d8]
1005d3af4: f9297666    	str	x6, [x19, #0x52e8]
1005d3af8: f9297a6e    	str	x14, [x19, #0x52f0]
1005d3afc: f965c660    	ldr	x0, [x19, #0x4b88]
1005d3b00: f100001f    	cmp	x0, #0x0
1005d3b04: 54ff5941    	b.ne	0x1005d262c <_mech_canonical_program_entry_v1_numeric_801+0x1cac>
1005d3b08: 17fffb2c    	b	0x1005d27b8 <_mech_canonical_program_entry_v1_numeric_801+0x1e38>
1005d3b0c: f84c03e0    	ldur	x0, [sp, #0xc0]
1005d3b10: f80983e0    	stur	x0, [sp, #0x98]
1005d3b14: 1400062d    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d3b18: f84c03e0    	ldur	x0, [sp, #0xc0]
1005d3b1c: f80983e0    	stur	x0, [sp, #0x98]
1005d3b20: 1400062a    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d3b24: d28073c0    	mov	x0, #0x39e              ; =926
1005d3b28: f9002740    	str	x0, [x26, #0x48]
1005d3b2c: d2800020    	mov	x0, #0x1                ; =1
1005d3b30: f80983e0    	stur	x0, [sp, #0x98]
1005d3b34: f9001a60    	str	x0, [x19, #0x30]
1005d3b38: f84c03ed    	ldur	x13, [sp, #0xc0]
1005d3b3c: f900226d    	str	x13, [x19, #0x40]
1005d3b40: d2800060    	mov	x0, #0x3                ; =3
1005d3b44: f9002660    	str	x0, [x19, #0x48]
1005d3b48: d28000c0    	mov	x0, #0x6                ; =6
1005d3b4c: f9003260    	str	x0, [x19, #0x60]
1005d3b50: d2800300    	mov	x0, #0x18               ; =24
1005d3b54: f9004260    	str	x0, [x19, #0x80]
1005d3b58: d2800000    	mov	x0, #0x0                ; =0
1005d3b5c: f900c660    	str	x0, [x19, #0x188]
1005d3b60: f84983e0    	ldur	x0, [sp, #0x98]
1005d3b64: f900ca60    	str	x0, [x19, #0x190]
1005d3b68: f9078a74    	str	x20, [x19, #0xf10]
1005d3b6c: f9078e7b    	str	x27, [x19, #0xf18]
1005d3b70: f84e03f4    	ldur	x20, [sp, #0xe0]
1005d3b74: 53001e80    	uxtb	w0, w20
1005d3b78: f9079a60    	str	x0, [x19, #0xf30]
1005d3b7c: f907d679    	str	x25, [x19, #0xfa8]
1005d3b80: f907da78    	str	x24, [x19, #0xfb0]
1005d3b84: f84d03f4    	ldur	x20, [sp, #0xd0]
1005d3b88: 53001e80    	uxtb	w0, w20
1005d3b8c: f907e660    	str	x0, [x19, #0xfc8]
1005d3b90: f9081a79    	str	x25, [x19, #0x1030]
1005d3b94: f9081e7c    	str	x28, [x19, #0x1038]
1005d3b98: f9082278    	str	x24, [x19, #0x1040]
1005d3b9c: 53001ea0    	uxtb	w0, w21
1005d3ba0: f9082e60    	str	x0, [x19, #0x1058]
1005d3ba4: f9086679    	str	x25, [x19, #0x10c8]
1005d3ba8: f9086a7c    	str	x28, [x19, #0x10d0]
1005d3bac: f9086e77    	str	x23, [x19, #0x10d8]
1005d3bb0: f9087278    	str	x24, [x19, #0x10e0]
1005d3bb4: 53001d29    	uxtb	w9, w9
1005d3bb8: f9087e69    	str	x9, [x19, #0x10f8]
1005d3bbc: f908ba79    	str	x25, [x19, #0x1170]
1005d3bc0: f908be7c    	str	x28, [x19, #0x1178]
1005d3bc4: f908c277    	str	x23, [x19, #0x1180]
1005d3bc8: f908c676    	str	x22, [x19, #0x1188]
1005d3bcc: f908ca78    	str	x24, [x19, #0x1190]
1005d3bd0: 53001cec    	uxtb	w12, w7
1005d3bd4: f908d26c    	str	x12, [x19, #0x11a0]
1005d3bd8: f908de6f    	str	x15, [x19, #0x11b8]
1005d3bdc: f908e66a    	str	x10, [x19, #0x11c8]
1005d3be0: f908ee68    	str	x8, [x19, #0x11d8]
1005d3be4: f908f665    	str	x5, [x19, #0x11e8]
1005d3be8: f925c66b    	str	x11, [x19, #0x4b88]
1005d3bec: 52834f81    	mov	w1, #0x1a7c             ; =6780
1005d3bf0: 72a00021    	movk	w1, #0x1, lsl #16
1005d3bf4: cb010061    	sub	x1, x3, x1
1005d3bf8: f925ca61    	str	x1, [x19, #0x4b90]
1005d3bfc: f925ce64    	str	x4, [x19, #0x4b98]
1005d3c00: f84783f5    	ldur	x21, [sp, #0x78]
1005d3c04: f928ee75    	str	x21, [x19, #0x51d8]
1005d3c08: f84083f5    	ldur	x21, [sp, #0x8]
1005d3c0c: f928fe75    	str	x21, [x19, #0x51f8]
1005d3c10: f9294262    	str	x2, [x19, #0x5280]
1005d3c14: f84203ed    	ldur	x13, [sp, #0x20]
1005d3c18: f929466d    	str	x13, [x19, #0x5288]
1005d3c1c: f84283ed    	ldur	x13, [sp, #0x28]
1005d3c20: f9294a6d    	str	x13, [x19, #0x5290]
1005d3c24: f84103e0    	ldur	x0, [sp, #0x10]
1005d3c28: cb010001    	sub	x1, x0, x1
1005d3c2c: d29e9380    	mov	x0, #0xf49c             ; =62620
1005d3c30: 9b008440    	msub	x0, x2, x0, x1
1005d3c34: f9294e60    	str	x0, [x19, #0x5298]
1005d3c38: f84303e5    	ldur	x5, [sp, #0x30]
1005d3c3c: f9295265    	str	x5, [x19, #0x52a0]
1005d3c40: f84383e9    	ldur	x9, [sp, #0x38]
1005d3c44: f9295669    	str	x9, [x19, #0x52a8]
1005d3c48: f84403ef    	ldur	x15, [sp, #0x40]
1005d3c4c: f9295e6f    	str	x15, [x19, #0x52b8]
1005d3c50: f84483e8    	ldur	x8, [sp, #0x48]
1005d3c54: f9296268    	str	x8, [x19, #0x52c0]
1005d3c58: f84503ed    	ldur	x13, [sp, #0x50]
1005d3c5c: f9296a6d    	str	x13, [x19, #0x52d0]
1005d3c60: f84583e1    	ldur	x1, [sp, #0x58]
1005d3c64: f9296e61    	str	x1, [x19, #0x52d8]
1005d3c68: f9297666    	str	x6, [x19, #0x52e8]
1005d3c6c: f9297a6e    	str	x14, [x19, #0x52f0]
1005d3c70: 140005d6    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d3c74: d28073e0    	mov	x0, #0x39f              ; =927
1005d3c78: f9002740    	str	x0, [x26, #0x48]
1005d3c7c: d2800020    	mov	x0, #0x1                ; =1
1005d3c80: f80983e0    	stur	x0, [sp, #0x98]
1005d3c84: f9001a60    	str	x0, [x19, #0x30]
1005d3c88: f84c03ed    	ldur	x13, [sp, #0xc0]
1005d3c8c: f900226d    	str	x13, [x19, #0x40]
1005d3c90: d2800060    	mov	x0, #0x3                ; =3
1005d3c94: f9002660    	str	x0, [x19, #0x48]
1005d3c98: d28000c0    	mov	x0, #0x6                ; =6
1005d3c9c: f9003260    	str	x0, [x19, #0x60]
1005d3ca0: d2800300    	mov	x0, #0x18               ; =24
1005d3ca4: f9004260    	str	x0, [x19, #0x80]
1005d3ca8: d2800000    	mov	x0, #0x0                ; =0
1005d3cac: f900c660    	str	x0, [x19, #0x188]
1005d3cb0: f84983e0    	ldur	x0, [sp, #0x98]
1005d3cb4: f900ca60    	str	x0, [x19, #0x190]
1005d3cb8: f9078a74    	str	x20, [x19, #0xf10]
1005d3cbc: f9078e7b    	str	x27, [x19, #0xf18]
1005d3cc0: f84e03f4    	ldur	x20, [sp, #0xe0]
1005d3cc4: 53001e80    	uxtb	w0, w20
1005d3cc8: f9079a60    	str	x0, [x19, #0xf30]
1005d3ccc: f907d679    	str	x25, [x19, #0xfa8]
1005d3cd0: f907da78    	str	x24, [x19, #0xfb0]
1005d3cd4: f84d03f4    	ldur	x20, [sp, #0xd0]
1005d3cd8: 53001e80    	uxtb	w0, w20
1005d3cdc: f907e660    	str	x0, [x19, #0xfc8]
1005d3ce0: f9081a79    	str	x25, [x19, #0x1030]
1005d3ce4: f9081e7c    	str	x28, [x19, #0x1038]
1005d3ce8: f9082278    	str	x24, [x19, #0x1040]
1005d3cec: 53001ea0    	uxtb	w0, w21
1005d3cf0: f9082e60    	str	x0, [x19, #0x1058]
1005d3cf4: f9086679    	str	x25, [x19, #0x10c8]
1005d3cf8: f9086a7c    	str	x28, [x19, #0x10d0]
1005d3cfc: f9086e77    	str	x23, [x19, #0x10d8]
1005d3d00: f9087278    	str	x24, [x19, #0x10e0]
1005d3d04: 53001d20    	uxtb	w0, w9
1005d3d08: f9087e60    	str	x0, [x19, #0x10f8]
1005d3d0c: f908ba79    	str	x25, [x19, #0x1170]
1005d3d10: f908be7c    	str	x28, [x19, #0x1178]
1005d3d14: f908c277    	str	x23, [x19, #0x1180]
1005d3d18: f908c676    	str	x22, [x19, #0x1188]
1005d3d1c: f908ca78    	str	x24, [x19, #0x1190]
1005d3d20: 53001ce7    	uxtb	w7, w7
1005d3d24: f908d267    	str	x7, [x19, #0x11a0]
1005d3d28: f908de6f    	str	x15, [x19, #0x11b8]
1005d3d2c: f908e66a    	str	x10, [x19, #0x11c8]
1005d3d30: f908ee68    	str	x8, [x19, #0x11d8]
1005d3d34: f908f665    	str	x5, [x19, #0x11e8]
1005d3d38: f908fa61    	str	x1, [x19, #0x11f0]
1005d3d3c: f925c66b    	str	x11, [x19, #0x4b88]
1005d3d40: 52834f88    	mov	w8, #0x1a7c             ; =6780
1005d3d44: 72a00028    	movk	w8, #0x1, lsl #16
1005d3d48: cb080068    	sub	x8, x3, x8
1005d3d4c: f925ca68    	str	x8, [x19, #0x4b90]
1005d3d50: f925ce64    	str	x4, [x19, #0x4b98]
1005d3d54: f84783f5    	ldur	x21, [sp, #0x78]
1005d3d58: f928ee75    	str	x21, [x19, #0x51d8]
1005d3d5c: f84083f5    	ldur	x21, [sp, #0x8]
1005d3d60: f928fe75    	str	x21, [x19, #0x51f8]
1005d3d64: f9294262    	str	x2, [x19, #0x5280]
1005d3d68: f84203ed    	ldur	x13, [sp, #0x20]
1005d3d6c: f929466d    	str	x13, [x19, #0x5288]
1005d3d70: f84283e0    	ldur	x0, [sp, #0x28]
1005d3d74: f9294a60    	str	x0, [x19, #0x5290]
1005d3d78: f84103e1    	ldur	x1, [sp, #0x10]
1005d3d7c: cb08002f    	sub	x15, x1, x8
1005d3d80: d29e9380    	mov	x0, #0xf49c             ; =62620
1005d3d84: 9b00bc4f    	msub	x15, x2, x0, x15
1005d3d88: f9294e6f    	str	x15, [x19, #0x5298]
1005d3d8c: f84303e5    	ldur	x5, [sp, #0x30]
1005d3d90: f9295265    	str	x5, [x19, #0x52a0]
1005d3d94: f84383e9    	ldur	x9, [sp, #0x38]
1005d3d98: f9295669    	str	x9, [x19, #0x52a8]
1005d3d9c: f84403ef    	ldur	x15, [sp, #0x40]
1005d3da0: f9295e6f    	str	x15, [x19, #0x52b8]
1005d3da4: f84483e8    	ldur	x8, [sp, #0x48]
1005d3da8: f9296268    	str	x8, [x19, #0x52c0]
1005d3dac: f84503ed    	ldur	x13, [sp, #0x50]
1005d3db0: f9296a6d    	str	x13, [x19, #0x52d0]
1005d3db4: f84583e1    	ldur	x1, [sp, #0x58]
1005d3db8: f9296e61    	str	x1, [x19, #0x52d8]
1005d3dbc: f9297666    	str	x6, [x19, #0x52e8]
1005d3dc0: f9297a6e    	str	x14, [x19, #0x52f0]
1005d3dc4: 14000581    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d3dc8: d2807420    	mov	x0, #0x3a1              ; =929
1005d3dcc: f9002740    	str	x0, [x26, #0x48]
1005d3dd0: d2800020    	mov	x0, #0x1                ; =1
1005d3dd4: f80983e0    	stur	x0, [sp, #0x98]
1005d3dd8: f9001a60    	str	x0, [x19, #0x30]
1005d3ddc: f84c03ed    	ldur	x13, [sp, #0xc0]
1005d3de0: f900226d    	str	x13, [x19, #0x40]
1005d3de4: d2800060    	mov	x0, #0x3                ; =3
1005d3de8: f9002660    	str	x0, [x19, #0x48]
1005d3dec: d28000c0    	mov	x0, #0x6                ; =6
1005d3df0: f9003260    	str	x0, [x19, #0x60]
1005d3df4: d2800300    	mov	x0, #0x18               ; =24
1005d3df8: f9004260    	str	x0, [x19, #0x80]
1005d3dfc: d2800000    	mov	x0, #0x0                ; =0
1005d3e00: f900c660    	str	x0, [x19, #0x188]
1005d3e04: f84983e0    	ldur	x0, [sp, #0x98]
1005d3e08: f900ca60    	str	x0, [x19, #0x190]
1005d3e0c: f9078a74    	str	x20, [x19, #0xf10]
1005d3e10: f9078e7b    	str	x27, [x19, #0xf18]
1005d3e14: f84e03f4    	ldur	x20, [sp, #0xe0]
1005d3e18: 53001e80    	uxtb	w0, w20
1005d3e1c: f9079a60    	str	x0, [x19, #0xf30]
1005d3e20: f907d679    	str	x25, [x19, #0xfa8]
1005d3e24: f907da78    	str	x24, [x19, #0xfb0]
1005d3e28: f84d03f4    	ldur	x20, [sp, #0xd0]
1005d3e2c: 53001e80    	uxtb	w0, w20
1005d3e30: f907e660    	str	x0, [x19, #0xfc8]
1005d3e34: f9081a79    	str	x25, [x19, #0x1030]
1005d3e38: f9081e7c    	str	x28, [x19, #0x1038]
1005d3e3c: f9082278    	str	x24, [x19, #0x1040]
1005d3e40: 53001ea0    	uxtb	w0, w21
1005d3e44: f9082e60    	str	x0, [x19, #0x1058]
1005d3e48: f9086679    	str	x25, [x19, #0x10c8]
1005d3e4c: f9086a7c    	str	x28, [x19, #0x10d0]
1005d3e50: f9086e77    	str	x23, [x19, #0x10d8]
1005d3e54: f9087278    	str	x24, [x19, #0x10e0]
1005d3e58: 53001d20    	uxtb	w0, w9
1005d3e5c: f9087e60    	str	x0, [x19, #0x10f8]
1005d3e60: f908ba79    	str	x25, [x19, #0x1170]
1005d3e64: f908be7c    	str	x28, [x19, #0x1178]
1005d3e68: f908c277    	str	x23, [x19, #0x1180]
1005d3e6c: f908c676    	str	x22, [x19, #0x1188]
1005d3e70: f908ca78    	str	x24, [x19, #0x1190]
1005d3e74: 53001ce0    	uxtb	w0, w7
1005d3e78: f908d260    	str	x0, [x19, #0x11a0]
1005d3e7c: f908de6f    	str	x15, [x19, #0x11b8]
1005d3e80: f908ee68    	str	x8, [x19, #0x11d8]
1005d3e84: f908f665    	str	x5, [x19, #0x11e8]
1005d3e88: f9090261    	str	x1, [x19, #0x1200]
1005d3e8c: f925c66b    	str	x11, [x19, #0x4b88]
1005d3e90: 52834f81    	mov	w1, #0x1a7c             ; =6780
1005d3e94: 72a00021    	movk	w1, #0x1, lsl #16
1005d3e98: cb010061    	sub	x1, x3, x1
1005d3e9c: f925ca61    	str	x1, [x19, #0x4b90]
1005d3ea0: f925ce64    	str	x4, [x19, #0x4b98]
1005d3ea4: f84783f5    	ldur	x21, [sp, #0x78]
1005d3ea8: f928ee75    	str	x21, [x19, #0x51d8]
1005d3eac: f84083f5    	ldur	x21, [sp, #0x8]
1005d3eb0: f928fe75    	str	x21, [x19, #0x51f8]
1005d3eb4: f9294262    	str	x2, [x19, #0x5280]
1005d3eb8: f84203ed    	ldur	x13, [sp, #0x20]
1005d3ebc: f929466d    	str	x13, [x19, #0x5288]
1005d3ec0: f84283e0    	ldur	x0, [sp, #0x28]
1005d3ec4: f9294a60    	str	x0, [x19, #0x5290]
1005d3ec8: f84103e0    	ldur	x0, [sp, #0x10]
1005d3ecc: cb010008    	sub	x8, x0, x1
1005d3ed0: d29e9389    	mov	x9, #0xf49c             ; =62620
1005d3ed4: 9b09a048    	msub	x8, x2, x9, x8
1005d3ed8: f9294e68    	str	x8, [x19, #0x5298]
1005d3edc: f84303e5    	ldur	x5, [sp, #0x30]
1005d3ee0: f9295265    	str	x5, [x19, #0x52a0]
1005d3ee4: f84383e9    	ldur	x9, [sp, #0x38]
1005d3ee8: f9295669    	str	x9, [x19, #0x52a8]
1005d3eec: f84403ef    	ldur	x15, [sp, #0x40]
1005d3ef0: f9295e6f    	str	x15, [x19, #0x52b8]
1005d3ef4: f84483e8    	ldur	x8, [sp, #0x48]
1005d3ef8: f9296268    	str	x8, [x19, #0x52c0]
1005d3efc: f84503ed    	ldur	x13, [sp, #0x50]
1005d3f00: f9296a6d    	str	x13, [x19, #0x52d0]
1005d3f04: f84583e1    	ldur	x1, [sp, #0x58]
1005d3f08: f9296e61    	str	x1, [x19, #0x52d8]
1005d3f0c: f9297666    	str	x6, [x19, #0x52e8]
1005d3f10: f9297a6e    	str	x14, [x19, #0x52f0]
1005d3f14: 1400052d    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d3f18: d2807440    	mov	x0, #0x3a2              ; =930
1005d3f1c: f9002740    	str	x0, [x26, #0x48]
1005d3f20: d2800020    	mov	x0, #0x1                ; =1
1005d3f24: f80983e0    	stur	x0, [sp, #0x98]
1005d3f28: f9001a60    	str	x0, [x19, #0x30]
1005d3f2c: f84c03ed    	ldur	x13, [sp, #0xc0]
1005d3f30: f900226d    	str	x13, [x19, #0x40]
1005d3f34: d2800060    	mov	x0, #0x3                ; =3
1005d3f38: f9002660    	str	x0, [x19, #0x48]
1005d3f3c: d28000c0    	mov	x0, #0x6                ; =6
1005d3f40: f9003260    	str	x0, [x19, #0x60]
1005d3f44: d2800300    	mov	x0, #0x18               ; =24
1005d3f48: f9004260    	str	x0, [x19, #0x80]
1005d3f4c: d2800000    	mov	x0, #0x0                ; =0
1005d3f50: f900c660    	str	x0, [x19, #0x188]
1005d3f54: f84983e0    	ldur	x0, [sp, #0x98]
1005d3f58: f900ca60    	str	x0, [x19, #0x190]
1005d3f5c: f9078a74    	str	x20, [x19, #0xf10]
1005d3f60: f9078e7b    	str	x27, [x19, #0xf18]
1005d3f64: f84e03f4    	ldur	x20, [sp, #0xe0]
1005d3f68: 53001e80    	uxtb	w0, w20
1005d3f6c: f9079a60    	str	x0, [x19, #0xf30]
1005d3f70: f907d679    	str	x25, [x19, #0xfa8]
1005d3f74: f907da78    	str	x24, [x19, #0xfb0]
1005d3f78: f84d03f4    	ldur	x20, [sp, #0xd0]
1005d3f7c: 53001e80    	uxtb	w0, w20
1005d3f80: f907e660    	str	x0, [x19, #0xfc8]
1005d3f84: f9081a79    	str	x25, [x19, #0x1030]
1005d3f88: f9081e7c    	str	x28, [x19, #0x1038]
1005d3f8c: f9082278    	str	x24, [x19, #0x1040]
1005d3f90: 53001ea0    	uxtb	w0, w21
1005d3f94: f9082e60    	str	x0, [x19, #0x1058]
1005d3f98: f9086679    	str	x25, [x19, #0x10c8]
1005d3f9c: f9086a7c    	str	x28, [x19, #0x10d0]
1005d3fa0: f9086e77    	str	x23, [x19, #0x10d8]
1005d3fa4: f9087278    	str	x24, [x19, #0x10e0]
1005d3fa8: 53001d20    	uxtb	w0, w9
1005d3fac: f9087e60    	str	x0, [x19, #0x10f8]
1005d3fb0: f908ba79    	str	x25, [x19, #0x1170]
1005d3fb4: f908be7c    	str	x28, [x19, #0x1178]
1005d3fb8: f908c277    	str	x23, [x19, #0x1180]
1005d3fbc: f908c676    	str	x22, [x19, #0x1188]
1005d3fc0: f908ca78    	str	x24, [x19, #0x1190]
1005d3fc4: 53001ce0    	uxtb	w0, w7
1005d3fc8: f908d260    	str	x0, [x19, #0x11a0]
1005d3fcc: f908ee68    	str	x8, [x19, #0x11d8]
1005d3fd0: f908f665    	str	x5, [x19, #0x11e8]
1005d3fd4: f909066a    	str	x10, [x19, #0x1208]
1005d3fd8: f925c66b    	str	x11, [x19, #0x4b88]
1005d3fdc: 52834f81    	mov	w1, #0x1a7c             ; =6780
1005d3fe0: 72a00021    	movk	w1, #0x1, lsl #16
1005d3fe4: cb010061    	sub	x1, x3, x1
1005d3fe8: f925ca61    	str	x1, [x19, #0x4b90]
1005d3fec: f925ce64    	str	x4, [x19, #0x4b98]
1005d3ff0: f84783f5    	ldur	x21, [sp, #0x78]
1005d3ff4: f928ee75    	str	x21, [x19, #0x51d8]
1005d3ff8: f84083f5    	ldur	x21, [sp, #0x8]
1005d3ffc: f928fe75    	str	x21, [x19, #0x51f8]
1005d4000: f9294262    	str	x2, [x19, #0x5280]
1005d4004: f84203ed    	ldur	x13, [sp, #0x20]
1005d4008: f929466d    	str	x13, [x19, #0x5288]
1005d400c: f84283e0    	ldur	x0, [sp, #0x28]
1005d4010: f9294a60    	str	x0, [x19, #0x5290]
1005d4014: f84103e0    	ldur	x0, [sp, #0x10]
1005d4018: cb010001    	sub	x1, x0, x1
1005d401c: d29e9380    	mov	x0, #0xf49c             ; =62620
1005d4020: 9b008440    	msub	x0, x2, x0, x1
1005d4024: f9294e60    	str	x0, [x19, #0x5298]
1005d4028: f84303e5    	ldur	x5, [sp, #0x30]
1005d402c: f9295265    	str	x5, [x19, #0x52a0]
1005d4030: f84383e9    	ldur	x9, [sp, #0x38]
1005d4034: f9295669    	str	x9, [x19, #0x52a8]
1005d4038: f84403ef    	ldur	x15, [sp, #0x40]
1005d403c: f9295e6f    	str	x15, [x19, #0x52b8]
1005d4040: f84483e8    	ldur	x8, [sp, #0x48]
1005d4044: f9296268    	str	x8, [x19, #0x52c0]
1005d4048: f84503ed    	ldur	x13, [sp, #0x50]
1005d404c: f9296a6d    	str	x13, [x19, #0x52d0]
1005d4050: f84583e1    	ldur	x1, [sp, #0x58]
1005d4054: f9296e61    	str	x1, [x19, #0x52d8]
1005d4058: f9297666    	str	x6, [x19, #0x52e8]
1005d405c: f9297a6e    	str	x14, [x19, #0x52f0]
1005d4060: 140004da    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d4064: d280746c    	mov	x12, #0x3a3             ; =931
1005d4068: f900274c    	str	x12, [x26, #0x48]
1005d406c: d2800020    	mov	x0, #0x1                ; =1
1005d4070: f80983e0    	stur	x0, [sp, #0x98]
1005d4074: f9001a60    	str	x0, [x19, #0x30]
1005d4078: f84c03ed    	ldur	x13, [sp, #0xc0]
1005d407c: f900226d    	str	x13, [x19, #0x40]
1005d4080: d2800060    	mov	x0, #0x3                ; =3
1005d4084: f9002660    	str	x0, [x19, #0x48]
1005d4088: d28000c0    	mov	x0, #0x6                ; =6
1005d408c: f9003260    	str	x0, [x19, #0x60]
1005d4090: d2800300    	mov	x0, #0x18               ; =24
1005d4094: f9004260    	str	x0, [x19, #0x80]
1005d4098: d2800000    	mov	x0, #0x0                ; =0
1005d409c: f900c660    	str	x0, [x19, #0x188]
1005d40a0: f84983e0    	ldur	x0, [sp, #0x98]
1005d40a4: f900ca60    	str	x0, [x19, #0x190]
1005d40a8: f9078a74    	str	x20, [x19, #0xf10]
1005d40ac: f9078e7b    	str	x27, [x19, #0xf18]
1005d40b0: f84e03f4    	ldur	x20, [sp, #0xe0]
1005d40b4: 53001e80    	uxtb	w0, w20
1005d40b8: f9079a60    	str	x0, [x19, #0xf30]
1005d40bc: f907d679    	str	x25, [x19, #0xfa8]
1005d40c0: f907da78    	str	x24, [x19, #0xfb0]
1005d40c4: f84d03f4    	ldur	x20, [sp, #0xd0]
1005d40c8: 53001e80    	uxtb	w0, w20
1005d40cc: f907e660    	str	x0, [x19, #0xfc8]
1005d40d0: f9081a79    	str	x25, [x19, #0x1030]
1005d40d4: f9081e7c    	str	x28, [x19, #0x1038]
1005d40d8: f9082278    	str	x24, [x19, #0x1040]
1005d40dc: 53001ea0    	uxtb	w0, w21
1005d40e0: f9082e60    	str	x0, [x19, #0x1058]
1005d40e4: f9086679    	str	x25, [x19, #0x10c8]
1005d40e8: f9086a7c    	str	x28, [x19, #0x10d0]
1005d40ec: f9086e77    	str	x23, [x19, #0x10d8]
1005d40f0: f9087278    	str	x24, [x19, #0x10e0]
1005d40f4: 53001d20    	uxtb	w0, w9
1005d40f8: f9087e60    	str	x0, [x19, #0x10f8]
1005d40fc: f908ba79    	str	x25, [x19, #0x1170]
1005d4100: f908be7c    	str	x28, [x19, #0x1178]
1005d4104: f908c277    	str	x23, [x19, #0x1180]
1005d4108: f908c676    	str	x22, [x19, #0x1188]
1005d410c: f908ca78    	str	x24, [x19, #0x1190]
1005d4110: 53001ce0    	uxtb	w0, w7
1005d4114: f908d260    	str	x0, [x19, #0x11a0]
1005d4118: f908ee68    	str	x8, [x19, #0x11d8]
1005d411c: f908f665    	str	x5, [x19, #0x11e8]
1005d4120: f909066a    	str	x10, [x19, #0x1208]
1005d4124: f9090a6f    	str	x15, [x19, #0x1210]
1005d4128: f925c66b    	str	x11, [x19, #0x4b88]
1005d412c: 52834f81    	mov	w1, #0x1a7c             ; =6780
1005d4130: 72a00021    	movk	w1, #0x1, lsl #16
1005d4134: cb010061    	sub	x1, x3, x1
1005d4138: f925ca61    	str	x1, [x19, #0x4b90]
1005d413c: f925ce64    	str	x4, [x19, #0x4b98]
1005d4140: f84783f5    	ldur	x21, [sp, #0x78]
1005d4144: f928ee75    	str	x21, [x19, #0x51d8]
1005d4148: f84083f5    	ldur	x21, [sp, #0x8]
1005d414c: f928fe75    	str	x21, [x19, #0x51f8]
1005d4150: f9294262    	str	x2, [x19, #0x5280]
1005d4154: f84203ed    	ldur	x13, [sp, #0x20]
1005d4158: f929466d    	str	x13, [x19, #0x5288]
1005d415c: f84283e0    	ldur	x0, [sp, #0x28]
1005d4160: f9294a60    	str	x0, [x19, #0x5290]
1005d4164: f84103e0    	ldur	x0, [sp, #0x10]
1005d4168: cb010001    	sub	x1, x0, x1
1005d416c: d29e9380    	mov	x0, #0xf49c             ; =62620
1005d4170: 9b008440    	msub	x0, x2, x0, x1
1005d4174: f9294e60    	str	x0, [x19, #0x5298]
1005d4178: f84303e5    	ldur	x5, [sp, #0x30]
1005d417c: f9295265    	str	x5, [x19, #0x52a0]
1005d4180: f84383e9    	ldur	x9, [sp, #0x38]
1005d4184: f9295669    	str	x9, [x19, #0x52a8]
1005d4188: f84403ef    	ldur	x15, [sp, #0x40]
1005d418c: f9295e6f    	str	x15, [x19, #0x52b8]
1005d4190: f84483e8    	ldur	x8, [sp, #0x48]
1005d4194: f9296268    	str	x8, [x19, #0x52c0]
1005d4198: f84503ed    	ldur	x13, [sp, #0x50]
1005d419c: f9296a6d    	str	x13, [x19, #0x52d0]
1005d41a0: f84583e1    	ldur	x1, [sp, #0x58]
1005d41a4: f9296e61    	str	x1, [x19, #0x52d8]
1005d41a8: f9297666    	str	x6, [x19, #0x52e8]
1005d41ac: f9297a6e    	str	x14, [x19, #0x52f0]
1005d41b0: 14000486    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d41b4: d280748c    	mov	x12, #0x3a4             ; =932
1005d41b8: f900274c    	str	x12, [x26, #0x48]
1005d41bc: d2800020    	mov	x0, #0x1                ; =1
1005d41c0: f80983e0    	stur	x0, [sp, #0x98]
1005d41c4: f9001a60    	str	x0, [x19, #0x30]
1005d41c8: f84c03ed    	ldur	x13, [sp, #0xc0]
1005d41cc: f900226d    	str	x13, [x19, #0x40]
1005d41d0: d280006c    	mov	x12, #0x3               ; =3
1005d41d4: f900266c    	str	x12, [x19, #0x48]
1005d41d8: d28000cc    	mov	x12, #0x6               ; =6
1005d41dc: f900326c    	str	x12, [x19, #0x60]
1005d41e0: d280030c    	mov	x12, #0x18              ; =24
1005d41e4: f900426c    	str	x12, [x19, #0x80]
1005d41e8: d280000c    	mov	x12, #0x0               ; =0
1005d41ec: f900c66c    	str	x12, [x19, #0x188]
1005d41f0: f900ca60    	str	x0, [x19, #0x190]
1005d41f4: f9078a74    	str	x20, [x19, #0xf10]
1005d41f8: f9078e7b    	str	x27, [x19, #0xf18]
1005d41fc: f84e03f4    	ldur	x20, [sp, #0xe0]
1005d4200: 53001e8c    	uxtb	w12, w20
1005d4204: f9079a6c    	str	x12, [x19, #0xf30]
1005d4208: f907d679    	str	x25, [x19, #0xfa8]
1005d420c: f907da78    	str	x24, [x19, #0xfb0]
1005d4210: f84d03f4    	ldur	x20, [sp, #0xd0]
1005d4214: 53001e80    	uxtb	w0, w20
1005d4218: f907e660    	str	x0, [x19, #0xfc8]
1005d421c: f9081a79    	str	x25, [x19, #0x1030]
1005d4220: f9081e7c    	str	x28, [x19, #0x1038]
1005d4224: f9082278    	str	x24, [x19, #0x1040]
1005d4228: 53001ea0    	uxtb	w0, w21
1005d422c: f9082e60    	str	x0, [x19, #0x1058]
1005d4230: f9086679    	str	x25, [x19, #0x10c8]
1005d4234: f9086a7c    	str	x28, [x19, #0x10d0]
1005d4238: f9086e77    	str	x23, [x19, #0x10d8]
1005d423c: f9087278    	str	x24, [x19, #0x10e0]
1005d4240: 53001d20    	uxtb	w0, w9
1005d4244: f9087e60    	str	x0, [x19, #0x10f8]
1005d4248: f908ba79    	str	x25, [x19, #0x1170]
1005d424c: f908be7c    	str	x28, [x19, #0x1178]
1005d4250: f908c277    	str	x23, [x19, #0x1180]
1005d4254: f908c676    	str	x22, [x19, #0x1188]
1005d4258: f908ca78    	str	x24, [x19, #0x1190]
1005d425c: 53001ce0    	uxtb	w0, w7
1005d4260: f908d260    	str	x0, [x19, #0x11a0]
1005d4264: f908ee68    	str	x8, [x19, #0x11d8]
1005d4268: f908f665    	str	x5, [x19, #0x11e8]
1005d426c: f909066a    	str	x10, [x19, #0x1208]
1005d4270: 9b0f7d00    	mul	x0, x8, x15
1005d4274: f9090e60    	str	x0, [x19, #0x1218]
1005d4278: f925c66b    	str	x11, [x19, #0x4b88]
1005d427c: 52834f81    	mov	w1, #0x1a7c             ; =6780
1005d4280: 72a00021    	movk	w1, #0x1, lsl #16
1005d4284: cb010061    	sub	x1, x3, x1
1005d4288: f925ca61    	str	x1, [x19, #0x4b90]
1005d428c: f925ce64    	str	x4, [x19, #0x4b98]
1005d4290: f84783f5    	ldur	x21, [sp, #0x78]
1005d4294: f928ee75    	str	x21, [x19, #0x51d8]
1005d4298: f84083f5    	ldur	x21, [sp, #0x8]
1005d429c: f928fe75    	str	x21, [x19, #0x51f8]
1005d42a0: f9294262    	str	x2, [x19, #0x5280]
1005d42a4: f84203ed    	ldur	x13, [sp, #0x20]
1005d42a8: f929466d    	str	x13, [x19, #0x5288]
1005d42ac: f84283e5    	ldur	x5, [sp, #0x28]
1005d42b0: f9294a65    	str	x5, [x19, #0x5290]
1005d42b4: f84103e0    	ldur	x0, [sp, #0x10]
1005d42b8: cb010001    	sub	x1, x0, x1
1005d42bc: d29e9380    	mov	x0, #0xf49c             ; =62620
1005d42c0: 9b008440    	msub	x0, x2, x0, x1
1005d42c4: f9294e60    	str	x0, [x19, #0x5298]
1005d42c8: f84303e5    	ldur	x5, [sp, #0x30]
1005d42cc: f9295265    	str	x5, [x19, #0x52a0]
1005d42d0: f84383e9    	ldur	x9, [sp, #0x38]
1005d42d4: f9295669    	str	x9, [x19, #0x52a8]
1005d42d8: f84403ef    	ldur	x15, [sp, #0x40]
1005d42dc: f9295e6f    	str	x15, [x19, #0x52b8]
1005d42e0: f84483e8    	ldur	x8, [sp, #0x48]
1005d42e4: f9296268    	str	x8, [x19, #0x52c0]
1005d42e8: f84503ed    	ldur	x13, [sp, #0x50]
1005d42ec: f9296a6d    	str	x13, [x19, #0x52d0]
1005d42f0: f84583e1    	ldur	x1, [sp, #0x58]
1005d42f4: f9296e61    	str	x1, [x19, #0x52d8]
1005d42f8: f9297666    	str	x6, [x19, #0x52e8]
1005d42fc: f9297a6e    	str	x14, [x19, #0x52f0]
1005d4300: 14000432    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d4304: d28074a0    	mov	x0, #0x3a5              ; =933
1005d4308: f9002740    	str	x0, [x26, #0x48]
1005d430c: d2800020    	mov	x0, #0x1                ; =1
1005d4310: f80983e0    	stur	x0, [sp, #0x98]
1005d4314: f9001a60    	str	x0, [x19, #0x30]
1005d4318: f84c03ed    	ldur	x13, [sp, #0xc0]
1005d431c: f900226d    	str	x13, [x19, #0x40]
1005d4320: d2800060    	mov	x0, #0x3                ; =3
1005d4324: f9002660    	str	x0, [x19, #0x48]
1005d4328: d28000c0    	mov	x0, #0x6                ; =6
1005d432c: f9003260    	str	x0, [x19, #0x60]
1005d4330: d2800300    	mov	x0, #0x18               ; =24
1005d4334: f9004260    	str	x0, [x19, #0x80]
1005d4338: d2800000    	mov	x0, #0x0                ; =0
1005d433c: f900c660    	str	x0, [x19, #0x188]
1005d4340: f84983e0    	ldur	x0, [sp, #0x98]
1005d4344: f900ca60    	str	x0, [x19, #0x190]
1005d4348: f9078a74    	str	x20, [x19, #0xf10]
1005d434c: f9078e7b    	str	x27, [x19, #0xf18]
1005d4350: f84e03f4    	ldur	x20, [sp, #0xe0]
1005d4354: 53001e8c    	uxtb	w12, w20
1005d4358: f9079a6c    	str	x12, [x19, #0xf30]
1005d435c: f907d679    	str	x25, [x19, #0xfa8]
1005d4360: f907da78    	str	x24, [x19, #0xfb0]
1005d4364: f84d03f4    	ldur	x20, [sp, #0xd0]
1005d4368: 53001e8c    	uxtb	w12, w20
1005d436c: f907e66c    	str	x12, [x19, #0xfc8]
1005d4370: f9081a79    	str	x25, [x19, #0x1030]
1005d4374: f9081e7c    	str	x28, [x19, #0x1038]
1005d4378: f9082278    	str	x24, [x19, #0x1040]
1005d437c: 53001eac    	uxtb	w12, w21
1005d4380: f9082e6c    	str	x12, [x19, #0x1058]
1005d4384: f9086679    	str	x25, [x19, #0x10c8]
1005d4388: f9086a7c    	str	x28, [x19, #0x10d0]
1005d438c: f9086e77    	str	x23, [x19, #0x10d8]
1005d4390: f9087278    	str	x24, [x19, #0x10e0]
1005d4394: 53001d2f    	uxtb	w15, w9
1005d4398: f9087e6f    	str	x15, [x19, #0x10f8]
1005d439c: f908ba79    	str	x25, [x19, #0x1170]
1005d43a0: f908be7c    	str	x28, [x19, #0x1178]
1005d43a4: f908c277    	str	x23, [x19, #0x1180]
1005d43a8: f908c676    	str	x22, [x19, #0x1188]
1005d43ac: f908ca78    	str	x24, [x19, #0x1190]
1005d43b0: 53001ce0    	uxtb	w0, w7
1005d43b4: f908d260    	str	x0, [x19, #0x11a0]
1005d43b8: f908f665    	str	x5, [x19, #0x11e8]
1005d43bc: f909066a    	str	x10, [x19, #0x1208]
1005d43c0: f9090e61    	str	x1, [x19, #0x1218]
1005d43c4: d1000900    	sub	x0, x8, #0x2
1005d43c8: f9091260    	str	x0, [x19, #0x1220]
1005d43cc: f925c66b    	str	x11, [x19, #0x4b88]
1005d43d0: 52834f81    	mov	w1, #0x1a7c             ; =6780
1005d43d4: 72a00021    	movk	w1, #0x1, lsl #16
1005d43d8: cb010061    	sub	x1, x3, x1
1005d43dc: f925ca61    	str	x1, [x19, #0x4b90]
1005d43e0: f925ce64    	str	x4, [x19, #0x4b98]
1005d43e4: f84783f5    	ldur	x21, [sp, #0x78]
1005d43e8: f928ee75    	str	x21, [x19, #0x51d8]
1005d43ec: f84083f5    	ldur	x21, [sp, #0x8]
1005d43f0: f928fe75    	str	x21, [x19, #0x51f8]
1005d43f4: f9294262    	str	x2, [x19, #0x5280]
1005d43f8: f84203ed    	ldur	x13, [sp, #0x20]
1005d43fc: f929466d    	str	x13, [x19, #0x5288]
1005d4400: f84283e0    	ldur	x0, [sp, #0x28]
1005d4404: f9294a60    	str	x0, [x19, #0x5290]
1005d4408: f84103e0    	ldur	x0, [sp, #0x10]
1005d440c: cb010001    	sub	x1, x0, x1
1005d4410: d29e9380    	mov	x0, #0xf49c             ; =62620
1005d4414: 9b008440    	msub	x0, x2, x0, x1
1005d4418: f9294e60    	str	x0, [x19, #0x5298]
1005d441c: f84303e5    	ldur	x5, [sp, #0x30]
1005d4420: f9295265    	str	x5, [x19, #0x52a0]
1005d4424: f84383e9    	ldur	x9, [sp, #0x38]
1005d4428: f9295669    	str	x9, [x19, #0x52a8]
1005d442c: f84403ef    	ldur	x15, [sp, #0x40]
1005d4430: f9295e6f    	str	x15, [x19, #0x52b8]
1005d4434: f84483e8    	ldur	x8, [sp, #0x48]
1005d4438: f9296268    	str	x8, [x19, #0x52c0]
1005d443c: f84503ed    	ldur	x13, [sp, #0x50]
1005d4440: f9296a6d    	str	x13, [x19, #0x52d0]
1005d4444: f84583e1    	ldur	x1, [sp, #0x58]
1005d4448: f9296e61    	str	x1, [x19, #0x52d8]
1005d444c: f9297666    	str	x6, [x19, #0x52e8]
1005d4450: f9297a6e    	str	x14, [x19, #0x52f0]
1005d4454: 140003dd    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d4458: d28074e0    	mov	x0, #0x3a7              ; =935
1005d445c: f9002740    	str	x0, [x26, #0x48]
1005d4460: d2800020    	mov	x0, #0x1                ; =1
1005d4464: f80983e0    	stur	x0, [sp, #0x98]
1005d4468: f9001a60    	str	x0, [x19, #0x30]
1005d446c: f84c03ed    	ldur	x13, [sp, #0xc0]
1005d4470: f900226d    	str	x13, [x19, #0x40]
1005d4474: d2800060    	mov	x0, #0x3                ; =3
1005d4478: f9002660    	str	x0, [x19, #0x48]
1005d447c: d28000c0    	mov	x0, #0x6                ; =6
1005d4480: f9003260    	str	x0, [x19, #0x60]
1005d4484: d2800300    	mov	x0, #0x18               ; =24
1005d4488: f9004260    	str	x0, [x19, #0x80]
1005d448c: d2800000    	mov	x0, #0x0                ; =0
1005d4490: f900c660    	str	x0, [x19, #0x188]
1005d4494: f84983e0    	ldur	x0, [sp, #0x98]
1005d4498: f900ca60    	str	x0, [x19, #0x190]
1005d449c: f9078a74    	str	x20, [x19, #0xf10]
1005d44a0: f9078e7b    	str	x27, [x19, #0xf18]
1005d44a4: f84e03f4    	ldur	x20, [sp, #0xe0]
1005d44a8: 53001e80    	uxtb	w0, w20
1005d44ac: f9079a60    	str	x0, [x19, #0xf30]
1005d44b0: f907d679    	str	x25, [x19, #0xfa8]
1005d44b4: f907da78    	str	x24, [x19, #0xfb0]
1005d44b8: f84d03f4    	ldur	x20, [sp, #0xd0]
1005d44bc: 53001e80    	uxtb	w0, w20
1005d44c0: f907e660    	str	x0, [x19, #0xfc8]
1005d44c4: f9081a79    	str	x25, [x19, #0x1030]
1005d44c8: f9081e7c    	str	x28, [x19, #0x1038]
1005d44cc: f9082278    	str	x24, [x19, #0x1040]
1005d44d0: 53001ea8    	uxtb	w8, w21
1005d44d4: f9082e68    	str	x8, [x19, #0x1058]
1005d44d8: f9086679    	str	x25, [x19, #0x10c8]
1005d44dc: f9086a7c    	str	x28, [x19, #0x10d0]
1005d44e0: f9086e77    	str	x23, [x19, #0x10d8]
1005d44e4: f9087278    	str	x24, [x19, #0x10e0]
1005d44e8: 53001d28    	uxtb	w8, w9
1005d44ec: f9087e68    	str	x8, [x19, #0x10f8]
1005d44f0: f908ba79    	str	x25, [x19, #0x1170]
1005d44f4: f908be7c    	str	x28, [x19, #0x1178]
1005d44f8: f908c277    	str	x23, [x19, #0x1180]
1005d44fc: f908c676    	str	x22, [x19, #0x1188]
1005d4500: f908ca78    	str	x24, [x19, #0x1190]
1005d4504: 53001cef    	uxtb	w15, w7
1005d4508: f908d26f    	str	x15, [x19, #0x11a0]
1005d450c: f908f665    	str	x5, [x19, #0x11e8]
1005d4510: f909066a    	str	x10, [x19, #0x1208]
1005d4514: f9091a61    	str	x1, [x19, #0x1230]
1005d4518: f925c66b    	str	x11, [x19, #0x4b88]
1005d451c: 52834f81    	mov	w1, #0x1a7c             ; =6780
1005d4520: 72a00021    	movk	w1, #0x1, lsl #16
1005d4524: cb010061    	sub	x1, x3, x1
1005d4528: f925ca61    	str	x1, [x19, #0x4b90]
1005d452c: f925ce64    	str	x4, [x19, #0x4b98]
1005d4530: f84783f5    	ldur	x21, [sp, #0x78]
1005d4534: f928ee75    	str	x21, [x19, #0x51d8]
1005d4538: f84083f5    	ldur	x21, [sp, #0x8]
1005d453c: f928fe75    	str	x21, [x19, #0x51f8]
1005d4540: f9294262    	str	x2, [x19, #0x5280]
1005d4544: f84203ed    	ldur	x13, [sp, #0x20]
1005d4548: f929466d    	str	x13, [x19, #0x5288]
1005d454c: f84283e0    	ldur	x0, [sp, #0x28]
1005d4550: f9294a60    	str	x0, [x19, #0x5290]
1005d4554: f84103e0    	ldur	x0, [sp, #0x10]
1005d4558: cb010001    	sub	x1, x0, x1
1005d455c: d29e9380    	mov	x0, #0xf49c             ; =62620
1005d4560: 9b008440    	msub	x0, x2, x0, x1
1005d4564: f9294e60    	str	x0, [x19, #0x5298]
1005d4568: f84303e5    	ldur	x5, [sp, #0x30]
1005d456c: f9295265    	str	x5, [x19, #0x52a0]
1005d4570: f84383e9    	ldur	x9, [sp, #0x38]
1005d4574: f9295669    	str	x9, [x19, #0x52a8]
1005d4578: f84403ef    	ldur	x15, [sp, #0x40]
1005d457c: f9295e6f    	str	x15, [x19, #0x52b8]
1005d4580: f84483e8    	ldur	x8, [sp, #0x48]
1005d4584: f9296268    	str	x8, [x19, #0x52c0]
1005d4588: f84503ed    	ldur	x13, [sp, #0x50]
1005d458c: f9296a6d    	str	x13, [x19, #0x52d0]
1005d4590: f84583e1    	ldur	x1, [sp, #0x58]
1005d4594: f9296e61    	str	x1, [x19, #0x52d8]
1005d4598: f9297666    	str	x6, [x19, #0x52e8]
1005d459c: f9297a6e    	str	x14, [x19, #0x52f0]
1005d45a0: 1400038a    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d45a4: d2807500    	mov	x0, #0x3a8              ; =936
1005d45a8: f9002740    	str	x0, [x26, #0x48]
1005d45ac: d2800020    	mov	x0, #0x1                ; =1
1005d45b0: f80983e0    	stur	x0, [sp, #0x98]
1005d45b4: f9001a60    	str	x0, [x19, #0x30]
1005d45b8: f84c03ed    	ldur	x13, [sp, #0xc0]
1005d45bc: f900226d    	str	x13, [x19, #0x40]
1005d45c0: d2800060    	mov	x0, #0x3                ; =3
1005d45c4: f9002660    	str	x0, [x19, #0x48]
1005d45c8: d28000c0    	mov	x0, #0x6                ; =6
1005d45cc: f9003260    	str	x0, [x19, #0x60]
1005d45d0: d2800300    	mov	x0, #0x18               ; =24
1005d45d4: f9004260    	str	x0, [x19, #0x80]
1005d45d8: d2800000    	mov	x0, #0x0                ; =0
1005d45dc: f900c660    	str	x0, [x19, #0x188]
1005d45e0: f84983e0    	ldur	x0, [sp, #0x98]
1005d45e4: f900ca60    	str	x0, [x19, #0x190]
1005d45e8: f9078a74    	str	x20, [x19, #0xf10]
1005d45ec: f9078e7b    	str	x27, [x19, #0xf18]
1005d45f0: f84e03f4    	ldur	x20, [sp, #0xe0]
1005d45f4: 53001e80    	uxtb	w0, w20
1005d45f8: f9079a60    	str	x0, [x19, #0xf30]
1005d45fc: f907d679    	str	x25, [x19, #0xfa8]
1005d4600: f907da78    	str	x24, [x19, #0xfb0]
1005d4604: f84d03f4    	ldur	x20, [sp, #0xd0]
1005d4608: 53001e80    	uxtb	w0, w20
1005d460c: f907e660    	str	x0, [x19, #0xfc8]
1005d4610: f9081a79    	str	x25, [x19, #0x1030]
1005d4614: f9081e7c    	str	x28, [x19, #0x1038]
1005d4618: f9082278    	str	x24, [x19, #0x1040]
1005d461c: 53001ea0    	uxtb	w0, w21
1005d4620: f9082e60    	str	x0, [x19, #0x1058]
1005d4624: f9086679    	str	x25, [x19, #0x10c8]
1005d4628: f9086a7c    	str	x28, [x19, #0x10d0]
1005d462c: f9086e77    	str	x23, [x19, #0x10d8]
1005d4630: f9087278    	str	x24, [x19, #0x10e0]
1005d4634: 53001d20    	uxtb	w0, w9
1005d4638: f9087e60    	str	x0, [x19, #0x10f8]
1005d463c: f908ba79    	str	x25, [x19, #0x1170]
1005d4640: f908be7c    	str	x28, [x19, #0x1178]
1005d4644: f908c277    	str	x23, [x19, #0x1180]
1005d4648: f908c676    	str	x22, [x19, #0x1188]
1005d464c: f908ca78    	str	x24, [x19, #0x1190]
1005d4650: 53001ce7    	uxtb	w7, w7
1005d4654: f908d267    	str	x7, [x19, #0x11a0]
1005d4658: f908f665    	str	x5, [x19, #0x11e8]
1005d465c: f9091e68    	str	x8, [x19, #0x1238]
1005d4660: f925c66b    	str	x11, [x19, #0x4b88]
1005d4664: 52834f88    	mov	w8, #0x1a7c             ; =6780
1005d4668: 72a00028    	movk	w8, #0x1, lsl #16
1005d466c: cb080068    	sub	x8, x3, x8
1005d4670: f925ca68    	str	x8, [x19, #0x4b90]
1005d4674: f925ce64    	str	x4, [x19, #0x4b98]
1005d4678: f84783f5    	ldur	x21, [sp, #0x78]
1005d467c: f928ee75    	str	x21, [x19, #0x51d8]
1005d4680: f84083f5    	ldur	x21, [sp, #0x8]
1005d4684: f928fe75    	str	x21, [x19, #0x51f8]
1005d4688: f9294262    	str	x2, [x19, #0x5280]
1005d468c: f84203ed    	ldur	x13, [sp, #0x20]
1005d4690: f929466d    	str	x13, [x19, #0x5288]
1005d4694: f84283e0    	ldur	x0, [sp, #0x28]
1005d4698: f9294a60    	str	x0, [x19, #0x5290]
1005d469c: f84103e1    	ldur	x1, [sp, #0x10]
1005d46a0: cb08002f    	sub	x15, x1, x8
1005d46a4: d29e9380    	mov	x0, #0xf49c             ; =62620
1005d46a8: 9b00bc4f    	msub	x15, x2, x0, x15
1005d46ac: f9294e6f    	str	x15, [x19, #0x5298]
1005d46b0: f84303e5    	ldur	x5, [sp, #0x30]
1005d46b4: f9295265    	str	x5, [x19, #0x52a0]
1005d46b8: f84383e9    	ldur	x9, [sp, #0x38]
1005d46bc: f9295669    	str	x9, [x19, #0x52a8]
1005d46c0: f84403ef    	ldur	x15, [sp, #0x40]
1005d46c4: f9295e6f    	str	x15, [x19, #0x52b8]
1005d46c8: f84483e8    	ldur	x8, [sp, #0x48]
1005d46cc: f9296268    	str	x8, [x19, #0x52c0]
1005d46d0: f84503ed    	ldur	x13, [sp, #0x50]
1005d46d4: f9296a6d    	str	x13, [x19, #0x52d0]
1005d46d8: f84583e1    	ldur	x1, [sp, #0x58]
1005d46dc: f9296e61    	str	x1, [x19, #0x52d8]
1005d46e0: f9297666    	str	x6, [x19, #0x52e8]
1005d46e4: f9297a6e    	str	x14, [x19, #0x52f0]
1005d46e8: 14000338    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d46ec: d2807520    	mov	x0, #0x3a9              ; =937
1005d46f0: f9002740    	str	x0, [x26, #0x48]
1005d46f4: d2800020    	mov	x0, #0x1                ; =1
1005d46f8: f80983e0    	stur	x0, [sp, #0x98]
1005d46fc: f9001a60    	str	x0, [x19, #0x30]
1005d4700: f84c03ed    	ldur	x13, [sp, #0xc0]
1005d4704: f900226d    	str	x13, [x19, #0x40]
1005d4708: d2800060    	mov	x0, #0x3                ; =3
1005d470c: f9002660    	str	x0, [x19, #0x48]
1005d4710: d28000c0    	mov	x0, #0x6                ; =6
1005d4714: f9003260    	str	x0, [x19, #0x60]
1005d4718: d2800300    	mov	x0, #0x18               ; =24
1005d471c: f9004260    	str	x0, [x19, #0x80]
1005d4720: d2800000    	mov	x0, #0x0                ; =0
1005d4724: f900c660    	str	x0, [x19, #0x188]
1005d4728: f84983e0    	ldur	x0, [sp, #0x98]
1005d472c: f900ca60    	str	x0, [x19, #0x190]
1005d4730: f9078a74    	str	x20, [x19, #0xf10]
1005d4734: f9078e7b    	str	x27, [x19, #0xf18]
1005d4738: f84e03f4    	ldur	x20, [sp, #0xe0]
1005d473c: 53001e80    	uxtb	w0, w20
1005d4740: f9079a60    	str	x0, [x19, #0xf30]
1005d4744: f907d679    	str	x25, [x19, #0xfa8]
1005d4748: f907da78    	str	x24, [x19, #0xfb0]
1005d474c: f84d03f4    	ldur	x20, [sp, #0xd0]
1005d4750: 53001e80    	uxtb	w0, w20
1005d4754: f907e660    	str	x0, [x19, #0xfc8]
1005d4758: f9081a79    	str	x25, [x19, #0x1030]
1005d475c: f9081e7c    	str	x28, [x19, #0x1038]
1005d4760: f9082278    	str	x24, [x19, #0x1040]
1005d4764: 53001ea0    	uxtb	w0, w21
1005d4768: f9082e60    	str	x0, [x19, #0x1058]
1005d476c: f9086679    	str	x25, [x19, #0x10c8]
1005d4770: f9086a7c    	str	x28, [x19, #0x10d0]
1005d4774: f9086e77    	str	x23, [x19, #0x10d8]
1005d4778: f9087278    	str	x24, [x19, #0x10e0]
1005d477c: 53001d20    	uxtb	w0, w9
1005d4780: f9087e60    	str	x0, [x19, #0x10f8]
1005d4784: f908ba79    	str	x25, [x19, #0x1170]
1005d4788: f908be7c    	str	x28, [x19, #0x1178]
1005d478c: f908c277    	str	x23, [x19, #0x1180]
1005d4790: f908c676    	str	x22, [x19, #0x1188]
1005d4794: f908ca78    	str	x24, [x19, #0x1190]
1005d4798: 53001ce0    	uxtb	w0, w7
1005d479c: f908d260    	str	x0, [x19, #0x11a0]
1005d47a0: f908f665    	str	x5, [x19, #0x11e8]
1005d47a4: f9091e68    	str	x8, [x19, #0x1238]
1005d47a8: f909226a    	str	x10, [x19, #0x1240]
1005d47ac: f925c66b    	str	x11, [x19, #0x4b88]
1005d47b0: 52834f81    	mov	w1, #0x1a7c             ; =6780
1005d47b4: 72a00021    	movk	w1, #0x1, lsl #16
1005d47b8: cb010061    	sub	x1, x3, x1
1005d47bc: f925ca61    	str	x1, [x19, #0x4b90]
1005d47c0: f925ce64    	str	x4, [x19, #0x4b98]
1005d47c4: f84783f5    	ldur	x21, [sp, #0x78]
1005d47c8: f928ee75    	str	x21, [x19, #0x51d8]
1005d47cc: f84083f5    	ldur	x21, [sp, #0x8]
1005d47d0: f928fe75    	str	x21, [x19, #0x51f8]
1005d47d4: f9294262    	str	x2, [x19, #0x5280]
1005d47d8: f84203ed    	ldur	x13, [sp, #0x20]
1005d47dc: f929466d    	str	x13, [x19, #0x5288]
1005d47e0: f84283e0    	ldur	x0, [sp, #0x28]
1005d47e4: f9294a60    	str	x0, [x19, #0x5290]
1005d47e8: f84103e0    	ldur	x0, [sp, #0x10]
1005d47ec: cb010005    	sub	x5, x0, x1
1005d47f0: d29e9387    	mov	x7, #0xf49c             ; =62620
1005d47f4: 9b079445    	msub	x5, x2, x7, x5
1005d47f8: f9294e65    	str	x5, [x19, #0x5298]
1005d47fc: f84303e5    	ldur	x5, [sp, #0x30]
1005d4800: f9295265    	str	x5, [x19, #0x52a0]
1005d4804: f84383e9    	ldur	x9, [sp, #0x38]
1005d4808: f9295669    	str	x9, [x19, #0x52a8]
1005d480c: f84403ef    	ldur	x15, [sp, #0x40]
1005d4810: f9295e6f    	str	x15, [x19, #0x52b8]
1005d4814: f84483e8    	ldur	x8, [sp, #0x48]
1005d4818: f9296268    	str	x8, [x19, #0x52c0]
1005d481c: f84503ed    	ldur	x13, [sp, #0x50]
1005d4820: f9296a6d    	str	x13, [x19, #0x52d0]
1005d4824: f84583e1    	ldur	x1, [sp, #0x58]
1005d4828: f9296e61    	str	x1, [x19, #0x52d8]
1005d482c: f9297666    	str	x6, [x19, #0x52e8]
1005d4830: f9297a6e    	str	x14, [x19, #0x52f0]
1005d4834: 140002e5    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d4838: d2807540    	mov	x0, #0x3aa              ; =938
1005d483c: f9002740    	str	x0, [x26, #0x48]
1005d4840: d2800020    	mov	x0, #0x1                ; =1
1005d4844: f80983e0    	stur	x0, [sp, #0x98]
1005d4848: f9001a60    	str	x0, [x19, #0x30]
1005d484c: f84c03ed    	ldur	x13, [sp, #0xc0]
1005d4850: f900226d    	str	x13, [x19, #0x40]
1005d4854: d2800060    	mov	x0, #0x3                ; =3
1005d4858: f9002660    	str	x0, [x19, #0x48]
1005d485c: d28000c0    	mov	x0, #0x6                ; =6
1005d4860: f9003260    	str	x0, [x19, #0x60]
1005d4864: d2800300    	mov	x0, #0x18               ; =24
1005d4868: f9004260    	str	x0, [x19, #0x80]
1005d486c: d2800000    	mov	x0, #0x0                ; =0
1005d4870: f900c660    	str	x0, [x19, #0x188]
1005d4874: f84983e0    	ldur	x0, [sp, #0x98]
1005d4878: f900ca60    	str	x0, [x19, #0x190]
1005d487c: f9078a74    	str	x20, [x19, #0xf10]
1005d4880: f9078e7b    	str	x27, [x19, #0xf18]
1005d4884: f84e03f4    	ldur	x20, [sp, #0xe0]
1005d4888: 53001e80    	uxtb	w0, w20
1005d488c: f9079a60    	str	x0, [x19, #0xf30]
1005d4890: f907d679    	str	x25, [x19, #0xfa8]
1005d4894: f907da78    	str	x24, [x19, #0xfb0]
1005d4898: f84d03f4    	ldur	x20, [sp, #0xd0]
1005d489c: 53001e80    	uxtb	w0, w20
1005d48a0: f907e660    	str	x0, [x19, #0xfc8]
1005d48a4: f9081a79    	str	x25, [x19, #0x1030]
1005d48a8: f9081e7c    	str	x28, [x19, #0x1038]
1005d48ac: f9082278    	str	x24, [x19, #0x1040]
1005d48b0: 53001ea0    	uxtb	w0, w21
1005d48b4: f9082e60    	str	x0, [x19, #0x1058]
1005d48b8: f9086679    	str	x25, [x19, #0x10c8]
1005d48bc: f9086a7c    	str	x28, [x19, #0x10d0]
1005d48c0: f9086e77    	str	x23, [x19, #0x10d8]
1005d48c4: f9087278    	str	x24, [x19, #0x10e0]
1005d48c8: 53001d20    	uxtb	w0, w9
1005d48cc: f9087e60    	str	x0, [x19, #0x10f8]
1005d48d0: f908ba79    	str	x25, [x19, #0x1170]
1005d48d4: f908be7c    	str	x28, [x19, #0x1178]
1005d48d8: f908c277    	str	x23, [x19, #0x1180]
1005d48dc: f908c676    	str	x22, [x19, #0x1188]
1005d48e0: f908ca78    	str	x24, [x19, #0x1190]
1005d48e4: 53001ce0    	uxtb	w0, w7
1005d48e8: f908d260    	str	x0, [x19, #0x11a0]
1005d48ec: f908f665    	str	x5, [x19, #0x11e8]
1005d48f0: f9091e68    	str	x8, [x19, #0x1238]
1005d48f4: 9b0a7ca0    	mul	x0, x5, x10
1005d48f8: f9092660    	str	x0, [x19, #0x1248]
1005d48fc: f925c66b    	str	x11, [x19, #0x4b88]
1005d4900: 52834f81    	mov	w1, #0x1a7c             ; =6780
1005d4904: 72a00021    	movk	w1, #0x1, lsl #16
1005d4908: cb010061    	sub	x1, x3, x1
1005d490c: f925ca61    	str	x1, [x19, #0x4b90]
1005d4910: f925ce64    	str	x4, [x19, #0x4b98]
1005d4914: f84783f5    	ldur	x21, [sp, #0x78]
1005d4918: f928ee75    	str	x21, [x19, #0x51d8]
1005d491c: f84083f5    	ldur	x21, [sp, #0x8]
1005d4920: f928fe75    	str	x21, [x19, #0x51f8]
1005d4924: f9294262    	str	x2, [x19, #0x5280]
1005d4928: f84203ed    	ldur	x13, [sp, #0x20]
1005d492c: f929466d    	str	x13, [x19, #0x5288]
1005d4930: f84283e0    	ldur	x0, [sp, #0x28]
1005d4934: f9294a60    	str	x0, [x19, #0x5290]
1005d4938: f84103e0    	ldur	x0, [sp, #0x10]
1005d493c: cb010001    	sub	x1, x0, x1
1005d4940: d29e9380    	mov	x0, #0xf49c             ; =62620
1005d4944: 9b008440    	msub	x0, x2, x0, x1
1005d4948: f9294e60    	str	x0, [x19, #0x5298]
1005d494c: f84303e5    	ldur	x5, [sp, #0x30]
1005d4950: f9295265    	str	x5, [x19, #0x52a0]
1005d4954: f84383e9    	ldur	x9, [sp, #0x38]
1005d4958: f9295669    	str	x9, [x19, #0x52a8]
1005d495c: f84403ef    	ldur	x15, [sp, #0x40]
1005d4960: f9295e6f    	str	x15, [x19, #0x52b8]
1005d4964: f84483e8    	ldur	x8, [sp, #0x48]
1005d4968: f9296268    	str	x8, [x19, #0x52c0]
1005d496c: f84503ed    	ldur	x13, [sp, #0x50]
1005d4970: f9296a6d    	str	x13, [x19, #0x52d0]
1005d4974: f84583e1    	ldur	x1, [sp, #0x58]
1005d4978: f9296e61    	str	x1, [x19, #0x52d8]
1005d497c: f9297666    	str	x6, [x19, #0x52e8]
1005d4980: f9297a6e    	str	x14, [x19, #0x52f0]
1005d4984: 14000291    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d4988: d280756c    	mov	x12, #0x3ab             ; =939
1005d498c: f900274c    	str	x12, [x26, #0x48]
1005d4990: d2800020    	mov	x0, #0x1                ; =1
1005d4994: f80983e0    	stur	x0, [sp, #0x98]
1005d4998: f9001a60    	str	x0, [x19, #0x30]
1005d499c: f84c03ed    	ldur	x13, [sp, #0xc0]
1005d49a0: f900226d    	str	x13, [x19, #0x40]
1005d49a4: d280006c    	mov	x12, #0x3               ; =3
1005d49a8: f900266c    	str	x12, [x19, #0x48]
1005d49ac: d28000cc    	mov	x12, #0x6               ; =6
1005d49b0: f900326c    	str	x12, [x19, #0x60]
1005d49b4: d280030d    	mov	x13, #0x18              ; =24
1005d49b8: f900426d    	str	x13, [x19, #0x80]
1005d49bc: d280000f    	mov	x15, #0x0               ; =0
1005d49c0: f900c66f    	str	x15, [x19, #0x188]
1005d49c4: f900ca60    	str	x0, [x19, #0x190]
1005d49c8: f9078a74    	str	x20, [x19, #0xf10]
1005d49cc: f9078e7b    	str	x27, [x19, #0xf18]
1005d49d0: f84e03f4    	ldur	x20, [sp, #0xe0]
1005d49d4: 53001e80    	uxtb	w0, w20
1005d49d8: f9079a60    	str	x0, [x19, #0xf30]
1005d49dc: f907d679    	str	x25, [x19, #0xfa8]
1005d49e0: f907da78    	str	x24, [x19, #0xfb0]
1005d49e4: f84d03f4    	ldur	x20, [sp, #0xd0]
1005d49e8: 53001e80    	uxtb	w0, w20
1005d49ec: f907e660    	str	x0, [x19, #0xfc8]
1005d49f0: f9081a79    	str	x25, [x19, #0x1030]
1005d49f4: f9081e7c    	str	x28, [x19, #0x1038]
1005d49f8: f9082278    	str	x24, [x19, #0x1040]
1005d49fc: 53001ea0    	uxtb	w0, w21
1005d4a00: f9082e60    	str	x0, [x19, #0x1058]
1005d4a04: f9086679    	str	x25, [x19, #0x10c8]
1005d4a08: f9086a7c    	str	x28, [x19, #0x10d0]
1005d4a0c: f9086e77    	str	x23, [x19, #0x10d8]
1005d4a10: f9087278    	str	x24, [x19, #0x10e0]
1005d4a14: 53001d20    	uxtb	w0, w9
1005d4a18: f9087e60    	str	x0, [x19, #0x10f8]
1005d4a1c: f908ba79    	str	x25, [x19, #0x1170]
1005d4a20: f908be7c    	str	x28, [x19, #0x1178]
1005d4a24: f908c277    	str	x23, [x19, #0x1180]
1005d4a28: f908c676    	str	x22, [x19, #0x1188]
1005d4a2c: f908ca78    	str	x24, [x19, #0x1190]
1005d4a30: 53001ce0    	uxtb	w0, w7
1005d4a34: f908d260    	str	x0, [x19, #0x11a0]
1005d4a38: f908f665    	str	x5, [x19, #0x11e8]
1005d4a3c: f9091e68    	str	x8, [x19, #0x1238]
1005d4a40: f909266a    	str	x10, [x19, #0x1248]
1005d4a44: d10008a0    	sub	x0, x5, #0x2
1005d4a48: f9092a60    	str	x0, [x19, #0x1250]
1005d4a4c: f925c66b    	str	x11, [x19, #0x4b88]
1005d4a50: 52834f81    	mov	w1, #0x1a7c             ; =6780
1005d4a54: 72a00021    	movk	w1, #0x1, lsl #16
1005d4a58: cb010061    	sub	x1, x3, x1
1005d4a5c: f925ca61    	str	x1, [x19, #0x4b90]
1005d4a60: f925ce64    	str	x4, [x19, #0x4b98]
1005d4a64: f84783f5    	ldur	x21, [sp, #0x78]
1005d4a68: f928ee75    	str	x21, [x19, #0x51d8]
1005d4a6c: f84083f5    	ldur	x21, [sp, #0x8]
1005d4a70: f928fe75    	str	x21, [x19, #0x51f8]
1005d4a74: f9294262    	str	x2, [x19, #0x5280]
1005d4a78: f84203ed    	ldur	x13, [sp, #0x20]
1005d4a7c: f929466d    	str	x13, [x19, #0x5288]
1005d4a80: f84283ed    	ldur	x13, [sp, #0x28]
1005d4a84: f9294a6d    	str	x13, [x19, #0x5290]
1005d4a88: f84103e0    	ldur	x0, [sp, #0x10]
1005d4a8c: cb010001    	sub	x1, x0, x1
1005d4a90: d29e9380    	mov	x0, #0xf49c             ; =62620
1005d4a94: 9b008440    	msub	x0, x2, x0, x1
1005d4a98: f9294e60    	str	x0, [x19, #0x5298]
1005d4a9c: f84303e5    	ldur	x5, [sp, #0x30]
1005d4aa0: f9295265    	str	x5, [x19, #0x52a0]
1005d4aa4: f84383e9    	ldur	x9, [sp, #0x38]
1005d4aa8: f9295669    	str	x9, [x19, #0x52a8]
1005d4aac: f84403ef    	ldur	x15, [sp, #0x40]
1005d4ab0: f9295e6f    	str	x15, [x19, #0x52b8]
1005d4ab4: f84483e8    	ldur	x8, [sp, #0x48]
1005d4ab8: f9296268    	str	x8, [x19, #0x52c0]
1005d4abc: f84503ed    	ldur	x13, [sp, #0x50]
1005d4ac0: f9296a6d    	str	x13, [x19, #0x52d0]
1005d4ac4: f84583e1    	ldur	x1, [sp, #0x58]
1005d4ac8: f9296e61    	str	x1, [x19, #0x52d8]
1005d4acc: f9297666    	str	x6, [x19, #0x52e8]
1005d4ad0: f9297a6e    	str	x14, [x19, #0x52f0]
1005d4ad4: 1400023d    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d4ad8: d2807580    	mov	x0, #0x3ac              ; =940
1005d4adc: f9002740    	str	x0, [x26, #0x48]
1005d4ae0: d2800020    	mov	x0, #0x1                ; =1
1005d4ae4: f80983e0    	stur	x0, [sp, #0x98]
1005d4ae8: f9001a60    	str	x0, [x19, #0x30]
1005d4aec: f84c03ed    	ldur	x13, [sp, #0xc0]
1005d4af0: f900226d    	str	x13, [x19, #0x40]
1005d4af4: d280006c    	mov	x12, #0x3               ; =3
1005d4af8: f900266c    	str	x12, [x19, #0x48]
1005d4afc: d28000cc    	mov	x12, #0x6               ; =6
1005d4b00: f900326c    	str	x12, [x19, #0x60]
1005d4b04: d280030c    	mov	x12, #0x18              ; =24
1005d4b08: f900426c    	str	x12, [x19, #0x80]
1005d4b0c: d280000c    	mov	x12, #0x0               ; =0
1005d4b10: f900c66c    	str	x12, [x19, #0x188]
1005d4b14: f900ca60    	str	x0, [x19, #0x190]
1005d4b18: f9078a74    	str	x20, [x19, #0xf10]
1005d4b1c: f9078e7b    	str	x27, [x19, #0xf18]
1005d4b20: f84e03f4    	ldur	x20, [sp, #0xe0]
1005d4b24: 53001e8c    	uxtb	w12, w20
1005d4b28: f9079a6c    	str	x12, [x19, #0xf30]
1005d4b2c: f907d679    	str	x25, [x19, #0xfa8]
1005d4b30: f907da78    	str	x24, [x19, #0xfb0]
1005d4b34: f84d03f4    	ldur	x20, [sp, #0xd0]
1005d4b38: 53001e8c    	uxtb	w12, w20
1005d4b3c: f907e66c    	str	x12, [x19, #0xfc8]
1005d4b40: f9081a79    	str	x25, [x19, #0x1030]
1005d4b44: f9081e7c    	str	x28, [x19, #0x1038]
1005d4b48: f9082278    	str	x24, [x19, #0x1040]
1005d4b4c: 53001ea0    	uxtb	w0, w21
1005d4b50: f9082e60    	str	x0, [x19, #0x1058]
1005d4b54: f9086679    	str	x25, [x19, #0x10c8]
1005d4b58: f9086a7c    	str	x28, [x19, #0x10d0]
1005d4b5c: f9086e77    	str	x23, [x19, #0x10d8]
1005d4b60: f9087278    	str	x24, [x19, #0x10e0]
1005d4b64: 53001d20    	uxtb	w0, w9
1005d4b68: f9087e60    	str	x0, [x19, #0x10f8]
1005d4b6c: f908ba79    	str	x25, [x19, #0x1170]
1005d4b70: f908be7c    	str	x28, [x19, #0x1178]
1005d4b74: f908c277    	str	x23, [x19, #0x1180]
1005d4b78: f908c676    	str	x22, [x19, #0x1188]
1005d4b7c: f908ca78    	str	x24, [x19, #0x1190]
1005d4b80: 53001ce0    	uxtb	w0, w7
1005d4b84: f908d260    	str	x0, [x19, #0x11a0]
1005d4b88: f908f665    	str	x5, [x19, #0x11e8]
1005d4b8c: f9091e68    	str	x8, [x19, #0x1238]
1005d4b90: d10008a0    	sub	x0, x5, #0x2
1005d4b94: 9b007d40    	mul	x0, x10, x0
1005d4b98: f9092e60    	str	x0, [x19, #0x1258]
1005d4b9c: f925c66b    	str	x11, [x19, #0x4b88]
1005d4ba0: 52834f81    	mov	w1, #0x1a7c             ; =6780
1005d4ba4: 72a00021    	movk	w1, #0x1, lsl #16
1005d4ba8: cb010061    	sub	x1, x3, x1
1005d4bac: f925ca61    	str	x1, [x19, #0x4b90]
1005d4bb0: f925ce64    	str	x4, [x19, #0x4b98]
1005d4bb4: f84783f5    	ldur	x21, [sp, #0x78]
1005d4bb8: f928ee75    	str	x21, [x19, #0x51d8]
1005d4bbc: f84083f5    	ldur	x21, [sp, #0x8]
1005d4bc0: f928fe75    	str	x21, [x19, #0x51f8]
1005d4bc4: f9294262    	str	x2, [x19, #0x5280]
1005d4bc8: f84203ed    	ldur	x13, [sp, #0x20]
1005d4bcc: f929466d    	str	x13, [x19, #0x5288]
1005d4bd0: f84283e0    	ldur	x0, [sp, #0x28]
1005d4bd4: f9294a60    	str	x0, [x19, #0x5290]
1005d4bd8: f84103e5    	ldur	x5, [sp, #0x10]
1005d4bdc: cb0100a1    	sub	x1, x5, x1
1005d4be0: d29e9380    	mov	x0, #0xf49c             ; =62620
1005d4be4: 9b008440    	msub	x0, x2, x0, x1
1005d4be8: f9294e60    	str	x0, [x19, #0x5298]
1005d4bec: f84303e5    	ldur	x5, [sp, #0x30]
1005d4bf0: f9295265    	str	x5, [x19, #0x52a0]
1005d4bf4: f84383e9    	ldur	x9, [sp, #0x38]
1005d4bf8: f9295669    	str	x9, [x19, #0x52a8]
1005d4bfc: f84403ef    	ldur	x15, [sp, #0x40]
1005d4c00: f9295e6f    	str	x15, [x19, #0x52b8]
1005d4c04: f84483e8    	ldur	x8, [sp, #0x48]
1005d4c08: f9296268    	str	x8, [x19, #0x52c0]
1005d4c0c: f84503ed    	ldur	x13, [sp, #0x50]
1005d4c10: f9296a6d    	str	x13, [x19, #0x52d0]
1005d4c14: f84583e1    	ldur	x1, [sp, #0x58]
1005d4c18: f9296e61    	str	x1, [x19, #0x52d8]
1005d4c1c: f9297666    	str	x6, [x19, #0x52e8]
1005d4c20: f9297a6e    	str	x14, [x19, #0x52f0]
1005d4c24: 140001e9    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d4c28: d28075a0    	mov	x0, #0x3ad              ; =941
1005d4c2c: f9002740    	str	x0, [x26, #0x48]
1005d4c30: d2800020    	mov	x0, #0x1                ; =1
1005d4c34: f80983e0    	stur	x0, [sp, #0x98]
1005d4c38: f9001a60    	str	x0, [x19, #0x30]
1005d4c3c: f84c03ed    	ldur	x13, [sp, #0xc0]
1005d4c40: f900226d    	str	x13, [x19, #0x40]
1005d4c44: d2800060    	mov	x0, #0x3                ; =3
1005d4c48: f9002660    	str	x0, [x19, #0x48]
1005d4c4c: d28000c0    	mov	x0, #0x6                ; =6
1005d4c50: f9003260    	str	x0, [x19, #0x60]
1005d4c54: d2800300    	mov	x0, #0x18               ; =24
1005d4c58: f9004260    	str	x0, [x19, #0x80]
1005d4c5c: d2800000    	mov	x0, #0x0                ; =0
1005d4c60: f900c660    	str	x0, [x19, #0x188]
1005d4c64: f84983e0    	ldur	x0, [sp, #0x98]
1005d4c68: f900ca60    	str	x0, [x19, #0x190]
1005d4c6c: f9078a74    	str	x20, [x19, #0xf10]
1005d4c70: f9078e7b    	str	x27, [x19, #0xf18]
1005d4c74: f84e03f4    	ldur	x20, [sp, #0xe0]
1005d4c78: 53001e80    	uxtb	w0, w20
1005d4c7c: f9079a60    	str	x0, [x19, #0xf30]
1005d4c80: f907d679    	str	x25, [x19, #0xfa8]
1005d4c84: f907da78    	str	x24, [x19, #0xfb0]
1005d4c88: f84d03f4    	ldur	x20, [sp, #0xd0]
1005d4c8c: 53001e8a    	uxtb	w10, w20
1005d4c90: f907e66a    	str	x10, [x19, #0xfc8]
1005d4c94: f9081a79    	str	x25, [x19, #0x1030]
1005d4c98: f9081e7c    	str	x28, [x19, #0x1038]
1005d4c9c: f9082278    	str	x24, [x19, #0x1040]
1005d4ca0: 53001eaa    	uxtb	w10, w21
1005d4ca4: f9082e6a    	str	x10, [x19, #0x1058]
1005d4ca8: f9086679    	str	x25, [x19, #0x10c8]
1005d4cac: f9086a7c    	str	x28, [x19, #0x10d0]
1005d4cb0: f9086e77    	str	x23, [x19, #0x10d8]
1005d4cb4: f9087278    	str	x24, [x19, #0x10e0]
1005d4cb8: 53001d2c    	uxtb	w12, w9
1005d4cbc: f9087e6c    	str	x12, [x19, #0x10f8]
1005d4cc0: f908ba79    	str	x25, [x19, #0x1170]
1005d4cc4: f908be7c    	str	x28, [x19, #0x1178]
1005d4cc8: f908c277    	str	x23, [x19, #0x1180]
1005d4ccc: f908c676    	str	x22, [x19, #0x1188]
1005d4cd0: f908ca78    	str	x24, [x19, #0x1190]
1005d4cd4: 53001ce0    	uxtb	w0, w7
1005d4cd8: f908d260    	str	x0, [x19, #0x11a0]
1005d4cdc: f9091e68    	str	x8, [x19, #0x1238]
1005d4ce0: f9092e61    	str	x1, [x19, #0x1258]
1005d4ce4: f9093265    	str	x5, [x19, #0x1260]
1005d4ce8: f925c66b    	str	x11, [x19, #0x4b88]
1005d4cec: 52834f81    	mov	w1, #0x1a7c             ; =6780
1005d4cf0: 72a00021    	movk	w1, #0x1, lsl #16
1005d4cf4: cb010061    	sub	x1, x3, x1
1005d4cf8: f925ca61    	str	x1, [x19, #0x4b90]
1005d4cfc: f925ce64    	str	x4, [x19, #0x4b98]
1005d4d00: f84783f5    	ldur	x21, [sp, #0x78]
1005d4d04: f928ee75    	str	x21, [x19, #0x51d8]
1005d4d08: f84083f5    	ldur	x21, [sp, #0x8]
1005d4d0c: f928fe75    	str	x21, [x19, #0x51f8]
1005d4d10: f9294262    	str	x2, [x19, #0x5280]
1005d4d14: f84203ed    	ldur	x13, [sp, #0x20]
1005d4d18: f929466d    	str	x13, [x19, #0x5288]
1005d4d1c: f84283e0    	ldur	x0, [sp, #0x28]
1005d4d20: f9294a60    	str	x0, [x19, #0x5290]
1005d4d24: f84103e0    	ldur	x0, [sp, #0x10]
1005d4d28: cb010001    	sub	x1, x0, x1
1005d4d2c: d29e9380    	mov	x0, #0xf49c             ; =62620
1005d4d30: 9b008440    	msub	x0, x2, x0, x1
1005d4d34: f9294e60    	str	x0, [x19, #0x5298]
1005d4d38: f84303e5    	ldur	x5, [sp, #0x30]
1005d4d3c: f9295265    	str	x5, [x19, #0x52a0]
1005d4d40: f84383e9    	ldur	x9, [sp, #0x38]
1005d4d44: f9295669    	str	x9, [x19, #0x52a8]
1005d4d48: f84403ef    	ldur	x15, [sp, #0x40]
1005d4d4c: f9295e6f    	str	x15, [x19, #0x52b8]
1005d4d50: f84483e8    	ldur	x8, [sp, #0x48]
1005d4d54: f9296268    	str	x8, [x19, #0x52c0]
1005d4d58: f84503ed    	ldur	x13, [sp, #0x50]
1005d4d5c: f9296a6d    	str	x13, [x19, #0x52d0]
1005d4d60: f84583e1    	ldur	x1, [sp, #0x58]
1005d4d64: f9296e61    	str	x1, [x19, #0x52d8]
1005d4d68: f9297666    	str	x6, [x19, #0x52e8]
1005d4d6c: f9297a6e    	str	x14, [x19, #0x52f0]
1005d4d70: 14000196    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d4d74: d28075e0    	mov	x0, #0x3af              ; =943
1005d4d78: f9002740    	str	x0, [x26, #0x48]
1005d4d7c: d2800020    	mov	x0, #0x1                ; =1
1005d4d80: f80983e0    	stur	x0, [sp, #0x98]
1005d4d84: f9001a60    	str	x0, [x19, #0x30]
1005d4d88: f84c03ed    	ldur	x13, [sp, #0xc0]
1005d4d8c: f900226d    	str	x13, [x19, #0x40]
1005d4d90: d2800060    	mov	x0, #0x3                ; =3
1005d4d94: f9002660    	str	x0, [x19, #0x48]
1005d4d98: d28000c0    	mov	x0, #0x6                ; =6
1005d4d9c: f9003260    	str	x0, [x19, #0x60]
1005d4da0: d2800300    	mov	x0, #0x18               ; =24
1005d4da4: f9004260    	str	x0, [x19, #0x80]
1005d4da8: d2800000    	mov	x0, #0x0                ; =0
1005d4dac: f900c660    	str	x0, [x19, #0x188]
1005d4db0: f84983e0    	ldur	x0, [sp, #0x98]
1005d4db4: f900ca60    	str	x0, [x19, #0x190]
1005d4db8: f9078a74    	str	x20, [x19, #0xf10]
1005d4dbc: f9078e7b    	str	x27, [x19, #0xf18]
1005d4dc0: f84e03f4    	ldur	x20, [sp, #0xe0]
1005d4dc4: 53001e80    	uxtb	w0, w20
1005d4dc8: f9079a60    	str	x0, [x19, #0xf30]
1005d4dcc: f907d679    	str	x25, [x19, #0xfa8]
1005d4dd0: f907da78    	str	x24, [x19, #0xfb0]
1005d4dd4: f84d03f4    	ldur	x20, [sp, #0xd0]
1005d4dd8: 53001e80    	uxtb	w0, w20
1005d4ddc: f907e660    	str	x0, [x19, #0xfc8]
1005d4de0: f9081a79    	str	x25, [x19, #0x1030]
1005d4de4: f9081e7c    	str	x28, [x19, #0x1038]
1005d4de8: f9082278    	str	x24, [x19, #0x1040]
1005d4dec: 53001ea0    	uxtb	w0, w21
1005d4df0: f9082e60    	str	x0, [x19, #0x1058]
1005d4df4: f9086679    	str	x25, [x19, #0x10c8]
1005d4df8: f9086a7c    	str	x28, [x19, #0x10d0]
1005d4dfc: f9086e77    	str	x23, [x19, #0x10d8]
1005d4e00: f9087278    	str	x24, [x19, #0x10e0]
1005d4e04: 53001d25    	uxtb	w5, w9
1005d4e08: f9087e65    	str	x5, [x19, #0x10f8]
1005d4e0c: f908ba79    	str	x25, [x19, #0x1170]
1005d4e10: f908be7c    	str	x28, [x19, #0x1178]
1005d4e14: f908c277    	str	x23, [x19, #0x1180]
1005d4e18: f908c676    	str	x22, [x19, #0x1188]
1005d4e1c: f908ca78    	str	x24, [x19, #0x1190]
1005d4e20: 53001ce9    	uxtb	w9, w7
1005d4e24: f908d269    	str	x9, [x19, #0x11a0]
1005d4e28: f9091e68    	str	x8, [x19, #0x1238]
1005d4e2c: f9093a61    	str	x1, [x19, #0x1270]
1005d4e30: f925c66b    	str	x11, [x19, #0x4b88]
1005d4e34: 52834f8d    	mov	w13, #0x1a7c            ; =6780
1005d4e38: 72a0002d    	movk	w13, #0x1, lsl #16
1005d4e3c: cb0d006d    	sub	x13, x3, x13
1005d4e40: f925ca6d    	str	x13, [x19, #0x4b90]
1005d4e44: f925ce64    	str	x4, [x19, #0x4b98]
1005d4e48: f84783f5    	ldur	x21, [sp, #0x78]
1005d4e4c: f928ee75    	str	x21, [x19, #0x51d8]
1005d4e50: f84083f5    	ldur	x21, [sp, #0x8]
1005d4e54: f928fe75    	str	x21, [x19, #0x51f8]
1005d4e58: f9294262    	str	x2, [x19, #0x5280]
1005d4e5c: f84203ef    	ldur	x15, [sp, #0x20]
1005d4e60: f929466f    	str	x15, [x19, #0x5288]
1005d4e64: f84283e0    	ldur	x0, [sp, #0x28]
1005d4e68: f9294a60    	str	x0, [x19, #0x5290]
1005d4e6c: f84103e1    	ldur	x1, [sp, #0x10]
1005d4e70: cb0d0021    	sub	x1, x1, x13
1005d4e74: d29e9380    	mov	x0, #0xf49c             ; =62620
1005d4e78: 9b008440    	msub	x0, x2, x0, x1
1005d4e7c: f9294e60    	str	x0, [x19, #0x5298]
1005d4e80: f84303e5    	ldur	x5, [sp, #0x30]
1005d4e84: f9295265    	str	x5, [x19, #0x52a0]
1005d4e88: f84383e9    	ldur	x9, [sp, #0x38]
1005d4e8c: f9295669    	str	x9, [x19, #0x52a8]
1005d4e90: f84403ef    	ldur	x15, [sp, #0x40]
1005d4e94: f9295e6f    	str	x15, [x19, #0x52b8]
1005d4e98: f84483e8    	ldur	x8, [sp, #0x48]
1005d4e9c: f9296268    	str	x8, [x19, #0x52c0]
1005d4ea0: f84503ed    	ldur	x13, [sp, #0x50]
1005d4ea4: f9296a6d    	str	x13, [x19, #0x52d0]
1005d4ea8: f84583e1    	ldur	x1, [sp, #0x58]
1005d4eac: f9296e61    	str	x1, [x19, #0x52d8]
1005d4eb0: f9297666    	str	x6, [x19, #0x52e8]
1005d4eb4: f9297a6e    	str	x14, [x19, #0x52f0]
1005d4eb8: 14000144    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d4ebc: d2807600    	mov	x0, #0x3b0              ; =944
1005d4ec0: f9002740    	str	x0, [x26, #0x48]
1005d4ec4: d2800000    	mov	x0, #0x0                ; =0
1005d4ec8: f925c660    	str	x0, [x19, #0x4b88]
1005d4ecc: d2800060    	mov	x0, #0x3                ; =3
1005d4ed0: f94093e5    	ldr	x5, [sp, #0x120]
1005d4ed4: f80983e0    	stur	x0, [sp, #0x98]
1005d4ed8: f101d8bf    	cmp	x5, #0x76
1005d4edc: 54fed2a2    	b.hs	0x1005d2930 <_mech_canonical_program_entry_v1_numeric_801+0x1fb0>
1005d4ee0: 1400013a    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d4ee4: f84c03e0    	ldur	x0, [sp, #0xc0]
1005d4ee8: f80983e0    	stur	x0, [sp, #0x98]
1005d4eec: 14000137    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d4ef0: d2807f40    	mov	x0, #0x3fa              ; =1018
1005d4ef4: f9002740    	str	x0, [x26, #0x48]
1005d4ef8: d2800000    	mov	x0, #0x0                ; =0
1005d4efc: f925c660    	str	x0, [x19, #0x4b88]
1005d4f00: d2800060    	mov	x0, #0x3                ; =3
1005d4f04: f94093e5    	ldr	x5, [sp, #0x120]
1005d4f08: f80983e0    	stur	x0, [sp, #0x98]
1005d4f0c: f101d8bf    	cmp	x5, #0x76
1005d4f10: 54fee8a2    	b.hs	0x1005d2c24 <_mech_canonical_program_entry_v1_numeric_801+0x22a4>
1005d4f14: 1400012d    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d4f18: d2808060    	mov	x0, #0x403              ; =1027
1005d4f1c: f9002740    	str	x0, [x26, #0x48]
1005d4f20: d2800020    	mov	x0, #0x1                ; =1
1005d4f24: f80983e0    	stur	x0, [sp, #0x98]
1005d4f28: f9001a60    	str	x0, [x19, #0x30]
1005d4f2c: d2800040    	mov	x0, #0x2                ; =2
1005d4f30: f9002260    	str	x0, [x19, #0x40]
1005d4f34: d2800060    	mov	x0, #0x3                ; =3
1005d4f38: f9002660    	str	x0, [x19, #0x48]
1005d4f3c: d28000c0    	mov	x0, #0x6                ; =6
1005d4f40: f9003260    	str	x0, [x19, #0x60]
1005d4f44: d2800300    	mov	x0, #0x18               ; =24
1005d4f48: f9004260    	str	x0, [x19, #0x80]
1005d4f4c: d2800000    	mov	x0, #0x0                ; =0
1005d4f50: f900c660    	str	x0, [x19, #0x188]
1005d4f54: f84983e0    	ldur	x0, [sp, #0x98]
1005d4f58: f900ca60    	str	x0, [x19, #0x190]
1005d4f5c: f9078a76    	str	x22, [x19, #0xf10]
1005d4f60: f9078e7b    	str	x27, [x19, #0xf18]
1005d4f64: f925c66b    	str	x11, [x19, #0x4b88]
1005d4f68: f925ca63    	str	x3, [x19, #0x4b90]
1005d4f6c: f925ce64    	str	x4, [x19, #0x4b98]
1005d4f70: f84783f5    	ldur	x21, [sp, #0x78]
1005d4f74: f928ee75    	str	x21, [x19, #0x51d8]
1005d4f78: f84083f5    	ldur	x21, [sp, #0x8]
1005d4f7c: f928fe75    	str	x21, [x19, #0x51f8]
1005d4f80: f9294262    	str	x2, [x19, #0x5280]
1005d4f84: f84203e0    	ldur	x0, [sp, #0x20]
1005d4f88: f9294660    	str	x0, [x19, #0x5288]
1005d4f8c: f84283e0    	ldur	x0, [sp, #0x28]
1005d4f90: f9294a60    	str	x0, [x19, #0x5290]
1005d4f94: f84103e1    	ldur	x1, [sp, #0x10]
1005d4f98: cb030023    	sub	x3, x1, x3
1005d4f9c: d29e9384    	mov	x4, #0xf49c             ; =62620
1005d4fa0: 9b048c42    	msub	x2, x2, x4, x3
1005d4fa4: f9294e62    	str	x2, [x19, #0x5298]
1005d4fa8: f929526c    	str	x12, [x19, #0x52a0]
1005d4fac: f929566a    	str	x10, [x19, #0x52a8]
1005d4fb0: f9295e68    	str	x8, [x19, #0x52b8]
1005d4fb4: f929627c    	str	x28, [x19, #0x52c0]
1005d4fb8: f9296a69    	str	x9, [x19, #0x52d0]
1005d4fbc: f9296e77    	str	x23, [x19, #0x52d8]
1005d4fc0: f929766e    	str	x14, [x19, #0x52e8]
1005d4fc4: f9297a6d    	str	x13, [x19, #0x52f0]
1005d4fc8: 14000100    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d4fcc: d2807d20    	mov	x0, #0x3e9              ; =1001
1005d4fd0: f9002740    	str	x0, [x26, #0x48]
1005d4fd4: d2800020    	mov	x0, #0x1                ; =1
1005d4fd8: f80983e0    	stur	x0, [sp, #0x98]
1005d4fdc: f9001a60    	str	x0, [x19, #0x30]
1005d4fe0: d2800040    	mov	x0, #0x2                ; =2
1005d4fe4: f9002260    	str	x0, [x19, #0x40]
1005d4fe8: d2800060    	mov	x0, #0x3                ; =3
1005d4fec: f9002660    	str	x0, [x19, #0x48]
1005d4ff0: d28000c0    	mov	x0, #0x6                ; =6
1005d4ff4: f9003260    	str	x0, [x19, #0x60]
1005d4ff8: d2800300    	mov	x0, #0x18               ; =24
1005d4ffc: f9004260    	str	x0, [x19, #0x80]
1005d5000: d2800000    	mov	x0, #0x0                ; =0
1005d5004: f900c660    	str	x0, [x19, #0x188]
1005d5008: f84983e0    	ldur	x0, [sp, #0x98]
1005d500c: f900ca60    	str	x0, [x19, #0x190]
1005d5010: f9078a74    	str	x20, [x19, #0xf10]
1005d5014: f9078e7b    	str	x27, [x19, #0xf18]
1005d5018: f84e03f4    	ldur	x20, [sp, #0xe0]
1005d501c: 53001e80    	uxtb	w0, w20
1005d5020: f9079a60    	str	x0, [x19, #0xf30]
1005d5024: f907d679    	str	x25, [x19, #0xfa8]
1005d5028: f907da78    	str	x24, [x19, #0xfb0]
1005d502c: f925c66b    	str	x11, [x19, #0x4b88]
1005d5030: f925ca63    	str	x3, [x19, #0x4b90]
1005d5034: f925ce64    	str	x4, [x19, #0x4b98]
1005d5038: f84783f5    	ldur	x21, [sp, #0x78]
1005d503c: f928ee75    	str	x21, [x19, #0x51d8]
1005d5040: f84083f5    	ldur	x21, [sp, #0x8]
1005d5044: f928fe75    	str	x21, [x19, #0x51f8]
1005d5048: f9294262    	str	x2, [x19, #0x5280]
1005d504c: f84203e0    	ldur	x0, [sp, #0x20]
1005d5050: f9294660    	str	x0, [x19, #0x5288]
1005d5054: f84283ef    	ldur	x15, [sp, #0x28]
1005d5058: f9294a6f    	str	x15, [x19, #0x5290]
1005d505c: f84103e1    	ldur	x1, [sp, #0x10]
1005d5060: cb030020    	sub	x0, x1, x3
1005d5064: d29e9381    	mov	x1, #0xf49c             ; =62620
1005d5068: 9b018040    	msub	x0, x2, x1, x0
1005d506c: f9294e60    	str	x0, [x19, #0x5298]
1005d5070: f84303e5    	ldur	x5, [sp, #0x30]
1005d5074: f9295265    	str	x5, [x19, #0x52a0]
1005d5078: f84383ef    	ldur	x15, [sp, #0x38]
1005d507c: f929566f    	str	x15, [x19, #0x52a8]
1005d5080: f9295e68    	str	x8, [x19, #0x52b8]
1005d5084: f929627c    	str	x28, [x19, #0x52c0]
1005d5088: f9296a69    	str	x9, [x19, #0x52d0]
1005d508c: f9296e77    	str	x23, [x19, #0x52d8]
1005d5090: f929766e    	str	x14, [x19, #0x52e8]
1005d5094: f9297a6d    	str	x13, [x19, #0x52f0]
1005d5098: 140000cc    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d509c: d2807b20    	mov	x0, #0x3d9              ; =985
1005d50a0: f9002740    	str	x0, [x26, #0x48]
1005d50a4: d2800020    	mov	x0, #0x1                ; =1
1005d50a8: f80983e0    	stur	x0, [sp, #0x98]
1005d50ac: f9001a60    	str	x0, [x19, #0x30]
1005d50b0: f84c03e0    	ldur	x0, [sp, #0xc0]
1005d50b4: f9002260    	str	x0, [x19, #0x40]
1005d50b8: d2800060    	mov	x0, #0x3                ; =3
1005d50bc: f9002660    	str	x0, [x19, #0x48]
1005d50c0: d28000c0    	mov	x0, #0x6                ; =6
1005d50c4: f9003260    	str	x0, [x19, #0x60]
1005d50c8: d2800300    	mov	x0, #0x18               ; =24
1005d50cc: f9004260    	str	x0, [x19, #0x80]
1005d50d0: d2800000    	mov	x0, #0x0                ; =0
1005d50d4: f900c660    	str	x0, [x19, #0x188]
1005d50d8: f84983e0    	ldur	x0, [sp, #0x98]
1005d50dc: f900ca60    	str	x0, [x19, #0x190]
1005d50e0: f9078a74    	str	x20, [x19, #0xf10]
1005d50e4: f9078e7b    	str	x27, [x19, #0xf18]
1005d50e8: f84e03f4    	ldur	x20, [sp, #0xe0]
1005d50ec: 53001e85    	uxtb	w5, w20
1005d50f0: f9079a65    	str	x5, [x19, #0xf30]
1005d50f4: f907d679    	str	x25, [x19, #0xfa8]
1005d50f8: f907da78    	str	x24, [x19, #0xfb0]
1005d50fc: f84d03f4    	ldur	x20, [sp, #0xd0]
1005d5100: 53001e87    	uxtb	w7, w20
1005d5104: f907e667    	str	x7, [x19, #0xfc8]
1005d5108: f9081a79    	str	x25, [x19, #0x1030]
1005d510c: f9081e7c    	str	x28, [x19, #0x1038]
1005d5110: f9082278    	str	x24, [x19, #0x1040]
1005d5114: f925c66b    	str	x11, [x19, #0x4b88]
1005d5118: f925ca63    	str	x3, [x19, #0x4b90]
1005d511c: f925ce64    	str	x4, [x19, #0x4b98]
1005d5120: f84783f5    	ldur	x21, [sp, #0x78]
1005d5124: f928ee75    	str	x21, [x19, #0x51d8]
1005d5128: f84083f5    	ldur	x21, [sp, #0x8]
1005d512c: f928fe75    	str	x21, [x19, #0x51f8]
1005d5130: f9294262    	str	x2, [x19, #0x5280]
1005d5134: f84203e0    	ldur	x0, [sp, #0x20]
1005d5138: f9294660    	str	x0, [x19, #0x5288]
1005d513c: f84283e6    	ldur	x6, [sp, #0x28]
1005d5140: f9294a66    	str	x6, [x19, #0x5290]
1005d5144: f84103e1    	ldur	x1, [sp, #0x10]
1005d5148: cb030020    	sub	x0, x1, x3
1005d514c: d29e9381    	mov	x1, #0xf49c             ; =62620
1005d5150: 9b018040    	msub	x0, x2, x1, x0
1005d5154: f9294e60    	str	x0, [x19, #0x5298]
1005d5158: f84303e5    	ldur	x5, [sp, #0x30]
1005d515c: f9295265    	str	x5, [x19, #0x52a0]
1005d5160: f84383e7    	ldur	x7, [sp, #0x38]
1005d5164: f9295667    	str	x7, [x19, #0x52a8]
1005d5168: f84403ef    	ldur	x15, [sp, #0x40]
1005d516c: f9295e6f    	str	x15, [x19, #0x52b8]
1005d5170: f84483e8    	ldur	x8, [sp, #0x48]
1005d5174: f9296268    	str	x8, [x19, #0x52c0]
1005d5178: f9296a69    	str	x9, [x19, #0x52d0]
1005d517c: f9296e77    	str	x23, [x19, #0x52d8]
1005d5180: f929766e    	str	x14, [x19, #0x52e8]
1005d5184: f9297a6d    	str	x13, [x19, #0x52f0]
1005d5188: 14000090    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d518c: d2807920    	mov	x0, #0x3c9              ; =969
1005d5190: f9002740    	str	x0, [x26, #0x48]
1005d5194: d2800020    	mov	x0, #0x1                ; =1
1005d5198: f80983e0    	stur	x0, [sp, #0x98]
1005d519c: f9001a60    	str	x0, [x19, #0x30]
1005d51a0: f84c03e9    	ldur	x9, [sp, #0xc0]
1005d51a4: f9002269    	str	x9, [x19, #0x40]
1005d51a8: d2800060    	mov	x0, #0x3                ; =3
1005d51ac: f9002660    	str	x0, [x19, #0x48]
1005d51b0: d28000c0    	mov	x0, #0x6                ; =6
1005d51b4: f9003260    	str	x0, [x19, #0x60]
1005d51b8: d2800300    	mov	x0, #0x18               ; =24
1005d51bc: f9004260    	str	x0, [x19, #0x80]
1005d51c0: d2800000    	mov	x0, #0x0                ; =0
1005d51c4: f900c660    	str	x0, [x19, #0x188]
1005d51c8: f84983e0    	ldur	x0, [sp, #0x98]
1005d51cc: f900ca60    	str	x0, [x19, #0x190]
1005d51d0: f9078a74    	str	x20, [x19, #0xf10]
1005d51d4: f9078e7b    	str	x27, [x19, #0xf18]
1005d51d8: f84e03f4    	ldur	x20, [sp, #0xe0]
1005d51dc: 53001e80    	uxtb	w0, w20
1005d51e0: f9079a60    	str	x0, [x19, #0xf30]
1005d51e4: f907d679    	str	x25, [x19, #0xfa8]
1005d51e8: f907da78    	str	x24, [x19, #0xfb0]
1005d51ec: f84d03f4    	ldur	x20, [sp, #0xd0]
1005d51f0: 53001e80    	uxtb	w0, w20
1005d51f4: f907e660    	str	x0, [x19, #0xfc8]
1005d51f8: f9081a79    	str	x25, [x19, #0x1030]
1005d51fc: f9081e7c    	str	x28, [x19, #0x1038]
1005d5200: f9082278    	str	x24, [x19, #0x1040]
1005d5204: 53001ea0    	uxtb	w0, w21
1005d5208: f9082e60    	str	x0, [x19, #0x1058]
1005d520c: f9086679    	str	x25, [x19, #0x10c8]
1005d5210: f9086a7c    	str	x28, [x19, #0x10d0]
1005d5214: f9086e77    	str	x23, [x19, #0x10d8]
1005d5218: f9087278    	str	x24, [x19, #0x10e0]
1005d521c: f925c66b    	str	x11, [x19, #0x4b88]
1005d5220: f925ca63    	str	x3, [x19, #0x4b90]
1005d5224: f925ce64    	str	x4, [x19, #0x4b98]
1005d5228: f84783f5    	ldur	x21, [sp, #0x78]
1005d522c: f928ee75    	str	x21, [x19, #0x51d8]
1005d5230: f84083f5    	ldur	x21, [sp, #0x8]
1005d5234: f928fe75    	str	x21, [x19, #0x51f8]
1005d5238: f9294262    	str	x2, [x19, #0x5280]
1005d523c: f84203e0    	ldur	x0, [sp, #0x20]
1005d5240: f9294660    	str	x0, [x19, #0x5288]
1005d5244: f84283e5    	ldur	x5, [sp, #0x28]
1005d5248: f9294a65    	str	x5, [x19, #0x5290]
1005d524c: f84103e1    	ldur	x1, [sp, #0x10]
1005d5250: cb030023    	sub	x3, x1, x3
1005d5254: d29e9384    	mov	x4, #0xf49c             ; =62620
1005d5258: 9b048c43    	msub	x3, x2, x4, x3
1005d525c: f9294e63    	str	x3, [x19, #0x5298]
1005d5260: f84303e5    	ldur	x5, [sp, #0x30]
1005d5264: f9295265    	str	x5, [x19, #0x52a0]
1005d5268: f84383e9    	ldur	x9, [sp, #0x38]
1005d526c: f9295669    	str	x9, [x19, #0x52a8]
1005d5270: f84403ef    	ldur	x15, [sp, #0x40]
1005d5274: f9295e6f    	str	x15, [x19, #0x52b8]
1005d5278: f84483e8    	ldur	x8, [sp, #0x48]
1005d527c: f9296268    	str	x8, [x19, #0x52c0]
1005d5280: f84503e0    	ldur	x0, [sp, #0x50]
1005d5284: f9296a60    	str	x0, [x19, #0x52d0]
1005d5288: f84583e1    	ldur	x1, [sp, #0x58]
1005d528c: f9296e61    	str	x1, [x19, #0x52d8]
1005d5290: f929766e    	str	x14, [x19, #0x52e8]
1005d5294: f9297a6d    	str	x13, [x19, #0x52f0]
1005d5298: 1400004c    	b	0x1005d53c8 <_mech_canonical_program_entry_v1_numeric_801+0x4a48>
1005d529c: d2807720    	mov	x0, #0x3b9              ; =953
1005d52a0: f9002740    	str	x0, [x26, #0x48]
1005d52a4: d2800020    	mov	x0, #0x1                ; =1
1005d52a8: f80983e0    	stur	x0, [sp, #0x98]
1005d52ac: f9001a60    	str	x0, [x19, #0x30]
1005d52b0: f84c03ed    	ldur	x13, [sp, #0xc0]
1005d52b4: f900226d    	str	x13, [x19, #0x40]
1005d52b8: d2800060    	mov	x0, #0x3                ; =3
1005d52bc: f9002660    	str	x0, [x19, #0x48]
1005d52c0: d28000c0    	mov	x0, #0x6                ; =6
1005d52c4: f9003260    	str	x0, [x19, #0x60]
1005d52c8: d2800300    	mov	x0, #0x18               ; =24
1005d52cc: f9004260    	str	x0, [x19, #0x80]
1005d52d0: d2800000    	mov	x0, #0x0                ; =0
1005d52d4: f900c660    	str	x0, [x19, #0x188]
1005d52d8: f84983e0    	ldur	x0, [sp, #0x98]
1005d52dc: f900ca60    	str	x0, [x19, #0x190]
1005d52e0: f9078a74    	str	x20, [x19, #0xf10]
1005d52e4: f9078e7b    	str	x27, [x19, #0xf18]
1005d52e8: f84e03f4    	ldur	x20, [sp, #0xe0]
1005d52ec: 53001e80    	uxtb	w0, w20
1005d52f0: f9079a60    	str	x0, [x19, #0xf30]
1005d52f4: f907d679    	str	x25, [x19, #0xfa8]
1005d52f8: f907da78    	str	x24, [x19, #0xfb0]
1005d52fc: f84d03f4    	ldur	x20, [sp, #0xd0]
1005d5300: 53001e80    	uxtb	w0, w20
1005d5304: f907e660    	str	x0, [x19, #0xfc8]
1005d5308: f9081a79    	str	x25, [x19, #0x1030]
1005d530c: f9081e7c    	str	x28, [x19, #0x1038]
1005d5310: f9082278    	str	x24, [x19, #0x1040]
1005d5314: 53001ea0    	uxtb	w0, w21
1005d5318: f9082e60    	str	x0, [x19, #0x1058]
1005d531c: f9086679    	str	x25, [x19, #0x10c8]
1005d5320: f9086a7c    	str	x28, [x19, #0x10d0]
1005d5324: f9086e77    	str	x23, [x19, #0x10d8]
1005d5328: f9087278    	str	x24, [x19, #0x10e0]
1005d532c: f84a03e5    	ldur	x5, [sp, #0xa0]
1005d5330: 53001ca0    	uxtb	w0, w5
1005d5334: f9087e60    	str	x0, [x19, #0x10f8]
1005d5338: f908ba79    	str	x25, [x19, #0x1170]
1005d533c: f908be7c    	str	x28, [x19, #0x1178]
1005d5340: f908c277    	str	x23, [x19, #0x1180]
1005d5344: f908c661    	str	x1, [x19, #0x1188]
1005d5348: f908ca78    	str	x24, [x19, #0x1190]
1005d534c: f925c66b    	str	x11, [x19, #0x4b88]
1005d5350: f925ca63    	str	x3, [x19, #0x4b90]
1005d5354: f925ce64    	str	x4, [x19, #0x4b98]
1005d5358: f84783f5    	ldur	x21, [sp, #0x78]
1005d535c: f928ee75    	str	x21, [x19, #0x51d8]
1005d5360: f84083f5    	ldur	x21, [sp, #0x8]
1005d5364: f928fe75    	str	x21, [x19, #0x51f8]
1005d5368: f9294262    	str	x2, [x19, #0x5280]
1005d536c: f84203ed    	ldur	x13, [sp, #0x20]
1005d5370: f929466d    	str	x13, [x19, #0x5288]
1005d5374: f84283eb    	ldur	x11, [sp, #0x28]
1005d5378: f9294a6b    	str	x11, [x19, #0x5290]
1005d537c: f84103e1    	ldur	x1, [sp, #0x10]
1005d5380: cb030020    	sub	x0, x1, x3
1005d5384: d29e9381    	mov	x1, #0xf49c             ; =62620
1005d5388: 9b018040    	msub	x0, x2, x1, x0
1005d538c: f9294e60    	str	x0, [x19, #0x5298]
1005d5390: f84303e5    	ldur	x5, [sp, #0x30]
1005d5394: f9295265    	str	x5, [x19, #0x52a0]
1005d5398: f84383e9    	ldur	x9, [sp, #0x38]
1005d539c: f9295669    	str	x9, [x19, #0x52a8]
1005d53a0: f84403ef    	ldur	x15, [sp, #0x40]
1005d53a4: f9295e6f    	str	x15, [x19, #0x52b8]
1005d53a8: f84483e8    	ldur	x8, [sp, #0x48]
1005d53ac: f9296268    	str	x8, [x19, #0x52c0]
1005d53b0: f84503ed    	ldur	x13, [sp, #0x50]
1005d53b4: f9296a6d    	str	x13, [x19, #0x52d0]
1005d53b8: f84583e1    	ldur	x1, [sp, #0x58]
1005d53bc: f9296e61    	str	x1, [x19, #0x52d8]
1005d53c0: f9297666    	str	x6, [x19, #0x52e8]
1005d53c4: f9297a6e    	str	x14, [x19, #0x52f0]
1005d53c8: d2800001    	mov	x1, #0x0                ; =0
1005d53cc: f84983e0    	ldur	x0, [sp, #0x98]
1005d53d0: 910503ff    	add	sp, sp, #0x140
1005d53d4: a8c153f3    	ldp	x19, x20, [sp], #0x10
1005d53d8: a8c15bf5    	ldp	x21, x22, [sp], #0x10
1005d53dc: a8c163f7    	ldp	x23, x24, [sp], #0x10
1005d53e0: a8c16bf9    	ldp	x25, x26, [sp], #0x10
1005d53e4: a8c173fb    	ldp	x27, x28, [sp], #0x10
1005d53e8: a8c17bfd    	ldp	x29, x30, [sp], #0x10
1005d53ec: d65f0fff    	retab
1005d53f0: 0000c11f    	udf	#0xc11f
1005d53f4: 0000c11f    	udf	#0xc11f
		...
