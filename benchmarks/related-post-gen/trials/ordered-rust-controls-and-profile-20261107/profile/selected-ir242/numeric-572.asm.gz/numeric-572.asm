
/private/tmp/mech-related-current-post-json-all-thread-profile-20261107-v1/selected-ir242/runner-profile:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001005cd480 <_mech_canonical_program_entry_v1_numeric_572>:
1005cd480: d503237f    	pacibsp
1005cd484: a9bf7bfd    	stp	x29, x30, [sp, #-0x10]!
1005cd488: 910003fd    	mov	x29, sp
1005cd48c: a9bf73fb    	stp	x27, x28, [sp, #-0x10]!
1005cd490: a9bf6bf9    	stp	x25, x26, [sp, #-0x10]!
1005cd494: a9bf63f7    	stp	x23, x24, [sp, #-0x10]!
1005cd498: a9bf5bf5    	stp	x21, x22, [sp, #-0x10]!
1005cd49c: a9bf53f3    	stp	x19, x20, [sp, #-0x10]!
1005cd4a0: d10243ff    	sub	sp, sp, #0x90
1005cd4a4: f80003e2    	stur	x2, [sp]
1005cd4a8: f940281b    	ldr	x27, [x0, #0x50]
1005cd4ac: f9402c06    	ldr	x6, [x0, #0x58]
1005cd4b0: f9403002    	ldr	x2, [x0, #0x60]
1005cd4b4: f940341c    	ldr	x28, [x0, #0x68]
1005cd4b8: aa0003f8    	mov	x24, x0
1005cd4bc: f80683fc    	stur	x28, [sp, #0x68]
1005cd4c0: d2800060    	mov	x0, #0x3                ; =3
1005cd4c4: f100037f    	cmp	x27, #0x0
1005cd4c8: f80803fb    	stur	x27, [sp, #0x80]
1005cd4cc: 5400a520    	b.eq	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005cd4d0: d2800060    	mov	x0, #0x3                ; =3
1005cd4d4: f10000df    	cmp	x6, #0x0
1005cd4d8: f80783e6    	stur	x6, [sp, #0x78]
1005cd4dc: 5400a4a0    	b.eq	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005cd4e0: d2800060    	mov	x0, #0x3                ; =3
1005cd4e4: aa0003e3    	mov	x3, x0
1005cd4e8: f100005f    	cmp	x2, #0x0
1005cd4ec: 54007100    	b.eq	0x1005ce30c <_mech_canonical_program_entry_v1_numeric_572+0xe8c>
1005cd4f0: f9659426    	ldr	x6, [x1, #0x4b28]
1005cd4f4: f10000df    	cmp	x6, #0x0
1005cd4f8: 54001060    	b.eq	0x1005cd704 <_mech_canonical_program_entry_v1_numeric_572+0x284>
1005cd4fc: f9400849    	ldr	x9, [x2, #0x10]
1005cd500: f945902e    	ldr	x14, [x1, #0xb20]
1005cd504: f945942e    	ldr	x14, [x1, #0xb28]
1005cd508: f945a02e    	ldr	x14, [x1, #0xb40]
1005cd50c: f945a82e    	ldr	x14, [x1, #0xb50]
1005cd510: f945ac2e    	ldr	x14, [x1, #0xb58]
1005cd514: f945b02e    	ldr	x14, [x1, #0xb60]
1005cd518: f945b42e    	ldr	x14, [x1, #0xb68]
1005cd51c: f945bc2e    	ldr	x14, [x1, #0xb78]
1005cd520: f945c02e    	ldr	x14, [x1, #0xb80]
1005cd524: f945c42e    	ldr	x14, [x1, #0xb88]
1005cd528: f945e42e    	ldr	x14, [x1, #0xbc8]
1005cd52c: f945e82e    	ldr	x14, [x1, #0xbd0]
1005cd530: f945ec2e    	ldr	x14, [x1, #0xbd8]
1005cd534: f945f82e    	ldr	x14, [x1, #0xbf0]
1005cd538: f946002e    	ldr	x14, [x1, #0xc00]
1005cd53c: f946042e    	ldr	x14, [x1, #0xc08]
1005cd540: f946082e    	ldr	x14, [x1, #0xc10]
1005cd544: f9460c2e    	ldr	x14, [x1, #0xc18]
1005cd548: f946102e    	ldr	x14, [x1, #0xc20]
1005cd54c: f946182e    	ldr	x14, [x1, #0xc30]
1005cd550: f9461c2e    	ldr	x14, [x1, #0xc38]
1005cd554: f946382e    	ldr	x14, [x1, #0xc70]
1005cd558: f946542e    	ldr	x14, [x1, #0xca8]
1005cd55c: f9659823    	ldr	x3, [x1, #0x4b30]
1005cd560: f9659c24    	ldr	x4, [x1, #0x4b38]
1005cd564: f9430937    	ldr	x23, [x9, #0x610]
1005cd568: f9431136    	ldr	x22, [x9, #0x620]
1005cd56c: f9405c4a    	ldr	x10, [x2, #0xb8]
1005cd570: f80183ea    	stur	x10, [sp, #0x18]
1005cd574: f9406054    	ldr	x20, [x2, #0xc0]
1005cd578: f80603f4    	stur	x20, [sp, #0x60]
1005cd57c: f940644e    	ldr	x14, [x2, #0xc8]
1005cd580: f940684e    	ldr	x14, [x2, #0xd0]
1005cd584: f9406c55    	ldr	x21, [x2, #0xd8]
1005cd588: f80083f5    	stur	x21, [sp, #0x8]
1005cd58c: f940705c    	ldr	x28, [x2, #0xe0]
1005cd590: f80583fc    	stur	x28, [sp, #0x58]
1005cd594: f940744e    	ldr	x14, [x2, #0xe8]
1005cd598: f940784e    	ldr	x14, [x2, #0xf0]
1005cd59c: f9407c5c    	ldr	x28, [x2, #0xf8]
1005cd5a0: f80503fc    	stur	x28, [sp, #0x50]
1005cd5a4: f940805c    	ldr	x28, [x2, #0x100]
1005cd5a8: f80483fc    	stur	x28, [sp, #0x48]
1005cd5ac: f940844e    	ldr	x14, [x2, #0x108]
1005cd5b0: f940884e    	ldr	x14, [x2, #0x110]
1005cd5b4: f9408c5b    	ldr	x27, [x2, #0x118]
1005cd5b8: f80403fb    	stur	x27, [sp, #0x40]
1005cd5bc: f940905c    	ldr	x28, [x2, #0x120]
1005cd5c0: f80383fc    	stur	x28, [sp, #0x38]
1005cd5c4: f940944e    	ldr	x14, [x2, #0x128]
1005cd5c8: f940984e    	ldr	x14, [x2, #0x130]
1005cd5cc: f80703e2    	stur	x2, [sp, #0x70]
1005cd5d0: d2800005    	mov	x5, #0x0                ; =0
1005cd5d4: d2800022    	mov	x2, #0x1                ; =1
1005cd5d8: aa0503e7    	mov	x7, x5
1005cd5dc: aa0503e8    	mov	x8, x5
1005cd5e0: aa0503ea    	mov	x10, x5
1005cd5e4: aa0503ed    	mov	x13, x5
1005cd5e8: f80103e5    	stur	x5, [sp, #0x10]
1005cd5ec: f80203e5    	stur	x5, [sp, #0x20]
1005cd5f0: d298690f    	mov	x15, #0xc348            ; =49992
1005cd5f4: eb0f007f    	cmp	x3, x15
1005cd5f8: 540009a2    	b.hs	0x1005cd72c <_mech_canonical_program_entry_v1_numeric_572+0x2ac>
1005cd5fc: d2800020    	mov	x0, #0x1                ; =1
1005cd600: aa0103f3    	mov	x19, x1
1005cd604: f9001a60    	str	x0, [x19, #0x30]
1005cd608: d2800041    	mov	x1, #0x2                ; =2
1005cd60c: f9002261    	str	x1, [x19, #0x40]
1005cd610: d2800001    	mov	x1, #0x0                ; =0
1005cd614: f900c661    	str	x1, [x19, #0x188]
1005cd618: f900ca60    	str	x0, [x19, #0x190]
1005cd61c: f9259666    	str	x6, [x19, #0x4b28]
1005cd620: f9259a63    	str	x3, [x19, #0x4b30]
1005cd624: f9259e64    	str	x4, [x19, #0x4b38]
1005cd628: f927ba77    	str	x23, [x19, #0x4f70]
1005cd62c: f927be76    	str	x22, [x19, #0x4f78]
1005cd630: f9285e65    	str	x5, [x19, #0x50b8]
1005cd634: f9286262    	str	x2, [x19, #0x50c0]
1005cd638: f928666d    	str	x13, [x19, #0x50c8]
1005cd63c: f9286a6a    	str	x10, [x19, #0x50d0]
1005cd640: f9286e68    	str	x8, [x19, #0x50d8]
1005cd644: f9287267    	str	x7, [x19, #0x50e0]
1005cd648: f9659660    	ldr	x0, [x19, #0x4b28]
1005cd64c: f100001f    	cmp	x0, #0x0
1005cd650: 540005a0    	b.eq	0x1005cd704 <_mech_canonical_program_entry_v1_numeric_572+0x284>
1005cd654: f9659a63    	ldr	x3, [x19, #0x4b30]
1005cd658: f9659e64    	ldr	x4, [x19, #0x4b38]
1005cd65c: d2800000    	mov	x0, #0x0                ; =0
1005cd660: f9259660    	str	x0, [x19, #0x4b28]
1005cd664: d2800061    	mov	x1, #0x3                ; =3
1005cd668: f84683ec    	ldur	x12, [sp, #0x68]
1005cd66c: f100c99f    	cmp	x12, #0x32
1005cd670: 54006523    	b.lo	0x1005ce314 <_mech_canonical_program_entry_v1_numeric_572+0xe94>
1005cd674: f967ba60    	ldr	x0, [x19, #0x4f70]
1005cd678: f84703eb    	ldur	x11, [sp, #0x70]
1005cd67c: f9000960    	str	x0, [x11, #0x10]
1005cd680: f967be61    	ldr	x1, [x19, #0x4f78]
1005cd684: f9000d61    	str	x1, [x11, #0x18]
1005cd688: f9000960    	str	x0, [x11, #0x10]
1005cd68c: f9000d61    	str	x1, [x11, #0x18]
1005cd690: f967e260    	ldr	x0, [x19, #0x4fc0]
1005cd694: f9003160    	str	x0, [x11, #0x60]
1005cd698: f967e660    	ldr	x0, [x19, #0x4fc8]
1005cd69c: f9003560    	str	x0, [x11, #0x68]
1005cd6a0: f967ea60    	ldr	x0, [x19, #0x4fd0]
1005cd6a4: f9003960    	str	x0, [x11, #0x70]
1005cd6a8: f9685e60    	ldr	x0, [x19, #0x50b8]
1005cd6ac: f900ad60    	str	x0, [x11, #0x158]
1005cd6b0: f9686260    	ldr	x0, [x19, #0x50c0]
1005cd6b4: f900b160    	str	x0, [x11, #0x160]
1005cd6b8: f9686660    	ldr	x0, [x19, #0x50c8]
1005cd6bc: f900b560    	str	x0, [x11, #0x168]
1005cd6c0: f9686a60    	ldr	x0, [x19, #0x50d0]
1005cd6c4: f900b960    	str	x0, [x11, #0x170]
1005cd6c8: f9686e60    	ldr	x0, [x19, #0x50d8]
1005cd6cc: f900bd60    	str	x0, [x11, #0x178]
1005cd6d0: f9687260    	ldr	x0, [x19, #0x50e0]
1005cd6d4: f900c160    	str	x0, [x11, #0x180]
1005cd6d8: d2804781    	mov	x1, #0x23c              ; =572
1005cd6dc: 92800102    	mov	x2, #-0x9               ; =-9
1005cd6e0: d2800025    	mov	x5, #0x1                ; =1
1005cd6e4: f84003e0    	ldur	x0, [sp]
1005cd6e8: f84783e6    	ldur	x6, [sp, #0x78]
1005cd6ec: f84803f5    	ldur	x21, [sp, #0x80]
1005cd6f0: d63f02a0    	blr	x21
1005cd6f4: d2800041    	mov	x1, #0x2                ; =2
1005cd6f8: aa0103e3    	mov	x3, x1
1005cd6fc: f100001f    	cmp	x0, #0x0
1005cd700: 540060e1    	b.ne	0x1005ce31c <_mech_canonical_program_entry_v1_numeric_572+0xe9c>
1005cd704: d2800001    	mov	x1, #0x0                ; =0
1005cd708: aa0103e0    	mov	x0, x1
1005cd70c: 910243ff    	add	sp, sp, #0x90
1005cd710: a8c153f3    	ldp	x19, x20, [sp], #0x10
1005cd714: a8c15bf5    	ldp	x21, x22, [sp], #0x10
1005cd718: a8c163f7    	ldp	x23, x24, [sp], #0x10
1005cd71c: a8c16bf9    	ldp	x25, x26, [sp], #0x10
1005cd720: a8c173fb    	ldp	x27, x28, [sp], #0x10
1005cd724: a8c17bfd    	ldp	x29, x30, [sp], #0x10
1005cd728: d65f0fff    	retab
1005cd72c: f84703eb    	ldur	x11, [sp, #0x70]
1005cd730: f84683ec    	ldur	x12, [sp, #0x68]
1005cd734: aa0103f3    	mov	x19, x1
1005cd738: f84803f5    	ldur	x21, [sp, #0x80]
1005cd73c: eb1602ff    	cmp	x23, x22
1005cd740: 9a9f27f4    	cset	x20, lo
1005cd744: f80303f4    	stur	x20, [sp, #0x30]
1005cd748: eb1602ff    	cmp	x23, x22
1005cd74c: 540001a3    	b.lo	0x1005cd780 <_mech_canonical_program_entry_v1_numeric_572+0x300>
1005cd750: d298690e    	mov	x14, #0xc348            ; =49992
1005cd754: cb0e0063    	sub	x3, x3, x14
1005cd758: 910004a5    	add	x5, x5, #0x1
1005cd75c: f80803f5    	stur	x21, [sp, #0x80]
1005cd760: f80703eb    	stur	x11, [sp, #0x70]
1005cd764: f80683ec    	stur	x12, [sp, #0x68]
1005cd768: f84203fb    	ldur	x27, [sp, #0x20]
1005cd76c: aa1803f4    	mov	x20, x24
1005cd770: aa1703ee    	mov	x14, x23
1005cd774: aa1703ec    	mov	x12, x23
1005cd778: f84183eb    	ldur	x11, [sp, #0x18]
1005cd77c: 140002b6    	b	0x1005ce254 <_mech_canonical_program_entry_v1_numeric_572+0xdd4>
1005cd780: f84483fb    	ldur	x27, [sp, #0x48]
1005cd784: eb1b02ff    	cmp	x23, x27
1005cd788: 54000883    	b.lo	0x1005cd898 <_mech_canonical_program_entry_v1_numeric_572+0x418>
1005cd78c: 140002e6    	b	0x1005ce324 <_mech_canonical_program_entry_v1_numeric_572+0xea4>
1005cd790: f80683ec    	stur	x12, [sp, #0x68]
1005cd794: f80703eb    	stur	x11, [sp, #0x70]
1005cd798: f80803f5    	stur	x21, [sp, #0x80]
1005cd79c: 1400002b    	b	0x1005cd848 <_mech_canonical_program_entry_v1_numeric_572+0x3c8>
1005cd7a0: f9659a63    	ldr	x3, [x19, #0x4b30]
1005cd7a4: f9659e64    	ldr	x4, [x19, #0x4b38]
1005cd7a8: d2800000    	mov	x0, #0x0                ; =0
1005cd7ac: f9259660    	str	x0, [x19, #0x4b28]
1005cd7b0: d2800060    	mov	x0, #0x3                ; =3
1005cd7b4: f100c99f    	cmp	x12, #0x32
1005cd7b8: f80683ec    	stur	x12, [sp, #0x68]
1005cd7bc: 54008da3    	b.lo	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005cd7c0: f967ba60    	ldr	x0, [x19, #0x4f70]
1005cd7c4: f9000960    	str	x0, [x11, #0x10]
1005cd7c8: f967be61    	ldr	x1, [x19, #0x4f78]
1005cd7cc: f9000d61    	str	x1, [x11, #0x18]
1005cd7d0: f9000960    	str	x0, [x11, #0x10]
1005cd7d4: f9000d61    	str	x1, [x11, #0x18]
1005cd7d8: f967e260    	ldr	x0, [x19, #0x4fc0]
1005cd7dc: f9003160    	str	x0, [x11, #0x60]
1005cd7e0: f967e660    	ldr	x0, [x19, #0x4fc8]
1005cd7e4: f9003560    	str	x0, [x11, #0x68]
1005cd7e8: f967ea60    	ldr	x0, [x19, #0x4fd0]
1005cd7ec: f9003960    	str	x0, [x11, #0x70]
1005cd7f0: f9685e60    	ldr	x0, [x19, #0x50b8]
1005cd7f4: f900ad60    	str	x0, [x11, #0x158]
1005cd7f8: f9686260    	ldr	x0, [x19, #0x50c0]
1005cd7fc: f900b160    	str	x0, [x11, #0x160]
1005cd800: f9686660    	ldr	x0, [x19, #0x50c8]
1005cd804: f900b560    	str	x0, [x11, #0x168]
1005cd808: f9686a60    	ldr	x0, [x19, #0x50d0]
1005cd80c: f900b960    	str	x0, [x11, #0x170]
1005cd810: f9686e60    	ldr	x0, [x19, #0x50d8]
1005cd814: f900bd60    	str	x0, [x11, #0x178]
1005cd818: f9687260    	ldr	x0, [x19, #0x50e0]
1005cd81c: f900c160    	str	x0, [x11, #0x180]
1005cd820: f80703eb    	stur	x11, [sp, #0x70]
1005cd824: d2804981    	mov	x1, #0x24c              ; =588
1005cd828: 92800102    	mov	x2, #-0x9               ; =-9
1005cd82c: f84003e0    	ldur	x0, [sp]
1005cd830: aa1403e5    	mov	x5, x20
1005cd834: f84783e6    	ldur	x6, [sp, #0x78]
1005cd838: d63f02a0    	blr	x21
1005cd83c: f80803f5    	stur	x21, [sp, #0x80]
1005cd840: f100001f    	cmp	x0, #0x0
1005cd844: 54005b61    	b.ne	0x1005ce3b0 <_mech_canonical_program_entry_v1_numeric_572+0xf30>
1005cd848: d2800060    	mov	x0, #0x3                ; =3
1005cd84c: f84683eb    	ldur	x11, [sp, #0x68]
1005cd850: f100097f    	cmp	x11, #0x2
1005cd854: 540088e3    	b.lo	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005cd858: d2800005    	mov	x5, #0x0                ; =0
1005cd85c: f84703e3    	ldur	x3, [sp, #0x70]
1005cd860: f9000065    	str	x5, [x3]
1005cd864: f945aa60    	ldr	x0, [x19, #0xb50]
1005cd868: f9000460    	str	x0, [x3, #0x8]
1005cd86c: d2804981    	mov	x1, #0x24c              ; =588
1005cd870: f84003e0    	ldur	x0, [sp]
1005cd874: f84783e6    	ldur	x6, [sp, #0x78]
1005cd878: f84803e7    	ldur	x7, [sp, #0x80]
1005cd87c: aa1403e4    	mov	x4, x20
1005cd880: aa0503e2    	mov	x2, x5
1005cd884: d63f00e0    	blr	x7
1005cd888: f100001f    	cmp	x0, #0x0
1005cd88c: 54005961    	b.ne	0x1005ce3b8 <_mech_canonical_program_entry_v1_numeric_572+0xf38>
1005cd890: d2800060    	mov	x0, #0x3                ; =3
1005cd894: 14000437    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005cd898: aa1803f4    	mov	x20, x24
1005cd89c: f84503fb    	ldur	x27, [sp, #0x50]
1005cd8a0: f80683ec    	stur	x12, [sp, #0x68]
1005cd8a4: f80703eb    	stur	x11, [sp, #0x70]
1005cd8a8: f80803f5    	stur	x21, [sp, #0x80]
1005cd8ac: f8777b79    	ldr	x25, [x27, x23, lsl #3]
1005cd8b0: 910006eb    	add	x11, x23, #0x1
1005cd8b4: f84483fb    	ldur	x27, [sp, #0x48]
1005cd8b8: eb1b017f    	cmp	x11, x27
1005cd8bc: 54000863    	b.lo	0x1005cd9c8 <_mech_canonical_program_entry_v1_numeric_572+0x548>
1005cd8c0: 140002c0    	b	0x1005ce3c0 <_mech_canonical_program_entry_v1_numeric_572+0xf40>
1005cd8c4: f9659a63    	ldr	x3, [x19, #0x4b30]
1005cd8c8: f9659e64    	ldr	x4, [x19, #0x4b38]
1005cd8cc: d2800000    	mov	x0, #0x0                ; =0
1005cd8d0: f9259660    	str	x0, [x19, #0x4b28]
1005cd8d4: d2800060    	mov	x0, #0x3                ; =3
1005cd8d8: f84683eb    	ldur	x11, [sp, #0x68]
1005cd8dc: f100c97f    	cmp	x11, #0x32
1005cd8e0: 54008483    	b.lo	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005cd8e4: f967ba60    	ldr	x0, [x19, #0x4f70]
1005cd8e8: f84703ed    	ldur	x13, [sp, #0x70]
1005cd8ec: f90009a0    	str	x0, [x13, #0x10]
1005cd8f0: f967be61    	ldr	x1, [x19, #0x4f78]
1005cd8f4: f84703e2    	ldur	x2, [sp, #0x70]
1005cd8f8: f9000c41    	str	x1, [x2, #0x18]
1005cd8fc: f9000840    	str	x0, [x2, #0x10]
1005cd900: f84703e0    	ldur	x0, [sp, #0x70]
1005cd904: f9000c01    	str	x1, [x0, #0x18]
1005cd908: f967e260    	ldr	x0, [x19, #0x4fc0]
1005cd90c: f84703e1    	ldur	x1, [sp, #0x70]
1005cd910: f9003020    	str	x0, [x1, #0x60]
1005cd914: f967e660    	ldr	x0, [x19, #0x4fc8]
1005cd918: f9003420    	str	x0, [x1, #0x68]
1005cd91c: f967ea60    	ldr	x0, [x19, #0x4fd0]
1005cd920: f9003820    	str	x0, [x1, #0x70]
1005cd924: f9685e60    	ldr	x0, [x19, #0x50b8]
1005cd928: f900ac20    	str	x0, [x1, #0x158]
1005cd92c: f9686260    	ldr	x0, [x19, #0x50c0]
1005cd930: f900b020    	str	x0, [x1, #0x160]
1005cd934: f9686660    	ldr	x0, [x19, #0x50c8]
1005cd938: f900b420    	str	x0, [x1, #0x168]
1005cd93c: f9686a60    	ldr	x0, [x19, #0x50d0]
1005cd940: f900b820    	str	x0, [x1, #0x170]
1005cd944: f9686e60    	ldr	x0, [x19, #0x50d8]
1005cd948: f900bc20    	str	x0, [x1, #0x178]
1005cd94c: f9687260    	ldr	x0, [x19, #0x50e0]
1005cd950: f900c020    	str	x0, [x1, #0x180]
1005cd954: d28049c1    	mov	x1, #0x24e              ; =590
1005cd958: 92800102    	mov	x2, #-0x9               ; =-9
1005cd95c: f84803e7    	ldur	x7, [sp, #0x80]
1005cd960: f84003e0    	ldur	x0, [sp]
1005cd964: aa1403e5    	mov	x5, x20
1005cd968: f84783e6    	ldur	x6, [sp, #0x78]
1005cd96c: d63f00e0    	blr	x7
1005cd970: f100001f    	cmp	x0, #0x0
1005cd974: 540056c1    	b.ne	0x1005ce44c <_mech_canonical_program_entry_v1_numeric_572+0xfcc>
1005cd978: d2800060    	mov	x0, #0x3                ; =3
1005cd97c: f84683eb    	ldur	x11, [sp, #0x68]
1005cd980: f100097f    	cmp	x11, #0x2
1005cd984: 54007f63    	b.lo	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005cd988: d2800005    	mov	x5, #0x0                ; =0
1005cd98c: f84703e3    	ldur	x3, [sp, #0x70]
1005cd990: f9000065    	str	x5, [x3]
1005cd994: f945b260    	ldr	x0, [x19, #0xb60]
1005cd998: f9000460    	str	x0, [x3, #0x8]
1005cd99c: d28049c1    	mov	x1, #0x24e              ; =590
1005cd9a0: f84003e0    	ldur	x0, [sp]
1005cd9a4: f84783e6    	ldur	x6, [sp, #0x78]
1005cd9a8: f84803e7    	ldur	x7, [sp, #0x80]
1005cd9ac: aa1403e4    	mov	x4, x20
1005cd9b0: aa0503e2    	mov	x2, x5
1005cd9b4: d63f00e0    	blr	x7
1005cd9b8: f100001f    	cmp	x0, #0x0
1005cd9bc: 540054c1    	b.ne	0x1005ce454 <_mech_canonical_program_entry_v1_numeric_572+0xfd4>
1005cd9c0: d2800060    	mov	x0, #0x3                ; =3
1005cd9c4: 140003eb    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005cd9c8: f84503fb    	ldur	x27, [sp, #0x50]
1005cd9cc: f86b7b78    	ldr	x24, [x27, x11, lsl #3]
1005cd9d0: d298690b    	mov	x11, #0xc348            ; =49992
1005cd9d4: cb0b0063    	sub	x3, x3, x11
1005cd9d8: d2800028    	mov	x8, #0x1                ; =1
1005cd9dc: 910004a5    	add	x5, x5, #0x1
1005cd9e0: d2800007    	mov	x7, #0x0                ; =0
1005cd9e4: d2800041    	mov	x1, #0x2                ; =2
1005cd9e8: f80283e1    	stur	x1, [sp, #0x28]
1005cd9ec: d298190b    	mov	x11, #0xc0c8            ; =49352
1005cd9f0: eb0b007f    	cmp	x3, x11
1005cd9f4: 9a9f37ec    	cset	x12, hs
1005cd9f8: f100089f    	cmp	x4, #0x2
1005cd9fc: 9a9f37ee    	cset	x14, hs
1005cda00: 0a0e018c    	and	w12, w12, w14
1005cda04: 37000acc    	tbnz	w12, #0x0, 0x1005cdb5c <_mech_canonical_program_entry_v1_numeric_572+0x6dc>
1005cda08: d280002e    	mov	x14, #0x1               ; =1
1005cda0c: f9001a6e    	str	x14, [x19, #0x30]
1005cda10: f84283e1    	ldur	x1, [sp, #0x28]
1005cda14: f9002261    	str	x1, [x19, #0x40]
1005cda18: d280000f    	mov	x15, #0x0               ; =0
1005cda1c: f900c66f    	str	x15, [x19, #0x188]
1005cda20: f900ca6e    	str	x14, [x19, #0x190]
1005cda24: f9059277    	str	x23, [x19, #0xb20]
1005cda28: f9059676    	str	x22, [x19, #0xb28]
1005cda2c: f84303f4    	ldur	x20, [sp, #0x30]
1005cda30: 53001e80    	uxtb	w0, w20
1005cda34: f905a260    	str	x0, [x19, #0xb40]
1005cda38: f9259666    	str	x6, [x19, #0x4b28]
1005cda3c: f9259a63    	str	x3, [x19, #0x4b30]
1005cda40: f9259e64    	str	x4, [x19, #0x4b38]
1005cda44: f927ba77    	str	x23, [x19, #0x4f70]
1005cda48: f927be76    	str	x22, [x19, #0x4f78]
1005cda4c: f927e279    	str	x25, [x19, #0x4fc0]
1005cda50: f927e678    	str	x24, [x19, #0x4fc8]
1005cda54: f927ea77    	str	x23, [x19, #0x4fd0]
1005cda58: f9285e65    	str	x5, [x19, #0x50b8]
1005cda5c: f9286262    	str	x2, [x19, #0x50c0]
1005cda60: f928666d    	str	x13, [x19, #0x50c8]
1005cda64: f9286a6a    	str	x10, [x19, #0x50d0]
1005cda68: f9286e68    	str	x8, [x19, #0x50d8]
1005cda6c: f9287267    	str	x7, [x19, #0x50e0]
1005cda70: f9659660    	ldr	x0, [x19, #0x4b28]
1005cda74: f100001f    	cmp	x0, #0x0
1005cda78: 540005e0    	b.eq	0x1005cdb34 <_mech_canonical_program_entry_v1_numeric_572+0x6b4>
1005cda7c: f9659a63    	ldr	x3, [x19, #0x4b30]
1005cda80: f9659e64    	ldr	x4, [x19, #0x4b38]
1005cda84: d2800000    	mov	x0, #0x0                ; =0
1005cda88: f9259660    	str	x0, [x19, #0x4b28]
1005cda8c: d2800060    	mov	x0, #0x3                ; =3
1005cda90: f84683eb    	ldur	x11, [sp, #0x68]
1005cda94: f100c97f    	cmp	x11, #0x32
1005cda98: 540076c3    	b.lo	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005cda9c: f967ba60    	ldr	x0, [x19, #0x4f70]
1005cdaa0: f84703e8    	ldur	x8, [sp, #0x70]
1005cdaa4: f9000900    	str	x0, [x8, #0x10]
1005cdaa8: f967be61    	ldr	x1, [x19, #0x4f78]
1005cdaac: f84703eb    	ldur	x11, [sp, #0x70]
1005cdab0: f9000d61    	str	x1, [x11, #0x18]
1005cdab4: f84703ed    	ldur	x13, [sp, #0x70]
1005cdab8: f90009a0    	str	x0, [x13, #0x10]
1005cdabc: f84703ef    	ldur	x15, [sp, #0x70]
1005cdac0: f9000de1    	str	x1, [x15, #0x18]
1005cdac4: f967e260    	ldr	x0, [x19, #0x4fc0]
1005cdac8: f84703e1    	ldur	x1, [sp, #0x70]
1005cdacc: f9003020    	str	x0, [x1, #0x60]
1005cdad0: f967e660    	ldr	x0, [x19, #0x4fc8]
1005cdad4: f9003420    	str	x0, [x1, #0x68]
1005cdad8: f967ea60    	ldr	x0, [x19, #0x4fd0]
1005cdadc: f9003820    	str	x0, [x1, #0x70]
1005cdae0: f9685e60    	ldr	x0, [x19, #0x50b8]
1005cdae4: f900ac20    	str	x0, [x1, #0x158]
1005cdae8: f9686260    	ldr	x0, [x19, #0x50c0]
1005cdaec: f900b020    	str	x0, [x1, #0x160]
1005cdaf0: f9686660    	ldr	x0, [x19, #0x50c8]
1005cdaf4: f900b420    	str	x0, [x1, #0x168]
1005cdaf8: f9686a60    	ldr	x0, [x19, #0x50d0]
1005cdafc: f900b820    	str	x0, [x1, #0x170]
1005cdb00: f9686e60    	ldr	x0, [x19, #0x50d8]
1005cdb04: f900bc20    	str	x0, [x1, #0x178]
1005cdb08: f9687260    	ldr	x0, [x19, #0x50e0]
1005cdb0c: f900c020    	str	x0, [x1, #0x180]
1005cdb10: d2804ae1    	mov	x1, #0x257              ; =599
1005cdb14: 92800102    	mov	x2, #-0x9               ; =-9
1005cdb18: d2800025    	mov	x5, #0x1                ; =1
1005cdb1c: f84003e0    	ldur	x0, [sp]
1005cdb20: f84783e6    	ldur	x6, [sp, #0x78]
1005cdb24: f84803e7    	ldur	x7, [sp, #0x80]
1005cdb28: d63f00e0    	blr	x7
1005cdb2c: f100001f    	cmp	x0, #0x0
1005cdb30: 54004961    	b.ne	0x1005ce45c <_mech_canonical_program_entry_v1_numeric_572+0xfdc>
1005cdb34: d2800000    	mov	x0, #0x0                ; =0
1005cdb38: f84283e1    	ldur	x1, [sp, #0x28]
1005cdb3c: 910243ff    	add	sp, sp, #0x90
1005cdb40: a8c153f3    	ldp	x19, x20, [sp], #0x10
1005cdb44: a8c15bf5    	ldp	x21, x22, [sp], #0x10
1005cdb48: a8c163f7    	ldp	x23, x24, [sp], #0x10
1005cdb4c: a8c16bf9    	ldp	x25, x26, [sp], #0x10
1005cdb50: a8c173fb    	ldp	x27, x28, [sp], #0x10
1005cdb54: a8c17bfd    	ldp	x29, x30, [sp], #0x10
1005cdb58: d65f0fff    	retab
1005cdb5c: eb18033f    	cmp	x25, x24
1005cdb60: 9a9f27fb    	cset	x27, lo
1005cdb64: eb18033f    	cmp	x25, x24
1005cdb68: 54000123    	b.lo	0x1005cdb8c <_mech_canonical_program_entry_v1_numeric_572+0x70c>
1005cdb6c: d298190c    	mov	x12, #0xc0c8            ; =49352
1005cdb70: cb0c0063    	sub	x3, x3, x12
1005cdb74: d1000884    	sub	x4, x4, #0x2
1005cdb78: 9100054a    	add	x10, x10, #0x1
1005cdb7c: aa1903e1    	mov	x1, x25
1005cdb80: f84183eb    	ldur	x11, [sp, #0x18]
1005cdb84: f84203fb    	ldur	x27, [sp, #0x20]
1005cdb88: 140001a6    	b	0x1005ce220 <_mech_canonical_program_entry_v1_numeric_572+0xda0>
1005cdb8c: f84383eb    	ldur	x11, [sp, #0x38]
1005cdb90: eb0b033f    	cmp	x25, x11
1005cdb94: 540008c3    	b.lo	0x1005cdcac <_mech_canonical_program_entry_v1_numeric_572+0x82c>
1005cdb98: 14000233    	b	0x1005ce464 <_mech_canonical_program_entry_v1_numeric_572+0xfe4>
1005cdb9c: f9659a63    	ldr	x3, [x19, #0x4b30]
1005cdba0: f9659e64    	ldr	x4, [x19, #0x4b38]
1005cdba4: d2800000    	mov	x0, #0x0                ; =0
1005cdba8: f9259660    	str	x0, [x19, #0x4b28]
1005cdbac: d2800060    	mov	x0, #0x3                ; =3
1005cdbb0: f84683eb    	ldur	x11, [sp, #0x68]
1005cdbb4: f100c97f    	cmp	x11, #0x32
1005cdbb8: 54006dc3    	b.lo	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005cdbbc: f967ba60    	ldr	x0, [x19, #0x4f70]
1005cdbc0: f84703e5    	ldur	x5, [sp, #0x70]
1005cdbc4: f90008a0    	str	x0, [x5, #0x10]
1005cdbc8: f967be61    	ldr	x1, [x19, #0x4f78]
1005cdbcc: f84703e8    	ldur	x8, [sp, #0x70]
1005cdbd0: f9000d01    	str	x1, [x8, #0x18]
1005cdbd4: f84703ea    	ldur	x10, [sp, #0x70]
1005cdbd8: f9000940    	str	x0, [x10, #0x10]
1005cdbdc: f84703ec    	ldur	x12, [sp, #0x70]
1005cdbe0: f9000d81    	str	x1, [x12, #0x18]
1005cdbe4: f967e260    	ldr	x0, [x19, #0x4fc0]
1005cdbe8: f84703ef    	ldur	x15, [sp, #0x70]
1005cdbec: f90031e0    	str	x0, [x15, #0x60]
1005cdbf0: f967e660    	ldr	x0, [x19, #0x4fc8]
1005cdbf4: f84703e1    	ldur	x1, [sp, #0x70]
1005cdbf8: f9003420    	str	x0, [x1, #0x68]
1005cdbfc: f967ea60    	ldr	x0, [x19, #0x4fd0]
1005cdc00: f9003820    	str	x0, [x1, #0x70]
1005cdc04: f9685e60    	ldr	x0, [x19, #0x50b8]
1005cdc08: f900ac20    	str	x0, [x1, #0x158]
1005cdc0c: f9686260    	ldr	x0, [x19, #0x50c0]
1005cdc10: f900b020    	str	x0, [x1, #0x160]
1005cdc14: f9686660    	ldr	x0, [x19, #0x50c8]
1005cdc18: f900b420    	str	x0, [x1, #0x168]
1005cdc1c: f9686a60    	ldr	x0, [x19, #0x50d0]
1005cdc20: f900b820    	str	x0, [x1, #0x170]
1005cdc24: f9686e60    	ldr	x0, [x19, #0x50d8]
1005cdc28: f900bc20    	str	x0, [x1, #0x178]
1005cdc2c: f9687261    	ldr	x1, [x19, #0x50e0]
1005cdc30: f84703e0    	ldur	x0, [sp, #0x70]
1005cdc34: f900c001    	str	x1, [x0, #0x180]
1005cdc38: d2804d01    	mov	x1, #0x268              ; =616
1005cdc3c: 92800102    	mov	x2, #-0x9               ; =-9
1005cdc40: f84803e7    	ldur	x7, [sp, #0x80]
1005cdc44: f84003e0    	ldur	x0, [sp]
1005cdc48: f84283e5    	ldur	x5, [sp, #0x28]
1005cdc4c: f84783e6    	ldur	x6, [sp, #0x78]
1005cdc50: d63f00e0    	blr	x7
1005cdc54: f100001f    	cmp	x0, #0x0
1005cdc58: 540045c1    	b.ne	0x1005ce510 <_mech_canonical_program_entry_v1_numeric_572+0x1090>
1005cdc5c: d2800060    	mov	x0, #0x3                ; =3
1005cdc60: f84683eb    	ldur	x11, [sp, #0x68]
1005cdc64: f100097f    	cmp	x11, #0x2
1005cdc68: 54006843    	b.lo	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005cdc6c: d2800005    	mov	x5, #0x0                ; =0
1005cdc70: f84703e3    	ldur	x3, [sp, #0x70]
1005cdc74: f9000065    	str	x5, [x3]
1005cdc78: f946026a    	ldr	x10, [x19, #0xc00]
1005cdc7c: f900046a    	str	x10, [x3, #0x8]
1005cdc80: d2804d01    	mov	x1, #0x268              ; =616
1005cdc84: f84003e0    	ldur	x0, [sp]
1005cdc88: f84783e6    	ldur	x6, [sp, #0x78]
1005cdc8c: f84803e7    	ldur	x7, [sp, #0x80]
1005cdc90: f84283e4    	ldur	x4, [sp, #0x28]
1005cdc94: aa0503e2    	mov	x2, x5
1005cdc98: d63f00e0    	blr	x7
1005cdc9c: f100001f    	cmp	x0, #0x0
1005cdca0: 540043c1    	b.ne	0x1005ce518 <_mech_canonical_program_entry_v1_numeric_572+0x1098>
1005cdca4: d2800060    	mov	x0, #0x3                ; =3
1005cdca8: 14000332    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005cdcac: f84403eb    	ldur	x11, [sp, #0x40]
1005cdcb0: f8797975    	ldr	x21, [x11, x25, lsl #3]
1005cdcb4: 910006ba    	add	x26, x21, #0x1
1005cdcb8: eb15035f    	cmp	x26, x21
1005cdcbc: 54004323    	b.lo	0x1005ce520 <_mech_canonical_program_entry_v1_numeric_572+0x10a0>
1005cdcc0: f84603eb    	ldur	x11, [sp, #0x60]
1005cdcc4: eb0b02bf    	cmp	x21, x11
1005cdcc8: 54000863    	b.lo	0x1005cddd4 <_mech_canonical_program_entry_v1_numeric_572+0x954>
1005cdccc: 14000237    	b	0x1005ce5a8 <_mech_canonical_program_entry_v1_numeric_572+0x1128>
1005cdcd0: f9659a63    	ldr	x3, [x19, #0x4b30]
1005cdcd4: f9659e64    	ldr	x4, [x19, #0x4b38]
1005cdcd8: d280000c    	mov	x12, #0x0               ; =0
1005cdcdc: f925966c    	str	x12, [x19, #0x4b28]
1005cdce0: d2800060    	mov	x0, #0x3                ; =3
1005cdce4: f84683eb    	ldur	x11, [sp, #0x68]
1005cdce8: f100c97f    	cmp	x11, #0x32
1005cdcec: 54006423    	b.lo	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005cdcf0: f967ba60    	ldr	x0, [x19, #0x4f70]
1005cdcf4: f84703e1    	ldur	x1, [sp, #0x70]
1005cdcf8: f9000820    	str	x0, [x1, #0x10]
1005cdcfc: f967be61    	ldr	x1, [x19, #0x4f78]
1005cdd00: f84703e2    	ldur	x2, [sp, #0x70]
1005cdd04: f9000c41    	str	x1, [x2, #0x18]
1005cdd08: f9000840    	str	x0, [x2, #0x10]
1005cdd0c: f84703e0    	ldur	x0, [sp, #0x70]
1005cdd10: f9000c01    	str	x1, [x0, #0x18]
1005cdd14: f967e260    	ldr	x0, [x19, #0x4fc0]
1005cdd18: f84703e1    	ldur	x1, [sp, #0x70]
1005cdd1c: f9003020    	str	x0, [x1, #0x60]
1005cdd20: f967e660    	ldr	x0, [x19, #0x4fc8]
1005cdd24: f9003420    	str	x0, [x1, #0x68]
1005cdd28: f967ea60    	ldr	x0, [x19, #0x4fd0]
1005cdd2c: f9003820    	str	x0, [x1, #0x70]
1005cdd30: f9685e60    	ldr	x0, [x19, #0x50b8]
1005cdd34: f900ac20    	str	x0, [x1, #0x158]
1005cdd38: f9686260    	ldr	x0, [x19, #0x50c0]
1005cdd3c: f900b020    	str	x0, [x1, #0x160]
1005cdd40: f9686660    	ldr	x0, [x19, #0x50c8]
1005cdd44: f900b420    	str	x0, [x1, #0x168]
1005cdd48: f9686a60    	ldr	x0, [x19, #0x50d0]
1005cdd4c: f900b820    	str	x0, [x1, #0x170]
1005cdd50: f9686e60    	ldr	x0, [x19, #0x50d8]
1005cdd54: f900bc20    	str	x0, [x1, #0x178]
1005cdd58: f9687260    	ldr	x0, [x19, #0x50e0]
1005cdd5c: f900c020    	str	x0, [x1, #0x180]
1005cdd60: d2804d41    	mov	x1, #0x26a              ; =618
1005cdd64: 92800102    	mov	x2, #-0x9               ; =-9
1005cdd68: f84803ef    	ldur	x15, [sp, #0x80]
1005cdd6c: f84003e0    	ldur	x0, [sp]
1005cdd70: f84283e5    	ldur	x5, [sp, #0x28]
1005cdd74: f84783e6    	ldur	x6, [sp, #0x78]
1005cdd78: d63f01e0    	blr	x15
1005cdd7c: f100001f    	cmp	x0, #0x0
1005cdd80: 540046a1    	b.ne	0x1005ce654 <_mech_canonical_program_entry_v1_numeric_572+0x11d4>
1005cdd84: d2800060    	mov	x0, #0x3                ; =3
1005cdd88: f84683eb    	ldur	x11, [sp, #0x68]
1005cdd8c: f100097f    	cmp	x11, #0x2
1005cdd90: 54005f03    	b.lo	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005cdd94: d2800005    	mov	x5, #0x0                ; =0
1005cdd98: f84703e3    	ldur	x3, [sp, #0x70]
1005cdd9c: f9000065    	str	x5, [x3]
1005cdda0: f9460a60    	ldr	x0, [x19, #0xc10]
1005cdda4: f9000460    	str	x0, [x3, #0x8]
1005cdda8: d2804d41    	mov	x1, #0x26a              ; =618
1005cddac: f84003e0    	ldur	x0, [sp]
1005cddb0: f84783e6    	ldur	x6, [sp, #0x78]
1005cddb4: f84803e7    	ldur	x7, [sp, #0x80]
1005cddb8: f84283e4    	ldur	x4, [sp, #0x28]
1005cddbc: aa0503e2    	mov	x2, x5
1005cddc0: d63f00e0    	blr	x7
1005cddc4: f100001f    	cmp	x0, #0x0
1005cddc8: 540044a1    	b.ne	0x1005ce65c <_mech_canonical_program_entry_v1_numeric_572+0x11dc>
1005cddcc: d2800060    	mov	x0, #0x3                ; =3
1005cddd0: 140002e8    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005cddd4: f84183e0    	ldur	x0, [sp, #0x18]
1005cddd8: f875780b    	ldr	x11, [x0, x21, lsl #3]
1005cdddc: 9100057c    	add	x28, x11, #0x1
1005cdde0: eb0b039f    	cmp	x28, x11
1005cdde4: 54004403    	b.lo	0x1005ce664 <_mech_canonical_program_entry_v1_numeric_572+0x11e4>
1005cdde8: f84583e0    	ldur	x0, [sp, #0x58]
1005cddec: eb00017f    	cmp	x11, x0
1005cddf0: 54000943    	b.lo	0x1005cdf18 <_mech_canonical_program_entry_v1_numeric_572+0xa98>
1005cddf4: 1400023f    	b	0x1005ce6f0 <_mech_canonical_program_entry_v1_numeric_572+0x1270>
1005cddf8: f9659a63    	ldr	x3, [x19, #0x4b30]
1005cddfc: f9659e64    	ldr	x4, [x19, #0x4b38]
1005cde00: d2800000    	mov	x0, #0x0                ; =0
1005cde04: f9259660    	str	x0, [x19, #0x4b28]
1005cde08: d2800060    	mov	x0, #0x3                ; =3
1005cde0c: f84683eb    	ldur	x11, [sp, #0x68]
1005cde10: f100c97f    	cmp	x11, #0x32
1005cde14: 54005ae3    	b.lo	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005cde18: f967ba60    	ldr	x0, [x19, #0x4f70]
1005cde1c: f84703e1    	ldur	x1, [sp, #0x70]
1005cde20: f9000820    	str	x0, [x1, #0x10]
1005cde24: f967be61    	ldr	x1, [x19, #0x4f78]
1005cde28: f84703e2    	ldur	x2, [sp, #0x70]
1005cde2c: f9000c41    	str	x1, [x2, #0x18]
1005cde30: f9000840    	str	x0, [x2, #0x10]
1005cde34: f9000c41    	str	x1, [x2, #0x18]
1005cde38: f967e260    	ldr	x0, [x19, #0x4fc0]
1005cde3c: f84703e5    	ldur	x5, [sp, #0x70]
1005cde40: f90030a0    	str	x0, [x5, #0x60]
1005cde44: f967e660    	ldr	x0, [x19, #0x4fc8]
1005cde48: f84703e7    	ldur	x7, [sp, #0x70]
1005cde4c: f90034e0    	str	x0, [x7, #0x68]
1005cde50: f967ea60    	ldr	x0, [x19, #0x4fd0]
1005cde54: f84703ea    	ldur	x10, [sp, #0x70]
1005cde58: f9003940    	str	x0, [x10, #0x70]
1005cde5c: f9685e60    	ldr	x0, [x19, #0x50b8]
1005cde60: f84703ed    	ldur	x13, [sp, #0x70]
1005cde64: f900ada0    	str	x0, [x13, #0x158]
1005cde68: f9686260    	ldr	x0, [x19, #0x50c0]
1005cde6c: f84703e1    	ldur	x1, [sp, #0x70]
1005cde70: f900b020    	str	x0, [x1, #0x160]
1005cde74: f9686660    	ldr	x0, [x19, #0x50c8]
1005cde78: f900b420    	str	x0, [x1, #0x168]
1005cde7c: f9686a60    	ldr	x0, [x19, #0x50d0]
1005cde80: f900b820    	str	x0, [x1, #0x170]
1005cde84: f9686e60    	ldr	x0, [x19, #0x50d8]
1005cde88: f900bc20    	str	x0, [x1, #0x178]
1005cde8c: f9687260    	ldr	x0, [x19, #0x50e0]
1005cde90: f900c020    	str	x0, [x1, #0x180]
1005cde94: d2804d81    	mov	x1, #0x26c              ; =620
1005cde98: 92800102    	mov	x2, #-0x9               ; =-9
1005cde9c: f84803e7    	ldur	x7, [sp, #0x80]
1005cdea0: f84003e0    	ldur	x0, [sp]
1005cdea4: f84283e5    	ldur	x5, [sp, #0x28]
1005cdea8: f84783e6    	ldur	x6, [sp, #0x78]
1005cdeac: d63f00e0    	blr	x7
1005cdeb0: f100001f    	cmp	x0, #0x0
1005cdeb4: 54004761    	b.ne	0x1005ce7a0 <_mech_canonical_program_entry_v1_numeric_572+0x1320>
1005cdeb8: d2800060    	mov	x0, #0x3                ; =3
1005cdebc: f84683eb    	ldur	x11, [sp, #0x68]
1005cdec0: f100097f    	cmp	x11, #0x2
1005cdec4: 54005569    	b.ls	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005cdec8: d2800005    	mov	x5, #0x0                ; =0
1005cdecc: f84703e3    	ldur	x3, [sp, #0x70]
1005cded0: f9000065    	str	x5, [x3]
1005cded4: f945ee63    	ldr	x3, [x19, #0xbd8]
1005cded8: f84703e0    	ldur	x0, [sp, #0x70]
1005cdedc: f9000403    	str	x3, [x0, #0x8]
1005cdee0: f9461264    	ldr	x4, [x19, #0xc20]
1005cdee4: f84703e3    	ldur	x3, [sp, #0x70]
1005cdee8: f9000864    	str	x4, [x3, #0x10]
1005cdeec: d2804d81    	mov	x1, #0x26c              ; =620
1005cdef0: d2800064    	mov	x4, #0x3                ; =3
1005cdef4: f84003e0    	ldur	x0, [sp]
1005cdef8: f84783e6    	ldur	x6, [sp, #0x78]
1005cdefc: f84803e7    	ldur	x7, [sp, #0x80]
1005cdf00: aa0503e2    	mov	x2, x5
1005cdf04: d63f00e0    	blr	x7
1005cdf08: f100001f    	cmp	x0, #0x0
1005cdf0c: 540044e1    	b.ne	0x1005ce7a8 <_mech_canonical_program_entry_v1_numeric_572+0x1328>
1005cdf10: d2800060    	mov	x0, #0x3                ; =3
1005cdf14: 14000297    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005cdf18: f84083e0    	ldur	x0, [sp, #0x8]
1005cdf1c: f86b780c    	ldr	x12, [x0, x11, lsl #3]
1005cdf20: d298190e    	mov	x14, #0xc0c8            ; =49352
1005cdf24: cb0e0063    	sub	x3, x3, x14
1005cdf28: d1000884    	sub	x4, x4, #0x2
1005cdf2c: 9100054a    	add	x10, x10, #0x1
1005cdf30: eb17019f    	cmp	x12, x23
1005cdf34: 54000061    	b.ne	0x1005cdf40 <_mech_canonical_program_entry_v1_numeric_572+0xac0>
1005cdf38: f80083e0    	stur	x0, [sp, #0x8]
1005cdf3c: 14000036    	b	0x1005ce014 <_mech_canonical_program_entry_v1_numeric_572+0xb94>
1005cdf40: f84103e1    	ldur	x1, [sp, #0x10]
1005cdf44: b5000621    	cbnz	x1, 0x1005ce008 <_mech_canonical_program_entry_v1_numeric_572+0xb88>
1005cdf48: 1400021a    	b	0x1005ce7b0 <_mech_canonical_program_entry_v1_numeric_572+0x1330>
1005cdf4c: f84703ee    	ldur	x14, [sp, #0x70]
1005cdf50: f90009d7    	str	x23, [x14, #0x10]
1005cdf54: f84703ef    	ldur	x15, [sp, #0x70]
1005cdf58: f9000df6    	str	x22, [x15, #0x18]
1005cdf5c: f84703e0    	ldur	x0, [sp, #0x70]
1005cdf60: f9000817    	str	x23, [x0, #0x10]
1005cdf64: f9000c16    	str	x22, [x0, #0x18]
1005cdf68: f9003019    	str	x25, [x0, #0x60]
1005cdf6c: f9003418    	str	x24, [x0, #0x68]
1005cdf70: f9003817    	str	x23, [x0, #0x70]
1005cdf74: f900ac05    	str	x5, [x0, #0x158]
1005cdf78: f900b002    	str	x2, [x0, #0x160]
1005cdf7c: f900b40d    	str	x13, [x0, #0x168]
1005cdf80: f900b80a    	str	x10, [x0, #0x170]
1005cdf84: f900bc08    	str	x8, [x0, #0x178]
1005cdf88: f900c007    	str	x7, [x0, #0x180]
1005cdf8c: f900c81c    	str	x28, [x0, #0x190]
1005cdf90: f900cc17    	str	x23, [x0, #0x198]
1005cdf94: 92800342    	mov	x2, #-0x1b              ; =-27
1005cdf98: d2800005    	mov	x5, #0x0                ; =0
1005cdf9c: f84803e7    	ldur	x7, [sp, #0x80]
1005cdfa0: f84003e0    	ldur	x0, [sp]
1005cdfa4: f84783e6    	ldur	x6, [sp, #0x78]
1005cdfa8: d63f00e0    	blr	x7
1005cdfac: f100001f    	cmp	x0, #0x0
1005cdfb0: 54004121    	b.ne	0x1005ce7d4 <_mech_canonical_program_entry_v1_numeric_572+0x1354>
1005cdfb4: f84703e3    	ldur	x3, [sp, #0x70]
1005cdfb8: f9400063    	ldr	x3, [x3]
1005cdfbc: f84703e0    	ldur	x0, [sp, #0x70]
1005cdfc0: f9400404    	ldr	x4, [x0, #0x8]
1005cdfc4: f9406c00    	ldr	x0, [x0, #0xd8]
1005cdfc8: f84703e1    	ldur	x1, [sp, #0x70]
1005cdfcc: f940a021    	ldr	x1, [x1, #0x140]
1005cdfd0: f80103e1    	stur	x1, [sp, #0x10]
1005cdfd4: f84703e1    	ldur	x1, [sp, #0x70]
1005cdfd8: f940ac25    	ldr	x5, [x1, #0x158]
1005cdfdc: f940b022    	ldr	x2, [x1, #0x160]
1005cdfe0: f940b42d    	ldr	x13, [x1, #0x168]
1005cdfe4: f940b82a    	ldr	x10, [x1, #0x170]
1005cdfe8: f84703e6    	ldur	x6, [sp, #0x70]
1005cdfec: f940bcc8    	ldr	x8, [x6, #0x178]
1005cdff0: f940c0c7    	ldr	x7, [x6, #0x180]
1005cdff4: f94008c9    	ldr	x9, [x6, #0x10]
1005cdff8: d2800026    	mov	x6, #0x1                ; =1
1005cdffc: f9259666    	str	x6, [x19, #0x4b28]
1005ce000: f80083e0    	stur	x0, [sp, #0x8]
1005ce004: 14000004    	b	0x1005ce014 <_mech_canonical_program_entry_v1_numeric_572+0xb94>
1005ce008: f80103e1    	stur	x1, [sp, #0x10]
1005ce00c: f82b7817    	str	x23, [x0, x11, lsl #3]
1005ce010: f80083e0    	stur	x0, [sp, #0x8]
1005ce014: f84603eb    	ldur	x11, [sp, #0x60]
1005ce018: eb0b02bf    	cmp	x21, x11
1005ce01c: 540008e3    	b.lo	0x1005ce138 <_mech_canonical_program_entry_v1_numeric_572+0xcb8>
1005ce020: 140001ef    	b	0x1005ce7dc <_mech_canonical_program_entry_v1_numeric_572+0x135c>
1005ce024: f9659a63    	ldr	x3, [x19, #0x4b30]
1005ce028: f9659e64    	ldr	x4, [x19, #0x4b38]
1005ce02c: d280000f    	mov	x15, #0x0               ; =0
1005ce030: f925966f    	str	x15, [x19, #0x4b28]
1005ce034: d2800060    	mov	x0, #0x3                ; =3
1005ce038: f84683eb    	ldur	x11, [sp, #0x68]
1005ce03c: f100c97f    	cmp	x11, #0x32
1005ce040: 54004983    	b.lo	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce044: f967ba60    	ldr	x0, [x19, #0x4f70]
1005ce048: f84703e5    	ldur	x5, [sp, #0x70]
1005ce04c: f90008a0    	str	x0, [x5, #0x10]
1005ce050: f967be61    	ldr	x1, [x19, #0x4f78]
1005ce054: f84703e6    	ldur	x6, [sp, #0x70]
1005ce058: f9000cc1    	str	x1, [x6, #0x18]
1005ce05c: f84703e8    	ldur	x8, [sp, #0x70]
1005ce060: f9000900    	str	x0, [x8, #0x10]
1005ce064: f84703ea    	ldur	x10, [sp, #0x70]
1005ce068: f9000d41    	str	x1, [x10, #0x18]
1005ce06c: f967e260    	ldr	x0, [x19, #0x4fc0]
1005ce070: f84703ed    	ldur	x13, [sp, #0x70]
1005ce074: f90031a0    	str	x0, [x13, #0x60]
1005ce078: f967e660    	ldr	x0, [x19, #0x4fc8]
1005ce07c: f84703e1    	ldur	x1, [sp, #0x70]
1005ce080: f9003420    	str	x0, [x1, #0x68]
1005ce084: f967ea60    	ldr	x0, [x19, #0x4fd0]
1005ce088: f9003820    	str	x0, [x1, #0x70]
1005ce08c: f9685e60    	ldr	x0, [x19, #0x50b8]
1005ce090: f900ac20    	str	x0, [x1, #0x158]
1005ce094: f9686260    	ldr	x0, [x19, #0x50c0]
1005ce098: f900b020    	str	x0, [x1, #0x160]
1005ce09c: f9686660    	ldr	x0, [x19, #0x50c8]
1005ce0a0: f900b420    	str	x0, [x1, #0x168]
1005ce0a4: f9686a60    	ldr	x0, [x19, #0x50d0]
1005ce0a8: f900b820    	str	x0, [x1, #0x170]
1005ce0ac: f9686e60    	ldr	x0, [x19, #0x50d8]
1005ce0b0: f900bc20    	str	x0, [x1, #0x178]
1005ce0b4: f9687260    	ldr	x0, [x19, #0x50e0]
1005ce0b8: f900c020    	str	x0, [x1, #0x180]
1005ce0bc: d2804de1    	mov	x1, #0x26f              ; =623
1005ce0c0: 92800102    	mov	x2, #-0x9               ; =-9
1005ce0c4: f84803e7    	ldur	x7, [sp, #0x80]
1005ce0c8: f84003e0    	ldur	x0, [sp]
1005ce0cc: f84283e5    	ldur	x5, [sp, #0x28]
1005ce0d0: f84783e6    	ldur	x6, [sp, #0x78]
1005ce0d4: d63f00e0    	blr	x7
1005ce0d8: f100001f    	cmp	x0, #0x0
1005ce0dc: 54003ce1    	b.ne	0x1005ce878 <_mech_canonical_program_entry_v1_numeric_572+0x13f8>
1005ce0e0: d2800060    	mov	x0, #0x3                ; =3
1005ce0e4: f84683eb    	ldur	x11, [sp, #0x68]
1005ce0e8: f100097f    	cmp	x11, #0x2
1005ce0ec: 54004429    	b.ls	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce0f0: d2800005    	mov	x5, #0x0                ; =0
1005ce0f4: f84703e3    	ldur	x3, [sp, #0x70]
1005ce0f8: f9000065    	str	x5, [x3]
1005ce0fc: f9461e60    	ldr	x0, [x19, #0xc38]
1005ce100: f9000460    	str	x0, [x3, #0x8]
1005ce104: f9461a60    	ldr	x0, [x19, #0xc30]
1005ce108: f9000860    	str	x0, [x3, #0x10]
1005ce10c: d2804de1    	mov	x1, #0x26f              ; =623
1005ce110: d2800064    	mov	x4, #0x3                ; =3
1005ce114: f84003e0    	ldur	x0, [sp]
1005ce118: f84783e6    	ldur	x6, [sp, #0x78]
1005ce11c: f84803ef    	ldur	x15, [sp, #0x80]
1005ce120: aa0503e2    	mov	x2, x5
1005ce124: d63f01e0    	blr	x15
1005ce128: f100001f    	cmp	x0, #0x0
1005ce12c: 54003aa1    	b.ne	0x1005ce880 <_mech_canonical_program_entry_v1_numeric_572+0x1400>
1005ce130: d2800060    	mov	x0, #0x3                ; =3
1005ce134: 1400020f    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce138: f84183eb    	ldur	x11, [sp, #0x18]
1005ce13c: f8757960    	ldr	x0, [x11, x21, lsl #3]
1005ce140: eb1c001f    	cmp	x0, x28
1005ce144: 54000081    	b.ne	0x1005ce154 <_mech_canonical_program_entry_v1_numeric_572+0xcd4>
1005ce148: aa1903e1    	mov	x1, x25
1005ce14c: f84203fb    	ldur	x27, [sp, #0x20]
1005ce150: 14000034    	b	0x1005ce220 <_mech_canonical_program_entry_v1_numeric_572+0xda0>
1005ce154: f84203fb    	ldur	x27, [sp, #0x20]
1005ce158: b500061b    	cbnz	x27, 0x1005ce218 <_mech_canonical_program_entry_v1_numeric_572+0xd98>
1005ce15c: 140001cb    	b	0x1005ce888 <_mech_canonical_program_entry_v1_numeric_572+0x1408>
1005ce160: f84703e0    	ldur	x0, [sp, #0x70]
1005ce164: f9000817    	str	x23, [x0, #0x10]
1005ce168: f9000c16    	str	x22, [x0, #0x18]
1005ce16c: f9000817    	str	x23, [x0, #0x10]
1005ce170: f9000c16    	str	x22, [x0, #0x18]
1005ce174: f9003019    	str	x25, [x0, #0x60]
1005ce178: f9003418    	str	x24, [x0, #0x68]
1005ce17c: f9003817    	str	x23, [x0, #0x70]
1005ce180: f900ac05    	str	x5, [x0, #0x158]
1005ce184: f900b002    	str	x2, [x0, #0x160]
1005ce188: f900b40d    	str	x13, [x0, #0x168]
1005ce18c: f900b80a    	str	x10, [x0, #0x170]
1005ce190: f900bc08    	str	x8, [x0, #0x178]
1005ce194: f900c007    	str	x7, [x0, #0x180]
1005ce198: f900c81a    	str	x26, [x0, #0x190]
1005ce19c: f900cc1c    	str	x28, [x0, #0x198]
1005ce1a0: 92800342    	mov	x2, #-0x1b              ; =-27
1005ce1a4: d2800005    	mov	x5, #0x0                ; =0
1005ce1a8: f84803e7    	ldur	x7, [sp, #0x80]
1005ce1ac: f84003e0    	ldur	x0, [sp]
1005ce1b0: f84783e6    	ldur	x6, [sp, #0x78]
1005ce1b4: d63f00e0    	blr	x7
1005ce1b8: f100001f    	cmp	x0, #0x0
1005ce1bc: 54003781    	b.ne	0x1005ce8ac <_mech_canonical_program_entry_v1_numeric_572+0x142c>
1005ce1c0: f84703e3    	ldur	x3, [sp, #0x70]
1005ce1c4: f9400063    	ldr	x3, [x3]
1005ce1c8: f84703e0    	ldur	x0, [sp, #0x70]
1005ce1cc: f9400404    	ldr	x4, [x0, #0x8]
1005ce1d0: f9405c0b    	ldr	x11, [x0, #0xb8]
1005ce1d4: f9409c1b    	ldr	x27, [x0, #0x138]
1005ce1d8: f940ac05    	ldr	x5, [x0, #0x158]
1005ce1dc: f84703e1    	ldur	x1, [sp, #0x70]
1005ce1e0: f940b022    	ldr	x2, [x1, #0x160]
1005ce1e4: f84703e6    	ldur	x6, [sp, #0x70]
1005ce1e8: f940b4cd    	ldr	x13, [x6, #0x168]
1005ce1ec: f940b8ca    	ldr	x10, [x6, #0x170]
1005ce1f0: f84703e7    	ldur	x7, [sp, #0x70]
1005ce1f4: f940bce8    	ldr	x8, [x7, #0x178]
1005ce1f8: f84703e9    	ldur	x9, [sp, #0x70]
1005ce1fc: f940c127    	ldr	x7, [x9, #0x180]
1005ce200: f84703ec    	ldur	x12, [sp, #0x70]
1005ce204: f9400989    	ldr	x9, [x12, #0x10]
1005ce208: d2800026    	mov	x6, #0x1                ; =1
1005ce20c: f9259666    	str	x6, [x19, #0x4b28]
1005ce210: aa1903e1    	mov	x1, x25
1005ce214: 14000003    	b	0x1005ce220 <_mech_canonical_program_entry_v1_numeric_572+0xda0>
1005ce218: f835797c    	str	x28, [x11, x21, lsl #3]
1005ce21c: aa1903e1    	mov	x1, x25
1005ce220: eb18033f    	cmp	x25, x24
1005ce224: 54000663    	b.lo	0x1005ce2f0 <_mech_canonical_program_entry_v1_numeric_572+0xe70>
1005ce228: d2800000    	mov	x0, #0x0                ; =0
1005ce22c: f9035920    	str	x0, [x9, #0x6b0]
1005ce230: f9035d20    	str	x0, [x9, #0x6b8]
1005ce234: f9036120    	str	x0, [x9, #0x6c0]
1005ce238: f9036520    	str	x0, [x9, #0x6c8]
1005ce23c: f9036920    	str	x0, [x9, #0x6d0]
1005ce240: f9036d20    	str	x0, [x9, #0x6d8]
1005ce244: d2800008    	mov	x8, #0x0                ; =0
1005ce248: aa0803e7    	mov	x7, x8
1005ce24c: aa1703ec    	mov	x12, x23
1005ce250: aa1703ee    	mov	x14, x23
1005ce254: eb1602ff    	cmp	x23, x22
1005ce258: 540003a3    	b.lo	0x1005ce2cc <_mech_canonical_program_entry_v1_numeric_572+0xe4c>
1005ce25c: d2800020    	mov	x0, #0x1                ; =1
1005ce260: f9001a60    	str	x0, [x19, #0x30]
1005ce264: d2800041    	mov	x1, #0x2                ; =2
1005ce268: f9002261    	str	x1, [x19, #0x40]
1005ce26c: d2800001    	mov	x1, #0x0                ; =0
1005ce270: f900c661    	str	x1, [x19, #0x188]
1005ce274: f900ca60    	str	x0, [x19, #0x190]
1005ce278: f9259666    	str	x6, [x19, #0x4b28]
1005ce27c: f9259a63    	str	x3, [x19, #0x4b30]
1005ce280: f9259e64    	str	x4, [x19, #0x4b38]
1005ce284: f927ba6e    	str	x14, [x19, #0x4f70]
1005ce288: f927be76    	str	x22, [x19, #0x4f78]
1005ce28c: f9285e65    	str	x5, [x19, #0x50b8]
1005ce290: f9286262    	str	x2, [x19, #0x50c0]
1005ce294: f928666d    	str	x13, [x19, #0x50c8]
1005ce298: f9286a6a    	str	x10, [x19, #0x50d0]
1005ce29c: f9286e68    	str	x8, [x19, #0x50d8]
1005ce2a0: f9287267    	str	x7, [x19, #0x50e0]
1005ce2a4: d2800000    	mov	x0, #0x0                ; =0
1005ce2a8: d2800021    	mov	x1, #0x1                ; =1
1005ce2ac: 910243ff    	add	sp, sp, #0x90
1005ce2b0: a8c153f3    	ldp	x19, x20, [sp], #0x10
1005ce2b4: a8c15bf5    	ldp	x21, x22, [sp], #0x10
1005ce2b8: a8c163f7    	ldp	x23, x24, [sp], #0x10
1005ce2bc: a8c16bf9    	ldp	x25, x26, [sp], #0x10
1005ce2c0: a8c173fb    	ldp	x27, x28, [sp], #0x10
1005ce2c4: a8c17bfd    	ldp	x29, x30, [sp], #0x10
1005ce2c8: d65f0fff    	retab
1005ce2cc: 91000597    	add	x23, x12, #0x1
1005ce2d0: eb0c02ff    	cmp	x23, x12
1005ce2d4: 54002f03    	b.lo	0x1005ce8b4 <_mech_canonical_program_entry_v1_numeric_572+0x1434>
1005ce2d8: d280002d    	mov	x13, #0x1               ; =1
1005ce2dc: aa1303e1    	mov	x1, x19
1005ce2e0: aa1403f8    	mov	x24, x20
1005ce2e4: f80183eb    	stur	x11, [sp, #0x18]
1005ce2e8: f80203fb    	stur	x27, [sp, #0x20]
1005ce2ec: 17fffcc1    	b	0x1005cd5f0 <_mech_canonical_program_entry_v1_numeric_572+0x170>
1005ce2f0: 91000439    	add	x25, x1, #0x1
1005ce2f4: eb01033f    	cmp	x25, x1
1005ce2f8: 54003083    	b.lo	0x1005ce908 <_mech_canonical_program_entry_v1_numeric_572+0x1488>
1005ce2fc: d2800027    	mov	x7, #0x1                ; =1
1005ce300: f80183eb    	stur	x11, [sp, #0x18]
1005ce304: f80203fb    	stur	x27, [sp, #0x20]
1005ce308: 17fffdb9    	b	0x1005cd9ec <_mech_canonical_program_entry_v1_numeric_572+0x56c>
1005ce30c: aa0303e0    	mov	x0, x3
1005ce310: 14000198    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce314: aa0103e0    	mov	x0, x1
1005ce318: 14000196    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce31c: aa0303e0    	mov	x0, x3
1005ce320: 14000194    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce324: d280498f    	mov	x15, #0x24c             ; =588
1005ce328: aa1803f4    	mov	x20, x24
1005ce32c: f900268f    	str	x15, [x20, #0x48]
1005ce330: d2800020    	mov	x0, #0x1                ; =1
1005ce334: f9001a60    	str	x0, [x19, #0x30]
1005ce338: d2800054    	mov	x20, #0x2               ; =2
1005ce33c: f9002274    	str	x20, [x19, #0x40]
1005ce340: d2800001    	mov	x1, #0x0                ; =0
1005ce344: f900c661    	str	x1, [x19, #0x188]
1005ce348: f900ca60    	str	x0, [x19, #0x190]
1005ce34c: f9059277    	str	x23, [x19, #0xb20]
1005ce350: f9059676    	str	x22, [x19, #0xb28]
1005ce354: f84303e0    	ldur	x0, [sp, #0x30]
1005ce358: 53001c00    	uxtb	w0, w0
1005ce35c: f905a260    	str	x0, [x19, #0xb40]
1005ce360: 910006e0    	add	x0, x23, #0x1
1005ce364: f905aa60    	str	x0, [x19, #0xb50]
1005ce368: f9259666    	str	x6, [x19, #0x4b28]
1005ce36c: d2986900    	mov	x0, #0xc348             ; =49992
1005ce370: cb000060    	sub	x0, x3, x0
1005ce374: f9259a60    	str	x0, [x19, #0x4b30]
1005ce378: f9259e64    	str	x4, [x19, #0x4b38]
1005ce37c: f927ba77    	str	x23, [x19, #0x4f70]
1005ce380: f927be76    	str	x22, [x19, #0x4f78]
1005ce384: 910004a0    	add	x0, x5, #0x1
1005ce388: f9285e60    	str	x0, [x19, #0x50b8]
1005ce38c: f9286262    	str	x2, [x19, #0x50c0]
1005ce390: f928666d    	str	x13, [x19, #0x50c8]
1005ce394: f9286a6a    	str	x10, [x19, #0x50d0]
1005ce398: f9286e68    	str	x8, [x19, #0x50d8]
1005ce39c: f9287267    	str	x7, [x19, #0x50e0]
1005ce3a0: f9659660    	ldr	x0, [x19, #0x4b28]
1005ce3a4: f100001f    	cmp	x0, #0x0
1005ce3a8: 54ff9fc1    	b.ne	0x1005cd7a0 <_mech_canonical_program_entry_v1_numeric_572+0x320>
1005ce3ac: 17fffcf9    	b	0x1005cd790 <_mech_canonical_program_entry_v1_numeric_572+0x310>
1005ce3b0: aa1403e0    	mov	x0, x20
1005ce3b4: 1400016f    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce3b8: aa1403e0    	mov	x0, x20
1005ce3bc: 1400016d    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce3c0: d28049cb    	mov	x11, #0x24e             ; =590
1005ce3c4: f900268b    	str	x11, [x20, #0x48]
1005ce3c8: d280002b    	mov	x11, #0x1               ; =1
1005ce3cc: f9001a6b    	str	x11, [x19, #0x30]
1005ce3d0: d2800054    	mov	x20, #0x2               ; =2
1005ce3d4: f9002274    	str	x20, [x19, #0x40]
1005ce3d8: d280000e    	mov	x14, #0x0               ; =0
1005ce3dc: f900c66e    	str	x14, [x19, #0x188]
1005ce3e0: f900ca6b    	str	x11, [x19, #0x190]
1005ce3e4: f9059277    	str	x23, [x19, #0xb20]
1005ce3e8: f9059676    	str	x22, [x19, #0xb28]
1005ce3ec: f84303e0    	ldur	x0, [sp, #0x30]
1005ce3f0: 53001c00    	uxtb	w0, w0
1005ce3f4: f905a260    	str	x0, [x19, #0xb40]
1005ce3f8: f905ae79    	str	x25, [x19, #0xb58]
1005ce3fc: 91000ae0    	add	x0, x23, #0x2
1005ce400: f905b260    	str	x0, [x19, #0xb60]
1005ce404: f9259666    	str	x6, [x19, #0x4b28]
1005ce408: d2986900    	mov	x0, #0xc348             ; =49992
1005ce40c: cb000060    	sub	x0, x3, x0
1005ce410: f9259a60    	str	x0, [x19, #0x4b30]
1005ce414: f9259e64    	str	x4, [x19, #0x4b38]
1005ce418: f927ba77    	str	x23, [x19, #0x4f70]
1005ce41c: f927be76    	str	x22, [x19, #0x4f78]
1005ce420: 910004a0    	add	x0, x5, #0x1
1005ce424: f9285e60    	str	x0, [x19, #0x50b8]
1005ce428: f9286262    	str	x2, [x19, #0x50c0]
1005ce42c: f928666d    	str	x13, [x19, #0x50c8]
1005ce430: f9286a6a    	str	x10, [x19, #0x50d0]
1005ce434: f9286e68    	str	x8, [x19, #0x50d8]
1005ce438: f9287267    	str	x7, [x19, #0x50e0]
1005ce43c: f9659660    	ldr	x0, [x19, #0x4b28]
1005ce440: f100001f    	cmp	x0, #0x0
1005ce444: 54ffa401    	b.ne	0x1005cd8c4 <_mech_canonical_program_entry_v1_numeric_572+0x444>
1005ce448: 17fffd4c    	b	0x1005cd978 <_mech_canonical_program_entry_v1_numeric_572+0x4f8>
1005ce44c: aa1403e0    	mov	x0, x20
1005ce450: 14000148    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce454: aa1403e0    	mov	x0, x20
1005ce458: 14000146    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce45c: f84283e0    	ldur	x0, [sp, #0x28]
1005ce460: 14000144    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce464: d2804d00    	mov	x0, #0x268              ; =616
1005ce468: f9002680    	str	x0, [x20, #0x48]
1005ce46c: d2800020    	mov	x0, #0x1                ; =1
1005ce470: f9001a60    	str	x0, [x19, #0x30]
1005ce474: f84283e1    	ldur	x1, [sp, #0x28]
1005ce478: f9002261    	str	x1, [x19, #0x40]
1005ce47c: d2800001    	mov	x1, #0x0                ; =0
1005ce480: f900c661    	str	x1, [x19, #0x188]
1005ce484: f900ca60    	str	x0, [x19, #0x190]
1005ce488: f9059277    	str	x23, [x19, #0xb20]
1005ce48c: f9059676    	str	x22, [x19, #0xb28]
1005ce490: f84303f4    	ldur	x20, [sp, #0x30]
1005ce494: 53001e80    	uxtb	w0, w20
1005ce498: f905a260    	str	x0, [x19, #0xb40]
1005ce49c: f905e679    	str	x25, [x19, #0xbc8]
1005ce4a0: f905ea78    	str	x24, [x19, #0xbd0]
1005ce4a4: f905ee77    	str	x23, [x19, #0xbd8]
1005ce4a8: 53001f60    	uxtb	w0, w27
1005ce4ac: f905fa60    	str	x0, [x19, #0xbf0]
1005ce4b0: 91000720    	add	x0, x25, #0x1
1005ce4b4: f9060260    	str	x0, [x19, #0xc00]
1005ce4b8: f9259666    	str	x6, [x19, #0x4b28]
1005ce4bc: d2981900    	mov	x0, #0xc0c8             ; =49352
1005ce4c0: cb000060    	sub	x0, x3, x0
1005ce4c4: f9259a60    	str	x0, [x19, #0x4b30]
1005ce4c8: d1000880    	sub	x0, x4, #0x2
1005ce4cc: f9259e60    	str	x0, [x19, #0x4b38]
1005ce4d0: f927ba77    	str	x23, [x19, #0x4f70]
1005ce4d4: f927be76    	str	x22, [x19, #0x4f78]
1005ce4d8: f927e279    	str	x25, [x19, #0x4fc0]
1005ce4dc: f927e678    	str	x24, [x19, #0x4fc8]
1005ce4e0: f927ea77    	str	x23, [x19, #0x4fd0]
1005ce4e4: f9285e65    	str	x5, [x19, #0x50b8]
1005ce4e8: f9286262    	str	x2, [x19, #0x50c0]
1005ce4ec: f928666d    	str	x13, [x19, #0x50c8]
1005ce4f0: 91000540    	add	x0, x10, #0x1
1005ce4f4: f9286a60    	str	x0, [x19, #0x50d0]
1005ce4f8: f9286e68    	str	x8, [x19, #0x50d8]
1005ce4fc: f9287267    	str	x7, [x19, #0x50e0]
1005ce500: f9659660    	ldr	x0, [x19, #0x4b28]
1005ce504: f100001f    	cmp	x0, #0x0
1005ce508: 54ffb4a1    	b.ne	0x1005cdb9c <_mech_canonical_program_entry_v1_numeric_572+0x71c>
1005ce50c: 17fffdd4    	b	0x1005cdc5c <_mech_canonical_program_entry_v1_numeric_572+0x7dc>
1005ce510: f84283e0    	ldur	x0, [sp, #0x28]
1005ce514: 14000117    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce518: f84283e0    	ldur	x0, [sp, #0x28]
1005ce51c: 14000115    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce520: d2804d20    	mov	x0, #0x269              ; =617
1005ce524: f9002680    	str	x0, [x20, #0x48]
1005ce528: d2800020    	mov	x0, #0x1                ; =1
1005ce52c: f9001a60    	str	x0, [x19, #0x30]
1005ce530: f84283e1    	ldur	x1, [sp, #0x28]
1005ce534: f9002261    	str	x1, [x19, #0x40]
1005ce538: d2800001    	mov	x1, #0x0                ; =0
1005ce53c: f900c661    	str	x1, [x19, #0x188]
1005ce540: f900ca60    	str	x0, [x19, #0x190]
1005ce544: f9059277    	str	x23, [x19, #0xb20]
1005ce548: f9059676    	str	x22, [x19, #0xb28]
1005ce54c: f84303f4    	ldur	x20, [sp, #0x30]
1005ce550: 53001e81    	uxtb	w1, w20
1005ce554: f905a261    	str	x1, [x19, #0xb40]
1005ce558: f905e679    	str	x25, [x19, #0xbc8]
1005ce55c: f905ea78    	str	x24, [x19, #0xbd0]
1005ce560: f905ee77    	str	x23, [x19, #0xbd8]
1005ce564: 53001f61    	uxtb	w1, w27
1005ce568: f905fa61    	str	x1, [x19, #0xbf0]
1005ce56c: f9060675    	str	x21, [x19, #0xc08]
1005ce570: f9259666    	str	x6, [x19, #0x4b28]
1005ce574: d2981901    	mov	x1, #0xc0c8             ; =49352
1005ce578: cb010061    	sub	x1, x3, x1
1005ce57c: f9259a61    	str	x1, [x19, #0x4b30]
1005ce580: d1000881    	sub	x1, x4, #0x2
1005ce584: f9259e61    	str	x1, [x19, #0x4b38]
1005ce588: f9285e65    	str	x5, [x19, #0x50b8]
1005ce58c: f9286262    	str	x2, [x19, #0x50c0]
1005ce590: f928666d    	str	x13, [x19, #0x50c8]
1005ce594: 91000541    	add	x1, x10, #0x1
1005ce598: f9286a61    	str	x1, [x19, #0x50d0]
1005ce59c: f9286e68    	str	x8, [x19, #0x50d8]
1005ce5a0: f9287267    	str	x7, [x19, #0x50e0]
1005ce5a4: 140000f3    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce5a8: d2804d40    	mov	x0, #0x26a              ; =618
1005ce5ac: f9002680    	str	x0, [x20, #0x48]
1005ce5b0: d2800020    	mov	x0, #0x1                ; =1
1005ce5b4: f9001a60    	str	x0, [x19, #0x30]
1005ce5b8: f84283e1    	ldur	x1, [sp, #0x28]
1005ce5bc: f9002261    	str	x1, [x19, #0x40]
1005ce5c0: d2800001    	mov	x1, #0x0                ; =0
1005ce5c4: f900c661    	str	x1, [x19, #0x188]
1005ce5c8: f900ca60    	str	x0, [x19, #0x190]
1005ce5cc: f9059277    	str	x23, [x19, #0xb20]
1005ce5d0: f9059676    	str	x22, [x19, #0xb28]
1005ce5d4: f84303f4    	ldur	x20, [sp, #0x30]
1005ce5d8: 53001e80    	uxtb	w0, w20
1005ce5dc: f905a260    	str	x0, [x19, #0xb40]
1005ce5e0: f905e679    	str	x25, [x19, #0xbc8]
1005ce5e4: f905ea78    	str	x24, [x19, #0xbd0]
1005ce5e8: f905ee77    	str	x23, [x19, #0xbd8]
1005ce5ec: 53001f60    	uxtb	w0, w27
1005ce5f0: f905fa60    	str	x0, [x19, #0xbf0]
1005ce5f4: f9060675    	str	x21, [x19, #0xc08]
1005ce5f8: f9060a7a    	str	x26, [x19, #0xc10]
1005ce5fc: f9259666    	str	x6, [x19, #0x4b28]
1005ce600: d2981900    	mov	x0, #0xc0c8             ; =49352
1005ce604: cb000060    	sub	x0, x3, x0
1005ce608: f9259a60    	str	x0, [x19, #0x4b30]
1005ce60c: d1000880    	sub	x0, x4, #0x2
1005ce610: f9259e60    	str	x0, [x19, #0x4b38]
1005ce614: f927ba77    	str	x23, [x19, #0x4f70]
1005ce618: f927be76    	str	x22, [x19, #0x4f78]
1005ce61c: f927e279    	str	x25, [x19, #0x4fc0]
1005ce620: f927e678    	str	x24, [x19, #0x4fc8]
1005ce624: f927ea77    	str	x23, [x19, #0x4fd0]
1005ce628: f9285e65    	str	x5, [x19, #0x50b8]
1005ce62c: f9286262    	str	x2, [x19, #0x50c0]
1005ce630: f928666d    	str	x13, [x19, #0x50c8]
1005ce634: 91000546    	add	x6, x10, #0x1
1005ce638: f9286a66    	str	x6, [x19, #0x50d0]
1005ce63c: f9286e68    	str	x8, [x19, #0x50d8]
1005ce640: f9287267    	str	x7, [x19, #0x50e0]
1005ce644: f9659669    	ldr	x9, [x19, #0x4b28]
1005ce648: f100013f    	cmp	x9, #0x0
1005ce64c: 54ffb421    	b.ne	0x1005cdcd0 <_mech_canonical_program_entry_v1_numeric_572+0x850>
1005ce650: 17fffdcd    	b	0x1005cdd84 <_mech_canonical_program_entry_v1_numeric_572+0x904>
1005ce654: f84283e0    	ldur	x0, [sp, #0x28]
1005ce658: 140000c6    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce65c: f84283e0    	ldur	x0, [sp, #0x28]
1005ce660: 140000c4    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce664: d2804d60    	mov	x0, #0x26b              ; =619
1005ce668: f9002680    	str	x0, [x20, #0x48]
1005ce66c: d2800020    	mov	x0, #0x1                ; =1
1005ce670: f9001a60    	str	x0, [x19, #0x30]
1005ce674: f84283e1    	ldur	x1, [sp, #0x28]
1005ce678: f9002261    	str	x1, [x19, #0x40]
1005ce67c: d2800001    	mov	x1, #0x0                ; =0
1005ce680: f900c661    	str	x1, [x19, #0x188]
1005ce684: f900ca60    	str	x0, [x19, #0x190]
1005ce688: f9059277    	str	x23, [x19, #0xb20]
1005ce68c: f9059676    	str	x22, [x19, #0xb28]
1005ce690: f84303f4    	ldur	x20, [sp, #0x30]
1005ce694: 53001e81    	uxtb	w1, w20
1005ce698: f905a261    	str	x1, [x19, #0xb40]
1005ce69c: f905e679    	str	x25, [x19, #0xbc8]
1005ce6a0: f905ea78    	str	x24, [x19, #0xbd0]
1005ce6a4: f905ee77    	str	x23, [x19, #0xbd8]
1005ce6a8: 53001f61    	uxtb	w1, w27
1005ce6ac: f905fa61    	str	x1, [x19, #0xbf0]
1005ce6b0: f9060675    	str	x21, [x19, #0xc08]
1005ce6b4: f9060e6b    	str	x11, [x19, #0xc18]
1005ce6b8: f9259666    	str	x6, [x19, #0x4b28]
1005ce6bc: d2981901    	mov	x1, #0xc0c8             ; =49352
1005ce6c0: cb010061    	sub	x1, x3, x1
1005ce6c4: f9259a61    	str	x1, [x19, #0x4b30]
1005ce6c8: d1000881    	sub	x1, x4, #0x2
1005ce6cc: f9259e61    	str	x1, [x19, #0x4b38]
1005ce6d0: f9285e65    	str	x5, [x19, #0x50b8]
1005ce6d4: f9286262    	str	x2, [x19, #0x50c0]
1005ce6d8: f928666d    	str	x13, [x19, #0x50c8]
1005ce6dc: 91000542    	add	x2, x10, #0x1
1005ce6e0: f9286a62    	str	x2, [x19, #0x50d0]
1005ce6e4: f9286e68    	str	x8, [x19, #0x50d8]
1005ce6e8: f9287267    	str	x7, [x19, #0x50e0]
1005ce6ec: 140000a1    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce6f0: d2804d89    	mov	x9, #0x26c              ; =620
1005ce6f4: f9002689    	str	x9, [x20, #0x48]
1005ce6f8: d280002c    	mov	x12, #0x1               ; =1
1005ce6fc: f9001a6c    	str	x12, [x19, #0x30]
1005ce700: f84283e1    	ldur	x1, [sp, #0x28]
1005ce704: f9002261    	str	x1, [x19, #0x40]
1005ce708: d280000e    	mov	x14, #0x0               ; =0
1005ce70c: f900c66e    	str	x14, [x19, #0x188]
1005ce710: f900ca6c    	str	x12, [x19, #0x190]
1005ce714: f9059277    	str	x23, [x19, #0xb20]
1005ce718: f9059676    	str	x22, [x19, #0xb28]
1005ce71c: f84303f4    	ldur	x20, [sp, #0x30]
1005ce720: 53001e80    	uxtb	w0, w20
1005ce724: f905a260    	str	x0, [x19, #0xb40]
1005ce728: f905e679    	str	x25, [x19, #0xbc8]
1005ce72c: f905ea78    	str	x24, [x19, #0xbd0]
1005ce730: f905ee77    	str	x23, [x19, #0xbd8]
1005ce734: 53001f60    	uxtb	w0, w27
1005ce738: f905fa60    	str	x0, [x19, #0xbf0]
1005ce73c: f9060675    	str	x21, [x19, #0xc08]
1005ce740: f9060e6b    	str	x11, [x19, #0xc18]
1005ce744: f906127c    	str	x28, [x19, #0xc20]
1005ce748: f9259666    	str	x6, [x19, #0x4b28]
1005ce74c: d2981900    	mov	x0, #0xc0c8             ; =49352
1005ce750: cb000060    	sub	x0, x3, x0
1005ce754: f9259a60    	str	x0, [x19, #0x4b30]
1005ce758: d1000880    	sub	x0, x4, #0x2
1005ce75c: f9259e60    	str	x0, [x19, #0x4b38]
1005ce760: f927ba77    	str	x23, [x19, #0x4f70]
1005ce764: f927be76    	str	x22, [x19, #0x4f78]
1005ce768: f927e279    	str	x25, [x19, #0x4fc0]
1005ce76c: f927e678    	str	x24, [x19, #0x4fc8]
1005ce770: f927ea77    	str	x23, [x19, #0x4fd0]
1005ce774: f9285e65    	str	x5, [x19, #0x50b8]
1005ce778: f9286262    	str	x2, [x19, #0x50c0]
1005ce77c: f928666d    	str	x13, [x19, #0x50c8]
1005ce780: 91000540    	add	x0, x10, #0x1
1005ce784: f9286a60    	str	x0, [x19, #0x50d0]
1005ce788: f9286e68    	str	x8, [x19, #0x50d8]
1005ce78c: f9287267    	str	x7, [x19, #0x50e0]
1005ce790: f9659660    	ldr	x0, [x19, #0x4b28]
1005ce794: f100001f    	cmp	x0, #0x0
1005ce798: 54ffb301    	b.ne	0x1005cddf8 <_mech_canonical_program_entry_v1_numeric_572+0x978>
1005ce79c: 17fffdc7    	b	0x1005cdeb8 <_mech_canonical_program_entry_v1_numeric_572+0xa38>
1005ce7a0: f84283e0    	ldur	x0, [sp, #0x28]
1005ce7a4: 14000073    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce7a8: f84283e0    	ldur	x0, [sp, #0x28]
1005ce7ac: 14000071    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce7b0: d2804d81    	mov	x1, #0x26c              ; =620
1005ce7b4: f9002681    	str	x1, [x20, #0x48]
1005ce7b8: d280000e    	mov	x14, #0x0               ; =0
1005ce7bc: f925966e    	str	x14, [x19, #0x4b28]
1005ce7c0: d2800060    	mov	x0, #0x3                ; =3
1005ce7c4: f84683eb    	ldur	x11, [sp, #0x68]
1005ce7c8: f100d17f    	cmp	x11, #0x34
1005ce7cc: 54ffbc02    	b.hs	0x1005cdf4c <_mech_canonical_program_entry_v1_numeric_572+0xacc>
1005ce7d0: 14000068    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce7d4: f84283e0    	ldur	x0, [sp, #0x28]
1005ce7d8: 14000066    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce7dc: d2804de0    	mov	x0, #0x26f              ; =623
1005ce7e0: f9002680    	str	x0, [x20, #0x48]
1005ce7e4: d2800020    	mov	x0, #0x1                ; =1
1005ce7e8: f9001a60    	str	x0, [x19, #0x30]
1005ce7ec: f84283e1    	ldur	x1, [sp, #0x28]
1005ce7f0: f9002261    	str	x1, [x19, #0x40]
1005ce7f4: d2800001    	mov	x1, #0x0                ; =0
1005ce7f8: f900c661    	str	x1, [x19, #0x188]
1005ce7fc: f900ca60    	str	x0, [x19, #0x190]
1005ce800: f9059277    	str	x23, [x19, #0xb20]
1005ce804: f9059676    	str	x22, [x19, #0xb28]
1005ce808: f84303f4    	ldur	x20, [sp, #0x30]
1005ce80c: 53001e80    	uxtb	w0, w20
1005ce810: f905a260    	str	x0, [x19, #0xb40]
1005ce814: f905e679    	str	x25, [x19, #0xbc8]
1005ce818: f905ea78    	str	x24, [x19, #0xbd0]
1005ce81c: f905ee77    	str	x23, [x19, #0xbd8]
1005ce820: 53001f60    	uxtb	w0, w27
1005ce824: f905fa60    	str	x0, [x19, #0xbf0]
1005ce828: f9061a7a    	str	x26, [x19, #0xc30]
1005ce82c: f9061e7c    	str	x28, [x19, #0xc38]
1005ce830: f9259666    	str	x6, [x19, #0x4b28]
1005ce834: f9259a63    	str	x3, [x19, #0x4b30]
1005ce838: f9259e64    	str	x4, [x19, #0x4b38]
1005ce83c: f927ba77    	str	x23, [x19, #0x4f70]
1005ce840: f927be76    	str	x22, [x19, #0x4f78]
1005ce844: f927e279    	str	x25, [x19, #0x4fc0]
1005ce848: f927e678    	str	x24, [x19, #0x4fc8]
1005ce84c: f927ea77    	str	x23, [x19, #0x4fd0]
1005ce850: f9285e65    	str	x5, [x19, #0x50b8]
1005ce854: f9286262    	str	x2, [x19, #0x50c0]
1005ce858: f928666d    	str	x13, [x19, #0x50c8]
1005ce85c: f9286a6a    	str	x10, [x19, #0x50d0]
1005ce860: f9286e68    	str	x8, [x19, #0x50d8]
1005ce864: f9287267    	str	x7, [x19, #0x50e0]
1005ce868: f965966c    	ldr	x12, [x19, #0x4b28]
1005ce86c: f100019f    	cmp	x12, #0x0
1005ce870: 54ffbda1    	b.ne	0x1005ce024 <_mech_canonical_program_entry_v1_numeric_572+0xba4>
1005ce874: 17fffe1b    	b	0x1005ce0e0 <_mech_canonical_program_entry_v1_numeric_572+0xc60>
1005ce878: f84283e0    	ldur	x0, [sp, #0x28]
1005ce87c: 1400003d    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce880: f84283e0    	ldur	x0, [sp, #0x28]
1005ce884: 1400003b    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce888: d2804de1    	mov	x1, #0x26f              ; =623
1005ce88c: f9002681    	str	x1, [x20, #0x48]
1005ce890: d2800000    	mov	x0, #0x0                ; =0
1005ce894: f9259660    	str	x0, [x19, #0x4b28]
1005ce898: d2800060    	mov	x0, #0x3                ; =3
1005ce89c: f84683eb    	ldur	x11, [sp, #0x68]
1005ce8a0: f100d17f    	cmp	x11, #0x34
1005ce8a4: 54ffc5e2    	b.hs	0x1005ce160 <_mech_canonical_program_entry_v1_numeric_572+0xce0>
1005ce8a8: 14000032    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce8ac: f84283e0    	ldur	x0, [sp, #0x28]
1005ce8b0: 14000030    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce8b4: d2805209    	mov	x9, #0x290              ; =656
1005ce8b8: f9002689    	str	x9, [x20, #0x48]
1005ce8bc: d2800020    	mov	x0, #0x1                ; =1
1005ce8c0: f9001a60    	str	x0, [x19, #0x30]
1005ce8c4: d2800049    	mov	x9, #0x2                ; =2
1005ce8c8: f9002269    	str	x9, [x19, #0x40]
1005ce8cc: d2800009    	mov	x9, #0x0                ; =0
1005ce8d0: f900c669    	str	x9, [x19, #0x188]
1005ce8d4: f900ca60    	str	x0, [x19, #0x190]
1005ce8d8: f905926c    	str	x12, [x19, #0xb20]
1005ce8dc: f9059676    	str	x22, [x19, #0xb28]
1005ce8e0: f9259666    	str	x6, [x19, #0x4b28]
1005ce8e4: f9259a63    	str	x3, [x19, #0x4b30]
1005ce8e8: f9259e64    	str	x4, [x19, #0x4b38]
1005ce8ec: f9285e65    	str	x5, [x19, #0x50b8]
1005ce8f0: f9286262    	str	x2, [x19, #0x50c0]
1005ce8f4: f928666d    	str	x13, [x19, #0x50c8]
1005ce8f8: f9286a6a    	str	x10, [x19, #0x50d0]
1005ce8fc: f9286e68    	str	x8, [x19, #0x50d8]
1005ce900: f9287267    	str	x7, [x19, #0x50e0]
1005ce904: 1400001b    	b	0x1005ce970 <_mech_canonical_program_entry_v1_numeric_572+0x14f0>
1005ce908: d2804f80    	mov	x0, #0x27c              ; =636
1005ce90c: f9002680    	str	x0, [x20, #0x48]
1005ce910: d2800020    	mov	x0, #0x1                ; =1
1005ce914: f9001a60    	str	x0, [x19, #0x30]
1005ce918: f84283e9    	ldur	x9, [sp, #0x28]
1005ce91c: f9002269    	str	x9, [x19, #0x40]
1005ce920: d2800009    	mov	x9, #0x0                ; =0
1005ce924: f900c669    	str	x9, [x19, #0x188]
1005ce928: f900ca60    	str	x0, [x19, #0x190]
1005ce92c: f9059277    	str	x23, [x19, #0xb20]
1005ce930: f9059676    	str	x22, [x19, #0xb28]
1005ce934: f84303f4    	ldur	x20, [sp, #0x30]
1005ce938: 53001e89    	uxtb	w9, w20
1005ce93c: f905a269    	str	x9, [x19, #0xb40]
1005ce940: f905e661    	str	x1, [x19, #0xbc8]
1005ce944: f905ea78    	str	x24, [x19, #0xbd0]
1005ce948: f905ee77    	str	x23, [x19, #0xbd8]
1005ce94c: f9259666    	str	x6, [x19, #0x4b28]
1005ce950: f9259a63    	str	x3, [x19, #0x4b30]
1005ce954: f9259e64    	str	x4, [x19, #0x4b38]
1005ce958: f9285e65    	str	x5, [x19, #0x50b8]
1005ce95c: f9286262    	str	x2, [x19, #0x50c0]
1005ce960: f928666d    	str	x13, [x19, #0x50c8]
1005ce964: f9286a6a    	str	x10, [x19, #0x50d0]
1005ce968: f9286e68    	str	x8, [x19, #0x50d8]
1005ce96c: f9287267    	str	x7, [x19, #0x50e0]
1005ce970: d2800001    	mov	x1, #0x0                ; =0
1005ce974: 910243ff    	add	sp, sp, #0x90
1005ce978: a8c153f3    	ldp	x19, x20, [sp], #0x10
1005ce97c: a8c15bf5    	ldp	x21, x22, [sp], #0x10
1005ce980: a8c163f7    	ldp	x23, x24, [sp], #0x10
1005ce984: a8c16bf9    	ldp	x25, x26, [sp], #0x10
1005ce988: a8c173fb    	ldp	x27, x28, [sp], #0x10
1005ce98c: a8c17bfd    	ldp	x29, x30, [sp], #0x10
1005ce990: d65f0fff    	retab
		...
