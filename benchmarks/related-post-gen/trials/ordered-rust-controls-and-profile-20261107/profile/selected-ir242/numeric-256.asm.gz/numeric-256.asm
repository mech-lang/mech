
/private/tmp/mech-related-current-post-json-all-thread-profile-20261107-v1/selected-ir242/runner-profile:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001005c5b00 <_mech_canonical_program_entry_v1_numeric_256>:
1005c5b00: d503237f    	pacibsp
1005c5b04: a9bf7bfd    	stp	x29, x30, [sp, #-0x10]!
1005c5b08: 910003fd    	mov	x29, sp
1005c5b0c: a9bf73fb    	stp	x27, x28, [sp, #-0x10]!
1005c5b10: a9bf6bf9    	stp	x25, x26, [sp, #-0x10]!
1005c5b14: a9bf63f7    	stp	x23, x24, [sp, #-0x10]!
1005c5b18: a9bf5bf5    	stp	x21, x22, [sp, #-0x10]!
1005c5b1c: a9bf53f3    	stp	x19, x20, [sp, #-0x10]!
1005c5b20: d10403ff    	sub	sp, sp, #0x100
1005c5b24: f80003e2    	stur	x2, [sp]
1005c5b28: f9402817    	ldr	x23, [x0, #0x50]
1005c5b2c: f80f03f7    	stur	x23, [sp, #0xf0]
1005c5b30: f9402c06    	ldr	x6, [x0, #0x58]
1005c5b34: f9403002    	ldr	x2, [x0, #0x60]
1005c5b38: f9403408    	ldr	x8, [x0, #0x68]
1005c5b3c: aa0003f5    	mov	x21, x0
1005c5b40: f80d83e8    	stur	x8, [sp, #0xd8]
1005c5b44: d2800060    	mov	x0, #0x3                ; =3
1005c5b48: f10002ff    	cmp	x23, #0x0
1005c5b4c: 5400d660    	b.eq	0x1005c7618 <_mech_canonical_program_entry_v1_numeric_256+0x1b18>
1005c5b50: d2800060    	mov	x0, #0x3                ; =3
1005c5b54: f10000df    	cmp	x6, #0x0
1005c5b58: f80e83e6    	stur	x6, [sp, #0xe8]
1005c5b5c: 5400d620    	b.eq	0x1005c7620 <_mech_canonical_program_entry_v1_numeric_256+0x1b20>
1005c5b60: d2800060    	mov	x0, #0x3                ; =3
1005c5b64: f80703e0    	stur	x0, [sp, #0x70]
1005c5b68: f100005f    	cmp	x2, #0x0
1005c5b6c: 54016b20    	b.eq	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c5b70: f9654c26    	ldr	x6, [x1, #0x4a98]
1005c5b74: f10000df    	cmp	x6, #0x0
1005c5b78: 54001ca0    	b.eq	0x1005c5f0c <_mech_canonical_program_entry_v1_numeric_256+0x40c>
1005c5b7c: f9400840    	ldr	x0, [x2, #0x10]
1005c5b80: f942e023    	ldr	x3, [x1, #0x5c0]
1005c5b84: f942e423    	ldr	x3, [x1, #0x5c8]
1005c5b88: f942f023    	ldr	x3, [x1, #0x5e0]
1005c5b8c: f942f823    	ldr	x3, [x1, #0x5f0]
1005c5b90: f942fc23    	ldr	x3, [x1, #0x5f8]
1005c5b94: f9430023    	ldr	x3, [x1, #0x600]
1005c5b98: f9430423    	ldr	x3, [x1, #0x608]
1005c5b9c: f9430c23    	ldr	x3, [x1, #0x618]
1005c5ba0: f9431023    	ldr	x3, [x1, #0x620]
1005c5ba4: f9432c23    	ldr	x3, [x1, #0x658]
1005c5ba8: f9433023    	ldr	x3, [x1, #0x660]
1005c5bac: f9433823    	ldr	x3, [x1, #0x670]
1005c5bb0: f9433c23    	ldr	x3, [x1, #0x678]
1005c5bb4: f9434423    	ldr	x3, [x1, #0x688]
1005c5bb8: f9434c23    	ldr	x3, [x1, #0x698]
1005c5bbc: f9435023    	ldr	x3, [x1, #0x6a0]
1005c5bc0: f9435423    	ldr	x3, [x1, #0x6a8]
1005c5bc4: f9437023    	ldr	x3, [x1, #0x6e0]
1005c5bc8: f9437423    	ldr	x3, [x1, #0x6e8]
1005c5bcc: f9437823    	ldr	x3, [x1, #0x6f0]
1005c5bd0: f9438023    	ldr	x3, [x1, #0x700]
1005c5bd4: f9438423    	ldr	x3, [x1, #0x708]
1005c5bd8: f9438c23    	ldr	x3, [x1, #0x718]
1005c5bdc: f9439423    	ldr	x3, [x1, #0x728]
1005c5be0: f9439823    	ldr	x3, [x1, #0x730]
1005c5be4: f9439c23    	ldr	x3, [x1, #0x738]
1005c5be8: f943a023    	ldr	x3, [x1, #0x740]
1005c5bec: f943bc23    	ldr	x3, [x1, #0x778]
1005c5bf0: f943c023    	ldr	x3, [x1, #0x780]
1005c5bf4: f943c423    	ldr	x3, [x1, #0x788]
1005c5bf8: f943c823    	ldr	x3, [x1, #0x790]
1005c5bfc: f943d023    	ldr	x3, [x1, #0x7a0]
1005c5c00: f943d823    	ldr	x3, [x1, #0x7b0]
1005c5c04: f943dc23    	ldr	x3, [x1, #0x7b8]
1005c5c08: f943e023    	ldr	x3, [x1, #0x7c0]
1005c5c0c: f943e423    	ldr	x3, [x1, #0x7c8]
1005c5c10: f943e823    	ldr	x3, [x1, #0x7d0]
1005c5c14: f943ec23    	ldr	x3, [x1, #0x7d8]
1005c5c18: f943f023    	ldr	x3, [x1, #0x7e0]
1005c5c1c: f943f423    	ldr	x3, [x1, #0x7e8]
1005c5c20: f943f823    	ldr	x3, [x1, #0x7f0]
1005c5c24: f943fc23    	ldr	x3, [x1, #0x7f8]
1005c5c28: f9440023    	ldr	x3, [x1, #0x800]
1005c5c2c: f9440423    	ldr	x3, [x1, #0x808]
1005c5c30: f9440823    	ldr	x3, [x1, #0x810]
1005c5c34: f9440c23    	ldr	x3, [x1, #0x818]
1005c5c38: f9441023    	ldr	x3, [x1, #0x820]
1005c5c3c: f9441423    	ldr	x3, [x1, #0x828]
1005c5c40: f9442023    	ldr	x3, [x1, #0x840]
1005c5c44: f9442c23    	ldr	x3, [x1, #0x858]
1005c5c48: f9443823    	ldr	x3, [x1, #0x870]
1005c5c4c: f9444423    	ldr	x3, [x1, #0x888]
1005c5c50: f9445023    	ldr	x3, [x1, #0x8a0]
1005c5c54: f9655023    	ldr	x3, [x1, #0x4aa0]
1005c5c58: f9655424    	ldr	x4, [x1, #0x4aa8]
1005c5c5c: aa0103ee    	mov	x14, x1
1005c5c60: f940d81a    	ldr	x26, [x0, #0x1b0]
1005c5c64: f940e019    	ldr	x25, [x0, #0x1c0]
1005c5c68: f940d441    	ldr	x1, [x2, #0x1a8]
1005c5c6c: f80683e1    	stur	x1, [sp, #0x68]
1005c5c70: f940d854    	ldr	x20, [x2, #0x1b0]
1005c5c74: f80503f4    	stur	x20, [sp, #0x50]
1005c5c78: f940dc41    	ldr	x1, [x2, #0x1b8]
1005c5c7c: f940e041    	ldr	x1, [x2, #0x1c0]
1005c5c80: f940e44f    	ldr	x15, [x2, #0x1c8]
1005c5c84: f80483ef    	stur	x15, [sp, #0x48]
1005c5c88: f940e841    	ldr	x1, [x2, #0x1d0]
1005c5c8c: f80083e1    	stur	x1, [sp, #0x8]
1005c5c90: f940ec41    	ldr	x1, [x2, #0x1d8]
1005c5c94: f940f041    	ldr	x1, [x2, #0x1e0]
1005c5c98: f940f441    	ldr	x1, [x2, #0x1e8]
1005c5c9c: f80d03e1    	stur	x1, [sp, #0xd0]
1005c5ca0: f940f841    	ldr	x1, [x2, #0x1f0]
1005c5ca4: f80c83e1    	stur	x1, [sp, #0xc8]
1005c5ca8: f940fc41    	ldr	x1, [x2, #0x1f8]
1005c5cac: f80c03e1    	stur	x1, [sp, #0xc0]
1005c5cb0: f9410041    	ldr	x1, [x2, #0x200]
1005c5cb4: f80b83e1    	stur	x1, [sp, #0xb8]
1005c5cb8: f9410441    	ldr	x1, [x2, #0x208]
1005c5cbc: f80b03e1    	stur	x1, [sp, #0xb0]
1005c5cc0: f9410841    	ldr	x1, [x2, #0x210]
1005c5cc4: f80a83e1    	stur	x1, [sp, #0xa8]
1005c5cc8: f9410c41    	ldr	x1, [x2, #0x218]
1005c5ccc: f9411041    	ldr	x1, [x2, #0x220]
1005c5cd0: f9412445    	ldr	x5, [x2, #0x248]
1005c5cd4: f80583e5    	stur	x5, [sp, #0x58]
1005c5cd8: f9412841    	ldr	x1, [x2, #0x250]
1005c5cdc: f80383e1    	stur	x1, [sp, #0x38]
1005c5ce0: f80e03e2    	stur	x2, [sp, #0xe0]
1005c5ce4: d280000c    	mov	x12, #0x0               ; =0
1005c5ce8: d2800021    	mov	x1, #0x1                ; =1
1005c5cec: aa0103f8    	mov	x24, x1
1005c5cf0: aa0c03e7    	mov	x7, x12
1005c5cf4: aa0c03e8    	mov	x8, x12
1005c5cf8: aa0c03e9    	mov	x9, x12
1005c5cfc: aa0c03ea    	mov	x10, x12
1005c5d00: aa0c03eb    	mov	x11, x12
1005c5d04: aa0c03ed    	mov	x13, x12
1005c5d08: aa0c03f6    	mov	x22, x12
1005c5d0c: f80103e3    	stur	x3, [sp, #0x10]
1005c5d10: f80403ec    	stur	x12, [sp, #0x40]
1005c5d14: f80603ec    	stur	x12, [sp, #0x60]
1005c5d18: d29d1501    	mov	x1, #0xe8a8             ; =59560
1005c5d1c: eb01007f    	cmp	x3, x1
1005c5d20: 9a9f37e1    	cset	x1, hs
1005c5d24: f84583e2    	ldur	x2, [sp, #0x58]
1005c5d28: f84503f4    	ldur	x20, [sp, #0x50]
1005c5d2c: eb02029f    	cmp	x20, x2
1005c5d30: 9a9f87e2    	cset	x2, ls
1005c5d34: f84583e5    	ldur	x5, [sp, #0x58]
1005c5d38: cb1400a5    	sub	x5, x5, x20
1005c5d3c: f10000bf    	cmp	x5, #0x0
1005c5d40: 9a9f07e5    	cset	x5, ne
1005c5d44: 0a050042    	and	w2, w2, w5
1005c5d48: aa0203e5    	mov	x5, x2
1005c5d4c: 0a050021    	and	w1, w1, w5
1005c5d50: f80a03e5    	stur	x5, [sp, #0xa0]
1005c5d54: 53001c21    	uxtb	w1, w1
1005c5d58: b5000ee1    	cbnz	x1, 0x1005c5f34 <_mech_canonical_program_entry_v1_numeric_256+0x434>
1005c5d5c: d2800020    	mov	x0, #0x1                ; =1
1005c5d60: aa0e03f3    	mov	x19, x14
1005c5d64: f9001a60    	str	x0, [x19, #0x30]
1005c5d68: d2800041    	mov	x1, #0x2                ; =2
1005c5d6c: f9002261    	str	x1, [x19, #0x40]
1005c5d70: d28000c1    	mov	x1, #0x6                ; =6
1005c5d74: f9003261    	str	x1, [x19, #0x60]
1005c5d78: d2800001    	mov	x1, #0x0                ; =0
1005c5d7c: f900c661    	str	x1, [x19, #0x188]
1005c5d80: f900ca60    	str	x0, [x19, #0x190]
1005c5d84: f9254e66    	str	x6, [x19, #0x4a98]
1005c5d88: f9255263    	str	x3, [x19, #0x4aa0]
1005c5d8c: f9255664    	str	x4, [x19, #0x4aa8]
1005c5d90: f927ba7a    	str	x26, [x19, #0x4f70]
1005c5d94: f927be79    	str	x25, [x19, #0x4f78]
1005c5d98: f84503f4    	ldur	x20, [sp, #0x50]
1005c5d9c: f9288a74    	str	x20, [x19, #0x5110]
1005c5da0: f84083f7    	ldur	x23, [sp, #0x8]
1005c5da4: f9289a77    	str	x23, [x19, #0x5130]
1005c5da8: f928de6c    	str	x12, [x19, #0x51b8]
1005c5dac: aa1803e2    	mov	x2, x24
1005c5db0: f928e262    	str	x2, [x19, #0x51c0]
1005c5db4: f928e66a    	str	x10, [x19, #0x51c8]
1005c5db8: f84103ea    	ldur	x10, [sp, #0x10]
1005c5dbc: cb030140    	sub	x0, x10, x3
1005c5dc0: d29d1501    	mov	x1, #0xe8a8             ; =59560
1005c5dc4: 9b018180    	msub	x0, x12, x1, x0
1005c5dc8: f928ea60    	str	x0, [x19, #0x51d0]
1005c5dcc: f928ee6b    	str	x11, [x19, #0x51d8]
1005c5dd0: f928f268    	str	x8, [x19, #0x51e0]
1005c5dd4: f928fa6d    	str	x13, [x19, #0x51f0]
1005c5dd8: f928fe76    	str	x22, [x19, #0x51f8]
1005c5ddc: f9290669    	str	x9, [x19, #0x5208]
1005c5de0: f9290a67    	str	x7, [x19, #0x5210]
1005c5de4: f9654e60    	ldr	x0, [x19, #0x4a98]
1005c5de8: f100001f    	cmp	x0, #0x0
1005c5dec: 54000900    	b.eq	0x1005c5f0c <_mech_canonical_program_entry_v1_numeric_256+0x40c>
1005c5df0: f9655263    	ldr	x3, [x19, #0x4aa0]
1005c5df4: f9655664    	ldr	x4, [x19, #0x4aa8]
1005c5df8: d2800001    	mov	x1, #0x0                ; =0
1005c5dfc: f9254e61    	str	x1, [x19, #0x4a98]
1005c5e00: d2800060    	mov	x0, #0x3                ; =3
1005c5e04: f84d83e1    	ldur	x1, [sp, #0xd8]
1005c5e08: f101603f    	cmp	x1, #0x58
1005c5e0c: 5400c0e3    	b.lo	0x1005c7628 <_mech_canonical_program_entry_v1_numeric_256+0x1b28>
1005c5e10: f967ba65    	ldr	x5, [x19, #0x4f70]
1005c5e14: f84e03ee    	ldur	x14, [sp, #0xe0]
1005c5e18: f90009c5    	str	x5, [x14, #0x10]
1005c5e1c: f967be66    	ldr	x6, [x19, #0x4f78]
1005c5e20: f9000dc6    	str	x6, [x14, #0x18]
1005c5e24: f9688a67    	ldr	x7, [x19, #0x5110]
1005c5e28: f900d9c7    	str	x7, [x14, #0x1b0]
1005c5e2c: f9689a68    	ldr	x8, [x19, #0x5130]
1005c5e30: f900e9c8    	str	x8, [x14, #0x1d0]
1005c5e34: f90009c5    	str	x5, [x14, #0x10]
1005c5e38: f9000dc6    	str	x6, [x14, #0x18]
1005c5e3c: f967da6b    	ldr	x11, [x19, #0x4fb0]
1005c5e40: f90029cb    	str	x11, [x14, #0x50]
1005c5e44: f967de6c    	ldr	x12, [x19, #0x4fb8]
1005c5e48: f9002dcc    	str	x12, [x14, #0x58]
1005c5e4c: f968026d    	ldr	x13, [x19, #0x5000]
1005c5e50: f90051cd    	str	x13, [x14, #0xa0]
1005c5e54: f968066f    	ldr	x15, [x19, #0x5008]
1005c5e58: f90055cf    	str	x15, [x14, #0xa8]
1005c5e5c: f9680a6f    	ldr	x15, [x19, #0x5010]
1005c5e60: f90059cf    	str	x15, [x14, #0xb0]
1005c5e64: f9683a60    	ldr	x0, [x19, #0x5070]
1005c5e68: f90089c0    	str	x0, [x14, #0x110]
1005c5e6c: f9683e60    	ldr	x0, [x19, #0x5078]
1005c5e70: f9008dc0    	str	x0, [x14, #0x118]
1005c5e74: f9684260    	ldr	x0, [x19, #0x5080]
1005c5e78: f90091c0    	str	x0, [x14, #0x120]
1005c5e7c: f9684660    	ldr	x0, [x19, #0x5088]
1005c5e80: f90095c0    	str	x0, [x14, #0x128]
1005c5e84: f968de60    	ldr	x0, [x19, #0x51b8]
1005c5e88: f9012dc0    	str	x0, [x14, #0x258]
1005c5e8c: f968e260    	ldr	x0, [x19, #0x51c0]
1005c5e90: f90131c0    	str	x0, [x14, #0x260]
1005c5e94: f968e660    	ldr	x0, [x19, #0x51c8]
1005c5e98: f90135c0    	str	x0, [x14, #0x268]
1005c5e9c: f968ea60    	ldr	x0, [x19, #0x51d0]
1005c5ea0: f90139c0    	str	x0, [x14, #0x270]
1005c5ea4: f968ee60    	ldr	x0, [x19, #0x51d8]
1005c5ea8: f9013dc0    	str	x0, [x14, #0x278]
1005c5eac: f968f260    	ldr	x0, [x19, #0x51e0]
1005c5eb0: f90141c0    	str	x0, [x14, #0x280]
1005c5eb4: d2800000    	mov	x0, #0x0                ; =0
1005c5eb8: f90145c0    	str	x0, [x14, #0x288]
1005c5ebc: f968fa61    	ldr	x1, [x19, #0x51f0]
1005c5ec0: f90149c1    	str	x1, [x14, #0x290]
1005c5ec4: f968fe61    	ldr	x1, [x19, #0x51f8]
1005c5ec8: f9014dc1    	str	x1, [x14, #0x298]
1005c5ecc: f90151c0    	str	x0, [x14, #0x2a0]
1005c5ed0: f9690660    	ldr	x0, [x19, #0x5208]
1005c5ed4: f90155c0    	str	x0, [x14, #0x2a8]
1005c5ed8: f9690a60    	ldr	x0, [x19, #0x5210]
1005c5edc: f90159c0    	str	x0, [x14, #0x2b0]
1005c5ee0: d2802001    	mov	x1, #0x100              ; =256
1005c5ee4: 92800102    	mov	x2, #-0x9               ; =-9
1005c5ee8: d2800025    	mov	x5, #0x1                ; =1
1005c5eec: f84003e0    	ldur	x0, [sp]
1005c5ef0: f84e83e6    	ldur	x6, [sp, #0xe8]
1005c5ef4: f84f03e7    	ldur	x7, [sp, #0xf0]
1005c5ef8: d63f00e0    	blr	x7
1005c5efc: aa0003e2    	mov	x2, x0
1005c5f00: d2800040    	mov	x0, #0x2                ; =2
1005c5f04: f100005f    	cmp	x2, #0x0
1005c5f08: 5400b941    	b.ne	0x1005c7630 <_mech_canonical_program_entry_v1_numeric_256+0x1b30>
1005c5f0c: d2800001    	mov	x1, #0x0                ; =0
1005c5f10: aa0103e0    	mov	x0, x1
1005c5f14: 910403ff    	add	sp, sp, #0x100
1005c5f18: a8c153f3    	ldp	x19, x20, [sp], #0x10
1005c5f1c: a8c15bf5    	ldp	x21, x22, [sp], #0x10
1005c5f20: a8c163f7    	ldp	x23, x24, [sp], #0x10
1005c5f24: a8c16bf9    	ldp	x25, x26, [sp], #0x10
1005c5f28: a8c173fb    	ldp	x27, x28, [sp], #0x10
1005c5f2c: a8c17bfd    	ldp	x29, x30, [sp], #0x10
1005c5f30: d65f0fff    	retab
1005c5f34: aa0e03f3    	mov	x19, x14
1005c5f38: f84e03ee    	ldur	x14, [sp, #0xe0]
1005c5f3c: f84d83e1    	ldur	x1, [sp, #0xd8]
1005c5f40: eb19035f    	cmp	x26, x25
1005c5f44: 9a9f27e2    	cset	x2, lo
1005c5f48: f80983e2    	stur	x2, [sp, #0x98]
1005c5f4c: eb19035f    	cmp	x26, x25
1005c5f50: 54000183    	b.lo	0x1005c5f80 <_mech_canonical_program_entry_v1_numeric_256+0x480>
1005c5f54: 9100058c    	add	x12, x12, #0x1
1005c5f58: d29d1502    	mov	x2, #0xe8a8             ; =59560
1005c5f5c: cb020063    	sub	x3, x3, x2
1005c5f60: f80e03ee    	stur	x14, [sp, #0xe0]
1005c5f64: f80d83e1    	stur	x1, [sp, #0xd8]
1005c5f68: aa1a03fb    	mov	x27, x26
1005c5f6c: aa1503f4    	mov	x20, x21
1005c5f70: aa1a03f5    	mov	x21, x26
1005c5f74: aa1803e2    	mov	x2, x24
1005c5f78: aa0a03e1    	mov	x1, x10
1005c5f7c: 140004ee    	b	0x1005c7334 <_mech_canonical_program_entry_v1_numeric_256+0x1834>
1005c5f80: f84c83e2    	ldur	x2, [sp, #0xc8]
1005c5f84: eb02035f    	cmp	x26, x2
1005c5f88: 54000be3    	b.lo	0x1005c6104 <_mech_canonical_program_entry_v1_numeric_256+0x604>
1005c5f8c: 140005ab    	b	0x1005c7638 <_mech_canonical_program_entry_v1_numeric_256+0x1b38>
1005c5f90: f80d83e1    	stur	x1, [sp, #0xd8]
1005c5f94: f80e03ee    	stur	x14, [sp, #0xe0]
1005c5f98: 14000046    	b	0x1005c60b0 <_mech_canonical_program_entry_v1_numeric_256+0x5b0>
1005c5f9c: f9655263    	ldr	x3, [x19, #0x4aa0]
1005c5fa0: f9655664    	ldr	x4, [x19, #0x4aa8]
1005c5fa4: d2800000    	mov	x0, #0x0                ; =0
1005c5fa8: f9254e60    	str	x0, [x19, #0x4a98]
1005c5fac: d2800060    	mov	x0, #0x3                ; =3
1005c5fb0: f101603f    	cmp	x1, #0x58
1005c5fb4: f80d83e1    	stur	x1, [sp, #0xd8]
1005c5fb8: 5400ba23    	b.lo	0x1005c76fc <_mech_canonical_program_entry_v1_numeric_256+0x1bfc>
1005c5fbc: f967ba60    	ldr	x0, [x19, #0x4f70]
1005c5fc0: f90009c0    	str	x0, [x14, #0x10]
1005c5fc4: f967be61    	ldr	x1, [x19, #0x4f78]
1005c5fc8: f9000dc1    	str	x1, [x14, #0x18]
1005c5fcc: f9688a62    	ldr	x2, [x19, #0x5110]
1005c5fd0: f900d9c2    	str	x2, [x14, #0x1b0]
1005c5fd4: f9689a62    	ldr	x2, [x19, #0x5130]
1005c5fd8: f900e9c2    	str	x2, [x14, #0x1d0]
1005c5fdc: f90009c0    	str	x0, [x14, #0x10]
1005c5fe0: f9000dc1    	str	x1, [x14, #0x18]
1005c5fe4: f967da60    	ldr	x0, [x19, #0x4fb0]
1005c5fe8: f90029c0    	str	x0, [x14, #0x50]
1005c5fec: f967de60    	ldr	x0, [x19, #0x4fb8]
1005c5ff0: f9002dc0    	str	x0, [x14, #0x58]
1005c5ff4: f9680260    	ldr	x0, [x19, #0x5000]
1005c5ff8: f90051c0    	str	x0, [x14, #0xa0]
1005c5ffc: f9680660    	ldr	x0, [x19, #0x5008]
1005c6000: f90055c0    	str	x0, [x14, #0xa8]
1005c6004: f9680a60    	ldr	x0, [x19, #0x5010]
1005c6008: f90059c0    	str	x0, [x14, #0xb0]
1005c600c: f9683a60    	ldr	x0, [x19, #0x5070]
1005c6010: f90089c0    	str	x0, [x14, #0x110]
1005c6014: f9683e60    	ldr	x0, [x19, #0x5078]
1005c6018: f9008dc0    	str	x0, [x14, #0x118]
1005c601c: f9684260    	ldr	x0, [x19, #0x5080]
1005c6020: f90091c0    	str	x0, [x14, #0x120]
1005c6024: f9684660    	ldr	x0, [x19, #0x5088]
1005c6028: f90095c0    	str	x0, [x14, #0x128]
1005c602c: f968de60    	ldr	x0, [x19, #0x51b8]
1005c6030: f9012dc0    	str	x0, [x14, #0x258]
1005c6034: f968e260    	ldr	x0, [x19, #0x51c0]
1005c6038: f90131c0    	str	x0, [x14, #0x260]
1005c603c: f968e660    	ldr	x0, [x19, #0x51c8]
1005c6040: f90135c0    	str	x0, [x14, #0x268]
1005c6044: f968ea60    	ldr	x0, [x19, #0x51d0]
1005c6048: f90139c0    	str	x0, [x14, #0x270]
1005c604c: f968ee60    	ldr	x0, [x19, #0x51d8]
1005c6050: f9013dc0    	str	x0, [x14, #0x278]
1005c6054: f968f260    	ldr	x0, [x19, #0x51e0]
1005c6058: f90141c0    	str	x0, [x14, #0x280]
1005c605c: d2800000    	mov	x0, #0x0                ; =0
1005c6060: f90145c0    	str	x0, [x14, #0x288]
1005c6064: f968fa61    	ldr	x1, [x19, #0x51f0]
1005c6068: f90149c1    	str	x1, [x14, #0x290]
1005c606c: f968fe61    	ldr	x1, [x19, #0x51f8]
1005c6070: f9014dc1    	str	x1, [x14, #0x298]
1005c6074: f90151c0    	str	x0, [x14, #0x2a0]
1005c6078: f9690660    	ldr	x0, [x19, #0x5208]
1005c607c: f90155c0    	str	x0, [x14, #0x2a8]
1005c6080: f9690a60    	ldr	x0, [x19, #0x5210]
1005c6084: f90159c0    	str	x0, [x14, #0x2b0]
1005c6088: f80e03ee    	stur	x14, [sp, #0xe0]
1005c608c: d2802201    	mov	x1, #0x110              ; =272
1005c6090: 92800102    	mov	x2, #-0x9               ; =-9
1005c6094: f84f03e7    	ldur	x7, [sp, #0xf0]
1005c6098: f84003e0    	ldur	x0, [sp]
1005c609c: aa1403e5    	mov	x5, x20
1005c60a0: f84e83e6    	ldur	x6, [sp, #0xe8]
1005c60a4: d63f00e0    	blr	x7
1005c60a8: f100001f    	cmp	x0, #0x0
1005c60ac: 5400b2c1    	b.ne	0x1005c7704 <_mech_canonical_program_entry_v1_numeric_256+0x1c04>
1005c60b0: d2800060    	mov	x0, #0x3                ; =3
1005c60b4: f84d83e8    	ldur	x8, [sp, #0xd8]
1005c60b8: f100091f    	cmp	x8, #0x2
1005c60bc: 5400b283    	b.lo	0x1005c770c <_mech_canonical_program_entry_v1_numeric_256+0x1c0c>
1005c60c0: d2800005    	mov	x5, #0x0                ; =0
1005c60c4: f84e03e3    	ldur	x3, [sp, #0xe0]
1005c60c8: f9000065    	str	x5, [x3]
1005c60cc: f942fa60    	ldr	x0, [x19, #0x5f0]
1005c60d0: f9000460    	str	x0, [x3, #0x8]
1005c60d4: d2802201    	mov	x1, #0x110              ; =272
1005c60d8: f84003e0    	ldur	x0, [sp]
1005c60dc: f84e83e6    	ldur	x6, [sp, #0xe8]
1005c60e0: f84f03e7    	ldur	x7, [sp, #0xf0]
1005c60e4: aa1403e4    	mov	x4, x20
1005c60e8: aa0503e2    	mov	x2, x5
1005c60ec: d63f00e0    	blr	x7
1005c60f0: f100001f    	cmp	x0, #0x0
1005c60f4: 5400b101    	b.ne	0x1005c7714 <_mech_canonical_program_entry_v1_numeric_256+0x1c14>
1005c60f8: d2800060    	mov	x0, #0x3                ; =3
1005c60fc: f80703e0    	stur	x0, [sp, #0x70]
1005c6100: 140009f4    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c6104: f80e03ee    	stur	x14, [sp, #0xe0]
1005c6108: f80d83e1    	stur	x1, [sp, #0xd8]
1005c610c: aa1503f4    	mov	x20, x21
1005c6110: aa0a03f5    	mov	x21, x10
1005c6114: aa1803e2    	mov	x2, x24
1005c6118: f84c03e1    	ldur	x1, [sp, #0xc0]
1005c611c: f100043f    	cmp	x1, #0x1
1005c6120: 9a9f17ea    	cset	x10, eq
1005c6124: f84b83e1    	ldur	x1, [sp, #0xb8]
1005c6128: f100043f    	cmp	x1, #0x1
1005c612c: 9a9f17ee    	cset	x14, eq
1005c6130: 2a0e014a    	orr	w10, w10, w14
1005c6134: 53001d4e    	uxtb	w14, w10
1005c6138: b400008e    	cbz	x14, 0x1005c6148 <_mech_canonical_program_entry_v1_numeric_256+0x648>
1005c613c: aa1a03e1    	mov	x1, x26
1005c6140: f84d03e5    	ldur	x5, [sp, #0xd0]
1005c6144: 14000008    	b	0x1005c6164 <_mech_canonical_program_entry_v1_numeric_256+0x664>
1005c6148: f84c03e1    	ldur	x1, [sp, #0xc0]
1005c614c: b4013d61    	cbz	x1, 0x1005c88f8 <_mech_canonical_program_entry_v1_numeric_256+0x2df8>
1005c6150: 9ac10b4e    	udiv	x14, x26, x1
1005c6154: 9b01e9cf    	msub	x15, x14, x1, x26
1005c6158: f84b83e1    	ldur	x1, [sp, #0xb8]
1005c615c: 9b0139e1    	madd	x1, x15, x1, x14
1005c6160: f84d03e5    	ldur	x5, [sp, #0xd0]
1005c6164: f86178bc    	ldr	x28, [x5, x1, lsl #3]
1005c6168: f80d03e5    	stur	x5, [sp, #0xd0]
1005c616c: 91000745    	add	x5, x26, #0x1
1005c6170: f84c83e1    	ldur	x1, [sp, #0xc8]
1005c6174: eb0100bf    	cmp	x5, x1
1005c6178: 54000cc3    	b.lo	0x1005c6310 <_mech_canonical_program_entry_v1_numeric_256+0x810>
1005c617c: 14000568    	b	0x1005c771c <_mech_canonical_program_entry_v1_numeric_256+0x1c1c>
1005c6180: f9655263    	ldr	x3, [x19, #0x4aa0]
1005c6184: f9655664    	ldr	x4, [x19, #0x4aa8]
1005c6188: d2800000    	mov	x0, #0x0                ; =0
1005c618c: f9254e60    	str	x0, [x19, #0x4a98]
1005c6190: d2800060    	mov	x0, #0x3                ; =3
1005c6194: f84d83e8    	ldur	x8, [sp, #0xd8]
1005c6198: f101611f    	cmp	x8, #0x58
1005c619c: 5400b223    	b.lo	0x1005c77e0 <_mech_canonical_program_entry_v1_numeric_256+0x1ce0>
1005c61a0: f967ba60    	ldr	x0, [x19, #0x4f70]
1005c61a4: f84e03e1    	ldur	x1, [sp, #0xe0]
1005c61a8: f9000820    	str	x0, [x1, #0x10]
1005c61ac: f967be61    	ldr	x1, [x19, #0x4f78]
1005c61b0: f84e03e2    	ldur	x2, [sp, #0xe0]
1005c61b4: f9000c41    	str	x1, [x2, #0x18]
1005c61b8: f9688a62    	ldr	x2, [x19, #0x5110]
1005c61bc: f84e03e5    	ldur	x5, [sp, #0xe0]
1005c61c0: f900d8a2    	str	x2, [x5, #0x1b0]
1005c61c4: f9689a62    	ldr	x2, [x19, #0x5130]
1005c61c8: f900e8a2    	str	x2, [x5, #0x1d0]
1005c61cc: f84e03e2    	ldur	x2, [sp, #0xe0]
1005c61d0: f9000840    	str	x0, [x2, #0x10]
1005c61d4: f84e03e0    	ldur	x0, [sp, #0xe0]
1005c61d8: f9000c01    	str	x1, [x0, #0x18]
1005c61dc: f967da60    	ldr	x0, [x19, #0x4fb0]
1005c61e0: f84e03e1    	ldur	x1, [sp, #0xe0]
1005c61e4: f9002820    	str	x0, [x1, #0x50]
1005c61e8: f967de60    	ldr	x0, [x19, #0x4fb8]
1005c61ec: f9002ca0    	str	x0, [x5, #0x58]
1005c61f0: f9680260    	ldr	x0, [x19, #0x5000]
1005c61f4: f84e03e6    	ldur	x6, [sp, #0xe0]
1005c61f8: f90050c0    	str	x0, [x6, #0xa0]
1005c61fc: f9680660    	ldr	x0, [x19, #0x5008]
1005c6200: f84e03e9    	ldur	x9, [sp, #0xe0]
1005c6204: f9005520    	str	x0, [x9, #0xa8]
1005c6208: f9680a60    	ldr	x0, [x19, #0x5010]
1005c620c: f84e03ec    	ldur	x12, [sp, #0xe0]
1005c6210: f9005980    	str	x0, [x12, #0xb0]
1005c6214: f9683a60    	ldr	x0, [x19, #0x5070]
1005c6218: f84e03ef    	ldur	x15, [sp, #0xe0]
1005c621c: f90089e0    	str	x0, [x15, #0x110]
1005c6220: f9683e60    	ldr	x0, [x19, #0x5078]
1005c6224: f9008c20    	str	x0, [x1, #0x118]
1005c6228: f9684261    	ldr	x1, [x19, #0x5080]
1005c622c: f84e03e0    	ldur	x0, [sp, #0xe0]
1005c6230: f9009001    	str	x1, [x0, #0x120]
1005c6234: f9684662    	ldr	x2, [x19, #0x5088]
1005c6238: f9009402    	str	x2, [x0, #0x128]
1005c623c: f968de65    	ldr	x5, [x19, #0x51b8]
1005c6240: f9012c05    	str	x5, [x0, #0x258]
1005c6244: f968e265    	ldr	x5, [x19, #0x51c0]
1005c6248: f9013005    	str	x5, [x0, #0x260]
1005c624c: f968e665    	ldr	x5, [x19, #0x51c8]
1005c6250: f9013405    	str	x5, [x0, #0x268]
1005c6254: f968ea66    	ldr	x6, [x19, #0x51d0]
1005c6258: f9013806    	str	x6, [x0, #0x270]
1005c625c: f968ee67    	ldr	x7, [x19, #0x51d8]
1005c6260: f9013c07    	str	x7, [x0, #0x278]
1005c6264: f968f268    	ldr	x8, [x19, #0x51e0]
1005c6268: f9014008    	str	x8, [x0, #0x280]
1005c626c: d2800009    	mov	x9, #0x0                ; =0
1005c6270: f9014409    	str	x9, [x0, #0x288]
1005c6274: f968fa6a    	ldr	x10, [x19, #0x51f0]
1005c6278: f901480a    	str	x10, [x0, #0x290]
1005c627c: f968fe6b    	ldr	x11, [x19, #0x51f8]
1005c6280: f9014c0b    	str	x11, [x0, #0x298]
1005c6284: f9015009    	str	x9, [x0, #0x2a0]
1005c6288: f969066d    	ldr	x13, [x19, #0x5208]
1005c628c: f901540d    	str	x13, [x0, #0x2a8]
1005c6290: f9690a6e    	ldr	x14, [x19, #0x5210]
1005c6294: f901580e    	str	x14, [x0, #0x2b0]
1005c6298: d2802241    	mov	x1, #0x112              ; =274
1005c629c: 92800102    	mov	x2, #-0x9               ; =-9
1005c62a0: f84f03e7    	ldur	x7, [sp, #0xf0]
1005c62a4: f84003e0    	ldur	x0, [sp]
1005c62a8: aa1403e5    	mov	x5, x20
1005c62ac: f84e83e6    	ldur	x6, [sp, #0xe8]
1005c62b0: d63f00e0    	blr	x7
1005c62b4: f100001f    	cmp	x0, #0x0
1005c62b8: 5400a981    	b.ne	0x1005c77e8 <_mech_canonical_program_entry_v1_numeric_256+0x1ce8>
1005c62bc: d2800060    	mov	x0, #0x3                ; =3
1005c62c0: f84d83e8    	ldur	x8, [sp, #0xd8]
1005c62c4: f100091f    	cmp	x8, #0x2
1005c62c8: 5400a943    	b.lo	0x1005c77f0 <_mech_canonical_program_entry_v1_numeric_256+0x1cf0>
1005c62cc: d2800005    	mov	x5, #0x0                ; =0
1005c62d0: f84e03e3    	ldur	x3, [sp, #0xe0]
1005c62d4: f9000065    	str	x5, [x3]
1005c62d8: f9430260    	ldr	x0, [x19, #0x600]
1005c62dc: f9000460    	str	x0, [x3, #0x8]
1005c62e0: d2802241    	mov	x1, #0x112              ; =274
1005c62e4: f84003e0    	ldur	x0, [sp]
1005c62e8: f84e83e6    	ldur	x6, [sp, #0xe8]
1005c62ec: f84f03e7    	ldur	x7, [sp, #0xf0]
1005c62f0: aa1403e4    	mov	x4, x20
1005c62f4: aa0503e2    	mov	x2, x5
1005c62f8: d63f00e0    	blr	x7
1005c62fc: f100001f    	cmp	x0, #0x0
1005c6300: 5400a7c1    	b.ne	0x1005c77f8 <_mech_canonical_program_entry_v1_numeric_256+0x1cf8>
1005c6304: d2800060    	mov	x0, #0x3                ; =3
1005c6308: f80703e0    	stur	x0, [sp, #0x70]
1005c630c: 14000971    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c6310: aa1503e1    	mov	x1, x21
1005c6314: 53001d48    	uxtb	w8, w10
1005c6318: b4000068    	cbz	x8, 0x1005c6324 <_mech_canonical_program_entry_v1_numeric_256+0x824>
1005c631c: f84d03e8    	ldur	x8, [sp, #0xd0]
1005c6320: 1400000a    	b	0x1005c6348 <_mech_canonical_program_entry_v1_numeric_256+0x848>
1005c6324: f84c03ee    	ldur	x14, [sp, #0xc0]
1005c6328: b4012eae    	cbz	x14, 0x1005c88fc <_mech_canonical_program_entry_v1_numeric_256+0x2dfc>
1005c632c: f84c03e8    	ldur	x8, [sp, #0xc0]
1005c6330: 9ac808a8    	udiv	x8, x5, x8
1005c6334: f84c03ea    	ldur	x10, [sp, #0xc0]
1005c6338: 9b0a9505    	msub	x5, x8, x10, x5
1005c633c: f84b83ea    	ldur	x10, [sp, #0xb8]
1005c6340: 9b0a20a5    	madd	x5, x5, x10, x8
1005c6344: f84d03e8    	ldur	x8, [sp, #0xd0]
1005c6348: f865791b    	ldr	x27, [x8, x5, lsl #3]
1005c634c: d29d1505    	mov	x5, #0xe8a8             ; =59560
1005c6350: cb050063    	sub	x3, x3, x5
1005c6354: d280002b    	mov	x11, #0x1               ; =1
1005c6358: f80183eb    	stur	x11, [sp, #0x18]
1005c635c: 9100058c    	add	x12, x12, #0x1
1005c6360: d280000b    	mov	x11, #0x0               ; =0
1005c6364: f80203eb    	stur	x11, [sp, #0x20]
1005c6368: d2968d05    	mov	x5, #0xb468             ; =46184
1005c636c: eb05007f    	cmp	x3, x5
1005c6370: 9a9f37e5    	cset	x5, hs
1005c6374: f84a03f8    	ldur	x24, [sp, #0xa0]
1005c6378: 0a1800a5    	and	w5, w5, w24
1005c637c: 53001ca5    	uxtb	w5, w5
1005c6380: b50010c5    	cbnz	x5, 0x1005c6598 <_mech_canonical_program_entry_v1_numeric_256+0xa98>
1005c6384: d2800020    	mov	x0, #0x1                ; =1
1005c6388: f9001a60    	str	x0, [x19, #0x30]
1005c638c: d2800045    	mov	x5, #0x2                ; =2
1005c6390: f9002265    	str	x5, [x19, #0x40]
1005c6394: aa0503f5    	mov	x21, x5
1005c6398: d28000c5    	mov	x5, #0x6                ; =6
1005c639c: f9003265    	str	x5, [x19, #0x60]
1005c63a0: d2800005    	mov	x5, #0x0                ; =0
1005c63a4: f900c665    	str	x5, [x19, #0x188]
1005c63a8: f900ca60    	str	x0, [x19, #0x190]
1005c63ac: f902e27a    	str	x26, [x19, #0x5c0]
1005c63b0: f902e679    	str	x25, [x19, #0x5c8]
1005c63b4: f84983e0    	ldur	x0, [sp, #0x98]
1005c63b8: 53001c00    	uxtb	w0, w0
1005c63bc: f902f260    	str	x0, [x19, #0x5e0]
1005c63c0: f9254e66    	str	x6, [x19, #0x4a98]
1005c63c4: f9255263    	str	x3, [x19, #0x4aa0]
1005c63c8: f9255664    	str	x4, [x19, #0x4aa8]
1005c63cc: f927ba7a    	str	x26, [x19, #0x4f70]
1005c63d0: f927be79    	str	x25, [x19, #0x4f78]
1005c63d4: f927da7c    	str	x28, [x19, #0x4fb0]
1005c63d8: f927de7b    	str	x27, [x19, #0x4fb8]
1005c63dc: f84503f4    	ldur	x20, [sp, #0x50]
1005c63e0: f9288a74    	str	x20, [x19, #0x5110]
1005c63e4: f84083f7    	ldur	x23, [sp, #0x8]
1005c63e8: f9289a77    	str	x23, [x19, #0x5130]
1005c63ec: f928de6c    	str	x12, [x19, #0x51b8]
1005c63f0: f928e262    	str	x2, [x19, #0x51c0]
1005c63f4: f928e661    	str	x1, [x19, #0x51c8]
1005c63f8: f84103e5    	ldur	x5, [sp, #0x10]
1005c63fc: cb0300a0    	sub	x0, x5, x3
1005c6400: d29d1501    	mov	x1, #0xe8a8             ; =59560
1005c6404: 9b018180    	msub	x0, x12, x1, x0
1005c6408: f928ea60    	str	x0, [x19, #0x51d0]
1005c640c: f84183eb    	ldur	x11, [sp, #0x18]
1005c6410: f928ee6b    	str	x11, [x19, #0x51d8]
1005c6414: f84203eb    	ldur	x11, [sp, #0x20]
1005c6418: f928f26b    	str	x11, [x19, #0x51e0]
1005c641c: f928fa6d    	str	x13, [x19, #0x51f0]
1005c6420: f928fe76    	str	x22, [x19, #0x51f8]
1005c6424: f9290669    	str	x9, [x19, #0x5208]
1005c6428: f9290a67    	str	x7, [x19, #0x5210]
1005c642c: f9654e65    	ldr	x5, [x19, #0x4a98]
1005c6430: f10000bf    	cmp	x5, #0x0
1005c6434: 540009e0    	b.eq	0x1005c6570 <_mech_canonical_program_entry_v1_numeric_256+0xa70>
1005c6438: f9655263    	ldr	x3, [x19, #0x4aa0]
1005c643c: f9655664    	ldr	x4, [x19, #0x4aa8]
1005c6440: d2800008    	mov	x8, #0x0                ; =0
1005c6444: f9254e68    	str	x8, [x19, #0x4a98]
1005c6448: d2800060    	mov	x0, #0x3                ; =3
1005c644c: f84d83e8    	ldur	x8, [sp, #0xd8]
1005c6450: f80703e0    	stur	x0, [sp, #0x70]
1005c6454: f101611f    	cmp	x8, #0x58
1005c6458: 540123c3    	b.lo	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c645c: f967ba6c    	ldr	x12, [x19, #0x4f70]
1005c6460: f84e03e0    	ldur	x0, [sp, #0xe0]
1005c6464: f900080c    	str	x12, [x0, #0x10]
1005c6468: f967be6d    	ldr	x13, [x19, #0x4f78]
1005c646c: f9000c0d    	str	x13, [x0, #0x18]
1005c6470: f9688a6e    	ldr	x14, [x19, #0x5110]
1005c6474: f900d80e    	str	x14, [x0, #0x1b0]
1005c6478: f9689a6f    	ldr	x15, [x19, #0x5130]
1005c647c: f900e80f    	str	x15, [x0, #0x1d0]
1005c6480: f900080c    	str	x12, [x0, #0x10]
1005c6484: f9000c0d    	str	x13, [x0, #0x18]
1005c6488: f967da60    	ldr	x0, [x19, #0x4fb0]
1005c648c: f84e03e1    	ldur	x1, [sp, #0xe0]
1005c6490: f9002820    	str	x0, [x1, #0x50]
1005c6494: f967de60    	ldr	x0, [x19, #0x4fb8]
1005c6498: f9002c20    	str	x0, [x1, #0x58]
1005c649c: f9680260    	ldr	x0, [x19, #0x5000]
1005c64a0: f9005020    	str	x0, [x1, #0xa0]
1005c64a4: f9680660    	ldr	x0, [x19, #0x5008]
1005c64a8: f9005420    	str	x0, [x1, #0xa8]
1005c64ac: f9680a60    	ldr	x0, [x19, #0x5010]
1005c64b0: f9005820    	str	x0, [x1, #0xb0]
1005c64b4: f9683a60    	ldr	x0, [x19, #0x5070]
1005c64b8: f84e03e5    	ldur	x5, [sp, #0xe0]
1005c64bc: f90088a0    	str	x0, [x5, #0x110]
1005c64c0: f9683e60    	ldr	x0, [x19, #0x5078]
1005c64c4: f84e03e6    	ldur	x6, [sp, #0xe0]
1005c64c8: f9008cc0    	str	x0, [x6, #0x118]
1005c64cc: f9684260    	ldr	x0, [x19, #0x5080]
1005c64d0: f84e03e9    	ldur	x9, [sp, #0xe0]
1005c64d4: f9009120    	str	x0, [x9, #0x120]
1005c64d8: f9684660    	ldr	x0, [x19, #0x5088]
1005c64dc: f84e03ec    	ldur	x12, [sp, #0xe0]
1005c64e0: f9009580    	str	x0, [x12, #0x128]
1005c64e4: f968de60    	ldr	x0, [x19, #0x51b8]
1005c64e8: f84e03ef    	ldur	x15, [sp, #0xe0]
1005c64ec: f9012de0    	str	x0, [x15, #0x258]
1005c64f0: f968e260    	ldr	x0, [x19, #0x51c0]
1005c64f4: f9013020    	str	x0, [x1, #0x260]
1005c64f8: f968e660    	ldr	x0, [x19, #0x51c8]
1005c64fc: f9013420    	str	x0, [x1, #0x268]
1005c6500: f968ea60    	ldr	x0, [x19, #0x51d0]
1005c6504: f9013820    	str	x0, [x1, #0x270]
1005c6508: f968ee60    	ldr	x0, [x19, #0x51d8]
1005c650c: f9013c20    	str	x0, [x1, #0x278]
1005c6510: f968f260    	ldr	x0, [x19, #0x51e0]
1005c6514: f9014020    	str	x0, [x1, #0x280]
1005c6518: d2800000    	mov	x0, #0x0                ; =0
1005c651c: f9014420    	str	x0, [x1, #0x288]
1005c6520: f968fa61    	ldr	x1, [x19, #0x51f0]
1005c6524: f84e03e2    	ldur	x2, [sp, #0xe0]
1005c6528: f9014841    	str	x1, [x2, #0x290]
1005c652c: f968fe61    	ldr	x1, [x19, #0x51f8]
1005c6530: f9014c41    	str	x1, [x2, #0x298]
1005c6534: f84e03e1    	ldur	x1, [sp, #0xe0]
1005c6538: f9015020    	str	x0, [x1, #0x2a0]
1005c653c: f9690660    	ldr	x0, [x19, #0x5208]
1005c6540: f9015420    	str	x0, [x1, #0x2a8]
1005c6544: f9690a60    	ldr	x0, [x19, #0x5210]
1005c6548: f9015820    	str	x0, [x1, #0x2b0]
1005c654c: d2802321    	mov	x1, #0x119              ; =281
1005c6550: 92800102    	mov	x2, #-0x9               ; =-9
1005c6554: d2800025    	mov	x5, #0x1                ; =1
1005c6558: f84003e0    	ldur	x0, [sp]
1005c655c: f84e83e6    	ldur	x6, [sp, #0xe8]
1005c6560: f84f03e7    	ldur	x7, [sp, #0xf0]
1005c6564: d63f00e0    	blr	x7
1005c6568: f100001f    	cmp	x0, #0x0
1005c656c: 540094a1    	b.ne	0x1005c7800 <_mech_canonical_program_entry_v1_numeric_256+0x1d00>
1005c6570: d2800000    	mov	x0, #0x0                ; =0
1005c6574: aa1503e1    	mov	x1, x21
1005c6578: 910403ff    	add	sp, sp, #0x100
1005c657c: a8c153f3    	ldp	x19, x20, [sp], #0x10
1005c6580: a8c15bf5    	ldp	x21, x22, [sp], #0x10
1005c6584: a8c163f7    	ldp	x23, x24, [sp], #0x10
1005c6588: a8c16bf9    	ldp	x25, x26, [sp], #0x10
1005c658c: a8c173fb    	ldp	x27, x28, [sp], #0x10
1005c6590: a8c17bfd    	ldp	x29, x30, [sp], #0x10
1005c6594: d65f0fff    	retab
1005c6598: d2800045    	mov	x5, #0x2                ; =2
1005c659c: f80903e5    	stur	x5, [sp, #0x90]
1005c65a0: 91000b85    	add	x5, x28, #0x2
1005c65a4: eb1c00bf    	cmp	x5, x28
1005c65a8: 54009303    	b.lo	0x1005c7808 <_mech_canonical_program_entry_v1_numeric_256+0x1d08>
1005c65ac: 91000b98    	add	x24, x28, #0x2
1005c65b0: eb1b031f    	cmp	x24, x27
1005c65b4: f80883f8    	stur	x24, [sp, #0x88]
1005c65b8: 9a9f27f8    	cset	x24, lo
1005c65bc: f84883e5    	ldur	x5, [sp, #0x88]
1005c65c0: eb1b00bf    	cmp	x5, x27
1005c65c4: 54000083    	b.lo	0x1005c65d4 <_mech_canonical_program_entry_v1_numeric_256+0xad4>
1005c65c8: d2968d05    	mov	x5, #0xb468             ; =46184
1005c65cc: cb050063    	sub	x3, x3, x5
1005c65d0: 1400034d    	b	0x1005c7304 <_mech_canonical_program_entry_v1_numeric_256+0x1804>
1005c65d4: d2968d05    	mov	x5, #0xb468             ; =46184
1005c65d8: cb050063    	sub	x3, x3, x5
1005c65dc: d280002a    	mov	x10, #0x1               ; =1
1005c65e0: f80283ea    	stur	x10, [sp, #0x28]
1005c65e4: 91000785    	add	x5, x28, #0x1
1005c65e8: f80803e5    	stur	x5, [sp, #0x80]
1005c65ec: d280000a    	mov	x10, #0x0               ; =0
1005c65f0: f80303ea    	stur	x10, [sp, #0x30]
1005c65f4: f84803f6    	ldur	x22, [sp, #0x80]
1005c65f8: d2979005    	mov	x5, #0xbc80             ; =48256
1005c65fc: eb05007f    	cmp	x3, x5
1005c6600: 9a9f37e5    	cset	x5, hs
1005c6604: f84a03e8    	ldur	x8, [sp, #0xa0]
1005c6608: 0a0800a5    	and	w5, w5, w8
1005c660c: 53001ca5    	uxtb	w5, w5
1005c6610: b50011c5    	cbnz	x5, 0x1005c6848 <_mech_canonical_program_entry_v1_numeric_256+0xd48>
1005c6614: d2800020    	mov	x0, #0x1                ; =1
1005c6618: f9001a60    	str	x0, [x19, #0x30]
1005c661c: f84903ee    	ldur	x14, [sp, #0x90]
1005c6620: f900226e    	str	x14, [x19, #0x40]
1005c6624: d28000c5    	mov	x5, #0x6                ; =6
1005c6628: f9003265    	str	x5, [x19, #0x60]
1005c662c: d2800005    	mov	x5, #0x0                ; =0
1005c6630: f900c665    	str	x5, [x19, #0x188]
1005c6634: f900ca60    	str	x0, [x19, #0x190]
1005c6638: f902e27a    	str	x26, [x19, #0x5c0]
1005c663c: f902e679    	str	x25, [x19, #0x5c8]
1005c6640: f84983e0    	ldur	x0, [sp, #0x98]
1005c6644: 53001c00    	uxtb	w0, w0
1005c6648: f902f260    	str	x0, [x19, #0x5e0]
1005c664c: f9032e7c    	str	x28, [x19, #0x658]
1005c6650: f903327b    	str	x27, [x19, #0x660]
1005c6654: 53001f00    	uxtb	w0, w24
1005c6658: f9033e60    	str	x0, [x19, #0x678]
1005c665c: f9254e66    	str	x6, [x19, #0x4a98]
1005c6660: f9255263    	str	x3, [x19, #0x4aa0]
1005c6664: f9255664    	str	x4, [x19, #0x4aa8]
1005c6668: f927ba7a    	str	x26, [x19, #0x4f70]
1005c666c: f927be79    	str	x25, [x19, #0x4f78]
1005c6670: f927da7c    	str	x28, [x19, #0x4fb0]
1005c6674: f927de7b    	str	x27, [x19, #0x4fb8]
1005c6678: f928027c    	str	x28, [x19, #0x5000]
1005c667c: f9280676    	str	x22, [x19, #0x5008]
1005c6680: f9280a7b    	str	x27, [x19, #0x5010]
1005c6684: f84503f4    	ldur	x20, [sp, #0x50]
1005c6688: f9288a74    	str	x20, [x19, #0x5110]
1005c668c: f84083f7    	ldur	x23, [sp, #0x8]
1005c6690: f9289a77    	str	x23, [x19, #0x5130]
1005c6694: f928de6c    	str	x12, [x19, #0x51b8]
1005c6698: f928e262    	str	x2, [x19, #0x51c0]
1005c669c: f928e661    	str	x1, [x19, #0x51c8]
1005c66a0: f84103e5    	ldur	x5, [sp, #0x10]
1005c66a4: cb0300a0    	sub	x0, x5, x3
1005c66a8: d29d1501    	mov	x1, #0xe8a8             ; =59560
1005c66ac: 9b018180    	msub	x0, x12, x1, x0
1005c66b0: f928ea60    	str	x0, [x19, #0x51d0]
1005c66b4: f84183eb    	ldur	x11, [sp, #0x18]
1005c66b8: f928ee6b    	str	x11, [x19, #0x51d8]
1005c66bc: f84203ed    	ldur	x13, [sp, #0x20]
1005c66c0: f928f26d    	str	x13, [x19, #0x51e0]
1005c66c4: f84283e5    	ldur	x5, [sp, #0x28]
1005c66c8: f928fa65    	str	x5, [x19, #0x51f0]
1005c66cc: f84303e1    	ldur	x1, [sp, #0x30]
1005c66d0: f928fe61    	str	x1, [x19, #0x51f8]
1005c66d4: f9290669    	str	x9, [x19, #0x5208]
1005c66d8: f9290a67    	str	x7, [x19, #0x5210]
1005c66dc: f9654e67    	ldr	x7, [x19, #0x4a98]
1005c66e0: f10000ff    	cmp	x7, #0x0
1005c66e4: 540009e0    	b.eq	0x1005c6820 <_mech_canonical_program_entry_v1_numeric_256+0xd20>
1005c66e8: f9655263    	ldr	x3, [x19, #0x4aa0]
1005c66ec: f9655664    	ldr	x4, [x19, #0x4aa8]
1005c66f0: d280000a    	mov	x10, #0x0               ; =0
1005c66f4: f9254e6a    	str	x10, [x19, #0x4a98]
1005c66f8: d2800060    	mov	x0, #0x3                ; =3
1005c66fc: f84d83e8    	ldur	x8, [sp, #0xd8]
1005c6700: f80703e0    	stur	x0, [sp, #0x70]
1005c6704: f101611f    	cmp	x8, #0x58
1005c6708: 54010e43    	b.lo	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c670c: f967ba6e    	ldr	x14, [x19, #0x4f70]
1005c6710: f84e03e5    	ldur	x5, [sp, #0xe0]
1005c6714: f90008ae    	str	x14, [x5, #0x10]
1005c6718: f967be6f    	ldr	x15, [x19, #0x4f78]
1005c671c: f84e03e8    	ldur	x8, [sp, #0xe0]
1005c6720: f9000d0f    	str	x15, [x8, #0x18]
1005c6724: f9688a60    	ldr	x0, [x19, #0x5110]
1005c6728: f84e03eb    	ldur	x11, [sp, #0xe0]
1005c672c: f900d960    	str	x0, [x11, #0x1b0]
1005c6730: f9689a60    	ldr	x0, [x19, #0x5130]
1005c6734: f84e03e1    	ldur	x1, [sp, #0xe0]
1005c6738: f900e820    	str	x0, [x1, #0x1d0]
1005c673c: f84e03e0    	ldur	x0, [sp, #0xe0]
1005c6740: f900080e    	str	x14, [x0, #0x10]
1005c6744: f9000c0f    	str	x15, [x0, #0x18]
1005c6748: f967da60    	ldr	x0, [x19, #0x4fb0]
1005c674c: f9002820    	str	x0, [x1, #0x50]
1005c6750: f967de60    	ldr	x0, [x19, #0x4fb8]
1005c6754: f9002c20    	str	x0, [x1, #0x58]
1005c6758: f9680260    	ldr	x0, [x19, #0x5000]
1005c675c: f9005020    	str	x0, [x1, #0xa0]
1005c6760: f9680660    	ldr	x0, [x19, #0x5008]
1005c6764: f9005420    	str	x0, [x1, #0xa8]
1005c6768: f9680a60    	ldr	x0, [x19, #0x5010]
1005c676c: f9005820    	str	x0, [x1, #0xb0]
1005c6770: f9683a60    	ldr	x0, [x19, #0x5070]
1005c6774: f9008820    	str	x0, [x1, #0x110]
1005c6778: f9683e60    	ldr	x0, [x19, #0x5078]
1005c677c: f9008c20    	str	x0, [x1, #0x118]
1005c6780: f9684260    	ldr	x0, [x19, #0x5080]
1005c6784: f9009020    	str	x0, [x1, #0x120]
1005c6788: f9684660    	ldr	x0, [x19, #0x5088]
1005c678c: f9009420    	str	x0, [x1, #0x128]
1005c6790: f968de60    	ldr	x0, [x19, #0x51b8]
1005c6794: f9012c20    	str	x0, [x1, #0x258]
1005c6798: f968e260    	ldr	x0, [x19, #0x51c0]
1005c679c: f9013020    	str	x0, [x1, #0x260]
1005c67a0: f968e660    	ldr	x0, [x19, #0x51c8]
1005c67a4: f9013420    	str	x0, [x1, #0x268]
1005c67a8: f968ea60    	ldr	x0, [x19, #0x51d0]
1005c67ac: f9013820    	str	x0, [x1, #0x270]
1005c67b0: f968ee60    	ldr	x0, [x19, #0x51d8]
1005c67b4: f9013c20    	str	x0, [x1, #0x278]
1005c67b8: f968f260    	ldr	x0, [x19, #0x51e0]
1005c67bc: f9014020    	str	x0, [x1, #0x280]
1005c67c0: d2800000    	mov	x0, #0x0                ; =0
1005c67c4: f90144a0    	str	x0, [x5, #0x288]
1005c67c8: f968fa61    	ldr	x1, [x19, #0x51f0]
1005c67cc: f84e03e6    	ldur	x6, [sp, #0xe0]
1005c67d0: f90148c1    	str	x1, [x6, #0x290]
1005c67d4: f968fe61    	ldr	x1, [x19, #0x51f8]
1005c67d8: f84e03e9    	ldur	x9, [sp, #0xe0]
1005c67dc: f9014d21    	str	x1, [x9, #0x298]
1005c67e0: f9015160    	str	x0, [x11, #0x2a0]
1005c67e4: f9690660    	ldr	x0, [x19, #0x5208]
1005c67e8: f84e03ee    	ldur	x14, [sp, #0xe0]
1005c67ec: f90155c0    	str	x0, [x14, #0x2a8]
1005c67f0: f9690a60    	ldr	x0, [x19, #0x5210]
1005c67f4: f84e03e1    	ldur	x1, [sp, #0xe0]
1005c67f8: f9015820    	str	x0, [x1, #0x2b0]
1005c67fc: d2802601    	mov	x1, #0x130              ; =304
1005c6800: 92800102    	mov	x2, #-0x9               ; =-9
1005c6804: d2800025    	mov	x5, #0x1                ; =1
1005c6808: f84003e0    	ldur	x0, [sp]
1005c680c: f84e83e6    	ldur	x6, [sp, #0xe8]
1005c6810: f84f03e7    	ldur	x7, [sp, #0xf0]
1005c6814: d63f00e0    	blr	x7
1005c6818: f100001f    	cmp	x0, #0x0
1005c681c: 54008521    	b.ne	0x1005c78c0 <_mech_canonical_program_entry_v1_numeric_256+0x1dc0>
1005c6820: d2800000    	mov	x0, #0x0                ; =0
1005c6824: d2800061    	mov	x1, #0x3                ; =3
1005c6828: 910403ff    	add	sp, sp, #0x100
1005c682c: a8c153f3    	ldp	x19, x20, [sp], #0x10
1005c6830: a8c15bf5    	ldp	x21, x22, [sp], #0x10
1005c6834: a8c163f7    	ldp	x23, x24, [sp], #0x10
1005c6838: a8c16bf9    	ldp	x25, x26, [sp], #0x10
1005c683c: a8c173fb    	ldp	x27, x28, [sp], #0x10
1005c6840: a8c17bfd    	ldp	x29, x30, [sp], #0x10
1005c6844: d65f0fff    	retab
1005c6848: 910006c5    	add	x5, x22, #0x1
1005c684c: eb1600bf    	cmp	x5, x22
1005c6850: f80783e5    	stur	x5, [sp, #0x78]
1005c6854: 540083c3    	b.lo	0x1005c78cc <_mech_canonical_program_entry_v1_numeric_256+0x1dcc>
1005c6858: f84783e5    	ldur	x5, [sp, #0x78]
1005c685c: eb1b00bf    	cmp	x5, x27
1005c6860: 9a9f27f7    	cset	x23, lo
1005c6864: eb1b00bf    	cmp	x5, x27
1005c6868: 54000083    	b.lo	0x1005c6878 <_mech_canonical_program_entry_v1_numeric_256+0xd78>
1005c686c: d2979005    	mov	x5, #0xbc80             ; =48256
1005c6870: cb050063    	sub	x3, x3, x5
1005c6874: 14000298    	b	0x1005c72d4 <_mech_canonical_program_entry_v1_numeric_256+0x17d4>
1005c6878: d2979005    	mov	x5, #0xbc80             ; =48256
1005c687c: cb050063    	sub	x3, x3, x5
1005c6880: d2800029    	mov	x9, #0x1                ; =1
1005c6884: d2800007    	mov	x7, #0x0                ; =0
1005c6888: f84783f5    	ldur	x21, [sp, #0x78]
1005c688c: d29bbe05    	mov	x5, #0xddf0             ; =56816
1005c6890: eb05007f    	cmp	x3, x5
1005c6894: 9a9f37e5    	cset	x5, hs
1005c6898: f84a03e8    	ldur	x8, [sp, #0xa0]
1005c689c: 0a0800a5    	and	w5, w5, w8
1005c68a0: f84083e8    	ldur	x8, [sp, #0x8]
1005c68a4: f84383ed    	ldur	x13, [sp, #0x38]
1005c68a8: eb0d011f    	cmp	x8, x13
1005c68ac: 9a9f87e8    	cset	x8, ls
1005c68b0: f84083ea    	ldur	x10, [sp, #0x8]
1005c68b4: cb0a01aa    	sub	x10, x13, x10
1005c68b8: f100015f    	cmp	x10, #0x0
1005c68bc: 9a9f07ea    	cset	x10, ne
1005c68c0: 0a0a0108    	and	w8, w8, w10
1005c68c4: 0a0800a5    	and	w5, w5, w8
1005c68c8: 53001ca5    	uxtb	w5, w5
1005c68cc: b5001305    	cbnz	x5, 0x1005c6b2c <_mech_canonical_program_entry_v1_numeric_256+0x102c>
1005c68d0: d2800020    	mov	x0, #0x1                ; =1
1005c68d4: f9001a60    	str	x0, [x19, #0x30]
1005c68d8: f84903ee    	ldur	x14, [sp, #0x90]
1005c68dc: f900226e    	str	x14, [x19, #0x40]
1005c68e0: d28000c5    	mov	x5, #0x6                ; =6
1005c68e4: f9003265    	str	x5, [x19, #0x60]
1005c68e8: d2800005    	mov	x5, #0x0                ; =0
1005c68ec: f900c665    	str	x5, [x19, #0x188]
1005c68f0: f900ca60    	str	x0, [x19, #0x190]
1005c68f4: f902e27a    	str	x26, [x19, #0x5c0]
1005c68f8: f902e679    	str	x25, [x19, #0x5c8]
1005c68fc: f84983e0    	ldur	x0, [sp, #0x98]
1005c6900: 53001c00    	uxtb	w0, w0
1005c6904: f902f260    	str	x0, [x19, #0x5e0]
1005c6908: f9032e7c    	str	x28, [x19, #0x658]
1005c690c: f903327b    	str	x27, [x19, #0x660]
1005c6910: 53001f00    	uxtb	w0, w24
1005c6914: f9033e60    	str	x0, [x19, #0x678]
1005c6918: f903727c    	str	x28, [x19, #0x6e0]
1005c691c: f9037676    	str	x22, [x19, #0x6e8]
1005c6920: f9037a7b    	str	x27, [x19, #0x6f0]
1005c6924: 53001ee0    	uxtb	w0, w23
1005c6928: f9038660    	str	x0, [x19, #0x708]
1005c692c: f9254e66    	str	x6, [x19, #0x4a98]
1005c6930: f9255263    	str	x3, [x19, #0x4aa0]
1005c6934: f9255664    	str	x4, [x19, #0x4aa8]
1005c6938: f927ba7a    	str	x26, [x19, #0x4f70]
1005c693c: f927be79    	str	x25, [x19, #0x4f78]
1005c6940: f927da7c    	str	x28, [x19, #0x4fb0]
1005c6944: f927de7b    	str	x27, [x19, #0x4fb8]
1005c6948: f928027c    	str	x28, [x19, #0x5000]
1005c694c: f9280676    	str	x22, [x19, #0x5008]
1005c6950: f9280a7b    	str	x27, [x19, #0x5010]
1005c6954: f9283a7c    	str	x28, [x19, #0x5070]
1005c6958: f9283e76    	str	x22, [x19, #0x5078]
1005c695c: f9284275    	str	x21, [x19, #0x5080]
1005c6960: f928467b    	str	x27, [x19, #0x5088]
1005c6964: f84503f4    	ldur	x20, [sp, #0x50]
1005c6968: f9288a74    	str	x20, [x19, #0x5110]
1005c696c: f84083f7    	ldur	x23, [sp, #0x8]
1005c6970: f9289a77    	str	x23, [x19, #0x5130]
1005c6974: f928de6c    	str	x12, [x19, #0x51b8]
1005c6978: f928e262    	str	x2, [x19, #0x51c0]
1005c697c: f928e661    	str	x1, [x19, #0x51c8]
1005c6980: f84103e5    	ldur	x5, [sp, #0x10]
1005c6984: cb0300a0    	sub	x0, x5, x3
1005c6988: d29d1501    	mov	x1, #0xe8a8             ; =59560
1005c698c: 9b018180    	msub	x0, x12, x1, x0
1005c6990: f928ea60    	str	x0, [x19, #0x51d0]
1005c6994: f84183eb    	ldur	x11, [sp, #0x18]
1005c6998: f928ee6b    	str	x11, [x19, #0x51d8]
1005c699c: f84203ed    	ldur	x13, [sp, #0x20]
1005c69a0: f928f26d    	str	x13, [x19, #0x51e0]
1005c69a4: f84283e2    	ldur	x2, [sp, #0x28]
1005c69a8: f928fa62    	str	x2, [x19, #0x51f0]
1005c69ac: f84303ea    	ldur	x10, [sp, #0x30]
1005c69b0: f928fe6a    	str	x10, [x19, #0x51f8]
1005c69b4: f9290669    	str	x9, [x19, #0x5208]
1005c69b8: f9290a67    	str	x7, [x19, #0x5210]
1005c69bc: f9654e60    	ldr	x0, [x19, #0x4a98]
1005c69c0: f100001f    	cmp	x0, #0x0
1005c69c4: 54000a00    	b.eq	0x1005c6b04 <_mech_canonical_program_entry_v1_numeric_256+0x1004>
1005c69c8: f9655263    	ldr	x3, [x19, #0x4aa0]
1005c69cc: f9655664    	ldr	x4, [x19, #0x4aa8]
1005c69d0: d2800000    	mov	x0, #0x0                ; =0
1005c69d4: f9254e60    	str	x0, [x19, #0x4a98]
1005c69d8: d2800060    	mov	x0, #0x3                ; =3
1005c69dc: f84d83e8    	ldur	x8, [sp, #0xd8]
1005c69e0: f80703e0    	stur	x0, [sp, #0x70]
1005c69e4: f101611f    	cmp	x8, #0x58
1005c69e8: 5400f743    	b.lo	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c69ec: f967ba60    	ldr	x0, [x19, #0x4f70]
1005c69f0: f84e03e1    	ldur	x1, [sp, #0xe0]
1005c69f4: f9000820    	str	x0, [x1, #0x10]
1005c69f8: f967be61    	ldr	x1, [x19, #0x4f78]
1005c69fc: f84e03e2    	ldur	x2, [sp, #0xe0]
1005c6a00: f9000c41    	str	x1, [x2, #0x18]
1005c6a04: f9688a62    	ldr	x2, [x19, #0x5110]
1005c6a08: f84e03e5    	ldur	x5, [sp, #0xe0]
1005c6a0c: f900d8a2    	str	x2, [x5, #0x1b0]
1005c6a10: f9689a62    	ldr	x2, [x19, #0x5130]
1005c6a14: f900e8a2    	str	x2, [x5, #0x1d0]
1005c6a18: f84e03e7    	ldur	x7, [sp, #0xe0]
1005c6a1c: f90008e0    	str	x0, [x7, #0x10]
1005c6a20: f84e03e9    	ldur	x9, [sp, #0xe0]
1005c6a24: f9000d21    	str	x1, [x9, #0x18]
1005c6a28: f967da60    	ldr	x0, [x19, #0x4fb0]
1005c6a2c: f84e03ec    	ldur	x12, [sp, #0xe0]
1005c6a30: f9002980    	str	x0, [x12, #0x50]
1005c6a34: f967de60    	ldr	x0, [x19, #0x4fb8]
1005c6a38: f84e03ef    	ldur	x15, [sp, #0xe0]
1005c6a3c: f9002de0    	str	x0, [x15, #0x58]
1005c6a40: f9680260    	ldr	x0, [x19, #0x5000]
1005c6a44: f84e03e1    	ldur	x1, [sp, #0xe0]
1005c6a48: f9005020    	str	x0, [x1, #0xa0]
1005c6a4c: f9680660    	ldr	x0, [x19, #0x5008]
1005c6a50: f9005420    	str	x0, [x1, #0xa8]
1005c6a54: f9680a60    	ldr	x0, [x19, #0x5010]
1005c6a58: f9005820    	str	x0, [x1, #0xb0]
1005c6a5c: f9683a60    	ldr	x0, [x19, #0x5070]
1005c6a60: f9008820    	str	x0, [x1, #0x110]
1005c6a64: f9683e60    	ldr	x0, [x19, #0x5078]
1005c6a68: f9008c20    	str	x0, [x1, #0x118]
1005c6a6c: f9684260    	ldr	x0, [x19, #0x5080]
1005c6a70: f9009020    	str	x0, [x1, #0x120]
1005c6a74: f9684660    	ldr	x0, [x19, #0x5088]
1005c6a78: f9009420    	str	x0, [x1, #0x128]
1005c6a7c: f968de60    	ldr	x0, [x19, #0x51b8]
1005c6a80: f9012c20    	str	x0, [x1, #0x258]
1005c6a84: f968e260    	ldr	x0, [x19, #0x51c0]
1005c6a88: f9013020    	str	x0, [x1, #0x260]
1005c6a8c: f968e660    	ldr	x0, [x19, #0x51c8]
1005c6a90: f9013420    	str	x0, [x1, #0x268]
1005c6a94: f968ea60    	ldr	x0, [x19, #0x51d0]
1005c6a98: f9013820    	str	x0, [x1, #0x270]
1005c6a9c: f968ee60    	ldr	x0, [x19, #0x51d8]
1005c6aa0: f9013c20    	str	x0, [x1, #0x278]
1005c6aa4: f968f260    	ldr	x0, [x19, #0x51e0]
1005c6aa8: f9014020    	str	x0, [x1, #0x280]
1005c6aac: d2800000    	mov	x0, #0x0                ; =0
1005c6ab0: f9014420    	str	x0, [x1, #0x288]
1005c6ab4: f968fa61    	ldr	x1, [x19, #0x51f0]
1005c6ab8: f84e03e2    	ldur	x2, [sp, #0xe0]
1005c6abc: f9014841    	str	x1, [x2, #0x290]
1005c6ac0: f968fe61    	ldr	x1, [x19, #0x51f8]
1005c6ac4: f9014c41    	str	x1, [x2, #0x298]
1005c6ac8: f9015040    	str	x0, [x2, #0x2a0]
1005c6acc: f9690660    	ldr	x0, [x19, #0x5208]
1005c6ad0: f90154a0    	str	x0, [x5, #0x2a8]
1005c6ad4: f9690a60    	ldr	x0, [x19, #0x5210]
1005c6ad8: f84e03e8    	ldur	x8, [sp, #0xe0]
1005c6adc: f9015900    	str	x0, [x8, #0x2b0]
1005c6ae0: d2802921    	mov	x1, #0x149              ; =329
1005c6ae4: 92800102    	mov	x2, #-0x9               ; =-9
1005c6ae8: d2800025    	mov	x5, #0x1                ; =1
1005c6aec: f84003e0    	ldur	x0, [sp]
1005c6af0: f84e83e6    	ldur	x6, [sp, #0xe8]
1005c6af4: f84f03e7    	ldur	x7, [sp, #0xf0]
1005c6af8: d63f00e0    	blr	x7
1005c6afc: f100001f    	cmp	x0, #0x0
1005c6b00: 54007501    	b.ne	0x1005c79a0 <_mech_canonical_program_entry_v1_numeric_256+0x1ea0>
1005c6b04: d2800000    	mov	x0, #0x0                ; =0
1005c6b08: d2800081    	mov	x1, #0x4                ; =4
1005c6b0c: 910403ff    	add	sp, sp, #0x100
1005c6b10: a8c153f3    	ldp	x19, x20, [sp], #0x10
1005c6b14: a8c15bf5    	ldp	x21, x22, [sp], #0x10
1005c6b18: a8c163f7    	ldp	x23, x24, [sp], #0x10
1005c6b1c: a8c16bf9    	ldp	x25, x26, [sp], #0x10
1005c6b20: a8c173fb    	ldp	x27, x28, [sp], #0x10
1005c6b24: a8c17bfd    	ldp	x29, x30, [sp], #0x10
1005c6b28: d65f0fff    	retab
1005c6b2c: eb1b02bf    	cmp	x21, x27
1005c6b30: 9a9f27ee    	cset	x14, lo
1005c6b34: eb1b02bf    	cmp	x21, x27
1005c6b38: 540000c3    	b.lo	0x1005c6b50 <_mech_canonical_program_entry_v1_numeric_256+0x1050>
1005c6b3c: d29bbe05    	mov	x5, #0xddf0             ; =56816
1005c6b40: cb050063    	sub	x3, x3, x5
1005c6b44: aa1503e8    	mov	x8, x21
1005c6b48: f80383ed    	stur	x13, [sp, #0x38]
1005c6b4c: 140001d5    	b	0x1005c72a0 <_mech_canonical_program_entry_v1_numeric_256+0x17a0>
1005c6b50: f84a83ef    	ldur	x15, [sp, #0xa8]
1005c6b54: eb0f039f    	cmp	x28, x15
1005c6b58: 54000cc3    	b.lo	0x1005c6cf0 <_mech_canonical_program_entry_v1_numeric_256+0x11f0>
1005c6b5c: 14000394    	b	0x1005c79ac <_mech_canonical_program_entry_v1_numeric_256+0x1eac>
1005c6b60: f9655263    	ldr	x3, [x19, #0x4aa0]
1005c6b64: f9655664    	ldr	x4, [x19, #0x4aa8]
1005c6b68: d280000a    	mov	x10, #0x0               ; =0
1005c6b6c: f9254e6a    	str	x10, [x19, #0x4a98]
1005c6b70: d2800060    	mov	x0, #0x3                ; =3
1005c6b74: f84d83e8    	ldur	x8, [sp, #0xd8]
1005c6b78: f80703e0    	stur	x0, [sp, #0x70]
1005c6b7c: f101611f    	cmp	x8, #0x58
1005c6b80: 5400ea83    	b.lo	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c6b84: f967ba6e    	ldr	x14, [x19, #0x4f70]
1005c6b88: f84e03e0    	ldur	x0, [sp, #0xe0]
1005c6b8c: f900080e    	str	x14, [x0, #0x10]
1005c6b90: f967be6f    	ldr	x15, [x19, #0x4f78]
1005c6b94: f9000c0f    	str	x15, [x0, #0x18]
1005c6b98: f9688a60    	ldr	x0, [x19, #0x5110]
1005c6b9c: f84e03e1    	ldur	x1, [sp, #0xe0]
1005c6ba0: f900d820    	str	x0, [x1, #0x1b0]
1005c6ba4: f9689a60    	ldr	x0, [x19, #0x5130]
1005c6ba8: f84e03e2    	ldur	x2, [sp, #0xe0]
1005c6bac: f900e840    	str	x0, [x2, #0x1d0]
1005c6bb0: f84e03e5    	ldur	x5, [sp, #0xe0]
1005c6bb4: f90008ae    	str	x14, [x5, #0x10]
1005c6bb8: f84e03e6    	ldur	x6, [sp, #0xe0]
1005c6bbc: f9000ccf    	str	x15, [x6, #0x18]
1005c6bc0: f967da60    	ldr	x0, [x19, #0x4fb0]
1005c6bc4: f84e03e9    	ldur	x9, [sp, #0xe0]
1005c6bc8: f9002920    	str	x0, [x9, #0x50]
1005c6bcc: f967de60    	ldr	x0, [x19, #0x4fb8]
1005c6bd0: f84e03ec    	ldur	x12, [sp, #0xe0]
1005c6bd4: f9002d80    	str	x0, [x12, #0x58]
1005c6bd8: f9680260    	ldr	x0, [x19, #0x5000]
1005c6bdc: f84e03ef    	ldur	x15, [sp, #0xe0]
1005c6be0: f90051e0    	str	x0, [x15, #0xa0]
1005c6be4: f9680660    	ldr	x0, [x19, #0x5008]
1005c6be8: f9005420    	str	x0, [x1, #0xa8]
1005c6bec: f9680a60    	ldr	x0, [x19, #0x5010]
1005c6bf0: f9005820    	str	x0, [x1, #0xb0]
1005c6bf4: f9683a60    	ldr	x0, [x19, #0x5070]
1005c6bf8: f9008820    	str	x0, [x1, #0x110]
1005c6bfc: f9683e60    	ldr	x0, [x19, #0x5078]
1005c6c00: f9008c20    	str	x0, [x1, #0x118]
1005c6c04: f9684260    	ldr	x0, [x19, #0x5080]
1005c6c08: f9009020    	str	x0, [x1, #0x120]
1005c6c0c: f9684660    	ldr	x0, [x19, #0x5088]
1005c6c10: f9009420    	str	x0, [x1, #0x128]
1005c6c14: f968de60    	ldr	x0, [x19, #0x51b8]
1005c6c18: f9012c20    	str	x0, [x1, #0x258]
1005c6c1c: f968e260    	ldr	x0, [x19, #0x51c0]
1005c6c20: f9013020    	str	x0, [x1, #0x260]
1005c6c24: f968e660    	ldr	x0, [x19, #0x51c8]
1005c6c28: f9013420    	str	x0, [x1, #0x268]
1005c6c2c: f968ea60    	ldr	x0, [x19, #0x51d0]
1005c6c30: f9013820    	str	x0, [x1, #0x270]
1005c6c34: f968ee60    	ldr	x0, [x19, #0x51d8]
1005c6c38: f9013c20    	str	x0, [x1, #0x278]
1005c6c3c: f968f260    	ldr	x0, [x19, #0x51e0]
1005c6c40: f9014020    	str	x0, [x1, #0x280]
1005c6c44: d2800000    	mov	x0, #0x0                ; =0
1005c6c48: f9014420    	str	x0, [x1, #0x288]
1005c6c4c: f968fa61    	ldr	x1, [x19, #0x51f0]
1005c6c50: f9014841    	str	x1, [x2, #0x290]
1005c6c54: f968fe61    	ldr	x1, [x19, #0x51f8]
1005c6c58: f9014c41    	str	x1, [x2, #0x298]
1005c6c5c: f84e03e1    	ldur	x1, [sp, #0xe0]
1005c6c60: f9015020    	str	x0, [x1, #0x2a0]
1005c6c64: f9690660    	ldr	x0, [x19, #0x5208]
1005c6c68: f9015440    	str	x0, [x2, #0x2a8]
1005c6c6c: f9690a60    	ldr	x0, [x19, #0x5210]
1005c6c70: f90158a0    	str	x0, [x5, #0x2b0]
1005c6c74: d2802b41    	mov	x1, #0x15a              ; =346
1005c6c78: 92800102    	mov	x2, #-0x9               ; =-9
1005c6c7c: f84f03e7    	ldur	x7, [sp, #0xf0]
1005c6c80: f84003e0    	ldur	x0, [sp]
1005c6c84: f84903e5    	ldur	x5, [sp, #0x90]
1005c6c88: f84e83e6    	ldur	x6, [sp, #0xe8]
1005c6c8c: d63f00e0    	blr	x7
1005c6c90: f100001f    	cmp	x0, #0x0
1005c6c94: 54007221    	b.ne	0x1005c7ad8 <_mech_canonical_program_entry_v1_numeric_256+0x1fd8>
1005c6c98: d2800060    	mov	x0, #0x3                ; =3
1005c6c9c: f84d83e8    	ldur	x8, [sp, #0xd8]
1005c6ca0: f80703e0    	stur	x0, [sp, #0x70]
1005c6ca4: f100091f    	cmp	x8, #0x2
1005c6ca8: 5400e143    	b.lo	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c6cac: d2800005    	mov	x5, #0x0                ; =0
1005c6cb0: f84e03e3    	ldur	x3, [sp, #0xe0]
1005c6cb4: f9000065    	str	x5, [x3]
1005c6cb8: f943da60    	ldr	x0, [x19, #0x7b0]
1005c6cbc: f9000460    	str	x0, [x3, #0x8]
1005c6cc0: d2802b41    	mov	x1, #0x15a              ; =346
1005c6cc4: f84003e0    	ldur	x0, [sp]
1005c6cc8: f84e83e6    	ldur	x6, [sp, #0xe8]
1005c6ccc: f84f03e7    	ldur	x7, [sp, #0xf0]
1005c6cd0: f84903e4    	ldur	x4, [sp, #0x90]
1005c6cd4: aa0503e2    	mov	x2, x5
1005c6cd8: d63f00e0    	blr	x7
1005c6cdc: f100001f    	cmp	x0, #0x0
1005c6ce0: 54007021    	b.ne	0x1005c7ae4 <_mech_canonical_program_entry_v1_numeric_256+0x1fe4>
1005c6ce4: d2800060    	mov	x0, #0x3                ; =3
1005c6ce8: f80703e0    	stur	x0, [sp, #0x70]
1005c6cec: 140006f9    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c6cf0: f84b03ea    	ldur	x10, [sp, #0xb0]
1005c6cf4: f87c794b    	ldr	x11, [x10, x28, lsl #3]
1005c6cf8: eb0f02df    	cmp	x22, x15
1005c6cfc: 54000d03    	b.lo	0x1005c6e9c <_mech_canonical_program_entry_v1_numeric_256+0x139c>
1005c6d00: 1400037c    	b	0x1005c7af0 <_mech_canonical_program_entry_v1_numeric_256+0x1ff0>
1005c6d04: f9655263    	ldr	x3, [x19, #0x4aa0]
1005c6d08: f9655664    	ldr	x4, [x19, #0x4aa8]
1005c6d0c: d2800000    	mov	x0, #0x0                ; =0
1005c6d10: f9254e60    	str	x0, [x19, #0x4a98]
1005c6d14: d2800060    	mov	x0, #0x3                ; =3
1005c6d18: f84d83e8    	ldur	x8, [sp, #0xd8]
1005c6d1c: f80703e0    	stur	x0, [sp, #0x70]
1005c6d20: f101611f    	cmp	x8, #0x58
1005c6d24: 5400dd63    	b.lo	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c6d28: f967ba60    	ldr	x0, [x19, #0x4f70]
1005c6d2c: f84e03e1    	ldur	x1, [sp, #0xe0]
1005c6d30: f9000820    	str	x0, [x1, #0x10]
1005c6d34: f967be61    	ldr	x1, [x19, #0x4f78]
1005c6d38: f84e03e2    	ldur	x2, [sp, #0xe0]
1005c6d3c: f9000c41    	str	x1, [x2, #0x18]
1005c6d40: f9688a62    	ldr	x2, [x19, #0x5110]
1005c6d44: f84e03e5    	ldur	x5, [sp, #0xe0]
1005c6d48: f900d8a2    	str	x2, [x5, #0x1b0]
1005c6d4c: f9689a62    	ldr	x2, [x19, #0x5130]
1005c6d50: f900e8a2    	str	x2, [x5, #0x1d0]
1005c6d54: f84e03e2    	ldur	x2, [sp, #0xe0]
1005c6d58: f9000840    	str	x0, [x2, #0x10]
1005c6d5c: f84e03e0    	ldur	x0, [sp, #0xe0]
1005c6d60: f9000c01    	str	x1, [x0, #0x18]
1005c6d64: f967da60    	ldr	x0, [x19, #0x4fb0]
1005c6d68: f90028a0    	str	x0, [x5, #0x50]
1005c6d6c: f967de60    	ldr	x0, [x19, #0x4fb8]
1005c6d70: f84e03e6    	ldur	x6, [sp, #0xe0]
1005c6d74: f9002cc0    	str	x0, [x6, #0x58]
1005c6d78: f9680260    	ldr	x0, [x19, #0x5000]
1005c6d7c: f84e03e9    	ldur	x9, [sp, #0xe0]
1005c6d80: f9005120    	str	x0, [x9, #0xa0]
1005c6d84: f9680660    	ldr	x0, [x19, #0x5008]
1005c6d88: f84e03ec    	ldur	x12, [sp, #0xe0]
1005c6d8c: f9005580    	str	x0, [x12, #0xa8]
1005c6d90: f9680a60    	ldr	x0, [x19, #0x5010]
1005c6d94: f84e03ef    	ldur	x15, [sp, #0xe0]
1005c6d98: f90059e0    	str	x0, [x15, #0xb0]
1005c6d9c: f9683a60    	ldr	x0, [x19, #0x5070]
1005c6da0: f84e03e1    	ldur	x1, [sp, #0xe0]
1005c6da4: f9008820    	str	x0, [x1, #0x110]
1005c6da8: f9683e61    	ldr	x1, [x19, #0x5078]
1005c6dac: f84e03e0    	ldur	x0, [sp, #0xe0]
1005c6db0: f9008c01    	str	x1, [x0, #0x118]
1005c6db4: f9684262    	ldr	x2, [x19, #0x5080]
1005c6db8: f9009002    	str	x2, [x0, #0x120]
1005c6dbc: f9684665    	ldr	x5, [x19, #0x5088]
1005c6dc0: f9009405    	str	x5, [x0, #0x128]
1005c6dc4: f968de65    	ldr	x5, [x19, #0x51b8]
1005c6dc8: f9012c05    	str	x5, [x0, #0x258]
1005c6dcc: f968e265    	ldr	x5, [x19, #0x51c0]
1005c6dd0: f9013005    	str	x5, [x0, #0x260]
1005c6dd4: f968e666    	ldr	x6, [x19, #0x51c8]
1005c6dd8: f9013406    	str	x6, [x0, #0x268]
1005c6ddc: f968ea67    	ldr	x7, [x19, #0x51d0]
1005c6de0: f9013807    	str	x7, [x0, #0x270]
1005c6de4: f968ee68    	ldr	x8, [x19, #0x51d8]
1005c6de8: f9013c08    	str	x8, [x0, #0x278]
1005c6dec: f968f269    	ldr	x9, [x19, #0x51e0]
1005c6df0: f9014009    	str	x9, [x0, #0x280]
1005c6df4: d280000a    	mov	x10, #0x0               ; =0
1005c6df8: f901440a    	str	x10, [x0, #0x288]
1005c6dfc: f968fa6b    	ldr	x11, [x19, #0x51f0]
1005c6e00: f901480b    	str	x11, [x0, #0x290]
1005c6e04: f968fe6c    	ldr	x12, [x19, #0x51f8]
1005c6e08: f9014c0c    	str	x12, [x0, #0x298]
1005c6e0c: f901500a    	str	x10, [x0, #0x2a0]
1005c6e10: f969066e    	ldr	x14, [x19, #0x5208]
1005c6e14: f901540e    	str	x14, [x0, #0x2a8]
1005c6e18: f9690a6f    	ldr	x15, [x19, #0x5210]
1005c6e1c: f901580f    	str	x15, [x0, #0x2b0]
1005c6e20: d2802b81    	mov	x1, #0x15c              ; =348
1005c6e24: 92800102    	mov	x2, #-0x9               ; =-9
1005c6e28: f84f03e7    	ldur	x7, [sp, #0xf0]
1005c6e2c: f84003e0    	ldur	x0, [sp]
1005c6e30: f84903e5    	ldur	x5, [sp, #0x90]
1005c6e34: f84e83e6    	ldur	x6, [sp, #0xe8]
1005c6e38: d63f00e0    	blr	x7
1005c6e3c: f100001f    	cmp	x0, #0x0
1005c6e40: 54006f01    	b.ne	0x1005c7c20 <_mech_canonical_program_entry_v1_numeric_256+0x2120>
1005c6e44: d2800060    	mov	x0, #0x3                ; =3
1005c6e48: f84d83e8    	ldur	x8, [sp, #0xd8]
1005c6e4c: f80703e0    	stur	x0, [sp, #0x70]
1005c6e50: f100091f    	cmp	x8, #0x2
1005c6e54: 5400d3e3    	b.lo	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c6e58: d2800005    	mov	x5, #0x0                ; =0
1005c6e5c: f84e03e3    	ldur	x3, [sp, #0xe0]
1005c6e60: f9000065    	str	x5, [x3]
1005c6e64: f943e260    	ldr	x0, [x19, #0x7c0]
1005c6e68: f9000460    	str	x0, [x3, #0x8]
1005c6e6c: d2802b81    	mov	x1, #0x15c              ; =348
1005c6e70: f84003e0    	ldur	x0, [sp]
1005c6e74: f84e83e6    	ldur	x6, [sp, #0xe8]
1005c6e78: f84f03e7    	ldur	x7, [sp, #0xf0]
1005c6e7c: f84903e4    	ldur	x4, [sp, #0x90]
1005c6e80: aa0503e2    	mov	x2, x5
1005c6e84: d63f00e0    	blr	x7
1005c6e88: f100001f    	cmp	x0, #0x0
1005c6e8c: 54006d01    	b.ne	0x1005c7c2c <_mech_canonical_program_entry_v1_numeric_256+0x212c>
1005c6e90: d2800060    	mov	x0, #0x3                ; =3
1005c6e94: f80703e0    	stur	x0, [sp, #0x70]
1005c6e98: 1400068e    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c6e9c: f8767948    	ldr	x8, [x10, x22, lsl #3]
1005c6ea0: eb0f02bf    	cmp	x21, x15
1005c6ea4: f80a83ef    	stur	x15, [sp, #0xa8]
1005c6ea8: 54000ce3    	b.lo	0x1005c7044 <_mech_canonical_program_entry_v1_numeric_256+0x1544>
1005c6eac: 14000363    	b	0x1005c7c38 <_mech_canonical_program_entry_v1_numeric_256+0x2138>
1005c6eb0: f9655263    	ldr	x3, [x19, #0x4aa0]
1005c6eb4: f9655664    	ldr	x4, [x19, #0x4aa8]
1005c6eb8: d2800000    	mov	x0, #0x0                ; =0
1005c6ebc: f9254e60    	str	x0, [x19, #0x4a98]
1005c6ec0: d2800060    	mov	x0, #0x3                ; =3
1005c6ec4: f84d83e8    	ldur	x8, [sp, #0xd8]
1005c6ec8: f80703e0    	stur	x0, [sp, #0x70]
1005c6ecc: f101611f    	cmp	x8, #0x58
1005c6ed0: 5400d003    	b.lo	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c6ed4: f967ba60    	ldr	x0, [x19, #0x4f70]
1005c6ed8: f84e03e1    	ldur	x1, [sp, #0xe0]
1005c6edc: f9000820    	str	x0, [x1, #0x10]
1005c6ee0: f967be61    	ldr	x1, [x19, #0x4f78]
1005c6ee4: f84e03e2    	ldur	x2, [sp, #0xe0]
1005c6ee8: f9000c41    	str	x1, [x2, #0x18]
1005c6eec: f9688a62    	ldr	x2, [x19, #0x5110]
1005c6ef0: f84e03e5    	ldur	x5, [sp, #0xe0]
1005c6ef4: f900d8a2    	str	x2, [x5, #0x1b0]
1005c6ef8: f9689a62    	ldr	x2, [x19, #0x5130]
1005c6efc: f900e8a2    	str	x2, [x5, #0x1d0]
1005c6f00: f84e03e2    	ldur	x2, [sp, #0xe0]
1005c6f04: f9000840    	str	x0, [x2, #0x10]
1005c6f08: f84e03e0    	ldur	x0, [sp, #0xe0]
1005c6f0c: f9000c01    	str	x1, [x0, #0x18]
1005c6f10: f967da60    	ldr	x0, [x19, #0x4fb0]
1005c6f14: f84e03e1    	ldur	x1, [sp, #0xe0]
1005c6f18: f9002820    	str	x0, [x1, #0x50]
1005c6f1c: f967de60    	ldr	x0, [x19, #0x4fb8]
1005c6f20: f9002c40    	str	x0, [x2, #0x58]
1005c6f24: f9680260    	ldr	x0, [x19, #0x5000]
1005c6f28: f90050a0    	str	x0, [x5, #0xa0]
1005c6f2c: f9680660    	ldr	x0, [x19, #0x5008]
1005c6f30: f84e03e8    	ldur	x8, [sp, #0xe0]
1005c6f34: f9005500    	str	x0, [x8, #0xa8]
1005c6f38: f9680a60    	ldr	x0, [x19, #0x5010]
1005c6f3c: f84e03eb    	ldur	x11, [sp, #0xe0]
1005c6f40: f9005960    	str	x0, [x11, #0xb0]
1005c6f44: f9683a60    	ldr	x0, [x19, #0x5070]
1005c6f48: f84e03ee    	ldur	x14, [sp, #0xe0]
1005c6f4c: f90089c0    	str	x0, [x14, #0x110]
1005c6f50: f9683e60    	ldr	x0, [x19, #0x5078]
1005c6f54: f9008c20    	str	x0, [x1, #0x118]
1005c6f58: f9684260    	ldr	x0, [x19, #0x5080]
1005c6f5c: f9009020    	str	x0, [x1, #0x120]
1005c6f60: f9684660    	ldr	x0, [x19, #0x5088]
1005c6f64: f9009420    	str	x0, [x1, #0x128]
1005c6f68: f968de60    	ldr	x0, [x19, #0x51b8]
1005c6f6c: f9012c20    	str	x0, [x1, #0x258]
1005c6f70: f968e260    	ldr	x0, [x19, #0x51c0]
1005c6f74: f9013020    	str	x0, [x1, #0x260]
1005c6f78: f968e660    	ldr	x0, [x19, #0x51c8]
1005c6f7c: f9013420    	str	x0, [x1, #0x268]
1005c6f80: f968ea60    	ldr	x0, [x19, #0x51d0]
1005c6f84: f9013820    	str	x0, [x1, #0x270]
1005c6f88: f968ee60    	ldr	x0, [x19, #0x51d8]
1005c6f8c: f9013c20    	str	x0, [x1, #0x278]
1005c6f90: f968f260    	ldr	x0, [x19, #0x51e0]
1005c6f94: f9014020    	str	x0, [x1, #0x280]
1005c6f98: d2800000    	mov	x0, #0x0                ; =0
1005c6f9c: f9014420    	str	x0, [x1, #0x288]
1005c6fa0: f968fa61    	ldr	x1, [x19, #0x51f0]
1005c6fa4: f9014841    	str	x1, [x2, #0x290]
1005c6fa8: f968fe61    	ldr	x1, [x19, #0x51f8]
1005c6fac: f9014c41    	str	x1, [x2, #0x298]
1005c6fb0: f84e03e1    	ldur	x1, [sp, #0xe0]
1005c6fb4: f9015020    	str	x0, [x1, #0x2a0]
1005c6fb8: f9690660    	ldr	x0, [x19, #0x5208]
1005c6fbc: f9015420    	str	x0, [x1, #0x2a8]
1005c6fc0: f9690a60    	ldr	x0, [x19, #0x5210]
1005c6fc4: f9015820    	str	x0, [x1, #0x2b0]
1005c6fc8: d2802bc1    	mov	x1, #0x15e              ; =350
1005c6fcc: 92800102    	mov	x2, #-0x9               ; =-9
1005c6fd0: f84f03e7    	ldur	x7, [sp, #0xf0]
1005c6fd4: f84003e0    	ldur	x0, [sp]
1005c6fd8: f84903e5    	ldur	x5, [sp, #0x90]
1005c6fdc: f84e83e6    	ldur	x6, [sp, #0xe8]
1005c6fe0: d63f00e0    	blr	x7
1005c6fe4: f100001f    	cmp	x0, #0x0
1005c6fe8: 54006c21    	b.ne	0x1005c7d6c <_mech_canonical_program_entry_v1_numeric_256+0x226c>
1005c6fec: d2800060    	mov	x0, #0x3                ; =3
1005c6ff0: f84d83e8    	ldur	x8, [sp, #0xd8]
1005c6ff4: f80703e0    	stur	x0, [sp, #0x70]
1005c6ff8: f100091f    	cmp	x8, #0x2
1005c6ffc: 5400c6a3    	b.lo	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c7000: d2800005    	mov	x5, #0x0                ; =0
1005c7004: f84e03e3    	ldur	x3, [sp, #0xe0]
1005c7008: f9000065    	str	x5, [x3]
1005c700c: f943ea60    	ldr	x0, [x19, #0x7d0]
1005c7010: f9000460    	str	x0, [x3, #0x8]
1005c7014: d2802bc1    	mov	x1, #0x15e              ; =350
1005c7018: f84003e0    	ldur	x0, [sp]
1005c701c: f84e83e6    	ldur	x6, [sp, #0xe8]
1005c7020: f84f03e7    	ldur	x7, [sp, #0xf0]
1005c7024: f84903e4    	ldur	x4, [sp, #0x90]
1005c7028: aa0503e2    	mov	x2, x5
1005c702c: d63f00e0    	blr	x7
1005c7030: f100001f    	cmp	x0, #0x0
1005c7034: 54006a21    	b.ne	0x1005c7d78 <_mech_canonical_program_entry_v1_numeric_256+0x2278>
1005c7038: d2800060    	mov	x0, #0x3                ; =3
1005c703c: f80703e0    	stur	x0, [sp, #0x70]
1005c7040: 14000624    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c7044: f875794f    	ldr	x15, [x10, x21, lsl #3]
1005c7048: f80b03ea    	stur	x10, [sp, #0xb0]
1005c704c: f100011f    	cmp	x8, #0x0
1005c7050: 540069a0    	b.eq	0x1005c7d84 <_mech_canonical_program_entry_v1_numeric_256+0x2284>
1005c7054: d100050a    	sub	x10, x8, #0x1
1005c7058: 9bca7d05    	umulh	x5, x8, x10
1005c705c: f10000bf    	cmp	x5, #0x0
1005c7060: 54007101    	b.ne	0x1005c7e80 <_mech_canonical_program_entry_v1_numeric_256+0x2380>
1005c7064: 9b0a7d05    	mul	x5, x8, x10
1005c7068: d341fcaa    	lsr	x10, x5, #1
1005c706c: 8b0a0168    	add	x8, x11, x10
1005c7070: eb0b011f    	cmp	x8, x11
1005c7074: 54007883    	b.lo	0x1005c7f84 <_mech_canonical_program_entry_v1_numeric_256+0x2484>
1005c7078: f10001ff    	cmp	x15, #0x0
1005c707c: 54008040    	b.eq	0x1005c8084 <_mech_canonical_program_entry_v1_numeric_256+0x2584>
1005c7080: d10005eb    	sub	x11, x15, #0x1
1005c7084: 9bcb7de5    	umulh	x5, x15, x11
1005c7088: f10000bf    	cmp	x5, #0x0
1005c708c: 540087a1    	b.ne	0x1005c8180 <_mech_canonical_program_entry_v1_numeric_256+0x2680>
1005c7090: f10009ff    	cmp	x15, #0x2
1005c7094: 54008f63    	b.lo	0x1005c8280 <_mech_canonical_program_entry_v1_numeric_256+0x2780>
1005c7098: 9b0b7dea    	mul	x10, x15, x11
1005c709c: d10009e5    	sub	x5, x15, #0x2
1005c70a0: 9bc57d45    	umulh	x5, x10, x5
1005c70a4: f10000bf    	cmp	x5, #0x0
1005c70a8: 540096e1    	b.ne	0x1005c8384 <_mech_canonical_program_entry_v1_numeric_256+0x2884>
1005c70ac: d10009e5    	sub	x5, x15, #0x2
1005c70b0: 9b057d45    	mul	x5, x10, x5
1005c70b4: d295556a    	mov	x10, #0xaaab            ; =43691
1005c70b8: f2b5554a    	movk	x10, #0xaaaa, lsl #16
1005c70bc: f2d5554a    	movk	x10, #0xaaaa, lsl #32
1005c70c0: f2f5554a    	movk	x10, #0xaaaa, lsl #48
1005c70c4: 9bca7ca5    	umulh	x5, x5, x10
1005c70c8: d342fcaa    	lsr	x10, x5, #2
1005c70cc: 8b0a010b    	add	x11, x8, x10
1005c70d0: eb08017f    	cmp	x11, x8
1005c70d4: 54009da3    	b.lo	0x1005c8488 <_mech_canonical_program_entry_v1_numeric_256+0x2988>
1005c70d8: f84403e8    	ldur	x8, [sp, #0x40]
1005c70dc: b5000ce8    	cbnz	x8, 0x1005c7278 <_mech_canonical_program_entry_v1_numeric_256+0x1778>
1005c70e0: 14000529    	b	0x1005c8584 <_mech_canonical_program_entry_v1_numeric_256+0x2a84>
1005c70e4: f84e03e5    	ldur	x5, [sp, #0xe0]
1005c70e8: f90008ba    	str	x26, [x5, #0x10]
1005c70ec: f9000cb9    	str	x25, [x5, #0x18]
1005c70f0: f90008ba    	str	x26, [x5, #0x10]
1005c70f4: f84e03e8    	ldur	x8, [sp, #0xe0]
1005c70f8: f9000d19    	str	x25, [x8, #0x18]
1005c70fc: f84e03ea    	ldur	x10, [sp, #0xe0]
1005c7100: f900295c    	str	x28, [x10, #0x50]
1005c7104: f84e03ed    	ldur	x13, [sp, #0xe0]
1005c7108: f9002dbb    	str	x27, [x13, #0x58]
1005c710c: f90051bc    	str	x28, [x13, #0xa0]
1005c7110: f84e03ef    	ldur	x15, [sp, #0xe0]
1005c7114: f90055f6    	str	x22, [x15, #0xa8]
1005c7118: f84e03e0    	ldur	x0, [sp, #0xe0]
1005c711c: f900581b    	str	x27, [x0, #0xb0]
1005c7120: f900881c    	str	x28, [x0, #0x110]
1005c7124: f9008c16    	str	x22, [x0, #0x118]
1005c7128: f9009015    	str	x21, [x0, #0x120]
1005c712c: f900941b    	str	x27, [x0, #0x128]
1005c7130: f9012c0c    	str	x12, [x0, #0x258]
1005c7134: f9013002    	str	x2, [x0, #0x260]
1005c7138: f9013401    	str	x1, [x0, #0x268]
1005c713c: d29bbe00    	mov	x0, #0xddf0             ; =56816
1005c7140: cb000063    	sub	x3, x3, x0
1005c7144: f84103e5    	ldur	x5, [sp, #0x10]
1005c7148: cb0300a0    	sub	x0, x5, x3
1005c714c: d29d1501    	mov	x1, #0xe8a8             ; =59560
1005c7150: 9b018180    	msub	x0, x12, x1, x0
1005c7154: f84e03e1    	ldur	x1, [sp, #0xe0]
1005c7158: f9013820    	str	x0, [x1, #0x270]
1005c715c: f84183e0    	ldur	x0, [sp, #0x18]
1005c7160: f9013c20    	str	x0, [x1, #0x278]
1005c7164: f84e03e0    	ldur	x0, [sp, #0xe0]
1005c7168: f84203ed    	ldur	x13, [sp, #0x20]
1005c716c: f901400d    	str	x13, [x0, #0x280]
1005c7170: d2800005    	mov	x5, #0x0                ; =0
1005c7174: f9014405    	str	x5, [x0, #0x288]
1005c7178: f84283e2    	ldur	x2, [sp, #0x28]
1005c717c: f9014802    	str	x2, [x0, #0x290]
1005c7180: f84303ea    	ldur	x10, [sp, #0x30]
1005c7184: f9014c0a    	str	x10, [x0, #0x298]
1005c7188: f9015005    	str	x5, [x0, #0x2a0]
1005c718c: f9015409    	str	x9, [x0, #0x2a8]
1005c7190: f9015807    	str	x7, [x0, #0x2b0]
1005c7194: f84083e0    	ldur	x0, [sp, #0x8]
1005c7198: 91000406    	add	x6, x0, #0x1
1005c719c: f84e03e0    	ldur	x0, [sp, #0xe0]
1005c71a0: f9016006    	str	x6, [x0, #0x2c0]
1005c71a4: f901640b    	str	x11, [x0, #0x2c8]
1005c71a8: d2802d21    	mov	x1, #0x169              ; =361
1005c71ac: 92800342    	mov	x2, #-0x1b              ; =-27
1005c71b0: f84f03e7    	ldur	x7, [sp, #0xf0]
1005c71b4: f84003e0    	ldur	x0, [sp]
1005c71b8: f84e83e6    	ldur	x6, [sp, #0xe8]
1005c71bc: d63f00e0    	blr	x7
1005c71c0: f100001f    	cmp	x0, #0x0
1005c71c4: 54009f41    	b.ne	0x1005c85ac <_mech_canonical_program_entry_v1_numeric_256+0x2aac>
1005c71c8: f84e03e3    	ldur	x3, [sp, #0xe0]
1005c71cc: f9400063    	ldr	x3, [x3]
1005c71d0: f84e03e7    	ldur	x7, [sp, #0xe0]
1005c71d4: f94004e4    	ldr	x4, [x7, #0x8]
1005c71d8: f84e03e9    	ldur	x9, [sp, #0xe0]
1005c71dc: f940e52e    	ldr	x14, [x9, #0x1c8]
1005c71e0: f84e03eb    	ldur	x11, [sp, #0xe0]
1005c71e4: f9411968    	ldr	x8, [x11, #0x230]
1005c71e8: f84e03ed    	ldur	x13, [sp, #0xe0]
1005c71ec: f80403e8    	stur	x8, [sp, #0x40]
1005c71f0: f940e9a5    	ldr	x5, [x13, #0x1d0]
1005c71f4: f84e03ef    	ldur	x15, [sp, #0xe0]
1005c71f8: f80083e5    	stur	x5, [sp, #0x8]
1005c71fc: f940edeb    	ldr	x11, [x15, #0x1d8]
1005c7200: f84e03e0    	ldur	x0, [sp, #0xe0]
1005c7204: f940f00b    	ldr	x11, [x0, #0x1e0]
1005c7208: f941280d    	ldr	x13, [x0, #0x250]
1005c720c: f80383ed    	stur	x13, [sp, #0x38]
1005c7210: f9412c0c    	ldr	x12, [x0, #0x258]
1005c7214: f9413002    	ldr	x2, [x0, #0x260]
1005c7218: f9413401    	ldr	x1, [x0, #0x268]
1005c721c: f941380b    	ldr	x11, [x0, #0x270]
1005c7220: f9413c00    	ldr	x0, [x0, #0x278]
1005c7224: f80183e0    	stur	x0, [sp, #0x18]
1005c7228: f84e03e0    	ldur	x0, [sp, #0xe0]
1005c722c: f941400d    	ldr	x13, [x0, #0x280]
1005c7230: f80203ed    	stur	x13, [sp, #0x20]
1005c7234: f9414800    	ldr	x0, [x0, #0x290]
1005c7238: f80283e0    	stur	x0, [sp, #0x28]
1005c723c: f84e03e0    	ldur	x0, [sp, #0xe0]
1005c7240: f9414c0a    	ldr	x10, [x0, #0x298]
1005c7244: f80303ea    	stur	x10, [sp, #0x30]
1005c7248: f9415409    	ldr	x9, [x0, #0x2a8]
1005c724c: f9415807    	ldr	x7, [x0, #0x2b0]
1005c7250: f9400800    	ldr	x0, [x0, #0x10]
1005c7254: d2800026    	mov	x6, #0x1                ; =1
1005c7258: f9254e66    	str	x6, [x19, #0x4a98]
1005c725c: 8b0b006d    	add	x13, x3, x11
1005c7260: d29d150f    	mov	x15, #0xe8a8            ; =59560
1005c7264: 9b0f3585    	madd	x5, x12, x15, x13
1005c7268: f80103e5    	stur	x5, [sp, #0x10]
1005c726c: aa1503e8    	mov	x8, x21
1005c7270: f80483ee    	stur	x14, [sp, #0x48]
1005c7274: 1400000b    	b	0x1005c72a0 <_mech_canonical_program_entry_v1_numeric_256+0x17a0>
1005c7278: f84083e5    	ldur	x5, [sp, #0x8]
1005c727c: f84483ee    	ldur	x14, [sp, #0x48]
1005c7280: f80383ed    	stur	x13, [sp, #0x38]
1005c7284: f80403e8    	stur	x8, [sp, #0x40]
1005c7288: f82579cb    	str	x11, [x14, x5, lsl #3]
1005c728c: 910004a5    	add	x5, x5, #0x1
1005c7290: f80083e5    	stur	x5, [sp, #0x8]
1005c7294: d29bbe0e    	mov	x14, #0xddf0            ; =56816
1005c7298: cb0e0063    	sub	x3, x3, x14
1005c729c: aa1503e8    	mov	x8, x21
1005c72a0: eb1b02bf    	cmp	x21, x27
1005c72a4: 54001a43    	b.lo	0x1005c75ec <_mech_canonical_program_entry_v1_numeric_256+0x1aec>
1005c72a8: d2800005    	mov	x5, #0x0                ; =0
1005c72ac: f901d805    	str	x5, [x0, #0x3b0]
1005c72b0: f901dc05    	str	x5, [x0, #0x3b8]
1005c72b4: f901e005    	str	x5, [x0, #0x3c0]
1005c72b8: f901e405    	str	x5, [x0, #0x3c8]
1005c72bc: f901e805    	str	x5, [x0, #0x3d0]
1005c72c0: f901ec05    	str	x5, [x0, #0x3d8]
1005c72c4: f901f005    	str	x5, [x0, #0x3e0]
1005c72c8: f901f405    	str	x5, [x0, #0x3e8]
1005c72cc: d2800009    	mov	x9, #0x0                ; =0
1005c72d0: aa0903e7    	mov	x7, x9
1005c72d4: f84783ea    	ldur	x10, [sp, #0x78]
1005c72d8: eb1b015f    	cmp	x10, x27
1005c72dc: 540016e3    	b.lo	0x1005c75b8 <_mech_canonical_program_entry_v1_numeric_256+0x1ab8>
1005c72e0: d2800005    	mov	x5, #0x0                ; =0
1005c72e4: f9016805    	str	x5, [x0, #0x2d0]
1005c72e8: f9016c05    	str	x5, [x0, #0x2d8]
1005c72ec: f9017005    	str	x5, [x0, #0x2e0]
1005c72f0: f9017405    	str	x5, [x0, #0x2e8]
1005c72f4: f9017805    	str	x5, [x0, #0x2f0]
1005c72f8: f9017c05    	str	x5, [x0, #0x2f8]
1005c72fc: d280000d    	mov	x13, #0x0               ; =0
1005c7300: aa0d03f6    	mov	x22, x13
1005c7304: f84883ea    	ldur	x10, [sp, #0x88]
1005c7308: eb1b015f    	cmp	x10, x27
1005c730c: 54001403    	b.lo	0x1005c758c <_mech_canonical_program_entry_v1_numeric_256+0x1a8c>
1005c7310: d2800005    	mov	x5, #0x0                ; =0
1005c7314: f9011805    	str	x5, [x0, #0x230]
1005c7318: f9011c05    	str	x5, [x0, #0x238]
1005c731c: f9012005    	str	x5, [x0, #0x240]
1005c7320: f9012405    	str	x5, [x0, #0x248]
1005c7324: d280000b    	mov	x11, #0x0               ; =0
1005c7328: aa0b03e8    	mov	x8, x11
1005c732c: aa1a03f5    	mov	x21, x26
1005c7330: aa1a03fb    	mov	x27, x26
1005c7334: eb19035f    	cmp	x26, x25
1005c7338: 54000083    	b.lo	0x1005c7348 <_mech_canonical_program_entry_v1_numeric_256+0x1848>
1005c733c: f84603ee    	ldur	x14, [sp, #0x60]
1005c7340: f84683ef    	ldur	x15, [sp, #0x68]
1005c7344: 1400005b    	b	0x1005c74b0 <_mech_canonical_program_entry_v1_numeric_256+0x19b0>
1005c7348: f84603ee    	ldur	x14, [sp, #0x60]
1005c734c: b5000a6e    	cbnz	x14, 0x1005c7498 <_mech_canonical_program_entry_v1_numeric_256+0x1998>
1005c7350: 1400049a    	b	0x1005c85b8 <_mech_canonical_program_entry_v1_numeric_256+0x2ab8>
1005c7354: f84e03e5    	ldur	x5, [sp, #0xe0]
1005c7358: f90008bb    	str	x27, [x5, #0x10]
1005c735c: f84e03e6    	ldur	x6, [sp, #0xe0]
1005c7360: f9000cd9    	str	x25, [x6, #0x18]
1005c7364: f84e03ea    	ldur	x10, [sp, #0xe0]
1005c7368: f900095b    	str	x27, [x10, #0x10]
1005c736c: f9000d59    	str	x25, [x10, #0x18]
1005c7370: f84e03ee    	ldur	x14, [sp, #0xe0]
1005c7374: f9012dcc    	str	x12, [x14, #0x258]
1005c7378: f90131c2    	str	x2, [x14, #0x260]
1005c737c: f84e03e0    	ldur	x0, [sp, #0xe0]
1005c7380: f9013401    	str	x1, [x0, #0x268]
1005c7384: f84103e5    	ldur	x5, [sp, #0x10]
1005c7388: cb0300a0    	sub	x0, x5, x3
1005c738c: d29d1501    	mov	x1, #0xe8a8             ; =59560
1005c7390: 9b018180    	msub	x0, x12, x1, x0
1005c7394: f84e03e1    	ldur	x1, [sp, #0xe0]
1005c7398: f9013820    	str	x0, [x1, #0x270]
1005c739c: f84e03e0    	ldur	x0, [sp, #0xe0]
1005c73a0: f9013c0b    	str	x11, [x0, #0x278]
1005c73a4: f9014008    	str	x8, [x0, #0x280]
1005c73a8: d2800005    	mov	x5, #0x0                ; =0
1005c73ac: f9014405    	str	x5, [x0, #0x288]
1005c73b0: f901480d    	str	x13, [x0, #0x290]
1005c73b4: f9014c16    	str	x22, [x0, #0x298]
1005c73b8: f9015005    	str	x5, [x0, #0x2a0]
1005c73bc: f9015409    	str	x9, [x0, #0x2a8]
1005c73c0: f9015807    	str	x7, [x0, #0x2b0]
1005c73c4: f84503e0    	ldur	x0, [sp, #0x50]
1005c73c8: 91000400    	add	x0, x0, #0x1
1005c73cc: f9016020    	str	x0, [x1, #0x2c0]
1005c73d0: f84e03e0    	ldur	x0, [sp, #0xe0]
1005c73d4: f84083f7    	ldur	x23, [sp, #0x8]
1005c73d8: f9016417    	str	x23, [x0, #0x2c8]
1005c73dc: d2803461    	mov	x1, #0x1a3              ; =419
1005c73e0: 92800342    	mov	x2, #-0x1b              ; =-27
1005c73e4: f84f03e7    	ldur	x7, [sp, #0xf0]
1005c73e8: f84003e0    	ldur	x0, [sp]
1005c73ec: f84e83e6    	ldur	x6, [sp, #0xe8]
1005c73f0: d63f00e0    	blr	x7
1005c73f4: d280004e    	mov	x14, #0x2               ; =2
1005c73f8: f80703ee    	stur	x14, [sp, #0x70]
1005c73fc: f100001f    	cmp	x0, #0x0
1005c7400: 5400a681    	b.ne	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c7404: f84e03e3    	ldur	x3, [sp, #0xe0]
1005c7408: f9400063    	ldr	x3, [x3]
1005c740c: f84e03e0    	ldur	x0, [sp, #0xe0]
1005c7410: f9400404    	ldr	x4, [x0, #0x8]
1005c7414: f940d40f    	ldr	x15, [x0, #0x1a8]
1005c7418: f941140e    	ldr	x14, [x0, #0x228]
1005c741c: f940d80b    	ldr	x11, [x0, #0x1b0]
1005c7420: f80503eb    	stur	x11, [sp, #0x50]
1005c7424: f940dc00    	ldr	x0, [x0, #0x1b8]
1005c7428: f84e03e1    	ldur	x1, [sp, #0xe0]
1005c742c: f940e020    	ldr	x0, [x1, #0x1c0]
1005c7430: f84e03e5    	ldur	x5, [sp, #0xe0]
1005c7434: f94124a8    	ldr	x8, [x5, #0x248]
1005c7438: f80583e8    	stur	x8, [sp, #0x58]
1005c743c: f9412cac    	ldr	x12, [x5, #0x258]
1005c7440: f84e03e7    	ldur	x7, [sp, #0xe0]
1005c7444: f94130e2    	ldr	x2, [x7, #0x260]
1005c7448: f84e03e9    	ldur	x9, [sp, #0xe0]
1005c744c: f9413521    	ldr	x1, [x9, #0x268]
1005c7450: f84e03eb    	ldur	x11, [sp, #0xe0]
1005c7454: f9413965    	ldr	x5, [x11, #0x270]
1005c7458: f84e03ed    	ldur	x13, [sp, #0xe0]
1005c745c: f9413dab    	ldr	x11, [x13, #0x278]
1005c7460: f84e03e0    	ldur	x0, [sp, #0xe0]
1005c7464: f9414008    	ldr	x8, [x0, #0x280]
1005c7468: f941480d    	ldr	x13, [x0, #0x290]
1005c746c: f9414c16    	ldr	x22, [x0, #0x298]
1005c7470: f9415409    	ldr	x9, [x0, #0x2a8]
1005c7474: f9415807    	ldr	x7, [x0, #0x2b0]
1005c7478: f9400800    	ldr	x0, [x0, #0x10]
1005c747c: d2800026    	mov	x6, #0x1                ; =1
1005c7480: f9254e66    	str	x6, [x19, #0x4a98]
1005c7484: 8b050065    	add	x5, x3, x5
1005c7488: d29d150a    	mov	x10, #0xe8a8            ; =59560
1005c748c: 9b0a1585    	madd	x5, x12, x10, x5
1005c7490: f80103e5    	stur	x5, [sp, #0x10]
1005c7494: 14000007    	b	0x1005c74b0 <_mech_canonical_program_entry_v1_numeric_256+0x19b0>
1005c7498: f84503e5    	ldur	x5, [sp, #0x50]
1005c749c: f84683ef    	ldur	x15, [sp, #0x68]
1005c74a0: f84083f7    	ldur	x23, [sp, #0x8]
1005c74a4: f82579f7    	str	x23, [x15, x5, lsl #3]
1005c74a8: 910004a5    	add	x5, x5, #0x1
1005c74ac: f80503e5    	stur	x5, [sp, #0x50]
1005c74b0: eb19035f    	cmp	x26, x25
1005c74b4: 54000563    	b.lo	0x1005c7560 <_mech_canonical_program_entry_v1_numeric_256+0x1a60>
1005c74b8: d2800020    	mov	x0, #0x1                ; =1
1005c74bc: f9001a60    	str	x0, [x19, #0x30]
1005c74c0: d2800045    	mov	x5, #0x2                ; =2
1005c74c4: f9002265    	str	x5, [x19, #0x40]
1005c74c8: d28000c5    	mov	x5, #0x6                ; =6
1005c74cc: f9003265    	str	x5, [x19, #0x60]
1005c74d0: d2800005    	mov	x5, #0x0                ; =0
1005c74d4: f900c665    	str	x5, [x19, #0x188]
1005c74d8: f900ca60    	str	x0, [x19, #0x190]
1005c74dc: f9254e66    	str	x6, [x19, #0x4a98]
1005c74e0: f9255263    	str	x3, [x19, #0x4aa0]
1005c74e4: f9255664    	str	x4, [x19, #0x4aa8]
1005c74e8: f927ba7b    	str	x27, [x19, #0x4f70]
1005c74ec: f927be79    	str	x25, [x19, #0x4f78]
1005c74f0: f84503f4    	ldur	x20, [sp, #0x50]
1005c74f4: f9288a74    	str	x20, [x19, #0x5110]
1005c74f8: f84083f7    	ldur	x23, [sp, #0x8]
1005c74fc: f9289a77    	str	x23, [x19, #0x5130]
1005c7500: f928de6c    	str	x12, [x19, #0x51b8]
1005c7504: f928e262    	str	x2, [x19, #0x51c0]
1005c7508: f928e661    	str	x1, [x19, #0x51c8]
1005c750c: f84103e5    	ldur	x5, [sp, #0x10]
1005c7510: cb0300aa    	sub	x10, x5, x3
1005c7514: d29d150e    	mov	x14, #0xe8a8            ; =59560
1005c7518: 9b0ea98a    	msub	x10, x12, x14, x10
1005c751c: f928ea6a    	str	x10, [x19, #0x51d0]
1005c7520: f928ee6b    	str	x11, [x19, #0x51d8]
1005c7524: f928f268    	str	x8, [x19, #0x51e0]
1005c7528: f928fa6d    	str	x13, [x19, #0x51f0]
1005c752c: f928fe76    	str	x22, [x19, #0x51f8]
1005c7530: f9290669    	str	x9, [x19, #0x5208]
1005c7534: f9290a67    	str	x7, [x19, #0x5210]
1005c7538: d2800000    	mov	x0, #0x0                ; =0
1005c753c: d2800021    	mov	x1, #0x1                ; =1
1005c7540: 910403ff    	add	sp, sp, #0x100
1005c7544: a8c153f3    	ldp	x19, x20, [sp], #0x10
1005c7548: a8c15bf5    	ldp	x21, x22, [sp], #0x10
1005c754c: a8c163f7    	ldp	x23, x24, [sp], #0x10
1005c7550: a8c16bf9    	ldp	x25, x26, [sp], #0x10
1005c7554: a8c173fb    	ldp	x27, x28, [sp], #0x10
1005c7558: a8c17bfd    	ldp	x29, x30, [sp], #0x10
1005c755c: d65f0fff    	retab
1005c7560: 910006ba    	add	x26, x21, #0x1
1005c7564: eb15035f    	cmp	x26, x21
1005c7568: 540083c3    	b.lo	0x1005c85e0 <_mech_canonical_program_entry_v1_numeric_256+0x2ae0>
1005c756c: d2800021    	mov	x1, #0x1                ; =1
1005c7570: f80683ef    	stur	x15, [sp, #0x68]
1005c7574: f80603ee    	stur	x14, [sp, #0x60]
1005c7578: aa0203f8    	mov	x24, x2
1005c757c: aa1403f5    	mov	x21, x20
1005c7580: aa1303ee    	mov	x14, x19
1005c7584: aa0103ea    	mov	x10, x1
1005c7588: 17fff9e4    	b	0x1005c5d18 <_mech_canonical_program_entry_v1_numeric_256+0x218>
1005c758c: f84603ee    	ldur	x14, [sp, #0x60]
1005c7590: f84683ef    	ldur	x15, [sp, #0x68]
1005c7594: 91000785    	add	x5, x28, #0x1
1005c7598: eb1c00bf    	cmp	x5, x28
1005c759c: 540086c3    	b.lo	0x1005c8674 <_mech_canonical_program_entry_v1_numeric_256+0x2b74>
1005c75a0: d2800028    	mov	x8, #0x1                ; =1
1005c75a4: f80203e8    	stur	x8, [sp, #0x20]
1005c75a8: aa0503fc    	mov	x28, x5
1005c75ac: f80603ee    	stur	x14, [sp, #0x60]
1005c75b0: f80683ef    	stur	x15, [sp, #0x68]
1005c75b4: 17fffb6d    	b	0x1005c6368 <_mech_canonical_program_entry_v1_numeric_256+0x868>
1005c75b8: f84883ea    	ldur	x10, [sp, #0x88]
1005c75bc: f84603ee    	ldur	x14, [sp, #0x60]
1005c75c0: f84683ef    	ldur	x15, [sp, #0x68]
1005c75c4: 910006c5    	add	x5, x22, #0x1
1005c75c8: eb1600bf    	cmp	x5, x22
1005c75cc: 54008ac3    	b.lo	0x1005c8724 <_mech_canonical_program_entry_v1_numeric_256+0x2c24>
1005c75d0: d2800028    	mov	x8, #0x1                ; =1
1005c75d4: f80303e8    	stur	x8, [sp, #0x30]
1005c75d8: aa0503f6    	mov	x22, x5
1005c75dc: f80603ee    	stur	x14, [sp, #0x60]
1005c75e0: f80683ef    	stur	x15, [sp, #0x68]
1005c75e4: f80883ea    	stur	x10, [sp, #0x88]
1005c75e8: 17fffc04    	b	0x1005c65f8 <_mech_canonical_program_entry_v1_numeric_256+0xaf8>
1005c75ec: f84883ea    	ldur	x10, [sp, #0x88]
1005c75f0: f84603ee    	ldur	x14, [sp, #0x60]
1005c75f4: f84683ef    	ldur	x15, [sp, #0x68]
1005c75f8: 91000515    	add	x21, x8, #0x1
1005c75fc: eb0802bf    	cmp	x21, x8
1005c7600: 54008f83    	b.lo	0x1005c87f0 <_mech_canonical_program_entry_v1_numeric_256+0x2cf0>
1005c7604: d2800027    	mov	x7, #0x1                ; =1
1005c7608: f80603ee    	stur	x14, [sp, #0x60]
1005c760c: f80683ef    	stur	x15, [sp, #0x68]
1005c7610: f80883ea    	stur	x10, [sp, #0x88]
1005c7614: 17fffc9e    	b	0x1005c688c <_mech_canonical_program_entry_v1_numeric_256+0xd8c>
1005c7618: f80703e0    	stur	x0, [sp, #0x70]
1005c761c: 140004ad    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c7620: f80703e0    	stur	x0, [sp, #0x70]
1005c7624: 140004ab    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c7628: f80703e0    	stur	x0, [sp, #0x70]
1005c762c: 140004a9    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c7630: f80703e0    	stur	x0, [sp, #0x70]
1005c7634: 140004a7    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c7638: d2802200    	mov	x0, #0x110              ; =272
1005c763c: aa1503f4    	mov	x20, x21
1005c7640: f9002680    	str	x0, [x20, #0x48]
1005c7644: d2800020    	mov	x0, #0x1                ; =1
1005c7648: f9001a60    	str	x0, [x19, #0x30]
1005c764c: d2800054    	mov	x20, #0x2               ; =2
1005c7650: f9002274    	str	x20, [x19, #0x40]
1005c7654: d28000c2    	mov	x2, #0x6                ; =6
1005c7658: f9003262    	str	x2, [x19, #0x60]
1005c765c: d2800002    	mov	x2, #0x0                ; =0
1005c7660: f900c662    	str	x2, [x19, #0x188]
1005c7664: f900ca60    	str	x0, [x19, #0x190]
1005c7668: f902e27a    	str	x26, [x19, #0x5c0]
1005c766c: f902e679    	str	x25, [x19, #0x5c8]
1005c7670: f84983e0    	ldur	x0, [sp, #0x98]
1005c7674: 53001c02    	uxtb	w2, w0
1005c7678: f902f262    	str	x2, [x19, #0x5e0]
1005c767c: 91000745    	add	x5, x26, #0x1
1005c7680: f902fa65    	str	x5, [x19, #0x5f0]
1005c7684: f9254e66    	str	x6, [x19, #0x4a98]
1005c7688: d29d1506    	mov	x6, #0xe8a8             ; =59560
1005c768c: cb060065    	sub	x5, x3, x6
1005c7690: f9255265    	str	x5, [x19, #0x4aa0]
1005c7694: f9255664    	str	x4, [x19, #0x4aa8]
1005c7698: f927ba7a    	str	x26, [x19, #0x4f70]
1005c769c: f927be79    	str	x25, [x19, #0x4f78]
1005c76a0: f84503ef    	ldur	x15, [sp, #0x50]
1005c76a4: f9288a6f    	str	x15, [x19, #0x5110]
1005c76a8: f84083f7    	ldur	x23, [sp, #0x8]
1005c76ac: f9289a77    	str	x23, [x19, #0x5130]
1005c76b0: 9100058c    	add	x12, x12, #0x1
1005c76b4: f928de6c    	str	x12, [x19, #0x51b8]
1005c76b8: aa1803e2    	mov	x2, x24
1005c76bc: f928e262    	str	x2, [x19, #0x51c0]
1005c76c0: f928e66a    	str	x10, [x19, #0x51c8]
1005c76c4: f84103e0    	ldur	x0, [sp, #0x10]
1005c76c8: cb05000f    	sub	x15, x0, x5
1005c76cc: 9b06bd8f    	msub	x15, x12, x6, x15
1005c76d0: f928ea6f    	str	x15, [x19, #0x51d0]
1005c76d4: f928ee6b    	str	x11, [x19, #0x51d8]
1005c76d8: f928f268    	str	x8, [x19, #0x51e0]
1005c76dc: f928fa6d    	str	x13, [x19, #0x51f0]
1005c76e0: f928fe76    	str	x22, [x19, #0x51f8]
1005c76e4: f9290669    	str	x9, [x19, #0x5208]
1005c76e8: f9290a67    	str	x7, [x19, #0x5210]
1005c76ec: f9654e60    	ldr	x0, [x19, #0x4a98]
1005c76f0: f100001f    	cmp	x0, #0x0
1005c76f4: 54ff4541    	b.ne	0x1005c5f9c <_mech_canonical_program_entry_v1_numeric_256+0x49c>
1005c76f8: 17fffa26    	b	0x1005c5f90 <_mech_canonical_program_entry_v1_numeric_256+0x490>
1005c76fc: f80703e0    	stur	x0, [sp, #0x70]
1005c7700: 14000474    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c7704: f80703f4    	stur	x20, [sp, #0x70]
1005c7708: 14000472    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c770c: f80703e0    	stur	x0, [sp, #0x70]
1005c7710: 14000470    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c7714: f80703f4    	stur	x20, [sp, #0x70]
1005c7718: 1400046e    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c771c: d2802240    	mov	x0, #0x112              ; =274
1005c7720: f9002680    	str	x0, [x20, #0x48]
1005c7724: d2800020    	mov	x0, #0x1                ; =1
1005c7728: f9001a60    	str	x0, [x19, #0x30]
1005c772c: d2800054    	mov	x20, #0x2               ; =2
1005c7730: f9002274    	str	x20, [x19, #0x40]
1005c7734: d28000c1    	mov	x1, #0x6                ; =6
1005c7738: f9003261    	str	x1, [x19, #0x60]
1005c773c: d2800001    	mov	x1, #0x0                ; =0
1005c7740: f900c661    	str	x1, [x19, #0x188]
1005c7744: f900ca60    	str	x0, [x19, #0x190]
1005c7748: f902e27a    	str	x26, [x19, #0x5c0]
1005c774c: f902e679    	str	x25, [x19, #0x5c8]
1005c7750: f84983e0    	ldur	x0, [sp, #0x98]
1005c7754: 53001c00    	uxtb	w0, w0
1005c7758: f902f260    	str	x0, [x19, #0x5e0]
1005c775c: f902fe7c    	str	x28, [x19, #0x5f8]
1005c7760: 91000b40    	add	x0, x26, #0x2
1005c7764: f9030260    	str	x0, [x19, #0x600]
1005c7768: f9254e66    	str	x6, [x19, #0x4a98]
1005c776c: d29d1500    	mov	x0, #0xe8a8             ; =59560
1005c7770: cb000063    	sub	x3, x3, x0
1005c7774: f9255263    	str	x3, [x19, #0x4aa0]
1005c7778: f9255664    	str	x4, [x19, #0x4aa8]
1005c777c: f927ba7a    	str	x26, [x19, #0x4f70]
1005c7780: f927be79    	str	x25, [x19, #0x4f78]
1005c7784: f84503e1    	ldur	x1, [sp, #0x50]
1005c7788: f9288a61    	str	x1, [x19, #0x5110]
1005c778c: f84083f7    	ldur	x23, [sp, #0x8]
1005c7790: f9289a77    	str	x23, [x19, #0x5130]
1005c7794: 91000584    	add	x4, x12, #0x1
1005c7798: f928de64    	str	x4, [x19, #0x51b8]
1005c779c: f928e262    	str	x2, [x19, #0x51c0]
1005c77a0: aa1503e1    	mov	x1, x21
1005c77a4: f928e661    	str	x1, [x19, #0x51c8]
1005c77a8: f84103e5    	ldur	x5, [sp, #0x10]
1005c77ac: cb0300a1    	sub	x1, x5, x3
1005c77b0: 9b008480    	msub	x0, x4, x0, x1
1005c77b4: f928ea60    	str	x0, [x19, #0x51d0]
1005c77b8: f928ee6b    	str	x11, [x19, #0x51d8]
1005c77bc: f928f268    	str	x8, [x19, #0x51e0]
1005c77c0: f928fa6d    	str	x13, [x19, #0x51f0]
1005c77c4: f928fe76    	str	x22, [x19, #0x51f8]
1005c77c8: f9290669    	str	x9, [x19, #0x5208]
1005c77cc: f9290a67    	str	x7, [x19, #0x5210]
1005c77d0: f9654e60    	ldr	x0, [x19, #0x4a98]
1005c77d4: f100001f    	cmp	x0, #0x0
1005c77d8: 54ff4d41    	b.ne	0x1005c6180 <_mech_canonical_program_entry_v1_numeric_256+0x680>
1005c77dc: 17fffab8    	b	0x1005c62bc <_mech_canonical_program_entry_v1_numeric_256+0x7bc>
1005c77e0: f80703e0    	stur	x0, [sp, #0x70]
1005c77e4: 1400043b    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c77e8: f80703f4    	stur	x20, [sp, #0x70]
1005c77ec: 14000439    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c77f0: f80703e0    	stur	x0, [sp, #0x70]
1005c77f4: 14000437    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c77f8: f80703f4    	stur	x20, [sp, #0x70]
1005c77fc: 14000435    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c7800: f80703f5    	stur	x21, [sp, #0x70]
1005c7804: 14000433    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c7808: d2802440    	mov	x0, #0x122              ; =290
1005c780c: f9002680    	str	x0, [x20, #0x48]
1005c7810: d2800020    	mov	x0, #0x1                ; =1
1005c7814: f80703e0    	stur	x0, [sp, #0x70]
1005c7818: f9001a60    	str	x0, [x19, #0x30]
1005c781c: f84903f4    	ldur	x20, [sp, #0x90]
1005c7820: f9002274    	str	x20, [x19, #0x40]
1005c7824: d28000c0    	mov	x0, #0x6                ; =6
1005c7828: f9003260    	str	x0, [x19, #0x60]
1005c782c: d2800000    	mov	x0, #0x0                ; =0
1005c7830: f900c660    	str	x0, [x19, #0x188]
1005c7834: f84703e0    	ldur	x0, [sp, #0x70]
1005c7838: f900ca60    	str	x0, [x19, #0x190]
1005c783c: f902e27a    	str	x26, [x19, #0x5c0]
1005c7840: f902e679    	str	x25, [x19, #0x5c8]
1005c7844: f84983fa    	ldur	x26, [sp, #0x98]
1005c7848: 53001f40    	uxtb	w0, w26
1005c784c: f902f260    	str	x0, [x19, #0x5e0]
1005c7850: f9032e7c    	str	x28, [x19, #0x658]
1005c7854: f903327b    	str	x27, [x19, #0x660]
1005c7858: f9254e66    	str	x6, [x19, #0x4a98]
1005c785c: d2968d05    	mov	x5, #0xb468             ; =46184
1005c7860: cb050063    	sub	x3, x3, x5
1005c7864: f9255263    	str	x3, [x19, #0x4aa0]
1005c7868: f9255664    	str	x4, [x19, #0x4aa8]
1005c786c: f84503f4    	ldur	x20, [sp, #0x50]
1005c7870: f9288a74    	str	x20, [x19, #0x5110]
1005c7874: f84083f7    	ldur	x23, [sp, #0x8]
1005c7878: f9289a77    	str	x23, [x19, #0x5130]
1005c787c: f928de6c    	str	x12, [x19, #0x51b8]
1005c7880: f928e262    	str	x2, [x19, #0x51c0]
1005c7884: f928e661    	str	x1, [x19, #0x51c8]
1005c7888: f84103e5    	ldur	x5, [sp, #0x10]
1005c788c: cb0300aa    	sub	x10, x5, x3
1005c7890: d29d150b    	mov	x11, #0xe8a8            ; =59560
1005c7894: 9b0ba98a    	msub	x10, x12, x11, x10
1005c7898: f928ea6a    	str	x10, [x19, #0x51d0]
1005c789c: f84183eb    	ldur	x11, [sp, #0x18]
1005c78a0: f928ee6b    	str	x11, [x19, #0x51d8]
1005c78a4: f84203e1    	ldur	x1, [sp, #0x20]
1005c78a8: f928f261    	str	x1, [x19, #0x51e0]
1005c78ac: f928fa6d    	str	x13, [x19, #0x51f0]
1005c78b0: f928fe76    	str	x22, [x19, #0x51f8]
1005c78b4: f9290669    	str	x9, [x19, #0x5208]
1005c78b8: f9290a67    	str	x7, [x19, #0x5210]
1005c78bc: 14000405    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c78c0: f84903e0    	ldur	x0, [sp, #0x90]
1005c78c4: f80703e0    	stur	x0, [sp, #0x70]
1005c78c8: 14000402    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c78cc: d2802740    	mov	x0, #0x13a              ; =314
1005c78d0: f9002680    	str	x0, [x20, #0x48]
1005c78d4: d2800020    	mov	x0, #0x1                ; =1
1005c78d8: f80703e0    	stur	x0, [sp, #0x70]
1005c78dc: f9001a60    	str	x0, [x19, #0x30]
1005c78e0: f84903ee    	ldur	x14, [sp, #0x90]
1005c78e4: f900226e    	str	x14, [x19, #0x40]
1005c78e8: d28000c0    	mov	x0, #0x6                ; =6
1005c78ec: f9003260    	str	x0, [x19, #0x60]
1005c78f0: d2800000    	mov	x0, #0x0                ; =0
1005c78f4: f900c660    	str	x0, [x19, #0x188]
1005c78f8: f84703e0    	ldur	x0, [sp, #0x70]
1005c78fc: f900ca60    	str	x0, [x19, #0x190]
1005c7900: f902e27a    	str	x26, [x19, #0x5c0]
1005c7904: f902e679    	str	x25, [x19, #0x5c8]
1005c7908: f84983fa    	ldur	x26, [sp, #0x98]
1005c790c: 53001f45    	uxtb	w5, w26
1005c7910: f902f265    	str	x5, [x19, #0x5e0]
1005c7914: f9032e7c    	str	x28, [x19, #0x658]
1005c7918: f903327b    	str	x27, [x19, #0x660]
1005c791c: 53001f05    	uxtb	w5, w24
1005c7920: f9033e65    	str	x5, [x19, #0x678]
1005c7924: f903727c    	str	x28, [x19, #0x6e0]
1005c7928: f9037676    	str	x22, [x19, #0x6e8]
1005c792c: f9037a7b    	str	x27, [x19, #0x6f0]
1005c7930: f9254e66    	str	x6, [x19, #0x4a98]
1005c7934: d297900a    	mov	x10, #0xbc80            ; =48256
1005c7938: cb0a006a    	sub	x10, x3, x10
1005c793c: f925526a    	str	x10, [x19, #0x4aa0]
1005c7940: f9255664    	str	x4, [x19, #0x4aa8]
1005c7944: f84503f4    	ldur	x20, [sp, #0x50]
1005c7948: f9288a74    	str	x20, [x19, #0x5110]
1005c794c: f84083f7    	ldur	x23, [sp, #0x8]
1005c7950: f9289a77    	str	x23, [x19, #0x5130]
1005c7954: f928de6c    	str	x12, [x19, #0x51b8]
1005c7958: f928e262    	str	x2, [x19, #0x51c0]
1005c795c: f928e661    	str	x1, [x19, #0x51c8]
1005c7960: f84103e5    	ldur	x5, [sp, #0x10]
1005c7964: cb0a00a1    	sub	x1, x5, x10
1005c7968: d29d1500    	mov	x0, #0xe8a8             ; =59560
1005c796c: 9b008580    	msub	x0, x12, x0, x1
1005c7970: f928ea60    	str	x0, [x19, #0x51d0]
1005c7974: f84183eb    	ldur	x11, [sp, #0x18]
1005c7978: f928ee6b    	str	x11, [x19, #0x51d8]
1005c797c: f84203ed    	ldur	x13, [sp, #0x20]
1005c7980: f928f26d    	str	x13, [x19, #0x51e0]
1005c7984: f84283e2    	ldur	x2, [sp, #0x28]
1005c7988: f928fa62    	str	x2, [x19, #0x51f0]
1005c798c: f84303ea    	ldur	x10, [sp, #0x30]
1005c7990: f928fe6a    	str	x10, [x19, #0x51f8]
1005c7994: f9290669    	str	x9, [x19, #0x5208]
1005c7998: f9290a67    	str	x7, [x19, #0x5210]
1005c799c: 140003cd    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c79a0: f84903e0    	ldur	x0, [sp, #0x90]
1005c79a4: f80703e0    	stur	x0, [sp, #0x70]
1005c79a8: 140003ca    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c79ac: d2802b40    	mov	x0, #0x15a              ; =346
1005c79b0: f9002680    	str	x0, [x20, #0x48]
1005c79b4: d2800020    	mov	x0, #0x1                ; =1
1005c79b8: f9001a60    	str	x0, [x19, #0x30]
1005c79bc: f84903e5    	ldur	x5, [sp, #0x90]
1005c79c0: f9002265    	str	x5, [x19, #0x40]
1005c79c4: d28000c5    	mov	x5, #0x6                ; =6
1005c79c8: f9003265    	str	x5, [x19, #0x60]
1005c79cc: d2800005    	mov	x5, #0x0                ; =0
1005c79d0: f900c665    	str	x5, [x19, #0x188]
1005c79d4: f900ca60    	str	x0, [x19, #0x190]
1005c79d8: f902e27a    	str	x26, [x19, #0x5c0]
1005c79dc: f902e679    	str	x25, [x19, #0x5c8]
1005c79e0: f84983e5    	ldur	x5, [sp, #0x98]
1005c79e4: 53001ca0    	uxtb	w0, w5
1005c79e8: f902f260    	str	x0, [x19, #0x5e0]
1005c79ec: f9032e7c    	str	x28, [x19, #0x658]
1005c79f0: f903327b    	str	x27, [x19, #0x660]
1005c79f4: 53001f00    	uxtb	w0, w24
1005c79f8: f9033e60    	str	x0, [x19, #0x678]
1005c79fc: f903727c    	str	x28, [x19, #0x6e0]
1005c7a00: f9037676    	str	x22, [x19, #0x6e8]
1005c7a04: f9037a7b    	str	x27, [x19, #0x6f0]
1005c7a08: 53001ee0    	uxtb	w0, w23
1005c7a0c: f9038660    	str	x0, [x19, #0x708]
1005c7a10: f903be7c    	str	x28, [x19, #0x778]
1005c7a14: f903c276    	str	x22, [x19, #0x780]
1005c7a18: f903c675    	str	x21, [x19, #0x788]
1005c7a1c: f903ca7b    	str	x27, [x19, #0x790]
1005c7a20: 53001dc0    	uxtb	w0, w14
1005c7a24: f903d260    	str	x0, [x19, #0x7a0]
1005c7a28: f84803e8    	ldur	x8, [sp, #0x80]
1005c7a2c: f903da68    	str	x8, [x19, #0x7b0]
1005c7a30: f9254e66    	str	x6, [x19, #0x4a98]
1005c7a34: d29bbe00    	mov	x0, #0xddf0             ; =56816
1005c7a38: cb000060    	sub	x0, x3, x0
1005c7a3c: f9255260    	str	x0, [x19, #0x4aa0]
1005c7a40: f9255664    	str	x4, [x19, #0x4aa8]
1005c7a44: f927ba7a    	str	x26, [x19, #0x4f70]
1005c7a48: f927be79    	str	x25, [x19, #0x4f78]
1005c7a4c: f927da7c    	str	x28, [x19, #0x4fb0]
1005c7a50: f927de7b    	str	x27, [x19, #0x4fb8]
1005c7a54: f928027c    	str	x28, [x19, #0x5000]
1005c7a58: f9280676    	str	x22, [x19, #0x5008]
1005c7a5c: f9280a7b    	str	x27, [x19, #0x5010]
1005c7a60: f9283a7c    	str	x28, [x19, #0x5070]
1005c7a64: f9283e76    	str	x22, [x19, #0x5078]
1005c7a68: f9284275    	str	x21, [x19, #0x5080]
1005c7a6c: f928467b    	str	x27, [x19, #0x5088]
1005c7a70: f84503f4    	ldur	x20, [sp, #0x50]
1005c7a74: f9288a74    	str	x20, [x19, #0x5110]
1005c7a78: f84083f7    	ldur	x23, [sp, #0x8]
1005c7a7c: f9289a77    	str	x23, [x19, #0x5130]
1005c7a80: f928de6c    	str	x12, [x19, #0x51b8]
1005c7a84: f928e262    	str	x2, [x19, #0x51c0]
1005c7a88: f928e661    	str	x1, [x19, #0x51c8]
1005c7a8c: f84103e5    	ldur	x5, [sp, #0x10]
1005c7a90: cb0000a0    	sub	x0, x5, x0
1005c7a94: d29d1501    	mov	x1, #0xe8a8             ; =59560
1005c7a98: 9b018180    	msub	x0, x12, x1, x0
1005c7a9c: f928ea60    	str	x0, [x19, #0x51d0]
1005c7aa0: f84183eb    	ldur	x11, [sp, #0x18]
1005c7aa4: f928ee6b    	str	x11, [x19, #0x51d8]
1005c7aa8: f84203ed    	ldur	x13, [sp, #0x20]
1005c7aac: f928f26d    	str	x13, [x19, #0x51e0]
1005c7ab0: f84283e2    	ldur	x2, [sp, #0x28]
1005c7ab4: f928fa62    	str	x2, [x19, #0x51f0]
1005c7ab8: f84303ea    	ldur	x10, [sp, #0x30]
1005c7abc: f928fe6a    	str	x10, [x19, #0x51f8]
1005c7ac0: f9290669    	str	x9, [x19, #0x5208]
1005c7ac4: f9290a67    	str	x7, [x19, #0x5210]
1005c7ac8: f9654e67    	ldr	x7, [x19, #0x4a98]
1005c7acc: f10000ff    	cmp	x7, #0x0
1005c7ad0: 54ff8481    	b.ne	0x1005c6b60 <_mech_canonical_program_entry_v1_numeric_256+0x1060>
1005c7ad4: 17fffc71    	b	0x1005c6c98 <_mech_canonical_program_entry_v1_numeric_256+0x1198>
1005c7ad8: f84903e0    	ldur	x0, [sp, #0x90]
1005c7adc: f80703e0    	stur	x0, [sp, #0x70]
1005c7ae0: 1400037c    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c7ae4: f84903e0    	ldur	x0, [sp, #0x90]
1005c7ae8: f80703e0    	stur	x0, [sp, #0x70]
1005c7aec: 14000379    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c7af0: d2802b80    	mov	x0, #0x15c              ; =348
1005c7af4: f9002680    	str	x0, [x20, #0x48]
1005c7af8: d2800020    	mov	x0, #0x1                ; =1
1005c7afc: f9001a60    	str	x0, [x19, #0x30]
1005c7b00: f84903ed    	ldur	x13, [sp, #0x90]
1005c7b04: f900226d    	str	x13, [x19, #0x40]
1005c7b08: d28000c5    	mov	x5, #0x6                ; =6
1005c7b0c: f9003265    	str	x5, [x19, #0x60]
1005c7b10: d2800005    	mov	x5, #0x0                ; =0
1005c7b14: f900c665    	str	x5, [x19, #0x188]
1005c7b18: f900ca60    	str	x0, [x19, #0x190]
1005c7b1c: f902e27a    	str	x26, [x19, #0x5c0]
1005c7b20: f902e679    	str	x25, [x19, #0x5c8]
1005c7b24: f84983e0    	ldur	x0, [sp, #0x98]
1005c7b28: 53001c05    	uxtb	w5, w0
1005c7b2c: f902f265    	str	x5, [x19, #0x5e0]
1005c7b30: f9032e7c    	str	x28, [x19, #0x658]
1005c7b34: f903327b    	str	x27, [x19, #0x660]
1005c7b38: 53001f08    	uxtb	w8, w24
1005c7b3c: f9033e68    	str	x8, [x19, #0x678]
1005c7b40: f903727c    	str	x28, [x19, #0x6e0]
1005c7b44: f9037676    	str	x22, [x19, #0x6e8]
1005c7b48: f9037a7b    	str	x27, [x19, #0x6f0]
1005c7b4c: 53001eed    	uxtb	w13, w23
1005c7b50: f903866d    	str	x13, [x19, #0x708]
1005c7b54: f903be7c    	str	x28, [x19, #0x778]
1005c7b58: f903c276    	str	x22, [x19, #0x780]
1005c7b5c: f903c675    	str	x21, [x19, #0x788]
1005c7b60: f903ca7b    	str	x27, [x19, #0x790]
1005c7b64: 53001dc0    	uxtb	w0, w14
1005c7b68: f903d260    	str	x0, [x19, #0x7a0]
1005c7b6c: f903de6b    	str	x11, [x19, #0x7b8]
1005c7b70: f84783f8    	ldur	x24, [sp, #0x78]
1005c7b74: f903e278    	str	x24, [x19, #0x7c0]
1005c7b78: f9254e66    	str	x6, [x19, #0x4a98]
1005c7b7c: d29bbe00    	mov	x0, #0xddf0             ; =56816
1005c7b80: cb000060    	sub	x0, x3, x0
1005c7b84: f9255260    	str	x0, [x19, #0x4aa0]
1005c7b88: f9255664    	str	x4, [x19, #0x4aa8]
1005c7b8c: f927ba7a    	str	x26, [x19, #0x4f70]
1005c7b90: f927be79    	str	x25, [x19, #0x4f78]
1005c7b94: f927da7c    	str	x28, [x19, #0x4fb0]
1005c7b98: f927de7b    	str	x27, [x19, #0x4fb8]
1005c7b9c: f928027c    	str	x28, [x19, #0x5000]
1005c7ba0: f9280676    	str	x22, [x19, #0x5008]
1005c7ba4: f9280a7b    	str	x27, [x19, #0x5010]
1005c7ba8: f9283a7c    	str	x28, [x19, #0x5070]
1005c7bac: f9283e76    	str	x22, [x19, #0x5078]
1005c7bb0: f9284275    	str	x21, [x19, #0x5080]
1005c7bb4: f928467b    	str	x27, [x19, #0x5088]
1005c7bb8: f84503f4    	ldur	x20, [sp, #0x50]
1005c7bbc: f9288a74    	str	x20, [x19, #0x5110]
1005c7bc0: f84083f7    	ldur	x23, [sp, #0x8]
1005c7bc4: f9289a77    	str	x23, [x19, #0x5130]
1005c7bc8: f928de6c    	str	x12, [x19, #0x51b8]
1005c7bcc: f928e262    	str	x2, [x19, #0x51c0]
1005c7bd0: f928e661    	str	x1, [x19, #0x51c8]
1005c7bd4: f84103e5    	ldur	x5, [sp, #0x10]
1005c7bd8: cb0000a0    	sub	x0, x5, x0
1005c7bdc: d29d1501    	mov	x1, #0xe8a8             ; =59560
1005c7be0: 9b018180    	msub	x0, x12, x1, x0
1005c7be4: f928ea60    	str	x0, [x19, #0x51d0]
1005c7be8: f84183eb    	ldur	x11, [sp, #0x18]
1005c7bec: f928ee6b    	str	x11, [x19, #0x51d8]
1005c7bf0: f84203ed    	ldur	x13, [sp, #0x20]
1005c7bf4: f928f26d    	str	x13, [x19, #0x51e0]
1005c7bf8: f84283e2    	ldur	x2, [sp, #0x28]
1005c7bfc: f928fa62    	str	x2, [x19, #0x51f0]
1005c7c00: f84303ea    	ldur	x10, [sp, #0x30]
1005c7c04: f928fe6a    	str	x10, [x19, #0x51f8]
1005c7c08: f9290669    	str	x9, [x19, #0x5208]
1005c7c0c: f9290a67    	str	x7, [x19, #0x5210]
1005c7c10: f9654e60    	ldr	x0, [x19, #0x4a98]
1005c7c14: f100001f    	cmp	x0, #0x0
1005c7c18: 54ff8761    	b.ne	0x1005c6d04 <_mech_canonical_program_entry_v1_numeric_256+0x1204>
1005c7c1c: 17fffc8a    	b	0x1005c6e44 <_mech_canonical_program_entry_v1_numeric_256+0x1344>
1005c7c20: f84903e0    	ldur	x0, [sp, #0x90]
1005c7c24: f80703e0    	stur	x0, [sp, #0x70]
1005c7c28: 1400032a    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c7c2c: f84903e0    	ldur	x0, [sp, #0x90]
1005c7c30: f80703e0    	stur	x0, [sp, #0x70]
1005c7c34: 14000327    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c7c38: d2802bc0    	mov	x0, #0x15e              ; =350
1005c7c3c: f9002680    	str	x0, [x20, #0x48]
1005c7c40: d2800020    	mov	x0, #0x1                ; =1
1005c7c44: f9001a60    	str	x0, [x19, #0x30]
1005c7c48: f84903e5    	ldur	x5, [sp, #0x90]
1005c7c4c: f9002265    	str	x5, [x19, #0x40]
1005c7c50: d28000c5    	mov	x5, #0x6                ; =6
1005c7c54: f9003265    	str	x5, [x19, #0x60]
1005c7c58: d2800005    	mov	x5, #0x0                ; =0
1005c7c5c: f900c665    	str	x5, [x19, #0x188]
1005c7c60: f900ca60    	str	x0, [x19, #0x190]
1005c7c64: f902e27a    	str	x26, [x19, #0x5c0]
1005c7c68: f902e679    	str	x25, [x19, #0x5c8]
1005c7c6c: f84983e0    	ldur	x0, [sp, #0x98]
1005c7c70: 53001c00    	uxtb	w0, w0
1005c7c74: f902f260    	str	x0, [x19, #0x5e0]
1005c7c78: f9032e7c    	str	x28, [x19, #0x658]
1005c7c7c: f903327b    	str	x27, [x19, #0x660]
1005c7c80: 53001f00    	uxtb	w0, w24
1005c7c84: f9033e60    	str	x0, [x19, #0x678]
1005c7c88: f903727c    	str	x28, [x19, #0x6e0]
1005c7c8c: f9037676    	str	x22, [x19, #0x6e8]
1005c7c90: f9037a7b    	str	x27, [x19, #0x6f0]
1005c7c94: 53001ee0    	uxtb	w0, w23
1005c7c98: f9038660    	str	x0, [x19, #0x708]
1005c7c9c: f903be7c    	str	x28, [x19, #0x778]
1005c7ca0: f903c276    	str	x22, [x19, #0x780]
1005c7ca4: f903c675    	str	x21, [x19, #0x788]
1005c7ca8: f903ca7b    	str	x27, [x19, #0x790]
1005c7cac: 53001dc0    	uxtb	w0, w14
1005c7cb0: f903d260    	str	x0, [x19, #0x7a0]
1005c7cb4: f903de6b    	str	x11, [x19, #0x7b8]
1005c7cb8: f903e668    	str	x8, [x19, #0x7c8]
1005c7cbc: 910006a0    	add	x0, x21, #0x1
1005c7cc0: f903ea60    	str	x0, [x19, #0x7d0]
1005c7cc4: f9254e66    	str	x6, [x19, #0x4a98]
1005c7cc8: d29bbe00    	mov	x0, #0xddf0             ; =56816
1005c7ccc: cb000060    	sub	x0, x3, x0
1005c7cd0: f9255260    	str	x0, [x19, #0x4aa0]
1005c7cd4: f9255664    	str	x4, [x19, #0x4aa8]
1005c7cd8: f927ba7a    	str	x26, [x19, #0x4f70]
1005c7cdc: f927be79    	str	x25, [x19, #0x4f78]
1005c7ce0: f927da7c    	str	x28, [x19, #0x4fb0]
1005c7ce4: f927de7b    	str	x27, [x19, #0x4fb8]
1005c7ce8: f928027c    	str	x28, [x19, #0x5000]
1005c7cec: f9280676    	str	x22, [x19, #0x5008]
1005c7cf0: f9280a7b    	str	x27, [x19, #0x5010]
1005c7cf4: f9283a7c    	str	x28, [x19, #0x5070]
1005c7cf8: f9283e76    	str	x22, [x19, #0x5078]
1005c7cfc: f9284275    	str	x21, [x19, #0x5080]
1005c7d00: f928467b    	str	x27, [x19, #0x5088]
1005c7d04: f84503f4    	ldur	x20, [sp, #0x50]
1005c7d08: f9288a74    	str	x20, [x19, #0x5110]
1005c7d0c: f84083f7    	ldur	x23, [sp, #0x8]
1005c7d10: f9289a77    	str	x23, [x19, #0x5130]
1005c7d14: f928de6c    	str	x12, [x19, #0x51b8]
1005c7d18: f928e262    	str	x2, [x19, #0x51c0]
1005c7d1c: f928e661    	str	x1, [x19, #0x51c8]
1005c7d20: f84103e5    	ldur	x5, [sp, #0x10]
1005c7d24: cb0000ae    	sub	x14, x5, x0
1005c7d28: d29d150f    	mov	x15, #0xe8a8            ; =59560
1005c7d2c: 9b0fb98e    	msub	x14, x12, x15, x14
1005c7d30: f928ea6e    	str	x14, [x19, #0x51d0]
1005c7d34: f84183eb    	ldur	x11, [sp, #0x18]
1005c7d38: f928ee6b    	str	x11, [x19, #0x51d8]
1005c7d3c: f84203ed    	ldur	x13, [sp, #0x20]
1005c7d40: f928f26d    	str	x13, [x19, #0x51e0]
1005c7d44: f84283e2    	ldur	x2, [sp, #0x28]
1005c7d48: f928fa62    	str	x2, [x19, #0x51f0]
1005c7d4c: f84303ea    	ldur	x10, [sp, #0x30]
1005c7d50: f928fe6a    	str	x10, [x19, #0x51f8]
1005c7d54: f9290669    	str	x9, [x19, #0x5208]
1005c7d58: f9290a67    	str	x7, [x19, #0x5210]
1005c7d5c: f9654e60    	ldr	x0, [x19, #0x4a98]
1005c7d60: f100001f    	cmp	x0, #0x0
1005c7d64: 54ff8a61    	b.ne	0x1005c6eb0 <_mech_canonical_program_entry_v1_numeric_256+0x13b0>
1005c7d68: 17fffca1    	b	0x1005c6fec <_mech_canonical_program_entry_v1_numeric_256+0x14ec>
1005c7d6c: f84903e0    	ldur	x0, [sp, #0x90]
1005c7d70: f80703e0    	stur	x0, [sp, #0x70]
1005c7d74: 140002d7    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c7d78: f84903e0    	ldur	x0, [sp, #0x90]
1005c7d7c: f80703e0    	stur	x0, [sp, #0x70]
1005c7d80: 140002d4    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c7d84: d2802bea    	mov	x10, #0x15f             ; =351
1005c7d88: f900268a    	str	x10, [x20, #0x48]
1005c7d8c: d2800020    	mov	x0, #0x1                ; =1
1005c7d90: f80703e0    	stur	x0, [sp, #0x70]
1005c7d94: f9001a60    	str	x0, [x19, #0x30]
1005c7d98: f84903ea    	ldur	x10, [sp, #0x90]
1005c7d9c: f900226a    	str	x10, [x19, #0x40]
1005c7da0: d28000cd    	mov	x13, #0x6               ; =6
1005c7da4: f900326d    	str	x13, [x19, #0x60]
1005c7da8: d280000d    	mov	x13, #0x0               ; =0
1005c7dac: f900c66d    	str	x13, [x19, #0x188]
1005c7db0: f900ca60    	str	x0, [x19, #0x190]
1005c7db4: f902e27a    	str	x26, [x19, #0x5c0]
1005c7db8: f902e679    	str	x25, [x19, #0x5c8]
1005c7dbc: f84983fa    	ldur	x26, [sp, #0x98]
1005c7dc0: 53001f40    	uxtb	w0, w26
1005c7dc4: f902f260    	str	x0, [x19, #0x5e0]
1005c7dc8: f9032e7c    	str	x28, [x19, #0x658]
1005c7dcc: f903327b    	str	x27, [x19, #0x660]
1005c7dd0: 53001f00    	uxtb	w0, w24
1005c7dd4: f9033e60    	str	x0, [x19, #0x678]
1005c7dd8: f903727c    	str	x28, [x19, #0x6e0]
1005c7ddc: f9037676    	str	x22, [x19, #0x6e8]
1005c7de0: f9037a7b    	str	x27, [x19, #0x6f0]
1005c7de4: 53001ee0    	uxtb	w0, w23
1005c7de8: f9038660    	str	x0, [x19, #0x708]
1005c7dec: f903be7c    	str	x28, [x19, #0x778]
1005c7df0: f903c276    	str	x22, [x19, #0x780]
1005c7df4: f903c675    	str	x21, [x19, #0x788]
1005c7df8: f903ca7b    	str	x27, [x19, #0x790]
1005c7dfc: 53001dc0    	uxtb	w0, w14
1005c7e00: f903d260    	str	x0, [x19, #0x7a0]
1005c7e04: f903de6b    	str	x11, [x19, #0x7b8]
1005c7e08: f903e668    	str	x8, [x19, #0x7c8]
1005c7e0c: f903ee6f    	str	x15, [x19, #0x7d8]
1005c7e10: f9254e66    	str	x6, [x19, #0x4a98]
1005c7e14: d29bbe00    	mov	x0, #0xddf0             ; =56816
1005c7e18: cb000063    	sub	x3, x3, x0
1005c7e1c: f9255263    	str	x3, [x19, #0x4aa0]
1005c7e20: f9255664    	str	x4, [x19, #0x4aa8]
1005c7e24: f84503f4    	ldur	x20, [sp, #0x50]
1005c7e28: f9288a74    	str	x20, [x19, #0x5110]
1005c7e2c: f84083f7    	ldur	x23, [sp, #0x8]
1005c7e30: f9289a77    	str	x23, [x19, #0x5130]
1005c7e34: f928de6c    	str	x12, [x19, #0x51b8]
1005c7e38: f928e262    	str	x2, [x19, #0x51c0]
1005c7e3c: f928e661    	str	x1, [x19, #0x51c8]
1005c7e40: f84103e5    	ldur	x5, [sp, #0x10]
1005c7e44: cb0300a1    	sub	x1, x5, x3
1005c7e48: d29d1500    	mov	x0, #0xe8a8             ; =59560
1005c7e4c: 9b008580    	msub	x0, x12, x0, x1
1005c7e50: f928ea60    	str	x0, [x19, #0x51d0]
1005c7e54: f84183eb    	ldur	x11, [sp, #0x18]
1005c7e58: f928ee6b    	str	x11, [x19, #0x51d8]
1005c7e5c: f84203ed    	ldur	x13, [sp, #0x20]
1005c7e60: f928f26d    	str	x13, [x19, #0x51e0]
1005c7e64: f84283e2    	ldur	x2, [sp, #0x28]
1005c7e68: f928fa62    	str	x2, [x19, #0x51f0]
1005c7e6c: f84303ea    	ldur	x10, [sp, #0x30]
1005c7e70: f928fe6a    	str	x10, [x19, #0x51f8]
1005c7e74: f9290669    	str	x9, [x19, #0x5208]
1005c7e78: f9290a67    	str	x7, [x19, #0x5210]
1005c7e7c: 14000295    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c7e80: d2802c00    	mov	x0, #0x160              ; =352
1005c7e84: f9002680    	str	x0, [x20, #0x48]
1005c7e88: d2800020    	mov	x0, #0x1                ; =1
1005c7e8c: f80703e0    	stur	x0, [sp, #0x70]
1005c7e90: f9001a60    	str	x0, [x19, #0x30]
1005c7e94: f84903e5    	ldur	x5, [sp, #0x90]
1005c7e98: f9002265    	str	x5, [x19, #0x40]
1005c7e9c: d28000c0    	mov	x0, #0x6                ; =6
1005c7ea0: f9003260    	str	x0, [x19, #0x60]
1005c7ea4: d2800000    	mov	x0, #0x0                ; =0
1005c7ea8: f900c660    	str	x0, [x19, #0x188]
1005c7eac: f84703e0    	ldur	x0, [sp, #0x70]
1005c7eb0: f900ca60    	str	x0, [x19, #0x190]
1005c7eb4: f902e27a    	str	x26, [x19, #0x5c0]
1005c7eb8: f902e679    	str	x25, [x19, #0x5c8]
1005c7ebc: f84983fa    	ldur	x26, [sp, #0x98]
1005c7ec0: 53001f40    	uxtb	w0, w26
1005c7ec4: f902f260    	str	x0, [x19, #0x5e0]
1005c7ec8: f9032e7c    	str	x28, [x19, #0x658]
1005c7ecc: f903327b    	str	x27, [x19, #0x660]
1005c7ed0: 53001f00    	uxtb	w0, w24
1005c7ed4: f9033e60    	str	x0, [x19, #0x678]
1005c7ed8: f903727c    	str	x28, [x19, #0x6e0]
1005c7edc: f9037676    	str	x22, [x19, #0x6e8]
1005c7ee0: f9037a7b    	str	x27, [x19, #0x6f0]
1005c7ee4: 53001ee5    	uxtb	w5, w23
1005c7ee8: f9038665    	str	x5, [x19, #0x708]
1005c7eec: f903be7c    	str	x28, [x19, #0x778]
1005c7ef0: f903c276    	str	x22, [x19, #0x780]
1005c7ef4: f903c675    	str	x21, [x19, #0x788]
1005c7ef8: f903ca7b    	str	x27, [x19, #0x790]
1005c7efc: 53001dcd    	uxtb	w13, w14
1005c7f00: f903d26d    	str	x13, [x19, #0x7a0]
1005c7f04: f903de6b    	str	x11, [x19, #0x7b8]
1005c7f08: f903e668    	str	x8, [x19, #0x7c8]
1005c7f0c: f903ee6f    	str	x15, [x19, #0x7d8]
1005c7f10: f903f26a    	str	x10, [x19, #0x7e0]
1005c7f14: f9254e66    	str	x6, [x19, #0x4a98]
1005c7f18: d29bbe0e    	mov	x14, #0xddf0            ; =56816
1005c7f1c: cb0e006e    	sub	x14, x3, x14
1005c7f20: f925526e    	str	x14, [x19, #0x4aa0]
1005c7f24: f9255664    	str	x4, [x19, #0x4aa8]
1005c7f28: f84503f4    	ldur	x20, [sp, #0x50]
1005c7f2c: f9288a74    	str	x20, [x19, #0x5110]
1005c7f30: f84083f7    	ldur	x23, [sp, #0x8]
1005c7f34: f9289a77    	str	x23, [x19, #0x5130]
1005c7f38: f928de6c    	str	x12, [x19, #0x51b8]
1005c7f3c: f928e262    	str	x2, [x19, #0x51c0]
1005c7f40: f928e661    	str	x1, [x19, #0x51c8]
1005c7f44: f84103e5    	ldur	x5, [sp, #0x10]
1005c7f48: cb0e00a1    	sub	x1, x5, x14
1005c7f4c: d29d1500    	mov	x0, #0xe8a8             ; =59560
1005c7f50: 9b008580    	msub	x0, x12, x0, x1
1005c7f54: f928ea60    	str	x0, [x19, #0x51d0]
1005c7f58: f84183eb    	ldur	x11, [sp, #0x18]
1005c7f5c: f928ee6b    	str	x11, [x19, #0x51d8]
1005c7f60: f84203ed    	ldur	x13, [sp, #0x20]
1005c7f64: f928f26d    	str	x13, [x19, #0x51e0]
1005c7f68: f84283e2    	ldur	x2, [sp, #0x28]
1005c7f6c: f928fa62    	str	x2, [x19, #0x51f0]
1005c7f70: f84303ea    	ldur	x10, [sp, #0x30]
1005c7f74: f928fe6a    	str	x10, [x19, #0x51f8]
1005c7f78: f9290669    	str	x9, [x19, #0x5208]
1005c7f7c: f9290a67    	str	x7, [x19, #0x5210]
1005c7f80: 14000254    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c7f84: d2802c40    	mov	x0, #0x162              ; =354
1005c7f88: f9002680    	str	x0, [x20, #0x48]
1005c7f8c: d2800020    	mov	x0, #0x1                ; =1
1005c7f90: f80703e0    	stur	x0, [sp, #0x70]
1005c7f94: f9001a60    	str	x0, [x19, #0x30]
1005c7f98: f84903e5    	ldur	x5, [sp, #0x90]
1005c7f9c: f9002265    	str	x5, [x19, #0x40]
1005c7fa0: d28000c0    	mov	x0, #0x6                ; =6
1005c7fa4: f9003260    	str	x0, [x19, #0x60]
1005c7fa8: d2800000    	mov	x0, #0x0                ; =0
1005c7fac: f900c660    	str	x0, [x19, #0x188]
1005c7fb0: f84703e0    	ldur	x0, [sp, #0x70]
1005c7fb4: f900ca60    	str	x0, [x19, #0x190]
1005c7fb8: f902e27a    	str	x26, [x19, #0x5c0]
1005c7fbc: f902e679    	str	x25, [x19, #0x5c8]
1005c7fc0: f84983fa    	ldur	x26, [sp, #0x98]
1005c7fc4: 53001f40    	uxtb	w0, w26
1005c7fc8: f902f260    	str	x0, [x19, #0x5e0]
1005c7fcc: f9032e7c    	str	x28, [x19, #0x658]
1005c7fd0: f903327b    	str	x27, [x19, #0x660]
1005c7fd4: 53001f00    	uxtb	w0, w24
1005c7fd8: f9033e60    	str	x0, [x19, #0x678]
1005c7fdc: f903727c    	str	x28, [x19, #0x6e0]
1005c7fe0: f9037676    	str	x22, [x19, #0x6e8]
1005c7fe4: f9037a7b    	str	x27, [x19, #0x6f0]
1005c7fe8: 53001ee0    	uxtb	w0, w23
1005c7fec: f9038660    	str	x0, [x19, #0x708]
1005c7ff0: f903be7c    	str	x28, [x19, #0x778]
1005c7ff4: f903c276    	str	x22, [x19, #0x780]
1005c7ff8: f903c675    	str	x21, [x19, #0x788]
1005c7ffc: f903ca7b    	str	x27, [x19, #0x790]
1005c8000: 53001dc0    	uxtb	w0, w14
1005c8004: f903d260    	str	x0, [x19, #0x7a0]
1005c8008: f903de6b    	str	x11, [x19, #0x7b8]
1005c800c: f903ee6f    	str	x15, [x19, #0x7d8]
1005c8010: f903fa6a    	str	x10, [x19, #0x7f0]
1005c8014: f9254e66    	str	x6, [x19, #0x4a98]
1005c8018: d29bbe00    	mov	x0, #0xddf0             ; =56816
1005c801c: cb000063    	sub	x3, x3, x0
1005c8020: f9255263    	str	x3, [x19, #0x4aa0]
1005c8024: f9255664    	str	x4, [x19, #0x4aa8]
1005c8028: f84503f4    	ldur	x20, [sp, #0x50]
1005c802c: f9288a74    	str	x20, [x19, #0x5110]
1005c8030: f84083f7    	ldur	x23, [sp, #0x8]
1005c8034: f9289a77    	str	x23, [x19, #0x5130]
1005c8038: f928de6c    	str	x12, [x19, #0x51b8]
1005c803c: f928e262    	str	x2, [x19, #0x51c0]
1005c8040: f928e661    	str	x1, [x19, #0x51c8]
1005c8044: f84103e5    	ldur	x5, [sp, #0x10]
1005c8048: cb0300a3    	sub	x3, x5, x3
1005c804c: d29d1504    	mov	x4, #0xe8a8             ; =59560
1005c8050: 9b048d83    	msub	x3, x12, x4, x3
1005c8054: f928ea63    	str	x3, [x19, #0x51d0]
1005c8058: f84183eb    	ldur	x11, [sp, #0x18]
1005c805c: f928ee6b    	str	x11, [x19, #0x51d8]
1005c8060: f84203ed    	ldur	x13, [sp, #0x20]
1005c8064: f928f26d    	str	x13, [x19, #0x51e0]
1005c8068: f84283e2    	ldur	x2, [sp, #0x28]
1005c806c: f928fa62    	str	x2, [x19, #0x51f0]
1005c8070: f84303ea    	ldur	x10, [sp, #0x30]
1005c8074: f928fe6a    	str	x10, [x19, #0x51f8]
1005c8078: f9290669    	str	x9, [x19, #0x5208]
1005c807c: f9290a67    	str	x7, [x19, #0x5210]
1005c8080: 14000214    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c8084: d2802c60    	mov	x0, #0x163              ; =355
1005c8088: f9002680    	str	x0, [x20, #0x48]
1005c808c: d2800020    	mov	x0, #0x1                ; =1
1005c8090: f80703e0    	stur	x0, [sp, #0x70]
1005c8094: f9001a60    	str	x0, [x19, #0x30]
1005c8098: f84903e0    	ldur	x0, [sp, #0x90]
1005c809c: f9002260    	str	x0, [x19, #0x40]
1005c80a0: d28000c0    	mov	x0, #0x6                ; =6
1005c80a4: f9003260    	str	x0, [x19, #0x60]
1005c80a8: d2800000    	mov	x0, #0x0                ; =0
1005c80ac: f900c660    	str	x0, [x19, #0x188]
1005c80b0: f84703e0    	ldur	x0, [sp, #0x70]
1005c80b4: f900ca60    	str	x0, [x19, #0x190]
1005c80b8: f902e27a    	str	x26, [x19, #0x5c0]
1005c80bc: f902e679    	str	x25, [x19, #0x5c8]
1005c80c0: f84983fa    	ldur	x26, [sp, #0x98]
1005c80c4: 53001f40    	uxtb	w0, w26
1005c80c8: f902f260    	str	x0, [x19, #0x5e0]
1005c80cc: f9032e7c    	str	x28, [x19, #0x658]
1005c80d0: f903327b    	str	x27, [x19, #0x660]
1005c80d4: 53001f00    	uxtb	w0, w24
1005c80d8: f9033e60    	str	x0, [x19, #0x678]
1005c80dc: f903727c    	str	x28, [x19, #0x6e0]
1005c80e0: f9037676    	str	x22, [x19, #0x6e8]
1005c80e4: f9037a7b    	str	x27, [x19, #0x6f0]
1005c80e8: 53001ee0    	uxtb	w0, w23
1005c80ec: f9038660    	str	x0, [x19, #0x708]
1005c80f0: f903be7c    	str	x28, [x19, #0x778]
1005c80f4: f903c276    	str	x22, [x19, #0x780]
1005c80f8: f903c675    	str	x21, [x19, #0x788]
1005c80fc: f903ca7b    	str	x27, [x19, #0x790]
1005c8100: 53001dc0    	uxtb	w0, w14
1005c8104: f903d260    	str	x0, [x19, #0x7a0]
1005c8108: f903ee6f    	str	x15, [x19, #0x7d8]
1005c810c: f903fe68    	str	x8, [x19, #0x7f8]
1005c8110: f9254e66    	str	x6, [x19, #0x4a98]
1005c8114: d29bbe00    	mov	x0, #0xddf0             ; =56816
1005c8118: cb000063    	sub	x3, x3, x0
1005c811c: f9255263    	str	x3, [x19, #0x4aa0]
1005c8120: f9255664    	str	x4, [x19, #0x4aa8]
1005c8124: f84503f4    	ldur	x20, [sp, #0x50]
1005c8128: f9288a74    	str	x20, [x19, #0x5110]
1005c812c: f84083f7    	ldur	x23, [sp, #0x8]
1005c8130: f9289a77    	str	x23, [x19, #0x5130]
1005c8134: f928de6c    	str	x12, [x19, #0x51b8]
1005c8138: f928e262    	str	x2, [x19, #0x51c0]
1005c813c: f928e661    	str	x1, [x19, #0x51c8]
1005c8140: f84103e5    	ldur	x5, [sp, #0x10]
1005c8144: cb0300a1    	sub	x1, x5, x3
1005c8148: d29d1500    	mov	x0, #0xe8a8             ; =59560
1005c814c: 9b008580    	msub	x0, x12, x0, x1
1005c8150: f928ea60    	str	x0, [x19, #0x51d0]
1005c8154: f84183eb    	ldur	x11, [sp, #0x18]
1005c8158: f928ee6b    	str	x11, [x19, #0x51d8]
1005c815c: f84203ed    	ldur	x13, [sp, #0x20]
1005c8160: f928f26d    	str	x13, [x19, #0x51e0]
1005c8164: f84283e2    	ldur	x2, [sp, #0x28]
1005c8168: f928fa62    	str	x2, [x19, #0x51f0]
1005c816c: f84303ea    	ldur	x10, [sp, #0x30]
1005c8170: f928fe6a    	str	x10, [x19, #0x51f8]
1005c8174: f9290669    	str	x9, [x19, #0x5208]
1005c8178: f9290a67    	str	x7, [x19, #0x5210]
1005c817c: 140001d5    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c8180: d2802c80    	mov	x0, #0x164              ; =356
1005c8184: f9002680    	str	x0, [x20, #0x48]
1005c8188: d2800020    	mov	x0, #0x1                ; =1
1005c818c: f80703e0    	stur	x0, [sp, #0x70]
1005c8190: f9001a60    	str	x0, [x19, #0x30]
1005c8194: f84903e0    	ldur	x0, [sp, #0x90]
1005c8198: f9002260    	str	x0, [x19, #0x40]
1005c819c: d28000c0    	mov	x0, #0x6                ; =6
1005c81a0: f9003260    	str	x0, [x19, #0x60]
1005c81a4: d2800000    	mov	x0, #0x0                ; =0
1005c81a8: f900c660    	str	x0, [x19, #0x188]
1005c81ac: f84703e0    	ldur	x0, [sp, #0x70]
1005c81b0: f900ca60    	str	x0, [x19, #0x190]
1005c81b4: f902e27a    	str	x26, [x19, #0x5c0]
1005c81b8: f902e679    	str	x25, [x19, #0x5c8]
1005c81bc: f84983fa    	ldur	x26, [sp, #0x98]
1005c81c0: 53001f45    	uxtb	w5, w26
1005c81c4: f902f265    	str	x5, [x19, #0x5e0]
1005c81c8: f9032e7c    	str	x28, [x19, #0x658]
1005c81cc: f903327b    	str	x27, [x19, #0x660]
1005c81d0: 53001f05    	uxtb	w5, w24
1005c81d4: f9033e65    	str	x5, [x19, #0x678]
1005c81d8: f903727c    	str	x28, [x19, #0x6e0]
1005c81dc: f9037676    	str	x22, [x19, #0x6e8]
1005c81e0: f9037a7b    	str	x27, [x19, #0x6f0]
1005c81e4: 53001eea    	uxtb	w10, w23
1005c81e8: f903866a    	str	x10, [x19, #0x708]
1005c81ec: f903be7c    	str	x28, [x19, #0x778]
1005c81f0: f903c276    	str	x22, [x19, #0x780]
1005c81f4: f903c675    	str	x21, [x19, #0x788]
1005c81f8: f903ca7b    	str	x27, [x19, #0x790]
1005c81fc: 53001dcd    	uxtb	w13, w14
1005c8200: f903d26d    	str	x13, [x19, #0x7a0]
1005c8204: f903ee6f    	str	x15, [x19, #0x7d8]
1005c8208: f903fe68    	str	x8, [x19, #0x7f8]
1005c820c: f904026b    	str	x11, [x19, #0x800]
1005c8210: f9254e66    	str	x6, [x19, #0x4a98]
1005c8214: d29bbe00    	mov	x0, #0xddf0             ; =56816
1005c8218: cb000063    	sub	x3, x3, x0
1005c821c: f9255263    	str	x3, [x19, #0x4aa0]
1005c8220: f9255664    	str	x4, [x19, #0x4aa8]
1005c8224: f84503f4    	ldur	x20, [sp, #0x50]
1005c8228: f9288a74    	str	x20, [x19, #0x5110]
1005c822c: f84083f7    	ldur	x23, [sp, #0x8]
1005c8230: f9289a77    	str	x23, [x19, #0x5130]
1005c8234: f928de6c    	str	x12, [x19, #0x51b8]
1005c8238: f928e262    	str	x2, [x19, #0x51c0]
1005c823c: f928e661    	str	x1, [x19, #0x51c8]
1005c8240: f84103e5    	ldur	x5, [sp, #0x10]
1005c8244: cb0300a1    	sub	x1, x5, x3
1005c8248: d29d1500    	mov	x0, #0xe8a8             ; =59560
1005c824c: 9b008580    	msub	x0, x12, x0, x1
1005c8250: f928ea60    	str	x0, [x19, #0x51d0]
1005c8254: f84183eb    	ldur	x11, [sp, #0x18]
1005c8258: f928ee6b    	str	x11, [x19, #0x51d8]
1005c825c: f84203ed    	ldur	x13, [sp, #0x20]
1005c8260: f928f26d    	str	x13, [x19, #0x51e0]
1005c8264: f84283e2    	ldur	x2, [sp, #0x28]
1005c8268: f928fa62    	str	x2, [x19, #0x51f0]
1005c826c: f84303ea    	ldur	x10, [sp, #0x30]
1005c8270: f928fe6a    	str	x10, [x19, #0x51f8]
1005c8274: f9290669    	str	x9, [x19, #0x5208]
1005c8278: f9290a67    	str	x7, [x19, #0x5210]
1005c827c: 14000195    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c8280: d2802ca0    	mov	x0, #0x165              ; =357
1005c8284: f9002680    	str	x0, [x20, #0x48]
1005c8288: d2800020    	mov	x0, #0x1                ; =1
1005c828c: f80703e0    	stur	x0, [sp, #0x70]
1005c8290: f9001a60    	str	x0, [x19, #0x30]
1005c8294: f84903e0    	ldur	x0, [sp, #0x90]
1005c8298: f9002260    	str	x0, [x19, #0x40]
1005c829c: d28000c0    	mov	x0, #0x6                ; =6
1005c82a0: f9003260    	str	x0, [x19, #0x60]
1005c82a4: d2800000    	mov	x0, #0x0                ; =0
1005c82a8: f900c660    	str	x0, [x19, #0x188]
1005c82ac: f84703e0    	ldur	x0, [sp, #0x70]
1005c82b0: f900ca60    	str	x0, [x19, #0x190]
1005c82b4: f902e27a    	str	x26, [x19, #0x5c0]
1005c82b8: f902e679    	str	x25, [x19, #0x5c8]
1005c82bc: f84983fa    	ldur	x26, [sp, #0x98]
1005c82c0: 53001f40    	uxtb	w0, w26
1005c82c4: f902f260    	str	x0, [x19, #0x5e0]
1005c82c8: f9032e7c    	str	x28, [x19, #0x658]
1005c82cc: f903327b    	str	x27, [x19, #0x660]
1005c82d0: 53001f00    	uxtb	w0, w24
1005c82d4: f9033e60    	str	x0, [x19, #0x678]
1005c82d8: f903727c    	str	x28, [x19, #0x6e0]
1005c82dc: f9037676    	str	x22, [x19, #0x6e8]
1005c82e0: f9037a7b    	str	x27, [x19, #0x6f0]
1005c82e4: 53001ee0    	uxtb	w0, w23
1005c82e8: f9038660    	str	x0, [x19, #0x708]
1005c82ec: f903be7c    	str	x28, [x19, #0x778]
1005c82f0: f903c276    	str	x22, [x19, #0x780]
1005c82f4: f903c675    	str	x21, [x19, #0x788]
1005c82f8: f903ca7b    	str	x27, [x19, #0x790]
1005c82fc: 53001dc0    	uxtb	w0, w14
1005c8300: f903d260    	str	x0, [x19, #0x7a0]
1005c8304: f903ee6f    	str	x15, [x19, #0x7d8]
1005c8308: f903fe68    	str	x8, [x19, #0x7f8]
1005c830c: 9b0b7de0    	mul	x0, x15, x11
1005c8310: f9040660    	str	x0, [x19, #0x808]
1005c8314: f9254e66    	str	x6, [x19, #0x4a98]
1005c8318: d29bbe00    	mov	x0, #0xddf0             ; =56816
1005c831c: cb000063    	sub	x3, x3, x0
1005c8320: f9255263    	str	x3, [x19, #0x4aa0]
1005c8324: f9255664    	str	x4, [x19, #0x4aa8]
1005c8328: f84503f4    	ldur	x20, [sp, #0x50]
1005c832c: f9288a74    	str	x20, [x19, #0x5110]
1005c8330: f84083f7    	ldur	x23, [sp, #0x8]
1005c8334: f9289a77    	str	x23, [x19, #0x5130]
1005c8338: f928de6c    	str	x12, [x19, #0x51b8]
1005c833c: f928e262    	str	x2, [x19, #0x51c0]
1005c8340: f928e661    	str	x1, [x19, #0x51c8]
1005c8344: f84103e5    	ldur	x5, [sp, #0x10]
1005c8348: cb0300a5    	sub	x5, x5, x3
1005c834c: d29d1506    	mov	x6, #0xe8a8             ; =59560
1005c8350: 9b069585    	msub	x5, x12, x6, x5
1005c8354: f928ea65    	str	x5, [x19, #0x51d0]
1005c8358: f84183eb    	ldur	x11, [sp, #0x18]
1005c835c: f928ee6b    	str	x11, [x19, #0x51d8]
1005c8360: f84203ed    	ldur	x13, [sp, #0x20]
1005c8364: f928f26d    	str	x13, [x19, #0x51e0]
1005c8368: f84283e2    	ldur	x2, [sp, #0x28]
1005c836c: f928fa62    	str	x2, [x19, #0x51f0]
1005c8370: f84303ea    	ldur	x10, [sp, #0x30]
1005c8374: f928fe6a    	str	x10, [x19, #0x51f8]
1005c8378: f9290669    	str	x9, [x19, #0x5208]
1005c837c: f9290a67    	str	x7, [x19, #0x5210]
1005c8380: 14000154    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c8384: d2802cc0    	mov	x0, #0x166              ; =358
1005c8388: f9002680    	str	x0, [x20, #0x48]
1005c838c: d2800020    	mov	x0, #0x1                ; =1
1005c8390: f80703e0    	stur	x0, [sp, #0x70]
1005c8394: f9001a60    	str	x0, [x19, #0x30]
1005c8398: f84903e0    	ldur	x0, [sp, #0x90]
1005c839c: f9002260    	str	x0, [x19, #0x40]
1005c83a0: d28000c0    	mov	x0, #0x6                ; =6
1005c83a4: f9003260    	str	x0, [x19, #0x60]
1005c83a8: d2800000    	mov	x0, #0x0                ; =0
1005c83ac: f900c660    	str	x0, [x19, #0x188]
1005c83b0: f84703e0    	ldur	x0, [sp, #0x70]
1005c83b4: f900ca60    	str	x0, [x19, #0x190]
1005c83b8: f902e27a    	str	x26, [x19, #0x5c0]
1005c83bc: f902e679    	str	x25, [x19, #0x5c8]
1005c83c0: f84983fa    	ldur	x26, [sp, #0x98]
1005c83c4: 53001f40    	uxtb	w0, w26
1005c83c8: f902f260    	str	x0, [x19, #0x5e0]
1005c83cc: f9032e7c    	str	x28, [x19, #0x658]
1005c83d0: f903327b    	str	x27, [x19, #0x660]
1005c83d4: 53001f00    	uxtb	w0, w24
1005c83d8: f9033e60    	str	x0, [x19, #0x678]
1005c83dc: f903727c    	str	x28, [x19, #0x6e0]
1005c83e0: f9037676    	str	x22, [x19, #0x6e8]
1005c83e4: f9037a7b    	str	x27, [x19, #0x6f0]
1005c83e8: 53001ee0    	uxtb	w0, w23
1005c83ec: f9038660    	str	x0, [x19, #0x708]
1005c83f0: f903be7c    	str	x28, [x19, #0x778]
1005c83f4: f903c276    	str	x22, [x19, #0x780]
1005c83f8: f903c675    	str	x21, [x19, #0x788]
1005c83fc: f903ca7b    	str	x27, [x19, #0x790]
1005c8400: 53001dc0    	uxtb	w0, w14
1005c8404: f903d260    	str	x0, [x19, #0x7a0]
1005c8408: f903fe68    	str	x8, [x19, #0x7f8]
1005c840c: f904066a    	str	x10, [x19, #0x808]
1005c8410: d10009e0    	sub	x0, x15, #0x2
1005c8414: f9040a60    	str	x0, [x19, #0x810]
1005c8418: f9254e66    	str	x6, [x19, #0x4a98]
1005c841c: d29bbe00    	mov	x0, #0xddf0             ; =56816
1005c8420: cb000063    	sub	x3, x3, x0
1005c8424: f9255263    	str	x3, [x19, #0x4aa0]
1005c8428: f9255664    	str	x4, [x19, #0x4aa8]
1005c842c: f84503f4    	ldur	x20, [sp, #0x50]
1005c8430: f9288a74    	str	x20, [x19, #0x5110]
1005c8434: f84083f7    	ldur	x23, [sp, #0x8]
1005c8438: f9289a77    	str	x23, [x19, #0x5130]
1005c843c: f928de6c    	str	x12, [x19, #0x51b8]
1005c8440: f928e262    	str	x2, [x19, #0x51c0]
1005c8444: f928e661    	str	x1, [x19, #0x51c8]
1005c8448: f84103e5    	ldur	x5, [sp, #0x10]
1005c844c: cb0300a1    	sub	x1, x5, x3
1005c8450: d29d1500    	mov	x0, #0xe8a8             ; =59560
1005c8454: 9b008580    	msub	x0, x12, x0, x1
1005c8458: f928ea60    	str	x0, [x19, #0x51d0]
1005c845c: f84183eb    	ldur	x11, [sp, #0x18]
1005c8460: f928ee6b    	str	x11, [x19, #0x51d8]
1005c8464: f84203ed    	ldur	x13, [sp, #0x20]
1005c8468: f928f26d    	str	x13, [x19, #0x51e0]
1005c846c: f84283e2    	ldur	x2, [sp, #0x28]
1005c8470: f928fa62    	str	x2, [x19, #0x51f0]
1005c8474: f84303ea    	ldur	x10, [sp, #0x30]
1005c8478: f928fe6a    	str	x10, [x19, #0x51f8]
1005c847c: f9290669    	str	x9, [x19, #0x5208]
1005c8480: f9290a67    	str	x7, [x19, #0x5210]
1005c8484: 14000113    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c8488: d2802d00    	mov	x0, #0x168              ; =360
1005c848c: f9002680    	str	x0, [x20, #0x48]
1005c8490: d2800020    	mov	x0, #0x1                ; =1
1005c8494: f80703e0    	stur	x0, [sp, #0x70]
1005c8498: f9001a60    	str	x0, [x19, #0x30]
1005c849c: f84903e0    	ldur	x0, [sp, #0x90]
1005c84a0: f9002260    	str	x0, [x19, #0x40]
1005c84a4: d28000c5    	mov	x5, #0x6                ; =6
1005c84a8: f9003265    	str	x5, [x19, #0x60]
1005c84ac: d2800005    	mov	x5, #0x0                ; =0
1005c84b0: f900c665    	str	x5, [x19, #0x188]
1005c84b4: f84703e0    	ldur	x0, [sp, #0x70]
1005c84b8: f900ca60    	str	x0, [x19, #0x190]
1005c84bc: f902e27a    	str	x26, [x19, #0x5c0]
1005c84c0: f902e679    	str	x25, [x19, #0x5c8]
1005c84c4: f84983fa    	ldur	x26, [sp, #0x98]
1005c84c8: 53001f4b    	uxtb	w11, w26
1005c84cc: f902f26b    	str	x11, [x19, #0x5e0]
1005c84d0: f9032e7c    	str	x28, [x19, #0x658]
1005c84d4: f903327b    	str	x27, [x19, #0x660]
1005c84d8: 53001f0b    	uxtb	w11, w24
1005c84dc: f9033e6b    	str	x11, [x19, #0x678]
1005c84e0: f903727c    	str	x28, [x19, #0x6e0]
1005c84e4: f9037676    	str	x22, [x19, #0x6e8]
1005c84e8: f9037a7b    	str	x27, [x19, #0x6f0]
1005c84ec: 53001eed    	uxtb	w13, w23
1005c84f0: f903866d    	str	x13, [x19, #0x708]
1005c84f4: f903be7c    	str	x28, [x19, #0x778]
1005c84f8: f903c276    	str	x22, [x19, #0x780]
1005c84fc: f903c675    	str	x21, [x19, #0x788]
1005c8500: f903ca7b    	str	x27, [x19, #0x790]
1005c8504: 53001dc0    	uxtb	w0, w14
1005c8508: f903d260    	str	x0, [x19, #0x7a0]
1005c850c: f903fe68    	str	x8, [x19, #0x7f8]
1005c8510: f904126a    	str	x10, [x19, #0x820]
1005c8514: f9254e66    	str	x6, [x19, #0x4a98]
1005c8518: d29bbe00    	mov	x0, #0xddf0             ; =56816
1005c851c: cb000063    	sub	x3, x3, x0
1005c8520: f9255263    	str	x3, [x19, #0x4aa0]
1005c8524: f9255664    	str	x4, [x19, #0x4aa8]
1005c8528: f84503f4    	ldur	x20, [sp, #0x50]
1005c852c: f9288a74    	str	x20, [x19, #0x5110]
1005c8530: f84083f7    	ldur	x23, [sp, #0x8]
1005c8534: f9289a77    	str	x23, [x19, #0x5130]
1005c8538: f928de6c    	str	x12, [x19, #0x51b8]
1005c853c: f928e262    	str	x2, [x19, #0x51c0]
1005c8540: f928e661    	str	x1, [x19, #0x51c8]
1005c8544: f84103e5    	ldur	x5, [sp, #0x10]
1005c8548: cb0300a1    	sub	x1, x5, x3
1005c854c: d29d1500    	mov	x0, #0xe8a8             ; =59560
1005c8550: 9b008580    	msub	x0, x12, x0, x1
1005c8554: f928ea60    	str	x0, [x19, #0x51d0]
1005c8558: f84183eb    	ldur	x11, [sp, #0x18]
1005c855c: f928ee6b    	str	x11, [x19, #0x51d8]
1005c8560: f84203ed    	ldur	x13, [sp, #0x20]
1005c8564: f928f26d    	str	x13, [x19, #0x51e0]
1005c8568: f84283e2    	ldur	x2, [sp, #0x28]
1005c856c: f928fa62    	str	x2, [x19, #0x51f0]
1005c8570: f84303ea    	ldur	x10, [sp, #0x30]
1005c8574: f928fe6a    	str	x10, [x19, #0x51f8]
1005c8578: f9290669    	str	x9, [x19, #0x5208]
1005c857c: f9290a67    	str	x7, [x19, #0x5210]
1005c8580: 140000d4    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c8584: d2802d20    	mov	x0, #0x169              ; =361
1005c8588: f9002680    	str	x0, [x20, #0x48]
1005c858c: d2800000    	mov	x0, #0x0                ; =0
1005c8590: f9254e60    	str	x0, [x19, #0x4a98]
1005c8594: d2800060    	mov	x0, #0x3                ; =3
1005c8598: f84d83e8    	ldur	x8, [sp, #0xd8]
1005c859c: f80703e0    	stur	x0, [sp, #0x70]
1005c85a0: f101691f    	cmp	x8, #0x5a
1005c85a4: 54ff5a02    	b.hs	0x1005c70e4 <_mech_canonical_program_entry_v1_numeric_256+0x15e4>
1005c85a8: 140000ca    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c85ac: f84903e0    	ldur	x0, [sp, #0x90]
1005c85b0: f80703e0    	stur	x0, [sp, #0x70]
1005c85b4: 140000c7    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c85b8: d280346e    	mov	x14, #0x1a3             ; =419
1005c85bc: f900268e    	str	x14, [x20, #0x48]
1005c85c0: d280000f    	mov	x15, #0x0               ; =0
1005c85c4: f9254e6f    	str	x15, [x19, #0x4a98]
1005c85c8: d2800060    	mov	x0, #0x3                ; =3
1005c85cc: f84d83ea    	ldur	x10, [sp, #0xd8]
1005c85d0: f80703e0    	stur	x0, [sp, #0x70]
1005c85d4: f101695f    	cmp	x10, #0x5a
1005c85d8: 54ff6be2    	b.hs	0x1005c7354 <_mech_canonical_program_entry_v1_numeric_256+0x1854>
1005c85dc: 140000bd    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c85e0: d2803580    	mov	x0, #0x1ac              ; =428
1005c85e4: f9002680    	str	x0, [x20, #0x48]
1005c85e8: d2800020    	mov	x0, #0x1                ; =1
1005c85ec: f80703e0    	stur	x0, [sp, #0x70]
1005c85f0: f9001a60    	str	x0, [x19, #0x30]
1005c85f4: d2800040    	mov	x0, #0x2                ; =2
1005c85f8: f9002260    	str	x0, [x19, #0x40]
1005c85fc: d28000c0    	mov	x0, #0x6                ; =6
1005c8600: f9003260    	str	x0, [x19, #0x60]
1005c8604: d2800000    	mov	x0, #0x0                ; =0
1005c8608: f900c660    	str	x0, [x19, #0x188]
1005c860c: f84703e0    	ldur	x0, [sp, #0x70]
1005c8610: f900ca60    	str	x0, [x19, #0x190]
1005c8614: f902e275    	str	x21, [x19, #0x5c0]
1005c8618: f902e679    	str	x25, [x19, #0x5c8]
1005c861c: f9254e66    	str	x6, [x19, #0x4a98]
1005c8620: f9255263    	str	x3, [x19, #0x4aa0]
1005c8624: f9255664    	str	x4, [x19, #0x4aa8]
1005c8628: f84503f4    	ldur	x20, [sp, #0x50]
1005c862c: f9288a74    	str	x20, [x19, #0x5110]
1005c8630: f84083f7    	ldur	x23, [sp, #0x8]
1005c8634: f9289a77    	str	x23, [x19, #0x5130]
1005c8638: f928de6c    	str	x12, [x19, #0x51b8]
1005c863c: f928e262    	str	x2, [x19, #0x51c0]
1005c8640: f928e661    	str	x1, [x19, #0x51c8]
1005c8644: f84103e5    	ldur	x5, [sp, #0x10]
1005c8648: cb0300a0    	sub	x0, x5, x3
1005c864c: d29d1501    	mov	x1, #0xe8a8             ; =59560
1005c8650: 9b018180    	msub	x0, x12, x1, x0
1005c8654: f928ea60    	str	x0, [x19, #0x51d0]
1005c8658: f928ee6b    	str	x11, [x19, #0x51d8]
1005c865c: f928f268    	str	x8, [x19, #0x51e0]
1005c8660: f928fa6d    	str	x13, [x19, #0x51f0]
1005c8664: f928fe76    	str	x22, [x19, #0x51f8]
1005c8668: f9290669    	str	x9, [x19, #0x5208]
1005c866c: f9290a67    	str	x7, [x19, #0x5210]
1005c8670: 14000098    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c8674: d2803240    	mov	x0, #0x192              ; =402
1005c8678: f9002680    	str	x0, [x20, #0x48]
1005c867c: d2800020    	mov	x0, #0x1                ; =1
1005c8680: f80703e0    	stur	x0, [sp, #0x70]
1005c8684: f9001a60    	str	x0, [x19, #0x30]
1005c8688: f84903ee    	ldur	x14, [sp, #0x90]
1005c868c: f900226e    	str	x14, [x19, #0x40]
1005c8690: d28000c0    	mov	x0, #0x6                ; =6
1005c8694: f9003260    	str	x0, [x19, #0x60]
1005c8698: d2800000    	mov	x0, #0x0                ; =0
1005c869c: f900c660    	str	x0, [x19, #0x188]
1005c86a0: f84703e0    	ldur	x0, [sp, #0x70]
1005c86a4: f900ca60    	str	x0, [x19, #0x190]
1005c86a8: f902e27a    	str	x26, [x19, #0x5c0]
1005c86ac: f902e679    	str	x25, [x19, #0x5c8]
1005c86b0: f84983fa    	ldur	x26, [sp, #0x98]
1005c86b4: 53001f40    	uxtb	w0, w26
1005c86b8: f902f260    	str	x0, [x19, #0x5e0]
1005c86bc: f9032e7c    	str	x28, [x19, #0x658]
1005c86c0: f903327b    	str	x27, [x19, #0x660]
1005c86c4: f9254e66    	str	x6, [x19, #0x4a98]
1005c86c8: f9255263    	str	x3, [x19, #0x4aa0]
1005c86cc: f9255664    	str	x4, [x19, #0x4aa8]
1005c86d0: f84503f4    	ldur	x20, [sp, #0x50]
1005c86d4: f9288a74    	str	x20, [x19, #0x5110]
1005c86d8: f84083f7    	ldur	x23, [sp, #0x8]
1005c86dc: f9289a77    	str	x23, [x19, #0x5130]
1005c86e0: f928de6c    	str	x12, [x19, #0x51b8]
1005c86e4: f928e262    	str	x2, [x19, #0x51c0]
1005c86e8: f928e661    	str	x1, [x19, #0x51c8]
1005c86ec: f84103e5    	ldur	x5, [sp, #0x10]
1005c86f0: cb0300a8    	sub	x8, x5, x3
1005c86f4: d29d150a    	mov	x10, #0xe8a8            ; =59560
1005c86f8: 9b0aa188    	msub	x8, x12, x10, x8
1005c86fc: f928ea68    	str	x8, [x19, #0x51d0]
1005c8700: f84183eb    	ldur	x11, [sp, #0x18]
1005c8704: f928ee6b    	str	x11, [x19, #0x51d8]
1005c8708: f84203e0    	ldur	x0, [sp, #0x20]
1005c870c: f928f260    	str	x0, [x19, #0x51e0]
1005c8710: f928fa6d    	str	x13, [x19, #0x51f0]
1005c8714: f928fe76    	str	x22, [x19, #0x51f8]
1005c8718: f9290669    	str	x9, [x19, #0x5208]
1005c871c: f9290a67    	str	x7, [x19, #0x5210]
1005c8720: 1400006c    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c8724: d2803040    	mov	x0, #0x182              ; =386
1005c8728: f9002680    	str	x0, [x20, #0x48]
1005c872c: d2800020    	mov	x0, #0x1                ; =1
1005c8730: f80703e0    	stur	x0, [sp, #0x70]
1005c8734: f9001a60    	str	x0, [x19, #0x30]
1005c8738: f84903ee    	ldur	x14, [sp, #0x90]
1005c873c: f900226e    	str	x14, [x19, #0x40]
1005c8740: d28000c0    	mov	x0, #0x6                ; =6
1005c8744: f9003260    	str	x0, [x19, #0x60]
1005c8748: d2800000    	mov	x0, #0x0                ; =0
1005c874c: f900c660    	str	x0, [x19, #0x188]
1005c8750: f84703e0    	ldur	x0, [sp, #0x70]
1005c8754: f900ca60    	str	x0, [x19, #0x190]
1005c8758: f902e27a    	str	x26, [x19, #0x5c0]
1005c875c: f902e679    	str	x25, [x19, #0x5c8]
1005c8760: f84983fa    	ldur	x26, [sp, #0x98]
1005c8764: 53001f40    	uxtb	w0, w26
1005c8768: f902f260    	str	x0, [x19, #0x5e0]
1005c876c: f9032e7c    	str	x28, [x19, #0x658]
1005c8770: f903327b    	str	x27, [x19, #0x660]
1005c8774: 53001f00    	uxtb	w0, w24
1005c8778: f9033e60    	str	x0, [x19, #0x678]
1005c877c: f903727c    	str	x28, [x19, #0x6e0]
1005c8780: f9037676    	str	x22, [x19, #0x6e8]
1005c8784: f9037a7b    	str	x27, [x19, #0x6f0]
1005c8788: f9254e66    	str	x6, [x19, #0x4a98]
1005c878c: f9255263    	str	x3, [x19, #0x4aa0]
1005c8790: f9255664    	str	x4, [x19, #0x4aa8]
1005c8794: f84503f4    	ldur	x20, [sp, #0x50]
1005c8798: f9288a74    	str	x20, [x19, #0x5110]
1005c879c: f84083f7    	ldur	x23, [sp, #0x8]
1005c87a0: f9289a77    	str	x23, [x19, #0x5130]
1005c87a4: f928de6c    	str	x12, [x19, #0x51b8]
1005c87a8: f928e262    	str	x2, [x19, #0x51c0]
1005c87ac: f928e661    	str	x1, [x19, #0x51c8]
1005c87b0: f84103e5    	ldur	x5, [sp, #0x10]
1005c87b4: cb0300a0    	sub	x0, x5, x3
1005c87b8: d29d1501    	mov	x1, #0xe8a8             ; =59560
1005c87bc: 9b018180    	msub	x0, x12, x1, x0
1005c87c0: f928ea60    	str	x0, [x19, #0x51d0]
1005c87c4: f84183eb    	ldur	x11, [sp, #0x18]
1005c87c8: f928ee6b    	str	x11, [x19, #0x51d8]
1005c87cc: f84203ed    	ldur	x13, [sp, #0x20]
1005c87d0: f928f26d    	str	x13, [x19, #0x51e0]
1005c87d4: f84283e2    	ldur	x2, [sp, #0x28]
1005c87d8: f928fa62    	str	x2, [x19, #0x51f0]
1005c87dc: f84303ea    	ldur	x10, [sp, #0x30]
1005c87e0: f928fe6a    	str	x10, [x19, #0x51f8]
1005c87e4: f9290669    	str	x9, [x19, #0x5208]
1005c87e8: f9290a67    	str	x7, [x19, #0x5210]
1005c87ec: 14000039    	b	0x1005c88d0 <_mech_canonical_program_entry_v1_numeric_256+0x2dd0>
1005c87f0: d2802e40    	mov	x0, #0x172              ; =370
1005c87f4: f9002680    	str	x0, [x20, #0x48]
1005c87f8: d2800020    	mov	x0, #0x1                ; =1
1005c87fc: f80703e0    	stur	x0, [sp, #0x70]
1005c8800: f9001a60    	str	x0, [x19, #0x30]
1005c8804: f84903ee    	ldur	x14, [sp, #0x90]
1005c8808: f900226e    	str	x14, [x19, #0x40]
1005c880c: d28000c0    	mov	x0, #0x6                ; =6
1005c8810: f9003260    	str	x0, [x19, #0x60]
1005c8814: d2800005    	mov	x5, #0x0                ; =0
1005c8818: f900c665    	str	x5, [x19, #0x188]
1005c881c: f84703e0    	ldur	x0, [sp, #0x70]
1005c8820: f900ca60    	str	x0, [x19, #0x190]
1005c8824: f902e27a    	str	x26, [x19, #0x5c0]
1005c8828: f902e679    	str	x25, [x19, #0x5c8]
1005c882c: f84983fa    	ldur	x26, [sp, #0x98]
1005c8830: 53001f45    	uxtb	w5, w26
1005c8834: f902f265    	str	x5, [x19, #0x5e0]
1005c8838: f9032e7c    	str	x28, [x19, #0x658]
1005c883c: f903327b    	str	x27, [x19, #0x660]
1005c8840: 53001f0a    	uxtb	w10, w24
1005c8844: f9033e6a    	str	x10, [x19, #0x678]
1005c8848: f903727c    	str	x28, [x19, #0x6e0]
1005c884c: f9037676    	str	x22, [x19, #0x6e8]
1005c8850: f9037a7b    	str	x27, [x19, #0x6f0]
1005c8854: 53001eed    	uxtb	w13, w23
1005c8858: f903866d    	str	x13, [x19, #0x708]
1005c885c: f903be7c    	str	x28, [x19, #0x778]
1005c8860: f903c276    	str	x22, [x19, #0x780]
1005c8864: f903c668    	str	x8, [x19, #0x788]
1005c8868: f903ca7b    	str	x27, [x19, #0x790]
1005c886c: f9254e66    	str	x6, [x19, #0x4a98]
1005c8870: f9255263    	str	x3, [x19, #0x4aa0]
1005c8874: f9255664    	str	x4, [x19, #0x4aa8]
1005c8878: f84503f4    	ldur	x20, [sp, #0x50]
1005c887c: f9288a74    	str	x20, [x19, #0x5110]
1005c8880: f84083f7    	ldur	x23, [sp, #0x8]
1005c8884: f9289a77    	str	x23, [x19, #0x5130]
1005c8888: f928de6c    	str	x12, [x19, #0x51b8]
1005c888c: f928e262    	str	x2, [x19, #0x51c0]
1005c8890: f928e661    	str	x1, [x19, #0x51c8]
1005c8894: f84103e5    	ldur	x5, [sp, #0x10]
1005c8898: cb0300a0    	sub	x0, x5, x3
1005c889c: d29d1501    	mov	x1, #0xe8a8             ; =59560
1005c88a0: 9b018180    	msub	x0, x12, x1, x0
1005c88a4: f928ea60    	str	x0, [x19, #0x51d0]
1005c88a8: f84183eb    	ldur	x11, [sp, #0x18]
1005c88ac: f928ee6b    	str	x11, [x19, #0x51d8]
1005c88b0: f84203ed    	ldur	x13, [sp, #0x20]
1005c88b4: f928f26d    	str	x13, [x19, #0x51e0]
1005c88b8: f84283e2    	ldur	x2, [sp, #0x28]
1005c88bc: f928fa62    	str	x2, [x19, #0x51f0]
1005c88c0: f84303ea    	ldur	x10, [sp, #0x30]
1005c88c4: f928fe6a    	str	x10, [x19, #0x51f8]
1005c88c8: f9290669    	str	x9, [x19, #0x5208]
1005c88cc: f9290a67    	str	x7, [x19, #0x5210]
1005c88d0: d2800001    	mov	x1, #0x0                ; =0
1005c88d4: f84703e0    	ldur	x0, [sp, #0x70]
1005c88d8: 910403ff    	add	sp, sp, #0x100
1005c88dc: a8c153f3    	ldp	x19, x20, [sp], #0x10
1005c88e0: a8c15bf5    	ldp	x21, x22, [sp], #0x10
1005c88e4: a8c163f7    	ldp	x23, x24, [sp], #0x10
1005c88e8: a8c16bf9    	ldp	x25, x26, [sp], #0x10
1005c88ec: a8c173fb    	ldp	x27, x28, [sp], #0x10
1005c88f0: a8c17bfd    	ldp	x29, x30, [sp], #0x10
1005c88f4: d65f0fff    	retab
1005c88f8: 0000c11f    	udf	#0xc11f
1005c88fc: 0000c11f    	udf	#0xc11f
