from pathlib import Path
import json,shutil,subprocess,hashlib,os,time
P=Path(__file__).parent;B=Path('/private/tmp/mech-related-u8-ids-u32-rank-rust-control-20261106-v1');RUST=Path('/Users/cim310/.rustup/toolchains/nightly-2026-03-03-aarch64-apple-darwin/bin')
original=(B/'src/main.rs').read_text();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sub=original[original.index('fn subsets('):original.index('fn index(')]
gen=original[original.index('fn generate('):original.index('fn main()')]
extra='''
// Private producer contract: ids are canonical indices from words and v<=64.
fn eligibility(offsets:&[u64],ids:&[u64],v:u64)->(bool,bool,Vec<u64>) {
    let n=offsets.len()-1;
    if !(3..=64).contains(&v)||(n as u64)>LOW {return(false,false,Vec::new());}
    let mut masks=if REUSE_MASKS {Vec::with_capacity(n)}else{Vec::new()};
    let mut ordered=true;
    for post in 0..n {
        let slice=&ids[offsets[post] as usize..offsets[post+1] as usize];
        if slice.len()>8 {return(false,false,Vec::new());}
        let mut mask=0u64;
        for &id in slice {
            let bit=1u64<<id;
            if mask&bit!=0 {return(false,false,Vec::new());}
            if USE_ORDERED_KEYS && bit<=mask {ordered=false;}
            mask|=bit;
        }
        if REUSE_MASKS {masks.push(mask);}
    }
    (true,USE_ORDERED_KEYS&&ordered,masks)
}
const fn binomials(width:u32)->[u32;64] {
    let mut table=[0;64];let mut n=0;
    while n<64 {
        let x=n as u32;
        table[n]=if x<width{0}else{match width{
            2=>x*(x-1)/2,
            3=>x*(x-1)*(x-2)/6,
            4=>x*(x-1)*(x-2)*(x-3)/24,
            _=>0,
        }};n+=1;
    }
    table
}
const C2:[u32;64]=binomials(2);
const C3:[u32;64]=binomials(3);
const C4:[u32;64]=binomials(4);
fn ordered3(a:u8,b:u8,c:u8)->u64 {
    if USE_TABLES {u64::from(u32::from(a)+C2[b as usize]+C3[c as usize])}
    else {let(a,b,c)=(u32::from(a),u32::from(b),u32::from(c));u64::from(a+b*(b-1)/2+c*(c-1)*(c-2)/6)}
}
fn ordered4(a:u8,b:u8,c:u8,d:u8)->u64 {
    if USE_TABLES {u64::from(u32::from(a)+C2[b as usize]+C3[c as usize]+C4[d as usize])}
    else {let(a,b,c,d)=(u32::from(a),u32::from(b),u32::from(c),u32::from(d));u64::from(a+b*(b-1)/2+c*(c-1)*(c-2)/6+d*(d-1)*(d-2)*(d-3)/24)}
}
fn subset_dispatch(offsets:&[u64],ids:&[u8],width:usize,ordered:bool)->(Vec<u64>,Vec<u64>){
    if ordered {subsets::<true>(offsets,ids,width)}else{subsets::<false>(offsets,ids,width)}
}
'''
modified=original.replace(sub,sub.replace('fn subsets(','fn subsets<const ORDERED:bool>(').replace('key3(ids[a],ids[b],ids[c])','if ORDERED {ordered3(ids[a],ids[b],ids[c])}else{key3(ids[a],ids[b],ids[c])}').replace('key4(ids[a],ids[b],ids[c],ids[d])','if ORDERED {ordered4(ids[a],ids[b],ids[c],ids[d])}else{key4(ids[a],ids[b],ids[c],ids[d])}'))
start=modified.index('    let eligible=(3..=64)');end=modified.index('    phase.insert("interning_and_eligibility_seconds"',start)
modified=modified[:start]+'    let (eligible,ordered,eligibility_masks)=eligibility(offsets,&ids,v);\n'+modified[end:]
modified=modified.replace('subsets(offsets,&byte_ids,3)','subset_dispatch(offsets,&byte_ids,3,ordered)').replace('subsets(offsets,&byte_ids,4)','subset_dispatch(offsets,&byte_ids,4,ordered)')
needle='let masks:Vec<u64>=(0..n).map(|p|(offsets[p]..offsets[p+1]).fold(0,|mask,i|mask|1u64.wrapping_shl(ids[i as usize]as u32))).collect();'
assert modified.count(needle)==1
modified=modified.replace(needle,'let masks:Vec<u64>=if REUSE_MASKS {eligibility_masks}else{(0..n).map(|p|(offsets[p]..offsets[p+1]).fold(0,|mask,i|mask|1u64.wrapping_shl(ids[i as usize]as u32))).collect()};')
modified=modified.replace('fn main()->io::Result<()> {',extra+'\nfn main()->io::Result<()> {')
# The old generation/key ordering remains an independent test-only baseline.
tests='''
#[cfg(test)]
mod ordered_control_tests {
    use super::*;
BASELINE
    #[test]
    fn ordered_combinadics_match_all_small_subsets_and_unsorted_permutations(){
        for a in 0u8..64 {for b in a+1..64 {for c in b+1..64 {
            let k=ordered3(a,b,c);
            for [x,y,z] in [[a,b,c],[a,c,b],[b,a,c],[b,c,a],[c,a,b],[c,b,a]] {assert_eq!(k,key3(x,y,z));}
            for d in c+1..64 {
                let want=ordered4(a,b,c,d);let values=[a,b,c,d];
                for i in 0..4 {for j in 0..4 {if i==j{continue;}for k in 0..4 {if k==i||k==j{continue;}let l=6-i-j-k;assert_eq!(want,key4(values[i],values[j],values[k],values[l]));}}}
            }
        }}}
    }
    #[test]
    fn mask_eligibility_preserves_unique_unordered_and_width_fallbacks(){
        let cases=[(vec![0,1,63],64,true,true),(vec![63,0,1],64,true,false),(vec![1,1,2],3,false,false),(vec![0,1,2],65,false,false),(vec![0,1,2,3,4,5,6,7,8],9,false,false),(vec![],3,true,true)];
        for (ids,v,valid,in_order)in cases {
            let (ok,ordered,masks)=eligibility(&[0,ids.len()as u64],&ids,v);
            assert_eq!(ok,valid);assert_eq!(ordered,valid&&USE_ORDERED_KEYS&&in_order);
            if valid&&REUSE_MASKS {assert_eq!(masks,vec![ids.iter().fold(0u64,|m,&id|m|1u64<<id)]);}else{assert!(masks.is_empty());}
        }
    }
    #[test]
    fn generation_matches_original_for_ordered_unordered_duplicates_and_fallbacks(){
        let mut random=0x5b25d6b80u64;
        for seed in 0..96 {
            let n=8+seed%31;let width=4+seed%4;let vocabulary=4+seed%12;
            let mut tags=Vec::new();let mut offsets=vec![0u64];
            for post in 0..n {
                let mut ids=(0..vocabulary).collect::<Vec<_>>();
                if seed%3!=0 {
                    for i in (1..ids.len()).rev(){random^=random<<13;random^=random>>7;random^=random<<17;ids.swap(i,random as usize%(i+1));}
                    ids.truncate(post%(vocabulary+1));
                }else{ids.truncate(width.min(vocabulary));}
                if seed%2==0 {ids.sort_unstable();}else{ids.reverse();}
                if seed%7==0 && seed%3!=0 && !ids.is_empty(){ids.push(ids[0]);}
                tags.extend(ids.into_iter().map(|id|format!("t{id:02}")));offsets.push(tags.len()as u64);
            }
            let refs=tags.iter().map(String::as_str).collect::<Vec<_>>();
            let (got,phases)=generate(&offsets,&refs);let(want,_)=generate_baseline(&offsets,&refs);assert_eq!(got,want,"seed{seed}");
            if seed%3==0 {assert_eq!(phases["fully_covered"],true,"fast branch seed{seed}");}
        }
    }
}
'''.replace('BASELINE',sub.replace('fn subsets(','fn subsets_baseline(')+gen.replace('fn generate(','fn generate_baseline(').replace('subsets(','subsets_baseline('))
variants={'scan-only':(False,False,False),'ordered':(True,False,False),'mask-reuse':(False,True,False),'ordered-mask':(True,True,False),'ordered-mask-tables':(True,True,True)}
manifest={}
def run(cmd,cwd,name,env):
 start=time.monotonic();x=subprocess.run(list(map(str,cmd)),cwd=cwd,env=env,capture_output=True,text=True);receipt=dict(command=list(map(str,cmd)),cwd=str(cwd),exit=x.returncode,seconds=time.monotonic()-start,stdout=x.stdout,stderr=x.stderr)
 (cwd/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');assert x.returncode==0,x.stdout+x.stderr
for name,(ordered,reuse,tables) in variants.items():
 p=P/name;(p/'src').mkdir(parents=True,exist_ok=True)
 for file in ['Cargo.toml','Cargo.lock']:shutil.copyfile(B/file,p/file)
 flags=f'\nconst USE_ORDERED_KEYS:bool={str(ordered).lower()};\nconst REUSE_MASKS:bool={str(reuse).lower()};\nconst USE_TABLES:bool={str(tables).lower()};\n'
 text=modified.replace('const LOW:',flags+'\nconst LOW:',1)+tests;(p/'src/main.rs').write_text(text)
 env={**os.environ,'RUSTC':str(RUST/'rustc'),'CARGO_TARGET_DIR':str(P/'target')}
 run([RUST/'cargo','build','--release','--locked','--offline'],p,'build',env);shutil.copy2(P/'target/release/rust_mech',p/'rust_mech')
 run([RUST/'cargo','test','--release','--locked','--offline','--bin','rust_mech','--','--test-threads=1'],p,'test',env)
 manifest[name]=dict(ordered_keys=ordered,reuse_masks=reuse,binomial_tables=tables,source=str(p/'src/main.rs'),source_sha256=sha(p/'src/main.rs'),executable=str(p/'rust_mech'),executable_sha256=sha(p/'rust_mech'),source_base_sha256=sha(B/'src/main.rs'),checked_release_arithmetic=True,unsafe_added=False,all_setup_inside_post_json_timer=True,test_cases=4,performance_measured=False)
 (P/'builds.json').write_text(json.dumps(manifest,indent=2)+'\n');print(name,'built;4 tests passed',flush=True)
