from pathlib import Path
import hashlib,json,subprocess,time,shutil
P=Path(__file__).parent;R=Path('/Users/cim310/mech-lang/mech/benchmarks/related-post-gen');U=Path('/private/tmp/mech-related-forward-read-windows-runners-20261107-v8/reuse-4/edges/edge-fixtures.json')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=json.loads(U.read_text());assert len(rows)==31
cases=[]
for x in rows:
 posts=Path(x.get('source_posts',x['command'][2]));data=json.loads(posts.read_text())
 if 'expected'in x:want=json.loads(Path(x['expected']).read_text())
 else:
  idx=json.loads((R/'fixtures'/('expected-'+x['fixture']+'.json')).read_text())['related_indices'];want=[{'_id':post['_id'],'tags':post['tags'],'related':[data[i]for i in selected]}for post,selected in zip(data,idx)]
 cases.append((x['fixture'],posts,want))
input=Path('/private/tmp/mech-related-current-input-fixtures-20261107/posts.json');oracle=Path('/private/tmp/mech-related-frozen-native-composition-latency-20261105-v1/related_posts_rust.json');cases.append(('full5000',input,json.loads(oracle.read_text())))
builds=json.loads((P/'builds.json').read_text());binaries={'before-u8-u32':'/private/tmp/mech-related-u8-ids-u32-rank-rust-control-20261106-v1/target/release/rust_mech',**{n:x['executable']for n,x in builds.items()}}
results=json.loads((P/'qualification.json').read_text())if(P/'qualification.json').exists()else[]
for name,binary in binaries.items():
 for case,source,want in cases:
  if any(x['variant']==name and x['case']==case and x['exact_original_Rust_output']for x in results):continue
  p=P/'qualification'/name/case;(p/'run').mkdir(parents=True,exist_ok=True);shutil.copyfile(source,p/'posts.json');start=time.monotonic();x=subprocess.run([binary],cwd=p/'run',capture_output=True,text=True,timeout=60);out=p/'related_posts_rust_mech.json';exact=x.returncode==0 and json.loads(out.read_text())==want
  v=dict(variant=name,case=case,command=[binary],cwd=str(p/'run'),exit=x.returncode,diagnostic_seconds=time.monotonic()-start,stdout=x.stdout,stderr=x.stderr,input_sha256=sha(p/'posts.json'),output_sha256=sha(out)if out.exists()else None,exact_original_Rust_output=exact,timing_claim=False);results.append(v);(p/'run.json').write_text(json.dumps(v,indent=2)+'\n');(P/'qualification.json').write_text(json.dumps(results,indent=2)+'\n');assert exact,v
 print(name,'31 edges and full5000 exact',flush=True)
(P/'qualification-summary.json').write_text(json.dumps(dict(variants=len(binaries),cases_each=len(cases),exact_outputs=len(results),all_exact=True,baseline_checked=True,all_new_unit_tests_passed=20,profile_and_qualification_timings_excluded=True),indent=2)+'\n')
