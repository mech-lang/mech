from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,os,subprocess
P=Path(__file__).parent;R=Path('/Users/cim310/mech-lang/mech/benchmarks/related-post-gen');D=R/'results';S=Path('/private/tmp/mech-related-compact-visit-work-compiler-20261107');L=S/'benchmarks/related-post-gen/trials/paired-select-and-visit-work-20261107'
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n')
analysis=read(P/'paired-analysis.json');assert all(not x['first_cohort_passed']for x in analysis['decisions'].values())
lat=read(D/'comparison-native-paired-select-and-visit-work-20261107-5000-m3.json');res=read(D/'comparison-native-paired-select-and-visit-work-resources-20261107-5000-m3.json')
source={'paired':'d18d25f699d3de7b655f2d4e1ff1e15197042597','compact':'43c194cd9f7f2f42f4afd142889d6eedba2cce36'}
report=dict(schema='mech.related-post-gen.paired-select-and-visit-work-report.v1',updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_commits=source,parent='b638320000f7cb33837df2ee73f09221551826a0',branches={'paired':'codex/related-paired-scalar-selects-20261107','compact':'codex/related-compact-visit-work-20261107'},identities={'paired':'IR268/work115/ABI41/image9','compact':'IR269/work115/ABI41/image11'},selected=False,goal_complete=False,production_backend='Cranelift',new_production_dependency=False,LLVM_optional_only=True,source_freeze=read(P/'source-freeze.json'),prospective_rule=read(P/'prospective-rule.json'),analysis=analysis,actual_machine=read(P/'actual-machine-and-size.json'),resources={n:res['summary'][n]for n in res['summary']if n.startswith('mech-')},
paired_change='Pair only adjacent independent I64 selects with the same predicate through iconcat/select.i128/isplit. Preserve raw nonzero truth and original effects/errors/work. Explicit ablation and emission counter;56 real benchmark pairs. Existing scalar and finite/alias/retry paths maintained. Optional LLVM lowering supports the internal concat vocabulary.',
compact_change='Serialize final u64 work prices in a versioned packed byte payload. Check native node/count/length then borrow bulk bytes; eagerly construct unchanged runtime visits from source-derived control plus final prices. Keep a separate untouched zero-completion base for existing funding checks; writer checks every non-work field against source derivation. Preserve legacy readers, independent source/layout proofs and genuine same-Object binding.',
qualification={'paired':read('/private/tmp/mech-related-paired-scalar-selects-tests-20261107-v3/summary.json'),'compact':read('/private/tmp/mech-related-compact-visit-work-tests-20261107-v2/summary.json'),'engine':read('/private/tmp/mech-related-compact-visit-work-engine-tests-20261107-v1/summary.json'),'loaders':read('/private/tmp/mech-related-compact-visit-work-loader-tests-20261107-v1/summary.json'),'benchmark_outputs_each':32,'scalar_DEFLATE_rows_each':133,'all_nontiming_and_physical_allocation_fields_exact_IR240':True,'optional_LLVM4_explicitly_passed_each':True,'promotion_full_GPU_suite_not_run':True},qualification_complete_for_promotion=False,
first_failures_retained=['IR268 first source test used separate control choices; adjacency correctly declined. Corrected to one tuple-valued choice, then coverage/ablation and all401 CI pass.','IR268 second GPU test link and first runner compiler link failed from full disk; no test or performance success inferred. Raw failed receipts retained.144 old task tool executables losslessly archived,12.07GiB freed; all benchmark runners, source, outputs and build receipts preserved.','IR269 first new visit equivalence test used a definitions-only DEFLATE fixture. Corrected to executable assembled skip source; all25 image tests,399 CI and133 regression rows pass.'],
conclusion='Both candidates fail their prospective promotion targets and remain unselected. No unchanged confirmation rerun. Paired selects use0.3% fewer processing instructions but lose27/31 parent processing pairs,paired+2.100%. Compact visits reduce restore instructions125.901M to110.071M(-12.574%) and native metadata by830788B(16.91%), but win only15/31 parent whole pairs and8/31 fixed242 whole pairs. Phase savings do not establish full-process superiority.',
lifecycle_diagnostic=read('/private/tmp/mech-related-visit-work-lifecycle-diagnostic-20261107-v1/summary.json'),launcher_retention_diagnostic_first=read('/private/tmp/mech-related-launcher-retention-diagnostic-20261107-v1/summary.json'),
next_probes={'paired_select_and_zero_store':read('/private/tmp/mech-related-cranelift-representation-probes-20261107-v1/summary.json'),'comparison_pairs':read('/private/tmp/mech-related-cranelift-comparison-pair-probes-20261107-v1/summary.json')},
next_actions=['Use actual executed hot-cone counts before selecting narrow equality/inequality pair combining; reduced probe already emits cmp/ccmp/branch and passes4096 native cases without new dependencies. General ordered comparison cones still need a proved backend rule.','Count executed retirement store pairs before integrating the successful16-byte store probe.','Keep the12.6% restore instruction saving as an unselected foundation; investigate launch variability and remaining eager metadata construction before another whole-process candidate.','Preserve fastest eligible measured Rust independently at both boundaries; meet both before completing the goal.'],all_first_and_adverse_results_retained=True,selected_compiler_unchanged='4cc266ae0d05c69432a4c15ffe99d5e586685647')
bal=Path('/private/tmp/mech-related-launcher-retention-diagnostic-20261107-v1/balanced-results.json')
if bal.exists():report['launcher_retention_diagnostic_balanced']=read(bal)
write(D/'compiler-native-paired-select-and-visit-work-20261107.json',report)
L.mkdir(parents=True,exist_ok=True)
def copy(f,rel):
 f=Path(f);b=f.read_bytes()
 if f.suffix in ['.rs','.o','.bin','.mecb','.toml']or len(b)>16000:rel+='.gz';b=gzip.compress(b,mtime=0)
 q=L/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
def tree(path,prefix):
 path=Path(path)
 if not path.exists():return
 for root,dirs,files in os.walk(path):
  dirs[:]=sorted(x for x in dirs if x not in ['.git','target','__pycache__','edges','latency','resources','build','runtime','llvm-build'])
  for name in sorted(files):
   f=Path(root)/name;rel=f.relative_to(path)
   if len(rel.parts)>3:continue
   if f.suffix in ['.py','.rs','.c','.clif','.vcode','.asm','.json','.gz','.log','.o','.bin']and'output.json'not in name and not name.startswith('actual-'):copy(f,prefix+'/'+str(rel))
copy(D/'compiler-native-paired-select-and-visit-work-20261107.json','report.json')
for n in ['comparison-native-paired-select-and-visit-work-20261107-5000-m3.json','comparison-native-paired-select-and-visit-work-resources-20261107-5000-m3.json']:copy(D/n,'cohorts/'+n)
for path,prefix in [(P,'protocol'),('/private/tmp/mech-related-paired-scalar-selects-20261107-v1','paired-protocol'),('/private/tmp/mech-related-compact-visit-work-20261107-v1','compact-protocol'),('/private/tmp/mech-related-cranelift-representation-probes-20261107-v1','representation-probes'),('/private/tmp/mech-related-cranelift-comparison-pair-probes-20261107-v1','comparison-probes'),('/private/tmp/mech-related-visit-work-lifecycle-diagnostic-20261107-v1','lifecycle-diagnostic'),('/private/tmp/mech-related-launcher-retention-diagnostic-20261107-v1','launcher-diagnostic')]:tree(path,prefix)
for kind,versions in [('paired-scalar-selects',[1,2,3]),('compact-visit-work',[1,2])]:
 for version in versions:tree(f'/private/tmp/mech-related-{kind}-opt-20261107-v{version}',f'{kind}/compiler-v{version}')
 for version in versions:tree(f'/private/tmp/mech-related-{kind}-tests-20261107-v{version}',f'{kind}/tests-v{version}')
 tree(f'/private/tmp/mech-related-{kind}-regressions-20261107-v1',f'{kind}/regressions')
for p,prefix in [('/private/tmp/mech-related-compact-visit-work-engine-tests-20261107-v1','engine-tests'),('/private/tmp/mech-related-compact-visit-work-loader-tests-20261107-v1','loaders'),('/private/tmp/mech-related-paired-select-and-visit-work-metrics-20261107-v1','pair-metrics'),('/private/tmp/mech-related-paired-select-and-visit-work-compact-metrics-20261107-v1','compact-metrics')]:tree(p,prefix)
for label,path in [('parent','/private/tmp/mech-related-llvm-native-image-cranelift-control-20261107-v4'),('paired','/private/tmp/mech-related-paired-scalar-selects-runners-20261107-v2'),('compact','/private/tmp/mech-related-compact-visit-work-runners-20261107-v2'),('paired-LLVM','/private/tmp/mech-related-paired-scalar-selects-llvm-reference-20261107-v1')]:
 p=Path(path);tree(p,'runners/'+label)
 for f in (p/'build').iterdir():
  if f.is_file():copy(f,'Objects/'+label+'/'+f.name)
 rt=p/'runtime'
 if rt.exists():
  for f in rt.glob('*.json'):copy(f,'runtimes/'+label+'/'+f.name)
for label,repo in [('paired','/private/tmp/mech-related-paired-scalar-selects-compiler-20261107'),('compact',str(S))]:
 patch=subprocess.check_output(['git','-c','gc.auto=0','diff',report['parent'],source[label]],cwd=repo);(L/(label+'-source.patch.gz')).write_bytes(gzip.compress(patch,mtime=0))
copy('/private/tmp/mech-related-current-input-fixtures-20261107/posts.json','inputs/posts.json')
copy('/private/tmp/mech-related-frozen-native-composition-latency-20261105-v1/related_posts_rust.json','outputs/Rust.json')
objects={}
for kind,cohort in [('latency',lat),('resources',res)]:
 for row in cohort['samples']:
  k=row['output_sha256'];matches=list((P/kind/'output-objects').glob(k+'*'));assert len(matches)==1,(kind,k,matches)
  f=matches[0];assert sha(f.read_bytes())==k
  if k not in objects:copy(f,'outputs/'+k+'.json');objects[k]=True
for name in ['compare-implementations.py','build-compiler.py','build-dependent-compiler.py','build-host.py','build-metrics.py','measurement.rs','audit-native-link.py','experiments/check_subset3.py']:copy(R/name,'recipes/'+name)
(L/'README.md').write_text('''# Paired selects and compact visit work: unselected experiments

Cranelift remains production; there is no new compiler dependency. IR268 and IR269 fail their predeclared primary performance gates. All first/adverse samples and test setup failures remain. Read report.json.gz and protocol/paired-analysis.json before interpreting smaller code or fewer instructions as speed. The compact table saves12.6% restoration instructions and830,788 metadata bytes, but full-process superiority is not established. Do not rerun an unchanged rejected candidate for favorable timing.

The source commits and two source patches are pinned. Runtime-only linked Objects and audits are retained for both candidates, parent and optional LLVM paired-select reference. Optional LLVM tools are used only in explicit reference/regression work.995 cohort outputs are independently checkable through the retained content-addressed output blobs. Each candidate passes133 scalar/DEFLATE non-timing/allocation rows. IR268 passes401 CI names;IR269 passes399 CI names,25 image tests,50 Engine image/reader tests,96 loader outputs and24 entire finite-denial comparisons. Broader promotion-only GPU checks were not run.

Lifecycle markers and launcher-retention probes are diagnostics, never replacement promotion timings or compiler CPU shares. The first unbalanced launcher test is retained; temporal drift and parent memory must be separated before attributing whole-process results. Narrow comparison-pair CLIF and exact16-byte store probes require executed site counts before integration. Run python3 verify.py for independent packet hashes, actual Mach-O text, test qualification and all995 output references.
''')
verify=r'''from pathlib import Path
import gzip,hashlib,json,struct,statistics,random,math
P=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def blob(n):
 p=P/n
 if not p.exists():p=Path(str(p)+'.gz')
 b=p.read_bytes();return gzip.decompress(b)if p.suffix=='.gz'else b
def read(n):return json.loads(blob(n))
m=read('manifest.json')
for n,x in m['files'].items():
 b=(P/n).read_bytes();assert len(b)==x['bytes']and sha(b)==x['sha256'],n
 d=gzip.decompress(b)if x['gzip']else b;assert len(d)==x['decoded_bytes']and sha(d)==x['decoded_sha256'],n
r=read('report.json');assert not r['selected']and not r['goal_complete']and not r['new_production_dependency']
for x in r['analysis']['decisions'].values():assert not x['first_cohort_passed']and not x['selected']
for kind,v,count in [('paired-scalar-selects',3,401),('compact-visit-work',2,399)]:
 ci=read(f'{kind}/tests-v{v}/ci-execute.json');assert ci['exit']==0 and f'{count} passed; 0 failed'in ci['stdout']
 for n in ['scalar','one-kib']:assert read(f'{kind}/regressions/{n}-comparison.json')['all_nontiming_fields_equal_IR240']
 assert read(f'{kind}/tests-v{v}/optional-llvm-regressions.json')['exit']==0
assert read('loaders/summary.json')['finite_denials']==24
assert read('loaders/summary.json')['full5000_plus_edges_exact']==96
assert read('compact-visit-work/tests-v1/all-image-tests.json')['exit']!=0
assert read('paired-scalar-selects/tests-v1/scalar-select-tests.json')['exit']!=0
assert read('paired-scalar-selects/tests-v2/test-build.json')['exit']!=0
oracle=read('outputs/Rust.json');checked=set();observed=0
latency=read('cohorts/comparison-native-paired-select-and-visit-work-20261107-5000-m3.json')
rule=r['prospective_rule']
def quant(a,q):
 p=(len(a)-1)*q;i=math.floor(p);j=math.ceil(p);return a[i]+(a[j]-a[i])*(p-i)
for candidate,decision in r['analysis']['decisions'].items():
 for ref,comparisons in decision['paired'].items():
  for boundary,expected in comparisons.items():
   vals={n:{x['sample']:x[boundary]for x in latency['samples']if x['variant']==n}for n in [candidate,ref]}
   assert all(set(v)==set(range(31))for v in vals.values())
   a=[vals[candidate][i]/vals[ref][i]-1 for i in range(31)]
   rng=random.Random(rule['bootstrap']['seed']);boots=sorted(statistics.median(a[rng.randrange(31)]for _ in range(31))for _ in range(rule['bootstrap']['resamples']))
   assert sum(v<0 for v in a)==expected['wins'] and statistics.median(a)==expected['median_paired_relative_change']
   assert [quant(boots,.025),quant(boots,.975)]==expected['two_sided_95_interval']
   assert quant(boots,.95)==expected['one_sided_95_upper']

for n,count in [('comparison-native-paired-select-and-visit-work-20261107-5000-m3.json',806),('comparison-native-paired-select-and-visit-work-resources-20261107-5000-m3.json',189)]:
 c=read('cohorts/'+n);assert len(c['samples'])==count
 for row in c['samples']:
  key=row['output_sha256'];assert row['exit']==0 and row['exact_rust_output']
  if key not in checked:
   data=blob('outputs/'+key+'.json');assert sha(data)==key and json.loads(data)==oracle;checked.add(key)
  observed+=1
texts={}
for label,key in [('parent','parent'),('paired','paired'),('compact','compact'),('paired-LLVM','paired_LLVM')]:
 b=blob('Objects/'+label+'/object.o');a=32;magic,cpu,_,_,ncmd,_,_,_=struct.unpack_from('<8I',b);assert magic==0xfeedfacf and cpu==0x100000c;found=[]
 for _ in range(ncmd):
  cmd,size=struct.unpack_from('<II',b,a)
  if cmd==0x19:
   for i in range(struct.unpack_from('<I',b,a+64)[0]):
    q=a+72+i*80
    if b[q:q+16].split(bytes([0]))[0]==b'__text':
     length=struct.unpack_from('<Q',b,q+40)[0];offset=struct.unpack_from('<I',b,q+48)[0];found.append(b[offset:offset+length])
  a+=size
 assert len(found)==1 and sha(found[0])==r['actual_machine'][key]['text_sha256'];texts[label]=sha(found[0])
assert texts['parent']==texts['compact']and texts['paired']!=texts['parent']
assert read('representation-probes/execute.json')['exit']==0
assert read('comparison-probes/execute.json')['exit']==0
assert read('lifecycle-diagnostic/summary.json')['exact_outputs']==22
print(json.dumps(dict(records=len(m['files']),exact_cohort_output_references=observed,source_commits=r['source_commits'],actual_machine_facts_rederived=True,all_source_test_failures_retained=True,selected=False)))
'''
(L/'verify.py').write_text(verify)
files={}
for f in sorted(L.rglob('*')):
 if not f.is_file()or f.name=='manifest.json':continue
 b=f.read_bytes();d=gzip.decompress(b)if f.suffix=='.gz'else b;files[str(f.relative_to(L))]=dict(bytes=len(b),sha256=sha(b),gzip=f.suffix=='.gz',decoded_bytes=len(d),decoded_sha256=sha(d))
write(L/'manifest.json',dict(schema='mech.related-post-gen.evidence-packet.v1',source_commits=source,files=files))
print('packet records',len(files),'bytes',sum(x['bytes']for x in files.values()),flush=True)
