use cranelift_codegen::{ir::{types, AbiParam, InstBuilder, MemFlags}, settings::{self, Configurable}};
use cranelift_frontend::{FunctionBuilder, FunctionBuilderContext};
use cranelift_module::{Module, Linkage, default_libcall_names};
use cranelift_object::{ObjectBuilder, ObjectModule};
fn main() {
 let out=std::env::args().nth(1).unwrap();
 let mut flags=settings::builder();
 for (k,v) in [("opt_level","speed"),("is_pic","true"),("preserve_frame_pointers","true"),("unwind_info","true"),("log2_min_function_alignment","7")] { flags.set(k,v).unwrap(); }
 let isa=cranelift_native::builder().unwrap().finish(settings::Flags::new(flags)).unwrap();
 let mut module=ObjectModule::new(ObjectBuilder::new(isa,"mech_representation_probes",default_libcall_names()).unwrap());
 for kind in ["bool_eq_and_scalar","bool_eq_and_pair","bool_ne_or_scalar","bool_ne_or_pair"] {
  let mut ctx=module.make_context(); ctx.set_disasm(true);
  ctx.func.signature.params = vec![AbiParam::new(types::I64);if kind.contains("clear"){1}else if kind.starts_with("bool"){4}else{2}];
  if kind.contains("selects") {ctx.func.signature.returns=vec![AbiParam::new(types::I64);2];} else if kind.starts_with("bool") || kind=="checked_add" {ctx.func.signature.returns=vec![AbiParam::new(types::I64)];}
  let id=module.declare_function(kind,Linkage::Export,&ctx.func.signature).unwrap();
  {let mut bc=FunctionBuilderContext::new();let mut b=FunctionBuilder::new(&mut ctx.func,&mut bc);let entry=b.create_block();b.append_block_params_for_function_params(entry);b.switch_to_block(entry);let args=b.block_params(entry).to_vec();
  if kind.contains("selects") {
   let c=b.ins().icmp(cranelift_codegen::ir::condcodes::IntCC::UnsignedGreaterThan,args[0],args[1]);
   let (x,y)=if kind=="paired_selects" {let f=b.ins().iconcat(args[0],args[1]);let r=b.ins().iconcat(args[1],args[0]);let p=b.ins().select(c,f,r);b.ins().isplit(p)}else{(b.ins().select(c,args[0],args[1]),b.ins().select(c,args[1],args[0]))};
   b.ins().return_(&[x,y]);
  }else if kind.contains("clear") {
   let z=b.ins().iconst(types::I64,0);
   if kind=="vector_clear" {let zz=b.ins().splat(types::I64X2,z);b.ins().store(MemFlags::new(),zz,args[0],0);}else{b.ins().store(MemFlags::new(),z,args[0],0);b.ins().store(MemFlags::new(),z,args[0],8);}
   b.ins().return_(&[]);
  }else if kind.starts_with("bool") {
   let cc=if kind.contains("eq_and"){cranelift_codegen::ir::condcodes::IntCC::Equal}else{cranelift_codegen::ir::condcodes::IntCC::NotEqual};
   let v=if kind.ends_with("pair") {
    let a=b.ins().iconcat(args[0],args[2]);let c=b.ins().iconcat(args[1],args[3]);b.ins().icmp(cc,a,c)
   }else{
    let a=b.ins().icmp(cc,args[0],args[1]);let c=b.ins().icmp(cc,args[2],args[3]);
    let a=b.ins().uextend(types::I64,a);let c=b.ins().uextend(types::I64,c);
    if kind.contains("eq_and"){b.ins().band(a,c)}else{b.ins().bor(a,c)}
   };
   let yes=b.create_block();let no=b.create_block(); b.ins().brif(v,yes,&[],no,&[]);
   b.switch_to_block(yes);let v=b.ins().iconst(types::I64,1);b.ins().return_(&[v]);
   b.switch_to_block(no);let v=b.ins().iconst(types::I64,0);b.ins().return_(&[v]);
  }else {let (v,c)=b.ins().uadd_overflow(args[0],args[1]);let ok=b.create_block();let fail=b.create_block();b.ins().brif(c,fail,&[],ok,&[]);b.switch_to_block(ok);b.ins().return_(&[v]);b.switch_to_block(fail);let z=b.ins().iconst(types::I64,0);b.ins().return_(&[z]);}
  b.seal_all_blocks();b.finalize();}
  std::fs::write(format!("{out}/{kind}.clif"),ctx.func.display().to_string()).unwrap();
  module.define_function(id,&mut ctx).unwrap();let code=ctx.compiled_code().unwrap();
  std::fs::write(format!("{out}/{kind}.vcode"),code.vcode.as_ref().unwrap()).unwrap();
  std::fs::write(format!("{out}/{kind}.bin"),code.code_buffer()).unwrap();
 }
 std::fs::write(format!("{out}/probes.o"),module.finish().emit().unwrap()).unwrap();
}
