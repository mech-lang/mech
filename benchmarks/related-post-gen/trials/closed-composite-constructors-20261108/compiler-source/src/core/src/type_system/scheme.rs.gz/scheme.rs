//! Storage-blind schemes for the maintained first-order source operations.

use crate::{
    BuiltinKindPredicate, BuiltinScalarKind, DimensionExpr, DimensionLifetime,
    DimensionParameterDeclaration, DimensionParameterId, DimensionParameterOrigin, InputKindScheme,
    KindConstraint, KindExpr, KindParameter, KindParameterId, KindScheme, ResolvedType,
    SemanticModelError, SourceSchemeTemplate, TableJoinMode,
};

#[cfg(feature = "no_std")]
use alloc::{boxed::Box, vec, vec::Vec};
#[cfg(not(feature = "no_std"))]
use std::{boxed::Box, vec, vec::Vec};

fn kind(id: u32) -> KindExpr {
    KindExpr::Parameter(KindParameterId::new(id))
}

fn dim(id: u32) -> DimensionExpr {
    DimensionExpr::Parameter(DimensionParameterId::new(id))
}

fn matrix(element: KindExpr, rows: DimensionExpr, columns: DimensionExpr) -> KindExpr {
    KindExpr::Matrix {
        element: Box::new(element),
        dimensions: vec![rows, columns].into_boxed_slice(),
    }
}

fn set(element: KindExpr, cardinality: DimensionExpr) -> KindExpr {
    KindExpr::Set {
        element: Box::new(element),
        cardinality,
    }
}

fn parameters(count: u32) -> Box<[KindParameter]> {
    (0..count)
        .map(|id| KindParameter {
            id: KindParameterId::new(id),
            upper_bound: None,
        })
        .collect::<Vec<_>>()
        .into_boxed_slice()
}

fn dimensions(count: u32) -> Box<[DimensionParameterDeclaration]> {
    (0..count)
        .map(|id| DimensionParameterDeclaration {
            id: DimensionParameterId::new(id),
            origin: DimensionParameterOrigin::Inferred,
            lifetime: DimensionLifetime::Turn,
            lower_bound: DimensionExpr::Constant(0),
            upper_bound: None,
        })
        .collect::<Vec<_>>()
        .into_boxed_slice()
}

fn bounded_dimensions(
    input_count: u32,
    output_upper_bound: Option<DimensionExpr>,
) -> Box<[DimensionParameterDeclaration]> {
    let mut declarations = dimensions(input_count).into_vec();
    declarations.push(DimensionParameterDeclaration {
        id: DimensionParameterId::new(input_count),
        origin: DimensionParameterOrigin::Inferred,
        lifetime: DimensionLifetime::Turn,
        lower_bound: DimensionExpr::Constant(0),
        upper_bound: output_upper_bound,
    });
    declarations.into_boxed_slice()
}

fn make(
    kinds: u32,
    dims: u32,
    inputs: Vec<KindExpr>,
    outputs: Vec<KindExpr>,
    constraints: Vec<KindConstraint>,
) -> Result<KindScheme, SemanticModelError> {
    make_with_dimensions(kinds, dimensions(dims), inputs, outputs, constraints)
}

fn make_with_dimensions(
    kinds: u32,
    dimensions: Box<[DimensionParameterDeclaration]>,
    inputs: Vec<KindExpr>,
    outputs: Vec<KindExpr>,
    constraints: Vec<KindConstraint>,
) -> Result<KindScheme, SemanticModelError> {
    KindScheme::new(
        parameters(kinds),
        dimensions,
        InputKindScheme::Fixed(inputs.into_boxed_slice()),
        outputs.into_boxed_slice(),
        constraints.into_boxed_slice(),
    )
}

fn variadic(
    kinds: u32,
    dims: u32,
    repeated: KindExpr,
    minimum: u32,
    output: KindExpr,
    constraints: Vec<KindConstraint>,
) -> Result<KindScheme, SemanticModelError> {
    KindScheme::new(
        parameters(kinds),
        dimensions(dims),
        InputKindScheme::Variadic {
            prefix: Box::new([]),
            repeated,
            min_repetitions: minimum,
        },
        vec![output].into_boxed_slice(),
        constraints.into_boxed_slice(),
    )
}

pub fn exact_unary(input: KindExpr, output: KindExpr) -> Result<KindScheme, SemanticModelError> {
    make(0, 0, vec![input], vec![output], Vec::new())
}

pub fn exact_binary(
    left: KindExpr,
    right: KindExpr,
    output: KindExpr,
) -> Result<KindScheme, SemanticModelError> {
    make(0, 0, vec![left, right], vec![output], Vec::new())
}

pub fn predicate_unary_same(
    predicate: BuiltinKindPredicate,
) -> Result<Vec<KindScheme>, SemanticModelError> {
    let scalar = make(
        1,
        0,
        vec![kind(0)],
        vec![kind(0)],
        vec![KindConstraint::Satisfies {
            kind: kind(0),
            predicate,
        }],
    )?;
    let matrix_kind = matrix(kind(0), dim(0), dim(1));
    let matrix = make(
        1,
        2,
        vec![matrix_kind.clone()],
        vec![matrix_kind],
        vec![KindConstraint::Satisfies {
            kind: kind(0),
            predicate,
        }],
    )?;
    Ok(vec![scalar, matrix])
}

pub fn promoted_binary_scalar() -> Result<KindScheme, SemanticModelError> {
    make(
        3,
        0,
        vec![kind(0), kind(1)],
        vec![kind(2)],
        vec![
            KindConstraint::Satisfies {
                kind: kind(0),
                predicate: BuiltinKindPredicate::Number,
            },
            KindConstraint::Satisfies {
                kind: kind(1),
                predicate: BuiltinKindPredicate::Number,
            },
            KindConstraint::Promotes {
                left: kind(0),
                right: kind(1),
                output: kind(2),
            },
        ],
    )
}

fn compatible_binary_matrices(
    kinds: u32,
    left: KindExpr,
    right: KindExpr,
    output: KindExpr,
    mut constraints: Vec<KindConstraint>,
) -> Result<Vec<KindScheme>, SemanticModelError> {
    // Equal live shape does not imply identical symbolic dimension origins.
    // Keep both inputs rigid and retain the two equal-extent obligations for
    // execution. The exact symbolic schemes remain the more-specific match.
    constraints.extend([
        KindConstraint::DimensionCompatible(dim(0), dim(2)),
        KindConstraint::DimensionCompatible(dim(1), dim(3)),
    ]);
    // Either input can supply an explicitly requested output shape. Without
    // such a request the solver canonicalizes these equivalent results.
    [0, 2]
        .into_iter()
        .map(|axis| {
            make(
                kinds,
                4,
                vec![
                    matrix(left.clone(), dim(0), dim(1)),
                    matrix(right.clone(), dim(2), dim(3)),
                ],
                vec![matrix(output.clone(), dim(axis), dim(axis + 1))],
                constraints.clone(),
            )
        })
        .collect()
}

pub fn promoted_binary_elementwise() -> Result<Vec<KindScheme>, SemanticModelError> {
    let mut schemes = vec![promoted_binary_scalar()?];
    for (left_matrix, right_matrix) in [(true, true), (true, false), (false, true)] {
        let shaped_left = matrix(kind(0), dim(0), dim(1));
        let shaped_right = matrix(kind(1), dim(0), dim(1));
        schemes.push(make(
            3,
            2,
            vec![
                if left_matrix { shaped_left } else { kind(0) },
                if right_matrix { shaped_right } else { kind(1) },
            ],
            vec![matrix(kind(2), dim(0), dim(1))],
            vec![
                KindConstraint::Satisfies {
                    kind: kind(0),
                    predicate: BuiltinKindPredicate::Number,
                },
                KindConstraint::Satisfies {
                    kind: kind(1),
                    predicate: BuiltinKindPredicate::Number,
                },
                KindConstraint::Promotes {
                    left: kind(0),
                    right: kind(1),
                    output: kind(2),
                },
            ],
        )?);
    }
    // Cross-representation matrix operations support one shaped operand and
    // one row or column broadcast. Describe those relationships directly so
    // source resolution cannot admit arbitrary incompatible matrix pairs and
    // defer their rejection until operation specialization.
    for reversed in [false, true] {
        for column in [true, false] {
            let shaped_element = if reversed { kind(1) } else { kind(0) };
            let broadcast_element = if reversed { kind(0) } else { kind(1) };
            let shaped = matrix(shaped_element, dim(0), dim(1));
            let broadcast = if column {
                matrix(broadcast_element, dim(2), DimensionExpr::Constant(1))
            } else {
                matrix(broadcast_element, DimensionExpr::Constant(1), dim(2))
            };
            let inputs = if reversed {
                vec![broadcast, shaped]
            } else {
                vec![shaped, broadcast]
            };
            schemes.push(make(
                3,
                3,
                inputs,
                vec![matrix(kind(2), dim(0), dim(1))],
                vec![
                    KindConstraint::Satisfies {
                        kind: kind(0),
                        predicate: BuiltinKindPredicate::Number,
                    },
                    KindConstraint::Satisfies {
                        kind: kind(1),
                        predicate: BuiltinKindPredicate::Number,
                    },
                    KindConstraint::Promotes {
                        left: kind(0),
                        right: kind(1),
                        output: kind(2),
                    },
                    KindConstraint::DimensionCompatible(dim(if column { 0 } else { 1 }), dim(2)),
                ],
            )?);
        }
    }
    schemes.extend(compatible_binary_matrices(
        3,
        kind(0),
        kind(1),
        kind(2),
        vec![
            KindConstraint::Satisfies {
                kind: kind(0),
                predicate: BuiltinKindPredicate::Number,
            },
            KindConstraint::Satisfies {
                kind: kind(1),
                predicate: BuiltinKindPredicate::Number,
            },
            KindConstraint::Promotes {
                left: kind(0),
                right: kind(1),
                output: kind(2),
            },
        ],
    )?);
    Ok(schemes)
}

fn exact_elementwise_comparison(element: KindExpr) -> Result<Vec<KindScheme>, SemanticModelError> {
    let boolean = BuiltinScalarKind::Bool.kind_expr();
    let mut schemes = vec![make(
        0,
        2,
        vec![
            matrix(element.clone(), dim(0), dim(1)),
            matrix(element.clone(), dim(0), dim(1)),
        ],
        vec![matrix(boolean.clone(), dim(0), dim(1))],
        Vec::new(),
    )?];
    for reversed in [false, true] {
        let shaped = matrix(element.clone(), dim(0), dim(1));
        let operands = |other: KindExpr| {
            if reversed {
                vec![other, shaped.clone()]
            } else {
                vec![shaped.clone(), other]
            }
        };
        schemes.push(make(
            0,
            2,
            operands(element.clone()),
            vec![matrix(boolean.clone(), dim(0), dim(1))],
            Vec::new(),
        )?);
        for column in [true, false] {
            let broadcast = if column {
                matrix(element.clone(), dim(2), DimensionExpr::Constant(1))
            } else {
                matrix(element.clone(), DimensionExpr::Constant(1), dim(2))
            };
            schemes.push(make(
                0,
                3,
                operands(broadcast),
                vec![matrix(boolean.clone(), dim(0), dim(1))],
                vec![KindConstraint::DimensionCompatible(
                    dim(if column { 0 } else { 1 }),
                    dim(2),
                )],
            )?);
        }
    }
    schemes.extend(compatible_binary_matrices(
        0,
        element.clone(),
        element,
        boolean,
        Vec::new(),
    )?);
    Ok(schemes)
}

pub fn comparison_exact() -> Result<Vec<KindScheme>, SemanticModelError> {
    let boolean = BuiltinScalarKind::Bool.kind_expr();
    let mut schemes = vec![make(
        1,
        0,
        vec![kind(0), kind(0)],
        vec![boolean.clone()],
        vec![KindConstraint::Satisfies {
            kind: kind(0),
            predicate: BuiltinKindPredicate::Equatable,
        }],
    )?];
    // Equatable admits nominal and structural values, but does not promise
    // elementwise comparison or broadcasting for matrices of those values.
    // Keep exact numeric matrix equality ahead of whole-value equality; mixed
    // numeric kinds use the promotion schemes added by the caller. Bool and
    // String are the other maintained elementwise kinds.
    schemes.push(make(
        1,
        2,
        vec![
            matrix(kind(0), dim(0), dim(1)),
            matrix(kind(0), dim(0), dim(1)),
        ],
        vec![matrix(boolean.clone(), dim(0), dim(1))],
        vec![KindConstraint::Satisfies {
            kind: kind(0),
            predicate: BuiltinKindPredicate::Number,
        }],
    )?);
    for element in [
        BuiltinScalarKind::Bool.kind_expr(),
        BuiltinScalarKind::String.kind_expr(),
        KindExpr::Index,
    ] {
        schemes.extend(exact_elementwise_comparison(element)?);
    }
    schemes.extend(compatible_binary_matrices(
        1,
        kind(0),
        kind(0),
        boolean.clone(),
        vec![KindConstraint::Satisfies {
            kind: kind(0),
            predicate: BuiltinKindPredicate::Number,
        }],
    )?);
    Ok(schemes)
}

fn strict_comparison_exact() -> Result<Vec<KindScheme>, SemanticModelError> {
    // Strict equality is the language spelling of exact type equality. It
    // never inserts a conversion and therefore requires one identical,
    // equatable semantic kind on both sides. Matrix extents may be described
    // by different fixed and turn-varying expressions, so retain exact
    // element kinds while proving the two axes compatible.
    let boolean = BuiltinScalarKind::Bool.kind_expr();
    Ok(vec![
        make(
            1,
            0,
            vec![kind(0), kind(0)],
            vec![boolean.clone()],
            vec![KindConstraint::Satisfies {
                kind: kind(0),
                predicate: BuiltinKindPredicate::Equatable,
            }],
        )?,
        make(
            1,
            4,
            vec![
                matrix(kind(0), dim(0), dim(1)),
                matrix(kind(0), dim(2), dim(3)),
            ],
            vec![boolean],
            vec![
                KindConstraint::Satisfies {
                    kind: kind(0),
                    predicate: BuiltinKindPredicate::Equatable,
                },
                KindConstraint::DimensionCompatible(dim(0), dim(2)),
                KindConstraint::DimensionCompatible(dim(1), dim(3)),
            ],
        )?,
    ])
}

pub fn comparison_promoted() -> Result<Vec<KindScheme>, SemanticModelError> {
    comparison_promoted_for_predicate(BuiltinKindPredicate::Number)
}

fn comparison_promoted_for_predicate(
    predicate: BuiltinKindPredicate,
) -> Result<Vec<KindScheme>, SemanticModelError> {
    let mut result = Vec::new();
    for arithmetic in promoted_binary_elementwise()? {
        let output = match arithmetic.outputs().first() {
            Some(KindExpr::Matrix { dimensions, .. }) => matrix(
                BuiltinScalarKind::Bool.kind_expr(),
                dimensions[0].clone(),
                dimensions[1].clone(),
            ),
            _ => BuiltinScalarKind::Bool.kind_expr(),
        };
        let mut constraints = arithmetic.constraints().to_vec();
        constraints.push(KindConstraint::Satisfies {
            kind: kind(0),
            predicate,
        });
        constraints.push(KindConstraint::Satisfies {
            kind: kind(1),
            predicate,
        });
        result.push(KindScheme::new(
            arithmetic.kind_parameters().to_vec().into_boxed_slice(),
            arithmetic
                .dimension_parameters()
                .to_vec()
                .into_boxed_slice(),
            arithmetic.inputs().clone(),
            vec![output].into_boxed_slice(),
            constraints.into_boxed_slice(),
        )?);
    }
    if predicate == BuiltinKindPredicate::Ordered {
        result.extend(exact_elementwise_comparison(KindExpr::Index)?);
    }
    Ok(result)
}

pub fn bool_unary() -> Result<Vec<KindScheme>, SemanticModelError> {
    let bool_kind = BuiltinScalarKind::Bool.kind_expr();
    Ok(vec![
        exact_unary(bool_kind.clone(), bool_kind.clone())?,
        make(
            0,
            2,
            vec![matrix(bool_kind.clone(), dim(0), dim(1))],
            vec![matrix(bool_kind, dim(0), dim(1))],
            Vec::new(),
        )?,
    ])
}

pub fn bool_binary() -> Result<Vec<KindScheme>, SemanticModelError> {
    let bool_kind = BuiltinScalarKind::Bool.kind_expr();
    let mut schemes = vec![
        exact_binary(bool_kind.clone(), bool_kind.clone(), bool_kind.clone())?,
        make(
            0,
            2,
            vec![
                matrix(bool_kind.clone(), dim(0), dim(1)),
                matrix(bool_kind.clone(), dim(0), dim(1)),
            ],
            vec![matrix(bool_kind.clone(), dim(0), dim(1))],
            Vec::new(),
        )?,
    ];
    for reversed in [false, true] {
        let shaped = matrix(bool_kind.clone(), dim(0), dim(1));
        let operands = |other: KindExpr| {
            if reversed {
                vec![other, shaped.clone()]
            } else {
                vec![shaped.clone(), other]
            }
        };
        schemes.push(make(
            0,
            2,
            operands(bool_kind.clone()),
            vec![shaped.clone()],
            Vec::new(),
        )?);
        for column in [true, false] {
            let broadcast = if column {
                matrix(bool_kind.clone(), dim(2), DimensionExpr::Constant(1))
            } else {
                matrix(bool_kind.clone(), DimensionExpr::Constant(1), dim(2))
            };
            schemes.push(make(
                0,
                3,
                operands(broadcast),
                vec![shaped.clone()],
                vec![KindConstraint::DimensionCompatible(
                    dim(if column { 0 } else { 1 }),
                    dim(2),
                )],
            )?);
        }
    }
    schemes.extend(compatible_binary_matrices(
        0,
        bool_kind.clone(),
        bool_kind.clone(),
        bool_kind,
        Vec::new(),
    )?);
    Ok(schemes)
}

fn range_scheme(arity: usize) -> Result<KindScheme, SemanticModelError> {
    match arity {
        2 => make(
            3,
            1,
            vec![kind(0), kind(1)],
            vec![matrix(kind(2), DimensionExpr::Constant(1), dim(0))],
            vec![
                KindConstraint::Satisfies {
                    kind: kind(0),
                    predicate: BuiltinKindPredicate::RangeEndpoint,
                },
                KindConstraint::Satisfies {
                    kind: kind(1),
                    predicate: BuiltinKindPredicate::RangeEndpoint,
                },
                KindConstraint::Promotes {
                    left: kind(0),
                    right: kind(1),
                    output: kind(2),
                },
            ],
        ),
        3 => make(
            5,
            1,
            vec![kind(0), kind(1), kind(2)],
            vec![matrix(kind(4), DimensionExpr::Constant(1), dim(0))],
            vec![
                KindConstraint::Satisfies {
                    kind: kind(0),
                    predicate: BuiltinKindPredicate::RangeEndpoint,
                },
                KindConstraint::Satisfies {
                    kind: kind(1),
                    predicate: BuiltinKindPredicate::RangeEndpoint,
                },
                KindConstraint::Satisfies {
                    kind: kind(2),
                    predicate: BuiltinKindPredicate::RangeEndpoint,
                },
                KindConstraint::Promotes {
                    left: kind(0),
                    right: kind(1),
                    output: kind(3),
                },
                KindConstraint::Promotes {
                    left: kind(3),
                    right: kind(2),
                    output: kind(4),
                },
            ],
        ),
        _ => unreachable!("range schemes have two or three endpoints"),
    }
}

pub fn range_binary() -> Result<KindScheme, SemanticModelError> {
    range_scheme(2)
}

pub fn range_ternary() -> Result<KindScheme, SemanticModelError> {
    range_scheme(3)
}

pub fn matrix_transpose() -> Result<KindScheme, SemanticModelError> {
    make(
        1,
        2,
        vec![matrix(kind(0), dim(0), dim(1))],
        vec![matrix(kind(0), dim(1), dim(0))],
        Vec::new(),
    )
}

pub fn matrix_product() -> Result<KindScheme, SemanticModelError> {
    make(
        3,
        3,
        vec![
            matrix(kind(0), dim(0), dim(1)),
            matrix(kind(1), dim(1), dim(2)),
        ],
        vec![matrix(kind(2), dim(0), dim(2))],
        vec![
            KindConstraint::Satisfies {
                kind: kind(0),
                predicate: BuiltinKindPredicate::Number,
            },
            KindConstraint::Satisfies {
                kind: kind(1),
                predicate: BuiltinKindPredicate::Number,
            },
            KindConstraint::Promotes {
                left: kind(0),
                right: kind(1),
                output: kind(2),
            },
        ],
    )
}

fn dynamic_matrix_product() -> Result<KindScheme, SemanticModelError> {
    make(
        3,
        4,
        vec![
            matrix(kind(0), dim(0), dim(1)),
            matrix(kind(1), dim(2), dim(3)),
        ],
        vec![matrix(kind(2), dim(0), dim(3))],
        vec![
            KindConstraint::Satisfies {
                kind: kind(0),
                predicate: BuiltinKindPredicate::Number,
            },
            KindConstraint::Satisfies {
                kind: kind(1),
                predicate: BuiltinKindPredicate::Number,
            },
            KindConstraint::Promotes {
                left: kind(0),
                right: kind(1),
                output: kind(2),
            },
            KindConstraint::DimensionCompatible(dim(1), dim(2)),
        ],
    )
}

pub fn matrix_dot() -> Result<KindScheme, SemanticModelError> {
    make(
        3,
        2,
        vec![
            matrix(kind(0), dim(0), dim(1)),
            matrix(kind(1), dim(0), dim(1)),
        ],
        vec![kind(2)],
        vec![
            KindConstraint::Satisfies {
                kind: kind(0),
                predicate: BuiltinKindPredicate::Number,
            },
            KindConstraint::Satisfies {
                kind: kind(1),
                predicate: BuiltinKindPredicate::Number,
            },
            KindConstraint::Promotes {
                left: kind(0),
                right: kind(1),
                output: kind(2),
            },
        ],
    )
}

fn dynamic_matrix_dot() -> Result<KindScheme, SemanticModelError> {
    make(
        3,
        4,
        vec![
            matrix(kind(0), dim(0), dim(1)),
            matrix(kind(1), dim(2), dim(3)),
        ],
        vec![kind(2)],
        vec![
            KindConstraint::Satisfies {
                kind: kind(0),
                predicate: BuiltinKindPredicate::Number,
            },
            KindConstraint::Satisfies {
                kind: kind(1),
                predicate: BuiltinKindPredicate::Number,
            },
            KindConstraint::Promotes {
                left: kind(0),
                right: kind(1),
                output: kind(2),
            },
            KindConstraint::DimensionCompatible(dim(0), dim(2)),
            KindConstraint::DimensionCompatible(dim(1), dim(3)),
        ],
    )
}

pub fn matrix_solve() -> Result<KindScheme, SemanticModelError> {
    make(
        1,
        2,
        vec![
            matrix(kind(0), dim(0), dim(0)),
            matrix(kind(0), dim(0), dim(1)),
        ],
        vec![matrix(kind(0), dim(0), dim(1))],
        vec![KindConstraint::Satisfies {
            kind: kind(0),
            predicate: BuiltinKindPredicate::FloatingPoint,
        }],
    )
}

fn dynamic_matrix_solve() -> Result<KindScheme, SemanticModelError> {
    make(
        1,
        4,
        vec![
            matrix(kind(0), dim(0), dim(1)),
            matrix(kind(0), dim(2), dim(3)),
        ],
        vec![matrix(kind(0), dim(2), dim(3))],
        vec![
            KindConstraint::Satisfies {
                kind: kind(0),
                predicate: BuiltinKindPredicate::FloatingPoint,
            },
            KindConstraint::DimensionCompatible(dim(0), dim(1)),
            KindConstraint::DimensionCompatible(dim(0), dim(2)),
        ],
    )
}

fn instantiate_concatenation_scheme(
    inputs: &[ResolvedType],
    horizontal: bool,
) -> Result<KindScheme, SemanticModelError> {
    if inputs.is_empty() {
        return Err(SemanticModelError::InvalidVariadicKindScheme);
    }
    let mut expected_inputs = Vec::with_capacity(inputs.len());
    let mut common_extents = Vec::with_capacity(inputs.len());
    let mut varying_extents = Vec::with_capacity(inputs.len());
    let mut next_dimension = 0_u32;
    for input in inputs {
        if let KindExpr::Matrix { dimensions, .. } = input.kind() {
            if dimensions.len() != 2 {
                return Err(SemanticModelError::InvalidVariadicKindScheme);
            }
            let rows = dim(next_dimension);
            let columns = dim(next_dimension.checked_add(1).ok_or(
                SemanticModelError::IdentityExhausted {
                    identity: crate::SemanticIdentityKind::DimensionParameterId,
                },
            )?);
            next_dimension =
                next_dimension
                    .checked_add(2)
                    .ok_or(SemanticModelError::IdentityExhausted {
                        identity: crate::SemanticIdentityKind::DimensionParameterId,
                    })?;
            expected_inputs.push(matrix(kind(0), rows.clone(), columns.clone()));
            common_extents.push(if horizontal {
                rows.clone()
            } else {
                columns.clone()
            });
            varying_extents.push(if horizontal { columns } else { rows });
        } else {
            expected_inputs.push(kind(0));
            common_extents.push(DimensionExpr::Constant(1));
            varying_extents.push(DimensionExpr::Constant(1));
        }
    }
    let common = common_extents[0].clone();
    let constraints = common_extents
        .iter()
        .skip(1)
        .map(|extent| KindConstraint::DimensionCompatible(common.clone(), extent.clone()))
        .collect::<Vec<_>>();
    let varying = DimensionExpr::Add(varying_extents.into_boxed_slice());
    let output = if horizontal {
        matrix(kind(0), common, varying)
    } else {
        matrix(kind(0), varying, common)
    };
    make(
        1,
        next_dimension,
        expected_inputs,
        vec![output],
        constraints,
    )
}

pub fn set_membership() -> Result<KindScheme, SemanticModelError> {
    make(
        2,
        1,
        vec![kind(0), set(kind(1), dim(0))],
        vec![BuiltinScalarKind::Bool.kind_expr()],
        vec![KindConstraint::Satisfies {
            kind: kind(1),
            predicate: BuiltinKindPredicate::Keyable,
        }],
    )
}

pub fn set_insert() -> Result<KindScheme, SemanticModelError> {
    make_with_dimensions(
        1,
        bounded_dimensions(
            1,
            Some(DimensionExpr::Add(
                vec![dim(0), DimensionExpr::Constant(1)].into_boxed_slice(),
            )),
        ),
        vec![set(kind(0), dim(0)), kind(0)],
        vec![set(kind(0), dim(1))],
        vec![KindConstraint::Satisfies {
            kind: kind(0),
            predicate: BuiltinKindPredicate::Keyable,
        }],
    )
}

pub fn set_remove() -> Result<KindScheme, SemanticModelError> {
    make_with_dimensions(
        1,
        bounded_dimensions(1, Some(dim(0))),
        vec![set(kind(0), dim(0)), kind(0)],
        vec![set(kind(0), dim(1))],
        vec![KindConstraint::Satisfies {
            kind: kind(0),
            predicate: BuiltinKindPredicate::Keyable,
        }],
    )
}

fn set_binary(output_upper_bound: DimensionExpr) -> Result<KindScheme, SemanticModelError> {
    make_with_dimensions(
        1,
        bounded_dimensions(2, Some(output_upper_bound)),
        vec![set(kind(0), dim(0)), set(kind(0), dim(1))],
        vec![set(kind(0), dim(2))],
        vec![KindConstraint::Satisfies {
            kind: kind(0),
            predicate: BuiltinKindPredicate::Keyable,
        }],
    )
}

pub fn set_union() -> Result<KindScheme, SemanticModelError> {
    set_binary(DimensionExpr::Add(vec![dim(0), dim(1)].into_boxed_slice()))
}

pub fn set_intersection() -> Result<KindScheme, SemanticModelError> {
    set_binary(DimensionExpr::Min(vec![dim(0), dim(1)].into_boxed_slice()))
}

pub fn set_difference() -> Result<KindScheme, SemanticModelError> {
    set_binary(dim(0))
}

pub fn set_symmetric_difference() -> Result<KindScheme, SemanticModelError> {
    set_union()
}

pub fn set_cartesian_product() -> Result<KindScheme, SemanticModelError> {
    make_with_dimensions(
        2,
        bounded_dimensions(
            2,
            Some(DimensionExpr::Multiply(
                vec![dim(0), dim(1)].into_boxed_slice(),
            )),
        ),
        vec![set(kind(0), dim(0)), set(kind(1), dim(1))],
        vec![set(
            KindExpr::Tuple(vec![kind(0), kind(1)].into_boxed_slice()),
            dim(2),
        )],
        Vec::new(),
    )
}

pub fn set_powerset() -> Result<KindScheme, SemanticModelError> {
    let mut extents = dimensions(1).into_vec();
    extents.push(DimensionParameterDeclaration {
        id: DimensionParameterId::new(1),
        origin: DimensionParameterOrigin::Inferred,
        lifetime: DimensionLifetime::Turn,
        lower_bound: DimensionExpr::Constant(0),
        upper_bound: Some(dim(0)),
    });
    extents.push(DimensionParameterDeclaration {
        id: DimensionParameterId::new(2),
        origin: DimensionParameterOrigin::Inferred,
        lifetime: DimensionLifetime::Turn,
        lower_bound: DimensionExpr::Constant(0),
        upper_bound: None,
    });
    make_with_dimensions(
        1,
        extents.into_boxed_slice(),
        vec![set(kind(0), dim(0))],
        vec![set(set(kind(0), dim(1)), dim(2))],
        Vec::new(),
    )
}

pub fn set_relation() -> Result<KindScheme, SemanticModelError> {
    make(
        1,
        2,
        vec![set(kind(0), dim(0)), set(kind(0), dim(1))],
        vec![BuiltinScalarKind::Bool.kind_expr()],
        vec![KindConstraint::Satisfies {
            kind: kind(0),
            predicate: BuiltinKindPredicate::Keyable,
        }],
    )
}

pub fn reduction_scalar() -> Result<KindScheme, SemanticModelError> {
    make(
        1,
        2,
        vec![matrix(kind(0), dim(0), dim(1))],
        vec![kind(0)],
        vec![KindConstraint::Satisfies {
            kind: kind(0),
            predicate: BuiltinKindPredicate::Number,
        }],
    )
}

fn n_choose_k_schemes() -> Result<Vec<KindScheme>, SemanticModelError> {
    let promotion = || KindConstraint::Promotes {
        left: kind(0),
        right: kind(1),
        output: kind(2),
    };
    let numeric = |index| KindConstraint::Satisfies {
        kind: kind(index),
        predicate: BuiltinKindPredicate::Number,
    };
    Ok(vec![
        make(
            3,
            0,
            vec![kind(0), kind(1)],
            vec![kind(2)],
            vec![numeric(0), numeric(1), promotion()],
        )?,
        make(
            3,
            4,
            vec![matrix(kind(0), dim(0), dim(1)), kind(1)],
            vec![matrix(kind(2), dim(2), dim(3))],
            vec![numeric(0), numeric(1), promotion()],
        )?,
    ])
}

fn set_comprehension_schemes() -> Result<Vec<KindScheme>, SemanticModelError> {
    let empty = KindExpr::Tuple(Box::new([]));
    Ok(vec![
        make(
            0,
            1,
            Vec::new(),
            vec![set(empty.clone(), dim(0))],
            vec![KindConstraint::Satisfies {
                kind: empty,
                predicate: BuiltinKindPredicate::Keyable,
            }],
        )?,
        variadic(
            1,
            1,
            kind(0),
            1,
            set(kind(0), dim(0)),
            vec![KindConstraint::Satisfies {
                kind: kind(0),
                predicate: BuiltinKindPredicate::Keyable,
            }],
        )?,
    ])
}

pub fn reduction_axis(column: bool) -> Result<KindScheme, SemanticModelError> {
    let output = if column {
        matrix(kind(0), dim(0), DimensionExpr::Constant(1))
    } else {
        matrix(kind(0), DimensionExpr::Constant(1), dim(1))
    };
    make(
        1,
        2,
        vec![matrix(kind(0), dim(0), dim(1))],
        vec![output],
        vec![KindConstraint::Satisfies {
            kind: kind(0),
            predicate: BuiltinKindPredicate::Number,
        }],
    )
}

pub fn string_unary() -> Result<KindScheme, SemanticModelError> {
    let string = BuiltinScalarKind::String.kind_expr();
    exact_unary(string.clone(), string)
}

pub fn string_binary() -> Result<KindScheme, SemanticModelError> {
    let string = BuiltinScalarKind::String.kind_expr();
    exact_binary(string.clone(), string.clone(), string)
}

fn number_format() -> Result<Vec<KindScheme>, SemanticModelError> {
    let precision = BuiltinScalarKind::U64.kind_expr();
    let string = BuiltinScalarKind::String.kind_expr();
    let mut schemes = Vec::new();
    // These are the exact scalar families implemented by the canonical
    // formatter. Rational/complex values do not inherit a made-up format.
    for scalar in [
        BuiltinScalarKind::U8,
        BuiltinScalarKind::U16,
        BuiltinScalarKind::U32,
        BuiltinScalarKind::U64,
        BuiltinScalarKind::U128,
        BuiltinScalarKind::I8,
        BuiltinScalarKind::I16,
        BuiltinScalarKind::I32,
        BuiltinScalarKind::I64,
        BuiltinScalarKind::I128,
        BuiltinScalarKind::F32,
        BuiltinScalarKind::F64,
    ] {
        let numeric = scalar.kind_expr();
        schemes.push(exact_binary(
            numeric.clone(),
            precision.clone(),
            string.clone(),
        )?);
        schemes.push(make(
            0,
            2,
            vec![matrix(numeric, dim(0), dim(1)), precision.clone()],
            vec![matrix(string.clone(), dim(0), dim(1))],
            Vec::new(),
        )?);
    }
    Ok(schemes)
}

fn sequence_length() -> Result<Vec<KindScheme>, SemanticModelError> {
    let count = BuiltinScalarKind::U64.kind_expr();
    Ok(vec![
        exact_unary(BuiltinScalarKind::String.kind_expr(), count.clone())?,
        make(
            1,
            2,
            vec![matrix(kind(0), dim(0), dim(1))],
            vec![count],
            Vec::new(),
        )?,
    ])
}

fn sequence_buffer(name: &str) -> Result<Vec<KindScheme>, SemanticModelError> {
    if name == "sequence/append-le-bytes" {
        // Retain the input row axis: a zero-count append can then preserve
        // the exact frozen value. Runtime geometry still requires one row.
        let byte = BuiltinScalarKind::U8.kind_expr();
        return Ok(vec![make(
            0,
            3,
            vec![
                matrix(byte.clone(), dim(0), dim(1)),
                BuiltinScalarKind::U64.kind_expr(),
                byte.clone(),
            ],
            vec![matrix(byte, dim(0), dim(2))],
            Vec::new(),
        )?]);
    }
    [
        BuiltinScalarKind::U8,
        BuiltinScalarKind::U16,
        BuiltinScalarKind::U32,
        BuiltinScalarKind::U64,
    ]
    .into_iter()
    .map(|scalar| {
        let element = scalar.kind_expr();
        let row = |count| matrix(element.clone(), DimensionExpr::Constant(1), count);
        let (inputs, count, dims) = match name {
            "sequence/with-capacity" => (
                vec![element.clone(), BuiltinScalarKind::U64.kind_expr()],
                dim(0),
                1,
            ),
            "sequence/reserve" => (
                vec![
                    matrix(element.clone(), dim(0), dim(1)),
                    BuiltinScalarKind::U64.kind_expr(),
                ],
                dim(2),
                3,
            ),
            "sequence/append" => (
                vec![matrix(element.clone(), dim(0), dim(1)), element.clone()],
                dim(2),
                3,
            ),
            "sequence/append-sublist" => (
                vec![
                    matrix(element.clone(), dim(0), dim(1)),
                    matrix(element.clone(), dim(2), dim(3)),
                    BuiltinScalarKind::U64.kind_expr(),
                    BuiltinScalarKind::U64.kind_expr(),
                ],
                dim(4),
                5,
            ),
            "sequence/clear" => (vec![matrix(element.clone(), dim(0), dim(1))], dim(2), 3),
            _ => unreachable!("maintained buffer scheme selection"),
        };
        // These are turn-shaped sequences. Their producer resolves the current
        // initialized length; a first empty visit must not freeze a recursive
        // frame's schema to zero (or an ever-growing affine expression).
        // A generic matrix parameter need not prove its row extent statically;
        // the operation checks the current row and refines the successful result.
        let output = if name == "sequence/append-sublist" {
            // Keep the destination row axis so an empty append can retain its owner.
            matrix(element.clone(), dim(0), count)
        } else {
            row(count)
        };
        make(0, dims, inputs, vec![output], Vec::new())
    })
    .collect()
}

fn sequence_sort_indices() -> Result<KindScheme, SemanticModelError> {
    let primary_length = DimensionExpr::Multiply(vec![dim(0), dim(1)].into_boxed_slice());
    let secondary_length = DimensionExpr::Multiply(vec![dim(2), dim(3)].into_boxed_slice());
    make(
        0,
        4,
        vec![
            matrix(BuiltinScalarKind::U64.kind_expr(), dim(0), dim(1)),
            BuiltinScalarKind::String.kind_expr(),
            matrix(BuiltinScalarKind::String.kind_expr(), dim(2), dim(3)),
            BuiltinScalarKind::String.kind_expr(),
        ],
        vec![matrix(
            KindExpr::Index,
            DimensionExpr::Constant(1),
            primary_length.clone(),
        )],
        vec![KindConstraint::DimensionCompatible(
            primary_length,
            secondary_length,
        )],
    )
}

fn text_lines() -> Result<KindScheme, SemanticModelError> {
    make_with_dimensions(
        0,
        bounded_dimensions(0, None),
        vec![BuiltinScalarKind::String.kind_expr()],
        vec![matrix(
            BuiltinScalarKind::String.kind_expr(),
            DimensionExpr::Constant(1),
            dim(0),
        )],
        Vec::new(),
    )
}

fn text_join() -> Result<KindScheme, SemanticModelError> {
    make(
        0,
        2,
        vec![
            matrix(BuiltinScalarKind::String.kind_expr(), dim(0), dim(1)),
            BuiltinScalarKind::String.kind_expr(),
        ],
        vec![BuiltinScalarKind::String.kind_expr()],
        Vec::new(),
    )
}

fn contains_map_key() -> Result<KindScheme, SemanticModelError> {
    make(
        2,
        1,
        vec![
            KindExpr::Map {
                key: Box::new(kind(0)),
                value: Box::new(kind(1)),
                cardinality: dim(0),
            },
            kind(0),
        ],
        vec![BuiltinScalarKind::Bool.kind_expr()],
        vec![KindConstraint::Satisfies {
            kind: kind(0),
            predicate: BuiltinKindPredicate::Keyable,
        }],
    )
}

fn insert_map() -> Result<KindScheme, SemanticModelError> {
    let map = |cardinality| KindExpr::Map {
        key: Box::new(kind(0)),
        value: Box::new(kind(1)),
        cardinality,
    };
    make(
        2,
        2,
        vec![map(dim(0)), kind(0), kind(1)],
        vec![map(dim(1))],
        vec![KindConstraint::Satisfies {
            kind: kind(0),
            predicate: BuiltinKindPredicate::Keyable,
        }],
    )
}

fn new_map() -> Result<KindScheme, SemanticModelError> {
    make(
        2,
        1,
        Vec::new(),
        vec![KindExpr::Map {
            key: Box::new(kind(0)),
            value: Box::new(kind(1)),
            cardinality: dim(0),
        }],
        vec![KindConstraint::Satisfies {
            kind: kind(0),
            predicate: BuiltinKindPredicate::Keyable,
        }],
    )
}

fn string_count_map(cardinality: DimensionExpr) -> KindExpr {
    KindExpr::Map {
        key: Box::new(BuiltinScalarKind::String.kind_expr()),
        value: Box::new(BuiltinScalarKind::U64.kind_expr()),
        cardinality,
    }
}

fn string_histogram() -> Result<KindScheme, SemanticModelError> {
    make_with_dimensions(
        0,
        dimensions(3),
        vec![matrix(
            BuiltinScalarKind::String.kind_expr(),
            dim(0),
            dim(1),
        )],
        vec![string_count_map(dim(2))],
        Vec::new(),
    )
}

fn string_count_projection(keys: bool) -> Result<KindScheme, SemanticModelError> {
    make(
        0,
        1,
        vec![string_count_map(dim(0))],
        vec![matrix(
            if keys {
                BuiltinScalarKind::String
            } else {
                BuiltinScalarKind::U64
            }
            .kind_expr(),
            DimensionExpr::Constant(1),
            dim(0),
        )],
        Vec::new(),
    )
}

fn absolute_value() -> Result<Vec<KindScheme>, SemanticModelError> {
    let mut schemes = predicate_unary_same(BuiltinKindPredicate::Real)?;
    for complex in [BuiltinScalarKind::C32, BuiltinScalarKind::C64] {
        let complex = complex.kind_expr();
        schemes.push(exact_unary(complex.clone(), complex.clone())?);
        schemes.push(make(
            0,
            2,
            vec![matrix(complex.clone(), dim(0), dim(1))],
            vec![matrix(complex, dim(0), dim(1))],
            Vec::new(),
        )?);
    }
    Ok(schemes)
}

fn string_ordering() -> Result<Vec<KindScheme>, SemanticModelError> {
    let string = BuiltinScalarKind::String.kind_expr();
    let boolean = BuiltinScalarKind::Bool.kind_expr();
    Ok(vec![
        exact_binary(string.clone(), string.clone(), boolean.clone())?,
        make(
            0,
            2,
            vec![
                matrix(string.clone(), dim(0), dim(1)),
                matrix(string, dim(0), dim(1)),
            ],
            vec![matrix(boolean, dim(0), dim(1))],
            Vec::new(),
        )?,
    ])
}

pub fn exact_assignment(arity: usize) -> Result<Vec<KindScheme>, SemanticModelError> {
    let constraints = || {
        vec![KindConstraint::Satisfies {
            kind: kind(0),
            predicate: BuiltinKindPredicate::Number,
        }]
    };
    let selector_count = arity.saturating_sub(2) as u32;
    let selectors = || (0..selector_count).map(|id| kind(id + 1));
    let mut scalar_inputs = vec![kind(0), kind(0)];
    scalar_inputs.extend(selectors());
    let sink = matrix(kind(0), dim(0), dim(1));
    let mut broadcast_inputs = vec![sink.clone(), kind(0)];
    broadcast_inputs.extend(selectors());
    let mut matrix_inputs = vec![sink.clone(), matrix(kind(0), dim(2), dim(3))];
    matrix_inputs.extend(selectors());
    let matrix_constraints = || {
        let mut result = constraints();
        if arity == 2 {
            result.extend([
                KindConstraint::DimensionEqual(dim(0), dim(2)),
                KindConstraint::DimensionEqual(dim(1), dim(3)),
            ]);
        }
        result
    };
    Ok(vec![
        make(
            1 + selector_count,
            0,
            scalar_inputs,
            vec![kind(0)],
            constraints(),
        )?,
        make(
            1 + selector_count,
            2,
            broadcast_inputs,
            vec![sink.clone()],
            constraints(),
        )?,
        make(
            1 + selector_count,
            4,
            matrix_inputs,
            vec![sink],
            matrix_constraints(),
        )?,
    ])
}

fn instantiate_table_join_scheme(
    inputs: &[ResolvedType],
    mode: TableJoinMode,
) -> Result<KindScheme, SemanticModelError> {
    let [left, right] = inputs else {
        return Err(SemanticModelError::InvalidVariadicKindScheme);
    };
    let (
        KindExpr::Table {
            columns: left_columns,
            ..
        },
        KindExpr::Table {
            columns: right_columns,
            ..
        },
    ) = (left.kind(), right.kind())
    else {
        return Err(SemanticModelError::InvalidVariadicKindScheme);
    };

    let mut left_fields = Vec::with_capacity(left_columns.len());
    for (index, field) in left_columns.iter().enumerate() {
        let parameter =
            u32::try_from(index).map_err(|_| SemanticModelError::DimensionOverflowV1)?;
        left_fields.push(crate::KindField {
            name: field.name.clone(),
            kind: kind(parameter),
        });
    }

    let mut right_fields = Vec::with_capacity(right_columns.len());
    let mut next_kind = left_fields.len();
    for field in right_columns {
        let field_kind = if let Some(index) = left_columns
            .iter()
            .position(|candidate| candidate.name == field.name)
        {
            left_fields[index].kind.clone()
        } else {
            let parameter =
                u32::try_from(next_kind).map_err(|_| SemanticModelError::DimensionOverflowV1)?;
            next_kind = next_kind
                .checked_add(1)
                .ok_or(SemanticModelError::DimensionOverflowV1)?;
            kind(parameter)
        };
        right_fields.push(crate::KindField {
            name: field.name.clone(),
            kind: field_kind,
        });
    }

    // The template fields below are kind parameters; inspect the resolved
    // input field before wrapping so an existing optional is not nested.
    let optional = |kind: &KindExpr, input: &KindExpr| match input {
        KindExpr::Option(_) => kind.clone(),
        _ => KindExpr::Option(Box::new(kind.clone())),
    };
    let left_outer = matches!(mode, TableJoinMode::RightOuter | TableJoinMode::FullOuter);
    let right_outer = matches!(mode, TableJoinMode::LeftOuter | TableJoinMode::FullOuter);
    let left_only = matches!(mode, TableJoinMode::LeftSemi | TableJoinMode::LeftAnti);
    let mut output_fields = left_fields
        .iter()
        .enumerate()
        .map(|(index, field)| crate::KindField {
            name: field.name.clone(),
            kind: if left_outer
                && !right_fields
                    .iter()
                    .any(|candidate| candidate.name == field.name)
            {
                optional(&field.kind, &left_columns[index].kind)
            } else {
                field.kind.clone()
            },
        })
        .collect::<Vec<_>>();
    if !left_only {
        output_fields.extend(
            right_fields
                .iter()
                .enumerate()
                .filter(|(_, field)| {
                    !left_fields
                        .iter()
                        .any(|candidate| candidate.name == field.name)
                })
                .map(|(index, field)| crate::KindField {
                    name: field.name.clone(),
                    kind: if right_outer {
                        optional(&field.kind, &right_columns[index].kind)
                    } else {
                        field.kind.clone()
                    },
                }),
        );
    }

    make(
        u32::try_from(next_kind).map_err(|_| SemanticModelError::DimensionOverflowV1)?,
        3,
        vec![
            KindExpr::Table {
                columns: left_fields.into_boxed_slice(),
                rows: dim(0),
            },
            KindExpr::Table {
                columns: right_fields.into_boxed_slice(),
                rows: dim(1),
            },
        ],
        vec![KindExpr::Table {
            columns: output_fields.into_boxed_slice(),
            rows: dim(2),
        }],
        Vec::new(),
    )
}

pub fn numeric_binary_for_predicate(
    predicate: BuiltinKindPredicate,
) -> Result<Vec<KindScheme>, SemanticModelError> {
    let mut schemes = promoted_binary_elementwise()?;
    schemes = schemes
        .into_iter()
        .map(|scheme| {
            let mut constraints = scheme.constraints().to_vec();
            constraints.push(KindConstraint::Satisfies {
                kind: kind(0),
                predicate,
            });
            constraints.push(KindConstraint::Satisfies {
                kind: kind(1),
                predicate,
            });
            KindScheme::new(
                scheme.kind_parameters().to_vec().into_boxed_slice(),
                scheme.dimension_parameters().to_vec().into_boxed_slice(),
                scheme.inputs().clone(),
                scheme.outputs().to_vec().into_boxed_slice(),
                constraints.into_boxed_slice(),
            )
        })
        .collect::<Result<Vec<_>, _>>()?;
    Ok(schemes)
}

pub fn maintained_source_scheme_template(name: &str) -> Option<SourceSchemeTemplate> {
    match name {
        "math/add" => Some(SourceSchemeTemplate::Addition),
        "compare/lt" | "compare/lte" | "compare/gt" | "compare/gte" => {
            Some(SourceSchemeTemplate::OrderedComparison)
        }
        "matrix/horzcat" => Some(SourceSchemeTemplate::HorizontalConcatenation),
        "matrix/vertcat" => Some(SourceSchemeTemplate::VerticalConcatenation),
        "set/define" => Some(SourceSchemeTemplate::SetDefinition),
        "table/join" => Some(SourceSchemeTemplate::TableJoin(TableJoinMode::Inner)),
        "table/left-outer-join" => Some(SourceSchemeTemplate::TableJoin(TableJoinMode::LeftOuter)),
        "table/right-outer-join" => {
            Some(SourceSchemeTemplate::TableJoin(TableJoinMode::RightOuter))
        }
        "table/full-outer-join" => Some(SourceSchemeTemplate::TableJoin(TableJoinMode::FullOuter)),
        "table/left-semi-join" => Some(SourceSchemeTemplate::TableJoin(TableJoinMode::LeftSemi)),
        "table/left-anti-join" => Some(SourceSchemeTemplate::TableJoin(TableJoinMode::LeftAnti)),
        _ => None,
    }
}

pub fn instantiate_source_scheme_template(
    template: SourceSchemeTemplate,
    inputs: &[ResolvedType],
) -> Result<Vec<KindScheme>, SemanticModelError> {
    if template == SourceSchemeTemplate::Addition {
        // An exact scalar interval pair keeps its declared bounds. Resident
        // execution checks the sum; interval addition grants neither numeric
        // promotion nor scalar/matrix broadcasting to interval kinds.
        let mut schemes =
            maintained_source_schemes("math/add")?.expect("addition has maintained source schemes");
        if let [left, right] = inputs
            && let KindExpr::IntegerInterval(interval) = left.kind()
            && interval.is_valid()
            && left.kind() == right.kind()
        {
            schemes.push(exact_binary(
                left.kind().clone(),
                right.kind().clone(),
                left.kind().clone(),
            )?);
        }
        return Ok(schemes);
    }
    if template == SourceSchemeTemplate::OrderedComparison {
        // Preserve the existing numeric, Index and String declarations. Only
        // an identical valid interval pair adds its exact resident-capable
        // scalar/elementwise family; Ordered alone must not widen admission of
        // unrelated scalar or broadcast layouts.
        let mut schemes = maintained_source_schemes("compare/lt")?
            .expect("ordering has maintained source schemes");
        let leaf = |input: &ResolvedType| match input.kind() {
            KindExpr::Matrix {
                element,
                dimensions,
            } if dimensions.len() == 2 => element.as_ref().clone(),
            kind => kind.clone(),
        };
        if let [left, right] = inputs {
            let element = leaf(left);
            if let KindExpr::IntegerInterval(interval) = &element
                && interval.is_valid()
                && leaf(right) == element
            {
                schemes.push(exact_binary(
                    element.clone(),
                    element.clone(),
                    BuiltinScalarKind::Bool.kind_expr(),
                )?);
                schemes.extend(exact_elementwise_comparison(element)?);
            }
        }
        return Ok(schemes);
    }
    let scheme = match template {
        SourceSchemeTemplate::HorizontalConcatenation => {
            instantiate_concatenation_scheme(inputs, true)?
        }
        SourceSchemeTemplate::VerticalConcatenation => {
            instantiate_concatenation_scheme(inputs, false)?
        }
        SourceSchemeTemplate::SetDefinition => {
            let cardinality =
                u64::try_from(inputs.len()).map_err(|_| SemanticModelError::DimensionOverflowV1)?;
            variadic(
                1,
                0,
                kind(0),
                1,
                set(kind(0), DimensionExpr::Constant(cardinality)),
                vec![KindConstraint::Satisfies {
                    kind: kind(0),
                    predicate: BuiltinKindPredicate::Keyable,
                }],
            )?
        }
        SourceSchemeTemplate::TableJoin(mode) => instantiate_table_join_scheme(inputs, mode)?,
        SourceSchemeTemplate::OrderedComparison => {
            unreachable!("ordering returns its scheme family above")
        }
        SourceSchemeTemplate::Addition => {
            unreachable!("addition returns its scheme family above")
        }
    };
    Ok(vec![scheme])
}

/// Maintained mathematical operation families. This single registry supplies
/// both source type schemes and portable operation-contract selection.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum MaintainedMathOperation {
    PromotedBinary,
    Power,
    Modulus,
    Negate,
    AbsoluteValue,
    FloatingBinary,
    FloatingUnary,
}

impl MaintainedMathOperation {
    pub const fn input_count(self) -> usize {
        match self {
            Self::Negate | Self::AbsoluteValue | Self::FloatingUnary => 1,
            Self::PromotedBinary | Self::Power | Self::Modulus | Self::FloatingBinary => 2,
        }
    }
}

pub fn maintained_math_operation(name: &str) -> Option<MaintainedMathOperation> {
    use MaintainedMathOperation::*;
    Some(match name {
        "math/add" | "math/sub" | "math/mul" | "math/div" => PromotedBinary,
        "math/pow" => Power,
        "math/mod" => Modulus,
        "math/neg" => Negate,
        "math/abs" => AbsoluteValue,
        "math/atan2" | "math/copysign" | "math/fdim" | "math/fmod" | "math/nextafter"
        | "math/remainder" | "math/bessel/jn" | "math/bessel/yn" => FloatingBinary,
        "math/acos" | "math/acosh" | "math/acot" | "math/acsc" | "math/asec" | "math/asin"
        | "math/asinh" | "math/atan" | "math/atanh" | "math/bessel/j0" | "math/bessel/j1"
        | "math/bessel/y0" | "math/bessel/y1" | "math/cbrt" | "math/ceil" | "math/cos"
        | "math/cosh" | "math/cot" | "math/csc" | "math/erf" | "math/erfc" | "math/floor"
        | "math/lgamma" | "math/log" | "math/log10" | "math/log1p" | "math/log2" | "math/rint"
        | "math/round" | "math/roundeven" | "math/sec" | "math/sin" | "math/sinh" | "math/sqrt"
        | "math/tan" | "math/tanh" | "math/tgamma" | "math/trunc" => FloatingUnary,
        _ => return None,
    })
}

/// Returns the explicit storage-blind schemes for one maintained source name.
/// This registry is catalog-construction metadata; execution never inspects
/// operation names to infer a result.
pub fn maintained_source_schemes(
    name: &str,
) -> Result<Option<Vec<KindScheme>>, SemanticModelError> {
    if let Some(operation) = maintained_math_operation(name) {
        use MaintainedMathOperation::*;
        let schemes = match operation {
            PromotedBinary => promoted_binary_elementwise()?,
            Power => {
                let mut schemes = promoted_binary_elementwise()?;
                // Rational power retains its integral exponent instead of
                // promoting that input to the base's rational kind.
                schemes.push(exact_binary(
                    BuiltinScalarKind::R64.kind_expr(),
                    BuiltinScalarKind::I32.kind_expr(),
                    BuiltinScalarKind::R64.kind_expr(),
                )?);
                schemes
            }
            Modulus => {
                let mut schemes = numeric_binary_for_predicate(BuiltinKindPredicate::Integer)?;
                schemes.extend(numeric_binary_for_predicate(
                    BuiltinKindPredicate::FloatingPoint,
                )?);
                schemes
            }
            Negate => predicate_unary_same(BuiltinKindPredicate::Negatable)?,
            AbsoluteValue => absolute_value()?,
            FloatingBinary => numeric_binary_for_predicate(BuiltinKindPredicate::FloatingPoint)?,
            FloatingUnary => predicate_unary_same(BuiltinKindPredicate::FloatingPoint)?,
        };
        return Ok(Some(schemes));
    }
    let schemes = match name {
        name if name.contains("-assign") => {
            let arity = if name.ends_with("/range-all") || name.ends_with("/range") {
                3
            } else {
                2
            };
            exact_assignment(arity)?
        }
        "compare/seq" | "compare/sneq" => strict_comparison_exact()?,
        "compare/eq" | "compare/neq" => {
            let mut values = comparison_exact()?;
            values.extend(comparison_promoted()?);
            values
        }
        "compare/gt" | "compare/gte" | "compare/lt" | "compare/lte" => {
            let mut values = comparison_promoted_for_predicate(BuiltinKindPredicate::Ordered)?;
            values.extend(string_ordering()?);
            values
        }
        "compare/max" | "compare/min" => {
            numeric_binary_for_predicate(BuiltinKindPredicate::Ordered)?
        }
        "logic/not" => bool_unary()?,
        "bits/not" | "bits/leading-zeros" | "bits/trailing-zeros" => vec![exact_unary(
            BuiltinScalarKind::U64.kind_expr(),
            BuiltinScalarKind::U64.kind_expr(),
        )?],
        "bits/and"
        | "bits/or"
        | "bits/xor"
        | "bits/shift-left-wrap"
        | "bits/shift-right-wrap"
        | "bits/wrapping-add"
        | "bits/wrapping-sub"
        | "bits/wrapping-mul" => vec![exact_binary(
            BuiltinScalarKind::U64.kind_expr(),
            BuiltinScalarKind::U64.kind_expr(),
            BuiltinScalarKind::U64.kind_expr(),
        )?],
        "logic/and" | "logic/or" | "logic/xor" => bool_binary()?,
        "range/exclusive" | "range/inclusive" => vec![range_binary()?],
        "range/exclusive-increment" | "range/inclusive-increment" => vec![range_ternary()?],
        "matrix/transpose" => vec![matrix_transpose()?],
        "matrix/matmul" => vec![matrix_product()?, dynamic_matrix_product()?],
        "matrix/dot" => vec![matrix_dot()?, dynamic_matrix_dot()?],
        "matrix/solve" => vec![matrix_solve()?, dynamic_matrix_solve()?],
        "matrix/comprehension" => vec![variadic(
            1,
            2,
            kind(0),
            0,
            matrix(kind(0), dim(0), dim(1)),
            Vec::new(),
        )?],
        "set/comprehension" => set_comprehension_schemes()?,
        "set/element-of" | "set/not-element-of" => vec![set_membership()?],
        "set/insert" => vec![set_insert()?],
        "set/remove" => vec![set_remove()?],
        "set/union" => vec![set_union()?],
        "set/intersection" => vec![set_intersection()?],
        "set/difference" => vec![set_difference()?],
        "set/symmetric-difference" => vec![set_symmetric_difference()?],
        "set/cartesian-product" => vec![set_cartesian_product()?],
        "set/powerset" => vec![set_powerset()?],
        "set/equals"
        | "set/not_equals"
        | "set/subset"
        | "set/proper_subset"
        | "set/superset"
        | "set/proper-superset"
        | "set/disjoint" => vec![set_relation()?],
        "set/size" => vec![make(
            1,
            1,
            vec![set(kind(0), dim(0))],
            vec![BuiltinScalarKind::U64.kind_expr()],
            Vec::new(),
        )?],
        "string/concat" => vec![string_binary()?],
        "number/parse-u64" => vec![exact_unary(
            BuiltinScalarKind::String.kind_expr(),
            BuiltinScalarKind::U64.kind_expr(),
        )?],
        "number/format" => number_format()?,
        "sequence/length" => sequence_length()?,
        name @ ("sequence/with-capacity"
        | "sequence/reserve"
        | "sequence/append"
        | "sequence/append-le-bytes"
        | "sequence/append-sublist"
        | "sequence/clear") => sequence_buffer(name)?,
        "sequence/sort-indices" => vec![sequence_sort_indices()?],
        "text/lines" => vec![text_lines()?],
        "text/join" => vec![text_join()?],
        "map/new" => vec![new_map()?],
        "map/insert" => vec![insert_map()?],
        "map/contains-key" => vec![contains_map_key()?],
        "map/histogram" => vec![string_histogram()?],
        "map/keys" => vec![string_count_projection(true)?],
        "map/values" => vec![string_count_projection(false)?],
        "stats/sum/column" => vec![reduction_axis(true)?],
        "stats/sum/row" => vec![reduction_axis(false)?],
        "combinatorics/n-choose-k" => n_choose_k_schemes()?,
        _ => return Ok(None),
    };
    Ok(Some(schemes))
}
