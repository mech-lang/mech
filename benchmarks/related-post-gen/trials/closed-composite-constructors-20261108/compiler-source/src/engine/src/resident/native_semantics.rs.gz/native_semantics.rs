//! Private proof of a selected maintained scalar implementation.
//!
//! Public operation names, cost declarations, and generic core attachments do
//! not grant this authority. Only finished, exact maintained binder branches
//! attach CandidateWitness. The shared binder validates and replaces it with
//! a seal over its exact final BoundCall. Neither witness type is exported.
use std::sync::Arc;

use mech_core::{
    AccessMode, AliasPolicy, BoundCall, BoundCallOrigin, BoundResidentKernel,
    ChangeDetectionPolicy, DeliveryMode, ExecutionTarget, ExternalInteraction, IntegerWidth,
    OutputConstruction, ResidentKernelBindRequest, ResidentPortLayout, ResidentShape,
    ResidentValueKind, ResolvedOperationContract, SchemaBody, ShapeRule,
};

pub(crate) use crate::native_scalar::{NativeScalarKind, NativeScalarOp};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) struct NativeScalarSemantics {
    op: NativeScalarOp,
}
impl NativeScalarSemantics {
    // The optional adapter and its backend-independent seal tests consume
    // this private read-only view. Resident-only production keeps it absent.
    #[cfg(any(test, feature = "native-artifact"))]
    pub(crate) fn op(self) -> NativeScalarOp {
        self.op
    }
    pub(crate) fn inputs(&self) -> &'static [NativeScalarKind] {
        self.op.signature().0
    }
    pub(crate) fn output(self) -> NativeScalarKind {
        self.op.signature().1
    }
}

#[derive(Clone)]
struct CandidateWitness {
    semantics: NativeScalarSemantics,
    contract: ResolvedOperationContract,
    inputs: Box<[ResidentPortLayout]>,
    output: ResidentPortLayout,
    parameters: Box<[u64]>,
}

struct SealedWitness {
    semantics: NativeScalarSemantics,
    bound_call: BoundCall,
}

fn scalar_port(
    request: &ResidentKernelBindRequest<'_>,
    port: &ResidentPortLayout,
    kind: NativeScalarKind,
) -> bool {
    let Some(entry) = request.schemas.entry(port.schema_id) else {
        return false;
    };
    let expected = match kind {
        NativeScalarKind::Bool => SchemaBody::Bool,
        #[cfg(any(feature = "convert", feature = "native-artifact"))]
        NativeScalarKind::U8 => SchemaBody::UnsignedInteger(IntegerWidth::W8),
        #[cfg(any(feature = "convert", feature = "native-artifact"))]
        NativeScalarKind::U16 => SchemaBody::UnsignedInteger(IntegerWidth::W16),
        #[cfg(any(feature = "convert", feature = "native-artifact"))]
        NativeScalarKind::U32 => SchemaBody::UnsignedInteger(IntegerWidth::W32),

        NativeScalarKind::U64 => SchemaBody::UnsignedInteger(IntegerWidth::W64),
        NativeScalarKind::I64 => SchemaBody::SignedInteger(IntegerWidth::W64),
        NativeScalarKind::F64 => SchemaBody::FloatingPoint(mech_core::FloatWidth::W64),
    };
    entry.key() == port.schema_key
        && entry.schema().body() == &expected
        && entry.schema().dimension_parameters().is_empty()
        && port.shape == ResidentShape::SCALAR
        && port.shape_instance.parameter_values().is_empty()
        && port.resolved_selector.is_none()
        && port.kind
            == match kind {
                NativeScalarKind::Bool => ResidentValueKind::Bool,
                NativeScalarKind::F64 => ResidentValueKind::F64,
                NativeScalarKind::U64 | NativeScalarKind::I64 => ResidentValueKind::Snapshot,
                #[cfg(any(feature = "convert", feature = "native-artifact"))]
                NativeScalarKind::U8 | NativeScalarKind::U16 | NativeScalarKind::U32 => {
                    ResidentValueKind::Snapshot
                }
            }
}

fn scalar_request(
    request: &ResidentKernelBindRequest<'_>,
    semantics: NativeScalarSemantics,
) -> bool {
    let ResolvedOperationContract::Declared(contract) = request.contract else {
        return false;
    };
    let [output] = contract.outputs.as_ref() else {
        return false;
    };
    // Casts retain their actual maintained KernelReported contract. This
    // operation-specific exception does not relax arithmetic certification.
    let cast = match semantics.op {
        #[cfg(feature = "convert")]
        NativeScalarOp::U64ToI64
        | NativeScalarOp::I64ToU64
        | NativeScalarOp::U64ToF64
        | NativeScalarOp::I64ToF64
        | NativeScalarOp::F64ToU64
        | NativeScalarOp::F64ToI64
        | NativeScalarOp::U8ToU16
        | NativeScalarOp::U8ToU32
        | NativeScalarOp::U8ToU64
        | NativeScalarOp::U16ToU8
        | NativeScalarOp::U16ToU32
        | NativeScalarOp::U16ToU64
        | NativeScalarOp::U32ToU8
        | NativeScalarOp::U32ToU16
        | NativeScalarOp::U32ToU64
        | NativeScalarOp::U64ToU8
        | NativeScalarOp::U64ToU16
        | NativeScalarOp::U64ToU32 => true,
        _ => false,
    };
    let change = if cast {
        ChangeDetectionPolicy::KernelReported
    } else {
        ChangeDetectionPolicy::ExactScalar
    };
    // These exact unary implementations have the maintained SameAsInput
    // contract. Binary arithmetic, comparisons and BoolNot retain Declared.
    let shape = if cast
        || matches!(
            semantics.op,
            NativeScalarOp::I64Neg | NativeScalarOp::F64Neg | NativeScalarOp::F64Sqrt
        ) {
        ShapeRule::SameAsInput { input: 0 }
    } else {
        ShapeRule::Declared
    };
    request.inputs.len() == semantics.inputs().len()
        && contract.inputs.len() == request.inputs.len()
        && contract.interaction == ExternalInteraction::Pure
        && contract
            .inputs
            .iter()
            .zip(request.inputs)
            .all(|(policy, layout)| {
                policy.schema == layout.schema_id
                    && policy.access == AccessMode::Read
                    && policy.delivery == DeliveryMode::Signal
            })
        && output.schema == request.output.schema_id
        && output.access == AccessMode::Write
        && output.delivery == DeliveryMode::Signal
        && output.construction == (OutputConstruction::FullWrite { shape })
        && output.alias == AliasPolicy::NoAlias
        && output.change_detection == change
        && request
            .inputs
            .iter()
            .zip(semantics.inputs())
            .all(|(port, kind)| scalar_port(request, port, *kind))
        && scalar_port(request, &request.output, semantics.output())
}

/// Used only by exact successful maintained scalar binder branches, after
/// every execution metadata/cost builder is finished. No public engine entry
/// accepts an attachment or supplies semantic certification by name.
pub(super) fn certify(
    request: &ResidentKernelBindRequest<'_>,
    kernel: BoundResidentKernel,
    op: NativeScalarOp,
) -> BoundResidentKernel {
    let semantics = NativeScalarSemantics { op };
    if !scalar_request(request, semantics) {
        return kernel;
    }
    let candidate = CandidateWitness {
        semantics,
        contract: request.contract.clone(),
        inputs: request.inputs.into(),
        output: request.output.clone(),
        parameters: kernel.parameters().into(),
    };
    kernel.with_lowering_witness(Arc::new(candidate))
}

fn bound_call_matches(request: &ResidentKernelBindRequest<'_>, bound_call: &BoundCall) -> bool {
    let ResolvedOperationContract::Declared(_) = request.contract else {
        return false;
    };
    let Ok(expected) = mech_core::ResolvedOperationDescriptor::from_resolved_contract(
        bound_call.operation_descriptor().canonical_name.clone(),
        request.contract,
    ) else {
        return false;
    };
    bound_call.origin() == &BoundCallOrigin::ArtifactOperation
        && matches!(
            bound_call.target(),
            ExecutionTarget::ResidentCpu | ExecutionTarget::Native
        )
        && bound_call.operation_descriptor() == &expected
        && bound_call.inputs().len() == request.inputs.len()
        && bound_call.outputs().len() == 1
        && bound_call
            .inputs()
            .iter()
            .zip(request.inputs)
            .all(|(descriptor, port)| {
                descriptor.schema().key() == port.schema_key
                    && descriptor.shape() == &port.shape_instance
            })
        && bound_call.outputs()[0].schema().key() == request.output.schema_key
        && bound_call.outputs()[0].shape() == &request.output.shape_instance
}

/// The shared resident/native binder owns this final metadata attachment. A
/// custom or changed delegated kernel remains usable by the resident but
/// cannot obtain our private semantic seal.
pub(super) fn bind_call(
    kernel: BoundResidentKernel,
    request: &ResidentKernelBindRequest<'_>,
    bound_call: BoundCall,
) -> BoundResidentKernel {
    let candidate = kernel
        .lowering_witness::<CandidateWitness>()
        .filter(|candidate| {
            candidate.contract == *request.contract
                && candidate.inputs.as_ref() == request.inputs
                && candidate.output == request.output
                && candidate.parameters.as_ref() == kernel.parameters()
                && scalar_request(request, candidate.semantics)
                && bound_call_matches(request, &bound_call)
        })
        .cloned();
    let accounting = kernel.work_accounting();
    if let Some(candidate) = candidate {
        // The seal and executor each retain this exact call. Ordinary kernels
        // have one consumer and can take the original metadata without a clone.
        let kernel = kernel
            .with_bound_call(bound_call.clone())
            .with_work_accounting(accounting);
        kernel.with_lowering_witness(Arc::new(SealedWitness {
            semantics: candidate.semantics,
            bound_call,
        }))
    } else {
        kernel
            .with_bound_call(bound_call)
            .with_work_accounting(accounting)
    }
}

/// Returns only typed semantics after auditing the actual selected kernel's
/// private seal. It never returns a witness or executes a kernel/input read.
#[allow(
    dead_code,
    reason = "canonical-native adapter is optional; private seal inspection is exercised by witness tests"
)]
pub(crate) fn validated_scalar(kernel: &BoundResidentKernel) -> Option<NativeScalarSemantics> {
    let seal = kernel.lowering_witness::<SealedWitness>()?;
    (kernel.bound_call()? == &seal.bound_call).then_some(seal.semantics)
}

#[cfg(test)]
mod tests {
    use super::*;
    use mech_core::{
        DeclaredOperationContract, FunctionCatalog, FunctionCatalogBuilder,
        ImplementationMemoryClass, ResidentKernelError, ResidentKernelInputs,
        ResidentKernelWorkAccounting, ResidentOperationKey, ResidentSnapshotOutput,
        ResidentValueMut, ResolvedInputPort, ResolvedOperationDescriptor, ResolvedOutputPort,
        ResolvedValueDescriptor, SchemaDraft, SchemaId, SchemaTable, SchemaTableBuilder,
    };
    use std::sync::atomic::{AtomicUsize, Ordering};

    fn catalog() -> FunctionCatalog {
        let mut builder = FunctionCatalogBuilder::new();
        crate::resident::numeric::install(&mut builder).unwrap();
        builder.build().unwrap()
    }

    struct Binding {
        schemas: SchemaTable,
        contract: ResolvedOperationContract,
        inputs: Box<[ResidentPortLayout]>,
        output: ResidentPortLayout,
    }
    impl Binding {
        fn scalar(op: NativeScalarOp) -> Self {
            let mut builder = SchemaTableBuilder::new();
            let handles = [
                SchemaBody::Bool,
                SchemaBody::UnsignedInteger(IntegerWidth::W64),
                SchemaBody::SignedInteger(IntegerWidth::W64),
                SchemaBody::FloatingPoint(mech_core::FloatWidth::W64),
                #[cfg(any(feature = "convert", feature = "native-artifact"))]
                SchemaBody::UnsignedInteger(IntegerWidth::W8),
                #[cfg(any(feature = "convert", feature = "native-artifact"))]
                SchemaBody::UnsignedInteger(IntegerWidth::W16),
                #[cfg(any(feature = "convert", feature = "native-artifact"))]
                SchemaBody::UnsignedInteger(IntegerWidth::W32),
            ]
            .into_iter()
            .map(|body| {
                builder
                    .insert(
                        SchemaDraft {
                            dimension_parameters: Box::new([]),
                            body,
                        }
                        .finalize()
                        .unwrap(),
                    )
                    .unwrap()
            })
            .collect::<Vec<_>>();
            let build = builder.finish().unwrap();
            let ids = handles
                .into_iter()
                .map(|handle| build.resolve(handle).unwrap())
                .collect::<Vec<_>>();
            let schemas = build.table;
            let semantics = NativeScalarSemantics { op };
            let layout = |kind| {
                let schema_id = match kind {
                    NativeScalarKind::Bool => ids[0],
                    NativeScalarKind::U64 => ids[1],
                    NativeScalarKind::I64 => ids[2],
                    NativeScalarKind::F64 => ids[3],
                    #[cfg(any(feature = "convert", feature = "native-artifact"))]
                    NativeScalarKind::U8 => ids[4],
                    #[cfg(any(feature = "convert", feature = "native-artifact"))]
                    NativeScalarKind::U16 => ids[5],
                    #[cfg(any(feature = "convert", feature = "native-artifact"))]
                    NativeScalarKind::U32 => ids[6],
                };
                ResidentPortLayout {
                    schema_id,
                    schema_key: schemas.entry(schema_id).unwrap().key(),
                    kind: match kind {
                        NativeScalarKind::Bool => ResidentValueKind::Bool,
                        NativeScalarKind::F64 => ResidentValueKind::F64,
                        NativeScalarKind::U64 | NativeScalarKind::I64 => {
                            ResidentValueKind::Snapshot
                        }
                        #[cfg(any(feature = "convert", feature = "native-artifact"))]
                        NativeScalarKind::U8 | NativeScalarKind::U16 | NativeScalarKind::U32 => {
                            ResidentValueKind::Snapshot
                        }
                    },
                    shape: ResidentShape::SCALAR,
                    shape_instance: schemas
                        .get(schema_id)
                        .unwrap()
                        .instantiate_shape(Box::new([]))
                        .unwrap(),
                    activation_fixed_shape: true,
                    resolved_selector: None,
                }
            };
            let inputs = semantics
                .inputs()
                .iter()
                .copied()
                .map(layout)
                .collect::<Vec<_>>()
                .into_boxed_slice();
            let output = layout(semantics.output());
            let contract = ResolvedOperationContract::Declared(DeclaredOperationContract {
                inputs: inputs
                    .iter()
                    .map(|port| ResolvedInputPort {
                        schema: port.schema_id,
                        access: AccessMode::Read,
                        delivery: DeliveryMode::Signal,
                    })
                    .collect::<Vec<_>>()
                    .into_boxed_slice(),
                outputs: Box::new([ResolvedOutputPort {
                    schema: output.schema_id,
                    access: AccessMode::Write,
                    delivery: DeliveryMode::Signal,
                    construction: OutputConstruction::FullWrite {
                        shape: if matches!(
                            op,
                            NativeScalarOp::I64Neg
                                | NativeScalarOp::F64Neg
                                | NativeScalarOp::F64Sqrt
                        ) {
                            ShapeRule::SameAsInput { input: 0 }
                        } else {
                            ShapeRule::Declared
                        },
                    },
                    alias: AliasPolicy::NoAlias,
                    change_detection: ChangeDetectionPolicy::ExactScalar,
                }]),
                interaction: ExternalInteraction::Pure,
            });
            Self {
                schemas,
                contract,
                inputs,
                output,
            }
        }
        fn request(&self) -> ResidentKernelBindRequest<'_> {
            ResidentKernelBindRequest {
                contract: &self.contract,
                schemas: &self.schemas,
                inputs: &self.inputs,
                output: self.output.clone(),
            }
        }
        fn call(&self, module: &str, operation: &str) -> BoundCall {
            let descriptor = |port: &ResidentPortLayout| {
                ResolvedValueDescriptor::from_schema(
                    self.schemas.get(port.schema_id).unwrap().clone(),
                    port.shape_instance.clone(),
                )
                .unwrap()
            };
            BoundCall::artifact_operation(
                ResolvedOperationDescriptor::from_resolved_contract(
                    format!("{module}/{operation}"),
                    &self.contract,
                )
                .unwrap(),
                self.inputs
                    .iter()
                    .map(descriptor)
                    .collect::<Vec<_>>()
                    .into_boxed_slice(),
                Box::new([descriptor(&self.output)]),
                ResidentOperationKey::new(Box::new([module.into()]), operation.into()).unwrap(),
            )
            .unwrap()
        }
        fn bind(&self, catalog: &FunctionCatalog, module: &str, name: &str) -> BoundResidentKernel {
            let entry = catalog.resident_factory(&[module.into()], name).unwrap();
            (entry.factory())(&self.request()).unwrap()
        }
        fn snapshot_output(&self) -> ResidentSnapshotOutput {
            ResidentSnapshotOutput {
                schema: self.output.schema_id,
                schema_key: self.output.schema_key,
                shape: self.output.shape_instance.clone(),
                exact_cardinality: None,
                maximum_cardinality: None,
            }
        }
    }

    #[cfg(any(feature = "convert", feature = "native-artifact"))]
    #[test]
    fn shared_unsigned_scalar_layouts_do_not_depend_on_conversion_factories() {
        use NativeScalarKind::{Bool, U8, U16, U32};
        use NativeScalarOp::{U8Eq, U16Eq, U32Eq};
        for (op, kind, wrong_kind) in [(U8Eq, U8, U16), (U16Eq, U16, U32), (U32Eq, U32, U8)] {
            assert_eq!(op.signature(), (&[kind, kind][..], Bool));
            let binding = Binding::scalar(op);
            let request = binding.request();
            for port in &binding.inputs {
                assert!(scalar_port(&request, port, kind));
                assert!(!scalar_port(&request, port, wrong_kind));
                let mut wrong_representation = port.clone();
                wrong_representation.kind = ResidentValueKind::Bool;
                assert!(!scalar_port(&request, &wrong_representation, kind));
            }
            assert!(scalar_port(&request, &binding.output, Bool));
            assert!(!scalar_port(&request, &binding.output, kind));
        }
    }

    #[test]
    fn maintained_scalar_branches_require_final_binding_before_exposing_semantics() {
        use NativeScalarOp::*;
        let catalog = catalog();
        for (module, name, op) in [
            ("math", "add", U64Add),
            ("math", "sub", U64Sub),
            ("math", "mul", U64Mul),
            ("math", "div", U64Div),
            ("math", "mod", U64Rem),
            ("compare", "eq", U64Eq),
            ("compare", "neq", U64Ne),
            ("compare", "lt", U64Lt),
            ("compare", "lte", U64Le),
            ("compare", "gt", U64Gt),
            ("compare", "gte", U64Ge),
            ("logic", "and", BoolAnd),
            ("logic", "or", BoolOr),
            ("logic", "xor", BoolXor),
            ("logic", "not", BoolNot),
            ("compare", "eq", BoolEq),
            ("compare", "neq", BoolNe),
        ] {
            let binding = Binding::scalar(op);
            let kernel = binding.bind(&catalog, module, name);
            assert!(
                validated_scalar(&kernel).is_none(),
                "unsealed {module}/{name}"
            );
            let sealed = bind_call(
                kernel.clone(),
                &binding.request(),
                binding.call(module, name),
            );
            assert_eq!(validated_scalar(&sealed).map(|s| s.op()), Some(op));
            assert_eq!(validated_scalar(&sealed.clone()).map(|s| s.op()), Some(op));
            assert_eq!(sealed.parameters(), kernel.parameters());
        }
    }

    #[cfg(any(feature = "convert", feature = "native-artifact"))]
    #[test]
    fn maintained_u32_arithmetic_requires_its_exact_final_scalar_binding() {
        use NativeScalarOp::*;
        let catalog = catalog();
        for (name, op) in [("mul", U32Mul), ("div", U32Div), ("mod", U32Rem)] {
            assert_eq!(
                op.signature(),
                (
                    &[NativeScalarKind::U32, NativeScalarKind::U32][..],
                    NativeScalarKind::U32
                )
            );
            let binding = Binding::scalar(op);
            let kernel = binding.bind(&catalog, "math", name);
            assert!(validated_scalar(&kernel).is_none());
            let sealed = bind_call(
                kernel.clone(),
                &binding.request(),
                binding.call("math", name),
            );
            assert_eq!(validated_scalar(&sealed).map(|s| s.op()), Some(op));
            assert_eq!(sealed.parameters(), kernel.parameters());
            // Changing the final selected binding invalidates the candidate;
            // an operation name or matching port count grants no authority.
            let changed = sealed.clone().with_bound_call(binding.call("math", "add"));
            assert!(validated_scalar(&changed).is_none());
            assert!(validated_scalar(&sealed.with_retained_state(Arc::new(0u64))).is_none());
        }
    }

    #[test]
    #[cfg(feature = "i64")]
    fn signed_scalar_branches_seal_only_their_exact_finished_contracts() {
        use NativeScalarOp::*;
        let catalog = catalog();
        for (module, name, op) in [
            ("math", "add", I64Add),
            ("math", "sub", I64Sub),
            ("math", "mul", I64Mul),
            ("math", "div", I64Div),
            ("math", "mod", I64Rem),
            ("math", "neg", I64Neg),
            ("compare", "eq", I64Eq),
            ("compare", "neq", I64Ne),
            ("compare", "lt", I64Lt),
            ("compare", "lte", I64Le),
            ("compare", "gt", I64Gt),
            ("compare", "gte", I64Ge),
        ] {
            let binding = Binding::scalar(op);
            let kernel = binding.bind(&catalog, module, name);
            assert!(validated_scalar(&kernel).is_none());
            let sealed = bind_call(
                kernel.clone(),
                &binding.request(),
                binding.call(module, name),
            );
            assert_eq!(validated_scalar(&sealed).map(|value| value.op()), Some(op));
            assert_eq!(
                validated_scalar(&sealed.clone()).map(|value| value.op()),
                Some(op)
            );
            assert!(validated_scalar(&sealed.with_retained_state(Arc::new(0u64))).is_none());
            let changed = kernel
                .clone()
                .with_snapshot_schemas(binding.schemas.clone());
            assert!(
                validated_scalar(&bind_call(
                    changed,
                    &binding.request(),
                    binding.call(module, name)
                ))
                .is_none()
            );
        }
        let mut unary = Binding::scalar(I64Neg);
        let semantics = NativeScalarSemantics { op: I64Neg };
        assert!(scalar_request(&unary.request(), semantics));
        let ResolvedOperationContract::Declared(contract) = &mut unary.contract else {
            unreachable!()
        };
        contract.outputs[0].construction = OutputConstruction::FullWrite {
            shape: ShapeRule::Declared,
        };
        assert!(!scalar_request(&unary.request(), semantics));
        let mut binary = Binding::scalar(I64Add);
        let ResolvedOperationContract::Declared(contract) = &mut binary.contract else {
            unreachable!()
        };
        contract.outputs[0].construction = OutputConstruction::FullWrite {
            shape: ShapeRule::SameAsInput { input: 0 },
        };
        assert!(!scalar_request(
            &binary.request(),
            NativeScalarSemantics { op: I64Add }
        ));
        assert!(!scalar_request(
            &Binding::scalar(U64Add).request(),
            NativeScalarSemantics { op: I64Add }
        ));
    }

    #[test]
    fn dense_f64_branches_seal_exact_contracts_without_certifying_snapshot_libm() {
        use NativeScalarOp::*;
        let catalog = catalog();
        for (module, name, op) in [
            ("math", "add", F64Add),
            ("math", "sub", F64Sub),
            ("math", "mul", F64Mul),
            ("math", "div", F64Div),
            ("math", "neg", F64Neg),
            ("math", "sqrt", F64Sqrt),
            ("compare", "eq", F64Eq),
            ("compare", "neq", F64Ne),
            ("compare", "lt", F64Lt),
            ("compare", "lte", F64Le),
            ("compare", "gt", F64Gt),
            ("compare", "gte", F64Ge),
        ] {
            let binding = Binding::scalar(op);
            let kernel = binding.bind(&catalog, module, name);
            assert!(validated_scalar(&kernel).is_none());
            let sealed = bind_call(kernel, &binding.request(), binding.call(module, name));
            assert_eq!(
                validated_scalar(&sealed).map(|semantics| semantics.op()),
                Some(op)
            );
            assert_eq!(
                validated_scalar(&sealed.clone()).map(|semantics| semantics.op()),
                Some(op)
            );
            assert!(validated_scalar(&sealed.with_retained_state(Arc::new(0u64))).is_none());
        }
        let mut snapshot_sqrt = Binding::scalar(F64Sqrt);
        snapshot_sqrt.inputs[0].kind = ResidentValueKind::Snapshot;
        snapshot_sqrt.output.kind = ResidentValueKind::Snapshot;
        let kernel = snapshot_sqrt.bind(&catalog, "math", "sqrt");
        assert!(
            kernel.snapshot_schemas().is_some(),
            "actual Snapshot/libm binder selected"
        );
        assert!(
            validated_scalar(&bind_call(
                kernel,
                &snapshot_sqrt.request(),
                snapshot_sqrt.call("math", "sqrt")
            ))
            .is_none()
        );
        for op in [F64Neg, F64Sqrt] {
            let mut binding = Binding::scalar(op);
            let ResolvedOperationContract::Declared(contract) = &mut binding.contract else {
                unreachable!()
            };
            contract.outputs[0].construction = OutputConstruction::FullWrite {
                shape: ShapeRule::Declared,
            };
            assert!(!scalar_request(
                &binding.request(),
                NativeScalarSemantics { op }
            ));
        }
        let mut binary = Binding::scalar(F64Add);
        let ResolvedOperationContract::Declared(contract) = &mut binary.contract else {
            unreachable!()
        };
        contract.outputs[0].construction = OutputConstruction::FullWrite {
            shape: ShapeRule::SameAsInput { input: 0 },
        };
        assert!(!scalar_request(
            &binary.request(),
            NativeScalarSemantics { op: F64Add }
        ));
    }

    #[test]
    fn every_delegated_semantic_or_cost_change_loses_private_authority() {
        let binding = Binding::scalar(NativeScalarOp::U64Add);
        let kernel = binding.bind(&catalog(), "math", "add");
        let call = binding.call("math", "add");
        let changed = [
            kernel
                .clone()
                .with_work_accounting(kernel.work_accounting()),
            kernel
                .clone()
                .with_snapshot_output(binding.snapshot_output()),
            kernel
                .clone()
                .with_snapshot_schemas(binding.schemas.clone()),
            kernel.clone().with_bound_call(call.clone()),
            kernel
                .clone()
                .with_retained_state(Arc::new(AtomicUsize::new(0))),
        ];
        for changed in changed {
            assert!(
                validated_scalar(&bind_call(changed, &binding.request(), call.clone())).is_none()
            );
        }
        let sealed = bind_call(kernel, &binding.request(), call);
        assert_eq!(
            validated_scalar(&sealed).map(|s| s.op()),
            Some(NativeScalarOp::U64Add)
        );
        assert!(
            validated_scalar(
                &sealed
                    .clone()
                    .with_work_accounting(sealed.work_accounting())
            )
            .is_none()
        );
        assert!(validated_scalar(&sealed.clone().with_retained_state(Arc::new(0u64))).is_none());
        assert!(
            validated_scalar(
                &sealed
                    .clone()
                    .with_snapshot_output(binding.snapshot_output())
            )
            .is_none()
        );
        assert!(
            validated_scalar(
                &sealed
                    .clone()
                    .with_snapshot_schemas(binding.schemas.clone())
            )
            .is_none()
        );
        assert!(
            validated_scalar(&sealed.clone().with_bound_call(binding.call("math", "add")))
                .is_none()
        );
    }

    static EXECUTIONS: AtomicUsize = AtomicUsize::new(0);
    fn custom_executor(
        _: &BoundResidentKernel,
        _: &dyn ResidentKernelInputs,
        _: ResidentValueMut<'_>,
    ) -> Result<bool, ResidentKernelError> {
        EXECUTIONS.fetch_add(1, Ordering::SeqCst);
        Err(ResidentKernelError::Arithmetic)
    }
    fn custom_factory(
        _: &ResidentKernelBindRequest<'_>,
    ) -> Result<BoundResidentKernel, mech_core::ResidentKernelBindError> {
        Ok(BoundResidentKernel::new(custom_executor, Box::new([]))
            .with_work_accounting(ResidentKernelWorkAccounting::RuntimeMetered)
            // Even the public typed semantic description is not a private seal.
            .with_lowering_witness(Arc::new(NativeScalarSemantics {
                op: NativeScalarOp::U64Add,
            })))
    }
    #[test]
    fn same_name_cost_claim_and_public_attachment_cannot_certify_replacement() {
        let binding = Binding::scalar(NativeScalarOp::U64Add);
        let mut builder = FunctionCatalogBuilder::new();
        builder
            .insert_resident_factory(
                ["math"],
                "add",
                ImplementationMemoryClass::NoAdditionalScratch,
                custom_factory,
            )
            .unwrap();
        let replacement = binding.bind(&builder.build().unwrap(), "math", "add");
        assert!(
            validated_scalar(&bind_call(
                replacement,
                &binding.request(),
                binding.call("math", "add")
            ))
            .is_none()
        );
        assert_eq!(EXECUTIONS.load(Ordering::SeqCst), 0);
    }

    #[test]
    fn genuine_candidate_is_bound_to_its_exact_request_not_just_schema_name() {
        let mut binding = Binding::scalar(NativeScalarOp::U64Add);
        let kernel = binding.bind(&catalog(), "math", "add");
        binding.inputs[0].activation_fixed_shape = false;
        let sealed = bind_call(kernel, &binding.request(), binding.call("math", "add"));
        assert!(validated_scalar(&sealed).is_none());
        let binding = Binding::scalar(NativeScalarOp::BoolNot);
        let kernel = binding.bind(&catalog(), "logic", "not");
        let wrong = Binding::scalar(NativeScalarOp::U64Add).call("math", "add");
        assert!(validated_scalar(&bind_call(kernel, &binding.request(), wrong)).is_none());
    }

    #[test]
    fn uncertified_numeric_shapes_and_operations_remain_uncertified() {
        let binding = Binding::scalar(NativeScalarOp::U64Add);
        let kernel = binding.bind(&catalog(), "math", "pow");
        assert!(
            validated_scalar(&bind_call(
                kernel,
                &binding.request(),
                binding.call("math", "pow")
            ))
            .is_none()
        );
        // Shape-one matrix schemas are not scalar semantic kinds.
        let matrix = SchemaDraft {
            dimension_parameters: Box::new([]),
            body: SchemaBody::Matrix {
                element: Box::new(SchemaBody::Bool),
                dimensions: Box::new([
                    mech_core::DimensionExpr::Constant(1),
                    mech_core::DimensionExpr::Constant(1),
                ]),
            },
        }
        .finalize()
        .unwrap();
        let mut builder = SchemaTableBuilder::new();
        let handle = builder.insert(matrix).unwrap();
        let build = builder.finish().unwrap();
        let id: SchemaId = build.resolve(handle).unwrap();
        let mut binding = Binding::scalar(NativeScalarOp::BoolNot);
        binding.schemas = build.table;
        binding.inputs[0].schema_id = id;
        binding.inputs[0].schema_key = binding.schemas.entry(id).unwrap().key();
        binding.inputs[0].shape_instance = binding
            .schemas
            .get(id)
            .unwrap()
            .instantiate_shape(Box::new([]))
            .unwrap();
        binding.output = binding.inputs[0].clone();
        let request = binding.request();
        assert!(!scalar_request(
            &request,
            NativeScalarSemantics {
                op: NativeScalarOp::BoolNot
            }
        ));
    }

    #[cfg(feature = "convert")]
    #[test]
    fn completed_scalar_converters_require_their_own_exact_contract_and_final_seal() {
        use NativeScalarOp::*;
        let mut builder = FunctionCatalogBuilder::new();
        super::super::conversion::install(&mut builder).unwrap();
        let catalog = builder.build().unwrap();
        for op in [
            U64ToI64, I64ToU64, U64ToF64, I64ToF64, F64ToU64, F64ToI64, U8ToU16, U8ToU32, U8ToU64,
            U16ToU8, U16ToU32, U16ToU64, U32ToU8, U32ToU16, U32ToU64, U64ToU8, U64ToU16, U64ToU32,
        ] {
            let mut binding = Binding::scalar(op);
            let policy =
                mech_core::maintained_operation_contract("convert/kind", 1, false).unwrap();
            let ResolvedOperationContract::Declared(contract) = &mut binding.contract else {
                panic!()
            };
            contract.outputs[0].construction = policy.outputs[0].construction.clone();
            contract.outputs[0].change_detection = policy.outputs[0].change_detection;
            assert_eq!(
                contract.outputs[0].change_detection,
                ChangeDetectionPolicy::KernelReported
            );
            let kernel = binding.bind(&catalog, "convert", "kind");
            // A completed actual binder candidate is not a final-call seal.
            assert!(validated_scalar(&kernel).is_none());
            let sealed = bind_call(kernel, &binding.request(), binding.call("convert", "kind"));
            assert_eq!(validated_scalar(&sealed).unwrap().op(), op);
            assert_eq!(validated_scalar(&sealed.clone()).unwrap().op(), op);
            assert!(
                validated_scalar(
                    &sealed
                        .clone()
                        .with_snapshot_schemas(binding.schemas.clone())
                )
                .is_none()
            );
            assert!(
                validated_scalar(&sealed.clone().with_retained_state(Arc::new(0u64))).is_none()
            );
            let semantics = NativeScalarSemantics { op };
            let ResolvedOperationContract::Declared(contract) = &mut binding.contract else {
                panic!()
            };
            contract.outputs[0].change_detection = ChangeDetectionPolicy::ExactScalar;
            assert!(!scalar_request(&binding.request(), semantics));
            let ResolvedOperationContract::Declared(contract) = &mut binding.contract else {
                panic!()
            };
            contract.outputs[0].change_detection = ChangeDetectionPolicy::KernelReported;
            contract.outputs[0].construction = OutputConstruction::FullWrite {
                shape: ShapeRule::Declared,
            };
            assert!(!scalar_request(&binding.request(), semantics));
        }
        // The cast policy must never become a global arithmetic relaxation.
        let mut arithmetic = Binding::scalar(U64Add);
        let ResolvedOperationContract::Declared(contract) = &mut arithmetic.contract else {
            panic!()
        };
        contract.outputs[0].change_detection = ChangeDetectionPolicy::KernelReported;
        assert!(!scalar_request(
            &arithmetic.request(),
            NativeScalarSemantics { op: U64Add }
        ));
    }
}
