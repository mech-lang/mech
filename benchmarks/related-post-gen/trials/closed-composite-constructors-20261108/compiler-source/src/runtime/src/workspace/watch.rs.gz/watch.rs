use std::{
    collections::BTreeSet,
    ffi::OsStr,
    path::{Path, PathBuf},
    sync::{
        Arc, Mutex,
        mpsc::{self, Receiver},
    },
};

use notify::{Event, EventKind, RecommendedWatcher, RecursiveMode, Watcher};

use super::*;

pub struct RuntimeWorkspaceWatcher {
    watcher: RecommendedWatcher,
    receiver: Receiver<notify::Result<Event>>,
    event_notifier: SharedWatchEventNotifier,
    watched_paths: BTreeSet<RuntimeWorkspaceWatchedPath>,
    watched_keys: BTreeSet<RuntimeWorkspaceWatchKey>,
}

type WatchEventNotifier = Arc<dyn Fn() + Send + Sync + 'static>;
type SharedWatchEventNotifier = Arc<Mutex<Option<WatchEventNotifier>>>;

#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
struct RuntimeWorkspaceWatchedPath {
    watch_path: PathBuf,
    authorized_path: PathBuf,
    filter_paths: Vec<PathBuf>,
    recursive: bool,
}

#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
struct RuntimeWorkspaceWatchKey {
    path: PathBuf,
    recursive: bool,
}

fn watch_key(watch: &RuntimeWorkspaceWatchedPath) -> RuntimeWorkspaceWatchKey {
    RuntimeWorkspaceWatchKey {
        path: normalize_workspace_watch_path(&watch.watch_path),
        recursive: watch.recursive,
    }
}

#[derive(Clone, Debug)]
pub struct RuntimeWorkspaceWatchPoll {
    pub events: Vec<RuntimeWorkspaceWatchEvent>,
    pub refresh: Option<RuntimeWorkspaceRefresh>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct RuntimeWorkspaceWatchEvent {
    pub path: PathBuf,
    pub kind: RuntimeWorkspaceWatchEventKind,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum RuntimeWorkspaceWatchEventKind {
    Created,
    Modified,
    Removed,
    Other,
}

impl RuntimeWorkspaceWatcher {
    pub fn open(workspace: &RuntimeWorkspace, runtime: &mut MechRuntime) -> MResult<Self> {
        let (sender, receiver) = mpsc::channel();
        let event_notifier = SharedWatchEventNotifier::default();
        let callback_notifier = event_notifier.clone();

        let watcher = notify::recommended_watcher(move |event| {
            let notifier = callback_notifier
                .lock()
                .ok()
                .and_then(|notifier| notifier.clone());
            if sender.send(event).is_ok()
                && let Some(notifier) = notifier
            {
                notifier();
            }
        })
        .map_err(|error| watch_error(format!("could not create watcher: {}", error)))?;

        let mut watcher = Self {
            watcher,
            receiver,
            event_notifier,
            watched_paths: BTreeSet::new(),
            watched_keys: BTreeSet::new(),
        };

        watcher.sync(workspace, runtime)?;

        Ok(watcher)
    }

    /// Registers a lightweight wake-up callback for newly queued filesystem events.
    ///
    /// The callback runs on the platform watcher's thread, so callers should only
    /// use it to signal their own event loop and perform the actual refresh there.
    pub fn set_event_notifier(&mut self, notifier: impl Fn() + Send + Sync + 'static) {
        if let Ok(mut current) = self.event_notifier.lock() {
            *current = Some(Arc::new(notifier));
        }
    }

    pub fn poll(
        &mut self,
        workspace: &mut RuntimeWorkspace,
        runtime: &mut MechRuntime,
        options: ModuleBuildOptions,
    ) -> MResult<RuntimeWorkspaceWatchPoll> {
        let events = self.drain_events()?;

        if events.is_empty() {
            return Ok(RuntimeWorkspaceWatchPoll {
                events,
                refresh: None,
            });
        }

        let refresh = workspace.refresh(runtime, options)?;
        self.sync(workspace, runtime)?;

        Ok(RuntimeWorkspaceWatchPoll {
            events,
            refresh: Some(refresh),
        })
    }

    pub fn sync(&mut self, workspace: &RuntimeWorkspace, runtime: &mut MechRuntime) -> MResult<()> {
        let desired = preserve_existing_watch_authorizations(
            &self.watched_paths,
            desired_watch_paths(workspace),
        );

        if let Some(subject) = workspace.config().capability_subject.as_deref() {
            for watch in &desired {
                crate::check_fs_capability(
                    runtime.capability_kernel_mut(),
                    subject,
                    crate::FS_WATCH,
                    &watch.authorized_path,
                )?;
            }
        }

        let desired_keys: BTreeSet<_> = desired.iter().map(watch_key).collect();
        let current_keys = self.watched_keys.clone();

        for key in current_keys.difference(&desired_keys) {
            self.watcher.unwatch(&key.path).map_err(|error| {
                watch_error(format!(
                    "could not unwatch `{}`: {}",
                    key.path.display(),
                    error,
                ))
            })?;
            self.watched_keys.remove(key);
        }

        for key in desired_keys
            .difference(&self.watched_keys)
            .cloned()
            .collect::<Vec<_>>()
        {
            let recursive_mode = if key.recursive {
                RecursiveMode::Recursive
            } else {
                RecursiveMode::NonRecursive
            };

            self.watcher
                .watch(&key.path, recursive_mode)
                .map_err(|error| {
                    watch_error(format!(
                        "could not watch `{}`: {}",
                        key.path.display(),
                        error,
                    ))
                })?;

            self.watched_keys.insert(key);
        }

        self.watched_paths = desired;
        Ok(())
    }

    pub fn drain_events(&mut self) -> MResult<Vec<RuntimeWorkspaceWatchEvent>> {
        let mut events = Vec::new();

        while let Ok(event) = self.receiver.try_recv() {
            let event =
                event.map_err(|error| watch_error(format!("watch event error: {}", error)))?;

            events.extend(
                watch_events_from_notify_event(event)
                    .into_iter()
                    .filter(|event| event_allowed_by_watches(&self.watched_paths, &event.path)),
            );
        }

        Ok(events)
    }

    pub fn watched_paths(&self) -> Vec<PathBuf> {
        self.watched_keys
            .iter()
            .map(|key| key.path.clone())
            .collect()
    }
}

fn desired_watch_paths(workspace: &RuntimeWorkspace) -> BTreeSet<RuntimeWorkspaceWatchedPath> {
    let mut paths = BTreeSet::new();

    for folder in &workspace.config().folders {
        if let Some(path) = local_workspace_path(&workspace.config().root, &folder.specifier) {
            paths.insert(RuntimeWorkspaceWatchedPath {
                watch_path: path.clone(),
                authorized_path: path,
                filter_paths: Vec::new(),
                recursive: folder.recursive,
            });
        }
    }

    for target in &workspace.config().targets {
        for watch in local_workspace_target_watches(&workspace.config().root, &target.specifier) {
            paths.insert(watch);
        }
    }

    paths
}

fn local_workspace_path(root: &Path, specifier: &str) -> Option<PathBuf> {
    if specifier.contains("://") {
        return None;
    }

    let path = PathBuf::from(specifier);
    let joined = if path.is_absolute() {
        path
    } else {
        root.join(path)
    };

    joined.canonicalize().ok()
}

fn local_workspace_target_watches(
    root: &Path,
    specifier: &str,
) -> Vec<RuntimeWorkspaceWatchedPath> {
    if specifier.contains("://") {
        return Vec::new();
    }
    let path = PathBuf::from(specifier);
    let joined = if path.is_absolute() {
        path
    } else {
        root.join(path)
    };
    let target_exists = joined.exists();
    let is_symlink = std::fs::symlink_metadata(&joined)
        .map(|metadata| metadata.file_type().is_symlink())
        .unwrap_or(false);

    if target_exists && joined.is_dir() {
        let Some(path) = joined.canonicalize().ok() else {
            return Vec::new();
        };
        return vec![RuntimeWorkspaceWatchedPath {
            watch_path: path.clone(),
            authorized_path: path,
            filter_paths: Vec::new(),
            recursive: false,
        }];
    }

    let filter_path = joined;
    let normalized_filter_path = normalize_workspace_watch_path(&filter_path);
    let authorized_path = if target_exists {
        normalized_filter_path.clone()
    } else {
        filter_path.clone()
    };

    let Some(parent) = filter_path
        .parent()
        .and_then(|parent| parent.canonicalize().ok())
    else {
        return Vec::new();
    };

    if !is_symlink {
        return vec![RuntimeWorkspaceWatchedPath {
            watch_path: parent,
            authorized_path,
            filter_paths: vec![normalized_filter_path],
            recursive: false,
        }];
    }

    let mut filter_paths = Vec::new();
    push_unique_path(&mut filter_paths, filter_path);
    push_unique_path(&mut filter_paths, normalized_filter_path.clone());

    let mut watches = vec![RuntimeWorkspaceWatchedPath {
        watch_path: parent,
        authorized_path: authorized_path.clone(),
        filter_paths,
        recursive: false,
    }];

    if target_exists {
        let canonical_target = normalized_filter_path;
        if let Some(canonical_parent) = canonical_target
            .parent()
            .and_then(|parent| parent.canonicalize().ok())
        {
            if canonical_parent != watches[0].watch_path {
                watches.push(RuntimeWorkspaceWatchedPath {
                    watch_path: canonical_parent,
                    authorized_path,
                    filter_paths: vec![canonical_target],
                    recursive: false,
                });
            }
        }
    }

    watches
}

fn normalize_workspace_watch_path(path: &Path) -> PathBuf {
    for ancestor in path.ancestors() {
        let Ok(mut canonical) = ancestor.canonicalize() else {
            continue;
        };
        let Ok(suffix) = path.strip_prefix(ancestor) else {
            return path.to_path_buf();
        };
        if suffix.as_os_str() != OsStr::new("") {
            canonical.push(suffix);
        }
        return canonical;
    }

    path.to_path_buf()
}

fn workspace_watch_paths_equivalent(left: &Path, right: &Path) -> bool {
    left == right || normalize_workspace_watch_path(left) == normalize_workspace_watch_path(right)
}

fn push_unique_path(paths: &mut Vec<PathBuf>, path: PathBuf) {
    if !paths.contains(&path) {
        paths.push(path);
    }
}

fn event_allowed_by_watches(watches: &BTreeSet<RuntimeWorkspaceWatchedPath>, path: &Path) -> bool {
    let normalized = normalize_workspace_watch_path(path);
    watches.iter().any(|watch| {
        if !watch.filter_paths.is_empty() {
            return watch
                .filter_paths
                .iter()
                .any(|target| workspace_watch_paths_equivalent(path, target));
        }
        let watch_path = normalize_workspace_watch_path(&watch.watch_path);
        if watch.recursive {
            normalized.starts_with(&watch_path)
        } else {
            normalized == watch_path || normalized.parent() == Some(watch_path.as_path())
        }
    })
}

fn watch_filter_matches(
    existing: &RuntimeWorkspaceWatchedPath,
    desired: &RuntimeWorkspaceWatchedPath,
) -> bool {
    if existing.filter_paths.is_empty() || desired.filter_paths.is_empty() {
        return false;
    }
    workspace_watch_paths_equivalent(&existing.watch_path, &desired.watch_path)
        && desired.filter_paths.iter().any(|desired_path| {
            existing
                .filter_paths
                .iter()
                .any(|existing_path| workspace_watch_paths_equivalent(desired_path, existing_path))
        })
}

fn can_preserve_watch_authorization(
    existing: &RuntimeWorkspaceWatchedPath,
    desired: &RuntimeWorkspaceWatchedPath,
) -> bool {
    if !watch_filter_matches(existing, desired) {
        return false;
    }

    if desired.authorized_path.exists() {
        return workspace_watch_paths_equivalent(
            &desired.authorized_path,
            &existing.authorized_path,
        );
    }

    true
}

fn preserve_existing_watch_authorizations(
    current: &BTreeSet<RuntimeWorkspaceWatchedPath>,
    desired: BTreeSet<RuntimeWorkspaceWatchedPath>,
) -> BTreeSet<RuntimeWorkspaceWatchedPath> {
    let mut result = BTreeSet::new();
    for mut watch in desired {
        if let Some(existing) = current
            .iter()
            .find(|existing| watch_filter_matches(existing, &watch))
        {
            if can_preserve_watch_authorization(existing, &watch) {
                watch.authorized_path = existing.authorized_path.clone();
                for path in &existing.filter_paths {
                    push_unique_path(&mut watch.filter_paths, path.clone());
                }
            }
        }
        result.insert(watch);
    }
    for existing in current {
        if should_preserve_missing_external_target_watch(existing, &result) {
            result.insert(existing.clone());
        }
    }
    result
}

fn should_preserve_missing_external_target_watch(
    existing: &RuntimeWorkspaceWatchedPath,
    desired: &BTreeSet<RuntimeWorkspaceWatchedPath>,
) -> bool {
    !existing.filter_paths.is_empty()
        && !existing.authorized_path.exists()
        && !desired
            .iter()
            .any(|watch| watch_filter_matches(existing, watch))
        && desired.iter().any(|watch| {
            !watch.filter_paths.is_empty()
                && workspace_watch_paths_equivalent(
                    &watch.authorized_path,
                    &existing.authorized_path,
                )
                && !workspace_watch_paths_equivalent(&watch.watch_path, &existing.watch_path)
        })
}

fn watch_events_from_notify_event(event: Event) -> Vec<RuntimeWorkspaceWatchEvent> {
    let kind = watch_event_kind(&event.kind);

    if matches!(kind, RuntimeWorkspaceWatchEventKind::Other) {
        return Vec::new();
    }

    event
        .paths
        .into_iter()
        .filter(|path| path.is_file() || path.is_dir() || !path.exists())
        .map(|path| RuntimeWorkspaceWatchEvent {
            path,
            kind: kind.clone(),
        })
        .collect()
}

fn watch_event_kind(kind: &EventKind) -> RuntimeWorkspaceWatchEventKind {
    match kind {
        EventKind::Create(_) => RuntimeWorkspaceWatchEventKind::Created,
        EventKind::Modify(_) => RuntimeWorkspaceWatchEventKind::Modified,
        EventKind::Remove(_) => RuntimeWorkspaceWatchEventKind::Removed,
        _ => RuntimeWorkspaceWatchEventKind::Other,
    }
}

fn watch_error(reason: impl Into<String>) -> MechError {
    MechError::new(
        RuntimeWorkspaceWatchError {
            reason: reason.into(),
        },
        None,
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::RuntimeBuilder;

    fn single_target_watch(root: &Path, specifier: &str) -> RuntimeWorkspaceWatchedPath {
        let watches = local_workspace_target_watches(root, specifier);
        assert_eq!(
            watches.len(),
            1,
            "expected exactly one watch for `{specifier}`, got {watches:?}",
        );
        watches.into_iter().next().unwrap()
    }

    #[test]
    fn watcher_rejects_path_without_watch_capability() {
        let root = std::env::temp_dir().join(format!(
            "mech-watch-capability-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        std::fs::create_dir_all(&root).unwrap();
        let workspace = RuntimeWorkspace::open(
            RuntimeWorkspaceConfig::new(&root)
                .capability_subject(crate::SERVE_HOST_SUBJECT)
                .folder("."),
        )
        .unwrap();
        let mut runtime = RuntimeBuilder::new()
            .capability_kernel(crate::SharedCapabilityKernel::new())
            .build()
            .unwrap();
        assert!(RuntimeWorkspaceWatcher::open(&workspace, &mut runtime).is_err());
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn target_watch_falls_back_to_existing_parent_when_target_is_deleted() {
        let root = std::env::temp_dir().join(format!(
            "mech-watch-target-parent-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        std::fs::create_dir_all(&root).unwrap();
        let target = root.join("main.mec");
        std::fs::write(&target, "x := 1").unwrap();
        let watch = single_target_watch(&root, "main.mec");
        assert_eq!(watch.watch_path, root.canonicalize().unwrap());
        assert_eq!(watch.authorized_path, target.canonicalize().unwrap());
        assert_eq!(
            watch.filter_paths,
            vec![normalize_workspace_watch_path(&target)],
        );
        std::fs::remove_file(&target).unwrap();
        let watch = single_target_watch(&root, "main.mec");
        assert_eq!(watch.watch_path, root.canonicalize().unwrap());
        assert_eq!(watch.authorized_path, target);
        assert_eq!(
            watch.filter_paths,
            vec![normalize_workspace_watch_path(&watch.authorized_path)],
        );
        assert_eq!(watch.filter_paths.len(), 1);
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn target_watch_ignores_non_local_specifiers() {
        let root = std::env::temp_dir();
        assert!(local_workspace_target_watches(&root, "https://example.com/main.mec").is_empty());
    }
    #[test]
    fn file_scoped_watch_grant_authorizes_parent_runtime_watch() {
        let root = std::env::temp_dir().join(format!(
            "mech-watch-file-grant-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        std::fs::create_dir_all(&root).unwrap();
        let target = root.join("main.mec");
        std::fs::write(&target, "x := 1").unwrap();

        let mut ids = crate::DefaultIdGenerator::new();
        let mut authority = crate::HostFilesystemAuthority::new(
            crate::MECH_TOOL_SUBJECT,
            crate::SharedCapabilityKernel::new(),
        );
        authority
            .grant_path(&mut ids, &target, false, [crate::FS_WATCH])
            .unwrap();
        authority
            .delegate_path_to(
                &mut ids,
                crate::SERVE_HOST_SUBJECT,
                &target,
                false,
                [crate::FS_WATCH],
            )
            .unwrap();
        let mut runtime = RuntimeBuilder::new()
            .capability_kernel(authority.kernel().clone())
            .build()
            .unwrap();
        let workspace = RuntimeWorkspace::open(
            RuntimeWorkspaceConfig::new(&root)
                .capability_subject(crate::SERVE_HOST_SUBJECT)
                .target("main", "main.mec"),
        )
        .unwrap();
        let watcher = RuntimeWorkspaceWatcher::open(&workspace, &mut runtime).unwrap();
        assert_eq!(watcher.watched_paths(), vec![root.canonicalize().unwrap()]);
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn file_target_watch_filters_sibling_events() {
        let root = std::env::temp_dir().join(format!(
            "mech-watch-filter-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        std::fs::create_dir_all(&root).unwrap();
        let target = root.join("main.mec");
        let sibling = root.join("sibling.mec");
        std::fs::write(&target, "x := 1").unwrap();
        std::fs::write(&sibling, "y := 2").unwrap();
        let watch = single_target_watch(&root, "main.mec");
        let mut watches = BTreeSet::new();
        watches.insert(watch);
        assert!(event_allowed_by_watches(&watches, &target));
        assert!(!event_allowed_by_watches(&watches, &sibling));
        std::fs::remove_file(&target).unwrap();
        assert!(event_allowed_by_watches(&watches, &target));
        std::fs::remove_dir_all(root).unwrap();
    }

    #[cfg(unix)]
    #[test]
    fn target_watch_filter_accepts_symlink_link_and_canonical_paths_but_rejects_siblings() {
        use std::os::unix::fs::symlink;
        let root = std::env::temp_dir().join(format!(
            "mech-watch-symlink-filter-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        std::fs::create_dir_all(&root).unwrap();
        let real = root.join("real.mec");
        let link = root.join("link.mec");
        let sibling = root.join("sibling.mec");
        std::fs::write(&real, "x := 1").unwrap();
        std::fs::write(&sibling, "y := 2").unwrap();
        symlink(&real, &link).unwrap();

        let watch = single_target_watch(&root, "link.mec");
        assert_eq!(watch.watch_path, root.canonicalize().unwrap());
        assert_eq!(watch.authorized_path, real.canonicalize().unwrap());
        assert!(watch.filter_paths.contains(&link));
        assert!(watch.filter_paths.contains(&real.canonicalize().unwrap()));

        let mut watches = BTreeSet::new();
        watches.insert(watch);
        assert!(event_allowed_by_watches(&watches, &link));
        assert!(event_allowed_by_watches(&watches, &real));
        assert!(!event_allowed_by_watches(&watches, &sibling));
        std::fs::remove_file(&link).unwrap();
        assert!(event_allowed_by_watches(&watches, &link));
        std::fs::remove_dir_all(root).unwrap();
    }

    #[cfg(unix)]
    #[test]
    fn symlink_file_watch_preserves_authorized_path_after_link_delete() {
        use std::os::unix::fs::symlink;
        let root = std::env::temp_dir().join(format!(
            "mech-watch-symlink-preserve-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        std::fs::create_dir_all(&root).unwrap();
        let real = root.join("real.mec");
        let link = root.join("link.mec");
        let sibling = root.join("sibling.mec");
        std::fs::write(&real, "x := 1").unwrap();
        std::fs::write(&sibling, "y := 2").unwrap();
        symlink(&real, &link).unwrap();

        let existing_watch = single_target_watch(&root, "link.mec");
        let canonical_real = real.canonicalize().unwrap();
        assert_eq!(existing_watch.authorized_path, canonical_real);
        assert!(existing_watch.filter_paths.contains(&link));
        assert!(existing_watch.filter_paths.contains(&canonical_real));

        let mut current = BTreeSet::new();
        current.insert(existing_watch);
        std::fs::remove_file(&link).unwrap();
        let mut desired = BTreeSet::new();
        desired.insert(single_target_watch(&root, "link.mec"));
        let reconciled = preserve_existing_watch_authorizations(&current, desired);
        let watch = reconciled.iter().next().unwrap();

        assert_eq!(watch.authorized_path, canonical_real);
        assert!(watch.filter_paths.contains(&link));
        assert!(event_allowed_by_watches(&reconciled, &link));
        assert!(!event_allowed_by_watches(&reconciled, &sibling));
        std::fs::remove_dir_all(root).unwrap();
    }

    #[cfg(unix)]
    #[test]
    fn retargeted_symlink_watch_uses_new_authorization_and_filters() {
        use std::os::unix::fs::symlink;
        let root = std::env::temp_dir().join(format!(
            "mech-watch-symlink-retarget-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        std::fs::create_dir_all(&root).unwrap();
        let a = root.join("a.mec");
        let b = root.join("b.mec");
        let link = root.join("link.mec");
        let sibling = root.join("sibling.mec");
        std::fs::write(&a, "x := 1").unwrap();
        std::fs::write(&b, "x := 2").unwrap();
        std::fs::write(&sibling, "y := 3").unwrap();
        symlink(&a, &link).unwrap();

        let current = local_workspace_target_watches(&root, "link.mec")
            .into_iter()
            .collect::<BTreeSet<_>>();
        let canonical_a = a.canonicalize().unwrap();
        let canonical_b = b.canonicalize().unwrap();
        assert!(
            current
                .iter()
                .any(|watch| watch.authorized_path == canonical_a)
        );

        std::fs::remove_file(&link).unwrap();
        symlink(&b, &link).unwrap();

        let desired = local_workspace_target_watches(&root, "link.mec")
            .into_iter()
            .collect::<BTreeSet<_>>();
        let reconciled = preserve_existing_watch_authorizations(&current, desired);
        let link_watch = reconciled
            .iter()
            .find(|watch| watch.filter_paths.contains(&link))
            .unwrap();

        assert_eq!(link_watch.authorized_path, canonical_b);
        assert_ne!(link_watch.authorized_path, canonical_a);
        assert!(link_watch.filter_paths.contains(&link));
        assert!(link_watch.filter_paths.contains(&canonical_b));
        assert!(!link_watch.filter_paths.contains(&canonical_a));
        assert!(event_allowed_by_watches(&reconciled, &link));
        assert!(event_allowed_by_watches(&reconciled, &b));
        assert!(!event_allowed_by_watches(&reconciled, &sibling));
        std::fs::remove_dir_all(root).unwrap();
    }

    #[cfg(unix)]
    #[test]
    fn symlink_target_outside_link_dir_watches_link_and_target_parents() {
        use std::os::unix::fs::symlink;
        let root = std::env::temp_dir().join(format!(
            "mech-watch-symlink-outside-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let link_dir = root.join("links");
        let shared_dir = root.join("shared");
        std::fs::create_dir_all(&link_dir).unwrap();
        std::fs::create_dir_all(&shared_dir).unwrap();
        let real = shared_dir.join("real.mec");
        let link = link_dir.join("link.mec");
        let link_sibling = link_dir.join("sibling.mec");
        let target_sibling = shared_dir.join("sibling.mec");
        std::fs::write(&real, "x := 1").unwrap();
        std::fs::write(&link_sibling, "y := 2").unwrap();
        std::fs::write(&target_sibling, "z := 3").unwrap();
        symlink(&real, &link).unwrap();

        let watches = local_workspace_target_watches(&root, "links/link.mec");
        let link_parent = link_dir.canonicalize().unwrap();
        let target_parent = shared_dir.canonicalize().unwrap();
        assert!(
            watches
                .iter()
                .any(|watch| watch.watch_path == link_parent && watch.filter_paths.contains(&link))
        );
        assert!(watches.iter().any(|watch| watch.watch_path == target_parent
            && watch.filter_paths.contains(&real.canonicalize().unwrap())));
        let watch_set = watches.into_iter().collect::<BTreeSet<_>>();
        assert!(event_allowed_by_watches(&watch_set, &link));
        assert!(event_allowed_by_watches(&watch_set, &real));
        assert!(!event_allowed_by_watches(&watch_set, &link_sibling));
        assert!(!event_allowed_by_watches(&watch_set, &target_sibling));
        std::fs::remove_dir_all(root).unwrap();
    }

    #[cfg(unix)]
    #[test]
    fn external_symlink_target_parent_watch_survives_missing_target() {
        use std::os::unix::fs::symlink;
        let root = std::env::temp_dir().join(format!(
            "mech-watch-external-missing-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let link_dir = root.join("links");
        let shared_dir = root.join("shared");
        std::fs::create_dir_all(&link_dir).unwrap();
        std::fs::create_dir_all(&shared_dir).unwrap();
        let real = shared_dir.join("real.mec");
        let link = link_dir.join("link.mec");
        let sibling = shared_dir.join("sibling.mec");
        std::fs::write(&real, "x := 1").unwrap();
        std::fs::write(&sibling, "y := 2").unwrap();
        symlink(&real, &link).unwrap();

        let current = local_workspace_target_watches(&root, "links/link.mec")
            .into_iter()
            .collect::<BTreeSet<_>>();
        let canonical_real = real.canonicalize().unwrap();
        let shared_parent = shared_dir.canonicalize().unwrap();
        assert!(
            current
                .iter()
                .any(|watch| watch.watch_path == shared_parent)
        );

        std::fs::remove_file(&real).unwrap();
        let desired = local_workspace_target_watches(&root, "links/link.mec")
            .into_iter()
            .collect::<BTreeSet<_>>();
        let reconciled = preserve_existing_watch_authorizations(&current, desired);

        assert!(
            reconciled
                .iter()
                .any(|watch| watch.watch_path == shared_parent
                    && watch.authorized_path == canonical_real)
        );
        assert!(
            reconciled
                .iter()
                .any(|watch| watch.filter_paths.contains(&link))
        );
        assert!(!event_allowed_by_watches(&reconciled, &sibling));

        std::fs::write(&real, "x := 2").unwrap();
        let event = Event {
            kind: EventKind::Create(notify::event::CreateKind::File),
            paths: vec![real.clone()],
            attrs: Default::default(),
        };
        let converted = watch_events_from_notify_event(event);
        assert_eq!(converted.len(), 1);
        assert!(event_allowed_by_watches(&reconciled, &real));
        std::fs::remove_dir_all(root).unwrap();
    }

    #[cfg(unix)]
    #[test]
    fn external_symlink_target_parent_watch_not_preserved_after_retarget() {
        use std::os::unix::fs::symlink;
        let root = std::env::temp_dir().join(format!(
            "mech-watch-external-retarget-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let link_dir = root.join("links");
        let shared_dir = root.join("shared");
        std::fs::create_dir_all(&link_dir).unwrap();
        std::fs::create_dir_all(&shared_dir).unwrap();
        let real = shared_dir.join("real.mec");
        let other = shared_dir.join("other.mec");
        let link = link_dir.join("link.mec");
        std::fs::write(&real, "x := 1").unwrap();
        std::fs::write(&other, "x := 2").unwrap();
        symlink(&real, &link).unwrap();

        let current = local_workspace_target_watches(&root, "links/link.mec")
            .into_iter()
            .collect::<BTreeSet<_>>();
        let canonical_real = real.canonicalize().unwrap();
        let canonical_other = other.canonicalize().unwrap();

        std::fs::remove_file(&link).unwrap();
        symlink(&other, &link).unwrap();
        let desired = local_workspace_target_watches(&root, "links/link.mec")
            .into_iter()
            .collect::<BTreeSet<_>>();
        let reconciled = preserve_existing_watch_authorizations(&current, desired);

        assert!(
            reconciled
                .iter()
                .any(|watch| watch.authorized_path == canonical_other)
        );
        assert!(
            !reconciled
                .iter()
                .any(|watch| watch.authorized_path == canonical_real)
        );
        assert!(
            !reconciled
                .iter()
                .any(|watch| watch.filter_paths.contains(&canonical_real))
        );
        std::fs::remove_dir_all(root).unwrap();
    }

    #[cfg(unix)]
    #[test]
    fn symlink_target_same_parent_uses_single_watch_with_both_filters() {
        use std::os::unix::fs::symlink;
        let root = std::env::temp_dir().join(format!(
            "mech-watch-symlink-same-parent-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        std::fs::create_dir_all(&root).unwrap();
        let real = root.join("real.mec");
        let link = root.join("link.mec");
        std::fs::write(&real, "x := 1").unwrap();
        symlink(&real, &link).unwrap();

        let watches = local_workspace_target_watches(&root, "link.mec");
        assert_eq!(watches.len(), 1);
        assert!(watches[0].filter_paths.contains(&link));
        assert!(
            watches[0]
                .filter_paths
                .contains(&real.canonicalize().unwrap())
        );
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn shared_parent_watch_keys_collapse_multiple_file_filters() {
        let root = std::env::temp_dir().join(format!(
            "mech-watch-shared-parent-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        std::fs::create_dir_all(&root).unwrap();
        std::fs::write(root.join("a.mec"), "a := 1").unwrap();
        std::fs::write(root.join("b.mec"), "b := 2").unwrap();
        let mut watches = BTreeSet::new();
        watches.extend(local_workspace_target_watches(&root, "a.mec"));
        watches.extend(local_workspace_target_watches(&root, "b.mec"));
        let keys = watches.iter().map(watch_key).collect::<BTreeSet<_>>();
        assert_eq!(watches.len(), 2);
        assert_eq!(keys.len(), 1);
        assert_eq!(
            keys.iter().next().unwrap().path,
            root.canonicalize().unwrap()
        );
        std::fs::remove_dir_all(root).unwrap();
    }

    #[cfg(unix)]
    #[test]
    fn missing_watch_path_normalizes_through_existing_symlink_ancestor() {
        use std::os::unix::fs::symlink;

        let root = std::env::temp_dir().join(format!(
            "mech-watch-alias-normalize-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let physical = root.join("physical");
        let docs = physical.join("docs");
        let alias = root.join("alias");
        std::fs::create_dir_all(&docs).unwrap();
        symlink(&physical, &alias).unwrap();

        let missing = alias.join("docs/main.mec");
        let expected = docs.canonicalize().unwrap().join("main.mec");
        assert!(!missing.exists());
        assert_eq!(normalize_workspace_watch_path(&missing), expected);

        std::fs::remove_dir_all(root).unwrap();
    }

    #[cfg(unix)]
    #[test]
    fn nonrecursive_watch_accepts_missing_child_through_aliased_parent() {
        use std::os::unix::fs::symlink;

        let root = std::env::temp_dir().join(format!(
            "mech-watch-alias-nonrecursive-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let physical = root.join("physical");
        let docs = physical.join("docs");
        let nested = docs.join("nested");
        let alias = root.join("alias");
        std::fs::create_dir_all(&nested).unwrap();
        symlink(&physical, &alias).unwrap();

        let canonical_docs = docs.canonicalize().unwrap();
        let direct_child = alias.join("docs/main.mec");
        let grandchild = alias.join("docs/nested/main.mec");
        let watch = RuntimeWorkspaceWatchedPath {
            watch_path: canonical_docs.clone(),
            authorized_path: canonical_docs,
            filter_paths: Vec::new(),
            recursive: false,
        };
        let watches = [watch].into_iter().collect::<BTreeSet<_>>();

        assert!(!direct_child.exists());
        assert!(!grandchild.exists());
        assert!(event_allowed_by_watches(&watches, &alias.join("docs")));
        assert!(event_allowed_by_watches(&watches, &direct_child));
        assert!(!event_allowed_by_watches(&watches, &grandchild));

        std::fs::remove_dir_all(root).unwrap();
    }

    #[cfg(unix)]
    #[test]
    fn recursive_watch_accepts_missing_descendant_through_aliased_parent() {
        use std::os::unix::fs::symlink;

        let root = std::env::temp_dir().join(format!(
            "mech-watch-alias-recursive-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let physical = root.join("physical");
        let docs = physical.join("docs");
        let nested = docs.join("nested");
        let alias = root.join("alias");
        std::fs::create_dir_all(&nested).unwrap();
        symlink(&physical, &alias).unwrap();

        let canonical_docs = docs.canonicalize().unwrap();
        let missing = alias.join("docs/nested/main.mec");
        let watch = RuntimeWorkspaceWatchedPath {
            watch_path: canonical_docs.clone(),
            authorized_path: canonical_docs,
            filter_paths: Vec::new(),
            recursive: true,
        };
        let watches = [watch].into_iter().collect::<BTreeSet<_>>();

        assert!(!missing.exists());
        assert!(event_allowed_by_watches(&watches, &missing));

        std::fs::remove_dir_all(root).unwrap();
    }

    #[cfg(unix)]
    #[test]
    fn aliased_directory_paths_share_one_watch_key() {
        use std::os::unix::fs::symlink;

        let root = std::env::temp_dir().join(format!(
            "mech-watch-alias-key-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let physical = root.join("physical");
        let docs = physical.join("docs");
        let alias = root.join("alias");
        std::fs::create_dir_all(&docs).unwrap();
        symlink(&physical, &alias).unwrap();

        let physical_watch = RuntimeWorkspaceWatchedPath {
            watch_path: docs.clone(),
            authorized_path: docs.clone(),
            filter_paths: Vec::new(),
            recursive: false,
        };
        let alias_docs = alias.join("docs");
        let alias_watch = RuntimeWorkspaceWatchedPath {
            watch_path: alias_docs.clone(),
            authorized_path: alias_docs,
            filter_paths: Vec::new(),
            recursive: false,
        };
        let recursive_alias_watch = RuntimeWorkspaceWatchedPath {
            recursive: true,
            ..alias_watch.clone()
        };

        assert_eq!(watch_key(&physical_watch), watch_key(&alias_watch));
        assert_ne!(
            watch_key(&physical_watch),
            watch_key(&recursive_alias_watch)
        );

        std::fs::remove_dir_all(root).unwrap();
    }

    #[cfg(target_os = "macos")]
    #[test]
    fn macos_temp_directory_alias_handles_missing_watch_paths() {
        let root = std::env::temp_dir().join(format!(
            "mech-watch-macos-temp-alias-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let docs = root.join("docs");
        std::fs::create_dir_all(&docs).unwrap();

        let missing_child = docs.join("main.mec");
        let canonical_docs = docs.canonicalize().unwrap();
        let watch = RuntimeWorkspaceWatchedPath {
            watch_path: canonical_docs.clone(),
            authorized_path: canonical_docs.clone(),
            filter_paths: Vec::new(),
            recursive: false,
        };
        let watches = [watch].into_iter().collect::<BTreeSet<_>>();

        assert_eq!(
            normalize_workspace_watch_path(&missing_child),
            canonical_docs.join("main.mec"),
        );
        assert!(event_allowed_by_watches(&watches, &missing_child));

        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn nonrecursive_directory_watch_allows_directory_and_direct_children_only() {
        let root = std::env::temp_dir().join(format!(
            "mech-watch-directory-event-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let docs = root.join("docs");
        let nested = docs.join("nested");
        std::fs::create_dir_all(&nested).unwrap();
        let watch = RuntimeWorkspaceWatchedPath {
            watch_path: docs.clone(),
            authorized_path: docs.clone(),
            filter_paths: Vec::new(),
            recursive: false,
        };
        let watches = [watch].into_iter().collect::<BTreeSet<_>>();
        assert!(event_allowed_by_watches(&watches, &docs));
        assert!(event_allowed_by_watches(&watches, &docs.join("main.mec")));
        assert!(!event_allowed_by_watches(
            &watches,
            &nested.join("main.mec")
        ));
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn filtered_file_watch_still_rejects_parent_directory_event() {
        let root = std::env::temp_dir().join(format!(
            "mech-watch-filter-parent-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        std::fs::create_dir_all(&root).unwrap();
        let target = root.join("main.mec");
        std::fs::write(&target, "x := 1").unwrap();
        let watch = single_target_watch(&root, "main.mec");
        let watches = [watch].into_iter().collect::<BTreeSet<_>>();
        assert!(!event_allowed_by_watches(&watches, &root));
        assert!(event_allowed_by_watches(&watches, &target));
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn recursive_directory_watch_still_allows_descendants() {
        let root = std::env::temp_dir().join(format!(
            "mech-watch-recursive-event-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let docs = root.join("docs");
        let nested_file = docs.join("nested/main.mec");
        std::fs::create_dir_all(nested_file.parent().unwrap()).unwrap();
        let watch = RuntimeWorkspaceWatchedPath {
            watch_path: docs.clone(),
            authorized_path: docs.clone(),
            filter_paths: Vec::new(),
            recursive: true,
        };
        let watches = [watch].into_iter().collect::<BTreeSet<_>>();
        assert!(event_allowed_by_watches(&watches, &docs));
        assert!(event_allowed_by_watches(&watches, &nested_file));
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn regular_missing_file_watch_without_existing_authorization_uses_missing_path() {
        let root = std::env::temp_dir().join(format!(
            "mech-watch-regular-missing-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        std::fs::create_dir_all(&root).unwrap();
        let missing = root.join("missing.mec");
        let watch = single_target_watch(&root, "missing.mec");
        assert_eq!(watch.authorized_path, missing);
        assert_eq!(
            watch.filter_paths,
            vec![normalize_workspace_watch_path(&watch.authorized_path)],
        );
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn watch_events_include_non_mec_paths() {
        let event = Event {
            kind: EventKind::Modify(notify::event::ModifyKind::Any),
            paths: vec![
                PathBuf::from("src/main.mec"),
                PathBuf::from("src/readme.txt"),
            ],
            attrs: Default::default(),
        };

        let events = watch_events_from_notify_event(event);

        assert_eq!(events.len(), 2);
        assert!(events.iter().any(|event| {
            event.path == PathBuf::from("src/main.mec")
                && event.kind == RuntimeWorkspaceWatchEventKind::Modified
        }));
        assert!(events.iter().any(|event| {
            event.path == PathBuf::from("src/readme.txt")
                && event.kind == RuntimeWorkspaceWatchEventKind::Modified
        }));
    }

    #[test]
    fn watch_events_from_notify_event_ignores_other_directory_events() {
        let root = std::env::temp_dir().join(format!(
            "mech-watch-other-dir-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let app = root.join("app");
        std::fs::create_dir_all(&app).unwrap();
        let event = Event {
            kind: EventKind::Access(notify::event::AccessKind::Any),
            paths: vec![app],
            attrs: Default::default(),
        };

        let events = watch_events_from_notify_event(event);

        assert!(events.is_empty());
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn watch_events_from_notify_event_keeps_create_directory_events() {
        let root = std::env::temp_dir().join(format!(
            "mech-watch-create-dir-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let app = root.join("app");
        std::fs::create_dir_all(&app).unwrap();
        let event = Event {
            kind: EventKind::Create(notify::event::CreateKind::Folder),
            paths: vec![app.clone()],
            attrs: Default::default(),
        };

        let events = watch_events_from_notify_event(event);

        assert_eq!(
            events,
            vec![RuntimeWorkspaceWatchEvent {
                path: app,
                kind: RuntimeWorkspaceWatchEventKind::Created
            }]
        );
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn watch_events_from_notify_event_keeps_modify_file_events() {
        let root = std::env::temp_dir().join(format!(
            "mech-watch-modify-file-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        std::fs::create_dir_all(&root).unwrap();
        let file = root.join("main.mec");
        std::fs::write(&file, "x := 1").unwrap();
        let event = Event {
            kind: EventKind::Modify(notify::event::ModifyKind::Data(
                notify::event::DataChange::Any,
            )),
            paths: vec![file.clone()],
            attrs: Default::default(),
        };

        let events = watch_events_from_notify_event(event);

        assert_eq!(
            events,
            vec![RuntimeWorkspaceWatchEvent {
                path: file,
                kind: RuntimeWorkspaceWatchEventKind::Modified
            }]
        );
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn watch_events_from_notify_event_keeps_existing_directory_paths() {
        let root = std::env::temp_dir().join(format!(
            "mech-watch-directory-convert-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let app = root.join("app");
        let sibling = root.join("sibling");
        std::fs::create_dir_all(&app).unwrap();
        std::fs::create_dir_all(&sibling).unwrap();
        let event = Event {
            kind: EventKind::Create(notify::event::CreateKind::Folder),
            paths: vec![app.clone()],
            attrs: Default::default(),
        };
        let events = watch_events_from_notify_event(event);
        assert_eq!(events.len(), 1);
        assert_eq!(events[0].path, app);

        let watch = RuntimeWorkspaceWatchedPath {
            watch_path: root.canonicalize().unwrap(),
            authorized_path: app.clone(),
            filter_paths: vec![app.clone()],
            recursive: false,
        };
        let watches = [watch].into_iter().collect::<BTreeSet<_>>();
        assert!(event_allowed_by_watches(&watches, &app));
        assert!(!event_allowed_by_watches(&watches, &sibling));
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn watch_events_from_notify_event_maps_multiple_mec_paths() {
        let event = Event {
            kind: EventKind::Create(notify::event::CreateKind::File),
            paths: vec![PathBuf::from("src/a.mec"), PathBuf::from("src/b.mec")],
            attrs: Default::default(),
        };

        let events = watch_events_from_notify_event(event);

        assert_eq!(events.len(), 2);
        assert!(events.iter().any(|event| {
            event.path == PathBuf::from("src/a.mec")
                && event.kind == RuntimeWorkspaceWatchEventKind::Created
        }));
        assert!(events.iter().any(|event| {
            event.path == PathBuf::from("src/b.mec")
                && event.kind == RuntimeWorkspaceWatchEventKind::Created
        }));
    }

    #[test]
    fn watch_event_kind_maps_create_modify_remove() {
        assert_eq!(
            watch_event_kind(&EventKind::Create(notify::event::CreateKind::Any)),
            RuntimeWorkspaceWatchEventKind::Created,
        );
        assert_eq!(
            watch_event_kind(&EventKind::Modify(notify::event::ModifyKind::Any)),
            RuntimeWorkspaceWatchEventKind::Modified,
        );
        assert_eq!(
            watch_event_kind(&EventKind::Remove(notify::event::RemoveKind::Any)),
            RuntimeWorkspaceWatchEventKind::Removed,
        );
    }
}
