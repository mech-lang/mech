#![cfg(feature = "resident_ekf_benchmarks")]

use mech_core::{CellSlotId, ReactiveInstanceId, ResidentValueRef};
use mech_engine::__resident::{
    ActivationFacts, CapturedSignalInput, FrozenEkfCompilationServices,
    PreparedResidentTurn as PreparedArtifactTurn, ReactiveInstance,
    ResidentExecutionError as ArtifactExecutionError, ResidentValueBorrow, activate,
    compile_frozen_ekf_source, frozen_ekf_compiler_catalog,
};
use mech_engine::__resident_ekf::{
    PreparedResidentTurn, ResidentEkfBatch, ResidentExecutionError as ResidentEkfExecutionError,
    ResidentFullWrite, ResidentTurnSummary,
};
use mech_runtime::__resident_recording::{LedgerSequence, ResidentTurnRecorder, TurnFailurePhase};

const INPUT: [f64; 4] = [1.0, 0.1, 24.0, -0.6];
const ARTIFACT_SOURCE: &str =
    include_str!("../../../tests/architecture/resident-activation/ekf-source-v1.mec");

fn artifact_instance() -> ReactiveInstance {
    let mut services = FrozenEkfCompilationServices::default();
    let compilation = compile_frozen_ekf_source(ARTIFACT_SOURCE, &mut services).unwrap();
    let catalog = frozen_ekf_compiler_catalog().unwrap();
    activate(
        ReactiveInstanceId::new(0, 0),
        &compilation.source_artifact,
        &catalog,
        &ActivationFacts::default(),
    )
    .unwrap()
}

fn artifact_state(instance: &ReactiveInstance) -> [u64; 12] {
    let mut result = [0; 12];
    for slot in instance
        .plan
        .slots
        .iter()
        .filter(|slot| slot.role == mech_engine::SlotRole::State)
    {
        let ResidentValueBorrow::F64 { values, .. } =
            instance.state_borrow(slot.artifact_id).unwrap()
        else {
            panic!("EKF resident state is f64")
        };
        let target = match values.len() {
            3 => &mut result[..3],
            9 => &mut result[3..],
            _ => panic!("unexpected EKF resident state shape"),
        };
        for (target, value) in target.iter_mut().zip(values) {
            *target = value.to_bits();
        }
    }
    result
}

fn prepare_artifact<'instance>(
    instance: &'instance mut ReactiveInstance,
    input: &[f64; 4],
) -> Result<PreparedArtifactTurn<'instance>, ArtifactExecutionError> {
    let captured = CapturedSignalInput {
        slot: instance.plan.inputs[0].slot,
        value: ResidentValueRef::F64(input),
    };
    instance.prepare_turn(&[captured])
}

fn commit_prepared(
    resident: &mut ResidentEkfBatch,
    recorder: &mut ResidentTurnRecorder,
    turn: usize,
    input: [f64; 4],
) -> (LedgerSequence, ResidentTurnSummary) {
    let permit = recorder.take_admission_permit(turn).unwrap();
    let prepared = resident.prepare_scheduled_turn(input).unwrap();
    let summary = prepared.summary();
    let sequence = recorder.prepare_commit(permit, prepared).unwrap().commit();
    (sequence, summary)
}

fn finish_prepared(
    prepared: PreparedResidentTurn<'_>,
    recorder: &mut ResidentTurnRecorder,
    permit: mech_runtime::__resident_recording::LedgerPermit,
) -> LedgerSequence {
    recorder.prepare_commit(permit, prepared).unwrap().commit()
}

#[test]
fn accepted_commit_is_invisible_until_one_publication_then_retains_owned_receipt() {
    let mut resident = ResidentEkfBatch::new(1);
    let mut recorder = ResidentTurnRecorder::new(2, 0).unwrap();
    let initial = resident.state(0);
    let permit = recorder.take_admission_permit(0).unwrap();
    let prepared = resident.prepare_scheduled_turn(INPUT).unwrap();
    let summary = prepared.summary();

    assert_eq!(prepared.published_epoch(), 0);
    assert_eq!(prepared.published_state(0), initial);
    assert_eq!(summary.before_epoch, 0);
    assert_eq!(summary.after_epoch, 1);
    assert_eq!(summary.touched_slots, 2);
    assert_eq!(summary.changed_slots, 2);
    assert_eq!(summary.dirty_nodes, 15);

    let sequence = finish_prepared(prepared, &mut recorder, permit);
    assert_eq!(sequence.get(), 1);
    assert_eq!(resident.published_epoch(), 1);
    assert_ne!(resident.state(0), initial);
    assert_eq!(recorder.recorded_ledger_len(), 1);

    let first_body = {
        let record = recorder.inspect_last().unwrap();
        assert!(record.accepted);
        assert_eq!(record.turn_id, 1);
        assert_eq!(record.transaction_id, 1);
        assert_eq!(record.input_first, 1);
        assert_eq!(record.input_last, 1);
        assert_eq!(record.failure_kind, None);
        assert_eq!(record.failure_phase, None);
        assert_eq!(record.body.before_epoch(), 0);
        assert_eq!(record.body.after_epoch(), 1);
        assert_eq!(record.body.state_hash(), summary.state_hash);
        assert_eq!(record.body.touched_slots(), 2);
        assert_eq!(record.body.changed_slots(), 2);
        assert_eq!(record.body.dirty_nodes(), 15);
        assert!(record.body.is_accepted());
        assert_eq!(record.body.version(), 0);
        record.body
    };

    commit_prepared(&mut resident, &mut recorder, 1, INPUT);
    assert_eq!(first_body.state_hash(), summary.state_hash);
    let record = recorder.inspect_last().unwrap();
    assert_eq!(record.sequence, 2);
    assert_eq!(record.turn_id, 2);
    assert_eq!(record.transaction_id, 2);
    assert_eq!(record.input_first, 2);
}

#[test]
fn rejected_candidate_records_failure_without_publication_and_epoch_is_not_reused() {
    let mut resident = ResidentEkfBatch::new(1);
    let mut recorder = ResidentTurnRecorder::new(2, 0).unwrap();
    let initial = resident.state(0);
    let permit = recorder.take_admission_permit(0).unwrap();
    let mut invalid = INPUT;
    invalid[2] = f64::NAN;
    let failure = match resident.prepare_scheduled_turn(invalid) {
        Ok(prepared) => {
            prepared.abort();
            panic!("invalid resident input unexpectedly prepared")
        }
        Err(failure) => failure,
    };
    let rejected = recorder
        .prepare_rejected(permit, resident.published_epoch(), failure)
        .unwrap();
    assert_eq!(rejected.append().get(), 1);

    assert_eq!(resident.published_epoch(), 0);
    assert_eq!(resident.state(0), initial);
    let record = recorder.inspect_last().unwrap();
    assert!(!record.accepted);
    assert!(record.failure_kind.is_some());
    assert!(!record.body.is_accepted());
    assert_eq!(record.body.after_epoch(), 0);

    let (_, summary) = commit_prepared(&mut resident, &mut recorder, 1, INPUT);
    assert_eq!(summary.after_epoch, 2);
    assert_eq!(resident.published_epoch(), 2);
}

#[test]
fn artifact_commit_uses_the_reserved_prepare_publish_append_boundary() {
    let mut instance = artifact_instance();
    assert_eq!(
        instance
            .plan
            .slots
            .iter()
            .filter(|slot| slot.role == mech_engine::SlotRole::State)
            .count(),
        2,
    );
    assert_eq!(instance.plan.outputs.len(), 1);
    let estimate = &instance.plan.slots[instance.plan.outputs[0].slot.get() as usize];
    assert_eq!(estimate.role, mech_engine::SlotRole::Output);
    assert_eq!(estimate.region.len, 3);
    let mut recorder = ResidentTurnRecorder::new(1, 0).unwrap();
    let initial = artifact_state(&instance);
    let permit = recorder.take_admission_permit(0).unwrap();
    let prepared = prepare_artifact(&mut instance, &INPUT).unwrap();
    let summary = prepared.summary();
    // Publication includes state, covariance, and the dedicated estimate output.
    assert_eq!(summary.touched_slots, 3);
    let commit = recorder.prepare_artifact_commit(permit, prepared).unwrap();
    assert_eq!(commit.commit().get(), 1);
    assert_eq!(instance.published_epoch().get(), 1);
    let published = artifact_state(&instance);
    assert_ne!(published, initial);
    let ResidentValueBorrow::F64 { values, .. } = instance.output_borrow(0).unwrap() else {
        panic!("EKF estimate output is f64")
    };
    assert_eq!(
        values
            .iter()
            .map(|value| value.to_bits())
            .collect::<Vec<_>>(),
        published[..3],
    );
    assert_eq!(recorder.recorded_ledger_len(), 1);
    let record = recorder.inspect_last().unwrap();
    assert!(record.accepted);
    assert_eq!(record.body.after_epoch(), 1);
    assert_eq!(record.body.state_hash(), summary.state_hash);
    assert_eq!(record.body.touched_slots(), summary.touched_slots);
}

#[test]
fn artifact_admission_capacity_is_taken_before_candidate_execution() {
    let instance = artifact_instance();
    let mut recorder = ResidentTurnRecorder::new(1, 0).unwrap();
    drop(recorder.take_admission_permit(0).unwrap());
    assert!(recorder.take_admission_permit(0).is_err());
    assert_eq!(instance.published_epoch().get(), 0);
}

#[test]
fn rejected_artifact_execution_appends_without_publication() {
    let mut instance = artifact_instance();
    let mut recorder = ResidentTurnRecorder::new(1, 0).unwrap();
    let initial = artifact_state(&instance);
    let permit = recorder.take_admission_permit(0).unwrap();
    let mut invalid = INPUT;
    invalid[0] = f64::NAN;
    let failure = match prepare_artifact(&mut instance, &invalid) {
        Ok(prepared) => {
            prepared.abort();
            panic!("invalid artifact candidate unexpectedly prepared")
        }
        Err(failure) => failure,
    };
    recorder
        .prepare_artifact_rejected(permit, instance.published_epoch().get(), failure)
        .unwrap()
        .append();
    assert_eq!(instance.published_epoch().get(), 0);
    assert_eq!(artifact_state(&instance), initial);
    assert_eq!(recorder.recorded_ledger_len(), 1);
    let record = recorder.inspect_last().unwrap();
    assert!(!record.accepted);
    assert_eq!(record.failure_phase, Some(TurnFailurePhase::Integrity));
}

#[test]
fn rejected_output_materialization_has_a_stable_execution_failure_record() {
    let mut recorder = ResidentTurnRecorder::new(1, 0).unwrap();
    let permit = recorder.take_admission_permit(0).unwrap();
    recorder
        .prepare_artifact_rejected(
            permit,
            0,
            ArtifactExecutionError::InvalidOutputMaterialization {
                slot: CellSlotId(7),
            },
        )
        .unwrap()
        .append();

    let record = recorder.inspect_last().unwrap();
    assert_eq!(record.failure_phase, Some(TurnFailurePhase::Execution));
    assert_eq!(record.failure_kind, Some("ResidentOutputMaterialization"));
}

#[test]
fn rejected_projection_state_has_a_stable_execution_failure_record() {
    let mut recorder = ResidentTurnRecorder::new(1, 0).unwrap();
    let permit = recorder.take_admission_permit(0).unwrap();
    recorder
        .prepare_artifact_rejected(
            permit,
            0,
            ArtifactExecutionError::InvalidProjectionState {
                slot: CellSlotId(7),
            },
        )
        .unwrap()
        .append();
    let record = recorder.inspect_last().unwrap();
    assert_eq!(record.failure_phase, Some(TurnFailurePhase::Execution));
    assert_eq!(record.failure_kind, Some("ResidentProjectionState"));
}

#[test]
fn admission_exhaustion_precedes_candidate_execution() {
    let resident = ResidentEkfBatch::new(1);
    let mut recorder = ResidentTurnRecorder::new(1, 0).unwrap();
    drop(recorder.take_admission_permit(0).unwrap());
    assert!(recorder.take_admission_permit(0).is_err());
    assert_eq!(resident.published_epoch(), 0);
    assert_eq!(resident.state(0), ResidentEkfBatch::new(1).state(0));
}

#[test]
fn retained_history_does_not_add_turn_work_or_record_iteration() {
    for history in [0, 1_000, 100_000] {
        let mut resident = ResidentEkfBatch::new(1);
        let mut recorder = ResidentTurnRecorder::new(1, history).unwrap();
        assert_eq!(recorder.records_inspected(), 0);
        let (sequence, summary) = commit_prepared(&mut resident, &mut recorder, 0, INPUT);
        assert_eq!(summary.dirty_nodes, 15);
        assert_eq!(recorder.recorded_ledger_len(), history + 1);
        assert_eq!(recorder.records_inspected(), 0);
        assert_eq!(sequence.get() as usize, history + 1);
        assert_eq!(
            recorder.inspect_last().unwrap().sequence as usize,
            history + 1
        );
        assert_eq!(recorder.records_inspected(), 1);
    }
}

#[test]
fn high_epoch_executes_the_same_trajectory_and_work() {
    let mut low = ResidentEkfBatch::new(1);
    let mut high = ResidentEkfBatch::new(1);
    high.set_next_epoch_for_benchmark(1_000_000_001);
    let low_prepared = low.prepare_scheduled_turn(INPUT).unwrap();
    let high_prepared = high.prepare_scheduled_turn(INPUT).unwrap();
    let low_summary = low_prepared.summary();
    let high_summary = high_prepared.summary();
    assert_eq!(low_summary.state_hash, high_summary.state_hash);
    assert_eq!(low_summary.touched_slots, high_summary.touched_slots);
    assert_eq!(low_summary.changed_slots, high_summary.changed_slots);
    assert_eq!(low_summary.dirty_nodes, high_summary.dirty_nodes);
    low_prepared.publish();
    high_prepared.publish();
    assert_eq!(low.state(0), high.state(0));
    assert_eq!(low.published_epoch(), 1);
    assert_eq!(high.published_epoch(), 1_000_000_001);
}

#[test]
fn rejection_failure_kinds_and_phases_are_stable_and_bounded() {
    let failures = [
        (
            ResidentEkfExecutionError::EpochExhausted,
            TurnFailurePhase::Execution,
            "ResidentEpochExhausted",
        ),
        (
            ResidentEkfExecutionError::IncompleteCandidate,
            TurnFailurePhase::Integrity,
            "ResidentIncompleteCandidate",
        ),
        (
            ResidentEkfExecutionError::LandmarkDistance,
            TurnFailurePhase::Integrity,
            "ResidentLandmarkDistance",
        ),
        (
            ResidentEkfExecutionError::InnovationDeterminant,
            TurnFailurePhase::Integrity,
            "ResidentInnovationDeterminant",
        ),
        (
            ResidentEkfExecutionError::NonFiniteState,
            TurnFailurePhase::Integrity,
            "ResidentNonFiniteState",
        ),
        (
            ResidentEkfExecutionError::CovarianceDiagonal,
            TurnFailurePhase::Integrity,
            "ResidentCovarianceDiagonal",
        ),
        (
            ResidentEkfExecutionError::CovarianceSymmetry,
            TurnFailurePhase::Integrity,
            "ResidentCovarianceSymmetry",
        ),
    ];
    let mut recorder = ResidentTurnRecorder::new(failures.len(), 0).unwrap();
    for (turn, (failure, phase, kind)) in failures.into_iter().enumerate() {
        let permit = recorder.take_admission_permit(turn).unwrap();
        recorder
            .prepare_rejected(permit, 0, failure)
            .unwrap()
            .append();
        let record = recorder.inspect_last().unwrap();
        assert_eq!(record.failure_phase, Some(phase));
        assert_eq!(record.failure_kind, Some(kind));
        assert!(!record.body.is_accepted());
    }
    assert_eq!(recorder.recorded_ledger_len(), 7);
}

#[test]
fn complete_full_write_prepares_receipt_before_one_publication() {
    let mut resident = ResidentFullWrite::new();
    let mut recorder = ResidentTurnRecorder::new(1, 0).unwrap();
    let before_epoch = resident.published_epoch();
    let permit = recorder.take_admission_permit(0).unwrap();
    let prepared = resident.prepare_turn(1.0).unwrap();
    let summary = prepared.summary();
    assert_eq!(summary.before_epoch, before_epoch);
    assert_eq!(summary.after_epoch, 1);
    assert_eq!(summary.touched_slots, 1);
    assert_eq!(summary.changed_slots, 1);
    assert_eq!(summary.dirty_nodes, 1);
    recorder
        .prepare_full_write_commit(permit, prepared)
        .unwrap()
        .commit();
    assert_eq!(resident.published_epoch(), 1);
    assert_eq!(recorder.recorded_ledger_len(), 1);
    let record = recorder.inspect_last().unwrap();
    assert!(record.accepted);
    assert_eq!(record.body.state_hash(), summary.state_hash);
}
