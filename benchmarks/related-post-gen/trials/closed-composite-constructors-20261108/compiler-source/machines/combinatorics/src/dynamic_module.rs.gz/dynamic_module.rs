#![cfg(feature = "dynamic-module")]

use mech_abi::MechStatusV1;
#[cfg(test)]
use mech_abi::{MechExportV1, MechKernelFnV1, MechKernelKindV1, MechStrV1};

#[cfg(test)]
const MODULE_NAME: &[u8] = b"combinatorics";
#[cfg(test)]
const EXPORT_NAME: &[u8] = b"combinatorics/n-choose-k";

mech_abi::mech_dynamic_module_v1! {
    module: b"combinatorics",
    exports: [
        binary_f64_f64_to_f64 {
            name: b"combinatorics/n-choose-k",
            function: combinatorics_n_choose_k_f64_v1,
        },
    ],
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn combinatorics_n_choose_k_f64_v1(
    n: f64,
    k: f64,
    out: *mut f64,
) -> MechStatusV1 {
    if out.is_null() {
        return MechStatusV1::NULL_POINTER;
    }
    if !crate::kernels::n_choose_k::supports_f64(n, k) {
        return MechStatusV1::UNSUPPORTED;
    }

    unsafe {
        *out = crate::kernels::n_choose_k::scalar(n, k);
    }

    MechStatusV1::OK
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn module_name_null_pointer_returns_null_pointer() {
        let status = unsafe { mech_module_name_v1(core::ptr::null_mut()) };

        assert_eq!(status, MechStatusV1::NULL_POINTER);
    }

    #[test]
    fn module_metadata_reports_module_name() {
        let mut module_name = MechStrV1 {
            ptr: core::ptr::null(),
            len: 0,
        };

        let status = unsafe { mech_module_name_v1(&mut module_name) };
        assert_eq!(status, MechStatusV1::OK);

        let name = unsafe { core::slice::from_raw_parts(module_name.ptr, module_name.len) };
        assert_eq!(name, MODULE_NAME);
    }

    #[test]
    fn module_export_count_is_one() {
        assert_eq!(unsafe { mech_module_export_count_v1() }, 1);
    }

    #[test]
    fn module_get_export_rejects_null_output() {
        let status = unsafe { mech_module_get_export_v1(0, core::ptr::null_mut()) };
        assert_eq!(status, MechStatusV1::NULL_POINTER);
    }

    #[test]
    fn module_get_export_rejects_invalid_index() {
        let mut export = MechExportV1 {
            name: MechStrV1 {
                ptr: core::ptr::null(),
                len: 0,
            },
            kind: MechKernelKindV1::BINARY_F64_F64_TO_F64,
            function: MechKernelFnV1 {
                binary_f64_f64_to_f64: combinatorics_n_choose_k_f64_v1,
            },
        };

        let status = unsafe { mech_module_get_export_v1(1, &mut export) };
        assert_eq!(status, MechStatusV1::INVALID_INDEX);
    }

    #[test]
    fn n_choose_k_rejects_null_output() {
        let status = unsafe { combinatorics_n_choose_k_f64_v1(10.0, 2.0, core::ptr::null_mut()) };
        assert_eq!(status, MechStatusV1::NULL_POINTER);
    }

    #[test]
    fn export_metadata_describes_n_choose_k_kernel() {
        let mut export = MechExportV1 {
            name: MechStrV1 {
                ptr: core::ptr::null(),
                len: 0,
            },
            kind: MechKernelKindV1::BINARY_F64_F64_TO_F64,
            function: MechKernelFnV1 {
                binary_f64_f64_to_f64: combinatorics_n_choose_k_f64_v1,
            },
        };
        let status = unsafe { mech_module_get_export_v1(0, &mut export) };
        let name = unsafe { core::slice::from_raw_parts(export.name.ptr, export.name.len) };

        assert_eq!(status, MechStatusV1::OK);
        assert_eq!(name, EXPORT_NAME);
        assert_eq!(export.kind, MechKernelKindV1::BINARY_F64_F64_TO_F64);
    }

    #[test]
    fn n_choose_k_f64_returns_expected_result() {
        let mut out = 0.0;
        let status = unsafe { combinatorics_n_choose_k_f64_v1(10.0, 2.0, &mut out) };

        assert_eq!(status, MechStatusV1::OK);
        assert_eq!(out, crate::kernels::n_choose_k::scalar(10.0_f64, 2.0_f64));
    }

    #[test]
    fn n_choose_k_returns_zero_when_k_exceeds_n() {
        let mut out = 123.0;
        let status = unsafe { combinatorics_n_choose_k_f64_v1(2.0, 10.0, &mut out) };

        assert_eq!(status, MechStatusV1::OK);
        assert_eq!(out, crate::kernels::n_choose_k::scalar(2.0_f64, 10.0_f64));
    }

    #[test]
    fn n_choose_k_rejects_non_finite_or_unbounded_dynamic_inputs() {
        for (n, k) in [
            (10.0, f64::INFINITY),
            (f64::NAN, 1.0),
            (2_000_002.0, 1_000_001.0),
            (1.0e100, 1.0e50),
        ] {
            let mut out = 123.0;
            let status = unsafe { combinatorics_n_choose_k_f64_v1(n, k, &mut out) };
            assert_eq!(status, MechStatusV1::UNSUPPORTED);
            assert_eq!(out, 123.0);
        }
    }
}
