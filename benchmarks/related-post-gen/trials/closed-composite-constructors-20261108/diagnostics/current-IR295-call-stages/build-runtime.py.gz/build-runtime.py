from pathlib import Path
import copy,hashlib,json,os,shutil,subprocess,time
P=Path(__file__).parent;R=Path('/Users/cim310/mech-lang/mech/benchmarks/related-post-gen');S=Path('/private/tmp/mech-related-native-call-stages-profile-compiler-20261108');O=Path('/private/tmp/mech-related-native-call-stages-profile-opt-20261108-v1');N=Path('/private/tmp/mech-related-native-string-classification-reuse-runners-20261108-v2');F=Path('/private/tmp/mech-related-generation-count-fusion-20261108/runners');RT=P/'runtime-v2';RT.mkdir(exist_ok=True)
def read(p):return json.loads(Path(p).read_text())
def write(p,d):Path(p).write_text(json.dumps(d,indent=2)+'\n')
def run(cmd,path,env=None):
 cmd=list(map(str,cmd));t=time.monotonic();x=subprocess.run(cmd,capture_output=True,text=True,env={**os.environ,**(env or {})});write(path,dict(command=cmd,environment=env or {},exit=x.returncode,seconds=time.monotonic()-t,stdout=x.stdout,stderr=x.stderr,diagnostic_only=True,promotion_timing_eligible=False));print(path.name,x.returncode,flush=True);assert x.returncode==0,x.stderr[-6000:]+x.stdout[-3000:]
build=read(O/'build.json');assert len(build['stages'])==12 and all(x['exit']==0 for x in build['stages']);libs={x['crate']:x['command'][-1]for x in build['stages']};old=read(N/'runtime/runtime-build.json');oldS='/private/tmp/mech-related-native-string-classification-reuse-compiler-20261108';cmd=[a.replace(oldS,str(S))for a in old['command']];cmd[1:1]=['--cfg','mech_native_entry_intervals']
for i,a in enumerate(cmd):
 if a=='--extern':
  name=cmd[i+1].split('=',1)[0]
  if name in libs:cmd[i+1]=name+'='+libs[name]
 if a.startswith('metadata='):cmd[i]='metadata=related_aligned_constructor_runtime_v1'
cmd[-1]=str(RT/'libmech_gpu.rlib')
for parent in sorted({str(Path(x).parent)for x in libs.values()}):cmd[1:1]=['-L','dependency='+parent]
env={k:v.replace(oldS,str(S))for k,v in old['environment'].items()};run(cmd,RT/'runtime-build.json',env)
gpu=next(x for x in build['stages']if x['crate']=='mech_gpu');gpu.update(command=cmd,environment=env,exit=0,library_sha256=hashlib.sha256((RT/'libmech_gpu.rlib').read_bytes()).hexdigest(),runtime_only=True);write(RT/'build.json',build);shutil.copyfile(O/'source-inventory.json',RT/'source-inventory.json')
print('Current runtime-only diagnostic GPU built',flush=True)
