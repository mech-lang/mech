//! Diagnostic-only nested probes. The final diagnostic host supplies the sink;
//! ordinary production builds contain neither the sink nor these calls.
unsafe extern "C" {
    fn mech_related_native_probe_begin_v1(stage: u64) -> u64;
    fn mech_related_native_probe_end_v1(token: u64);
}

pub(super) struct Scope(u64);
impl Scope {
    pub(super) fn new(stage: u64) -> Self {
        // SAFETY: only the retained diagnostic host links this cfg. Its sink
        // records a token without observing or altering any program value.
        Self(unsafe { mech_related_native_probe_begin_v1(stage) })
    }
}
impl Drop for Scope {
    fn drop(&mut self) {
        // SAFETY: this guard owns exactly the synchronous begin token.
        unsafe { mech_related_native_probe_end_v1(self.0) };
    }
}
