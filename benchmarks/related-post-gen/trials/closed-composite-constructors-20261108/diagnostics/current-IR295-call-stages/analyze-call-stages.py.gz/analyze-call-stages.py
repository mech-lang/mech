from pathlib import Path
from collections import defaultdict
import json,statistics as st
P=Path(__file__).parent/'profile';rows=json.load(open(P/'profiles.json'));groups=defaultdict(list)
def delta(e):return dict(ns=e['end_ns']-e['start_ns'],instructions=e['end_counters']['instructions']-e['start_counters']['instructions'],requests=e['end_allocations']['thread_requests']-e['start_allocations']['thread_requests'],bytes=e['end_allocations']['thread_requested_bytes']-e['start_allocations']['thread_requested_bytes'])
for row in rows:
 if row['variant']!='histogram-reuse-detail':continue
 trace=json.load(open(row['trace']));es=[e for e in trace['capture']['events']if e['thread']==trace['main_thread']]
 bysite=defaultdict(list)
 for e in es:
  if e['stage']=='helper_ffi' and e['operation']==0 and e['site']in[38,40,44,61]:bysite[e['site']].append(e)
 for site,helpers in bysite.items():
  stages=defaultdict(lambda:dict(ns=0,instructions=0,requests=0,bytes=0,count=0));full=dict(ns=0,instructions=0,requests=0,bytes=0)
  for e in helpers:
   for k,v in delta(e).items():full[k]+=v
   for c in es:
    if c['stage'].startswith('leaf_')and e['start_ns']<=c['start_ns']<=c['end_ns']<=e['end_ns']:
     for k,v in delta(c).items():stages[c['stage']][k]+=v
     stages[c['stage']]['count']+=1
  def minus(value,*nested):return{k:value[k]-sum(s.get(k,0)for s in nested)for k in full}
  residual=minus(full,stages.get('leaf_binding',{}),stages.get('leaf_invocation',{}));assert all(v>=0 for v in residual.values())
  groups[str(site)].append(dict(pair=row['pair'],calls=len(helpers),full=full,stages=dict(stages),outside_binding_and_invocation=residual))
summ={}
for site,runs in groups.items():
 assert len(runs)==8
 def med(rows):return {k:st.median(x[k]for x in rows)for k in rows[0]}
 names=set(runs[0]['stages']);assert all(set(r['stages'])==names for r in runs)
 summ[site]=dict(captures=8,calls=st.median(r['calls']for r in runs),full=med([r['full']for r in runs]),stages={n:med([r['stages'][n]for r in runs])for n in sorted(names)},outside_binding_and_invocation=med([r['outside_binding_and_invocation']for r in runs]))
out=dict(diagnostic_only=True,promotion_timing_eligible=False,current_production_source='788f2ad00dcb993aa3c9c6aa62e624b0ca7483aa',unchanged_production_Objects=True,raw_runs=groups,summaries=summ,scope='Conditional internal probes only;inclusive nested stages, medians not additive;outside binding/invocation disjoint per capture. Probe/allocator/counter costs remain in diagnostic observations, not measured promotional savings.')
(P/'call-stage-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
for site,d in summ.items():
 print('SITE',site,'calls',d['calls'],'FULL',d['full'])
 for n,v in d['stages'].items():print(' ',n,v)
 print(' OUTSIDE',d['outside_binding_and_invocation'])
