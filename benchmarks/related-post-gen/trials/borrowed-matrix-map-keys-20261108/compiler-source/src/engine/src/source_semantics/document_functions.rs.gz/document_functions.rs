//! Local function calls expand into the same canonical operation graph as their caller.

use super::comprehension::{
    PendingCollectionValue, PendingComprehensionOperation, PendingComprehensionStep,
};
use super::*;
use mech_syntax::document::{
    ApplicationExpressionSyntax, ComprehensionQualifierSyntax, ComprehensionQualifierValueSyntax,
    FunctionCallSyntax, MatchArmSyntax, MatrixComprehensionSyntax, SetComprehensionSyntax,
};

#[path = "recursive_statement_functions.rs"]
mod recursive_statements;

enum DocumentFunctionBody {
    Expression(SyntaxNode),
    Statements(SyntaxNode),
    Patterns(SyntaxNode),
}

enum PatternLiftOutput {
    Set { upper_bound: Option<DimensionExpr> },
    Matrix { source_schema: SchemaDraft },
}

struct PatternLift {
    id: crate::ControlBlockId,
    start: usize,
    source: PendingValue,
    element: SchemaDraft,
    output: PatternLiftOutput,
}

fn calls_function(node: &SyntaxNode, name: &str) -> Result<bool, SourceSemanticError> {
    if let Some(call) = FunctionCallSyntax::cast(node.clone())
        && let Some(function) = call.function()
        && node_text(function.syntax())? == name
    {
        return Ok(true);
    }
    if let Some(application) = ApplicationExpressionSyntax::cast(node.clone()) {
        for stage in application.stages() {
            if let Some(function) = stage.function()
                && node_text(function.syntax())? == name
            {
                return Ok(true);
            }
        }
    }
    for child in node.children() {
        if calls_function(&child, name)? {
            return Ok(true);
        }
    }
    Ok(false)
}

fn contains_invariant(
    node: &SyntaxNode,
    functions: &BTreeMap<String, SyntaxNode>,
    visited: &mut BTreeSet<String>,
    depth: usize,
) -> Result<bool, SourceSemanticError> {
    if node.kind() == SyntaxKind::InvariantDefine {
        return Ok(true);
    }
    let mut callees = Vec::new();
    if let Some(call) = FunctionCallSyntax::cast(node.clone())
        && let Some(function) = call.function()
    {
        callees.push(node_text(function.syntax())?);
    }
    if let Some(application) = ApplicationExpressionSyntax::cast(node.clone()) {
        for stage in application.stages() {
            if let Some(function) = stage.function() {
                callees.push(node_text(function.syntax())?);
            }
        }
    }
    for name in callees {
        if let Some(body) = functions.get(&name)
            && visited.insert(name)
        {
            if depth >= crate::MAX_CONTROL_DEPTH as usize {
                return Err(SourceSemanticError {
                    code: "source-semantics/function-expansion-depth",
                    message: "function check analysis exceeds the lexical depth limit".to_owned(),
                    anchor: SourceSemanticAnchor::for_node(node),
                });
            }
            if contains_invariant(body, functions, visited, depth + 1)? {
                return Ok(true);
            }
        }
    }
    for child in node.children() {
        if contains_invariant(&child, functions, visited, depth)? {
            return Ok(true);
        }
    }
    Ok(false)
}

fn references_variable(node: &SyntaxNode, name: &str) -> Result<bool, SourceSemanticError> {
    references_free_variable(node, name, false)
}

fn references_pattern_variable(
    pattern: &PatternSyntax,
    name: &str,
    shadowed: bool,
) -> Result<bool, SourceSemanticError> {
    let value = pattern
        .value()
        .ok_or_else(|| missing_kind_child(pattern.syntax(), "pattern body"))?;
    let children = match value {
        PatternValueSyntax::Expression(expression) => {
            return if standalone_pattern_variable(&expression).is_some() {
                Ok(false)
            } else {
                references_free_variable(expression.syntax(), name, shadowed)
            };
        }
        PatternValueSyntax::Array(array) => array
            .elements()
            .iter()
            .filter_map(|element| element.pattern())
            .collect::<Vec<_>>(),
        PatternValueSyntax::Tuple(tuple) => tuple.items(),
        PatternValueSyntax::AtomStruct(tuple) => tuple.items(),
        PatternValueSyntax::TupleStruct(tuple) => tuple.items(),
        PatternValueSyntax::Wildcard(_) => Vec::new(),
    };
    for child in children {
        if references_pattern_variable(&child, name, shadowed)? {
            return Ok(true);
        }
    }
    Ok(false)
}

fn references_comprehension_variable(
    value: Option<ExpressionSyntax>,
    qualifiers: Vec<ComprehensionQualifierSyntax>,
    name: &str,
    mut shadowed: bool,
) -> Result<bool, SourceSemanticError> {
    for qualifier in qualifiers {
        match qualifier.value() {
            Some(ComprehensionQualifierValueSyntax::Generator(generator)) => {
                if let Some(source) = generator.source()
                    && references_free_variable(source.syntax(), name, shadowed)?
                {
                    return Ok(true);
                }
                if let Some(pattern) = generator.pattern() {
                    if references_pattern_variable(&pattern, name, shadowed)? {
                        return Ok(true);
                    }
                    let mut bindings = Vec::new();
                    collect_pattern_bindings(&pattern, &mut bindings)?;
                    shadowed |= bindings.iter().any(|binding| binding.name == name);
                }
            }
            Some(ComprehensionQualifierValueSyntax::Definition(definition)) => {
                let variable = definition.variable();
                for child in definition.syntax().children() {
                    if variable.as_ref().is_some_and(|variable| {
                        child.kind() == SyntaxKind::Variable
                            && child.range() == variable.syntax().range()
                    }) {
                        continue;
                    }
                    if references_free_variable(&child, name, shadowed)? {
                        return Ok(true);
                    }
                }
                if let Some(variable) = variable
                    && let Some(VariableStemSyntax::Identifier(identifier)) = variable.stem()
                {
                    shadowed |= node_text(identifier.syntax())? == name;
                }
            }
            Some(ComprehensionQualifierValueSyntax::Filter(filter)) => {
                if references_free_variable(filter.syntax(), name, shadowed)? {
                    return Ok(true);
                }
            }
            None => {}
        }
    }
    match value {
        Some(value) => references_free_variable(value.syntax(), name, shadowed),
        None => Ok(false),
    }
}

fn references_free_variable(
    node: &SyntaxNode,
    name: &str,
    shadowed: bool,
) -> Result<bool, SourceSemanticError> {
    if let Some(arm) = MatchArmSyntax::cast(node.clone()) {
        let mut arm_shadowed = shadowed;
        if let Some(pattern) = arm.pattern() {
            if references_pattern_variable(&pattern, name, shadowed)? {
                return Ok(true);
            }
            let mut bindings = Vec::new();
            collect_pattern_bindings(&pattern, &mut bindings)?;
            arm_shadowed |= bindings.iter().any(|binding| binding.name == name);
        }
        for expression in [arm.guard(), arm.value()].into_iter().flatten() {
            if references_free_variable(expression.syntax(), name, arm_shadowed)? {
                return Ok(true);
            }
        }
        return Ok(false);
    }
    if let Some(comprehension) = SetComprehensionSyntax::cast(node.clone()) {
        return references_comprehension_variable(
            comprehension.value(),
            comprehension.qualifiers(),
            name,
            shadowed,
        );
    }
    if let Some(comprehension) = MatrixComprehensionSyntax::cast(node.clone()) {
        return references_comprehension_variable(
            comprehension.value(),
            comprehension.qualifiers(),
            name,
            shadowed,
        );
    }
    if let Some(variable) = VariableSyntax::cast(node.clone())
        && let Some(VariableStemSyntax::Identifier(identifier)) = variable.stem()
    {
        return Ok(!shadowed && node_text(identifier.syntax())? == name);
    }
    for child in node.children() {
        if references_free_variable(&child, name, shadowed)? {
            return Ok(true);
        }
    }
    Ok(false)
}

fn lift_element_conforms(element: &SchemaBody, parameter: &SchemaDraft) -> bool {
    if element == &parameter.body {
        return true;
    }
    if matches!(
        parameter.body,
        SchemaBody::Matrix { .. } | SchemaBody::Set { .. } | SchemaBody::Dynamic
    ) {
        return false;
    }
    if schema_annotation_accepts(element, &parameter.body) {
        return true;
    }
    let Ok(source) = ResolvedType::from_schema_body(element, &[]) else {
        return false;
    };
    let Ok(target) = ResolvedType::from_schema_body(&parameter.body, &[]) else {
        return false;
    };
    plan_explicit_cast(&source, &target).is_ok()
}

fn function_parameter(
    builder: &SemanticBuilder,
    node: &SyntaxNode,
) -> Result<(String, SchemaDraft), SourceSemanticError> {
    let name = node
        .children()
        .find(|child| child.kind() == SyntaxKind::Identifier)
        .ok_or_else(|| {
            internal(
                SourceSemanticAnchor::for_node(node),
                "function parameter has no name".to_owned(),
            )
        })?;
    let annotation = node
        .children()
        .find_map(KindAnnotationSyntax::cast)
        .ok_or_else(|| {
            internal(
                SourceSemanticAnchor::for_node(node),
                "function parameter has no kind".to_owned(),
            )
        })?;
    Ok((
        node_text(&name)?,
        builder.annotation_schema_draft(&annotation)?,
    ))
}

impl SemanticBuilder {
    pub(super) fn register_document_functions(
        &mut self,
        units: &[DocumentUnit],
    ) -> Result<(), SourceSemanticError> {
        for unit in units {
            match unit {
                DocumentUnit::Function(function) => {
                    let name = function
                        .children()
                        .find(|child| child.kind() == SyntaxKind::Identifier)
                        .ok_or_else(|| {
                            internal(
                                SourceSemanticAnchor::for_node(function),
                                "function has no name".to_owned(),
                            )
                        })?;
                    let name = node_text(&name)?;
                    if self
                        .local_functions
                        .insert(name.clone(), function.clone())
                        .is_some()
                    {
                        return Err(SourceSemanticError {
                            code: "source-semantics/duplicate-function",
                            message: format!("function {name} is defined more than once"),
                            anchor: SourceSemanticAnchor::for_node(function),
                        });
                    }
                }
                DocumentUnit::Fence(_, _, units) => self.register_document_functions(units)?,
                _ => {}
            }
        }
        Ok(())
    }

    pub(in super::super) fn require_function_local_binding(
        &self,
        name: &str,
        syntax: &SyntaxNode,
    ) -> Result<(), SourceSemanticError> {
        if name.starts_with('@') && self.input_schema_overrides.contains_key(name) {
            return Ok(());
        }
        if let Some(function) = self.active_functions.last() {
            if matches!(
                self.document_bindings.get(name),
                Some(PendingBinding::MutableState(_) | PendingBinding::MutableLocal(_))
            ) {
                return Err(SourceSemanticError {
                    code: "source-semantics/mutable-function-capture",
                    message: format!(
                        "function {function} cannot capture mutable document state {name}"
                    ),
                    anchor: SourceSemanticAnchor::for_node(syntax),
                });
            }
            return Err(SourceSemanticError {
                code: "source-semantics/unbound-function-input",
                message: format!("function {function} references undeclared local {name}"),
                anchor: SourceSemanticAnchor::for_node(syntax),
            });
        }
        Ok(())
    }

    pub(in super::super) fn unary_document_parameter_schema(
        &self,
        name: &str,
        syntax: &SyntaxNode,
    ) -> Result<SchemaDraft, SourceSemanticError> {
        let function = &self.local_functions[name];
        let parameters = function
            .children()
            .filter(|child| child.kind() == SyntaxKind::FunctionArg)
            .map(|node| function_parameter(self, &node))
            .collect::<Result<Vec<_>, _>>()?;
        let [(_, schema)] = parameters.as_slice() else {
            return Err(SourceSemanticError {
                code: "source-semantics/incompatible-call-arity",
                message: format!(
                    "application requires a unary function; {name} has {} parameters",
                    parameters.len()
                ),
                anchor: SourceSemanticAnchor::for_node(syntax),
            });
        };
        Ok(schema.clone())
    }

    pub(in super::super) fn inline_document_function(
        &mut self,
        name: &str,
        inputs: Vec<PendingValue>,
        names: &[String],
        call: &SyntaxNode,
    ) -> Result<PendingValue, SourceSemanticError> {
        let error = |code, message: String| SourceSemanticError {
            code,
            message,
            anchor: SourceSemanticAnchor::for_node(call),
        };
        let function = self.local_functions[name].clone();
        let parameters = function
            .children()
            .filter(|child| child.kind() == SyntaxKind::FunctionArg)
            .map(|node| function_parameter(self, &node))
            .collect::<Result<Vec<_>, _>>()?;
        let mut selected = vec![None; parameters.len()];
        for (input, supplied) in inputs.into_iter().zip(names) {
            let ordinal = if supplied.is_empty() {
                selected.iter().position(Option::is_none)
            } else {
                parameters.iter().position(|(name, _)| name == supplied)
            }
            .ok_or_else(|| {
                error(
                    "source-semantics/invalid-call-argument",
                    format!("function {name} has no available parameter {supplied}"),
                )
            })?;
            if selected[ordinal].replace(input).is_some() {
                return Err(error(
                    "source-semantics/duplicate-call-argument",
                    format!("parameter {} is supplied twice", parameters[ordinal].0),
                ));
            }
        }
        let selected = selected
            .into_iter()
            .collect::<Option<Vec<_>>>()
            .ok_or_else(|| {
                error(
                    "source-semantics/missing-call-argument",
                    format!("function {name} requires all declared arguments"),
                )
            })?;
        let body = function
            .children()
            .find_map(|child| match child.kind() {
                SyntaxKind::FunctionDefineExpression => {
                    Some(DocumentFunctionBody::Expression(child))
                }
                SyntaxKind::FunctionDefineStatements => {
                    Some(DocumentFunctionBody::Statements(child))
                }
                SyntaxKind::FunctionDefineMatchArms => Some(DocumentFunctionBody::Patterns(child)),
                _ => None,
            })
            .ok_or_else(|| {
                error(
                    "source-semantics/unsupported-function-body",
                    "canonical function has no supported body".to_owned(),
                )
            })?;
        if self.active_functions.iter().any(|active| active == name) {
            if self
                .active_functions
                .last()
                .is_none_or(|active| active != name)
            {
                return Err(error(
                    "source-semantics/mutual-recursion",
                    format!("function {name} forms an unsupported mutual recursion cycle"),
                ));
            }
            if matches!(body, DocumentFunctionBody::Expression(_)) {
                return Err(error(
                    "source-semantics/recursive-expression-function",
                    format!(
                        "function {name} requires a pattern or statement body for canonical recursion"
                    ),
                ));
            }
            let (expected, root_depth, comprehension_depth) = self
                .active_recursive_outputs
                .iter()
                .rev()
                .find_map(|(active, output, root_depth, comprehension_depth)| {
                    (active == name).then_some((output.clone(), *root_depth, *comprehension_depth))
                })
                .ok_or_else(|| {
                    error(
                        "source-semantics/recursive-function",
                        format!("function {name} has no active callable frame"),
                    )
                })?;
            if self.comprehension_depth != comprehension_depth {
                return Err(error(
                    "source-semantics/recursive-comprehension",
                    format!("recursive function {name} cannot cross a comprehension invocation"),
                ));
            }
            let ancestor = self
                .match_depth
                .checked_sub(root_depth)
                .and_then(|depth| u8::try_from(depth).ok())
                .ok_or_else(|| {
                    error(
                        "source-semantics/recursive-function",
                        format!("function {name} has no enclosing lexical match"),
                    )
                })?;
            let arguments = parameters
                .iter()
                .zip(selected)
                .map(|((_, schema), input)| {
                    self.conform_schema_draft(
                        input,
                        schema,
                        call,
                        "source-semantics/incompatible-function-argument",
                        "recursive argument does not satisfy its declared kind",
                    )
                })
                .collect::<Result<Vec<_>, _>>()?;
            let argument = if let [argument] = arguments.as_slice() {
                *argument
            } else {
                let mut dimensions = Vec::new();
                let elements = arguments
                    .iter()
                    .map(|argument| {
                        function_argument_shape::embed(
                            &self.schema_draft_of(*argument)?,
                            &mut dimensions,
                            SourceSemanticAnchor::for_node(call),
                        )
                    })
                    .collect::<Result<Vec<_>, _>>()?;
                self.emit_with_schema_draft(
                    "core/composite-pack",
                    arguments,
                    SchemaDraft {
                        dimension_parameters: dimensions.into_boxed_slice(),
                        body: SchemaBody::Tuple(elements.into_boxed_slice()),
                    },
                    call,
                    "function-arguments",
                    Some(name.to_owned()),
                )
            };
            let index = self.nodes.len() as u32;
            self.nodes.push(PendingNode {
                body: PendingNodeBody::RecursiveCall(ancestor),
                inferable_projection: false,
                inputs: vec![argument],
                schema: expected,
                exposes_output: true,
                state: None,
                semantic: SourceSemanticNode {
                    operation: format!("function/{name}/recur"),
                    role: "recursive-call",
                    detail: Some(name.to_owned()),
                    anchor: SourceSemanticAnchor::for_node(call),
                },
            });
            return Ok(PendingValue::Node(index));
        }
        if self.active_functions.len() >= crate::MAX_CONTROL_DEPTH as usize {
            return Err(error(
                "source-semantics/function-expansion-depth",
                format!("function {name} exceeds the lexical expansion depth"),
            ));
        }
        // Resolve immutable names from the defining document's already-produced
        // bindings. Caller-local bindings never participate in this environment.
        // Parameter insertion below deliberately shadows these document globals.
        let mut local_bindings = self
            .document_bindings
            .iter()
            .filter_map(|(name, binding)| match binding {
                PendingBinding::Value(value) => Some((name.clone(), PendingBinding::Value(*value))),
                PendingBinding::MutableState(_) | PendingBinding::MutableLocal(_) => None,
            })
            .collect::<BTreeMap<_, _>>();
        let mut parameter_names = BTreeSet::new();
        let mut arguments = Vec::new();
        let mut lifted_collection = None;
        for ((parameter, schema), input) in parameters.iter().zip(selected) {
            if !parameter_names.insert(parameter.clone()) {
                return Err(error(
                    "source-semantics/duplicate-function-parameter",
                    format!("parameter {parameter} is declared twice"),
                ));
            }
            let actual = self.schema_draft_of(input)?;
            // A unary scalar function maps matrix elements regardless of its
            // body syntax. The lift retains the matrix shape and admits only
            // pure element operations when its completed body is packaged.
            let matrix_lift = parameters.len() == 1
                && schema.dimension_parameters.is_empty()
                && matches!(
                    &actual.body,
                    SchemaBody::Matrix { element, .. }
                        if lift_element_conforms(element, schema)
                );
            let set_lift = parameters.len() == 1
                && matches!(&body, DocumentFunctionBody::Patterns(_))
                && schema.dimension_parameters.is_empty()
                && matches!(
                    &actual.body,
                    SchemaBody::Set { element, .. }
                        if lift_element_conforms(element, schema)
                );
            let value = if matrix_lift {
                let SchemaBody::Matrix { element, .. } = &actual.body else {
                    unreachable!("matrix lifting retains its source schema")
                };
                let source_element = SchemaDraft {
                    dimension_parameters: Box::new([]),
                    body: element.as_ref().clone(),
                };
                let (lift, value) = self.begin_pattern_lift(
                    input,
                    &source_element,
                    PatternLiftOutput::Matrix {
                        source_schema: actual,
                    },
                    call,
                )?;
                lifted_collection = Some(lift);
                self.conform_schema_draft(
                    value,
                    schema,
                    call,
                    "source-semantics/incompatible-function-argument",
                    "function argument does not satisfy its declared kind",
                )?
            } else if set_lift {
                let SchemaBody::Set {
                    element,
                    cardinality,
                } = &actual.body
                else {
                    unreachable!("set lifting retains its source schema")
                };
                let source_element = SchemaDraft {
                    dimension_parameters: Box::new([]),
                    body: element.as_ref().clone(),
                };
                let upper_bound = match cardinality {
                    CardinalitySpec::Exact(value) => Some(value.clone()),
                    CardinalitySpec::Dynamic { upper_bound } => upper_bound.clone(),
                };
                let upper_bound = if actual.dimension_parameters.is_empty() {
                    upper_bound
                } else {
                    match upper_bound {
                        Some(DimensionExpr::Constant(value)) => {
                            Some(DimensionExpr::Constant(value))
                        }
                        _ => None,
                    }
                };
                let (lift, value) = self.begin_pattern_lift(
                    input,
                    &source_element,
                    PatternLiftOutput::Set { upper_bound },
                    call,
                )?;
                lifted_collection = Some(lift);
                self.conform_schema_draft(
                    value,
                    schema,
                    call,
                    "source-semantics/incompatible-function-argument",
                    "function argument does not satisfy its declared kind",
                )?
            } else {
                self.conform_schema_draft(
                    input,
                    schema,
                    call,
                    "source-semantics/incompatible-function-argument",
                    "function argument does not satisfy its declared kind",
                )?
            };
            local_bindings.insert(parameter.clone(), PendingBinding::Value(value));
            arguments.push(value);
        }
        let caller_bindings = std::mem::replace(&mut self.bindings, local_bindings);
        let caller_definitions = std::mem::replace(&mut self.scope_definitions, parameter_names);
        let caller_external = std::mem::take(&mut self.external_definitions);
        self.active_functions.push(name.to_owned());
        if lifted_collection.is_some() {
            self.comprehension_depth += 1;
        }
        // Function-local mutation versions local values. It must not allocate
        // retained document state or make a pure call depend on its last visit.
        self.local_mutation_depth += 1;
        let result = (|| match body {
            DocumentFunctionBody::Expression(body) => {
                if self.control_depth == 0
                    && contains_invariant(&body, &self.local_functions, &mut BTreeSet::new(), 0)?
                {
                    let expected = self.expression_function_schema(name, &body)?;
                    self.inline_function_body_frame(
                        name,
                        &body,
                        &parameters,
                        &arguments,
                        call,
                        expected,
                        &error,
                        |builder| builder.inline_expression_function_body(name, &body),
                    )
                } else {
                    self.inline_expression_function_body(name, &body)
                }
            }
            DocumentFunctionBody::Statements(body) => {
                // Keep the complete invocation in one lexical frame. In
                // particular, later closed expressions must not activate at
                // document scope ahead of an input-dependent entry check.
                // An existing selected body already orders all inlined work.
                // Recursion still needs its own argument frame and loop target.
                if calls_function(&body, name)?
                    || (self.control_depth == 0
                        && contains_invariant(
                            &body,
                            &self.local_functions,
                            &mut BTreeSet::new(),
                            0,
                        )?)
                {
                    self.inline_recursive_statement_function_body(
                        name,
                        &body,
                        &parameters,
                        &arguments,
                        call,
                        &error,
                    )
                } else {
                    self.inline_statement_function_body(name, &body, call, &error)
                }
            }
            DocumentFunctionBody::Patterns(body) => {
                self.inline_pattern_function_body(name, &body, &arguments, call)
            }
        })();
        self.local_mutation_depth -= 1;
        let result = if let Some(lift) = lifted_collection {
            self.comprehension_depth -= 1;
            self.control_depth -= 1;
            result.and_then(|result| self.finish_pattern_lift(lift, result, name, call))
        } else {
            result
        };
        self.active_functions.pop();
        self.bindings = caller_bindings;
        self.scope_definitions = caller_definitions;
        self.external_definitions = caller_external;
        result
    }

    fn expression_function_schema(
        &mut self,
        name: &str,
        body: &SyntaxNode,
    ) -> Result<SchemaDraft, SourceSemanticError> {
        let annotation = body
            .children()
            .find_map(KindAnnotationSyntax::cast)
            .ok_or_else(|| SourceSemanticError {
                code: "source-semantics/missing-function-output",
                message: format!("function {name} has no output kind"),
                anchor: SourceSemanticAnchor::for_node(body),
            })?;
        self.annotation_schema_draft(&annotation)
    }

    fn inline_expression_function_body(
        &mut self,
        name: &str,
        body: &SyntaxNode,
    ) -> Result<PendingValue, SourceSemanticError> {
        let expected = self.expression_function_schema(name, body)?;
        let expression = body
            .children()
            .find_map(ExpressionSyntax::cast)
            .ok_or_else(|| SourceSemanticError {
                code: "source-semantics/missing-function-output",
                message: format!("function {name} has no result expression"),
                anchor: SourceSemanticAnchor::for_node(body),
            })?;
        let value = self
            .expression_with_expected(&expression, Some(ExpectedSchema::Value(&expected)))?
            .0;
        self.conform_schema_draft(
            value,
            &expected,
            expression.syntax(),
            "source-semantics/incompatible-function-output",
            "function result does not satisfy its declared kind",
        )
    }

    fn begin_pattern_lift(
        &mut self,
        source: PendingValue,
        element: &SchemaDraft,
        output: PatternLiftOutput,
        call: &SyntaxNode,
    ) -> Result<(PatternLift, PendingValue), SourceSemanticError> {
        if !element.dimension_parameters.is_empty() {
            return Err(SourceSemanticError {
                code: "source-semantics/incompatible-function-argument",
                message: "collection-lifted function input requires a closed element kind"
                    .to_owned(),
                anchor: SourceSemanticAnchor::for_node(call),
            });
        }
        if self.control_depth == 0 {
            self.next_control_block = 0;
        }
        let id = self.next_control_block;
        self.next_control_block = id
            .checked_add(1)
            .filter(|id| *id as usize <= crate::MAX_CONTROL_BLOCKS)
            .ok_or_else(|| SourceSemanticError {
                code: "source-semantics/unsupported-function-body",
                message: "collection-lifted function exhausted control block identities".to_owned(),
                anchor: SourceSemanticAnchor::for_node(call),
            })?;
        self.control_depth += 1;
        let start = self.nodes.len();
        let binding = PendingValue::Node(u32::try_from(start).map_err(|_| {
            internal(
                SourceSemanticAnchor::for_node(call),
                "collection-lifted function exhausted node identities".to_owned(),
            )
        })?);
        self.nodes.push(PendingNode {
            body: PendingNodeBody::CollectionBinding,
            inferable_projection: false,
            inputs: Vec::new(),
            schema: element.clone(),
            exposes_output: true,
            state: None,
            semantic: SourceSemanticNode {
                operation: String::new(),
                role: "collection-binding",
                detail: Some("collection-lifted function element".to_owned()),
                anchor: SourceSemanticAnchor::for_node(call),
            },
        });
        Ok((
            PatternLift {
                id: crate::ControlBlockId(id),
                start,
                source,
                element: element.clone(),
                output,
            },
            binding,
        ))
    }

    fn finish_pattern_lift(
        &mut self,
        lift: PatternLift,
        result: PendingValue,
        name: &str,
        call: &SyntaxNode,
    ) -> Result<PendingValue, SourceSemanticError> {
        let output_element = self.schema_draft_of(result)?;
        if !output_element.dimension_parameters.is_empty() {
            return Err(SourceSemanticError {
                code: "source-semantics/incompatible-function-output",
                message: "collection-lifted function output requires a closed element kind"
                    .to_owned(),
                anchor: SourceSemanticAnchor::for_node(call),
            });
        }
        if matches!(lift.output, PatternLiftOutput::Set { .. }) {
            require_keyable_set_element(&output_element.body, &[], call)?;
            if !matches!(
                &output_element.body,
                SchemaBody::Bool
                    | SchemaBody::Index
                    | SchemaBody::FloatingPoint(mech_core::FloatWidth::W64)
            ) {
                return Err(SourceSemanticError {
                    code: "source-semantics/unsupported-lifted-set-result-kind",
                    message: "lifted set results require Bool, Index, or f64 elements".to_owned(),
                    anchor: SourceSemanticAnchor::for_node(call),
                });
            }
        }

        let mut inputs = Vec::new();
        let mut capture =
            |value: PendingValue| -> Result<PendingCollectionValue, SourceSemanticError> {
                match value {
                    PendingValue::Constant(id) => Ok(PendingCollectionValue::Constant(id)),
                    PendingValue::Node(index) if index as usize >= lift.start => {
                        Ok(PendingCollectionValue::Local(index - lift.start as u32))
                    }
                    PendingValue::UnresolvedEmpty(anchor) => Err(unresolved_empty(anchor)),
                    _ => {
                        let ordinal = match inputs.iter().position(|existing| *existing == value) {
                            Some(ordinal) => ordinal,
                            None => {
                                inputs.push(value);
                                inputs.len() - 1
                            }
                        };
                        Ok(PendingCollectionValue::Input(
                            u16::try_from(ordinal).map_err(|_| SourceSemanticError {
                                code: "source-semantics/unsupported-function-body",
                                message: "collection-lifted function has too many captures"
                                    .to_owned(),
                                anchor: SourceSemanticAnchor::for_node(call),
                            })?,
                        ))
                    }
                }
            };
        let source = capture(lift.source)?;
        let yield_value = capture(result)?;
        let mut steps = vec![PendingComprehensionStep::Generator {
            source,
            pattern: crate::CollectionPattern::Bind {
                local: 0,
                schema: lift.element,
            },
        }];
        for (offset, node) in self.nodes.split_off(lift.start).into_iter().enumerate() {
            let body = match node.body {
                PendingNodeBody::CollectionBinding => continue,
                PendingNodeBody::Operation {
                    operation,
                    contract: Some(contract),
                    requirement: None,
                } if node.state.is_none()
                    && contract.interaction == mech_core::ExternalInteraction::Pure =>
                {
                    PendingControlOperationBody::Operation {
                        operation,
                        contract,
                    }
                }
                PendingNodeBody::Match(control) if node.state.is_none() => {
                    PendingControlOperationBody::Match(control)
                }
                PendingNodeBody::Comprehension(control) if node.state.is_none() => {
                    PendingControlOperationBody::Comprehension(control)
                }
                PendingNodeBody::Iteration(control) if node.state.is_none() => {
                    PendingControlOperationBody::Iteration(control)
                }
                PendingNodeBody::LocalAssert if node.state.is_none() => {
                    PendingControlOperationBody::Assert
                }
                _ => {
                    return Err(SourceSemanticError {
                        code: "source-semantics/unsupported-function-body",
                        message: "collection-lifted functions require pure element operations"
                            .to_owned(),
                        anchor: SourceSemanticAnchor::for_node(call),
                    });
                }
            };
            steps.push(PendingComprehensionStep::Operation(
                PendingComprehensionOperation {
                    local: offset as u32,
                    body,
                    inputs: node
                        .inputs
                        .into_iter()
                        .map(&mut capture)
                        .collect::<Result<Box<[_]>, _>>()?,
                    schema: node.schema,
                },
            ));
        }
        let (kind, operation, schema) = match lift.output {
            PatternLiftOutput::Set { upper_bound } => (
                crate::ComprehensionKind::Set,
                "set/comprehension",
                SchemaDraft {
                    dimension_parameters: Box::new([]),
                    body: SchemaBody::Set {
                        element: Box::new(output_element.body),
                        cardinality: CardinalitySpec::Dynamic { upper_bound },
                    },
                },
            ),
            PatternLiftOutput::Matrix { source_schema } => {
                let SchemaBody::Matrix { dimensions, .. } = source_schema.body else {
                    unreachable!("matrix lifting retains its source schema")
                };
                (
                    crate::ComprehensionKind::MatrixPreserveShape,
                    "matrix/comprehension",
                    SchemaDraft {
                        dimension_parameters: source_schema.dimension_parameters,
                        body: SchemaBody::Matrix {
                            element: Box::new(output_element.body),
                            dimensions,
                        },
                    },
                )
            }
        };
        let node = self.nodes.len() as u32;
        self.nodes.push(PendingNode {
            body: PendingNodeBody::Comprehension(PendingComprehension {
                id: lift.id,
                kind,
                steps: steps.into_boxed_slice(),
                yield_value,
            }),
            inferable_projection: false,
            inputs,
            schema,
            exposes_output: true,
            state: None,
            semantic: SourceSemanticNode {
                operation: operation.to_owned(),
                role: "function-lift",
                detail: Some(name.to_owned()),
                anchor: SourceSemanticAnchor::for_node(call),
            },
        });
        Ok(PendingValue::Node(node))
    }

    fn inline_statement_function_body(
        &mut self,
        name: &str,
        body: &SyntaxNode,
        call: &SyntaxNode,
        error: &impl Fn(&'static str, String) -> SourceSemanticError,
    ) -> Result<PendingValue, SourceSemanticError> {
        let outputs = body
            .children()
            .find(|child| {
                matches!(
                    child.kind(),
                    SyntaxKind::FunctionOutArg | SyntaxKind::FunctionOutArgs
                )
            })
            .ok_or_else(|| {
                error(
                    "source-semantics/missing-function-output",
                    format!("function {name} has no output declaration"),
                )
            })?;
        let outputs = outputs
            .children()
            .filter(|child| child.kind() == SyntaxKind::FunctionArg)
            .map(|node| function_parameter(self, &node))
            .collect::<Result<Vec<_>, _>>()?;
        let mut units = Vec::new();
        let mut exports = Vec::new();
        for statement in body
            .children()
            .filter(|child| child.kind() == SyntaxKind::Statement)
        {
            collect_document_units(&statement, &mut units, &mut exports)?;
        }
        let mut bindings = self.bindings.keys().cloned().collect();
        declare_document_inputs(self, &units, &mut bindings)?;
        // Header output kinds are lexical expectations for their direct
        // definitions, so empty/compound literals can lower before final
        // return conformance. Nested calls supply their own headers instead
        // of inheriting this map from an ambient builder field.
        let mut expected_bindings = BTreeMap::new();
        for (output, schema) in &outputs {
            expected_bindings
                .entry(output.clone())
                .or_insert_with(|| schema.clone());
        }
        compile_document_units_with_definition_context(
            self,
            units,
            &bindings,
            &mut Vec::new(),
            false,
            &expected_bindings,
        )?;
        let mut values = Vec::new();
        let mut output_names = BTreeSet::new();
        for (output, schema) in outputs {
            if !output_names.insert(output.clone()) {
                return Err(error(
                    "source-semantics/duplicate-function-output",
                    format!("output {output} is declared twice"),
                ));
            }
            if !self.scope_definitions.contains(&output) {
                return Err(error(
                    "source-semantics/undefined-function-output",
                    format!("function {name} does not define output {output}"),
                ));
            }
            let binding = self.bindings.get(&output).copied().ok_or_else(|| {
                error(
                    "source-semantics/undefined-function-output",
                    format!("function {name} does not define output {output}"),
                )
            })?;
            let value = self.read_document_binding(binding, call)?;
            values.push(self.conform_schema_draft(
                value,
                &schema,
                call,
                "source-semantics/incompatible-function-output",
                "function output does not satisfy its declared kind",
            )?);
        }
        if let [value] = values.as_slice() {
            return Ok(*value);
        }
        let mut dimensions = Vec::new();
        let schemas = values
            .iter()
            .map(|value| {
                embed_schema_draft(
                    &self.schema_draft_of(*value)?,
                    &mut dimensions,
                    SourceSemanticAnchor::for_node(call),
                )
            })
            .collect::<Result<Vec<_>, _>>()?;
        Ok(self.emit_with_schema_draft(
            "core/composite-pack",
            values,
            SchemaDraft {
                dimension_parameters: dimensions.into_boxed_slice(),
                body: SchemaBody::Tuple(schemas.into_boxed_slice()),
            },
            call,
            "function-outputs",
            Some(name.to_owned()),
        ))
    }

    fn inline_pattern_function_body(
        &mut self,
        name: &str,
        body: &SyntaxNode,
        arguments: &[PendingValue],
        call: &SyntaxNode,
    ) -> Result<PendingValue, SourceSemanticError> {
        let output = body
            .children()
            .find_map(KindAnnotationSyntax::cast)
            .ok_or_else(|| SourceSemanticError {
                code: "source-semantics/missing-function-output",
                message: format!("function {name} has no output kind"),
                anchor: SourceSemanticAnchor::for_node(body),
            })?;
        let expected = self.annotation_schema_draft(&output)?;
        let scrutinee = if let [argument] = arguments {
            *argument
        } else {
            let mut dimensions = Vec::new();
            let elements = arguments
                .iter()
                .map(|argument| {
                    function_argument_shape::embed(
                        &self.schema_draft_of(*argument)?,
                        &mut dimensions,
                        SourceSemanticAnchor::for_node(call),
                    )
                })
                .collect::<Result<Vec<_>, _>>()?;
            self.emit_with_schema_draft(
                "core/composite-pack",
                arguments.to_vec(),
                SchemaDraft {
                    dimension_parameters: dimensions.into_boxed_slice(),
                    body: SchemaBody::Tuple(elements.into_boxed_slice()),
                },
                call,
                "function-arguments",
                Some(name.to_owned()),
            )
        };
        let arms = body
            .children()
            .filter(|child| child.kind() == SyntaxKind::FunctionMatchArm)
            .map(|arm| {
                let pattern = arm.children().find_map(PatternSyntax::cast);
                let value = arm
                    .children()
                    .find_map(ExpressionSyntax::cast)
                    .ok_or_else(|| SourceSemanticError {
                        code: "source-semantics/missing-function-arm-value",
                        message: format!("function {name} has an arm without a value"),
                        anchor: SourceSemanticAnchor::for_node(&arm),
                    })?;
                Ok(SourceMatchArm {
                    pattern,
                    guard: None,
                    body: SourceMatchBody::Expression(value),
                    syntax: arm,
                })
            })
            .collect::<Result<Vec<_>, SourceSemanticError>>()?;
        if arms
            .iter()
            .map(|arm| calls_function(arm.body.syntax(), name))
            .collect::<Result<Vec<_>, _>>()?
            .into_iter()
            .any(|recursive| recursive)
        {
            for arm in &arms {
                let mut bindings = Vec::new();
                if let Some(pattern) = &arm.pattern {
                    collect_pattern_bindings(pattern, &mut bindings)?;
                }
                for parameter in &self.scope_definitions {
                    if !bindings.iter().any(|binding| &binding.name == parameter)
                        && references_variable(arm.body.syntax(), parameter)?
                    {
                        return Err(SourceSemanticError {
                            code: "source-semantics/recursive-function-capture",
                            message: format!(
                                "recursive function {name} must bind parameter {parameter} in every arm that reads it"
                            ),
                            anchor: SourceSemanticAnchor::for_node(&arm.syntax),
                        });
                    }
                }
            }
        }
        let enum_input = matches!(
            self.schema_draft_of(scrutinee)?.body,
            SchemaBody::Enum { .. }
        );
        self.active_recursive_outputs.push((
            name.to_owned(),
            expected.clone(),
            self.match_depth + 1,
            self.comprehension_depth,
        ));
        let result = self.lower_match_expression(
            scrutinee,
            &arms,
            body,
            !enum_input,
            Some(&expected),
            false,
        );
        self.active_recursive_outputs.pop();
        let result = result?;
        self.conform_schema_draft(
            result,
            &expected,
            call,
            "source-semantics/incompatible-function-output",
            "function output does not satisfy its declared kind",
        )
    }
}

#[cfg(test)]
mod recursive_capture_tests {
    use super::*;

    use mech_syntax::document::{DocumentId, ParseConfig, Revision, TextSnapshot};

    fn expression(source: &str) -> ExpressionSyntax {
        fn find(node: SyntaxNode) -> Option<ExpressionSyntax> {
            ExpressionSyntax::cast(node.clone()).or_else(|| node.children().find_map(find))
        }
        let parsed = mech_syntax::document::parse_canonical_document(
            TextSnapshot::new(DocumentId(0x557), Revision(1), source).unwrap(),
            ParseConfig::default(),
        );
        assert!(parsed.is_strictly_clean(), "{source}");
        let syntax = find(parsed.syntax()).unwrap();
        assert_eq!(syntax.syntax().range(), parsed.source.full_range());
        syntax
    }

    #[test]
    fn nested_binders_only_shadow_their_own_scopes() {
        for (source, captures_n) in [
            ("(1 ? | n => n)", false),
            ("(n ? | x => x)", true),
            ("[n | n <- [1]]", false),
            ("[n | x <- [1]]", true),
            ("[x | x <- n]", true),
        ] {
            assert_eq!(
                references_variable(expression(source).syntax(), "n").unwrap(),
                captures_n,
                "{source}"
            );
        }
    }
}
