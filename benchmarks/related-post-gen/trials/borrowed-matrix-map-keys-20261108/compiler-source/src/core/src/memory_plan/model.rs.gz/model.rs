#[cfg(feature = "functions")]
use crate::BoundCall;
use crate::{
    CellSlotId, ConstantId, ExtentEvolution, MemoryTopology, NodeId, PortDirection, RegionPolicy,
    ResolvedValueDescriptor, ScalarMemoryKind, StorageCapabilityDescriptor,
};

#[cfg(feature = "no_std")]
use alloc::{boxed::Box, string::String};
#[cfg(not(feature = "no_std"))]
use std::{boxed::Box, string::String};

macro_rules! plan_id {
    ($name:ident) => {
        #[repr(transparent)]
        #[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
        pub struct $name(u32);

        impl $name {
            pub const fn new(raw: u32) -> Self {
                Self(raw)
            }

            pub const fn get(self) -> u32 {
                self.0
            }
        }
    };
}

plan_id!(MemoryObjectId);
plan_id!(MemoryArenaId);
plan_id!(AliasGroupId);
plan_id!(ReuseGroupId);
plan_id!(MemoryPlanPoint);

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum MemoryTargetKind {
    DirectHost,
    ResidentCpu,
    NativeHost,
    WasmHost,
    Gpu,
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum MemorySpace {
    Host,
    ResidentCpu,
    Device { region: u32 },
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum PlannedSlotKind {
    FixedScalar(ScalarMemoryKind),
    StringHeader,
    CanonicalValueHandle,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum StorageLayoutClass {
    Scalar { slot: PlannedSlotKind },
    DenseColumnMajor { slot: PlannedSlotKind },
    CanonicalSnapshot { topology: MemoryTopology },
}

impl StorageLayoutClass {
    pub const fn planned_slot(&self) -> PlannedSlotKind {
        match self {
            Self::Scalar { slot } | Self::DenseColumnMajor { slot } => *slot,
            Self::CanonicalSnapshot { .. } => PlannedSlotKind::CanonicalValueHandle,
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct SlotLayout {
    pub bytes: u64,
    pub alignment: u32,
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum CapacityAuthority {
    ExactSemantic,
    ActivationSemantic,
    SemanticUpperBound,
    CurrentValueWitness,
    TargetPolicyLimit,
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum GrowthPolicy {
    Fixed,
    ReservedToBound,
    ReplanBeforeGrowth,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct CapacityRequirement {
    pub current: u64,
    pub required: u64,
    pub maximum: Option<u64>,
    pub authority: CapacityAuthority,
    pub growth: GrowthPolicy,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct AxisCapacityPlan {
    pub current: u64,
    pub capacity: CapacityRequirement,
    pub evolution: ExtentEvolution,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct PayloadCapacityPlan {
    pub current_bytes: u64,
    pub required_bytes: u64,
    pub maximum_bytes: Option<u64>,
    pub current_nodes: u64,
    pub required_nodes: u64,
    pub maximum_nodes: Option<u64>,
    pub authority: CapacityAuthority,
    pub growth: GrowthPolicy,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct DimensionCapacity {
    pub current: u64,
    pub maximum: Option<u64>,
    pub evolution: ExtentEvolution,
}

/// Additional implementation work and allocator-backed scratch for one call.
/// This augments, rather than replaces, its maintained implementation memory class.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub struct PlannedExecutionDemand {
    pub temporary_bytes: u64,
    pub cloned_bytes: u64,
    pub retained_nodes: u64,
    pub work: super::WorkDemand,
}

/// Current input authorities shared by prospective output and execution planning.
/// No published-output footprint or reconstructed input payload is substituted.
#[cfg(feature = "functions")]
pub struct ExecutionDemandPlanningRequest<'a> {
    pub inputs: &'a [ResolvedValueDescriptor],
    pub input_witnesses: &'a [MemoryFootprintWitness],
}

#[cfg(feature = "functions")]
impl ExecutionDemandPlanningRequest<'_> {
    pub fn input_footprint(
        &self,
        input: usize,
    ) -> Result<CurrentMemoryFootprint, super::MemoryPlanError> {
        if self.inputs.len() != self.input_witnesses.len() || input >= self.inputs.len() {
            return Err(super::MemoryPlanError::DescriptorArityMismatch);
        }
        match self.input_witnesses[input] {
            MemoryFootprintWitness::Known(footprint) => Ok(footprint),
            MemoryFootprintWitness::Deferred(stage) => {
                Err(super::MemoryPlanError::MissingFootprintWitness { stage })
            }
        }
    }
}

#[derive(Clone, Copy, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct CurrentMemoryFootprint {
    pub logical_elements: u64,
    pub fixed_bytes: u64,
    pub payload_bytes: u64,
    pub encoded_bytes: u64,
    pub retained_nodes: u64,
    pub schema_bytes: u64,
    pub shape_parameter_count: u64,
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum MemoryWitnessStage {
    Activation,
    Turn,
    ExternalIngress,
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum MemoryFootprintWitness {
    Known(CurrentMemoryFootprint),
    Deferred(MemoryWitnessStage),
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct DeferredMemoryWitness {
    pub direction: PortDirection,
    pub port: u16,
    pub stage: MemoryWitnessStage,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ValueLayoutPlan {
    pub storage: StorageLayoutClass,
    pub axes: Box<[AxisCapacityPlan]>,
    pub current_elements: u64,
    pub capacity_elements: CapacityRequirement,
    pub slot: SlotLayout,
    pub strides_bytes: Box<[u64]>,
    pub current_address_span_bytes: u64,
    pub capacity_bytes: u64,
    pub payload: PayloadCapacityPlan,
}

#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum MemoryObjectOwner {
    Constant(ConstantId),
    Slot(CellSlotId),
    NodeInput {
        node: NodeId,
        port: u16,
    },
    NodeOutput {
        node: NodeId,
        port: u16,
    },
    NodeScratch {
        node: NodeId,
        ordinal: u16,
    },
    TransactionStage {
        node: NodeId,
        output: u16,
    },
    Transfer {
        ordinal: u32,
    },
    DirectCallPort {
        call: u32,
        direction: PortDirection,
        port: u16,
    },
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum AllocationRole {
    FixedStorage,
    VariablePayload,
    /// Reservation-backed heap construction workspace. Unlike numeric
    /// `Scratch`, this authority is realized indirectly and never allocates
    /// an otherwise-unused contiguous host block.
    ConstructionWorkspace,
    OrderedIndex,
    SelectorPlan,
    Scratch,
    TransactionStage,
    TransferStage,
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct ArenaPlacement {
    pub arena: MemoryArenaId,
    pub offset: u64,
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum MemoryLifetime {
    Program,
    Activation,
    Turn {
        first: MemoryPlanPoint,
        last: MemoryPlanPoint,
    },
    Transaction {
        first: MemoryPlanPoint,
        last: MemoryPlanPoint,
    },
    Transfer {
        first: MemoryPlanPoint,
        last: MemoryPlanPoint,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AllocationPlan {
    pub id: MemoryObjectId,
    pub owner: MemoryObjectOwner,
    pub role: AllocationRole,
    /// Sealed element/header identity for typed access. `None` denotes an
    /// explicitly raw byte/scratch allocation and cannot be opened as a typed
    /// value view.
    pub slot: Option<PlannedSlotKind>,
    pub space: MemorySpace,
    pub current_bytes: u64,
    pub capacity_bytes: u64,
    /// Maximum simultaneously registered independent payload blocks for an
    /// indirect envelope. Zero for contiguous/device allocations.
    pub payload_block_capacity: u64,
    pub alignment: u32,
    pub lifetime: MemoryLifetime,
    pub placement: ArenaPlacement,
    pub reuse_group: Option<ReuseGroupId>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ArenaPlan {
    pub id: MemoryArenaId,
    pub space: MemorySpace,
    pub backing: ArenaBackingKind,
    pub alignment: u32,
    pub capacity_bytes: u64,
    pub members: Box<[MemoryObjectId]>,
}

/// Physical ownership model required to realize an arena.
///
/// Indirect payload offsets are accounting coordinates. They are never
/// interpreted as addresses within one contiguous allocation.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum ArenaBackingKind {
    ContiguousBytes,
    IndirectOwnedPayloads,
    /// Finite construction authority for allocator-backed temporary objects.
    /// The arena is an accounting coordinate only: realization must not also
    /// allocate a contiguous block or a persistent payload registry for it.
    ReservationOnlyWorkspace,
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum AliasDecision {
    Disjoint,
    BorrowInput { input: u16 },
    ReuseInput { input: u16 },
    InPlaceRequired { input: u16 },
    StageThenPublish { input: Option<u16> },
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum TransactionRequirement {
    None,
    StageAndSwap {
        current: MemoryObjectId,
        staged: MemoryObjectId,
    },
    UndoSnapshot {
        target: MemoryObjectId,
        undo: MemoryObjectId,
    },
    DoubleBuffer {
        current: MemoryObjectId,
        next: MemoryObjectId,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RegionAccessPlan {
    WholeValue,
    Contiguous {
        offset_bytes: u64,
        length_bytes: u64,
    },
    Strided {
        offset_bytes: u64,
        count: u64,
        stride_bytes: u64,
        element_bytes: u64,
    },
    Rectangle {
        base_offset_bytes: u64,
        rows: u64,
        columns: u64,
        row_stride_bytes: u64,
        column_stride_bytes: u64,
    },
    Gather {
        selected_elements: u64,
        index_bytes: u64,
    },
    CollectionEntry {
        key_bytes: u64,
    },
    Deferred(RegionPolicy),
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum TransferDirection {
    Upload,
    Readback,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TransferPlan {
    pub slot: CellSlotId,
    pub direction: TransferDirection,
    pub source: MemorySpace,
    pub destination: MemorySpace,
    pub current_bytes: u64,
    pub capacity_bytes: u64,
    pub lifetime: MemoryLifetime,
    pub consumer: Option<NodeId>,
    pub interface_name: Option<String>,
}

/// Pointer-free description of one backing selected by semantic type authority.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PhysicalStorageDescriptor {
    pub capabilities: StorageCapabilityDescriptor,
    pub slot: PlannedSlotKind,
    pub space: MemorySpace,
    pub lifetime: MemoryLifetime,
    pub reusable_turn_temporary: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PortMemoryPlan {
    pub descriptor: ResolvedValueDescriptor,
    pub value: ValueLayoutPlan,
    pub region: RegionAccessPlan,
    pub object: MemoryObjectId,
}

#[cfg(feature = "functions")]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CallMemoryPlan {
    pub bound_call: BoundCall,
    pub inputs: Box<[PortMemoryPlan]>,
    pub outputs: Box<[PortMemoryPlan]>,
    /// Physical authorities are retained so resolving a provider-owned
    /// contract can re-run the complete planner rather than relabeling a
    /// stale layout, alias, transaction, scratch, and demand result.
    pub input_storage: Box<[PhysicalStorageDescriptor]>,
    pub output_storage: Box<[PhysicalStorageDescriptor]>,
    /// Original footprint authorities are retained so a deferred activation
    /// or turn witness can replace them and re-derive every dependent demand
    /// through the same core calculation used during call planning.
    pub input_witnesses: Box<[MemoryFootprintWitness]>,
    pub output_witnesses: Box<[MemoryFootprintWitness]>,
    /// Original semantic output regions are retained independently from the
    /// provisionally derived output ports. External contracts may not expose
    /// their final memory requirements until provider resolution.
    pub output_regions: Box<[RegionAccessPlan]>,
    pub input_lifetimes: Box<[MemoryLifetime]>,
    pub output_lifetimes: Box<[MemoryLifetime]>,
    pub allocations: Box<[AllocationPlan]>,
    pub aliases: Box<[AliasDecision]>,
    pub transactions: Box<[TransactionRequirement]>,
    pub implementation_memory: super::ImplementationMemoryClass,
    pub target: super::TargetMemoryProfile,
    pub demand: super::ResourceDemand,
    pub deferred_witnesses: Box<[DeferredMemoryWitness]>,
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum MemoryPlanAuditStatus {
    Exact,
    WithinPlannedCapacity,
    CapacityDeferredToRuntime,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MemoryPlanObservation {
    pub object: MemoryObjectId,
    pub current_bytes: u64,
    pub capacity_bytes: u64,
    pub payload_bytes: u64,
    pub retained_nodes: u64,
    pub logical_elements: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MemoryPlanAuditMismatch {
    pub object: MemoryObjectId,
    pub field: &'static str,
    pub planned: u64,
    pub observed: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MemoryPlanAuditReport {
    pub statuses: Box<[(MemoryObjectId, MemoryPlanAuditStatus)]>,
    pub mismatches: Box<[MemoryPlanAuditMismatch]>,
}

impl MemoryPlanAuditReport {
    pub fn assert_conformant(&self) -> Result<(), super::MemoryPlanError> {
        if let Some(mismatch) = self.mismatches.first() {
            return Err(super::MemoryPlanError::ObservationExceeded {
                mismatch: mismatch.clone(),
            });
        }
        Ok(())
    }
}
