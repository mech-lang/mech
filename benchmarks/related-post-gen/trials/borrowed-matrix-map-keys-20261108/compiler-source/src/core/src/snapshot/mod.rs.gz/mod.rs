mod composite_cost;
mod constants;
mod data;
mod draft;
mod encoding;
mod error;
mod index;
mod relations;
mod set_conversion;
pub(crate) use self::set_conversion::{
    normalize_set_conversion_drafts, normalize_set_conversion_drafts_with_context,
};
mod sequence;
pub(crate) mod validation;
mod views;

pub use self::composite_cost::CompositeBindingCost;
pub use self::constants::{
    ConstantEntry, ConstantHandle, ConstantStore, ConstantStoreBuild, ConstantStoreBuilder,
};
pub use self::data::{
    CanonicalKeyValue, Complex32Bits, Complex64Bits, DynamicValue, EnumValue, F32Bits, F64Bits,
    MapEntryValue, MapValue, MatrixValue, Rational64Value, RecordValue, ReifiedKind, ReifiedType,
    SetValue, TableValue, ValueData,
};
pub use self::draft::{
    EnumDraft, MapEntryDraft, NamedValueDraft, OptionDraft, ReifiedTypeDraft, TableColumnDraft,
    ValueDataDraft, ValueDraft,
};
pub use self::encoding::{
    CanonicalDataWork, CanonicalDataWorkError, ValueFootprint, ValueFootprintError,
    canonical_data_payload_len, canonical_data_retained_footprint,
    canonical_sequence_element_retained_footprint, prospective_packed_matrix_node_count,
    prospective_string_value_footprint, visit_canonical_data_work,
};
pub use self::error::{
    SchemaDataKind, SnapshotPath, SnapshotPathSegment, SnapshotValueError, ValueDataKind,
};
pub use self::relations::{
    SetValueRelation, canonical_data_draft_finalization_work,
    canonical_data_draft_finalization_work_with_budget, canonical_key_draft_finalization_work,
    canonical_key_draft_finalization_work_with_budget, compare_key_data, schema_data_language_eq,
    schema_data_partial_cmp, schema_data_snapshot_eq,
};
pub use self::sequence::SequenceView;
pub use self::validation::{
    CompositeSnapshotConstructor, FrozenSnapshotIdentity, MatrixSnapshotConstructor,
    OwnedSnapshotBytes, OwnedSnapshotString, OwnedSnapshotUnsignedMatrix,
    PrivateUnsignedAppendPreparation, PrivateUnsignedMatrix, SnapshotCanonicalizationBudget,
    SnapshotValidationContext, StringMatrixSnapshotConstructor, StringOwnershipTransfer,
    StringSnapshotConstructor, TableSnapshotBuilder, UnsignedMatrixBuffer,
    UnsignedMatrixOwnershipTransfer, UnsignedMatrixSnapshotConstructor, UnsignedMatrixViewMut,
    Value, build_f64_set_snapshot, build_f64_set_snapshot_after_remove,
    canonical_snapshot_data_draft, canonical_snapshot_data_draft_in,
    canonical_snapshot_data_draft_with_context, dynamic_canonical_allocation_bound_bytes,
    f64_set_snapshot_contains, rebuild_f64_set_snapshot, wrap_resident_dynamic_data,
    wrap_resident_dynamic_value,
};
pub use self::views::{EnumView, MapView, MatrixView, RecordView, SetView, TableView, TupleView};
pub use crate::{ConstantId, KeyHash, ValueHash};

#[cfg(test)]
mod composite_constructor_tests;

#[cfg(test)]
mod matrix_constructor_tests;

#[cfg(test)]
mod matrix_node_footprint_tests;
