#![cfg(feature = "functions")]

use mech_core::snapshot::{F64Bits, SnapshotValidationContext};
use mech_core::{
    AllocationPlan, AllocationRole, ArenaBackingKind, ArenaPlacement, ArenaPlan, CallAccessRequest,
    CellPublicationCandidate, CellPublicationEvidence, FunctionInvocation, KernelMemoryFrame,
    ManagedCallAccessRequest, ManagedPort, ManagedSequence, ManagedString, MechExecutionServices,
    MechFunctionImpl, MemoryAccessMode, MemoryAccessRegion, MemoryArenaId, MemoryBudgetLimits,
    MemoryBudgetViolation, MemoryDomain, MemoryLifetime, MemoryObjectId, MemoryObjectOwner,
    MemoryPlanPoint, MemoryPlanRevision, MemoryRuntimeError, MemorySpace, NoMechExecutionServices,
    PreparedCellPublication, PreparedCellPublicationBatch, PublicationCandidate,
    ReactiveSolveStatus, ResourceDemand, ReuseGroupId, RuntimeBinding, RuntimePlanView, SchemaBody,
    SchemaDraft, SchemaTableBuilder, ValueCell, ValueDataDraft, ValueDraft,
};

fn runtime_plan_view<'a>(
    revision: MemoryPlanRevision,
    allocations: &'a [AllocationPlan],
    arenas: &'a [ArenaPlan],
    demand: ResourceDemand,
    limits: MemoryBudgetLimits,
    violations: &'a [MemoryBudgetViolation],
) -> RuntimePlanView<'a> {
    RuntimePlanView::for_call(
        revision,
        allocations,
        arenas,
        demand,
        0,
        limits,
        &[],
        64,
        violations,
    )
}

fn allocation(
    id: u32,
    arena: u32,
    offset: u64,
    current: u64,
    capacity: u64,
    lifetime: MemoryLifetime,
    reuse_group: Option<u32>,
) -> AllocationPlan {
    AllocationPlan {
        id: MemoryObjectId::new(id),
        owner: MemoryObjectOwner::DirectCallPort {
            call: 0,
            direction: mech_core::PortDirection::Output,
            port: id as u16,
        },
        role: AllocationRole::FixedStorage,
        slot: Some(mech_core::PlannedSlotKind::FixedScalar(
            mech_core::ScalarMemoryKind::Unsigned(mech_core::IntegerWidth::W64),
        )),
        space: MemorySpace::Host,
        current_bytes: current,
        capacity_bytes: capacity,
        payload_block_capacity: 0,
        alignment: 8,
        lifetime,
        placement: ArenaPlacement {
            arena: MemoryArenaId::new(arena),
            offset,
        },
        reuse_group: reuse_group.map(ReuseGroupId::new),
    }
}

fn f64_allocation(
    id: u32,
    arena: u32,
    offset: u64,
    current: u64,
    capacity: u64,
    lifetime: MemoryLifetime,
) -> AllocationPlan {
    let mut allocation = allocation(id, arena, offset, current, capacity, lifetime, None);
    allocation.slot = Some(mech_core::PlannedSlotKind::FixedScalar(
        mech_core::ScalarMemoryKind::Floating(mech_core::FloatWidth::W64),
    ));
    allocation
}

fn arena(id: u32, backing: ArenaBackingKind, capacity: u64, members: &[u32]) -> ArenaPlan {
    ArenaPlan {
        id: MemoryArenaId::new(id),
        space: MemorySpace::Host,
        backing,
        alignment: 8,
        capacity_bytes: capacity,
        members: members
            .iter()
            .copied()
            .map(MemoryObjectId::new)
            .collect::<Vec<_>>()
            .into_boxed_slice(),
    }
}

#[test]
fn reservations_are_finite_and_release_unused_authority() {
    let domain = MemoryDomain::new().unwrap();
    let revision = domain.issue_plan_revision().unwrap();
    let allocations = [allocation(0, 0, 0, 8, 64, MemoryLifetime::Activation, None)];
    let arenas = [arena(0, ArenaBackingKind::ContiguousBytes, 64, &[0])];
    {
        let reservation = domain
            .prepare_realization(runtime_plan_view(
                revision,
                &allocations,
                &arenas,
                ResourceDemand::default(),
                MemoryBudgetLimits::default(),
                &[],
            ))
            .unwrap();
        assert_eq!(reservation.reserved_bytes(), 72);
        assert_eq!(domain.ledger().reserved_bytes, 72);
        assert_eq!(domain.ledger().active_reservations, 1);
    }
    assert_eq!(domain.ledger().reserved_bytes, 0);
    assert_eq!(domain.ledger().active_reservations, 0);
}

#[test]
fn configured_memory_budget_counts_unique_arenas_and_shared_reservations() {
    let budget = mech_core::ManagedMemoryBudget::new(80);
    let domain = MemoryDomain::with_memory_budget(budget.clone()).unwrap();
    let sibling = MemoryDomain::with_memory_budget(budget.clone()).unwrap();
    // The shared 64-byte physical arena is counted once, plus each object's
    // existing 8-byte initialization bitmap. It is not 64 bytes per member.
    let allocations = [
        allocation(0, 0, 0, 8, 32, MemoryLifetime::Activation, None),
        allocation(1, 0, 32, 8, 32, MemoryLifetime::Activation, None),
    ];
    let arenas = [arena(0, ArenaBackingKind::ContiguousBytes, 64, &[0, 1])];
    let reserve = |owner: &MemoryDomain| {
        owner.prepare_realization(runtime_plan_view(
            owner.issue_plan_revision().unwrap(),
            &allocations,
            &arenas,
            ResourceDemand::default(),
            MemoryBudgetLimits::default(),
            &[],
        ))
    };
    let reservation = reserve(&domain).unwrap();
    assert_eq!(reservation.reserved_bytes(), 80);
    assert_eq!(budget.used_bytes(), 80);
    assert!(matches!(
        reserve(&sibling),
        Err(MemoryRuntimeError::BudgetExceeded {
            requested: 160,
            limit: 80,
            ..
        })
    ));
    assert_eq!(sibling.ledger().reserved_bytes, 0);
    assert!(sibling.allocation_observations().is_empty());
    drop(reservation);
    assert_eq!(budget.used_bytes(), 0);
    let realized = domain.materialize(reserve(&domain).unwrap()).unwrap();
    assert_eq!(budget.used_bytes(), 80);
    drop(domain);
    assert_eq!(budget.used_bytes(), 80, "live realization owns its backing");
    drop(realized);
    assert_eq!(budget.used_bytes(), 0);

    let one_under =
        MemoryDomain::with_memory_budget(mech_core::ManagedMemoryBudget::new(79)).unwrap();
    assert!(matches!(
        reserve(&one_under),
        Err(MemoryRuntimeError::BudgetExceeded {
            requested: 80,
            limit: 79,
            ..
        })
    ));
    assert!(one_under.allocation_observations().is_empty());
}

#[test]
fn configured_memory_budget_rejects_combined_states_before_allocation_and_releases_failure() {
    let budget = mech_core::ManagedMemoryBudget::new(144);
    let domain = MemoryDomain::with_memory_budget(budget.clone()).unwrap();
    let allocations = [
        allocation(0, 0, 0, 8, 64, MemoryLifetime::Activation, None),
        allocation(1, 1, 0, 8, 64, MemoryLifetime::Activation, None),
    ];
    let arenas = [
        arena(0, ArenaBackingKind::ContiguousBytes, 64, &[0]),
        arena(1, ArenaBackingKind::ContiguousBytes, 64, &[1]),
    ];
    let reserve = |owner: &MemoryDomain| {
        owner.prepare_realization(runtime_plan_view(
            owner.issue_plan_revision().unwrap(),
            &allocations,
            &arenas,
            ResourceDemand::default(),
            MemoryBudgetLimits::default(),
            &[],
        ))
    };
    let limited =
        MemoryDomain::with_memory_budget(mech_core::ManagedMemoryBudget::new(143)).unwrap();
    assert!(matches!(
        reserve(&limited),
        Err(MemoryRuntimeError::BudgetExceeded { .. })
    ));
    assert!(limited.allocation_observations().is_empty());
    domain
        .inject_failure_after(mech_core::MemoryFailurePoint::HostAllocation, 1)
        .unwrap();
    assert!(matches!(
        domain.materialize(reserve(&domain).unwrap()),
        Err(MemoryRuntimeError::AllocationFailed { .. })
    ));
    assert_eq!(
        budget.used_bytes(),
        0,
        "both partial ownership and unused reservation release"
    );
    assert_eq!(domain.ledger().reserved_bytes, 0);
    assert!(domain.allocation_observations().is_empty());
    let realized = domain.materialize(reserve(&domain).unwrap()).unwrap();
    assert_eq!(budget.used_bytes(), 144);
    domain.close().unwrap();
    assert_eq!(
        budget.used_bytes(),
        144,
        "close cannot uncharge retained storage"
    );
    drop(realized);
    domain.collect_retired().unwrap();
    assert_eq!(budget.used_bytes(), 0);
}

#[test]
fn configured_memory_budget_follows_independent_payload_and_frozen_owners() {
    let budget = mech_core::ManagedMemoryBudget::new(1024 * 1024);
    let domain = MemoryDomain::with_memory_budget(budget.clone()).unwrap();
    let revision = domain.issue_plan_revision().unwrap();
    let mut payload = allocation(0, 0, 0, 0, 16, MemoryLifetime::Activation, None);
    payload.role = AllocationRole::VariablePayload;
    payload.slot = None;
    payload.payload_block_capacity = 1;
    payload.alignment = 1;
    let realized = domain
        .materialize(
            domain
                .prepare_realization(runtime_plan_view(
                    revision,
                    &[payload],
                    &[arena(0, ArenaBackingKind::IndirectOwnedPayloads, 16, &[0])],
                    ResourceDemand::default(),
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    let allocator = domain
        .planned_allocator(
            &realized,
            domain
                .plan_object_key(revision, MemoryObjectId::new(0))
                .unwrap(),
        )
        .unwrap();
    let string = ManagedString::try_new(allocator.clone(), "retained").unwrap();
    let envelope_bytes = budget.used_bytes();
    assert!(envelope_bytes >= 16);
    domain.close().unwrap();
    drop(realized);
    drop(domain);
    assert_eq!(budget.used_bytes(), envelope_bytes);
    assert_eq!(string.as_str(), "retained");
    assert!(matches!(
        ManagedString::try_new(allocator.clone(), "x"),
        Err(MemoryRuntimeError::DomainClosed)
    ));
    drop(allocator);
    drop(string);
    assert_eq!(budget.used_bytes(), 0);

    let domain = MemoryDomain::with_memory_budget(budget.clone()).unwrap();
    let cell = ValueCell::from_exact_in(&domain, "immutable owned payload".to_owned()).unwrap();
    let snapshot = cell.snapshot().unwrap();
    let shared = snapshot.clone();
    let before_clone = budget.used_bytes();
    let another = shared.clone();
    assert_eq!(
        budget.used_bytes(),
        before_clone,
        "shared roots charge once"
    );
    drop(another);
    drop(cell);
    domain.close().unwrap();
    drop(domain);
    assert!(
        budget.used_bytes() > 0,
        "detached immutable allocation retains its budget ticket"
    );
    assert!(
        matches!(snapshot.data(), mech_core::ValueData::String(value) if value.as_ref() == "immutable owned payload")
    );
    drop(snapshot);
    std::thread::spawn(move || drop(shared)).join().unwrap();
    assert_eq!(budget.used_bytes(), 0);
}

#[test]
fn resident_payload_transfer_moves_capacity_and_revokes_the_replaced_envelope() {
    let budget = mech_core::ManagedMemoryBudget::new(1024 * 1024);
    let domain = MemoryDomain::with_memory_budget(budget.clone()).unwrap();
    let revision = domain.issue_plan_revision().unwrap();
    let mut payload = allocation(0, 0, 0, 0, 4096, MemoryLifetime::Activation, None);
    payload.role = AllocationRole::VariablePayload;
    payload.slot = None;
    payload.payload_block_capacity = 4;
    payload.alignment = 8;
    let realized = domain
        .materialize(
            domain
                .prepare_realization(runtime_plan_view(
                    revision,
                    &[payload],
                    &[arena(
                        0,
                        ArenaBackingKind::IndirectOwnedPayloads,
                        4096,
                        &[0],
                    )],
                    ResourceDemand::default(),
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    let key = domain
        .plan_object_key(revision, MemoryObjectId::new(0))
        .unwrap();
    let before = budget.used_bytes();
    let transferred = domain
        .transfer_resident_payload_budget_capacity(&realized, key)
        .unwrap();
    assert_eq!(transferred.capacity_bytes(), 4096);
    assert_eq!(budget.used_bytes(), before);
    let revoked = domain.planned_allocator(&realized, key).unwrap();
    assert!(matches!(
        ManagedString::try_new(revoked, "cannot allocate twice"),
        Err(MemoryRuntimeError::DomainClosed)
    ));
    drop(realized);
    drop(domain);
    assert_eq!(budget.used_bytes(), 4096);
    drop(transferred);
    assert_eq!(budget.used_bytes(), 0);
}

fn detached_budget_test_value(payload: &str) -> mech_core::Value {
    let schema = SchemaDraft {
        dimension_parameters: Box::new([]),
        body: SchemaBody::String,
    }
    .finalize()
    .unwrap();
    let mut builder = SchemaTableBuilder::new();
    let handle = builder.insert(schema).unwrap();
    let build = builder.finish().unwrap();
    let schema = build.resolve(handle).unwrap();
    let (schemas, _) = build.into_parts();
    ValueDraft {
        schema,
        shape_values: Box::new([]),
        data: ValueDataDraft::String(payload.to_owned()),
    }
    .finalize(&SnapshotValidationContext::new(&schemas))
    .unwrap()
}

#[test]
fn immutable_budget_handoff_shares_roots_and_retains_old_candidate_coexistence() {
    let old = detached_budget_test_value("old immutable bytes");
    let bytes = old
        .memory_budget_admission_bytes(&mech_core::ManagedMemoryBudget::new(u64::MAX))
        .unwrap();
    let retained = old.memory_budget_required_bytes().unwrap();
    let budget = mech_core::ManagedMemoryBudget::new(bytes * 2);
    let mut admitted = budget.reserve_capacity(bytes * 2).unwrap();
    let old = old.into_memory_budget(&mut admitted).unwrap();
    assert_eq!(admitted.capacity_bytes(), bytes);
    assert_eq!(old.memory_budget_retained_bytes(&budget), Some(retained));
    let exported = old.clone().into_memory_budget(&mut admitted).unwrap();
    assert_eq!(admitted.capacity_bytes(), bytes);
    assert!(old.shares_frozen_storage(&exported));

    let candidate = detached_budget_test_value("new immutable bytes");
    assert_eq!(
        candidate.memory_budget_admission_bytes(&budget).unwrap(),
        bytes
    );
    let candidate = candidate.into_memory_budget(&mut admitted).unwrap();
    assert_eq!(admitted.capacity_bytes(), 0);
    assert_eq!(budget.used_bytes(), bytes * 2);
    assert!(budget.reserve_capacity(1).is_err());
    drop(old);
    assert_eq!(budget.used_bytes(), bytes * 2);
    std::thread::spawn(move || {
        assert!(
            matches!(exported.data(), mech_core::ValueData::String(value)
            if value.as_ref() == "old immutable bytes")
        );
        drop(exported);
    })
    .join()
    .unwrap();
    assert_eq!(budget.used_bytes(), bytes);
    drop(candidate);
    drop(admitted);
    assert_eq!(budget.used_bytes(), 0);
}

#[test]
fn immutable_budget_handoff_rejects_insufficient_capacity_without_consuming_it() {
    let value = detached_budget_test_value("immutable capacity failure");
    let bytes = value
        .memory_budget_admission_bytes(&mech_core::ManagedMemoryBudget::new(u64::MAX))
        .unwrap();
    let budget = mech_core::ManagedMemoryBudget::new(bytes);
    let mut admitted = budget.reserve_capacity(bytes - 1).unwrap();
    assert!(matches!(
        value.clone().into_memory_budget(&mut admitted),
        Err(MemoryRuntimeError::BudgetExceeded { requested, limit, .. })
            if requested == bytes && limit == bytes - 1
    ));
    assert_eq!(admitted.capacity_bytes(), bytes - 1);
    assert_eq!(budget.used_bytes(), bytes - 1);
    assert_eq!(value.memory_budget_retained_bytes(&budget), None);
    admitted.resize_capacity(bytes).unwrap();
    let value = value.into_memory_budget(&mut admitted).unwrap();
    assert_eq!(admitted.capacity_bytes(), 0);
    drop(admitted);
    assert_eq!(budget.used_bytes(), bytes);
    drop(value);
    assert_eq!(budget.used_bytes(), 0);
}

#[test]
fn immutable_budget_handoff_preserves_existing_physical_ticket_after_domain_close() {
    let domain = MemoryDomain::new().unwrap();
    let cell = ValueCell::from_exact_in(&domain, "owned by its frozen tree".to_owned()).unwrap();
    let snapshot = cell.snapshot().unwrap();
    let original = snapshot.clone();
    let before = domain.ledger();
    let bytes = snapshot
        .memory_budget_admission_bytes(&mech_core::ManagedMemoryBudget::new(u64::MAX))
        .unwrap();
    let retained = snapshot.memory_budget_required_bytes().unwrap();
    let budget = mech_core::ManagedMemoryBudget::new(bytes);
    let mut admitted = budget.reserve_capacity(bytes).unwrap();
    let snapshot = snapshot.into_memory_budget(&mut admitted).unwrap();
    let shared = snapshot.clone();
    assert!(snapshot.shares_retained_payload_ticket(&original));
    assert_eq!(domain.ledger(), before);
    assert_eq!(shared.memory_budget_retained_bytes(&budget), Some(retained));
    drop(cell);
    domain.close().unwrap();
    drop(domain);
    assert_eq!(budget.used_bytes(), bytes);
    assert!(matches!(shared.data(), mech_core::ValueData::String(value)
        if value.as_ref() == "owned by its frozen tree"));
    drop(snapshot);
    assert_eq!(budget.used_bytes(), bytes);
    std::thread::spawn(move || drop(shared)).join().unwrap();
    drop(admitted);
    assert_eq!(budget.used_bytes(), 0);
    assert!(
        matches!(original.data(), mech_core::ValueData::String(_)),
        "the caller's original data can outlive a released import claim"
    );
}

#[test]
fn immutable_budget_import_rollback_releases_claims_while_callers_retain_their_values() {
    let original = detached_budget_test_value("caller keeps immutable input");
    let rejected = detached_budget_test_value("a later candidate needs additional bytes");
    let account_a = mech_core::ManagedMemoryBudget::new(1_000_000);
    let mut a = account_a
        .reserve_capacity(original.memory_budget_admission_bytes(&account_a).unwrap())
        .unwrap();
    let original = original.into_memory_budget(&mut a).unwrap();
    drop(a);
    let baseline_a = account_a.used_bytes();

    let account_b = mech_core::ManagedMemoryBudget::new(1_000_000);
    let first = original.memory_budget_admission_bytes(&account_b).unwrap();
    let mut b = account_b.reserve_capacity(first).unwrap();
    let imported = original.clone().into_memory_budget(&mut b).unwrap();
    assert_eq!(b.capacity_bytes(), 0);
    assert_eq!(original.memory_budget_retained_bytes(&account_b), None);
    assert_eq!(account_a.used_bytes(), baseline_a);
    assert!(matches!(
        rejected.clone().into_memory_budget(&mut b),
        Err(MemoryRuntimeError::BudgetExceeded { .. })
    ));
    drop(imported);
    drop(b);
    assert_eq!(
        account_b.used_bytes(),
        0,
        "failed candidate import leaves no permanent account claim in caller data"
    );
    assert_eq!(account_a.used_bytes(), baseline_a);
    assert!(
        matches!(original.data(), mech_core::ValueData::String(value) if value.as_ref() == "caller keeps immutable input")
    );

    let mut retry = account_b.reserve_capacity(first).unwrap();
    let imported = original.clone().into_memory_budget(&mut retry).unwrap();
    assert_eq!(
        original.memory_budget_admission_bytes(&account_b).unwrap(),
        0
    );
    let alias = original.clone().into_memory_budget(&mut retry).unwrap();
    assert_eq!(account_b.used_bytes(), first);
    drop(imported);
    assert_eq!(account_b.used_bytes(), first);
    drop(alias);
    drop(retry);
    assert_eq!(account_b.used_bytes(), 0);
    drop(original);
    assert_eq!(account_a.used_bytes(), 0);
}

#[test]
fn immutable_budget_import_keys_schema_ownership_separately_from_shared_data() {
    let original = detached_budget_test_value("shared bytes with two schema owners");
    let schemas = original.schemas().unwrap();
    let rebound = original
        .rebind(original.schema(), original.shape(), &schemas.clone())
        .unwrap();
    // Force the distinct context path rather than the true-clone fast path.
    let copied_schemas = (*schemas).clone();
    let rebound = rebound
        .rebind(rebound.schema(), rebound.shape(), &copied_schemas)
        .unwrap();
    assert!(original.shares_frozen_storage(&rebound));
    assert!(!std::sync::Arc::ptr_eq(
        &original.schemas().unwrap(),
        &rebound.schemas().unwrap()
    ));
    let budget = mech_core::ManagedMemoryBudget::new(1_000_000);
    let first = original.memory_budget_admission_bytes(&budget).unwrap();
    let second = rebound.memory_budget_admission_bytes(&budget).unwrap();
    let mut admitted = budget.reserve_capacity(first + second).unwrap();
    let original = original.into_memory_budget(&mut admitted).unwrap();
    assert_eq!(
        rebound.memory_budget_admission_bytes(&budget).unwrap(),
        second
    );
    let rebound = rebound.into_memory_budget(&mut admitted).unwrap();
    assert_eq!(admitted.capacity_bytes(), 0);
    assert_eq!(budget.used_bytes(), first + second);
    drop(original);
    assert_eq!(budget.used_bytes(), second);
    drop(rebound);
    drop(admitted);
    assert_eq!(budget.used_bytes(), 0);
}

#[test]
fn immutable_budget_import_allocation_failures_preserve_callers_and_allow_retry() {
    for successful_steps in [0, 1] {
        let original = detached_budget_test_value("unchanged after failed owner construction");
        let budget = mech_core::ManagedMemoryBudget::new(1_000_000);
        let required = original.memory_budget_admission_bytes(&budget).unwrap();
        let mut admitted = budget.reserve_capacity(required).unwrap();
        budget.inject_snapshot_import_failure_after(successful_steps);
        assert!(matches!(
            original.clone().into_memory_budget(&mut admitted),
            Err(MemoryRuntimeError::AllocationFailed { .. })
        ));
        assert_eq!(admitted.capacity_bytes(), required);
        assert_eq!(budget.used_bytes(), required);
        assert_eq!(original.memory_budget_retained_bytes(&budget), None);
        assert_eq!(
            original.memory_budget_admission_bytes(&budget).unwrap(),
            required
        );
        drop(admitted);
        assert_eq!(budget.used_bytes(), 0);
        assert!(
            matches!(original.data(), mech_core::ValueData::String(value)
            if value.as_ref() == "unchanged after failed owner construction")
        );

        let mut retry = budget.reserve_capacity(required).unwrap();
        let imported = original.clone().into_memory_budget(&mut retry).unwrap();
        assert_eq!(retry.capacity_bytes(), 0);
        drop(imported);
        drop(retry);
        assert_eq!(budget.used_bytes(), 0);
        assert!(matches!(original.data(), mech_core::ValueData::String(_)));
    }
}

#[test]
fn plan_member_identity_validation_handles_many_zero_byte_objects_exactly() {
    const MEMBER_COUNT: u32 = 2_048;

    let domain = MemoryDomain::new().unwrap();
    let revision = domain.issue_plan_revision().unwrap();
    let allocations = (0..MEMBER_COUNT)
        .map(|id| allocation(id, 0, 0, 0, 0, MemoryLifetime::Activation, None))
        .collect::<Vec<_>>();
    let members = (0..MEMBER_COUNT)
        .map(MemoryObjectId::new)
        .collect::<Vec<_>>()
        .into_boxed_slice();
    let arenas = [ArenaPlan {
        id: MemoryArenaId::new(0),
        space: MemorySpace::Host,
        backing: ArenaBackingKind::ContiguousBytes,
        alignment: 8,
        capacity_bytes: 0,
        members,
    }];
    let reservation = domain
        .prepare_realization(runtime_plan_view(
            revision,
            &allocations,
            &arenas,
            ResourceDemand::default(),
            MemoryBudgetLimits::default(),
            &[],
        ))
        .unwrap();
    assert_eq!(reservation.reserved_bytes(), 0);

    let duplicate_domain = MemoryDomain::new().unwrap();
    let duplicate_revision = duplicate_domain.issue_plan_revision().unwrap();
    let duplicate_allocations = [allocation(0, 0, 0, 0, 0, MemoryLifetime::Activation, None)];
    let duplicate_arenas = [arena(0, ArenaBackingKind::ContiguousBytes, 0, &[0, 0])];
    assert!(matches!(
        duplicate_domain.prepare_realization(runtime_plan_view(
            duplicate_revision,
            &duplicate_allocations,
            &duplicate_arenas,
            ResourceDemand::default(),
            MemoryBudgetLimits::default(),
            &[],
        )),
        Err(MemoryRuntimeError::InvalidLayout {
            reason: "arena repeats a member object",
            ..
        })
    ));

    let duplicate_object_domain = MemoryDomain::new().unwrap();
    let duplicate_object_revision = duplicate_object_domain.issue_plan_revision().unwrap();
    let duplicate_object_allocations = [
        allocation(0, 0, 0, 0, 0, MemoryLifetime::Activation, None),
        allocation(0, 0, 0, 0, 0, MemoryLifetime::Activation, None),
    ];
    let duplicate_object_arenas = [arena(0, ArenaBackingKind::ContiguousBytes, 0, &[0])];
    assert!(matches!(
        duplicate_object_domain.prepare_realization(runtime_plan_view(
            duplicate_object_revision,
            &duplicate_object_allocations,
            &duplicate_object_arenas,
            ResourceDemand::default(),
            MemoryBudgetLimits::default(),
            &[],
        )),
        Err(MemoryRuntimeError::InvalidLayout {
            reason: "duplicate memory object id",
            ..
        })
    ));

    let duplicate_arena_domain = MemoryDomain::new().unwrap();
    let duplicate_arena_revision = duplicate_arena_domain.issue_plan_revision().unwrap();
    let duplicate_arena_allocations = [allocation(0, 0, 0, 0, 0, MemoryLifetime::Activation, None)];
    let duplicate_arena_arenas = [
        arena(0, ArenaBackingKind::ContiguousBytes, 0, &[0]),
        arena(0, ArenaBackingKind::ContiguousBytes, 0, &[]),
    ];
    assert!(matches!(
        duplicate_arena_domain.prepare_realization(runtime_plan_view(
            duplicate_arena_revision,
            &duplicate_arena_allocations,
            &duplicate_arena_arenas,
            ResourceDemand::default(),
            MemoryBudgetLimits::default(),
            &[],
        )),
        Err(MemoryRuntimeError::InvalidLayout {
            reason: "duplicate arena id",
            ..
        })
    ));

    let cross_listed_domain = MemoryDomain::new().unwrap();
    let cross_listed_revision = cross_listed_domain.issue_plan_revision().unwrap();
    let cross_listed_ledger = cross_listed_domain.ledger();
    let mut empty_index = allocation(1, 1, 0, 0, 0, MemoryLifetime::Activation, None);
    empty_index.slot = Some(mech_core::PlannedSlotKind::FixedScalar(
        mech_core::ScalarMemoryKind::Index,
    ));
    let cross_listed_allocations = [
        allocation(0, 0, 0, 8, 8, MemoryLifetime::Activation, None),
        empty_index,
    ];
    let cross_listed_arenas = [
        arena(0, ArenaBackingKind::ContiguousBytes, 8, &[0, 1]),
        arena(1, ArenaBackingKind::ContiguousBytes, 0, &[1]),
    ];
    assert!(matches!(
        cross_listed_domain.prepare_realization(runtime_plan_view(
            cross_listed_revision,
            &cross_listed_allocations,
            &cross_listed_arenas,
            ResourceDemand::default(),
            MemoryBudgetLimits::default(),
            &[],
        )),
        Err(MemoryRuntimeError::InvalidLayout {
            object: Some(object),
            reason: "memory object is listed by more than one arena",
            ..
        }) if object == MemoryObjectId::new(1)
    ));
    assert_eq!(cross_listed_domain.ledger(), cross_listed_ledger);

    let wrong_arena_domain = MemoryDomain::new().unwrap();
    let wrong_arena_revision = wrong_arena_domain.issue_plan_revision().unwrap();
    let wrong_arena_ledger = wrong_arena_domain.ledger();
    let wrong_arena_allocations = [allocation(0, 1, 0, 0, 0, MemoryLifetime::Activation, None)];
    let wrong_arena_arenas = [
        arena(0, ArenaBackingKind::ContiguousBytes, 0, &[0]),
        arena(1, ArenaBackingKind::ContiguousBytes, 0, &[]),
    ];
    assert!(matches!(
        wrong_arena_domain.prepare_realization(runtime_plan_view(
            wrong_arena_revision,
            &wrong_arena_allocations,
            &wrong_arena_arenas,
            ResourceDemand::default(),
            MemoryBudgetLimits::default(),
            &[],
        )),
        Err(MemoryRuntimeError::InvalidLayout {
            object: Some(object),
            reason: "allocation is absent from its arena member list",
            ..
        }) if object == MemoryObjectId::new(0)
    ));
    assert_eq!(wrong_arena_domain.ledger(), wrong_arena_ledger);

    let nonadjacent_domain = MemoryDomain::new().unwrap();
    let nonadjacent_revision = nonadjacent_domain.issue_plan_revision().unwrap();
    let nonadjacent_ledger = nonadjacent_domain.ledger();
    let nonadjacent_allocations = [
        allocation(0, 0, 0, 0, 0, MemoryLifetime::Activation, None),
        allocation(1, 1, 0, 0, 0, MemoryLifetime::Activation, None),
        allocation(2, 1, 0, 0, 0, MemoryLifetime::Activation, None),
    ];
    let nonadjacent_arenas = [
        arena(0, ArenaBackingKind::ContiguousBytes, 0, &[0, 2]),
        arena(1, ArenaBackingKind::ContiguousBytes, 0, &[1, 2]),
    ];
    assert!(matches!(
        nonadjacent_domain.prepare_realization(runtime_plan_view(
            nonadjacent_revision,
            &nonadjacent_allocations,
            &nonadjacent_arenas,
            ResourceDemand::default(),
            MemoryBudgetLimits::default(),
            &[],
        )),
        Err(MemoryRuntimeError::InvalidLayout {
            object: Some(object),
            reason: "memory object is listed by more than one arena",
            ..
        }) if object == MemoryObjectId::new(2)
    ));
    assert_eq!(nonadjacent_domain.ledger(), nonadjacent_ledger);
}

#[test]
fn construction_workspace_is_reserved_without_a_duplicate_host_block() {
    let domain = MemoryDomain::new().unwrap();
    let revision = domain.issue_plan_revision().unwrap();
    let mut workspace = allocation(
        0,
        0,
        0,
        64 * 1024,
        64 * 1024,
        MemoryLifetime::Turn {
            first: MemoryPlanPoint::new(0),
            last: MemoryPlanPoint::new(0),
        },
        None,
    );
    workspace.role = AllocationRole::ConstructionWorkspace;
    workspace.slot = None;
    workspace.alignment = 1;
    let arenas = [arena(
        0,
        ArenaBackingKind::ReservationOnlyWorkspace,
        workspace.capacity_bytes,
        &[0],
    )];
    let realized = domain
        .materialize(
            domain
                .prepare_realization(runtime_plan_view(
                    revision,
                    &[workspace.clone()],
                    &arenas,
                    ResourceDemand {
                        turn_peak_bytes: workspace.capacity_bytes,
                        ..ResourceDemand::default()
                    },
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    let object = domain
        .plan_object_key(revision, MemoryObjectId::new(0))
        .unwrap();
    assert!(matches!(
        realized.binding(object).unwrap(),
        RuntimeBinding::ReservationOnly {
            capacity_bytes: 65_536,
            ..
        }
    ));
    let observations = domain.allocation_observations();
    assert_eq!(observations.len(), 1);
    assert_eq!(observations[0].capacity_bytes, 65_536);
    assert_eq!(observations[0].actual_block_bytes, 0);
}

#[test]
fn construction_workspace_role_and_reservation_backing_are_a_sealed_pair() {
    let construction_domain = MemoryDomain::new().unwrap();
    let construction_revision = construction_domain.issue_plan_revision().unwrap();
    let mut construction = allocation(0, 0, 0, 4_096, 4_096, MemoryLifetime::Activation, None);
    construction.role = AllocationRole::ConstructionWorkspace;
    construction.slot = None;
    construction.alignment = 1;
    assert!(matches!(
        construction_domain.prepare_realization(runtime_plan_view(
            construction_revision,
            &[construction],
            &[arena(0, ArenaBackingKind::ContiguousBytes, 4_096, &[0])],
            ResourceDemand::default(),
            MemoryBudgetLimits::default(),
            &[],
        )),
        Err(MemoryRuntimeError::InvalidLayout { .. })
    ));
    assert_eq!(construction_domain.ledger(), Default::default());

    let storage_domain = MemoryDomain::new().unwrap();
    let storage_revision = storage_domain.issue_plan_revision().unwrap();
    let mut storage = allocation(0, 0, 0, 4_096, 4_096, MemoryLifetime::Activation, None);
    storage.slot = None;
    storage.alignment = 1;
    assert!(matches!(
        storage_domain.prepare_realization(runtime_plan_view(
            storage_revision,
            &[storage],
            &[arena(
                0,
                ArenaBackingKind::ReservationOnlyWorkspace,
                4_096,
                &[0],
            )],
            ResourceDemand::default(),
            MemoryBudgetLimits::default(),
            &[],
        )),
        Err(MemoryRuntimeError::InvalidLayout { .. })
    ));
    assert_eq!(storage_domain.ledger(), Default::default());
}

#[test]
fn realization_recomputes_budget_instead_of_trusting_cached_violations() {
    let domain = MemoryDomain::new().unwrap();
    let revision = domain.issue_plan_revision().unwrap();
    let allocations = [allocation(0, 0, 0, 0, 8, MemoryLifetime::Activation, None)];
    let arenas = [arena(0, ArenaBackingKind::ContiguousBytes, 8, &[0])];
    let demand = ResourceDemand {
        turn_peak_bytes: 17,
        ..ResourceDemand::default()
    };
    let limits = MemoryBudgetLimits {
        max_temporary_bytes: Some(16),
        ..MemoryBudgetLimits::default()
    };

    assert!(matches!(
        domain.prepare_realization(runtime_plan_view(
            revision,
            &allocations,
            &arenas,
            demand,
            limits,
            &[],
        )),
        Err(MemoryRuntimeError::BudgetExceeded {
            requested: 17,
            limit: 16,
            ..
        })
    ));
    assert_eq!(domain.ledger().reserved_bytes, 0);
    assert_eq!(domain.ledger().active_reservations, 0);
}

#[test]
fn realization_rejects_underreported_temporary_allocations_before_reservation() {
    for lifetime in [
        MemoryLifetime::Turn {
            first: MemoryPlanPoint::new(0),
            last: MemoryPlanPoint::new(1),
        },
        MemoryLifetime::Transaction {
            first: MemoryPlanPoint::new(0),
            last: MemoryPlanPoint::new(1),
        },
        MemoryLifetime::Transfer {
            first: MemoryPlanPoint::new(0),
            last: MemoryPlanPoint::new(1),
        },
    ] {
        for backing in [
            ArenaBackingKind::ContiguousBytes,
            ArenaBackingKind::IndirectOwnedPayloads,
            ArenaBackingKind::ReservationOnlyWorkspace,
        ] {
            let domain = MemoryDomain::new().unwrap();
            let revision = domain.issue_plan_revision().unwrap();
            // Required capacity is charged before initialization, including
            // indirect payloads and deferred construction workspace.
            let mut temporary = allocation(0, 0, 0, 0, 1_024, lifetime, None);
            temporary.role = AllocationRole::Scratch;
            match backing {
                ArenaBackingKind::ContiguousBytes => {}
                ArenaBackingKind::IndirectOwnedPayloads => {
                    temporary.role = AllocationRole::VariablePayload;
                    temporary.slot = None;
                    temporary.payload_block_capacity = 1;
                }
                ArenaBackingKind::ReservationOnlyWorkspace => {
                    temporary.role = AllocationRole::ConstructionWorkspace;
                    temporary.slot = None;
                }
            }
            assert!(matches!(
                domain.prepare_realization(runtime_plan_view(
                    revision,
                    &[temporary],
                    &[arena(0, backing, 1_024, &[0])],
                    ResourceDemand::default(),
                    MemoryBudgetLimits {
                        max_temporary_bytes: Some(0),
                        ..Default::default()
                    },
                    &[],
                )),
                Err(MemoryRuntimeError::BudgetExceeded {
                    requested: 1_024,
                    limit: 0,
                    ..
                })
            ));
            assert_eq!(domain.ledger(), Default::default());
            assert!(domain.allocation_observations().is_empty());
        }
    }
}

#[test]
fn temporary_budget_checks_closed_lifetime_peaks_and_disjoint_reuse() {
    for (first_last, second_first, reuse, limit, admitted) in [
        (1, 1, false, 127, false),
        (1, 1, false, 128, true),
        (0, 1, true, 64, true),
    ] {
        let domain = MemoryDomain::new().unwrap();
        let revision = domain.issue_plan_revision().unwrap();
        let reuse_group = reuse.then_some(0);
        let allocations = [
            allocation(
                0,
                0,
                0,
                0,
                64,
                MemoryLifetime::Turn {
                    first: MemoryPlanPoint::new(0),
                    last: MemoryPlanPoint::new(first_last),
                },
                reuse_group,
            ),
            allocation(
                1,
                0,
                if reuse { 0 } else { 64 },
                0,
                64,
                MemoryLifetime::Transaction {
                    first: MemoryPlanPoint::new(second_first),
                    last: MemoryPlanPoint::new(2),
                },
                reuse_group,
            ),
            // Retained instance storage is governed by its own lifetime,
            // even when it shares the same physical arena.
            allocation(2, 0, 128, 64, 64, MemoryLifetime::Activation, None),
        ];
        let result = domain.prepare_realization(runtime_plan_view(
            revision,
            &allocations,
            &[arena(0, ArenaBackingKind::ContiguousBytes, 192, &[0, 1, 2])],
            ResourceDemand::default(),
            MemoryBudgetLimits {
                max_temporary_bytes: Some(limit),
                ..Default::default()
            },
            &[],
        ));
        if admitted {
            let realized = domain.materialize(result.unwrap()).unwrap();
            assert!(
                realized
                    .bindings()
                    .iter()
                    .all(|(_, binding)| binding.handle().is_some())
            );
        } else {
            assert!(matches!(
                result,
                Err(MemoryRuntimeError::BudgetExceeded {
                    requested: 128,
                    limit: 127,
                    ..
                })
            ));
            assert_eq!(domain.ledger(), Default::default());
        }
    }
}

#[test]
fn temporary_budget_rejects_reversed_lifetimes_and_overflow_without_reserving() {
    for reversed in [true, false] {
        let domain = MemoryDomain::new().unwrap();
        let revision = domain.issue_plan_revision().unwrap();
        let capacity = if reversed { 8 } else { 1_u64 << 63 };
        let allocations = [
            allocation(
                0,
                0,
                0,
                0,
                capacity,
                MemoryLifetime::Turn {
                    first: MemoryPlanPoint::new(if reversed { 2 } else { 0 }),
                    last: MemoryPlanPoint::new(1),
                },
                None,
            ),
            allocation(
                1,
                1,
                0,
                0,
                capacity,
                MemoryLifetime::Turn {
                    first: MemoryPlanPoint::new(0),
                    last: MemoryPlanPoint::new(1),
                },
                None,
            ),
        ];
        let result = domain.prepare_realization(runtime_plan_view(
            revision,
            &allocations,
            &[
                arena(0, ArenaBackingKind::ContiguousBytes, capacity, &[0]),
                arena(1, ArenaBackingKind::ContiguousBytes, capacity, &[1]),
            ],
            ResourceDemand::default(),
            MemoryBudgetLimits {
                max_temporary_bytes: Some(u64::MAX),
                ..Default::default()
            },
            &[],
        ));
        if reversed {
            assert!(matches!(
                result,
                Err(MemoryRuntimeError::InvalidLifetimeTransition { .. })
            ));
        } else {
            assert!(matches!(
                result,
                Err(MemoryRuntimeError::AccountingInvariantViolation { .. })
            ));
        }
        assert_eq!(domain.ledger(), Default::default());
        assert!(domain.allocation_observations().is_empty());
    }
}

#[test]
fn realization_tracks_initialization_and_scoped_access() {
    let domain = MemoryDomain::new().unwrap();
    let revision = domain.issue_plan_revision().unwrap();
    let allocations = [allocation(0, 0, 0, 8, 64, MemoryLifetime::Activation, None)];
    let arenas = [arena(0, ArenaBackingKind::ContiguousBytes, 64, &[0])];
    let reservation = domain
        .prepare_realization(runtime_plan_view(
            revision,
            &allocations,
            &arenas,
            ResourceDemand::default(),
            MemoryBudgetLimits::default(),
            &[],
        ))
        .unwrap();
    let realized = domain.materialize(reservation).unwrap();
    let key = domain
        .plan_object_key(revision, MemoryObjectId::new(0))
        .unwrap();
    let binding = realized.binding(key).unwrap();
    assert_eq!(binding.required_initialization_bytes(), 8);
    assert_eq!(binding.initialized_bytes(), 0);
    let unreadable = domain.prepare_call(
        &realized,
        &[CallAccessRequest {
            object: key,
            mode: MemoryAccessMode::Read,
            region: MemoryAccessRegion::Contiguous {
                offset_bytes: 0,
                length_bytes: 8,
            },
        }],
    );
    assert!(matches!(
        unreadable,
        Err(MemoryRuntimeError::UninitializedAccess { .. })
    ));

    let write = domain
        .prepare_call(
            &realized,
            &[CallAccessRequest {
                object: key,
                mode: MemoryAccessMode::Write,
                region: MemoryAccessRegion::Contiguous {
                    offset_bytes: 0,
                    length_bytes: 8,
                },
            }],
        )
        .unwrap();
    domain
        .acquire_call(&realized, &write)
        .unwrap()
        .with_object_init_writer::<u64>(key, |writer| writer.write_next(42))
        .unwrap();
    assert_eq!(realized.binding(key).unwrap().initialized_bytes(), 8);

    let read = domain
        .prepare_call(
            &realized,
            &[CallAccessRequest {
                object: key,
                mode: MemoryAccessMode::Read,
                region: MemoryAccessRegion::WholeInitialized,
            }],
        )
        .unwrap();
    let frame = domain.acquire_call(&realized, &read).unwrap();
    let value = frame
        .with_bytes(key, |bytes| u64::from_ne_bytes(bytes.try_into().unwrap()))
        .unwrap();
    assert_eq!(value, 42);

    let observations = domain.allocation_observations();
    assert_eq!(observations.len(), 1);
    assert_eq!(observations[0].capacity_bytes, 64);
    assert_eq!(observations[0].actual_block_bytes, 64);
    assert!(observations[0].actual_block_alignment >= 8);
}

#[test]
fn logical_managed_ports_resolve_only_inside_the_prepared_lease_scope() {
    let cell = ValueCell::from_exact(0_u64).unwrap();
    let clone = cell.clone();
    let invocation = FunctionInvocation::nullary(cell.clone());
    let port = invocation.output().try_managed::<u64>().unwrap();
    assert_eq!(port.logical_cell_id(), cell.reactive_cell_id());

    let domain = MemoryDomain::new().unwrap();
    let revision = domain.issue_plan_revision().unwrap();
    let allocations = [allocation(0, 0, 0, 0, 8, MemoryLifetime::Activation, None)];
    let arenas = [arena(0, ArenaBackingKind::ContiguousBytes, 8, &[0])];
    let realized = domain
        .materialize(
            domain
                .prepare_realization(runtime_plan_view(
                    revision,
                    &allocations,
                    &arenas,
                    ResourceDemand::default(),
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    let object = domain
        .plan_object_key(revision, MemoryObjectId::new(0))
        .unwrap();
    let prepared = domain
        .prepare_managed_call(
            &realized,
            &[ManagedCallAccessRequest::new(
                &port,
                object,
                MemoryAccessMode::Write,
                MemoryAccessRegion::Contiguous {
                    offset_bytes: 0,
                    length_bytes: 8,
                },
            )],
        )
        .unwrap();
    let mut frame = domain.acquire_call(&realized, &prepared).unwrap();
    frame
        .with_port_init_writer(&port, |writer| writer.write_next(17))
        .unwrap();
    drop(frame);

    let prepared = domain
        .prepare_managed_call(
            &realized,
            &[ManagedCallAccessRequest::new(
                &port,
                object,
                MemoryAccessMode::Read,
                MemoryAccessRegion::WholeInitialized,
            )],
        )
        .unwrap();
    let frame = domain.acquire_call(&realized, &prepared).unwrap();
    assert_eq!(
        frame.with_port_slice(&port, |values| values[0]).unwrap(),
        17
    );
    assert!(cell.same_logical_cell(&clone));
}

#[test]
fn value_cell_clones_share_shape_storage_and_publication_version() {
    let cell = ValueCell::dynamic_matrix(
        mech_core::SchemaBody::FloatingPoint(mech_core::FloatWidth::W64),
        vec![1, 2].into_boxed_slice(),
        vec![
            mech_core::ValueDataDraft::F64(F64Bits::from_f64(1.0)),
            mech_core::ValueDataDraft::F64(F64Bits::from_f64(2.0)),
        ]
        .into_boxed_slice(),
    )
    .unwrap();
    let clone = cell.clone();
    let initial_version = cell.published_version();
    let replacement = ValueCell::dynamic_matrix(
        mech_core::SchemaBody::FloatingPoint(mech_core::FloatWidth::W64),
        vec![2, 2].into_boxed_slice(),
        vec![
            mech_core::ValueDataDraft::F64(F64Bits::from_f64(3.0)),
            mech_core::ValueDataDraft::F64(F64Bits::from_f64(4.0)),
            mech_core::ValueDataDraft::F64(F64Bits::from_f64(5.0)),
            mech_core::ValueDataDraft::F64(F64Bits::from_f64(6.0)),
        ]
        .into_boxed_slice(),
    )
    .unwrap()
    .snapshot()
    .unwrap();

    cell.replace(&replacement).unwrap();
    assert!(cell.same_logical_cell(&clone));
    assert_eq!(
        clone.snapshot().unwrap().canonical_data_draft().unwrap(),
        replacement.canonical_data_draft().unwrap(),
    );
    assert_eq!(clone.shape().parameter_values(), &[2, 2]);
    assert!(clone.published_version() > initial_version);
}

#[test]
fn managed_function_entry_executes_only_through_its_complete_frame() {
    struct Double {
        input: ManagedPort<u64>,
        output: ManagedPort<u64>,
    }

    impl MechFunctionImpl for Double {
        fn solve_managed(
            &self,
            frame: &mut KernelMemoryFrame<'_>,
            _: &mut dyn MechExecutionServices,
        ) -> mech_core::MResult<ReactiveSolveStatus> {
            let value = frame.with_port_slice(&self.input, |values| values[0])?;
            frame.with_port_init_writer(&self.output, |writer| writer.write_next(value * 2))?;
            Ok(ReactiveSolveStatus::Changed)
        }

        fn to_string(&self) -> String {
            "managed low-level double kernel".into()
        }
    }

    let input_cell = ValueCell::from_exact(0_u64).unwrap();
    let output_cell = ValueCell::from_exact(0_u64).unwrap();
    let invocation = FunctionInvocation::unary(output_cell, input_cell);
    let input = invocation.input(0).unwrap().try_managed::<u64>().unwrap();
    let output = invocation.output().try_managed::<u64>().unwrap();
    let function = Double {
        input: input.clone(),
        output: output.clone(),
    };

    let domain = MemoryDomain::new().unwrap();
    let revision = domain.issue_plan_revision().unwrap();
    let allocations = [
        allocation(0, 0, 0, 0, 8, MemoryLifetime::Activation, None),
        allocation(1, 0, 8, 0, 8, MemoryLifetime::Activation, None),
    ];
    let arenas = [arena(0, ArenaBackingKind::ContiguousBytes, 16, &[0, 1])];
    let realized = domain
        .materialize(
            domain
                .prepare_realization(runtime_plan_view(
                    revision,
                    &allocations,
                    &arenas,
                    ResourceDemand::default(),
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    let input_object = domain
        .plan_object_key(revision, MemoryObjectId::new(0))
        .unwrap();
    let output_object = domain
        .plan_object_key(revision, MemoryObjectId::new(1))
        .unwrap();
    let initialize = domain
        .prepare_managed_call(
            &realized,
            &[ManagedCallAccessRequest::new(
                &input,
                input_object,
                MemoryAccessMode::Write,
                MemoryAccessRegion::Contiguous {
                    offset_bytes: 0,
                    length_bytes: 8,
                },
            )],
        )
        .unwrap();
    domain
        .acquire_call(&realized, &initialize)
        .unwrap()
        .with_port_init_writer(&input, |writer| writer.write_next(21))
        .unwrap();
    let prepared = domain
        .prepare_managed_call(
            &realized,
            &[
                ManagedCallAccessRequest::new(
                    &input,
                    input_object,
                    MemoryAccessMode::Read,
                    MemoryAccessRegion::WholeInitialized,
                ),
                ManagedCallAccessRequest::new(
                    &output,
                    output_object,
                    MemoryAccessMode::Write,
                    MemoryAccessRegion::Contiguous {
                        offset_bytes: 0,
                        length_bytes: 8,
                    },
                ),
            ],
        )
        .unwrap();
    let mut frame = domain.acquire_call(&realized, &prepared).unwrap();
    let mut services = NoMechExecutionServices;
    assert_eq!(
        function.solve_managed(&mut frame, &mut services).unwrap(),
        ReactiveSolveStatus::Changed,
    );
    drop(frame);
    let read = domain
        .prepare_managed_call(
            &realized,
            &[ManagedCallAccessRequest::new(
                &output,
                output_object,
                MemoryAccessMode::Read,
                MemoryAccessRegion::WholeInitialized,
            )],
        )
        .unwrap();
    assert_eq!(
        domain
            .acquire_call(&realized, &read)
            .unwrap()
            .with_port_slice(&output, |values| values[0])
            .unwrap(),
        42,
    );
}

#[test]
fn low_level_matrix_object_remapping_preserves_admission_and_reclamation() {
    struct Sum {
        input: ManagedPort<f64>,
        output: ManagedPort<f64>,
    }

    impl MechFunctionImpl for Sum {
        fn solve_managed(
            &self,
            frame: &mut KernelMemoryFrame<'_>,
            _: &mut dyn MechExecutionServices,
        ) -> mech_core::MResult<ReactiveSolveStatus> {
            let sum = frame.with_port_slice(&self.input, |values| values.iter().sum::<f64>())?;
            frame.with_port_init_writer(&self.output, |writer| writer.write_next(sum))?;
            Ok(ReactiveSolveStatus::Changed)
        }

        fn to_string(&self) -> String {
            "managed low-level sum kernel".into()
        }
    }

    let matrix = ValueCell::dynamic_matrix(
        mech_core::SchemaBody::FloatingPoint(mech_core::FloatWidth::W64),
        vec![1, 2].into_boxed_slice(),
        vec![
            mech_core::ValueDataDraft::F64(F64Bits::from_f64(1.0)),
            mech_core::ValueDataDraft::F64(F64Bits::from_f64(2.0)),
        ]
        .into_boxed_slice(),
    )
    .unwrap();
    let matrix_clone = matrix.clone();
    let output_cell = ValueCell::from_exact(0.0_f64).unwrap();
    let invocation = FunctionInvocation::unary(output_cell, matrix.clone());
    let input = invocation
        .input(0)
        .unwrap()
        .try_managed_matrix::<f64>()
        .unwrap();
    let output = invocation.output().try_managed::<f64>().unwrap();
    let function = Sum {
        input: input.clone(),
        output: output.clone(),
    };

    let domain = MemoryDomain::new().unwrap();
    let initial_revision = domain.issue_plan_revision().unwrap();
    let initial_allocations = [
        f64_allocation(0, 0, 0, 16, 16, MemoryLifetime::Activation),
        f64_allocation(1, 0, 16, 0, 8, MemoryLifetime::Activation),
    ];
    let initial_arenas = [arena(0, ArenaBackingKind::ContiguousBytes, 24, &[0, 1])];
    let initial = domain
        .materialize(
            domain
                .prepare_realization(runtime_plan_view(
                    initial_revision,
                    &initial_allocations,
                    &initial_arenas,
                    ResourceDemand::default(),
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    let initial_input = domain
        .plan_object_key(initial_revision, MemoryObjectId::new(0))
        .unwrap();
    let initial_output = domain
        .plan_object_key(initial_revision, MemoryObjectId::new(1))
        .unwrap();
    initialize_managed_f64(&domain, &initial, &input, initial_input, &[1.0, 2.0]);
    assert_eq!(
        execute_sum(
            &domain,
            &initial,
            &function,
            &input,
            initial_input,
            &output,
            initial_output,
        ),
        3.0,
    );
    let initial_handle = initial.binding(initial_input).unwrap().handle().unwrap();

    let grown_revision = domain.issue_plan_revision().unwrap();
    let grown_allocations = [
        f64_allocation(0, 1, 0, 32, 32, MemoryLifetime::Activation),
        f64_allocation(1, 1, 32, 0, 8, MemoryLifetime::Activation),
    ];
    let grown_arenas = [arena(1, ArenaBackingKind::ContiguousBytes, 40, &[0, 1])];
    let grown = domain
        .materialize(
            domain
                .prepare_realization(runtime_plan_view(
                    grown_revision,
                    &grown_allocations,
                    &grown_arenas,
                    ResourceDemand::default(),
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    domain.activate_realization(&grown).unwrap();
    let grown_input = domain
        .plan_object_key(grown_revision, MemoryObjectId::new(0))
        .unwrap();
    let grown_output = domain
        .plan_object_key(grown_revision, MemoryObjectId::new(1))
        .unwrap();
    let grown_handle = grown.binding(grown_input).unwrap().handle().unwrap();
    assert_ne!(initial_handle, grown_handle);
    initialize_managed_f64(&domain, &grown, &input, grown_input, &[1.0, 2.0, 3.0, 4.0]);
    let replacement = ValueCell::dynamic_matrix(
        mech_core::SchemaBody::FloatingPoint(mech_core::FloatWidth::W64),
        vec![2, 2].into_boxed_slice(),
        [1.0, 2.0, 3.0, 4.0]
            .into_iter()
            .map(|value| mech_core::ValueDataDraft::F64(F64Bits::from_f64(value)))
            .collect::<Vec<_>>()
            .into_boxed_slice(),
    )
    .unwrap()
    .snapshot()
    .unwrap();
    matrix.replace(&replacement).unwrap();
    assert_eq!(matrix_clone.shape().parameter_values(), &[2, 2]);
    assert_eq!(
        execute_sum(
            &domain,
            &grown,
            &function,
            &input,
            grown_input,
            &output,
            grown_output,
        ),
        10.0,
    );

    domain.retire(initial_handle).unwrap();
    let initial_output_handle = initial.binding(initial_output).unwrap().handle().unwrap();
    if initial_output_handle != initial_handle {
        domain.retire(initial_output_handle).unwrap();
    }
    assert_eq!(domain.collect_retired().unwrap(), 0);
    drop(initial);
    assert_eq!(domain.collect_retired().unwrap(), 1);

    let before_failed_growth = matrix_clone.snapshot().unwrap();
    let rejected_revision = domain.issue_plan_revision().unwrap();
    let rejected_allocations = [allocation(
        0,
        2,
        0,
        80,
        80,
        MemoryLifetime::Activation,
        None,
    )];
    let rejected_arenas = [arena(2, ArenaBackingKind::ContiguousBytes, 80, &[0])];
    let limits = MemoryBudgetLimits {
        max_storage_buffer_bytes: Some(64),
        ..MemoryBudgetLimits::default()
    };
    assert!(matches!(
        domain.prepare_realization(runtime_plan_view(
            rejected_revision,
            &rejected_allocations,
            &rejected_arenas,
            ResourceDemand::default(),
            limits,
            &[],
        )),
        Err(MemoryRuntimeError::BudgetExceeded { .. })
    ));
    assert_eq!(
        matrix_clone
            .snapshot()
            .unwrap()
            .canonical_data_draft()
            .unwrap(),
        before_failed_growth.canonical_data_draft().unwrap(),
    );
}

fn initialize_managed_f64(
    domain: &MemoryDomain,
    realized: &mech_core::RealizedMemoryPlan,
    port: &ManagedPort<f64>,
    object: mech_core::PlanObjectKey,
    values: &[f64],
) {
    let bytes = (values.len() * core::mem::size_of::<f64>()) as u64;
    let prepared = domain
        .prepare_managed_call(
            realized,
            &[ManagedCallAccessRequest::new(
                port,
                object,
                MemoryAccessMode::Write,
                MemoryAccessRegion::Contiguous {
                    offset_bytes: 0,
                    length_bytes: bytes,
                },
            )],
        )
        .unwrap();
    domain
        .acquire_call(realized, &prepared)
        .unwrap()
        .with_port_init_writer(port, |writer| writer.copy_from_slice(values))
        .unwrap();
}

fn execute_sum(
    domain: &MemoryDomain,
    realized: &mech_core::RealizedMemoryPlan,
    function: &impl MechFunctionImpl,
    input: &ManagedPort<f64>,
    input_object: mech_core::PlanObjectKey,
    output: &ManagedPort<f64>,
    output_object: mech_core::PlanObjectKey,
) -> f64 {
    let prepared = domain
        .prepare_managed_call(
            realized,
            &[
                ManagedCallAccessRequest::new(
                    input,
                    input_object,
                    MemoryAccessMode::Read,
                    MemoryAccessRegion::WholeInitialized,
                ),
                ManagedCallAccessRequest::new(
                    output,
                    output_object,
                    MemoryAccessMode::Write,
                    MemoryAccessRegion::Contiguous {
                        offset_bytes: 0,
                        length_bytes: 8,
                    },
                ),
            ],
        )
        .unwrap();
    let mut frame = domain.acquire_call(realized, &prepared).unwrap();
    function
        .solve_managed(&mut frame, &mut NoMechExecutionServices)
        .unwrap();
    drop(frame);
    let read = domain
        .prepare_managed_call(
            realized,
            &[ManagedCallAccessRequest::new(
                output,
                output_object,
                MemoryAccessMode::Read,
                MemoryAccessRegion::WholeInitialized,
            )],
        )
        .unwrap();
    domain
        .acquire_call(realized, &read)
        .unwrap()
        .with_port_slice(output, |values| values[0])
        .unwrap()
}

#[test]
fn lease_acquisition_is_atomic_and_region_aware() {
    let domain = MemoryDomain::new().unwrap();
    let revision = domain.issue_plan_revision().unwrap();
    let allocations = [
        allocation(0, 0, 0, 0, 8, MemoryLifetime::Activation, None),
        allocation(1, 0, 8, 0, 8, MemoryLifetime::Activation, None),
    ];
    let arenas = [arena(0, ArenaBackingKind::ContiguousBytes, 16, &[0, 1])];
    let realized = domain
        .materialize(
            domain
                .prepare_realization(runtime_plan_view(
                    revision,
                    &allocations,
                    &arenas,
                    ResourceDemand::default(),
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    let left = domain
        .plan_object_key(revision, MemoryObjectId::new(0))
        .unwrap();
    let right = domain
        .plan_object_key(revision, MemoryObjectId::new(1))
        .unwrap();
    for key in [left, right] {
        let write = domain
            .prepare_call(
                &realized,
                &[CallAccessRequest {
                    object: key,
                    mode: MemoryAccessMode::Write,
                    region: MemoryAccessRegion::Contiguous {
                        offset_bytes: 0,
                        length_bytes: 8,
                    },
                }],
            )
            .unwrap();
        domain
            .acquire_call(&realized, &write)
            .unwrap()
            .with_object_init_writer::<u64>(key, |writer| {
                writer.write_next(u64::from(key.object().get()))
            })
            .unwrap();
    }

    let left_read = domain
        .prepare_call(
            &realized,
            &[CallAccessRequest {
                object: left,
                mode: MemoryAccessMode::Read,
                region: MemoryAccessRegion::WholeInitialized,
            }],
        )
        .unwrap();
    let reader_one = domain.acquire_call(&realized, &left_read).unwrap();
    let left_read_two = domain
        .prepare_call(
            &realized,
            &[CallAccessRequest {
                object: left,
                mode: MemoryAccessMode::Read,
                region: MemoryAccessRegion::WholeInitialized,
            }],
        )
        .unwrap();
    let reader_two = domain.acquire_call(&realized, &left_read_two).unwrap();
    let left_write = domain
        .prepare_call(
            &realized,
            &[CallAccessRequest {
                object: left,
                mode: MemoryAccessMode::Write,
                region: MemoryAccessRegion::WholeInitialized,
            }],
        )
        .unwrap();
    assert!(matches!(
        domain.acquire_call(&realized, &left_write),
        Err(MemoryRuntimeError::BorrowConflict { .. })
    ));
    let right_write = domain
        .prepare_call(
            &realized,
            &[CallAccessRequest {
                object: right,
                mode: MemoryAccessMode::Write,
                region: MemoryAccessRegion::WholeInitialized,
            }],
        )
        .unwrap();
    assert!(domain.acquire_call(&realized, &right_write).is_ok());
    drop(reader_two);
    drop(reader_one);
    assert!(domain.acquire_call(&realized, &left_write).is_ok());

    let gap = MemoryAccessRegion::Contiguous {
        offset_bytes: 4,
        length_bytes: 4,
    };
    let empty_domain = MemoryDomain::new().unwrap();
    let empty_revision = empty_domain.issue_plan_revision().unwrap();
    let mut empty_allocation = allocation(0, 0, 0, 0, 8, MemoryLifetime::Activation, None);
    empty_allocation.slot = None;
    let empty_realized = empty_domain
        .materialize(
            empty_domain
                .prepare_realization(runtime_plan_view(
                    empty_revision,
                    &[empty_allocation],
                    &[arena(0, ArenaBackingKind::ContiguousBytes, 8, &[0])],
                    ResourceDemand::default(),
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    let empty_key = empty_domain
        .plan_object_key(empty_revision, MemoryObjectId::new(0))
        .unwrap();
    let gap_write = empty_domain
        .prepare_call(
            &empty_realized,
            &[CallAccessRequest {
                object: empty_key,
                mode: MemoryAccessMode::Write,
                region: gap,
            }],
        )
        .unwrap();
    let mut frame = empty_domain
        .acquire_call(&empty_realized, &gap_write)
        .unwrap();
    assert!(matches!(
        frame.with_bytes_mut(empty_key, |_| ()),
        Err(MemoryRuntimeError::UninitializedAccess { .. })
    ));
}

#[test]
fn overlapping_regions_require_a_disjoint_lifetime_reuse_group() {
    let domain = MemoryDomain::new().unwrap();
    let revision = domain.issue_plan_revision().unwrap();
    let mut allocations = [
        allocation(
            0,
            0,
            0,
            0,
            32,
            MemoryLifetime::Turn {
                first: MemoryPlanPoint::new(0),
                last: MemoryPlanPoint::new(1),
            },
            Some(3),
        ),
        allocation(
            1,
            0,
            0,
            0,
            32,
            MemoryLifetime::Turn {
                first: MemoryPlanPoint::new(2),
                last: MemoryPlanPoint::new(3),
            },
            Some(3),
        ),
    ];
    for allocation in &mut allocations {
        allocation.slot = None;
    }
    let arenas = [arena(0, ArenaBackingKind::ContiguousBytes, 32, &[0, 1])];
    assert!(
        domain
            .prepare_realization(runtime_plan_view(
                revision,
                &allocations,
                &arenas,
                ResourceDemand::default(),
                MemoryBudgetLimits::default(),
                &[],
            ))
            .is_ok()
    );

    let invalid_domain = MemoryDomain::new().unwrap();
    let invalid_revision = invalid_domain.issue_plan_revision().unwrap();
    let mut invalid = allocations;
    invalid[1].lifetime = MemoryLifetime::Turn {
        first: MemoryPlanPoint::new(1),
        last: MemoryPlanPoint::new(2),
    };
    assert!(matches!(
        invalid_domain.prepare_realization(runtime_plan_view(
            invalid_revision,
            &invalid,
            &arenas,
            ResourceDemand::default(),
            MemoryBudgetLimits::default(),
            &[],
        )),
        Err(MemoryRuntimeError::InvalidReuse { .. })
    ));
}

#[test]
fn reused_regions_are_leaseable_only_during_their_declared_plan_interval() {
    let domain = MemoryDomain::new().unwrap();
    let revision = domain.issue_plan_revision().unwrap();
    let mut allocations = [
        allocation(
            0,
            0,
            0,
            0,
            16,
            MemoryLifetime::Turn {
                first: MemoryPlanPoint::new(0),
                last: MemoryPlanPoint::new(1),
            },
            Some(7),
        ),
        allocation(
            1,
            0,
            0,
            0,
            16,
            MemoryLifetime::Turn {
                first: MemoryPlanPoint::new(2),
                last: MemoryPlanPoint::new(3),
            },
            Some(7),
        ),
    ];
    for allocation in &mut allocations {
        allocation.slot = None;
    }
    let arenas = [arena(0, ArenaBackingKind::ContiguousBytes, 16, &[0, 1])];
    let realized = domain
        .materialize(
            domain
                .prepare_realization(runtime_plan_view(
                    revision,
                    &allocations,
                    &arenas,
                    ResourceDemand::default(),
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    let first = domain
        .plan_object_key(revision, MemoryObjectId::new(0))
        .unwrap();
    let second = domain
        .plan_object_key(revision, MemoryObjectId::new(1))
        .unwrap();
    assert_eq!(
        realized.binding(first).unwrap().handle(),
        realized.binding(second).unwrap().handle()
    );

    let prepare_write = |object| {
        domain
            .prepare_call(
                &realized,
                &[CallAccessRequest {
                    object,
                    mode: MemoryAccessMode::Write,
                    region: MemoryAccessRegion::Contiguous {
                        offset_bytes: 0,
                        length_bytes: 16,
                    },
                }],
            )
            .unwrap()
    };
    let first_write = prepare_write(first);
    let second_write = prepare_write(second);

    assert!(matches!(
        domain.acquire_call(&realized, &first_write),
        Err(MemoryRuntimeError::InvalidLifetimeTransition { .. })
    ));
    {
        let scope = domain.enter_plan_point(MemoryPlanPoint::new(0)).unwrap();
        assert_eq!(scope.point(), MemoryPlanPoint::new(0));
        domain
            .acquire_call(&realized, &first_write)
            .unwrap()
            .with_object_init_writer::<u8>(first, |writer| {
                for _ in 0..16 {
                    writer.write_next(11)?;
                }
                Ok::<(), MemoryRuntimeError>(())
            })
            .unwrap();
        assert!(matches!(
            domain.acquire_call(&realized, &second_write),
            Err(MemoryRuntimeError::InvalidLifetimeTransition { .. })
        ));
        assert!(matches!(
            domain.enter_plan_point(MemoryPlanPoint::new(1)),
            Err(MemoryRuntimeError::TurnInFlight)
        ));
    }
    {
        let first_read = domain
            .prepare_call(
                &realized,
                &[CallAccessRequest {
                    object: first,
                    mode: MemoryAccessMode::Read,
                    region: MemoryAccessRegion::Contiguous {
                        offset_bytes: 0,
                        length_bytes: 16,
                    },
                }],
            )
            .unwrap();
        let _scope = domain.enter_plan_point(MemoryPlanPoint::new(1)).unwrap();
        let frame = domain.acquire_call(&realized, &first_read).unwrap();
        frame
            .with_bytes(first, |bytes| assert!(bytes.iter().all(|byte| *byte == 11)))
            .unwrap();
    }
    {
        let _scope = domain.enter_plan_point(MemoryPlanPoint::new(2)).unwrap();
        assert!(matches!(
            domain.acquire_call(&realized, &first_write),
            Err(MemoryRuntimeError::InvalidLifetimeTransition { .. })
        ));
        domain
            .acquire_call(&realized, &second_write)
            .unwrap()
            .with_object_init_writer::<u8>(second, |writer| {
                for _ in 0..16 {
                    writer.write_next(22)?;
                }
                Ok::<(), MemoryRuntimeError>(())
            })
            .unwrap();
    }
    {
        let _scope = domain.enter_plan_point(MemoryPlanPoint::new(0)).unwrap();
        assert!(matches!(
            domain.prepare_call(
                &realized,
                &[CallAccessRequest {
                    object: first,
                    mode: MemoryAccessMode::Read,
                    region: MemoryAccessRegion::Contiguous {
                        offset_bytes: 0,
                        length_bytes: 16,
                    },
                }],
            ),
            Err(MemoryRuntimeError::UninitializedAccess { .. })
        ));
    }
}

#[test]
fn retired_allocations_wait_for_held_leases_before_reclamation() {
    let domain = MemoryDomain::new().unwrap();
    let revision = domain.issue_plan_revision().unwrap();
    let realized = domain
        .materialize(
            domain
                .prepare_realization(runtime_plan_view(
                    revision,
                    &[allocation(0, 0, 0, 0, 8, MemoryLifetime::Activation, None)],
                    &[arena(0, ArenaBackingKind::ContiguousBytes, 8, &[0])],
                    ResourceDemand::default(),
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    let object = domain
        .plan_object_key(revision, MemoryObjectId::new(0))
        .unwrap();
    let write = domain
        .prepare_call(
            &realized,
            &[CallAccessRequest {
                object,
                mode: MemoryAccessMode::Write,
                region: MemoryAccessRegion::Contiguous {
                    offset_bytes: 0,
                    length_bytes: 8,
                },
            }],
        )
        .unwrap();
    domain
        .acquire_call(&realized, &write)
        .unwrap()
        .with_object_init_writer::<u64>(object, |writer| writer.write_next(23))
        .unwrap();
    let read = domain
        .prepare_call(
            &realized,
            &[CallAccessRequest {
                object,
                mode: MemoryAccessMode::Read,
                region: MemoryAccessRegion::WholeInitialized,
            }],
        )
        .unwrap();
    let held = domain.acquire_call(&realized, &read).unwrap();
    let handle = realized.binding(object).unwrap().handle().unwrap();
    domain.retire(handle).unwrap();
    assert_eq!(domain.collect_retired().unwrap(), 0);
    let read_after_retire = domain
        .prepare_call(
            &realized,
            &[CallAccessRequest {
                object,
                mode: MemoryAccessMode::Read,
                region: MemoryAccessRegion::WholeInitialized,
            }],
        )
        .unwrap();
    assert!(matches!(
        domain.acquire_call(&realized, &read_after_retire),
        Err(MemoryRuntimeError::InvalidLifetimeTransition { .. })
    ));
    assert_eq!(
        held.with_bytes(object, |bytes| u64::from_ne_bytes(
            bytes.try_into().unwrap()
        ))
        .unwrap(),
        23
    );
    drop(held);
    // A live realization is retained storage ownership, independently of
    // whether any access lease is currently installed.
    assert_eq!(domain.collect_retired().unwrap(), 0);
    assert!(matches!(
        domain.acquire_call(&realized, &read),
        Err(MemoryRuntimeError::InvalidLifetimeTransition { .. })
    ));
    drop(realized);
    assert_eq!(domain.collect_retired().unwrap(), 1);
    assert!(matches!(
        domain.retire(handle),
        Err(MemoryRuntimeError::StaleAllocationGeneration { .. })
    ));
}

#[test]
fn device_registration_and_submission_holds_follow_planned_ownership() {
    let domain = MemoryDomain::new().unwrap();
    let revision = domain.issue_plan_revision().unwrap();
    let mut device = allocation(0, 0, 0, 16, 16, MemoryLifetime::Activation, None);
    device.space = MemorySpace::Device { region: 0 };
    let transfer_lifetime = MemoryLifetime::Transfer {
        first: MemoryPlanPoint::new(0),
        last: MemoryPlanPoint::new(0),
    };
    let mut transfer = allocation(1, 1, 0, 0, 8, transfer_lifetime, None);
    transfer.role = AllocationRole::TransferStage;
    let mut device_arena = arena(0, ArenaBackingKind::ContiguousBytes, 16, &[0]);
    device_arena.space = MemorySpace::Device { region: 0 };
    let transfer_arena = arena(1, ArenaBackingKind::ContiguousBytes, 8, &[1]);
    let realized = domain
        .materialize(
            domain
                .prepare_realization(runtime_plan_view(
                    revision,
                    &[device, transfer],
                    &[device_arena, transfer_arena],
                    ResourceDemand::default(),
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    let device_object = domain
        .plan_object_key(revision, MemoryObjectId::new(0))
        .unwrap();
    let transfer_object = domain
        .plan_object_key(revision, MemoryObjectId::new(1))
        .unwrap();
    assert!(matches!(
        realized.binding(device_object).unwrap(),
        RuntimeBinding::Device { .. }
    ));
    assert_eq!(domain.allocation_observations()[0].actual_block_bytes, 0);

    let owner = domain
        .register_device_allocation(&realized, device_object, 16, 16)
        .unwrap();
    let observation = domain.allocation_observations()[0];
    assert_eq!(observation.actual_block_bytes, 16);
    assert_eq!(observation.device_owner_pins, 1);
    let prepared = domain
        .prepare_device_submission(&realized, &[device_object], &[transfer_object])
        .unwrap();
    let hold = domain
        .begin_prepared_device_submission(&realized, &prepared)
        .unwrap();
    assert_eq!(domain.ledger().in_flight_device_bytes, 16);
    assert_eq!(domain.ledger().in_flight_transfer_bytes, 8);
    assert_eq!(domain.allocation_observations()[0].submission_pins, 1);

    hold.complete().unwrap();
    assert_eq!(domain.ledger().in_flight_device_bytes, 0);
    assert_eq!(domain.ledger().in_flight_transfer_bytes, 0);
    domain
        .begin_prepared_device_submission(&realized, &prepared)
        .unwrap()
        .complete()
        .unwrap();
    domain.retire(owner.handle()).unwrap();
    assert_eq!(domain.collect_retired().unwrap(), 0);
    drop(owner);
    assert_eq!(domain.collect_retired().unwrap(), 0);
    drop(realized);
    assert_eq!(domain.collect_retired().unwrap(), 2);
}

#[test]
fn device_loss_prevents_new_submissions() {
    let domain = MemoryDomain::new().unwrap();
    let revision = domain.issue_plan_revision().unwrap();
    let mut allocation = allocation(0, 0, 0, 4, 4, MemoryLifetime::Activation, None);
    allocation.space = MemorySpace::Device { region: 2 };
    allocation.alignment = 4;
    let mut arena = arena(0, ArenaBackingKind::ContiguousBytes, 4, &[0]);
    arena.space = MemorySpace::Device { region: 2 };
    arena.alignment = 4;
    let realized = domain
        .materialize(
            domain
                .prepare_realization(runtime_plan_view(
                    revision,
                    &[allocation],
                    &[arena],
                    ResourceDemand::default(),
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    let object = domain
        .plan_object_key(revision, MemoryObjectId::new(0))
        .unwrap();
    let owner = domain
        .register_device_allocation(&realized, object, 4, 4)
        .unwrap();
    owner.mark_lost().unwrap();
    assert!(matches!(
        domain.begin_device_submission(&realized, &[object], &[]),
        Err(MemoryRuntimeError::DeviceLost { .. })
    ));
    assert!(domain.allocation_observations()[0].device_lost);
}

#[test]
fn handles_are_domain_scoped_and_stale_generations_are_rejected() {
    let domain = MemoryDomain::new().unwrap();
    let revision = domain.issue_plan_revision().unwrap();
    let allocations = [allocation(0, 0, 0, 0, 8, MemoryLifetime::Activation, None)];
    let arenas = [arena(0, ArenaBackingKind::ContiguousBytes, 8, &[0])];
    let first = domain
        .materialize(
            domain
                .prepare_realization(runtime_plan_view(
                    revision,
                    &allocations,
                    &arenas,
                    ResourceDemand::default(),
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    let key = domain
        .plan_object_key(revision, MemoryObjectId::new(0))
        .unwrap();
    let old = first.binding(key).unwrap().handle().unwrap();
    let other = MemoryDomain::new().unwrap();
    assert!(matches!(
        other.retire(old),
        Err(MemoryRuntimeError::WrongMemoryDomain { .. })
    ));
    domain.retire(old).unwrap();
    assert_eq!(domain.collect_retired().unwrap(), 0);
    drop(first);
    assert_eq!(domain.collect_retired().unwrap(), 1);

    let next_revision = domain.issue_plan_revision().unwrap();
    let second = domain
        .materialize(
            domain
                .prepare_realization(runtime_plan_view(
                    next_revision,
                    &allocations,
                    &arenas,
                    ResourceDemand::default(),
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    let next_key = domain
        .plan_object_key(next_revision, MemoryObjectId::new(0))
        .unwrap();
    let current = second.binding(next_key).unwrap().handle().unwrap();
    assert_eq!(old.slot(), current.slot());
    assert_ne!(old.generation(), current.generation());
    assert!(matches!(
        domain.retire(old),
        Err(MemoryRuntimeError::StaleAllocationGeneration { .. })
    ));
}

#[test]
fn indirect_payload_envelopes_are_owned_separately_and_charged_once() {
    let domain = MemoryDomain::new().unwrap();
    let revision = domain.issue_plan_revision().unwrap();
    let mut left = allocation(0, 0, 0, 0, 11, MemoryLifetime::Activation, None);
    left.role = AllocationRole::VariablePayload;
    left.slot = None;
    left.payload_block_capacity = 1;
    left.alignment = 1;
    let mut right = allocation(1, 0, 0, 0, 13, MemoryLifetime::Activation, None);
    right.role = AllocationRole::VariablePayload;
    right.slot = None;
    right.payload_block_capacity = 1;
    right.alignment = 1;
    let allocations = [left, right];
    let mut payload_arena = arena(0, ArenaBackingKind::IndirectOwnedPayloads, 24, &[0, 1]);
    payload_arena.alignment = 1;
    let realized = domain
        .materialize(
            domain
                .prepare_realization(runtime_plan_view(
                    revision,
                    &allocations,
                    &[payload_arena],
                    ResourceDemand::default(),
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    assert_eq!(realized.bindings().len(), 2);
    assert_eq!(domain.ledger().committed_bytes, 72);
    assert_eq!(domain.allocation_observations().len(), 2);

    let left_key = domain
        .plan_object_key(revision, MemoryObjectId::new(0))
        .unwrap();
    let right_key = domain
        .plan_object_key(revision, MemoryObjectId::new(1))
        .unwrap();
    let left_allocator = domain.planned_allocator(&realized, left_key).unwrap();
    let right_allocator = domain.planned_allocator(&realized, right_key).unwrap();
    let string = ManagedString::try_new(left_allocator.clone(), "hello world").unwrap();
    let sequence =
        ManagedSequence::try_from_slice(right_allocator.clone(), b"hello, world!").unwrap();
    assert_eq!(string.as_str(), "hello world");
    assert_eq!(sequence.as_slice(), b"hello, world!");
    assert_eq!(left_allocator.allocated_bytes().unwrap(), 11);
    assert_eq!(right_allocator.allocated_bytes().unwrap(), 13);
    assert_eq!(domain.ledger().committed_bytes, 72);
    assert!(matches!(
        ManagedString::try_new(left_allocator.clone(), "x"),
        Err(MemoryRuntimeError::CapacityExceeded { .. })
    ));
    let observations = domain.allocation_observations();
    assert_eq!(observations[0].actual_block_bytes, 11);
    assert_eq!(observations[1].actual_block_bytes, 13);
    assert_eq!(observations[0].payload_owner_pins, 1);

    let left_handle = realized.binding(left_key).unwrap().handle().unwrap();
    domain.retire(left_handle).unwrap();
    assert_eq!(domain.collect_retired().unwrap(), 0);
    drop(string);
    drop(left_allocator);
    assert_eq!(domain.collect_retired().unwrap(), 0);
    drop(realized);
    assert_eq!(domain.collect_retired().unwrap(), 1);
}

#[test]
fn detached_values_share_one_sendable_immutable_payload_root() {
    let value = ValueCell::from_exact(37_u64).unwrap().snapshot().unwrap();
    let clone = value.clone();
    assert!(value.shares_frozen_storage(&clone));
    std::thread::spawn(move || drop(clone)).join().unwrap();
}

#[test]
fn ordinary_dynamic_cell_snapshots_retain_the_frozen_root_after_close() {
    let schema = SchemaDraft {
        dimension_parameters: Box::new([]),
        body: SchemaBody::Tuple(vec![SchemaBody::Dynamic].into_boxed_slice()),
    }
    .finalize()
    .unwrap();
    let mut builder = SchemaTableBuilder::new();
    let handle = builder.insert(schema).unwrap();
    let build = builder.finish().unwrap();
    let schema = build.resolve(handle).unwrap();
    let (schemas, _) = build.into_parts();
    let value = ValueDraft {
        schema,
        shape_values: Box::new([]),
        data: ValueDataDraft::Tuple(vec![ValueDataDraft::Dynamic(None)].into_boxed_slice()),
    }
    .finalize(&SnapshotValidationContext::new(&schemas))
    .unwrap();
    let domain = MemoryDomain::new().unwrap();
    let cell = ValueCell::from_snapshot_in(&domain, value.clone()).unwrap();
    let first = cell.snapshot().unwrap();
    let second = cell.snapshot().unwrap();
    assert!(value.shares_frozen_storage(&first));
    assert!(first.shares_frozen_storage(&second));

    drop(cell);
    domain.close().unwrap();
    assert!(matches!(first.data(), mech_core::ValueData::Tuple(_)));
    assert!(first.shares_frozen_storage(&second));
}

#[test]
fn reclaimed_realizations_release_historical_region_and_revision_metadata() {
    const CAPACITY: u64 = 4 * 1024 * 1024;

    let domain = MemoryDomain::new().unwrap();
    let mut stale_key = None;
    for iteration in 0..12_u64 {
        let revision = domain.issue_plan_revision().unwrap();
        let capacity = CAPACITY + (iteration % 3) * 64;
        let mut allocations = [allocation(
            0,
            0,
            0,
            1,
            capacity,
            MemoryLifetime::Activation,
            None,
        )];
        allocations[0].slot = None;
        let arenas = [arena(0, ArenaBackingKind::ContiguousBytes, capacity, &[0])];
        let realized = domain
            .materialize(
                domain
                    .prepare_realization(runtime_plan_view(
                        revision,
                        &allocations,
                        &arenas,
                        ResourceDemand::default(),
                        MemoryBudgetLimits::default(),
                        &[],
                    ))
                    .unwrap(),
            )
            .unwrap();
        let key = domain
            .plan_object_key(revision, MemoryObjectId::new(0))
            .unwrap();
        let write = domain
            .prepare_call(
                &realized,
                &[CallAccessRequest {
                    object: key,
                    mode: MemoryAccessMode::Write,
                    region: MemoryAccessRegion::Contiguous {
                        offset_bytes: 0,
                        length_bytes: 1,
                    },
                }],
            )
            .unwrap();
        domain
            .acquire_call(&realized, &write)
            .unwrap()
            .with_object_init_writer::<u8>(key, |writer| writer.write_next(7))
            .unwrap();
        stale_key.get_or_insert(key);

        let retained = (iteration == 0).then(|| realized.clone());
        drop(realized);
        if let Some(retained) = retained {
            assert_eq!(domain.collect_retired().unwrap(), 0);
            let metadata = domain.metadata_observation();
            assert_eq!(metadata.regions, 1);
            assert!(metadata.initialization_bytes >= CAPACITY / 8);
            drop(retained);
        }
        assert_eq!(domain.collect_retired().unwrap(), 1);
        assert_eq!(domain.metadata_observation(), Default::default());
        assert_eq!(domain.ledger().committed_bytes, 0);
    }

    let rejected = domain.issue_plan_revision().unwrap();
    let allocations = [allocation(0, 0, 0, 0, 8, MemoryLifetime::Activation, None)];
    let arenas = [arena(0, ArenaBackingKind::ContiguousBytes, 8, &[0])];
    let limits = MemoryBudgetLimits {
        max_temporary_bytes: Some(1),
        ..MemoryBudgetLimits::default()
    };
    assert!(
        domain
            .prepare_realization(runtime_plan_view(
                rejected,
                &allocations,
                &arenas,
                ResourceDemand {
                    turn_peak_bytes: 2,
                    ..ResourceDemand::default()
                },
                limits,
                &[],
            ))
            .is_err()
    );
    domain.collect_retired().unwrap();
    assert_eq!(domain.metadata_observation(), Default::default());

    let revision = domain.issue_plan_revision().unwrap();
    let realized = domain
        .materialize(
            domain
                .prepare_realization(runtime_plan_view(
                    revision,
                    &allocations,
                    &arenas,
                    ResourceDemand::default(),
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    assert!(matches!(
        domain.prepare_call(
            &realized,
            &[CallAccessRequest {
                object: stale_key.unwrap(),
                mode: MemoryAccessMode::Read,
                region: MemoryAccessRegion::WholeInitialized,
            }],
        ),
        Err(MemoryRuntimeError::InvalidPlanRevision { .. })
            | Err(MemoryRuntimeError::UnknownPlanObject { .. })
    ));
}

#[test]
fn immutable_snapshot_imports_share_one_physical_payload_ticket() {
    let source_cell = ValueCell::from_exact("x".repeat(256 * 1024)).unwrap();
    let source = source_cell.snapshot().unwrap();
    let left_domain = MemoryDomain::new().unwrap();
    let right_domain = MemoryDomain::new().unwrap();

    let left = ValueCell::from_snapshot_in(&left_domain, source.clone()).unwrap();
    let right = ValueCell::from_snapshot_in(&right_domain, source.clone()).unwrap();
    let left_snapshot = left.snapshot().unwrap();
    let right_snapshot = right.snapshot().unwrap();

    assert!(source.shares_frozen_storage(&left_snapshot));
    assert!(left_snapshot.shares_frozen_storage(&right_snapshot));
    assert!(source.shares_retained_payload_ticket(&left_snapshot));
    assert!(left_snapshot.shares_retained_payload_ticket(&right_snapshot));
    assert!(left_domain.ledger().committed_bytes > 0);
    assert!(right_domain.ledger().committed_bytes > 0);

    let deep_copy = ValueCell::from_exact("x".repeat(256 * 1024))
        .unwrap()
        .snapshot()
        .unwrap();
    assert!(!source.shares_frozen_storage(&deep_copy));
    assert!(!source.shares_retained_payload_ticket(&deep_copy));

    drop(source_cell);
    drop(source);
    left_domain.close().unwrap();
    right_domain.close().unwrap();
    drop(left);
    drop(right);
    assert!(matches!(
        left_snapshot.data(),
        mech_core::ValueData::String(value) if value.len() == 256 * 1024
    ));
    assert!(left_snapshot.shares_retained_payload_ticket(&right_snapshot));
}

#[test]
fn publication_versions_change_only_for_changed_candidates() {
    let domain = MemoryDomain::new().unwrap();
    let revision = domain.issue_plan_revision().unwrap();
    let allocations = [allocation(0, 0, 0, 0, 8, MemoryLifetime::Activation, None)];
    let arenas = [arena(0, ArenaBackingKind::ContiguousBytes, 8, &[0])];
    let realized = domain
        .materialize(
            domain
                .prepare_realization(runtime_plan_view(
                    revision,
                    &allocations,
                    &arenas,
                    ResourceDemand::default(),
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    let key = domain
        .plan_object_key(revision, MemoryObjectId::new(0))
        .unwrap();
    let binding = realized.binding(key).unwrap();
    assert!(matches!(binding, RuntimeBinding::ManagedHostRegion { .. }));
    let mut unchanged = domain
        .prepare_publication(
            &realized,
            vec![PublicationCandidate {
                object: key,
                binding: binding.clone(),
                shape: vec![1].into_boxed_slice(),
                changed: false,
            }],
        )
        .unwrap();
    let first = domain.commit_publication(&mut unchanged).unwrap();
    assert_eq!(first[0].version.get(), 1);
    assert!(matches!(
        domain.commit_publication(&mut unchanged),
        Err(MemoryRuntimeError::PublicationAlreadyCompleted)
    ));

    let mut changed = domain
        .prepare_publication(
            &realized,
            vec![PublicationCandidate {
                object: key,
                binding,
                shape: vec![1].into_boxed_slice(),
                changed: true,
            }],
        )
        .unwrap();
    let second = domain.commit_publication(&mut changed).unwrap();
    assert_eq!(second[0].version.get(), 2);
    let mut third = domain
        .prepare_publication(
            &realized,
            vec![PublicationCandidate {
                object: key,
                binding: second[0].binding.clone(),
                shape: vec![1].into_boxed_slice(),
                changed: true,
            }],
        )
        .unwrap();
    assert_eq!(
        domain.commit_publication(&mut third).unwrap()[0]
            .version
            .get(),
        3
    );
}

#[test]
fn interval_initialized_region_requires_membership_before_publication() {
    let domain = MemoryDomain::new().unwrap();
    let cell = interval_publication_cell(&domain, None, &[2]);
    let before = IntervalCellState::capture(&cell);
    let region = InitializedIntervalRegion::new(&domain, &[10]);
    // The invalid endpoint is raw kernel output, not a ValueDraft that could
    // reject it before the initialized-region publication boundary is reached.
    let prepared = region.prepare(&domain, &cell).unwrap();
    let rejection = match domain.ready_cell_publication(prepared) {
        Err(error) => Some(error),
        Ok(ready) => {
            drop(ready);
            None
        }
    };
    before.assert_unchanged(&cell);
    assert_interval_publication_rejection(
        rejection
            .expect("initialized raw u64 10 reached the ready gate for exclusive interval [1, 10)"),
        None,
    );

    region.write(&domain, &[3]);
    domain
        .ready_cell_publication(region.prepare(&domain, &cell).unwrap())
        .unwrap()
        .commit();
    before.assert_identity_and_shape(&cell);
    assert_eq!(u64_cell(&cell), 3);
    assert!(cell.published_version() > before.version);
}

fn interval_publication_cell(
    domain: &MemoryDomain,
    matrix_rows: Option<u64>,
    values: &[u64],
) -> ValueCell {
    let interval = SchemaBody::IntegerInterval(mech_core::IntegerInterval::Unsigned {
        width: mech_core::IntegerWidth::W64,
        lower: 1,
        upper: 10,
        upper_inclusive: false,
    });
    let (dimension_parameters, body, shape_values, data) = match matrix_rows {
        None => {
            assert_eq!(values.len(), 1);
            (
                Box::new([]) as Box<[_]>,
                interval,
                Box::new([]) as Box<[_]>,
                ValueDataDraft::U64(values[0]),
            )
        }
        Some(rows) => (
            vec![mech_core::DimensionParameterDeclaration {
                id: mech_core::DimensionParameterId::new(0),
                origin: mech_core::DimensionParameterOrigin::Explicit,
                lifetime: mech_core::DimensionLifetime::Activation,
                lower_bound: mech_core::DimensionExpr::Constant(0),
                upper_bound: Some(mech_core::DimensionExpr::Constant(4)),
            }]
            .into_boxed_slice(),
            SchemaBody::Matrix {
                element: Box::new(interval),
                dimensions: vec![
                    mech_core::DimensionExpr::Parameter(mech_core::DimensionParameterId::new(0)),
                    mech_core::DimensionExpr::Constant(3),
                ]
                .into_boxed_slice(),
            },
            vec![rows].into_boxed_slice(),
            ValueDataDraft::Matrix(values.iter().copied().map(ValueDataDraft::U64).collect()),
        ),
    };
    let schema = SchemaDraft {
        dimension_parameters,
        body,
    }
    .finalize()
    .unwrap();
    let mut builder = SchemaTableBuilder::new();
    let handle = builder.insert(schema).unwrap();
    let build = builder.finish().unwrap();
    let schema = build.resolve(handle).unwrap();
    let (schemas, _) = build.into_parts();
    let value = ValueDraft {
        schema,
        shape_values,
        data,
    }
    .finalize(&SnapshotValidationContext::new(&schemas))
    .unwrap();
    ValueCell::from_snapshot_in(domain, value).unwrap()
}

struct IntervalCellState {
    values: Vec<u64>,
    id: mech_core::CanonicalCellId,
    schema: mech_core::SchemaId,
    schema_key: mech_core::SchemaKey,
    shape: mech_core::ShapeInstance,
    version: mech_core::PublishedValueVersion,
}

impl IntervalCellState {
    fn capture(cell: &ValueCell) -> Self {
        Self {
            values: interval_cell_values(cell),
            id: cell.reactive_cell_id(),
            schema: cell.schema(),
            schema_key: cell.schema_key(),
            shape: cell.shape().clone(),
            version: cell.published_version(),
        }
    }

    fn assert_identity_and_shape(&self, cell: &ValueCell) {
        assert_eq!(cell.reactive_cell_id(), self.id);
        assert_eq!(cell.schema(), self.schema);
        assert_eq!(cell.schema_key(), self.schema_key);
        assert_eq!(cell.shape().clone(), self.shape);
        let snapshot = cell.snapshot().unwrap();
        assert_eq!(snapshot.schema(), self.schema);
        assert_eq!(snapshot.schema_key(), self.schema_key);
        assert_eq!(snapshot.shape(), &self.shape);
    }

    fn assert_unchanged(&self, cell: &ValueCell) {
        self.assert_identity_and_shape(cell);
        assert_eq!(interval_cell_values(cell), self.values);
        assert_eq!(cell.published_version(), self.version);
    }
}

fn interval_cell_values(cell: &ValueCell) -> Vec<u64> {
    let snapshot = cell.snapshot().unwrap();
    match snapshot.data() {
        mech_core::ValueData::U64(value) => vec![*value],
        mech_core::ValueData::Matrix(matrix) => matrix
            .elements()
            .to_values()
            .into_iter()
            .map(|element| match element {
                mech_core::ValueData::U64(value) => value,
                _ => panic!("expected interval U64 matrix member"),
            })
            .collect(),
        _ => panic!("expected interval U64 scalar or matrix"),
    }
}

fn assert_interval_publication_rejection(error: mech_core::MechError, matrix_index: Option<u64>) {
    assert_eq!(error.kind_name(), "ValueCellSnapshotFailure", "{error:?}");
    let message = error.kind_message();
    assert!(message.contains("IntegerIntervalViolationV1"), "{error:?}");
    if let Some(index) = matrix_index {
        assert!(
            message.contains(&format!("MatrixElement({index})")),
            "{error:?}"
        );
    }
}

fn interval_scalar_cell_from_data(
    domain: &MemoryDomain,
    interval: mech_core::IntegerInterval,
    data: ValueDataDraft,
) -> ValueCell {
    let schema = SchemaDraft {
        dimension_parameters: Box::new([]),
        body: SchemaBody::IntegerInterval(interval),
    }
    .finalize()
    .unwrap();
    let mut builder = SchemaTableBuilder::new();
    let handle = builder.insert(schema).unwrap();
    let build = builder.finish().unwrap();
    let schema = build.resolve(handle).unwrap();
    let (schemas, _) = build.into_parts();
    let value = ValueDraft {
        schema,
        shape_values: Box::new([]),
        data,
    }
    .finalize(&SnapshotValidationContext::new(&schemas))
    .unwrap();
    ValueCell::from_snapshot_in(domain, value).unwrap()
}

struct InitializedIntervalRegion {
    realized: mech_core::RealizedMemoryPlan,
    object: mech_core::PlanObjectKey,
    region: MemoryAccessRegion,
    count: usize,
}

impl InitializedIntervalRegion {
    fn matrix(domain: &MemoryDomain, rows: u64, columns: u64, values: &[u64]) -> Self {
        assert_eq!(rows * columns, values.len() as u64);
        let mut result = Self::new(domain, values);
        result.region = MemoryAccessRegion::Rectangle {
            offset_bytes: 0,
            rows,
            columns,
            row_stride_bytes: 8,
            column_stride_bytes: rows * 8,
            element_bytes: 8,
        };
        result
    }

    fn new(domain: &MemoryDomain, values: &[u64]) -> Self {
        let bytes = (values.len() as u64) * 8;
        let revision = domain.issue_plan_revision().unwrap();
        let allocations = [allocation(
            0,
            0,
            0,
            0,
            bytes,
            MemoryLifetime::Activation,
            None,
        )];
        let arenas = [arena(0, ArenaBackingKind::ContiguousBytes, bytes, &[0])];
        let realized = domain
            .materialize(
                domain
                    .prepare_realization(runtime_plan_view(
                        revision,
                        &allocations,
                        &arenas,
                        ResourceDemand::default(),
                        MemoryBudgetLimits::default(),
                        &[],
                    ))
                    .unwrap(),
            )
            .unwrap();
        let object = domain
            .plan_object_key(revision, MemoryObjectId::new(0))
            .unwrap();
        domain.activate_realization(&realized).unwrap();
        let result = Self {
            realized,
            object,
            region: MemoryAccessRegion::Contiguous {
                offset_bytes: 0,
                length_bytes: bytes,
            },
            count: values.len(),
        };
        result.write(domain, values);
        result
    }

    fn write_access(&self, domain: &MemoryDomain) -> mech_core::PreparedCallAccess {
        domain
            .prepare_call(
                &self.realized,
                &[CallAccessRequest {
                    object: self.object,
                    mode: MemoryAccessMode::Write,
                    region: MemoryAccessRegion::Contiguous {
                        offset_bytes: 0,
                        length_bytes: (self.count as u64) * 8,
                    },
                }],
            )
            .unwrap()
    }

    fn write(&self, domain: &MemoryDomain, values: &[u64]) {
        assert_eq!(values.len(), self.count);
        let initialization = self.write_access(domain);
        domain
            .acquire_call(&self.realized, &initialization)
            .unwrap()
            .with_object_init_writer::<u64>(self.object, |writer| writer.copy_from_slice(values))
            .unwrap();
    }

    fn prepare(
        &self,
        domain: &MemoryDomain,
        cell: &ValueCell,
    ) -> mech_core::MResult<PreparedCellPublication> {
        domain.prepare_cell_publication(
            &self.realized,
            vec![CellPublicationCandidate {
                cell: cell.clone(),
                object: self.object,
                binding: self.realized.binding(self.object).unwrap(),
                region: self.region,
                evidence: CellPublicationEvidence::initialized_region(cell.shape().clone()),
                changed: true,
            }],
        )
    }
}

#[test]
fn interval_initialized_region_revalidates_at_ready_and_excludes_writers() {
    let domain = MemoryDomain::new().unwrap();
    let cell = interval_publication_cell(&domain, None, &[2]);
    let before = IntervalCellState::capture(&cell);
    let region = InitializedIntervalRegion::new(&domain, &[3]);
    let prepared = region.prepare(&domain, &cell).unwrap();
    // Preparation cannot certify content that a later admitted kernel changes.
    region.write(&domain, &[10]);
    let stale_rejection = match domain.ready_cell_publication(prepared) {
        Err(error) => Some(error),
        Ok(ready) => {
            drop(ready);
            None
        }
    };
    before.assert_unchanged(&cell);
    assert_interval_publication_rejection(
        stale_rejection
            .expect("ready trusted stale interval preparation after raw 3 -> 10 rewrite"),
        None,
    );

    region.write(&domain, &[3]);
    let prepared = region.prepare(&domain, &cell).unwrap();
    let write = region.write_access(&domain);
    let held_writer = domain.acquire_call(&region.realized, &write).unwrap();
    let overlap_rejected = match domain.ready_cell_publication(prepared) {
        Err(_) => true,
        Ok(ready) => {
            drop(ready);
            false
        }
    };
    drop(held_writer);
    before.assert_unchanged(&cell);
    assert!(
        overlap_rejected,
        "ready admitted an overlapping live typed writer"
    );

    let ready = domain
        .ready_cell_publication(region.prepare(&domain, &cell).unwrap())
        .unwrap();
    let writer_rejected = match domain.acquire_call(&region.realized, &write) {
        Err(_) => true,
        Ok(writer) => {
            drop(writer);
            false
        }
    };
    let projection_rejected =
        match domain.project_host_arena::<u64>(&region.realized, MemoryArenaId::new(0), 1) {
            Err(_) => true,
            Ok(projection) => {
                drop(projection);
                false
            }
        };
    // Do not panic while the ready gate is held, even if exclusion regresses.
    // A projection also revokes initialization, so an unexpected capability
    // must abort this candidate rather than publish it during a negative check.
    if writer_rejected && projection_rejected {
        ready.commit();
    } else {
        drop(ready);
    }
    assert!(
        writer_rejected,
        "typed writer entered while Ready held the candidate"
    );
    assert!(
        projection_rejected,
        "host-arena projection entered while Ready held the candidate"
    );
    before.assert_identity_and_shape(&cell);
    assert_eq!(u64_cell(&cell), 3);
    assert!(cell.published_version() > before.version);
}

#[test]
fn interval_initialized_region_matrix_batch_rejects_late_member_atomically() {
    let domain = MemoryDomain::new().unwrap();
    let left = interval_publication_cell(&domain, None, &[2]);
    let right = interval_publication_cell(&domain, Some(2), &[2, 3, 4, 5, 6, 7]);
    let left_before = IntervalCellState::capture(&left);
    let right_before = IntervalCellState::capture(&right);
    assert_eq!(right_before.shape.parameter_values(), &[2]);
    let left_region = InitializedIntervalRegion::new(&domain, &[3]);
    let left_candidate = left_region.prepare(&domain, &left).unwrap();
    let right_region = InitializedIntervalRegion::matrix(&domain, 2, 3, &[3, 6, 4, 7, 5, 10]);
    let right_candidate = right_region.prepare(&domain, &right).unwrap();
    let rejection = match PreparedCellPublicationBatch::new(vec![left_candidate, right_candidate])
        .unwrap()
        .ready()
    {
        Err(error) => Some(error),
        Ok(ready) => {
            drop(ready);
            None
        }
    };
    left_before.assert_unchanged(&left);
    right_before.assert_unchanged(&right);
    assert_interval_publication_rejection(
        rejection.expect("late invalid matrix member allowed an earlier sibling to publish"),
        Some(5),
    );

    // Stage valid candidates, then corrupt only the last raw matrix member.
    // This forces batch ready itself to revalidate, not just its preparation.
    let left_region = InitializedIntervalRegion::new(&domain, &[3]);
    let left_candidate = left_region.prepare(&domain, &left).unwrap();
    let right_region = InitializedIntervalRegion::matrix(&domain, 2, 3, &[3, 6, 4, 7, 5, 8]);
    let right_candidate = right_region.prepare(&domain, &right).unwrap();
    right_region.write(&domain, &[3, 6, 4, 7, 5, 10]);
    let rejection = match PreparedCellPublicationBatch::new(vec![left_candidate, right_candidate])
        .unwrap()
        .ready()
    {
        Err(error) => Some(error),
        Ok(ready) => {
            drop(ready);
            None
        }
    };
    left_before.assert_unchanged(&left);
    right_before.assert_unchanged(&right);
    assert_interval_publication_rejection(
        rejection.expect("batch ready trusted stale interval matrix preparation"),
        Some(5),
    );

    let left_region = InitializedIntervalRegion::new(&domain, &[3]);
    let left_candidate = left_region.prepare(&domain, &left).unwrap();
    let right_region = InitializedIntervalRegion::matrix(&domain, 2, 3, &[3, 6, 4, 7, 5, 8]);
    let right_candidate = right_region.prepare(&domain, &right).unwrap();
    let write = right_region.write_access(&domain);
    let ready = PreparedCellPublicationBatch::new(vec![left_candidate, right_candidate])
        .unwrap()
        .ready()
        .unwrap();
    let writer_rejected = match domain.acquire_call(&right_region.realized, &write) {
        Err(_) => true,
        Ok(writer) => {
            drop(writer);
            false
        }
    };
    let projection_rejected =
        match domain.project_host_arena::<u64>(&right_region.realized, MemoryArenaId::new(0), 6) {
            Err(_) => true,
            Ok(projection) => {
                drop(projection);
                false
            }
        };
    if writer_rejected && projection_rejected {
        ready.commit();
    } else {
        drop(ready);
    }
    assert!(
        writer_rejected,
        "typed writer entered while batch Ready held the matrix"
    );
    assert!(
        projection_rejected,
        "host projection entered while batch Ready held the matrix"
    );
    left_before.assert_identity_and_shape(&left);
    right_before.assert_identity_and_shape(&right);
    assert_eq!(u64_cell(&left), 3);
    assert_eq!(interval_cell_values(&right), vec![3, 4, 5, 6, 7, 8]);
    assert!(left.published_version() > left_before.version);
    assert!(right.published_version() > right_before.version);
}

#[test]
fn interval_initialized_region_uses_exact_integer_widths() {
    macro_rules! check_width {
        ($ty:ty, $variant:ident, $sign:ident, $width:ident, $wide:ty) => {
            check_width!($ty, $variant, $sign, $width, $wide, <$ty>::MAX - 9, <$ty>::MAX);
        };
        ($ty:ty, $variant:ident, $sign:ident, $width:ident, $wide:ty, $lower:expr, $upper:expr) => {
            for upper_inclusive in [false, true] {
                let lower = $lower;
                let upper = $upper;
                let initial = lower + 1;
                let valid = lower + 2;
                // Exclusive tests reject the upper endpoint; inclusive tests
                // reject below the lower endpoint while accepting the upper.
                let invalid = if upper_inclusive {
                    match lower.checked_sub(1) {
                        Some(value) => value,
                        None => upper + 1,
                    }
                } else { upper };
                let domain = MemoryDomain::new().unwrap();
                let cell = interval_scalar_cell_from_data(
                    &domain,
                    mech_core::IntegerInterval::$sign {
                        width: mech_core::IntegerWidth::$width,
                        lower: <$wide>::from(lower),
                        upper: <$wide>::from(upper),
                        upper_inclusive,
                    },
                    ValueDataDraft::$variant(initial),
                );
                let id = cell.reactive_cell_id();
                let schema = cell.schema();
                let key = cell.schema_key();
                let shape = cell.shape().clone();
                let version = cell.published_version();
                let bytes = core::mem::size_of::<$ty>() as u64;
                let alignment = core::mem::align_of::<$ty>() as u32;
                let revision = domain.issue_plan_revision().unwrap();
                let mut planned = allocation(0, 0, 0, 0, bytes, MemoryLifetime::Activation, None);
                planned.slot = Some(mech_core::PlannedSlotKind::FixedScalar(
                    mech_core::ScalarMemoryKind::$sign(mech_core::IntegerWidth::$width),
                ));
                planned.alignment = alignment;
                let allocations = [planned];
                let mut planned_arena = arena(0, ArenaBackingKind::ContiguousBytes, bytes, &[0]);
                planned_arena.alignment = alignment;
                let arenas = [planned_arena];
                let realized = domain
                    .materialize(
                        domain
                            .prepare_realization(runtime_plan_view(
                                revision,
                                &allocations,
                                &arenas,
                                ResourceDemand::default(),
                                MemoryBudgetLimits::default(),
                                &[],
                            ))
                            .unwrap(),
                    )
                    .unwrap();
                let object = domain.plan_object_key(revision, MemoryObjectId::new(0)).unwrap();
                domain.activate_realization(&realized).unwrap();
                let region = MemoryAccessRegion::Contiguous { offset_bytes: 0, length_bytes: bytes };
                let write = domain.prepare_call(&realized, &[CallAccessRequest {
                    object, mode: MemoryAccessMode::Write, region,
                }]).unwrap();
                let initialize = |value: $ty| {
                    domain.acquire_call(&realized, &write).unwrap()
                        .with_object_init_writer::<$ty>(object, |writer| writer.write_next(value)).unwrap();
                };
                let prepare = || domain.prepare_cell_publication(&realized, vec![CellPublicationCandidate {
                    cell: cell.clone(), object, binding: realized.binding(object).unwrap(), region,
                    evidence: CellPublicationEvidence::initialized_region(shape.clone()), changed: true,
                }]).unwrap();
                initialize(invalid);
                let rejection = match domain.ready_cell_publication(prepare()) {
                    Err(error) => Some(error),
                    Ok(ready) => { drop(ready); None }
                };
                assert_interval_publication_rejection(
                    rejection.expect(concat!(stringify!($ty), " invalid raw interval endpoint reached Ready")),
                    None,
                );
                assert!(matches!(cell.snapshot().unwrap().data(), mech_core::ValueData::$variant(value) if *value == initial));
                assert_eq!(cell.published_version(), version);
                // Both ordinary members and inclusive maxima are admitted in
                // exact integer arithmetic, including u128/i128 extremes.
                let valid = if lower == <$ty>::MIN { lower } else if upper_inclusive { upper } else { valid };
                initialize(valid);
                domain.ready_cell_publication(prepare()).unwrap().commit();
                assert!(matches!(cell.snapshot().unwrap().data(), mech_core::ValueData::$variant(value) if *value == valid));
                assert_eq!(cell.reactive_cell_id(), id);
                assert_eq!(cell.schema(), schema);
                assert_eq!(cell.schema_key(), key);
                assert_eq!(cell.shape().clone(), shape);
                assert!(cell.published_version() > version);
            }
        };
    }
    #[cfg(feature = "u8")]
    check_width!(u8, U8, Unsigned, W8, u128);
    #[cfg(feature = "u16")]
    check_width!(u16, U16, Unsigned, W16, u128);
    #[cfg(feature = "u32")]
    check_width!(u32, U32, Unsigned, W32, u128);
    #[cfg(feature = "u64")]
    check_width!(u64, U64, Unsigned, W64, u128);
    #[cfg(feature = "u128")]
    check_width!(u128, U128, Unsigned, W128, u128);
    #[cfg(feature = "i8")]
    check_width!(i8, I8, Signed, W8, i128);
    #[cfg(feature = "i16")]
    check_width!(i16, I16, Signed, W16, i128);
    #[cfg(feature = "i32")]
    check_width!(i32, I32, Signed, W32, i128);
    #[cfg(feature = "i64")]
    check_width!(i64, I64, Signed, W64, i128);
    #[cfg(feature = "i128")]
    check_width!(i128, I128, Signed, W128, i128);
    #[cfg(feature = "i128")]
    check_width!(i128, I128, Signed, W128, i128, i128::MIN, i128::MIN + 10);
}

#[test]
fn interval_initialized_region_matrix_handles_empty_and_padded_geometry() {
    let domain = MemoryDomain::new().unwrap();
    let empty = interval_publication_cell(&domain, Some(0), &[]);
    let empty_before = IntervalCellState::capture(&empty);
    let empty_region = InitializedIntervalRegion::matrix(&domain, 0, 3, &[]);
    domain
        .ready_cell_publication(empty_region.prepare(&domain, &empty).unwrap())
        .unwrap()
        .commit();
    empty_before.assert_identity_and_shape(&empty);
    assert_eq!(empty.shape().parameter_values(), &[0]);
    assert_eq!(interval_cell_values(&empty), Vec::<u64>::new());
    assert!(empty.published_version() > empty_before.version);

    let matrix = interval_publication_cell(&domain, Some(2), &[2, 3, 4, 5, 6, 7]);
    let before = IntervalCellState::capture(&matrix);
    // Two invalid padding lanes lie outside the logical 2×3 rectangle. Only
    // the final semantic lane (raw index7, canonical index5) must be refused.
    let mut padded = InitializedIntervalRegion::new(&domain, &[3, 6, 10, 4, 7, 10, 5, 10]);
    padded.region = MemoryAccessRegion::Rectangle {
        offset_bytes: 0,
        rows: 2,
        columns: 3,
        row_stride_bytes: 8,
        column_stride_bytes: 24,
        element_bytes: 8,
    };
    let rejection = match domain.ready_cell_publication(padded.prepare(&domain, &matrix).unwrap()) {
        Err(error) => Some(error),
        Ok(ready) => {
            drop(ready);
            None
        }
    };
    before.assert_unchanged(&matrix);
    assert_interval_publication_rejection(
        rejection.expect("padded matrix admitted its late invalid semantic member"),
        Some(5),
    );
    padded.write(&domain, &[3, 6, 10, 4, 7, 10, 5, 8]);
    domain
        .ready_cell_publication(padded.prepare(&domain, &matrix).unwrap())
        .unwrap()
        .commit();
    before.assert_identity_and_shape(&matrix);
    assert_eq!(interval_cell_values(&matrix), vec![3, 4, 5, 6, 7, 8]);
    assert!(matrix.published_version() > before.version);
}

#[cfg(feature = "full")]
#[test]
fn interval_initialized_region_required_in_place_restores_and_retries() {
    use mech_core::{
        AccessMode, AliasPolicy, BoundCall, BytecodeCompilerContext, CallMemoryPlanningRequest,
        ChangeDetectionPolicy, CurrentMemoryFootprint, DeliveryMode, ExecutionTarget,
        ExternalInteraction, FunctionInstance, ImplementationMemoryClass, InputPortLayout,
        InputPortPolicy, MechFunctionCompiler, MemoryFootprintWitness,
        OperationContractDeclaration, OutputConstruction, OutputPortPolicy, RegionAccessPlan,
        RegionPolicy, Register, ResolvedOperationDescriptor, RuntimeFunctionId,
        TargetMemoryProfile, TransactionRequirement, physical_storage_descriptor, plan_call_memory,
    };
    use std::{cell::Cell, rc::Rc};

    struct WriteInterval {
        input: ManagedPort<u64>,
        output: ManagedPort<u64>,
        next: Rc<Cell<u64>>,
        observed: Rc<Cell<u64>>,
    }

    impl MechFunctionImpl for WriteInterval {
        fn solve_managed(
            &self,
            frame: &mut KernelMemoryFrame<'_>,
            _: &mut dyn MechExecutionServices,
        ) -> mech_core::MResult<ReactiveSolveStatus> {
            self.observed
                .set(frame.with_port_slice(&self.input, |values| values[0])?);
            frame.with_port_slice_mut(&self.output, |values| values[0] = self.next.get())?;
            Ok(ReactiveSolveStatus::Changed)
        }

        fn to_string(&self) -> String {
            "initialized interval required-in-place output".into()
        }
    }

    impl MechFunctionCompiler for WriteInterval {
        fn compile(&self, _: &mut dyn BytecodeCompilerContext) -> mech_core::MResult<Register> {
            Err(MemoryRuntimeError::CandidateValidationFailed {
                object: None,
                reason: "test-only managed interval writer is not an artifact compiler".into(),
            }
            .into())
        }
    }

    let domain = MemoryDomain::new().unwrap();
    let cell = interval_publication_cell(&domain, None, &[2]);
    let before = IntervalCellState::capture(&cell);
    let descriptor = cell.resolved_descriptor().unwrap();
    let operation = ResolvedOperationDescriptor::from_name(
        "test/in-place-interval",
        OperationContractDeclaration {
            inputs: InputPortLayout::Fixed(
                vec![InputPortPolicy {
                    access: AccessMode::Read,
                    delivery: DeliveryMode::Signal,
                }]
                .into_boxed_slice(),
            ),
            outputs: vec![OutputPortPolicy {
                access: AccessMode::Write,
                delivery: DeliveryMode::Signal,
                construction: OutputConstruction::ReadModifyWrite {
                    base_input: 0,
                    regions: RegionPolicy::WholeValue,
                },
                alias: AliasPolicy::InPlaceRequired { input: 0 },
                change_detection: ChangeDetectionPolicy::AlwaysChanged,
            }]
            .into_boxed_slice(),
            interaction: ExternalInteraction::Pure,
        },
    )
    .unwrap();
    let bound = BoundCall::syntax_directed(
        operation,
        vec![descriptor.clone()].into_boxed_slice(),
        vec![descriptor].into_boxed_slice(),
        RuntimeFunctionId::from_name("R15InPlaceInterval"),
        ExecutionTarget::DirectRuntime,
    )
    .unwrap();
    let target = TargetMemoryProfile::current_direct_host().unwrap();
    let storage =
        physical_storage_descriptor(cell.representation(), &target, MemoryLifetime::Activation);
    let witness = MemoryFootprintWitness::Known(CurrentMemoryFootprint {
        logical_elements: 1,
        fixed_bytes: 8,
        encoded_bytes: 8,
        retained_nodes: 1,
        schema_bytes: 1,
        shape_parameter_count: 0,
        ..CurrentMemoryFootprint::default()
    });
    let plan = plan_call_memory(CallMemoryPlanningRequest {
        bound_call: &bound,
        input_storage: &[storage.clone()],
        output_storage: &[storage],
        input_witnesses: &[witness],
        output_witnesses: &[witness],
        published_output_witnesses: &[witness],
        implementation_memory: ImplementationMemoryClass::NoAdditionalScratch,
        target: &target,
        regions: &[RegionAccessPlan::WholeValue],
    })
    .unwrap();
    assert!(matches!(
        plan.transactions[0],
        TransactionRequirement::UndoSnapshot { .. }
    ));
    let invocation = FunctionInvocation::unary(cell.clone(), cell.clone());
    let input = invocation.input(0).unwrap().try_managed::<u64>().unwrap();
    let output = invocation.output().try_managed::<u64>().unwrap();
    let next = Rc::new(Cell::new(10));
    let observed = Rc::new(Cell::new(0));
    let instance = FunctionInstance::new(
        Box::new(WriteInterval {
            input,
            output,
            next: next.clone(),
            observed: observed.clone(),
        }),
        invocation,
        Rc::new(plan),
    )
    .unwrap();
    let error = instance
        .solve_reactive()
        .expect_err("invalid in-place interval candidate published");
    assert_interval_publication_rejection(error, None);
    before.assert_unchanged(&cell);
    assert_eq!(observed.get(), 2);

    next.set(3);
    assert_eq!(
        instance.solve_reactive().unwrap(),
        ReactiveSolveStatus::Changed
    );
    assert_eq!(
        observed.get(),
        2,
        "the rejected output must restore its exact undo image"
    );
    before.assert_identity_and_shape(&cell);
    assert_eq!(u64_cell(&cell), 3);
    assert!(cell.published_version() > before.version);
}

#[test]
fn multi_cell_publication_rejects_late_conflict_before_any_value_changes() {
    let domain = MemoryDomain::new().unwrap();
    let left = ValueCell::from_exact_in(&domain, 1_u64).unwrap();
    let right = ValueCell::from_exact_in(&domain, 2_u64).unwrap();
    let left_alias = left.clone();
    let right_alias = right.clone();
    let left_before_version = left.published_version();
    let right_before_version = right.published_version();
    let left_next = left
        .rebuild_data_draft(mech_core::ValueDataDraft::U64(10))
        .unwrap();
    let right_next = right
        .rebuild_data_draft(mech_core::ValueDataDraft::U64(20))
        .unwrap();

    let revision = domain.issue_plan_revision().unwrap();
    let allocations = [
        allocation(0, 0, 0, 0, 8, MemoryLifetime::Activation, None),
        allocation(1, 0, 8, 0, 8, MemoryLifetime::Activation, None),
    ];
    let arenas = [arena(0, ArenaBackingKind::ContiguousBytes, 16, &[0, 1])];
    let realized = domain
        .materialize(
            domain
                .prepare_realization(runtime_plan_view(
                    revision,
                    &allocations,
                    &arenas,
                    ResourceDemand::default(),
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    let left_object = domain
        .plan_object_key(revision, MemoryObjectId::new(0))
        .unwrap();
    let right_object = domain
        .plan_object_key(revision, MemoryObjectId::new(1))
        .unwrap();
    domain.activate_realization(&realized).unwrap();
    let initialization = domain
        .prepare_call(
            &realized,
            &[
                CallAccessRequest {
                    object: left_object,
                    mode: MemoryAccessMode::Write,
                    region: MemoryAccessRegion::Contiguous {
                        offset_bytes: 0,
                        length_bytes: 8,
                    },
                },
                CallAccessRequest {
                    object: right_object,
                    mode: MemoryAccessMode::Write,
                    region: MemoryAccessRegion::Contiguous {
                        offset_bytes: 0,
                        length_bytes: 8,
                    },
                },
            ],
        )
        .unwrap();
    {
        let mut frame = domain.acquire_call(&realized, &initialization).unwrap();
        frame
            .with_object_init_writer::<u64>(left_object, |writer| writer.write_next(10))
            .unwrap();
        frame
            .with_object_init_writer::<u64>(right_object, |writer| writer.write_next(20))
            .unwrap();
    }
    let prepared = domain
        .prepare_cell_publication(
            &realized,
            vec![
                CellPublicationCandidate {
                    cell: left.clone(),
                    object: left_object,
                    binding: realized.binding(left_object).unwrap(),
                    region: MemoryAccessRegion::Contiguous {
                        offset_bytes: 0,
                        length_bytes: 8,
                    },
                    evidence: CellPublicationEvidence::initialized_region(
                        left_next.shape().clone(),
                    ),
                    changed: true,
                },
                CellPublicationCandidate {
                    cell: right.clone(),
                    object: right_object,
                    binding: realized.binding(right_object).unwrap(),
                    region: MemoryAccessRegion::Contiguous {
                        offset_bytes: 0,
                        length_bytes: 8,
                    },
                    evidence: CellPublicationEvidence::initialized_region(
                        right_next.shape().clone(),
                    ),
                    changed: true,
                },
            ],
        )
        .unwrap();
    let held_shape = right.shape();
    assert!(domain.ready_cell_publication(prepared).is_err());
    drop(held_shape);
    assert_eq!(u64_cell(&left_alias), 1);
    assert_eq!(u64_cell(&right_alias), 2);
    assert_eq!(left.published_version(), left_before_version);
    assert_eq!(right.published_version(), right_before_version);
    let prepared = domain
        .prepare_cell_publication(
            &realized,
            vec![
                CellPublicationCandidate {
                    cell: left.clone(),
                    object: left_object,
                    binding: realized.binding(left_object).unwrap(),
                    region: MemoryAccessRegion::Contiguous {
                        offset_bytes: 0,
                        length_bytes: 8,
                    },
                    evidence: CellPublicationEvidence::initialized_region(left.shape().clone()),
                    changed: true,
                },
                CellPublicationCandidate {
                    cell: right.clone(),
                    object: right_object,
                    binding: realized.binding(right_object).unwrap(),
                    region: MemoryAccessRegion::Contiguous {
                        offset_bytes: 0,
                        length_bytes: 8,
                    },
                    evidence: CellPublicationEvidence::initialized_region(right.shape().clone()),
                    changed: true,
                },
            ],
        )
        .unwrap();
    let ready = domain.ready_cell_publication(prepared).unwrap();
    let shape_held_after_ready = right.shape();
    let committed = ready.commit();
    assert!(shape_held_after_ready.parameter_values().is_empty());
    drop(shape_held_after_ready);
    assert_eq!(committed.len(), 2);
    assert_eq!(u64_cell(&left_alias), 10);
    assert_eq!(u64_cell(&right_alias), 20);
    assert!(left.published_version() > left_before_version);
    assert!(right.published_version() > right_before_version);
}

#[test]
fn sibling_call_candidates_in_one_session_publish_as_one_atomic_batch() {
    fn stage(domain: &MemoryDomain, cell: &ValueCell, value: u64) -> PreparedCellPublication {
        let revision = domain.issue_plan_revision().unwrap();
        let allocations = [allocation(0, 0, 0, 0, 8, MemoryLifetime::Activation, None)];
        let arenas = [arena(0, ArenaBackingKind::ContiguousBytes, 8, &[0])];
        let realized = domain
            .materialize(
                domain
                    .prepare_realization(runtime_plan_view(
                        revision,
                        &allocations,
                        &arenas,
                        ResourceDemand::default(),
                        MemoryBudgetLimits::default(),
                        &[],
                    ))
                    .unwrap(),
            )
            .unwrap();
        let object = domain
            .plan_object_key(revision, MemoryObjectId::new(0))
            .unwrap();
        domain.activate_realization(&realized).unwrap();
        let scope = domain.enter_plan_point(MemoryPlanPoint::new(0)).unwrap();
        let initialization = domain
            .prepare_call(
                &realized,
                &[CallAccessRequest {
                    object,
                    mode: MemoryAccessMode::Write,
                    region: MemoryAccessRegion::Contiguous {
                        offset_bytes: 0,
                        length_bytes: 8,
                    },
                }],
            )
            .unwrap();
        domain
            .acquire_call(&realized, &initialization)
            .unwrap()
            .with_object_init_writer::<u64>(object, |writer| writer.write_next(value))
            .unwrap();
        let publication = domain
            .prepare_cell_publication(
                &realized,
                vec![CellPublicationCandidate {
                    cell: cell.clone(),
                    object,
                    binding: realized.binding(object).unwrap(),
                    region: MemoryAccessRegion::Contiguous {
                        offset_bytes: 0,
                        length_bytes: 8,
                    },
                    evidence: CellPublicationEvidence::initialized_region(cell.shape().clone()),
                    changed: true,
                }],
            )
            .unwrap();
        drop(scope);
        publication
    }

    let domain = MemoryDomain::new().unwrap();
    let left = ValueCell::from_exact_in(&domain, 1_u64).unwrap();
    let right = ValueCell::from_exact_in(&domain, 2_u64).unwrap();
    let left_version = left.published_version();
    let right_version = right.published_version();
    let left_candidate = stage(&domain, &left, 10);
    let right_candidate = stage(&domain, &right, 20);

    // Staging owns both candidates but exposes neither of them.
    assert_eq!(u64_cell(&left), 1);
    assert_eq!(u64_cell(&right), 2);
    assert_eq!(left.published_version(), left_version);
    assert_eq!(right.published_version(), right_version);

    PreparedCellPublicationBatch::new(vec![left_candidate, right_candidate])
        .unwrap()
        .ready()
        .unwrap()
        .commit();
    assert_eq!(u64_cell(&left), 10);
    assert_eq!(u64_cell(&right), 20);
    assert!(left.published_version() > left_version);
    assert!(right.published_version() > right_version);
}

fn u64_cell(cell: &ValueCell) -> u64 {
    let snapshot = cell.snapshot().unwrap();
    let mech_core::ValueData::U64(value) = snapshot.data() else {
        panic!("expected U64 cell")
    };
    *value
}

#[test]
fn resident_projection_uses_the_realized_arena_without_a_second_allocation() {
    let domain = MemoryDomain::new().unwrap();
    let revision = domain.issue_plan_revision().unwrap();
    let allocations = [allocation(
        0,
        0,
        0,
        16,
        16,
        MemoryLifetime::Activation,
        None,
    )];
    let arenas = [arena(0, ArenaBackingKind::ContiguousBytes, 16, &[0])];
    let reservation = domain
        .prepare_realization(runtime_plan_view(
            revision,
            &allocations,
            &arenas,
            ResourceDemand {
                activation_bytes: 16,
                ..ResourceDemand::default()
            },
            MemoryBudgetLimits::default(),
            &[],
        ))
        .unwrap();
    let realized = domain.materialize(reservation).unwrap();
    let object = domain
        .plan_object_key(revision, MemoryObjectId::new(0))
        .unwrap();
    let mut storage = domain
        .project_host_arena::<u64>(&realized, MemoryArenaId::new(0), 2)
        .unwrap();
    let managed_write = domain
        .prepare_call(
            &realized,
            &[CallAccessRequest {
                object,
                mode: MemoryAccessMode::Write,
                region: MemoryAccessRegion::Contiguous {
                    offset_bytes: 0,
                    length_bytes: 16,
                },
            }],
        )
        .unwrap();
    assert!(matches!(
        domain.acquire_call(&realized, &managed_write),
        Err(MemoryRuntimeError::BorrowConflict { .. })
    ));
    assert!(
        domain
            .project_host_arena::<u64>(&realized, MemoryArenaId::new(0), 2)
            .is_err(),
        "one physical arena cannot acquire two simultaneous typed owners",
    );
    let committed = domain.ledger().committed_bytes;
    storage[0] = 11;
    storage[1] = 22;
    assert_eq!(&*storage, &[11, 22]);
    assert_eq!(domain.ledger().committed_bytes, committed);
    drop(storage);
    let held = domain.acquire_call(&realized, &managed_write).unwrap();
    assert!(matches!(
        domain.project_host_arena::<u64>(&realized, MemoryArenaId::new(0), 2),
        Err(MemoryRuntimeError::BorrowConflict { .. })
    ));
    drop(held);
    assert!(
        domain
            .project_host_arena::<u64>(&realized, MemoryArenaId::new(0), 2)
            .is_ok(),
        "dropping the typed projection releases only its claim, not the arena",
    );
}

#[test]
fn resident_projection_requires_one_planned_slot_kind_across_the_complete_arena() {
    let domain = MemoryDomain::new().unwrap();
    let wrong_slot_revision = domain.issue_plan_revision().unwrap();
    let wrong_slot_allocations = [allocation(0, 0, 0, 8, 8, MemoryLifetime::Activation, None)];
    let wrong_slot_arenas = [arena(0, ArenaBackingKind::ContiguousBytes, 8, &[0])];
    let wrong_slot = domain
        .materialize(
            domain
                .prepare_realization(runtime_plan_view(
                    wrong_slot_revision,
                    &wrong_slot_allocations,
                    &wrong_slot_arenas,
                    ResourceDemand {
                        activation_bytes: 8,
                        ..ResourceDemand::default()
                    },
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    assert!(matches!(
        domain.project_host_arena::<f64>(&wrong_slot, MemoryArenaId::new(0), 1),
        Err(MemoryRuntimeError::InvalidLayout {
            reason: "resident arena element type does not match its planned slot",
            ..
        })
    ));

    let packed_revision = domain.issue_plan_revision().unwrap();
    let packed_allocations = [
        allocation(1, 1, 0, 8, 8, MemoryLifetime::Activation, None),
        allocation(2, 1, 8, 8, 8, MemoryLifetime::Activation, None),
    ];
    let packed_arenas = [arena(1, ArenaBackingKind::ContiguousBytes, 16, &[1, 2])];
    let packed = domain
        .materialize(
            domain
                .prepare_realization(runtime_plan_view(
                    packed_revision,
                    &packed_allocations,
                    &packed_arenas,
                    ResourceDemand {
                        activation_bytes: 16,
                        ..ResourceDemand::default()
                    },
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    assert!(
        domain
            .project_host_arena::<u64>(&packed, MemoryArenaId::new(1), 2)
            .is_ok()
    );

    let index_mixed_revision = domain.issue_plan_revision().unwrap();
    let mut index_member = allocation(6, 3, 8, 8, 8, MemoryLifetime::Activation, None);
    index_member.slot = Some(mech_core::PlannedSlotKind::FixedScalar(
        mech_core::ScalarMemoryKind::Index,
    ));
    let index_mixed_allocations = [
        allocation(5, 3, 0, 8, 8, MemoryLifetime::Activation, None),
        index_member,
    ];
    let index_mixed_arenas = [arena(3, ArenaBackingKind::ContiguousBytes, 16, &[5, 6])];
    let index_mixed = domain
        .materialize(
            domain
                .prepare_realization(runtime_plan_view(
                    index_mixed_revision,
                    &index_mixed_allocations,
                    &index_mixed_arenas,
                    ResourceDemand {
                        activation_bytes: 16,
                        ..ResourceDemand::default()
                    },
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    assert!(matches!(
        domain.project_host_arena::<u64>(&index_mixed, MemoryArenaId::new(3), 2),
        Err(MemoryRuntimeError::InvalidLayout {
            reason: "resident arena projection requires one exact planned slot kind",
            ..
        })
    ));

    let empty_index_mixed_revision = domain.issue_plan_revision().unwrap();
    let mut empty_index_member = allocation(8, 4, 8, 0, 0, MemoryLifetime::Activation, None);
    empty_index_member.slot = Some(mech_core::PlannedSlotKind::FixedScalar(
        mech_core::ScalarMemoryKind::Index,
    ));
    let empty_index_mixed_allocations = [
        allocation(7, 4, 0, 8, 8, MemoryLifetime::Activation, None),
        empty_index_member,
    ];
    let empty_index_mixed_arenas = [arena(4, ArenaBackingKind::ContiguousBytes, 8, &[7, 8])];
    let empty_index_mixed = domain
        .materialize(
            domain
                .prepare_realization(runtime_plan_view(
                    empty_index_mixed_revision,
                    &empty_index_mixed_allocations,
                    &empty_index_mixed_arenas,
                    ResourceDemand {
                        activation_bytes: 8,
                        ..ResourceDemand::default()
                    },
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    assert!(matches!(
        domain.project_host_arena::<u64>(&empty_index_mixed, MemoryArenaId::new(4), 1),
        Err(MemoryRuntimeError::InvalidLayout {
            reason: "resident arena projection requires one exact planned slot kind",
            ..
        })
    ));

    let mixed_revision = domain.issue_plan_revision().unwrap();
    let mixed_allocations = [
        allocation(3, 2, 0, 8, 8, MemoryLifetime::Activation, None),
        f64_allocation(4, 2, 8, 8, 8, MemoryLifetime::Activation),
    ];
    let mixed_arenas = [arena(2, ArenaBackingKind::ContiguousBytes, 16, &[3, 4])];
    let mixed = domain
        .materialize(
            domain
                .prepare_realization(runtime_plan_view(
                    mixed_revision,
                    &mixed_allocations,
                    &mixed_arenas,
                    ResourceDemand {
                        activation_bytes: 16,
                        ..ResourceDemand::default()
                    },
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    assert!(matches!(
        domain.project_host_arena::<u64>(&mixed, MemoryArenaId::new(2), 2),
        Err(MemoryRuntimeError::InvalidLayout {
            reason: "resident arena element type does not match its planned slot",
            ..
        })
    ));
}

#[test]
fn rejected_resident_projection_layout_preserves_initialization() {
    let domain = MemoryDomain::new().unwrap();
    let revision = domain.issue_plan_revision().unwrap();
    let allocations = [allocation(
        0,
        0,
        0,
        16,
        16,
        MemoryLifetime::Activation,
        None,
    )];
    let arenas = [arena(0, ArenaBackingKind::ContiguousBytes, 16, &[0])];
    let realized = domain
        .materialize(
            domain
                .prepare_realization(runtime_plan_view(
                    revision,
                    &allocations,
                    &arenas,
                    ResourceDemand {
                        activation_bytes: 16,
                        ..ResourceDemand::default()
                    },
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    let object = domain
        .plan_object_key(revision, MemoryObjectId::new(0))
        .unwrap();
    let write = domain
        .prepare_call(
            &realized,
            &[CallAccessRequest {
                object,
                mode: MemoryAccessMode::Write,
                region: MemoryAccessRegion::Contiguous {
                    offset_bytes: 0,
                    length_bytes: 16,
                },
            }],
        )
        .unwrap();
    domain
        .acquire_call(&realized, &write)
        .unwrap()
        .with_object_init_writer::<u64>(object, |writer| {
            writer.write_next(11)?;
            writer.write_next(22)
        })
        .unwrap();
    assert_eq!(realized.binding(object).unwrap().initialized_bytes(), 16);

    assert!(matches!(
        domain.project_host_arena::<u64>(&realized, MemoryArenaId::new(0), 1),
        Err(MemoryRuntimeError::InvalidLayout {
            reason: "resident lane type does not exactly cover its planned arena",
            ..
        })
    ));
    assert_eq!(realized.binding(object).unwrap().initialized_bytes(), 16);
    let read = domain
        .prepare_call(
            &realized,
            &[CallAccessRequest {
                object,
                mode: MemoryAccessMode::Read,
                region: MemoryAccessRegion::WholeInitialized,
            }],
        )
        .unwrap();
    assert!(domain.acquire_call(&realized, &read).is_ok());
}

#[cfg(feature = "bool")]
#[test]
fn resident_projection_revokes_managed_initialization_before_mutable_access() {
    let domain = MemoryDomain::new().unwrap();
    let revision = domain.issue_plan_revision().unwrap();
    let mut bool_allocation = allocation(0, 0, 0, 1, 1, MemoryLifetime::Activation, None);
    bool_allocation.slot = Some(mech_core::PlannedSlotKind::FixedScalar(
        mech_core::ScalarMemoryKind::Bool,
    ));
    bool_allocation.alignment = 1;
    let allocations = [bool_allocation];
    let arenas = [arena(0, ArenaBackingKind::ContiguousBytes, 1, &[0])];
    let realized = domain
        .materialize(
            domain
                .prepare_realization(runtime_plan_view(
                    revision,
                    &allocations,
                    &arenas,
                    ResourceDemand {
                        activation_bytes: 1,
                        ..ResourceDemand::default()
                    },
                    MemoryBudgetLimits::default(),
                    &[],
                ))
                .unwrap(),
        )
        .unwrap();
    let object = domain
        .plan_object_key(revision, MemoryObjectId::new(0))
        .unwrap();
    let write = domain
        .prepare_call(
            &realized,
            &[CallAccessRequest {
                object,
                mode: MemoryAccessMode::Write,
                region: MemoryAccessRegion::Contiguous {
                    offset_bytes: 0,
                    length_bytes: 1,
                },
            }],
        )
        .unwrap();
    domain
        .acquire_call(&realized, &write)
        .unwrap()
        .with_object_init_writer::<bool>(object, |writer| writer.write_next(true))
        .unwrap();
    assert_eq!(realized.binding(object).unwrap().initialized_bytes(), 1);

    let mut projection = domain
        .project_host_arena::<u8>(&realized, MemoryArenaId::new(0), 1)
        .unwrap();
    projection[0] = 2;
    drop(projection);

    assert_eq!(realized.binding(object).unwrap().initialized_bytes(), 0);
    assert!(matches!(
        domain.prepare_call(
            &realized,
            &[CallAccessRequest {
                object,
                mode: MemoryAccessMode::Read,
                region: MemoryAccessRegion::WholeInitialized,
            }],
        ),
        Err(MemoryRuntimeError::UninitializedAccess { .. })
    ));
}
