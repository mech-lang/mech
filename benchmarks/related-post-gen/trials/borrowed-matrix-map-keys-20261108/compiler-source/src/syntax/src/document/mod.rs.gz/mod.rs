#![forbid(unsafe_code)]

//! Lossless canonical document syntax infrastructure.

extern crate alloc;

pub mod annotation;
pub mod ast;
pub mod builder;
pub mod diagnostic;
pub mod edit;
pub mod fence;
pub mod flags;
pub mod green;
pub mod ids;
pub mod incremental;
pub mod index;
pub mod line_index;
pub mod parser;
pub mod pointer;
pub mod red;
mod retained_sequence;
pub mod source;
mod submission;
pub mod syntax_kind;

use alloc::sync::Arc;
use alloc::vec::Vec;

pub use annotation::*;
pub use ast::*;
pub use builder::*;
pub use diagnostic::*;
pub use edit::*;
pub use fence::*;
pub use flags::*;
pub use green::*;
pub use ids::*;
pub use incremental::*;
pub use index::*;
pub use line_index::*;
pub use parser::stream::*;
pub use parser::{
    GrammarFragmentContext, GrammarFragmentKind, GrammarFragmentSnapshot, ParseConfig, ParseLimits,
    parse_canonical_document, parse_canonical_grammar, parse_canonical_grammar_fragment,
};
pub use pointer::*;
pub use red::*;
pub use source::*;
pub use submission::*;
pub use syntax_kind::*;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RestartMode {
    Document,
    Paragraph,
    Mech,
    Fence,
    Grammar,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct RestartEntry {
    pub node: NodeId,
    pub range: TextRange,
    pub mode: RestartMode,
    pub delimiter_depth: u32,
    pub line_start: bool,
    pub indentation: u32,
}

#[derive(Clone, Debug, Default)]
pub struct RestartIndex {
    entries: Vec<RestartEntry>,
}

impl RestartIndex {
    pub fn push(&mut self, entry: RestartEntry) {
        self.entries.push(entry);
    }

    pub fn iter(&self) -> impl Iterator<Item = &RestartEntry> {
        self.entries.iter()
    }

    pub fn as_slice(&self) -> &[RestartEntry] {
        &self.entries
    }

    pub fn get(&self, node: NodeId) -> Option<&RestartEntry> {
        self.entries.iter().find(|entry| entry.node == node)
    }
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub struct ParseStats {
    pub source_bytes: u64,
    pub parser_steps: u64,
    pub events_emitted: u64,
    pub diagnostics_emitted: u64,
    pub diagnostics_truncated: bool,
    /// Cumulative recovery work, including bytes scanned by rejected alternatives.
    pub recovery_bytes: u64,
    pub reparse_root_count: u64,
    pub reused_node_count: u64,
    pub new_node_count: u64,
}

#[derive(Clone, Debug)]
pub struct SyntaxSnapshot {
    pub document: DocumentId,
    pub revision: Revision,
    pub source: TextSnapshot,
    pub root: Arc<GreenNode>,
    pub diagnostics: DiagnosticStore,
    pub nodes: NodeIndex,
    pub restarts: RestartIndex,
    pub stats: ParseStats,
}

impl SyntaxSnapshot {
    pub fn new(source: TextSnapshot, root: Arc<GreenNode>, diagnostics: DiagnosticStore) -> Self {
        let document = source.document();
        let revision = source.revision();
        let nodes = NodeIndex::build(&root);
        Self {
            document,
            revision,
            source,
            root,
            diagnostics,
            nodes,
            restarts: RestartIndex::default(),
            stats: ParseStats::default(),
        }
    }

    pub fn syntax(&self) -> SyntaxNode {
        SyntaxNode::new_root(self.root.clone(), self.source.clone())
    }

    pub fn is_strictly_clean(&self) -> bool {
        self.diagnostics.is_empty()
            && !self.stats.diagnostics_truncated
            && !self
                .root
                .flags
                .intersects(NodeFlags::CONTAINS_ERROR | NodeFlags::CONTAINS_MISSING)
    }
}
