use std::collections::{BTreeMap, BTreeSet};
use std::fs;
use std::path::PathBuf;

const EXPECTED_RULES: usize = 543;
const EXPECTED_EXECUTABLE_RULES: usize = 83;
const EXPECTED_EXECUTABLE_COMPONENTS: usize = 1;
const DEPENDENCY_HEADER: &str = "grammar-name\tdirect-children\tdirect-parents";
const SCC_HEADER: &str = "component-id\tcomponent-size\trecursive\tmembers\t\
                          outgoing-components\toutgoing-supporting-rules";
const COMPONENT_HEADER: &str = "grammar-name\tfamily\tcomponent-id\tcomponent-size\t\
                            recursive-component\tsame-component-children\tclosure-children\t\
                            supporting-external-children";

const ANCHORS: &[&str] = &[
    "expression",
    "formula",
    "factor",
    "literal",
    "kind-annotation",
    "kind",
    "kind-scalar",
    "var",
    "subscript",
    "slice",
    "structure",
    "matrix",
    "map",
    "set",
    "tuple",
    "function-call",
    "pattern",
    "comprehension-qualifier",
    "variable-define",
    "fsm-pipe",
];

#[derive(Clone, Debug)]
struct Port {
    family: String,
    syntax: String,
    semantic: String,
    scope: String,
    policy: String,
    component: String,
}

#[derive(Clone, Debug)]
struct SccRow {
    id: String,
    size: usize,
    recursive: bool,
    members: BTreeSet<String>,
    outgoing_components: BTreeSet<String>,
    outgoing_supporting: BTreeSet<String>,
}

#[derive(Clone, Debug)]
struct ComponentRow {
    family: String,
    component_id: String,
    component_size: usize,
    recursive: bool,
    same_component: BTreeSet<String>,
    closure_children: BTreeSet<String>,
    supporting_external: BTreeSet<String>,
}

fn repository_root() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../..")
}

fn fields(line: &str) -> Vec<&str> {
    line.split('\t').collect()
}

fn parse_name_list(field: &str) -> BTreeSet<String> {
    if field == "none" {
        return BTreeSet::new();
    }
    let names = field
        .split('|')
        .map(str::trim)
        .map(str::to_owned)
        .collect::<BTreeSet<_>>();
    assert!(!names.contains(""), "list contains an empty name");
    assert_eq!(names.len(), field.split('|').count(), "duplicate list name");
    names
}

fn parse_bool(field: &str) -> bool {
    match field {
        "true" => true,
        "false" => false,
        other => panic!("invalid boolean {other}"),
    }
}

fn canonical_inventory_names() -> BTreeSet<String> {
    let source = fs::read_to_string(repository_root().join("docs/design/grammar-audit/ports.tsv"))
        .expect("read ports.tsv");
    let mut lines = source.lines();
    let header = fields(lines.next().expect("ports.tsv header"));
    let name = header
        .iter()
        .position(|field| *field == "grammar-name")
        .unwrap();
    let names = lines
        .map(fields)
        .map(|row| row[name].to_owned())
        .collect::<BTreeSet<_>>();
    assert_eq!(names.len(), EXPECTED_RULES);
    names
}

fn dependencies() -> BTreeMap<String, BTreeSet<String>> {
    let source = fs::read_to_string(
        repository_root().join("docs/design/grammar-audit/canonical-dependencies.tsv"),
    )
    .expect("read canonical-dependencies.tsv");
    let mut lines = source.lines();
    assert_eq!(lines.next(), Some(DEPENDENCY_HEADER));
    let mut previous = String::new();
    let mut graph = BTreeMap::new();
    let mut reported_parents = BTreeMap::new();
    for (index, line) in lines.enumerate() {
        assert!(!line.is_empty(), "blank dependency row {}", index + 2);
        let row = fields(line);
        assert_eq!(row.len(), 3, "invalid dependency row {}", index + 2);
        assert!(
            row[0] > previous.as_str(),
            "dependency rows are not ordered"
        );
        previous = row[0].to_owned();
        assert!(
            graph
                .insert(row[0].to_owned(), parse_name_list(row[1]))
                .is_none()
        );
        reported_parents.insert(row[0].to_owned(), parse_name_list(row[2]));
    }
    assert_eq!(graph.len(), EXPECTED_RULES);
    let mut reversed = graph
        .keys()
        .map(|name| (name.clone(), BTreeSet::new()))
        .collect::<BTreeMap<_, _>>();
    for (parent, children) in &graph {
        for child in children {
            reversed
                .get_mut(child)
                .unwrap_or_else(|| panic!("unknown dependency {child}"))
                .insert(parent.clone());
        }
    }
    assert_eq!(reported_parents, reversed);
    graph
}

fn ports() -> BTreeMap<String, Port> {
    let source = fs::read_to_string(repository_root().join("docs/design/grammar-audit/ports.tsv"))
        .expect("read ports.tsv");
    let mut lines = source.lines();
    assert_eq!(
        lines.next(),
        Some(
            "grammar-name\tfamily\tsyntax-status\tsemantic-status\t\
             grammar-scope\tnode-policy\tcomponent\tnotes"
        )
    );
    let mut previous = String::new();
    let mut ports = BTreeMap::new();
    for (index, line) in lines.enumerate() {
        assert!(!line.is_empty(), "blank port row {}", index + 2);
        let row = fields(line);
        assert_eq!(row.len(), 8, "invalid port row {}", index + 2);
        assert!(row[0] > previous.as_str(), "ports are not ordered");
        previous = row[0].to_owned();
        assert!(
            ports
                .insert(
                    row[0].to_owned(),
                    Port {
                        family: row[1].to_owned(),
                        syntax: row[2].to_owned(),
                        semantic: row[3].to_owned(),
                        scope: row[4].to_owned(),
                        policy: row[5].to_owned(),
                        component: row[6].to_owned(),
                    },
                )
                .is_none()
        );
    }
    assert_eq!(ports.len(), EXPECTED_RULES);
    ports
}

fn scc_report() -> BTreeMap<String, SccRow> {
    let source = fs::read_to_string(
        repository_root().join("docs/design/grammar-audit/grammar-component-boundaries.tsv"),
    )
    .expect("read grammar-component-boundaries.tsv");
    let mut lines = source.lines();
    assert_eq!(lines.next(), Some(SCC_HEADER));
    let mut rows = BTreeMap::new();
    let mut all_members = BTreeSet::new();
    for (index, line) in lines.enumerate() {
        assert!(!line.is_empty(), "blank SCC row {}", index + 2);
        let row = fields(line);
        assert_eq!(row.len(), 6, "invalid SCC row {}", index + 2);
        let members = parse_name_list(row[3]);
        let size = row[1].parse::<usize>().expect("component size");
        assert_eq!(size, members.len(), "component size for {}", row[0]);
        for member in &members {
            assert!(
                all_members.insert(member.clone()),
                "duplicate SCC member {member}"
            );
        }
        let value = SccRow {
            id: row[0].to_owned(),
            size,
            recursive: parse_bool(row[2]),
            members,
            outgoing_components: parse_name_list(row[4]),
            outgoing_supporting: parse_name_list(row[5]),
        };
        assert!(rows.insert(row[0].to_owned(), value).is_none());
    }
    rows
}

fn component_report() -> BTreeMap<String, ComponentRow> {
    let source =
        fs::read_to_string(repository_root().join("docs/design/grammar-audit/recursive-core.tsv"))
            .expect("read recursive-core.tsv");
    let mut lines = source.lines();
    assert_eq!(lines.next(), Some(COMPONENT_HEADER));
    let mut previous = String::new();
    let mut rows = BTreeMap::new();
    for (index, line) in lines.enumerate() {
        assert!(
            !line.is_empty(),
            "blank executable grammar row {}",
            index + 2
        );
        let row = fields(line);
        assert_eq!(row.len(), 8, "invalid executable grammar row {}", index + 2);
        assert!(
            row[0] > previous.as_str(),
            "executable grammar rows are not ordered"
        );
        previous = row[0].to_owned();
        let value = ComponentRow {
            family: row[1].to_owned(),
            component_id: row[2].to_owned(),
            component_size: row[3].parse().expect("executable grammar component size"),
            recursive: parse_bool(row[4]),
            same_component: parse_name_list(row[5]),
            closure_children: parse_name_list(row[6]),
            supporting_external: parse_name_list(row[7]),
        };
        assert!(rows.insert(row[0].to_owned(), value).is_none());
    }
    rows
}

fn visit(
    node: &str,
    graph: &BTreeMap<String, BTreeSet<String>>,
    visited: &mut BTreeSet<String>,
    order: &mut Vec<String>,
) {
    if !visited.insert(node.to_owned()) {
        return;
    }
    for child in &graph[node] {
        visit(child, graph, visited, order);
    }
    order.push(node.to_owned());
}

fn collect_component(
    node: &str,
    reversed: &BTreeMap<String, BTreeSet<String>>,
    visited: &mut BTreeSet<String>,
    members: &mut BTreeSet<String>,
) {
    if !visited.insert(node.to_owned()) {
        return;
    }
    members.insert(node.to_owned());
    for parent in &reversed[node] {
        collect_component(parent, reversed, visited, members);
    }
}

fn components(graph: &BTreeMap<String, BTreeSet<String>>) -> Vec<BTreeSet<String>> {
    let mut visited = BTreeSet::new();
    let mut order = Vec::new();
    for node in graph.keys() {
        visit(node, graph, &mut visited, &mut order);
    }
    let mut reversed = graph
        .keys()
        .map(|name| (name.clone(), BTreeSet::new()))
        .collect::<BTreeMap<_, _>>();
    for (parent, children) in graph {
        for child in children {
            reversed.get_mut(child).unwrap().insert(parent.clone());
        }
    }
    visited.clear();
    let mut components = Vec::new();
    for node in order.into_iter().rev() {
        if visited.contains(&node) {
            continue;
        }
        let mut members = BTreeSet::new();
        collect_component(&node, &reversed, &mut visited, &mut members);
        components.push(members);
    }
    components.sort_by(|left, right| {
        right
            .len()
            .cmp(&left.len())
            .then_with(|| left.iter().cmp(right.iter()))
    });
    components
}

fn component_by_rule(components: &[BTreeSet<String>]) -> BTreeMap<String, usize> {
    components
        .iter()
        .enumerate()
        .flat_map(|(index, component)| component.iter().cloned().map(move |member| (member, index)))
        .collect()
}

fn is_non_supporting(port: &Port) -> bool {
    port.scope != "supporting"
}

fn is_certified(port: &Port) -> bool {
    port.syntax == "certified"
}

#[test]
fn report_schemas_ordering_and_uniqueness_are_exact() {
    let graph = dependencies();
    let ports = ports();
    let inventory = canonical_inventory_names();
    assert_eq!(graph.keys().cloned().collect::<BTreeSet<_>>(), inventory);
    assert_eq!(ports.keys().cloned().collect::<BTreeSet<_>>(), inventory);

    let components = components(&graph);
    let by_rule = component_by_rule(&components);
    let component = component_report();
    assert_eq!(component.len(), EXPECTED_EXECUTABLE_RULES);
    let components_in_report = component
        .values()
        .map(|row| row.component_id.as_str())
        .collect::<BTreeSet<_>>();
    assert_eq!(components_in_report.len(), EXPECTED_EXECUTABLE_COMPONENTS);
    for (name, row) in &component {
        let component_index = by_rule[name];
        let component = &components[component_index];
        assert!(component.contains(name));
        assert_eq!(row.component_id, format!("SCC-{:04}", component_index + 1));
        assert_eq!(row.component_size, component.len());
        assert_eq!(
            row.recursive,
            component.len() > 1 || graph[name].contains(name)
        );
    }
}

#[test]
fn kosaraju_independently_recomputes_every_non_supporting_component() {
    let graph = dependencies();
    let ports = ports();
    let components = components(&graph);
    let by_rule = component_by_rule(&components);
    let report = scc_report();
    let reported_by_member = report
        .values()
        .flat_map(|row| row.members.iter().cloned().map(move |member| (member, row)))
        .collect::<BTreeMap<_, _>>();

    for component in &components {
        let inactive = component
            .iter()
            .filter(|member| is_non_supporting(&ports[*member]))
            .count();
        assert!(
            inactive == 0 || inactive == component.len(),
            "mixed grammar-scope SCC: {component:?}"
        );
    }

    let non_supporting_names = ports
        .iter()
        .filter_map(|(name, port)| is_non_supporting(port).then_some(name.clone()))
        .collect::<BTreeSet<_>>();
    assert_eq!(
        reported_by_member.keys().cloned().collect::<BTreeSet<_>>(),
        non_supporting_names
    );

    let reported_id_by_component = report
        .values()
        .map(|row| (row.members.clone(), row.id.clone()))
        .collect::<BTreeMap<_, _>>();
    for name in &non_supporting_names {
        let component = &components[by_rule[name]];
        let row = reported_by_member[name];
        assert_eq!(&row.members, component, "SCC membership for {name}");
        assert_eq!(row.size, component.len(), "SCC size for {name}");
        let recursive = component.len() > 1 || graph[name].contains(name);
        assert_eq!(row.recursive, recursive, "recursive flag for {name}");
    }

    for row in report.values() {
        let mut outgoing_components = BTreeSet::new();
        let mut outgoing_supporting = BTreeSet::new();
        for member in &row.members {
            for child in &graph[member] {
                if row.members.contains(child) {
                    continue;
                }
                if is_non_supporting(&ports[child]) {
                    let target = &components[by_rule[child]];
                    outgoing_components.insert(reported_id_by_component[target].clone());
                } else {
                    assert!(is_certified(&ports[child]));
                    outgoing_supporting.insert(child.clone());
                }
            }
        }
        assert_eq!(
            row.outgoing_components, outgoing_components,
            "outgoing SCCs for {}",
            row.id
        );
        assert_eq!(
            row.outgoing_supporting, outgoing_supporting,
            "supporting dependencies for {}",
            row.id
        );
    }
}

#[test]
fn expression_root_certification_is_exact_and_dependency_closed() {
    let graph = dependencies();
    let ports = ports();
    let component = component_report();
    let component_names = component.keys().cloned().collect::<BTreeSet<_>>();
    let components = components(&graph);
    let by_rule = component_by_rule(&components);
    let root_component = by_rule["expression"];
    assert_eq!(components[root_component], component_names);
    assert!(
        component_names
            .iter()
            .all(|name| is_certified(&ports[name]))
    );

    let external = component_names
        .iter()
        .flat_map(|name| graph[name].iter())
        .filter(|child| !component_names.contains(*child))
        .cloned()
        .collect::<BTreeSet<_>>();

    let reported_external = component
        .values()
        .flat_map(|row| row.supporting_external.iter().cloned())
        .collect::<BTreeSet<_>>();
    assert_eq!(external, reported_external);
    assert_eq!(external.len(), 75);
}

#[test]
fn component_boundary_rows_preserve_all_port_and_edge_invariants() {
    let graph = dependencies();
    let ports = ports();
    let component = component_report();
    let component_names = component.keys().cloned().collect::<BTreeSet<_>>();
    let by_component = component.iter().fold(
        BTreeMap::<String, BTreeSet<String>>::new(),
        |mut grouped, (name, row)| {
            grouped
                .entry(row.component_id.clone())
                .or_default()
                .insert(name.clone());
            grouped
        },
    );

    for (name, row) in &component {
        let port = &ports[name];
        assert_eq!(row.family, port.family);
        assert!(is_certified(port));
        assert_eq!(port.component, "executable");
        assert_ne!(port.policy, "undecided");
        assert_eq!(port.semantic, "certified");
        assert_eq!(port.scope, "executable-core");

        let mut same_component = BTreeSet::new();
        let mut closure_children = BTreeSet::new();
        let mut supporting_external = BTreeSet::new();
        for child in &graph[name] {
            if by_component[&row.component_id].contains(child) {
                same_component.insert(child.clone());
            } else if component_names.contains(child) {
                closure_children.insert(child.clone());
            } else {
                assert!(is_certified(&ports[child]), "non-supporting child {child}");
                assert_eq!(ports[child].scope, "supporting");
                supporting_external.insert(child.clone());
            }
        }
        assert_eq!(
            row.same_component, same_component,
            "same-component children for {name}"
        );
        assert_eq!(
            row.closure_children, closure_children,
            "closure children for {name}"
        );
        assert_eq!(
            row.supporting_external, supporting_external,
            "external children for {name}"
        );
    }
}

#[test]
fn reviewed_count_anchors_and_families_are_frozen() {
    let component = component_report();
    assert_eq!(component.len(), EXPECTED_EXECUTABLE_RULES);
    let components = component
        .values()
        .map(|row| row.component_id.as_str())
        .collect::<BTreeSet<_>>();
    assert_eq!(components.len(), EXPECTED_EXECUTABLE_COMPONENTS);
    for anchor in ANCHORS {
        assert!(
            component.contains_key(*anchor),
            "missing executable grammar anchor {anchor}"
        );
    }
    for (name, row) in &component {
        assert!(
            !matches!(
                row.family.as_str(),
                "mechdown" | "mika" | "repl" | "activation" | "parser"
            ),
            "forbidden executable grammar family for {name}: {}",
            row.family
        );
    }
}

#[test]
fn recursive_core_has_exact_parser_typed_views_and_executable_registry() {
    let root = repository_root();
    let parser_directory = root.join("src/syntax/src/document/parser/canonical/recursive_core");
    assert!(parser_directory.is_dir());
    let actual_files = fs::read_dir(&parser_directory)
        .expect("read recursive parser directory")
        .map(|entry| {
            entry
                .expect("read recursive parser entry")
                .file_name()
                .to_string_lossy()
                .into_owned()
        })
        .collect::<BTreeSet<_>>();
    let expected_files = [
        "calls.rs",
        "comprehensions.rs",
        "expressions.rs",
        "fsm.rs",
        "kinds.rs",
        "literals.rs",
        "mod.rs",
        "patterns.rs",
        "precedence.rs",
        "structures.rs",
        "subscripts.rs",
        "variables.rs",
    ]
    .into_iter()
    .map(str::to_owned)
    .collect::<BTreeSet<_>>();
    let mut expected_parser_files = expected_files.clone();
    expected_parser_files.remove("precedence.rs");
    expected_parser_files.remove("kinds.rs");
    expected_parser_files.remove("structures.rs");
    expected_parser_files.insert(String::from("structures"));
    expected_parser_files.insert(String::from("kinds"));
    expected_parser_files.insert(String::from("precedence"));
    expected_parser_files.insert(String::from("required.rs"));
    assert_eq!(actual_files, expected_parser_files);
    let precedence_files = fs::read_dir(parser_directory.join("precedence"))
        .expect("read retained precedence module")
        .map(|entry| {
            entry
                .expect("precedence entry")
                .file_name()
                .to_string_lossy()
                .into_owned()
        })
        .collect::<BTreeSet<_>>();
    assert_eq!(
        precedence_files,
        ["mod.rs", "continuation"]
            .into_iter()
            .map(str::to_owned)
            .collect()
    );

    let ast_directory = root.join("src/syntax/src/document/ast/recursive_core");
    assert!(ast_directory.is_dir());
    let actual_ast_files = fs::read_dir(&ast_directory)
        .expect("read recursive typed-view directory")
        .map(|entry| {
            entry
                .expect("read recursive typed-view entry")
                .file_name()
                .to_string_lossy()
                .into_owned()
        })
        .collect::<BTreeSet<_>>();
    assert_eq!(actual_ast_files, expected_files);
    assert!(
        !root
            .join("src/syntax/src/document/lower/legacy/recursive_core")
            .exists(),
        "the retired recursive lowerer must not be recreated"
    );

    let component = component_report();
    let ports = ports();
    assert_eq!(component.len(), EXPECTED_EXECUTABLE_RULES);
    for name in component.keys() {
        let port = &ports[name];
        assert!(is_certified(port), "{name}");
        assert_eq!(port.semantic, "certified", "{name}");
        assert_eq!(port.scope, "executable-core", "{name}");
        assert_ne!(port.policy, "undecided", "{name}");
        assert_eq!(port.component, "executable", "{name}");
    }
}

#[test]
fn recursive_dispatcher_and_production_functions_match_the_certified_inventory() {
    let root = repository_root();
    let parser_directory = root.join("src/syntax/src/document/parser/canonical/recursive_core");
    let expected_functions = component_report()
        .keys()
        .map(|name| format!("parse_{}", name.replace('-', "_")))
        .collect::<BTreeSet<_>>();
    assert_eq!(expected_functions.len(), EXPECTED_EXECUTABLE_RULES);

    let mut actual_functions = BTreeSet::new();
    let mut pending = vec![parser_directory.clone()];
    while let Some(path) = pending.pop() {
        if path.is_dir() {
            pending.extend(
                fs::read_dir(&path)
                    .expect("read recursive parser directory")
                    .map(|entry| entry.expect("read recursive parser entry").path()),
            );
            continue;
        }
        if path == parser_directory.join("mod.rs") {
            continue;
        }
        assert_eq!(
            path.extension().and_then(|extension| extension.to_str()),
            Some("rs")
        );
        let source = fs::read_to_string(&path).expect("read recursive production module");
        for suffix in source.split("pub(super) fn ").skip(1) {
            let name = suffix.split('(').next().expect("function name").trim();
            if name.starts_with("parse_") {
                assert!(
                    actual_functions.insert(name.to_owned()),
                    "duplicate production function {name}"
                );
            }
        }
    }
    assert_eq!(actual_functions, expected_functions);

    let module = fs::read_to_string(parser_directory.join("mod.rs")).expect("read dispatcher");
    let inventory_start = module.find("pub(crate) const EXECUTABLE_RULES").unwrap();
    let inventory_end = module[inventory_start..].find("];\n").unwrap() + inventory_start;
    let inventory = &module[inventory_start..inventory_end];
    assert_eq!(
        inventory.matches("rules::").count(),
        EXPECTED_EXECUTABLE_RULES
    );

    let dispatcher_start = module.find("pub(crate) fn parse_rule").unwrap();
    let dispatcher = &module[dispatcher_start..];
    assert_eq!(
        dispatcher
            .lines()
            .filter(|line| line.contains("rules::") && line.contains("=>"))
            .count(),
        EXPECTED_EXECUTABLE_RULES
    );
    assert!(dispatcher.contains("_ => return None"));
}
