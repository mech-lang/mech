use std::collections::BTreeMap;

use js_sys::{Array, Float32Array, Object, Reflect, Uint32Array};
use mech_core::{GpuMemoryLimits, MemoryLifetime, MemorySpace};
use mech_gpu::{
    GpuExecutionPlan, GpuKernelPlanSource, GpuPlanInitialValues, GpuPlanKernelKind, GpuPlanLayout,
    GpuPlanScalar, PlannedGpuExecution,
};
use wasm_bindgen::JsValue;
use web_time::Instant;

#[derive(Clone, Copy, Debug, Default)]
pub(crate) struct CompileTimings {
    pub(crate) catalog_setup: f64,
    pub(crate) parsing: f64,
    pub(crate) artifact_compilation: f64,
    pub(crate) gpu_lowering: f64,
    pub(crate) input_capture: f64,
}

pub(crate) fn gpu_program_manifest(
    program: GpuKernelPlanSource<'_>,
    input_values: &BTreeMap<String, Vec<f32>>,
    backend: &str,
    retained_outputs: &std::collections::BTreeSet<String>,
    timings: CompileTimings,
) -> Result<JsValue, JsValue> {
    let manifest_started = Instant::now();

    let manifest = Object::new();
    let execution = GpuExecutionPlan::build(program, input_values)
        .map_err(|failure| error(failure.to_string()))?;
    let plan = PlannedGpuExecution::from_execution(
        execution,
        GpuMemoryLimits {
            max_buffer_size: u64::MAX,
            max_storage_buffer_binding_size: u64::MAX,
            max_storage_buffers_per_shader_stage: u32::MAX,
            max_bindings_per_bind_group: u32::MAX,
            max_compute_workgroups_per_dimension: u32::MAX,
            max_compute_invocations_per_workgroup: u32::MAX,
            max_compute_workgroup_size_x: u32::MAX,
            min_storage_buffer_offset_alignment: 256,
        },
    )
    .map_err(|failure| error(failure.to_string()))?;
    let execution = &plan.execution;
    set(
        &manifest,
        "physicalRevision",
        execution
            .physical_revision_with_retained_outputs(backend, retained_outputs)
            .map_err(|failure| error(failure.to_string()))?,
    )?;
    set(&manifest, "planVersion", execution.version)?;
    set(
        &manifest,
        "kernelKind",
        match execution.kernel_kind {
            GpuPlanKernelKind::Elementwise => "elementwise",
            GpuPlanKernelKind::FixedShape => "fixed-shape",
        },
    )?;
    set(&manifest, "wgsl", execution.wgsl.as_str())?;
    set(&manifest, "workgroupSize", execution.workgroup_size)?;
    set(&manifest, "dispatchElements", execution.dispatch_elements)?;

    let bindings = Array::new();
    for binding in &execution.bindings {
        let encoded = binding_value(
            binding.binding,
            &binding.name,
            match binding.access {
                mech_gpu::GpuBindingAccess::Read => "read",
                mech_gpu::GpuBindingAccess::ReadWrite => "read-write",
            },
            match binding.role {
                mech_gpu::GpuExecutionBindingRole::Input => "input",
                mech_gpu::GpuExecutionBindingRole::StateRead => "state-read",
                mech_gpu::GpuExecutionBindingRole::StateWrite => "state-write",
                mech_gpu::GpuExecutionBindingRole::Output => "output",
                mech_gpu::GpuExecutionBindingRole::IntegrityFault => "integrity-fault",
            },
            binding.slot,
            usize::try_from(binding.elements)
                .map_err(|_| error("GPU binding size exceeds the browser limit"))?,
            match binding.scalar {
                GpuPlanScalar::F32 => "f32",
                GpuPlanScalar::U32 => "u32",
            },
        )?;
        set(
            &encoded,
            "memoryObject",
            plan.binding_object(binding.binding)
                .ok_or_else(|| error("GPU binding has no managed memory object"))?
                .get(),
        )?;
        match &binding.initial_values {
            Some(GpuPlanInitialValues::F32(values)) => set(
                &encoded,
                "initialValues",
                Float32Array::from(values.as_slice()),
            )?,
            Some(GpuPlanInitialValues::U32(values)) => set(
                &encoded,
                "initialValues",
                Uint32Array::from(values.as_slice()),
            )?,
            None => {}
        }
        bindings.push(&encoded);
    }
    set(&manifest, "bindings", bindings)?;

    let constraints = Array::new();
    for constraint in &execution.constraints {
        let value = Object::new();
        set(&value, "code", constraint.code)?;
        set(&value, "id", constraint.id.to_string())?;
        set(&value, "name", constraint.name.as_str())?;
        constraints.push(&value);
    }
    set(&manifest, "constraints", constraints)?;

    let states = Array::new();
    for state in &execution.states {
        let value = Object::new();
        set(&value, "slot", state.slot)?;
        set(&value, "recurrence", state.recurrence)?;
        set(
            &value,
            "elements",
            u32::try_from(state.elements)
                .map_err(|_| error("GPU state size exceeds the browser limit"))?,
        )?;
        set(
            &value,
            "elementsPerInstance",
            u32::try_from(state.elements_per_instance)
                .map_err(|_| error("GPU state shape exceeds the browser limit"))?,
        )?;
        set(
            &value,
            "initialValues",
            Float32Array::from(state.initial_values.as_slice()),
        )?;
        let objects = plan
            .state_objects(mech_core::CellSlotId::new(state.slot))
            .ok_or_else(|| error("GPU state has no managed double buffer"))?;
        let memory_objects = Array::new();
        memory_objects.push(&JsValue::from_f64(objects[0].get() as f64));
        memory_objects.push(&JsValue::from_f64(objects[1].get() as f64));
        set(&value, "memoryObjects", memory_objects)?;
        states.push(&value);
    }
    set(&manifest, "states", states)?;

    let outputs = Array::new();
    for output in &execution.outputs {
        let value = Object::new();
        set(&value, "name", output.name.as_str())?;
        set(&value, "slot", output.slot)?;
        set(&value, "physicalOutput", output.physical_output)?;
        set(
            &value,
            "elements",
            u32::try_from(output.elements)
                .map_err(|_| error("GPU output size exceeds the browser limit"))?,
        )?;
        set(
            &value,
            "elementsPerInstance",
            u32::try_from(output.elements_per_instance)
                .map_err(|_| error("GPU output shape exceeds the browser limit"))?,
        )?;
        let dimensions = Array::new();
        let sample_dimensions = Array::new();
        for dimension in &output.dimensions {
            dimensions.push(&JsValue::from_f64(*dimension as f64));
        }
        for dimension in &output.sample_dimensions {
            sample_dimensions.push(&JsValue::from_f64(*dimension as f64));
        }
        set(&value, "dimensions", dimensions)?;
        set(&value, "sampleDimensions", sample_dimensions)?;
        set(
            &value,
            "physicalLayout",
            match output.physical_layout {
                GpuPlanLayout::RowMajor => "row-major",
                GpuPlanLayout::ColumnMajor => "column-major",
            },
        )?;
        outputs.push(&value);
    }
    set(&manifest, "outputs", outputs)?;

    let physical_outputs = Array::new();
    for output in &execution.physical_outputs {
        let value = Object::new();
        set(&value, "id", output.id)?;
        set(&value, "slot", output.slot)?;
        if let Some(binding) = output.binding {
            set(&value, "binding", binding)?;
        }
        set(
            &value,
            "sampleElements",
            u32::try_from(output.sample_elements)
                .map_err(|_| error("GPU sampled output size exceeds the browser limit"))?,
        )?;
        let slot = mech_core::CellSlotId::new(output.slot);
        set(
            &value,
            "readbackDeviceObject",
            plan.readback_device_object(slot)
                .ok_or_else(|| error("GPU output has no managed device readback object"))?
                .get(),
        )?;
        set(
            &value,
            "readbackHostObject",
            plan.readback_object(slot)
                .ok_or_else(|| error("GPU output has no managed host readback object"))?
                .get(),
        )?;
        let aliases = Array::new();
        for alias in &output.aliases {
            aliases.push(&JsValue::from_str(alias));
        }
        set(&value, "aliases", aliases)?;
        physical_outputs.push(&value);
    }
    set(&manifest, "physicalOutputs", physical_outputs)?;

    let memory_allocations = Array::new();
    for allocation in plan.memory.allocations.iter() {
        let value = Object::new();
        set(&value, "object", allocation.id.get())?;
        set(
            &value,
            "capacityBytes",
            allocation.capacity_bytes.to_string(),
        )?;
        set(
            &value,
            "space",
            match allocation.space {
                MemorySpace::Device { .. } => "device",
                MemorySpace::Host => "host",
                MemorySpace::ResidentCpu => "resident",
            },
        )?;
        set(
            &value,
            "lifetime",
            match allocation.lifetime {
                MemoryLifetime::Program => "program",
                MemoryLifetime::Activation => "activation",
                MemoryLifetime::Turn { .. } => "turn",
                MemoryLifetime::Transaction { .. } => "transaction",
                MemoryLifetime::Transfer { .. } => "transfer",
            },
        )?;
        memory_allocations.push(&value);
    }
    set(&manifest, "memoryAllocations", memory_allocations)?;
    if let Some([device, host]) = plan.integrity_readback_objects() {
        let objects = Array::new();
        objects.push(&JsValue::from_f64(device.get() as f64));
        objects.push(&JsValue::from_f64(host.get() as f64));
        set(&manifest, "integrityReadbackObjects", objects)?;
    }

    let compile_timings = Object::new();
    set(&compile_timings, "catalogSetup", timings.catalog_setup)?;
    set(&compile_timings, "parsing", timings.parsing)?;
    set(
        &compile_timings,
        "artifactCompilation",
        timings.artifact_compilation,
    )?;
    set(&compile_timings, "gpuLowering", timings.gpu_lowering)?;
    set(&compile_timings, "inputCapture", timings.input_capture)?;
    set(
        &compile_timings,
        "manifestEncoding",
        milliseconds(manifest_started),
    )?;
    set(&manifest, "compileTimings", compile_timings)?;
    Ok(manifest.into())
}

fn binding_value(
    binding: u32,
    name: &str,
    access: &str,
    role: &str,
    slot: u32,
    elements: usize,
    scalar: &str,
) -> Result<Object, JsValue> {
    let value = Object::new();
    set(&value, "binding", binding)?;
    set(&value, "name", name)?;
    set(&value, "access", access)?;
    set(&value, "role", role)?;
    set(&value, "slot", slot)?;
    set(
        &value,
        "elements",
        u32::try_from(elements).map_err(|_| error("GPU binding size exceeds the browser limit"))?,
    )?;
    set(&value, "scalar", scalar)?;
    Ok(value)
}

fn milliseconds(started: Instant) -> f64 {
    started.elapsed().as_secs_f64() * 1_000.0
}

fn set(target: &Object, name: &str, value: impl Into<JsValue>) -> Result<(), JsValue> {
    Reflect::set(target, &JsValue::from_str(name), &value.into()).map(|_| ())
}

fn error(message: impl AsRef<str>) -> JsValue {
    js_sys::Error::new(message.as_ref()).into()
}
