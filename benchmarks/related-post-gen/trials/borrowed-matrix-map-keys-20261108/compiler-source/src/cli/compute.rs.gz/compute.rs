use std::collections::BTreeMap;

use mech_compute::{BackendRequest, ComputePlatform, ComputeValue};
use mech_core::{MResult, MechError, MechErrorKind};
use mech_engine::ProgramArtifact;
use mech_gpu::{
    ComputeHostFactory, ComputeLowerer, lower_elementwise_compute_program,
    native_compute_backend_registry,
};
use mech_runtime::{FileSourceResolver, RuntimeHostFactory, SourceRequest};

use crate::cli::run::{cli_module_options, cli_runtime_builder};
use crate::cli::runtime_plan::RunExecutionPlan;

pub(crate) struct CompiledNativeComputeApplication {
    pub(crate) coordinator: ProgramArtifact,
    pub(crate) factory: Box<dyn RuntimeHostFactory>,
}

pub(crate) fn configured_compute_host(plan: &RunExecutionPlan) -> MResult<Option<&str>> {
    let mut instances = plan
        .configured_hosts
        .iter()
        .filter(|host| host.provider == "compute");
    let first = instances.next();
    if let Some(second) = instances.next() {
        return Err(compute_cli_error(
            "configure_compute_host",
            format!(
                "v0.4 supports one configured compute host; found `{}` and `{}`",
                first.expect("a second instance implies a first").name,
                second.name,
            ),
        ));
    }
    if let Some(host) = plan
        .configured_hosts
        .iter()
        .find(|host| host.provider == "gpu")
    {
        return Err(compute_cli_error(
            "configure_compute_host",
            format!(
                "host `{}` uses removed provider `gpu`; use provider `compute` and scheme `compute://`",
                host.name
            ),
        ));
    }
    Ok(first.map(|host| host.name.as_str()))
}

pub(crate) fn compile_inline_compute_application(
    plan: &RunExecutionPlan,
    source: &str,
    resolver: FileSourceResolver,
) -> MResult<CompiledNativeComputeApplication> {
    compile_compute_application(plan, resolver, |compiler| {
        compiler.compile_mixed_source(source)
    })
}

pub(crate) fn compile_root_compute_application(
    plan: &RunExecutionPlan,
    request: SourceRequest,
    resolver: FileSourceResolver,
) -> MResult<CompiledNativeComputeApplication> {
    compile_compute_application(plan, resolver, |compiler| {
        compiler.compile_canonical_mixed_root(request, cli_module_options())
    })
}

fn compile_compute_application(
    plan: &RunExecutionPlan,
    resolver: FileSourceResolver,
    compile: impl FnOnce(
        &mut mech_runtime::ProgramCompiler,
    ) -> MResult<mech_runtime::MixedProgramCompilation>,
) -> MResult<CompiledNativeComputeApplication> {
    configured_compute_host(plan)?.ok_or_else(|| {
        compute_cli_error(
            "compile_compute_application",
            "the application has no configured compute host",
        )
    })?;
    let ordinary_hosts = plan
        .configured_hosts
        .iter()
        .filter(|host| host.provider != "compute")
        .cloned()
        .collect::<Vec<_>>();
    let mut compiler = cli_runtime_builder(
        plan.runtime_config.clone(),
        &plan.cli_grants,
        &ordinary_hosts,
        &plan.configured_run_grants,
        Vec::new(),
    )?
    .source_resolver(resolver)
    .build_compiler()?;
    let mixed = compile(&mut compiler)?;

    let mut activation_values =
        initializer_values(&mixed.compute.interface, &mixed.compute.initializers)?;
    activation_values.extend(
        mixed
            .activation_inputs
            .iter()
            .map(|(name, value)| (name.clone(), value_elements(value))),
    );
    let program = match lower_elementwise_compute_program(&mixed.compute.artifact) {
        Ok(program) => program,
        Err(elementwise_failure) => ComputeLowerer
            .compile_broadcast(&mixed.compute.artifact, &activation_values)
            .map(|kernel| kernel.compute_program().clone())
            .map_err(|fixed_failure| {
                compute_cli_error(
                    "lower_compute_region",
                    format!(
                        "region `{}` is not supported by the native compute backends; elementwise: {elementwise_failure}; fixed-shape: {fixed_failure}",
                        mixed.compute.declaration.name,
                    ),
                )
            })?,
    };
    let mut factory = ComputeHostFactory::new(
        mixed.compute.declaration.name.clone(),
        mixed.compute.declaration.placement,
        program,
        mixed.compute.initializers,
        native_compute_backend_registry(),
        ComputePlatform::Native,
    )?
    .with_retained_outputs(mixed.retained_outputs)?;
    if let Some(request) = plan.backend_override.as_deref() {
        factory =
            factory.with_backend_override(BackendRequest::parse(request).map_err(|error| {
                compute_cli_error(
                    "select_compute_backend",
                    format!("invalid backend override `{request}`: {error}"),
                )
            })?);
    }

    Ok(CompiledNativeComputeApplication {
        coordinator: mixed.coordinator.into_artifact(),
        factory: Box::new(factory),
    })
}

fn initializer_values(
    interface: &mech_compute::ComputeRegionInterface,
    initializers: &mech_compute::ComputeInitializerSet,
) -> MResult<BTreeMap<String, Vec<f32>>> {
    interface
        .inputs
        .iter()
        .map(|port| {
            let value = initializers.get(port.id).ok_or_else(|| {
                compute_cli_error(
                    "lower_compute_region",
                    format!("compute input `{}` has no initializer", port.name),
                )
            })?;
            let value = port.normalize_value(value.clone()).map_err(|failure| {
                compute_cli_error("lower_compute_region", failure.to_string())
            })?;
            Ok((port.name.to_string(), value_elements(&value)))
        })
        .collect()
}

fn value_elements(value: &ComputeValue) -> Vec<f32> {
    match value {
        ComputeValue::ScalarF32(value) => vec![*value],
        ComputeValue::TensorF32 { values, .. } => values.to_vec(),
    }
}

#[derive(Clone, Debug)]
struct NativeComputeCliError {
    operation: &'static str,
    reason: String,
}

impl MechErrorKind for NativeComputeCliError {
    fn name(&self) -> &str {
        "NativeComputeCliError"
    }

    fn message(&self) -> String {
        format!("{} failed: {}", self.operation, self.reason)
    }
}

fn compute_cli_error(operation: &'static str, reason: impl Into<String>) -> MechError {
    MechError::new(
        NativeComputeCliError {
            operation,
            reason: reason.into(),
        },
        None,
    )
    .with_compiler_loc()
}
