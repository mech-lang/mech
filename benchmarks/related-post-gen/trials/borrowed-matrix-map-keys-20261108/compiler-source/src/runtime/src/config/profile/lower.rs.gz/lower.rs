#[cfg(feature = "source")]
use std::collections::{BTreeMap, BTreeSet};
use std::path::PathBuf;

#[cfg(feature = "source")]
use crate::HostContextManifest;
#[cfg(feature = "source")]
use crate::validate_run_resource_grant;
use crate::{HostInstanceConfig, HostManifestConfig, RunResourceGrantConfig};
use mech_core::ModuleManifestConfig;
#[cfg(feature = "source")]
use mech_core::{MResult, MechError};
#[cfg(feature = "source")]
use mech_core::{ModuleManifestExportConfig, ModuleManifestExportKind};

#[cfg(feature = "source")]
use super::{ConfigValue, InvalidConfigField};

#[derive(Clone, Debug, PartialEq)]
pub struct MechConfigDocument {
    pub source_name: String,
    pub runtime: RuntimeConfigPatch,
    pub build: Option<BuildHostConfig>,
    pub serve: Option<ServeHostConfig>,
    pub run: Option<RunHostConfig>,
    pub hosts: Vec<HostInstanceConfig>,
    pub capabilities: Vec<ConfigCapabilityGrant>,
    pub host: Option<HostManifestConfig>,
    pub module: Option<ModuleManifestConfig>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ActorBootstrapConfig {
    pub subject: String,
    pub message_kind: String,
    pub message_payload: String,
    pub initial_state: Option<String>,
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct BuildHostConfig {
    pub actor: Option<ActorBootstrapConfig>,
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct RuntimeConfigPatch {
    pub name: Option<String>,
    pub resident_durability: Option<crate::ResidentDurabilityPolicy>,
    pub limits: RuntimeLimitsPatch,
    pub diagnostics: DiagnosticsConfigPatch,
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct RuntimeLimitsPatch {
    pub max_steps_per_turn: Option<u64>,
    pub max_turn_duration_ms: Option<u64>,
    pub max_memory_bytes: Option<u64>,
    pub max_tasks: Option<u64>,
    pub max_actors: Option<u64>,
    pub max_actor_mailbox_len: Option<u64>,
    pub max_source_bytes: Option<u64>,
    pub max_in_memory_events: Option<u64>,
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct DiagnosticsConfigPatch {
    pub trace_enabled: Option<bool>,
    pub profile_enabled: Option<bool>,
    pub debug_enabled: Option<bool>,
    pub log_level: Option<String>,
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum ServePresentation {
    #[default]
    Document,
    Output,
}

impl ServePresentation {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Document => "document",
            Self::Output => "output",
        }
    }
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct ServeHostConfig {
    pub address: Option<String>,
    pub port: Option<u16>,
    pub paths: Vec<PathBuf>,
    pub stylesheets: Vec<PathBuf>,
    pub shim: Option<PathBuf>,
    pub wasm: Option<PathBuf>,
    pub presentation: ServePresentation,
}

#[derive(Clone, Debug, Default, PartialEq)]
pub struct RunHostConfig {
    pub paths: Vec<PathBuf>,
    pub grants: Vec<RunResourceGrantConfig>,
    pub grants_specified: bool,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ConfigCapabilityGrant {
    pub kind: ConfigCapabilityKind,
    pub path: PathBuf,
    pub recursive: Option<bool>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum ConfigCapabilityKind {
    CapRoot,
    Read,
    Watch,
    Serve,
}

#[cfg(feature = "source")]
pub(super) struct ConfigLowerer;

#[cfg(feature = "source")]
impl ConfigLowerer {
    pub(super) fn new() -> Self {
        Self
    }

    pub(super) fn lower(
        &self,
        source_name: String,
        value: ConfigValue,
    ) -> MResult<MechConfigDocument> {
        let map = expect_map("config", &value)?;
        let mut doc = MechConfigDocument {
            source_name,
            runtime: RuntimeConfigPatch::default(),
            build: None,
            serve: None,
            run: None,
            hosts: Vec::new(),
            capabilities: Vec::new(),
            host: None,
            module: None,
        };
        for (key, value) in map {
            match key.as_str() {
                "runtime" => doc.runtime = self.lower_runtime(value)?,
                "build" => doc.build = Some(self.lower_build(value)?),
                "serve" => doc.serve = Some(self.lower_serve(value)?),
                "run" => doc.run = Some(self.lower_run(value)?),
                "hosts" => doc.hosts = self.lower_hosts(value)?,
                "host" => doc.host = Some(self.lower_host_manifest(value)?),
                "capabilities" => doc.capabilities = self.lower_capabilities(value)?,
                "module" => doc.module = Some(self.lower_module(value)?),
                other => return invalid(format!("unknown top-level config field `{other}`")),
            }
        }
        Ok(doc)
    }

    fn lower_build(&self, value: &ConfigValue) -> MResult<BuildHostConfig> {
        let map = expect_map("build", value)?;
        let mut out = BuildHostConfig::default();
        for (key, value) in map {
            match key.as_str() {
                "actor" => out.actor = Some(self.lower_actor_bootstrap(value)?),
                other => return invalid(format!("unknown build field `{other}`")),
            }
        }
        Ok(out)
    }

    fn lower_actor_bootstrap(&self, value: &ConfigValue) -> MResult<ActorBootstrapConfig> {
        let map = expect_map("build.actor", value)?;
        let mut subject = None;
        let mut message_kind = None;
        let mut message_payload = None;
        let mut initial_state = None;
        for (key, value) in map {
            match key.as_str() {
                "subject" => subject = Some(expect_string("build.actor.subject", value)?),
                "message-kind" => {
                    message_kind = Some(expect_string("build.actor.message-kind", value)?)
                }
                "message-payload" => {
                    message_payload = Some(expect_string("build.actor.message-payload", value)?)
                }
                "initial-state" => {
                    initial_state = Some(match value {
                        ConfigValue::Null => None,
                        _ => Some(expect_string("build.actor.initial-state", value)?),
                    })
                }
                other => return invalid(format!("unknown build.actor field `{other}`")),
            }
        }
        let subject = subject.ok_or_else(|| invalid_error("build.actor.subject is required"))?;
        if subject.trim().is_empty() {
            return invalid("build.actor.subject must be non-empty");
        }
        let message_kind =
            message_kind.ok_or_else(|| invalid_error("build.actor.message-kind is required"))?;
        if message_kind.trim().is_empty() {
            return invalid("build.actor.message-kind must be non-empty");
        }
        let message_payload = message_payload
            .ok_or_else(|| invalid_error("build.actor.message-payload is required"))?;
        Ok(ActorBootstrapConfig {
            subject,
            message_kind,
            message_payload,
            initial_state: initial_state.unwrap_or(None),
        })
    }

    fn lower_hosts(&self, value: &ConfigValue) -> MResult<Vec<HostInstanceConfig>> {
        let mut out = Vec::new();
        let mut names = BTreeSet::new();
        for (idx, item) in expect_list("hosts", value)?.iter().enumerate() {
            let where_ = format!("hosts[{idx}]");
            let map = expect_map(&where_, item)?;
            let mut name = None;
            let mut provider = None;
            let mut settings = None;
            for (key, value) in map {
                match key.as_str() {
                    "name" => name = Some(expect_string(&format!("{where_}.name"), value)?),
                    "provider" => {
                        provider = Some(expect_string(&format!("{where_}.provider"), value)?)
                    }
                    "settings" => {
                        settings = Some(match value {
                            ConfigValue::Null => ConfigValue::Map(BTreeMap::new()),
                            ConfigValue::List(items) if items.is_empty() => {
                                ConfigValue::Map(BTreeMap::new())
                            }
                            _ => value.clone(),
                        })
                    }
                    other => return invalid(format!("unknown {where_} field `{other}`")),
                }
            }
            let name = name.ok_or_else(|| invalid_error(format!("{where_}.name is required")))?;
            if name.trim().is_empty() {
                return invalid(format!("{where_}.name must be non-empty"));
            }
            if !names.insert(name.clone()) {
                return invalid(format!("duplicate host instance `{name}`"));
            }
            let provider =
                provider.ok_or_else(|| invalid_error(format!("{where_}.provider is required")))?;
            if provider.trim().is_empty() {
                return invalid(format!("{where_}.provider must be non-empty"));
            }
            let settings = settings.unwrap_or_else(|| ConfigValue::Map(BTreeMap::new()));
            out.push(HostInstanceConfig {
                name,
                provider,
                settings,
            });
        }
        Ok(out)
    }

    fn lower_host_manifest(&self, value: &ConfigValue) -> MResult<HostManifestConfig> {
        let map = expect_map("host", value)?;
        let mut provider = None;
        let mut contexts = None;
        for (key, value) in map {
            match key.as_str() {
                "provider" => provider = Some(expect_string("host.provider", value)?),
                "contexts" => {
                    contexts = Some(
                        expect_list("host.contexts", value)?
                            .iter()
                            .enumerate()
                            .map(|(idx, item)| self.lower_host_context(idx, item))
                            .collect::<MResult<Vec<_>>>()?,
                    )
                }
                other => return invalid(format!("unknown host field `{other}`")),
            }
        }
        let manifest = HostManifestConfig {
            provider: provider.ok_or_else(|| invalid_error("host.provider is required"))?,
            contexts: contexts.ok_or_else(|| invalid_error("host.contexts is required"))?,
        };
        crate::validate_host_manifest(&manifest)?;
        Ok(manifest)
    }

    fn lower_host_context(&self, idx: usize, value: &ConfigValue) -> MResult<HostContextManifest> {
        let where_ = format!("host.contexts[{idx}]");
        let map = expect_map(&where_, value)?;
        let mut name = None;
        let mut base_uri_template = None;
        let mut operations = None;
        for (key, value) in map {
            match key.as_str() {
                "name" => name = Some(expect_string(&format!("{where_}.name"), value)?),
                "base-uri" => {
                    base_uri_template = Some(expect_string(&format!("{where_}.base-uri"), value)?)
                }
                "operations" => {
                    operations = Some(expect_string_list(&format!("{where_}.operations"), value)?)
                }
                other => return invalid(format!("unknown {where_} field `{other}`")),
            }
        }
        Ok(HostContextManifest {
            name: name.ok_or_else(|| invalid_error(format!("{where_}.name is required")))?,
            base_uri_template: base_uri_template
                .ok_or_else(|| invalid_error(format!("{where_}.base-uri is required")))?,
            operations: operations
                .ok_or_else(|| invalid_error(format!("{where_}.operations is required")))?,
        })
    }

    fn lower_module(&self, value: &ConfigValue) -> MResult<ModuleManifestConfig> {
        let map = expect_map("module", value)?;
        let mut name = None;
        let mut exports = None;
        for (key, value) in map {
            match key.as_str() {
                "name" => name = Some(expect_string("module.name", value)?),
                "exports" => {
                    let list = expect_list("module.exports", value)?;
                    exports = Some(
                        list.iter()
                            .enumerate()
                            .map(|(idx, v)| self.lower_module_export(idx, v))
                            .collect::<MResult<Vec<_>>>()?,
                    );
                }
                other => return invalid(format!("unknown module field `{other}`")),
            }
        }
        let name = name.ok_or_else(|| invalid_error("module.name is required"))?;
        if name.trim().is_empty() {
            return invalid("module.name must be non-empty");
        }
        let exports = exports.ok_or_else(|| invalid_error("module.exports is required"))?;
        Ok(ModuleManifestConfig { name, exports })
    }

    fn lower_module_export(
        &self,
        idx: usize,
        value: &ConfigValue,
    ) -> MResult<ModuleManifestExportConfig> {
        let where_ = format!("module.exports[{idx}]");
        let map = expect_map(&where_, value)?;
        let mut name = None;
        let mut kind = None;
        let mut base_uri = None;
        let mut operations = None;
        for (key, value) in map {
            match key.as_str() {
                "name" => name = Some(expect_string(&format!("{where_}.name"), value)?),
                "kind" => {
                    let raw = expect_string(&format!("{where_}.kind"), value)?;
                    kind = Some(match raw.as_str() {
                        "context" => ModuleManifestExportKind::Context,
                        _ => {
                            return invalid(format!(
                                "{where_}.kind must be `context`; got `{raw}`"
                            ));
                        }
                    });
                }
                "base-uri" => base_uri = Some(expect_string(&format!("{where_}.base-uri"), value)?),
                "operations" => {
                    operations = Some(expect_string_list(&format!("{where_}.operations"), value)?)
                }
                other => return invalid(format!("unknown {where_} field `{other}`")),
            }
        }
        let name = name.ok_or_else(|| invalid_error(format!("{where_}.name is required")))?;
        if name.trim().is_empty() {
            return invalid(format!("{where_}.name must be non-empty"));
        }
        let kind = kind.ok_or_else(|| invalid_error(format!("{where_}.kind is required")))?;
        let base_uri =
            base_uri.ok_or_else(|| invalid_error(format!("{where_}.base-uri is required")))?;
        if !base_uri.contains("://") {
            return invalid(format!("{where_}.base-uri must contain `://`"));
        }
        let operations =
            operations.ok_or_else(|| invalid_error(format!("{where_}.operations is required")))?;
        if operations.is_empty() {
            return invalid(format!(
                "{where_}.operations must contain at least one operation"
            ));
        }
        for op in &operations {
            if op != "read" && op != "write" {
                return invalid(format!(
                    "module context exports only support operations `read` and `write`; got `{op}`"
                ));
            }
        }
        Ok(ModuleManifestExportConfig {
            name,
            kind,
            base_uri,
            operations,
        })
    }

    fn lower_runtime(&self, value: &ConfigValue) -> MResult<RuntimeConfigPatch> {
        let map = expect_map("runtime", value)?;
        let mut out = RuntimeConfigPatch::default();
        for (key, value) in map {
            match key.as_str() {
                "name" => out.name = Some(expect_string("runtime.name", value)?),
                "resident-durability" => {
                    let value = expect_string("runtime.resident-durability", value)?;
                    out.resident_durability = Some(match value.as_str() {
                        "volatile" => crate::ResidentDurabilityPolicy::Volatile,
                        "retained" => crate::ResidentDurabilityPolicy::Retained,
                        other => {
                            return invalid(format!(
                                "runtime.resident-durability must be one of volatile, retained; got `{other}`"
                            ));
                        }
                    });
                }
                "limits" => out.limits = self.lower_limits(value)?,
                "diagnostics" => out.diagnostics = self.lower_diagnostics(value)?,
                other => return invalid(format!("unknown runtime field `{other}`")),
            }
        }
        Ok(out)
    }

    fn lower_limits(&self, value: &ConfigValue) -> MResult<RuntimeLimitsPatch> {
        let map = expect_map("runtime.limits", value)?;
        let mut out = RuntimeLimitsPatch::default();
        for (key, value) in map {
            match key.as_str() {
                "max-steps-per-turn" => {
                    out.max_steps_per_turn =
                        Some(expect_u64("runtime.limits.max-steps-per-turn", value)?)
                }
                "max-turn-duration-ms" => {
                    out.max_turn_duration_ms =
                        Some(expect_u64("runtime.limits.max-turn-duration-ms", value)?)
                }
                "max-memory-bytes" => {
                    out.max_memory_bytes =
                        Some(expect_u64("runtime.limits.max-memory-bytes", value)?)
                }
                "max-tasks" => out.max_tasks = Some(expect_u64("runtime.limits.max-tasks", value)?),
                "max-actors" => {
                    out.max_actors = Some(expect_u64("runtime.limits.max-actors", value)?)
                }
                "max-actor-mailbox-len" => {
                    out.max_actor_mailbox_len =
                        Some(expect_u64("runtime.limits.max-actor-mailbox-len", value)?)
                }
                "max-source-bytes" => {
                    out.max_source_bytes =
                        Some(expect_u64("runtime.limits.max-source-bytes", value)?)
                }
                "max-in-memory-events" => {
                    out.max_in_memory_events =
                        Some(expect_u64("runtime.limits.max-in-memory-events", value)?)
                }
                other => return invalid(format!("unknown runtime.limits field `{other}`")),
            }
        }
        Ok(out)
    }

    fn lower_diagnostics(&self, value: &ConfigValue) -> MResult<DiagnosticsConfigPatch> {
        let map = expect_map("runtime.diagnostics", value)?;
        let mut out = DiagnosticsConfigPatch::default();
        for (key, value) in map {
            match key.as_str() {
                "trace-enabled" => {
                    out.trace_enabled =
                        Some(expect_bool("runtime.diagnostics.trace-enabled", value)?)
                }
                "profile-enabled" => {
                    out.profile_enabled =
                        Some(expect_bool("runtime.diagnostics.profile-enabled", value)?)
                }
                "debug-enabled" => {
                    out.debug_enabled =
                        Some(expect_bool("runtime.diagnostics.debug-enabled", value)?)
                }
                "log-level" => {
                    let log_level = expect_string("runtime.diagnostics.log-level", value)?;
                    if !matches!(
                        log_level.as_str(),
                        "error" | "warn" | "info" | "debug" | "trace"
                    ) {
                        return invalid(format!(
                            "runtime.diagnostics.log-level must be one of error, warn, info, debug, trace; got `{log_level}`"
                        ));
                    }
                    out.log_level = Some(log_level)
                }
                other => return invalid(format!("unknown runtime.diagnostics field `{other}`")),
            }
        }
        Ok(out)
    }

    fn lower_serve(&self, value: &ConfigValue) -> MResult<ServeHostConfig> {
        let map = expect_map("serve", value)?;
        let mut out = ServeHostConfig::default();
        for (key, value) in map {
            match key.as_str() {
                "address" => out.address = Some(expect_string("serve.address", value)?),
                "port" => {
                    let port = expect_u64("serve.port", value)?;
                    if !(1..=65535).contains(&port) {
                        return invalid("serve.port must be in 1..65535");
                    }
                    out.port = Some(port as u16);
                }
                "paths" => out.paths = expect_path_list("serve.paths", value)?,
                "stylesheets" => out.stylesheets = expect_path_list("serve.stylesheets", value)?,
                "shim" => out.shim = Some(PathBuf::from(expect_string("serve.shim", value)?)),
                "wasm" => out.wasm = Some(PathBuf::from(expect_string("serve.wasm", value)?)),
                "presentation" => {
                    let presentation = expect_string("serve.presentation", value)?;
                    out.presentation = match presentation.as_str() {
                        "document" => ServePresentation::Document,
                        "output" => ServePresentation::Output,
                        _ => {
                            return invalid(format!(
                                "serve.presentation must be one of document, output; got `{presentation}`"
                            ));
                        }
                    };
                }
                other => return invalid(format!("unknown serve field `{other}`")),
            }
        }
        Ok(out)
    }

    fn lower_run(&self, value: &ConfigValue) -> MResult<RunHostConfig> {
        let map = expect_map("run", value)?;
        let mut out = RunHostConfig::default();

        for (key, value) in map {
            match key.as_str() {
                "paths" => out.paths = expect_path_list("run.paths", value)?,
                "grants" => {
                    out.grants = self.lower_run_grants(value)?;
                    out.grants_specified = true;
                }
                other => return invalid(format!("unknown run field `{other}`")),
            }
        }

        Ok(out)
    }

    fn lower_run_grants(&self, value: &ConfigValue) -> MResult<Vec<RunResourceGrantConfig>> {
        expect_list("run.grants", value)?
            .iter()
            .enumerate()
            .map(|(idx, item)| {
                let where_ = format!("run.grants[{idx}]");
                let map = expect_map(&where_, item)?;
                let mut target = None;
                let mut operations = None;
                let mut paths = None;
                for (key, value) in map {
                    match key.as_str() {
                        "target" => {
                            target = Some(expect_string(&format!("{where_}.target"), value)?)
                        }
                        "operations" => {
                            operations =
                                Some(expect_string_list(&format!("{where_}.operations"), value)?)
                        }
                        "paths" => {
                            paths = Some(expect_string_list(&format!("{where_}.paths"), value)?)
                        }
                        other => return invalid(format!("unknown {where_} field `{other}`")),
                    }
                }
                let grant = RunResourceGrantConfig {
                    target: target
                        .ok_or_else(|| invalid_error(format!("{where_}.target is required")))?,
                    operations: operations
                        .ok_or_else(|| invalid_error(format!("{where_}.operations is required")))?,
                    paths: paths
                        .ok_or_else(|| invalid_error(format!("{where_}.paths is required")))?,
                };
                validate_run_resource_grant(&grant)?;
                Ok(grant)
            })
            .collect()
    }

    fn lower_capabilities(&self, value: &ConfigValue) -> MResult<Vec<ConfigCapabilityGrant>> {
        let list = expect_list("capabilities", value)?;
        let mut out = Vec::new();
        for (idx, item) in list.iter().enumerate() {
            let where_ = format!("capabilities[{idx}]");
            let map = expect_map(&where_, item)?;
            let mut kind = None;
            let mut path = None;
            let mut recursive = None;
            for (key, value) in map {
                match key.as_str() {
                    "allow" => {
                        kind = Some(
                            match expect_string(&format!("{where_}.allow"), value)?.as_str() {
                                "cap-root" => ConfigCapabilityKind::CapRoot,
                                "read" => ConfigCapabilityKind::Read,
                                "watch" => ConfigCapabilityKind::Watch,
                                "serve" => ConfigCapabilityKind::Serve,
                                other => {
                                    return invalid(format!(
                                        "unknown capability allow value `{other}`"
                                    ));
                                }
                            },
                        )
                    }
                    "path" => {
                        path = Some(PathBuf::from(expect_string(
                            &format!("{where_}.path"),
                            value,
                        )?))
                    }
                    "recursive" => {
                        recursive = Some(expect_bool(&format!("{where_}.recursive"), value)?)
                    }
                    other => return invalid(format!("unknown capability field `{other}`")),
                }
            }
            let Some(kind) = kind else {
                return invalid(format!("{where_}.allow is required"));
            };
            let Some(path) = path else {
                return invalid(format!("{where_}.path is required"));
            };
            out.push(ConfigCapabilityGrant {
                kind,
                path,
                recursive,
            });
        }
        Ok(out)
    }
}

#[cfg(feature = "source")]
fn expect_map<'a>(
    where_: &str,
    value: &'a ConfigValue,
) -> MResult<&'a BTreeMap<String, ConfigValue>> {
    match value {
        ConfigValue::Map(map) => Ok(map),
        other => invalid(format!(
            "{where_} must be a map/object, got {}",
            type_name(other)
        )),
    }
}

#[cfg(feature = "source")]
fn expect_list<'a>(where_: &str, value: &'a ConfigValue) -> MResult<&'a Vec<ConfigValue>> {
    match value {
        ConfigValue::List(list) => Ok(list),
        other => invalid(format!("{where_} must be a list, got {}", type_name(other))),
    }
}

#[cfg(feature = "source")]
fn expect_string(where_: &str, value: &ConfigValue) -> MResult<String> {
    match value {
        ConfigValue::String(s) => Ok(s.clone()),
        other => invalid(format!(
            "{where_} must be a string, got {}",
            type_name(other)
        )),
    }
}

#[cfg(feature = "source")]
fn expect_bool(where_: &str, value: &ConfigValue) -> MResult<bool> {
    match value {
        ConfigValue::Bool(b) => Ok(*b),
        other => invalid(format!("{where_} must be a bool, got {}", type_name(other))),
    }
}

#[cfg(feature = "source")]
fn expect_u64(where_: &str, value: &ConfigValue) -> MResult<u64> {
    match value {
        ConfigValue::Integer(i) if *i >= 0 => Ok(*i as u64),
        other => invalid(format!(
            "{where_} must be a non-negative integer, got {}",
            type_name(other)
        )),
    }
}

#[cfg(feature = "source")]
fn expect_path_list(where_: &str, value: &ConfigValue) -> MResult<Vec<PathBuf>> {
    expect_list(where_, value)?
        .iter()
        .enumerate()
        .map(|(idx, value)| expect_string(&format!("{where_}[{idx}]"), value).map(PathBuf::from))
        .collect()
}

#[cfg(feature = "source")]
fn expect_string_list(where_: &str, value: &ConfigValue) -> MResult<Vec<String>> {
    expect_list(where_, value)?
        .iter()
        .enumerate()
        .map(|(idx, value)| expect_string(&format!("{where_}[{idx}]"), value))
        .collect()
}

#[cfg(feature = "source")]
fn invalid_error(reason: impl Into<String>) -> MechError {
    MechError::new(InvalidConfigField::new(reason), None).with_compiler_loc()
}

#[cfg(feature = "source")]
fn invalid<T>(reason: impl Into<String>) -> MResult<T> {
    Err(invalid_error(reason))
}

#[cfg(feature = "source")]
fn type_name(value: &ConfigValue) -> &'static str {
    match value {
        ConfigValue::Null => "null",
        ConfigValue::Bool(_) => "bool",
        ConfigValue::Integer(_) => "integer",
        ConfigValue::Float(_) => "float",
        ConfigValue::String(_) => "string",
        ConfigValue::List(_) => "list",
        ConfigValue::Map(_) => "map",
    }
}

#[cfg(all(test, feature = "source"))]
mod tests {
    use super::*;
    use crate::{ConfigProfileOptions, parse_config_document};

    fn parse(source: &str) -> MResult<MechConfigDocument> {
        parse_config_document("mech.mcfg", source, ConfigProfileOptions::default())
    }

    #[test]
    fn run_paths_parse_and_lower() {
        let doc = parse(
            r#"config := {
  run: {
    paths: ["foo.mec", "bar.mec"]
  }
}
"#,
        )
        .unwrap();

        let run = doc.run.unwrap();
        assert_eq!(
            run.paths,
            vec![PathBuf::from("foo.mec"), PathBuf::from("bar.mec")]
        );
    }

    #[test]
    fn serve_presentation_parses_and_defaults_to_document() {
        let output = parse(r#"config := {serve: {presentation: "output"}}"#).unwrap();
        assert_eq!(
            output.serve.unwrap().presentation,
            ServePresentation::Output
        );

        let defaulted = parse(r#"config := {serve: {port: 8081}}"#).unwrap();
        assert_eq!(
            defaulted.serve.unwrap().presentation,
            ServePresentation::Document
        );
    }

    #[test]
    fn unknown_serve_presentation_fails() {
        let error = parse(r#"config := {serve: {presentation: "canvas"}}"#).unwrap_err();
        assert!(
            format!("{error:?}").contains("serve.presentation must be one of document, output")
        );
    }

    #[test]
    fn runtime_accepts_direct_resident_durability() {
        let document = parse(r#"config := {runtime: {resident-durability: "retained"}}"#).unwrap();
        assert_eq!(
            document.runtime.resident_durability,
            Some(crate::ResidentDurabilityPolicy::Retained)
        );
    }

    #[test]
    fn unknown_run_field_fails() {
        let err = parse(
            r#"config := {
  run: {
    bad: true
  }
}
"#,
        )
        .expect_err("unknown run fields must fail");
        let msg = format!("{} {} {:?}", err.kind_name(), err.kind_message(), err);
        assert!(msg.contains("unknown run field `bad`"));
    }

    #[test]
    fn run_executor_configuration_is_rejected() {
        let error = parse(
            r#"config := {
  run: {executor: {provider: "gpu" turns: 1}}
}
"#,
        )
        .expect_err("run.executor must not recreate an alternate application executor");

        assert!(format!("{error:?}").contains("unknown run field `executor`"));
    }

    #[test]
    fn run_grants_empty_paths_allowed_when_explicit_empty_list_is_rejected_or_allowed_per_policy() {
        let result = parse_config_document(
            "test.mcfg",
            r#"config := {run: {grants: [{target: "cli/stdout" operations: ["write"] paths: []}]}}"#,
            ConfigProfileOptions::default(),
        );

        assert!(result.is_err());
    }

    #[test]
    fn run_grants_stdout_line_lowers() {
        let doc = parse_config_document(
            "test.mcfg",
            r#"config := {run: {grants: [{target: "cli/stdout" operations: ["write"] paths: ["line"]}]}}"#,
            ConfigProfileOptions::default(),
        ).unwrap();

        let run = doc.run.unwrap();
        assert_eq!(run.grants.len(), 1);
        assert_eq!(run.grants[0].target, "cli/stdout");
        assert_eq!(run.grants[0].operations, vec!["write".to_string()]);
        assert_eq!(run.grants[0].paths, vec!["line".to_string()]);
    }

    #[test]
    fn run_grants_env_path_lowers() {
        let doc = parse_config_document(
            "test.mcfg",
            r#"config := {run: {grants: [{target: "cli/env" operations: ["read"] paths: ["PATH"]}]}}"#,
            ConfigProfileOptions::default(),
        ).unwrap();

        let run = doc.run.unwrap();
        assert_eq!(run.grants[0].target, "cli/env");
        assert_eq!(run.grants[0].operations, vec!["read".to_string()]);
        assert_eq!(run.grants[0].paths, vec!["PATH".to_string()]);
    }

    #[test]
    fn run_cli_is_rejected() {
        let err = parse_config_document(
            "test.mcfg",
            r#"config := {run: {cli: {stdout: {write: ["line"]}}}}"#,
            ConfigProfileOptions::default(),
        )
        .unwrap_err();

        let error = format!("{err:?}");
        assert!(error.contains("unknown run field `cli`"), "got {error}");
    }

    #[test]
    fn actor_build_bootstrap_lowers_exact_fields() {
        let doc = parse(
            r#"config := {
  build: {
    actor: {
      subject: "actor:main"
      message-kind: "startup"
      message-payload: "hello"
      initial-state: "initial"
    }
  }
}"#,
        )
        .unwrap();

        assert_eq!(
            doc.build.unwrap().actor,
            Some(ActorBootstrapConfig {
                subject: "actor:main".to_owned(),
                message_kind: "startup".to_owned(),
                message_payload: "hello".to_owned(),
                initial_state: Some("initial".to_owned()),
            })
        );
    }

    #[test]
    fn actor_build_bootstrap_accepts_empty_payload_and_null_state() {
        let doc = parse(
            r#"config := {build: {actor: {
  subject: "actor:main"
  message-kind: "startup"
  message-payload: ""
  initial-state: null
}}}"#,
        )
        .unwrap();

        let actor = doc.build.unwrap().actor.unwrap();
        assert_eq!(actor.message_payload, "");
        assert_eq!(actor.initial_state, None);
    }

    #[test]
    fn actor_build_bootstrap_rejects_missing_empty_mistyped_and_unknown_fields() {
        for source in [
            r#"config := {build: {actor: {message-kind: "startup" message-payload: "hello"}}}"#,
            r#"config := {build: {actor: {subject: "  " message-kind: "startup" message-payload: "hello"}}}"#,
            r#"config := {build: {actor: {subject: "actor:main" message-kind: "  " message-payload: "hello"}}}"#,
            r#"config := {build: {actor: {subject: "actor:main" message-kind: "startup" message-payload: 1}}}"#,
            r#"config := {build: {actor: {subject: "actor:main" message-kind: "startup" message-payload: "hello" extra: true}}}"#,
        ] {
            assert!(parse(source).is_err(), "unexpectedly accepted {source}");
        }
    }
}
