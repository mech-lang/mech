//! Store abstraction for the Mech runtime.
//!
//! `MechStore` is the database boundary. It defines what the runtime needs from
//! persistence without selecting a backend by enum.
//!
//! Durable backends should implement `MechStore` directly:
//!
//! - SQLite store
//! - Postgres store
//! - embedded KV store
//! - distributed database store
//! - host-provided store
//!
//! The included `InMemoryStore` is only the default implementation for tests,
//! prototypes, and the first runtime shell.

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

use std::collections::{HashMap, VecDeque};
use std::sync::Arc;
#[cfg(all(test, feature = "source"))]
use std::sync::Mutex;
#[cfg(all(test, feature = "source"))]
use std::sync::atomic::{AtomicUsize, Ordering};

use mech_core::{MResult, MechError, MechErrorKind, MechSourceCode};

#[cfg(feature = "source")]
use crate::SourceDocument;
use crate::capability::{Capability, CapabilityRequest};
use crate::context::ResourceBudgetExceededError;
use crate::effect::RuntimeEffectRecord;
use crate::event::RuntimeEvent;
#[cfg(test)]
use crate::event::RuntimeEventKind;
use crate::id::{
    ActorId, CapabilityId, EventId, MessageId, ModuleId, ModuleVersionId, ObjectId, TaskId,
    TransactionId,
};
use crate::module_id;
use crate::resolver::{
    ModuleScopeMetadata, SourceAddressReference, SourceContextDeclaration, SourceExportDeclaration,
    SourceImportAlias, SourceImportDeclaration, SourceScope, import_requires_source_dependency,
};

#[path = "store_prepared_commit.rs"]
mod prepared_commit;
#[path = "store_validation.rs"]
mod validation;

#[cfg(test)]
#[path = "store_prepared_commit_tests.rs"]
mod prepared_commit_tests;

// -----------------------------------------------------------------------------
// Store Trait
// -----------------------------------------------------------------------------

pub trait MechStore: std::fmt::Debug + Send {
    fn put_module(&mut self, module: ModuleRecord) -> MResult<ModuleId>;

    fn get_module(&self, id: ModuleId) -> MResult<Option<ModuleRecord>>;

    fn find_module_by_name(&self, name: &str) -> MResult<Option<ModuleRecord>>;

    fn put_module_version(&mut self, version: ModuleVersionRecord) -> MResult<ModuleVersionId>;

    fn get_module_version(&self, id: ModuleVersionId) -> MResult<Option<ModuleVersionRecord>>;

    /// All retained source revisions for this module, including inactive versions.
    /// Implementations must return the durable history, not only the active source.
    #[cfg(feature = "source")]
    fn module_source_documents(&self, module: ModuleId) -> MResult<Vec<SourceDocument>>;

    fn set_active_module_version(
        &mut self,
        module: ModuleId,
        version: ModuleVersionId,
    ) -> MResult<()>;

    fn get_active_module_version(&self, module: ModuleId) -> MResult<Option<ModuleVersionId>>;

    fn put_object(&mut self, object: ObjectRecord) -> MResult<ObjectId>;

    fn get_object(&self, id: ObjectId) -> MResult<Option<ObjectRecord>>;

    fn update_object(&mut self, object: ObjectRecord) -> MResult<ObjectId>;

    fn put_task(&mut self, task: TaskRecord) -> MResult<TaskId>;

    fn get_task(&self, id: TaskId) -> MResult<Option<TaskRecord>>;

    fn update_task(&mut self, task: TaskRecord) -> MResult<TaskId>;

    fn task_count(&self) -> MResult<u64>;

    fn put_actor(&mut self, actor: ActorRecord) -> MResult<ActorId>;

    fn get_actor(&self, id: ActorId) -> MResult<Option<ActorRecord>>;

    fn update_actor(&mut self, actor: ActorRecord) -> MResult<ActorId>;

    fn actor_count(&self) -> MResult<u64>;

    fn enqueue_message(&mut self, actor: ActorId, message: MessageRecord) -> MResult<MessageId>;

    fn mailbox_len(&self, actor: ActorId) -> MResult<u64>;

    fn peek_message(&self, actor: ActorId) -> MResult<Option<MessageRecord>>;

    fn list_mailbox(&self, actor: ActorId) -> MResult<Vec<MessageRecord>>;

    fn ack_message(&mut self, actor: ActorId, message: MessageId) -> MResult<()>;

    fn pop_message(&mut self, actor: ActorId) -> MResult<Option<MessageRecord>> {
        let Some(message) = self.peek_message(actor)? else {
            return Ok(None);
        };

        self.ack_message(actor, message.id)?;
        Ok(Some(message))
    }

    fn grant_capability(
        &mut self,
        id: CapabilityId,
        capability: Arc<dyn Capability>,
    ) -> MResult<CapabilityId>;

    /// Administratively remove a capability grant that has not committed.
    ///
    /// Contract:
    ///
    /// - `grant_capability` must not retain grant state when it returns `Err`;
    /// - `rollback_capability_grant` is called only after `grant_capability`
    ///   returned `Ok`;
    /// - it administratively removes an uncommitted record;
    /// - it ignores the capability's revocable policy;
    /// - it is idempotent;
    /// - it removes subject and revocation indexes as well as the primary record.
    fn rollback_capability_grant(&mut self, id: CapabilityId) -> MResult<()>;

    fn get_capability(&self, id: CapabilityId) -> MResult<Option<Arc<dyn Capability>>>;

    fn list_capabilities_for_subject(&self, subject_key: &str) -> MResult<Vec<CapabilityId>>;

    fn revoke_capability(&mut self, id: CapabilityId) -> MResult<()>;

    fn is_capability_revoked(&self, id: CapabilityId) -> MResult<bool>;

    fn append_event(&mut self, event: RuntimeEvent) -> MResult<EventId>;

    fn get_event(&self, id: EventId) -> MResult<Option<RuntimeEvent>>;

    fn list_events(&self, limit: Option<usize>) -> MResult<Vec<RuntimeEvent>>;

    fn configure_event_retention(&mut self, _: Option<usize>) -> MResult<()> {
        Ok(())
    }

    /// Applies one atomic, all-or-nothing durable runtime batch.
    ///
    /// Returning `Err` means no element of the batch committed. Returning `Ok`
    /// means the complete batch committed. The runtime does not supply database
    /// isolation against external writers.
    fn commit_runtime(&mut self, commit: RuntimeStoreCommit) -> MResult<TransactionId>;

    fn commit_transaction(&mut self, tx: TransactionRecord) -> MResult<TransactionId>;

    fn get_transaction(&self, id: TransactionId) -> MResult<Option<TransactionRecord>>;

    fn list_transactions(&self, limit: Option<usize>) -> MResult<Vec<TransactionRecord>>;
}

// -----------------------------------------------------------------------------
// Module Records
// -----------------------------------------------------------------------------

#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ModuleRecord {
    pub id: ModuleId,
    pub name: String,
    pub description: Option<String>,
}

impl ModuleRecord {
    pub fn new(id: ModuleId, name: impl Into<String>) -> Self {
        Self {
            id,
            name: name.into(),
            description: None,
        }
    }

    pub fn with_description(mut self, description: impl Into<String>) -> Self {
        self.description = Some(description.into());
        self
    }

    pub fn validate(&self) -> MResult<()> {
        if self.id.is_zero() {
            return invalid_store_record("module.id", "must not be zero");
        }

        if self.name.trim().is_empty() {
            return invalid_store_record("module.name", "must not be empty");
        }

        Ok(())
    }
}

#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ModuleImportEdge {
    pub scope: SourceScope,
    pub import: SourceImportDeclaration,
    pub dependency: ModuleVersionId,
}

#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ModuleVersionRecord {
    pub id: ModuleVersionId,
    pub module: ModuleId,
    pub version: u64,
    pub source: Option<MechSourceCode>,
    #[cfg(feature = "source")]
    #[cfg_attr(feature = "serde", serde(skip))]
    pub source_document: Option<SourceDocument>,
    pub bytecode: Option<Vec<u8>>,
    pub exports: Vec<SourceExportDeclaration>,
    pub imports: Vec<SourceImportDeclaration>,
    pub contexts: Vec<SourceContextDeclaration>,
    pub address_references: Vec<SourceAddressReference>,
    pub scopes: Vec<ModuleScopeMetadata>,
    pub dependencies: Vec<ModuleVersionId>,
    pub import_edges: Vec<ModuleImportEdge>,
    pub capability_requirements: Vec<CapabilityRequest>,
}

fn import_requires_edge(import: &SourceImportDeclaration) -> bool {
    import_requires_source_dependency(import)
}

fn collection_len_u64(resource: &'static str, len: usize) -> MResult<u64> {
    u64::try_from(len).map_err(|_| {
        MechError::new(
            ResourceBudgetExceededError {
                resource,
                used: u64::MAX,
                requested: 1,
                max: None,
            },
            None,
        )
    })
}

impl ModuleVersionRecord {
    pub fn new(id: ModuleVersionId, module: ModuleId, version: u64) -> Self {
        Self {
            id,
            module,
            version,
            source: None,
            #[cfg(feature = "source")]
            source_document: None,
            bytecode: None,
            exports: Vec::new(),
            imports: Vec::new(),
            contexts: Vec::new(),
            address_references: Vec::new(),
            scopes: Vec::new(),
            dependencies: Vec::new(),
            import_edges: Vec::new(),
            capability_requirements: Vec::new(),
        }
    }

    pub fn with_source(mut self, source: MechSourceCode) -> Self {
        self.source = Some(source);
        self
    }

    #[cfg(feature = "source")]
    pub fn with_source_document(mut self, source_document: Option<SourceDocument>) -> Self {
        self.source_document = source_document;
        self
    }

    pub fn with_bytecode(mut self, bytecode: Vec<u8>) -> Self {
        self.bytecode = Some(bytecode);
        self
    }

    pub fn with_dependencies(mut self, dependencies: Vec<ModuleVersionId>) -> Self {
        self.dependencies = dependencies;
        self
    }

    pub fn with_exports(mut self, exports: Vec<SourceExportDeclaration>) -> Self {
        self.exports = exports;
        self
    }

    pub fn with_imports(mut self, imports: Vec<SourceImportDeclaration>) -> Self {
        self.imports = imports;
        self
    }

    pub fn with_contexts(mut self, contexts: Vec<SourceContextDeclaration>) -> Self {
        self.contexts = contexts;
        self
    }

    pub fn with_address_references(
        mut self,
        address_references: Vec<SourceAddressReference>,
    ) -> Self {
        self.address_references = address_references;
        self
    }

    pub fn with_scopes(mut self, scopes: Vec<ModuleScopeMetadata>) -> Self {
        self.scopes = scopes;
        self
    }

    pub fn with_import_edges(mut self, import_edges: Vec<ModuleImportEdge>) -> Self {
        self.import_edges = import_edges;
        self
    }

    pub fn with_capability_requirements(mut self, requirements: Vec<CapabilityRequest>) -> Self {
        self.capability_requirements = requirements;
        self
    }

    pub fn validate(&self) -> MResult<()> {
        if self.id.is_zero() {
            return invalid_store_record("module_version.id", "must not be zero");
        }

        if self.module.is_zero() {
            return invalid_store_record("module_version.module", "must not be zero");
        }

        if self.version == 0 {
            return invalid_store_record("module_version.version", "must be greater than zero");
        }

        #[cfg(feature = "source")]
        if let Some(document) = &self.source_document {
            match &self.source {
                Some(MechSourceCode::String(source))
                    if source.as_str() == document.source().to_contiguous_string() => {}
                Some(MechSourceCode::String(_)) => {
                    return invalid_store_record(
                        "module_version.source_document",
                        "must retain the exact source bytes",
                    );
                }
                _ => {
                    return invalid_store_record(
                        "module_version.source_document",
                        "requires textual source",
                    );
                }
            }
        }

        Ok(())
    }

    #[cfg(feature = "source")]
    pub(crate) fn validate_source_owner(&self, canonical_uri: &str) -> MResult<()> {
        if let Some(document) = &self.source_document {
            if document.source().document().0 != mech_core::hash_str(canonical_uri) {
                return invalid_store_record(
                    "module_version.source_document",
                    "document owner does not match the module URI",
                );
            }
        }
        Ok(())
    }

    #[cfg(feature = "source")]
    fn validate_source_revisions<'a>(
        &self,
        known_versions: impl Iterator<Item = &'a ModuleVersionRecord>,
    ) -> MResult<()> {
        let Some(document) = &self.source_document else {
            return Ok(());
        };
        for known in known_versions.filter(|known| known.module == self.module) {
            if let Some(previous) = &known.source_document {
                if previous.source().revision() == document.source().revision()
                    && previous != document
                {
                    return invalid_store_record(
                        "module_version.source_document",
                        "revision already identifies another document",
                    );
                }
            }
        }
        Ok(())
    }

    pub fn validate_import_edges(&self) -> MResult<()> {
        let mut matched_edges = vec![false; self.import_edges.len()];
        for import in self
            .imports
            .iter()
            .filter(|import| import_requires_edge(import))
        {
            let Some((index, _)) = self
                .import_edges
                .iter()
                .enumerate()
                .find(|(index, edge)| !matched_edges[*index] && &edge.import == import)
            else {
                return Err(MechError::new(
                    InvalidModuleImportEdgesError {
                        module: self.id,
                        reason: format!(
                            "required source dependency import `{}` has no import edge",
                            import.specifier
                        ),
                    },
                    None,
                ));
            };
            matched_edges[index] = true;
        }

        for edge in &self.import_edges {
            if matches!(edge.import.alias, Some(SourceImportAlias::Context(_))) {
                return Err(MechError::new(
                    InvalidModuleImportEdgesError {
                        module: self.id,
                        reason: "context imports must not create import edges".to_string(),
                    },
                    None,
                ));
            }

            if edge.import.specifier.trim().is_empty() {
                return Err(MechError::new(
                    InvalidModuleImportEdgesError {
                        module: self.id,
                        reason: "import edge has empty specifier".to_string(),
                    },
                    None,
                ));
            }

            if !self.dependencies.contains(&edge.dependency) {
                return Err(MechError::new(
                    InvalidModuleImportEdgesError {
                        module: self.id,
                        reason: format!(
                            "import edge dependency {} is not listed in dependencies",
                            edge.dependency
                        ),
                    },
                    None,
                ));
            }

            if !self.imports.iter().any(|import| {
                import.specifier == edge.import.specifier && import.kind == edge.import.kind
            }) {
                return Err(MechError::new(
                    InvalidModuleImportEdgesError {
                        module: self.id,
                        reason: format!(
                            "import edge specifier `{}` kind {:?} not found in imports",
                            edge.import.specifier, edge.import.kind
                        ),
                    },
                    None,
                ));
            }

            if !import_exists_in_scope(self, &edge.scope, &edge.import) {
                return Err(MechError::new(
                    InvalidModuleImportEdgesError {
                        module: self.id,
                        reason: format!(
                            "import edge specifier `{}` kind {:?} not found in scope {:?}",
                            edge.import.specifier, edge.import.kind, edge.scope
                        ),
                    },
                    None,
                ));
            }
        }

        Ok(())
    }
}

fn import_exists_in_scope(
    record: &ModuleVersionRecord,
    scope: &SourceScope,
    import: &SourceImportDeclaration,
) -> bool {
    record
        .scopes
        .iter()
        .find(|metadata| &metadata.scope == scope)
        .map(|metadata| metadata.imports.iter().any(|candidate| candidate == import))
        .unwrap_or(false)
}

#[derive(Debug, Clone)]
pub struct InvalidModuleImportEdgesError {
    pub module: ModuleVersionId,
    pub reason: String,
}

impl MechErrorKind for InvalidModuleImportEdgesError {
    fn name(&self) -> &str {
        "InvalidModuleImportEdges"
    }

    fn message(&self) -> String {
        format!(
            "invalid import edges for module version `{}`: {}",
            self.module, self.reason
        )
    }
}

// -----------------------------------------------------------------------------
// Object Records
// -----------------------------------------------------------------------------

#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ObjectRecord {
    pub id: ObjectId,
    pub kind: String,
    pub version: u64,
    pub encoding: String,
    pub data: Vec<u8>,
}

impl ObjectRecord {
    pub fn new(
        id: ObjectId,
        kind: impl Into<String>,
        encoding: impl Into<String>,
        data: Vec<u8>,
    ) -> Self {
        Self {
            id,
            kind: kind.into(),
            version: 1,
            encoding: encoding.into(),
            data,
        }
    }

    pub fn text(id: ObjectId, kind: impl Into<String>, text: impl Into<String>) -> Self {
        Self::new(id, kind, "text/plain", text.into().into_bytes())
    }

    pub fn json(id: ObjectId, kind: impl Into<String>, json: impl Into<String>) -> Self {
        Self::new(id, kind, "application/json", json.into().into_bytes())
    }

    pub fn bytes(id: ObjectId, kind: impl Into<String>, data: Vec<u8>) -> Self {
        Self::new(id, kind, "application/octet-stream", data)
    }

    pub fn with_version(mut self, version: u64) -> Self {
        self.version = version;
        self
    }

    pub fn validate(&self) -> MResult<()> {
        if self.id.is_zero() {
            return invalid_store_record("object.id", "must not be zero");
        }

        if self.kind.trim().is_empty() {
            return invalid_store_record("object.kind", "must not be empty");
        }

        if self.version == 0 {
            return invalid_store_record("object.version", "must be greater than zero");
        }

        if self.encoding.trim().is_empty() {
            return invalid_store_record("object.encoding", "must not be empty");
        }

        Ok(())
    }
}

// -----------------------------------------------------------------------------
// Task Records
// -----------------------------------------------------------------------------

#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TaskStatus {
    pub name: String,
}

impl TaskStatus {
    pub fn new(name: impl Into<String>) -> Self {
        Self { name: name.into() }
    }

    pub fn pending() -> Self {
        Self::new("pending")
    }

    pub fn running() -> Self {
        Self::new("running")
    }

    pub fn completed() -> Self {
        Self::new("completed")
    }

    pub fn failed() -> Self {
        Self::new("failed")
    }

    pub fn cancelled() -> Self {
        Self::new("cancelled")
    }

    pub fn validate(&self) -> MResult<()> {
        if self.name.trim().is_empty() {
            return invalid_store_record("task.status", "must not be empty");
        }

        Ok(())
    }
}

impl Default for TaskStatus {
    fn default() -> Self {
        Self::pending()
    }
}

#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TaskRecord {
    pub id: TaskId,
    pub module_version: Option<ModuleVersionId>,
    pub subject: String,
    pub status: TaskStatus,
    pub capabilities: Vec<CapabilityId>,
}

impl TaskRecord {
    pub fn new(id: TaskId, subject: impl Into<String>) -> Self {
        Self {
            id,
            module_version: None,
            subject: subject.into(),
            status: TaskStatus::pending(),
            capabilities: Vec::new(),
        }
    }

    pub fn with_module_version(mut self, module_version: ModuleVersionId) -> Self {
        self.module_version = Some(module_version);
        self
    }

    pub fn with_capabilities(mut self, capabilities: Vec<CapabilityId>) -> Self {
        self.capabilities = capabilities;
        self
    }

    pub fn with_status(mut self, status: TaskStatus) -> Self {
        self.status = status;
        self
    }

    pub fn validate(&self) -> MResult<()> {
        if self.id.is_zero() {
            return invalid_store_record("task.id", "must not be zero");
        }

        if self.subject.trim().is_empty() {
            return invalid_store_record("task.subject", "must not be empty");
        }

        self.status.validate()
    }
}

// -----------------------------------------------------------------------------
// Actor and Message Records
// -----------------------------------------------------------------------------

#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ActorRecord {
    pub id: ActorId,
    pub subject: String,
    pub behavior: Option<ModuleVersionId>,
    pub state: Option<ObjectId>,
    pub status: String,
    pub capabilities: Vec<CapabilityId>,
}

impl ActorRecord {
    pub fn new(id: ActorId, subject: impl Into<String>) -> Self {
        Self {
            id,
            subject: subject.into(),
            behavior: None,
            state: None,
            status: "ready".to_string(),
            capabilities: Vec::new(),
        }
    }

    pub fn with_behavior(mut self, behavior: ModuleVersionId) -> Self {
        self.behavior = Some(behavior);
        self
    }

    pub fn with_state(mut self, state: ObjectId) -> Self {
        self.state = Some(state);
        self
    }

    pub fn with_status(mut self, status: impl Into<String>) -> Self {
        self.status = status.into();
        self
    }

    pub fn with_capabilities(mut self, capabilities: Vec<CapabilityId>) -> Self {
        self.capabilities = capabilities;
        self
    }

    pub fn validate(&self) -> MResult<()> {
        if self.id.is_zero() {
            return invalid_store_record("actor.id", "must not be zero");
        }

        if self.subject.trim().is_empty() {
            return invalid_store_record("actor.subject", "must not be empty");
        }

        if self.status.trim().is_empty() {
            return invalid_store_record("actor.status", "must not be empty");
        }

        Ok(())
    }
}

#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct MessageRecord {
    pub id: MessageId,
    pub actor: ActorId,
    pub sender: Option<String>,
    pub kind: String,
    pub payload: Vec<u8>,
}

impl MessageRecord {
    pub fn new(id: MessageId, actor: ActorId, kind: impl Into<String>, payload: Vec<u8>) -> Self {
        Self {
            id,
            actor,
            sender: None,
            kind: kind.into(),
            payload,
        }
    }

    pub fn with_sender(mut self, sender: impl Into<String>) -> Self {
        self.sender = Some(sender.into());
        self
    }

    pub fn validate(&self) -> MResult<()> {
        if self.id.is_zero() {
            return invalid_store_record("message.id", "must not be zero");
        }

        if self.actor.is_zero() {
            return invalid_store_record("message.actor", "must not be zero");
        }

        if self.kind.trim().is_empty() {
            return invalid_store_record("message.kind", "must not be empty");
        }

        Ok(())
    }
}

// -----------------------------------------------------------------------------
// Transactions
// -----------------------------------------------------------------------------

#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TransactionRecord {
    pub id: TransactionId,
    pub subject: String,

    pub read_set: Vec<ObjectId>,
    pub write_set: Vec<ObjectId>,

    pub message_acks: Vec<MessageId>,
    pub message_sends: Vec<MessageId>,

    pub task_updates: Vec<TaskId>,
    pub actor_updates: Vec<ActorId>,

    pub events: Vec<EventId>,
    #[cfg_attr(feature = "serde", serde(default))]
    pub effects: Vec<RuntimeEffectRecord>,
}

impl TransactionRecord {
    pub fn new(id: TransactionId, subject: impl Into<String>) -> Self {
        Self {
            id,
            subject: subject.into(),

            read_set: Vec::new(),
            write_set: Vec::new(),

            message_acks: Vec::new(),
            message_sends: Vec::new(),

            task_updates: Vec::new(),
            actor_updates: Vec::new(),

            events: Vec::new(),
            effects: Vec::new(),
        }
    }

    pub fn with_read_set(mut self, read_set: Vec<ObjectId>) -> Self {
        self.read_set = read_set;
        self
    }

    pub fn with_write_set(mut self, write_set: Vec<ObjectId>) -> Self {
        self.write_set = write_set;
        self
    }

    pub fn with_message_acks(mut self, message_acks: Vec<MessageId>) -> Self {
        self.message_acks = message_acks;
        self
    }

    pub fn with_message_sends(mut self, message_sends: Vec<MessageId>) -> Self {
        self.message_sends = message_sends;
        self
    }

    pub fn with_task_updates(mut self, task_updates: Vec<TaskId>) -> Self {
        self.task_updates = task_updates;
        self
    }

    pub fn with_actor_updates(mut self, actor_updates: Vec<ActorId>) -> Self {
        self.actor_updates = actor_updates;
        self
    }

    pub fn with_events(mut self, events: Vec<EventId>) -> Self {
        self.events = events;
        self
    }

    pub fn with_effects(mut self, effects: Vec<RuntimeEffectRecord>) -> Self {
        self.effects = effects;
        self
    }

    pub fn validate(&self) -> MResult<()> {
        if self.id.is_zero() {
            return invalid_store_record("transaction.id", "must not be zero");
        }

        if self.subject.trim().is_empty() {
            return invalid_store_record("transaction.subject", "must not be empty");
        }

        Ok(())
    }
}

#[derive(Clone, Debug)]
pub struct RuntimeStoreCommit {
    pub transaction: TransactionRecord,
    pub module_puts: Vec<ModuleRecord>,
    pub module_version_puts: Vec<ModuleVersionRecord>,
    pub capability_grants: Vec<(CapabilityId, Arc<dyn Capability>)>,
    pub capability_revocations: Vec<CapabilityId>,
    pub object_puts: Vec<ObjectRecord>,
    pub object_updates: Vec<ObjectRecord>,
    pub task_updates: Vec<TaskRecord>,
    pub actor_updates: Vec<ActorRecord>,
    pub message_acks: Vec<(ActorId, MessageId)>,
    pub message_enqueues: Vec<(ActorId, MessageRecord)>,
    pub events: Vec<RuntimeEvent>,
}

#[cfg(all(test, feature = "source"))]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum InMemoryAppendEventFailureKind {
    TransactionAborted,
    EffectAborted,
}

#[cfg(all(test, feature = "source"))]
impl InMemoryAppendEventFailureKind {
    fn matches(self, kind: &RuntimeEventKind) -> bool {
        matches!(
            (self, kind),
            (
                Self::TransactionAborted,
                RuntimeEventKind::TransactionAborted { .. },
            ) | (Self::EffectAborted, RuntimeEventKind::EffectAborted { .. },)
        )
    }

    fn name(self) -> &'static str {
        match self {
            Self::TransactionAborted => "TransactionAborted",
            Self::EffectAborted => "EffectAborted",
        }
    }
}

#[cfg(all(test, feature = "source"))]
#[derive(Debug, Clone)]
struct InMemoryAppendEventFailure {
    event: &'static str,
}

#[cfg(all(test, feature = "source"))]
impl MechErrorKind for InMemoryAppendEventFailure {
    fn name(&self) -> &str {
        "InMemoryAppendEventFailure"
    }

    fn message(&self) -> String {
        format!(
            "in-memory store test probe rejected {} event publication",
            self.event,
        )
    }
}

// -----------------------------------------------------------------------------
// In-Memory Store
// -----------------------------------------------------------------------------

#[derive(Clone, Debug, Default)]
pub struct InMemoryStore {
    modules: HashMap<ModuleId, ModuleRecord>,
    modules_by_name: HashMap<String, ModuleId>,
    module_versions: HashMap<ModuleVersionId, ModuleVersionRecord>,
    active_module_versions: HashMap<ModuleId, ModuleVersionId>,

    objects: HashMap<ObjectId, ObjectRecord>,

    tasks: HashMap<TaskId, TaskRecord>,

    actors: HashMap<ActorId, ActorRecord>,
    mailboxes: HashMap<ActorId, VecDeque<MessageRecord>>,

    capabilities: HashMap<CapabilityId, Arc<dyn Capability>>,
    capabilities_by_subject: HashMap<String, Vec<CapabilityId>>,
    revoked_capabilities: HashMap<CapabilityId, bool>,

    events: HashMap<EventId, RuntimeEvent>,
    event_order: VecDeque<EventId>,
    max_events: Option<usize>,

    transactions: HashMap<TransactionId, TransactionRecord>,
    transaction_order: Vec<TransactionId>,

    #[cfg(test)]
    panic_on_get_object: bool,
    #[cfg(all(test, feature = "source"))]
    panic_on_commit_runtime: bool,
    #[cfg(all(test, feature = "source"))]
    commit_runtime_calls: Option<Arc<AtomicUsize>>,
    #[cfg(all(test, feature = "source"))]
    append_event_failures: Option<Arc<Mutex<VecDeque<InMemoryAppendEventFailureKind>>>>,
}

impl InMemoryStore {
    pub fn new() -> Self {
        Self::default()
    }

    #[cfg(test)]
    fn cloned_record_count_for_cost_probe(&self) -> usize {
        self.modules.len()
            + self.module_versions.len()
            + self.active_module_versions.len()
            + self.objects.len()
            + self.tasks.len()
            + self.actors.len()
            + self.mailboxes.len()
            + self.mailboxes.values().map(VecDeque::len).sum::<usize>()
            + self.capabilities.len()
            + self.capabilities_by_subject.len()
            + self
                .capabilities_by_subject
                .values()
                .map(Vec::len)
                .sum::<usize>()
            + self.revoked_capabilities.len()
            + self.events.len()
            + self.event_order.len()
            + self.transactions.len()
            + self.transaction_order.len()
    }

    #[cfg(test)]
    pub(crate) fn panic_on_get_object_for_test(&mut self) {
        self.panic_on_get_object = true;
    }

    #[cfg(all(test, feature = "source"))]
    pub(crate) fn panic_on_commit_runtime_for_test(&mut self) {
        self.panic_on_commit_runtime = true;
    }

    #[cfg(all(test, feature = "source"))]
    #[allow(
        dead_code,
        reason = "used by source-enabled transaction regression profiles"
    )]
    pub(crate) fn with_commit_runtime_counter_for_test(
        mut self,
        counter: Arc<AtomicUsize>,
    ) -> Self {
        self.commit_runtime_calls = Some(counter);
        self
    }

    #[cfg(all(test, feature = "source"))]
    pub(crate) fn with_append_event_failures_for_test(
        mut self,
        failures: Arc<Mutex<VecDeque<InMemoryAppendEventFailureKind>>>,
    ) -> Self {
        self.append_event_failures = Some(failures);
        self
    }

    fn prune_events(&mut self) {
        if let Some(max_events) = self.max_events {
            while self.event_order.len() > max_events {
                if let Some(removed) = self.event_order.pop_front() {
                    self.events.remove(&removed);
                }
            }
        }
    }

    fn ensure_module_exists(&self, module: ModuleId) -> MResult<()> {
        if !self.modules.contains_key(&module) {
            return Err(MechError::new(
                StoreRecordNotFoundError {
                    record_type: "module",
                    id: module.to_string(),
                },
                None,
            ));
        }

        Ok(())
    }

    fn ensure_module_version_exists(&self, version: ModuleVersionId) -> MResult<()> {
        if !self.module_versions.contains_key(&version) {
            return Err(MechError::new(
                StoreRecordNotFoundError {
                    record_type: "module_version",
                    id: version.to_string(),
                },
                None,
            ));
        }

        Ok(())
    }

    fn ensure_actor_exists(&self, actor: ActorId) -> MResult<()> {
        if !self.actors.contains_key(&actor) {
            return Err(MechError::new(
                StoreRecordNotFoundError {
                    record_type: "actor",
                    id: actor.to_string(),
                },
                None,
            ));
        }

        Ok(())
    }
}

impl MechStore for InMemoryStore {
    fn put_module(&mut self, module: ModuleRecord) -> MResult<ModuleId> {
        module.validate()?;

        if self.modules.contains_key(&module.id) {
            return Err(MechError::new(
                StoreRecordAlreadyExistsError {
                    record_type: "module",
                    id: module.id.to_string(),
                },
                None,
            ));
        }

        if self.modules_by_name.contains_key(&module.name) {
            return Err(MechError::new(
                StoreRecordAlreadyExistsError {
                    record_type: "module.name",
                    id: module.name.clone(),
                },
                None,
            ));
        }

        let id = module.id;
        self.modules_by_name.insert(module.name.clone(), id);
        self.modules.insert(id, module);
        Ok(id)
    }

    fn get_module(&self, id: ModuleId) -> MResult<Option<ModuleRecord>> {
        Ok(self.modules.get(&id).cloned())
    }

    fn find_module_by_name(&self, name: &str) -> MResult<Option<ModuleRecord>> {
        let Some(id) = self.modules_by_name.get(name) else {
            return Ok(None);
        };

        Ok(self.modules.get(id).cloned())
    }

    fn put_module_version(&mut self, version: ModuleVersionRecord) -> MResult<ModuleVersionId> {
        version.validate()?;
        self.ensure_module_exists(version.module)?;
        #[cfg(feature = "source")]
        {
            version.validate_source_owner(&self.modules[&version.module].name)?;
            version.validate_source_revisions(self.module_versions.values())?;
        }

        if self.module_versions.contains_key(&version.id) {
            return Err(MechError::new(
                StoreRecordAlreadyExistsError {
                    record_type: "module_version",
                    id: version.id.to_string(),
                },
                None,
            ));
        }

        let id = version.id;
        self.module_versions.insert(id, version);
        Ok(id)
    }

    fn get_module_version(&self, id: ModuleVersionId) -> MResult<Option<ModuleVersionRecord>> {
        Ok(self.module_versions.get(&id).cloned())
    }

    #[cfg(feature = "source")]
    fn module_source_documents(&self, module: ModuleId) -> MResult<Vec<SourceDocument>> {
        Ok(self
            .module_versions
            .values()
            .filter(|version| version.module == module)
            .filter_map(|version| version.source_document.clone())
            .collect())
    }

    fn set_active_module_version(
        &mut self,
        module: ModuleId,
        version: ModuleVersionId,
    ) -> MResult<()> {
        self.ensure_module_exists(module)?;
        self.ensure_module_version_exists(version)?;

        let version_record = self.module_versions.get(&version).unwrap();

        if version_record.module != module {
            return Err(MechError::new(
                InvalidStoreRecordError {
                    field: "active_module_version",
                    reason: "module version does not belong to module",
                },
                None,
            ));
        }

        self.active_module_versions.insert(module, version);
        Ok(())
    }

    fn get_active_module_version(&self, module: ModuleId) -> MResult<Option<ModuleVersionId>> {
        Ok(self.active_module_versions.get(&module).copied())
    }

    fn put_object(&mut self, object: ObjectRecord) -> MResult<ObjectId> {
        object.validate()?;

        if self.objects.contains_key(&object.id) {
            return Err(MechError::new(
                StoreRecordAlreadyExistsError {
                    record_type: "object",
                    id: object.id.to_string(),
                },
                None,
            ));
        }

        let id = object.id;
        self.objects.insert(id, object);
        Ok(id)
    }

    fn get_object(&self, id: ObjectId) -> MResult<Option<ObjectRecord>> {
        #[cfg(test)]
        if self.panic_on_get_object {
            panic!("deliberate store read panic");
        }
        Ok(self.objects.get(&id).cloned())
    }

    fn update_object(&mut self, object: ObjectRecord) -> MResult<ObjectId> {
        object.validate()?;

        if !self.objects.contains_key(&object.id) {
            return Err(MechError::new(
                StoreRecordNotFoundError {
                    record_type: "object",
                    id: object.id.to_string(),
                },
                None,
            ));
        }

        let id = object.id;
        self.objects.insert(id, object);
        Ok(id)
    }

    fn put_task(&mut self, task: TaskRecord) -> MResult<TaskId> {
        task.validate()?;

        if self.tasks.contains_key(&task.id) {
            return Err(MechError::new(
                StoreRecordAlreadyExistsError {
                    record_type: "task",
                    id: task.id.to_string(),
                },
                None,
            ));
        }

        let id = task.id;
        self.tasks.insert(id, task);
        Ok(id)
    }

    fn get_task(&self, id: TaskId) -> MResult<Option<TaskRecord>> {
        Ok(self.tasks.get(&id).cloned())
    }

    fn update_task(&mut self, task: TaskRecord) -> MResult<TaskId> {
        task.validate()?;

        if !self.tasks.contains_key(&task.id) {
            return Err(MechError::new(
                StoreRecordNotFoundError {
                    record_type: "task",
                    id: task.id.to_string(),
                },
                None,
            ));
        }

        let id = task.id;
        self.tasks.insert(id, task);
        Ok(id)
    }

    fn task_count(&self) -> MResult<u64> {
        collection_len_u64("tasks", self.tasks.len())
    }

    fn put_actor(&mut self, actor: ActorRecord) -> MResult<ActorId> {
        actor.validate()?;

        if self.actors.contains_key(&actor.id) {
            return Err(MechError::new(
                StoreRecordAlreadyExistsError {
                    record_type: "actor",
                    id: actor.id.to_string(),
                },
                None,
            ));
        }

        let id = actor.id;
        self.mailboxes.entry(id).or_default();
        self.actors.insert(id, actor);
        Ok(id)
    }

    fn get_actor(&self, id: ActorId) -> MResult<Option<ActorRecord>> {
        Ok(self.actors.get(&id).cloned())
    }

    fn update_actor(&mut self, actor: ActorRecord) -> MResult<ActorId> {
        actor.validate()?;

        if !self.actors.contains_key(&actor.id) {
            return Err(MechError::new(
                StoreRecordNotFoundError {
                    record_type: "actor",
                    id: actor.id.to_string(),
                },
                None,
            ));
        }

        let id = actor.id;
        self.actors.insert(id, actor);
        self.mailboxes.entry(id).or_default();
        Ok(id)
    }

    fn actor_count(&self) -> MResult<u64> {
        collection_len_u64("actors", self.actors.len())
    }

    fn enqueue_message(&mut self, actor: ActorId, message: MessageRecord) -> MResult<MessageId> {
        self.ensure_actor_exists(actor)?;
        message.validate()?;

        if message.actor != actor {
            return Err(MechError::new(
                InvalidStoreRecordError {
                    field: "message.actor",
                    reason: "message actor does not match target actor",
                },
                None,
            ));
        }

        let id = message.id;
        self.mailboxes.entry(actor).or_default().push_back(message);
        Ok(id)
    }

    fn mailbox_len(&self, actor: ActorId) -> MResult<u64> {
        self.ensure_actor_exists(actor)?;
        collection_len_u64(
            "actor_mailbox",
            self.mailboxes
                .get(&actor)
                .map(|mailbox| mailbox.len())
                .unwrap_or(0),
        )
    }

    fn peek_message(&self, actor: ActorId) -> MResult<Option<MessageRecord>> {
        self.ensure_actor_exists(actor)?;

        Ok(self
            .mailboxes
            .get(&actor)
            .and_then(|mailbox| mailbox.front().cloned()))
    }

    fn list_mailbox(&self, actor: ActorId) -> MResult<Vec<MessageRecord>> {
        self.ensure_actor_exists(actor)?;

        Ok(self
            .mailboxes
            .get(&actor)
            .map(|mailbox| mailbox.iter().cloned().collect())
            .unwrap_or_default())
    }

    fn ack_message(&mut self, actor: ActorId, message: MessageId) -> MResult<()> {
        self.ensure_actor_exists(actor)?;

        let Some(mailbox) = self.mailboxes.get_mut(&actor) else {
            return Ok(());
        };

        if let Some(index) = mailbox.iter().position(|queued| queued.id == message) {
            mailbox.remove(index);
        }

        Ok(())
    }

    fn grant_capability(
        &mut self,
        id: CapabilityId,
        capability: Arc<dyn Capability>,
    ) -> MResult<CapabilityId> {
        capability.validate()?;

        if id.is_zero() {
            return invalid_store_record("capability.id", "must not be zero");
        }

        if capability.id() != id {
            return Err(MechError::new(
                InvalidStoreRecordError {
                    field: "capability.id",
                    reason: "capability id does not match grant id",
                },
                None,
            ));
        }

        if self.capabilities.contains_key(&id) {
            return Err(MechError::new(
                StoreRecordAlreadyExistsError {
                    record_type: "capability",
                    id: id.to_string(),
                },
                None,
            ));
        }

        self.capabilities_by_subject
            .entry(capability.subject_key().to_string())
            .or_default()
            .push(id);

        self.revoked_capabilities.insert(id, false);
        self.capabilities.insert(id, capability);
        Ok(id)
    }

    fn rollback_capability_grant(&mut self, id: CapabilityId) -> MResult<()> {
        self.capabilities.remove(&id);
        self.revoked_capabilities.remove(&id);

        self.capabilities_by_subject.retain(|_, ids| {
            ids.retain(|candidate| *candidate != id);
            !ids.is_empty()
        });

        Ok(())
    }

    fn get_capability(&self, id: CapabilityId) -> MResult<Option<Arc<dyn Capability>>> {
        Ok(self.capabilities.get(&id).cloned())
    }

    fn list_capabilities_for_subject(&self, subject_key: &str) -> MResult<Vec<CapabilityId>> {
        Ok(self
            .capabilities_by_subject
            .get(subject_key)
            .cloned()
            .unwrap_or_default())
    }

    fn revoke_capability(&mut self, id: CapabilityId) -> MResult<()> {
        let Some(capability) = self.capabilities.get(&id) else {
            return Err(MechError::new(
                StoreRecordNotFoundError {
                    record_type: "capability",
                    id: id.to_string(),
                },
                None,
            ));
        };

        if !capability.is_revocable() {
            return Err(MechError::new(
                StoreCapabilityNotRevocableError { capability: id },
                None,
            ));
        }

        self.revoked_capabilities.insert(id, true);
        Ok(())
    }

    fn is_capability_revoked(&self, id: CapabilityId) -> MResult<bool> {
        if !self.capabilities.contains_key(&id) {
            return Err(MechError::new(
                StoreRecordNotFoundError {
                    record_type: "capability",
                    id: id.to_string(),
                },
                None,
            ));
        }

        Ok(self.revoked_capabilities.get(&id).copied().unwrap_or(false))
    }

    fn append_event(&mut self, event: RuntimeEvent) -> MResult<EventId> {
        event.validate()?;

        #[cfg(all(test, feature = "source"))]
        if let Some(failures) = &self.append_event_failures {
            let mut failures = failures
                .lock()
                .expect("append-event failure probe mutex poisoned");
            if failures
                .front()
                .is_some_and(|failure| failure.matches(&event.kind))
            {
                let failure = failures
                    .pop_front()
                    .expect("matching append-event failure must exist");
                return Err(MechError::new(
                    InMemoryAppendEventFailure {
                        event: failure.name(),
                    },
                    None,
                ));
            }
        }

        if self.events.contains_key(&event.id) {
            return Err(MechError::new(
                StoreRecordAlreadyExistsError {
                    record_type: "event",
                    id: event.id.to_string(),
                },
                None,
            ));
        }

        let id = event.id;
        self.events.insert(id, event);
        self.event_order.push_back(id);
        self.prune_events();
        Ok(id)
    }

    fn get_event(&self, id: EventId) -> MResult<Option<RuntimeEvent>> {
        Ok(self.events.get(&id).cloned())
    }

    fn list_events(&self, limit: Option<usize>) -> MResult<Vec<RuntimeEvent>> {
        let iter = self.event_order.iter().rev();

        let ids: Vec<EventId> = match limit {
            Some(limit) => iter.take(limit).copied().collect(),
            None => iter.copied().collect(),
        };

        Ok(ids
            .into_iter()
            .rev()
            .filter_map(|id| self.events.get(&id).cloned())
            .collect())
    }

    fn configure_event_retention(&mut self, max_events: Option<usize>) -> MResult<()> {
        self.max_events = max_events;
        self.prune_events();
        Ok(())
    }

    fn commit_runtime(&mut self, commit: RuntimeStoreCommit) -> MResult<TransactionId> {
        #[cfg(any(test, feature = "runtime_bench_probes"))]
        crate::runtime::cost_probe::record_commit_runtime_call();
        #[cfg(all(test, feature = "source"))]
        if let Some(counter) = &self.commit_runtime_calls {
            counter.fetch_add(1, Ordering::SeqCst);
        }
        #[cfg(all(test, feature = "source"))]
        if self.panic_on_commit_runtime {
            panic!("deliberate store commit panic");
        }
        #[cfg(any(test, feature = "runtime_bench_probes"))]
        let prepare_started = std::time::Instant::now();
        let prepared = prepared_commit::PreparedInMemoryCommit::prepare(self, commit);
        #[cfg(any(test, feature = "runtime_bench_probes"))]
        crate::runtime::cost_probe::record_in_memory_store_prepare_duration(
            prepare_started.elapsed(),
        );
        let prepared = prepared?;

        #[cfg(any(test, feature = "runtime_bench_probes"))]
        let apply_started = std::time::Instant::now();
        let id = self.apply_prepared_runtime_commit(prepared);
        #[cfg(any(test, feature = "runtime_bench_probes"))]
        crate::runtime::cost_probe::record_in_memory_store_apply_duration(apply_started.elapsed());
        Ok(id)
    }

    fn commit_transaction(&mut self, tx: TransactionRecord) -> MResult<TransactionId> {
        tx.validate()?;

        if self.transactions.contains_key(&tx.id) {
            return Err(MechError::new(
                StoreRecordAlreadyExistsError {
                    record_type: "transaction",
                    id: tx.id.to_string(),
                },
                None,
            ));
        }

        let id = tx.id;
        self.transactions.insert(id, tx);
        self.transaction_order.push(id);
        #[cfg(any(test, feature = "runtime_bench_probes"))]
        crate::runtime::cost_probe::record_transaction_committed();
        Ok(id)
    }

    fn get_transaction(&self, id: TransactionId) -> MResult<Option<TransactionRecord>> {
        Ok(self.transactions.get(&id).cloned())
    }

    fn list_transactions(&self, limit: Option<usize>) -> MResult<Vec<TransactionRecord>> {
        let iter = self.transaction_order.iter().rev();

        let ids: Vec<TransactionId> = match limit {
            Some(limit) => iter.take(limit).copied().collect(),
            None => iter.copied().collect(),
        };

        Ok(ids
            .into_iter()
            .rev()
            .filter_map(|id| self.transactions.get(&id).cloned())
            .collect())
    }
}

// -----------------------------------------------------------------------------
// Store Errors
// -----------------------------------------------------------------------------

#[derive(Debug, Clone)]
pub struct InvalidStoreRecordError {
    pub field: &'static str,
    pub reason: &'static str,
}

impl MechErrorKind for InvalidStoreRecordError {
    fn name(&self) -> &str {
        "InvalidStoreRecord"
    }

    fn message(&self) -> String {
        format!(
            "Invalid store record field `{}`: {}",
            self.field, self.reason
        )
    }
}

fn invalid_store_record<T>(field: &'static str, reason: &'static str) -> MResult<T> {
    Err(MechError::new(
        InvalidStoreRecordError { field, reason },
        None,
    ))
}

#[derive(Debug, Clone)]
pub struct StoreRecordAlreadyExistsError {
    pub record_type: &'static str,
    pub id: String,
}

impl MechErrorKind for StoreRecordAlreadyExistsError {
    fn name(&self) -> &str {
        "StoreRecordAlreadyExists"
    }

    fn message(&self) -> String {
        format!("{} record already exists: {}", self.record_type, self.id)
    }
}

#[derive(Debug, Clone)]
pub struct StoreRecordNotFoundError {
    pub record_type: &'static str,
    pub id: String,
}

impl MechErrorKind for StoreRecordNotFoundError {
    fn name(&self) -> &str {
        "StoreRecordNotFound"
    }

    fn message(&self) -> String {
        format!("{} record not found: {}", self.record_type, self.id)
    }
}

#[derive(Debug, Clone)]
pub struct StoreCapabilityNotRevocableError {
    pub capability: CapabilityId,
}

#[derive(Debug, Clone)]
pub struct StoreCapacityReservationError {
    pub structure: &'static str,
}

impl MechErrorKind for StoreCapacityReservationError {
    fn name(&self) -> &str {
        "StoreCapacityReservation"
    }

    fn message(&self) -> String {
        format!(
            "unable to reserve capacity for in-memory store structure `{}`",
            self.structure
        )
    }
}

impl MechErrorKind for StoreCapabilityNotRevocableError {
    fn name(&self) -> &str {
        "StoreCapabilityNotRevocable"
    }

    fn message(&self) -> String {
        format!("Capability is not revocable: {}", self.capability)
    }
}

// -----------------------------------------------------------------------------
// Tests
// -----------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[cfg(feature = "source")]
    #[test]
    fn stored_document_owner_and_revision_cannot_be_aliased() {
        use mech_syntax::document::{ParseConfig, Revision};
        let uri = "memory:main.mec";
        let module = module_id(uri);
        let mut store = InMemoryStore::new();
        store.put_module(ModuleRecord::new(module, uri)).unwrap();
        let record = |id, owner, source: &str| {
            ModuleVersionRecord::new(ModuleVersionId(id), module, 1)
                .with_source(MechSourceCode::String(source.into()))
                .with_source_document(Some(
                    SourceDocument::parse_resolved(
                        owner,
                        Revision(0),
                        source,
                        ParseConfig::default(),
                    )
                    .unwrap(),
                ))
        };
        let wrong_owner = record(2, "memory:other.mec", "value := 1\n");
        assert!(store.put_module_version(wrong_owner.clone()).is_err());
        assert!(
            store
                .commit_runtime(runtime_commit(70, vec![], vec![wrong_owner]))
                .is_err()
        );
        let first = record(2, uri, "value := 1\n");
        let conflicting = record(3, uri, "value := 2\n");
        assert!(
            store
                .commit_runtime(runtime_commit(
                    71,
                    vec![],
                    vec![first.clone(), conflicting.clone()]
                ))
                .is_err()
        );
        assert!(
            store
                .get_module_version(ModuleVersionId(2))
                .unwrap()
                .is_none()
        );
        store.put_module_version(first.clone()).unwrap();
        assert!(store.put_module_version(conflicting.clone()).is_err());
        assert!(
            store
                .commit_runtime(runtime_commit(72, vec![], vec![conflicting]))
                .is_err()
        );
        assert_eq!(
            store.get_module_version(ModuleVersionId(2)).unwrap(),
            Some(first)
        );
        // Rebuilding an existing revision with different compilation inputs is valid.
        store
            .put_module_version(record(4, uri, "value := 1\n"))
            .unwrap();
    }

    #[cfg(feature = "source")]
    #[test]
    fn stored_source_document_must_match_exact_textual_source() {
        use mech_syntax::document::{ParseConfig, Revision};
        let document = SourceDocument::parse_resolved(
            "memory:main.mec",
            Revision(0),
            "value := 1\r\n",
            ParseConfig::default(),
        )
        .unwrap();
        for source in [
            None,
            Some(MechSourceCode::Html("value := 1\r\n".into())),
            Some(MechSourceCode::String("value := 2\r\n".into())),
            Some(MechSourceCode::String("value := 1\n".into())),
        ] {
            let mut version = ModuleVersionRecord::new(ModuleVersionId(2), ModuleId(1), 1)
                .with_source_document(Some(document.clone()));
            version.source = source;
            assert!(version.validate().is_err());
            let mut store = InMemoryStore::new();
            store
                .put_module(ModuleRecord::new(ModuleId(1), "memory:main.mec"))
                .unwrap();
            assert!(store.put_module_version(version).is_err());
            assert!(
                store
                    .get_module_version(ModuleVersionId(2))
                    .unwrap()
                    .is_none()
            );
        }
        let version = ModuleVersionRecord::new(ModuleVersionId(2), ModuleId(1), 1)
            .with_source(MechSourceCode::String("value := 1\r\n".into()))
            .with_source_document(Some(document));
        assert!(version.validate().is_ok());
    }

    use crate::capability::{BasicCapability, BasicOperation, BasicResource, BasicSubject};

    use crate::event::{RuntimeEvent, RuntimeEventKind};

    fn runtime_commit(
        id: u128,
        module_puts: Vec<ModuleRecord>,
        module_version_puts: Vec<ModuleVersionRecord>,
    ) -> RuntimeStoreCommit {
        RuntimeStoreCommit {
            transaction: TransactionRecord::new(TransactionId(id), "test"),
            module_puts,
            module_version_puts,
            capability_grants: Vec::new(),
            capability_revocations: Vec::new(),
            object_puts: Vec::new(),
            object_updates: Vec::new(),
            task_updates: Vec::new(),
            actor_updates: Vec::new(),
            message_acks: Vec::new(),
            message_enqueues: Vec::new(),
            events: Vec::new(),
        }
    }

    #[test]
    fn runtime_cost_probe_store_clone_count_sums_logical_records_and_indexes() {
        let mut store = InMemoryStore::new();
        store
            .modules
            .insert(ModuleId(1), ModuleRecord::new(ModuleId(1), "one"));
        store.modules_by_name.insert("one".to_string(), ModuleId(1));
        store.module_versions.insert(
            ModuleVersionId(2),
            ModuleVersionRecord::new(ModuleVersionId(2), ModuleId(1), 1),
        );
        store
            .active_module_versions
            .insert(ModuleId(1), ModuleVersionId(2));
        store.objects.insert(
            ObjectId(3),
            ObjectRecord::text(ObjectId(3), "object", "value"),
        );
        store
            .tasks
            .insert(TaskId(4), TaskRecord::new(TaskId(4), "task:4"));
        store
            .actors
            .insert(ActorId(5), ActorRecord::new(ActorId(5), "actor:5"));
        store.mailboxes.insert(
            ActorId(5),
            VecDeque::from([MessageRecord::new(
                MessageId(6),
                ActorId(5),
                "message",
                Vec::new(),
            )]),
        );
        let capability = Arc::new(BasicCapability::new(
            CapabilityId(7),
            &BasicSubject::new("subject"),
            &BasicResource::new("resource"),
            [BasicOperation::new("read")],
        ));
        store.capabilities.insert(CapabilityId(7), capability);
        store
            .capabilities_by_subject
            .insert("subject".to_string(), vec![CapabilityId(7)]);
        store.revoked_capabilities.insert(CapabilityId(7), false);
        store.events.insert(
            EventId(8),
            RuntimeEvent::new(EventId(8), 0, RuntimeEventKind::RuntimeTickStarted),
        );
        store.event_order.push_back(EventId(8));
        store.transactions.insert(
            TransactionId(9),
            TransactionRecord::new(TransactionId(9), "subject"),
        );
        store.transaction_order.push(TransactionId(9));

        // The module-name index is deliberately excluded by the frozen runtime cost
        // diagnostic definition; all requested record and index families sum
        // to sixteen logical retained items here.
        assert_eq!(store.cloned_record_count_for_cost_probe(), 16);
    }

    #[test]
    fn module_round_trip() {
        let mut store = InMemoryStore::new();

        let module = ModuleRecord::new(ModuleId(1), "main");
        store.put_module(module).unwrap();

        let loaded = store.get_module(ModuleId(1)).unwrap().unwrap();
        assert_eq!(loaded.name, "main");

        let found = store.find_module_by_name("main").unwrap().unwrap();
        assert_eq!(found.id, ModuleId(1));
    }

    #[test]
    fn module_version_requires_existing_module() {
        let mut store = InMemoryStore::new();

        let version = ModuleVersionRecord::new(ModuleVersionId(1), ModuleId(999), 1);

        assert!(store.put_module_version(version).is_err());
    }

    #[test]
    fn active_module_version_round_trip() {
        let mut store = InMemoryStore::new();

        store
            .put_module(ModuleRecord::new(ModuleId(1), "main"))
            .unwrap();

        store
            .put_module_version(ModuleVersionRecord::new(
                ModuleVersionId(10),
                ModuleId(1),
                1,
            ))
            .unwrap();

        store
            .set_active_module_version(ModuleId(1), ModuleVersionId(10))
            .unwrap();

        assert_eq!(
            store.get_active_module_version(ModuleId(1)).unwrap(),
            Some(ModuleVersionId(10)),
        );
    }

    #[test]
    fn object_round_trip() {
        let mut store = InMemoryStore::new();

        let object = ObjectRecord::text(ObjectId(1), "note", "hello");
        store.put_object(object).unwrap();

        let loaded = store.get_object(ObjectId(1)).unwrap().unwrap();
        assert_eq!(loaded.kind, "note");
        assert_eq!(loaded.encoding, "text/plain");
        assert_eq!(loaded.data, b"hello");
    }

    #[test]
    fn task_round_trip() {
        let mut store = InMemoryStore::new();

        let task = TaskRecord::new(TaskId(1), "task:1").with_status(TaskStatus::running());

        store.put_task(task).unwrap();

        let loaded = store.get_task(TaskId(1)).unwrap().unwrap();
        assert_eq!(loaded.status.name, "running");
    }

    #[test]
    fn actor_message_queue() {
        let mut store = InMemoryStore::new();

        store
            .put_actor(ActorRecord::new(ActorId(1), "actor:1"))
            .unwrap();

        store
            .enqueue_message(
                ActorId(1),
                MessageRecord::new(MessageId(1), ActorId(1), "ping", b"hello".to_vec()),
            )
            .unwrap();

        let peeked = store.peek_message(ActorId(1)).unwrap().unwrap();
        assert_eq!(peeked.kind, "ping");

        let popped = store.pop_message(ActorId(1)).unwrap().unwrap();
        assert_eq!(popped.payload, b"hello");

        assert!(store.pop_message(ActorId(1)).unwrap().is_none());
    }

    #[test]
    fn actor_message_ack_removes_specific_message() {
        let mut store = InMemoryStore::new();

        store
            .put_actor(ActorRecord::new(ActorId(1), "actor:1"))
            .unwrap();

        let first = MessageRecord::new(MessageId(1), ActorId(1), "first", b"one".to_vec());

        let second = MessageRecord::new(MessageId(2), ActorId(1), "second", b"two".to_vec());

        store.enqueue_message(ActorId(1), first).unwrap();
        store.enqueue_message(ActorId(1), second).unwrap();

        assert_eq!(
            store.peek_message(ActorId(1)).unwrap().unwrap().id,
            MessageId(1),
        );

        store.ack_message(ActorId(1), MessageId(1)).unwrap();

        assert_eq!(
            store.peek_message(ActorId(1)).unwrap().unwrap().id,
            MessageId(2),
        );

        store.ack_message(ActorId(1), MessageId(2)).unwrap();

        assert!(store.peek_message(ActorId(1)).unwrap().is_none());
    }

    #[test]
    fn capability_round_trip_and_revoke() {
        let mut store = InMemoryStore::new();

        let subject = BasicSubject::new("task:1");
        let resource = BasicResource::new("db:users");

        let capability = BasicCapability::new(
            CapabilityId(1),
            &subject,
            &resource,
            [BasicOperation::read()],
        );

        store
            .grant_capability(CapabilityId(1), Arc::new(capability))
            .unwrap();

        let ids = store.list_capabilities_for_subject("task:1").unwrap();

        assert_eq!(ids, vec![CapabilityId(1)]);

        assert!(!store.is_capability_revoked(CapabilityId(1)).unwrap());

        store.revoke_capability(CapabilityId(1)).unwrap();

        assert!(store.is_capability_revoked(CapabilityId(1)).unwrap());
    }

    #[test]
    fn capability_grant_rollback_removes_non_revocable_capability() {
        let mut store = InMemoryStore::new();
        let capability =
            BasicCapability::from_keys(CapabilityId(1), "task:1", "db:users", [":read"])
                .revocable(false);

        store
            .grant_capability(CapabilityId(1), Arc::new(capability))
            .unwrap();
        store.rollback_capability_grant(CapabilityId(1)).unwrap();

        assert!(store.get_capability(CapabilityId(1)).unwrap().is_none());
        assert!(
            store
                .list_capabilities_for_subject("task:1")
                .unwrap()
                .is_empty()
        );

        let replacement =
            BasicCapability::from_keys(CapabilityId(1), "task:1", "db:users", [":read"])
                .revocable(false);
        assert_eq!(
            store
                .grant_capability(CapabilityId(1), Arc::new(replacement))
                .unwrap(),
            CapabilityId(1),
        );
    }

    #[test]
    fn capability_grant_rollback_is_idempotent() {
        let mut store = InMemoryStore::new();

        assert!(store.rollback_capability_grant(CapabilityId(1)).is_ok());

        let capability =
            BasicCapability::from_keys(CapabilityId(1), "task:1", "db:users", [":read"]);
        store
            .grant_capability(CapabilityId(1), Arc::new(capability))
            .unwrap();

        assert!(store.rollback_capability_grant(CapabilityId(1)).is_ok());
        assert!(store.rollback_capability_grant(CapabilityId(1)).is_ok());
    }

    #[test]
    fn event_order_is_preserved_with_limit() {
        let mut store = InMemoryStore::new();

        store
            .append_event(RuntimeEvent::new(
                EventId(1),
                0,
                RuntimeEventKind::RuntimeError {
                    message: "first".to_string(),
                },
            ))
            .unwrap();

        store
            .append_event(RuntimeEvent::new(
                EventId(2),
                1,
                RuntimeEventKind::RuntimeError {
                    message: "second".to_string(),
                },
            ))
            .unwrap();

        store
            .append_event(RuntimeEvent::new(
                EventId(3),
                2,
                RuntimeEventKind::RuntimeError {
                    message: "third".to_string(),
                },
            ))
            .unwrap();

        let events = store.list_events(Some(2)).unwrap();

        assert_eq!(events.len(), 2);
        assert_eq!(events[0].id, EventId(2));
        assert_eq!(events[1].id, EventId(3));
        assert_eq!(events[0].sequence, 1);
        assert_eq!(events[1].sequence, 2);
    }

    #[test]
    fn in_memory_event_retention_keeps_newest_events() {
        let mut store = InMemoryStore::new();
        store.configure_event_retention(Some(2)).unwrap();
        for id in 1u64..=3 {
            store
                .append_event(RuntimeEvent::new(
                    EventId(id as u128),
                    id,
                    RuntimeEventKind::RuntimeError {
                        message: format!("event {id}"),
                    },
                ))
                .unwrap();
        }
        assert!(store.get_event(EventId(1)).unwrap().is_none());
        let events = store.list_events(None).unwrap();
        assert_eq!(
            events.iter().map(|event| event.id).collect::<Vec<_>>(),
            vec![EventId(2), EventId(3)]
        );
    }

    #[test]
    fn transaction_round_trip() {
        let mut store = InMemoryStore::new();

        let tx = TransactionRecord::new(TransactionId(1), "task:1")
            .with_read_set(vec![ObjectId(1)])
            .with_write_set(vec![ObjectId(2)])
            .with_message_acks(vec![MessageId(3)])
            .with_message_sends(vec![MessageId(4)])
            .with_task_updates(vec![TaskId(5)])
            .with_actor_updates(vec![ActorId(6)])
            .with_events(vec![EventId(7)]);

        store.commit_transaction(tx).unwrap();

        let loaded = store.get_transaction(TransactionId(1)).unwrap().unwrap();

        assert_eq!(loaded.subject, "task:1");
        assert_eq!(loaded.read_set, vec![ObjectId(1)]);
        assert_eq!(loaded.write_set, vec![ObjectId(2)]);
        assert_eq!(loaded.message_acks, vec![MessageId(3)]);
        assert_eq!(loaded.message_sends, vec![MessageId(4)]);
        assert_eq!(loaded.task_updates, vec![TaskId(5)]);
        assert_eq!(loaded.actor_updates, vec![ActorId(6)]);
        assert_eq!(loaded.events, vec![EventId(7)]);
    }

    #[test]
    fn in_memory_store_batch_failure_does_not_mutate_store() {
        let mut store = InMemoryStore::new();

        let event = RuntimeEvent::new(
            EventId(1),
            0,
            RuntimeEventKind::ObjectCreated {
                object_id: ObjectId(1),
            },
        );

        let commit = RuntimeStoreCommit {
            transaction: TransactionRecord::new(TransactionId(1), "task:1")
                .with_write_set(vec![ObjectId(1), ObjectId(2)])
                .with_events(vec![EventId(1)]),
            module_puts: Vec::new(),
            module_version_puts: Vec::new(),
            capability_grants: Vec::new(),
            capability_revocations: Vec::new(),
            object_puts: vec![ObjectRecord::text(ObjectId(1), "note", "hello")],
            object_updates: vec![ObjectRecord::text(ObjectId(2), "note", "missing")],
            task_updates: Vec::new(),
            actor_updates: Vec::new(),
            message_acks: Vec::new(),
            message_enqueues: Vec::new(),
            events: vec![event],
        };

        assert!(store.commit_runtime(commit).is_err());
        assert!(store.get_object(ObjectId(1)).unwrap().is_none());
        assert!(store.get_object(ObjectId(2)).unwrap().is_none());
        assert!(store.get_event(EventId(1)).unwrap().is_none());
        assert!(store.get_transaction(TransactionId(1)).unwrap().is_none());
        assert!(store.list_events(None).unwrap().is_empty());
        assert!(store.list_transactions(None).unwrap().is_empty());
    }

    #[test]
    fn runtime_commit_publishes_module_and_version_together() {
        let mut store = InMemoryStore::new();
        let module = ModuleRecord::new(module_id("memory://main.mec"), "memory://main.mec");
        let version = ModuleVersionRecord::new(ModuleVersionId(10), module.id, 1);

        store
            .commit_runtime(runtime_commit(
                1,
                vec![module.clone()],
                vec![version.clone()],
            ))
            .unwrap();

        assert_eq!(store.get_module(module.id).unwrap(), Some(module));
        assert_eq!(store.get_module_version(version.id).unwrap(), Some(version),);
    }

    #[test]
    fn runtime_commit_missing_module_owner_is_atomic() {
        let mut store = InMemoryStore::new();
        let version =
            ModuleVersionRecord::new(ModuleVersionId(10), module_id("memory://missing.mec"), 1);

        assert!(
            store
                .commit_runtime(runtime_commit(1, Vec::new(), vec![version]))
                .is_err(),
        );
        assert!(store.list_transactions(None).unwrap().is_empty());
        assert!(
            store
                .get_module_version(ModuleVersionId(10))
                .unwrap()
                .is_none(),
        );
    }

    #[test]
    fn runtime_commit_missing_dependency_is_atomic() {
        let mut store = InMemoryStore::new();
        let module = ModuleRecord::new(module_id("memory://main.mec"), "memory://main.mec");
        let version = ModuleVersionRecord::new(ModuleVersionId(10), module.id, 1)
            .with_dependencies(vec![ModuleVersionId(99)]);

        assert!(
            store
                .commit_runtime(runtime_commit(1, vec![module.clone()], vec![version],))
                .is_err(),
        );
        assert!(store.get_module(module.id).unwrap().is_none());
        assert!(store.list_transactions(None).unwrap().is_empty());
    }

    #[test]
    fn identical_runtime_module_publication_is_idempotent() {
        let mut store = InMemoryStore::new();
        let module = ModuleRecord::new(module_id("memory://main.mec"), "memory://main.mec")
            .with_description("first");
        let version = ModuleVersionRecord::new(ModuleVersionId(10), module.id, 1);
        store
            .commit_runtime(runtime_commit(
                1,
                vec![module.clone()],
                vec![version.clone()],
            ))
            .unwrap();

        store
            .commit_runtime(runtime_commit(
                2,
                vec![ModuleRecord::new(module.id, module.name.clone()).with_description("second")],
                vec![version],
            ))
            .unwrap();

        assert_eq!(
            store
                .get_module(module.id)
                .unwrap()
                .unwrap()
                .description
                .as_deref(),
            Some("first"),
        );
    }

    #[test]
    fn runtime_module_conflict_leaves_other_categories_unchanged() {
        let mut store = InMemoryStore::new();
        let module = ModuleRecord::new(module_id("memory://main.mec"), "memory://main.mec");
        let version = ModuleVersionRecord::new(ModuleVersionId(10), module.id, 1);
        store
            .commit_runtime(runtime_commit(1, vec![module.clone()], vec![version]))
            .unwrap();
        let mut conflict = runtime_commit(
            2,
            vec![module],
            vec![ModuleVersionRecord::new(
                ModuleVersionId(10),
                module_id("memory://other.mec"),
                1,
            )],
        );
        conflict
            .object_puts
            .push(ObjectRecord::text(ObjectId(20), "note", "must not commit"));

        assert!(store.commit_runtime(conflict).is_err());
        assert!(store.get_object(ObjectId(20)).unwrap().is_none());
        assert!(store.get_transaction(TransactionId(2)).unwrap().is_none(),);
    }

    #[test]
    fn context_import_without_import_edge_validates() {
        let import = SourceImportDeclaration {
            specifier: "browser/dom".to_string(),
            alias: Some(SourceImportAlias::Context("ui".to_string())),
            module: Some("browser".to_string()),
            item: Some("dom".to_string()),
            kind: crate::resolver::SourceImportKind::Single {
                name: "dom".to_string(),
            },
        };
        let version = ModuleVersionRecord::new(ModuleVersionId(10), ModuleId(1), 1)
            .with_imports(vec![import]);
        assert!(version.validate_import_edges().is_ok());
    }
}
