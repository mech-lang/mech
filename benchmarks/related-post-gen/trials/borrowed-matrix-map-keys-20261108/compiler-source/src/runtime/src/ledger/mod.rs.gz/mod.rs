//! Bounded owned turn-record storage primitives.

mod capacity;
#[cfg(any(test, feature = "runtime_bench_probes"))]
mod pool;
#[cfg(any(test, feature = "runtime_bench_probes"))]
mod queue;
mod retained;
#[cfg(test)]
mod tests;

use mech_core::MResult;

use crate::turn_record::{AccountedRecord, LedgerSequence};

pub use capacity::RecordEstimate;
pub(crate) use capacity::{CapacityController, CapacityReservation};
#[cfg(any(feature = "runtime_bench_probes", feature = "resident-external"))]
pub(crate) use capacity::{LedgerAllocationFailed, invalid_permit};
#[cfg(any(test, feature = "runtime_bench_probes"))]
pub use pool::{PooledRecordBuffer, RecordBufferPool};
#[cfg(any(test, feature = "runtime_bench_probes"))]
pub use queue::OwnedTurnRecordQueue;
pub use retained::RetainedTurnLedger;

/// An unused reservation for one future ledger append.
#[derive(Debug)]
pub struct LedgerPermit {
    controller: CapacityController,
    ledger_identity: u64,
    ledger_generation: u64,
    reservation: Option<CapacityReservation>,
    consumed: bool,
}

impl LedgerPermit {
    #[cfg(test)]
    pub fn sequence(&self) -> LedgerSequence {
        self.reservation
            .as_ref()
            .expect("live ledger permit reservation")
            .sequence
    }

    fn new(controller: CapacityController, reservation: CapacityReservation) -> Self {
        Self {
            ledger_identity: controller.identity(),
            ledger_generation: controller.generation(),
            controller,
            reservation: Some(reservation),
            consumed: false,
        }
    }
}

impl Drop for LedgerPermit {
    fn drop(&mut self) {
        if let Some(reservation) = self.reservation.take() {
            self.controller.release_reserved(reservation);
        }
    }
}

/// An owned record bound to already-reserved ledger capacity.
#[derive(Debug)]
pub struct PreparedLedgerAppend<R> {
    controller: CapacityController,
    reservation: Option<CapacityReservation>,
    record: Option<R>,
}

impl<R> PreparedLedgerAppend<R> {
    pub(crate) fn reservation(&self) -> CapacityReservation {
        *self
            .reservation
            .as_ref()
            .expect("live prepared ledger append reservation")
    }

    #[cfg(test)]
    pub fn retained_bytes(&self) -> usize {
        self.reservation
            .as_ref()
            .map_or(0, |reservation| reservation.bytes)
    }

    pub(crate) fn into_parts(mut self) -> (CapacityReservation, R) {
        let reservation = self
            .reservation
            .take()
            .expect("prepared append reservation consumed once");
        let record = self
            .record
            .take()
            .expect("prepared append record consumed once");
        (reservation, record)
    }

    pub(crate) fn controller(&self) -> &CapacityController {
        &self.controller
    }
}

impl<R> Drop for PreparedLedgerAppend<R> {
    fn drop(&mut self) {
        if let Some(reservation) = self.reservation.take() {
            self.controller.release_prepared(reservation);
        }
    }
}

/// Reserve, prepare, then infallibly append an owned record.
pub(crate) trait TurnLedger<R>
where
    R: AccountedRecord,
{
    fn reserve(&self, estimate: RecordEstimate) -> MResult<LedgerPermit>;

    fn prepare_append(&self, permit: LedgerPermit, record: R) -> MResult<PreparedLedgerAppend<R>>;

    fn append(&mut self, prepared: PreparedLedgerAppend<R>) -> LedgerSequence;
}

pub(crate) fn reserve(
    controller: &CapacityController,
    estimate: RecordEstimate,
) -> MResult<LedgerPermit> {
    let reservation = controller.reserve(estimate)?;
    Ok(LedgerPermit::new(controller.clone(), reservation))
}

pub(crate) fn prepare<R: AccountedRecord>(
    controller: &CapacityController,
    permit: LedgerPermit,
    record: R,
) -> MResult<PreparedLedgerAppend<R>> {
    record.validate_for_recording()?;
    let actual_bytes = record.retained_bytes();
    let (prepared_controller, reservation) =
        prepare_reservation(controller, permit, 1, actual_bytes)?;
    Ok(PreparedLedgerAppend {
        controller: prepared_controller,
        reservation: Some(reservation),
        record: Some(record),
    })
}

pub(crate) fn prepare_reservation(
    controller: &CapacityController,
    mut permit: LedgerPermit,
    actual_records: usize,
    actual_bytes: usize,
) -> MResult<(CapacityController, CapacityReservation)> {
    let reservation = permit
        .reservation
        .take()
        .ok_or_else(|| capacity::invalid_permit("permit reservation has already been consumed"))?;
    let bound = controller.bind(
        &permit.controller,
        permit.ledger_identity,
        permit.ledger_generation,
        permit.consumed,
        reservation,
        actual_records,
        actual_bytes,
    );
    let reservation = match bound {
        Ok(reservation) => reservation,
        Err(error) => {
            permit.controller.release_reserved(reservation);
            return Err(error);
        }
    };
    permit.consumed = true;
    Ok((controller.clone(), reservation))
}
