//! Runtime transaction abort and rollback protocol.

use crate::runtime::MechRuntime;
use crate::runtime::state::ScopedRuntimeState;
use crate::{
    ActiveRuntimeEffectPhase, RuntimeContext, RuntimeEffectId, RuntimeEventKind,
    RuntimeTransactionNotFoundError, TransactionId,
};
use mech_core::{MResult, MechError};
use std::collections::HashSet;

impl MechRuntime {
    pub fn abort_runtime_transaction(
        &mut self,
        context: &mut RuntimeContext,
        reason: impl Into<String>,
    ) -> MResult<()> {
        self.reject_effect_reentrancy("abort_runtime_transaction")?;
        self.abort_runtime_transaction_internal(context, reason.into(), Vec::new())
    }

    pub(in crate::runtime) fn abort_runtime_transaction_with_recovered_events(
        &mut self,
        context: &mut RuntimeContext,
        reason: impl Into<String>,
        recovered_events: Vec<RuntimeEventKind>,
    ) -> MResult<()> {
        self.reject_effect_reentrancy("abort_runtime_transaction")?;
        self.abort_runtime_transaction_internal(context, reason.into(), recovered_events)
    }

    pub(in crate::runtime) fn abort_runtime_transaction_internal(
        &mut self,
        context: &mut RuntimeContext,
        reason: String,
        recovered_events: Vec<RuntimeEventKind>,
    ) -> MResult<()> {
        let (transaction_id, rollback_failures) = self
            .abort_runtime_transaction_cleanup_with_recovered_events(
                context,
                &reason,
                recovered_events,
            )?;

        if rollback_failures.is_empty() {
            return Ok(());
        }

        Err(self.poison_runtime_operation(
            "abort_runtime_transaction",
            Some(transaction_id),
            reason,
            rollback_failures,
        ))
    }

    pub(in crate::runtime) fn abort_runtime_transaction_cleanup(
        &mut self,
        context: &mut RuntimeContext,
        reason: &str,
    ) -> MResult<(TransactionId, Vec<String>)> {
        self.abort_runtime_transaction_cleanup_with_recovered_events(context, reason, Vec::new())
    }

    fn abort_runtime_transaction_cleanup_with_recovered_events(
        &mut self,
        context: &mut RuntimeContext,
        reason: &str,
        recovered_events: Vec<RuntimeEventKind>,
    ) -> MResult<(TransactionId, Vec<String>)> {
        self.validate_context_for_runtime(context)?;

        let transaction_id = Self::context_transaction_id(context)?;
        let mut rollback_failures = Vec::new();
        let mut envelope = self
            .active_transactions
            .remove(&transaction_id)
            .ok_or_else(|| {
                MechError::new(RuntimeTransactionNotFoundError { transaction_id }, None)
            })?;

        if let Err(error) = envelope
            .context_baseline
            .restore_preserving_consumption(context)
        {
            rollback_failures.push(format!("context baseline restore failed: {:?}", error));
        }
        if let Err(error) = self.validate_context_for_runtime(context) {
            rollback_failures.push(format!(
                "context baseline restore invariant failed: {:?}",
                error,
            ));
        }

        let abortable_effects = envelope.effects.abortable_ids();
        let phase_guard = ScopedRuntimeState::enter(
            &self.active_effect_phase,
            ActiveRuntimeEffectPhase::Aborting,
        );
        let effect_abort_failures = envelope.effects.abort_all();
        drop(phase_guard);
        let failed_effect_aborts: HashSet<RuntimeEffectId> = effect_abort_failures
            .iter()
            .map(|failure| failure.effect_id)
            .collect();
        rollback_failures.extend(Self::describe_effect_failures(effect_abort_failures));

        if let Err(error) = envelope.store.abort(reason) {
            rollback_failures.push(format!(
                "staged store discard invariant failed: {:?}",
                error,
            ));
        }

        for event in recovered_events {
            if let Err(error) = self.emit_event_immediate_to_context(context, event) {
                rollback_failures.push(format!(
                    "recovered transaction event publication failed: {:?}",
                    error,
                ));
            }
        }

        for effect_id in abortable_effects {
            if failed_effect_aborts.contains(&effect_id) {
                continue;
            }
            if let Err(error) = self.emit_event_immediate_to_context(
                context,
                RuntimeEventKind::EffectAborted { effect_id },
            ) {
                rollback_failures.push(format!(
                    "effect-aborted event publication failed for effect {effect_id}: {:?}",
                    error,
                ));
            }
        }

        if let Err(error) = self.emit_event_immediate_to_context(
            context,
            RuntimeEventKind::TransactionAborted {
                transaction_id,
                message: reason.to_string(),
            },
        ) {
            rollback_failures.push(format!(
        "transaction-aborted event publication failed for transaction {transaction_id}: {:?}",
        error,
            ));
        }

        if let Err(error) = context.finish_event_transaction_scope() {
            rollback_failures.push(format!(
                "context event compaction after abort failed: {:?}",
                error,
            ));
        }

        Ok((transaction_id, rollback_failures))
    }

    #[cfg(feature = "source")]
    pub(in crate::runtime) fn validate_transaction_cleanup_complete(
        &self,
        context: &RuntimeContext,
        transaction_id: TransactionId,
    ) -> Vec<String> {
        let mut failures = Vec::new();

        if self.active_transactions.contains_key(&transaction_id) {
            failures.push(format!(
                "active transaction envelope {} still exists after cleanup",
                transaction_id,
            ));
        }
        if context.transaction == Some(transaction_id) {
            failures.push(format!(
                "runtime context still references transaction {} after cleanup",
                transaction_id,
            ));
        }
        failures
    }

    #[cfg(feature = "source")]
    pub(in crate::runtime) fn finish_transaction_cleanup_best_effort(
        &mut self,
        context: &mut RuntimeContext,
        transaction_id: TransactionId,
        reason: &str,
    ) -> Vec<String> {
        let mut failures = Vec::new();

        if let Some(mut transaction) = self.active_transactions.remove(&transaction_id) {
            let phase_guard = ScopedRuntimeState::enter(
                &self.active_effect_phase,
                ActiveRuntimeEffectPhase::Aborting,
            );
            let effect_abort_failures = transaction.effects.abort_all();
            drop(phase_guard);
            failures.extend(Self::describe_effect_failures(effect_abort_failures));
            if let Err(error) = transaction.store.abort(reason) {
                failures.push(format!(
                    "best-effort staged store discard failed: {:?}",
                    error,
                ));
            }
        }
        if context.transaction == Some(transaction_id) {
            context.transaction = None;
        }
        if context.transaction.is_none() {
            if let Err(error) = context.finish_event_transaction_scope() {
                failures.push(format!(
                    "best-effort context event compaction failed: {:?}",
                    error,
                ));
            }
        }
        failures
    }

    #[cfg(feature = "source")]
    pub(in crate::runtime) fn cleanup_failed_implicit_operation(
        &mut self,
        context: &mut RuntimeContext,
        operation: &'static str,
        transaction_id: TransactionId,
        reason: &str,
    ) -> Vec<String> {
        let mut failures = Vec::new();

        match self.abort_runtime_transaction_cleanup(context, reason) {
            Ok((cleaned_transaction_id, cleanup_failures)) => {
                failures.extend(cleanup_failures);
                if cleaned_transaction_id != transaction_id {
                    failures.push(format!(
                        "implicit cleanup targeted transaction {}, expected {}",
                        cleaned_transaction_id, transaction_id,
                    ));
                }
            }
            Err(error) => failures.push(format!(
                "implicit transaction cleanup for `{}` transaction {} could not start: {:?}",
                operation, transaction_id, error,
            )),
        }

        let invariant_failures =
            self.validate_transaction_cleanup_complete(context, transaction_id);
        if !invariant_failures.is_empty() {
            failures.extend(invariant_failures);
            failures.extend(self.finish_transaction_cleanup_best_effort(
                context,
                transaction_id,
                reason,
            ));
            failures.extend(
                self.validate_transaction_cleanup_complete(context, transaction_id)
                    .into_iter()
                    .map(|failure| {
                        format!(
                            "implicit cleanup invariant remained unsatisfied: {}",
                            failure,
                        )
                    }),
            );
        }

        failures
    }
}
