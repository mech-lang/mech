//! Current canonical caller holdings. Future retained-map owners must add their
//! private table/owner-lane nodes; a view never grants execution authority.
use crate::native_artifact::NativeExecutionPhase;
use crate::native_artifact::program::protocol::abi::Frame;
use crate::native_artifact::program::runtime::invocation::Invocation;
use crate::native_artifact::program::runtime::maps::string::PublicationGeometry;
use crate::native_artifact::program::runtime::{NativeProgramExecutionError as Error, invalid};

fn add(a: u64, b: u64) -> Result<u64, Error> {
    a.checked_add(b)
        .ok_or_else(|| invalid("native caller node geometry overflows"))
}

// Preserve the existing 64-bit ABI caller envelope. Grouping persistent state
// made its combined layout smaller; repricing is a separate resource change.
const CHARGED_INVOCATION_BYTES: u64 = 2432;

pub(in crate::native_artifact::program::runtime) fn fixed_nodes() -> Result<u64, Error> {
    CHARGED_INVOCATION_BYTES
        .checked_add(core::mem::size_of::<Frame>() as u64)
        .and_then(|n| n.checked_add(128))
        .ok_or_else(|| invalid("native caller fixed geometry overflows"))
}

impl Invocation<'_, '_, '_> {
    /// These private loans have no ordinary canonical-owner census yet.
    /// Every selecting consumer retains its own check order and fallback.
    pub(super) fn has_uninventoried_private_owners(&self) -> bool {
        self.histogram.is_some()
            || self.line_window.is_some()
            || self.window_region.is_some()
            || self.window_hashes.is_some()
            || self.closed_tail.is_some()
            || self.prefix.as_ref().is_some_and(|prefix| !prefix.input.eof)
    }
    pub(in crate::native_artifact::program::runtime) fn retained_caller_dynamic_nodes(
        &self,
        site: usize,
    ) -> Result<u64, Error> {
        add(
            self.state.library.memory_budget().retained_snapshot_nodes(),
            self.state
                .call_caches
                .caller_retained_nodes(&self.state.library)
                .map_err(|error| Error::Library {
                    origin: self.descriptor.metadata().plan.blocks()[site].origin(),
                    error,
                })?,
        )
    }

    pub(in crate::native_artifact::program::runtime) fn retained_caller_geometry(
        &mut self,
        site: usize,
    ) -> Result<Option<PublicationGeometry>, Error> {
        self.check_caller_geometry_visit(site)?;
        self.retained_caller_inventory(site)
    }

    fn check_caller_geometry_visit(&self, site: usize) -> Result<(), Error> {
        let current = u32::try_from(site).map_err(|_| invalid("caller geometry site overflows"))?;
        if self.state.control.previous != Some(current)
            || self.state.control.completed
            || self.state.consumed
        {
            return Err(invalid("caller geometry outside fresh current visit"));
        }
        Ok(())
    }

    pub(in crate::native_artifact::program::runtime) fn retained_caller_fixed_geometry(
        &mut self,
        site: usize,
    ) -> Result<Option<u64>, Error> {
        self.check_caller_geometry_visit(site)?;
        self.retained_caller_fixed_inventory()
    }

    /// Inventory only; no visit or storage permission. The closed map entry
    /// uses this after its initializer was consumed, under that owner's proof.
    pub(in crate::native_artifact::program::runtime) fn retained_caller_inventory(
        &mut self,
        site: usize,
    ) -> Result<Option<PublicationGeometry>, Error> {
        let Some(fixed) = self.retained_caller_fixed_inventory()? else {
            return Ok(None);
        };
        let nodes = add(fixed, self.retained_caller_dynamic_nodes(site)?)?;
        Ok(Some(PublicationGeometry {
            live_bytes: self.state.library.memory_budget().used_bytes(),
            live_nodes: nodes,
        }))
    }

    /// Only this invocation's private holdings. Shared snapshot counts can
    /// change when another worker publishes or retires a value, so a stable
    /// local census must never be obtained by subtracting two shared samples.
    pub(in crate::native_artifact::program::runtime) fn retained_caller_fixed_inventory(
        &mut self,
    ) -> Result<Option<u64>, Error> {
        // A source/window loan needs its own live-owner witness. Decline this
        // view instead of treating borrowed producer storage as empty. Ordinary
        // canonical execution remains available to the future selecting caller.
        if self.has_uninventoried_private_owners() {
            return Ok(None);
        }
        let memory = self.state.library.memory_budget();
        self.state.control.work.check_memory_budget(&memory)?;
        self.state
            .control
            .work
            .charge(NativeExecutionPhase::Setup, 512)?;
        // Fixed invocation/frame/transport roots. This bound excludes variable
        // payload backing, so a long String is never priced as one node/byte.
        let mut nodes = fixed_nodes()?;
        nodes = add(nodes, self.state.buffer_frames.retained_nodes())?;
        nodes = add(
            nodes,
            self.state
                .map_owners
                .matrix_key_retained_nodes(&mut self.state.control.work)?,
        )?;
        if let Some(collections) = &self.state.collections {
            nodes = add(
                nodes,
                collections.caller_retained_nodes(&mut self.state.control.work)?,
            )?;
        }
        nodes = add(nodes, self.line_matrix_coexistence(None)?.retained_nodes)?;
        if self.borrowed_strings.is_some() {
            // Two flat metadata backings; genuine canonical pins are already
            // counted by the shared-account snapshot witness.
            nodes = add(nodes, 2)?;
        }
        if let Some(selected) = &self.selected_join {
            nodes = add(nodes, selected.caller_retained_nodes()?)?;
        }
        Ok(Some(nodes))
    }
}

#[cfg(all(test, feature = "canonical-native-program"))]
mod tests;
