//! Facts about the current selected key, never about benchmark queries. A new
//! selection or header invalidates predicates; a successful insertion changes
//! absence to presence. Joins keep only facts valid on every incoming path.
use crate::native_artifact::program::codegen::packed_loop::*;
use crate::native_artifact::program::codegen::packed_map::LookupFact as Fact;
use crate::native_artifact::program::codegen::tag_threading::{Edge, Graph, Target};
use mech_engine::native_artifact::NativeScalarOp as Op;
use std::collections::VecDeque;

const MAX_NODES: usize = 1024;
const MAX_PREDICATES: usize = 128;

#[derive(Clone, Debug)]
enum Expr {
    Unknown,
    Copy(usize),
    Not(usize),
    Equal(usize, u32),
}
impl Expr {
    fn predicate(&self, aliases: &BTreeMap<usize, bool>) -> Option<bool> {
        match *self {
            Self::Unknown => None,
            Self::Copy(word) => aliases.get(&word).copied(),
            Self::Not(word) => aliases.get(&word).map(|v| !v),
            Self::Equal(word, ordinal @ (0 | 1)) => {
                aliases.get(&word).map(|v| *v == (ordinal == 1))
            }
            Self::Equal(_, _) => None,
        }
    }
}
#[derive(Clone, Debug)]
enum Effect {
    Reset,
    Select,
    Contains(usize),
    Get(usize),
    Insert,
    Words(Vec<(usize, Expr)>),
}
#[derive(Clone, Debug)]
struct Step {
    effect: Effect,
    edge: Edge,
    condition: Expr,
}
#[derive(Clone, Debug, PartialEq, Eq)]
struct State {
    lookup: Fact,
    // true: this boolean equals current-key presence; false: its inverse.
    aliases: BTreeMap<usize, bool>,
}
impl Default for State {
    fn default() -> Self {
        Self {
            lookup: Fact::Unknown,
            aliases: BTreeMap::new(),
        }
    }
}
impl State {
    fn apply(&mut self, effect: &Effect) -> Option<()> {
        match effect {
            Effect::Reset | Effect::Select => {
                self.lookup = if matches!(effect, Effect::Reset) {
                    Fact::Unknown
                } else {
                    Fact::Fresh
                };
                self.aliases.clear();
            }
            Effect::Contains(output) => {
                if matches!(self.lookup, Fact::Unknown | Fact::Fresh) {
                    self.lookup = Fact::Cached;
                }
                self.aliases.insert(*output, true);
            }
            Effect::Get(output) => {
                // Only the successful original get can reach its successor.
                self.lookup = Fact::Present;
                self.aliases.remove(output);
            }
            Effect::Insert => {
                // The private helper refreshes the pointer even after growth.
                // Old predicates describe the pre-insert map, so discard them.
                self.lookup = Fact::Present;
                self.aliases.clear();
            }
            Effect::Words(writes) => {
                // Aggregate copies read all old words before writing any new one.
                let values = writes
                    .iter()
                    .map(|(word, expr)| (*word, expr.predicate(&self.aliases)))
                    .collect::<Vec<_>>();
                for (word, predicate) in values {
                    self.aliases.remove(&word);
                    if let Some(predicate) = predicate {
                        self.aliases.insert(word, predicate);
                    }
                }
            }
        }
        (self.aliases.len() <= MAX_PREDICATES).then_some(())
    }
    fn refine(&mut self, present: bool) -> bool {
        match (self.lookup, present) {
            (Fact::Present, false) | (Fact::Absent, true) => false,
            (Fact::Cached | Fact::Present | Fact::Absent, _) => {
                self.lookup = if present { Fact::Present } else { Fact::Absent };
                true
            }
            // No predicate may manufacture a cached entry after invalidation.
            _ => true,
        }
    }
    fn intersect(&mut self, other: &Self) {
        self.lookup = match (self.lookup, other.lookup) {
            (a, b) if a == b => a,
            (
                Fact::Cached | Fact::Present | Fact::Absent,
                Fact::Cached | Fact::Present | Fact::Absent,
            ) => Fact::Cached,
            _ => Fact::Unknown,
        };
        self.aliases
            .retain(|word, polarity| other.aliases.get(word) == Some(polarity));
        if matches!(self.lookup, Fact::Unknown | Fact::Fresh) {
            self.aliases.clear();
        }
    }
}

fn solve(steps: &[Step]) -> Option<Vec<Fact>> {
    if steps.is_empty() || steps.len() > MAX_NODES {
        return None;
    }
    let targets = |edge: &Edge| -> Vec<Target> {
        match edge {
            Edge::Jump(next) => vec![*next],
            Edge::Branch { yes, no } => vec![*yes, *no],
            Edge::Dispatch { cases, other } => cases
                .iter()
                .map(|(_, target)| *target)
                .chain([*other])
                .collect(),
            Edge::Reject => Vec::new(),
        }
    };
    for step in steps {
        if targets(&step.edge)
            .iter()
            .any(|t| matches!(t, Target::Node(n) if *n >= steps.len()))
        {
            return None;
        }
    }
    let mut incoming = vec![None; steps.len()];
    incoming[0] = Some(State::default());
    let mut pending = VecDeque::from([0]);
    let mut queued = vec![false; steps.len()];
    queued[0] = true;
    let mut visits = 0usize;
    while let Some(node) = pending.pop_front() {
        queued[node] = false;
        visits += 1;
        if visits > MAX_NODES * (MAX_PREDICATES + 4) {
            return None;
        }
        let step = &steps[node];
        let mut after = incoming[node].clone()?;
        after.apply(&step.effect)?;
        let predicate = step.condition.predicate(&after.aliases);
        for (edge_index, next) in targets(&step.edge).into_iter().enumerate() {
            let Target::Node(next) = next else {
                continue;
            };
            let mut state = after.clone();
            if matches!(step.edge, Edge::Branch { .. }) {
                if let Some(polarity) = predicate {
                    if !state.refine(polarity == (edge_index == 0)) {
                        continue;
                    }
                }
            }
            let changed = if let Some(old) = &mut incoming[next] {
                let before = old.clone();
                old.intersect(&state);
                *old != before
            } else {
                incoming[next] = Some(state);
                true
            };
            if changed && !queued[next] {
                pending.push_back(next);
                queued[next] = true;
            }
        }
    }
    Some(
        incoming
            .into_iter()
            .map(|state| state.map_or(Fact::Unknown, |s| s.lookup))
            .collect(),
    )
}

fn aggregate_effect(layout: &NativeScalarAggregates, action: &Aggregate) -> Option<Effect> {
    let copy = |value, index| field(layout, value, index).map(Expr::Copy);
    let (output, values) = match action {
        Aggregate::Pack { output, words } => (
            *output,
            words
                .iter()
                .map(|word| {
                    Some(match word {
                        Word::Scalar(value) => Expr::Copy(value.get() as usize),
                        Word::Field(value, index) => copy(*value, *index)?,
                        Word::Constant(_) => Expr::Unknown,
                    })
                })
                .collect::<Option<Vec<_>>>()?,
        ),
        Aggregate::Copy { source, output } => (
            *output,
            (0..layout.slot(*output)?.1)
                .map(|i| copy(*source, i))
                .collect::<Option<Vec<_>>>()?,
        ),
        Aggregate::Project {
            source,
            offset,
            output,
            ..
        } => (
            *output,
            (0..layout.slot(*output)?.1)
                .map(|i| copy(*source, offset.checked_add(i)?))
                .collect::<Option<Vec<_>>>()?,
        ),
        Aggregate::Observe {
            source,
            offset,
            ordinal,
            output,
            ..
        } => {
            let word = field(layout, *source, *offset)?;
            let expr = ordinal.map_or(Expr::Copy(word), |ordinal| Expr::Equal(word, ordinal));
            return Some(Effect::Words(vec![(output.get() as usize, expr)]));
        }
    };
    let (base, count) = layout.slot(output)?;
    if values.len() != count {
        return None;
    }
    Some(Effect::Words(
        values
            .into_iter()
            .enumerate()
            .map(|(i, expr)| (base + i, expr))
            .collect(),
    ))
}

pub(in crate::native_artifact::program::codegen::packed_loop) fn derive(
    code: CodePlan<'_>,
    closed: &Layout,
    id: usize,
    owner: &NativeMapOwnerWords,
    aggregates: &NativeScalarAggregates,
    graph: &Graph,
) -> Option<Vec<Fact>> {
    let region = &closed.regions[id];
    region.packed.as_ref()?;
    let owner_index = region.map?;
    let mut constants = BTreeMap::new();
    for i in 0..code.constant_count() {
        let (value, word) = code.constant(i).ok()?;
        if let Some(word) = word {
            constants.insert(value.get() as usize, word);
        }
    }
    let mut steps = Vec::new();
    for node in &graph.nodes {
        let site = node.site;
        if closed.sites.get(site) != Some(&Some(id)) {
            return None;
        }
        let block = &code.blocks()[site];
        let effect = if site == region.tail.header() as usize {
            if !matches!(block.action(), Action::Scalar(Scalar::None)) {
                return None;
            }
            // Refill can clear the cache, including on a terminal traversal.
            Effect::Reset
        } else if let Some((layout, action)) = aggregate_at(owner, aggregates, owner_index, site) {
            aggregate_effect(layout, action)?
        } else if let Some(span) = owner.span_site(site).map(|i| &owner.spans()[i]) {
            if span.region() != owner_index {
                return None;
            }
            if span.range_site() as usize == site {
                Effect::Select
            } else {
                Effect::Words(Vec::new())
            }
        } else if owner.call_region(site) == Some(owner_index) {
            let Action::LibraryCall {
                template, output, ..
            } = block.action()
            else {
                return None;
            };
            match template.primitive() {
                P::MapContainsKey => Effect::Contains(output.get() as usize),
                P::MapKeyAccess => Effect::Get(output.get() as usize),
                P::MapInsert => Effect::Insert,
                _ => return None,
            }
        } else {
            match block.action() {
                Action::Scalar(Scalar::None) => Effect::Words(Vec::new()),
                Action::Scalar(Scalar::Copy { source, output }) => Effect::Words(vec![(
                    output.get() as usize,
                    Expr::Copy(source.get() as usize),
                )]),
                Action::Scalar(Scalar::Primitive {
                    op,
                    operands,
                    output,
                    ..
                }) => {
                    let expr = if *op == Op::BoolNot && operands.len() == 1 {
                        Expr::Not(operands[0].get() as usize)
                    } else {
                        Expr::Unknown
                    };
                    Effect::Words(vec![(output.get() as usize, expr)])
                }
                _ => return None,
            }
        };
        let condition = match block.terminator() {
            Term::Scalar(Branch::Branch { condition, .. }) => Expr::Copy(condition.get() as usize),
            Term::Scalar(Branch::LiteralBranch { left, right, .. })
                if code.kind(left)? != NativeScalarKind::F64 =>
            {
                if let Some(word @ (0 | 1)) = constants.get(&(right.get() as usize)) {
                    Expr::Equal(left.get() as usize, *word as u32)
                } else if let Some(word @ (0 | 1)) = constants.get(&(left.get() as usize)) {
                    Expr::Equal(right.get() as usize, *word as u32)
                } else {
                    Expr::Unknown
                }
            }
            _ => Expr::Unknown,
        };
        steps.push(Step {
            effect,
            condition,
            edge: node.edge.clone(),
        });
    }
    solve(&steps)
}

#[cfg(test)]
mod tests;
