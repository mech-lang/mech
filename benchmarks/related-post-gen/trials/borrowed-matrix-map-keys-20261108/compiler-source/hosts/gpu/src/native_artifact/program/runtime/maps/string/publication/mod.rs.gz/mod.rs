//! Immutable canonical output at an owner boundary. No source traversal,
//! accumulation or execution authority is implemented by this storage bridge.
use crate::native_artifact::program::runtime::maps::string::*;
use mech_core::snapshot::{
    MapEntryDraft, SnapshotCanonicalizationBudget, SnapshotValidationContext, ValueDataDraft,
    ValueDraft,
};
use mech_core::{
    CardinalitySpec, DimensionExpr, IntegerWidth, MemoryBudgetLimits, ResidentKernelError,
    SchemaBody, SchemaId, SchemaTable, Value, ValueData,
};
use std::sync::Arc;

mod result;
use result::ResultLayout;

/// Complete simultaneous caller geometry, INCLUDING this retained table and
/// any prior output. A future native caller must derive this from its live
/// frame/owners; these descriptive numbers confer no publication authority.
#[derive(Clone, Copy)]
pub(in crate::native_artifact) struct Geometry {
    pub live_bytes: u64,
    pub live_nodes: u64,
}
struct Plan {
    workspace: u64,
    finalization: u64,
    compute: u64,
    staging_nodes: u64,
}
fn exact_vec<T>(count: usize) -> Result<Vec<T>, Error> {
    let mut values = Vec::new();
    values
        .try_reserve_exact(count)
        .map_err(|_| Error::Allocation)?;
    if values.capacity() != count {
        return Err(Error::Allocation);
    }
    Ok(values)
}
fn required(limit: Option<u64>) -> Result<u64, Error> {
    limit.ok_or(Error::Publication("unbounded call dimension"))
}

pub(in crate::native_artifact) fn string_u64_schema(
    schemas: &SchemaTable,
    schema: SchemaId,
    count: u64,
) -> Result<(), Error> {
    let target = schemas
        .get(schema)
        .ok_or(Error::Publication("missing schema"))?;
    if !target.dimension_parameters().is_empty() {
        return Err(Error::Publication("parameterized output schema"));
    }
    string_u64_body(target.body(), count)
}

fn string_u64_body(body: &SchemaBody, count: u64) -> Result<(), Error> {
    let SchemaBody::Map {
        key,
        value,
        cardinality,
    } = body
    else {
        return Err(Error::Publication("output is not a map"));
    };
    if key.as_ref() != &SchemaBody::String
        || value.as_ref() != &SchemaBody::UnsignedInteger(IntegerWidth::W64)
    {
        return Err(Error::Publication("output key/value kind"));
    }
    match cardinality {
        CardinalitySpec::Exact(DimensionExpr::Constant(n)) if *n == count => Ok(()),
        CardinalitySpec::Dynamic { upper_bound: None } => Ok(()),
        CardinalitySpec::Dynamic {
            upper_bound: Some(DimensionExpr::Constant(n)),
        } if count <= *n => Ok(()),
        _ => Err(Error::Publication("output cardinality")),
    }
}

/// Logical canonical output size, independent of a private retained storage
/// choice. Private read-only maps must keep these same declared output caps.
pub(in crate::native_artifact) fn logical_map_bytes(
    count: u64,
    payload: u64,
) -> Result<u64, Error> {
    add(
        add(size_of::<Value>() as u64, size_of::<ValueData>() as u64)?,
        add(
            mul(
                count,
                (size_of::<mech_core::snapshot::MapEntryValue>() + 2 * size_of::<ValueData>())
                    as u64,
            )?,
            payload,
        )?,
    )
}
pub(in crate::native_artifact) fn logical_map_limits(
    published: u64,
    limits: MemoryBudgetLimits,
) -> Result<(), Error> {
    check(1, required(limits.max_output_elements)?, "output elements")?;
    check(
        published,
        required(limits.max_output_bytes)?,
        "output bytes",
    )?;
    check(
        published,
        required(limits.max_cloned_bytes)?,
        "cloned bytes",
    )
}
impl<S: BuildHasher> OwnedStringMap<S> {
    #[cfg(test)]
    fn publication_plan(
        &self,
        schemas: &Arc<SchemaTable>,
        schema: SchemaId,
        geometry: Geometry,
        limits: MemoryBudgetLimits,
    ) -> Result<Plan, Error> {
        let result = ResultLayout::new(schemas, schema, &[])?;
        self.publication_plan_result(schemas, geometry, limits, &result)
    }

    fn publication_plan_result(
        &self,
        schemas: &Arc<SchemaTable>,
        geometry: Geometry,
        limits: MemoryBudgetLimits,
        result: &ResultLayout<'_>,
    ) -> Result<Plan, Error> {
        for limit in [
            limits.max_output_elements,
            limits.max_output_bytes,
            limits.max_temporary_bytes,
            limits.max_cloned_bytes,
            limits.max_retained_nodes,
            limits.max_compute_work,
            limits.max_comparison_work,
        ] {
            required(limit)?;
        }
        let retained = self.retained_bytes()?;
        let count = self.len() as u64;
        if geometry.live_bytes < retained || geometry.live_nodes < add(count, 1)? {
            return Err(Error::Publication("caller geometry omits retained owner"));
        }
        self.work.charge(128, 0)?;
        result.validate_map(count)?;
        // Sharing the schema arena still imports its complete ownership.
        let schema_bytes = schemas
            .clone_allocation_bound_bytes_with_precharge(|bytes| self.work.charge(bytes, 0))
            .map_err(|error| match error {
                mech_core::SchemaAllocationBoundError::Precharge(error) => Error::Work(error),
                mech_core::SchemaAllocationBoundError::ArithmeticOverflow => Error::Overflow,
            })?;
        let payload = self.keys.capacity_bytes();
        // Exact narrow canonical layout, matching Value::retained_footprint:
        // Value + root ValueData + MapEntryValue + two child ValueDatas/key.
        let published = add(
            logical_map_bytes(count, payload)?,
            result.extra_value_bytes()?,
        )?;
        let nodes = add(add(mul(count, 2)?, 2)?, result.extra_nodes())?;
        let drafts = add(
            mul(
                count,
                (size_of::<MapEntryDraft>() + 2 * size_of::<ValueDataDraft>() + size_of::<String>())
                    as u64,
            )?,
            result.extra_draft_bytes()?,
        )?;
        let order = mul(count, size_of::<(&str, u64)>() as u64)?;
        let owner = mul(
            add(
                add(schema_bytes, Value::canonical_owner_allocation_bytes())?,
                Value::memory_budget_claim_metadata_bytes(),
            )?,
            4,
        )?;
        let workspace = add(
            add(owner, 4096)?,
            add(
                order,
                add(mul(drafts, 4)?, add(mul(published, 4)?, mul(payload, 4)?)?)?,
            )?,
        )?;
        logical_map_limits(published, limits)?;
        check(
            add(geometry.live_nodes, mul(nodes, 3)?)?,
            required(limits.max_retained_nodes)?,
            "retained nodes",
        )?;
        check(
            add(geometry.live_bytes, workspace)?,
            required(limits.max_temporary_bytes)?,
            "temporary bytes",
        )?;
        // Sorted drafts take the core finalizer's ordered append route. Each
        // adjacent String comparison is covered by three total payload scans.
        let result_finalization = result.extra_finalization()?;
        let finalization = add(
            add(add(mul(payload, 3)?, mul(count, 8)?)?, 8)?,
            result_finalization,
        )?;
        let compute = add(add(mul(workspace, 16)?, 256)?, mul(result_finalization, 8)?)?;
        Ok(Plan {
            workspace,
            finalization,
            compute,
            staging_nodes: mul(nodes, 2)?,
        })
    }

    /// Copy one complete current table into an independently owned immutable
    /// map. The table stays intact on success and every denial/failure. The
    /// caller must still prove the exact native site, owner and live geometry.
    #[cfg(test)]
    pub(in crate::native_artifact) fn publish(
        &self,
        schemas: &Arc<SchemaTable>,
        schema: SchemaId,
        geometry: crate::native_artifact::program::runtime::maps::string::PublicationGeometry,
        limits: MemoryBudgetLimits,
    ) -> Result<Value, Error> {
        self.publish_result(schemas, schema, &[], geometry, limits)
    }

    /// Publish the one retained Map and its fixed scalar companions together.
    /// The schema-directed recipe is bounded and no intermediate canonical Map
    /// is created or exposed before the complete result is admitted.
    pub(in crate::native_artifact) fn publish_result(
        &self,
        schemas: &Arc<SchemaTable>,
        schema: SchemaId,
        words: &[u64],
        geometry: Geometry,
        limits: MemoryBudgetLimits,
    ) -> Result<Value, Error> {
        let compute = required(limits.max_compute_work)?;
        let comparison = required(limits.max_comparison_work)?;
        self.work.with_call_limits(compute, comparison, || {
            let result = ResultLayout::new(schemas, schema, words)?;
            self.work.charge(mul(result.extra_nodes(), 64)?, 0)?;
            let plan = self.publication_plan_result(schemas, geometry, limits, &result)?;
            self.work.charge(plan.compute, plan.finalization)?;
            let memory = self.metadata.budget().with_limits(
                required(limits.max_temporary_bytes)?,
                required(limits.max_retained_nodes)?,
            );
            // The retained map, construction scratch and admitted canonical
            // output are distinct live owners. Scratch covers the unadmitted
            // draft/finalizer; import atomically adds the canonical witness.
            let _staging = memory.reserve_nodes(plan.staging_nodes)?;
            let mut reservation = memory.reserve_capacity(plan.workspace)?;
            let mut order = exact_vec(self.len())?;
            order.extend(self.entries()?);
            sort(&mut order, &self.work)?;
            let mut entries = exact_vec(order.len())?;
            for (key, value) in order {
                let mut text = String::new();
                text.try_reserve_exact(key.len())
                    .map_err(|_| Error::Allocation)?;
                if text.capacity() != key.len() {
                    return Err(Error::Allocation);
                }
                text.push_str(key);
                let mut items = exact_vec(2)?;
                items.push(ValueDataDraft::String(text));
                items.push(ValueDataDraft::U64(value));
                entries.push(MapEntryDraft {
                    items: items.into_boxed_slice(),
                });
            }
            let canonical = SnapshotCanonicalizationBudget::new(plan.finalization);
            let context = SnapshotValidationContext::with_shared_schemas(schemas)
                .with_canonicalization_budget(&canonical);
            let value = ValueDraft {
                schema,
                shape_values: Box::new([]),
                data: result.wrap(ValueDataDraft::Map(entries.into_boxed_slice()), words)?,
            }
            .finalize(&context)
            .map_err(|_| Error::Publication("canonical finalization"))?;
            value
                .into_memory_budget(&mut reservation)
                .map_err(Error::Memory)
        })?
    }
}

// Fallible, allocation-free heapsort of BORROWED entries. Every comparison is
// prepaid before inspecting key bytes. A denial only disturbs this workspace,
// never the retained table; no panic or fresh comparison allowance is used.
fn sort(values: &mut [(&str, u64)], work: &NativeLibraryWorkBudget) -> Result<(), Error> {
    // This leaf only compares borrowed bytes and swaps borrowed entries. No
    // allocation, host callback or budget observer runs while a batch is held.
    work.with_debit_batch(|batch| {
        sort_with_debits(values, &mut |compute, comparison| {
            batch.charge(compute, comparison)
        })
    })?
}

fn sort_with_debits(
    values: &mut [(&str, u64)],
    charge: &mut impl FnMut(u64, u64) -> Result<(), ResidentKernelError>,
) -> Result<(), Error> {
    fn less(
        a: &str,
        b: &str,
        charge: &mut impl FnMut(u64, u64) -> Result<(), ResidentKernelError>,
    ) -> Result<bool, Error> {
        let bytes = add(add(a.len() as u64, b.len() as u64)?, 1)?;
        charge(add(mul(bytes, 8)?, 32)?, bytes)?;
        Ok(a.as_bytes() < b.as_bytes())
    }
    fn sift(
        values: &mut [(&str, u64)],
        mut root: usize,
        charge: &mut impl FnMut(u64, u64) -> Result<(), ResidentKernelError>,
    ) -> Result<(), Error> {
        loop {
            charge(32, 0)?;
            let left = root
                .checked_mul(2)
                .and_then(|n| n.checked_add(1))
                .ok_or(Error::Overflow)?;
            if left >= values.len() {
                return Ok(());
            }
            let mut child = left;
            if left + 1 < values.len() && less(values[left].0, values[left + 1].0, charge)? {
                child += 1;
            }
            if !less(values[root].0, values[child].0, charge)? {
                return Ok(());
            }
            values.swap(root, child);
            root = child;
        }
    }
    for root in (0..values.len() / 2).rev() {
        sift(values, root, charge)?;
    }
    for end in (1..values.len()).rev() {
        charge(32, 0)?;
        values.swap(0, end);
        sift(&mut values[..end], 0, charge)?;
    }
    Ok(())
}

#[cfg(test)]
mod tests;
