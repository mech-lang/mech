#[cfg(feature = "source")]
use mech_core::CanonicalFunctionSpecializer;
use mech_core::{FunctionCatalogBuilder, MResult};
#[cfg(feature = "source")]
use mech_core::{FunctionExport, FunctionExposure};
#[cfg(feature = "source")]
use std::sync::Arc;

#[cfg(feature = "source")]
fn install_canonical_operation<T>(
    builder: &mut FunctionCatalogBuilder,
    canonical_name: &str,
    compiler: T,
) -> MResult<()>
where
    T: CanonicalFunctionSpecializer + 'static,
{
    let declaration = mech_core::maintained_source_type_declaration(canonical_name)?;
    let operation =
        builder.insert_canonical_specializer(canonical_name, declaration, Arc::new(compiler))?;
    builder.insert_export(FunctionExport {
        operation,
        canonical_name: canonical_name.to_string(),
        module: None,
        item: None,
        exposure: FunctionExposure::Prelude,
    })
}

#[cfg(feature = "source")]
pub fn install_source(builder: &mut FunctionCatalogBuilder) -> MResult<()> {
    #[cfg(feature = "and")]
    install_canonical_operation(builder, "logic/and", crate::LogicAnd {})?;
    #[cfg(feature = "not")]
    install_canonical_operation(builder, "logic/not", crate::LogicNot {})?;
    #[cfg(feature = "or")]
    install_canonical_operation(builder, "logic/or", crate::LogicOr {})?;
    #[cfg(feature = "xor")]
    install_canonical_operation(builder, "logic/xor", crate::LogicXor {})?;
    Ok(())
}

macro_rules! declare_logic_native_factory {
    (
        ($module:ident; $operation:ident; $operation_feature:literal),
        $_lib:ident, $suffix:ident, none,
        $_scalar:ty, $_scalar_name:literal, $_scalar_token:ident
    ) => {
        paste::paste! {
            mech_core::declare_native_runtime_factory! {
                cfg: all(feature = $operation_feature, feature = "bool"),
                registration: [<register_logic_ $operation:lower _ $suffix:lower>],
                installer: [<install_logic_ $operation:lower _ $suffix:lower>],
                name: concat!(stringify!($operation), stringify!($suffix), "<bool>"),
                factory_type: crate::$module::[<$operation $suffix>],
                contract: mech_core::__mech_elementwise_binop_contract!($suffix),
                operations: [mech_core::OperationId::from_name(concat!("logic/", $operation_feature))],
                package: "mech-logic",
                crate_name: "mech_logic",
                installer_path: concat!(
                    "mech_logic::__mech_native::install_logic_",
                    stringify!([<$operation:lower>]), "_", stringify!([<$suffix:lower>]),
                ),
                extra_cargo_features: [$operation_feature],
            }
        }
    };
    (
        ($module:ident; $operation:ident; $operation_feature:literal),
        $_lib:ident, $suffix:ident, $shape_feature:literal,
        $_scalar:ty, $_scalar_name:literal, $_scalar_token:ident
    ) => {
        paste::paste! {
            mech_core::declare_native_runtime_factory! {
                cfg: all(feature = $operation_feature, feature = "bool"),
                registration: [<register_logic_ $operation:lower _ $suffix:lower>],
                installer: [<install_logic_ $operation:lower _ $suffix:lower>],
                name: concat!(stringify!($operation), stringify!($suffix), "<bool>"),
                factory_type: crate::$module::[<$operation $suffix>],
                contract: mech_core::__mech_elementwise_binop_contract!($suffix),
                operations: [mech_core::OperationId::from_name(concat!("logic/", $operation_feature))],
                package: "mech-logic",
                crate_name: "mech_logic",
                installer_path: concat!(
                    "mech_logic::__mech_native::install_logic_",
                    stringify!([<$operation:lower>]), "_", stringify!([<$suffix:lower>]),
                ),
                extra_cargo_features: [$operation_feature],
            }
        }
    };
}

#[cfg(any(feature = "and", feature = "or", feature = "xor"))]
macro_rules! register_logic_native_factory {
    (
        ($builder:ident; $_module:ident; $operation:ident; $_operation_feature:literal),
        $_lib:ident, $suffix:ident, $_shape_feature:tt,
        $_scalar:ty, $_scalar_name:literal, $_scalar_token:ident
    ) => {
        paste::paste! { [<register_logic_ $operation:lower _ $suffix:lower>]($builder)?; }
    };
}

#[cfg(feature = "native-link")]
macro_rules! export_logic_native_factory {
    (
        ($_module:ident; $operation:ident; $operation_feature:literal),
        $_lib:ident, $suffix:ident, $_shape_feature:tt,
        $_scalar:ty, $_scalar_name:literal, $_scalar_token:ident
    ) => {
        #[cfg(all(feature = $operation_feature, feature = "bool"))]
        paste::paste! { pub use super::[<install_logic_ $operation:lower _ $suffix:lower>]; }
    };
}

macro_rules! declare_logic_binop_runtime {
    ($module:ident, $operation:ident, $operation_feature:literal) => {
        mech_core::__mech_for_each_binop_runtime_factory_for_type!(
            declare_logic_native_factory,
            ($module; $operation; $operation_feature),
            $operation,
            bool,
            "bool",
            bool
        );
    };
}

declare_logic_binop_runtime!(and, And, "and");
declare_logic_binop_runtime!(or, Or, "or");
declare_logic_binop_runtime!(xor, Xor, "xor");

#[cfg(feature = "not")]
macro_rules! for_each_logic_not_shape {
    ($callback:ident, $context:tt) => {
        #[cfg(feature = "matrix1")]
        $callback!($context, m1, "matrix1", nalgebra::Matrix1<bool>);
        #[cfg(feature = "matrix2")]
        $callback!($context, m2, "matrix2", nalgebra::Matrix2<bool>);
        #[cfg(feature = "matrix3")]
        $callback!($context, m3, "matrix3", nalgebra::Matrix3<bool>);
        #[cfg(feature = "matrix4")]
        $callback!($context, m4, "matrix4", nalgebra::Matrix4<bool>);
        #[cfg(feature = "matrix2x3")]
        $callback!($context, m2x3, "matrix2x3", nalgebra::Matrix2x3<bool>);
        #[cfg(feature = "matrix3x2")]
        $callback!($context, m3x2, "matrix3x2", nalgebra::Matrix3x2<bool>);
        #[cfg(feature = "matrixd")]
        $callback!($context, md, "matrixd", nalgebra::DMatrix<bool>);
        #[cfg(feature = "row_vector2")]
        $callback!($context, r2, "row_vector2", nalgebra::RowVector2<bool>);
        #[cfg(feature = "row_vector3")]
        $callback!($context, r3, "row_vector3", nalgebra::RowVector3<bool>);
        #[cfg(feature = "row_vector4")]
        $callback!($context, r4, "row_vector4", nalgebra::RowVector4<bool>);
        #[cfg(feature = "row_vectord")]
        $callback!($context, rd, "row_vectord", nalgebra::RowDVector<bool>);
        #[cfg(feature = "vector2")]
        $callback!($context, v2, "vector2", nalgebra::Vector2<bool>);
        #[cfg(feature = "vector3")]
        $callback!($context, v3, "vector3", nalgebra::Vector3<bool>);
        #[cfg(feature = "vector4")]
        $callback!($context, v4, "vector4", nalgebra::Vector4<bool>);
        #[cfg(feature = "vectord")]
        $callback!($context, vd, "vectord", nalgebra::DVector<bool>);
    };
}

#[cfg(feature = "not")]
macro_rules! declare_logic_not_factory {
    (scalar, $suffix:ident, $shape_feature:literal, $shape:ty) => {
        compile_error!("scalar logic/not uses its dedicated declaration");
    };
    (vector, $suffix:ident, $shape_feature:literal, $shape:ty) => {
        paste::paste! {
            mech_core::declare_native_runtime_factory! {
                cfg: all(feature = "not", feature = "bool", feature = $shape_feature),
                registration: [<register_logic_not_ $suffix>],
                installer: [<install_logic_not_ $suffix>],
                name: crate::not::not_vector_runtime_name::<$shape>(),
                factory_type: crate::not::NotV<bool, $shape>,
                contract: mech_core::RuntimeFunctionContract::output_matches_input(
                    0,
                    mech_core::RuntimeOutputAliasPolicy::DisallowInputAlias,
                ),
                operations: [mech_core::OperationId::from_name("logic/not")],
                package: "mech-logic",
                crate_name: "mech_logic",
                installer_path: concat!(
                    "mech_logic::__mech_native::install_logic_not_",
                    stringify!($suffix),
                ),
                extra_cargo_features: ["not"],
            }
        }
    };
}

mech_core::declare_native_runtime_factory! {
    cfg: all(feature = "not", feature = "bool"),
    registration: register_logic_not_s,
    installer: install_logic_not_s,
    name: "NotS<bool>",
    factory_type: crate::not::NotS<bool>,
    contract: mech_core::RuntimeFunctionContract::no_matrix(
        mech_core::RuntimeOutputAliasPolicy::DisallowInputAlias,
    ),
    operations: [mech_core::OperationId::from_name("logic/not")],
    package: "mech-logic",
    crate_name: "mech_logic",
    installer_path: "mech_logic::__mech_native::install_logic_not_s",
    extra_cargo_features: ["not"],
}

#[cfg(feature = "not")]
for_each_logic_not_shape!(declare_logic_not_factory, vector);

#[cfg(feature = "not")]
macro_rules! register_logic_not_factory {
    ($builder:ident, $suffix:ident, $_shape_feature:literal, $_shape:ty) => {
        paste::paste! { [<register_logic_not_ $suffix>]($builder)?; }
    };
}

#[cfg(all(feature = "native-link", feature = "not"))]
macro_rules! export_logic_not_factory {
    (export, $suffix:ident, $_shape_feature:literal, $_shape:ty) => {
        paste::paste! { pub use super::[<install_logic_not_ $suffix>]; }
    };
}

#[cfg(any(feature = "and", feature = "or", feature = "xor"))]
macro_rules! install_native_logic_binop_runtime {
    ($builder:ident, $module:ident, $operation:ident, $operation_feature:literal) => {
        mech_core::__mech_for_each_binop_runtime_factory_for_type!(
            register_logic_native_factory,
            ($builder; $module; $operation; $operation_feature),
            $operation,
            bool,
            "bool",
            bool
        );
    };
}

#[doc(hidden)]
#[cfg(feature = "native-link")]
pub mod __mech_native {
    macro_rules! export_logic_binop_runtime {
        ($module:ident, $operation:ident, $operation_feature:literal) => {
            mech_core::__mech_for_each_binop_runtime_factory_for_type!(
                export_logic_native_factory,
                ($module; $operation; $operation_feature),
                $operation,
                bool,
                "bool",
                bool
            );
        };
    }
    export_logic_binop_runtime!(and, And, "and");
    export_logic_binop_runtime!(or, Or, "or");
    export_logic_binop_runtime!(xor, Xor, "xor");
    #[cfg(all(feature = "not", feature = "bool"))]
    pub use super::install_logic_not_s;
    #[cfg(feature = "not")]
    for_each_logic_not_shape!(export_logic_not_factory, export);
}

/// Installs every enabled concrete bytecode factory owned by `mech-logic`.
pub fn install_runtime(builder: &mut FunctionCatalogBuilder) -> MResult<()> {
    #[cfg(feature = "and")]
    install_native_logic_binop_runtime!(builder, and, And, "and");
    #[cfg(feature = "or")]
    install_native_logic_binop_runtime!(builder, or, Or, "or");
    #[cfg(feature = "xor")]
    install_native_logic_binop_runtime!(builder, xor, Xor, "xor");
    #[cfg(all(feature = "not", feature = "bool"))]
    register_logic_not_s(builder)?;
    #[cfg(feature = "not")]
    for_each_logic_not_shape!(register_logic_not_factory, builder);
    Ok(())
}

#[cfg(all(test, feature = "source"))]
mod tests {
    use super::*;
    use mech_core::OperationId;

    fn expected_operations() -> Vec<&'static str> {
        let mut expected = Vec::new();
        #[cfg(feature = "and")]
        expected.push("logic/and");
        #[cfg(feature = "not")]
        expected.push("logic/not");
        #[cfg(feature = "or")]
        expected.push("logic/or");
        #[cfg(feature = "xor")]
        expected.push("logic/xor");
        expected
    }

    #[test]
    fn source_catalog_matches_the_frozen_logic_surface() {
        let mut runtime_builder = FunctionCatalogBuilder::new();
        install_runtime(&mut runtime_builder).unwrap();
        let runtime_count = runtime_builder.build().unwrap().runtime_factory_count();
        let mut builder = FunctionCatalogBuilder::new();
        install_runtime(&mut builder).unwrap();
        install_source(&mut builder).unwrap();
        let catalog = builder.build().unwrap();
        let expected = expected_operations();

        #[cfg(all(feature = "and", feature = "not", feature = "or", feature = "xor"))]
        assert_eq!(expected.len(), 4);
        assert_eq!(catalog.specializer_count(), expected.len());
        assert_eq!(catalog.runtime_factory_count(), runtime_count);
        for name in expected {
            let operation = OperationId::from_name(name);
            assert_eq!(
                catalog
                    .specializer(operation)
                    .unwrap()
                    .operation
                    .canonical_name
                    .as_ref(),
                name
            );
            assert_eq!(
                catalog.exports_for_operation(operation),
                &[FunctionExport {
                    operation,
                    canonical_name: name.to_string(),
                    module: None,
                    item: None,
                    exposure: FunctionExposure::Prelude,
                }],
            );
        }
    }
}
