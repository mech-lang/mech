#![cfg(feature = "dynamic-module")]

#[cfg(test)]
use mech_abi::{MechExportV1, MechKernelFnV1, MechKernelKindV1, MechStrV1};
use mech_abi::{MechF64ViewMutV1, MechF64ViewV1, MechStatusV1};

#[cfg(test)]
const MODULE_NAME: &[u8] = b"math";
#[cfg(test)]
const EXPORT_NAME: &[u8] = b"math/round";
#[cfg(test)]
const SQRT_EXPORT_NAME: &[u8] = b"math/sqrt";
#[cfg(test)]
const FLOOR_EXPORT_NAME: &[u8] = b"math/floor";
#[cfg(test)]
const CEIL_EXPORT_NAME: &[u8] = b"math/ceil";
#[cfg(test)]
const ATAN2_EXPORT_NAME: &[u8] = b"math/atan2";
#[cfg(test)]
const SIN_EXPORT_NAME: &[u8] = b"math/sin";
#[cfg(test)]
const COS_EXPORT_NAME: &[u8] = b"math/cos";
#[cfg(test)]
const TAN_EXPORT_NAME: &[u8] = b"math/tan";
#[cfg(test)]
const ASIN_EXPORT_NAME: &[u8] = b"math/asin";
#[cfg(test)]
const ACOS_EXPORT_NAME: &[u8] = b"math/acos";
#[cfg(test)]
const ATAN_EXPORT_NAME: &[u8] = b"math/atan";

macro_rules! define_unary_f64_dynamic_kernels {
    ($scalar_symbol:ident, $view_symbol:ident, $kernel_mod:ident) => {
        #[unsafe(no_mangle)]
        pub unsafe extern "C" fn $scalar_symbol(input: f64, out: *mut f64) -> MechStatusV1 {
            unsafe { call_unary_f64(input, out, crate::kernels::$kernel_mod::scalar_f64) }
        }

        #[unsafe(no_mangle)]
        pub unsafe extern "C" fn $view_symbol(
            input: MechF64ViewV1,
            out: MechF64ViewMutV1,
        ) -> MechStatusV1 {
            unsafe { call_unary_f64_view(input, out, crate::kernels::$kernel_mod::view_f64) }
        }
    };
}

macro_rules! define_binary_f64_dynamic_kernel {
    ($symbol:ident, $kernel_mod:ident) => {
        #[unsafe(no_mangle)]
        pub unsafe extern "C" fn $symbol(lhs: f64, rhs: f64, out: *mut f64) -> MechStatusV1 {
            unsafe { call_binary_f64(lhs, rhs, out, crate::kernels::$kernel_mod::scalar_f64) }
        }
    };
}

macro_rules! math_dynamic_module_v1 {
    (
        unary: [
            $(
                $unary_name:expr => ($unary_scalar:path, $unary_view:path)
            ),* $(,)?
        ],
        binary: [
            $(
                $binary_name:expr => $binary_scalar:path
            ),* $(,)?
        ],
    ) => {
        mech_abi::mech_dynamic_module_v1! {
            module: b"math",
            exports: [
                $(
                    unary_f64_to_f64 {
                        name: $unary_name,
                        function: $unary_scalar,
                    },
                    unary_f64_view_to_f64_view {
                        name: $unary_name,
                        function: $unary_view,
                    },
                )*
                $(
                    binary_f64_f64_to_f64 {
                        name: $binary_name,
                        function: $binary_scalar,
                    },
                )*
            ],
        }
    };
}

math_dynamic_module_v1! {
    unary: [
        b"math/round" => (math_round_f64_v1, math_round_f64_view_v1),
        b"math/sqrt" => (math_sqrt_f64_v1, math_sqrt_f64_view_v1),
        b"math/floor" => (math_floor_f64_v1, math_floor_f64_view_v1),
        b"math/ceil" => (math_ceil_f64_v1, math_ceil_f64_view_v1),
        b"math/sin" => (math_sin_f64_v1, math_sin_f64_view_v1),
        b"math/cos" => (math_cos_f64_v1, math_cos_f64_view_v1),
        b"math/tan" => (math_tan_f64_v1, math_tan_f64_view_v1),
        b"math/asin" => (math_asin_f64_v1, math_asin_f64_view_v1),
        b"math/acos" => (math_acos_f64_v1, math_acos_f64_view_v1),
        b"math/atan" => (math_atan_f64_v1, math_atan_f64_view_v1),
    ],
    binary: [
        b"math/atan2" => math_atan2_f64_v1,
    ],
}

unsafe fn call_unary_f64(input: f64, out: *mut f64, kernel: fn(f64) -> f64) -> MechStatusV1 {
    if out.is_null() {
        return MechStatusV1::NULL_POINTER;
    }

    unsafe {
        *out = kernel(input);
    }

    MechStatusV1::OK
}

unsafe fn call_binary_f64(
    lhs: f64,
    rhs: f64,
    out: *mut f64,
    kernel: fn(f64, f64) -> f64,
) -> MechStatusV1 {
    if out.is_null() {
        return MechStatusV1::NULL_POINTER;
    }

    unsafe {
        *out = kernel(lhs, rhs);
    }

    MechStatusV1::OK
}

unsafe fn call_unary_f64_view(
    input: MechF64ViewV1,
    out: MechF64ViewMutV1,
    kernel: fn(&[f64], &mut [f64]),
) -> MechStatusV1 {
    if input.len != out.len {
        return MechStatusV1::WRONG_SHAPE;
    }

    if input.rows != out.rows || input.cols != out.cols {
        return MechStatusV1::WRONG_SHAPE;
    }

    let Some(input_cells) = input.rows.checked_mul(input.cols) else {
        return MechStatusV1::WRONG_SHAPE;
    };

    let Some(out_cells) = out.rows.checked_mul(out.cols) else {
        return MechStatusV1::WRONG_SHAPE;
    };

    if input.len != input_cells || out.len != out_cells {
        return MechStatusV1::WRONG_SHAPE;
    }

    if input.len == 0 {
        return MechStatusV1::OK;
    }

    if input.ptr.is_null() || out.ptr.is_null() {
        return MechStatusV1::NULL_POINTER;
    }

    let input_slice = unsafe { core::slice::from_raw_parts(input.ptr, input.len) };
    let out_slice = unsafe { core::slice::from_raw_parts_mut(out.ptr, out.len) };

    kernel(input_slice, out_slice);

    MechStatusV1::OK
}

define_unary_f64_dynamic_kernels!(math_round_f64_v1, math_round_f64_view_v1, round);

define_unary_f64_dynamic_kernels!(math_sqrt_f64_v1, math_sqrt_f64_view_v1, sqrt);

define_unary_f64_dynamic_kernels!(math_floor_f64_v1, math_floor_f64_view_v1, floor);

define_unary_f64_dynamic_kernels!(math_ceil_f64_v1, math_ceil_f64_view_v1, ceil);

define_unary_f64_dynamic_kernels!(math_sin_f64_v1, math_sin_f64_view_v1, sin);

define_unary_f64_dynamic_kernels!(math_cos_f64_v1, math_cos_f64_view_v1, cos);

define_unary_f64_dynamic_kernels!(math_tan_f64_v1, math_tan_f64_view_v1, tan);

define_unary_f64_dynamic_kernels!(math_asin_f64_v1, math_asin_f64_view_v1, asin);

define_unary_f64_dynamic_kernels!(math_acos_f64_v1, math_acos_f64_view_v1, acos);

define_unary_f64_dynamic_kernels!(math_atan_f64_v1, math_atan_f64_view_v1, atan);

define_binary_f64_dynamic_kernel!(math_atan2_f64_v1, atan2);

#[cfg(test)]
mod tests {
    use super::*;

    fn assert_export_metadata(index: usize, expected_name: &[u8], expected_kind: MechKernelKindV1) {
        let mut export = MechExportV1 {
            name: MechStrV1 {
                ptr: core::ptr::null(),
                len: 0,
            },
            kind: MechKernelKindV1::UNARY_F64_TO_F64,
            function: MechKernelFnV1 {
                unary_f64_to_f64: math_round_f64_v1,
            },
        };

        let status = unsafe { mech_module_get_export_v1(index, &mut export) };
        let name = unsafe { core::slice::from_raw_parts(export.name.ptr, export.name.len) };

        assert_eq!(status, MechStatusV1::OK);
        assert_eq!(name, expected_name);
        assert_eq!(export.kind, expected_kind);
    }

    #[test]
    fn module_name_null_pointer_returns_null_pointer() {
        let status = unsafe { mech_module_name_v1(core::ptr::null_mut()) };
        assert_eq!(status, MechStatusV1::NULL_POINTER);
    }

    #[test]
    fn module_metadata_reports_module_name() {
        let mut module_name = MechStrV1 {
            ptr: core::ptr::null(),
            len: 0,
        };
        let status = unsafe { mech_module_name_v1(&mut module_name) };
        let name = unsafe { core::slice::from_raw_parts(module_name.ptr, module_name.len) };
        assert_eq!(status, MechStatusV1::OK);
        assert_eq!(name, MODULE_NAME);
    }

    #[test]
    fn module_export_count_is_twenty_one() {
        assert_eq!(unsafe { mech_module_export_count_v1() }, 21);
    }

    #[test]
    fn module_get_export_rejects_null_output() {
        let status = unsafe { mech_module_get_export_v1(0, core::ptr::null_mut()) };
        assert_eq!(status, MechStatusV1::NULL_POINTER);
    }

    #[test]
    fn module_get_export_rejects_invalid_index() {
        let mut export = MechExportV1 {
            name: MechStrV1 {
                ptr: core::ptr::null(),
                len: 0,
            },
            kind: MechKernelKindV1::UNARY_F64_TO_F64,
            function: MechKernelFnV1 {
                unary_f64_to_f64: math_round_f64_v1,
            },
        };
        let status = unsafe { mech_module_get_export_v1(21, &mut export) };
        assert_eq!(status, MechStatusV1::INVALID_INDEX);
    }

    #[test]
    fn export_metadata_describes_all_exported_kernels_in_order() {
        assert_export_metadata(0, EXPORT_NAME, MechKernelKindV1::UNARY_F64_TO_F64);
        assert_export_metadata(1, EXPORT_NAME, MechKernelKindV1::UNARY_F64_VIEW_TO_F64_VIEW);

        assert_export_metadata(2, SQRT_EXPORT_NAME, MechKernelKindV1::UNARY_F64_TO_F64);
        assert_export_metadata(
            3,
            SQRT_EXPORT_NAME,
            MechKernelKindV1::UNARY_F64_VIEW_TO_F64_VIEW,
        );

        assert_export_metadata(4, FLOOR_EXPORT_NAME, MechKernelKindV1::UNARY_F64_TO_F64);
        assert_export_metadata(
            5,
            FLOOR_EXPORT_NAME,
            MechKernelKindV1::UNARY_F64_VIEW_TO_F64_VIEW,
        );

        assert_export_metadata(6, CEIL_EXPORT_NAME, MechKernelKindV1::UNARY_F64_TO_F64);
        assert_export_metadata(
            7,
            CEIL_EXPORT_NAME,
            MechKernelKindV1::UNARY_F64_VIEW_TO_F64_VIEW,
        );

        assert_export_metadata(8, SIN_EXPORT_NAME, MechKernelKindV1::UNARY_F64_TO_F64);
        assert_export_metadata(
            9,
            SIN_EXPORT_NAME,
            MechKernelKindV1::UNARY_F64_VIEW_TO_F64_VIEW,
        );

        assert_export_metadata(10, COS_EXPORT_NAME, MechKernelKindV1::UNARY_F64_TO_F64);
        assert_export_metadata(
            11,
            COS_EXPORT_NAME,
            MechKernelKindV1::UNARY_F64_VIEW_TO_F64_VIEW,
        );

        assert_export_metadata(12, TAN_EXPORT_NAME, MechKernelKindV1::UNARY_F64_TO_F64);
        assert_export_metadata(
            13,
            TAN_EXPORT_NAME,
            MechKernelKindV1::UNARY_F64_VIEW_TO_F64_VIEW,
        );

        assert_export_metadata(14, ASIN_EXPORT_NAME, MechKernelKindV1::UNARY_F64_TO_F64);
        assert_export_metadata(
            15,
            ASIN_EXPORT_NAME,
            MechKernelKindV1::UNARY_F64_VIEW_TO_F64_VIEW,
        );

        assert_export_metadata(16, ACOS_EXPORT_NAME, MechKernelKindV1::UNARY_F64_TO_F64);
        assert_export_metadata(
            17,
            ACOS_EXPORT_NAME,
            MechKernelKindV1::UNARY_F64_VIEW_TO_F64_VIEW,
        );

        assert_export_metadata(18, ATAN_EXPORT_NAME, MechKernelKindV1::UNARY_F64_TO_F64);
        assert_export_metadata(
            19,
            ATAN_EXPORT_NAME,
            MechKernelKindV1::UNARY_F64_VIEW_TO_F64_VIEW,
        );

        assert_export_metadata(
            20,
            ATAN2_EXPORT_NAME,
            MechKernelKindV1::BINARY_F64_F64_TO_F64,
        );
    }

    #[test]
    fn export_metadata_describes_round_kernel() {
        let mut export = MechExportV1 {
            name: MechStrV1 {
                ptr: core::ptr::null(),
                len: 0,
            },
            kind: MechKernelKindV1::UNARY_F64_TO_F64,
            function: MechKernelFnV1 {
                unary_f64_to_f64: math_round_f64_v1,
            },
        };
        let status = unsafe { mech_module_get_export_v1(0, &mut export) };
        let name = unsafe { core::slice::from_raw_parts(export.name.ptr, export.name.len) };
        assert_eq!(status, MechStatusV1::OK);
        assert_eq!(name, EXPORT_NAME);
        assert_eq!(export.kind, MechKernelKindV1::UNARY_F64_TO_F64);
    }

    #[test]
    fn export_metadata_describes_round_view_kernel() {
        let mut export = MechExportV1 {
            name: MechStrV1 {
                ptr: core::ptr::null(),
                len: 0,
            },
            kind: MechKernelKindV1::UNARY_F64_VIEW_TO_F64_VIEW,
            function: MechKernelFnV1 {
                unary_f64_view_to_f64_view: math_round_f64_view_v1,
            },
        };
        let status = unsafe { mech_module_get_export_v1(1, &mut export) };
        let name = unsafe { core::slice::from_raw_parts(export.name.ptr, export.name.len) };
        assert_eq!(status, MechStatusV1::OK);
        assert_eq!(name, EXPORT_NAME);
        assert_eq!(export.kind, MechKernelKindV1::UNARY_F64_VIEW_TO_F64_VIEW);
    }

    #[test]
    fn export_metadata_describes_sqrt_scalar_kernel() {
        let mut export = MechExportV1 {
            name: MechStrV1 {
                ptr: core::ptr::null(),
                len: 0,
            },
            kind: MechKernelKindV1::UNARY_F64_TO_F64,
            function: MechKernelFnV1 {
                unary_f64_to_f64: math_sqrt_f64_v1,
            },
        };
        let status = unsafe { mech_module_get_export_v1(2, &mut export) };
        let name = unsafe { core::slice::from_raw_parts(export.name.ptr, export.name.len) };
        assert_eq!(status, MechStatusV1::OK);
        assert_eq!(name, SQRT_EXPORT_NAME);
        assert_eq!(export.kind, MechKernelKindV1::UNARY_F64_TO_F64);
    }

    #[test]
    fn export_metadata_describes_sqrt_view_kernel() {
        let mut export = MechExportV1 {
            name: MechStrV1 {
                ptr: core::ptr::null(),
                len: 0,
            },
            kind: MechKernelKindV1::UNARY_F64_VIEW_TO_F64_VIEW,
            function: MechKernelFnV1 {
                unary_f64_view_to_f64_view: math_sqrt_f64_view_v1,
            },
        };
        let status = unsafe { mech_module_get_export_v1(3, &mut export) };
        let name = unsafe { core::slice::from_raw_parts(export.name.ptr, export.name.len) };
        assert_eq!(status, MechStatusV1::OK);
        assert_eq!(name, SQRT_EXPORT_NAME);
        assert_eq!(export.kind, MechKernelKindV1::UNARY_F64_VIEW_TO_F64_VIEW);
    }

    #[test]
    fn export_metadata_describes_atan2_kernel() {
        let mut export = MechExportV1 {
            name: MechStrV1 {
                ptr: core::ptr::null(),
                len: 0,
            },
            kind: MechKernelKindV1::BINARY_F64_F64_TO_F64,
            function: MechKernelFnV1 {
                binary_f64_f64_to_f64: math_atan2_f64_v1,
            },
        };
        let status = unsafe { mech_module_get_export_v1(20, &mut export) };
        let name = unsafe { core::slice::from_raw_parts(export.name.ptr, export.name.len) };
        assert_eq!(status, MechStatusV1::OK);
        assert_eq!(name, ATAN2_EXPORT_NAME);
        assert_eq!(export.kind, MechKernelKindV1::BINARY_F64_F64_TO_F64);
    }

    #[test]
    fn math_round_f64_returns_expected_result() {
        let mut out = 0.0;
        let status = unsafe { math_round_f64_v1(1.23, &mut out) };
        assert_eq!(status, MechStatusV1::OK);
        assert_eq!(out, 1.0);
    }

    #[test]
    fn math_sqrt_f64_returns_expected_result() {
        let mut out = 0.0;
        let status = unsafe { math_sqrt_f64_v1(9.0, &mut out) };
        assert_eq!(status, MechStatusV1::OK);
        assert_eq!(out, 3.0);
    }

    #[test]
    fn math_floor_f64_returns_expected_result() {
        let mut out = 0.0;
        let status = unsafe { math_floor_f64_v1(4.56, &mut out) };
        assert_eq!(status, MechStatusV1::OK);
        assert_eq!(out, 4.0);
    }

    #[test]
    fn math_ceil_f64_returns_expected_result() {
        let mut out = 0.0;
        let status = unsafe { math_ceil_f64_v1(4.56, &mut out) };
        assert_eq!(status, MechStatusV1::OK);
        assert_eq!(out, 5.0);
    }

    #[test]
    fn math_sin_f64_returns_expected_result() {
        let mut out = 1.0;
        let status = unsafe { math_sin_f64_v1(0.0, &mut out) };
        assert_eq!(status, MechStatusV1::OK);
        assert_eq!(out, 0.0);
    }

    #[test]
    fn math_cos_f64_returns_expected_result() {
        let mut out = 0.0;
        let status = unsafe { math_cos_f64_v1(0.0, &mut out) };
        assert_eq!(status, MechStatusV1::OK);
        assert_eq!(out, 1.0);
    }

    #[test]
    fn math_tan_f64_returns_expected_result() {
        let mut out = 1.0;
        let status = unsafe { math_tan_f64_v1(0.0, &mut out) };
        assert_eq!(status, MechStatusV1::OK);
        assert_eq!(out, 0.0);
    }

    #[test]
    fn math_asin_f64_returns_expected_result() {
        let mut out = 1.0;
        let status = unsafe { math_asin_f64_v1(0.0, &mut out) };
        assert_eq!(status, MechStatusV1::OK);
        assert_eq!(out, 0.0);
    }

    #[test]
    fn math_acos_f64_returns_expected_result() {
        let mut out = 1.0;
        let status = unsafe { math_acos_f64_v1(1.0, &mut out) };
        assert_eq!(status, MechStatusV1::OK);
        assert_eq!(out, 0.0);
    }

    #[test]
    fn math_atan_f64_returns_expected_result() {
        let mut out = 1.0;
        let status = unsafe { math_atan_f64_v1(0.0, &mut out) };
        assert_eq!(status, MechStatusV1::OK);
        assert_eq!(out, 0.0);
    }

    #[test]
    fn math_atan2_f64_returns_expected_result() {
        let mut out = 1.0;
        let status = unsafe { math_atan2_f64_v1(0.0, 1.0, &mut out) };
        assert_eq!(status, MechStatusV1::OK);
        assert_eq!(out, 0.0);
    }

    #[test]
    fn math_sqrt_f64_view_returns_expected_result() {
        let input = [1.0, 4.0, 9.0];
        let mut out = [0.0, 0.0, 0.0];
        let status = unsafe {
            math_sqrt_f64_view_v1(
                MechF64ViewV1 {
                    ptr: input.as_ptr(),
                    len: input.len(),
                    rows: 1,
                    cols: 3,
                },
                MechF64ViewMutV1 {
                    ptr: out.as_mut_ptr(),
                    len: out.len(),
                    rows: 1,
                    cols: 3,
                },
            )
        };
        assert_eq!(status, MechStatusV1::OK);
        assert_eq!(out, [1.0, 2.0, 3.0]);
    }

    #[test]
    fn math_cos_f64_view_returns_expected_result() {
        let input = [0.0, 0.0];
        let mut out = [0.0, 0.0];

        let status = unsafe {
            math_cos_f64_view_v1(
                MechF64ViewV1 {
                    ptr: input.as_ptr(),
                    len: input.len(),
                    rows: 1,
                    cols: 2,
                },
                MechF64ViewMutV1 {
                    ptr: out.as_mut_ptr(),
                    len: out.len(),
                    rows: 1,
                    cols: 2,
                },
            )
        };

        assert_eq!(status, MechStatusV1::OK);
        assert_eq!(out, [1.0, 1.0]);
    }

    #[test]
    fn math_round_f64_rejects_null_output() {
        let status = unsafe { math_round_f64_v1(1.23, core::ptr::null_mut()) };
        assert_eq!(status, MechStatusV1::NULL_POINTER);
    }

    #[test]
    fn math_round_f64_view_returns_expected_result() {
        let input = [1.23, 2.7, 3.1];
        let mut out = [0.0, 0.0, 0.0];

        let status = unsafe {
            math_round_f64_view_v1(
                MechF64ViewV1 {
                    ptr: input.as_ptr(),
                    len: input.len(),
                    rows: 1,
                    cols: 3,
                },
                MechF64ViewMutV1 {
                    ptr: out.as_mut_ptr(),
                    len: out.len(),
                    rows: 1,
                    cols: 3,
                },
            )
        };

        assert_eq!(status, MechStatusV1::OK);
        assert_eq!(out, [1.0, 3.0, 3.0]);
    }

    #[test]
    fn math_round_f64_view_rejects_null_input() {
        let mut out = [0.0, 0.0, 0.0];

        let status = unsafe {
            math_round_f64_view_v1(
                MechF64ViewV1 {
                    ptr: core::ptr::null(),
                    len: out.len(),
                    rows: 1,
                    cols: 3,
                },
                MechF64ViewMutV1 {
                    ptr: out.as_mut_ptr(),
                    len: out.len(),
                    rows: 1,
                    cols: 3,
                },
            )
        };

        assert_eq!(status, MechStatusV1::NULL_POINTER);
    }

    #[test]
    fn math_round_f64_view_rejects_null_output() {
        let input = [1.23, 2.7, 3.1];

        let status = unsafe {
            math_round_f64_view_v1(
                MechF64ViewV1 {
                    ptr: input.as_ptr(),
                    len: input.len(),
                    rows: 1,
                    cols: 3,
                },
                MechF64ViewMutV1 {
                    ptr: core::ptr::null_mut(),
                    len: input.len(),
                    rows: 1,
                    cols: 3,
                },
            )
        };

        assert_eq!(status, MechStatusV1::NULL_POINTER);
    }

    #[test]
    fn math_round_f64_view_rejects_wrong_len() {
        let input = [1.23, 2.7, 3.1];
        let mut out = [0.0, 0.0];

        let status = unsafe {
            math_round_f64_view_v1(
                MechF64ViewV1 {
                    ptr: input.as_ptr(),
                    len: input.len(),
                    rows: 1,
                    cols: 3,
                },
                MechF64ViewMutV1 {
                    ptr: out.as_mut_ptr(),
                    len: out.len(),
                    rows: 1,
                    cols: 2,
                },
            )
        };

        assert_eq!(status, MechStatusV1::WRONG_SHAPE);
    }

    #[test]
    fn math_round_f64_view_rejects_mismatched_shape() {
        let input = [1.23, 2.7, 3.1, 4.2];
        let mut out = [0.0, 0.0, 0.0, 0.0];

        let status = unsafe {
            math_round_f64_view_v1(
                MechF64ViewV1 {
                    ptr: input.as_ptr(),
                    len: input.len(),
                    rows: 2,
                    cols: 2,
                },
                MechF64ViewMutV1 {
                    ptr: out.as_mut_ptr(),
                    len: out.len(),
                    rows: 1,
                    cols: 4,
                },
            )
        };

        assert_eq!(status, MechStatusV1::WRONG_SHAPE);
    }

    #[test]
    fn math_round_f64_view_rejects_len_shape_mismatch() {
        let input = [1.23, 2.7, 3.1];
        let mut out = [0.0, 0.0, 0.0];

        let status = unsafe {
            math_round_f64_view_v1(
                MechF64ViewV1 {
                    ptr: input.as_ptr(),
                    len: input.len(),
                    rows: 3,
                    cols: 3,
                },
                MechF64ViewMutV1 {
                    ptr: out.as_mut_ptr(),
                    len: out.len(),
                    rows: 3,
                    cols: 3,
                },
            )
        };

        assert_eq!(status, MechStatusV1::WRONG_SHAPE);
    }

    #[test]
    fn math_round_f64_view_accepts_empty_views() {
        let status = unsafe {
            math_round_f64_view_v1(
                MechF64ViewV1 {
                    ptr: core::ptr::null(),
                    len: 0,
                    rows: 0,
                    cols: 0,
                },
                MechF64ViewMutV1 {
                    ptr: core::ptr::null_mut(),
                    len: 0,
                    rows: 0,
                    cols: 0,
                },
            )
        };

        assert_eq!(status, MechStatusV1::OK);
    }
}
