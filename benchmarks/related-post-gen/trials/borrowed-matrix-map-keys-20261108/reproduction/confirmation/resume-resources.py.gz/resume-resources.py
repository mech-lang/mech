from pathlib import Path
import datetime,hashlib,json,os,re,shutil,subprocess,time
P=Path(__file__).parent;R=Path('/Users/cim310/mech-lang/mech/benchmarks/related-post-gen');D=R/'results'
def read(p):return json.loads(Path(p).read_text())
rule=read(P/'prospective-rule.json');lat=read(D/rule['output_latency'])
assert len(lat['samples'])==775 and all(x['exit']==0 and x['exact_rust_output'] for x in lat['samples'])
assert not(D/rule['output_resources']).exists()
assert shutil.disk_usage(P).free>=1024**3
snap=subprocess.check_output(['ps','-axo','pid,ppid,etime,pcpu,command'],text=True);busy=[]
for line in snap.splitlines()[1:]:
 a=line.split(None,4)
 if len(a)!=5 or int(a[0])in[os.getpid(),os.getppid()]:continue
 command=Path(a[4].split()[0]).name
 if re.fullmatch(r'rustc|cargo|clang|clang\+\+|llc|opt|sample|gzip|xz|zstd|(?:gpu|engine|mech_core|mech_engine)-tests|one-kib|scalar|runner-(?:aot|metrics|profile|pc|trace|phases)',command):busy.append(a[:2]+[a[4].split()[0]])
assert not busy,busy
(P/'resources-quiet.json').write_text(json.dumps(dict(quiet=True,resumed_only_not_yet_started_resources=True,completed_latency_untouched=True,process_snapshot_sha256=hashlib.sha256(snap.encode()).hexdigest(),no_build_test_profile_archive_overlapped=True),indent=2)+'\n')
cmd=list(map(str,['python3',R/'compare-implementations.py','--config',P/'resources-config.json','--input','/private/tmp/mech-related-current-input-fixtures-20261107/posts.json','--samples','7','--order','randomized','--seed',str(rule['resource_seed']),'--deduplicate-outputs','--resources','--work',P/'resources','--output',D/rule['output_resources']]))
t=time.monotonic();r=subprocess.run(cmd,capture_output=True,text=True);(P/'resources-run.json').write_text(json.dumps(dict(command=cmd,exit=r.returncode,seconds=time.monotonic()-t,stdout=r.stdout,stderr=r.stderr),indent=2)+'\n');print('resources-run',r.returncode,flush=True);assert r.returncode==0,r.stdout[-2500:]+r.stderr[-2500:]
