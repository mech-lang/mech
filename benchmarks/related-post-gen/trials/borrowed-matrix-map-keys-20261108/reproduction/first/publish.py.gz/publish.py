from pathlib import Path
import gzip,hashlib,json,re,subprocess,datetime
P=Path(__file__).parent;C=Path('/private/tmp/mech-related-borrowed-matrix-map-keys-confirmation-20261108');S=Path('/private/tmp/mech-related-borrowed-matrix-map-keys-compiler-20261108');O=Path('/private/tmp/mech-related-borrowed-matrix-map-keys-opt-20261108-v2');N=Path('/private/tmp/mech-related-borrowed-matrix-map-keys-runners-20261108-v2');Q=Path('/private/tmp/mech-related-borrowed-matrix-map-keys-regressions-20261108-v2');R=Path('/Users/cim310/mech-lang/mech/benchmarks/related-post-gen');D=R/'results';DEST=S/'benchmarks/related-post-gen/trials/borrowed-matrix-map-keys-20261108'
read=lambda p:json.loads(Path(p).read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(name,b):
 p=DEST/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(b,mtime=0)if name.endswith('.gz')else b)
def cp(p,name):put(name,Path(p).read_bytes())
commit=read(P/'prospective-rule.json')['compiler_commit'];assert subprocess.check_output(['git','-C',str(S),'rev-parse','HEAD'],text=True).strip()==commit
I=read(O/'source-inventory.json');assert I['files']==read(P/'test-source-inventory.json')['files']==read(N/'runtime/source-inventory.json')['files']
for name,h in I['files'].items():
 b=(S/name).read_bytes();assert sha(b)==h;put('compiler-source/'+name+'.gz',b)
for p in O.glob('*.json'):cp(p,'compiler/'+p.name+'.gz')
for p in P.glob('*.json'):cp(p,'experiment/first/'+p.name+'.gz')
for root in ['failed-first-build','first-focused-results','first-headroom-results','full-input-test-build-error','first-ci-version-assertions','qualified-v6-before-metadata-walk-funding']:
 for p in (P/root).rglob('*'):
  if p.is_file() and p.suffix in ['.json','.gz']:
   name='qualification/preliminary/'+str(p.relative_to(P))
   if p.suffix=='.gz':put(name,gzip.decompress(p.read_bytes()))
   else:cp(p,name+'.gz')
for p in C.glob('*.json'):cp(p,'experiment/confirmation/'+p.name+'.gz')
for root,label in [(P,'first'),(C,'confirmation')]:
 for p in root.glob('*.py'):cp(p,'reproduction/'+label+'/'+p.name+'.gz')
for p in Q.glob('*.json'):cp(p,'qualification/scalar-DEFLATE/'+p.name+'.gz')
cp(Q/'run.py','reproduction/scalar-DEFLATE.py.gz')
# The Engine and its loan API are unchanged. Preserve the qualified parent
# tests and exact source inventory used for verified library reuse.
T=Path('/private/tmp/mech-related-closed-composite-constructors-tests-20261108-v2')
for name in ['closed-constructor-tests.json','composite-tests.json','all-native-collection-tests.json','engine-test-source-inventory.json']:
 cp(T/name,'qualification/unchanged-Engine/'+name+'.gz')
rows=[];seen=set()
for root,label in [(P,'first'),(C,'confirmation')]:
 rule=read(root/'prospective-rule.json')
 for boundary,key in [('latency','output_latency'),('resources','output_resources')]:
  f=D/rule[key];cp(f,'cohorts/'+f.name+'.gz');d=read(f)
  for x in d['samples']:
   assert x['exit']==0 and x['exact_rust_output'];h=x['output_sha256'];rows.append(dict(cohort=label,boundary=boundary,sample=x['sample'],variant=x['variant'],sha256=h))
   if h not in seen:
    f=root/boundary/(x['variant']+'-'+str(x['sample'])+'.json');b=f.read_bytes();assert sha(b)==h;put('outputs/'+h+'.json.gz',b);seen.add(h)
assert len(rows)==1914
put('outputs/manifest.json',(json.dumps(dict(outputs=rows,count=len(rows),all_exact=True),indent=2)+'\n').encode())
for f in (N/'histogram-reuse').rglob('*'):
 if f.is_file() and f.suffix in ['.json','.mec','.mecb','.rs','.o','.bin']:
  cp(f,'native/'+str(f.relative_to(N/'histogram-reuse'))+'.gz')
for f in (P/'metrics-v2').rglob('*'):
 if f.is_file() and f.suffix in ['.json','.rs']:cp(f,'metrics/'+str(f.relative_to(P/'metrics-v2'))+'.gz')
for name in ['restore-profile.sample.txt','restore-profile.stdout.log','restore-profile.stderr.log']:
 cp(P/name,'diagnostics/'+name+'.gz')
cp(N/'build-and-qualify.py','reproduction/build-and-qualify.py.gz')
cp(N/'runtime/runtime-build.json','native/runtime/runtime-build.json.gz');cp(N/'runtime/build.json','native/runtime/build.json.gz');cp(N/'runtime/source-inventory.json','native/runtime/source-inventory.json.gz')
put('compiler-change.patch.gz',subprocess.check_output(['git','-C',str(S),'diff','61997b025486521438578d7d101f1cdf7ab6f6c9',commit,'--','.github/workflows/ci-full.yml','hosts/gpu']))
a,b=read(P/'paired-analysis.json'),read(C/'paired-analysis.json');rule=read(P/'prospective-rule.json');base=rule['matched_parent'];selected=rule['selected_control'];candidate=rule['candidate']
text=(P/'restore-profile.sample.txt').read_text();proof=sum(int(m.group(1))for line in text.split('Total number in stack',1)[0].splitlines()if 'matrix_map_keys' in line and (m:=re.search(r'(\d+) _R',line)));assert proof==1161
profile=dict(restoration_entry_samples=3456,proof_derivation_inclusive_samples=1161,full_plan_revalidation_under_proof=1063,proof_fraction_of_restoration_samples=1161/3456,revalidation_fraction_within_proof_samples=1063/1161,scope='Repeated restore-only diagnostic with unchanged Mech Object; exact full5000 output afterwards. Samples are inclusive and not predicted removable latency.')
put('diagnostics/restore-profile-analysis.json',(json.dumps(profile,indent=2)+'\n').encode())
report=dict(schema='mech.related-post-gen.borrowed-matrix-map-keys.v1',updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),compiler_commit=commit,branch='codex/related-borrowed-matrix-map-keys-20261108',identity='IR299/work118/ABI41/image11',backend='Cranelift',selected_processing_compiler='IR295',candidate_retained_for_allocations_and_further_pipeline_work=True,processing_improvement_established=False,whole_process_gate=False,goal_complete=False,first=a,confirmation=b,binaries=read(P/'binary-and-control-summary.json'),qualification=read(P/'summary.json'),scalar_DEFLATE=read(P/'control-parent-parity.json'),restoration_profile=profile,source_sha256=sha((N/'histogram-reuse/build/source.mec').read_bytes()),next=['Remove redundant whole-plan validation during verified same-Object restoration while retaining independent/untrusted validation.','Extend borrowed keys through map/keys and the private frame, pinning the immutable key snapshot through original-handle retirement.','Keep the generic UTF8 seed/dictionary through the next lookup; distinguish keyset identity from current dictionary values.','Run separately attributable private-owned-write-first and completed-producer element-range experiments.'],unselected_ordinal_IR298_not_integrated_or_timed=True)
(D/'native-borrowed-matrix-map-keys-current-20261108.json').write_text(json.dumps(report,indent=2)+'\n');put('current-report.json',(json.dumps(report,indent=2)+'\n').encode())
readme=f'''# Borrowed String matrix cells into retained Map insertion

IR299 implements Stage A of the dictionary-preparation brief. This is a retained allocation improvement, **not a processing-speed promotion**. IR295 remains selected. Cranelift remains the production backend; no LLVM tool or dependency was added.

The compiler proves that one String matrix scalar result has exactly one semantic reader: the adjacent retained String/U64 Map insertion, in the same owning loop. Hidden/control/output/effect uses are included. The source matrix is immutable in an enclosing scope. The original String-read visit uses the existing Engine NativeStringMatrixKeyLoan; insertion consumes its selected cell with the current dictionary token. No String Value is constructed. Every original selector/output/clone/bounds obligation and finite limit remains; new metadata scans/residency are explicitly funded on the same invocation accounts. Stale generations, foreign map tokens, replay and failure cleanup remain checked.

Canonical map/keys, the private argument frame, canonical seed tuple and dictionary publication remain unchanged. The source program is byte-identical to IR295. The source loop and scalar arithmetic remain generated; existing Map storage helpers still perform insertion. This step does not claim that the full dictionary pipeline is native. The separate ordinal-loop prototype IR298 remains unselected, unintegrated and untimed.

| Cohort | Fastest eligible Rust | IR295 selected | IR297 parent | IR299 | IR299 / fastest Rust |
|---|---:|---:|---:|---:|---:|
| First C24 | 1.510292 ms | 1.909000 ms | 1.909792 ms | 1.908791 ms | 1.263856x |
| Independent C25 | 1.510209 ms | 1.899292 ms | 1.902792 ms | 1.908125 ms | 1.263484x |

All22 retained Rust controls run;20 are processing eligible. Preinitialized pools remain whole-process only. Each cohort has775 exact latency outputs and182 separate resource outputs; all1914 output records are preserved by content hash. Every sample, including adverse/outlier observations, remains. No data-dependent preparation, loan allocation, admission, worker create/run/join, cleanup or materialization moved outside the continuous post-JSON timer.

IR299 paired processing changes against immediate parent IR297: first +0.0326%,95% interval[-0.6107,+0.4956],14/31 favorable; confirmation +0.8511%,interval[-0.5170,+1.1265],13/31 favorable. Neither establishes improvement or regression. Relative to selected IR295, paired changes are +0.1772% and +0.3944%, also inconclusive. The latest selected measurement is1.899292ms /1.257635x fastest Rust. This is a remeasurement of unchanged IR295, not a new compiler win.

Confirmation processing resources: allocation requests1973→1751 (-222,11.25%); requested bytes7871350→7861191 (-10159); instructions34657222→34575168 (-82054,0.237%); cycles11118483→11147078 (slightly more). Additional peak requested heap5763262→5763966 (+704B); total peak14106634→14107498 (+864B). Candidate RSS28393472B / physical footprint17547624B. Rust reference uses58 allocations /17694378 instructions. No timing gain is inferred from fewer allocations or instructions.

The actual full5000 source diagnostic confirms28 borrowed producer cells,0 canonical String Values and28 retained insertions, with exact Rust results in original and restored descriptors. The compiler also finds a second qualifying site in the source's general path; no executed-count claim is made for that site. Net -222 allocations is the measured full-processing result, not a claim that the original140 kernel allocations explain every avoided wrapper allocation.

The whole-process cost is adverse and retained. Confirmation IR29737.923708ms→IR29941.592917ms; paired +8.6728%,interval[+6.1266,+11.7678]. First paired change +13.0406%. Restoration7.898125→11.597667ms; confirmation paired +46.9589%. Restore allocations28643→62607, requested bytes13662080→58510822; instructions124075018→180435258. This is not grounds to discard the allocation improvement or impose a whole-process gate.

A fresh executable profile isolates the new loading gap:1161/3456 restoration samples (33.59%) enter the new proof derivation;1063/1161 of those (91.56%) enter full-plan revalidation. The same exact linked Mech Object is used in a restore-loop host adapter and its final full5000 output is exact. These inclusive diagnostic samples are not additive production savings. Next remove redundant validation from already verified same-Object loading while preserving independent/untrusted validation, then continue the larger key-view/dictionary representation work. Only0.24% fewer processing instructions explains why this bounded allocation step has not solved the processing gap.

Native text grows72B to1031460B; stack remains1568B;49 numeric functions,4 workers and8 numeric worker regions remain. Object5781112→5781184B; executable17057424→17089952B (+32528). Build-owned native metadata record remains4741224B. Runtime is the compiler-free GPU build; exact linked Object text, relocations and metadata exports pass auditv9.

Qualification:6 new self-contained proof/runtime contracts; all444 native CI names, retaining all438 parent names; retained map, image/caller, UTF8/classification and modular-range contracts; original/decoded/restored execution; Unicode/NUL/empty/long65-key data, partial/no-op/out-of-bounds results; fresh keys and nonempty seeds; stale source/token and per-call caps;512-key metadata-refusal canonical fallback; six global finite-budget boundaries with first denial/publication/cleanup/retry checks. Full5000 plus31 edge outputs are exact. All128 scalar and5 DEFLATE nontiming records, including allocations/work/visits, are identical to IR297. No fresh scalar/DEFLATE latency claim is inferred from concurrent qualification timers. Engine source/dependencies are unchanged and reuse is verified against complete Rust/Cargo inventories and the retained129 native-collection tests.

Initial harness type errors, adjacency/extra-site expectation corrections, insufficient-headroom fixture, obsolete work-policy assertions, and pre-funding revision receipts remain. Two disk preflights stopped before measurement; completed confirmation latency was retained and only not-yet-started resources resumed. Intermediate/test executables were archived losslessly with hashes/modes locally; no primary output was discarded.

Source commit `{commit}`; research branch `codex/related-borrowed-matrix-map-keys-20261108`. PR990 integrated head remains IR242 and targets973. Rechecked973 at`efd9069b589512630891810191e7de35d57325d8`:two new commits change five documentation/experiment files, no compiler source. Ordinary production remains R199/IR214; R211 dead-owner-transfer numbers remain diagnostic with ordinary-contract omissions, not an inherited production gain.

Reproduction scripts, all source inventories, exact source patch, Object/metadata/audits, ordinary and instrumented host sources, raw cohorts and content-addressed outputs are included. Build/test/measurement paths and toolchain hashes remain in receipts. Read current-report.json and experiment/*/paired-analysis.json for complete resource and paired statistics. No parity claim; the goal remains active.
'''
put('README.md',readme.encode())
manifest={str(f.relative_to(DEST)):sha(f.read_bytes())for f in DEST.rglob('*')if f.is_file()and f.name!='manifest.json'}
put('manifest.json',(json.dumps(dict(schema='mech.related-post-gen.retained-experiment.v1',compiler_source_commit=commit,processing_baseline_unchanged=True,allocation_improvement_retained=True,payloads=manifest),indent=2)+'\n').encode());assert all(sha((DEST/f).read_bytes())==h for f,h in manifest.items())
print(json.dumps(dict(packet=str(DEST),payloads=len(manifest),outputs=len(rows),source_commit=commit,verified=True)))
