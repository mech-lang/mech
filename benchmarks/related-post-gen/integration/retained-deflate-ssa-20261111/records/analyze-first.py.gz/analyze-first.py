from pathlib import Path
import json,random,statistics as st,math
E=Path(__file__).parent;Q=E/'first';read=lambda p:json.loads(Path(p).read_text());a=read(Q/'latency.json');r=read(Q/'resources.json');rule=read(E/'prospective-rule.json');n=31;c=rule['primary_candidate'];b=rule['primary_control'];ref=a['matched_native_reference']['variant'];assert len(a['samples'])==n*25 and len(r['samples'])==7*26;assert all(x['exit']==0 and x['exact_rust_output'] for x in a['samples']+r['samples'])
def quant(xs,p):
 i=(len(xs)-1)*p;k=math.floor(i);return xs[k]+(xs[math.ceil(i)]-xs[k])*(i-k)
def pair(left,right,field):
 rows={v:{x['sample']:x.get(field,x['seconds'])for x in a['samples']if x['variant']==v}for v in [left,right]};assert all(set(x)==set(range(n))for x in rows.values());d=[rows[left][i]/rows[right][i]-1 for i in range(n)];rng=random.Random(rule['bootstrap_seed']);boots=sorted(st.median(d[rng.randrange(n)]for _ in range(n))for _ in range(rule['bootstrap_resamples']));return dict(candidate=left,baseline=right,pairs=n,wins=sum(x<0 for x in d),median_paired_relative_change=st.median(d),two_sided_95_interval=[quant(boots,.025),quant(boots,.975)],all_pair_changes=d)
pairs={f:pair(c,b,f)for f in ['post_json_seconds','wall_seconds','compile_or_restore_seconds']};med={}
for name,v in a['summary'].items():
 if name.startswith('mech')or name==ref:
  rows=[x for x in a['samples']if x['variant']==name];med[name]={f:st.median(x[f]for x in rows)for f in ['post_json_seconds','wall_seconds','compile_or_restore_seconds']if all(f in x for x in rows)};med[name]['times_fastest_eligible_Rust']=v['post_json_over_fastest_matched_native']
resources={name:{k:v[k]for k in ['post_json_measurement_median','process_resources_median','stage_measurements_median']if k in v}for name,v in r['summary'].items()if name.startswith('mech')or name==ref+'-instrumented'}
out=dict(exact_latency_outputs=len(a['samples']),exact_resource_outputs=len(r['samples']),fastest_eligible_Rust=a['matched_native_reference'],medians=med,resources=resources,paired_comparisons=pairs,advance_to_confirmation=pairs['post_json_seconds']['two_sided_95_interval'][1]<0,goal_complete=False,all_first_and_adverse_samples_retained=True,whole_process_gate=False,bootstrap_seed=rule['bootstrap_seed'],bootstrap_resamples=rule['bootstrap_resamples'])
(Q/'analysis.json').write_text(json.dumps(out,indent=2)+'\n');print('medians',json.dumps(med,indent=2));print('paired',json.dumps({k:{q:v[q]for q in ['median_paired_relative_change','two_sided_95_interval','wins']}for k,v in pairs.items()}));print('confirm',out['advance_to_confirmation'])
for name,v in resources.items():
 p=v['post_json_measurement_median'];print(name,{k:p[k]for k in ['allocation_requests','requested_allocation_bytes','peak_additional_live_requested_heap_bytes']},p['hardware'])
