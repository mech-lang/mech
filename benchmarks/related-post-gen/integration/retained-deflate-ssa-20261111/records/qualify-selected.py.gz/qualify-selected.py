from pathlib import Path
import hashlib,json,os,subprocess,time
E=Path(__file__).parent;P=E/'selected-qualification';P.mkdir(exist_ok=False);text=(E/'runners/selected/runner.rs').read_text();text=text.replace('let catalog = linked_catalog().unwrap();','let catalog = mech_stdlib::source_catalog();')
old='    let artifact = source(&std::fs::read_to_string(&args[0]).unwrap());'
new=old+'''\n    #[cfg(not(linked))]
    let artifact = if std::env::var_os("MECH_QUAL_DECODED").is_some() {
        mech_engine::decode_program_artifact_bytecode_v1(&mech_engine::encode_program_artifact_bytecode_v1(&artifact).unwrap()).unwrap()
    } else { artifact };'''
assert text.count(old)==1;text=text.replace(old,new)
marker='        if sample+1==samples {'
extra='''        // Qualification only: hold successful published roots across every
        // finite denial, then retry the entire unchanged 5000-post program.
        let expected = output.iter().map(|v| v.as_ref().unwrap().canonical_data_draft().unwrap()).collect::<Vec<_>>();
        for dimension in ["control", "library", "comparison", "memory", "nodes", "transport"] {
            let prior = output.clone();
            let retained = (memory.used_bytes(), memory.retained_snapshot_nodes());
            let mut policy = mode.execution();
            let mut budget = memory.clone();
            match dimension {
                "control" => policy.execution.max_work = 0,
                "library" => policy.library.max_compute_work = Some(0),
                "comparison" => policy.library.max_comparison_work = Some(0),
                "memory" => budget = memory.with_limits(0, u64::MAX),
                "nodes" => budget = memory.with_limits(u64::MAX, 0),
                "transport" => policy.execution.max_transport_bytes = 0,
                _ => unreachable!(),
            }
            let error = program.evaluate_into(&input, &mut output, policy, &budget).unwrap_err();
            assert!(output.iter().zip(&prior).all(|(a,b)| a.as_ref().unwrap().shares_frozen_storage(b.as_ref().unwrap())));
            assert_eq!((memory.used_bytes(), memory.retained_snapshot_nodes()), retained);
            let report = program.evaluate_into(&input, &mut output, mode.execution(), &memory).unwrap();
            assert_eq!(output.iter().map(|v| v.as_ref().unwrap().canonical_data_draft().unwrap()).collect::<Vec<_>>(), expected);
            println!("QUALIFICATION {}", serde_json::json!({"dimension":dimension,"denied":true,"error":format!("{error:?}"),"publication_unchanged_on_denial":true,"retry_full5000_exact":true,"retry_work":report.work,"diagnostic_only":true}));
        }
'''
assert text.count(marker)==1;text=text.replace(marker,extra+marker);(P/'runner.rs').write_text(text)
def run(c,name,env=None):
 t=time.monotonic();r=subprocess.run(list(map(str,c)),capture_output=True,text=True,env={**os.environ,**(env or {})});(P/(name+'.json')).write_text(json.dumps(dict(command=list(map(str,c)),environment=env or {},exit=r.returncode,seconds=time.monotonic()-t,stdout=r.stdout,stderr=r.stderr,qualification_only=True,timings_eligible=False),indent=2)+'\n');print(name,r.returncode,flush=True);assert r.returncode==0,r.stdout[-8000:]+r.stderr[-8000:];return r
run(['python3','/private/tmp/mech-related-pr990-rebase-evidence-20261111/build-cargo-host.py','--compiler-build',E/'compiler/build.json','--source',P/'runner.rs','--out',P/'runner-qualify'],'build')
expected=json.loads((E/'frozen-inputs/expected.json').read_text());summary=[]
for decoded in [False,True]:
 n='decoded'if decoded else'original';p=P/(n+'-output.json');r=run([P/'runner-qualify',E/'runners/selected/build/source.mec',E/'frozen-inputs/posts.json',p,'1'],n,{'MECH_QUAL_DECODED':'1'}if decoded else{});assert json.loads(p.read_text())==expected;qs=[json.loads(x.removeprefix('QUALIFICATION '))for x in r.stdout.splitlines()if x.startswith('QUALIFICATION ')];assert len(qs)==6;summary.append(dict(form=n,full5000_JSON_exact=True,six_finite_denials_with_unchanged_publication_and_full_retry=True,records=qs))
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('selected original/decoded full5000,12denials+12fullretries exact',flush=True)
