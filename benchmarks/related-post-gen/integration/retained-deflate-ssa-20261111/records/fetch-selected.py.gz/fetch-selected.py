from pathlib import Path
import json,urllib.request,hashlib,tarfile,re
E=Path(__file__).parent
S=Path('/private/tmp/mech-related-compiler-catchup-20261111')
old=Path('/private/tmp/mech-related-pr990-rebase-evidence-20261111')
rounds=json.loads((S/'benchmarks/mech-deflate/experiments.json').read_text())['rounds']
number=304;chain=[]
while number>293:
 root=E/('deflate-r'+str(number)); e=root/'packet/evidence'; root.mkdir(exist_ok=True)
 pinfile=e/'source-pins.json'
 if not pinfile.exists():
  v=rounds[str(number)]['review_packet']; f=root/'packet.tar.gz'
  if not f.exists():f.write_bytes(urllib.request.urlopen(v['url'],timeout=60).read())
  data=f.read_bytes();assert hashlib.sha256(data).hexdigest()==v['sha256'];assert len(data)==v['bytes']
  with tarfile.open(f)as t:t.extractall(root/'packet',filter='data')
  print('downloaded verified R'+str(number),len(data),flush=True)
 pin=json.loads(pinfile.read_text());chain.append(dict(round=number,root=str(e),source_pins=pin))
 parent=pin.get('compiler_parent_round')
 if parent is None:
  archive=pin.get('compiler_parent_archive',pin.get('compiler_base_archive')); url=archive.get('url')if isinstance(archive,dict)else archive
  assert url,(number,pin.keys());parent=int(re.search(r'/r(\d+)-',url)[1])
 assert parent<number,(number,parent);number=parent
assert number==293,number
prior=json.loads((old/'deflate-selected-source-chain.json').read_text())
chain.extend(prior)
(E/'selected-source-chain.json').write_text(json.dumps(chain,indent=2)+'\n')
print('selected chain',[r['round']for r in chain],flush=True)
