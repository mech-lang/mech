from pathlib import Path
import json,gzip,hashlib,subprocess,statistics as st,importlib.util
E=Path(__file__).parent;S=Path('/private/tmp/mech-related-compiler-catchup-20261111');D=S/'benchmarks/related-post-gen/integration/retained-deflate-ssa-20261111';D.mkdir(exist_ok=False);read=lambda p:json.loads(Path(p).read_text());sha=lambda b:hashlib.sha256(b).hexdigest();files=[];seen=set()
def add(p,rel=None):
 p=Path(p)
 if not p.is_file():return
 rel=Path(rel)if rel else p.relative_to(E)
 if str(rel)in seen:return
 seen.add(str(rel));b=p.read_bytes();q=D/'records'/Path(str(rel)+'.gz');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(gzip.compress(b,mtime=0));files.append(dict(path=str(q.relative_to(D)),sha256=sha(q.read_bytes()),uncompressed_sha256=sha(b),uncompressed_bytes=len(b),original_path=str(p)))
for p in sorted(E.iterdir()):
 if p.suffix in ['.json','.py','.rs']:add(p)
for name in ['compiler','runtime','tests','compiler-v1','runtime-v1','tests-v1','tests-first-missing-archive-test-sources','qualification','regressions','metrics','selected-qualification','profile']:
 for p in sorted((E/name).rglob('*')):
  if not p.is_file()or p.suffix not in ['.json','.py','.rs','.txt','.stdout','.stderr']:continue
  if p.name in ['output.json','original-output.json','decoded-output.json']or'build'in p.relative_to(E/name).parts:continue
  add(p)
for p in sorted((E/'first').glob('*.json')):add(p)
for p in sorted((E/'runners/selected').glob('*')):
 if p.suffix in ['.json','.rs']and p.name!='output.json':add(p)
for name in ['source.mec','metadata.json','descriptor.json','frame-summary.json','catalog-profile.json']:
 add(E/'runners/selected/build'/name,Path('selected-bundle')/name)
for p in sorted((E/'runners/selected/edges').rglob('*.json')):add(p)
for n in [304,301]:add(E/f'deflate-r{n}/packet/evidence/test-changes.patch')
a=read(E/'first/analysis.json');lat=read(E/'first/latency.json');r=read(E/'first/resources.json');rule=read(E/'prospective-rule.json');c=rule['primary_candidate'];b=rule['primary_control'];ref=a['fastest_eligible_Rust']['variant'];p=a['paired_comparisons']['post_json_seconds'];meta=read(E/'objects/selected/metadata.json');prior=read('/private/tmp/mech-related-narrow-updates-20261111/runners/counts-postings32/build/metadata.json');res=a['resources'];cn=c+'-instrumented';bn=b+'-instrumented';rn=ref+'-instrumented';C=res[cn];B=res[bn];R=res[rn];current=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip();base=subprocess.check_output(['git','rev-parse','origin/codex/level12-compression-consolidated'],cwd=S,text=True).strip();subprocess.run(['git','merge-base','--is-ancestor',base,'HEAD'],cwd=S,check=True)
sp=importlib.util.spec_from_file_location('i',S/'benchmarks/related-post-gen/build-compiler.py');i=importlib.util.module_from_spec(sp);sp.loader.exec_module(i);sources=i.source_inventory(S);assert sources==read(E/'compiler/source-inventory.json')['files'];assert sha((S/'benchmarks/related-post-gen/mech/related_optimized.mec').read_bytes())=='d70a001620977aff9529884d0207fbf7952a359388988431b4102ae0465f1905';assert not a['advance_to_confirmation'];assert read(E/'qualification/final-ci.json')['passed']==528
summary=dict(schema='mech.related-post-gen.retained-deflate-ssa.v1',compiler=dict(identity='IR317/work126/ABI42/image11',measured_commit=current,PR973_base=base,inventoried_compiler_config_sources=len(sources),source_sha256=read(E/'compiler/build.json')['source_sha256'],backend='Cranelift 0.131.3 with checked DEFLATE backend patches; regalloc2 0.15.2',required_LLVM_dependency=False,retained_experimental_source_round=304,import_provenance=read(E/'cfg-import-provenance.json'),full_experimental_compact_runtime_imported=False),selection=dict(compiler_passes_retained_for_code_and_instruction_savings=True,confirmed_latency_improvement=False,independent_confirmation_attempted=False,reason='First latency interval spans zero; do not repeat an unchanged inconclusive variant.',maintained_source_sha256='d70a001620977aff9529884d0207fbf7952a359388988431b4102ae0465f1905',numeric_functions=49,query_workers=4),qualification=dict(compiler_contracts=528,all508_parent_names_retained=True,all484_IR308_names_retained=True,scalar_non_timing_resource_rows_exact=128,DEFLATE_non_timing_resource_rows_exact=5,linked_exact_cases=32,same_Object_audit=True,full5000_original_decoded=True,zero_budget_denials=12,full5000_retries=12,diagnostic_same_Object_profiles=2),first=a,function_effects=read(E/'function-effects.json'),emission_counts=read(E/'selected-emission-counts.json'),profile=read(E/'profile/analysis.json'),limitations=['The #973 Git branch and its experimental compiler archives are separate publication surfaces. This imports retained portable SSA passes, preserving selected managed leaf/tree lowering; it does not replace it with the entire experimental compact entry.','First/adverse tests, receipts and all775 latency plus182 separate resource observations are preserved. No unchanged latency retry.','Diagnostic repeated native profiles exclude repeated input admission/export/materialization. Reported sampled leaves are not exact CPU or latency shares.','Whole-process remains visible without an acceptance gate; no new required LLVM dependency or counter exemption.'],artifacts=files)
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
rows=['All rows come from the same31-round randomized first cohort. The continuous post-JSON timer includes setup, admission, allocations, worker creation/run/join, cleanup and materialization. Preinitialized rows have ineligible raw timer scopes. No latency confirmation was run.','', '| Variant | Timer ms | × fastest eligible Rust | Whole-process ms | Restore ms |','| --- | ---: | ---: | ---: | ---: |']
for n,v in lat['summary'].items():
 xs=[x for x in lat['samples']if x['variant']==n];restore=st.median(x['compile_or_restore_seconds']for x in xs)*1000 if'compile_or_restore_seconds'in xs[0]else None;ratio=v.get('post_json_over_fastest_matched_native');timer=(v.get('median_post_json_seconds')or v['median_seconds'])*1000;rows.append(f"| `{n}` | {timer:.6f} | {f'{ratio:.6f}'if ratio is not None else'ineligible'} | {v['median_whole_process_seconds']*1000:.6f} | {f'{restore:.6f}'if restore is not None else'—'} |")
(D/'ALL-TIMINGS.md').write_text('\n'.join(rows).replace('same31','same 31')+'\n')
resource=['| Post-JSON resource | Published IR315 | Imported IR317 | Matched Rust |','| --- | ---: | ---: | ---: |']
for label,key,hw in [('Retired instructions','instructions_retired',True),('Cycles','cycles',True),('Allocation requests','allocation_requests',False),('Requested allocation bytes','requested_allocation_bytes',False),('Peak additional requested heap bytes','peak_additional_live_requested_heap_bytes',False)]:
 vals=[]
 for x in [B,C,R]:
  v=x['post_json_measurement_median'];vals.append(f"{(v['hardware']if hw else v)[key]:,}")
 resource.append('| '+label+' | '+' | '.join(vals)+' |')
cm=a['medians'][c];bm=a['medians'][b];q=next(x for x in summary['function_effects']if x['header']==1587);ci=p['two_sided_95_interval'];cfg=read(E/'latency-config-frozen.json');exes={v['name']:v['executable_file_bytes']for v in cfg['implementations']};wp=a['paired_comparisons']['wall_seconds'];prof=summary['profile'];gap=cm['post_json_seconds']-a['fastest_eligible_Rust']['median_seconds']
report=f'''# Retained DEFLATE SSA compiler integration

PR #990 includes #973 through `{base}`. The retained DEFLATE compiler exists in public experiment archives as well as maintained Git code. This change reconstructs and hash-verifies all842 files of the retained R304 closure, then integrates its portable structural SSA passes into the selected native compiler. It preserves the existing managed numeric leaf/tree route, narrow checked-write proofs, backend patches and guard ordering. It does not claim that the entire experimental compact runtime has been imported.

The imported passes refine current predicates, forward pure identity routes and loop edges with typed live-outs, preserve agreeing Boolean literals across joins, fold scoped bitwise constants, share fixed-window limits and ordered capture spans, and reuse adjacent typed addresses. They operate on current immutable CLIF words. Effects, traps, source work debits, ownership, memory permission, output publication and failure order retain their existing contracts. Independent emission ablations remain available. Numeric guard proofs run before the late imported transforms.

Two integration gaps were repaired: structural cleanup now normalizes the aliases it creates before returning, preserving idempotence; fixed-window matching accepts equivalent add-immediate subtraction under the same selected nonwrapping length proof. The first failed build and first528-test run remain in the evidence. That run passed526 and exposed the two subsequently fixed cases. The missing window tests were supplied locally with executable short/exact/wrapping bounds, distinct rejection, side-effect, alternate-entry, publication and retry coverage. Published address/span test patches are retained byte-for-byte.

## First matched timings

| Implementation | Post-JSON median | × fastest eligible Rust |
| --- | ---: | ---: |
| Fastest eligible Rust (`{ref}`) | {a['fastest_eligible_Rust']['median_seconds']*1000:.6f} ms | 1.000000× |
| Published IR315, same maintained source | {bm['post_json_seconds']*1000:.6f} ms | {bm['times_fastest_eligible_Rust']:.6f}× |
| Imported IR317, same maintained source | {cm['post_json_seconds']*1000:.6f} ms | {cm['times_fastest_eligible_Rust']:.6f}× |

The median paired change is **{p['median_paired_relative_change']*100:+.3f}%**, with a descriptive95% interval **[{ci[0]*100:+.3f}%, {ci[1]*100:+.3f}%]** and18/31 paired wins. This is **inconclusive latency evidence**. No unchanged confirmation cohort was repeated. The compiler changes are retained for verified instruction/code savings under the relaxed acceptance policy. They are not described as a confirmed latency improvement. The1.00× goal remains unmet; this first cohort leaves{gap*1e6:.3f}μs to its measured fastest eligible Rust.

There are31 randomized latency rounds across25 implementations and seven separate resource rounds across26. All22 Rust controls remain, including the two ineligible preinitialized scopes. Every775 latency and182 resource output matches Rust exactly. No sample or outlier is removed. The fastest reference is selected afresh in this cohort. The source SHA is `d70a001620977aff9529884d0207fbf7952a359388988431b4102ae0465f1905`, unchanged from the independently confirmed IR315 source. Four query workers and all preparation, input admission, allocation, worker creation/run/join, internal cleanup and materialization remain within one continuous post-JSON interval.

[Every implementation's timing](ALL-TIMINGS.md) includes restoration and complete-process measurements. The earlier independent IR315 confirmation remains1.675500ms /1.118055× against its own1.498584ms Rust reference. Its ratio cannot be compared directly to the new cohort's ratio to infer a speedup.

## Resources and emitted code

'''+'\n'.join(resource)+f'''

Imported IR317 retires49,933 fewer instructions (−0.155%) than same-source IR315. Allocations and requested/peak additional heap are identical. Cycles change+0.076%; no cycle improvement is claimed. All49 numeric functions remain native. Generated code changes{prior['code_bytes']:,}→{meta['code_bytes']:,} bytes (−2,060), with reported module stack bound unchanged at{meta['stack_bytes']:,} bytes. Executable size changes{exes[b]:,}→{exes[c]:,} bytes. The compiler simplifies291 identity routes and8 loop edges on this source. Other newly imported passes do not fire here, and no savings are attributed to them.

The hot query grows{q['old_code']:,}→{q['code']:,} code bytes while its frame remains{q['stack']} bytes. It has26 identity-route shortcuts but no loop-edge shortcut. Overall text savings come from other bodies. Shorter control flow is not assumed to produce better register allocation or elapsed time.

Instrumented process instructions change{B['process_resources_median']['instructions_retired']:,}→{C['process_resources_median']['instructions_retired']:,}. Peak RSS changes{B['process_resources_median']['peak_resident_bytes']:,}→{C['process_resources_median']['peak_resident_bytes']:,} bytes and lifetime physical footprint{B['process_resources_median']['peak_physical_footprint_bytes']:,}→{C['process_resources_median']['peak_physical_footprint_bytes']:,}. The complete-process median is{cm['wall_seconds']*1000:.6f}ms versus{bm['wall_seconds']*1000:.6f}ms; its paired change is{wp['median_paired_relative_change']*100:+.3f}% [{wp['two_sided_95_interval'][0]*100:+.3f}%, {wp['two_sided_95_interval'][1]*100:+.3f}%]. Whole-process remains visible without an acceptance gate. Raw records retain every restoration/JSON, heap, instruction, cycle and residency field.

## Qualification and profile

All528 selected native compiler contracts pass, retaining all508 parent and484 selected IR308 names. The60 focused cleanup contracts pass. All128 scalar and five DEFLATE rows match every previous non-timing/resource field. The linked executable passes32 exact-output cases and an Object-to-executable byte audit. The actual5000-post source passes original and decoded execution,12 zero-budget denials preserving prior published roots, and12 successful complete retries. Full-source zero-budget probes are not presented as exact-threshold sweeps; the small generic contracts retain exact finite-boundary checks.

Fresh same-Object diagnostic profiles of IR315 and IR317 each complete10,001 invocations with an exact final5000-post output. The compiled query remains the largest active reported leaf, followed by the compiled UTF8 histogram and numeric index loops. Work-escrow locking and worker/frame management remain visible. In IR317 the query has4867 reported leaf samples, the histogram1203, the index at header774 has718, and budget escrow locking583. These are diagnostic sample counts, not additive CPU percentages or estimated latency savings. The repeated loop includes invocation/worker lifecycle and cleanup but excludes repeated input admission/export/materialization. A full-boundary critical-path study remains needed before assigning savings to serial preparation.

Measured compiler commit `{current}` is based on #973 `{base}`. Every{len(sources):,} inventoried compiler/config source matches the qualified compiler; the maintained source is byte-pinned separately. Identity is IR317/work126/ABI42/image11. Cranelift0.131.3 and regalloc2 0.15.2 remain production; LLVM is not required. The unqualified parallel-index prototype remains isolated and is not included in this comparison.

`summary.json` indexes compressed raw observations, source inventories, archive/source reconstruction pins, exact recipes, tests, first failures, executable audits and current profiles. Large repeated output payloads are represented by their exact comparison/result hashes in the retained cohort records; the complete local raw directories are preserved.
'''
import re
report=re.sub(r'(?<=\w)(?=\d)',lambda m:' ' if report[m.start()-1].isalpha() else '',report) if False else report
for x,y in [('all842','all 842'),('first528','first 528'),('passed526','passed 526'),('descriptive95','descriptive 95'),('and18/31','and 18/31'),('The1.00','The 1.00'),('leaves'+f'{gap*1e6:.3f}','leaves '+f'{gap*1e6:.3f}'),('are31','are 31'),('across25','across 25'),('across26','across 26'),('All22','All 22'),('Every775','All 775'),('and182','and 182'),('remains1.675500','remains 1.675500'),('own1.498584','own 1.498584'),('retires49,933','retires 49,933'),('change+0.076','change +0.076'),('All49','All 49'),('simplifies291','simplifies 291'),('and8','and 8'),('has26','has 26'),('All528','All 528'),('all508','all 508'),('and484','and 484'),('The60','The 60'),('All128','All 128'),('passes32','passes 32'),('actual5000','actual 5000'),('execution,12','execution, 12'),('and12','and 12'),('complete10,001','complete 10,001'),('final5000','final 5000'),('has4867','has 4867'),('histogram1203','histogram 1203'),('header774','header 774'),('has718','has 718'),('locking583','locking 583'),('Cranelift0.131.3','Cranelift 0.131.3')]:report=report.replace(x,y)
report=re.sub(r'(?<=\d)(ms|μs)\b',r' \1',report)
report=re.sub(r'\b(changes|change|grows|remains|is|at|Every|versus|footprint)(?=\d)',r'\1 ',report)
(D/'REPORT.md').write_text(report)
for f in files:
 data=gzip.decompress((D/f['path']).read_bytes());assert sha(data)==f['uncompressed_sha256']
print('verified',len(files),'records',sum((D/x['path']).stat().st_size for x in files),'compressed bytes',flush=True)
