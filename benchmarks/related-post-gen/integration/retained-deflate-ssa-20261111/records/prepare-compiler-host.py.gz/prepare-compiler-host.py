from pathlib import Path
import json,subprocess,time,shutil
E=Path(__file__).parent;B=Path('/private/tmp/mech-related-pr990-rebase-evidence-20261111');S=Path('/private/tmp/mech-related-compiler-catchup-20261111')
c=['python3',str(B/'build-cargo-host.py'),'--compiler-build',str(E/'compiler/build.json'),'--source','/private/tmp/mech-related-numeric-owner-handoff-runners-20261108-v2/compiler-facts.rs','--out',str(E/'compiler-host')]
t=time.monotonic();r=subprocess.run(c,capture_output=True,text=True);(E/'compiler-host-run.json').write_text(json.dumps(dict(command=c,exit=r.returncode,seconds=time.monotonic()-t,stdout=r.stdout,stderr=r.stderr),indent=2)+'\n');print('host',r.returncode,flush=True);assert r.returncode==0,r.stderr
p=E/'objects/selected';p.parent.mkdir(exist_ok=True);c=[str(E/'compiler-host'),str(S/'benchmarks/related-post-gen/mech/related_optimized.mec'),str(p)];t=time.monotonic();r=subprocess.run(c,capture_output=True,text=True);(p.parent/'selected-compile.json').write_text(json.dumps(dict(command=c,exit=r.returncode,seconds=time.monotonic()-t,stdout=r.stdout,stderr=r.stderr),indent=2)+'\n');print('selected object',r.returncode,r.stdout[-900:],r.stderr[-2500:],flush=True);assert r.returncode==0
m=json.loads((p/'metadata.json').read_text());print('code',m['code_bytes'],'stack',m['stack_bytes'],'numeric functions',len(m['compiled_numeric_functions']),flush=True)
