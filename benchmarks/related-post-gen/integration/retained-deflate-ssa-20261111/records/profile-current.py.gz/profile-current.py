from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,sys
E=Path(__file__).parent;P=E/'profile';P.mkdir(exist_ok=True);S=Path('/private/tmp/mech-related-compiler-catchup-20261111');B=S/'benchmarks/related-post-gen';OLD=Path('/private/tmp/mech-related-narrow-updates-20261111');INPUT=E/'frozen-inputs/posts.json';ORACLE=E/'frozen-inputs/expected.json';write=lambda p,d:Path(p).write_text(json.dumps(d,indent=2)+'\n')
variants={'ir315':(OLD/'runners/counts-postings32/build',OLD/'runtime/build.json'),'ir317':(E/'runners/selected/build',E/'runtime/build.json')}
def run(c,out):
 c=list(map(str,c));t=time.monotonic();r=subprocess.run(c,capture_output=True,text=True);write(P/(out+'.json'),dict(command=c,exit=r.returncode,seconds=time.monotonic()-t,stdout=r.stdout,stderr=r.stderr));print(out,r.returncode,flush=True);assert r.returncode==0,r.stderr[-5000:];return r
if sys.argv[1]=='build':
 for label,(bundle,build) in variants.items():
  d=P/label;d.mkdir();(d/'build').symlink_to(bundle,target_is_directory=True);shutil.copyfile('/private/tmp/mech-related-numeric-owner-handoff-runners-20261108-v2/histogram-reuse/runner-native-profile.rs',d/'runner.rs')
  run(['python3','/private/tmp/mech-related-pr990-rebase-evidence-20261111/build-cargo-host.py','--compiler-build',build,'--source',d/'runner.rs','--out',d/'runner-profile','--bundle',d/'build','--linked'],label+'-build')
  run(['python3',B/'audit-native-link.py','--object',d/'build/object.o','--executable',d/'runner-profile','--output',d/'same-object-audit.json'],label+'-audit')
else:
 snapshot=subprocess.check_output(['ps','-axo','pid,ppid,comm'],text=True);busy=[]
 for line in snapshot.splitlines()[1:]:
  if any(line.rstrip().endswith('/'+name)for name in ['rustc','cargo','sample','gzip','gpu-tests','engine-tests','one-kib','scalar','runner-aot','runner-metrics']):busy.append(line)
 write(P/'quiet-before-profiles.json',dict(quiet=not busy,busy=busy,snapshot_sha256=hashlib.sha256(snapshot.encode()).hexdigest()));assert not busy
 for label in variants:
  d=P/label;cmd=list(map(str,[d/'runner-profile',d/'build/source.mec',INPUT,d/'output.json','1']));t=time.monotonic()
  with(d/'stdout.txt').open('w')as o,(d/'stderr.txt').open('w')as e:
   proc=subprocess.Popen(cmd,stdout=o,stderr=e);sc=['/usr/bin/sample',str(proc.pid),'10','1','-file',str(d/'native.sample.txt')];sr=subprocess.run(sc,capture_output=True,text=True);code=proc.wait()
  assert sr.returncode==code==0,(code,sr.stderr)
  assert json.loads((d/'output.json').read_text())==json.loads(ORACLE.read_text())
  write(d/'receipt.json',dict(command=cmd,exit=code,seconds=time.monotonic()-t,sampler_command=sc,sampler_exit=sr.returncode,sampler_stdout=sr.stdout,sampler_stderr=sr.stderr,same_Object_audit_passed=True,diagnostic_only=True,promotion_timing_eligible=False,repeated_native_invocations=10001,exact_final5000_output=True,executable_sha256=hashlib.sha256((d/'runner-profile').read_bytes()).hexdigest(),input_sha256=hashlib.sha256(INPUT.read_bytes()).hexdigest(),scope='Repeated evaluate_into includes fresh invocation/worker lifecycle/cleanup; repeated input admission/export/materialization excluded. Inclusive stacks overlap and are not additive CPU/latency shares.'))
  print(label,'fresh diagnostic profile exact final5000',flush=True)
