from pathlib import Path
import json,subprocess,time,hashlib,datetime,importlib.util,os
E=Path(__file__).parent;S=Path('/private/tmp/mech-related-compiler-catchup-20261111');read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert read(E/'qualification/final-ci.json')['exit']==0
assert read(E/'qualification/final-ci.json')['passed']==528
assert read(E/'qualification/cfg-imported-tests.json')['exit']==0
assert all(x['all_non_timing_fields_exact'] for x in read(E/'regressions/comparison.json'))
assert len(read(E/'selected-qualification/summary.json'))==2
for n in ['all-retained-map-contracts','image-and-caller-geometry','classification-UTF8-range-protocol','packed-frame-effects']:assert read(E/'qualification'/(n+'.json'))['exit']==0
for n in ['audit-run','actual5000','edge-run']:assert read(E/'runners/selected'/(n+'.json'))['exit']==0
sp=importlib.util.spec_from_file_location('i',S/'benchmarks/related-post-gen/build-compiler.py');i=importlib.util.module_from_spec(sp);sp.loader.exec_module(i);files=i.source_inventory(S)
for n in ['compiler','runtime','tests']:assert read(E/n/'source-inventory.json')['files']==files,n
assert subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True)==''
Q=E/'first';Q.mkdir(exist_ok=False);rule=read(E/'prospective-rule.json');configs={k:E/(k+'-config-frozen.json')for k in ['latency','resources']}
for config in configs.values():
 for v in read(config)['implementations']:
  for field in ['executable','source','receipt']:
   if field in v:assert sha(v[field])==v[field+'_sha256'],(v['name'],field)
(Q/'source-freeze.json').write_text(json.dumps(dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip(),base='d09e3a4b78126b888e241599752b13a514e089d7',compiler_source_sha256=read(E/'compiler/build.json')['source_sha256'],input_sha256=sha(E/'frozen-inputs/posts.json'),configs_sha256={k:sha(v)for k,v in configs.items()},rule_sha256=sha(E/'prospective-rule.json'),qualified_contracts=528,all508_parent_names_retained=True,UTC=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n')
for kind,n,seed in [('latency',31,rule['seed']),('resources',7,rule['resource_seed'])]:
 snapshot=subprocess.check_output(['ps','-axo','pid,ppid,comm'],text=True);busy=[]
 for l in snapshot.splitlines()[1:]:
  a=l.split(None,2)
  if len(a)!=3 or int(a[0])in[os.getpid(),os.getppid()]:continue
  if a[2].rsplit('/',1)[-1]in['rustc','cargo','clang','clang++','sample','gzip','xz','zstd','gpu-tests','engine-tests','one-kib','scalar','runner-aot','runner-metrics','runner-profile','runner-qualify']:busy.append(a)
 (Q/(kind+'-quiet.json')).write_text(json.dumps(dict(no_build_test_profile_archive_overlap=not busy,busy=busy,snapshot_sha256=hashlib.sha256(snapshot.encode()).hexdigest()),indent=2)+'\n');assert not busy,busy
 c=['python3','/Users/cim310/mech-lang/mech/benchmarks/related-post-gen/compare-implementations.py','--config',str(configs[kind]),'--input',str(E/'frozen-inputs/posts.json'),'--samples',str(n),'--order','randomized','--seed',str(seed),'--deduplicate-outputs','--work',str(Q/kind),'--output',str(Q/(kind+'.json'))]
 if kind=='resources':c.append('--resources')
 t=time.monotonic();r=subprocess.run(c,capture_output=True,text=True);(Q/(kind+'-run.json')).write_text(json.dumps(dict(command=c,exit=r.returncode,seconds=time.monotonic()-t,stdout=r.stdout,stderr=r.stderr),indent=2)+'\n');print(kind,r.returncode,round(time.monotonic()-t,2),flush=True);assert r.returncode==0,r.stderr[-3000:]
