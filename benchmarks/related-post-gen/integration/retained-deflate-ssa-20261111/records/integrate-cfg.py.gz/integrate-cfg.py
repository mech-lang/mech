from pathlib import Path
import shutil,json,hashlib
E=Path(__file__).parent;S=Path('/private/tmp/mech-related-compiler-catchup-20261111');R=E/'deflate-r304-source';rel=Path('hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup');src=R/rel;dst=S/rel
names=['adjacent_addresses.rs','current_predicates.rs','current_predicates','identity_routes','threaded_edges','window_bounds.rs','window_bounds','word_ranges/condition.rs','word_ranges/mod.rs','boolean_words.rs']
records=[]
for name in names:
 p=src/name;q=dst/name
 if p.is_dir():shutil.copytree(p,q)
 else:q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
 for f in ([p]if p.is_file()else p.rglob('*')):
  if f.is_file():records.append(dict(path=str(f.relative_to(R)),sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
p=dst/'word_ranges/mod.rs';t=p.read_text();needle='    pub fn value_range(&mut self, value: Value) -> Option<Range> {';assert needle in t;t=t.replace(needle,'''    pub fn canonical_boolean(&mut self, value: Value) -> bool {
        self.range(value, MAX_DEPTH).is_some_and(|range| range.1 <= 1)
    }

'''+needle);p.write_text(t)
p=dst/'mod.rs';t=p.read_text();t=t.replace('mod boolean_words;','mod adjacent_addresses;\nmod current_predicates;\nmod identity_routes;\nmod threaded_edges;\nmod window_bounds;\nmod boolean_words;');t=t.replace('Function, InstBuilder, InstructionData, Opcode, Value, ValueDef, condcodes::IntCC,','Block, Function, InstBuilder, InstructionData, Opcode, Value, ValueDef, condcodes::IntCC,')
needle='    optimize_ordered(controls, context, isa, true)';assert t.count(needle)==1;t=t.replace(needle,'''    let mut report = optimize_ordered(controls, context, isa, true)?;
    finish_imported_passes(controls, context, isa, &mut report)?;
    Ok(report)''')
fields=['current_predicate_branches','identity_edges','loop_edges','bitwise_constant_branches','window_bounds_combined','ordered_capture_spans','adjacent_addresses_reused']
needle='        known_width_branches_removed: 0,';assert needle in t;t=t.replace(needle,needle+'\n'+''.join('        '+f+': 0,\n'for f in fields).rstrip())
# Keep the existing cleanup and unsigned-guard ordering. Imported wrapper
# cleanup uses the existing core only, so the late pass pipeline cannot recurse.
extra=(src/'mod.rs').read_text().split('pub(in crate::native_artifact) fn forward_identity_routes(',1)[1]
extra='pub(in crate::native_artifact) fn forward_identity_routes('+extra
extra=extra.replace('        optimize(controls, context, isa)?;', '        optimize_ordered(controls, context, isa, true)?;')
# Each import has an independent emission-only ablation while CfgCleanup
# continues to disable all structural transformations.
for fn,opt in [('forward_identity_routes_from','IdentityRoutes'),('refine_current_predicates','CurrentPredicates'),('fold_proved_widths','ProvedWordWidths'),('fold_ordered_capture_spans','OrderedCaptureSpans'),('reuse_adjacent_addresses','AdjacentAddresses'),('combine_window_bounds','FixedWindowBounds'),('thread_loop_edges','LoopEdgeThreading')]:
 start=extra.index(' fn '+fn+'(');at=extra.index('if !controls.enabled(OptimizationPass::CfgCleanup)',start);extra=extra[:at]+extra[at:].replace('if !controls.enabled(OptimizationPass::CfgCleanup)', 'if !controls.enabled(OptimizationPass::CfgCleanup) || !controls.enabled(OptimizationPass::'+opt+')',1)
t+='\n'+extra+'''
/// Run retained DEFLATE SSA passes after the ordinary checked numeric guard
/// proofs. They consume immutable machine words, never runtime permissions.
pub(in crate::native_artifact) fn finish_imported_passes(
    controls: &CompilationControls,
    context: &mut Context,
    isa: &dyn TargetIsa,
    report: &mut CfgCleanup,
) -> Result<(), NativeCompileError> {
    if !report.enabled { return Ok(()); }
    if controls.enabled(OptimizationPass::ScopedBitwiseConstants) {
        let changed = fold_bitwise_constants(controls, &mut context.func);
        report.bitwise_constant_branches += changed;
        if changed != 0 { optimize_ordered(controls, context, isa, true)?; }
    }
    report.loop_edges += thread_loop_edges(controls, context, isa)?.threaded_edges;
    report.identity_edges += forward_identity_routes(controls, context, isa)?.threaded_edges;
    report.current_predicate_branches += refine_current_predicates(controls, context, isa)?.removed_branches;
    report.known_width_branches_removed += fold_proved_widths(controls, context, isa)?;
    report.window_bounds_combined += combine_window_bounds(controls, context, isa)?;
    report.ordered_capture_spans += fold_ordered_capture_spans(controls, context, isa)?;
    report.adjacent_addresses_reused += reuse_adjacent_addresses(controls, context, isa)?;
    (report.after_blocks, report.after_instructions) = counts(&context.func);
    Ok(())
}

fn fold_bitwise_constants(controls: &CompilationControls, function: &mut Function) -> usize {
    if !controls.enabled(OptimizationPass::CfgCleanup) { return 0; }
    let mut facts = word_ranges::Facts::with_bitwise_constants(function);
    let changes = function.layout.blocks().filter_map(|block| {
        let inst = function.layout.last_inst(block)?;
        let InstructionData::Brif {arg,blocks,..} = &function.dfg.insts[inst] else {return None;};
        let selected = &blocks[usize::from(!facts.condition(*arg)?)];
        Some((inst,selected.block(&function.dfg.value_lists),selected.args(&function.dfg.value_lists).collect::<Vec<_>>()))
    }).collect::<Vec<_>>();
    for (inst,target,args) in &changes {function.dfg.replace(*inst).jump(*target,args);}
    changes.len()
}
''';p.write_text(t)
p=S/'hosts/gpu/src/native_artifact/codegen/control/report/mod.rs';t=p.read_text();needle='    pub known_width_branches_removed: usize,';assert needle in t;t=t.replace(needle,needle+'\n'+''.join('    pub '+f+': usize,\n'for f in fields).rstrip());p.write_text(t)
p=S/'hosts/gpu/src/native_artifact/codegen/options.rs';t=p.read_text();needle='    ProvedWordWidths,';assert needle in t;t=t.replace(needle,needle+'''
    /// Retained DEFLATE structural SSA passes; every option is emission-only.
    CurrentPredicates,
    IdentityRoutes,
    LoopEdgeThreading,
    ScopedBitwiseConstants,
    FixedWindowBounds,
    OrderedCaptureSpans,
    AdjacentAddresses,''');p.write_text(t)
p=S/'hosts/gpu/src/native_artifact/program/codegen/numeric_region_outlined.rs';t=p.read_text();needle='        let header = region.tail.header() as usize;';assert t.count(needle)==1;t=t.replace(needle,'''        crate::native_artifact::program::codegen::cfg_cleanup::finish_imported_passes(
            controls, &mut context, module.isa(), &mut cleanup,
        )?;
'''+needle);p.write_text(t)
p=S/'hosts/gpu/src/native_artifact/program/image/identity.rs';t=p.read_text();assert '= 315;'in t;t=t.replace('= 315;','= 317;');p.write_text(t)
(E/'cfg-import-provenance.json').write_text(json.dumps(dict(source_round=304,closure_verified_files=842,imported_sources=records,preserved='IR315 leaf/tree lowering, guard ordering, early identities, Boolean conditions, current narrow-write proofs and finite ledgers',experimental_compact_entry_imported=False),indent=2)+'\n')
print('imported',len(records),'verified module files')
