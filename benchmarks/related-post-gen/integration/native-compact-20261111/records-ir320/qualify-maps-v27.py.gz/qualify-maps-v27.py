from pathlib import Path
import subprocess,json,time,hashlib
E=Path(__file__).parent;D=E/'maps-v27/all';rustc='/Users/cim310/.rustup/toolchains/nightly-2026-03-03-aarch64-apple-darwin/bin/rustc'
for label in ['original','decoded']:
 for fixture in ['maps-native-check','maps-native-index-check']:
  out=D/(label+'-'+fixture);c=[rustc,'--edition=2024','-C','opt-level=3','-C',f'link-arg={D/(label+".o")}',str(E/(fixture+'.rs')),'-o',str(out)];t=time.monotonic();r=subprocess.run(c,capture_output=True,text=True);(out.with_suffix('.link.json')).write_text(json.dumps(dict(command=c,exit=r.returncode,seconds=time.monotonic()-t,stdout=r.stdout,stderr=r.stderr),indent=2)+'\n');assert r.returncode==0,r.stderr
  t=time.monotonic();r=subprocess.run([str(out)],capture_output=True,text=True);(out.with_suffix('.run.json')).write_text(json.dumps(dict(command=[str(out)],exit=r.returncode,seconds=time.monotonic()-t,stdout=r.stdout,stderr=r.stderr,qualification_only=True,object_sha256=hashlib.sha256((D/(label+'.o')).read_bytes()).hexdigest()),indent=2)+'\n');print(label,fixture,r.returncode,r.stdout,r.stderr[-2000:],flush=True);assert r.returncode==0
