use mech_gpu::native_artifact::compact_runtime as arrays;
use std::collections::BTreeMap;
#[repr(C)]#[derive(Debug)]struct Status{status:u64,origin:u64}
unsafe extern "C"{fn mech_compact_closed_v2(heap:*mut std::ffi::c_void,input:*const u64,output:*mut u64)->Status;}
unsafe fn numbers(view:&[u64])->Vec<u64>{assert_eq!(view[3],1);assert_eq!(view[1],view[4]);if view[1]==0{vec![]}else{unsafe{std::slice::from_raw_parts(view[0]as*const u64,view[1]as usize).to_vec()}}}
fn main(){
 let args:Vec<_>=std::env::args().skip(1).collect();let metadata:serde_json::Value=serde_json::from_str(&std::fs::read_to_string(&args[0]).unwrap()).unwrap();let m=&metadata["metadata"];let kind=&args[1];
 assert!(!m["native_string_classes"].as_array().unwrap().is_empty());let read_site=m["native_string_classes"][0]["lookups"][0]["read_site"].as_u64().unwrap();
 let mut dictionary=vec!["".to_owned(),"é".into(),"e\u{301}".into(),"🦀".into(),"x\0y".into()];dictionary.extend((0..257).map(|i|format!("{}{:04}東京", "a".repeat(i%67),i)));
 let mut cases=0;let mut errors=0;
 for count in [0,1,2,3,7,16,31,64,129,512,2000]{for mode in 0..3{for key in ["","é","missing"]{
  let tags=(0..count).map(|i|if mode==2{key}else{dictionary[if mode==1{i%dictionary.len()}else{(i*37+i/3)%dictionary.len()}].as_str()}).collect::<Vec<_>>();
  let spans=tags.iter().map(|s|[s.as_ptr()as u64,s.len()as u64]).collect::<Vec<_>>();let view=[spans.as_ptr()as u64,count as u64,count as u64,1,count as u64,0];let mut input=vec![0u64;m["input_words"].as_u64().unwrap()as usize];
  for port in m["inputs"].as_array().unwrap(){let offset=port["input_offset"].as_u64().unwrap()as usize;match port["name"].as_str().unwrap(){"mech-source-input-74616773"=>input[offset..offset+6].copy_from_slice(&view),"mech-source-input-6b6579"=>input[offset..offset+2].copy_from_slice(&[key.as_ptr()as u64,key.len()as u64]),n=>panic!("unexpected input {n}")}}
  let expected=tags.iter().fold(BTreeMap::<&str,u64>::new(),|mut h,k|{*h.entry(k).or_default()+=1;h});let mut heap=arrays::Heap::new();let sentinel=0xdadacafef00d1234u64;let mut output=vec![sentinel;m["output_words"].as_u64().unwrap()as usize];
  let status=unsafe{mech_compact_closed_v2((&mut heap as*mut arrays::Heap).cast(),input.as_ptr(),output.as_mut_ptr())};
  if kind=="missing"&&tags.iter().any(|s|*s!=key){assert_eq!(status.status,0x19501);assert_eq!(status.origin,read_site);assert!(output.iter().all(|v|*v==sentinel));errors+=1;}
  else{assert_eq!(status.status,0,"{status:?}, count={count}, mode={mode}, key={key:?}");let expected_counts=tags.iter().map(|s|expected[s]).collect::<Vec<_>>();let actual=unsafe{numbers(&output[..6])};if kind=="missing"{assert_eq!(actual,vec![17;count]);}else{assert_eq!(actual,expected_counts);if kind=="two-maps"{assert_eq!(unsafe{numbers(&output[6..12])},tags.iter().map(|s|if *s==key{17}else{expected[s]}).collect::<Vec<_>>());}}}
  heap.discard_private();assert_eq!(heap.counters.live_payload_bytes,0);cases+=1;
 }}}
 println!("{kind}: {cases} exact native class cases, {errors} missing-key errors with original origin and untouched output; all backing reclaimed");
}
