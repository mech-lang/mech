from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,time,sys
E=Path(__file__).parent;B=Path('/private/tmp/mech-related-pr990-rebase-evidence-20261111');S=Path('/private/tmp/mech-related-compact-native-development-20261111');OLD='/private/tmp/mech-related-pr990-rebase-20261111';spec=importlib.util.spec_from_file_location('gpu_command',B/'cargo-gpu-command.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);base=json.loads((B/'cargo-patched-compiler/build.json').read_text());spec=importlib.util.spec_from_file_location('inventory',S/'benchmarks/related-post-gen/build-compiler.py');i=importlib.util.module_from_spec(spec);spec.loader.exec_module(i)
def build(label):
 test=label.startswith('tests');runtime=label.startswith('runtime');d=E/label;d.mkdir(exist_ok=False);out=d/('gpu-tests'if test else'libmech_gpu.rlib');files=i.source_inventory(S);prior=json.loads((B/'cargo-patched-compiler/source-inventory.json').read_text())['files'];changed=[k for k in set(files)|set(prior)if files.get(k)!=prior.get(k)];assert all(k.startswith('hosts/gpu/')for k in changed),changed;h=hashlib.sha256(json.dumps(files,sort_keys=True).encode()).hexdigest();inv=dict(root=str(S),files=files,sha256=h);(d/'source-inventory.json').write_text(json.dumps(inv,indent=2)+'\n')
 c,e=m.command(base,out,test=test,runtime=runtime);c=[arg.replace(OLD,str(S)).replace('related_312_', 'related_320_native_compact_')for arg in c];e={k:v.replace(OLD,str(S))for k,v in e.items()};t=time.monotonic();r=subprocess.run(c,cwd=S,env={**os.environ,**e},capture_output=True,text=True);receipt=dict(command=c,environment=e,exit=r.returncode,seconds=time.monotonic()-t,stdout=r.stdout,stderr=r.stderr,source_sha256=h);(d/'compile.json').write_text(json.dumps(receipt,indent=2)+'\n');print(label,r.returncode,round(receipt['seconds'],2),flush=True)
 if r.returncode:print(r.stderr[-9000:],flush=True)
 assert r.returncode==0;assert files==i.source_inventory(S)
 if not test:
  import shutil
  runtime_sources=S/'hosts/gpu/src/native_artifact/compact_runtime'
  if runtime_sources.is_dir():shutil.copytree(runtime_sources,d/'compact-runtime')
  b=json.loads(json.dumps(base));b.update(source=str(S),source_sha256=h,source_inventory_sha256=hashlib.sha256((d/'source-inventory.json').read_bytes()).hexdigest(),reused_non_GPU_packages_source_identical=True);g=b['stages'][-1];g.update(command=c,environment=e,exit=0,seconds=receipt['seconds'],stdout=r.stdout,stderr=r.stderr,library_path=str(out),library_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),source_sha256=h,runtime_only=runtime,reused=False);(d/'build.json').write_text(json.dumps(b,indent=2)+'\n')
if __name__=='__main__':
 for label in sys.argv[1:]or ['compiler','runtime','tests']:build(label)
