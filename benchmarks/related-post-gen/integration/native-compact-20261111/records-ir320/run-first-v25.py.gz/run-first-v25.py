from pathlib import Path
import subprocess,json,time,hashlib,importlib.util
E=Path(__file__).parent;S=Path('/private/tmp/mech-related-compact-native-development-20261111');D=E/'first-v25'
for kind in ['latency','resources']:
 p=D/f'{kind}-config.json';config=json.loads(p.read_text());config['primary_timing_metric']='post_json';p.write_text(json.dumps(config,indent=2)+'\n')
# Check the summary policy on retained data without rerunning any executable.
spec=importlib.util.spec_from_file_location('compare',S/'benchmarks/related-post-gen/compare-implementations.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
r=json.loads((E/'first-v17/latency-complete.json').read_text());r['primary_timing_metric']='post_json';m.add_timing_comparisons(r);assert r['primary_metric']=='post_json_over_fastest_matched_native' and r['primary_reference']==r['matched_native_reference'];r['primary_timing_metric']='whole_process';m.add_timing_comparisons(r);assert r['primary_metric']=='whole_process_over_fastest'
(D/'timing-policy-check.json').write_text(json.dumps(dict(default_whole_process_preserved=True,explicit_post_json_policy=True,retained_data_only=True),indent=2)+'\n')
for kind,samples,seed in [('latency',31,202611111725),('resources',7,202611111726)]:
 ps=subprocess.run(['ps','-axo','pid=,pcpu=,comm='],capture_output=True,text=True);busy=[line for line in ps.stdout.splitlines()if any(name in line.split()[-1]for name in ['rustc','cargo','gpu-tests','xctrace','/sample'])];(D/f'{kind}-quiet.json').write_text(json.dumps(dict(quiet=not busy,busy=busy,snapshot_sha256=hashlib.sha256(ps.stdout.encode()).hexdigest()),indent=2)+'\n');assert not busy,busy
 c=['python3',str(S/'benchmarks/related-post-gen/compare-implementations.py'),'--config',str(D/f'{kind}-config.json'),'--input','/private/tmp/mech-related-narrow-updates-20261111/frozen-inputs/posts.json','--samples',str(samples),'--order','randomized','--seed',str(seed),'--deduplicate-outputs','--work',str(D/kind),'--output',str(D/f'{kind}.json')]
 if kind=='resources':c+=['--resources']
 t=time.monotonic()
 with (D/f'{kind}-stdout.txt').open('w')as out,(D/f'{kind}-stderr.txt').open('w')as err:r=subprocess.run(c,stdout=out,stderr=err)
 row=dict(command=c,exit=r.returncode,seconds=time.monotonic()-t);(D/f'{kind}-run.json').write_text(json.dumps(row,indent=2)+'\n');print(kind,json.dumps(row),flush=True);assert r.returncode==0
