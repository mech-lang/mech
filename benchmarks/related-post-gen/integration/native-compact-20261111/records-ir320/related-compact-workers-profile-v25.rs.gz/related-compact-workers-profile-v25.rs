//! JSON, typed borrowed input spans, native invocation and Related materialization.
//! All tag interning, indexing, scoring and selection execute in the linked Object.
use mech_gpu::native_artifact::compact_runtime as arrays;
use serde::{Deserialize, Serialize};
use std::{fs::File,io::BufWriter,time::Instant};
#[repr(C)] #[derive(Debug)] struct Status { status:u64, origin:u64 }
unsafe extern "C" { fn mech_compact_closed_v2(heap:*mut std::ffi::c_void,input:*const u64,output:*mut u64)->Status; }
#[derive(Deserialize,Serialize)] struct Post { #[serde(rename="_id")] id:String,title:String,tags:Vec<Box<str>> }
#[derive(Serialize)] struct Related<'a> { #[serde(rename="_id")] id:&'a str,tags:&'a [Box<str>],related:[&'a Post;5] }
fn run(){
    let args:Vec<_>=std::env::args().skip(1).collect();assert_eq!(args.len(),4,"runner SOURCE POSTS OUTPUT SAMPLES");
    assert_eq!(args[3],"1");
    assert_eq!(std::fs::read_to_string(&args[0]).unwrap(),include_str!("exact-source-v16/source.mec"));
    let json=Instant::now();let posts:Vec<Post>=serde_json::from_str(&std::fs::read_to_string(&args[1]).unwrap()).unwrap();assert!(!posts.is_empty());
    let json_seconds=json.elapsed().as_secs_f64();for profile_round in 0..5001 {let start=Instant::now();
    let tag_count=posts.iter().try_fold(0usize,|n,p|n.checked_add(p.tags.len())).unwrap();
    let mut offsets=Vec::<u64>::with_capacity(posts.len()+1);offsets.push(0);
    let mut tags=Vec::<[u64;2]>::with_capacity(tag_count);
    for p in &posts {for t in &p.tags{tags.push([t.as_ptr()as u64,t.len()as u64]);}offsets.push(tags.len()as u64);}
    let offset_view=[offsets.as_ptr()as u64,offsets.len()as u64,offsets.len()as u64,1,offsets.len()as u64,0];
    let tag_view=[tags.as_ptr()as u64,tags.len()as u64,tags.len()as u64,1,tags.len()as u64,0];
    let mut input=[0u64;12];
    // Generated from the exact current typed input inventory by the build script.
    include!("related-compact-input-order.rs");
    let admission_seconds=start.elapsed().as_secs_f64();
    let mut heap=arrays::Heap::new();let mut output=[0u64;6];let native_start=Instant::now();
    let status=unsafe{mech_compact_closed_v2((&mut heap as *mut arrays::Heap).cast(),input.as_ptr(),output.as_mut_ptr())};
    assert_eq!(status.status,0,"native failure {status:?}");
    let native_seconds=native_start.elapsed().as_secs_f64();
    assert_eq!(output[1],(posts.len()*5)as u64);let indices=unsafe{std::slice::from_raw_parts(output[0]as*const u64,output[1]as usize)};
    let related=posts.iter().zip(indices.chunks_exact(5)).map(|(p,top)|Related{id:&p.id,tags:&p.tags,related:std::array::from_fn(|i|&posts[usize::try_from(top[i]).unwrap()])}).collect::<Vec<_>>();
    std::hint::black_box(&related);
    let requests=heap.counters.payload_requests;let requested=heap.counters.requested_payload_bytes;let peak=heap.counters.peak_payload_bytes;
    let workers=heap.parallel_peak_workers.max(1);let batches=heap.parallel_batches;let parallel_peak_upper=heap.counters.parallel_peak_payload_upper_bound;
    heap.discard_private();assert_eq!(heap.counters.live_payload_bytes,0);drop(heap);drop(tags);drop(offsets);
    let seconds=start.elapsed().as_secs_f64();
    if profile_round == 5000 {
    println!("{}",serde_json::json!({"posts":posts.len(),"sample":0,"post_json_seconds":seconds,"seconds":native_seconds,"input_admission_seconds":admission_seconds,"json_read_and_parse_seconds":json_seconds,"native_payload_requests":requests,"native_requested_payload_bytes":requested,"native_root_peak_payload_bytes":peak,"native_parallel_peak_payload_upper_bound":parallel_peak_upper,"parallel_peak_workers":workers,"parallel_batches":batches,"contract":"compact/unmetered typed native entry; arithmetic and indexing checked","post_json_boundary":"after JSON decoding through typed span preparation, native invocation, RelatedPosts materialization, native heap cleanup and preparation buffer destruction; JSON serialization outside interval"}));
    serde_json::to_writer(BufWriter::new(File::create(&args[2]).unwrap()),&related).unwrap();
    }
    }
}
fn main(){std::thread::Builder::new().stack_size(32*1024*1024).spawn(run).unwrap().join().unwrap();}
