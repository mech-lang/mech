#[path = "/private/tmp/mech-related-compact-native-development-evidence-20261111/r308/evidence/scratch/array-runtime.rs"]
mod arrays;
use std::collections::BTreeMap;
#[repr(C)] #[derive(Debug)] struct Status { status:u64, origin:u64 }
unsafe extern "C" { fn mech_compact_closed_v2(heap:*mut arrays::Heap,input:*const u64,output:*mut u64)->Status; }
unsafe fn strings(view:&[u64])->Vec<String> {
    assert_eq!(view[3],1);assert_eq!(view[1],view[4]);
    (0..view[1] as usize).map(|i|unsafe {
        let p=(view[0] as *const u64).add(i*2);
        String::from_utf8(std::slice::from_raw_parts(*p as *const u8,*p.add(1) as usize).to_vec()).unwrap()
    }).collect()
}
unsafe fn numbers(view:&[u64])->Vec<u64> {assert_eq!(view[3],1);assert_eq!(view[1],view[4]);if view[1]==0 {vec![]}else{unsafe{std::slice::from_raw_parts(view[0]as*const u64,view[1]as usize).to_vec()}}}
fn main(){
    let dictionary=["", "a", "aa", "aaaaaaaab", "aaaaaaaac", "e\u{301}", "é", "🦀", "x\0y", "\r\n", "z"];
    let mut cases=0;
    for size in [0,1,2,7,11,31,129,1000] {
        let tags=(0..size).map(|i|dictionary[(i*37+i/3)%dictionary.len()]).collect::<Vec<_>>();
        let spans=tags.iter().flat_map(|s|[s.as_ptr()as u64,s.len()as u64]).collect::<Vec<_>>();
        let mut expected=BTreeMap::<String,u64>::new();for s in &tags{*expected.entry((*s).into()).or_default()+=1;}
        for key in dictionary.into_iter().chain(["missing","aaaaaaaad","🦀x"]) {
            for value in [0,17,u64::MAX] {
                let input=[spans.as_ptr()as u64,size as u64,size as u64,1,size as u64,0,key.as_ptr()as u64,key.len()as u64,value];
                let mut heap=arrays::Heap::new();let mut output=[0xdadacafef00d1234u64;28];
                let status=unsafe{mech_compact_closed_v2(&mut heap,input.as_ptr(),output.as_mut_ptr())};
                assert_eq!(status.status,0,"{status:?},size={size},key={key:?}");
                let mut updated=expected.clone();updated.insert(key.into(),value);
                let actual=unsafe{(strings(&output[0..6]),numbers(&output[6..12]),strings(&output[12..18]),numbers(&output[18..24]))};
                assert_eq!(actual.0,expected.keys().cloned().collect::<Vec<_>>());assert_eq!(actual.1,expected.values().copied().collect::<Vec<_>>());
                assert_eq!(actual.2,updated.keys().cloned().collect::<Vec<_>>());assert_eq!(actual.3,updated.values().copied().collect::<Vec<_>>());
                assert_eq!(output[24],*expected.get(key).unwrap_or(&0));assert_eq!(&output[25..28],&[1,value,value]);
                heap.discard_private();assert_eq!(heap.counters.live_payload_bytes,0);cases+=1;
            }
        }
    }
    println!("{cases} exact native histogram/alias/insertion/projection/lookup/membership cases, all backing reclaimed");
}
