from pathlib import Path
import json,subprocess,os,time,sys
E=Path(__file__).parent;S=Path('/private/tmp/mech-related-compact-native-development-20261111');version=sys.argv[1]
def run(c,path,env=None):
 t=time.monotonic();r=subprocess.run(list(map(str,c)),capture_output=True,text=True,env=env);path.write_text(json.dumps(dict(command=list(map(str,c)),exit=r.returncode,seconds=time.monotonic()-t,stdout=r.stdout,stderr=r.stderr),indent=2)+'\n');print(path.name,r.returncode,r.stdout[-3500:],r.stderr[-3500:],flush=True);assert r.returncode==0
run(['python3','/private/tmp/mech-related-pr990-rebase-evidence-20261111/build-cargo-host.py','--compiler-build',E/f'compiler-{version}/build.json','--source','/private/tmp/mech-related-checked-compact-20261111/compact-probe.rs','--out',E/f'compact-probe-{version}'],E/f'probe-{version}-build-run.json')
flags=dict(v.split('=',1)for v in json.loads((E/('r314/evidence/flags.json' if int(version[1:])>=30 else 'r308/evidence/flags.json')).read_text()));flags['MECH_COMPACT_FAILURE_DIR']=str(E/f'native-failure-{version}');flags.update({'MECH_SHARE_REPEATED_BOUNDS':'1'} if int(version[1:])>=26 else {});(E/f'flags-{version}.json').write_text(json.dumps(flags,indent=2)+'\n')
for source,d in [(S/'benchmarks/related-post-gen/mech/related_optimized.mec',E/f'exact-source-{version}'),(E/'maps-v12/all.mec',E/f'maps-{version}/all'),(E/'maps-v15/get.mec',E/f'maps-{version}/get'),(E/'r308/evidence/witness/dot-product.mec',E/f'r308-witness-{version}')]:
 d.parent.mkdir(exist_ok=True,parents=True);run([E/f'compact-probe-{version}',source,d],d.with_suffix('.run.json'),{**os.environ,**flags})
