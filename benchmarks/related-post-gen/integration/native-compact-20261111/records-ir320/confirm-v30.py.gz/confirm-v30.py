"""Independent fresh-process orchestration; does not import the cohort harness."""
from pathlib import Path
import json,subprocess,hashlib,random,statistics,time,re,shutil,os
E=Path(__file__).parent;D=E/'independent-v30';D.mkdir(exist_ok=False);config=json.loads((E/'first-v30/latency-config.json').read_text());variants=config['implementations'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();posts=Path('/private/tmp/mech-related-narrow-updates-20261111/frozen-inputs/posts.json');shutil.copy2(posts,D/'posts.json');gold=json.loads(Path('/private/tmp/mech-related-compiler-catchup-evidence-20261111/runners/selected/output.json').read_text());names={v['name']:v for v in variants};rng=random.Random(202611112245);orders=[]
for i in range(13):
 order=list(names);rng.shuffle(order);orders.append(order)
ps=subprocess.run(['ps','-axo','pid=,pcpu=,comm='],capture_output=True,text=True);busy=[l for l in ps.stdout.splitlines()if any(n in l.split()[-1]for n in ['rustc','cargo','gpu-tests','one-kib','xctrace','/sample'])];assert not busy,busy
pins=[{**v,'executable_sha256':sha(v['executable'])}for v in variants];(D/'prospective-rule.json').write_text(json.dumps(dict(independent_orchestration=True,seed=202611112245,rounds=orders,implementations=pins,input_sha256=sha(posts),primary='continuous post_json including setup and worker lifecycle; no whole-process acceptance gate',acceptance='candidate median <= fastest eligible fresh native median; all observations retained and outputs exact',quiet_snapshot_sha256=hashlib.sha256(ps.stdout.encode()).hexdigest()),indent=2)+'\n');records=[];objects=D/'output-objects';objects.mkdir();start=time.monotonic()
for sample,order in enumerate(orders):
 for name in order:
  v=names[name];assert sha(v['executable'])==v['executable_sha256'];out=D/f'{name}-{sample}.json'
  if v['kind']=='mech':c=[v['executable'],v['source'],str(posts),str(out),'1'];cwd=D
  else:
   cwd=D/name;cwd.mkdir(exist_ok=True);out=D/v['output'];out.unlink(missing_ok=True);c=[v['executable'],*v.get('arguments',[])]
  t=time.monotonic();r=subprocess.run(c,cwd=cwd,capture_output=True,text=True,timeout=180);wall=time.monotonic()-t;row=dict(sample=sample,variant=name,command=c,cwd=str(cwd),exit=r.returncode,wall_seconds=wall,stdout=r.stdout,stderr=r.stderr);records.append(row);(D/'partial.json').write_text(json.dumps(records,indent=2)+'\n');assert r.returncode==0,row
  actual=json.loads(out.read_text());assert actual==gold,(name,sample);row['exact_full_output']=True;row['output_sha256']=sha(out);blob=objects/(row['output_sha256']+'.json')
  if not blob.exists():shutil.copy2(out,blob);blob.chmod(0o444)
  retained=D/f'{name}-{sample}.output.json';os.link(blob,retained)
  if v['kind']=='mech':data=json.loads(next(l for l in r.stdout.splitlines()if l.startswith('{')));row['post_json_seconds']=data['post_json_seconds']
  else:
   match=re.search(r'Processing time .*:\s*([0-9.]+)\s*(ns|µs|us|ms|s)',r.stdout);assert match,r.stdout
   row['seconds']=float(match[1])*{'ns':1e-9,'µs':1e-6,'us':1e-6,'ms':1e-3,'s':1}[match[2]]
   if v.get('calculation_boundary')=='post_json_including_setup':row['post_json_seconds']=row['seconds']
  (D/'partial.json').write_text(json.dumps(records,indent=2)+'\n')
summary={}
for name,v in names.items():
 rows=[r for r in records if r['variant']==name];s=dict(samples=len(rows),all_exact=all(r['exact_full_output']for r in rows),median_whole_process_seconds=statistics.median(r['wall_seconds']for r in rows))
 if v.get('calculation_boundary')=='post_json_including_setup':s['median_post_json_seconds']=statistics.median(r['post_json_seconds']for r in rows)
 summary[name]=s
eligible=[n for n,v in names.items()if v['kind']!='mech'and v.get('calculation_boundary')=='post_json_including_setup'];reference=min(eligible,key=lambda n:summary[n]['median_post_json_seconds']);baseline=summary[reference]['median_post_json_seconds'];candidate='mech-ir320-compact-native-4';ratio=summary[candidate]['median_post_json_seconds']/baseline
report=dict(schema='mech.independent-related-native-confirmation.v1',independent_orchestration=True,seed=202611112245,rounds=13,implementations=pins,execution_order=orders,samples=records,summary=summary,fastest_eligible_native=reference,reference_post_json_ms=baseline*1000,candidate=candidate,candidate_post_json_ms=summary[candidate]['median_post_json_seconds']*1000,times_fastest_eligible_native=ratio,all312_outputs_exact=len(records)==312 and all(r['exact_full_output']for r in records),target_met=ratio<=1,seconds=time.monotonic()-start,limitations=['Shared development machine; confirmation uses a separately implemented orchestration and unchanged pinned adapters.'])
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k not in ['implementations','execution_order','samples','summary']},indent=2));assert report['target_met']and report['all312_outputs_exact']
