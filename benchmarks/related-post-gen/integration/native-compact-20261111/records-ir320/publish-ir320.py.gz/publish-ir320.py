from pathlib import Path
import gzip
import hashlib
import json
import statistics
import subprocess

E = Path(__file__).parent
S = Path('/private/tmp/mech-related-compact-native-development-20261111')
D = S / 'benchmarks/related-post-gen/integration/native-compact-20261111'


def read(name):
    return json.loads((E / name).read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


lat = read('first-v30/latency.json')
res = read('first-v30/resources.json')
ind = read('independent-v30/report.json')
contracts = read('final-v31-contracts.json')
assert contracts['exit'] == 0 and contracts['passed'] == 589
assert len(lat['samples']) == 744 and len(res['samples']) == 175
assert all(s['exit'] == 0 and s['exact_rust_output'] for s in lat['samples'] + res['samples'])
assert len(ind['samples']) == 312 and ind['all312_outputs_exact'] and ind['target_met']
assert all(s['exit'] == 0 and s['exact_full_output'] for s in ind['samples'])
assert lat['primary_reference']['variant'] == 'rust-ordered-mask-tables256'
candidate = 'mech-ir320-compact-native-4'
names = ['rust-ordered-mask-tables256', 'mech-ir317-retained-ssa-4', candidate]
rows = []
for n in names:
    a = lat['summary'][n]
    b = res['summary'][n + '-instrumented' if n != candidate else n]
    m = b['post_json_measurement_median']
    rows.append(dict(
        implementation=n,
        post_json_ms=a['median_post_json_seconds'] * 1000,
        times_fastest_eligible_Rust=a['post_json_over_fastest_matched_native'],
        whole_process_ms=a['median_whole_process_seconds'] * 1000,
        resources=dict(
            instructions=m['hardware']['instructions_retired'],
            cycles=m['hardware']['cycles'],
            allocation_requests=m['allocation_requests'],
            requested_allocator_bytes=m['requested_allocation_bytes'],
            peak_additional_requested_allocator_heap_bytes=m['peak_additional_live_requested_heap_bytes'],
            allocator_accounting_underflows=m['allocator_accounting_underflows'],
            process_peak_resident_bytes=b['process_resources_median']['peak_resident_bytes'],
            process_peak_physical_footprint_bytes=b['process_resources_median']['peak_physical_footprint_bytes'],
            full_post_json_measurement=m,
            full_process_resources=b['process_resources_median'],
        ),
    ))
assert rows[-1]['times_fastest_eligible_Rust'] <= 1

files = set()


def add(name):
    p = E / name
    assert p.is_file(), p
    files.add(p)


def metadata_tree(name):
    for p in (E / name).rglob('*'):
        if p.is_file() and p.suffix in {'.json', '.txt', '.mec', '.o', '.mecb', '.clif', '.asm', '.rs', '.patch'}:
            # Full JSON outputs are stored once below, addressed by content.
            if p.suffix == '.json' and p.stat().st_size > 2_000_000:
                continue
            files.add(p)


for v in (25, 27, 30):
    for p in (E / f'first-v{v}').iterdir():
        if p.is_file():
            files.add(p)
    for p in (E / f'first-v{v}/resources').glob('*.resources.txt'):
        files.add(p)

for name in ('report.json', 'prospective-rule.json', 'partial.json'):
    add('independent-v30/' + name)

for name in (
    'confirm-v30.py', 'run-first-v25.py', 'run-first-v27.py', 'run-first-v30.py',
    'run-native-probes.py', 'link-and-qualify-workers.py', 'build.py', 'build-compact-host.py',
    'related-compact-native-workers.rs', 'related-compact-native-workers-metrics.rs',
    'related-compact-workers-profile-v25.rs', 'maps-native-check.rs', 'maps-native-index-check.rs',
    'classes-native-check.rs', 'qualify-maps-v27.py', 'qualify-regressions-v27.py',
    'r314-integration-pins.json', 'r312-r314-patch-application.json',
    'post-r314-rebase-source-identity.json', 'v31-same-measured-payloads.json',
    'v29-ordinary-source-identity.json', 'format-check-v30.json', 'format-check-v31.json',
    'final-v27-contracts.json', 'final-v27-contracts.stdout', 'final-v27-contracts.stderr',
    'final-v31-contracts.json', 'final-v31-contracts.stdout', 'final-v31-contracts.stderr',
):
    add(name)

for v in (19, 20, 24, 25, 27, 28, 29, 30, 31):
    for name in ('build.json', 'compile.json', 'source-inventory.json'):
        add(f'compiler-v{v}/' + name)
    add(f'exact-source-v{v}.run.json')
    add(f'flags-v{v}.json')
    metadata_tree(f'exact-source-v{v}')
    metadata_tree(f'qualification-v{v}')
    for kind in ('original', 'decoded', 'metrics', 'profile'):
        p = E / f'runner-compact-v{v}-{kind}.build.json'
        if p.exists():
            files.add(p)

for v in (21, 23, 26):
    metadata_tree(f'compiler-v{v}')
for v in (12, 13, 14, 15):
    metadata_tree(f'tests-v{v}')

metadata_tree('maps-v27')
metadata_tree('classes-v28')
for p in (E / 'regressions-v27').glob('*.json'):
    files.add(p)

for v in (24, 25, 27, 30):
    metadata_tree(f'profile-v{v}')

for n in (309, 312, 313, 314):
    add(f'r{n}-download.json')
    add(f'r{n}-catalog.json')
    for name in ('compiler-changes.patch', 'flags.json', 'source-pins.json'):
        add(f'r{n}/evidence/' + name)
    if n != 309:
        add(f'r{n}/evidence/focused-tests.patch')

# Preserve the exact benchmark input, result and all reference sources once.
P = E / 'publication-inputs'
P.mkdir(exist_ok=True)
input_data = Path(lat['input']['path']).read_bytes()
assert sha(input_data) == lat['input']['sha256']
(P / 'posts.json').write_bytes(input_data)
gold = Path('/private/tmp/mech-related-compiler-catchup-evidence-20261111/runners/selected/output.json').read_bytes()
gold_hash = sha(gold)
assert gold_hash == '470263449577b9b386d47cf81a5b7ed6ec4155eabc8bb31709f55e2e3634f6fc'
(P / f'{gold_hash}.output.json').write_bytes(gold)
files.update((P / 'posts.json', P / f'{gold_hash}.output.json'))

output_index = []
for cohort in ('first-v25/latency.json', 'first-v25/resources.json', 'first-v27/latency.json',
               'first-v27/resources.json', 'first-v30/latency.json', 'first-v30/resources.json',
               'independent-v30/report.json'):
    v = read(cohort)
    for sample in v['samples']:
        assert sample['output_sha256'] == gold_hash
        output_index.append(dict(cohort=cohort, variant=sample['variant'],
                                 sample=sample['sample'], output_sha256=gold_hash))
write(P / 'output-content-index.json', dict(
    deduplicated=True,
    method='Each retained sample records its full-output SHA256 and exact parsed equality. All outputs share these bytes; one content-addressed file is shipped.',
    outputs=output_index,
))
files.add(P / 'output-content-index.json')

source_pins = []
for impl in lat['implementations'] + res['implementations']:
    if not impl.get('source'):
        continue
    src = Path(impl['source'])
    if not src.is_file():
        continue
    data = src.read_bytes()
    if impl.get('source_sha256'):
        assert sha(data) == impl['source_sha256'], src
    name = impl['name']
    dest = P / 'sources' / (name + src.suffix)
    dest.parent.mkdir(exist_ok=True)
    dest.write_bytes(data)
    files.add(dest)
    source_pins.append(dict(variant=name, original_path=str(src), path=str(dest.relative_to(E)), sha256=sha(data)))
write(P / 'reference-source-pins.json', source_pins)
files.add(P / 'reference-source-pins.json')

obj = E / 'exact-source-v30/original.o'
exe = E / 'runner-compact-v30-original'
size = subprocess.run(['size', '-m', str(obj), str(exe)], capture_output=True, text=True, check=True)
write(P / 'binary-size.json', dict(
    command=['size', '-m', str(obj), str(exe)], stdout=size.stdout,
    object_file_bytes=obj.stat().st_size, executable_file_bytes=exe.stat().st_size,
    object_sha256=sha(obj.read_bytes()), executable_sha256=sha(exe.read_bytes()),
))
files.add(P / 'binary-size.json')

add('publish-ir320.py')
records = []
for p in sorted(files):
    rel = p.relative_to(E)
    data = p.read_bytes()
    out = D / 'records-ir320' / Path(str(rel) + '.gz')
    out.parent.mkdir(parents=True, exist_ok=True)
    compressed = gzip.compress(data, mtime=0)
    out.write_bytes(compressed)
    records.append(dict(path=str(out.relative_to(D)), source=str(rel),
                        compressed_sha256=sha(compressed), uncompressed_sha256=sha(data),
                        compressed_bytes=len(compressed), uncompressed_bytes=len(data)))
write(D / 'records-ir320.json', dict(schema=1, records=records))

trajectory = []
for v, label in ((17, 'Initial compact serial'), (25, 'Native workers and shared UTF8 hash'),
                 (27, 'Native Map index and repeated bounds'), (30, 'Native input classes and retained R314')):
    a = read(f'first-v{v}/' + ('latency-complete.json' if v == 17 else 'latency.json'))
    compact_name = next(n for n in a['summary'] if 'compact' in n)
    compact = a['summary'][compact_name]
    ref = a.get('primary_reference') or a['matched_native_reference']
    trajectory.append(dict(stage=label, cohort=f'first-v{v}',
                           compact_ms=compact['median_post_json_seconds'] * 1000,
                           matched_fastest_Rust_ms=ref['median_seconds'] * 1000,
                           times_matched_fastest_Rust=compact['post_json_over_fastest_matched_native']))

report = dict(
    schema='mech.related-post-gen.native-compact-comparison.v2',
    status='Target met in first complete cohort and independent confirmation',
    workload_target_met=True,
    compiler_source_commit='9fbc7c91ea770b2000c64c670fab3098655f4b9c',
    base_rebased_to='fd47444b440f6422cdefe957f2b2cd6a251ab44c',
    retained_compiler='R314', upstream_cutoff_utc='2026-11-11 22:17:12 UTC',
    IR=320, work_version=126, ABI=42, image_version=11,
    backend='Cranelift 0.131.3 / regalloc2 0.15.2', llvm_dependency_added=False,
    benchmark_source='benchmarks/related-post-gen/mech/related_optimized.mec',
    source_sha256=sha((E / 'exact-source-v30/source.mec').read_bytes()),
    benchmark_source_changed_for_this_gain=False,
    input_sha256=sha(input_data), posts=5000, tags=22538, distinct_tags=28,
    machine=lat['machine'], primary_metric='complete post-JSON interval',
    primary_boundary=lat['timing_boundaries']['post_json'],
    timing_details='After JSON decoding; input span preparation, allocations, native work, create/run/join of four workers, heap and preparation cleanup, RelatedPosts materialization. JSON serialization outside. No input-specific index or worker resources are prepared before this timer.',
    whole_process_gate=False,
    whole_process_reference=lat['whole_process_reference'],
    scope_limit='This result is post-JSON processing. Whole-process medians remain visible and are slower than the fastest Rust process; this is not a whole-process speed win.',
    rows=rows,
    primary_cohort=dict(rounds=31, variants=24, Rust_variants=22,
                        eligible_Rust_variants=20, seed=202611112230,
                        exact_full_outputs=744, reference=lat['primary_reference'],
                        report='first-v30/latency.json'),
    resource_cohort=dict(rounds=7, variants=25, seed=202611112231,
                         exact_full_outputs=175, instrumented_separately=True,
                         latency_not_used_for_selection=True, report='first-v30/resources.json'),
    independent_confirmation=dict(
        rounds=13, variants=24, seed=ind['seed'], exact_full_outputs=312,
        candidate_ms=ind['candidate_post_json_ms'], Rust_ms=ind['reference_post_json_ms'],
        times_fastest_eligible_Rust=ind['times_fastest_eligible_native'], target_met=True,
        independent_orchestration=True, separate_machine=False,
        report='independent-v30/report.json',
    ),
    no_outlier_removal=True, all_initial_observations_retained=True,
    candidate_predeclared_original_Object=True,
    original_and_decoded_Objects_identical=True,
    formatted_final_compiler_emits_identical_measured_Objects=True,
    source_after_rebase_identical_to_final_build=True,
    trajectory=trajectory,
    implementation=dict(
        ordinary_managed_entry_remains_selected=True,
        compact_contract='Diagnostic compact/unmetered native entry omits exact managed resource accounting, admission and recovery. Arithmetic, indexing and assertion checks remain.',
        managed_comparison='Retained IR317 managed four-worker compiler, measured in every matched cohort.',
        compiler_work=['Current Boolean ownership proof enables in-place buffer reuse',
                       'Current read-only numeric phases shared with native worker bodies',
                       'Native scoped parallel entries from current constructor-private capture proof',
                       'Shared native UTF8 chunk hashing and canonical histogram construction',
                       'Native canonical Map index with COW and deterministic entry order',
                       'Input String equivalence classes from canonical histogram/lookup proof; bulk native expansion',
                       'Retained R309 repeated bounds, R312 exit packets, R313 dominating comparisons, R314 scalar spans'],
        workers=4, native_workers=True, native_algorithm=True,
        compatibility_bridges=False,
        host_role='JSON adapter, concrete allocation/COW/free, generic worker create/join and heap adoption; no tag/post/scoring algorithm.',
        native_Object_imports=['mech_compact_allocate', 'mech_compact_writable', 'mech_compact_free', 'mech_compact_parallel', 'memmove'],
        class_proof_scope='Direct immutable invocation-input strings only. Distinct Maps compute their own first-class values; missing keys retain original read-site failure. Owned/unrelated/unproved sources decline this optimization.',
    ),
    memory_boundaries=dict(
        allocator='Global requested allocator heap, all threads, within the post-JSON interval. Excludes anonymous mappings and OS thread stacks.',
        native_payload='Concrete native backing, including anonymous mappings, tracked separately from allocator counts. These counters overlap some allocations; do not add them.',
        native_payload_requests=23, native_requested_payload_bytes=4171036,
        native_root_peak_payload_bytes=2737336,
        native_worker_phase_peak_payload_upper_bound_bytes=2537336,
        worker_phase_bound_is_not_process_peak=True,
    ),
    native_size=dict(object_text_bytes=182604, object_file_bytes=obj.stat().st_size,
                     root_code_bytes=140236, root_stack_bytes=10064,
                     worker_code_bytes=6440, worker_stack_bytes=880,
                     linked_executable_text_bytes=494948, executable_file_bytes=exe.stat().st_size,
                     Object_sha256=sha(obj.read_bytes()), executable_sha256=sha(exe.read_bytes())),
    qualification=dict(
        final_contracts=589, all583_prior_names_retained=True,
        final_focused_contracts=48,
        original_and_decoded_full5000_exact=True, edge_cases_per_artifact=31,
        native_Map_cases_v27=2388, native_class_cases_v28=594,
        native_missing_key_errors_v28=116,
        source_origin_and_untouched_output_and_heap_reclamation_verified=True,
        prior_scalar_DEFLATE_non_timing_rows_exact=133,
        scalar_DEFLATE_scope='Measured on v27; compact-only class changes preserve ordinary compiler sources. Later retained R312–R314 rewrites are gated to the compact/private/vector path, exercised by final focused and broad native tests. No fresh v31 133-row run claimed.',
        rustfmt_changed_Rust_files=34, rustfmt_passed=True,
    ),
    profile=dict(report='profile-v30/receipt.json', samples='profile-v30/native.sample.txt',
                 machine_source_ranges='profile-v30/route/machine-source-ranges.json',
                 measured_Object_unmodified=True, repeated_post_JSON_invocations=5001,
                 JSON_decoded_once=True, diagnostic_only=True,
                 interpretation='Compiled query loops now dominate; repetitive input-tag lookup was reduced by native input classes. Inclusive sampled stacks overlap and must not be added as elapsed percentages.'),
    evidence_manifest='records-ir320.json',
    historical_baseline_report='report.json', historical_baseline_manifest='records.json',
    replay='python3 benchmarks/related-post-gen/integration/native-compact-20261111/verify.py',
    limitations=['Shared development machine; exploratory timings with matched randomized fresh processes.',
                 'Independent confirmation uses separate orchestration on the same host, not another machine.',
                 'The compact/unmetered contract is distinct from ordinary managed execution.',
                 'Preinitialized Rust worker-pool timers are shown but ineligible for the matched primary interval.',
                 'Compiler gaps remain for other language shapes; this does not claim whole-language native coverage.'],
)
write(D / 'latest.json', report)
print(json.dumps(dict(records=len(records), compressed_bytes=sum(r['compressed_bytes'] for r in records),
                      rows=rows, independent=report['independent_confirmation']), indent=2))
