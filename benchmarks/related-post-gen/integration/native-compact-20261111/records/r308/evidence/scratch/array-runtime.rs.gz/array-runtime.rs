//! Concrete diagnostic array backing. No schemas, library binding, dispatch,
//! source word banks or canonical Value identities participate in these calls.
use std::{
    alloc::{Layout, alloc, alloc_zeroed, dealloc},
    ptr,
};
#[path = "zero_pages.rs"]
mod zero_pages;
pub const ALLOCATION: u64 = 0x19402;
pub const INVALID: u64 = 0x19403;
pub type View = [u64; 6];

#[repr(C)]
pub struct Owner {
    pub references: u64,
    slot: usize,
    data: *mut u8,
    capacity: usize,
    stride: usize,
    alignment_and_mapping: usize,
}
impl Owner {
    // A nonempty validated Layout reserves this high bit. Keeping the backing
    // flag there preserves the original six-word owner descriptor.
    const MAPPED: usize = 1usize << (usize::BITS - 1);

    fn alignment(&self) -> usize {
        self.alignment_and_mapping & !Self::MAPPED
    }

    fn is_mapped(&self) -> bool {
        self.alignment_and_mapping & Self::MAPPED != 0
    }
}
#[derive(Default, Debug)]
pub struct Counters {
    pub payload_requests: u64,
    pub requested_payload_bytes: u64,
    pub initialized_bytes_copied: u64,
    pub zeroed_bytes: u64,
    #[cfg(any(test, feature = "mapped-zero-counters"))]
    pub mapped_payload_requests: u64,
    #[cfg(any(test, feature = "mapped-zero-counters"))]
    pub mapped_payload_bytes: u64,
    #[cfg(any(test, feature = "mapped-zero-counters"))]
    pub live_mapped_payload_bytes: u64,
    pub live_payload_bytes: u64,
    pub peak_payload_bytes: u64,
}
#[derive(Default, Debug)]
pub struct ScratchAudit {
    pub allocations: u64,
    pub copies: u64,
    pub copied_bytes: u64,
    pub releases: u64,
    pub overwritten_words: u64,
    pub last_overwritten_word: u64,
}

// Diagnostic for the pinned fixture only. Both poison values fit U32 and
// cannot be a legal packed level-12 match/header.
const CACHE_WORDS: usize = 1_500_513;

#[derive(Default)]
pub struct Heap {
    owners: Vec<*mut Owner>,
    free: Vec<usize>,
    pub counters: Counters,
    pub scratch_audit: ScratchAudit,
    pub scratch_poison: Option<u32>,
}
impl Heap {
    pub fn new() -> Self {
        Self::default()
    }
    pub fn discard_private(&mut self) {
        for index in 0..self.owners.len() {
            let owner = self.owners[index];
            if !owner.is_null() {
                unsafe {
                    (*owner).references = 0;
                    self.release(owner)
                        .expect("owned diagnostic backing cleanup");
                }
            }
        }
        assert_eq!(self.counters.live_payload_bytes, 0);
        #[cfg(any(test, feature = "mapped-zero-counters"))]
        assert_eq!(self.counters.live_mapped_payload_bytes, 0);
    }
    fn allocate(
        &mut self,
        capacity: usize,
        stride: usize,
        alignment: usize,
        zeroed: bool,
    ) -> Result<View, u64> {
        if stride == 0 || alignment == 0 || !alignment.is_power_of_two() {
            return Err(INVALID);
        }
        let bytes = capacity.checked_mul(stride).ok_or(1u64)?;
        let layout = Layout::from_size_align(bytes, alignment).map_err(|_| 1u64)?;
        if bytes == 0 {
            return Ok([alignment as u64, 0, 0, 1, 0, 0]);
        }
        debug_assert_eq!(alignment & Owner::MAPPED, 0);
        // Fresh page mappings provide the same initialized zero words.
        // Byte outputs keep their original allocator for direct Vec transfer.
        let mapping = if zeroed && stride != 1 {
            zero_pages::reserve(layout)?
        } else {
            None
        };
        let mapped = mapping.is_some();
        let data = if let Some(mapping) = mapping {
            mapping.as_ptr()
        } else {
            // SAFETY: checked nonzero layout. The selected allocator operation
            // establishes the original initialization contract.
            unsafe {
                if zeroed {
                    alloc_zeroed(layout)
                } else {
                    alloc(layout)
                }
            }
        };
        if data.is_null() {
            return Err(ALLOCATION);
        }
        if stride == 4 && capacity == CACHE_WORDS && zeroed {
            self.scratch_audit.allocations += 1;
            if let Some(poison) = self.scratch_poison {
                // The original allocator and its initialization/failure
                // behavior have completed. This separate diagnostic supplies
                // alternate initialized bit patterns before native use.
                for index in 0..capacity {
                    unsafe { data.cast::<u32>().add(index).write(poison) };
                }
            }
        }
        let slot = self.free.pop().unwrap_or_else(|| {
            self.owners.push(ptr::null_mut());
            self.owners.len() - 1
        });
        let owner = Box::into_raw(Box::new(Owner {
            references: 0,
            slot,
            data,
            capacity,
            stride,
            alignment_and_mapping: if mapped {
                alignment | Owner::MAPPED
            } else {
                alignment
            },
        }));
        self.owners[slot] = owner;
        self.counters.payload_requests += 1;
        self.counters.requested_payload_bytes += bytes as u64;
        self.counters.live_payload_bytes += bytes as u64;
        self.counters.peak_payload_bytes = self
            .counters
            .peak_payload_bytes
            .max(self.counters.live_payload_bytes);
        if zeroed {
            self.counters.zeroed_bytes += bytes as u64
        }
        #[cfg(any(test, feature = "mapped-zero-counters"))]
        if mapped {
            self.counters.mapped_payload_requests += 1;
            self.counters.mapped_payload_bytes += bytes as u64;
            self.counters.live_mapped_payload_bytes += bytes as u64;
        }
        Ok([data as u64, 0, capacity as u64, 1, 0, owner as u64])
    }
    unsafe fn release(&mut self, owner: *mut Owner) -> Result<(), u64> {
        if owner.is_null() {
            return Ok(());
        }
        // SAFETY: only the owning native transaction supplies concrete owner
        // pointers, and a zero refcount is required before physical release.
        let record = unsafe { &*owner };
        if record.references != 0 || self.owners.get(record.slot).copied() != Some(owner) {
            return Err(INVALID);
        }
        let bytes = record.capacity.checked_mul(record.stride).ok_or(INVALID)?;
        let layout = Layout::from_size_align(bytes, record.alignment()).map_err(|_| INVALID)?;
        let slot = record.slot;
        let data = record.data;
        if record.stride == 4 && record.capacity == CACHE_WORDS && record.is_mapped() {
            self.scratch_audit.releases += 1;
            if let Some(poison) = self.scratch_poison {
                // Every original word was initialized by the mapping and the
                // diagnostic fill, so untouched words can be inspected here.
                let words = unsafe { std::slice::from_raw_parts(data.cast::<u32>(), CACHE_WORDS) };
                for (index, &word) in words.iter().enumerate() {
                    if word != poison {
                        self.scratch_audit.overwritten_words += 1;
                        self.scratch_audit.last_overwritten_word = (index + 1) as u64;
                    }
                }
            }
        }
        if record.is_mapped() {
            // SAFETY: this exact mapping is live, exclusive and registered.
            unsafe { zero_pages::release(data, bytes)? };
            #[cfg(any(test, feature = "mapped-zero-counters"))]
            {
                self.counters.live_mapped_payload_bytes -= bytes as u64;
            }
        } else {
            // SAFETY: this pointer retains its original allocator layout.
            unsafe { dealloc(data, layout) };
        }
        unsafe { drop(Box::from_raw(owner)) };
        self.owners[slot] = ptr::null_mut();
        self.free.push(slot);
        self.counters.live_payload_bytes -= bytes as u64;
        Ok(())
    }
    fn writable(
        &mut self,
        source: View,
        consume: bool,
        minimum: usize,
        stride: usize,
        alignment: usize,
    ) -> Result<View, u64> {
        let length = usize::try_from(source[1]).map_err(|_| INVALID)?;
        let capacity = usize::try_from(source[2]).map_err(|_| INVALID)?;
        if length > capacity || minimum < length {
            return Err(INVALID);
        }
        let owner = source[5] as *mut Owner;
        if consume && !owner.is_null() {
            // SAFETY: current private owner came from this live transaction;
            // native last-use permits replacing this source, not a live alias.
            let record = unsafe { &*owner };
            if self.owners.get(record.slot).copied() != Some(owner)
                || record.stride != stride
                || record.alignment() != alignment
                || record.data as u64 != source[0]
                || record.capacity != capacity
            {
                return Err(INVALID);
            }
            if record.references == 1 && minimum <= capacity {
                return Ok(source);
            }
        }
        let mut result = self.allocate(capacity.max(minimum), stride, alignment, false)?;
        let bytes = length.checked_mul(stride).ok_or(1u64)?;
        if bytes != 0 {
            // SAFETY: source's actual initialized prefix is valid for this
            // synchronous call; fresh destination has at least that capacity.
            unsafe {
                ptr::copy_nonoverlapping(source[0] as *const u8, result[0] as *mut u8, bytes)
            };
        }
        if stride == 4 && capacity == CACHE_WORDS && bytes != 0 {
            self.scratch_audit.copies += 1;
            self.scratch_audit.copied_bytes += bytes as u64;
        }
        self.counters.initialized_bytes_copied += bytes as u64;
        result[1] = source[1];
        result[3] = source[3];
        result[4] = source[4];
        Ok(result)
    }
}
impl Drop for Heap {
    fn drop(&mut self) {
        // A failed private transaction publishes no roots. Generated values
        // and views cannot escape this lifetime; discard all remaining scratch.
        self.discard_private();
    }
}

/// # Safety
/// Current owning Heap and a disjoint six-word output lane outlive the call.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn mech_compact_allocate(
    context: *mut Heap,
    capacity: u64,
    stride: u64,
    alignment: u64,
    zeroed: u64,
    output: *mut u64,
) -> u64 {
    if context.is_null() || output.is_null() {
        return INVALID;
    }
    let result = unsafe { &mut *context }.allocate(
        capacity as usize,
        stride as usize,
        alignment as usize,
        zeroed != 0,
    );
    match result {
        Ok(view) => {
            unsafe { ptr::copy_nonoverlapping(view.as_ptr(), output, 6) };
            0
        }
        Err(status) => status,
    }
}
/// # Safety
/// Both lanes and the current concrete backing owners belong to this live
/// transaction. `consume` additionally requires the compiler's last-use proof.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn mech_compact_writable(
    context: *mut Heap,
    source: *const u64,
    consume: u64,
    minimum: u64,
    stride: u64,
    alignment: u64,
    output: *mut u64,
) -> u64 {
    if context.is_null() || source.is_null() || output.is_null() {
        return INVALID;
    }
    let view = unsafe { ptr::read(source.cast::<View>()) };
    let result = unsafe { &mut *context }.writable(
        view,
        consume != 0,
        minimum as usize,
        stride as usize,
        alignment as usize,
    );
    match result {
        Ok(view) => {
            unsafe { ptr::copy_nonoverlapping(view.as_ptr(), output, 6) };
            0
        }
        Err(status) => status,
    }
}
/// # Safety
/// The generated final release has decremented this current owner's count to0.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn mech_compact_free(context: *mut Heap, owner: *mut Owner) -> u64 {
    if context.is_null() {
        return INVALID;
    }
    match unsafe { (&mut *context).release(owner) } {
        Ok(()) => 0,
        Err(status) => status,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn live_alias_copies_initialized_prefix_and_keeps_capacity() {
        let mut heap = Heap::new();
        let mut original = heap.allocate(305257, 8, 8, false).unwrap();
        unsafe {
            (original[0] as *mut u64).write(17);
            (original[0] as *mut u64).add(1).write(29);
            (*(original[5] as *mut Owner)).references = 2;
        }
        original[1] = 2;
        original[4] = 2;
        let copy = heap.writable(original, true, 2, 8, 8).unwrap();
        assert_ne!(copy[0], original[0]);
        assert_eq!(copy[2], 305257);
        assert_eq!(heap.counters.initialized_bytes_copied, 16);
        unsafe {
            (copy[0] as *mut u64).write(99);
            assert_eq!((original[0] as *const u64).read(), 17);
        }
        let before = heap.counters.payload_requests;
        unsafe {
            (*(original[5] as *mut Owner)).references = 1;
        }
        let reused = heap.writable(original, true, 2, 8, 8).unwrap();
        assert_eq!(reused, original);
        assert_eq!(heap.counters.payload_requests, before);
    }
    #[test]
    fn real_cache_and_tree_are_initialized_but_path_reserve_is_not() {
        let mut heap = Heap::new();
        let tree = heap.allocate(262144, 2, 2, true).unwrap();
        let cache = heap.allocate(1500513, 4, 4, true).unwrap();
        let nodes = heap.allocate(305257, 8, 8, false).unwrap();
        unsafe {
            assert_eq!((tree[0] as *const u16).add(262143).read(), 0);
            assert_eq!((cache[0] as *const u32).add(1500512).read(), 0);
        }
        assert_eq!(heap.counters.zeroed_bytes, 262144 * 2 + 1500513 * 4);
        assert_eq!(nodes[1], 0);
        assert_eq!(nodes[2], 305257);
        assert_eq!(heap.counters.initialized_bytes_copied, 0);
    }
    #[test]
    fn clear_keeps_private_capacity_and_copies_no_elements() {
        let mut heap = Heap::new();
        let mut source = heap.allocate(305257, 8, 8, false).unwrap();
        unsafe {
            (*(source[5] as *mut Owner)).references = 1;
        }
        // A clear result has an empty initialized prefix. No unread bytes are
        // exposed and no old element is copied into a new backing.
        source[1] = 0;
        source[3] = 1;
        source[4] = 0;
        let requests = heap.counters.payload_requests;
        assert_eq!(heap.writable(source, true, 0, 8, 8).unwrap(), source);
        assert_eq!(heap.counters.payload_requests, requests);
        unsafe {
            (*(source[5] as *mut Owner)).references = 2;
        }
        let other = heap.writable(source, true, 0, 8, 8).unwrap();
        assert_ne!(other[0], source[0]);
        assert_eq!(other[2], 305257);
        assert_eq!(heap.counters.initialized_bytes_copied, 0);
    }
    #[test]
    fn rejected_physical_size_keeps_source_and_result_lane_and_recovers() {
        let mut heap = Heap::new();
        let mut source = heap.allocate(13, 1, 1, false).unwrap();
        source[1] = 2;
        source[4] = 2;
        unsafe {
            (source[0] as *mut u8).write(17);
            (source[0] as *mut u8).add(1).write(29);
            (*(source[5] as *mut Owner)).references = 2;
        }
        let before = source;
        let mut output = [0x5555555555555555u64; 6];
        let expected = output;
        // usize::MAX cannot describe a Rust allocation. This rejects without
        // attempting an enormous allocation or changing current owned storage.
        let status = unsafe {
            mech_compact_writable(
                &mut heap,
                source.as_ptr(),
                0,
                u64::MAX,
                1,
                1,
                output.as_mut_ptr(),
            )
        };
        assert_eq!(status, 1);
        assert_eq!(source, before);
        assert_eq!(output, expected);
        unsafe {
            assert_eq!((source[0] as *const u8).read(), 17);
            assert_eq!((source[0] as *const u8).add(1).read(), 29);
            assert_eq!((*(source[5] as *const Owner)).references, 2);
        }
        let status = unsafe {
            mech_compact_writable(&mut heap, source.as_ptr(), 0, 3, 1, 1, output.as_mut_ptr())
        };
        assert_eq!(status, 0);
        assert_eq!(output[1], 2);
        assert_eq!(output[2], 13);
        assert_ne!(output[0], source[0]);
        assert_eq!(heap.counters.initialized_bytes_copied, 2);
    }
}

impl Heap {
    /// Transfer the sole final U8 allocation without a payload copy. All view
    /// aliases are counted by the generated typed source-value lifetime code.
    ///
    /// # Safety
    /// The view must originate from this heap in the exact generated entry.
    pub unsafe fn take_u8(&mut self, view: View) -> Result<Vec<u8>, u64> {
        let [pointer, length, capacity, rows, columns, owner] = view;
        if rows != 1 || columns != length || length > capacity || owner == 0 {
            return Err(INVALID);
        }
        let owner = owner as *mut Owner;
        // SAFETY: final views are returned by the exact linked native body. A
        // current heap slot, exact backing geometry and sole reference are all
        // checked before removing that owner and constructing the Vec.
        let record = unsafe { &*owner };
        if self.owners.get(record.slot).copied() != Some(owner)
            || record.references != 1
            || record.stride != 1
            || record.alignment_and_mapping != 1
            || record.data as u64 != pointer
            || record.capacity as u64 != capacity
        {
            return Err(INVALID);
        }
        let slot = record.slot;
        self.owners[slot] = ptr::null_mut();
        self.free.push(slot);
        self.counters.live_payload_bytes -= capacity;
        let record = unsafe { Box::from_raw(owner) };
        // Allocation uses this exact U8 layout through the pinned global
        // allocator; the Vec becomes its sole owner and retains full capacity.
        let result =
            unsafe { Vec::from_raw_parts(record.data, length as usize, capacity as usize) };
        drop(record);
        Ok(result)
    }
}

#[cfg(all(test, target_os = "macos"))]
mod mapped_tests {
    use super::*;

    #[test]
    fn mapped_numeric_zeros_remain_readable_and_live_aliases_keep_their_words() {
        assert_eq!(
            std::mem::size_of::<Owner>(),
            6 * std::mem::size_of::<usize>()
        );
        let mut heap = Heap::new();
        let mut source = heap.allocate(262144, 4, 4, true).unwrap();
        let bytes = 262144 * 4;
        assert_eq!(heap.counters.mapped_payload_requests, 1);
        assert_eq!(heap.counters.mapped_payload_bytes, bytes);
        let old = unsafe { std::slice::from_raw_parts_mut(source[0] as *mut u32, 262144) };
        assert!(old.iter().all(|value| *value == 0));
        old[0] = 17;
        old[262143] = 29;
        source[1] = 262144;
        source[4] = 262144;
        unsafe { (*(source[5] as *mut Owner)).references = 2 };
        let copied = heap.writable(source, true, 262144, 4, 4).unwrap();
        assert_ne!(source[0], copied[0]);
        assert_eq!(copied[2], source[2]);
        unsafe { (copied[0] as *mut u32).write(99) };
        assert_eq!(old[0], 17);
        assert_eq!(old[262143], 29);
        assert_eq!(heap.counters.initialized_bytes_copied, bytes);
        assert_eq!(heap.counters.mapped_payload_requests, 1);
        heap.discard_private();
        assert_eq!(heap.counters.live_mapped_payload_bytes, 0);
    }

    #[test]
    fn failed_mapping_keeps_prior_backing_and_recovers_on_retry() {
        let mut heap = Heap::new();
        let prior = heap.allocate(262144, 4, 4, true).unwrap();
        unsafe { (prior[0] as *mut u32).write(73) };
        let requests = heap.counters.payload_requests;
        zero_pages::DENY.with(|deny| deny.set(true));
        assert_eq!(heap.allocate(1500513, 4, 4, true), Err(ALLOCATION));
        zero_pages::DENY.with(|deny| deny.set(false));
        assert_eq!(heap.counters.payload_requests, requests);
        assert_eq!(unsafe { (prior[0] as *const u32).read() }, 73);
        let retry = heap.allocate(1500513, 4, 4, true).unwrap();
        assert_eq!(unsafe { (retry[0] as *const u32).add(1500512).read() }, 0);
        heap.discard_private();
        assert_eq!(heap.counters.live_payload_bytes, 0);
        assert_eq!(heap.counters.live_mapped_payload_bytes, 0);
    }

    #[test]
    fn byte_output_retains_the_original_allocator_and_transfer() {
        let mut heap = Heap::new();
        let mut output = heap.allocate(131072, 1, 1, true).unwrap();
        assert_eq!(heap.counters.mapped_payload_requests, 0);
        unsafe {
            (output[0] as *mut u8).write(42);
            (*(output[5] as *mut Owner)).references = 1;
        }
        output[1] = 1;
        output[4] = 1;
        let published = unsafe { heap.take_u8(output) }.unwrap();
        assert_eq!(published, [42]);
        assert_eq!(published.capacity(), 131072);
        assert_eq!(heap.counters.live_payload_bytes, 0);
    }
}

#[cfg(all(test, target_os = "macos"))]
pub(crate) fn deny_test_mapping(denied: bool) {
    zero_pages::DENY.with(|deny| deny.set(denied));
}
