from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,time,sys
E=Path(__file__).parent;B=Path('/private/tmp/mech-related-pr990-rebase-evidence-20261111');S=Path('/private/tmp/mech-related-known-widths-compiler-20261111');OLD='/private/tmp/mech-related-pr990-rebase-20261111';spec=importlib.util.spec_from_file_location('gpu_command',B/'cargo-gpu-command.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);b=json.loads((B/'cargo-patched-compiler/build.json').read_text());b['source']=str(S)
def build(label,test=False,runtime=False):
 d=E/label;d.mkdir(exist_ok=False);out=d/('gpu-tests'if test else'libmech_gpu.rlib');c,e=m.command(b,out,test=test,runtime=runtime);c=[arg.replace(OLD,str(S)).replace('related_312_','related_313_')for arg in c];e={key:value.replace(OLD,str(S))for key,value in e.items()}
 if not test and not runtime:
  c += ['-C','metadata=related_313_compiler']
 t=time.monotonic();r=subprocess.run(c,cwd=S,env={**os.environ,**e},capture_output=True,text=True);receipt=dict(command=c,environment=e,exit=r.returncode,seconds=time.monotonic()-t,stdout=r.stdout,stderr=r.stderr);(d/'compile.json').write_text(json.dumps(receipt,indent=2)+'\n');print(label,r.returncode,round(receipt['seconds'],2),flush=True)
 if r.returncode:print(r.stderr[-12000:],flush=True)
 assert r.returncode==0
 if not test:
  bb=json.loads(json.dumps(b));stage=bb['stages'][-1];stage.update(command=c,environment=e,library_path=str(out),library_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),runtime_only=runtime);bb['source']=str(S);bb['source_sha256']=hashlib.sha256(json.dumps({str(p.relative_to(S)):hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted((S/'hosts/gpu').rglob('*.rs'))},sort_keys=True).encode()).hexdigest();(d/'build.json').write_text(json.dumps(bb,indent=2)+'\n')
 return out
# Contracts execute before building native binaries; no latency capture overlaps compilation.
if __name__=='__main__':
 stage=sys.argv[1]if len(sys.argv)>1 else 'tests'
 build(stage,test=stage=='tests',runtime=stage=='runtime')
