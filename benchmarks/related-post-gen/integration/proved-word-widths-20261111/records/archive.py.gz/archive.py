from pathlib import Path
import gzip,hashlib,json,subprocess
E=Path(__file__).parent;S=Path('/private/tmp/mech-related-known-widths-compiler-20261111');D=S/'benchmarks/related-post-gen/integration/proved-word-widths-20261111';D.mkdir(exist_ok=False);manifest=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
def add(p):
 p=Path(p);rel=p.relative_to(E);q=D/'records'/Path(str(rel)+'.gz');q.parent.mkdir(parents=True,exist_ok=True);b=p.read_bytes();q.write_bytes(gzip.compress(b,mtime=0));manifest.append(dict(path=str(q.relative_to(D)),sha256=sha(q.read_bytes()),uncompressed_sha256=sha(b),uncompressed_bytes=len(b)))
for p in sorted(E.glob('*.json')):add(p)
for dirname in['qualification','regressions','compiler','runtime','runner','variant-objects','tests']:
 for p in sorted((E/dirname).glob('*.json')):add(p)
for p in sorted((E/'runner/build').glob('*.json')):
 if p.name!='catalog-profile.json':add(p)
for p in sorted(E.glob('*.py')):add(p)
inv=json.loads((E/'qualification/integrated-ci-inventory.json').read_text());assert len(inv['names'])==502
fx=json.loads((E/'width-source-variant-effects.json').read_text());assert all(x['native_text_equal_to_IR312']and not x['removed_width_guards']for x in fx);effect=json.loads((E/'width-baseline-effect.json').read_text());assert effect['text_bytes_equal']and effect['proved_width_guards_removed']==0
for p in[E/'compiler-host.build.json',E/'runner/runner-aot.build.json']:
 d=json.loads(p.read_text());assert sha(Path(d['compiler_build']).read_bytes())==d['compiler_build_sha256']
summary=dict(schema='mech.related-post-gen.proved-word-widths.v1',identity='IR313/work126/ABI42/image11',parent='8e56185fb061d73263d6c4f084974b79eccb6c20',proof='Finite unsigned width propagation over every current SSA incoming edge; remove only a proved width guard or an index guard dominated by a sufficient current length floor. This introduces no memory permissions, source assumptions or work changes.',source='Verified R293 known_widths pass and three upstream execution tests, with the selected Boolean incoming-edge proof retained and a new default-pipeline/ablation execution test.',qualification=dict(compiler_contracts=502,all_484_selected_IR308_contracts_retained=True,width_mechanism_tests=4,scalar_rows_exact=128,one_kib_DEFLATE_rows_exact=5,all_resource_fields_exact=True,original_and_restored_actual5000=True,linked_exact_outputs=32,same_Object_audit=True,native_functions=49),benchmark_effect=dict(selected=effect,source_variants=fx,new_latency_claim=False,unchanged_latency_not_repeated=True,latest_measured_reference='IR312: 1.698625 ms / 1.120127x fastest eligible Rust in the first matched cohort. This is not a fresh IR313 measurement.',whole_process_effect_not_measured=True,goal_complete=False),artifacts=manifest)
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');(D/'REPORT.md').write_text('''The default compiler now propagates unsigned SSA widths through every input to a join or loop. It folds a bounds branch only when those values fit and, for a variable length, the same current length has a sufficient floor on a dominating selected edge. Unknown definitions, wide backedges, changed lengths, shared joins, exceptional control and unsupported operations retain their original guards. Source operations, checks, traps and work accounting remain separate effects.

The pass comes from the hash-verified R293 DEFLATE compiler closure. The selected compiler retains its early identity, Boolean and unsigned guard passes. The new pass uses those existing incoming-edge facts with no added assumptions, has a private compile-option ablation, and reports its own branch count. IR313 invalidates old compiled images while retaining work126/ABI42.

Four execution tests cover packed joins, growing/shifted loop backedges, current selected length floors, changed lengths, wide backedges, shared joins and the actual default pipeline versus ablation. All 502 compiler contracts pass, including every one of the 484 selected IR308 names. All 133 scalar/DEFLATE rows match IR312 on every non-timing and resource field. Original/restored full-input execution and 32 linked exact-output cases pass; the linked Object byte audit passes and all 49 numeric functions remain.

This pass removes zero guards from the selected related-post program. Its entire native text section is byte-identical to IR312. The byte-ID, tables256 and combined source variants also emit byte-identical native text. No unchanged timing cohort was repeated, and there is no new latency claim. The last matched measurement is IR312 at 1.698625 ms / 1.120127× fastest eligible Rust; it is not a fresh IR313 whole-process or latency result. This closes a general packed-join compiler gap but does not close the remaining related-post performance gap.

The compressed records retain all qualification, compilation, source identities and native-text comparisons. Build-manifest source annotations are separate from consumed manifests; both host receipts match their exact consumed manifest bytes, and all non-GPU package sources match the previously qualified dependency closure.
''');print('archived',len(manifest),'records',sum((D/r['path']).stat().st_size for r in manifest),'compressed bytes')
