from pathlib import Path
import hashlib,json,os,subprocess,time,shutil
E=Path(__file__).parent;B=Path('/private/tmp/mech-related-pr990-rebase-evidence-20261111');S=Path('/private/tmp/mech-related-known-widths-compiler-20261111');read=lambda p:json.loads(Path(p).read_text());P=E/'regressions';P.mkdir(exist_ok=False)
def run(c,p):
 c=list(map(str,c));t=time.monotonic();r=subprocess.run(c,cwd=S,env={**os.environ,'RUSTC_BOOTSTRAP':'1'},capture_output=True,text=True);p.write_text(json.dumps(dict(command=c,exit=r.returncode,seconds=time.monotonic()-t,stdout=r.stdout,stderr=r.stderr,qualification_only=True),indent=2)+'\n');print(p.name,r.returncode,flush=True);assert r.returncode==0,r.stdout[-5000:]+r.stderr[-5000:];return r
comparisons=[]
for kind,n in [('scalar',128),('one-kib',5)]:
 c=read(B/'ir312-regression-controls'/f'{kind}-build.json')['command']
 for i,arg in enumerate(c[:-1]):
  if arg=='--extern'and c[i+1].startswith('mech_gpu='):c[i+1]='mech_gpu='+str(E/'compiler/libmech_gpu.rlib')
 c[c.index('-o')+1]=str(P/kind);c+=['-L','dependency='+str(E/'compiler')];run(c,P/f'{kind}-build.json')
 c=read(B/'ir312-regression-controls'/f'{kind}-run.json')['command'];c[0]=str(P/kind);run(c,P/f'{kind}-run.json')
 def rows(p):return [{k:v for k,v in json.loads(l).items()if k not in['seconds','seconds_per_evaluation']}for l in read(p)['stdout'].splitlines()if l.startswith('{')]
 a=rows(P/f'{kind}-run.json');b=rows(B/'ir312-regression-controls'/f'{kind}-run.json');assert len(a)==len(b)==n;changes=[dict(row=i,before=y,after=x)for i,(x,y)in enumerate(zip(a,b))if x!=y];comparisons.append(dict(kind=kind,rows=n,all_non_timing_fields_exact=not changes,changes=changes));assert not changes,changes
(P/'comparison.json').write_text(json.dumps(comparisons,indent=2)+'\n');print('133 exact rows including resources',flush=True)
N=E/'runner';N.mkdir();shutil.copytree(E/'object',N/'build');shutil.copyfile(B/'ir312-runners/patched/runner.rs',N/'runner.rs');run(['python3',B/'build-cargo-host.py','--compiler-build',E/'runtime/build.json','--source',N/'runner.rs','--out',N/'runner-aot','--bundle',N/'build','--linked'],N/'runner-build.json');run(['python3',S/'benchmarks/related-post-gen/audit-native-link.py','--object',N/'build/object.o','--executable',N/'runner-aot','--output',N/'same-object-audit.json'],N/'audit-run.json');run([N/'runner-aot',N/'build/source.mec','/private/tmp/mech-related-current-input-fixtures-20261107/posts.json',N/'output.json','1'],N/'actual5000.json');assert read(N/'output.json')==read('/private/tmp/mech-related-compact-table-sources-20261108/reference-v1/related_posts_rust.json');run(['python3',S/'benchmarks/related-post-gen/experiments/check_subset3.py','--runner',N/'runner-aot','--rust','/private/tmp/mech-related-post-rust-local-20261102/rust/target/release/rust','--source',N/'build/source.mec','--out',N/'edges'],N/'edges-run.json');print('32 linked exact outputs and Object byte audit',flush=True)
