from pathlib import Path
import hashlib,json,shutil
S=Path('/private/tmp/mech-related-known-widths-compiler-20261111');R=Path('/private/tmp/mech-related-pr990-rebase-evidence-20261111/deflate-r293-source-v3');E=Path(__file__).parent;C=Path('hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup');changes=[]
def replace(rel,old,new):
 p=S/rel;s=p.read_text();assert s.count(old)==1,(rel,old[:50],s.count(old));p.write_text(s.replace(old,new));changes.append(str(rel))
for n in ['known_widths.rs','known_widths_tests.rs']:
 shutil.copyfile(R/C/n,S/C/n);changes.append(str(C/n))
# Retain selected Boolean range refinements and expose its existing incoming-edge proof.
replace(C/'boolean_words.rs','fn inputs(f: &Function, cfg: &ControlFlowGraph)','pub(super) fn inputs(f: &Function, cfg: &ControlFlowGraph)')
replace(C/'selected_ranges.rs','\nfn incoming(\n','\npub(super) fn incoming(\n')
replace(C/'known_widths.rs','selected_ranges::incoming(function, cfg, block)','selected_ranges::incoming(function, cfg, block, &BTreeMap::new())')
replace(C/'mod.rs','mod local_phis;','mod known_widths;\nmod local_phis;')
replace(C/'mod.rs','        boolean_phi_values: 0,','        boolean_phi_values: 0,\n        known_width_branches_removed: 0,')
replace(C/'mod.rs','    if controls.enabled(OptimizationPass::DemandLiveness) {','''    if controls.enabled(OptimizationPass::ProvedWordWidths) {
        report.known_width_branches_removed =
            known_widths::fold(&mut context.func, &context.cfg, &context.domtree);
        if report.known_width_branches_removed != 0 {
            context.compute_cfg();
            context.compute_domtree();
            context.eliminate_unreachable_code(isa).map_err(backend)?;
            context.remove_constant_phis(isa).map_err(backend)?;
        }
    }
    if controls.enabled(OptimizationPass::DemandLiveness) {''')
replace(Path('hosts/gpu/src/native_artifact/codegen/control/report/mod.rs'),'    pub boolean_phi_values: usize,','    pub boolean_phi_values: usize,\n    pub known_width_branches_removed: usize,')
replace(Path('hosts/gpu/src/native_artifact/codegen/options.rs'),'    DemandLiveness,','''    DemandLiveness,
    /// Propagate unsigned widths through every current SSA input and fold only
    /// guards proved by those bounds and a dominating selected length floor.
    ProvedWordWidths,''')
replace(Path('hosts/gpu/src/native_artifact/program/image/identity.rs'),'pub const NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 312;','pub const NATIVE_PROGRAM_TYPED_IR_VERSION: u64 = 313;')
(E/'import-source-provenance.json').write_text(json.dumps(dict(parent='8e56185fb061d73263d6c4f084974b79eccb6c20',identity='IR313/work126/ABI42/image11',source_packet='R293 (all 838 source files hash verified)',borrowed_pass=['known_widths.rs','known_widths_tests.rs'],adaptation='Expose existing selected Boolean range proof, call it with no additional assumptions, preserve selected early identity/Boolean/unsigned guard passes, gate emission using fixed default compile options and a test ablation.',changed_paths=changes,original_sha256={n:hashlib.sha256((R/C/n).read_bytes()).hexdigest()for n in['known_widths.rs','known_widths_tests.rs']}),indent=2)+'\n')
print('imported proved SSA word widths; selected source unchanged;',len(set(changes)),'paths')
