from pathlib import Path
import importlib.util,json,subprocess,time,hashlib
E=Path(__file__).parent;S=Path('/private/tmp/mech-related-known-widths-compiler-20261111');B=Path('/private/tmp/mech-related-pr990-rebase-evidence-20261111');C=S/'hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup';spec=importlib.util.spec_from_file_location('audit',S/'benchmarks/related-post-gen/audit-native-link.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
rows=[]
for label in ['byte-ids','tables256','byte-tables256']:
 source=B/'ir312-runners'/label/'build/source.mec';root=E/'variant-objects'/label;root.parent.mkdir(exist_ok=True);c=[str(E/'compiler-host'),str(source),str(root)];t=time.monotonic();r=subprocess.run(c,capture_output=True,text=True);(root.parent/(label+'-compile.json')).write_text(json.dumps(dict(command=c,exit=r.returncode,seconds=time.monotonic()-t,stdout=r.stdout,stderr=r.stderr),indent=2)+'\n');assert r.returncode==0,r.stderr
 m=json.loads((root/'metadata.json').read_text());effects=[('main',m['compiled_cfg_cleanup'])]+[(x['header'],x['cleanup'])for x in m['compiled_numeric_functions']];changed=[(h,x['known_width_branches_removed'])for h,x in effects if x.get('known_width_branches_removed')];texts=[]
 for p in [root/'object.o',B/'ir312-runners'/label/'build/object.o']:
  data,secs,_=a.macho(p);sec=next(s for s in secs if s['name']=='__text');texts.append(data[sec['offset']:sec['offset']+sec['size']])
 row=dict(variant=label,removed_width_guards=changed,native_text_equal_to_IR312=texts[0]==texts[1],native_text_sha256=hashlib.sha256(texts[0]).hexdigest(),code_bytes=m['code_bytes'],numeric_functions=len(m['compiled_numeric_functions']));rows.append(row);print(row,flush=True)
(E/'width-source-variant-effects.json').write_text(json.dumps(rows,indent=2)+'\n')
