from pathlib import Path
import re,json,hashlib,shutil
OLD=Path(__file__).parent;P=Path('/private/tmp/mech-related-narrow-index-sources-20261111-v3');P.mkdir(exist_ok=False);source=Path('/private/tmp/mech-related-known-widths-compiler-20261111/benchmarks/related-post-gen/mech/related_optimized.mec').read_text();oldv=json.loads((OLD/'source-variants.json').read_text());functions={}
for m in re.finditer(r'^([a-z][a-z0-9-]*)\([^\n]*\) => \([^\n]*\) :=\n',source,re.M):
 e=source.index('.\n',m.end())+2;functions[m[1]]=source[m.start():e]
records={}
for label,x in oldv.items():
 text=Path(x['path']).read_text();clones={}
 for m in re.finditer(r'^(narrow-[a-z][a-z0-9-]*)\([^\n]*\) => \([^\n]*\) :=\n',text,re.M):
  e=text.index('.\n',m.end())+2;clones[m[1]]=text[m.start():e]
 retained={'related-offsets','related-index-posts','related-index-tags','related-index-tag-step'}
 replacements={n:'narrow-'+n if n in retained else n for n in x['cloned_functions']}
 merged=source
 for n in x['cloned_functions']:
  if n in retained:continue
  body=clones['narrow-'+n]
  for original,new in sorted(replacements.items(),key=lambda x:len(x[0]),reverse=True):
   body=re.sub(r'(?<![a-z0-9-])narrow-'+re.escape(original)+r'(?=\()',new,body)
  assert merged.count(functions[n])==1;merged=merged.replace(functions[n],body)
 extras='// Guarded U32 storage. Rows are already distinct and contain at most eight tags.\n'
 extras+='// Each bucket frequency is at most posts; large inputs retain generic original scoring.\n'
 for helper in ['narrow-word32','narrow-set32']:
  extras+=clones[helper]+'\n'
 if x['narrow_counts']:extras+='<narrow-count-index> := <([u64],[u32])>\n<narrow-counted-index> := <([u64],[u64],[u32])>\n'
 if x['narrow_postings']:extras+='<narrow-posting-index> := <([u64],[u32])>\n'
 for n in sorted(set(x['cloned_functions'])&retained):extras+=clones['narrow-'+n]+'\n'
 merged=merged.replace('posts <= 288230376151711743u64','posts <= 4294967295u64')
 merged=merged.replace('\nrelated(offsets<[u64]>, tags<[string]>)\n','\n'+extras+'\nrelated(offsets<[u64]>, tags<[string]>)\n')
 assert merged.count('subset-indexed(offsets, ids, vocabulary, posts, prepared.1)')==1
 path=P/label/'source.mec';path.parent.mkdir();path.write_text(merged);records[label]=dict(**{k:v for k,v in x.items()if k not in ['path','sha256','cloned_functions']},path=str(path),sha256=hashlib.sha256(merged.encode()).hexdigest(),only_cloned_shared_helpers=sorted(set(x['cloned_functions'])&retained),guard_moved_to_existing_eligibility=True,large_inputs_use_existing_generic_scoring=True,lines=len(merged.splitlines()))
(P/'source-variants.json').write_text(json.dumps(records,indent=2)+'\n');shutil.copyfile(__file__,P/'prepare-compact-sources.py');print([(k,v['lines'])for k,v in records.items()])
