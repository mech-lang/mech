from pathlib import Path
import hashlib,json,os,subprocess,time,shutil
E=Path(__file__).parent;B=Path('/private/tmp/mech-related-pr990-rebase-evidence-20261111');S=Path('/private/tmp/mech-related-narrow-index-compiler-20261111');read=lambda p:json.loads(Path(p).read_text());P=E/'regressions';P.mkdir(exist_ok=False)
def run(c,p):
 c=list(map(str,c));t=time.monotonic();r=subprocess.run(c,cwd=S,env={**os.environ,'RUSTC_BOOTSTRAP':'1'},capture_output=True,text=True);p.write_text(json.dumps(dict(command=c,exit=r.returncode,seconds=time.monotonic()-t,stdout=r.stdout,stderr=r.stderr,qualification_only=True),indent=2)+'\n');print(p.name,r.returncode,flush=True);assert r.returncode==0,r.stdout[-5000:]+r.stderr[-5000:];return r
comparisons=[]
for kind,n in [('scalar',128),('one-kib',5)]:
 c=read(B/'ir312-regression-controls'/f'{kind}-build.json')['command']
 for i,arg in enumerate(c[:-1]):
  if arg=='--extern'and c[i+1].startswith('mech_gpu='):c[i+1]='mech_gpu='+str(E/'compiler/libmech_gpu.rlib')
 c[c.index('-o')+1]=str(P/kind);c+=['-L','dependency='+str(E/'compiler')];run(c,P/f'{kind}-build.json')
 c=read(B/'ir312-regression-controls'/f'{kind}-run.json')['command'];c[0]=str(P/kind);run(c,P/f'{kind}-run.json')
 def rows(p):return [{k:v for k,v in json.loads(l).items()if k not in['seconds','seconds_per_evaluation']}for l in read(p)['stdout'].splitlines()if l.startswith('{')]
 a=rows(P/f'{kind}-run.json');b=rows(B/'ir312-regression-controls'/f'{kind}-run.json');assert len(a)==len(b)==n;changes=[dict(row=i,before=y,after=x)for i,(x,y)in enumerate(zip(a,b))if x!=y];comparisons.append(dict(kind=kind,rows=n,all_non_timing_fields_exact=not changes,changes=changes));assert not changes,changes
(P/'comparison.json').write_text(json.dumps(comparisons,indent=2)+'\n');print('133 exact rows including resources',flush=True)
