from pathlib import Path
import subprocess,time,json
E=Path(__file__).parent;S=Path('/private/tmp/mech-related-narrow-index-compiler-20261111');P=Path('/private/tmp/mech-related-narrow-index-sources-20261111-v3');variants={'baseline':S/'benchmarks/related-post-gen/mech/related_optimized.mec',**{k:Path(v['path'])for k,v in json.loads((P/'source-variants.json').read_text()).items()},'fixture':E/'narrow-scan-fixture.mec'};out={}
for n,src in variants.items():
 root=E/'objects'/n;root.parent.mkdir(exist_ok=True);c=[str(E/'compiler-host'),str(src),str(root)];t=time.monotonic();r=subprocess.run(c,capture_output=True,text=True);(root.parent/(n+'-compile.json')).write_text(json.dumps(dict(command=c,exit=r.returncode,seconds=time.monotonic()-t,stdout=r.stdout,stderr=r.stderr),indent=2)+'\n');print(n,r.returncode,r.stdout[-800:],r.stderr[-1500:],flush=True);assert r.returncode==0
 m=json.loads((root/'metadata.json').read_text());d=json.loads((root/'descriptor.json').read_text())['descriptor'];partial=[];trees=[]
 for i,reg in enumerate(d['closed_tails']['regions']):
  p=reg['numeric']
  if p and p['phase']and p['exits']:partial.append(dict(id=i,header=reg['tail']['header'],exits=p['exits']))
  if reg['numeric_tree']:trees.append(reg['tail']['header'])
 out[n]=dict(code_bytes=m['code_bytes'],stack_bytes=m['stack_bytes'],numeric_functions=len(m['compiled_numeric_functions']),partial_phases=partial,complete_tree_headers=trees)
(E/'selection-effects.json').write_text(json.dumps(out,indent=2)+'\n')
print('selection effect summary',{k:dict(functions=v['numeric_functions'],complete_trees=len(v['complete_tree_headers']),partial_phases=len(v['partial_phases']))for k,v in out.items()},flush=True)
