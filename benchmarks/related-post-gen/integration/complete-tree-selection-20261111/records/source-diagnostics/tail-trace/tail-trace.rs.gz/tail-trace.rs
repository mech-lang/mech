//! Reconcile a closed generated Tail to the SAME invocation account.
//! The generated body consumes finite native fuel; this never executes a loop.
use crate::native_artifact::NativeExecutionPhase;
use crate::native_artifact::program::prepare::numeric_plan::ExitKind;
use crate::native_artifact::program::runtime::invocation::Invocation;
use crate::native_artifact::program::runtime::{
    NativeProgramExecutionError as Error, amount, invalid,
};

#[derive(Clone, Copy)]
pub(super) enum Region {
    Tail(usize),
    Segment(usize),
}
pub(in crate::native_artifact::program::runtime) struct State {
    pub(super) region: Region,
    pub(super) used: (u64, u64),
    pub(super) remaining: (u64, u64),
    pub(super) entry: u32,
    pub(super) partial: bool,
    pub(super) native_fuel: Option<mech_engine::native_artifact::NativeWorkerNativeFuel>,
}
impl State {
    pub(super) fn same_budget(
        &self,
        budget: &mech_engine::native_artifact::NativeLibraryWorkBudget,
    ) -> bool {
        budget.used() == self.used
            && match &self.native_fuel {
                Some(fuel) => fuel.shares_account(budget) && fuel.allowance() == self.remaining,
                None => budget.unscoped_remaining() == Some(self.remaining),
            }
    }
}
impl Invocation<'_, '_, '_> {
    pub(super) fn record_worker_numeric(&mut self, compute: u64) -> Result<(), Error> {
        self.state.stats.parallel_numeric_regions = self
            .state
            .stats
            .parallel_numeric_regions
            .checked_add(1)
            .ok_or_else(|| invalid("parallel numeric region count overflow"))?;
        self.state.stats.parallel_numeric_work = self
            .state
            .stats
            .parallel_numeric_work
            .checked_add(compute)
            .ok_or_else(|| invalid("parallel numeric debit count overflow"))?;
        Ok(())
    }
    pub(in crate::native_artifact::program::runtime) fn begin_closed_tail(
        &mut self,
        site: usize,
        args: [u64; 3],
    ) -> Result<Option<u64>, Error> {
        let layout = &self.descriptor.metadata().closed_tails;
        let region = layout
            .initializers
            .get(site)
            .copied()
            .flatten()
            .filter(|_| self.state.control.previous == Some(site as u32))
            .or_else(|| {
                layout.sites.get(site).copied().flatten().filter(|&id| {
                    let region = &layout.regions[id];
                    region.tail.header() as usize == site
                        && region
                            .numeric
                            .as_ref()
                            .is_some_and(|proof| !proof.exits.is_empty())
                        && self.state.control.previous == Some(region.tail.latch())
                        && self.numeric_prepaid.is_none()
                })
            })
            .ok_or_else(|| {
                invalid("closed Tail outside initializer or cold continuation header")
            })?;
        self.begin_closed_region(site, args, region)
    }
    pub(in crate::native_artifact::program::runtime) fn begin_closed_region(
        &mut self,
        _site: usize,
        args: [u64; 3],
        region: usize,
    ) -> Result<Option<u64>, Error> {
        let proof = &self.descriptor.metadata().closed_tails.regions[region];
        if args != [0; 3]
            || self.closed_tail.is_some()
            || self.window_region.is_some()
            || (self.state.consumed
                && proof.map.is_none()
                && proof.numeric.is_none()
                && proof.captures.is_none())
        {
            return Err(invalid("duplicate or malformed closed Tail entry"));
        }
        let layout = &self.descriptor.metadata().closed_tails;
        let proof = &layout.regions[region];
        let primary = layout.sites[proof.tail.header() as usize];
        if primary != Some(region)
            && self
                .numeric_prepaid
                .is_some_and(|route| Some(route.region) != primary)
        {
            // A paid route belongs only to its exact primary. Without a paid
            // route, an ordinary child may take its independently proved loan:
            // the entry/current-parent checks and fresh fuel admission below
            // still apply, and no original source work receives credit.
            trace_tail_event(region, proof.tail.header(), 0, _site, 0); return Ok(Some(0));
        }
        if self.numeric_prepaid.is_some()
            && proof
                .numeric
                .as_ref()
                .is_some_and(|proof| !proof.exits.is_empty())
        {
            trace_tail_event(region, proof.tail.header(), 1, _site, 0); return Ok(Some(0));
        }
        // A complete secondary contains only its root and descendants. Their
        // validated IDs exceed every paid ancestor when this is negative.
        // Conservatively refuse a possible overlap, including unrelated older
        // IDs, without scanning source inventories or granting source credit.
        if primary != Some(region)
            && self
                .numeric_prepaid
                .is_some_and(|route| route.may_include_iteration(Some(proof.iteration)))
        {
            trace_tail_event(region, proof.tail.header(), 2, _site, 0); return Ok(Some(0));
        }
        if self.state.control.current != Some(proof.iteration)
            || self.progress[proof.iteration as usize * 2..][..2] != [0, 1]
        {
            return Err(invalid("closed Tail outside active invocation"));
        }
        if (proof.numeric.is_some() || proof.captures.is_some())
            && proof
                .tail
                .parent()
                .is_some_and(|parent| self.progress[parent as usize * 2 + 1] != 1)
        {
            return Err(invalid("numeric child has no suspended active parent"));
        }
        if let Some(tree) = &proof.numeric_tree {
            if tree
                .nodes
                .iter()
                .skip(1)
                .any(|node| self.progress[node.iteration as usize * 2..][..2] != [0, 0])
            {
                trace_tail_event(region, proof.tail.header(), 3, _site, 0); return Ok(Some(0));
            }
        }
        // Covers entry/exit metadata and all exceptional cleanup dispatch arms.
        self.state.control.work.charge(
            NativeExecutionPhase::Setup,
            amount(layout.regions.len(), 128, 1024)?,
        )?;
        if proof.borrowed.is_some_and(|region| {
            !self
                .borrowed_strings
                .as_ref()
                .is_some_and(|state| state.active && state.region == region)
        }) {
            trace_tail_event(region, proof.tail.header(), 4, _site, 0); return Ok(Some(0));
        }
        let Some(mut remaining) = self.state.library.unscoped_remaining() else {
            trace_tail_event(region, proof.tail.header(), 5, _site, 0); return Ok(Some(0));
        };
        if proof.numeric.is_some() {
            if !self.begin_numeric_views(region)? {
                trace_tail_event(region, proof.tail.header(), 6, _site, 0); return Ok(Some(0));
            }
            // Entry validation spent on this SAME ledger. Fund the native body
            // from the post-entry remainder, never the earlier preview.
            remaining = self
                .state
                .library
                .unscoped_remaining()
                .ok_or_else(|| invalid("numeric entry changed account scope"))?;
        }
        if proof.captures.is_some() {
            if !self.begin_captured_numeric_views(region)? {
                trace_tail_event(region, proof.tail.header(), 7, _site, 0); return Ok(Some(0));
            }
            remaining = self
                .state
                .library
                .unscoped_remaining()
                .ok_or_else(|| invalid("numeric capture entry changed account scope"))?;
        }
        let native_fuel =
            if self.worker.is_some() && (proof.numeric.is_some() || proof.captures.is_some()) {
                let Some(fuel) =
                    self.state
                        .library
                        .reserve_native_worker_fuel()
                        .map_err(|error| Error::Collection {
                            origin: proof.tail.origin(),
                            error,
                        })?
                else {
                    trace_tail_event(region, proof.tail.header(), 8, _site, 0); return Ok(Some(0));
                };
                remaining = fuel.allowance();
                Some(fuel)
            } else {
                None
            };
        if proof.map.is_some() {
            let Some(words) = self.begin_closed_map(region)? else {
                trace_tail_event(region, proof.tail.header(), 9, _site, 0); return Ok(Some(0));
            };
            for (index, word) in words.into_iter().enumerate() {
                self.write_borrowed_word(index, word)?;
            }
        } else {
            self.write_borrowed_word(0, remaining.0)?;
            self.write_borrowed_word(1, remaining.1)?;
        }
        self.closed_tail = Some(State {
            region: Region::Tail(region),
            used: self.state.library.used(),
            remaining,
            entry: self
                .state
                .control
                .previous
                .ok_or_else(|| invalid("closed Tail has no current predecessor"))?,
            partial: false,
            native_fuel,
        });
        trace_tail_event(region, proof.tail.header(), 14, _site, 0);
        Ok(Some(1))
    }

    pub(in crate::native_artifact::program::runtime) fn end_closed_tail(
        &mut self,
        site: usize,
        args: [u64; 3],
    ) -> Result<Option<u64>, Error> {
        let mut state = self
            .closed_tail
            .take()
            .ok_or_else(|| invalid("closed Tail exit without entry"))?;
        let descriptor = self.descriptor;
        let layout = &descriptor.metadata().closed_tails;
        let Region::Tail(region) = state.region else {
            return Err(invalid("closed Tail exit received a parent segment loan"));
        };
        trace_tail_event(region, layout.regions[region].tail.header(), 15, site, args[2]);
        if layout.regions[region].numeric_tree.is_some() {
            return self.end_numeric_tree(region, state, site, args);
        }
        let proof = &layout.regions[region];
        if self.state.control.previous != Some(state.entry)
            || self.state.control.current != Some(proof.iteration)
            || self.progress[proof.iteration as usize * 2..][..2] != [0, 1]
            || (proof.map.is_none() && !state.same_budget(&self.state.library))
        {
            return Err(invalid(
                "closed Tail account or entry changed during native execution",
            ));
        }
        if (proof.numeric.is_some() || proof.captures.is_some())
            && proof
                .tail
                .parent()
                .is_some_and(|parent| self.progress[parent as usize * 2 + 1] != 1)
        {
            return Err(invalid("numeric child's suspended parent changed"));
        }
        let (compute, comparison, traversals) = if proof.map.is_some() {
            if args[1] != 0 {
                return Err(invalid("closed map comparison lane changed"));
            }
            (0, 0, self.reconcile_closed(region, args[0], args[2])?)
        } else {
            let compute = state
                .remaining
                .0
                .checked_sub(args[0])
                .ok_or_else(|| invalid("closed Tail compute fuel was renewed"))?;
            let comparison = state
                .remaining
                .1
                .checked_sub(args[1])
                .ok_or_else(|| invalid("closed Tail comparison fuel was renewed"))?;
            let traversals =
                if let Some(phase) = proof.numeric.as_ref().and_then(|p| p.phase.as_ref()) {
                    let mut expected = (0u64, 0u64);
                    let mut root = 0;
                    for (index, debit) in phase.loops.iter().enumerate() {
                        let count = self.read_borrowed_word(2 + debit.counter)?;
                        if index == 0 {
                            root = count;
                        }
                        expected.0 = count
                            .checked_mul(debit.compute)
                            .and_then(|n| expected.0.checked_add(n))
                            .ok_or_else(|| invalid("phase compute settlement overflows"))?;
                        expected.1 = count
                            .checked_mul(debit.comparison)
                            .and_then(|n| expected.1.checked_add(n))
                            .ok_or_else(|| invalid("phase comparison settlement overflows"))?;
                    }
                    if expected != (compute, comparison) {
                        return Err(invalid("phase fuel differs from actual traversal debits"));
                    }
                    root
                } else {
                    let traversals = compute / proof.compute;
                    if compute % proof.compute != 0
                        || traversals.checked_mul(proof.comparison) != Some(comparison)
                    {
                        return Err(invalid(
                            "closed Tail fuel differs from proved body envelope",
                        ));
                    }
                    traversals
                };
            (compute, comparison, traversals)
        };
        let previous = match args[2] {
            0 if site == proof.tail.exit() as usize && (traversals > 0 || state.partial) => proof.tail.finish(),
            // No fuel for a complete body: reconcile before the ordinary header
            // admits any further instruction. No allowance is refilled.
            1 if site == proof.tail.header() as usize => {
                if traversals == 0 && !state.partial {
                    state.entry
                } else {
                    proof.tail.latch()
                }
            }
            4 if site == proof.tail.header() as usize && self.prefix.is_some() => {
                if traversals == 0 {
                    state.entry
                } else {
                    proof.tail.latch()
                }
            }
            2 | 3 if proof.numeric.as_ref().map_or_else(
                || layout.sites.get(site).copied().flatten() == Some(region),
                |proof| proof.sites.binary_search(&site).is_ok(),
            ) => site as u32,
            5 if proof.numeric.as_ref().and_then(|p| p.action(site)).is_some_and(|a| matches!(a,
                crate::native_artifact::program::prepare::readonly_numeric::Operation::Write { .. }
                | crate::native_artifact::program::prepare::readonly_numeric::Operation::Append { .. }
                | crate::native_artifact::program::prepare::readonly_numeric::Operation::AppendLeBytes { .. })) => site as u32,
            6 if (traversals > 0 || state.partial) && self.numeric_prepaid.is_none() => proof.numeric.as_ref()
                .and_then(|proof| proof.exits.iter().find(|exit| exit.to == site && matches!(exit.kind, ExitKind::Unsupported)))
                .map(|exit| exit.from as u32)
                .ok_or_else(|| invalid("numeric cold exit is outside its exact source edge"))?,
            7 if (traversals > 0 || state.partial) && self.numeric_prepaid.is_none() => proof.numeric.as_ref()
                .and_then(|proof| proof.exits.iter().find(|exit| exit.to == site && !matches!(exit.kind, ExitKind::Unsupported)))
                .map(|exit| exit.from as u32)
                .ok_or_else(|| invalid("numeric fuel exit is outside its exact source edge"))?,
            _ => return Err(invalid("closed Tail exit outside its proved boundary")),
        };
        let worker_funded = state.native_fuel.is_some();
        if let Some(fuel) = state.native_fuel.take() {
            fuel.finish(compute, comparison)
                .map_err(|error| Error::Collection {
                    origin: descriptor.metadata().plan.blocks()[site].origin(),
                    error,
                })?;
            self.record_worker_numeric(compute)?;
        }
        self.synchronize_numeric_carrier(region, site, args[2])?;
        if !worker_funded {
            self.state
                .library
                .charge(compute, comparison)
                .map_err(|error| Error::Collection {
                    origin: descriptor.metadata().plan.blocks()[site].origin(),
                    error,
                })?;
        }
        // This is one proved bulk transition, not fabricated/replayed per-op
        // visits. The report counts the remaining actual admitted CFG visits.
        self.state.control.previous = Some(previous);
        if matches!(args[2], 6 | 7) {
            let exit = proof
                .numeric
                .as_ref()
                .unwrap()
                .exits
                .iter()
                .find(|exit| exit.to == site)
                .unwrap();
            let (active, deepest) = match exit.kind {
                ExitKind::Unsupported if args[2] == 6 => {
                    let active = descriptor.metadata().plan.blocks()[exit.from]
                        .iteration()
                        .ok_or_else(|| invalid("cold continuation lacks its active Tail"))?;
                    (active, active)
                }
                ExitKind::ChildInitialize { iteration } | ExitKind::ChildHeader { iteration }
                    if args[2] == 7 =>
                {
                    let parent = descriptor.metadata().plan.iterations()[iteration as usize]
                        .as_ref()
                        .parent()
                        .ok_or_else(|| invalid("fuel continuation lacks its paid parent"))?;
                    let active = if matches!(exit.kind, ExitKind::ChildHeader { .. }) {
                        iteration
                    } else {
                        parent
                    };
                    (active, parent)
                }
                _ => return Err(invalid("numeric continuation differs from its exit kind")),
            };
            // Native synchronous Tail children have no hidden counted-loop or
            // collection state. Export/finalization and all fallible charges
            // finish before restoring their exact lexical activation chain.
            for child in proof
                .numeric
                .as_ref()
                .unwrap()
                .phase
                .as_ref()
                .unwrap()
                .loops
                .iter()
                .skip(1)
            {
                if self.progress[child.iteration as usize * 2..][..2] != [0, 0] {
                    return Err(invalid("fuel continuation found an active ordinary child"));
                }
            }
            let continuation = self.native_parent_continuation(region, active)?;
            #[cfg(all(test, feature = "canonical-native-program"))]
            let previous_marker = self.parent_continuation.current();
            let mut at = active;
            loop {
                self.progress[at as usize * 2..][..2].copy_from_slice(&[0, 1]);
                if at == proof.iteration {
                    break;
                }
                at = descriptor.metadata().plan.iterations()[at as usize]
                    .as_ref()
                    .parent()
                    .ok_or_else(|| invalid("fuel continuation escapes its native root"))?;
            }
            self.state.control.current = Some(active);
            if let Some(continuation) = continuation {
                self.parent_continuation = continuation;
            }
            #[cfg(all(test, feature = "canonical-native-program"))]
            super::super::composition_tests::observe::parent_marker_handoff(
                proof.iteration,
                active,
                previous_marker,
                self.parent_continuation.current(),
                args[2],
            );
            self.numeric_prepaid = Some(super::NumericPrepaid { region, deepest });
            self.state.scalar_path = None;
        }
        if proof.map.is_some() && args[2] == 0 {
            self.state.map_owners.closed_exit = Some((previous, proof.tail.exit()));
        }
        self.state.consumed = proof.numeric.is_some() && !matches!(args[2], 2 | 5);
        if args[2] == 0
            && proof.numeric.as_ref().is_some_and(|numeric| {
                !numeric.scalar_inputs.is_empty() || !numeric.scalar_outputs.is_empty()
            })
        {
            let bank = self
                .state
                .buffer_frames
                .scalar_bank_pointer(&descriptor.metadata().buffer_frames)?;
            self.write_borrowed_word(2, bank)?;
        }
        if args[2] == 3 {
            // Arithmetic/assertion/rejection exits have no leaf callback to consume the
            // owner loan. Drop it before the existing typed error is returned.
            self.borrowed_strings = None;
        }
        Ok(None)
    }

    /// Continue the already prepaid traversal after its one-time fallible
    /// materialization. The new loan is the SAME post-materialization account;
    /// no source header/body allowance is renewed or charged twice.
    pub(super) fn resume_numeric_after_write(
        &mut self,
        region: usize,
        site: usize,
    ) -> Result<(), Error> {
        if self.closed_tail.is_some() || self.state.control.previous != Some(site as u32) {
            return Err(invalid(
                "numeric materialization resume outside settled site",
            ));
        }
        let mut remaining = self
            .state
            .library
            .unscoped_remaining()
            .ok_or_else(|| invalid("numeric materialization changed account scope"))?;
        let native_fuel = if self.worker.is_some() {
            let fuel = self
                .state
                .library
                .reserve_native_worker_fuel()
                .map_err(|error| Error::Collection {
                    origin: self.descriptor.metadata().plan.blocks()[site].origin(),
                    error,
                })?
                .ok_or_else(|| invalid("numeric worker materialization lost its account"))?;
            remaining = fuel.allowance();
            Some(fuel)
        } else {
            None
        };
        self.write_borrowed_word(0, remaining.0)?;
        self.write_borrowed_word(1, remaining.1)?;
        if let Some(tree) = &self.descriptor.metadata().closed_tails.regions[region].numeric_tree {
            for node in 0..tree.nodes.len() {
                self.write_borrowed_word(2 + tree.traversals(node), 0)?;
            }
            let bank = self
                .state
                .buffer_frames
                .scalar_bank_pointer(&self.descriptor.metadata().buffer_frames)?;
            self.write_borrowed_word(2, bank)?;
        }
        if let Some(phase) = self.descriptor.metadata().closed_tails.regions[region]
            .numeric
            .as_ref()
            .and_then(|p| p.phase.as_ref())
        {
            for debit in &phase.loops {
                self.write_borrowed_word(2 + debit.counter, 0)?;
            }
        }
        self.closed_tail = Some(State {
            region: Region::Tail(region),
            used: self.state.library.used(),
            remaining,
            entry: site as u32,
            partial: true,
            native_fuel,
        });
        Ok(())
    }
}

fn trace_tail_event(id: usize, header: u32, reason: usize, site: usize, mode: u64) {
    static COUNTS: [std::sync::atomic::AtomicU64; 65536] = [const { std::sync::atomic::AtomicU64::new(0) }; 65536];
    let slot=id*16+reason;
    if slot>=COUNTS.len() {return;}
    let n=COUNTS[slot].fetch_add(1, std::sync::atomic::Ordering::Relaxed)+1;
    if n.is_power_of_two() {eprintln!("TAIL_EVENT id={id} header={header} reason={reason} site={site} mode={mode} n={n}");}
}
