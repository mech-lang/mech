from pathlib import Path
import collections,json,re,subprocess
E=Path(__file__).parent;P=E/'profile';out={}
for label in ['baseline','counts32','counts-postings32']:
 s=(P/label/'native.sample.txt').read_text();body=s.split('Sort by top of stack, same collapsed (when >= 5):\n',1)[1].split('Binary images',1)[0];rows=[]
 for line in body.splitlines():
  m=re.match(r'\s*(.+?)\s+\(in (.+?)\)\s+(\d+)\s*$',line)
  if m:rows.append(dict(symbol=m[1],image=m[2],reported_leaf_samples=int(m[3])))
 names=[r['symbol']for r in rows];r=subprocess.run(['/opt/homebrew/opt/llvm/bin/llvm-cxxfilt','-n'],input='\n'.join(names)+'\n',capture_output=True,text=True,check=True);names=dict(zip(names,r.stdout.splitlines()));groups=collections.Counter()
 for row in rows:
  row['name']=names[row['symbol']];n=row['name'];image=row['image']
  if n.startswith('mech_canonical_program_entry_v1'):g='compiled_Mech_native_code'
  elif any(w in n for w in ['ulock_wait','psynch_mutexwait','__semwait_signal','mach_msg2_trap','__workq_kernreturn']):g='OS_waits_including_idle_main_and_worker_joins'
  elif 'dyld' in image:g='startup_loader'
  elif any(w in n for w in ['lock_escrow','charge_compute','next_after_native','observe_control_work','NativeLibraryWorkBudget','ControlWorkContext','ResidentBudgetMeter']):g='host_work_accounting'
  elif any(w in n for w in ['pthread','thread_start','bsdthread','sigaltstack']):g='thread_lifecycle_or_scheduling'
  elif 'mech_'in n:g='other_Mech_host_runtime'
  else:g='other_system_and_allocator'
  row['group']=g;groups[g]+=row['reported_leaf_samples']
 active=sum(n for g,n in groups.items()if g not in['OS_waits_including_idle_main_and_worker_joins','startup_loader']);top=[r for r in rows if r['group']not in['OS_waits_including_idle_main_and_worker_joins','startup_loader']]
 out[label]=dict(collapsed_report_threshold=5,reported_leaf_samples=sum(groups.values()),reported_groups=dict(groups),active_reported_leaf_samples=active,native_fraction_of_reported_nonwait_nonloader_leaves=groups['compiled_Mech_native_code']/active,top_active_reported_leaves=top[:40],all_reported_rows=rows,diagnostic_only=True,not_CPU_or_wall_time_share=True,inclusive_stacks_overlap=True,short_lived_workers_and_OS_sampling_disturbance=True)
(P/'analysis.json').write_text(json.dumps(out,indent=2)+'\n')
for label,d in out.items():
 print(label,d['reported_groups'],'native_active_reported_fraction',d['native_fraction_of_reported_nonwait_nonloader_leaves'])
 for r in d['top_active_reported_leaves'][:15]:print(r['reported_leaf_samples'],r['name'])
