from pathlib import Path
import json,hashlib,shutil,subprocess,datetime,importlib.util
E=Path(__file__).parent;S=Path('/private/tmp/mech-related-narrow-index-compiler-20261111');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text());D=E/'frozen-inputs';D.mkdir(exist_ok=True);inp=Path('/private/tmp/mech-related-current-input-fixtures-20261107/posts.json');shutil.copy2(inp,D/'posts.json');assert sha(D/'posts.json')=='500530b81cb81c5b1a5e48aa30de6a89ba0a350460ad826c4c7bb023e6e46cb8'
lat=read(E/'latency-config.json');notes=[]
for v in lat['implementations']:
 if v['kind']!='upstream':continue
 R=D/v['name'];R.mkdir(exist_ok=True);original=dict(v);p=Path(v['executable']);q=R/p.name;shutil.copy2(p,q);assert sha(q)==v['executable_sha256'];v['executable']=str(q);v['original_executable']=str(p)
 for field in['source','receipt']:
  if field in v:
   p=Path(v[field]);assert p.is_file(),(v['name'],field,p);q=R/(field+p.suffix);shutil.copy2(p,q);assert sha(q)==v[field+'_sha256'];v['original_'+field]=str(p);v[field]=str(q)
 notes.append(dict(name=v['name'],binary_sha256=v['executable_sha256'],frozen_executable=v['executable'],original_executable=original['executable'],source_or_receipt_availability_note=v.get('availability_note')))
(E/'latency-config-frozen.json').write_text(json.dumps(lat,indent=2)+'\n')
res=read(E/'existing-resources.json');new=read(E/'metrics/metrics-config.json');res['implementations']+= [v for v in new['implementations']if v['kind']=='mech'];res['prospective_performance_rule']=str(E/'prospective-rule.json');res['authoritative_latency_comparison']=str(E/'first/latency.json');assert len(res['implementations'])==29
# Only relocate the uninstrumented oracle; the resource controls retain their separately verified executable pins.
ref=next(v for v in lat['implementations']if v['name']==res['reference']);res['implementations']=[ref if v['name']==res['reference']else v for v in res['implementations']]
prior_resources={v['name']:v for v in read(Path('/private/tmp/mech-related-pr990-rebase-evidence-20261111/ir312-first-v2/resources-v2.json'))['implementations']}
for v in res['implementations']:
 if v['name'] in prior_resources:
  prior=prior_resources[v['name']]
  assert sha(v['executable'])==prior['executable_sha256'],v['name']
  for field in ['executable_sha256','source_sha256','receipt_sha256','executable_file_bytes']:
   if field in prior and field not in v:v[field]=prior[field]
 if 'executable_sha256' not in v:
  receipt=read(v['receipt']);assert receipt['exit']==0
  assert sha(v['executable'])==receipt['executable_sha256']
  assert sha(v['source'])==receipt['bundle']['source.mec']['sha256']
  v.update(executable_sha256=receipt['executable_sha256'],source_sha256=sha(v['source']),receipt_sha256=sha(v['receipt']),executable_file_bytes=Path(v['executable']).stat().st_size)
 assert sha(v['executable'])==v['executable_sha256'],v['name']
(E/'resources-config.json').write_text(json.dumps(res,indent=2)+'\n');(E/'reference-freeze.json').write_text(json.dumps(notes,indent=2)+'\n')
current=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip();assert subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=S,text=True)==''
spec=importlib.util.spec_from_file_location('b',S/'benchmarks/related-post-gen/build-compiler.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);files=b.source_inventory(S)
for label in['compiler','runtime','tests']:
 inv=read(E/label/'source-inventory.json');assert files==inv['files'],label
Q=E/'first';Q.mkdir(exist_ok=False);(Q/'source-freeze.json').write_text(json.dumps(dict(commit=current,compiler_source_sha256=read(E/'compiler/build.json')['source_sha256'],input_sha256=sha(D/'posts.json'),latency_config_sha256=sha(E/'latency-config-frozen.json'),resources_config_sha256=sha(E/'resources-config.json'),rule_sha256=sha(E/'prospective-rule.json'),UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),all_frozen_libraries_and_binaries_pinned=True),indent=2)+'\n');print('source',current,'28 latency variants;29 resource variants; fixed input and22 Rust copies verified')
