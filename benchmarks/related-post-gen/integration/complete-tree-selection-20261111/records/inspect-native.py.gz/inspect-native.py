from pathlib import Path
import importlib.util,json,hashlib
E=Path(__file__).parent;S=Path('/private/tmp/mech-related-narrow-index-compiler-20261111');sp=importlib.util.spec_from_file_location('audit',S/'benchmarks/related-post-gen/audit-native-link.py');a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a)
def text(p):
 d,s,_=a.macho(p);s=next(x for x in s if x['name']=='__text');return d[s['offset']:s['offset']+s['size']]
p=Path('/private/tmp/mech-related-known-widths-20261111/runner/build/object.o');parent=text(p);rows=[]
for label in ['baseline','counts32','postings32','counts-postings32']:
 d=E/'runners'/label;b=d/'build';m=json.loads((b/'metadata.json').read_text());t=text(b/'object.o');rows.append(dict(variant=label,code_bytes=m['code_bytes'],reported_module_stack_bound_bytes=m['stack_bytes'],native_text_bytes=len(t),native_text_sha256=hashlib.sha256(t).hexdigest(),native_text_equal_to_IR313_selected_source=t==parent,numeric_functions=len(m['compiled_numeric_functions']),executable_bytes=(d/'runner-aot').stat().st_size,executable_sha256=hashlib.sha256((d/'runner-aot').read_bytes()).hexdigest(),source_sha256=hashlib.sha256((b/'source.mec').read_bytes()).hexdigest()))
(E/'native-code-inspection.json').write_text(json.dumps(rows,indent=2)+'\n')
for r in rows:print(r)
