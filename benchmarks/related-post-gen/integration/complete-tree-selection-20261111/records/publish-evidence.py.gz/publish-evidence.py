from pathlib import Path
import gzip,hashlib,json,subprocess
E=Path(__file__).parent;S=Path('/private/tmp/mech-related-narrow-index-compiler-20261111');D=S/'benchmarks/related-post-gen/integration/complete-tree-selection-20261111';D.mkdir(exist_ok=False)
read=lambda p:json.loads(Path(p).read_text());sha=lambda b:hashlib.sha256(b).hexdigest();files=[];seen=set()
def add(p,rel=None):
 p=Path(p)
 if not p.is_file():return
 rel=Path(rel)if rel else p.relative_to(E)
 if str(rel)in seen:return
 seen.add(str(rel));b=p.read_bytes();q=D/'records'/Path(str(rel)+'.gz');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(gzip.compress(b,mtime=0));files.append(dict(path=str(q.relative_to(D)),sha256=sha(q.read_bytes()),uncompressed_sha256=sha(b),uncompressed_bytes=len(b),original_path=str(p)))
for p in sorted(E.glob('*')):
 if p.suffix in ['.json','.py','.mec']:add(p)
for n in ['compiler','runtime','tests','qualification','regressions','first','metrics']:
 for p in sorted((E/n).rglob('*.json')):
  # Raw output values are covered by equality receipts and output hashes;
  # retain reports, manifests and every sample, without repeating fixture data.
  if p.name in ['output.json','catalog-profile.json']or p.parent.name in ['latency','resources']:continue
  if n=='first'and len(p.relative_to(E/n).parts)>1:continue
  add(p)
 for p in sorted((E/n).glob('*.py')):add(p)
for n in ['baseline','counts32','postings32','counts-postings32']:
 d=E/'runners'/n
 for p in sorted(d.glob('*.json')):
  if p.name!='output.json':add(p)
 add(d/'runner.rs');add(d/'build/source.mec')
 for k in ['metadata.json','frame-summary.json','descriptor.json']:add(d/'build'/k)
 for p in sorted((d/'edges').rglob('*.json')):add(p)
for p in sorted((E/'profile').rglob('*')):
 if p.is_file()and (p.suffix in ['.json','.rs','.txt'])and p.name!='output.json'and'build'not in p.relative_to(E/'profile').parts:add(p)
# Preserve initial failed broad selection, including exact source and resource regression.
old=Path('/private/tmp/mech-related-complete-tree-selection-20261111')
for p in sorted(old.glob('*')):
 if p.suffix in ['.json','.py','.mec','.rs']:add(p,Path('first-broad-failures')/p.relative_to(old))
for n in ['compiler','runtime','tests','tests-first-build','qualification','regressions']:
 for p in sorted((old/n).glob('*.json')):add(p,Path('first-broad-failures')/p.relative_to(old))
# Prior source prototypes and diagnostic host traces are separate, never timed finalists.
p2=Path('/private/tmp/mech-related-narrow-index-sources-20261111-v2')
for n in ['decline-trace','tail-trace','counts-profile']:
 for p in sorted((p2/n).glob('*')):
  if p.is_file()and p.suffix in ['.json','.rs','.txt']and p.name!='output.json':add(p,Path('source-diagnostics')/n/p.name)
p3=Path('/private/tmp/mech-related-narrow-index-sources-20261111-v3')
for p in sorted(p3.glob('*')):
 if p.is_file()and p.suffix in ['.py','.json']:add(p,Path('source-preparation')/p.name)
a=read(E/'first/paired-analysis.json');static=read(E/'native-code-inspection.json');reb=read(E/'rebase-source-identity.json')
summary=dict(schema='mech.related-post-gen.complete-readonly-tree-selection.v1',compiler=dict(identity='IR314/work126/ABI42/image11',measured_commit='09d30f06f43d40724ad8ed8fcb486cf09c94393b',rebased_commit=reb['rebased_compiler_commit'],PR973_base=reb['current_PR973_base'],rebase_source_identity=reb,backend='Cranelift 0.131.3 with verified DEFLATE backend patches',required_LLVM_dependency=False),decision=dict(compiler_gap_fixed=True,selected_source_unchanged=True,source_variants_experimental=True,latency_win_demonstrated=False,confirmation_not_run='No predeclared source candidate demonstrates first latency improvement against both same-compiler baseline and published parent.',goal_met=False,whole_process_is_gate=False),qualification=dict(compiler_contracts=505,all_484_selected_IR308_names_retained=True,scalar_non_timing_exact_rows=128,DEFLATE_non_timing_exact_rows=5,original_restored_actual5000=True,linked_exact_outputs=128,same_Object_audits=4,latency_exact_outputs=868,resource_exact_outputs=203,current_same_Object_diagnostic_profiles=3),analysis=a,native_code=static,initial_broad_failure=dict(compiler_contracts_passed=502,cold_child_contract_failures=3,DEFLATE_resource_regressions=3,retained=True,adopted=False,latency_calls=0),evidence_limits=['All first and adverse results retained. No unchanged timing rerun or independent confirmation for inconclusive variants.','Raw resource report defaults to the former Apple M3 reference; this summary matches resources to the actual fresh latency winner, rust-ordered-mask-tables256-instrumented.','Profile repeated loop excludes repeated input admission and result materialization; sampler categories are not exact CPU or elapsed shares. Each final output is exact for all5000posts.','The narrow source guard uses the existing generic fallback above u32::MAX posts. Smaller keys, ranks and prefix sums were not assumed to fit U32.','The latest #973 commits add experiment/design records only. The rebase includes them, but does not import the full R301 experimental compact runtime or all experimental compiler files.','Preparation failures occurred before timed calls. Missing legacy Rust source receipts remain explicit rather than fabricated.'],artifacts=files)
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
report='''The compiler now keeps a complete readonly numeric loop tree in native code when the existing selection would choose a readonly partial phase with an unsupported child. Both the tree and its readonly ownership are independently proved. If either proof declines, the original phase remains. Mutable phases and current-funded child exits retain their established compact transport. This fixes the U32 coverage scan returning to the host once per post without weakening finite admission, failure order, aliases, recovery or publication.

The initial broader preference failed three existing cold-child contracts and increased resource accounting in three DEFLATE rows. Those first results and exact source files are retained. Restricting the preference to readonly unsupported exits passes all 505 compiler contracts, including every one of the 484 selected IR308 names. All 128 scalar and five DEFLATE rows match the parent on every non-timing/resource field. Original/restored full-input execution passes. Four linked runners each pass 32 exact-output cases and their Object byte audit.

The same simplified U32 counter source drops accounted work from 285,254,221,728 on IR313 to 37,005,786,724 on IR314; the combined source drops from 284,557,819,064 to 36,864,870,728. These are compiler resource counters, not hardware instructions or elapsed-time gains. All variants retain 49 emitted numeric functions, four native workers, four tasks and eight numeric regions. The maintained U64 source's entire native text is byte-identical to IR313.

The source experiments narrow only frequency banks and/or posting IDs. Prefixes, ranks, positions and key arithmetic retain U64. Existing ordered/distinct eligibility proves a subset occurs at most once per post; the fast path additionally requires posts <= u32::MAX. Larger inputs take the existing generic scoring fallback. The maintained source is unchanged.

The first matched cohort retains all 31 randomized latency rounds and seven separate resource rounds, with 868 and 203 exact outputs respectively. All 22 Rust controls remain; the two controls with preinitialized work outside their timer are ineligible as post-JSON references. Input admission, preparation, allocations, native work, worker creation/run/join, internal cleanup and materialization remain inside one continuous post-JSON interval.

| Implementation | Post-JSON median | × fastest eligible Rust |
| --- | ---: | ---: |
| Rust ordered masks/tables256 | 1.497167 ms | 1.000000 |
| Historical IR308 control | 1.709750 ms | 1.141990 |
| Published IR313 control | 1.700167 ms | 1.135589 |
| IR314 maintained source | 1.697375 ms | 1.133725 |
| IR314 U32 counts | 1.693166 ms | 1.130913 |
| IR314 U32 postings | 1.705125 ms | 1.138901 |
| IR314 both U32 | 1.700958 ms | 1.136118 |

No source variant demonstrates a reliable latency improvement against the same-compiler control and published parent. Median paired changes against IR314 maintained source are +0.210% [−0.708%, +1.370%] for counts, +0.406% [−0.390%, +0.937%] for postings, and +0.501% [−0.145%, +1.356%] for both. Combined versus published IR313 is adverse: +0.593% [+0.184%, +1.222%]. The intervals use 20,000 deterministic bootstrap resamples with the seed declared before capture; every first sample and outlier remains. No unchanged retry or independent confirmation was run.

| Post-JSON resource median | Maintained | U32 counts | U32 postings | Both U32 | Matched Rust |
| --- | ---: | ---: | ---: | ---: | ---: |
| Retired instructions | 31,721,909 | 31,851,219 | 32,247,674 | 32,421,995 | 17,671,383 |
| Cycles | 10,429,467 | 10,370,037 | 10,227,103 | 10,278,389 | 5,877,840 |
| Allocation requests | 720 | 735 | 726 | 735 | 58 |
| Requested bytes | 7,326,125 | 7,221,329 | 7,143,541 | 7,036,985 | 6,825,713 |
| Peak additional requested heap | 5,357,407 | 5,056,203 | 5,174,823 | 4,871,859 | 5,648,124 |
| Native code bytes | 1,031,964 | 1,047,324 | 1,026,616 | 1,046,936 | — |
| Reported module stack bound | 1,584 | 1,568 | 1,568 | 1,568 | — |
| Executable bytes | 17,181,584 | 17,132,048 | 17,148,560 | 17,099,024 | — |

Both-U32 saves 9.063% peak additional requested heap and 3.947% requested bytes, while adding allocations and instructions. These are useful resource results, with no claimed speed gain. Complete-process medians remain visible in raw reports: maintained Mech 47.102917 ms, fastest post-JSON Rust 22.123167 ms. Restoration, process instructions, RSS, physical footprint and heap stages remain independently recorded; whole-process is not an acceptance gate.

Fresh same-Object profiles of maintained, counts and combined executables each run 10,001 invocations and finish with an exact 5,000-post output. The compiled query is the largest active reported leaf, followed by the native UTF8 histogram and index loops. Host escrow locking and worker lifecycle remain visible. Generated Mech code accounts for about 76% of reported nonwait/nonloader leaf observations in these repeated-invocation profiles. This is a diagnostic sample distribution, not a CPU/latency attribution; repeated input admission and materialization are outside that loop. Narrower memory alone has not reduced the query's generated instruction work.

PR990 is rebased onto #973 at `4debec08de0feeb0884f13aa620c7167a1729682`. All 2,737 inventoried compiler/configuration source files match the measured compiler after rebase. The new #973 commits add experimental compiler evidence and design documents; those bundles are separate from maintained compiler source. The checked R293 backend and SSA-width work already integrated into IR312/313 remains. Cranelift is the production backend, with no required LLVM dependency. The full R301 compact experimental runtime has not been substituted into this compiler.

The compiler selection fix is retained. U32 source variants remain experiments because latency is inconclusive or adverse. The next narrow compiler gap is the U64-only checked read/increment fact: narrow successful arithmetic can support the same current-read proof while retaining its narrower overflow error. This has not yet been implemented or credited as a gain. The 1.00× goal remains unmet.

`summary.json` indexes compressed raw reports, source inventories, recipes, build receipts, profiles and initial failures by SHA-256. Local binaries are not duplicated in git. The maintained source hash is `7707f4b6e57015b5017996bc96c78284a3bda2825a2e8846979b23ccc60b5799`.
'''
(D/'REPORT.md').write_text(report)
print('records',len(files),'compressed bytes',sum((D/x['path']).stat().st_size for x in files))
