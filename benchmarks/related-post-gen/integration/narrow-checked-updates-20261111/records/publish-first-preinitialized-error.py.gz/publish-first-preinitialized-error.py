from pathlib import Path
import json,gzip,hashlib
E=Path(__file__).parent;S=Path('/private/tmp/mech-related-narrow-updates-compiler-20261111');D=S/'benchmarks/related-post-gen/integration/narrow-checked-updates-20261111';D.mkdir(exist_ok=False);read=lambda p:json.loads(Path(p).read_text());sha=lambda b:hashlib.sha256(b).hexdigest();files=[];seen=set()
def add(p,rel=None):
 p=Path(p)
 if not p.is_file():return
 rel=Path(rel)if rel else p.relative_to(E)
 if str(rel)in seen:return
 seen.add(str(rel));b=p.read_bytes();q=D/'records'/Path(str(rel)+'.gz');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(gzip.compress(b,mtime=0));files.append(dict(path=str(q.relative_to(D)),sha256=sha(q.read_bytes()),uncompressed_sha256=sha(b),uncompressed_bytes=len(b),original_path=str(p)))
for p in sorted(E.glob('*')):
 if p.suffix in ['.json','.py','.rs','.mec']:add(p)
for n in ['compiler','runtime','tests','tests-first-build','tests-syntax-fixtures','qualification','regressions','metrics','first','confirmation','selected-qualification','native-inspection']:
 for p in sorted((E/n).rglob('*')):
  if not p.is_file()or p.suffix not in ['.json','.py','.rs','.s']:continue
  if p.name in ['output.json','original-output.json','decoded-output.json','catalog-profile.json']:continue
  if n in ['first','confirmation']and len(p.relative_to(E/n).parts)>1:continue
  if'build'in p.relative_to(E/n).parts:continue
  add(p)
for n in ['baseline','counts32','postings32','counts-postings32']:
 d=E/'runners'/n
 for p in sorted(d.glob('*.json')):
  if p.name!='output.json':add(p)
 add(d/'runner.rs');add(d/'build/source.mec')
 for k in ['metadata.json','descriptor.json','frame-summary.json']:add(d/'build'/k)
 for p in sorted((d/'edges').rglob('*.json')):add(p)
for p in sorted((E/'profile').rglob('*')):
 if p.is_file()and p.suffix in ['.json','.rs','.txt']and p.name!='output.json'and'build'not in p.relative_to(E/'profile').parts:add(p)
f=read(E/'first/paired-analysis.json');c=read(E/'confirmation/paired-analysis.json');static=read(E/'native-code-inspection.json');queries=read(E/'native-inspection/summary.json');reb=read(E/'rebase-source-identity.json');sel=read(E/'selection-decision.json');name='mech-ir315-counts-postings32-4';base='mech-ir314-baseline-4';same='mech-ir314-counts-postings32-4';own='mech-ir315-baseline-4';key=name+'-instrumented'
summary=dict(schema='mech.related-post-gen.narrow-checked-updates.v1',compiler=dict(identity='IR315/work126/ABI42/image11',measured_commit='389032ed560502bcace0841f7aa4f0af63e56cbf',rebased_compiler_commit=reb['rebased_compiler_commit'],PR973_base=reb['current_PR973_base'],backend='Cranelift 0.131.3 with verified DEFLATE backend patches',required_LLVM_dependency=False,rebase_source_identity=reb),selection=sel,qualification=dict(selected_compiler_contracts=508,all505_IR314_names_retained=True,all484_IR308_names_retained=True,targeted_update_and_traversal_fact_contracts=22,scalar_non_timing_exact_rows=128,DEFLATE_non_timing_exact_rows=5,linked_exact_outputs=128,same_Object_audits=4,selected_full5000_original_and_decoded=True,selected_full_finite_denials=12,selected_full_successful_retries=12,current_same_Object_profiles=2,latency_exact_outputs=1798,resource_exact_outputs=420),first=f,confirmation=c,native_code=static,query_static_inspection=queries,evidence_limits=['Primary counts-only and postings-only results are inconclusive; only the predeclared favorable combined source advances to confirmation. All first and adverse rows remain.','Resource tables match the actual fresh latency winner separately in each cohort. Default raw resource references remain explicit.','Profile repeated loop excludes repeated input admission/materialization and includes short-lived worker sampling effects. Sample categories are not CPU or elapsed-time shares.','The selected query shrinks with narrow postings but retains the same query text as IR314 combined; the new checked-update compiler improvement is in producer/scatter code.','Initial Rust test build and source-fixture syntax failures are retained. There were no timed calls during these preparation failures.','No whole-process gate, timing-scope move, preinitialized worker pool, counter exemption or LLVM production dependency was added.'],artifacts=files)
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
rows=[]
for label,folder in [('First','first'),('Confirmation','confirmation')]:
 lat=read(E/folder/'latency.json');rows.extend([f'## {label} cohort','',f"Fastest eligible post-JSON reference: `{lat['matched_native_reference']['variant']}`. All rows retain their own first samples. Restoration is excluded from post-JSON and included in whole process.",'','| Variant | Post-JSON ms | × fastest eligible Rust | Whole-process ms | Restore ms |','| --- | ---: | ---: | ---: | ---: |'])
 for n,r in lat['summary'].items():
  xs=[x for x in lat['samples']if x['variant']==n];restore=sorted(x['compile_or_restore_seconds']for x in xs)[len(xs)//2]*1000 if'compile_or_restore_seconds'in xs[0]else None;ratio=r.get('post_json_over_fastest_matched_native');post=r.get('median_post_json_seconds',r['median_seconds'])*1000;rows.append(f"| `{n}` | {post:.6f} | {ratio:.6f} | {r['median_whole_process_seconds']*1000:.6f} | {f'{restore:.6f}'if restore is not None else'—'} |")
 rows.append('')
(D/'ALL-TIMINGS.md').write_text('\n'.join(rows)+'\n')
def paired(a,b,kind='post_json_seconds'):
 r=a['paired_comparisons'][name+' vs '+b][kind];lo,hi=r['two_sided_95_interval'];return f"{100*r['median_paired_relative_change']:+.3f}% [{100*lo:+.3f}%, {100*hi:+.3f}%]"
def m(a,n):return a['medians'][n]['median_post_json_seconds']*1000
def ratio(a,n):return a['medians'][n]['times_fastest_eligible_Rust']
resource=c['resource_medians'];ref=c['resource_reference_matched_to_latency'];rnames=[base+'-instrumented',same+'-instrumented',key,ref];headers=['Published U64','IR314 same combined source','Selected IR315 combined','Matched Rust'];table=['| Post-JSON resource median | '+' | '.join(headers)+' |','| --- | ---: | ---: | ---: | ---: |']
for label,k,hardware in [('Retired instructions','instructions_retired',True),('Cycles','cycles',True),('Allocation requests','allocation_requests',False),('Requested bytes','requested_allocation_bytes',False),('Peak additional requested heap','peak_additional_live_requested_heap_bytes',False)]:
 vals=[]
 for n in rnames:
  r=resource[n]['post_json_measurement_median'];vals.append(f"{(r['hardware']if hardware else r)[k]:,}")
 table.append('| '+label+' | '+' | '.join(vals)+' |')
selected=resource[key];published=resource[base+'-instrumented'];sr=selected['stage_measurements_median']['restore'];br=published['stage_measurements_median']['restore'];sp=selected['process_resources_median'];bp=published['process_resources_median']
report=f'''IR315 extends the existing current-read/update proof to checked U8/U32 arithmetic and unsigned storage widths. A successful checked narrow addition is the same mathematical sum in the proof's U64 domain; it proves that an exact current cell plus one changes. The generated store can then omit its repeated bounds check, old-cell load and equality test. Narrow overflow still executes at the original scalar operation. Arithmetic-guard removal remains U64-only. Unchanged cells, other indices, stale values, unknown calls/joins and unproved ownership retain their original checks.

Independent writes preserve facts only for distinct logical carrier homes under the existing owner/COW witness. Sharing physical backing does not grant independence by itself. The same first-change copy, publication, failure ordering, finite admission and retry contracts remain. The image identity advances to IR315; work126/ABI42/image11 and all production counters remain.

For the same U32-count source, proved increments rise 14→43 and native code falls 1,047,324→1,025,960 bytes. For U32 postings, cross-write increments rise 6→12. The combined source recovers 8→43 increments and shrinks 1,046,936→1,023,588 bytes. Every variant retains 49 emitted numeric functions. The maintained U64 source's full native text is byte-identical to IR314.

## Confirmed selected source

The maintained source is now the exact measured combined U32-count/U32-posting source, SHA-256 `{sel['selected_source_sha256']}`. Prefix sums, key arithmetic, positions and ranks remain U64. Existing ordered/distinct rows of at most eight tags and vocabulary at most64 prove each subset occurs at most once per post. The fast path also requires posts<=u32::MAX; larger inputs take the existing generic scoring fallback. No fixture data, post count, dictionary contents or outputs are precomputed. Four native workers are created, run and joined inside each invocation.

The first cohort contains 31 seeded randomized rounds across31 variants. Counts-only, the predeclared primary candidate, is inconclusive. Postings-only is also inconclusive. Only the predeclared combined candidate improves against its same-source IR314 parent, published maintained source and same-compiler U64 control. It advances to an independent31-round confirmation with fresh preregistered seeds. All22 Rust controls remain in both; the two preinitialized timer scopes remain ineligible as post-JSON references. No unchanged adverse alternative is retried.

| Cohort | Published IR314 U64 | IR315 U64 control | Selected IR315 combined | Fastest eligible Rust | Selected × Rust |
| --- | ---: | ---: | ---: | ---: | ---: |
| First | {m(f,base):.6f} ms | {m(f,own):.6f} ms | {m(f,name):.6f} ms | {f['fastest_eligible_Rust']['median_seconds']*1000:.6f} ms | {ratio(f,name):.6f}× |
| Confirmation | {m(c,base):.6f} ms | {m(c,own):.6f} ms | {m(c,name):.6f} ms | {c['fastest_eligible_Rust']['median_seconds']*1000:.6f} ms | {ratio(c,name):.6f}× |

First fastest Rust is the Apple M3 ordered-mask/tables256 control; confirmation fastest is its untuned counterpart. The denominator is chosen afresh, never combined from a different cohort. The authoritative timer is one continuous post-JSON interval including input admission, source preparation, allocations, native work, worker creation/run/join, internal cleanup and materialization. Restoration and JSON IO remain in complete process.

| Paired post-JSON change, median and descriptive95% interval | First | Confirmation |
| --- | ---: | ---: |
| Selected vs published U64 | {paired(f,base)} | {paired(c,base)} |
| Selected vs same-source IR314 | {paired(f,same)} | {paired(c,same)} |
| Selected vs same-compiler U64 | {paired(f,own)} | {paired(c,own)} |

Intervals use20,000 bootstrap resamples with seeds declared before capture. Every first sample and outlier remains. There are **1,798 exact latency outputs** and **420 exact outputs from separate resource cohorts**. [All first and confirmation timings](ALL-TIMINGS.md) include every Rust and Mech row. **The1.00× goal remains unmet; confirmation leaves176.916μs to the fastest measured eligible Rust.**

## Resources and sizes

'''+'\n'.join(table)+f'''

Selected versus published U64 saves9.063% peak additional requested heap and3.947% requested bytes. Allocation requests rise720→735. Instructions remain above the U64 source and are1.824× matched Rust, despite the elapsed gain; resource regressions are not hidden. The compiler alone reduces the same combined source's confirmation instructions32,429,018→32,232,107. Hardware counters aggregate all participating threads, so their ratios are not elapsed ratios.

Selected native code is1,023,588 bytes versus U64's1,031,964. Reported module stack bound is1,568 versus1,584 bytes. Executable size is17,082,512 versus17,181,584 bytes. The selected query is31,452 bytes versus32,192, with7,863 versus8,048 static instructions and1,572 versus1,730 static stack references; alignment padding is excluded. Its reported frame grows560→576 bytes. Static references are not dynamic spill counts. This query text is unchanged from IR314's same combined source; the new checked-update proof shrinks producer/scatter code.

Restoration remains visible: selected {sr['allocation_requests']:,} requests /{sr['requested_allocation_bytes']:,} bytes /{sr['hardware']['instructions_retired']:,} instructions, versus published {br['allocation_requests']:,} /{br['requested_allocation_bytes']:,} /{br['hardware']['instructions_retired']:,}. Instrumented whole-process instructions are {sp['instructions_retired']:,} versus {bp['instructions_retired']:,}; peak RSS {sp['peak_resident_bytes']:,} versus {bp['peak_resident_bytes']:,}, lifetime physical footprint {sp['peak_physical_footprint_bytes']:,} versus {bp['peak_physical_footprint_bytes']:,} bytes. Raw reports retain all cycles, heap stages, residency and footprint fields.

Confirmation launch-through-exit median is46.350500ms for selected Mech, versus47.420416ms for published U64. Its paired change is {paired(c,base,'wall_seconds')}. Fastest complete-process Rust is the ordered-mask-reuse control at21.954875ms; it differs from the post-JSON reference. Whole-process remains visible and is not an acceptance gate.

## Qualification and current profile

All508 selected native compiler contracts pass, retaining all505 IR314 and484 IR308 names. The22 focused update/traversal tests include actual selected U8/U32 emission and ablations, overflow, bounds, unchanged/different cells, physical aliases with logical independence, original/decoded/restored execution, six finite dimensions, failure publication and retry. All128 scalar and five DEFLATE rows preserve every non-timing/resource field. Four linked variants pass32 exact cases each and their Object byte audit.

The selected complete5000-post source separately passes original and decoded artifact execution,12 finite denials with prior outputs preserved, and12 successful complete retries. Linked restoration is exercised by every linked-output/cohort call. Generic tiny-source finite tests find exact successful boundaries; full-source probes deliberately test zero-budget denial and retry. These scopes are distinct and are not presented as full-input exact-threshold sweeps.

Fresh same-Object profiles of U64 and selected combined code each finish10,001 invocations and an exact final5000-post output. The native query is the largest active reported leaf, followed by the UTF8 histogram and native index loops. Budget escrow locking, frame allocation and worker lifecycle remain visible. The profile loop excludes repeated input admission/materialization; sample categories include short-lived-worker disturbance and are not exact CPU or latency shares. A fresh full-boundary phase study is still needed to divide the remaining critical-path gap.

Initial qualification preparation failed on a Rust lifetime in the new test helper and then on source-fixture cast syntax. The first code, build manifests and failing receipts remain. The corrected tests pass; these failures started zero benchmark calls. No production behavior was weakened to bypass them.

The branch includes #973 through `{reb['current_PR973_base']}`. All{reb['inventoried_compiler_configuration_files']:,} inventoried compiler/configuration files match the measured compiler after the documentation-only rebase, and the maintained Mech source is byte-identical to the measured candidate. Cranelift remains production; LLVM is not required. The checked DEFLATE backend/SSA-width work remains integrated; experimental compact runtime bundles have not replaced this compiler wholesale.

`summary.json` indexes the compressed raw records, full hashes, build recipes, source inventories, failures, profiles, timings and selection decision. No parity, merge or green-hosted-CI claim is made.
'''
(D/'REPORT.md').write_text(report)
print('records',len(files),'compressed bytes',sum((D/x['path']).stat().st_size for x in files),flush=True)
