/private/tmp/mech-related-narrow-updates-20261111/objects/counts-postings32/object.o:
(__TEXT,__text) section
_mech_canonical_program_entry_v1_numeric_1587:
   3c080:	hint	#27
   3c084:	stp	x29, x30, [sp, #-0x10]!
   3c088:	mov	x29, sp
   3c08c:	stp	x27, x28, [sp, #-0x10]!
   3c090:	stp	x25, x26, [sp, #-0x10]!
   3c094:	stp	x23, x24, [sp, #-0x10]!
   3c098:	stp	x21, x22, [sp, #-0x10]!
   3c09c:	stp	x19, x20, [sp, #-0x10]!
   3c0a0:	sub	sp, sp, #0x1e0
   3c0a4:	mov	x5, x1
   3c0a8:	stur	x2, [sp, #0x8]
   3c0ac:	ldr	x21, [x0, #0x50]
   3c0b0:	str	x21, [sp, #0x1d0]
   3c0b4:	ldr	x6, [x0, #0x58]
   3c0b8:	ldr	x1, [x0, #0x60]
   3c0bc:	ldr	x13, [x0, #0x68]
   3c0c0:	stur	x0, [sp]
   3c0c4:	str	x13, [sp, #0x1b8]
   3c0c8:	mov	x0, #0x3
   3c0cc:	cmp	x21, #0x0
   3c0d0:	b.eq	0x41314
   3c0d4:	mov	x0, #0x3
   3c0d8:	cmp	x6, #0x0
   3c0dc:	str	x6, [sp, #0x1c8]
   3c0e0:	b.eq	0x4131c
   3c0e4:	mov	x0, #0x3
   3c0e8:	mov	x25, x0
   3c0ec:	cmp	x1, #0x0
   3c0f0:	b.eq	0x43b34
   3c0f4:	mov	x0, x5
   3c0f8:	ldr	x22, [x0, #0x54d0]
   3c0fc:	cmp	x22, #0x0
   3c100:	stur	x22, [sp, #0x58]
   3c104:	b.eq	0x3c664
   3c108:	ldr	x25, [x1, #0x10]
   3c10c:	ldr	x3, [x0, #0x54d8]
   3c110:	ldr	x4, [x0, #0x54e0]
   3c114:	stur	x4, [sp, #0x60]
   3c118:	ldr	x27, [x25, #0xcd0]
   3c11c:	stur	x27, [sp, #0xc8]
   3c120:	ldr	x27, [x25, #0xce0]
   3c124:	str	x27, [sp, #0x1b0]
   3c128:	ldr	x28, [x1, #0x908]
   3c12c:	str	x28, [sp, #0x1a8]
   3c130:	ldr	x28, [x1, #0x910]
   3c134:	str	x28, [sp, #0x1a0]
   3c138:	ldr	x0, [x1, #0x918]
   3c13c:	ldr	x0, [x1, #0x920]
   3c140:	ldr	x28, [x1, #0x928]
   3c144:	str	x28, [sp, #0x198]
   3c148:	ldr	x28, [x1, #0x930]
   3c14c:	str	x28, [sp, #0x190]
   3c150:	ldr	x0, [x1, #0x938]
   3c154:	ldr	x0, [x1, #0x940]
   3c158:	ldr	x28, [x1, #0x948]
   3c15c:	str	x28, [sp, #0x188]
   3c160:	ldr	x28, [x1, #0x950]
   3c164:	str	x28, [sp, #0x180]
   3c168:	ldr	x0, [x1, #0x958]
   3c16c:	ldr	x0, [x1, #0x960]
   3c170:	ldr	x20, [x1, #0x968]
   3c174:	str	x20, [sp, #0x178]
   3c178:	ldr	x28, [x1, #0x970]
   3c17c:	str	x28, [sp, #0x170]
   3c180:	ldr	x0, [x1, #0x978]
   3c184:	ldr	x0, [x1, #0x980]
   3c188:	ldr	x28, [x1, #0x988]
   3c18c:	str	x28, [sp, #0x168]
   3c190:	ldr	x28, [x1, #0x990]
   3c194:	str	x28, [sp, #0x160]
   3c198:	ldr	x0, [x1, #0x998]
   3c19c:	ldr	x0, [x1, #0x9a0]
   3c1a0:	ldr	x28, [x1, #0x9a8]
   3c1a4:	str	x28, [sp, #0x158]
   3c1a8:	ldr	x28, [x1, #0x9b0]
   3c1ac:	str	x28, [sp, #0x150]
   3c1b0:	ldr	x0, [x1, #0x9b8]
   3c1b4:	ldr	x0, [x1, #0x9c0]
   3c1b8:	ldr	x28, [x1, #0x9c8]
   3c1bc:	str	x28, [sp, #0x148]
   3c1c0:	ldr	x28, [x1, #0x9d0]
   3c1c4:	str	x28, [sp, #0x140]
   3c1c8:	ldr	x0, [x1, #0x9d8]
   3c1cc:	ldr	x0, [x1, #0x9e0]
   3c1d0:	ldr	x28, [x1, #0x9e8]
   3c1d4:	str	x28, [sp, #0x138]
   3c1d8:	ldr	x28, [x1, #0x9f0]
   3c1dc:	str	x28, [sp, #0x130]
   3c1e0:	ldr	x0, [x1, #0x9f8]
   3c1e4:	ldr	x0, [x1, #0xa00]
   3c1e8:	ldr	x28, [x1, #0xa08]
   3c1ec:	str	x28, [sp, #0x128]
   3c1f0:	ldr	x28, [x1, #0xa10]
   3c1f4:	str	x28, [sp, #0x120]
   3c1f8:	ldr	x0, [x1, #0xa18]
   3c1fc:	ldr	x0, [x1, #0xa20]
   3c200:	ldr	x22, [x1, #0xa28]
   3c204:	stur	x22, [sp, #0x98]
   3c208:	ldr	x24, [x1, #0xa30]
   3c20c:	stur	x24, [sp, #0x28]
   3c210:	ldr	x0, [x1, #0xa38]
   3c214:	ldr	x0, [x1, #0xa40]
   3c218:	ldr	x0, [x1, #0xa98]
   3c21c:	stur	x0, [sp, #0x88]
   3c220:	str	x1, [sp, #0x1c0]
   3c224:	mov	x15, #0x0
   3c228:	mov	x4, #0x1
   3c22c:	stur	x4, [sp, #0x68]
   3c230:	mov	x13, #0xf
   3c234:	mov	x2, x15
   3c238:	mov	x6, x15
   3c23c:	mov	x7, x15
   3c240:	mov	x11, x15
   3c244:	mov	x12, x15
   3c248:	mov	x14, x15
   3c24c:	mov	x26, x15
   3c250:	stur	x3, [sp, #0x50]
   3c254:	stur	x15, [sp, #0x78]
   3c258:	stur	x15, [sp, #0x80]
   3c25c:	stur	x15, [sp, #0x90]
   3c260:	mov	w0, #0xb946
   3c264:	movk	w0, #0x1, lsl #16
   3c268:	cmp	x3, x0
   3c26c:	cset	x1, hs
   3c270:	ldur	x0, [sp, #0x88]
   3c274:	ldur	x24, [sp, #0x28]
   3c278:	cmp	x24, x0
   3c27c:	cset	x4, ls
   3c280:	sub	x0, x0, x24
   3c284:	cmp	x0, #0x4
   3c288:	cset	x0, hi
   3c28c:	and	w4, w4, w0
   3c290:	and	w1, w1, w4
   3c294:	uxtb	w1, w1
   3c298:	cbz	x1, 0x41324
   3c29c:	stur	x2, [sp, #0x70]
   3c2a0:	ldur	x23, [sp, #0xc8]
   3c2a4:	mov	x19, x5
   3c2a8:	ldur	x10, [sp, #0x78]
   3c2ac:	ldur	x4, [sp, #0x60]
   3c2b0:	ldr	x2, [sp, #0x1b8]
   3c2b4:	ldr	x1, [sp, #0x1c0]
   3c2b8:	b	0x3c68c
   3c2bc:	ldur	x23, [sp, #0xc8]
   3c2c0:	b	0x3c37c
   3c2c4:	ldur	x0, [sp, #0x60]
   3c2c8:	mov	x4, x3
   3c2cc:	ldur	x23, [sp, #0xc8]
   3c2d0:	b	0x3c354
   3c2d4:	ldr	x27, [sp, #0x1b0]
   3c2d8:	cmp	x23, x27
   3c2dc:	b.lo	0x3c338
   3c2e0:	cmp	x23, x27
   3c2e4:	b.lo	0x3c328
   3c2e8:	cmp	x23, x27
   3c2ec:	b.lo	0x3c318
   3c2f0:	cmp	x23, x27
   3c2f4:	b.lo	0x3c308
   3c2f8:	mov	w1, #0x1
   3c2fc:	ldur	x0, [sp, #0x60]
   3c300:	mov	x4, x3
   3c304:	b	0x3c354
   3c308:	mov	w1, #0x1
   3c30c:	ldur	x0, [sp, #0x60]
   3c310:	mov	x4, x3
   3c314:	b	0x3c354
   3c318:	mov	w1, #0x1
   3c31c:	ldur	x0, [sp, #0x60]
   3c320:	mov	x4, x3
   3c324:	b	0x3c354
   3c328:	mov	x4, x3
   3c32c:	mov	x1, x0
   3c330:	ldur	x0, [sp, #0x60]
   3c334:	b	0x3c354
   3c338:	mov	w1, #0x1
   3c33c:	ldur	x0, [sp, #0x60]
   3c340:	mov	x4, x3
   3c344:	b	0x3c354
   3c348:	mov	w1, #0x1
   3c34c:	ldur	x0, [sp, #0x60]
   3c350:	mov	x4, x3
   3c354:	tbz	w1, #0x0, 0x3c374
   3c358:	stur	x2, [sp, #0x70]
   3c35c:	mov	x19, x5
   3c360:	ldur	x10, [sp, #0x78]
   3c364:	ldur	x4, [sp, #0x60]
   3c368:	ldr	x2, [sp, #0x1b8]
   3c36c:	ldr	x1, [sp, #0x1c0]
   3c370:	b	0x3c68c
   3c374:	mov	x3, x4
   3c378:	stur	x0, [sp, #0x60]
   3c37c:	mov	x0, #0x0
   3c380:	mov	x19, x5
   3c384:	str	x0, [x19, #0x30]
   3c388:	mov	x1, #0x1000000000000000
   3c38c:	str	x1, [x19, #0x38]
   3c390:	mov	x1, #0x1
   3c394:	str	x1, [x19, #0x48]
   3c398:	mov	x4, #0x101010101010101
   3c39c:	str	x4, [x19, #0x50]
   3c3a0:	mov	x4, #0x2
   3c3a4:	str	x4, [x19, #0x58]
   3c3a8:	mov	x4, #0x3
   3c3ac:	str	x4, [x19, #0x60]
   3c3b0:	mov	x4, #0x4
   3c3b4:	str	x4, [x19, #0x68]
   3c3b8:	mov	x4, #0xf0f0f0f0f0f0f0f
   3c3bc:	str	x4, [x19, #0x90]
   3c3c0:	mov	x4, #0x3333333333333333
   3c3c4:	str	x4, [x19, #0xa0]
   3c3c8:	mov	x4, #0x38
   3c3cc:	str	x4, [x19, #0xa8]
   3c3d0:	mov	x4, #0x3a
   3c3d4:	str	x4, [x19, #0xb0]
   3c3d8:	mov	x4, #0x5555555555555555
   3c3dc:	str	x4, [x19, #0xc8]
   3c3e0:	mov	x4, #0x3ffffffffffffff
   3c3e4:	str	x4, [x19, #0xd8]
   3c3e8:	str	x0, [x19, #0x178]
   3c3ec:	str	x1, [x19, #0x180]
   3c3f0:	ldur	x21, [sp, #0x58]
   3c3f4:	str	x21, [x19, #0x54d0]
   3c3f8:	str	x3, [x19, #0x54d8]
   3c3fc:	ldur	x4, [sp, #0x60]
   3c400:	str	x4, [x19, #0x54e0]
   3c404:	str	x23, [x19, #0x5818]
   3c408:	ldr	x27, [sp, #0x1b0]
   3c40c:	str	x27, [x19, #0x5820]
   3c410:	ldur	x24, [sp, #0x28]
   3c414:	str	x24, [x19, #0x6238]
   3c418:	str	x15, [x19, #0x62a8]
   3c41c:	ldur	x8, [sp, #0x68]
   3c420:	str	x8, [x19, #0x62b0]
   3c424:	str	x2, [x19, #0x62b8]
   3c428:	ldur	x4, [sp, #0x50]
   3c42c:	sub	x0, x4, x3
   3c430:	mov	w1, #0xb946
   3c434:	movk	w1, #0x1, lsl #16
   3c438:	msub	x0, x15, x1, x0
   3c43c:	str	x0, [x19, #0x62c0]
   3c440:	str	x26, [x19, #0x62c8]
   3c444:	str	x14, [x19, #0x62d0]
   3c448:	ldur	x10, [sp, #0x78]
   3c44c:	str	x10, [x19, #0x62e0]
   3c450:	ldur	x10, [sp, #0x80]
   3c454:	str	x10, [x19, #0x62e8]
   3c458:	str	x12, [x19, #0x62f8]
   3c45c:	str	x11, [x19, #0x6300]
   3c460:	str	x7, [x19, #0x6310]
   3c464:	str	x6, [x19, #0x6318]
   3c468:	ldr	x0, [x19, #0x54d0]
   3c46c:	cmp	x0, #0x0
   3c470:	b.eq	0x3c664
   3c474:	ldr	x3, [x19, #0x54d8]
   3c478:	ldr	x4, [x19, #0x54e0]
   3c47c:	mov	x0, #0x0
   3c480:	str	x0, [x19, #0x54d0]
   3c484:	mov	x0, #0x3
   3c488:	ldr	x2, [sp, #0x1b8]
   3c48c:	cmp	x2, #0x164
   3c490:	b.lo	0x41374
   3c494:	ldr	x0, [x19, #0x5818]
   3c498:	ldr	x1, [sp, #0x1c0]
   3c49c:	str	x0, [x1, #0x10]
   3c4a0:	ldr	x2, [x19, #0x5820]
   3c4a4:	str	x2, [x1, #0x18]
   3c4a8:	ldr	x5, [x19, #0x6238]
   3c4ac:	str	x5, [x1, #0xa30]
   3c4b0:	str	x0, [x1, #0x10]
   3c4b4:	str	x2, [x1, #0x18]
   3c4b8:	ldr	x5, [x19, #0x58f8]
   3c4bc:	str	x5, [x1, #0xf0]
   3c4c0:	ldr	x5, [x19, #0x5900]
   3c4c4:	str	x5, [x1, #0xf8]
   3c4c8:	ldr	x6, [x19, #0x5908]
   3c4cc:	str	x6, [x1, #0x100]
   3c4d0:	ldr	x7, [x19, #0x5910]
   3c4d4:	str	x7, [x1, #0x108]
   3c4d8:	ldr	x8, [x19, #0x5918]
   3c4dc:	str	x8, [x1, #0x110]
   3c4e0:	ldr	x9, [x19, #0x5920]
   3c4e4:	str	x9, [x1, #0x118]
   3c4e8:	ldr	x10, [x19, #0x5928]
   3c4ec:	str	x10, [x1, #0x120]
   3c4f0:	ldr	x11, [x19, #0x5930]
   3c4f4:	str	x11, [x1, #0x128]
   3c4f8:	ldr	x12, [x19, #0x5938]
   3c4fc:	str	x12, [x1, #0x130]
   3c500:	ldr	x13, [x19, #0x5a70]
   3c504:	str	x13, [x1, #0x268]
   3c508:	ldr	x14, [x19, #0x5a78]
   3c50c:	str	x14, [x1, #0x270]
   3c510:	ldr	x15, [x19, #0x5a80]
   3c514:	str	x15, [x1, #0x278]
   3c518:	ldr	x0, [x19, #0x5a88]
   3c51c:	str	x0, [x1, #0x280]
   3c520:	ldr	x0, [x19, #0x5a90]
   3c524:	str	x0, [x1, #0x288]
   3c528:	ldr	x0, [x19, #0x5a98]
   3c52c:	str	x0, [x1, #0x290]
   3c530:	ldr	x0, [x19, #0x5aa0]
   3c534:	str	x0, [x1, #0x298]
   3c538:	ldr	x0, [x19, #0x5aa8]
   3c53c:	str	x0, [x1, #0x2a0]
   3c540:	ldr	x0, [x19, #0x5ab0]
   3c544:	str	x0, [x1, #0x2a8]
   3c548:	ldr	x0, [x19, #0x5d38]
   3c54c:	str	x0, [x1, #0x530]
   3c550:	ldr	x0, [x19, #0x5d40]
   3c554:	str	x0, [x1, #0x538]
   3c558:	ldr	x0, [x19, #0x5d48]
   3c55c:	str	x0, [x1, #0x540]
   3c560:	ldr	x0, [x19, #0x5d50]
   3c564:	str	x0, [x1, #0x548]
   3c568:	ldr	x0, [x19, #0x5d58]
   3c56c:	str	x0, [x1, #0x550]
   3c570:	ldr	x0, [x19, #0x5d60]
   3c574:	str	x0, [x1, #0x558]
   3c578:	ldr	x0, [x19, #0x5d68]
   3c57c:	str	x0, [x1, #0x560]
   3c580:	ldr	x0, [x19, #0x5d70]
   3c584:	str	x0, [x1, #0x568]
   3c588:	ldr	x0, [x19, #0x5e98]
   3c58c:	str	x0, [x1, #0x690]
   3c590:	ldr	x0, [x19, #0x5ea0]
   3c594:	str	x0, [x1, #0x698]
   3c598:	ldr	x0, [x19, #0x5ea8]
   3c59c:	str	x0, [x1, #0x6a0]
   3c5a0:	ldr	x0, [x19, #0x5eb0]
   3c5a4:	str	x0, [x1, #0x6a8]
   3c5a8:	ldr	x0, [x19, #0x5eb8]
   3c5ac:	str	x0, [x1, #0x6b0]
   3c5b0:	ldr	x0, [x19, #0x5ec0]
   3c5b4:	str	x0, [x1, #0x6b8]
   3c5b8:	ldr	x0, [x19, #0x5ec8]
   3c5bc:	str	x0, [x1, #0x6c0]
   3c5c0:	ldr	x0, [x19, #0x5ed0]
   3c5c4:	str	x0, [x1, #0x6c8]
   3c5c8:	ldr	x0, [x19, #0x62a8]
   3c5cc:	str	x0, [x1, #0xaa0]
   3c5d0:	ldr	x0, [x19, #0x62b0]
   3c5d4:	str	x0, [x1, #0xaa8]
   3c5d8:	ldr	x0, [x19, #0x62b8]
   3c5dc:	str	x0, [x1, #0xab0]
   3c5e0:	ldr	x0, [x19, #0x62c0]
   3c5e4:	str	x0, [x1, #0xab8]
   3c5e8:	ldr	x0, [x19, #0x62c8]
   3c5ec:	str	x0, [x1, #0xac0]
   3c5f0:	ldr	x0, [x19, #0x62d0]
   3c5f4:	str	x0, [x1, #0xac8]
   3c5f8:	mov	x0, #0x0
   3c5fc:	str	x0, [x1, #0xad0]
   3c600:	ldr	x2, [x19, #0x62e0]
   3c604:	str	x2, [x1, #0xad8]
   3c608:	ldr	x2, [x19, #0x62e8]
   3c60c:	str	x2, [x1, #0xae0]
   3c610:	str	x0, [x1, #0xae8]
   3c614:	ldr	x2, [x19, #0x62f8]
   3c618:	str	x2, [x1, #0xaf0]
   3c61c:	ldr	x2, [x19, #0x6300]
   3c620:	str	x2, [x1, #0xaf8]
   3c624:	str	x0, [x1, #0xb00]
   3c628:	ldr	x0, [x19, #0x6310]
   3c62c:	str	x0, [x1, #0xb08]
   3c630:	ldr	x0, [x19, #0x6318]
   3c634:	str	x0, [x1, #0xb10]
   3c638:	mov	x1, #0x633
   3c63c:	mov	x2, #-0x9
   3c640:	mov	x5, #0x1
   3c644:	ldur	x0, [sp, #0x8]
   3c648:	ldr	x6, [sp, #0x1c8]
   3c64c:	ldr	x21, [sp, #0x1d0]
   3c650:	blr	x21
   3c654:	mov	x8, x0
   3c658:	mov	x0, #0x2
   3c65c:	cmp	x8, #0x0
   3c660:	b.ne	0x4137c
   3c664:	mov	x1, #0x0
   3c668:	mov	x0, x1
   3c66c:	add	sp, sp, #0x1e0
   3c670:	ldp	x19, x20, [sp], #0x10
   3c674:	ldp	x21, x22, [sp], #0x10
   3c678:	ldp	x23, x24, [sp], #0x10
   3c67c:	ldp	x25, x26, [sp], #0x10
   3c680:	ldp	x27, x28, [sp], #0x10
   3c684:	ldp	x29, x30, [sp], #0x10
   3c688:	.long	0xd65f0fff
   3c68c:	ldr	x27, [sp, #0x1b0]
   3c690:	cmp	x23, x27
   3c694:	cset	x0, lo
   3c698:	cmp	x23, x27
   3c69c:	b.lo	0x3c6e4
   3c6a0:	mov	x5, #0x0
   3c6a4:	stur	x5, [sp, #0x10]
   3c6a8:	mov	w0, #0xb946
   3c6ac:	movk	w0, #0x1, lsl #16
   3c6b0:	sub	x3, x3, x0
   3c6b4:	mov	x24, x23
   3c6b8:	ldur	x0, [sp, #0x10]
   3c6bc:	stur	x0, [sp, #0x30]
   3c6c0:	stur	x0, [sp, #0x38]
   3c6c4:	stur	x0, [sp, #0x40]
   3c6c8:	stur	x0, [sp, #0x48]
   3c6cc:	stur	x4, [sp, #0x60]
   3c6d0:	stur	x10, [sp, #0x78]
   3c6d4:	stur	x23, [sp, #0xc8]
   3c6d8:	str	x2, [sp, #0x1b8]
   3c6dc:	str	x1, [sp, #0x1c0]
   3c6e0:	b	0x407f8
   3c6e4:	ldr	x20, [sp, #0x160]
   3c6e8:	cmp	x23, x20
   3c6ec:	b.lo	0x3c93c
   3c6f0:	b	0x41384
   3c6f4:	str	x2, [sp, #0x1b8]
   3c6f8:	str	x1, [sp, #0x1c0]
   3c6fc:	b	0x3c8e8
   3c700:	ldr	x3, [x19, #0x54d8]
   3c704:	ldr	x4, [x19, #0x54e0]
   3c708:	mov	x5, #0x0
   3c70c:	str	x5, [x19, #0x54d0]
   3c710:	mov	x0, #0x3
   3c714:	cmp	x2, #0x164
   3c718:	str	x2, [sp, #0x1b8]
   3c71c:	b.lo	0x414a0
   3c720:	ldr	x7, [x19, #0x5818]
   3c724:	str	x7, [x1, #0x10]
   3c728:	ldr	x8, [x19, #0x5820]
   3c72c:	str	x8, [x1, #0x18]
   3c730:	ldr	x9, [x19, #0x6238]
   3c734:	str	x9, [x1, #0xa30]
   3c738:	str	x7, [x1, #0x10]
   3c73c:	str	x8, [x1, #0x18]
   3c740:	ldr	x12, [x19, #0x58f8]
   3c744:	str	x12, [x1, #0xf0]
   3c748:	ldr	x13, [x19, #0x5900]
   3c74c:	str	x13, [x1, #0xf8]
   3c750:	ldr	x14, [x19, #0x5908]
   3c754:	str	x14, [x1, #0x100]
   3c758:	ldr	x15, [x19, #0x5910]
   3c75c:	str	x15, [x1, #0x108]
   3c760:	ldr	x0, [x19, #0x5918]
   3c764:	str	x0, [x1, #0x110]
   3c768:	ldr	x0, [x19, #0x5920]
   3c76c:	str	x0, [x1, #0x118]
   3c770:	ldr	x0, [x19, #0x5928]
   3c774:	str	x0, [x1, #0x120]
   3c778:	ldr	x0, [x19, #0x5930]
   3c77c:	str	x0, [x1, #0x128]
   3c780:	ldr	x0, [x19, #0x5938]
   3c784:	str	x0, [x1, #0x130]
   3c788:	ldr	x0, [x19, #0x5a70]
   3c78c:	str	x0, [x1, #0x268]
   3c790:	ldr	x0, [x19, #0x5a78]
   3c794:	str	x0, [x1, #0x270]
   3c798:	ldr	x0, [x19, #0x5a80]
   3c79c:	str	x0, [x1, #0x278]
   3c7a0:	ldr	x0, [x19, #0x5a88]
   3c7a4:	str	x0, [x1, #0x280]
   3c7a8:	ldr	x0, [x19, #0x5a90]
   3c7ac:	str	x0, [x1, #0x288]
   3c7b0:	ldr	x0, [x19, #0x5a98]
   3c7b4:	str	x0, [x1, #0x290]
   3c7b8:	ldr	x0, [x19, #0x5aa0]
   3c7bc:	str	x0, [x1, #0x298]
   3c7c0:	ldr	x0, [x19, #0x5aa8]
   3c7c4:	str	x0, [x1, #0x2a0]
   3c7c8:	ldr	x0, [x19, #0x5ab0]
   3c7cc:	str	x0, [x1, #0x2a8]
   3c7d0:	ldr	x0, [x19, #0x5d38]
   3c7d4:	str	x0, [x1, #0x530]
   3c7d8:	ldr	x0, [x19, #0x5d40]
   3c7dc:	str	x0, [x1, #0x538]
   3c7e0:	ldr	x0, [x19, #0x5d48]
   3c7e4:	str	x0, [x1, #0x540]
   3c7e8:	ldr	x0, [x19, #0x5d50]
   3c7ec:	str	x0, [x1, #0x548]
   3c7f0:	ldr	x0, [x19, #0x5d58]
   3c7f4:	str	x0, [x1, #0x550]
   3c7f8:	ldr	x0, [x19, #0x5d60]
   3c7fc:	str	x0, [x1, #0x558]
   3c800:	ldr	x0, [x19, #0x5d68]
   3c804:	str	x0, [x1, #0x560]
   3c808:	ldr	x0, [x19, #0x5d70]
   3c80c:	str	x0, [x1, #0x568]
   3c810:	ldr	x0, [x19, #0x5e98]
   3c814:	str	x0, [x1, #0x690]
   3c818:	ldr	x0, [x19, #0x5ea0]
   3c81c:	str	x0, [x1, #0x698]
   3c820:	ldr	x0, [x19, #0x5ea8]
   3c824:	str	x0, [x1, #0x6a0]
   3c828:	ldr	x0, [x19, #0x5eb0]
   3c82c:	str	x0, [x1, #0x6a8]
   3c830:	ldr	x0, [x19, #0x5eb8]
   3c834:	str	x0, [x1, #0x6b0]
   3c838:	ldr	x0, [x19, #0x5ec0]
   3c83c:	str	x0, [x1, #0x6b8]
   3c840:	ldr	x0, [x19, #0x5ec8]
   3c844:	str	x0, [x1, #0x6c0]
   3c848:	ldr	x0, [x19, #0x5ed0]
   3c84c:	str	x0, [x1, #0x6c8]
   3c850:	ldr	x0, [x19, #0x62a8]
   3c854:	str	x0, [x1, #0xaa0]
   3c858:	ldr	x0, [x19, #0x62b0]
   3c85c:	str	x0, [x1, #0xaa8]
   3c860:	ldr	x0, [x19, #0x62b8]
   3c864:	str	x0, [x1, #0xab0]
   3c868:	ldr	x0, [x19, #0x62c0]
   3c86c:	str	x0, [x1, #0xab8]
   3c870:	ldr	x0, [x19, #0x62c8]
   3c874:	str	x0, [x1, #0xac0]
   3c878:	ldr	x0, [x19, #0x62d0]
   3c87c:	str	x0, [x1, #0xac8]
   3c880:	mov	x0, #0x0
   3c884:	str	x0, [x1, #0xad0]
   3c888:	ldr	x2, [x19, #0x62e0]
   3c88c:	str	x2, [x1, #0xad8]
   3c890:	ldr	x2, [x19, #0x62e8]
   3c894:	str	x2, [x1, #0xae0]
   3c898:	str	x0, [x1, #0xae8]
   3c89c:	ldr	x2, [x19, #0x62f8]
   3c8a0:	str	x2, [x1, #0xaf0]
   3c8a4:	ldr	x2, [x19, #0x6300]
   3c8a8:	str	x2, [x1, #0xaf8]
   3c8ac:	str	x0, [x1, #0xb00]
   3c8b0:	ldr	x0, [x19, #0x6310]
   3c8b4:	str	x0, [x1, #0xb08]
   3c8b8:	ldr	x0, [x19, #0x6318]
   3c8bc:	str	x0, [x1, #0xb10]
   3c8c0:	str	x1, [sp, #0x1c0]
   3c8c4:	mov	x1, #0x64c
   3c8c8:	mov	x2, #-0x9
   3c8cc:	ldr	x21, [sp, #0x1d0]
   3c8d0:	ldur	x0, [sp, #0x8]
   3c8d4:	mov	x5, x20
   3c8d8:	ldr	x6, [sp, #0x1c8]
   3c8dc:	blr	x21
   3c8e0:	cmp	x0, #0x0
   3c8e4:	b.ne	0x414a8
   3c8e8:	mov	x0, #0x3
   3c8ec:	ldr	x14, [sp, #0x1b8]
   3c8f0:	cmp	x14, #0x2
   3c8f4:	b.lo	0x414b0
   3c8f8:	mov	x5, #0x0
   3c8fc:	ldr	x3, [sp, #0x1c0]
   3c900:	str	x5, [x3]
   3c904:	ldr	x6, [x19, #0x2170]
   3c908:	str	x6, [x3, #0x8]
   3c90c:	mov	x1, #0x64c
   3c910:	ldur	x0, [sp, #0x8]
   3c914:	ldr	x6, [sp, #0x1c8]
   3c918:	ldr	x21, [sp, #0x1d0]
   3c91c:	mov	x4, x20
   3c920:	mov	x2, x5
   3c924:	blr	x21
   3c928:	cmp	x0, #0x0
   3c92c:	b.ne	0x414b8
   3c930:	mov	x0, #0x3
   3c934:	mov	x25, x0
   3c938:	b	0x43b34
   3c93c:	ldr	x20, [sp, #0x168]
   3c940:	stur	x10, [sp, #0x78]
   3c944:	str	x2, [sp, #0x1b8]
   3c948:	str	x1, [sp, #0x1c0]
   3c94c:	ldr	x1, [x20, x23, lsl #3]
   3c950:	add	x2, x23, #0x1
   3c954:	ldr	x20, [sp, #0x160]
   3c958:	stur	x23, [sp, #0xc8]
   3c95c:	cmp	x2, x20
   3c960:	str	x2, [sp, #0x110]
   3c964:	b.lo	0x3cbd4
   3c968:	b	0x414c0
   3c96c:	ldr	x3, [x19, #0x54d8]
   3c970:	ldr	x4, [x19, #0x54e0]
   3c974:	mov	x0, #0x0
   3c978:	str	x0, [x19, #0x54d0]
   3c97c:	mov	x0, #0x3
   3c980:	ldr	x14, [sp, #0x1b8]
   3c984:	cmp	x14, #0x164
   3c988:	b.lo	0x415f0
   3c98c:	ldr	x0, [x19, #0x5818]
   3c990:	ldr	x12, [sp, #0x1c0]
   3c994:	str	x0, [x12, #0x10]
   3c998:	ldr	x1, [x19, #0x5820]
   3c99c:	ldr	x15, [sp, #0x1c0]
   3c9a0:	str	x1, [x15, #0x18]
   3c9a4:	ldr	x2, [x19, #0x6238]
   3c9a8:	ldr	x5, [sp, #0x1c0]
   3c9ac:	str	x2, [x5, #0xa30]
   3c9b0:	ldr	x2, [sp, #0x1c0]
   3c9b4:	str	x0, [x2, #0x10]
   3c9b8:	ldr	x0, [sp, #0x1c0]
   3c9bc:	str	x1, [x0, #0x18]
   3c9c0:	ldr	x5, [x19, #0x58f8]
   3c9c4:	str	x5, [x0, #0xf0]
   3c9c8:	ldr	x5, [x19, #0x5900]
   3c9cc:	str	x5, [x0, #0xf8]
   3c9d0:	ldr	x6, [x19, #0x5908]
   3c9d4:	str	x6, [x0, #0x100]
   3c9d8:	ldr	x7, [x19, #0x5910]
   3c9dc:	str	x7, [x0, #0x108]
   3c9e0:	ldr	x8, [x19, #0x5918]
   3c9e4:	str	x8, [x0, #0x110]
   3c9e8:	ldr	x9, [x19, #0x5920]
   3c9ec:	str	x9, [x0, #0x118]
   3c9f0:	ldr	x10, [x19, #0x5928]
   3c9f4:	str	x10, [x0, #0x120]
   3c9f8:	ldr	x11, [x19, #0x5930]
   3c9fc:	str	x11, [x0, #0x128]
   3ca00:	ldr	x12, [x19, #0x5938]
   3ca04:	str	x12, [x0, #0x130]
   3ca08:	ldr	x13, [x19, #0x5a70]
   3ca0c:	str	x13, [x0, #0x268]
   3ca10:	ldr	x14, [x19, #0x5a78]
   3ca14:	str	x14, [x0, #0x270]
   3ca18:	ldr	x15, [x19, #0x5a80]
   3ca1c:	str	x15, [x0, #0x278]
   3ca20:	ldr	x0, [x19, #0x5a88]
   3ca24:	ldr	x1, [sp, #0x1c0]
   3ca28:	str	x0, [x1, #0x280]
   3ca2c:	ldr	x0, [x19, #0x5a90]
   3ca30:	str	x0, [x1, #0x288]
   3ca34:	ldr	x0, [x19, #0x5a98]
   3ca38:	ldr	x5, [sp, #0x1c0]
   3ca3c:	str	x0, [x5, #0x290]
   3ca40:	ldr	x0, [x19, #0x5aa0]
   3ca44:	ldr	x7, [sp, #0x1c0]
   3ca48:	str	x0, [x7, #0x298]
   3ca4c:	ldr	x0, [x19, #0x5aa8]
   3ca50:	ldr	x10, [sp, #0x1c0]
   3ca54:	str	x0, [x10, #0x2a0]
   3ca58:	ldr	x0, [x19, #0x5ab0]
   3ca5c:	ldr	x13, [sp, #0x1c0]
   3ca60:	str	x0, [x13, #0x2a8]
   3ca64:	ldr	x0, [x19, #0x5d38]
   3ca68:	str	x0, [x1, #0x530]
   3ca6c:	ldr	x0, [x19, #0x5d40]
   3ca70:	str	x0, [x1, #0x538]
   3ca74:	ldr	x0, [x19, #0x5d48]
   3ca78:	str	x0, [x1, #0x540]
   3ca7c:	ldr	x0, [x19, #0x5d50]
   3ca80:	str	x0, [x1, #0x548]
   3ca84:	ldr	x0, [x19, #0x5d58]
   3ca88:	str	x0, [x1, #0x550]
   3ca8c:	ldr	x0, [x19, #0x5d60]
   3ca90:	str	x0, [x1, #0x558]
   3ca94:	ldr	x0, [x19, #0x5d68]
   3ca98:	str	x0, [x1, #0x560]
   3ca9c:	ldr	x0, [x19, #0x5d70]
   3caa0:	str	x0, [x1, #0x568]
   3caa4:	ldr	x0, [x19, #0x5e98]
   3caa8:	str	x0, [x1, #0x690]
   3caac:	ldr	x0, [x19, #0x5ea0]
   3cab0:	str	x0, [x1, #0x698]
   3cab4:	ldr	x0, [x19, #0x5ea8]
   3cab8:	str	x0, [x1, #0x6a0]
   3cabc:	ldr	x0, [x19, #0x5eb0]
   3cac0:	str	x0, [x1, #0x6a8]
   3cac4:	ldr	x0, [x19, #0x5eb8]
   3cac8:	str	x0, [x1, #0x6b0]
   3cacc:	ldr	x0, [x19, #0x5ec0]
   3cad0:	str	x0, [x1, #0x6b8]
   3cad4:	ldr	x0, [x19, #0x5ec8]
   3cad8:	str	x0, [x1, #0x6c0]
   3cadc:	ldr	x0, [x19, #0x5ed0]
   3cae0:	str	x0, [x1, #0x6c8]
   3cae4:	ldr	x0, [x19, #0x62a8]
   3cae8:	str	x0, [x1, #0xaa0]
   3caec:	ldr	x0, [x19, #0x62b0]
   3caf0:	str	x0, [x5, #0xaa8]
   3caf4:	ldr	x0, [x19, #0x62b8]
   3caf8:	str	x0, [x7, #0xab0]
   3cafc:	ldr	x0, [x19, #0x62c0]
   3cb00:	str	x0, [x10, #0xab8]
   3cb04:	ldr	x0, [x19, #0x62c8]
   3cb08:	str	x0, [x13, #0xac0]
   3cb0c:	ldr	x0, [x19, #0x62d0]
   3cb10:	str	x0, [x1, #0xac8]
   3cb14:	mov	x0, #0x0
   3cb18:	str	x0, [x1, #0xad0]
   3cb1c:	ldr	x1, [x19, #0x62e0]
   3cb20:	str	x1, [x2, #0xad8]
   3cb24:	ldr	x1, [x19, #0x62e8]
   3cb28:	str	x1, [x2, #0xae0]
   3cb2c:	ldr	x1, [sp, #0x1c0]
   3cb30:	str	x0, [x1, #0xae8]
   3cb34:	ldr	x1, [x19, #0x62f8]
   3cb38:	str	x1, [x2, #0xaf0]
   3cb3c:	ldr	x1, [x19, #0x6300]
   3cb40:	str	x1, [x2, #0xaf8]
   3cb44:	ldr	x1, [sp, #0x1c0]
   3cb48:	str	x0, [x1, #0xb00]
   3cb4c:	ldr	x0, [x19, #0x6310]
   3cb50:	str	x0, [x1, #0xb08]
   3cb54:	ldr	x0, [x19, #0x6318]
   3cb58:	str	x0, [x1, #0xb10]
   3cb5c:	mov	x1, #0x64e
   3cb60:	mov	x2, #-0x9
   3cb64:	ldr	x21, [sp, #0x1d0]
   3cb68:	ldur	x0, [sp, #0x8]
   3cb6c:	mov	x5, x23
   3cb70:	ldr	x6, [sp, #0x1c8]
   3cb74:	blr	x21
   3cb78:	cmp	x0, #0x0
   3cb7c:	b.ne	0x415f8
   3cb80:	mov	x0, #0x3
   3cb84:	ldr	x14, [sp, #0x1b8]
   3cb88:	cmp	x14, #0x2
   3cb8c:	b.lo	0x41600
   3cb90:	mov	x5, #0x0
   3cb94:	ldr	x3, [sp, #0x1c0]
   3cb98:	str	x5, [x3]
   3cb9c:	ldr	x0, [x19, #0x2180]
   3cba0:	str	x0, [x3, #0x8]
   3cba4:	mov	x1, #0x64e
   3cba8:	ldur	x0, [sp, #0x8]
   3cbac:	ldr	x6, [sp, #0x1c8]
   3cbb0:	ldr	x21, [sp, #0x1d0]
   3cbb4:	mov	x4, x23
   3cbb8:	mov	x2, x5
   3cbbc:	blr	x21
   3cbc0:	cmp	x0, #0x0
   3cbc4:	b.ne	0x41608
   3cbc8:	mov	x0, #0x3
   3cbcc:	mov	x25, x0
   3cbd0:	b	0x43b34
   3cbd4:	ldr	x20, [sp, #0x168]
   3cbd8:	ldr	x5, [x20, x2, lsl #3]
   3cbdc:	ldr	x20, [sp, #0x120]
   3cbe0:	cmp	x23, x20
   3cbe4:	b.lo	0x3ce68
   3cbe8:	b	0x41610
   3cbec:	ldr	x3, [x19, #0x54d8]
   3cbf0:	ldr	x4, [x19, #0x54e0]
   3cbf4:	mov	x0, #0x0
   3cbf8:	str	x0, [x19, #0x54d0]
   3cbfc:	mov	x0, #0x3
   3cc00:	ldr	x14, [sp, #0x1b8]
   3cc04:	cmp	x14, #0x164
   3cc08:	b.lo	0x41738
   3cc0c:	ldr	x0, [x19, #0x5818]
   3cc10:	ldr	x1, [sp, #0x1c0]
   3cc14:	str	x0, [x1, #0x10]
   3cc18:	ldr	x1, [x19, #0x5820]
   3cc1c:	ldr	x2, [sp, #0x1c0]
   3cc20:	str	x1, [x2, #0x18]
   3cc24:	ldr	x2, [x19, #0x6238]
   3cc28:	ldr	x5, [sp, #0x1c0]
   3cc2c:	str	x2, [x5, #0xa30]
   3cc30:	ldr	x2, [sp, #0x1c0]
   3cc34:	str	x0, [x2, #0x10]
   3cc38:	ldr	x0, [sp, #0x1c0]
   3cc3c:	str	x1, [x0, #0x18]
   3cc40:	ldr	x0, [x19, #0x58f8]
   3cc44:	ldr	x1, [sp, #0x1c0]
   3cc48:	str	x0, [x1, #0xf0]
   3cc4c:	ldr	x0, [x19, #0x5900]
   3cc50:	str	x0, [x1, #0xf8]
   3cc54:	ldr	x0, [x19, #0x5908]
   3cc58:	str	x0, [x1, #0x100]
   3cc5c:	ldr	x0, [x19, #0x5910]
   3cc60:	str	x0, [x1, #0x108]
   3cc64:	ldr	x1, [x19, #0x5918]
   3cc68:	ldr	x0, [sp, #0x1c0]
   3cc6c:	str	x1, [x0, #0x110]
   3cc70:	ldr	x2, [x19, #0x5920]
   3cc74:	str	x2, [x0, #0x118]
   3cc78:	ldr	x5, [x19, #0x5928]
   3cc7c:	str	x5, [x0, #0x120]
   3cc80:	ldr	x5, [x19, #0x5930]
   3cc84:	str	x5, [x0, #0x128]
   3cc88:	ldr	x5, [x19, #0x5938]
   3cc8c:	str	x5, [x0, #0x130]
   3cc90:	ldr	x6, [x19, #0x5a70]
   3cc94:	str	x6, [x0, #0x268]
   3cc98:	ldr	x7, [x19, #0x5a78]
   3cc9c:	ldr	x2, [sp, #0x1c0]
   3cca0:	str	x7, [x2, #0x270]
   3cca4:	ldr	x8, [x19, #0x5a80]
   3cca8:	ldr	x5, [sp, #0x1c0]
   3ccac:	str	x8, [x5, #0x278]
   3ccb0:	ldr	x9, [x19, #0x5a88]
   3ccb4:	ldr	x8, [sp, #0x1c0]
   3ccb8:	str	x9, [x8, #0x280]
   3ccbc:	ldr	x10, [x19, #0x5a90]
   3ccc0:	ldr	x11, [sp, #0x1c0]
   3ccc4:	str	x10, [x11, #0x288]
   3ccc8:	ldr	x11, [x19, #0x5a98]
   3cccc:	ldr	x14, [sp, #0x1c0]
   3ccd0:	str	x11, [x14, #0x290]
   3ccd4:	ldr	x12, [x19, #0x5aa0]
   3ccd8:	str	x12, [x0, #0x298]
   3ccdc:	ldr	x13, [x19, #0x5aa8]
   3cce0:	str	x13, [x0, #0x2a0]
   3cce4:	ldr	x14, [x19, #0x5ab0]
   3cce8:	str	x14, [x0, #0x2a8]
   3ccec:	ldr	x15, [x19, #0x5d38]
   3ccf0:	str	x15, [x0, #0x530]
   3ccf4:	ldr	x0, [x19, #0x5d40]
   3ccf8:	ldr	x1, [sp, #0x1c0]
   3ccfc:	str	x0, [x1, #0x538]
   3cd00:	ldr	x0, [x19, #0x5d48]
   3cd04:	str	x0, [x1, #0x540]
   3cd08:	ldr	x0, [x19, #0x5d50]
   3cd0c:	str	x0, [x1, #0x548]
   3cd10:	ldr	x0, [x19, #0x5d58]
   3cd14:	str	x0, [x1, #0x550]
   3cd18:	ldr	x0, [x19, #0x5d60]
   3cd1c:	str	x0, [x1, #0x558]
   3cd20:	ldr	x0, [x19, #0x5d68]
   3cd24:	str	x0, [x1, #0x560]
   3cd28:	ldr	x0, [x19, #0x5d70]
   3cd2c:	str	x0, [x1, #0x568]
   3cd30:	ldr	x0, [x19, #0x5e98]
   3cd34:	str	x0, [x1, #0x690]
   3cd38:	ldr	x0, [x19, #0x5ea0]
   3cd3c:	str	x0, [x1, #0x698]
   3cd40:	ldr	x0, [x19, #0x5ea8]
   3cd44:	str	x0, [x1, #0x6a0]
   3cd48:	ldr	x0, [x19, #0x5eb0]
   3cd4c:	str	x0, [x1, #0x6a8]
   3cd50:	ldr	x0, [x19, #0x5eb8]
   3cd54:	str	x0, [x1, #0x6b0]
   3cd58:	ldr	x0, [x19, #0x5ec0]
   3cd5c:	str	x0, [x2, #0x6b8]
   3cd60:	ldr	x0, [x19, #0x5ec8]
   3cd64:	str	x0, [x5, #0x6c0]
   3cd68:	ldr	x0, [x19, #0x5ed0]
   3cd6c:	str	x0, [x8, #0x6c8]
   3cd70:	ldr	x0, [x19, #0x62a8]
   3cd74:	ldr	x11, [sp, #0x1c0]
   3cd78:	str	x0, [x11, #0xaa0]
   3cd7c:	ldr	x0, [x19, #0x62b0]
   3cd80:	ldr	x14, [sp, #0x1c0]
   3cd84:	str	x0, [x14, #0xaa8]
   3cd88:	ldr	x0, [x19, #0x62b8]
   3cd8c:	str	x0, [x1, #0xab0]
   3cd90:	ldr	x0, [x19, #0x62c0]
   3cd94:	str	x0, [x1, #0xab8]
   3cd98:	ldr	x0, [x19, #0x62c8]
   3cd9c:	str	x0, [x1, #0xac0]
   3cda0:	ldr	x0, [x19, #0x62d0]
   3cda4:	str	x0, [x1, #0xac8]
   3cda8:	mov	x0, #0x0
   3cdac:	str	x0, [x1, #0xad0]
   3cdb0:	ldr	x1, [x19, #0x62e0]
   3cdb4:	str	x1, [x2, #0xad8]
   3cdb8:	ldr	x1, [x19, #0x62e8]
   3cdbc:	str	x1, [x2, #0xae0]
   3cdc0:	ldr	x1, [sp, #0x1c0]
   3cdc4:	str	x0, [x1, #0xae8]
   3cdc8:	ldr	x1, [x19, #0x62f8]
   3cdcc:	str	x1, [x2, #0xaf0]
   3cdd0:	ldr	x1, [x19, #0x6300]
   3cdd4:	str	x1, [x2, #0xaf8]
   3cdd8:	ldr	x1, [sp, #0x1c0]
   3cddc:	str	x0, [x1, #0xb00]
   3cde0:	ldr	x0, [x19, #0x6310]
   3cde4:	str	x0, [x1, #0xb08]
   3cde8:	ldr	x0, [x19, #0x6318]
   3cdec:	str	x0, [x1, #0xb10]
   3cdf0:	mov	x1, #0x650
   3cdf4:	mov	x2, #-0x9
   3cdf8:	ldr	x21, [sp, #0x1d0]
   3cdfc:	ldur	x0, [sp, #0x8]
   3ce00:	mov	x5, x20
   3ce04:	ldr	x6, [sp, #0x1c8]
   3ce08:	blr	x21
   3ce0c:	cmp	x0, #0x0
   3ce10:	b.ne	0x41740
   3ce14:	mov	x0, #0x3
   3ce18:	ldr	x14, [sp, #0x1b8]
   3ce1c:	cmp	x14, #0x2
   3ce20:	b.lo	0x41748
   3ce24:	mov	x5, #0x0
   3ce28:	ldr	x3, [sp, #0x1c0]
   3ce2c:	str	x5, [x3]
   3ce30:	ldr	x0, [x19, #0x2190]
   3ce34:	str	x0, [x3, #0x8]
   3ce38:	mov	x1, #0x650
   3ce3c:	ldur	x0, [sp, #0x8]
   3ce40:	ldr	x6, [sp, #0x1c8]
   3ce44:	ldr	x21, [sp, #0x1d0]
   3ce48:	mov	x4, x20
   3ce4c:	mov	x2, x5
   3ce50:	blr	x21
   3ce54:	cmp	x0, #0x0
   3ce58:	b.ne	0x41750
   3ce5c:	mov	x0, #0x3
   3ce60:	mov	x25, x0
   3ce64:	b	0x43b34
   3ce68:	ldr	x20, [sp, #0x128]
   3ce6c:	stur	x4, [sp, #0x60]
   3ce70:	stur	x1, [sp, #0xb8]
   3ce74:	str	x5, [sp, #0x108]
   3ce78:	str	x0, [sp, #0x118]
   3ce7c:	ldr	x14, [x20, x23, lsl #3]
   3ce80:	str	x14, [sp, #0x100]
   3ce84:	mov	w0, #0xb946
   3ce88:	movk	w0, #0x1, lsl #16
   3ce8c:	sub	x3, x3, x0
   3ce90:	mov	x0, #0x0
   3ce94:	stur	x0, [sp, #0x10]
   3ce98:	ldur	x23, [sp, #0x10]
   3ce9c:	ldur	x1, [sp, #0x10]
   3cea0:	stur	x1, [sp, #0x18]
   3cea4:	stur	x1, [sp, #0x40]
   3cea8:	stur	x1, [sp, #0x48]
   3ceac:	mov	w1, #0x1226
   3ceb0:	movk	w1, #0x1, lsl #16
   3ceb4:	cmp	x3, x1
   3ceb8:	b.hs	0x3d280
   3cebc:	mov	x1, #0x0
   3cec0:	str	x1, [x19, #0x30]
   3cec4:	mov	x2, #0x1000000000000000
   3cec8:	str	x2, [x19, #0x38]
   3cecc:	mov	x4, #0x1
   3ced0:	str	x4, [x19, #0x48]
   3ced4:	mov	x5, #0x101010101010101
   3ced8:	str	x5, [x19, #0x50]
   3cedc:	mov	x5, #0x2
   3cee0:	str	x5, [x19, #0x58]
   3cee4:	mov	x20, x5
   3cee8:	mov	x8, #0x3
   3ceec:	str	x8, [x19, #0x60]
   3cef0:	mov	x8, #0x4
   3cef4:	str	x8, [x19, #0x68]
   3cef8:	mov	x8, #0xf0f0f0f0f0f0f0f
   3cefc:	str	x8, [x19, #0x90]
   3cf00:	mov	x9, #0x3333333333333333
   3cf04:	str	x9, [x19, #0xa0]
   3cf08:	mov	x10, #0x38
   3cf0c:	str	x10, [x19, #0xa8]
   3cf10:	mov	x13, #0x3a
   3cf14:	str	x13, [x19, #0xb0]
   3cf18:	mov	x13, #0x5555555555555555
   3cf1c:	str	x13, [x19, #0xc8]
   3cf20:	mov	x13, #0x3ffffffffffffff
   3cf24:	str	x13, [x19, #0xd8]
   3cf28:	str	x1, [x19, #0x178]
   3cf2c:	str	x4, [x19, #0x180]
   3cf30:	ldur	x1, [sp, #0xc8]
   3cf34:	str	x1, [x19, #0x2140]
   3cf38:	ldr	x27, [sp, #0x1b0]
   3cf3c:	str	x27, [x19, #0x2148]
   3cf40:	ldr	x26, [sp, #0x118]
   3cf44:	uxtb	w1, w26
   3cf48:	str	x1, [x19, #0x2158]
   3cf4c:	ldur	x10, [sp, #0x58]
   3cf50:	str	x10, [x19, #0x54d0]
   3cf54:	str	x3, [x19, #0x54d8]
   3cf58:	ldur	x1, [sp, #0x60]
   3cf5c:	str	x1, [x19, #0x54e0]
   3cf60:	ldur	x1, [sp, #0xc8]
   3cf64:	str	x1, [x19, #0x5818]
   3cf68:	str	x27, [x19, #0x5820]
   3cf6c:	ldur	x1, [sp, #0xb8]
   3cf70:	str	x1, [x19, #0x58f8]
   3cf74:	ldr	x14, [sp, #0x108]
   3cf78:	str	x14, [x19, #0x5900]
   3cf7c:	ldur	x1, [sp, #0xc8]
   3cf80:	str	x1, [x19, #0x5908]
   3cf84:	ldr	x14, [sp, #0x100]
   3cf88:	str	x14, [x19, #0x5910]
   3cf8c:	ldur	x1, [sp, #0x10]
   3cf90:	str	x1, [x19, #0x5918]
   3cf94:	str	x0, [x19, #0x5920]
   3cf98:	str	x23, [x19, #0x5928]
   3cf9c:	ldur	x23, [sp, #0x40]
   3cfa0:	str	x23, [x19, #0x5930]
   3cfa4:	ldur	x26, [sp, #0x48]
   3cfa8:	str	x26, [x19, #0x5938]
   3cfac:	ldur	x24, [sp, #0x28]
   3cfb0:	str	x24, [x19, #0x6238]
   3cfb4:	add	x0, x15, #0x1
   3cfb8:	str	x0, [x19, #0x62a8]
   3cfbc:	ldur	x23, [sp, #0x68]
   3cfc0:	str	x23, [x19, #0x62b0]
   3cfc4:	ldur	x28, [sp, #0x70]
   3cfc8:	str	x28, [x19, #0x62b8]
   3cfcc:	ldur	x1, [sp, #0x50]
   3cfd0:	sub	x1, x1, x3
   3cfd4:	mov	w2, #0xb946
   3cfd8:	movk	w2, #0x1, lsl #16
   3cfdc:	msub	x0, x0, x2, x1
   3cfe0:	str	x0, [x19, #0x62c0]
   3cfe4:	str	x4, [x19, #0x62c8]
   3cfe8:	ldur	x14, [sp, #0x18]
   3cfec:	str	x14, [x19, #0x62d0]
   3cff0:	ldur	x22, [sp, #0x78]
   3cff4:	str	x22, [x19, #0x62e0]
   3cff8:	ldur	x9, [sp, #0x80]
   3cffc:	str	x9, [x19, #0x62e8]
   3d000:	str	x12, [x19, #0x62f8]
   3d004:	str	x11, [x19, #0x6300]
   3d008:	str	x7, [x19, #0x6310]
   3d00c:	str	x6, [x19, #0x6318]
   3d010:	ldr	x0, [x19, #0x54d0]
   3d014:	cmp	x0, #0x0
   3d018:	b.eq	0x3d258
   3d01c:	ldr	x3, [x19, #0x54d8]
   3d020:	ldr	x4, [x19, #0x54e0]
   3d024:	mov	x0, #0x0
   3d028:	str	x0, [x19, #0x54d0]
   3d02c:	mov	x0, #0x3
   3d030:	ldr	x14, [sp, #0x1b8]
   3d034:	mov	x25, x0
   3d038:	cmp	x14, #0x164
   3d03c:	b.lo	0x43b34
   3d040:	ldr	x0, [x19, #0x5818]
   3d044:	ldr	x1, [sp, #0x1c0]
   3d048:	str	x0, [x1, #0x10]
   3d04c:	ldr	x1, [x19, #0x5820]
   3d050:	ldr	x2, [sp, #0x1c0]
   3d054:	str	x1, [x2, #0x18]
   3d058:	ldr	x2, [x19, #0x6238]
   3d05c:	ldr	x5, [sp, #0x1c0]
   3d060:	str	x2, [x5, #0xa30]
   3d064:	ldr	x2, [sp, #0x1c0]
   3d068:	str	x0, [x2, #0x10]
   3d06c:	ldr	x0, [sp, #0x1c0]
   3d070:	str	x1, [x0, #0x18]
   3d074:	ldr	x0, [x19, #0x58f8]
   3d078:	ldr	x1, [sp, #0x1c0]
   3d07c:	str	x0, [x1, #0xf0]
   3d080:	ldr	x0, [x19, #0x5900]
   3d084:	str	x0, [x1, #0xf8]
   3d088:	ldr	x0, [x19, #0x5908]
   3d08c:	str	x0, [x1, #0x100]
   3d090:	ldr	x0, [x19, #0x5910]
   3d094:	str	x0, [x1, #0x108]
   3d098:	ldr	x0, [x19, #0x5918]
   3d09c:	str	x0, [x5, #0x110]
   3d0a0:	ldr	x0, [x19, #0x5920]
   3d0a4:	ldr	x6, [sp, #0x1c0]
   3d0a8:	str	x0, [x6, #0x118]
   3d0ac:	ldr	x1, [x19, #0x5928]
   3d0b0:	ldr	x9, [sp, #0x1c0]
   3d0b4:	str	x1, [x9, #0x120]
   3d0b8:	ldr	x2, [x19, #0x5930]
   3d0bc:	ldr	x12, [sp, #0x1c0]
   3d0c0:	str	x2, [x12, #0x128]
   3d0c4:	ldr	x5, [x19, #0x5938]
   3d0c8:	ldr	x15, [sp, #0x1c0]
   3d0cc:	str	x5, [x15, #0x130]
   3d0d0:	ldr	x5, [x19, #0x5a70]
   3d0d4:	ldr	x0, [sp, #0x1c0]
   3d0d8:	str	x5, [x0, #0x268]
   3d0dc:	ldr	x5, [x19, #0x5a78]
   3d0e0:	str	x5, [x0, #0x270]
   3d0e4:	ldr	x6, [x19, #0x5a80]
   3d0e8:	str	x6, [x0, #0x278]
   3d0ec:	ldr	x7, [x19, #0x5a88]
   3d0f0:	str	x7, [x0, #0x280]
   3d0f4:	ldr	x8, [x19, #0x5a90]
   3d0f8:	str	x8, [x0, #0x288]
   3d0fc:	ldr	x9, [x19, #0x5a98]
   3d100:	str	x9, [x0, #0x290]
   3d104:	ldr	x10, [x19, #0x5aa0]
   3d108:	str	x10, [x0, #0x298]
   3d10c:	ldr	x11, [x19, #0x5aa8]
   3d110:	str	x11, [x0, #0x2a0]
   3d114:	ldr	x12, [x19, #0x5ab0]
   3d118:	str	x12, [x0, #0x2a8]
   3d11c:	ldr	x13, [x19, #0x5d38]
   3d120:	str	x13, [x0, #0x530]
   3d124:	ldr	x14, [x19, #0x5d40]
   3d128:	str	x14, [x0, #0x538]
   3d12c:	ldr	x15, [x19, #0x5d48]
   3d130:	str	x15, [x0, #0x540]
   3d134:	ldr	x0, [x19, #0x5d50]
   3d138:	ldr	x1, [sp, #0x1c0]
   3d13c:	str	x0, [x1, #0x548]
   3d140:	ldr	x0, [x19, #0x5d58]
   3d144:	str	x0, [x1, #0x550]
   3d148:	ldr	x0, [x19, #0x5d60]
   3d14c:	str	x0, [x1, #0x558]
   3d150:	ldr	x0, [x19, #0x5d68]
   3d154:	str	x0, [x1, #0x560]
   3d158:	ldr	x0, [x19, #0x5d70]
   3d15c:	ldr	x5, [sp, #0x1c0]
   3d160:	str	x0, [x5, #0x568]
   3d164:	ldr	x0, [x19, #0x5e98]
   3d168:	ldr	x6, [sp, #0x1c0]
   3d16c:	str	x0, [x6, #0x690]
   3d170:	ldr	x0, [x19, #0x5ea0]
   3d174:	ldr	x9, [sp, #0x1c0]
   3d178:	str	x0, [x9, #0x698]
   3d17c:	ldr	x0, [x19, #0x5ea8]
   3d180:	ldr	x12, [sp, #0x1c0]
   3d184:	str	x0, [x12, #0x6a0]
   3d188:	ldr	x0, [x19, #0x5eb0]
   3d18c:	ldr	x15, [sp, #0x1c0]
   3d190:	str	x0, [x15, #0x6a8]
   3d194:	ldr	x0, [x19, #0x5eb8]
   3d198:	str	x0, [x1, #0x6b0]
   3d19c:	ldr	x0, [x19, #0x5ec0]
   3d1a0:	str	x0, [x1, #0x6b8]
   3d1a4:	ldr	x0, [x19, #0x5ec8]
   3d1a8:	str	x0, [x1, #0x6c0]
   3d1ac:	ldr	x0, [x19, #0x5ed0]
   3d1b0:	str	x0, [x1, #0x6c8]
   3d1b4:	ldr	x0, [x19, #0x62a8]
   3d1b8:	str	x0, [x1, #0xaa0]
   3d1bc:	ldr	x0, [x19, #0x62b0]
   3d1c0:	str	x0, [x1, #0xaa8]
   3d1c4:	ldr	x0, [x19, #0x62b8]
   3d1c8:	str	x0, [x1, #0xab0]
   3d1cc:	ldr	x0, [x19, #0x62c0]
   3d1d0:	str	x0, [x1, #0xab8]
   3d1d4:	ldr	x0, [x19, #0x62c8]
   3d1d8:	str	x0, [x1, #0xac0]
   3d1dc:	ldr	x0, [x19, #0x62d0]
   3d1e0:	str	x0, [x1, #0xac8]
   3d1e4:	mov	x0, #0x0
   3d1e8:	str	x0, [x1, #0xad0]
   3d1ec:	ldr	x1, [x19, #0x62e0]
   3d1f0:	ldr	x2, [sp, #0x1c0]
   3d1f4:	str	x1, [x2, #0xad8]
   3d1f8:	ldr	x1, [x19, #0x62e8]
   3d1fc:	str	x1, [x2, #0xae0]
   3d200:	ldr	x1, [sp, #0x1c0]
   3d204:	str	x0, [x1, #0xae8]
   3d208:	ldr	x1, [x19, #0x62f8]
   3d20c:	str	x1, [x2, #0xaf0]
   3d210:	ldr	x1, [x19, #0x6300]
   3d214:	str	x1, [x2, #0xaf8]
   3d218:	ldr	x1, [sp, #0x1c0]
   3d21c:	str	x0, [x1, #0xb00]
   3d220:	ldr	x0, [x19, #0x6310]
   3d224:	str	x0, [x5, #0xb08]
   3d228:	ldr	x0, [x19, #0x6318]
   3d22c:	ldr	x7, [sp, #0x1c0]
   3d230:	str	x0, [x7, #0xb10]
   3d234:	mov	x1, #0x653
   3d238:	mov	x2, #-0x9
   3d23c:	mov	x5, #0x1
   3d240:	ldur	x0, [sp, #0x8]
   3d244:	ldr	x6, [sp, #0x1c8]
   3d248:	ldr	x21, [sp, #0x1d0]
   3d24c:	blr	x21
   3d250:	cmp	x0, #0x0
   3d254:	b.ne	0x41758
   3d258:	mov	x0, #0x0
   3d25c:	mov	x1, x20
   3d260:	add	sp, sp, #0x1e0
   3d264:	ldp	x19, x20, [sp], #0x10
   3d268:	ldp	x21, x22, [sp], #0x10
   3d26c:	ldp	x23, x24, [sp], #0x10
   3d270:	ldp	x25, x26, [sp], #0x10
   3d274:	ldp	x27, x28, [sp], #0x10
   3d278:	ldp	x29, x30, [sp], #0x10
   3d27c:	.long	0xd65f0fff
   3d280:	ldur	x1, [sp, #0xb8]
   3d284:	ldr	x14, [sp, #0x108]
   3d288:	ldr	x26, [sp, #0x118]
   3d28c:	cmp	x1, x14
   3d290:	cset	x2, lo
   3d294:	stur	x2, [sp, #0xf8]
   3d298:	cmp	x1, x14
   3d29c:	b.lo	0x3d2d0
   3d2a0:	mov	w5, #0x1226
   3d2a4:	movk	w5, #0x1, lsl #16
   3d2a8:	sub	x3, x3, x5
   3d2ac:	ldur	x8, [sp, #0x48]
   3d2b0:	stur	x8, [sp, #0xa0]
   3d2b4:	stur	x23, [sp, #0x38]
   3d2b8:	stur	x0, [sp, #0x30]
   3d2bc:	ldur	x14, [sp, #0x10]
   3d2c0:	mov	x5, x1
   3d2c4:	mov	x4, x23
   3d2c8:	ldur	x2, [sp, #0x40]
   3d2cc:	b	0x3eb08
   3d2d0:	ldr	x20, [sp, #0x150]
   3d2d4:	cmp	x1, x20
   3d2d8:	b.lo	0x3d54c
   3d2dc:	b	0x41760
   3d2e0:	ldr	x3, [x19, #0x54d8]
   3d2e4:	ldr	x4, [x19, #0x54e0]
   3d2e8:	mov	x5, #0x0
   3d2ec:	str	x5, [x19, #0x54d0]
   3d2f0:	mov	x0, #0x3
   3d2f4:	ldr	x14, [sp, #0x1b8]
   3d2f8:	mov	x25, x0
   3d2fc:	cmp	x14, #0x164
   3d300:	b.lo	0x43b34
   3d304:	ldr	x7, [x19, #0x5818]
   3d308:	ldr	x12, [sp, #0x1c0]
   3d30c:	str	x7, [x12, #0x10]
   3d310:	ldr	x8, [x19, #0x5820]
   3d314:	ldr	x15, [sp, #0x1c0]
   3d318:	str	x8, [x15, #0x18]
   3d31c:	ldr	x9, [x19, #0x6238]
   3d320:	ldr	x0, [sp, #0x1c0]
   3d324:	str	x9, [x0, #0xa30]
   3d328:	str	x7, [x0, #0x10]
   3d32c:	str	x8, [x0, #0x18]
   3d330:	ldr	x12, [x19, #0x58f8]
   3d334:	str	x12, [x0, #0xf0]
   3d338:	ldr	x13, [x19, #0x5900]
   3d33c:	str	x13, [x0, #0xf8]
   3d340:	ldr	x14, [x19, #0x5908]
   3d344:	str	x14, [x0, #0x100]
   3d348:	ldr	x15, [x19, #0x5910]
   3d34c:	str	x15, [x0, #0x108]
   3d350:	ldr	x0, [x19, #0x5918]
   3d354:	ldr	x1, [sp, #0x1c0]
   3d358:	str	x0, [x1, #0x110]
   3d35c:	ldr	x0, [x19, #0x5920]
   3d360:	str	x0, [x1, #0x118]
   3d364:	ldr	x0, [x19, #0x5928]
   3d368:	str	x0, [x1, #0x120]
   3d36c:	ldr	x0, [x19, #0x5930]
   3d370:	str	x0, [x1, #0x128]
   3d374:	ldr	x0, [x19, #0x5938]
   3d378:	str	x0, [x1, #0x130]
   3d37c:	ldr	x0, [x19, #0x5a70]
   3d380:	str	x0, [x1, #0x268]
   3d384:	ldr	x0, [x19, #0x5a78]
   3d388:	str	x0, [x1, #0x270]
   3d38c:	ldr	x0, [x19, #0x5a80]
   3d390:	str	x0, [x1, #0x278]
   3d394:	ldr	x0, [x19, #0x5a88]
   3d398:	str	x0, [x1, #0x280]
   3d39c:	ldr	x0, [x19, #0x5a90]
   3d3a0:	str	x0, [x1, #0x288]
   3d3a4:	ldr	x0, [x19, #0x5a98]
   3d3a8:	ldr	x5, [sp, #0x1c0]
   3d3ac:	str	x0, [x5, #0x290]
   3d3b0:	ldr	x0, [x19, #0x5aa0]
   3d3b4:	ldr	x7, [sp, #0x1c0]
   3d3b8:	str	x0, [x7, #0x298]
   3d3bc:	ldr	x0, [x19, #0x5aa8]
   3d3c0:	ldr	x10, [sp, #0x1c0]
   3d3c4:	str	x0, [x10, #0x2a0]
   3d3c8:	ldr	x0, [x19, #0x5ab0]
   3d3cc:	ldr	x13, [sp, #0x1c0]
   3d3d0:	str	x0, [x13, #0x2a8]
   3d3d4:	ldr	x0, [x19, #0x5d38]
   3d3d8:	str	x0, [x1, #0x530]
   3d3dc:	ldr	x0, [x19, #0x5d40]
   3d3e0:	str	x0, [x1, #0x538]
   3d3e4:	ldr	x0, [x19, #0x5d48]
   3d3e8:	str	x0, [x1, #0x540]
   3d3ec:	ldr	x0, [x19, #0x5d50]
   3d3f0:	str	x0, [x1, #0x548]
   3d3f4:	ldr	x0, [x19, #0x5d58]
   3d3f8:	str	x0, [x1, #0x550]
   3d3fc:	ldr	x0, [x19, #0x5d60]
   3d400:	str	x0, [x1, #0x558]
   3d404:	ldr	x0, [x19, #0x5d68]
   3d408:	str	x0, [x1, #0x560]
   3d40c:	ldr	x0, [x19, #0x5d70]
   3d410:	str	x0, [x1, #0x568]
   3d414:	ldr	x0, [x19, #0x5e98]
   3d418:	str	x0, [x1, #0x690]
   3d41c:	ldr	x0, [x19, #0x5ea0]
   3d420:	str	x0, [x1, #0x698]
   3d424:	ldr	x0, [x19, #0x5ea8]
   3d428:	str	x0, [x1, #0x6a0]
   3d42c:	ldr	x0, [x19, #0x5eb0]
   3d430:	str	x0, [x1, #0x6a8]
   3d434:	ldr	x0, [x19, #0x5eb8]
   3d438:	str	x0, [x1, #0x6b0]
   3d43c:	ldr	x0, [x19, #0x5ec0]
   3d440:	str	x0, [x1, #0x6b8]
   3d444:	ldr	x0, [x19, #0x5ec8]
   3d448:	str	x0, [x1, #0x6c0]
   3d44c:	ldr	x0, [x19, #0x5ed0]
   3d450:	str	x0, [x1, #0x6c8]
   3d454:	ldr	x0, [x19, #0x62a8]
   3d458:	str	x0, [x1, #0xaa0]
   3d45c:	ldr	x0, [x19, #0x62b0]
   3d460:	str	x0, [x5, #0xaa8]
   3d464:	ldr	x0, [x19, #0x62b8]
   3d468:	str	x0, [x7, #0xab0]
   3d46c:	ldr	x0, [x19, #0x62c0]
   3d470:	str	x0, [x10, #0xab8]
   3d474:	ldr	x0, [x19, #0x62c8]
   3d478:	str	x0, [x13, #0xac0]
   3d47c:	ldr	x0, [x19, #0x62d0]
   3d480:	str	x0, [x1, #0xac8]
   3d484:	mov	x0, #0x0
   3d488:	str	x0, [x1, #0xad0]
   3d48c:	ldr	x1, [x19, #0x62e0]
   3d490:	ldr	x2, [sp, #0x1c0]
   3d494:	str	x1, [x2, #0xad8]
   3d498:	ldr	x1, [x19, #0x62e8]
   3d49c:	str	x1, [x2, #0xae0]
   3d4a0:	ldr	x1, [sp, #0x1c0]
   3d4a4:	str	x0, [x1, #0xae8]
   3d4a8:	ldr	x1, [x19, #0x62f8]
   3d4ac:	str	x1, [x2, #0xaf0]
   3d4b0:	ldr	x1, [x19, #0x6300]
   3d4b4:	str	x1, [x2, #0xaf8]
   3d4b8:	ldr	x1, [sp, #0x1c0]
   3d4bc:	str	x0, [x1, #0xb00]
   3d4c0:	ldr	x0, [x19, #0x6310]
   3d4c4:	str	x0, [x1, #0xb08]
   3d4c8:	ldr	x0, [x19, #0x6318]
   3d4cc:	str	x0, [x1, #0xb10]
   3d4d0:	mov	x1, #0x668
   3d4d4:	mov	x2, #-0x9
   3d4d8:	ldr	x21, [sp, #0x1d0]
   3d4dc:	ldur	x0, [sp, #0x8]
   3d4e0:	mov	x5, x20
   3d4e4:	ldr	x6, [sp, #0x1c8]
   3d4e8:	blr	x21
   3d4ec:	cmp	x0, #0x0
   3d4f0:	b.ne	0x418f8
   3d4f4:	mov	x0, #0x3
   3d4f8:	ldr	x14, [sp, #0x1b8]
   3d4fc:	mov	x25, x0
   3d500:	cmp	x14, #0x2
   3d504:	b.lo	0x43b34
   3d508:	mov	x5, #0x0
   3d50c:	ldr	x3, [sp, #0x1c0]
   3d510:	str	x5, [x3]
   3d514:	ldr	x6, [x19, #0x2220]
   3d518:	str	x6, [x3, #0x8]
   3d51c:	mov	x1, #0x668
   3d520:	ldur	x0, [sp, #0x8]
   3d524:	ldr	x6, [sp, #0x1c8]
   3d528:	ldr	x21, [sp, #0x1d0]
   3d52c:	mov	x4, x20
   3d530:	mov	x2, x5
   3d534:	blr	x21
   3d538:	cmp	x0, #0x0
   3d53c:	b.ne	0x41900
   3d540:	mov	x0, #0x3
   3d544:	mov	x25, x0
   3d548:	b	0x43b34
   3d54c:	stur	x23, [sp, #0x38]
   3d550:	stur	x0, [sp, #0x30]
   3d554:	ldr	x20, [sp, #0x158]
   3d558:	mov	x14, x1
   3d55c:	ldr	x14, [x20, x14, lsl #3]
   3d560:	add	x1, x14, #0x1
   3d564:	cmp	x1, x14
   3d568:	b.lo	0x41908
   3d56c:	ldr	x20, [sp, #0x140]
   3d570:	cmp	x14, x20
   3d574:	b.lo	0x3d808
   3d578:	b	0x41a5c
   3d57c:	ldr	x3, [x19, #0x54d8]
   3d580:	ldr	x4, [x19, #0x54e0]
   3d584:	mov	x0, #0x0
   3d588:	str	x0, [x19, #0x54d0]
   3d58c:	mov	x0, #0x3
   3d590:	ldr	x14, [sp, #0x1b8]
   3d594:	mov	x25, x0
   3d598:	cmp	x14, #0x164
   3d59c:	b.lo	0x43b34
   3d5a0:	ldr	x0, [x19, #0x5818]
   3d5a4:	ldr	x1, [sp, #0x1c0]
   3d5a8:	str	x0, [x1, #0x10]
   3d5ac:	ldr	x1, [x19, #0x5820]
   3d5b0:	ldr	x2, [sp, #0x1c0]
   3d5b4:	str	x1, [x2, #0x18]
   3d5b8:	ldr	x2, [x19, #0x6238]
   3d5bc:	ldr	x5, [sp, #0x1c0]
   3d5c0:	str	x2, [x5, #0xa30]
   3d5c4:	ldr	x2, [sp, #0x1c0]
   3d5c8:	str	x0, [x2, #0x10]
   3d5cc:	ldr	x0, [sp, #0x1c0]
   3d5d0:	str	x1, [x0, #0x18]
   3d5d4:	ldr	x0, [x19, #0x58f8]
   3d5d8:	ldr	x1, [sp, #0x1c0]
   3d5dc:	str	x0, [x1, #0xf0]
   3d5e0:	ldr	x0, [x19, #0x5900]
   3d5e4:	str	x0, [x1, #0xf8]
   3d5e8:	ldr	x0, [x19, #0x5908]
   3d5ec:	str	x0, [x1, #0x100]
   3d5f0:	ldr	x1, [x19, #0x5910]
   3d5f4:	str	x1, [x2, #0x108]
   3d5f8:	ldr	x2, [x19, #0x5918]
   3d5fc:	str	x2, [x5, #0x110]
   3d600:	ldr	x5, [x19, #0x5920]
   3d604:	ldr	x8, [sp, #0x1c0]
   3d608:	str	x5, [x8, #0x118]
   3d60c:	ldr	x5, [x19, #0x5928]
   3d610:	ldr	x11, [sp, #0x1c0]
   3d614:	str	x5, [x11, #0x120]
   3d618:	ldr	x5, [x19, #0x5930]
   3d61c:	ldr	x14, [sp, #0x1c0]
   3d620:	str	x5, [x14, #0x128]
   3d624:	ldr	x6, [x19, #0x5938]
   3d628:	ldr	x0, [sp, #0x1c0]
   3d62c:	str	x6, [x0, #0x130]
   3d630:	ldr	x7, [x19, #0x5a70]
   3d634:	str	x7, [x0, #0x268]
   3d638:	ldr	x8, [x19, #0x5a78]
   3d63c:	str	x8, [x0, #0x270]
   3d640:	ldr	x9, [x19, #0x5a80]
   3d644:	str	x9, [x0, #0x278]
   3d648:	ldr	x10, [x19, #0x5a88]
   3d64c:	str	x10, [x0, #0x280]
   3d650:	ldr	x11, [x19, #0x5a90]
   3d654:	str	x11, [x0, #0x288]
   3d658:	ldr	x12, [x19, #0x5a98]
   3d65c:	str	x12, [x0, #0x290]
   3d660:	ldr	x13, [x19, #0x5aa0]
   3d664:	str	x13, [x0, #0x298]
   3d668:	ldr	x14, [x19, #0x5aa8]
   3d66c:	str	x14, [x0, #0x2a0]
   3d670:	ldr	x15, [x19, #0x5ab0]
   3d674:	str	x15, [x0, #0x2a8]
   3d678:	ldr	x0, [x19, #0x5d38]
   3d67c:	ldr	x1, [sp, #0x1c0]
   3d680:	str	x0, [x1, #0x530]
   3d684:	ldr	x0, [x19, #0x5d40]
   3d688:	str	x0, [x1, #0x538]
   3d68c:	ldr	x0, [x19, #0x5d48]
   3d690:	str	x0, [x1, #0x540]
   3d694:	ldr	x0, [x19, #0x5d50]
   3d698:	str	x0, [x1, #0x548]
   3d69c:	ldr	x0, [x19, #0x5d58]
   3d6a0:	str	x0, [x1, #0x550]
   3d6a4:	ldr	x0, [x19, #0x5d60]
   3d6a8:	str	x0, [x1, #0x558]
   3d6ac:	ldr	x0, [x19, #0x5d68]
   3d6b0:	ldr	x2, [sp, #0x1c0]
   3d6b4:	str	x0, [x2, #0x560]
   3d6b8:	ldr	x0, [x19, #0x5d70]
   3d6bc:	ldr	x5, [sp, #0x1c0]
   3d6c0:	str	x0, [x5, #0x568]
   3d6c4:	ldr	x0, [x19, #0x5e98]
   3d6c8:	ldr	x8, [sp, #0x1c0]
   3d6cc:	str	x0, [x8, #0x690]
   3d6d0:	ldr	x0, [x19, #0x5ea0]
   3d6d4:	ldr	x11, [sp, #0x1c0]
   3d6d8:	str	x0, [x11, #0x698]
   3d6dc:	ldr	x0, [x19, #0x5ea8]
   3d6e0:	ldr	x14, [sp, #0x1c0]
   3d6e4:	str	x0, [x14, #0x6a0]
   3d6e8:	ldr	x0, [x19, #0x5eb0]
   3d6ec:	str	x0, [x1, #0x6a8]
   3d6f0:	ldr	x0, [x19, #0x5eb8]
   3d6f4:	str	x0, [x1, #0x6b0]
   3d6f8:	ldr	x0, [x19, #0x5ec0]
   3d6fc:	str	x0, [x1, #0x6b8]
   3d700:	ldr	x0, [x19, #0x5ec8]
   3d704:	str	x0, [x1, #0x6c0]
   3d708:	ldr	x0, [x19, #0x5ed0]
   3d70c:	str	x0, [x1, #0x6c8]
   3d710:	ldr	x0, [x19, #0x62a8]
   3d714:	str	x0, [x1, #0xaa0]
   3d718:	ldr	x0, [x19, #0x62b0]
   3d71c:	str	x0, [x1, #0xaa8]
   3d720:	ldr	x0, [x19, #0x62b8]
   3d724:	str	x0, [x1, #0xab0]
   3d728:	ldr	x0, [x19, #0x62c0]
   3d72c:	str	x0, [x1, #0xab8]
   3d730:	ldr	x0, [x19, #0x62c8]
   3d734:	str	x0, [x1, #0xac0]
   3d738:	ldr	x0, [x19, #0x62d0]
   3d73c:	str	x0, [x1, #0xac8]
   3d740:	mov	x0, #0x0
   3d744:	str	x0, [x1, #0xad0]
   3d748:	ldr	x1, [x19, #0x62e0]
   3d74c:	str	x1, [x2, #0xad8]
   3d750:	ldr	x1, [x19, #0x62e8]
   3d754:	str	x1, [x2, #0xae0]
   3d758:	ldr	x1, [sp, #0x1c0]
   3d75c:	str	x0, [x1, #0xae8]
   3d760:	ldr	x1, [x19, #0x62f8]
   3d764:	str	x1, [x2, #0xaf0]
   3d768:	ldr	x1, [x19, #0x6300]
   3d76c:	str	x1, [x2, #0xaf8]
   3d770:	str	x0, [x5, #0xb00]
   3d774:	ldr	x0, [x19, #0x6310]
   3d778:	ldr	x6, [sp, #0x1c0]
   3d77c:	str	x0, [x6, #0xb08]
   3d780:	ldr	x0, [x19, #0x6318]
   3d784:	ldr	x9, [sp, #0x1c0]
   3d788:	str	x0, [x9, #0xb10]
   3d78c:	mov	x1, #0x66a
   3d790:	mov	x2, #-0x9
   3d794:	ldr	x21, [sp, #0x1d0]
   3d798:	ldur	x0, [sp, #0x8]
   3d79c:	mov	x5, x20
   3d7a0:	ldr	x6, [sp, #0x1c8]
   3d7a4:	blr	x21
   3d7a8:	cmp	x0, #0x0
   3d7ac:	b.ne	0x41bfc
   3d7b0:	mov	x0, #0x3
   3d7b4:	ldr	x14, [sp, #0x1b8]
   3d7b8:	mov	x25, x0
   3d7bc:	cmp	x14, #0x2
   3d7c0:	b.lo	0x43b34
   3d7c4:	mov	x5, #0x0
   3d7c8:	ldr	x3, [sp, #0x1c0]
   3d7cc:	str	x5, [x3]
   3d7d0:	ldr	x0, [x19, #0x2230]
   3d7d4:	str	x0, [x3, #0x8]
   3d7d8:	mov	x1, #0x66a
   3d7dc:	ldur	x0, [sp, #0x8]
   3d7e0:	ldr	x6, [sp, #0x1c8]
   3d7e4:	ldr	x21, [sp, #0x1d0]
   3d7e8:	mov	x4, x20
   3d7ec:	mov	x2, x5
   3d7f0:	blr	x21
   3d7f4:	cmp	x0, #0x0
   3d7f8:	b.ne	0x41c04
   3d7fc:	mov	x0, #0x3
   3d800:	mov	x25, x0
   3d804:	b	0x43b34
   3d808:	ldr	x20, [sp, #0x148]
   3d80c:	ldr	x26, [x20, x14, lsl #3]
   3d810:	ldr	x20, [sp, #0x140]
   3d814:	cmp	x1, x20
   3d818:	b.lo	0x3da94
   3d81c:	b	0x41c0c
   3d820:	ldr	x3, [x19, #0x54d8]
   3d824:	ldr	x4, [x19, #0x54e0]
   3d828:	mov	x0, #0x0
   3d82c:	str	x0, [x19, #0x54d0]
   3d830:	mov	x0, #0x3
   3d834:	ldr	x14, [sp, #0x1b8]
   3d838:	mov	x25, x0
   3d83c:	cmp	x14, #0x164
   3d840:	b.lo	0x43b34
   3d844:	ldr	x0, [x19, #0x5818]
   3d848:	ldr	x7, [sp, #0x1c0]
   3d84c:	str	x0, [x7, #0x10]
   3d850:	ldr	x1, [x19, #0x5820]
   3d854:	ldr	x10, [sp, #0x1c0]
   3d858:	str	x1, [x10, #0x18]
   3d85c:	ldr	x2, [x19, #0x6238]
   3d860:	ldr	x13, [sp, #0x1c0]
   3d864:	str	x2, [x13, #0xa30]
   3d868:	ldr	x15, [sp, #0x1c0]
   3d86c:	str	x0, [x15, #0x10]
   3d870:	ldr	x0, [sp, #0x1c0]
   3d874:	str	x1, [x0, #0x18]
   3d878:	ldr	x5, [x19, #0x58f8]
   3d87c:	str	x5, [x0, #0xf0]
   3d880:	ldr	x5, [x19, #0x5900]
   3d884:	str	x5, [x0, #0xf8]
   3d888:	ldr	x6, [x19, #0x5908]
   3d88c:	str	x6, [x0, #0x100]
   3d890:	ldr	x7, [x19, #0x5910]
   3d894:	str	x7, [x0, #0x108]
   3d898:	ldr	x8, [x19, #0x5918]
   3d89c:	str	x8, [x0, #0x110]
   3d8a0:	ldr	x9, [x19, #0x5920]
   3d8a4:	str	x9, [x0, #0x118]
   3d8a8:	ldr	x10, [x19, #0x5928]
   3d8ac:	str	x10, [x0, #0x120]
   3d8b0:	ldr	x11, [x19, #0x5930]
   3d8b4:	str	x11, [x0, #0x128]
   3d8b8:	ldr	x12, [x19, #0x5938]
   3d8bc:	str	x12, [x0, #0x130]
   3d8c0:	ldr	x13, [x19, #0x5a70]
   3d8c4:	str	x13, [x0, #0x268]
   3d8c8:	ldr	x14, [x19, #0x5a78]
   3d8cc:	str	x14, [x0, #0x270]
   3d8d0:	ldr	x15, [x19, #0x5a80]
   3d8d4:	str	x15, [x0, #0x278]
   3d8d8:	ldr	x0, [x19, #0x5a88]
   3d8dc:	ldr	x1, [sp, #0x1c0]
   3d8e0:	str	x0, [x1, #0x280]
   3d8e4:	ldr	x0, [x19, #0x5a90]
   3d8e8:	str	x0, [x1, #0x288]
   3d8ec:	ldr	x0, [x19, #0x5a98]
   3d8f0:	str	x0, [x1, #0x290]
   3d8f4:	ldr	x0, [x19, #0x5aa0]
   3d8f8:	ldr	x2, [sp, #0x1c0]
   3d8fc:	str	x0, [x2, #0x298]
   3d900:	ldr	x0, [x19, #0x5aa8]
   3d904:	ldr	x5, [sp, #0x1c0]
   3d908:	str	x0, [x5, #0x2a0]
   3d90c:	ldr	x0, [x19, #0x5ab0]
   3d910:	ldr	x8, [sp, #0x1c0]
   3d914:	str	x0, [x8, #0x2a8]
   3d918:	ldr	x0, [x19, #0x5d38]
   3d91c:	ldr	x11, [sp, #0x1c0]
   3d920:	str	x0, [x11, #0x530]
   3d924:	ldr	x0, [x19, #0x5d40]
   3d928:	ldr	x14, [sp, #0x1c0]
   3d92c:	str	x0, [x14, #0x538]
   3d930:	ldr	x0, [x19, #0x5d48]
   3d934:	str	x0, [x1, #0x540]
   3d938:	ldr	x0, [x19, #0x5d50]
   3d93c:	str	x0, [x1, #0x548]
   3d940:	ldr	x0, [x19, #0x5d58]
   3d944:	str	x0, [x1, #0x550]
   3d948:	ldr	x0, [x19, #0x5d60]
   3d94c:	str	x0, [x1, #0x558]
   3d950:	ldr	x0, [x19, #0x5d68]
   3d954:	str	x0, [x1, #0x560]
   3d958:	ldr	x0, [x19, #0x5d70]
   3d95c:	str	x0, [x1, #0x568]
   3d960:	ldr	x0, [x19, #0x5e98]
   3d964:	str	x0, [x1, #0x690]
   3d968:	ldr	x0, [x19, #0x5ea0]
   3d96c:	str	x0, [x1, #0x698]
   3d970:	ldr	x0, [x19, #0x5ea8]
   3d974:	str	x0, [x1, #0x6a0]
   3d978:	ldr	x0, [x19, #0x5eb0]
   3d97c:	str	x0, [x1, #0x6a8]
   3d980:	ldr	x0, [x19, #0x5eb8]
   3d984:	str	x0, [x1, #0x6b0]
   3d988:	ldr	x0, [x19, #0x5ec0]
   3d98c:	str	x0, [x1, #0x6b8]
   3d990:	ldr	x0, [x19, #0x5ec8]
   3d994:	str	x0, [x1, #0x6c0]
   3d998:	ldr	x0, [x19, #0x5ed0]
   3d99c:	str	x0, [x1, #0x6c8]
   3d9a0:	ldr	x0, [x19, #0x62a8]
   3d9a4:	str	x0, [x1, #0xaa0]
   3d9a8:	ldr	x0, [x19, #0x62b0]
   3d9ac:	str	x0, [x1, #0xaa8]
   3d9b0:	ldr	x0, [x19, #0x62b8]
   3d9b4:	str	x0, [x2, #0xab0]
   3d9b8:	ldr	x0, [x19, #0x62c0]
   3d9bc:	str	x0, [x5, #0xab8]
   3d9c0:	ldr	x0, [x19, #0x62c8]
   3d9c4:	str	x0, [x8, #0xac0]
   3d9c8:	ldr	x0, [x19, #0x62d0]
   3d9cc:	str	x0, [x11, #0xac8]
   3d9d0:	mov	x0, #0x0
   3d9d4:	str	x0, [x14, #0xad0]
   3d9d8:	ldr	x1, [x19, #0x62e0]
   3d9dc:	str	x1, [x2, #0xad8]
   3d9e0:	ldr	x1, [x19, #0x62e8]
   3d9e4:	str	x1, [x2, #0xae0]
   3d9e8:	ldr	x1, [sp, #0x1c0]
   3d9ec:	str	x0, [x1, #0xae8]
   3d9f0:	ldr	x1, [x19, #0x62f8]
   3d9f4:	str	x1, [x2, #0xaf0]
   3d9f8:	ldr	x1, [x19, #0x6300]
   3d9fc:	str	x1, [x2, #0xaf8]
   3da00:	ldr	x1, [sp, #0x1c0]
   3da04:	str	x0, [x1, #0xb00]
   3da08:	ldr	x0, [x19, #0x6310]
   3da0c:	str	x0, [x1, #0xb08]
   3da10:	ldr	x0, [x19, #0x6318]
   3da14:	str	x0, [x1, #0xb10]
   3da18:	mov	x1, #0x66c
   3da1c:	mov	x2, #-0x9
   3da20:	ldr	x21, [sp, #0x1d0]
   3da24:	ldur	x0, [sp, #0x8]
   3da28:	mov	x5, x20
   3da2c:	ldr	x6, [sp, #0x1c8]
   3da30:	blr	x21
   3da34:	cmp	x0, #0x0
   3da38:	b.ne	0x41db8
   3da3c:	mov	x0, #0x3
   3da40:	ldr	x14, [sp, #0x1b8]
   3da44:	mov	x25, x0
   3da48:	cmp	x14, #0x2
   3da4c:	b.lo	0x43b34
   3da50:	mov	x5, #0x0
   3da54:	ldr	x3, [sp, #0x1c0]
   3da58:	str	x5, [x3]
   3da5c:	ldr	x0, [x19, #0x2240]
   3da60:	str	x0, [x3, #0x8]
   3da64:	mov	x1, #0x66c
   3da68:	ldur	x0, [sp, #0x8]
   3da6c:	ldr	x6, [sp, #0x1c8]
   3da70:	ldr	x21, [sp, #0x1d0]
   3da74:	mov	x4, x20
   3da78:	mov	x2, x5
   3da7c:	blr	x21
   3da80:	cmp	x0, #0x0
   3da84:	b.ne	0x41dc0
   3da88:	mov	x0, #0x3
   3da8c:	mov	x25, x0
   3da90:	b	0x43b34
   3da94:	ldr	x20, [sp, #0x148]
   3da98:	ldr	x8, [x20, x1, lsl #3]
   3da9c:	mov	w5, #0x1226
   3daa0:	movk	w5, #0x1, lsl #16
   3daa4:	sub	x5, x3, x5
   3daa8:	mov	x0, #0x0
   3daac:	stur	x0, [sp, #0xc0]
   3dab0:	mov	x9, #0x2
   3dab4:	ldr	x20, [sp, #0x130]
   3dab8:	stur	x9, [sp, #0xf0]
   3dabc:	cmp	x20, x8
   3dac0:	b.lo	0x3dae0
   3dac4:	ldur	x0, [sp, #0x30]
   3dac8:	ldur	x2, [sp, #0x40]
   3dacc:	ldur	x4, [sp, #0x38]
   3dad0:	ldur	x14, [sp, #0x10]
   3dad4:	ldur	x1, [sp, #0x48]
   3dad8:	stur	x1, [sp, #0xa0]
   3dadc:	b	0x3e264
   3dae0:	ldur	x21, [sp, #0x30]
   3dae4:	ldur	x22, [sp, #0x40]
   3dae8:	ldur	x24, [sp, #0x38]
   3daec:	ldur	x28, [sp, #0x10]
   3daf0:	ldur	x0, [sp, #0x48]
   3daf4:	stur	x0, [sp, #0xa0]
   3daf8:	mov	w9, #0xe176
   3dafc:	movk	w9, #0x2, lsl #16
   3db00:	cmp	x5, x9
   3db04:	b.hs	0x3db44
   3db08:	ldur	x25, [sp, #0xc8]
   3db0c:	ldur	x23, [sp, #0x30]
   3db10:	ldur	x20, [sp, #0x40]
   3db14:	mov	x14, x28
   3db18:	ldur	x28, [sp, #0xb8]
   3db1c:	ldur	x13, [sp, #0x48]
   3db20:	ldur	x9, [sp, #0xc8]
   3db24:	mov	x4, x24
   3db28:	ldur	x24, [sp, #0x10]
   3db2c:	ldur	x3, [sp, #0xc8]
   3db30:	mov	x2, x22
   3db34:	ldur	x1, [sp, #0xc8]
   3db38:	mov	x0, x21
   3db3c:	ldur	x21, [sp, #0x38]
   3db40:	b	0x3e29c
   3db44:	cmp	x26, x8
   3db48:	cset	x1, lo
   3db4c:	cmp	x26, x8
   3db50:	b.lo	0x3db84
   3db54:	mov	x20, x21
   3db58:	mov	x14, x28
   3db5c:	ldur	x10, [sp, #0xa0]
   3db60:	mov	x9, x26
   3db64:	mov	x4, x24
   3db68:	mov	x3, x24
   3db6c:	mov	x2, x22
   3db70:	mov	x1, x22
   3db74:	mov	x22, x28
   3db78:	mov	x0, x21
   3db7c:	ldur	x21, [sp, #0xc0]
   3db80:	b	0x3e210
   3db84:	ldr	x20, [sp, #0x130]
   3db88:	cmp	x26, x20
   3db8c:	b.lo	0x3de1c
   3db90:	b	0x41dc8
   3db94:	ldr	x3, [x19, #0x54d8]
   3db98:	ldr	x4, [x19, #0x54e0]
   3db9c:	mov	x0, #0x0
   3dba0:	str	x0, [x19, #0x54d0]
   3dba4:	mov	x0, #0x3
   3dba8:	ldr	x14, [sp, #0x1b8]
   3dbac:	mov	x25, x0
   3dbb0:	cmp	x14, #0x164
   3dbb4:	b.lo	0x43b34
   3dbb8:	ldr	x0, [x19, #0x5818]
   3dbbc:	ldr	x1, [sp, #0x1c0]
   3dbc0:	str	x0, [x1, #0x10]
   3dbc4:	ldr	x1, [x19, #0x5820]
   3dbc8:	ldr	x2, [sp, #0x1c0]
   3dbcc:	str	x1, [x2, #0x18]
   3dbd0:	ldr	x2, [x19, #0x6238]
   3dbd4:	ldr	x5, [sp, #0x1c0]
   3dbd8:	str	x2, [x5, #0xa30]
   3dbdc:	ldr	x2, [sp, #0x1c0]
   3dbe0:	str	x0, [x2, #0x10]
   3dbe4:	ldr	x0, [sp, #0x1c0]
   3dbe8:	str	x1, [x0, #0x18]
   3dbec:	ldr	x0, [x19, #0x58f8]
   3dbf0:	ldr	x1, [sp, #0x1c0]
   3dbf4:	str	x0, [x1, #0xf0]
   3dbf8:	ldr	x0, [x19, #0x5900]
   3dbfc:	str	x0, [x1, #0xf8]
   3dc00:	ldr	x0, [x19, #0x5908]
   3dc04:	str	x0, [x1, #0x100]
   3dc08:	ldr	x0, [x19, #0x5910]
   3dc0c:	str	x0, [x1, #0x108]
   3dc10:	ldr	x0, [x19, #0x5918]
   3dc14:	str	x0, [x1, #0x110]
   3dc18:	ldr	x0, [x19, #0x5920]
   3dc1c:	str	x0, [x1, #0x118]
   3dc20:	ldr	x0, [x19, #0x5928]
   3dc24:	str	x0, [x1, #0x120]
   3dc28:	ldr	x0, [x19, #0x5930]
   3dc2c:	str	x0, [x1, #0x128]
   3dc30:	ldr	x0, [x19, #0x5938]
   3dc34:	str	x0, [x1, #0x130]
   3dc38:	ldr	x0, [x19, #0x5a70]
   3dc3c:	str	x0, [x1, #0x268]
   3dc40:	ldr	x0, [x19, #0x5a78]
   3dc44:	str	x0, [x1, #0x270]
   3dc48:	ldr	x0, [x19, #0x5a80]
   3dc4c:	str	x0, [x2, #0x278]
   3dc50:	ldr	x0, [x19, #0x5a88]
   3dc54:	str	x0, [x5, #0x280]
   3dc58:	ldr	x0, [x19, #0x5a90]
   3dc5c:	ldr	x8, [sp, #0x1c0]
   3dc60:	str	x0, [x8, #0x288]
   3dc64:	ldr	x0, [x19, #0x5a98]
   3dc68:	ldr	x11, [sp, #0x1c0]
   3dc6c:	str	x0, [x11, #0x290]
   3dc70:	ldr	x1, [x19, #0x5aa0]
   3dc74:	ldr	x14, [sp, #0x1c0]
   3dc78:	str	x1, [x14, #0x298]
   3dc7c:	ldr	x2, [x19, #0x5aa8]
   3dc80:	ldr	x0, [sp, #0x1c0]
   3dc84:	str	x2, [x0, #0x2a0]
   3dc88:	ldr	x5, [x19, #0x5ab0]
   3dc8c:	str	x5, [x0, #0x2a8]
   3dc90:	ldr	x5, [x19, #0x5d38]
   3dc94:	str	x5, [x0, #0x530]
   3dc98:	ldr	x5, [x19, #0x5d40]
   3dc9c:	str	x5, [x0, #0x538]
   3dca0:	ldr	x6, [x19, #0x5d48]
   3dca4:	str	x6, [x0, #0x540]
   3dca8:	ldr	x7, [x19, #0x5d50]
   3dcac:	str	x7, [x0, #0x548]
   3dcb0:	ldr	x8, [x19, #0x5d58]
   3dcb4:	str	x8, [x0, #0x550]
   3dcb8:	ldr	x9, [x19, #0x5d60]
   3dcbc:	str	x9, [x0, #0x558]
   3dcc0:	ldr	x10, [x19, #0x5d68]
   3dcc4:	str	x10, [x0, #0x560]
   3dcc8:	ldr	x11, [x19, #0x5d70]
   3dccc:	str	x11, [x0, #0x568]
   3dcd0:	ldr	x12, [x19, #0x5e98]
   3dcd4:	str	x12, [x0, #0x690]
   3dcd8:	ldr	x13, [x19, #0x5ea0]
   3dcdc:	str	x13, [x0, #0x698]
   3dce0:	ldr	x14, [x19, #0x5ea8]
   3dce4:	str	x14, [x0, #0x6a0]
   3dce8:	ldr	x15, [x19, #0x5eb0]
   3dcec:	str	x15, [x0, #0x6a8]
   3dcf0:	ldr	x0, [x19, #0x5eb8]
   3dcf4:	ldr	x1, [sp, #0x1c0]
   3dcf8:	str	x0, [x1, #0x6b0]
   3dcfc:	ldr	x0, [x19, #0x5ec0]
   3dd00:	str	x0, [x1, #0x6b8]
   3dd04:	ldr	x0, [x19, #0x5ec8]
   3dd08:	ldr	x2, [sp, #0x1c0]
   3dd0c:	str	x0, [x2, #0x6c0]
   3dd10:	ldr	x0, [x19, #0x5ed0]
   3dd14:	ldr	x5, [sp, #0x1c0]
   3dd18:	str	x0, [x5, #0x6c8]
   3dd1c:	ldr	x0, [x19, #0x62a8]
   3dd20:	ldr	x8, [sp, #0x1c0]
   3dd24:	str	x0, [x8, #0xaa0]
   3dd28:	ldr	x0, [x19, #0x62b0]
   3dd2c:	ldr	x11, [sp, #0x1c0]
   3dd30:	str	x0, [x11, #0xaa8]
   3dd34:	ldr	x0, [x19, #0x62b8]
   3dd38:	ldr	x14, [sp, #0x1c0]
   3dd3c:	str	x0, [x14, #0xab0]
   3dd40:	ldr	x0, [x19, #0x62c0]
   3dd44:	str	x0, [x1, #0xab8]
   3dd48:	ldr	x0, [x19, #0x62c8]
   3dd4c:	str	x0, [x1, #0xac0]
   3dd50:	ldr	x0, [x19, #0x62d0]
   3dd54:	str	x0, [x1, #0xac8]
   3dd58:	mov	x0, #0x0
   3dd5c:	str	x0, [x1, #0xad0]
   3dd60:	ldr	x1, [x19, #0x62e0]
   3dd64:	str	x1, [x2, #0xad8]
   3dd68:	ldr	x1, [x19, #0x62e8]
   3dd6c:	str	x1, [x2, #0xae0]
   3dd70:	ldr	x1, [sp, #0x1c0]
   3dd74:	str	x0, [x1, #0xae8]
   3dd78:	ldr	x1, [x19, #0x62f8]
   3dd7c:	str	x1, [x2, #0xaf0]
   3dd80:	ldr	x1, [x19, #0x6300]
   3dd84:	str	x1, [x2, #0xaf8]
   3dd88:	ldr	x1, [sp, #0x1c0]
   3dd8c:	str	x0, [x1, #0xb00]
   3dd90:	ldr	x0, [x19, #0x6310]
   3dd94:	str	x0, [x1, #0xb08]
   3dd98:	ldr	x0, [x19, #0x6318]
   3dd9c:	str	x0, [x1, #0xb10]
   3dda0:	mov	x1, #0x682
   3dda4:	mov	x2, #-0x9
   3dda8:	ldr	x21, [sp, #0x1d0]
   3ddac:	ldur	x0, [sp, #0x8]
   3ddb0:	mov	x5, x20
   3ddb4:	ldr	x6, [sp, #0x1c8]
   3ddb8:	blr	x21
   3ddbc:	cmp	x0, #0x0
   3ddc0:	b.ne	0x41fc8
   3ddc4:	mov	x0, #0x3
   3ddc8:	ldr	x14, [sp, #0x1b8]
   3ddcc:	mov	x25, x0
   3ddd0:	cmp	x14, #0x2
   3ddd4:	b.lo	0x43b34
   3ddd8:	mov	x5, #0x0
   3dddc:	ldr	x3, [sp, #0x1c0]
   3dde0:	str	x5, [x3]
   3dde4:	ldr	x0, [x19, #0x22c0]
   3dde8:	str	x0, [x3, #0x8]
   3ddec:	mov	x1, #0x682
   3ddf0:	ldur	x0, [sp, #0x8]
   3ddf4:	ldr	x6, [sp, #0x1c8]
   3ddf8:	ldr	x21, [sp, #0x1d0]
   3ddfc:	mov	x4, x20
   3de00:	mov	x2, x5
   3de04:	blr	x21
   3de08:	cmp	x0, #0x0
   3de0c:	b.ne	0x41fd0
   3de10:	mov	x0, #0x3
   3de14:	mov	x25, x0
   3de18:	b	0x43b34
   3de1c:	mov	x14, x28
   3de20:	mov	x0, x21
   3de24:	ldur	x21, [sp, #0xc0]
   3de28:	mov	x23, #0x2
   3de2c:	ldr	x20, [sp, #0x138]
   3de30:	ldr	w3, [x20, x26, lsl #2]
   3de34:	mov	w10, w3
   3de38:	ldur	x9, [sp, #0xc8]
   3de3c:	cmp	x10, x9
   3de40:	b.ne	0x3de68
   3de44:	mov	x20, x0
   3de48:	mov	x10, x24
   3de4c:	mov	x9, x26
   3de50:	mov	x4, x24
   3de54:	mov	x3, x22
   3de58:	mov	x2, x22
   3de5c:	mov	x22, x14
   3de60:	ldur	x1, [sp, #0xa0]
   3de64:	b	0x3e1dc
   3de68:	ldr	x20, [sp, #0x120]
   3de6c:	cmp	x10, x20
   3de70:	b.lo	0x3e0ec
   3de74:	b	0x41fd8
   3de78:	ldr	x3, [x19, #0x54d8]
   3de7c:	ldr	x4, [x19, #0x54e0]
   3de80:	mov	x5, #0x0
   3de84:	str	x5, [x19, #0x54d0]
   3de88:	mov	x0, #0x3
   3de8c:	ldr	x14, [sp, #0x1b8]
   3de90:	mov	x25, x0
   3de94:	cmp	x14, #0x164
   3de98:	b.lo	0x43b34
   3de9c:	ldr	x9, [x19, #0x5818]
   3dea0:	ldr	x7, [sp, #0x1c0]
   3dea4:	str	x9, [x7, #0x10]
   3dea8:	ldr	x10, [x19, #0x5820]
   3deac:	ldr	x11, [sp, #0x1c0]
   3deb0:	str	x10, [x11, #0x18]
   3deb4:	ldr	x11, [x19, #0x6238]
   3deb8:	ldr	x13, [sp, #0x1c0]
   3debc:	str	x11, [x13, #0xa30]
   3dec0:	ldr	x15, [sp, #0x1c0]
   3dec4:	str	x9, [x15, #0x10]
   3dec8:	ldr	x0, [sp, #0x1c0]
   3decc:	str	x10, [x0, #0x18]
   3ded0:	ldr	x14, [x19, #0x58f8]
   3ded4:	str	x14, [x0, #0xf0]
   3ded8:	ldr	x15, [x19, #0x5900]
   3dedc:	str	x15, [x0, #0xf8]
   3dee0:	ldr	x0, [x19, #0x5908]
   3dee4:	ldr	x1, [sp, #0x1c0]
   3dee8:	str	x0, [x1, #0x100]
   3deec:	ldr	x0, [x19, #0x5910]
   3def0:	str	x0, [x1, #0x108]
   3def4:	ldr	x0, [x19, #0x5918]
   3def8:	str	x0, [x1, #0x110]
   3defc:	ldr	x0, [x19, #0x5920]
   3df00:	str	x0, [x1, #0x118]
   3df04:	ldr	x0, [x19, #0x5928]
   3df08:	str	x0, [x1, #0x120]
   3df0c:	ldr	x0, [x19, #0x5930]
   3df10:	str	x0, [x1, #0x128]
   3df14:	ldr	x0, [x19, #0x5938]
   3df18:	str	x0, [x1, #0x130]
   3df1c:	ldr	x0, [x19, #0x5a70]
   3df20:	str	x0, [x1, #0x268]
   3df24:	ldr	x0, [x19, #0x5a78]
   3df28:	str	x0, [x1, #0x270]
   3df2c:	ldr	x0, [x19, #0x5a80]
   3df30:	str	x0, [x1, #0x278]
   3df34:	ldr	x0, [x19, #0x5a88]
   3df38:	str	x0, [x1, #0x280]
   3df3c:	ldr	x0, [x19, #0x5a90]
   3df40:	str	x0, [x1, #0x288]
   3df44:	ldr	x0, [x19, #0x5a98]
   3df48:	str	x0, [x1, #0x290]
   3df4c:	ldr	x0, [x19, #0x5aa0]
   3df50:	ldr	x2, [sp, #0x1c0]
   3df54:	str	x0, [x2, #0x298]
   3df58:	ldr	x0, [x19, #0x5aa8]
   3df5c:	ldr	x5, [sp, #0x1c0]
   3df60:	str	x0, [x5, #0x2a0]
   3df64:	ldr	x0, [x19, #0x5ab0]
   3df68:	ldr	x8, [sp, #0x1c0]
   3df6c:	str	x0, [x8, #0x2a8]
   3df70:	ldr	x0, [x19, #0x5d38]
   3df74:	ldr	x11, [sp, #0x1c0]
   3df78:	str	x0, [x11, #0x530]
   3df7c:	ldr	x0, [x19, #0x5d40]
   3df80:	ldr	x14, [sp, #0x1c0]
   3df84:	str	x0, [x14, #0x538]
   3df88:	ldr	x0, [x19, #0x5d48]
   3df8c:	str	x0, [x1, #0x540]
   3df90:	ldr	x0, [x19, #0x5d50]
   3df94:	str	x0, [x1, #0x548]
   3df98:	ldr	x0, [x19, #0x5d58]
   3df9c:	str	x0, [x1, #0x550]
   3dfa0:	ldr	x0, [x19, #0x5d60]
   3dfa4:	str	x0, [x1, #0x558]
   3dfa8:	ldr	x0, [x19, #0x5d68]
   3dfac:	str	x0, [x1, #0x560]
   3dfb0:	ldr	x0, [x19, #0x5d70]
   3dfb4:	str	x0, [x1, #0x568]
   3dfb8:	ldr	x0, [x19, #0x5e98]
   3dfbc:	str	x0, [x1, #0x690]
   3dfc0:	ldr	x0, [x19, #0x5ea0]
   3dfc4:	str	x0, [x1, #0x698]
   3dfc8:	ldr	x0, [x19, #0x5ea8]
   3dfcc:	str	x0, [x1, #0x6a0]
   3dfd0:	ldr	x0, [x19, #0x5eb0]
   3dfd4:	str	x0, [x1, #0x6a8]
   3dfd8:	ldr	x0, [x19, #0x5eb8]
   3dfdc:	str	x0, [x1, #0x6b0]
   3dfe0:	ldr	x0, [x19, #0x5ec0]
   3dfe4:	str	x0, [x1, #0x6b8]
   3dfe8:	ldr	x0, [x19, #0x5ec8]
   3dfec:	str	x0, [x1, #0x6c0]
   3dff0:	ldr	x0, [x19, #0x5ed0]
   3dff4:	str	x0, [x1, #0x6c8]
   3dff8:	ldr	x0, [x19, #0x62a8]
   3dffc:	str	x0, [x1, #0xaa0]
   3e000:	ldr	x0, [x19, #0x62b0]
   3e004:	str	x0, [x1, #0xaa8]
   3e008:	ldr	x0, [x19, #0x62b8]
   3e00c:	str	x0, [x2, #0xab0]
   3e010:	ldr	x0, [x19, #0x62c0]
   3e014:	str	x0, [x5, #0xab8]
   3e018:	ldr	x0, [x19, #0x62c8]
   3e01c:	str	x0, [x8, #0xac0]
   3e020:	ldr	x0, [x19, #0x62d0]
   3e024:	str	x0, [x11, #0xac8]
   3e028:	mov	x0, #0x0
   3e02c:	str	x0, [x14, #0xad0]
   3e030:	ldr	x1, [x19, #0x62e0]
   3e034:	str	x1, [x2, #0xad8]
   3e038:	ldr	x1, [x19, #0x62e8]
   3e03c:	str	x1, [x2, #0xae0]
   3e040:	ldr	x1, [sp, #0x1c0]
   3e044:	str	x0, [x1, #0xae8]
   3e048:	ldr	x1, [x19, #0x62f8]
   3e04c:	str	x1, [x2, #0xaf0]
   3e050:	ldr	x1, [x19, #0x6300]
   3e054:	str	x1, [x2, #0xaf8]
   3e058:	ldr	x1, [sp, #0x1c0]
   3e05c:	str	x0, [x1, #0xb00]
   3e060:	ldr	x0, [x19, #0x6310]
   3e064:	str	x0, [x1, #0xb08]
   3e068:	ldr	x0, [x19, #0x6318]
   3e06c:	str	x0, [x1, #0xb10]
   3e070:	mov	x1, #0x68a
   3e074:	mov	x2, #-0x9
   3e078:	ldr	x21, [sp, #0x1d0]
   3e07c:	ldur	x0, [sp, #0x8]
   3e080:	mov	x5, x23
   3e084:	ldr	x6, [sp, #0x1c8]
   3e088:	blr	x21
   3e08c:	cmp	x0, #0x0
   3e090:	b.ne	0x421dc
   3e094:	mov	x0, #0x3
   3e098:	ldr	x14, [sp, #0x1b8]
   3e09c:	mov	x25, x0
   3e0a0:	cmp	x14, #0x2
   3e0a4:	b.lo	0x43b34
   3e0a8:	mov	x5, #0x0
   3e0ac:	ldr	x3, [sp, #0x1c0]
   3e0b0:	str	x5, [x3]
   3e0b4:	ldr	x8, [x19, #0x22e8]
   3e0b8:	str	x8, [x3, #0x8]
   3e0bc:	mov	x1, #0x68a
   3e0c0:	ldur	x0, [sp, #0x8]
   3e0c4:	ldr	x6, [sp, #0x1c8]
   3e0c8:	ldr	x21, [sp, #0x1d0]
   3e0cc:	mov	x4, x23
   3e0d0:	mov	x2, x5
   3e0d4:	blr	x21
   3e0d8:	cmp	x0, #0x0
   3e0dc:	b.ne	0x421e4
   3e0e0:	mov	x0, #0x3
   3e0e4:	mov	x25, x0
   3e0e8:	b	0x43b34
   3e0ec:	mov	x2, x22
   3e0f0:	mov	x4, x24
   3e0f4:	ldr	x20, [sp, #0x128]
   3e0f8:	ldr	x1, [x20, w3, uxtw #3]
   3e0fc:	ldr	x3, [sp, #0x100]
   3e100:	and	x1, x3, x1
   3e104:	fmov	d0, x1
   3e108:	cnt.8b	v0, v0
   3e10c:	addv.8b	b0, v0
   3e110:	umov.b	w1, v0[0]
   3e114:	eor	x3, x10, #0x3ffffffffffffff
   3e118:	orr	x9, x3, x1, lsl #58
   3e11c:	ldur	x10, [sp, #0xa0]
   3e120:	cmp	x9, x10
   3e124:	cset	x1, hi
   3e128:	cmp	x9, x14
   3e12c:	cset	x3, ne
   3e130:	and	w1, w1, w3
   3e134:	cmp	x9, x0
   3e138:	cset	x3, ne
   3e13c:	and	w1, w1, w3
   3e140:	cmp	x9, x4
   3e144:	cset	x3, ne
   3e148:	and	w1, w1, w3
   3e14c:	cmp	x9, x2
   3e150:	cset	x3, ne
   3e154:	and	w1, w1, w3
   3e158:	uxtb	w1, w1
   3e15c:	tbnz	w1, #0x0, 0x3e178
   3e160:	mov	x1, x14
   3e164:	mov	x3, x2
   3e168:	mov	x9, x0
   3e16c:	mov	x10, x4
   3e170:	ldur	x20, [sp, #0xa0]
   3e174:	b	0x3e1a8
   3e178:	cmp	x9, x14
   3e17c:	csel	x1, x9, x14, hi
   3e180:	csel	x3, x9, x14, lo
   3e184:	cmp	x3, x0
   3e188:	csel	x9, x3, x0, hi
   3e18c:	csel	x3, x3, x0, lo
   3e190:	cmp	x3, x4
   3e194:	csel	x10, x3, x4, hi
   3e198:	csel	x22, x3, x4, lo
   3e19c:	cmp	x22, x2
   3e1a0:	csel	x3, x22, x2, hi
   3e1a4:	csel	x20, x22, x2, lo
   3e1a8:	mov	x22, x14
   3e1ac:	mov	x14, x1
   3e1b0:	mov	x23, x4
   3e1b4:	mov	x4, x10
   3e1b8:	mov	x10, x23
   3e1bc:	mov	x23, x2
   3e1c0:	mov	x2, x3
   3e1c4:	mov	x3, x23
   3e1c8:	ldur	x1, [sp, #0xa0]
   3e1cc:	stur	x20, [sp, #0xa0]
   3e1d0:	mov	x20, x0
   3e1d4:	mov	x0, x9
   3e1d8:	mov	x9, x26
   3e1dc:	mov	x23, x14
   3e1e0:	mov	x14, x22
   3e1e4:	mov	x22, x23
   3e1e8:	mov	x23, x1
   3e1ec:	mov	x1, x2
   3e1f0:	mov	x2, x3
   3e1f4:	mov	x3, x4
   3e1f8:	mov	x4, x10
   3e1fc:	ldur	x10, [sp, #0xa0]
   3e200:	stur	x23, [sp, #0xa0]
   3e204:	mov	x23, x0
   3e208:	mov	x0, x20
   3e20c:	mov	x20, x23
   3e210:	cmp	x26, x8
   3e214:	b.lo	0x3e22c
   3e218:	mov	w1, #0xe176
   3e21c:	movk	w1, #0x2, lsl #16
   3e220:	sub	x3, x5, x1
   3e224:	ldur	x5, [sp, #0xb8]
   3e228:	b	0x3eaf4
   3e22c:	add	x26, x9, #0x1
   3e230:	cmp	x26, x9
   3e234:	b.lo	0x421ec
   3e238:	mov	w0, #0xe176
   3e23c:	movk	w0, #0x2, lsl #16
   3e240:	sub	x5, x5, x0
   3e244:	mov	x21, #0x1
   3e248:	stur	x21, [sp, #0xc0]
   3e24c:	stur	x10, [sp, #0xa0]
   3e250:	mov	x28, x22
   3e254:	mov	x24, x3
   3e258:	mov	x22, x1
   3e25c:	mov	x21, x20
   3e260:	b	0x3daf8
   3e264:	mov	w1, #0xe176
   3e268:	movk	w1, #0x2, lsl #16
   3e26c:	cmp	x5, x1
   3e270:	b.hs	0x3e6d8
   3e274:	ldur	x1, [sp, #0xc8]
   3e278:	ldur	x3, [sp, #0xc8]
   3e27c:	ldur	x9, [sp, #0xc8]
   3e280:	ldur	x13, [sp, #0x48]
   3e284:	ldur	x20, [sp, #0x40]
   3e288:	ldur	x21, [sp, #0x38]
   3e28c:	ldur	x23, [sp, #0x30]
   3e290:	ldur	x24, [sp, #0x10]
   3e294:	ldur	x25, [sp, #0xc8]
   3e298:	ldur	x28, [sp, #0xb8]
   3e29c:	mov	x22, #0x0
   3e2a0:	str	x22, [x19, #0x30]
   3e2a4:	mov	x10, #0x1000000000000000
   3e2a8:	str	x10, [x19, #0x38]
   3e2ac:	mov	x10, #0x1
   3e2b0:	str	x10, [x19, #0x48]
   3e2b4:	mov	x27, #0x101010101010101
   3e2b8:	str	x27, [x19, #0x50]
   3e2bc:	ldur	x27, [sp, #0xf0]
   3e2c0:	str	x27, [x19, #0x58]
   3e2c4:	mov	x27, #0x3
   3e2c8:	str	x27, [x19, #0x60]
   3e2cc:	mov	x27, #0x4
   3e2d0:	str	x27, [x19, #0x68]
   3e2d4:	mov	x27, #0xf0f0f0f0f0f0f0f
   3e2d8:	str	x27, [x19, #0x90]
   3e2dc:	mov	x27, #0x3333333333333333
   3e2e0:	str	x27, [x19, #0xa0]
   3e2e4:	mov	x27, #0x38
   3e2e8:	str	x27, [x19, #0xa8]
   3e2ec:	mov	x27, #0x3a
   3e2f0:	str	x27, [x19, #0xb0]
   3e2f4:	mov	x27, #0x5555555555555555
   3e2f8:	str	x27, [x19, #0xc8]
   3e2fc:	mov	x27, #0x3ffffffffffffff
   3e300:	str	x27, [x19, #0xd8]
   3e304:	str	x22, [x19, #0x178]
   3e308:	str	x10, [x19, #0x180]
   3e30c:	ldur	x22, [sp, #0xc8]
   3e310:	str	x22, [x19, #0x2140]
   3e314:	ldr	x27, [sp, #0x1b0]
   3e318:	str	x27, [x19, #0x2148]
   3e31c:	ldr	x22, [sp, #0x118]
   3e320:	uxtb	w22, w22
   3e324:	str	x22, [x19, #0x2158]
   3e328:	ldur	x22, [sp, #0xb8]
   3e32c:	str	x22, [x19, #0x21e8]
   3e330:	ldr	x22, [sp, #0x108]
   3e334:	str	x22, [x19, #0x21f0]
   3e338:	str	x1, [x19, #0x21f8]
   3e33c:	ldr	x1, [sp, #0x100]
   3e340:	str	x1, [x19, #0x2200]
   3e344:	ldur	x1, [sp, #0xf8]
   3e348:	uxtb	w1, w1
   3e34c:	str	x1, [x19, #0x2210]
   3e350:	ldur	x1, [sp, #0x58]
   3e354:	str	x1, [x19, #0x54d0]
   3e358:	str	x5, [x19, #0x54d8]
   3e35c:	ldur	x1, [sp, #0x60]
   3e360:	str	x1, [x19, #0x54e0]
   3e364:	str	x3, [x19, #0x5818]
   3e368:	str	x27, [x19, #0x5820]
   3e36c:	str	x28, [x19, #0x58f8]
   3e370:	ldr	x1, [sp, #0x108]
   3e374:	str	x1, [x19, #0x5900]
   3e378:	str	x25, [x19, #0x5908]
   3e37c:	ldr	x1, [sp, #0x100]
   3e380:	str	x1, [x19, #0x5910]
   3e384:	ldur	x1, [sp, #0x10]
   3e388:	str	x1, [x19, #0x5918]
   3e38c:	ldur	x1, [sp, #0x30]
   3e390:	str	x1, [x19, #0x5920]
   3e394:	ldur	x1, [sp, #0x38]
   3e398:	str	x1, [x19, #0x5928]
   3e39c:	ldur	x25, [sp, #0x40]
   3e3a0:	str	x25, [x19, #0x5930]
   3e3a4:	ldur	x1, [sp, #0x48]
   3e3a8:	str	x1, [x19, #0x5938]
   3e3ac:	str	x24, [x19, #0x59b0]
   3e3b0:	str	x23, [x19, #0x59b8]
   3e3b4:	str	x21, [x19, #0x59c0]
   3e3b8:	str	x20, [x19, #0x59c8]
   3e3bc:	str	x13, [x19, #0x59d0]
   3e3c0:	str	x26, [x19, #0x5a70]
   3e3c4:	str	x8, [x19, #0x5a78]
   3e3c8:	str	x9, [x19, #0x5a80]
   3e3cc:	ldr	x26, [sp, #0x100]
   3e3d0:	str	x26, [x19, #0x5a88]
   3e3d4:	str	x14, [x19, #0x5a90]
   3e3d8:	str	x0, [x19, #0x5a98]
   3e3dc:	str	x4, [x19, #0x5aa0]
   3e3e0:	str	x2, [x19, #0x5aa8]
   3e3e4:	ldur	x21, [sp, #0xa0]
   3e3e8:	str	x21, [x19, #0x5ab0]
   3e3ec:	ldur	x24, [sp, #0x28]
   3e3f0:	str	x24, [x19, #0x6238]
   3e3f4:	add	x0, x15, #0x1
   3e3f8:	str	x0, [x19, #0x62a8]
   3e3fc:	ldur	x23, [sp, #0x68]
   3e400:	str	x23, [x19, #0x62b0]
   3e404:	ldur	x28, [sp, #0x70]
   3e408:	str	x28, [x19, #0x62b8]
   3e40c:	ldur	x4, [sp, #0x50]
   3e410:	sub	x1, x4, x5
   3e414:	mov	w2, #0xb946
   3e418:	movk	w2, #0x1, lsl #16
   3e41c:	msub	x0, x0, x2, x1
   3e420:	str	x0, [x19, #0x62c0]
   3e424:	str	x10, [x19, #0x62c8]
   3e428:	ldur	x14, [sp, #0x18]
   3e42c:	str	x14, [x19, #0x62d0]
   3e430:	str	x10, [x19, #0x62e0]
   3e434:	ldur	x21, [sp, #0xc0]
   3e438:	str	x21, [x19, #0x62e8]
   3e43c:	str	x12, [x19, #0x62f8]
   3e440:	str	x11, [x19, #0x6300]
   3e444:	str	x7, [x19, #0x6310]
   3e448:	str	x6, [x19, #0x6318]
   3e44c:	ldr	x0, [x19, #0x54d0]
   3e450:	cmp	x0, #0x0
   3e454:	b.eq	0x3e6b0
   3e458:	ldr	x3, [x19, #0x54d8]
   3e45c:	ldr	x4, [x19, #0x54e0]
   3e460:	mov	x0, #0x0
   3e464:	str	x0, [x19, #0x54d0]
   3e468:	mov	x0, #0x3
   3e46c:	ldr	x14, [sp, #0x1b8]
   3e470:	mov	x25, x0
   3e474:	cmp	x14, #0x164
   3e478:	b.lo	0x43b34
   3e47c:	ldr	x0, [x19, #0x5818]
   3e480:	ldr	x1, [sp, #0x1c0]
   3e484:	str	x0, [x1, #0x10]
   3e488:	ldr	x1, [x19, #0x5820]
   3e48c:	ldr	x2, [sp, #0x1c0]
   3e490:	str	x1, [x2, #0x18]
   3e494:	ldr	x2, [x19, #0x6238]
   3e498:	ldr	x5, [sp, #0x1c0]
   3e49c:	str	x2, [x5, #0xa30]
   3e4a0:	ldr	x2, [x19, #0x59b0]
   3e4a4:	str	x2, [x5, #0x1a8]
   3e4a8:	ldr	x2, [x19, #0x59b8]
   3e4ac:	str	x2, [x5, #0x1b0]
   3e4b0:	ldr	x2, [x19, #0x59c0]
   3e4b4:	str	x2, [x5, #0x1b8]
   3e4b8:	ldr	x2, [x19, #0x59c8]
   3e4bc:	str	x2, [x5, #0x1c0]
   3e4c0:	ldr	x2, [x19, #0x59d0]
   3e4c4:	str	x2, [x5, #0x1c8]
   3e4c8:	ldr	x7, [sp, #0x1c0]
   3e4cc:	str	x0, [x7, #0x10]
   3e4d0:	ldr	x9, [sp, #0x1c0]
   3e4d4:	str	x1, [x9, #0x18]
   3e4d8:	ldr	x0, [x19, #0x58f8]
   3e4dc:	ldr	x12, [sp, #0x1c0]
   3e4e0:	str	x0, [x12, #0xf0]
   3e4e4:	ldr	x0, [x19, #0x5900]
   3e4e8:	ldr	x15, [sp, #0x1c0]
   3e4ec:	str	x0, [x15, #0xf8]
   3e4f0:	ldr	x0, [x19, #0x5908]
   3e4f4:	ldr	x1, [sp, #0x1c0]
   3e4f8:	str	x0, [x1, #0x100]
   3e4fc:	ldr	x0, [x19, #0x5910]
   3e500:	str	x0, [x1, #0x108]
   3e504:	ldr	x0, [x19, #0x5918]
   3e508:	str	x0, [x1, #0x110]
   3e50c:	ldr	x0, [x19, #0x5920]
   3e510:	str	x0, [x1, #0x118]
   3e514:	ldr	x0, [x19, #0x5928]
   3e518:	str	x0, [x1, #0x120]
   3e51c:	ldr	x0, [x19, #0x5930]
   3e520:	str	x0, [x1, #0x128]
   3e524:	ldr	x0, [x19, #0x5938]
   3e528:	str	x0, [x1, #0x130]
   3e52c:	ldr	x0, [x19, #0x5a70]
   3e530:	str	x0, [x1, #0x268]
   3e534:	ldr	x0, [x19, #0x5a78]
   3e538:	str	x0, [x1, #0x270]
   3e53c:	ldr	x0, [x19, #0x5a80]
   3e540:	str	x0, [x1, #0x278]
   3e544:	ldr	x0, [x19, #0x5a88]
   3e548:	str	x0, [x1, #0x280]
   3e54c:	ldr	x0, [x19, #0x5a90]
   3e550:	str	x0, [x1, #0x288]
   3e554:	ldr	x0, [x19, #0x5a98]
   3e558:	str	x0, [x1, #0x290]
   3e55c:	ldr	x0, [x19, #0x5aa0]
   3e560:	str	x0, [x1, #0x298]
   3e564:	ldr	x1, [x19, #0x5aa8]
   3e568:	ldr	x0, [sp, #0x1c0]
   3e56c:	str	x1, [x0, #0x2a0]
   3e570:	ldr	x2, [x19, #0x5ab0]
   3e574:	str	x2, [x0, #0x2a8]
   3e578:	ldr	x5, [x19, #0x5d38]
   3e57c:	ldr	x6, [sp, #0x1c0]
   3e580:	str	x5, [x6, #0x530]
   3e584:	ldr	x5, [x19, #0x5d40]
   3e588:	str	x5, [x6, #0x538]
   3e58c:	ldr	x5, [x19, #0x5d48]
   3e590:	str	x5, [x9, #0x540]
   3e594:	ldr	x6, [x19, #0x5d50]
   3e598:	str	x6, [x12, #0x548]
   3e59c:	ldr	x7, [x19, #0x5d58]
   3e5a0:	str	x7, [x15, #0x550]
   3e5a4:	ldr	x8, [x19, #0x5d60]
   3e5a8:	str	x8, [x0, #0x558]
   3e5ac:	ldr	x9, [x19, #0x5d68]
   3e5b0:	str	x9, [x0, #0x560]
   3e5b4:	ldr	x10, [x19, #0x5d70]
   3e5b8:	str	x10, [x0, #0x568]
   3e5bc:	ldr	x11, [x19, #0x5e98]
   3e5c0:	str	x11, [x0, #0x690]
   3e5c4:	ldr	x12, [x19, #0x5ea0]
   3e5c8:	str	x12, [x0, #0x698]
   3e5cc:	ldr	x13, [x19, #0x5ea8]
   3e5d0:	str	x13, [x0, #0x6a0]
   3e5d4:	ldr	x14, [x19, #0x5eb0]
   3e5d8:	str	x14, [x0, #0x6a8]
   3e5dc:	ldr	x15, [x19, #0x5eb8]
   3e5e0:	str	x15, [x0, #0x6b0]
   3e5e4:	ldr	x0, [x19, #0x5ec0]
   3e5e8:	ldr	x1, [sp, #0x1c0]
   3e5ec:	str	x0, [x1, #0x6b8]
   3e5f0:	ldr	x0, [x19, #0x5ec8]
   3e5f4:	str	x0, [x1, #0x6c0]
   3e5f8:	ldr	x0, [x19, #0x5ed0]
   3e5fc:	str	x0, [x1, #0x6c8]
   3e600:	ldr	x0, [x19, #0x62a8]
   3e604:	str	x0, [x1, #0xaa0]
   3e608:	ldr	x0, [x19, #0x62b0]
   3e60c:	str	x0, [x1, #0xaa8]
   3e610:	ldr	x0, [x19, #0x62b8]
   3e614:	str	x0, [x1, #0xab0]
   3e618:	ldr	x0, [x19, #0x62c0]
   3e61c:	str	x0, [x1, #0xab8]
   3e620:	ldr	x0, [x19, #0x62c8]
   3e624:	str	x0, [x1, #0xac0]
   3e628:	ldr	x0, [x19, #0x62d0]
   3e62c:	ldr	x5, [sp, #0x1c0]
   3e630:	str	x0, [x5, #0xac8]
   3e634:	mov	x0, #0x0
   3e638:	ldr	x6, [sp, #0x1c0]
   3e63c:	str	x0, [x6, #0xad0]
   3e640:	ldr	x1, [x19, #0x62e0]
   3e644:	ldr	x9, [sp, #0x1c0]
   3e648:	str	x1, [x9, #0xad8]
   3e64c:	ldr	x1, [x19, #0x62e8]
   3e650:	ldr	x12, [sp, #0x1c0]
   3e654:	str	x1, [x12, #0xae0]
   3e658:	ldr	x14, [sp, #0x1c0]
   3e65c:	str	x0, [x14, #0xae8]
   3e660:	ldr	x1, [x19, #0x62f8]
   3e664:	ldr	x2, [sp, #0x1c0]
   3e668:	str	x1, [x2, #0xaf0]
   3e66c:	ldr	x1, [x19, #0x6300]
   3e670:	str	x1, [x2, #0xaf8]
   3e674:	ldr	x1, [sp, #0x1c0]
   3e678:	str	x0, [x1, #0xb00]
   3e67c:	ldr	x0, [x19, #0x6310]
   3e680:	str	x0, [x1, #0xb08]
   3e684:	ldr	x0, [x19, #0x6318]
   3e688:	str	x0, [x1, #0xb10]
   3e68c:	mov	x1, #0x66f
   3e690:	mov	x2, #-0x9
   3e694:	mov	x5, #0x1
   3e698:	ldur	x0, [sp, #0x8]
   3e69c:	ldr	x6, [sp, #0x1c8]
   3e6a0:	ldr	x21, [sp, #0x1d0]
   3e6a4:	blr	x21
   3e6a8:	cmp	x0, #0x0
   3e6ac:	b.ne	0x42348
   3e6b0:	mov	x0, #0x0
   3e6b4:	mov	x1, #0x3
   3e6b8:	add	sp, sp, #0x1e0
   3e6bc:	ldp	x19, x20, [sp], #0x10
   3e6c0:	ldp	x21, x22, [sp], #0x10
   3e6c4:	ldp	x23, x24, [sp], #0x10
   3e6c8:	ldp	x25, x26, [sp], #0x10
   3e6cc:	ldp	x27, x28, [sp], #0x10
   3e6d0:	ldp	x29, x30, [sp], #0x10
   3e6d4:	.long	0xd65f0fff
   3e6d8:	ldur	x21, [sp, #0xc0]
   3e6dc:	cmp	x26, x8
   3e6e0:	cset	x9, lo
   3e6e4:	cmp	x26, x8
   3e6e8:	b.lo	0x3e70c
   3e6ec:	ldur	x1, [sp, #0xa0]
   3e6f0:	mov	x3, x2
   3e6f4:	mov	x9, x26
   3e6f8:	mov	x22, x4
   3e6fc:	ldur	x23, [sp, #0xf0]
   3e700:	mov	x24, x0
   3e704:	mov	x27, x14
   3e708:	b	0x3eadc
   3e70c:	ldr	x23, [sp, #0x138]
   3e710:	ldr	w1, [x23, x26, lsl #2]
   3e714:	mov	w10, w1
   3e718:	ldur	x23, [sp, #0xc8]
   3e71c:	cmp	x10, x23
   3e720:	b.ne	0x3e744
   3e724:	ldur	x1, [sp, #0xa0]
   3e728:	mov	x3, x2
   3e72c:	mov	x9, x26
   3e730:	mov	x10, x4
   3e734:	mov	x20, x0
   3e738:	mov	x22, x14
   3e73c:	ldur	x23, [sp, #0xf0]
   3e740:	b	0x3eaac
   3e744:	ldr	x20, [sp, #0x120]
   3e748:	cmp	x10, x20
   3e74c:	b.lo	0x3e9c8
   3e750:	b	0x42350
   3e754:	ldr	x3, [x19, #0x54d8]
   3e758:	ldr	x4, [x19, #0x54e0]
   3e75c:	mov	x0, #0x0
   3e760:	str	x0, [x19, #0x54d0]
   3e764:	mov	x0, #0x3
   3e768:	ldr	x14, [sp, #0x1b8]
   3e76c:	mov	x25, x0
   3e770:	cmp	x14, #0x164
   3e774:	b.lo	0x43b34
   3e778:	ldr	x0, [x19, #0x5818]
   3e77c:	ldr	x1, [sp, #0x1c0]
   3e780:	str	x0, [x1, #0x10]
   3e784:	ldr	x1, [x19, #0x5820]
   3e788:	ldr	x2, [sp, #0x1c0]
   3e78c:	str	x1, [x2, #0x18]
   3e790:	ldr	x2, [x19, #0x6238]
   3e794:	ldr	x5, [sp, #0x1c0]
   3e798:	str	x2, [x5, #0xa30]
   3e79c:	ldr	x2, [sp, #0x1c0]
   3e7a0:	str	x0, [x2, #0x10]
   3e7a4:	str	x1, [x5, #0x18]
   3e7a8:	ldr	x0, [x19, #0x58f8]
   3e7ac:	ldr	x7, [sp, #0x1c0]
   3e7b0:	str	x0, [x7, #0xf0]
   3e7b4:	ldr	x0, [x19, #0x5900]
   3e7b8:	ldr	x10, [sp, #0x1c0]
   3e7bc:	str	x0, [x10, #0xf8]
   3e7c0:	ldr	x0, [x19, #0x5908]
   3e7c4:	ldr	x13, [sp, #0x1c0]
   3e7c8:	str	x0, [x13, #0x100]
   3e7cc:	ldr	x0, [x19, #0x5910]
   3e7d0:	ldr	x1, [sp, #0x1c0]
   3e7d4:	str	x0, [x1, #0x108]
   3e7d8:	ldr	x0, [x19, #0x5918]
   3e7dc:	str	x0, [x1, #0x110]
   3e7e0:	ldr	x0, [x19, #0x5920]
   3e7e4:	str	x0, [x1, #0x118]
   3e7e8:	ldr	x0, [x19, #0x5928]
   3e7ec:	str	x0, [x1, #0x120]
   3e7f0:	ldr	x0, [x19, #0x5930]
   3e7f4:	str	x0, [x1, #0x128]
   3e7f8:	ldr	x0, [x19, #0x5938]
   3e7fc:	str	x0, [x1, #0x130]
   3e800:	ldr	x0, [x19, #0x5a70]
   3e804:	str	x0, [x1, #0x268]
   3e808:	ldr	x0, [x19, #0x5a78]
   3e80c:	str	x0, [x1, #0x270]
   3e810:	ldr	x0, [x19, #0x5a80]
   3e814:	str	x0, [x1, #0x278]
   3e818:	ldr	x0, [x19, #0x5a88]
   3e81c:	str	x0, [x1, #0x280]
   3e820:	ldr	x0, [x19, #0x5a90]
   3e824:	str	x0, [x1, #0x288]
   3e828:	ldr	x0, [x19, #0x5a98]
   3e82c:	str	x0, [x1, #0x290]
   3e830:	ldr	x0, [x19, #0x5aa0]
   3e834:	str	x0, [x1, #0x298]
   3e838:	ldr	x0, [x19, #0x5aa8]
   3e83c:	str	x0, [x1, #0x2a0]
   3e840:	ldr	x0, [x19, #0x5ab0]
   3e844:	str	x0, [x1, #0x2a8]
   3e848:	ldr	x0, [x19, #0x5d38]
   3e84c:	str	x0, [x1, #0x530]
   3e850:	ldr	x0, [x19, #0x5d40]
   3e854:	str	x0, [x1, #0x538]
   3e858:	ldr	x0, [x19, #0x5d48]
   3e85c:	str	x0, [x5, #0x540]
   3e860:	ldr	x0, [x19, #0x5d50]
   3e864:	str	x0, [x7, #0x548]
   3e868:	ldr	x0, [x19, #0x5d58]
   3e86c:	str	x0, [x10, #0x550]
   3e870:	ldr	x0, [x19, #0x5d60]
   3e874:	str	x0, [x13, #0x558]
   3e878:	ldr	x0, [x19, #0x5d68]
   3e87c:	str	x0, [x1, #0x560]
   3e880:	ldr	x0, [x19, #0x5d70]
   3e884:	str	x0, [x1, #0x568]
   3e888:	ldr	x0, [x19, #0x5e98]
   3e88c:	str	x0, [x1, #0x690]
   3e890:	ldr	x0, [x19, #0x5ea0]
   3e894:	str	x0, [x1, #0x698]
   3e898:	ldr	x0, [x19, #0x5ea8]
   3e89c:	str	x0, [x1, #0x6a0]
   3e8a0:	ldr	x0, [x19, #0x5eb0]
   3e8a4:	str	x0, [x1, #0x6a8]
   3e8a8:	ldr	x0, [x19, #0x5eb8]
   3e8ac:	str	x0, [x1, #0x6b0]
   3e8b0:	ldr	x0, [x19, #0x5ec0]
   3e8b4:	str	x0, [x1, #0x6b8]
   3e8b8:	ldr	x0, [x19, #0x5ec8]
   3e8bc:	str	x0, [x1, #0x6c0]
   3e8c0:	ldr	x0, [x19, #0x5ed0]
   3e8c4:	str	x0, [x1, #0x6c8]
   3e8c8:	ldr	x0, [x19, #0x62a8]
   3e8cc:	str	x0, [x1, #0xaa0]
   3e8d0:	ldr	x0, [x19, #0x62b0]
   3e8d4:	str	x0, [x1, #0xaa8]
   3e8d8:	ldr	x0, [x19, #0x62b8]
   3e8dc:	str	x0, [x1, #0xab0]
   3e8e0:	ldr	x0, [x19, #0x62c0]
   3e8e4:	str	x0, [x1, #0xab8]
   3e8e8:	ldr	x1, [x19, #0x62c8]
   3e8ec:	ldr	x0, [sp, #0x1c0]
   3e8f0:	str	x1, [x0, #0xac0]
   3e8f4:	ldr	x2, [x19, #0x62d0]
   3e8f8:	str	x2, [x0, #0xac8]
   3e8fc:	mov	x5, #0x0
   3e900:	ldr	x1, [sp, #0x1c0]
   3e904:	str	x5, [x1, #0xad0]
   3e908:	ldr	x6, [x19, #0x62e0]
   3e90c:	str	x6, [x7, #0xad8]
   3e910:	ldr	x6, [x19, #0x62e8]
   3e914:	str	x6, [x7, #0xae0]
   3e918:	ldr	x9, [sp, #0x1c0]
   3e91c:	str	x5, [x9, #0xae8]
   3e920:	ldr	x7, [x19, #0x62f8]
   3e924:	ldr	x12, [sp, #0x1c0]
   3e928:	str	x7, [x12, #0xaf0]
   3e92c:	ldr	x8, [x19, #0x6300]
   3e930:	ldr	x15, [sp, #0x1c0]
   3e934:	str	x8, [x15, #0xaf8]
   3e938:	str	x5, [x0, #0xb00]
   3e93c:	ldr	x10, [x19, #0x6310]
   3e940:	str	x10, [x0, #0xb08]
   3e944:	ldr	x11, [x19, #0x6318]
   3e948:	str	x11, [x0, #0xb10]
   3e94c:	mov	x2, #-0x9
   3e950:	ldr	x21, [sp, #0x1d0]
   3e954:	ldur	x0, [sp, #0x8]
   3e958:	mov	x1, x20
   3e95c:	mov	x5, x23
   3e960:	ldr	x6, [sp, #0x1c8]
   3e964:	blr	x21
   3e968:	cmp	x0, #0x0
   3e96c:	b.ne	0x42554
   3e970:	mov	x0, #0x3
   3e974:	ldr	x14, [sp, #0x1b8]
   3e978:	mov	x25, x0
   3e97c:	cmp	x14, #0x2
   3e980:	b.lo	0x43b34
   3e984:	mov	x5, #0x0
   3e988:	ldr	x3, [sp, #0x1c0]
   3e98c:	str	x5, [x3]
   3e990:	ldr	x0, [x19, #0x22e8]
   3e994:	str	x0, [x3, #0x8]
   3e998:	ldur	x0, [sp, #0x8]
   3e99c:	mov	x1, x20
   3e9a0:	ldr	x6, [sp, #0x1c8]
   3e9a4:	ldr	x21, [sp, #0x1d0]
   3e9a8:	mov	x4, x23
   3e9ac:	mov	x2, x5
   3e9b0:	blr	x21
   3e9b4:	cmp	x0, #0x0
   3e9b8:	b.ne	0x4255c
   3e9bc:	mov	x0, #0x3
   3e9c0:	mov	x25, x0
   3e9c4:	b	0x43b34
   3e9c8:	ldr	x20, [sp, #0x128]
   3e9cc:	ldur	x23, [sp, #0xf0]
   3e9d0:	ldr	x1, [x20, w1, uxtw #3]
   3e9d4:	ldr	x3, [sp, #0x100]
   3e9d8:	and	x1, x3, x1
   3e9dc:	fmov	d0, x1
   3e9e0:	cnt.8b	v0, v0
   3e9e4:	addv.8b	b0, v0
   3e9e8:	umov.b	w1, v0[0]
   3e9ec:	eor	x3, x10, #0x3ffffffffffffff
   3e9f0:	orr	x9, x3, x1, lsl #58
   3e9f4:	ldur	x10, [sp, #0xa0]
   3e9f8:	cmp	x9, x10
   3e9fc:	cset	x1, hi
   3ea00:	cmp	x9, x14
   3ea04:	cset	x3, ne
   3ea08:	and	w1, w1, w3
   3ea0c:	cmp	x9, x0
   3ea10:	cset	x3, ne
   3ea14:	and	w1, w1, w3
   3ea18:	cmp	x9, x4
   3ea1c:	cset	x3, ne
   3ea20:	and	w1, w1, w3
   3ea24:	cmp	x9, x2
   3ea28:	cset	x3, ne
   3ea2c:	and	w1, w1, w3
   3ea30:	uxtb	w1, w1
   3ea34:	tbnz	w1, #0x0, 0x3ea50
   3ea38:	mov	x1, x14
   3ea3c:	mov	x3, x0
   3ea40:	mov	x9, x4
   3ea44:	mov	x10, x2
   3ea48:	ldur	x20, [sp, #0xa0]
   3ea4c:	b	0x3ea80
   3ea50:	cmp	x9, x14
   3ea54:	csel	x1, x9, x14, hi
   3ea58:	csel	x9, x9, x14, lo
   3ea5c:	cmp	x9, x0
   3ea60:	csel	x3, x9, x0, hi
   3ea64:	csel	x10, x9, x0, lo
   3ea68:	cmp	x10, x4
   3ea6c:	csel	x9, x10, x4, hi
   3ea70:	csel	x20, x10, x4, lo
   3ea74:	cmp	x20, x2
   3ea78:	csel	x10, x20, x2, hi
   3ea7c:	csel	x20, x20, x2, lo
   3ea80:	mov	x22, x14
   3ea84:	mov	x14, x1
   3ea88:	ldur	x1, [sp, #0xa0]
   3ea8c:	stur	x20, [sp, #0xa0]
   3ea90:	mov	x20, x0
   3ea94:	mov	x0, x3
   3ea98:	mov	x3, x2
   3ea9c:	mov	x2, x10
   3eaa0:	mov	x10, x4
   3eaa4:	mov	x4, x9
   3eaa8:	mov	x9, x26
   3eaac:	mov	x27, x14
   3eab0:	mov	x24, x0
   3eab4:	mov	x14, x22
   3eab8:	mov	x22, x4
   3eabc:	mov	x4, x10
   3eac0:	mov	x28, x2
   3eac4:	mov	x2, x3
   3eac8:	mov	x3, x28
   3eacc:	mov	x28, x1
   3ead0:	ldur	x1, [sp, #0xa0]
   3ead4:	stur	x28, [sp, #0xa0]
   3ead8:	mov	x0, x20
   3eadc:	cmp	x26, x8
   3eae0:	b.lo	0x412d0
   3eae4:	mov	w1, #0xe176
   3eae8:	movk	w1, #0x2, lsl #16
   3eaec:	sub	x3, x5, x1
   3eaf0:	ldur	x5, [sp, #0xb8]
   3eaf4:	tbnz	w13, #0x1, 0x42564
   3eaf8:	mov	x22, #0x0
   3eafc:	stur	x22, [sp, #0x78]
   3eb00:	ldur	x1, [sp, #0x78]
   3eb04:	stur	x1, [sp, #0x80]
   3eb08:	ldur	x1, [sp, #0xb8]
   3eb0c:	ldr	x8, [sp, #0x108]
   3eb10:	cmp	x1, x8
   3eb14:	b.lo	0x41298
   3eb18:	tbnz	w13, #0x0, 0x425b8
   3eb1c:	ldur	x0, [sp, #0xc8]
   3eb20:	ldr	x23, [sp, #0x1a0]
   3eb24:	cmp	x0, x23
   3eb28:	b.lo	0x3edb0
   3eb2c:	b	0x4260c
   3eb30:	ldr	x3, [x19, #0x54d8]
   3eb34:	ldr	x4, [x19, #0x54e0]
   3eb38:	mov	x0, #0x0
   3eb3c:	str	x0, [x19, #0x54d0]
   3eb40:	mov	x0, #0x3
   3eb44:	ldr	x14, [sp, #0x1b8]
   3eb48:	mov	x25, x0
   3eb4c:	cmp	x14, #0x164
   3eb50:	b.lo	0x43b34
   3eb54:	ldr	x0, [x19, #0x5818]
   3eb58:	ldr	x1, [sp, #0x1c0]
   3eb5c:	str	x0, [x1, #0x10]
   3eb60:	ldr	x1, [x19, #0x5820]
   3eb64:	ldr	x2, [sp, #0x1c0]
   3eb68:	str	x1, [x2, #0x18]
   3eb6c:	ldr	x2, [x19, #0x6238]
   3eb70:	ldr	x5, [sp, #0x1c0]
   3eb74:	str	x2, [x5, #0xa30]
   3eb78:	ldr	x2, [sp, #0x1c0]
   3eb7c:	str	x0, [x2, #0x10]
   3eb80:	ldr	x0, [sp, #0x1c0]
   3eb84:	str	x1, [x0, #0x18]
   3eb88:	ldr	x0, [x19, #0x58f8]
   3eb8c:	ldr	x1, [sp, #0x1c0]
   3eb90:	str	x0, [x1, #0xf0]
   3eb94:	ldr	x0, [x19, #0x5900]
   3eb98:	str	x0, [x1, #0xf8]
   3eb9c:	ldr	x0, [x19, #0x5908]
   3eba0:	str	x0, [x5, #0x100]
   3eba4:	ldr	x0, [x19, #0x5910]
   3eba8:	ldr	x6, [sp, #0x1c0]
   3ebac:	str	x0, [x6, #0x108]
   3ebb0:	ldr	x0, [x19, #0x5918]
   3ebb4:	ldr	x9, [sp, #0x1c0]
   3ebb8:	str	x0, [x9, #0x110]
   3ebbc:	ldr	x0, [x19, #0x5920]
   3ebc0:	ldr	x12, [sp, #0x1c0]
   3ebc4:	str	x0, [x12, #0x118]
   3ebc8:	ldr	x0, [x19, #0x5928]
   3ebcc:	ldr	x15, [sp, #0x1c0]
   3ebd0:	str	x0, [x15, #0x120]
   3ebd4:	ldr	x0, [x19, #0x5930]
   3ebd8:	str	x0, [x1, #0x128]
   3ebdc:	ldr	x0, [x19, #0x5938]
   3ebe0:	str	x0, [x1, #0x130]
   3ebe4:	ldr	x0, [x19, #0x5a70]
   3ebe8:	str	x0, [x1, #0x268]
   3ebec:	ldr	x0, [x19, #0x5a78]
   3ebf0:	str	x0, [x1, #0x270]
   3ebf4:	ldr	x0, [x19, #0x5a80]
   3ebf8:	str	x0, [x1, #0x278]
   3ebfc:	ldr	x0, [x19, #0x5a88]
   3ec00:	str	x0, [x1, #0x280]
   3ec04:	ldr	x0, [x19, #0x5a90]
   3ec08:	str	x0, [x1, #0x288]
   3ec0c:	ldr	x0, [x19, #0x5a98]
   3ec10:	str	x0, [x1, #0x290]
   3ec14:	ldr	x0, [x19, #0x5aa0]
   3ec18:	str	x0, [x1, #0x298]
   3ec1c:	ldr	x0, [x19, #0x5aa8]
   3ec20:	str	x0, [x1, #0x2a0]
   3ec24:	ldr	x0, [x19, #0x5ab0]
   3ec28:	str	x0, [x1, #0x2a8]
   3ec2c:	ldr	x0, [x19, #0x5d38]
   3ec30:	str	x0, [x1, #0x530]
   3ec34:	ldr	x0, [x19, #0x5d40]
   3ec38:	str	x0, [x1, #0x538]
   3ec3c:	ldr	x0, [x19, #0x5d48]
   3ec40:	str	x0, [x1, #0x540]
   3ec44:	ldr	x0, [x19, #0x5d50]
   3ec48:	str	x0, [x1, #0x548]
   3ec4c:	ldr	x0, [x19, #0x5d58]
   3ec50:	str	x0, [x1, #0x550]
   3ec54:	ldr	x0, [x19, #0x5d60]
   3ec58:	str	x0, [x5, #0x558]
   3ec5c:	ldr	x0, [x19, #0x5d68]
   3ec60:	str	x0, [x6, #0x560]
   3ec64:	ldr	x0, [x19, #0x5d70]
   3ec68:	str	x0, [x9, #0x568]
   3ec6c:	ldr	x0, [x19, #0x5e98]
   3ec70:	str	x0, [x12, #0x690]
   3ec74:	ldr	x0, [x19, #0x5ea0]
   3ec78:	str	x0, [x15, #0x698]
   3ec7c:	ldr	x0, [x19, #0x5ea8]
   3ec80:	str	x0, [x1, #0x6a0]
   3ec84:	ldr	x0, [x19, #0x5eb0]
   3ec88:	str	x0, [x1, #0x6a8]
   3ec8c:	ldr	x0, [x19, #0x5eb8]
   3ec90:	str	x0, [x1, #0x6b0]
   3ec94:	ldr	x0, [x19, #0x5ec0]
   3ec98:	str	x0, [x1, #0x6b8]
   3ec9c:	ldr	x1, [x19, #0x5ec8]
   3eca0:	ldr	x0, [sp, #0x1c0]
   3eca4:	str	x1, [x0, #0x6c0]
   3eca8:	ldr	x2, [x19, #0x5ed0]
   3ecac:	str	x2, [x0, #0x6c8]
   3ecb0:	ldr	x5, [x19, #0x62a8]
   3ecb4:	str	x5, [x0, #0xaa0]
   3ecb8:	ldr	x5, [x19, #0x62b0]
   3ecbc:	str	x5, [x0, #0xaa8]
   3ecc0:	ldr	x5, [x19, #0x62b8]
   3ecc4:	str	x5, [x0, #0xab0]
   3ecc8:	ldr	x6, [x19, #0x62c0]
   3eccc:	str	x6, [x0, #0xab8]
   3ecd0:	ldr	x7, [x19, #0x62c8]
   3ecd4:	str	x7, [x0, #0xac0]
   3ecd8:	ldr	x8, [x19, #0x62d0]
   3ecdc:	str	x8, [x0, #0xac8]
   3ece0:	mov	x9, #0x0
   3ece4:	str	x9, [x0, #0xad0]
   3ece8:	ldr	x10, [x19, #0x62e0]
   3ecec:	str	x10, [x0, #0xad8]
   3ecf0:	ldr	x11, [x19, #0x62e8]
   3ecf4:	str	x11, [x0, #0xae0]
   3ecf8:	str	x9, [x0, #0xae8]
   3ecfc:	ldr	x13, [x19, #0x62f8]
   3ed00:	ldr	x2, [sp, #0x1c0]
   3ed04:	str	x13, [x2, #0xaf0]
   3ed08:	ldr	x14, [x19, #0x6300]
   3ed0c:	ldr	x5, [sp, #0x1c0]
   3ed10:	str	x14, [x5, #0xaf8]
   3ed14:	ldr	x7, [sp, #0x1c0]
   3ed18:	str	x9, [x7, #0xb00]
   3ed1c:	ldr	x0, [x19, #0x6310]
   3ed20:	ldr	x10, [sp, #0x1c0]
   3ed24:	str	x0, [x10, #0xb08]
   3ed28:	ldr	x0, [x19, #0x6318]
   3ed2c:	ldr	x13, [sp, #0x1c0]
   3ed30:	str	x0, [x13, #0xb10]
   3ed34:	mov	x1, #0x71d
   3ed38:	mov	x2, #-0x9
   3ed3c:	ldr	x21, [sp, #0x1d0]
   3ed40:	ldur	x0, [sp, #0x8]
   3ed44:	mov	x5, x20
   3ed48:	ldr	x6, [sp, #0x1c8]
   3ed4c:	blr	x21
   3ed50:	cmp	x0, #0x0
   3ed54:	b.ne	0x42738
   3ed58:	mov	x0, #0x3
   3ed5c:	ldr	x14, [sp, #0x1b8]
   3ed60:	mov	x25, x0
   3ed64:	cmp	x14, #0x2
   3ed68:	b.lo	0x43b34
   3ed6c:	mov	x5, #0x0
   3ed70:	ldr	x3, [sp, #0x1c0]
   3ed74:	str	x5, [x3]
   3ed78:	ldr	x0, [x19, #0x2578]
   3ed7c:	str	x0, [x3, #0x8]
   3ed80:	mov	x1, #0x71d
   3ed84:	ldur	x0, [sp, #0x8]
   3ed88:	ldr	x6, [sp, #0x1c8]
   3ed8c:	ldr	x21, [sp, #0x1d0]
   3ed90:	mov	x4, x20
   3ed94:	mov	x2, x5
   3ed98:	blr	x21
   3ed9c:	cmp	x0, #0x0
   3eda0:	b.ne	0x42740
   3eda4:	mov	x0, #0x3
   3eda8:	mov	x25, x0
   3edac:	b	0x43b34
   3edb0:	ldur	x8, [sp, #0xc8]
   3edb4:	ldr	x23, [sp, #0x1a8]
   3edb8:	ldr	x14, [x23, x8, lsl #3]
   3edbc:	ldr	x0, [sp, #0x110]
   3edc0:	ldr	x23, [sp, #0x1a0]
   3edc4:	cmp	x0, x23
   3edc8:	b.lo	0x3f044
   3edcc:	b	0x42748
   3edd0:	ldr	x3, [x19, #0x54d8]
   3edd4:	ldr	x4, [x19, #0x54e0]
   3edd8:	mov	x15, #0x0
   3eddc:	str	x15, [x19, #0x54d0]
   3ede0:	mov	x0, #0x3
   3ede4:	ldr	x14, [sp, #0x1b8]
   3ede8:	mov	x25, x0
   3edec:	cmp	x14, #0x164
   3edf0:	b.lo	0x43b34
   3edf4:	ldr	x0, [x19, #0x5818]
   3edf8:	ldr	x1, [sp, #0x1c0]
   3edfc:	str	x0, [x1, #0x10]
   3ee00:	ldr	x1, [x19, #0x5820]
   3ee04:	ldr	x2, [sp, #0x1c0]
   3ee08:	str	x1, [x2, #0x18]
   3ee0c:	ldr	x2, [x19, #0x6238]
   3ee10:	ldr	x5, [sp, #0x1c0]
   3ee14:	str	x2, [x5, #0xa30]
   3ee18:	ldr	x2, [sp, #0x1c0]
   3ee1c:	str	x0, [x2, #0x10]
   3ee20:	str	x1, [x5, #0x18]
   3ee24:	ldr	x0, [x19, #0x58f8]
   3ee28:	ldr	x6, [sp, #0x1c0]
   3ee2c:	str	x0, [x6, #0xf0]
   3ee30:	ldr	x0, [x19, #0x5900]
   3ee34:	ldr	x9, [sp, #0x1c0]
   3ee38:	str	x0, [x9, #0xf8]
   3ee3c:	ldr	x0, [x19, #0x5908]
   3ee40:	ldr	x12, [sp, #0x1c0]
   3ee44:	str	x0, [x12, #0x100]
   3ee48:	ldr	x0, [x19, #0x5910]
   3ee4c:	ldr	x15, [sp, #0x1c0]
   3ee50:	str	x0, [x15, #0x108]
   3ee54:	ldr	x0, [x19, #0x5918]
   3ee58:	ldr	x1, [sp, #0x1c0]
   3ee5c:	str	x0, [x1, #0x110]
   3ee60:	ldr	x0, [x19, #0x5920]
   3ee64:	str	x0, [x1, #0x118]
   3ee68:	ldr	x0, [x19, #0x5928]
   3ee6c:	str	x0, [x1, #0x120]
   3ee70:	ldr	x0, [x19, #0x5930]
   3ee74:	str	x0, [x1, #0x128]
   3ee78:	ldr	x0, [x19, #0x5938]
   3ee7c:	str	x0, [x1, #0x130]
   3ee80:	ldr	x0, [x19, #0x5a70]
   3ee84:	str	x0, [x1, #0x268]
   3ee88:	ldr	x0, [x19, #0x5a78]
   3ee8c:	str	x0, [x1, #0x270]
   3ee90:	ldr	x0, [x19, #0x5a80]
   3ee94:	str	x0, [x1, #0x278]
   3ee98:	ldr	x0, [x19, #0x5a88]
   3ee9c:	str	x0, [x1, #0x280]
   3eea0:	ldr	x0, [x19, #0x5a90]
   3eea4:	str	x0, [x1, #0x288]
   3eea8:	ldr	x0, [x19, #0x5a98]
   3eeac:	str	x0, [x1, #0x290]
   3eeb0:	ldr	x0, [x19, #0x5aa0]
   3eeb4:	str	x0, [x1, #0x298]
   3eeb8:	ldr	x0, [x19, #0x5aa8]
   3eebc:	str	x0, [x1, #0x2a0]
   3eec0:	ldr	x0, [x19, #0x5ab0]
   3eec4:	str	x0, [x1, #0x2a8]
   3eec8:	ldr	x0, [x19, #0x5d38]
   3eecc:	str	x0, [x1, #0x530]
   3eed0:	ldr	x0, [x19, #0x5d40]
   3eed4:	str	x0, [x1, #0x538]
   3eed8:	ldr	x0, [x19, #0x5d48]
   3eedc:	str	x0, [x5, #0x540]
   3eee0:	ldr	x0, [x19, #0x5d50]
   3eee4:	str	x0, [x6, #0x548]
   3eee8:	ldr	x0, [x19, #0x5d58]
   3eeec:	str	x0, [x9, #0x550]
   3eef0:	ldr	x0, [x19, #0x5d60]
   3eef4:	str	x0, [x12, #0x558]
   3eef8:	ldr	x0, [x19, #0x5d68]
   3eefc:	str	x0, [x15, #0x560]
   3ef00:	ldr	x0, [x19, #0x5d70]
   3ef04:	str	x0, [x1, #0x568]
   3ef08:	ldr	x0, [x19, #0x5e98]
   3ef0c:	str	x0, [x1, #0x690]
   3ef10:	ldr	x0, [x19, #0x5ea0]
   3ef14:	str	x0, [x1, #0x698]
   3ef18:	ldr	x0, [x19, #0x5ea8]
   3ef1c:	str	x0, [x1, #0x6a0]
   3ef20:	ldr	x0, [x19, #0x5eb0]
   3ef24:	str	x0, [x1, #0x6a8]
   3ef28:	ldr	x0, [x19, #0x5eb8]
   3ef2c:	str	x0, [x1, #0x6b0]
   3ef30:	ldr	x0, [x19, #0x5ec0]
   3ef34:	str	x0, [x1, #0x6b8]
   3ef38:	ldr	x0, [x19, #0x5ec8]
   3ef3c:	str	x0, [x1, #0x6c0]
   3ef40:	ldr	x0, [x19, #0x5ed0]
   3ef44:	str	x0, [x1, #0x6c8]
   3ef48:	ldr	x0, [x19, #0x62a8]
   3ef4c:	str	x0, [x1, #0xaa0]
   3ef50:	ldr	x0, [x19, #0x62b0]
   3ef54:	str	x0, [x1, #0xaa8]
   3ef58:	ldr	x0, [x19, #0x62b8]
   3ef5c:	str	x0, [x1, #0xab0]
   3ef60:	ldr	x0, [x19, #0x62c0]
   3ef64:	str	x0, [x1, #0xab8]
   3ef68:	ldr	x0, [x19, #0x62c8]
   3ef6c:	str	x0, [x1, #0xac0]
   3ef70:	ldr	x0, [x19, #0x62d0]
   3ef74:	str	x0, [x1, #0xac8]
   3ef78:	mov	x1, #0x0
   3ef7c:	ldr	x0, [sp, #0x1c0]
   3ef80:	str	x1, [x0, #0xad0]
   3ef84:	ldr	x2, [x19, #0x62e0]
   3ef88:	str	x2, [x5, #0xad8]
   3ef8c:	ldr	x5, [x19, #0x62e8]
   3ef90:	str	x5, [x6, #0xae0]
   3ef94:	ldr	x8, [sp, #0x1c0]
   3ef98:	str	x1, [x8, #0xae8]
   3ef9c:	ldr	x5, [x19, #0x62f8]
   3efa0:	ldr	x11, [sp, #0x1c0]
   3efa4:	str	x5, [x11, #0xaf0]
   3efa8:	ldr	x6, [x19, #0x6300]
   3efac:	ldr	x14, [sp, #0x1c0]
   3efb0:	str	x6, [x14, #0xaf8]
   3efb4:	str	x1, [x0, #0xb00]
   3efb8:	ldr	x8, [x19, #0x6310]
   3efbc:	str	x8, [x0, #0xb08]
   3efc0:	ldr	x9, [x19, #0x6318]
   3efc4:	str	x9, [x0, #0xb10]
   3efc8:	mov	x1, #0x71f
   3efcc:	mov	x2, #-0x9
   3efd0:	ldr	x21, [sp, #0x1d0]
   3efd4:	ldur	x0, [sp, #0x8]
   3efd8:	mov	x5, x20
   3efdc:	ldr	x6, [sp, #0x1c8]
   3efe0:	blr	x21
   3efe4:	cmp	x0, #0x0
   3efe8:	b.ne	0x42878
   3efec:	mov	x0, #0x3
   3eff0:	ldr	x14, [sp, #0x1b8]
   3eff4:	mov	x25, x0
   3eff8:	cmp	x14, #0x2
   3effc:	b.lo	0x43b34
   3f000:	mov	x5, #0x0
   3f004:	ldr	x3, [sp, #0x1c0]
   3f008:	str	x5, [x3]
   3f00c:	ldr	x0, [x19, #0x2588]
   3f010:	str	x0, [x3, #0x8]
   3f014:	mov	x1, #0x71f
   3f018:	ldur	x0, [sp, #0x8]
   3f01c:	ldr	x6, [sp, #0x1c8]
   3f020:	ldr	x21, [sp, #0x1d0]
   3f024:	mov	x4, x20
   3f028:	mov	x2, x5
   3f02c:	blr	x21
   3f030:	cmp	x0, #0x0
   3f034:	b.ne	0x42880
   3f038:	mov	x0, #0x3
   3f03c:	mov	x25, x0
   3f040:	b	0x43b34
   3f044:	ldr	x23, [sp, #0x1a8]
   3f048:	ldr	x12, [x23, x0, lsl #3]
   3f04c:	mov	x0, #0x0
   3f050:	ldur	x1, [sp, #0x88]
   3f054:	ldur	x24, [sp, #0x28]
   3f058:	stur	x0, [sp, #0x20]
   3f05c:	cmp	x24, x1
   3f060:	cset	x0, ls
   3f064:	sub	x1, x1, x24
   3f068:	cmp	x1, #0x4
   3f06c:	cset	x5, hi
   3f070:	mov	x1, x5
   3f074:	and	w5, w0, w1
   3f078:	stur	x1, [sp, #0xe8]
   3f07c:	mov	x0, #0x1000000000000000
   3f080:	mov	w1, #0x1706
   3f084:	movk	w1, #0x1, lsl #16
   3f088:	cmp	x3, x1
   3f08c:	cset	x1, hs
   3f090:	and	w1, w1, w5
   3f094:	uxtb	w1, w1
   3f098:	cbz	x1, 0x42888
   3f09c:	b	0x3f4c0
   3f0a0:	ldur	x8, [sp, #0xc8]
   3f0a4:	ldur	x10, [sp, #0xc8]
   3f0a8:	b	0x3f11c
   3f0ac:	ldur	x2, [sp, #0x60]
   3f0b0:	mov	x4, x3
   3f0b4:	b	0x3f108
   3f0b8:	tbnz	w1, #0x0, 0x3f0ec
   3f0bc:	tbnz	w1, #0x0, 0x3f0dc
   3f0c0:	mov	w2, #0x1
   3f0c4:	cmp	x1, #0x0
   3f0c8:	ldur	x28, [sp, #0xe8]
   3f0cc:	csel	x1, x28, x2, eq
   3f0d0:	ldur	x2, [sp, #0x60]
   3f0d4:	mov	x4, x3
   3f0d8:	b	0x3f108
   3f0dc:	mov	w1, #0x1
   3f0e0:	ldur	x2, [sp, #0x60]
   3f0e4:	mov	x4, x3
   3f0e8:	b	0x3f108
   3f0ec:	mov	w1, #0x1
   3f0f0:	ldur	x2, [sp, #0x60]
   3f0f4:	mov	x4, x3
   3f0f8:	b	0x3f108
   3f0fc:	mov	w1, #0x1
   3f100:	ldur	x2, [sp, #0x60]
   3f104:	mov	x4, x3
   3f108:	tbnz	w1, #0x0, 0x3f4c0
   3f10c:	mov	x3, x4
   3f110:	ldur	x8, [sp, #0xc8]
   3f114:	ldur	x10, [sp, #0xc8]
   3f118:	stur	x2, [sp, #0x60]
   3f11c:	mov	x1, #0x0
   3f120:	str	x1, [x19, #0x30]
   3f124:	str	x0, [x19, #0x38]
   3f128:	mov	x0, #0x1
   3f12c:	str	x0, [x19, #0x48]
   3f130:	mov	x2, #0x101010101010101
   3f134:	str	x2, [x19, #0x50]
   3f138:	mov	x20, #0x2
   3f13c:	str	x20, [x19, #0x58]
   3f140:	mov	x2, #0x3
   3f144:	str	x2, [x19, #0x60]
   3f148:	mov	x2, #0x4
   3f14c:	str	x2, [x19, #0x68]
   3f150:	stur	x2, [sp, #0xe0]
   3f154:	mov	x2, #0xf0f0f0f0f0f0f0f
   3f158:	str	x2, [x19, #0x90]
   3f15c:	mov	x2, #0x3333333333333333
   3f160:	str	x2, [x19, #0xa0]
   3f164:	mov	x2, #0x38
   3f168:	str	x2, [x19, #0xa8]
   3f16c:	mov	x2, #0x3a
   3f170:	str	x2, [x19, #0xb0]
   3f174:	mov	x2, #0x5555555555555555
   3f178:	str	x2, [x19, #0xc8]
   3f17c:	mov	x2, #0x3ffffffffffffff
   3f180:	str	x2, [x19, #0xd8]
   3f184:	str	x1, [x19, #0x178]
   3f188:	str	x0, [x19, #0x180]
   3f18c:	ldur	x23, [sp, #0xc8]
   3f190:	str	x23, [x19, #0x2140]
   3f194:	ldr	x27, [sp, #0x1b0]
   3f198:	str	x27, [x19, #0x2148]
   3f19c:	ldr	x2, [sp, #0x118]
   3f1a0:	uxtb	w9, w2
   3f1a4:	str	x9, [x19, #0x2158]
   3f1a8:	ldur	x2, [sp, #0x58]
   3f1ac:	str	x2, [x19, #0x54d0]
   3f1b0:	str	x3, [x19, #0x54d8]
   3f1b4:	ldur	x4, [sp, #0x60]
   3f1b8:	str	x4, [x19, #0x54e0]
   3f1bc:	str	x8, [x19, #0x5818]
   3f1c0:	str	x27, [x19, #0x5820]
   3f1c4:	str	x14, [x19, #0x5d38]
   3f1c8:	str	x12, [x19, #0x5d40]
   3f1cc:	str	x10, [x19, #0x5d48]
   3f1d0:	ldur	x23, [sp, #0x10]
   3f1d4:	str	x23, [x19, #0x5d50]
   3f1d8:	ldur	x26, [sp, #0x30]
   3f1dc:	str	x26, [x19, #0x5d58]
   3f1e0:	ldur	x23, [sp, #0x38]
   3f1e4:	str	x23, [x19, #0x5d60]
   3f1e8:	ldur	x25, [sp, #0x40]
   3f1ec:	str	x25, [x19, #0x5d68]
   3f1f0:	ldur	x23, [sp, #0x48]
   3f1f4:	str	x23, [x19, #0x5d70]
   3f1f8:	ldur	x24, [sp, #0x28]
   3f1fc:	str	x24, [x19, #0x6238]
   3f200:	add	x2, x15, #0x1
   3f204:	str	x2, [x19, #0x62a8]
   3f208:	ldur	x23, [sp, #0x68]
   3f20c:	str	x23, [x19, #0x62b0]
   3f210:	ldur	x28, [sp, #0x70]
   3f214:	str	x28, [x19, #0x62b8]
   3f218:	ldur	x4, [sp, #0x50]
   3f21c:	sub	x3, x4, x3
   3f220:	mov	w4, #0xb946
   3f224:	movk	w4, #0x1, lsl #16
   3f228:	msub	x2, x2, x4, x3
   3f22c:	str	x2, [x19, #0x62c0]
   3f230:	str	x1, [x19, #0x62c8]
   3f234:	str	x1, [x19, #0x62d0]
   3f238:	ldur	x22, [sp, #0x78]
   3f23c:	str	x22, [x19, #0x62e0]
   3f240:	ldur	x9, [sp, #0x80]
   3f244:	str	x9, [x19, #0x62e8]
   3f248:	str	x0, [x19, #0x62f8]
   3f24c:	ldur	x0, [sp, #0x20]
   3f250:	str	x0, [x19, #0x6300]
   3f254:	str	x7, [x19, #0x6310]
   3f258:	str	x6, [x19, #0x6318]
   3f25c:	ldr	x0, [x19, #0x54d0]
   3f260:	cmp	x0, #0x0
   3f264:	b.eq	0x3f498
   3f268:	ldr	x3, [x19, #0x54d8]
   3f26c:	ldr	x4, [x19, #0x54e0]
   3f270:	mov	x0, #0x0
   3f274:	str	x0, [x19, #0x54d0]
   3f278:	mov	x0, #0x3
   3f27c:	ldr	x14, [sp, #0x1b8]
   3f280:	mov	x25, x0
   3f284:	cmp	x14, #0x164
   3f288:	b.lo	0x43b34
   3f28c:	ldr	x0, [x19, #0x5818]
   3f290:	ldr	x1, [sp, #0x1c0]
   3f294:	str	x0, [x1, #0x10]
   3f298:	ldr	x1, [x19, #0x5820]
   3f29c:	ldr	x2, [sp, #0x1c0]
   3f2a0:	str	x1, [x2, #0x18]
   3f2a4:	ldr	x2, [x19, #0x6238]
   3f2a8:	ldr	x5, [sp, #0x1c0]
   3f2ac:	str	x2, [x5, #0xa30]
   3f2b0:	ldr	x2, [sp, #0x1c0]
   3f2b4:	str	x0, [x2, #0x10]
   3f2b8:	str	x1, [x2, #0x18]
   3f2bc:	ldr	x0, [x19, #0x58f8]
   3f2c0:	str	x0, [x5, #0xf0]
   3f2c4:	ldr	x0, [x19, #0x5900]
   3f2c8:	ldr	x7, [sp, #0x1c0]
   3f2cc:	str	x0, [x7, #0xf8]
   3f2d0:	ldr	x0, [x19, #0x5908]
   3f2d4:	ldr	x10, [sp, #0x1c0]
   3f2d8:	str	x0, [x10, #0x100]
   3f2dc:	ldr	x0, [x19, #0x5910]
   3f2e0:	ldr	x13, [sp, #0x1c0]
   3f2e4:	str	x0, [x13, #0x108]
   3f2e8:	ldr	x0, [x19, #0x5918]
   3f2ec:	ldr	x1, [sp, #0x1c0]
   3f2f0:	str	x0, [x1, #0x110]
   3f2f4:	ldr	x0, [x19, #0x5920]
   3f2f8:	str	x0, [x1, #0x118]
   3f2fc:	ldr	x0, [x19, #0x5928]
   3f300:	str	x0, [x1, #0x120]
   3f304:	ldr	x0, [x19, #0x5930]
   3f308:	str	x0, [x1, #0x128]
   3f30c:	ldr	x0, [x19, #0x5938]
   3f310:	str	x0, [x1, #0x130]
   3f314:	ldr	x0, [x19, #0x5a70]
   3f318:	str	x0, [x1, #0x268]
   3f31c:	ldr	x0, [x19, #0x5a78]
   3f320:	str	x0, [x1, #0x270]
   3f324:	ldr	x0, [x19, #0x5a80]
   3f328:	str	x0, [x1, #0x278]
   3f32c:	ldr	x0, [x19, #0x5a88]
   3f330:	str	x0, [x1, #0x280]
   3f334:	ldr	x0, [x19, #0x5a90]
   3f338:	str	x0, [x1, #0x288]
   3f33c:	ldr	x0, [x19, #0x5a98]
   3f340:	str	x0, [x1, #0x290]
   3f344:	ldr	x0, [x19, #0x5aa0]
   3f348:	str	x0, [x1, #0x298]
   3f34c:	ldr	x0, [x19, #0x5aa8]
   3f350:	str	x0, [x1, #0x2a0]
   3f354:	ldr	x0, [x19, #0x5ab0]
   3f358:	str	x0, [x1, #0x2a8]
   3f35c:	ldr	x0, [x19, #0x5d38]
   3f360:	str	x0, [x1, #0x530]
   3f364:	ldr	x1, [x19, #0x5d40]
   3f368:	ldr	x0, [sp, #0x1c0]
   3f36c:	str	x1, [x0, #0x538]
   3f370:	ldr	x2, [x19, #0x5d48]
   3f374:	ldr	x1, [sp, #0x1c0]
   3f378:	str	x2, [x1, #0x540]
   3f37c:	ldr	x5, [x19, #0x5d50]
   3f380:	ldr	x6, [sp, #0x1c0]
   3f384:	str	x5, [x6, #0x548]
   3f388:	ldr	x5, [x19, #0x5d58]
   3f38c:	str	x5, [x7, #0x550]
   3f390:	ldr	x5, [x19, #0x5d60]
   3f394:	str	x5, [x10, #0x558]
   3f398:	ldr	x6, [x19, #0x5d68]
   3f39c:	str	x6, [x13, #0x560]
   3f3a0:	ldr	x7, [x19, #0x5d70]
   3f3a4:	str	x7, [x0, #0x568]
   3f3a8:	ldr	x8, [x19, #0x5e98]
   3f3ac:	str	x8, [x0, #0x690]
   3f3b0:	ldr	x9, [x19, #0x5ea0]
   3f3b4:	str	x9, [x0, #0x698]
   3f3b8:	ldr	x10, [x19, #0x5ea8]
   3f3bc:	str	x10, [x0, #0x6a0]
   3f3c0:	ldr	x11, [x19, #0x5eb0]
   3f3c4:	str	x11, [x0, #0x6a8]
   3f3c8:	ldr	x12, [x19, #0x5eb8]
   3f3cc:	str	x12, [x0, #0x6b0]
   3f3d0:	ldr	x13, [x19, #0x5ec0]
   3f3d4:	str	x13, [x0, #0x6b8]
   3f3d8:	ldr	x14, [x19, #0x5ec8]
   3f3dc:	str	x14, [x0, #0x6c0]
   3f3e0:	ldr	x15, [x19, #0x5ed0]
   3f3e4:	str	x15, [x0, #0x6c8]
   3f3e8:	ldr	x0, [x19, #0x62a8]
   3f3ec:	str	x0, [x1, #0xaa0]
   3f3f0:	ldr	x0, [x19, #0x62b0]
   3f3f4:	str	x0, [x1, #0xaa8]
   3f3f8:	ldr	x0, [x19, #0x62b8]
   3f3fc:	str	x0, [x1, #0xab0]
   3f400:	ldr	x0, [x19, #0x62c0]
   3f404:	str	x0, [x1, #0xab8]
   3f408:	ldr	x0, [x19, #0x62c8]
   3f40c:	str	x0, [x1, #0xac0]
   3f410:	ldr	x0, [x19, #0x62d0]
   3f414:	str	x0, [x1, #0xac8]
   3f418:	mov	x0, #0x0
   3f41c:	str	x0, [x1, #0xad0]
   3f420:	ldr	x1, [x19, #0x62e0]
   3f424:	ldr	x2, [sp, #0x1c0]
   3f428:	str	x1, [x2, #0xad8]
   3f42c:	ldr	x1, [x19, #0x62e8]
   3f430:	ldr	x5, [sp, #0x1c0]
   3f434:	str	x1, [x5, #0xae0]
   3f438:	ldr	x6, [sp, #0x1c0]
   3f43c:	str	x0, [x6, #0xae8]
   3f440:	ldr	x1, [x19, #0x62f8]
   3f444:	ldr	x9, [sp, #0x1c0]
   3f448:	str	x1, [x9, #0xaf0]
   3f44c:	ldr	x1, [x19, #0x6300]
   3f450:	ldr	x12, [sp, #0x1c0]
   3f454:	str	x1, [x12, #0xaf8]
   3f458:	ldr	x14, [sp, #0x1c0]
   3f45c:	str	x0, [x14, #0xb00]
   3f460:	ldr	x0, [x19, #0x6310]
   3f464:	ldr	x1, [sp, #0x1c0]
   3f468:	str	x0, [x1, #0xb08]
   3f46c:	ldr	x0, [x19, #0x6318]
   3f470:	str	x0, [x1, #0xb10]
   3f474:	mov	x1, #0x722
   3f478:	mov	x2, #-0x9
   3f47c:	mov	x5, #0x1
   3f480:	ldur	x0, [sp, #0x8]
   3f484:	ldr	x6, [sp, #0x1c8]
   3f488:	ldr	x21, [sp, #0x1d0]
   3f48c:	blr	x21
   3f490:	cmp	x0, #0x0
   3f494:	b.ne	0x428ec
   3f498:	mov	x0, #0x0
   3f49c:	ldur	x1, [sp, #0xe0]
   3f4a0:	add	sp, sp, #0x1e0
   3f4a4:	ldp	x19, x20, [sp], #0x10
   3f4a8:	ldp	x21, x22, [sp], #0x10
   3f4ac:	ldp	x23, x24, [sp], #0x10
   3f4b0:	ldp	x25, x26, [sp], #0x10
   3f4b4:	ldp	x27, x28, [sp], #0x10
   3f4b8:	ldp	x29, x30, [sp], #0x10
   3f4bc:	.long	0xd65f0fff
   3f4c0:	cmp	x14, x12
   3f4c4:	cset	x1, lo
   3f4c8:	mov	x2, #0x1000000000000000
   3f4cc:	ldur	x23, [sp, #0x48]
   3f4d0:	cmp	x23, x2
   3f4d4:	cset	x2, lo
   3f4d8:	and	w1, w1, w2
   3f4dc:	uxtb	w22, w1
   3f4e0:	tbnz	w22, #0x0, 0x3f50c
   3f4e4:	stur	x22, [sp, #0xe0]
   3f4e8:	mov	w1, #0x1706
   3f4ec:	movk	w1, #0x1, lsl #16
   3f4f0:	sub	x3, x3, x1
   3f4f4:	ldur	x1, [sp, #0x40]
   3f4f8:	ldur	x2, [sp, #0x10]
   3f4fc:	ldur	x4, [sp, #0x30]
   3f500:	ldur	x22, [sp, #0x48]
   3f504:	ldur	x23, [sp, #0x38]
   3f508:	b	0x407d4
   3f50c:	stur	x22, [sp, #0xe0]
   3f510:	add	x2, x14, #0x1
   3f514:	cmp	x2, x14
   3f518:	b.lo	0x428f4
   3f51c:	ldr	x23, [sp, #0x190]
   3f520:	cmp	x14, x23
   3f524:	b.lo	0x3f7b0
   3f528:	b	0x42a28
   3f52c:	ldr	x3, [x19, #0x54d8]
   3f530:	ldr	x4, [x19, #0x54e0]
   3f534:	mov	x0, #0x0
   3f538:	str	x0, [x19, #0x54d0]
   3f53c:	mov	x0, #0x3
   3f540:	ldr	x14, [sp, #0x1b8]
   3f544:	mov	x25, x0
   3f548:	cmp	x14, #0x164
   3f54c:	b.lo	0x43b34
   3f550:	ldr	x0, [x19, #0x5818]
   3f554:	ldr	x1, [sp, #0x1c0]
   3f558:	str	x0, [x1, #0x10]
   3f55c:	ldr	x1, [x19, #0x5820]
   3f560:	ldr	x2, [sp, #0x1c0]
   3f564:	str	x1, [x2, #0x18]
   3f568:	ldr	x2, [x19, #0x6238]
   3f56c:	ldr	x5, [sp, #0x1c0]
   3f570:	str	x2, [x5, #0xa30]
   3f574:	ldr	x2, [sp, #0x1c0]
   3f578:	str	x0, [x2, #0x10]
   3f57c:	ldr	x0, [sp, #0x1c0]
   3f580:	str	x1, [x0, #0x18]
   3f584:	ldr	x0, [x19, #0x58f8]
   3f588:	ldr	x1, [sp, #0x1c0]
   3f58c:	str	x0, [x1, #0xf0]
   3f590:	ldr	x0, [x19, #0x5900]
   3f594:	str	x0, [x1, #0xf8]
   3f598:	ldr	x0, [x19, #0x5908]
   3f59c:	str	x0, [x1, #0x100]
   3f5a0:	ldr	x0, [x19, #0x5910]
   3f5a4:	str	x0, [x1, #0x108]
   3f5a8:	ldr	x0, [x19, #0x5918]
   3f5ac:	str	x0, [x1, #0x110]
   3f5b0:	ldr	x0, [x19, #0x5920]
   3f5b4:	str	x0, [x1, #0x118]
   3f5b8:	ldr	x0, [x19, #0x5928]
   3f5bc:	str	x0, [x1, #0x120]
   3f5c0:	ldr	x0, [x19, #0x5930]
   3f5c4:	str	x0, [x1, #0x128]
   3f5c8:	ldr	x0, [x19, #0x5938]
   3f5cc:	str	x0, [x1, #0x130]
   3f5d0:	ldr	x0, [x19, #0x5a70]
   3f5d4:	str	x0, [x5, #0x268]
   3f5d8:	ldr	x0, [x19, #0x5a78]
   3f5dc:	ldr	x6, [sp, #0x1c0]
   3f5e0:	str	x0, [x6, #0x270]
   3f5e4:	ldr	x0, [x19, #0x5a80]
   3f5e8:	ldr	x9, [sp, #0x1c0]
   3f5ec:	str	x0, [x9, #0x278]
   3f5f0:	ldr	x0, [x19, #0x5a88]
   3f5f4:	ldr	x12, [sp, #0x1c0]
   3f5f8:	str	x0, [x12, #0x280]
   3f5fc:	ldr	x0, [x19, #0x5a90]
   3f600:	ldr	x15, [sp, #0x1c0]
   3f604:	str	x0, [x15, #0x288]
   3f608:	ldr	x0, [x19, #0x5a98]
   3f60c:	str	x0, [x1, #0x290]
   3f610:	ldr	x0, [x19, #0x5aa0]
   3f614:	str	x0, [x1, #0x298]
   3f618:	ldr	x0, [x19, #0x5aa8]
   3f61c:	str	x0, [x1, #0x2a0]
   3f620:	ldr	x0, [x19, #0x5ab0]
   3f624:	str	x0, [x1, #0x2a8]
   3f628:	ldr	x0, [x19, #0x5d38]
   3f62c:	str	x0, [x1, #0x530]
   3f630:	ldr	x0, [x19, #0x5d40]
   3f634:	str	x0, [x1, #0x538]
   3f638:	ldr	x0, [x19, #0x5d48]
   3f63c:	str	x0, [x1, #0x540]
   3f640:	ldr	x0, [x19, #0x5d50]
   3f644:	str	x0, [x1, #0x548]
   3f648:	ldr	x0, [x19, #0x5d58]
   3f64c:	str	x0, [x1, #0x550]
   3f650:	ldr	x0, [x19, #0x5d60]
   3f654:	str	x0, [x1, #0x558]
   3f658:	ldr	x0, [x19, #0x5d68]
   3f65c:	str	x0, [x1, #0x560]
   3f660:	ldr	x1, [x19, #0x5d70]
   3f664:	ldr	x0, [sp, #0x1c0]
   3f668:	str	x1, [x0, #0x568]
   3f66c:	ldr	x2, [x19, #0x5e98]
   3f670:	str	x2, [x0, #0x690]
   3f674:	ldr	x5, [x19, #0x5ea0]
   3f678:	str	x5, [x0, #0x698]
   3f67c:	ldr	x5, [x19, #0x5ea8]
   3f680:	str	x5, [x0, #0x6a0]
   3f684:	ldr	x5, [x19, #0x5eb0]
   3f688:	str	x5, [x0, #0x6a8]
   3f68c:	ldr	x6, [x19, #0x5eb8]
   3f690:	ldr	x5, [sp, #0x1c0]
   3f694:	str	x6, [x5, #0x6b0]
   3f698:	ldr	x7, [x19, #0x5ec0]
   3f69c:	ldr	x6, [sp, #0x1c0]
   3f6a0:	str	x7, [x6, #0x6b8]
   3f6a4:	ldr	x8, [x19, #0x5ec8]
   3f6a8:	str	x8, [x9, #0x6c0]
   3f6ac:	ldr	x9, [x19, #0x5ed0]
   3f6b0:	str	x9, [x12, #0x6c8]
   3f6b4:	ldr	x10, [x19, #0x62a8]
   3f6b8:	str	x10, [x15, #0xaa0]
   3f6bc:	ldr	x11, [x19, #0x62b0]
   3f6c0:	str	x11, [x0, #0xaa8]
   3f6c4:	ldr	x12, [x19, #0x62b8]
   3f6c8:	str	x12, [x0, #0xab0]
   3f6cc:	ldr	x13, [x19, #0x62c0]
   3f6d0:	str	x13, [x0, #0xab8]
   3f6d4:	ldr	x14, [x19, #0x62c8]
   3f6d8:	str	x14, [x0, #0xac0]
   3f6dc:	ldr	x15, [x19, #0x62d0]
   3f6e0:	str	x15, [x0, #0xac8]
   3f6e4:	mov	x0, #0x0
   3f6e8:	ldr	x1, [sp, #0x1c0]
   3f6ec:	str	x0, [x1, #0xad0]
   3f6f0:	ldr	x1, [x19, #0x62e0]
   3f6f4:	ldr	x2, [sp, #0x1c0]
   3f6f8:	str	x1, [x2, #0xad8]
   3f6fc:	ldr	x1, [x19, #0x62e8]
   3f700:	str	x1, [x2, #0xae0]
   3f704:	ldr	x1, [sp, #0x1c0]
   3f708:	str	x0, [x1, #0xae8]
   3f70c:	ldr	x1, [x19, #0x62f8]
   3f710:	str	x1, [x2, #0xaf0]
   3f714:	ldr	x1, [x19, #0x6300]
   3f718:	str	x1, [x2, #0xaf8]
   3f71c:	ldr	x1, [sp, #0x1c0]
   3f720:	str	x0, [x1, #0xb00]
   3f724:	ldr	x0, [x19, #0x6310]
   3f728:	str	x0, [x1, #0xb08]
   3f72c:	ldr	x0, [x19, #0x6318]
   3f730:	str	x0, [x1, #0xb10]
   3f734:	mov	x1, #0x738
   3f738:	mov	x2, #-0x9
   3f73c:	ldr	x21, [sp, #0x1d0]
   3f740:	ldur	x0, [sp, #0x8]
   3f744:	mov	x5, x20
   3f748:	ldr	x6, [sp, #0x1c8]
   3f74c:	blr	x21
   3f750:	cmp	x0, #0x0
   3f754:	b.ne	0x42ba0
   3f758:	mov	x0, #0x3
   3f75c:	ldr	x14, [sp, #0x1b8]
   3f760:	mov	x25, x0
   3f764:	cmp	x14, #0x2
   3f768:	b.lo	0x43b34
   3f76c:	mov	x5, #0x0
   3f770:	ldr	x3, [sp, #0x1c0]
   3f774:	str	x5, [x3]
   3f778:	ldr	x0, [x19, #0x2620]
   3f77c:	str	x0, [x3, #0x8]
   3f780:	mov	x1, #0x738
   3f784:	ldur	x0, [sp, #0x8]
   3f788:	ldr	x6, [sp, #0x1c8]
   3f78c:	ldr	x21, [sp, #0x1d0]
   3f790:	mov	x4, x20
   3f794:	mov	x2, x5
   3f798:	blr	x21
   3f79c:	cmp	x0, #0x0
   3f7a0:	b.ne	0x42ba8
   3f7a4:	mov	x0, #0x3
   3f7a8:	mov	x25, x0
   3f7ac:	b	0x43b34
   3f7b0:	ldr	x23, [sp, #0x198]
   3f7b4:	ldr	x1, [x23, x14, lsl #3]
   3f7b8:	add	x4, x1, #0x1
   3f7bc:	cmp	x4, x1
   3f7c0:	b.lo	0x42bb0
   3f7c4:	ldr	x23, [sp, #0x180]
   3f7c8:	cmp	x1, x23
   3f7cc:	b.lo	0x3fa4c
   3f7d0:	b	0x42cec
   3f7d4:	ldr	x3, [x19, #0x54d8]
   3f7d8:	ldr	x4, [x19, #0x54e0]
   3f7dc:	mov	x13, #0x0
   3f7e0:	str	x13, [x19, #0x54d0]
   3f7e4:	mov	x0, #0x3
   3f7e8:	ldr	x14, [sp, #0x1b8]
   3f7ec:	mov	x25, x0
   3f7f0:	cmp	x14, #0x164
   3f7f4:	b.lo	0x43b34
   3f7f8:	ldr	x0, [x19, #0x5818]
   3f7fc:	ldr	x1, [sp, #0x1c0]
   3f800:	str	x0, [x1, #0x10]
   3f804:	ldr	x1, [x19, #0x5820]
   3f808:	ldr	x2, [sp, #0x1c0]
   3f80c:	str	x1, [x2, #0x18]
   3f810:	ldr	x2, [x19, #0x6238]
   3f814:	ldr	x5, [sp, #0x1c0]
   3f818:	str	x2, [x5, #0xa30]
   3f81c:	ldr	x2, [sp, #0x1c0]
   3f820:	str	x0, [x2, #0x10]
   3f824:	ldr	x0, [sp, #0x1c0]
   3f828:	str	x1, [x0, #0x18]
   3f82c:	ldr	x0, [x19, #0x58f8]
   3f830:	ldr	x1, [sp, #0x1c0]
   3f834:	str	x0, [x1, #0xf0]
   3f838:	ldr	x0, [x19, #0x5900]
   3f83c:	str	x0, [x5, #0xf8]
   3f840:	ldr	x0, [x19, #0x5908]
   3f844:	ldr	x6, [sp, #0x1c0]
   3f848:	str	x0, [x6, #0x100]
   3f84c:	ldr	x0, [x19, #0x5910]
   3f850:	ldr	x9, [sp, #0x1c0]
   3f854:	str	x0, [x9, #0x108]
   3f858:	ldr	x0, [x19, #0x5918]
   3f85c:	ldr	x12, [sp, #0x1c0]
   3f860:	str	x0, [x12, #0x110]
   3f864:	ldr	x0, [x19, #0x5920]
   3f868:	ldr	x15, [sp, #0x1c0]
   3f86c:	str	x0, [x15, #0x118]
   3f870:	ldr	x0, [x19, #0x5928]
   3f874:	str	x0, [x1, #0x120]
   3f878:	ldr	x0, [x19, #0x5930]
   3f87c:	str	x0, [x1, #0x128]
   3f880:	ldr	x0, [x19, #0x5938]
   3f884:	str	x0, [x1, #0x130]
   3f888:	ldr	x0, [x19, #0x5a70]
   3f88c:	str	x0, [x1, #0x268]
   3f890:	ldr	x0, [x19, #0x5a78]
   3f894:	str	x0, [x1, #0x270]
   3f898:	ldr	x0, [x19, #0x5a80]
   3f89c:	str	x0, [x1, #0x278]
   3f8a0:	ldr	x0, [x19, #0x5a88]
   3f8a4:	str	x0, [x1, #0x280]
   3f8a8:	ldr	x0, [x19, #0x5a90]
   3f8ac:	str	x0, [x1, #0x288]
   3f8b0:	ldr	x0, [x19, #0x5a98]
   3f8b4:	str	x0, [x1, #0x290]
   3f8b8:	ldr	x0, [x19, #0x5aa0]
   3f8bc:	str	x0, [x1, #0x298]
   3f8c0:	ldr	x0, [x19, #0x5aa8]
   3f8c4:	str	x0, [x1, #0x2a0]
   3f8c8:	ldr	x0, [x19, #0x5ab0]
   3f8cc:	str	x0, [x1, #0x2a8]
   3f8d0:	ldr	x0, [x19, #0x5d38]
   3f8d4:	str	x0, [x1, #0x530]
   3f8d8:	ldr	x0, [x19, #0x5d40]
   3f8dc:	str	x0, [x1, #0x538]
   3f8e0:	ldr	x0, [x19, #0x5d48]
   3f8e4:	str	x0, [x1, #0x540]
   3f8e8:	ldr	x0, [x19, #0x5d50]
   3f8ec:	str	x0, [x1, #0x548]
   3f8f0:	ldr	x0, [x19, #0x5d58]
   3f8f4:	str	x0, [x5, #0x550]
   3f8f8:	ldr	x0, [x19, #0x5d60]
   3f8fc:	str	x0, [x6, #0x558]
   3f900:	ldr	x0, [x19, #0x5d68]
   3f904:	str	x0, [x9, #0x560]
   3f908:	ldr	x0, [x19, #0x5d70]
   3f90c:	str	x0, [x12, #0x568]
   3f910:	ldr	x0, [x19, #0x5e98]
   3f914:	str	x0, [x15, #0x690]
   3f918:	ldr	x0, [x19, #0x5ea0]
   3f91c:	str	x0, [x1, #0x698]
   3f920:	ldr	x0, [x19, #0x5ea8]
   3f924:	str	x0, [x1, #0x6a0]
   3f928:	ldr	x0, [x19, #0x5eb0]
   3f92c:	str	x0, [x1, #0x6a8]
   3f930:	ldr	x0, [x19, #0x5eb8]
   3f934:	str	x0, [x1, #0x6b0]
   3f938:	ldr	x0, [x19, #0x5ec0]
   3f93c:	str	x0, [x1, #0x6b8]
   3f940:	ldr	x0, [x19, #0x5ec8]
   3f944:	str	x0, [x1, #0x6c0]
   3f948:	ldr	x0, [x19, #0x5ed0]
   3f94c:	str	x0, [x1, #0x6c8]
   3f950:	ldr	x0, [x19, #0x62a8]
   3f954:	str	x0, [x1, #0xaa0]
   3f958:	ldr	x0, [x19, #0x62b0]
   3f95c:	str	x0, [x1, #0xaa8]
   3f960:	ldr	x0, [x19, #0x62b8]
   3f964:	str	x0, [x1, #0xab0]
   3f968:	ldr	x0, [x19, #0x62c0]
   3f96c:	str	x0, [x1, #0xab8]
   3f970:	ldr	x0, [x19, #0x62c8]
   3f974:	str	x0, [x1, #0xac0]
   3f978:	ldr	x0, [x19, #0x62d0]
   3f97c:	str	x0, [x1, #0xac8]
   3f980:	mov	x0, #0x0
   3f984:	str	x0, [x1, #0xad0]
   3f988:	ldr	x1, [x19, #0x62e0]
   3f98c:	str	x1, [x2, #0xad8]
   3f990:	ldr	x1, [x19, #0x62e8]
   3f994:	str	x1, [x2, #0xae0]
   3f998:	str	x0, [x2, #0xae8]
   3f99c:	ldr	x5, [x19, #0x62f8]
   3f9a0:	str	x5, [x6, #0xaf0]
   3f9a4:	ldr	x5, [x19, #0x6300]
   3f9a8:	ldr	x8, [sp, #0x1c0]
   3f9ac:	str	x5, [x8, #0xaf8]
   3f9b0:	ldr	x10, [sp, #0x1c0]
   3f9b4:	str	x0, [x10, #0xb00]
   3f9b8:	ldr	x6, [x19, #0x6310]
   3f9bc:	ldr	x13, [sp, #0x1c0]
   3f9c0:	str	x6, [x13, #0xb08]
   3f9c4:	ldr	x7, [x19, #0x6318]
   3f9c8:	ldr	x0, [sp, #0x1c0]
   3f9cc:	str	x7, [x0, #0xb10]
   3f9d0:	mov	x1, #0x73a
   3f9d4:	mov	x2, #-0x9
   3f9d8:	ldr	x21, [sp, #0x1d0]
   3f9dc:	ldur	x0, [sp, #0x8]
   3f9e0:	mov	x5, x28
   3f9e4:	ldr	x6, [sp, #0x1c8]
   3f9e8:	blr	x21
   3f9ec:	cmp	x0, #0x0
   3f9f0:	b.ne	0x42e68
   3f9f4:	mov	x0, #0x3
   3f9f8:	ldr	x14, [sp, #0x1b8]
   3f9fc:	mov	x25, x0
   3fa00:	cmp	x14, #0x2
   3fa04:	b.lo	0x43b34
   3fa08:	mov	x5, #0x0
   3fa0c:	ldr	x3, [sp, #0x1c0]
   3fa10:	str	x5, [x3]
   3fa14:	ldr	x0, [x19, #0x2630]
   3fa18:	str	x0, [x3, #0x8]
   3fa1c:	mov	x1, #0x73a
   3fa20:	ldur	x0, [sp, #0x8]
   3fa24:	ldr	x6, [sp, #0x1c8]
   3fa28:	ldr	x21, [sp, #0x1d0]
   3fa2c:	mov	x4, x28
   3fa30:	mov	x2, x5
   3fa34:	blr	x21
   3fa38:	cmp	x0, #0x0
   3fa3c:	b.ne	0x42e70
   3fa40:	mov	x0, #0x3
   3fa44:	mov	x25, x0
   3fa48:	b	0x43b34
   3fa4c:	ldr	x23, [sp, #0x188]
   3fa50:	ldr	x11, [x23, x1, lsl #3]
   3fa54:	ldr	x23, [sp, #0x180]
   3fa58:	cmp	x4, x23
   3fa5c:	b.lo	0x3fccc
   3fa60:	b	0x42e78
   3fa64:	ldr	x3, [x19, #0x54d8]
   3fa68:	ldr	x4, [x19, #0x54e0]
   3fa6c:	mov	x0, #0x0
   3fa70:	str	x0, [x19, #0x54d0]
   3fa74:	mov	x0, #0x3
   3fa78:	ldr	x14, [sp, #0x1b8]
   3fa7c:	mov	x25, x0
   3fa80:	cmp	x14, #0x164
   3fa84:	b.lo	0x43b34
   3fa88:	ldr	x0, [x19, #0x5818]
   3fa8c:	ldr	x10, [sp, #0x1c0]
   3fa90:	str	x0, [x10, #0x10]
   3fa94:	ldr	x1, [x19, #0x5820]
   3fa98:	ldr	x13, [sp, #0x1c0]
   3fa9c:	str	x1, [x13, #0x18]
   3faa0:	ldr	x2, [x19, #0x6238]
   3faa4:	ldr	x5, [sp, #0x1c0]
   3faa8:	str	x2, [x5, #0xa30]
   3faac:	ldr	x2, [sp, #0x1c0]
   3fab0:	str	x0, [x2, #0x10]
   3fab4:	ldr	x0, [sp, #0x1c0]
   3fab8:	str	x1, [x0, #0x18]
   3fabc:	ldr	x0, [x19, #0x58f8]
   3fac0:	ldr	x1, [sp, #0x1c0]
   3fac4:	str	x0, [x1, #0xf0]
   3fac8:	ldr	x0, [x19, #0x5900]
   3facc:	str	x0, [x1, #0xf8]
   3fad0:	ldr	x0, [x19, #0x5908]
   3fad4:	str	x0, [x1, #0x100]
   3fad8:	ldr	x0, [x19, #0x5910]
   3fadc:	str	x0, [x1, #0x108]
   3fae0:	ldr	x0, [x19, #0x5918]
   3fae4:	str	x0, [x1, #0x110]
   3fae8:	ldr	x0, [x19, #0x5920]
   3faec:	str	x0, [x1, #0x118]
   3faf0:	ldr	x0, [x19, #0x5928]
   3faf4:	str	x0, [x1, #0x120]
   3faf8:	ldr	x0, [x19, #0x5930]
   3fafc:	str	x0, [x1, #0x128]
   3fb00:	ldr	x0, [x19, #0x5938]
   3fb04:	str	x0, [x1, #0x130]
   3fb08:	ldr	x0, [x19, #0x5a70]
   3fb0c:	str	x0, [x1, #0x268]
   3fb10:	ldr	x0, [x19, #0x5a78]
   3fb14:	str	x0, [x1, #0x270]
   3fb18:	ldr	x0, [x19, #0x5a80]
   3fb1c:	str	x0, [x1, #0x278]
   3fb20:	ldr	x0, [x19, #0x5a88]
   3fb24:	str	x0, [x1, #0x280]
   3fb28:	ldr	x0, [x19, #0x5a90]
   3fb2c:	str	x0, [x1, #0x288]
   3fb30:	ldr	x0, [x19, #0x5a98]
   3fb34:	str	x0, [x2, #0x290]
   3fb38:	ldr	x0, [x19, #0x5aa0]
   3fb3c:	str	x0, [x5, #0x298]
   3fb40:	ldr	x0, [x19, #0x5aa8]
   3fb44:	ldr	x8, [sp, #0x1c0]
   3fb48:	str	x0, [x8, #0x2a0]
   3fb4c:	ldr	x0, [x19, #0x5ab0]
   3fb50:	ldr	x11, [sp, #0x1c0]
   3fb54:	str	x0, [x11, #0x2a8]
   3fb58:	ldr	x0, [x19, #0x5d38]
   3fb5c:	ldr	x14, [sp, #0x1c0]
   3fb60:	str	x0, [x14, #0x530]
   3fb64:	ldr	x0, [x19, #0x5d40]
   3fb68:	str	x0, [x1, #0x538]
   3fb6c:	ldr	x0, [x19, #0x5d48]
   3fb70:	str	x0, [x1, #0x540]
   3fb74:	ldr	x0, [x19, #0x5d50]
   3fb78:	str	x0, [x1, #0x548]
   3fb7c:	ldr	x0, [x19, #0x5d58]
   3fb80:	str	x0, [x1, #0x550]
   3fb84:	ldr	x0, [x19, #0x5d60]
   3fb88:	str	x0, [x1, #0x558]
   3fb8c:	ldr	x0, [x19, #0x5d68]
   3fb90:	str	x0, [x1, #0x560]
   3fb94:	ldr	x0, [x19, #0x5d70]
   3fb98:	str	x0, [x1, #0x568]
   3fb9c:	ldr	x0, [x19, #0x5e98]
   3fba0:	str	x0, [x1, #0x690]
   3fba4:	ldr	x0, [x19, #0x5ea0]
   3fba8:	str	x0, [x1, #0x698]
   3fbac:	ldr	x0, [x19, #0x5ea8]
   3fbb0:	str	x0, [x1, #0x6a0]
   3fbb4:	ldr	x0, [x19, #0x5eb0]
   3fbb8:	str	x0, [x1, #0x6a8]
   3fbbc:	ldr	x0, [x19, #0x5eb8]
   3fbc0:	str	x0, [x1, #0x6b0]
   3fbc4:	ldr	x0, [x19, #0x5ec0]
   3fbc8:	str	x0, [x1, #0x6b8]
   3fbcc:	ldr	x0, [x19, #0x5ec8]
   3fbd0:	str	x0, [x1, #0x6c0]
   3fbd4:	ldr	x0, [x19, #0x5ed0]
   3fbd8:	str	x0, [x1, #0x6c8]
   3fbdc:	ldr	x0, [x19, #0x62a8]
   3fbe0:	str	x0, [x1, #0xaa0]
   3fbe4:	ldr	x0, [x19, #0x62b0]
   3fbe8:	str	x0, [x2, #0xaa8]
   3fbec:	ldr	x0, [x19, #0x62b8]
   3fbf0:	str	x0, [x5, #0xab0]
   3fbf4:	ldr	x0, [x19, #0x62c0]
   3fbf8:	str	x0, [x8, #0xab8]
   3fbfc:	ldr	x1, [x19, #0x62c8]
   3fc00:	str	x1, [x11, #0xac0]
   3fc04:	ldr	x2, [x19, #0x62d0]
   3fc08:	str	x2, [x14, #0xac8]
   3fc0c:	mov	x5, #0x0
   3fc10:	ldr	x0, [sp, #0x1c0]
   3fc14:	str	x5, [x0, #0xad0]
   3fc18:	ldr	x6, [x19, #0x62e0]
   3fc1c:	str	x6, [x0, #0xad8]
   3fc20:	ldr	x6, [x19, #0x62e8]
   3fc24:	str	x6, [x0, #0xae0]
   3fc28:	str	x5, [x0, #0xae8]
   3fc2c:	ldr	x7, [x19, #0x62f8]
   3fc30:	str	x7, [x0, #0xaf0]
   3fc34:	ldr	x8, [x19, #0x6300]
   3fc38:	str	x8, [x0, #0xaf8]
   3fc3c:	str	x5, [x0, #0xb00]
   3fc40:	ldr	x10, [x19, #0x6310]
   3fc44:	str	x10, [x0, #0xb08]
   3fc48:	ldr	x11, [x19, #0x6318]
   3fc4c:	str	x11, [x0, #0xb10]
   3fc50:	mov	x1, #0x73c
   3fc54:	mov	x2, #-0x9
   3fc58:	ldr	x21, [sp, #0x1d0]
   3fc5c:	ldur	x0, [sp, #0x8]
   3fc60:	mov	x5, x20
   3fc64:	ldr	x6, [sp, #0x1c8]
   3fc68:	blr	x21
   3fc6c:	cmp	x0, #0x0
   3fc70:	b.ne	0x42ff8
   3fc74:	mov	x0, #0x3
   3fc78:	ldr	x14, [sp, #0x1b8]
   3fc7c:	mov	x25, x0
   3fc80:	cmp	x14, #0x2
   3fc84:	b.lo	0x43b34
   3fc88:	mov	x5, #0x0
   3fc8c:	ldr	x3, [sp, #0x1c0]
   3fc90:	str	x5, [x3]
   3fc94:	ldr	x0, [x19, #0x2640]
   3fc98:	str	x0, [x3, #0x8]
   3fc9c:	mov	x1, #0x73c
   3fca0:	ldur	x0, [sp, #0x8]
   3fca4:	ldr	x6, [sp, #0x1c8]
   3fca8:	ldr	x21, [sp, #0x1d0]
   3fcac:	mov	x4, x20
   3fcb0:	mov	x2, x5
   3fcb4:	blr	x21
   3fcb8:	cmp	x0, #0x0
   3fcbc:	b.ne	0x43000
   3fcc0:	mov	x0, #0x3
   3fcc4:	mov	x25, x0
   3fcc8:	b	0x43b34
   3fccc:	ldr	x23, [sp, #0x188]
   3fcd0:	ldr	x7, [x23, x4, lsl #3]
   3fcd4:	mov	w1, #0x1706
   3fcd8:	movk	w1, #0x1, lsl #16
   3fcdc:	sub	x6, x3, x1
   3fce0:	mov	x9, #0x0
   3fce4:	stur	x9, [sp, #0xa8]
   3fce8:	mov	x24, #0x2
   3fcec:	stur	x24, [sp, #0xd8]
   3fcf0:	mov	x28, #0x3ffffffffffffff
   3fcf4:	ldr	x23, [sp, #0x170]
   3fcf8:	stur	x28, [sp, #0xd0]
   3fcfc:	cmp	x23, x7
   3fd00:	b.lo	0x3fd20
   3fd04:	ldur	x1, [sp, #0x40]
   3fd08:	ldur	x2, [sp, #0x10]
   3fd0c:	ldur	x4, [sp, #0x30]
   3fd10:	ldur	x22, [sp, #0x48]
   3fd14:	ldur	x23, [sp, #0x38]
   3fd18:	ldur	x27, [sp, #0xa8]
   3fd1c:	b	0x401e0
   3fd20:	ldur	x1, [sp, #0x40]
   3fd24:	ldur	x2, [sp, #0x10]
   3fd28:	ldur	x4, [sp, #0x30]
   3fd2c:	ldur	x23, [sp, #0x38]
   3fd30:	ldur	x3, [sp, #0x48]
   3fd34:	stur	x3, [sp, #0xb0]
   3fd38:	mov	w3, #0xccd6
   3fd3c:	movk	w3, #0x2, lsl #16
   3fd40:	cmp	x6, x3
   3fd44:	cset	x3, hs
   3fd48:	and	w3, w3, w5
   3fd4c:	uxtb	w3, w3
   3fd50:	cbz	x3, 0x43008
   3fd54:	b	0x3fe00
   3fd58:	ldur	x5, [sp, #0xc8]
   3fd5c:	ldur	x8, [sp, #0x48]
   3fd60:	mov	x10, x14
   3fd64:	ldur	x13, [sp, #0x40]
   3fd68:	ldur	x20, [sp, #0x38]
   3fd6c:	ldur	x21, [sp, #0x30]
   3fd70:	ldur	x22, [sp, #0xb0]
   3fd74:	ldur	x24, [sp, #0xc8]
   3fd78:	ldur	x25, [sp, #0x10]
   3fd7c:	ldur	x26, [sp, #0xc8]
   3fd80:	ldur	x27, [sp, #0xa8]
   3fd84:	ldur	x28, [sp, #0xc8]
   3fd88:	b	0x40294
   3fd8c:	ldur	x3, [sp, #0x60]
   3fd90:	mov	x9, x6
   3fd94:	b	0x3fdc0
   3fd98:	mov	w3, #0x1
   3fd9c:	cmp	x11, x7
   3fda0:	ldur	x28, [sp, #0xe8]
   3fda4:	csel	x8, x28, x3, hs
   3fda8:	ldur	x3, [sp, #0x60]
   3fdac:	mov	x9, x6
   3fdb0:	b	0x3fdc0
   3fdb4:	ldur	x3, [sp, #0x60]
   3fdb8:	ldur	x8, [sp, #0xe8]
   3fdbc:	mov	x9, x6
   3fdc0:	tbnz	w8, #0x0, 0x3fe00
   3fdc4:	ldur	x5, [sp, #0xc8]
   3fdc8:	mov	x6, x9
   3fdcc:	ldur	x8, [sp, #0x48]
   3fdd0:	mov	x10, x14
   3fdd4:	ldur	x13, [sp, #0x40]
   3fdd8:	ldur	x20, [sp, #0x38]
   3fddc:	ldur	x21, [sp, #0x30]
   3fde0:	ldur	x22, [sp, #0xb0]
   3fde4:	ldur	x24, [sp, #0xc8]
   3fde8:	ldur	x25, [sp, #0x10]
   3fdec:	ldur	x26, [sp, #0xc8]
   3fdf0:	ldur	x27, [sp, #0xa8]
   3fdf4:	ldur	x28, [sp, #0xc8]
   3fdf8:	stur	x3, [sp, #0x60]
   3fdfc:	b	0x40294
   3fe00:	cmp	x11, x7
   3fe04:	cset	x21, lo
   3fe08:	cmp	x11, x7
   3fe0c:	b.lo	0x3fe1c
   3fe10:	mov	x20, #0x0
   3fe14:	ldur	x22, [sp, #0xb0]
   3fe18:	b	0x400a0
   3fe1c:	ldr	x3, [sp, #0x170]
   3fe20:	cmp	x11, x3
   3fe24:	b.lo	0x40090
   3fe28:	b	0x43050
   3fe2c:	ldr	x3, [x19, #0x54d8]
   3fe30:	ldr	x4, [x19, #0x54e0]
   3fe34:	mov	x9, #0x0
   3fe38:	str	x9, [x19, #0x54d0]
   3fe3c:	mov	x0, #0x3
   3fe40:	ldr	x14, [sp, #0x1b8]
   3fe44:	mov	x25, x0
   3fe48:	cmp	x14, #0x164
   3fe4c:	b.lo	0x43b34
   3fe50:	ldr	x13, [x19, #0x5818]
   3fe54:	ldr	x0, [sp, #0x1c0]
   3fe58:	str	x13, [x0, #0x10]
   3fe5c:	ldr	x14, [x19, #0x5820]
   3fe60:	str	x14, [x0, #0x18]
   3fe64:	ldr	x15, [x19, #0x6238]
   3fe68:	str	x15, [x0, #0xa30]
   3fe6c:	str	x13, [x0, #0x10]
   3fe70:	str	x14, [x0, #0x18]
   3fe74:	ldr	x0, [x19, #0x58f8]
   3fe78:	ldr	x1, [sp, #0x1c0]
   3fe7c:	str	x0, [x1, #0xf0]
   3fe80:	ldr	x0, [x19, #0x5900]
   3fe84:	str	x0, [x1, #0xf8]
   3fe88:	ldr	x0, [x19, #0x5908]
   3fe8c:	str	x0, [x1, #0x100]
   3fe90:	ldr	x0, [x19, #0x5910]
   3fe94:	str	x0, [x1, #0x108]
   3fe98:	ldr	x0, [x19, #0x5918]
   3fe9c:	ldr	x5, [sp, #0x1c0]
   3fea0:	str	x0, [x5, #0x110]
   3fea4:	ldr	x0, [x19, #0x5920]
   3fea8:	ldr	x7, [sp, #0x1c0]
   3feac:	str	x0, [x7, #0x118]
   3feb0:	ldr	x0, [x19, #0x5928]
   3feb4:	ldr	x10, [sp, #0x1c0]
   3feb8:	str	x0, [x10, #0x120]
   3febc:	ldr	x0, [x19, #0x5930]
   3fec0:	ldr	x13, [sp, #0x1c0]
   3fec4:	str	x0, [x13, #0x128]
   3fec8:	ldr	x0, [x19, #0x5938]
   3fecc:	str	x0, [x1, #0x130]
   3fed0:	ldr	x0, [x19, #0x5a70]
   3fed4:	str	x0, [x1, #0x268]
   3fed8:	ldr	x0, [x19, #0x5a78]
   3fedc:	str	x0, [x1, #0x270]
   3fee0:	ldr	x0, [x19, #0x5a80]
   3fee4:	str	x0, [x1, #0x278]
   3fee8:	ldr	x0, [x19, #0x5a88]
   3feec:	str	x0, [x1, #0x280]
   3fef0:	ldr	x0, [x19, #0x5a90]
   3fef4:	str	x0, [x1, #0x288]
   3fef8:	ldr	x0, [x19, #0x5a98]
   3fefc:	str	x0, [x1, #0x290]
   3ff00:	ldr	x0, [x19, #0x5aa0]
   3ff04:	str	x0, [x1, #0x298]
   3ff08:	ldr	x0, [x19, #0x5aa8]
   3ff0c:	str	x0, [x1, #0x2a0]
   3ff10:	ldr	x0, [x19, #0x5ab0]
   3ff14:	str	x0, [x1, #0x2a8]
   3ff18:	ldr	x0, [x19, #0x5d38]
   3ff1c:	str	x0, [x1, #0x530]
   3ff20:	ldr	x0, [x19, #0x5d40]
   3ff24:	str	x0, [x1, #0x538]
   3ff28:	ldr	x0, [x19, #0x5d48]
   3ff2c:	str	x0, [x1, #0x540]
   3ff30:	ldr	x0, [x19, #0x5d50]
   3ff34:	str	x0, [x1, #0x548]
   3ff38:	ldr	x0, [x19, #0x5d58]
   3ff3c:	str	x0, [x1, #0x550]
   3ff40:	ldr	x0, [x19, #0x5d60]
   3ff44:	str	x0, [x1, #0x558]
   3ff48:	ldr	x0, [x19, #0x5d68]
   3ff4c:	str	x0, [x1, #0x560]
   3ff50:	ldr	x0, [x19, #0x5d70]
   3ff54:	str	x0, [x5, #0x568]
   3ff58:	ldr	x0, [x19, #0x5e98]
   3ff5c:	str	x0, [x7, #0x690]
   3ff60:	ldr	x0, [x19, #0x5ea0]
   3ff64:	str	x0, [x10, #0x698]
   3ff68:	ldr	x0, [x19, #0x5ea8]
   3ff6c:	str	x0, [x13, #0x6a0]
   3ff70:	ldr	x0, [x19, #0x5eb0]
   3ff74:	str	x0, [x1, #0x6a8]
   3ff78:	ldr	x0, [x19, #0x5eb8]
   3ff7c:	str	x0, [x1, #0x6b0]
   3ff80:	ldr	x0, [x19, #0x5ec0]
   3ff84:	str	x0, [x1, #0x6b8]
   3ff88:	ldr	x0, [x19, #0x5ec8]
   3ff8c:	str	x0, [x1, #0x6c0]
   3ff90:	ldr	x0, [x19, #0x5ed0]
   3ff94:	str	x0, [x1, #0x6c8]
   3ff98:	ldr	x0, [x19, #0x62a8]
   3ff9c:	str	x0, [x1, #0xaa0]
   3ffa0:	ldr	x0, [x19, #0x62b0]
   3ffa4:	str	x0, [x1, #0xaa8]
   3ffa8:	ldr	x0, [x19, #0x62b8]
   3ffac:	str	x0, [x1, #0xab0]
   3ffb0:	ldr	x0, [x19, #0x62c0]
   3ffb4:	str	x0, [x1, #0xab8]
   3ffb8:	ldr	x0, [x19, #0x62c8]
   3ffbc:	str	x0, [x1, #0xac0]
   3ffc0:	ldr	x0, [x19, #0x62d0]
   3ffc4:	str	x0, [x1, #0xac8]
   3ffc8:	mov	x0, #0x0
   3ffcc:	str	x0, [x1, #0xad0]
   3ffd0:	ldr	x1, [x19, #0x62e0]
   3ffd4:	ldr	x2, [sp, #0x1c0]
   3ffd8:	str	x1, [x2, #0xad8]
   3ffdc:	ldr	x1, [x19, #0x62e8]
   3ffe0:	str	x1, [x2, #0xae0]
   3ffe4:	ldr	x1, [sp, #0x1c0]
   3ffe8:	str	x0, [x1, #0xae8]
   3ffec:	ldr	x1, [x19, #0x62f8]
   3fff0:	str	x1, [x2, #0xaf0]
   3fff4:	ldr	x1, [x19, #0x6300]
   3fff8:	str	x1, [x2, #0xaf8]
   3fffc:	str	x0, [x2, #0xb00]
   40000:	ldr	x2, [x19, #0x6310]
   40004:	str	x2, [x5, #0xb08]
   40008:	ldr	x5, [x19, #0x6318]
   4000c:	ldr	x8, [sp, #0x1c0]
   40010:	str	x5, [x8, #0xb10]
   40014:	mov	x1, #0x750
   40018:	mov	x2, #-0x9
   4001c:	ldr	x21, [sp, #0x1d0]
   40020:	ldur	x0, [sp, #0x8]
   40024:	mov	x5, x20
   40028:	ldr	x6, [sp, #0x1c8]
   4002c:	blr	x21
   40030:	cmp	x0, #0x0
   40034:	b.ne	0x4321c
   40038:	mov	x0, #0x3
   4003c:	ldr	x14, [sp, #0x1b8]
   40040:	mov	x25, x0
   40044:	cmp	x14, #0x2
   40048:	b.lo	0x43b34
   4004c:	mov	x5, #0x0
   40050:	ldr	x3, [sp, #0x1c0]
   40054:	str	x5, [x3]
   40058:	ldr	x12, [x19, #0x26b0]
   4005c:	str	x12, [x3, #0x8]
   40060:	mov	x1, #0x750
   40064:	ldur	x0, [sp, #0x8]
   40068:	ldr	x6, [sp, #0x1c8]
   4006c:	ldr	x21, [sp, #0x1d0]
   40070:	mov	x4, x20
   40074:	mov	x2, x5
   40078:	blr	x21
   4007c:	cmp	x0, #0x0
   40080:	b.ne	0x43224
   40084:	mov	x0, #0x3
   40088:	mov	x25, x0
   4008c:	b	0x43b34
   40090:	ldr	x8, [sp, #0x178]
   40094:	ldur	x22, [sp, #0xb0]
   40098:	ldr	w3, [x8, x11, lsl #2]
   4009c:	mov	w20, w3
   400a0:	mov	x28, #0x3ffffffffffffff
   400a4:	eor	x3, x20, #0x3ffffffffffffff
   400a8:	orr	x8, x3, #0xc00000000000000
   400ac:	cmp	x8, x22
   400b0:	cset	x8, hi
   400b4:	and	w8, w21, w8
   400b8:	uxtb	w8, w8
   400bc:	tbnz	w8, #0x0, 0x400d8
   400c0:	mov	x3, x2
   400c4:	mov	x10, x4
   400c8:	mov	x20, x1
   400cc:	mov	x21, x22
   400d0:	mov	x24, x23
   400d4:	b	0x40190
   400d8:	ldur	x9, [sp, #0xc8]
   400dc:	cmp	x20, x9
   400e0:	b.ne	0x400fc
   400e4:	mov	x3, x2
   400e8:	mov	x10, x4
   400ec:	mov	x20, x1
   400f0:	mov	x21, x22
   400f4:	mov	x24, x23
   400f8:	b	0x40190
   400fc:	and	x21, x2, #0x3ffffffffffffff
   40100:	eor	x10, x20, #0x3ffffffffffffff
   40104:	cmp	x10, x21
   40108:	cset	x20, ne
   4010c:	and	x9, x4, #0x3ffffffffffffff
   40110:	cmp	x10, x9
   40114:	cset	x9, ne
   40118:	and	w20, w20, w9
   4011c:	and	x9, x23, #0x3ffffffffffffff
   40120:	cmp	x10, x9
   40124:	cset	x9, ne
   40128:	and	w20, w20, w9
   4012c:	and	x9, x1, #0x3ffffffffffffff
   40130:	cmp	x10, x9
   40134:	cset	x9, ne
   40138:	and	w9, w20, w9
   4013c:	uxtb	w9, w9
   40140:	tbnz	w9, #0x0, 0x4015c
   40144:	mov	x3, x2
   40148:	mov	x10, x4
   4014c:	mov	x20, x1
   40150:	mov	x21, x22
   40154:	mov	x24, x23
   40158:	b	0x40190
   4015c:	orr	x10, x3, #0xc00000000000000
   40160:	cmp	x10, x2
   40164:	csel	x3, x10, x2, hi
   40168:	csel	x20, x10, x2, lo
   4016c:	cmp	x20, x4
   40170:	csel	x10, x20, x4, hi
   40174:	csel	x20, x20, x4, lo
   40178:	cmp	x20, x23
   4017c:	csel	x24, x20, x23, hi
   40180:	csel	x21, x20, x23, lo
   40184:	cmp	x21, x1
   40188:	csel	x20, x21, x1, hi
   4018c:	csel	x21, x21, x1, lo
   40190:	tbnz	w8, #0x0, 0x401a4
   40194:	mov	w3, #0xccd6
   40198:	movk	w3, #0x2, lsl #16
   4019c:	sub	x3, x6, x3
   401a0:	b	0x407c8
   401a4:	add	x1, x11, #0x1
   401a8:	cmp	x1, x11
   401ac:	b.lo	0x4322c
   401b0:	mov	w2, #0xccd6
   401b4:	movk	w2, #0x2, lsl #16
   401b8:	sub	x6, x6, x2
   401bc:	mov	x27, #0x1
   401c0:	stur	x21, [sp, #0xb0]
   401c4:	stur	x27, [sp, #0xa8]
   401c8:	mov	x23, x24
   401cc:	mov	x11, x1
   401d0:	mov	x4, x10
   401d4:	mov	x2, x3
   401d8:	mov	x1, x20
   401dc:	b	0x3fd38
   401e0:	mov	w3, #0xccd6
   401e4:	movk	w3, #0x2, lsl #16
   401e8:	cmp	x6, x3
   401ec:	cset	x3, hs
   401f0:	and	w3, w3, w5
   401f4:	uxtb	w3, w3
   401f8:	cbz	x3, 0x43374
   401fc:	b	0x406a8
   40200:	ldur	x5, [sp, #0xc8]
   40204:	ldur	x8, [sp, #0x48]
   40208:	mov	x10, x14
   4020c:	ldur	x13, [sp, #0x40]
   40210:	ldur	x20, [sp, #0x38]
   40214:	ldur	x21, [sp, #0x30]
   40218:	ldur	x24, [sp, #0xc8]
   4021c:	ldur	x25, [sp, #0x10]
   40220:	ldur	x26, [sp, #0xc8]
   40224:	ldur	x28, [sp, #0xc8]
   40228:	b	0x40294
   4022c:	ldur	x8, [sp, #0x60]
   40230:	mov	x9, x6
   40234:	b	0x40260
   40238:	mov	w3, #0x1
   4023c:	cmp	x11, x7
   40240:	ldur	x28, [sp, #0xe8]
   40244:	csel	x3, x28, x3, hs
   40248:	ldur	x8, [sp, #0x60]
   4024c:	mov	x9, x6
   40250:	b	0x40260
   40254:	ldur	x3, [sp, #0xe8]
   40258:	ldur	x8, [sp, #0x60]
   4025c:	mov	x9, x6
   40260:	tbnz	w3, #0x0, 0x406a8
   40264:	stur	x8, [sp, #0x60]
   40268:	ldur	x28, [sp, #0xc8]
   4026c:	ldur	x26, [sp, #0xc8]
   40270:	ldur	x25, [sp, #0x10]
   40274:	ldur	x24, [sp, #0xc8]
   40278:	ldur	x21, [sp, #0x30]
   4027c:	ldur	x20, [sp, #0x38]
   40280:	ldur	x13, [sp, #0x40]
   40284:	mov	x10, x14
   40288:	ldur	x8, [sp, #0x48]
   4028c:	mov	x6, x9
   40290:	ldur	x5, [sp, #0xc8]
   40294:	mov	x3, #0x0
   40298:	str	x3, [x19, #0x30]
   4029c:	str	x0, [x19, #0x38]
   402a0:	mov	x0, #0x1
   402a4:	str	x0, [x19, #0x48]
   402a8:	mov	x9, #0x101010101010101
   402ac:	str	x9, [x19, #0x50]
   402b0:	ldur	x9, [sp, #0xd8]
   402b4:	str	x9, [x19, #0x58]
   402b8:	mov	x9, #0x3
   402bc:	str	x9, [x19, #0x60]
   402c0:	mov	x9, #0x4
   402c4:	str	x9, [x19, #0x68]
   402c8:	mov	x9, #0xf0f0f0f0f0f0f0f
   402cc:	str	x9, [x19, #0x90]
   402d0:	mov	x9, #0x3333333333333333
   402d4:	str	x9, [x19, #0xa0]
   402d8:	mov	x9, #0x38
   402dc:	str	x9, [x19, #0xa8]
   402e0:	mov	x9, #0x3a
   402e4:	str	x9, [x19, #0xb0]
   402e8:	mov	x9, #0x5555555555555555
   402ec:	str	x9, [x19, #0xc8]
   402f0:	ldur	x9, [sp, #0xd0]
   402f4:	str	x9, [x19, #0xd8]
   402f8:	str	x3, [x19, #0x178]
   402fc:	str	x0, [x19, #0x180]
   40300:	ldur	x9, [sp, #0xc8]
   40304:	str	x9, [x19, #0x2140]
   40308:	ldr	x9, [sp, #0x1b0]
   4030c:	str	x9, [x19, #0x2148]
   40310:	ldr	x9, [sp, #0x118]
   40314:	uxtb	w9, w9
   40318:	str	x9, [x19, #0x2158]
   4031c:	str	x14, [x19, #0x25d8]
   40320:	str	x12, [x19, #0x25e0]
   40324:	str	x24, [x19, #0x25e8]
   40328:	ldur	x9, [sp, #0xe0]
   4032c:	str	x9, [x19, #0x2610]
   40330:	ldur	x9, [sp, #0x58]
   40334:	str	x9, [x19, #0x54d0]
   40338:	str	x6, [x19, #0x54d8]
   4033c:	ldur	x9, [sp, #0x60]
   40340:	str	x9, [x19, #0x54e0]
   40344:	str	x26, [x19, #0x5818]
   40348:	ldr	x14, [sp, #0x1b0]
   4034c:	str	x14, [x19, #0x5820]
   40350:	str	x10, [x19, #0x5d38]
   40354:	str	x12, [x19, #0x5d40]
   40358:	str	x28, [x19, #0x5d48]
   4035c:	ldur	x9, [sp, #0x10]
   40360:	str	x9, [x19, #0x5d50]
   40364:	ldur	x26, [sp, #0x30]
   40368:	str	x26, [x19, #0x5d58]
   4036c:	ldur	x9, [sp, #0x38]
   40370:	str	x9, [x19, #0x5d60]
   40374:	ldur	x9, [sp, #0x40]
   40378:	str	x9, [x19, #0x5d68]
   4037c:	ldur	x9, [sp, #0x48]
   40380:	str	x9, [x19, #0x5d70]
   40384:	str	x25, [x19, #0x5de0]
   40388:	str	x21, [x19, #0x5de8]
   4038c:	str	x20, [x19, #0x5df0]
   40390:	str	x13, [x19, #0x5df8]
   40394:	str	x8, [x19, #0x5e00]
   40398:	str	x11, [x19, #0x5e98]
   4039c:	str	x7, [x19, #0x5ea0]
   403a0:	str	x5, [x19, #0x5ea8]
   403a4:	str	x2, [x19, #0x5eb0]
   403a8:	str	x4, [x19, #0x5eb8]
   403ac:	str	x23, [x19, #0x5ec0]
   403b0:	str	x1, [x19, #0x5ec8]
   403b4:	str	x22, [x19, #0x5ed0]
   403b8:	ldur	x24, [sp, #0x28]
   403bc:	str	x24, [x19, #0x6238]
   403c0:	add	x1, x15, #0x1
   403c4:	str	x1, [x19, #0x62a8]
   403c8:	ldur	x23, [sp, #0x68]
   403cc:	str	x23, [x19, #0x62b0]
   403d0:	ldur	x28, [sp, #0x70]
   403d4:	str	x28, [x19, #0x62b8]
   403d8:	ldur	x4, [sp, #0x50]
   403dc:	sub	x2, x4, x6
   403e0:	mov	w4, #0xb946
   403e4:	movk	w4, #0x1, lsl #16
   403e8:	msub	x1, x1, x4, x2
   403ec:	str	x1, [x19, #0x62c0]
   403f0:	str	x3, [x19, #0x62c8]
   403f4:	str	x3, [x19, #0x62d0]
   403f8:	ldur	x22, [sp, #0x78]
   403fc:	str	x22, [x19, #0x62e0]
   40400:	ldur	x9, [sp, #0x80]
   40404:	str	x9, [x19, #0x62e8]
   40408:	str	x0, [x19, #0x62f8]
   4040c:	ldur	x6, [sp, #0x20]
   40410:	str	x6, [x19, #0x6300]
   40414:	str	x0, [x19, #0x6310]
   40418:	str	x27, [x19, #0x6318]
   4041c:	ldr	x0, [x19, #0x54d0]
   40420:	cmp	x0, #0x0
   40424:	b.eq	0x40680
   40428:	ldr	x3, [x19, #0x54d8]
   4042c:	ldr	x4, [x19, #0x54e0]
   40430:	mov	x0, #0x0
   40434:	str	x0, [x19, #0x54d0]
   40438:	mov	x0, #0x3
   4043c:	ldr	x14, [sp, #0x1b8]
   40440:	mov	x25, x0
   40444:	cmp	x14, #0x164
   40448:	b.lo	0x43b34
   4044c:	ldr	x0, [x19, #0x5818]
   40450:	ldr	x1, [sp, #0x1c0]
   40454:	str	x0, [x1, #0x10]
   40458:	ldr	x1, [x19, #0x5820]
   4045c:	ldr	x2, [sp, #0x1c0]
   40460:	str	x1, [x2, #0x18]
   40464:	ldr	x2, [x19, #0x6238]
   40468:	ldr	x5, [sp, #0x1c0]
   4046c:	str	x2, [x5, #0xa30]
   40470:	ldr	x2, [x19, #0x5de0]
   40474:	str	x2, [x5, #0x5d8]
   40478:	ldr	x2, [x19, #0x5de8]
   4047c:	str	x2, [x5, #0x5e0]
   40480:	ldr	x2, [x19, #0x5df0]
   40484:	str	x2, [x5, #0x5e8]
   40488:	ldr	x2, [x19, #0x5df8]
   4048c:	str	x2, [x5, #0x5f0]
   40490:	ldr	x5, [x19, #0x5e00]
   40494:	ldr	x2, [sp, #0x1c0]
   40498:	str	x5, [x2, #0x5f8]
   4049c:	ldr	x5, [sp, #0x1c0]
   404a0:	str	x0, [x5, #0x10]
   404a4:	ldr	x6, [sp, #0x1c0]
   404a8:	str	x1, [x6, #0x18]
   404ac:	ldr	x6, [x19, #0x58f8]
   404b0:	ldr	x9, [sp, #0x1c0]
   404b4:	str	x6, [x9, #0xf0]
   404b8:	ldr	x7, [x19, #0x5900]
   404bc:	ldr	x12, [sp, #0x1c0]
   404c0:	str	x7, [x12, #0xf8]
   404c4:	ldr	x8, [x19, #0x5908]
   404c8:	ldr	x15, [sp, #0x1c0]
   404cc:	str	x8, [x15, #0x100]
   404d0:	ldr	x9, [x19, #0x5910]
   404d4:	ldr	x0, [sp, #0x1c0]
   404d8:	str	x9, [x0, #0x108]
   404dc:	ldr	x10, [x19, #0x5918]
   404e0:	str	x10, [x0, #0x110]
   404e4:	ldr	x11, [x19, #0x5920]
   404e8:	str	x11, [x0, #0x118]
   404ec:	ldr	x12, [x19, #0x5928]
   404f0:	str	x12, [x0, #0x120]
   404f4:	ldr	x13, [x19, #0x5930]
   404f8:	str	x13, [x0, #0x128]
   404fc:	ldr	x14, [x19, #0x5938]
   40500:	str	x14, [x0, #0x130]
   40504:	ldr	x15, [x19, #0x5a70]
   40508:	str	x15, [x0, #0x268]
   4050c:	ldr	x0, [x19, #0x5a78]
   40510:	ldr	x1, [sp, #0x1c0]
   40514:	str	x0, [x1, #0x270]
   40518:	ldr	x0, [x19, #0x5a80]
   4051c:	str	x0, [x1, #0x278]
   40520:	ldr	x0, [x19, #0x5a88]
   40524:	str	x0, [x1, #0x280]
   40528:	ldr	x0, [x19, #0x5a90]
   4052c:	str	x0, [x1, #0x288]
   40530:	ldr	x0, [x19, #0x5a98]
   40534:	str	x0, [x1, #0x290]
   40538:	ldr	x0, [x19, #0x5aa0]
   4053c:	str	x0, [x1, #0x298]
   40540:	ldr	x0, [x19, #0x5aa8]
   40544:	str	x0, [x1, #0x2a0]
   40548:	ldr	x0, [x19, #0x5ab0]
   4054c:	str	x0, [x1, #0x2a8]
   40550:	ldr	x0, [x19, #0x5d38]
   40554:	str	x0, [x1, #0x530]
   40558:	ldr	x0, [x19, #0x5d40]
   4055c:	str	x0, [x5, #0x538]
   40560:	ldr	x0, [x19, #0x5d48]
   40564:	ldr	x6, [sp, #0x1c0]
   40568:	str	x0, [x6, #0x540]
   4056c:	ldr	x0, [x19, #0x5d50]
   40570:	ldr	x9, [sp, #0x1c0]
   40574:	str	x0, [x9, #0x548]
   40578:	ldr	x0, [x19, #0x5d58]
   4057c:	ldr	x12, [sp, #0x1c0]
   40580:	str	x0, [x12, #0x550]
   40584:	ldr	x0, [x19, #0x5d60]
   40588:	ldr	x15, [sp, #0x1c0]
   4058c:	str	x0, [x15, #0x558]
   40590:	ldr	x0, [x19, #0x5d68]
   40594:	str	x0, [x1, #0x560]
   40598:	ldr	x0, [x19, #0x5d70]
   4059c:	str	x0, [x1, #0x568]
   405a0:	ldr	x0, [x19, #0x5e98]
   405a4:	str	x0, [x1, #0x690]
   405a8:	ldr	x0, [x19, #0x5ea0]
   405ac:	str	x0, [x1, #0x698]
   405b0:	ldr	x0, [x19, #0x5ea8]
   405b4:	str	x0, [x1, #0x6a0]
   405b8:	ldr	x0, [x19, #0x5eb0]
   405bc:	str	x0, [x1, #0x6a8]
   405c0:	ldr	x0, [x19, #0x5eb8]
   405c4:	str	x0, [x1, #0x6b0]
   405c8:	ldr	x0, [x19, #0x5ec0]
   405cc:	str	x0, [x1, #0x6b8]
   405d0:	ldr	x0, [x19, #0x5ec8]
   405d4:	str	x0, [x1, #0x6c0]
   405d8:	ldr	x0, [x19, #0x5ed0]
   405dc:	str	x0, [x1, #0x6c8]
   405e0:	ldr	x0, [x19, #0x62a8]
   405e4:	str	x0, [x1, #0xaa0]
   405e8:	ldr	x0, [x19, #0x62b0]
   405ec:	str	x0, [x1, #0xaa8]
   405f0:	ldr	x0, [x19, #0x62b8]
   405f4:	str	x0, [x1, #0xab0]
   405f8:	ldr	x0, [x19, #0x62c0]
   405fc:	str	x0, [x1, #0xab8]
   40600:	ldr	x0, [x19, #0x62c8]
   40604:	str	x0, [x1, #0xac0]
   40608:	ldr	x0, [x19, #0x62d0]
   4060c:	str	x0, [x1, #0xac8]
   40610:	mov	x0, #0x0
   40614:	str	x0, [x5, #0xad0]
   40618:	ldr	x1, [x19, #0x62e0]
   4061c:	str	x1, [x6, #0xad8]
   40620:	ldr	x1, [x19, #0x62e8]
   40624:	str	x1, [x9, #0xae0]
   40628:	ldr	x11, [sp, #0x1c0]
   4062c:	str	x0, [x11, #0xae8]
   40630:	ldr	x1, [x19, #0x62f8]
   40634:	ldr	x14, [sp, #0x1c0]
   40638:	str	x1, [x14, #0xaf0]
   4063c:	ldr	x1, [x19, #0x6300]
   40640:	str	x1, [x2, #0xaf8]
   40644:	ldr	x1, [sp, #0x1c0]
   40648:	str	x0, [x1, #0xb00]
   4064c:	ldr	x0, [x19, #0x6310]
   40650:	str	x0, [x1, #0xb08]
   40654:	ldr	x0, [x19, #0x6318]
   40658:	str	x0, [x1, #0xb10]
   4065c:	mov	x1, #0x73f
   40660:	mov	x2, #-0x9
   40664:	mov	x5, #0x1
   40668:	ldur	x0, [sp, #0x8]
   4066c:	ldr	x6, [sp, #0x1c8]
   40670:	ldr	x21, [sp, #0x1d0]
   40674:	blr	x21
   40678:	cmp	x0, #0x0
   4067c:	b.ne	0x433bc
   40680:	mov	x0, #0x0
   40684:	mov	x1, #0x5
   40688:	add	sp, sp, #0x1e0
   4068c:	ldp	x19, x20, [sp], #0x10
   40690:	ldp	x21, x22, [sp], #0x10
   40694:	ldp	x23, x24, [sp], #0x10
   40698:	ldp	x25, x26, [sp], #0x10
   4069c:	ldp	x27, x28, [sp], #0x10
   406a0:	ldp	x29, x30, [sp], #0x10
   406a4:	.long	0xd65f0fff
   406a8:	cmp	x11, x7
   406ac:	cset	x8, lo
   406b0:	cmp	x11, x7
   406b4:	b.lo	0x406c0
   406b8:	mov	x20, #0x0
   406bc:	b	0x406cc
   406c0:	ldr	x3, [sp, #0x178]
   406c4:	ldr	w3, [x3, x11, lsl #2]
   406c8:	mov	w20, w3
   406cc:	eor	x3, x20, #0x3ffffffffffffff
   406d0:	orr	x9, x3, #0xc00000000000000
   406d4:	cmp	x9, x22
   406d8:	cset	x9, hi
   406dc:	and	w8, w8, w9
   406e0:	uxtb	w8, w8
   406e4:	tbnz	w8, #0x0, 0x40700
   406e8:	mov	x3, x2
   406ec:	mov	x10, x4
   406f0:	mov	x21, x23
   406f4:	mov	x24, x1
   406f8:	mov	x26, x22
   406fc:	b	0x407b8
   40700:	ldur	x9, [sp, #0xc8]
   40704:	cmp	x20, x9
   40708:	b.ne	0x40724
   4070c:	mov	x3, x2
   40710:	mov	x10, x4
   40714:	mov	x21, x23
   40718:	mov	x24, x1
   4071c:	mov	x26, x22
   40720:	b	0x407b8
   40724:	and	x21, x2, #0x3ffffffffffffff
   40728:	eor	x10, x20, #0x3ffffffffffffff
   4072c:	cmp	x10, x21
   40730:	cset	x20, ne
   40734:	and	x9, x4, #0x3ffffffffffffff
   40738:	cmp	x10, x9
   4073c:	cset	x9, ne
   40740:	and	w20, w20, w9
   40744:	and	x9, x23, #0x3ffffffffffffff
   40748:	cmp	x10, x9
   4074c:	cset	x9, ne
   40750:	and	w20, w20, w9
   40754:	and	x9, x1, #0x3ffffffffffffff
   40758:	cmp	x10, x9
   4075c:	cset	x9, ne
   40760:	and	w9, w20, w9
   40764:	uxtb	w9, w9
   40768:	tbnz	w9, #0x0, 0x40784
   4076c:	mov	x3, x2
   40770:	mov	x10, x4
   40774:	mov	x21, x23
   40778:	mov	x24, x1
   4077c:	mov	x26, x22
   40780:	b	0x407b8
   40784:	orr	x10, x3, #0xc00000000000000
   40788:	cmp	x10, x2
   4078c:	csel	x3, x10, x2, hi
   40790:	csel	x28, x10, x2, lo
   40794:	cmp	x28, x4
   40798:	csel	x10, x28, x4, hi
   4079c:	csel	x20, x28, x4, lo
   407a0:	cmp	x20, x23
   407a4:	csel	x21, x20, x23, hi
   407a8:	csel	x20, x20, x23, lo
   407ac:	cmp	x20, x1
   407b0:	csel	x24, x20, x1, hi
   407b4:	csel	x26, x20, x1, lo
   407b8:	tbnz	w8, #0x0, 0x41250
   407bc:	mov	w3, #0xccd6
   407c0:	movk	w3, #0x2, lsl #16
   407c4:	sub	x3, x6, x3
   407c8:	tbnz	w13, #0x3, 0x433c4
   407cc:	mov	x7, #0x0
   407d0:	mov	x6, x7
   407d4:	ldur	x8, [sp, #0xe0]
   407d8:	tbnz	w8, #0x0, 0x41218
   407dc:	tbnz	w13, #0x2, 0x43410
   407e0:	mov	x26, #0x0
   407e4:	mov	x11, x26
   407e8:	mov	x12, x26
   407ec:	mov	x14, x26
   407f0:	ldur	x23, [sp, #0xc8]
   407f4:	ldur	x24, [sp, #0xc8]
   407f8:	ldur	x0, [sp, #0xc8]
   407fc:	ldr	x27, [sp, #0x1b0]
   40800:	cmp	x0, x27
   40804:	b.lo	0x40818
   40808:	add	x15, x15, #0x1
   4080c:	ldur	x20, [sp, #0x90]
   40810:	ldur	x28, [sp, #0x98]
   40814:	b	0x410cc
   40818:	ldur	x20, [sp, #0x90]
   4081c:	cbnz	x20, 0x409c8
   40820:	b	0x4345c
   40824:	ldr	x9, [sp, #0x1c0]
   40828:	str	x24, [x9, #0x10]
   4082c:	ldr	x13, [sp, #0x1c0]
   40830:	str	x27, [x13, #0x18]
   40834:	str	x24, [x13, #0x10]
   40838:	ldr	x0, [sp, #0x1c0]
   4083c:	str	x27, [x0, #0x18]
   40840:	mov	x5, #0x1
   40844:	add	x0, x15, #0x1
   40848:	ldr	x1, [sp, #0x1c0]
   4084c:	str	x0, [x1, #0xaa0]
   40850:	ldur	x1, [sp, #0x68]
   40854:	ldr	x2, [sp, #0x1c0]
   40858:	str	x1, [x2, #0xaa8]
   4085c:	ldr	x1, [sp, #0x1c0]
   40860:	ldur	x28, [sp, #0x70]
   40864:	str	x28, [x1, #0xab0]
   40868:	ldur	x4, [sp, #0x50]
   4086c:	sub	x1, x4, x3
   40870:	mov	w2, #0xb946
   40874:	movk	w2, #0x1, lsl #16
   40878:	msub	x0, x0, x2, x1
   4087c:	ldr	x1, [sp, #0x1c0]
   40880:	str	x0, [x1, #0xab8]
   40884:	ldr	x0, [sp, #0x1c0]
   40888:	str	x26, [x0, #0xac0]
   4088c:	str	x14, [x0, #0xac8]
   40890:	mov	x0, #0x0
   40894:	str	x0, [x1, #0xad0]
   40898:	ldur	x22, [sp, #0x78]
   4089c:	str	x22, [x1, #0xad8]
   408a0:	ldur	x9, [sp, #0x80]
   408a4:	str	x9, [x1, #0xae0]
   408a8:	str	x0, [x1, #0xae8]
   408ac:	str	x12, [x1, #0xaf0]
   408b0:	str	x11, [x1, #0xaf8]
   408b4:	str	x0, [x1, #0xb00]
   408b8:	ldr	x0, [sp, #0x1c0]
   408bc:	str	x7, [x0, #0xb08]
   408c0:	str	x6, [x0, #0xb10]
   408c4:	ldur	x2, [sp, #0x28]
   408c8:	add	x6, x2, #0x1
   408cc:	str	x6, [x0, #0xb20]
   408d0:	ldur	x0, [sp, #0x10]
   408d4:	and	x7, x0, #0x3ffffffffffffff
   408d8:	eor	x7, x7, #0x3ffffffffffffff
   408dc:	ldr	x0, [sp, #0x1c0]
   408e0:	str	x7, [x0, #0xb28]
   408e4:	mov	x1, #0x7f4
   408e8:	mov	x2, #-0x1b
   408ec:	ldur	x4, [sp, #0x60]
   408f0:	ldr	x21, [sp, #0x1d0]
   408f4:	ldur	x0, [sp, #0x8]
   408f8:	ldr	x6, [sp, #0x1c8]
   408fc:	blr	x21
   40900:	mov	x1, #0x2
   40904:	mov	x25, x1
   40908:	cmp	x0, #0x0
   4090c:	b.ne	0x43b34
   40910:	ldr	x3, [sp, #0x1c0]
   40914:	ldr	x3, [x3]
   40918:	ldr	x7, [sp, #0x1c0]
   4091c:	ldr	x4, [x7, #0x8]
   40920:	ldr	x9, [sp, #0x1c0]
   40924:	stur	x4, [sp, #0x60]
   40928:	ldr	x28, [x9, #0xa28]
   4092c:	ldr	x11, [sp, #0x1c0]
   40930:	ldr	x20, [x11, #0xa90]
   40934:	ldr	x13, [sp, #0x1c0]
   40938:	ldr	x1, [x13, #0xa30]
   4093c:	ldr	x15, [sp, #0x1c0]
   40940:	ldr	x11, [x15, #0xa38]
   40944:	ldr	x0, [sp, #0x1c0]
   40948:	ldr	x11, [x0, #0xa40]
   4094c:	ldr	x0, [x0, #0xa98]
   40950:	stur	x0, [sp, #0x88]
   40954:	ldr	x0, [sp, #0x1c0]
   40958:	ldr	x15, [x0, #0xaa0]
   4095c:	ldr	x0, [x0, #0xaa8]
   40960:	stur	x0, [sp, #0x68]
   40964:	ldr	x0, [sp, #0x1c0]
   40968:	ldr	x14, [x0, #0xab0]
   4096c:	stur	x14, [sp, #0x70]
   40970:	ldr	x13, [x0, #0xab8]
   40974:	ldr	x26, [x0, #0xac0]
   40978:	ldr	x14, [x0, #0xac8]
   4097c:	ldr	x22, [x0, #0xad8]
   40980:	stur	x22, [sp, #0x78]
   40984:	ldr	x9, [x0, #0xae0]
   40988:	stur	x9, [sp, #0x80]
   4098c:	ldr	x12, [x0, #0xaf0]
   40990:	ldr	x11, [x0, #0xaf8]
   40994:	ldr	x7, [x0, #0xb08]
   40998:	ldr	x6, [x0, #0xb10]
   4099c:	ldr	x25, [x0, #0x10]
   409a0:	mov	x10, #0x1
   409a4:	stur	x10, [sp, #0x58]
   409a8:	str	x10, [x19, #0x54d0]
   409ac:	add	x13, x3, x13
   409b0:	mov	w0, #0xb946
   409b4:	movk	w0, #0x1, lsl #16
   409b8:	madd	x4, x15, x0, x13
   409bc:	stur	x4, [sp, #0x50]
   409c0:	mov	x13, #0xf
   409c4:	b	0x409ec
   409c8:	ldur	x0, [sp, #0x10]
   409cc:	ldur	x28, [sp, #0x98]
   409d0:	and	x0, x0, #0x3ffffffffffffff
   409d4:	eor	x0, x0, #0x3ffffffffffffff
   409d8:	ldur	x1, [sp, #0x28]
   409dc:	str	x0, [x28, x1, lsl #3]
   409e0:	ldur	x0, [sp, #0x28]
   409e4:	add	x1, x0, #0x1
   409e8:	add	x15, x15, #0x1
   409ec:	cbnz	x20, 0x40b8c
   409f0:	b	0x43488
   409f4:	ldr	x13, [sp, #0x1c0]
   409f8:	str	x24, [x13, #0x10]
   409fc:	ldr	x27, [sp, #0x1b0]
   40a00:	str	x27, [x13, #0x18]
   40a04:	ldr	x0, [sp, #0x1c0]
   40a08:	str	x24, [x0, #0x10]
   40a0c:	str	x27, [x0, #0x18]
   40a10:	str	x15, [x0, #0xaa0]
   40a14:	ldur	x4, [sp, #0x68]
   40a18:	str	x4, [x0, #0xaa8]
   40a1c:	ldur	x28, [sp, #0x70]
   40a20:	str	x28, [x0, #0xab0]
   40a24:	ldur	x4, [sp, #0x50]
   40a28:	sub	x0, x4, x3
   40a2c:	mov	w2, #0xb946
   40a30:	movk	w2, #0x1, lsl #16
   40a34:	msub	x0, x15, x2, x0
   40a38:	ldr	x2, [sp, #0x1c0]
   40a3c:	str	x0, [x2, #0xab8]
   40a40:	ldr	x0, [sp, #0x1c0]
   40a44:	str	x26, [x0, #0xac0]
   40a48:	str	x14, [x0, #0xac8]
   40a4c:	mov	x0, #0x0
   40a50:	str	x0, [x2, #0xad0]
   40a54:	ldur	x22, [sp, #0x78]
   40a58:	str	x22, [x2, #0xad8]
   40a5c:	ldur	x9, [sp, #0x80]
   40a60:	str	x9, [x2, #0xae0]
   40a64:	str	x0, [x2, #0xae8]
   40a68:	str	x12, [x2, #0xaf0]
   40a6c:	str	x11, [x2, #0xaf8]
   40a70:	str	x0, [x2, #0xb00]
   40a74:	ldr	x0, [sp, #0x1c0]
   40a78:	str	x7, [x0, #0xb08]
   40a7c:	str	x6, [x0, #0xb10]
   40a80:	mov	x5, #0x1
   40a84:	add	x0, x1, #0x1
   40a88:	ldr	x1, [sp, #0x1c0]
   40a8c:	str	x0, [x1, #0xb20]
   40a90:	ldur	x26, [sp, #0x30]
   40a94:	and	x0, x26, #0x3ffffffffffffff
   40a98:	eor	x0, x0, #0x3ffffffffffffff
   40a9c:	str	x0, [x1, #0xb28]
   40aa0:	mov	x1, #0x7f8
   40aa4:	mov	x2, #-0x1b
   40aa8:	ldur	x4, [sp, #0x60]
   40aac:	ldr	x21, [sp, #0x1d0]
   40ab0:	ldur	x0, [sp, #0x8]
   40ab4:	ldr	x6, [sp, #0x1c8]
   40ab8:	blr	x21
   40abc:	mov	x1, #0x2
   40ac0:	mov	x25, x1
   40ac4:	cmp	x0, #0x0
   40ac8:	b.ne	0x43b34
   40acc:	ldr	x3, [sp, #0x1c0]
   40ad0:	ldr	x3, [x3]
   40ad4:	ldr	x8, [sp, #0x1c0]
   40ad8:	ldr	x4, [x8, #0x8]
   40adc:	ldr	x10, [sp, #0x1c0]
   40ae0:	stur	x4, [sp, #0x60]
   40ae4:	ldr	x28, [x10, #0xa28]
   40ae8:	ldr	x12, [sp, #0x1c0]
   40aec:	ldr	x20, [x12, #0xa90]
   40af0:	ldr	x14, [sp, #0x1c0]
   40af4:	ldr	x1, [x14, #0xa30]
   40af8:	ldr	x0, [sp, #0x1c0]
   40afc:	ldr	x0, [x0, #0xa38]
   40b00:	ldr	x0, [sp, #0x1c0]
   40b04:	ldr	x0, [x0, #0xa40]
   40b08:	ldr	x0, [sp, #0x1c0]
   40b0c:	ldr	x2, [x0, #0xa98]
   40b10:	stur	x2, [sp, #0x88]
   40b14:	ldr	x15, [x0, #0xaa0]
   40b18:	ldr	x0, [x0, #0xaa8]
   40b1c:	stur	x0, [sp, #0x68]
   40b20:	ldr	x0, [sp, #0x1c0]
   40b24:	ldr	x0, [x0, #0xab0]
   40b28:	stur	x0, [sp, #0x70]
   40b2c:	ldr	x0, [sp, #0x1c0]
   40b30:	ldr	x0, [x0, #0xab8]
   40b34:	ldr	x2, [sp, #0x1c0]
   40b38:	ldr	x26, [x2, #0xac0]
   40b3c:	ldr	x14, [x2, #0xac8]
   40b40:	ldr	x22, [x2, #0xad8]
   40b44:	stur	x22, [sp, #0x78]
   40b48:	ldr	x9, [x2, #0xae0]
   40b4c:	stur	x9, [sp, #0x80]
   40b50:	ldr	x12, [x2, #0xaf0]
   40b54:	ldr	x11, [x2, #0xaf8]
   40b58:	ldr	x7, [x2, #0xb08]
   40b5c:	ldr	x6, [x2, #0xb10]
   40b60:	ldr	x25, [x2, #0x10]
   40b64:	mov	x10, #0x1
   40b68:	stur	x10, [sp, #0x58]
   40b6c:	str	x10, [x19, #0x54d0]
   40b70:	add	x0, x3, x0
   40b74:	mov	w2, #0xb946
   40b78:	movk	w2, #0x1, lsl #16
   40b7c:	madd	x4, x15, x2, x0
   40b80:	stur	x4, [sp, #0x50]
   40b84:	mov	x13, #0xf
   40b88:	b	0x40ba0
   40b8c:	ldur	x0, [sp, #0x30]
   40b90:	and	x0, x0, #0x3ffffffffffffff
   40b94:	eor	x0, x0, #0x3ffffffffffffff
   40b98:	str	x0, [x28, x1, lsl #3]
   40b9c:	add	x1, x1, #0x1
   40ba0:	cbnz	x20, 0x40d3c
   40ba4:	b	0x434b4
   40ba8:	ldr	x13, [sp, #0x1c0]
   40bac:	str	x24, [x13, #0x10]
   40bb0:	ldr	x27, [sp, #0x1b0]
   40bb4:	str	x27, [x13, #0x18]
   40bb8:	ldr	x0, [sp, #0x1c0]
   40bbc:	str	x24, [x0, #0x10]
   40bc0:	str	x27, [x0, #0x18]
   40bc4:	str	x15, [x0, #0xaa0]
   40bc8:	ldur	x0, [sp, #0x68]
   40bcc:	ldr	x2, [sp, #0x1c0]
   40bd0:	str	x0, [x2, #0xaa8]
   40bd4:	ldr	x0, [sp, #0x1c0]
   40bd8:	ldur	x28, [sp, #0x70]
   40bdc:	str	x28, [x0, #0xab0]
   40be0:	ldur	x4, [sp, #0x50]
   40be4:	sub	x8, x4, x3
   40be8:	mov	w9, #0xb946
   40bec:	movk	w9, #0x1, lsl #16
   40bf0:	msub	x8, x15, x9, x8
   40bf4:	str	x8, [x0, #0xab8]
   40bf8:	str	x26, [x0, #0xac0]
   40bfc:	str	x14, [x0, #0xac8]
   40c00:	mov	x10, #0x0
   40c04:	str	x10, [x0, #0xad0]
   40c08:	ldur	x22, [sp, #0x78]
   40c0c:	str	x22, [x0, #0xad8]
   40c10:	ldur	x9, [sp, #0x80]
   40c14:	str	x9, [x0, #0xae0]
   40c18:	str	x10, [x0, #0xae8]
   40c1c:	str	x12, [x0, #0xaf0]
   40c20:	str	x11, [x0, #0xaf8]
   40c24:	str	x10, [x0, #0xb00]
   40c28:	str	x7, [x0, #0xb08]
   40c2c:	str	x6, [x0, #0xb10]
   40c30:	mov	x5, #0x1
   40c34:	add	x0, x1, #0x1
   40c38:	ldr	x1, [sp, #0x1c0]
   40c3c:	str	x0, [x1, #0xb20]
   40c40:	ldur	x0, [sp, #0x38]
   40c44:	and	x0, x0, #0x3ffffffffffffff
   40c48:	eor	x0, x0, #0x3ffffffffffffff
   40c4c:	str	x0, [x1, #0xb28]
   40c50:	mov	x1, #0x7fc
   40c54:	mov	x2, #-0x1b
   40c58:	ldur	x4, [sp, #0x60]
   40c5c:	ldr	x21, [sp, #0x1d0]
   40c60:	ldur	x0, [sp, #0x8]
   40c64:	ldr	x6, [sp, #0x1c8]
   40c68:	blr	x21
   40c6c:	mov	x1, #0x2
   40c70:	mov	x25, x1
   40c74:	cmp	x0, #0x0
   40c78:	b.ne	0x43b34
   40c7c:	ldr	x3, [sp, #0x1c0]
   40c80:	ldr	x3, [x3]
   40c84:	ldr	x8, [sp, #0x1c0]
   40c88:	ldr	x4, [x8, #0x8]
   40c8c:	ldr	x10, [sp, #0x1c0]
   40c90:	stur	x4, [sp, #0x60]
   40c94:	ldr	x28, [x10, #0xa28]
   40c98:	ldr	x12, [sp, #0x1c0]
   40c9c:	ldr	x20, [x12, #0xa90]
   40ca0:	ldr	x14, [sp, #0x1c0]
   40ca4:	ldr	x1, [x14, #0xa30]
   40ca8:	ldr	x0, [sp, #0x1c0]
   40cac:	ldr	x0, [x0, #0xa38]
   40cb0:	ldr	x0, [sp, #0x1c0]
   40cb4:	ldr	x0, [x0, #0xa40]
   40cb8:	ldr	x0, [sp, #0x1c0]
   40cbc:	ldr	x0, [x0, #0xa98]
   40cc0:	stur	x0, [sp, #0x88]
   40cc4:	ldr	x0, [sp, #0x1c0]
   40cc8:	ldr	x15, [x0, #0xaa0]
   40ccc:	ldr	x5, [x0, #0xaa8]
   40cd0:	stur	x5, [sp, #0x68]
   40cd4:	ldr	x0, [x0, #0xab0]
   40cd8:	stur	x0, [sp, #0x70]
   40cdc:	ldr	x0, [sp, #0x1c0]
   40ce0:	ldr	x0, [x0, #0xab8]
   40ce4:	ldr	x2, [sp, #0x1c0]
   40ce8:	ldr	x26, [x2, #0xac0]
   40cec:	ldr	x14, [x2, #0xac8]
   40cf0:	ldr	x22, [x2, #0xad8]
   40cf4:	stur	x22, [sp, #0x78]
   40cf8:	ldr	x9, [x2, #0xae0]
   40cfc:	stur	x9, [sp, #0x80]
   40d00:	ldr	x12, [x2, #0xaf0]
   40d04:	ldr	x11, [x2, #0xaf8]
   40d08:	ldr	x7, [x2, #0xb08]
   40d0c:	ldr	x6, [x2, #0xb10]
   40d10:	ldr	x25, [x2, #0x10]
   40d14:	mov	x10, #0x1
   40d18:	stur	x10, [sp, #0x58]
   40d1c:	str	x10, [x19, #0x54d0]
   40d20:	add	x0, x3, x0
   40d24:	mov	w2, #0xb946
   40d28:	movk	w2, #0x1, lsl #16
   40d2c:	madd	x4, x15, x2, x0
   40d30:	stur	x4, [sp, #0x50]
   40d34:	mov	x13, #0xf
   40d38:	b	0x40d50
   40d3c:	ldur	x0, [sp, #0x38]
   40d40:	and	x0, x0, #0x3ffffffffffffff
   40d44:	eor	x0, x0, #0x3ffffffffffffff
   40d48:	str	x0, [x28, x1, lsl #3]
   40d4c:	add	x1, x1, #0x1
   40d50:	cbnz	x20, 0x40efc
   40d54:	b	0x434e0
   40d58:	ldr	x13, [sp, #0x1c0]
   40d5c:	str	x24, [x13, #0x10]
   40d60:	ldr	x27, [sp, #0x1b0]
   40d64:	str	x27, [x13, #0x18]
   40d68:	ldr	x0, [sp, #0x1c0]
   40d6c:	str	x24, [x0, #0x10]
   40d70:	str	x27, [x0, #0x18]
   40d74:	str	x15, [x0, #0xaa0]
   40d78:	ldur	x0, [sp, #0x68]
   40d7c:	ldr	x2, [sp, #0x1c0]
   40d80:	str	x0, [x2, #0xaa8]
   40d84:	ldr	x0, [sp, #0x1c0]
   40d88:	ldur	x28, [sp, #0x70]
   40d8c:	str	x28, [x0, #0xab0]
   40d90:	ldur	x4, [sp, #0x50]
   40d94:	sub	x0, x4, x3
   40d98:	mov	w2, #0xb946
   40d9c:	movk	w2, #0x1, lsl #16
   40da0:	msub	x0, x15, x2, x0
   40da4:	ldr	x2, [sp, #0x1c0]
   40da8:	str	x0, [x2, #0xab8]
   40dac:	ldr	x0, [sp, #0x1c0]
   40db0:	str	x26, [x0, #0xac0]
   40db4:	str	x14, [x0, #0xac8]
   40db8:	mov	x0, #0x0
   40dbc:	str	x0, [x2, #0xad0]
   40dc0:	ldur	x22, [sp, #0x78]
   40dc4:	str	x22, [x2, #0xad8]
   40dc8:	ldur	x9, [sp, #0x80]
   40dcc:	str	x9, [x2, #0xae0]
   40dd0:	str	x0, [x2, #0xae8]
   40dd4:	str	x12, [x2, #0xaf0]
   40dd8:	str	x11, [x2, #0xaf8]
   40ddc:	str	x0, [x2, #0xb00]
   40de0:	ldr	x0, [sp, #0x1c0]
   40de4:	str	x7, [x0, #0xb08]
   40de8:	str	x6, [x0, #0xb10]
   40dec:	mov	x5, #0x1
   40df0:	add	x0, x1, #0x1
   40df4:	ldr	x1, [sp, #0x1c0]
   40df8:	str	x0, [x1, #0xb20]
   40dfc:	ldur	x25, [sp, #0x40]
   40e00:	and	x0, x25, #0x3ffffffffffffff
   40e04:	eor	x0, x0, #0x3ffffffffffffff
   40e08:	str	x0, [x1, #0xb28]
   40e0c:	mov	x1, #0x800
   40e10:	mov	x2, #-0x1b
   40e14:	ldur	x4, [sp, #0x60]
   40e18:	ldr	x21, [sp, #0x1d0]
   40e1c:	ldur	x0, [sp, #0x8]
   40e20:	ldr	x6, [sp, #0x1c8]
   40e24:	blr	x21
   40e28:	mov	x1, #0x2
   40e2c:	mov	x25, x1
   40e30:	cmp	x0, #0x0
   40e34:	b.ne	0x43b34
   40e38:	ldr	x3, [sp, #0x1c0]
   40e3c:	ldr	x3, [x3]
   40e40:	ldr	x8, [sp, #0x1c0]
   40e44:	ldr	x4, [x8, #0x8]
   40e48:	ldr	x10, [sp, #0x1c0]
   40e4c:	stur	x4, [sp, #0x60]
   40e50:	ldr	x28, [x10, #0xa28]
   40e54:	ldr	x12, [sp, #0x1c0]
   40e58:	ldr	x20, [x12, #0xa90]
   40e5c:	ldr	x14, [sp, #0x1c0]
   40e60:	ldr	x1, [x14, #0xa30]
   40e64:	ldr	x0, [sp, #0x1c0]
   40e68:	ldr	x0, [x0, #0xa38]
   40e6c:	ldr	x0, [sp, #0x1c0]
   40e70:	ldr	x0, [x0, #0xa40]
   40e74:	ldr	x0, [sp, #0x1c0]
   40e78:	ldr	x0, [x0, #0xa98]
   40e7c:	stur	x0, [sp, #0x88]
   40e80:	ldr	x0, [sp, #0x1c0]
   40e84:	ldr	x15, [x0, #0xaa0]
   40e88:	ldr	x0, [x0, #0xaa8]
   40e8c:	stur	x0, [sp, #0x68]
   40e90:	ldr	x0, [sp, #0x1c0]
   40e94:	ldr	x0, [x0, #0xab0]
   40e98:	stur	x0, [sp, #0x70]
   40e9c:	ldr	x0, [sp, #0x1c0]
   40ea0:	ldr	x0, [x0, #0xab8]
   40ea4:	ldr	x2, [sp, #0x1c0]
   40ea8:	ldr	x26, [x2, #0xac0]
   40eac:	ldr	x14, [x2, #0xac8]
   40eb0:	ldr	x22, [x2, #0xad8]
   40eb4:	stur	x22, [sp, #0x78]
   40eb8:	ldr	x9, [x2, #0xae0]
   40ebc:	stur	x9, [sp, #0x80]
   40ec0:	ldr	x12, [x2, #0xaf0]
   40ec4:	ldr	x11, [x2, #0xaf8]
   40ec8:	ldr	x7, [x2, #0xb08]
   40ecc:	ldr	x6, [x2, #0xb10]
   40ed0:	ldr	x25, [x2, #0x10]
   40ed4:	mov	x10, #0x1
   40ed8:	stur	x10, [sp, #0x58]
   40edc:	str	x10, [x19, #0x54d0]
   40ee0:	add	x0, x3, x0
   40ee4:	mov	w2, #0xb946
   40ee8:	movk	w2, #0x1, lsl #16
   40eec:	madd	x4, x15, x2, x0
   40ef0:	stur	x4, [sp, #0x50]
   40ef4:	mov	x13, #0xf
   40ef8:	b	0x40f10
   40efc:	ldur	x8, [sp, #0x40]
   40f00:	and	x2, x8, #0x3ffffffffffffff
   40f04:	eor	x2, x2, #0x3ffffffffffffff
   40f08:	str	x2, [x28, x1, lsl #3]
   40f0c:	add	x1, x1, #0x1
   40f10:	cbnz	x20, 0x410b4
   40f14:	b	0x4350c
   40f18:	ldr	x13, [sp, #0x1c0]
   40f1c:	str	x24, [x13, #0x10]
   40f20:	ldr	x27, [sp, #0x1b0]
   40f24:	str	x27, [x13, #0x18]
   40f28:	ldr	x0, [sp, #0x1c0]
   40f2c:	str	x24, [x0, #0x10]
   40f30:	str	x27, [x0, #0x18]
   40f34:	str	x15, [x0, #0xaa0]
   40f38:	ldur	x9, [sp, #0x68]
   40f3c:	str	x9, [x0, #0xaa8]
   40f40:	ldur	x28, [sp, #0x70]
   40f44:	str	x28, [x0, #0xab0]
   40f48:	ldur	x4, [sp, #0x50]
   40f4c:	sub	x0, x4, x3
   40f50:	mov	w2, #0xb946
   40f54:	movk	w2, #0x1, lsl #16
   40f58:	msub	x0, x15, x2, x0
   40f5c:	ldr	x2, [sp, #0x1c0]
   40f60:	str	x0, [x2, #0xab8]
   40f64:	ldr	x0, [sp, #0x1c0]
   40f68:	str	x26, [x0, #0xac0]
   40f6c:	str	x14, [x0, #0xac8]
   40f70:	mov	x0, #0x0
   40f74:	str	x0, [x2, #0xad0]
   40f78:	ldur	x22, [sp, #0x78]
   40f7c:	str	x22, [x2, #0xad8]
   40f80:	ldur	x9, [sp, #0x80]
   40f84:	str	x9, [x2, #0xae0]
   40f88:	str	x0, [x2, #0xae8]
   40f8c:	str	x12, [x2, #0xaf0]
   40f90:	str	x11, [x2, #0xaf8]
   40f94:	str	x0, [x2, #0xb00]
   40f98:	ldr	x0, [sp, #0x1c0]
   40f9c:	str	x7, [x0, #0xb08]
   40fa0:	str	x6, [x0, #0xb10]
   40fa4:	mov	x5, #0x1
   40fa8:	add	x0, x1, #0x1
   40fac:	ldr	x1, [sp, #0x1c0]
   40fb0:	str	x0, [x1, #0xb20]
   40fb4:	ldur	x9, [sp, #0x48]
   40fb8:	and	x0, x9, #0x3ffffffffffffff
   40fbc:	eor	x0, x0, #0x3ffffffffffffff
   40fc0:	str	x0, [x1, #0xb28]
   40fc4:	mov	x1, #0x804
   40fc8:	mov	x2, #-0x1b
   40fcc:	ldur	x4, [sp, #0x60]
   40fd0:	ldr	x21, [sp, #0x1d0]
   40fd4:	ldur	x0, [sp, #0x8]
   40fd8:	ldr	x6, [sp, #0x1c8]
   40fdc:	blr	x21
   40fe0:	mov	x1, #0x2
   40fe4:	mov	x25, x1
   40fe8:	cmp	x0, #0x0
   40fec:	b.ne	0x43b34
   40ff0:	ldr	x3, [sp, #0x1c0]
   40ff4:	ldr	x3, [x3]
   40ff8:	ldr	x8, [sp, #0x1c0]
   40ffc:	ldr	x4, [x8, #0x8]
   41000:	ldr	x10, [sp, #0x1c0]
   41004:	stur	x4, [sp, #0x60]
   41008:	ldr	x28, [x10, #0xa28]
   4100c:	ldr	x12, [sp, #0x1c0]
   41010:	ldr	x20, [x12, #0xa90]
   41014:	ldr	x14, [sp, #0x1c0]
   41018:	ldr	x0, [x14, #0xa30]
   4101c:	stur	x0, [sp, #0x28]
   41020:	ldr	x0, [sp, #0x1c0]
   41024:	ldr	x0, [x0, #0xa38]
   41028:	ldr	x0, [sp, #0x1c0]
   4102c:	ldr	x0, [x0, #0xa40]
   41030:	ldr	x0, [sp, #0x1c0]
   41034:	ldr	x1, [x0, #0xa98]
   41038:	stur	x1, [sp, #0x88]
   4103c:	ldr	x15, [x0, #0xaa0]
   41040:	ldr	x0, [x0, #0xaa8]
   41044:	stur	x0, [sp, #0x68]
   41048:	ldr	x0, [sp, #0x1c0]
   4104c:	ldr	x0, [x0, #0xab0]
   41050:	stur	x0, [sp, #0x70]
   41054:	ldr	x0, [sp, #0x1c0]
   41058:	ldr	x0, [x0, #0xab8]
   4105c:	ldr	x1, [sp, #0x1c0]
   41060:	ldr	x26, [x1, #0xac0]
   41064:	ldr	x14, [x1, #0xac8]
   41068:	ldr	x22, [x1, #0xad8]
   4106c:	stur	x22, [sp, #0x78]
   41070:	ldr	x9, [x1, #0xae0]
   41074:	stur	x9, [sp, #0x80]
   41078:	ldr	x12, [x1, #0xaf0]
   4107c:	ldr	x11, [x1, #0xaf8]
   41080:	ldr	x7, [x1, #0xb08]
   41084:	ldr	x6, [x1, #0xb10]
   41088:	ldr	x25, [x1, #0x10]
   4108c:	mov	x10, #0x1
   41090:	stur	x10, [sp, #0x58]
   41094:	str	x10, [x19, #0x54d0]
   41098:	add	x0, x3, x0
   4109c:	mov	w1, #0xb946
   410a0:	movk	w1, #0x1, lsl #16
   410a4:	madd	x4, x15, x1, x0
   410a8:	stur	x4, [sp, #0x50]
   410ac:	mov	x13, #0xf
   410b0:	b	0x410cc
   410b4:	ldur	x0, [sp, #0x48]
   410b8:	and	x0, x0, #0x3ffffffffffffff
   410bc:	eor	x0, x0, #0x3ffffffffffffff
   410c0:	str	x0, [x28, x1, lsl #3]
   410c4:	add	x9, x1, #0x1
   410c8:	stur	x9, [sp, #0x28]
   410cc:	ldur	x0, [sp, #0xc8]
   410d0:	ldr	x27, [sp, #0x1b0]
   410d4:	cmp	x0, x27
   410d8:	b.lo	0x411ec
   410dc:	mov	x0, #0x0
   410e0:	str	x0, [x19, #0x30]
   410e4:	mov	x1, #0x1000000000000000
   410e8:	str	x1, [x19, #0x38]
   410ec:	mov	x1, #0x1
   410f0:	str	x1, [x19, #0x48]
   410f4:	mov	x2, #0x101010101010101
   410f8:	str	x2, [x19, #0x50]
   410fc:	mov	x2, #0x2
   41100:	str	x2, [x19, #0x58]
   41104:	mov	x2, #0x3
   41108:	str	x2, [x19, #0x60]
   4110c:	mov	x2, #0x4
   41110:	str	x2, [x19, #0x68]
   41114:	mov	x2, #0xf0f0f0f0f0f0f0f
   41118:	str	x2, [x19, #0x90]
   4111c:	mov	x2, #0x3333333333333333
   41120:	str	x2, [x19, #0xa0]
   41124:	mov	x2, #0x38
   41128:	str	x2, [x19, #0xa8]
   4112c:	mov	x2, #0x3a
   41130:	str	x2, [x19, #0xb0]
   41134:	mov	x2, #0x5555555555555555
   41138:	str	x2, [x19, #0xc8]
   4113c:	mov	x2, #0x3ffffffffffffff
   41140:	str	x2, [x19, #0xd8]
   41144:	str	x0, [x19, #0x178]
   41148:	str	x1, [x19, #0x180]
   4114c:	ldur	x10, [sp, #0x58]
   41150:	str	x10, [x19, #0x54d0]
   41154:	str	x3, [x19, #0x54d8]
   41158:	ldur	x4, [sp, #0x60]
   4115c:	str	x4, [x19, #0x54e0]
   41160:	str	x24, [x19, #0x5818]
   41164:	str	x27, [x19, #0x5820]
   41168:	ldur	x24, [sp, #0x28]
   4116c:	str	x24, [x19, #0x6238]
   41170:	str	x15, [x19, #0x62a8]
   41174:	ldur	x23, [sp, #0x68]
   41178:	str	x23, [x19, #0x62b0]
   4117c:	ldur	x28, [sp, #0x70]
   41180:	str	x28, [x19, #0x62b8]
   41184:	ldur	x4, [sp, #0x50]
   41188:	sub	x13, x4, x3
   4118c:	mov	w0, #0xb946
   41190:	movk	w0, #0x1, lsl #16
   41194:	msub	x13, x15, x0, x13
   41198:	str	x13, [x19, #0x62c0]
   4119c:	str	x26, [x19, #0x62c8]
   411a0:	str	x14, [x19, #0x62d0]
   411a4:	ldur	x22, [sp, #0x78]
   411a8:	str	x22, [x19, #0x62e0]
   411ac:	ldur	x9, [sp, #0x80]
   411b0:	str	x9, [x19, #0x62e8]
   411b4:	str	x12, [x19, #0x62f8]
   411b8:	str	x11, [x19, #0x6300]
   411bc:	str	x7, [x19, #0x6310]
   411c0:	str	x6, [x19, #0x6318]
   411c4:	mov	x0, #0x0
   411c8:	mov	x1, #0x1
   411cc:	add	sp, sp, #0x1e0
   411d0:	ldp	x19, x20, [sp], #0x10
   411d4:	ldp	x21, x22, [sp], #0x10
   411d8:	ldp	x23, x24, [sp], #0x10
   411dc:	ldp	x25, x26, [sp], #0x10
   411e0:	ldp	x27, x28, [sp], #0x10
   411e4:	ldp	x29, x30, [sp], #0x10
   411e8:	.long	0xd65f0fff
   411ec:	add	x0, x23, #0x1
   411f0:	stur	x0, [sp, #0xc8]
   411f4:	cmp	x0, x23
   411f8:	b.lo	0x43538
   411fc:	mov	x8, #0x1
   41200:	stur	x8, [sp, #0x70]
   41204:	ldur	x2, [sp, #0x70]
   41208:	mov	x5, x19
   4120c:	stur	x20, [sp, #0x90]
   41210:	stur	x28, [sp, #0x98]
   41214:	b	0x3c260
   41218:	ldur	x20, [sp, #0x90]
   4121c:	ldur	x28, [sp, #0x98]
   41220:	add	x8, x14, #0x1
   41224:	cmp	x8, x14
   41228:	b.lo	0x43638
   4122c:	mov	x9, #0x1
   41230:	stur	x9, [sp, #0x20]
   41234:	mov	x14, x8
   41238:	stur	x2, [sp, #0x10]
   4123c:	stur	x4, [sp, #0x30]
   41240:	stur	x23, [sp, #0x38]
   41244:	stur	x1, [sp, #0x40]
   41248:	stur	x22, [sp, #0x48]
   4124c:	b	0x3f080
   41250:	ldur	x20, [sp, #0x90]
   41254:	ldur	x28, [sp, #0x98]
   41258:	add	x1, x11, #0x1
   4125c:	cmp	x1, x11
   41260:	b.lo	0x43760
   41264:	ldur	x2, [sp, #0xd0]
   41268:	ldur	x4, [sp, #0xd8]
   4126c:	mov	w8, #0xccd6
   41270:	movk	w8, #0x2, lsl #16
   41274:	sub	x6, x6, x8
   41278:	mov	x27, #0x1
   4127c:	mov	x23, x21
   41280:	mov	x22, x26
   41284:	mov	x11, x1
   41288:	mov	x4, x10
   4128c:	mov	x2, x3
   41290:	mov	x1, x24
   41294:	b	0x401e0
   41298:	ldur	x20, [sp, #0x90]
   4129c:	ldur	x28, [sp, #0x98]
   412a0:	add	x1, x5, #0x1
   412a4:	stur	x1, [sp, #0xb8]
   412a8:	cmp	x1, x5
   412ac:	b.lo	0x438a8
   412b0:	mov	x1, #0x1
   412b4:	stur	x1, [sp, #0x18]
   412b8:	mov	x23, x4
   412bc:	stur	x14, [sp, #0x10]
   412c0:	stur	x2, [sp, #0x40]
   412c4:	ldur	x1, [sp, #0xa0]
   412c8:	stur	x1, [sp, #0x48]
   412cc:	b	0x3ceac
   412d0:	ldur	x20, [sp, #0x90]
   412d4:	ldur	x28, [sp, #0x98]
   412d8:	add	x26, x9, #0x1
   412dc:	cmp	x26, x9
   412e0:	b.lo	0x439e0
   412e4:	mov	w10, #0xe176
   412e8:	movk	w10, #0x2, lsl #16
   412ec:	sub	x5, x5, x10
   412f0:	mov	x21, #0x1
   412f4:	mov	x0, x24
   412f8:	mov	x2, x3
   412fc:	mov	x4, x22
   41300:	mov	x14, x27
   41304:	stur	x1, [sp, #0xa0]
   41308:	stur	x21, [sp, #0xc0]
   4130c:	stur	x23, [sp, #0xf0]
   41310:	b	0x3e264
   41314:	mov	x25, x0
   41318:	b	0x43b34
   4131c:	mov	x25, x0
   41320:	b	0x43b34
   41324:	mov	w1, #0xb946
   41328:	movk	w1, #0x1, lsl #16
   4132c:	cmp	x3, x1
   41330:	b.lo	0x3c2bc
   41334:	mov	w1, #0x1
   41338:	uxtb	w4, w4
   4133c:	cbnz	x4, 0x3c2c4
   41340:	ldur	x1, [sp, #0x88]
   41344:	cmp	x24, x1
   41348:	b.ls	0x41360
   4134c:	mov	w1, #0x0
   41350:	ldur	x0, [sp, #0x60]
   41354:	mov	x4, x3
   41358:	ldur	x23, [sp, #0xc8]
   4135c:	b	0x3c354
   41360:	ldr	x1, [sp, #0x1b0]
   41364:	ldur	x23, [sp, #0xc8]
   41368:	cmp	x23, x1
   4136c:	b.lo	0x3c348
   41370:	b	0x3c2d4
   41374:	mov	x25, x0
   41378:	b	0x43b34
   4137c:	mov	x25, x0
   41380:	b	0x43b34
   41384:	mov	x5, #0x64c
   41388:	ldur	x20, [sp]
   4138c:	str	x5, [x20, #0x48]
   41390:	mov	x5, #0x0
   41394:	str	x5, [x19, #0x30]
   41398:	mov	x8, #0x1000000000000000
   4139c:	str	x8, [x19, #0x38]
   413a0:	mov	x8, #0x1
   413a4:	str	x8, [x19, #0x48]
   413a8:	mov	x9, #0x101010101010101
   413ac:	str	x9, [x19, #0x50]
   413b0:	mov	x20, #0x2
   413b4:	str	x20, [x19, #0x58]
   413b8:	mov	x9, #0x3
   413bc:	str	x9, [x19, #0x60]
   413c0:	mov	x9, #0x4
   413c4:	str	x9, [x19, #0x68]
   413c8:	mov	x9, #0xf0f0f0f0f0f0f0f
   413cc:	str	x9, [x19, #0x90]
   413d0:	mov	x9, #0x3333333333333333
   413d4:	str	x9, [x19, #0xa0]
   413d8:	mov	x9, #0x38
   413dc:	str	x9, [x19, #0xa8]
   413e0:	mov	x9, #0x3a
   413e4:	str	x9, [x19, #0xb0]
   413e8:	mov	x9, #0x5555555555555555
   413ec:	str	x9, [x19, #0xc8]
   413f0:	mov	x9, #0x3ffffffffffffff
   413f4:	str	x9, [x19, #0xd8]
   413f8:	str	x5, [x19, #0x178]
   413fc:	str	x8, [x19, #0x180]
   41400:	str	x23, [x19, #0x2140]
   41404:	str	x27, [x19, #0x2148]
   41408:	uxtb	w0, w0
   4140c:	str	x0, [x19, #0x2158]
   41410:	add	x0, x23, #0x1
   41414:	str	x0, [x19, #0x2170]
   41418:	ldur	x0, [sp, #0x58]
   4141c:	str	x0, [x19, #0x54d0]
   41420:	mov	w0, #0xb946
   41424:	movk	w0, #0x1, lsl #16
   41428:	sub	x3, x3, x0
   4142c:	str	x3, [x19, #0x54d8]
   41430:	str	x4, [x19, #0x54e0]
   41434:	str	x23, [x19, #0x5818]
   41438:	str	x27, [x19, #0x5820]
   4143c:	ldur	x24, [sp, #0x28]
   41440:	str	x24, [x19, #0x6238]
   41444:	add	x4, x15, #0x1
   41448:	str	x4, [x19, #0x62a8]
   4144c:	ldur	x23, [sp, #0x68]
   41450:	str	x23, [x19, #0x62b0]
   41454:	ldur	x28, [sp, #0x70]
   41458:	str	x28, [x19, #0x62b8]
   4145c:	ldur	x5, [sp, #0x50]
   41460:	sub	x3, x5, x3
   41464:	msub	x0, x4, x0, x3
   41468:	str	x0, [x19, #0x62c0]
   4146c:	str	x26, [x19, #0x62c8]
   41470:	str	x14, [x19, #0x62d0]
   41474:	str	x10, [x19, #0x62e0]
   41478:	ldur	x9, [sp, #0x80]
   4147c:	str	x9, [x19, #0x62e8]
   41480:	str	x12, [x19, #0x62f8]
   41484:	str	x11, [x19, #0x6300]
   41488:	str	x7, [x19, #0x6310]
   4148c:	str	x6, [x19, #0x6318]
   41490:	ldr	x0, [x19, #0x54d0]
   41494:	cmp	x0, #0x0
   41498:	b.ne	0x3c700
   4149c:	b	0x3c6f4
   414a0:	mov	x25, x0
   414a4:	b	0x43b34
   414a8:	mov	x25, x20
   414ac:	b	0x43b34
   414b0:	mov	x25, x0
   414b4:	b	0x43b34
   414b8:	mov	x25, x20
   414bc:	b	0x43b34
   414c0:	mov	x2, #0x64e
   414c4:	ldur	x20, [sp]
   414c8:	str	x2, [x20, #0x48]
   414cc:	mov	x2, #0x0
   414d0:	str	x2, [x19, #0x30]
   414d4:	mov	x5, #0x1000000000000000
   414d8:	str	x5, [x19, #0x38]
   414dc:	mov	x5, #0x1
   414e0:	str	x5, [x19, #0x48]
   414e4:	mov	x8, #0x101010101010101
   414e8:	str	x8, [x19, #0x50]
   414ec:	mov	x23, #0x2
   414f0:	str	x23, [x19, #0x58]
   414f4:	mov	x8, #0x3
   414f8:	str	x8, [x19, #0x60]
   414fc:	mov	x8, #0x4
   41500:	str	x8, [x19, #0x68]
   41504:	mov	x8, #0xf0f0f0f0f0f0f0f
   41508:	str	x8, [x19, #0x90]
   4150c:	mov	x8, #0x3333333333333333
   41510:	str	x8, [x19, #0xa0]
   41514:	mov	x8, #0x38
   41518:	str	x8, [x19, #0xa8]
   4151c:	mov	x8, #0x3a
   41520:	str	x8, [x19, #0xb0]
   41524:	mov	x8, #0x5555555555555555
   41528:	str	x8, [x19, #0xc8]
   4152c:	mov	x8, #0x3ffffffffffffff
   41530:	str	x8, [x19, #0xd8]
   41534:	str	x2, [x19, #0x178]
   41538:	str	x5, [x19, #0x180]
   4153c:	ldur	x8, [sp, #0xc8]
   41540:	str	x8, [x19, #0x2140]
   41544:	str	x27, [x19, #0x2148]
   41548:	uxtb	w0, w0
   4154c:	str	x0, [x19, #0x2158]
   41550:	str	x1, [x19, #0x2178]
   41554:	ldur	x13, [sp, #0xc8]
   41558:	add	x0, x13, #0x2
   4155c:	str	x0, [x19, #0x2180]
   41560:	ldur	x10, [sp, #0x58]
   41564:	str	x10, [x19, #0x54d0]
   41568:	mov	w0, #0xb946
   4156c:	movk	w0, #0x1, lsl #16
   41570:	sub	x1, x3, x0
   41574:	str	x1, [x19, #0x54d8]
   41578:	str	x4, [x19, #0x54e0]
   4157c:	ldur	x2, [sp, #0xc8]
   41580:	str	x2, [x19, #0x5818]
   41584:	str	x27, [x19, #0x5820]
   41588:	ldur	x24, [sp, #0x28]
   4158c:	str	x24, [x19, #0x6238]
   41590:	add	x2, x15, #0x1
   41594:	str	x2, [x19, #0x62a8]
   41598:	ldur	x8, [sp, #0x68]
   4159c:	str	x8, [x19, #0x62b0]
   415a0:	ldur	x28, [sp, #0x70]
   415a4:	str	x28, [x19, #0x62b8]
   415a8:	ldur	x4, [sp, #0x50]
   415ac:	sub	x1, x4, x1
   415b0:	msub	x0, x2, x0, x1
   415b4:	str	x0, [x19, #0x62c0]
   415b8:	str	x26, [x19, #0x62c8]
   415bc:	str	x14, [x19, #0x62d0]
   415c0:	ldur	x22, [sp, #0x78]
   415c4:	str	x22, [x19, #0x62e0]
   415c8:	ldur	x9, [sp, #0x80]
   415cc:	str	x9, [x19, #0x62e8]
   415d0:	str	x12, [x19, #0x62f8]
   415d4:	str	x11, [x19, #0x6300]
   415d8:	str	x7, [x19, #0x6310]
   415dc:	str	x6, [x19, #0x6318]
   415e0:	ldr	x0, [x19, #0x54d0]
   415e4:	cmp	x0, #0x0
   415e8:	b.ne	0x3c96c
   415ec:	b	0x3cb80
   415f0:	mov	x25, x0
   415f4:	b	0x43b34
   415f8:	mov	x25, x23
   415fc:	b	0x43b34
   41600:	mov	x25, x0
   41604:	b	0x43b34
   41608:	mov	x25, x23
   4160c:	b	0x43b34
   41610:	mov	x8, #0x650
   41614:	ldur	x20, [sp]
   41618:	str	x8, [x20, #0x48]
   4161c:	mov	x9, #0x0
   41620:	str	x9, [x19, #0x30]
   41624:	mov	x10, #0x1000000000000000
   41628:	str	x10, [x19, #0x38]
   4162c:	mov	x13, #0x1
   41630:	str	x13, [x19, #0x48]
   41634:	mov	x2, #0x101010101010101
   41638:	str	x2, [x19, #0x50]
   4163c:	mov	x20, #0x2
   41640:	str	x20, [x19, #0x58]
   41644:	mov	x2, #0x3
   41648:	str	x2, [x19, #0x60]
   4164c:	mov	x2, #0x4
   41650:	str	x2, [x19, #0x68]
   41654:	mov	x2, #0xf0f0f0f0f0f0f0f
   41658:	str	x2, [x19, #0x90]
   4165c:	mov	x2, #0x3333333333333333
   41660:	str	x2, [x19, #0xa0]
   41664:	mov	x2, #0x38
   41668:	str	x2, [x19, #0xa8]
   4166c:	mov	x2, #0x3a
   41670:	str	x2, [x19, #0xb0]
   41674:	mov	x2, #0x5555555555555555
   41678:	str	x2, [x19, #0xc8]
   4167c:	mov	x2, #0x3ffffffffffffff
   41680:	str	x2, [x19, #0xd8]
   41684:	str	x9, [x19, #0x178]
   41688:	str	x13, [x19, #0x180]
   4168c:	str	x23, [x19, #0x2140]
   41690:	str	x27, [x19, #0x2148]
   41694:	uxtb	w0, w0
   41698:	str	x0, [x19, #0x2158]
   4169c:	str	x1, [x19, #0x2178]
   416a0:	str	x5, [x19, #0x2188]
   416a4:	ldr	x0, [sp, #0x110]
   416a8:	str	x0, [x19, #0x2190]
   416ac:	ldur	x10, [sp, #0x58]
   416b0:	str	x10, [x19, #0x54d0]
   416b4:	mov	w0, #0xb946
   416b8:	movk	w0, #0x1, lsl #16
   416bc:	sub	x1, x3, x0
   416c0:	str	x1, [x19, #0x54d8]
   416c4:	str	x4, [x19, #0x54e0]
   416c8:	str	x23, [x19, #0x5818]
   416cc:	str	x27, [x19, #0x5820]
   416d0:	ldur	x24, [sp, #0x28]
   416d4:	str	x24, [x19, #0x6238]
   416d8:	add	x2, x15, #0x1
   416dc:	str	x2, [x19, #0x62a8]
   416e0:	ldur	x23, [sp, #0x68]
   416e4:	str	x23, [x19, #0x62b0]
   416e8:	ldur	x28, [sp, #0x70]
   416ec:	str	x28, [x19, #0x62b8]
   416f0:	ldur	x4, [sp, #0x50]
   416f4:	sub	x1, x4, x1
   416f8:	msub	x0, x2, x0, x1
   416fc:	str	x0, [x19, #0x62c0]
   41700:	str	x26, [x19, #0x62c8]
   41704:	str	x14, [x19, #0x62d0]
   41708:	ldur	x22, [sp, #0x78]
   4170c:	str	x22, [x19, #0x62e0]
   41710:	ldur	x9, [sp, #0x80]
   41714:	str	x9, [x19, #0x62e8]
   41718:	str	x12, [x19, #0x62f8]
   4171c:	str	x11, [x19, #0x6300]
   41720:	str	x7, [x19, #0x6310]
   41724:	str	x6, [x19, #0x6318]
   41728:	ldr	x0, [x19, #0x54d0]
   4172c:	cmp	x0, #0x0
   41730:	b.ne	0x3cbec
   41734:	b	0x3ce14
   41738:	mov	x25, x0
   4173c:	b	0x43b34
   41740:	mov	x25, x20
   41744:	b	0x43b34
   41748:	mov	x25, x0
   4174c:	b	0x43b34
   41750:	mov	x25, x20
   41754:	b	0x43b34
   41758:	mov	x25, x20
   4175c:	b	0x43b34
   41760:	mov	x13, #0x668
   41764:	ldur	x20, [sp]
   41768:	str	x13, [x20, #0x48]
   4176c:	mov	x13, #0x0
   41770:	str	x13, [x19, #0x30]
   41774:	mov	x2, #0x1000000000000000
   41778:	str	x2, [x19, #0x38]
   4177c:	mov	x2, #0x1
   41780:	str	x2, [x19, #0x48]
   41784:	mov	x4, #0x101010101010101
   41788:	str	x4, [x19, #0x50]
   4178c:	mov	x20, #0x2
   41790:	str	x20, [x19, #0x58]
   41794:	mov	x4, #0x3
   41798:	str	x4, [x19, #0x60]
   4179c:	mov	x4, #0x4
   417a0:	str	x4, [x19, #0x68]
   417a4:	mov	x4, #0xf0f0f0f0f0f0f0f
   417a8:	str	x4, [x19, #0x90]
   417ac:	mov	x4, #0x3333333333333333
   417b0:	str	x4, [x19, #0xa0]
   417b4:	mov	x4, #0x38
   417b8:	str	x4, [x19, #0xa8]
   417bc:	mov	x4, #0x3a
   417c0:	str	x4, [x19, #0xb0]
   417c4:	mov	x4, #0x5555555555555555
   417c8:	str	x4, [x19, #0xc8]
   417cc:	mov	x4, #0x3ffffffffffffff
   417d0:	str	x4, [x19, #0xd8]
   417d4:	str	x13, [x19, #0x178]
   417d8:	str	x2, [x19, #0x180]
   417dc:	ldur	x4, [sp, #0xc8]
   417e0:	str	x4, [x19, #0x2140]
   417e4:	ldr	x27, [sp, #0x1b0]
   417e8:	str	x27, [x19, #0x2148]
   417ec:	uxtb	w4, w26
   417f0:	str	x4, [x19, #0x2158]
   417f4:	str	x1, [x19, #0x21e8]
   417f8:	str	x14, [x19, #0x21f0]
   417fc:	ldur	x1, [sp, #0xc8]
   41800:	str	x1, [x19, #0x21f8]
   41804:	ldr	x26, [sp, #0x100]
   41808:	str	x26, [x19, #0x2200]
   4180c:	ldur	x14, [sp, #0xf8]
   41810:	uxtb	w1, w14
   41814:	str	x1, [x19, #0x2210]
   41818:	ldur	x14, [sp, #0xb8]
   4181c:	add	x1, x14, #0x1
   41820:	str	x1, [x19, #0x2220]
   41824:	ldur	x10, [sp, #0x58]
   41828:	str	x10, [x19, #0x54d0]
   4182c:	mov	w1, #0x1226
   41830:	movk	w1, #0x1, lsl #16
   41834:	sub	x1, x3, x1
   41838:	str	x1, [x19, #0x54d8]
   4183c:	ldur	x4, [sp, #0x60]
   41840:	str	x4, [x19, #0x54e0]
   41844:	ldur	x3, [sp, #0xc8]
   41848:	str	x3, [x19, #0x5818]
   4184c:	str	x27, [x19, #0x5820]
   41850:	str	x14, [x19, #0x58f8]
   41854:	ldr	x14, [sp, #0x108]
   41858:	str	x14, [x19, #0x5900]
   4185c:	str	x3, [x19, #0x5908]
   41860:	str	x26, [x19, #0x5910]
   41864:	ldur	x13, [sp, #0x10]
   41868:	str	x13, [x19, #0x5918]
   4186c:	str	x0, [x19, #0x5920]
   41870:	str	x23, [x19, #0x5928]
   41874:	ldur	x25, [sp, #0x40]
   41878:	str	x25, [x19, #0x5930]
   4187c:	ldur	x23, [sp, #0x48]
   41880:	str	x23, [x19, #0x5938]
   41884:	ldur	x24, [sp, #0x28]
   41888:	str	x24, [x19, #0x6238]
   4188c:	add	x0, x15, #0x1
   41890:	str	x0, [x19, #0x62a8]
   41894:	ldur	x23, [sp, #0x68]
   41898:	str	x23, [x19, #0x62b0]
   4189c:	ldur	x28, [sp, #0x70]
   418a0:	str	x28, [x19, #0x62b8]
   418a4:	ldur	x4, [sp, #0x50]
   418a8:	sub	x1, x4, x1
   418ac:	mov	w3, #0xb946
   418b0:	movk	w3, #0x1, lsl #16
   418b4:	msub	x0, x0, x3, x1
   418b8:	str	x0, [x19, #0x62c0]
   418bc:	str	x2, [x19, #0x62c8]
   418c0:	ldur	x14, [sp, #0x18]
   418c4:	str	x14, [x19, #0x62d0]
   418c8:	ldur	x22, [sp, #0x78]
   418cc:	str	x22, [x19, #0x62e0]
   418d0:	ldur	x9, [sp, #0x80]
   418d4:	str	x9, [x19, #0x62e8]
   418d8:	str	x12, [x19, #0x62f8]
   418dc:	str	x11, [x19, #0x6300]
   418e0:	str	x7, [x19, #0x6310]
   418e4:	str	x6, [x19, #0x6318]
   418e8:	ldr	x0, [x19, #0x54d0]
   418ec:	cmp	x0, #0x0
   418f0:	b.ne	0x3d2e0
   418f4:	b	0x3d4f4
   418f8:	mov	x25, x20
   418fc:	b	0x43b34
   41900:	mov	x25, x20
   41904:	b	0x43b34
   41908:	mov	x0, #0x669
   4190c:	ldur	x20, [sp]
   41910:	str	x0, [x20, #0x48]
   41914:	mov	x1, #0x0
   41918:	str	x1, [x19, #0x30]
   4191c:	mov	x0, #0x1000000000000000
   41920:	str	x0, [x19, #0x38]
   41924:	mov	x0, #0x1
   41928:	mov	x25, x0
   4192c:	str	x0, [x19, #0x48]
   41930:	mov	x0, #0x101010101010101
   41934:	str	x0, [x19, #0x50]
   41938:	mov	x0, #0x2
   4193c:	str	x0, [x19, #0x58]
   41940:	mov	x0, #0x3
   41944:	str	x0, [x19, #0x60]
   41948:	mov	x0, #0x4
   4194c:	str	x0, [x19, #0x68]
   41950:	mov	x0, #0xf0f0f0f0f0f0f0f
   41954:	str	x0, [x19, #0x90]
   41958:	mov	x0, #0x3333333333333333
   4195c:	str	x0, [x19, #0xa0]
   41960:	mov	x0, #0x38
   41964:	str	x0, [x19, #0xa8]
   41968:	mov	x0, #0x3a
   4196c:	str	x0, [x19, #0xb0]
   41970:	mov	x0, #0x5555555555555555
   41974:	str	x0, [x19, #0xc8]
   41978:	mov	x0, #0x3ffffffffffffff
   4197c:	str	x0, [x19, #0xd8]
   41980:	str	x1, [x19, #0x178]
   41984:	mov	x0, x25
   41988:	str	x0, [x19, #0x180]
   4198c:	ldur	x23, [sp, #0xc8]
   41990:	str	x23, [x19, #0x2140]
   41994:	ldr	x27, [sp, #0x1b0]
   41998:	str	x27, [x19, #0x2148]
   4199c:	uxtb	w0, w26
   419a0:	str	x0, [x19, #0x2158]
   419a4:	ldur	x8, [sp, #0xb8]
   419a8:	str	x8, [x19, #0x21e8]
   419ac:	ldr	x0, [sp, #0x108]
   419b0:	str	x0, [x19, #0x21f0]
   419b4:	str	x23, [x19, #0x21f8]
   419b8:	ldr	x26, [sp, #0x100]
   419bc:	str	x26, [x19, #0x2200]
   419c0:	ldur	x8, [sp, #0xf8]
   419c4:	uxtb	w0, w8
   419c8:	str	x0, [x19, #0x2210]
   419cc:	str	x14, [x19, #0x2228]
   419d0:	ldur	x10, [sp, #0x58]
   419d4:	str	x10, [x19, #0x54d0]
   419d8:	mov	w1, #0x1226
   419dc:	movk	w1, #0x1, lsl #16
   419e0:	sub	x1, x3, x1
   419e4:	str	x1, [x19, #0x54d8]
   419e8:	ldur	x4, [sp, #0x60]
   419ec:	str	x4, [x19, #0x54e0]
   419f0:	ldur	x24, [sp, #0x28]
   419f4:	str	x24, [x19, #0x6238]
   419f8:	add	x2, x15, #0x1
   419fc:	str	x2, [x19, #0x62a8]
   41a00:	ldur	x23, [sp, #0x68]
   41a04:	str	x23, [x19, #0x62b0]
   41a08:	ldur	x28, [sp, #0x70]
   41a0c:	str	x28, [x19, #0x62b8]
   41a10:	ldur	x4, [sp, #0x50]
   41a14:	sub	x1, x4, x1
   41a18:	mov	w3, #0xb946
   41a1c:	movk	w3, #0x1, lsl #16
   41a20:	msub	x0, x2, x3, x1
   41a24:	str	x0, [x19, #0x62c0]
   41a28:	mov	x0, x25
   41a2c:	str	x0, [x19, #0x62c8]
   41a30:	ldur	x14, [sp, #0x18]
   41a34:	str	x14, [x19, #0x62d0]
   41a38:	ldur	x22, [sp, #0x78]
   41a3c:	str	x22, [x19, #0x62e0]
   41a40:	ldur	x9, [sp, #0x80]
   41a44:	str	x9, [x19, #0x62e8]
   41a48:	str	x12, [x19, #0x62f8]
   41a4c:	str	x11, [x19, #0x6300]
   41a50:	str	x7, [x19, #0x6310]
   41a54:	str	x6, [x19, #0x6318]
   41a58:	b	0x43b34
   41a5c:	mov	x0, #0x66a
   41a60:	ldur	x20, [sp]
   41a64:	str	x0, [x20, #0x48]
   41a68:	mov	x2, #0x0
   41a6c:	str	x2, [x19, #0x30]
   41a70:	mov	x0, #0x1000000000000000
   41a74:	str	x0, [x19, #0x38]
   41a78:	mov	x0, #0x1
   41a7c:	str	x0, [x19, #0x48]
   41a80:	mov	x4, #0x101010101010101
   41a84:	str	x4, [x19, #0x50]
   41a88:	mov	x20, #0x2
   41a8c:	str	x20, [x19, #0x58]
   41a90:	mov	x4, #0x3
   41a94:	str	x4, [x19, #0x60]
   41a98:	mov	x4, #0x4
   41a9c:	str	x4, [x19, #0x68]
   41aa0:	mov	x4, #0xf0f0f0f0f0f0f0f
   41aa4:	str	x4, [x19, #0x90]
   41aa8:	mov	x5, #0x3333333333333333
   41aac:	str	x5, [x19, #0xa0]
   41ab0:	mov	x8, #0x38
   41ab4:	str	x8, [x19, #0xa8]
   41ab8:	mov	x8, #0x3a
   41abc:	str	x8, [x19, #0xb0]
   41ac0:	mov	x8, #0x5555555555555555
   41ac4:	str	x8, [x19, #0xc8]
   41ac8:	mov	x9, #0x3ffffffffffffff
   41acc:	str	x9, [x19, #0xd8]
   41ad0:	str	x2, [x19, #0x178]
   41ad4:	str	x0, [x19, #0x180]
   41ad8:	ldur	x23, [sp, #0xc8]
   41adc:	str	x23, [x19, #0x2140]
   41ae0:	ldr	x27, [sp, #0x1b0]
   41ae4:	str	x27, [x19, #0x2148]
   41ae8:	uxtb	w2, w26
   41aec:	str	x2, [x19, #0x2158]
   41af0:	ldur	x2, [sp, #0xb8]
   41af4:	str	x2, [x19, #0x21e8]
   41af8:	ldr	x2, [sp, #0x108]
   41afc:	str	x2, [x19, #0x21f0]
   41b00:	str	x23, [x19, #0x21f8]
   41b04:	ldr	x26, [sp, #0x100]
   41b08:	str	x26, [x19, #0x2200]
   41b0c:	ldur	x2, [sp, #0xf8]
   41b10:	uxtb	w2, w2
   41b14:	str	x2, [x19, #0x2210]
   41b18:	str	x14, [x19, #0x2228]
   41b1c:	str	x1, [x19, #0x2230]
   41b20:	ldur	x10, [sp, #0x58]
   41b24:	str	x10, [x19, #0x54d0]
   41b28:	mov	w1, #0x1226
   41b2c:	movk	w1, #0x1, lsl #16
   41b30:	sub	x1, x3, x1
   41b34:	str	x1, [x19, #0x54d8]
   41b38:	ldur	x4, [sp, #0x60]
   41b3c:	str	x4, [x19, #0x54e0]
   41b40:	str	x23, [x19, #0x5818]
   41b44:	str	x27, [x19, #0x5820]
   41b48:	ldur	x14, [sp, #0xb8]
   41b4c:	str	x14, [x19, #0x58f8]
   41b50:	ldr	x14, [sp, #0x108]
   41b54:	str	x14, [x19, #0x5900]
   41b58:	str	x23, [x19, #0x5908]
   41b5c:	str	x26, [x19, #0x5910]
   41b60:	ldur	x23, [sp, #0x10]
   41b64:	str	x23, [x19, #0x5918]
   41b68:	ldur	x26, [sp, #0x30]
   41b6c:	str	x26, [x19, #0x5920]
   41b70:	ldur	x23, [sp, #0x38]
   41b74:	str	x23, [x19, #0x5928]
   41b78:	ldur	x25, [sp, #0x40]
   41b7c:	str	x25, [x19, #0x5930]
   41b80:	ldur	x23, [sp, #0x48]
   41b84:	str	x23, [x19, #0x5938]
   41b88:	ldur	x24, [sp, #0x28]
   41b8c:	str	x24, [x19, #0x6238]
   41b90:	add	x2, x15, #0x1
   41b94:	str	x2, [x19, #0x62a8]
   41b98:	ldur	x23, [sp, #0x68]
   41b9c:	str	x23, [x19, #0x62b0]
   41ba0:	ldur	x28, [sp, #0x70]
   41ba4:	str	x28, [x19, #0x62b8]
   41ba8:	ldur	x4, [sp, #0x50]
   41bac:	sub	x1, x4, x1
   41bb0:	mov	w3, #0xb946
   41bb4:	movk	w3, #0x1, lsl #16
   41bb8:	msub	x1, x2, x3, x1
   41bbc:	str	x1, [x19, #0x62c0]
   41bc0:	str	x0, [x19, #0x62c8]
   41bc4:	ldur	x14, [sp, #0x18]
   41bc8:	str	x14, [x19, #0x62d0]
   41bcc:	ldur	x22, [sp, #0x78]
   41bd0:	str	x22, [x19, #0x62e0]
   41bd4:	ldur	x9, [sp, #0x80]
   41bd8:	str	x9, [x19, #0x62e8]
   41bdc:	str	x12, [x19, #0x62f8]
   41be0:	str	x11, [x19, #0x6300]
   41be4:	str	x7, [x19, #0x6310]
   41be8:	str	x6, [x19, #0x6318]
   41bec:	ldr	x0, [x19, #0x54d0]
   41bf0:	cmp	x0, #0x0
   41bf4:	b.ne	0x3d57c
   41bf8:	b	0x3d7b0
   41bfc:	mov	x25, x20
   41c00:	b	0x43b34
   41c04:	mov	x25, x20
   41c08:	b	0x43b34
   41c0c:	mov	x2, #0x66c
   41c10:	ldur	x20, [sp]
   41c14:	str	x2, [x20, #0x48]
   41c18:	mov	x4, #0x0
   41c1c:	str	x4, [x19, #0x30]
   41c20:	mov	x5, #0x1000000000000000
   41c24:	str	x5, [x19, #0x38]
   41c28:	mov	x5, #0x1
   41c2c:	str	x5, [x19, #0x48]
   41c30:	mov	x8, #0x101010101010101
   41c34:	str	x8, [x19, #0x50]
   41c38:	mov	x20, #0x2
   41c3c:	str	x20, [x19, #0x58]
   41c40:	mov	x8, #0x3
   41c44:	str	x8, [x19, #0x60]
   41c48:	mov	x9, #0x4
   41c4c:	str	x9, [x19, #0x68]
   41c50:	mov	x10, #0xf0f0f0f0f0f0f0f
   41c54:	str	x10, [x19, #0x90]
   41c58:	mov	x13, #0x3333333333333333
   41c5c:	str	x13, [x19, #0xa0]
   41c60:	mov	x13, #0x38
   41c64:	str	x13, [x19, #0xa8]
   41c68:	mov	x13, #0x3a
   41c6c:	str	x13, [x19, #0xb0]
   41c70:	mov	x0, #0x5555555555555555
   41c74:	str	x0, [x19, #0xc8]
   41c78:	mov	x0, #0x3ffffffffffffff
   41c7c:	str	x0, [x19, #0xd8]
   41c80:	str	x4, [x19, #0x178]
   41c84:	str	x5, [x19, #0x180]
   41c88:	ldur	x23, [sp, #0xc8]
   41c8c:	str	x23, [x19, #0x2140]
   41c90:	ldr	x27, [sp, #0x1b0]
   41c94:	str	x27, [x19, #0x2148]
   41c98:	ldr	x0, [sp, #0x118]
   41c9c:	uxtb	w0, w0
   41ca0:	str	x0, [x19, #0x2158]
   41ca4:	ldur	x0, [sp, #0xb8]
   41ca8:	str	x0, [x19, #0x21e8]
   41cac:	ldr	x0, [sp, #0x108]
   41cb0:	str	x0, [x19, #0x21f0]
   41cb4:	str	x23, [x19, #0x21f8]
   41cb8:	ldr	x0, [sp, #0x100]
   41cbc:	str	x0, [x19, #0x2200]
   41cc0:	ldur	x0, [sp, #0xf8]
   41cc4:	uxtb	w0, w0
   41cc8:	str	x0, [x19, #0x2210]
   41ccc:	str	x26, [x19, #0x2238]
   41cd0:	add	x0, x14, #0x2
   41cd4:	str	x0, [x19, #0x2240]
   41cd8:	ldur	x10, [sp, #0x58]
   41cdc:	str	x10, [x19, #0x54d0]
   41ce0:	mov	w0, #0x1226
   41ce4:	movk	w0, #0x1, lsl #16
   41ce8:	sub	x0, x3, x0
   41cec:	str	x0, [x19, #0x54d8]
   41cf0:	ldur	x4, [sp, #0x60]
   41cf4:	str	x4, [x19, #0x54e0]
   41cf8:	str	x23, [x19, #0x5818]
   41cfc:	str	x27, [x19, #0x5820]
   41d00:	ldur	x14, [sp, #0xb8]
   41d04:	str	x14, [x19, #0x58f8]
   41d08:	ldr	x14, [sp, #0x108]
   41d0c:	str	x14, [x19, #0x5900]
   41d10:	str	x23, [x19, #0x5908]
   41d14:	ldr	x26, [sp, #0x100]
   41d18:	str	x26, [x19, #0x5910]
   41d1c:	ldur	x23, [sp, #0x10]
   41d20:	str	x23, [x19, #0x5918]
   41d24:	ldur	x26, [sp, #0x30]
   41d28:	str	x26, [x19, #0x5920]
   41d2c:	ldur	x23, [sp, #0x38]
   41d30:	str	x23, [x19, #0x5928]
   41d34:	ldur	x25, [sp, #0x40]
   41d38:	str	x25, [x19, #0x5930]
   41d3c:	ldur	x23, [sp, #0x48]
   41d40:	str	x23, [x19, #0x5938]
   41d44:	ldur	x24, [sp, #0x28]
   41d48:	str	x24, [x19, #0x6238]
   41d4c:	add	x1, x15, #0x1
   41d50:	str	x1, [x19, #0x62a8]
   41d54:	ldur	x23, [sp, #0x68]
   41d58:	str	x23, [x19, #0x62b0]
   41d5c:	ldur	x28, [sp, #0x70]
   41d60:	str	x28, [x19, #0x62b8]
   41d64:	ldur	x4, [sp, #0x50]
   41d68:	sub	x0, x4, x0
   41d6c:	mov	w2, #0xb946
   41d70:	movk	w2, #0x1, lsl #16
   41d74:	msub	x0, x1, x2, x0
   41d78:	str	x0, [x19, #0x62c0]
   41d7c:	str	x5, [x19, #0x62c8]
   41d80:	ldur	x14, [sp, #0x18]
   41d84:	str	x14, [x19, #0x62d0]
   41d88:	ldur	x22, [sp, #0x78]
   41d8c:	str	x22, [x19, #0x62e0]
   41d90:	ldur	x9, [sp, #0x80]
   41d94:	str	x9, [x19, #0x62e8]
   41d98:	str	x12, [x19, #0x62f8]
   41d9c:	str	x11, [x19, #0x6300]
   41da0:	str	x7, [x19, #0x6310]
   41da4:	str	x6, [x19, #0x6318]
   41da8:	ldr	x0, [x19, #0x54d0]
   41dac:	cmp	x0, #0x0
   41db0:	b.ne	0x3d820
   41db4:	b	0x3da3c
   41db8:	mov	x25, x20
   41dbc:	b	0x43b34
   41dc0:	mov	x25, x20
   41dc4:	b	0x43b34
   41dc8:	mov	x0, #0x682
   41dcc:	ldur	x20, [sp]
   41dd0:	str	x0, [x20, #0x48]
   41dd4:	mov	x0, #0x0
   41dd8:	str	x0, [x19, #0x30]
   41ddc:	mov	x2, #0x1000000000000000
   41de0:	str	x2, [x19, #0x38]
   41de4:	mov	x2, #0x1
   41de8:	str	x2, [x19, #0x48]
   41dec:	mov	x3, #0x101010101010101
   41df0:	str	x3, [x19, #0x50]
   41df4:	mov	x20, #0x2
   41df8:	str	x20, [x19, #0x58]
   41dfc:	mov	x3, #0x3
   41e00:	str	x3, [x19, #0x60]
   41e04:	mov	x3, #0x4
   41e08:	str	x3, [x19, #0x68]
   41e0c:	mov	x3, #0xf0f0f0f0f0f0f0f
   41e10:	str	x3, [x19, #0x90]
   41e14:	mov	x3, #0x3333333333333333
   41e18:	str	x3, [x19, #0xa0]
   41e1c:	mov	x3, #0x38
   41e20:	str	x3, [x19, #0xa8]
   41e24:	mov	x3, #0x3a
   41e28:	str	x3, [x19, #0xb0]
   41e2c:	mov	x3, #0x5555555555555555
   41e30:	str	x3, [x19, #0xc8]
   41e34:	mov	x3, #0x3ffffffffffffff
   41e38:	str	x3, [x19, #0xd8]
   41e3c:	str	x0, [x19, #0x178]
   41e40:	str	x2, [x19, #0x180]
   41e44:	ldur	x23, [sp, #0xc8]
   41e48:	str	x23, [x19, #0x2140]
   41e4c:	ldr	x27, [sp, #0x1b0]
   41e50:	str	x27, [x19, #0x2148]
   41e54:	ldr	x0, [sp, #0x118]
   41e58:	uxtb	w0, w0
   41e5c:	str	x0, [x19, #0x2158]
   41e60:	ldur	x14, [sp, #0xb8]
   41e64:	str	x14, [x19, #0x21e8]
   41e68:	ldr	x14, [sp, #0x108]
   41e6c:	str	x14, [x19, #0x21f0]
   41e70:	str	x23, [x19, #0x21f8]
   41e74:	ldr	x0, [sp, #0x100]
   41e78:	str	x0, [x19, #0x2200]
   41e7c:	ldur	x14, [sp, #0xf8]
   41e80:	uxtb	w0, w14
   41e84:	str	x0, [x19, #0x2210]
   41e88:	str	x26, [x19, #0x2288]
   41e8c:	str	x8, [x19, #0x2290]
   41e90:	str	x23, [x19, #0x2298]
   41e94:	ldr	x0, [sp, #0x100]
   41e98:	str	x0, [x19, #0x22a0]
   41e9c:	uxtb	w0, w1
   41ea0:	str	x0, [x19, #0x22b0]
   41ea4:	add	x0, x26, #0x1
   41ea8:	str	x0, [x19, #0x22c0]
   41eac:	ldur	x10, [sp, #0x58]
   41eb0:	str	x10, [x19, #0x54d0]
   41eb4:	mov	w3, #0xe176
   41eb8:	movk	w3, #0x2, lsl #16
   41ebc:	sub	x3, x5, x3
   41ec0:	str	x3, [x19, #0x54d8]
   41ec4:	ldur	x4, [sp, #0x60]
   41ec8:	str	x4, [x19, #0x54e0]
   41ecc:	str	x23, [x19, #0x5818]
   41ed0:	str	x27, [x19, #0x5820]
   41ed4:	ldur	x14, [sp, #0xb8]
   41ed8:	str	x14, [x19, #0x58f8]
   41edc:	ldr	x14, [sp, #0x108]
   41ee0:	str	x14, [x19, #0x5900]
   41ee4:	str	x23, [x19, #0x5908]
   41ee8:	ldr	x0, [sp, #0x100]
   41eec:	str	x0, [x19, #0x5910]
   41ef0:	ldur	x23, [sp, #0x10]
   41ef4:	str	x23, [x19, #0x5918]
   41ef8:	ldur	x0, [sp, #0x30]
   41efc:	str	x0, [x19, #0x5920]
   41f00:	ldur	x23, [sp, #0x38]
   41f04:	str	x23, [x19, #0x5928]
   41f08:	ldur	x25, [sp, #0x40]
   41f0c:	str	x25, [x19, #0x5930]
   41f10:	ldur	x23, [sp, #0x48]
   41f14:	str	x23, [x19, #0x5938]
   41f18:	str	x26, [x19, #0x5a70]
   41f1c:	str	x8, [x19, #0x5a78]
   41f20:	ldur	x23, [sp, #0xc8]
   41f24:	str	x23, [x19, #0x5a80]
   41f28:	ldr	x26, [sp, #0x100]
   41f2c:	str	x26, [x19, #0x5a88]
   41f30:	mov	x14, x28
   41f34:	str	x14, [x19, #0x5a90]
   41f38:	mov	x0, x21
   41f3c:	str	x0, [x19, #0x5a98]
   41f40:	mov	x0, x24
   41f44:	str	x0, [x19, #0x5aa0]
   41f48:	mov	x14, x22
   41f4c:	str	x14, [x19, #0x5aa8]
   41f50:	ldur	x0, [sp, #0xa0]
   41f54:	str	x0, [x19, #0x5ab0]
   41f58:	ldur	x24, [sp, #0x28]
   41f5c:	str	x24, [x19, #0x6238]
   41f60:	add	x0, x15, #0x1
   41f64:	str	x0, [x19, #0x62a8]
   41f68:	ldur	x23, [sp, #0x68]
   41f6c:	str	x23, [x19, #0x62b0]
   41f70:	ldur	x28, [sp, #0x70]
   41f74:	str	x28, [x19, #0x62b8]
   41f78:	ldur	x4, [sp, #0x50]
   41f7c:	sub	x1, x4, x3
   41f80:	mov	w3, #0xb946
   41f84:	movk	w3, #0x1, lsl #16
   41f88:	msub	x0, x0, x3, x1
   41f8c:	str	x0, [x19, #0x62c0]
   41f90:	str	x2, [x19, #0x62c8]
   41f94:	ldur	x14, [sp, #0x18]
   41f98:	str	x14, [x19, #0x62d0]
   41f9c:	str	x2, [x19, #0x62e0]
   41fa0:	ldur	x21, [sp, #0xc0]
   41fa4:	str	x21, [x19, #0x62e8]
   41fa8:	str	x12, [x19, #0x62f8]
   41fac:	str	x11, [x19, #0x6300]
   41fb0:	str	x7, [x19, #0x6310]
   41fb4:	str	x6, [x19, #0x6318]
   41fb8:	ldr	x0, [x19, #0x54d0]
   41fbc:	cmp	x0, #0x0
   41fc0:	b.ne	0x3db94
   41fc4:	b	0x3ddc4
   41fc8:	mov	x25, x20
   41fcc:	b	0x43b34
   41fd0:	mov	x25, x20
   41fd4:	b	0x43b34
   41fd8:	mov	x2, #0x68a
   41fdc:	ldur	x20, [sp]
   41fe0:	str	x2, [x20, #0x48]
   41fe4:	mov	x2, #0x0
   41fe8:	str	x2, [x19, #0x30]
   41fec:	mov	x3, #0x1000000000000000
   41ff0:	str	x3, [x19, #0x38]
   41ff4:	mov	x13, #0x1
   41ff8:	str	x13, [x19, #0x48]
   41ffc:	mov	x3, #0x101010101010101
   42000:	str	x3, [x19, #0x50]
   42004:	str	x23, [x19, #0x58]
   42008:	mov	x4, #0x3
   4200c:	str	x4, [x19, #0x60]
   42010:	mov	x9, #0x4
   42014:	str	x9, [x19, #0x68]
   42018:	mov	x9, #0xf0f0f0f0f0f0f0f
   4201c:	str	x9, [x19, #0x90]
   42020:	mov	x9, #0x3333333333333333
   42024:	str	x9, [x19, #0xa0]
   42028:	mov	x9, #0x38
   4202c:	str	x9, [x19, #0xa8]
   42030:	mov	x9, #0x3a
   42034:	str	x9, [x19, #0xb0]
   42038:	mov	x3, #0x5555555555555555
   4203c:	str	x3, [x19, #0xc8]
   42040:	mov	x3, #0x3ffffffffffffff
   42044:	str	x3, [x19, #0xd8]
   42048:	str	x2, [x19, #0x178]
   4204c:	str	x13, [x19, #0x180]
   42050:	ldur	x2, [sp, #0xc8]
   42054:	str	x2, [x19, #0x2140]
   42058:	ldr	x27, [sp, #0x1b0]
   4205c:	str	x27, [x19, #0x2148]
   42060:	ldr	x2, [sp, #0x118]
   42064:	uxtb	w2, w2
   42068:	str	x2, [x19, #0x2158]
   4206c:	ldur	x2, [sp, #0xb8]
   42070:	str	x2, [x19, #0x21e8]
   42074:	ldr	x2, [sp, #0x108]
   42078:	str	x2, [x19, #0x21f0]
   4207c:	ldur	x2, [sp, #0xc8]
   42080:	str	x2, [x19, #0x21f8]
   42084:	ldr	x2, [sp, #0x100]
   42088:	str	x2, [x19, #0x2200]
   4208c:	ldur	x2, [sp, #0xf8]
   42090:	uxtb	w2, w2
   42094:	str	x2, [x19, #0x2210]
   42098:	str	x26, [x19, #0x2288]
   4209c:	str	x8, [x19, #0x2290]
   420a0:	ldur	x2, [sp, #0xc8]
   420a4:	str	x2, [x19, #0x2298]
   420a8:	ldr	x2, [sp, #0x100]
   420ac:	str	x2, [x19, #0x22a0]
   420b0:	uxtb	w1, w1
   420b4:	str	x1, [x19, #0x22b0]
   420b8:	str	x10, [x19, #0x22d0]
   420bc:	add	x1, x10, #0x1
   420c0:	str	x1, [x19, #0x22e8]
   420c4:	ldur	x10, [sp, #0x58]
   420c8:	str	x10, [x19, #0x54d0]
   420cc:	mov	w1, #0xe176
   420d0:	movk	w1, #0x2, lsl #16
   420d4:	sub	x1, x5, x1
   420d8:	str	x1, [x19, #0x54d8]
   420dc:	ldur	x4, [sp, #0x60]
   420e0:	str	x4, [x19, #0x54e0]
   420e4:	ldur	x2, [sp, #0xc8]
   420e8:	str	x2, [x19, #0x5818]
   420ec:	str	x27, [x19, #0x5820]
   420f0:	ldur	x10, [sp, #0xb8]
   420f4:	str	x10, [x19, #0x58f8]
   420f8:	ldr	x2, [sp, #0x108]
   420fc:	str	x2, [x19, #0x5900]
   42100:	ldur	x2, [sp, #0xc8]
   42104:	str	x2, [x19, #0x5908]
   42108:	ldr	x2, [sp, #0x100]
   4210c:	str	x2, [x19, #0x5910]
   42110:	ldur	x2, [sp, #0x10]
   42114:	str	x2, [x19, #0x5918]
   42118:	ldur	x2, [sp, #0x30]
   4211c:	str	x2, [x19, #0x5920]
   42120:	ldur	x2, [sp, #0x38]
   42124:	str	x2, [x19, #0x5928]
   42128:	ldur	x25, [sp, #0x40]
   4212c:	str	x25, [x19, #0x5930]
   42130:	ldur	x2, [sp, #0x48]
   42134:	str	x2, [x19, #0x5938]
   42138:	str	x26, [x19, #0x5a70]
   4213c:	str	x8, [x19, #0x5a78]
   42140:	ldur	x2, [sp, #0xc8]
   42144:	str	x2, [x19, #0x5a80]
   42148:	ldr	x26, [sp, #0x100]
   4214c:	str	x26, [x19, #0x5a88]
   42150:	str	x14, [x19, #0x5a90]
   42154:	str	x0, [x19, #0x5a98]
   42158:	mov	x4, x24
   4215c:	str	x4, [x19, #0x5aa0]
   42160:	mov	x2, x22
   42164:	str	x2, [x19, #0x5aa8]
   42168:	ldur	x2, [sp, #0xa0]
   4216c:	str	x2, [x19, #0x5ab0]
   42170:	ldur	x24, [sp, #0x28]
   42174:	str	x24, [x19, #0x6238]
   42178:	add	x0, x15, #0x1
   4217c:	str	x0, [x19, #0x62a8]
   42180:	ldur	x2, [sp, #0x68]
   42184:	str	x2, [x19, #0x62b0]
   42188:	ldur	x28, [sp, #0x70]
   4218c:	str	x28, [x19, #0x62b8]
   42190:	ldur	x4, [sp, #0x50]
   42194:	sub	x1, x4, x1
   42198:	mov	w2, #0xb946
   4219c:	movk	w2, #0x1, lsl #16
   421a0:	msub	x0, x0, x2, x1
   421a4:	str	x0, [x19, #0x62c0]
   421a8:	str	x13, [x19, #0x62c8]
   421ac:	ldur	x14, [sp, #0x18]
   421b0:	str	x14, [x19, #0x62d0]
   421b4:	str	x13, [x19, #0x62e0]
   421b8:	str	x21, [x19, #0x62e8]
   421bc:	str	x12, [x19, #0x62f8]
   421c0:	str	x11, [x19, #0x6300]
   421c4:	str	x7, [x19, #0x6310]
   421c8:	str	x6, [x19, #0x6318]
   421cc:	ldr	x2, [x19, #0x54d0]
   421d0:	cmp	x2, #0x0
   421d4:	b.ne	0x3de78
   421d8:	b	0x3e094
   421dc:	mov	x25, x23
   421e0:	b	0x43b34
   421e4:	mov	x25, x23
   421e8:	b	0x43b34
   421ec:	mov	x0, #0x704
   421f0:	ldur	x20, [sp]
   421f4:	str	x0, [x20, #0x48]
   421f8:	mov	x1, #0x0
   421fc:	str	x1, [x19, #0x30]
   42200:	mov	x0, #0x1000000000000000
   42204:	str	x0, [x19, #0x38]
   42208:	mov	x0, #0x1
   4220c:	mov	x25, x0
   42210:	str	x0, [x19, #0x48]
   42214:	mov	x0, #0x101010101010101
   42218:	str	x0, [x19, #0x50]
   4221c:	mov	x0, #0x2
   42220:	str	x0, [x19, #0x58]
   42224:	mov	x0, #0x3
   42228:	str	x0, [x19, #0x60]
   4222c:	mov	x0, #0x4
   42230:	str	x0, [x19, #0x68]
   42234:	mov	x0, #0xf0f0f0f0f0f0f0f
   42238:	str	x0, [x19, #0x90]
   4223c:	mov	x0, #0x3333333333333333
   42240:	str	x0, [x19, #0xa0]
   42244:	mov	x0, #0x38
   42248:	str	x0, [x19, #0xa8]
   4224c:	mov	x0, #0x3a
   42250:	str	x0, [x19, #0xb0]
   42254:	mov	x0, #0x5555555555555555
   42258:	str	x0, [x19, #0xc8]
   4225c:	mov	x0, #0x3ffffffffffffff
   42260:	str	x0, [x19, #0xd8]
   42264:	str	x1, [x19, #0x178]
   42268:	mov	x0, x25
   4226c:	str	x0, [x19, #0x180]
   42270:	ldur	x23, [sp, #0xc8]
   42274:	str	x23, [x19, #0x2140]
   42278:	ldr	x27, [sp, #0x1b0]
   4227c:	str	x27, [x19, #0x2148]
   42280:	ldr	x0, [sp, #0x118]
   42284:	uxtb	w0, w0
   42288:	str	x0, [x19, #0x2158]
   4228c:	ldur	x14, [sp, #0xb8]
   42290:	str	x14, [x19, #0x21e8]
   42294:	ldr	x14, [sp, #0x108]
   42298:	str	x14, [x19, #0x21f0]
   4229c:	str	x23, [x19, #0x21f8]
   422a0:	ldr	x26, [sp, #0x100]
   422a4:	str	x26, [x19, #0x2200]
   422a8:	ldur	x14, [sp, #0xf8]
   422ac:	uxtb	w1, w14
   422b0:	str	x1, [x19, #0x2210]
   422b4:	str	x9, [x19, #0x2288]
   422b8:	str	x8, [x19, #0x2290]
   422bc:	str	x23, [x19, #0x2298]
   422c0:	str	x26, [x19, #0x22a0]
   422c4:	ldur	x10, [sp, #0x58]
   422c8:	str	x10, [x19, #0x54d0]
   422cc:	mov	w8, #0xe176
   422d0:	movk	w8, #0x2, lsl #16
   422d4:	sub	x8, x5, x8
   422d8:	str	x8, [x19, #0x54d8]
   422dc:	ldur	x4, [sp, #0x60]
   422e0:	str	x4, [x19, #0x54e0]
   422e4:	ldur	x24, [sp, #0x28]
   422e8:	str	x24, [x19, #0x6238]
   422ec:	add	x10, x15, #0x1
   422f0:	str	x10, [x19, #0x62a8]
   422f4:	ldur	x23, [sp, #0x68]
   422f8:	str	x23, [x19, #0x62b0]
   422fc:	ldur	x28, [sp, #0x70]
   42300:	str	x28, [x19, #0x62b8]
   42304:	ldur	x4, [sp, #0x50]
   42308:	sub	x13, x4, x8
   4230c:	mov	w14, #0xb946
   42310:	movk	w14, #0x1, lsl #16
   42314:	msub	x13, x10, x14, x13
   42318:	str	x13, [x19, #0x62c0]
   4231c:	mov	x0, x25
   42320:	str	x0, [x19, #0x62c8]
   42324:	ldur	x14, [sp, #0x18]
   42328:	str	x14, [x19, #0x62d0]
   4232c:	str	x0, [x19, #0x62e0]
   42330:	str	x21, [x19, #0x62e8]
   42334:	str	x12, [x19, #0x62f8]
   42338:	str	x11, [x19, #0x6300]
   4233c:	str	x7, [x19, #0x6310]
   42340:	str	x6, [x19, #0x6318]
   42344:	b	0x43b34
   42348:	ldur	x25, [sp, #0xf0]
   4234c:	b	0x43b34
   42350:	mov	x1, #0x68a
   42354:	ldur	x20, [sp]
   42358:	str	x1, [x20, #0x48]
   4235c:	mov	x20, x1
   42360:	mov	x1, #0x0
   42364:	str	x1, [x19, #0x30]
   42368:	mov	x13, #0x1000000000000000
   4236c:	str	x13, [x19, #0x38]
   42370:	mov	x13, #0x1
   42374:	str	x13, [x19, #0x48]
   42378:	mov	x3, #0x101010101010101
   4237c:	str	x3, [x19, #0x50]
   42380:	ldur	x23, [sp, #0xf0]
   42384:	str	x23, [x19, #0x58]
   42388:	mov	x3, #0x3
   4238c:	str	x3, [x19, #0x60]
   42390:	mov	x3, #0x4
   42394:	str	x3, [x19, #0x68]
   42398:	mov	x3, #0xf0f0f0f0f0f0f0f
   4239c:	str	x3, [x19, #0x90]
   423a0:	mov	x3, #0x3333333333333333
   423a4:	str	x3, [x19, #0xa0]
   423a8:	mov	x3, #0x38
   423ac:	str	x3, [x19, #0xa8]
   423b0:	mov	x3, #0x3a
   423b4:	str	x3, [x19, #0xb0]
   423b8:	mov	x3, #0x5555555555555555
   423bc:	str	x3, [x19, #0xc8]
   423c0:	mov	x3, #0x3ffffffffffffff
   423c4:	str	x3, [x19, #0xd8]
   423c8:	str	x1, [x19, #0x178]
   423cc:	str	x13, [x19, #0x180]
   423d0:	ldur	x1, [sp, #0xc8]
   423d4:	str	x1, [x19, #0x2140]
   423d8:	ldr	x27, [sp, #0x1b0]
   423dc:	str	x27, [x19, #0x2148]
   423e0:	ldr	x1, [sp, #0x118]
   423e4:	uxtb	w1, w1
   423e8:	str	x1, [x19, #0x2158]
   423ec:	ldur	x1, [sp, #0xb8]
   423f0:	str	x1, [x19, #0x21e8]
   423f4:	ldr	x1, [sp, #0x108]
   423f8:	str	x1, [x19, #0x21f0]
   423fc:	ldur	x1, [sp, #0xc8]
   42400:	str	x1, [x19, #0x21f8]
   42404:	ldr	x1, [sp, #0x100]
   42408:	str	x1, [x19, #0x2200]
   4240c:	ldur	x1, [sp, #0xf8]
   42410:	uxtb	w1, w1
   42414:	str	x1, [x19, #0x2210]
   42418:	str	x26, [x19, #0x2288]
   4241c:	str	x8, [x19, #0x2290]
   42420:	ldur	x1, [sp, #0xc8]
   42424:	str	x1, [x19, #0x2298]
   42428:	ldr	x1, [sp, #0x100]
   4242c:	str	x1, [x19, #0x22a0]
   42430:	uxtb	w1, w9
   42434:	str	x1, [x19, #0x22b0]
   42438:	str	x10, [x19, #0x22d0]
   4243c:	add	x1, x10, #0x1
   42440:	str	x1, [x19, #0x22e8]
   42444:	ldur	x10, [sp, #0x58]
   42448:	str	x10, [x19, #0x54d0]
   4244c:	mov	w1, #0xe176
   42450:	movk	w1, #0x2, lsl #16
   42454:	sub	x1, x5, x1
   42458:	str	x1, [x19, #0x54d8]
   4245c:	ldur	x3, [sp, #0x60]
   42460:	str	x3, [x19, #0x54e0]
   42464:	ldur	x3, [sp, #0xc8]
   42468:	str	x3, [x19, #0x5818]
   4246c:	str	x27, [x19, #0x5820]
   42470:	ldur	x3, [sp, #0xb8]
   42474:	str	x3, [x19, #0x58f8]
   42478:	ldr	x3, [sp, #0x108]
   4247c:	str	x3, [x19, #0x5900]
   42480:	ldur	x3, [sp, #0xc8]
   42484:	str	x3, [x19, #0x5908]
   42488:	ldr	x3, [sp, #0x100]
   4248c:	str	x3, [x19, #0x5910]
   42490:	ldur	x3, [sp, #0x10]
   42494:	str	x3, [x19, #0x5918]
   42498:	ldur	x3, [sp, #0x30]
   4249c:	str	x3, [x19, #0x5920]
   424a0:	ldur	x3, [sp, #0x38]
   424a4:	str	x3, [x19, #0x5928]
   424a8:	ldur	x25, [sp, #0x40]
   424ac:	str	x25, [x19, #0x5930]
   424b0:	ldur	x3, [sp, #0x48]
   424b4:	str	x3, [x19, #0x5938]
   424b8:	str	x26, [x19, #0x5a70]
   424bc:	str	x8, [x19, #0x5a78]
   424c0:	ldur	x3, [sp, #0xc8]
   424c4:	str	x3, [x19, #0x5a80]
   424c8:	ldr	x26, [sp, #0x100]
   424cc:	str	x26, [x19, #0x5a88]
   424d0:	str	x14, [x19, #0x5a90]
   424d4:	str	x0, [x19, #0x5a98]
   424d8:	str	x4, [x19, #0x5aa0]
   424dc:	str	x2, [x19, #0x5aa8]
   424e0:	ldur	x2, [sp, #0xa0]
   424e4:	str	x2, [x19, #0x5ab0]
   424e8:	ldur	x24, [sp, #0x28]
   424ec:	str	x24, [x19, #0x6238]
   424f0:	add	x2, x15, #0x1
   424f4:	str	x2, [x19, #0x62a8]
   424f8:	ldur	x0, [sp, #0x68]
   424fc:	str	x0, [x19, #0x62b0]
   42500:	ldur	x28, [sp, #0x70]
   42504:	str	x28, [x19, #0x62b8]
   42508:	ldur	x4, [sp, #0x50]
   4250c:	sub	x5, x4, x1
   42510:	mov	w8, #0xb946
   42514:	movk	w8, #0x1, lsl #16
   42518:	msub	x5, x2, x8, x5
   4251c:	str	x5, [x19, #0x62c0]
   42520:	str	x13, [x19, #0x62c8]
   42524:	ldur	x14, [sp, #0x18]
   42528:	str	x14, [x19, #0x62d0]
   4252c:	str	x13, [x19, #0x62e0]
   42530:	str	x21, [x19, #0x62e8]
   42534:	str	x12, [x19, #0x62f8]
   42538:	str	x11, [x19, #0x6300]
   4253c:	str	x7, [x19, #0x6310]
   42540:	str	x6, [x19, #0x6318]
   42544:	ldr	x14, [x19, #0x54d0]
   42548:	cmp	x14, #0x0
   4254c:	b.ne	0x3e754
   42550:	b	0x3e970
   42554:	mov	x25, x23
   42558:	b	0x43b34
   4255c:	mov	x25, x23
   42560:	b	0x43b34
   42564:	mov	x1, #0x0
   42568:	str	x1, [x25, #0x1180]
   4256c:	str	x1, [x25, #0x1188]
   42570:	str	x1, [x25, #0x1190]
   42574:	str	x1, [x25, #0x1198]
   42578:	str	x1, [x25, #0x11a0]
   4257c:	str	x1, [x25, #0x11a8]
   42580:	str	x1, [x25, #0x11b0]
   42584:	str	x1, [x25, #0x11b8]
   42588:	str	x1, [x25, #0x11c0]
   4258c:	str	x1, [x25, #0x11c8]
   42590:	str	x1, [x25, #0x11d0]
   42594:	str	x1, [x25, #0x11d8]
   42598:	str	x1, [x25, #0x11e0]
   4259c:	str	x1, [x25, #0x11e8]
   425a0:	str	x1, [x25, #0x11f0]
   425a4:	str	x1, [x25, #0x11f8]
   425a8:	str	x1, [x25, #0x1200]
   425ac:	str	x1, [x25, #0x1208]
   425b0:	and	x13, x13, #0xfffffffffffffffd
   425b4:	b	0x3eaf8
   425b8:	mov	x0, #0x0
   425bc:	str	x0, [x25, #0xe90]
   425c0:	str	x0, [x25, #0xe98]
   425c4:	str	x0, [x25, #0xea0]
   425c8:	str	x0, [x25, #0xea8]
   425cc:	str	x0, [x25, #0xeb0]
   425d0:	str	x0, [x25, #0xeb8]
   425d4:	str	x0, [x25, #0xec0]
   425d8:	str	x0, [x25, #0xec8]
   425dc:	str	x0, [x25, #0xed0]
   425e0:	str	x0, [x25, #0xed8]
   425e4:	str	x0, [x25, #0xee0]
   425e8:	str	x0, [x25, #0xee8]
   425ec:	str	x0, [x25, #0xef0]
   425f0:	str	x0, [x25, #0xef8]
   425f4:	str	x0, [x25, #0xf00]
   425f8:	str	x0, [x25, #0xf08]
   425fc:	str	x0, [x25, #0xf10]
   42600:	str	x0, [x25, #0xf18]
   42604:	and	x13, x13, #0xfffffffffffffffe
   42608:	b	0x3eb1c
   4260c:	mov	x0, #0x71d
   42610:	ldur	x20, [sp]
   42614:	str	x0, [x20, #0x48]
   42618:	mov	x0, #0x0
   4261c:	str	x0, [x19, #0x30]
   42620:	mov	x1, #0x1000000000000000
   42624:	str	x1, [x19, #0x38]
   42628:	mov	x1, #0x1
   4262c:	str	x1, [x19, #0x48]
   42630:	mov	x2, #0x101010101010101
   42634:	str	x2, [x19, #0x50]
   42638:	mov	x20, #0x2
   4263c:	str	x20, [x19, #0x58]
   42640:	mov	x2, #0x3
   42644:	str	x2, [x19, #0x60]
   42648:	mov	x2, #0x4
   4264c:	str	x2, [x19, #0x68]
   42650:	mov	x2, #0xf0f0f0f0f0f0f0f
   42654:	str	x2, [x19, #0x90]
   42658:	mov	x2, #0x3333333333333333
   4265c:	str	x2, [x19, #0xa0]
   42660:	mov	x2, #0x38
   42664:	str	x2, [x19, #0xa8]
   42668:	mov	x2, #0x3a
   4266c:	str	x2, [x19, #0xb0]
   42670:	mov	x2, #0x5555555555555555
   42674:	str	x2, [x19, #0xc8]
   42678:	mov	x2, #0x3ffffffffffffff
   4267c:	str	x2, [x19, #0xd8]
   42680:	str	x0, [x19, #0x178]
   42684:	str	x1, [x19, #0x180]
   42688:	ldur	x23, [sp, #0xc8]
   4268c:	str	x23, [x19, #0x2140]
   42690:	ldr	x27, [sp, #0x1b0]
   42694:	str	x27, [x19, #0x2148]
   42698:	ldr	x1, [sp, #0x118]
   4269c:	uxtb	w1, w1
   426a0:	str	x1, [x19, #0x2158]
   426a4:	ldr	x1, [sp, #0x110]
   426a8:	str	x1, [x19, #0x2578]
   426ac:	ldur	x10, [sp, #0x58]
   426b0:	str	x10, [x19, #0x54d0]
   426b4:	str	x3, [x19, #0x54d8]
   426b8:	ldur	x4, [sp, #0x60]
   426bc:	str	x4, [x19, #0x54e0]
   426c0:	str	x23, [x19, #0x5818]
   426c4:	str	x27, [x19, #0x5820]
   426c8:	ldur	x24, [sp, #0x28]
   426cc:	str	x24, [x19, #0x6238]
   426d0:	add	x8, x15, #0x1
   426d4:	str	x8, [x19, #0x62a8]
   426d8:	ldur	x23, [sp, #0x68]
   426dc:	str	x23, [x19, #0x62b0]
   426e0:	ldur	x28, [sp, #0x70]
   426e4:	str	x28, [x19, #0x62b8]
   426e8:	ldur	x4, [sp, #0x50]
   426ec:	sub	x13, x4, x3
   426f0:	mov	w14, #0xb946
   426f4:	movk	w14, #0x1, lsl #16
   426f8:	msub	x13, x8, x14, x13
   426fc:	str	x13, [x19, #0x62c0]
   42700:	str	x0, [x19, #0x62c8]
   42704:	str	x0, [x19, #0x62d0]
   42708:	ldur	x22, [sp, #0x78]
   4270c:	str	x22, [x19, #0x62e0]
   42710:	ldur	x9, [sp, #0x80]
   42714:	str	x9, [x19, #0x62e8]
   42718:	str	x12, [x19, #0x62f8]
   4271c:	str	x11, [x19, #0x6300]
   42720:	str	x7, [x19, #0x6310]
   42724:	str	x6, [x19, #0x6318]
   42728:	ldr	x0, [x19, #0x54d0]
   4272c:	cmp	x0, #0x0
   42730:	b.ne	0x3eb30
   42734:	b	0x3ed58
   42738:	mov	x25, x20
   4273c:	b	0x43b34
   42740:	mov	x25, x20
   42744:	b	0x43b34
   42748:	mov	x0, #0x71f
   4274c:	ldur	x20, [sp]
   42750:	str	x0, [x20, #0x48]
   42754:	mov	x0, #0x0
   42758:	str	x0, [x19, #0x30]
   4275c:	mov	x1, #0x1000000000000000
   42760:	str	x1, [x19, #0x38]
   42764:	mov	x1, #0x1
   42768:	str	x1, [x19, #0x48]
   4276c:	mov	x2, #0x101010101010101
   42770:	str	x2, [x19, #0x50]
   42774:	mov	x20, #0x2
   42778:	str	x20, [x19, #0x58]
   4277c:	mov	x2, #0x3
   42780:	str	x2, [x19, #0x60]
   42784:	mov	x2, #0x4
   42788:	str	x2, [x19, #0x68]
   4278c:	mov	x2, #0xf0f0f0f0f0f0f0f
   42790:	str	x2, [x19, #0x90]
   42794:	mov	x2, #0x3333333333333333
   42798:	str	x2, [x19, #0xa0]
   4279c:	mov	x2, #0x38
   427a0:	str	x2, [x19, #0xa8]
   427a4:	mov	x2, #0x3a
   427a8:	str	x2, [x19, #0xb0]
   427ac:	mov	x2, #0x5555555555555555
   427b0:	str	x2, [x19, #0xc8]
   427b4:	mov	x2, #0x3ffffffffffffff
   427b8:	str	x2, [x19, #0xd8]
   427bc:	str	x0, [x19, #0x178]
   427c0:	str	x1, [x19, #0x180]
   427c4:	ldur	x23, [sp, #0xc8]
   427c8:	str	x23, [x19, #0x2140]
   427cc:	ldr	x27, [sp, #0x1b0]
   427d0:	str	x27, [x19, #0x2148]
   427d4:	ldr	x1, [sp, #0x118]
   427d8:	uxtb	w1, w1
   427dc:	str	x1, [x19, #0x2158]
   427e0:	str	x14, [x19, #0x2580]
   427e4:	add	x1, x23, #0x2
   427e8:	str	x1, [x19, #0x2588]
   427ec:	ldur	x10, [sp, #0x58]
   427f0:	str	x10, [x19, #0x54d0]
   427f4:	str	x3, [x19, #0x54d8]
   427f8:	ldur	x4, [sp, #0x60]
   427fc:	str	x4, [x19, #0x54e0]
   42800:	str	x23, [x19, #0x5818]
   42804:	str	x27, [x19, #0x5820]
   42808:	ldur	x24, [sp, #0x28]
   4280c:	str	x24, [x19, #0x6238]
   42810:	add	x1, x15, #0x1
   42814:	str	x1, [x19, #0x62a8]
   42818:	ldur	x23, [sp, #0x68]
   4281c:	str	x23, [x19, #0x62b0]
   42820:	ldur	x28, [sp, #0x70]
   42824:	str	x28, [x19, #0x62b8]
   42828:	ldur	x4, [sp, #0x50]
   4282c:	sub	x3, x4, x3
   42830:	mov	w4, #0xb946
   42834:	movk	w4, #0x1, lsl #16
   42838:	msub	x3, x1, x4, x3
   4283c:	str	x3, [x19, #0x62c0]
   42840:	str	x0, [x19, #0x62c8]
   42844:	str	x0, [x19, #0x62d0]
   42848:	ldur	x22, [sp, #0x78]
   4284c:	str	x22, [x19, #0x62e0]
   42850:	ldur	x9, [sp, #0x80]
   42854:	str	x9, [x19, #0x62e8]
   42858:	str	x12, [x19, #0x62f8]
   4285c:	str	x11, [x19, #0x6300]
   42860:	str	x7, [x19, #0x6310]
   42864:	str	x6, [x19, #0x6318]
   42868:	ldr	x12, [x19, #0x54d0]
   4286c:	cmp	x12, #0x0
   42870:	b.ne	0x3edd0
   42874:	b	0x3efec
   42878:	mov	x25, x20
   4287c:	b	0x43b34
   42880:	mov	x25, x20
   42884:	b	0x43b34
   42888:	mov	w1, #0x1706
   4288c:	movk	w1, #0x1, lsl #16
   42890:	cmp	x3, x1
   42894:	b.lo	0x3f0a0
   42898:	mov	w1, #0x1
   4289c:	uxtb	w2, w5
   428a0:	cbnz	x2, 0x3f0ac
   428a4:	ldur	x1, [sp, #0x88]
   428a8:	ldur	x24, [sp, #0x28]
   428ac:	cmp	x24, x1
   428b0:	b.ls	0x428c4
   428b4:	mov	w1, #0x0
   428b8:	ldur	x2, [sp, #0x60]
   428bc:	mov	x4, x3
   428c0:	b	0x3f108
   428c4:	cmp	x14, x12
   428c8:	cset	x1, lo
   428cc:	mov	x2, #0x1000000000000000
   428d0:	ldur	x23, [sp, #0x48]
   428d4:	cmp	x23, x2
   428d8:	cset	x2, lo
   428dc:	and	w1, w1, w2
   428e0:	uxtb	w1, w1
   428e4:	tbnz	w1, #0x0, 0x3f0fc
   428e8:	b	0x3f0b8
   428ec:	mov	x25, x20
   428f0:	b	0x43b34
   428f4:	mov	x1, #0x737
   428f8:	ldur	x20, [sp]
   428fc:	str	x1, [x20, #0x48]
   42900:	mov	x1, #0x0
   42904:	str	x1, [x19, #0x30]
   42908:	str	x0, [x19, #0x38]
   4290c:	mov	x0, #0x1
   42910:	mov	x25, x0
   42914:	str	x0, [x19, #0x48]
   42918:	mov	x2, #0x101010101010101
   4291c:	str	x2, [x19, #0x50]
   42920:	mov	x2, #0x2
   42924:	str	x2, [x19, #0x58]
   42928:	mov	x4, #0x3
   4292c:	str	x4, [x19, #0x60]
   42930:	mov	x4, #0x4
   42934:	str	x4, [x19, #0x68]
   42938:	mov	x5, #0xf0f0f0f0f0f0f0f
   4293c:	str	x5, [x19, #0x90]
   42940:	mov	x8, #0x3333333333333333
   42944:	str	x8, [x19, #0xa0]
   42948:	mov	x8, #0x38
   4294c:	str	x8, [x19, #0xa8]
   42950:	mov	x8, #0x3a
   42954:	str	x8, [x19, #0xb0]
   42958:	mov	x9, #0x5555555555555555
   4295c:	str	x9, [x19, #0xc8]
   42960:	mov	x10, #0x3ffffffffffffff
   42964:	str	x10, [x19, #0xd8]
   42968:	str	x1, [x19, #0x178]
   4296c:	str	x0, [x19, #0x180]
   42970:	ldur	x23, [sp, #0xc8]
   42974:	str	x23, [x19, #0x2140]
   42978:	ldr	x27, [sp, #0x1b0]
   4297c:	str	x27, [x19, #0x2148]
   42980:	ldr	x0, [sp, #0x118]
   42984:	uxtb	w0, w0
   42988:	str	x0, [x19, #0x2158]
   4298c:	str	x14, [x19, #0x25d8]
   42990:	str	x12, [x19, #0x25e0]
   42994:	str	x23, [x19, #0x25e8]
   42998:	str	x22, [x19, #0x2610]
   4299c:	ldur	x10, [sp, #0x58]
   429a0:	str	x10, [x19, #0x54d0]
   429a4:	mov	w2, #0x1706
   429a8:	movk	w2, #0x1, lsl #16
   429ac:	sub	x2, x3, x2
   429b0:	str	x2, [x19, #0x54d8]
   429b4:	ldur	x4, [sp, #0x60]
   429b8:	str	x4, [x19, #0x54e0]
   429bc:	ldur	x24, [sp, #0x28]
   429c0:	str	x24, [x19, #0x6238]
   429c4:	add	x3, x15, #0x1
   429c8:	str	x3, [x19, #0x62a8]
   429cc:	ldur	x23, [sp, #0x68]
   429d0:	str	x23, [x19, #0x62b0]
   429d4:	ldur	x28, [sp, #0x70]
   429d8:	str	x28, [x19, #0x62b8]
   429dc:	ldur	x4, [sp, #0x50]
   429e0:	sub	x2, x4, x2
   429e4:	mov	w4, #0xb946
   429e8:	movk	w4, #0x1, lsl #16
   429ec:	msub	x0, x3, x4, x2
   429f0:	str	x0, [x19, #0x62c0]
   429f4:	str	x1, [x19, #0x62c8]
   429f8:	str	x1, [x19, #0x62d0]
   429fc:	ldur	x22, [sp, #0x78]
   42a00:	str	x22, [x19, #0x62e0]
   42a04:	ldur	x9, [sp, #0x80]
   42a08:	str	x9, [x19, #0x62e8]
   42a0c:	mov	x0, x25
   42a10:	str	x0, [x19, #0x62f8]
   42a14:	ldur	x0, [sp, #0x20]
   42a18:	str	x0, [x19, #0x6300]
   42a1c:	str	x7, [x19, #0x6310]
   42a20:	str	x6, [x19, #0x6318]
   42a24:	b	0x43b34
   42a28:	mov	x1, #0x738
   42a2c:	ldur	x20, [sp]
   42a30:	str	x1, [x20, #0x48]
   42a34:	mov	x1, #0x0
   42a38:	str	x1, [x19, #0x30]
   42a3c:	str	x0, [x19, #0x38]
   42a40:	mov	x0, #0x1
   42a44:	str	x0, [x19, #0x48]
   42a48:	mov	x4, #0x101010101010101
   42a4c:	str	x4, [x19, #0x50]
   42a50:	mov	x20, #0x2
   42a54:	str	x20, [x19, #0x58]
   42a58:	mov	x4, #0x3
   42a5c:	str	x4, [x19, #0x60]
   42a60:	mov	x4, #0x4
   42a64:	str	x4, [x19, #0x68]
   42a68:	mov	x4, #0xf0f0f0f0f0f0f0f
   42a6c:	str	x4, [x19, #0x90]
   42a70:	mov	x4, #0x3333333333333333
   42a74:	str	x4, [x19, #0xa0]
   42a78:	mov	x4, #0x38
   42a7c:	str	x4, [x19, #0xa8]
   42a80:	mov	x4, #0x3a
   42a84:	str	x4, [x19, #0xb0]
   42a88:	mov	x4, #0x5555555555555555
   42a8c:	str	x4, [x19, #0xc8]
   42a90:	mov	x4, #0x3ffffffffffffff
   42a94:	str	x4, [x19, #0xd8]
   42a98:	str	x1, [x19, #0x178]
   42a9c:	str	x0, [x19, #0x180]
   42aa0:	ldur	x23, [sp, #0xc8]
   42aa4:	str	x23, [x19, #0x2140]
   42aa8:	ldr	x27, [sp, #0x1b0]
   42aac:	str	x27, [x19, #0x2148]
   42ab0:	ldr	x4, [sp, #0x118]
   42ab4:	uxtb	w4, w4
   42ab8:	str	x4, [x19, #0x2158]
   42abc:	str	x14, [x19, #0x25d8]
   42ac0:	str	x12, [x19, #0x25e0]
   42ac4:	str	x23, [x19, #0x25e8]
   42ac8:	str	x22, [x19, #0x2610]
   42acc:	str	x2, [x19, #0x2620]
   42ad0:	ldur	x10, [sp, #0x58]
   42ad4:	str	x10, [x19, #0x54d0]
   42ad8:	mov	w2, #0x1706
   42adc:	movk	w2, #0x1, lsl #16
   42ae0:	sub	x2, x3, x2
   42ae4:	str	x2, [x19, #0x54d8]
   42ae8:	ldur	x4, [sp, #0x60]
   42aec:	str	x4, [x19, #0x54e0]
   42af0:	str	x23, [x19, #0x5818]
   42af4:	str	x27, [x19, #0x5820]
   42af8:	str	x14, [x19, #0x5d38]
   42afc:	str	x12, [x19, #0x5d40]
   42b00:	str	x23, [x19, #0x5d48]
   42b04:	ldur	x23, [sp, #0x10]
   42b08:	str	x23, [x19, #0x5d50]
   42b0c:	ldur	x26, [sp, #0x30]
   42b10:	str	x26, [x19, #0x5d58]
   42b14:	ldur	x23, [sp, #0x38]
   42b18:	str	x23, [x19, #0x5d60]
   42b1c:	ldur	x25, [sp, #0x40]
   42b20:	str	x25, [x19, #0x5d68]
   42b24:	ldur	x23, [sp, #0x48]
   42b28:	str	x23, [x19, #0x5d70]
   42b2c:	ldur	x24, [sp, #0x28]
   42b30:	str	x24, [x19, #0x6238]
   42b34:	add	x15, x15, #0x1
   42b38:	str	x15, [x19, #0x62a8]
   42b3c:	ldur	x23, [sp, #0x68]
   42b40:	str	x23, [x19, #0x62b0]
   42b44:	ldur	x28, [sp, #0x70]
   42b48:	str	x28, [x19, #0x62b8]
   42b4c:	ldur	x4, [sp, #0x50]
   42b50:	sub	x2, x4, x2
   42b54:	mov	w3, #0xb946
   42b58:	movk	w3, #0x1, lsl #16
   42b5c:	msub	x2, x15, x3, x2
   42b60:	str	x2, [x19, #0x62c0]
   42b64:	str	x1, [x19, #0x62c8]
   42b68:	str	x1, [x19, #0x62d0]
   42b6c:	ldur	x22, [sp, #0x78]
   42b70:	str	x22, [x19, #0x62e0]
   42b74:	ldur	x9, [sp, #0x80]
   42b78:	str	x9, [x19, #0x62e8]
   42b7c:	str	x0, [x19, #0x62f8]
   42b80:	ldur	x0, [sp, #0x20]
   42b84:	str	x0, [x19, #0x6300]
   42b88:	str	x7, [x19, #0x6310]
   42b8c:	str	x6, [x19, #0x6318]
   42b90:	ldr	x0, [x19, #0x54d0]
   42b94:	cmp	x0, #0x0
   42b98:	b.ne	0x3f52c
   42b9c:	b	0x3f758
   42ba0:	mov	x25, x20
   42ba4:	b	0x43b34
   42ba8:	mov	x25, x20
   42bac:	b	0x43b34
   42bb0:	mov	x2, #0x739
   42bb4:	ldur	x20, [sp]
   42bb8:	str	x2, [x20, #0x48]
   42bbc:	mov	x2, #0x0
   42bc0:	str	x2, [x19, #0x30]
   42bc4:	str	x0, [x19, #0x38]
   42bc8:	mov	x0, #0x1
   42bcc:	mov	x25, x0
   42bd0:	str	x0, [x19, #0x48]
   42bd4:	mov	x0, #0x101010101010101
   42bd8:	str	x0, [x19, #0x50]
   42bdc:	mov	x0, #0x2
   42be0:	str	x0, [x19, #0x58]
   42be4:	mov	x0, #0x3
   42be8:	str	x0, [x19, #0x60]
   42bec:	mov	x0, #0x4
   42bf0:	str	x0, [x19, #0x68]
   42bf4:	mov	x0, #0xf0f0f0f0f0f0f0f
   42bf8:	str	x0, [x19, #0x90]
   42bfc:	mov	x0, #0x3333333333333333
   42c00:	str	x0, [x19, #0xa0]
   42c04:	mov	x0, #0x38
   42c08:	str	x0, [x19, #0xa8]
   42c0c:	mov	x0, #0x3a
   42c10:	str	x0, [x19, #0xb0]
   42c14:	mov	x0, #0x5555555555555555
   42c18:	str	x0, [x19, #0xc8]
   42c1c:	mov	x0, #0x3ffffffffffffff
   42c20:	str	x0, [x19, #0xd8]
   42c24:	str	x2, [x19, #0x178]
   42c28:	mov	x0, x25
   42c2c:	str	x0, [x19, #0x180]
   42c30:	ldur	x23, [sp, #0xc8]
   42c34:	str	x23, [x19, #0x2140]
   42c38:	ldr	x27, [sp, #0x1b0]
   42c3c:	str	x27, [x19, #0x2148]
   42c40:	ldr	x0, [sp, #0x118]
   42c44:	uxtb	w0, w0
   42c48:	str	x0, [x19, #0x2158]
   42c4c:	str	x14, [x19, #0x25d8]
   42c50:	str	x12, [x19, #0x25e0]
   42c54:	str	x23, [x19, #0x25e8]
   42c58:	str	x22, [x19, #0x2610]
   42c5c:	str	x1, [x19, #0x2628]
   42c60:	ldur	x10, [sp, #0x58]
   42c64:	str	x10, [x19, #0x54d0]
   42c68:	mov	w4, #0x1706
   42c6c:	movk	w4, #0x1, lsl #16
   42c70:	sub	x3, x3, x4
   42c74:	str	x3, [x19, #0x54d8]
   42c78:	ldur	x4, [sp, #0x60]
   42c7c:	str	x4, [x19, #0x54e0]
   42c80:	ldur	x24, [sp, #0x28]
   42c84:	str	x24, [x19, #0x6238]
   42c88:	add	x8, x15, #0x1
   42c8c:	str	x8, [x19, #0x62a8]
   42c90:	ldur	x23, [sp, #0x68]
   42c94:	str	x23, [x19, #0x62b0]
   42c98:	ldur	x28, [sp, #0x70]
   42c9c:	str	x28, [x19, #0x62b8]
   42ca0:	ldur	x4, [sp, #0x50]
   42ca4:	sub	x9, x4, x3
   42ca8:	mov	w10, #0xb946
   42cac:	movk	w10, #0x1, lsl #16
   42cb0:	msub	x9, x8, x10, x9
   42cb4:	str	x9, [x19, #0x62c0]
   42cb8:	str	x2, [x19, #0x62c8]
   42cbc:	str	x2, [x19, #0x62d0]
   42cc0:	ldur	x22, [sp, #0x78]
   42cc4:	str	x22, [x19, #0x62e0]
   42cc8:	ldur	x9, [sp, #0x80]
   42ccc:	str	x9, [x19, #0x62e8]
   42cd0:	mov	x0, x25
   42cd4:	str	x0, [x19, #0x62f8]
   42cd8:	ldur	x2, [sp, #0x20]
   42cdc:	str	x2, [x19, #0x6300]
   42ce0:	str	x7, [x19, #0x6310]
   42ce4:	str	x6, [x19, #0x6318]
   42ce8:	b	0x43b34
   42cec:	mov	x2, #0x73a
   42cf0:	ldur	x20, [sp]
   42cf4:	str	x2, [x20, #0x48]
   42cf8:	mov	x2, #0x0
   42cfc:	str	x2, [x19, #0x30]
   42d00:	str	x0, [x19, #0x38]
   42d04:	mov	x0, #0x1
   42d08:	str	x0, [x19, #0x48]
   42d0c:	mov	x5, #0x101010101010101
   42d10:	str	x5, [x19, #0x50]
   42d14:	mov	x28, #0x2
   42d18:	str	x28, [x19, #0x58]
   42d1c:	mov	x5, #0x3
   42d20:	str	x5, [x19, #0x60]
   42d24:	mov	x5, #0x4
   42d28:	str	x5, [x19, #0x68]
   42d2c:	mov	x5, #0xf0f0f0f0f0f0f0f
   42d30:	str	x5, [x19, #0x90]
   42d34:	mov	x5, #0x3333333333333333
   42d38:	str	x5, [x19, #0xa0]
   42d3c:	mov	x5, #0x38
   42d40:	str	x5, [x19, #0xa8]
   42d44:	mov	x5, #0x3a
   42d48:	str	x5, [x19, #0xb0]
   42d4c:	mov	x5, #0x5555555555555555
   42d50:	str	x5, [x19, #0xc8]
   42d54:	mov	x5, #0x3ffffffffffffff
   42d58:	str	x5, [x19, #0xd8]
   42d5c:	str	x2, [x19, #0x178]
   42d60:	str	x0, [x19, #0x180]
   42d64:	ldur	x23, [sp, #0xc8]
   42d68:	str	x23, [x19, #0x2140]
   42d6c:	ldr	x27, [sp, #0x1b0]
   42d70:	str	x27, [x19, #0x2148]
   42d74:	ldr	x5, [sp, #0x118]
   42d78:	uxtb	w5, w5
   42d7c:	str	x5, [x19, #0x2158]
   42d80:	str	x14, [x19, #0x25d8]
   42d84:	str	x12, [x19, #0x25e0]
   42d88:	str	x23, [x19, #0x25e8]
   42d8c:	str	x22, [x19, #0x2610]
   42d90:	str	x1, [x19, #0x2628]
   42d94:	str	x4, [x19, #0x2630]
   42d98:	ldur	x10, [sp, #0x58]
   42d9c:	str	x10, [x19, #0x54d0]
   42da0:	mov	w1, #0x1706
   42da4:	movk	w1, #0x1, lsl #16
   42da8:	sub	x1, x3, x1
   42dac:	str	x1, [x19, #0x54d8]
   42db0:	ldur	x4, [sp, #0x60]
   42db4:	str	x4, [x19, #0x54e0]
   42db8:	str	x23, [x19, #0x5818]
   42dbc:	str	x27, [x19, #0x5820]
   42dc0:	str	x14, [x19, #0x5d38]
   42dc4:	str	x12, [x19, #0x5d40]
   42dc8:	str	x23, [x19, #0x5d48]
   42dcc:	ldur	x23, [sp, #0x10]
   42dd0:	str	x23, [x19, #0x5d50]
   42dd4:	ldur	x26, [sp, #0x30]
   42dd8:	str	x26, [x19, #0x5d58]
   42ddc:	ldur	x23, [sp, #0x38]
   42de0:	str	x23, [x19, #0x5d60]
   42de4:	ldur	x25, [sp, #0x40]
   42de8:	str	x25, [x19, #0x5d68]
   42dec:	ldur	x23, [sp, #0x48]
   42df0:	str	x23, [x19, #0x5d70]
   42df4:	ldur	x24, [sp, #0x28]
   42df8:	str	x24, [x19, #0x6238]
   42dfc:	add	x3, x15, #0x1
   42e00:	str	x3, [x19, #0x62a8]
   42e04:	ldur	x23, [sp, #0x68]
   42e08:	str	x23, [x19, #0x62b0]
   42e0c:	ldur	x15, [sp, #0x70]
   42e10:	str	x15, [x19, #0x62b8]
   42e14:	ldur	x4, [sp, #0x50]
   42e18:	sub	x1, x4, x1
   42e1c:	mov	w4, #0xb946
   42e20:	movk	w4, #0x1, lsl #16
   42e24:	msub	x1, x3, x4, x1
   42e28:	str	x1, [x19, #0x62c0]
   42e2c:	str	x2, [x19, #0x62c8]
   42e30:	str	x2, [x19, #0x62d0]
   42e34:	ldur	x22, [sp, #0x78]
   42e38:	str	x22, [x19, #0x62e0]
   42e3c:	ldur	x9, [sp, #0x80]
   42e40:	str	x9, [x19, #0x62e8]
   42e44:	str	x0, [x19, #0x62f8]
   42e48:	ldur	x0, [sp, #0x20]
   42e4c:	str	x0, [x19, #0x6300]
   42e50:	str	x7, [x19, #0x6310]
   42e54:	str	x6, [x19, #0x6318]
   42e58:	ldr	x10, [x19, #0x54d0]
   42e5c:	cmp	x10, #0x0
   42e60:	b.ne	0x3f7d4
   42e64:	b	0x3f9f4
   42e68:	mov	x25, x28
   42e6c:	b	0x43b34
   42e70:	mov	x25, x28
   42e74:	b	0x43b34
   42e78:	mov	x2, #0x73c
   42e7c:	ldur	x20, [sp]
   42e80:	str	x2, [x20, #0x48]
   42e84:	mov	x2, #0x0
   42e88:	str	x2, [x19, #0x30]
   42e8c:	str	x0, [x19, #0x38]
   42e90:	mov	x0, #0x1
   42e94:	str	x0, [x19, #0x48]
   42e98:	mov	x4, #0x101010101010101
   42e9c:	str	x4, [x19, #0x50]
   42ea0:	mov	x20, #0x2
   42ea4:	str	x20, [x19, #0x58]
   42ea8:	mov	x4, #0x3
   42eac:	str	x4, [x19, #0x60]
   42eb0:	mov	x4, #0x4
   42eb4:	str	x4, [x19, #0x68]
   42eb8:	mov	x4, #0xf0f0f0f0f0f0f0f
   42ebc:	str	x4, [x19, #0x90]
   42ec0:	mov	x4, #0x3333333333333333
   42ec4:	str	x4, [x19, #0xa0]
   42ec8:	mov	x4, #0x38
   42ecc:	str	x4, [x19, #0xa8]
   42ed0:	mov	x4, #0x3a
   42ed4:	str	x4, [x19, #0xb0]
   42ed8:	mov	x4, #0x5555555555555555
   42edc:	str	x4, [x19, #0xc8]
   42ee0:	mov	x4, #0x3ffffffffffffff
   42ee4:	str	x4, [x19, #0xd8]
   42ee8:	str	x2, [x19, #0x178]
   42eec:	str	x0, [x19, #0x180]
   42ef0:	ldur	x23, [sp, #0xc8]
   42ef4:	str	x23, [x19, #0x2140]
   42ef8:	ldr	x27, [sp, #0x1b0]
   42efc:	str	x27, [x19, #0x2148]
   42f00:	ldr	x4, [sp, #0x118]
   42f04:	uxtb	w4, w4
   42f08:	str	x4, [x19, #0x2158]
   42f0c:	str	x14, [x19, #0x25d8]
   42f10:	str	x12, [x19, #0x25e0]
   42f14:	str	x23, [x19, #0x25e8]
   42f18:	str	x22, [x19, #0x2610]
   42f1c:	str	x11, [x19, #0x2638]
   42f20:	add	x1, x1, #0x2
   42f24:	str	x1, [x19, #0x2640]
   42f28:	ldur	x10, [sp, #0x58]
   42f2c:	str	x10, [x19, #0x54d0]
   42f30:	mov	w1, #0x1706
   42f34:	movk	w1, #0x1, lsl #16
   42f38:	sub	x1, x3, x1
   42f3c:	str	x1, [x19, #0x54d8]
   42f40:	ldur	x4, [sp, #0x60]
   42f44:	str	x4, [x19, #0x54e0]
   42f48:	str	x23, [x19, #0x5818]
   42f4c:	str	x27, [x19, #0x5820]
   42f50:	str	x14, [x19, #0x5d38]
   42f54:	str	x12, [x19, #0x5d40]
   42f58:	str	x23, [x19, #0x5d48]
   42f5c:	ldur	x23, [sp, #0x10]
   42f60:	str	x23, [x19, #0x5d50]
   42f64:	ldur	x26, [sp, #0x30]
   42f68:	str	x26, [x19, #0x5d58]
   42f6c:	ldur	x23, [sp, #0x38]
   42f70:	str	x23, [x19, #0x5d60]
   42f74:	ldur	x25, [sp, #0x40]
   42f78:	str	x25, [x19, #0x5d68]
   42f7c:	ldur	x23, [sp, #0x48]
   42f80:	str	x23, [x19, #0x5d70]
   42f84:	ldur	x24, [sp, #0x28]
   42f88:	str	x24, [x19, #0x6238]
   42f8c:	add	x3, x15, #0x1
   42f90:	str	x3, [x19, #0x62a8]
   42f94:	ldur	x23, [sp, #0x68]
   42f98:	str	x23, [x19, #0x62b0]
   42f9c:	ldur	x28, [sp, #0x70]
   42fa0:	str	x28, [x19, #0x62b8]
   42fa4:	ldur	x4, [sp, #0x50]
   42fa8:	sub	x5, x4, x1
   42fac:	mov	w8, #0xb946
   42fb0:	movk	w8, #0x1, lsl #16
   42fb4:	msub	x5, x3, x8, x5
   42fb8:	str	x5, [x19, #0x62c0]
   42fbc:	str	x2, [x19, #0x62c8]
   42fc0:	str	x2, [x19, #0x62d0]
   42fc4:	ldur	x22, [sp, #0x78]
   42fc8:	str	x22, [x19, #0x62e0]
   42fcc:	ldur	x9, [sp, #0x80]
   42fd0:	str	x9, [x19, #0x62e8]
   42fd4:	str	x0, [x19, #0x62f8]
   42fd8:	ldur	x0, [sp, #0x20]
   42fdc:	str	x0, [x19, #0x6300]
   42fe0:	str	x7, [x19, #0x6310]
   42fe4:	str	x6, [x19, #0x6318]
   42fe8:	ldr	x14, [x19, #0x54d0]
   42fec:	cmp	x14, #0x0
   42ff0:	b.ne	0x3fa64
   42ff4:	b	0x3fc74
   42ff8:	mov	x25, x20
   42ffc:	b	0x43b34
   43000:	mov	x25, x20
   43004:	b	0x43b34
   43008:	mov	w3, #0xccd6
   4300c:	movk	w3, #0x2, lsl #16
   43010:	cmp	x6, x3
   43014:	b.lo	0x3fd58
   43018:	mov	w8, #0x1
   4301c:	uxtb	w3, w5
   43020:	cbnz	x3, 0x3fd8c
   43024:	ldur	x9, [sp, #0x88]
   43028:	ldur	x24, [sp, #0x28]
   4302c:	cmp	x24, x9
   43030:	b.ls	0x43044
   43034:	mov	w8, #0x0
   43038:	ldur	x3, [sp, #0x60]
   4303c:	mov	x9, x6
   43040:	b	0x3fdc0
   43044:	cmp	x11, x7
   43048:	b.lo	0x3fdb4
   4304c:	b	0x3fd98
   43050:	mov	x8, #0x750
   43054:	ldur	x20, [sp]
   43058:	str	x8, [x20, #0x48]
   4305c:	mov	x8, #0x0
   43060:	str	x8, [x19, #0x30]
   43064:	str	x0, [x19, #0x38]
   43068:	mov	x13, #0x1
   4306c:	str	x13, [x19, #0x48]
   43070:	mov	x0, #0x101010101010101
   43074:	str	x0, [x19, #0x50]
   43078:	mov	x20, #0x2
   4307c:	str	x20, [x19, #0x58]
   43080:	mov	x0, #0x3
   43084:	str	x0, [x19, #0x60]
   43088:	mov	x0, #0x4
   4308c:	str	x0, [x19, #0x68]
   43090:	mov	x0, #0xf0f0f0f0f0f0f0f
   43094:	str	x0, [x19, #0x90]
   43098:	mov	x0, #0x3333333333333333
   4309c:	str	x0, [x19, #0xa0]
   430a0:	mov	x0, #0x38
   430a4:	str	x0, [x19, #0xa8]
   430a8:	mov	x0, #0x3a
   430ac:	str	x0, [x19, #0xb0]
   430b0:	mov	x0, #0x5555555555555555
   430b4:	str	x0, [x19, #0xc8]
   430b8:	mov	x0, #0x3ffffffffffffff
   430bc:	str	x0, [x19, #0xd8]
   430c0:	str	x8, [x19, #0x178]
   430c4:	str	x13, [x19, #0x180]
   430c8:	ldur	x0, [sp, #0xc8]
   430cc:	str	x0, [x19, #0x2140]
   430d0:	ldr	x27, [sp, #0x1b0]
   430d4:	str	x27, [x19, #0x2148]
   430d8:	ldr	x0, [sp, #0x118]
   430dc:	uxtb	w0, w0
   430e0:	str	x0, [x19, #0x2158]
   430e4:	str	x14, [x19, #0x25d8]
   430e8:	str	x12, [x19, #0x25e0]
   430ec:	ldur	x3, [sp, #0xc8]
   430f0:	str	x3, [x19, #0x25e8]
   430f4:	ldur	x22, [sp, #0xe0]
   430f8:	str	x22, [x19, #0x2610]
   430fc:	str	x11, [x19, #0x2680]
   43100:	str	x7, [x19, #0x2688]
   43104:	ldur	x9, [sp, #0xc8]
   43108:	str	x9, [x19, #0x2690]
   4310c:	uxtb	w0, w21
   43110:	str	x0, [x19, #0x26a0]
   43114:	add	x0, x11, #0x1
   43118:	str	x0, [x19, #0x26b0]
   4311c:	ldur	x10, [sp, #0x58]
   43120:	str	x10, [x19, #0x54d0]
   43124:	mov	w0, #0xccd6
   43128:	movk	w0, #0x2, lsl #16
   4312c:	sub	x0, x6, x0
   43130:	str	x0, [x19, #0x54d8]
   43134:	ldur	x3, [sp, #0x60]
   43138:	str	x3, [x19, #0x54e0]
   4313c:	ldur	x3, [sp, #0xc8]
   43140:	str	x3, [x19, #0x5818]
   43144:	str	x27, [x19, #0x5820]
   43148:	str	x14, [x19, #0x5d38]
   4314c:	str	x12, [x19, #0x5d40]
   43150:	str	x3, [x19, #0x5d48]
   43154:	ldur	x3, [sp, #0x10]
   43158:	str	x3, [x19, #0x5d50]
   4315c:	ldur	x26, [sp, #0x30]
   43160:	str	x26, [x19, #0x5d58]
   43164:	ldur	x3, [sp, #0x38]
   43168:	str	x3, [x19, #0x5d60]
   4316c:	ldur	x25, [sp, #0x40]
   43170:	str	x25, [x19, #0x5d68]
   43174:	ldur	x3, [sp, #0x48]
   43178:	str	x3, [x19, #0x5d70]
   4317c:	str	x11, [x19, #0x5e98]
   43180:	str	x7, [x19, #0x5ea0]
   43184:	ldur	x3, [sp, #0xc8]
   43188:	str	x3, [x19, #0x5ea8]
   4318c:	str	x2, [x19, #0x5eb0]
   43190:	str	x4, [x19, #0x5eb8]
   43194:	str	x23, [x19, #0x5ec0]
   43198:	str	x1, [x19, #0x5ec8]
   4319c:	ldur	x22, [sp, #0xb0]
   431a0:	str	x22, [x19, #0x5ed0]
   431a4:	ldur	x24, [sp, #0x28]
   431a8:	str	x24, [x19, #0x6238]
   431ac:	add	x1, x15, #0x1
   431b0:	str	x1, [x19, #0x62a8]
   431b4:	ldur	x23, [sp, #0x68]
   431b8:	str	x23, [x19, #0x62b0]
   431bc:	ldur	x28, [sp, #0x70]
   431c0:	str	x28, [x19, #0x62b8]
   431c4:	ldur	x4, [sp, #0x50]
   431c8:	sub	x0, x4, x0
   431cc:	mov	w2, #0xb946
   431d0:	movk	w2, #0x1, lsl #16
   431d4:	msub	x0, x1, x2, x0
   431d8:	str	x0, [x19, #0x62c0]
   431dc:	str	x8, [x19, #0x62c8]
   431e0:	str	x8, [x19, #0x62d0]
   431e4:	ldur	x22, [sp, #0x78]
   431e8:	str	x22, [x19, #0x62e0]
   431ec:	ldur	x9, [sp, #0x80]
   431f0:	str	x9, [x19, #0x62e8]
   431f4:	str	x13, [x19, #0x62f8]
   431f8:	ldur	x6, [sp, #0x20]
   431fc:	str	x6, [x19, #0x6300]
   43200:	str	x13, [x19, #0x6310]
   43204:	ldur	x27, [sp, #0xa8]
   43208:	str	x27, [x19, #0x6318]
   4320c:	ldr	x6, [x19, #0x54d0]
   43210:	cmp	x6, #0x0
   43214:	b.ne	0x3fe2c
   43218:	b	0x40038
   4321c:	mov	x25, x20
   43220:	b	0x43b34
   43224:	mov	x25, x20
   43228:	b	0x43b34
   4322c:	mov	x1, #0x7d0
   43230:	ldur	x20, [sp]
   43234:	str	x1, [x20, #0x48]
   43238:	mov	x1, #0x0
   4323c:	str	x1, [x19, #0x30]
   43240:	str	x0, [x19, #0x38]
   43244:	mov	x0, #0x1
   43248:	mov	x25, x0
   4324c:	str	x0, [x19, #0x48]
   43250:	mov	x0, #0x101010101010101
   43254:	str	x0, [x19, #0x50]
   43258:	mov	x0, #0x2
   4325c:	str	x0, [x19, #0x58]
   43260:	mov	x0, #0x3
   43264:	str	x0, [x19, #0x60]
   43268:	mov	x0, #0x4
   4326c:	str	x0, [x19, #0x68]
   43270:	mov	x0, #0xf0f0f0f0f0f0f0f
   43274:	str	x0, [x19, #0x90]
   43278:	mov	x0, #0x3333333333333333
   4327c:	str	x0, [x19, #0xa0]
   43280:	mov	x0, #0x38
   43284:	str	x0, [x19, #0xa8]
   43288:	mov	x0, #0x3a
   4328c:	str	x0, [x19, #0xb0]
   43290:	mov	x0, #0x5555555555555555
   43294:	str	x0, [x19, #0xc8]
   43298:	str	x28, [x19, #0xd8]
   4329c:	str	x1, [x19, #0x178]
   432a0:	mov	x0, x25
   432a4:	str	x0, [x19, #0x180]
   432a8:	ldur	x23, [sp, #0xc8]
   432ac:	str	x23, [x19, #0x2140]
   432b0:	ldr	x27, [sp, #0x1b0]
   432b4:	str	x27, [x19, #0x2148]
   432b8:	ldr	x0, [sp, #0x118]
   432bc:	uxtb	w8, w0
   432c0:	str	x8, [x19, #0x2158]
   432c4:	str	x14, [x19, #0x25d8]
   432c8:	str	x12, [x19, #0x25e0]
   432cc:	str	x23, [x19, #0x25e8]
   432d0:	ldur	x22, [sp, #0xe0]
   432d4:	str	x22, [x19, #0x2610]
   432d8:	str	x11, [x19, #0x2680]
   432dc:	str	x7, [x19, #0x2688]
   432e0:	str	x23, [x19, #0x2690]
   432e4:	ldur	x10, [sp, #0x58]
   432e8:	str	x10, [x19, #0x54d0]
   432ec:	mov	w2, #0xccd6
   432f0:	movk	w2, #0x2, lsl #16
   432f4:	sub	x2, x6, x2
   432f8:	str	x2, [x19, #0x54d8]
   432fc:	ldur	x4, [sp, #0x60]
   43300:	str	x4, [x19, #0x54e0]
   43304:	ldur	x24, [sp, #0x28]
   43308:	str	x24, [x19, #0x6238]
   4330c:	add	x3, x15, #0x1
   43310:	str	x3, [x19, #0x62a8]
   43314:	ldur	x23, [sp, #0x68]
   43318:	str	x23, [x19, #0x62b0]
   4331c:	ldur	x28, [sp, #0x70]
   43320:	str	x28, [x19, #0x62b8]
   43324:	ldur	x4, [sp, #0x50]
   43328:	sub	x2, x4, x2
   4332c:	mov	w4, #0xb946
   43330:	movk	w4, #0x1, lsl #16
   43334:	msub	x0, x3, x4, x2
   43338:	str	x0, [x19, #0x62c0]
   4333c:	str	x1, [x19, #0x62c8]
   43340:	str	x1, [x19, #0x62d0]
   43344:	ldur	x22, [sp, #0x78]
   43348:	str	x22, [x19, #0x62e0]
   4334c:	ldur	x9, [sp, #0x80]
   43350:	str	x9, [x19, #0x62e8]
   43354:	mov	x0, x25
   43358:	str	x0, [x19, #0x62f8]
   4335c:	ldur	x6, [sp, #0x20]
   43360:	str	x6, [x19, #0x6300]
   43364:	str	x0, [x19, #0x6310]
   43368:	ldur	x27, [sp, #0xa8]
   4336c:	str	x27, [x19, #0x6318]
   43370:	b	0x43b34
   43374:	mov	w3, #0xccd6
   43378:	movk	w3, #0x2, lsl #16
   4337c:	cmp	x6, x3
   43380:	b.lo	0x40200
   43384:	mov	w3, #0x1
   43388:	uxtb	w8, w5
   4338c:	cbnz	x8, 0x4022c
   43390:	ldur	x3, [sp, #0x88]
   43394:	ldur	x24, [sp, #0x28]
   43398:	cmp	x24, x3
   4339c:	b.ls	0x433b0
   433a0:	mov	w3, #0x0
   433a4:	ldur	x8, [sp, #0x60]
   433a8:	mov	x9, x6
   433ac:	b	0x40260
   433b0:	cmp	x11, x7
   433b4:	b.lo	0x40254
   433b8:	b	0x40238
   433bc:	ldur	x25, [sp, #0xd8]
   433c0:	b	0x43b34
   433c4:	mov	x6, #0x0
   433c8:	str	x6, [x25, #0x19d0]
   433cc:	str	x6, [x25, #0x19d8]
   433d0:	str	x6, [x25, #0x19e0]
   433d4:	str	x6, [x25, #0x19e8]
   433d8:	str	x6, [x25, #0x19f0]
   433dc:	str	x6, [x25, #0x19f8]
   433e0:	str	x6, [x25, #0x1a00]
   433e4:	str	x6, [x25, #0x1a08]
   433e8:	str	x6, [x25, #0x1a10]
   433ec:	str	x6, [x25, #0x1a18]
   433f0:	str	x6, [x25, #0x1a20]
   433f4:	str	x6, [x25, #0x1a28]
   433f8:	str	x6, [x25, #0x1a30]
   433fc:	str	x6, [x25, #0x1a38]
   43400:	str	x6, [x25, #0x1a40]
   43404:	str	x6, [x25, #0x1a48]
   43408:	and	x13, x13, #0xfffffffffffffff7
   4340c:	b	0x407cc
   43410:	mov	x0, #0x0
   43414:	str	x0, [x25, #0x1710]
   43418:	str	x0, [x25, #0x1718]
   4341c:	str	x0, [x25, #0x1720]
   43420:	str	x0, [x25, #0x1728]
   43424:	str	x0, [x25, #0x1730]
   43428:	str	x0, [x25, #0x1738]
   4342c:	str	x0, [x25, #0x1740]
   43430:	str	x0, [x25, #0x1748]
   43434:	str	x0, [x25, #0x1750]
   43438:	str	x0, [x25, #0x1758]
   4343c:	str	x0, [x25, #0x1760]
   43440:	str	x0, [x25, #0x1768]
   43444:	str	x0, [x25, #0x1770]
   43448:	str	x0, [x25, #0x1778]
   4344c:	str	x0, [x25, #0x1780]
   43450:	str	x0, [x25, #0x1788]
   43454:	and	x13, x13, #0xfffffffffffffffb
   43458:	b	0x407e0
   4345c:	mov	x0, #0x7f4
   43460:	ldur	x20, [sp]
   43464:	str	x0, [x20, #0x48]
   43468:	mov	x0, #0x0
   4346c:	str	x0, [x19, #0x54d0]
   43470:	mov	x0, #0x3
   43474:	mov	x25, x0
   43478:	ldr	x0, [sp, #0x1b8]
   4347c:	cmp	x0, #0x166
   43480:	b.hs	0x40824
   43484:	b	0x43b34
   43488:	mov	x0, #0x7f8
   4348c:	ldur	x20, [sp]
   43490:	str	x0, [x20, #0x48]
   43494:	mov	x0, #0x0
   43498:	str	x0, [x19, #0x54d0]
   4349c:	mov	x0, #0x3
   434a0:	mov	x25, x0
   434a4:	ldr	x0, [sp, #0x1b8]
   434a8:	cmp	x0, #0x166
   434ac:	b.hs	0x409f4
   434b0:	b	0x43b34
   434b4:	mov	x0, #0x7fc
   434b8:	ldur	x20, [sp]
   434bc:	str	x0, [x20, #0x48]
   434c0:	mov	x0, #0x0
   434c4:	str	x0, [x19, #0x54d0]
   434c8:	mov	x0, #0x3
   434cc:	mov	x25, x0
   434d0:	ldr	x0, [sp, #0x1b8]
   434d4:	cmp	x0, #0x166
   434d8:	b.hs	0x40ba8
   434dc:	b	0x43b34
   434e0:	mov	x0, #0x800
   434e4:	ldur	x20, [sp]
   434e8:	str	x0, [x20, #0x48]
   434ec:	mov	x0, #0x0
   434f0:	str	x0, [x19, #0x54d0]
   434f4:	mov	x0, #0x3
   434f8:	mov	x25, x0
   434fc:	ldr	x0, [sp, #0x1b8]
   43500:	cmp	x0, #0x166
   43504:	b.hs	0x40d58
   43508:	b	0x43b34
   4350c:	mov	x8, #0x804
   43510:	ldur	x20, [sp]
   43514:	str	x8, [x20, #0x48]
   43518:	mov	x9, #0x0
   4351c:	str	x9, [x19, #0x54d0]
   43520:	mov	x0, #0x3
   43524:	ldr	x2, [sp, #0x1b8]
   43528:	mov	x25, x0
   4352c:	cmp	x2, #0x166
   43530:	b.hs	0x40f18
   43534:	b	0x43b34
   43538:	mov	x0, #0x80d
   4353c:	ldur	x20, [sp]
   43540:	str	x0, [x20, #0x48]
   43544:	mov	x1, #0x0
   43548:	str	x1, [x19, #0x30]
   4354c:	mov	x0, #0x1000000000000000
   43550:	str	x0, [x19, #0x38]
   43554:	mov	x0, #0x1
   43558:	mov	x25, x0
   4355c:	str	x0, [x19, #0x48]
   43560:	mov	x0, #0x101010101010101
   43564:	str	x0, [x19, #0x50]
   43568:	mov	x0, #0x2
   4356c:	str	x0, [x19, #0x58]
   43570:	mov	x0, #0x3
   43574:	str	x0, [x19, #0x60]
   43578:	mov	x0, #0x4
   4357c:	str	x0, [x19, #0x68]
   43580:	mov	x0, #0xf0f0f0f0f0f0f0f
   43584:	str	x0, [x19, #0x90]
   43588:	mov	x0, #0x3333333333333333
   4358c:	str	x0, [x19, #0xa0]
   43590:	mov	x0, #0x38
   43594:	str	x0, [x19, #0xa8]
   43598:	mov	x0, #0x3a
   4359c:	str	x0, [x19, #0xb0]
   435a0:	mov	x0, #0x5555555555555555
   435a4:	str	x0, [x19, #0xc8]
   435a8:	mov	x0, #0x3ffffffffffffff
   435ac:	str	x0, [x19, #0xd8]
   435b0:	str	x1, [x19, #0x178]
   435b4:	mov	x0, x25
   435b8:	str	x0, [x19, #0x180]
   435bc:	str	x23, [x19, #0x2140]
   435c0:	str	x27, [x19, #0x2148]
   435c4:	ldur	x10, [sp, #0x58]
   435c8:	str	x10, [x19, #0x54d0]
   435cc:	str	x3, [x19, #0x54d8]
   435d0:	ldur	x4, [sp, #0x60]
   435d4:	str	x4, [x19, #0x54e0]
   435d8:	ldur	x24, [sp, #0x28]
   435dc:	str	x24, [x19, #0x6238]
   435e0:	str	x15, [x19, #0x62a8]
   435e4:	ldur	x23, [sp, #0x68]
   435e8:	str	x23, [x19, #0x62b0]
   435ec:	ldur	x28, [sp, #0x70]
   435f0:	str	x28, [x19, #0x62b8]
   435f4:	ldur	x4, [sp, #0x50]
   435f8:	sub	x1, x4, x3
   435fc:	mov	w0, #0xb946
   43600:	movk	w0, #0x1, lsl #16
   43604:	msub	x0, x15, x0, x1
   43608:	str	x0, [x19, #0x62c0]
   4360c:	str	x26, [x19, #0x62c8]
   43610:	str	x14, [x19, #0x62d0]
   43614:	ldur	x22, [sp, #0x78]
   43618:	str	x22, [x19, #0x62e0]
   4361c:	ldur	x9, [sp, #0x80]
   43620:	str	x9, [x19, #0x62e8]
   43624:	str	x12, [x19, #0x62f8]
   43628:	str	x11, [x19, #0x6300]
   4362c:	str	x7, [x19, #0x6310]
   43630:	str	x6, [x19, #0x6318]
   43634:	b	0x43b34
   43638:	mov	x8, #0x7e0
   4363c:	ldur	x20, [sp]
   43640:	str	x8, [x20, #0x48]
   43644:	mov	x8, #0x0
   43648:	str	x8, [x19, #0x30]
   4364c:	str	x0, [x19, #0x38]
   43650:	mov	x0, #0x1
   43654:	mov	x25, x0
   43658:	str	x0, [x19, #0x48]
   4365c:	mov	x10, #0x101010101010101
   43660:	str	x10, [x19, #0x50]
   43664:	mov	x11, #0x2
   43668:	str	x11, [x19, #0x58]
   4366c:	mov	x13, #0x3
   43670:	str	x13, [x19, #0x60]
   43674:	mov	x13, #0x4
   43678:	str	x13, [x19, #0x68]
   4367c:	mov	x0, #0xf0f0f0f0f0f0f0f
   43680:	str	x0, [x19, #0x90]
   43684:	mov	x0, #0x3333333333333333
   43688:	str	x0, [x19, #0xa0]
   4368c:	mov	x0, #0x38
   43690:	str	x0, [x19, #0xa8]
   43694:	mov	x0, #0x3a
   43698:	str	x0, [x19, #0xb0]
   4369c:	mov	x0, #0x5555555555555555
   436a0:	str	x0, [x19, #0xc8]
   436a4:	mov	x0, #0x3ffffffffffffff
   436a8:	str	x0, [x19, #0xd8]
   436ac:	str	x8, [x19, #0x178]
   436b0:	mov	x0, x25
   436b4:	str	x0, [x19, #0x180]
   436b8:	ldur	x23, [sp, #0xc8]
   436bc:	str	x23, [x19, #0x2140]
   436c0:	ldr	x27, [sp, #0x1b0]
   436c4:	str	x27, [x19, #0x2148]
   436c8:	ldr	x0, [sp, #0x118]
   436cc:	uxtb	w0, w0
   436d0:	str	x0, [x19, #0x2158]
   436d4:	str	x14, [x19, #0x25d8]
   436d8:	str	x12, [x19, #0x25e0]
   436dc:	str	x23, [x19, #0x25e8]
   436e0:	ldur	x10, [sp, #0x58]
   436e4:	str	x10, [x19, #0x54d0]
   436e8:	str	x3, [x19, #0x54d8]
   436ec:	ldur	x4, [sp, #0x60]
   436f0:	str	x4, [x19, #0x54e0]
   436f4:	ldur	x24, [sp, #0x28]
   436f8:	str	x24, [x19, #0x6238]
   436fc:	add	x1, x15, #0x1
   43700:	str	x1, [x19, #0x62a8]
   43704:	ldur	x23, [sp, #0x68]
   43708:	str	x23, [x19, #0x62b0]
   4370c:	ldur	x28, [sp, #0x70]
   43710:	str	x28, [x19, #0x62b8]
   43714:	ldur	x4, [sp, #0x50]
   43718:	sub	x2, x4, x3
   4371c:	mov	w0, #0xb946
   43720:	movk	w0, #0x1, lsl #16
   43724:	msub	x0, x1, x0, x2
   43728:	str	x0, [x19, #0x62c0]
   4372c:	str	x8, [x19, #0x62c8]
   43730:	str	x8, [x19, #0x62d0]
   43734:	ldur	x22, [sp, #0x78]
   43738:	str	x22, [x19, #0x62e0]
   4373c:	ldur	x9, [sp, #0x80]
   43740:	str	x9, [x19, #0x62e8]
   43744:	mov	x0, x25
   43748:	str	x0, [x19, #0x62f8]
   4374c:	ldur	x0, [sp, #0x20]
   43750:	str	x0, [x19, #0x6300]
   43754:	str	x7, [x19, #0x6310]
   43758:	str	x6, [x19, #0x6318]
   4375c:	b	0x43b34
   43760:	mov	x1, #0x7d0
   43764:	ldur	x20, [sp]
   43768:	str	x1, [x20, #0x48]
   4376c:	mov	x1, #0x0
   43770:	str	x1, [x19, #0x30]
   43774:	str	x0, [x19, #0x38]
   43778:	mov	x0, #0x1
   4377c:	mov	x25, x0
   43780:	str	x0, [x19, #0x48]
   43784:	mov	x0, #0x101010101010101
   43788:	str	x0, [x19, #0x50]
   4378c:	ldur	x4, [sp, #0xd8]
   43790:	str	x4, [x19, #0x58]
   43794:	mov	x0, #0x3
   43798:	str	x0, [x19, #0x60]
   4379c:	mov	x0, #0x4
   437a0:	str	x0, [x19, #0x68]
   437a4:	mov	x0, #0xf0f0f0f0f0f0f0f
   437a8:	str	x0, [x19, #0x90]
   437ac:	mov	x0, #0x3333333333333333
   437b0:	str	x0, [x19, #0xa0]
   437b4:	mov	x0, #0x38
   437b8:	str	x0, [x19, #0xa8]
   437bc:	mov	x0, #0x3a
   437c0:	str	x0, [x19, #0xb0]
   437c4:	mov	x2, #0x5555555555555555
   437c8:	str	x2, [x19, #0xc8]
   437cc:	ldur	x2, [sp, #0xd0]
   437d0:	str	x2, [x19, #0xd8]
   437d4:	str	x1, [x19, #0x178]
   437d8:	mov	x0, x25
   437dc:	str	x0, [x19, #0x180]
   437e0:	ldur	x23, [sp, #0xc8]
   437e4:	str	x23, [x19, #0x2140]
   437e8:	ldr	x0, [sp, #0x1b0]
   437ec:	str	x0, [x19, #0x2148]
   437f0:	ldr	x0, [sp, #0x118]
   437f4:	uxtb	w8, w0
   437f8:	str	x8, [x19, #0x2158]
   437fc:	str	x14, [x19, #0x25d8]
   43800:	str	x12, [x19, #0x25e0]
   43804:	str	x23, [x19, #0x25e8]
   43808:	ldur	x22, [sp, #0xe0]
   4380c:	str	x22, [x19, #0x2610]
   43810:	str	x11, [x19, #0x2680]
   43814:	str	x7, [x19, #0x2688]
   43818:	str	x23, [x19, #0x2690]
   4381c:	ldur	x10, [sp, #0x58]
   43820:	str	x10, [x19, #0x54d0]
   43824:	mov	w0, #0xccd6
   43828:	movk	w0, #0x2, lsl #16
   4382c:	sub	x2, x6, x0
   43830:	str	x2, [x19, #0x54d8]
   43834:	ldur	x4, [sp, #0x60]
   43838:	str	x4, [x19, #0x54e0]
   4383c:	ldur	x24, [sp, #0x28]
   43840:	str	x24, [x19, #0x6238]
   43844:	add	x3, x15, #0x1
   43848:	str	x3, [x19, #0x62a8]
   4384c:	ldur	x23, [sp, #0x68]
   43850:	str	x23, [x19, #0x62b0]
   43854:	ldur	x28, [sp, #0x70]
   43858:	str	x28, [x19, #0x62b8]
   4385c:	ldur	x4, [sp, #0x50]
   43860:	sub	x2, x4, x2
   43864:	mov	w0, #0xb946
   43868:	movk	w0, #0x1, lsl #16
   4386c:	msub	x0, x3, x0, x2
   43870:	str	x0, [x19, #0x62c0]
   43874:	str	x1, [x19, #0x62c8]
   43878:	str	x1, [x19, #0x62d0]
   4387c:	ldur	x22, [sp, #0x78]
   43880:	str	x22, [x19, #0x62e0]
   43884:	ldur	x9, [sp, #0x80]
   43888:	str	x9, [x19, #0x62e8]
   4388c:	mov	x0, x25
   43890:	str	x0, [x19, #0x62f8]
   43894:	ldur	x6, [sp, #0x20]
   43898:	str	x6, [x19, #0x6300]
   4389c:	str	x0, [x19, #0x6310]
   438a0:	str	x27, [x19, #0x6318]
   438a4:	b	0x43b34
   438a8:	mov	x0, #0x714
   438ac:	ldur	x20, [sp]
   438b0:	str	x0, [x20, #0x48]
   438b4:	mov	x1, #0x0
   438b8:	str	x1, [x19, #0x30]
   438bc:	mov	x0, #0x1000000000000000
   438c0:	str	x0, [x19, #0x38]
   438c4:	mov	x0, #0x1
   438c8:	mov	x25, x0
   438cc:	str	x0, [x19, #0x48]
   438d0:	mov	x0, #0x101010101010101
   438d4:	str	x0, [x19, #0x50]
   438d8:	mov	x0, #0x2
   438dc:	str	x0, [x19, #0x58]
   438e0:	mov	x0, #0x3
   438e4:	str	x0, [x19, #0x60]
   438e8:	mov	x0, #0x4
   438ec:	str	x0, [x19, #0x68]
   438f0:	mov	x0, #0xf0f0f0f0f0f0f0f
   438f4:	str	x0, [x19, #0x90]
   438f8:	mov	x0, #0x3333333333333333
   438fc:	str	x0, [x19, #0xa0]
   43900:	mov	x0, #0x38
   43904:	str	x0, [x19, #0xa8]
   43908:	mov	x0, #0x3a
   4390c:	str	x0, [x19, #0xb0]
   43910:	mov	x0, #0x5555555555555555
   43914:	str	x0, [x19, #0xc8]
   43918:	mov	x0, #0x3ffffffffffffff
   4391c:	str	x0, [x19, #0xd8]
   43920:	str	x1, [x19, #0x178]
   43924:	mov	x0, x25
   43928:	str	x0, [x19, #0x180]
   4392c:	ldur	x23, [sp, #0xc8]
   43930:	str	x23, [x19, #0x2140]
   43934:	ldr	x27, [sp, #0x1b0]
   43938:	str	x27, [x19, #0x2148]
   4393c:	ldr	x4, [sp, #0x118]
   43940:	uxtb	w0, w4
   43944:	str	x0, [x19, #0x2158]
   43948:	str	x5, [x19, #0x21e8]
   4394c:	ldr	x14, [sp, #0x108]
   43950:	str	x14, [x19, #0x21f0]
   43954:	str	x23, [x19, #0x21f8]
   43958:	ldr	x26, [sp, #0x100]
   4395c:	str	x26, [x19, #0x2200]
   43960:	ldur	x10, [sp, #0x58]
   43964:	str	x10, [x19, #0x54d0]
   43968:	str	x3, [x19, #0x54d8]
   4396c:	ldur	x4, [sp, #0x60]
   43970:	str	x4, [x19, #0x54e0]
   43974:	ldur	x24, [sp, #0x28]
   43978:	str	x24, [x19, #0x6238]
   4397c:	add	x4, x15, #0x1
   43980:	str	x4, [x19, #0x62a8]
   43984:	ldur	x23, [sp, #0x68]
   43988:	str	x23, [x19, #0x62b0]
   4398c:	ldur	x28, [sp, #0x70]
   43990:	str	x28, [x19, #0x62b8]
   43994:	ldur	x0, [sp, #0x50]
   43998:	sub	x8, x0, x3
   4399c:	mov	w9, #0xb946
   439a0:	movk	w9, #0x1, lsl #16
   439a4:	msub	x8, x4, x9, x8
   439a8:	str	x8, [x19, #0x62c0]
   439ac:	mov	x0, x25
   439b0:	str	x0, [x19, #0x62c8]
   439b4:	ldur	x14, [sp, #0x18]
   439b8:	str	x14, [x19, #0x62d0]
   439bc:	ldur	x22, [sp, #0x78]
   439c0:	str	x22, [x19, #0x62e0]
   439c4:	ldur	x9, [sp, #0x80]
   439c8:	str	x9, [x19, #0x62e8]
   439cc:	str	x12, [x19, #0x62f8]
   439d0:	str	x11, [x19, #0x6300]
   439d4:	str	x7, [x19, #0x6310]
   439d8:	str	x6, [x19, #0x6318]
   439dc:	b	0x43b34
   439e0:	mov	x0, #0x704
   439e4:	ldur	x20, [sp]
   439e8:	str	x0, [x20, #0x48]
   439ec:	mov	x1, #0x0
   439f0:	str	x1, [x19, #0x30]
   439f4:	mov	x0, #0x1000000000000000
   439f8:	str	x0, [x19, #0x38]
   439fc:	mov	x0, #0x1
   43a00:	mov	x25, x0
   43a04:	str	x0, [x19, #0x48]
   43a08:	mov	x0, #0x101010101010101
   43a0c:	str	x0, [x19, #0x50]
   43a10:	str	x23, [x19, #0x58]
   43a14:	mov	x0, #0x3
   43a18:	str	x0, [x19, #0x60]
   43a1c:	mov	x0, #0x4
   43a20:	str	x0, [x19, #0x68]
   43a24:	mov	x0, #0xf0f0f0f0f0f0f0f
   43a28:	str	x0, [x19, #0x90]
   43a2c:	mov	x0, #0x3333333333333333
   43a30:	str	x0, [x19, #0xa0]
   43a34:	mov	x0, #0x38
   43a38:	str	x0, [x19, #0xa8]
   43a3c:	mov	x0, #0x3a
   43a40:	str	x0, [x19, #0xb0]
   43a44:	mov	x0, #0x5555555555555555
   43a48:	str	x0, [x19, #0xc8]
   43a4c:	mov	x0, #0x3ffffffffffffff
   43a50:	str	x0, [x19, #0xd8]
   43a54:	str	x1, [x19, #0x178]
   43a58:	mov	x0, x25
   43a5c:	str	x0, [x19, #0x180]
   43a60:	ldur	x23, [sp, #0xc8]
   43a64:	str	x23, [x19, #0x2140]
   43a68:	ldr	x27, [sp, #0x1b0]
   43a6c:	str	x27, [x19, #0x2148]
   43a70:	ldr	x10, [sp, #0x118]
   43a74:	uxtb	w0, w10
   43a78:	str	x0, [x19, #0x2158]
   43a7c:	ldur	x14, [sp, #0xb8]
   43a80:	str	x14, [x19, #0x21e8]
   43a84:	ldr	x14, [sp, #0x108]
   43a88:	str	x14, [x19, #0x21f0]
   43a8c:	str	x23, [x19, #0x21f8]
   43a90:	ldr	x26, [sp, #0x100]
   43a94:	str	x26, [x19, #0x2200]
   43a98:	ldur	x14, [sp, #0xf8]
   43a9c:	uxtb	w0, w14
   43aa0:	str	x0, [x19, #0x2210]
   43aa4:	str	x9, [x19, #0x2288]
   43aa8:	str	x8, [x19, #0x2290]
   43aac:	str	x23, [x19, #0x2298]
   43ab0:	str	x26, [x19, #0x22a0]
   43ab4:	ldur	x10, [sp, #0x58]
   43ab8:	str	x10, [x19, #0x54d0]
   43abc:	mov	w0, #0xe176
   43ac0:	movk	w0, #0x2, lsl #16
   43ac4:	sub	x1, x5, x0
   43ac8:	str	x1, [x19, #0x54d8]
   43acc:	ldur	x4, [sp, #0x60]
   43ad0:	str	x4, [x19, #0x54e0]
   43ad4:	ldur	x24, [sp, #0x28]
   43ad8:	str	x24, [x19, #0x6238]
   43adc:	add	x2, x15, #0x1
   43ae0:	str	x2, [x19, #0x62a8]
   43ae4:	ldur	x23, [sp, #0x68]
   43ae8:	str	x23, [x19, #0x62b0]
   43aec:	ldur	x28, [sp, #0x70]
   43af0:	str	x28, [x19, #0x62b8]
   43af4:	ldur	x4, [sp, #0x50]
   43af8:	sub	x1, x4, x1
   43afc:	mov	w0, #0xb946
   43b00:	movk	w0, #0x1, lsl #16
   43b04:	msub	x0, x2, x0, x1
   43b08:	str	x0, [x19, #0x62c0]
   43b0c:	mov	x0, x25
   43b10:	str	x0, [x19, #0x62c8]
   43b14:	ldur	x14, [sp, #0x18]
   43b18:	str	x14, [x19, #0x62d0]
   43b1c:	str	x0, [x19, #0x62e0]
   43b20:	str	x21, [x19, #0x62e8]
   43b24:	str	x12, [x19, #0x62f8]
   43b28:	str	x11, [x19, #0x6300]
   43b2c:	str	x7, [x19, #0x6310]
   43b30:	str	x6, [x19, #0x6318]
   43b34:	mov	x1, #0x0
   43b38:	mov	x0, x25
   43b3c:	add	sp, sp, #0x1e0
   43b40:	ldp	x19, x20, [sp], #0x10
   43b44:	ldp	x21, x22, [sp], #0x10
   43b48:	ldp	x23, x24, [sp], #0x10
   43b4c:	ldp	x25, x26, [sp], #0x10
   43b50:	ldp	x27, x28, [sp], #0x10
   43b54:	ldp	x29, x30, [sp], #0x10
   43b58:	.long	0xd65f0fff
   43b5c:	udf	#0x0
   43b60:	udf	#0x0
   43b64:	udf	#0x0
   43b68:	udf	#0x0
   43b6c:	udf	#0x0
   43b70:	udf	#0x0
   43b74:	udf	#0x0
   43b78:	udf	#0x0
   43b7c:	udf	#0x0
