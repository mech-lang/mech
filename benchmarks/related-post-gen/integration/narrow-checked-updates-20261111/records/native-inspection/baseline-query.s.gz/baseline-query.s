/private/tmp/mech-related-narrow-updates-20261111/objects/baseline/object.o:
(__TEXT,__text) section
_mech_canonical_program_entry_v1_numeric_1646:
   3bc80:	hint	#27
   3bc84:	stp	x29, x30, [sp, #-0x10]!
   3bc88:	mov	x29, sp
   3bc8c:	stp	x27, x28, [sp, #-0x10]!
   3bc90:	stp	x25, x26, [sp, #-0x10]!
   3bc94:	stp	x23, x24, [sp, #-0x10]!
   3bc98:	stp	x21, x22, [sp, #-0x10]!
   3bc9c:	stp	x19, x20, [sp, #-0x10]!
   3bca0:	sub	sp, sp, #0x1d0
   3bca4:	mov	x5, x1
   3bca8:	stur	x2, [sp, #0x8]
   3bcac:	ldr	x27, [x0, #0x50]
   3bcb0:	str	x27, [sp, #0x1b0]
   3bcb4:	ldr	x6, [x0, #0x58]
   3bcb8:	ldr	x1, [x0, #0x60]
   3bcbc:	ldr	x13, [x0, #0x68]
   3bcc0:	stur	x0, [sp]
   3bcc4:	str	x13, [sp, #0x198]
   3bcc8:	mov	x0, #0x3
   3bccc:	cmp	x27, #0x0
   3bcd0:	b.eq	0x40f0c
   3bcd4:	mov	x0, #0x3
   3bcd8:	cmp	x6, #0x0
   3bcdc:	str	x6, [sp, #0x1a8]
   3bce0:	b.eq	0x40f14
   3bce4:	mov	x0, #0x3
   3bce8:	stur	x0, [sp, #0xc0]
   3bcec:	cmp	x1, #0x0
   3bcf0:	b.eq	0x43a18
   3bcf4:	mov	x0, x5
   3bcf8:	ldr	x26, [x0, #0x5788]
   3bcfc:	cmp	x26, #0x0
   3bd00:	stur	x26, [sp, #0x58]
   3bd04:	b.eq	0x3c258
   3bd08:	ldr	x22, [x1, #0x10]
   3bd0c:	ldr	x3, [x0, #0x5790]
   3bd10:	ldr	x4, [x0, #0x5798]
   3bd14:	stur	x4, [sp, #0x60]
   3bd18:	ldr	x28, [x22, #0xec0]
   3bd1c:	stur	x28, [sp, #0xb8]
   3bd20:	ldr	x28, [x22, #0xed0]
   3bd24:	str	x28, [sp, #0x190]
   3bd28:	ldr	x19, [x1, #0xab8]
   3bd2c:	stur	x19, [sp, #0x90]
   3bd30:	ldr	x0, [x1, #0xac0]
   3bd34:	stur	x0, [sp, #0x28]
   3bd38:	ldr	x0, [x1, #0xac8]
   3bd3c:	ldr	x0, [x1, #0xad0]
   3bd40:	ldr	x25, [x1, #0xad8]
   3bd44:	str	x25, [sp, #0x188]
   3bd48:	ldr	x25, [x1, #0xae0]
   3bd4c:	str	x25, [sp, #0x180]
   3bd50:	ldr	x0, [x1, #0xae8]
   3bd54:	ldr	x0, [x1, #0xaf0]
   3bd58:	ldr	x25, [x1, #0xaf8]
   3bd5c:	str	x25, [sp, #0x178]
   3bd60:	ldr	x25, [x1, #0xb00]
   3bd64:	str	x25, [sp, #0x170]
   3bd68:	ldr	x0, [x1, #0xb08]
   3bd6c:	ldr	x0, [x1, #0xb10]
   3bd70:	ldr	x25, [x1, #0xb18]
   3bd74:	str	x25, [sp, #0x168]
   3bd78:	ldr	x25, [x1, #0xb20]
   3bd7c:	str	x25, [sp, #0x160]
   3bd80:	ldr	x0, [x1, #0xb28]
   3bd84:	ldr	x0, [x1, #0xb30]
   3bd88:	ldr	x25, [x1, #0xb38]
   3bd8c:	str	x25, [sp, #0x158]
   3bd90:	ldr	x25, [x1, #0xb40]
   3bd94:	str	x25, [sp, #0x150]
   3bd98:	ldr	x0, [x1, #0xb48]
   3bd9c:	ldr	x0, [x1, #0xb50]
   3bda0:	ldr	x25, [x1, #0xb58]
   3bda4:	str	x25, [sp, #0x148]
   3bda8:	ldr	x25, [x1, #0xb60]
   3bdac:	str	x25, [sp, #0x140]
   3bdb0:	ldr	x0, [x1, #0xb68]
   3bdb4:	ldr	x0, [x1, #0xb70]
   3bdb8:	ldr	x25, [x1, #0xb78]
   3bdbc:	str	x25, [sp, #0x138]
   3bdc0:	ldr	x25, [x1, #0xb80]
   3bdc4:	str	x25, [sp, #0x130]
   3bdc8:	ldr	x0, [x1, #0xb88]
   3bdcc:	ldr	x0, [x1, #0xb90]
   3bdd0:	ldr	x25, [x1, #0xb98]
   3bdd4:	str	x25, [sp, #0x128]
   3bdd8:	ldr	x25, [x1, #0xba0]
   3bddc:	str	x25, [sp, #0x120]
   3bde0:	ldr	x0, [x1, #0xba8]
   3bde4:	ldr	x0, [x1, #0xbb0]
   3bde8:	ldr	x25, [x1, #0xbb8]
   3bdec:	str	x25, [sp, #0x118]
   3bdf0:	ldr	x25, [x1, #0xbc0]
   3bdf4:	str	x25, [sp, #0x110]
   3bdf8:	ldr	x0, [x1, #0xbc8]
   3bdfc:	ldr	x0, [x1, #0xbd0]
   3be00:	ldr	x26, [x1, #0xbd8]
   3be04:	str	x26, [sp, #0x108]
   3be08:	ldr	x25, [x1, #0xbe0]
   3be0c:	str	x25, [sp, #0x100]
   3be10:	ldr	x0, [x1, #0xbe8]
   3be14:	ldr	x0, [x1, #0xbf0]
   3be18:	ldr	x4, [x1, #0xc48]
   3be1c:	stur	x4, [sp, #0x88]
   3be20:	str	x1, [sp, #0x1a0]
   3be24:	mov	x14, #0x0
   3be28:	mov	x21, #0x1
   3be2c:	stur	x21, [sp, #0x68]
   3be30:	mov	x13, #0xf
   3be34:	mov	x6, x14
   3be38:	mov	x7, x14
   3be3c:	mov	x10, x14
   3be40:	mov	x11, x14
   3be44:	mov	x12, x14
   3be48:	mov	x15, x14
   3be4c:	mov	x20, x14
   3be50:	mov	x21, x14
   3be54:	mov	x27, x14
   3be58:	stur	x3, [sp, #0x50]
   3be5c:	stur	x14, [sp, #0x80]
   3be60:	mov	w0, #0xc87e
   3be64:	movk	w0, #0x1, lsl #16
   3be68:	cmp	x3, x0
   3be6c:	cset	x1, hs
   3be70:	ldur	x0, [sp, #0x28]
   3be74:	ldur	x2, [sp, #0x88]
   3be78:	cmp	x0, x2
   3be7c:	cset	x4, ls
   3be80:	sub	x0, x2, x0
   3be84:	cmp	x0, #0x4
   3be88:	cset	x0, hi
   3be8c:	and	w4, w4, w0
   3be90:	and	w1, w1, w4
   3be94:	uxtb	w1, w1
   3be98:	cbz	x1, 0x40f1c
   3be9c:	stur	x10, [sp, #0x78]
   3bea0:	stur	x21, [sp, #0x70]
   3bea4:	mov	x23, x5
   3bea8:	ldur	x4, [sp, #0x60]
   3beac:	ldr	x2, [sp, #0x198]
   3beb0:	ldr	x1, [sp, #0x1a0]
   3beb4:	b	0x3c280
   3beb8:	mov	x2, x3
   3bebc:	ldur	x0, [sp, #0x60]
   3bec0:	b	0x3bf48
   3bec4:	ldur	x8, [sp, #0xb8]
   3bec8:	cmp	x8, x28
   3becc:	b.lo	0x3bf2c
   3bed0:	cmp	x1, x28
   3bed4:	b.lo	0x3bf1c
   3bed8:	ldur	x0, [sp, #0xb8]
   3bedc:	cmp	x0, x28
   3bee0:	b.lo	0x3bf0c
   3bee4:	cmp	x0, x28
   3bee8:	b.lo	0x3befc
   3beec:	mov	w1, #0x1
   3bef0:	ldur	x0, [sp, #0x60]
   3bef4:	mov	x2, x3
   3bef8:	b	0x3bf48
   3befc:	mov	w1, #0x1
   3bf00:	ldur	x0, [sp, #0x60]
   3bf04:	mov	x2, x3
   3bf08:	b	0x3bf48
   3bf0c:	mov	w1, #0x1
   3bf10:	ldur	x0, [sp, #0x60]
   3bf14:	mov	x2, x3
   3bf18:	b	0x3bf48
   3bf1c:	mov	x2, x3
   3bf20:	mov	x1, x0
   3bf24:	ldur	x0, [sp, #0x60]
   3bf28:	b	0x3bf48
   3bf2c:	mov	w1, #0x1
   3bf30:	ldur	x0, [sp, #0x60]
   3bf34:	mov	x2, x3
   3bf38:	b	0x3bf48
   3bf3c:	mov	w1, #0x1
   3bf40:	ldur	x0, [sp, #0x60]
   3bf44:	mov	x2, x3
   3bf48:	tbz	w1, #0x0, 0x3bf68
   3bf4c:	ldr	x1, [sp, #0x1a0]
   3bf50:	ldr	x2, [sp, #0x198]
   3bf54:	ldur	x4, [sp, #0x60]
   3bf58:	mov	x23, x5
   3bf5c:	stur	x21, [sp, #0x70]
   3bf60:	stur	x10, [sp, #0x78]
   3bf64:	b	0x3c280
   3bf68:	mov	x3, x2
   3bf6c:	stur	x0, [sp, #0x60]
   3bf70:	mov	x8, #0x0
   3bf74:	mov	x23, x5
   3bf78:	str	x8, [x23, #0x18]
   3bf7c:	mov	x9, #0x1000000000000000
   3bf80:	str	x9, [x23, #0x20]
   3bf84:	mov	x13, #0x1
   3bf88:	str	x13, [x23, #0x30]
   3bf8c:	mov	x0, #0x101010101010101
   3bf90:	str	x0, [x23, #0x38]
   3bf94:	mov	x0, #0x2
   3bf98:	str	x0, [x23, #0x40]
   3bf9c:	mov	x0, #0x3
   3bfa0:	str	x0, [x23, #0x48]
   3bfa4:	mov	x0, #0x4
   3bfa8:	str	x0, [x23, #0x50]
   3bfac:	mov	x0, #0xf0f0f0f0f0f0f0f
   3bfb0:	str	x0, [x23, #0x78]
   3bfb4:	mov	x0, #0x3333333333333333
   3bfb8:	str	x0, [x23, #0x88]
   3bfbc:	mov	x0, #0x38
   3bfc0:	str	x0, [x23, #0x90]
   3bfc4:	mov	x0, #0x3a
   3bfc8:	str	x0, [x23, #0x98]
   3bfcc:	mov	x0, #0x5555555555555555
   3bfd0:	str	x0, [x23, #0xb0]
   3bfd4:	mov	x0, #0x3ffffffffffffff
   3bfd8:	str	x0, [x23, #0xb8]
   3bfdc:	str	x8, [x23, #0x188]
   3bfe0:	str	x13, [x23, #0x190]
   3bfe4:	ldur	x26, [sp, #0x58]
   3bfe8:	str	x26, [x23, #0x5788]
   3bfec:	str	x3, [x23, #0x5790]
   3bff0:	ldur	x4, [sp, #0x60]
   3bff4:	str	x4, [x23, #0x5798]
   3bff8:	ldur	x27, [sp, #0xb8]
   3bffc:	str	x27, [x23, #0x5ac0]
   3c000:	ldr	x28, [sp, #0x190]
   3c004:	str	x28, [x23, #0x5ac8]
   3c008:	ldur	x1, [sp, #0x28]
   3c00c:	str	x1, [x23, #0x6570]
   3c010:	str	x14, [x23, #0x6700]
   3c014:	ldur	x0, [sp, #0x68]
   3c018:	str	x0, [x23, #0x6708]
   3c01c:	str	x21, [x23, #0x6710]
   3c020:	ldur	x4, [sp, #0x50]
   3c024:	sub	x0, x4, x3
   3c028:	mov	w1, #0xc87e
   3c02c:	movk	w1, #0x1, lsl #16
   3c030:	msub	x0, x14, x1, x0
   3c034:	str	x0, [x23, #0x6718]
   3c038:	str	x20, [x23, #0x6720]
   3c03c:	str	x15, [x23, #0x6728]
   3c040:	str	x10, [x23, #0x6738]
   3c044:	ldur	x9, [sp, #0x80]
   3c048:	str	x9, [x23, #0x6740]
   3c04c:	str	x12, [x23, #0x6750]
   3c050:	str	x11, [x23, #0x6758]
   3c054:	str	x7, [x23, #0x6768]
   3c058:	str	x6, [x23, #0x6770]
   3c05c:	ldr	x0, [x23, #0x5788]
   3c060:	cmp	x0, #0x0
   3c064:	b.eq	0x3c258
   3c068:	ldr	x3, [x23, #0x5790]
   3c06c:	ldr	x4, [x23, #0x5798]
   3c070:	mov	x0, #0x0
   3c074:	str	x0, [x23, #0x5788]
   3c078:	mov	x0, #0x3
   3c07c:	ldr	x2, [sp, #0x198]
   3c080:	cmp	x2, #0x19a
   3c084:	b.lo	0x40f68
   3c088:	ldr	x0, [x23, #0x5ac0]
   3c08c:	ldr	x1, [sp, #0x1a0]
   3c090:	str	x0, [x1, #0x10]
   3c094:	ldr	x2, [x23, #0x5ac8]
   3c098:	str	x2, [x1, #0x18]
   3c09c:	ldr	x5, [x23, #0x6570]
   3c0a0:	str	x5, [x1, #0xac0]
   3c0a4:	str	x0, [x1, #0x10]
   3c0a8:	str	x2, [x1, #0x18]
   3c0ac:	ldr	x0, [x23, #0x5c10]
   3c0b0:	str	x0, [x1, #0x160]
   3c0b4:	ldr	x0, [x23, #0x5c18]
   3c0b8:	str	x0, [x1, #0x168]
   3c0bc:	ldr	x0, [x23, #0x5c20]
   3c0c0:	str	x0, [x1, #0x170]
   3c0c4:	ldr	x0, [x23, #0x5c28]
   3c0c8:	str	x0, [x1, #0x178]
   3c0cc:	ldr	x0, [x23, #0x5c30]
   3c0d0:	str	x0, [x1, #0x180]
   3c0d4:	ldr	x0, [x23, #0x5c38]
   3c0d8:	str	x0, [x1, #0x188]
   3c0dc:	ldr	x0, [x23, #0x5c40]
   3c0e0:	str	x0, [x1, #0x190]
   3c0e4:	ldr	x0, [x23, #0x5c48]
   3c0e8:	str	x0, [x1, #0x198]
   3c0ec:	ldr	x0, [x23, #0x5c50]
   3c0f0:	str	x0, [x1, #0x1a0]
   3c0f4:	ldr	x0, [x23, #0x5df8]
   3c0f8:	str	x0, [x1, #0x348]
   3c0fc:	ldr	x0, [x23, #0x5e00]
   3c100:	str	x0, [x1, #0x350]
   3c104:	ldr	x2, [x23, #0x5e08]
   3c108:	str	x2, [x1, #0x358]
   3c10c:	ldr	x2, [x23, #0x5e10]
   3c110:	str	x2, [x1, #0x360]
   3c114:	ldr	x5, [x23, #0x5e18]
   3c118:	str	x5, [x1, #0x368]
   3c11c:	ldr	x5, [x23, #0x5e20]
   3c120:	str	x5, [x1, #0x370]
   3c124:	ldr	x5, [x23, #0x5e28]
   3c128:	str	x5, [x1, #0x378]
   3c12c:	ldr	x6, [x23, #0x5e30]
   3c130:	str	x6, [x1, #0x380]
   3c134:	ldr	x7, [x23, #0x5e38]
   3c138:	str	x7, [x1, #0x388]
   3c13c:	ldr	x8, [x23, #0x6128]
   3c140:	str	x8, [x1, #0x678]
   3c144:	ldr	x9, [x23, #0x6130]
   3c148:	str	x9, [x1, #0x680]
   3c14c:	ldr	x10, [x23, #0x6138]
   3c150:	str	x10, [x1, #0x688]
   3c154:	ldr	x11, [x23, #0x6140]
   3c158:	str	x11, [x1, #0x690]
   3c15c:	ldr	x12, [x23, #0x6148]
   3c160:	str	x12, [x1, #0x698]
   3c164:	ldr	x13, [x23, #0x6150]
   3c168:	str	x13, [x1, #0x6a0]
   3c16c:	ldr	x14, [x23, #0x6158]
   3c170:	str	x14, [x1, #0x6a8]
   3c174:	ldr	x15, [x23, #0x6160]
   3c178:	str	x15, [x1, #0x6b0]
   3c17c:	ldr	x0, [x23, #0x62f0]
   3c180:	str	x0, [x1, #0x840]
   3c184:	ldr	x0, [x23, #0x62f8]
   3c188:	str	x0, [x1, #0x848]
   3c18c:	ldr	x0, [x23, #0x6300]
   3c190:	str	x0, [x1, #0x850]
   3c194:	ldr	x0, [x23, #0x6308]
   3c198:	str	x0, [x1, #0x858]
   3c19c:	ldr	x0, [x23, #0x6310]
   3c1a0:	str	x0, [x1, #0x860]
   3c1a4:	ldr	x0, [x23, #0x6318]
   3c1a8:	str	x0, [x1, #0x868]
   3c1ac:	ldr	x0, [x23, #0x6320]
   3c1b0:	str	x0, [x1, #0x870]
   3c1b4:	ldr	x0, [x23, #0x6328]
   3c1b8:	str	x0, [x1, #0x878]
   3c1bc:	ldr	x0, [x23, #0x6700]
   3c1c0:	str	x0, [x1, #0xc50]
   3c1c4:	ldr	x0, [x23, #0x6708]
   3c1c8:	str	x0, [x1, #0xc58]
   3c1cc:	ldr	x0, [x23, #0x6710]
   3c1d0:	str	x0, [x1, #0xc60]
   3c1d4:	ldr	x0, [x23, #0x6718]
   3c1d8:	str	x0, [x1, #0xc68]
   3c1dc:	ldr	x0, [x23, #0x6720]
   3c1e0:	str	x0, [x1, #0xc70]
   3c1e4:	ldr	x0, [x23, #0x6728]
   3c1e8:	str	x0, [x1, #0xc78]
   3c1ec:	mov	x0, #0x0
   3c1f0:	str	x0, [x1, #0xc80]
   3c1f4:	ldr	x2, [x23, #0x6738]
   3c1f8:	str	x2, [x1, #0xc88]
   3c1fc:	ldr	x2, [x23, #0x6740]
   3c200:	str	x2, [x1, #0xc90]
   3c204:	str	x0, [x1, #0xc98]
   3c208:	ldr	x2, [x23, #0x6750]
   3c20c:	str	x2, [x1, #0xca0]
   3c210:	ldr	x2, [x23, #0x6758]
   3c214:	str	x2, [x1, #0xca8]
   3c218:	str	x0, [x1, #0xcb0]
   3c21c:	ldr	x0, [x23, #0x6768]
   3c220:	str	x0, [x1, #0xcb8]
   3c224:	ldr	x0, [x23, #0x6770]
   3c228:	str	x0, [x1, #0xcc0]
   3c22c:	mov	x1, #0x66e
   3c230:	mov	x2, #-0x9
   3c234:	mov	x5, #0x1
   3c238:	ldur	x0, [sp, #0x8]
   3c23c:	ldr	x6, [sp, #0x1a8]
   3c240:	ldr	x27, [sp, #0x1b0]
   3c244:	blr	x27
   3c248:	mov	x1, x0
   3c24c:	mov	x0, #0x2
   3c250:	cmp	x1, #0x0
   3c254:	b.ne	0x40f70
   3c258:	mov	x1, #0x0
   3c25c:	mov	x0, x1
   3c260:	add	sp, sp, #0x1d0
   3c264:	ldp	x19, x20, [sp], #0x10
   3c268:	ldp	x21, x22, [sp], #0x10
   3c26c:	ldp	x23, x24, [sp], #0x10
   3c270:	ldp	x25, x26, [sp], #0x10
   3c274:	ldp	x27, x28, [sp], #0x10
   3c278:	ldp	x29, x30, [sp], #0x10
   3c27c:	.long	0xd65f0fff
   3c280:	ldur	x0, [sp, #0xb8]
   3c284:	ldr	x28, [sp, #0x190]
   3c288:	cmp	x0, x28
   3c28c:	cset	x0, lo
   3c290:	ldur	x5, [sp, #0xb8]
   3c294:	cmp	x5, x28
   3c298:	b.lo	0x3c2e0
   3c29c:	mov	x0, #0x0
   3c2a0:	stur	x0, [sp, #0x10]
   3c2a4:	mov	w0, #0xc87e
   3c2a8:	movk	w0, #0x1, lsl #16
   3c2ac:	sub	x3, x3, x0
   3c2b0:	str	x1, [sp, #0x1a0]
   3c2b4:	str	x2, [sp, #0x198]
   3c2b8:	stur	x4, [sp, #0x60]
   3c2bc:	ldur	x0, [sp, #0x10]
   3c2c0:	stur	x0, [sp, #0x48]
   3c2c4:	stur	x0, [sp, #0x40]
   3c2c8:	stur	x0, [sp, #0x38]
   3c2cc:	stur	x0, [sp, #0x30]
   3c2d0:	ldur	x24, [sp, #0xb8]
   3c2d4:	ldur	x21, [sp, #0xb8]
   3c2d8:	ldur	x2, [sp, #0x88]
   3c2dc:	b	0x40428
   3c2e0:	ldr	x26, [sp, #0x180]
   3c2e4:	cmp	x5, x26
   3c2e8:	b.lo	0x3c538
   3c2ec:	b	0x40f78
   3c2f0:	str	x2, [sp, #0x198]
   3c2f4:	str	x1, [sp, #0x1a0]
   3c2f8:	b	0x3c4e4
   3c2fc:	ldr	x3, [x23, #0x5790]
   3c300:	ldr	x4, [x23, #0x5798]
   3c304:	mov	x0, #0x0
   3c308:	str	x0, [x23, #0x5788]
   3c30c:	mov	x0, #0x3
   3c310:	cmp	x2, #0x19a
   3c314:	str	x2, [sp, #0x198]
   3c318:	b.lo	0x4109c
   3c31c:	ldr	x0, [x23, #0x5ac0]
   3c320:	str	x0, [x1, #0x10]
   3c324:	ldr	x2, [x23, #0x5ac8]
   3c328:	str	x2, [x1, #0x18]
   3c32c:	ldr	x5, [x23, #0x6570]
   3c330:	str	x5, [x1, #0xac0]
   3c334:	str	x0, [x1, #0x10]
   3c338:	str	x2, [x1, #0x18]
   3c33c:	ldr	x0, [x23, #0x5c10]
   3c340:	str	x0, [x1, #0x160]
   3c344:	ldr	x0, [x23, #0x5c18]
   3c348:	str	x0, [x1, #0x168]
   3c34c:	ldr	x0, [x23, #0x5c20]
   3c350:	str	x0, [x1, #0x170]
   3c354:	ldr	x0, [x23, #0x5c28]
   3c358:	str	x0, [x1, #0x178]
   3c35c:	ldr	x0, [x23, #0x5c30]
   3c360:	str	x0, [x1, #0x180]
   3c364:	ldr	x0, [x23, #0x5c38]
   3c368:	str	x0, [x1, #0x188]
   3c36c:	ldr	x0, [x23, #0x5c40]
   3c370:	str	x0, [x1, #0x190]
   3c374:	ldr	x0, [x23, #0x5c48]
   3c378:	str	x0, [x1, #0x198]
   3c37c:	ldr	x0, [x23, #0x5c50]
   3c380:	str	x0, [x1, #0x1a0]
   3c384:	ldr	x0, [x23, #0x5df8]
   3c388:	str	x0, [x1, #0x348]
   3c38c:	ldr	x0, [x23, #0x5e00]
   3c390:	str	x0, [x1, #0x350]
   3c394:	ldr	x0, [x23, #0x5e08]
   3c398:	str	x0, [x1, #0x358]
   3c39c:	ldr	x2, [x23, #0x5e10]
   3c3a0:	str	x2, [x1, #0x360]
   3c3a4:	ldr	x2, [x23, #0x5e18]
   3c3a8:	str	x2, [x1, #0x368]
   3c3ac:	ldr	x5, [x23, #0x5e20]
   3c3b0:	str	x5, [x1, #0x370]
   3c3b4:	ldr	x5, [x23, #0x5e28]
   3c3b8:	str	x5, [x1, #0x378]
   3c3bc:	ldr	x5, [x23, #0x5e30]
   3c3c0:	str	x5, [x1, #0x380]
   3c3c4:	ldr	x6, [x23, #0x5e38]
   3c3c8:	str	x6, [x1, #0x388]
   3c3cc:	ldr	x7, [x23, #0x6128]
   3c3d0:	str	x7, [x1, #0x678]
   3c3d4:	ldr	x8, [x23, #0x6130]
   3c3d8:	str	x8, [x1, #0x680]
   3c3dc:	ldr	x9, [x23, #0x6138]
   3c3e0:	str	x9, [x1, #0x688]
   3c3e4:	ldr	x10, [x23, #0x6140]
   3c3e8:	str	x10, [x1, #0x690]
   3c3ec:	ldr	x11, [x23, #0x6148]
   3c3f0:	str	x11, [x1, #0x698]
   3c3f4:	ldr	x12, [x23, #0x6150]
   3c3f8:	str	x12, [x1, #0x6a0]
   3c3fc:	ldr	x13, [x23, #0x6158]
   3c400:	str	x13, [x1, #0x6a8]
   3c404:	ldr	x14, [x23, #0x6160]
   3c408:	str	x14, [x1, #0x6b0]
   3c40c:	ldr	x15, [x23, #0x62f0]
   3c410:	str	x15, [x1, #0x840]
   3c414:	ldr	x0, [x23, #0x62f8]
   3c418:	str	x0, [x1, #0x848]
   3c41c:	ldr	x0, [x23, #0x6300]
   3c420:	str	x0, [x1, #0x850]
   3c424:	ldr	x0, [x23, #0x6308]
   3c428:	str	x0, [x1, #0x858]
   3c42c:	ldr	x0, [x23, #0x6310]
   3c430:	str	x0, [x1, #0x860]
   3c434:	ldr	x0, [x23, #0x6318]
   3c438:	str	x0, [x1, #0x868]
   3c43c:	ldr	x0, [x23, #0x6320]
   3c440:	str	x0, [x1, #0x870]
   3c444:	ldr	x0, [x23, #0x6328]
   3c448:	str	x0, [x1, #0x878]
   3c44c:	ldr	x0, [x23, #0x6700]
   3c450:	str	x0, [x1, #0xc50]
   3c454:	ldr	x0, [x23, #0x6708]
   3c458:	str	x0, [x1, #0xc58]
   3c45c:	ldr	x0, [x23, #0x6710]
   3c460:	str	x0, [x1, #0xc60]
   3c464:	ldr	x0, [x23, #0x6718]
   3c468:	str	x0, [x1, #0xc68]
   3c46c:	ldr	x0, [x23, #0x6720]
   3c470:	str	x0, [x1, #0xc70]
   3c474:	ldr	x0, [x23, #0x6728]
   3c478:	str	x0, [x1, #0xc78]
   3c47c:	mov	x0, #0x0
   3c480:	str	x0, [x1, #0xc80]
   3c484:	ldr	x2, [x23, #0x6738]
   3c488:	str	x2, [x1, #0xc88]
   3c48c:	ldr	x2, [x23, #0x6740]
   3c490:	str	x2, [x1, #0xc90]
   3c494:	str	x0, [x1, #0xc98]
   3c498:	ldr	x2, [x23, #0x6750]
   3c49c:	str	x2, [x1, #0xca0]
   3c4a0:	ldr	x2, [x23, #0x6758]
   3c4a4:	str	x2, [x1, #0xca8]
   3c4a8:	str	x0, [x1, #0xcb0]
   3c4ac:	ldr	x0, [x23, #0x6768]
   3c4b0:	str	x0, [x1, #0xcb8]
   3c4b4:	ldr	x0, [x23, #0x6770]
   3c4b8:	str	x0, [x1, #0xcc0]
   3c4bc:	str	x1, [sp, #0x1a0]
   3c4c0:	mov	x1, #0x67e
   3c4c4:	mov	x2, #-0x9
   3c4c8:	ldr	x27, [sp, #0x1b0]
   3c4cc:	ldur	x0, [sp, #0x8]
   3c4d0:	mov	x5, x21
   3c4d4:	ldr	x6, [sp, #0x1a8]
   3c4d8:	blr	x27
   3c4dc:	cmp	x0, #0x0
   3c4e0:	b.ne	0x410a4
   3c4e4:	mov	x0, #0x3
   3c4e8:	ldr	x15, [sp, #0x198]
   3c4ec:	cmp	x15, #0x2
   3c4f0:	b.lo	0x410ac
   3c4f4:	mov	x5, #0x0
   3c4f8:	ldr	x3, [sp, #0x1a0]
   3c4fc:	str	x5, [x3]
   3c500:	ldr	x0, [x23, #0x2310]
   3c504:	str	x0, [x3, #0x8]
   3c508:	mov	x1, #0x67e
   3c50c:	ldur	x0, [sp, #0x8]
   3c510:	ldr	x6, [sp, #0x1a8]
   3c514:	ldr	x27, [sp, #0x1b0]
   3c518:	mov	x4, x21
   3c51c:	mov	x2, x5
   3c520:	blr	x27
   3c524:	cmp	x0, #0x0
   3c528:	b.ne	0x410b4
   3c52c:	mov	x0, #0x3
   3c530:	stur	x0, [sp, #0xc0]
   3c534:	b	0x43a18
   3c538:	str	x1, [sp, #0x1a0]
   3c53c:	str	x2, [sp, #0x198]
   3c540:	ldr	x26, [sp, #0x188]
   3c544:	ldur	x1, [sp, #0xb8]
   3c548:	ldr	x1, [x26, x1, lsl #3]
   3c54c:	stur	x1, [sp, #0xa8]
   3c550:	add	x1, x5, #0x1
   3c554:	ldr	x26, [sp, #0x180]
   3c558:	cmp	x1, x26
   3c55c:	mov	x25, x1
   3c560:	b.lo	0x3c7ec
   3c564:	b	0x410bc
   3c568:	ldr	x3, [x23, #0x5790]
   3c56c:	ldr	x4, [x23, #0x5798]
   3c570:	mov	x0, #0x0
   3c574:	str	x0, [x23, #0x5788]
   3c578:	mov	x0, #0x3
   3c57c:	ldr	x15, [sp, #0x198]
   3c580:	cmp	x15, #0x19a
   3c584:	b.lo	0x411e8
   3c588:	ldr	x0, [x23, #0x5ac0]
   3c58c:	ldr	x1, [sp, #0x1a0]
   3c590:	str	x0, [x1, #0x10]
   3c594:	ldr	x1, [x23, #0x5ac8]
   3c598:	ldr	x2, [sp, #0x1a0]
   3c59c:	str	x1, [x2, #0x18]
   3c5a0:	ldr	x2, [x23, #0x6570]
   3c5a4:	ldr	x5, [sp, #0x1a0]
   3c5a8:	str	x2, [x5, #0xac0]
   3c5ac:	ldr	x2, [sp, #0x1a0]
   3c5b0:	str	x0, [x2, #0x10]
   3c5b4:	ldr	x0, [sp, #0x1a0]
   3c5b8:	str	x1, [x0, #0x18]
   3c5bc:	ldr	x0, [x23, #0x5c10]
   3c5c0:	str	x0, [x2, #0x160]
   3c5c4:	ldr	x0, [x23, #0x5c18]
   3c5c8:	str	x0, [x5, #0x168]
   3c5cc:	ldr	x0, [x23, #0x5c20]
   3c5d0:	ldr	x8, [sp, #0x1a0]
   3c5d4:	str	x0, [x8, #0x170]
   3c5d8:	ldr	x0, [x23, #0x5c28]
   3c5dc:	ldr	x11, [sp, #0x1a0]
   3c5e0:	str	x0, [x11, #0x178]
   3c5e4:	ldr	x0, [x23, #0x5c30]
   3c5e8:	ldr	x14, [sp, #0x1a0]
   3c5ec:	str	x0, [x14, #0x180]
   3c5f0:	ldr	x0, [x23, #0x5c38]
   3c5f4:	ldr	x1, [sp, #0x1a0]
   3c5f8:	str	x0, [x1, #0x188]
   3c5fc:	ldr	x0, [x23, #0x5c40]
   3c600:	str	x0, [x1, #0x190]
   3c604:	ldr	x0, [x23, #0x5c48]
   3c608:	str	x0, [x1, #0x198]
   3c60c:	ldr	x0, [x23, #0x5c50]
   3c610:	str	x0, [x1, #0x1a0]
   3c614:	ldr	x0, [x23, #0x5df8]
   3c618:	str	x0, [x1, #0x348]
   3c61c:	ldr	x0, [x23, #0x5e00]
   3c620:	str	x0, [x1, #0x350]
   3c624:	ldr	x0, [x23, #0x5e08]
   3c628:	str	x0, [x1, #0x358]
   3c62c:	ldr	x0, [x23, #0x5e10]
   3c630:	str	x0, [x1, #0x360]
   3c634:	ldr	x0, [x23, #0x5e18]
   3c638:	str	x0, [x1, #0x368]
   3c63c:	ldr	x0, [x23, #0x5e20]
   3c640:	str	x0, [x1, #0x370]
   3c644:	ldr	x0, [x23, #0x5e28]
   3c648:	str	x0, [x1, #0x378]
   3c64c:	ldr	x0, [x23, #0x5e30]
   3c650:	str	x0, [x1, #0x380]
   3c654:	ldr	x0, [x23, #0x5e38]
   3c658:	str	x0, [x1, #0x388]
   3c65c:	ldr	x0, [x23, #0x6128]
   3c660:	str	x0, [x1, #0x678]
   3c664:	ldr	x0, [x23, #0x6130]
   3c668:	str	x0, [x1, #0x680]
   3c66c:	ldr	x1, [x23, #0x6138]
   3c670:	ldr	x0, [sp, #0x1a0]
   3c674:	str	x1, [x0, #0x688]
   3c678:	ldr	x2, [x23, #0x6140]
   3c67c:	str	x2, [x5, #0x690]
   3c680:	ldr	x5, [x23, #0x6148]
   3c684:	ldr	x6, [sp, #0x1a0]
   3c688:	str	x5, [x6, #0x698]
   3c68c:	ldr	x5, [x23, #0x6150]
   3c690:	str	x5, [x8, #0x6a0]
   3c694:	ldr	x5, [x23, #0x6158]
   3c698:	str	x5, [x11, #0x6a8]
   3c69c:	ldr	x6, [x23, #0x6160]
   3c6a0:	str	x6, [x14, #0x6b0]
   3c6a4:	ldr	x7, [x23, #0x62f0]
   3c6a8:	str	x7, [x0, #0x840]
   3c6ac:	ldr	x8, [x23, #0x62f8]
   3c6b0:	str	x8, [x0, #0x848]
   3c6b4:	ldr	x9, [x23, #0x6300]
   3c6b8:	str	x9, [x0, #0x850]
   3c6bc:	ldr	x10, [x23, #0x6308]
   3c6c0:	str	x10, [x0, #0x858]
   3c6c4:	ldr	x11, [x23, #0x6310]
   3c6c8:	str	x11, [x0, #0x860]
   3c6cc:	ldr	x12, [x23, #0x6318]
   3c6d0:	str	x12, [x0, #0x868]
   3c6d4:	ldr	x13, [x23, #0x6320]
   3c6d8:	str	x13, [x0, #0x870]
   3c6dc:	ldr	x14, [x23, #0x6328]
   3c6e0:	str	x14, [x0, #0x878]
   3c6e4:	ldr	x15, [x23, #0x6700]
   3c6e8:	str	x15, [x0, #0xc50]
   3c6ec:	ldr	x0, [x23, #0x6708]
   3c6f0:	ldr	x1, [sp, #0x1a0]
   3c6f4:	str	x0, [x1, #0xc58]
   3c6f8:	ldr	x0, [x23, #0x6710]
   3c6fc:	str	x0, [x1, #0xc60]
   3c700:	ldr	x0, [x23, #0x6718]
   3c704:	str	x0, [x1, #0xc68]
   3c708:	ldr	x0, [x23, #0x6720]
   3c70c:	str	x0, [x1, #0xc70]
   3c710:	ldr	x0, [x23, #0x6728]
   3c714:	str	x0, [x1, #0xc78]
   3c718:	mov	x0, #0x0
   3c71c:	str	x0, [x1, #0xc80]
   3c720:	ldr	x1, [x23, #0x6738]
   3c724:	ldr	x2, [sp, #0x1a0]
   3c728:	str	x1, [x2, #0xc88]
   3c72c:	ldr	x1, [x23, #0x6740]
   3c730:	str	x1, [x2, #0xc90]
   3c734:	ldr	x5, [sp, #0x1a0]
   3c738:	str	x0, [x5, #0xc98]
   3c73c:	ldr	x1, [x23, #0x6750]
   3c740:	ldr	x7, [sp, #0x1a0]
   3c744:	str	x1, [x7, #0xca0]
   3c748:	ldr	x1, [x23, #0x6758]
   3c74c:	ldr	x10, [sp, #0x1a0]
   3c750:	str	x1, [x10, #0xca8]
   3c754:	ldr	x12, [sp, #0x1a0]
   3c758:	str	x0, [x12, #0xcb0]
   3c75c:	ldr	x0, [x23, #0x6768]
   3c760:	ldr	x15, [sp, #0x1a0]
   3c764:	str	x0, [x15, #0xcb8]
   3c768:	ldr	x0, [x23, #0x6770]
   3c76c:	ldr	x1, [sp, #0x1a0]
   3c770:	str	x0, [x1, #0xcc0]
   3c774:	mov	x1, #0x680
   3c778:	mov	x2, #-0x9
   3c77c:	ldr	x27, [sp, #0x1b0]
   3c780:	ldur	x0, [sp, #0x8]
   3c784:	mov	x5, x21
   3c788:	ldr	x6, [sp, #0x1a8]
   3c78c:	blr	x27
   3c790:	cmp	x0, #0x0
   3c794:	b.ne	0x411f0
   3c798:	mov	x0, #0x3
   3c79c:	ldr	x15, [sp, #0x198]
   3c7a0:	cmp	x15, #0x2
   3c7a4:	b.lo	0x411f8
   3c7a8:	mov	x5, #0x0
   3c7ac:	ldr	x3, [sp, #0x1a0]
   3c7b0:	str	x5, [x3]
   3c7b4:	ldr	x0, [x23, #0x2320]
   3c7b8:	str	x0, [x3, #0x8]
   3c7bc:	mov	x1, #0x680
   3c7c0:	ldur	x0, [sp, #0x8]
   3c7c4:	ldr	x6, [sp, #0x1a8]
   3c7c8:	ldr	x27, [sp, #0x1b0]
   3c7cc:	mov	x4, x21
   3c7d0:	mov	x2, x5
   3c7d4:	blr	x27
   3c7d8:	cmp	x0, #0x0
   3c7dc:	b.ne	0x41200
   3c7e0:	mov	x0, #0x3
   3c7e4:	stur	x0, [sp, #0xc0]
   3c7e8:	b	0x43a18
   3c7ec:	ldr	x26, [sp, #0x188]
   3c7f0:	ldr	x1, [x26, x1, lsl #3]
   3c7f4:	stur	x1, [sp, #0xf0]
   3c7f8:	ldur	x1, [sp, #0xb8]
   3c7fc:	ldr	x26, [sp, #0x170]
   3c800:	cmp	x1, x26
   3c804:	b.lo	0x3ca88
   3c808:	b	0x41208
   3c80c:	ldr	x3, [x23, #0x5790]
   3c810:	ldr	x4, [x23, #0x5798]
   3c814:	mov	x0, #0x0
   3c818:	str	x0, [x23, #0x5788]
   3c81c:	mov	x0, #0x3
   3c820:	ldr	x15, [sp, #0x198]
   3c824:	cmp	x15, #0x19a
   3c828:	b.lo	0x4133c
   3c82c:	ldr	x0, [x23, #0x5ac0]
   3c830:	ldr	x1, [sp, #0x1a0]
   3c834:	str	x0, [x1, #0x10]
   3c838:	ldr	x1, [x23, #0x5ac8]
   3c83c:	ldr	x2, [sp, #0x1a0]
   3c840:	str	x1, [x2, #0x18]
   3c844:	ldr	x2, [x23, #0x6570]
   3c848:	ldr	x5, [sp, #0x1a0]
   3c84c:	str	x2, [x5, #0xac0]
   3c850:	ldr	x7, [sp, #0x1a0]
   3c854:	str	x0, [x7, #0x10]
   3c858:	ldr	x9, [sp, #0x1a0]
   3c85c:	str	x1, [x9, #0x18]
   3c860:	ldr	x0, [x23, #0x5c10]
   3c864:	ldr	x12, [sp, #0x1a0]
   3c868:	str	x0, [x12, #0x160]
   3c86c:	ldr	x0, [x23, #0x5c18]
   3c870:	ldr	x15, [sp, #0x1a0]
   3c874:	str	x0, [x15, #0x168]
   3c878:	ldr	x0, [x23, #0x5c20]
   3c87c:	ldr	x1, [sp, #0x1a0]
   3c880:	str	x0, [x1, #0x170]
   3c884:	ldr	x0, [x23, #0x5c28]
   3c888:	str	x0, [x1, #0x178]
   3c88c:	ldr	x0, [x23, #0x5c30]
   3c890:	str	x0, [x1, #0x180]
   3c894:	ldr	x0, [x23, #0x5c38]
   3c898:	str	x0, [x1, #0x188]
   3c89c:	ldr	x0, [x23, #0x5c40]
   3c8a0:	str	x0, [x1, #0x190]
   3c8a4:	ldr	x0, [x23, #0x5c48]
   3c8a8:	str	x0, [x1, #0x198]
   3c8ac:	ldr	x0, [x23, #0x5c50]
   3c8b0:	str	x0, [x1, #0x1a0]
   3c8b4:	ldr	x0, [x23, #0x5df8]
   3c8b8:	str	x0, [x1, #0x348]
   3c8bc:	ldr	x0, [x23, #0x5e00]
   3c8c0:	str	x0, [x1, #0x350]
   3c8c4:	ldr	x0, [x23, #0x5e08]
   3c8c8:	str	x0, [x1, #0x358]
   3c8cc:	ldr	x0, [x23, #0x5e10]
   3c8d0:	str	x0, [x1, #0x360]
   3c8d4:	ldr	x0, [x23, #0x5e18]
   3c8d8:	str	x0, [x1, #0x368]
   3c8dc:	ldr	x0, [x23, #0x5e20]
   3c8e0:	str	x0, [x1, #0x370]
   3c8e4:	ldr	x0, [x23, #0x5e28]
   3c8e8:	str	x0, [x1, #0x378]
   3c8ec:	ldr	x0, [x23, #0x5e30]
   3c8f0:	str	x0, [x1, #0x380]
   3c8f4:	ldr	x0, [x23, #0x5e38]
   3c8f8:	str	x0, [x1, #0x388]
   3c8fc:	ldr	x0, [x23, #0x6128]
   3c900:	str	x0, [x5, #0x678]
   3c904:	ldr	x0, [x23, #0x6130]
   3c908:	ldr	x6, [sp, #0x1a0]
   3c90c:	str	x0, [x6, #0x680]
   3c910:	ldr	x0, [x23, #0x6138]
   3c914:	str	x0, [x9, #0x688]
   3c918:	ldr	x0, [x23, #0x6140]
   3c91c:	str	x0, [x12, #0x690]
   3c920:	ldr	x0, [x23, #0x6148]
   3c924:	str	x0, [x15, #0x698]
   3c928:	ldr	x0, [x23, #0x6150]
   3c92c:	str	x0, [x1, #0x6a0]
   3c930:	ldr	x0, [x23, #0x6158]
   3c934:	str	x0, [x1, #0x6a8]
   3c938:	ldr	x0, [x23, #0x6160]
   3c93c:	str	x0, [x1, #0x6b0]
   3c940:	ldr	x0, [x23, #0x62f0]
   3c944:	str	x0, [x1, #0x840]
   3c948:	ldr	x1, [x23, #0x62f8]
   3c94c:	ldr	x0, [sp, #0x1a0]
   3c950:	str	x1, [x0, #0x848]
   3c954:	ldr	x2, [x23, #0x6300]
   3c958:	str	x2, [x0, #0x850]
   3c95c:	ldr	x5, [x23, #0x6308]
   3c960:	str	x5, [x0, #0x858]
   3c964:	ldr	x5, [x23, #0x6310]
   3c968:	str	x5, [x0, #0x860]
   3c96c:	ldr	x5, [x23, #0x6318]
   3c970:	str	x5, [x0, #0x868]
   3c974:	ldr	x6, [x23, #0x6320]
   3c978:	str	x6, [x0, #0x870]
   3c97c:	ldr	x7, [x23, #0x6328]
   3c980:	str	x7, [x0, #0x878]
   3c984:	ldr	x8, [x23, #0x6700]
   3c988:	str	x8, [x0, #0xc50]
   3c98c:	ldr	x9, [x23, #0x6708]
   3c990:	str	x9, [x0, #0xc58]
   3c994:	ldr	x10, [x23, #0x6710]
   3c998:	str	x10, [x0, #0xc60]
   3c99c:	ldr	x11, [x23, #0x6718]
   3c9a0:	str	x11, [x0, #0xc68]
   3c9a4:	ldr	x12, [x23, #0x6720]
   3c9a8:	str	x12, [x0, #0xc70]
   3c9ac:	ldr	x13, [x23, #0x6728]
   3c9b0:	ldr	x5, [sp, #0x1a0]
   3c9b4:	str	x13, [x5, #0xc78]
   3c9b8:	mov	x14, #0x0
   3c9bc:	ldr	x6, [sp, #0x1a0]
   3c9c0:	str	x14, [x6, #0xc80]
   3c9c4:	ldr	x15, [x23, #0x6738]
   3c9c8:	ldr	x9, [sp, #0x1a0]
   3c9cc:	str	x15, [x9, #0xc88]
   3c9d0:	ldr	x0, [x23, #0x6740]
   3c9d4:	ldr	x12, [sp, #0x1a0]
   3c9d8:	str	x0, [x12, #0xc90]
   3c9dc:	ldr	x15, [sp, #0x1a0]
   3c9e0:	str	x14, [x15, #0xc98]
   3c9e4:	ldr	x0, [x23, #0x6750]
   3c9e8:	ldr	x1, [sp, #0x1a0]
   3c9ec:	str	x0, [x1, #0xca0]
   3c9f0:	ldr	x0, [x23, #0x6758]
   3c9f4:	str	x0, [x1, #0xca8]
   3c9f8:	ldr	x0, [sp, #0x1a0]
   3c9fc:	str	x14, [x0, #0xcb0]
   3ca00:	ldr	x0, [x23, #0x6768]
   3ca04:	str	x0, [x1, #0xcb8]
   3ca08:	ldr	x0, [x23, #0x6770]
   3ca0c:	str	x0, [x1, #0xcc0]
   3ca10:	mov	x1, #0x682
   3ca14:	mov	x2, #-0x9
   3ca18:	ldr	x27, [sp, #0x1b0]
   3ca1c:	ldur	x0, [sp, #0x8]
   3ca20:	mov	x5, x21
   3ca24:	ldr	x6, [sp, #0x1a8]
   3ca28:	blr	x27
   3ca2c:	cmp	x0, #0x0
   3ca30:	b.ne	0x41344
   3ca34:	mov	x0, #0x3
   3ca38:	ldr	x15, [sp, #0x198]
   3ca3c:	cmp	x15, #0x2
   3ca40:	b.lo	0x4134c
   3ca44:	mov	x5, #0x0
   3ca48:	ldr	x3, [sp, #0x1a0]
   3ca4c:	str	x5, [x3]
   3ca50:	ldr	x0, [x23, #0x2330]
   3ca54:	str	x0, [x3, #0x8]
   3ca58:	mov	x1, #0x682
   3ca5c:	ldur	x0, [sp, #0x8]
   3ca60:	ldr	x6, [sp, #0x1a8]
   3ca64:	ldr	x27, [sp, #0x1b0]
   3ca68:	mov	x4, x21
   3ca6c:	mov	x2, x5
   3ca70:	blr	x27
   3ca74:	cmp	x0, #0x0
   3ca78:	b.ne	0x41354
   3ca7c:	mov	x0, #0x3
   3ca80:	stur	x0, [sp, #0xc0]
   3ca84:	b	0x43a18
   3ca88:	stur	x0, [sp, #0xf8]
   3ca8c:	stur	x4, [sp, #0x60]
   3ca90:	ldr	x26, [sp, #0x178]
   3ca94:	ldur	x0, [sp, #0xb8]
   3ca98:	ldr	x0, [x26, x0, lsl #3]
   3ca9c:	stur	x0, [sp, #0xe8]
   3caa0:	mov	w0, #0xc87e
   3caa4:	movk	w0, #0x1, lsl #16
   3caa8:	sub	x3, x3, x0
   3caac:	mov	x4, #0x0
   3cab0:	stur	x4, [sp, #0x10]
   3cab4:	ldur	x15, [sp, #0x10]
   3cab8:	ldur	x24, [sp, #0x10]
   3cabc:	ldur	x0, [sp, #0x10]
   3cac0:	stur	x0, [sp, #0x18]
   3cac4:	stur	x0, [sp, #0x40]
   3cac8:	stur	x0, [sp, #0x48]
   3cacc:	mov	w0, #0x2166
   3cad0:	movk	w0, #0x1, lsl #16
   3cad4:	cmp	x3, x0
   3cad8:	b.hs	0x3ce88
   3cadc:	mov	x1, #0x0
   3cae0:	str	x1, [x23, #0x18]
   3cae4:	mov	x0, #0x1000000000000000
   3cae8:	str	x0, [x23, #0x20]
   3caec:	mov	x0, #0x1
   3caf0:	str	x0, [x23, #0x30]
   3caf4:	mov	x2, #0x101010101010101
   3caf8:	str	x2, [x23, #0x38]
   3cafc:	mov	x2, #0x2
   3cb00:	str	x2, [x23, #0x40]
   3cb04:	mov	x22, x2
   3cb08:	mov	x2, #0x3
   3cb0c:	str	x2, [x23, #0x48]
   3cb10:	mov	x2, #0x4
   3cb14:	str	x2, [x23, #0x50]
   3cb18:	mov	x2, #0xf0f0f0f0f0f0f0f
   3cb1c:	str	x2, [x23, #0x78]
   3cb20:	mov	x2, #0x3333333333333333
   3cb24:	str	x2, [x23, #0x88]
   3cb28:	mov	x2, #0x38
   3cb2c:	str	x2, [x23, #0x90]
   3cb30:	mov	x2, #0x3a
   3cb34:	str	x2, [x23, #0x98]
   3cb38:	mov	x2, #0x5555555555555555
   3cb3c:	str	x2, [x23, #0xb0]
   3cb40:	mov	x2, #0x3ffffffffffffff
   3cb44:	str	x2, [x23, #0xb8]
   3cb48:	str	x1, [x23, #0x188]
   3cb4c:	str	x0, [x23, #0x190]
   3cb50:	ldur	x27, [sp, #0xb8]
   3cb54:	str	x27, [x23, #0x22e0]
   3cb58:	ldr	x28, [sp, #0x190]
   3cb5c:	str	x28, [x23, #0x22e8]
   3cb60:	ldur	x1, [sp, #0xf8]
   3cb64:	uxtb	w1, w1
   3cb68:	str	x1, [x23, #0x22f8]
   3cb6c:	ldur	x10, [sp, #0x58]
   3cb70:	str	x10, [x23, #0x5788]
   3cb74:	str	x3, [x23, #0x5790]
   3cb78:	ldur	x4, [sp, #0x60]
   3cb7c:	str	x4, [x23, #0x5798]
   3cb80:	str	x27, [x23, #0x5ac0]
   3cb84:	str	x28, [x23, #0x5ac8]
   3cb88:	ldur	x10, [sp, #0xa8]
   3cb8c:	str	x10, [x23, #0x5c10]
   3cb90:	ldur	x1, [sp, #0xf0]
   3cb94:	str	x1, [x23, #0x5c18]
   3cb98:	str	x27, [x23, #0x5c20]
   3cb9c:	ldur	x5, [sp, #0xe8]
   3cba0:	str	x5, [x23, #0x5c28]
   3cba4:	ldur	x1, [sp, #0x10]
   3cba8:	str	x1, [x23, #0x5c30]
   3cbac:	str	x24, [x23, #0x5c38]
   3cbb0:	str	x15, [x23, #0x5c40]
   3cbb4:	ldur	x20, [sp, #0x40]
   3cbb8:	str	x20, [x23, #0x5c48]
   3cbbc:	ldur	x24, [sp, #0x48]
   3cbc0:	str	x24, [x23, #0x5c50]
   3cbc4:	ldur	x1, [sp, #0x28]
   3cbc8:	str	x1, [x23, #0x6570]
   3cbcc:	add	x1, x14, #0x1
   3cbd0:	str	x1, [x23, #0x6700]
   3cbd4:	ldur	x24, [sp, #0x68]
   3cbd8:	str	x24, [x23, #0x6708]
   3cbdc:	ldur	x25, [sp, #0x70]
   3cbe0:	str	x25, [x23, #0x6710]
   3cbe4:	ldur	x4, [sp, #0x50]
   3cbe8:	sub	x2, x4, x3
   3cbec:	mov	w3, #0xc87e
   3cbf0:	movk	w3, #0x1, lsl #16
   3cbf4:	msub	x1, x1, x3, x2
   3cbf8:	str	x1, [x23, #0x6718]
   3cbfc:	str	x0, [x23, #0x6720]
   3cc00:	ldur	x21, [sp, #0x18]
   3cc04:	str	x21, [x23, #0x6728]
   3cc08:	ldur	x19, [sp, #0x78]
   3cc0c:	str	x19, [x23, #0x6738]
   3cc10:	ldur	x26, [sp, #0x80]
   3cc14:	str	x26, [x23, #0x6740]
   3cc18:	str	x12, [x23, #0x6750]
   3cc1c:	str	x11, [x23, #0x6758]
   3cc20:	str	x7, [x23, #0x6768]
   3cc24:	str	x6, [x23, #0x6770]
   3cc28:	ldr	x0, [x23, #0x5788]
   3cc2c:	cmp	x0, #0x0
   3cc30:	b.eq	0x3ce60
   3cc34:	ldr	x3, [x23, #0x5790]
   3cc38:	ldr	x4, [x23, #0x5798]
   3cc3c:	mov	x0, #0x0
   3cc40:	str	x0, [x23, #0x5788]
   3cc44:	mov	x0, #0x3
   3cc48:	ldr	x15, [sp, #0x198]
   3cc4c:	stur	x0, [sp, #0xc0]
   3cc50:	cmp	x15, #0x19a
   3cc54:	b.lo	0x43a18
   3cc58:	ldr	x0, [x23, #0x5ac0]
   3cc5c:	ldr	x1, [sp, #0x1a0]
   3cc60:	str	x0, [x1, #0x10]
   3cc64:	ldr	x1, [x23, #0x5ac8]
   3cc68:	ldr	x2, [sp, #0x1a0]
   3cc6c:	str	x1, [x2, #0x18]
   3cc70:	ldr	x2, [x23, #0x6570]
   3cc74:	ldr	x5, [sp, #0x1a0]
   3cc78:	str	x2, [x5, #0xac0]
   3cc7c:	ldr	x2, [sp, #0x1a0]
   3cc80:	str	x0, [x2, #0x10]
   3cc84:	ldr	x0, [sp, #0x1a0]
   3cc88:	str	x1, [x0, #0x18]
   3cc8c:	ldr	x0, [x23, #0x5c10]
   3cc90:	ldr	x1, [sp, #0x1a0]
   3cc94:	str	x0, [x1, #0x160]
   3cc98:	ldr	x0, [x23, #0x5c18]
   3cc9c:	str	x0, [x1, #0x168]
   3cca0:	ldr	x0, [x23, #0x5c20]
   3cca4:	str	x0, [x1, #0x170]
   3cca8:	ldr	x0, [x23, #0x5c28]
   3ccac:	str	x0, [x1, #0x178]
   3ccb0:	ldr	x0, [x23, #0x5c30]
   3ccb4:	str	x0, [x1, #0x180]
   3ccb8:	ldr	x0, [x23, #0x5c38]
   3ccbc:	str	x0, [x1, #0x188]
   3ccc0:	ldr	x0, [x23, #0x5c40]
   3ccc4:	str	x0, [x1, #0x190]
   3ccc8:	ldr	x0, [x23, #0x5c48]
   3cccc:	str	x0, [x1, #0x198]
   3ccd0:	ldr	x0, [x23, #0x5c50]
   3ccd4:	str	x0, [x1, #0x1a0]
   3ccd8:	ldr	x0, [x23, #0x5df8]
   3ccdc:	str	x0, [x1, #0x348]
   3cce0:	ldr	x0, [x23, #0x5e00]
   3cce4:	str	x0, [x5, #0x350]
   3cce8:	ldr	x0, [x23, #0x5e08]
   3ccec:	ldr	x7, [sp, #0x1a0]
   3ccf0:	str	x0, [x7, #0x358]
   3ccf4:	ldr	x0, [x23, #0x5e10]
   3ccf8:	ldr	x10, [sp, #0x1a0]
   3ccfc:	str	x0, [x10, #0x360]
   3cd00:	ldr	x0, [x23, #0x5e18]
   3cd04:	ldr	x13, [sp, #0x1a0]
   3cd08:	str	x0, [x13, #0x368]
   3cd0c:	ldr	x0, [x23, #0x5e20]
   3cd10:	str	x0, [x1, #0x370]
   3cd14:	ldr	x0, [x23, #0x5e28]
   3cd18:	str	x0, [x1, #0x378]
   3cd1c:	ldr	x0, [x23, #0x5e30]
   3cd20:	str	x0, [x1, #0x380]
   3cd24:	ldr	x0, [x23, #0x5e38]
   3cd28:	str	x0, [x1, #0x388]
   3cd2c:	ldr	x0, [x23, #0x6128]
   3cd30:	str	x0, [x1, #0x678]
   3cd34:	ldr	x0, [x23, #0x6130]
   3cd38:	str	x0, [x1, #0x680]
   3cd3c:	ldr	x0, [x23, #0x6138]
   3cd40:	str	x0, [x1, #0x688]
   3cd44:	ldr	x0, [x23, #0x6140]
   3cd48:	str	x0, [x1, #0x690]
   3cd4c:	ldr	x0, [x23, #0x6148]
   3cd50:	str	x0, [x1, #0x698]
   3cd54:	ldr	x1, [x23, #0x6150]
   3cd58:	ldr	x0, [sp, #0x1a0]
   3cd5c:	str	x1, [x0, #0x6a0]
   3cd60:	ldr	x2, [x23, #0x6158]
   3cd64:	str	x2, [x0, #0x6a8]
   3cd68:	ldr	x5, [x23, #0x6160]
   3cd6c:	str	x5, [x0, #0x6b0]
   3cd70:	ldr	x5, [x23, #0x62f0]
   3cd74:	str	x5, [x0, #0x840]
   3cd78:	ldr	x5, [x23, #0x62f8]
   3cd7c:	str	x5, [x0, #0x848]
   3cd80:	ldr	x6, [x23, #0x6300]
   3cd84:	str	x6, [x0, #0x850]
   3cd88:	ldr	x7, [x23, #0x6308]
   3cd8c:	str	x7, [x0, #0x858]
   3cd90:	ldr	x8, [x23, #0x6310]
   3cd94:	ldr	x1, [sp, #0x1a0]
   3cd98:	str	x8, [x1, #0x860]
   3cd9c:	ldr	x9, [x23, #0x6318]
   3cda0:	ldr	x5, [sp, #0x1a0]
   3cda4:	str	x9, [x5, #0x868]
   3cda8:	ldr	x10, [x23, #0x6320]
   3cdac:	ldr	x7, [sp, #0x1a0]
   3cdb0:	str	x10, [x7, #0x870]
   3cdb4:	ldr	x11, [x23, #0x6328]
   3cdb8:	ldr	x10, [sp, #0x1a0]
   3cdbc:	str	x11, [x10, #0x878]
   3cdc0:	ldr	x12, [x23, #0x6700]
   3cdc4:	str	x12, [x13, #0xc50]
   3cdc8:	ldr	x13, [x23, #0x6708]
   3cdcc:	str	x13, [x0, #0xc58]
   3cdd0:	ldr	x14, [x23, #0x6710]
   3cdd4:	str	x14, [x0, #0xc60]
   3cdd8:	ldr	x15, [x23, #0x6718]
   3cddc:	str	x15, [x0, #0xc68]
   3cde0:	ldr	x0, [x23, #0x6720]
   3cde4:	str	x0, [x1, #0xc70]
   3cde8:	ldr	x0, [x23, #0x6728]
   3cdec:	str	x0, [x1, #0xc78]
   3cdf0:	mov	x0, #0x0
   3cdf4:	str	x0, [x1, #0xc80]
   3cdf8:	ldr	x1, [x23, #0x6738]
   3cdfc:	ldr	x2, [sp, #0x1a0]
   3ce00:	str	x1, [x2, #0xc88]
   3ce04:	ldr	x1, [x23, #0x6740]
   3ce08:	str	x1, [x2, #0xc90]
   3ce0c:	ldr	x1, [sp, #0x1a0]
   3ce10:	str	x0, [x1, #0xc98]
   3ce14:	ldr	x1, [x23, #0x6750]
   3ce18:	str	x1, [x2, #0xca0]
   3ce1c:	ldr	x1, [x23, #0x6758]
   3ce20:	str	x1, [x2, #0xca8]
   3ce24:	ldr	x1, [sp, #0x1a0]
   3ce28:	str	x0, [x1, #0xcb0]
   3ce2c:	ldr	x0, [x23, #0x6768]
   3ce30:	str	x0, [x1, #0xcb8]
   3ce34:	ldr	x0, [x23, #0x6770]
   3ce38:	str	x0, [x1, #0xcc0]
   3ce3c:	mov	x1, #0x68b
   3ce40:	mov	x2, #-0x9
   3ce44:	mov	x5, #0x1
   3ce48:	ldur	x0, [sp, #0x8]
   3ce4c:	ldr	x6, [sp, #0x1a8]
   3ce50:	ldr	x27, [sp, #0x1b0]
   3ce54:	blr	x27
   3ce58:	cmp	x0, #0x0
   3ce5c:	b.ne	0x4135c
   3ce60:	mov	x0, #0x0
   3ce64:	mov	x1, x22
   3ce68:	add	sp, sp, #0x1d0
   3ce6c:	ldp	x19, x20, [sp], #0x10
   3ce70:	ldp	x21, x22, [sp], #0x10
   3ce74:	ldp	x23, x24, [sp], #0x10
   3ce78:	ldp	x25, x26, [sp], #0x10
   3ce7c:	ldp	x27, x28, [sp], #0x10
   3ce80:	ldp	x29, x30, [sp], #0x10
   3ce84:	.long	0xd65f0fff
   3ce88:	ldur	x1, [sp, #0xf8]
   3ce8c:	ldur	x0, [sp, #0xa8]
   3ce90:	ldur	x2, [sp, #0xf0]
   3ce94:	cmp	x0, x2
   3ce98:	cset	x4, lo
   3ce9c:	cmp	x0, x2
   3cea0:	b.lo	0x3ced4
   3cea4:	mov	w0, #0x2166
   3cea8:	movk	w0, #0x1, lsl #16
   3ceac:	sub	x3, x3, x0
   3ceb0:	mov	x0, x24
   3ceb4:	ldur	x4, [sp, #0x40]
   3ceb8:	ldur	x5, [sp, #0x10]
   3cebc:	ldur	x9, [sp, #0xa8]
   3cec0:	stur	x24, [sp, #0x30]
   3cec4:	stur	x15, [sp, #0x38]
   3cec8:	ldur	x2, [sp, #0x48]
   3cecc:	stur	x2, [sp, #0xa0]
   3ced0:	b	0x3e70c
   3ced4:	ldr	x26, [sp, #0x160]
   3ced8:	cmp	x0, x26
   3cedc:	b.lo	0x3d174
   3cee0:	b	0x41364
   3cee4:	ldr	x3, [x23, #0x5790]
   3cee8:	ldr	x4, [x23, #0x5798]
   3ceec:	mov	x0, #0x0
   3cef0:	str	x0, [x23, #0x5788]
   3cef4:	mov	x0, #0x3
   3cef8:	ldr	x15, [sp, #0x198]
   3cefc:	stur	x0, [sp, #0xc0]
   3cf00:	cmp	x15, #0x19a
   3cf04:	b.lo	0x43a18
   3cf08:	ldr	x0, [x23, #0x5ac0]
   3cf0c:	ldr	x1, [sp, #0x1a0]
   3cf10:	str	x0, [x1, #0x10]
   3cf14:	ldr	x1, [x23, #0x5ac8]
   3cf18:	ldr	x2, [sp, #0x1a0]
   3cf1c:	str	x1, [x2, #0x18]
   3cf20:	ldr	x2, [x23, #0x6570]
   3cf24:	ldr	x5, [sp, #0x1a0]
   3cf28:	str	x2, [x5, #0xac0]
   3cf2c:	ldr	x2, [sp, #0x1a0]
   3cf30:	str	x0, [x2, #0x10]
   3cf34:	str	x1, [x2, #0x18]
   3cf38:	ldr	x0, [x23, #0x5c10]
   3cf3c:	str	x0, [x5, #0x160]
   3cf40:	ldr	x0, [x23, #0x5c18]
   3cf44:	ldr	x7, [sp, #0x1a0]
   3cf48:	str	x0, [x7, #0x168]
   3cf4c:	ldr	x0, [x23, #0x5c20]
   3cf50:	ldr	x10, [sp, #0x1a0]
   3cf54:	str	x0, [x10, #0x170]
   3cf58:	ldr	x0, [x23, #0x5c28]
   3cf5c:	ldr	x13, [sp, #0x1a0]
   3cf60:	str	x0, [x13, #0x178]
   3cf64:	ldr	x0, [x23, #0x5c30]
   3cf68:	ldr	x1, [sp, #0x1a0]
   3cf6c:	str	x0, [x1, #0x180]
   3cf70:	ldr	x0, [x23, #0x5c38]
   3cf74:	str	x0, [x1, #0x188]
   3cf78:	ldr	x0, [x23, #0x5c40]
   3cf7c:	str	x0, [x1, #0x190]
   3cf80:	ldr	x0, [x23, #0x5c48]
   3cf84:	str	x0, [x1, #0x198]
   3cf88:	ldr	x0, [x23, #0x5c50]
   3cf8c:	str	x0, [x1, #0x1a0]
   3cf90:	ldr	x0, [x23, #0x5df8]
   3cf94:	str	x0, [x1, #0x348]
   3cf98:	ldr	x1, [x23, #0x5e00]
   3cf9c:	ldr	x0, [sp, #0x1a0]
   3cfa0:	str	x1, [x0, #0x350]
   3cfa4:	ldr	x2, [x23, #0x5e08]
   3cfa8:	str	x2, [x0, #0x358]
   3cfac:	ldr	x5, [x23, #0x5e10]
   3cfb0:	str	x5, [x0, #0x360]
   3cfb4:	ldr	x5, [x23, #0x5e18]
   3cfb8:	str	x5, [x0, #0x368]
   3cfbc:	ldr	x5, [x23, #0x5e20]
   3cfc0:	str	x5, [x0, #0x370]
   3cfc4:	ldr	x6, [x23, #0x5e28]
   3cfc8:	str	x6, [x0, #0x378]
   3cfcc:	ldr	x7, [x23, #0x5e30]
   3cfd0:	str	x7, [x0, #0x380]
   3cfd4:	ldr	x8, [x23, #0x5e38]
   3cfd8:	str	x8, [x0, #0x388]
   3cfdc:	ldr	x9, [x23, #0x6128]
   3cfe0:	str	x9, [x0, #0x678]
   3cfe4:	ldr	x10, [x23, #0x6130]
   3cfe8:	str	x10, [x0, #0x680]
   3cfec:	ldr	x11, [x23, #0x6138]
   3cff0:	ldr	x1, [sp, #0x1a0]
   3cff4:	str	x11, [x1, #0x688]
   3cff8:	ldr	x12, [x23, #0x6140]
   3cffc:	ldr	x5, [sp, #0x1a0]
   3d000:	str	x12, [x5, #0x690]
   3d004:	ldr	x13, [x23, #0x6148]
   3d008:	ldr	x7, [sp, #0x1a0]
   3d00c:	str	x13, [x7, #0x698]
   3d010:	ldr	x14, [x23, #0x6150]
   3d014:	ldr	x10, [sp, #0x1a0]
   3d018:	str	x14, [x10, #0x6a0]
   3d01c:	ldr	x15, [x23, #0x6158]
   3d020:	ldr	x13, [sp, #0x1a0]
   3d024:	str	x15, [x13, #0x6a8]
   3d028:	ldr	x0, [x23, #0x6160]
   3d02c:	str	x0, [x1, #0x6b0]
   3d030:	ldr	x0, [x23, #0x62f0]
   3d034:	str	x0, [x1, #0x840]
   3d038:	ldr	x0, [x23, #0x62f8]
   3d03c:	str	x0, [x1, #0x848]
   3d040:	ldr	x0, [x23, #0x6300]
   3d044:	str	x0, [x1, #0x850]
   3d048:	ldr	x0, [x23, #0x6308]
   3d04c:	str	x0, [x1, #0x858]
   3d050:	ldr	x0, [x23, #0x6310]
   3d054:	str	x0, [x1, #0x860]
   3d058:	ldr	x0, [x23, #0x6318]
   3d05c:	str	x0, [x1, #0x868]
   3d060:	ldr	x0, [x23, #0x6320]
   3d064:	str	x0, [x1, #0x870]
   3d068:	ldr	x0, [x23, #0x6328]
   3d06c:	str	x0, [x1, #0x878]
   3d070:	ldr	x0, [x23, #0x6700]
   3d074:	str	x0, [x1, #0xc50]
   3d078:	ldr	x0, [x23, #0x6708]
   3d07c:	str	x0, [x1, #0xc58]
   3d080:	ldr	x0, [x23, #0x6710]
   3d084:	str	x0, [x1, #0xc60]
   3d088:	ldr	x0, [x23, #0x6718]
   3d08c:	str	x0, [x1, #0xc68]
   3d090:	ldr	x0, [x23, #0x6720]
   3d094:	str	x0, [x1, #0xc70]
   3d098:	ldr	x0, [x23, #0x6728]
   3d09c:	str	x0, [x1, #0xc78]
   3d0a0:	mov	x0, #0x0
   3d0a4:	str	x0, [x1, #0xc80]
   3d0a8:	ldr	x1, [x23, #0x6738]
   3d0ac:	ldr	x2, [sp, #0x1a0]
   3d0b0:	str	x1, [x2, #0xc88]
   3d0b4:	ldr	x1, [x23, #0x6740]
   3d0b8:	str	x1, [x5, #0xc90]
   3d0bc:	ldr	x6, [sp, #0x1a0]
   3d0c0:	str	x0, [x6, #0xc98]
   3d0c4:	ldr	x1, [x23, #0x6750]
   3d0c8:	ldr	x9, [sp, #0x1a0]
   3d0cc:	str	x1, [x9, #0xca0]
   3d0d0:	ldr	x1, [x23, #0x6758]
   3d0d4:	ldr	x12, [sp, #0x1a0]
   3d0d8:	str	x1, [x12, #0xca8]
   3d0dc:	ldr	x14, [sp, #0x1a0]
   3d0e0:	str	x0, [x14, #0xcb0]
   3d0e4:	ldr	x0, [x23, #0x6768]
   3d0e8:	ldr	x1, [sp, #0x1a0]
   3d0ec:	str	x0, [x1, #0xcb8]
   3d0f0:	ldr	x0, [x23, #0x6770]
   3d0f4:	str	x0, [x1, #0xcc0]
   3d0f8:	mov	x1, #0x69c
   3d0fc:	mov	x2, #-0x9
   3d100:	ldr	x27, [sp, #0x1b0]
   3d104:	ldur	x0, [sp, #0x8]
   3d108:	mov	x5, x20
   3d10c:	ldr	x6, [sp, #0x1a8]
   3d110:	blr	x27
   3d114:	cmp	x0, #0x0
   3d118:	b.ne	0x41500
   3d11c:	mov	x0, #0x3
   3d120:	ldr	x15, [sp, #0x198]
   3d124:	stur	x0, [sp, #0xc0]
   3d128:	cmp	x15, #0x2
   3d12c:	b.lo	0x43a18
   3d130:	mov	x5, #0x0
   3d134:	ldr	x3, [sp, #0x1a0]
   3d138:	str	x5, [x3]
   3d13c:	ldr	x0, [x23, #0x23d0]
   3d140:	str	x0, [x3, #0x8]
   3d144:	mov	x1, #0x69c
   3d148:	ldur	x0, [sp, #0x8]
   3d14c:	ldr	x6, [sp, #0x1a8]
   3d150:	ldr	x27, [sp, #0x1b0]
   3d154:	mov	x4, x20
   3d158:	mov	x2, x5
   3d15c:	blr	x27
   3d160:	cmp	x0, #0x0
   3d164:	b.ne	0x41508
   3d168:	mov	x0, #0x3
   3d16c:	stur	x0, [sp, #0xc0]
   3d170:	b	0x43a18
   3d174:	ldr	x26, [sp, #0x168]
   3d178:	stur	x24, [sp, #0x30]
   3d17c:	stur	x15, [sp, #0x38]
   3d180:	ldr	x2, [x26, x0, lsl #3]
   3d184:	add	x5, x2, #0x1
   3d188:	cmp	x5, x2
   3d18c:	b.lo	0x41510
   3d190:	ldr	x26, [sp, #0x150]
   3d194:	cmp	x2, x26
   3d198:	b.lo	0x3d424
   3d19c:	b	0x41660
   3d1a0:	ldr	x3, [x23, #0x5790]
   3d1a4:	ldr	x4, [x23, #0x5798]
   3d1a8:	mov	x0, #0x0
   3d1ac:	str	x0, [x23, #0x5788]
   3d1b0:	mov	x0, #0x3
   3d1b4:	ldr	x15, [sp, #0x198]
   3d1b8:	stur	x0, [sp, #0xc0]
   3d1bc:	cmp	x15, #0x19a
   3d1c0:	b.lo	0x43a18
   3d1c4:	ldr	x0, [x23, #0x5ac0]
   3d1c8:	ldr	x1, [sp, #0x1a0]
   3d1cc:	str	x0, [x1, #0x10]
   3d1d0:	ldr	x1, [x23, #0x5ac8]
   3d1d4:	ldr	x2, [sp, #0x1a0]
   3d1d8:	str	x1, [x2, #0x18]
   3d1dc:	ldr	x2, [x23, #0x6570]
   3d1e0:	ldr	x5, [sp, #0x1a0]
   3d1e4:	str	x2, [x5, #0xac0]
   3d1e8:	ldr	x2, [sp, #0x1a0]
   3d1ec:	str	x0, [x2, #0x10]
   3d1f0:	ldr	x0, [sp, #0x1a0]
   3d1f4:	str	x1, [x0, #0x18]
   3d1f8:	ldr	x0, [x23, #0x5c10]
   3d1fc:	ldr	x1, [sp, #0x1a0]
   3d200:	str	x0, [x1, #0x160]
   3d204:	ldr	x0, [x23, #0x5c18]
   3d208:	str	x0, [x1, #0x168]
   3d20c:	ldr	x0, [x23, #0x5c20]
   3d210:	str	x0, [x1, #0x170]
   3d214:	ldr	x0, [x23, #0x5c28]
   3d218:	str	x0, [x1, #0x178]
   3d21c:	ldr	x0, [x23, #0x5c30]
   3d220:	str	x0, [x1, #0x180]
   3d224:	ldr	x0, [x23, #0x5c38]
   3d228:	str	x0, [x1, #0x188]
   3d22c:	ldr	x0, [x23, #0x5c40]
   3d230:	str	x0, [x1, #0x190]
   3d234:	ldr	x0, [x23, #0x5c48]
   3d238:	str	x0, [x1, #0x198]
   3d23c:	ldr	x0, [x23, #0x5c50]
   3d240:	str	x0, [x1, #0x1a0]
   3d244:	ldr	x0, [x23, #0x5df8]
   3d248:	str	x0, [x1, #0x348]
   3d24c:	ldr	x0, [x23, #0x5e00]
   3d250:	str	x0, [x2, #0x350]
   3d254:	ldr	x0, [x23, #0x5e08]
   3d258:	str	x0, [x5, #0x358]
   3d25c:	ldr	x0, [x23, #0x5e10]
   3d260:	ldr	x8, [sp, #0x1a0]
   3d264:	str	x0, [x8, #0x360]
   3d268:	ldr	x0, [x23, #0x5e18]
   3d26c:	ldr	x11, [sp, #0x1a0]
   3d270:	str	x0, [x11, #0x368]
   3d274:	ldr	x0, [x23, #0x5e20]
   3d278:	ldr	x14, [sp, #0x1a0]
   3d27c:	str	x0, [x14, #0x370]
   3d280:	ldr	x0, [x23, #0x5e28]
   3d284:	str	x0, [x1, #0x378]
   3d288:	ldr	x0, [x23, #0x5e30]
   3d28c:	str	x0, [x1, #0x380]
   3d290:	ldr	x0, [x23, #0x5e38]
   3d294:	str	x0, [x1, #0x388]
   3d298:	ldr	x0, [x23, #0x6128]
   3d29c:	str	x0, [x1, #0x678]
   3d2a0:	ldr	x0, [x23, #0x6130]
   3d2a4:	str	x0, [x1, #0x680]
   3d2a8:	ldr	x0, [x23, #0x6138]
   3d2ac:	str	x0, [x1, #0x688]
   3d2b0:	ldr	x0, [x23, #0x6140]
   3d2b4:	str	x0, [x1, #0x690]
   3d2b8:	ldr	x0, [x23, #0x6148]
   3d2bc:	str	x0, [x1, #0x698]
   3d2c0:	ldr	x0, [x23, #0x6150]
   3d2c4:	str	x0, [x1, #0x6a0]
   3d2c8:	ldr	x1, [x23, #0x6158]
   3d2cc:	ldr	x0, [sp, #0x1a0]
   3d2d0:	str	x1, [x0, #0x6a8]
   3d2d4:	ldr	x2, [x23, #0x6160]
   3d2d8:	str	x2, [x0, #0x6b0]
   3d2dc:	ldr	x5, [x23, #0x62f0]
   3d2e0:	str	x5, [x0, #0x840]
   3d2e4:	ldr	x5, [x23, #0x62f8]
   3d2e8:	str	x5, [x0, #0x848]
   3d2ec:	ldr	x5, [x23, #0x6300]
   3d2f0:	str	x5, [x0, #0x850]
   3d2f4:	ldr	x6, [x23, #0x6308]
   3d2f8:	str	x6, [x0, #0x858]
   3d2fc:	ldr	x7, [x23, #0x6310]
   3d300:	str	x7, [x0, #0x860]
   3d304:	ldr	x8, [x23, #0x6318]
   3d308:	ldr	x2, [sp, #0x1a0]
   3d30c:	str	x8, [x2, #0x868]
   3d310:	ldr	x9, [x23, #0x6320]
   3d314:	ldr	x5, [sp, #0x1a0]
   3d318:	str	x9, [x5, #0x870]
   3d31c:	ldr	x10, [x23, #0x6328]
   3d320:	ldr	x8, [sp, #0x1a0]
   3d324:	str	x10, [x8, #0x878]
   3d328:	ldr	x11, [x23, #0x6700]
   3d32c:	ldr	x12, [sp, #0x1a0]
   3d330:	str	x11, [x12, #0xc50]
   3d334:	ldr	x12, [x23, #0x6708]
   3d338:	str	x12, [x14, #0xc58]
   3d33c:	ldr	x13, [x23, #0x6710]
   3d340:	str	x13, [x0, #0xc60]
   3d344:	ldr	x14, [x23, #0x6718]
   3d348:	str	x14, [x0, #0xc68]
   3d34c:	ldr	x15, [x23, #0x6720]
   3d350:	str	x15, [x0, #0xc70]
   3d354:	ldr	x0, [x23, #0x6728]
   3d358:	ldr	x1, [sp, #0x1a0]
   3d35c:	str	x0, [x1, #0xc78]
   3d360:	mov	x0, #0x0
   3d364:	str	x0, [x1, #0xc80]
   3d368:	ldr	x1, [x23, #0x6738]
   3d36c:	str	x1, [x2, #0xc88]
   3d370:	ldr	x1, [x23, #0x6740]
   3d374:	str	x1, [x2, #0xc90]
   3d378:	ldr	x1, [sp, #0x1a0]
   3d37c:	str	x0, [x1, #0xc98]
   3d380:	ldr	x1, [x23, #0x6750]
   3d384:	str	x1, [x2, #0xca0]
   3d388:	ldr	x1, [x23, #0x6758]
   3d38c:	str	x1, [x2, #0xca8]
   3d390:	ldr	x1, [sp, #0x1a0]
   3d394:	str	x0, [x1, #0xcb0]
   3d398:	ldr	x0, [x23, #0x6768]
   3d39c:	str	x0, [x1, #0xcb8]
   3d3a0:	ldr	x0, [x23, #0x6770]
   3d3a4:	str	x0, [x1, #0xcc0]
   3d3a8:	mov	x1, #0x69e
   3d3ac:	mov	x2, #-0x9
   3d3b0:	ldr	x27, [sp, #0x1b0]
   3d3b4:	ldur	x0, [sp, #0x8]
   3d3b8:	mov	x5, x20
   3d3bc:	ldr	x6, [sp, #0x1a8]
   3d3c0:	blr	x27
   3d3c4:	cmp	x0, #0x0
   3d3c8:	b.ne	0x41800
   3d3cc:	mov	x0, #0x3
   3d3d0:	ldr	x15, [sp, #0x198]
   3d3d4:	stur	x0, [sp, #0xc0]
   3d3d8:	cmp	x15, #0x2
   3d3dc:	b.lo	0x43a18
   3d3e0:	mov	x5, #0x0
   3d3e4:	ldr	x3, [sp, #0x1a0]
   3d3e8:	str	x5, [x3]
   3d3ec:	ldr	x0, [x23, #0x23e0]
   3d3f0:	str	x0, [x3, #0x8]
   3d3f4:	mov	x1, #0x69e
   3d3f8:	ldur	x0, [sp, #0x8]
   3d3fc:	ldr	x6, [sp, #0x1a8]
   3d400:	ldr	x27, [sp, #0x1b0]
   3d404:	mov	x4, x20
   3d408:	mov	x2, x5
   3d40c:	blr	x27
   3d410:	cmp	x0, #0x0
   3d414:	b.ne	0x41808
   3d418:	mov	x0, #0x3
   3d41c:	stur	x0, [sp, #0xc0]
   3d420:	b	0x43a18
   3d424:	ldr	x26, [sp, #0x158]
   3d428:	stur	x4, [sp, #0xe0]
   3d42c:	ldr	x20, [x26, x2, lsl #3]
   3d430:	ldr	x26, [sp, #0x150]
   3d434:	cmp	x5, x26
   3d438:	b.lo	0x3d6c8
   3d43c:	b	0x41810
   3d440:	ldr	x3, [x23, #0x5790]
   3d444:	ldr	x4, [x23, #0x5798]
   3d448:	mov	x0, #0x0
   3d44c:	str	x0, [x23, #0x5788]
   3d450:	mov	x0, #0x3
   3d454:	ldr	x15, [sp, #0x198]
   3d458:	stur	x0, [sp, #0xc0]
   3d45c:	cmp	x15, #0x19a
   3d460:	b.lo	0x43a18
   3d464:	ldr	x0, [x23, #0x5ac0]
   3d468:	ldr	x1, [sp, #0x1a0]
   3d46c:	str	x0, [x1, #0x10]
   3d470:	ldr	x1, [x23, #0x5ac8]
   3d474:	ldr	x2, [sp, #0x1a0]
   3d478:	str	x1, [x2, #0x18]
   3d47c:	ldr	x2, [x23, #0x6570]
   3d480:	ldr	x5, [sp, #0x1a0]
   3d484:	str	x2, [x5, #0xac0]
   3d488:	ldr	x2, [sp, #0x1a0]
   3d48c:	str	x0, [x2, #0x10]
   3d490:	ldr	x0, [sp, #0x1a0]
   3d494:	str	x1, [x0, #0x18]
   3d498:	ldr	x0, [x23, #0x5c10]
   3d49c:	ldr	x1, [sp, #0x1a0]
   3d4a0:	str	x0, [x1, #0x160]
   3d4a4:	ldr	x0, [x23, #0x5c18]
   3d4a8:	str	x0, [x2, #0x168]
   3d4ac:	ldr	x0, [x23, #0x5c20]
   3d4b0:	str	x0, [x5, #0x170]
   3d4b4:	ldr	x0, [x23, #0x5c28]
   3d4b8:	ldr	x8, [sp, #0x1a0]
   3d4bc:	str	x0, [x8, #0x178]
   3d4c0:	ldr	x0, [x23, #0x5c30]
   3d4c4:	ldr	x11, [sp, #0x1a0]
   3d4c8:	str	x0, [x11, #0x180]
   3d4cc:	ldr	x0, [x23, #0x5c38]
   3d4d0:	ldr	x14, [sp, #0x1a0]
   3d4d4:	str	x0, [x14, #0x188]
   3d4d8:	ldr	x0, [x23, #0x5c40]
   3d4dc:	str	x0, [x1, #0x190]
   3d4e0:	ldr	x0, [x23, #0x5c48]
   3d4e4:	str	x0, [x1, #0x198]
   3d4e8:	ldr	x0, [x23, #0x5c50]
   3d4ec:	str	x0, [x1, #0x1a0]
   3d4f0:	ldr	x0, [x23, #0x5df8]
   3d4f4:	str	x0, [x1, #0x348]
   3d4f8:	ldr	x0, [x23, #0x5e00]
   3d4fc:	str	x0, [x1, #0x350]
   3d500:	ldr	x0, [x23, #0x5e08]
   3d504:	str	x0, [x1, #0x358]
   3d508:	ldr	x0, [x23, #0x5e10]
   3d50c:	str	x0, [x1, #0x360]
   3d510:	ldr	x0, [x23, #0x5e18]
   3d514:	str	x0, [x1, #0x368]
   3d518:	ldr	x0, [x23, #0x5e20]
   3d51c:	str	x0, [x1, #0x370]
   3d520:	ldr	x0, [x23, #0x5e28]
   3d524:	str	x0, [x1, #0x378]
   3d528:	ldr	x0, [x23, #0x5e30]
   3d52c:	str	x0, [x1, #0x380]
   3d530:	ldr	x0, [x23, #0x5e38]
   3d534:	str	x0, [x1, #0x388]
   3d538:	ldr	x1, [x23, #0x6128]
   3d53c:	ldr	x0, [sp, #0x1a0]
   3d540:	str	x1, [x0, #0x678]
   3d544:	ldr	x2, [x23, #0x6130]
   3d548:	str	x2, [x0, #0x680]
   3d54c:	ldr	x5, [x23, #0x6138]
   3d550:	str	x5, [x0, #0x688]
   3d554:	ldr	x5, [x23, #0x6140]
   3d558:	str	x5, [x0, #0x690]
   3d55c:	ldr	x5, [x23, #0x6148]
   3d560:	ldr	x2, [sp, #0x1a0]
   3d564:	str	x5, [x2, #0x698]
   3d568:	ldr	x6, [x23, #0x6150]
   3d56c:	ldr	x5, [sp, #0x1a0]
   3d570:	str	x6, [x5, #0x6a0]
   3d574:	ldr	x7, [x23, #0x6158]
   3d578:	str	x7, [x8, #0x6a8]
   3d57c:	ldr	x8, [x23, #0x6160]
   3d580:	str	x8, [x11, #0x6b0]
   3d584:	ldr	x9, [x23, #0x62f0]
   3d588:	str	x9, [x14, #0x840]
   3d58c:	ldr	x10, [x23, #0x62f8]
   3d590:	str	x10, [x0, #0x848]
   3d594:	ldr	x11, [x23, #0x6300]
   3d598:	str	x11, [x0, #0x850]
   3d59c:	ldr	x12, [x23, #0x6308]
   3d5a0:	str	x12, [x0, #0x858]
   3d5a4:	ldr	x13, [x23, #0x6310]
   3d5a8:	str	x13, [x0, #0x860]
   3d5ac:	ldr	x14, [x23, #0x6318]
   3d5b0:	str	x14, [x0, #0x868]
   3d5b4:	ldr	x15, [x23, #0x6320]
   3d5b8:	str	x15, [x0, #0x870]
   3d5bc:	ldr	x0, [x23, #0x6328]
   3d5c0:	ldr	x1, [sp, #0x1a0]
   3d5c4:	str	x0, [x1, #0x878]
   3d5c8:	ldr	x0, [x23, #0x6700]
   3d5cc:	str	x0, [x1, #0xc50]
   3d5d0:	ldr	x0, [x23, #0x6708]
   3d5d4:	str	x0, [x1, #0xc58]
   3d5d8:	ldr	x0, [x23, #0x6710]
   3d5dc:	str	x0, [x1, #0xc60]
   3d5e0:	ldr	x0, [x23, #0x6718]
   3d5e4:	str	x0, [x1, #0xc68]
   3d5e8:	ldr	x0, [x23, #0x6720]
   3d5ec:	str	x0, [x1, #0xc70]
   3d5f0:	ldr	x0, [x23, #0x6728]
   3d5f4:	str	x0, [x1, #0xc78]
   3d5f8:	mov	x0, #0x0
   3d5fc:	str	x0, [x1, #0xc80]
   3d600:	ldr	x1, [x23, #0x6738]
   3d604:	str	x1, [x2, #0xc88]
   3d608:	ldr	x1, [x23, #0x6740]
   3d60c:	str	x1, [x2, #0xc90]
   3d610:	ldr	x1, [sp, #0x1a0]
   3d614:	str	x0, [x1, #0xc98]
   3d618:	ldr	x1, [x23, #0x6750]
   3d61c:	str	x1, [x5, #0xca0]
   3d620:	ldr	x1, [x23, #0x6758]
   3d624:	ldr	x7, [sp, #0x1a0]
   3d628:	str	x1, [x7, #0xca8]
   3d62c:	ldr	x9, [sp, #0x1a0]
   3d630:	str	x0, [x9, #0xcb0]
   3d634:	ldr	x0, [x23, #0x6768]
   3d638:	ldr	x12, [sp, #0x1a0]
   3d63c:	str	x0, [x12, #0xcb8]
   3d640:	ldr	x0, [x23, #0x6770]
   3d644:	ldr	x15, [sp, #0x1a0]
   3d648:	str	x0, [x15, #0xcc0]
   3d64c:	mov	x1, #0x6a0
   3d650:	mov	x2, #-0x9
   3d654:	ldr	x27, [sp, #0x1b0]
   3d658:	ldur	x0, [sp, #0x8]
   3d65c:	mov	x5, x21
   3d660:	ldr	x6, [sp, #0x1a8]
   3d664:	blr	x27
   3d668:	cmp	x0, #0x0
   3d66c:	b.ne	0x419b8
   3d670:	mov	x0, #0x3
   3d674:	ldr	x15, [sp, #0x198]
   3d678:	stur	x0, [sp, #0xc0]
   3d67c:	cmp	x15, #0x2
   3d680:	b.lo	0x43a18
   3d684:	mov	x5, #0x0
   3d688:	ldr	x3, [sp, #0x1a0]
   3d68c:	str	x5, [x3]
   3d690:	ldr	x0, [x23, #0x23f0]
   3d694:	str	x0, [x3, #0x8]
   3d698:	mov	x1, #0x6a0
   3d69c:	ldur	x0, [sp, #0x8]
   3d6a0:	ldr	x6, [sp, #0x1a8]
   3d6a4:	ldr	x27, [sp, #0x1b0]
   3d6a8:	mov	x4, x21
   3d6ac:	mov	x2, x5
   3d6b0:	blr	x27
   3d6b4:	cmp	x0, #0x0
   3d6b8:	b.ne	0x419c0
   3d6bc:	mov	x0, #0x3
   3d6c0:	stur	x0, [sp, #0xc0]
   3d6c4:	b	0x43a18
   3d6c8:	ldr	x26, [sp, #0x158]
   3d6cc:	ldr	x10, [x26, x5, lsl #3]
   3d6d0:	mov	w0, #0x2166
   3d6d4:	movk	w0, #0x1, lsl #16
   3d6d8:	sub	x9, x3, x0
   3d6dc:	mov	x0, #0x0
   3d6e0:	ldr	x26, [sp, #0x140]
   3d6e4:	stur	x0, [sp, #0xb0]
   3d6e8:	cmp	x26, x10
   3d6ec:	b.lo	0x3d708
   3d6f0:	ldur	x0, [sp, #0x30]
   3d6f4:	ldur	x4, [sp, #0x40]
   3d6f8:	ldur	x5, [sp, #0x10]
   3d6fc:	ldur	x1, [sp, #0x48]
   3d700:	stur	x1, [sp, #0xa0]
   3d704:	b	0x3de70
   3d708:	ldur	x0, [sp, #0x10]
   3d70c:	ldur	x5, [sp, #0x38]
   3d710:	ldur	x8, [sp, #0x30]
   3d714:	ldur	x19, [sp, #0x40]
   3d718:	ldur	x1, [sp, #0x48]
   3d71c:	stur	x1, [sp, #0xa0]
   3d720:	mov	w1, #0xdc1e
   3d724:	movk	w1, #0x2, lsl #16
   3d728:	cmp	x9, x1
   3d72c:	b.hs	0x3d76c
   3d730:	ldur	x27, [sp, #0xb8]
   3d734:	ldur	x26, [sp, #0x10]
   3d738:	ldur	x25, [sp, #0x30]
   3d73c:	ldur	x24, [sp, #0x38]
   3d740:	ldur	x22, [sp, #0x40]
   3d744:	ldur	x21, [sp, #0xa8]
   3d748:	mov	x15, x5
   3d74c:	ldur	x13, [sp, #0x48]
   3d750:	mov	x5, x0
   3d754:	mov	x4, x19
   3d758:	ldur	x19, [sp, #0xb8]
   3d75c:	ldur	x1, [sp, #0xb8]
   3d760:	mov	x0, x8
   3d764:	ldur	x8, [sp, #0xb8]
   3d768:	b	0x3dea8
   3d76c:	cmp	x20, x10
   3d770:	cset	x1, lo
   3d774:	cmp	x20, x10
   3d778:	b.lo	0x3d7a8
   3d77c:	mov	x24, x0
   3d780:	mov	x21, x8
   3d784:	mov	x15, x5
   3d788:	mov	x4, x19
   3d78c:	mov	x2, x20
   3d790:	mov	x1, x19
   3d794:	mov	x19, x5
   3d798:	mov	x5, x0
   3d79c:	mov	x0, x8
   3d7a0:	ldur	x8, [sp, #0xa0]
   3d7a4:	b	0x3de1c
   3d7a8:	ldr	x3, [sp, #0x140]
   3d7ac:	cmp	x20, x3
   3d7b0:	b.lo	0x3da30
   3d7b4:	b	0x419c8
   3d7b8:	ldr	x3, [x23, #0x5790]
   3d7bc:	ldr	x4, [x23, #0x5798]
   3d7c0:	mov	x0, #0x0
   3d7c4:	str	x0, [x23, #0x5788]
   3d7c8:	mov	x0, #0x3
   3d7cc:	ldr	x15, [sp, #0x198]
   3d7d0:	stur	x0, [sp, #0xc0]
   3d7d4:	cmp	x15, #0x19a
   3d7d8:	b.lo	0x43a18
   3d7dc:	ldr	x0, [x23, #0x5ac0]
   3d7e0:	ldr	x1, [sp, #0x1a0]
   3d7e4:	str	x0, [x1, #0x10]
   3d7e8:	ldr	x1, [x23, #0x5ac8]
   3d7ec:	ldr	x5, [sp, #0x1a0]
   3d7f0:	str	x1, [x5, #0x18]
   3d7f4:	ldr	x2, [x23, #0x6570]
   3d7f8:	ldr	x7, [sp, #0x1a0]
   3d7fc:	str	x2, [x7, #0xac0]
   3d800:	ldr	x9, [sp, #0x1a0]
   3d804:	str	x0, [x9, #0x10]
   3d808:	ldr	x11, [sp, #0x1a0]
   3d80c:	str	x1, [x11, #0x18]
   3d810:	ldr	x0, [x23, #0x5c10]
   3d814:	ldr	x14, [sp, #0x1a0]
   3d818:	str	x0, [x14, #0x160]
   3d81c:	ldr	x0, [x23, #0x5c18]
   3d820:	ldr	x1, [sp, #0x1a0]
   3d824:	str	x0, [x1, #0x168]
   3d828:	ldr	x0, [x23, #0x5c20]
   3d82c:	str	x0, [x1, #0x170]
   3d830:	ldr	x0, [x23, #0x5c28]
   3d834:	str	x0, [x1, #0x178]
   3d838:	ldr	x0, [x23, #0x5c30]
   3d83c:	str	x0, [x1, #0x180]
   3d840:	ldr	x0, [x23, #0x5c38]
   3d844:	str	x0, [x1, #0x188]
   3d848:	ldr	x0, [x23, #0x5c40]
   3d84c:	str	x0, [x1, #0x190]
   3d850:	ldr	x0, [x23, #0x5c48]
   3d854:	str	x0, [x1, #0x198]
   3d858:	ldr	x0, [x23, #0x5c50]
   3d85c:	str	x0, [x1, #0x1a0]
   3d860:	ldr	x0, [x23, #0x5df8]
   3d864:	str	x0, [x1, #0x348]
   3d868:	ldr	x0, [x23, #0x5e00]
   3d86c:	str	x0, [x1, #0x350]
   3d870:	ldr	x0, [x23, #0x5e08]
   3d874:	str	x0, [x1, #0x358]
   3d878:	ldr	x0, [x23, #0x5e10]
   3d87c:	str	x0, [x1, #0x360]
   3d880:	ldr	x0, [x23, #0x5e18]
   3d884:	str	x0, [x1, #0x368]
   3d888:	ldr	x0, [x23, #0x5e20]
   3d88c:	str	x0, [x1, #0x370]
   3d890:	ldr	x0, [x23, #0x5e28]
   3d894:	str	x0, [x1, #0x378]
   3d898:	ldr	x0, [x23, #0x5e30]
   3d89c:	str	x0, [x1, #0x380]
   3d8a0:	ldr	x0, [x23, #0x5e38]
   3d8a4:	ldr	x2, [sp, #0x1a0]
   3d8a8:	str	x0, [x2, #0x388]
   3d8ac:	ldr	x0, [x23, #0x6128]
   3d8b0:	str	x0, [x5, #0x678]
   3d8b4:	ldr	x0, [x23, #0x6130]
   3d8b8:	ldr	x8, [sp, #0x1a0]
   3d8bc:	str	x0, [x8, #0x680]
   3d8c0:	ldr	x0, [x23, #0x6138]
   3d8c4:	str	x0, [x11, #0x688]
   3d8c8:	ldr	x0, [x23, #0x6140]
   3d8cc:	str	x0, [x14, #0x690]
   3d8d0:	ldr	x0, [x23, #0x6148]
   3d8d4:	str	x0, [x1, #0x698]
   3d8d8:	ldr	x0, [x23, #0x6150]
   3d8dc:	str	x0, [x1, #0x6a0]
   3d8e0:	ldr	x0, [x23, #0x6158]
   3d8e4:	str	x0, [x1, #0x6a8]
   3d8e8:	ldr	x0, [x23, #0x6160]
   3d8ec:	str	x0, [x1, #0x6b0]
   3d8f0:	ldr	x0, [x23, #0x62f0]
   3d8f4:	str	x0, [x1, #0x840]
   3d8f8:	ldr	x0, [x23, #0x62f8]
   3d8fc:	str	x0, [x1, #0x848]
   3d900:	ldr	x0, [x23, #0x6300]
   3d904:	str	x0, [x1, #0x850]
   3d908:	ldr	x0, [x23, #0x6308]
   3d90c:	str	x0, [x1, #0x858]
   3d910:	ldr	x0, [x23, #0x6310]
   3d914:	str	x0, [x1, #0x860]
   3d918:	ldr	x0, [x23, #0x6318]
   3d91c:	str	x0, [x1, #0x868]
   3d920:	ldr	x1, [x23, #0x6320]
   3d924:	ldr	x0, [sp, #0x1a0]
   3d928:	str	x1, [x0, #0x870]
   3d92c:	ldr	x2, [x23, #0x6328]
   3d930:	str	x2, [x0, #0x878]
   3d934:	ldr	x5, [x23, #0x6700]
   3d938:	str	x5, [x0, #0xc50]
   3d93c:	ldr	x5, [x23, #0x6708]
   3d940:	str	x5, [x0, #0xc58]
   3d944:	ldr	x5, [x23, #0x6710]
   3d948:	str	x5, [x0, #0xc60]
   3d94c:	ldr	x6, [x23, #0x6718]
   3d950:	str	x6, [x0, #0xc68]
   3d954:	ldr	x7, [x23, #0x6720]
   3d958:	ldr	x2, [sp, #0x1a0]
   3d95c:	str	x7, [x2, #0xc70]
   3d960:	ldr	x8, [x23, #0x6728]
   3d964:	ldr	x5, [sp, #0x1a0]
   3d968:	str	x8, [x5, #0xc78]
   3d96c:	mov	x9, #0x0
   3d970:	ldr	x8, [sp, #0x1a0]
   3d974:	str	x9, [x8, #0xc80]
   3d978:	ldr	x10, [x23, #0x6738]
   3d97c:	str	x10, [x11, #0xc88]
   3d980:	ldr	x11, [x23, #0x6740]
   3d984:	str	x11, [x14, #0xc90]
   3d988:	str	x9, [x0, #0xc98]
   3d98c:	ldr	x13, [x23, #0x6750]
   3d990:	str	x13, [x0, #0xca0]
   3d994:	ldr	x14, [x23, #0x6758]
   3d998:	str	x14, [x0, #0xca8]
   3d99c:	str	x9, [x0, #0xcb0]
   3d9a0:	ldr	x0, [x23, #0x6768]
   3d9a4:	ldr	x1, [sp, #0x1a0]
   3d9a8:	str	x0, [x1, #0xcb8]
   3d9ac:	ldr	x0, [x23, #0x6770]
   3d9b0:	str	x0, [x1, #0xcc0]
   3d9b4:	mov	x1, #0x6ba
   3d9b8:	mov	x2, #-0x9
   3d9bc:	ldr	x27, [sp, #0x1b0]
   3d9c0:	ldur	x0, [sp, #0x8]
   3d9c4:	mov	x5, x22
   3d9c8:	ldr	x6, [sp, #0x1a8]
   3d9cc:	blr	x27
   3d9d0:	cmp	x0, #0x0
   3d9d4:	b.ne	0x41bb8
   3d9d8:	mov	x0, #0x3
   3d9dc:	ldr	x15, [sp, #0x198]
   3d9e0:	stur	x0, [sp, #0xc0]
   3d9e4:	cmp	x15, #0x2
   3d9e8:	b.lo	0x43a18
   3d9ec:	mov	x5, #0x0
   3d9f0:	ldr	x3, [sp, #0x1a0]
   3d9f4:	str	x5, [x3]
   3d9f8:	ldr	x0, [x23, #0x2490]
   3d9fc:	str	x0, [x3, #0x8]
   3da00:	mov	x1, #0x6ba
   3da04:	ldur	x0, [sp, #0x8]
   3da08:	ldr	x6, [sp, #0x1a8]
   3da0c:	ldr	x27, [sp, #0x1b0]
   3da10:	mov	x4, x22
   3da14:	mov	x2, x5
   3da18:	blr	x27
   3da1c:	cmp	x0, #0x0
   3da20:	b.ne	0x41bc0
   3da24:	mov	x0, #0x3
   3da28:	stur	x0, [sp, #0xc0]
   3da2c:	b	0x43a18
   3da30:	stur	x0, [sp, #0x98]
   3da34:	mov	x15, x5
   3da38:	ldr	x3, [sp, #0x148]
   3da3c:	mov	x0, x8
   3da40:	ldr	x2, [x3, x20, lsl #3]
   3da44:	ldur	x3, [sp, #0xb8]
   3da48:	cmp	x2, x3
   3da4c:	b.ne	0x3da74
   3da50:	ldur	x21, [sp, #0x98]
   3da54:	mov	x8, x15
   3da58:	ldur	x5, [sp, #0x98]
   3da5c:	mov	x4, x19
   3da60:	mov	x3, x19
   3da64:	mov	x19, x0
   3da68:	mov	x2, x20
   3da6c:	ldur	x1, [sp, #0xa0]
   3da70:	b	0x3ddf4
   3da74:	add	x4, x2, #0x1
   3da78:	cmp	x4, x2
   3da7c:	b.lo	0x41bc8
   3da80:	ldr	x8, [sp, #0x170]
   3da84:	cmp	x2, x8
   3da88:	b.lo	0x3dd10
   3da8c:	b	0x41d34
   3da90:	ldr	x3, [x23, #0x5790]
   3da94:	ldr	x4, [x23, #0x5798]
   3da98:	mov	x0, #0x0
   3da9c:	str	x0, [x23, #0x5788]
   3daa0:	mov	x0, #0x3
   3daa4:	ldr	x15, [sp, #0x198]
   3daa8:	stur	x0, [sp, #0xc0]
   3daac:	cmp	x15, #0x19a
   3dab0:	b.lo	0x43a18
   3dab4:	ldr	x0, [x23, #0x5ac0]
   3dab8:	ldr	x1, [sp, #0x1a0]
   3dabc:	str	x0, [x1, #0x10]
   3dac0:	ldr	x1, [x23, #0x5ac8]
   3dac4:	ldr	x2, [sp, #0x1a0]
   3dac8:	str	x1, [x2, #0x18]
   3dacc:	ldr	x2, [x23, #0x6570]
   3dad0:	ldr	x5, [sp, #0x1a0]
   3dad4:	str	x2, [x5, #0xac0]
   3dad8:	str	x0, [x5, #0x10]
   3dadc:	ldr	x7, [sp, #0x1a0]
   3dae0:	str	x1, [x7, #0x18]
   3dae4:	ldr	x0, [x23, #0x5c10]
   3dae8:	ldr	x10, [sp, #0x1a0]
   3daec:	str	x0, [x10, #0x160]
   3daf0:	ldr	x0, [x23, #0x5c18]
   3daf4:	ldr	x13, [sp, #0x1a0]
   3daf8:	str	x0, [x13, #0x168]
   3dafc:	ldr	x0, [x23, #0x5c20]
   3db00:	ldr	x1, [sp, #0x1a0]
   3db04:	str	x0, [x1, #0x170]
   3db08:	ldr	x0, [x23, #0x5c28]
   3db0c:	str	x0, [x1, #0x178]
   3db10:	ldr	x0, [x23, #0x5c30]
   3db14:	str	x0, [x1, #0x180]
   3db18:	ldr	x0, [x23, #0x5c38]
   3db1c:	str	x0, [x1, #0x188]
   3db20:	ldr	x0, [x23, #0x5c40]
   3db24:	str	x0, [x1, #0x190]
   3db28:	ldr	x0, [x23, #0x5c48]
   3db2c:	str	x0, [x1, #0x198]
   3db30:	ldr	x0, [x23, #0x5c50]
   3db34:	str	x0, [x1, #0x1a0]
   3db38:	ldr	x0, [x23, #0x5df8]
   3db3c:	str	x0, [x1, #0x348]
   3db40:	ldr	x0, [x23, #0x5e00]
   3db44:	str	x0, [x1, #0x350]
   3db48:	ldr	x0, [x23, #0x5e08]
   3db4c:	str	x0, [x1, #0x358]
   3db50:	ldr	x0, [x23, #0x5e10]
   3db54:	str	x0, [x1, #0x360]
   3db58:	ldr	x0, [x23, #0x5e18]
   3db5c:	str	x0, [x1, #0x368]
   3db60:	ldr	x0, [x23, #0x5e20]
   3db64:	str	x0, [x1, #0x370]
   3db68:	ldr	x0, [x23, #0x5e28]
   3db6c:	str	x0, [x1, #0x378]
   3db70:	ldr	x0, [x23, #0x5e30]
   3db74:	str	x0, [x1, #0x380]
   3db78:	ldr	x0, [x23, #0x5e38]
   3db7c:	str	x0, [x1, #0x388]
   3db80:	ldr	x0, [x23, #0x6128]
   3db84:	str	x0, [x1, #0x678]
   3db88:	ldr	x0, [x23, #0x6130]
   3db8c:	str	x0, [x5, #0x680]
   3db90:	ldr	x1, [x23, #0x6138]
   3db94:	str	x1, [x7, #0x688]
   3db98:	ldr	x2, [x23, #0x6140]
   3db9c:	str	x2, [x10, #0x690]
   3dba0:	ldr	x5, [x23, #0x6148]
   3dba4:	str	x5, [x13, #0x698]
   3dba8:	ldr	x5, [x23, #0x6150]
   3dbac:	ldr	x0, [sp, #0x1a0]
   3dbb0:	str	x5, [x0, #0x6a0]
   3dbb4:	ldr	x5, [x23, #0x6158]
   3dbb8:	str	x5, [x0, #0x6a8]
   3dbbc:	ldr	x6, [x23, #0x6160]
   3dbc0:	str	x6, [x0, #0x6b0]
   3dbc4:	ldr	x7, [x23, #0x62f0]
   3dbc8:	str	x7, [x0, #0x840]
   3dbcc:	ldr	x8, [x23, #0x62f8]
   3dbd0:	str	x8, [x0, #0x848]
   3dbd4:	ldr	x9, [x23, #0x6300]
   3dbd8:	str	x9, [x0, #0x850]
   3dbdc:	ldr	x10, [x23, #0x6308]
   3dbe0:	str	x10, [x0, #0x858]
   3dbe4:	ldr	x11, [x23, #0x6310]
   3dbe8:	str	x11, [x0, #0x860]
   3dbec:	ldr	x12, [x23, #0x6318]
   3dbf0:	str	x12, [x0, #0x868]
   3dbf4:	ldr	x13, [x23, #0x6320]
   3dbf8:	str	x13, [x0, #0x870]
   3dbfc:	ldr	x14, [x23, #0x6328]
   3dc00:	str	x14, [x0, #0x878]
   3dc04:	ldr	x15, [x23, #0x6700]
   3dc08:	str	x15, [x0, #0xc50]
   3dc0c:	ldr	x0, [x23, #0x6708]
   3dc10:	ldr	x1, [sp, #0x1a0]
   3dc14:	str	x0, [x1, #0xc58]
   3dc18:	ldr	x0, [x23, #0x6710]
   3dc1c:	str	x0, [x1, #0xc60]
   3dc20:	ldr	x0, [x23, #0x6718]
   3dc24:	str	x0, [x1, #0xc68]
   3dc28:	ldr	x0, [x23, #0x6720]
   3dc2c:	str	x0, [x1, #0xc70]
   3dc30:	ldr	x0, [x23, #0x6728]
   3dc34:	str	x0, [x1, #0xc78]
   3dc38:	mov	x0, #0x0
   3dc3c:	ldr	x5, [sp, #0x1a0]
   3dc40:	str	x0, [x5, #0xc80]
   3dc44:	ldr	x1, [x23, #0x6738]
   3dc48:	ldr	x7, [sp, #0x1a0]
   3dc4c:	str	x1, [x7, #0xc88]
   3dc50:	ldr	x1, [x23, #0x6740]
   3dc54:	ldr	x10, [sp, #0x1a0]
   3dc58:	str	x1, [x10, #0xc90]
   3dc5c:	ldr	x12, [sp, #0x1a0]
   3dc60:	str	x0, [x12, #0xc98]
   3dc64:	ldr	x1, [x23, #0x6750]
   3dc68:	ldr	x15, [sp, #0x1a0]
   3dc6c:	str	x1, [x15, #0xca0]
   3dc70:	ldr	x1, [x23, #0x6758]
   3dc74:	ldr	x2, [sp, #0x1a0]
   3dc78:	str	x1, [x2, #0xca8]
   3dc7c:	ldr	x1, [sp, #0x1a0]
   3dc80:	str	x0, [x1, #0xcb0]
   3dc84:	ldr	x0, [x23, #0x6768]
   3dc88:	str	x0, [x1, #0xcb8]
   3dc8c:	ldr	x0, [x23, #0x6770]
   3dc90:	str	x0, [x1, #0xcc0]
   3dc94:	mov	x1, #0x6c1
   3dc98:	mov	x2, #-0x9
   3dc9c:	ldr	x27, [sp, #0x1b0]
   3dca0:	ldur	x0, [sp, #0x8]
   3dca4:	mov	x5, x21
   3dca8:	ldr	x6, [sp, #0x1a8]
   3dcac:	blr	x27
   3dcb0:	cmp	x0, #0x0
   3dcb4:	b.ne	0x41f28
   3dcb8:	mov	x0, #0x3
   3dcbc:	ldr	x15, [sp, #0x198]
   3dcc0:	stur	x0, [sp, #0xc0]
   3dcc4:	cmp	x15, #0x2
   3dcc8:	b.lo	0x43a18
   3dccc:	mov	x5, #0x0
   3dcd0:	ldr	x3, [sp, #0x1a0]
   3dcd4:	str	x5, [x3]
   3dcd8:	ldr	x0, [x23, #0x24b0]
   3dcdc:	str	x0, [x3, #0x8]
   3dce0:	mov	x1, #0x6c1
   3dce4:	ldur	x0, [sp, #0x8]
   3dce8:	ldr	x6, [sp, #0x1a8]
   3dcec:	ldr	x27, [sp, #0x1b0]
   3dcf0:	mov	x4, x21
   3dcf4:	mov	x2, x5
   3dcf8:	blr	x27
   3dcfc:	cmp	x0, #0x0
   3dd00:	b.ne	0x41f30
   3dd04:	mov	x0, #0x3
   3dd08:	stur	x0, [sp, #0xc0]
   3dd0c:	b	0x43a18
   3dd10:	ldr	x1, [sp, #0x178]
   3dd14:	mov	x4, x19
   3dd18:	ldur	x5, [sp, #0x98]
   3dd1c:	ldr	x1, [x1, x2, lsl #3]
   3dd20:	ldur	x3, [sp, #0xe8]
   3dd24:	and	x1, x3, x1
   3dd28:	fmov	d16, x1
   3dd2c:	cnt.8b	v16, v16
   3dd30:	addv.8b	b16, v16
   3dd34:	umov.b	w1, v16[0]
   3dd38:	eor	x2, x2, #0x3ffffffffffffff
   3dd3c:	orr	x2, x2, x1, lsl #58
   3dd40:	ldur	x24, [sp, #0xa0]
   3dd44:	cmp	x2, x24
   3dd48:	cset	x1, hi
   3dd4c:	cmp	x2, x5
   3dd50:	cset	x3, ne
   3dd54:	and	w1, w1, w3
   3dd58:	cmp	x2, x0
   3dd5c:	cset	x3, ne
   3dd60:	and	w1, w1, w3
   3dd64:	cmp	x2, x15
   3dd68:	cset	x3, ne
   3dd6c:	and	w1, w1, w3
   3dd70:	cmp	x2, x4
   3dd74:	cset	x3, ne
   3dd78:	and	w1, w1, w3
   3dd7c:	uxtb	w1, w1
   3dd80:	tbnz	w1, #0x0, 0x3dd98
   3dd84:	mov	x1, x0
   3dd88:	mov	x2, x15
   3dd8c:	mov	x8, x5
   3dd90:	ldur	x21, [sp, #0xa0]
   3dd94:	b	0x3ddc8
   3dd98:	cmp	x2, x5
   3dd9c:	csel	x8, x2, x5, hi
   3dda0:	csel	x2, x2, x5, lo
   3dda4:	cmp	x2, x0
   3dda8:	csel	x1, x2, x0, hi
   3ddac:	csel	x19, x2, x0, lo
   3ddb0:	cmp	x19, x15
   3ddb4:	csel	x2, x19, x15, hi
   3ddb8:	csel	x21, x19, x15, lo
   3ddbc:	cmp	x21, x4
   3ddc0:	csel	x19, x21, x4, hi
   3ddc4:	csel	x21, x21, x4, lo
   3ddc8:	mov	x3, x4
   3ddcc:	mov	x4, x19
   3ddd0:	mov	x19, x0
   3ddd4:	mov	x0, x1
   3ddd8:	ldur	x1, [sp, #0xa0]
   3dddc:	stur	x21, [sp, #0xa0]
   3dde0:	mov	x21, x5
   3dde4:	mov	x5, x8
   3dde8:	mov	x8, x15
   3ddec:	mov	x15, x2
   3ddf0:	mov	x2, x20
   3ddf4:	mov	x24, x5
   3ddf8:	mov	x5, x21
   3ddfc:	mov	x21, x0
   3de00:	mov	x0, x19
   3de04:	mov	x19, x15
   3de08:	mov	x15, x8
   3de0c:	ldur	x8, [sp, #0xa0]
   3de10:	stur	x1, [sp, #0xa0]
   3de14:	mov	x1, x4
   3de18:	mov	x4, x3
   3de1c:	cmp	x20, x10
   3de20:	b.lo	0x3de38
   3de24:	mov	w8, #0xdc1e
   3de28:	movk	w8, #0x2, lsl #16
   3de2c:	sub	x3, x9, x8
   3de30:	ldur	x9, [sp, #0xa8]
   3de34:	b	0x3e6f8
   3de38:	add	x20, x2, #0x1
   3de3c:	cmp	x20, x2
   3de40:	b.lo	0x41f38
   3de44:	mov	w0, #0xdc1e
   3de48:	movk	w0, #0x2, lsl #16
   3de4c:	sub	x9, x9, x0
   3de50:	mov	x3, #0x1
   3de54:	stur	x3, [sp, #0xb0]
   3de58:	stur	x8, [sp, #0xa0]
   3de5c:	mov	x8, x21
   3de60:	mov	x5, x19
   3de64:	mov	x19, x1
   3de68:	mov	x0, x24
   3de6c:	b	0x3d720
   3de70:	mov	w1, #0xdc1e
   3de74:	movk	w1, #0x2, lsl #16
   3de78:	cmp	x9, x1
   3de7c:	b.hs	0x3e2d0
   3de80:	ldur	x1, [sp, #0xb8]
   3de84:	ldur	x8, [sp, #0xb8]
   3de88:	ldur	x13, [sp, #0x48]
   3de8c:	ldur	x19, [sp, #0xb8]
   3de90:	ldur	x21, [sp, #0xa8]
   3de94:	ldur	x22, [sp, #0x40]
   3de98:	ldur	x24, [sp, #0x38]
   3de9c:	ldur	x25, [sp, #0x30]
   3dea0:	ldur	x26, [sp, #0x10]
   3dea4:	ldur	x27, [sp, #0xb8]
   3dea8:	mov	x28, #0x0
   3deac:	str	x28, [x23, #0x18]
   3deb0:	mov	x2, #0x1000000000000000
   3deb4:	str	x2, [x23, #0x20]
   3deb8:	mov	x2, #0x1
   3debc:	str	x2, [x23, #0x30]
   3dec0:	mov	x3, #0x101010101010101
   3dec4:	str	x3, [x23, #0x38]
   3dec8:	mov	x3, #0x2
   3decc:	str	x3, [x23, #0x40]
   3ded0:	stur	x3, [sp, #0xd8]
   3ded4:	mov	x3, #0x3
   3ded8:	str	x3, [x23, #0x48]
   3dedc:	mov	x3, #0x4
   3dee0:	str	x3, [x23, #0x50]
   3dee4:	mov	x3, #0xf0f0f0f0f0f0f0f
   3dee8:	str	x3, [x23, #0x78]
   3deec:	mov	x3, #0x3333333333333333
   3def0:	str	x3, [x23, #0x88]
   3def4:	mov	x3, #0x38
   3def8:	str	x3, [x23, #0x90]
   3defc:	mov	x3, #0x3a
   3df00:	str	x3, [x23, #0x98]
   3df04:	mov	x3, #0x5555555555555555
   3df08:	str	x3, [x23, #0xb0]
   3df0c:	mov	x3, #0x3ffffffffffffff
   3df10:	str	x3, [x23, #0xb8]
   3df14:	str	x28, [x23, #0x188]
   3df18:	str	x2, [x23, #0x190]
   3df1c:	ldur	x3, [sp, #0xb8]
   3df20:	str	x3, [x23, #0x22e0]
   3df24:	ldr	x28, [sp, #0x190]
   3df28:	str	x28, [x23, #0x22e8]
   3df2c:	ldur	x3, [sp, #0xf8]
   3df30:	uxtb	w3, w3
   3df34:	str	x3, [x23, #0x22f8]
   3df38:	ldur	x3, [sp, #0xa8]
   3df3c:	str	x3, [x23, #0x2398]
   3df40:	ldur	x3, [sp, #0xf0]
   3df44:	str	x3, [x23, #0x23a0]
   3df48:	str	x19, [x23, #0x23a8]
   3df4c:	ldur	x3, [sp, #0xe8]
   3df50:	str	x3, [x23, #0x23b0]
   3df54:	ldur	x3, [sp, #0xe0]
   3df58:	uxtb	w3, w3
   3df5c:	str	x3, [x23, #0x23c0]
   3df60:	ldur	x3, [sp, #0x58]
   3df64:	str	x3, [x23, #0x5788]
   3df68:	str	x9, [x23, #0x5790]
   3df6c:	ldur	x3, [sp, #0x60]
   3df70:	str	x3, [x23, #0x5798]
   3df74:	str	x1, [x23, #0x5ac0]
   3df78:	str	x28, [x23, #0x5ac8]
   3df7c:	str	x21, [x23, #0x5c10]
   3df80:	ldur	x1, [sp, #0xf0]
   3df84:	str	x1, [x23, #0x5c18]
   3df88:	str	x27, [x23, #0x5c20]
   3df8c:	ldur	x1, [sp, #0xe8]
   3df90:	str	x1, [x23, #0x5c28]
   3df94:	ldur	x1, [sp, #0x10]
   3df98:	str	x1, [x23, #0x5c30]
   3df9c:	ldur	x21, [sp, #0x30]
   3dfa0:	str	x21, [x23, #0x5c38]
   3dfa4:	ldur	x1, [sp, #0x38]
   3dfa8:	str	x1, [x23, #0x5c40]
   3dfac:	ldur	x1, [sp, #0x40]
   3dfb0:	str	x1, [x23, #0x5c48]
   3dfb4:	ldur	x3, [sp, #0x48]
   3dfb8:	str	x3, [x23, #0x5c50]
   3dfbc:	str	x26, [x23, #0x5cc8]
   3dfc0:	str	x25, [x23, #0x5cd0]
   3dfc4:	str	x24, [x23, #0x5cd8]
   3dfc8:	str	x22, [x23, #0x5ce0]
   3dfcc:	str	x13, [x23, #0x5ce8]
   3dfd0:	str	x20, [x23, #0x5df8]
   3dfd4:	str	x10, [x23, #0x5e00]
   3dfd8:	str	x8, [x23, #0x5e08]
   3dfdc:	ldur	x1, [sp, #0xe8]
   3dfe0:	str	x1, [x23, #0x5e10]
   3dfe4:	str	x5, [x23, #0x5e18]
   3dfe8:	str	x0, [x23, #0x5e20]
   3dfec:	str	x15, [x23, #0x5e28]
   3dff0:	str	x4, [x23, #0x5e30]
   3dff4:	ldur	x24, [sp, #0xa0]
   3dff8:	str	x24, [x23, #0x5e38]
   3dffc:	ldur	x1, [sp, #0x28]
   3e000:	str	x1, [x23, #0x6570]
   3e004:	add	x0, x14, #0x1
   3e008:	str	x0, [x23, #0x6700]
   3e00c:	ldur	x24, [sp, #0x68]
   3e010:	str	x24, [x23, #0x6708]
   3e014:	ldur	x25, [sp, #0x70]
   3e018:	str	x25, [x23, #0x6710]
   3e01c:	ldur	x4, [sp, #0x50]
   3e020:	sub	x1, x4, x9
   3e024:	mov	w3, #0xc87e
   3e028:	movk	w3, #0x1, lsl #16
   3e02c:	msub	x0, x0, x3, x1
   3e030:	str	x0, [x23, #0x6718]
   3e034:	str	x2, [x23, #0x6720]
   3e038:	ldur	x13, [sp, #0x18]
   3e03c:	str	x13, [x23, #0x6728]
   3e040:	str	x2, [x23, #0x6738]
   3e044:	ldur	x3, [sp, #0xb0]
   3e048:	str	x3, [x23, #0x6740]
   3e04c:	str	x12, [x23, #0x6750]
   3e050:	str	x11, [x23, #0x6758]
   3e054:	str	x7, [x23, #0x6768]
   3e058:	str	x6, [x23, #0x6770]
   3e05c:	ldr	x0, [x23, #0x5788]
   3e060:	cmp	x0, #0x0
   3e064:	b.eq	0x3e2a8
   3e068:	ldr	x3, [x23, #0x5790]
   3e06c:	ldr	x4, [x23, #0x5798]
   3e070:	mov	x1, #0x0
   3e074:	str	x1, [x23, #0x5788]
   3e078:	mov	x0, #0x3
   3e07c:	ldr	x15, [sp, #0x198]
   3e080:	stur	x0, [sp, #0xc0]
   3e084:	cmp	x15, #0x19a
   3e088:	b.lo	0x43a18
   3e08c:	ldr	x5, [x23, #0x5ac0]
   3e090:	ldr	x0, [sp, #0x1a0]
   3e094:	str	x5, [x0, #0x10]
   3e098:	ldr	x6, [x23, #0x5ac8]
   3e09c:	str	x6, [x0, #0x18]
   3e0a0:	ldr	x7, [x23, #0x6570]
   3e0a4:	str	x7, [x0, #0xac0]
   3e0a8:	ldr	x8, [x23, #0x5cc8]
   3e0ac:	str	x8, [x0, #0x218]
   3e0b0:	ldr	x9, [x23, #0x5cd0]
   3e0b4:	str	x9, [x0, #0x220]
   3e0b8:	ldr	x10, [x23, #0x5cd8]
   3e0bc:	str	x10, [x0, #0x228]
   3e0c0:	ldr	x11, [x23, #0x5ce0]
   3e0c4:	str	x11, [x0, #0x230]
   3e0c8:	ldr	x12, [x23, #0x5ce8]
   3e0cc:	str	x12, [x0, #0x238]
   3e0d0:	str	x5, [x0, #0x10]
   3e0d4:	str	x6, [x0, #0x18]
   3e0d8:	ldr	x15, [x23, #0x5c10]
   3e0dc:	ldr	x5, [sp, #0x1a0]
   3e0e0:	str	x15, [x5, #0x160]
   3e0e4:	ldr	x0, [x23, #0x5c18]
   3e0e8:	ldr	x6, [sp, #0x1a0]
   3e0ec:	str	x0, [x6, #0x168]
   3e0f0:	ldr	x0, [x23, #0x5c20]
   3e0f4:	ldr	x9, [sp, #0x1a0]
   3e0f8:	str	x0, [x9, #0x170]
   3e0fc:	ldr	x0, [x23, #0x5c28]
   3e100:	ldr	x12, [sp, #0x1a0]
   3e104:	str	x0, [x12, #0x178]
   3e108:	ldr	x0, [x23, #0x5c30]
   3e10c:	ldr	x15, [sp, #0x1a0]
   3e110:	str	x0, [x15, #0x180]
   3e114:	ldr	x0, [x23, #0x5c38]
   3e118:	ldr	x1, [sp, #0x1a0]
   3e11c:	str	x0, [x1, #0x188]
   3e120:	ldr	x0, [x23, #0x5c40]
   3e124:	str	x0, [x1, #0x190]
   3e128:	ldr	x0, [x23, #0x5c48]
   3e12c:	str	x0, [x1, #0x198]
   3e130:	ldr	x0, [x23, #0x5c50]
   3e134:	str	x0, [x1, #0x1a0]
   3e138:	ldr	x0, [x23, #0x5df8]
   3e13c:	str	x0, [x1, #0x348]
   3e140:	ldr	x0, [x23, #0x5e00]
   3e144:	str	x0, [x1, #0x350]
   3e148:	ldr	x0, [x23, #0x5e08]
   3e14c:	str	x0, [x1, #0x358]
   3e150:	ldr	x0, [x23, #0x5e10]
   3e154:	str	x0, [x1, #0x360]
   3e158:	ldr	x0, [x23, #0x5e18]
   3e15c:	str	x0, [x1, #0x368]
   3e160:	ldr	x0, [x23, #0x5e20]
   3e164:	str	x0, [x1, #0x370]
   3e168:	ldr	x0, [x23, #0x5e28]
   3e16c:	str	x0, [x1, #0x378]
   3e170:	ldr	x0, [x23, #0x5e30]
   3e174:	str	x0, [x1, #0x380]
   3e178:	ldr	x0, [x23, #0x5e38]
   3e17c:	str	x0, [x1, #0x388]
   3e180:	ldr	x0, [x23, #0x6128]
   3e184:	str	x0, [x1, #0x678]
   3e188:	ldr	x0, [x23, #0x6130]
   3e18c:	str	x0, [x1, #0x680]
   3e190:	ldr	x0, [x23, #0x6138]
   3e194:	str	x0, [x1, #0x688]
   3e198:	ldr	x0, [x23, #0x6140]
   3e19c:	str	x0, [x5, #0x690]
   3e1a0:	ldr	x0, [x23, #0x6148]
   3e1a4:	str	x0, [x6, #0x698]
   3e1a8:	ldr	x0, [x23, #0x6150]
   3e1ac:	str	x0, [x9, #0x6a0]
   3e1b0:	ldr	x0, [x23, #0x6158]
   3e1b4:	str	x0, [x12, #0x6a8]
   3e1b8:	ldr	x0, [x23, #0x6160]
   3e1bc:	str	x0, [x15, #0x6b0]
   3e1c0:	ldr	x0, [x23, #0x62f0]
   3e1c4:	str	x0, [x1, #0x840]
   3e1c8:	ldr	x0, [x23, #0x62f8]
   3e1cc:	str	x0, [x1, #0x848]
   3e1d0:	ldr	x0, [x23, #0x6300]
   3e1d4:	str	x0, [x1, #0x850]
   3e1d8:	ldr	x0, [x23, #0x6308]
   3e1dc:	str	x0, [x1, #0x858]
   3e1e0:	ldr	x0, [x23, #0x6310]
   3e1e4:	str	x0, [x1, #0x860]
   3e1e8:	ldr	x0, [x23, #0x6318]
   3e1ec:	str	x0, [x1, #0x868]
   3e1f0:	ldr	x0, [x23, #0x6320]
   3e1f4:	str	x0, [x1, #0x870]
   3e1f8:	ldr	x0, [x23, #0x6328]
   3e1fc:	str	x0, [x1, #0x878]
   3e200:	ldr	x0, [x23, #0x6700]
   3e204:	str	x0, [x1, #0xc50]
   3e208:	ldr	x0, [x23, #0x6708]
   3e20c:	str	x0, [x1, #0xc58]
   3e210:	ldr	x0, [x23, #0x6710]
   3e214:	str	x0, [x1, #0xc60]
   3e218:	ldr	x0, [x23, #0x6718]
   3e21c:	str	x0, [x1, #0xc68]
   3e220:	ldr	x0, [x23, #0x6720]
   3e224:	str	x0, [x1, #0xc70]
   3e228:	ldr	x0, [x23, #0x6728]
   3e22c:	str	x0, [x1, #0xc78]
   3e230:	mov	x0, #0x0
   3e234:	str	x0, [x1, #0xc80]
   3e238:	ldr	x1, [x23, #0x6738]
   3e23c:	ldr	x2, [sp, #0x1a0]
   3e240:	str	x1, [x2, #0xc88]
   3e244:	ldr	x1, [x23, #0x6740]
   3e248:	str	x1, [x5, #0xc90]
   3e24c:	str	x0, [x5, #0xc98]
   3e250:	ldr	x1, [x23, #0x6750]
   3e254:	ldr	x8, [sp, #0x1a0]
   3e258:	str	x1, [x8, #0xca0]
   3e25c:	ldr	x1, [x23, #0x6758]
   3e260:	ldr	x11, [sp, #0x1a0]
   3e264:	str	x1, [x11, #0xca8]
   3e268:	ldr	x13, [sp, #0x1a0]
   3e26c:	str	x0, [x13, #0xcb0]
   3e270:	ldr	x0, [x23, #0x6768]
   3e274:	ldr	x1, [sp, #0x1a0]
   3e278:	str	x0, [x1, #0xcb8]
   3e27c:	ldr	x0, [x23, #0x6770]
   3e280:	str	x0, [x1, #0xcc0]
   3e284:	mov	x1, #0x6a9
   3e288:	mov	x2, #-0x9
   3e28c:	mov	x5, #0x1
   3e290:	ldur	x0, [sp, #0x8]
   3e294:	ldr	x6, [sp, #0x1a8]
   3e298:	ldr	x27, [sp, #0x1b0]
   3e29c:	blr	x27
   3e2a0:	cmp	x0, #0x0
   3e2a4:	b.ne	0x42098
   3e2a8:	mov	x0, #0x0
   3e2ac:	mov	x1, #0x3
   3e2b0:	add	sp, sp, #0x1d0
   3e2b4:	ldp	x19, x20, [sp], #0x10
   3e2b8:	ldp	x21, x22, [sp], #0x10
   3e2bc:	ldp	x23, x24, [sp], #0x10
   3e2c0:	ldp	x25, x26, [sp], #0x10
   3e2c4:	ldp	x27, x28, [sp], #0x10
   3e2c8:	ldp	x29, x30, [sp], #0x10
   3e2cc:	.long	0xd65f0fff
   3e2d0:	cmp	x20, x10
   3e2d4:	cset	x8, lo
   3e2d8:	cmp	x20, x10
   3e2dc:	b.lo	0x3e2fc
   3e2e0:	ldur	x1, [sp, #0xa0]
   3e2e4:	mov	x19, x4
   3e2e8:	mov	x21, x20
   3e2ec:	mov	x24, x15
   3e2f0:	mov	x26, x0
   3e2f4:	mov	x28, x5
   3e2f8:	b	0x3e6e0
   3e2fc:	ldr	x24, [sp, #0x148]
   3e300:	ldr	x2, [x24, x20, lsl #3]
   3e304:	ldur	x1, [sp, #0xb8]
   3e308:	cmp	x2, x1
   3e30c:	b.ne	0x3e32c
   3e310:	ldur	x1, [sp, #0xa0]
   3e314:	mov	x2, x4
   3e318:	mov	x3, x15
   3e31c:	mov	x8, x0
   3e320:	mov	x19, x5
   3e324:	mov	x21, x20
   3e328:	b	0x3e6a8
   3e32c:	add	x21, x2, #0x1
   3e330:	cmp	x21, x2
   3e334:	b.lo	0x420a4
   3e338:	ldr	x1, [sp, #0x170]
   3e33c:	cmp	x2, x1
   3e340:	b.lo	0x3e5c8
   3e344:	b	0x42210
   3e348:	ldr	x3, [x23, #0x5790]
   3e34c:	ldr	x4, [x23, #0x5798]
   3e350:	mov	x0, #0x0
   3e354:	str	x0, [x23, #0x5788]
   3e358:	mov	x0, #0x3
   3e35c:	ldr	x15, [sp, #0x198]
   3e360:	stur	x0, [sp, #0xc0]
   3e364:	cmp	x15, #0x19a
   3e368:	b.lo	0x43a18
   3e36c:	ldr	x0, [x23, #0x5ac0]
   3e370:	ldr	x1, [sp, #0x1a0]
   3e374:	str	x0, [x1, #0x10]
   3e378:	ldr	x1, [x23, #0x5ac8]
   3e37c:	ldr	x2, [sp, #0x1a0]
   3e380:	str	x1, [x2, #0x18]
   3e384:	ldr	x2, [x23, #0x6570]
   3e388:	ldr	x5, [sp, #0x1a0]
   3e38c:	str	x2, [x5, #0xac0]
   3e390:	ldr	x2, [sp, #0x1a0]
   3e394:	str	x0, [x2, #0x10]
   3e398:	str	x1, [x2, #0x18]
   3e39c:	ldr	x0, [x23, #0x5c10]
   3e3a0:	str	x0, [x5, #0x160]
   3e3a4:	ldr	x0, [x23, #0x5c18]
   3e3a8:	ldr	x8, [sp, #0x1a0]
   3e3ac:	str	x0, [x8, #0x168]
   3e3b0:	ldr	x0, [x23, #0x5c20]
   3e3b4:	ldr	x11, [sp, #0x1a0]
   3e3b8:	str	x0, [x11, #0x170]
   3e3bc:	ldr	x0, [x23, #0x5c28]
   3e3c0:	ldr	x14, [sp, #0x1a0]
   3e3c4:	str	x0, [x14, #0x178]
   3e3c8:	ldr	x0, [x23, #0x5c30]
   3e3cc:	ldr	x1, [sp, #0x1a0]
   3e3d0:	str	x0, [x1, #0x180]
   3e3d4:	ldr	x0, [x23, #0x5c38]
   3e3d8:	str	x0, [x1, #0x188]
   3e3dc:	ldr	x0, [x23, #0x5c40]
   3e3e0:	str	x0, [x1, #0x190]
   3e3e4:	ldr	x0, [x23, #0x5c48]
   3e3e8:	str	x0, [x1, #0x198]
   3e3ec:	ldr	x0, [x23, #0x5c50]
   3e3f0:	str	x0, [x1, #0x1a0]
   3e3f4:	ldr	x0, [x23, #0x5df8]
   3e3f8:	str	x0, [x1, #0x348]
   3e3fc:	ldr	x0, [x23, #0x5e00]
   3e400:	str	x0, [x1, #0x350]
   3e404:	ldr	x0, [x23, #0x5e08]
   3e408:	str	x0, [x1, #0x358]
   3e40c:	ldr	x0, [x23, #0x5e10]
   3e410:	str	x0, [x1, #0x360]
   3e414:	ldr	x0, [x23, #0x5e18]
   3e418:	str	x0, [x1, #0x368]
   3e41c:	ldr	x0, [x23, #0x5e20]
   3e420:	str	x0, [x1, #0x370]
   3e424:	ldr	x0, [x23, #0x5e28]
   3e428:	str	x0, [x1, #0x378]
   3e42c:	ldr	x0, [x23, #0x5e30]
   3e430:	str	x0, [x1, #0x380]
   3e434:	ldr	x0, [x23, #0x5e38]
   3e438:	str	x0, [x1, #0x388]
   3e43c:	ldr	x0, [x23, #0x6128]
   3e440:	str	x0, [x1, #0x678]
   3e444:	ldr	x0, [x23, #0x6130]
   3e448:	str	x0, [x1, #0x680]
   3e44c:	ldr	x0, [x23, #0x6138]
   3e450:	str	x0, [x2, #0x688]
   3e454:	ldr	x0, [x23, #0x6140]
   3e458:	str	x0, [x5, #0x690]
   3e45c:	ldr	x0, [x23, #0x6148]
   3e460:	str	x0, [x8, #0x698]
   3e464:	ldr	x0, [x23, #0x6150]
   3e468:	str	x0, [x11, #0x6a0]
   3e46c:	ldr	x0, [x23, #0x6158]
   3e470:	str	x0, [x14, #0x6a8]
   3e474:	ldr	x0, [x23, #0x6160]
   3e478:	str	x0, [x1, #0x6b0]
   3e47c:	ldr	x1, [x23, #0x62f0]
   3e480:	ldr	x0, [sp, #0x1a0]
   3e484:	str	x1, [x0, #0x840]
   3e488:	ldr	x2, [x23, #0x62f8]
   3e48c:	str	x2, [x0, #0x848]
   3e490:	ldr	x5, [x23, #0x6300]
   3e494:	str	x5, [x0, #0x850]
   3e498:	ldr	x5, [x23, #0x6308]
   3e49c:	str	x5, [x0, #0x858]
   3e4a0:	ldr	x5, [x23, #0x6310]
   3e4a4:	str	x5, [x0, #0x860]
   3e4a8:	ldr	x6, [x23, #0x6318]
   3e4ac:	str	x6, [x0, #0x868]
   3e4b0:	ldr	x7, [x23, #0x6320]
   3e4b4:	str	x7, [x0, #0x870]
   3e4b8:	ldr	x8, [x23, #0x6328]
   3e4bc:	str	x8, [x0, #0x878]
   3e4c0:	ldr	x9, [x23, #0x6700]
   3e4c4:	str	x9, [x0, #0xc50]
   3e4c8:	ldr	x10, [x23, #0x6708]
   3e4cc:	str	x10, [x0, #0xc58]
   3e4d0:	ldr	x11, [x23, #0x6710]
   3e4d4:	str	x11, [x0, #0xc60]
   3e4d8:	ldr	x12, [x23, #0x6718]
   3e4dc:	str	x12, [x0, #0xc68]
   3e4e0:	ldr	x13, [x23, #0x6720]
   3e4e4:	str	x13, [x0, #0xc70]
   3e4e8:	ldr	x14, [x23, #0x6728]
   3e4ec:	str	x14, [x0, #0xc78]
   3e4f0:	mov	x15, #0x0
   3e4f4:	str	x15, [x0, #0xc80]
   3e4f8:	ldr	x0, [x23, #0x6738]
   3e4fc:	ldr	x2, [sp, #0x1a0]
   3e500:	str	x0, [x2, #0xc88]
   3e504:	ldr	x0, [x23, #0x6740]
   3e508:	ldr	x5, [sp, #0x1a0]
   3e50c:	str	x0, [x5, #0xc90]
   3e510:	ldr	x7, [sp, #0x1a0]
   3e514:	str	x15, [x7, #0xc98]
   3e518:	ldr	x0, [x23, #0x6750]
   3e51c:	ldr	x10, [sp, #0x1a0]
   3e520:	str	x0, [x10, #0xca0]
   3e524:	ldr	x0, [x23, #0x6758]
   3e528:	ldr	x13, [sp, #0x1a0]
   3e52c:	str	x0, [x13, #0xca8]
   3e530:	ldr	x0, [sp, #0x1a0]
   3e534:	str	x15, [x0, #0xcb0]
   3e538:	ldr	x0, [x23, #0x6768]
   3e53c:	ldr	x1, [sp, #0x1a0]
   3e540:	str	x0, [x1, #0xcb8]
   3e544:	ldr	x0, [x23, #0x6770]
   3e548:	str	x0, [x1, #0xcc0]
   3e54c:	mov	x2, #-0x9
   3e550:	ldr	x11, [sp, #0x1b0]
   3e554:	ldur	x0, [sp, #0x8]
   3e558:	mov	x1, x19
   3e55c:	mov	x5, x27
   3e560:	ldr	x6, [sp, #0x1a8]
   3e564:	blr	x11
   3e568:	cmp	x0, #0x0
   3e56c:	b.ne	0x42414
   3e570:	mov	x0, #0x3
   3e574:	ldr	x15, [sp, #0x198]
   3e578:	stur	x0, [sp, #0xc0]
   3e57c:	cmp	x15, #0x2
   3e580:	b.lo	0x43a18
   3e584:	mov	x5, #0x0
   3e588:	ldr	x3, [sp, #0x1a0]
   3e58c:	str	x5, [x3]
   3e590:	ldr	x0, [x23, #0x24b0]
   3e594:	str	x0, [x3, #0x8]
   3e598:	ldur	x0, [sp, #0x8]
   3e59c:	mov	x1, x19
   3e5a0:	ldr	x6, [sp, #0x1a8]
   3e5a4:	ldr	x7, [sp, #0x1b0]
   3e5a8:	mov	x4, x27
   3e5ac:	mov	x2, x5
   3e5b0:	blr	x7
   3e5b4:	cmp	x0, #0x0
   3e5b8:	b.ne	0x4241c
   3e5bc:	mov	x0, #0x3
   3e5c0:	stur	x0, [sp, #0xc0]
   3e5c4:	b	0x43a18
   3e5c8:	ldr	x1, [sp, #0x178]
   3e5cc:	ldr	x1, [x1, x2, lsl #3]
   3e5d0:	ldur	x3, [sp, #0xe8]
   3e5d4:	and	x8, x3, x1
   3e5d8:	fmov	d2, x8
   3e5dc:	cnt.8b	v4, v2
   3e5e0:	addv.8b	b6, v4
   3e5e4:	umov.b	w8, v6[0]
   3e5e8:	eor	x1, x2, #0x3ffffffffffffff
   3e5ec:	orr	x8, x1, x8, lsl #58
   3e5f0:	ldur	x24, [sp, #0xa0]
   3e5f4:	cmp	x8, x24
   3e5f8:	cset	x1, hi
   3e5fc:	cmp	x8, x5
   3e600:	cset	x2, ne
   3e604:	and	w1, w1, w2
   3e608:	cmp	x8, x0
   3e60c:	cset	x2, ne
   3e610:	and	w1, w1, w2
   3e614:	cmp	x8, x15
   3e618:	cset	x2, ne
   3e61c:	and	w1, w1, w2
   3e620:	cmp	x8, x4
   3e624:	cset	x2, ne
   3e628:	and	w1, w1, w2
   3e62c:	uxtb	w1, w1
   3e630:	tbnz	w1, #0x0, 0x3e64c
   3e634:	mov	x1, x5
   3e638:	mov	x2, x0
   3e63c:	mov	x8, x15
   3e640:	mov	x19, x4
   3e644:	ldur	x21, [sp, #0xa0]
   3e648:	b	0x3e67c
   3e64c:	cmp	x8, x5
   3e650:	csel	x1, x8, x5, hi
   3e654:	csel	x8, x8, x5, lo
   3e658:	cmp	x8, x0
   3e65c:	csel	x2, x8, x0, hi
   3e660:	csel	x19, x8, x0, lo
   3e664:	cmp	x19, x15
   3e668:	csel	x8, x19, x15, hi
   3e66c:	csel	x21, x19, x15, lo
   3e670:	cmp	x21, x4
   3e674:	csel	x19, x21, x4, hi
   3e678:	csel	x21, x21, x4, lo
   3e67c:	mov	x3, x15
   3e680:	mov	x15, x8
   3e684:	mov	x8, x0
   3e688:	mov	x0, x2
   3e68c:	mov	x2, x4
   3e690:	mov	x4, x19
   3e694:	mov	x19, x5
   3e698:	mov	x5, x1
   3e69c:	ldur	x1, [sp, #0xa0]
   3e6a0:	stur	x21, [sp, #0xa0]
   3e6a4:	mov	x21, x20
   3e6a8:	mov	x28, x5
   3e6ac:	mov	x26, x0
   3e6b0:	mov	x24, x15
   3e6b4:	mov	x15, x3
   3e6b8:	mov	x5, x19
   3e6bc:	mov	x19, x4
   3e6c0:	mov	x4, x2
   3e6c4:	str	x1, [sp, #0x1b8]
   3e6c8:	ldur	x1, [sp, #0xa0]
   3e6cc:	str	x28, [sp, #0x1c0]
   3e6d0:	ldr	x28, [sp, #0x1b8]
   3e6d4:	stur	x28, [sp, #0xa0]
   3e6d8:	mov	x0, x8
   3e6dc:	ldr	x28, [sp, #0x1c0]
   3e6e0:	cmp	x20, x10
   3e6e4:	b.lo	0x40ecc
   3e6e8:	mov	w1, #0xdc1e
   3e6ec:	movk	w1, #0x2, lsl #16
   3e6f0:	sub	x3, x9, x1
   3e6f4:	ldur	x9, [sp, #0xa8]
   3e6f8:	tbnz	w13, #0x1, 0x42424
   3e6fc:	mov	x19, #0x0
   3e700:	stur	x19, [sp, #0x78]
   3e704:	ldur	x1, [sp, #0x78]
   3e708:	stur	x1, [sp, #0x80]
   3e70c:	ldur	x1, [sp, #0xa8]
   3e710:	ldur	x10, [sp, #0xf0]
   3e714:	cmp	x1, x10
   3e718:	b.lo	0x40e94
   3e71c:	tbnz	w13, #0x0, 0x42478
   3e720:	ldur	x0, [sp, #0xb8]
   3e724:	ldr	x24, [sp, #0x130]
   3e728:	cmp	x0, x24
   3e72c:	b.lo	0x3e9b8
   3e730:	b	0x424cc
   3e734:	ldr	x3, [x23, #0x5790]
   3e738:	ldr	x4, [x23, #0x5798]
   3e73c:	mov	x0, #0x0
   3e740:	str	x0, [x23, #0x5788]
   3e744:	mov	x0, #0x3
   3e748:	ldr	x15, [sp, #0x198]
   3e74c:	stur	x0, [sp, #0xc0]
   3e750:	cmp	x15, #0x19a
   3e754:	b.lo	0x43a18
   3e758:	ldr	x0, [x23, #0x5ac0]
   3e75c:	ldr	x1, [sp, #0x1a0]
   3e760:	str	x0, [x1, #0x10]
   3e764:	ldr	x1, [x23, #0x5ac8]
   3e768:	ldr	x2, [sp, #0x1a0]
   3e76c:	str	x1, [x2, #0x18]
   3e770:	ldr	x2, [x23, #0x6570]
   3e774:	ldr	x5, [sp, #0x1a0]
   3e778:	str	x2, [x5, #0xac0]
   3e77c:	ldr	x2, [sp, #0x1a0]
   3e780:	str	x0, [x2, #0x10]
   3e784:	ldr	x0, [sp, #0x1a0]
   3e788:	str	x1, [x0, #0x18]
   3e78c:	ldr	x0, [x23, #0x5c10]
   3e790:	ldr	x1, [sp, #0x1a0]
   3e794:	str	x0, [x1, #0x160]
   3e798:	ldr	x0, [x23, #0x5c18]
   3e79c:	str	x0, [x1, #0x168]
   3e7a0:	ldr	x0, [x23, #0x5c20]
   3e7a4:	str	x0, [x1, #0x170]
   3e7a8:	ldr	x0, [x23, #0x5c28]
   3e7ac:	str	x0, [x5, #0x178]
   3e7b0:	ldr	x0, [x23, #0x5c30]
   3e7b4:	ldr	x7, [sp, #0x1a0]
   3e7b8:	str	x0, [x7, #0x180]
   3e7bc:	ldr	x0, [x23, #0x5c38]
   3e7c0:	ldr	x10, [sp, #0x1a0]
   3e7c4:	str	x0, [x10, #0x188]
   3e7c8:	ldr	x0, [x23, #0x5c40]
   3e7cc:	ldr	x13, [sp, #0x1a0]
   3e7d0:	str	x0, [x13, #0x190]
   3e7d4:	ldr	x0, [x23, #0x5c48]
   3e7d8:	str	x0, [x1, #0x198]
   3e7dc:	ldr	x0, [x23, #0x5c50]
   3e7e0:	str	x0, [x1, #0x1a0]
   3e7e4:	ldr	x0, [x23, #0x5df8]
   3e7e8:	str	x0, [x1, #0x348]
   3e7ec:	ldr	x0, [x23, #0x5e00]
   3e7f0:	str	x0, [x1, #0x350]
   3e7f4:	ldr	x0, [x23, #0x5e08]
   3e7f8:	str	x0, [x1, #0x358]
   3e7fc:	ldr	x0, [x23, #0x5e10]
   3e800:	str	x0, [x1, #0x360]
   3e804:	ldr	x0, [x23, #0x5e18]
   3e808:	str	x0, [x1, #0x368]
   3e80c:	ldr	x0, [x23, #0x5e20]
   3e810:	str	x0, [x1, #0x370]
   3e814:	ldr	x0, [x23, #0x5e28]
   3e818:	str	x0, [x1, #0x378]
   3e81c:	ldr	x0, [x23, #0x5e30]
   3e820:	str	x0, [x1, #0x380]
   3e824:	ldr	x0, [x23, #0x5e38]
   3e828:	str	x0, [x1, #0x388]
   3e82c:	ldr	x0, [x23, #0x6128]
   3e830:	str	x0, [x1, #0x678]
   3e834:	ldr	x0, [x23, #0x6130]
   3e838:	str	x0, [x1, #0x680]
   3e83c:	ldr	x1, [x23, #0x6138]
   3e840:	ldr	x0, [sp, #0x1a0]
   3e844:	str	x1, [x0, #0x688]
   3e848:	ldr	x2, [x23, #0x6140]
   3e84c:	str	x2, [x0, #0x690]
   3e850:	ldr	x5, [x23, #0x6148]
   3e854:	str	x5, [x0, #0x698]
   3e858:	ldr	x5, [x23, #0x6150]
   3e85c:	ldr	x1, [sp, #0x1a0]
   3e860:	str	x5, [x1, #0x6a0]
   3e864:	ldr	x5, [x23, #0x6158]
   3e868:	ldr	x6, [sp, #0x1a0]
   3e86c:	str	x5, [x6, #0x6a8]
   3e870:	ldr	x6, [x23, #0x6160]
   3e874:	str	x6, [x7, #0x6b0]
   3e878:	ldr	x7, [x23, #0x62f0]
   3e87c:	str	x7, [x10, #0x840]
   3e880:	ldr	x8, [x23, #0x62f8]
   3e884:	str	x8, [x13, #0x848]
   3e888:	ldr	x9, [x23, #0x6300]
   3e88c:	str	x9, [x0, #0x850]
   3e890:	ldr	x10, [x23, #0x6308]
   3e894:	str	x10, [x0, #0x858]
   3e898:	ldr	x11, [x23, #0x6310]
   3e89c:	str	x11, [x0, #0x860]
   3e8a0:	ldr	x12, [x23, #0x6318]
   3e8a4:	str	x12, [x0, #0x868]
   3e8a8:	ldr	x13, [x23, #0x6320]
   3e8ac:	str	x13, [x0, #0x870]
   3e8b0:	ldr	x14, [x23, #0x6328]
   3e8b4:	str	x14, [x0, #0x878]
   3e8b8:	ldr	x15, [x23, #0x6700]
   3e8bc:	str	x15, [x0, #0xc50]
   3e8c0:	ldr	x0, [x23, #0x6708]
   3e8c4:	str	x0, [x1, #0xc58]
   3e8c8:	ldr	x0, [x23, #0x6710]
   3e8cc:	str	x0, [x1, #0xc60]
   3e8d0:	ldr	x0, [x23, #0x6718]
   3e8d4:	str	x0, [x1, #0xc68]
   3e8d8:	ldr	x0, [x23, #0x6720]
   3e8dc:	str	x0, [x1, #0xc70]
   3e8e0:	ldr	x0, [x23, #0x6728]
   3e8e4:	str	x0, [x1, #0xc78]
   3e8e8:	mov	x0, #0x0
   3e8ec:	str	x0, [x1, #0xc80]
   3e8f0:	ldr	x1, [x23, #0x6738]
   3e8f4:	ldr	x2, [sp, #0x1a0]
   3e8f8:	str	x1, [x2, #0xc88]
   3e8fc:	ldr	x1, [x23, #0x6740]
   3e900:	str	x1, [x2, #0xc90]
   3e904:	ldr	x1, [sp, #0x1a0]
   3e908:	str	x0, [x1, #0xc98]
   3e90c:	ldr	x1, [x23, #0x6750]
   3e910:	str	x1, [x2, #0xca0]
   3e914:	ldr	x1, [x23, #0x6758]
   3e918:	ldr	x5, [sp, #0x1a0]
   3e91c:	str	x1, [x5, #0xca8]
   3e920:	str	x0, [x5, #0xcb0]
   3e924:	ldr	x0, [x23, #0x6768]
   3e928:	ldr	x8, [sp, #0x1a0]
   3e92c:	str	x0, [x8, #0xcb8]
   3e930:	ldr	x0, [x23, #0x6770]
   3e934:	ldr	x11, [sp, #0x1a0]
   3e938:	str	x0, [x11, #0xcc0]
   3e93c:	mov	x1, #0x754
   3e940:	mov	x2, #-0x9
   3e944:	ldr	x27, [sp, #0x1b0]
   3e948:	ldur	x0, [sp, #0x8]
   3e94c:	mov	x5, x20
   3e950:	ldr	x6, [sp, #0x1a8]
   3e954:	blr	x27
   3e958:	cmp	x0, #0x0
   3e95c:	b.ne	0x425f8
   3e960:	mov	x0, #0x3
   3e964:	ldr	x15, [sp, #0x198]
   3e968:	stur	x0, [sp, #0xc0]
   3e96c:	cmp	x15, #0x2
   3e970:	b.lo	0x43a18
   3e974:	mov	x5, #0x0
   3e978:	ldr	x3, [sp, #0x1a0]
   3e97c:	str	x5, [x3]
   3e980:	ldr	x0, [x23, #0x2740]
   3e984:	str	x0, [x3, #0x8]
   3e988:	mov	x1, #0x754
   3e98c:	ldur	x0, [sp, #0x8]
   3e990:	ldr	x6, [sp, #0x1a8]
   3e994:	ldr	x27, [sp, #0x1b0]
   3e998:	mov	x4, x20
   3e99c:	mov	x2, x5
   3e9a0:	blr	x27
   3e9a4:	cmp	x0, #0x0
   3e9a8:	b.ne	0x42600
   3e9ac:	mov	x0, #0x3
   3e9b0:	stur	x0, [sp, #0xc0]
   3e9b4:	b	0x43a18
   3e9b8:	ldur	x4, [sp, #0xb8]
   3e9bc:	ldr	x24, [sp, #0x138]
   3e9c0:	ldr	x0, [x24, x4, lsl #3]
   3e9c4:	mov	x5, x0
   3e9c8:	mov	x0, x25
   3e9cc:	ldr	x24, [sp, #0x130]
   3e9d0:	cmp	x0, x24
   3e9d4:	b.lo	0x3ec58
   3e9d8:	b	0x42608
   3e9dc:	ldr	x3, [x23, #0x5790]
   3e9e0:	ldr	x4, [x23, #0x5798]
   3e9e4:	mov	x0, #0x0
   3e9e8:	str	x0, [x23, #0x5788]
   3e9ec:	mov	x0, #0x3
   3e9f0:	ldr	x15, [sp, #0x198]
   3e9f4:	stur	x0, [sp, #0xc0]
   3e9f8:	cmp	x15, #0x19a
   3e9fc:	b.lo	0x43a18
   3ea00:	ldr	x0, [x23, #0x5ac0]
   3ea04:	ldr	x1, [sp, #0x1a0]
   3ea08:	str	x0, [x1, #0x10]
   3ea0c:	ldr	x1, [x23, #0x5ac8]
   3ea10:	ldr	x2, [sp, #0x1a0]
   3ea14:	str	x1, [x2, #0x18]
   3ea18:	ldr	x2, [x23, #0x6570]
   3ea1c:	ldr	x5, [sp, #0x1a0]
   3ea20:	str	x2, [x5, #0xac0]
   3ea24:	ldr	x2, [sp, #0x1a0]
   3ea28:	str	x0, [x2, #0x10]
   3ea2c:	str	x1, [x2, #0x18]
   3ea30:	ldr	x0, [x23, #0x5c10]
   3ea34:	str	x0, [x5, #0x160]
   3ea38:	ldr	x0, [x23, #0x5c18]
   3ea3c:	ldr	x7, [sp, #0x1a0]
   3ea40:	str	x0, [x7, #0x168]
   3ea44:	ldr	x0, [x23, #0x5c20]
   3ea48:	ldr	x10, [sp, #0x1a0]
   3ea4c:	str	x0, [x10, #0x170]
   3ea50:	ldr	x0, [x23, #0x5c28]
   3ea54:	ldr	x13, [sp, #0x1a0]
   3ea58:	str	x0, [x13, #0x178]
   3ea5c:	ldr	x0, [x23, #0x5c30]
   3ea60:	ldr	x1, [sp, #0x1a0]
   3ea64:	str	x0, [x1, #0x180]
   3ea68:	ldr	x0, [x23, #0x5c38]
   3ea6c:	str	x0, [x1, #0x188]
   3ea70:	ldr	x0, [x23, #0x5c40]
   3ea74:	str	x0, [x1, #0x190]
   3ea78:	ldr	x0, [x23, #0x5c48]
   3ea7c:	str	x0, [x1, #0x198]
   3ea80:	ldr	x0, [x23, #0x5c50]
   3ea84:	str	x0, [x1, #0x1a0]
   3ea88:	ldr	x0, [x23, #0x5df8]
   3ea8c:	str	x0, [x1, #0x348]
   3ea90:	ldr	x0, [x23, #0x5e00]
   3ea94:	str	x0, [x1, #0x350]
   3ea98:	ldr	x0, [x23, #0x5e08]
   3ea9c:	str	x0, [x1, #0x358]
   3eaa0:	ldr	x0, [x23, #0x5e10]
   3eaa4:	str	x0, [x1, #0x360]
   3eaa8:	ldr	x0, [x23, #0x5e18]
   3eaac:	str	x0, [x1, #0x368]
   3eab0:	ldr	x0, [x23, #0x5e20]
   3eab4:	str	x0, [x1, #0x370]
   3eab8:	ldr	x0, [x23, #0x5e28]
   3eabc:	str	x0, [x1, #0x378]
   3eac0:	ldr	x0, [x23, #0x5e30]
   3eac4:	str	x0, [x1, #0x380]
   3eac8:	ldr	x0, [x23, #0x5e38]
   3eacc:	str	x0, [x1, #0x388]
   3ead0:	ldr	x0, [x23, #0x6128]
   3ead4:	str	x0, [x1, #0x678]
   3ead8:	ldr	x0, [x23, #0x6130]
   3eadc:	str	x0, [x1, #0x680]
   3eae0:	ldr	x0, [x23, #0x6138]
   3eae4:	str	x0, [x1, #0x688]
   3eae8:	ldr	x0, [x23, #0x6140]
   3eaec:	str	x0, [x5, #0x690]
   3eaf0:	ldr	x0, [x23, #0x6148]
   3eaf4:	str	x0, [x7, #0x698]
   3eaf8:	ldr	x0, [x23, #0x6150]
   3eafc:	str	x0, [x10, #0x6a0]
   3eb00:	ldr	x0, [x23, #0x6158]
   3eb04:	str	x0, [x13, #0x6a8]
   3eb08:	ldr	x0, [x23, #0x6160]
   3eb0c:	str	x0, [x1, #0x6b0]
   3eb10:	ldr	x0, [x23, #0x62f0]
   3eb14:	str	x0, [x1, #0x840]
   3eb18:	ldr	x0, [x23, #0x62f8]
   3eb1c:	str	x0, [x1, #0x848]
   3eb20:	ldr	x1, [x23, #0x6300]
   3eb24:	ldr	x0, [sp, #0x1a0]
   3eb28:	str	x1, [x0, #0x850]
   3eb2c:	ldr	x2, [x23, #0x6308]
   3eb30:	str	x2, [x0, #0x858]
   3eb34:	ldr	x5, [x23, #0x6310]
   3eb38:	str	x5, [x0, #0x860]
   3eb3c:	ldr	x5, [x23, #0x6318]
   3eb40:	str	x5, [x0, #0x868]
   3eb44:	ldr	x5, [x23, #0x6320]
   3eb48:	str	x5, [x0, #0x870]
   3eb4c:	ldr	x6, [x23, #0x6328]
   3eb50:	str	x6, [x0, #0x878]
   3eb54:	ldr	x7, [x23, #0x6700]
   3eb58:	str	x7, [x0, #0xc50]
   3eb5c:	ldr	x8, [x23, #0x6708]
   3eb60:	str	x8, [x0, #0xc58]
   3eb64:	ldr	x9, [x23, #0x6710]
   3eb68:	str	x9, [x0, #0xc60]
   3eb6c:	ldr	x10, [x23, #0x6718]
   3eb70:	str	x10, [x0, #0xc68]
   3eb74:	ldr	x11, [x23, #0x6720]
   3eb78:	str	x11, [x0, #0xc70]
   3eb7c:	ldr	x12, [x23, #0x6728]
   3eb80:	str	x12, [x0, #0xc78]
   3eb84:	mov	x13, #0x0
   3eb88:	str	x13, [x0, #0xc80]
   3eb8c:	ldr	x14, [x23, #0x6738]
   3eb90:	ldr	x1, [sp, #0x1a0]
   3eb94:	str	x14, [x1, #0xc88]
   3eb98:	ldr	x15, [x23, #0x6740]
   3eb9c:	ldr	x5, [sp, #0x1a0]
   3eba0:	str	x15, [x5, #0xc90]
   3eba4:	ldr	x6, [sp, #0x1a0]
   3eba8:	str	x13, [x6, #0xc98]
   3ebac:	ldr	x0, [x23, #0x6750]
   3ebb0:	ldr	x9, [sp, #0x1a0]
   3ebb4:	str	x0, [x9, #0xca0]
   3ebb8:	ldr	x0, [x23, #0x6758]
   3ebbc:	ldr	x12, [sp, #0x1a0]
   3ebc0:	str	x0, [x12, #0xca8]
   3ebc4:	ldr	x14, [sp, #0x1a0]
   3ebc8:	str	x13, [x14, #0xcb0]
   3ebcc:	ldr	x0, [x23, #0x6768]
   3ebd0:	str	x0, [x1, #0xcb8]
   3ebd4:	ldr	x0, [x23, #0x6770]
   3ebd8:	str	x0, [x1, #0xcc0]
   3ebdc:	mov	x1, #0x756
   3ebe0:	mov	x2, #-0x9
   3ebe4:	ldr	x27, [sp, #0x1b0]
   3ebe8:	ldur	x0, [sp, #0x8]
   3ebec:	mov	x5, x20
   3ebf0:	ldr	x6, [sp, #0x1a8]
   3ebf4:	blr	x27
   3ebf8:	cmp	x0, #0x0
   3ebfc:	b.ne	0x4273c
   3ec00:	mov	x0, #0x3
   3ec04:	ldr	x15, [sp, #0x198]
   3ec08:	stur	x0, [sp, #0xc0]
   3ec0c:	cmp	x15, #0x2
   3ec10:	b.lo	0x43a18
   3ec14:	mov	x5, #0x0
   3ec18:	ldr	x3, [sp, #0x1a0]
   3ec1c:	str	x5, [x3]
   3ec20:	ldr	x0, [x23, #0x2750]
   3ec24:	str	x0, [x3, #0x8]
   3ec28:	mov	x1, #0x756
   3ec2c:	ldur	x0, [sp, #0x8]
   3ec30:	ldr	x6, [sp, #0x1a8]
   3ec34:	ldr	x27, [sp, #0x1b0]
   3ec38:	mov	x4, x20
   3ec3c:	mov	x2, x5
   3ec40:	blr	x27
   3ec44:	cmp	x0, #0x0
   3ec48:	b.ne	0x42744
   3ec4c:	mov	x0, #0x3
   3ec50:	stur	x0, [sp, #0xc0]
   3ec54:	b	0x43a18
   3ec58:	mov	x1, x25
   3ec5c:	mov	x15, x5
   3ec60:	ldr	x24, [sp, #0x138]
   3ec64:	ldr	x0, [x24, x1, lsl #3]
   3ec68:	stur	x0, [sp, #0xd8]
   3ec6c:	mov	x10, #0x0
   3ec70:	ldur	x1, [sp, #0x28]
   3ec74:	ldur	x2, [sp, #0x88]
   3ec78:	stur	x10, [sp, #0x20]
   3ec7c:	cmp	x1, x2
   3ec80:	cset	x0, ls
   3ec84:	sub	x1, x2, x1
   3ec88:	cmp	x1, #0x4
   3ec8c:	cset	x5, hi
   3ec90:	mov	x1, x5
   3ec94:	and	w5, w0, w1
   3ec98:	mov	x28, x1
   3ec9c:	mov	x0, #0x1000000000000000
   3eca0:	mov	w1, #0x2646
   3eca4:	movk	w1, #0x1, lsl #16
   3eca8:	cmp	x3, x1
   3ecac:	cset	x1, hs
   3ecb0:	and	w1, w1, w5
   3ecb4:	uxtb	w1, w1
   3ecb8:	cbz	x1, 0x4274c
   3ecbc:	b	0x3f0e0
   3ecc0:	ldur	x1, [sp, #0xb8]
   3ecc4:	ldur	x2, [sp, #0xb8]
   3ecc8:	b	0x3ed3c
   3eccc:	ldur	x4, [sp, #0x60]
   3ecd0:	mov	x8, x3
   3ecd4:	b	0x3ed28
   3ecd8:	tbnz	w1, #0x0, 0x3ed0c
   3ecdc:	tbnz	w1, #0x0, 0x3ecfc
   3ece0:	mov	w4, #0x1
   3ece4:	cmp	x1, #0x0
   3ece8:	mov	x8, x28
   3ecec:	csel	x1, x8, x4, eq
   3ecf0:	ldur	x4, [sp, #0x60]
   3ecf4:	mov	x8, x3
   3ecf8:	b	0x3ed28
   3ecfc:	mov	w1, #0x1
   3ed00:	ldur	x4, [sp, #0x60]
   3ed04:	mov	x8, x3
   3ed08:	b	0x3ed28
   3ed0c:	mov	w1, #0x1
   3ed10:	ldur	x4, [sp, #0x60]
   3ed14:	mov	x8, x3
   3ed18:	b	0x3ed28
   3ed1c:	mov	w1, #0x1
   3ed20:	ldur	x4, [sp, #0x60]
   3ed24:	mov	x8, x3
   3ed28:	tbnz	w1, #0x0, 0x3f0e0
   3ed2c:	ldur	x1, [sp, #0xb8]
   3ed30:	ldur	x2, [sp, #0xb8]
   3ed34:	mov	x3, x8
   3ed38:	stur	x4, [sp, #0x60]
   3ed3c:	mov	x8, #0x0
   3ed40:	str	x8, [x23, #0x18]
   3ed44:	str	x0, [x23, #0x20]
   3ed48:	mov	x9, #0x1
   3ed4c:	str	x9, [x23, #0x30]
   3ed50:	mov	x10, #0x101010101010101
   3ed54:	str	x10, [x23, #0x38]
   3ed58:	mov	x20, #0x2
   3ed5c:	str	x20, [x23, #0x40]
   3ed60:	mov	x11, #0x3
   3ed64:	str	x11, [x23, #0x48]
   3ed68:	mov	x12, #0x4
   3ed6c:	str	x12, [x23, #0x50]
   3ed70:	stur	x12, [sp, #0xd0]
   3ed74:	mov	x13, #0xf0f0f0f0f0f0f0f
   3ed78:	str	x13, [x23, #0x78]
   3ed7c:	mov	x0, #0x3333333333333333
   3ed80:	str	x0, [x23, #0x88]
   3ed84:	mov	x0, #0x38
   3ed88:	str	x0, [x23, #0x90]
   3ed8c:	mov	x0, #0x3a
   3ed90:	str	x0, [x23, #0x98]
   3ed94:	mov	x0, #0x5555555555555555
   3ed98:	str	x0, [x23, #0xb0]
   3ed9c:	mov	x0, #0x3ffffffffffffff
   3eda0:	str	x0, [x23, #0xb8]
   3eda4:	str	x8, [x23, #0x188]
   3eda8:	str	x9, [x23, #0x190]
   3edac:	ldur	x27, [sp, #0xb8]
   3edb0:	str	x27, [x23, #0x22e0]
   3edb4:	ldr	x28, [sp, #0x190]
   3edb8:	str	x28, [x23, #0x22e8]
   3edbc:	ldur	x0, [sp, #0xf8]
   3edc0:	uxtb	w0, w0
   3edc4:	str	x0, [x23, #0x22f8]
   3edc8:	ldur	x10, [sp, #0x58]
   3edcc:	str	x10, [x23, #0x5788]
   3edd0:	str	x3, [x23, #0x5790]
   3edd4:	ldur	x4, [sp, #0x60]
   3edd8:	str	x4, [x23, #0x5798]
   3eddc:	str	x2, [x23, #0x5ac0]
   3ede0:	str	x28, [x23, #0x5ac8]
   3ede4:	str	x15, [x23, #0x6128]
   3ede8:	ldur	x15, [sp, #0xd8]
   3edec:	str	x15, [x23, #0x6130]
   3edf0:	str	x1, [x23, #0x6138]
   3edf4:	ldur	x24, [sp, #0x10]
   3edf8:	str	x24, [x23, #0x6140]
   3edfc:	ldur	x21, [sp, #0x30]
   3ee00:	str	x21, [x23, #0x6148]
   3ee04:	ldur	x24, [sp, #0x38]
   3ee08:	str	x24, [x23, #0x6150]
   3ee0c:	ldur	x22, [sp, #0x40]
   3ee10:	str	x22, [x23, #0x6158]
   3ee14:	ldur	x0, [sp, #0x48]
   3ee18:	str	x0, [x23, #0x6160]
   3ee1c:	ldur	x1, [sp, #0x28]
   3ee20:	str	x1, [x23, #0x6570]
   3ee24:	add	x0, x14, #0x1
   3ee28:	str	x0, [x23, #0x6700]
   3ee2c:	ldur	x24, [sp, #0x68]
   3ee30:	str	x24, [x23, #0x6708]
   3ee34:	ldur	x25, [sp, #0x70]
   3ee38:	str	x25, [x23, #0x6710]
   3ee3c:	ldur	x4, [sp, #0x50]
   3ee40:	sub	x1, x4, x3
   3ee44:	mov	w2, #0xc87e
   3ee48:	movk	w2, #0x1, lsl #16
   3ee4c:	msub	x0, x0, x2, x1
   3ee50:	str	x0, [x23, #0x6718]
   3ee54:	str	x8, [x23, #0x6720]
   3ee58:	str	x8, [x23, #0x6728]
   3ee5c:	ldur	x19, [sp, #0x78]
   3ee60:	str	x19, [x23, #0x6738]
   3ee64:	ldur	x26, [sp, #0x80]
   3ee68:	str	x26, [x23, #0x6740]
   3ee6c:	str	x9, [x23, #0x6750]
   3ee70:	ldur	x0, [sp, #0x20]
   3ee74:	str	x0, [x23, #0x6758]
   3ee78:	str	x7, [x23, #0x6768]
   3ee7c:	str	x6, [x23, #0x6770]
   3ee80:	ldr	x0, [x23, #0x5788]
   3ee84:	cmp	x0, #0x0
   3ee88:	b.eq	0x3f0b8
   3ee8c:	ldr	x3, [x23, #0x5790]
   3ee90:	ldr	x4, [x23, #0x5798]
   3ee94:	mov	x0, #0x0
   3ee98:	str	x0, [x23, #0x5788]
   3ee9c:	mov	x0, #0x3
   3eea0:	ldr	x15, [sp, #0x198]
   3eea4:	stur	x0, [sp, #0xc0]
   3eea8:	cmp	x15, #0x19a
   3eeac:	b.lo	0x43a18
   3eeb0:	ldr	x0, [x23, #0x5ac0]
   3eeb4:	ldr	x1, [sp, #0x1a0]
   3eeb8:	str	x0, [x1, #0x10]
   3eebc:	ldr	x1, [x23, #0x5ac8]
   3eec0:	ldr	x2, [sp, #0x1a0]
   3eec4:	str	x1, [x2, #0x18]
   3eec8:	ldr	x2, [x23, #0x6570]
   3eecc:	ldr	x5, [sp, #0x1a0]
   3eed0:	str	x2, [x5, #0xac0]
   3eed4:	ldr	x2, [sp, #0x1a0]
   3eed8:	str	x0, [x2, #0x10]
   3eedc:	str	x1, [x5, #0x18]
   3eee0:	ldr	x0, [x23, #0x5c10]
   3eee4:	ldr	x7, [sp, #0x1a0]
   3eee8:	str	x0, [x7, #0x160]
   3eeec:	ldr	x0, [x23, #0x5c18]
   3eef0:	ldr	x10, [sp, #0x1a0]
   3eef4:	str	x0, [x10, #0x168]
   3eef8:	ldr	x1, [x23, #0x5c20]
   3eefc:	ldr	x13, [sp, #0x1a0]
   3ef00:	str	x1, [x13, #0x170]
   3ef04:	ldr	x2, [x23, #0x5c28]
   3ef08:	ldr	x0, [sp, #0x1a0]
   3ef0c:	str	x2, [x0, #0x178]
   3ef10:	ldr	x5, [x23, #0x5c30]
   3ef14:	str	x5, [x0, #0x180]
   3ef18:	ldr	x5, [x23, #0x5c38]
   3ef1c:	str	x5, [x0, #0x188]
   3ef20:	ldr	x5, [x23, #0x5c40]
   3ef24:	str	x5, [x0, #0x190]
   3ef28:	ldr	x6, [x23, #0x5c48]
   3ef2c:	str	x6, [x0, #0x198]
   3ef30:	ldr	x7, [x23, #0x5c50]
   3ef34:	str	x7, [x0, #0x1a0]
   3ef38:	ldr	x8, [x23, #0x5df8]
   3ef3c:	str	x8, [x0, #0x348]
   3ef40:	ldr	x9, [x23, #0x5e00]
   3ef44:	str	x9, [x0, #0x350]
   3ef48:	ldr	x10, [x23, #0x5e08]
   3ef4c:	str	x10, [x0, #0x358]
   3ef50:	ldr	x11, [x23, #0x5e10]
   3ef54:	str	x11, [x0, #0x360]
   3ef58:	ldr	x12, [x23, #0x5e18]
   3ef5c:	str	x12, [x0, #0x368]
   3ef60:	ldr	x13, [x23, #0x5e20]
   3ef64:	str	x13, [x0, #0x370]
   3ef68:	ldr	x14, [x23, #0x5e28]
   3ef6c:	str	x14, [x0, #0x378]
   3ef70:	ldr	x15, [x23, #0x5e30]
   3ef74:	str	x15, [x0, #0x380]
   3ef78:	ldr	x0, [x23, #0x5e38]
   3ef7c:	ldr	x1, [sp, #0x1a0]
   3ef80:	str	x0, [x1, #0x388]
   3ef84:	ldr	x0, [x23, #0x6128]
   3ef88:	str	x0, [x1, #0x678]
   3ef8c:	ldr	x0, [x23, #0x6130]
   3ef90:	str	x0, [x1, #0x680]
   3ef94:	ldr	x0, [x23, #0x6138]
   3ef98:	ldr	x5, [sp, #0x1a0]
   3ef9c:	str	x0, [x5, #0x688]
   3efa0:	ldr	x0, [x23, #0x6140]
   3efa4:	ldr	x7, [sp, #0x1a0]
   3efa8:	str	x0, [x7, #0x690]
   3efac:	ldr	x0, [x23, #0x6148]
   3efb0:	ldr	x10, [sp, #0x1a0]
   3efb4:	str	x0, [x10, #0x698]
   3efb8:	ldr	x0, [x23, #0x6150]
   3efbc:	ldr	x13, [sp, #0x1a0]
   3efc0:	str	x0, [x13, #0x6a0]
   3efc4:	ldr	x0, [x23, #0x6158]
   3efc8:	str	x0, [x1, #0x6a8]
   3efcc:	ldr	x0, [x23, #0x6160]
   3efd0:	str	x0, [x1, #0x6b0]
   3efd4:	ldr	x0, [x23, #0x62f0]
   3efd8:	str	x0, [x1, #0x840]
   3efdc:	ldr	x0, [x23, #0x62f8]
   3efe0:	str	x0, [x1, #0x848]
   3efe4:	ldr	x0, [x23, #0x6300]
   3efe8:	str	x0, [x1, #0x850]
   3efec:	ldr	x0, [x23, #0x6308]
   3eff0:	str	x0, [x1, #0x858]
   3eff4:	ldr	x0, [x23, #0x6310]
   3eff8:	str	x0, [x1, #0x860]
   3effc:	ldr	x0, [x23, #0x6318]
   3f000:	str	x0, [x1, #0x868]
   3f004:	ldr	x0, [x23, #0x6320]
   3f008:	str	x0, [x1, #0x870]
   3f00c:	ldr	x0, [x23, #0x6328]
   3f010:	str	x0, [x1, #0x878]
   3f014:	ldr	x0, [x23, #0x6700]
   3f018:	str	x0, [x1, #0xc50]
   3f01c:	ldr	x0, [x23, #0x6708]
   3f020:	str	x0, [x1, #0xc58]
   3f024:	ldr	x0, [x23, #0x6710]
   3f028:	str	x0, [x1, #0xc60]
   3f02c:	ldr	x0, [x23, #0x6718]
   3f030:	str	x0, [x1, #0xc68]
   3f034:	ldr	x0, [x23, #0x6720]
   3f038:	str	x0, [x1, #0xc70]
   3f03c:	ldr	x0, [x23, #0x6728]
   3f040:	str	x0, [x1, #0xc78]
   3f044:	mov	x0, #0x0
   3f048:	str	x0, [x1, #0xc80]
   3f04c:	ldr	x1, [x23, #0x6738]
   3f050:	str	x1, [x5, #0xc88]
   3f054:	ldr	x1, [x23, #0x6740]
   3f058:	str	x1, [x7, #0xc90]
   3f05c:	ldr	x9, [sp, #0x1a0]
   3f060:	str	x0, [x9, #0xc98]
   3f064:	ldr	x1, [x23, #0x6750]
   3f068:	ldr	x12, [sp, #0x1a0]
   3f06c:	str	x1, [x12, #0xca0]
   3f070:	ldr	x1, [x23, #0x6758]
   3f074:	ldr	x15, [sp, #0x1a0]
   3f078:	str	x1, [x15, #0xca8]
   3f07c:	ldr	x1, [sp, #0x1a0]
   3f080:	str	x0, [x1, #0xcb0]
   3f084:	ldr	x0, [x23, #0x6768]
   3f088:	str	x0, [x1, #0xcb8]
   3f08c:	ldr	x0, [x23, #0x6770]
   3f090:	str	x0, [x1, #0xcc0]
   3f094:	mov	x1, #0x75e
   3f098:	mov	x2, #-0x9
   3f09c:	mov	x5, #0x1
   3f0a0:	ldur	x0, [sp, #0x8]
   3f0a4:	ldr	x6, [sp, #0x1a8]
   3f0a8:	ldr	x27, [sp, #0x1b0]
   3f0ac:	blr	x27
   3f0b0:	cmp	x0, #0x0
   3f0b4:	b.ne	0x427b0
   3f0b8:	mov	x0, #0x0
   3f0bc:	ldur	x1, [sp, #0xd0]
   3f0c0:	add	sp, sp, #0x1d0
   3f0c4:	ldp	x19, x20, [sp], #0x10
   3f0c8:	ldp	x21, x22, [sp], #0x10
   3f0cc:	ldp	x23, x24, [sp], #0x10
   3f0d0:	ldp	x25, x26, [sp], #0x10
   3f0d4:	ldp	x27, x28, [sp], #0x10
   3f0d8:	ldp	x29, x30, [sp], #0x10
   3f0dc:	.long	0xd65f0fff
   3f0e0:	ldur	x1, [sp, #0xd8]
   3f0e4:	cmp	x15, x1
   3f0e8:	cset	x4, lo
   3f0ec:	mov	x8, #0x1000000000000000
   3f0f0:	ldur	x20, [sp, #0x48]
   3f0f4:	cmp	x20, x8
   3f0f8:	cset	x8, lo
   3f0fc:	and	w4, w4, w8
   3f100:	uxtb	w19, w4
   3f104:	tbnz	w19, #0x0, 0x3f130
   3f108:	stur	x19, [sp, #0xd0]
   3f10c:	mov	w8, #0x2646
   3f110:	movk	w8, #0x1, lsl #16
   3f114:	sub	x3, x3, x8
   3f118:	ldur	x4, [sp, #0x38]
   3f11c:	ldur	x19, [sp, #0x48]
   3f120:	ldur	x21, [sp, #0x30]
   3f124:	ldur	x24, [sp, #0x40]
   3f128:	ldur	x25, [sp, #0x10]
   3f12c:	b	0x40404
   3f130:	stur	x19, [sp, #0xd0]
   3f134:	add	x9, x15, #0x1
   3f138:	cmp	x9, x15
   3f13c:	b.lo	0x427b8
   3f140:	ldr	x20, [sp, #0x120]
   3f144:	cmp	x15, x20
   3f148:	b.lo	0x3f3e0
   3f14c:	b	0x428f4
   3f150:	ldr	x3, [x23, #0x5790]
   3f154:	ldr	x4, [x23, #0x5798]
   3f158:	mov	x0, #0x0
   3f15c:	str	x0, [x23, #0x5788]
   3f160:	mov	x0, #0x3
   3f164:	ldr	x15, [sp, #0x198]
   3f168:	stur	x0, [sp, #0xc0]
   3f16c:	cmp	x15, #0x19a
   3f170:	b.lo	0x43a18
   3f174:	ldr	x0, [x23, #0x5ac0]
   3f178:	ldr	x1, [sp, #0x1a0]
   3f17c:	str	x0, [x1, #0x10]
   3f180:	ldr	x1, [x23, #0x5ac8]
   3f184:	ldr	x2, [sp, #0x1a0]
   3f188:	str	x1, [x2, #0x18]
   3f18c:	ldr	x2, [x23, #0x6570]
   3f190:	ldr	x5, [sp, #0x1a0]
   3f194:	str	x2, [x5, #0xac0]
   3f198:	ldr	x2, [sp, #0x1a0]
   3f19c:	str	x0, [x2, #0x10]
   3f1a0:	ldr	x0, [sp, #0x1a0]
   3f1a4:	str	x1, [x0, #0x18]
   3f1a8:	ldr	x0, [x23, #0x5c10]
   3f1ac:	ldr	x1, [sp, #0x1a0]
   3f1b0:	str	x0, [x1, #0x160]
   3f1b4:	ldr	x0, [x23, #0x5c18]
   3f1b8:	str	x0, [x1, #0x168]
   3f1bc:	ldr	x0, [x23, #0x5c20]
   3f1c0:	str	x0, [x1, #0x170]
   3f1c4:	ldr	x0, [x23, #0x5c28]
   3f1c8:	str	x0, [x1, #0x178]
   3f1cc:	ldr	x0, [x23, #0x5c30]
   3f1d0:	str	x0, [x1, #0x180]
   3f1d4:	ldr	x0, [x23, #0x5c38]
   3f1d8:	str	x0, [x1, #0x188]
   3f1dc:	ldr	x0, [x23, #0x5c40]
   3f1e0:	str	x0, [x1, #0x190]
   3f1e4:	ldr	x0, [x23, #0x5c48]
   3f1e8:	str	x0, [x1, #0x198]
   3f1ec:	ldr	x0, [x23, #0x5c50]
   3f1f0:	str	x0, [x1, #0x1a0]
   3f1f4:	ldr	x0, [x23, #0x5df8]
   3f1f8:	str	x0, [x5, #0x348]
   3f1fc:	ldr	x0, [x23, #0x5e00]
   3f200:	ldr	x6, [sp, #0x1a0]
   3f204:	str	x0, [x6, #0x350]
   3f208:	ldr	x1, [x23, #0x5e08]
   3f20c:	ldr	x9, [sp, #0x1a0]
   3f210:	str	x1, [x9, #0x358]
   3f214:	ldr	x2, [x23, #0x5e10]
   3f218:	ldr	x12, [sp, #0x1a0]
   3f21c:	str	x2, [x12, #0x360]
   3f220:	ldr	x5, [x23, #0x5e18]
   3f224:	ldr	x15, [sp, #0x1a0]
   3f228:	str	x5, [x15, #0x368]
   3f22c:	ldr	x5, [x23, #0x5e20]
   3f230:	ldr	x0, [sp, #0x1a0]
   3f234:	str	x5, [x0, #0x370]
   3f238:	ldr	x5, [x23, #0x5e28]
   3f23c:	str	x5, [x0, #0x378]
   3f240:	ldr	x6, [x23, #0x5e30]
   3f244:	str	x6, [x0, #0x380]
   3f248:	ldr	x7, [x23, #0x5e38]
   3f24c:	str	x7, [x0, #0x388]
   3f250:	ldr	x8, [x23, #0x6128]
   3f254:	str	x8, [x0, #0x678]
   3f258:	ldr	x9, [x23, #0x6130]
   3f25c:	str	x9, [x0, #0x680]
   3f260:	ldr	x10, [x23, #0x6138]
   3f264:	str	x10, [x0, #0x688]
   3f268:	ldr	x11, [x23, #0x6140]
   3f26c:	str	x11, [x0, #0x690]
   3f270:	ldr	x12, [x23, #0x6148]
   3f274:	str	x12, [x0, #0x698]
   3f278:	ldr	x13, [x23, #0x6150]
   3f27c:	str	x13, [x0, #0x6a0]
   3f280:	ldr	x14, [x23, #0x6158]
   3f284:	str	x14, [x0, #0x6a8]
   3f288:	ldr	x15, [x23, #0x6160]
   3f28c:	str	x15, [x0, #0x6b0]
   3f290:	ldr	x0, [x23, #0x62f0]
   3f294:	ldr	x1, [sp, #0x1a0]
   3f298:	str	x0, [x1, #0x840]
   3f29c:	ldr	x0, [x23, #0x62f8]
   3f2a0:	str	x0, [x1, #0x848]
   3f2a4:	ldr	x0, [x23, #0x6300]
   3f2a8:	str	x0, [x1, #0x850]
   3f2ac:	ldr	x0, [x23, #0x6308]
   3f2b0:	str	x0, [x1, #0x858]
   3f2b4:	ldr	x0, [x23, #0x6310]
   3f2b8:	ldr	x5, [sp, #0x1a0]
   3f2bc:	str	x0, [x5, #0x860]
   3f2c0:	ldr	x0, [x23, #0x6318]
   3f2c4:	ldr	x6, [sp, #0x1a0]
   3f2c8:	str	x0, [x6, #0x868]
   3f2cc:	ldr	x0, [x23, #0x6320]
   3f2d0:	ldr	x9, [sp, #0x1a0]
   3f2d4:	str	x0, [x9, #0x870]
   3f2d8:	ldr	x0, [x23, #0x6328]
   3f2dc:	ldr	x12, [sp, #0x1a0]
   3f2e0:	str	x0, [x12, #0x878]
   3f2e4:	ldr	x0, [x23, #0x6700]
   3f2e8:	ldr	x15, [sp, #0x1a0]
   3f2ec:	str	x0, [x15, #0xc50]
   3f2f0:	ldr	x0, [x23, #0x6708]
   3f2f4:	str	x0, [x1, #0xc58]
   3f2f8:	ldr	x0, [x23, #0x6710]
   3f2fc:	str	x0, [x1, #0xc60]
   3f300:	ldr	x0, [x23, #0x6718]
   3f304:	str	x0, [x1, #0xc68]
   3f308:	ldr	x0, [x23, #0x6720]
   3f30c:	str	x0, [x1, #0xc70]
   3f310:	ldr	x0, [x23, #0x6728]
   3f314:	str	x0, [x1, #0xc78]
   3f318:	mov	x0, #0x0
   3f31c:	str	x0, [x1, #0xc80]
   3f320:	ldr	x1, [x23, #0x6738]
   3f324:	ldr	x2, [sp, #0x1a0]
   3f328:	str	x1, [x2, #0xc88]
   3f32c:	ldr	x1, [x23, #0x6740]
   3f330:	str	x1, [x2, #0xc90]
   3f334:	ldr	x1, [sp, #0x1a0]
   3f338:	str	x0, [x1, #0xc98]
   3f33c:	ldr	x1, [x23, #0x6750]
   3f340:	str	x1, [x2, #0xca0]
   3f344:	ldr	x1, [x23, #0x6758]
   3f348:	str	x1, [x2, #0xca8]
   3f34c:	ldr	x1, [sp, #0x1a0]
   3f350:	str	x0, [x1, #0xcb0]
   3f354:	ldr	x0, [x23, #0x6768]
   3f358:	str	x0, [x1, #0xcb8]
   3f35c:	ldr	x0, [x23, #0x6770]
   3f360:	str	x0, [x1, #0xcc0]
   3f364:	mov	x1, #0x771
   3f368:	mov	x2, #-0x9
   3f36c:	ldr	x27, [sp, #0x1b0]
   3f370:	ldur	x0, [sp, #0x8]
   3f374:	mov	x5, x21
   3f378:	ldr	x6, [sp, #0x1a8]
   3f37c:	blr	x27
   3f380:	cmp	x0, #0x0
   3f384:	b.ne	0x42a74
   3f388:	mov	x0, #0x3
   3f38c:	ldr	x15, [sp, #0x198]
   3f390:	stur	x0, [sp, #0xc0]
   3f394:	cmp	x15, #0x2
   3f398:	b.lo	0x43a18
   3f39c:	mov	x5, #0x0
   3f3a0:	ldr	x3, [sp, #0x1a0]
   3f3a4:	str	x5, [x3]
   3f3a8:	ldr	x0, [x23, #0x27f8]
   3f3ac:	str	x0, [x3, #0x8]
   3f3b0:	mov	x1, #0x771
   3f3b4:	ldur	x0, [sp, #0x8]
   3f3b8:	ldr	x6, [sp, #0x1a8]
   3f3bc:	ldr	x27, [sp, #0x1b0]
   3f3c0:	mov	x4, x21
   3f3c4:	mov	x2, x5
   3f3c8:	blr	x27
   3f3cc:	cmp	x0, #0x0
   3f3d0:	b.ne	0x42a7c
   3f3d4:	mov	x0, #0x3
   3f3d8:	stur	x0, [sp, #0xc0]
   3f3dc:	b	0x43a18
   3f3e0:	ldr	x20, [sp, #0x128]
   3f3e4:	ldr	x1, [x20, x15, lsl #3]
   3f3e8:	add	x4, x1, #0x1
   3f3ec:	cmp	x4, x1
   3f3f0:	b.lo	0x42a84
   3f3f4:	ldr	x20, [sp, #0x110]
   3f3f8:	cmp	x1, x20
   3f3fc:	b.lo	0x3f688
   3f400:	b	0x42bc4
   3f404:	ldr	x3, [x23, #0x5790]
   3f408:	ldr	x4, [x23, #0x5798]
   3f40c:	mov	x0, #0x0
   3f410:	str	x0, [x23, #0x5788]
   3f414:	mov	x0, #0x3
   3f418:	ldr	x15, [sp, #0x198]
   3f41c:	stur	x0, [sp, #0xc0]
   3f420:	cmp	x15, #0x19a
   3f424:	b.lo	0x43a18
   3f428:	ldr	x0, [x23, #0x5ac0]
   3f42c:	ldr	x1, [sp, #0x1a0]
   3f430:	str	x0, [x1, #0x10]
   3f434:	ldr	x1, [x23, #0x5ac8]
   3f438:	ldr	x2, [sp, #0x1a0]
   3f43c:	str	x1, [x2, #0x18]
   3f440:	ldr	x2, [x23, #0x6570]
   3f444:	ldr	x5, [sp, #0x1a0]
   3f448:	str	x2, [x5, #0xac0]
   3f44c:	ldr	x2, [sp, #0x1a0]
   3f450:	str	x0, [x2, #0x10]
   3f454:	ldr	x0, [sp, #0x1a0]
   3f458:	str	x1, [x0, #0x18]
   3f45c:	ldr	x0, [x23, #0x5c10]
   3f460:	ldr	x1, [sp, #0x1a0]
   3f464:	str	x0, [x1, #0x160]
   3f468:	ldr	x0, [x23, #0x5c18]
   3f46c:	str	x0, [x5, #0x168]
   3f470:	ldr	x0, [x23, #0x5c20]
   3f474:	ldr	x6, [sp, #0x1a0]
   3f478:	str	x0, [x6, #0x170]
   3f47c:	ldr	x0, [x23, #0x5c28]
   3f480:	ldr	x9, [sp, #0x1a0]
   3f484:	str	x0, [x9, #0x178]
   3f488:	ldr	x0, [x23, #0x5c30]
   3f48c:	ldr	x12, [sp, #0x1a0]
   3f490:	str	x0, [x12, #0x180]
   3f494:	ldr	x0, [x23, #0x5c38]
   3f498:	ldr	x15, [sp, #0x1a0]
   3f49c:	str	x0, [x15, #0x188]
   3f4a0:	ldr	x0, [x23, #0x5c40]
   3f4a4:	str	x0, [x1, #0x190]
   3f4a8:	ldr	x0, [x23, #0x5c48]
   3f4ac:	str	x0, [x1, #0x198]
   3f4b0:	ldr	x0, [x23, #0x5c50]
   3f4b4:	str	x0, [x1, #0x1a0]
   3f4b8:	ldr	x0, [x23, #0x5df8]
   3f4bc:	str	x0, [x1, #0x348]
   3f4c0:	ldr	x0, [x23, #0x5e00]
   3f4c4:	str	x0, [x1, #0x350]
   3f4c8:	ldr	x0, [x23, #0x5e08]
   3f4cc:	str	x0, [x1, #0x358]
   3f4d0:	ldr	x0, [x23, #0x5e10]
   3f4d4:	str	x0, [x1, #0x360]
   3f4d8:	ldr	x0, [x23, #0x5e18]
   3f4dc:	str	x0, [x1, #0x368]
   3f4e0:	ldr	x0, [x23, #0x5e20]
   3f4e4:	str	x0, [x1, #0x370]
   3f4e8:	ldr	x0, [x23, #0x5e28]
   3f4ec:	str	x0, [x1, #0x378]
   3f4f0:	ldr	x0, [x23, #0x5e30]
   3f4f4:	str	x0, [x1, #0x380]
   3f4f8:	ldr	x0, [x23, #0x5e38]
   3f4fc:	str	x0, [x1, #0x388]
   3f500:	ldr	x0, [x23, #0x6128]
   3f504:	str	x0, [x1, #0x678]
   3f508:	ldr	x0, [x23, #0x6130]
   3f50c:	str	x0, [x1, #0x680]
   3f510:	ldr	x0, [x23, #0x6138]
   3f514:	str	x0, [x1, #0x688]
   3f518:	ldr	x0, [x23, #0x6140]
   3f51c:	str	x0, [x1, #0x690]
   3f520:	ldr	x0, [x23, #0x6148]
   3f524:	str	x0, [x5, #0x698]
   3f528:	ldr	x0, [x23, #0x6150]
   3f52c:	str	x0, [x6, #0x6a0]
   3f530:	ldr	x0, [x23, #0x6158]
   3f534:	str	x0, [x9, #0x6a8]
   3f538:	ldr	x0, [x23, #0x6160]
   3f53c:	str	x0, [x12, #0x6b0]
   3f540:	ldr	x0, [x23, #0x62f0]
   3f544:	str	x0, [x15, #0x840]
   3f548:	ldr	x0, [x23, #0x62f8]
   3f54c:	str	x0, [x1, #0x848]
   3f550:	ldr	x1, [x23, #0x6300]
   3f554:	ldr	x0, [sp, #0x1a0]
   3f558:	str	x1, [x0, #0x850]
   3f55c:	ldr	x2, [x23, #0x6308]
   3f560:	str	x2, [x0, #0x858]
   3f564:	ldr	x5, [x23, #0x6310]
   3f568:	str	x5, [x0, #0x860]
   3f56c:	ldr	x5, [x23, #0x6318]
   3f570:	str	x5, [x0, #0x868]
   3f574:	ldr	x5, [x23, #0x6320]
   3f578:	str	x5, [x0, #0x870]
   3f57c:	ldr	x6, [x23, #0x6328]
   3f580:	str	x6, [x0, #0x878]
   3f584:	ldr	x7, [x23, #0x6700]
   3f588:	str	x7, [x0, #0xc50]
   3f58c:	ldr	x8, [x23, #0x6708]
   3f590:	str	x8, [x0, #0xc58]
   3f594:	ldr	x9, [x23, #0x6710]
   3f598:	str	x9, [x0, #0xc60]
   3f59c:	ldr	x10, [x23, #0x6718]
   3f5a0:	str	x10, [x0, #0xc68]
   3f5a4:	ldr	x11, [x23, #0x6720]
   3f5a8:	str	x11, [x0, #0xc70]
   3f5ac:	ldr	x12, [x23, #0x6728]
   3f5b0:	str	x12, [x0, #0xc78]
   3f5b4:	mov	x13, #0x0
   3f5b8:	str	x13, [x0, #0xc80]
   3f5bc:	ldr	x14, [x23, #0x6738]
   3f5c0:	str	x14, [x0, #0xc88]
   3f5c4:	ldr	x15, [x23, #0x6740]
   3f5c8:	str	x15, [x0, #0xc90]
   3f5cc:	ldr	x2, [sp, #0x1a0]
   3f5d0:	str	x13, [x2, #0xc98]
   3f5d4:	ldr	x0, [x23, #0x6750]
   3f5d8:	ldr	x5, [sp, #0x1a0]
   3f5dc:	str	x0, [x5, #0xca0]
   3f5e0:	ldr	x0, [x23, #0x6758]
   3f5e4:	ldr	x8, [sp, #0x1a0]
   3f5e8:	str	x0, [x8, #0xca8]
   3f5ec:	ldr	x10, [sp, #0x1a0]
   3f5f0:	str	x13, [x10, #0xcb0]
   3f5f4:	ldr	x0, [x23, #0x6768]
   3f5f8:	ldr	x13, [sp, #0x1a0]
   3f5fc:	str	x0, [x13, #0xcb8]
   3f600:	ldr	x0, [x23, #0x6770]
   3f604:	ldr	x1, [sp, #0x1a0]
   3f608:	str	x0, [x1, #0xcc0]
   3f60c:	mov	x1, #0x773
   3f610:	mov	x2, #-0x9
   3f614:	ldr	x27, [sp, #0x1b0]
   3f618:	ldur	x0, [sp, #0x8]
   3f61c:	mov	x5, x21
   3f620:	ldr	x6, [sp, #0x1a8]
   3f624:	blr	x27
   3f628:	cmp	x0, #0x0
   3f62c:	b.ne	0x42d48
   3f630:	mov	x0, #0x3
   3f634:	ldr	x15, [sp, #0x198]
   3f638:	stur	x0, [sp, #0xc0]
   3f63c:	cmp	x15, #0x2
   3f640:	b.lo	0x43a18
   3f644:	mov	x5, #0x0
   3f648:	ldr	x3, [sp, #0x1a0]
   3f64c:	str	x5, [x3]
   3f650:	ldr	x0, [x23, #0x2808]
   3f654:	str	x0, [x3, #0x8]
   3f658:	mov	x1, #0x773
   3f65c:	ldur	x0, [sp, #0x8]
   3f660:	ldr	x6, [sp, #0x1a8]
   3f664:	ldr	x27, [sp, #0x1b0]
   3f668:	mov	x4, x21
   3f66c:	mov	x2, x5
   3f670:	blr	x27
   3f674:	cmp	x0, #0x0
   3f678:	b.ne	0x42d50
   3f67c:	mov	x0, #0x3
   3f680:	stur	x0, [sp, #0xc0]
   3f684:	b	0x43a18
   3f688:	ldr	x20, [sp, #0x118]
   3f68c:	ldr	x11, [x20, x1, lsl #3]
   3f690:	ldr	x20, [sp, #0x110]
   3f694:	cmp	x4, x20
   3f698:	b.lo	0x3f928
   3f69c:	b	0x42d58
   3f6a0:	ldr	x3, [x23, #0x5790]
   3f6a4:	ldr	x4, [x23, #0x5798]
   3f6a8:	mov	x0, #0x0
   3f6ac:	str	x0, [x23, #0x5788]
   3f6b0:	mov	x0, #0x3
   3f6b4:	ldr	x15, [sp, #0x198]
   3f6b8:	stur	x0, [sp, #0xc0]
   3f6bc:	cmp	x15, #0x19a
   3f6c0:	b.lo	0x43a18
   3f6c4:	ldr	x0, [x23, #0x5ac0]
   3f6c8:	ldr	x10, [sp, #0x1a0]
   3f6cc:	str	x0, [x10, #0x10]
   3f6d0:	ldr	x1, [x23, #0x5ac8]
   3f6d4:	ldr	x13, [sp, #0x1a0]
   3f6d8:	str	x1, [x13, #0x18]
   3f6dc:	ldr	x2, [x23, #0x6570]
   3f6e0:	ldr	x5, [sp, #0x1a0]
   3f6e4:	str	x2, [x5, #0xac0]
   3f6e8:	ldr	x2, [sp, #0x1a0]
   3f6ec:	str	x0, [x2, #0x10]
   3f6f0:	ldr	x0, [sp, #0x1a0]
   3f6f4:	str	x1, [x0, #0x18]
   3f6f8:	ldr	x0, [x23, #0x5c10]
   3f6fc:	ldr	x1, [sp, #0x1a0]
   3f700:	str	x0, [x1, #0x160]
   3f704:	ldr	x0, [x23, #0x5c18]
   3f708:	str	x0, [x1, #0x168]
   3f70c:	ldr	x0, [x23, #0x5c20]
   3f710:	str	x0, [x1, #0x170]
   3f714:	ldr	x0, [x23, #0x5c28]
   3f718:	str	x0, [x1, #0x178]
   3f71c:	ldr	x0, [x23, #0x5c30]
   3f720:	str	x0, [x1, #0x180]
   3f724:	ldr	x0, [x23, #0x5c38]
   3f728:	str	x0, [x1, #0x188]
   3f72c:	ldr	x0, [x23, #0x5c40]
   3f730:	str	x0, [x1, #0x190]
   3f734:	ldr	x0, [x23, #0x5c48]
   3f738:	str	x0, [x1, #0x198]
   3f73c:	ldr	x0, [x23, #0x5c50]
   3f740:	str	x0, [x1, #0x1a0]
   3f744:	ldr	x0, [x23, #0x5df8]
   3f748:	str	x0, [x1, #0x348]
   3f74c:	ldr	x0, [x23, #0x5e00]
   3f750:	str	x0, [x1, #0x350]
   3f754:	ldr	x0, [x23, #0x5e08]
   3f758:	str	x0, [x1, #0x358]
   3f75c:	ldr	x0, [x23, #0x5e10]
   3f760:	str	x0, [x1, #0x360]
   3f764:	ldr	x0, [x23, #0x5e18]
   3f768:	str	x0, [x1, #0x368]
   3f76c:	ldr	x0, [x23, #0x5e20]
   3f770:	str	x0, [x2, #0x370]
   3f774:	ldr	x0, [x23, #0x5e28]
   3f778:	str	x0, [x5, #0x378]
   3f77c:	ldr	x0, [x23, #0x5e30]
   3f780:	ldr	x8, [sp, #0x1a0]
   3f784:	str	x0, [x8, #0x380]
   3f788:	ldr	x0, [x23, #0x5e38]
   3f78c:	ldr	x11, [sp, #0x1a0]
   3f790:	str	x0, [x11, #0x388]
   3f794:	ldr	x0, [x23, #0x6128]
   3f798:	ldr	x14, [sp, #0x1a0]
   3f79c:	str	x0, [x14, #0x678]
   3f7a0:	ldr	x0, [x23, #0x6130]
   3f7a4:	str	x0, [x1, #0x680]
   3f7a8:	ldr	x0, [x23, #0x6138]
   3f7ac:	str	x0, [x1, #0x688]
   3f7b0:	ldr	x0, [x23, #0x6140]
   3f7b4:	str	x0, [x1, #0x690]
   3f7b8:	ldr	x0, [x23, #0x6148]
   3f7bc:	str	x0, [x1, #0x698]
   3f7c0:	ldr	x0, [x23, #0x6150]
   3f7c4:	str	x0, [x1, #0x6a0]
   3f7c8:	ldr	x1, [x23, #0x6158]
   3f7cc:	ldr	x0, [sp, #0x1a0]
   3f7d0:	str	x1, [x0, #0x6a8]
   3f7d4:	ldr	x2, [x23, #0x6160]
   3f7d8:	str	x2, [x0, #0x6b0]
   3f7dc:	ldr	x5, [x23, #0x62f0]
   3f7e0:	str	x5, [x0, #0x840]
   3f7e4:	ldr	x5, [x23, #0x62f8]
   3f7e8:	str	x5, [x0, #0x848]
   3f7ec:	ldr	x5, [x23, #0x6300]
   3f7f0:	str	x5, [x0, #0x850]
   3f7f4:	ldr	x6, [x23, #0x6308]
   3f7f8:	str	x6, [x0, #0x858]
   3f7fc:	ldr	x7, [x23, #0x6310]
   3f800:	str	x7, [x0, #0x860]
   3f804:	ldr	x8, [x23, #0x6318]
   3f808:	str	x8, [x0, #0x868]
   3f80c:	ldr	x9, [x23, #0x6320]
   3f810:	str	x9, [x0, #0x870]
   3f814:	ldr	x10, [x23, #0x6328]
   3f818:	str	x10, [x0, #0x878]
   3f81c:	ldr	x11, [x23, #0x6700]
   3f820:	str	x11, [x0, #0xc50]
   3f824:	ldr	x12, [x23, #0x6708]
   3f828:	ldr	x2, [sp, #0x1a0]
   3f82c:	str	x12, [x2, #0xc58]
   3f830:	ldr	x13, [x23, #0x6710]
   3f834:	ldr	x5, [sp, #0x1a0]
   3f838:	str	x13, [x5, #0xc60]
   3f83c:	ldr	x14, [x23, #0x6718]
   3f840:	ldr	x8, [sp, #0x1a0]
   3f844:	str	x14, [x8, #0xc68]
   3f848:	ldr	x15, [x23, #0x6720]
   3f84c:	ldr	x11, [sp, #0x1a0]
   3f850:	str	x15, [x11, #0xc70]
   3f854:	ldr	x0, [x23, #0x6728]
   3f858:	ldr	x14, [sp, #0x1a0]
   3f85c:	str	x0, [x14, #0xc78]
   3f860:	mov	x0, #0x0
   3f864:	ldr	x1, [sp, #0x1a0]
   3f868:	str	x0, [x1, #0xc80]
   3f86c:	ldr	x1, [x23, #0x6738]
   3f870:	str	x1, [x2, #0xc88]
   3f874:	ldr	x1, [x23, #0x6740]
   3f878:	str	x1, [x2, #0xc90]
   3f87c:	ldr	x1, [sp, #0x1a0]
   3f880:	str	x0, [x1, #0xc98]
   3f884:	ldr	x1, [x23, #0x6750]
   3f888:	str	x1, [x2, #0xca0]
   3f88c:	ldr	x1, [x23, #0x6758]
   3f890:	str	x1, [x2, #0xca8]
   3f894:	ldr	x1, [sp, #0x1a0]
   3f898:	str	x0, [x1, #0xcb0]
   3f89c:	ldr	x0, [x23, #0x6768]
   3f8a0:	str	x0, [x1, #0xcb8]
   3f8a4:	ldr	x0, [x23, #0x6770]
   3f8a8:	str	x0, [x1, #0xcc0]
   3f8ac:	mov	x1, #0x775
   3f8b0:	mov	x2, #-0x9
   3f8b4:	ldr	x27, [sp, #0x1b0]
   3f8b8:	ldur	x0, [sp, #0x8]
   3f8bc:	mov	x5, x21
   3f8c0:	ldr	x6, [sp, #0x1a8]
   3f8c4:	blr	x27
   3f8c8:	cmp	x0, #0x0
   3f8cc:	b.ne	0x42ee0
   3f8d0:	mov	x0, #0x3
   3f8d4:	ldr	x15, [sp, #0x198]
   3f8d8:	stur	x0, [sp, #0xc0]
   3f8dc:	cmp	x15, #0x2
   3f8e0:	b.lo	0x43a18
   3f8e4:	mov	x5, #0x0
   3f8e8:	ldr	x3, [sp, #0x1a0]
   3f8ec:	str	x5, [x3]
   3f8f0:	ldr	x0, [x23, #0x2818]
   3f8f4:	str	x0, [x3, #0x8]
   3f8f8:	mov	x1, #0x775
   3f8fc:	ldur	x0, [sp, #0x8]
   3f900:	ldr	x6, [sp, #0x1a8]
   3f904:	ldr	x27, [sp, #0x1b0]
   3f908:	mov	x4, x21
   3f90c:	mov	x2, x5
   3f910:	blr	x27
   3f914:	cmp	x0, #0x0
   3f918:	b.ne	0x42ee8
   3f91c:	mov	x0, #0x3
   3f920:	stur	x0, [sp, #0xc0]
   3f924:	b	0x43a18
   3f928:	ldr	x20, [sp, #0x118]
   3f92c:	ldr	x7, [x20, x4, lsl #3]
   3f930:	mov	w1, #0x2646
   3f934:	movk	w1, #0x1, lsl #16
   3f938:	sub	x6, x3, x1
   3f93c:	mov	x9, #0x0
   3f940:	mov	x8, #0x3ffffffffffffff
   3f944:	ldr	x20, [sp, #0x100]
   3f948:	stur	x8, [sp, #0xc8]
   3f94c:	cmp	x20, x7
   3f950:	b.lo	0x3f96c
   3f954:	ldur	x4, [sp, #0x38]
   3f958:	ldur	x19, [sp, #0x48]
   3f95c:	ldur	x21, [sp, #0x30]
   3f960:	ldur	x24, [sp, #0x40]
   3f964:	ldur	x25, [sp, #0x10]
   3f968:	b	0x3fe2c
   3f96c:	ldur	x4, [sp, #0x38]
   3f970:	ldur	x12, [sp, #0x48]
   3f974:	ldur	x21, [sp, #0x30]
   3f978:	ldur	x24, [sp, #0x40]
   3f97c:	ldur	x25, [sp, #0x10]
   3f980:	mov	w1, #0xcb86
   3f984:	movk	w1, #0x2, lsl #16
   3f988:	cmp	x6, x1
   3f98c:	cset	x1, hs
   3f990:	and	w1, w1, w5
   3f994:	uxtb	w1, w1
   3f998:	cbz	x1, 0x42ef0
   3f99c:	b	0x3fa40
   3f9a0:	ldur	x28, [sp, #0xb8]
   3f9a4:	ldur	x27, [sp, #0x30]
   3f9a8:	ldur	x26, [sp, #0x38]
   3f9ac:	ldur	x20, [sp, #0xb8]
   3f9b0:	mov	x19, x12
   3f9b4:	ldur	x12, [sp, #0xb8]
   3f9b8:	ldur	x10, [sp, #0x10]
   3f9bc:	ldur	x5, [sp, #0xb8]
   3f9c0:	ldur	x3, [sp, #0x48]
   3f9c4:	ldur	x2, [sp, #0x40]
   3f9c8:	mov	x1, x15
   3f9cc:	b	0x3fee0
   3f9d0:	ldur	x3, [sp, #0x60]
   3f9d4:	mov	x8, x6
   3f9d8:	b	0x3fa04
   3f9dc:	mov	w1, #0x1
   3f9e0:	cmp	x11, x7
   3f9e4:	mov	x8, x28
   3f9e8:	csel	x1, x8, x1, hs
   3f9ec:	ldur	x3, [sp, #0x60]
   3f9f0:	mov	x8, x6
   3f9f4:	b	0x3fa04
   3f9f8:	mov	x1, x28
   3f9fc:	ldur	x3, [sp, #0x60]
   3fa00:	mov	x8, x6
   3fa04:	tbnz	w1, #0x0, 0x3fa40
   3fa08:	stur	x3, [sp, #0x60]
   3fa0c:	ldur	x28, [sp, #0xb8]
   3fa10:	ldur	x27, [sp, #0x30]
   3fa14:	ldur	x26, [sp, #0x38]
   3fa18:	ldur	x20, [sp, #0xb8]
   3fa1c:	mov	x19, x12
   3fa20:	ldur	x12, [sp, #0xb8]
   3fa24:	ldur	x10, [sp, #0x10]
   3fa28:	mov	x6, x8
   3fa2c:	ldur	x5, [sp, #0xb8]
   3fa30:	ldur	x3, [sp, #0x48]
   3fa34:	ldur	x2, [sp, #0x40]
   3fa38:	mov	x1, x15
   3fa3c:	b	0x3fee0
   3fa40:	cmp	x11, x7
   3fa44:	cset	x3, lo
   3fa48:	cmp	x11, x7
   3fa4c:	b.lo	0x3fa5c
   3fa50:	mov	x10, #0x0
   3fa54:	mov	x19, x12
   3fa58:	b	0x3fcf0
   3fa5c:	ldr	x20, [sp, #0x100]
   3fa60:	cmp	x11, x20
   3fa64:	b.lo	0x3fce4
   3fa68:	b	0x42f34
   3fa6c:	ldr	x3, [x23, #0x5790]
   3fa70:	ldr	x4, [x23, #0x5798]
   3fa74:	mov	x0, #0x0
   3fa78:	str	x0, [x23, #0x5788]
   3fa7c:	mov	x0, #0x3
   3fa80:	ldr	x15, [sp, #0x198]
   3fa84:	stur	x0, [sp, #0xc0]
   3fa88:	cmp	x15, #0x19a
   3fa8c:	b.lo	0x43a18
   3fa90:	ldr	x0, [x23, #0x5ac0]
   3fa94:	ldr	x1, [sp, #0x1a0]
   3fa98:	str	x0, [x1, #0x10]
   3fa9c:	ldr	x1, [x23, #0x5ac8]
   3faa0:	ldr	x2, [sp, #0x1a0]
   3faa4:	str	x1, [x2, #0x18]
   3faa8:	ldr	x2, [x23, #0x6570]
   3faac:	ldr	x5, [sp, #0x1a0]
   3fab0:	str	x2, [x5, #0xac0]
   3fab4:	ldr	x2, [sp, #0x1a0]
   3fab8:	str	x0, [x2, #0x10]
   3fabc:	ldr	x0, [sp, #0x1a0]
   3fac0:	str	x1, [x0, #0x18]
   3fac4:	ldr	x0, [x23, #0x5c10]
   3fac8:	ldr	x1, [sp, #0x1a0]
   3facc:	str	x0, [x1, #0x160]
   3fad0:	ldr	x0, [x23, #0x5c18]
   3fad4:	str	x0, [x1, #0x168]
   3fad8:	ldr	x0, [x23, #0x5c20]
   3fadc:	str	x0, [x1, #0x170]
   3fae0:	ldr	x0, [x23, #0x5c28]
   3fae4:	str	x0, [x5, #0x178]
   3fae8:	ldr	x0, [x23, #0x5c30]
   3faec:	ldr	x7, [sp, #0x1a0]
   3faf0:	str	x0, [x7, #0x180]
   3faf4:	ldr	x0, [x23, #0x5c38]
   3faf8:	ldr	x10, [sp, #0x1a0]
   3fafc:	str	x0, [x10, #0x188]
   3fb00:	ldr	x0, [x23, #0x5c40]
   3fb04:	ldr	x13, [sp, #0x1a0]
   3fb08:	str	x0, [x13, #0x190]
   3fb0c:	ldr	x0, [x23, #0x5c48]
   3fb10:	str	x0, [x1, #0x198]
   3fb14:	ldr	x0, [x23, #0x5c50]
   3fb18:	str	x0, [x1, #0x1a0]
   3fb1c:	ldr	x0, [x23, #0x5df8]
   3fb20:	str	x0, [x1, #0x348]
   3fb24:	ldr	x0, [x23, #0x5e00]
   3fb28:	str	x0, [x1, #0x350]
   3fb2c:	ldr	x0, [x23, #0x5e08]
   3fb30:	str	x0, [x1, #0x358]
   3fb34:	ldr	x0, [x23, #0x5e10]
   3fb38:	str	x0, [x1, #0x360]
   3fb3c:	ldr	x0, [x23, #0x5e18]
   3fb40:	str	x0, [x1, #0x368]
   3fb44:	ldr	x0, [x23, #0x5e20]
   3fb48:	str	x0, [x1, #0x370]
   3fb4c:	ldr	x0, [x23, #0x5e28]
   3fb50:	str	x0, [x1, #0x378]
   3fb54:	ldr	x0, [x23, #0x5e30]
   3fb58:	str	x0, [x1, #0x380]
   3fb5c:	ldr	x0, [x23, #0x5e38]
   3fb60:	str	x0, [x1, #0x388]
   3fb64:	ldr	x0, [x23, #0x6128]
   3fb68:	str	x0, [x1, #0x678]
   3fb6c:	ldr	x0, [x23, #0x6130]
   3fb70:	str	x0, [x1, #0x680]
   3fb74:	ldr	x0, [x23, #0x6138]
   3fb78:	str	x0, [x1, #0x688]
   3fb7c:	ldr	x0, [x23, #0x6140]
   3fb80:	str	x0, [x1, #0x690]
   3fb84:	ldr	x0, [x23, #0x6148]
   3fb88:	str	x0, [x1, #0x698]
   3fb8c:	ldr	x0, [x23, #0x6150]
   3fb90:	str	x0, [x1, #0x6a0]
   3fb94:	ldr	x0, [x23, #0x6158]
   3fb98:	str	x0, [x5, #0x6a8]
   3fb9c:	ldr	x0, [x23, #0x6160]
   3fba0:	str	x0, [x7, #0x6b0]
   3fba4:	ldr	x0, [x23, #0x62f0]
   3fba8:	str	x0, [x10, #0x840]
   3fbac:	ldr	x0, [x23, #0x62f8]
   3fbb0:	str	x0, [x13, #0x848]
   3fbb4:	ldr	x1, [x23, #0x6300]
   3fbb8:	ldr	x0, [sp, #0x1a0]
   3fbbc:	str	x1, [x0, #0x850]
   3fbc0:	ldr	x2, [x23, #0x6308]
   3fbc4:	str	x2, [x0, #0x858]
   3fbc8:	ldr	x5, [x23, #0x6310]
   3fbcc:	str	x5, [x0, #0x860]
   3fbd0:	ldr	x5, [x23, #0x6318]
   3fbd4:	str	x5, [x0, #0x868]
   3fbd8:	ldr	x5, [x23, #0x6320]
   3fbdc:	str	x5, [x0, #0x870]
   3fbe0:	ldr	x6, [x23, #0x6328]
   3fbe4:	str	x6, [x0, #0x878]
   3fbe8:	ldr	x7, [x23, #0x6700]
   3fbec:	str	x7, [x0, #0xc50]
   3fbf0:	ldr	x8, [x23, #0x6708]
   3fbf4:	str	x8, [x0, #0xc58]
   3fbf8:	ldr	x9, [x23, #0x6710]
   3fbfc:	str	x9, [x0, #0xc60]
   3fc00:	ldr	x10, [x23, #0x6718]
   3fc04:	str	x10, [x0, #0xc68]
   3fc08:	ldr	x11, [x23, #0x6720]
   3fc0c:	str	x11, [x0, #0xc70]
   3fc10:	ldr	x12, [x23, #0x6728]
   3fc14:	str	x12, [x0, #0xc78]
   3fc18:	mov	x13, #0x0
   3fc1c:	str	x13, [x0, #0xc80]
   3fc20:	ldr	x14, [x23, #0x6738]
   3fc24:	str	x14, [x0, #0xc88]
   3fc28:	ldr	x15, [x23, #0x6740]
   3fc2c:	str	x15, [x0, #0xc90]
   3fc30:	str	x13, [x0, #0xc98]
   3fc34:	ldr	x0, [x23, #0x6750]
   3fc38:	ldr	x1, [sp, #0x1a0]
   3fc3c:	str	x0, [x1, #0xca0]
   3fc40:	ldr	x0, [x23, #0x6758]
   3fc44:	ldr	x5, [sp, #0x1a0]
   3fc48:	str	x0, [x5, #0xca8]
   3fc4c:	str	x13, [x5, #0xcb0]
   3fc50:	ldr	x0, [x23, #0x6768]
   3fc54:	ldr	x8, [sp, #0x1a0]
   3fc58:	str	x0, [x8, #0xcb8]
   3fc5c:	ldr	x0, [x23, #0x6770]
   3fc60:	ldr	x11, [sp, #0x1a0]
   3fc64:	str	x0, [x11, #0xcc0]
   3fc68:	mov	x1, #0x78d
   3fc6c:	mov	x2, #-0x9
   3fc70:	ldr	x27, [sp, #0x1b0]
   3fc74:	ldur	x0, [sp, #0x8]
   3fc78:	mov	x5, x22
   3fc7c:	ldr	x6, [sp, #0x1a8]
   3fc80:	blr	x27
   3fc84:	cmp	x0, #0x0
   3fc88:	b.ne	0x430f4
   3fc8c:	mov	x0, #0x3
   3fc90:	ldr	x15, [sp, #0x198]
   3fc94:	stur	x0, [sp, #0xc0]
   3fc98:	cmp	x15, #0x2
   3fc9c:	b.lo	0x43a18
   3fca0:	mov	x5, #0x0
   3fca4:	ldr	x3, [sp, #0x1a0]
   3fca8:	str	x5, [x3]
   3fcac:	ldr	x0, [x23, #0x28a8]
   3fcb0:	str	x0, [x3, #0x8]
   3fcb4:	mov	x1, #0x78d
   3fcb8:	ldur	x0, [sp, #0x8]
   3fcbc:	ldr	x6, [sp, #0x1a8]
   3fcc0:	ldr	x27, [sp, #0x1b0]
   3fcc4:	mov	x4, x22
   3fcc8:	mov	x2, x5
   3fccc:	blr	x27
   3fcd0:	cmp	x0, #0x0
   3fcd4:	b.ne	0x430fc
   3fcd8:	mov	x0, #0x3
   3fcdc:	stur	x0, [sp, #0xc0]
   3fce0:	b	0x43a18
   3fce4:	mov	x19, x12
   3fce8:	ldr	x20, [sp, #0x108]
   3fcec:	ldr	x10, [x20, x11, lsl #3]
   3fcf0:	mov	x8, #0x3ffffffffffffff
   3fcf4:	eor	x26, x10, #0x3ffffffffffffff
   3fcf8:	orr	x1, x26, #0xc00000000000000
   3fcfc:	cmp	x1, x19
   3fd00:	cset	x1, hi
   3fd04:	and	w1, w3, w1
   3fd08:	uxtb	w3, w1
   3fd0c:	tbnz	w3, #0x0, 0x3fd28
   3fd10:	mov	x1, x25
   3fd14:	mov	x10, x21
   3fd18:	mov	x12, x4
   3fd1c:	mov	x20, x24
   3fd20:	mov	x26, x19
   3fd24:	b	0x3fde0
   3fd28:	ldur	x1, [sp, #0xb8]
   3fd2c:	cmp	x10, x1
   3fd30:	b.ne	0x3fd4c
   3fd34:	mov	x1, x25
   3fd38:	mov	x10, x21
   3fd3c:	mov	x12, x4
   3fd40:	mov	x20, x24
   3fd44:	mov	x26, x19
   3fd48:	b	0x3fde0
   3fd4c:	and	x12, x25, #0x3ffffffffffffff
   3fd50:	eor	x10, x10, #0x3ffffffffffffff
   3fd54:	cmp	x10, x12
   3fd58:	cset	x12, ne
   3fd5c:	and	x1, x21, #0x3ffffffffffffff
   3fd60:	cmp	x10, x1
   3fd64:	cset	x1, ne
   3fd68:	and	w12, w12, w1
   3fd6c:	and	x1, x4, #0x3ffffffffffffff
   3fd70:	cmp	x10, x1
   3fd74:	cset	x1, ne
   3fd78:	and	w1, w12, w1
   3fd7c:	and	x12, x24, #0x3ffffffffffffff
   3fd80:	cmp	x10, x12
   3fd84:	cset	x10, ne
   3fd88:	and	w1, w1, w10
   3fd8c:	uxtb	w1, w1
   3fd90:	tbnz	w1, #0x0, 0x3fdac
   3fd94:	mov	x1, x25
   3fd98:	mov	x10, x21
   3fd9c:	mov	x12, x4
   3fda0:	mov	x20, x24
   3fda4:	mov	x26, x19
   3fda8:	b	0x3fde0
   3fdac:	orr	x10, x26, #0xc00000000000000
   3fdb0:	cmp	x10, x25
   3fdb4:	csel	x1, x10, x25, hi
   3fdb8:	csel	x12, x10, x25, lo
   3fdbc:	cmp	x12, x21
   3fdc0:	csel	x10, x12, x21, hi
   3fdc4:	csel	x20, x12, x21, lo
   3fdc8:	cmp	x20, x4
   3fdcc:	csel	x12, x20, x4, hi
   3fdd0:	csel	x26, x20, x4, lo
   3fdd4:	cmp	x26, x24
   3fdd8:	csel	x20, x26, x24, hi
   3fddc:	csel	x26, x26, x24, lo
   3fde0:	tbnz	w3, #0x0, 0x3fdf4
   3fde4:	mov	w1, #0xcb86
   3fde8:	movk	w1, #0x2, lsl #16
   3fdec:	sub	x3, x6, x1
   3fdf0:	b	0x403f8
   3fdf4:	add	x3, x11, #0x1
   3fdf8:	cmp	x3, x11
   3fdfc:	b.lo	0x43104
   3fe00:	mov	w4, #0xcb86
   3fe04:	movk	w4, #0x2, lsl #16
   3fe08:	sub	x6, x6, x4
   3fe0c:	mov	x9, #0x1
   3fe10:	mov	x25, x1
   3fe14:	mov	x24, x20
   3fe18:	mov	x21, x10
   3fe1c:	mov	x11, x3
   3fe20:	mov	x4, x12
   3fe24:	mov	x12, x26
   3fe28:	b	0x3f980
   3fe2c:	mov	w1, #0xcb86
   3fe30:	movk	w1, #0x2, lsl #16
   3fe34:	cmp	x6, x1
   3fe38:	cset	x1, hs
   3fe3c:	and	w1, w1, w5
   3fe40:	uxtb	w1, w1
   3fe44:	cbz	x1, 0x4324c
   3fe48:	b	0x402dc
   3fe4c:	mov	x1, x15
   3fe50:	ldur	x2, [sp, #0x40]
   3fe54:	ldur	x3, [sp, #0x48]
   3fe58:	ldur	x5, [sp, #0xb8]
   3fe5c:	ldur	x10, [sp, #0x10]
   3fe60:	ldur	x12, [sp, #0xb8]
   3fe64:	ldur	x20, [sp, #0xb8]
   3fe68:	ldur	x26, [sp, #0x38]
   3fe6c:	ldur	x27, [sp, #0x30]
   3fe70:	ldur	x28, [sp, #0xb8]
   3fe74:	b	0x3fee0
   3fe78:	ldur	x3, [sp, #0x60]
   3fe7c:	mov	x8, x6
   3fe80:	b	0x3feac
   3fe84:	mov	w3, #0x1
   3fe88:	cmp	x11, x7
   3fe8c:	mov	x8, x28
   3fe90:	csel	x1, x8, x3, hs
   3fe94:	ldur	x3, [sp, #0x60]
   3fe98:	mov	x8, x6
   3fe9c:	b	0x3feac
   3fea0:	mov	x1, x28
   3fea4:	ldur	x3, [sp, #0x60]
   3fea8:	mov	x8, x6
   3feac:	tbnz	w1, #0x0, 0x402dc
   3feb0:	stur	x3, [sp, #0x60]
   3feb4:	ldur	x28, [sp, #0xb8]
   3feb8:	ldur	x27, [sp, #0x30]
   3febc:	ldur	x26, [sp, #0x38]
   3fec0:	ldur	x20, [sp, #0xb8]
   3fec4:	ldur	x12, [sp, #0xb8]
   3fec8:	ldur	x10, [sp, #0x10]
   3fecc:	mov	x6, x8
   3fed0:	ldur	x5, [sp, #0xb8]
   3fed4:	ldur	x3, [sp, #0x48]
   3fed8:	ldur	x2, [sp, #0x40]
   3fedc:	mov	x1, x15
   3fee0:	mov	x8, #0x0
   3fee4:	str	x8, [x23, #0x18]
   3fee8:	str	x0, [x23, #0x20]
   3feec:	mov	x13, #0x1
   3fef0:	str	x13, [x23, #0x30]
   3fef4:	mov	x0, #0x101010101010101
   3fef8:	str	x0, [x23, #0x38]
   3fefc:	mov	x22, #0x2
   3ff00:	str	x22, [x23, #0x40]
   3ff04:	mov	x0, #0x3
   3ff08:	str	x0, [x23, #0x48]
   3ff0c:	mov	x0, #0x4
   3ff10:	str	x0, [x23, #0x50]
   3ff14:	mov	x0, #0xf0f0f0f0f0f0f0f
   3ff18:	str	x0, [x23, #0x78]
   3ff1c:	mov	x0, #0x3333333333333333
   3ff20:	str	x0, [x23, #0x88]
   3ff24:	mov	x0, #0x38
   3ff28:	str	x0, [x23, #0x90]
   3ff2c:	mov	x0, #0x3a
   3ff30:	str	x0, [x23, #0x98]
   3ff34:	mov	x0, #0x5555555555555555
   3ff38:	str	x0, [x23, #0xb0]
   3ff3c:	ldur	x0, [sp, #0xc8]
   3ff40:	str	x0, [x23, #0xb8]
   3ff44:	str	x8, [x23, #0x188]
   3ff48:	str	x13, [x23, #0x190]
   3ff4c:	ldur	x0, [sp, #0xb8]
   3ff50:	str	x0, [x23, #0x22e0]
   3ff54:	ldr	x0, [sp, #0x190]
   3ff58:	str	x0, [x23, #0x22e8]
   3ff5c:	ldur	x0, [sp, #0xf8]
   3ff60:	uxtb	w0, w0
   3ff64:	str	x0, [x23, #0x22f8]
   3ff68:	str	x15, [x23, #0x27b0]
   3ff6c:	ldur	x15, [sp, #0xd8]
   3ff70:	str	x15, [x23, #0x27b8]
   3ff74:	str	x12, [x23, #0x27c0]
   3ff78:	ldur	x0, [sp, #0xd0]
   3ff7c:	str	x0, [x23, #0x27e8]
   3ff80:	ldur	x0, [sp, #0x58]
   3ff84:	str	x0, [x23, #0x5788]
   3ff88:	str	x6, [x23, #0x5790]
   3ff8c:	ldur	x0, [sp, #0x60]
   3ff90:	str	x0, [x23, #0x5798]
   3ff94:	str	x28, [x23, #0x5ac0]
   3ff98:	ldr	x28, [sp, #0x190]
   3ff9c:	str	x28, [x23, #0x5ac8]
   3ffa0:	str	x1, [x23, #0x6128]
   3ffa4:	str	x15, [x23, #0x6130]
   3ffa8:	str	x20, [x23, #0x6138]
   3ffac:	ldur	x0, [sp, #0x10]
   3ffb0:	str	x0, [x23, #0x6140]
   3ffb4:	ldur	x0, [sp, #0x30]
   3ffb8:	str	x0, [x23, #0x6148]
   3ffbc:	ldur	x0, [sp, #0x38]
   3ffc0:	str	x0, [x23, #0x6150]
   3ffc4:	ldur	x0, [sp, #0x40]
   3ffc8:	str	x0, [x23, #0x6158]
   3ffcc:	ldur	x20, [sp, #0x48]
   3ffd0:	str	x20, [x23, #0x6160]
   3ffd4:	str	x10, [x23, #0x61d0]
   3ffd8:	str	x27, [x23, #0x61d8]
   3ffdc:	str	x26, [x23, #0x61e0]
   3ffe0:	str	x2, [x23, #0x61e8]
   3ffe4:	str	x3, [x23, #0x61f0]
   3ffe8:	str	x11, [x23, #0x62f0]
   3ffec:	str	x7, [x23, #0x62f8]
   3fff0:	str	x5, [x23, #0x6300]
   3fff4:	str	x25, [x23, #0x6308]
   3fff8:	str	x21, [x23, #0x6310]
   3fffc:	str	x4, [x23, #0x6318]
   40000:	str	x24, [x23, #0x6320]
   40004:	str	x19, [x23, #0x6328]
   40008:	ldur	x1, [sp, #0x28]
   4000c:	str	x1, [x23, #0x6570]
   40010:	add	x0, x14, #0x1
   40014:	str	x0, [x23, #0x6700]
   40018:	ldur	x24, [sp, #0x68]
   4001c:	str	x24, [x23, #0x6708]
   40020:	ldur	x25, [sp, #0x70]
   40024:	str	x25, [x23, #0x6710]
   40028:	ldur	x4, [sp, #0x50]
   4002c:	sub	x1, x4, x6
   40030:	mov	w2, #0xc87e
   40034:	movk	w2, #0x1, lsl #16
   40038:	msub	x0, x0, x2, x1
   4003c:	str	x0, [x23, #0x6718]
   40040:	str	x8, [x23, #0x6720]
   40044:	str	x8, [x23, #0x6728]
   40048:	ldur	x19, [sp, #0x78]
   4004c:	str	x19, [x23, #0x6738]
   40050:	ldur	x26, [sp, #0x80]
   40054:	str	x26, [x23, #0x6740]
   40058:	str	x13, [x23, #0x6750]
   4005c:	ldur	x6, [sp, #0x20]
   40060:	str	x6, [x23, #0x6758]
   40064:	str	x13, [x23, #0x6768]
   40068:	str	x9, [x23, #0x6770]
   4006c:	ldr	x6, [x23, #0x5788]
   40070:	cmp	x6, #0x0
   40074:	b.eq	0x402b4
   40078:	ldr	x3, [x23, #0x5790]
   4007c:	ldr	x4, [x23, #0x5798]
   40080:	mov	x9, #0x0
   40084:	str	x9, [x23, #0x5788]
   40088:	mov	x0, #0x3
   4008c:	ldr	x15, [sp, #0x198]
   40090:	stur	x0, [sp, #0xc0]
   40094:	cmp	x15, #0x19a
   40098:	b.lo	0x43a18
   4009c:	ldr	x13, [x23, #0x5ac0]
   400a0:	ldr	x0, [sp, #0x1a0]
   400a4:	str	x13, [x0, #0x10]
   400a8:	ldr	x14, [x23, #0x5ac8]
   400ac:	str	x14, [x0, #0x18]
   400b0:	ldr	x15, [x23, #0x6570]
   400b4:	str	x15, [x0, #0xac0]
   400b8:	ldr	x0, [x23, #0x61d0]
   400bc:	ldr	x1, [sp, #0x1a0]
   400c0:	str	x0, [x1, #0x720]
   400c4:	ldr	x0, [x23, #0x61d8]
   400c8:	str	x0, [x1, #0x728]
   400cc:	ldr	x0, [x23, #0x61e0]
   400d0:	str	x0, [x1, #0x730]
   400d4:	ldr	x0, [x23, #0x61e8]
   400d8:	str	x0, [x1, #0x738]
   400dc:	ldr	x0, [x23, #0x61f0]
   400e0:	ldr	x5, [sp, #0x1a0]
   400e4:	str	x0, [x5, #0x740]
   400e8:	ldr	x6, [sp, #0x1a0]
   400ec:	str	x13, [x6, #0x10]
   400f0:	ldr	x8, [sp, #0x1a0]
   400f4:	str	x14, [x8, #0x18]
   400f8:	ldr	x0, [x23, #0x5c10]
   400fc:	ldr	x11, [sp, #0x1a0]
   40100:	str	x0, [x11, #0x160]
   40104:	ldr	x0, [x23, #0x5c18]
   40108:	ldr	x14, [sp, #0x1a0]
   4010c:	str	x0, [x14, #0x168]
   40110:	ldr	x0, [x23, #0x5c20]
   40114:	str	x0, [x1, #0x170]
   40118:	ldr	x0, [x23, #0x5c28]
   4011c:	str	x0, [x1, #0x178]
   40120:	ldr	x0, [x23, #0x5c30]
   40124:	str	x0, [x1, #0x180]
   40128:	ldr	x0, [x23, #0x5c38]
   4012c:	str	x0, [x1, #0x188]
   40130:	ldr	x0, [x23, #0x5c40]
   40134:	str	x0, [x1, #0x190]
   40138:	ldr	x0, [x23, #0x5c48]
   4013c:	str	x0, [x1, #0x198]
   40140:	ldr	x0, [x23, #0x5c50]
   40144:	str	x0, [x1, #0x1a0]
   40148:	ldr	x0, [x23, #0x5df8]
   4014c:	str	x0, [x1, #0x348]
   40150:	ldr	x0, [x23, #0x5e00]
   40154:	str	x0, [x1, #0x350]
   40158:	ldr	x0, [x23, #0x5e08]
   4015c:	str	x0, [x1, #0x358]
   40160:	ldr	x0, [x23, #0x5e10]
   40164:	str	x0, [x1, #0x360]
   40168:	ldr	x0, [x23, #0x5e18]
   4016c:	str	x0, [x1, #0x368]
   40170:	ldr	x0, [x23, #0x5e20]
   40174:	str	x0, [x1, #0x370]
   40178:	ldr	x0, [x23, #0x5e28]
   4017c:	str	x0, [x1, #0x378]
   40180:	ldr	x0, [x23, #0x5e30]
   40184:	str	x0, [x1, #0x380]
   40188:	ldr	x0, [x23, #0x5e38]
   4018c:	str	x0, [x1, #0x388]
   40190:	ldr	x0, [x23, #0x6128]
   40194:	ldr	x2, [sp, #0x1a0]
   40198:	str	x0, [x2, #0x678]
   4019c:	ldr	x0, [x23, #0x6130]
   401a0:	str	x0, [x5, #0x680]
   401a4:	ldr	x0, [x23, #0x6138]
   401a8:	str	x0, [x8, #0x688]
   401ac:	ldr	x0, [x23, #0x6140]
   401b0:	str	x0, [x11, #0x690]
   401b4:	ldr	x0, [x23, #0x6148]
   401b8:	str	x0, [x14, #0x698]
   401bc:	ldr	x0, [x23, #0x6150]
   401c0:	str	x0, [x1, #0x6a0]
   401c4:	ldr	x0, [x23, #0x6158]
   401c8:	str	x0, [x1, #0x6a8]
   401cc:	ldr	x0, [x23, #0x6160]
   401d0:	str	x0, [x1, #0x6b0]
   401d4:	ldr	x0, [x23, #0x62f0]
   401d8:	str	x0, [x1, #0x840]
   401dc:	ldr	x0, [x23, #0x62f8]
   401e0:	str	x0, [x1, #0x848]
   401e4:	ldr	x0, [x23, #0x6300]
   401e8:	str	x0, [x1, #0x850]
   401ec:	ldr	x0, [x23, #0x6308]
   401f0:	str	x0, [x1, #0x858]
   401f4:	ldr	x0, [x23, #0x6310]
   401f8:	str	x0, [x1, #0x860]
   401fc:	ldr	x0, [x23, #0x6318]
   40200:	str	x0, [x1, #0x868]
   40204:	ldr	x0, [x23, #0x6320]
   40208:	str	x0, [x1, #0x870]
   4020c:	ldr	x0, [x23, #0x6328]
   40210:	str	x0, [x1, #0x878]
   40214:	ldr	x0, [x23, #0x6700]
   40218:	str	x0, [x1, #0xc50]
   4021c:	ldr	x0, [x23, #0x6708]
   40220:	str	x0, [x1, #0xc58]
   40224:	ldr	x0, [x23, #0x6710]
   40228:	str	x0, [x1, #0xc60]
   4022c:	ldr	x0, [x23, #0x6718]
   40230:	str	x0, [x1, #0xc68]
   40234:	ldr	x0, [x23, #0x6720]
   40238:	str	x0, [x1, #0xc70]
   4023c:	ldr	x0, [x23, #0x6728]
   40240:	str	x0, [x2, #0xc78]
   40244:	mov	x0, #0x0
   40248:	str	x0, [x5, #0xc80]
   4024c:	ldr	x1, [x23, #0x6738]
   40250:	str	x1, [x8, #0xc88]
   40254:	ldr	x2, [x23, #0x6740]
   40258:	str	x2, [x11, #0xc90]
   4025c:	ldr	x13, [sp, #0x1a0]
   40260:	str	x0, [x13, #0xc98]
   40264:	ldr	x5, [x23, #0x6750]
   40268:	ldr	x1, [sp, #0x1a0]
   4026c:	str	x5, [x1, #0xca0]
   40270:	ldr	x5, [x23, #0x6758]
   40274:	str	x5, [x1, #0xca8]
   40278:	str	x0, [x1, #0xcb0]
   4027c:	ldr	x7, [x23, #0x6768]
   40280:	ldr	x0, [sp, #0x1a0]
   40284:	str	x7, [x0, #0xcb8]
   40288:	ldr	x8, [x23, #0x6770]
   4028c:	str	x8, [x0, #0xcc0]
   40290:	mov	x1, #0x77d
   40294:	mov	x2, #-0x9
   40298:	mov	x5, #0x1
   4029c:	ldur	x0, [sp, #0x8]
   402a0:	ldr	x6, [sp, #0x1a8]
   402a4:	ldr	x27, [sp, #0x1b0]
   402a8:	blr	x27
   402ac:	cmp	x0, #0x0
   402b0:	b.ne	0x43290
   402b4:	mov	x0, #0x0
   402b8:	mov	x1, #0x5
   402bc:	add	sp, sp, #0x1d0
   402c0:	ldp	x19, x20, [sp], #0x10
   402c4:	ldp	x21, x22, [sp], #0x10
   402c8:	ldp	x23, x24, [sp], #0x10
   402cc:	ldp	x25, x26, [sp], #0x10
   402d0:	ldp	x27, x28, [sp], #0x10
   402d4:	ldp	x29, x30, [sp], #0x10
   402d8:	.long	0xd65f0fff
   402dc:	cmp	x11, x7
   402e0:	cset	x1, lo
   402e4:	cmp	x11, x7
   402e8:	b.lo	0x402f4
   402ec:	mov	x10, #0x0
   402f0:	b	0x402fc
   402f4:	ldr	x3, [sp, #0x108]
   402f8:	ldr	x10, [x3, x11, lsl #3]
   402fc:	eor	x8, x10, #0x3ffffffffffffff
   40300:	orr	x3, x8, #0xc00000000000000
   40304:	cmp	x3, x19
   40308:	cset	x3, hi
   4030c:	and	w1, w1, w3
   40310:	uxtb	w3, w1
   40314:	tbnz	w3, #0x0, 0x40330
   40318:	mov	x1, x25
   4031c:	mov	x10, x21
   40320:	mov	x12, x4
   40324:	mov	x20, x24
   40328:	mov	x26, x19
   4032c:	b	0x403e8
   40330:	ldur	x1, [sp, #0xb8]
   40334:	cmp	x10, x1
   40338:	b.ne	0x40354
   4033c:	mov	x1, x25
   40340:	mov	x10, x21
   40344:	mov	x12, x4
   40348:	mov	x20, x24
   4034c:	mov	x26, x19
   40350:	b	0x403e8
   40354:	and	x12, x25, #0x3ffffffffffffff
   40358:	eor	x10, x10, #0x3ffffffffffffff
   4035c:	cmp	x10, x12
   40360:	cset	x12, ne
   40364:	and	x1, x21, #0x3ffffffffffffff
   40368:	cmp	x10, x1
   4036c:	cset	x1, ne
   40370:	and	w12, w12, w1
   40374:	and	x1, x4, #0x3ffffffffffffff
   40378:	cmp	x10, x1
   4037c:	cset	x1, ne
   40380:	and	w12, w12, w1
   40384:	and	x1, x24, #0x3ffffffffffffff
   40388:	cmp	x10, x1
   4038c:	cset	x1, ne
   40390:	and	w12, w12, w1
   40394:	uxtb	w12, w12
   40398:	tbnz	w12, #0x0, 0x403b4
   4039c:	mov	x1, x25
   403a0:	mov	x10, x21
   403a4:	mov	x12, x4
   403a8:	mov	x20, x24
   403ac:	mov	x26, x19
   403b0:	b	0x403e8
   403b4:	orr	x8, x8, #0xc00000000000000
   403b8:	cmp	x8, x25
   403bc:	csel	x1, x8, x25, hi
   403c0:	csel	x8, x8, x25, lo
   403c4:	cmp	x8, x21
   403c8:	csel	x10, x8, x21, hi
   403cc:	csel	x8, x8, x21, lo
   403d0:	cmp	x8, x4
   403d4:	csel	x12, x8, x4, hi
   403d8:	csel	x8, x8, x4, lo
   403dc:	cmp	x8, x24
   403e0:	csel	x20, x8, x24, hi
   403e4:	csel	x26, x8, x24, lo
   403e8:	tbnz	w3, #0x0, 0x40e54
   403ec:	mov	w1, #0xcb86
   403f0:	movk	w1, #0x2, lsl #16
   403f4:	sub	x3, x6, x1
   403f8:	tbnz	w13, #0x3, 0x43298
   403fc:	mov	x7, #0x0
   40400:	mov	x6, x7
   40404:	ldur	x1, [sp, #0xd0]
   40408:	tbnz	w1, #0x0, 0x40e20
   4040c:	tbnz	w13, #0x2, 0x432e4
   40410:	mov	x20, #0x0
   40414:	mov	x11, x20
   40418:	mov	x12, x20
   4041c:	mov	x15, x20
   40420:	ldur	x21, [sp, #0xb8]
   40424:	ldur	x24, [sp, #0xb8]
   40428:	ldur	x0, [sp, #0xb8]
   4042c:	ldr	x28, [sp, #0x190]
   40430:	cmp	x0, x28
   40434:	b.lo	0x40444
   40438:	add	x14, x14, #0x1
   4043c:	ldur	x8, [sp, #0x90]
   40440:	b	0x40cd0
   40444:	cbnz	x27, 0x405e4
   40448:	b	0x43330
   4044c:	ldr	x8, [sp, #0x1a0]
   40450:	str	x21, [x8, #0x10]
   40454:	ldr	x10, [sp, #0x1a0]
   40458:	str	x28, [x10, #0x18]
   4045c:	ldr	x13, [sp, #0x1a0]
   40460:	str	x21, [x13, #0x10]
   40464:	ldr	x0, [sp, #0x1a0]
   40468:	str	x28, [x0, #0x18]
   4046c:	mov	x5, #0x1
   40470:	add	x8, x14, #0x1
   40474:	str	x8, [x0, #0xc50]
   40478:	ldur	x0, [sp, #0x68]
   4047c:	ldr	x1, [sp, #0x1a0]
   40480:	str	x0, [x1, #0xc58]
   40484:	ldr	x0, [sp, #0x1a0]
   40488:	ldur	x25, [sp, #0x70]
   4048c:	str	x25, [x0, #0xc60]
   40490:	ldur	x4, [sp, #0x50]
   40494:	sub	x9, x4, x3
   40498:	mov	w10, #0xc87e
   4049c:	movk	w10, #0x1, lsl #16
   404a0:	msub	x9, x8, x10, x9
   404a4:	str	x9, [x0, #0xc68]
   404a8:	str	x20, [x0, #0xc70]
   404ac:	str	x15, [x0, #0xc78]
   404b0:	mov	x13, #0x0
   404b4:	str	x13, [x0, #0xc80]
   404b8:	ldur	x19, [sp, #0x78]
   404bc:	str	x19, [x0, #0xc88]
   404c0:	ldur	x26, [sp, #0x80]
   404c4:	str	x26, [x0, #0xc90]
   404c8:	str	x13, [x0, #0xc98]
   404cc:	str	x12, [x0, #0xca0]
   404d0:	str	x11, [x0, #0xca8]
   404d4:	str	x13, [x0, #0xcb0]
   404d8:	str	x7, [x0, #0xcb8]
   404dc:	str	x6, [x0, #0xcc0]
   404e0:	ldur	x1, [sp, #0x28]
   404e4:	add	x0, x1, #0x1
   404e8:	ldr	x1, [sp, #0x1a0]
   404ec:	str	x0, [x1, #0xcd0]
   404f0:	ldur	x12, [sp, #0x10]
   404f4:	and	x0, x12, #0x3ffffffffffffff
   404f8:	eor	x0, x0, #0x3ffffffffffffff
   404fc:	str	x0, [x1, #0xcd8]
   40500:	mov	x1, #0x830
   40504:	mov	x2, #-0x1b
   40508:	ldur	x4, [sp, #0x60]
   4050c:	ldr	x27, [sp, #0x1b0]
   40510:	ldur	x0, [sp, #0x8]
   40514:	ldr	x6, [sp, #0x1a8]
   40518:	blr	x27
   4051c:	mov	x1, #0x2
   40520:	stur	x1, [sp, #0xc0]
   40524:	cmp	x0, #0x0
   40528:	b.ne	0x43a18
   4052c:	ldr	x3, [sp, #0x1a0]
   40530:	ldr	x3, [x3]
   40534:	ldr	x6, [sp, #0x1a0]
   40538:	ldr	x4, [x6, #0x8]
   4053c:	ldr	x8, [sp, #0x1a0]
   40540:	stur	x4, [sp, #0x60]
   40544:	ldr	x8, [x8, #0xab8]
   40548:	ldr	x10, [sp, #0x1a0]
   4054c:	ldr	x27, [x10, #0xbf8]
   40550:	ldr	x12, [sp, #0x1a0]
   40554:	ldr	x9, [x12, #0xac0]
   40558:	ldr	x14, [sp, #0x1a0]
   4055c:	ldr	x0, [x14, #0xac8]
   40560:	ldr	x0, [sp, #0x1a0]
   40564:	ldr	x0, [x0, #0xad0]
   40568:	ldr	x0, [sp, #0x1a0]
   4056c:	ldr	x2, [x0, #0xc48]
   40570:	ldr	x14, [x0, #0xc50]
   40574:	ldr	x0, [x0, #0xc58]
   40578:	stur	x0, [sp, #0x68]
   4057c:	ldr	x0, [sp, #0x1a0]
   40580:	ldr	x25, [x0, #0xc60]
   40584:	stur	x25, [sp, #0x70]
   40588:	ldr	x0, [x0, #0xc68]
   4058c:	ldr	x1, [sp, #0x1a0]
   40590:	ldr	x20, [x1, #0xc70]
   40594:	ldr	x15, [x1, #0xc78]
   40598:	ldr	x19, [x1, #0xc88]
   4059c:	stur	x19, [sp, #0x78]
   405a0:	ldr	x26, [x1, #0xc90]
   405a4:	stur	x26, [sp, #0x80]
   405a8:	ldr	x12, [x1, #0xca0]
   405ac:	ldr	x11, [x1, #0xca8]
   405b0:	ldr	x7, [x1, #0xcb8]
   405b4:	ldr	x6, [x1, #0xcc0]
   405b8:	ldr	x22, [x1, #0x10]
   405bc:	mov	x10, #0x1
   405c0:	stur	x10, [sp, #0x58]
   405c4:	str	x10, [x23, #0x5788]
   405c8:	add	x0, x3, x0
   405cc:	mov	w1, #0xc87e
   405d0:	movk	w1, #0x1, lsl #16
   405d4:	madd	x4, x14, x1, x0
   405d8:	stur	x4, [sp, #0x50]
   405dc:	mov	x13, #0xf
   405e0:	b	0x40604
   405e4:	ldur	x0, [sp, #0x10]
   405e8:	ldur	x8, [sp, #0x90]
   405ec:	and	x0, x0, #0x3ffffffffffffff
   405f0:	eor	x0, x0, #0x3ffffffffffffff
   405f4:	ldur	x1, [sp, #0x28]
   405f8:	str	x0, [x8, x1, lsl #3]
   405fc:	add	x9, x1, #0x1
   40600:	add	x14, x14, #0x1
   40604:	cbnz	x27, 0x40794
   40608:	b	0x4335c
   4060c:	ldr	x10, [sp, #0x1a0]
   40610:	str	x21, [x10, #0x10]
   40614:	ldr	x13, [sp, #0x1a0]
   40618:	ldr	x28, [sp, #0x190]
   4061c:	str	x28, [x13, #0x18]
   40620:	ldr	x0, [sp, #0x1a0]
   40624:	str	x21, [x0, #0x10]
   40628:	str	x28, [x0, #0x18]
   4062c:	str	x14, [x0, #0xc50]
   40630:	ldur	x13, [sp, #0x68]
   40634:	str	x13, [x0, #0xc58]
   40638:	ldur	x25, [sp, #0x70]
   4063c:	str	x25, [x0, #0xc60]
   40640:	ldur	x4, [sp, #0x50]
   40644:	sub	x0, x4, x3
   40648:	mov	w1, #0xc87e
   4064c:	movk	w1, #0x1, lsl #16
   40650:	msub	x0, x14, x1, x0
   40654:	ldr	x1, [sp, #0x1a0]
   40658:	str	x0, [x1, #0xc68]
   4065c:	ldr	x0, [sp, #0x1a0]
   40660:	str	x20, [x0, #0xc70]
   40664:	str	x15, [x0, #0xc78]
   40668:	mov	x0, #0x0
   4066c:	str	x0, [x1, #0xc80]
   40670:	ldur	x19, [sp, #0x78]
   40674:	str	x19, [x1, #0xc88]
   40678:	ldur	x26, [sp, #0x80]
   4067c:	str	x26, [x1, #0xc90]
   40680:	str	x0, [x1, #0xc98]
   40684:	str	x12, [x1, #0xca0]
   40688:	str	x11, [x1, #0xca8]
   4068c:	str	x0, [x1, #0xcb0]
   40690:	ldr	x0, [sp, #0x1a0]
   40694:	str	x7, [x0, #0xcb8]
   40698:	str	x6, [x0, #0xcc0]
   4069c:	mov	x5, #0x1
   406a0:	add	x0, x9, #0x1
   406a4:	str	x0, [x1, #0xcd0]
   406a8:	ldur	x0, [sp, #0x30]
   406ac:	and	x0, x0, #0x3ffffffffffffff
   406b0:	eor	x0, x0, #0x3ffffffffffffff
   406b4:	str	x0, [x1, #0xcd8]
   406b8:	mov	x1, #0x834
   406bc:	mov	x2, #-0x1b
   406c0:	ldur	x4, [sp, #0x60]
   406c4:	ldr	x27, [sp, #0x1b0]
   406c8:	ldur	x0, [sp, #0x8]
   406cc:	ldr	x6, [sp, #0x1a8]
   406d0:	blr	x27
   406d4:	mov	x1, #0x2
   406d8:	stur	x1, [sp, #0xc0]
   406dc:	cmp	x0, #0x0
   406e0:	b.ne	0x43a18
   406e4:	ldr	x3, [sp, #0x1a0]
   406e8:	ldr	x3, [x3]
   406ec:	ldr	x7, [sp, #0x1a0]
   406f0:	ldr	x4, [x7, #0x8]
   406f4:	ldr	x9, [sp, #0x1a0]
   406f8:	stur	x4, [sp, #0x60]
   406fc:	ldr	x8, [x9, #0xab8]
   40700:	ldr	x11, [sp, #0x1a0]
   40704:	ldr	x27, [x11, #0xbf8]
   40708:	ldr	x13, [sp, #0x1a0]
   4070c:	ldr	x1, [x13, #0xac0]
   40710:	ldr	x15, [sp, #0x1a0]
   40714:	ldr	x2, [x15, #0xac8]
   40718:	ldr	x0, [sp, #0x1a0]
   4071c:	ldr	x2, [x0, #0xad0]
   40720:	ldr	x2, [x0, #0xc48]
   40724:	ldr	x14, [x0, #0xc50]
   40728:	ldr	x0, [x0, #0xc58]
   4072c:	stur	x0, [sp, #0x68]
   40730:	ldr	x0, [sp, #0x1a0]
   40734:	ldr	x25, [x0, #0xc60]
   40738:	stur	x25, [sp, #0x70]
   4073c:	ldr	x4, [x0, #0xc68]
   40740:	ldr	x20, [x0, #0xc70]
   40744:	ldr	x15, [x0, #0xc78]
   40748:	ldr	x19, [x0, #0xc88]
   4074c:	stur	x19, [sp, #0x78]
   40750:	ldr	x26, [x0, #0xc90]
   40754:	stur	x26, [sp, #0x80]
   40758:	ldr	x12, [x0, #0xca0]
   4075c:	ldr	x11, [x0, #0xca8]
   40760:	ldr	x7, [x0, #0xcb8]
   40764:	ldr	x6, [x0, #0xcc0]
   40768:	ldr	x22, [x0, #0x10]
   4076c:	mov	x10, #0x1
   40770:	stur	x10, [sp, #0x58]
   40774:	str	x10, [x23, #0x5788]
   40778:	add	x4, x3, x4
   4077c:	mov	w5, #0xc87e
   40780:	movk	w5, #0x1, lsl #16
   40784:	madd	x4, x14, x5, x4
   40788:	stur	x4, [sp, #0x50]
   4078c:	mov	x13, #0xf
   40790:	b	0x407a8
   40794:	ldur	x0, [sp, #0x30]
   40798:	and	x4, x0, #0x3ffffffffffffff
   4079c:	eor	x4, x4, #0x3ffffffffffffff
   407a0:	str	x4, [x8, x9, lsl #3]
   407a4:	add	x1, x9, #0x1
   407a8:	cbnz	x27, 0x4094c
   407ac:	b	0x43388
   407b0:	ldr	x10, [sp, #0x1a0]
   407b4:	str	x21, [x10, #0x10]
   407b8:	ldr	x13, [sp, #0x1a0]
   407bc:	ldr	x28, [sp, #0x190]
   407c0:	str	x28, [x13, #0x18]
   407c4:	ldr	x0, [sp, #0x1a0]
   407c8:	str	x21, [x0, #0x10]
   407cc:	str	x28, [x0, #0x18]
   407d0:	str	x14, [x0, #0xc50]
   407d4:	ldur	x0, [sp, #0x68]
   407d8:	ldr	x2, [sp, #0x1a0]
   407dc:	str	x0, [x2, #0xc58]
   407e0:	ldr	x0, [sp, #0x1a0]
   407e4:	ldur	x25, [sp, #0x70]
   407e8:	str	x25, [x0, #0xc60]
   407ec:	ldur	x4, [sp, #0x50]
   407f0:	sub	x0, x4, x3
   407f4:	mov	w2, #0xc87e
   407f8:	movk	w2, #0x1, lsl #16
   407fc:	msub	x0, x14, x2, x0
   40800:	ldr	x2, [sp, #0x1a0]
   40804:	str	x0, [x2, #0xc68]
   40808:	ldr	x0, [sp, #0x1a0]
   4080c:	str	x20, [x0, #0xc70]
   40810:	str	x15, [x0, #0xc78]
   40814:	mov	x0, #0x0
   40818:	str	x0, [x2, #0xc80]
   4081c:	ldur	x19, [sp, #0x78]
   40820:	str	x19, [x2, #0xc88]
   40824:	ldur	x26, [sp, #0x80]
   40828:	str	x26, [x2, #0xc90]
   4082c:	str	x0, [x2, #0xc98]
   40830:	str	x12, [x2, #0xca0]
   40834:	str	x11, [x2, #0xca8]
   40838:	str	x0, [x2, #0xcb0]
   4083c:	ldr	x0, [sp, #0x1a0]
   40840:	str	x7, [x0, #0xcb8]
   40844:	str	x6, [x0, #0xcc0]
   40848:	mov	x5, #0x1
   4084c:	add	x0, x1, #0x1
   40850:	ldr	x1, [sp, #0x1a0]
   40854:	str	x0, [x1, #0xcd0]
   40858:	ldur	x4, [sp, #0x38]
   4085c:	and	x0, x4, #0x3ffffffffffffff
   40860:	eor	x0, x0, #0x3ffffffffffffff
   40864:	str	x0, [x1, #0xcd8]
   40868:	mov	x1, #0x838
   4086c:	mov	x2, #-0x1b
   40870:	ldur	x4, [sp, #0x60]
   40874:	ldr	x27, [sp, #0x1b0]
   40878:	ldur	x0, [sp, #0x8]
   4087c:	ldr	x6, [sp, #0x1a8]
   40880:	blr	x27
   40884:	mov	x3, #0x2
   40888:	stur	x3, [sp, #0xc0]
   4088c:	cmp	x0, #0x0
   40890:	b.ne	0x43a18
   40894:	ldr	x3, [sp, #0x1a0]
   40898:	ldr	x3, [x3]
   4089c:	ldr	x7, [sp, #0x1a0]
   408a0:	ldr	x4, [x7, #0x8]
   408a4:	ldr	x9, [sp, #0x1a0]
   408a8:	stur	x4, [sp, #0x60]
   408ac:	ldr	x8, [x9, #0xab8]
   408b0:	ldr	x11, [sp, #0x1a0]
   408b4:	ldr	x27, [x11, #0xbf8]
   408b8:	ldr	x13, [sp, #0x1a0]
   408bc:	ldr	x1, [x13, #0xac0]
   408c0:	ldr	x15, [sp, #0x1a0]
   408c4:	ldr	x0, [x15, #0xac8]
   408c8:	ldr	x0, [sp, #0x1a0]
   408cc:	ldr	x0, [x0, #0xad0]
   408d0:	ldr	x0, [sp, #0x1a0]
   408d4:	ldr	x2, [x0, #0xc48]
   408d8:	ldr	x14, [x0, #0xc50]
   408dc:	ldr	x15, [x0, #0xc58]
   408e0:	stur	x15, [sp, #0x68]
   408e4:	ldr	x25, [x0, #0xc60]
   408e8:	ldr	x0, [sp, #0x1a0]
   408ec:	stur	x25, [sp, #0x70]
   408f0:	ldr	x0, [x0, #0xc68]
   408f4:	ldr	x4, [sp, #0x1a0]
   408f8:	ldr	x20, [x4, #0xc70]
   408fc:	ldr	x15, [x4, #0xc78]
   40900:	ldr	x19, [x4, #0xc88]
   40904:	stur	x19, [sp, #0x78]
   40908:	ldr	x26, [x4, #0xc90]
   4090c:	stur	x26, [sp, #0x80]
   40910:	ldr	x12, [x4, #0xca0]
   40914:	ldr	x11, [x4, #0xca8]
   40918:	ldr	x7, [x4, #0xcb8]
   4091c:	ldr	x6, [x4, #0xcc0]
   40920:	ldr	x22, [x4, #0x10]
   40924:	mov	x10, #0x1
   40928:	stur	x10, [sp, #0x58]
   4092c:	str	x10, [x23, #0x5788]
   40930:	add	x0, x3, x0
   40934:	mov	w4, #0xc87e
   40938:	movk	w4, #0x1, lsl #16
   4093c:	madd	x4, x14, x4, x0
   40940:	stur	x4, [sp, #0x50]
   40944:	mov	x13, #0xf
   40948:	b	0x40960
   4094c:	ldur	x0, [sp, #0x38]
   40950:	and	x0, x0, #0x3ffffffffffffff
   40954:	eor	x0, x0, #0x3ffffffffffffff
   40958:	str	x0, [x8, x1, lsl #3]
   4095c:	add	x1, x1, #0x1
   40960:	cbnz	x27, 0x40afc
   40964:	b	0x433b4
   40968:	ldr	x10, [sp, #0x1a0]
   4096c:	str	x21, [x10, #0x10]
   40970:	ldr	x13, [sp, #0x1a0]
   40974:	ldr	x28, [sp, #0x190]
   40978:	str	x28, [x13, #0x18]
   4097c:	ldr	x0, [sp, #0x1a0]
   40980:	str	x21, [x0, #0x10]
   40984:	str	x28, [x0, #0x18]
   40988:	str	x14, [x0, #0xc50]
   4098c:	ldur	x0, [sp, #0x68]
   40990:	ldr	x2, [sp, #0x1a0]
   40994:	str	x0, [x2, #0xc58]
   40998:	ldr	x0, [sp, #0x1a0]
   4099c:	ldur	x25, [sp, #0x70]
   409a0:	str	x25, [x0, #0xc60]
   409a4:	ldur	x4, [sp, #0x50]
   409a8:	sub	x0, x4, x3
   409ac:	mov	w2, #0xc87e
   409b0:	movk	w2, #0x1, lsl #16
   409b4:	msub	x0, x14, x2, x0
   409b8:	ldr	x2, [sp, #0x1a0]
   409bc:	str	x0, [x2, #0xc68]
   409c0:	ldr	x0, [sp, #0x1a0]
   409c4:	str	x20, [x0, #0xc70]
   409c8:	str	x15, [x0, #0xc78]
   409cc:	mov	x0, #0x0
   409d0:	str	x0, [x2, #0xc80]
   409d4:	ldur	x19, [sp, #0x78]
   409d8:	str	x19, [x2, #0xc88]
   409dc:	ldur	x26, [sp, #0x80]
   409e0:	str	x26, [x2, #0xc90]
   409e4:	str	x0, [x2, #0xc98]
   409e8:	str	x12, [x2, #0xca0]
   409ec:	str	x11, [x2, #0xca8]
   409f0:	str	x0, [x2, #0xcb0]
   409f4:	ldr	x0, [sp, #0x1a0]
   409f8:	str	x7, [x0, #0xcb8]
   409fc:	str	x6, [x0, #0xcc0]
   40a00:	mov	x5, #0x1
   40a04:	add	x9, x1, #0x1
   40a08:	str	x9, [x0, #0xcd0]
   40a0c:	ldur	x22, [sp, #0x40]
   40a10:	and	x10, x22, #0x3ffffffffffffff
   40a14:	eor	x10, x10, #0x3ffffffffffffff
   40a18:	str	x10, [x0, #0xcd8]
   40a1c:	mov	x1, #0x83c
   40a20:	mov	x2, #-0x1b
   40a24:	ldur	x4, [sp, #0x60]
   40a28:	ldr	x27, [sp, #0x1b0]
   40a2c:	ldur	x0, [sp, #0x8]
   40a30:	ldr	x6, [sp, #0x1a8]
   40a34:	blr	x27
   40a38:	mov	x1, #0x2
   40a3c:	stur	x1, [sp, #0xc0]
   40a40:	cmp	x0, #0x0
   40a44:	b.ne	0x43a18
   40a48:	ldr	x3, [sp, #0x1a0]
   40a4c:	ldr	x3, [x3]
   40a50:	ldr	x7, [sp, #0x1a0]
   40a54:	ldr	x4, [x7, #0x8]
   40a58:	ldr	x9, [sp, #0x1a0]
   40a5c:	stur	x4, [sp, #0x60]
   40a60:	ldr	x8, [x9, #0xab8]
   40a64:	ldr	x11, [sp, #0x1a0]
   40a68:	ldr	x27, [x11, #0xbf8]
   40a6c:	ldr	x13, [sp, #0x1a0]
   40a70:	ldr	x1, [x13, #0xac0]
   40a74:	ldr	x15, [sp, #0x1a0]
   40a78:	ldr	x14, [x15, #0xac8]
   40a7c:	ldr	x0, [sp, #0x1a0]
   40a80:	ldr	x14, [x0, #0xad0]
   40a84:	ldr	x2, [x0, #0xc48]
   40a88:	ldr	x14, [x0, #0xc50]
   40a8c:	ldr	x0, [x0, #0xc58]
   40a90:	stur	x0, [sp, #0x68]
   40a94:	ldr	x0, [sp, #0x1a0]
   40a98:	ldr	x25, [x0, #0xc60]
   40a9c:	stur	x25, [sp, #0x70]
   40aa0:	ldr	x0, [x0, #0xc68]
   40aa4:	ldr	x4, [sp, #0x1a0]
   40aa8:	ldr	x20, [x4, #0xc70]
   40aac:	ldr	x15, [x4, #0xc78]
   40ab0:	ldr	x19, [x4, #0xc88]
   40ab4:	stur	x19, [sp, #0x78]
   40ab8:	ldr	x26, [x4, #0xc90]
   40abc:	stur	x26, [sp, #0x80]
   40ac0:	ldr	x12, [x4, #0xca0]
   40ac4:	ldr	x11, [x4, #0xca8]
   40ac8:	ldr	x7, [x4, #0xcb8]
   40acc:	ldr	x6, [x4, #0xcc0]
   40ad0:	ldr	x22, [x4, #0x10]
   40ad4:	mov	x10, #0x1
   40ad8:	stur	x10, [sp, #0x58]
   40adc:	str	x10, [x23, #0x5788]
   40ae0:	add	x0, x3, x0
   40ae4:	mov	w4, #0xc87e
   40ae8:	movk	w4, #0x1, lsl #16
   40aec:	madd	x4, x14, x4, x0
   40af0:	stur	x4, [sp, #0x50]
   40af4:	mov	x13, #0xf
   40af8:	b	0x40b10
   40afc:	ldur	x10, [sp, #0x40]
   40b00:	and	x0, x10, #0x3ffffffffffffff
   40b04:	eor	x0, x0, #0x3ffffffffffffff
   40b08:	str	x0, [x8, x1, lsl #3]
   40b0c:	add	x1, x1, #0x1
   40b10:	cbnz	x27, 0x40cb8
   40b14:	b	0x433e0
   40b18:	ldr	x10, [sp, #0x1a0]
   40b1c:	str	x21, [x10, #0x10]
   40b20:	ldr	x13, [sp, #0x1a0]
   40b24:	ldr	x28, [sp, #0x190]
   40b28:	str	x28, [x13, #0x18]
   40b2c:	ldr	x0, [sp, #0x1a0]
   40b30:	str	x21, [x0, #0x10]
   40b34:	str	x28, [x0, #0x18]
   40b38:	str	x14, [x0, #0xc50]
   40b3c:	ldur	x0, [sp, #0x68]
   40b40:	ldr	x2, [sp, #0x1a0]
   40b44:	str	x0, [x2, #0xc58]
   40b48:	ldr	x0, [sp, #0x1a0]
   40b4c:	ldur	x25, [sp, #0x70]
   40b50:	str	x25, [x0, #0xc60]
   40b54:	ldur	x4, [sp, #0x50]
   40b58:	sub	x0, x4, x3
   40b5c:	mov	w2, #0xc87e
   40b60:	movk	w2, #0x1, lsl #16
   40b64:	msub	x0, x14, x2, x0
   40b68:	ldr	x2, [sp, #0x1a0]
   40b6c:	str	x0, [x2, #0xc68]
   40b70:	ldr	x0, [sp, #0x1a0]
   40b74:	str	x20, [x0, #0xc70]
   40b78:	str	x15, [x0, #0xc78]
   40b7c:	mov	x0, #0x0
   40b80:	str	x0, [x2, #0xc80]
   40b84:	ldur	x19, [sp, #0x78]
   40b88:	str	x19, [x2, #0xc88]
   40b8c:	ldur	x26, [sp, #0x80]
   40b90:	str	x26, [x2, #0xc90]
   40b94:	str	x0, [x2, #0xc98]
   40b98:	str	x12, [x2, #0xca0]
   40b9c:	str	x11, [x2, #0xca8]
   40ba0:	str	x0, [x2, #0xcb0]
   40ba4:	ldr	x0, [sp, #0x1a0]
   40ba8:	str	x7, [x0, #0xcb8]
   40bac:	str	x6, [x0, #0xcc0]
   40bb0:	mov	x5, #0x1
   40bb4:	add	x0, x1, #0x1
   40bb8:	ldr	x1, [sp, #0x1a0]
   40bbc:	str	x0, [x1, #0xcd0]
   40bc0:	ldur	x20, [sp, #0x48]
   40bc4:	and	x0, x20, #0x3ffffffffffffff
   40bc8:	eor	x0, x0, #0x3ffffffffffffff
   40bcc:	str	x0, [x1, #0xcd8]
   40bd0:	mov	x1, #0x840
   40bd4:	mov	x2, #-0x1b
   40bd8:	ldur	x4, [sp, #0x60]
   40bdc:	ldr	x27, [sp, #0x1b0]
   40be0:	ldur	x0, [sp, #0x8]
   40be4:	ldr	x6, [sp, #0x1a8]
   40be8:	blr	x27
   40bec:	mov	x1, #0x2
   40bf0:	stur	x1, [sp, #0xc0]
   40bf4:	cmp	x0, #0x0
   40bf8:	b.ne	0x43a18
   40bfc:	ldr	x3, [sp, #0x1a0]
   40c00:	ldr	x3, [x3]
   40c04:	ldr	x7, [sp, #0x1a0]
   40c08:	ldr	x4, [x7, #0x8]
   40c0c:	ldr	x9, [sp, #0x1a0]
   40c10:	stur	x4, [sp, #0x60]
   40c14:	ldr	x8, [x9, #0xab8]
   40c18:	ldr	x11, [sp, #0x1a0]
   40c1c:	ldr	x27, [x11, #0xbf8]
   40c20:	ldr	x13, [sp, #0x1a0]
   40c24:	ldr	x1, [x13, #0xac0]
   40c28:	ldr	x15, [sp, #0x1a0]
   40c2c:	stur	x1, [sp, #0x28]
   40c30:	ldr	x0, [x15, #0xac8]
   40c34:	ldr	x0, [sp, #0x1a0]
   40c38:	ldr	x0, [x0, #0xad0]
   40c3c:	ldr	x0, [sp, #0x1a0]
   40c40:	ldr	x2, [x0, #0xc48]
   40c44:	ldr	x14, [x0, #0xc50]
   40c48:	ldr	x0, [x0, #0xc58]
   40c4c:	stur	x0, [sp, #0x68]
   40c50:	ldr	x0, [sp, #0x1a0]
   40c54:	ldr	x25, [x0, #0xc60]
   40c58:	stur	x25, [sp, #0x70]
   40c5c:	ldr	x0, [x0, #0xc68]
   40c60:	ldr	x1, [sp, #0x1a0]
   40c64:	ldr	x20, [x1, #0xc70]
   40c68:	ldr	x15, [x1, #0xc78]
   40c6c:	ldr	x19, [x1, #0xc88]
   40c70:	stur	x19, [sp, #0x78]
   40c74:	ldr	x26, [x1, #0xc90]
   40c78:	stur	x26, [sp, #0x80]
   40c7c:	ldr	x12, [x1, #0xca0]
   40c80:	ldr	x11, [x1, #0xca8]
   40c84:	ldr	x7, [x1, #0xcb8]
   40c88:	ldr	x6, [x1, #0xcc0]
   40c8c:	ldr	x22, [x1, #0x10]
   40c90:	mov	x10, #0x1
   40c94:	stur	x10, [sp, #0x58]
   40c98:	str	x10, [x23, #0x5788]
   40c9c:	add	x0, x3, x0
   40ca0:	mov	w1, #0xc87e
   40ca4:	movk	w1, #0x1, lsl #16
   40ca8:	madd	x4, x14, x1, x0
   40cac:	stur	x4, [sp, #0x50]
   40cb0:	mov	x13, #0xf
   40cb4:	b	0x40cd0
   40cb8:	ldur	x0, [sp, #0x48]
   40cbc:	and	x0, x0, #0x3ffffffffffffff
   40cc0:	eor	x0, x0, #0x3ffffffffffffff
   40cc4:	str	x0, [x8, x1, lsl #3]
   40cc8:	add	x1, x1, #0x1
   40ccc:	stur	x1, [sp, #0x28]
   40cd0:	ldur	x0, [sp, #0xb8]
   40cd4:	ldr	x28, [sp, #0x190]
   40cd8:	cmp	x0, x28
   40cdc:	b.lo	0x40df0
   40ce0:	mov	x4, #0x0
   40ce4:	str	x4, [x23, #0x18]
   40ce8:	mov	x5, #0x1000000000000000
   40cec:	str	x5, [x23, #0x20]
   40cf0:	mov	x8, #0x1
   40cf4:	str	x8, [x23, #0x30]
   40cf8:	mov	x9, #0x101010101010101
   40cfc:	str	x9, [x23, #0x38]
   40d00:	mov	x9, #0x2
   40d04:	str	x9, [x23, #0x40]
   40d08:	mov	x9, #0x3
   40d0c:	str	x9, [x23, #0x48]
   40d10:	mov	x10, #0x4
   40d14:	str	x10, [x23, #0x50]
   40d18:	mov	x13, #0xf0f0f0f0f0f0f0f
   40d1c:	str	x13, [x23, #0x78]
   40d20:	mov	x13, #0x3333333333333333
   40d24:	str	x13, [x23, #0x88]
   40d28:	mov	x13, #0x38
   40d2c:	str	x13, [x23, #0x90]
   40d30:	mov	x0, #0x3a
   40d34:	str	x0, [x23, #0x98]
   40d38:	mov	x0, #0x5555555555555555
   40d3c:	str	x0, [x23, #0xb0]
   40d40:	mov	x0, #0x3ffffffffffffff
   40d44:	str	x0, [x23, #0xb8]
   40d48:	str	x4, [x23, #0x188]
   40d4c:	str	x8, [x23, #0x190]
   40d50:	ldur	x10, [sp, #0x58]
   40d54:	str	x10, [x23, #0x5788]
   40d58:	str	x3, [x23, #0x5790]
   40d5c:	ldur	x4, [sp, #0x60]
   40d60:	str	x4, [x23, #0x5798]
   40d64:	str	x21, [x23, #0x5ac0]
   40d68:	str	x28, [x23, #0x5ac8]
   40d6c:	ldur	x1, [sp, #0x28]
   40d70:	str	x1, [x23, #0x6570]
   40d74:	str	x14, [x23, #0x6700]
   40d78:	ldur	x24, [sp, #0x68]
   40d7c:	str	x24, [x23, #0x6708]
   40d80:	ldur	x25, [sp, #0x70]
   40d84:	str	x25, [x23, #0x6710]
   40d88:	ldur	x4, [sp, #0x50]
   40d8c:	sub	x0, x4, x3
   40d90:	mov	w1, #0xc87e
   40d94:	movk	w1, #0x1, lsl #16
   40d98:	msub	x0, x14, x1, x0
   40d9c:	str	x0, [x23, #0x6718]
   40da0:	str	x20, [x23, #0x6720]
   40da4:	str	x15, [x23, #0x6728]
   40da8:	ldur	x19, [sp, #0x78]
   40dac:	str	x19, [x23, #0x6738]
   40db0:	ldur	x26, [sp, #0x80]
   40db4:	str	x26, [x23, #0x6740]
   40db8:	str	x12, [x23, #0x6750]
   40dbc:	str	x11, [x23, #0x6758]
   40dc0:	str	x7, [x23, #0x6768]
   40dc4:	str	x6, [x23, #0x6770]
   40dc8:	mov	x0, #0x0
   40dcc:	mov	x1, #0x1
   40dd0:	add	sp, sp, #0x1d0
   40dd4:	ldp	x19, x20, [sp], #0x10
   40dd8:	ldp	x21, x22, [sp], #0x10
   40ddc:	ldp	x23, x24, [sp], #0x10
   40de0:	ldp	x25, x26, [sp], #0x10
   40de4:	ldp	x27, x28, [sp], #0x10
   40de8:	ldp	x29, x30, [sp], #0x10
   40dec:	.long	0xd65f0fff
   40df0:	add	x0, x24, #0x1
   40df4:	stur	x0, [sp, #0xb8]
   40df8:	cmp	x0, x24
   40dfc:	b.lo	0x4340c
   40e00:	mov	x25, #0x1
   40e04:	stur	x25, [sp, #0x70]
   40e08:	mov	x5, x23
   40e0c:	ldur	x10, [sp, #0x78]
   40e10:	ldur	x21, [sp, #0x70]
   40e14:	stur	x2, [sp, #0x88]
   40e18:	stur	x8, [sp, #0x90]
   40e1c:	b	0x3be60
   40e20:	ldur	x8, [sp, #0x90]
   40e24:	add	x1, x15, #0x1
   40e28:	cmp	x1, x15
   40e2c:	b.lo	0x4350c
   40e30:	mov	x9, #0x1
   40e34:	stur	x9, [sp, #0x20]
   40e38:	mov	x15, x1
   40e3c:	stur	x25, [sp, #0x10]
   40e40:	stur	x21, [sp, #0x30]
   40e44:	stur	x4, [sp, #0x38]
   40e48:	stur	x24, [sp, #0x40]
   40e4c:	stur	x19, [sp, #0x48]
   40e50:	b	0x3eca0
   40e54:	ldur	x8, [sp, #0x90]
   40e58:	add	x3, x11, #0x1
   40e5c:	cmp	x3, x11
   40e60:	b.lo	0x43638
   40e64:	ldur	x4, [sp, #0xc8]
   40e68:	mov	w9, #0xcb86
   40e6c:	movk	w9, #0x2, lsl #16
   40e70:	sub	x6, x6, x9
   40e74:	mov	x9, #0x1
   40e78:	mov	x25, x1
   40e7c:	mov	x24, x20
   40e80:	mov	x21, x10
   40e84:	mov	x19, x26
   40e88:	mov	x11, x3
   40e8c:	mov	x4, x12
   40e90:	b	0x3fe2c
   40e94:	ldur	x2, [sp, #0x88]
   40e98:	ldur	x8, [sp, #0x90]
   40e9c:	add	x1, x9, #0x1
   40ea0:	stur	x1, [sp, #0xa8]
   40ea4:	cmp	x1, x9
   40ea8:	b.lo	0x43784
   40eac:	mov	x1, #0x1
   40eb0:	stur	x1, [sp, #0x18]
   40eb4:	mov	x24, x0
   40eb8:	stur	x5, [sp, #0x10]
   40ebc:	stur	x4, [sp, #0x40]
   40ec0:	ldur	x1, [sp, #0xa0]
   40ec4:	stur	x1, [sp, #0x48]
   40ec8:	b	0x3cacc
   40ecc:	ldur	x2, [sp, #0x88]
   40ed0:	ldur	x8, [sp, #0x90]
   40ed4:	add	x20, x21, #0x1
   40ed8:	cmp	x20, x21
   40edc:	b.lo	0x438bc
   40ee0:	mov	w0, #0xdc1e
   40ee4:	movk	w0, #0x2, lsl #16
   40ee8:	sub	x9, x9, x0
   40eec:	mov	x3, #0x1
   40ef0:	stur	x3, [sp, #0xb0]
   40ef4:	mov	x0, x26
   40ef8:	mov	x4, x19
   40efc:	mov	x5, x28
   40f00:	mov	x15, x24
   40f04:	stur	x1, [sp, #0xa0]
   40f08:	b	0x3de70
   40f0c:	stur	x0, [sp, #0xc0]
   40f10:	b	0x43a18
   40f14:	stur	x0, [sp, #0xc0]
   40f18:	b	0x43a18
   40f1c:	mov	w1, #0xc87e
   40f20:	movk	w1, #0x1, lsl #16
   40f24:	cmp	x3, x1
   40f28:	b.lo	0x3bf70
   40f2c:	mov	w1, #0x1
   40f30:	uxtb	w4, w4
   40f34:	cbnz	x4, 0x3beb8
   40f38:	ldur	x1, [sp, #0x28]
   40f3c:	cmp	x1, x2
   40f40:	b.ls	0x40f54
   40f44:	mov	w1, #0x0
   40f48:	ldur	x0, [sp, #0x60]
   40f4c:	mov	x2, x3
   40f50:	b	0x3bf48
   40f54:	ldur	x1, [sp, #0xb8]
   40f58:	ldr	x28, [sp, #0x190]
   40f5c:	cmp	x1, x28
   40f60:	b.lo	0x3bf3c
   40f64:	b	0x3bec4
   40f68:	stur	x0, [sp, #0xc0]
   40f6c:	b	0x43a18
   40f70:	stur	x0, [sp, #0xc0]
   40f74:	b	0x43a18
   40f78:	mov	x5, #0x67e
   40f7c:	ldur	x26, [sp]
   40f80:	str	x5, [x26, #0x48]
   40f84:	mov	x5, #0x0
   40f88:	str	x5, [x23, #0x18]
   40f8c:	mov	x8, #0x1000000000000000
   40f90:	str	x8, [x23, #0x20]
   40f94:	mov	x8, #0x1
   40f98:	str	x8, [x23, #0x30]
   40f9c:	mov	x9, #0x101010101010101
   40fa0:	str	x9, [x23, #0x38]
   40fa4:	mov	x21, #0x2
   40fa8:	str	x21, [x23, #0x40]
   40fac:	mov	x9, #0x3
   40fb0:	str	x9, [x23, #0x48]
   40fb4:	mov	x9, #0x4
   40fb8:	str	x9, [x23, #0x50]
   40fbc:	mov	x10, #0xf0f0f0f0f0f0f0f
   40fc0:	str	x10, [x23, #0x78]
   40fc4:	mov	x13, #0x3333333333333333
   40fc8:	str	x13, [x23, #0x88]
   40fcc:	mov	x13, #0x38
   40fd0:	str	x13, [x23, #0x90]
   40fd4:	mov	x13, #0x3a
   40fd8:	str	x13, [x23, #0x98]
   40fdc:	mov	x9, #0x5555555555555555
   40fe0:	str	x9, [x23, #0xb0]
   40fe4:	mov	x9, #0x3ffffffffffffff
   40fe8:	str	x9, [x23, #0xb8]
   40fec:	str	x5, [x23, #0x188]
   40ff0:	str	x8, [x23, #0x190]
   40ff4:	ldur	x27, [sp, #0xb8]
   40ff8:	str	x27, [x23, #0x22e0]
   40ffc:	str	x28, [x23, #0x22e8]
   41000:	uxtb	w0, w0
   41004:	str	x0, [x23, #0x22f8]
   41008:	add	x0, x27, #0x1
   4100c:	str	x0, [x23, #0x2310]
   41010:	ldur	x10, [sp, #0x58]
   41014:	str	x10, [x23, #0x5788]
   41018:	mov	w0, #0xc87e
   4101c:	movk	w0, #0x1, lsl #16
   41020:	sub	x3, x3, x0
   41024:	str	x3, [x23, #0x5790]
   41028:	str	x4, [x23, #0x5798]
   4102c:	str	x27, [x23, #0x5ac0]
   41030:	str	x28, [x23, #0x5ac8]
   41034:	ldur	x4, [sp, #0x28]
   41038:	str	x4, [x23, #0x6570]
   4103c:	add	x4, x14, #0x1
   41040:	str	x4, [x23, #0x6700]
   41044:	ldur	x24, [sp, #0x68]
   41048:	str	x24, [x23, #0x6708]
   4104c:	ldur	x25, [sp, #0x70]
   41050:	str	x25, [x23, #0x6710]
   41054:	ldur	x5, [sp, #0x50]
   41058:	sub	x3, x5, x3
   4105c:	msub	x0, x4, x0, x3
   41060:	str	x0, [x23, #0x6718]
   41064:	str	x20, [x23, #0x6720]
   41068:	str	x15, [x23, #0x6728]
   4106c:	ldur	x19, [sp, #0x78]
   41070:	str	x19, [x23, #0x6738]
   41074:	ldur	x26, [sp, #0x80]
   41078:	str	x26, [x23, #0x6740]
   4107c:	str	x12, [x23, #0x6750]
   41080:	str	x11, [x23, #0x6758]
   41084:	str	x7, [x23, #0x6768]
   41088:	str	x6, [x23, #0x6770]
   4108c:	ldr	x0, [x23, #0x5788]
   41090:	cmp	x0, #0x0
   41094:	b.ne	0x3c2fc
   41098:	b	0x3c2f0
   4109c:	stur	x0, [sp, #0xc0]
   410a0:	b	0x43a18
   410a4:	stur	x21, [sp, #0xc0]
   410a8:	b	0x43a18
   410ac:	stur	x0, [sp, #0xc0]
   410b0:	b	0x43a18
   410b4:	stur	x21, [sp, #0xc0]
   410b8:	b	0x43a18
   410bc:	mov	x1, #0x680
   410c0:	ldur	x26, [sp]
   410c4:	str	x1, [x26, #0x48]
   410c8:	mov	x1, #0x0
   410cc:	str	x1, [x23, #0x18]
   410d0:	mov	x2, #0x1000000000000000
   410d4:	str	x2, [x23, #0x20]
   410d8:	mov	x2, #0x1
   410dc:	str	x2, [x23, #0x30]
   410e0:	mov	x5, #0x101010101010101
   410e4:	str	x5, [x23, #0x38]
   410e8:	mov	x21, #0x2
   410ec:	str	x21, [x23, #0x40]
   410f0:	mov	x5, #0x3
   410f4:	str	x5, [x23, #0x48]
   410f8:	mov	x5, #0x4
   410fc:	str	x5, [x23, #0x50]
   41100:	mov	x5, #0xf0f0f0f0f0f0f0f
   41104:	str	x5, [x23, #0x78]
   41108:	mov	x5, #0x3333333333333333
   4110c:	str	x5, [x23, #0x88]
   41110:	mov	x5, #0x38
   41114:	str	x5, [x23, #0x90]
   41118:	mov	x5, #0x3a
   4111c:	str	x5, [x23, #0x98]
   41120:	mov	x5, #0x5555555555555555
   41124:	str	x5, [x23, #0xb0]
   41128:	mov	x8, #0x3ffffffffffffff
   4112c:	str	x8, [x23, #0xb8]
   41130:	str	x1, [x23, #0x188]
   41134:	str	x2, [x23, #0x190]
   41138:	ldur	x27, [sp, #0xb8]
   4113c:	str	x27, [x23, #0x22e0]
   41140:	str	x28, [x23, #0x22e8]
   41144:	uxtb	w13, w0
   41148:	str	x13, [x23, #0x22f8]
   4114c:	ldur	x0, [sp, #0xa8]
   41150:	str	x0, [x23, #0x2318]
   41154:	add	x13, x27, #0x2
   41158:	str	x13, [x23, #0x2320]
   4115c:	ldur	x10, [sp, #0x58]
   41160:	str	x10, [x23, #0x5788]
   41164:	mov	w0, #0xc87e
   41168:	movk	w0, #0x1, lsl #16
   4116c:	sub	x1, x3, x0
   41170:	str	x1, [x23, #0x5790]
   41174:	str	x4, [x23, #0x5798]
   41178:	str	x27, [x23, #0x5ac0]
   4117c:	str	x28, [x23, #0x5ac8]
   41180:	ldur	x2, [sp, #0x28]
   41184:	str	x2, [x23, #0x6570]
   41188:	add	x2, x14, #0x1
   4118c:	str	x2, [x23, #0x6700]
   41190:	ldur	x24, [sp, #0x68]
   41194:	str	x24, [x23, #0x6708]
   41198:	ldur	x25, [sp, #0x70]
   4119c:	str	x25, [x23, #0x6710]
   411a0:	ldur	x4, [sp, #0x50]
   411a4:	sub	x1, x4, x1
   411a8:	msub	x0, x2, x0, x1
   411ac:	str	x0, [x23, #0x6718]
   411b0:	str	x20, [x23, #0x6720]
   411b4:	str	x15, [x23, #0x6728]
   411b8:	ldur	x19, [sp, #0x78]
   411bc:	str	x19, [x23, #0x6738]
   411c0:	ldur	x26, [sp, #0x80]
   411c4:	str	x26, [x23, #0x6740]
   411c8:	str	x12, [x23, #0x6750]
   411cc:	str	x11, [x23, #0x6758]
   411d0:	str	x7, [x23, #0x6768]
   411d4:	str	x6, [x23, #0x6770]
   411d8:	ldr	x0, [x23, #0x5788]
   411dc:	cmp	x0, #0x0
   411e0:	b.ne	0x3c568
   411e4:	b	0x3c798
   411e8:	stur	x0, [sp, #0xc0]
   411ec:	b	0x43a18
   411f0:	stur	x21, [sp, #0xc0]
   411f4:	b	0x43a18
   411f8:	stur	x0, [sp, #0xc0]
   411fc:	b	0x43a18
   41200:	stur	x21, [sp, #0xc0]
   41204:	b	0x43a18
   41208:	mov	x1, #0x682
   4120c:	ldur	x26, [sp]
   41210:	str	x1, [x26, #0x48]
   41214:	mov	x1, #0x0
   41218:	str	x1, [x23, #0x18]
   4121c:	mov	x2, #0x1000000000000000
   41220:	str	x2, [x23, #0x20]
   41224:	mov	x2, #0x1
   41228:	str	x2, [x23, #0x30]
   4122c:	mov	x5, #0x101010101010101
   41230:	str	x5, [x23, #0x38]
   41234:	mov	x21, #0x2
   41238:	str	x21, [x23, #0x40]
   4123c:	mov	x5, #0x3
   41240:	str	x5, [x23, #0x48]
   41244:	mov	x5, #0x4
   41248:	str	x5, [x23, #0x50]
   4124c:	mov	x5, #0xf0f0f0f0f0f0f0f
   41250:	str	x5, [x23, #0x78]
   41254:	mov	x5, #0x3333333333333333
   41258:	str	x5, [x23, #0x88]
   4125c:	mov	x5, #0x38
   41260:	str	x5, [x23, #0x90]
   41264:	mov	x5, #0x3a
   41268:	str	x5, [x23, #0x98]
   4126c:	mov	x5, #0x5555555555555555
   41270:	str	x5, [x23, #0xb0]
   41274:	mov	x5, #0x3ffffffffffffff
   41278:	str	x5, [x23, #0xb8]
   4127c:	str	x1, [x23, #0x188]
   41280:	str	x2, [x23, #0x190]
   41284:	ldur	x27, [sp, #0xb8]
   41288:	str	x27, [x23, #0x22e0]
   4128c:	str	x28, [x23, #0x22e8]
   41290:	uxtb	w5, w0
   41294:	str	x5, [x23, #0x22f8]
   41298:	ldur	x0, [sp, #0xa8]
   4129c:	str	x0, [x23, #0x2318]
   412a0:	ldur	x0, [sp, #0xf0]
   412a4:	str	x0, [x23, #0x2328]
   412a8:	mov	x0, x25
   412ac:	str	x0, [x23, #0x2330]
   412b0:	ldur	x10, [sp, #0x58]
   412b4:	str	x10, [x23, #0x5788]
   412b8:	mov	w8, #0xc87e
   412bc:	movk	w8, #0x1, lsl #16
   412c0:	sub	x9, x3, x8
   412c4:	str	x9, [x23, #0x5790]
   412c8:	str	x4, [x23, #0x5798]
   412cc:	str	x27, [x23, #0x5ac0]
   412d0:	str	x28, [x23, #0x5ac8]
   412d4:	ldur	x1, [sp, #0x28]
   412d8:	str	x1, [x23, #0x6570]
   412dc:	add	x13, x14, #0x1
   412e0:	str	x13, [x23, #0x6700]
   412e4:	ldur	x24, [sp, #0x68]
   412e8:	str	x24, [x23, #0x6708]
   412ec:	ldur	x25, [sp, #0x70]
   412f0:	str	x25, [x23, #0x6710]
   412f4:	ldur	x4, [sp, #0x50]
   412f8:	sub	x0, x4, x9
   412fc:	msub	x0, x13, x8, x0
   41300:	str	x0, [x23, #0x6718]
   41304:	str	x20, [x23, #0x6720]
   41308:	str	x15, [x23, #0x6728]
   4130c:	ldur	x19, [sp, #0x78]
   41310:	str	x19, [x23, #0x6738]
   41314:	ldur	x26, [sp, #0x80]
   41318:	str	x26, [x23, #0x6740]
   4131c:	str	x12, [x23, #0x6750]
   41320:	str	x11, [x23, #0x6758]
   41324:	str	x7, [x23, #0x6768]
   41328:	str	x6, [x23, #0x6770]
   4132c:	ldr	x0, [x23, #0x5788]
   41330:	cmp	x0, #0x0
   41334:	b.ne	0x3c80c
   41338:	b	0x3ca34
   4133c:	stur	x0, [sp, #0xc0]
   41340:	b	0x43a18
   41344:	stur	x21, [sp, #0xc0]
   41348:	b	0x43a18
   4134c:	stur	x0, [sp, #0xc0]
   41350:	b	0x43a18
   41354:	stur	x21, [sp, #0xc0]
   41358:	b	0x43a18
   4135c:	stur	x22, [sp, #0xc0]
   41360:	b	0x43a18
   41364:	mov	x0, #0x69c
   41368:	ldur	x26, [sp]
   4136c:	str	x0, [x26, #0x48]
   41370:	mov	x2, #0x0
   41374:	str	x2, [x23, #0x18]
   41378:	mov	x0, #0x1000000000000000
   4137c:	str	x0, [x23, #0x20]
   41380:	mov	x0, #0x1
   41384:	str	x0, [x23, #0x30]
   41388:	mov	x5, #0x101010101010101
   4138c:	str	x5, [x23, #0x38]
   41390:	mov	x20, #0x2
   41394:	str	x20, [x23, #0x40]
   41398:	mov	x5, #0x3
   4139c:	str	x5, [x23, #0x48]
   413a0:	mov	x5, #0x4
   413a4:	str	x5, [x23, #0x50]
   413a8:	mov	x5, #0xf0f0f0f0f0f0f0f
   413ac:	str	x5, [x23, #0x78]
   413b0:	mov	x5, #0x3333333333333333
   413b4:	str	x5, [x23, #0x88]
   413b8:	mov	x5, #0x38
   413bc:	str	x5, [x23, #0x90]
   413c0:	mov	x5, #0x3a
   413c4:	str	x5, [x23, #0x98]
   413c8:	mov	x5, #0x5555555555555555
   413cc:	str	x5, [x23, #0xb0]
   413d0:	mov	x5, #0x3ffffffffffffff
   413d4:	str	x5, [x23, #0xb8]
   413d8:	str	x2, [x23, #0x188]
   413dc:	str	x0, [x23, #0x190]
   413e0:	ldur	x27, [sp, #0xb8]
   413e4:	str	x27, [x23, #0x22e0]
   413e8:	ldr	x28, [sp, #0x190]
   413ec:	str	x28, [x23, #0x22e8]
   413f0:	uxtb	w8, w1
   413f4:	str	x8, [x23, #0x22f8]
   413f8:	ldur	x1, [sp, #0xa8]
   413fc:	str	x1, [x23, #0x2398]
   41400:	ldur	x13, [sp, #0xf0]
   41404:	str	x13, [x23, #0x23a0]
   41408:	str	x27, [x23, #0x23a8]
   4140c:	ldur	x1, [sp, #0xe8]
   41410:	str	x1, [x23, #0x23b0]
   41414:	uxtb	w13, w4
   41418:	str	x13, [x23, #0x23c0]
   4141c:	ldur	x1, [sp, #0xa8]
   41420:	add	x1, x1, #0x1
   41424:	str	x1, [x23, #0x23d0]
   41428:	ldur	x10, [sp, #0x58]
   4142c:	str	x10, [x23, #0x5788]
   41430:	mov	w1, #0x2166
   41434:	movk	w1, #0x1, lsl #16
   41438:	sub	x1, x3, x1
   4143c:	str	x1, [x23, #0x5790]
   41440:	ldur	x4, [sp, #0x60]
   41444:	str	x4, [x23, #0x5798]
   41448:	str	x27, [x23, #0x5ac0]
   4144c:	str	x28, [x23, #0x5ac8]
   41450:	ldur	x2, [sp, #0xa8]
   41454:	str	x2, [x23, #0x5c10]
   41458:	ldur	x2, [sp, #0xf0]
   4145c:	str	x2, [x23, #0x5c18]
   41460:	str	x27, [x23, #0x5c20]
   41464:	ldur	x2, [sp, #0xe8]
   41468:	str	x2, [x23, #0x5c28]
   4146c:	ldur	x2, [sp, #0x10]
   41470:	str	x2, [x23, #0x5c30]
   41474:	str	x24, [x23, #0x5c38]
   41478:	str	x15, [x23, #0x5c40]
   4147c:	ldur	x22, [sp, #0x40]
   41480:	str	x22, [x23, #0x5c48]
   41484:	ldur	x2, [sp, #0x48]
   41488:	str	x2, [x23, #0x5c50]
   4148c:	ldur	x2, [sp, #0x28]
   41490:	str	x2, [x23, #0x6570]
   41494:	add	x2, x14, #0x1
   41498:	str	x2, [x23, #0x6700]
   4149c:	ldur	x24, [sp, #0x68]
   414a0:	str	x24, [x23, #0x6708]
   414a4:	ldur	x25, [sp, #0x70]
   414a8:	str	x25, [x23, #0x6710]
   414ac:	ldur	x4, [sp, #0x50]
   414b0:	sub	x1, x4, x1
   414b4:	mov	w3, #0xc87e
   414b8:	movk	w3, #0x1, lsl #16
   414bc:	msub	x1, x2, x3, x1
   414c0:	str	x1, [x23, #0x6718]
   414c4:	str	x0, [x23, #0x6720]
   414c8:	ldur	x13, [sp, #0x18]
   414cc:	str	x13, [x23, #0x6728]
   414d0:	ldur	x19, [sp, #0x78]
   414d4:	str	x19, [x23, #0x6738]
   414d8:	ldur	x26, [sp, #0x80]
   414dc:	str	x26, [x23, #0x6740]
   414e0:	str	x12, [x23, #0x6750]
   414e4:	str	x11, [x23, #0x6758]
   414e8:	str	x7, [x23, #0x6768]
   414ec:	str	x6, [x23, #0x6770]
   414f0:	ldr	x0, [x23, #0x5788]
   414f4:	cmp	x0, #0x0
   414f8:	b.ne	0x3cee4
   414fc:	b	0x3d11c
   41500:	stur	x20, [sp, #0xc0]
   41504:	b	0x43a18
   41508:	stur	x20, [sp, #0xc0]
   4150c:	b	0x43a18
   41510:	mov	x0, #0x69d
   41514:	ldur	x26, [sp]
   41518:	str	x0, [x26, #0x48]
   4151c:	mov	x5, #0x0
   41520:	str	x5, [x23, #0x18]
   41524:	mov	x0, #0x1000000000000000
   41528:	str	x0, [x23, #0x20]
   4152c:	mov	x0, #0x1
   41530:	stur	x0, [sp, #0xc0]
   41534:	str	x0, [x23, #0x30]
   41538:	mov	x0, #0x101010101010101
   4153c:	str	x0, [x23, #0x38]
   41540:	mov	x0, #0x2
   41544:	str	x0, [x23, #0x40]
   41548:	mov	x0, #0x3
   4154c:	str	x0, [x23, #0x48]
   41550:	mov	x0, #0x4
   41554:	str	x0, [x23, #0x50]
   41558:	mov	x8, #0xf0f0f0f0f0f0f0f
   4155c:	str	x8, [x23, #0x78]
   41560:	mov	x8, #0x3333333333333333
   41564:	str	x8, [x23, #0x88]
   41568:	mov	x8, #0x38
   4156c:	str	x8, [x23, #0x90]
   41570:	mov	x8, #0x3a
   41574:	str	x8, [x23, #0x98]
   41578:	mov	x8, #0x5555555555555555
   4157c:	str	x8, [x23, #0xb0]
   41580:	mov	x8, #0x3ffffffffffffff
   41584:	str	x8, [x23, #0xb8]
   41588:	str	x5, [x23, #0x188]
   4158c:	ldur	x0, [sp, #0xc0]
   41590:	str	x0, [x23, #0x190]
   41594:	ldur	x27, [sp, #0xb8]
   41598:	str	x27, [x23, #0x22e0]
   4159c:	ldr	x28, [sp, #0x190]
   415a0:	str	x28, [x23, #0x22e8]
   415a4:	uxtb	w13, w1
   415a8:	str	x13, [x23, #0x22f8]
   415ac:	ldur	x9, [sp, #0xa8]
   415b0:	str	x9, [x23, #0x2398]
   415b4:	ldur	x15, [sp, #0xf0]
   415b8:	str	x15, [x23, #0x23a0]
   415bc:	str	x27, [x23, #0x23a8]
   415c0:	ldur	x15, [sp, #0xe8]
   415c4:	str	x15, [x23, #0x23b0]
   415c8:	uxtb	w0, w4
   415cc:	str	x0, [x23, #0x23c0]
   415d0:	str	x2, [x23, #0x23d8]
   415d4:	ldur	x10, [sp, #0x58]
   415d8:	str	x10, [x23, #0x5788]
   415dc:	mov	w1, #0x2166
   415e0:	movk	w1, #0x1, lsl #16
   415e4:	sub	x1, x3, x1
   415e8:	str	x1, [x23, #0x5790]
   415ec:	ldur	x4, [sp, #0x60]
   415f0:	str	x4, [x23, #0x5798]
   415f4:	ldur	x0, [sp, #0x28]
   415f8:	str	x0, [x23, #0x6570]
   415fc:	add	x2, x14, #0x1
   41600:	str	x2, [x23, #0x6700]
   41604:	ldur	x24, [sp, #0x68]
   41608:	str	x24, [x23, #0x6708]
   4160c:	ldur	x25, [sp, #0x70]
   41610:	str	x25, [x23, #0x6710]
   41614:	ldur	x4, [sp, #0x50]
   41618:	sub	x1, x4, x1
   4161c:	mov	w3, #0xc87e
   41620:	movk	w3, #0x1, lsl #16
   41624:	msub	x0, x2, x3, x1
   41628:	str	x0, [x23, #0x6718]
   4162c:	ldur	x0, [sp, #0xc0]
   41630:	str	x0, [x23, #0x6720]
   41634:	ldur	x13, [sp, #0x18]
   41638:	str	x13, [x23, #0x6728]
   4163c:	ldur	x19, [sp, #0x78]
   41640:	str	x19, [x23, #0x6738]
   41644:	ldur	x26, [sp, #0x80]
   41648:	str	x26, [x23, #0x6740]
   4164c:	str	x12, [x23, #0x6750]
   41650:	str	x11, [x23, #0x6758]
   41654:	str	x7, [x23, #0x6768]
   41658:	str	x6, [x23, #0x6770]
   4165c:	b	0x43a18
   41660:	mov	x0, #0x69e
   41664:	ldur	x26, [sp]
   41668:	str	x0, [x26, #0x48]
   4166c:	mov	x8, #0x0
   41670:	str	x8, [x23, #0x18]
   41674:	mov	x0, #0x1000000000000000
   41678:	str	x0, [x23, #0x20]
   4167c:	mov	x0, #0x1
   41680:	str	x0, [x23, #0x30]
   41684:	mov	x9, #0x101010101010101
   41688:	str	x9, [x23, #0x38]
   4168c:	mov	x20, #0x2
   41690:	str	x20, [x23, #0x40]
   41694:	mov	x9, #0x3
   41698:	str	x9, [x23, #0x48]
   4169c:	mov	x9, #0x4
   416a0:	str	x9, [x23, #0x50]
   416a4:	mov	x9, #0xf0f0f0f0f0f0f0f
   416a8:	str	x9, [x23, #0x78]
   416ac:	mov	x9, #0x3333333333333333
   416b0:	str	x9, [x23, #0x88]
   416b4:	mov	x9, #0x38
   416b8:	str	x9, [x23, #0x90]
   416bc:	mov	x9, #0x3a
   416c0:	str	x9, [x23, #0x98]
   416c4:	mov	x9, #0x5555555555555555
   416c8:	str	x9, [x23, #0xb0]
   416cc:	mov	x9, #0x3ffffffffffffff
   416d0:	str	x9, [x23, #0xb8]
   416d4:	str	x8, [x23, #0x188]
   416d8:	str	x0, [x23, #0x190]
   416dc:	ldur	x27, [sp, #0xb8]
   416e0:	str	x27, [x23, #0x22e0]
   416e4:	ldr	x28, [sp, #0x190]
   416e8:	str	x28, [x23, #0x22e8]
   416ec:	uxtb	w1, w1
   416f0:	str	x1, [x23, #0x22f8]
   416f4:	ldur	x1, [sp, #0xa8]
   416f8:	str	x1, [x23, #0x2398]
   416fc:	ldur	x15, [sp, #0xf0]
   41700:	str	x15, [x23, #0x23a0]
   41704:	str	x27, [x23, #0x23a8]
   41708:	ldur	x15, [sp, #0xe8]
   4170c:	str	x15, [x23, #0x23b0]
   41710:	uxtb	w1, w4
   41714:	str	x1, [x23, #0x23c0]
   41718:	str	x2, [x23, #0x23d8]
   4171c:	str	x5, [x23, #0x23e0]
   41720:	ldur	x10, [sp, #0x58]
   41724:	str	x10, [x23, #0x5788]
   41728:	mov	w2, #0x2166
   4172c:	movk	w2, #0x1, lsl #16
   41730:	sub	x2, x3, x2
   41734:	str	x2, [x23, #0x5790]
   41738:	ldur	x4, [sp, #0x60]
   4173c:	str	x4, [x23, #0x5798]
   41740:	str	x27, [x23, #0x5ac0]
   41744:	str	x28, [x23, #0x5ac8]
   41748:	ldur	x1, [sp, #0xa8]
   4174c:	str	x1, [x23, #0x5c10]
   41750:	ldur	x15, [sp, #0xf0]
   41754:	str	x15, [x23, #0x5c18]
   41758:	str	x27, [x23, #0x5c20]
   4175c:	ldur	x15, [sp, #0xe8]
   41760:	str	x15, [x23, #0x5c28]
   41764:	ldur	x24, [sp, #0x10]
   41768:	str	x24, [x23, #0x5c30]
   4176c:	ldur	x21, [sp, #0x30]
   41770:	str	x21, [x23, #0x5c38]
   41774:	ldur	x13, [sp, #0x38]
   41778:	str	x13, [x23, #0x5c40]
   4177c:	ldur	x22, [sp, #0x40]
   41780:	str	x22, [x23, #0x5c48]
   41784:	ldur	x1, [sp, #0x48]
   41788:	str	x1, [x23, #0x5c50]
   4178c:	ldur	x1, [sp, #0x28]
   41790:	str	x1, [x23, #0x6570]
   41794:	add	x1, x14, #0x1
   41798:	str	x1, [x23, #0x6700]
   4179c:	ldur	x24, [sp, #0x68]
   417a0:	str	x24, [x23, #0x6708]
   417a4:	ldur	x25, [sp, #0x70]
   417a8:	str	x25, [x23, #0x6710]
   417ac:	ldur	x4, [sp, #0x50]
   417b0:	sub	x2, x4, x2
   417b4:	mov	w3, #0xc87e
   417b8:	movk	w3, #0x1, lsl #16
   417bc:	msub	x1, x1, x3, x2
   417c0:	str	x1, [x23, #0x6718]
   417c4:	str	x0, [x23, #0x6720]
   417c8:	ldur	x13, [sp, #0x18]
   417cc:	str	x13, [x23, #0x6728]
   417d0:	ldur	x19, [sp, #0x78]
   417d4:	str	x19, [x23, #0x6738]
   417d8:	ldur	x26, [sp, #0x80]
   417dc:	str	x26, [x23, #0x6740]
   417e0:	str	x12, [x23, #0x6750]
   417e4:	str	x11, [x23, #0x6758]
   417e8:	str	x7, [x23, #0x6768]
   417ec:	str	x6, [x23, #0x6770]
   417f0:	ldr	x0, [x23, #0x5788]
   417f4:	cmp	x0, #0x0
   417f8:	b.ne	0x3d1a0
   417fc:	b	0x3d3cc
   41800:	stur	x20, [sp, #0xc0]
   41804:	b	0x43a18
   41808:	stur	x20, [sp, #0xc0]
   4180c:	b	0x43a18
   41810:	mov	x0, #0x6a0
   41814:	ldur	x26, [sp]
   41818:	str	x0, [x26, #0x48]
   4181c:	mov	x4, #0x0
   41820:	str	x4, [x23, #0x18]
   41824:	mov	x0, #0x1000000000000000
   41828:	str	x0, [x23, #0x20]
   4182c:	mov	x0, #0x1
   41830:	str	x0, [x23, #0x30]
   41834:	mov	x5, #0x101010101010101
   41838:	str	x5, [x23, #0x38]
   4183c:	mov	x21, #0x2
   41840:	str	x21, [x23, #0x40]
   41844:	mov	x5, #0x3
   41848:	str	x5, [x23, #0x48]
   4184c:	mov	x5, #0x4
   41850:	str	x5, [x23, #0x50]
   41854:	mov	x5, #0xf0f0f0f0f0f0f0f
   41858:	str	x5, [x23, #0x78]
   4185c:	mov	x5, #0x3333333333333333
   41860:	str	x5, [x23, #0x88]
   41864:	mov	x5, #0x38
   41868:	str	x5, [x23, #0x90]
   4186c:	mov	x5, #0x3a
   41870:	str	x5, [x23, #0x98]
   41874:	mov	x5, #0x5555555555555555
   41878:	str	x5, [x23, #0xb0]
   4187c:	mov	x5, #0x3ffffffffffffff
   41880:	str	x5, [x23, #0xb8]
   41884:	str	x4, [x23, #0x188]
   41888:	str	x0, [x23, #0x190]
   4188c:	ldur	x27, [sp, #0xb8]
   41890:	str	x27, [x23, #0x22e0]
   41894:	ldr	x28, [sp, #0x190]
   41898:	str	x28, [x23, #0x22e8]
   4189c:	uxtb	w1, w1
   418a0:	str	x1, [x23, #0x22f8]
   418a4:	ldur	x1, [sp, #0xa8]
   418a8:	str	x1, [x23, #0x2398]
   418ac:	ldur	x15, [sp, #0xf0]
   418b0:	str	x15, [x23, #0x23a0]
   418b4:	str	x27, [x23, #0x23a8]
   418b8:	ldur	x15, [sp, #0xe8]
   418bc:	str	x15, [x23, #0x23b0]
   418c0:	ldur	x8, [sp, #0xe0]
   418c4:	uxtb	w4, w8
   418c8:	str	x4, [x23, #0x23c0]
   418cc:	str	x20, [x23, #0x23e8]
   418d0:	add	x8, x2, #0x2
   418d4:	str	x8, [x23, #0x23f0]
   418d8:	ldur	x10, [sp, #0x58]
   418dc:	str	x10, [x23, #0x5788]
   418e0:	mov	w8, #0x2166
   418e4:	movk	w8, #0x1, lsl #16
   418e8:	sub	x8, x3, x8
   418ec:	str	x8, [x23, #0x5790]
   418f0:	ldur	x4, [sp, #0x60]
   418f4:	str	x4, [x23, #0x5798]
   418f8:	str	x27, [x23, #0x5ac0]
   418fc:	str	x28, [x23, #0x5ac8]
   41900:	ldur	x5, [sp, #0xa8]
   41904:	str	x5, [x23, #0x5c10]
   41908:	ldur	x15, [sp, #0xf0]
   4190c:	str	x15, [x23, #0x5c18]
   41910:	str	x27, [x23, #0x5c20]
   41914:	ldur	x15, [sp, #0xe8]
   41918:	str	x15, [x23, #0x5c28]
   4191c:	ldur	x24, [sp, #0x10]
   41920:	str	x24, [x23, #0x5c30]
   41924:	ldur	x1, [sp, #0x30]
   41928:	str	x1, [x23, #0x5c38]
   4192c:	ldur	x24, [sp, #0x38]
   41930:	str	x24, [x23, #0x5c40]
   41934:	ldur	x22, [sp, #0x40]
   41938:	str	x22, [x23, #0x5c48]
   4193c:	ldur	x20, [sp, #0x48]
   41940:	str	x20, [x23, #0x5c50]
   41944:	ldur	x1, [sp, #0x28]
   41948:	str	x1, [x23, #0x6570]
   4194c:	add	x1, x14, #0x1
   41950:	str	x1, [x23, #0x6700]
   41954:	ldur	x24, [sp, #0x68]
   41958:	str	x24, [x23, #0x6708]
   4195c:	ldur	x25, [sp, #0x70]
   41960:	str	x25, [x23, #0x6710]
   41964:	ldur	x4, [sp, #0x50]
   41968:	sub	x2, x4, x8
   4196c:	mov	w3, #0xc87e
   41970:	movk	w3, #0x1, lsl #16
   41974:	msub	x1, x1, x3, x2
   41978:	str	x1, [x23, #0x6718]
   4197c:	str	x0, [x23, #0x6720]
   41980:	ldur	x13, [sp, #0x18]
   41984:	str	x13, [x23, #0x6728]
   41988:	ldur	x19, [sp, #0x78]
   4198c:	str	x19, [x23, #0x6738]
   41990:	ldur	x26, [sp, #0x80]
   41994:	str	x26, [x23, #0x6740]
   41998:	str	x12, [x23, #0x6750]
   4199c:	str	x11, [x23, #0x6758]
   419a0:	str	x7, [x23, #0x6768]
   419a4:	str	x6, [x23, #0x6770]
   419a8:	ldr	x0, [x23, #0x5788]
   419ac:	cmp	x0, #0x0
   419b0:	b.ne	0x3d440
   419b4:	b	0x3d670
   419b8:	stur	x21, [sp, #0xc0]
   419bc:	b	0x43a18
   419c0:	stur	x21, [sp, #0xc0]
   419c4:	b	0x43a18
   419c8:	mov	x2, #0x6ba
   419cc:	ldur	x26, [sp]
   419d0:	str	x2, [x26, #0x48]
   419d4:	mov	x3, #0x0
   419d8:	str	x3, [x23, #0x18]
   419dc:	mov	x2, #0x1000000000000000
   419e0:	str	x2, [x23, #0x20]
   419e4:	mov	x2, #0x1
   419e8:	str	x2, [x23, #0x30]
   419ec:	mov	x4, #0x101010101010101
   419f0:	str	x4, [x23, #0x38]
   419f4:	mov	x22, #0x2
   419f8:	str	x22, [x23, #0x40]
   419fc:	mov	x4, #0x3
   41a00:	str	x4, [x23, #0x48]
   41a04:	mov	x4, #0x4
   41a08:	str	x4, [x23, #0x50]
   41a0c:	mov	x4, #0xf0f0f0f0f0f0f0f
   41a10:	str	x4, [x23, #0x78]
   41a14:	mov	x4, #0x3333333333333333
   41a18:	str	x4, [x23, #0x88]
   41a1c:	mov	x4, #0x38
   41a20:	str	x4, [x23, #0x90]
   41a24:	mov	x4, #0x3a
   41a28:	str	x4, [x23, #0x98]
   41a2c:	mov	x4, #0x5555555555555555
   41a30:	str	x4, [x23, #0xb0]
   41a34:	mov	x4, #0x3ffffffffffffff
   41a38:	str	x4, [x23, #0xb8]
   41a3c:	str	x3, [x23, #0x188]
   41a40:	str	x2, [x23, #0x190]
   41a44:	ldur	x27, [sp, #0xb8]
   41a48:	str	x27, [x23, #0x22e0]
   41a4c:	ldr	x28, [sp, #0x190]
   41a50:	str	x28, [x23, #0x22e8]
   41a54:	ldur	x3, [sp, #0xf8]
   41a58:	uxtb	w3, w3
   41a5c:	str	x3, [x23, #0x22f8]
   41a60:	ldur	x3, [sp, #0xa8]
   41a64:	str	x3, [x23, #0x2398]
   41a68:	ldur	x15, [sp, #0xf0]
   41a6c:	str	x15, [x23, #0x23a0]
   41a70:	str	x27, [x23, #0x23a8]
   41a74:	ldur	x15, [sp, #0xe8]
   41a78:	str	x15, [x23, #0x23b0]
   41a7c:	ldur	x24, [sp, #0xe0]
   41a80:	uxtb	w3, w24
   41a84:	str	x3, [x23, #0x23c0]
   41a88:	str	x20, [x23, #0x2458]
   41a8c:	str	x10, [x23, #0x2460]
   41a90:	str	x27, [x23, #0x2468]
   41a94:	str	x15, [x23, #0x2470]
   41a98:	uxtb	w1, w1
   41a9c:	str	x1, [x23, #0x2480]
   41aa0:	add	x1, x20, #0x1
   41aa4:	str	x1, [x23, #0x2490]
   41aa8:	ldur	x1, [sp, #0x58]
   41aac:	str	x1, [x23, #0x5788]
   41ab0:	mov	w1, #0xdc1e
   41ab4:	movk	w1, #0x2, lsl #16
   41ab8:	sub	x1, x9, x1
   41abc:	str	x1, [x23, #0x5790]
   41ac0:	ldur	x4, [sp, #0x60]
   41ac4:	str	x4, [x23, #0x5798]
   41ac8:	str	x27, [x23, #0x5ac0]
   41acc:	str	x28, [x23, #0x5ac8]
   41ad0:	ldur	x3, [sp, #0xa8]
   41ad4:	str	x3, [x23, #0x5c10]
   41ad8:	ldur	x15, [sp, #0xf0]
   41adc:	str	x15, [x23, #0x5c18]
   41ae0:	str	x27, [x23, #0x5c20]
   41ae4:	ldur	x15, [sp, #0xe8]
   41ae8:	str	x15, [x23, #0x5c28]
   41aec:	ldur	x24, [sp, #0x10]
   41af0:	str	x24, [x23, #0x5c30]
   41af4:	ldur	x21, [sp, #0x30]
   41af8:	str	x21, [x23, #0x5c38]
   41afc:	ldur	x24, [sp, #0x38]
   41b00:	str	x24, [x23, #0x5c40]
   41b04:	ldur	x3, [sp, #0x40]
   41b08:	str	x3, [x23, #0x5c48]
   41b0c:	ldur	x3, [sp, #0x48]
   41b10:	str	x3, [x23, #0x5c50]
   41b14:	str	x20, [x23, #0x5df8]
   41b18:	str	x10, [x23, #0x5e00]
   41b1c:	str	x27, [x23, #0x5e08]
   41b20:	str	x15, [x23, #0x5e10]
   41b24:	str	x0, [x23, #0x5e18]
   41b28:	mov	x0, x8
   41b2c:	str	x0, [x23, #0x5e20]
   41b30:	mov	x15, x5
   41b34:	str	x15, [x23, #0x5e28]
   41b38:	mov	x15, x19
   41b3c:	str	x15, [x23, #0x5e30]
   41b40:	ldur	x0, [sp, #0xa0]
   41b44:	str	x0, [x23, #0x5e38]
   41b48:	ldur	x0, [sp, #0x28]
   41b4c:	str	x0, [x23, #0x6570]
   41b50:	add	x8, x14, #0x1
   41b54:	str	x8, [x23, #0x6700]
   41b58:	ldur	x24, [sp, #0x68]
   41b5c:	str	x24, [x23, #0x6708]
   41b60:	ldur	x25, [sp, #0x70]
   41b64:	str	x25, [x23, #0x6710]
   41b68:	ldur	x4, [sp, #0x50]
   41b6c:	sub	x13, x4, x1
   41b70:	mov	w14, #0xc87e
   41b74:	movk	w14, #0x1, lsl #16
   41b78:	msub	x13, x8, x14, x13
   41b7c:	str	x13, [x23, #0x6718]
   41b80:	str	x2, [x23, #0x6720]
   41b84:	ldur	x13, [sp, #0x18]
   41b88:	str	x13, [x23, #0x6728]
   41b8c:	str	x2, [x23, #0x6738]
   41b90:	ldur	x3, [sp, #0xb0]
   41b94:	str	x3, [x23, #0x6740]
   41b98:	str	x12, [x23, #0x6750]
   41b9c:	str	x11, [x23, #0x6758]
   41ba0:	str	x7, [x23, #0x6768]
   41ba4:	str	x6, [x23, #0x6770]
   41ba8:	ldr	x0, [x23, #0x5788]
   41bac:	cmp	x0, #0x0
   41bb0:	b.ne	0x3d7b8
   41bb4:	b	0x3d9d8
   41bb8:	stur	x22, [sp, #0xc0]
   41bbc:	b	0x43a18
   41bc0:	stur	x22, [sp, #0xc0]
   41bc4:	b	0x43a18
   41bc8:	mov	x0, #0x6c0
   41bcc:	ldur	x26, [sp]
   41bd0:	str	x0, [x26, #0x48]
   41bd4:	mov	x4, #0x0
   41bd8:	str	x4, [x23, #0x18]
   41bdc:	mov	x0, #0x1000000000000000
   41be0:	str	x0, [x23, #0x20]
   41be4:	mov	x0, #0x1
   41be8:	stur	x0, [sp, #0xc0]
   41bec:	str	x0, [x23, #0x30]
   41bf0:	mov	x0, #0x101010101010101
   41bf4:	str	x0, [x23, #0x38]
   41bf8:	mov	x0, #0x2
   41bfc:	str	x0, [x23, #0x40]
   41c00:	mov	x0, #0x3
   41c04:	str	x0, [x23, #0x48]
   41c08:	mov	x0, #0x4
   41c0c:	str	x0, [x23, #0x50]
   41c10:	mov	x0, #0xf0f0f0f0f0f0f0f
   41c14:	str	x0, [x23, #0x78]
   41c18:	mov	x0, #0x3333333333333333
   41c1c:	str	x0, [x23, #0x88]
   41c20:	mov	x0, #0x38
   41c24:	str	x0, [x23, #0x90]
   41c28:	mov	x0, #0x3a
   41c2c:	str	x0, [x23, #0x98]
   41c30:	mov	x0, #0x5555555555555555
   41c34:	str	x0, [x23, #0xb0]
   41c38:	mov	x0, #0x3ffffffffffffff
   41c3c:	str	x0, [x23, #0xb8]
   41c40:	str	x4, [x23, #0x188]
   41c44:	ldur	x0, [sp, #0xc0]
   41c48:	str	x0, [x23, #0x190]
   41c4c:	ldur	x27, [sp, #0xb8]
   41c50:	str	x27, [x23, #0x22e0]
   41c54:	ldr	x28, [sp, #0x190]
   41c58:	str	x28, [x23, #0x22e8]
   41c5c:	ldur	x0, [sp, #0xf8]
   41c60:	uxtb	w0, w0
   41c64:	str	x0, [x23, #0x22f8]
   41c68:	ldur	x0, [sp, #0xa8]
   41c6c:	str	x0, [x23, #0x2398]
   41c70:	ldur	x15, [sp, #0xf0]
   41c74:	str	x15, [x23, #0x23a0]
   41c78:	str	x27, [x23, #0x23a8]
   41c7c:	ldur	x15, [sp, #0xe8]
   41c80:	str	x15, [x23, #0x23b0]
   41c84:	ldur	x24, [sp, #0xe0]
   41c88:	uxtb	w3, w24
   41c8c:	str	x3, [x23, #0x23c0]
   41c90:	str	x20, [x23, #0x2458]
   41c94:	str	x10, [x23, #0x2460]
   41c98:	str	x27, [x23, #0x2468]
   41c9c:	str	x15, [x23, #0x2470]
   41ca0:	uxtb	w8, w1
   41ca4:	str	x8, [x23, #0x2480]
   41ca8:	str	x2, [x23, #0x2498]
   41cac:	ldur	x10, [sp, #0x58]
   41cb0:	str	x10, [x23, #0x5788]
   41cb4:	mov	w10, #0xdc1e
   41cb8:	movk	w10, #0x2, lsl #16
   41cbc:	sub	x9, x9, x10
   41cc0:	str	x9, [x23, #0x5790]
   41cc4:	ldur	x4, [sp, #0x60]
   41cc8:	str	x4, [x23, #0x5798]
   41ccc:	ldur	x1, [sp, #0x28]
   41cd0:	str	x1, [x23, #0x6570]
   41cd4:	add	x13, x14, #0x1
   41cd8:	str	x13, [x23, #0x6700]
   41cdc:	ldur	x24, [sp, #0x68]
   41ce0:	str	x24, [x23, #0x6708]
   41ce4:	ldur	x25, [sp, #0x70]
   41ce8:	str	x25, [x23, #0x6710]
   41cec:	ldur	x4, [sp, #0x50]
   41cf0:	sub	x15, x4, x9
   41cf4:	mov	w1, #0xc87e
   41cf8:	movk	w1, #0x1, lsl #16
   41cfc:	msub	x15, x13, x1, x15
   41d00:	str	x15, [x23, #0x6718]
   41d04:	ldur	x0, [sp, #0xc0]
   41d08:	str	x0, [x23, #0x6720]
   41d0c:	ldur	x13, [sp, #0x18]
   41d10:	str	x13, [x23, #0x6728]
   41d14:	str	x0, [x23, #0x6738]
   41d18:	ldur	x3, [sp, #0xb0]
   41d1c:	str	x3, [x23, #0x6740]
   41d20:	str	x12, [x23, #0x6750]
   41d24:	str	x11, [x23, #0x6758]
   41d28:	str	x7, [x23, #0x6768]
   41d2c:	str	x6, [x23, #0x6770]
   41d30:	b	0x43a18
   41d34:	mov	x3, #0x6c1
   41d38:	ldur	x26, [sp]
   41d3c:	str	x3, [x26, #0x48]
   41d40:	mov	x5, #0x0
   41d44:	str	x5, [x23, #0x18]
   41d48:	mov	x3, #0x1000000000000000
   41d4c:	str	x3, [x23, #0x20]
   41d50:	mov	x8, #0x1
   41d54:	str	x8, [x23, #0x30]
   41d58:	mov	x3, #0x101010101010101
   41d5c:	str	x3, [x23, #0x38]
   41d60:	mov	x21, #0x2
   41d64:	str	x21, [x23, #0x40]
   41d68:	mov	x3, #0x3
   41d6c:	str	x3, [x23, #0x48]
   41d70:	mov	x3, #0x4
   41d74:	str	x3, [x23, #0x50]
   41d78:	mov	x3, #0xf0f0f0f0f0f0f0f
   41d7c:	str	x3, [x23, #0x78]
   41d80:	mov	x3, #0x3333333333333333
   41d84:	str	x3, [x23, #0x88]
   41d88:	mov	x3, #0x38
   41d8c:	str	x3, [x23, #0x90]
   41d90:	mov	x3, #0x3a
   41d94:	str	x3, [x23, #0x98]
   41d98:	mov	x3, #0x5555555555555555
   41d9c:	str	x3, [x23, #0xb0]
   41da0:	mov	x3, #0x3ffffffffffffff
   41da4:	str	x3, [x23, #0xb8]
   41da8:	str	x5, [x23, #0x188]
   41dac:	str	x8, [x23, #0x190]
   41db0:	ldur	x27, [sp, #0xb8]
   41db4:	str	x27, [x23, #0x22e0]
   41db8:	ldr	x28, [sp, #0x190]
   41dbc:	str	x28, [x23, #0x22e8]
   41dc0:	ldur	x3, [sp, #0xf8]
   41dc4:	uxtb	w3, w3
   41dc8:	str	x3, [x23, #0x22f8]
   41dcc:	ldur	x3, [sp, #0xa8]
   41dd0:	str	x3, [x23, #0x2398]
   41dd4:	ldur	x3, [sp, #0xf0]
   41dd8:	str	x3, [x23, #0x23a0]
   41ddc:	str	x27, [x23, #0x23a8]
   41de0:	ldur	x3, [sp, #0xe8]
   41de4:	str	x3, [x23, #0x23b0]
   41de8:	ldur	x24, [sp, #0xe0]
   41dec:	uxtb	w3, w24
   41df0:	str	x3, [x23, #0x23c0]
   41df4:	str	x20, [x23, #0x2458]
   41df8:	str	x10, [x23, #0x2460]
   41dfc:	str	x27, [x23, #0x2468]
   41e00:	ldur	x13, [sp, #0xe8]
   41e04:	str	x13, [x23, #0x2470]
   41e08:	uxtb	w1, w1
   41e0c:	str	x1, [x23, #0x2480]
   41e10:	str	x2, [x23, #0x2498]
   41e14:	str	x4, [x23, #0x24b0]
   41e18:	ldur	x1, [sp, #0x58]
   41e1c:	str	x1, [x23, #0x5788]
   41e20:	mov	w1, #0xdc1e
   41e24:	movk	w1, #0x2, lsl #16
   41e28:	sub	x1, x9, x1
   41e2c:	str	x1, [x23, #0x5790]
   41e30:	ldur	x4, [sp, #0x60]
   41e34:	str	x4, [x23, #0x5798]
   41e38:	str	x27, [x23, #0x5ac0]
   41e3c:	str	x28, [x23, #0x5ac8]
   41e40:	ldur	x2, [sp, #0xa8]
   41e44:	str	x2, [x23, #0x5c10]
   41e48:	ldur	x2, [sp, #0xf0]
   41e4c:	str	x2, [x23, #0x5c18]
   41e50:	str	x27, [x23, #0x5c20]
   41e54:	ldur	x2, [sp, #0xe8]
   41e58:	str	x2, [x23, #0x5c28]
   41e5c:	ldur	x24, [sp, #0x10]
   41e60:	str	x24, [x23, #0x5c30]
   41e64:	ldur	x2, [sp, #0x30]
   41e68:	str	x2, [x23, #0x5c38]
   41e6c:	ldur	x24, [sp, #0x38]
   41e70:	str	x24, [x23, #0x5c40]
   41e74:	ldur	x22, [sp, #0x40]
   41e78:	str	x22, [x23, #0x5c48]
   41e7c:	ldur	x2, [sp, #0x48]
   41e80:	str	x2, [x23, #0x5c50]
   41e84:	str	x20, [x23, #0x5df8]
   41e88:	str	x10, [x23, #0x5e00]
   41e8c:	str	x27, [x23, #0x5e08]
   41e90:	ldur	x2, [sp, #0xe8]
   41e94:	str	x2, [x23, #0x5e10]
   41e98:	ldur	x5, [sp, #0x98]
   41e9c:	str	x5, [x23, #0x5e18]
   41ea0:	str	x0, [x23, #0x5e20]
   41ea4:	str	x15, [x23, #0x5e28]
   41ea8:	mov	x4, x19
   41eac:	str	x4, [x23, #0x5e30]
   41eb0:	ldur	x24, [sp, #0xa0]
   41eb4:	str	x24, [x23, #0x5e38]
   41eb8:	ldur	x0, [sp, #0x28]
   41ebc:	str	x0, [x23, #0x6570]
   41ec0:	add	x0, x14, #0x1
   41ec4:	str	x0, [x23, #0x6700]
   41ec8:	ldur	x24, [sp, #0x68]
   41ecc:	str	x24, [x23, #0x6708]
   41ed0:	ldur	x25, [sp, #0x70]
   41ed4:	str	x25, [x23, #0x6710]
   41ed8:	ldur	x4, [sp, #0x50]
   41edc:	sub	x1, x4, x1
   41ee0:	mov	w2, #0xc87e
   41ee4:	movk	w2, #0x1, lsl #16
   41ee8:	msub	x0, x0, x2, x1
   41eec:	str	x0, [x23, #0x6718]
   41ef0:	str	x8, [x23, #0x6720]
   41ef4:	ldur	x13, [sp, #0x18]
   41ef8:	str	x13, [x23, #0x6728]
   41efc:	str	x8, [x23, #0x6738]
   41f00:	ldur	x3, [sp, #0xb0]
   41f04:	str	x3, [x23, #0x6740]
   41f08:	str	x12, [x23, #0x6750]
   41f0c:	str	x11, [x23, #0x6758]
   41f10:	str	x7, [x23, #0x6768]
   41f14:	str	x6, [x23, #0x6770]
   41f18:	ldr	x0, [x23, #0x5788]
   41f1c:	cmp	x0, #0x0
   41f20:	b.ne	0x3da90
   41f24:	b	0x3dcb8
   41f28:	stur	x21, [sp, #0xc0]
   41f2c:	b	0x43a18
   41f30:	stur	x21, [sp, #0xc0]
   41f34:	b	0x43a18
   41f38:	mov	x8, #0x73b
   41f3c:	ldur	x26, [sp]
   41f40:	str	x8, [x26, #0x48]
   41f44:	mov	x13, #0x0
   41f48:	str	x13, [x23, #0x18]
   41f4c:	mov	x15, #0x1000000000000000
   41f50:	str	x15, [x23, #0x20]
   41f54:	mov	x0, #0x1
   41f58:	stur	x0, [sp, #0xc0]
   41f5c:	str	x0, [x23, #0x30]
   41f60:	mov	x15, #0x101010101010101
   41f64:	str	x15, [x23, #0x38]
   41f68:	mov	x15, #0x2
   41f6c:	str	x15, [x23, #0x40]
   41f70:	mov	x15, #0x3
   41f74:	str	x15, [x23, #0x48]
   41f78:	mov	x15, #0x4
   41f7c:	str	x15, [x23, #0x50]
   41f80:	mov	x0, #0xf0f0f0f0f0f0f0f
   41f84:	str	x0, [x23, #0x78]
   41f88:	mov	x0, #0x3333333333333333
   41f8c:	str	x0, [x23, #0x88]
   41f90:	mov	x0, #0x38
   41f94:	str	x0, [x23, #0x90]
   41f98:	mov	x0, #0x3a
   41f9c:	str	x0, [x23, #0x98]
   41fa0:	mov	x0, #0x5555555555555555
   41fa4:	str	x0, [x23, #0xb0]
   41fa8:	mov	x0, #0x3ffffffffffffff
   41fac:	str	x0, [x23, #0xb8]
   41fb0:	str	x13, [x23, #0x188]
   41fb4:	ldur	x0, [sp, #0xc0]
   41fb8:	str	x0, [x23, #0x190]
   41fbc:	ldur	x27, [sp, #0xb8]
   41fc0:	str	x27, [x23, #0x22e0]
   41fc4:	ldr	x28, [sp, #0x190]
   41fc8:	str	x28, [x23, #0x22e8]
   41fcc:	ldur	x0, [sp, #0xf8]
   41fd0:	uxtb	w0, w0
   41fd4:	str	x0, [x23, #0x22f8]
   41fd8:	ldur	x0, [sp, #0xa8]
   41fdc:	str	x0, [x23, #0x2398]
   41fe0:	ldur	x15, [sp, #0xf0]
   41fe4:	str	x15, [x23, #0x23a0]
   41fe8:	str	x27, [x23, #0x23a8]
   41fec:	ldur	x15, [sp, #0xe8]
   41ff0:	str	x15, [x23, #0x23b0]
   41ff4:	ldur	x24, [sp, #0xe0]
   41ff8:	uxtb	w0, w24
   41ffc:	str	x0, [x23, #0x23c0]
   42000:	str	x2, [x23, #0x2458]
   42004:	str	x10, [x23, #0x2460]
   42008:	str	x27, [x23, #0x2468]
   4200c:	str	x15, [x23, #0x2470]
   42010:	ldur	x10, [sp, #0x58]
   42014:	str	x10, [x23, #0x5788]
   42018:	mov	w1, #0xdc1e
   4201c:	movk	w1, #0x2, lsl #16
   42020:	sub	x1, x9, x1
   42024:	str	x1, [x23, #0x5790]
   42028:	ldur	x4, [sp, #0x60]
   4202c:	str	x4, [x23, #0x5798]
   42030:	ldur	x8, [sp, #0x28]
   42034:	str	x8, [x23, #0x6570]
   42038:	add	x2, x14, #0x1
   4203c:	str	x2, [x23, #0x6700]
   42040:	ldur	x24, [sp, #0x68]
   42044:	str	x24, [x23, #0x6708]
   42048:	ldur	x25, [sp, #0x70]
   4204c:	str	x25, [x23, #0x6710]
   42050:	ldur	x4, [sp, #0x50]
   42054:	sub	x1, x4, x1
   42058:	mov	w3, #0xc87e
   4205c:	movk	w3, #0x1, lsl #16
   42060:	msub	x0, x2, x3, x1
   42064:	str	x0, [x23, #0x6718]
   42068:	ldur	x0, [sp, #0xc0]
   4206c:	str	x0, [x23, #0x6720]
   42070:	ldur	x13, [sp, #0x18]
   42074:	str	x13, [x23, #0x6728]
   42078:	str	x0, [x23, #0x6738]
   4207c:	ldur	x3, [sp, #0xb0]
   42080:	str	x3, [x23, #0x6740]
   42084:	str	x12, [x23, #0x6750]
   42088:	str	x11, [x23, #0x6758]
   4208c:	str	x7, [x23, #0x6768]
   42090:	str	x6, [x23, #0x6770]
   42094:	b	0x43a18
   42098:	ldur	x0, [sp, #0xd8]
   4209c:	stur	x0, [sp, #0xc0]
   420a0:	b	0x43a18
   420a4:	mov	x0, #0x6c0
   420a8:	ldur	x26, [sp]
   420ac:	str	x0, [x26, #0x48]
   420b0:	mov	x1, #0x0
   420b4:	str	x1, [x23, #0x18]
   420b8:	mov	x0, #0x1000000000000000
   420bc:	str	x0, [x23, #0x20]
   420c0:	mov	x0, #0x1
   420c4:	stur	x0, [sp, #0xc0]
   420c8:	str	x0, [x23, #0x30]
   420cc:	mov	x0, #0x101010101010101
   420d0:	str	x0, [x23, #0x38]
   420d4:	mov	x0, #0x2
   420d8:	str	x0, [x23, #0x40]
   420dc:	mov	x0, #0x3
   420e0:	str	x0, [x23, #0x48]
   420e4:	mov	x0, #0x4
   420e8:	str	x0, [x23, #0x50]
   420ec:	mov	x0, #0xf0f0f0f0f0f0f0f
   420f0:	str	x0, [x23, #0x78]
   420f4:	mov	x0, #0x3333333333333333
   420f8:	str	x0, [x23, #0x88]
   420fc:	mov	x0, #0x38
   42100:	str	x0, [x23, #0x90]
   42104:	mov	x0, #0x3a
   42108:	str	x0, [x23, #0x98]
   4210c:	mov	x0, #0x5555555555555555
   42110:	str	x0, [x23, #0xb0]
   42114:	mov	x0, #0x3ffffffffffffff
   42118:	str	x0, [x23, #0xb8]
   4211c:	str	x1, [x23, #0x188]
   42120:	ldur	x0, [sp, #0xc0]
   42124:	str	x0, [x23, #0x190]
   42128:	ldur	x27, [sp, #0xb8]
   4212c:	str	x27, [x23, #0x22e0]
   42130:	ldr	x28, [sp, #0x190]
   42134:	str	x28, [x23, #0x22e8]
   42138:	ldur	x0, [sp, #0xf8]
   4213c:	uxtb	w0, w0
   42140:	str	x0, [x23, #0x22f8]
   42144:	ldur	x0, [sp, #0xa8]
   42148:	str	x0, [x23, #0x2398]
   4214c:	ldur	x15, [sp, #0xf0]
   42150:	str	x15, [x23, #0x23a0]
   42154:	str	x27, [x23, #0x23a8]
   42158:	ldur	x15, [sp, #0xe8]
   4215c:	str	x15, [x23, #0x23b0]
   42160:	ldur	x24, [sp, #0xe0]
   42164:	uxtb	w0, w24
   42168:	str	x0, [x23, #0x23c0]
   4216c:	str	x20, [x23, #0x2458]
   42170:	str	x10, [x23, #0x2460]
   42174:	str	x27, [x23, #0x2468]
   42178:	str	x15, [x23, #0x2470]
   4217c:	uxtb	w0, w8
   42180:	str	x0, [x23, #0x2480]
   42184:	str	x2, [x23, #0x2498]
   42188:	ldur	x10, [sp, #0x58]
   4218c:	str	x10, [x23, #0x5788]
   42190:	mov	w3, #0xdc1e
   42194:	movk	w3, #0x2, lsl #16
   42198:	sub	x3, x9, x3
   4219c:	str	x3, [x23, #0x5790]
   421a0:	ldur	x4, [sp, #0x60]
   421a4:	str	x4, [x23, #0x5798]
   421a8:	ldur	x1, [sp, #0x28]
   421ac:	str	x1, [x23, #0x6570]
   421b0:	add	x8, x14, #0x1
   421b4:	str	x8, [x23, #0x6700]
   421b8:	ldur	x24, [sp, #0x68]
   421bc:	str	x24, [x23, #0x6708]
   421c0:	ldur	x25, [sp, #0x70]
   421c4:	str	x25, [x23, #0x6710]
   421c8:	ldur	x4, [sp, #0x50]
   421cc:	sub	x9, x4, x3
   421d0:	mov	w10, #0xc87e
   421d4:	movk	w10, #0x1, lsl #16
   421d8:	msub	x9, x8, x10, x9
   421dc:	str	x9, [x23, #0x6718]
   421e0:	ldur	x0, [sp, #0xc0]
   421e4:	str	x0, [x23, #0x6720]
   421e8:	ldur	x13, [sp, #0x18]
   421ec:	str	x13, [x23, #0x6728]
   421f0:	str	x0, [x23, #0x6738]
   421f4:	ldur	x3, [sp, #0xb0]
   421f8:	str	x3, [x23, #0x6740]
   421fc:	str	x12, [x23, #0x6750]
   42200:	str	x11, [x23, #0x6758]
   42204:	str	x7, [x23, #0x6768]
   42208:	str	x6, [x23, #0x6770]
   4220c:	b	0x43a18
   42210:	mov	x1, #0x6c1
   42214:	ldur	x26, [sp]
   42218:	str	x1, [x26, #0x48]
   4221c:	mov	x19, x1
   42220:	mov	x1, #0x0
   42224:	str	x1, [x23, #0x18]
   42228:	mov	x3, #0x1000000000000000
   4222c:	str	x3, [x23, #0x20]
   42230:	mov	x13, #0x1
   42234:	str	x13, [x23, #0x30]
   42238:	mov	x3, #0x101010101010101
   4223c:	str	x3, [x23, #0x38]
   42240:	mov	x27, #0x2
   42244:	str	x27, [x23, #0x40]
   42248:	mov	x3, #0x3
   4224c:	str	x3, [x23, #0x48]
   42250:	mov	x3, #0x4
   42254:	str	x3, [x23, #0x50]
   42258:	mov	x3, #0xf0f0f0f0f0f0f0f
   4225c:	str	x3, [x23, #0x78]
   42260:	mov	x3, #0x3333333333333333
   42264:	str	x3, [x23, #0x88]
   42268:	mov	x3, #0x38
   4226c:	str	x3, [x23, #0x90]
   42270:	mov	x3, #0x3a
   42274:	str	x3, [x23, #0x98]
   42278:	mov	x3, #0x5555555555555555
   4227c:	str	x3, [x23, #0xb0]
   42280:	mov	x3, #0x3ffffffffffffff
   42284:	str	x3, [x23, #0xb8]
   42288:	str	x1, [x23, #0x188]
   4228c:	str	x13, [x23, #0x190]
   42290:	ldur	x1, [sp, #0xb8]
   42294:	str	x1, [x23, #0x22e0]
   42298:	ldr	x28, [sp, #0x190]
   4229c:	str	x28, [x23, #0x22e8]
   422a0:	ldur	x1, [sp, #0xf8]
   422a4:	uxtb	w1, w1
   422a8:	str	x1, [x23, #0x22f8]
   422ac:	ldur	x1, [sp, #0xa8]
   422b0:	str	x1, [x23, #0x2398]
   422b4:	ldur	x1, [sp, #0xf0]
   422b8:	str	x1, [x23, #0x23a0]
   422bc:	ldur	x1, [sp, #0xb8]
   422c0:	str	x1, [x23, #0x23a8]
   422c4:	ldur	x1, [sp, #0xe8]
   422c8:	str	x1, [x23, #0x23b0]
   422cc:	ldur	x24, [sp, #0xe0]
   422d0:	uxtb	w1, w24
   422d4:	str	x1, [x23, #0x23c0]
   422d8:	str	x20, [x23, #0x2458]
   422dc:	str	x10, [x23, #0x2460]
   422e0:	ldur	x3, [sp, #0xb8]
   422e4:	str	x3, [x23, #0x2468]
   422e8:	ldur	x1, [sp, #0xe8]
   422ec:	str	x1, [x23, #0x2470]
   422f0:	uxtb	w1, w8
   422f4:	str	x1, [x23, #0x2480]
   422f8:	str	x2, [x23, #0x2498]
   422fc:	str	x21, [x23, #0x24b0]
   42300:	ldur	x1, [sp, #0x58]
   42304:	str	x1, [x23, #0x5788]
   42308:	mov	w1, #0xdc1e
   4230c:	movk	w1, #0x2, lsl #16
   42310:	sub	x1, x9, x1
   42314:	str	x1, [x23, #0x5790]
   42318:	ldur	x2, [sp, #0x60]
   4231c:	str	x2, [x23, #0x5798]
   42320:	ldur	x2, [sp, #0xb8]
   42324:	str	x2, [x23, #0x5ac0]
   42328:	str	x28, [x23, #0x5ac8]
   4232c:	ldur	x2, [sp, #0xa8]
   42330:	str	x2, [x23, #0x5c10]
   42334:	ldur	x8, [sp, #0xf0]
   42338:	str	x8, [x23, #0x5c18]
   4233c:	ldur	x2, [sp, #0xb8]
   42340:	str	x2, [x23, #0x5c20]
   42344:	ldur	x2, [sp, #0xe8]
   42348:	str	x2, [x23, #0x5c28]
   4234c:	ldur	x24, [sp, #0x10]
   42350:	str	x24, [x23, #0x5c30]
   42354:	ldur	x21, [sp, #0x30]
   42358:	str	x21, [x23, #0x5c38]
   4235c:	ldur	x24, [sp, #0x38]
   42360:	str	x24, [x23, #0x5c40]
   42364:	ldur	x22, [sp, #0x40]
   42368:	str	x22, [x23, #0x5c48]
   4236c:	ldur	x2, [sp, #0x48]
   42370:	str	x2, [x23, #0x5c50]
   42374:	str	x20, [x23, #0x5df8]
   42378:	str	x10, [x23, #0x5e00]
   4237c:	ldur	x2, [sp, #0xb8]
   42380:	str	x2, [x23, #0x5e08]
   42384:	ldur	x2, [sp, #0xe8]
   42388:	str	x2, [x23, #0x5e10]
   4238c:	str	x5, [x23, #0x5e18]
   42390:	str	x0, [x23, #0x5e20]
   42394:	str	x15, [x23, #0x5e28]
   42398:	str	x4, [x23, #0x5e30]
   4239c:	ldur	x24, [sp, #0xa0]
   423a0:	str	x24, [x23, #0x5e38]
   423a4:	ldur	x2, [sp, #0x28]
   423a8:	str	x2, [x23, #0x6570]
   423ac:	add	x14, x14, #0x1
   423b0:	str	x14, [x23, #0x6700]
   423b4:	ldur	x24, [sp, #0x68]
   423b8:	str	x24, [x23, #0x6708]
   423bc:	ldur	x25, [sp, #0x70]
   423c0:	str	x25, [x23, #0x6710]
   423c4:	ldur	x4, [sp, #0x50]
   423c8:	sub	x0, x4, x1
   423cc:	mov	w1, #0xc87e
   423d0:	movk	w1, #0x1, lsl #16
   423d4:	msub	x0, x14, x1, x0
   423d8:	str	x0, [x23, #0x6718]
   423dc:	str	x13, [x23, #0x6720]
   423e0:	ldur	x8, [sp, #0x18]
   423e4:	str	x8, [x23, #0x6728]
   423e8:	str	x13, [x23, #0x6738]
   423ec:	ldur	x3, [sp, #0xb0]
   423f0:	str	x3, [x23, #0x6740]
   423f4:	str	x12, [x23, #0x6750]
   423f8:	str	x11, [x23, #0x6758]
   423fc:	str	x7, [x23, #0x6768]
   42400:	str	x6, [x23, #0x6770]
   42404:	ldr	x0, [x23, #0x5788]
   42408:	cmp	x0, #0x0
   4240c:	b.ne	0x3e348
   42410:	b	0x3e570
   42414:	stur	x27, [sp, #0xc0]
   42418:	b	0x43a18
   4241c:	stur	x27, [sp, #0xc0]
   42420:	b	0x43a18
   42424:	mov	x1, #0x0
   42428:	str	x1, [x22, #0x1530]
   4242c:	str	x1, [x22, #0x1538]
   42430:	str	x1, [x22, #0x1540]
   42434:	str	x1, [x22, #0x1548]
   42438:	str	x1, [x22, #0x1550]
   4243c:	str	x1, [x22, #0x1558]
   42440:	str	x1, [x22, #0x1560]
   42444:	str	x1, [x22, #0x1568]
   42448:	str	x1, [x22, #0x1570]
   4244c:	str	x1, [x22, #0x1578]
   42450:	str	x1, [x22, #0x1580]
   42454:	str	x1, [x22, #0x1588]
   42458:	str	x1, [x22, #0x1590]
   4245c:	str	x1, [x22, #0x1598]
   42460:	str	x1, [x22, #0x15a0]
   42464:	str	x1, [x22, #0x15a8]
   42468:	str	x1, [x22, #0x15b0]
   4246c:	str	x1, [x22, #0x15b8]
   42470:	and	x13, x13, #0xfffffffffffffffd
   42474:	b	0x3e6fc
   42478:	mov	x0, #0x0
   4247c:	str	x0, [x22, #0x1160]
   42480:	str	x0, [x22, #0x1168]
   42484:	str	x0, [x22, #0x1170]
   42488:	str	x0, [x22, #0x1178]
   4248c:	str	x0, [x22, #0x1180]
   42490:	str	x0, [x22, #0x1188]
   42494:	str	x0, [x22, #0x1190]
   42498:	str	x0, [x22, #0x1198]
   4249c:	str	x0, [x22, #0x11a0]
   424a0:	str	x0, [x22, #0x11a8]
   424a4:	str	x0, [x22, #0x11b0]
   424a8:	str	x0, [x22, #0x11b8]
   424ac:	str	x0, [x22, #0x11c0]
   424b0:	str	x0, [x22, #0x11c8]
   424b4:	str	x0, [x22, #0x11d0]
   424b8:	str	x0, [x22, #0x11d8]
   424bc:	str	x0, [x22, #0x11e0]
   424c0:	str	x0, [x22, #0x11e8]
   424c4:	and	x13, x13, #0xfffffffffffffffe
   424c8:	b	0x3e720
   424cc:	mov	x0, #0x754
   424d0:	ldur	x26, [sp]
   424d4:	str	x0, [x26, #0x48]
   424d8:	mov	x0, #0x0
   424dc:	str	x0, [x23, #0x18]
   424e0:	mov	x1, #0x1000000000000000
   424e4:	str	x1, [x23, #0x20]
   424e8:	mov	x1, #0x1
   424ec:	str	x1, [x23, #0x30]
   424f0:	mov	x2, #0x101010101010101
   424f4:	str	x2, [x23, #0x38]
   424f8:	mov	x20, #0x2
   424fc:	str	x20, [x23, #0x40]
   42500:	mov	x2, #0x3
   42504:	str	x2, [x23, #0x48]
   42508:	mov	x2, #0x4
   4250c:	str	x2, [x23, #0x50]
   42510:	mov	x2, #0xf0f0f0f0f0f0f0f
   42514:	str	x2, [x23, #0x78]
   42518:	mov	x4, #0x3333333333333333
   4251c:	str	x4, [x23, #0x88]
   42520:	mov	x4, #0x38
   42524:	str	x4, [x23, #0x90]
   42528:	mov	x5, #0x3a
   4252c:	str	x5, [x23, #0x98]
   42530:	mov	x8, #0x5555555555555555
   42534:	str	x8, [x23, #0xb0]
   42538:	mov	x8, #0x3ffffffffffffff
   4253c:	str	x8, [x23, #0xb8]
   42540:	str	x0, [x23, #0x188]
   42544:	str	x1, [x23, #0x190]
   42548:	ldur	x27, [sp, #0xb8]
   4254c:	str	x27, [x23, #0x22e0]
   42550:	ldr	x28, [sp, #0x190]
   42554:	str	x28, [x23, #0x22e8]
   42558:	ldur	x1, [sp, #0xf8]
   4255c:	uxtb	w13, w1
   42560:	str	x13, [x23, #0x22f8]
   42564:	mov	x13, x25
   42568:	str	x13, [x23, #0x2740]
   4256c:	ldur	x10, [sp, #0x58]
   42570:	str	x10, [x23, #0x5788]
   42574:	str	x3, [x23, #0x5790]
   42578:	ldur	x4, [sp, #0x60]
   4257c:	str	x4, [x23, #0x5798]
   42580:	str	x27, [x23, #0x5ac0]
   42584:	str	x28, [x23, #0x5ac8]
   42588:	ldur	x1, [sp, #0x28]
   4258c:	str	x1, [x23, #0x6570]
   42590:	add	x1, x14, #0x1
   42594:	str	x1, [x23, #0x6700]
   42598:	ldur	x24, [sp, #0x68]
   4259c:	str	x24, [x23, #0x6708]
   425a0:	ldur	x25, [sp, #0x70]
   425a4:	str	x25, [x23, #0x6710]
   425a8:	ldur	x4, [sp, #0x50]
   425ac:	sub	x2, x4, x3
   425b0:	mov	w3, #0xc87e
   425b4:	movk	w3, #0x1, lsl #16
   425b8:	msub	x1, x1, x3, x2
   425bc:	str	x1, [x23, #0x6718]
   425c0:	str	x0, [x23, #0x6720]
   425c4:	str	x0, [x23, #0x6728]
   425c8:	ldur	x19, [sp, #0x78]
   425cc:	str	x19, [x23, #0x6738]
   425d0:	ldur	x26, [sp, #0x80]
   425d4:	str	x26, [x23, #0x6740]
   425d8:	str	x12, [x23, #0x6750]
   425dc:	str	x11, [x23, #0x6758]
   425e0:	str	x7, [x23, #0x6768]
   425e4:	str	x6, [x23, #0x6770]
   425e8:	ldr	x0, [x23, #0x5788]
   425ec:	cmp	x0, #0x0
   425f0:	b.ne	0x3e734
   425f4:	b	0x3e960
   425f8:	stur	x20, [sp, #0xc0]
   425fc:	b	0x43a18
   42600:	stur	x20, [sp, #0xc0]
   42604:	b	0x43a18
   42608:	mov	x0, #0x756
   4260c:	ldur	x26, [sp]
   42610:	str	x0, [x26, #0x48]
   42614:	mov	x0, #0x0
   42618:	str	x0, [x23, #0x18]
   4261c:	mov	x1, #0x1000000000000000
   42620:	str	x1, [x23, #0x20]
   42624:	mov	x1, #0x1
   42628:	str	x1, [x23, #0x30]
   4262c:	mov	x2, #0x101010101010101
   42630:	str	x2, [x23, #0x38]
   42634:	mov	x20, #0x2
   42638:	str	x20, [x23, #0x40]
   4263c:	mov	x2, #0x3
   42640:	str	x2, [x23, #0x48]
   42644:	mov	x2, #0x4
   42648:	str	x2, [x23, #0x50]
   4264c:	mov	x2, #0xf0f0f0f0f0f0f0f
   42650:	str	x2, [x23, #0x78]
   42654:	mov	x2, #0x3333333333333333
   42658:	str	x2, [x23, #0x88]
   4265c:	mov	x2, #0x38
   42660:	str	x2, [x23, #0x90]
   42664:	mov	x2, #0x3a
   42668:	str	x2, [x23, #0x98]
   4266c:	mov	x2, #0x5555555555555555
   42670:	str	x2, [x23, #0xb0]
   42674:	mov	x2, #0x3ffffffffffffff
   42678:	str	x2, [x23, #0xb8]
   4267c:	str	x0, [x23, #0x188]
   42680:	str	x1, [x23, #0x190]
   42684:	ldur	x27, [sp, #0xb8]
   42688:	str	x27, [x23, #0x22e0]
   4268c:	ldr	x28, [sp, #0x190]
   42690:	str	x28, [x23, #0x22e8]
   42694:	ldur	x1, [sp, #0xf8]
   42698:	uxtb	w4, w1
   4269c:	str	x4, [x23, #0x22f8]
   426a0:	mov	x15, x5
   426a4:	str	x15, [x23, #0x2748]
   426a8:	add	x5, x27, #0x2
   426ac:	str	x5, [x23, #0x2750]
   426b0:	ldur	x10, [sp, #0x58]
   426b4:	str	x10, [x23, #0x5788]
   426b8:	str	x3, [x23, #0x5790]
   426bc:	ldur	x4, [sp, #0x60]
   426c0:	str	x4, [x23, #0x5798]
   426c4:	str	x27, [x23, #0x5ac0]
   426c8:	str	x28, [x23, #0x5ac8]
   426cc:	ldur	x1, [sp, #0x28]
   426d0:	str	x1, [x23, #0x6570]
   426d4:	add	x13, x14, #0x1
   426d8:	str	x13, [x23, #0x6700]
   426dc:	ldur	x24, [sp, #0x68]
   426e0:	str	x24, [x23, #0x6708]
   426e4:	ldur	x25, [sp, #0x70]
   426e8:	str	x25, [x23, #0x6710]
   426ec:	ldur	x4, [sp, #0x50]
   426f0:	sub	x15, x4, x3
   426f4:	mov	w1, #0xc87e
   426f8:	movk	w1, #0x1, lsl #16
   426fc:	msub	x15, x13, x1, x15
   42700:	str	x15, [x23, #0x6718]
   42704:	str	x0, [x23, #0x6720]
   42708:	str	x0, [x23, #0x6728]
   4270c:	ldur	x19, [sp, #0x78]
   42710:	str	x19, [x23, #0x6738]
   42714:	ldur	x26, [sp, #0x80]
   42718:	str	x26, [x23, #0x6740]
   4271c:	str	x12, [x23, #0x6750]
   42720:	str	x11, [x23, #0x6758]
   42724:	str	x7, [x23, #0x6768]
   42728:	str	x6, [x23, #0x6770]
   4272c:	ldr	x0, [x23, #0x5788]
   42730:	cmp	x0, #0x0
   42734:	b.ne	0x3e9dc
   42738:	b	0x3ec00
   4273c:	stur	x20, [sp, #0xc0]
   42740:	b	0x43a18
   42744:	stur	x20, [sp, #0xc0]
   42748:	b	0x43a18
   4274c:	mov	w1, #0x2646
   42750:	movk	w1, #0x1, lsl #16
   42754:	cmp	x3, x1
   42758:	b.lo	0x3ecc0
   4275c:	mov	w1, #0x1
   42760:	uxtb	w4, w5
   42764:	cbnz	x4, 0x3eccc
   42768:	ldur	x1, [sp, #0x28]
   4276c:	cmp	x1, x2
   42770:	b.ls	0x42784
   42774:	mov	w1, #0x0
   42778:	ldur	x4, [sp, #0x60]
   4277c:	mov	x8, x3
   42780:	b	0x3ed28
   42784:	ldur	x1, [sp, #0xd8]
   42788:	cmp	x15, x1
   4278c:	cset	x1, lo
   42790:	mov	x4, #0x1000000000000000
   42794:	ldur	x20, [sp, #0x48]
   42798:	cmp	x20, x4
   4279c:	cset	x4, lo
   427a0:	and	w1, w1, w4
   427a4:	uxtb	w1, w1
   427a8:	tbnz	w1, #0x0, 0x3ed1c
   427ac:	b	0x3ecd8
   427b0:	stur	x20, [sp, #0xc0]
   427b4:	b	0x43a18
   427b8:	mov	x11, #0x770
   427bc:	ldur	x26, [sp]
   427c0:	str	x11, [x26, #0x48]
   427c4:	mov	x13, #0x0
   427c8:	str	x13, [x23, #0x18]
   427cc:	str	x0, [x23, #0x20]
   427d0:	mov	x0, #0x1
   427d4:	stur	x0, [sp, #0xc0]
   427d8:	str	x0, [x23, #0x30]
   427dc:	mov	x0, #0x101010101010101
   427e0:	str	x0, [x23, #0x38]
   427e4:	mov	x0, #0x2
   427e8:	str	x0, [x23, #0x40]
   427ec:	mov	x0, #0x3
   427f0:	str	x0, [x23, #0x48]
   427f4:	mov	x0, #0x4
   427f8:	str	x0, [x23, #0x50]
   427fc:	mov	x0, #0xf0f0f0f0f0f0f0f
   42800:	str	x0, [x23, #0x78]
   42804:	mov	x0, #0x3333333333333333
   42808:	str	x0, [x23, #0x88]
   4280c:	mov	x0, #0x38
   42810:	str	x0, [x23, #0x90]
   42814:	mov	x0, #0x3a
   42818:	str	x0, [x23, #0x98]
   4281c:	mov	x0, #0x5555555555555555
   42820:	str	x0, [x23, #0xb0]
   42824:	mov	x0, #0x3ffffffffffffff
   42828:	str	x0, [x23, #0xb8]
   4282c:	str	x13, [x23, #0x188]
   42830:	ldur	x0, [sp, #0xc0]
   42834:	str	x0, [x23, #0x190]
   42838:	ldur	x27, [sp, #0xb8]
   4283c:	str	x27, [x23, #0x22e0]
   42840:	ldr	x28, [sp, #0x190]
   42844:	str	x28, [x23, #0x22e8]
   42848:	ldur	x0, [sp, #0xf8]
   4284c:	uxtb	w0, w0
   42850:	str	x0, [x23, #0x22f8]
   42854:	str	x15, [x23, #0x27b0]
   42858:	ldur	x15, [sp, #0xd8]
   4285c:	str	x15, [x23, #0x27b8]
   42860:	str	x27, [x23, #0x27c0]
   42864:	str	x19, [x23, #0x27e8]
   42868:	ldur	x10, [sp, #0x58]
   4286c:	str	x10, [x23, #0x5788]
   42870:	mov	w1, #0x2646
   42874:	movk	w1, #0x1, lsl #16
   42878:	sub	x1, x3, x1
   4287c:	str	x1, [x23, #0x5790]
   42880:	ldur	x4, [sp, #0x60]
   42884:	str	x4, [x23, #0x5798]
   42888:	ldur	x0, [sp, #0x28]
   4288c:	str	x0, [x23, #0x6570]
   42890:	add	x2, x14, #0x1
   42894:	str	x2, [x23, #0x6700]
   42898:	ldur	x24, [sp, #0x68]
   4289c:	str	x24, [x23, #0x6708]
   428a0:	ldur	x25, [sp, #0x70]
   428a4:	str	x25, [x23, #0x6710]
   428a8:	ldur	x4, [sp, #0x50]
   428ac:	sub	x1, x4, x1
   428b0:	mov	w3, #0xc87e
   428b4:	movk	w3, #0x1, lsl #16
   428b8:	msub	x0, x2, x3, x1
   428bc:	str	x0, [x23, #0x6718]
   428c0:	str	x13, [x23, #0x6720]
   428c4:	str	x13, [x23, #0x6728]
   428c8:	ldur	x19, [sp, #0x78]
   428cc:	str	x19, [x23, #0x6738]
   428d0:	ldur	x26, [sp, #0x80]
   428d4:	str	x26, [x23, #0x6740]
   428d8:	ldur	x0, [sp, #0xc0]
   428dc:	str	x0, [x23, #0x6750]
   428e0:	ldur	x5, [sp, #0x20]
   428e4:	str	x5, [x23, #0x6758]
   428e8:	str	x7, [x23, #0x6768]
   428ec:	str	x6, [x23, #0x6770]
   428f0:	b	0x43a18
   428f4:	mov	x1, #0x771
   428f8:	ldur	x26, [sp]
   428fc:	str	x1, [x26, #0x48]
   42900:	mov	x1, #0x0
   42904:	str	x1, [x23, #0x18]
   42908:	str	x0, [x23, #0x20]
   4290c:	mov	x0, #0x1
   42910:	str	x0, [x23, #0x30]
   42914:	mov	x2, #0x101010101010101
   42918:	str	x2, [x23, #0x38]
   4291c:	mov	x21, #0x2
   42920:	str	x21, [x23, #0x40]
   42924:	mov	x2, #0x3
   42928:	str	x2, [x23, #0x48]
   4292c:	mov	x2, #0x4
   42930:	str	x2, [x23, #0x50]
   42934:	mov	x2, #0xf0f0f0f0f0f0f0f
   42938:	str	x2, [x23, #0x78]
   4293c:	mov	x2, #0x3333333333333333
   42940:	str	x2, [x23, #0x88]
   42944:	mov	x2, #0x38
   42948:	str	x2, [x23, #0x90]
   4294c:	mov	x2, #0x3a
   42950:	str	x2, [x23, #0x98]
   42954:	mov	x4, #0x5555555555555555
   42958:	str	x4, [x23, #0xb0]
   4295c:	mov	x4, #0x3ffffffffffffff
   42960:	str	x4, [x23, #0xb8]
   42964:	str	x1, [x23, #0x188]
   42968:	str	x0, [x23, #0x190]
   4296c:	ldur	x27, [sp, #0xb8]
   42970:	str	x27, [x23, #0x22e0]
   42974:	ldr	x28, [sp, #0x190]
   42978:	str	x28, [x23, #0x22e8]
   4297c:	ldur	x2, [sp, #0xf8]
   42980:	uxtb	w10, w2
   42984:	str	x10, [x23, #0x22f8]
   42988:	str	x15, [x23, #0x27b0]
   4298c:	ldur	x11, [sp, #0xd8]
   42990:	str	x11, [x23, #0x27b8]
   42994:	str	x27, [x23, #0x27c0]
   42998:	str	x19, [x23, #0x27e8]
   4299c:	str	x9, [x23, #0x27f8]
   429a0:	ldur	x10, [sp, #0x58]
   429a4:	str	x10, [x23, #0x5788]
   429a8:	mov	w2, #0x2646
   429ac:	movk	w2, #0x1, lsl #16
   429b0:	sub	x2, x3, x2
   429b4:	str	x2, [x23, #0x5790]
   429b8:	ldur	x4, [sp, #0x60]
   429bc:	str	x4, [x23, #0x5798]
   429c0:	str	x27, [x23, #0x5ac0]
   429c4:	str	x28, [x23, #0x5ac8]
   429c8:	str	x15, [x23, #0x6128]
   429cc:	ldur	x15, [sp, #0xd8]
   429d0:	str	x15, [x23, #0x6130]
   429d4:	str	x27, [x23, #0x6138]
   429d8:	ldur	x24, [sp, #0x10]
   429dc:	str	x24, [x23, #0x6140]
   429e0:	ldur	x11, [sp, #0x30]
   429e4:	str	x11, [x23, #0x6148]
   429e8:	ldur	x24, [sp, #0x38]
   429ec:	str	x24, [x23, #0x6150]
   429f0:	ldur	x22, [sp, #0x40]
   429f4:	str	x22, [x23, #0x6158]
   429f8:	ldur	x20, [sp, #0x48]
   429fc:	str	x20, [x23, #0x6160]
   42a00:	ldur	x8, [sp, #0x28]
   42a04:	str	x8, [x23, #0x6570]
   42a08:	add	x3, x14, #0x1
   42a0c:	str	x3, [x23, #0x6700]
   42a10:	ldur	x24, [sp, #0x68]
   42a14:	str	x24, [x23, #0x6708]
   42a18:	ldur	x25, [sp, #0x70]
   42a1c:	str	x25, [x23, #0x6710]
   42a20:	ldur	x4, [sp, #0x50]
   42a24:	sub	x2, x4, x2
   42a28:	mov	w4, #0xc87e
   42a2c:	movk	w4, #0x1, lsl #16
   42a30:	msub	x2, x3, x4, x2
   42a34:	str	x2, [x23, #0x6718]
   42a38:	str	x1, [x23, #0x6720]
   42a3c:	str	x1, [x23, #0x6728]
   42a40:	ldur	x19, [sp, #0x78]
   42a44:	str	x19, [x23, #0x6738]
   42a48:	ldur	x26, [sp, #0x80]
   42a4c:	str	x26, [x23, #0x6740]
   42a50:	str	x0, [x23, #0x6750]
   42a54:	ldur	x0, [sp, #0x20]
   42a58:	str	x0, [x23, #0x6758]
   42a5c:	str	x7, [x23, #0x6768]
   42a60:	str	x6, [x23, #0x6770]
   42a64:	ldr	x0, [x23, #0x5788]
   42a68:	cmp	x0, #0x0
   42a6c:	b.ne	0x3f150
   42a70:	b	0x3f388
   42a74:	stur	x21, [sp, #0xc0]
   42a78:	b	0x43a18
   42a7c:	stur	x21, [sp, #0xc0]
   42a80:	b	0x43a18
   42a84:	mov	x2, #0x772
   42a88:	ldur	x26, [sp]
   42a8c:	str	x2, [x26, #0x48]
   42a90:	mov	x2, #0x0
   42a94:	str	x2, [x23, #0x18]
   42a98:	str	x0, [x23, #0x20]
   42a9c:	mov	x0, #0x1
   42aa0:	stur	x0, [sp, #0xc0]
   42aa4:	str	x0, [x23, #0x30]
   42aa8:	mov	x0, #0x101010101010101
   42aac:	str	x0, [x23, #0x38]
   42ab0:	mov	x0, #0x2
   42ab4:	str	x0, [x23, #0x40]
   42ab8:	mov	x0, #0x3
   42abc:	str	x0, [x23, #0x48]
   42ac0:	mov	x0, #0x4
   42ac4:	str	x0, [x23, #0x50]
   42ac8:	mov	x0, #0xf0f0f0f0f0f0f0f
   42acc:	str	x0, [x23, #0x78]
   42ad0:	mov	x4, #0x3333333333333333
   42ad4:	str	x4, [x23, #0x88]
   42ad8:	mov	x4, #0x38
   42adc:	str	x4, [x23, #0x90]
   42ae0:	mov	x4, #0x3a
   42ae4:	str	x4, [x23, #0x98]
   42ae8:	mov	x4, #0x5555555555555555
   42aec:	str	x4, [x23, #0xb0]
   42af0:	mov	x5, #0x3ffffffffffffff
   42af4:	str	x5, [x23, #0xb8]
   42af8:	str	x2, [x23, #0x188]
   42afc:	ldur	x0, [sp, #0xc0]
   42b00:	str	x0, [x23, #0x190]
   42b04:	ldur	x27, [sp, #0xb8]
   42b08:	str	x27, [x23, #0x22e0]
   42b0c:	ldr	x28, [sp, #0x190]
   42b10:	str	x28, [x23, #0x22e8]
   42b14:	ldur	x0, [sp, #0xf8]
   42b18:	uxtb	w10, w0
   42b1c:	str	x10, [x23, #0x22f8]
   42b20:	str	x15, [x23, #0x27b0]
   42b24:	ldur	x15, [sp, #0xd8]
   42b28:	str	x15, [x23, #0x27b8]
   42b2c:	str	x27, [x23, #0x27c0]
   42b30:	str	x19, [x23, #0x27e8]
   42b34:	str	x1, [x23, #0x2800]
   42b38:	ldur	x10, [sp, #0x58]
   42b3c:	str	x10, [x23, #0x5788]
   42b40:	mov	w1, #0x2646
   42b44:	movk	w1, #0x1, lsl #16
   42b48:	sub	x1, x3, x1
   42b4c:	str	x1, [x23, #0x5790]
   42b50:	ldur	x4, [sp, #0x60]
   42b54:	str	x4, [x23, #0x5798]
   42b58:	ldur	x0, [sp, #0x28]
   42b5c:	str	x0, [x23, #0x6570]
   42b60:	add	x3, x14, #0x1
   42b64:	str	x3, [x23, #0x6700]
   42b68:	ldur	x24, [sp, #0x68]
   42b6c:	str	x24, [x23, #0x6708]
   42b70:	ldur	x25, [sp, #0x70]
   42b74:	str	x25, [x23, #0x6710]
   42b78:	ldur	x4, [sp, #0x50]
   42b7c:	sub	x1, x4, x1
   42b80:	mov	w4, #0xc87e
   42b84:	movk	w4, #0x1, lsl #16
   42b88:	msub	x0, x3, x4, x1
   42b8c:	str	x0, [x23, #0x6718]
   42b90:	str	x2, [x23, #0x6720]
   42b94:	str	x2, [x23, #0x6728]
   42b98:	ldur	x19, [sp, #0x78]
   42b9c:	str	x19, [x23, #0x6738]
   42ba0:	ldur	x26, [sp, #0x80]
   42ba4:	str	x26, [x23, #0x6740]
   42ba8:	ldur	x0, [sp, #0xc0]
   42bac:	str	x0, [x23, #0x6750]
   42bb0:	ldur	x0, [sp, #0x20]
   42bb4:	str	x0, [x23, #0x6758]
   42bb8:	str	x7, [x23, #0x6768]
   42bbc:	str	x6, [x23, #0x6770]
   42bc0:	b	0x43a18
   42bc4:	mov	x2, #0x773
   42bc8:	ldur	x26, [sp]
   42bcc:	str	x2, [x26, #0x48]
   42bd0:	mov	x2, #0x0
   42bd4:	str	x2, [x23, #0x18]
   42bd8:	str	x0, [x23, #0x20]
   42bdc:	mov	x0, #0x1
   42be0:	str	x0, [x23, #0x30]
   42be4:	mov	x5, #0x101010101010101
   42be8:	str	x5, [x23, #0x38]
   42bec:	mov	x21, #0x2
   42bf0:	str	x21, [x23, #0x40]
   42bf4:	mov	x5, #0x3
   42bf8:	str	x5, [x23, #0x48]
   42bfc:	mov	x5, #0x4
   42c00:	str	x5, [x23, #0x50]
   42c04:	mov	x5, #0xf0f0f0f0f0f0f0f
   42c08:	str	x5, [x23, #0x78]
   42c0c:	mov	x5, #0x3333333333333333
   42c10:	str	x5, [x23, #0x88]
   42c14:	mov	x5, #0x38
   42c18:	str	x5, [x23, #0x90]
   42c1c:	mov	x5, #0x3a
   42c20:	str	x5, [x23, #0x98]
   42c24:	mov	x5, #0x5555555555555555
   42c28:	str	x5, [x23, #0xb0]
   42c2c:	mov	x5, #0x3ffffffffffffff
   42c30:	str	x5, [x23, #0xb8]
   42c34:	str	x2, [x23, #0x188]
   42c38:	str	x0, [x23, #0x190]
   42c3c:	ldur	x27, [sp, #0xb8]
   42c40:	str	x27, [x23, #0x22e0]
   42c44:	ldr	x28, [sp, #0x190]
   42c48:	str	x28, [x23, #0x22e8]
   42c4c:	ldur	x5, [sp, #0xf8]
   42c50:	uxtb	w5, w5
   42c54:	str	x5, [x23, #0x22f8]
   42c58:	str	x15, [x23, #0x27b0]
   42c5c:	ldur	x5, [sp, #0xd8]
   42c60:	str	x5, [x23, #0x27b8]
   42c64:	str	x27, [x23, #0x27c0]
   42c68:	str	x19, [x23, #0x27e8]
   42c6c:	str	x1, [x23, #0x2800]
   42c70:	str	x4, [x23, #0x2808]
   42c74:	ldur	x10, [sp, #0x58]
   42c78:	str	x10, [x23, #0x5788]
   42c7c:	mov	w1, #0x2646
   42c80:	movk	w1, #0x1, lsl #16
   42c84:	sub	x1, x3, x1
   42c88:	str	x1, [x23, #0x5790]
   42c8c:	ldur	x4, [sp, #0x60]
   42c90:	str	x4, [x23, #0x5798]
   42c94:	str	x27, [x23, #0x5ac0]
   42c98:	str	x28, [x23, #0x5ac8]
   42c9c:	str	x15, [x23, #0x6128]
   42ca0:	ldur	x15, [sp, #0xd8]
   42ca4:	str	x15, [x23, #0x6130]
   42ca8:	str	x27, [x23, #0x6138]
   42cac:	ldur	x24, [sp, #0x10]
   42cb0:	str	x24, [x23, #0x6140]
   42cb4:	ldur	x3, [sp, #0x30]
   42cb8:	str	x3, [x23, #0x6148]
   42cbc:	ldur	x24, [sp, #0x38]
   42cc0:	str	x24, [x23, #0x6150]
   42cc4:	ldur	x22, [sp, #0x40]
   42cc8:	str	x22, [x23, #0x6158]
   42ccc:	ldur	x20, [sp, #0x48]
   42cd0:	str	x20, [x23, #0x6160]
   42cd4:	ldur	x3, [sp, #0x28]
   42cd8:	str	x3, [x23, #0x6570]
   42cdc:	add	x12, x14, #0x1
   42ce0:	str	x12, [x23, #0x6700]
   42ce4:	ldur	x24, [sp, #0x68]
   42ce8:	str	x24, [x23, #0x6708]
   42cec:	ldur	x25, [sp, #0x70]
   42cf0:	str	x25, [x23, #0x6710]
   42cf4:	ldur	x4, [sp, #0x50]
   42cf8:	sub	x15, x4, x1
   42cfc:	mov	w1, #0xc87e
   42d00:	movk	w1, #0x1, lsl #16
   42d04:	msub	x15, x12, x1, x15
   42d08:	str	x15, [x23, #0x6718]
   42d0c:	str	x2, [x23, #0x6720]
   42d10:	str	x2, [x23, #0x6728]
   42d14:	ldur	x19, [sp, #0x78]
   42d18:	str	x19, [x23, #0x6738]
   42d1c:	ldur	x26, [sp, #0x80]
   42d20:	str	x26, [x23, #0x6740]
   42d24:	str	x0, [x23, #0x6750]
   42d28:	ldur	x0, [sp, #0x20]
   42d2c:	str	x0, [x23, #0x6758]
   42d30:	str	x7, [x23, #0x6768]
   42d34:	str	x6, [x23, #0x6770]
   42d38:	ldr	x0, [x23, #0x5788]
   42d3c:	cmp	x0, #0x0
   42d40:	b.ne	0x3f404
   42d44:	b	0x3f630
   42d48:	stur	x21, [sp, #0xc0]
   42d4c:	b	0x43a18
   42d50:	stur	x21, [sp, #0xc0]
   42d54:	b	0x43a18
   42d58:	mov	x2, #0x775
   42d5c:	ldur	x26, [sp]
   42d60:	str	x2, [x26, #0x48]
   42d64:	mov	x2, #0x0
   42d68:	str	x2, [x23, #0x18]
   42d6c:	str	x0, [x23, #0x20]
   42d70:	mov	x0, #0x1
   42d74:	str	x0, [x23, #0x30]
   42d78:	mov	x4, #0x101010101010101
   42d7c:	str	x4, [x23, #0x38]
   42d80:	mov	x21, #0x2
   42d84:	str	x21, [x23, #0x40]
   42d88:	mov	x4, #0x3
   42d8c:	str	x4, [x23, #0x48]
   42d90:	mov	x4, #0x4
   42d94:	str	x4, [x23, #0x50]
   42d98:	mov	x4, #0xf0f0f0f0f0f0f0f
   42d9c:	str	x4, [x23, #0x78]
   42da0:	mov	x4, #0x3333333333333333
   42da4:	str	x4, [x23, #0x88]
   42da8:	mov	x4, #0x38
   42dac:	str	x4, [x23, #0x90]
   42db0:	mov	x4, #0x3a
   42db4:	str	x4, [x23, #0x98]
   42db8:	mov	x4, #0x5555555555555555
   42dbc:	str	x4, [x23, #0xb0]
   42dc0:	mov	x4, #0x3ffffffffffffff
   42dc4:	str	x4, [x23, #0xb8]
   42dc8:	str	x2, [x23, #0x188]
   42dcc:	str	x0, [x23, #0x190]
   42dd0:	ldur	x27, [sp, #0xb8]
   42dd4:	str	x27, [x23, #0x22e0]
   42dd8:	ldr	x28, [sp, #0x190]
   42ddc:	str	x28, [x23, #0x22e8]
   42de0:	ldur	x4, [sp, #0xf8]
   42de4:	uxtb	w4, w4
   42de8:	str	x4, [x23, #0x22f8]
   42dec:	str	x15, [x23, #0x27b0]
   42df0:	ldur	x10, [sp, #0xd8]
   42df4:	str	x10, [x23, #0x27b8]
   42df8:	str	x27, [x23, #0x27c0]
   42dfc:	str	x19, [x23, #0x27e8]
   42e00:	str	x11, [x23, #0x2810]
   42e04:	add	x1, x1, #0x2
   42e08:	str	x1, [x23, #0x2818]
   42e0c:	ldur	x10, [sp, #0x58]
   42e10:	str	x10, [x23, #0x5788]
   42e14:	mov	w4, #0x2646
   42e18:	movk	w4, #0x1, lsl #16
   42e1c:	sub	x3, x3, x4
   42e20:	str	x3, [x23, #0x5790]
   42e24:	ldur	x4, [sp, #0x60]
   42e28:	str	x4, [x23, #0x5798]
   42e2c:	str	x27, [x23, #0x5ac0]
   42e30:	str	x28, [x23, #0x5ac8]
   42e34:	str	x15, [x23, #0x6128]
   42e38:	ldur	x15, [sp, #0xd8]
   42e3c:	str	x15, [x23, #0x6130]
   42e40:	str	x27, [x23, #0x6138]
   42e44:	ldur	x24, [sp, #0x10]
   42e48:	str	x24, [x23, #0x6140]
   42e4c:	ldur	x9, [sp, #0x30]
   42e50:	str	x9, [x23, #0x6148]
   42e54:	ldur	x24, [sp, #0x38]
   42e58:	str	x24, [x23, #0x6150]
   42e5c:	ldur	x22, [sp, #0x40]
   42e60:	str	x22, [x23, #0x6158]
   42e64:	ldur	x20, [sp, #0x48]
   42e68:	str	x20, [x23, #0x6160]
   42e6c:	ldur	x1, [sp, #0x28]
   42e70:	str	x1, [x23, #0x6570]
   42e74:	add	x1, x14, #0x1
   42e78:	str	x1, [x23, #0x6700]
   42e7c:	ldur	x24, [sp, #0x68]
   42e80:	str	x24, [x23, #0x6708]
   42e84:	ldur	x25, [sp, #0x70]
   42e88:	str	x25, [x23, #0x6710]
   42e8c:	ldur	x4, [sp, #0x50]
   42e90:	sub	x3, x4, x3
   42e94:	mov	w4, #0xc87e
   42e98:	movk	w4, #0x1, lsl #16
   42e9c:	msub	x1, x1, x4, x3
   42ea0:	str	x1, [x23, #0x6718]
   42ea4:	str	x2, [x23, #0x6720]
   42ea8:	str	x2, [x23, #0x6728]
   42eac:	ldur	x19, [sp, #0x78]
   42eb0:	str	x19, [x23, #0x6738]
   42eb4:	ldur	x26, [sp, #0x80]
   42eb8:	str	x26, [x23, #0x6740]
   42ebc:	str	x0, [x23, #0x6750]
   42ec0:	ldur	x0, [sp, #0x20]
   42ec4:	str	x0, [x23, #0x6758]
   42ec8:	str	x7, [x23, #0x6768]
   42ecc:	str	x6, [x23, #0x6770]
   42ed0:	ldr	x0, [x23, #0x5788]
   42ed4:	cmp	x0, #0x0
   42ed8:	b.ne	0x3f6a0
   42edc:	b	0x3f8d0
   42ee0:	stur	x21, [sp, #0xc0]
   42ee4:	b	0x43a18
   42ee8:	stur	x21, [sp, #0xc0]
   42eec:	b	0x43a18
   42ef0:	mov	w1, #0xcb86
   42ef4:	movk	w1, #0x2, lsl #16
   42ef8:	cmp	x6, x1
   42efc:	b.lo	0x3f9a0
   42f00:	mov	w1, #0x1
   42f04:	uxtb	w3, w5
   42f08:	cbnz	x3, 0x3f9d0
   42f0c:	ldur	x1, [sp, #0x28]
   42f10:	cmp	x1, x2
   42f14:	b.ls	0x42f28
   42f18:	mov	w1, #0x0
   42f1c:	ldur	x3, [sp, #0x60]
   42f20:	mov	x8, x6
   42f24:	b	0x3fa04
   42f28:	cmp	x11, x7
   42f2c:	b.lo	0x3f9f8
   42f30:	b	0x3f9dc
   42f34:	mov	x1, #0x78d
   42f38:	ldur	x26, [sp]
   42f3c:	str	x1, [x26, #0x48]
   42f40:	mov	x2, #0x0
   42f44:	str	x2, [x23, #0x18]
   42f48:	str	x0, [x23, #0x20]
   42f4c:	mov	x0, #0x1
   42f50:	str	x0, [x23, #0x30]
   42f54:	mov	x1, #0x101010101010101
   42f58:	str	x1, [x23, #0x38]
   42f5c:	mov	x22, #0x2
   42f60:	str	x22, [x23, #0x40]
   42f64:	mov	x1, #0x3
   42f68:	str	x1, [x23, #0x48]
   42f6c:	mov	x1, #0x4
   42f70:	str	x1, [x23, #0x50]
   42f74:	mov	x1, #0xf0f0f0f0f0f0f0f
   42f78:	str	x1, [x23, #0x78]
   42f7c:	mov	x1, #0x3333333333333333
   42f80:	str	x1, [x23, #0x88]
   42f84:	mov	x1, #0x38
   42f88:	str	x1, [x23, #0x90]
   42f8c:	mov	x1, #0x3a
   42f90:	str	x1, [x23, #0x98]
   42f94:	mov	x1, #0x5555555555555555
   42f98:	str	x1, [x23, #0xb0]
   42f9c:	mov	x1, #0x3ffffffffffffff
   42fa0:	str	x1, [x23, #0xb8]
   42fa4:	str	x2, [x23, #0x188]
   42fa8:	str	x0, [x23, #0x190]
   42fac:	ldur	x27, [sp, #0xb8]
   42fb0:	str	x27, [x23, #0x22e0]
   42fb4:	ldr	x28, [sp, #0x190]
   42fb8:	str	x28, [x23, #0x22e8]
   42fbc:	ldur	x1, [sp, #0xf8]
   42fc0:	uxtb	w1, w1
   42fc4:	str	x1, [x23, #0x22f8]
   42fc8:	str	x15, [x23, #0x27b0]
   42fcc:	ldur	x1, [sp, #0xd8]
   42fd0:	str	x1, [x23, #0x27b8]
   42fd4:	str	x27, [x23, #0x27c0]
   42fd8:	ldur	x19, [sp, #0xd0]
   42fdc:	str	x19, [x23, #0x27e8]
   42fe0:	str	x11, [x23, #0x2878]
   42fe4:	str	x7, [x23, #0x2880]
   42fe8:	str	x27, [x23, #0x2888]
   42fec:	uxtb	w1, w3
   42ff0:	str	x1, [x23, #0x2898]
   42ff4:	add	x1, x11, #0x1
   42ff8:	str	x1, [x23, #0x28a8]
   42ffc:	ldur	x10, [sp, #0x58]
   43000:	str	x10, [x23, #0x5788]
   43004:	mov	w1, #0xcb86
   43008:	movk	w1, #0x2, lsl #16
   4300c:	sub	x1, x6, x1
   43010:	str	x1, [x23, #0x5790]
   43014:	ldur	x3, [sp, #0x60]
   43018:	str	x3, [x23, #0x5798]
   4301c:	str	x27, [x23, #0x5ac0]
   43020:	str	x28, [x23, #0x5ac8]
   43024:	str	x15, [x23, #0x6128]
   43028:	ldur	x15, [sp, #0xd8]
   4302c:	str	x15, [x23, #0x6130]
   43030:	str	x27, [x23, #0x6138]
   43034:	ldur	x3, [sp, #0x10]
   43038:	str	x3, [x23, #0x6140]
   4303c:	ldur	x3, [sp, #0x30]
   43040:	str	x3, [x23, #0x6148]
   43044:	ldur	x3, [sp, #0x38]
   43048:	str	x3, [x23, #0x6150]
   4304c:	ldur	x3, [sp, #0x40]
   43050:	str	x3, [x23, #0x6158]
   43054:	ldur	x20, [sp, #0x48]
   43058:	str	x20, [x23, #0x6160]
   4305c:	str	x11, [x23, #0x62f0]
   43060:	str	x7, [x23, #0x62f8]
   43064:	str	x27, [x23, #0x6300]
   43068:	str	x25, [x23, #0x6308]
   4306c:	str	x21, [x23, #0x6310]
   43070:	str	x4, [x23, #0x6318]
   43074:	str	x24, [x23, #0x6320]
   43078:	mov	x19, x12
   4307c:	str	x19, [x23, #0x6328]
   43080:	ldur	x3, [sp, #0x28]
   43084:	str	x3, [x23, #0x6570]
   43088:	add	x12, x14, #0x1
   4308c:	str	x12, [x23, #0x6700]
   43090:	ldur	x24, [sp, #0x68]
   43094:	str	x24, [x23, #0x6708]
   43098:	ldur	x25, [sp, #0x70]
   4309c:	str	x25, [x23, #0x6710]
   430a0:	ldur	x4, [sp, #0x50]
   430a4:	sub	x15, x4, x1
   430a8:	mov	w1, #0xc87e
   430ac:	movk	w1, #0x1, lsl #16
   430b0:	msub	x15, x12, x1, x15
   430b4:	str	x15, [x23, #0x6718]
   430b8:	str	x2, [x23, #0x6720]
   430bc:	str	x2, [x23, #0x6728]
   430c0:	ldur	x19, [sp, #0x78]
   430c4:	str	x19, [x23, #0x6738]
   430c8:	ldur	x26, [sp, #0x80]
   430cc:	str	x26, [x23, #0x6740]
   430d0:	str	x0, [x23, #0x6750]
   430d4:	ldur	x6, [sp, #0x20]
   430d8:	str	x6, [x23, #0x6758]
   430dc:	str	x0, [x23, #0x6768]
   430e0:	str	x9, [x23, #0x6770]
   430e4:	ldr	x0, [x23, #0x5788]
   430e8:	cmp	x0, #0x0
   430ec:	b.ne	0x3fa6c
   430f0:	b	0x3fc8c
   430f4:	stur	x22, [sp, #0xc0]
   430f8:	b	0x43a18
   430fc:	stur	x22, [sp, #0xc0]
   43100:	b	0x43a18
   43104:	mov	x5, #0x80c
   43108:	ldur	x26, [sp]
   4310c:	str	x5, [x26, #0x48]
   43110:	mov	x13, #0x0
   43114:	str	x13, [x23, #0x18]
   43118:	str	x0, [x23, #0x20]
   4311c:	mov	x0, #0x1
   43120:	stur	x0, [sp, #0xc0]
   43124:	str	x0, [x23, #0x30]
   43128:	mov	x10, #0x101010101010101
   4312c:	str	x10, [x23, #0x38]
   43130:	mov	x10, #0x2
   43134:	str	x10, [x23, #0x40]
   43138:	mov	x12, #0x3
   4313c:	str	x12, [x23, #0x48]
   43140:	mov	x12, #0x4
   43144:	str	x12, [x23, #0x50]
   43148:	mov	x0, #0xf0f0f0f0f0f0f0f
   4314c:	str	x0, [x23, #0x78]
   43150:	mov	x0, #0x3333333333333333
   43154:	str	x0, [x23, #0x88]
   43158:	mov	x0, #0x38
   4315c:	str	x0, [x23, #0x90]
   43160:	mov	x0, #0x3a
   43164:	str	x0, [x23, #0x98]
   43168:	mov	x0, #0x5555555555555555
   4316c:	str	x0, [x23, #0xb0]
   43170:	str	x8, [x23, #0xb8]
   43174:	str	x13, [x23, #0x188]
   43178:	ldur	x0, [sp, #0xc0]
   4317c:	str	x0, [x23, #0x190]
   43180:	ldur	x27, [sp, #0xb8]
   43184:	str	x27, [x23, #0x22e0]
   43188:	ldr	x28, [sp, #0x190]
   4318c:	str	x28, [x23, #0x22e8]
   43190:	ldur	x0, [sp, #0xf8]
   43194:	uxtb	w0, w0
   43198:	str	x0, [x23, #0x22f8]
   4319c:	str	x15, [x23, #0x27b0]
   431a0:	ldur	x15, [sp, #0xd8]
   431a4:	str	x15, [x23, #0x27b8]
   431a8:	str	x27, [x23, #0x27c0]
   431ac:	ldur	x19, [sp, #0xd0]
   431b0:	str	x19, [x23, #0x27e8]
   431b4:	str	x11, [x23, #0x2878]
   431b8:	str	x7, [x23, #0x2880]
   431bc:	str	x27, [x23, #0x2888]
   431c0:	ldur	x10, [sp, #0x58]
   431c4:	str	x10, [x23, #0x5788]
   431c8:	mov	w1, #0xcb86
   431cc:	movk	w1, #0x2, lsl #16
   431d0:	sub	x1, x6, x1
   431d4:	str	x1, [x23, #0x5790]
   431d8:	ldur	x4, [sp, #0x60]
   431dc:	str	x4, [x23, #0x5798]
   431e0:	ldur	x3, [sp, #0x28]
   431e4:	str	x3, [x23, #0x6570]
   431e8:	add	x2, x14, #0x1
   431ec:	str	x2, [x23, #0x6700]
   431f0:	ldur	x24, [sp, #0x68]
   431f4:	str	x24, [x23, #0x6708]
   431f8:	ldur	x25, [sp, #0x70]
   431fc:	str	x25, [x23, #0x6710]
   43200:	ldur	x4, [sp, #0x50]
   43204:	sub	x1, x4, x1
   43208:	mov	w3, #0xc87e
   4320c:	movk	w3, #0x1, lsl #16
   43210:	msub	x0, x2, x3, x1
   43214:	str	x0, [x23, #0x6718]
   43218:	str	x13, [x23, #0x6720]
   4321c:	str	x13, [x23, #0x6728]
   43220:	ldur	x19, [sp, #0x78]
   43224:	str	x19, [x23, #0x6738]
   43228:	ldur	x26, [sp, #0x80]
   4322c:	str	x26, [x23, #0x6740]
   43230:	ldur	x0, [sp, #0xc0]
   43234:	str	x0, [x23, #0x6750]
   43238:	ldur	x6, [sp, #0x20]
   4323c:	str	x6, [x23, #0x6758]
   43240:	str	x0, [x23, #0x6768]
   43244:	str	x9, [x23, #0x6770]
   43248:	b	0x43a18
   4324c:	mov	w1, #0xcb86
   43250:	movk	w1, #0x2, lsl #16
   43254:	cmp	x6, x1
   43258:	b.lo	0x3fe4c
   4325c:	mov	w1, #0x1
   43260:	uxtb	w3, w5
   43264:	cbnz	x3, 0x3fe78
   43268:	ldur	x1, [sp, #0x28]
   4326c:	cmp	x1, x2
   43270:	b.ls	0x43284
   43274:	mov	w1, #0x0
   43278:	ldur	x3, [sp, #0x60]
   4327c:	mov	x8, x6
   43280:	b	0x3feac
   43284:	cmp	x11, x7
   43288:	b.lo	0x3fea0
   4328c:	b	0x3fe84
   43290:	stur	x22, [sp, #0xc0]
   43294:	b	0x43a18
   43298:	mov	x1, #0x0
   4329c:	str	x1, [x22, #0x1f20]
   432a0:	str	x1, [x22, #0x1f28]
   432a4:	str	x1, [x22, #0x1f30]
   432a8:	str	x1, [x22, #0x1f38]
   432ac:	str	x1, [x22, #0x1f40]
   432b0:	str	x1, [x22, #0x1f48]
   432b4:	str	x1, [x22, #0x1f50]
   432b8:	str	x1, [x22, #0x1f58]
   432bc:	str	x1, [x22, #0x1f60]
   432c0:	str	x1, [x22, #0x1f68]
   432c4:	str	x1, [x22, #0x1f70]
   432c8:	str	x1, [x22, #0x1f78]
   432cc:	str	x1, [x22, #0x1f80]
   432d0:	str	x1, [x22, #0x1f88]
   432d4:	str	x1, [x22, #0x1f90]
   432d8:	str	x1, [x22, #0x1f98]
   432dc:	and	x13, x13, #0xfffffffffffffff7
   432e0:	b	0x403fc
   432e4:	mov	x0, #0x0
   432e8:	str	x0, [x22, #0x1b90]
   432ec:	str	x0, [x22, #0x1b98]
   432f0:	str	x0, [x22, #0x1ba0]
   432f4:	str	x0, [x22, #0x1ba8]
   432f8:	str	x0, [x22, #0x1bb0]
   432fc:	str	x0, [x22, #0x1bb8]
   43300:	str	x0, [x22, #0x1bc0]
   43304:	str	x0, [x22, #0x1bc8]
   43308:	str	x0, [x22, #0x1bd0]
   4330c:	str	x0, [x22, #0x1bd8]
   43310:	str	x0, [x22, #0x1be0]
   43314:	str	x0, [x22, #0x1be8]
   43318:	str	x0, [x22, #0x1bf0]
   4331c:	str	x0, [x22, #0x1bf8]
   43320:	str	x0, [x22, #0x1c00]
   43324:	str	x0, [x22, #0x1c08]
   43328:	and	x13, x13, #0xfffffffffffffffb
   4332c:	b	0x40410
   43330:	mov	x0, #0x830
   43334:	ldur	x26, [sp]
   43338:	str	x0, [x26, #0x48]
   4333c:	mov	x0, #0x0
   43340:	str	x0, [x23, #0x5788]
   43344:	mov	x0, #0x3
   43348:	stur	x0, [sp, #0xc0]
   4334c:	ldr	x0, [sp, #0x198]
   43350:	cmp	x0, #0x19c
   43354:	b.hs	0x4044c
   43358:	b	0x43a18
   4335c:	mov	x0, #0x834
   43360:	ldur	x26, [sp]
   43364:	str	x0, [x26, #0x48]
   43368:	mov	x0, #0x0
   4336c:	str	x0, [x23, #0x5788]
   43370:	mov	x0, #0x3
   43374:	stur	x0, [sp, #0xc0]
   43378:	ldr	x0, [sp, #0x198]
   4337c:	cmp	x0, #0x19c
   43380:	b.hs	0x4060c
   43384:	b	0x43a18
   43388:	mov	x10, #0x838
   4338c:	ldur	x26, [sp]
   43390:	str	x10, [x26, #0x48]
   43394:	mov	x13, #0x0
   43398:	str	x13, [x23, #0x5788]
   4339c:	mov	x0, #0x3
   433a0:	stur	x0, [sp, #0xc0]
   433a4:	ldr	x0, [sp, #0x198]
   433a8:	cmp	x0, #0x19c
   433ac:	b.hs	0x407b0
   433b0:	b	0x43a18
   433b4:	mov	x0, #0x83c
   433b8:	ldur	x26, [sp]
   433bc:	str	x0, [x26, #0x48]
   433c0:	mov	x0, #0x0
   433c4:	str	x0, [x23, #0x5788]
   433c8:	mov	x0, #0x3
   433cc:	stur	x0, [sp, #0xc0]
   433d0:	ldr	x0, [sp, #0x198]
   433d4:	cmp	x0, #0x19c
   433d8:	b.hs	0x40968
   433dc:	b	0x43a18
   433e0:	mov	x0, #0x840
   433e4:	ldur	x26, [sp]
   433e8:	str	x0, [x26, #0x48]
   433ec:	mov	x0, #0x0
   433f0:	str	x0, [x23, #0x5788]
   433f4:	mov	x0, #0x3
   433f8:	ldr	x2, [sp, #0x198]
   433fc:	stur	x0, [sp, #0xc0]
   43400:	cmp	x2, #0x19c
   43404:	b.hs	0x40b18
   43408:	b	0x43a18
   4340c:	mov	x0, #0x849
   43410:	ldur	x26, [sp]
   43414:	str	x0, [x26, #0x48]
   43418:	mov	x1, #0x0
   4341c:	str	x1, [x23, #0x18]
   43420:	mov	x0, #0x1000000000000000
   43424:	str	x0, [x23, #0x20]
   43428:	mov	x0, #0x1
   4342c:	stur	x0, [sp, #0xc0]
   43430:	str	x0, [x23, #0x30]
   43434:	mov	x0, #0x101010101010101
   43438:	str	x0, [x23, #0x38]
   4343c:	mov	x0, #0x2
   43440:	str	x0, [x23, #0x40]
   43444:	mov	x0, #0x3
   43448:	str	x0, [x23, #0x48]
   4344c:	mov	x0, #0x4
   43450:	str	x0, [x23, #0x50]
   43454:	mov	x0, #0xf0f0f0f0f0f0f0f
   43458:	str	x0, [x23, #0x78]
   4345c:	mov	x0, #0x3333333333333333
   43460:	str	x0, [x23, #0x88]
   43464:	mov	x0, #0x38
   43468:	str	x0, [x23, #0x90]
   4346c:	mov	x0, #0x3a
   43470:	str	x0, [x23, #0x98]
   43474:	mov	x0, #0x5555555555555555
   43478:	str	x0, [x23, #0xb0]
   4347c:	mov	x0, #0x3ffffffffffffff
   43480:	str	x0, [x23, #0xb8]
   43484:	str	x1, [x23, #0x188]
   43488:	ldur	x0, [sp, #0xc0]
   4348c:	str	x0, [x23, #0x190]
   43490:	str	x24, [x23, #0x22e0]
   43494:	str	x28, [x23, #0x22e8]
   43498:	ldur	x10, [sp, #0x58]
   4349c:	str	x10, [x23, #0x5788]
   434a0:	str	x3, [x23, #0x5790]
   434a4:	ldur	x4, [sp, #0x60]
   434a8:	str	x4, [x23, #0x5798]
   434ac:	ldur	x1, [sp, #0x28]
   434b0:	str	x1, [x23, #0x6570]
   434b4:	str	x14, [x23, #0x6700]
   434b8:	ldur	x24, [sp, #0x68]
   434bc:	str	x24, [x23, #0x6708]
   434c0:	ldur	x25, [sp, #0x70]
   434c4:	str	x25, [x23, #0x6710]
   434c8:	ldur	x4, [sp, #0x50]
   434cc:	sub	x4, x4, x3
   434d0:	mov	w5, #0xc87e
   434d4:	movk	w5, #0x1, lsl #16
   434d8:	msub	x4, x14, x5, x4
   434dc:	str	x4, [x23, #0x6718]
   434e0:	str	x20, [x23, #0x6720]
   434e4:	str	x15, [x23, #0x6728]
   434e8:	ldur	x19, [sp, #0x78]
   434ec:	str	x19, [x23, #0x6738]
   434f0:	ldur	x26, [sp, #0x80]
   434f4:	str	x26, [x23, #0x6740]
   434f8:	str	x12, [x23, #0x6750]
   434fc:	str	x11, [x23, #0x6758]
   43500:	str	x7, [x23, #0x6768]
   43504:	str	x6, [x23, #0x6770]
   43508:	b	0x43a18
   4350c:	mov	x1, #0x81c
   43510:	ldur	x26, [sp]
   43514:	str	x1, [x26, #0x48]
   43518:	mov	x1, #0x0
   4351c:	str	x1, [x23, #0x18]
   43520:	str	x0, [x23, #0x20]
   43524:	mov	x0, #0x1
   43528:	stur	x0, [sp, #0xc0]
   4352c:	str	x0, [x23, #0x30]
   43530:	mov	x0, #0x101010101010101
   43534:	str	x0, [x23, #0x38]
   43538:	mov	x0, #0x2
   4353c:	str	x0, [x23, #0x40]
   43540:	mov	x0, #0x3
   43544:	str	x0, [x23, #0x48]
   43548:	mov	x0, #0x4
   4354c:	str	x0, [x23, #0x50]
   43550:	mov	x0, #0xf0f0f0f0f0f0f0f
   43554:	str	x0, [x23, #0x78]
   43558:	mov	x0, #0x3333333333333333
   4355c:	str	x0, [x23, #0x88]
   43560:	mov	x0, #0x38
   43564:	str	x0, [x23, #0x90]
   43568:	mov	x0, #0x3a
   4356c:	str	x0, [x23, #0x98]
   43570:	mov	x0, #0x5555555555555555
   43574:	str	x0, [x23, #0xb0]
   43578:	mov	x0, #0x3ffffffffffffff
   4357c:	str	x0, [x23, #0xb8]
   43580:	str	x1, [x23, #0x188]
   43584:	ldur	x0, [sp, #0xc0]
   43588:	str	x0, [x23, #0x190]
   4358c:	ldur	x27, [sp, #0xb8]
   43590:	str	x27, [x23, #0x22e0]
   43594:	ldr	x28, [sp, #0x190]
   43598:	str	x28, [x23, #0x22e8]
   4359c:	ldur	x0, [sp, #0xf8]
   435a0:	uxtb	w0, w0
   435a4:	str	x0, [x23, #0x22f8]
   435a8:	str	x15, [x23, #0x27b0]
   435ac:	ldur	x15, [sp, #0xd8]
   435b0:	str	x15, [x23, #0x27b8]
   435b4:	str	x27, [x23, #0x27c0]
   435b8:	ldur	x10, [sp, #0x58]
   435bc:	str	x10, [x23, #0x5788]
   435c0:	str	x3, [x23, #0x5790]
   435c4:	ldur	x4, [sp, #0x60]
   435c8:	str	x4, [x23, #0x5798]
   435cc:	ldur	x15, [sp, #0x28]
   435d0:	str	x15, [x23, #0x6570]
   435d4:	add	x2, x14, #0x1
   435d8:	str	x2, [x23, #0x6700]
   435dc:	ldur	x24, [sp, #0x68]
   435e0:	str	x24, [x23, #0x6708]
   435e4:	ldur	x25, [sp, #0x70]
   435e8:	str	x25, [x23, #0x6710]
   435ec:	ldur	x4, [sp, #0x50]
   435f0:	sub	x3, x4, x3
   435f4:	mov	w0, #0xc87e
   435f8:	movk	w0, #0x1, lsl #16
   435fc:	msub	x0, x2, x0, x3
   43600:	str	x0, [x23, #0x6718]
   43604:	str	x1, [x23, #0x6720]
   43608:	str	x1, [x23, #0x6728]
   4360c:	ldur	x19, [sp, #0x78]
   43610:	str	x19, [x23, #0x6738]
   43614:	ldur	x26, [sp, #0x80]
   43618:	str	x26, [x23, #0x6740]
   4361c:	ldur	x0, [sp, #0xc0]
   43620:	str	x0, [x23, #0x6750]
   43624:	ldur	x0, [sp, #0x20]
   43628:	str	x0, [x23, #0x6758]
   4362c:	str	x7, [x23, #0x6768]
   43630:	str	x6, [x23, #0x6770]
   43634:	b	0x43a18
   43638:	mov	x4, #0x80c
   4363c:	ldur	x26, [sp]
   43640:	str	x4, [x26, #0x48]
   43644:	mov	x5, #0x0
   43648:	str	x5, [x23, #0x18]
   4364c:	str	x0, [x23, #0x20]
   43650:	mov	x0, #0x1
   43654:	stur	x0, [sp, #0xc0]
   43658:	str	x0, [x23, #0x30]
   4365c:	mov	x8, #0x101010101010101
   43660:	str	x8, [x23, #0x38]
   43664:	mov	x10, #0x2
   43668:	str	x10, [x23, #0x40]
   4366c:	mov	x10, #0x3
   43670:	str	x10, [x23, #0x48]
   43674:	mov	x12, #0x4
   43678:	str	x12, [x23, #0x50]
   4367c:	mov	x12, #0xf0f0f0f0f0f0f0f
   43680:	str	x12, [x23, #0x78]
   43684:	mov	x13, #0x3333333333333333
   43688:	str	x13, [x23, #0x88]
   4368c:	mov	x0, #0x38
   43690:	str	x0, [x23, #0x90]
   43694:	mov	x0, #0x3a
   43698:	str	x0, [x23, #0x98]
   4369c:	mov	x0, #0x5555555555555555
   436a0:	str	x0, [x23, #0xb0]
   436a4:	ldur	x4, [sp, #0xc8]
   436a8:	str	x4, [x23, #0xb8]
   436ac:	str	x5, [x23, #0x188]
   436b0:	ldur	x0, [sp, #0xc0]
   436b4:	str	x0, [x23, #0x190]
   436b8:	ldur	x27, [sp, #0xb8]
   436bc:	str	x27, [x23, #0x22e0]
   436c0:	ldr	x28, [sp, #0x190]
   436c4:	str	x28, [x23, #0x22e8]
   436c8:	ldur	x0, [sp, #0xf8]
   436cc:	uxtb	w0, w0
   436d0:	str	x0, [x23, #0x22f8]
   436d4:	str	x15, [x23, #0x27b0]
   436d8:	ldur	x15, [sp, #0xd8]
   436dc:	str	x15, [x23, #0x27b8]
   436e0:	str	x27, [x23, #0x27c0]
   436e4:	ldur	x19, [sp, #0xd0]
   436e8:	str	x19, [x23, #0x27e8]
   436ec:	str	x11, [x23, #0x2878]
   436f0:	str	x7, [x23, #0x2880]
   436f4:	str	x27, [x23, #0x2888]
   436f8:	ldur	x10, [sp, #0x58]
   436fc:	str	x10, [x23, #0x5788]
   43700:	mov	w0, #0xcb86
   43704:	movk	w0, #0x2, lsl #16
   43708:	sub	x1, x6, x0
   4370c:	str	x1, [x23, #0x5790]
   43710:	ldur	x4, [sp, #0x60]
   43714:	str	x4, [x23, #0x5798]
   43718:	ldur	x0, [sp, #0x28]
   4371c:	str	x0, [x23, #0x6570]
   43720:	add	x2, x14, #0x1
   43724:	str	x2, [x23, #0x6700]
   43728:	ldur	x24, [sp, #0x68]
   4372c:	str	x24, [x23, #0x6708]
   43730:	ldur	x25, [sp, #0x70]
   43734:	str	x25, [x23, #0x6710]
   43738:	ldur	x4, [sp, #0x50]
   4373c:	sub	x1, x4, x1
   43740:	mov	w0, #0xc87e
   43744:	movk	w0, #0x1, lsl #16
   43748:	msub	x0, x2, x0, x1
   4374c:	str	x0, [x23, #0x6718]
   43750:	str	x5, [x23, #0x6720]
   43754:	str	x5, [x23, #0x6728]
   43758:	ldur	x19, [sp, #0x78]
   4375c:	str	x19, [x23, #0x6738]
   43760:	ldur	x26, [sp, #0x80]
   43764:	str	x26, [x23, #0x6740]
   43768:	ldur	x0, [sp, #0xc0]
   4376c:	str	x0, [x23, #0x6750]
   43770:	ldur	x6, [sp, #0x20]
   43774:	str	x6, [x23, #0x6758]
   43778:	str	x0, [x23, #0x6768]
   4377c:	str	x9, [x23, #0x6770]
   43780:	b	0x43a18
   43784:	mov	x0, #0x74b
   43788:	ldur	x26, [sp]
   4378c:	str	x0, [x26, #0x48]
   43790:	mov	x1, #0x0
   43794:	str	x1, [x23, #0x18]
   43798:	mov	x0, #0x1000000000000000
   4379c:	str	x0, [x23, #0x20]
   437a0:	mov	x0, #0x1
   437a4:	stur	x0, [sp, #0xc0]
   437a8:	str	x0, [x23, #0x30]
   437ac:	mov	x0, #0x101010101010101
   437b0:	str	x0, [x23, #0x38]
   437b4:	mov	x0, #0x2
   437b8:	str	x0, [x23, #0x40]
   437bc:	mov	x0, #0x3
   437c0:	str	x0, [x23, #0x48]
   437c4:	mov	x0, #0x4
   437c8:	str	x0, [x23, #0x50]
   437cc:	mov	x0, #0xf0f0f0f0f0f0f0f
   437d0:	str	x0, [x23, #0x78]
   437d4:	mov	x0, #0x3333333333333333
   437d8:	str	x0, [x23, #0x88]
   437dc:	mov	x2, #0x38
   437e0:	str	x2, [x23, #0x90]
   437e4:	mov	x2, #0x3a
   437e8:	str	x2, [x23, #0x98]
   437ec:	mov	x4, #0x5555555555555555
   437f0:	str	x4, [x23, #0xb0]
   437f4:	mov	x4, #0x3ffffffffffffff
   437f8:	str	x4, [x23, #0xb8]
   437fc:	str	x1, [x23, #0x188]
   43800:	ldur	x0, [sp, #0xc0]
   43804:	str	x0, [x23, #0x190]
   43808:	ldur	x27, [sp, #0xb8]
   4380c:	str	x27, [x23, #0x22e0]
   43810:	ldr	x28, [sp, #0x190]
   43814:	str	x28, [x23, #0x22e8]
   43818:	ldur	x0, [sp, #0xf8]
   4381c:	uxtb	w10, w0
   43820:	str	x10, [x23, #0x22f8]
   43824:	str	x9, [x23, #0x2398]
   43828:	ldur	x15, [sp, #0xf0]
   4382c:	str	x15, [x23, #0x23a0]
   43830:	str	x27, [x23, #0x23a8]
   43834:	ldur	x15, [sp, #0xe8]
   43838:	str	x15, [x23, #0x23b0]
   4383c:	ldur	x10, [sp, #0x58]
   43840:	str	x10, [x23, #0x5788]
   43844:	str	x3, [x23, #0x5790]
   43848:	ldur	x4, [sp, #0x60]
   4384c:	str	x4, [x23, #0x5798]
   43850:	ldur	x1, [sp, #0x28]
   43854:	str	x1, [x23, #0x6570]
   43858:	add	x1, x14, #0x1
   4385c:	str	x1, [x23, #0x6700]
   43860:	ldur	x24, [sp, #0x68]
   43864:	str	x24, [x23, #0x6708]
   43868:	ldur	x25, [sp, #0x70]
   4386c:	str	x25, [x23, #0x6710]
   43870:	ldur	x4, [sp, #0x50]
   43874:	sub	x2, x4, x3
   43878:	mov	w0, #0xc87e
   4387c:	movk	w0, #0x1, lsl #16
   43880:	msub	x0, x1, x0, x2
   43884:	str	x0, [x23, #0x6718]
   43888:	ldur	x0, [sp, #0xc0]
   4388c:	str	x0, [x23, #0x6720]
   43890:	ldur	x13, [sp, #0x18]
   43894:	str	x13, [x23, #0x6728]
   43898:	ldur	x19, [sp, #0x78]
   4389c:	str	x19, [x23, #0x6738]
   438a0:	ldur	x26, [sp, #0x80]
   438a4:	str	x26, [x23, #0x6740]
   438a8:	str	x12, [x23, #0x6750]
   438ac:	str	x11, [x23, #0x6758]
   438b0:	str	x7, [x23, #0x6768]
   438b4:	str	x6, [x23, #0x6770]
   438b8:	b	0x43a18
   438bc:	mov	x0, #0x73b
   438c0:	ldur	x26, [sp]
   438c4:	str	x0, [x26, #0x48]
   438c8:	mov	x1, #0x0
   438cc:	str	x1, [x23, #0x18]
   438d0:	mov	x0, #0x1000000000000000
   438d4:	str	x0, [x23, #0x20]
   438d8:	mov	x0, #0x1
   438dc:	stur	x0, [sp, #0xc0]
   438e0:	str	x0, [x23, #0x30]
   438e4:	mov	x0, #0x101010101010101
   438e8:	str	x0, [x23, #0x38]
   438ec:	mov	x0, #0x2
   438f0:	str	x0, [x23, #0x40]
   438f4:	mov	x0, #0x3
   438f8:	str	x0, [x23, #0x48]
   438fc:	mov	x0, #0x4
   43900:	str	x0, [x23, #0x50]
   43904:	mov	x0, #0xf0f0f0f0f0f0f0f
   43908:	str	x0, [x23, #0x78]
   4390c:	mov	x0, #0x3333333333333333
   43910:	str	x0, [x23, #0x88]
   43914:	mov	x0, #0x38
   43918:	str	x0, [x23, #0x90]
   4391c:	mov	x0, #0x3a
   43920:	str	x0, [x23, #0x98]
   43924:	mov	x0, #0x5555555555555555
   43928:	str	x0, [x23, #0xb0]
   4392c:	mov	x0, #0x3ffffffffffffff
   43930:	str	x0, [x23, #0xb8]
   43934:	str	x1, [x23, #0x188]
   43938:	ldur	x0, [sp, #0xc0]
   4393c:	str	x0, [x23, #0x190]
   43940:	ldur	x27, [sp, #0xb8]
   43944:	str	x27, [x23, #0x22e0]
   43948:	ldr	x28, [sp, #0x190]
   4394c:	str	x28, [x23, #0x22e8]
   43950:	ldur	x0, [sp, #0xf8]
   43954:	uxtb	w0, w0
   43958:	str	x0, [x23, #0x22f8]
   4395c:	ldur	x0, [sp, #0xa8]
   43960:	str	x0, [x23, #0x2398]
   43964:	ldur	x15, [sp, #0xf0]
   43968:	str	x15, [x23, #0x23a0]
   4396c:	str	x27, [x23, #0x23a8]
   43970:	ldur	x15, [sp, #0xe8]
   43974:	str	x15, [x23, #0x23b0]
   43978:	ldur	x24, [sp, #0xe0]
   4397c:	uxtb	w0, w24
   43980:	str	x0, [x23, #0x23c0]
   43984:	str	x21, [x23, #0x2458]
   43988:	str	x10, [x23, #0x2460]
   4398c:	str	x27, [x23, #0x2468]
   43990:	str	x15, [x23, #0x2470]
   43994:	ldur	x10, [sp, #0x58]
   43998:	str	x10, [x23, #0x5788]
   4399c:	mov	w4, #0xdc1e
   439a0:	movk	w4, #0x2, lsl #16
   439a4:	sub	x4, x9, x4
   439a8:	str	x4, [x23, #0x5790]
   439ac:	ldur	x0, [sp, #0x60]
   439b0:	str	x0, [x23, #0x5798]
   439b4:	ldur	x1, [sp, #0x28]
   439b8:	str	x1, [x23, #0x6570]
   439bc:	add	x8, x14, #0x1
   439c0:	str	x8, [x23, #0x6700]
   439c4:	ldur	x24, [sp, #0x68]
   439c8:	str	x24, [x23, #0x6708]
   439cc:	ldur	x25, [sp, #0x70]
   439d0:	str	x25, [x23, #0x6710]
   439d4:	ldur	x0, [sp, #0x50]
   439d8:	sub	x10, x0, x4
   439dc:	mov	w13, #0xc87e
   439e0:	movk	w13, #0x1, lsl #16
   439e4:	msub	x10, x8, x13, x10
   439e8:	str	x10, [x23, #0x6718]
   439ec:	ldur	x0, [sp, #0xc0]
   439f0:	str	x0, [x23, #0x6720]
   439f4:	ldur	x13, [sp, #0x18]
   439f8:	str	x13, [x23, #0x6728]
   439fc:	str	x0, [x23, #0x6738]
   43a00:	ldur	x3, [sp, #0xb0]
   43a04:	str	x3, [x23, #0x6740]
   43a08:	str	x12, [x23, #0x6750]
   43a0c:	str	x11, [x23, #0x6758]
   43a10:	str	x7, [x23, #0x6768]
   43a14:	str	x6, [x23, #0x6770]
   43a18:	mov	x1, #0x0
   43a1c:	ldur	x0, [sp, #0xc0]
   43a20:	add	sp, sp, #0x1d0
   43a24:	ldp	x19, x20, [sp], #0x10
   43a28:	ldp	x21, x22, [sp], #0x10
   43a2c:	ldp	x23, x24, [sp], #0x10
   43a30:	ldp	x25, x26, [sp], #0x10
   43a34:	ldp	x27, x28, [sp], #0x10
   43a38:	ldp	x29, x30, [sp], #0x10
   43a3c:	.long	0xd65f0fff
   43a40:	udf	#0x0
   43a44:	udf	#0x0
   43a48:	udf	#0x0
   43a4c:	udf	#0x0
   43a50:	udf	#0x0
   43a54:	udf	#0x0
   43a58:	udf	#0x0
   43a5c:	udf	#0x0
   43a60:	udf	#0x0
   43a64:	udf	#0x0
   43a68:	udf	#0x0
   43a6c:	udf	#0x0
   43a70:	udf	#0x0
   43a74:	udf	#0x0
   43a78:	udf	#0x0
   43a7c:	udf	#0x0
