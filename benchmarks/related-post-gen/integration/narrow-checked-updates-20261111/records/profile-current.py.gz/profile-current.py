from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,re
E=Path(__file__).parent;P=E/'profile';P.mkdir(exist_ok=False);N=E/'runners';S=Path('/private/tmp/mech-related-narrow-updates-compiler-20261111');B=S/'benchmarks/related-post-gen';INPUT=E/'frozen-inputs/posts.json';ORACLE=E/'frozen-inputs/expected.json'
write=lambda p,d:Path(p).write_text(json.dumps(d,indent=2)+'\n')
def run(c,out):
 c=list(map(str,c));t=time.monotonic();r=subprocess.run(c,capture_output=True,text=True);write(P/(out+'.json'),dict(command=c,exit=r.returncode,seconds=time.monotonic()-t,stdout=r.stdout,stderr=r.stderr));print(out,r.returncode,flush=True);assert r.returncode==0,r.stderr[-5000:];return r
for label in ['baseline','counts-postings32']:
 d=P/label;d.mkdir();(d/'build').symlink_to(N/label/'build',target_is_directory=True);shutil.copyfile('/private/tmp/mech-related-numeric-owner-handoff-runners-20261108-v2/histogram-reuse/runner-native-profile.rs',d/'runner.rs')
 run(['python3','/private/tmp/mech-related-pr990-rebase-evidence-20261111/build-cargo-host.py','--compiler-build',E/'runtime/build.json','--source',d/'runner.rs','--out',d/'runner-profile','--bundle',d/'build','--linked'],label+'-build')
 run(['python3',B/'audit-native-link.py','--object',d/'build/object.o','--executable',d/'runner-profile','--output',d/'same-object-audit.json'],label+'-audit')
snapshot=subprocess.check_output(['ps','-axo','pid,ppid,comm'],text=True);busy=[]
for line in snapshot.splitlines()[1:]:
 if any(line.rstrip().endswith('/'+name)for name in ['rustc','cargo','sample','gzip','gpu-tests','engine-tests']):busy.append(line)
write(P/'quiet-before-profiles.json',dict(quiet=not busy,busy=busy,process_snapshot_sha256=hashlib.sha256(snapshot.encode()).hexdigest()));assert not busy
for label in ['baseline','counts-postings32']:
 d=P/label;cmd=list(map(str,[d/'runner-profile',d/'build/source.mec',INPUT,d/'output.json','1']));t=time.monotonic()
 with(d/'stdout.txt').open('w')as o,(d/'stderr.txt').open('w')as e:
  proc=subprocess.Popen(cmd,stdout=o,stderr=e);sc=['/usr/bin/sample',str(proc.pid),'10','1','-file',str(d/'native.sample.txt')];sr=subprocess.run(sc,capture_output=True,text=True);code=proc.wait()
 assert sr.returncode==code==0,(code,sr.stderr)
 assert json.loads((d/'output.json').read_text())==json.loads(ORACLE.read_text())
 write(d/'receipt.json',dict(command=cmd,exit=code,seconds=time.monotonic()-t,sampler_command=sc,sampler_exit=sr.returncode,sampler_stdout=sr.stdout,sampler_stderr=sr.stderr,same_Object_audit_passed=True,diagnostic_only=True,promotion_timing_eligible=False,repeated_native_invocations=10001,exact_final5000_output=True,input_sha256=hashlib.sha256(INPUT.read_bytes()).hexdigest(),output_sha256=hashlib.sha256((d/'output.json').read_bytes()).hexdigest(),scope='Repeated evaluate_into including fresh invocation/worker lifecycle and cleanup. Admission/export/materialization excluded from repeated loop. Inclusive sample stacks overlap and are not additive savings.'))
 print(label,'fresh diagnostic profile exact final5000',flush=True)
