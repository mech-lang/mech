from pathlib import Path
import json,subprocess,time
E=Path(__file__).parent;old=Path('/private/tmp/mech-related-complete-tree-selection-20261111-v2');c=json.loads((old/'compiler-host-run.json').read_text())['command'];c=[x.replace(str(old),str(E))for x in c];t=time.monotonic();r=subprocess.run(c,capture_output=True,text=True);(E/'compiler-host-run.json').write_text(json.dumps(dict(command=c,exit=r.returncode,seconds=time.monotonic()-t,stdout=r.stdout,stderr=r.stderr),indent=2)+'\n');print('compiler host',r.returncode,flush=True);assert r.returncode==0,r.stderr
subprocess.run(['python3',str(E/'compile-sources.py')],check=True)
