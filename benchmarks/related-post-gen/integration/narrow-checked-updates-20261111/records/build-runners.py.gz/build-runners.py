from pathlib import Path
import shutil,json,subprocess,time
E=Path(__file__).parent;B=Path('/private/tmp/mech-related-pr990-rebase-evidence-20261111');S=Path('/private/tmp/mech-related-narrow-updates-compiler-20261111');N=E/'runners';N.mkdir(exist_ok=False);oracle=json.loads(Path('/private/tmp/mech-related-narrow-updates-20261111/frozen-inputs/expected.json').read_text())
for label in ['baseline','counts32','postings32','counts-postings32']:
 d=N/label;d.mkdir();shutil.copytree(E/'objects'/label,d/'build');shutil.copyfile(B/'ir312-runners/patched/runner.rs',d/'runner.rs')
 def run(c,name):
  c=list(map(str,c));t=time.monotonic();r=subprocess.run(c,capture_output=True,text=True);(d/(name+'.json')).write_text(json.dumps(dict(command=c,exit=r.returncode,seconds=time.monotonic()-t,stdout=r.stdout,stderr=r.stderr,qualification_only=True),indent=2)+'\n');print(label,name,r.returncode,flush=True)
  if r.returncode:print(r.stdout[-5000:]+r.stderr[-5000:],flush=True)
  assert r.returncode==0
 run(['python3',B/'build-cargo-host.py','--compiler-build',E/'runtime/build.json','--source',d/'runner.rs','--out',d/'runner-aot','--bundle',d/'build','--linked'],'runner-build');run(['python3',S/'benchmarks/related-post-gen/audit-native-link.py','--object',d/'build/object.o','--executable',d/'runner-aot','--output',d/'same-object-audit.json'],'audit-run');run([d/'runner-aot',d/'build/source.mec','/private/tmp/mech-related-narrow-updates-20261111/frozen-inputs/posts.json',d/'output.json','1'],'actual5000');assert json.loads((d/'output.json').read_text())==oracle;run(['python3',S/'benchmarks/related-post-gen/experiments/check_subset3.py','--runner',d/'runner-aot','--rust','/private/tmp/mech-related-post-rust-local-20261102/rust/target/release/rust','--source',d/'build/source.mec','--out',d/'edges'],'edge-run');print(label,'32 exact outputs',flush=True)
