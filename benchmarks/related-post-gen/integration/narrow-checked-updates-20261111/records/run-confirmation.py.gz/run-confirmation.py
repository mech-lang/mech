from pathlib import Path
import hashlib,json,os,re,subprocess,time
E=Path(__file__).parent;Q=E/'confirmation';R=Path('/Users/cim310/mech-lang/mech/benchmarks/related-post-gen');read=lambda p:json.loads(Path(p).read_text());rule=read(E/'prospective-rule.json')
def quiet(name):
 snapshot=subprocess.check_output(['ps','-axo','pid,ppid,comm'],text=True);busy=[]
 for l in snapshot.splitlines()[1:]:
  a=l.split(None,2)
  if len(a)!=3 or int(a[0])in[os.getpid(),os.getppid()]:continue
  if a[2].rsplit('/',1)[-1]in['rustc','cargo','clang','clang++','sample','gzip','xz','zstd','gpu-tests','engine-tests','one-kib','scalar','runner-aot','runner-metrics','runner-profile']:busy.append(a)
 (Q/(name+'-quiet.json')).write_text(json.dumps(dict(no_build_test_profile_archive_overlap=not busy,busy=busy,process_snapshot_sha256=hashlib.sha256(snapshot.encode()).hexdigest()),indent=2)+'\n');assert not busy,busy
for kind,samples,seed,config in [('latency',31,rule['confirmation_seed'],E/'confirmation-latency-config.json'),('resources',7,rule['confirmation_resource_seed'],E/'confirmation-resources-config.json')]:
 quiet(kind);c=['python3',str(R/'compare-implementations.py'),'--config',str(config),'--input',str(E/'frozen-inputs/posts.json'),'--samples',str(samples),'--order','randomized','--seed',str(seed),'--deduplicate-outputs','--work',str(Q/kind),'--output',str(Q/(kind+'.json'))]
 if kind=='resources':c.append('--resources')
 t=time.monotonic();r=subprocess.run(c,capture_output=True,text=True);(Q/(kind+'-run.json')).write_text(json.dumps(dict(command=c,exit=r.returncode,seconds=time.monotonic()-t,stdout=r.stdout,stderr=r.stderr),indent=2)+'\n');print(kind,'exit',r.returncode,'seconds',round(time.monotonic()-t,2),flush=True)
 if r.returncode:print(r.stderr[-6000:],flush=True)
 assert r.returncode==0
 if kind=='latency':
  d=read(Q/'latency.json');ref=d['matched_native_reference']['variant'];rs=read(E/'confirmation-resources-config.json');assert any(v['name']==ref+'-instrumented'for v in rs['implementations']);rs['resource_reference']=ref+'-instrumented';rs['whole_process_resource_reference']=d['whole_process_reference']['variant']+'-instrumented';(E/'resources-config-matched-confirmation-latency.json').write_text(json.dumps(rs,indent=2)+'\n')
  # The pinned resource configuration remains unchanged; the measured fastest
  # reference mapping is preserved separately for analysis and ratios.
