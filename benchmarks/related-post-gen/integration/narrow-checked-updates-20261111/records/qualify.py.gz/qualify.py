import json,subprocess,time,os,sys,re
from pathlib import Path
ROOT=Path(__file__).parent;P=ROOT/'qualification';P.mkdir(exist_ok=True);S=Path('/private/tmp/mech-related-narrow-updates-compiler-20261111');EXE=ROOT/'tests/gpu-tests'
def run(args,name,env=None):
 c=[str(EXE),*args];start=time.monotonic();x=subprocess.run(c,cwd=S,capture_output=True,text=True,env={**os.environ,**(env or {})});receipt=P/(name+'.json');attempt=1
 while receipt.exists():
  attempt+=1;receipt=P/(name+'-attempt-'+str(attempt)+'.json')
 receipt.write_text(json.dumps(dict(command=c,environment=env or {},exit=x.returncode,seconds=time.monotonic()-start,stdout=x.stdout,stderr=x.stderr,qualification_only=True),indent=2)+'\n');print(name,x.returncode,flush=True)
 if x.returncode:print(x.stdout[-14000:]+x.stderr[-14000:],flush=True)
 return x
if sys.argv[1]=='inventory':
 wf=(S/'.github/workflows/ci-full.yml').read_text();section=wf.split('- name: Inventory and execute native composition contracts',1)[1].split('- name:',1)[0];selection=section.split('--lib --',1)[1].split('--list',1)[0].replace('\\',' ').split();x=run([*selection,'--list'],'integrated-ci-list');assert x.returncode==0;names={l[:-6]for l in x.stdout.splitlines()if l.endswith(': test')};old=json.loads(Path('/private/tmp/mech-related-numeric-owner-handoff-20261108/final-qualification/integrated-ci-list.json').read_text());prior={l[:-6]for l in old['stdout'].splitlines()if l.endswith(': test')};missing=sorted(prior-names);print('listed',len(names),'selected IR308 names missing',missing,flush=True);assert not missing
 (P/'integrated-ci-inventory.json').write_text(json.dumps(dict(selection=selection,names=sorted(names),selected_IR308_names_preserved=True,added=sorted(names-prior)),indent=2)+'\n')
 expected=int(re.search(r'native-composition-tests.txt\)\" -eq (\d+)',section)[1]);assert expected==len(names),(expected,len(names))
elif sys.argv[1]=='critical':
 x=run(['numeric_outlining','numeric_tree_owner_handoff','--test-threads=1','--nocapture'],'critical-native-mechanisms');assert x.returncode==0
elif sys.argv[1]=='ci':
 q=json.loads((P/'integrated-ci-inventory.json').read_text());x=run([*q['selection'],'--test-threads=1'],'integrated-ci-execute');passed={l[5:-7]for l in x.stdout.splitlines()if l.startswith('test ')and l.endswith(' ... ok')};print('passed',len(passed),'expected',len(q['names']),flush=True);assert x.returncode==0 and passed==set(q['names'])
elif sys.argv[1]=='extra':
 for name,selection in [('all-retained-map-contracts',['program::runtime::maps::']),('image-and-caller-geometry',['program::image::','caller_geometry::tests']),('classification-UTF8-range-protocol',['native_string_classes','unsigned_guard_facts::','modular_ranges','codegen::utf8_lookup::','codegen::utf8_histogram::','compiled_histogram_tests','program::protocol::']),('packed-frame-effects',['codegen::packed_map::frame_state::tests'])]:
  x=run([*selection,'--test-threads=1'],name);assert x.returncode==0
elif sys.argv[1]=='actual':
 x=run(['matrix_map_keys_full_input_selects_28','--ignored','--test-threads=1','--nocapture'],'actual-source-full5000',{'MECH_MATRIX_KEY_BENCH_SOURCE':str(S/'benchmarks/related-post-gen/experiments/related-u64-four-workers-ir314.mec'),'MECH_MATRIX_KEY_BENCH_INPUT':'/private/tmp/mech-related-narrow-updates-20261111/frozen-inputs/posts.json','MECH_MATRIX_KEY_BENCH_ORACLE':'/private/tmp/mech-related-narrow-updates-20261111/frozen-inputs/expected.json'});assert x.returncode==0
