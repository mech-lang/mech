from pathlib import Path
import importlib.util,json,hashlib
E=Path(__file__).parent;old=Path('/private/tmp/mech-related-complete-tree-selection-20261111-v2');S=Path('/private/tmp/mech-related-narrow-updates-compiler-20261111');sp=importlib.util.spec_from_file_location('audit',S/'benchmarks/related-post-gen/audit-native-link.py');a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a)
def text(p):
 d,s,_=a.macho(p);s=next(x for x in s if x['name']=='__text');return d[s['offset']:s['offset']+s['size']]
rows=[]
for n in ['baseline','counts32','postings32','counts-postings32']:
 m=json.loads((E/'objects'/n/'metadata.json').read_text());p=json.loads((old/'objects'/n/'metadata.json').read_text());t=text(E/'objects'/n/'object.o');pt=text(old/'objects'/n/'object.o');d={}
 for label,v in [('IR314',p),('IR315',m)]:
  r=v.get('compiled_numeric_write_loops',[])+v.get('compiled_readonly_numeric_loops',[]);d[label]=dict(checked_increment_writes=sum(len(x['proven_checked_increment_writes']) for x in r),independent_view_increment_writes=sum(len(x['proven_independent_view_increment_writes'])for x in r),code_bytes=v['code_bytes'],reported_module_stack_bound_bytes=v['stack_bytes'],numeric_functions=len(v['compiled_numeric_functions']))
 d.update(variant=n,native_text_equal_to_same_source_IR314=t==pt,native_text_sha256=hashlib.sha256(t).hexdigest(),parent_native_text_sha256=hashlib.sha256(pt).hexdigest(),native_text_bytes=len(t));p=E/'runners'/n/'runner-aot'
 if p.exists():d.update(executable_bytes=p.stat().st_size,executable_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 rows.append(d);print(d,flush=True)
(E/'native-code-inspection.json').write_text(json.dumps(rows,indent=2)+'\n')
