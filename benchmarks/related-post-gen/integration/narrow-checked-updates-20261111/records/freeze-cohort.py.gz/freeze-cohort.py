from pathlib import Path
import json,hashlib,shutil,subprocess,datetime,importlib.util
E=Path(__file__).parent;old=Path('/private/tmp/mech-related-complete-tree-selection-20261111-v2');S=Path('/private/tmp/mech-related-narrow-updates-compiler-20261111');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text());D=E/'frozen-inputs';assert sha(D/'posts.json')=='500530b81cb81c5b1a5e48aa30de6a89ba0a350460ad826c4c7bb023e6e46cb8'
for n in ['integrated-ci-execute','critical-native-mechanisms','all-retained-map-contracts','image-and-caller-geometry','classification-UTF8-range-protocol','packed-frame-effects','actual-source-full5000']:
 assert read(E/'qualification'/f'{n}.json')['exit']==0,n
names=set(read(E/'qualification/integrated-ci-inventory.json')['names']);prior=set(read(old/'qualification/integrated-ci-inventory.json')['names']);assert len(names)==508 and prior<=names
assert all(v['all_non_timing_fields_exact']and not v['changes']for v in read(E/'regressions/comparison.json'))
for n in ['baseline','counts32','postings32','counts-postings32']:
 for r in ['audit-run.json','actual5000.json','edge-run.json']:assert read(E/'runners'/n/r)['exit']==0,(n,r)
lat=read(E/'latency-config.json');notes=[]
for v in lat['implementations']:
 assert sha(v['executable'])==v['executable_sha256'],v['name']
 if v['kind']!='upstream':continue
 root=D/v['name'];root.mkdir(exist_ok=True)
 for field in ['executable','source','receipt']:
  if field not in v:continue
  p=Path(v[field]);assert p.is_file();q=root/(p.name if field=='executable'else field+p.suffix);shutil.copy2(p,q);assert sha(q)==v[field+'_sha256'];v['copied_from_'+field]=str(p);v[field]=str(q)
 notes.append(dict(variant=v['name'],executable_sha256=v['executable_sha256'],frozen_executable=v['executable']))
assert len(lat['implementations'])==31
(E/'latency-config-frozen.json').write_text(json.dumps(lat,indent=2)+'\n')
res=read(E/'existing-resources.json');fresh=read(E/'metrics/metrics-config.json');assert fresh['measurement_source_sha256']==read(old/'metrics/metrics-config.json')['measurement_source_sha256'];res['implementations'] += [v for v in fresh['implementations']if v['kind']=='mech'];assert len(res['implementations'])==32
for v in res['implementations']:
 if 'executable_sha256'not in v:
  r=read(v['receipt']);assert r['exit']==0 and sha(v['executable'])==r['executable_sha256'];assert sha(v['source'])==r['bundle']['source.mec']['sha256'];v.update(executable_sha256=r['executable_sha256'],source_sha256=sha(v['source']),receipt_sha256=sha(v['receipt']),executable_file_bytes=Path(v['executable']).stat().st_size)
 assert sha(v['executable'])==v['executable_sha256'],v['name']
 # Preserve every original executable byte and available source/receipt. Legacy
 # unavailable source/receipt notes stay explicit; no files are fabricated.
 if v['kind']=='upstream':
  root=D/(v['name']+'-resource');root.mkdir(exist_ok=True)
  for field in ['executable','source','receipt']:
   if field not in v:continue
   p=Path(v[field]);assert p.is_file();q=root/(p.name if field=='executable'else field+p.suffix);shutil.copy2(p,q);assert sha(q)==v[field+'_sha256'];v['copied_from_'+field]=str(p);v[field]=str(q)
res['prospective_performance_rule']=str(E/'prospective-rule.json');res['authoritative_latency_comparison']=str(E/'first/latency.json');res['resource_reference']='rust-ordered-mask-tables256-instrumented';res['measurement_source_sha256']=fresh['measurement_source_sha256'];(E/'resources-config.json').write_text(json.dumps(res,indent=2)+'\n');(E/'reference-freeze.json').write_text(json.dumps(notes,indent=2)+'\n')
current=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip();assert subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=S,text=True)==''
spec=importlib.util.spec_from_file_location('b',S/'benchmarks/related-post-gen/build-compiler.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);files=b.source_inventory(S)
for label in ['compiler','runtime','tests']:assert files==read(E/label/'source-inventory.json')['files'],label
Q=E/'first';Q.mkdir(exist_ok=False);(Q/'source-freeze.json').write_text(json.dumps(dict(commit=current,compiler_source_sha256=read(E/'compiler/build.json')['source_sha256'],input_sha256=sha(D/'posts.json'),latency_config_sha256=sha(E/'latency-config-frozen.json'),resources_config_sha256=sha(E/'resources-config.json'),rule_sha256=sha(E/'prospective-rule.json'),UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),all_frozen_libraries_and_binaries_pinned=True,qualified_compiler_names=508,all505_parent_names_retained=True),indent=2)+'\n');print('source freeze',current,'31 latency /32 resource variants;505 parent names retained',flush=True)
