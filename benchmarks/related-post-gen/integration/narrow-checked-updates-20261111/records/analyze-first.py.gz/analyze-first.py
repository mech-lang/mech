from pathlib import Path
import json,math,random,statistics as st
E=Path(__file__).parent;Q=E/'first';read=lambda p:json.loads(Path(p).read_text())
lat=read(Q/'latency.json');res=read(Q/'resources.json')
assert len(lat['samples'])==31*31 and len(res['samples'])==32*7
assert all(s['exit']==0 and s['exact_rust_output'] for s in lat['samples']+res['samples'])
def quant(a,q):
 x=(len(a)-1)*q;i=math.floor(x);j=math.ceil(x);return a[i]+(a[j]-a[i])*(x-i)
def paired(a,b,f):
 data={n:{x['sample']:x.get(f,x['seconds']) for x in lat['samples']if x['variant']==n}for n in[a,b]};assert all(set(d)==set(range(31))for d in data.values())
 d=[data[a][i]/data[b][i]-1 for i in range(31)];rng=random.Random(202611110516);boots=sorted(st.median(d[rng.randrange(31)]for _ in range(31))for _ in range(20000))
 return dict(candidate=a,baseline=b,pairs=31,wins=sum(v<0 for v in d),median_paired_relative_change=st.median(d),two_sided_95_interval=[quant(boots,.025),quant(boots,.975)],all_pair_changes=d)
base='mech-ir315-baseline-4';pub='mech-ir314-baseline-4';old='mech-ir308-numeric-owner-handoff-4';variants=[f'mech-ir315-{n}-4'for n in ['counts32','postings32','counts-postings32']]
ref=lat['matched_native_reference']['variant']
pairs={}
comparisons=[(base,pub),(pub,old)]
for a in variants:
 for b in [base,pub,a.replace('ir315','ir314')]:
  comparisons.append((a,b))
comparisons += [(a,ref)for a in [base,*variants]]
for a,b in comparisons:
 fields=['post_json_seconds','wall_seconds','compile_or_restore_seconds'] if b.startswith('mech') else ['post_json_seconds']
 pairs[a+' vs '+b]={f:paired(a,b,f)for f in fields}
med={}
for n,v in lat['summary'].items():
 if n.startswith('mech-')or n==ref:
  rows=[x for x in lat['samples']if x['variant']==n];med[n]={f:st.median(x[f]for x in rows)for f in ['post_json_seconds','wall_seconds','compile_or_restore_seconds']if all(f in x for x in rows)};med[n]['median_post_json_seconds']=v.get('median_post_json_seconds',v['median_seconds']);med[n]['times_fastest_eligible_Rust']=v['post_json_over_fastest_matched_native']
resources={};rref=ref+'-instrumented';assert rref in res['summary']
for n,v in res['summary'].items():
 if n.startswith('mech-')or n==rref:
  resources[n]={k:v[k]for k in['post_json_measurement_median','process_resources_median','stage_measurements_median']if k in v}
deltas={}
b=resources[base+'-instrumented']['post_json_measurement_median']
for n in variants:
 a=resources[n+'-instrumented']['post_json_measurement_median']
 deltas[n]={k:{'candidate':a[k],'baseline':b[k],'delta':a[k]-b[k],'fraction':a[k]/b[k]-1}for k in ['allocation_requests','requested_allocation_bytes','peak_additional_live_requested_heap_bytes']}
 deltas[n].update({k:{'candidate':a['hardware'][k],'baseline':b['hardware'][k],'delta':a['hardware'][k]-b['hardware'][k],'fraction':a['hardware'][k]/b['hardware'][k]-1}for k in ['instructions_retired','cycles']})
advancing=[n for n in variants if all(pairs[n+' vs '+b]['post_json_seconds']['two_sided_95_interval'][1]<0 for b in [base,pub,n.replace('ir315','ir314')])]
out=dict(exact_latency_outputs=len(lat['samples']),exact_resource_outputs=len(res['samples']),all_first_and_adverse_samples_retained=True,fastest_eligible_Rust=lat['matched_native_reference'],resource_reference_matched_to_latency=rref,raw_resource_default_reference=res['resource_reference'],medians=med,resource_medians=resources,paired_comparisons=pairs,source_resource_deltas=deltas,latency_confirmation_candidates=advancing,whole_process_gate=False,unchanged_inconclusive_variants_not_repeated=True,goal_complete=False,analysis_bootstrap_seed=202611110516,bootstrap_resamples=20000,bootstrap_seed_registered_before_capture=True,bootstrap_note='Deterministic descriptive uncertainty of median paired relative changes; no first samples or outliers discarded. No repeated favorable seed selection.')
(Q/'paired-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print('outputs',len(lat['samples']),len(res['samples']),'advance',advancing)
for k,v in pairs.items():
 r=v['post_json_seconds'];print(k,'paired%',round(100*r['median_paired_relative_change'],4),'CI%', [round(100*x,4) for x in r['two_sided_95_interval']],'wins',r['wins'])
for n,r in resources.items():
 a=r['post_json_measurement_median'];print(n,{k:a[k]for k in ['allocation_requests','requested_allocation_bytes','peak_additional_live_requested_heap_bytes']},{k:a['hardware'][k]for k in ['instructions_retired','cycles']})
