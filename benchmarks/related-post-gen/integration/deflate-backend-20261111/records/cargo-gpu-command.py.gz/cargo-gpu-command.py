import json
from pathlib import Path
P=Path(__file__).parent

def command(build, output, test=False, runtime=False):
 gpu=build['stages'][-1];args=gpu['command'];out=[];i=0
 while i<len(args):
  arg=args[i]
  if arg in ['--out-dir','--emit','--json','--error-format']:
   i+=2;continue
  if arg.startswith(('--emit=','--json=','--error-format=')):
   i+=1;continue
  if arg=='--crate-type':
   out.extend(['--test']if test else ['--crate-type=rlib']);i+=2;continue
  if arg=='-C'and args[i+1].startswith(('metadata=','extra-filename=')):
   i+=2;continue
  if runtime and arg=='--cfg'and args[i+1].startswith('feature='):
   i+=2;continue
  out.append(arg);i+=1
 if runtime:
  for feature in ['canonical-native-runtime','canonical-native-program-runtime']:out+=['--cfg','feature="'+feature+'"']
 out+=['-D','warnings','-C','metadata=related_312_'+('tests'if test else'runtime'),'-o',str(output)]
 if test:
  records=[json.loads(s)for s in(P/'cargo-patched-test-deps-v2.jsonl').read_text().splitlines()];art={r['target']['name']:r for r in records if r.get('reason')=='compiler-artifact'}
  old={out[j+1].split('=')[0]for j,a in enumerate(out[:-1])if a=='--extern'}
  for name in ['mech_runtime','mech_stdlib','mech_syntax','tempfile']:
   if name in old:continue
   path=next(p for p in art[name]['filenames']if p.endswith('.rlib'));out+=['--extern',name+'='+path]
 for i,arg in enumerate(out[:-1]):
  if arg=='--extern' and out[i+1].endswith('.rmeta'):
   name,path=out[i+1].split('=',1);library=Path(path).with_suffix('.rlib');assert library.exists(),library;out[i+1]=name+'='+str(library)
 return out,gpu['environment']
