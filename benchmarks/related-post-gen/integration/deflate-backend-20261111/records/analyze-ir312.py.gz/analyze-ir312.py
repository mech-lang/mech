from pathlib import Path
import json,math,random,statistics as st
E=Path(__file__).parent;Q=E/'ir312-first-v2';read=lambda p:json.loads(Path(p).read_text())
lat=read(Q/'latency.json');res=read(Q/'resources-v2.json')
assert len(lat['samples'])==29*31 and len(res['samples'])==30*7
assert all(s['exit']==0 and s['exact_rust_output'] for s in lat['samples']+res['samples'])
def quant(a,q):
 x=(len(a)-1)*q;i=math.floor(x);j=math.ceil(x);return a[i]+(a[j]-a[i])*(x-i)
def paired(a,b,f):
 data={n:{x['sample']:x[f]for x in lat['samples']if x['variant']==n}for n in[a,b]};assert all(set(d)==set(range(31))for d in data.values())
 d=[data[a][i]/data[b][i]-1 for i in range(31)];rng=random.Random(202611110314);boots=sorted(st.median(d[rng.randrange(31)]for _ in range(31))for _ in range(20000))
 return dict(candidate=a,baseline=b,pairs=31,wins=sum(v<0 for v in d),median_paired_relative_change=st.median(d),two_sided_95_interval=[quant(boots,.025),quant(boots,.975)],all_pair_changes=d)
pairs={}
base='mech-ir312-stock-4';pat='mech-ir312-patched-4';old='mech-ir308-numeric-owner-handoff-4';reb='mech-ir311-rebased-4'
for a,b in [(pat,base),(pat,old),(reb,old),(base,reb),*[(f'mech-ir312-{n}-4',pat)for n in ['byte-ids','tables256','byte-tables256']]]:
 pairs[a+' vs '+b]={f:paired(a,b,f)for f in ['post_json_seconds','wall_seconds','compile_or_restore_seconds']}
med={}
for n,v in lat['summary'].items():
 if n.startswith('mech-'):
  rows=[x for x in lat['samples']if x['variant']==n];med[n]={f:st.median(x[f]for x in rows)for f in ['post_json_seconds','wall_seconds','compile_or_restore_seconds']};med[n]['times_fastest_eligible_Rust']=v['post_json_over_fastest_matched_native']
resources={}
for n,v in res['summary'].items():
 if n.startswith('mech-')or n==res['resource_reference']:
  resources[n]={k:v[k]for k in['post_json_measurement_median','process_resources_median','stage_measurements_median']if k in v}
a=resources[pat+'-instrumented']['post_json_measurement_median'];b=resources[base+'-instrumented']['post_json_measurement_median']
backend_delta=dict(instructions=a['hardware']['instructions_retired']-b['hardware']['instructions_retired'],instructions_fraction=a['hardware']['instructions_retired']/b['hardware']['instructions_retired']-1,cycles=a['hardware']['cycles']-b['hardware']['cycles'],same_allocations=a['allocation_requests']==b['allocation_requests'],same_requested_bytes=a['requested_allocation_bytes']==b['requested_allocation_bytes'],same_peak_additional_heap=a['peak_additional_live_requested_heap_bytes']==b['peak_additional_live_requested_heap_bytes'],native_code_bytes=-4568,reported_stack_bound_bytes=16)
ci=pairs[pat+' vs '+base]['post_json_seconds']['two_sided_95_interval']
out=dict(exact_latency_outputs=len(lat['samples']),exact_resource_outputs=len(res['samples']),all_first_and_adverse_samples_retained=True,fastest_eligible_Rust=lat['matched_native_reference'],medians=med,resource_medians=resources,paired_comparisons=pairs,backend_resource_delta=backend_delta,latency_win_demonstrated=ci[1]<0,whole_process_gate=False,unchanged_adverse_variants_not_repeated=True,source_variants_selected=False,goal_complete=False,analysis_bootstrap_seed=202611110314,bootstrap_resamples=20000,bootstrap_seed_registered_after_capture=True,bootstrap_note='Deterministic descriptive uncertainty of median paired relative changes; no first samples or outliers discarded. No repeated favorable seed selection.')
(Q/'paired-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print('outputs',len(lat['samples']),len(res['samples']));print('backend resources',backend_delta)
for k,v in pairs.items():
 r=v['post_json_seconds'];print(k,'paired%',100*r['median_paired_relative_change'],'CI%', [100*x for x in r['two_sided_95_interval']],'wins',r['wins'])
