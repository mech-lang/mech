from pathlib import Path
import json,subprocess,os,hashlib,time,copy,sys,importlib.util
P=Path(__file__).parent;S=Path('/private/tmp/mech-related-pr990-rebase-20261111');O=Path('/private/tmp/mech-related-pr990-backend-opt-20261111');O.mkdir(exist_ok=True)
base=Path('/private/tmp/mech-related-pr990-rebase-opt-20261111-v4/build.json');b=json.loads(base.read_text());prior_inventory=json.loads(base.with_name('source-inventory.json').read_text())['files'];spec=importlib.util.spec_from_file_location('h',S/'benchmarks/related-post-gen/build-compiler.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);files=h.source_inventory(S);source_hash=hashlib.sha256(json.dumps(files,sort_keys=True).encode()).hexdigest();(O/'source-inventory.json').write_text(json.dumps(dict(root=str(S),files=files,sha256=source_hash),indent=2)+'\n')
backend=json.loads((P/'backend-libraries.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();backend_libs={name:next(path for path in row['filenames']if path.endswith('.rlib'))for name,row in backend.items()};b=copy.deepcopy(b);b.update(source_sha256=source_hash,base_build=str(base),backend_build=str(P/'backend-build.jsonl'),backend_build_sha256=sha(P/'backend-build.jsonl'),backend_provenance_sha256=sha(S/'vendor/compiler-backend-provenance.json'),backend_libraries={n:dict(path=p,sha256=sha(p))for n,p in backend_libs.items()});gpu=b['stages'][-1];assert gpu['crate']=='mech_gpu'
for stage in b['stages'][:-1]:
 assert sha(stage['command'][-1])==stage['library_sha256'];manifest=Path(stage['environment']['CARGO_MANIFEST_DIR']);candidates=[Path(*manifest.parts[i:])for i in range(1,len(manifest.parts))if str(Path(*manifest.parts[i:])/'Cargo.toml')in prior_inventory];assert len(candidates)==1;prefix=str(candidates[0])+'/' 
 assert {k:v for k,v in files.items()if k.startswith(prefix)}=={k:v for k,v in prior_inventory.items()if k.startswith(prefix)},stage['crate'];stage['reused']=True
c=gpu['command'].copy();c[1:1]=['-L','dependency=/private/tmp/mech-related-pr990-backend-target-20261111/release/deps']
for i,arg in enumerate(c[:-1]):
 if arg=='--extern':
  name=c[i+1].split('=',1)[0]
  if name in backend_libs:c[i+1]=name+'='+backend_libs[name]
 if arg.startswith('metadata='):c[i]='metadata=related_r312_backend_'+source_hash[:16]
c[-1]=str(O/'libmech_gpu.rlib');gpu.update(command=c,source_sha256=source_hash,reused=False);start=time.monotonic();x=subprocess.run(c,cwd=S,env={**os.environ,**gpu['environment']},capture_output=True,text=True);gpu.update(exit=x.returncode,seconds=time.monotonic()-start,stdout=x.stdout,stderr=x.stderr)
if x.returncode==0:gpu['library_sha256']=sha(c[-1])
(O/'build.json').write_text(json.dumps(b,indent=2)+'\n');print('IR312 backend compiler',x.returncode,flush=True);print(x.stderr[-8000:]);assert x.returncode==0;assert files==h.source_inventory(S)
