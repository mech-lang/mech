from pathlib import Path
import json,shutil,hashlib,subprocess
P=Path(__file__).parent;chain=list(reversed(json.loads((P/'deflate-selected-source-chain.json').read_text())));out=P/'deflate-r293-source-v3';assert not out.exists();shutil.copytree(Path(chain[0]['root'])/'candidate-source',out)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for row in chain[1:]:
 pin=row['source_pins']
 if row['round']==276:
  pin=json.loads((Path(row['root'])/'peeled-source-pins.json').read_text())
  formatting=P/'deflate-r275/packet/evidence/format-only.patch';assert sha(formatting)==pin['compiler_parent_format_patch_sha256']
  subprocess.run(['git','apply',str(formatting)],cwd=out,check=True)
 changes={name:dict(before=v.get('before',v.get('baseline')),after=v.get('after',v.get('candidate'))) for name,v in pin.get('changed_sources',{}).items()};e=Path(row['root'])
 if not changes:continue
 for name,v in changes.items():
  before=v.get('before');f=out/name
  assert (sha(f)if f.exists()else None)==before,(row['round'],name,'before hash')
 # Prefer exact whole-file snapshots when present, otherwise apply the pinned patch.
 copies={}
 for f in e.rglob('*'):
  if f.is_file()and f.suffix in ['.rs','.toml','.mec']:
   digest=sha(f)
   for name,v in changes.items():
    if v['after']==digest:copies[name]=f
 if len(copies)==len(changes):
  for name,f in copies.items():
   target=out/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,target)
 else:
  patches=[f for f in e.rglob('*.patch')if sha(f)==pin['compiler_patch_sha256']];assert len(patches)==1,(row['round'],patches)
  x=subprocess.run(['git','apply','--check',str(patches[0])],cwd=out,capture_output=True,text=True);assert x.returncode==0,(row['round'],x.stderr)
  subprocess.run(['git','apply',str(patches[0])],cwd=out,check=True)
 for name,v in changes.items():assert sha(out/name)==v['after'],(row['round'],name,'after hash')
 print('reconstructed verified',row['round'],len(changes),'files',flush=True)
final=chain[-1]['source_pins']['candidate_source_sha256'];bad=[name for name,want in final.items()if not(out/name).exists()or sha(out/name)!=want];assert not bad,bad
(P/'deflate-r293-source-reconstruction.json').write_text(json.dumps(dict(all_files_verified=len(final),rounds=[r['round']for r in chain],root=str(out),source_sha256=final),indent=2)+'\n');print('EXACT R293 compiler closure',len(final),'files',flush=True)
