"""Finish the variants whose changed matcher graph required fresh counters."""
from pathlib import Path
from hashlib import sha256
from runpy import run_path
import json, os, subprocess

n = Path(__file__).resolve().parent
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: sha256(Path(p).read_bytes()).hexdigest()
tool = run_path(str(n.parent.parent / 'current-roadmap/scorer-runtime/emit.py'),
                run_name='read_pinned_profiled_symbols')
for variant in ['pinned', 'wide-pinned']:
    raw = 'tune-read-' + variant + '-raw'
    out = n / ('tune-read-' + variant + '-profiled')
    prior = read(n / raw / 'receipt.json')
    assert not (out / 'receipt.json').exists()
    misses = read(out / 'needs-fresh-profiles.json')
    assert [x['symbol'] for x in misses] == ['mech_compact_numeric_475_vector']
    rebased = read(out / 'profile-rebase.json')
    profiles = [x['symbol'] + '@' + x['new_profile'] for x in rebased]
    fresh = n / (raw + '-matcher-profile.json')
    profiles.append('mech_compact_numeric_475_vector@' + str(fresh))
    flags = prior['flags'] | {'MECH_COMPACT_PHASE_BLOCK_LAYOUT': ';'.join(profiles)}
    cmd = [prior['compile'][0], prior['compile'][1], str(out / 'frontend'), 'compact']
    with (out / 'compile.log').open('w') as log:
        subprocess.run(cmd, env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')} | flags,
                       stdout=log, stderr=log, check=True)
    artifacts = {name: sha(out / 'frontend' / name) for name in prior['artifacts']}
    assert artifacts['program.mecb'] == prior['artifacts']['program.mecb']
    layout = tool['symbols'](out / 'frontend/program.o')
    receipt = prior | {'compile': cmd, 'command': cmd, 'flags': flags,
                       'artifacts': artifacts, 'object_sha256': artifacts['program.o'],
                       'metadata_sha256': artifacts['metadata.json'],
                       'bytecode_sha256': artifacts['program.mecb'],
                       'text_bytes': layout['text_bytes'], 'layout': layout,
                       'profile_rebase_sha256': sha(out / 'profile-rebase.json'),
                       'fresh_matcher_profile_sha256': sha(fresh),
                       'profile_source': raw, 'runtime_qualification': 'pending'}
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(out.name, layout['text_bytes'], flush=True)
