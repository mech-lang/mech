"""Keep a retained layout heuristic only for an identical ordered code graph."""
from pathlib import Path
from hashlib import sha256
from runpy import run_path
import json, os, subprocess

ROOT = Path(__file__).resolve().parent
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: sha256(Path(p).read_bytes()).hexdigest()
source = ROOT.parent / 'natural4k-runtime-target/rebase-spill-pair-profiles.py'
shapes = {'__file__': str(source)}
exec(compile(source.read_text().split('base=read(LAB/')[0], str(source), 'exec'), shapes)
shapes['OUT'] = ROOT
shape = shapes['shape']
tool = run_path(str(ROOT.parent.parent / 'current-roadmap/scorer-runtime/emit.py'), run_name='read_tuning_profiled_symbols')
base = read(ROOT / 'read-window-probe-profiled/receipt.json')
for variant in ['wide', 'pinned', 'wide-pinned', 'hash32']:
    raw = 'tune-read-' + variant + '-raw'
    prior = read(ROOT / raw / 'receipt.json')
    out = ROOT / ('tune-read-' + variant + '-profiled')
    out.mkdir()
    profiles, proof, misses = [], [], []
    for item in base['flags']['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].split(';'):
        symbol, path = item.split('@', 1)
        control, candidate = shape('tune-read-control-raw', symbol), shape(raw, symbol)
        old = read(path)
        assert sorted(old['order']) == control['heads'] and old.get('literal_offset') == control['pool']
        if control['code_blocks'] != candidate['code_blocks']:
            misses.append({'symbol': symbol, 'reason': 'Different ordered block graph; fresh profiling required.', 'control': control, 'candidate': candidate})
            continue
        assert 'object_tail' not in old
        table = dict(zip(control['code_heads'], candidate['code_heads'], strict=True))
        order = [table[h] for h in old['order'] if h in table] + candidate['zero_literal_padding']
        assert sorted(order) == candidate['heads']
        new = old | {'order': order, 'literal_offset': candidate['pool']}
        target = out / (symbol + '-profile.json')
        target.write_text(json.dumps(new, indent=2) + '\n')
        profiles.append(symbol + '@' + str(target))
        proof.append({'symbol': symbol, 'control': control, 'candidate': candidate,
                      'old_profile': path, 'old_profile_sha256': sha(path),
                      'new_profile': str(target), 'new_profile_sha256': sha(target),
                      'scope': 'Exact ordered graph and checked pool/padding coordinate mapping. Reuses a heuristic, not a latency prediction.'})
    (out / 'profile-rebase.json').write_text(json.dumps(proof, indent=2) + '\n')
    if misses:
        (out / 'needs-fresh-profiles.json').write_text(json.dumps(misses, indent=2) + '\n')
        print(out.name, 'needs fresh profiles', [x['symbol'] for x in misses], flush=True)
        continue
    flags = prior['flags'] | {'MECH_COMPACT_PHASE_BLOCK_LAYOUT': ';'.join(profiles)}
    command = [prior['compile'][0], prior['compile'][1], str(out / 'frontend'), 'compact']
    with (out / 'compile.log').open('w') as log:
        subprocess.run(command, env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')} | flags,
                       stdout=log, stderr=log, check=True)
    artifacts = {name: sha(out / 'frontend' / name) for name in prior['artifacts']}
    assert artifacts['program.mecb'] == prior['artifacts']['program.mecb']
    layout = tool['symbols'](out / 'frontend/program.o')
    receipt = prior | {'compile': command, 'command': command, 'flags': flags, 'artifacts': artifacts,
                       'object_sha256': artifacts['program.o'], 'metadata_sha256': artifacts['metadata.json'],
                       'bytecode_sha256': artifacts['program.mecb'], 'text_bytes': layout['text_bytes'], 'layout': layout,
                       'profile_rebase_sha256': sha(out / 'profile-rebase.json'), 'runtime_qualification': 'pending'}
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(out.name, layout['text_bytes'], flush=True)
