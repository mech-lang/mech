"""Revisit retained code-generation choices on the new admitted-window base."""
from pathlib import Path
from hashlib import sha256
from runpy import run_path
import json, os, subprocess

ROOT = Path(__file__).resolve().parent
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: sha256(Path(p).read_bytes()).hexdigest()
base = read(ROOT / 'read-window-probe-profiled/receipt.json')
tool = run_path(str(ROOT.parent.parent / 'current-roadmap/scorer-runtime/emit.py'), run_name='read_tuning_symbols')
variants = [
    ('tune-read-control-raw', {}, []),
    ('tune-read-wide-raw', {}, ['MECH_FORWARD_PREVIOUS_NARROW']),
    ('tune-read-pinned-raw', {}, ['MECH_COMPACT_REMATERIALIZE_IMMUTABLE_READS']),
    ('tune-read-wide-pinned-raw', {}, ['MECH_FORWARD_PREVIOUS_NARROW', 'MECH_COMPACT_REMATERIALIZE_IMMUTABLE_READS']),
    ('tune-read-hash32-raw', {'MECH_NARROW_PRIVATE_ARITHMETIC': 'shifts'}, []),
]
for role, added, removed in variants:
    out = ROOT / role
    out.mkdir()
    flags = base['flags'] | added
    for name in [*removed, 'MECH_COMPACT_PHASE_BLOCK_LAYOUT']:
        flags.pop(name, None)
    command = [base['compile'][0], base['compile'][1], str(out / 'frontend'), 'compact']
    with (out / 'compile.log').open('w') as log:
        run = subprocess.run(command, env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')} | flags,
                             stdout=log, stderr=log)
    if run.returncode:
        (out / 'failed-emission.json').write_text(json.dumps({'command': command, 'flags': flags, 'exit_code': run.returncode}, indent=2) + '\n')
        print(role, 'failed', flush=True)
        continue
    artifacts = {name: sha(out / 'frontend' / name) for name in base['artifacts']}
    assert artifacts['program.mecb'] == base['artifacts']['program.mecb']
    layout = tool['symbols'](out / 'frontend/program.o')
    receipt = base | {'compile': command, 'command': command, 'flags': flags, 'artifacts': artifacts,
                      'object_sha256': artifacts['program.o'], 'metadata_sha256': artifacts['metadata.json'],
                      'bytecode_sha256': artifacts['program.mecb'], 'text_bytes': layout['text_bytes'], 'layout': layout,
                      'tuning': {'added_flags': added, 'removed_flags': removed}, 'runtime_qualification': 'pending'}
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(role, layout['text_bytes'], flush=True)
