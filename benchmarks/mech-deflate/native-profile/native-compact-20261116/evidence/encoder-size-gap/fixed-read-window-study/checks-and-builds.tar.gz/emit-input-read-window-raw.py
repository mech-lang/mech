from pathlib import Path
from hashlib import sha256
from runpy import run_path
import json,os,subprocess
n=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();build=read(n/'admitted-input-read-window-compiler/build.json');tool=run_path(str(n.parent.parent/'current-roadmap/scorer-runtime/emit.py'),run_name='input_word_length_symbols')
roles=[('read-window-word','window-clean-word-profiled'),('read-window-probe','window-clean-probe-profiled'),('read-window-packet','window-clean-packet-profiled')]
for role,base in roles:
 old=read(n/base/'receipt.json');out=n/role;out.mkdir();flags=old['flags']|{'MECH_REUSE_ADMITTED_INPUT_WINDOWS':'1'};flags['MECH_COMPACT_PHASE_BLOCK_LAYOUT']=';'.join(x for x in flags['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].split(';') if not x.startswith('mech_compact_numeric_475_vector@'));cmd=[build['compiler'],old['compile'][1],str(out/'frontend'),'compact']
 with (out/'compile.log').open('w') as log:r=subprocess.run(cmd,env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}|flags,stdout=log,stderr=log)
 if r.returncode:
  (out/'failed-emission.json').write_text(json.dumps({'command':cmd,'flags':flags,'exit_code':r.returncode},indent=2)+'\n');print(role,'failed',(out/'compile.log').read_text()[-2500:],flush=True);continue
 artifacts={name:sha(out/'frontend'/name) for name in old['artifacts']};assert artifacts['program.mecb']==old['artifacts']['program.mecb'];layout=tool['symbols'](out/'frontend/program.o');spans=[]
 def walk(x):
  if isinstance(x,dict):
   if x.get('admitted_input_spans'):spans.append({'header':x.get('header'),'symbol':x.get('symbol'),'spans':x['admitted_input_spans']})
   for v in x.values():walk(v)
  elif isinstance(x,list):
   for v in x:walk(v)
 walk(read(out/'frontend/metadata.json'));assert spans and all(s.get('minimum_length')==8 for group in spans for s in group['spans'])
 receipt=old|{'compile':cmd,'command':cmd,'compiler_sha256':build['compiler_sha256'],'source_base':build['source_base'],'source_inputs':build['source_sha256'],'flags':flags,'artifacts':artifacts,'object_sha256':artifacts['program.o'],'metadata_sha256':artifacts['metadata.json'],'bytecode_sha256':artifacts['program.mecb'],'text_bytes':layout['text_bytes'],'layout':layout,'admitted_input_spans':spans,'runtime_qualification':'pending'};(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(role,layout['text_bytes'],spans,flush=True)
