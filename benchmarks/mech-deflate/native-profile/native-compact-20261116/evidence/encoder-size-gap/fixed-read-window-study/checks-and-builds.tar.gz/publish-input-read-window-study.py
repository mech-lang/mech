"""Publish read-proof discovery and every tuning order, including losses."""
from pathlib import Path
from hashlib import sha256
import gzip, io, json, shutil, subprocess, tarfile

N = Path(__file__).resolve().parent
Q = N.parent.parent
W = Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP')
P = W / 'benchmarks/mech-deflate/native-profile/native-compact-20261116'
E = P / 'evidence/encoder-size-gap/fixed-read-window-study'
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: sha256(Path(p).read_bytes()).hexdigest()
write = lambda p, v: p.write_text(json.dumps(v, indent=2) + '\n')
source = '2dcf8babd9e34e1f2d752edd875e1572f185aef5'
roles = ['read-window-word-profiled', 'read-window-probe-profiled', 'read-window-packet-profiled',
         'tune-read-wide-profiled', 'tune-read-pinned-profiled',
         'tune-read-wide-pinned-profiled', 'tune-read-hash32-profiled']
stages = {
    'read_proof': read(N / 'input-read-window-discovery-read-window-word-profiled-results.json'),
    'carry_load_hash_tuning': read(N / 'read-window-tuning-discovery-tune-read-wide-profiled-results.json'),
}
assert all(stage['complete'] for stage in stages.values())
assert [len(stage['runs']) for stage in stages.values()] == [6, 8]
E.mkdir()
selected = {}

def add(path):
    path = Path(path)
    if path.is_file():
        selected[str(path.relative_to(N))] = path

def folder(path):
    for file in Path(path).rglob('*'):
        if not file.is_file() or '/compiler/' in str(file.relative_to(N)):
            continue
        if file.suffix in ['.json', '.jsonl', '.log', '.stderr', '.txt', '.py', '.rs', '.c', '.o', '.mecb', '.gz', '.clif'] or file.name in ['mech-worker', 'layout-stack-worker', 'checked-exit-failure-worker']:
            add(file)

for role in roles:
    folder(N / role)
    folder(Path(read(N / role / 'linked-proof.json')['result']).parent.parent)
for name in ['admitted-input-read-window-compiler', 'admitted-input-read-window-repository-tests',
             'input-read-window-supporting-tests', 'input-read-window-disabled-replays',
             'read-window-probe-optimized-inspection', 'input-read-window-matched-builds',
             'read-window-tuning-matched-builds']:
    folder(N / name)
counter_roles = ['read-window-word', 'read-window-probe', 'read-window-packet',
                 'tune-read-pinned-raw', 'tune-read-wide-pinned-raw']
for role in counter_roles + ['tune-read-control-raw', 'tune-read-wide-raw', 'tune-read-hash32-raw']:
    folder(N / role)
add(N / 'word-complements-prior-wins.json')
for path in N.glob('*.py'):
    if any(term in path.name for term in ['input-read-window', 'read-window', 'window-profiled', 'input-windows', 'count-matcher', 'recover-vector']):
        add(path)
for path in N.glob('*.log'):
    if any(term in path.name for term in ['read-window', 'input-read-window', 'tune-read']):
        add(path)
archives = {}

def archive(path, files):
    pins, prior = {}, {}
    with tarfile.open(path, 'w:gz', compresslevel=6) as tar:
        for name, file in sorted(files.items()):
            data = file.read_bytes()
            digest = sha256(data).hexdigest()
            pin = (digest, len(data))
            info = tarfile.TarInfo(name)
            info.mtime, info.mode = 0, 0o644
            if pin in prior:
                info.type, info.linkname = tarfile.LNKTYPE, prior[pin]
                tar.addfile(info)
            else:
                info.size = len(data)
                tar.addfile(info, io.BytesIO(data))
                prior[pin] = name
            pins[name] = {'bytes': len(data), 'sha256': digest}
    archives[path.name] = pins

archive(E / 'checks-and-builds.tar.gz', selected)
raw = {}
for stage in stages.values():
    for run in stage['runs']:
        root = Q / Path(run['run']).name
        for file in root.rglob('*'):
            if file.is_file():
                raw[str(file.relative_to(Q))] = file
archive(E / 'raw-runtime.tar.gz', raw)
write(E / 'archive-files.json', archives)
(E / 'phase-profiles').mkdir()
published = {}
for role in roles:
    receipt = read(N / role / 'receipt.json')
    bound = read(N / role / 'bound/runtime.json')
    profiles = []
    for item in receipt['flags']['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].split(';'):
        symbol, path = item.split('@', 1)
        pin = sha(path)
        target = E / 'phase-profiles' / (pin[:24] + '.json')
        if not target.exists():
            shutil.copyfile(path, target)
        profiles.append({'symbol': symbol, 'path': str(target.relative_to(E)), 'sha256': pin})
    published[role] = {
        'artifact_sha256': receipt['artifacts'], 'text_bytes': receipt['text_bytes'],
        'worker_sha256': bound['worker_sha256'], 'compiler_sha256': receipt['compiler_sha256'],
        'flags_as_run': receipt['flags'], 'profiles': profiles,
        'source_inputs': receipt['source_inputs'], 'source_basis': source,
    }
    for leaf in ['program.o', 'metadata.json']:
        (E / (role + '-' + leaf + '.gz')).write_bytes(gzip.compress((N / role / 'frontend' / leaf).read_bytes(), mtime=0))
required = read(N / 'word-complements-prior-wins.json')['required_previous_individual_wins']
audit = []
for stage, data in stages.items():
    for run in data['runs']:
        misses = {peer: [row['case'] for row in run['results']
                         if row['case'] in required[peer] and row[key]['mech-experiment'] >= 1]
                  for peer, key in [('roc', 'paired_x_roc'), ('libdeflate', 'paired_x_libdeflate')]}
        audit.append({'stage': stage, 'role': run['role'], 'order': run['order'],
                      'previous_wins_missing': misses})
result = {
    'promoted': False, 'qualified_selection_unchanged': True,
    'qualified': {'encoder_text_bytes': 63612, 'roc_wins': 81, 'libdeflate_wins': 62,
                  'worker_sha256': 'a2f692f524448d7b1c972abf5f1cc92ac412c1fcd1424ce4ade4b9bae526481c'},
    'source_basis_commit': source,
    'source_sha256': sha(P / 'program.mec'),
    'bytecode_sha256': published[roles[0]]['artifact_sha256']['program.mecb'],
    'roles': published, 'stages': stages, 'panel_audit': audit,
    'builds': read(N / 'input-read-window-matched-builds/summary.json'),
    'tuning_builds': read(N / 'read-window-tuning-matched-builds/summary.json'),
    'native_tests': {'span_calls': 60992, 'histogram_calls': 11760, 'relevant_tests': 25},
    'counter_roles': counter_roles,
    'inspection': read(N / 'read-window-probe-optimized-inspection/result.json'),
    'limitations': [
        'All 21-case, 24-block panels are discovery; full 81-case confidence qualification is outstanding.',
        'Every original observation remains; small slowdowns are allowed when the prior peer win survives.',
        'No qualified 63rd C win is established. The qualified histogram selection is unchanged.',
        'Diagnostic-entry checks do not establish ordinary managed-entry admission and recovery.',
        'Repository-wide unsafe audit remains blocked by the pre-existing missing archived pinned_allocator.rs.',
    ],
}
write(E / 'result.json', result)
shutil.copyfile(P / 'evidence/encoder-size-gap/admitted-input-span-study/host.json', E / 'host.json')
print('Preserved', len(selected), 'check/build files,', len(raw), 'runtime files,', len(roles), 'variants and all fourteen orders.', flush=True)
