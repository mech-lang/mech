from pathlib import Path
from hashlib import sha256
import gzip,io,json,shutil,subprocess,tarfile
n=Path(__file__).resolve().parent;q=n.parent.parent
w=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP');p=w/'benchmarks/mech-deflate/native-profile/native-compact-20261116';e=p/'evidence/encoder-size-gap/admitted-input-span-study';e.mkdir()
read=lambda path:json.loads(path.read_text());sha=lambda path:sha256(path.read_bytes()).hexdigest();write=lambda path,data:path.write_text(json.dumps(data,indent=2)+'\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();assert head=='b55805f7f36a6163b4b0f7200d0519461b6448e2'
late=['span-late-word-profiled','span-late-vector-profiled','span-late-vector-complements-profiled','probe-bitwise-vector-complements-profiled','probe-span-vector-complements-profiled'];early=['span-fast-word-profiled','span-fast-vector-profiled','span-fast-vector-complements-profiled'];bit=['bitwise-word-profiled','bitwise-vector-profiled','bitwise-vector-complements-profiled'];roles=bit+early+late
stages={'bitwise':{'discovery':read(n/'bitwise-screen-bitwise-word-profiled-results.json'),'full_point_screens':{role:read(n/('small-table-full24-'+role)/'result.json') for role in [bit[0],bit[2]]}},'early_span':{'source_commit':'6ac617bae4e9433f5e99319d907d1df717cae8d5','discovery':read(n/'span-discovery-span-fast-word-profiled-results.json'),'builds':read(n/'span-matched-builds/summary.json')},'composed_span':{'source_commit':head,'discovery':read(n/'span-composed-discovery-span-late-word-profiled-results.json'),'builds':read(n/'span-composed-matched-builds/summary.json')}}
selected={}
def add(path):
 path=Path(path)
 if path.is_file():selected[str(path.relative_to(n))]=path

def folder(path):
 for file in path.rglob('*'):
  if not file.is_file() or '/compiler/' in str(file.relative_to(n)):continue
  if file.suffix in ['.json','.jsonl','.log','.stderr','.txt','.py','.rs','.c','.o','.mecb','.gz'] or file.name in ['mech-worker','layout-stack-worker','checked-exit-failure-worker']:add(file)

for role in roles:
 r=read(n/role/'receipt.json');bound=read(n/role/'bound/runtime.json');folder(n/role)
 for link in [n/role/'linked-proof.json']:
  if link.exists():add(Path(read(link)['result']))
for role in ['bitwise-word','bitwise-vector','bitwise-vector-complements','span-fast-word','span-fast-vector','span-fast-vector-complements','span-late-word','span-late-vector','span-late-vector-complements','probe-bitwise-vector-complements','probe-span-vector-complements']:folder(n/role)
for name in ['bitwise-index-range-compiler','bitwise-index-range-repository-tests','admitted-input-span-final-compiler','admitted-input-span-final-repository-tests','admitted-input-span-source-windows-compiler','admitted-input-span-composed-compiler','admitted-input-span-composed-repository-tests','admitted-input-span-late-compiler','admitted-input-span-late-repository-tests','span-composed-wide-equal-tests','span-composed-retained-replay','span-source-window-rebase','span-static-contracts','span-matched-builds','span-composed-matched-builds']:folder(n/name)
for name in ['span-source-word','span-source-vector','span-source-vector-complements']:folder(n/name)
for name in ['word-complements-prior-wins.json','span-late-receipt-summary-correction.json','span-composed-discovery-panel-audit.json']:add(n/name)
for stage in stages.values():
 for run in stage['discovery']['runs']:
  add(n/Path(run.get('run',run.get('folder'))).name/'unused')
 for role,screen in stage.get('full_point_screens',{}).items():folder(n/('small-table-full24-'+role))
for name in ['bitwise-screen-bitwise-word-profiled-results.json','span-discovery-span-fast-word-profiled-results.json','span-composed-discovery-span-late-word-profiled-results.json']:add(n/name)
for file in n.glob('*.py'):
 if any(s in file.name for s in ['input-span','admitted-span','composed-span','late-span','probe-span','probe-combinations']):add(file)
add(n/'count-matcher-modes.py');add(n/'recover-vector-word-candidate.py');add(n/'qualify-small-table-entry-guard.py')
archives={}
def archive(path,files):
 pins={}
 with tarfile.open(path,'w:gz',compresslevel=6) as tar:
  for name,file in sorted(files.items()):
   data=file.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data));pins[name]={'bytes':len(data),'sha256':sha256(data).hexdigest()}
 archives[path.name]=pins
archive(e/'checks-and-builds.tar.gz',selected)
raw={}
for stage in stages.values():
 runs=list(stage['discovery']['runs'])
 for screen in stage.get('full_point_screens',{}).values():runs+=screen['runs']
 for run in runs:
  root=q/Path(run.get('run',run.get('folder'))).name
  for file in root.rglob('*'):
   if file.is_file():raw[str(file.relative_to(q))]=file
archive(e/'raw-runtime.tar.gz',raw);write(e/'archive-files.json',archives)
(e/'phase-profiles').mkdir();published={}
for role in roles:
 r=read(n/role/'receipt.json');bound=read(n/role/'bound/runtime.json');profiles=[]
 for spec in r['flags']['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].split(';'):
  if not spec:continue
  symbol,path=spec.split('@',1);path=Path(path);pin=sha(path);target=e/'phase-profiles'/(pin[:24]+'.json')
  if not target.exists():shutil.copyfile(path,target)
  profiles.append({'symbol':symbol,'path':str(target.relative_to(e)),'sha256':pin})
 record={'artifact_sha256':r['artifacts'],'text_bytes':r['text_bytes'],'worker_sha256':bound['worker_sha256'],'compiler_sha256':r['compiler_sha256'],'flags_as_run':r['flags'],'profiles':profiles,'source_inputs':r.get('source_inputs'),'source_basis':head if role in late else stages['early_span']['source_commit'] if role in early else 'ddebb908bfef55b353bee24df00bb01cd3da534b'}
 published[role]=record
 for leaf in ['program.o','metadata.json']:(e/(role+'-'+leaf+'.gz')).write_bytes(gzip.compress((n/role/'frontend'/leaf).read_bytes(),mtime=0))
result={'promoted':False,'qualified_selection_unchanged':True,'qualified':{'encoder_text_bytes':63612,'roc_wins':81,'libdeflate_wins':62,'worker_sha256':'a2f692f524448d7b1c972abf5f1cc92ac412c1fcd1424ce4ade4b9bae526481c'},'source_basis_commit':head,'source_sha256':sha(p/'program.mec'),'bytecode_sha256':published[late[0]]['artifact_sha256']['program.mecb'],'roles':published,'stages':stages,'native_tests':{'span_calls':12096,'histogram_calls':11760,'relevant_tests':15},'limitations':['Nineteen-case span/probe panels are not full81-case scores or confidence qualification.','Bitwise full point screens use24 blocks and are not confidence promotion.','Diagnostic-entry qualification does not establish ordinary managed-entry admission/recovery.','Unsafe audit is blocked by pre-existing missing benchmarks/mech-deflate/comparison/rust/src/pinned_allocator.rs.'],'ir_counter_note':'Composed span metadata counts three folded SSA comparisons, including a predecessor comparison retained for dead-value retirement. Two active input-byte checks are removed.'};write(e/'result.json',result)
print('Published',len(selected),'check/build files;',len(raw),'runtime files;',len(published),'bound variants;',sum(f.stat().st_size for f in e.glob('*.gz')),'compressed bytes')
