"""Reuse layout orders only after proving the ordered block graph is unchanged."""
from pathlib import Path
from hashlib import sha256
from runpy import run_path
import json, os, subprocess, sys

ROOT = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_text())
sha = lambda p: sha256(Path(p).read_bytes()).hexdigest()
source = ROOT.parent / 'natural4k-runtime-target/rebase-spill-pair-profiles.py'
shapes = {'__file__': str(source)}
exec(compile(source.read_text().split('base=read(LAB/')[0], str(source), 'exec'), shapes)
shapes['OUT'] = ROOT
shape = shapes['shape']
tool = run_path(str(ROOT.parent.parent / 'current-roadmap/scorer-runtime/emit.py'), run_name='packet_profiled_symbols')
base = read(ROOT / 'input-word-probe-profiled/receipt.json')
roles = sys.argv[1:] or ['qualify', 'multiple', 'both', 'pinned-loads', 'both-pinned']

for role in roles:
    raw = 'packet-raw-' + role
    old = read(ROOT / raw / 'receipt.json')
    out = ROOT / ('packet-' + role + '-profiled')
    out.mkdir()
    profiles, proofs = [], []
    for item in base['flags']['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].split(';'):
        symbol, profile_path = item.split('@', 1)
        profile = read(Path(profile_path))
        control = shape('packet-raw-control', symbol)
        candidate = shape(raw, symbol)
        assert control['code_blocks'] == candidate['code_blocks'], symbol
        assert sorted(profile['order']) == control['heads'], symbol
        assert profile.get('literal_offset') == control['pool'], symbol
        assert 'object_tail' not in profile, symbol
        table = dict(zip(control['code_heads'], candidate['code_heads'], strict=True))
        rebased = profile | {
            'order': [table[k] for k in profile['order'] if k in table] + candidate['zero_literal_padding'],
            'literal_offset': candidate['pool'],
        }
        assert sorted(rebased['order']) == candidate['heads'], symbol
        path = out / (symbol + '-profile.json')
        path.write_text(json.dumps(rebased, indent=2) + '\n')
        profiles.append(symbol + '@' + str(path))
        proofs.append({
            'symbol': symbol,
            'control': control,
            'candidate': candidate,
            'old_profile': profile_path,
            'old_profile_sha256': sha(profile_path),
            'new_profile': str(path),
            'new_profile_sha256': sha(path),
            'proof': 'The ordered non-padding blocks and all control-transfer destinations match exactly. Each actual trailing zero word remains in the new order after proving no incoming edge or preceding fallthrough. This reuses a layout heuristic, not a latency claim.',
        })
    (out / 'profile-rebase.json').write_text(json.dumps(proofs, indent=2) + '\n')
    flags = old['flags'] | {'MECH_COMPACT_PHASE_BLOCK_LAYOUT': ';'.join(profiles)}
    command = [old['compile'][0], old['compile'][1], str(out / 'frontend'), 'compact']
    with (out / 'compile.log').open('w') as log:
        subprocess.run(command, env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')} | flags,
                       stdout=log, stderr=log, check=True)
    artifacts = {name: sha(out / 'frontend' / name) for name in ['program.o', 'metadata.json', 'program.mecb']}
    assert artifacts['program.mecb'] == old['artifacts']['program.mecb']
    layout = tool['symbols'](out / 'frontend/program.o')
    receipt = old | {
        'compile': command, 'command': command, 'flags': flags, 'artifacts': artifacts,
        'object_sha256': artifacts['program.o'], 'metadata_sha256': artifacts['metadata.json'],
        'bytecode_sha256': artifacts['program.mecb'], 'text_bytes': layout['text_bytes'], 'layout': layout,
        'profile_rebase_sha256': sha(out / 'profile-rebase.json'), 'runtime_qualification': 'pending',
    }
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(out.name, layout['text_bytes'], flush=True)
