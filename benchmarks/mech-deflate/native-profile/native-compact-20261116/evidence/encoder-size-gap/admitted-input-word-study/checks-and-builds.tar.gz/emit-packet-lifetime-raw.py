from pathlib import Path
from hashlib import sha256
from runpy import run_path
import json,os,subprocess
n=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();base=read(n/'input-word-probe-profiled/receipt.json');tool=run_path(str(n.parent.parent/'current-roadmap/scorer-runtime/emit.py'),run_name='packet_lifetime_symbols')
variants=[('packet-raw-qualify',{'MECH_QUALIFY_PHASE_INPUT_PACKET':'1'},[]),('packet-raw-multiple',{'MECH_DEFER_EXIT_PACKET_WORDS':'multiple'},[]),('packet-raw-both',{'MECH_QUALIFY_PHASE_INPUT_PACKET':'1','MECH_DEFER_EXIT_PACKET_WORDS':'multiple'},[]),('packet-raw-pinned-loads',{},['MECH_COMPACT_REMATERIALIZE_IMMUTABLE_READS']),('packet-raw-both-pinned',{'MECH_QUALIFY_PHASE_INPUT_PACKET':'1','MECH_DEFER_EXIT_PACKET_WORDS':'multiple'},['MECH_COMPACT_REMATERIALIZE_IMMUTABLE_READS'])]
for role,added,removed in variants:
 out=n/role;out.mkdir();flags=base['flags']|added
 for name in removed:flags.pop(name,None)
 flags.pop('MECH_COMPACT_PHASE_BLOCK_LAYOUT',None);cmd=[base['compile'][0],base['compile'][1],str(out/'frontend'),'compact']
 with (out/'compile.log').open('w') as log:r=subprocess.run(cmd,env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}|flags,stdout=log,stderr=log)
 if r.returncode:
  (out/'failed-emission.json').write_text(json.dumps({'command':cmd,'flags':flags,'exit_code':r.returncode},indent=2)+'\n');print(role,'failed',(out/'compile.log').read_text()[-2000:],flush=True);continue
 art={name:sha(out/'frontend'/name) for name in base['artifacts']};assert art['program.mecb']==base['artifacts']['program.mecb'];layout=tool['symbols'](out/'frontend/program.o');receipt=base|{'compile':cmd,'command':cmd,'flags':flags,'artifacts':art,'object_sha256':art['program.o'],'metadata_sha256':art['metadata.json'],'bytecode_sha256':art['program.mecb'],'text_bytes':layout['text_bytes'],'layout':layout,'packet_sweep':{'added_flags':added,'removed_flags':removed},'runtime_qualification':'pending'};(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(role,layout['text_bytes'],'matcher',layout['symbols']['_mech_compact_numeric_475_vector']['extent'],flush=True)
