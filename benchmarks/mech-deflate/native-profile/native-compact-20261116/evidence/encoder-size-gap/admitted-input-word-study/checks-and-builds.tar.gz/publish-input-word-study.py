"""Preserve all input-word and packet discovery orders, including adverse data."""
from pathlib import Path
from hashlib import sha256
import gzip, io, json, shutil, subprocess, tarfile

N = Path(__file__).resolve().parent
Q = N.parent.parent
W = Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP')
P = W / 'benchmarks/mech-deflate/native-profile/native-compact-20261116'
E = P / 'evidence/encoder-size-gap/admitted-input-word-study'
E.mkdir()
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: sha256(Path(p).read_bytes()).hexdigest()
write = lambda p, v: p.write_text(json.dumps(v, indent=2) + '\n')
source = 'baeab0027d90305fa3a9b750264acf621acf94ce'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
word = ['input-word-word-profiled', 'input-word-vector-profiled', 'input-word-vector-complements-profiled', 'input-word-probe-profiled']
packet = ['packet-qualify-profiled', 'packet-multiple-profiled', 'packet-both-profiled', 'packet-pinned-loads-profiled', 'packet-both-pinned-profiled']
roles = word + packet
stages = {
    'input_word': read(N / 'input-word-discovery-input-word-word-profiled-results.json'),
    'packet_lifetime': read(N / 'packet-lifetime-screen-v2-packet-qualify-profiled-results.json'),
}
assert all(stage['complete'] for stage in stages.values())
selected = {}

def add(path):
    path = Path(path)
    if path.is_file():
        selected[str(path.relative_to(N))] = path

def folder(path):
    for file in Path(path).rglob('*'):
        if not file.is_file() or '/compiler/' in str(file.relative_to(N)):
            continue
        if file.suffix in ['.json', '.jsonl', '.log', '.stderr', '.txt', '.py', '.rs', '.c', '.o', '.mecb', '.gz', '.clif'] or file.name in ['mech-worker', 'layout-stack-worker', 'checked-exit-failure-worker']:
            add(file)

for role in roles:
    folder(N / role)
    pin = read(N / role / 'linked-proof.json')
    folder(Path(pin['result']).parent.parent)
for name in ['admitted-input-word-compiler', 'admitted-input-word-repository-tests', 'input-word-wide-equal-tests', 'input-word-packet-storage-tests', 'input-word-static-contracts', 'input-word-disabled-replays', 'optimized-phase-inspection-compiler', 'optimized-phase-inspection-replays', 'input-word-packet-matched-builds']:
    folder(N / name)
for name in ['word-complements-prior-wins.json', 'input-word-packet-panel-audit.json', 'packet-lifetime-raw-shapes.json', 'packet-lifetime-checked-replays.json', 'restored-runtime-oracle.json']:
    add(N / name)
for path in N.glob('*.py'):
    if any(term in path.name for term in ['input-word', 'packet-lifetime', 'optimized-phase', 'input-span']):
        add(path)
for name in ['qualify-small-table-entry-guard.py', 'recover-vector-word-candidate.py', 'count-matcher-modes.py']:
    add(N / name)
for path in N.glob('packet-lifetime*.log'):
    add(path)
for path in N.glob('packet-raw-*'):
    folder(path)
for path in N.glob('packet-*/failed-emission.json'):
    add(path)
    add(path.parent / 'compile.log')
folder(N / 'input-word-current-collector-inspection')
archives = {}

def archive(path, files):
    pins, prior = {}, {}
    with tarfile.open(path, 'w:gz', compresslevel=6) as tar:
        for name, file in sorted(files.items()):
            data = file.read_bytes()
            digest = sha256(data).hexdigest()
            pin = (digest, len(data))
            info = tarfile.TarInfo(name)
            info.mtime, info.mode = 0, 0o644
            if pin in prior:
                info.type, info.linkname = tarfile.LNKTYPE, prior[pin]
                tar.addfile(info)
            else:
                info.size = len(data)
                tar.addfile(info, io.BytesIO(data))
                prior[pin] = name
            pins[name] = {'bytes': len(data), 'sha256': digest}
    archives[path.name] = pins

archive(E / 'checks-and-builds.tar.gz', selected)
raw = {}
for stage in stages.values():
    for run in stage['runs']:
        root = Q / Path(run['run']).name
        for file in root.rglob('*'):
            if file.is_file():
                raw[str(file.relative_to(Q))] = file
archive(E / 'raw-runtime.tar.gz', raw)
write(E / 'archive-files.json', archives)
(E / 'phase-profiles').mkdir()
published = {}
for role in roles:
    receipt = read(N / role / 'receipt.json')
    bound = read(N / role / 'bound/runtime.json')
    profiles = []
    for item in receipt['flags']['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].split(';'):
        symbol, path = item.split('@', 1)
        pin = sha(path)
        target = E / 'phase-profiles' / (pin[:24] + '.json')
        if not target.exists():
            shutil.copyfile(path, target)
        profiles.append({'symbol': symbol, 'path': str(target.relative_to(E)), 'sha256': pin})
    published[role] = {
        'artifact_sha256': receipt['artifacts'], 'text_bytes': receipt['text_bytes'],
        'worker_sha256': bound['worker_sha256'], 'compiler_sha256': receipt['compiler_sha256'],
        'flags_as_run': receipt['flags'], 'profiles': profiles,
        'source_inputs': receipt['source_inputs'], 'source_basis': source,
    }
    for leaf in ['program.o', 'metadata.json']:
        (E / (role + '-' + leaf + '.gz')).write_bytes(gzip.compress((N / role / 'frontend' / leaf).read_bytes(), mtime=0))
result = {
    'promoted': False, 'qualified_selection_unchanged': True,
    'qualified': {'encoder_text_bytes': 63612, 'roc_wins': 81, 'libdeflate_wins': 62,
                  'worker_sha256': 'a2f692f524448d7b1c972abf5f1cc92ac412c1fcd1424ce4ade4b9bae526481c'},
    'source_basis_commit': source, 'inspection_source_commit': head,
    'source_sha256': sha(P / 'program.mec'), 'bytecode_sha256': published[word[0]]['artifact_sha256']['program.mecb'],
    'roles': published, 'stages': stages, 'panel_audit': read(N / 'input-word-packet-panel-audit.json'),
    'builds': read(N / 'input-word-packet-matched-builds/summary.json'),
    'native_tests': {'span_calls': 22680, 'histogram_calls': 11760, 'relevant_tests': 21},
    'inspection': read(N / 'optimized-phase-inspection-replays/result.json'),
    'limitations': ['The 21-case, 24-block panels are discovery, not full 81-case confidence qualification.',
                    'Every prior named peer win observed in these panels remains a point win; unobserved cases are not inferred.',
                    'Natural 4 KiB remains slower than C. There is no qualified 63rd C win.',
                    'The smaller packet-qualified candidate slows natural and distribution-change inputs; it is retained for repair.',
                    'Diagnostic-entry checks do not establish ordinary managed-entry admission and recovery.',
                    'Repository-wide unsafe audit remains blocked by the pre-existing missing archived pinned_allocator.rs.'],
}
write(E / 'result.json', result)
shutil.copyfile(P / 'evidence/encoder-size-gap/admitted-input-span-study/host.json', E / 'host.json')
print('Preserved', len(selected), 'check/build files,', len(raw), 'runtime files,', len(roles), 'variants and all 18 orders.', flush=True)
