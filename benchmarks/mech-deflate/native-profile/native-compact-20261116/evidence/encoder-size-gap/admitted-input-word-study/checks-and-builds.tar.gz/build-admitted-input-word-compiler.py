from pathlib import Path
from hashlib import sha256
import subprocess,json,os,time,shutil,datetime
n=Path(__file__).resolve().parent;w=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP');out=n/'admitted-input-word-compiler';out.mkdir()
old=json.loads((n/'first-word-probe-compiler/build.json').read_text());source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();paths=json.loads((n/'admitted-input-word-repository-tests/plan.json').read_text())['source_sha256'];files={p:sha256((w/p).read_bytes()).hexdigest() for p in paths};sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
assert all(sha(w/p)==pin for p,pin in files.items())
command=list(old['command']);command[command.index('--target-dir')+1]=str(n.parent/'compiler-target');env=old['profile']|{'CARGO_INCREMENTAL':'0'}
for name in files:
 target=out/'source-inputs'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(w/name,target)
plan={'command':command,'environment':env,'source_base':source,'source_pin':'Working-tree admitted input-span proof overlay; exact inputs copied before build','source_sha256':files,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Rust compiler rebuild, distinct from source-through-final-link codec timing.'};(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');start=time.monotonic()
with (out/'build.jsonl').open('w') as log,(out/'build.stderr').open('w') as err:
 child=subprocess.Popen(command,cwd=w,env=os.environ|env,stdout=log,stderr=err,start_new_session=True);(out/'process.json').write_text(json.dumps({'pid':child.pid,'pgid':child.pid})+'\n');code=child.wait()
result=plan|{'seconds':time.monotonic()-start,'exit_code':code};assert all(sha(w/p)==pin for p,pin in files.items())
if code==0:
 records=[json.loads(row) for row in (out/'build.jsonl').read_text().splitlines() if row.startswith('{')];exes=[r['executable'] for r in records if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='compile_profile' and r.get('executable')];assert len(exes)==1
 compiler=Path(exes[0]);pin=sha(compiler);target=out/'compiler'/pin[:16]/'compile_profile';target.parent.mkdir(parents=True);shutil.copy2(compiler,target);result.update(compiler=str(target),compiler_sha256=pin)
(out/'build.json').write_text(json.dumps(result,indent=2)+'\n');print('Admitted input-span compiler rebuild',code,result['seconds'],result.get('compiler_sha256'),flush=True);assert code==0,(out/'build.stderr').read_text()[-5000:]
