from pathlib import Path
from hashlib import sha256
from runpy import run_path
import json,subprocess,os,struct
n=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();build=read(n/'admitted-input-span-compiler/build.json');tool=run_path(str(n.parent.parent/'current-roadmap/scorer-runtime/emit.py'),run_name='span_fast_symbols');raw=read(n/'span-source-window-rebase/raw-windows.json')
def text_bytes(path):
 data=path.read_bytes();assert struct.unpack_from('<I',data)[0]==0xfeedfacf;offset=32
 for _ in range(struct.unpack_from('<I',data,16)[0]):
  command,size=struct.unpack_from('<II',data,offset)
  if command==0x19:
   for i in range(struct.unpack_from('<I',data,offset+64)[0]):
    section=offset+72+i*80;name,segment,addr,length,fileoff=struct.unpack_from('<16s16sQQI',data,section)
    if name.rstrip(b'\0')==b'__text' and segment.rstrip(b'\0')==b'__TEXT':return data[fileoff:fileoff+length]
  offset+=size
 raise AssertionError('missing text')
for kind in ['word','vector','vector-complements']:
 old=read(n/('span-source-'+kind)/'receipt.json');out=n/('span-fast-'+kind);out.mkdir();flags=old['flags']|raw
 for key in ['MECH_COMPACT_SOURCE_CONTROLLER_WINDOWS','MECH_COMPACT_SOURCE_CONTINUATION_WINDOWS','MECH_COMPACT_SOURCE_BLOCK_REPORT']:flags.pop(key,None)
 command=[build['compiler'],old['compile'][1],str(out/'frontend'),'compact']
 with (out/'compile.log').open('w') as log:r=subprocess.run(command,env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}|flags,stdout=log,stderr=log)
 assert r.returncode==0,(out/'compile.log').read_text()[-3000:]
 artifacts={name:sha(out/'frontend'/name) for name in old['artifacts']};assert artifacts['program.mecb']==old['artifacts']['program.mecb'];layout=tool['symbols'](out/'frontend/program.o');section=text_bytes(out/'frontend/program.o');assert section==text_bytes(n/('span-source-'+kind)/'frontend/program.o')
 receipt=old|{'compile':command,'command':command,'flags':flags,'compiler_sha256':build['compiler_sha256'],'source_base':build['source_base'],'source_inputs':build['source_sha256'],'artifacts':artifacts,'object_sha256':artifacts['program.o'],'metadata_sha256':artifacts['metadata.json'],'bytecode_sha256':artifacts['program.mecb'],'text_bytes':layout['text_bytes'],'layout':layout,'minimal_compiler_text_identity':{'source_window_role':'span-source-'+kind,'text_sha256':sha256(section).hexdigest()},'runtime_qualification':'pending'};(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(out.name,layout['text_bytes'],receipt['admitted_input_spans'],flush=True)
