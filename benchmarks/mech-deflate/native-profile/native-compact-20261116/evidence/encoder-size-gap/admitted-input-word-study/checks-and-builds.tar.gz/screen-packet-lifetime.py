"""Held-feature packet lifetime discovery, separate from full win qualification."""
from pathlib import Path
from hashlib import sha256
import json, os, sys

ROOT = Path(__file__).resolve().parent
Q = ROOT.parent.parent
read = lambda p: json.loads(p.read_text())
sha = lambda p: sha256(Path(p).read_bytes()).hexdigest()
timer = Q / 'compare-library.py'
control = ROOT / 'input-word-probe-profiled/bound'
cases = read(ROOT / 'input-word-discovery-input-word-word-profiled-plan.json')['cases']
roles = sys.argv[1:] or ['packet-qualify-profiled', 'packet-multiple-profiled',
                          'packet-both-profiled', 'packet-pinned-loads-profiled',
                          'packet-both-pinned-profiled']
plan = {
    'cases': cases, 'roles': roles, 'orders': ['forward', 'reverse'], 'blocks_per_case': 24,
    'scope': 'Twenty-one-case discovery with the input-word/probe worker held fixed as control. Short inputs expose any guard fallback loss. All 24 actor permutations in each case are retained. Full 81-case confidence qualification is separate.',
    'timer_sha256': sha(timer), 'control_folder': str(control),
    'control_worker_sha256': sha(control / 'mech-worker'),
    'worker_sha256_by_role': {}, 'linked_proof_sha256_by_role': {},
    'load_before': os.getloadavg(),
}
for role in roles:
    folder = ROOT / role
    runtime = read(folder / 'bound/runtime.json')
    assert sha(folder / 'bound/mech-worker') == runtime['worker_sha256']
    assert sha(folder / 'bound/program.o') == runtime['object_sha256']
    proof = read(folder / 'linked-proof.json')
    assert sha(Path(proof['result'])) == proof['sha256']
    assert proof['peak_stack_bytes'] <= 5280
    plan['worker_sha256_by_role'][role] = runtime['worker_sha256']
    plan['linked_proof_sha256_by_role'][role] = proof['sha256']
prefix = 'packet-lifetime-screen-v2-' + roles[0]
(ROOT / (prefix + '-plan.json')).write_text(json.dumps(plan, indent=2) + '\n')
program = timer.read_text()
needle = "selected = {case['name'] for case in cases}"
assert program.count(needle) == 1
program = program.replace(needle, 'selected = ' + repr(set(cases)))
runs = []
for role in roles:
    for order in plan['orders']:
        label = 'packet-lifetime-screen-v2-' + role + '-' + order
        sys.argv = [str(timer), label, str(control), str(ROOT / role / 'bound')] + (['reverse'] if order == 'reverse' else [])
        exec(compile(program, str(timer), 'exec'), {'__file__': str(timer), '__name__': '__main__'})
        summary = read(Q / label / 'summary.json')
        assert len(summary) == len(cases)
        runs.append({'role': role, 'order': order, 'run': str(Q / label),
                     'summary_sha256': sha(Q / label / 'summary.json'), 'results': summary})
        (ROOT / (prefix + '-results.json')).write_text(json.dumps({'plan': plan, 'runs': runs, 'complete': len(runs) == len(roles) * 2}, indent=2) + '\n')
        for row in summary:
            if row['case'] in ['prefix-natural-4096', '320-overlap', 'prefix-random-1048576']:
                print(role, order, row['case'], 'C', row['paired_x_libdeflate']['mech-experiment'],
                      'Roc', row['paired_x_roc']['mech-experiment'], 'vs held base',
                      row['paired_x_roc']['mech-experiment'] / row['paired_x_roc']['mech-control'], flush=True)
