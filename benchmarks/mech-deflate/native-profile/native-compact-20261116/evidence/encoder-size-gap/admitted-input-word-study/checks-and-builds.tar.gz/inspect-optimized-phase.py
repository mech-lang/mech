"""Prove that optimized IR inspection preserves every emitted artifact."""
from pathlib import Path
from hashlib import sha256
import json, os, subprocess

ROOT = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_text())
sha = lambda p: sha256(Path(p).read_bytes()).hexdigest()
build = read(ROOT / 'optimized-phase-inspection-compiler/build.json')
compiler = build['compiler']
assert sha(compiler) == build['compiler_sha256']
OUT = ROOT / 'optimized-phase-inspection-replays'
OUT.mkdir()
results = []
for role in ['bounded-histogram-word', 'input-word-word-profiled', 'input-word-probe-profiled', 'packet-qualify-profiled']:
    prior = read(ROOT / role / 'receipt.json')
    for mode, inspect, checked in [('plain', False, False), ('inspected', True, False), ('checked-inspected', True, True)]:
        folder = OUT / role / mode
        folder.mkdir(parents=True)
        flags = prior['flags'].copy()
        ir = folder / 'mech_compact_numeric_475_vector.clif'
        if inspect:
            flags['MECH_INSPECT_OPTIMIZED_PHASE_CLIF'] = str(ir)
        if checked:
            flags['MECH_COMPACT_PAIR_REGISTER_SPILLS'] = 'checked'
        command = [compiler, prior['compile'][1], str(folder / 'frontend'), 'compact']
        with (folder / 'compile.log').open('w') as log:
            subprocess.run(command, env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')} | flags,
                           stdout=log, stderr=log, check=True)
        artifacts = {name: sha(folder / 'frontend' / name) for name in prior['artifacts']}
        assert artifacts == prior['artifacts'], (role, mode)
        if inspect:
            assert ir.is_file() and ir.stat().st_size > 100
        results.append({'role': role, 'mode': mode, 'command': command, 'flags': flags,
                        'artifacts': artifacts, 'exact_previous_artifacts': True,
                        'ir_sha256': sha(ir) if inspect else None})
        (OUT / 'result.json').write_text(json.dumps({'compiler_sha256': build['compiler_sha256'], 'runs': results}, indent=2) + '\n')
        print(role, mode, 'all three artifacts exact', flush=True)
