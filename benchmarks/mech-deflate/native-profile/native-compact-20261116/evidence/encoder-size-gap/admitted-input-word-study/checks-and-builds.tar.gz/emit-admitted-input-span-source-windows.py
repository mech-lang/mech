from pathlib import Path
from hashlib import sha256
from runpy import run_path
import json,subprocess,os
N=Path(__file__).resolve().parent;Q=N.parent.parent;read=lambda p:json.loads(p.read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();build=read(N/'admitted-input-span-source-windows-compiler/build.json');compiler=build['compiler'];assert sha(compiler)==build['compiler_sha256'];tool=run_path(str(Q/'current-roadmap/scorer-runtime/emit.py'),run_name='admitted_index_range_symbols')
for role,base,enabled in [('span-source-word','bitwise-word',True),('span-source-vector','bitwise-vector',True),('span-source-vector-complements','bitwise-vector-complements',True)]:
 old=read(N/base/'receipt.json');out=N/role;out.mkdir();flags=old['flags'].copy();flags.update(read(N/'small-table-feature-source-map/mapped-windows.json'));flags.pop('MECH_COMPACT_LAYOUT_CONTROLLER_WINDOWS',None);flags.pop('MECH_COMPACT_CONTINUATION_WINDOWS',None);reports=out/'maps';reports.mkdir();flags['MECH_COMPACT_SOURCE_BLOCK_REPORT']=str(reports)
 if enabled:
  flags['MECH_REUSE_ADMITTED_INPUT_SPANS']='1'
  flags['MECH_REUSE_ADMITTED_INDEX_RANGES']='1';flags['MECH_REUSE_ADMITTED_BITWISE_INDEX_RANGES']='1';flags['MECH_BOUNDED_BYTE_HISTOGRAM']='1';flags['MECH_COMPACT_PHASE_BLOCK_LAYOUT']=';'.join(x for x in flags['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].split(';') if not x.startswith('mech_compact_numeric_475_vector@'))
 command=[compiler,old['compile'][1],str(out/'frontend'),'compact']
 with (out/'compile.log').open('w') as log:r=subprocess.run(command,env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}|flags,stdout=log,stderr=log)
 if r.returncode:
  (out/'failed-emission.json').write_text(json.dumps({'command':command,'flags':flags,'exit_code':r.returncode,'log_sha256':sha(out/'compile.log')},indent=2)+'\n');print(role,'failed',r.returncode,(out/'compile.log').read_text()[-5000:],flush=True);continue
 artifacts={name:sha(out/'frontend'/name) for name in ['program.o','metadata.json','program.mecb']};assert artifacts['program.mecb']==old['artifacts']['program.mecb'];layout=tool['symbols'](out/'frontend/program.o')
 def walk(x):
  if isinstance(x,dict):
   if 'admitted_input_spans' in x:yield {'header':x.get('header'),'symbol':x.get('symbol'),'spans':x['admitted_input_spans']}
   for v in x.values():yield from walk(v)
  elif isinstance(x,list):
   for v in x:yield from walk(v)
 admitted=list(walk(read(out/'frontend/metadata.json')))
 if not enabled:assert artifacts==old['artifacts']
 receipt={'source_base':build['source_base'],'source_inputs':build['source_sha256'],'compiler_sha256':build['compiler_sha256'],'compile':command,'command':command,'flags':flags,'artifacts':artifacts,'object_sha256':artifacts['program.o'],'metadata_sha256':artifacts['metadata.json'],'bytecode_sha256':artifacts['program.mecb'],'text_bytes':layout['text_bytes'],'layout':layout,'admitted_input_spans':admitted,'runtime_qualification':'pending'};(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(role,layout['text_bytes'],admitted,flush=True)
