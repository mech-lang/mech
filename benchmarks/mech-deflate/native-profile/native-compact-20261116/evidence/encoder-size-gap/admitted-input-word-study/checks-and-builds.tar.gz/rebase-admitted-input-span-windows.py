from pathlib import Path
from hashlib import sha256
import json
n=Path(__file__).resolve().parent;out=n/'span-source-window-rebase';out.mkdir();read=lambda p:json.loads(p.read_text());sha=lambda p:sha256(p.read_bytes()).hexdigest();maps=[]
for role in ['span-source-word','span-source-vector','span-source-vector-complements']:
 path=n/role/'maps/mech_compact_closed_v2.json';d=read(path);flags=read(n/role/'receipt.json')['flags'];raw={}
 def resolve(coordinate):
  if coordinate.startswith('s'):
   block=d['source_blocks'][int(coordinate[1:])];assert block is not None;return block
  index,offset=map(int,coordinate[1:].split('.'));span=d['auxiliary_ranges'][index];assert span is not None and 0<=offset<span[1]-span[0];return span[0]+offset
 for key in ['MECH_COMPACT_SOURCE_CONTROLLER_WINDOWS','MECH_COMPACT_SOURCE_CONTINUATION_WINDOWS']:
  families=[]
  for family in flags[key].split(';'):
   windows=[]
   for window in family.split(','):
    a,b,origin=window.split(':');windows.append(':'.join(map(str,[resolve(a),resolve(b),int(origin)])))
   families.append(','.join(windows))
  name=key.replace('SOURCE_CONTROLLER','LAYOUT_CONTROLLER').replace('SOURCE_CONTINUATION','CONTINUATION');raw[name]=';'.join(families)
 maps.append({'role':role,'source_map_sha256':sha(path),'raw_windows':raw,'source_artifacts':read(n/role/'receipt.json')['artifacts']})
assert all(m['raw_windows']==maps[0]['raw_windows'] for m in maps)
(out/'raw-windows.json').write_text(json.dumps(maps[0]['raw_windows'],indent=2)+'\n');(out/'result.json').write_text(json.dumps({'roles':maps,'scope':'Source-relative checked windows resolved against fresh feature-enabled emitted root maps. Minimal compiler emits the final workers.'},indent=2)+'\n')
print('All three fresh source maps resolve to the same checked numeric boundaries.')
