import os,subprocess
from pathlib import Path
active=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP')
os.environ['GIT_DIR']=subprocess.check_output(['git','rev-parse','--absolute-git-dir'],cwd=active,text=True).strip()
os.environ['GIT_WORK_TREE']=str(active)
"""Acquire full 96-block peer-win qualification for the smaller word/complement encoder."""
from pathlib import Path
from runpy import run_path
import inspect,json,sys
root=Path('/private/tmp/mech-shared-cold-epilogues.2L6obP/.qualification/consolidation-995/natural4k-scorer-repair');lab=root.parent
h=run_path(str(lab.parent/'current-roadmap/shared-heap-call-setup/evaluate.py'),run_name='natural4k_ordered_gate')
rt=h['runtime'];rt.HERE=root;rt.UNCHANGED=root/'bounded-histogram-word/bound';rt.BASE='038724f27'
rt.__dict__.update(HERE=root,UNCHANGED=rt.UNCHANGED,BASE=rt.BASE)
rt.timing.prepare.__globals__['control']=rt.UNCHANGED
source=inspect.getsource(rt.measure)
# The actual full 24-block screen supersedes the old focus-folder layout.
source=source.replace("        screen = read(HERE / role / 'focus/screen.json')\n        assert screen['preserves_peer_wins']\n","        screen = read(HERE / 'bounded-histogram-full24-screen.json')\n        assert screen['complete'] and len(screen['runs']) == 2\n        assert screen['plan']['worker_sha256'] == pin['worker_sha256']\n        for prior in screen['runs']:\n            assert len(prior['results']) == 81\n            for key, floor in [('paired_x_roc', 81), ('paired_x_libdeflate', 62)]:\n                assert sum(row[key]['mech-experiment'] < 1 for row in prior['results']) >= floor\n                assert not [row for row in prior['results'] if row[key]['mech-control'] < 1 <= row[key]['mech-experiment']]\n")
source=source.replace("compiler_file = Path(receipt['compile'][0]).with_name('result.json')", "compiler_file = Path('/private/tmp/mech-shared-cold-epilogues.2L6obP/.qualification/consolidation-995/natural4k-scorer-repair/small-table-entry-guard-compiler/build.json')")
source=source.replace('Measure the exact checked worker after keeping shared cold returns in the caller.','Measure guarded whole-span histogram against the exact qualified 63,388 B worker. Compiler 08e3 is built from source 7ea6 plus its preserved acquisition overlay. Canonical source and bytecode are unchanged; no new win is inherited.')
source=source.replace("prefix = f'shared-terminal-{role}-{kind}'","prefix = f'bounded-histogram-qualified-{role}-{kind}'")
rt.__dict__['__file__']=str(Path(__file__).resolve())
exec(compile(source,str(Path(__file__).resolve())+':measure','exec'),rt.__dict__)
source=inspect.getsource(rt.check).replace("'linked-' + '-'.join(roles)","'linked-packet-lifetime-v3-' + '-'.join(roles)").replace("f'shared-terminal-","f'packet-lifetime-v3-")
exec(compile(source,str(Path(__file__).resolve())+':check','exec'),rt.__dict__)
# The original temporary C source is gone. Reuse the exact previously qualified
# stack probe object, while probing every newly linked worker as usual.
probe=lab/'preserved-registers/linked-current-preserved/linked-proofs/stack-support/stack.o'
probe_sha='47629aa045ac454421a6f8412b9a50fd52eebc76cb4a19191aee9f4c6d7aec22'
assert rt.sha(probe)==probe_sha
old_compile="subprocess.run(['cc','-std=gnu11','-O2','-Wall','-Wextra','-Werror','-c',\n                q/'controller-stack-probe.c','-o',c_object],check=True)"
new_compile="__import__('shutil').copyfile("+repr(str(probe))+",c_object)\nassert __import__('hashlib').sha256(c_object.read_bytes()).hexdigest()=="+repr(probe_sha)
old_copy="    original = (q / name).read_text()"
new_copy=old_copy+"\n    if name=='check-layout-stack.py':\n        old="+repr(old_compile)+"\n        assert original.count(old)==1\n        original=original.replace(old,"+repr(new_compile)+")"
source=inspect.getsource(rt.driver.link.check_contracts)
needle_driver="    driver = (Q / 'backend-work-hardened/verify-linked.py').read_text()"
assert source.count(needle_driver)==1
source=source.replace(needle_driver,needle_driver+"\n    assert driver.count("+repr(old_copy)+")==1\n    driver=driver.replace("+repr(old_copy)+","+repr(new_copy)+")")
exec(compile(source,str(Path(__file__).resolve())+':check_contracts', 'exec'),rt.driver.link.check_contracts.__globals__)
# Add the two large-random contracts that motivated this experiment.
rt.timing.focus=[*rt.timing.focus,'prefix-random-262144','prefix-random-1048576']
action,*roles=sys.argv[1:]
if action=='check':
 for role in roles:
  r=json.loads((root/role/'receipt.json').read_text())
  if not (root/role/'bound/runtime.json').exists():rt.driver.link.link_worker(rt.UNCHANGED,root/role/'frontend',root/role/'bound')
  pin=json.loads((root/role/'bound/runtime.json').read_text())
  pin.pop('size_bytes',None);pin.pop('encoder_sha256',None);pin['encoder_text_bytes']=r['text_bytes'];(root/role/'bound/runtime.json').write_text(json.dumps(pin,indent=2)+'\n')
  assert pin['object_sha256']==r['object_sha256']
  assert rt.driver.link.sha(root/role/'bound/mech-worker')==pin['worker_sha256']
 rt.check(*roles)
 for role in roles:
  proof=json.loads((root/role/'linked-proof.json').read_text());assert proof['peak_stack_bytes']<=5280
elif action in ('focus','full'):
 for role in roles:rt.measure(role,action)
else:raise ValueError(action)
