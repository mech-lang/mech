"""Refresh sampled attribution on the newly published exact-worker compiler."""
from pathlib import Path
from runpy import run_path
import json
lab=Path(__file__).resolve().parent
profile=lab/'indexed-cleanup-profile'
profile.mkdir()
source=lab/'sample-final-cleanup.py'
tools=run_path(str(source),run_name='indexed_cleanup_samples')
tools['main'].__globals__.update(HERE=profile,RECORD=json.loads((lab/'loop-liveout-index/indexed/receipt.json').read_text()))
tools['main']()
