from pathlib import Path
import json,os,subprocess,time
n=Path(__file__).resolve().parent
print('Waiting for the already-live compiler and default-test controllers6710/6709.',flush=True)
def alive(pid):
 try:os.kill(pid,0);return True
 except ProcessLookupError:return False
while any(alive(pid) for pid in [6710,6709]):time.sleep(5)
for leaf in ['scalar-pair-revisit-compiler/build.json','scalar-pair-revisit-repository-tests/result.json']:
 r=json.loads((n/leaf).read_text());assert r['exit_code']==0,(leaf,r)
commands=[['python3','test-scalar-pair-enabled.py'],['python3','emit-scalar-pair-raw.py'],['python3','count-paired-packed-key.py','scalar-pair-tail-probe','scalar-pair-head-probe'],['python3','emit-scalar-pair-profiled.py']]
for role in ['scalar-pair-tail-probe-profiled','scalar-pair-head-probe-profiled']:
 commands.extend([['python3','qualify-input-windows.py','check',role],['python3','check-window-profiled-candidate.py',role]])
for index,command in enumerate(commands):
 print('Running',command,flush=True)
 with (n/f'scalar-pair-preparation-{index}.log').open('w') as log:
  r=subprocess.run(command,cwd=n,stdout=log,stderr=subprocess.STDOUT)
 assert r.returncode==0,(command,(n/f'scalar-pair-preparation-{index}.log').read_text()[-6000:])
 print('Completed',command,flush=True)
(n/'scalar-pair-campaign-ready.json').write_text(json.dumps({'commands':commands,'all_exit_codes':0,'runtime_clocks_started':False},indent=2)+'\n')
print('All compiler/test/count/semantic producers complete; runtime campaign has not started.',flush=True)
