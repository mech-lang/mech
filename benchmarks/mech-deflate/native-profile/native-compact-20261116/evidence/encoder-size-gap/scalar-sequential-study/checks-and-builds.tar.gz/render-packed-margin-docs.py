from pathlib import Path
import json
W=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP');P=W/'benchmarks/mech-deflate/native-profile/native-compact-20261116';E=P/'evidence/encoder-size-gap/packed-margin-repair-study';r=json.loads((E/'result.json').read_text());b=r['builds'];source=r['source_basis_commit']
text='''# Packed scorer head-group and item-width study

**Keep the head-group saving and continue optimizing the paired scorer. The qualified default remains 63,612 B / 81 Roc / 62 libdeflate. No new qualified C win is claimed.**

Head-group processing emits **63,836 B**, saving **16 B** and **10,308 executed scorer instructions** on natural 4 KiB against the exact 63,852 B paired-carried candidate. It measures **0.998497× / 1.000382× libdeflate** in the complete forward/reverse 21-case discovery orders; time against its matching held control is **1.000019× / 0.998029×**. The reverse gap remains. All prior wins present in all eight complete discovery orders survive. These panels do not establish a new full score or confidence qualification.

'''
text+=f'Compiler source: [`{source[:10]}`](https://github.com/mech-lang/mech/commit/{source}). The original 2,719-line Mech codec and canonical bytecode are unchanged. No LLVM dependency is added.\n\n'
text+='''`MECH_ORDERED_PACKED_HEAD_GROUP=1` moves the optional four-element group to the beginning. The paired loop then reuses the existing end value. The same admitted immutable elements are visited, and packed ordinals retain strict/earliest source choices. In this source epoch the paired entry still requires sixteen elements, so an optional head leaves at least sixteen for the loop. Scalar remainders, wide-cost fallback, checked errors, direct scalar execution and exact source accounting are unchanged.

`MECH_ORDERED_PACKED_WIDE_ITEM=1` widens the ordinal before removing its bias. A full-width offset can fold into that subtraction; unchanged zero ordinal becomes I64 −1 and preserves the entire old item. Its pure total extension is discarded when no winner exists. The feature applies only to a carried full-width item; an index-only result retains the original I32 representation.

For this codec, existing item narrowing already performs the useful fold. **Wide-only reproduces all three original paired artifacts exactly; head+wide reproduces all three head-only artifacts exactly**, both before and after block layout. They receive no separate timing claim. Revisit the older `MECH_ORDERED_PACK_WINNER_AT_EXIT=1` option to expose a real width effect: widening removes **2,955 instructions** from that deferred candidate on natural 4 KiB. The deferred mode still adds instructions overall and does not establish a latency gain. All comparisons and no-ops remain preserved.

## All distinct-code discovery orders

Each row contains complete 21-case/24-balanced-block forward and reverse acquisitions. Every candidate compares against the same exact 63,852 B paired-carried worker, with the same declared eight-case profile policy. Times are Mech / peer; lower is faster.

| Candidate | Encoder text | Natural 4 KiB / C | Natural time / held paired control |
| --- | ---: | ---: | ---: |
'''
for role in ['packed-head-group-probe-profiled','packed-defer-item-probe-profiled','packed-defer-wide-probe-profiled','packed-head-defer-wide-probe-profiled']:
 rows=[next(row for row in run['results'] if row['case']=='prefix-natural-4096') for run in r['stages']['margin']['runs'] if run['role']==role];x=[row['paired_x_libdeflate']['mech-experiment'] for row in rows];y=[row['paired_x_roc']['mech-experiment']/row['paired_x_roc']['mech-control'] for row in rows];text+=f"| `{role}` | {r['roles'][role]['text_bytes']:,} B | {x[0]:.6f}× / {x[1]:.6f}× | {y[0]:.6f}× / {y[1]:.6f}× |\n"
text+='''
Untimed raw-scorer counts on natural 4 KiB:

| Candidate | Instructions | Branches | Stack loads / stores |
| --- | ---: | ---: | ---: |
| Previous paired carried | 3,343,871 | 549,581 | 17,310 / 18,475 |
| Head group | 3,333,563 | 549,581 | 17,310 / 18,475 |
| Deferred item | 3,354,596 | 549,581 | 17,320 / 18,480 |
| Deferred + wide | 3,351,641 | 549,581 | 17,320 / 18,480 |
| Head + deferred + wide | 3,341,333 | 549,581 | 17,320 / 18,480 |

The wider representation removes one instruction per admitted packed reduction in the deferred version. It does not change the eight-case counts without deferred reconstruction. Counts are diagnostic, not latency claims. Zero-call cases retain their original zero weights.

## Source through final executable builds

Apple M1, macOS 15.6.1, arm64. Eight balanced serial fresh-process trials per actor include final executable linking. Compilers and fixed support are prebuilt equally. Bootstrap and strip are separate; every emitted Mech object, full metadata and bytecode is hash checked.

| Actor | Encoder text | Source through final link | Stripped executable |
| --- | ---: | ---: | ---: |
'''
for actor,name,size,exe in [('mech-control-reference','Qualified histogram',63612,276072),('mech-head-group','Head-group candidate',63836,276072),('roc','Roc',57696,191912),('libdeflate','libdeflate C',37080,155752)]:text+=f"| {name} | {size:,} B | {b['medians'][actor]['source_through_link']:.6f} s | {exe:,} B |\n"
x=b['paired_ratios']['mech-head-group'];text+=f"\nHead-group encoder text is **{63836/57696:.3f}× Roc / {63836/37080:.3f}× C**; paired build time is **{x['roc']:.6f}× Roc / {x['libdeflate']:.6f}× C**, **{x['mech-control-reference']:.6f}×** the qualified control. No compile-time gain is established. Phase medians and all observations are in the build archive.\n\n"
text+='''## Validation and portable replay

- Nineteen optimized tests pass in four configurations: default; both new options with header testing; both with lane carry and latch testing; and both with the older deferred-item option. Each configuration includes **94,208 loop/key calls, 16,384 wide-item calls and 16,384 earlier winner/item calls**. The fixtures cover strict ties, complete old I64 items, total offset wraparound, both loop forms, all 16-bit boundaries and unaligned guarded storage. Composition tests preserve source remainders, wrapping, denial, publication and retry.
- All three artifacts reproduce exactly for **25 older recipes**. All six new workers pass 162 output/inflation/alias observations, six checked failures and twelve injected failures followed by twelve exact recoveries. Normal/checked artifacts match exactly. Peak stack is **4,736 B**, below the 5,280 B cap.
- All six portable recipes reproduce exactly in normal and checked emission with relocated profiles. The public verifier checks actual artifact equality against the preceding published study, not only recorded equality booleans. The full GPU suite is not claimed; the existing missing archived allocator still blocks the repository unsafe audit.

```sh
python3 verify.py
python3 reproduce.py /path/to/compile_profile /tmp/head-group-replay --role packed-head-group-probe-profiled
```

`checks-and-builds.tar.gz` preserves compiler and test source overlays/commands, all replays, six candidate workers and checks, instruction counts, negative equivalence results and full build observations. `raw-runtime.tar.gz` preserves all eight distinct-code orders. Every member is pinned in `archive-files.json`. The preceding paired candidate and both complete 96-block outcomes remain available in the [paired accumulator study](../paired-packed-accumulator-study/README.md); its reverse 0.036% miss is not discarded.

Next: test entering the paired vector loop with eight candidates only when packed cost/index bounds are met. The arithmetic needs one eight-candidate group, while the current sixteen-element entry is a performance heuristic. Short wide-cost intervals must retain their scalar path, and wide vector intervals retain their sixteen-element entry. Compare both head and tail forms; repeat the full 81-case confidence gate before claiming win 63. That follow-up is not implemented in this source epoch.
'''
(E/'README.md').write_text(text)
new='''Compiler source **`2b6ed311d`** keeps the paired scorer and tests head-group processing plus wider item decoding. The head candidate is **63,836 B**, saving **16 B** and **10,308 executed natural-4-KiB scorer instructions**. It measures **0.998497× / 1.000382× C**, with **1.000019× / 0.998029×** time versus the exact paired-carried control. All prior wins present in eight complete 21-case discovery orders survive. No new full score or qualified 63rd win is claimed; keep the saving and continue the paired scorer. The qualified default remains **63,612 B / 81 Roc / 62 C**.

Wide-only and head+wide are exact artifact no-ops for this codec. Combining width changes with the older deferred-item option removes 2,955 instructions, but the deferred family does not establish a latency gain. All six workers pass output/error/stack/recovery gates and portable normal/checked replay. Nineteen optimized tests pass in four configurations; 25 older recipes reproduce all artifacts exactly. Head build is **2.222766 s**, paired **0.744078× Roc / 4.610974× C**, with **276,072 B** stripped executable and **4,736 B** peak stack. No compile-time gain is shown. [Source, all eight distinct-code orders, negative results, counts, checks and complete builds](evidence/encoder-size-gap/packed-margin-repair-study/README.md).

Next, enter at eight only under the packed bounds and retain the original short wide-cost scalar path. This revisits the earlier short-vector work with the new paired scorer; it is not implemented in the linked source epoch.

'''
p=P/'REVIEW.md';p.write_text(new+'Preceding paired-accumulator checkpoint:\n\n'+p.read_text().replace('Latest compiler source **`31910aff6`**','Preceding compiler source **`31910aff6`**',1))
p=P/'CURRENT.md';s=p.read_text();a=s.index('Latest complete-build cohort on the **Apple M1**');z=s.index('\n\n',a);s=s[:a]+'''Latest complete-build cohort on the **Apple M1** reproduces the qualified encoder exactly and measures **2.216508 s Mech, 2.988164 s Roc and 0.482030 s C**, eight balanced fresh-process trials including final executable linking with equal prebuilt compilers/support. Paired qualified-control ratios are **0.741978× Roc / 4.602918× C**. Stripped executables remain 276,072 B / 191,912 B / 155,752 B. Bootstrap and strip are separate; no compilation-time gain is established. [Current build evidence](evidence/encoder-size-gap/packed-margin-repair-study/README.md).'''+s[z:];s=s.replace('## Current paired packed-accumulator experiments','## Current paired scorer margin experiments\n\n'+new+'## Preceding paired packed-accumulator experiments',1).replace('Latest compiler source **`31910aff6`**','Preceding compiler source **`31910aff6`**',1);p.write_text(s)
p=P/'scorecard.json';s=json.loads(p.read_text());s['packed_margin_repair_experiment']={'source_commit':source,'compiler_sha256':r['roles']['packed-head-group-probe-profiled']['compiler_sha256'],'evidence':'evidence/encoder-size-gap/packed-margin-repair-study/README.md','promoted':False,'qualified_selection_unchanged':True,'head_text_bytes':63836,'head_saved_bytes':16,'head_natural_scorer_instructions_removed':10308,'native_tests':r['native_tests'],'artifact_equivalence':r['artifact_equivalence'],'discovery_orders':8,'discovery_cases':21,'all_observed_prior_wins_preserved':True,'new63rd_qualified':False,'complete_build':b,'next_target':'Packed eight-candidate entry guarded by cost/index bounds; preserve scalar8..15 wide-cost path and original sixteen-element wide vector threshold. Keep all original named wins.'};s['current_matched_build']='packed_margin_repair_experiment.complete_build';s['review'].update(compiler_source_commit=source,compiler_sha256=r['roles']['packed-head-group-probe-profiled']['compiler_sha256'],latest_deployment_evidence=s['packed_margin_repair_experiment']['evidence']);s['next_runtime_target'].update(primary_investigation=s['packed_margin_repair_experiment']['next_target']);p.write_text(json.dumps(s,indent=2)+'\n');print('Margin-study documentation and scorecard updated; eight-entry remains a separate source epoch.')
