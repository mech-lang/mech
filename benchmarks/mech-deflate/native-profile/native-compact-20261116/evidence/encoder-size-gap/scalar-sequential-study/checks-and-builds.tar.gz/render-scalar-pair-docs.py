from pathlib import Path
import json
w=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP');p=w/'benchmarks/mech-deflate/native-profile/native-compact-20261116';e=p/'evidence/encoder-size-gap/scalar-pair-revisit-study';r=json.loads((e/'result.json').read_text());b=r['builds'];source=r['source_basis_commit'];required=json.loads((Path(__file__).parent/'word-complements-prior-wins.json').read_text())['required_previous_individual_wins']
text=f'''# Paired scalar continuation under the modern scorer

**Keep the qualified 63,612 B /81 Roc /62 libdeflate default and the preceding eight-entry candidate. The restored paired scalar path needs repair: it loses the existing natural8KiB C win. No new qualified win is claimed.**

Compiler source: [`{source[:10]}`](https://github.com/mech-lang/mech/commit/{source}). The original 2,719-line Mech codec and canonical bytecode remain unchanged. No LLVM dependency is added. The opt-in source and all observations are retained.

`MECH_ORDERED_PAIRED_CONTINUATION=1` revisits the earlier paired-scalar experiment with the current 4,736 B frame and packed eight-entry scorer. After the original first scalar visit, two admitted continuation visits are evaluated together. A strict comparison chooses the earlier member of a tie; another strict comparison preserves the entire incoming item on a tie with the best. The original scalar loop handles an odd remainder. Deferred-item reconstruction remains supported. The same source-derived immutable windows and biased-index witness admit both reads; no visits, budgets or error checks are removed.

A separate production helper keeps the pair control flow small and directly testable. The new native fixture covers both reverse widths, unaligned guarded storage, wrapping U32 costs, complete old I64 items, strict ties, multiple pairs and odd tails. The disabled option reproduces **all three artifacts for33 older recipes exactly**.

## All eight runtime orders

Each entry is a complete21-case/24-balanced-block acquisition. Times are Mech /libdeflate; lower is faster. Original head/tail variants compare against their exact eight-entry workers. Register-setting pairs compare against matching unpaired controls with the same setting and layout policy. The latter leave the two other phases unprofiled and prepare the same fresh eight-case scorer profile for both actors, so they do not isolate register preference from that policy change.

| Candidate | Text | Order | Natural4KiB /C | Natural8KiB /C | 4KiB time /held control | Missing old C wins in panel |
| --- | ---: | --- | ---: | ---: | ---: | --- |
'''
for stage in r['stages'].values():
 for run in stage['runs']:
  rows={row['case']:row for row in run['results']};four=rows['prefix-natural-4096'];eight=rows['prefix-natural-8192'];misses=[row['case'] for row in run['results'] if row['case'] in required['libdeflate'] and row['paired_x_libdeflate']['mech-experiment']>=1]
  text+=f"| `{run['role']}` | {r['roles'][run['role']]['text_bytes']:,} B | {run['order']} | {four['paired_x_libdeflate']['mech-experiment']:.6f}× | {eight['paired_x_libdeflate']['mech-experiment']:.6f}× | {four['paired_x_roc']['mech-experiment']/four['paired_x_roc']['mech-control']:.6f}× | {', '.join(misses) or 'none'} |\n"
text+='''
These discovery panels do not establish a full81-case score. All previous observed Roc wins survive, but the named natural8KiB C loss rules out promotion now. Keep the source and investigate the cause. The preceding eight-entry candidate remains **63,868 B /63 C point wins in both full96 orders**, with the new reverse natural4KiB confidence interval still crossing parity; the qualified score remains81/62.

## Work and register lifetime

Peak stack stays **4,736 B**. Reload frequency increases sharply even though the pair body itself does not load the stack. The outer literal-cost-table setup now reloads its base from `[sp,#0x90]` on35,565 visits in natural4KiB. Both cost values remain live until the pair minimum is reconstructed, alongside the incoming best and item. Generated code also repeats two comparisons to reconstruct the index and item. This gives specific lifetimes and instructions to repair.

| Natural4KiB raw scorer | Instructions | Branches | Stack loads | Stack stores |
| --- | ---: | ---: | ---: | ---: |
| Eight-entry head | 3,266,626 | 513,080 | 17,310 | 18,475 |
| Paired scalar head | 3,589,068 | 509,199 | 105,720 | 19,650 |

The pair removes3,881 branches but adds322,442 instructions and88,410 stack loads. Natural8KiB rises from7,608,126 to8,466,508 instructions and43,074 to259,920 stack loads. These are untimed diagnostic counts, not latency measurements.

Both existing register settings were attempted: preserved preference only for the root, and no preserved preference. **The raw scorer body hashes and aggregate work counts remain unchanged** for the matching paired/unpaired body in each setting. Other code changes: the two root-only workers emit63,852/64,092 B; the two plain workers emit64,620/64,860 B. All four setting workers pass the semantic gates. Their complete runtime orders above are retained; they do not repair scorer spills.

## Broad loss census

An additional diagnostic census covers eleven cases, using the exact preceding eight-entry raw scorer. It changes no shipping object, layout profile or latency data. Its published full96 references identify the next closest remaining C losses: natural1KiB at approximately1.25×, random1MiB at1.28× and distribution change at1.28–1.29×. Every reference is checked against the preceding raw archive.

Natural1KiB executes423,496 scorer instructions,2,496 stack loads and2,804 stack stores. Its leading blocks contain paired vector scoring, first scalar visits and scalar continuation. Random1MiB instead executes69,418,301 instructions; its hottest13-instruction literal-only block runs2,986,191 times. That block loads the literal cost, constructs and stores the packed DP cost/item word, and advances the outer traversal. Two nearby four-instruction blocks handle descriptor extraction and the literal-index bound. This route needs separate optimization to close the larger random-input gap. The raw blocks and counts for all eleven cases are preserved, including the distribution-change mixture.

## Source through final executable builds

Apple M1, macOS15.6.1, arm64. Ten balanced serial fresh-process trials per actor include final executable linking. Compilers and fixed support are prebuilt equally; bootstrap and stripping are separate. Every generated Mech object, full metadata and bytecode is hash checked. All runtime and diagnostic producers finish before these clocks begin.

| Actor | Encoder text | Source through final link | Stripped executable |
| --- | ---: | ---: | ---: |
'''
for actor,label,size,exe in [('mech-control-reference','Qualified histogram',63612,276072),('mech-scalar-pair-tail','Paired scalar, tail',64124,276072),('mech-scalar-pair-head','Paired scalar, head',64108,276072),('roc','Roc',57696,191912),('libdeflate','libdeflate C',37080,155752)]:text+=f"| {label} | {size:,} B | {b['medians'][actor]['source_through_link']:.6f} s | {exe:,} B |\n"
x=b['paired_ratios']['mech-scalar-pair-head'];v=b['phases']['mech-scalar-pair-head'];text+=f"\nHead paired build time: **{x['roc']:.6f}× Roc /{x['libdeflate']:.6f}× C**, **{x['mech-control-reference']:.6f}×** the qualified control. Text: **{64108/57696:.3f}× Roc /{64108/37080:.3f}× C**. No compilation-time gain is established.\n\nPhase medians: parsing **{v['parse']*1000:.3f} ms**, semantics **{v['frontend']*1000:.3f} ms**, artifact **{v['artifact']*1000:.3f} ms**, encoding **{v['encode']*1000:.3f} ms**, native pipeline **{v['native']*1000:.3f} ms**, final link **{b['medians']['mech-scalar-pair-head']['link']*1000:.3f} ms**. Catalog overlaps parsing; independently computed medians do not add exactly.\n\n"
text+='''## Validation and reproduction

Twenty optimized tests pass in four configurations: default; paired scalar with eight-entry/head/wide item; the same with carried lanes and latch testing; and paired scalar with deferred-item reconstruction. Each configuration includes **22,528 new paired-scalar native calls**,94,208 packed-key/loop calls,16,384 wide-item calls and16,384 prior winner/item calls. All33 disabled recipes reproduce exactly.

All six workers pass162 output/inflation/alias observations, six checked failures, twelve injected failures and twelve exact recoveries. Normal and checked artifacts match, as do all six portable normal/checked recipes with relocated profiles. Peak stack is4,736 B, below5,280 B. The full GPU suite is not claimed; the pre-existing missing archived allocator still blocks the repository unsafe audit.

```sh
python3 verify.py
python3 reproduce.py /path/to/compile_profile /tmp/paired-scalar-replay --role scalar-pair-head-probe-profiled
```

The verifier checks the six source/artifact bindings, test overlays,33 exact replays, semantic/recovery gates, work counts and their prior-study comparisons, all eight raw runtime orders, the eleven-case loss census and ten complete build trials per actor. Archives preserve every observation, including regressions; every member is pinned in `archive-files.json`.

Next, update the minimum and item after each scalar visit within an unrolled pair. This can shorten the first cost and incoming-best lifetimes and avoid reconstructing a pair winner. Test it against this exact paired candidate and the preceding unpaired worker; preserve the old paired mode, exact tails, all prior named wins and the qualified81/62 default. Separately investigate the literal-only DP route identified by the broad census. These follow-ups are not implemented in this source epoch.
'''
# Normalize prose spacing without changing numerical evidence.
for a,z in [(' /81',' / 81'),(' /62',' / 62'),(' /63',' / 63'),(' /C',' / C'),(' /libdeflate',' / libdeflate'),(' /held',' / held'),('for33','for 33'),('complete21','complete 21'),('full81','full 81'),('natural8KiB','natural 8 KiB'),('natural4KiB','natural 4 KiB'),('Natural4KiB','Natural 4 KiB'),('Natural8KiB','Natural 8 KiB'),('natural1KiB','natural 1 KiB'),('Natural1KiB','Natural 1 KiB'),('random1MiB','random 1 MiB'),('Random1MiB','Random 1 MiB'),('approximately1.25','approximately 1.25'),('at1.28','at 1.28'),('on35,565','on 35,565'),('removes3,881','removes 3,881'),('adds322,442','adds 322,442'),('and88,410','and 88,410'),('from7,608,126','from 7,608,126'),('to8,466,508','to 8,466,508'),('and43,074','and 43,074'),('to259,920','to 259,920'),('emit63,852/64,092','emit 63,852 / 64,092'),('emit64,620/64,860','emit 64,620 / 64,860'),('executes423,496','executes 423,496'),('instructions,2,496','instructions, 2,496'),('and2,804','and 2,804'),('executes69,418,301','executes 69,418,301'),('hottest13','hottest 13'),('runs2,986,191','runs 2,986,191'),('macOS15.6.1','macOS 15.6.1'),('calls**,94','calls**, 94'),('calls,16','calls, 16'),('and16','and 16'),('All33','All 33'),('pass162','pass 162'),('is4,736','is 4,736'),('below5,280','below 5,280'),('overlays,33','overlays, 33'),('qualified81/62','qualified 81/62')]:text=text.replace(a,z)
text=text.replace('× Roc /','× Roc / ')
(e/'README.md').write_text(text)
summary=f'''Compiler source **`{source[:10]}`** restores the historical paired scalar continuation as an opt-in path. It passes **20 optimized tests in four configurations**, including **22,528 new native calls** per configuration, and all **33 older recipes reproduce exactly**. Both main candidates and four register-setting workers pass output/error/stack/recovery gates and portable normal/checked replay. The qualified **63,612 B /81 Roc /62 C** default remains selected; the preceding eight-entry candidate still retains63 C point wins in both full96 orders, with reverse confidence crossing parity.

Pairing increases natural4KiB stack loads **17,310 →105,720** and instructions **3,266,626 →3,589,068**, despite removing3,881 branches. Its original head variant costs **1.96–2.44% more natural4KiB time** and **4.21–4.86% more natural8KiB time** than its held control, losing the old8KiB C win in both orders. Existing register settings leave the scorer body and counts unchanged; their four additional orders are preserved. Keep the source and repair the cost/best/item lifetimes. A separate eleven-case census also identifies the literal-only DP route behind random-input losses. [All eight orders, checks, counts, builds and replay](evidence/encoder-size-gap/scalar-pair-revisit-study/README.md).

Head text: **64,108 B**; complete build **{b['medians']['mech-scalar-pair-head']['source_through_link']:.6f} s**, paired **{x['roc']:.6f}× Roc /{x['libdeflate']:.6f}× C**; stripped executable **276,072 B**; peak stack **4,736 B**. No compile-time gain is shown. Next, test sequential updates inside the unrolled pair and optimize the literal-only route separately. These follow-ups are not yet implemented.

'''
for a,z in [(' /81',' / 81'),(' /62',' / 62'),('retains63','retains 63'),('natural4KiB','natural 4 KiB'),('natural8KiB','natural 8 KiB'),('old8KiB','old 8 KiB'),('→105','→ 105'),('→3,589','→ 3,589'),('removing3,881','removing 3,881'),('× Roc /','× Roc / ')]:summary=summary.replace(a,z)
f=p/'REVIEW.md';f.write_text(summary+'Preceding guarded eight-entry checkpoint:\n\n'+f.read_text())
f=p/'CURRENT.md';s=f.read_text();a=s.index('Latest complete-build cohort on the **Apple M1**');z=s.index('\n\n',a);s=s[:a]+f"Latest complete-build cohort on the **Apple M1** reproduces the qualified encoder exactly and measures **{b['medians']['mech-control-reference']['source_through_link']:.6f} s Mech, {b['medians']['roc']['source_through_link']:.6f} s Roc and {b['medians']['libdeflate']['source_through_link']:.6f} s C**, ten balanced fresh-process trials including final executable linking with equal prebuilt compilers/support. Stripped executables remain 276,072 B /191,912 B /155,752 B. Bootstrap and strip are separate; no compilation-time gain is established. [Current build evidence](evidence/encoder-size-gap/scalar-pair-revisit-study/README.md)."+s[z:];s=s.replace('## Current guarded eight-entry experiment','## Current paired scalar revisit\n\n'+summary+'## Preceding guarded eight-entry experiment',1);f.write_text(s)
f=p/'scorecard.json';s=json.loads(f.read_text());s['scalar_pair_revisit_experiment']={'source_commit':source,'compiler_sha256':r['roles']['scalar-pair-head-probe-profiled']['compiler_sha256'],'evidence':'evidence/encoder-size-gap/scalar-pair-revisit-study/README.md','promoted':False,'qualified_selection_unchanged':True,'head_text_bytes':64108,'peak_stack_bytes':4736,'native_tests':r['native_tests'],'discovery_orders':8,'full81_score_measured':False,'register_equivalence':r['register_equivalence'],'broad_loss_census':r['broad_loss_census'],'panel_audit':r['panel_audit'],'complete_build':b,'next_target':'Sequential minimum/item updates within the unrolled pair to shorten first-cost and incoming-best lifetimes. Keep exact odd tails and prior named wins. Separately investigate literal-only packed DP writes identified by the eleven-case loss census.'};s['current_matched_build']='scalar_pair_revisit_experiment.complete_build';s['review'].update(compiler_source_commit=source,compiler_sha256=s['scalar_pair_revisit_experiment']['compiler_sha256'],latest_deployment_evidence=s['scalar_pair_revisit_experiment']['evidence']);s['next_runtime_target'].update(primary_investigation=s['scalar_pair_revisit_experiment']['next_target']);f.write_text(json.dumps(s,indent=2)+'\n')
print('Paired scalar revisit and broad census documented; qualified81/62 unchanged.')
