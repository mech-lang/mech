"""Emit branch experiments and require exact pre-existing artifacts when off."""
from pathlib import Path
from hashlib import sha256
from runpy import run_path
import json, os, subprocess

N = Path(__file__).resolve().parent
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: sha256(Path(p).read_bytes()).hexdigest()
build = read(N / 'packed-eight-entry-compiler/build.json')
tool = run_path(str(N.parent.parent / 'current-roadmap/scorer-runtime/emit.py'),
                run_name='deferred_winner_symbols')

def compile_into(out, prior, flags):
    out.mkdir(parents=True)
    command = [build['compiler'], prior['compile'][1], str(out / 'frontend'), 'compact']
    with (out / 'compile.log').open('w') as log:
        subprocess.run(command, env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')} | flags,
                       stdout=log, stderr=log, check=True)
    artifacts = {name: sha(out / 'frontend' / name) for name in prior['artifacts']}
    assert artifacts['program.mecb'] == prior['artifacts']['program.mecb']
    return command, artifacts

replays = N / 'packed-eight-entry-disabled-replays'
replays.mkdir()
rows = []
for role in ['bounded-histogram-word', 'read-window-word-profiled', 'read-window-probe-profiled',
             'select-packet-family-word-cold-profiled', 'select-packet-family-probe-cold-profiled',
             'select-packet-family-word-scorer-profiled',
             'select-packet-word-combined-profiled', 'select-packet-probe-combined-profiled',
             'defer-winner-probe-profiled', 'defer-winner-word-profiled',
             'defer-winner-combined-word-profiled', 'defer-winner-combined-probe-profiled',
             'mapped-item-probe-profiled', 'mapped-item-word-profiled',
             'mapped-item-combined-word-profiled', 'mapped-item-combined-probe-profiled',
             'packed-key-probe-profiled','packed-key-word-profiled','packed-key-carry-probe-profiled','packed-key-carry-word-profiled',
             'extended-control-probe-profiled','packed-extended-probe-profiled','packed-extended-carry-probe-profiled',
             'paired-key-probe-profiled','paired-key-carry-probe-profiled',
             'packed-head-group-probe-profiled','packed-wide-item-probe-profiled','packed-head-wide-probe-profiled',
             'packed-defer-item-probe-profiled','packed-defer-wide-probe-profiled','packed-head-defer-wide-probe-profiled']:
    old = read(N / role / 'receipt.json')
    command, artifacts = compile_into(replays / role, old, old['flags'])
    assert artifacts == old['artifacts'], role
    rows.append({'role': role, 'command': command, 'artifacts': artifacts, 'three_exact': True})
(replays / 'result.json').write_text(json.dumps({'all_three_exact': True,
    'compiler_sha256': build['compiler_sha256'], 'runs': rows}, indent=2) + '\n')
for role, base in [('packed-eight-paired-probe','paired-key-carry-probe-profiled'),
                   ('packed-eight-head-probe','packed-head-group-probe-profiled')]:
    prior = read(N / base / 'receipt.json')
    flags = prior['flags'] | {'MECH_ORDERED_PACKED_EIGHT_ENTRY':'1'}
    profiles = []
    for item in flags['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].split(';'):
        symbol, _ = item.split('@', 1)
        if symbol != 'mech_compact_numeric_3009_no_growth_composed':
            profiles.append(item)
    assert len(profiles) == 2
    flags['MECH_COMPACT_PHASE_BLOCK_LAYOUT'] = ';'.join(profiles)
    command, artifacts = compile_into(N / role, prior, flags)
    layout = tool['symbols'](N / role / 'frontend/program.o')
    for symbol in ['_mech_compact_numeric_475_vector', '_mech_compact_numeric_3956_vector']:
        assert layout['symbols'][symbol]['sha256'] == prior['layout']['symbols'][symbol]['sha256'], symbol
    record = prior | {'compile': command, 'command': command,
        'compiler_sha256': build['compiler_sha256'], 'source_base': build['source_base'],
        'source_inputs': build['source_sha256'], 'flags': flags, 'artifacts': artifacts,
        'object_sha256': artifacts['program.o'], 'metadata_sha256': artifacts['metadata.json'],
        'bytecode_sha256': artifacts['program.mecb'], 'text_bytes': layout['text_bytes'],
        'layout': layout, 'base_role': base, 'runtime_qualification': 'pending'}
    (N / role / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
    print(role, layout['text_bytes'], layout['symbols']['_mech_compact_numeric_3009_no_growth_composed']['extent'], flush=True)
