from pathlib import Path
import json
W=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP')
P=W/'benchmarks/mech-deflate/native-profile/native-compact-20261116'
E=P/'evidence/encoder-size-gap/packed-eight-entry-study'
r=json.loads((E/'result.json').read_text());q=r['qualification96'];b=r['builds'];source=r['source_basis_commit'];head='packed-eight-head-probe-profiled'
old_supported=all(not (set(peer['unsupported'])-({'prefix-natural-4096'} if name=='libdeflate' else set())) for audit in q['named_win_audit'] for name,peer in audit['peers'].items())
text=f'''# Guarded eight-candidate packed scorer entry

**Strict 63-win qualification: {'passed' if q['passed'] else 'not passed'}. The qualified default remains 63,612 B / 81 Roc / 62 libdeflate until selection is separately updated. Keep the candidate and its measured gains.**

Compiler source: [`{source[:10]}`](https://github.com/mech-lang/mech/commit/{source}). The original 2,719-line Mech codec and canonical bytecode remain unchanged. No LLVM dependency is added.

`MECH_ORDERED_PACKED_EIGHT_ENTRY=1` permits a paired packed reduction to begin at eight candidates. It requires the existing little-endian AArch64 packed-cost option, exactly two accumulators, no carried pointers, and an index-independent cost. The runtime packed-key best/count guard is reused at vector entry. Eight to fifteen candidates with wide costs return to the original short scalar path; the original wide vector loop retains its sixteen-element threshold. Counts below eight retain the same first scalar operation. Exact remainder, strict earliest-winner behavior, original wide item, checked errors and finite source accounting remain maintained.

Both head and tail forms are measured against their exact sixteen-entry workers, with the same declared eight-case layout profile policy. With this option disabled, **31 older recipes reproduce all three artifacts exactly**. This source change keeps the earlier head-group and wider-item machinery.

## Runtime campaign

All ratios are Mech / libdeflate; lower is faster. Discovery comprises four complete 21-case/24-balanced-block orders. The head candidate then receives two complete 81-case/24-block screens and two complete 81-case/96-block qualifications. Every observation is retained.

| Candidate | Encoder text | Discovery natural 4 KiB, forward / reverse |
| --- | ---: | ---: |
'''
for role,pin in r['roles'].items():
 rows=[next(row for row in run['results'] if row['case']=='prefix-natural-4096') for stage in r['stages'].values() for run in stage['runs'] if run['role']==role]
 text+=f"| `{role}` | {pin['text_bytes']:,} B | {rows[0]['paired_x_libdeflate']['mech-experiment']:.6f}× / {rows[1]['paired_x_libdeflate']['mech-experiment']:.6f}× |\n"
text+='\n| Full24 order | Roc wins | C wins | Natural 4 KiB / C |\n| --- | ---: | ---: | ---: |\n'
for run in r['full24']['runs']:
 x=next(row for row in run['results'] if row['case']=='prefix-natural-4096')['paired_x_libdeflate']['mech-experiment']
 text+=f"| {run['order']} | {run['peers']['roc']['wins']} | {run['peers']['libdeflate']['wins']} | {x:.6f}× |\n"
text+='\n| Full96 order | Roc point / precision wins | C point / precision wins | Natural 4 KiB / C | 90% paired time-change interval vs C |\n| --- | ---: | ---: | ---: | ---: |\n'
for report,audit in zip(q['runtime_report']['runs'],q['named_win_audit'],strict=True):
 natural=audit['peers']['libdeflate']['cases']['prefix-natural-4096'];ci=natural['interval'];peers=report['peers']
 counts=lambda name:f"{peers[name]['point_estimate_wins']['mech-experiment']} / {peers[name]['precision_supported_wins']['mech-experiment']}"
 text+=f"| {report['order']} | {counts('roc')} | {counts('libdeflate')} | {natural['paired_x']:.6f}× | {ci['lower']*100:+.3f}% to {ci['upper']*100:+.3f}% |\n"
text+=f"\nEvery original 81 Roc / 62 C named win is precision-supported in both full96 orders: **{old_supported}**. Strict qualification passes: **{q['passed']}**. The final gate remains 63 C wins, every prior named win plus natural 4 KiB, and the existing 90% / 8,000-resample confidence policy in both orders. The reverse full24 target at 1.002393× C was admitted within the existing 0.5% discovery resolution; that screening admission does not weaken the final gate.\n\n"
text+='Unsupported named wins are recorded for each complete96 order:\n\n'
for audit in q['named_win_audit']:
 text+=f"- {audit['order']}: "+'; '.join(name+': '+(', '.join(peer['unsupported']) or 'none') for name,peer in audit['peers'].items())+'.\n'
text+='''
The public verifier replays raw observations, cleanup and actor pins, both full24 screens, the complete full96 report and each required named confidence outcome. Before timing, all 81 temporary input/prefix/expected contents and shapes were reconciled with the canonical inventory. Only the canonical replay inventory digest is reconciled; original pins and all data remain intact.

## Untimed scorer counts

On natural 4 KiB, the head candidate removes **66,937 instructions and 36,501 branches** against the preceding sixteen-entry head worker. Stack traffic is unchanged. Aggregate instruction, branch and stack counts on random 1 MiB and distribution change are exactly unchanged; individual branch opcodes can differ. Natural 8 KiB executes more scorer instructions but retains its previous peer win; speed changes are allowed when prior individual peer wins survive. These counts are diagnostic and do not replace latency observations.

| Raw scorer | Natural 4 KiB instructions | Branches | Stack loads / stores |
| --- | ---: | ---: | ---: |
| Previous paired carried | 3,343,871 | 549,581 | 17,310 / 18,475 |
| Previous sixteen-entry head | 3,333,563 | 549,581 | 17,310 / 18,475 |
| Eight-entry paired | 3,286,504 | 513,080 | 17,310 / 18,475 |
| Eight-entry head | 3,266,626 | 513,080 | 17,310 / 18,475 |

## Source through final executable builds

Apple M1, macOS 15.6.1, arm64. Ten balanced serial fresh-process trials per actor include final executable linking, with compilers and fixed support prebuilt equally. Bootstrap and strip are separate. Every generated Mech object, full metadata and bytecode is hash checked. Build clocks start after the runtime campaign and its confidence replay finish.

| Actor | Encoder text | Source through final link | Stripped executable |
| --- | ---: | ---: | ---: |
'''
for actor,name,size,exe in [('mech-control-reference','Qualified histogram',63612,276072),('mech-eight-paired','Eight-entry paired',63884,276072),('mech-eight-head','Eight-entry head',63868,276072),('roc','Roc',57696,191912),('libdeflate','libdeflate C',37080,155752)]:
 text+=f"| {name} | {size:,} B | {b['medians'][actor]['source_through_link']:.6f} s | {exe:,} B |\n"
x=b['paired_ratios']['mech-eight-head']
text+=f"\nHead encoder text is **{63868/57696:.3f}× Roc / {63868/37080:.3f}× C**; paired build time is **{x['roc']:.6f}× Roc / {x['libdeflate']:.6f}× C**, **{x['mech-control-reference']:.6f}×** the qualified control. No compile-time gain is established. All phase medians and observations are in the archive.\n\n"
text+='''## Validation and portable replay

Nineteen optimized tests pass in three configurations: default; eight-entry paired/head/wide item with direct item and singleton; and the same with carried lanes plus latch testing. Each configuration includes **94,208 packed-key/loop native calls, 16,384 wide-item calls and 16,384 prior winner/item calls**. All 31 old recipes reproduce exactly with eight-entry disabled.

Both candidates pass 162 output/inflation/alias observations, six checked failures, twelve injected failures and twelve exact recoveries. Peak stack is **4,736 B**, below the 5,280 B cap. Normal and checked artifacts match exactly, as do portable normal/checked replays with relocated layout profiles. The full GPU suite is not claimed; the pre-existing missing archived allocator still blocks the repository unsafe audit.

```sh
python3 verify.py
python3 reproduce.py /path/to/compile_profile /tmp/eight-entry-replay --role packed-eight-head-probe-profiled
```

`checks-and-builds.tar.gz` contains compiler/test source overlays and commands, old recipe replays, checks, counts, full qualification records and complete-build observations. `raw-runtime.tar.gz` preserves all eight orders: four discovery, two full24 and two full96. Every member is pinned in `archive-files.json`.

The [head/item study](../packed-margin-repair-study/README.md) preserves the earlier 16 B saving, two exact no-ops and the deferred-item revisit. The [paired accumulator study](../paired-packed-accumulator-study/README.md) preserves the preceding reverse 0.036% miss. Keep all gains available for combination. If the new margin remains unsupported, revisit the earlier scalar pairing against this newer 4,736 B frame and inspect actual scalar-block counts; its earlier 5,280 B build increased spill loads.
'''
(E/'README.md').write_text(text)
summary=f"""Compiler source **`{source[:10]}`** adds guarded eight-candidate entry to the paired packed scorer. Head candidate: **63,868 B**, **4,736 B** stack. It removes **66,937 natural-4-KiB scorer instructions and 36,501 branches** versus the sixteen-entry head worker, with unchanged stack traffic. Every original named 81 Roc / 62 C win remains precision-supported in both full96 orders: **{old_supported}**. Strict 63-win qualification passes: **{q['passed']}**. The qualified 63,612 B histogram remains selected until a separate promotion. [All eight runtime orders, confidence results, source, tests, counts, builds and portable replay](evidence/encoder-size-gap/packed-eight-entry-study/README.md).

"""
for report,audit in zip(q['runtime_report']['runs'],q['named_win_audit'],strict=True):
 natural=audit['peers']['libdeflate']['cases']['prefix-natural-4096'];ci=natural['interval'];c=report['peers']['libdeflate']
 summary+=f"{report['order'].capitalize()}96: **81 Roc / {c['point_estimate_wins']['mech-experiment']} C point wins**, natural 4 KiB **{natural['paired_x']:.6f}× C**, 90% interval **{ci['lower']*100:+.3f}% to {ci['upper']*100:+.3f}%**. "
summary+=f"\n\nHead complete build: **{b['medians']['mech-eight-head']['source_through_link']:.6f} s**, paired **{x['roc']:.6f}× Roc / {x['libdeflate']:.6f}× C**, stripped executable **276,072 B**. Nineteen optimized tests pass in three configurations; 31 older recipes and both portable normal/checked artifacts reproduce exactly. No compilation-time gain is established.\n\n"
p=P/'REVIEW.md';p.write_text(summary+'Preceding head/item checkpoint:\n\n'+p.read_text())
p=P/'CURRENT.md';s=p.read_text();a=s.index('Latest complete-build cohort on the **Apple M1**');z=s.index('\n\n',a);s=s[:a]+f"Latest complete-build cohort on the **Apple M1** reproduces the qualified encoder exactly and measures **{b['medians']['mech-control-reference']['source_through_link']:.6f} s Mech, {b['medians']['roc']['source_through_link']:.6f} s Roc and {b['medians']['libdeflate']['source_through_link']:.6f} s C**, ten balanced fresh-process trials including final executable linking with equal prebuilt compilers/support. Stripped executables remain 276,072 B / 191,912 B / 155,752 B. Bootstrap and strip are separate; no compilation-time gain is established. [Current build evidence](evidence/encoder-size-gap/packed-eight-entry-study/README.md)."+s[z:];s=s.replace('## Current paired scorer margin experiments','## Current guarded eight-entry experiment\n\n'+summary+'## Preceding paired scorer margin experiments',1);p.write_text(s)
p=P/'scorecard.json';s=json.loads(p.read_text());s['packed_eight_entry_experiment']={'source_commit':source,'compiler_sha256':r['roles'][head]['compiler_sha256'],'evidence':'evidence/encoder-size-gap/packed-eight-entry-study/README.md','promoted':False,'qualified_selection_unchanged':True,'head_text_bytes':63868,'peak_stack_bytes':4736,'native_tests':r['native_tests'],'discovery_orders':4,'full24_orders':2,'full96_orders':2,'all_original_named_wins_precision_supported':old_supported,'new63rd_strict_qualification_passed':q['passed'],'full96_report':q['runtime_report']['runs'],'named_unsupported':{audit['order']:{name:peer['unsupported'] for name,peer in audit['peers'].items()} for audit in q['named_win_audit']},'complete_build':b,'next_target':'Retain the eight-entry candidate. If its 63rd win lacks confidence, revisit historical scalar pairing against the modern frame and inspect actual scalar-block counts.'};s['current_matched_build']='packed_eight_entry_experiment.complete_build';s['review'].update(compiler_source_commit=source,compiler_sha256=r['roles'][head]['compiler_sha256'],latest_deployment_evidence=s['packed_eight_entry_experiment']['evidence']);s['next_runtime_target'].update(primary_investigation=s['packed_eight_entry_experiment']['next_target']);p.write_text(json.dumps(s,indent=2)+'\n')
print('Eight-entry documentation and scorecard updated. Strict qualification passed:',q['passed'])
