"""Publish read-proof discovery and every tuning order, including losses."""
from pathlib import Path
from hashlib import sha256
import gzip, io, json, shutil, subprocess, tarfile

N = Path(__file__).resolve().parent
Q = N.parent.parent
W = Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP')
P = W / 'benchmarks/mech-deflate/native-profile/native-compact-20261116'
E = P / 'evidence/encoder-size-gap/scalar-pair-revisit-study'
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: sha256(Path(p).read_bytes()).hexdigest()
write = lambda p, v: p.write_text(json.dumps(v, indent=2) + '\n')
source = subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()
roles = ['scalar-pair-tail-probe-profiled','scalar-pair-head-probe-profiled','eight-entry-root-probe-profiled','scalar-pair-root-probe-profiled','eight-entry-plain-probe-profiled','scalar-pair-plain-probe-profiled']
stages = {'scalar_pair': read(N / 'scalar-pair-discovery-scalar-pair-tail-probe-profiled-results.json'), 'registers':read(N/'scalar-pair-register-discovery-scalar-pair-root-probe-profiled-results.json')}
assert all(stage['complete'] for stage in stages.values())
assert read(N/'scalar-pair-revisit-matched-builds/summary.json')['trials']==10
assert [len(stage['runs']) for stage in stages.values()] == [4,4]
E.mkdir()
selected = {}

def add(path):
    path = Path(path)
    if path.is_file():
        selected[str(path.relative_to(N))] = path

def folder(path):
    for file in Path(path).rglob('*'):
        if not file.is_file() or '/compiler/' in str(file.relative_to(N)):
            continue
        if file.suffix in ['.json', '.jsonl', '.log', '.stderr', '.txt', '.py', '.rs', '.c', '.o', '.mecb', '.gz', '.clif'] or file.name in ['mech-worker', 'layout-stack-worker', 'checked-exit-failure-worker']:
            add(file)

for role in roles:
    folder(N / role)
    folder(Path(read(N / role / 'linked-proof.json')['result']).parent.parent)
for name in ['scalar-pair-revisit-compiler','scalar-pair-revisit-repository-tests','scalar-pair-revisit-enabled-tests','scalar-pair-revisit-disabled-replays','scalar-pair-revisit-matched-builds']:
    folder(N / name)
for name in ['scalar-pair-revisit-full24-scalar-pair-head-probe-profiled','scalar-pair-revisit-qualified96-scalar-pair-head-probe-profiled']:
    folder(N/name)
counter_roles = [role.removesuffix('-profiled') for role in roles]
for role in counter_roles:
    folder(N / role)
add(N / 'word-complements-prior-wins.json')
for f in ['scalar-pair-revisit-compiler','scalar-pair-revisit-repository-tests']:
    add(N / f / 'source-inputs/scripts/unsafe-boundaries.allowlist')
for path in N.glob('*.py'):
    if any(term in path.name for term in ['packed','paired','scorer','scalar-pair','input-windows','window-profiled']):
        add(path)
for path in N.glob('*.log'):
    if any(term in path.name for term in ['winner','vector-item','scorer','combined','paired','eight-entry']):
        add(path)
selected['as-run-fixtures.json'] = Q/'fixtures.json'
folder(N/'packed-eight-head-probe/instruction-counts-loss-census')
add(N/'eight-entry-loss-census-summary.json')
add(N/'scalar-pair-register-equivalence.json')
add(N/'scalar-pair-register-gates.json')
add(N/'scalar-pair-register-ablations.json')
archives = {}

def archive(path, files):
    pins, prior = {}, {}
    with tarfile.open(path, 'w:gz', compresslevel=6) as tar:
        for name, file in sorted(files.items()):
            data = file.read_bytes()
            digest = sha256(data).hexdigest()
            pin = (digest, len(data))
            info = tarfile.TarInfo(name)
            info.mtime, info.mode = 0, 0o644
            if pin in prior:
                info.type, info.linkname = tarfile.LNKTYPE, prior[pin]
                tar.addfile(info)
            else:
                info.size = len(data)
                tar.addfile(info, io.BytesIO(data))
                prior[pin] = name
            pins[name] = {'bytes': len(data), 'sha256': digest}
    archives[path.name] = pins

archive(E / 'checks-and-builds.tar.gz', selected)
raw = {}
for stage in stages.values():
    for run in stage['runs']:
        root = Q / Path(run['run']).name
        for file in root.rglob('*'):
            if file.is_file():
                raw[str(file.relative_to(Q))] = file
full24_path=N/'scalar-pair-revisit-full24-scalar-pair-head-probe-profiled/result.json'
qualification96_path=N/'scalar-pair-revisit-qualified96-scalar-pair-head-probe-profiled/result.json'
full24=read(full24_path) if full24_path.exists() else None
qualification96=read(qualification96_path) if qualification96_path.exists() else None
for label in ([Path(row['folder']).name for row in full24['runs']] if full24 else [])+([row['id'] for row in qualification96['receipts']] if qualification96 else []):
    for file in (Q/label).rglob('*'):
        if file.is_file():raw[str(file.relative_to(Q))]=file
archive(E / 'raw-runtime.tar.gz', raw)
write(E / 'archive-files.json', archives)
(E / 'phase-profiles').mkdir()
published = {}
for role in roles:
    receipt = read(N / role / 'receipt.json')
    bound = read(N / role / 'bound/runtime.json')
    profiles = []
    for item in receipt['flags']['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].split(';'):
        symbol, path = item.split('@', 1)
        pin = sha(path)
        target = E / 'phase-profiles' / (pin[:24] + '.json')
        if not target.exists():
            shutil.copyfile(path, target)
        profiles.append({'symbol': symbol, 'path': str(target.relative_to(E)), 'sha256': pin})
    published[role] = {
        'artifact_sha256': receipt['artifacts'], 'text_bytes': receipt['text_bytes'],
        'worker_sha256': bound['worker_sha256'], 'compiler_sha256': receipt['compiler_sha256'],
        'flags_as_run': receipt['flags'], 'profiles': profiles,
        'source_inputs': receipt['source_inputs'], 'source_basis': source,
    }
    for leaf in ['program.o', 'metadata.json']:
        (E / (role + '-' + leaf + '.gz')).write_bytes(gzip.compress((N / role / 'frontend' / leaf).read_bytes(), mtime=0))
required = read(N / 'word-complements-prior-wins.json')['required_previous_individual_wins']
audit = []
for stage, data in stages.items():
    for run in data['runs']:
        misses = {peer: [row['case'] for row in run['results']
                         if row['case'] in required[peer] and row[key]['mech-experiment'] >= 1]
                  for peer, key in [('roc', 'paired_x_roc'), ('libdeflate', 'paired_x_libdeflate')]}
        audit.append({'stage': stage, 'role': run['role'], 'order': run['order'],
                      'previous_wins_missing': misses})
counter_comparisons=[]
for current, previous, study in [('scalar-pair-tail-probe','packed-eight-paired-probe','packed-eight-entry-study'),('scalar-pair-head-probe','packed-eight-head-probe','packed-eight-entry-study')]:
    old=read(N/previous/'instruction-counts/counts.json');new=read(N/current/'instruction-counts/counts.json')
    metrics=['instructions','branches','stack_loads','stack_stores'];cases={}
    for name in new['cases']:
        before={key:old['cases'][name]['counts'].get(key,0) for key in metrics};after={key:new['cases'][name]['counts'].get(key,0) for key in metrics}
        cases[name]={'before':before,'after':after,'delta':{key:after[key]-before[key] for key in metrics}}
    member=previous+'/instruction-counts/counts.json';prior=E.parent/study
    assert sha(N/previous/'instruction-counts/counts.json')==read(prior/'archive-files.json')['checks-and-builds.tar.gz'][member]['sha256']
    counter_comparisons.append({'current_role':current,'previous_role':previous,'previous_study':study,'previous_counts_member':member,'previous_counts_sha256':sha(N/previous/'instruction-counts/counts.json'),'current_counts_sha256':sha(N/current/'instruction-counts/counts.json'),'cases':cases,'scope':'Raw scorer aggregate work only, same eight-case policy; opcode choice or branch direction may differ even where these totals match. Not a latency claim.'})
result = {
    'promoted': False, 'qualified_selection_unchanged': True,
    'qualified': {'encoder_text_bytes': 63612, 'roc_wins': 81, 'libdeflate_wins': 62,
                  'worker_sha256': 'a2f692f524448d7b1c972abf5f1cc92ac412c1fcd1424ce4ade4b9bae526481c'},
    'source_basis_commit': source,
    'source_sha256': sha(P / 'program.mec'),
    'bytecode_sha256': published[roles[0]]['artifact_sha256']['program.mecb'],
    'roles': published, 'stages': stages, 'panel_audit': audit, 'full24':full24, 'qualification96':qualification96,
    'builds': read(N / 'scalar-pair-revisit-matched-builds/summary.json'),
    'native_tests': {'tests_per_mode':20,'modes':4,'packed_key_fixture_calls_per_mode':94208,'wide_item_fixture_calls_per_mode':16384,'paired_scalar_fixture_calls_per_mode':22528,'prior_winner_fixture_calls_per_mode':16384},
    'counter_roles': counter_roles, 'broad_loss_census':read(N/'eight-entry-loss-census-summary.json'), 'register_equivalence':read(N/'scalar-pair-register-equivalence.json'), 'historical_counter_comparisons':counter_comparisons,
    'limitations': [
        'The 21-case discovery and full24 screens do not establish qualification; both complete96-block orders and every prior named confidence requirement decide it.',
        'Every original observation remains; small slowdowns are allowed when the prior peer win survives.',
        'No new full81-case qualification was attempted while the paired candidate lost the existing natural8K C win in discovery. The current default is unchanged. Both original paired candidates and the register ablations remain available for repair.',
        'Diagnostic-entry checks do not establish ordinary managed-entry admission and recovery.',
        'Repository-wide unsafe audit remains blocked by the pre-existing missing archived pinned_allocator.rs.',
    ],
}
write(E / 'result.json', result)
shutil.copyfile(P / 'evidence/encoder-size-gap/admitted-input-span-study/host.json', E / 'host.json')
print('Preserved', len(selected), 'check/build files,', len(raw), 'runtime files,', len(roles), 'variants and all four orders.', flush=True)
