from pathlib import Path
from collections import Counter
import subprocess,re,json
lab=Path(__file__).resolve().parent
root=lab/'checked-root-phase/current-native-profile-complete'
node_sets=[];symbols=set()
for folder in sorted(p for p in root.iterdir() if p.is_dir()):
 graph=(folder/'sample.txt').read_text().split('Call graph:\n',1)[1].split('\nTotal number in stack',1)[0]
 nodes=[];stack=[]
 for line in graph.splitlines():
  m=re.match(r'^([ +!|:.\t]*)([0-9]+) (.+)$',line)
  if not m:continue
  depth,count,sym=len(m[1]),int(m[2]),m[3].split('  (in ',1)[0]
  while stack and nodes[stack[-1]]['depth']>=depth:stack.pop()
  parent=stack[-1] if stack else None
  node={'depth':depth,'count':count,'symbol':sym,'parent':parent,'children':0}
  if parent is not None:nodes[parent]['children']+=count
  nodes.append(node);stack.append(len(nodes)-1);symbols.add(sym)
 node_sets.append(nodes)
items=sorted(symbols);decoded=subprocess.check_output([str(lab/'checked-root-phase/current-native-profile/demangle')],input='\n'.join(items)+'\n',text=True).splitlines();assert len(items)==len(decoded)
names=dict(zip(items,decoded));totals=Counter();leaves=Counter();owners=Counter();trials=[]
for nodes in node_sets:
 counts=Counter();bad=[]
 for i,node in enumerate(nodes):
  exclusive=node['count']-node['children']
  if exclusive<0:bad.append(i);continue
  if not exclusive:continue
  path=[];at=i
  while at is not None:path.append(names[nodes[at]['symbol']]);at=nodes[at]['parent']
  leaf=path[0]
  if any(word in leaf for word in ['__ulock_wait','__psynch_cvwait','semaphore_wait','kevent','__workq_kernreturn','__semwait_signal','mach_msg','__psynch_mutexwait']):kind='idle_or_wait'
  elif any('cranelift_codegen::verifier' in f for f in path):kind='validation'
  elif any('cranelift_codegen::flowgraph' in f or 'cranelift_codegen::dominator_tree' in f or 'cranelift_codegen::dominator_tree2' in f for f in path):kind='cfg_and_dominance'
  elif any('cranelift_frontend::ssa' in f or 'cranelift_frontend::frontend' in f for f in path):kind='ssa_construction'
  elif any('regalloc2::' in f or 'cranelift_codegen::machinst' in f or 'cranelift_codegen::isa::aarch64' in f for f in path):kind='machine_emission_and_regalloc'
  elif any('cranelift_codegen::egraph' in f or 'cranelift_codegen::opts' in f or 'Context::optimize' in f for f in path):kind='backend_optimization'
  elif any('cfg_cleanup' in f for f in path):kind='native_cleanup_rewrites'
  elif any('checked_traversals' in f or 'checked_region_' in f for f in path):kind='checked_region_admission_and_preparation'
  elif any('compact::guards' in f for f in path):kind='native_guard_construction'
  elif any('compact::phase_function' in f for f in path):kind='phase_ir_construction'
  elif any('numeric_traversal' in f or 'traversal_facts' in f for f in path):kind='numeric_analysis'
  elif any('compact::emit::define_entry' in f for f in path):kind='root_ir_construction_and_other_passes'
  elif any('emit_compact_closed_object' in f for f in path):kind='other_native_planning_and_emission'
  else:kind='outside_native_or_teardown'
  counts[kind]+=exclusive;leaves[leaf]+=exclusive
  owner=next((f for f in path if 'mech_gpu::native_artifact' in f),'outside native')
  if kind!='idle_or_wait':owners[owner]+=exclusive
 assert not bad,bad
 totals.update(counts);trials.append(dict(counts))
active=sum(n for k,n in totals.items() if k!='idle_or_wait');result={'scope':'stack-derived exclusive sample classification; encode-through-exit under concurrent test-build load, not exclusive latency','active_samples':active,'categories':{k:{'samples':n,'fraction_of_nonwait_samples':n/active if k!='idle_or_wait' else None} for k,n in totals.most_common()},'per_trial':trials,'top_native_owners':owners.most_common(24),'top_leaf_symbols':leaves.most_common(30)}
(root/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['active_samples','categories','top_native_owners']},indent=2)[:10000])
