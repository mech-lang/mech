"""Sample only the native interval; verify unchanged artifacts, do not time a gain."""
from pathlib import Path
from hashlib import sha256
import json,os,subprocess,time
lab=Path(__file__).resolve().parent
root=lab/'checked-root-phase/current-native-profile-complete';root.mkdir(exist_ok=True)
base=json.loads((lab/'checked-root-phase/control-source-private-helpers/rebuild.json').read_text())
compiler=Path(json.loads((lab/'checked-root-phase/codebook-core-private-helpers/receipt.json').read_text())['command'][0])
assert sha256(compiler.read_bytes()).hexdigest()==base['compiler_sha256']
records=[]
for trial in range(3):
 folder=root/str(trial);folder.mkdir();command=[str(compiler),base['phases']['source_to_native']['command'][1],str(folder/'frontend'),'compact']
 with (folder/'compile.log').open('w') as log:
  child=subprocess.Popen(command,env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}|base['native_flags'],stdout=log,stderr=log)
  deadline=time.monotonic()+60
  while child.poll() is None and '"phase":"encode"' not in (folder/'compile.log').read_text():
   assert time.monotonic()<deadline
   time.sleep(.01)
  assert child.poll() is None,'Compiler ended before native sampling'
  with (folder/'sampler.log').open('w') as sample_log:
   sample=subprocess.run(['sample',str(child.pid),'3','1','-file',str(folder/'sample.txt')],stdout=sample_log,stderr=sample_log)
  result=child.wait()
 assert result==0 and (folder/'sample.txt').exists(),(trial,result,sample.returncode)
 assert 'Call graph:' in (folder/'sample.txt').read_text()
 actual={n:sha256((folder/'frontend'/n).read_bytes()).hexdigest() for n in ['program.o','metadata.json','program.mecb']}
 expected=dict(zip(actual,[base['object_sha256'],base['metadata_sha256'],base['bytecode_sha256']]))
 assert actual==expected
 records.append({'trial':trial,'pid':child.pid,'artifacts':actual,'exact_control':True,'sample_file':str(folder/'sample.txt'),'sampler_exit_code':sample.returncode})
 print('sample',trial,'exact control artifacts',flush=True)
(root/'result.json').write_text(json.dumps({'compiler_sha256':base['compiler_sha256'],'source_base':'c697f100f8','scope':'diagnostic encode-through-process-exit stack samples under concurrent test-build load; 3-second collector follows target exit to include complete native work and teardown; not a latency measurement','trials':records},indent=2)+'\n')
