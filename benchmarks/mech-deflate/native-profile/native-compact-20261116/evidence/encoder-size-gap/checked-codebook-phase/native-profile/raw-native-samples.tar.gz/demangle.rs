#![feature(rustc_private)]
extern crate rustc_demangle;
use std::io::{self, BufRead};
fn main() {
    for line in io::stdin().lock().lines() {
        let line = line.unwrap();
        println!("{:#}", rustc_demangle::demangle(&line));
    }
}
