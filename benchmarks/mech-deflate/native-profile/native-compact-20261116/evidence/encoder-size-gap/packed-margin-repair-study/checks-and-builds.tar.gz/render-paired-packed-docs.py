from pathlib import Path
import json
W=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP');P=W/'benchmarks/mech-deflate/native-profile/native-compact-20261116';E=P/'evidence/encoder-size-gap/paired-packed-accumulator-study';r=json.loads((E/'result.json').read_text());source=r['source_basis_commit'];build=r['builds'];q=r['qualification96'];n=Path(__file__).resolve().parent
old_floor=all(not peer['unsupported'] or (run['order']=='reverse' and name=='libdeflate' and peer['unsupported']==['prefix-natural-4096']) for run in q['named_win_audit'] for name,peer in run['peers'].items());assert old_floor
r['passes_existing_named_81_62_floor']=old_floor
(E/'result.json').write_text(json.dumps(r,indent=2)+'\n')
text='''# Paired packed accumulator study

**Keep this candidate for margin repair.** It retains every prior individual **81 Roc / 62 libdeflate win with confidence support in both full 96-block orders**. The new natural-4-KiB win is supported in forward but remains uncertain in reverse. The qualified default stays **63,612 B / 81 Roc / 62 C**; no qualified 63rd win is claimed.

The carried paired loop takes **1.50% / 1.59% less natural-4-KiB time** than its matching one-accumulator control in the two complete 21-case discovery orders. Both full 81-case/24-block screens win **81 Roc / 63 C**, preserving every previous named win. The stricter 96-block qualification then records:

| Full 81-case order | Roc point / precision wins | C point / precision wins | Natural 4 KiB / C | 90% paired interval, Mech time change vs C |
| --- | ---: | ---: | ---: | ---: |
| Forward96 | 81 / 81 | 63 / 63 | 0.984695× | −1.990% to −1.078% |
| Reverse96 | 81 / 81 | 62 / 62 | 1.000362× | −0.429% to +0.528% |

Reverse misses parity by **0.036%**. It loses no previously qualified case. This is a specific remaining margin problem, not a reason to discard the candidate. Every original observation, including the adverse reverse order and the initial inventory-replay error, is preserved.

'''
text+=f'Compiler source: [`{source[:10]}`](https://github.com/mech-lang/mech/commit/{source}). Enable `MECH_ORDERED_PACKED_COST_INDEX=1` and `MECH_ORDERED_PACKED_ACCUMULATORS=2`; `MECH_ORDERED_VECTOR_CARRY_LANES=1` selects the carried variant. The original 2,719-line Mech codec and canonical bytecode are unchanged. No LLVM dependency is added.\n\n'
text+='''The existing U16 best/absolute-stop guard admits the bounded key, with the original optimized vector loop on a miss. Two four-candidate groups update separate packed minima before advancing by eight. One optional group of four is evaluated before the paired prefix. Its reads are immutable and already admitted; packed ordinals preserve earliest original source order even when this tail is visited first. The existing scalar remainder still processes zero to three elements. All traversals, errors, source charges and finite accounting are preserved. No unsafe production code is added.

All three artifacts reproduce exactly for **23 older recipes**, including all seven preceding packed/profile variants. The two new workers pass **162 output/inflation/alias observations, six checked failures, twelve injected failures followed by twelve exact recoveries**, normal/checked identity and the **5,280 B** stack cap. Peak stack is **4,736 B**. Eighteen optimized tests pass with packing off, paired packing on, and paired packing with carry plus latch testing; each configuration includes **61,440 key-fixture calls** and **16,384 previous winner/item calls**. The direct fixture exercises the actual paired emitter with/without carry and header/latch testing, 0/4/8/16/20/24/28-element boundaries, wide costs, sentinel ties, cross-group/optional-tail ties and the 65,535 boundary.

## Discovery and executed work

Both candidates use the same declared eight-case profile policy as their matching one-accumulator controls. All prior wins present in all four complete 21-case/24-block orders survive. Times are Mech / peer, lower is faster.

| Variant | Encoder text | Natural 4 KiB / C, forward / reverse | Natural time / matching control |
| --- | ---: | ---: | ---: |
'''
for role in r['roles']:
 rows=[next(x for x in run['results'] if x['case']=='prefix-natural-4096') for run in r['stages']['paired']['runs'] if run['role']==role]
 ratios=[row['paired_x_libdeflate']['mech-experiment'] for row in rows];base=[row['paired_x_roc']['mech-experiment']/row['paired_x_roc']['mech-control'] for row in rows]
 text+=f"| `{role}` | {r['roles'][role]['text_bytes']:,} B | {ratios[0]:.6f}× / {ratios[1]:.6f}× | {base[0]:.6f}× / {base[1]:.6f}× |\n"
text+='''
Untimed raw-scorer counts on natural 4 KiB:

| Scorer | Instructions | Branches | Stack loads / stores |
| --- | ---: | ---: | ---: |
| One packed accumulator | 3,379,620 | 573,275 | 17,305 / 18,470 |
| Two packed accumulators | 3,359,267 | 556,013 | 17,310 / 18,475 |
| One accumulator, carried indices | 3,331,665 | 555,990 | 17,305 / 18,470 |
| Two accumulators, carried indices | 3,343,871 | 549,581 | 17,310 / 18,475 |

The carried paired version removes 6,409 branches while adding 12,206 instructions and five stack loads/stores. Its measured latency improves despite the larger instruction count. Separate accumulators and unrolling target dependency/branch costs; no hardware-counter attribution to either mechanism alone is claimed. Original baselines and the preceding layout repair are in the [packed-key study](../packed-cost-ordinal-study/README.md).

## Complete executable builds

Apple M1, macOS 15.6.1, arm64. Ten balanced serial fresh-process trials per actor include source compilation through final executable linking. Compilers and fixed support are prebuilt equally. Bootstrap and strip are separate. Every generated Mech object, complete metadata and canonical bytecode is hash checked.

| Actor | Encoder text | Source through final executable link | Stripped executable |
| --- | ---: | ---: | ---: |
'''
for actor,label,size,exe in [('mech-control-reference','Qualified histogram',63612,276072),('mech-paired-probe','Paired packed probe',63836,276072),('mech-paired-carry-probe','Paired packed carried probe',63852,276072),('roc','Roc',57696,191912),('libdeflate','libdeflate C',37080,155752)]:
 text+=f"| {label} | {size:,} B | {build['medians'][actor]['source_through_link']:.6f} s | {exe:,} B |\n"
x=build['paired_ratios']['mech-paired-carry-probe'];phases=build['phases']['mech-paired-carry-probe'];text+=f"\nThe carried probe is **{63852/57696:.3f}× Roc / {63852/37080:.3f}× C encoder text**. Paired complete-build ratios are **{x['roc']:.6f}× Roc / {x['libdeflate']:.6f}× C**, and **{x['mech-control-reference']:.6f}×** qualified control. No compile-time gain is established.\n\n"
text+='Its phase medians are '+', '.join(f'{key} **{phases[key]*1000:.3f} ms**' for key in ['parse','frontend','artifact','encode','native'])+f", final executable link **{build['medians']['mech-paired-carry-probe']['link']*1000:.3f} ms**. Independent phase medians do not sum exactly to the overall median. The minimal compiler release rebuild took **228.069 s**; it is excluded from codec-build timing and is not a clean-bootstrap comparison.\n\n"
text+='''## Replay and qualification scope

The qualification uses the existing v3 90% coverage and 8,000-resample method, with a stricter target: all original 81 Roc / 62 C named wins plus natural 4 KiB, with C floor 63. Every required original case remains precision-supported in each order; only reverse natural 4 KiB is unsupported. Small slowdowns remain allowed when prior peer wins survive. The stricter result is not promoted.

The initial replay found that temporary inventories call the prefix file `prefix`, while the frozen inventory names it by its SHA256. It stopped after both timing runs had completed. The correction verifies all 81 input/prefix/expected files byte-identical, including sizes, raw bytes and capacities, preserves original runtime pins, and reconciles only the canonical replay inventory digest. This is the existing `full-timing.py` reconciliation method. No clock was rerun or original data changed. Both the failed replay log and corrected replay/source are archived.

`checks-and-builds.tar.gz` contains compiler/test sources and commands, 23 exact older recipe replays, worker/stack/recovery checks, full24/96 plans, inventory reconciliation and full build observations. `raw-runtime.tar.gz` contains all four discovery orders, both full24 orders and both full96 orders. Every member is hashed in `archive-files.json`. Both portable recipes reproduce all three artifacts exactly in normal and checked emission, recorded in `portable-replays.json`.

```sh
python3 verify.py
python3 reproduce.py /path/to/compile_profile /tmp/paired-replay --role paired-key-carry-probe-profiled
```

The verifier checks source/object/worker bindings, exact prior replays, tests, errors, stack, recovery, all raw discovery/full24/full96 calls, actor cleanup, inventory reconciliation, both confidence reports and complete builds. Its success means the study is reproduced, including the failed new-win gate; it does not claim 63 qualified C wins. The full GPU suite is not claimed. The repository unsafe audit remains blocked by the pre-existing missing archived `pinned_allocator.rs`.

Next, retain the paired carried loop and repair its margin by (1) peeling the optional four-element group at the beginning, so the main loop can use the existing end bound, and (2) widening the packed ordinal before subtracting its bias, so item reconstruction can fold the offset. Test both changes separately and together against this exact candidate. Neither change is implemented in this checkpoint. Preserve both qualification orders and every named old win.
'''
(E/'README.md').write_text(text)
new='''Latest compiler source **`31910aff6`** adds two independent packed accumulators over eight candidates. The **63,852 B** carried probe takes **1.50% / 1.59% less natural-4-KiB time** than its matching one-accumulator control. Both full81/24-block orders win **81 Roc / 63 C**. Full96 then retains every original **81 Roc / 62 C** named win with confidence support, but natural 4 KiB is **0.984695× C forward / 1.000362× C reverse**. Its reverse 90% interval spans parity (−0.429% to +0.528%). **Keep the candidate and repair this one margin; no qualified 63rd win is claimed.** The smaller qualified 63,612 B histogram remains selected.

Complete carried-probe build is **2.215453 s**, paired **0.742850× Roc / 4.606302× C**; encoder text is **1.107× Roc / 1.722× C**, stripped executable **276,072 B** and peak stack **4,736 B**. All prior named wins, output/error/recovery/stack gates, three configurations of eighteen optimized tests, 23 exact older recipes and both portable normal/checked emissions pass. No compile-time gain is shown. [Source, all eight runtime orders, both confidence reports, counts, complete builds and replay](evidence/encoder-size-gap/paired-packed-accumulator-study/README.md).

Next, test optional-head peeling and a widened packed ordinal separately and together. This targets redundant loop-bound setup and item-index reconstruction while retaining this exact paired candidate. These repairs are not yet implemented.

'''
p=P/'REVIEW.md';old=p.read_text().replace('Latest compiler source **`f3d74d948`**','Preceding compiler source **`f3d74d948`**',1);p.write_text(new+'Preceding packed-key checkpoint:\n\n'+old)
p=P/'CURRENT.md';old=p.read_text();a=old.index('Latest complete-build cohort on the **Apple M1**');b=old.index('\n\n',a);old=old[:a]+'''Latest complete-build cohort on the **Apple M1** reproduces the qualified encoder exactly and measures **2.209647 s Mech, 2.985657 s Roc and 0.481600 s C**, ten balanced fresh-process trials including final executable linking with equal prebuilt compilers/support. Paired qualified-control ratios are **0.740874× Roc / 4.591871× C**. Stripped executables remain 276,072 B / 191,912 B / 155,752 B. Bootstrap and strip are separate; no compilation-time gain is established. [Current build evidence](evidence/encoder-size-gap/paired-packed-accumulator-study/README.md).'''+old[b:];old=old.replace('## Current bounded packed-key experiments','## Current paired packed-accumulator experiments\n\n'+new+'## Preceding bounded packed-key experiments',1).replace('Latest compiler source **`f3d74d948`**','Preceding compiler source **`f3d74d948`**',1);p.write_text(old)
p=P/'scorecard.json';s=json.loads(p.read_text());s['paired_packed_accumulator_experiment']={'source_commit':source,'compiler_sha256':r['roles']['paired-key-carry-probe-profiled']['compiler_sha256'],'evidence':'evidence/encoder-size-gap/paired-packed-accumulator-study/README.md','promoted':False,'qualified_selection_unchanged':True,'decision':'Retain candidate for one-case margin repair; all existing individual win floors pass','candidate_text_bytes':63852,'peak_stack_bytes':4736,'full24_scores':{'forward':{'roc':81,'libdeflate':63},'reverse':{'roc':81,'libdeflate':63}},'full96_scores':{'forward':{'roc':81,'libdeflate':63},'reverse':{'roc':81,'libdeflate':62}},'all_original_named_wins_precision_supported_both_orders':True,'new63rd_qualified':False,'natural4k_by_order':{run['order']:run['peers']['libdeflate']['cases']['prefix-natural-4096'] for run in q['named_win_audit']},'complete_build':build,'native_tests':r['native_tests'],'disabled_replay_recipes':23,'portable_recipe_replays':2,'next_target':'Retain paired carried loop; test optional-head peeling and widened packed ordinal separately/together. No abandonment over the reverse0.036% miss.'};s['current_matched_build']='paired_packed_accumulator_experiment.complete_build';s['review'].update(compiler_source_commit=source,compiler_sha256=r['roles']['paired-key-carry-probe-profiled']['compiler_sha256'],latest_deployment_evidence=s['paired_packed_accumulator_experiment']['evidence']);s['next_runtime_target']={'case':'prefix-natural-4096','scope':'Full81-case96-block paired carried loop; old81Roc/62C all precision-supported. Only the new reverse natural4K win remains unsupported.','natural4k_by_order':s['paired_packed_accumulator_experiment']['natural4k_by_order'],'primary_investigation':s['paired_packed_accumulator_experiment']['next_target'],'evidence':s['paired_packed_accumulator_experiment']['evidence']};s['packed_cost_ordinal_experiment']['next_target']='Paired accumulators are implemented; see paired_packed_accumulator_experiment.';p.write_text(json.dumps(s,indent=2)+'\n');print('Study, current status, review and scorecard updated; qualified high-water mark remains62.')
