from pathlib import Path
from hashlib import sha256
import subprocess,json,sys,time,os
N=Path(__file__).resolve().parent;I=N.parent;Q=I.parent
role='word-current-complements-profiled';bound=N/role/'bound';control=I/'collector-read-lifetimes/placement/immutable-profiled/bound';receipt=json.loads((bound/'runtime.json').read_text());assert sha256((bound/'mech-worker').read_bytes()).hexdigest()==receipt['worker_sha256'];recovery=json.loads((N/role/'promotion-recoveries/result.json').read_text());assert recovery['exact_recoveries']==12 and recovery['benchmark_worker_sha256']==receipt['worker_sha256']
plan={'role':role,'worker_sha256':receipt['worker_sha256'],'control_worker_sha256':sha256((control/'mech-worker').read_bytes()).hexdigest(),'orders':['forward','reverse'],'cases':81,'blocks_per_case':24,'load_before':os.getloadavg(),'started_unix':time.time()};(N/'word-complements-full-plan.json').write_text(json.dumps(plan,indent=2)+'\n');runs=[]
for order in plan['orders']:
 label='word-complements-full-20261119-'+order;assert not (Q/label).exists();cmd=[sys.executable,'-u',str(Q/'compare-library.py'),label,str(control),str(bound)]+(['reverse'] if order=='reverse' else []);subprocess.run(cmd,check=True);summary=json.loads((Q/label/'summary.json').read_text());assert len(summary)==81;runs.append({'role':role,'order':order,'run':str(Q/label),'summary_sha256':sha256((Q/label/'summary.json').read_bytes()).hexdigest(),'results':summary});(N/'word-complements-full-results.json').write_text(json.dumps({'plan':plan,'runs':runs,'complete':len(runs)==2},indent=2)+'\n')
