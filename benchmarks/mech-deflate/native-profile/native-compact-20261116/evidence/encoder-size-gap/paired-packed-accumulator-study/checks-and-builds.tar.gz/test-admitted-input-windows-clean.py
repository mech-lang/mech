from pathlib import Path
import os,json,subprocess,time,hashlib,datetime
w=Path.cwd();n=Path(__file__).resolve().parent;out=n/'admitted-input-window-clean-repository-tests';out.mkdir(exist_ok=True)
plan=json.loads((n/'admitted-index-range-repository-tests/plan.json').read_text());files=['hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/admitted_spans/induction.rs', 'hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/admitted_spans/mod.rs', 'hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/admitted_spans/tests/mod.rs', 'hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/admitted_spans/tests/fixture.rs', 'hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/bounded_byte_histogram/mod.rs', 'hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/mod.rs', 'hosts/gpu/src/native_artifact/program/compact/phase_function.rs', 'hosts/gpu/src/native_artifact/program/compact/phases.rs']
files += ['hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/admitted_spans/word_length.rs', 'hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/admitted_spans/windows.rs', 'hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/admitted_spans/tests/window_tests.rs']
pins={name:hashlib.sha256((w/name).read_bytes()).hexdigest() for name in files};plan['source_sha256']=pins;plan['start_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
plan['command'][plan['command'].index('admitted_lengths')]='admitted_spans'
(plan_path:=out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
start=time.monotonic()
with (out/'test.log').open('w') as f:
 run=subprocess.run(plan['command'],cwd=w,env={**os.environ,**plan['environment']},stdout=f,stderr=subprocess.STDOUT)

 if run.returncode==0:
  ranges=list(plan['command']);ranges[ranges.index('admitted_spans')]='bounded_byte_histogram';run=subprocess.run(ranges,cwd=w,env={**os.environ,**plan['environment']},stdout=f,stderr=subprocess.STDOUT)
assert pins=={name:hashlib.sha256((w/name).read_bytes()).hexdigest() for name in files},'Rust sources changed during build'
result={'exit_code':run.returncode,'seconds':time.monotonic()-start,'source_sha256':pins,'test_log_sha256':hashlib.sha256((out/'test.log').read_bytes()).hexdigest()};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(run.returncode)
