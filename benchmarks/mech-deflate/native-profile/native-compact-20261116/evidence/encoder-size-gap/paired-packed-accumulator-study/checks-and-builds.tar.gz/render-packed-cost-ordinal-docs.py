from pathlib import Path
import json
W=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP');P=W/'benchmarks/mech-deflate/native-profile/native-compact-20261116';E=P/'evidence/encoder-size-gap/packed-cost-ordinal-study';r=json.loads((E/'result.json').read_text());source=r['source_basis_commit'];build=r['builds'];n=Path(__file__).resolve().parent
roles=list(r['roles']);observations={}
for stage in r['stages'].values():
 for run in stage['runs']:
  observations.setdefault(run['role'],{})[run['order']]={row['case']:row for row in run['results']}
assert all(not any(a['previous_wins_missing'].values()) for a in r['panel_audit'])
text='''# Bounded packed vector cost and ordinal study

The compiler now integrates the packed-key prototype under explicit unsigned bounds. **The qualified selection remains 63,612 B / 81 Roc / 62 libdeflate. No new C win or compile-time gain is established.** Every prior peer win observed in all fourteen discovery orders survives; these panels do not establish a new full score or confidence qualification.

The original packed probe takes **0.89% / 0.88% less time on natural 4 KiB** than its matching control, reaching **1.005062× / 1.008491× libdeflate**. Carrying the packed indices removes more instructions but does not improve this latency consistently. Its distribution-change slowdown is repaired by a broader profile: the carried version takes **0.39% / 0.57% less time** than its matching revised-profile control. Both stages, all controls and every adverse observation remain included.

'''
text+=f'Compiler source: [`{source[:10]}`](https://github.com/mech-lang/mech/commit/{source}). `MECH_ORDERED_PACKED_COST_INDEX=1` enables the experiment; `MECH_ORDERED_VECTOR_CARRY_LANES=1` adds carried indices. The original 2,719-line Mech codec and canonical bytecode are unchanged. No LLVM dependency is added.\n\n'
text+='''The packed key is `(saturating_u16(cost) << 16) | (index + 1)`. The incoming best has ordinal zero, preserving the old choice on equal cost. The earliest original index breaks candidate ties. Packing requires `best <= 65535` and absolute `stop <= 65535`; a same-plan static fact may discharge the stop bound. Large candidate costs cannot beat an admitted best. A guard miss retains the original optimized vector loop. Expressions that use the index in their cost, pointer-carry recipes and unsupported targets keep that loop. Scalar remainders, errors and exact traversal accounting are unchanged.

The shared vector-loop emitter preserves construction order for disabled and legacy settings: **all three artifacts match exactly for sixteen older recipes**, including index-only and mapped-item options. This change adds no unsafe production code.

## All discovery results

Times are Mech / peer; lower is faster. Each cell contains forward / reverse results from a complete 21-case, 24-balanced-block order. The original four variants compare against their matching old word/probe controls. The revised-profile control compares against the old probe; both revised packed variants compare against that revised control. See `result.json` for every case, all control ratios, profiles and artifact/source pins.

| Variant | Encoder text | Natural 4 KiB / C | Distribution time / held control |
| --- | ---: | ---: | ---: |
'''
for role in roles:
 orders=observations[role];nat=[orders[o]['prefix-natural-4096']['paired_x_libdeflate']['mech-experiment'] for o in ['forward','reverse']];dist=[orders[o]['16384-distribution-change']['paired_x_roc']['mech-experiment']/orders[o]['16384-distribution-change']['paired_x_roc']['mech-control'] for o in ['forward','reverse']]
 text+=f"| `{role}` | {r['roles'][role]['text_bytes']:,} B | {nat[0]:.6f}× / {nat[1]:.6f}× | {dist[0]:.6f}× / {dist[1]:.6f}× |\n"
text+='''
Untimed counters cover the original six cases and an extended eight-case cohort adding distribution change and overlap. In the raw probe scorer, natural 4 KiB falls from **3,414,780 to 3,379,620 instructions**, and to **3,331,665** with carried indices. Branches change from **569,130 to 573,275**, or **555,990** with carry. Stack loads/stores remain **17,305 / 18,470**. Packed reductions use one horizontal minimum; guard misses use the old two. No scorer vector path executes on distribution change: its instruction counts are identical. Adding that case to the block-layout profile recovers the observed latency penalty; this is evidence for a layout effect, not a hardware-counter attribution.

## Complete executable builds

Apple M1, macOS 15.6.1, arm64. Ten balanced serial fresh-process trials per actor include source compilation and final executable linking. Compilers and fixed support are prebuilt equally. Bootstrap and strip are separate. Every emitted Mech object, complete metadata and canonical bytecode is hash checked.

| Actor | Encoder text | Source through final executable link | Stripped executable |
| --- | ---: | ---: | ---: |
'''
for actor,label,size,exe in [('mech-control-reference','Qualified histogram',63612,276072),('mech-packed-probe','Original-profile packed probe',63660,276072),('mech-packed-extended-carry','Revised-profile carried probe',63660,276072),('roc','Roc',57696,191912),('libdeflate','libdeflate C',37080,155752)]:
 text+=f"| {label} | {size:,} B | {build['medians'][actor]['source_through_link']:.6f} s | {exe:,} B |\n"
ratios=build['paired_ratios']['mech-packed-extended-carry'];phases=build['phases']['mech-packed-extended-carry'];text+=f"\nRepaired carried-probe paired build ratios: **{ratios['roc']:.6f}× Roc / {ratios['libdeflate']:.6f}× C**, and **{ratios['mech-control-reference']:.6f}×** qualified control. No compile-time gain is established. Its encoder text is **{63660/57696:.3f}× Roc / {63660/37080:.3f}× C**.\n\n"
text+='Phase medians for that recipe: '+', '.join(f'{key} **{phases[key]*1000:.3f} ms**' for key in ['parse','frontend','artifact','encode','native'])+f", final executable link **{build['medians']['mech-packed-extended-carry']['link']*1000:.3f} ms**. Independently computed medians do not sum exactly to the overall median. The compiler release rebuild itself took **228.247 s**; it is excluded from codec-build timing and is not a clean-bootstrap comparison.\n\n"
text+='''## Validation and replay

- Eighteen optimized ordered-reduction tests pass in three configurations: packing disabled, enabled, and enabled with lane carry plus latch testing. Each configuration includes **28,672 packed-key native calls** and **16,384 existing winner/item calls**. The key fixture covers wide unsigned costs, best/stop bounds, ties, high indices, zero groups, unaligned guarded storage, carried lanes and the optimized fallback. Composition tests cover source remainders, unsigned wrapping, global ties, denial, publication and retry.
- All seven linked workers pass 162 output/inflation/alias observations and six checked failures. Each passes twelve injected failures followed by twelve exact recoveries. Peak stack is **4,736 B**, below the 5,280 B cap. Normal/checked object, full metadata and bytecode match exactly.
- All seven portable recipes reproduce exactly in normal and checked emission with relocated profiles. The full GPU suite is not claimed. The repository unsafe audit remains blocked by the pre-existing absent `benchmarks/mech-deflate/comparison/rust/src/pinned_allocator.rs`; the new fixture has an exact allowlist entry in the publication commit.

```sh
python3 verify.py
python3 reproduce.py /path/to/compile_profile /tmp/packed-replay --role packed-extended-carry-probe-profiled
```

Build the minimal `compile_profile` from the pinned compiler source using the command/environment and complete source overlay in `checks-and-builds.tar.gz`, under `packed-vector-key-compiler/plan.json` and `source-inputs/`. Reproduction also works from the PR head, whose follow-up allowlist metadata does not change emitted code. `portable-replays.json` records all fourteen exact source emissions. `archive-files.json` hashes every member of both archives; the verifier streams hardlink targets, checks source pins with Git, rederives timings and instruction totals, and checks tests, errors, stack, recoveries and complete builds.

The original qualified histogram remains available with its complete forward96 / pooled reverse288 confidence evidence. No prior result is discarded.

Next: test two independent packed accumulators over eight candidates, retaining the ordinary vector fallback and exact tail handling. This targets the packed loop's serial key/minimum dependency and branch count; it is not implemented or claimed as a gain in this study. Keep the original-profile probe and the repaired broader-profile version as separate controls, and retain every existing individual peer win before promotion.
'''
(E/'README.md').write_text(text)
new='''Latest compiler source **`f3d74d948`** integrates bounded packed cost/ordinal keys with the original optimized vector fallback. The packed probe takes **0.89% / 0.88% less natural-4-KiB time** than its matching control, reaching **1.005062× / 1.008491× libdeflate**. No 63rd win is established. Carrying indices removes more instructions; a broader profile repairs its distribution-change slowdown to **0.39% / 0.57% less time** than its matching revised-profile control. All prior peer wins observed in fourteen complete 21-case orders survive; the qualified **63,612 B / 81 Roc / 62 C** recipe remains selected.

The repaired probe is **63,660 B**, **1.103× Roc / 1.717× C encoder text**, with **4,736 B** peak stack. Its complete executable build is **2.221298 s**, paired **0.743629× Roc / 4.605955× C**; the same-cohort qualified build is **2.218823 s**. No compile-time gain is shown. Eighteen optimized tests pass in all three feature configurations; sixteen old recipes and all seven portable normal/checked emissions reproduce exactly. All seven workers pass output/error/stack/recovery gates. [Source, all fourteen raw orders, counts, build profiles, verifier and reproduction](evidence/encoder-size-gap/packed-cost-ordinal-study/README.md).

Next, test two independent packed accumulators over eight candidates to reduce the key/minimum dependency and loop branches. Preserve the existing vector fallback, exact tails, all named peer wins and every adverse observation. This is the next experiment, not an implemented result.

'''
p=P/'REVIEW.md';old=p.read_text().replace('Latest source **`46dc3230f`**','Preceding source **`46dc3230f`**',1);p.write_text(new+'Preceding conditional-winner checkpoint:\n\n'+old)
p=P/'CURRENT.md';old=p.read_text();old=old.replace('Latest complete-build cohort on the **Apple M1** reproduces the qualified encoder exactly and measures **2.212275 s Mech, 2.990601 s Roc and 0.481984 s C**, fourteen balanced fresh-process trials including final executable linking and equal prebuilt compilers/support. Paired qualified-control ratios are **0.740639× Roc / 4.587332× C**. Stripped executables remain 276,072 B / 191,912 B / 155,752 B. Bootstrap and strip are separate; no compilation-time gain is established. [Current build evidence](evidence/encoder-size-gap/conditional-winner-item-study/README.md).','Latest complete-build cohort on the **Apple M1** reproduces the qualified encoder exactly and measures **2.218823 s Mech, 2.985871 s Roc and 0.482094 s C**, ten balanced fresh-process trials including final executable linking and equal prebuilt compilers/support. Paired qualified-control ratios are **0.742459× Roc / 4.599063× C**. Stripped executables remain 276,072 B / 191,912 B / 155,752 B. Bootstrap and strip are separate; no compilation-time gain is established. [Current build evidence](evidence/encoder-size-gap/packed-cost-ordinal-study/README.md).')
old=old.replace('## Current conditional winner experiments','## Current bounded packed-key experiments\n\n'+new+'## Preceding conditional winner experiments',1).replace('Latest source **`46dc3230f`**','Preceding source **`46dc3230f`**',1);p.write_text(old)
p=P/'scorecard.json';s=json.loads(p.read_text());s['packed_cost_ordinal_experiment']={'source_commit':source,'compiler_sha256':r['roles'][roles[0]]['compiler_sha256'],'evidence':'evidence/encoder-size-gap/packed-cost-ordinal-study/README.md','promoted':False,'qualified_selection_unchanged':True,'roles':{k:{'encoder_text_bytes':v['text_bytes'],'artifact_sha256':v['artifact_sha256'],'worker_sha256':v['worker_sha256']} for k,v in r['roles'].items()},'peak_stack_bytes':4736,'discovery':{'orders':14,'cases_per_order':21,'balanced_blocks_per_case':24,'all_observed_previous_wins_preserved':True,'new_C_win':False,'full_score_not_established':True},'complete_build':build,'native_tests':r['native_tests'],'disabled_replay_recipes':16,'portable_recipe_replays':7,'next_target':'Two independent packed accumulators over eight candidates, retaining original vector fallback and exact tail handling; not implemented in this study.'};s['current_matched_build']='packed_cost_ordinal_experiment.complete_build';s['review'].update(compiler_source_commit=source,compiler_sha256=r['roles'][roles[0]]['compiler_sha256'],latest_deployment_evidence=s['packed_cost_ordinal_experiment']['evidence']);s['next_runtime_target']={'case':'prefix-natural-4096','paired_mech_c':[1.0050615782139611,1.0084908378964916],'scope':'Original-profile packed probe, 21-case/24-block discovery only; no qualified new win. Use the exact ratios in linked evidence.','primary_investigation':s['packed_cost_ordinal_experiment']['next_target'],'evidence':s['packed_cost_ordinal_experiment']['evidence']};s['runtime_high_water']['current_qualified_llvm_free_encoder_bytes']=63612;s['conditional_winner_item_experiment']['next_target']='Packed prototype is now integrated; see packed_cost_ordinal_experiment.';p.write_text(json.dumps(s,indent=2)+'\n')
# Record the actual two-order values rather than rounded presentation numbers.
s['next_runtime_target']['paired_mech_c']=[observations['packed-key-probe-profiled'][o]['prefix-natural-4096']['paired_x_libdeflate']['mech-experiment'] for o in ['forward','reverse']];p.write_text(json.dumps(s,indent=2)+'\n')
print('README, CURRENT, REVIEW and scorecard updated.')
