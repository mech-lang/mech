from pathlib import Path
import json,subprocess,os,time
from hashlib import sha256
n=Path(__file__).resolve().parent;w=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP');plan=json.loads((n/'paired-packed-key-repository-tests/plan.json').read_text());out=n/'paired-packed-key-enabled-tests';out.mkdir();rows=[]
for label,flags in [('paired',{'MECH_ORDERED_PACKED_COST_INDEX':'1','MECH_ORDERED_PACKED_ACCUMULATORS':'2'}),('paired-carry-latch',{'MECH_ORDERED_PACKED_COST_INDEX':'1','MECH_ORDERED_PACKED_ACCUMULATORS':'2','MECH_ORDERED_VECTOR_CARRY_LANES':'1','MECH_ORDERED_VECTOR_LATCH_TEST':'1'})]:
 start=time.monotonic()
 with (out/(label+'.log')).open('w') as log:r=subprocess.run(plan['command'],cwd=w,env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}|plan['environment']|flags,stdout=log,stderr=log)
 row={'label':label,'flags':flags,'command':plan['command'],'seconds':time.monotonic()-start,'exit_code':r.returncode,'log_sha256':sha256((out/(label+'.log')).read_bytes()).hexdigest()};rows.append(row);(out/'result.json').write_text(json.dumps({'source_sha256':plan['source_sha256'],'runs':rows,'complete':len(rows)==2},indent=2)+'\n');print(label,r.returncode,row['seconds'],flush=True);assert r.returncode==0,(out/(label+'.log')).read_text()[-6000:]
