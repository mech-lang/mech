"""Full 96-block qualification: all named prior wins plus natural4K, both orders."""
from pathlib import Path
from hashlib import sha256
import gzip,json,math,os,subprocess,sys
N=Path(__file__).resolve().parent;Q=N.parent.parent
W=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP');P=W/'benchmarks/mech-deflate/native-profile/native-compact-20261116'
sys.path.insert(0,str(P))
import qualification_timings as timing
from qualification_records import ACTORS,MECH,PEERS,CANDIDATE,Evidence,Findings,load_fixtures
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
write=lambda p,v:Path(p).write_text(json.dumps(v,indent=2)+'\n')
ref=lambda p:{'path':str(Path(p).relative_to(Q)),'sha256':sha(p)}
role=sys.argv[1];out=N/('paired-key-qualified96-'+role);plan=read(out/'plan.json');policy=read(out/'policy.json');identities=plan['identities'];required=plan['required_previous_wins']
for name in ['compiler_build','timer','controller','policy','as_run_fixture_inventory','environment','contract']:
 assert sha(Q/plan[name]['path'])==plan[name]['sha256'],name
findings=Findings();fixtures=load_fixtures(Evidence(P,findings),policy);assert len(fixtures)==81 and not findings.rejected and not findings.unresolved
inventory=read(Q/'fixtures.json');assert [row['name'] for row in inventory]==list(fixtures)
content={}
for row in inventory:
 frozen=fixtures[row['name']]
 for field in ['input_sha256','expected_sha256','input_bytes','prefix_bytes','raw_bytes','capacity']:
  assert row[field]==frozen[field],(row['name'],field)
 content[row['name']]={field:sha(row[field]) for field in ['input','prefix','expected']}
 assert content[row['name']]=={field:sha(P/frozen[field]) for field in ['input','prefix','expected']}
write(out/'inventory-reconciliation.json',{'as_run_inventory_sha256':sha(Q/'fixtures.json'),'canonical_inventory_sha256':policy['fixture_inventory_sha256'],'content':content,'scope':'The temporary prefix filename is prefix; the canonical inventory uses its SHA256 as the filename. Every input, prefix and expected file is verified byte-identical with the same sizes, raw bytes and capacity. Original runtime pins are preserved; only canonical replay pins replace the inventory digest, following the existing full-timing.py reconciliation.'})
# All clocks are complete before raw-data replay or bootstrap computation.
print("All runtime clocks complete; replaying output, cleanup, pins and confidence bounds.",flush=True)
evidence=Evidence(Q,findings);runs=[];receipts=[];named=[]
canonical=out/'canonical-pins';canonical.mkdir(exist_ok=True)
for run in plan['runs']:
 folder=Q/run['id'];record=run|{'pins':ref(folder/'pins.json'),'summary':ref(folder/'summary.json'),'complete':ref(folder/'complete.json'),'fixture_inventory':ref(Q/'fixtures.json'),'observations':{f.parent.name:ref(f) for f in sorted(folder.glob('*/observations.json.gz'))},'cleanup':{actor:ref(folder/(actor+'.stderr')) for actor in ACTORS}}
 original=read(folder/'pins.json');reconciled=original|{'input_inventory_sha256':policy['fixture_inventory_sha256']};write(canonical/(run['id']+'.json'),reconciled);record.update(original_pins=record['pins'],pins=ref(canonical/(run['id']+'.json')),inventory_reconciliation=ref(out/'inventory-reconciliation.json'))
 actual=timing.runtime_run(record,fixtures,evidence,identities,policy,run);assert actual is not None;runs.append(actual);receipts.append(record)
 audit={}
 for peer in PEERS:
  cases={}
  for index,(name,ratios) in enumerate(actual['ratios'].items()):
   if name not in required[peer]:continue
   parts=timing.paired(actual['cases'][name],CANDIDATE,peer);largest=max(map(max,parts))
   interval=timing.interval(parts,index,policy) if largest>=0 else {'estimate':timing.estimate(parts),'lower':math.exp(min(map(min,parts)))-1,'upper':math.exp(largest)-1,'bound_method':'Every individual balanced block wins; enclosing observed block bounds, matching the v3 precision shortcut.'}
   cases[name]={'paired_x':ratios[peer][CANDIDATE],'interval':interval,'supported':ratios[peer][CANDIDATE]<1 and interval['upper']<0}
  assert set(cases)==set(required[peer]);audit[peer]={'cases':cases,'unsupported':[name for name,row in cases.items() if not row['supported']]}
 named.append({'id':run['id'],'order':run['order'],'peers':audit})
report=timing.decide_runtime(runs,[],policy,fixtures,findings);passed=not findings.rejected and not findings.unresolved and all(not peer['unsupported'] for run in named for peer in run['peers'].values())
result={'passed':passed,'complete':True,'plan_sha256':sha(out/'plan.json'),'receipts':receipts,'runtime_report':report,'named_win_audit':named,'rejected':findings.rejected,'unresolved':findings.unresolved,'qualified_selection_automatically_changed':False};write(out/'result.json',result)
print(json.dumps({'passed':passed,'runs':report['runs'],'named_unsupported':{run['order']:{peer:row['unsupported'] for peer,row in run['peers'].items()} for run in named},'rejected':findings.rejected,'unresolved':findings.unresolved},indent=2),flush=True)
