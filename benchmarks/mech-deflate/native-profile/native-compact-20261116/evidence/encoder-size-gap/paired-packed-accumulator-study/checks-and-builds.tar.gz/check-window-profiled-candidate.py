from pathlib import Path
from hashlib import sha256
import json,os,subprocess,sys
n=Path(__file__).resolve().parent;role=sys.argv[1];r=json.loads((n/role/'receipt.json').read_text());out=n/role/'checked-emission';out.mkdir();cmd=[r['compile'][0],r['compile'][1],str(out/'frontend'),'compact'];flags=r['flags']|{'MECH_COMPACT_PAIR_REGISTER_SPILLS':'checked'}
with (out/'compile.log').open('w') as log:subprocess.run(cmd,env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}|flags,stdout=log,stderr=log,check=True)
art={name:sha256((out/'frontend'/name).read_bytes()).hexdigest() for name in r['artifacts']};assert art==r['artifacts'];(out/'result.json').write_text(json.dumps({'command':cmd,'artifacts':art,'normal_checked_identical':True},indent=2)+'\n')
with (n/(role+'-recoveries.log')).open('w') as log:subprocess.run(['python3',str(n/'recover-vector-word-candidate.py'),role],stdout=log,stderr=log,check=True)
print(role,'checked artifacts exact and twelve failure/recovery pairs pass',flush=True)
