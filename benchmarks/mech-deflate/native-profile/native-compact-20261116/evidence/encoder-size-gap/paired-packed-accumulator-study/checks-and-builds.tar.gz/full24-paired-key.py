from pathlib import Path
from hashlib import sha256
import json,os,sys
N=Path(__file__).resolve().parent;Q=N.parent.parent;timer=Q/'compare-library.py';role=sys.argv[1];control=N/'bounded-histogram-word/bound';candidate=N/role/'bound';out=N/('paired-key-full24-'+role);out.mkdir();read=lambda p:json.loads(p.read_text());sha=lambda p:sha256(p.read_bytes()).hexdigest();plan={'cases':81,'orders':['forward','reverse'],'blocks_per_case':24,'timer_sha256':sha(timer),'driver_sha256':sha(Path(__file__)),'control_worker_sha256':sha(control/'mech-worker'),'candidate_worker_sha256':sha(candidate/'mech-worker'),'load_before':os.getloadavg(),'scope':'Full 81-case point screen for the paired packed scorer. Promotion requires all 81 Roc wins and every original named C win plus natural4K in both 96-block confidence-qualified orders. This 24-block screen alone establishes no new qualified score.'};(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');runs=[]
for order in plan['orders']:
 label='paired-key-full24-'+role+'-'+order;sys.argv=[str(timer),label,str(control),str(candidate)]+(['reverse'] if order=='reverse' else []);exec(compile(timer.read_text(),str(timer),'exec'),{'__file__':str(timer),'__name__':'__main__'});rows=read(Q/label/'summary.json');assert len(rows)==81
 report={}
 for key,peer in [('paired_x_roc','roc'),('paired_x_libdeflate','libdeflate')]:
  report[peer]={'wins':sum(r[key]['mech-experiment']<1 for r in rows),'control_wins':sum(r[key]['mech-control']<1 for r in rows),'lost_cases':[r['case'] for r in rows if r[key]['mech-control']<1<=r[key]['mech-experiment']]}
 required=read(N/'word-complements-prior-wins.json')['required_previous_individual_wins']
 for key,peer in [('paired_x_roc','roc'),('paired_x_libdeflate','libdeflate')]:report[peer]['lost_previous_named_wins']=[r['case'] for r in rows if r['case'] in required[peer] and r[key]['mech-experiment']>=1]
 runs.append({'order':order,'folder':str(Q/label),'summary_sha256':sha(Q/label/'summary.json'),'peers':report,'results':rows});(out/'result.json').write_text(json.dumps({'plan':plan,'runs':runs,'complete':len(runs)==2},indent=2)+'\n');print(order,report,flush=True)
