#![allow(dead_code,unused_imports)]
mod native_artifact {
 pub type NativeCompileError=String;
 pub mod compiler {pub fn backend(error:impl std::fmt::Display)->String {error.to_string()}}
 pub mod program {pub mod codegen {pub mod cfg_cleanup {
use cranelift_codegen::ir::{Block,Function,Inst,InstructionData as Data,Opcode,Opcode as Op,MemFlags,Value,ValueDef,Endianness,types,condcodes::IntCC};use cranelift_codegen::flowgraph::ControlFlowGraph;use std::collections::{BTreeMap,BTreeSet};pub(in crate::native_artifact::program) fn incoming<'a>(
    function: &'a Function,
    cfg: &'a ControlFlowGraph,
    block: Block,
    ordinal: usize,
) -> impl Iterator<Item = (Block, Option<Value>)> + 'a {
    cfg.pred_iter(block).flat_map(move |pred| {
        function.dfg.insts[pred.inst]
            .branch_destination(&function.dfg.jump_tables, &function.dfg.exception_tables)
            .iter()
            .filter(move |call| call.block(&function.dfg.value_lists) == block)
            .map(move |call| {
                let value = call
                    .args(&function.dfg.value_lists)
                    .nth(ordinal)
                    .and_then(|arg| arg.as_value())
                    .map(|v| function.dfg.resolve_aliases(v));
                (pred.block, value)
            })
    })
}


use incoming as incoming_block_arguments;
mod word_ranges{use cranelift_codegen::ir::{Block,Function,Inst,InstructionData as Data,Opcode,Opcode as Op,MemFlags,Value,ValueDef,Endianness,types,condcodes::IntCC};use cranelift_codegen::flowgraph::ControlFlowGraph;use std::collections::{BTreeMap,BTreeSet};fn word_mask(function: &Function, value: Value) -> Option<u64> {
    let ty = function.dfg.value_type(value);
    (ty.is_int() && !ty.is_vector() && ty.bits() > 0 && ty.bits() <= 64)
        .then(|| u64::MAX >> (64 - ty.bits()))
}

pub(super) fn literal(function: &Function, value: Value) -> Option<u64> {
    let value = function.dfg.resolve_aliases(value);
    let ValueDef::Result(inst, 0) = function.dfg.value_def(value) else {
        return None;
    };
    let Data::UnaryImm {
        opcode: Op::Iconst,
        imm,
    } = function.dfg.insts[inst]
    else {
        return None;
    };
    Some(imm.bits() as u64 & word_mask(function, value)?)
}

/// Normalize integer addition modulo the word width. Callers use I64 words.
pub(super) fn constant_offset(f: &Function, mut value: Value) -> (Value, u64) {
    let mut offset = 0u64;
    loop {
        value = f.dfg.resolve_aliases(value);
        let step = match f.dfg.value_def(value) {
            ValueDef::Result(inst, 0) => match f.dfg.insts[inst] {
                Data::BinaryImm64 {
                    opcode: Op::IaddImm,
                    arg,
                    imm,
                } => Some((arg, imm.bits() as u64)),
                Data::Binary {
                    opcode: Op::Iadd,
                    args: [left, right],
                } => literal(f, right)
                    .map(|constant| (left, constant))
                    .or_else(|| literal(f, left).map(|constant| (right, constant))),
                _ => None,
            },
            _ => None,
        };
        let Some((next, constant)) = step else {
            return (value, offset);
        };
        offset = offset.wrapping_add(constant);
        value = next;
    }
}

}
mod boolean_conditions{use cranelift_codegen::ir::{Function,InstructionData as D,Opcode as O,Value,ValueDef,types};pub(in super::super) fn masked_integer_comparison(
    f: &Function,
    instruction: &D,
    mut resolve: impl FnMut(Value) -> Option<Value>,
) -> Option<Value> {
    let D::BinaryImm64 {
        opcode: O::BandImm,
        arg,
        imm,
    } = *instruction
    else {
        return None;
    };
    if imm.bits() != 1 {
        return None;
    }
    let mut value = arg;
    for _ in 0..8 {
        value = resolve(value)?;
        let ValueDef::Result(definition, 0) = f.dfg.value_def(value) else {
            return None;
        };
        match f.dfg.insts[definition] {
            D::Unary {
                opcode: O::Uextend,
                arg,
            } => value = arg,
            D::IntCompare { .. } | D::IntCompareImm { .. }
                if f.dfg.value_type(value) == types::I8 =>
            {
                return Some(value);
            }
            _ => return None,
        }
    }
    None
}

}
use boolean_conditions::masked_integer_comparison;
mod window_bounds{use cranelift_codegen::ir::{Block,Function,Inst,InstructionData as Data,Opcode,Opcode as Op,MemFlags,Value,ValueDef,Endianness,types,condcodes::IntCC};use cranelift_codegen::flowgraph::ControlFlowGraph;use std::collections::{BTreeMap,BTreeSet};use super::{masked_integer_comparison,word_ranges::literal};fn predicate_definition(f: &Function, mut value: Value) -> Option<Inst> {
    loop {
        let ValueDef::Result(inst, 0) = f.dfg.value_def(f.dfg.resolve_aliases(value)) else {
            return None;
        };
        match f.dfg.insts[inst] {
            Data::Unary {
                opcode: Opcode::Uextend,
                arg,
            } => value = arg,
            _ => match masked_integer_comparison(f, &f.dfg.insts[inst], |value| {
                Some(f.dfg.resolve_aliases(value))
            }) {
                Some(comparison) => value = comparison,
                None => return Some(inst),
            },
        }
    }
}

pub(super) fn comparison(f: &Function, value: Value) -> Option<Inst> {
    let mut inst = predicate_definition(f, value)?;
    loop {
        let inner = match f.dfg.insts[inst] {
            Data::IntCompare {
                cond: IntCC::Equal,
                args: [a, b],
                ..
            } if literal(f, b) == Some(1) => Some(a),
            Data::IntCompare {
                cond: IntCC::Equal,
                args: [a, b],
                ..
            } if literal(f, a) == Some(1) => Some(b),
            Data::IntCompareImm {
                cond: IntCC::Equal,
                arg,
                imm,
                ..
            } if imm.bits() == 1 => Some(arg),
            _ => None,
        };
        // Equality to one is identity only for the result of a comparison.
        if let Some(next) = inner.and_then(|word| predicate_definition(f, word)) {
            if matches!(
                f.dfg.insts[next],
                Data::IntCompare { .. } | Data::IntCompareImm { .. }
            ) {
                inst = next;
                continue;
            }
        }
        return Some(inst);
    }
}

}
mod composed_reads{use cranelift_codegen::ir::{Block,Function,Inst,InstructionData as Data,Opcode,Opcode as Op,MemFlags,Value,ValueDef,Endianness,types,condcodes::IntCC};use cranelift_codegen::flowgraph::ControlFlowGraph;use std::collections::{BTreeMap,BTreeSet};use std::sync::Arc;use super::{window_bounds::comparison,word_ranges::{constant_offset,literal}};#[derive(Clone)]
pub(in crate::native_artifact) struct Literal {
    pub length: u64,
    pub maximum: u64,
    pub bytes: Option<Arc<[u8]>>,
}
#[derive(Clone)]
pub(in crate::native_artifact) struct View {
    pub array: usize,
    pub pointer_word: usize,
    pub length_word: usize,
    pub width: u8,
    pub literal: Option<Literal>,
}
#[derive(Clone)]
pub(super) struct Read {
    branch: Inst,
    pub(super) index: Value,
    pub(super) view: View,
    pub(super) join: Block,
    pub(super) result: Value,
    arms: Vec<Block>,
}

pub(super) fn definition(f: &Function, value: Value) -> Option<(Inst, Data)> {
    let ValueDef::Result(inst, 0) = f.dfg.value_def(f.dfg.resolve_aliases(value)) else {
        return None;
    };
    Some((inst, f.dfg.insts[inst]))
}

fn incoming(
    f: &Function,
    cfg: &ControlFlowGraph,
    block: Block,
    slot: usize,
) -> Option<Vec<(Block, Value)>> {
    let mut arguments = Vec::new();
    for edge in cfg.pred_iter(block) {
        for call in
            f.dfg.insts[edge.inst].branch_destination(&f.dfg.jump_tables, &f.dfg.exception_tables)
        {
            if call.block(&f.dfg.value_lists) == block {
                arguments.push((
                    edge.block,
                    call.args(&f.dfg.value_lists).nth(slot)?.as_value()?,
                ));
            }
        }
    }
    (!arguments.is_empty()).then_some(arguments)
}

// Invariant packet fields can pass through a self edge or be reloaded by an
// alternate entry. All external definitions must identify the same word.
pub(super) fn packet_word(
    f: &Function,
    cfg: &ControlFlowGraph,
    loads: &BTreeMap<Value, (Inst, usize)>,
    value: Value,
) -> Option<usize> {
    let mut pending = vec![value];
    let mut seen = BTreeSet::new();
    let mut result = None;
    while let Some(value) = pending.pop() {
        let value = f.dfg.resolve_aliases(value);
        if !seen.insert(value) {
            continue;
        }
        if let Some(&(_, word)) = loads.get(&value) {
            if result.is_some_and(|old| old != word) {
                return None;
            }
            result = Some(word);
        } else if let ValueDef::Param(block, slot) = f.dfg.value_def(value) {
            if Some(block) == f.layout.entry_block() {
                return None;
            }
            pending.extend(
                incoming(f, cfg, block, slot)?
                    .into_iter()
                    .map(|(_, value)| value),
            );
        } else {
            return None;
        }
    }
    result
}

pub(super) fn scalar(op: Op) -> bool {
    matches!(
        op,
        Op::Iconst
            | Op::Iadd
            | Op::IaddImm
            | Op::Isub
            | Op::ImulImm
            | Op::Ishl
            | Op::IshlImm
            | Op::Ushr
            | Op::UshrImm
            | Op::Band
            | Op::BandImm
            | Op::Uextend
            | Op::Ireduce
            | Op::Icmp
            | Op::IcmpImm
    )
}

// Follow a single-entry arm to its merge. Exactly one typed load is allowed
// in the selected arm and no effects are allowed in the default arm.
pub(super) fn arm(
    f: &Function,
    cfg: &ControlFlowGraph,
    mut block: Block,
) -> Option<(Block, Value, Vec<Block>, Vec<Inst>)> {
    let mut blocks = Vec::new();
    let mut loads = Vec::new();
    loop {
        if cfg.pred_iter(block).count() != 1
            || !f.dfg.block_params(block).is_empty()
            || blocks.contains(&block)
        {
            return None;
        }
        blocks.push(block);
        let last = f.layout.last_inst(block)?;
        for inst in f.layout.block_insts(block).take_while(|&inst| inst != last) {
            let op = f.dfg.insts[inst].opcode();
            if matches!(op, Op::Load | Op::Uload8 | Op::Uload32) {
                loads.push(inst);
            } else if !scalar(op) {
                return None;
            }
        }
        let Data::Jump { destination, .. } = f.dfg.insts[last] else {
            return None;
        };
        block = destination.block(&f.dfg.value_lists);
        if cfg.pred_iter(block).count() > 1 {
            let mut args = destination.args(&f.dfg.value_lists);
            let result = args.next()?.as_value()?;
            return (args.next().is_none()).then_some((block, result, blocks, loads));
        }
        if destination.args(&f.dfg.value_lists).next().is_some() {
            return None;
        }
    }
}

pub(super) fn read_comparison(f: &Function, condition: Value) -> Option<Inst> {
    let compare = comparison(f, condition)?;
    let Data::BinaryImm64 {
        opcode: Op::BandImm,
        arg,
        imm,
    } = f.dfg.insts[compare]
    else {
        return Some(compare);
    };
    if imm.bits() != 1 || f.dfg.value_type(arg) != types::I8 {
        return None;
    }
    // A compact branch may expose the low bit of a comparison for native
    // selection. An arbitrary byte mask does not establish a read bound.
    let (inner, data) = definition(f, arg)?;
    matches!(data, Data::IntCompare { .. }).then_some(inner)
}

pub(super) fn defaulted_read(
    f: &Function,
    cfg: &ControlFlowGraph,
    packet_loads: &BTreeMap<Value, (Inst, usize)>,
    views: &[View],
    branch: Inst,
    endianness: Endianness,
) -> Option<Read> {
    let Data::Brif { arg, blocks, .. } = f.dfg.insts[branch] else {
        return None;
    };
    let compare = read_comparison(f, arg)?;
    let Data::IntCompare {
        cond: IntCC::UnsignedLessThan,
        args: [index, length],
        ..
    } = f.dfg.insts[compare]
    else {
        return None;
    };
    let length = packet_word(f, cfg, packet_loads, length)?;
    let view = views
        .iter()
        .find(|view| view.length_word == length)?
        .clone();
    let (join, yes, mut arms, loads) = arm(f, cfg, blocks[0].block(&f.dfg.value_lists))?;
    let (other_join, no, no_arm, no_loads) = arm(f, cfg, blocks[1].block(&f.dfg.value_lists))?;
    let [result] = *f.dfg.block_params(join) else {
        return None;
    };
    if join != other_join
        || cfg.pred_iter(join).count() != 2
        || literal(f, no) != Some(0)
        || !no_loads.is_empty()
        || f.dfg.value_type(result) != types::I64
        || f.dfg.value_type(index) != types::I64
    {
        return None;
    }
    let [load] = *loads.as_slice() else {
        return None;
    };
    let Data::Load {
        opcode,
        arg: address,
        offset,
        flags,
    } = f.dfg.insts[load]
    else {
        return None;
    };
    if i32::from(offset) != 0 || flags.endianness(endianness) != endianness {
        return None;
    }
    let loaded = f.dfg.first_result(load);
    let returned = f.dfg.resolve_aliases(yes);
    let same_result = match (view.width, opcode) {
        (1, Op::Uload8) | (4, Op::Uload32) => loaded == returned,
        (8, Op::Load) => loaded == returned && flags == MemFlags::new(),
        (width @ (1 | 4), Op::Load) => {
            let expected = if width == 1 { types::I8 } else { types::I32 };
            f.dfg.value_type(loaded) == expected
                && matches!(definition(f, returned), Some((_, Data::Unary {
                    opcode: Op::Uextend, arg,
                })) if f.dfg.resolve_aliases(arg) == loaded)
        }
        _ => false,
    };
    if !same_result || f.dfg.value_type(returned) != types::I64 {
        return None;
    }
    let (
        _,
        Data::Binary {
            opcode: Op::Iadd,
            args,
        },
    ) = definition(f, address)?
    else {
        return None;
    };
    let expected = constant_offset(f, index);
    let matches = |pointer: Value, bytes: Value| {
        if packet_word(f, cfg, packet_loads, pointer) != Some(view.pointer_word) {
            return false;
        }
        match definition(f, bytes) {
            Some((
                _,
                Data::BinaryImm64 {
                    opcode: Op::ImulImm,
                    arg,
                    imm,
                },
            )) if imm.bits() == i64::from(view.width) => constant_offset(f, arg) == expected,
            Some((
                _,
                Data::BinaryImm64 {
                    opcode: Op::IshlImm,
                    arg,
                    imm,
                },
            )) if imm.bits() == i64::from(view.width.ilog2()) => {
                constant_offset(f, arg) == expected
            }
            _ => view.width == 1 && constant_offset(f, bytes) == expected,
        }
    };
    if !matches(args[0], args[1]) && !matches(args[1], args[0]) {
        return None;
    }
    arms.extend(no_arm);
    Some(Read {
        branch,
        index,
        view,
        join,
        result,
        arms,
    })
}

}
#[path="/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/defaulted_loads/mod.rs"] mod defaulted_loads;
}}}}
