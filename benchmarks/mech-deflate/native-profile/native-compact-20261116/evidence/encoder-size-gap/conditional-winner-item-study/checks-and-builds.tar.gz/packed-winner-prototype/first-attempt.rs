// Standalone ISA experiment, not a codec artifact or a latency benchmark.
use cranelift_codegen::ir::{AbiParam, ConstantData, Endianness, InstBuilder, MemFlags, Type, Value, condcodes::IntCC, types};
use cranelift_frontend::{FunctionBuilder, FunctionBuilderContext};
use cranelift_jit::{JITBuilder, JITModule};
use cranelift_module::{Linkage, Module, default_libcall_names};
use std::{fs, path::PathBuf};

fn vector(b: &mut FunctionBuilder<'_>, ty: Type, bytes: Vec<u8>) -> Value {
    let data = b.func.dfg.constants.insert(ConstantData::from(bytes));
    b.ins().vconst(ty, data)
}

fn minimum(b: &mut FunctionBuilder<'_>, values: Value) -> Value {
    let a = b.ins().extractlane(values, 0);
    let b1 = b.ins().extractlane(values, 1);
    let c = b.ins().extractlane(values, 2);
    let d = b.ins().extractlane(values, 3);
    let lo = b.ins().umin(a, b1);
    let hi = b.ins().umin(c, d);
    b.ins().umin(lo, hi)
}

fn main() {
    assert!(cfg!(all(target_arch="aarch64", target_endian="little")));
    let output = PathBuf::from(std::env::args().nth(1).unwrap());
    fs::create_dir_all(&output).unwrap();
    let mut module = JITModule::new(JITBuilder::with_flags(
        &[("opt_level", "speed"), ("enable_verifier", "true")], default_libcall_names()).unwrap());
    let mut functions = Vec::new();
    for packed in [false, true] {
        let mut context = module.make_context();
        context.set_disasm(true);
        context.func.signature.params = vec![AbiParam::new(types::I64); 3];
        context.func.signature.returns = vec![AbiParam::new(types::I32)];
        let mut builder = FunctionBuilderContext::new();
        let mut b = FunctionBuilder::new(&mut context.func, &mut builder);
        let entry = b.create_block();
        b.append_block_params_for_function_params(entry);
        b.switch_to_block(entry);
        let [input, metadata, destination] = b.block_params(entry)[..] else { unreachable!() };
        let count = b.ins().load(types::I64, MemFlags::new(), metadata, 0);
        let start = b.ins().load(types::I64, MemFlags::new(), metadata, 8);
        let best = b.ins().load(types::I32, MemFlags::new(), metadata, 16);
        let stop = b.ins().iadd(start, count);
        let initial = if packed { b.ins().ishl_imm(best, 16) } else { best };
        let initial = b.ins().splat(types::I32X4, initial);
        let missing = b.ins().iconst(types::I32, -1);
        let absent = b.ins().splat(types::I32X4, missing);
        let zero = b.ins().iconst(types::I32, 0);
        let zeros = b.ins().splat(types::I32X4, zero);
        let lanes = if packed {
            vector(&mut b, types::I16X8, [1u16,2,3,4,0,0,0,0].into_iter().flat_map(u16::to_le_bytes).collect())
        } else {
            vector(&mut b, types::I32X4, [0u32,1,2,3].into_iter().flat_map(u32::to_le_bytes).collect())
        };
        let header = b.create_block();
        for ty in [types::I64, types::I32X4] { b.append_block_param(header,ty); }
        if !packed { b.append_block_param(header, types::I32X4); }
        let mut initial_args = vec![start.into(), initial.into()];
        if !packed { initial_args.push(absent.into()); }
        b.ins().jump(header, &initial_args);
        b.switch_to_block(header);
        let parameters = b.block_params(header).to_vec();
        let k = parameters[0];
        let body = b.create_block();
        let done = b.create_block();
        let more = b.ins().icmp(IntCC::UnsignedLessThan,k,stop);
        b.ins().brif(more,body,&[],done,&[]);
        b.switch_to_block(body);
        let offset = b.ins().isub(k,start);
        let offset = b.ins().ishl_imm(offset,2);
        let pointer = b.ins().iadd(input,offset);
        let costs = b.ins().load(types::I32X4,MemFlags::new(),pointer,0);
        let next_values = if packed {
            let index = b.ins().ireduce(types::I16,k);
            let index = b.ins().splat(types::I16X8,index);
            let index = b.ins().iadd(index,lanes);
            let costs = b.ins().uunarrow(costs,zeros);
            let flags = MemFlags::new().with_endianness(Endianness::Little);
            let index = b.ins().bitcast(types::I8X16,flags,index);
            let costs = b.ins().bitcast(types::I8X16,flags,costs);
            let mask = b.func.dfg.immediates.push(ConstantData::from(vec![
                0,1,16,17,2,3,18,19,4,5,20,21,6,7,22,23]));
            let key = b.ins().shuffle(index,costs,mask);
            let key = b.ins().bitcast(types::I32X4,flags,key);
            vec![b.ins().umin(key,parameters[1])]
        } else {
            let index = b.ins().ireduce(types::I32,k);
            let index = b.ins().splat(types::I32X4,index);
            let index = b.ins().iadd(index,lanes);
            let better = b.ins().icmp(IntCC::UnsignedLessThan,costs,parameters[1]);
            let cost = b.ins().umin(costs,parameters[1]);
            let index = b.ins().bitselect(better,index,parameters[2]);
            vec![cost,index]
        };
        let next = b.ins().iadd_imm(k,4);
        let mut args = vec![next.into()];
        args.extend(next_values.into_iter().map(Into::into));
        b.ins().jump(header,&args);
        b.switch_to_block(done);
        let (cost,winner) = if packed {
            let key = minimum(&mut b,parameters[1]);
            let cost = b.ins().ushr_imm(key,16);
            let position = b.ins().band_imm(key,65535);
            let winner = b.ins().iadd_imm(position,-1);
            (cost,winner)
        } else {
            let cost = minimum(&mut b,parameters[1]);
            let equal_cost = b.ins().splat(types::I32X4,cost);
            let equal = b.ins().icmp(IntCC::Equal,parameters[1],equal_cost);
            let positions = b.ins().bitselect(equal,parameters[2],absent);
            (cost,minimum(&mut b,positions))
        };
        b.ins().store(MemFlags::new(),cost,destination,0);
        b.ins().store(MemFlags::new(),winner,destination,4);
        b.ins().return_(&[winner]);
        b.seal_all_blocks(); b.finalize();
        let id = module.declare_function(&format!("packed_{packed}"),Linkage::Local,&context.func.signature).unwrap();
        module.define_function(id,&mut context).unwrap();
        let code = context.compiled_code().unwrap();
        fs::write(output.join(format!("packed-{packed}.vcode.txt")),code.vcode.as_ref().unwrap()).unwrap();
        functions.push(id);
    }
    module.finalize_definitions().unwrap();
    type Entry = unsafe extern "C" fn(*const u32,*const u64,*mut u32)->u32;
    let calls=functions.into_iter().map(|id| {
        // SAFETY: the live finalized module owns each exact declared C entry.
        unsafe { std::mem::transmute::<*const u8,Entry>(module.get_finalized_function(id)) }
    }).collect::<Vec<_>>();
    let mut seed=0x8a72_4ef1_d63b_c905u64;
    for sample in 0..4096usize {
        let mut next=|| { seed^=seed<<13;seed^=seed>>7;seed^=seed<<17;seed as u32 };
        let count=[0,4,8,16,32,64,128,252,256,508,512][sample%11];
        let start=match sample%4 {0=>0,1=>3,2=>32767,_=>65535-count};
        let best=[0,1,7,32767,32768,65534,65535,next()&65535][sample%8];
        assert!(start+count<=65535);
        let mut storage=vec![0xdead_beefu32;count+2];
        for (at,value) in storage[1..count+1].iter_mut().enumerate() {
            *value=match sample%6 {0=>best,1=>best.saturating_sub(1),2=>u32::MAX,_=> if at%3==0 {next()&65535} else {next()}};
        }
        let mut minimum=best;let mut winner=u32::MAX;
        for (at,&cost) in storage[1..count+1].iter().enumerate() {
            if cost<minimum {minimum=cost;winner=(start+at) as u32;}
        }
        let metadata=[count as u64,start as u64,u64::from(best)];
        let original=storage.clone();
        for call in &calls {
            let mut output=[0xa5a5_a5a5u32;4];
            // SAFETY: metadata admits the complete initialized source slice,
            // count is a multiple of four, stop and best fit U16, and output
            // is disjoint and guarded. All storage and the JIT stay live.
            let actual=unsafe {call(storage.as_ptr().add(1),metadata.as_ptr(),output.as_mut_ptr().add(1))};
            assert_eq!(actual,winner,"sample {sample}");
            assert_eq!(output,[0xa5a5_a5a5,minimum,winner,0xa5a5_a5a5]);
            assert_eq!(storage,original);
        }
    }
    println!("Verified8192nativecalls: best/stop<=65535, arbitraryU32costs, strictinitialtie, earliestglobalindex, saturatinghighcosts andguardedunalignedstorage. Prototypeonly; no codec or latency claim.");
}
