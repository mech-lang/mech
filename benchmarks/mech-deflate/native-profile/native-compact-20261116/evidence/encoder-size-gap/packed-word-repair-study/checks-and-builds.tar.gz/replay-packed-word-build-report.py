"""Repair reporting only: all18 completed measurement records remain unchanged."""
from pathlib import Path
from hashlib import sha256
from statistics import median
import json
N=Path(__file__).resolve().parent;O=N/'packed-word-repair-matched-builds'
read=lambda p:json.loads(p.read_text());sha=lambda p:sha256(p.read_bytes()).hexdigest();write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
plan=read(O/'plan.json');actors=plan['actors'];assert len(plan['orders'])==18
warm={role:read(O/'warmup'/role/'result.json') for role in actors};rows=[]
for i,order in enumerate(plan['orders'],1):
 row={role:read(O/f'order-{i}'/role/'result.json') for role in order};assert set(row)==set(actors)
 for role,item in row.items():
  assert item['generated_artifacts']==actors[role]['artifact_sha256'] and item['stripped_executable']==warm[role]['stripped_executable']
  if role.startswith('mech-'):
   for artifact,leaf in [('encoder','program.o'),('metadata','metadata.json'),('bytecode','program.mecb')]:assert sha(O/f'order-{i}'/role/'frontend'/leaf)==item['generated_artifacts'][artifact]
 rows.append(row)
medians={role:{cut:median(row[role]['seconds'][cut] for row in rows) for cut in warm[role]['seconds']} for role in actors};mech=[r for r in actors if r.startswith('mech-')]
ratios={role:{peer:median(row[role]['seconds']['source_through_link']/row[peer]['seconds']['source_through_link'] for row in rows) for peer in ['roc','libdeflate','mech-selected63']} for role in mech}
phases={}
for role in mech:
 profiles=[{phase['phase']:phase['seconds'] for phase in row[role]['compiler_phases']} for row in rows];assert all(p.keys()==profiles[0].keys() for p in profiles)
 phases[role]={phase:median(p[phase] for p in profiles) for phase in profiles[0]}
repair={'reason':'Post-measurement reporting expected mech-control-reference, but the actual named control is mech-selected63. All18 ordered trials and warmup completed before that KeyError. Reconstruct medians/ratios/phases from original saved actor result.json files; no clocks rerun or observations changed.','driver_log_sha256':sha(N/'packed-word-repair-matched-builds.log'),'replay_script_sha256':sha(Path(__file__)),'measurement_records':{str(p.relative_to(O)):sha(p) for p in O.glob('*/**/result.json')}}
comparison={'plan_sha256':sha(O/'plan.json'),'medians':medians,'paired_ratios':ratios,'phases':phases,'warmup':warm,'observations':rows,'load_after':None,'post_measurement_report_repair':repair};write(O/'comparison.json',comparison)
summary={k:comparison[k] for k in ['plan_sha256','medians','paired_ratios','phases']};summary.update(trials=len(rows),source_commit=plan['source_pin'],post_measurement_report_repair=repair,scope='18 balanced serial fresh-process source-through-final-executable-link trials per actor; all compilers and fixed support prebuilt equally. Every generated artifact checked. Strip and compiler bootstrap separate. Reporting label repaired from original saved records after acquisition; no measurements rerun.');write(O/'summary.json',summary)
print({k:v['source_through_link'] for k,v in medians.items()});print('narrow-eight paired:',ratios['mech-narrow-eight'])
