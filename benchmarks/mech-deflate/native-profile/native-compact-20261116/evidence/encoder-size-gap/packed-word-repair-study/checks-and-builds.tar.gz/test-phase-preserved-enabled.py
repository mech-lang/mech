from pathlib import Path
from hashlib import sha256
import json,subprocess,os,time
n=Path(__file__).resolve().parent
w=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP')
plan=json.loads((n/'phase-preserved-repository-tests/plan.json').read_text())
assert json.loads((n/'phase-preserved-repository-tests/result.json').read_text())['exit_code']==0
out=n/'phase-preserved-enabled-tests';out.mkdir();rows=[]
common={'MECH_ORDERED_PACKED_COST_INDEX':'1','MECH_ORDERED_PACKED_ACCUMULATORS':'2','MECH_ORDERED_PACKED_EIGHT_ENTRY':'1','MECH_ORDERED_PACKED_HEAD_GROUP':'1','MECH_ORDERED_PACKED_WIDE_ITEM':'1','MECH_DIRECT_ITEM_NO_GROWTH':'1','MECH_SINGLETON_ORDERED_REDUCTION':'1','MECH_ORDERED_PAIRED_CONTINUATION':'sequential-tail','MECH_ORDERED_PREFER_PRESERVED_REGS':'1'}
for label,extra in [('head',{}),('head-carry-latch',{'MECH_ORDERED_VECTOR_CARRY_LANES':'1','MECH_ORDERED_VECTOR_LATCH_TEST':'1'}),('head-deferred',{'MECH_ORDERED_PACK_WINNER_AT_EXIT':'1'})]:
 flags=common|extra;start=time.monotonic()
 with (out/(label+'.log')).open('w') as log:
  r=subprocess.run(plan['command'],cwd=w,env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}|plan['environment']|flags,stdout=log,stderr=log)
 assert all(sha256((w/path).read_bytes()).hexdigest()==pin for path,pin in plan['source_sha256'].items())
 row={'label':label,'flags':flags,'command':plan['command'],'seconds':time.monotonic()-start,'exit_code':r.returncode,'log_sha256':sha256((out/(label+'.log')).read_bytes()).hexdigest()};rows.append(row)
 (out/'result.json').write_text(json.dumps({'source_sha256':plan['source_sha256'],'runs':rows,'complete':len(rows)==3},indent=2)+'\n')
 print(label,r.returncode,row['seconds'],flush=True)
 assert r.returncode==0,(out/(label+'.log')).read_text()[-6000:]
