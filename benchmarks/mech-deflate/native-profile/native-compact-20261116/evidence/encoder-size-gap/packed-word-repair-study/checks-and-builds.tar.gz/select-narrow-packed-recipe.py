from pathlib import Path
from hashlib import sha256
import json
N=Path(__file__).resolve().parent
P=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/benchmarks/mech-deflate/native-profile/native-compact-20261116')
E=P/'evidence/encoder-size-gap/packed-word-repair-study'
read=lambda p:json.loads(p.read_text())
r=read(E/'result.json');assert r['full96']['passed'] and all(not x for x in r['full96']['raw_validation'].values())
role='narrow-eight-probe-profiled';pin=r['roles'][role];old=read(P/'evidence/encoder-size-gap/packed-eight-entry-study/candidate.json');candidate=old.copy();flags=pin['flags_as_run']
candidate.update(recipe='m1-narrow-packed-words',source_base=pin['source_basis'],source_integration_commit=pin['source_basis'],compiler_sha256=pin['compiler_sha256'],source_sha256=r['source_sha256'],artifact_sha256=pin['artifact_sha256'],encoder_text_bytes=pin['text_bytes'],native_flags_as_run=flags,profiles=pin['profiles'],override_flags={k:v for k,v in flags.items() if k!='MECH_COMPACT_PHASE_BLOCK_LAYOUT'},source_inputs=pin['source_inputs'],worker_sha256=pin['worker_sha256'],peak_stack_bytes=4736,runtime_wins={'roc':81,'libdeflate':63},blocks_per_order=96,working_selection=True,selection_basis=r['selection_basis'],new_win_confidence={run['order']:run['peers']['libdeflate']['cases']['prefix-natural-4096'] for run in r['full96']['named_win_audit']},scope='Selected working source recipe: bounded low-bit folding on immutable packed-word costs. All81 Roc and63 C named point wins retained in both full96 orders; confidence reported separately. Original2719-line Mech and canonical bytecode retained; no LLVM dependency.')
(E/'candidate.json').write_text(json.dumps(candidate,indent=2)+'\n')
p=P/'rebuild.py';s=p.read_text();needle="    'm1-packed-eight-entry': 'packed-eight-entry-study',\n";assert needle in s
if "'m1-narrow-packed-words':" not in s:s=s.replace(needle,needle+"    'm1-narrow-packed-words': 'packed-word-repair-study',\n")
s=s.replace("default=('m1-packed-eight-entry'", "default=('m1-narrow-packed-words'");p.write_text(s)
s=(N/'verify-working-eight-entry-selection.py').read_text().replace("evidence/encoder-size-gap/packed-eight-entry-study","evidence/encoder-size-gap/packed-word-repair-study").replace("'m1-packed-eight-entry'","'m1-narrow-packed-words'").replace("'packed-eight-head-probe-profiled/receipt.json'","'narrow-eight-probe-profiled/receipt.json'").replace("'phase-preserved-compiler/build.json'","'narrow-packed-compiler/build.json'").replace("'working-eight-entry-selection-replay'","'working-narrow-selection-replay'")
(N/'verify-working-narrow-selection.py').write_text(s)
print('Named recipe and default prepared; actual named normal/checked assembly replay still required.')
