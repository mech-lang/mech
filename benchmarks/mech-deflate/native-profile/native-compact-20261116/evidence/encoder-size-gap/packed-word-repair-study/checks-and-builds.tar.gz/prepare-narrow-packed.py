from pathlib import Path
import subprocess,json,sys
n=Path(__file__).resolve().parent
assert json.loads((n/'narrow-packed-compiler/build.json').read_text())['exit_code']==0
assert json.loads((n/'narrow-packed-repository-tests/result.json').read_text())['exit_code']==0
commands=[['python3', 'test-narrow-packed-enabled.py'], ['python3', 'emit-narrow-packed-raw.py'], ['python3', 'count-paired-packed-key.py', 'narrow-eight-probe', 'narrow-packet-eight-probe', 'narrow-once-probe', 'narrow-packet-once-probe'], ['python3', 'emit-narrow-packed-profiled.py'], ['python3', 'qualify-input-windows.py', 'check', 'narrow-eight-probe-profiled'], ['python3', 'check-window-profiled-candidate.py', 'narrow-eight-probe-profiled'], ['python3', 'qualify-input-windows.py', 'check', 'narrow-packet-eight-probe-profiled'], ['python3', 'check-window-profiled-candidate.py', 'narrow-packet-eight-probe-profiled'], ['python3', 'qualify-input-windows.py', 'check', 'narrow-once-probe-profiled'], ['python3', 'check-window-profiled-candidate.py', 'narrow-once-probe-profiled'], ['python3', 'qualify-input-windows.py', 'check', 'narrow-packet-once-probe-profiled'], ['python3', 'check-window-profiled-candidate.py', 'narrow-packet-once-probe-profiled']]
if '--bodies-only' in sys.argv:
 commands=commands[2:]
for i,cmd in enumerate(commands):
 if cmd==['python3','test-narrow-packed-enabled.py'] and (n/'narrow-packed-enabled-tests/result.json').exists() and json.loads((n/'narrow-packed-enabled-tests/result.json').read_text())['complete']:
  continue
 if cmd==['python3','emit-narrow-packed-raw.py'] and all((n/role/'receipt.json').exists() for role in ['narrow-eight-probe','narrow-packet-eight-probe','narrow-once-probe','narrow-packet-once-probe']):
  assert json.loads((n/'narrow-packed-disabled-replays/result.json').read_text())['all_three_exact']
  continue
 print('stage',i,cmd,flush=True)
 with (n/f'narrow-packed-preparation-{i}.log').open('w') as log:r=subprocess.run(cmd,cwd=n,stdout=log,stderr=log)
 assert r.returncode==0,(n/f'narrow-packed-preparation-{i}.log').read_text()[-5000:]
(n/'narrow-packed-ready.json').write_text(json.dumps({'commands':commands,'all_exit_codes':0,'runtime_clocks_started':False},indent=2)+'\n')
print('All narrow-cost workers pass source/profile/semantic/checked/recovery gates',flush=True)
