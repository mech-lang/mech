"""Freeze register, packet and packed-low-word repairs after all measurement clocks stop."""
from pathlib import Path
from hashlib import sha256
import gzip,io,json,shutil,tarfile
N=Path(__file__).resolve().parent;Q=N.parent.parent
P=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/benchmarks/mech-deflate/native-profile/native-compact-20261116')
E=P/'evidence/encoder-size-gap/packed-word-repair-study'
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
groups={
 'register': ['phase-preserved-'+mode+'-probe-profiled' for mode in ['unpaired','legacy','loop','once']],
 'packet': [role+'-profiled' for role in ['packet-eight-probe','packet-once-probe','packet-reg-eight-probe','packet-reg-once-probe']],
 'narrow': [role+'-profiled' for role in ['narrow-eight-probe','narrow-packet-eight-probe','narrow-once-probe','narrow-packet-once-probe']],
}
stage_files={'register':'phase-preserved-selected63-discovery-phase-preserved-unpaired-probe-profiled-results.json','packet':'scorer-packet-selected63-discovery-packet-eight-probe-profiled-results.json','narrow':'narrow-packed-selected63-discovery-narrow-eight-probe-profiled-results.json'}
stages={k:read(N/v) for k,v in stage_files.items()};assert all(v['complete'] and len(v['runs'])==8 for v in stages.values())
full_folder='narrow-packed-qualified96-narrow-eight-probe-profiled';full=read(N/full_folder/'result.json');assert full['complete']
builds=read(N/'packed-word-repair-matched-builds/summary.json');assert builds['trials']==18
roles=sum(groups.values(),[]);files={}
def add(p):
 p=Path(p)
 if p.is_file():files[str(p.relative_to(N))]=p
def folder(p):
 for f in Path(p).rglob('*'):
  if not f.is_file() or '/compiler/' in str(f.relative_to(N)):continue
  if f.suffix in ['.json','.jsonl','.log','.stderr','.txt','.py','.rs','.c','.o','.mecb','.gz','.clif','.vcode','.allowlist'] or f.name in ['mech-worker','layout-stack-worker','checked-exit-failure-worker']:add(f)
for role in roles:
 folder(N/role);folder(N/role.removesuffix('-profiled'));folder(Path(read(N/role/'linked-proof.json')['result']).parent.parent)
for folder_name in ['phase-preserved-compiler','phase-preserved-repository-tests','phase-preserved-enabled-tests','phase-preserved-disabled-replays','narrow-packed-compiler','narrow-packed-repository-tests','narrow-packed-enabled-tests','narrow-packed-disabled-replays','packed-word-repair-matched-builds',full_folder,'scorer-narrow-diagnostic','phase-preserved-inspection']:
 folder(N/folder_name)
for old in ['packed-eight-head-probe','scalar-pair-head-probe','scalar-loop-head-probe','scalar-once-head-probe']:
 add(N/old/'receipt.json');folder(N/old/'instruction-counts');folder(N/old/'instruction-counts-loss-census')
for path in N.glob('*.py'):
 if any(t in path.name for t in ['phase-preserved','scorer-packet','narrow-packed','packed-word','paired-packed-key','scorer-loss-census','qualify-input-windows','window-profiled-candidate']):add(path)
for name in ['phase-preserved-artifact-comparison.json','phase-preserved-symbol-comparison.json','phase-preserved-register-diff.txt','narrow-packed-unsafe-audit.log','word-complements-prior-wins.json','critical-path-next.json']:
 add(N/name)
files['as-run-fixtures.json']=Q/'fixtures.json';raw={}
for stage in stages.values():
 for run in stage['runs']:
  for p in Path(run['run']).rglob('*'):
   if p.is_file():raw[str(p.relative_to(Q))]=p
for receipt in full['receipts']:
 for p in (Q/receipt['id']).rglob('*'):
  if p.is_file():raw[str(p.relative_to(Q))]=p
E.mkdir();archives={}
def archive(path,items):
 pins={};prior={}
 with tarfile.open(path,'w:gz',compresslevel=6) as tar:
  for name,p in sorted(items.items()):
   data=p.read_bytes();h=sha256(data).hexdigest();key=h,len(data);info=tarfile.TarInfo(name);info.mode=0o644
   if key in prior:info.type=tarfile.LNKTYPE;info.linkname=prior[key];tar.addfile(info)
   else:info.size=len(data);tar.addfile(info,io.BytesIO(data));prior[key]=name
   pins[name]={'bytes':len(data),'sha256':h}
 archives[path.name]=pins
archive(E/'checks-and-builds.tar.gz',files);archive(E/'raw-runtime.tar.gz',raw);write(E/'archive-files.json',archives)
(E/'phase-profiles').mkdir();published={}
for role in roles:
 rec=read(N/role/'receipt.json');worker=read(N/role/'bound/runtime.json');profiles=[]
 for entry in rec['flags']['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].split(';'):
  symbol,path=entry.split('@',1);h=sha(path);dest=E/'phase-profiles'/(h[:24]+'.json')
  if not dest.exists():shutil.copyfile(path,dest)
  profiles.append({'symbol':symbol,'path':str(dest.relative_to(E)),'sha256':h})
 published[role]={'artifact_sha256':rec['artifacts'],'text_bytes':rec['text_bytes'],'worker_sha256':worker['worker_sha256'],'compiler_sha256':rec['compiler_sha256'],'source_basis':rec['source_base'],'source_inputs':rec['source_inputs'],'flags_as_run':rec['flags'],'profiles':profiles}
 for leaf in ['program.o','metadata.json']:(E/(role+'-'+leaf+'.gz')).write_bytes(gzip.compress((N/role/'frontend'/leaf).read_bytes(),mtime=0))
policy=read(N/full_folder/'policy.json');comparisons=[]
bases=['packed-eight-head-probe','scalar-pair-head-probe','scalar-loop-head-probe','scalar-once-head-probe','packed-eight-head-probe','scalar-once-head-probe','phase-preserved-unpaired-probe','phase-preserved-once-probe','packed-eight-head-probe','packet-eight-probe','scalar-once-head-probe','packet-once-probe']
for role,base in zip(roles,bases,strict=True):
 current=role.removesuffix('-profiled');before=read(N/base/'instruction-counts/counts.json');after=read(N/current/'instruction-counts/counts.json');cases={}
 for name,b in after['cases'].items():
  a=before['cases'][name];keys=['instructions','branches','stack_loads','stack_stores'];x={k:a['counts'].get(k,0) for k in keys};y={k:b['counts'].get(k,0) for k in keys};cases[name]={'before':x,'after':y,'delta':{k:y[k]-x[k] for k in keys}}
 comparisons.append({'current_role':current,'previous_role':base,'before_sha256':sha(N/base/'instruction-counts/counts.json'),'after_sha256':sha(N/current/'instruction-counts/counts.json'),'cases':cases})
audit=[]
for group,stage in stages.items():
 for run in stage['runs']:
  missing={peer:[row['case'] for row in run['results'] if row['case'] in policy['required_peer_wins'][peer] and row[key]['mech-experiment']>=1] for peer,key in [('roc','paired_x_roc'),('libdeflate','paired_x_libdeflate')]};audit.append({'group':group,'role':run['role'],'order':run['order'],'required_point_wins_missing':missing})
result={'source_sha256':sha(P/'program.mec'),'bytecode_sha256':published[roles[0]]['artifact_sha256']['program.mecb'],'groups':groups,'roles':published,'stages':stages,'panel_audit':audit,'counter_comparisons':comparisons,'full96':full,'full96_folder':full_folder,'builds':builds,'build_folder':'packed-word-repair-matched-builds','working_policy':policy,'baseline':{'recipe':'m1-packed-eight-entry','text_bytes':63868,'roc_point_wins':81,'libdeflate_point_wins':63,'worker_sha256':'0863e47b3aa5fb64256fdaf51feba952e4d3078ac3b11db488e8fe6aaff9afcf'},'native_tests':{'phase-preserved':{'tests':20,'configurations':4,'scalar_pair_calls':67584,'older_replays':45},'narrow-packed':{'tests':21,'configurations':4,'scalar_pair_calls':67584,'narrow_packed_calls':101376,'older_replays':53}},'promotion_eligible':full['passed'],'selection_basis':'Both complete81-case point scores and every required named point win in both96-block orders; report confidence separately. No score is inferred from21-case panels or counters.','limitations':['8.6% fewer scorer instructions on1MiB random does not establish a runtime gain; all adverse outcomes retained.','Single-tail gains and packet64B savings remain available for repair even where a named point win is missing.','Complete build clocks, runtime clocks, profiles, counters, Rust producers, tests and archive compression do not overlap.','Repository unsafe audit remains blocked by the pre-existing missing archived pinned_allocator.rs.']}
write(E/'result.json',result);shutil.copyfile(P/'evidence/encoder-size-gap/scalar-sequential-study/host.json',E/'host.json')
print('Frozen',len(files),'check/build files,',len(raw),'runtime files and12 source-built repairs. Portable replay and verification still required.',flush=True)
