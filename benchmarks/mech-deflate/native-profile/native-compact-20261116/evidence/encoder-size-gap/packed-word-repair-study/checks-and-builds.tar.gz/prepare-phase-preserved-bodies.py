from pathlib import Path
import json,subprocess
n=Path(__file__).resolve().parent
assert json.loads((n/'phase-preserved-compiler/build.json').read_text())['exit_code']==0
roles=['phase-preserved-unpaired-probe','phase-preserved-legacy-probe','phase-preserved-loop-probe','phase-preserved-once-probe']
commands=[['python3','emit-phase-preserved-raw.py'],['python3','count-paired-packed-key.py',*roles],['python3','emit-phase-preserved-profiled.py']]
for role in roles:commands.extend([['python3','qualify-input-windows.py','check',role+'-profiled'],['python3','check-window-profiled-candidate.py',role+'-profiled']])
commands.append(['python3','count-scorer-loss-census.py','phase-preserved-unpaired-probe','phase-preserved-once-probe'])
for index,command in enumerate(commands):
 print('Running',command,flush=True)
 with (n/f'phase-preserved-body-{index}.log').open('w') as log:r=subprocess.run(command,cwd=n,stdout=log,stderr=subprocess.STDOUT)
 assert r.returncode==0,(command,(n/f'phase-preserved-body-{index}.log').read_text()[-7000:])
 print('Completed',command,flush=True)
(n/'phase-preserved-bodies-ready.json').write_text(json.dumps({'commands':commands,'all_exit_codes':0,'runtime_clocks_started':False},indent=2)+'\n');print('All body/check/counter producers complete; runtime clocks have not started.',flush=True)
