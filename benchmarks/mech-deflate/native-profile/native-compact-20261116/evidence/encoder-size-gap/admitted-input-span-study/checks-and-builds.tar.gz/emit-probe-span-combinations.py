from pathlib import Path
from hashlib import sha256
from runpy import run_path
import json,os,subprocess
n=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();build=read(n/'admitted-input-span-composed-compiler/build.json');tool=run_path(str(n.parent.parent/'current-roadmap/scorer-runtime/emit.py'),run_name='probe_span_symbols')
for role,base in [('probe-bitwise-vector-complements','bitwise-vector-complements'),('probe-span-vector-complements','span-late-vector-complements')]:
 old=read(n/base/'receipt.json');out=n/role;out.mkdir();flags=old['flags']|{'MECH_PROBE_WORD_BEFORE_VECTOR':'1'};assert flags.get('MECH_REUSE_VECTOR_MISMATCH') is not None
 flags['MECH_COMPACT_PHASE_BLOCK_LAYOUT']=';'.join(x for x in flags['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].split(';') if not x.startswith('mech_compact_numeric_475_vector@'))
 cmd=[build['compiler'],old['compile'][1],str(out/'frontend'),'compact']
 with (out/'compile.log').open('w') as log:subprocess.run(cmd,env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}|flags,stdout=log,stderr=log,check=True)
 artifacts={name:sha(out/'frontend'/name) for name in old['artifacts']};assert artifacts['program.mecb']==old['artifacts']['program.mecb'];layout=tool['symbols'](out/'frontend/program.o');evidence=[]
 def walk(x):
  if isinstance(x,dict):
   if x.get('first_word_equality_probes'):evidence.append({'header':x.get('header'),'symbol':x.get('symbol'),'first_word_equality_probes':x['first_word_equality_probes'],'admitted_input_spans':x.get('admitted_input_spans')})
   for v in x.values():walk(v)
  elif isinstance(x,list):
   for v in x:walk(v)
 walk(read(out/'frontend/metadata.json'));assert evidence
 receipt=old|{'compile':cmd,'command':cmd,'compiler_sha256':build['compiler_sha256'],'source_base':build['source_base'],'source_inputs':build['source_sha256'],'flags':flags,'artifacts':artifacts,'object_sha256':artifacts['program.o'],'metadata_sha256':artifacts['metadata.json'],'bytecode_sha256':artifacts['program.mecb'],'text_bytes':layout['text_bytes'],'layout':layout,'first_word_probe':evidence,'runtime_qualification':'pending'};(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(role,layout['text_bytes'],evidence,flush=True)
