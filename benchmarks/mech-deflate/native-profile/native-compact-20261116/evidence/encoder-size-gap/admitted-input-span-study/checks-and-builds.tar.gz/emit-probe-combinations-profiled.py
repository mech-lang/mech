from pathlib import Path
from hashlib import sha256
from runpy import run_path
import json,os,subprocess,sys
n=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();tool=run_path(str(n.parent.parent/'current-roadmap/scorer-runtime/emit.py'),run_name='small_table_profiled_symbols')
build=read(n/'admitted-input-span-composed-compiler/build.json')
for raw in sys.argv[1:] or ['probe-bitwise-vector-complements','probe-span-vector-complements']:
 old=read(n/raw/'receipt.json');out=n/(raw+'-profiled');out.mkdir();profile=n/(raw+'-matcher-profile.json');flags=old['flags'].copy();flags['MECH_COMPACT_PHASE_BLOCK_LAYOUT']+=';mech_compact_numeric_475_vector@'+str(profile);cmd=[build['compiler'],old['compile'][1],str(out/'frontend'),'compact']
 with (out/'compile.log').open('w') as log:r=subprocess.run(cmd,env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}|flags,stdout=log,stderr=log)
 assert r.returncode==0,(out/'compile.log').read_text()[-4000:]
 art={name:sha(out/'frontend'/name) for name in ['program.o','metadata.json','program.mecb']};assert art['program.mecb']==old['artifacts']['program.mecb'];layout=tool['symbols'](out/'frontend/program.o');receipt=old|{'compiler_sha256':build['compiler_sha256'],'source_base':build['source_base'],'source_inputs':build['source_sha256'],'compile':cmd,'command':cmd,'flags':flags,'artifacts':art,'object_sha256':art['program.o'],'metadata_sha256':art['metadata.json'],'bytecode_sha256':art['program.mecb'],'layout':layout,'text_bytes':layout['text_bytes'],'profile_sha256':sha(profile),'profile_source':raw,'runtime_qualification':'pending'};(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(raw+'-profiled',layout['text_bytes'],receipt.get('admitted_input_spans',[]),flush=True)
