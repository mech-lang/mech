from pathlib import Path
import subprocess
N=Path(__file__).resolve().parent;O=N/'expanded-packet-root-study'
for mode in ['families','root-forward','combined']:
    print('starting quiet runtime',mode,flush=True)
    with (O/(mode+'-timing.log')).open('w') as log:subprocess.run(['python3',str(N/'time-expanded-packet-root-candidate.py'),mode],stdout=log,stderr=log,check=True)
    print('completed',mode,flush=True)
