"""Exercise the main named source build path, using current compiler sources."""
from pathlib import Path
from hashlib import sha256
import json,subprocess,os
N=Path(__file__).resolve().parent;S=N/'expanded-packet-root-study';W=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP');P=W/'benchmarks/mech-deflate/native-profile/native-compact-20261116';read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();records={}
for mode in ['families','root-forward','combined']:
 name='m1-root-packet-'+mode;out=S/('main-rebuild-'+mode);cmd=['python3',str(P/'rebuild.py'),str(out),'--variant',name,'--target-dir',str(N.parent/'compiler-target')]
 with (S/('main-rebuild-'+mode+'.log')).open('w') as log:subprocess.run(cmd,cwd=W,stdout=log,stderr=log,check=True)
 expected=read(S/(mode+'/receipt.json'))['artifacts'];art={'program.o':sha(out/'native/program.o'),'metadata.json':sha(out/'native/metadata.json'),'program.mecb':sha(out/'frontend/program.mecb')};assert art==expected
 records[name]={'all_three_exact':True,'artifacts':art,'source_sha256':sha(P/'program.mec'),'rebuild_py_sha256':sha(P/'rebuild.py'),'command':cmd,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()};print(name,'main source build all3 exact',flush=True)
(S/'main-rebuilds-verified.json').write_text(json.dumps(records,indent=2)+'\n')
