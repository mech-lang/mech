"""Separate the hot scorer's packet qualification from the smaller phases."""
from pathlib import Path
from hashlib import sha256
from runpy import run_path
import json, os, subprocess

N = Path(__file__).resolve().parent
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: sha256(Path(p).read_bytes()).hexdigest()
build = read(N / 'selected-packet-compiler/build.json')
tool = run_path(str(N.parent.parent / 'current-roadmap/scorer-runtime/emit.py'),
                run_name='selected_packet_symbols')
probe = read(N / 'read-window-probe-profiled/receipt.json')
packet = read(N / 'read-window-packet-profiled/receipt.json')
scorer = 'mech_compact_numeric_3009'
cold_bases = [p['symbol'] for p in read(N / 'read-window-probe-profiled/frontend/metadata.json')['numeric_phases'] if p['symbol'] != scorer]
assert len(cold_bases) == 13
cold = [base + suffix for base in cold_bases for suffix in ['', '_vector', '_no_growth']]

def compile_into(out, prior, flags):
    out.mkdir(parents=True)
    command = [build['compiler'], prior['compile'][1], str(out / 'frontend'), 'compact']
    with (out / 'compile.log').open('w') as log:
        subprocess.run(command, env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')} | flags,
                       stdout=log, stderr=log, check=True)
    artifacts = {name: sha(out / 'frontend' / name) for name in prior['artifacts']}
    assert artifacts['program.mecb'] == prior['artifacts']['program.mecb']
    return command, artifacts

assert read(N / 'selected-packet-disabled-replays/result.json')['all_three_exact']

for kind, base_role in [('probe', 'read-window-probe-profiled'), ('word', 'read-window-word-profiled')]:
    prior = read(N / base_role / 'receipt.json')
    for part, selected in [('others', cold)]:
        role = f'select-packet-family-{kind}-{part}-raw'
        flags = prior['flags'].copy()
        flags.pop('MECH_COMPACT_PHASE_BLOCK_LAYOUT', None)
        if selected is not None:
            flags['MECH_QUALIFY_PHASE_INPUT_PACKET'] = 'only:' + ','.join(selected)
        command, artifacts = compile_into(N / role, prior, flags)
        layout = tool['symbols'](N / role / 'frontend/program.o')
        record = prior | {'compile': command, 'command': command,
            'compiler_sha256': build['compiler_sha256'], 'source_base': build['source_base'],
            'source_inputs': build['source_sha256'], 'flags': flags, 'artifacts': artifacts,
            'object_sha256': artifacts['program.o'], 'metadata_sha256': artifacts['metadata.json'],
            'bytecode_sha256': artifacts['program.mecb'], 'text_bytes': layout['text_bytes'],
            'layout': layout, 'phase_selection': selected,
            'base_role': base_role, 'runtime_qualification': 'pending'}
        (N / role / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
        print(role, layout['text_bytes'], flush=True)
