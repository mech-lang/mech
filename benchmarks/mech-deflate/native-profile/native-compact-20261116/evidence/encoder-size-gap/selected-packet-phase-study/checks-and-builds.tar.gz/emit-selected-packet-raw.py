"""Separate the hot scorer's packet qualification from the smaller phases."""
from pathlib import Path
from hashlib import sha256
from runpy import run_path
import json, os, subprocess

N = Path(__file__).resolve().parent
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: sha256(Path(p).read_bytes()).hexdigest()
build = read(N / 'selected-packet-compiler/build.json')
tool = run_path(str(N.parent.parent / 'current-roadmap/scorer-runtime/emit.py'),
                run_name='selected_packet_symbols')
probe = read(N / 'read-window-probe-profiled/receipt.json')
packet = read(N / 'read-window-packet-profiled/receipt.json')
scorer = 'mech_compact_numeric_3009_no_growth_composed'
cold = [symbol[1:] for symbol, atom in probe['layout']['symbols'].items()
        if symbol.startswith('_mech_compact_numeric_')
        and symbol != '_' + scorer
        and atom['sha256'] != packet['layout']['symbols'][symbol]['sha256']]
assert len(cold) == 11, cold

def compile_into(out, prior, flags):
    out.mkdir(parents=True)
    command = [build['compiler'], prior['compile'][1], str(out / 'frontend'), 'compact']
    with (out / 'compile.log').open('w') as log:
        subprocess.run(command, env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')} | flags,
                       stdout=log, stderr=log, check=True)
    artifacts = {name: sha(out / 'frontend' / name) for name in prior['artifacts']}
    assert artifacts['program.mecb'] == prior['artifacts']['program.mecb']
    return command, artifacts

replays = N / 'selected-packet-disabled-replays'
replays.mkdir()
rows = []
for role in ['bounded-histogram-word', 'read-window-word-profiled',
             'read-window-probe-profiled', 'read-window-packet-profiled']:
    old = read(N / role / 'receipt.json')
    command, artifacts = compile_into(replays / role, old, old['flags'])
    assert artifacts == old['artifacts'], role
    rows.append({'role': role, 'command': command, 'artifacts': artifacts, 'three_exact': True})
for name, selection in [('empty', 'only:'), ('unknown', 'only:mech_compact_numeric_no_such_phase')]:
    command, artifacts = compile_into(replays / name, probe, probe['flags'] | {'MECH_QUALIFY_PHASE_INPUT_PACKET': selection})
    assert artifacts == probe['artifacts'], name
    rows.append({'role': name, 'selection': selection, 'command': command,
                 'artifacts': artifacts, 'three_exact': True})
(replays / 'result.json').write_text(json.dumps({'all_three_exact': True,
    'compiler_sha256': build['compiler_sha256'], 'runs': rows}, indent=2) + '\n')

for kind, base_role in [('probe', 'read-window-probe-profiled'), ('word', 'read-window-word-profiled')]:
    prior = read(N / base_role / 'receipt.json')
    for part, selected in [('control', None), ('cold', cold), ('scorer', [scorer])]:
        role = f'select-packet-{kind}-{part}-raw'
        flags = prior['flags'].copy()
        flags.pop('MECH_COMPACT_PHASE_BLOCK_LAYOUT', None)
        if selected is not None:
            flags['MECH_QUALIFY_PHASE_INPUT_PACKET'] = 'only:' + ','.join(selected)
        command, artifacts = compile_into(N / role, prior, flags)
        layout = tool['symbols'](N / role / 'frontend/program.o')
        record = prior | {'compile': command, 'command': command,
            'compiler_sha256': build['compiler_sha256'], 'source_base': build['source_base'],
            'source_inputs': build['source_sha256'], 'flags': flags, 'artifacts': artifacts,
            'object_sha256': artifacts['program.o'], 'metadata_sha256': artifacts['metadata.json'],
            'bytecode_sha256': artifacts['program.mecb'], 'text_bytes': layout['text_bytes'],
            'layout': layout, 'phase_selection': selected,
            'base_role': base_role, 'runtime_qualification': 'pending'}
        (N / role / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
        print(role, layout['text_bytes'], flush=True)
