"""Untimed counts of the actual final forwarded matcher allocations."""
from pathlib import Path
from hashlib import sha256
import ast,json,shutil
N=Path(__file__).resolve().parent;O=N/'forwarded-register-study';Q=N.parent.parent;read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
script=N/'count-current-semantic-matcher.py';ns={'__file__':str(script),'__name__':'final_forwarded_register_counters'};exec(compile(script.read_text().split('\nsource_shapes={}')[0],str(script),'exec'),ns);driver=ns['driver'];ns['shapes']['OUT']=O
source=N/'prepare-forwarded-register-study.py';nodes=[v for v in ast.parse(source.read_text()).body if isinstance(v,ast.FunctionDef) and v.name=='count'];assert len(nodes)==1;exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'))
records={}
for role in ['linear-profiled','sqrt-profiled']:
 folder,shape=count(O/role,'mech_compact_numeric_475_vector');r=read(folder/'counts.json');records[role]={'counts_sha256':sha(folder/'counts.json'),'object_sha256':r['object_sha256'],'cases':{case:{k:v for k,v in row.items() if k!='blocks'} for case,row in r['cases'].items()}}
(O/'final-matcher-work.json').write_text(json.dumps(records,indent=2)+'\n');print('actual final matcher counts complete',flush=True)
