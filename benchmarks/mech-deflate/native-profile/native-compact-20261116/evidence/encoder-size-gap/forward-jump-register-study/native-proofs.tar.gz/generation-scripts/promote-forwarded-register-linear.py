from pathlib import Path
from hashlib import sha256
import json
N=Path(__file__).resolve().parent;S=N/'forwarded-register-study';P=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/benchmarks/mech-deflate/native-profile/native-compact-20261116');O=P/'evidence/encoder-size-gap/forward-jump-register-study';read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
full=read(S/'linear-full96-results.json');assert full['complete'] and full['point_passed'] and all(not v['required_missing'] for run in full['runs'] for v in run['peers'].values())
for mode in ['linear','sqrt']:
 proof=read(S/'main-rebuilds-verified.json')['m1-forwarded-register-'+mode];assert proof['all_three_exact'] and proof['artifacts']==read(S/(mode+'-profiled/receipt.json'))['artifacts']
 for emission in ['normal','checked']:assert read(S/'public-replays'/(mode+'-'+emission)/'reproduction.json')['all_three_exact']
assert len(read(N/'forwarded-register-matched-builds/comparison.json')['observations'])==10
assert read(N/'forwarded-register-matched-builds/deployment-smokes.json')['checked_executions']==405
rebuild=P/'rebuild.py';before=sha(rebuild);s=rebuild.read_text();old="default=('m1-profiled-register-sqrt' if";new="default=('m1-forwarded-register-linear' if";assert s.count(old)==1;rebuild.write_text(s.replace(old,new))
policy=read(P/'working-selection-policy.json');policy['working_recipe']='m1-forwarded-register-linear';(P/'working-selection-policy.json').write_text(json.dumps(policy,indent=2)+'\n')
for mode in ['linear','sqrt']:
 manifest=O/mode/'candidate.json';r=read(manifest);r['working_selection']=mode=='linear';r['source_inputs']={path:sha(P.parents[3]/path) for path in r['source_inputs']};manifest.write_text(json.dumps(r,indent=2)+'\n')
receipt=read(S/'linear-profiled/receipt.json');record={'selected_default_changed':True,'previous_recipe':'m1-profiled-register-sqrt','previous_text_bytes':63612,'recipe':'m1-forwarded-register-linear','text_bytes':63516,'saved_text_bytes':96,'artifacts':receipt['artifacts'],'worker_sha256':sha(S/'linear-profiled/bound/mech-worker'),'source_sha256':receipt['source_sha256'],'bytecode_unchanged':True,'all_required_named_wins_preserved':True,'confidence_assessed':False,'selection_basis':'Both full81/96 point orders and every required named81Roc/63Cwin. Broad family gains, smaller code and smaller stack. Alternative sqrt retained with its distribution slowdown and without full81qualification.','compiler_rebuild_py_before_default_sha256':before,'compiler_rebuild_py_after_default_sha256':sha(rebuild),'stack_bytes':4720,'next_C_target':64,'ultimate_C_target':81};(S/'promotion.json').write_text(json.dumps(record,indent=2)+'\n');(O/'promotion.json').write_text(json.dumps(record,indent=2)+'\n');print('promoted 63516 B broad cleanup; every named81/63win retained')
