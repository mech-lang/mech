"""Fresh code/counters/profiles after generic empty-jump forwarding. Untimed."""
from pathlib import Path
from hashlib import sha256
import json,os,subprocess,shutil,sys
N=Path(__file__).resolve().parent;O=N/'forwarded-register-study';O.mkdir();Q=N.parent.parent
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}
script=N/'count-current-semantic-matcher.py';ns={'__file__':str(script),'__name__':'fresh_forwarded_profiles'};exec(compile(script.read_text().split('\nsource_shapes={}')[0],str(script),'exec'),ns);driver=ns['driver'];ns['shapes']['OUT']=O
r=read(N/'compact-register-weights/phis-sqrt-profiled/receipt.json');compiler=read(N/'measured-register-weights/compiler-build-v5/build.json')['compiler'];assert sha(compiler)==r['compiler_sha256']
MF='mech_compact_numeric_475_vector';HF='mech_compact_numeric_3956_vector';kept=';'.join(p for p in r['flags']['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].split(';') if p.split('@')[0] not in [MF,HF]);base={k:v for k,v in r['flags'].items() if k!='MECH_COMPACT_PHASE_REGISTER_WEIGHTS'}|{'MECH_COMPACT_PHASE_BLOCK_LAYOUT':kept,'MECH_COMPACT_SKIP_EMPTY_JUMPS':'vector'}
def emit(name,flags,capture=False):
 out=O/name;out.mkdir();cmd=[compiler,r['command'][1],str(out/'frontend'),'compact']
 with (out/'compile.log').open('w') as log:subprocess.run(cmd,env=env|flags,stdout=log,stderr=log,check=True)
 art={f:sha(out/'frontend'/f) for f in r['artifacts']};assert art['program.mecb']==r['artifacts']['program.mecb'];layout=driver.symbols(out/'frontend/program.o');receipt=r|{'command':cmd,'compile':cmd,'flags':flags,'artifacts':art,'layout':layout,'text_bytes':layout['text_bytes'],'object_sha256':art['program.o'],'metadata_sha256':art['metadata.json'],'bytecode_sha256':art['program.mecb']};receipt.pop('linked_proof_sha256',None);(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');driver.link.link_worker(N/'compact-register-weights/phis-sqrt-profiled/bound',out/'frontend',out/'bound');driver.link.check_worker(out/'bound','forwarded-'+name);runtime=read(out/'bound/runtime.json');runtime['encoder_text_bytes']=receipt['text_bytes'];(out/'bound/runtime.json').write_text(json.dumps(runtime,indent=2)+'\n');print('emitted',name,receipt['text_bytes'],flush=True);return out

def count(raw,symbol):
 front=raw/'canonical-counter-input/frontend'
 if not front.exists():
  front.mkdir(parents=True);normalization=ns['normal'](raw/'frontend/program.o',front/'program.o')
  for f in ['metadata.json','program.mecb']:shutil.copyfile(raw/'frontend'/f,front/f)
  (front.parent/'canonicalization.json').write_text(json.dumps(normalization,indent=2)+'\n');driver.link.link_worker(raw/'bound',front,front.parent/'bound');assert sha(front.parent/'bound/mech-worker')==sha(raw/'bound/mech-worker')
 shape=ns['shapes']['shape'](str(raw),symbol);folder=raw/('counts-'+symbol.split('_')[3]);target=front.parent/'bound';original=Q/'count-matcher-instructions.py';program=original.read_text();needle='    root = q / f"{label}-native/final-candidate"';assert program.count(needle)==1;program=program.replace(needle,'    root = Path('+repr(str(target))+')');needle='    directory = q / "matcher-dynamic-blocks" / actor';assert program.count(needle)==1;program=program.replace(needle,'    directory = Path('+repr(str(folder))+')').replace('allow_data_references=literal_start is not None','allow_data_references=True');scope={'__file__':str(original),'__name__':'forwarded_counts'};exec(compile(program,str(original),'exec'),scope);scope['count']('forwarded-'+raw.name+'-'+symbol,'forwarded',ns['training'],'_'+symbol,shape['pool']);(folder/'counts.json').rename(folder/'canonical-counts.json');counts=read(folder/'canonical-counts.json');assert counts['object_sha256']==sha(front/'program.o');atom=driver.symbols(front/'program.o')['symbols']['_'+symbol];assert all(atom[k]==shape['atom'][k] for k in ['extent','sha256','relocations']);delta=shape['atom']['start']-atom['start']
 for case in counts['cases'].values():
  for block in case['blocks']:block['address']=hex(int(block['address'],16)+delta)
 counts.update(object_sha256=sha(raw/'frontend/program.o'),canonical_counts_sha256=sha(folder/'canonical-counts.json'),address_translation=delta);(folder/'counts.json').write_text(json.dumps(counts,indent=2)+'\n');(folder/'plan.json').write_text(json.dumps({'untimed':True,'source_object_sha256':sha(raw/'frontend/program.o'),'diagnostic_object_sha256':sha(front/'program.o'),'source_worker_sha256':sha(raw/'bound/mech-worker'),'canonical_worker_sha256':sha(target/'mech-worker'),'address_translation':delta,'cases':ns['training'],'diagnostic_counter_source':program},indent=2)+'\n');return folder,shape

training=emit('training',base|{'MECH_INSPECT_PHASE_REGISTER_PROFILE':str(O/'training'/(MF+'.vcode'))})
folder,shape=count(training,MF)
# The published portable derivation expects this path name; preserve one exact copy.
shutil.copytree(folder,training/'block-counts-475')
public=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/benchmarks/mech-deflate/native-profile/native-compact-20261116/evidence/measured-register-weight-study');sys.path.insert(0,str(public));from derive_register_weights import derive
profiles=O/'register-profiles';profiles.mkdir()
for mode,profile in derive(training).items():(profiles/(mode+'.json')).write_text(json.dumps(profile,indent=2)+'\n')
folder,hfshape=count(training,HF);hfprofile=ns['profile_matcher'](str(folder),hfshape,folder)
for mode in ['linear','sqrt']:
 flags=base|{'MECH_COMPACT_PHASE_REGISTER_WEIGHTS':MF+'@'+str(profiles/(mode+'.json'))};raw=emit(mode+'-raw',flags);folder,shape=count(raw,MF);mfprofile=ns['profile_matcher'](str(folder),shape,folder);a=read(training/'receipt.json')['layout']['symbols']['_'+HF];b=read(raw/'receipt.json')['layout']['symbols']['_'+HF];assert all(a[k]==b[k] for k in ['extent','sha256','relocations']);final=emit(mode+'-profiled',flags|{'MECH_COMPACT_PHASE_BLOCK_LAYOUT':kept+';'+HF+'@'+str(hfprofile)+';'+MF+'@'+str(mfprofile)});rr=read(final/'receipt.json');checked=final/'checked-emission';cmd=[compiler,r['command'][1],str(checked/'frontend'),'compact']
 with (final/'checked.log').open('w') as log:subprocess.run(cmd,env=env|rr['flags']|{'MECH_COMPACT_PAIR_REGISTER_SPILLS':'checked'},stdout=log,stderr=log,check=True)
 assert {f:sha(checked/'frontend'/f) for f in rr['artifacts']}==rr['artifacts'];print(mode,'fresh register/layouts and checked exact',flush=True)
(O/'state.json').write_text(json.dumps({'complete':True,'codec_source_changed':False,'timing_performed':False,'fresh_machine_and_register_profiles':True},indent=2)+'\n')
