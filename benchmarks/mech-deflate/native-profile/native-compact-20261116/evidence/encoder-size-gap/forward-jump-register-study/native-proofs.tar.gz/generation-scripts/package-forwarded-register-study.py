"""Archive compact recipes, all adverse observations and the current CFG census."""
from pathlib import Path
from hashlib import sha256
import gzip,io,json,tarfile
N=Path(__file__).resolve().parent;S=N/'forwarded-register-study';Q=N.parent.parent
P=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/benchmarks/mech-deflate/native-profile/native-compact-20261116');O=P/'evidence/encoder-size-gap/forward-jump-register-study';read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();archives={}
def tree(members,source,prefix):
 for file in source.rglob('*'):
  if file.is_file() and '__pycache__' not in file.parts and file.name not in ['compile_profile','package.log']:members[prefix+'/'+str(file.relative_to(source))]=file
def archive(name,members):
 pins={}
 with (O/name).open('wb') as stream,gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as tar:
   for name_in_tar,path in sorted(members.items()):
    assert not name_in_tar.startswith('/') and '..' not in Path(name_in_tar).parts
    data=path if isinstance(path,bytes) else path.read_bytes();entry=tarfile.TarInfo(name_in_tar);entry.size=len(data);entry.mode=0o644;entry.mtime=0;tar.addfile(entry,io.BytesIO(data));pins[name_in_tar]=sha256(data).hexdigest()
 archives[name]={'sha256':sha(O/name),'bytes':(O/name).stat().st_size,'members':pins}
native={};tree(native,S,'study')
for file in N.glob('*forwarded*register*.py'):native['generation-scripts/'+file.name]=file
native['generation-scripts/count-selected-forwarder-control.py']=N/'count-selected-forwarder-control.py'
native['comparison-sources/main.c']=Q/'minimal-deployment/source/main.c';archive('native-proofs.tar.gz',native)
raw={'runtime/fixtures-original.json':Q/'fixtures.json','runtime/C-oracle.json':Q/'pinned-peers/libdeflate-output-oracle.json','runtime/working-selection-policy.json':S/'working-selection-policy-as-run.json'};portable={}
for fixture in read(Q/'fixtures.json'):
 portable[fixture['name']]={}
 for tag in ['input','prefix','expected']:
  file=Path(fixture[tag]);pin=sha(file);relative='runtime/fixture-data/'+pin+'.bin';raw[relative]=file;portable[fixture['name']][tag]={'member':relative,'sha256':pin}
raw['runtime/fixtures-portable.json']=(json.dumps(portable,indent=2)+'\n').encode()
for role in ['linear','sqrt']:
 for order in ['forward','reverse']:
  name='forwarded-register-'+role+'-'+order;tree(raw,Q/name,'runtime/'+name)
archive('panel-runtime-raw.tar.gz',raw)
for role in ['linear']:
 members={}
 for order in ['forward','reverse']:
  name='forwarded-register-'+role+'-full96-'+order;tree(members,Q/name,'runtime/'+name)
 archive('full-runtime-'+role+'.tar.gz',members)
builds={};tree(builds,N/'forwarded-register-matched-builds','builds');archive('complete-builds.tar.gz',builds)
summary={'selected_default_changed':read(S/'promotion.json')['selected_default_changed'],'promotion':read(S/'promotion.json'),'old_selected_Roc_wins':81,'old_selected_C_wins':63,'next_C_target':64,'ultimate_C_target':81,'codec_source_changed':False,'source_lines':2719,'confidence_assessed':False,'compiler_feature_commit':'5b3a4af26c0d39775580ca868e62af36f0049ae2','panels':{role:read(S/(role+'-timing-results.json')) for role in ['linear','sqrt']},'full_qualification':{'linear':read(S/'linear-full96-results.json')},'builds':read(N/'forwarded-register-matched-builds/summary.json'),'public_native_replays':4,'archives':archives,'scope':'Existing generic empty-jump forwarding, fresh register spill weights and MF/HF layouts on unchanged original2719line source. Both panelorders and all adverse observations retained. Onlylinear has full81qualification, every namedwinchecked; confidence separate. Actualmain source paths checked; promotion recorded separately.'};(O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');(O/'archives.json').write_text(json.dumps(archives,indent=2)+'\n');print(json.dumps({k:{a:b for a,b in v.items() if a!='members'} for k,v in archives.items()},indent=2))
