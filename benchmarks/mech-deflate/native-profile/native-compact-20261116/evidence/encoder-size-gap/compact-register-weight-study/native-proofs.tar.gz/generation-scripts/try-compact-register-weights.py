"""Try exact-identity profile reuse on the unchanged original codec."""
from pathlib import Path
from hashlib import sha256
import json,os,subprocess
N=Path(__file__).resolve().parent;O=N/'compact-register-weights';O.mkdir()
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
baseline=read(N/'narrow-packet-eight-probe-profiled/receipt.json');build=read(N/'measured-register-weights/compiler-build-v5/build.json');compiler=build['compiler'];assert sha(compiler)==build['compiler_sha256'];source=Path(baseline['command'][1]);assert sha(source)=='653597f08f889908c48610e90aa65e94a77847fb34500d0cc3a046f83cd3d299'
plan={'compiler_sha256':sha(compiler),'source_sha256':sha(source),'codec_source_changed':False,'source_lines':2719,'control':'m1-narrow-packet-words,63804B,81Roc/63C','hypothesis':'The generic register-weighting gain may combine with the smaller original codec and the previously retained carried-low-cost proof. Only reuse the profile when complete lowered VCode matches. No weaker identity check or unchecked machine-profile transfer.','arms':['selected-linear','selected-sqrt','phis-linear','phis-sqrt'],'next_C_target':64,'ultimate_C_target':81};(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
script=N/'count-current-semantic-matcher.py';ns={'__file__':str(script),'__name__':'compact_register_reuse'};exec(compile(script.read_text().split('\nsource_shapes={}')[0],str(script),'exec'),ns);driver=ns['driver'];env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')};results=[]
for carry in ['selected','phis']:
 for model in ['linear','sqrt']:
  role=carry+'-'+model;out=O/role;out.mkdir();flags=dict(baseline['flags']);flags['MECH_COMPACT_PHASE_BLOCK_LAYOUT']=';'.join(v for v in flags['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].split(';') if not v.startswith('mech_compact_numeric_475_vector@'));profile=N/'measured-register-weights/profiles-v5'/(model+'.json');flags['MECH_COMPACT_PHASE_REGISTER_WEIGHTS']='mech_compact_numeric_475_vector@'+str(profile)
  if carry=='phis':flags['MECH_FOLD_NARROW_PACKED_WORDS']='phis'
  cmd=[compiler,str(source),str(out/'frontend'),'compact']
  with (out/'compile.log').open('w') as log:status=subprocess.run(cmd,env=env|flags,stdout=log,stderr=log)
  result={'role':role,'exit_code':status.returncode,'command':cmd,'flags':flags,'register_profile_sha256':sha(profile),'compiler_sha256':sha(compiler),'source_sha256':sha(source)}
  if status.returncode==0:
   artifacts={f:sha(out/'frontend'/f) for f in baseline['artifacts']};assert artifacts['program.mecb']==baseline['artifacts']['program.mecb'];layout=driver.symbols(out/'frontend/program.o');result|={'identity_matched':True,'artifacts':artifacts,'layout':layout,'text_bytes':layout['text_bytes']};(out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(role,'accepted fullVCode; text',result['text_bytes'],flush=True)
  else:
   message=[line for line in (out/'compile.log').read_text().splitlines() if 'Unsupported feature:' in line];result|={'identity_matched':False,'diagnostic':message};print(role,'rejected',message[:1],flush=True)
  results.append(result);(O/'direct-reuse-results.json').write_text(json.dumps(results,indent=2)+'\n')
