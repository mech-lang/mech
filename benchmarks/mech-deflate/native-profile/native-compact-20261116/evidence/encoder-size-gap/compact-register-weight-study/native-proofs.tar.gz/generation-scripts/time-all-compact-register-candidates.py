from pathlib import Path
import subprocess
N=Path(__file__).resolve().parent;O=N/'compact-register-weights'
for mode in ['selected-linear','selected-sqrt','phis-linear','phis-sqrt']:
    print('starting quiet runtime',mode,flush=True)
    with (O/(mode+'-timing.log')).open('w') as log:subprocess.run(['python3',str(N/'time-compact-register-candidate.py'),mode],stdout=log,stderr=log,check=True)
    print('completed',mode,flush=True)
