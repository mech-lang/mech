from pathlib import Path
import subprocess
N=Path(__file__).resolve().parent;O=N/'compact-register-weights'
for role in ['phis-linear','phis-sqrt']:
    print('starting quiet full81/96',role,flush=True)
    with (O/(role+'-full96.log')).open('w') as log:subprocess.run(['python3',str(N/('qualify-compact-'+role+'-full96.py'))],stdout=log,stderr=log,check=True)
    print('completed',role,flush=True)
