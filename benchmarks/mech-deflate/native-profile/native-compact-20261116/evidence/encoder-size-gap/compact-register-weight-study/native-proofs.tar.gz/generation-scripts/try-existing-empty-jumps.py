"""Untimed current-source retest of the existing forward-jump cleanup."""
from pathlib import Path
from hashlib import sha256
import json,os,subprocess,re
N=Path(__file__).resolve().parent;O=N/'compact-register-weights/forwarding-census';read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();r=read(N/'narrow-packet-eight-probe-profiled/receipt.json');compiler=read(N/'measured-register-weights/compiler-build-v5/build.json')['compiler'];env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}
p=N/'count-current-semantic-matcher.py';ns={'__file__':str(p),'__name__':'current_empty_jump_retest'};exec(compile(p.read_text().split('\nsource_shapes={}')[0],str(p),'exec'),ns);driver=ns['driver'];records=[]
for role in ['control','empty-jumps']:
 out=O/role;out.mkdir();flags={k:v for k,v in r['flags'].items() if k!='MECH_COMPACT_PHASE_BLOCK_LAYOUT'};flags['MECH_INSPECT_OPTIMIZED_PHASE_CLIF']=str(out/'mech_compact_numeric_475_vector.clif')
 if role=='empty-jumps':flags['MECH_COMPACT_SKIP_EMPTY_JUMPS']='vector'
 cmd=[compiler,r['command'][1],str(out/'frontend'),'compact']
 with (out/'compile.log').open('w') as log:subprocess.run(cmd,env=env|flags,stdout=log,stderr=log,check=True)
 artifacts={f:sha(out/'frontend'/f) for f in r['artifacts']};assert artifacts['program.mecb']==r['artifacts']['program.mecb'];layout=driver.symbols(out/'frontend/program.o');text=(out/'mech_compact_numeric_475_vector.clif').read_text();matches=list(re.finditer(r'^block(\d+)(?:\(([^\n]*)\))?[^\n]*:',text,re.M));blocks=[]
 for i,m in enumerate(matches):
  body=text[m.end():matches[i+1].start() if i+1<len(matches) else text.rfind('}')];lines=[v.strip().split(';')[0].strip() for v in body.splitlines()];ops=[v for v in lines if v and not re.fullmatch(r'v\d+ -> v\d+',v)];single_jump=len(ops)==1 and ops[0].startswith('jump block');params=re.findall(r'v\d+: \w+',m.group(2) or '');blocks.append({'block':int(m.group(1)),'parameters':len(params),'instructions':len(ops),'single_jump':single_jump,'jump':ops[0] if single_jump else None})
 item={'role':role,'command':cmd,'flags':flags,'compiler_sha256':sha(compiler),'artifacts':artifacts,'text_bytes':layout['text_bytes'],'layout':layout,'prepared_blocks':len(blocks),'single_jump_blocks':sum(b['single_jump'] for b in blocks),'argument_free_single_jump_blocks':sum(b['single_jump'] and b['parameters']==0 for b in blocks),'parameterized_single_jump_blocks':sum(b['single_jump'] and b['parameters']>0 for b in blocks),'blocks':blocks};(out/'receipt.json').write_text(json.dumps(item,indent=2)+'\n');records.append(item);print(role,{k:item[k] for k in ['text_bytes','prepared_blocks','single_jump_blocks','argument_free_single_jump_blocks','parameterized_single_jump_blocks']},flush=True)
(O/'existing-forwarder-results.json').write_text(json.dumps(records,indent=2)+'\n')
