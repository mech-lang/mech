"""Transfer layout only for byte-identical relocation-free matcher atoms."""
from pathlib import Path
from hashlib import sha256
import json,os,subprocess
N=Path(__file__).resolve().parent;O=N/'compact-register-weights';read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')};symbol='mech_compact_numeric_475_vector'
p=N/'count-current-semantic-matcher.py';ns={'__file__':str(p),'__name__':'compact_register_layouts'};exec(compile(p.read_text().split('\nsource_shapes={}')[0],str(p),'exec'),ns);driver=ns['driver'];proofs=[]
for role in ['selected-linear','selected-sqrt','phis-linear','phis-sqrt']:
 raw=O/role;r=read(raw/'receipt.json');model=role.split('-')[1];previous=N/'measured-register-weights'/(model+'-unprofiled-v5');old=read(previous/'receipt.json');a=r['layout']['symbols']['_'+symbol];b=old['layout']['symbols']['_'+symbol]
 assert {k:a[k] for k in ['extent','sha256','relocations']}=={k:b[k] for k in ['extent','sha256','relocations']} and not a['relocations']
 final_previous=read(N/'measured-register-weights'/('hybrid32-register-'+model+'-profiled/receipt.json'));profiles=[x for x in final_previous['flags']['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].split(';') if x.startswith(symbol+'@')];assert len(profiles)==1
 profile=Path(profiles[0].split('@')[1]);flags=r['flags']|{'MECH_COMPACT_PHASE_BLOCK_LAYOUT':r['flags']['MECH_COMPACT_PHASE_BLOCK_LAYOUT']+';'+symbol+'@'+str(profile)};out=O/(role+'-profiled');out.mkdir();cmd=[r['command'][0],r['command'][1],str(out/'frontend'),'compact']
 with (out/'compile.log').open('w') as log:subprocess.run(cmd,env=env|flags,stdout=log,stderr=log,check=True)
 artifacts={f:sha(out/'frontend'/f) for f in r['artifacts']};assert artifacts['program.mecb']==r['artifacts']['program.mecb'];layout=driver.symbols(out/'frontend/program.o');receipt=r|{'command':cmd,'compile':cmd,'flags':flags,'artifacts':artifacts,'layout':layout,'text_bytes':layout['text_bytes'],'object_sha256':artifacts['program.o'],'metadata_sha256':artifacts['metadata.json'],'bytecode_sha256':artifacts['program.mecb']};(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 checked=out/'checked-emission';cmd2=[cmd[0],cmd[1],str(checked/'frontend'),'compact']
 with (out/'checked.log').open('w') as log:subprocess.run(cmd2,env=env|flags|{'MECH_COMPACT_PAIR_REGISTER_SPILLS':'checked'},stdout=log,stderr=log,check=True)
 assert artifacts=={f:sha(checked/'frontend'/f) for f in artifacts};driver.link.link_worker(N/'narrow-packet-eight-probe-profiled/bound',out/'frontend',out/'bound');driver.link.check_worker(out/'bound','compact-register-'+role)
 runtime=read(out/'bound/runtime.json');runtime['encoder_text_bytes']=receipt['text_bytes'];(out/'bound/runtime.json').write_text(json.dumps(runtime,indent=2)+'\n')
 proofs.append({'role':role,'original_source_sha256':r['source_sha256'],'old_raw_object_sha256':old['artifacts']['program.o'],'new_raw_object_sha256':r['artifacts']['program.o'],'old_atom':b,'new_atom':a,'layout_profile_sha256':sha(profile),'layout_profile':str(profile),'proof':'Exact complete VCode accepted by compiler, then exact raw matcher bytes/extent and empty relocation lists. Function-relative layout profile applies to this identical atom; normal/checked final objects match.'});print(role,'finaltext',receipt['text_bytes'],'all3 normal/checked exact;162 outputs pass',flush=True)
(O/'layout-transfer-proof.json').write_text(json.dumps(proofs,indent=2)+'\n')
