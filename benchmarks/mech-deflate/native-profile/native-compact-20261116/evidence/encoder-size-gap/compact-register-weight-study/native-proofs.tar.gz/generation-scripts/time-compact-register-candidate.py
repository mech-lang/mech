"""Both21case24block orders, after native gates; no concurrent producers."""
from pathlib import Path
from hashlib import sha256
import json,os,sys
N=Path(__file__).resolve().parent;Q=N.parent.parent;O=N/'compact-register-weights';mode=sys.argv[1];assert mode in ['selected-linear','selected-sqrt','phis-linear','phis-sqrt']
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
timer=Q/'compare-library.py';control=N/'narrow-packet-eight-probe-profiled/bound';candidate=O/(mode+'-profiled/bound')
cases=['one-stored','seven-stored-prefix','empty','eight-overlap','320-overlap','prefix-periodic-1024','prefix-natural-1024','prefix-natural-4096','prefix-natural-8192','prefix-random-1024','prefix-random-4096','prefix-random-8192','prefix-random-16384','prefix-random-32767','prefix-random-32768','prefix-random-32769','prefix-random-65535','prefix-random-65536','prefix-random-65537','prefix-random-1048576','16384-distribution-change']
gate=read(O/(mode+'-profiled/linked-proof.json'));assert gate['candidate_peak_stack_bytes']<=5280
assert read(O/(mode+'-profiled/promotion-recoveries/result.json'))['benchmark_worker_sha256']==sha(candidate/'mech-worker')
plan={'cases':cases,'orders':['forward','reverse'],'actors':{'mech-control':str(control),'mech-experiment':str(candidate),'roc':'pinned','libdeflate':'pinnedC12'},'register_weight_mode':mode,'blocks_per_case':24,'timer_sha256':sha(timer),'controller_sha256':sha(Path(__file__)),'worker_sha256':{'control':sha(control/'mech-worker'),'candidate':sha(candidate/'mech-worker')},'scope':'Complete fresh heap/context call through cleanup, all24fouractorpermutations, both21caseorders. Selected original2719line codec versus the identical source with measured register spill weights, optionally combined with the previously retained carried-low-cost proof. Complete VCode identity and byte-identical matcher layout transfer verified. Both21caseorders/all24permutations. Every reported slowdown and loss retained. No full81claim.','load_before':os.getloadavg()}
(O/(mode+'-timing-plan.json')).write_text(json.dumps(plan,indent=2)+'\n')
program=timer.read_text();before="selected = {case['name'] for case in cases}";assert program.count(before)==1;program=program.replace(before,'selected = '+repr(set(cases)))
runs=[]
for order in plan['orders']:
    label='compact-register-'+mode+'-'+order;sys.argv=[str(timer),label,str(control),str(candidate)]+(['reverse'] if order=='reverse' else [])
    exec(compile(program,str(timer),'exec'),{'__file__':str(timer),'__name__':'__main__'})
    rows=read(Q/label/'summary.json');assert len(rows)==21
    runs.append({'order':order,'run':str(Q/label),'summary_sha256':sha(Q/label/'summary.json'),'results':rows})
    (O/(mode+'-timing-results.json')).write_text(json.dumps({'plan':plan,'runs':runs,'complete':len(runs)==2},indent=2)+'\n')
    print('Finished',order,'all21cases/all24blocks',flush=True)
