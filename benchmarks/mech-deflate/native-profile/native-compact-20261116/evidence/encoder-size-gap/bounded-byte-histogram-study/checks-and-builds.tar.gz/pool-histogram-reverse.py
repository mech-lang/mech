"""Strict named-win checks; retain original reverse96 plus fresh reverse192."""
from pathlib import Path
from hashlib import sha256
import json,gzip,sys
N=Path(__file__).resolve().parent;Q=N.parent.parent;P=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/benchmarks/mech-deflate/native-profile/native-compact-20261116');sys.path.insert(0,str(P));import qualification_timings as t
from qualification_records import Evidence,Findings,load_fixtures
read=lambda p:json.loads(p.read_text());sha=lambda p:sha256(p.read_bytes()).hexdigest();policy=read(P/'qualification-policy-v3.json');fixtures=load_fixtures(Evidence(P,Findings()),policy);record=read(N/'bounded-histogram-word/full/full-replay.json');plan=read(N/'bounded-histogram-word/full/plan.json');findings=Findings();evidence=Evidence(Q,findings);original=[]
for entry in plan['runs']:
 run=t.runtime_run(record['receipts'][entry['id']],fixtures,evidence,plan['identities'],policy,entry);assert run;original.append(run)
repeat=read(N/'bounded-histogram-reverse192/result.json');assert repeat['complete'];folder=Path(repeat['folder']);pins=read(folder/'pins.json');assert read(folder/'complete.json')['balanced_blocks_per_case']==192
for actor,key in [('mech-control','control_worker_sha256'),('mech-experiment','candidate_worker_sha256')]:assert pins['actors'][actor]['binary_sha256']==repeat['plan'][key]==plan['identities'][actor]['worker']
new={}
for row in repeat['results']:
 name=row['case'];raw=json.loads(gzip.decompress((folder/name/'observations.json.gz').read_bytes()));new[name]=t.case_blocks(raw,fixtures[name],192)[0]
assert set(new)==set(fixtures)
required=read(N/'word-complements-prior-wins.json')['required_previous_individual_wins']
def evaluate(groups):
 out={}
 for peer in ['roc','libdeflate']:
  rows={};unsupported=[]
  for index,name in enumerate(fixtures):
   if name not in required[peer]:continue
   strata=[]
   for group in groups:strata.extend(t.paired(group[name],'mech-experiment',peer))
   ci=t.interval(strata,index,policy);rows[name]=ci
   if ci['estimate']>=0 or ci['upper']>=0:unsupported.append(name)
  out[peer]={'required':len(rows),'supported':len(rows)-len(unsupported),'unsupported':unsupported,'intervals':rows}
 return out
report={'source_commit':'7ea6c80d8db874e10392bdb2a3d38e6205ca876d','candidate_worker_sha256':plan['identities']['mech-experiment']['worker'],'original_record_sha256':sha(N/'bounded-histogram-word/full/full-replay.json'),'repeat_result_sha256':sha(N/'bounded-histogram-reverse192/result.json'),'forward96':evaluate([original[0]['cases']]),'original_reverse96':evaluate([original[1]['cases']]),'repeat_reverse192':evaluate([new]),'pooled_reverse288':evaluate([original[1]['cases'],new]),'scope':'Every original observation retained. Pooled reverse resamples blocks separately within each acquisition and numerator/denominator actor order. Required named wins are those of the prior qualified reference; this is not an aggregate-count substitution.'}
report['all_previous_individual_wins_in_both_orders']=all(not report[k][peer]['unsupported'] for k in ['forward96','pooled_reverse288'] for peer in ['roc','libdeflate']);assert findings.rejected==findings.unresolved==[]
(N/'bounded-histogram-pooled-individual-wins.json').write_text(json.dumps(report,indent=2)+'\n')
for key in ['forward96','original_reverse96','repeat_reverse192','pooled_reverse288']:print(key,{p:{k:v for k,v in report[key][p].items() if k!='intervals'} for p in ['roc','libdeflate']},flush=True)
print('All previous individual wins in both orders:',report['all_previous_individual_wins_in_both_orders'],flush=True)
