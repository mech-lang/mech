from pathlib import Path
from hashlib import sha256
from runpy import run_path
import json,os,subprocess
N=Path(__file__).resolve().parent;Q=N.parent.parent;read=lambda p:json.loads(p.read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();build=read(N/'bounded-histogram-compiler/build.json');compiler=build['compiler'];assert sha(compiler)==build['compiler_sha256'];tool=run_path(str(Q/'current-roadmap/scorer-runtime/emit.py'),run_name='bounded_histogram_symbols')
for role,base,enabled in [('bounded-histogram-disabled-control','word-current-complements-profiled',False),('bounded-histogram-word','word-current-complements-profiled',True),('bounded-histogram-vector','vector-mismatch-narrow-profiled',True),('bounded-histogram-first-word','first-word-complements-profiled',True)]:
 old=read(N/base/'receipt.json');out=N/role;out.mkdir();flags=old['flags'].copy()
 if enabled:flags['MECH_BOUNDED_BYTE_HISTOGRAM']='1'
 command=[compiler,old['compile'][1],str(out/'frontend'),'compact']
 with (out/'compile.log').open('w') as log:r=subprocess.run(command,env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}|flags,stdout=log,stderr=log)
 assert r.returncode==0,(out/'compile.log').read_text()[-5000:]
 artifacts={name:sha(out/'frontend'/name) for name in ['program.o','metadata.json','program.mecb']};assert artifacts['program.mecb']==old['artifacts']['program.mecb'];layout=tool['symbols'](out/'frontend/program.o')
 def walk(x):
  if isinstance(x,dict):
   if 'bounded_byte_histogram' in x:yield {'header':x.get('header'),'proof':x['bounded_byte_histogram']}
   for v in x.values():yield from walk(v)
  elif isinstance(x,list):
   for v in x:yield from walk(v)
 admitted=list(walk(read(out/'frontend/metadata.json')))
 if not enabled:assert artifacts==old['artifacts']
 else:assert admitted,(role,'no proof admitted')
 receipt={'source_base':build['source_base'],'source_inputs':build['source_sha256'],'compiler_sha256':build['compiler_sha256'],'compile':command,'command':command,'flags':flags,'artifacts':artifacts,'object_sha256':artifacts['program.o'],'metadata_sha256':artifacts['metadata.json'],'bytecode_sha256':artifacts['program.mecb'],'text_bytes':layout['text_bytes'],'layout':layout,'bounded_histogram':admitted,'runtime_qualification':'pending'};(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(role,layout['text_bytes'],admitted,flush=True)
