from pathlib import Path
from hashlib import sha256
import gzip,io,json,tarfile,shutil
N=Path(__file__).resolve().parent;Q=N.parent.parent;W=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP');P=W/'benchmarks/mech-deflate/native-profile/native-compact-20261116';E=P/'evidence/encoder-size-gap/bounded-byte-histogram-study';E.mkdir(exist_ok=True);read=lambda p:json.loads(p.read_text());sha=lambda p:sha256(p.read_bytes()).hexdigest()
R=N/'bounded-histogram-word';r=read(R/'receipt.json');runtime=read(R/'bound/runtime.json');full=read(R/'full/full-replay.json');strict=read(N/'bounded-histogram-pooled-individual-wins.json');assert strict['all_previous_individual_wins_in_both_orders'];assert read(N/'bounded-histogram-word-checked/result.json')['matches'];assert read(R/'promotion-recoveries/result.json')['exact_recoveries']==12
for name in ['program.o','metadata.json']:(E/(name+'.gz')).write_bytes(gzip.compress((R/'frontend'/name).read_bytes(),mtime=0))
for name in ['mech-worker','metadata.json','runtime.json']:(E/('worker-'+name+'.gz')).write_bytes(gzip.compress((R/'bound'/name).read_bytes(),mtime=0))
profiles=[]
for item in r['flags']['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].split(';'):
 symbol,path=item.split('@',1);target=E/'profiles'/(symbol+'.json');target.parent.mkdir(exist_ok=True);shutil.copy2(path,target);profiles.append({'symbol':symbol,'path':str(target.relative_to(E)),'sha256':sha(target)})
build=read(N/'bounded-histogram-compiler/build.json');candidate={'recipe':'m1-bounded-byte-histogram','source_base':build['source_base'],'source_integration_commit':'7ea6c80d8db874e10392bdb2a3d38e6205ca876d','compiler_sha256':build['compiler_sha256'],'source_sha256':sha(P/'program.mec'),'artifact_sha256':r['artifacts'],'encoder_text_bytes':r['text_bytes'],'native_flags_as_run':r['flags'],'profiles':profiles,'override_flags':{k:v for k,v in r['flags'].items() if k!='MECH_COMPACT_PHASE_BLOCK_LAYOUT'},'remove_flags':['MECH_COMPACT_ROOT_TAIL_PROFILE'],'source_inputs':build['source_sha256'],'worker_sha256':runtime['worker_sha256'],'peak_stack_bytes':4864,'runtime_wins':{'roc':[81,81],'libdeflate':[62,62]},'blocks_per_order':{'forward':96,'reverse':288},'reverse_acquisitions':[96,192],'scope':'All prior individual point and confidence wins: forward96 and reverse288 pooled by acquisition and actor order. The original reverse96 had2 uncertain Roc comparisons; its complete192-block repeat independently supports81/62, and all288 reverse blocks are retained. No63rd Cwin; original codec and bytecode unchanged.'}
for name in ['candidate.json','emission.json']:(E/name).write_text(json.dumps(candidate,indent=2)+'\n')
files={}
for folder in ['bounded-histogram-word/full','bounded-histogram-word/promotion-recoveries','bounded-histogram-word-checked','bounded-histogram-repository-tests','bounded-histogram-compiler','bounded-histogram-full24','bounded-histogram-reverse192','bounded-histogram-matched-builds','bounded-histogram-word/instruction-counts-histogram']:
 for p in (N/folder).rglob('*'):
  if p.is_file() and p.suffix in ['.json','.jsonl','.log','.rs','.py','.clif','.vcode'] and '/compiler/' not in str(p):files[str(p.relative_to(N))]=p
for role in ['bounded-histogram-disabled-control','bounded-histogram-word','bounded-histogram-vector','bounded-histogram-first-word']:
 for name in ['receipt.json','linked-proof.json']:
  if (N/role/name).exists():files[role+'/'+name]=N/role/name
 if (N/role/'linked-proof.json').exists():
  proof=read(N/role/'linked-proof.json');p=Path(proof['result']);assert sha(p)==proof['sha256'];files[str(p.relative_to(N))]=p
for name in ['word-complements-prior-wins.json','bounded-histogram-pooled-individual-wins.json','bounded-histogram-reverse-variance.json','bounded-histogram-screen-bounded-histogram-word-results.json','bounded-histogram-screen-bounded-histogram-word-plan.json','emit-bounded-histogram.py','count-bounded-histogram.py','full24-bounded-histogram.py','qualify-bounded-histogram-full.py','repeat-histogram-reverse-precision.py','pool-histogram-reverse.py','measure-bounded-histogram-builds.py','run-bounded-histogram-tests.py','build-bounded-histogram-compiler.py','recover-vector-word-candidate.py','publish-bounded-histogram.py']:files[name]=N/name
for name in ['qualification-policy-v3.json','qualification_records.py','qualification_timings.py']:files['qualification-source/'+name]=P/name
files['compare-library.py']=Q/'compare-library.py'
raw={};folders=[Q/entry['id'] for entry in full['runs']]+[Path(row['folder']) for row in read(N/'bounded-histogram-full24/result.json')['runs']]+[Path(read(N/'bounded-histogram-reverse192/result.json')['folder'])]+[Path(row['run']) for row in read(N/'bounded-histogram-screen-bounded-histogram-word-results.json')['runs']]
for root in folders:
 for p in root.rglob('*'):
  if p.is_file() and (p.name in ['observations.json.gz','summary.json','complete.json','pins.json'] or p.suffix=='.stderr'):raw[str(Path(root.name)/p.relative_to(root))]=p

def archive(path,members):
 pins={}
 with path.open('wb') as stream,gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0) as gz,tarfile.open(mode='w',fileobj=gz) as tar:
  for name,p in sorted(members.items()):
   data=p.read_bytes();entry=tarfile.TarInfo(name);entry.size=len(data);entry.mtime=0;entry.mode=0o644;tar.addfile(entry,io.BytesIO(data));pins[name]={'bytes':len(data),'sha256':sha256(data).hexdigest()}
 return pins
manifest={'checks-and-builds.tar.gz':archive(E/'checks-and-builds.tar.gz',files),'raw-runtime.tar.gz':archive(E/'raw-runtime.tar.gz',raw)};(E/'archive-files.json').write_text(json.dumps(manifest,indent=2)+'\n')
result={'candidate':candidate,'decision':'Retain','strict_individual_wins':strict,'previous_compact_reference':{'text_bytes':63388,'worker_sha256':'fab303151eca902a95986488684102fc1707ec7f8df1324ebfd9c55543cfc368'},'text_bytes_added':224,'build':read(N/'bounded-histogram-matched-builds/summary.json'),'no_new_c_win':True,'original_full':full['runs']};(E/'result.json').write_text(json.dumps(result,indent=2)+'\n');shutil.copy2(P/'evidence/encoder-size-gap/word-complement-current-read-study/reproduce.py',E/'reproduce.py');print('Published histogram package',len(files),'check/build files',len(raw),'raw files',flush=True)
