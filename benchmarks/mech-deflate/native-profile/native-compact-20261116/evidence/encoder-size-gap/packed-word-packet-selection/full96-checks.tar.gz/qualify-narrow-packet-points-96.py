"""Full 96-block qualification: all named prior wins plus natural4K, both orders."""
from pathlib import Path
from hashlib import sha256
import gzip,json,math,os,subprocess,sys
N=Path(__file__).resolve().parent;Q=N.parent.parent
W=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP');P=W/'benchmarks/mech-deflate/native-profile/native-compact-20261116'
sys.path.insert(0,str(P))
import qualification_timings as timing
from qualification_records import ACTORS,MECH,PEERS,CANDIDATE,Evidence,Findings,load_fixtures
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
write=lambda p,v:Path(p).write_text(json.dumps(v,indent=2)+'\n')
ref=lambda p:{'path':str(Path(p).relative_to(Q)),'sha256':sha(p)}
role=sys.argv[1];candidate=N/role/'bound';control=N/'narrow-eight-probe-profiled/bound'
required=read(P/'working-selection-policy.json')['required_peer_wins']
assert sha(control/'mech-worker')=='bb834bc0836f976612bd955a71ef753800820e1b515b08425db968d20c76e11a'
build=read(N/'narrow-packed-compiler/build.json');receipt=read(N/role/'receipt.json');assert receipt['compiler_sha256']==build['compiler_sha256']==sha(build['compiler'])
linked=read(N/role/'linked-proof.json');assert linked['peak_stack_bytes']<=5280 and sha(linked['result'])==linked['sha256']
out=N/('narrow-packed-qualified96-'+role);out.mkdir()
policy=read(P/'working-selection-policy.json');assert policy['peer_win_floors']=={'roc':81,'libdeflate':63};write(out/'policy.json',policy)
findings=Findings();fixtures=load_fixtures(Evidence(P,findings),policy);assert len(fixtures)==81 and not findings.rejected and not findings.unresolved
inventory=read(Q/'fixtures.json');assert [x['name'] for x in inventory]==list(fixtures)
content={}
for row in inventory:
 frozen=fixtures[row['name']]
 for field in ['input_sha256','expected_sha256','input_bytes','prefix_bytes','raw_bytes','capacity']:
  assert row[field]==frozen[field],(row['name'],field)
 content[row['name']]={field:sha(row[field]) for field in ['input','prefix','expected']}
 assert content[row['name']]=={field:sha(P/frozen[field]) for field in ['input','prefix','expected']}
write(out/'inventory-reconciliation.json',{'as_run_inventory_sha256':sha(Q/'fixtures.json'),'canonical_inventory_sha256':policy['fixture_inventory_sha256'],'content':content,'scope':'All81 temporary andcanonical input/prefix/expected files have identical bytes and geometry. The prefix basename differs. Preserve original pins and reconcile only canonical replay inventory digest, following full-timing.py.'})
environment={'cpu':subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip(),'os':subprocess.check_output(['sw_vers'],text=True).strip(),'architecture':os.uname().machine,'protocol':'Four actors, serial complete balanced permutations; 96 blocks per case; independent >=0.2s warmup; compression through private heap cleanup.'}
assert environment['cpu']=='Apple M1' and environment['architecture']=='arm64' and '15.6.1' in environment['os'];write(out/'environment.json',environment)
write(out/'contract.json',{'scope':'diagnostic','level':12,'timing_boundary':'compression through private heap cleanup','fixture_inventory_sha256':policy['fixture_inventory_sha256']})
peers=read(Q/'pinned-peers/pins.json')['actors'];identities={actor:{'worker':sha(folder/'mech-worker'),'metadata':sha(folder/'metadata.json')} for actor,folder in [('mech-control',control),('mech-experiment',candidate)]}
identities.update({actor:{'worker':peers[actor]['binary_sha256'],'metadata':peers[actor].get('metadata_sha256')} for actor in PEERS});identities.update(environment_sha256=sha(out/'environment.json'),contract_sha256=sha(out/'contract.json'))
timer=Q/'compare-library.py';prefix='narrow-packed-qualified96-'+role
plan={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),'compiler_build':ref(N/'narrow-packed-compiler/build.json'),'compiler_sha256':build['compiler_sha256'],'timer':ref(timer),'controller':ref(Path(__file__)),'policy':ref(out/'policy.json'),'policy_basis_sha256':sha(P/'working-selection-policy.json'),'required_previous_wins':required,'identities':identities,'linked_proof_sha256':linked['sha256'],'discovery_source':ref(N/'narrow-packed-selected63-discovery-narrow-eight-probe-profiled-results.json'),'as_run_fixture_inventory':ref(Q/'fixtures.json'),'environment':ref(out/'environment.json'),'contract':ref(out/'contract.json'),'candidate_artifacts':receipt['artifacts'],'runs':[{'id':prefix+'-'+order,'kind':'full','order':order,'blocks_per_case':96} for order in ['forward','reverse']],'promising_screen_admission':'Both21-case discovery orders are retained. The packet candidate has one narrow target point loss in one order and is still pursued for its additional48B saving. Both complete96 orders decide every81/63 named point requirement; confidence remains separate. The control is the selected63852B build.', 'scope':'Working selection follows the user-selected point rule:81 Roc and63 C plus every required named point win in both complete96 orders. Confidence is retained separately. All raw correctness, cleanup, artifact, inventory and host checks must pass. No automatic selection before replay.'};write(out/'plan.json',plan)
program=timer.read_text();needle='orders = list(permutations(commands))';assert program.count(needle)==1;program=program.replace(needle,needle+' * 4');hook="assert digest(FIXTURES) == pins['input_inventory_sha256']";assert program.count(hook)==1;bound={k:identities[k] for k in ['environment_sha256','contract_sha256']};program=program.replace(hook,hook+'\npins.update('+repr(bound)+')')
for key in list(os.environ):
 if key.startswith('MECH_'):del os.environ[key]
for run in plan['runs']:
 assert not (Q/run['id']).exists()
 sys.argv=[str(timer),run['id'],str(control),str(candidate)]+(['reverse'] if run['order']=='reverse' else [])
 exec(compile(program,str(timer),'exec'),{'__file__':str(timer),'__name__':'__main__'})
# All clocks are complete before raw-data replay or bootstrap computation.
print("All runtime clocks complete; replaying output, cleanup, pins and confidence bounds.",flush=True)
evidence=Evidence(Q,findings);runs=[];receipts=[];named=[]
canonical=out/'canonical-pins';canonical.mkdir(exist_ok=True)
for run in plan['runs']:
 folder=Q/run['id'];record=run|{'pins':ref(folder/'pins.json'),'summary':ref(folder/'summary.json'),'complete':ref(folder/'complete.json'),'fixture_inventory':ref(Q/'fixtures.json'),'observations':{f.parent.name:ref(f) for f in sorted(folder.glob('*/observations.json.gz'))},'cleanup':{actor:ref(folder/(actor+'.stderr')) for actor in ACTORS}}
 original=read(folder/'pins.json');reconciled=original|{'input_inventory_sha256':policy['fixture_inventory_sha256']};write(canonical/(run['id']+'.json'),reconciled);record.update(original_pins=record['pins'],pins=ref(canonical/(run['id']+'.json')),inventory_reconciliation=ref(out/'inventory-reconciliation.json'))
 actual=timing.runtime_run(record,fixtures,evidence,identities,policy,run);assert actual is not None;runs.append(actual);receipts.append(record)
 audit={}
 for peer in PEERS:
  cases={}
  for index,(name,ratios) in enumerate(actual['ratios'].items()):
   if name not in required[peer]:continue
   parts=timing.paired(actual['cases'][name],CANDIDATE,peer);largest=max(map(max,parts))
   interval=timing.interval(parts,index,policy) if largest>=0 else {'estimate':timing.estimate(parts),'lower':math.exp(min(map(min,parts)))-1,'upper':math.exp(largest)-1,'bound_method':'Every individual balanced block wins; enclosing observed block bounds, matching the v3 precision shortcut.'}
   cases[name]={'paired_x':ratios[peer][CANDIDATE],'interval':interval,'supported':ratios[peer][CANDIDATE]<1 and interval['upper']<0}
  assert set(cases)==set(required[peer]);audit[peer]={'cases':cases,'unsupported':[name for name,row in cases.items() if not row['supported']]}
 named.append({'id':run['id'],'order':run['order'],'peers':audit})
validation={'rejected':list(findings.rejected),'unresolved':list(findings.unresolved)}
point_runs=[]
for run in runs:
 peers={}
 for peer in PEERS:
  wins=[name for name,ratios in run['ratios'].items() if ratios[peer][CANDIDATE]<1]
  missing=sorted(set(required[peer])-set(wins))
  peers[peer]={'wins':len(wins),'required_missing':missing,'passed':len(wins)>=policy['peer_win_floors'][peer] and not missing}
 point_runs.append({'id':run['id'],'peers':peers})
passed=not validation['rejected'] and not validation['unresolved'] and all(peer['passed'] for run in point_runs for peer in run['peers'].values())
report=timing.decide_runtime(runs,[],policy,fixtures,findings)
confidence_passed=not findings.rejected and not findings.unresolved and all(not peer['unsupported'] for run in named for peer in run['peers'].values())
result={'passed':passed,'confidence_passed':confidence_passed,'raw_validation':validation,'point_runs':point_runs,'selection_basis':policy['selection_basis'],'complete':True,'plan_sha256':sha(out/'plan.json'),'receipts':receipts,'runtime_report':report,'named_win_audit':named,'rejected':findings.rejected,'unresolved':findings.unresolved,'qualified_selection_automatically_changed':False};write(out/'result.json',result)
print(json.dumps({'passed':passed,'confidence_passed':confidence_passed,'point_runs':point_runs,'runs':report['runs'],'named_unsupported':{run['order']:{peer:row['unsupported'] for peer,row in run['peers'].items()} for run in named},'rejected':findings.rejected,'unresolved':findings.unresolved},indent=2),flush=True)
