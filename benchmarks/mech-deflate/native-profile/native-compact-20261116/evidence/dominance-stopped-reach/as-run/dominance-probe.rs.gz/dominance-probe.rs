
use cranelift_codegen::cursor::{Cursor, FuncCursor};
use cranelift_codegen::dominator_tree::DominatorTree;
use cranelift_codegen::flowgraph::ControlFlowGraph;
use cranelift_codegen::ir::{Block, Function, InstBuilder, JumpTableData, types};
use std::{collections::BTreeMap, sync::Arc};

#[path = "reach-before.rs"]
mod reach;
use reach::Reachability;

fn candidate(
    dom: &DominatorTree,
    memo: &Reachability,
    owner: Block,
    target: Block,
    use_block: Block,
) -> Option<bool> {
    let mut reach = BTreeMap::<Block, Arc<Vec<bool>>>::new();
    // A fresh visit to the defining block ends the query.
    if owner == target {
        return Some(false);
    }
    let owner_dominates_target = dom.block_dominates(owner, target);
    let mut used = false;
    for &block in &[use_block] {
        if block == owner || !dom.is_reachable(block) {
            continue;
        }
        if owner_dominates_target && dom.block_dominates(target, block) {
            // A simple entry-to-use path visits owner before target and
            // cannot visit owner again. Its suffix proves the use is live.
            used = true;
            continue;
        }
        if !owner_dominates_target && dom.block_dominates(owner, block) {
            // A target-to-use path avoiding owner could be joined to an
            // entry-to-target path avoiding owner, contradicting dominance.
            continue;
        }
        // A remaining reachable use would lie outside a required
        // dominance region. Its stopped reachability must be checked.
        let reachable = reach.entry(owner).or_insert_with(|| {
            memo
                .reachable(target.as_u32() as usize, owner.as_u32() as usize)
        });
        if reachable[block.as_u32() as usize] {
            return None;
        }
    }

    Some(used)
}

fn check_successors(successors: Vec<Vec<usize>>) -> usize {
    let mut f = Function::new();
    let blocks = (0..successors.len()).map(|_| f.dfg.make_block()).collect::<Vec<_>>();
    let mut cursor = FuncCursor::new(&mut f);
    for (source, targets) in successors.iter().enumerate() {
        cursor.insert_block(blocks[source]);
        match targets.as_slice() {
            [] => {
                cursor.ins().return_(&[]);
            }
            [only] => {
                cursor.ins().jump(blocks[*only], &[]);
            }
            [first, tail @ ..] => {
                let dfg = &mut cursor.func.dfg;
                let default = dfg.block_call(blocks[*first], &[]);
                let others = tail
                    .iter()
                    .map(|target| dfg.block_call(blocks[*target], &[]))
                    .collect::<Vec<_>>();
                let table = cursor.func.create_jump_table(JumpTableData::new(default, &others));
                let selector = cursor.ins().iconst(types::I32, 0);
                cursor.ins().br_table(selector, table);
            }
        }
    }

    let cfg = ControlFlowGraph::with_function(&f);
    let dom = DominatorTree::with_function(&f, &cfg);
    let memo = Reachability::new(successors.clone());
    let mut queries = 0;
    for &owner in &blocks {
        for &target in &blocks {
            if !dom.is_reachable(target) {
                continue;
            }
            let reached = memo.reachable(target.as_u32() as usize, owner.as_u32() as usize);
            for &user in &blocks {
                let old = if reached[user.as_u32() as usize] {
                    (dom.block_dominates(target, user) && dom.block_dominates(owner, target))
                        .then_some(true)
                } else {
                    Some(false)
                };
                assert_eq!(old, candidate(&dom, &memo, owner, target, user),
                    "successors {successors:?}, owner {owner}, target {target}, use {user}");
                queries += 1;
            }
        }
    }
    queries
}

#[test]
fn dominance_matches_original_stopped_reachability() {
    let mut queries = 0;
    for bits in 0..512 {
        let graph: Vec<Vec<usize>> = (0..3)
            .map(|src| (0..3).filter(|dst| bits & (1 << (src * 3 + dst)) != 0).collect())
            .collect();
        queries += check_successors(graph);
    }
    let mut rng = 993u32;
    for size in 4..9 {
        for _ in 0..32 {
            let graph: Vec<Vec<usize>> = (0..size)
                .map(|_src| {
                    (0..size * 2)
                        .filter_map(|_| {
                            rng = rng.wrapping_mul(1664525).wrapping_add(1013904223);
                            (rng >> 30 == 0).then_some((rng >> 16) as usize % size)
                        })
                        .collect()
                })
                .collect();
            queries += check_successors(graph);
        }
    }
    eprintln!("checked {queries} queries against the original stopped search");
}
