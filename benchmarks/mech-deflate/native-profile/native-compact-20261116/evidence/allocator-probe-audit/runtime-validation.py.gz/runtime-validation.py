#!/usr/bin/env python3
"""Check the original and boxed all-thread test against the pinned tracker."""
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import tempfile

base = "d5bd13ddd3f5dfd97ee6118171c8674a511c04d0"
workspace = Path("/private/tmp/mech-shared-cold-epilogues.2L6obP")
scratch = Path(__file__).resolve().parent
exports = []
cargo_log = workspace / ".qualification/parser-cache-windows/integrated-cargo.jsonl"
for raw in cargo_log.read_text().splitlines():
    try:
        record = json.loads(raw)
    except ValueError:
        continue
    if record.get("reason") != "compiler-artifact":
        continue
    crate = record["target"]["name"]
    if crate in ("serde", "serde_json"):
        path, = [Path(name) for name in record["filenames"] if name.endswith(".rlib")]
        exports.append((crate, path))
assert sorted(name for name, _ in exports) == ["serde", "serde_json"], exports
deps_directory = exports[0][1].parent
assert all(path.is_file() and path.parent == deps_directory for _, path in exports)
source_root = "benchmarks/related-post-gen"
variants = {
    "baseline": subprocess.check_output(
        ["git", "show", f"{base}:{source_root}/check-measurement.rs"], cwd=workspace
    ),
    "boxed": (scratch / source_root / "check-measurement.rs").read_bytes(),
}
tracker = (scratch / source_root / "measurement.rs").read_bytes()
assert tracker == subprocess.check_output(
    ["git", "show", f"{base}:{source_root}/measurement.rs"], cwd=workspace
)

def replace_once(source, old, new):
    assert source.count(old) == 1
    return source.replace(old, new, 1)

annotation = b"""
// Diagnostic only. Count matching allocation and deallocation calls during the window.
static PROBE_BLOCK_ALLOCS: AtomicU64 = AtomicU64::new(0);
static PROBE_BLOCK_FREES: AtomicU64 = AtomicU64::new(0);

pub fn probe_block_counts() -> (u64, u64) {
    (PROBE_BLOCK_ALLOCS.load(Relaxed), PROBE_BLOCK_FREES.load(Relaxed))
}
"""
count_alloc = b"""        if !result.is_null() {
            if ACTIVE.load(Relaxed) && layout.size() == 1024 && layout.align() == 16 {
                PROBE_BLOCK_ALLOCS.fetch_add(1, Relaxed);
            }
            acquired(layout.size());
        }
"""
old_acquire = b"""        if !result.is_null() {
            acquired(layout.size());
        }
"""
# Instrument alloc only. The test makes normal allocations.
starts_at = b"    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {"
ends_at = b"    unsafe fn alloc_zeroed(&self"
offset = tracker.index(starts_at)
end = tracker.index(ends_at)
alloc_code = replace_once(tracker[offset:end], old_acquire, count_alloc)
recorded_tracker = tracker[:offset] + alloc_code + tracker[end:] + annotation
old_release = b"""        released(layout.size());
    }
}
"""
recorded_tracker = replace_once(
    recorded_tracker,
    old_release,
    b"""        if ACTIVE.load(Relaxed) && layout.size() == 1024 && layout.align() == 16 {
            PROBE_BLOCK_FREES.fetch_add(1, Relaxed);
        }
""" + old_release,
)

receipts = {}
programs_dir = Path(tempfile.mkdtemp(prefix="mech-allocator-probe-runtime.", dir="/private/tmp"))
for name, source in variants.items():
    for checked_layout in (False, True):
        label = name if not checked_layout else f"{name}-layout"
        unit = programs_dir / label
        unit.mkdir()
        current_source = source
        current_tracker = tracker
        if checked_layout:
            current_tracker = recorded_tracker
            current_source = replace_once(
                current_source,
                b"    allocated.wait();\n    release.wait();",
                b"    allocated.wait();\n"
                b"    assert_eq!(measurement::probe_block_counts(), (12, 0));\n"
                b"    release.wait();",
            )
            current_source = replace_once(
                current_source,
                b"    let measured = serde_json::to_value(window.finish()).unwrap();",
                b"    assert_eq!(measurement::probe_block_counts(), (12, 12));\n"
                b"    let measured = serde_json::to_value(window.finish()).unwrap();",
            )
        probe = unit / "check-measurement.rs"
        probe.write_bytes(current_source)
        (unit / "measurement.rs").write_bytes(current_tracker)
        binary = unit / "check-measurement"
        command = [
            "rustc", "+nightly-2026-03-03", "--edition=2024", "--crate-name", "check_measurement",
            "-D", "warnings", "-C", "opt-level=3", "-L", f"dependency={deps_directory}",
        ]
        for crate, path in exports:
            command += ["--extern", f"{crate}={path}"]
        command += [str(probe), "-o", str(binary)]
        built = subprocess.run(command, cwd=unit, capture_output=True, text=True, check=False)
        (scratch / f"{label}-build.log").write_text(built.stdout + built.stderr)
        built.check_returncode()
        executed = subprocess.run([binary], cwd=unit, capture_output=True, text=True, check=False)
        (scratch / f"{label}-run.log").write_text(executed.stdout + executed.stderr)
        executed.check_returncode()
        outcome = json.loads(executed.stdout)
        assert outcome["status"] == "passed", (label, outcome)
        assert len(outcome["empty_window_overhead"]) == 7, (label, outcome)
        samples = outcome["all_thread_allocation_check"]
        assert samples["freed_allocation_bytes"] >= 12288
        receipts[label] = {
            "command": command,
            "source_sha256": sha256(current_source).hexdigest(),
            "measurement_sha256": sha256(current_tracker).hexdigest(),
            "binary_sha256": sha256(binary.read_bytes()).hexdigest(),
            "exact_layout_checks": [[12, 0], [12, 12]] if checked_layout else None,
            "outcome": samples,
            "empty_window_samples": len(outcome["empty_window_overhead"]),
        }
        print(label, {key: samples[key] for key in (
            "allocation_requests", "requested_allocation_bytes", "freed_allocation_bytes",
            "peak_additional_live_requested_heap_bytes", "allocator_lifetime_accounting_underflows",
        )}, flush=True)
receipt = {"base": base, "rustc": subprocess.check_output(
    ["rustc", "+nightly-2026-03-03", "--version"], text=True
).strip(), "programs": receipts}
(scratch / "runtime-validation.json").write_text(json.dumps(receipt, indent=2) + "\n")

