from pathlib import Path
from runpy import run_path
import json,sys
Q=Path('/private/tmp/mech-shared-cold-epilogues.2L6obP/.qualification');I=Q/'consolidation-995';D=I/'controller-source-boundaries/scoped-registers';P=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/benchmarks/mech-deflate/native-profile/native-compact-20261116');link=run_path(str(Q/'current-roadmap/checked-root-census/recheck-link.py'),run_name='source_units_link')
template=I/'collector-read-lifetimes/placement/immutable-profiled/bound'
roles=sys.argv[1:] or ['remapped-unsplit','early-remapped','early-shared-packets','early-owner-homes','early-owner-homes-shared']
for role in roles:
 folder=D/role;receipt=json.loads((folder/'result.json').read_text());record=(json.loads((folder/'bound/runtime.json').read_text()) if (folder/'bound/runtime.json').exists() else link['link_worker'](template,folder/'frontend',folder/'bound'))
 for key in ['size_bytes','encoder_sha256']:record.pop(key,None)
 record['encoder_text_bytes']=receipt['encoder_text_bytes'];record['bytecode_sha256']=receipt['artifacts']['program.mecb']
 (folder/'bound/runtime.json').write_text(json.dumps(record,indent=2)+'\n')
 
 if not (folder/'bound/qualification.json').exists():link['check_worker'](folder/'bound','source-unit-final44-'+role)
 else:assert json.loads((folder/'bound/qualification.json').read_text())['worker_sha256']==record['worker_sha256']
 (folder/'receipt.json').write_text(json.dumps(receipt|{'object_sha256':record['object_sha256'],'metadata_sha256':record['metadata_sha256'],'compile':receipt['command'],'compiler_sha256':json.loads((D/'build.json').read_text())['compiler_sha256']},indent=2)+'\n')
 print(role,'162 exact output/inflation/alias checks passed',record['worker_sha256'],flush=True)
