#![allow(dead_code)]
mod native_artifact {
 #[derive(Debug)] pub enum NativeCompileError { InvalidPlan { node:Option<usize>, reason:&'static str }, Backend(String) }
 pub mod compiler { use super::NativeCompileError;
  pub fn backend(error:impl std::fmt::Display)->NativeCompileError {NativeCompileError::Backend(error.to_string())}
pub(in crate::native_artifact) fn offset(index: usize) -> Result<i32, NativeCompileError> {
    index
        .checked_mul(8)
        .and_then(|v| i32::try_from(v).ok())
        .ok_or(NativeCompileError::InvalidPlan {
            node: None,
            reason: "transport offset exceeds ABI",
        })
}
 }
 pub mod codegen {
  pub mod control { pub mod plan {
   #[derive(Clone,Copy)] pub struct CodePlan<'a>(std::marker::PhantomData<&'a ()>);
   pub struct Slot; impl Slot {pub fn get(self)->u32 {panic!("constructor plan is outside test scope")}}
   impl CodePlan<'_> {
    pub fn constant_count(self)->usize {panic!("constructor plan is outside test scope")}
    pub fn constant(self,_:usize)->Result<(Slot,Option<u64>),crate::native_artifact::NativeCompileError> {panic!("constructor plan is outside test scope")}
   }
  }}
  pub mod common {
#[path="/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/hosts/gpu/src/native_artifact/codegen/common/ssa_words.rs"] mod ssa_words;
}}}
