#![allow(dead_code)]
mod native_artifact {
 #[derive(Debug)] pub enum NativeCompileError {InvalidPlan{node:Option<usize>,reason:&'static str},Backend(String)}
 pub mod compiler {use super::NativeCompileError;pub fn backend(error:impl std::fmt::Display)->NativeCompileError {NativeCompileError::Backend(error.to_string())}
pub(in crate::native_artifact) fn offset(index: usize) -> Result<i32, NativeCompileError> {
    index
        .checked_mul(8)
        .and_then(|v| i32::try_from(v).ok())
        .ok_or(NativeCompileError::InvalidPlan {
            node: None,
            reason: "transport offset exceeds ABI",
        })
}
}
 pub mod program {pub mod compact {
#[path="/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/hosts/gpu/src/native_artifact/program/compact/phase_storage.rs"]mod phase_storage;
}}}
