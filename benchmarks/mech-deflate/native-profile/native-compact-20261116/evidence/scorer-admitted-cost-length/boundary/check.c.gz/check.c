
#include <assert.h>
#include <stdint.h>
#include <stdio.h>

extern uint64_t lookup_original(uint64_t, const uint64_t *, uint64_t);
extern uint64_t lookup_split(uint64_t, const uint64_t *, uint64_t);
extern uint64_t lookup_other_length(uint64_t, const uint64_t *, uint64_t);

int main(void) {
    static uint32_t values[65536];
    for (uint32_t j = 0; j < 65536; j++)
        values[j] = j + 1;
    const uint64_t lengths[] = {545, 546, 547, 610, 1024, 65536};
    const uint64_t indexes[] = {
        0, 1, 255, 285, 286, 287, 288, 349, 351, 764, 765, 766, 65000,
        UINT64_MAX - 259, UINT64_MAX - 258, UINT64_MAX - 1, UINT64_MAX
    };
    unsigned checked = 0;
    for (unsigned n = 0; n < sizeof(lengths) / sizeof(lengths[0]); n++) {
        const uint64_t packet[] = {(uint64_t)(uintptr_t)values, lengths[n], 65536};
        for (unsigned j = 0; j < sizeof(indexes) / sizeof(indexes[0]); j++) {
            const uint64_t raw = indexes[j], index = raw + 259;
            const uint64_t expected = index < lengths[n] ? values[index] : 0;
            assert(lookup_original(raw, packet, 0) == expected);
            assert(lookup_split(raw, packet, 0) == expected);
            assert(lookup_other_length(raw, packet, 0) == expected);
            checked++;
        }
    }
    printf("%u lookup inputs passed on all three generated entries\n", checked);
}
