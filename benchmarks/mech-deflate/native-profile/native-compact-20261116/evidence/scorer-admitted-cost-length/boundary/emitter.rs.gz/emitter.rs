
#![allow(dead_code)]
mod native_artifact {
use std::{collections::{BTreeMap, BTreeSet}, sync::Arc};
use cranelift_codegen::cursor::{Cursor, FuncCursor};
use cranelift_codegen::flowgraph::ControlFlowGraph;
use cranelift_codegen::ir::{AbiParam, Block, Function, Inst, InstBuilder,
    Opcode, Value, ValueDef, MemFlags, condcodes::IntCC, types};
use cranelift_codegen::ir::{InstructionData as D, InstructionData as Data, Opcode as O, Opcode as Op};
use cranelift_frontend::{FunctionBuilder, FunctionBuilderContext};
use cranelift_module::{Linkage, Module, default_libcall_names};
use cranelift_object::{ObjectBuilder, ObjectModule};
#[derive(Clone)]
pub(in crate::native_artifact) struct Literal {
    pub length: u64,
    pub maximum: u64,
    pub bytes: Option<Arc<[u8]>>,
}
#[derive(Clone)]
pub(in crate::native_artifact) struct View {
    pub array: usize,
    pub pointer_word: usize,
    pub length_word: usize,
    pub width: u8,
    pub literal: Option<Literal>,
}
pub(in crate::native_artifact) struct Capture<'a> {
    pub packet_loads: &'a BTreeMap<Value, (Inst, usize)>,
    pub views: &'a [View],
    pub header: Block,
    pub countdown_word: usize,
}
#[derive(Clone, Copy, Eq, PartialEq, serde::Serialize)]
pub(in crate::native_artifact) struct Admission {
    pub cache: usize,
    pub cursor_word: usize,
    pub costs: usize,
    pub minimum_costs: u64,
    pub cells_per_bank: u64,
    pub second_bias: u64,
    pub minimum_records: u64,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub immutable_code_bytes: Option<u64>,
}


pub(super) fn definition(f: &Function, value: Value) -> Option<(Inst, Data)> {
    let ValueDef::Result(inst, 0) = f.dfg.value_def(f.dfg.resolve_aliases(value)) else {
        return None;
    };
    Some((inst, f.dfg.insts[inst]))
}

fn incoming(
    f: &Function,
    cfg: &ControlFlowGraph,
    block: Block,
    slot: usize,
) -> Option<Vec<(Block, Value)>> {
    let mut arguments = Vec::new();
    for edge in cfg.pred_iter(block) {
        for call in
            f.dfg.insts[edge.inst].branch_destination(&f.dfg.jump_tables, &f.dfg.exception_tables)
        {
            if call.block(&f.dfg.value_lists) == block {
                arguments.push((
                    edge.block,
                    call.args(&f.dfg.value_lists).nth(slot)?.as_value()?,
                ));
            }
        }
    }
    (!arguments.is_empty()).then_some(arguments)
}

// Invariant packet fields can pass through a self edge or be reloaded by an
// alternate entry. All external definitions must identify the same word.
pub(super) fn packet_word(
    f: &Function,
    cfg: &ControlFlowGraph,
    loads: &BTreeMap<Value, (Inst, usize)>,
    value: Value,
) -> Option<usize> {
    let mut pending = vec![value];
    let mut seen = BTreeSet::new();
    let mut result = None;
    while let Some(value) = pending.pop() {
        let value = f.dfg.resolve_aliases(value);
        if !seen.insert(value) {
            continue;
        }
        if let Some(&(_, word)) = loads.get(&value) {
            if result.is_some_and(|old| old != word) {
                return None;
            }
            result = Some(word);
        } else if let ValueDef::Param(block, slot) = f.dfg.value_def(value) {
            if Some(block) == f.layout.entry_block() {
                return None;
            }
            pending.extend(
                incoming(f, cfg, block, slot)?
                    .into_iter()
                    .map(|(_, value)| value),
            );
        } else {
            return None;
        }
    }
    result
}


pub(super) fn read_comparison(f: &Function, condition: Value) -> Option<Inst> {
    let compare = comparison(f, condition)?;
    let Data::BinaryImm64 {
        opcode: Op::BandImm,
        arg,
        imm,
    } = f.dfg.insts[compare]
    else {
        return Some(compare);
    };
    if imm.bits() != 1 || f.dfg.value_type(arg) != types::I8 {
        return None;
    }
    // A compact branch may expose the low bit of a comparison for native
    // selection. An arbitrary byte mask does not establish a read bound.
    let (inner, data) = definition(f, arg)?;
    matches!(data, Data::IntCompare { .. }).then_some(inner)
}


fn word_mask(function: &Function, value: Value) -> Option<u64> {
    let ty = function.dfg.value_type(value);
    (ty.is_int() && !ty.is_vector() && ty.bits() > 0 && ty.bits() <= 64)
        .then(|| u64::MAX >> (64 - ty.bits()))
}

pub(super) fn literal(function: &Function, value: Value) -> Option<u64> {
    let value = function.dfg.resolve_aliases(value);
    let ValueDef::Result(inst, 0) = function.dfg.value_def(value) else {
        return None;
    };
    let Data::UnaryImm {
        opcode: Op::Iconst,
        imm,
    } = function.dfg.insts[inst]
    else {
        return None;
    };
    Some(imm.bits() as u64 & word_mask(function, value)?)
}

/// Normalize integer addition modulo the word width. Callers use I64 words.
pub(super) fn constant_offset(f: &Function, mut value: Value) -> (Value, u64) {
    let mut offset = 0u64;
    loop {
        value = f.dfg.resolve_aliases(value);
        let step = match f.dfg.value_def(value) {
            ValueDef::Result(inst, 0) => match f.dfg.insts[inst] {
                Data::BinaryImm64 {
                    opcode: Op::IaddImm,
                    arg,
                    imm,
                } => Some((arg, imm.bits() as u64)),
                Data::Binary {
                    opcode: Op::Iadd,
                    args: [left, right],
                } => literal(f, right)
                    .map(|constant| (left, constant))
                    .or_else(|| literal(f, left).map(|constant| (right, constant))),
                _ => None,
            },
            _ => None,
        };
        let Some((next, constant)) = step else {
            return (value, offset);
        };
        offset = offset.wrapping_add(constant);
        value = next;
    }
}


fn predicate_definition(f: &Function, mut value: Value) -> Option<Inst> {
    loop {
        let ValueDef::Result(inst, 0) = f.dfg.value_def(f.dfg.resolve_aliases(value)) else {
            return None;
        };
        match f.dfg.insts[inst] {
            Data::Unary {
                opcode: Opcode::Uextend,
                arg,
            } => value = arg,
            _ => match masked_integer_comparison(f, &f.dfg.insts[inst], |value| {
                Some(f.dfg.resolve_aliases(value))
            }) {
                Some(comparison) => value = comparison,
                None => return Some(inst),
            },
        }
    }
}

pub(super) fn comparison(f: &Function, value: Value) -> Option<Inst> {
    let mut inst = predicate_definition(f, value)?;
    loop {
        let inner = match f.dfg.insts[inst] {
            Data::IntCompare {
                cond: IntCC::Equal,
                args: [a, b],
                ..
            } if literal(f, b) == Some(1) => Some(a),
            Data::IntCompare {
                cond: IntCC::Equal,
                args: [a, b],
                ..
            } if literal(f, a) == Some(1) => Some(b),
            Data::IntCompareImm {
                cond: IntCC::Equal,
                arg,
                imm,
                ..
            } if imm.bits() == 1 => Some(arg),
            _ => None,
        };
        // Equality to one is identity only for the result of a comparison.
        if let Some(next) = inner.and_then(|word| predicate_definition(f, word)) {
            if matches!(
                f.dfg.insts[next],
                Data::IntCompare { .. } | Data::IntCompareImm { .. }
            ) {
                inst = next;
                continue;
            }
        }
        return Some(inst);
    }
}


fn masked_integer_comparison(
    f: &Function,
    instruction: &D,
    mut resolve: impl FnMut(Value) -> Option<Value>,
) -> Option<Value> {
    let D::BinaryImm64 {
        opcode: O::BandImm,
        arg,
        imm,
    } = *instruction
    else {
        return None;
    };
    if imm.bits() != 1 {
        return None;
    }
    let mut value = arg;
    for _ in 0..8 {
        value = resolve(value)?;
        let ValueDef::Result(definition, 0) = f.dfg.value_def(value) else {
            return None;
        };
        match f.dfg.insts[definition] {
            D::Unary {
                opcode: O::Uextend,
                arg,
            } => value = arg,
            D::IntCompare { .. } | D::IntCompareImm { .. }
                if f.dfg.value_type(value) == types::I8 =>
            {
                return Some(value);
            }
            _ => return None,
        }
    }
    None
}


/// Use the caller's admitted cost extent for prefix reads. A larger index
/// keeps the original full-length check, including the zero default.
pub(in crate::native_artifact) fn split_admitted_cost_checks(
    f: &mut Function,
    cfg: &ControlFlowGraph,
    capture: &Capture<'_>,
    admission: Admission,
) -> usize {
    let Some(view) = capture.views.iter().find(|v| v.array == admission.costs) else {
        return 0;
    };
    let Some(offset) = view
        .length_word
        .checked_mul(8)
        .and_then(|n| i32::try_from(n).ok())
    else {
        return 0;
    };
    let Ok(floor) = i64::try_from(admission.minimum_costs) else {
        return 0;
    };
    let Some(entry) = f.layout.entry_block() else {
        return 0;
    };
    let &[_, input, _] = f.dfg.block_params(entry) else {
        return 0;
    };
    let checks = f
        .layout
        .blocks()
        .filter_map(|block| {
            let branch = f.layout.last_inst(block)?;
            let Data::Brif { arg, blocks, .. } = f.dfg.insts[branch] else {
                return None;
            };
            let [yes, no] = blocks;
            if blocks
                .iter()
                .any(|edge| edge.args(&f.dfg.value_lists).next().is_some())
            {
                return None;
            }
            let compare = read_comparison(f, arg)?;
            let Data::IntCompare {
                cond: IntCC::UnsignedLessThan,
                args: [index, length],
                ..
            } = f.dfg.insts[compare]
            else {
                return None;
            };
            if f.dfg.value_type(index) != types::I64
                || packet_word(f, cfg, capture.packet_loads, length) != Some(view.length_word)
                || !matches!(constant_offset(f, index).1, bias if bias > 0 && bias < floor as u64)
            {
                return None;
            }
            Some((
                branch,
                index,
                yes.block(&f.dfg.value_lists),
                no.block(&f.dfg.value_lists),
            ))
        })
        .collect::<Vec<_>>();
    let count = checks.len();
    for (branch, index, yes, no) in checks {
        let fallback = f.dfg.make_block();
        f.layout.append_block(fallback);
        f.layout.set_cold(fallback);
        let mut cursor = FuncCursor::new(f).at_inst(branch);
        let prefix = cursor.ins().icmp_imm(IntCC::UnsignedLessThan, index, floor);
        cursor
            .func
            .dfg
            .replace(branch)
            .brif(prefix, yes, &[], fallback, &[]);

        // The caller's immutable input packet supplies the same length that
        // the original comparison propagated through the loop.
        cursor.goto_bottom(fallback);
        let length = cursor
            .ins()
            .load(types::I64, MemFlags::new(), input, offset);
        let fits = cursor.ins().icmp(IntCC::UnsignedLessThan, index, length);
        cursor.ins().brif(fits, yes, &[], no, &[]);
    }
    count
}


pub fn emit(output: &str) {
    let isa = cranelift_native::builder().unwrap()
        .finish(cranelift_codegen::settings::Flags::new(cranelift_codegen::settings::builder()))
        .unwrap();
    let builder = ObjectBuilder::new(isa, "cost_length_checks", default_libcall_names()).unwrap();
    let mut module = ObjectModule::new(builder);
    for (name, enabled, used_word, expected) in [
        ("lookup_original", false, 1, 0),
        ("lookup_split", true, 1, 1),
        ("lookup_other_length", true, 2, 0),
    ] {
        let mut context = module.make_context();
        context.func.signature = module.make_signature();
        context.func.signature.params = vec![AbiParam::new(types::I64); 3];
        context.func.signature.returns.push(AbiParam::new(types::I64));
        let id = module.declare_function(name, Linkage::Export, &context.func.signature).unwrap();
        let mut state = FunctionBuilderContext::new();
        let mut b = FunctionBuilder::new(&mut context.func, &mut state);
        let entry = b.create_block();
        let header = b.create_block();
        let yes = b.create_block();
        let no = b.create_block();
        b.append_block_params_for_function_params(entry);
        b.append_block_param(header, types::I64);
        b.switch_to_block(entry);
        let [raw, packet, _] = b.block_params(entry).try_into().unwrap();
        let count = b.ins().load(types::I64, MemFlags::new(), packet, 8);
        let data = b.ins().load(types::I64, MemFlags::new(), packet, 0);
        let index = b.ins().iadd_imm(raw, 259);
        b.ins().jump(header, &[count.into()]);
        b.switch_to_block(header);
        let length = b.block_params(header)[0];
        let fit = b.ins().icmp(IntCC::UnsignedLessThan, index, length);
        let guard = b.ins().band_imm(fit, 1);
        b.ins().brif(guard, yes, &[], no, &[]);
        b.switch_to_block(yes);
        let scaled = b.ins().ishl_imm(index, 2);
        let at = b.ins().iadd(data, scaled);
        let value = b.ins().uload32(MemFlags::new(), at, 0);
        b.ins().return_(&[value]);
        b.switch_to_block(no);
        let default = b.ins().iconst(types::I64, 0);
        b.ins().return_(&[default]);
        b.seal_all_blocks();
        b.finalize();

        let loads = BTreeMap::from([(count, (definition(&context.func, count).unwrap().0, 1))]);
        let view = View { array: 2, pointer_word: 0, length_word: used_word, width: 4, literal: None };
        let capture = Capture { packet_loads: &loads, views: &[view], header, countdown_word: 0 };
        let admission = Admission { costs: 2, minimum_costs: 545, cache: 0, cursor_word: 0,
            cells_per_bank: 256, second_bias: 14, minimum_records: 2048, immutable_code_bytes: Some(65536) };
        context.compute_cfg();
        if enabled {
            let n = split_admitted_cost_checks(&mut context.func, &context.cfg, &capture, admission);
            assert_eq!(n, expected, "{name}");
        }
        context.compute_cfg();
        context.verify(module.isa()).unwrap();
        module.define_function(id, &mut context).unwrap();
    }
    std::fs::write(output, module.finish().emit().unwrap()).unwrap();
}

}
fn main() {
    let output = std::env::args().nth(1).unwrap();
    native_artifact::emit(&output);
}
