"""Check unchanged-code source attribution before interpreting any counts."""
from pathlib import Path
from hashlib import sha256
import json,os,subprocess

O=Path(__file__).resolve().parent;N=O.parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
build=read(O/'compiler/build.json');assert build['exit_code']==0
assert sha(build['compiler'])==build['compiler_sha256']
recipe=read(N/'source-sort-hybrid32-profiled/receipt.json')
env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}
records=[]
for enabled in [False,True]:
    folder=O/('source-sites-on' if enabled else 'source-sites-off');folder.mkdir()
    flags=dict(recipe['flags'])
    if enabled:
        flags|={'MECH_INSPECT_PHASE_SOURCE_SITES':str(folder/'canonical-sites'),
                'MECH_INSPECT_PHASE_CLIF':str(folder/'mech_compact_numeric_475_vector.clif')}
    command=[build['compiler'],recipe['compile'][1],str(folder/'frontend'),'compact']
    with (folder/'compile.log').open('w') as log:subprocess.run(command,env=env|flags,stdout=log,stderr=log,check=True)
    artifacts={name:sha(folder/'frontend'/name) for name in recipe['artifacts']}
    exact=artifacts==recipe['artifacts']
    assert artifacts['program.mecb']==recipe['artifacts']['program.mecb']
    if not enabled:assert exact
    record={'enabled':enabled,'command':command,'flags':flags,'artifacts':artifacts,
            'compiler_sha256':build['compiler_sha256'],'source_sha256':recipe['source_sha256'],
            'all_three_exact':exact,'reference_artifacts':recipe['artifacts']}
    if enabled:
        ranges=read(folder/'mech_compact_numeric_475_vector.source-ranges.json')
        source=read(folder/'canonical-sites/source-475-vector-true-no-growth-false.json')
        sites={r['site'] for r in source};metadata=read(folder/'frontend/metadata.json')
        phase=next(p['vector_variant'] for p in metadata['numeric_phases'] if p['header']==475)
        assert ranges and sites
        assert all(0<=r['start']<r['end']<=phase['code_bytes'] for r in ranges)
        assert all(r['start']%4==r['end']%4==0 for r in ranges)
        assert all(r['site']==4294967295 or r['site'] in sites for r in ranges)
        record.update(source_range_count=len(ranges),canonical_site_count=len(sites),
                      known_source_bytes=sum(r['end']-r['start'] for r in ranges if r['site'] in sites),
                      code_bytes=phase['code_bytes'])
    (folder/'receipt.json').write_text(json.dumps(record,indent=2)+'\n');records.append(record)
    (O/'probe.json').write_text(json.dumps({'complete':len(records)==2,'records':records},indent=2)+'\n')
    print('enabled',enabled,'all3 exact',exact,{k:record[k] for k in ['source_range_count','known_source_bytes','code_bytes'] if k in record},flush=True)
