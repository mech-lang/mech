from pathlib import Path
from hashlib import sha256
import bisect,json,math,re,os,subprocess
N=Path(__file__).resolve().parent;O=N/'measured-register-weights';read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}
script=N/'count-current-semantic-matcher.py';ns={'__file__':str(script),'__name__':'register_candidate_tools'};exec(compile(script.read_text().split('\nsource_shapes={}')[0],str(script),'exec'),ns);driver=ns['driver']
r=read(O/'training-native-v4/receipt.json');symbol='mech_compact_numeric_475_vector';text=(O/'training-native-v4'/(symbol+'.vcode')).read_text();expected=text.split(';; REGALLOC_INPUT_BEGIN\n',1)[1].split(';; REGALLOC_INPUT_END\n',1)[0];mapping=[(int(i),int(at)) for i,at in re.findall(r'^;; REGALLOC_BLOCK (\d+) offset=(\d+) ',text,re.M)];assert [i for i,_ in mapping]==list(range(len(mapping)));counts=read(O/'training-native-v4/block-counts-475/counts.json');atom=r['layout']['symbols']['_'+symbol];weights=[0.0]*len(mapping);audit={}
for case,sample in counts['cases'].items():
 visits={int(b['address'],16)-atom['start']:b['visits'] for b in sample['blocks']};heads=sorted(visits);assert heads[0]==0
 mapped=[heads[bisect.bisect_right(heads,offset)-1] for _,offset in mapping];observed=[visits[head] for head in mapped];total=sum(visits.values());assert total>0
 assert observed[0]==sample['calls'],(case,observed[0],sample['calls'])
 for index,value in enumerate(observed):weights[index]+=value/total/len(counts['cases'])
 audit[case]={'kernel_calls':sample['calls'],'mapped_visits':observed,'machine_offsets':mapped,'sum_mapped_visits':total,'distinct_machine_offsets':len(set(mapped)),'mapping_scope':'Final resolved VCode label to containing observed machine basic block, including folded/empty labels. Shared label offsets are retained explicitly, not treated as independent dynamic observations.'}
profiles=O/'profiles-v4';profiles.mkdir()
for mode,power in [('linear',1.0),('sqrt',0.5)]:
 frequencies=[max(1,min(1<<20,round((value/max(weights))**power*4096))) for value in weights]
 profile={'expected_vcode':expected,'block_frequencies':frequencies,'scope':'Equal case share of mapped kernel block visits across nine mixed cases, normalized to maximum4096, floor1. All virtual-code instructions, register types/constraints/clobbers must match exactly. '+mode,'power':power,'cases':list(counts['cases']),'training_object_sha256':r['artifacts']['program.o'],'training_vcode_sha256':sha(O/'training-native-v4'/(symbol+'.vcode')),'block_counts_sha256':sha(O/'training-native-v4/block-counts-475/counts.json')};(profiles/(mode+'.json')).write_text(json.dumps(profile,indent=2)+'\n')
(O/'weight-mapping-audit-v4.json').write_text(json.dumps({'training_symbol':symbol,'mapping':mapping,'cases':audit,'equal_case_shares':weights},indent=2)+'\n')
flags={k:v for k,v in r['flags'].items() if k not in ['MECH_INSPECT_PHASE_VCODE','MECH_INSPECT_PHASE_REGISTER_PROFILE']}
bad=read(profiles/'linear.json');bad['expected_vcode']+='stale-profile';(profiles/'stale.json').write_text(json.dumps(bad)+'\n');badout=O/'rejected-stale-v4';badout.mkdir();cmd=[r['command'][0],r['command'][1],str(badout/'frontend'),'compact']
with (badout/'compile.log').open('w') as log:failure=subprocess.run(cmd,env=env|flags|{'MECH_COMPACT_PHASE_REGISTER_WEIGHTS':symbol+'@'+str(profiles/'stale.json')},stdout=log,stderr=log)
assert failure.returncode!=0 and 'register frequency profile does not match lowered code' in (badout/'compile.log').read_text();(badout/'rejection.json').write_text(json.dumps({'expected_failure':True,'exit_code':failure.returncode,'reason':'register frequency profile does not match lowered code'},indent=2)+'\n');print('stale profile rejected before allocation',flush=True)
for mode in ['linear','sqrt']:
 out=O/(mode+'-unprofiled-v4');out.mkdir();selected=flags|{'MECH_COMPACT_PHASE_REGISTER_WEIGHTS':symbol+'@'+str(profiles/(mode+'.json'))};cmd=[r['command'][0],r['command'][1],str(out/'frontend'),'compact']
 with (out/'compile.log').open('w') as log:subprocess.run(cmd,env=env|selected,stdout=log,stderr=log,check=True)
 artifacts={f:sha(out/'frontend'/f) for f in r['artifacts']};assert artifacts['program.mecb']==r['artifacts']['program.mecb'];layout=driver.symbols(out/'frontend/program.o');receipt=r|{'command':cmd,'compile':cmd,'flags':selected,'artifacts':artifacts,'layout':layout,'text_bytes':layout['text_bytes']};(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');driver.link.link_worker(O/'training-native-v4/bound',out/'frontend',out/'bound');driver.link.check_worker(out/'bound','register-'+mode);print(mode,'text',receipt['text_bytes'],'root stack',read(out/'frontend/metadata.json')['stack_bytes'],'weight range',min(read(profiles/(mode+'.json'))['block_frequencies']),max(read(profiles/(mode+'.json'))['block_frequencies']),flush=True)
