"""Run only after all runtime and complete-build clocks are terminal."""
from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess
N=Path(__file__).resolve().parent;S=N/'measured-register-weights'
W=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP');P=W/'benchmarks/mech-deflate/native-profile/native-compact-20261116';O=P/'evidence/measured-register-weight-study';OLD=P/'evidence/lazy-adaptive-check-study'
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
O.mkdir(exist_ok=True);roles={};code_commit=subprocess.check_output(['git','rev-parse','5b3a4af26'],text=True).strip()
(O/'compiler-source.patch').write_bytes(subprocess.check_output(['git','diff','44400df51','5b3a4af26','--','hosts/gpu','vendor/cranelift-codegen','vendor/regalloc2']))
for mode in ['linear','sqrt']:
 local='hybrid32-register-'+mode+'-profiled';r=read(S/local/'receipt.json');flags=dict(r['flags']);profiles=[]
 for control in ['MECH_COMPACT_PHASE_BLOCK_LAYOUT','MECH_COMPACT_PHASE_REGISTER_WEIGHTS']:
  for value in flags.pop(control).split(';'):
   symbol,path=value.split('@');path=Path(path);pin=sha(path);dest=O/'profiles'/(pin[:16]+'-'+path.name);dest.parent.mkdir(exist_ok=True);shutil.copy2(path,dest);profiles.append({'control':control,'symbol':symbol,'file':str(dest.relative_to(O)),'sha256':pin})
 source='../huffman-sort-replay-study/program-hybrid-u32.mec';assert sha(O/source)==r['source_sha256']
 roles['hybrid-'+mode]={'local_role':local,'base_source':source,'base_source_sha256':r['source_sha256'],'source_file':source,'source_sha256':r['source_sha256'],'source_lines':2732,'compiler_sha256':r['compiler_sha256'],'compiler_source_commit':code_commit,'compiler_build_manifest_sha256':sha(S/'compiler-build-v5/build.json'),'flags':flags,'profiles':profiles,'artifacts':r['artifacts'],'text_bytes':r['text_bytes'],'worker_sha256':sha(S/local/'bound/mech-worker'),'measured_peak_stack_bytes':4752}
 runtime=S/local/'bound/runtime.json';record=read(runtime);record['encoder_text_bytes']=r['text_bytes'];runtime.write_text(json.dumps(record,indent=2)+'\n')
(O/'recipes.json').write_text(json.dumps({'roles':roles},indent=2)+'\n');(O/'generate.py').write_text('"""This compiler experiment leaves the qualified HF-U32 Mech source unchanged."""\nfrom hashlib import sha256\ndef generate(source):\n    assert sha256(source.encode()).hexdigest()=="ecf98df0c4f0ea9bfd2b5ae548a76fdfba178703c224a6e33e987848711a4b22"\n    return source\n')
s=(OLD/'reproduce.py').read_text().replace('conditional adaptive-block source','source using measured register spill weights').replace("choices=['hybrid-lazy'], default='hybrid-lazy'","choices=['hybrid-linear','hybrid-sqrt'], default='hybrid-linear'")
s=s.replace('    profiles = []','    profiles = {}').replace("        profiles.append(profile['symbol']+'@'+str(path))","        profiles.setdefault(profile['control'], []).append(profile['symbol']+'@'+str(path))").replace("    flags = recipe['flags'] | {'MECH_COMPACT_PHASE_BLOCK_LAYOUT':';'.join(profiles)}","    flags = recipe['flags'] | {control:';'.join(entries) for control,entries in profiles.items()}")
(O/'reproduce.py').write_text(s);replays=S/'public-replays';replays.mkdir(exist_ok=True);compiler=read(S/'compiler-build-v5/build.json')['compiler']
for role in roles:
 for mode in ['normal','checked']:
  output=replays/(role+'-'+mode)
  if output.exists():
   result=read(output/'reproduction.json');assert result['all_three_exact'] and result['artifacts']==roles[role]['artifacts'];continue
  subprocess.run(['python3',str(O/'reproduce.py'),compiler,str(output),'--role',role]+(['--checked'] if mode=='checked' else []),check=True)
for file in ['verify_runtime.py']:
 shutil.copy2(OLD/file,O/file)
shutil.copy2(S/'BROADER-PLAN.md',O/'BROADER-PLAN.md')
print('public register-weight sources, recipes, profiles and four exact native replays ready')
