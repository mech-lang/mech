"""Archive stable results only after every producer and clock is terminal."""
from pathlib import Path
from hashlib import sha256
import gzip,io,json,tarfile,sys

N=Path(__file__).resolve().parent;S=N/'measured-register-weights';Q=N.parent.parent
P=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/benchmarks/mech-deflate/native-profile/native-compact-20261116');O=P/'evidence/measured-register-weight-study'
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();manifests={}

def tree(members,source,prefix):
 for path in source.rglob('*'):
  if path.is_file() and '__pycache__' not in path.parts and path.name not in ['compile_profile','package.log']:members[prefix+'/'+str(path.relative_to(source))]=path

def archive(name,members):
 pins={}
 with (O/name).open('wb') as stream,gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as tar:
   for relative,path in sorted(members.items()):
    assert not relative.startswith('/') and '..' not in Path(relative).parts
    data=path if isinstance(path,bytes) else path.read_bytes();item=tarfile.TarInfo(relative);item.size=len(data);item.mode=0o644;item.mtime=0;tar.addfile(item,io.BytesIO(data));pins[relative]=sha256(data).hexdigest()
 manifests[name]={'sha256':sha(O/name),'bytes':(O/name).stat().st_size,'members':pins}

native={};tree(native,S,'study')
for path in N.glob('*register*.py'):native['generation-scripts/'+path.name]=path
for name in ['frontend','bound','collector-final-counts-475']:tree(native,N/'source-sort-hybrid32-profiled'/name,'held-source/'+name)
native['held-source/receipt.json']=N/'source-sort-hybrid32-profiled/receipt.json'
native['comparison-sources/main.c']=Q/'minimal-deployment/source/main.c'
archive('native-proofs.tar.gz',native)
if '--native-only' in sys.argv:
 previous=read(O/'archives.json')
 manifests.update({name:pin for name,pin in previous.items() if name!='native-proofs.tar.gz'})
else:
 common={'runtime/fixtures-original.json':Q/'fixtures.json','runtime/C-oracle.json':Q/'pinned-peers/libdeflate-output-oracle.json','runtime/working-selection-policy.json':P/'working-selection-policy.json'};portable={}
 for fixture in read(Q/'fixtures.json'):
  portable[fixture['name']]={}
  for tag in ['input','prefix','expected']:
   path=Path(fixture[tag]);pin=sha(path);relative='runtime/fixture-data/'+pin+'.bin';common[relative]=path;portable[fixture['name']][tag]={'member':relative,'sha256':pin}
 common['runtime/fixtures-portable.json']=(json.dumps(portable,indent=2)+'\n').encode()
 for mode in ['linear','sqrt']:
  for order in ['forward','reverse']:
   name='measured-register-'+mode+'-'+order;tree(common,Q/name,'runtime/'+name)
 archive('panel-runtime-raw.tar.gz',common)
 for mode in ['linear','sqrt']:
  members={}
  for order in ['forward','reverse']:
   name='register-'+mode+'-full96-'+order;tree(members,Q/name,'runtime/'+name)
  archive('full-runtime-'+mode+'.tar.gz',members)
 builds={};tree(builds,N/'register-weight-matched-builds','builds');archive('complete-builds.tar.gz',builds)
summary={'selected_default_changed':False,'selected_Roc_wins':81,'selected_C_wins':63,'next_C_target':64,'ultimate_C_target':81,'candidate_promoted':False,'confidence_assessed':False,'compiler_source_commit':read(O/'recipes.json')['roles']['hybrid-linear']['compiler_source_commit'],'linear_panel':read(S/'linear-timing-results.json'),'sqrt_panel':read(S/'sqrt-timing-results.json'),'full_qualification':{mode:read(S/(mode+'-full96-results.json')) for mode in ['linear','sqrt']},'builds':read(N/'register-weight-matched-builds/summary.json'),'public_native_replays':4,'archives':manifests,'scope':'Generic measured spill weights with exact complete VCode identity. Same qualified HF-U32 codec source. Every previous named peer win checked in bothfull81/96orders for each variant; confidence separate. Original-source smaller default remains selected. No64thwin established unless complete raw point results explicitly show it.'}
(O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');(O/'archives.json').write_text(json.dumps(manifests,indent=2)+'\n');print(json.dumps({k:{x:y for x,y in v.items() if x!='members'} for k,v in manifests.items()},indent=2))
