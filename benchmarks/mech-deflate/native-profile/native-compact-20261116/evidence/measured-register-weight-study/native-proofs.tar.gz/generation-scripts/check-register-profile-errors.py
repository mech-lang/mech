"""Actual compiler rejects partial, zero and oversized frequency vectors."""
from pathlib import Path
import json,os,subprocess
N=Path(__file__).resolve().parent;O=N/'measured-register-weights';read=lambda p:json.loads(Path(p).read_text());r=read(O/'training-native-v5/receipt.json');profile=read(O/'profiles-v5/linear.json');env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')};flags={k:v for k,v in r['flags'].items() if k!='MECH_INSPECT_PHASE_REGISTER_PROFILE'};out=O/'profile-shape-rejections';out.mkdir();results={}
for name in ['missing-block','zero-weight','excess-weight']:
 p=profile|{'block_frequencies':list(profile['block_frequencies'])}
 if name=='missing-block':p['block_frequencies'].pop()
 else:p['block_frequencies'][0]=0 if name=='zero-weight' else (1<<20)+1
 path=out/(name+'.json');path.write_text(json.dumps(p)+'\n');cmd=[r['command'][0],r['command'][1],str(out/name/'frontend'),'compact'];profile_flags=flags|{'MECH_COMPACT_PHASE_REGISTER_WEIGHTS':'mech_compact_numeric_475_vector@'+str(path)}
 with (out/(name+'.log')).open('w') as log:status=subprocess.run(cmd,env=env|profile_flags,stdout=log,stderr=log)
 assert status.returncode!=0 and 'weights for' in (out/(name+'.log')).read_text() and 'all weights must be in' in (out/(name+'.log')).read_text()
 results[name]={'exit_code':status.returncode,'expected_rejection':True}
(out/'result.json').write_text(json.dumps(results,indent=2)+'\n');print('all3 malformed profiles rejected before register allocation',flush=True)
