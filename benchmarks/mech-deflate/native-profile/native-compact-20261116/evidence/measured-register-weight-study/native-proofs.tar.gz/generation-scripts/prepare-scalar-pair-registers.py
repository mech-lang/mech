from pathlib import Path
import json,subprocess
n=Path(__file__).resolve().parent;rows=json.loads((n/'scalar-pair-register-ablations.json').read_text());roles=[row['role'] for row in rows]
commands=[['python3','count-paired-packed-key.py',*roles],['python3','emit-scalar-pair-register-profiled.py',*roles]]
for index,command in enumerate(commands):
 print('Running',command,flush=True)
 with (n/f'scalar-pair-register-preparation-{index}.log').open('w') as log:r=subprocess.run(command,cwd=n,stdout=log,stderr=subprocess.STDOUT)
 assert r.returncode==0,(command,(n/f'scalar-pair-register-preparation-{index}.log').read_text()[-6000:])
gates=[]
for role in roles:
 for index,command in enumerate([['python3','qualify-input-windows.py','check',role+'-profiled'],['python3','check-window-profiled-candidate.py',role+'-profiled']]):
  with (n/f'{role}-gate-{index}.log').open('w') as log:r=subprocess.run(command,cwd=n,stdout=log,stderr=subprocess.STDOUT)
  gates.append({'role':role+'-profiled','command':command,'exit_code':r.returncode});print(command,r.returncode,flush=True)
(n/'scalar-pair-register-gates.json').write_text(json.dumps({'complete':True,'runs':gates},indent=2)+'\n');print('All register ablation gates completed; runtime clocks have not started.',flush=True)
