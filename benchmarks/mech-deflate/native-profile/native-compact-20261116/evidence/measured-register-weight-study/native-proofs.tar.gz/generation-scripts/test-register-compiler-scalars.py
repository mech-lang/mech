from pathlib import Path
import json,os,subprocess,time,hashlib
O=Path(__file__).resolve().parent/'measured-register-weights/repository-tests'
p=json.loads((O/'plan.json').read_text());sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert all(sha(path)==pin for path,pin in p['source_sha256'].items())
start=time.monotonic()
with (O/'stdout.log').open('w') as log,(O/'stderr.log').open('w') as err:
    ret=subprocess.run(p['command'],env=os.environ|p['environment'],stdout=log,stderr=err)
assert all(sha(path)==pin for path,pin in p['source_sha256'].items())
result={'exit_code':ret.returncode,'seconds':time.monotonic()-start,'scope':p['scope']}
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(result,flush=True)
assert ret.returncode==0
