from pathlib import Path
from hashlib import sha256
from runpy import run_path
import json,os,subprocess
n=Path(__file__).resolve().parent;read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
build=read(n/'scalar-pair-revisit-compiler/build.json');tool=run_path(str(n.parent.parent/'current-roadmap/scorer-runtime/emit.py'),run_name='scalar_pair_register_symbols');rows=[]
for scope in ['root','plain']:
 for pair in [False,True]:
  role=('scalar-pair-' if pair else 'eight-entry-')+scope+'-probe';base='scalar-pair-head-probe-profiled' if pair else 'packed-eight-head-probe-profiled';old=read(n/base/'receipt.json');flags=old['flags'].copy()
  flags.pop('MECH_COMPACT_PHASE_BLOCK_LAYOUT',None)
  if scope=='plain':flags.pop('MECH_COMPACT_PREFER_PRESERVED_REGS',None)
  else:flags['MECH_COMPACT_PREFER_PRESERVED_REGS']='root'
  out=n/role;out.mkdir();cmd=[build['compiler'],old['compile'][1],str(out/'frontend'),'compact']
  with (out/'compile.log').open('w') as log:r=subprocess.run(cmd,env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}|flags,stdout=log,stderr=log)
  assert r.returncode==0,(out/'compile.log').read_text()[-5000:]
  artifacts={name:sha(out/'frontend'/name) for name in old['artifacts']};assert artifacts['program.mecb']==old['artifacts']['program.mecb'];layout=tool['symbols'](out/'frontend/program.o')
  receipt=old|{'compile':cmd,'command':cmd,'compiler_sha256':build['compiler_sha256'],'source_base':build['source_base'],'source_inputs':build['source_sha256'],'flags':flags,'artifacts':artifacts,'object_sha256':artifacts['program.o'],'metadata_sha256':artifacts['metadata.json'],'bytecode_sha256':artifacts['program.mecb'],'layout':layout,'text_bytes':layout['text_bytes'],'base_role':base,'runtime_qualification':'pending','scope':'Register-preference ablation with matching paired/unpaired eight-entry head controls. Other phases have the same unprofiled policy; fresh scorer profiles follow. No previous qualified win is inherited.'}
  (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');rows.append({'role':role,'base_role':base,'scope':scope,'pair':pair,'text_bytes':receipt['text_bytes']});print(role,receipt['text_bytes'],flush=True)
(n/'scalar-pair-register-ablations.json').write_text(json.dumps(rows,indent=2)+'\n')
