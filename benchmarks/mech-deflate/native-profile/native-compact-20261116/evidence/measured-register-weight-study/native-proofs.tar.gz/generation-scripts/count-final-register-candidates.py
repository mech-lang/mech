"""Untimed diagnostic clones and source-compiled layout profiles only."""
from pathlib import Path
from hashlib import sha256
import json,os,subprocess,shutil
N=Path(__file__).resolve().parent;O=N/'measured-register-weights';Q=N.parent.parent
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
script=N/'count-current-semantic-matcher.py';ns={'__file__':str(script),'__name__':'collector_profile_tools'}
exec(compile(script.read_text().split('\nsource_shapes={}')[0],str(script),'exec'),ns)
driver=ns['driver'];ns['shapes']['OUT']=O
shape=lambda role,symbol:ns['shapes']['shape'](str(role),symbol)
env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}
proof=[]
for name,raw_path in [('register-linear-final',O/'hybrid32-register-linear-profiled'),('register-sqrt-final',O/'hybrid32-register-sqrt-profiled')]:
    raw=Path(raw_path);r=read(raw/'receipt.json');r['layout']=driver.symbols(raw/'frontend/program.o');(raw/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
    front=raw/'register-final-counter-input/frontend';front.mkdir(parents=True)
    normalization=ns['normal'](raw/'frontend/program.o',front/'program.o')
    for f in ['metadata.json','program.mecb']:shutil.copyfile(raw/'frontend'/f,front/f)
    (front.parent/'canonicalization.json').write_text(json.dumps(normalization,indent=2)+'\n')
    target=front.parent/'bound';driver.link.link_worker(raw/'bound',front,target)
    assert sha(target/'mech-worker')==sha(raw/'bound/mech-worker')
    profiles=[]
    for header in [475]:
        symbol='mech_compact_numeric_'+str(header)+'_vector';source=shape(raw,symbol);folder=raw/('register-final-counts-'+str(header))
        base=Q/'count-matcher-instructions.py';program=base.read_text()
        before='    root = q / f"{label}-native/final-candidate"';assert program.count(before)==1;program=program.replace(before,'    root = Path('+repr(str(target))+')')
        before='    directory = q / "matcher-dynamic-blocks" / actor';assert program.count(before)==1;program=program.replace(before,'    directory = Path('+repr(str(folder))+')')
        program=program.replace('allow_data_references=literal_start is not None','allow_data_references=True')
        scope={'__name__':'collector_diagnostic_blocks','__file__':str(base)};exec(compile(program,str(base),'exec'),scope)
        scope['count'](name+'-'+str(header),name,ns['training'],'_'+symbol,source['pool'])
        (folder/'counts.json').rename(folder/'canonical-counts.json');counts=read(folder/'canonical-counts.json')
        atom=driver.symbols(front/'program.o')['symbols']['_'+symbol]
        assert {k:atom[k] for k in ['extent','sha256','relocations']}=={k:source['atom'][k] for k in ['extent','sha256','relocations']}
        delta=source['atom']['start']-atom['start']
        for case in counts['cases'].values():
            for block in case['blocks']:block['address']=hex(int(block['address'],16)+delta)
        counts.update(object_sha256=source['object_sha256'],canonical_counts_sha256=sha(folder/'canonical-counts.json'),address_translation=delta)
        (folder/'counts.json').write_text(json.dumps(counts,indent=2)+'\n')
        (folder/'plan.json').write_text(json.dumps({'untimed':True,'shipping_object_sha256':sha(raw/'frontend/program.o'),'diagnostic_counter_source':program,'normalization':normalization,'cases':ns['training'],'scope':'Counts describe this admitted kernel only; controller fallback excluded. Diagnostic object never used for latency or shipping.'},indent=2)+'\n')
