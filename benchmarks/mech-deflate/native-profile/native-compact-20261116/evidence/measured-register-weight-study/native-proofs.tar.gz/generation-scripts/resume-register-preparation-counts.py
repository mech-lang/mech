from pathlib import Path
import subprocess
N=Path(__file__).resolve().parent;O=N/'measured-register-weights'
for script,log in [('resume-register-counts-v5.py','training-v5-counts.log'),('build-register-candidates-v5.py','candidates-v5.log'),('profile-register-candidates.py','profile-candidates.log'),('qualify-register-candidates.py','gates.log')]:
    print('starting',script,flush=True)
    with (O/log).open('w') as stream:subprocess.run(['python3',str(N/script)],stdout=stream,stderr=stream,check=True)
    print('completed',script,flush=True)
