"""Bind historical counter coordinates to actual source images without rewriting them."""
from pathlib import Path
from hashlib import sha256
import copy,json
N=Path(__file__).resolve().parent;S=N/'measured-register-weights';read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
p=N/'count-current-semantic-matcher.py';ns={'__file__':str(p),'__name__':'bind_counter_images'};exec(compile(p.read_text().split('\nsource_shapes={}')[0],str(p),'exec'),ns);symbols=ns['driver'].symbols;bindings=[]
for path in S.rglob('counts.json'):
 canonical=path.with_name('canonical-counts.json')
 if not canonical.exists() or path.name!='counts.json':continue
 root=path.parent.parent;receipt=root/'receipt.json'
 if not receipt.exists():continue
 r=read(receipt);counts=read(path);original=read(canonical);counter=root/('register-final-counter-input' if path.parent.name.startswith('register-final') else 'canonical-counter-input');front=root/'frontend/program.o';normalized=counter/'frontend/program.o';source_sha=sha(front);canonical_sha=sha(normalized)
 assert source_sha==r['artifacts']['program.o'] and canonical_sha==original['object_sha256']
 assert counts['canonical_counts_sha256']==sha(canonical)
 symbol=counts['symbol'];a=symbols(front)['symbols'][symbol];b=symbols(normalized)['symbols'][symbol];assert a['relocations']==b['relocations'];assert (a['extent'],a['sha256'])==(b['extent'],b['sha256']);delta=a['start']-b['start'];assert counts['address_translation']==delta
 expected=copy.deepcopy(original['cases'])
 for sample in expected.values():
  for block in sample['blocks']:block['address']=hex(int(block['address'],16)+delta)
 assert expected==counts['cases']
 raw_worker=root/'bound/mech-worker';normalized_worker=counter/'bound/mech-worker';assert sha(raw_worker)==sha(normalized_worker)
 plan=read(path.with_name('plan.json'));assert plan.get('source_object_sha256',plan.get('shipping_object_sha256'))==source_sha
 record={'source_object_sha256':source_sha,'canonical_object_sha256':canonical_sha,'historical_counts_alias':counts['object_sha256'],'counts_sha256':sha(path),'canonical_counts_sha256':sha(canonical),'source_object':str(front.relative_to(root)),'canonical_object':str(normalized.relative_to(root)),'source_atom':a,'canonical_atom':b,'source_worker':str(raw_worker.relative_to(root)),'canonical_worker':str(normalized_worker.relative_to(root)),'worker_sha256':sha(raw_worker),'address_translation':delta,'scope':'Exact source/canonical kernel bytes, identical linked worker, actual source pin in producer plan and complete translated block records. Historical top-level alias and timed profile files preserved.'};dest=path.with_name('source-binding.json');dest.write_text(json.dumps(record,indent=2)+'\n');bindings.append(str(dest.relative_to(S)))
(S/'counter-source-bindings.json').write_text(json.dumps({'bindings':bindings,'records_unchanged':True,'timed_profile_files_unchanged':True},indent=2)+'\n');print('bound',len(bindings),'historical counter records to exact source/canonical images')
