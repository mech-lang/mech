from pathlib import Path
N=Path(__file__).resolve().parent;P=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/benchmarks/mech-deflate/native-profile/native-compact-20261116');O=P/'evidence/measured-register-weight-study'
s=(P/'evidence/lazy-adaptive-check-study/verify.py').read_text()
s=s.replace('import zlib','import zlib\nfrom derive_register_weights import derive')
s=s.replace("assert actors == 5 and orders == len(comparison['observations']) == 10","assert actors == 6 and orders == len(comparison['observations']) == 12")
s=s.replace("    assert not summary['candidate_promoted'] and not summary['candidate_full81_qualified']","    assert not summary['candidate_promoted']")
s=s.replace("for key in ['conditional_check']:","for key in ['linear_panel','sqrt_panel']:")
begin=s.index("        for run in summary['conditional_check']['runs']:");end=s.index('        orders, executions = complete_builds',begin)
s=s[:begin]+'''        for key in ['linear_panel','sqrt_panel']:
            for run in summary[key]['runs']:
                for peer in ['roc','libdeflate']:
                    lost = [r['case'] for r in run['results'] if r['paired_x_'+peer]['mech-control']<1<=r['paired_x_'+peer]['mech-experiment']]
                    assert not lost, lost
        policy = read(runtime/'working-selection-policy.json')
        for mode, full in summary['full_qualification'].items():
            assert full['complete'] and len(full['runs'])==2
            required = policy['required_peer_wins']
            for run in full['runs']:
                for peer,names in required.items():
                    wins = {v['case'] for v in run['results'] if v['paired_x_'+peer]['mech-experiment']<1}
                    missing = sorted(set(names)-wins)
                    actual = {'wins':len(wins),'required_missing':missing,'passed':not missing and len(wins)>=policy['peer_win_floors'][peer]}
                    assert actual == run['peers'][peer]
            assert full['point_passed'] == all(v['passed'] for run in full['runs'] for v in run['peers'].values())
            count,_,zero = raw.runtime(runtime,full['runs'],81,96,required if full['point_passed'] else None)
            calls += count; zeros += zero
        derived = derive(root/'study/training-native-v5')
        recipes = read(HERE/'recipes.json')['roles']
        for mode, profile in derived.items():
            entry = next(v for v in recipes['hybrid-'+mode]['profiles'] if v['control']=='MECH_COMPACT_PHASE_REGISTER_WEIGHTS')
            assert read(HERE/entry['file']) == profile
        tests = root/'study/repository-tests'
        assert read(tests/'result.json')['exit_code']==0
        assert '79 passed; 0 failed;' in (tests/'stdout.log').read_text()
        rejection = read(root/'study/rejected-stale-v5/rejection.json')
        assert rejection['expected_failure'] and rejection['exit_code']!=0
        rejected = read(root/'study/profile-shape-rejections/result.json')
        assert len(rejected)==3 and all(v['expected_rejection'] and v['exit_code']!=0 for v in rejected.values())
'''+s[end:]
s=s.replace("'new_qualified_C_win':False", "'new_qualified_C_win':any(v['wins']>63 for full in summary['full_qualification'].values() for run in full['runs'] for peer,v in run['peers'].items() if peer=='libdeflate')")
(O/'verify.py').write_text(s)
(O/'derive_register_weights.py').write_text((N/'derive-register-weights.py').read_text())
print('prepared portable verifier for native gates, all runtime calls, full named wins, weights and complete builds')
