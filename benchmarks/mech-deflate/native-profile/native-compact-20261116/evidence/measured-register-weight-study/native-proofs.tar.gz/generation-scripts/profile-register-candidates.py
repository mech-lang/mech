"""Fresh layout profiles and checked emission for measured register allocations."""
from pathlib import Path
from hashlib import sha256
import json,os,subprocess,shutil
N=Path(__file__).resolve().parent;O=N/'measured-register-weights';Q=N.parent.parent
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}
script=N/'count-current-semantic-matcher.py';ns={'__file__':str(script),'__name__':'register_layout_tools'};exec(compile(script.read_text().split('\nsource_shapes={}')[0],str(script),'exec'),ns);driver=ns['driver'];ns['shapes']['OUT']=O
for mode in ['linear','sqrt']:
 raw=O/(mode+'-unprofiled-v5');r=read(raw/'receipt.json');front=raw/'canonical-counter-input/frontend';front.mkdir(parents=True);normalization=ns['normal'](raw/'frontend/program.o',front/'program.o')
 for f in ['metadata.json','program.mecb']:shutil.copyfile(raw/'frontend'/f,front/f)
 (front.parent/'canonicalization.json').write_text(json.dumps(normalization,indent=2)+'\n');target=front.parent/'bound';driver.link.link_worker(raw/'bound',front,target);assert sha(target/'mech-worker')==sha(raw/'bound/mech-worker')
 symbol='mech_compact_numeric_475_vector';source=ns['shapes']['shape'](str(raw),symbol);folder=raw/'block-counts-475';base=Q/'count-matcher-instructions.py';program=base.read_text();before='    root = q / f"{label}-native/final-candidate"';assert program.count(before)==1;program=program.replace(before,'    root = Path('+repr(str(target))+')');before='    directory = q / "matcher-dynamic-blocks" / actor';assert program.count(before)==1;program=program.replace(before,'    directory = Path('+repr(str(folder))+')');program=program.replace('allow_data_references=literal_start is not None','allow_data_references=True');scope={'__name__':'register_dynamic_blocks','__file__':str(base)};exec(compile(program,str(base),'exec'),scope);scope['count']('register-'+mode+'-475','register-'+mode,ns['training'],'_'+symbol,source['pool'])
 (folder/'counts.json').rename(folder/'canonical-counts.json');counts=read(folder/'canonical-counts.json');atom=driver.symbols(front/'program.o')['symbols']['_'+symbol];assert {k:atom[k] for k in ['extent','sha256','relocations']}=={k:source['atom'][k] for k in ['extent','sha256','relocations']};delta=source['atom']['start']-atom['start']
 for sample in counts['cases'].values():
  for block in sample['blocks']:block['address']=hex(int(block['address'],16)+delta)
 counts.update(object_sha256=source['object_sha256'],canonical_counts_sha256=sha(folder/'canonical-counts.json'),address_translation=delta);(folder/'counts.json').write_text(json.dumps(counts,indent=2)+'\n');(folder/'plan.json').write_text(json.dumps({'untimed':True,'shipping_object_sha256':sha(raw/'frontend/program.o'),'diagnostic_counter_source':program,'normalization':normalization,'cases':ns['training'],'scope':'This exact raw allocation only. Diagnostic objects never time shipping calls; fresh profile regenerated for changed machine graph.'},indent=2)+'\n');profile=ns['profile_matcher'](str(folder),source,folder)
 out=O/('hybrid32-register-'+mode+'-profiled');out.mkdir();flags=r['flags']|{'MECH_COMPACT_PHASE_BLOCK_LAYOUT':r['flags']['MECH_COMPACT_PHASE_BLOCK_LAYOUT']+';'+symbol+'@'+str(profile)};cmd=[r['command'][0],r['command'][1],str(out/'frontend'),'compact']
 with (out/'compile.log').open('w') as log:subprocess.run(cmd,env=env|flags,stdout=log,stderr=log,check=True)
 artifacts={f:sha(out/'frontend'/f) for f in r['artifacts']};assert artifacts['program.mecb']==r['artifacts']['program.mecb'];layout=driver.symbols(out/'frontend/program.o');receipt=r|{'command':cmd,'compile':cmd,'flags':flags,'artifacts':artifacts,'layout':layout,'text_bytes':layout['text_bytes']};(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 checked=out/'checked-emission';cmd2=[cmd[0],cmd[1],str(checked/'frontend'),'compact']
 with (out/'checked.log').open('w') as log:subprocess.run(cmd2,env=env|flags|{'MECH_COMPACT_PAIR_REGISTER_SPILLS':'checked'},stdout=log,stderr=log,check=True)
 assert {f:sha(checked/'frontend'/f) for f in artifacts}==artifacts;driver.link.link_worker(raw/'bound',out/'frontend',out/'bound');driver.link.check_worker(out/'bound','register-'+mode+'-profiled');print(mode,'fresh profile text',receipt['text_bytes'],'all3 checked exact',flush=True)
