from pathlib import Path
import json,subprocess,shutil,os
N=Path(__file__).resolve().parent;script=N/'count-current-semantic-matcher.py';ns={'__file__':str(script),'__name__':'source_search_final_gates'};exec(compile(script.read_text().split('\nsource_shapes={}')[0],str(script),'exec'),ns);driver=ns['driver'];sha=ns['sha'];read=lambda p:json.loads(p.read_text())
control='source-search-control-profiled';role='source-search-split-profiled'
for item in [control,role]:
 p=N/item;r=read(p/'receipt.json');driver.link.link_worker(N/'bounded-histogram-word/bound',p/'frontend',p/'bound');pin=read(p/'bound/runtime.json');pin.pop('size_bytes',None);pin.pop('encoder_sha256',None);pin['encoder_text_bytes']=r['text_bytes'];(p/'bound/runtime.json').write_text(json.dumps(pin,indent=2)+'\n');driver.link.check_worker(p/'bound','source-search-profiled-'+item);print(item,'all162successes',flush=True)
for cmd in [['python3',str(N/'qualify-input-windows.py'),'check',control],['python3',str(N/'check-window-profiled-candidate.py'),control]]:
 with (N/('source-search-final-'+Path(cmd[1]).stem+'.log')).open('w') as log:subprocess.run(cmd,stdout=log,stderr=log,check=True)
print(control,'allerror/stack/recovery/checked gates pass',flush=True)
old=N/'linked-input-window-current-source-search-split-homes';study=N/('linked-input-window-current-'+role);study.mkdir();(study/'worker-checks').mkdir();shutil.copytree(old/'worker-checks/maintained',study/'worker-checks/maintained')
mp=study/'worker-checks/maintained';mr=read(mp/'runtime.json');prior_dir=Path(mr['linked_encoder']['path']).parent;mr['link']=[arg.replace(str(prior_dir),str(mp)) for arg in mr['link']]
with (mp/'relocation-relink.log').open('w') as log:subprocess.run(mr['link'],stdout=log,stderr=log,check=True)
assert sha(mp/'mech-worker')==mr['worker_sha256'];mr['linked_encoder']['path']=str(mp/'program.o');(mp/'runtime.json').write_text(json.dumps(mr,indent=2)+'\n')
driver.link.link_worker(N/role/'bound',N/role/'frontend',study/'worker-checks'/role);driver.link.check_worker(study/'worker-checks'/role,'source-search-final-stage')
s=(old/'verify-linked.py').read_text().replace('source-search-split-homes',role);(study/'verify-linked.py').write_text(s)
# Checked backend allocation must emit exactly the same new source artifacts.
r=read(N/role/'receipt.json');out=N/role/'checked-emission';out.mkdir();cmd=[r['compile'][0],r['compile'][1],str(out/'frontend'),'compact'];flags=r['flags']|{'MECH_COMPACT_PAIR_REGISTER_SPILLS':'checked'}
with (out/'compile.log').open('w') as log:subprocess.run(cmd,env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}|flags,stdout=log,stderr=log,check=True)
a={f:sha(out/'frontend'/f) for f in r['artifacts']};assert a==r['artifacts'];(out/'result.json').write_text(json.dumps({'command':cmd,'artifacts':a,'normal_checked_identical':True},indent=2)+'\n')
with (N/'source-search-final-source-aware.log').open('w') as log:subprocess.run(['python3',str(N/'check-source-search-origins.py'),role],stdout=log,stderr=log,check=True)
print(role,'source-aware sixerrors/stack/12recovery/checked pass',flush=True)
(N/'source-search-specialization/ready.json').write_text(json.dumps({'roles':[control,role],'all162successes_each':True,'all6checked_failure_actions_each':True,'all12recovery_pairs_each':True,'normal_checked_identical_each':True,'stack_cap':5280,'clock_started':False,'worker_sha256':{x:sha(N/x/'bound/mech-worker') for x in [control,role]}},indent=2)+'\n')
