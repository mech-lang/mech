"""Derive eligible direct homes and scorer labels from each source's own graph."""
from pathlib import Path
from hashlib import sha256
import json,os,subprocess
N=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();O=N/'source-search-specialization';plan=read(O/'plan.json');flags=plan['held_flags'].copy();old_homes=flags.pop('MECH_COMPACT_DIRECT_SCALAR_HOMES')
for role,source in [('source-search-control-homes',plan['original_source']),('source-search-split-homes',plan['variant_source'])]:
 out=N/role;out.mkdir();census=out/'home-census';census.mkdir();cmd=[plan['compiler'],source,str(census/'frontend'),'compact'];cf=flags|{'MECH_COMPACT_DIRECT_SCALAR_HOME_CENSUS':str(census/'homes.json')}
 with (census/'compile.log').open('w') as log:subprocess.run(cmd,env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}|cf,stdout=log,stderr=log,check=True)
 homes=read(census/'homes.json');selected=[h['slot'] for h in homes if h['admitted']];assert selected
 meta=read(census/'frontend/metadata.json');scorers=[p for p in meta['numeric_phases'] if p.get('composed_variant',{}).get('admission',{}).get('minimum_costs')==545];assert len(scorers)==1,[(p['header'],p.get('composed_variant',{}).get('admission',{})) for p in meta['numeric_phases']]
 scorer=scorers[0]['header'];assert any(p['header']==475 for p in meta['numeric_phases']);hist=scorer-188;assert any(p['header']==hist for p in meta['numeric_phases'])
 # The narrow source edit inserts only within the collector. Assert every
 # later phase has the same interface after a common header displacement.
 baseline=read(N/'source-search-control/frontend/metadata.json');delta=scorer-3009
 for prior in baseline['numeric_phases']:
  header=prior['header']+(delta if prior['header']>475 else 0);current=next(p for p in meta['numeric_phases'] if p['header']==header)
  if header!=475:assert (current['input_words'],current['output_words'])==(prior['input_words'],prior['output_words'])
 ff=flags|{'MECH_COMPACT_DIRECT_SCALAR_HOMES':','.join(map(str,selected)),'MECH_COMPACT_REFUSE_GENERAL_VECTORS':f'475,{hist},362','MECH_QUALIFY_PHASE_INPUT_PACKET':f'only:mech_compact_numeric_{scorer},mech_compact_numeric_{scorer}_vector,mech_compact_numeric_{scorer}_no_growth'}
 command=[plan['compiler'],source,str(out/'frontend'),'compact']
 with (out/'compile.log').open('w') as log:subprocess.run(command,env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}|ff,stdout=log,stderr=log,check=True)
 metadata=read(out/'frontend/metadata.json');receipt={'source_base':'89dd67efb617e44e72aaa0710101e566661e8600','compiler_sha256':plan['compiler_sha256'],'compile':command,'command':command,'flags':ff,'artifacts':{f:sha(out/'frontend'/f) for f in ['program.o','metadata.json','program.mecb']},'source_sha256':sha(source),'scorer_header':scorer,'post_collector_header_delta':delta,'home_census_sha256':sha(census/'homes.json'),'admitted_direct_homes':len(selected),'held_source_experiment_plan_sha256':sha(O/'plan.json')}
 receipt.update(object_sha256=receipt['artifacts']['program.o'],metadata_sha256=receipt['artifacts']['metadata.json'],bytecode_sha256=receipt['artifacts']['program.mecb'])
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(role,'code-root',metadata['code_bytes'],'stack',metadata['stack_bytes'],'homes',len(selected),'scorer',scorer,flush=True)
