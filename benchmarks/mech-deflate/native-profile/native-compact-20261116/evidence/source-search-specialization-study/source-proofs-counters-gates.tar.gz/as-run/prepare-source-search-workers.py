from pathlib import Path
import json,subprocess
N=Path(__file__).resolve().parent
script=N/'count-current-semantic-scorer.py';src=script.read_text().split('\nsource_shapes={}')[0];ns={'__file__':str(script),'__name__':'source_search_tools'};exec(compile(src,str(script),'exec'),ns);driver=ns['driver'];sha=ns['sha']
roles=['source-search-control-homes','source-search-split-homes']
for role in roles:
 folder=N/role;receipt=json.loads((folder/'receipt.json').read_text());layout=driver.symbols(folder/'frontend/program.o');receipt.update(layout=layout,text_bytes=layout['text_bytes']);(folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(role,'wholetext',layout['text_bytes'],'matcher',layout['symbols']['_mech_compact_numeric_475_vector']['extent'],flush=True)
for role in roles:
 for command in [['python3',str(N/'qualify-input-windows.py'),'check',role],['python3',str(N/'check-window-profiled-candidate.py'),role]]:
  name='source-search-'+role+'-'+('contracts' if 'check' in command else 'recoveries')+'.log'
  with (N/name).open('w') as log:subprocess.run(command,stdout=log,stderr=log,check=True)
  print(role,command[1].rsplit('/',1)[-1],'passed',flush=True)
(N/'source-search-specialization/ready.json').write_text(json.dumps({'roles':roles,'all_contracts_passed':True,'all_checked_artifacts_exact':True,'all12_error_recovery_pairs_passed':True,'clock_started':False},indent=2)+'\n')
