"""Preserve named failure actions across the separately pinned source edit."""
from pathlib import Path
from hashlib import sha256
import json,os,subprocess,shutil,sys
N=Path(__file__).resolve().parent;P=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/benchmarks/mech-deflate/native-profile/native-compact-20261116');read=lambda p:json.loads(p.read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();role=sys.argv[1] if len(sys.argv)>1 else 'source-search-split-homes';study=N/('linked-input-window-current-'+role);plan=read(N/'source-search-specialization/plan.json')
before=Path(plan['original_source']);after=Path(plan['variant_source']);old,new=plan['changed_expression']['before'],plan['changed_expression']['after'];assert before.read_text().count(old)==1 and after.read_text()==before.read_text().replace(old,new)
a=read(study/'worker-checks/maintained/metadata.json')['origins'];b=read(study/'worker-checks'/role/'metadata.json')['origins'];delta=len(b)-len(a);assert delta==838
# The edit expands the collector. All later action-local identities remain
# equal in order; lexical block labels are either unchanged or displaced85.
assert all((o['node'],o['local'])==(b[i+delta]['node'],b[i+delta]['local']) for i,o in enumerate(a[2779:],2779))
assert all((b[i+delta]['block']-o['block']) in [0,85] if o['block'] is not None and b[i+delta]['block'] is not None else o['block']==b[i+delta]['block'] for i,o in enumerate(a[2779:],2779))
mapping={str(i):{'site':i+(delta if i>=2779 else 0)} for i in [23,69,7164]}
report={'source_mapping':mapping,'original_source_sha256':sha(before),'candidate_source_sha256':sha(after),'changed_expression_sha256':sha256((old+'\n'+new).encode()).hexdigest(),'unchanged_suffix_start':2779,'instruction_displacement':delta,'lexical_block_displacements':[0,85],'node_local_identities_preserved_in_suffix':True,'scope':'Only named final-output allocation failures before the edit or in unchanged source suffix. Actual native status/action origins are independently checked by the existing six-case failure worker; no arbitrary changed-collector errors are mapped.'}
mapfile=N/'source-search-specialization/source-origin-map.json';mapfile.write_text(json.dumps(report,indent=2)+'\n')
for oldsite,row in mapping.items():
 assert (a[int(oldsite)]['node'],a[int(oldsite)]['local'])==(b[row['site']]['node'],b[row['site']]['local'])
original=(study/'verify-linked.py').read_text();replacement='''assert all((origins[0][int(old)]['node'],origins[0][int(old)]['local']) == (origins[1][site['site']]['node'],origins[1][site['site']]['local']) for old,site in json.loads(Path(MAPFILE).read_text())['source_mapping'].items())\nenv['MECH_ERROR_SOURCE_MAP']=MAPFILE'''.replace('MAPFILE',repr(str(mapfile)))
assert original.count('assert all(origin == origins[0] for origin in origins)')==1
s=original.replace('assert all(origin == origins[0] for origin in origins)',replacement).replace('out = study / "linked-proofs"','out = study / "linked-proofs-source-aware"')
file=study/'verify-source-origins.py';file.write_text(s)
with (study/'verify-source-origins.log').open('w') as log:subprocess.run(['python3',str(file)],stdout=log,stderr=log,check=True)
result=read(study/'linked-proofs-source-aware/result.json');peak=max(result['peak_stack_bytes'].values());assert peak<=5280
(N/role/'linked-proof.json').write_text(json.dumps({'result':str(study/'linked-proofs-source-aware/result.json'),'sha256':sha(study/'linked-proofs-source-aware/result.json'),'peak_stack_bytes':peak,'source_origin_mapping':str(mapfile),'source_origin_mapping_sha256':sha(mapfile),'scope':'Different source; all162successes match, named failure actions mapped in unchanged source with status preserved, stackmeasured.'},indent=2)+'\n')
# Allocation-fault/recovery checks use the same six named actions with each
# source's own instruction numbers, while retaining the exact status policy.
packet=N/'source-search-specialization/recovery-packet';packet.mkdir(exist_ok=True)
for name in ['worker.rs','pinned_allocator.rs']:shutil.copyfile(P/name,packet/name)
policy=read(P/'qualification-policy-v3.json')
for case,want in policy['checked_failures'].items():want['origin']=mapping[str(want['origin'])]['site']
policy['separately_pinned_source_sha256']=sha(after);policy['source_origin_mapping_sha256']=sha(mapfile);(packet/'qualification-policy-v3.json').write_text(json.dumps(policy,indent=2)+'\n')
fixtures=read(P/'fixtures.json')
for case in fixtures:
 for field in ['input','prefix','expected']:case[field]=str(P/case[field])
(packet/'fixtures.json').write_text(json.dumps(fixtures,indent=2)+'\n')
recover=(N/'recover-vector-word-candidate.py').read_text();needle="PACKET=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/benchmarks/mech-deflate/native-profile/native-compact-20261116')";assert recover.count(needle)==1
recover=recover.replace(needle,'PACKET=Path('+repr(str(packet))+')').replace("h=run_path(str(PACKET/'rebuild_checks.py')", "h=run_path(str(Path("+repr(str(P/'rebuild_checks.py'))+"))")
# The helper's __file__ location still points at N, preserving original role paths.
rf=N/'recover-source-search.py';rf.write_text(recover)
with (N/(role+'-recoveries.log')).open('w') as log:subprocess.run(['python3',str(rf),role],stdout=log,stderr=log,check=True)
print('source-specific sixerror actions, stack and12fault/recovery pairs pass',flush=True)
