"""Two complete21case orders, all120permutations of five freshly constructed actors."""
from pathlib import Path
from hashlib import sha256
import json,os,sys
N=Path(__file__).resolve().parent;Q=N.parent.parent;read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();timer=Q/'compare-library.py';selected=N/'narrow-packet-eight-probe-profiled/bound';base=N/'source-search-control-profiled/bound';trial=N/'source-search-split-profiled/bound'
cases=['one-stored','seven-stored-prefix','empty','eight-overlap','320-overlap','prefix-periodic-1024','prefix-natural-1024','prefix-natural-4096','prefix-natural-8192','prefix-random-1024','prefix-random-4096','prefix-random-8192','prefix-random-16384','prefix-random-32767','prefix-random-32768','prefix-random-32769','prefix-random-65535','prefix-random-65536','prefix-random-65537','prefix-random-1048576','16384-distribution-change']
plan={'cases':cases,'orders':['forward','reverse'],'actors':{'mech-control':str(selected),'mech-source-control':str(base),'mech-experiment':str(trial),'roc':'pinned','libdeflate':'pinnedC12'},'blocks_per_case':120,'timer_sha256':sha(timer),'controller_sha256':sha(Path(__file__)),'mech_worker_sha256':{name:sha(folder/'mech-worker') for name,folder in [('mech-control',selected),('mech-source-control',base),('mech-experiment',trial)]},'scope':'Complete compact call with fresh heap/construction through private cleanup for eachMech actor; all120balanced fiveactorpermutations inboth21caseorders. Sourcevariant isolated againstsamegeneric-hint/proof-derived-layout sourcecontrol, and comparedsimultaneously toselected81Roc/63Cworker andpinnedpeers. Sourcevariantnotfull81qualified.','load_before':os.getloadavg()}
(N/'source-search-specialization/timing-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
program=timer.read_text();needle="selected = {case['name'] for case in cases}";assert program.count(needle)==1;program=program.replace(needle,'selected = '+repr(set(cases)))
needle="ACTORS = [BASELINE, CANDIDATE, 'roc', 'libdeflate']";assert program.count(needle)==1;program=program.replace(needle,"ACTORS = [BASELINE, 'mech-source-control', CANDIDATE, 'roc', 'libdeflate']")
needle='for actor, folder in [(BASELINE,Path(before)), (CANDIDATE,Path(after))]:';assert program.count(needle)==1;program=program.replace(needle,"for actor, folder in [(BASELINE,Path(before)), (CANDIDATE,Path(after)), ('mech-source-control',Path("+repr(str(base))+"))]:")
needle='for actor in (BASELINE, CANDIDATE):';assert program.count(needle)==1;program=program.replace(needle,"for actor in (BASELINE, CANDIDATE, 'mech-source-control'):")
runs=[]
for order in plan['orders']:
 label='source-search-fiveway-'+order;sys.argv=[str(timer),label,str(selected),str(trial)]+(['reverse'] if order=='reverse' else [])
 exec(compile(program,str(timer),'exec'),{'__file__':str(timer),'__name__':'__main__'})
 rows=read(Q/label/'summary.json');assert len(rows)==21;runs.append({'order':order,'run':str(Q/label),'summary_sha256':sha(Q/label/'summary.json'),'results':rows});(N/'source-search-specialization/timing-results.json').write_text(json.dumps({'plan':plan,'runs':runs,'complete':len(runs)==2},indent=2)+'\n');print('Finished',order,'all21cases/all120blocks',flush=True)
