"""Separate ordinary-Mech source experiment; original source stays unchanged."""
from pathlib import Path
from hashlib import sha256
import json,os,subprocess
N=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
O=N/'source-search-specialization';O.mkdir();compiler=read(N/'parallel-low-compiler/build.json');prior=read(N/'narrow-packet-eight-probe-profiled/receipt.json');original=Path(prior['compile'][1]);assert sha(original)=='653597f08f889908c48610e90aa65e94a77847fb34500d0cc3a046f83cd3d299'
old='''    | true => bt-advance(mf, hash3, hash4, input, current-base, bits/wrapping-sub(position, current-base), max-length, searching, 300u64, cache, pointer, previous-match)'''
new='''    | true => (searching?
      | true => bt-without-prefix(bt-get-matches(mf, hash3, hash4, input, current-base, bits/wrapping-sub(position, current-base), max-length, max-length, 300u64, cache, pointer))
      | false => bt-advance(mf, hash3, hash4, input, current-base, bits/wrapping-sub(position, current-base), max-length, false, 300u64, cache, pointer, previous-match))'''
s=original.read_text();assert s.count(old)==1
source=O/'program.mec';source.write_text(s.replace(old,new))
# These are source-graph coordinate/layout hints, not semantic permissions.
# Remove them from BOTH arms. Keep the production selected worker as a
# separate third control for any later whole-call timing.
remove=['MECH_COMPACT_PHASE_BLOCK_LAYOUT','MECH_COMPACT_SHARE_CONTROLLER_WINDOWS','MECH_COMPACT_LAYOUT_CONTROLLER_WINDOWS','MECH_COMPACT_CONTINUATION_WINDOWS','MECH_COMPACT_REFUSE_GENERAL_VECTORS','MECH_QUALIFY_PHASE_INPUT_PACKET']
flags={k:v for k,v in prior['flags'].items() if k not in remove};flags['MECH_FOLD_NARROW_PACKED_WORDS']='phis'
plan={'original_source':str(original),'original_source_sha256':sha(original),'variant_source':str(source),'variant_source_sha256':sha(source),'compiler':compiler['compiler'],'compiler_sha256':compiler['compiler_sha256'],'changed_expression':{'before':old,'after':new},'held_flags':flags,'omitted_source_coordinate_hints':{k:prior['flags'][k] for k in remove},'scope':'Held-hint whole-source experiment, not production selection. Both source arms use the same generic flags. Current selected source/bytecode/worker remain unchanged. Must measure against selected63 as well as this held-hint baseline.'}
(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for role,input_path in [('source-search-control',original),('source-search-split',source)]:
 folder=N/role;folder.mkdir();cmd=[compiler['compiler'],str(input_path),str(folder/'frontend'),'compact']
 with (folder/'compile.log').open('w') as log:subprocess.run(cmd,env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}|flags,stdout=log,stderr=log,check=True)
 meta=read(folder/'frontend/metadata.json');scorers=[p for p in meta['numeric_phases'] if p.get('composed_variant',{}).get('admission',{}).get('minimum_cost_words')==545]
 print(role,'firstpass code',meta['code_bytes'],'stack',meta['stack_bytes'],'phases',[(p['header'],p['code_bytes'],list(p.get('composed_variant',{}).get('admission',{}))) for p in meta['numeric_phases']],flush=True)
 receipt={'source_base':'89dd67efb617e44e72aaa0710101e566661e8600','compiler_sha256':compiler['compiler_sha256'],'compile':cmd,'command':cmd,'flags':flags,'artifacts':{f:sha(folder/'frontend'/f) for f in ['program.o','metadata.json','program.mecb']},'source_sha256':sha(input_path),'held_source_experiment_plan_sha256':sha(O/'plan.json')}
 receipt.update(object_sha256=receipt['artifacts']['program.o'],metadata_sha256=receipt['artifacts']['metadata.json'],bytecode_sha256=receipt['artifacts']['program.mecb'])
 (folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Both source arms emitted; inspect before any timing.',flush=True)
