//! Four source candidates, with native unsigned low halves and no cost array.
use super::*;
use crate::native_artifact::codegen::common::ssa_words::Words;
use cranelift_codegen::ir::{ConstantData, Endianness, InstBuilder, MemFlags, Value, types};
use cranelift_frontend::FunctionBuilder;
use std::collections::BTreeMap;

pub(super) fn constant(b: &mut FunctionBuilder<'_>, values: [u32; 4]) -> Value {
    let bytes = values
        .into_iter()
        .flat_map(u32::to_le_bytes)
        .collect::<Vec<_>>();
    let id = b.func.dfg.constants.insert(ConstantData::from(bytes));
    b.ins().vconst(types::I32X4, id)
}

/// Project four packed low words in descending element order. Swapping the
/// input halves first lets AArch64 use UZP1 followed by REV64, without a
/// shuffle-table load or a constrained consecutive register pair.
pub(super) fn reverse_low_words(b: &mut FunctionBuilder<'_>, first: Value, second: Value) -> Value {
    let low_words = b.func.dfg.immediates.push(ConstantData::from(vec![
        0u8, 1, 2, 3, 8, 9, 10, 11, 16, 17, 18, 19, 24, 25, 26, 27,
    ]));
    let packed = b.ins().shuffle(second, first, low_words);
    let pairs = b.func.dfg.immediates.push(ConstantData::from(vec![
        4u8, 5, 6, 7, 0, 1, 2, 3, 12, 13, 14, 15, 8, 9, 10, 11,
    ]));
    b.ins().shuffle(packed, packed, pairs)
}

pub(super) struct Inputs {
    words: BTreeMap<usize, Value>,
    vector_words: BTreeMap<usize, Value>,
    bases: BTreeMap<Window, Value>,
}

/// An address for the current admitted element. The wide form reads all of
/// a packed U64 cell and projects its low word on little-endian targets.
#[derive(Clone, Copy)]
pub(super) enum ScalarRead {
    LowWord(Value),
    PackedWord(Value),
}

impl Inputs {
    pub fn new(
        b: &mut FunctionBuilder<'_>,
        words: &Words,
        proof: &Proof,
        shadow: usize,
        cost: &Cost,
    ) -> Self {
        let mut out = Self {
            words: BTreeMap::new(),
            vector_words: BTreeMap::new(),
            bases: BTreeMap::new(),
        };
        out.capture(b, words, proof, shadow, cost);
        out
    }
    fn capture(
        &mut self,
        b: &mut FunctionBuilder<'_>,
        words: &Words,
        proof: &Proof,
        shadow: usize,
        cost: &Cost,
    ) {
        match cost {
            Cost::Word(slot) => {
                self.words.entry(*slot).or_insert_with(|| {
                    let value = words.read(b, *slot);
                    let value = b.ins().ireduce(types::I32, value);
                    value
                });
            }
            Cost::Read(w) => {
                self.bases.entry(*w).or_insert_with(|| {
                    let view = shadow + proof.view(w.array);
                    let base = words.read(b, view);
                    let ordinal = if w.reverse {
                        let length = words.read(b, view + 1);
                        b.ins().iadd_imm(length, (w.delta as i64).wrapping_neg())
                    } else {
                        b.ins().iconst(types::I64, w.delta as i64)
                    };
                    let shift = if proof.arrays[w.array].width == 8 {
                        3
                    } else {
                        2
                    };
                    let offset = b.ins().ishl_imm(ordinal, shift);
                    // The current entry already admits every reached read.
                    // This is integer address geometry, with no load at the
                    // adjusted base and no retained authority across entries.
                    b.ins().iadd(base, offset)
                });
            }
            Cost::Add(a, c) | Cost::And(a, c) | Cost::Or(a, c) | Cost::Xor(a, c) => {
                self.capture(b, words, proof, shadow, a);
                self.capture(b, words, proof, shadow, c);
            }
            _ => {}
        }
    }
    pub(super) fn prepare_vector_words(&mut self, b: &mut FunctionBuilder<'_>) {
        self.vector_words.extend(
            self.words
                .iter()
                .map(|(&slot, &word)| (slot, b.ins().splat(types::I32X4, word))),
        );
    }

    pub fn emit(
        &self,
        b: &mut FunctionBuilder<'_>,
        proof: &Proof,
        cost: &Cost,
        k: Value,
        indices: Value,
    ) -> Value {
        self.emit_with_pointers(b, proof, cost, k, indices, &[])
    }

    pub(super) fn emit_with_pointers(
        &self,
        b: &mut FunctionBuilder<'_>,
        proof: &Proof,
        cost: &Cost,
        k: Value,
        indices: Value,
        pointers: &[(Window, Value)],
    ) -> Value {
        match cost {
            Cost::Constant(value) => constant(b, [*value; 4]),
            Cost::Word(slot) => self
                .vector_words
                .get(slot)
                .copied()
                .unwrap_or_else(|| b.ins().splat(types::I32X4, self.words[slot])),
            Cost::Index => indices,
            Cost::Read(w) => {
                let pointer = pointers
                    .iter()
                    .find_map(|(window, pointer)| (window == w).then_some(*pointer))
                    .unwrap_or_else(|| self.pointer(b, proof, *w, k));
                self.read_at(b, proof, *w, pointer)
            }
            Cost::Add(a, c) | Cost::And(a, c) | Cost::Or(a, c) | Cost::Xor(a, c) => {
                let a = self.emit_with_pointers(b, proof, a, k, indices, pointers);
                let c = self.emit_with_pointers(b, proof, c, k, indices, pointers);
                match cost {
                    Cost::Add(..) => b.ins().iadd(a, c),
                    Cost::And(..) => b.ins().band(a, c),
                    Cost::Or(..) => b.ins().bor(a, c),
                    _ => b.ins().bxor(a, c),
                }
            }
        }
    }
    pub(super) fn pointer(
        &self,
        b: &mut FunctionBuilder<'_>,
        proof: &Proof,
        w: Window,
        k: Value,
    ) -> Value {
        let shift = if proof.arrays[w.array].width == 8 {
            3
        } else {
            2
        };
        let offset = b.ins().ishl_imm(k, shift);
        let base = self.bases[&w];
        if w.reverse {
            b.ins().isub(base, offset)
        } else {
            b.ins().iadd(base, offset)
        }
    }
    fn read_at(
        &self,
        b: &mut FunctionBuilder<'_>,
        proof: &Proof,
        w: Window,
        pointer: Value,
    ) -> Value {
        let width = proof.arrays[w.array].width;
        let pointer = if w.reverse {
            b.ins().iadd_imm(pointer, -3 * width as i64)
        } else {
            pointer
        };
        // Every lane lies in the original initialized window. Alignment is not
        // inferred from allocation capacity or the vector load's width.
        let flags = MemFlags::new().with_notrap();
        let first = b.ins().load(types::I8X16, flags, pointer, 0);
        let bytes = if width == 8 {
            let second = b.ins().load(types::I8X16, flags, pointer, 16);
            if w.reverse
                && cfg!(target_arch = "aarch64")
                && std::env::var_os("MECH_ORDERED_REVERSE_LOW_WORDS").is_some()
            {
                reverse_low_words(b, first, second)
            } else {
                let mask = if w.reverse {
                    [24u8, 25, 26, 27, 16, 17, 18, 19, 8, 9, 10, 11, 0, 1, 2, 3]
                } else {
                    [0u8, 1, 2, 3, 8, 9, 10, 11, 16, 17, 18, 19, 24, 25, 26, 27]
                };
                let mask = b
                    .func
                    .dfg
                    .immediates
                    .push(ConstantData::from(mask.to_vec()));
                b.ins().shuffle(first, second, mask)
            }
        } else if w.reverse {
            let mask = b.func.dfg.immediates.push(ConstantData::from(vec![
                12u8, 13, 14, 15, 8, 9, 10, 11, 4, 5, 6, 7, 0, 1, 2, 3,
            ]));
            b.ins().shuffle(first, first, mask)
        } else {
            first
        };
        b.ins().bitcast(
            types::I32X4,
            MemFlags::new().with_endianness(Endianness::Little),
            bytes,
        )
    }

    pub(super) fn uses_index(cost: &Cost) -> bool {
        match cost {
            Cost::Index => true,
            Cost::Add(left, right)
            | Cost::And(left, right)
            | Cost::Or(left, right)
            | Cost::Xor(left, right) => Self::uses_index(left) || Self::uses_index(right),
            _ => false,
        }
    }

    pub fn scalar(
        &self,
        b: &mut FunctionBuilder<'_>,
        proof: &Proof,
        cost: &Cost,
        k: Value,
        pointers: &[(Window, ScalarRead)],
    ) -> Value {
        match cost {
            Cost::Constant(value) => b.ins().iconst(types::I32, i64::from(*value)),
            Cost::Word(slot) => self.words[slot],
            Cost::Index => b.ins().ireduce(types::I32, k),
            Cost::Read(w) => {
                let address = pointers
                    .iter()
                    .find_map(|(window, pointer)| (*window == *w).then_some(*pointer))
                    .unwrap_or_else(|| ScalarRead::LowWord(self.pointer(b, proof, *w, k)));
                let flags = MemFlags::new().with_notrap();
                match address {
                    ScalarRead::LowWord(pointer) => b.ins().load(types::I32, flags, pointer, 0),
                    ScalarRead::PackedWord(pointer) => {
                        debug_assert!(
                            cfg!(target_endian = "little") && proof.arrays[w.array].width == 8
                        );
                        let packed = b.ins().load(types::I64, flags, pointer, 0);
                        b.ins().ireduce(types::I32, packed)
                    }
                }
            }
            Cost::Add(a, c) | Cost::And(a, c) | Cost::Or(a, c) | Cost::Xor(a, c) => {
                let a = self.scalar(b, proof, a, k, pointers);
                let c = self.scalar(b, proof, c, k, pointers);
                match cost {
                    Cost::Add(..) => b.ins().iadd(a, c),
                    Cost::And(..) => b.ins().band(a, c),
                    Cost::Or(..) => b.ins().bor(a, c),
                    _ => b.ins().bxor(a, c),
                }
            }
        }
    }
}
