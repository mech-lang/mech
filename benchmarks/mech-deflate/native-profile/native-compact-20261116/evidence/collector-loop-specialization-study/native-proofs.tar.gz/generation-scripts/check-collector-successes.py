from pathlib import Path
from hashlib import sha256
import json,subprocess,select,os,sys
N=Path(__file__).resolve().parent;Q=N.parent.parent;O=N/'collector-loop-specialization'
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
fixtures=read(Q/'fixtures.json')
for name in sys.argv[1:] or ['hybrid32-homes','original-homes']:
 out=O/name;bound=out/'bound';p=subprocess.Popen([str(bound/'mech-worker'),str(bound/'metadata.json'),str(Q/'fixtures.json')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=(out/'native-check.stderr').open('wb'));buffer=b''
 def line():
  global buffer
  while b'\n' not in buffer:
   assert select.select([p.stdout],[],[],30)[0];part=os.read(p.stdout.fileno(),65536);assert part,(name,p.poll());buffer+=part
  value,buffer=buffer.split(b'\n',1);return value.decode()
 def send(s):p.stdin.write(s.encode());p.stdin.flush()
 assert line()=='SESSION_READY';records=[]
 for i,case in enumerate(fixtures):
  send(f"C\t{i}\t0\n");assert line()=='CASE_READY\t'+case['name'];send('NN')
  for _ in range(2):
   v=json.loads(line());assert v['case']==case['name'];assert all(v[k] for k in ['exact_reference','independent_inflation','input_alias_unchanged','borrowed_output_alias_unchanged']);assert v['nonreturned_private_bytes_at_return']==0;assert v['capacity']==case['capacity'];records.append(v)
  assert line()=='CASE_DONE\t'+case['name']
 send('Q\n');assert p.wait(timeout=10)==0
 baseline=N/('linked-input-window-current-source-sort-hybrid-profiled-source-sort-hybrid32-profiled/worker-checks/source-sort-hybrid32-profiled/smokes.json' if name.startswith('hybrid32') else 'linked-input-window-current-source-sort-shell-profiled-source-sort-bucket-profiled/worker-checks/source-sort-shell-profiled/smokes.json')
 prior=read(baseline);assert len(prior)==len(records)==162
 ignored={'seconds'}
 differences=[]
 for before,after in zip(prior,records):
  difference={k:[before.get(k),after.get(k)] for k in set(before)|set(after) if before.get(k)!=after.get(k) and k not in ignored}
  if difference:differences.append({'case':after['case'],'changes':difference})
 result={'role':name,'worker_sha256':sha(bound/'mech-worker'),'checked_calls':len(records),'all162pass':len(records)==162,'records':records,'baseline_observation_differences':differences}
 (out/'native-check.json').write_text(json.dumps(result,indent=2)+'\n');print(name,'all162 outputs/aliases/inflation/cleanup pass','observation differences',len(differences),flush=True)
 if differences: print(json.dumps(differences[:2],indent=2),flush=True)
