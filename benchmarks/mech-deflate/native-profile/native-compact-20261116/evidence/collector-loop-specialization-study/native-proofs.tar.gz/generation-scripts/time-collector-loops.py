"""Both21case24block orders, after native gates; no concurrent producers."""
from pathlib import Path
from hashlib import sha256
import json,os,sys
N=Path(__file__).resolve().parent;Q=N.parent.parent;O=N/'collector-loop-specialization'
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
timer=Q/'compare-library.py';control=N/'source-sort-hybrid32-profiled/bound';candidate=O/'hybrid32-profiled/bound'
cases=['one-stored','seven-stored-prefix','empty','eight-overlap','320-overlap','prefix-periodic-1024','prefix-natural-1024','prefix-natural-4096','prefix-natural-8192','prefix-random-1024','prefix-random-4096','prefix-random-8192','prefix-random-16384','prefix-random-32767','prefix-random-32768','prefix-random-32769','prefix-random-65535','prefix-random-65536','prefix-random-65537','prefix-random-1048576','16384-distribution-change']
gate=read(O/'hybrid32-profiled/linked-proof.json');assert gate['candidate_peak_stack_bytes']<=5280
assert read(O/'hybrid32-profiled/promotion-recoveries/result.json')['benchmark_worker_sha256']==sha(candidate/'mech-worker')
plan={'cases':cases,'orders':['forward','reverse'],'actors':{'mech-control':str(control),'mech-experiment':str(candidate),'roc':'pinned','libdeflate':'pinnedC12'},'blocks_per_case':24,'timer_sha256':sha(timer),'controller_sha256':sha(Path(__file__)),'worker_sha256':{'control':sha(control/'mech-worker'),'candidate':sha(candidate/'mech-worker')},'scope':'Complete fresh heap/context call through cleanup, all24fouractorpermutations, both21caseorders. Qualified HF-U32 source versus separately pinned collector-loop source; generic source-specific homes and fresh9case matcher layout policy. Immutable-defaulted-read scope is all for the new source and matcher-only for heldcontrol. No full81win claim.','load_before':os.getloadavg()}
(O/'timing-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
program=timer.read_text();before="selected = {case['name'] for case in cases}";assert program.count(before)==1;program=program.replace(before,'selected = '+repr(set(cases)))
runs=[]
for order in plan['orders']:
    label='collector-search-skip-'+order;sys.argv=[str(timer),label,str(control),str(candidate)]+(['reverse'] if order=='reverse' else [])
    exec(compile(program,str(timer),'exec'),{'__file__':str(timer),'__name__':'__main__'})
    rows=read(Q/label/'summary.json');assert len(rows)==21
    runs.append({'order':order,'run':str(Q/label),'summary_sha256':sha(Q/label/'summary.json'),'results':rows})
    (O/'timing-results.json').write_text(json.dumps({'plan':plan,'runs':runs,'complete':len(runs)==2},indent=2)+'\n')
    print('Finished',order,'all21cases/all24blocks',flush=True)
