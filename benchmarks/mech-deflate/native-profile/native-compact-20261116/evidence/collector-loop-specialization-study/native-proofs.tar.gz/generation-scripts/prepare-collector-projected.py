from pathlib import Path
from hashlib import sha256
import importlib.util,json,os,subprocess,shutil
N=Path(__file__).resolve().parent
O=N/'collector-loop-specialization'
P=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/benchmarks/mech-deflate/native-profile/native-compact-20261116')
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
c=read(N/'huffman-sort-replay/config.json')
spec=importlib.util.spec_from_file_location('collector_build',P/'evidence/huffman-sort-replay-study/build.py');bm=importlib.util.module_from_spec(spec);spec.loader.exec_module(bm)
env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}
for name,inline in [('hybrid32','6477,6271'),('original','5837,5631')]:
    source=O/(name+'-project-first.mec');out=O/(name+'-projected-homes');out.mkdir()
    inline_a,inline_b=inline.split(',')
    flags=c['flags']|{'MECH_FOLD_NARROW_PACKED_WORDS':'phis','MECH_COMPACT_REFUSE_GENERAL_VECTORS':'475,3779,362','MECH_COMPACT_FORWARD_PHASE_SPILLS':'mech_compact_numeric_475_vector','MECH_COMPACT_SHORT_EQUALITY_PHASE':'mech_compact_numeric_475_vector','MECH_COMPACT_IMMUTABLE_DEFAULTED_READS':'mech_compact_numeric_475_vector','MECH_QUALIFY_PHASE_INPUT_PACKET':'only:mech_compact_numeric_3967,mech_compact_numeric_3967_vector,mech_compact_numeric_3967_no_growth','MECH_COMPACT_INLINE_SYMBOLS':f'mech_compact_numeric_{inline_a},mech_compact_numeric_{inline_b}_vector'}
    cmd=[c['compiler'],str(source),str(out/'census/frontend'),'compact']
    with (out/'census.log').open('w') as log:subprocess.run(cmd,env=env|flags|{'MECH_COMPACT_DIRECT_SCALAR_HOME_CENSUS':str(out/'homes.json')},stdout=log,stderr=log,check=True)
    homes=[v['slot'] for v in read(out/'homes.json') if v['admitted']]
    flags|={'MECH_COMPACT_DIRECT_SCALAR_HOMES':','.join(map(str,homes))}
    cmd=[c['compiler'],str(source),str(out/'frontend'),'compact']
    with (out/'compile.log').open('w') as log:subprocess.run(cmd,env=env|flags,stdout=log,stderr=log,check=True)
    artifacts={f:sha(out/'frontend'/f) for f in ['program.o','metadata.json','program.mecb']}
    r={'source_base':'89dd67efb617e44e72aaa0710101e566661e8600','compiler_sha256':sha(c['compiler']),'source_sha256':sha(source),'command':cmd,'compile':cmd,'flags':flags,'artifacts':artifacts,'object_sha256':artifacts['program.o'],'metadata_sha256':artifacts['metadata.json'],'bytecode_sha256':artifacts['program.mecb'],'text_bytes':bm.text_size(out/'frontend/program.o')}
    (out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
    bound=out/'bound';bound.mkdir();shutil.copyfile(out/'frontend/program.o',bound/'program.o');shutil.copyfile(out/'frontend/metadata.json',bound/'metadata.json')
    link=list(c['selected_link']);link[link.index('-o')+1]=str(bound/'mech-worker');index=link.index('link-arg='+c['selected_object']);link[index]='link-arg='+str(bound/'program.o')
    with (out/'link.log').open('w') as log:subprocess.run(link,stdout=log,stderr=log,check=True)
    runtime={'bytecode_sha256':artifacts['program.mecb'],'metadata_sha256':artifacts['metadata.json'],'worker_sha256':sha(bound/'mech-worker'),'link':link,'object_sha256':artifacts['program.o'],'linked_encoder':{'argument_index':index,'path':str(bound/'program.o'),'sha256':artifacts['program.o']},'encoder_text_bytes':r['text_bytes']};(bound/'runtime.json').write_text(json.dumps(runtime,indent=2)+'\n')
    m=read(out/'frontend/metadata.json')
    print(name,'text',r['text_bytes'],'root stack',m['stack_bytes'],'homes',len(homes),'phases',[(p['header'],p['input_words'],p['output_words'],p['code_bytes']) for p in m['numeric_phases']],flush=True)
