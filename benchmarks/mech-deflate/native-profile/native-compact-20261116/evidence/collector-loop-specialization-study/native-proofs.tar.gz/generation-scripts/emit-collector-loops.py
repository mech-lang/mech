from pathlib import Path
from hashlib import sha256
import importlib.util, json, os, subprocess

N = Path(__file__).resolve().parent
P = Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/benchmarks/mech-deflate/native-profile/native-compact-20261116')
O = N/'collector-loop-specialization'
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: sha256(Path(p).read_bytes()).hexdigest()
config = read(N/'huffman-sort-replay/config.json')
spec = importlib.util.spec_from_file_location('huff_build', P/'evidence/huffman-sort-replay-study/build.py')
build = importlib.util.module_from_spec(spec); spec.loader.exec_module(build)
flags = config['flags'] | {'MECH_FOLD_NARROW_PACKED_WORDS':'phis'}
assert not set(config['omitted_graph_coordinate_hints']) & set(flags)
environment = {k:v for k,v in os.environ.items() if not k.startswith('MECH_')}
for name in ['hybrid32', 'original']:
    source = O/(name+'-loops.mec')
    out = O/(name+'-generic'); out.mkdir()
    command = [config['compiler'], str(source), str(out/'frontend'), 'compact']
    with (out/'compile.log').open('w') as log:
        subprocess.run(command, env=environment|flags|{'MECH_COMPACT_DIRECT_SCALAR_HOME_CENSUS':str(out/'homes.json')}, stdout=log, stderr=log, check=True)
    metadata = read(out/'frontend/metadata.json')
    artifacts = {f:sha(out/'frontend'/f) for f in ['program.o','metadata.json','program.mecb']}
    receipt = {'source_base':'89dd67efb617e44e72aaa0710101e566661e8600','compiler_sha256':sha(config['compiler']), 'command':command,'compile':command,'flags':flags,'source_sha256':sha(source),'artifacts':artifacts,'text_bytes':build.text_size(out/'frontend/program.o')}
    receipt.update(object_sha256=artifacts['program.o'],metadata_sha256=artifacts['metadata.json'],bytecode_sha256=artifacts['program.mecb'])
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(name, 'text', receipt['text_bytes'], 'stack', metadata['stack_bytes'], 'actions', len(metadata['origins']), 'homes',sum(v['admitted'] for v in read(out/'homes.json')), flush=True)
    for p in metadata['numeric_phases']:
        variants={k:{q:v.get(q) for q in ['symbol','code_bytes','stack_bytes','selected_by_guard']} for k,v in p.items() if isinstance(v,dict) and 'symbol' in v}
        print(p['header'],p['input_words'],p['output_words'],p['code_bytes'],variants,flush=True)
