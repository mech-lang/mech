#![allow(dead_code)]

mod native_artifact {
    #[derive(Debug)]
    pub struct NativeCompileError;

    mod compiler {
        use super::NativeCompileError;

        pub(crate) fn offset(slot: usize) -> Result<i32, NativeCompileError> {
            slot.checked_mul(8).and_then(|n| i32::try_from(n).ok()).ok_or(NativeCompileError)
        }
    }

    mod codegen {
        mod control {
            pub mod plan {
                use super::super::super::NativeCompileError;

                pub struct CodePlan<'a>(pub &'a [u64]);
                pub struct Slot(u32);
                impl Slot {
                    pub fn get(&self) -> u32 {
                        self.0
                    }
                }
                impl CodePlan<'_> {
                    pub fn constant_count(&self) -> usize {
                        self.0.len()
                    }
                    pub fn constant(&self, index: usize) -> Result<(Slot, Option<u64>), NativeCompileError> {
                        Ok((Slot(index as u32), Some(self.0[index])))
                    }
                }
            }
        }
        #[path = "/private/tmp/mech-shared-cold-epilogues.2L6obP/.qualification/current-roadmap/immutable-root-literals/source/hosts/gpu/src/native_artifact/codegen/common/ssa_words.rs"]
        mod ssa_words;
    }
}
