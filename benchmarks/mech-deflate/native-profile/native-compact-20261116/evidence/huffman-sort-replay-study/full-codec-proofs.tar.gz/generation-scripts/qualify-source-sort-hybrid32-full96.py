"""Full81-case point qualification for the separately pinned ordinary-source arm."""
from pathlib import Path
from hashlib import sha256
import json,os,sys
N=Path(__file__).resolve().parent;Q=N.parent.parent;P=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/benchmarks/mech-deflate/native-profile/native-compact-20261116');read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();timer=Q/'compare-library.py';before=N/'narrow-packet-eight-probe-profiled/bound';after=N/'source-sort-hybrid32-profiled/bound';policy=read(P/'working-selection-policy.json')
plan={'orders':['forward','reverse'],'named_cases':81,'blocks_per_case':96,'timer_sha256':sha(timer),'controller_sha256':sha(Path(__file__)),'selected_control_worker':sha(before/'mech-worker'),'candidate_worker':sha(after/'mech-worker'),'policy_sha256':sha(P/'working-selection-policy.json'),'required_peer_wins':policy['required_peer_wins'],'peer_win_floors':policy['peer_win_floors'],'scope':'Both full81case96block orders; point score and everypreviousnamed81Roc/63Cwin. Confidence separately, not an extra selectiongate. Different source candidate uses its separatelyverified sixfailureaction mapping; defaultsource unchanged.','load_before':os.getloadavg()}
(N/'huffman-sort-replay/hybrid32-full96-plan.json').write_text(json.dumps(plan,indent=2)+'\n');program=timer.read_text();needle='orders = list(permutations(commands))';assert program.count(needle)==1;program=program.replace(needle,needle+' * 4');runs=[]
for order in plan['orders']:
 label='source-sort-hybrid32-full96-'+order;sys.argv=[str(timer),label,str(before),str(after)]+(['reverse'] if order=='reverse' else [])
 exec(compile(program,str(timer),'exec'),{'__file__':str(timer),'__name__':'__main__'})
 rows=read(Q/label/'summary.json');assert len(rows)==81;peers={}
 for peer in ['roc','libdeflate']:
  key='paired_x_'+peer;wins={r['case'] for r in rows if r[key]['mech-experiment']<1};missing=sorted(set(policy['required_peer_wins'][peer])-wins);peers[peer]={'wins':len(wins),'required_missing':missing,'passed':not missing and len(wins)>=policy['peer_win_floors'][peer]}
 runs.append({'order':order,'run':str(Q/label),'summary_sha256':sha(Q/label/'summary.json'),'peers':peers,'results':rows});result={'plan':plan,'runs':runs,'complete':len(runs)==2,'point_passed':len(runs)==2 and all(p['passed'] for r in runs for p in r['peers'].values()),'selected_default_changed':False,'confidence_assessed':False};(N/'huffman-sort-replay/hybrid32-full96-results.json').write_text(json.dumps(result,indent=2)+'\n');print('FULL96',order,peers,flush=True)
