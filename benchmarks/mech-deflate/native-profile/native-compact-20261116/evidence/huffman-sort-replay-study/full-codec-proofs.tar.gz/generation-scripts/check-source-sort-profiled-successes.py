from pathlib import Path
from hashlib import sha256
import json,subprocess,select,os
N=Path(__file__).resolve().parent;Q=N.parent.parent;read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();fixtures=read(Q/'fixtures.json')
for role in ['source-sort-shell-profiled','source-sort-bucket-profiled']:
 out=N/role;bound=out/'bound';p=subprocess.Popen([str(bound/'mech-worker'),str(bound/'metadata.json'),str(Q/'fixtures.json')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=(out/'native-check.stderr').open('wb'));buffer=b''
 def line():
  global buffer
  while b'\n' not in buffer:
   assert select.select([p.stdout],[],[],30)[0];part=os.read(p.stdout.fileno(),65536);assert part,(role,p.poll());buffer+=part
  value,buffer=buffer.split(b'\n',1);return value.decode()
 def send(s):p.stdin.write(s.encode());p.stdin.flush()
 assert line()=='SESSION_READY';records=[]
 for i,case in enumerate(fixtures):
  send(f"C\t{i}\t0\n");assert line()=='CASE_READY\t'+case['name'];send('NN')
  for _ in range(2):
   v=json.loads(line());assert v['case']==case['name'];assert all(v[k] for k in ['exact_reference','independent_inflation','input_alias_unchanged','borrowed_output_alias_unchanged']);assert v['nonreturned_private_bytes_at_return']==0;assert v['capacity']==case['capacity'];records.append(v)
  assert line()=='CASE_DONE\t'+case['name']
 send('Q\n');assert p.wait(timeout=10)==0;result={'role':role,'worker_sha256':sha(bound/'mech-worker'),'checked_calls':len(records),'all162pass':len(records)==162,'records':records};(out/'native-check.json').write_text(json.dumps(result,indent=2)+'\n');print(role,'all162outputs/aliases/inflation/cleanup pass',flush=True)
