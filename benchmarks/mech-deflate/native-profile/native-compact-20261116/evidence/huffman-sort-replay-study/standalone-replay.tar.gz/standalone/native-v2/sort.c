/*
 * deflate_compress.c - a compressor for DEFLATE
 *
 * Copyright 2016 Eric Biggers
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */


#include <assert.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
typedef uint32_t u32;
typedef uint8_t u8;
#define DEFLATE_MAX_NUM_SYMS 288
#define MIN(a,b) ((a) < (b) ? (a) : (b))
#ifndef SORT_COUNTERS
#define SORT_COUNTERS 0
#endif
struct sort_work {
    uint64_t frequency_reads, counter_updates, key_comparisons, output_writes;
};
static struct sort_work work;
#define COUNT(field) do { if (SORT_COUNTERS) ++work.field; } while (0)
#define COMPARE(expression) (SORT_COUNTERS ? (++work.key_comparisons, (expression)) : (expression))
void replay_reset_work(void) { memset(&work, 0, sizeof(work)); }
void replay_read_work(struct sort_work *out) { *out = work; }
extern void *mi_zalloc(size_t);
extern void mi_free(void *);
static void
heapify_subtree(u32 A[], unsigned length, unsigned subtree_idx)
{
	unsigned parent_idx;
	unsigned child_idx;
	u32 v;

	v = A[subtree_idx];
	parent_idx = subtree_idx;
	while ((child_idx = parent_idx * 2) <= length) {
		if (child_idx < length && COMPARE(A[child_idx + 1] > A[child_idx]))
			child_idx++;
		if (COMPARE(v >= A[child_idx]))
			break;
		COUNT(output_writes);
		A[parent_idx] = A[child_idx];
		parent_idx = child_idx;
	}
	COUNT(output_writes);
	A[parent_idx] = v;
}

/*
 * Rearrange the array 'A' so that it satisfies the maxheap property.
 * 'A' uses 1-based indices, so the children of A[i] are A[i*2] and A[i*2 + 1].
 */
static void
heapify_array(u32 A[], unsigned length)
{
	unsigned subtree_idx;

	for (subtree_idx = length / 2; subtree_idx >= 1; subtree_idx--)
		heapify_subtree(A, length, subtree_idx);
}

/*
 * Sort the array 'A', which contains 'length' unsigned 32-bit integers.
 *
 * Note: name this function heap_sort() instead of heapsort() to avoid colliding
 * with heapsort() from stdlib.h on BSD-derived systems.
 */
static void
heap_sort(u32 A[], unsigned length)
{
	A--; /* Use 1-based indices  */

	heapify_array(A, length);

	while (length >= 2) {
		u32 tmp = A[length];

		COUNT(output_writes);
		A[length] = A[1];
		COUNT(output_writes);
		A[1] = tmp;
		length--;
		heapify_subtree(A, length, 1);
	}
}

#define NUM_SYMBOL_BITS 10
#define NUM_FREQ_BITS	(32 - NUM_SYMBOL_BITS)
#define SYMBOL_MASK	((1 << NUM_SYMBOL_BITS) - 1)
#define FREQ_MASK	(~SYMBOL_MASK)

#define GET_NUM_COUNTERS(num_syms)	(num_syms)

/*
 * Sort the symbols primarily by frequency and secondarily by symbol value.
 * Discard symbols with zero frequency and fill in an array with the remaining
 * symbols, along with their frequencies.  The low NUM_SYMBOL_BITS bits of each
 * array entry will contain the symbol value, and the remaining bits will
 * contain the frequency.
 *
 * @num_syms
 *	Number of symbols in the alphabet, at most 1 << NUM_SYMBOL_BITS.
 *
 * @freqs[num_syms]
 *	Frequency of each symbol, summing to at most (1 << NUM_FREQ_BITS) - 1.
 *
 * @lens[num_syms]
 *	An array that eventually will hold the length of each codeword.  This
 *	function only fills in the codeword lengths for symbols that have zero
 *	frequency, which are not well defined per se but will be set to 0.
 *
 * @symout[num_syms]
 *	The output array, described above.
 *
 * Returns the number of entries in 'symout' that were filled.  This is the
 * number of symbols that have nonzero frequency.
 */
static unsigned
sort_symbols(unsigned num_syms, const u32 freqs[], u8 lens[], u32 symout[])
{
	unsigned sym;
	unsigned i;
	unsigned num_used_syms;
	unsigned num_counters;
	unsigned counters[GET_NUM_COUNTERS(DEFLATE_MAX_NUM_SYMS)];

	/*
	 * We use heapsort, but with an added optimization.  Since often most
	 * symbol frequencies are low, we first do a count sort using a limited
	 * number of counters.  High frequencies are counted in the last
	 * counter, and only they will be sorted with heapsort.
	 *
	 * Note: with more symbols, it is generally beneficial to have more
	 * counters.  About 1 counter per symbol seems fastest.
	 */

	num_counters = GET_NUM_COUNTERS(num_syms);

	memset(counters, 0, num_counters * sizeof(counters[0]));

	/* Count the frequencies. */
	for (sym = 0; sym < num_syms; sym++) {
		COUNT(frequency_reads);
		COUNT(counter_updates);
		counters[MIN(freqs[sym], num_counters - 1)]++;
	}

	/*
	 * Make the counters cumulative, ignoring the zero-th, which counted
	 * symbols with zero frequency.  As a side effect, this calculates the
	 * number of symbols with nonzero frequency.
	 */
	num_used_syms = 0;
	for (i = 1; i < num_counters; i++) {
		unsigned count = counters[i];

		COUNT(counter_updates);
		counters[i] = num_used_syms;
		num_used_syms += count;
	}

	/*
	 * Sort nonzero-frequency symbols using the counters.  At the same time,
	 * set the codeword lengths of zero-frequency symbols to 0.
	 */
	for (sym = 0; sym < num_syms; sym++) {
		COUNT(frequency_reads);
		u32 freq = freqs[sym];

		if (freq != 0) {
			COUNT(counter_updates);
			COUNT(output_writes);
			symout[counters[MIN(freq, num_counters - 1)]++] =
				sym | (freq << NUM_SYMBOL_BITS);
		} else {
			lens[sym] = 0;
		}
	}

	/* Sort the symbols counted in the last counter. */
	heap_sort(symout + counters[num_counters - 2],
		  counters[num_counters - 1] - counters[num_counters - 2]);

	return num_used_syms;
}


static unsigned mech_shell(unsigned n, const u32 *freqs, u32 *words) {
    unsigned used = 0;
    for (unsigned sym = 0; sym < n; ++sym) {
        COUNT(frequency_reads);
        u32 frequency = freqs[sym];
        if (frequency) {
            COUNT(output_writes);
            words[used++] = sym | (frequency << 10);
        }
    }
    uint64_t gaps = UINT64_C(4362938489);
    while (gaps & 255) {
        unsigned gap = gaps & 255;
        for (unsigned at = gap; at < used; ++at) {
            u32 key = words[at];
            unsigned position = at;
            for (;;) {
                unsigned previous = position >= gap ? position - gap : position;
                u32 prior = position >= gap ? words[previous] : key;
                int moving = COMPARE(prior > key);
                COUNT(output_writes);
                words[position] = moving ? prior : key;
                if (!moving) break;
                position = previous;
            }
        }
        gaps >>= 8;
    }
    return used;
}

unsigned replay_c_native(unsigned n, const u32 *freqs, u32 *out) {
    assert(n >= 2 && n <= 288);
    u32 *scratch = mi_zalloc(n * sizeof(*scratch));
    assert(scratch);
    u8 lens[288];
    unsigned used = sort_symbols(n, freqs, lens, scratch);
    memcpy(out, scratch, used * sizeof(*out));
    mi_free(scratch);
    return used;
}

unsigned replay_c_mech(unsigned n, const u32 *freqs, u32 *out) {
    assert(n >= 2 && n <= 288);
    u32 *scratch = mi_zalloc(n * sizeof(*scratch));
    assert(scratch);
    unsigned used = mech_shell(n, freqs, scratch);
    memcpy(out, scratch, used * sizeof(*out));
    mi_free(scratch);
    return used;
}
