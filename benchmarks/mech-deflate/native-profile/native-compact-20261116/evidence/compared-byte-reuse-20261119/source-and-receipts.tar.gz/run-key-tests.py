from pathlib import Path
from hashlib import sha256
import json,os,re,subprocess
D=Path(__file__).resolve().parent;F=D/'cost-key-tests';binary=D.parent/'target/release/deps/mech_gpu-b3b0f09228423e85';W=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP');source=W/'hosts/gpu/src/native_artifact/program/codegen/ordered_reduction/emit.rs';pin=json.loads((F/'build.json').read_text())['source_sha256'];assert sha256(source.read_bytes()).hexdigest()==pin
latch={'MECH_ORDERED_VECTOR_LATCH_TEST':'1','MECH_SINGLETON_ORDERED_REDUCTION':'1','MECH_REVERSE_REDUCTION_CURSOR':'1','MECH_NARROW_ORDERED_ITEM':'1','MECH_ORDERED_HORIZONTAL_MINIMUM':'1','MECH_ORDERED_REVERSE_LOW_WORDS':'1','MECH_ORDERED_VECTOR_HOIST_COST_WORDS':'1'}
latch|={'MECH_DIRECT_ITEM_NO_GROWTH':'1','MECH_REDUCTION_COUNTDOWN':'1'}
configs={
 'key-single':latch|{'MECH_ORDERED_SCALAR_COST_KEY':'single'},
 'key-pair':latch|{'MECH_ORDERED_SCALAR_COST_KEY':'pair'},
 'key-pair-vector12-body':latch|{'MECH_ORDERED_SCALAR_COST_KEY':'pair','MECH_ORDERED_VECTOR_MINIMUM':'12','MECH_ORDERED_VECTOR_CARRY_POINTERS':'body','MECH_ORDERED_VECTOR_CARRY_LANES':'1'},
 'key-pair-vector4-body':latch|{'MECH_ORDERED_SCALAR_COST_KEY':'pair','MECH_ORDERED_VECTOR_MINIMUM':'4','MECH_ORDERED_VECTOR_CARRY_POINTERS':'body'},
 'vector8-body':latch|{'MECH_ORDERED_VECTOR_MINIMUM':'8','MECH_ORDERED_VECTOR_CARRY_POINTERS':'body','MECH_ORDERED_VECTOR_CARRY_LANES':'1'},
 'winner-branch':latch|{'MECH_ORDERED_SCALAR_WINNER_BRANCH':'1'},
 'winner-branch-cold':latch|{'MECH_ORDERED_SCALAR_WINNER_BRANCH':'cold'},
};rows=[]
for role,flags in configs.items():
 cmd=[str(binary),'ordered_reduction','--test-threads=1'];r=subprocess.run(cmd,cwd=W,env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}|flags,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(F/(role+'.log')).write_text(r.stdout);assert r.returncode==0,r.stdout;match=re.search(r'test result: ok\. (\d+) passed; (\d+) failed',r.stdout);assert match and int(match[1])==16 and int(match[2])==0;r={'role':role,'flags':flags,'command':cmd,'tests_passed':int(match[1]),'binary_sha256':sha256(binary.read_bytes()).hexdigest(),'source_sha256':pin};rows.append(r);print(role,r['tests_passed'],'passed',flush=True)
(F/'result.json').write_text(json.dumps(rows,indent=2)+'\n')
