from pathlib import Path
from hashlib import sha256
import json,os,subprocess,time
D=Path(__file__).resolve().parent;I=D.parent;W=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP')
plan=json.loads((I/'natural4k-runtime-target/vector-pointers/test-build-plan.json').read_text());folder=D/'dp-production-tests';folder.mkdir();source=W/'hosts/gpu/src/native_artifact/program/codegen/append_previous.rs';pin=sha256(source.read_bytes()).hexdigest();start=time.perf_counter()
with (folder/'build.log').open('w') as log:
 child=subprocess.Popen(plan['command'],cwd=W,env=dict(os.environ)|plan['environment'],stdout=log,stderr=log,start_new_session=True)
 (folder/'process.json').write_text(json.dumps({'pid':child.pid,'pgid':os.getpgid(child.pid),'command':plan['command'],'environment':plan['environment'],'source_sha256':pin},indent=2)+'\n')
 code=child.wait()
assert sha256(source.read_bytes()).hexdigest()==pin
(folder/'build.json').write_text(json.dumps({'exit_code':code,'elapsed_seconds_untimed':time.perf_counter()-start,'source_sha256':pin,'build_log_sha256':sha256((folder/'build.log').read_bytes()).hexdigest()},indent=2)+'\n');print('Test build finished',code,flush=True)
raise SystemExit(code)
