from pathlib import Path
from hashlib import sha256
import json,os,subprocess,time
D=Path(__file__).resolve().parent;I=D.parent;W=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP')
plan=json.loads((I/'natural4k-runtime-target/vector-pointers/test-build-plan.json').read_text());folder=D/'cost-key-tests';folder.mkdir();source=W/'hosts/gpu/src/native_artifact/program/codegen/ordered_reduction/emit.rs';pin=sha256(source.read_bytes()).hexdigest();pins={str(p.relative_to(W)):sha256(p.read_bytes()).hexdigest() for p in [source,source.with_name('scalar_key.rs'),source.with_name('mod.rs'),source.with_name('tests.rs')]};start=time.perf_counter()
with (folder/'build.log').open('w') as log:
 child=subprocess.Popen(plan['command'],cwd=W,env=dict(os.environ)|plan['environment'],stdout=log,stderr=log,start_new_session=True)
 (folder/'process.json').write_text(json.dumps({'pid':child.pid,'pgid':os.getpgid(child.pid),'command':plan['command'],'environment':plan['environment'],'source_sha256':pin,'source_inputs':pins},indent=2)+'\n')
 code=child.wait()
assert {p:sha256((W/p).read_bytes()).hexdigest() for p in pins}==pins
(folder/'build.json').write_text(json.dumps({'exit_code':code,'elapsed_seconds_untimed':time.perf_counter()-start,'source_sha256':pin,'source_inputs':pins,'build_log_sha256':sha256((folder/'build.log').read_bytes()).hexdigest()},indent=2)+'\n');print('Test build finished',code,flush=True)
raise SystemExit(code)
