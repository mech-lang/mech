from pathlib import Path
from hashlib import sha256
import subprocess,json
N=Path(__file__).resolve().parent;I=N.parent;D=I/'target/release/deps';W=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP');P=W/'hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/composed_reads.rs';O=N/'compressed-index-jit';O.mkdir();source=P.read_text();a=source.index('#[derive(Clone, PartialEq, Eq, PartialOrd, Ord)]');b=source.index('\nstruct DenseCodes',a);definitions=source[a:b];a=source.index('        let index = if let Some(index) = dense.key.compressed');b=source.index('        let cell = c.ins().iadd(codes, index);',a);emission=source[a:b].replace('dense.key.compressed','recipe');code='''use std::sync::Arc;
use cranelift_codegen::{cursor::{Cursor,FuncCursor},ir::{AbiParam,InstBuilder,Value,condcodes::IntCC,types}};
use cranelift_jit::{JITBuilder,JITModule};
use cranelift_module::{Linkage,Module,default_libcall_names};
'''+definitions+'''
fn emit_index(c: &mut FuncCursor<'_>, word: Value, recipe: Option<CompressedIndex>) -> Value {
'''+emission+'''index
}
#[test]
fn native_index_matches_every_admitted_word() {
 for length in [1usize,2,16,128,256] {
  for shift in [1u64,3,7,10] {
   let bytes:Arc<[u8]>=(0..length).map(|i|(i%31) as u8).collect();
   let mut key=CodeKey {bytes,input_length:65536,high_shift:shift,bias:32,compressed:None};
   let dense=key.encode();key.compress();let table=key.encode();
   let mut module=JITModule::new(JITBuilder::with_flags(&[("opt_level","speed"),("enable_verifier","true")],default_libcall_names()).unwrap());
   let mut context=module.make_context();context.func.signature.params=vec![AbiParam::new(types::I64)];context.func.signature.returns=vec![AbiParam::new(types::I64)];
   let entry=context.func.dfg.make_block();context.func.layout.append_block(entry);let word=context.func.dfg.append_block_param(entry,types::I64);
   let mut c=FuncCursor::new(&mut context.func).at_bottom(entry);let index=emit_index(&mut c,word,key.compressed);c.ins().return_(&[index]);
   let id=module.declare_function("compact_index",Linkage::Local,&context.func.signature).unwrap();module.define_function(id,&mut context).unwrap();module.finalize_definitions().unwrap();
   type Call=unsafe extern "C" fn(u64)->u64;
   // SAFETY: The finalized live module owns this exact C signature.
   let call:Call=unsafe {std::mem::transmute(module.get_finalized_function(id))};
   for word in 0..65536u64 {let index=unsafe{call(word)} as usize;let expected=key.compressed.map_or(word as usize,|r|r.index(word));assert_eq!(index,expected);assert_eq!(table[index],dense[word as usize]);}
  }
 }
}
''';(O/'tests.rs').write_text(code);libs={'cranelift_codegen':'b6d1bfe0a604f895','cranelift_jit':'f2d24416a39f2055','cranelift_module':'853726e31c32ab7d'};cmd=['rustc','+nightly-2026-03-03','--test','--edition=2024','-O','-L','dependency='+str(D),str(O/'tests.rs'),'-o',str(O/'tests')]
for crate,h in libs.items():cmd+=['--extern',crate+'='+str(D/('lib'+crate+'-'+h+'.rlib'))]
r=subprocess.run(cmd,text=True,capture_output=True);(O/'build.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr;r=subprocess.run([str(O/'tests'),'--test-threads=1'],text=True,capture_output=True);(O/'tests.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr;(O/'result.json').write_text(json.dumps({'source_sha256':sha256(P.read_bytes()).hexdigest(),'extracted_native_expression_sha256':sha256(emission.encode()).hexdigest(),'test_source_sha256':sha256(code.encode()).hexdigest(),'command':cmd,'tests':1,'geometries':20,'words_per_geometry':65536,'scope':'Exact source-derived native index expression under verified optimized JIT, all 65536 admitted words per geometry. Source receiver adapted to a parameter; no rewrite/admission stub is supplied.'},indent=2)+'\n');print(r.stdout,flush=True)
