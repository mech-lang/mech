from pathlib import Path
from hashlib import sha256
from runpy import run_path
import json,os,subprocess,sys,time
D=Path(__file__).resolve().parent;I=D.parent;Q=I.parent;W=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP');read=lambda p:json.loads(p.read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();build=read(D/'scalar-branch-retry/build.json');compiler=str(Path(build['compiler']).resolve());assert sha(compiler)==build['compiler_sha256'];flags=read(I/'controller-source-boundaries/scoped-registers/selected-map/result.json')['flags'];flags.pop('MECH_COMPACT_SOURCE_BLOCK_REPORT',None);source=W/'benchmarks/mech-deflate/native-profile/native-compact-20261116/program.mec';tool=run_path(str(Q/'current-roadmap/scorer-runtime/emit.py'),run_name='source_scorer_layout');profiles=flags['MECH_COMPACT_PHASE_BLOCK_LAYOUT'];without=';'.join(x for x in profiles.split(';') if not x.startswith('mech_compact_numeric_3009_no_growth_composed@'))

variants={
 'loop-exact-control':None,
 'branch-hot-default':{'MECH_ORDERED_SCALAR_WINNER_BRANCH':'1'},
 'branch-cold-default':{'MECH_ORDERED_SCALAR_WINNER_BRANCH':'cold'},
 'branch-body-default':{'MECH_ORDERED_SCALAR_WINNER_BRANCH':'1','MECH_ORDERED_VECTOR_CARRY_POINTERS':'body'},
 'branch-cold-body-default':{'MECH_ORDERED_SCALAR_WINNER_BRANCH':'cold','MECH_ORDERED_VECTOR_CARRY_POINTERS':'body'},
 'vector4-default':{'MECH_ORDERED_VECTOR_MINIMUM':'4'},
 'vector8-default':{'MECH_ORDERED_VECTOR_MINIMUM':'8'},
 'vector12-default':{'MECH_ORDERED_VECTOR_MINIMUM':'12'},
 'vector8-body-default':{'MECH_ORDERED_VECTOR_MINIMUM':'8','MECH_ORDERED_VECTOR_CARRY_POINTERS':'body'},
 'vector12-body-default':{'MECH_ORDERED_VECTOR_MINIMUM':'12','MECH_ORDERED_VECTOR_CARRY_POINTERS':'body'},
 'branch-vector8-body-default':{'MECH_ORDERED_SCALAR_WINNER_BRANCH':'1','MECH_ORDERED_VECTOR_MINIMUM':'8','MECH_ORDERED_VECTOR_CARRY_POINTERS':'body'},
 'branch-vector12-body-default':{'MECH_ORDERED_SCALAR_WINNER_BRANCH':'1','MECH_ORDERED_VECTOR_MINIMUM':'12','MECH_ORDERED_VECTOR_CARRY_POINTERS':'body'},
}
for label,extra in variants.items():
 folder=D/label;folder.mkdir(exist_ok=False);command=[compiler,str(source),str(folder/'frontend'),'compact'];native=flags.copy() if extra is None else flags|{'MECH_COMPACT_PHASE_BLOCK_LAYOUT':without}|extra
 with (folder/'compile.log').open('w') as log:r=subprocess.run(command,env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}|native,stdout=log,stderr=log)
 assert r.returncode==0,(folder/'compile.log').read_text()[-3000:];front=folder/'frontend';artifacts={n:sha(front/n) for n in ['program.o','metadata.json','program.mecb']};assert artifacts['program.mecb']=='c6529d934f020f07f8e59f13fab40927e066649e202269818ad3f009a942a8c3';layout=tool['symbols'](front/'program.o')
 receipt={'source_base':'c36477ebda733142c3d860abd12799fa12229faa','source_pin':'c36477ebda733142c3d860abd12799fa12229faa plus source-pinned scorer body pointers, scalar winner branch and vector entry minima','compile':command,'command':command,'flags':native,'compiler_sha256':sha(compiler),'artifacts':artifacts,'object_sha256':artifacts['program.o'],'metadata_sha256':artifacts['metadata.json'],'bytecode_sha256':artifacts['program.mecb'],'layout':layout,'text_bytes':layout['text_bytes'],'runtime_qualification':'pending'};(folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(label,layout['text_bytes'],flush=True)

selected=read(D/'loop-exact-control/receipt.json');assert selected['object_sha256']=='cf15343f1f01089d427122ce51a91ef6fa7b70ef89c50ca4db20901a8d2cefd9' and selected['metadata_sha256']=='169d4b5286cba371400aad6a8e760d2cdb43e1839f8c6b325c9ba542820e6b3d'
