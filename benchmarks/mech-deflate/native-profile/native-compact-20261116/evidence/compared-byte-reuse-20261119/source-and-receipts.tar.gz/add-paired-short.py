from pathlib import Path
W=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP');p=W/'hosts/gpu/src/native_artifact/program/codegen/ordered_reduction/emit.rs';s=p.read_text();needle='        let vector = b.create_block();';assert s.count(needle)==1;s=s.replace(needle,'''        // Keep the one-visit path direct. Only a nonempty continuation may
        // enter the paired body, and only when the selected item is pure and
        // the existing affine proof has admitted every original visit.
        let pair = biased.filter(|_| {
            cfg!(target_arch = "aarch64")
                && deferred.is_none()
                && std::env::var_os("MECH_ORDERED_PAIRED_CONTINUATION").is_some()
        });
        let scalar_entry = if pair.is_some() {
            let entry = b.create_block();
            for ty in [types::I64, types::I32, types::I64, types::I64, types::I64] {
                b.append_block_param(entry, ty);
            }
            entry
        } else {
            scalar_body
        };
'''+needle)
# Only the entries into the scalar continuation change; the scalar tail itself is unchanged.
s=s.replace('b.ins().jump(scalar_body, &args);','b.ins().jump(scalar_entry, &args);')
s=s.replace('''                scalar_body,
                &[start.into(), best.into(), initial.into()],''','''                scalar_entry,
                &[start.into(), best.into(), initial.into()],''')
s=s.replace('''                scalar_body,
                &[end.into(), minimum.into(), carried_value.into()],''','''                scalar_entry,
                &[end.into(), minimum.into(), carried_value.into()],''')
needle='''        // Short entries have completed their first visit. Vector entries''';assert s.count(needle)==1
paired='''        if let Some((front, other)) = pair {
            let back = reverse.expect("paired continuation has a reverse cursor");
            let group = b.create_block();
            let tail = b.create_block();
            for ty in [types::I64, types::I32, types::I64, types::I64, types::I64] {
                b.append_block_param(group, ty);
            }
            b.switch_to_block(scalar_entry);
            let args = b.block_params(scalar_entry).to_vec();
            let has_pair = b
                .ins()
                .icmp_imm(IntCC::UnsignedGreaterThanOrEqual, args[4], 2);
            let args: Vec<_> = args.into_iter().map(Into::into).collect();
            b.ins().brif(has_pair, group, &args, scalar_body, &args);
            b.switch_to_block(group);
            let args = b.block_params(group).to_vec();
            let index = args[0];
            let next = b.ins().iadd_imm(index, 1);
            let stride = i64::from(proof.arrays[back.array].width);
            let back_first = b.ins().iadd_imm(args[3], -stride);
            let back_second = b.ins().iadd_imm(args[3], -2 * stride);
            let front_stride = i64::from(proof.arrays[front.array].width);
            let front_base = words.read(b, shadow + proof.view(front.array));
            let front_offset = b.ins().imul_imm(index, front_stride);
            let front_first = b.ins().iadd(front_base, front_offset);
            let front_second = b.ins().iadd_imm(front_first, front_stride);
            let cost = |b: &mut FunctionBuilder<'_>, index, front_address, back_address| {
                inputs.scalar(
                    b,
                    proof,
                    &self.cost,
                    index,
                    &[
                        (front, ScalarRead::LowWord(front_address)),
                        (back, ScalarRead::LowWord(back_address)),
                    ],
                )
            };
            // Both source visits have the same admitted initialized windows.
            // Strict comparisons preserve the earliest equal-cost candidate
            // and retain an equal incoming best, including its full U64 item.
            let a = cost(b, index, front_first, back_first);
            let d = cost(b, next, front_second, back_second);
            let later = b.ins().icmp(IntCC::UnsignedLessThan, d, a);
            let pair_min = b.ins().select(later, d, a);
            let winner = b.ins().select(later, next, index);
            let better = b.ins().icmp(IntCC::UnsignedLessThan, pair_min, args[1]);
            let minimum = b.ins().select(better, pair_min, args[1]);
            let shifted = emit_item_low32(b, words, proof, shadow, other, index, ordinary);
            let winner = b.ins().ireduce(types::I32, winner);
            let selected = b.ins().bor(winner, shifted);
            let selected = b.ins().uextend(types::I64, selected);
            let item = b.ins().select(better, selected, args[2]);
            let next = b.ins().iadd_imm(index, 2);
            let left = b.ins().iadd_imm(args[4], -2);
            let more = b.ins().icmp_imm(IntCC::UnsignedGreaterThanOrEqual, left, 2);
            let next_args = [
                next.into(),
                minimum.into(),
                item.into(),
                back_second.into(),
                left.into(),
            ];
            b.ins().brif(more, group, &next_args, tail, &[]);
            b.switch_to_block(tail);
            let odd = b.ins().icmp_imm(IntCC::NotEqual, left, 0);
            b.ins().brif(
                odd,
                scalar_body,
                &next_args,
                scalar_finish,
                &[minimum.into(), item.into()],
            );
        }
'''
s=s.replace(needle,paired+needle);p.write_text(s)
