from pathlib import Path
from hashlib import sha256
import json, subprocess, time
N=Path(__file__).resolve().parent;Q=N.parent.parent;I=N.parent;O=N/'instruction-profile';O.mkdir();B=I/'collector-read-lifetimes/placement/immutable-profiled/bound';command=[str(B/'mech-worker'),str(B/'metadata.json'),str(Q/'fixtures.json')];name='prefix-natural-4096';fixtures=json.loads((Q/'fixtures.json').read_text());index=next(i for i,r in enumerate(fixtures) if r['name']==name);sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();assert sha(command[0])=='834c7a7e423a69c46483a3dae74d9450949fdf142b5ad2dede894e0da3ca8693'
with (O/'worker.stderr').open('w') as err,(O/'record.log').open('w') as log:
 p=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True)
 try:
  assert p.stdout.readline().strip()=='SESSION_READY';p.stdin.write(f'C\t{index}\t0\n');p.stdin.flush();assert p.stdout.readline().strip()==f'CASE_READY\t{name}';p.stdin.write('W'*100+'NN');p.stdin.flush();time.sleep(.4)
  trace=['xctrace','record','--template','Time Profiler','--attach',str(p.pid),'--time-limit','5s','--no-prompt','--output',str(O/'runtime.trace')]
  result=subprocess.run(trace,stdout=log,stderr=log,timeout=35);rows=[];lines=[]
  while True:
   line=p.stdout.readline();assert line,('worker ended',p.poll());lines.append(line)
   if line.startswith('{'):rows.append(json.loads(line))
   if line.strip()==f'CASE_DONE\t{name}':break
  assert len(rows)==2 and all(all(row[k] for k in ['exact_reference','independent_inflation','input_alias_unchanged','borrowed_output_alias_unchanged']) for row in rows);p.stdin.write('Q\n');p.stdin.flush();assert p.wait(timeout=10)==0;(O/'protocol.log').write_text(''.join(lines));(O/'result.json').write_text(json.dumps({'command':command,'worker_sha256':sha(command[0]),'trace_command':trace,'trace_exit_code':result.returncode,'verified_calls':rows,'scope':'Untimed original exact worker; instruction sample diagnostics only. Worker validation is outside measured runtime qualification.'},indent=2)+'\n');print('Trace exit',result.returncode,flush=True)
 finally:
  if p.poll() is None:p.terminate();p.wait(timeout=10)
