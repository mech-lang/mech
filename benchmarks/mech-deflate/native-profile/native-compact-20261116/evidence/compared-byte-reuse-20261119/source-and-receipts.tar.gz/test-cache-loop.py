from pathlib import Path
from hashlib import sha256
import subprocess,json
N=Path(__file__).resolve().parent;I=N.parent;D=I/'target/release/deps';W=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP');P=W/'hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/composed_reads.rs';C=P.parent/'composed_reads/cache.rs';O=N/'cache-loop-jit';O.mkdir(exist_ok=True);source=P.read_text();a=source.index('        if let Some(cached) = cached {');b=source.index('        } else {\n            let value = c.ins().uload32',a);emission=source[a+len('        if let Some(cached) = cached {'):b].replace('self.slot.branch','lookup').replace('self.cost.join','join')
code=r'''use std::collections::BTreeSet;
use cranelift_codegen::{cursor::{Cursor,FuncCursor},dominator_tree::DominatorTree,flowgraph::ControlFlowGraph,ir::{AbiParam,Block,Function,Inst,InstBuilder,MemFlags,Value,condcodes::IntCC,types}};
use cranelift_frontend::{FunctionBuilder,FunctionBuilderContext};
use cranelift_jit::{JITBuilder,JITModule};
use cranelift_module::{Linkage,Module,default_libcall_names};
mod cache {
'''+C.read_text().replace('//! One immutable indexed value carried around a proved natural loop.','// Exact production plan.')+r'''
}
fn make(caching: bool,bypass:bool)->(JITModule,unsafe extern "C" fn(*const u32,*const u8,u64)->u64) {
 let mut module=JITModule::new(JITBuilder::with_flags(&[("opt_level","speed"),("enable_verifier","true")],default_libcall_names()).unwrap());
 let mut context=module.make_context();context.func.signature.params=vec![AbiParam::new(types::I64);3];context.func.signature.returns=vec![AbiParam::new(types::I64)];
 let mut fc=FunctionBuilderContext::new();let mut b=FunctionBuilder::new(&mut context.func,&mut fc);
 let entry=b.create_block();let header=b.create_block();let probe=b.create_block();let readable=b.create_block();let default=b.create_block();let join=b.create_block();let out=b.create_block();let skipped=b.create_block();
 b.append_block_params_for_function_params(entry);b.append_block_param(header,types::I64);b.append_block_param(header,types::I64);b.append_block_param(join,types::I64);b.append_block_param(out,types::I64);
 b.switch_to_block(entry);let args=b.block_params(entry).to_vec();let zero=b.ins().iconst(types::I64,0);let nonempty=b.ins().icmp_imm(IntCC::NotEqual,args[2],0);b.ins().brif(nonempty,header,&[zero.into(),zero.into()],out,&[zero.into()]);
 b.switch_to_block(header);let p=b.block_params(header).to_vec();let byte=b.ins().iadd(args[1],p[0]);let code=b.ins().uload8(types::I64,MemFlags::trusted(),byte,0);let byte=b.ins().ishl_imm(code,2);let address=b.ins().iadd(args[0],byte);
 if bypass {let skip=b.ins().icmp_imm(IntCC::Equal,code,254);b.ins().brif(skip,skipped,&[],probe,&[]);} else {b.ins().jump(probe,&[]);}
 b.switch_to_block(skipped);if bypass {let next=b.ins().iadd_imm(p[0],1);let more=b.ins().icmp(IntCC::UnsignedLessThan,next,args[2]);b.ins().brif(more,header,&[next.into(),p[1].into()],out,&[p[1].into()]);} else {b.ins().return_(&[zero]);}
 b.switch_to_block(probe);let valid=b.ins().icmp_imm(IntCC::UnsignedLessThan,code,256);let lookup=b.ins().brif(valid,readable,&[],default,&[]);
 b.switch_to_block(readable);let value=b.ins().uload32(MemFlags::trusted(),address,0);b.ins().jump(join,&[value.into()]);
 b.switch_to_block(default);b.ins().jump(join,&[zero.into()]);
 b.switch_to_block(join);let value=b.block_params(join)[0];let sum=b.ins().iadd(p[1],value);let next=b.ins().iadd_imm(p[0],1);let more=b.ins().icmp(IntCC::UnsignedLessThan,next,args[2]);b.ins().brif(more,header,&[next.into(),sum.into()],out,&[sum.into()]);
 b.switch_to_block(out);let value=b.block_params(out)[0];b.ins().return_(&[value]);b.seal_all_blocks();b.finalize();
 context.compute_cfg();context.compute_domtree();let plan=cache::Plan::derive(&context.func,&context.cfg,&context.domtree,lookup,join);
 if bypass {assert!(plan.is_none());} else {assert!(plan.is_some());}
 if caching && !bypass {
  let cached=plan.unwrap().carry(&mut context.func,&context.cfg,join);let mut c=FuncCursor::new(&mut context.func).at_inst(lookup);let flags=MemFlags::trusted();
'''+emission+r'''
 }
 context.compute_cfg();context.compute_domtree();
 let id=module.declare_function("readonly_cache",Linkage::Local,&context.func.signature).unwrap();module.define_function(id,&mut context).unwrap();module.finalize_definitions().unwrap();
 // SAFETY: The finalized live module owns this exact C signature.
 let call=unsafe{std::mem::transmute(module.get_finalized_function(id))};(module,call)
}
#[test]
fn cached_prices_preserve_unsigned_values_and_reset_between_calls() {
 let (_normal,normal)=make(false,false);let (_cached,cached)=make(true,false);
 let sequences=[vec![],vec![0],vec![255;100],vec![0,1,0,1,255,255,0],(0..=255).collect(),(0..4096).map(|i|((i/7)%256) as u8).collect()];
 for seed in [0u32,1,0x7fff_ffff,0x8000_0000,u32::MAX] {
  let prices=std::array::from_fn::<_,256,_>(|i|seed.wrapping_add((i as u32).wrapping_mul(0x10001)));
  for codes in &sequences {let expected=codes.iter().map(|&c|prices[c as usize] as u64).sum::<u64>();unsafe{assert_eq!(normal(prices.as_ptr(),codes.as_ptr(),codes.len() as u64),expected);assert_eq!(cached(prices.as_ptr(),codes.as_ptr(),codes.len() as u64),expected);}}
 }
}
#[test]
fn a_backedge_that_skips_the_lookup_declines() {let (_module,_call)=make(false,true);}
''';(O/'tests.rs').write_text(code);libs={'cranelift_codegen':'b6d1bfe0a604f895','cranelift_frontend':'cae5d6e3b818ad19','cranelift_jit':'f2d24416a39f2055','cranelift_module':'853726e31c32ab7d'};cmd=['rustc','+nightly-2026-03-03','--test','--edition=2024','-O','-L','dependency='+str(D),str(O/'tests.rs'),'-o',str(O/'tests')]
for crate,h in libs.items():cmd+=['--extern',crate+'='+str(D/('lib'+crate+'-'+h+'.rlib'))]
r=subprocess.run(cmd,text=True,capture_output=True);(O/'build.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr;r=subprocess.run([str(O/'tests'),'--test-threads=1'],text=True,capture_output=True);(O/'tests.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr;(O/'result.json').write_text(json.dumps({'source_sha256':sha256(P.read_bytes()).hexdigest(),'cache_plan_sha256':sha256(C.read_bytes()).hexdigest(),'test_source_sha256':sha256(code.encode()).hexdigest(),'command':cmd,'tests':2,'scope':'Exact production cache plan and native hit/miss emission under verified optimized JIT. Independent readonly fixtures cover empty/repeated/alternating/all-byte keys, full unsigned prices, reset between calls and an unqualified backedge. Parent source admission and codec finite accounting are checked separately.'},indent=2)+'\n');print(r.stdout,flush=True)
