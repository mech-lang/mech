from pathlib import Path
N=Path(__file__).resolve().parent;s=(N/'histogram-short-visits.py').read_text();s=s.replace("N/'short-visit-profile'","N/'cost-transition-profile'");s=s.replace("if pc == start + 652:","if pc == start + 620:").replace("assert assembly[pc] == ('cmp', 'x28, #0x10'), assembly[pc]","assert assembly[pc] == ('add', 'x8, x3, #0x80c'), assembly[pc]")
a=s.index("asm.write_text('''");b=s.index("''');subprocess.run",a)
s=s[:a]+"""asm.write_text('''.text
stp x15,x16,[sp,#-32]!
str x17,[sp,#16]
adrp x16,_mech_matcher_block_counts@GOTPAGE
ldr x16,[x16,_mech_matcher_block_counts@GOTPAGEOFF]
ldr x17,[x16,#32760]
str x7,[x16,#32760]
orr x17,x7,x17,lsl #5
add x16,x16,#8192
add x16,x16,x17,lsl #3
ldr x15,[x16]
add x15,x15,#1
str x15,[x16]
ldr x17,[sp,#16]
ldp x15,x16,[sp],#32
"""+s[b:]
s=s.replace("<8I","<14I");s=s.replace("at + 4, 0x5D000000 | n), (at + 8, 0x6C000000 | n)","at + 8, 0x5D000000 | n), (at + 12, 0x6C000000 | n)")
s=s.replace("exec(compile(text,str(helper),'exec'),h)","text=text.replace('[u64; 1024]', '[u64; 4096]').replace('[0; 1024]', '[0; 4096]');exec(compile(text,str(helper),'exec'),h)")
a=s.index("assert not any(counts[len(leaders):512])");b=s.index("(O/'counter-source.py')",a)
s=s[:a]+"""assert not any(counts[len(leaders):1024]) and not any(counts[2048:4095]);hist={i:n for i,n in enumerate(counts[1024:2048]) if n};total=sum(hist.values());hits=sum(n for i,n in hist.items() if i//32==i%32);results[name]={'transitions':hist,'total':total,'same_class':hits,'same_class_fraction':hits/total,'calls':counts[0]};print(name,{k:v for k,v in results[name].items() if k!='transitions'},flush=True)
(O/'result.json').write_text(json.dumps({'untimed':True,'shipping_worker_sha256':sha256((B/'mech-worker').read_bytes()).hexdigest(),'shipping_object_sha256':sha256((B/'program.o').read_bytes()).hexdigest(),'histogram_instruction_offset':620,'histogram_value':'previous_code*32+current_code; previous initialized to0 per call','cases':results,'scope':'Diagnostic clone only. Counter addition preserves registers, SP and NZCV; no latency inference.'},indent=2)+'\\n');"""+s[b:]
(N/'histogram-cost-cache.py').write_text(s)
