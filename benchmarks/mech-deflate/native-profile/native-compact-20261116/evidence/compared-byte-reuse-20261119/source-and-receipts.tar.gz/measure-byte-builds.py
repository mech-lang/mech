from pathlib import Path
from hashlib import sha256
from runpy import run_path
from statistics import median
import json,sys,subprocess
D=Path(__file__).resolve().parent;I=D.parent;Q=I.parent;W=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP');read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
source_pin=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip();prior=read(I/'collector-read-lifetimes/final-integration/matched-builds/plan.json');fixed=prior['actors']['mech-final-source'];script=Q/'current-roadmap/shared-terminal-returns/measure.py';sys.path.insert(0,str(script.parent));lab=run_path(str(script),run_name='dp_full_build_measurement')
def prepare(controls,variants):
 assert controls==['reference'] and variants==['dp'];actors={}
 for role,case in [('mech-control-reference','byte-edge-control'),('mech-byte-wide','byte-edge-wide-profiled'),('mech-byte-complements','byte-edge-complements-profiled')]:
  r=read(D/case/'receipt.json');encoder=str(D/case/'frontend/program.o');link=[encoder if arg==fixed['reference_object'] else arg for arg in fixed['link']];assert link.count(encoder)==1
  job=fixed|{'compile':r['command'],'compiler_sha256':r['compiler_sha256'],'link':link,'reference_object':encoder,'flags':r['flags'],'artifact_sha256':dict(zip(['encoder','metadata','bytecode'],[r['artifacts'][n] for n in ['program.o','metadata.json','program.mecb']])),'text_bytes':r['text_bytes'],'compiler_source_commit':source_pin,'scope':'Current production compiler; unchanged codec and canonical bytecode; compared-byte experiment is not a new qualified peer win.'};job.pop('linked_proof_sha256',None);actors[role]=job
 actors.update({peer:prior['actors'][peer] for peer in ['roc','libdeflate']})
 for job in actors.values():
  assert sha(job['compile'][0])==job['compiler_sha256'];assert all(sha(path)==h for path,h in job['host_inputs_sha256'].items())
 timer=lab['runtime'].MATCHED.with_name('timing-driver.py');assert sha(timer)==prior['timer_sha256'];return actors,timer
lab['acquire'].__globals__.update(BASE=source_pin,construct=prepare);O=D/'byte-edge-matched-builds';lab['acquire'](O,['reference'],['dp']);raw=read(O/'comparison.json');result={k:raw[k] for k in ['plan_sha256','medians','phases','paired_ratios']};result|={'trials':len(raw['observations']),'source_commit':source_pin,'scope':'Ten serial balanced fresh-process source-through-final-executable-link orders. Compilers and fixed support prebuilt for every actor. Every generated Mech object, complete metadata and bytecode is hash checked. Strip is separate. Bootstrap is excluded equally.'};(O/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
