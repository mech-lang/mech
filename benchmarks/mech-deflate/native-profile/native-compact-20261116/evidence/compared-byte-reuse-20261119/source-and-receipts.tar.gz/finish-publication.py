from pathlib import Path
import json,hashlib
W=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP');P=W/'benchmarks/mech-deflate/native-profile/native-compact-20261116';E=P/'evidence/runtime-next-win-20261119';s=json.loads((E/'study.json').read_text());rows=[]
for campaign in s['campaigns'].values():
 by={}
 for r in campaign['runs']:by.setdefault(r['role'],{})[r['order']]=r['result']
 for role,v in by.items():
  a,b=v['forward'],v['reverse'];rows.append(f"| {role} | {s['cases'][role]['text_bytes']:,} | {a['paired_x_libdeflate']['mech-experiment']:.6f} / {b['paired_x_libdeflate']['mech-experiment']:.6f} | {a['paired_x_roc']['mech-experiment']/a['paired_x_roc']['mech-control']:.6f} / {b['paired_x_roc']['mech-experiment']/b['paired_x_roc']['mech-control']:.6f} |")
(E/'README.md').write_text('''# Runtime work toward the 63rd libdeflate win

The objective is **63/81 libdeflate wins while preserving every existing peer win and 81/81 Roc**. The retained selection remains **63,532 B, 81/81 Roc and 62/81 libdeflate**. None of the experiments below earns a new win. They remain available for repair.

These are single-case diagnostics on `prefix-natural-4096`: **96 balanced paired blocks in each of two orders**, with the exact qualified `834c7a7e…` worker as the same-run control and pinned Roc/libdeflate workers. Ratios below one are faster. They are not complete 81-case qualifications and cannot establish preservation of every previous win. Full selection and compile-time measurements were not repeated for unsuccessful probes.

| Variant | Whole encoder text, B | Mech/libdeflate, forward / reverse | Experiment/control, forward / reverse |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(rows)+'''

## Mechanisms and bounded repairs

- **Vector pointers:** carry admitted addresses inside the vector body; reconstruct the scalar remainder from the invariant base. Test both body-only and terminal transport, then combine body pointers with carried vector indices. Body-only is within about 0.4% of control and remains short of C. Only this small generic opt-in source extension is committed as live compiler code (`66073d79dc7b9f1b44d89fcffda8cc6c72ceccb2`). The default compiler mode reproduces the retained artifacts exactly.
- **Earlier scalar options:** repeat delayed item packing, encoded winners, first-ordinal reuse and reverse-address construction against the current compiler. Combining these with body-only pointers does not recover the required time.
- **Explicit winner branch / vector entry:** avoid constructing an unselected scalar item; try hot and cold update branches, and 4/8/12-element vector entry. The 12-element entry is close to control. Other changes slow this case; no new win is inferred.
- **Packed unsigned cost/index:** reduce a U64 lexicographic key in single or paired scalar visits. The initial version adds spills. A bounded repair uses one-based source ordinals with a zero sentinel, removes an extra admission test and drops the redundant live minimum. It reduces scalar stack loads from 35,625 to 55, but still takes about 2–3% more time for paired visits. Exact source inputs for both stages are archived.
- **Matcher strategy:** repeat word-only and wider-vector modes. Disabling saved-prefix options emits the exact same matcher object, establishing no applicable opportunity for those flags here. Word-only saves 112 B after placement but does not earn a runtime win.
- **Word-first hybrid:** run the original 8-byte comparison before wider tiers on the proved unsaved path. Test both 16- and 64-byte tiers. The original source already uses trailing-zero detection on differing words. The hybrid remains near control, while the wider tier is slower. Preserve both source snapshots and failed attempts, without adding unused production machinery.

Every timed worker is source-emitted from the unchanged 2,719-line codec and canonical bytecode. No LLVM dependency is added. Counter clones are untimed diagnostics, never latency inputs. The scorer/matcher layout profiles are explicit partial-flow estimates, not exact edge counts; profiles for unchanged other functions are reused only after code and relocation identities agree.

The actual linked checks cover 162 output/inflation/alias observations and six checked failures per profiled worker, with 4,848 B active stack below the 5,280 B limit. Those checks do not establish a fresh twelve-recovery campaign for every probe. Optimized original/decoded reduction tests pass in five body-pointer configurations (15 tests each). The archived packed-key compiler has 16 tests passing in seven configurations and a direct production-key JIT test over 5,400 combinations. Some generic whole-program fixtures do not admit the biased packed-item fast path, so the direct primitive test and actual codec checks provide different coverage. The word-first harness tests the exact production unsaved rewrite; saved-state adapters are unexecuted and provide no saved-state proof.

## Portable evidence

`source-and-receipts.tar.gz` contains compiler input overlays, implementation patches, emission recipes, native objects, metadata, profiles, counter provenance and checks. `raw-runtime.tar.gz` contains every raw latency block, peer pins and the timing driver. `archive-files.json` pins every entry. `study.json` records compiler and native-artifact identities and every result. Compilers and linked workers are not bundled; rebuild the compiler from the pinned base plus the exact `source-inputs` overlay for the stage being replayed, then apply its recipe. Profile path arguments can be rebound to `portable-profiles/<sha>.json` after hash verification. Retain untracked source inputs from snapshots as well as tracked patches when replaying prototype stages.

Some early `bound/runtime.json` files retain inherited `size_bytes`/`encoder_sha256` labels; those two labels are not authoritative. Use each emission receipt's `text_bytes` and `artifacts.program.o`, checked directly by `verify.py`, plus the actual worker hash bound by each campaign. No experimental promotions are recorded.

Run `python3 verify.py` to recalculate archive hashes, emitted text sizes, canonical bytecode, live source identity and all paired runtime ratios. The selected worker and full scorecard remain documented in [the retained study](../encoder-size-gap/immutable-current-read-study/README.md). The latest matched source-through-link timing, **2.245045 s**, belongs to compiler source `44fc9f053…`; the new opt-in pointer source has not received a fresh matched build cohort.
''')
