mod native_artifact {pub mod program {pub mod codegen {pub mod cfg_cleanup {use cranelift_codegen::ir::{Function,InstructionData as D,Opcode as O,Value,ValueDef,types};pub(super) fn masked_integer_comparison(
    f: &Function,
    instruction: &D,
    mut resolve: impl FnMut(Value) -> Option<Value>,
) -> Option<Value> {
    let D::BinaryImm64 {
        opcode: O::BandImm,
        arg,
        imm,
    } = *instruction
    else {
        return None;
    };
    if imm.bits() != 1 {
        return None;
    }
    let mut value = arg;
    for _ in 0..8 {
        value = resolve(value)?;
        let ValueDef::Result(definition, 0) = f.dfg.value_def(value) else {
            return None;
        };
        match f.dfg.insts[definition] {
            D::Unary {
                opcode: O::Uextend,
                arg,
            } => value = arg,
            D::IntCompare { .. } | D::IntCompareImm { .. }
                if f.dfg.value_type(value) == types::I8 =>
            {
                return Some(value);
            }
            _ => return None,
        }
    }
    None
}
pub mod word_ranges {use cranelift_codegen::ir::{Function,InstructionData as Data,Value,ValueDef};use cranelift_codegen::ir::Opcode as Op;fn word_mask(function: &Function, value: Value) -> Option<u64> {
    let ty = function.dfg.value_type(value);
    (ty.is_int() && !ty.is_vector() && ty.bits() > 0 && ty.bits() <= 64)
        .then(|| u64::MAX >> (64 - ty.bits()))
}

pub(super) fn literal(function: &Function, value: Value) -> Option<u64> {
    let value = function.dfg.resolve_aliases(value);
    let ValueDef::Result(inst, 0) = function.dfg.value_def(value) else {
        return None;
    };
    let Data::UnaryImm {
        opcode: Op::Iconst,
        imm,
    } = function.dfg.insts[inst]
    else {
        return None;
    };
    Some(imm.bits() as u64 & word_mask(function, value)?)
}
} pub mod window_bounds {use cranelift_codegen::ir::{Function,Inst,InstructionData as Data,Opcode,Value,ValueDef,condcodes::IntCC};use super::{masked_integer_comparison,word_ranges::literal};fn predicate_definition(f: &Function, mut value: Value) -> Option<Inst> {
    loop {
        let ValueDef::Result(inst, 0) = f.dfg.value_def(f.dfg.resolve_aliases(value)) else {
            return None;
        };
        match f.dfg.insts[inst] {
            Data::Unary {
                opcode: Opcode::Uextend,
                arg,
            } => value = arg,
            _ => match masked_integer_comparison(f, &f.dfg.insts[inst], |value| {
                Some(f.dfg.resolve_aliases(value))
            }) {
                Some(comparison) => value = comparison,
                None => return Some(inst),
            },
        }
    }
}

pub(super) fn comparison(f: &Function, value: Value) -> Option<Inst> {
    let mut inst = predicate_definition(f, value)?;
    loop {
        let inner = match f.dfg.insts[inst] {
            Data::IntCompare {
                cond: IntCC::Equal,
                args: [a, b],
                ..
            } if literal(f, b) == Some(1) => Some(a),
            Data::IntCompare {
                cond: IntCC::Equal,
                args: [a, b],
                ..
            } if literal(f, a) == Some(1) => Some(b),
            Data::IntCompareImm {
                cond: IntCC::Equal,
                arg,
                imm,
                ..
            } if imm.bits() == 1 => Some(arg),
            _ => None,
        };
        // Equality to one is identity only for the result of a comparison.
        if let Some(next) = inner.and_then(|word| predicate_definition(f, word)) {
            if matches!(
                f.dfg.insts[next],
                Data::IntCompare { .. } | Data::IntCompareImm { .. }
            ) {
                inst = next;
                continue;
            }
        }
        return Some(inst);
    }
}
} #[path="/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/compared_bytes/mod.rs"]pub mod compared_bytes;}}}}