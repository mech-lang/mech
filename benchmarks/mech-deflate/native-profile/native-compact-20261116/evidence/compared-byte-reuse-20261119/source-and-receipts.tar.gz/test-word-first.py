from pathlib import Path
from hashlib import sha256
import json,subprocess
D=Path(__file__).resolve().parent;I=D.parent;W=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP');B=W/'hosts/gpu/src/native_artifact/program/codegen';T=D/'word-first-unit';T.mkdir(exist_ok=True);sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
def function(text,name):
 a=text.index('fn '+name+'(');start=text.index('{',a);depth=0
 for i in range(start,len(text)):
  depth+=(text[i]=='{')-(text[i]=='}')
  if depth==0:return text[a:i+1]
 raise ValueError(name)
source=(B/'wide_equal.rs').read_text();body=source[source.index('struct Resolve'):source.index('#[cfg(test)]')].replace('pub(in crate::native_artifact)','pub(crate)');mask=function((B/'cfg_cleanup/boolean_conditions/mod.rs').read_text(),'masked_integer_comparison')
header=r"""#![allow(dead_code)]
use cranelift_codegen::Context;
use cranelift_codegen::cursor::{Cursor,FuncCursor};
use cranelift_codegen::ir::condcodes::{CondCode,IntCC};
use cranelift_codegen::ir::{Block,BlockArg,Endianness,Function,Inst,InstBuilder,InstructionData as Data,MemFlags,Opcode,Value,ValueDef,types};
use std::collections::BTreeSet;
use Data as D;use Opcode as O;
struct Certificate {header:Block,blocks:BTreeSet<Block>,source_header:usize,reuse_scope:Option<reuse::Scope>}
mod reuse {
 use super::*;
 #[derive(Clone,Copy,Debug)]pub struct Scope {pub header:usize}
 #[derive(Clone,Copy)]pub struct State;
 #[derive(Debug)]pub enum Extent {Fixed(u64),Variable}
 pub fn extent(_: &Context,_:&Certificate,_:&Change)->Option<Extent>{panic!("saved-state admission is outside these tests")}
 pub fn begin(_: &mut Context,_:Scope,_:&Change)->Option<State>{panic!("saved-state admission is outside these tests")}
 impl State {
  pub fn advance_forwarded(self,_:&mut FuncCursor<'_>,_:&Change,_:Value,_:Value)->Value{panic!("saved state is outside these tests")}
  pub fn advance(self,_:&mut FuncCursor<'_>,_:&Change,_:Value,_:bool)->Value{panic!("saved state is outside these tests")}
  pub fn proved_prefix_end(self,_:&mut FuncCursor<'_>,_:&Change,_:Value)->Value{panic!("saved state is outside these tests")}
  pub fn record_prefix(self,_:&mut Function,_:&Change,_:u64,_:Value){panic!("saved state is outside these tests")}
  pub fn record_words(self,_:&mut Function,_:&Certificate,_:&Change){panic!("saved state is outside these tests")}
 }
}
mod prefix {
 use super::*;
 pub struct Handoff {pub header:usize}
 impl Handoff {pub fn emit(self,_:&mut Function,_:Value)->Value{panic!("saved state is outside these tests")}}
 pub fn continuation(_: &Context,_:&Certificate,_:&Change,_:reuse::Scope,_:&[Certificate],_:&std::collections::BTreeMap<usize,(reuse::State,Value)>)->Option<Handoff>{panic!("saved-state admission is outside these tests")}
}
"""
tests=(B/'wide_equal_tests.rs').read_text();names=['fixture','equality_scan_strategies_preserve_word_mismatches_and_admitted_tails','compact_wide_equal_refuses_effects_other_steps_extra_state_or_unproved_geometry'];test_header='\nmod tests {\nuse super::*;\nuse cranelift_codegen::ir::AbiParam;\nuse cranelift_frontend::{FunctionBuilder,FunctionBuilderContext};\nuse cranelift_jit::{JITBuilder,JITModule};\nuse cranelift_module::{Linkage,Module,default_libcall_names};\n';parts=[function(tests,n) for n in names];test_body=test_header+parts[0]+'\n'+''.join('#[test]\n'+p+'\n' for p in parts[1:])+'}\n';test_body=test_body.replace('JITBuilder::new(default_libcall_names()).unwrap()','JITBuilder::with_flags(&[("opt_level","speed"),("enable_verifier","true")],default_libcall_names()).unwrap()');harness=header+mask+'\n'+body+'\n'+test_body;(T/'tests.rs').write_text(harness)
libs=json.loads((I/'collector-read-lifetimes/focused-tests/build.json').read_text())['dependencies'];cmd=['rustc','+nightly-2026-03-03','--edition=2024','--test','-D','warnings','-C','opt-level=3','-L','dependency='+str(I/'target/release/deps'),str(T/'tests.rs'),'-o',str(T/'tests')]
for name,r in libs.items():assert sha(r['path'])==r['sha256'];cmd+=['--extern',name+'='+r['path']]
with (T/'build.log').open('w') as log:done=subprocess.run(cmd,stdout=log,stderr=log)
assert done.returncode==0,(T/'build.log').read_text()
with (T/'tests.log').open('w') as log:done=subprocess.run([str(T/'tests'),'--test-threads=1'],env={k:v for k,v in __import__('os').environ.items() if not k.startswith('MECH_')},stdout=log,stderr=log)
record={'command':cmd,'source_inputs':{str(p.relative_to(W)):sha(p) for p in [B/'wide_equal.rs',B/'wide_equal_tests.rs',B/'cfg_cleanup/boolean_conditions/mod.rs']},'test_binary_sha256':sha(T/'tests'),'exit_code':done.returncode,'dependencies':libs,'scope':'Complete production Resolve/candidate/apply/strategy optimizer and Boolean-mask function, with exact source test fixture and two source tests under optimized verified JIT. Saved-state constructors/methods are unexecuted panic adapters. Word-first applies only when saved state is absent. No constructor, saved-state or source-loan admission proof is inferred; actual codec outputs/failures/recovery/stack/runtime remain separate.'};(T/'result.json').write_text(json.dumps(record,indent=2)+'\n');print((T/'tests.log').read_text(),flush=True);assert done.returncode==0
