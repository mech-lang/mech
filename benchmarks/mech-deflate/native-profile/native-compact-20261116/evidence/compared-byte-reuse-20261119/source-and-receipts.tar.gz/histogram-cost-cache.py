"""Untimed source-bound value histogram; instrumented clone is never latency code."""
from pathlib import Path
from hashlib import sha256
import json,subprocess,struct
N=Path(__file__).resolve().parent;I=N.parent;Q=I.parent;O=N/'cost-transition-profile';O.mkdir();script=N/'count-profiles.py';source=script.read_text().split('source_shapes={}',1)[0];scope={'__file__':str(script),'__name__':'short_histogram_helpers'};exec(compile(source,str(script),'exec'),scope);normalize=scope['normal'];B=I/'collector-read-lifetimes/placement/immutable-profiled/bound';F=O/'canonical/frontend';F.mkdir(parents=True);pin=normalize(B/'program.o',F/'program.o');(O/'canonicalization.json').write_text(json.dumps(pin,indent=2)+'\n')
helper=Q/'count-matcher-instructions.py';h={'__file__':str(helper),'__name__':'short_histogram_counter'};text=helper.read_text();needle='        mapped[pc] = start + len(output) * 4';assert text.count(needle)==1;injection='''        if pc == start + 620:
            assert assembly[pc] == ('add', 'x8, x3, #0x80c'), assembly[pc]
            at = start + len(output) * 4
            new_relocs.extend(((at + 8, 0x5D000000 | n), (at + 12, 0x6C000000 | n)))
            output.extend(hist_words)
''';text=text.replace(needle,injection+needle);text=text.replace('[u64; 1024]', '[u64; 4096]').replace('[0; 1024]', '[0; 4096]');exec(compile(text,str(helper),'exec'),h)
asm=O/'histogram.s';asm.write_text('''.text
stp x15,x16,[sp,#-32]!
str x17,[sp,#16]
adrp x16,_mech_matcher_block_counts@GOTPAGE
ldr x16,[x16,_mech_matcher_block_counts@GOTPAGEOFF]
ldr x17,[x16,#32760]
str x7,[x16,#32760]
orr x17,x7,x17,lsl #5
add x16,x16,#8192
add x16,x16,x17,lsl #3
ldr x15,[x16]
add x15,x15,#1
str x15,[x16]
ldr x17,[sp,#16]
ldp x15,x16,[sp],#32
''');subprocess.run(['clang','-c',str(asm),'-o',str(O/'histogram.o')],check=True);data,sections,_=h['macho'].load(O/'histogram.o');sect=sections[h['text']];words=list(struct.unpack_from('<14I',data,sect[3]));h['hist_words']=words;metadata=json.loads((B/'metadata.json').read_text());_,_,phase=h['phase_metadata'](metadata,'_mech_compact_numeric_3009_no_growth_composed');assert phase['code_bytes']>652
# The retained atom's literal pool begins at 1088; read it from the exact archived shape.
parsed=scope['study'].rebase.parse('selected');pool=parsed['pool'];print('pool',pool,flush=True)
asms,leaders,end=h['instrument'](F/'program.o',phase['code_bytes'],O/'program.o','_mech_compact_numeric_3009_no_growth_composed',pool);assert len(leaders)<512
worker=h['link_worker'](B,O,O/'program.o');fixtures=json.loads((Q/'fixtures.json').read_text());results={}
for name in ['prefix-natural-4096','prefix-natural-8192','prefix-random-1048576']:
 index=next(i for i,r in enumerate(fixtures) if r['name']==name);result=subprocess.run([str(worker),str(B/'metadata.json'),str(Q/'fixtures.json')],input=f'C\t{index}\t0\nNNQ\n',text=True,capture_output=True,check=True);(O/(name+'.protocol.log')).write_text(result.stdout);(O/(name+'.stderr')).write_text(result.stderr);rows=[json.loads(l) for l in result.stdout.splitlines() if l.startswith('{')];assert len(rows)==2 and rows[0]['block_counts']==rows[1]['block_counts'];assert all(all(r[k] for k in ['exact_reference','independent_inflation','input_alias_unchanged','borrowed_output_alias_unchanged']) for r in rows);counts=rows[0]['block_counts'];assert not any(counts[len(leaders):1024]) and not any(counts[2048:4095]);hist={i:n for i,n in enumerate(counts[1024:2048]) if n};total=sum(hist.values());hits=sum(n for i,n in hist.items() if i//32==i%32);results[name]={'transitions':hist,'total':total,'same_class':hits,'same_class_fraction':hits/total,'calls':counts[0]};print(name,{k:v for k,v in results[name].items() if k!='transitions'},flush=True)
(O/'result.json').write_text(json.dumps({'untimed':True,'shipping_worker_sha256':sha256((B/'mech-worker').read_bytes()).hexdigest(),'shipping_object_sha256':sha256((B/'program.o').read_bytes()).hexdigest(),'histogram_instruction_offset':620,'histogram_value':'previous_code*32+current_code; previous initialized to0 per call','cases':results,'scope':'Diagnostic clone only. Counter addition preserves registers, SP and NZCV; no latency inference.'},indent=2)+'\n');(O/'counter-source.py').write_text(text)
