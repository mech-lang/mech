from pathlib import Path
W=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP');p=W/'hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/composed_reads.rs';s=p.read_text();needle='''    bias: u8,
}''';assert s.count(needle)==1;s=s.replace(needle,'''    bias: u8,
    compressed: Option<CompressedIndex>,
}

#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
struct CompressedIndex {
    split: u64,
    bank: u64,
    shift: u64,
    length: usize,
}

impl CompressedIndex {
    fn index(self, word: u64) -> usize {
        if word > self.split {
            ((word - 1) >> self.shift) as usize + self.bank as usize
        } else {
            word as usize
        }
    }
}''')
a=s.index('''    fn encode(&self) -> Box<[u8]> {''');b=s.index('\n}\n\nstruct DenseCodes',a)
s=s[:a]+'''    fn value(&self, word: u64) -> u8 {
        let split = self.bytes.len() as u64;
        let upper = word > split;
        let shift = if upper { self.high_shift } else { 0 };
        let index = word.wrapping_sub(1) >> shift;
        let slot = if index < split {
            self.bytes[index as usize]
        } else {
            0
        };
        slot + if upper { self.bias } else { 0 }
    }

    fn compressed_values(&self, index: CompressedIndex) -> Option<Box<[u8]>> {
        let mut entries = vec![None; index.length];
        for word in 0..self.input_length {
            let cell = entries.get_mut(index.index(word))?;
            let value = self.value(word);
            if cell.is_some_and(|previous| previous != value) {
                return None;
            }
            *cell = Some(value);
        }
        Some(entries.into_iter().map(|v| v.unwrap_or(0)).collect())
    }

    fn compress(&mut self) {
        let split = self.bytes.len() as u64;
        if split == 0 || self.high_shift == 0 || self.high_shift >= 64
            || self.input_length <= split + 1
        {
            return;
        }
        let bank = (split + 1).next_power_of_two();
        let length = bank + ((self.input_length - 2) >> self.high_shift) + 1;
        if length >= self.input_length / 2 {
            return;
        }
        let Ok(length) = usize::try_from(length) else { return; };
        let index = CompressedIndex { split, bank, shift: self.high_shift, length };
        // Every admitted word must address the same source-derived code.
        // A conflicting cell or unrepresentable geometry keeps the dense map.
        if self.compressed_values(index).is_some() {
            self.compressed = Some(index);
        }
    }

    fn encode(&self) -> Box<[u8]> {
        if let Some(index) = self.compressed {
            return self.compressed_values(index).expect("verified immutable index map");
        }
        (0..self.input_length).map(|word| self.value(word)).collect()
    }''' +s[b:]
a=s.index('''            Some(DenseCodes {
                word,
                key: CodeKey {''');b=s.index('''        })()
    } else {''',a)
s=s[:a]+'''            let mut key = CodeKey {
                bytes: bytes.clone(),
                input_length: maximum + 1,
                high_shift: split.selector.high,
                bias: bank_delta as u8,
                compressed: None,
            };
            if std::env::var_os("MECH_COMPOSE_COMPRESSED_COST_CODES").is_some() {
                key.compress();
            }
            Some(DenseCodes { word, key })
'''+s[b:]
needle='''        let cell = c.ins().iadd(codes, word);''';assert s.count(needle)==1;s=s.replace(needle,'''        let index = if let Some(index) = dense.key.compressed {
            let previous = c.ins().iadd_imm(word, -1);
            let upper = c.ins().ushr_imm(previous, index.shift as i64);
            let upper = c.ins().iadd_imm(upper, index.bank as i64);
            let large = c.ins().icmp_imm(IntCC::UnsignedGreaterThan, word, index.split as i64);
            c.ins().select(large, upper, word)
        } else {
            word
        };
        let cell = c.ins().iadd(codes, index);''')
p.write_text(s)
