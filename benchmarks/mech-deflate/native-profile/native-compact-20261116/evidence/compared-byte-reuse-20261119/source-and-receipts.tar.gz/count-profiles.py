"""Untimed diagnostic block counters; shipping objects come only from source compilation."""
from pathlib import Path
from runpy import run_path
from hashlib import sha256
from types import ModuleType,SimpleNamespace
import ast,json,struct,sys
ROOT=Path(__file__).resolve().parent;LAB=ROOT.parent;Q=LAB.parent
PACKET=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/benchmarks/mech-deflate/native-profile/native-compact-20261116')
sys.path.insert(0,str(Q));sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
# Reuse only the original parser/relocation helpers. Importing the historical
# outlining script as a whole would open unrelated, now-missing temp artifacts.
obj_file=PACKET.parent/'compact-size/compact_object.py';branch_file=Q/'outline-compiled-aarch64-root.py'
def functions(path,names):
 tree=ast.parse(path.read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names];assert {n.name for n in nodes}==set(names)
 scope={'unpack_from':struct.unpack_from};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),scope);return {n:scope[n] for n in names}
layout=ModuleType('outline-compiled-aarch64-root');layout.obj=SimpleNamespace(**functions(obj_file,['tables','relocs']))
for key,value in functions(branch_file,['branch_field','branch_target','branch_opcode']).items():setattr(layout,key,value)
sys.modules[layout.__name__]=layout
h=run_path(str(Q/'current-roadmap/shared-heap-call-setup/evaluate.py'),run_name='natural4k_counter_tools');rt=h['runtime'];study=rt.study;driver=rt.driver
study.HERE=ROOT;study.rebase.HERE=ROOT
training=('prefix-natural-4096','prefix-natural-8192','reymont-prefix-32769','prefix-natural-32769')
roles=sys.argv[1:] or ['control-default','pointer-exit-default','pointer-body-default','pointer-exit-lanes-default','pointer-body-lanes-default']
normalizer_file=LAB/'collector-read-lifetimes/canonical-counter-input.py'
normalizer_source=normalizer_file.read_text().split("link=run_path",1)[0]
normalizer={'__file__':str(normalizer_file),'__name__':'scorer_counter_coordinates'};exec(compile(normalizer_source,str(normalizer_file),'exec'),normalizer)
normal=normalizer['normalize']
source_shapes={}
for role in roles:
 actual=ROOT/role/'bound'
 if not (actual/'runtime.json').exists():driver.link.link_worker(LAB/'collector-read-lifetimes/placement/immutable-profiled/bound',ROOT/role/'frontend',actual)
 recipe=json.loads((actual/'runtime.json').read_text());recipe.pop('size_bytes',None);recipe.pop('encoder_sha256',None);recipe['encoder_text_bytes']=json.loads((ROOT/role/'receipt.json').read_text())['text_bytes'];(actual/'runtime.json').write_text(json.dumps(recipe,indent=2)+'\n')
 if not (actual/'qualification.json').exists():driver.link.check_worker(actual,'scorer-body44-raw-'+role)
 original=study.rebase.parse(role);source_shapes[role]=original
 front=ROOT/role/'canonical-counter-input/frontend';front.mkdir(parents=True,exist_ok=True)
 normalization=normal(ROOT/role/'frontend/program.o',front/'program.o')
 for name in ['metadata.json','program.mecb']:(front/name).write_bytes((ROOT/role/'frontend'/name).read_bytes())
 (front.parent/'canonicalization.json').write_text(json.dumps(normalization,indent=2)+'\n')
 target=front.parent/'bound'
 if not (target/'runtime.json').exists():driver.link.link_worker(actual,front,target)
 assert sha(target/'mech-worker')==sha(actual/'mech-worker'), 'Counter coordinate input must link to the exact same worker'
 if not (target/'qualification.json').exists():driver.link.check_worker(target,'scorer-body44-canonical-'+role)
 ref=study.rebase.parse(role);folder=ROOT/role/'instruction-counts'
 original=Q/'count-matcher-instructions.py';program=original.read_text();needle='    root = q / f"{label}-native/final-candidate"';assert program.count(needle)==1;program=program.replace(needle,f'    root = Path({str(target)!r})')
 needle='    directory = q / "matcher-dynamic-blocks" / actor';assert program.count(needle)==1;program=program.replace(needle,f'    directory = Path({str(folder)!r})')
 headers={'__name__':'natural4k_source_body_counters','__file__':str(original)};exec(compile(program,str(original),'exec'),headers)
 if not (folder/'canonical-counts.json').exists():
  headers['count'](role,role,training,driver.SCORER,ref['pool'])
  (folder/'counts.json').rename(folder/'canonical-counts.json')
 record={'untimed':True,'shipping_encoder_sha256':sha(actual/'program.o'),'diagnostic_coordinate_object_sha256':sha(target/'program.o'),'counter_driver_sha256':sha(original),'branch_helpers':{'source':str(branch_file),'sha256':sha(branch_file)},'object_helpers':{'source':str(obj_file),'sha256':sha(obj_file)},'training_cases':training,'counter_source':program,'scope':'Instrumentation adds counters only to a diagnostic clone. Never use it for latency or deployment.'}
 (folder/'plan.json').write_text(json.dumps(record,indent=2)+'\n')
 raw=folder/'counts.json'
 counts=json.loads((folder/'canonical-counts.json').read_text());canonical_atom=driver.symbols(front/'program.o')['symbols'][driver.SCORER];source_atom=source_shapes[role]['atom'];assert {k:canonical_atom[k] for k in ['extent','sha256','relocations']}=={k:source_atom[k] for k in ['extent','sha256','relocations']}
 delta=source_atom['start']-canonical_atom['start']
 for case in counts['cases'].values():
  for block in case['blocks']:block['address']=hex(int(block['address'],16)+delta)
 counts.update(object_sha256=source_shapes[role]['object_sha256'],canonical_counts_sha256=sha(folder/'canonical-counts.json'),address_translation=delta,canonicalization_sha256=sha(front.parent/'canonicalization.json'))
 raw.write_text(json.dumps(counts,indent=2)+'\n')
 profile=study.profiles(role);p=json.loads(profile.read_text());p['thread_jumps']=True;profile.write_text(json.dumps(p,indent=2)+'\n')
 print(role,'profile',profile,flush=True)
