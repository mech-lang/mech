from pathlib import Path
from hashlib import sha256
import gzip,io,json,tarfile,subprocess
D=Path(__file__).resolve().parent;I=D.parent;Q=I.parent;W=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP');P=W/'benchmarks/mech-deflate/native-profile/native-compact-20261116';E=P/'evidence/runtime-next-win-20261119';E.mkdir(exist_ok=False);sha=lambda b:sha256(b).hexdigest();read=lambda p:json.loads(p.read_text())
def archive(path,files):
 pins={}
 with path.open('wb') as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped:
   with tarfile.open(mode='w',fileobj=zipped) as tar:
    for name,f in sorted(files.items()):
     data=Path(f).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data));pins[name]={'bytes':len(data),'sha256':sha(data)}
 return pins
files={}
for f in D.rglob('*'):
 if not f.is_file():continue
 rel=f.relative_to(D)
 if 'compiler' in rel.parts and f.name=='compile_profile':continue
 if f.suffix in ['.json','.jsonl','.py','.log','.rs','.patch','.txt','.stderr','.mec'] or f.name.endswith('.json.gz'):
  files[str(rel)]=f
 elif f.name=='program.o' and f.parent.name=='frontend' and 'canonical-counter-input' not in rel.parts:files[str(rel)]=f
files['canonical-program.mecb']=D/'selected/frontend/program.mecb';cases={}
for p in D.glob('*/receipt.json'):
 r=read(p);cases[p.parent.name]={'receipt':str(p.relative_to(D)),'text_bytes':r['text_bytes'],'artifacts':r['artifacts'],'compiler_sha256':r['compiler_sha256']}
profile_files={}
for p in D.glob('*profile.json'):profile_files[sha(p.read_bytes())]=p
for p in D.glob('*/receipt.json'):
 for item in read(p)['flags'].get('MECH_COMPACT_PHASE_BLOCK_LAYOUT','').split(';'):
  if item:
   f=Path(item.split('@',1)[1]);assert f.exists();profile_files[sha(f.read_bytes())]=f
for h,f in profile_files.items():files['portable-profiles/'+h+'.json']=f
campaigns={};raw_files={}
for p in D.glob('probe-*-results.json'):
 r=read(p);campaigns[p.stem]=r
 for row in r['runs']:
  folder=Path(row['run']);key=folder.name
  for f in folder.rglob('*'):
   if f.is_file() and (f.name in ['observations.json.gz','summary.json','pins.json','pins.sha256'] or f.suffix=='.stderr'):raw_files[str(Path(key)/f.relative_to(folder))]=f
raw_files['compare-library.py']=Q/'compare-library.py';receipt_pins=archive(E/'source-and-receipts.tar.gz',files);raw_pins=archive(E/'raw-runtime.tar.gz',raw_files);(E/'archive-files.json').write_text(json.dumps({'source-and-receipts.tar.gz':receipt_pins,'raw-runtime.tar.gz':raw_pins},indent=2)+'\n')
(E/'study.json').write_text(json.dumps({'live_source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),'live_source_selection':read(D/'live-source-selection.json'),'objective':'Earn 63/81 libdeflate wins while retaining every existing peer win and 81/81 Roc.','qualified_selection':{'recipe':'m1-immutable-current-reads','text_bytes':63532,'roc':81,'libdeflate':62,'worker_sha256':'834c7a7e423a69c46483a3dae74d9450949fdf142b5ad2dede894e0da3ca8693'},'experimental_promotions':[],'cases':cases,'campaigns':campaigns,'scope':'Single-case diagnostics, 96 balanced paired blocks per order. No full runtime qualification or 63rd win is claimed. All measured objects come from original-source compilation; counters use separate untimed clones.'},indent=2)+'\n');print('Published',len(cases),'cases,',len(campaigns),'campaigns,',len(files)+len(raw_files),'archive entries',flush=True)
