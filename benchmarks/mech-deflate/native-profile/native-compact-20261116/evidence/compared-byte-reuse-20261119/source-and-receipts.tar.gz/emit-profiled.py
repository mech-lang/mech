from pathlib import Path
from hashlib import sha256
from runpy import run_path
import json,os,subprocess,sys
D=Path(__file__).resolve().parent;I=D.parent;Q=I.parent;read=lambda p:json.loads(p.read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();tool=run_path(str(Q/'current-roadmap/scorer-runtime/emit.py'),run_name='profiled_scorer_layout')
for old in ['control-default','pointer-exit-default','pointer-body-default','pointer-exit-lanes-default','pointer-body-lanes-default']:
 r=read(D/old/'receipt.json');role=old.replace('-default','-profiled');folder=D/role;folder.mkdir();profile=D/(old+'-scorer-profile.json');flags=r['flags'].copy();flags['MECH_COMPACT_PHASE_BLOCK_LAYOUT']+=';mech_compact_numeric_3009_no_growth_composed@'+str(profile);cmd=[r['compile'][0],r['compile'][1],str(folder/'frontend'),'compact']
 with (folder/'compile.log').open('w') as log:done=subprocess.run(cmd,env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}|flags,stdout=log,stderr=log)
 assert done.returncode==0,(folder/'compile.log').read_text()[-4000:];front=folder/'frontend';art={n:sha(front/n) for n in ['program.o','metadata.json','program.mecb']};assert art['program.mecb']==r['bytecode_sha256'];layout=tool['symbols'](front/'program.o');receipt=r|{'compile':cmd,'command':cmd,'flags':flags,'artifacts':art,'object_sha256':art['program.o'],'metadata_sha256':art['metadata.json'],'layout':layout,'text_bytes':layout['text_bytes'],'profile_sha256':sha(profile),'profile_source':old,'runtime_qualification':'pending'};receipt.pop('unpaired_seconds_diagnostic',None);(folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(role,layout['text_bytes'],flush=True)
