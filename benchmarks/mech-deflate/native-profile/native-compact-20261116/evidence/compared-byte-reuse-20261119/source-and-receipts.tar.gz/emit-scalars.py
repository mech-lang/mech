from pathlib import Path
from hashlib import sha256
from runpy import run_path
import json,os,subprocess,sys,time
D=Path(__file__).resolve().parent;I=D.parent;Q=I.parent;W=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP');read=lambda p:json.loads(p.read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();build=read(D/'compiler-build/build.json');compiler=str(Path(build['compiler']).resolve());assert sha(compiler)==build['compiler_sha256'];flags=read(I/'controller-source-boundaries/scoped-registers/selected-map/result.json')['flags'];flags.pop('MECH_COMPACT_SOURCE_BLOCK_REPORT',None);source=W/'benchmarks/mech-deflate/native-profile/native-compact-20261116/program.mec';tool=run_path(str(Q/'current-roadmap/scorer-runtime/emit.py'),run_name='source_scorer_layout');profiles=flags['MECH_COMPACT_PHASE_BLOCK_LAYOUT'];without=';'.join(x for x in profiles.split(';') if not x.startswith('mech_compact_numeric_3009_no_growth_composed@'))

variants={
 'scalar-reuse-ordinal-default':{'MECH_ORDERED_REUSE_FIRST_ORDINAL':'1'},
 'scalar-from-end-default':{'MECH_ORDERED_FIRST_REVERSE_FROM_END':'1'},
 'scalar-reuse-from-end-default':{'MECH_ORDERED_REUSE_FIRST_ORDINAL':'1','MECH_ORDERED_FIRST_REVERSE_FROM_END':'1'},
 'scalar-pack-default':{'MECH_ORDERED_PACK_WINNER_AT_EXIT':'1'},
 'scalar-encode-default':{'MECH_ORDERED_ENCODE_WINNER_WITH_OFFSET':'1'},
 'scalar-pack-body-default':{'MECH_ORDERED_PACK_WINNER_AT_EXIT':'1','MECH_ORDERED_VECTOR_CARRY_POINTERS':'body'},
 'scalar-encode-body-default':{'MECH_ORDERED_ENCODE_WINNER_WITH_OFFSET':'1','MECH_ORDERED_VECTOR_CARRY_POINTERS':'body'},
 'scalar-pack-addresses-default':{'MECH_ORDERED_PACK_WINNER_AT_EXIT':'1','MECH_ORDERED_VECTOR_CARRY_POINTERS':'body','MECH_ORDERED_REUSE_FIRST_ORDINAL':'1','MECH_ORDERED_FIRST_REVERSE_FROM_END':'1'},
}
for label,extra in variants.items():
 folder=D/label;folder.mkdir(exist_ok=False);command=[compiler,str(source),str(folder/'frontend'),'compact'];native=flags|{'MECH_COMPACT_PHASE_BLOCK_LAYOUT':without}|extra
 with (folder/'compile.log').open('w') as log:r=subprocess.run(command,env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}|native,stdout=log,stderr=log)
 assert r.returncode==0,(folder/'compile.log').read_text()[-3000:];front=folder/'frontend';artifacts={n:sha(front/n) for n in ['program.o','metadata.json','program.mecb']};assert artifacts['program.mecb']=='c6529d934f020f07f8e59f13fab40927e066649e202269818ad3f009a942a8c3';layout=tool['symbols'](front/'program.o')
 receipt={'source_base':'44fc9f05304111c6e75cac54a3dc5ec5c4f443bf','source_pin':'44fc9f05304111c6e75cac54a3dc5ec5c4f443bf plus scorer body-only pointer repair','compile':command,'command':command,'flags':native,'compiler_sha256':sha(compiler),'artifacts':artifacts,'object_sha256':artifacts['program.o'],'metadata_sha256':artifacts['metadata.json'],'bytecode_sha256':artifacts['program.mecb'],'layout':layout,'text_bytes':layout['text_bytes'],'runtime_qualification':'pending'};(folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(label,layout['text_bytes'],flush=True)
