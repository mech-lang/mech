from pathlib import Path
from hashlib import sha256
from runpy import run_path
import json,os,subprocess,sys,time
D=Path(__file__).resolve().parent;I=D.parent;Q=I.parent;W=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP');read=lambda p:json.loads(p.read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();build=read(D/'scalar-key-repair-compiler/build.json');compiler=str(Path(build['compiler']).resolve());assert sha(compiler)==build['compiler_sha256'];flags=read(I/'controller-source-boundaries/scoped-registers/selected-map/result.json')['flags'];flags.pop('MECH_COMPACT_SOURCE_BLOCK_REPORT',None);source=W/'benchmarks/mech-deflate/native-profile/native-compact-20261116/program.mec';tool=run_path(str(Q/'current-roadmap/scorer-runtime/emit.py'),run_name='source_scorer_layout');profiles=flags['MECH_COMPACT_PHASE_BLOCK_LAYOUT'];without=';'.join(x for x in profiles.split(';') if not x.startswith('mech_compact_numeric_475_vector@'))

variants={
 'matcher-exact-control':None,
 'matcher-vector-default':{},
 'matcher-word-default':{'MECH_EQUAL_COMPARE_STRATEGY':'word'},
 'matcher-vector-no-prefix-default':{'MECH_REUSE_EQUALITY_PREFIX':None},
 'matcher-vector-no-reuse-default':{'MECH_REUSE_EQUALITY_PREFIX':None,'MECH_REUSE_SHIFTED_EQUALITY':None},
}
for label,extra in variants.items():
 folder=D/label;folder.mkdir(exist_ok=False);command=[compiler,str(source),str(folder/'frontend'),'compact'];native=flags.copy() if extra is None else flags|{'MECH_COMPACT_PHASE_BLOCK_LAYOUT':without}|extra
 native={k:v for k,v in native.items() if v is not None}
 with (folder/'compile.log').open('w') as log:r=subprocess.run(command,env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}|native,stdout=log,stderr=log)
 assert r.returncode==0,(folder/'compile.log').read_text()[-3000:];front=folder/'frontend';artifacts={n:sha(front/n) for n in ['program.o','metadata.json','program.mecb']};assert artifacts['program.mecb']=='c6529d934f020f07f8e59f13fab40927e066649e202269818ad3f009a942a8c3';layout=tool['symbols'](front/'program.o')
 receipt={'source_base':'c36477ebda733142c3d860abd12799fa12229faa','source_pin':'c36477ebda733142c3d860abd12799fa12229faa plus source-pinned scalar cost keys and paired admitted visits','compile':command,'command':command,'flags':native,'compiler_sha256':sha(compiler),'artifacts':artifacts,'object_sha256':artifacts['program.o'],'metadata_sha256':artifacts['metadata.json'],'bytecode_sha256':artifacts['program.mecb'],'layout':layout,'text_bytes':layout['text_bytes'],'runtime_qualification':'pending'};(folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(label,layout['text_bytes'],flush=True)

selected=read(D/'matcher-exact-control/receipt.json');assert selected['object_sha256']=='cf15343f1f01089d427122ce51a91ef6fa7b70ef89c50ca4db20901a8d2cefd9' and selected['metadata_sha256']=='169d4b5286cba371400aad6a8e760d2cdb43e1839f8c6b325c9ba542820e6b3d'
