"""Publish source-built, unselected byte-reuse and guard-repair evidence."""
from pathlib import Path
from hashlib import sha256
import gzip
import io
import json
import subprocess
import tarfile

D = Path(__file__).resolve().parent
I = D.parent
Q = I.parent
W = Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP')
P = W / 'benchmarks/mech-deflate/native-profile/native-compact-20261116'
E = P / 'evidence/compared-byte-reuse-20261119'
E.mkdir(exist_ok=True)
read = lambda p: json.loads(Path(p).read_text())
digest = lambda p: sha256(Path(p).read_bytes()).hexdigest()


def archive(path, files):
    pins = {}
    with path.open('wb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
            with tarfile.open(mode='w', fileobj=zipped) as tar:
                for name, file in sorted(files.items()):
                    data = file.read_bytes()
                    info = tarfile.TarInfo(name)
                    info.size, info.mtime, info.mode = len(data), 0, 0o644
                    tar.addfile(info, io.BytesIO(data))
                    pins[name] = {'bytes': len(data), 'sha256': sha256(data).hexdigest()}
    return pins


campaigns = {}
raw_files = {'compare-library.py': Q / 'compare-library.py'}
for path in [*D.glob('dp-guard-panel-*-results.json'), *D.glob('byte-edge-panel-*-results.json')]:
    campaign = read(path)
    assert campaign['complete']
    campaigns[path.stem] = campaign
    for row in campaign['runs']:
        folder = Path(row['run'])
        for file in folder.rglob('*'):
            if file.is_file() and (file.name in ['observations.json.gz', 'summary.json', 'pins.json', 'pins.sha256'] or file.suffix == '.stderr'):
                raw_files[str(Path(folder.name) / file.relative_to(folder))] = file

roles = {row['role'] for campaign in campaigns.values() for row in campaign['runs']}
roles |= {p.parent.name for p in D.glob('byte-edge-*/receipt.json')}
roots = set(roles) | {p.name for p in D.glob('byte-edge-*') if p.is_dir()}
roots |= {'dp-vector-guards-compiler', 'dp-forward-narrow-compiler'}
for role in roles:
    path = D / role / 'linked-proof.json'
    if path.exists():
        roots.add(Path(read(path)['result']).relative_to(D).parts[0])
files = {}
for folder in sorted(roots):
    for file in (D / folder).rglob('*'):
        if not file.is_file():
            continue
        rel = file.relative_to(D)
        if 'compiler' in rel.parts and file.name == 'compile_profile':
            continue
        if file.suffix in ['.json', '.jsonl', '.py', '.log', '.rs', '.patch', '.txt', '.stderr', '.mec'] or file.name.endswith('.json.gz') or file.name == 'samples.xml':
            files[str(rel)] = file
        elif file.name == 'program.o' and file.parent.name == 'frontend' and 'canonical-counter-input' not in rel.parts:
            files[str(rel)] = file
for file in D.glob('*.py'):
    files[file.name] = file
for name in ['guard-timing-interruption.json', 'byte-edge-panel.log', 'byte-edge-matched-builds.log']:
    files[name] = D / name
files['canonical-program.mecb'] = D / 'byte-edge-control/frontend/program.mecb'

profiles = {}
cases = {}
for role in sorted(roles):
    receipt = read(D / role / 'receipt.json')
    cases[role] = {key: receipt[key] for key in ['text_bytes', 'artifacts', 'compiler_sha256']}
    cases[role]['receipt'] = role + '/receipt.json'
    for item in receipt['flags'].get('MECH_COMPACT_PHASE_BLOCK_LAYOUT', '').split(';'):
        if item:
            path = Path(item.split('@', 1)[1])
            pin = digest(path)
            profiles[str(path)] = pin
            files['portable-profiles/' + pin + '.json'] = path

source_commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
build = read(D / 'byte-edge-compiler/build.json')
identities = read(D / 'byte-edge-compiler/source-identities.json')
for name, pin in identities.items():
    assert digest(W / name) == pin
    assert sha256(subprocess.check_output(['git', 'show', source_commit + ':' + name], cwd=W)).hexdigest() == pin
study = {
    'live_source_commit': source_commit,
    'live_source_inputs': identities,
    'live_source_archive_prefix': 'byte-edge-compiler/source-inputs/',
    'live_compiler_sha256': build['compiler_sha256'],
    'objective': 'Earn the 63rd libdeflate runtime win while retaining every existing peer win and 81/81 Roc.',
    'qualified_selection': {'recipe': 'm1-immutable-current-reads', 'text_bytes': 63532, 'roc': 81, 'libdeflate': 62, 'worker_sha256': '834c7a7e423a69c46483a3dae74d9450949fdf142b5ad2dede894e0da3ca8693'},
    'experimental_promotions': [],
    'cases': cases,
    'profile_inputs': profiles,
    'campaigns': campaigns,
    'complete_builds': ['byte-edge-matched-builds'],
    'compiler_provenance': {
        build['compiler_sha256']: {'base': build['source_base'], 'committed_implementation': source_commit, 'overlay': 'byte-edge-compiler/source-inputs/'},
        '5766fbea1bcef642223ddd2d99bee5bd5f790ed39a7dbc925cab2091431929df': {'committed_implementation': '96b1f1ebc6214f57af22636721f8bd5a639bbc5a', 'overlay': 'dp-forward-narrow-compiler/source-inputs/'},
        'ed05fd7c18330654e2cc14973a091c8fd9c687058f8d2b7bce8f497964a1d518': {'base': read(D / 'dp-vector-guards-compiler/build.json')['source_base'], 'overlay': 'dp-vector-guards-compiler/source-inputs/', 'scope': 'Archived broader guard-gate prototype, absent from live source.'},
    },
    'provenance_note': 'Inherited source_base/source_pin fields in individual emission receipts label the earlier DP experiment family. Compiler SHA, build.json, complete overlays and the compiler_provenance map above identify the actual source. Artifact and runtime pins are unchanged.',
    'discarded_timing': {'record': 'guard-timing-interruption.json', 'reason': 'An earlier guard campaign overlapped a unit-test build, was interrupted, and contributes no eligible runtime observations. The separately named dp-guard-panel campaign ran after that job ended.'},
    'scope': 'Nineteen-case broad discovery, twenty-four balanced blocks per order. No full score or new peer win is claimed. Every latency input is an original-source emission; diagnostic counter clones are untimed. The codec and canonical bytecode are unchanged.',
}
pins = {'source-and-receipts.tar.gz': archive(E / 'source-and-receipts.tar.gz', files), 'raw-runtime.tar.gz': archive(E / 'raw-runtime.tar.gz', raw_files)}
(E / 'archive-files.json').write_text(json.dumps(pins, indent=2) + '\n')
(E / 'study.json').write_text(json.dumps(study, indent=2) + '\n')
print('Published', len(cases), 'emissions,', sum(len(c['runs']) for c in campaigns.values()), 'runtime orders,', len(files) + len(raw_files), 'archive entries', flush=True)
