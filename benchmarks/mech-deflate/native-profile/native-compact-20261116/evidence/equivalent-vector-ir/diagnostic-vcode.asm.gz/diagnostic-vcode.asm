  pacibsp
  unwind Aarch64SetPointerAuth { return_addresses: true }
  stp fp, lr, [sp, #-16]!
  unwind PushFrameRegs { offset_upward_to_caller_sp: 16 }
  mov fp, sp
  unwind DefineNewFrame { offset_upward_to_caller_sp: 16, offset_downward_to_clobbers: 80 }
  stp x27, x28, [sp, #-16]!
  unwind SaveReg { clobber_offset: 64, reg: p27i }
  unwind SaveReg { clobber_offset: 72, reg: p28i }
  stp x25, x26, [sp, #-16]!
  unwind SaveReg { clobber_offset: 48, reg: p25i }
  unwind SaveReg { clobber_offset: 56, reg: p26i }
  stp x23, x24, [sp, #-16]!
  unwind SaveReg { clobber_offset: 32, reg: p23i }
  unwind SaveReg { clobber_offset: 40, reg: p24i }
  stp x21, x22, [sp, #-16]!
  unwind SaveReg { clobber_offset: 16, reg: p21i }
  unwind SaveReg { clobber_offset: 24, reg: p22i }
  stp x19, x20, [sp, #-16]!
  unwind SaveReg { clobber_offset: 0, reg: p19i }
  unwind SaveReg { clobber_offset: 8, reg: p20i }
  sub sp, sp, #160
  unwind StackAlloc { size: 160 }
block0:
  mov x3, x2
  str x0, [sp, #96]
  ldr x0, [x1, #152]
  str x0, [sp, #120]
  ldr x23, [x1]
  str x23, [sp, #104]
  ldr x7, [x1, #8]
  ldr x0, [x1, #16]
  str x0, [sp, #112]
  ldr x19, [x1, #24]
  ldr x20, [x1, #32]
  str x20, [sp, #152]
  ldr x0, [x1, #40]
  ldr x23, [x1, #48]
  ldr x24, [x1, #56]
  ldr x2, [x1, #64]
  ldr x2, [x1, #72]
  ldr x25, [x1, #80]
  ldr x26, [x1, #88]
  ldr x2, [x1, #96]
  ldr x2, [x1, #104]
  ldr x21, [x1, #112]
  str x21, [sp, #144]
  ldr x28, [x1, #120]
  str x28, [sp, #136]
  ldr x2, [x1, #128]
  ldr x2, [x1, #136]
  ldr x27, [x1, #144]
  b label1
block1:
  b label2
block2:
  b label3
block3:
  b label4
block4:
  b label5
block5:
  b label6
block6:
  b label7
block7:
  b label8
block8:
  b label9
block9:
  b label10
block10:
  b label11
block11:
  ldr x5, [sp, #104]
  subs xzr, x5, #0
  b.ne label14 ; b label12
block12:
  ldr x1, [sp, #112]
  mov x22, x3
  str x1, [x22, #8]
  str x19, [x22, #16]
  ldr x2, [sp, #152]
  str x2, [x22, #24]
  str x0, [x22, #32]
  str x27, [x22, #40]
  str x1, [x22, #48]
  str x19, [x22, #56]
  str x27, [x22, #64]
  ldr x8, [sp, #152]
  str x8, [x22, #72]
  str x0, [x22, #80]
  ldr x1, [sp, #120]
  str x1, [x22, #88]
  b label13
block13:
  movz x1, #0
  mov x0, x1
  add sp, sp, #160
  ldp x19, x20, [sp], #16
  ldp x21, x22, [sp], #16
  ldp x23, x24, [sp], #16
  ldp x25, x26, [sp], #16
  ldp x27, x28, [sp], #16
  ldp fp, lr, [sp], #16
  retabsp
block14:
  mov x22, x3
  b label15
block15:
  b label16
block16:
  b label17
block17:
  b label18
block18:
  b label19
block19:
  b label20
block20:
  b label21
block21:
  b label22
block22:
  b label23
block23:
  b label24
block24:
  sub x0, x7, #1
  subs xzr, x0, x24
  b.lo label28 ; b label25
block25:
  b label26
block26:
  b label27
block27:
  movz x13, #0
  b label32
block28:
  b label29
block29:
  b label30
block30:
  sub x1, x7, #1
  ldr w13, [x23, x1, LSL #2]
  b label31
block31:
  b label32
block32:
  b label33
block33:
  b label34
block34:
  b label35
block35:
  b label36
block36:
  b label37
block37:
  b label38
block38:
  b label39
block39:
  b label40
block40:
  b label41
block41:
  b label42
block42:
  b label43
block43:
  b label44
block44:
  subs xzr, x0, x24
  b.lo label48 ; b label45
block45:
  b label46
block46:
  b label47
block47:
  b label52
block48:
  b label49
block49:
  b label50
block50:
  b label51
block51:
  b label52
block52:
  b label53
block53:
  b label54
block54:
  b label55
block55:
  b label56
block56:
  b label57
block57:
  b label58
block58:
  b label59
block59:
  b label60
block60:
  b label61
block61:
  b label62
block62:
  b label63
block63:
  b label64
block64:
  b label65
block65:
  lsr x0, x13, #16
  add x1, x0, #259
  subs xzr, x1, x26
  b.lo label69 ; b label66
block66:
  b label67
block67:
  b label68
block68:
  movz x3, #0
  b label73
block69:
  b label70
block70:
  b label71
block71:
  add x1, x0, #259
  ldr w3, [x25, x1, LSL #2]
  b label72
block72:
  b label73
block73:
  b label74
block74:
  b label75
block75:
  b label76
block76:
  b label77
block77:
  b label78
block78:
  b label79
block79:
  b label80
block80:
  b label81
block81:
  b label82
block82:
  b label83
block83:
  b label84
block84:
  b label85
block85:
  sub x1, x19, #1
  subs xzr, x1, x19
  b.lo label89 ; b label86
block86:
  b label87
block87:
  b label88
block88:
  movz x4, #0
  b label93
block89:
  b label90
block90:
  b label91
block91:
  sub x1, x19, #1
  ldr x2, [sp, #112]
  ldr x4, [x2, x1, LSL #3]
  b label92
block92:
  b label93
block93:
  b label94
block94:
  b label95
block95:
  b label96
block96:
  b label97
block97:
  b label98
block98:
  b label99
block99:
  b label100
block100:
  b label101
block101:
  b label102
block102:
  b label103
block103:
  b label104
block104:
  b label105
block105:
  b label106
block106:
  b label107
block107:
  b label108
block108:
  b label109
block109:
  b label110
block110:
  b label111
block111:
  b label112
block112:
  b label113
block113:
  b label114
block114:
  b label115
block115:
  b label116
block116:
  b label117
block117:
  and x1, x13, #65535
  sub x2, x7, #1
  sub x1, x2, x1
  str x1, [sp, #128]
  movz x2, #0
  and x1, x4, #4294967295
  add x1, x3, x1
  and x28, x1, #4294967295
  and x0, x0, #4294967295
  movz x1, #1
  orr x0, x1, x0, LSL 9
  and x20, x0, #4294967295
  ldr x0, [sp, #128]
  b label118
block118:
  b label119
block119:
  b label120
block120:
  b label121
block121:
  b label122
block122:
  b label123
block123:
  b label124
block124:
  b label125
block125:
  b label126
block126:
  b label127
block127:
  sub x1, x7, #1
  subs xzr, x0, x1
  b.ne label205 ; b label128
block128:
  b label129
block129:
  b label130
block130:
  b label131
block131:
  b label132
block132:
  b label133
block133:
  b label134
block134:
  b label135
block135:
  b label136
block136:
  b label137
block137:
  b label138
block138:
  b label139
block139:
  b label140
block140:
  b label141
block141:
  b label142
block142:
  b label143
block143:
  b label144
block144:
  b label145
block145:
  b label146
block146:
  b label147
block147:
  b label148
block148:
  b label149
block149:
  b label150
block150:
  sub x0, x27, x19
  movz x1, #0
  subs xzr, x19, x27
  ccmp x0, x1, #nZcv, ls
  b.ne label151 ; b label152
block151:
  b label190
block154:
  subs xzr, x2, x27
  b.ls label155 ; b label156
block155:
  ldr x1, [sp, #120]
  mov x21, x27
  b label170
block156:
  cbnz x27, label158 ; b label157
block157:
  movz x3, #8
  b label169
block158:
  subs xzr, x27, #512
  cset x11, lo
  subs xzr, x27, #16384
  cset x12, hi
  orr w12, w11, w12
  uxtb w12, w12
  cbnz x12, label166 ; b label159
block159:
  adds x12, x27, x27
  cset x14, hs
  movz x0, #1
  uxtb w13, w14
  subs wzr, w13, #0
  b.eq label161 ; b label160
block161:
  adds x15, x12, x27
  cset x1, hs
  movz x0, #1
  uxtb w1, w1
  subs wzr, w1, #0
  b.eq label163 ; b label162
block163:
  movz x0, #1
  adds x1, x15, x0
  cset x3, hs
  uxtb w3, w3
  subs wzr, w3, #0
  b.eq label165 ; b label164
block165:
  lsr x3, x1, #1
  b label169
block166:
  adds x3, x27, x27
  cset x1, hs
  movz x0, #1
  uxtb w1, w1
  subs wzr, w1, #0
  b.eq label168 ; b label167
block168:
  b label169
block169:
  subs xzr, x3, x2
  csel x21, x3, x2, hi
  ldr x1, [sp, #120]
  b label170
block170:
  cbnz x1, label172 ; b label171
block171:
  b label175
block172:
  ldr x1, [sp, #120]
  ldr x0, [x1]
  subs xzr, x0, #1
  ccmp x21, x27, #nzCv, eq
  b.ls label173 ; b label174
block173:
  b label178
block174:
  b label175
block175:
  movz x6, #17
  ldr x1, [sp, #112]
  ldr x0, [sp, #96]
  mov x2, x19
  mov x3, x27
  ldr x4, [sp, #120]
  mov x5, x21
  bl 0
  cbnz x0, label177 ; b label176
block177:
  subs xzr, x27, x21
  csel x27, x27, x21, hi
  str x0, [sp, #112]
  b label178
block178:
  cbnz x1, label180 ; b label179
block179:
  mov x21, x1
  ldr x1, [sp, #120]
  b label181
block180:
  ldr x0, [x1]
  add x0, x0, #1
  str x0, [x1]
  mov x21, x1
  ldr x1, [sp, #120]
  b label181
block181:
  ldr x1, [sp, #120]
  cbnz x1, label183 ; b label182
block182:
  b label189
block183:
  ldr x0, [x1]
  sub x0, x0, #1
  str x0, [x1]
  cbnz x0, label184 ; b label185
block184:
  b label189
block185:
  load_ext_name_got x2, User(userextname5)
  ldr x0, [sp, #96]
  blr x2
  cbnz x0, label186 ; b label187
block187:
  b label189
block189:
  str x21, [sp, #120]
  b label190
block190:
  b label191
block191:
  orr x0, x28, x20, LSL 32
  ldr x1, [sp, #112]
  str x0, [x1, x19, LSL #3]
  b label192
block192:
  b label193
block193:
  b label194
block194:
  b label195
block195:
  b label196
block196:
  b label197
block197:
  b label198
block198:
  b label199
block199:
  b label200
block200:
  b label201
block201:
  b label202
block202:
  b label203
block203:
  b label204
block204:
  ldr x13, [sp, #104]
  sub x13, x13, #1
  add x19, x19, #1
  mov x0, x19
  mov x3, x22
  ldr x7, [sp, #128]
  str x13, [sp, #104]
  b label1
block205:
  ldr x13, [sp, #104]
  b label206
block206:
  b label207
block207:
  b label208
block208:
  b label209
block209:
  b label210
block210:
  b label211
block211:
  b label212
block212:
  b label213
block213:
  subs xzr, x0, x24
  b.lo label217 ; b label214
block214:
  b label215
block215:
  b label216
block216:
  movz x8, #0
  b label221
block217:
  b label218
block218:
  b label219
block219:
  ldr w8, [x23, x0, LSL #2]
  b label220
block220:
  b label221
block221:
  b label222
block222:
  b label223
block223:
  b label224
block224:
  b label225
block225:
  b label226
block226:
  b label227
block227:
  b label228
block228:
  b label229
block229:
  b label230
block230:
  b label231
block231:
  b label232
block232:
  b label233
block233:
  b label234
block234:
  b label235
block235:
  b label236
block236:
  b label237
block237:
  lsr x3, x8, #16
  sub x1, x3, #1
  movz x4, #256
  and x5, x3, #4294967295
  sub x3, x4, x5
  and x3, x3, #4294967295
  lsr x6, x3, #29
  and x3, x6, #63
  lsr x1, x1, x3
  ldr x3, [sp, #136]
  subs xzr, x1, x3
  b.lo label241 ; b label238
block238:
  b label239
block239:
  b label240
block240:
  movz x9, #0
  ldr x4, [sp, #144]
  b label245
block241:
  b label242
block242:
  b label243
block243:
  ldr x4, [sp, #144]
  ldrb w9, [x4, x1]
  b label244
block244:
  b label245
block245:
  b label246
block246:
  b label247
block247:
  b label248
block248:
  b label249
block249:
  b label250
block250:
  b label251
block251:
  b label252
block252:
  b label253
block253:
  b label254
block254:
  b label255
block255:
  b label256
block256:
  b label257
block257:
  add x1, x9, x6, LSL 1
  add x6, x1, #515
  subs xzr, x6, x26
  b.lo label261 ; b label258
block258:
  b label259
block259:
  b label260
block260:
  movz x6, #0
  b label265
block261:
  b label262
block262:
  b label263
block263:
  add x6, x1, #515
  ldr w6, [x25, x6, LSL #2]
  b label264
block264:
  b label265
block265:
  b label266
block266:
  b label267
block267:
  b label268
block268:
  b label269
block269:
  b label270
block270:
  b label271
block271:
  b label272
block272:
  b label273
block273:
  b label274
block274:
  b label275
block275:
  subs xzr, x0, x24
  b.lo label279 ; b label276
block276:
  b label277
block277:
  b label278
block278:
  b label283
block279:
  b label280
block280:
  b label281
block281:
  b label282
block282:
  b label283
block283:
  b label284
block284:
  b label285
block285:
  b label286
block286:
  b label287
block287:
  b label288
block288:
  b label289
block289:
  b label290
block290:
  b label291
block291:
  and x8, x8, #65535
  sub x1, x8, #3
  subs xzr, x1, #255
  b.ls label296 ; b label292
block292:
  b label293
block296:
  b label297
block297:
  b label298
block298:
  b label299
block299:
  b label300
block300:
  b label301
block301:
  b label302
block302:
  sub x1, x8, #2
  subs xzr, x2, x1
  b.lo label402 ; b label303
block303:
  b label304
block304:
  b label305
block305:
  b label306
block306:
  b label307
block307:
  b label308
block308:
  b label309
block309:
  b label310
block310:
  b label311
block311:
  b label312
block312:
  sub x1, x8, #2
  subs xzr, x2, x1
  b.lo label323 ; b label313
block313:
  b label314
block314:
  b label315
block315:
  b label316
block316:
  b label317
block317:
  b label318
block318:
  b label319
block319:
  b label320
block320:
  b label321
block321:
  b label322
block322:
  b label419
block323:
  b label324
block324:
  b label325
block325:
  b label326
block326:
  b label327
block327:
  b label328
block328:
  b label329
block329:
  b label330
block330:
  b label331
block331:
  b label332
block332:
  b label333
block333:
  b label334
block334:
  b label335
block335:
  add x1, x2, #3
  ldr w10, [x25, x1, LSL #2]
  b label336
block336:
  b label337
block337:
  mov x9, x2
  b label338
block338:
  b label339
block339:
  b label340
block340:
  b label341
block341:
  b label342
block342:
  b label343
block343:
  b label344
block344:
  b label345
block345:
  b label346
block346:
  b label347
block347:
  b label348
block348:
  b label349
block349:
  b label350
block350:
  b label351
block351:
  b label352
block352:
  b label353
block353:
  b label354
block354:
  b label355
block355:
  b label356
block356:
  b label357
block357:
  b label358
block358:
  add x1, x2, #3
  sub x1, x19, x1
  ldr x11, [sp, #112]
  ldr x11, [x11, x1, LSL #3]
  b label359
block359:
  b label360
block360:
  b label361
block361:
  b label362
block362:
  b label363
block363:
  b label364
block364:
  b label365
block365:
  b label366
block366:
  b label367
block367:
  b label368
block368:
  b label369
block369:
  b label370
block370:
  b label371
block371:
  b label372
block372:
  b label373
block373:
  add x1, x6, x10
  and x1, x1, #4294967295
  and x10, x11, #4294967295
  add x1, x1, x10
  and x1, x1, #4294967295
  subs xzr, x1, x28
  b.lo label377 ; b label374
block374:
  b label375
block375:
  b label376
block376:
  mov x11, x28
  b label379
block377:
  b label378
block378:
  mov x11, x1
  b label379
block379:
  b label380
block380:
  b label381
block381:
  subs xzr, x1, x28
  b.lo label385 ; b label382
block382:
  b label383
block383:
  b label384
block384:
  b label396
block385:
  b label386
block386:
  b label387
block387:
  b label388
block388:
  b label389
block389:
  b label390
block390:
  b label391
block391:
  b label392
block392:
  b label393
block393:
  b label394
block394:
  b label395
block395:
  add x1, x2, #3
  orr x1, x1, x5, LSL 9
  and x20, x1, #4294967295
  b label396
block396:
  b label397
block397:
  b label398
block398:
  b label399
block399:
  b label400
block400:
  b label401
block401:
  mov x28, x11
  add x2, x9, #1
  b label304
block402:
  sub x1, x8, #2
  sub x1, x1, x2
  movn w10, #0
  subs xzr, x1, #16
  b.hs label404 ; b label403
block403:
  b label409
block404:
  dup v1.4s, w28
  movi v28.16b, #255
  and x1, x1, #18446744073709551612
  add x9, x2, x1
  mov v0.16b, v28.16b
  b label405
block405:
  subs xzr, x2, x9
  b.lo label427 ; b label406
block406:
  sub x2, x8, #2
  ext v31.16b, v1.16b, v1.16b, #8
  umin v31.4s, v1.4s, v31.4s
  rev64 v2.4s, v31.4s
  umin v31.4s, v31.4s, v2.4s
  mov w28, v31.s[0]
  cmeq v30.4s, v1.4s, v31.4s
  bsl v30.16b, v30.16b, v0.16b, v28.16b
  ext v31.16b, v30.16b, v30.16b, #8
  umin v31.4s, v30.4s, v31.4s
  rev64 v0.4s, v31.4s
  umin v31.4s, v31.4s, v0.4s
  mov w10, v31.s[0]
  subs xzr, x9, x2
  b.lo label407 ; b label408
block407:
  mov x2, x9
  b label409
block408:
  mov x11, x28
  b label413
block409:
  add x9, x25, #12
  sub x1, x19, #3
  ldr x14, [sp, #112]
  add x12, x14, x1, LSL 3
  b label410
block410:
  ldr w11, [x9, x2, LSL #2]
  sub x1, x12, x2, LSL 3
  ldr w15, [x1]
  add x14, x2, #1
  sub x1, x8, #2
  add w11, w6, w11
  add w15, w11, w15
  subs wzr, w15, w28
  csel x11, x15, x28, lo
  subs wzr, w15, w28
  csel x10, x2, x10, lo
  subs xzr, x14, x1
  b.lo label411 ; b label412
block411:
  mov x2, x14
  mov x28, x11
  b label410
block412:
  b label413
block413:
  movn w1, #0
  subs wzr, w10, w1
  b.ne label415 ; b label414
block414:
  b label418
block415:
  b label416
block416:
  b label417
block417:
  mov w1, w10
  add x1, x1, #3
  orr x1, x1, x5, LSL 9
  and x20, x1, #4294967295
  b label418
block418:
  mov w28, w11
  sub x2, x8, #2
  b label419
block419:
  b label420
block420:
  b label421
block421:
  b label422
block422:
  b label423
block423:
  b label424
block424:
  b label425
block425:
  b label426
block426:
  add x0, x0, #1
  str x13, [sp, #104]
  str x3, [sp, #136]
  str x4, [sp, #144]
  b label118
block427:
  add x1, x25, #12
  lsl x10, x2, #2
  ldr q2, [x1, x10]
  sub x1, x19, #3
  ldr x10, [sp, #112]
  add x1, x10, x1, LSL 3
  sub x1, x1, x2, LSL 3
  ldr q30, [x1, #-24]
  ldr q31, [x1, #-8]
  add x10, x2, #4
  dup v3.4s, w6
  add v2.4s, v3.4s, v2.4s
  ldr q3, [const(1)]
  tbl v3.16b, { v30.16b, v31.16b }, v3.16b
  add v3.4s, v2.4s, v3.4s
  umin v2.4s, v3.4s, v1.4s
  cmhi v1.4s, v1.4s, v3.4s
  dup v3.4s, w2
  ldr q4, [const(0)]
  add v3.4s, v3.4s, v4.4s
  bsl v1.16b, v1.16b, v3.16b, v0.16b
  mov x2, x10
  mov v0.16b, v1.16b
  mov v1.16b, v2.16b
  b label405
block152:
  movz x0, #1
  adds x2, x19, x0
  cset x3, hs
  uxtb w3, w3
  subs wzr, w3, #0
  b.eq label154 ; b label153
block153:
  b label188
block160:
  b label188
block162:
  b label188
block164:
  b label188
block167:
  b label188
block176:
  mov x0, x1
  b label188
block186:
  b label188
block188:
  movz x1, #3396
  str x1, [x22]
  b label294
block293:
  movz x0, #3238
  str x0, [x22]
  movz x0, #9
  b label294
block294:
  b label295
block295:
  ldr x1, [x22]
  add sp, sp, #160
  ldp x19, x20, [sp], #16
  ldp x21, x22, [sp], #16
  ldp x23, x24, [sp], #16
  ldp x25, x26, [sp], #16
  ldp x27, x28, [sp], #16
  ldp fp, lr, [sp], #16
  retabsp
