//! Forward the last initialized cell of an exclusively appended U64 vector.
//! The enclosing append-run proof fixes the read's (length - 1) geometry.
//! The compact caller additionally admits only this one append mutation; every
//! ordinary, literal-run and paired-run store is recorded by its own emitter.
use cranelift_codegen::ir::{
    Block, Function, Inst, InstBuilder, InstructionData as Data, Opcode, Value, condcodes::IntCC,
    types,
};
use cranelift_codegen::{
    Context,
    cursor::{Cursor, FuncCursor},
    flowgraph::ControlFlowGraph,
};
use std::collections::{BTreeMap, BTreeSet};

#[derive(Clone)]
pub(in crate::native_artifact) struct Hint {
    read: Inst,
    stores: Vec<Inst>,
}
impl Hint {
    pub(super) fn new(read: Inst, stores: Vec<Inst>) -> Self {
        Self { read, stores }
    }
    pub(in crate::native_artifact) fn apply(
        &self,
        context: &mut Context,
        loads: &BTreeMap<Value, (Inst, usize)>,
        output_word: usize,
    ) -> Result<(usize, usize), &'static str> {
        // Address/CFG rewrites can duplicate a source store after recording.
        // Rebuild the complete set from the admitted current packet identity.
        let f = &context.func;
        let entry = f.layout.entry_block().ok_or("missing entry")?;
        let packet = f.dfg.block_params(entry);
        if packet.len() != 3 {
            return Err("unexpected private packet signature");
        }
        let mut stores = Vec::new();
        for block in f.layout.blocks() {
            for inst in f.layout.block_insts(block) {
                if let Data::Store { .. } = f.dfg.insts[inst] {
                    let [value, address] = *f.dfg.inst_args(inst) else {
                        return Err("unsupported store");
                    };
                    let root = origin(
                        f,
                        &context.cfg,
                        loads,
                        output_word,
                        [packet[1], packet[2]],
                        address,
                        0,
                    );
                    match root {
                        Some(Origin::Array) if f.dfg.value_type(value) == types::I64 => {
                            stores.push(inst)
                        }
                        Some(Origin::Packet | Origin::Stack) => {}
                        _ => return Err("unclassified current write"),
                    }
                }
            }
        }
        if self.stores.is_empty() {
            return Err("no original append lineage");
        }
        forward(context, self.read, &stores)
    }
}

#[derive(Clone, Copy)]
enum Origin {
    Array,
    Packet,
    Stack,
}
fn origin(
    f: &Function,
    cfg: &ControlFlowGraph,
    loads: &BTreeMap<Value, (Inst, usize)>,
    word: usize,
    packets: [Value; 2],
    value: Value,
    depth: usize,
) -> Option<Origin> {
    if depth > 16 {
        return None;
    }
    let value = f.dfg.resolve_aliases(value);
    if super::super::cfg_cleanup::composed_reads::packet_word(f, cfg, loads, value) == Some(word) {
        return Some(Origin::Array);
    }
    if packets.contains(&value) {
        return Some(Origin::Packet);
    }
    let cranelift_codegen::ir::ValueDef::Result(inst, 0) = f.dfg.value_def(value) else {
        return None;
    };
    match f.dfg.insts[inst] {
        Data::StackLoad { .. } => None,
        Data::StackAddr { .. } => Some(Origin::Stack),
        Data::Binary {
            opcode: Opcode::Iadd,
            args: [a, b],
        } => origin(f, cfg, loads, word, packets, a, depth + 1)
            .or_else(|| origin(f, cfg, loads, word, packets, b, depth + 1)),
        Data::Binary {
            opcode: Opcode::Isub,
            args: [a, _],
        }
        | Data::BinaryImm64 {
            opcode: Opcode::IaddImm,
            arg: a,
            ..
        } => origin(f, cfg, loads, word, packets, a, depth + 1),
        _ => None,
    }
}

struct State<'a> {
    cfg: &'a ControlFlowGraph,
    definitions: BTreeMap<Block, Value>,
    incoming: BTreeMap<Block, (Value, Value)>,
    entry: Block,
    zero: Value,
    one: Value,
    reachable: BTreeSet<Block>,
}
impl State<'_> {
    fn end(&mut self, f: &mut Function, block: Block) -> (Value, Value) {
        if let Some(&value) = self.definitions.get(&block) {
            (value, self.one)
        } else {
            self.start(f, block)
        }
    }
    fn start(&mut self, f: &mut Function, block: Block) -> (Value, Value) {
        if block == self.entry || !self.reachable.contains(&block) {
            return (self.zero, self.zero);
        }
        if let Some(&values) = self.incoming.get(&block) {
            return values;
        }
        let edges = self
            .cfg
            .pred_iter(block)
            .map(|edge| (edge.block, edge.inst))
            .collect::<BTreeSet<_>>();
        if edges.len() == 1
            && let Some(&(predecessor, _)) = edges.first()
            && predecessor != block
        {
            let values = self.end(f, predecessor);
            self.incoming.insert(block, values);
            return values;
        }
        let value = f.dfg.append_block_param(block, types::I64);
        let valid = f.dfg.append_block_param(block, types::I64);
        self.incoming.insert(block, (value, valid));
        for (predecessor, inst) in edges {
            let (value, valid) = self.end(f, predecessor);
            let dfg = &mut f.dfg;
            for call in dfg.insts[inst]
                .branch_destination_mut(&mut dfg.jump_tables, &mut dfg.exception_tables)
            {
                if call.block(&dfg.value_lists) == block {
                    call.append_argument(value, &mut dfg.value_lists);
                    call.append_argument(valid, &mut dfg.value_lists);
                }
            }
        }
        (value, valid)
    }
}

pub(super) fn forward(
    context: &mut Context,
    read: Inst,
    stores: &[Inst],
) -> Result<(usize, usize), &'static str> {
    let f = &mut context.func;
    let blocks = f.layout.blocks().collect::<Vec<_>>();
    if blocks.len() > 1024 || stores.is_empty() {
        return Err("append forwarding analysis limit");
    }
    let Data::Load {
        opcode: opcode @ (Opcode::Load | Opcode::Uload32),
        flags: read_flags,
        offset: read_offset,
        ..
    } = f.dfg.insts[read]
    else {
        return Err("previous word is not a plain load");
    };
    let old = f.dfg.first_result(read);
    let ty = f.dfg.value_type(old);
    if (ty == types::I32 || opcode == Opcode::Uload32)
        && read_flags.endianness(cranelift_codegen::ir::Endianness::Little)
            != cranelift_codegen::ir::Endianness::Little
    {
        return Err("narrow forwarding requires little-endian low words");
    }
    if !matches!(ty, types::I32 | types::I64) || i32::from(read_offset) != 0 {
        return Err("previous word width or displacement differs");
    }
    let known = stores.iter().copied().collect::<BTreeSet<_>>();
    for &store in stores {
        let Data::Store { flags, .. } = f.dfg.insts[store] else {
            return Err("append definition is not a store");
        };
        if f.dfg.value_type(f.dfg.inst_args(store)[0]) != types::I64
            || flags.endianness(cranelift_codegen::ir::Endianness::Little)
                != read_flags.endianness(cranelift_codegen::ir::Endianness::Little)
        {
            return Err("append word representation differs");
        }
    }
    let at = f
        .layout
        .inst_block(read)
        .ok_or("previous load has no block")?;
    let after = f
        .layout
        .next_inst(read)
        .ok_or("previous load has no continuation")?;
    let entry = f.layout.entry_block().ok_or("missing entry")?;
    let first = f.layout.first_inst(entry).ok_or("empty entry")?;
    let mut definitions = BTreeMap::new();
    let mut preceding = None;
    for &block in &blocks {
        for inst in f.layout.block_insts(block) {
            if block == at && inst == read {
                preceding = definitions.get(&block).copied();
            }
            if known.contains(&inst) {
                definitions.insert(block, f.dfg.inst_args(inst)[0]);
            }
        }
    }
    let mut c = FuncCursor::new(f).at_inst(first);
    let zero = c.ins().iconst(types::I64, 0);
    let one = c.ins().iconst(types::I64, 1);
    let mut state = State {
        cfg: &context.cfg,
        definitions,
        incoming: BTreeMap::new(),
        entry,
        zero,
        one,
        reachable: blocks
            .iter()
            .copied()
            .filter(|&b| context.domtree.is_reachable(b))
            .collect(),
    };
    let (cached, valid) = if let Some(value) = preceding {
        (value, one)
    } else {
        state.start(c.func, at)
    };
    let count = state.incoming.len();
    let join = c.func.dfg.make_block();
    c.func.layout.split_block(join, after);
    let loaded = c.func.dfg.append_block_param(join, ty);
    let miss = c.func.dfg.make_block();
    c.func.layout.append_block(miss);
    c.func.layout.remove_inst(read);
    c.func.layout.append_inst(read, miss);
    c.goto_bottom(at);
    let cached = if ty == types::I32 {
        c.ins().ireduce(types::I32, cached)
    } else if opcode == Opcode::Uload32 {
        let low = c.ins().ireduce(types::I32, cached);
        c.ins().uextend(types::I64, low)
    } else {
        cached
    };
    let present = c.ins().icmp_imm(IntCC::NotEqual, valid, 0);
    c.ins().brif(present, join, &[cached.into()], miss, &[]);
    c.goto_bottom(miss);
    let miss_jump = c.ins().jump(join, &[old.into()]);
    let insts = c
        .func
        .layout
        .blocks()
        .flat_map(|b| c.func.layout.block_insts(b))
        .collect::<Vec<_>>();
    for inst in insts {
        if inst != miss_jump {
            c.func
                .dfg
                .map_inst_values(inst, |v| if v == old { loaded } else { v });
        }
    }
    context.compute_cfg();
    context.compute_domtree();
    Ok((count, stores.len()))
}
