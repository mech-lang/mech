//! A bounded lexicographic U32 key for cost and original source ordinal.
use super::{cost::Inputs, emit, *};
use crate::native_artifact::codegen::common::ssa_words::Words;
use cranelift_codegen::ir::{Block, InstBuilder, Value, condcodes::IntCC, types};
use cranelift_frontend::FunctionBuilder;

pub(super) const INDEX_BITS: u32 = 9;
pub(super) const INDEX_MASK: u32 = (1 << INDEX_BITS) - 1;
pub(super) const COST_LIMIT: u32 = u32::MAX >> INDEX_BITS;

pub(super) fn cost_key(b: &mut FunctionBuilder<'_>, mut cost: Value, ordinal: Value) -> Value {
    // Exact saturating doubling is ordinary unsigned vector IR. The backend
    // can combine the chain into a saturating immediate shift. Large costs
    // become U32::MAX and cannot beat the admitted incoming best key.
    for _ in 0..INDEX_BITS {
        cost = b.ins().uadd_sat(cost, cost);
    }
    b.ins().bor(cost, ordinal)
}

pub(super) fn emit(
    b: &mut FunctionBuilder<'_>,
    words: &Words,
    proof: &Proof,
    shadow: usize,
    reduction: &Reduction,
    inputs: &Inputs,
    front: Window,
    back: Window,
    offset: &Item,
    start: Value,
    stop: Value,
    best: Value,
    old_item: Value,
    scalar_body: Block,
    scalar_finish: Block,
    ordinary: Block,
) {
    let declined = b.create_block();
    let eligible = b.create_block();
    let vector = b.create_block();
    let remaining = b.ins().isub(stop, start);
    let minimum = match std::env::var("MECH_ORDERED_PACKED_VECTOR_MINIMUM").as_deref() {
        Ok("8") => 8,
        Ok("12") => 12,
        Ok("16") => 16,
        _ => 4,
    };
    let enough = b
        .ins()
        .icmp_imm(IntCC::UnsignedGreaterThanOrEqual, remaining, minimum);
    b.ins().brif(enough, eligible, &[], declined, &[]);
    b.switch_to_block(eligible);
    let count = b
        .ins()
        .icmp_imm(IntCC::UnsignedLessThanOrEqual, stop, i64::from(INDEX_MASK));
    let bounded = b
        .ins()
        .icmp_imm(IntCC::UnsignedLessThanOrEqual, best, i64::from(COST_LIMIT));
    let valid = b.ins().band(count, bounded);
    b.ins().brif(valid, vector, &[], declined, &[]);
    b.switch_to_block(vector);
    let mut inputs = inputs.clone();
    inputs.prepare_vector_words(b);
    let prefix = b.ins().band_imm(remaining, -4);
    let end = b.ins().iadd(start, prefix);
    let initial = b.ins().ishl_imm(best, i64::from(INDEX_BITS));
    let initial = b.ins().splat(types::I32X4, initial);
    let lanes = super::cost::constant(b, [1, 2, 3, 4]);
    let header = b.create_block();
    b.append_block_param(header, types::I64);
    b.append_block_param(header, types::I32X4);
    let finish = b.create_block();
    b.append_block_param(finish, types::I32X4);
    let pointers = std::env::var_os("MECH_ORDERED_PACKED_VECTOR_POINTERS").is_some();
    let windows = if pointers {
        reduction.reads.as_slice()
    } else {
        &[]
    };
    let mut args = vec![start.into(), initial.into()];
    for &window in windows {
        b.append_block_param(header, types::I64);
        args.push(inputs.pointer(b, proof, window, start).into());
    }
    b.ins().jump(header, &args);
    b.switch_to_block(header);
    let params = b.block_params(header).to_vec();
    let k = params[0];
    let k32 = b.ins().ireduce(types::I32, k);
    let index = b.ins().splat(types::I32X4, k32);
    let ordinal = b.ins().iadd(index, lanes);
    let addresses = windows
        .iter()
        .enumerate()
        .map(|(i, &w)| (w, params[2 + i]))
        .collect::<Vec<_>>();
    let cost = if addresses.is_empty() {
        inputs.emit(b, proof, &reduction.cost, k, index)
    } else {
        inputs.emit_with_pointers(b, proof, &reduction.cost, k, index, &addresses)
    };
    let key = cost_key(b, cost, ordinal);
    let key = b.ins().umin(key, params[1]);
    let next = b.ins().iadd_imm(k, 4);
    let mut args = vec![next.into(), key.into()];
    for (window, pointer) in addresses {
        let stride = 4 * i64::from(proof.arrays[window.array].width);
        args.push(
            b.ins()
                .iadd_imm(pointer, if window.reverse { -stride } else { stride })
                .into(),
        );
    }
    let more = b.ins().icmp(IntCC::UnsignedLessThan, next, end);
    b.ins().brif(more, header, &args, finish, &[key.into()]);
    b.switch_to_block(finish);
    // Initial ordinal zero wins an equal incoming best. All real ordinals are
    // k+1 in 1..511, so unsigned key order is exactly (cost, source order).
    let minimum = emit::minimum_word(b, b.block_params(finish)[0]);
    let ordinal = b.ins().band_imm(minimum, i64::from(INDEX_MASK));
    let cost = b.ins().ushr_imm(minimum, i64::from(INDEX_BITS));
    let changed = b.ins().icmp_imm(IntCC::NotEqual, ordinal, 0);
    let winner = b.ins().iadd_imm(ordinal, -1);
    let biased = b.ins().iadd_imm(winner, front.delta as i64);
    let other = emit::emit_item_low32(b, words, proof, shadow, offset, start, ordinary);
    let selected = b.ins().bor(biased, other);
    let selected = b.ins().uextend(types::I64, selected);
    let item = b.ins().select(changed, selected, old_item);
    let more = b.ins().icmp(IntCC::UnsignedLessThan, end, stop);
    let remainder = b.create_block();
    b.ins().brif(
        more,
        remainder,
        &[],
        scalar_finish,
        &[cost.into(), item.into()],
    );
    b.switch_to_block(remainder);
    let previous = b.ins().iadd_imm(end, -1);
    let reverse = inputs.pointer(b, proof, back, previous);
    let index = b.ins().iadd_imm(end, front.delta as i64);
    let left = b.ins().isub(stop, end);
    b.ins().jump(
        scalar_body,
        &[
            index.into(),
            cost.into(),
            item.into(),
            reverse.into(),
            left.into(),
        ],
    );
    b.switch_to_block(declined);
}
