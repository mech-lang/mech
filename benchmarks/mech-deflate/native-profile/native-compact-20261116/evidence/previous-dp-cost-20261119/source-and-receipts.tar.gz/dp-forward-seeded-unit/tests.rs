mod previous {
// Forward the last initialized cell of an exclusively appended U64 vector.
// The enclosing append-run proof fixes the read's (length - 1) geometry.
// The compact caller additionally admits only this one append mutation; every
// ordinary, literal-run and paired-run store is recorded by its own emitter.
use cranelift_codegen::ir::{
    Block, Function, Inst, InstBuilder, InstructionData as Data, MemFlags, Opcode, Value,
    condcodes::IntCC, types,
};
use cranelift_codegen::{
    Context,
    cursor::{Cursor, FuncCursor},
    flowgraph::ControlFlowGraph,
};
use std::collections::{BTreeMap, BTreeSet};

struct State<'a> {
    cfg: &'a ControlFlowGraph,
    definitions: BTreeMap<Block, Value>,
    incoming: BTreeMap<Block, (Value, Value)>,
    entry: Block,
    zero: Value,
    one: Value,
    initial: Value,
    seeded: bool,
    reachable: BTreeSet<Block>,
}
impl State<'_> {
    fn end(&mut self, f: &mut Function, block: Block) -> (Value, Value) {
        if let Some(&value) = self.definitions.get(&block) {
            (value, self.one)
        } else {
            self.start(f, block)
        }
    }
    fn start(&mut self, f: &mut Function, block: Block) -> (Value, Value) {
        if block == self.entry {
            return (self.initial, if self.seeded { self.one } else { self.zero });
        }
        if !self.reachable.contains(&block) {
            return (self.zero, self.zero);
        }
        if let Some(&values) = self.incoming.get(&block) {
            return values;
        }
        let edges = self
            .cfg
            .pred_iter(block)
            .map(|edge| (edge.block, edge.inst))
            .collect::<BTreeSet<_>>();
        if edges.len() == 1
            && let Some(&(predecessor, _)) = edges.first()
            && predecessor != block
        {
            let values = self.end(f, predecessor);
            self.incoming.insert(block, values);
            return values;
        }
        let value = f.dfg.append_block_param(block, types::I64);
        let valid = if self.seeded {
            self.one
        } else {
            f.dfg.append_block_param(block, types::I64)
        };
        self.incoming.insert(block, (value, valid));
        for (predecessor, inst) in edges {
            let (value, valid) = self.end(f, predecessor);
            let dfg = &mut f.dfg;
            for call in dfg.insts[inst]
                .branch_destination_mut(&mut dfg.jump_tables, &mut dfg.exception_tables)
            {
                if call.block(&dfg.value_lists) == block {
                    call.append_argument(value, &mut dfg.value_lists);
                    if !self.seeded {
                        call.append_argument(valid, &mut dfg.value_lists);
                    }
                }
            }
        }
        (value, valid)
    }
}

pub(super) fn forward(
    context: &mut Context,
    read: Inst,
    stores: &[Inst],
    seed: Option<(Value, Value)>,
) -> Result<(usize, usize), &'static str> {
    let f = &mut context.func;
    let mut blocks = f.layout.blocks().collect::<Vec<_>>();
    if blocks.len() > 1024 || stores.is_empty() {
        return Err("append forwarding analysis limit");
    }
    let Data::Load {
        opcode: opcode @ (Opcode::Load | Opcode::Uload32),
        flags: read_flags,
        offset: read_offset,
        ..
    } = f.dfg.insts[read]
    else {
        return Err("previous word is not a plain load");
    };
    let old = f.dfg.first_result(read);
    let ty = f.dfg.value_type(old);
    if (ty == types::I32 || opcode == Opcode::Uload32)
        && read_flags.endianness(cranelift_codegen::ir::Endianness::Little)
            != cranelift_codegen::ir::Endianness::Little
    {
        return Err("narrow forwarding requires little-endian low words");
    }
    if !matches!(ty, types::I32 | types::I64) || i32::from(read_offset) != 0 {
        return Err("previous word width or displacement differs");
    }
    let known = stores.iter().copied().collect::<BTreeSet<_>>();
    for &store in stores {
        let Data::Store { flags, .. } = f.dfg.insts[store] else {
            return Err("append definition is not a store");
        };
        if f.dfg.value_type(f.dfg.inst_args(store)[0]) != types::I64
            || flags.endianness(cranelift_codegen::ir::Endianness::Little)
                != read_flags.endianness(cranelift_codegen::ir::Endianness::Little)
        {
            return Err("append word representation differs");
        }
    }
    let at = f
        .layout
        .inst_block(read)
        .ok_or("previous load has no block")?;
    let after = f
        .layout
        .next_inst(read)
        .ok_or("previous load has no continuation")?;
    let mut entry = f.layout.entry_block().ok_or("missing entry")?;
    let first = f.layout.first_inst(entry).ok_or("empty entry")?;
    if let Some((pointer, length)) = seed {
        if at == entry
            || stores
                .iter()
                .any(|&inst| f.layout.inst_block(inst) == Some(entry))
            || [pointer, length].iter().any(|&value| {
                f.dfg.value_type(value) != types::I64
                    || match f.dfg.value_def(value) {
                        cranelift_codegen::ir::ValueDef::Result(inst, _) => {
                            f.layout.inst_block(inst) != Some(entry)
                        }
                        cranelift_codegen::ir::ValueDef::Param(block, _) => block != entry,
                        _ => true,
                    }
            })
        {
            return Err("entry seed does not precede the append recurrence");
        }
    }
    let mut definitions = BTreeMap::new();
    let mut preceding = None;
    for &block in &blocks {
        for inst in f.layout.block_insts(block) {
            if block == at && inst == read {
                preceding = definitions.get(&block).copied();
            }
            if known.contains(&inst) {
                definitions.insert(block, f.dfg.inst_args(inst)[0]);
            }
        }
    }
    let mut c = FuncCursor::new(f).at_inst(first);
    let zero = c.ins().iconst(types::I64, 0);
    let one = c.ins().iconst(types::I64, 1);
    let initial = if let Some((pointer, length)) = seed {
        // The sealed NoGrowth caller owns an initialized U64 view and admits
        // its unchanged geometry. A nonempty entry view therefore permits one
        // pure read here, even when the source loop has zero iterations. Empty
        // views take no read; source nonempty/error checks remain in place.
        let terminator = c.func.layout.last_inst(entry).expect("nonempty entry");
        let resume = c.func.dfg.make_block();
        c.func.layout.split_block(resume, terminator);
        let load = c.func.dfg.make_block();
        c.func.layout.append_block(load);
        let join = c.func.dfg.make_block();
        c.func.layout.append_block(join);
        let value = c.func.dfg.append_block_param(join, types::I64);
        c.goto_bottom(entry);
        let nonempty = c.ins().icmp_imm(IntCC::NotEqual, length, 0);
        c.ins().brif(nonempty, load, &[], join, &[zero.into()]);
        c.goto_bottom(load);
        let last = c.ins().iadd_imm(length, -1);
        let displacement = c.ins().ishl_imm(last, 3);
        let address = c.ins().iadd(pointer, displacement);
        // Mutable element memory: no readonly, can_move or alignment claim.
        let flags = MemFlags::new()
            .with_notrap()
            .with_endianness(read_flags.endianness(cranelift_codegen::ir::Endianness::Little));
        let loaded = c.ins().load(types::I64, flags, address, 0);
        c.ins().jump(join, &[loaded.into()]);
        c.goto_bottom(join);
        c.ins().jump(resume, &[]);
        entry = resume;
        blocks = c.func.layout.blocks().collect();
        value
    } else {
        zero
    };
    context.compute_cfg();
    context.compute_domtree();
    let mut c = FuncCursor::new(&mut context.func);
    let mut state = State {
        cfg: &context.cfg,
        definitions,
        incoming: BTreeMap::new(),
        entry,
        zero,
        one,
        initial,
        seeded: seed.is_some(),
        reachable: blocks
            .iter()
            .copied()
            .filter(|&b| context.domtree.is_reachable(b))
            .collect(),
    };
    let (cached, valid) = if let Some(value) = preceding {
        (value, one)
    } else {
        state.start(c.func, at)
    };
    let count = state.incoming.len();
    if seed.is_some() {
        c.goto_inst(read);
        let cached = if ty == types::I32 {
            c.ins().ireduce(types::I32, cached)
        } else if opcode == Opcode::Uload32 {
            let low = c.ins().ireduce(types::I32, cached);
            c.ins().uextend(types::I64, low)
        } else {
            cached
        };
        c.func.layout.remove_inst(read);
        c.func.dfg.clear_results(read);
        c.func.dfg.change_to_alias(old, cached);
        context.compute_cfg();
        context.compute_domtree();
        return Ok((count, stores.len()));
    }
    let join = c.func.dfg.make_block();
    c.func.layout.split_block(join, after);
    let loaded = c.func.dfg.append_block_param(join, ty);
    let miss = c.func.dfg.make_block();
    c.func.layout.append_block(miss);
    c.func.layout.remove_inst(read);
    c.func.layout.append_inst(read, miss);
    c.goto_bottom(at);
    let cached = if ty == types::I32 {
        c.ins().ireduce(types::I32, cached)
    } else if opcode == Opcode::Uload32 {
        let low = c.ins().ireduce(types::I32, cached);
        c.ins().uextend(types::I64, low)
    } else {
        cached
    };
    let present = c.ins().icmp_imm(IntCC::NotEqual, valid, 0);
    c.ins().brif(present, join, &[cached.into()], miss, &[]);
    c.goto_bottom(miss);
    let miss_jump = c.ins().jump(join, &[old.into()]);
    let insts = c
        .func
        .layout
        .blocks()
        .flat_map(|b| c.func.layout.block_insts(b))
        .collect::<Vec<_>>();
    for inst in insts {
        if inst != miss_jump {
            c.func
                .dfg
                .map_inst_values(inst, |v| if v == old { loaded } else { v });
        }
    }
    context.compute_cfg();
    context.compute_domtree();
    Ok((count, stores.len()))
}

}

use cranelift_codegen::{ir::{AbiParam,InstBuilder,MemFlags,condcodes::IntCC,types},Context};
use cranelift_frontend::{FunctionBuilder,FunctionBuilderContext};
use cranelift_jit::{JITBuilder,JITModule};
use cranelift_module::{Linkage,Module,default_libcall_names};
fn make(mode:u8,kind:u8)->(JITModule,unsafe extern "C" fn(*mut u64,u64,*const u32,u64)->u64) {
 let mut module=JITModule::new(JITBuilder::with_flags(&[("opt_level","speed"),("enable_verifier","true")],default_libcall_names()).unwrap());let mut c=module.make_context();
 c.func.signature.params=vec![AbiParam::new(types::I64);4];c.func.signature.returns=vec![AbiParam::new(types::I64)];
 let mut fc=FunctionBuilderContext::new();let mut b=FunctionBuilder::new(&mut c.func,&mut fc);
 let entry=b.create_block();let header=b.create_block();let check=b.create_block();let read_block=b.create_block();let even=b.create_block();let odd=b.create_block();let out=b.create_block();let bad=b.create_block();
 b.append_block_params_for_function_params(entry);for _ in 0..2{b.append_block_param(header,types::I64);}b.append_block_param(out,types::I64);
 b.switch_to_block(entry);let args=b.block_params(entry).to_vec();let zero=b.ins().iconst(types::I64,0);b.ins().jump(header,&[zero.into(),args[1].into()]);
 b.switch_to_block(header);let state=b.block_params(header).to_vec();let more=b.ins().icmp(IntCC::UnsignedLessThan,state[0],args[3]);b.ins().brif(more,check,&[],out,&[state[1].into()]);
 b.switch_to_block(check);let nonempty=b.ins().icmp_imm(IntCC::NotEqual,state[1],0);b.ins().brif(nonempty,read_block,&[],bad,&[]);
 b.switch_to_block(bad);let error=b.ins().iconst(types::I64,-1);b.ins().return_(&[error]);
 b.switch_to_block(read_block);let prior=b.ins().iadd_imm(state[1],-1);let at=b.ins().ishl_imm(prior,3);let at=b.ins().iadd(args[0],at);let physical=match kind {0=>b.ins().load(types::I64,MemFlags::new(),at,0),1=>b.ins().uload32(MemFlags::new(),at,0),_=>b.ins().load(types::I32,MemFlags::new(),at,0)};let read_inst=b.func.dfg.value_def(physical).inst().unwrap();let read=if kind==2{b.ins().uextend(types::I64,physical)}else{physical};
 let at=b.ins().ishl_imm(state[0],2);let at=b.ins().iadd(args[2],at);let price=b.ins().uload32(MemFlags::new(),at,0);let low=b.ins().ireduce(types::I32,read);let price=b.ins().ireduce(types::I32,price);let low=b.ins().iadd(low,price);let low=b.ins().uextend(types::I64,low);
 let high=b.ins().ushr_imm(read,32);let high=b.ins().bxor(high,state[0]);let high=b.ins().ishl_imm(high,32);let word=b.ins().bor(low,high);
 let at=b.ins().ishl_imm(state[1],3);let at=b.ins().iadd(args[0],at);let next=b.ins().iadd_imm(state[0],1);let length=b.ins().iadd_imm(state[1],1);let odd_flag=b.ins().band_imm(state[0],1);b.ins().brif(odd_flag,odd,&[],even,&[]);
 b.switch_to_block(even);let a=b.ins().store(MemFlags::new(),word,at,0);b.ins().jump(header,&[next.into(),length.into()]);
 b.switch_to_block(odd);let word=b.ins().bxor_imm(word,0x1234_5678_0000_0000);let d=b.ins().store(MemFlags::new(),word,at,0);b.ins().jump(header,&[next.into(),length.into()]);
 b.switch_to_block(out);let result=b.block_params(out)[0];b.ins().return_(&[result]);b.seal_all_blocks();b.finalize();
 c.compute_cfg();c.compute_domtree();if mode>0 {assert!(previous::forward(&mut c,read_inst,&[a,d],if mode==2{Some((args[0],args[1]))}else{None}).is_ok());}
 let id=module.declare_function("append_previous",Linkage::Local,&c.func.signature).unwrap();module.define_function(id,&mut c).unwrap();module.finalize_definitions().unwrap();
 // SAFETY: The live finalized module owns this exact C signature.
 let call=unsafe{std::mem::transmute(module.get_finalized_function(id))};(module,call)
}
#[test]
fn forward_last_append_preserves_initial_word_wraps_branches_and_resets() {
 let mut tested=0;for mode in 1..=2 {for kind in 0..3 {let (_a,a)=make(0,kind);let (_b,b)=make(mode,kind);
 for seed in [0u64,1,u64::MAX,0x8000_0000_8000_0000,0x0123_4567_ffff_ffff] {
  for initial in [0usize,1,2,4] {
   for count in [0usize,1,2,3,7,16] {
    for price in [0u32,1,0x8000_0000,u32::MAX] {
     let mut before=[0xfeed_face_dead_beefu64;32];before[..initial].fill(seed);let mut after=before;let prices=std::array::from_fn::<_,16,_>(|i|price.wrapping_add(i as u32));
     let x=unsafe{a(before.as_mut_ptr(),initial as u64,prices.as_ptr(),count as u64)};
     let y=unsafe{b(after.as_mut_ptr(),initial as u64,prices.as_ptr(),count as u64)};
     assert_eq!(x,y);assert_eq!(before,after);assert_eq!(x,if initial==0&&count>0{u64::MAX}else{(initial+count) as u64});tested+=1;
    }
   }
  }
 }
 }} assert_eq!(tested,2880);
}
