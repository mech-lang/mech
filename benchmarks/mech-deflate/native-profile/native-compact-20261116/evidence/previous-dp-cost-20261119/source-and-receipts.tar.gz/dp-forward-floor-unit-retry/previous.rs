//! Forward the last initialized cell of an exclusively appended U64 vector.
//! The enclosing append-run proof fixes the read's (length - 1) geometry.
//! The compact caller additionally admits only this one append mutation; every
//! ordinary, literal-run and paired-run store is recorded by its own emitter.
use cranelift_codegen::ir::{
    Block, Function, Inst, InstBuilder, InstructionData as Data, MemFlags, Opcode, Value,
    condcodes::IntCC, types,
};
use cranelift_codegen::{
    Context,
    cursor::{Cursor, FuncCursor},
    flowgraph::ControlFlowGraph,
};
use std::collections::{BTreeMap, BTreeSet};
struct State<'a> {
    cfg: &'a ControlFlowGraph,
    definitions: BTreeMap<Block, Value>,
    incoming: BTreeMap<Block, (Value, Value)>,
    entry: Block,
    zero: Value,
    one: Value,
    initial: Value,
    seeded: bool,
    reachable: BTreeSet<Block>,
}
impl State<'_> {
    fn end(&mut self, f: &mut Function, block: Block) -> (Value, Value) {
        if let Some(&value) = self.definitions.get(&block) {
            (value, self.one)
        } else {
            self.start(f, block)
        }
    }
    fn start(&mut self, f: &mut Function, block: Block) -> (Value, Value) {
        if block == self.entry {
            return (self.initial, if self.seeded { self.one } else { self.zero });
        }
        if !self.reachable.contains(&block) {
            return (self.zero, self.zero);
        }
        if let Some(&values) = self.incoming.get(&block) {
            return values;
        }
        let edges = self
            .cfg
            .pred_iter(block)
            .map(|edge| (edge.block, edge.inst))
            .collect::<BTreeSet<_>>();
        if edges.len() == 1
            && let Some(&(predecessor, _)) = edges.first()
            && predecessor != block
        {
            let values = self.end(f, predecessor);
            self.incoming.insert(block, values);
            return values;
        }
        let value = f.dfg.append_block_param(block, types::I64);
        let valid = if self.seeded {
            self.one
        } else {
            f.dfg.append_block_param(block, types::I64)
        };
        self.incoming.insert(block, (value, valid));
        for (predecessor, inst) in edges {
            let (value, valid) = self.end(f, predecessor);
            let dfg = &mut f.dfg;
            for call in dfg.insts[inst]
                .branch_destination_mut(&mut dfg.jump_tables, &mut dfg.exception_tables)
            {
                if call.block(&dfg.value_lists) == block {
                    call.append_argument(value, &mut dfg.value_lists);
                    if !self.seeded {
                        call.append_argument(valid, &mut dfg.value_lists);
                    }
                }
            }
        }
        (value, valid)
    }
}

pub(super) fn forward(
    context: &mut Context,
    read: Inst,
    stores: &[Inst],
    seed: Option<(Value, Value)>,
) -> Result<(usize, usize), &'static str> {
    let f = &mut context.func;
    let mut blocks = f.layout.blocks().collect::<Vec<_>>();
    if blocks.len() > 1024 || stores.is_empty() {
        return Err("append forwarding analysis limit");
    }
    let Data::Load {
        opcode: opcode @ (Opcode::Load | Opcode::Uload32),
        flags: read_flags,
        offset: read_offset,
        ..
    } = f.dfg.insts[read]
    else {
        return Err("previous word is not a plain load");
    };
    let old = f.dfg.first_result(read);
    let ty = f.dfg.value_type(old);
    if (ty == types::I32 || opcode == Opcode::Uload32)
        && read_flags.endianness(cranelift_codegen::ir::Endianness::Little)
            != cranelift_codegen::ir::Endianness::Little
    {
        return Err("narrow forwarding requires little-endian low words");
    }
    if !matches!(ty, types::I32 | types::I64) || i32::from(read_offset) != 0 {
        return Err("previous word width or displacement differs");
    }
    let known = stores.iter().copied().collect::<BTreeSet<_>>();
    for &store in stores {
        let Data::Store { flags, .. } = f.dfg.insts[store] else {
            return Err("append definition is not a store");
        };
        if f.dfg.value_type(f.dfg.inst_args(store)[0]) != types::I64
            || flags.endianness(cranelift_codegen::ir::Endianness::Little)
                != read_flags.endianness(cranelift_codegen::ir::Endianness::Little)
        {
            return Err("append word representation differs");
        }
    }
    let at = f
        .layout
        .inst_block(read)
        .ok_or("previous load has no block")?;
    let after = f
        .layout
        .next_inst(read)
        .ok_or("previous load has no continuation")?;
    let mut entry = f.layout.entry_block().ok_or("missing entry")?;
    let first = f.layout.first_inst(entry).ok_or("empty entry")?;
    if let Some((pointer, length)) = seed {
        if at == entry
            || stores
                .iter()
                .any(|&inst| f.layout.inst_block(inst) == Some(entry))
            || [pointer, length].iter().any(|&value| {
                f.dfg.value_type(value) != types::I64
                    || match f.dfg.value_def(value) {
                        cranelift_codegen::ir::ValueDef::Result(inst, _) => {
                            f.layout.inst_block(inst) != Some(entry)
                        }
                        cranelift_codegen::ir::ValueDef::Param(block, _) => block != entry,
                        _ => true,
                    }
            })
        {
            return Err("entry seed does not precede the append recurrence");
        }
    }
    let mut definitions = BTreeMap::new();
    let mut preceding = None;
    for &block in &blocks {
        for inst in f.layout.block_insts(block) {
            if block == at && inst == read {
                preceding = definitions.get(&block).copied();
            }
            if known.contains(&inst) {
                definitions.insert(block, f.dfg.inst_args(inst)[0]);
            }
        }
    }
    let mut c = FuncCursor::new(f).at_inst(first);
    let zero = c.ins().iconst(types::I64, 0);
    let one = c.ins().iconst(types::I64, 1);
    let initial = if let Some((pointer, length)) = seed {
        // The sealed NoGrowth caller owns an initialized U64 view and admits
        // its unchanged geometry. A nonempty entry view therefore permits one
        // pure read here, even when the source loop has zero iterations. Empty
        // views take no read; source nonempty/error checks remain in place.
        let terminator = c.func.layout.last_inst(entry).expect("nonempty entry");
        let resume = c.func.dfg.make_block();
        c.func.layout.split_block(resume, terminator);
        let load = c.func.dfg.make_block();
        c.func.layout.append_block(load);
        let join = c.func.dfg.make_block();
        c.func.layout.append_block(join);
        let value = c.func.dfg.append_block_param(join, types::I64);
        c.goto_bottom(entry);
        let nonempty = c.ins().icmp_imm(IntCC::NotEqual, length, 0);
        c.ins().brif(nonempty, load, &[], join, &[zero.into()]);
        c.goto_bottom(load);
        let last = c.ins().iadd_imm(length, -1);
        let displacement = c.ins().ishl_imm(last, 3);
        let address = c.ins().iadd(pointer, displacement);
        // Mutable element memory: no readonly, can_move or alignment claim.
        let flags = MemFlags::new()
            .with_notrap()
            .with_endianness(read_flags.endianness(cranelift_codegen::ir::Endianness::Little));
        let loaded = c.ins().load(types::I64, flags, address, 0);
        c.ins().jump(join, &[loaded.into()]);
        c.goto_bottom(join);
        c.ins().jump(resume, &[]);
        entry = resume;
        blocks = c.func.layout.blocks().collect();
        value
    } else {
        zero
    };
    context.compute_cfg();
    context.compute_domtree();
    let mut c = FuncCursor::new(&mut context.func);
    let mut state = State {
        cfg: &context.cfg,
        definitions,
        incoming: BTreeMap::new(),
        entry,
        zero,
        one,
        initial,
        seeded: seed.is_some(),
        reachable: blocks
            .iter()
            .copied()
            .filter(|&b| context.domtree.is_reachable(b))
            .collect(),
    };
    let (cached, valid) = if let Some(value) = preceding {
        (value, one)
    } else {
        state.start(c.func, at)
    };
    let count = state.incoming.len();
    if seed.is_some() {
        c.goto_inst(read);
        let cached = if ty == types::I32 {
            c.ins().ireduce(types::I32, cached)
        } else if opcode == Opcode::Uload32 {
            let low = c.ins().ireduce(types::I32, cached);
            c.ins().uextend(types::I64, low)
        } else {
            cached
        };
        c.func.layout.remove_inst(read);
        c.func.dfg.clear_results(read);
        c.func.dfg.change_to_alias(old, cached);
        context.compute_cfg();
        context.compute_domtree();
        return Ok((count, stores.len()));
    }
    let join = c.func.dfg.make_block();
    c.func.layout.split_block(join, after);
    let loaded = c.func.dfg.append_block_param(join, ty);
    let miss = c.func.dfg.make_block();
    c.func.layout.append_block(miss);
    c.func.layout.remove_inst(read);
    c.func.layout.append_inst(read, miss);
    c.goto_bottom(at);
    let cached = if ty == types::I32 {
        c.ins().ireduce(types::I32, cached)
    } else if opcode == Opcode::Uload32 {
        let low = c.ins().ireduce(types::I32, cached);
        c.ins().uextend(types::I64, low)
    } else {
        cached
    };
    let present = c.ins().icmp_imm(IntCC::NotEqual, valid, 0);
    c.ins().brif(present, join, &[cached.into()], miss, &[]);
    c.goto_bottom(miss);
    let miss_jump = c.ins().jump(join, &[old.into()]);
    let insts = c
        .func
        .layout
        .blocks()
        .flat_map(|b| c.func.layout.block_insts(b))
        .collect::<Vec<_>>();
    for inst in insts {
        if inst != miss_jump {
            c.func
                .dfg
                .map_inst_values(inst, |v| if v == old { loaded } else { v });
        }
    }
    context.compute_cfg();
    context.compute_domtree();
    Ok((count, stores.len()))
}

#[path="append_previous_tests.rs"]
mod tests;
