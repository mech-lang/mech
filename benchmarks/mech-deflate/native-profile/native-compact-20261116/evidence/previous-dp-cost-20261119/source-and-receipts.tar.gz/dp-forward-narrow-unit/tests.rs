mod native_artifact {pub mod program {pub mod codegen {pub mod cfg_cleanup {pub mod composed_reads {use cranelift_codegen::{ir::{Block,Function,Value,ValueDef},flowgraph::ControlFlowGraph}; use std::collections::{BTreeMap,BTreeSet};fn incoming(
    f: &Function,
    cfg: &ControlFlowGraph,
    block: Block,
    slot: usize,
) -> Option<Vec<(Block, Value)>> {
    let mut arguments = Vec::new();
    for edge in cfg.pred_iter(block) {
        for call in
            f.dfg.insts[edge.inst].branch_destination(&f.dfg.jump_tables, &f.dfg.exception_tables)
        {
            if call.block(&f.dfg.value_lists) == block {
                arguments.push((
                    edge.block,
                    call.args(&f.dfg.value_lists).nth(slot)?.as_value()?,
                ));
            }
        }
    }
    (!arguments.is_empty()).then_some(arguments)
}

// Invariant packet fields can pass through a self edge or be reloaded by an
// alternate entry. All external definitions must identify the same word.
pub(in crate::native_artifact) fn packet_word(
    f: &Function,
    cfg: &ControlFlowGraph,
    loads: &BTreeMap<Value, (Inst, usize)>,
    value: Value,
) -> Option<usize> {
    let mut pending = vec![value];
    let mut seen = BTreeSet::new();
    let mut result = None;
    while let Some(value) = pending.pop() {
        let value = f.dfg.resolve_aliases(value);
        if !seen.insert(value) {
            continue;
        }
        if let Some(&(_, word)) = loads.get(&value) {
            if result.is_some_and(|old| old != word) {
                return None;
            }
            result = Some(word);
        } else if let ValueDef::Param(block, slot) = f.dfg.value_def(value) {
            if Some(block) == f.layout.entry_block() {
                return None;
            }
            pending.extend(
                incoming(f, cfg, block, slot)?
                    .into_iter()
                    .map(|(_, value)| value),
            );
        } else {
            return None;
        }
    }
    result
}

}} pub mod append_run { #[path="/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/hosts/gpu/src/native_artifact/program/codegen/append_previous.rs"] mod previous; }}}}