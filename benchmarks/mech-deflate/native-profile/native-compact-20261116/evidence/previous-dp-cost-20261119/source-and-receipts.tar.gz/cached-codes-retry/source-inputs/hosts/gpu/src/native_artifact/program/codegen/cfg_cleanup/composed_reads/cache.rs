//! One immutable indexed value carried around a proved natural loop.
use super::*;

pub(super) struct Plan {
    header: Block,
    backedges: BTreeSet<Inst>,
}

impl Plan {
    pub(super) fn derive(
        f: &Function,
        cfg: &ControlFlowGraph,
        dom: &DominatorTree,
        lookup: Inst,
        join: Block,
    ) -> Option<Self> {
        let joined = f.layout.first_inst(join)?;
        let mut chosen: Option<Self> = None;
        for header in f.layout.blocks() {
            let first = f.layout.first_inst(header)?;
            if !dom.dominates(first, lookup, &f.layout) {
                continue;
            }
            let incoming = cfg.pred_iter(header).collect::<Vec<_>>();
            let backedges = incoming
                .iter()
                .filter(|edge| dom.dominates(first, edge.inst, &f.layout))
                .map(|edge| edge.inst)
                .collect::<BTreeSet<_>>();
            // Initialize on every external edge. Every backedge must execute
            // this lookup and obtain its joined value before carrying it.
            if backedges.is_empty()
                || incoming.iter().all(|edge| backedges.contains(&edge.inst))
                || backedges
                    .iter()
                    .any(|&edge| !dom.dominates(joined, edge, &f.layout))
            {
                continue;
            }
            if let Some(previous) = &chosen {
                let previous = f.layout.first_inst(previous.header)?;
                if !dom.dominates(previous, first, &f.layout) {
                    continue;
                }
            }
            chosen = Some(Self { header, backedges });
        }
        chosen
    }

    pub(super) fn carry(self, f: &mut Function, cfg: &ControlFlowGraph, join: Block) -> Value {
        let entry = f.layout.entry_block().expect("function entry");
        let first = f.layout.first_inst(entry).expect("entry instruction");
        let zero = FuncCursor::new(f)
            .at_inst(first)
            .ins()
            .iconst(types::I64, 0);
        let cached = f.dfg.append_block_param(self.header, types::I64);
        let updated = f.dfg.append_block_param(join, types::I64);
        let dfg = &mut f.dfg;
        // The old read arms become unreachable after the rewrite, but their
        // original jumps must still satisfy the expanded join signature.
        for edge in cfg.pred_iter(join) {
            for call in dfg.insts[edge.inst]
                .branch_destination_mut(&mut dfg.jump_tables, &mut dfg.exception_tables)
            {
                if call.block(&dfg.value_lists) == join {
                    call.append_argument(zero, &mut dfg.value_lists);
                }
            }
        }
        for edge in cfg.pred_iter(self.header) {
            let value = if self.backedges.contains(&edge.inst) {
                updated
            } else {
                zero
            };
            for call in dfg.insts[edge.inst]
                .branch_destination_mut(&mut dfg.jump_tables, &mut dfg.exception_tables)
            {
                if call.block(&dfg.value_lists) == self.header {
                    call.append_argument(value, &mut dfg.value_lists);
                }
            }
        }
        cached
    }
}
