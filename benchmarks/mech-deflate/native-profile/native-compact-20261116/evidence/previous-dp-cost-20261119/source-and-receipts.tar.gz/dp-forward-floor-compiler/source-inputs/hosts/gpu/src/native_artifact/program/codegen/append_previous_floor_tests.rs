use super::*;
use cranelift_codegen::ir::{AbiParam, types};
use cranelift_frontend::{FunctionBuilder, FunctionBuilderContext};
use cranelift_jit::{JITBuilder, JITModule};
use cranelift_module::{Linkage, Module, default_libcall_names};

fn compile(floor: Option<u64>) -> (JITModule, unsafe extern "C" fn(u64) -> u64) {
    let mut module = JITModule::new(
        JITBuilder::with_flags(
            &[("opt_level", "speed"), ("enable_verifier", "true")],
            default_libcall_names(),
        )
        .unwrap(),
    );
    let mut c = module.make_context();
    c.func.signature.params.push(AbiParam::new(types::I64));
    c.func.signature.returns.push(AbiParam::new(types::I64));
    let mut fc = FunctionBuilderContext::new();
    let mut b = FunctionBuilder::new(&mut c.func, &mut fc);
    let entry = b.create_block();
    b.append_block_params_for_function_params(entry);
    b.switch_to_block(entry);
    let length = b.block_params(entry)[0];
    let last = b.ins().iadd_imm(length, -1);
    let mut result = b.ins().iconst(types::I64, 0);
    let mut bit = 0;
    for bound in [0, 1, 257, 258, 259, 1 << 63, u64::MAX] {
        for cc in [
            IntCC::Equal,
            IntCC::NotEqual,
            IntCC::UnsignedLessThan,
            IntCC::UnsignedLessThanOrEqual,
            IntCC::UnsignedGreaterThan,
            IntCC::UnsignedGreaterThanOrEqual,
        ] {
            let test = b.ins().icmp_imm(cc, length, bound as i64);
            let word = b.ins().uextend(types::I64, test);
            let word = b.ins().ishl_imm(word, bit);
            result = b.ins().bor(result, word);
            bit += 1;
        }
    }
    for cc in [
        IntCC::Equal,
        IntCC::NotEqual,
        IntCC::UnsignedLessThan,
        IntCC::UnsignedLessThanOrEqual,
        IntCC::UnsignedGreaterThan,
        IntCC::UnsignedGreaterThanOrEqual,
        IntCC::SignedLessThan,
        IntCC::SignedGreaterThanOrEqual,
    ] {
        for (a, z) in [(last, length), (length, last)] {
            let test = b.ins().icmp(cc, a, z);
            let word = b.ins().uextend(types::I64, test);
            let word = b.ins().ishl_imm(word, bit);
            result = b.ins().bor(result, word);
            bit += 1;
        }
    }
    b.ins().return_(&[result]);
    b.seal_all_blocks();
    b.finalize();
    if let Some(floor) = floor {
        let folded = super::fold(&mut c.func, length, floor);
        assert_eq!(folded == 0, floor == 0);
    }
    let id = module
        .declare_function("current_length_floor", Linkage::Local, &c.func.signature)
        .unwrap();
    module.define_function(id, &mut c).unwrap();
    module.finalize_definitions().unwrap();
    // SAFETY: The live finalized module owns this exact C signature.
    let call = unsafe { std::mem::transmute(module.get_finalized_function(id)) };
    (module, call)
}

#[test]
fn checked_current_length_floor_preserves_unsigned_edges_and_signed_comparisons() {
    let (_module, original) = compile(None);
    for floor in [0, 1, 258, 1 << 63, u64::MAX] {
        let (_module, folded) = compile(Some(floor));
        for length in [
            0,
            1,
            2,
            257,
            258,
            259,
            260,
            (1 << 63) - 1,
            1 << 63,
            u64::MAX - 1,
            u64::MAX,
        ] {
            if length < floor {
                continue;
            }
            // SAFETY: Both live modules expose this exact scalar C signature.
            let (a, b) = unsafe { (original(length), folded(length)) };
            assert_eq!(a, b, "floor={floor}, length={length}");
        }
    }
}
