//! Reuse the caller's current-length floor at the captured append recurrence.
use cranelift_codegen::ir::{
    Function, InstBuilder, InstructionData as Data, Opcode, Value, ValueDef,
    condcodes::{CondCode, IntCC},
};

fn literal(f: &Function, value: Value) -> Option<u64> {
    let ValueDef::Result(inst, 0) = f.dfg.value_def(f.dfg.resolve_aliases(value)) else {
        return None;
    };
    match f.dfg.insts[inst] {
        Data::UnaryImm {
            opcode: Opcode::Iconst,
            imm,
        } => Some(imm.bits() as u64),
        _ => None,
    }
}

fn previous(f: &Function, value: Value, length: Value) -> bool {
    let ValueDef::Result(inst, 0) = f.dfg.value_def(f.dfg.resolve_aliases(value)) else {
        return false;
    };
    match f.dfg.insts[inst] {
        Data::BinaryImm64 {
            opcode: Opcode::IaddImm,
            arg,
            imm,
        } => imm.bits() == -1 && f.dfg.resolve_aliases(arg) == length,
        Data::Binary {
            opcode: Opcode::Isub,
            args: [a, b],
        } => f.dfg.resolve_aliases(a) == length && literal(f, b) == Some(1),
        _ => false,
    }
}

fn against_floor(cc: IntCC, bound: u64, floor: u64) -> Option<bool> {
    match cc {
        IntCC::Equal if floor > bound => Some(false),
        IntCC::NotEqual if floor > bound => Some(true),
        IntCC::UnsignedLessThan if floor >= bound => Some(false),
        IntCC::UnsignedLessThanOrEqual if floor > bound => Some(false),
        IntCC::UnsignedGreaterThan if floor > bound => Some(true),
        IntCC::UnsignedGreaterThanOrEqual if floor >= bound => Some(true),
        _ => None,
    }
}

pub(super) fn fold(f: &mut Function, length: Value, floor: u64) -> usize {
    if floor == 0 {
        return 0;
    }
    let length = f.dfg.resolve_aliases(length);
    let mut changes = Vec::new();
    for block in f.layout.blocks() {
        for inst in f.layout.block_insts(block) {
            let answer = match f.dfg.insts[inst] {
                Data::IntCompareImm { cond, arg, imm, .. }
                    if f.dfg.resolve_aliases(arg) == length =>
                {
                    against_floor(cond, imm.bits() as u64, floor)
                }
                Data::IntCompare {
                    cond, args: [a, b], ..
                } => {
                    let a = f.dfg.resolve_aliases(a);
                    let b = f.dfg.resolve_aliases(b);
                    if a == length
                        && let Some(bound) = literal(f, b)
                    {
                        against_floor(cond, bound, floor)
                    } else if b == length
                        && let Some(bound) = literal(f, a)
                    {
                        against_floor(cond.swap_args(), bound, floor)
                    } else {
                        let cc = if b == length && previous(f, a, length) {
                            Some(cond)
                        } else if a == length && previous(f, b, length) {
                            Some(cond.swap_args())
                        } else {
                            None
                        };
                        match cc {
                            Some(
                                IntCC::UnsignedLessThan
                                | IntCC::UnsignedLessThanOrEqual
                                | IntCC::NotEqual,
                            ) => Some(true),
                            Some(
                                IntCC::UnsignedGreaterThan
                                | IntCC::UnsignedGreaterThanOrEqual
                                | IntCC::Equal,
                            ) => Some(false),
                            _ => None,
                        }
                    }
                }
                _ => None,
            };
            if let Some(answer) = answer {
                changes.push((inst, answer));
            }
        }
    }
    for &(inst, answer) in &changes {
        let ty = f.dfg.value_type(f.dfg.first_result(inst));
        f.dfg.replace(inst).iconst(ty, i64::from(answer));
    }
    changes.len()
}

#[cfg(all(test, feature = "jit", target_pointer_width = "64"))]
#[path = "append_previous_floor_tests.rs"]
mod tests;
