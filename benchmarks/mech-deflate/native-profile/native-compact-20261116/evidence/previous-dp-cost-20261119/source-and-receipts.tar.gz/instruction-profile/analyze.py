from pathlib import Path
from collections import Counter
import xml.etree.ElementTree as ET
import subprocess,json,re
O=Path(__file__).resolve().parent;I=O.parent.parent;worker=I/'collector-read-lifetimes/placement/immutable-profiled/bound/mech-worker';tree=ET.parse(O/'samples.xml');ids={e.get('id'):e for e in tree.iter() if e.get('id')};resolve=lambda e:ids[e.get('ref')] if e.get('ref') else e
byname=Counter();pcs=Counter();frames={};count=0
for row in tree.findall('.//row'):
 stack=row.find('backtrace')
 if stack is None:continue
 stack=resolve(stack);frame=resolve(stack.find('frame'));name=frame.get('name');byname[name]+=1;count+=1
 binary=resolve(frame.find('binary'))
 if binary.get('name')=='mech-worker':
  pc=(int(frame.get('addr'),16)-int(binary.get('load-addr'),16))&~3;pcs[(name,pc)]+=1
nm=subprocess.check_output(['nm','-n',str(worker)],text=True);symbols={}
for line in nm.splitlines():
 p=line.split()
 if len(p)==3 and re.fullmatch('[0-9a-fA-F]+',p[0]):symbols[p[2].lstrip('_')]=int(p[0],16)
dis=subprocess.check_output(['otool','-tvV',str(worker)],text=True);(O/'disassembly.txt').write_text(dis);instructions={}
for line in dis.splitlines():
 m=re.match(r'^([0-9a-fA-F]{16})\s+(.+)$',line)
 if m:instructions[int(m[1],16)]=m[2]
rows=[]
for (name,pc),n in pcs.most_common():
 address=pc+0x100000000;start=symbols.get(name);rows.append({'function':name,'object_relative_address':hex(pc),'function_offset':address-start if start else None,'samples':n,'instruction':instructions.get(address)})
result={'samples':count,'leaf_functions':dict(byname.most_common()),'instructions':rows,'scope':'Time Profiler leaf PCs aligned down to 4B. Samples can skid around dependency stalls; they are not retired instruction counts.'};(O/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print('Total',count,'Leaf',byname.most_common(8));print(json.dumps(rows[:30],indent=2))
