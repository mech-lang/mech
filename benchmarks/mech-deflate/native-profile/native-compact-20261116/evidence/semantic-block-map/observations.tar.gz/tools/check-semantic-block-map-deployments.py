"""Execute each actually timed stripped image on all81 inputs; save raw streams."""
from pathlib import Path
from hashlib import sha256
import json,subprocess,zlib
N=Path(__file__).resolve().parent;Q=N.parent.parent;B=N/'semantic-block-map/matched-builds';read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();actors=list(read(B/'plan.json')['actors']);records=[];pins={};outputs=B/'deployment-outputs';outputs.mkdir()
for actor in actors:
 exe=B/'warmup'/actor/'compressor';pins[actor]=sha(exe)
 for fixture in read(Q/'fixtures.json'):
  inp=Path(fixture['input']).read_bytes();prefix=Path(fixture['prefix']).read_bytes();expected=Path(fixture['expected']).read_bytes();assert expected.startswith(prefix) and sha256(inp).hexdigest()==fixture['input_sha256'];raw=subprocess.check_output([str(exe),fixture['input']]);assert zlib.decompress(raw,-15)==inp;matches=raw==expected[len(prefix):];assert matches or actor=='libdeflate';pin=sha256(raw).hexdigest();output=outputs/(pin+'.deflate')
  if output.exists():assert output.read_bytes()==raw
  else:output.write_bytes(raw)
  records.append({'actor':actor,'case':fixture['name'],'input_sha256':sha256(inp).hexdigest(),'output_sha256':pin,'output_file':str(output.relative_to(B)),'output_bytes':len(raw),'independent_inflation':True,'matches_selected_bytes':matches})
assert len(records)==324
(B/'deployment-smokes.json').write_text(json.dumps({'checked_executions':len(records),'actors_sha256':pins,'records':records},indent=2)+'\n');print('all324 actual timed stripped-executable executions pass; raw streams saved',flush=True)
