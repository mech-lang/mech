"""Prove the source/block sidecar transparent, then bind raw VCode labels."""
from pathlib import Path
from hashlib import sha256
import json,os,re,subprocess
N=Path(__file__).resolve().parent;O=N/'semantic-block-map/probe';O.mkdir();read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')};build=read(N/'semantic-block-map/compiler-build/build.json');compiler=build['compiler'];assert sha(compiler)==build['compiler_sha256'];control=N/'expanded-packet-root-study/combined';r=read(control/'receipt.json');symbol='mech_compact_numeric_475_vector'
script=N/'count-current-semantic-matcher.py';ns={'__file__':str(script),'__name__':'normal_source_block_map_tools'};exec(compile(script.read_text().split('\nsource_shapes={}')[0],str(script),'exec'),ns);driver=ns['driver'];ns['shapes']['OUT']=O;receipts={}
for role in ['selected-off','selected-mapped','raw-trace-off','raw-trace-mapped']:
 out=O/role;out.mkdir();flags=dict(r['flags'])
 if role.startswith('raw-'):
  flags['MECH_COMPACT_PHASE_BLOCK_LAYOUT']=';'.join(entry for entry in flags['MECH_COMPACT_PHASE_BLOCK_LAYOUT'].split(';') if not entry.startswith(symbol+'@'))
  flags['MECH_INSPECT_PHASE_REGISTER_PROFILE']=str(out/(symbol+'.vcode'))
  flags['MECH_INSPECT_OPTIMIZED_PHASE_CLIF']=str(out/(symbol+'.clif'))
 if role.endswith('mapped'):flags['MECH_INSPECT_NUMERIC_SITE_BLOCKS']=str(out/'475-vector.json')
 cmd=[compiler,r['command'][1],str(out/'frontend'),'compact']
 with (out/'compile.log').open('w') as log:subprocess.run(cmd,env=env|flags,stdout=log,stderr=log,check=True)
 artifacts={name:sha(out/'frontend'/name) for name in r['artifacts']};assert artifacts['program.mecb']==r['artifacts']['program.mecb']
 if role.startswith('selected-'):assert artifacts==r['artifacts'],(role,artifacts)
 elif role.endswith('mapped'):assert artifacts==receipts['raw-trace-off']['artifacts'],(role,artifacts)
 layout=driver.symbols(out/'frontend/program.o');receipt=r|{'command':cmd,'compile':cmd,'flags':flags,'compiler_sha256':sha(compiler),'compiler_source_base':build['source_base'],'compiler_source_overlay_sha256':sha(N/'semantic-block-map/compiler-build/build.json'),'artifacts':artifacts,'layout':layout,'text_bytes':layout['text_bytes'],'object_sha256':artifacts['program.o'],'metadata_sha256':artifacts['metadata.json'],'bytecode_sha256':artifacts['program.mecb']};receipt.pop('linked_proof_sha256',None);(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');receipts[role]=receipt;driver.link.link_worker(control/'bound',out/'frontend',out/'bound');driver.link.check_worker(out/'bound','source-block-map-'+role);runtime=read(out/'bound/runtime.json');runtime['encoder_text_bytes']=receipt['text_bytes'];(out/'bound/runtime.json').write_text(json.dumps(runtime,indent=2)+'\n');print(role,'all3exact against propercontrol;162outputs pass;text',receipt['text_bytes'],flush=True)
assert sha(O/'selected-off/bound/mech-worker')==sha(O/'selected-mapped/bound/mech-worker')==sha(control/'bound/mech-worker')
assert sha(O/'raw-trace-off/bound/mech-worker')==sha(O/'raw-trace-mapped/bound/mech-worker')
a,b=read(O/'selected-mapped/475-vector.json'),read(O/'raw-trace-mapped/475-vector.json');assert a==b and a['header']==475
vcode=O/'raw-trace-mapped'/(symbol+'.vcode');assert sha(vcode)==sha(O/'raw-trace-off'/(symbol+'.vcode'));text=vcode.read_text();labels=[{'vcode_block':int(index),'offset':int(offset),'ir_block':int(block) if block else None} for index,offset,block in re.findall(r'^;; REGALLOC_BLOCK (\d+) offset=(\d+) ir=(?:Some\(block(\d+)\)|None) successors=',text,re.M)];assert labels and [v['vcode_block'] for v in labels]==list(range(len(labels)));atom=receipts['raw-trace-mapped']['layout']['symbols']['_'+symbol];assert all(0<=v['offset']<=atom['extent'] for v in labels)
by_ir={}
for item in labels:
 if item['ir_block'] is not None:by_ir.setdefault(item['ir_block'],[]).append(item)
records=[item|{'machine_labels':by_ir.get(item['ir_block'],[])} for item in a['emitted_sites']];mapped=[v for v in records if v['machine_labels']];surviving={v['ir_block'] for v in mapped};classes={}
for item in labels:classes.setdefault(item['offset'],[]).append(item['vcode_block'])
proof={'compiler_sha256':sha(compiler),'selected_all_three_exact':True,'selected_worker_exact':True,'raw_sidecar_all_three_exact':True,'raw_vcode_exact':True,'selected_and_raw_preoptimization_maps_exact':True,'source_map_sha256':sha(O/'raw-trace-mapped/475-vector.json'),'raw_object_sha256':receipts['raw-trace-mapped']['artifacts']['program.o'],'source_sites':len(a['source_sites']),'emitted_sites':len(records),'mapped_emitted_sites':len(mapped),'surviving_source_blocks':len(surviving),'vcode_blocks':len(labels),'distinct_label_offsets':len(classes),'folded_label_classes':sum(len(v)>1 for v in classes.values()),'records':records,'labels':labels,'offset_classes':classes,'scope':'SourceMap itself leaves all3 selected artifacts and exact selected worker unchanged. Rawtraceoff/on identical;actualVCode/objectbound. MF machine-layout profile removed fortrace because AArch64 rejects disassemblywithpostemitlayout. Rawtrace counts mustnever be relabeled asshipping instruction totals or clocks. Deleted/merged labels are recorded, notindependent observations.'};(O/'mapping-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print({k:v for k,v in proof.items() if k not in ['records','labels','offset_classes']},flush=True)
