"""Untimed actual raw matcher counts for source-event attribution."""
from pathlib import Path
from hashlib import sha256
import ast,json,shutil
N=Path(__file__).resolve().parent;O=N/'semantic-block-map/probe';Q=N.parent.parent;read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
p=N/'count-current-semantic-matcher.py';ns={'__file__':str(p),'__name__':'source_event_matcher_counts'};exec(compile(p.read_text().split('\nsource_shapes={}')[0],str(p),'exec'),ns);driver=ns['driver'];ns['shapes']['OUT']=O
source=N/'prepare-forwarded-register-study.py';nodes=[v for v in ast.parse(source.read_text()).body if isinstance(v,ast.FunctionDef) and v.name=='count'];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'));folder,shape=count(O/'raw-trace-mapped','mech_compact_numeric_475_vector');print('actualsource-eventdiagnosticcounts ready',folder,flush=True)
