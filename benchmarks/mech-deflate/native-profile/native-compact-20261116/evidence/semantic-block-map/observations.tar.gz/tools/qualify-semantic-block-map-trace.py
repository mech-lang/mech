"""Native successes, named checked errors, stack and injected recoveries."""
from pathlib import Path
from hashlib import sha256
import importlib.util,json,os,subprocess,shutil,sys
N=Path(__file__).resolve().parent;O=N/'semantic-block-map/probe';Q=N.parent.parent
P=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/benchmarks/mech-deflate/native-profile/native-compact-20261116')
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
script=N/'count-current-semantic-matcher.py';ns={'__file__':str(script),'__name__':'collector_native_gates'};exec(compile(script.read_text().split('\nsource_shapes={}')[0],str(script),'exec'),ns);driver=ns['driver']
template=(N/'linked-input-window-current-source-sort-hybrid-profiled-source-sort-hybrid32-profiled/verify-linked.py').read_text()
for name in sys.argv[1:] or ['raw-trace-mapped']:
    role=O/name;study=O/(name+'-gates');study.mkdir();workers=study/'worker-checks';workers.mkdir()
    for label,source in [('maintained',N/'narrow-packet-eight-probe-profiled'),('candidate',role)]:
        target=workers/label;driver.link.link_worker(source/'bound',source/'frontend',target);driver.link.check_worker(target,'collector-'+name+'-'+label)
        assert sha(target/'mech-worker')==sha(source/'bound/mech-worker')
    a=read(workers/'maintained/metadata.json')['origins'];b=read(workers/'candidate/metadata.json')['origins'];delta=len(b)-len(a);key=lambda v:(v['node'],v['local'])
    prefix=0
    while prefix<min(len(a),len(b)) and key(a[prefix])==key(b[prefix]):prefix+=1
    suffix=0
    while suffix<min(len(a),len(b))-prefix and key(a[-1-suffix])==key(b[-1-suffix]):suffix+=1
    mapping={str(i):{'site':i if i<prefix else i+delta} for i in [23,69,7164]}
    assert all(i<prefix or i>=len(a)-suffix for i in [23,69,7164])
    assert all(key(a[int(i)])==key(b[v['site']]) for i,v in mapping.items())
    report={'source_mapping':mapping,'original_source_sha256':sha(P/'program.mec'),'candidate_source_sha256':read(role/'receipt.json')['source_sha256'],'unchanged_prefix_instructions':prefix,'unchanged_suffix_start':len(a)-suffix,'unchanged_suffix_instruction_count':suffix,'instruction_displacement':delta,'scope':'Only the named failure actions in unchanged source prefix/suffix. Changed collector and Huffman actions are not mapped.'}
    mapfile=study/'source-origin-map.json';mapfile.write_text(json.dumps(report,indent=2)+'\n')
    text=template.replace("roles = ('maintained', 'source-sort-hybrid-profiled', 'source-sort-hybrid32-profiled')","roles = ('maintained', 'candidate')")
    before='assert all(origin == origins[0] for origin in origins)';assert text.count(before)==1
    text=text.replace(before,"assert all((origins[0][int(old)]['node'],origins[0][int(old)]['local']) == (origins[1][row['site']]['node'],origins[1][row['site']]['local']) for old,row in json.loads(Path("+repr(str(mapfile))+").read_text())['source_mapping'].items())\nenv['MECH_ERROR_SOURCE_MAP']="+repr(str(mapfile)))
    if name.startswith('hybrid32'):
        before='assert len(record[0]) == 162 and all(entry == record[0] for entry in record)';assert text.count(before)==1
        text=text.replace(before,"""assert all(len(rows)==162 for rows in record)
resource_fields={'payload_allocation_requests','requested_payload_bytes','zeroed_bytes'}
resource_deltas=[]
for before,after in zip(*record):
    assert {k:v for k,v in before.items() if k not in resource_fields}=={k:v for k,v in after.items() if k not in resource_fields}
    requests=after['payload_allocation_requests']-before['payload_allocation_requests']
    added=after['requested_payload_bytes']-before['requested_payload_bytes']
    assert requests>=0 and added==after['zeroed_bytes']-before['zeroed_bytes']==requests*288*4
    resource_deltas.append({'case':before['case'],'added_counter_allocations':requests,'added_zero_initialized_extent_bytes':added})
write(out/'source-resource-deltas.json',resource_deltas)""")
    vf=study/'verify-linked.py';vf.write_text(text)
    with (study/'verify.log').open('w') as log:subprocess.run(['python3',str(vf)],stdout=log,stderr=log,check=True)
    result=read(study/'linked-proofs/result.json');assert max(result['peak_stack_bytes'].values())<=5280
    (role/'linked-proof.json').write_text(json.dumps({'result':str(study/'linked-proofs/result.json'),'sha256':sha(study/'linked-proofs/result.json'),'candidate_peak_stack_bytes':result['peak_stack_bytes']['candidate'],'pair_peak_stack_bytes':max(result['peak_stack_bytes'].values()),'source_origin_mapping':str(mapfile),'source_origin_mapping_sha256':sha(mapfile),'scope':'162 exact outputs/inflations/aliases/resources/cleanup each; six named source-mapped allocation errors; actual measured stack.'},indent=2)+'\n')
    packet=study/'recovery-packet';packet.mkdir()
    for f in ['worker.rs','pinned_allocator.rs']:shutil.copyfile(P/f,packet/f)
    policy=read(P/'qualification-policy-v3.json')
    for case,want in policy['checked_failures'].items():want['origin']=mapping[str(want['origin'])]['site']
    policy.update(separately_pinned_source_sha256=report['candidate_source_sha256'],source_origin_mapping_sha256=sha(mapfile))
    (packet/'qualification-policy-v3.json').write_text(json.dumps(policy,indent=2)+'\n')
    fixtures=read(P/'fixtures.json')
    for case in fixtures:
        for field in ['input','prefix','expected']:case[field]=str(P/case[field])
    (packet/'fixtures.json').write_text(json.dumps(fixtures,indent=2)+'\n')
    recover=(N/'recover-vector-word-candidate.py').read_text()
    before="PACKET=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/benchmarks/mech-deflate/native-profile/native-compact-20261116')";assert recover.count(before)==1
    recover=recover.replace(before,'PACKET=Path('+repr(str(packet))+')').replace("h=run_path(str(PACKET/'rebuild_checks.py')","h=run_path(str(Path("+repr(str(P/'rebuild_checks.py'))+"))")
    rf=study/'recover.py';rf.write_text(recover)
    with (study/'recovery.log').open('w') as log:subprocess.run(['python3',str(rf),str(role)],stdout=log,stderr=log,check=True)
    print(name,'all162 successes; six errors; 12 recovery pairs; actual stack',result['peak_stack_bytes']['candidate'],flush=True)
