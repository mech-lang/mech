from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess
N=Path(__file__).resolve().parent;S=N/'semantic-block-map';P=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/benchmarks/mech-deflate/native-profile/native-compact-20261116');O=P/'evidence/semantic-block-map';O.mkdir(exist_ok=True);read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();roles={}
for role in ['selected-off','selected-mapped','raw-trace-off','raw-trace-mapped']:
 r=read(S/'probe'/role/'receipt.json');flags={k:v for k,v in r['flags'].items() if not k.startswith('MECH_INSPECT_')};profiles=[]
 for control in ['MECH_COMPACT_PHASE_BLOCK_LAYOUT','MECH_COMPACT_PHASE_REGISTER_WEIGHTS']:
  for value in flags.pop(control).split(';'):
   symbol,path=value.split('@');path=Path(path);pin=sha(path);dest=O/'profiles'/(pin[:16]+'-'+path.name);dest.parent.mkdir(exist_ok=True);shutil.copy2(path,dest);profiles.append({'control':control,'symbol':symbol,'file':str(dest.relative_to(O)),'sha256':pin})
 roles[role]={'source_file':'../../program.mec','source_sha256':r['source_sha256'],'compiler_sha256':r['compiler_sha256'],'flags':flags,'profiles':profiles,'artifacts':r['artifacts'],'text_bytes':r['text_bytes'],'worker_sha256':sha(S/'probe'/role/'bound/mech-worker'),'sidecar':role.endswith('mapped'),'raw_trace':role.startswith('raw-')}
(O/'recipes.json').write_text(json.dumps({'roles':roles},indent=2)+'\n');shutil.copy2(P/'evidence/measured-register-weight-study/build_compiler.py',O/'build_compiler.py');shutil.copy2(P/'evidence/measured-register-weight-study/verify_runtime.py',O/'verify_runtime.py');code="""from pathlib import Path
from hashlib import sha256
import argparse,json,os,subprocess
parser=argparse.ArgumentParser(__doc__);parser.add_argument('compiler',type=Path);parser.add_argument('output',type=Path);parser.add_argument('--role',choices=['selected-off','selected-mapped','raw-trace-off','raw-trace-mapped'],default='selected-mapped');parser.add_argument('--checked',action='store_true');args=parser.parse_args();here=Path(__file__).resolve().parent;out=args.output.resolve();out.mkdir(parents=True,exist_ok=False);r=json.loads((here/'recipes.json').read_text())['roles'][args.role];sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();source=(here/r['source_file']).read_bytes();assert sha256(source).hexdigest()==r['source_sha256'];(out/'program.mec').write_bytes(source);flags=r['flags'].copy();entries={}
for profile in r['profiles']:
 path=here/profile['file'];assert sha(path)==profile['sha256'];entries.setdefault(profile['control'],[]).append(profile['symbol']+'@'+str(path))
flags|={k:';'.join(v) for k,v in entries.items()}
if r['sidecar']:flags['MECH_INSPECT_NUMERIC_SITE_BLOCKS']=str(out/'475-vector.json')
if r['raw_trace']:
 flags['MECH_INSPECT_PHASE_REGISTER_PROFILE']=str(out/'mech_compact_numeric_475_vector.vcode');flags['MECH_INSPECT_OPTIMIZED_PHASE_CLIF']=str(out/'mech_compact_numeric_475_vector.clif')
if args.checked:flags['MECH_COMPACT_PAIR_REGISTER_SPILLS']='checked'
cmd=[str(args.compiler.resolve()),str(out/'program.mec'),str(out/'frontend'),'compact']
with (out/'compile.log').open('w') as log:subprocess.run(cmd,env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}|flags,stdout=log,stderr=log,check=True)
artifacts={name:sha(out/'frontend'/name) for name in r['artifacts']};assert artifacts==r['artifacts'];result={'role':args.role,'checked':args.checked,'all_three_exact':True,'artifacts':artifacts,'source_sha256':sha(out/'program.mec'),'compiler_sha256':sha(args.compiler),'command':cmd,'flags':flags};(out/'reproduction.json').write_text(json.dumps(result,indent=2)+'\\n');print(args.role,args.checked,'all three exact')
""";(O/'reproduce.py').write_text(code);compiler=read(S/'compiler-build/build.json')['compiler'];replays=S/'public-replays';replays.mkdir(exist_ok=True)
for role in roles:
 for mode in ['normal','checked']:
  out=replays/(role+'-'+mode)
  if out.exists():assert read(out/'reproduction.json')['artifacts']==roles[role]['artifacts'];continue
  subprocess.run(['python3',str(O/'reproduce.py'),compiler,str(out),'--role',role]+(['--checked'] if mode=='checked' else []),check=True)
print('eight public source/path normalchecked replays exact')
