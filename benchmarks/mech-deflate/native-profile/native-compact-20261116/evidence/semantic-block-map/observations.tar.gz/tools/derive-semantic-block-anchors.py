"""Map actual raw-loop labels to complete static heads, preserving zero blocks."""
from pathlib import Path
from hashlib import sha256
import bisect,json,re,tarfile
N=Path(__file__).resolve().parent;O=N/'semantic-block-map/probe';P=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/benchmarks/mech-deflate/native-profile/native-compact-20261116');read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest();m=read(O/'mapping-proof.json');r=read(O/'raw-trace-mapped/receipt.json');counts=read(O/'raw-trace-mapped/counts-475/counts.json');assert counts['object_sha256']==m['raw_object_sha256']==r['artifacts']['program.o']
p=N/'count-current-semantic-matcher.py';ns={'__file__':str(p),'__name__':'complete_static_anchor_graph'};exec(compile(p.read_text().split('\nsource_shapes={}')[0],str(p),'exec'),ns);ns['shapes']['OUT']=O;shape=ns['shapes']['shape'](str(O/'raw-trace-mapped'),'mech_compact_numeric_475_vector');heads=shape['code_heads'];atom=shape['atom'];assert atom==r['layout']['symbols']['_mech_compact_numeric_475_vector'];assert heads[0]==0
rows=[v for v in m['records'] if 'TailHeader' in v['terminator'] or v['action'].startswith('Latch') or v['operation']=='Some(Fallback)'];cases={}
with tarfile.open(P/'evidence/current-phase-work-study/c-semantic-traces.tar.gz') as archive:
 for case,record in counts['cases'].items():
  observed={int(b['address'],16)-atom['start']:b['visits'] for b in record['blocks']};assert set(observed)<=set(heads);anchors=[]
  for row in rows:
   labels=[]
   for label in row['machine_labels']:
    index=bisect.bisect_right(heads,label['offset'])-1;assert index>=0;head=heads[index]
    if index+1<len(heads):assert label['offset']<heads[index+1]
    labels.append(label|{'static_machine_head':head,'visits':observed.get(head,0),'exact_machine_head':head==label['offset']})
   match=re.search(r'iteration: (\d+)',row['action']+' '+row['terminator']);anchors.append({'source_site':row['source_site'],'iteration':int(match[1]) if match else None,'kind':'fallback' if row['operation']=='Some(Fallback)' else 'header' if 'TailHeader' in row['terminator'] else 'latch','version_initialize':row['version_initialize'],'labels':labels})
  peer=json.load(archive.extractfile('libdeflate/'+case+'.json'));cases[case]={'private_matcher_calls':record['calls'],'C_counters':peer['counters'],'anchors':anchors,'scope':'Machine-block visits for mapped source anchors. Empty/merged labels and source versions are explicit; these are not automatically logicalsource event counts. Zero visits use complete static CFG heads, never nearest visited heads. Checked controller outside MF phase is excluded fromMechcounts.'}
result={'source_map_sha256':m['source_map_sha256'],'raw_object_sha256':counts['object_sha256'],'counts_sha256':sha(O/'raw-trace-mapped/counts-475/counts.json'),'static_shape':shape,'cases':cases};(O/'anchor-census.json').write_text(json.dumps(result,indent=2)+'\n')
for case in ['prefix-random-1048576','prefix-natural-4096','prefix-random-4096']:
 c=cases[case];print(case,'Cpositions/tree/skip',*[c['C_counters'][k] for k in ['search_positions','search_tree_visits','skip_positions','skip_tree_visits']])
 for row in c['anchors']:
  if row['kind']=='header' or row['kind']=='fallback':print(row['kind'],row['iteration'] or row['source_site'],row['version_initialize'],[(v['static_machine_head'],v['visits'],v['exact_machine_head']) for v in row['labels']])
