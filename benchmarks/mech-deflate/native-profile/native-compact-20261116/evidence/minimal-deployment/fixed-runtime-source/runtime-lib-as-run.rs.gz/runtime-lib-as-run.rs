pub mod native_artifact { #[path = "/private/tmp/mech-shared-cold-epilogues.2L6obP/.qualification/scratch-runtime-backends/word-zero-pages/compact_runtime/mod.rs"] pub mod compact_runtime; }
