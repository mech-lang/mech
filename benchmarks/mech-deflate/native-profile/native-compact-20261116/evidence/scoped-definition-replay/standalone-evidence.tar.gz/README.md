# Replaying the winning variable definition

The optimized Apple M1 parser ran the pinned 243,209-byte source in six balanced serial orders. Each fresh process checked the source hash, the full identity-bearing tree, 718,353 final events and 3,967,302 fuel charges. The unchanged compiler grammar pin is dae46c686703560230150a93f36c44c4978ffdc7. The source digests bind the optimized variants to the patch and the active-witness refusal.

| Actor | Median parser time | Paired ratio to control |
| --- | ---: | ---: |
| Control | 1.876249 s | 1.000000× |
| Scoped definition replay | 1.302888 s | 0.694139× |
| Capture-only ablation | 1.959348 s | 1.043495× |

The prototype saved 573.361 ms at the medians and was faster in 6/6 orders. The capture-only build records the winning recipe and follows the previous replay. Its elapsed time includes the recording and admission cost.

The instrumented exact full-source check reported the bounded recipe payload below. Payload bytes count the captured event-vector allocation. The ordinal maximum includes holes and bounds the separate temporary remapping table. Captured green nodes are retained through ordinary reference-counted pointers.

```text
Receipt { disabled: false, captures: 3128, applies: 3128, max_events: 19895, max_payload_bytes: 983040, max_ordinals: 61763, minimum_first_grant: 243211278785 }
```

The full comparison preserved the raw event and cache-publication digest, node/token/diagnostic allocation cursors, tree and indexes, fuel, logical grants, checkpoints, rewinds, and cache work. The finite and segmented checks and the active raw-witness refusal passed. All 535 existing syntax tests passed. The test observer was absent from timed binaries.

PROOF.md records the replay conditions and old execution fallback. The production source patch and capture-only variant are separate. The standalone result qualifies the parser boundary. Linked compiler timings and emitted artifacts have a separate measurement.
