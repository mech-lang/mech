"""Generate the scoped definition replay and one capture-only ablation."""
import difflib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess

profile = Path("/private/tmp/mech-best-choice-profile.Y0SGCETr")
profile_spec = importlib.util.spec_from_file_location("profile_prepare", profile / "prepare.py")
profile_prepare = importlib.util.module_from_spec(profile_spec)
profile_spec.loader.exec_module(profile_prepare)
base_source, pin, verify = profile_prepare.base_source, profile_prepare.pin, profile_prepare.verify

area = Path(__file__).resolve().parent
parser = Path("document/parser")
canonical = parser / "canonical"
doc = canonical / "document"


def replace(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)


def parser_state(text):
    text = replace(text, "/// Input-independent ownership of a live parse.", """// The active definition trial only observes its first effective raw scan.
#[derive(Clone, Copy, Default)]
pub(crate) enum DefinitionRawOrigin {
    #[default]
    Off,
    Waiting,
    Fresh { at: TextSize, final_end: Option<TextSize> },
    Inherited,
}

/// Input-independent ownership of a live parse.""")
    text = replace(text, "    grapheme_tail: Option<grapheme_scan::GraphemeScan>,\n", """    grapheme_tail: Option<grapheme_scan::GraphemeScan>,
    definition_raw: DefinitionRawOrigin,
""")
    text = replace(text, "            grapheme_tail: None,\n", """            grapheme_tail: None,
            definition_raw: DefinitionRawOrigin::Off,
""")
    return replace(text, "    pub(crate) fn bump_char_raw(&mut self)", """    pub(crate) fn observe_definition_raw_origin(&mut self, final_end: Option<TextSize>) {
        if matches!(self.state.definition_raw, DefinitionRawOrigin::Waiting) {
            let at = self.offset();
            self.state.definition_raw = if self
                .state
                .grapheme_tail
                .as_ref()
                .is_some_and(|tail| tail.resumes_at(at, final_end))
            {
                DefinitionRawOrigin::Inherited
            } else {
                DefinitionRawOrigin::Fresh { at, final_end }
            };
        }
    }

    pub(crate) fn bump_char_raw(&mut self)""")


def document_continuation(text):
    text = replace(text, "\nuse super::*;\n", "\nuse super::*;\nuse super::definition_replay::{Position as DefinitionPosition, Recording as DefinitionRecording};\n")
    text = replace(text, "    BestChoice(Choice<'g>, Option<(usize, u32)>),", """    BestChoice(Choice<'g>, Option<(usize, u32)>, Option<Box<DefinitionRecording>>),""")
    text = replace(text, "    pub peak_frames: usize,\n", "    pub peak_frames: usize,\n    definition_poll: u64,\n")
    text = replace(text, "            peak_frames: 1,\n", "            peak_frames: 1,\n            definition_poll: 0,\n")
    text = replace(text, """    /// The allowance counts grammar-frame transitions.""", """    fn definition_position(&self, input_final: bool, allowance: u64) -> DefinitionPosition {
        DefinitionPosition {
            poll: self.definition_poll,
            steps: self.steps,
            child_work: self.child_work,
            allowance,
            input_final,
        }
    }

    fn record_definition(
        &self,
        parser: &mut Parser<'_>,
        expression: &GrammarExpression,
        input_final: bool,
        allowance: u64,
    ) -> Option<Box<DefinitionRecording>> {
        if matches!(expression, GrammarExpression::Rule(rule) if *rule == rules::VARIABLE_DEFINE)
            && parser.current_rule() == Some(rules::STATEMENT)
        {
            DefinitionRecording::begin(parser, self.definition_position(input_final, allowance))
        } else {
            None
        }
    }

    /// The allowance counts grammar-frame transitions.""")
    text = replace(text, """    ) -> Progress {
        while !self.frames.is_empty()""", """    ) -> Progress {
        self.definition_poll = self.definition_poll.saturating_add(1);
        while !self.frames.is_empty()""")
    old = """                Frame::BestChoice(mut frame, mut selected) => {
                    if parser.is_halted() {
                        self.result = Attempt::Committed;
                        continue;
                    }
                    if self.result == Attempt::Committed && selected.is_none() {
                        continue;
                    }
                    if self.result == Attempt::Matched {
                        let consumed = (parser.offset() - frame.checkpoint.cursor.offset).0;
                        if selected.is_none_or(|(_, old)| consumed > old) {
                            selected = Some((frame.index, consumed));
                        }
                    }
                    frame.index += 1;
                    parser.rewind(frame.checkpoint);
                    self.state = frame.initial;
                    if let Some(item) = frame.items.get(frame.index) {
                        self.push(Frame::BestChoice(frame, selected));
                        self.push(Frame::Expression(item));
                    } else if let Some((index, _)) = selected {
                        self.push(Frame::Expression(&frame.items[index]));
                    } else {
                        self.result = Attempt::NoMatch;
                    }
                }
"""
    new = """                Frame::BestChoice(mut frame, mut selected, mut definition) => {
                    let halted = parser.is_halted();
                    let stop = self.result == Attempt::Committed && selected.is_none();
                    let mut winner = false;
                    if !halted && self.result == Attempt::Matched {
                        let consumed = (parser.offset() - frame.checkpoint.cursor.offset).0;
                        if selected.is_none_or(|(_, old)| consumed > old) {
                            selected = Some((frame.index, consumed));
                            winner = true;
                        }
                    }
                    if let Some(recording) = definition.take() {
                        definition = recording.observe(
                            parser,
                            self.definition_position(input_final, *allowance),
                            winner,
                        );
                    }
                    if halted {
                        self.result = Attempt::Committed;
                        continue;
                    }
                    if stop {
                        continue;
                    }
                    frame.index += 1;
                    parser.rewind(frame.checkpoint);
                    self.state = frame.initial;
                    if let Some(item) = frame.items.get(frame.index) {
                        if definition.is_none() {
                            definition = self.record_definition(parser, item, input_final, *allowance);
                        }
                        self.push(Frame::BestChoice(frame, selected, definition));
                        self.push(Frame::Expression(item));
                    } else if let Some((index, _)) = selected {
                        if let Some((steps, child_work)) = definition.and_then(|recording| {
                            recording.apply(parser, self.definition_position(input_final, *allowance))
                        }) {
                            *allowance -= steps + child_work;
                            self.steps += steps;
                            self.child_work += child_work;
                            self.result = Attempt::Matched;
                        } else {
                            self.push(Frame::Expression(&frame.items[index]));
                        }
                    } else {
                        self.result = Attempt::NoMatch;
                    }
                }
"""
    text = replace(text, old, new)
    text = replace(text, "                Frame::Expression(expression) => self.expression(parser, expression),",
                   "                Frame::Expression(expression) => self.expression(parser, expression, input_final, *allowance),")
    text = replace(text, "    fn expression(&mut self, parser: &mut Parser<'_>, expression: &'g GrammarExpression) {",
                   "    fn expression(&mut self, parser: &mut Parser<'_>, expression: &'g GrammarExpression, input_final: bool, allowance: u64) {")
    return replace(text, "                    self.push(Frame::BestChoice(frame, None));",
                   """                    let definition = self.record_definition(parser, &items[0], input_final, allowance);
                    self.push(Frame::BestChoice(frame, None, definition));""")


def apply_patches(out):
    patches = {
        parser / "mod.rs": parser_state,
        parser / "tree_cache.rs": lambda s: replace(s, "    fn accumulate(&mut self, work: Self)", "    pub(super) fn accumulate(&mut self, work: Self)"),
        canonical / "prediction.rs": lambda s: replace(s, "const MIN_ANALYSIS_ALLOWANCE", "pub(super) const MIN_ANALYSIS_ALLOWANCE"),
        canonical / "base/continuation.rs": lambda s: replace(s, """                        let end = final_input.then_some(parser.cursor().context_end());
                        let scan = parser""", """                        let end = final_input.then_some(parser.cursor().context_end());
                        parser.observe_definition_raw_origin(end);
                        let scan = parser"""),
        canonical / "base/recognition.rs": lambda s: replace(s, """        let start = p.state.events.len();
        let identity = p.ids.node();""", """        p.observe_definition_raw_origin(Some(key.context_end));
        let start = p.state.events.len();
        let identity = p.ids.node();"""),
        doc / "mod.rs": lambda s: replace(s, "pub(crate) mod continuation;\n", "pub(crate) mod continuation;\nmod definition_replay;\n"),
        doc / "continuation.rs": document_continuation,
    }
    for path, patch in patches.items():
        f = out / path
        f.write_text(patch(f.read_text()))
    new = doc / "definition_replay.rs"
    shutil.copyfile(area / "definition_replay.rs", out / new)
    paths = sorted([*patches, new])
    subprocess.run([
        "rustfmt", "+nightly-2026-03-03", "--edition", "2024",
        "--config", "skip_children=true", *(out / p for p in paths),
    ], check=True)
    return paths


def write_diff(before, after, paths, name):
    parts = []
    for path in paths:
        previous = (before / path).read_text().splitlines(keepends=True) if (before / path).is_file() else []
        current = (after / path).read_text().splitlines(keepends=True)
        if previous == current:
            continue
        label = f"src/syntax/src/{path}"
        parts.extend(difflib.unified_diff(previous, current, fromfile=f"a/{label}" if previous else "/dev/null",
                                          tofile=f"b/{label}"))
    (area / name).write_text("".join(parts))


def prepare():
    assert len(verify()) == 164
    out = area / "source"
    shutil.copytree(base_source, out)
    paths = apply_patches(out)
    write_diff(base_source, out, paths, "definition-replay.patch")
    ablation = area / "ablation"
    shutil.copytree(out, ablation)
    p = ablation / doc / "definition_replay.rs"
    p.write_text(replace(p.read_text(), "const APPLY: bool = true;", "const APPLY: bool = false;"))
    write_diff(out, ablation, paths, "ablation.patch")
    (area / "pin.json").write_text(json.dumps({"pin": pin, "files": [str(p) for p in paths]}, indent=2) + "\n")
    print("Staged candidate and ablation against", pin)


if __name__ == "__main__":
    prepare()
