"""Build and qualify the pinned private structural replay."""
from collections import Counter
import itertools
import json
import os
from pathlib import Path
import shutil
from statistics import median
import subprocess
import sys

from prepare import area, base_source, doc, parser, pin, profile_prepare, replace, verify

checkout = profile_prepare.checkout
baseline = profile_prepare.base
source = profile_prepare.source
receipt = profile_prepare.receipt
digest = profile_prepare.digest
probe_arg = receipt["link"][-3]
test_receipt = json.loads((baseline / "validation/receipt.json").read_text())["tests"]
assert len(verify()) == 164
names = ("control", "candidate", "capture-only")
orders = tuple(itertools.permutations(names))
assert all(Counter(column) == Counter(dict.fromkeys(names, 2)) for column in zip(*orders))
env = os.environ | {
    "CARGO_MANIFEST_DIR": str(checkout / "src/syntax"),
    "CARGO_PKG_VERSION": "0.3.5",
    "MECH_DEFINITION_SOURCE": str(source),
}


def write(path, data):
    path.write_text(json.dumps(data, indent=2) + "\n")


def run(command, log):
    command = list(map(str, command))
    with log.open("wb") as file:
        subprocess.run(command, cwd=checkout, env=env, stdout=file, stderr=subprocess.STDOUT, check=True)
    return command


def test_source(out):
    staged = out / "workspace/src/syntax/src"
    shutil.copytree(area / "source", staged)
    shutil.copytree(checkout / "src/syntax/tests/canonical_rules", staged.parent / "tests/canonical_rules")
    support = out / "workspace/src/core/tests/support"
    support.mkdir(parents=True)
    shutil.copyfile(checkout / "src/core/tests/support/allocation_probe.rs", support / "allocation_probe.rs")
    f = staged / parser / "mod.rs"
    text = replace(f.read_text(), "pub mod checkpoint;\n", "pub mod checkpoint;\nmod definition_validation;\n")
    text = replace(text, "    definition_raw: DefinitionRawOrigin,\n",
                   "    definition_raw: DefinitionRawOrigin,\n    validation: definition_validation::Receipt,\n")
    text = replace(text, "            definition_raw: DefinitionRawOrigin::Off,\n",
                   "            definition_raw: DefinitionRawOrigin::Off,\n            validation: definition_validation::Receipt::default(),\n")
    f.write_text(text)
    shutil.copyfile(area / "validation.rs", staged / parser / "definition_validation.rs")
    f = staged / doc / "definition_replay.rs"
    text = replace(f.read_text(), """        if !matches!(parser.state.definition_raw, DefinitionRawOrigin::Off)
            || !sealed(parser, position)""",
                   """        if parser.state.validation.disabled
            || !matches!(parser.state.definition_raw, DefinitionRawOrigin::Off)
            || !sealed(parser, position)""")
    text = replace(text, "                origin\n                    .finish(parser, position, raw)\n                    .map(|summary| Box::new(Self(Phase::Selected(summary))))",
                   """                origin.finish(parser, position, raw).map(|summary| {
                    let report = &mut parser.state.validation;
                    report.captures += 1;
                    report.max_events = report.max_events.max(summary.events.len());
                    report.max_payload_bytes = report.max_payload_bytes.max(
                        summary.events.capacity() * core::mem::size_of::<Event>()
                    );
                    report.max_ordinals = report.max_ordinals.max(summary.nodes).max(summary.tokens);
                    Box::new(Self(Phase::Selected(summary)))
                })""")
    text = replace(text, "        let events = self.fresh_events(parser.ids)?;",
                   """        let events = self.fresh_events(parser.ids)?;
        let first_grant = at.steps + at.child_work + self.steps + self.child_work
            + remaining_headroom(parser).expect("admitted stale-cache headroom");
        let report = &mut parser.state.validation;
        report.applies += 1;
        if at.poll == 1 && report.minimum_first_grant == 0 {
            report.minimum_first_grant = first_grant;
        }""")
    f.write_text(text + (area / "busy-witness-test.rs").read_text())
    return staged


def test_build():
    out = area / "validation"
    out.mkdir(exist_ok=False)
    staged = test_source(out)
    test = out / "syntax-tests"
    args = [
        str(staged / "lib.rs") if arg == str(base_source / "lib.rs")
        else str(test) if arg == str(baseline / "validation/syntax-tests")
        else "metadata=definition-replay-exact" if arg.startswith("metadata=")
        else arg
        for arg in test_receipt["build"]
    ]
    assert str(staged / "lib.rs") in args and str(test) in args
    sha2 = next(arg for arg in receipt["link"] if arg.startswith("sha2="))
    command = run([*args, "--extern", sha2], out / "build.log")
    write(out / "build.json", {"command": command, "binary_sha256": digest(test)})


def test_run(which):
    out = area / "validation"
    test = out / "syntax-tests"
    expected = json.loads((out / "build.json").read_text())
    assert digest(test) == expected["binary_sha256"]
    filters = {"full": ["scoped_definition_full_input"], "finite": ["scoped_definition_finite_and_segmented"],
               "witness": ["scoped_definition_preserves_busy_witness"], "suite": ["--skip", "scoped_definition_"]}
    command = run([test, "--test-threads=1", "--nocapture", *filters[which]], out / f"{which}.log")
    print((out / f"{which}.log").read_text().split("test result:")[-1].strip(), flush=True)
    write(out / f"{which}-run.json", {"command": command, "log": f"{which}.log"})


def build_actor(name, tree):
    out = area / "optimized" / name
    out.mkdir(parents=True, exist_ok=False)
    library = out / "libmech_syntax.rlib"
    binary = out / "parser"
    opts = [
        str(tree / "lib.rs") if arg == str(base_source / "lib.rs")
        else str(library) if arg.endswith("/candidate/libmech_syntax.rlib")
        else f"metadata=definition-replay-{name}" if arg.startswith("metadata=")
        else arg for arg in receipt["build"]
    ]
    assert str(tree / "lib.rs") in opts and str(library) in opts
    link = [
        f"mech_syntax={library}" if arg.startswith("mech_syntax=")
        else str(binary) if arg == str(profile_prepare.control)
        else arg for arg in receipt["link"]
    ]
    assert str(binary) in link
    command = run(opts, out / "build.log")
    linked = run(link, out / "link.log")
    write(out / "build.json", {"build": command, "link": linked, "binary_sha256": digest(binary)})


def baseline_actor():
    return profile_prepare.control


def parse(role, label, out):
    binary = baseline_actor() if role == "control" else area / "optimized" / role / "parser"
    path = out / f"{label}-{role}.json"
    command = run([binary, source, path], out / f"{label}-{role}.log")
    measured = json.loads(path.read_text())
    assert all(measured[k] == v for k, v in receipt["exact_tree_and_work"].items()), measured
    return {"command": command, **measured}


def timing():
    out = area / "timings"
    out.mkdir()
    for what in ("full", "finite", "witness", "suite"):
        assert (area / f"validation/{what}-run.json").is_file()
    for role in names[1:]:
        actor = area / "optimized" / role
        expected = json.loads((actor / "build.json").read_text())
        assert digest(actor / "parser") == expected["binary_sha256"]
    write(out / "plan.json", {"source_pin": pin, "rounds": orders, "warmup_order": names})
    for name in names:
        parse(name, "preflight", out)
    rows = []
    for index, order in enumerate(orders, 1):
        rows.append({role: parse(role, f"order-{index}", out) for role in order})
    by_actor = {name: median(row[name]["parse_seconds"] for row in rows) for name in names}
    ratio = {name: median(row[name]["parse_seconds"] / row["control"]["parse_seconds"] for row in rows)
             for name in names if name != "control"}
    write(out / "report.json", {"rounds": rows, "medians_s": by_actor, "paired_vs_control": ratio})
    print(json.dumps({"medians_s": by_actor, "paired_vs_control": ratio}, indent=2), flush=True)


if __name__ == "__main__":
    command, *args = sys.argv[1:]
    if command == "build":
        role, = args
        build_actor(role, {"candidate": area / "source", "capture-only": area / "ablation"}[role])
    elif command == "test":
        which, = args
        test_run(which)
    else:
        {"test-build": test_build, "timing": timing}[command]()
