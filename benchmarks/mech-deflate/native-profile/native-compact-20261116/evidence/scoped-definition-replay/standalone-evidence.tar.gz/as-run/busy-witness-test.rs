#[test]
fn scoped_definition_preserves_busy_witness() {
    use crate::document::parser::{LexicalMode, ParseConfig};
    use crate::document::{DocumentId, Revision, TextSnapshot};

    let snapshot = TextSnapshot::new(DocumentId(21), Revision(1), "x := 7\n").unwrap();
    let mut ids = IdGenerator::new();
    let mut parser = Parser::new(
        &snapshot,
        LexicalMode::CanonicalSourceFragment,
        ParseConfig::default(),
        &mut ids,
    );
    parser.state.tree_cache.one_shot = true;
    let position = Position {
        poll: 1,
        steps: 0,
        child_work: 0,
        allowance: u64::MAX,
        input_final: true,
    };
    parser.state.definition_raw = DefinitionRawOrigin::Fresh {
        at: TextSize(1),
        final_end: Some(snapshot.byte_len()),
    };
    assert!(Recording::begin(&mut parser, position).is_none());
    assert!(
        matches!(parser.state.definition_raw, DefinitionRawOrigin::Fresh { at: TextSize(1), final_end: Some(end) } if end == snapshot.byte_len())
    );
    parser.state.definition_raw = DefinitionRawOrigin::Off;
    assert!(Recording::begin(&mut parser, position).is_some());
    assert!(matches!(
        parser.state.definition_raw,
        DefinitionRawOrigin::Waiting
    ));
}
