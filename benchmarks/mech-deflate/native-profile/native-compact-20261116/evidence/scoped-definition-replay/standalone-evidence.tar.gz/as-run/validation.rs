//! Exact private differential of the scoped BestChoice replay.
use super::*;
use crate::document::{DocumentId, GreenElement, Revision};
use sha2::{Digest, Sha256};

#[derive(Clone, Copy, Debug, Default)]
pub(super) struct Receipt {
    pub disabled: bool,
    pub captures: usize,
    pub applies: usize,
    pub max_events: usize,
    pub max_payload_bytes: usize,
    pub max_ordinals: u64,
    pub minimum_first_grant: u64,
}

fn number(h: &mut Sha256, n: u64) {
    h.update(n.to_le_bytes());
}

fn events(tape: &Journal<Event>) -> [u8; 32] {
    let mut digest = Sha256::new();
    for event in tape.iter() {
        match event {
            Event::Start {
                identity,
                cached,
                kind,
                flags,
            } => {
                digest.update([0]);
                number(&mut digest, *kind as u64);
                number(&mut digest, u64::from(flags.0));
                number(&mut digest, identity.map_or(0, |v| v.0));
                if let Some(cached) = cached {
                    digest.update([1]);
                    number(&mut digest, cached.end_event as u64);
                    number(&mut digest, u64::from(cached.range.start.0));
                    number(&mut digest, u64::from(cached.range.end.0));
                    number(&mut digest, cached.node.id.0);
                    number(&mut digest, cached.node.structural_hash);
                    number(&mut digest, cached.node.kind as u64);
                    number(&mut digest, u64::from(cached.node.flags.0));
                    number(&mut digest, u64::from(cached.node.text_len.0));
                    number(&mut digest, cached.node.children.len() as u64);
                    for child in cached.node.children.iter() {
                        match child {
                            GreenElement::Node(node) => {
                                digest.update([0]);
                                number(&mut digest, node.id.0);
                                number(&mut digest, node.structural_hash);
                            }
                            GreenElement::Token(token) => {
                                digest.update([1]);
                                number(&mut digest, token.id.0);
                                number(&mut digest, token.text_hash);
                                number(&mut digest, token.kind as u64);
                                number(&mut digest, u64::from(token.text_len.0));
                                number(&mut digest, u64::from(token.flags.0));
                            }
                        }
                    }
                } else {
                    digest.update([0]);
                }
            }
            Event::Token { kind, range, flags } => {
                digest.update([1]);
                number(&mut digest, *kind as u64);
                number(&mut digest, u64::from(range.start.0));
                number(&mut digest, u64::from(range.end.0));
                number(&mut digest, u64::from(flags.0));
            }
            Event::Reuse { node } => {
                digest.update([2]);
                number(&mut digest, node.id.0);
                number(&mut digest, node.structural_hash);
            }
            Event::Finish => digest.update([3]),
            Event::Tombstone => digest.update([4]),
        }
    }
    digest.finalize().into()
}

fn tree(node: &GreenNode, digest: &mut Sha256) {
    number(digest, node.id.0);
    number(digest, node.kind as u64);
    number(digest, u64::from(node.text_len.0));
    number(digest, u64::from(node.flags.0));
    number(digest, node.structural_hash);
    number(digest, node.children.len() as u64);
    for child in node.children.iter() {
        match child {
            GreenElement::Node(node) => {
                digest.update([0]);
                tree(node, digest);
            }
            GreenElement::Token(token) => {
                digest.update([1]);
                number(digest, token.id.0);
                number(digest, token.kind as u64);
                number(digest, u64::from(token.text_len.0));
                number(digest, u64::from(token.flags.0));
                number(digest, token.text_hash);
            }
        }
    }
}

#[derive(Debug, Eq, PartialEq)]
struct Observation {
    steps: u64,
    child_work: u64,
    document_frames: usize,
    fuel: u64,
    cursor: TextSize,
    rewinds: u64,
    rewound_bytes: u64,
    events: [u8; 32],
    peaks: [usize; 4],
    cache: [u64; 5],
    ids: [u64; 3],
    poll_digest: [u8; 32],
    tree: [u8; 32],
    indexes: [u8; 32],
    stats: ParseStats,
}

fn run(
    source: TextSnapshot,
    config: ParseConfig,
    grants: &[u64],
    disabled: bool,
    one_shot: bool,
    initial_final: bool,
) -> (Observation, Receipt) {
    let mut ids = IdGenerator::new();
    let mut parser = Parser::new(
        &source,
        LexicalMode::CanonicalSourceFragment,
        config,
        &mut ids,
    );
    parser.state.validation.disabled = disabled;
    if one_shot {
        parser.state.events = Journal::batch();
        parser.state.tree_cache.one_shot = true;
    }
    parser.set_resource_rule(rules::PARSE);
    let mut continuation = canonical::document::continuation::Continuation::document_root();
    use canonical::document::continuation::Progress;
    let mut poll_digest = Sha256::new();
    let mut final_input = initial_final;
    for poll in 0..10_000_000 {
        let grant = grants[poll % grants.len()];
        let mut allowance = grant;
        let progress = continuation.advance(&mut parser, final_input, &mut allowance);
        let outcome = match progress {
            Progress::Complete(_) => 0,
            Progress::NeedsProcessing => 1,
            Progress::NeedInput => 2,
            Progress::Limited => 3,
        };
        for value in [
            grant - allowance,
            u64::from(parser.offset().0),
            parser.state.fuel,
            parser.state.rewinds,
            parser.state.events.len() as u64,
            parser.ids.next_node(),
            parser.ids.next_token(),
            parser.ids.next_diagnostic(),
            outcome,
        ] {
            number(&mut poll_digest, value);
        }
        if outcome == 0 {
            break;
        }
        assert_ne!(poll, 9_999_999, "finite fixture must drain");
        if outcome >= 2 {
            assert!(!final_input, "unexpected final parse outcome");
            final_input = true;
        }
        parser = Parser::resume(&source, parser.suspend(), &mut ids);
    }
    let receipt = parser.state.validation;
    let state = &parser.state;
    let cache = state.tree_cache.total_work();
    let mut report = Observation {
        steps: continuation.steps,
        child_work: continuation.child_work,
        document_frames: continuation.peak_frames,
        fuel: state.fuel,
        cursor: parser.offset(),
        rewinds: state.rewinds,
        rewound_bytes: state.rewound_bytes,
        events: events(&state.events),
        peaks: [
            state.peak_events,
            state.peak_open_markers,
            state.rules.peak_depth(),
            state.tree_cache.peak_pending,
        ],
        cache: [
            cache.events,
            cache.token_bytes,
            cache.child_storage_nodes,
            cache.nodes,
            cache.reused,
        ],
        ids: [
            parser.ids.next_node(),
            parser.ids.next_token(),
            parser.ids.next_diagnostic(),
        ],
        poll_digest: poll_digest.finalize().into(),
        tree: [0; 32],
        indexes: [0; 32],
        stats: ParseStats::default(),
    };
    let output = parser.finish();
    let parsed = finish_snapshot(source, output, &mut ids, SyntaxKind::Document);
    let mut tree_hash = Sha256::new();
    tree(&parsed.root, &mut tree_hash);
    report.tree = tree_hash.finalize().into();
    let mut indexes = Sha256::new();
    for (id, record) in parsed.nodes.nodes() {
        number(&mut indexes, id.0);
        indexes.update(alloc::format!("{record:?}"));
    }
    for restart in parsed.restarts.iter() {
        indexes.update(alloc::format!("{restart:?}"));
    }
    indexes.update(alloc::format!("{:?}", parsed.diagnostics));
    report.indexes = indexes.finalize().into();
    report.stats = parsed.stats;
    (report, receipt)
}

fn compare(
    source: TextSnapshot,
    config: ParseConfig,
    grants: &[u64],
    one_shot: bool,
    initial_final: bool,
) -> Receipt {
    let (control, _) = run(
        source.clone(),
        config,
        grants,
        true,
        one_shot,
        initial_final,
    );
    let (candidate, receipt) = run(source, config, grants, false, one_shot, initial_final);
    assert_eq!(control, candidate);
    receipt
}

#[test]
fn scoped_definition_full_input() {
    let path = std::env::var("MECH_DEFINITION_SOURCE").expect("private pinned source");
    let text = std::fs::read_to_string(path).unwrap();
    let worker = std::thread::Builder::new()
        .stack_size(32 * 1024 * 1024)
        .spawn(move || {
            let source = TextSnapshot::new(DocumentId(0x50524f47), Revision(1), &*text).unwrap();
            let applied = compare(source, ParseConfig::default(), &[u64::MAX], true, true);
            assert!(applied.applies > 0, "{applied:?}");
            eprintln!("definition payload {applied:?}");
        })
        .unwrap();
    worker.join().unwrap();
}

#[test]
fn scoped_definition_finite_and_segmented() {
    let fixtures = [
        "a := 1\nb := a + 2\n",
        "~x<u8> := 3u8\n",
        "x :=\n",
        "x = 1\n",
        "x := f(4)\n",
        "width := [1, 2, 3]\n",
        "é := \"Å\"\n",
        "a\u{301} := \"e\u{301}\"\n",
        "```mech\nx := 1\n```\n",
        "bad := x +\nnext := 5\n",
        "pick := ((x == 2)? | true => 1 | false => 0)\n",
    ];
    let ordinary = ParseConfig::default();
    let mut applied = 0usize;
    for text in fixtures {
        let source = TextSnapshot::new(DocumentId(17), Revision(1), text).unwrap();
        let ordinary_receipt = compare(source.clone(), ordinary, &[u64::MAX], true, true);
        applied += ordinary_receipt.applies;
        if ordinary_receipt.minimum_first_grant != 0 {
            let floor = ordinary_receipt.minimum_first_grant;
            let exact = compare(source.clone(), ordinary, &[floor, u64::MAX], true, true);
            let lower = compare(source.clone(), ordinary, &[floor - 1, u64::MAX], true, true);
            assert!(
                exact.applies > 0 && lower.applies < exact.applies,
                "{text:?} {exact:?} {lower:?}"
            );
        }
        let mut split = TextSnapshot::new(DocumentId(17), Revision(1), "").unwrap();
        for scalar in text.chars() {
            split = split.append(scalar.to_string()).unwrap();
        }
        for configuration in [
            ordinary,
            ParseConfig {
                limits: ParseLimits {
                    fuel: 127,
                    ..ordinary.limits
                },
            },
            ParseConfig {
                limits: ParseLimits {
                    max_events: 39,
                    ..ordinary.limits
                },
            },
            ParseConfig {
                limits: ParseLimits {
                    max_nesting: 8,
                    ..ordinary.limits
                },
            },
        ] {
            for grants in [&[u64::MAX][..], &[1, 7, 23, 17][..], &[5, 37, 71][..]] {
                let segmented = compare(split.clone(), configuration, grants, true, true);
                assert_eq!(segmented.applies, 0);
                let streaming = compare(source.clone(), configuration, grants, false, false);
                assert_eq!(streaming.applies, 0);
                compare(source.clone(), configuration, grants, true, true);
            }
        }
        let (base, _) = run(source.clone(), ordinary, &[u64::MAX], true, true, true);
        for fuel in [
            base.stats.parser_steps.saturating_sub(1),
            base.stats.parser_steps,
            base.stats.parser_steps.saturating_add(1),
        ] {
            compare(
                source.clone(),
                ParseConfig {
                    limits: ParseLimits {
                        fuel,
                        ..ordinary.limits
                    },
                },
                &[u64::MAX],
                true,
                true,
            );
        }
        let approx_event_gate = (base.peaks[0] + base.peaks[1] + 3) as u32;
        for max_events in [
            approx_event_gate - 1,
            approx_event_gate,
            approx_event_gate + 1,
        ] {
            compare(
                source.clone(),
                ParseConfig {
                    limits: ParseLimits {
                        max_events,
                        ..ordinary.limits
                    },
                },
                &[u64::MAX],
                true,
                true,
            );
        }
    }
    assert!(applied > 0);
}
