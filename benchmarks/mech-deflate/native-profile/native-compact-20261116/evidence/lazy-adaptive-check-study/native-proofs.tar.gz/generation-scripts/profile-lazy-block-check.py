"""Untimed diagnostic clones and source-compiled layout profiles only."""
from pathlib import Path
from hashlib import sha256
import json,os,subprocess,shutil
N=Path(__file__).resolve().parent;O=N/'lazy-block-check';Q=N.parent.parent
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
script=N/'count-current-semantic-matcher.py';ns={'__file__':str(script),'__name__':'collector_profile_tools'}
exec(compile(script.read_text().split('\nsource_shapes={}')[0],str(script),'exec'),ns)
driver=ns['driver'];ns['shapes']['OUT']=O
shape=lambda role,symbol:ns['shapes']['shape'](str(role),symbol)
env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}
proof=[]
for name,huff in [('hybrid32-lazy',4615)]:
    raw=O/'homes';r=read(raw/'receipt.json');r['layout']=driver.symbols(raw/'frontend/program.o');(raw/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
    front=raw/'canonical-counter-input/frontend';front.mkdir(parents=True)
    normalization=ns['normal'](raw/'frontend/program.o',front/'program.o')
    for f in ['metadata.json','program.mecb']:shutil.copyfile(raw/'frontend'/f,front/f)
    (front.parent/'canonicalization.json').write_text(json.dumps(normalization,indent=2)+'\n')
    target=front.parent/'bound';driver.link.link_worker(raw/'bound',front,target)
    assert sha(target/'mech-worker')==sha(raw/'bound/mech-worker')
    profiles=[]
    for header in [475]:
        symbol='mech_compact_numeric_'+str(header)+'_vector';source=shape(raw,symbol);folder=raw/('instruction-counts-'+str(header))
        base=Q/'count-matcher-instructions.py';program=base.read_text()
        before='    root = q / f"{label}-native/final-candidate"';assert program.count(before)==1;program=program.replace(before,'    root = Path('+repr(str(target))+')')
        before='    directory = q / "matcher-dynamic-blocks" / actor';assert program.count(before)==1;program=program.replace(before,'    directory = Path('+repr(str(folder))+')')
        program=program.replace('allow_data_references=literal_start is not None','allow_data_references=True')
        scope={'__name__':'collector_diagnostic_blocks','__file__':str(base)};exec(compile(program,str(base),'exec'),scope)
        scope['count'](name+'-'+str(header),name,ns['training'],'_'+symbol,source['pool'])
        (folder/'counts.json').rename(folder/'canonical-counts.json');counts=read(folder/'canonical-counts.json')
        atom=driver.symbols(front/'program.o')['symbols']['_'+symbol]
        assert {k:atom[k] for k in ['extent','sha256','relocations']}=={k:source['atom'][k] for k in ['extent','sha256','relocations']}
        delta=source['atom']['start']-atom['start']
        for case in counts['cases'].values():
            for block in case['blocks']:block['address']=hex(int(block['address'],16)+delta)
        counts.update(object_sha256=source['object_sha256'],canonical_counts_sha256=sha(folder/'canonical-counts.json'),address_translation=delta)
        (folder/'counts.json').write_text(json.dumps(counts,indent=2)+'\n')
        (folder/'plan.json').write_text(json.dumps({'untimed':True,'shipping_object_sha256':sha(raw/'frontend/program.o'),'diagnostic_counter_source':program,'normalization':normalization,'cases':ns['training'],'scope':'Counts describe this admitted kernel only; controller fallback excluded. Diagnostic object never used for latency or shipping.'},indent=2)+'\n')
        path=ns['profile_matcher'](str(folder),source,folder);profiles.append(symbol+'@'+str(path))
    for old,oldsymbol,oldprofile,newsymbol in [
        (N/'parallel-low-packet-probe','mech_compact_numeric_3009_no_growth_composed',N/'parallel-low-packet-probe-scorer-profile.json','mech_compact_numeric_3029_no_growth_composed'),
        (N/'source-search-control-homes','mech_compact_numeric_3956_vector',N/'dp-vector-private-complements-3956-profile.json',f'mech_compact_numeric_{huff}_vector')]:
        a=shape(old,oldsymbol);b=shape(raw,newsymbol);p=read(oldprofile)
        assert a['code_blocks']==b['code_blocks'],(name,newsymbol)
        assert sorted(p['order'])==a['heads'] and p.get('literal_offset')==a['pool']
        table=dict(zip(a['code_heads'],b['code_heads'],strict=True));new=p|{'order':[table[k] for k in p['order'] if k in table]+b['zero_literal_padding'],'literal_offset':b['pool']}
        assert sorted(new['order'])==b['heads']
        dest=raw/(newsymbol+'-layout.json');dest.write_text(json.dumps(new,indent=2)+'\n');profiles.append(newsymbol+'@'+str(dest));proof.append({'role':name,'old_profile':str(oldprofile),'old_shape':a,'new_shape':b,'new_profile':str(dest),'proof':'Ordered graph equality; code-head bijection and literal-pool boundary; no semantic assumption.'})
    flags=r['flags']|{'MECH_COMPACT_PHASE_BLOCK_LAYOUT':';'.join(profiles)}
    out=O/'hybrid32-lazy-profiled';out.mkdir();cmd=[r['compile'][0],r['compile'][1],str(out/'frontend'),'compact']
    with (out/'compile.log').open('w') as log:subprocess.run(cmd,env=env|flags,stdout=log,stderr=log,check=True)
    artifacts={f:sha(out/'frontend'/f) for f in ['program.o','metadata.json','program.mecb']};layout=driver.symbols(out/'frontend/program.o')
    receipt=r|{'compile':cmd,'command':cmd,'flags':flags,'artifacts':artifacts,'layout':layout,'text_bytes':layout['text_bytes'],'object_sha256':artifacts['program.o'],'metadata_sha256':artifacts['metadata.json'],'bytecode_sha256':artifacts['program.mecb']}
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    checked=out/'checked-emission';cc=[r['compile'][0],r['compile'][1],str(checked/'frontend'),'compact']
    with (out/'checked.log').open('w') as log:subprocess.run(cc,env=env|flags|{'MECH_COMPACT_PAIR_REGISTER_SPILLS':'checked'},stdout=log,stderr=log,check=True)
    assert artifacts=={f:sha(checked/'frontend'/f) for f in artifacts}
    driver.link.link_worker(raw/'bound',out/'frontend',out/'bound')
    print(name,'profiled text',receipt['text_bytes'],'normal/checked all3 exact',flush=True)
(O/'profile-transfer.json').write_text(json.dumps(proof,indent=2)+'\n')
