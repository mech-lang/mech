#![allow(dead_code)]
extern crate alloc;
#[path = "/private/tmp/mech-shared-cold-epilogues.2L6obP/.qualification/current-roadmap/semantic-body-dispatch/source/src/syntax/src/document/retained_sequence.rs"]
mod retained_sequence;
