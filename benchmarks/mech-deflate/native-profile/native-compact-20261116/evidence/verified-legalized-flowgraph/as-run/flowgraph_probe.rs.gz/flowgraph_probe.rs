use cranelift_codegen::control::ControlPlane;
use cranelift_codegen::cursor::{Cursor, FuncCursor};
use cranelift_codegen::ir::{AbiParam, Block, Inst, InstBuilder, types};
use cranelift_codegen::settings::{self, Configurable};
use cranelift_codegen::{CodegenError, Context, isa};

fn cfg() -> (Context, Block, Block, Inst) {
    let mut ctx = Context::new();
    let entry = ctx.func.dfg.make_block();
    let live = ctx.func.dfg.make_block();
    let dead = ctx.func.dfg.make_block();
    let mut cursor = FuncCursor::new(&mut ctx.func);
    cursor.insert_block(entry);
    let jump = cursor.ins().jump(live, &[]);
    cursor.insert_block(live);
    cursor.ins().return_(&[]);
    cursor.insert_block(dead);
    cursor.ins().return_(&[]);
    ctx.flowgraph();
    (ctx, entry, live, jump)
}

fn main() {
    for verifiable in [true, false] {
        let mut settings = settings::builder();
        settings
            .set("enable_verifier", if verifiable { "true" } else { "false" })
            .unwrap();
        settings.set("opt_level", "speed").unwrap();
        let isa = isa::lookup_by_name("aarch64")
            .unwrap()
            .finish(settings::Flags::new(settings))
            .unwrap();
        let (mut ctx, entry, live, _) = cfg();
        ctx.optimize(isa.as_ref(), &mut ControlPlane::default())
            .unwrap();
        ctx.verify(isa.as_ref()).unwrap();
        assert_eq!(ctx.func.layout.blocks().collect::<Vec<_>>(), [entry, live]);
        println!(
            "optimized function with verifier={verifiable}\n{}",
            ctx.func.display()
        );

        let (mut ctx, _, _, _) = cfg();
        ctx.legalize(isa.as_ref()).unwrap();
        assert!(!ctx.cfg.is_valid() && !ctx.domtree.is_valid());
        println!("standalone legalize invalidates graphs with verifier={verifiable}");

        if verifiable {
            let (mut ctx, _, _, _) = cfg();
            ctx.func.signature.returns.push(AbiParam::new(types::I64));
            let err = ctx
                .optimize(isa.as_ref(), &mut ControlPlane::default())
                .unwrap_err();
            let CodegenError::Verifier(errors) = err else {
                panic!("expected verifier diagnostics")
            };
            let rendered = errors.to_string();
            assert!(rendered.contains("return"));
            println!("invalid return rejected:\n{rendered}");
            assert!(!ctx.cfg.is_valid() && !ctx.domtree.is_valid());
        }
    }
}
