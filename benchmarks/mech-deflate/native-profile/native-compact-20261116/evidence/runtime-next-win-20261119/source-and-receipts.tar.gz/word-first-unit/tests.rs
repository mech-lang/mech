#![allow(dead_code)]
use cranelift_codegen::Context;
use cranelift_codegen::cursor::{Cursor,FuncCursor};
use cranelift_codegen::ir::condcodes::{CondCode,IntCC};
use cranelift_codegen::ir::{Block,BlockArg,Endianness,Function,Inst,InstBuilder,InstructionData as Data,MemFlags,Opcode,Value,ValueDef,types};
use std::collections::BTreeSet;
use Data as D;use Opcode as O;
struct Certificate {header:Block,blocks:BTreeSet<Block>,source_header:usize,reuse_scope:Option<reuse::Scope>}
mod reuse {
 use super::*;
 #[derive(Clone,Copy,Debug)]pub struct Scope {pub header:usize}
 #[derive(Clone,Copy)]pub struct State;
 #[derive(Debug)]pub enum Extent {Fixed(u64),Variable}
 pub fn extent(_: &Context,_:&Certificate,_:&Change)->Option<Extent>{panic!("saved-state admission is outside these tests")}
 pub fn begin(_: &mut Context,_:Scope,_:&Change)->Option<State>{panic!("saved-state admission is outside these tests")}
 impl State {
  pub fn advance_forwarded(self,_:&mut FuncCursor<'_>,_:&Change,_:Value,_:Value)->Value{panic!("saved state is outside these tests")}
  pub fn advance(self,_:&mut FuncCursor<'_>,_:&Change,_:Value,_:bool)->Value{panic!("saved state is outside these tests")}
  pub fn proved_prefix_end(self,_:&mut FuncCursor<'_>,_:&Change,_:Value)->Value{panic!("saved state is outside these tests")}
  pub fn record_prefix(self,_:&mut Function,_:&Change,_:u64,_:Value){panic!("saved state is outside these tests")}
  pub fn record_words(self,_:&mut Function,_:&Certificate,_:&Change){panic!("saved state is outside these tests")}
 }
}
mod prefix {
 use super::*;
 pub struct Handoff {pub header:usize}
 impl Handoff {pub fn emit(self,_:&mut Function,_:Value)->Value{panic!("saved state is outside these tests")}}
 pub fn continuation(_: &Context,_:&Certificate,_:&Change,_:reuse::Scope,_:&[Certificate],_:&std::collections::BTreeMap<usize,(reuse::State,Value)>)->Option<Handoff>{panic!("saved-state admission is outside these tests")}
}
fn masked_integer_comparison(
    f: &Function,
    instruction: &D,
    mut resolve: impl FnMut(Value) -> Option<Value>,
) -> Option<Value> {
    let D::BinaryImm64 {
        opcode: O::BandImm,
        arg,
        imm,
    } = *instruction
    else {
        return None;
    };
    if imm.bits() != 1 {
        return None;
    }
    let mut value = arg;
    for _ in 0..8 {
        value = resolve(value)?;
        let ValueDef::Result(definition, 0) = f.dfg.value_def(value) else {
            return None;
        };
        match f.dfg.insts[definition] {
            D::Unary {
                opcode: O::Uextend,
                arg,
            } => value = arg,
            D::IntCompare { .. } | D::IntCompareImm { .. }
                if f.dfg.value_type(value) == types::I8 =>
            {
                return Some(value);
            }
            _ => return None,
        }
    }
    None
}
struct Resolve<'a> {
    context: &'a Context,
    header: Block,
}
impl Resolve<'_> {
    fn value(&self, mut value: Value) -> Option<Value> {
        let f = &self.context.func;
        let mut seen = BTreeSet::new();
        loop {
            value = f.dfg.resolve_aliases(value);
            if !seen.insert(value) {
                return None;
            }
            let ValueDef::Param(block, ordinal) = f.dfg.value_def(value) else {
                return Some(value);
            };
            if block == self.header {
                return Some(value);
            }
            let mut incoming = None;
            for pred in self.context.cfg.pred_iter(block) {
                for edge in f.dfg.insts[pred.inst]
                    .branch_destination(&f.dfg.jump_tables, &f.dfg.exception_tables)
                {
                    if edge.block(&f.dfg.value_lists) != block {
                        continue;
                    }
                    let current = edge.args(&f.dfg.value_lists).nth(ordinal)?.as_value()?;
                    if incoming.replace(current).is_some() {
                        return Some(value);
                    }
                }
            }
            let Some(next) = incoming else {
                return Some(value);
            };
            value = next;
        }
    }
    fn inst(&self, value: Value) -> Option<Inst> {
        let ValueDef::Result(inst, 0) = self.context.func.dfg.value_def(self.value(value)?) else {
            return None;
        };
        Some(inst)
    }
    fn constant(&self, value: Value) -> Option<u64> {
        let Data::UnaryImm {
            opcode: Opcode::Iconst,
            imm,
        } = self.context.func.dfg.insts[self.inst(value)?]
        else {
            return None;
        };
        Some(imm.bits() as u64)
    }
    fn invariant(&self, value: Value) -> Option<Value> {
        let value = self.value(value)?;
        let f = &self.context.func;
        let before = match f.dfg.value_def(value) {
            ValueDef::Result(inst, _) => {
                self.context.domtree.dominates(inst, self.header, &f.layout)
            }
            ValueDef::Param(block, _) => {
                block != self.header && self.context.domtree.block_dominates(block, self.header)
            }
            _ => false,
        };
        before.then_some(value)
    }
    fn add(&self, value: Value, at: Value, amount: u64) -> bool {
        let Some(inst) = self.inst(value) else {
            return false;
        };
        match self.context.func.dfg.insts[inst] {
            Data::Binary {
                opcode: Opcode::Iadd,
                args,
            } => {
                (self.value(args[0]) == Some(at) && self.constant(args[1]) == Some(amount))
                    || (self.value(args[1]) == Some(at) && self.constant(args[0]) == Some(amount))
            }
            Data::BinaryImm64 {
                opcode: Opcode::IaddImm,
                arg,
                imm,
            } => self.value(arg) == Some(at) && imm.bits() as u64 == amount,
            _ => false,
        }
    }
    fn comparison_mask(&self, inst: Inst) -> Option<Value> {
        let f = &self.context.func;
        masked_integer_comparison(f, &f.dfg.insts[inst], |value| self.value(value))
    }

    fn predicate(&self, mut value: Value, mut yes: bool) -> Option<(IntCC, Value, Value)> {
        let f = &self.context.func;
        let mut seen = BTreeSet::new();
        loop {
            value = self.value(value)?;
            if !seen.insert(value) {
                return None;
            }
            let inst = self.inst(value)?;
            match f.dfg.insts[inst] {
                Data::Unary {
                    opcode: Opcode::Uextend,
                    arg,
                } => value = arg,
                Data::IntCompare { cond, args, .. } => {
                    if matches!(cond, IntCC::Equal | IntCC::NotEqual) {
                        let (inner, constant) = if let Some(v) = self.constant(args[1]) {
                            (args[0], v)
                        } else if let Some(v) = self.constant(args[0]) {
                            (args[1], v)
                        } else {
                            return Some((
                                if yes { cond } else { cond.complement() },
                                self.value(args[0])?,
                                self.value(args[1])?,
                            ));
                        };
                        let inner_inst = self.inst(inner)?;
                        if constant <= 1
                            && matches!(
                                f.dfg.insts[inner_inst],
                                Data::Unary {
                                    opcode: Opcode::Uextend,
                                    ..
                                } | Data::IntCompare { .. }
                                    | Data::IntCompareImm { .. }
                            )
                        {
                            yes ^= (constant == 0) == (cond == IntCC::Equal);
                            value = inner;
                            continue;
                        }
                    }
                    return Some((
                        if yes { cond } else { cond.complement() },
                        self.value(args[0])?,
                        self.value(args[1])?,
                    ));
                }
                _ => value = self.comparison_mask(inst)?,
            }
        }
    }
}

struct Trace {
    instructions: Vec<Inst>,
    end: Inst,
}
fn trace(f: &Function, cert: &Certificate, start: Block, back: bool) -> Option<Trace> {
    let mut block = start;
    let mut seen = BTreeSet::new();
    let mut instructions = Vec::new();
    loop {
        if !cert.blocks.contains(&block) || !seen.insert(block) {
            return None;
        }
        let end = f.layout.last_inst(block)?;
        instructions.extend(f.layout.block_insts(block).filter(|&i| i != end));
        match f.dfg.insts[end] {
            Data::Jump { destination, .. } => {
                block = destination.block(&f.dfg.value_lists);
                if back && block == cert.header {
                    return Some(Trace { instructions, end });
                }
            }
            Data::Brif { .. } if !back => return Some(Trace { instructions, end }),
            _ => return None,
        }
    }
}

#[derive(Clone, Copy)]
struct Change {
    entry: Inst,
    backedge: Inst,
    limit: Value,
    bases: [Value; 2],
    limit_check: Inst,
    limit_exit: Block,
}
impl Change {
    fn initial(self, f: &Function, cert: &Certificate) -> Option<Value> {
        f.dfg.insts[self.entry]
            .branch_destination(&f.dfg.jump_tables, &f.dfg.exception_tables)
            .iter()
            .find(|edge| edge.block(&f.dfg.value_lists) == cert.header)?
            .args(&f.dfg.value_lists)
            .next()?
            .as_value()
    }
}

fn candidate(context: &Context, cert: &Certificate) -> Option<Change> {
    let f = &context.func;
    let &[at] = f.dfg.block_params(cert.header) else {
        return None;
    };
    if f.dfg.value_type(at) != types::I64 {
        return None;
    }
    let r = Resolve {
        context,
        header: cert.header,
    };
    let header = trace(f, cert, cert.header, false)?;
    let Data::Brif { arg, blocks, .. } = f.dfg.insts[header.end] else {
        return None;
    };
    if blocks[0].block(&f.dfg.value_lists) == blocks[1].block(&f.dfg.value_lists) {
        return None;
    }
    let (cc, sum, limit) = r.predicate(arg, true)?;
    let body_index = match cc {
        IntCC::UnsignedLessThanOrEqual => 0,
        IntCC::UnsignedGreaterThan => 1,
        _ => return None,
    };
    if !r.add(sum, at, 8) {
        return None;
    }
    let limit = r.invariant(limit)?;
    let body = trace(f, cert, blocks[body_index].block(&f.dfg.value_lists), false)?;
    let Data::Brif {
        arg,
        blocks: compared,
        ..
    } = f.dfg.insts[body.end]
    else {
        return None;
    };
    let (cc, a, b) = r.predicate(arg, true)?;
    let equal_index = match cc {
        IntCC::Equal => 0,
        IntCC::NotEqual => 1,
        _ => return None,
    };
    let difference = if r.constant(b) == Some(0) {
        a
    } else if r.constant(a) == Some(0) {
        b
    } else {
        return None;
    };
    let Data::Binary {
        opcode: Opcode::Bxor,
        args,
    } = f.dfg.insts[r.inst(difference)?]
    else {
        return None;
    };
    let mut bases = Vec::new();
    for value in args {
        let inst = r.inst(value)?;
        if f.dfg.value_type(f.dfg.inst_results(inst)[0]) != types::I64 {
            return None;
        }
        let Data::Load {
            arg, offset, flags, ..
        } = f.dfg.insts[inst]
        else {
            return None;
        };
        if i32::from(offset) != 0 || flags.endianness(Endianness::Little) != Endianness::Little {
            return None;
        }
        let Data::Binary {
            opcode: Opcode::Iadd,
            args,
        } = f.dfg.insts[r.inst(arg)?]
        else {
            return None;
        };
        let base = if r.value(args[0])? == at {
            r.invariant(args[1])?
        } else if r.value(args[1])? == at {
            r.invariant(args[0])?
        } else {
            return None;
        };
        bases.push(base);
    }
    let back = trace(
        f,
        cert,
        compared[equal_index].block(&f.dfg.value_lists),
        true,
    )?;
    let Data::Jump { destination, .. } = f.dfg.insts[back.end] else {
        return None;
    };
    let args = destination.args(&f.dfg.value_lists).collect::<Vec<_>>();
    if args.len() != 1 || !r.add(args[0].as_value()?, at, 8) {
        return None;
    }
    // The cycle must contain only exactly these pure scalar predicates,
    // addresses, equality and immutable loads. No debit/store/call/check can be
    // bypassed. A sole induction phi excludes an observed extra carried value.
    let loads = body
        .instructions
        .iter()
        .filter(|&&i| f.dfg.insts[i].opcode() == Opcode::Load)
        .count();
    if loads != 2 {
        return None;
    }
    for inst in header
        .instructions
        .iter()
        .chain(&body.instructions)
        .chain(&back.instructions)
    {
        if !matches!(
            f.dfg.insts[*inst].opcode(),
            Opcode::Iconst
                | Opcode::Iadd
                | Opcode::IaddImm
                | Opcode::Icmp
                | Opcode::Uextend
                | Opcode::Bxor
                | Opcode::Load
        ) && r.comparison_mask(*inst).is_none()
        {
            return None;
        }
        if f.dfg.insts[*inst].opcode() == Opcode::Load && !body.instructions.contains(inst) {
            return None;
        }
    }
    // Exactly one initial edge and the proved equal backedge. Do not redirect
    // an additional traversal whose entry facts have not been established.
    let incoming = context
        .cfg
        .pred_iter(cert.header)
        .map(|pred| pred.inst)
        .collect::<BTreeSet<_>>();
    if incoming.len() != 2
        || !incoming.contains(&back.end)
        || incoming.iter().any(|&inst| {
            inst != back.end && context.domtree.dominates(cert.header, inst, &f.layout)
        })
    {
        return None;
    }
    Some(Change {
        entry: incoming.into_iter().find(|&inst| inst != back.end)?,
        backedge: back.end,
        limit,
        bases: bases.try_into().ok()?,
        limit_check: header.end,
        limit_exit: blocks[1 - body_index].block(&f.dfg.value_lists),
    })
}

// Keep the equality result in vector form until its one Boolean observation.
// This reads exactly the same admitted words and retains the scalar mismatch
// continuation; only the pure reduction of already-loaded bits changes.
fn any_bits(c: &mut FuncCursor<'_>, difference: Value) -> Value {
    if std::env::var_os("MECH_WIDE_ANY_BITS").is_some() {
        c.ins().vany_true(difference)
    } else {
        let low = c.ins().extractlane(difference, 0);
        let high = c.ins().extractlane(difference, 1);
        c.ins().bor(low, high)
    }
}

enum SavedInterval {
    Long(reuse::State, Option<Value>),
    Prefix(reuse::State, u64, prefix::Handoff),
}

fn apply(
    f: &mut Function,
    cert: &Certificate,
    change: Change,
    state: Option<SavedInterval>,
    wide_tier: bool,
    after_word: bool,
) -> Option<(usize, reuse::State, Value)> {
    let check = f.dfg.make_block();
    let initial = f.dfg.append_block_param(check, types::I64);
    let wide = wide_tier.then(|| {
        let body = f.dfg.make_block();
        let at = f.dfg.append_block_param(body, types::I64);
        (body, at, f.dfg.make_block())
    });
    let short_check = f.dfg.make_block();
    let short_initial = f.dfg.append_block_param(short_check, types::I64);
    let short_wide = f.dfg.make_block();
    let short_at = f.dfg.append_block_param(short_wide, types::I64);
    let short_advance = f.dfg.make_block();
    f.layout.append_block(check);
    if let Some((body, _, advance)) = wide {
        f.layout.append_block(body);
        f.layout.append_block(advance);
    }
    for block in [short_check, short_wide, short_advance] {
        f.layout.append_block(block);
    }
    // The capture gate establishes initial <= limit. Once an immutable group
    // differs, its first differing word is reachable by the unchanged scalar
    // loop. A sub-vector remainder likewise stays in that scalar loop.
    // With no saved-interval state, the original first word can select the
    // wider path. Its equal backedge has exactly the same admitted cursor
    // geometry as the original entry, and no source effects are skipped.
    let entry = if after_word {
        change.backedge
    } else {
        change.entry
    };
    f.rewrite_branch_destination(entry, cert.header, check);
    let mut c = FuncCursor::new(f).at_bottom(check);
    let mut forwarded = None;
    let initial = match state {
        Some(SavedInterval::Long(state, Some(end))) => {
            state.advance_forwarded(&mut c, &change, initial, end)
        }
        Some(SavedInterval::Long(state, None)) => state.advance(&mut c, &change, initial, false),
        Some(SavedInterval::Prefix(state, width, handoff)) => {
            let end = state.proved_prefix_end(&mut c, &change, initial);
            let compare = c.func.dfg.make_block();
            c.func.layout.append_block(compare);
            c.ins().brif(
                end,
                cert.header,
                &[BlockArg::Value(change.limit)],
                compare,
                &[],
            );
            state.record_prefix(c.func, &change, width, end);
            let header = handoff.header;
            let parameter = handoff.emit(c.func, end);
            forwarded = Some((header, state, parameter));
            c.goto_bottom(compare);
            initial
        }
        None => initial,
    };
    let flags = MemFlags::new().with_endianness(Endianness::Little);
    if let Some((body, wide_at, advance)) = wide {
        let remaining = c.ins().isub(change.limit, initial);
        let last_wide = c.ins().iadd_imm(change.limit, -64);
        let enough = c
            .ins()
            .icmp_imm(IntCC::UnsignedGreaterThanOrEqual, remaining, 64);
        c.ins().brif(
            enough,
            body,
            &[BlockArg::Value(initial)],
            short_check,
            &[BlockArg::Value(initial)],
        );
        c.goto_bottom(body);
        let left = c.ins().iadd(change.bases[0], wide_at);
        let right = c.ins().iadd(change.bases[1], wide_at);
        // A failed group restarts at the same scalar word. The certificate
        // excludes effects and observable intermediate state from the cycle.
        let mut combined = None;
        for offset in [0, 16, 32, 48] {
            let a = c.ins().load(types::I64X2, flags, left, offset);
            let b = c.ins().load(types::I64X2, flags, right, offset);
            let difference = c.ins().bxor(a, b);
            combined = Some(match combined {
                Some(previous) => c.ins().bor(previous, difference),
                None => difference,
            });
        }
        let differs = any_bits(&mut c, combined.unwrap());
        c.ins().brif(
            differs,
            cert.header,
            &[BlockArg::Value(wide_at)],
            advance,
            &[],
        );
        c.goto_bottom(advance);
        // Entry proves limit >= 64 and wide_at <= limit - 64. The same
        // comparison at the latch proves the next complete group readable.
        let next = c.ins().iadd_imm(wide_at, 64);
        let enough = c
            .ins()
            .icmp(IntCC::UnsignedLessThanOrEqual, next, last_wide);
        c.ins().brif(
            enough,
            body,
            &[BlockArg::Value(next)],
            short_check,
            &[BlockArg::Value(next)],
        );
    } else {
        c.ins().jump(short_check, &[BlockArg::Value(initial)]);
    }

    c.goto_bottom(short_check);
    let remaining = c.ins().isub(change.limit, short_initial);
    let last_short = c.ins().iadd_imm(change.limit, -16);
    let enough = c
        .ins()
        .icmp_imm(IntCC::UnsignedGreaterThanOrEqual, remaining, 16);
    c.ins().brif(
        enough,
        short_wide,
        &[BlockArg::Value(short_initial)],
        cert.header,
        &[BlockArg::Value(short_initial)],
    );
    c.goto_bottom(short_wide);
    let left = c.ins().iadd(change.bases[0], short_at);
    let right = c.ins().iadd(change.bases[1], short_at);
    let a = c.ins().load(types::I64X2, flags, left, 0);
    let b = c.ins().load(types::I64X2, flags, right, 0);
    let difference = c.ins().bxor(a, b);
    let differs = any_bits(&mut c, difference);
    c.ins().brif(
        differs,
        cert.header,
        &[BlockArg::Value(short_at)],
        short_advance,
        &[],
    );
    c.goto_bottom(short_advance);
    // Remaining length only decreases, so an exhausted short tier can
    // proceed straight to the scalar remainder at the current position.
    let next = c.ins().iadd_imm(short_at, 16);
    let enough = c
        .ins()
        .icmp(IntCC::UnsignedLessThanOrEqual, next, last_short);
    c.ins().brif(
        enough,
        short_wide,
        &[BlockArg::Value(next)],
        cert.header,
        &[BlockArg::Value(next)],
    );
    forwarded
}

#[derive(Default)]
pub(crate) struct Outcome {
    pub wider: Vec<usize>,
    pub reused: Vec<(usize, usize)>,
    pub prefixes: Vec<(usize, usize)>,
}

pub(crate) fn optimize(
    context: &mut Context,
    certificates: &[Certificate],
    reuse_prefix: bool,
    wide_tier: bool,
) -> Outcome {
    let strategy = std::env::var("MECH_EQUAL_COMPARE_STRATEGY").ok();
    optimize_with_strategy(
        context,
        certificates,
        reuse_prefix,
        wide_tier,
        strategy.as_deref(),
    )
}

fn optimize_with_strategy(
    context: &mut Context,
    certificates: &[Certificate],
    reuse_prefix: bool,
    wide_tier: bool,
    strategy: Option<&str>,
) -> Outcome {
    let mut outcome = Outcome::default();
    if strategy == Some("word") {
        // The certified source recurrence already compares admitted U64
        // words. Avoid speculative vector reads when word comparisons are
        // selected; all original source checks and operations remain intact.
        return outcome;
    }
    let mut continuations = std::collections::BTreeMap::new();
    for (index, cert) in certificates.iter().enumerate() {
        context.compute_cfg();
        context.compute_domtree();
        let Some(change) = candidate(context, cert) else {
            continue;
        };
        let mut saved = None;
        if reuse_prefix && std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() {
            let extent = reuse::extent(context, cert, &change);
            eprintln!(
                "equality entry {} {:?}: {extent:?}, limit exit {}",
                cert.source_header, cert.reuse_scope, change.limit_exit
            );
        }
        if let Some(scope) = cert.reuse_scope {
            if let Some((state, end)) = continuations.remove(&cert.source_header) {
                saved = Some(SavedInterval::Long(state, Some(end)));
                outcome.reused.push((cert.source_header, scope.header));
            } else {
                match reuse::extent(context, cert, &change) {
                    Some(reuse::Extent::Fixed(width))
                        if reuse_prefix && width >= 8 && width % 8 == 0 =>
                    {
                        if let Some(handoff) = prefix::continuation(
                            context,
                            cert,
                            &change,
                            scope,
                            &certificates[index + 1..],
                            &continuations,
                        ) && let Some(state) = reuse::begin(context, scope, &change)
                        {
                            saved = Some(SavedInterval::Prefix(state, width, handoff));
                        }
                    }
                    Some(reuse::Extent::Variable) => {
                        if let Some(state) = reuse::begin(context, scope, &change) {
                            saved = Some(SavedInterval::Long(state, None));
                            outcome.reused.push((cert.source_header, scope.header));
                        }
                    }
                    _ => {}
                }
            }
        }
        if let Some(SavedInterval::Long(state, _)) = &saved {
            state.record_words(&mut context.func, cert, &change);
        }
        let after_word = strategy == Some("word-first") && saved.is_none();
        if let Some((header, state, end)) = apply(
            &mut context.func,
            cert,
            change,
            saved,
            wide_tier,
            after_word,
        ) {
            continuations.insert(header, (state, end));
            outcome.prefixes.push((cert.source_header, header));
        }
        outcome.wider.push(cert.source_header);
    }
    if !outcome.wider.is_empty() {
        context.compute_cfg();
        context.compute_domtree();
    }
    outcome
}



mod tests {
use super::*;
use cranelift_codegen::ir::AbiParam;
use cranelift_frontend::{FunctionBuilder,FunctionBuilderContext};
use cranelift_jit::{JITBuilder,JITModule};
use cranelift_module::{Linkage,Module,default_libcall_names};
fn fixture(module: &JITModule, variant: &str) -> (Context, Certificate) {
    let mut c = module.make_context();
    c.func.signature.params = vec![AbiParam::new(types::I64); 4];
    if matches!(variant, "raw_mask" | "extra_raw_mask") {
        c.func.signature.params.push(AbiParam::new(types::I8));
    }
    c.func.signature.returns = vec![AbiParam::new(types::I64)];
    let mut fb = FunctionBuilderContext::new();
    let certificate;
    {
        let mut b = FunctionBuilder::new(&mut c.func, &mut fb);
        let entry = b.create_block();
        b.append_block_params_for_function_params(entry);
        let header = b.create_block();
        let body = b.create_block();
        let back = b.create_block();
        let exit = b.create_block();
        let mismatch = b.create_block();
        b.append_block_param(header, types::I64);
        if variant == "carried" {
            b.append_block_param(header, types::I64);
        }
        b.switch_to_block(entry);
        let args = b.block_params(entry).to_vec();
        let mut initial = vec![args[2].into()];
        if variant == "carried" {
            initial.push(args[2].into());
        }
        // Model the real certificate's ordered-entry gate. The constructed
        // buffers cover every tested limit; failed admission keeps scalar exit.
        let admitted = b.create_block();
        let refused = b.create_block();
        let ordered = b
            .ins()
            .icmp(IntCC::UnsignedLessThanOrEqual, args[2], args[3]);
        b.ins().brif(ordered, admitted, &[], refused, &[]);
        b.switch_to_block(refused);
        b.ins().return_(&[args[2]]);
        b.switch_to_block(admitted);
        if variant == "extra_entry" {
            let alternate = b.create_block();
            let choose = b.ins().icmp_imm(IntCC::Equal, args[2], 0);
            b.ins().brif(choose, header, &initial, alternate, &[]);
            b.switch_to_block(alternate);
        }
        b.ins().jump(header, &initial);
        b.switch_to_block(header);
        let at = b.block_params(header)[0];
        let sum = b.ins().iadd_imm(at, 8);
        let valid = b.ins().icmp(IntCC::UnsignedLessThanOrEqual, sum, args[3]);
        let valid = match variant {
            "cleanup_masks" => {
                let word = b.ins().uextend(types::I64, valid);
                b.ins().icmp_imm(IntCC::Equal, word, 1)
            }
            "extended_masks" => {
                let word = b.ins().uextend(types::I64, valid);
                b.ins().band_imm(word, 1)
            }
            "wrong_mask" => b.ins().band_imm(valid, 2),
            "raw_mask" => b.ins().band_imm(args[4], 1),
            _ => valid,
        };
        b.ins().brif(valid, body, &[], exit, &[]);
        b.switch_to_block(body);
        let a = b.ins().iadd(args[0], at);
        let d = b.ins().iadd(args[1], at);
        let flags = MemFlags::new().with_endianness(if variant == "big" {
            Endianness::Big
        } else {
            Endianness::Little
        });
        let a = b.ins().load(types::I64, flags, a, 0);
        let d = b.ins().load(types::I64, flags, d, 0);
        if variant == "store" {
            b.ins().store(MemFlags::new(), a, args[0], 0);
        }
        let difference = b.ins().bxor(a, d);
        // Use ordinary Icmp with a constant, as the shared source emitter does.
        let zero = b.ins().iconst(types::I64, 0);
        let equal = if variant == "immediate" {
            b.ins().icmp_imm(IntCC::Equal, difference, 0)
        } else {
            b.ins().icmp(IntCC::Equal, difference, zero)
        };
        let equal = match variant {
            "cleanup_masks" => {
                let word = b.ins().uextend(types::I64, equal);
                b.ins().icmp_imm(IntCC::NotEqual, word, 0)
            }
            "extended_masks" => {
                let word = b.ins().uextend(types::I64, equal);
                b.ins().band_imm(word, 1)
            }
            _ => equal,
        };
        if variant == "extra_raw_mask" {
            b.ins().band_imm(args[4], 1);
        }
        b.ins().brif(equal, back, &[], mismatch, &[]);
        b.switch_to_block(back);
        let next = b
            .ins()
            .iadd_imm(at, if variant == "stride" { 12 } else { 8 });
        let mut next_args = vec![next.into()];
        if variant == "carried" {
            next_args.push(next.into());
        }
        b.ins().jump(header, &next_args);
        b.switch_to_block(mismatch);
        b.ins().return_(&[at]);
        b.switch_to_block(exit);
        b.ins().return_(&[at]);
        b.seal_all_blocks();
        b.finalize();
        certificate = Certificate {
            header,
            blocks: BTreeSet::from([header, body, back]),
            source_header: 7,
            reuse_scope: None,
        };
    }
    (c, certificate)
}
#[test]
fn equality_scan_strategies_preserve_word_mismatches_and_admitted_tails() {
    for (strategy, wide_tier) in [
        ("word", true),
        ("vector", true),
        ("vector", false),
        ("word-first", true),
        ("word-first", false),
    ] {
        let mut module = JITModule::new(JITBuilder::with_flags(&[("opt_level","speed"),("enable_verifier","true")],default_libcall_names()).unwrap());
        let (mut context, certificate) = fixture(&module, "normal");
        let outcome = optimize_with_strategy(
            &mut context,
            &[certificate],
            false,
            wide_tier,
            Some(strategy),
        );
        if strategy == "word" {
            assert!(outcome.wider.is_empty());
        } else {
            assert_eq!(outcome.wider, [7]);
        }
        cranelift_codegen::verify_function(&context.func, module.isa()).unwrap();
        let id = module
            .declare_function("equality_strategy", Linkage::Local, &context.func.signature)
            .unwrap();
        module.define_function(id, &mut context).unwrap();
        module.finalize_definitions().unwrap();
        let function: unsafe extern "C" fn(*const u8, *const u8, u64, u64) -> u64 =
            unsafe { std::mem::transmute(module.get_finalized_function(id)) };
        for offset in 0..8 {
            for start in [0, 1, 7, 8, 13] {
                for limit in [
                    0, 7, 8, 9, 15, 16, 17, 31, 32, 33, 63, 64, 65, 127, 128, 129, 255, 256, 257,
                ] {
                    let left = [0u8; 288];
                    for mismatch in 0..=264 {
                        for bit in [1, 128] {
                            let mut right = [0u8; 288];
                            if mismatch < 264 {
                                right[offset + mismatch] = bit;
                            }
                            let mut expected = start;
                            while expected + 8 <= limit {
                                let at = offset + expected as usize;
                                if left[at..at + 8] != right[at..at + 8] {
                                    break;
                                }
                                expected += 8;
                            }
                            let actual = unsafe {
                                function(
                                    left.as_ptr().add(offset),
                                    right.as_ptr().add(offset),
                                    start,
                                    limit,
                                )
                            };
                            assert_eq!(
                                actual, expected,
                                "{strategy}, offset={offset}, start={start}, limit={limit}, mismatch={mismatch}"
                            );
                        }
                    }
                }
            }
        }
    }
}
#[test]
fn compact_wide_equal_refuses_effects_other_steps_extra_state_or_unproved_geometry() {
    let module = JITModule::new(JITBuilder::with_flags(&[("opt_level","speed"),("enable_verifier","true")],default_libcall_names()).unwrap());
    for variant in [
        "store",
        "stride",
        "carried",
        "big",
        "immediate",
        "extra_entry",
        "wrong_mask",
        "raw_mask",
        "extra_raw_mask",
    ] {
        let (mut c, certificate) = fixture(&module, variant);
        cranelift_codegen::verify_function(&c.func, module.isa()).unwrap();
        let before = c.func.display().to_string();
        assert!(
            optimize(&mut c, &[certificate], false, true)
                .wider
                .is_empty(),
            "{variant}"
        );
        assert_eq!(c.func.display().to_string(), before);
    }
    let (mut c, mut certificate) = fixture(&module, "normal");
    certificate.blocks.clear();
    assert!(
        optimize(&mut c, &[certificate], false, true)
            .wider
            .is_empty()
    );
}
}
