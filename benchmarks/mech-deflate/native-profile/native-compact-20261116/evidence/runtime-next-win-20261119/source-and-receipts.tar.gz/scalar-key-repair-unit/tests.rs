mod scalar_key { use cranelift_codegen::ir::{InstBuilder,Value,types}; use cranelift_frontend::FunctionBuilder;
pub(super) fn pack(b: &mut FunctionBuilder<'_>, cost: Value, ordinal: Value) -> Value {
    let cost = b.ins().uextend(types::I64, cost);
    let cost = b.ins().ishl_imm(cost, 32);
    b.ins().bor(cost, ordinal)
}

}
#[test]
fn ordered_reduction_scalar_keys_keep_unsigned_costs_and_earliest_ties() {
    use cranelift_codegen::ir::{AbiParam, InstBuilder, types};
    use cranelift_frontend::{FunctionBuilder, FunctionBuilderContext};
    use cranelift_jit::{JITBuilder, JITModule};
    use cranelift_module::{Linkage, Module, default_libcall_names};

    let mut module = JITModule::new(
        JITBuilder::with_flags(
            &[("opt_level", "speed"), ("enable_verifier", "true")],
            default_libcall_names(),
        )
        .unwrap(),
    );
    let mut context = module.make_context();
    context.func.signature.params = [types::I32, types::I32, types::I64, types::I32, types::I64]
        .into_iter()
        .map(AbiParam::new)
        .collect();
    context.func.signature.returns = vec![AbiParam::new(types::I64)];
    let mut builder = FunctionBuilderContext::new();
    let mut b = FunctionBuilder::new(&mut context.func, &mut builder);
    let entry = b.create_block();
    b.append_block_params_for_function_params(entry);
    b.switch_to_block(entry);
    let [best, first_cost, first_index, second_cost, second_index] =
        b.block_params(entry).try_into().unwrap();
    let zero = b.ins().iconst(types::I64, 0);
    let initial = crate::scalar_key::pack(&mut b, best, zero);
    let first = crate::scalar_key::pack(&mut b, first_cost, first_index);
    let second = crate::scalar_key::pack(&mut b, second_cost, second_index);
    let pair = b.ins().umin(first, second);
    let result = b.ins().umin(initial, pair);
    b.ins().return_(&[result]);
    b.seal_all_blocks();
    b.finalize();
    let id = module
        .declare_function("scalar_cost_keys", Linkage::Local, &context.func.signature)
        .unwrap();
    module.define_function(id, &mut context).unwrap();
    module.finalize_definitions().unwrap();
    type Entry = unsafe extern "C" fn(u32, u32, u64, u32, u64) -> u64;
    // SAFETY: The live finalized module owns this exact C signature.
    let call: Entry = unsafe { std::mem::transmute(module.get_finalized_function(id)) };
    let costs = [0, 1, 0x7fff_ffff, 0x8000_0000, u32::MAX - 1, u32::MAX];
    for best in costs {
        for first_cost in costs {
            for second_cost in costs {
                for first_index in [0, 1, 511, u32::MAX - 1, u32::MAX] {
                    for second_index in [0, 1, 511, u32::MAX - 1, u32::MAX] {
                        let expected = [
                            (best, 0),
                            (first_cost, first_index),
                            (second_cost, second_index),
                        ]
                        .into_iter()
                        .min()
                        .unwrap();
                        // SAFETY: Only integer arguments with admitted U32 ordinals.
                        let actual = unsafe {
                            call(
                                best,
                                first_cost,
                                first_index.into(),
                                second_cost,
                                second_index.into(),
                            )
                        };
                        assert_eq!(
                            (actual >> 32, actual as u32),
                            (u64::from(expected.0), expected.1)
                        );
                    }
                }
            }
        }
    }
}

