//! A stable unsigned (cost, ordinal) minimum over the same admitted visits.
use super::cost::{Inputs, ScalarRead};
use super::{Item, Proof, Reduction, Window};
use crate::native_artifact::codegen::common::ssa_words::Words;
use cranelift_codegen::ir::condcodes::IntCC;
use cranelift_codegen::ir::{Block, InstBuilder, Value, types};
use cranelift_frontend::FunctionBuilder;

pub(super) fn pack(b: &mut FunctionBuilder<'_>, cost: Value, ordinal: Value) -> Value {
    let cost = b.ins().uextend(types::I64, cost);
    let cost = b.ins().ishl_imm(cost, 32);
    b.ins().bor(cost, ordinal)
}

pub(super) fn emit(
    reduction: &Reduction,
    b: &mut FunctionBuilder<'_>,
    words: &Words,
    proof: &Proof,
    shadow: usize,
    inputs: &Inputs,
    body: Block,
    finish: Block,
    incoming_item: Value,
    front: Window,
    back: Window,
    offset: &Item,
    ordinary: Block,
) {
    let params = b.block_params(body).to_vec();
    let front_width = i64::from(proof.arrays[front.array].width);
    let back_width = i64::from(proof.arrays[back.array].width);
    let base = words.read(b, shadow + proof.view(front.array));
    let displacement = b.ins().imul_imm(params[0], front_width);
    let forward = b.ins().iadd(base, displacement);
    let reverse = b.ins().iadd_imm(params[2], -back_width);
    let pointers = [
        (front, ScalarRead::LowWord(forward)),
        (back, ScalarRead::LowWord(reverse)),
    ];
    let cost = inputs.scalar(b, proof, &reduction.cost, params[0], &pointers);
    // The carried ordinal is one-based in the original source coordinates.
    // The existing stop <= U32::MAX guard proves it fits, even when the
    // forward read's biased coordinate crosses the U32 boundary. Zero is
    // reserved for the unchanged incoming winner.
    let ordinal = b.ins().iadd_imm(params[0], 1 - front.delta as i64);
    let first = pack(b, cost, ordinal);
    let done = b.create_block();
    b.append_block_param(done, types::I64);
    let paired = std::env::var_os("MECH_ORDERED_SCALAR_COST_KEY").as_deref()
        != Some(std::ffi::OsStr::new("single"));
    let (key, visited, prior) = if paired {
        let pair = b.create_block();
        let single = b.create_block();
        let two = b
            .ins()
            .icmp_imm(IntCC::UnsignedGreaterThanOrEqual, params[3], 2);
        b.ins().brif(two, pair, &[], single, &[]);
        b.switch_to_block(single);
        let key = b.ins().umin(first, params[1]);
        b.ins().jump(done, &[key.into()]);
        b.switch_to_block(pair);
        let second_index = b.ins().iadd_imm(ordinal, 1);
        let forward = b.ins().iadd_imm(forward, front_width);
        let reverse = b.ins().iadd_imm(reverse, -back_width);
        let pointers = [
            (front, ScalarRead::LowWord(forward)),
            (back, ScalarRead::LowWord(reverse)),
        ];
        // The two-visit branch proves both original candidates remain. No
        // extra element or allocation capacity is used as read authority.
        // The biased-item proof excludes direct ordinal uses in the cost.
        // Both reads use the explicit admitted second-element addresses.
        let cost = inputs.scalar(b, proof, &reduction.cost, params[0], &pointers);
        let second = pack(b, cost, second_index);
        let pair = b.ins().umin(first, second);
        (b.ins().umin(pair, params[1]), 2, reverse)
    } else {
        (b.ins().umin(first, params[1]), 1, reverse)
    };
    let next = b.ins().iadd_imm(params[0], visited);
    let left = b.ins().iadd_imm(params[3], -visited);
    let more = b.ins().icmp_imm(IntCC::NotEqual, left, 0);
    b.ins().brif(
        more,
        body,
        &[next.into(), key.into(), prior.into(), left.into()],
        done,
        &[key.into()],
    );
    b.switch_to_block(done);
    let key = b.block_params(done)[0];
    // Decode only after the loop. Carrying a decoded cost to its exit would
    // otherwise put that extraction back on every iteration's critical path.
    let cost = b.ins().ushr_imm(key, 32);
    let cost = b.ins().ireduce(types::I32, cost);
    let index = b.ins().ireduce(types::I32, key);
    let improved = b.ins().icmp_imm(IntCC::NotEqual, index, 0);
    let index = b.ins().iadd_imm(index, front.delta as i64 - 1);
    let index = b.ins().uextend(types::I64, index);
    let other = super::emit::emit_item_low32(b, words, proof, shadow, offset, index, ordinary);
    let index = b.ins().ireduce(types::I32, index);
    let item = b.ins().bor(index, other);
    let item = b.ins().uextend(types::I64, item);
    // A seed at the incoming cost never authorizes replacing its original
    // item. For improvements, unsigned key order also keeps the earliest
    // source ordinal on ties, including a winner in the vector prefix.
    let item = b.ins().select(improved, item, incoming_item);
    b.ins().jump(finish, &[cost.into(), item.into()]);
}
