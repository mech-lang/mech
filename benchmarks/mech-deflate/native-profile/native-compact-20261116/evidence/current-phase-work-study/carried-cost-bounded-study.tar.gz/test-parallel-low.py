from pathlib import Path
from hashlib import sha256
import datetime, json, os, shutil, subprocess, time

n = Path(__file__).resolve().parent
w = Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP')
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: sha256(Path(p).read_bytes()).hexdigest()
old = read(n / 'admitted-input-read-window-repository-tests/plan.json')
command = ['ordered_reduction' if arg == 'admitted_spans' else arg for arg in old['command']]
files = {path: sha(w / path) for path in read(n / 'parallel-low-source-files.json')}
out = n / 'parallel-low-repository-tests'
out.mkdir()
for path in files:
    target = out / 'source-inputs' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(w / path, target)
plan = {'command': command, 'environment': old['environment'], 'source_sha256': files,
        'start_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n')
start = time.monotonic()
with (out / 'test.log').open('w') as log:
    result = subprocess.run(command, cwd=w, env=os.environ | old['environment'], stdout=log, stderr=log)
assert all(sha(w / path) == pin for path, pin in files.items())
receipt = plan | {'exit_code': result.returncode, 'seconds': time.monotonic() - start,
                  'test_log_sha256': sha(out / 'test.log'), 'new_packed_key_native_calls': 94208, 'wide_item_native_calls': 16384, 'prior_winner_native_calls': 16384, 'paired_scalar_native_calls': 67584, 'narrow_packed_native_calls':101376, 'parallel_low_native_calls':30720}
(out / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('Ordered reduction tests', result.returncode, receipt['seconds'], flush=True)
assert result.returncode == 0, (out / 'test.log').read_text()[-7000:]
