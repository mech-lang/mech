"""Serial two-order panels against both the legacy pair and maintained eight-entry worker."""
from pathlib import Path
from hashlib import sha256
import json,os,sys
n=Path(__file__).resolve().parent;q=n.parent.parent
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
roles=sys.argv[1:] or ['parallel-low-packet-probe-profiled']
mode='selected63'
bases={role:('narrow-packet-eight-probe-profiled' if '-packet-' in role else 'narrow-eight-probe-profiled') for role in roles}
cases=['one-stored','seven-stored-prefix','empty','eight-overlap','320-overlap','prefix-periodic-1024','prefix-natural-1024','prefix-natural-4096','prefix-natural-8192','prefix-random-1024','prefix-random-4096','prefix-random-8192','prefix-random-16384','prefix-random-32767','prefix-random-32768','prefix-random-32769','prefix-random-65535','prefix-random-65536','prefix-random-65537','prefix-random-1048576','16384-distribution-change']
timer=q/'compare-library.py';prefix='parallel-low-'+mode+'-discovery';controls={role:n/bases[role]/'bound' for role in roles}
plan={'cases':cases,'roles':roles,'orders':['forward','reverse'],'blocks_per_case':24,'timer_sha256':sha(timer),'controller_sha256':sha(Path(__file__)),'control_worker_sha256_by_role':{role:sha(folder/'mech-worker') for role,folder in controls.items()},'control_folders':{role:str(folder) for role,folder in controls.items()},'load_before':os.getloadavg(),'scope':'Complete21-case discovery of proved parallel low-word carry versus its exact retained local-folding control; bounded evaluation before broad phase/work attribution, versus selected81/63 worker. '+mode+' head/tail control, same eight-case profile policy. Both code identities and all observations preserved; full81 confidence qualification is separate.'}
(n/(prefix+'-'+roles[0]+'-plan.json')).write_text(json.dumps(plan,indent=2)+'\n')
program=timer.read_text();needle="selected = {case['name'] for case in cases}";assert program.count(needle)==1;program=program.replace(needle,'selected = '+repr(set(cases)));runs=[]
for role in roles:
 for order in plan['orders']:
  label=prefix+'-'+role+'-'+order;bound=n/role/'bound';pin=read(bound/'runtime.json');assert sha(bound/'mech-worker')==pin['worker_sha256']
  sys.argv=[str(timer),label,str(controls[role]),str(bound)]+(['reverse'] if order=='reverse' else [])
  exec(compile(program,str(timer),'exec'),{'__file__':str(timer),'__name__':'__main__'})
  rows=read(q/label/'summary.json');assert len(rows)==len(cases)
  runs.append({'role':role,'order':order,'run':str(q/label),'summary_sha256':sha(q/label/'summary.json'),'results':rows})
  (n/(prefix+'-'+roles[0]+'-results.json')).write_text(json.dumps({'plan':plan,'runs':runs,'complete':len(runs)==len(roles)*2},indent=2)+'\n')
  for row in rows:
   if row['case'] in ['prefix-natural-4096','prefix-natural-8192','16384-distribution-change','320-overlap']:
    print(mode,role,order,row['case'],'C',row['paired_x_libdeflate']['mech-experiment'],'vsheld',row['paired_x_roc']['mech-experiment']/row['paired_x_roc']['mech-control'],flush=True)
