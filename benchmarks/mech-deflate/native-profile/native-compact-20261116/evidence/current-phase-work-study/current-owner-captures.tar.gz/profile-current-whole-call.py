"""Current exact-worker stack captures across the losing families; not a latency campaign."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import ast,json,os,re,subprocess,time
N=Path(__file__).resolve().parent;Q=N.parent.parent
P=Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/benchmarks/mech-deflate/native-profile/native-compact-20261116')
O=N/'current-phase-work-census';read=lambda p:json.loads(p.read_text());sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
fixtures=read(Q/'fixtures.json');peers=read(Q/'pinned-peers/pins.json');actors={}
for actor,role in [('mech-histogram','bounded-histogram-word'),('mech-selected63','narrow-packet-eight-probe-profiled'),('mech-sequential','narrow-packet-once-probe-profiled'),('mech-carried-cost','parallel-low-packet-probe-profiled')]:
 folder=N/role/'bound';pin=read(folder/'runtime.json');actors[actor]={'role':role,'command':[str(folder/'mech-worker'),str(folder/'metadata.json'),str(Q/'fixtures.json')],'worker_sha256':pin['worker_sha256'],'metadata_sha256':sha(folder/'metadata.json'),'kind':'mech'}
actors['libdeflate']={'command':peers['actors']['libdeflate']['command'],'worker_sha256':peers['actors']['libdeflate']['binary_sha256'],'kind':'libdeflate'}
cases=['prefix-natural-1024','prefix-natural-4096','prefix-natural-8192','prefix-random-4096','prefix-random-16384','prefix-random-65536','prefix-random-1048576','16384-distribution-change','320-overlap']
O.mkdir();plan={'cases':cases,'actors':actors,'sample_seconds':3,'interval_ms':1,'warmup_commands':24,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=P,text=True).strip(),'load_before':os.getloadavg(),'scope':'Stage1current exact-worker owner attribution. Five actors and nine cases, repeated fresh-construction-through-cleanup calls. Samples also include excluded preparation/validation. Named encoder roots have different scopes in Mech/C; these are not aligned phase elapsed times or forecasts. Stage2semantic work traces and captured-phase replay remain required.','requested_work_dimensions':['setup/cleanup allocations,mappings,firsttouch,retirement','collection positions,treevisits,comparedbytes,recordcounts,splits','DPpasses,literalpositions,candidateevaluations,choices,stopreasons','histograms,frequencyvectors,sortcomparisons/moves,codebookbuilds','outputitems/bytes,bitwriting,finaltransfer']}
(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
classifier=P/'evidence/history-and-profiles-20261119/analyze.py';nodes=[n for n in ast.parse(classifier.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='parse'];scope={'re':re,'Counter':Counter,'payload':lambda p:Path(p).read_bytes()};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(classifier),'exec'),scope);parse=scope['parse'];profiles={}
for name in cases:
 index=next(i for i,row in enumerate(fixtures) if row['name']==name);profiles[name]={}
 for actor,job in actors.items():
  assert sha(job['command'][0])==job['worker_sha256'];folder=O/name/actor;folder.mkdir(parents=True)
  with (folder/'stderr.log').open('w') as err,(folder/'protocol.log').open('w') as protocol:
   child=subprocess.Popen(job['command'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True)
   try:
    assert child.stdout.readline().strip()=='SESSION_READY';child.stdin.write(f'C\t{index}\t0\n');child.stdin.flush();assert child.stdout.readline().strip()==f'CASE_READY\t{name}'
    child.stdin.write('W'*24+'NN');child.stdin.flush();time.sleep(.4)
    sample=['/usr/bin/sample',str(child.pid),'3','1','-file',str(folder/'sample.txt')]
    with (folder/'sample.log').open('w') as log:captured=subprocess.run(sample,stdout=log,stderr=log)
    assert captured.returncode==0,(folder/'sample.log').read_text();rows=[]
    while True:
     line=child.stdout.readline();assert line,(name,actor,child.poll());protocol.write(line)
     if line.startswith('{'):rows.append(json.loads(line))
     if line.strip()==f'CASE_DONE\t{name}':break
    assert len(rows)==2 and all(all(row[k] for k in ['independent_inflation','input_alias_unchanged','borrowed_output_alias_unchanged']) for row in rows)
    child.stdin.write('Q\n');child.stdin.flush();assert child.wait(timeout=10)==0
   finally:
    if child.poll() is None:child.terminate();child.wait(timeout=10)
  try:stats=parse(folder/'sample.txt',job['kind'])
  except AssertionError as error:stats={'encoder_stack_samples':0,'scope_limited':str(error),'buckets':{},'reason':'The chosen encoder root is absent or too rarely sampled for this small/stored path; do not infer zero phase cost.'}
  fields=['payload_allocation_requests','requested_payload_bytes','initialized_bytes_copied','zeroed_bytes','peak_private_payload_bytes','nonreturned_private_bytes_at_return','input_bytes','prefix_bytes','raw_bytes']
  counters={k:rows[0][k] for k in fields if k in rows[0]};assert all(all(row[k]==value for k,value in counters.items()) for row in rows)
  record={'case':name,'actor':actor,'worker_sha256':job['worker_sha256'],'metadata_sha256':job.get('metadata_sha256'),'sample_command':sample,'sample_sha256':sha(folder/'sample.txt'),'sample_exit_code':captured.returncode,'verified_calls':rows,'allocation_snapshot':counters,'initialization_counter_meaning':'zeroed_bytes is requested initialized extent, not physical clearing or measured memset traffic; first-touch must be measured separately','stats':stats,'load_after':os.getloadavg()}
  (folder/'result.json').write_text(json.dumps(record,indent=2)+'\n');profiles[name][actor]=record
  (O/'summary.json').write_text(json.dumps({'plan':plan,'classifier_sha256':sha(classifier),'profiles':profiles,'complete':sum(len(x) for x in profiles.values())==len(cases)*len(actors)},indent=2)+'\n');print(name,actor,'root samples',stats['encoder_stack_samples'],{k:round(v['percent'],1) for k,v in stats['buckets'].items()},flush=True)
print('Stage1current owner captures complete. Semantic-phase alignment/work traces and replay are still pending.',flush=True)
