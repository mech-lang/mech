#![no_std]

extern crate alloc;
#[cfg(any(test, feature = "native-threads"))]
extern crate std;

pub mod native_artifact {
    pub mod compact_runtime;
}
