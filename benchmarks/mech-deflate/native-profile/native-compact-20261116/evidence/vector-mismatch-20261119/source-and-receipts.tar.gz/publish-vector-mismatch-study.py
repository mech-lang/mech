"""Publish vector mismatch forwarding and current scalar-word combinations."""
from pathlib import Path
from hashlib import sha256
import gzip
import io
import json
import subprocess
import tarfile

D = Path(__file__).resolve().parent
I = D.parent
Q = I.parent
W = Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP')
P = W / 'benchmarks/mech-deflate/native-profile/native-compact-20261116'
E = P / 'evidence/vector-mismatch-20261119'
E.mkdir(exist_ok=True)
read = lambda p: json.loads(Path(p).read_text())
digest = lambda p: sha256(Path(p).read_bytes()).hexdigest()


def archive(path, files):
    pins = {}
    with path.open('wb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
            with tarfile.open(mode='w', fileobj=zipped) as tar:
                for name, file in sorted(files.items()):
                    data = file.read_bytes()
                    info = tarfile.TarInfo(name)
                    info.size, info.mtime, info.mode = len(data), 0, 0o644
                    tar.addfile(info, io.BytesIO(data))
                    pins[name] = {'bytes': len(data), 'sha256': sha256(data).hexdigest()}
    return pins


campaigns = {}
raw_files = {'compare-library.py': Q / 'compare-library.py'}
for path in D.glob('vector-mismatch-clean-panel-*-results.json'):
    campaign = read(path)
    assert campaign['complete']
    campaigns[path.stem] = campaign
    for row in campaign['runs']:
        folder = Path(row['run'])
        for file in folder.rglob('*'):
            if file.is_file() and (file.name in ['observations.json.gz', 'summary.json', 'pins.json', 'pins.sha256'] or file.suffix == '.stderr'):
                raw_files[str(Path(folder.name) / file.relative_to(folder))] = file

roles = {row['role'] for campaign in campaigns.values() for row in campaign['runs']}
roles |= {p.parent.name for pattern in ['word-current*/receipt.json','word-reuse*/receipt.json','vector-mismatch*/receipt.json'] for p in D.glob(pattern)}
roots = set(roles) | {'vector-mismatch-compiler','vector-mismatch-unit-final','vector-mismatch-gpu-tests','vector-mismatch-matched-builds','byte-bounds-geometry-compiler'}
# The interrupted campaign is excluded; native tests and the failed full GPU build are retained.
for role in roles:
    path = D / role / 'linked-proof.json'
    if path.exists():
        roots.add(Path(read(path)['result']).relative_to(D).parts[0])
files = {}
for folder in sorted(roots):
    for file in (D / folder).rglob('*'):
        if not file.is_file():
            continue
        rel = file.relative_to(D)
        if 'compiler' in rel.parts and file.name == 'compile_profile':
            continue
        if file.suffix in ['.json', '.jsonl', '.py', '.log', '.rs', '.patch', '.txt', '.stderr', '.mec', '.allowlist'] or file.name.endswith('.json.gz') or file.name == 'samples.xml':
            files[str(rel)] = file
        elif file.name == 'program.o' and file.parent.name == 'frontend' and 'canonical-counter-input' not in rel.parts:
            files[str(rel)] = file
for file in D.glob('*.py'):
    files[file.name] = file
for name in ['vector-mismatch-clean-panel.log','vector-mismatch-matched-builds.log','vector-mismatch-runtime-interruption.json','vector-mismatch-clean-panel-process.json']:
    files[name] = D / name
files['canonical-program.mecb'] = D / 'vector-mismatch-control/frontend/program.mecb'
for file in D.glob('vector-mismatch-unsafe-audit.*'):
    files[file.name] = file
for file in D.glob('deployment-archive-*.json'):
    files[file.name] = file
for file in D.glob('deployment-archive-*.log'):
    files[file.name] = file
trial = Path('/private/tmp/mech-root-transport.A9Qtzt/mech-alloc-only/trial')
for root in [trial / 'source', trial / 'runtime']:
    for file in root.rglob('*'):
        if file.is_file() and (file.suffix == '.rs' or file.name in ['Cargo.toml', 'Cargo.lock']):
            files['deployment-support-source/' + str(file.relative_to(trial))] = file
for name in ['Cargo.toml', 'Cargo.lock', 'plan.json']:
    files['deployment-support-source/' + name] = trial / name

profiles = {}
cases = {}
for role in sorted(roles):
    receipt = read(D / role / 'receipt.json')
    cases[role] = {key: receipt[key] for key in ['text_bytes', 'artifacts', 'compiler_sha256']}
    cases[role]['receipt'] = role + '/receipt.json'
    for item in receipt['flags'].get('MECH_COMPACT_PHASE_BLOCK_LAYOUT', '').split(';'):
        if item:
            path = Path(item.split('@', 1)[1])
            pin = digest(path)
            profiles[str(path)] = pin
            files['portable-profiles/' + pin + '.json'] = path

source_commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
build = read(D / 'vector-mismatch-compiler/build.json')
identities = read(D / 'vector-mismatch-compiler/source-identities.json')
for name, pin in identities.items():
    assert digest(W / name) == pin
    assert sha256(subprocess.check_output(['git', 'show', source_commit + ':' + name], cwd=W)).hexdigest() == pin
study = {
    'live_source_commit': source_commit,
    'live_source_inputs': identities,
    'live_source_archive_prefix': 'vector-mismatch-compiler/source-inputs/',
    'live_compiler_sha256': build['compiler_sha256'],
    'objective': 'Earn the 63rd libdeflate runtime win while retaining every existing peer win and 81/81 Roc.',
    'qualified_selection': {'recipe': 'm1-immutable-current-reads', 'text_bytes': 63532, 'roc': 81, 'libdeflate': 62, 'worker_sha256': '834c7a7e423a69c46483a3dae74d9450949fdf142b5ad2dede894e0da3ca8693'},
    'experimental_promotions': [],
    'cases': cases,
    'profile_inputs': profiles,
    'campaigns': campaigns,
    'complete_builds': ['vector-mismatch-matched-builds'],
    'compiler_provenance': {
        build['compiler_sha256']: {'base': build['source_base'], 'committed_implementation': source_commit, 'overlay': 'vector-mismatch-compiler/source-inputs/'},
        '5bcc225bdcf5aea18dbe2c87b1d43284b98d3af804a2589875f9b78c03741157': {'base': '3da1be46552080131171bcabbeb43b02ec336e47', 'committed_implementation': '7259e858f3fc4a979c89378d3c73f45af4e6151c', 'overlay': 'byte-bounds-geometry-compiler/source-inputs/'},
    },
    'provenance_note': 'All latency workers are source-built. Scalar word-current cases use compiler 5bcc; new vector/word-reuse cases use 47ee. All fresh Mech build actors use current 47ee and must reproduce the timed artifacts exactly. The word-reuse strategy retains saved-prefix machinery where admitted; this codec has no admitted saved interval, so no cache hit or reused prefix is claimed.',
    'interruption': {'record': 'vector-mismatch-runtime-interruption.json', 'excluded_prefix': 'vector-mismatch-panel-', 'eligible_prefix': 'vector-mismatch-clean-panel-', 'reason': 'User-requested disk cleanup interrupted the first campaign. All its partial observations are ineligible.'},
    'deployment_support': {'restore_receipt': 'deployment-archive-restoration.json', 'archive_sha256': '6c29b7cba9eabe61caa31d406b3a31ceb4f4d1d835048065706eac6735e89ac2', 'scope': 'Cached fixed archive was rebuilt after authorized cleanup with its original standalone project settings. Initial offline and unrelated-worktree-configuration attempts are preserved, excluded from all codec timing, and not used. Final hash matches the original prebuilt support exactly.'},
    'full_gpu_test': {'result': 'vector-mismatch-gpu-tests/result.json', 'status': 'Build failed before tests: No space left on device while compiling the existing full-catalog mech-math dev dependency. Not a passing full GPU test result.'},
    'scope': 'Nineteen-case broad discovery, twenty-four balanced blocks per order. No full score or new peer win is claimed. Every latency input is an original-source emission; diagnostic counter clones are untimed. The codec and canonical bytecode are unchanged.',
}
pins = {'source-and-receipts.tar.gz': archive(E / 'source-and-receipts.tar.gz', files), 'raw-runtime.tar.gz': archive(E / 'raw-runtime.tar.gz', raw_files)}
(E / 'archive-files.json').write_text(json.dumps(pins, indent=2) + '\n')
(E / 'study.json').write_text(json.dumps(study, indent=2) + '\n')
print('Published', len(cases), 'emissions,', sum(len(c['runs']) for c in campaigns.values()), 'runtime orders,', len(files) + len(raw_files), 'archive entries', flush=True)
