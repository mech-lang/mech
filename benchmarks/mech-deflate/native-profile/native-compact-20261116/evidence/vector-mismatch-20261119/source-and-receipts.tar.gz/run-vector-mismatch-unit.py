from pathlib import Path
import json,subprocess,hashlib,sys
n=Path(__file__).resolve().parent;out=n/(sys.argv[1] if len(sys.argv)>1 else 'vector-mismatch-unit-fixed');out.mkdir();src=Path('hosts/gpu/src/native_artifact/program/codegen/wide_equal.rs').read_text()
def item(start):
 a=src.index(start);left=src.index('{',a);level=1;at=left+1
 while level:
  if src[at]=='{':level+=1
  elif src[at]=='}':level-=1
  at+=1
 return src[a:at]
old=n/'byte-edge-unit-transport';wrapper=(old/'tests.rs').read_text();a=wrapper.index('pub(super) fn masked_integer_comparison');b=wrapper.index('\npub mod word_ranges',a);mask=wrapper[a:b]
preamble='''mod native_artifact {pub mod program {pub mod codegen {
mod cfg_cleanup {use cranelift_codegen::ir::{Function,InstructionData as D,Opcode as O,Value,ValueDef,types};
'''+mask+'''\n}
mod wide_equal {
use super::cfg_cleanup::masked_integer_comparison;
use cranelift_codegen::{Context,cursor::{Cursor,FuncCursor}};
use cranelift_codegen::ir::{Block,BlockArg,Endianness,Function,Inst,InstBuilder,InstructionData as Data,MemFlags,Opcode,Value,ValueDef,types};
use cranelift_codegen::ir::condcodes::{CondCode,IntCC};
use std::collections::BTreeSet;
struct Certificate {header:Block,blocks:BTreeSet<Block>,source_header:usize,reuse_scope:Option<()>}
'''
parts=[item(s) for s in ['struct Resolve<','impl Resolve<','struct Trace {','fn trace(','#[derive(Clone, Copy)]\nstruct Change {','impl Change {','fn candidate(']]
file=Path('hosts/gpu/src/native_artifact/program/codegen/wide_equal_mismatch/mod.rs').resolve();text=preamble+'\n'.join(parts)+'\n#[path="'+str(file)+'"] mod mismatch;\n}}}}\n';(out/'tests.rs').write_text(text)
r=json.loads((old/'result.json').read_text());cmd=[str(out/'tests.rs') if x==str(old/'tests.rs') else str(out/'tests') if x==str(old/'tests') else x for x in r['command']]
pins={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in ['hosts/gpu/src/native_artifact/program/codegen/wide_equal.rs','hosts/gpu/src/native_artifact/program/codegen/wide_equal_mismatch/mod.rs','hosts/gpu/src/native_artifact/program/codegen/wide_equal_mismatch/tests.rs']}
with (out/'compile.log').open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=log)
assert p.returncode==0,(out/'compile.log').read_text()
with (out/'test.log').open('w') as log:p=subprocess.run([str(out/'tests'),'--nocapture'],stdout=log,stderr=log)
print((out/'test.log').read_text());assert p.returncode==0
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==pin for p,pin in pins.items()), 'Rust input changed during test build'
r['command']=cmd;r.update(tests=2,observations=1288960,refusal_fixtures=4,refusal_comparisons=60,scope='Exact production mismatch module and its tests, with exact Resolve, trace, candidate and Change source. Minimal Certificate fixture exercises admitted physical windows; production certificate construction is separately checked by the source-built codec.')
paths=['hosts/gpu/src/native_artifact/program/codegen/wide_equal.rs','hosts/gpu/src/native_artifact/program/codegen/wide_equal_mismatch/mod.rs','hosts/gpu/src/native_artifact/program/codegen/wide_equal_mismatch/tests.rs'];r['source_sha256']={name:hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in paths};r['harness_sha256']=hashlib.sha256((out/'tests.rs').read_bytes()).hexdigest();(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
