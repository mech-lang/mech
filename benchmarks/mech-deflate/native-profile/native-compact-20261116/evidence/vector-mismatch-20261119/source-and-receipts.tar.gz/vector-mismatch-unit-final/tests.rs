mod native_artifact {pub mod program {pub mod codegen {
mod cfg_cleanup {use cranelift_codegen::ir::{Function,InstructionData as D,Opcode as O,Value,ValueDef,types};
pub(super) fn masked_integer_comparison(
    f: &Function,
    instruction: &D,
    mut resolve: impl FnMut(Value) -> Option<Value>,
) -> Option<Value> {
    let D::BinaryImm64 {
        opcode: O::BandImm,
        arg,
        imm,
    } = *instruction
    else {
        return None;
    };
    if imm.bits() != 1 {
        return None;
    }
    let mut value = arg;
    for _ in 0..8 {
        value = resolve(value)?;
        let ValueDef::Result(definition, 0) = f.dfg.value_def(value) else {
            return None;
        };
        match f.dfg.insts[definition] {
            D::Unary {
                opcode: O::Uextend,
                arg,
            } => value = arg,
            D::IntCompare { .. } | D::IntCompareImm { .. }
                if f.dfg.value_type(value) == types::I8 =>
            {
                return Some(value);
            }
            _ => return None,
        }
    }
    None
}
}
mod wide_equal {
use super::cfg_cleanup::masked_integer_comparison;
use cranelift_codegen::{Context,cursor::{Cursor,FuncCursor}};
use cranelift_codegen::ir::{Block,BlockArg,Endianness,Function,Inst,InstBuilder,InstructionData as Data,MemFlags,Opcode,Value,ValueDef,types};
use cranelift_codegen::ir::condcodes::{CondCode,IntCC};
use std::collections::BTreeSet;
struct Certificate {header:Block,blocks:BTreeSet<Block>,source_header:usize,reuse_scope:Option<()>}
struct Resolve<'a> {
    context: &'a Context,
    header: Block,
}
impl Resolve<'_> {
    fn value(&self, mut value: Value) -> Option<Value> {
        let f = &self.context.func;
        let mut seen = BTreeSet::new();
        loop {
            value = f.dfg.resolve_aliases(value);
            if !seen.insert(value) {
                return None;
            }
            let ValueDef::Param(block, ordinal) = f.dfg.value_def(value) else {
                return Some(value);
            };
            if block == self.header {
                return Some(value);
            }
            let mut incoming = None;
            for pred in self.context.cfg.pred_iter(block) {
                for edge in f.dfg.insts[pred.inst]
                    .branch_destination(&f.dfg.jump_tables, &f.dfg.exception_tables)
                {
                    if edge.block(&f.dfg.value_lists) != block {
                        continue;
                    }
                    let current = edge.args(&f.dfg.value_lists).nth(ordinal)?.as_value()?;
                    if incoming.replace(current).is_some() {
                        return Some(value);
                    }
                }
            }
            let Some(next) = incoming else {
                return Some(value);
            };
            value = next;
        }
    }
    fn inst(&self, value: Value) -> Option<Inst> {
        let ValueDef::Result(inst, 0) = self.context.func.dfg.value_def(self.value(value)?) else {
            return None;
        };
        Some(inst)
    }
    fn constant(&self, value: Value) -> Option<u64> {
        let Data::UnaryImm {
            opcode: Opcode::Iconst,
            imm,
        } = self.context.func.dfg.insts[self.inst(value)?]
        else {
            return None;
        };
        Some(imm.bits() as u64)
    }
    fn invariant(&self, value: Value) -> Option<Value> {
        let value = self.value(value)?;
        let f = &self.context.func;
        let before = match f.dfg.value_def(value) {
            ValueDef::Result(inst, _) => {
                self.context.domtree.dominates(inst, self.header, &f.layout)
            }
            ValueDef::Param(block, _) => {
                block != self.header && self.context.domtree.block_dominates(block, self.header)
            }
            _ => false,
        };
        before.then_some(value)
    }
    fn add(&self, value: Value, at: Value, amount: u64) -> bool {
        let Some(inst) = self.inst(value) else {
            return false;
        };
        match self.context.func.dfg.insts[inst] {
            Data::Binary {
                opcode: Opcode::Iadd,
                args,
            } => {
                (self.value(args[0]) == Some(at) && self.constant(args[1]) == Some(amount))
                    || (self.value(args[1]) == Some(at) && self.constant(args[0]) == Some(amount))
            }
            Data::BinaryImm64 {
                opcode: Opcode::IaddImm,
                arg,
                imm,
            } => self.value(arg) == Some(at) && imm.bits() as u64 == amount,
            _ => false,
        }
    }
    fn comparison_mask(&self, inst: Inst) -> Option<Value> {
        let f = &self.context.func;
        masked_integer_comparison(f, &f.dfg.insts[inst], |value| self.value(value))
    }

    fn predicate(&self, mut value: Value, mut yes: bool) -> Option<(IntCC, Value, Value)> {
        let f = &self.context.func;
        let mut seen = BTreeSet::new();
        loop {
            value = self.value(value)?;
            if !seen.insert(value) {
                return None;
            }
            let inst = self.inst(value)?;
            match f.dfg.insts[inst] {
                Data::Unary {
                    opcode: Opcode::Uextend,
                    arg,
                } => value = arg,
                Data::IntCompare { cond, args, .. } => {
                    if matches!(cond, IntCC::Equal | IntCC::NotEqual) {
                        let (inner, constant) = if let Some(v) = self.constant(args[1]) {
                            (args[0], v)
                        } else if let Some(v) = self.constant(args[0]) {
                            (args[1], v)
                        } else {
                            return Some((
                                if yes { cond } else { cond.complement() },
                                self.value(args[0])?,
                                self.value(args[1])?,
                            ));
                        };
                        let inner_inst = self.inst(inner)?;
                        if constant <= 1
                            && matches!(
                                f.dfg.insts[inner_inst],
                                Data::Unary {
                                    opcode: Opcode::Uextend,
                                    ..
                                } | Data::IntCompare { .. }
                                    | Data::IntCompareImm { .. }
                            )
                        {
                            yes ^= (constant == 0) == (cond == IntCC::Equal);
                            value = inner;
                            continue;
                        }
                    }
                    return Some((
                        if yes { cond } else { cond.complement() },
                        self.value(args[0])?,
                        self.value(args[1])?,
                    ));
                }
                _ => value = self.comparison_mask(inst)?,
            }
        }
    }
}
struct Trace {
    blocks: BTreeSet<Block>,
    instructions: Vec<Inst>,
    end: Inst,
}
fn trace(f: &Function, cert: &Certificate, start: Block, back: bool) -> Option<Trace> {
    let mut block = start;
    let mut seen = BTreeSet::new();
    let mut instructions = Vec::new();
    loop {
        if !cert.blocks.contains(&block) || !seen.insert(block) {
            return None;
        }
        let end = f.layout.last_inst(block)?;
        instructions.extend(f.layout.block_insts(block).filter(|&i| i != end));
        match f.dfg.insts[end] {
            Data::Jump { destination, .. } => {
                block = destination.block(&f.dfg.value_lists);
                if back && block == cert.header {
                    return Some(Trace {
                        blocks: seen,
                        instructions,
                        end,
                    });
                }
            }
            Data::Brif { .. } if !back => {
                return Some(Trace {
                    blocks: seen,
                    instructions,
                    end,
                });
            }
            _ => return None,
        }
    }
}
#[derive(Clone, Copy)]
struct Change {
    entry: Inst,
    limit: Value,
    bases: [Value; 2],
    limit_check: Inst,
    limit_exit: Block,
    comparison: Inst,
    mismatch_edge: usize,
    difference: Value,
}
impl Change {
    fn initial(self, f: &Function, cert: &Certificate) -> Option<Value> {
        f.dfg.insts[self.entry]
            .branch_destination(&f.dfg.jump_tables, &f.dfg.exception_tables)
            .iter()
            .find(|edge| edge.block(&f.dfg.value_lists) == cert.header)?
            .args(&f.dfg.value_lists)
            .next()?
            .as_value()
    }
}
fn candidate(context: &Context, cert: &Certificate) -> Option<Change> {
    let f = &context.func;
    let &[at] = f.dfg.block_params(cert.header) else {
        return None;
    };
    if f.dfg.value_type(at) != types::I64 {
        return None;
    }
    let r = Resolve {
        context,
        header: cert.header,
    };
    let header = trace(f, cert, cert.header, false)?;
    let Data::Brif { arg, blocks, .. } = f.dfg.insts[header.end] else {
        return None;
    };
    if blocks[0].block(&f.dfg.value_lists) == blocks[1].block(&f.dfg.value_lists) {
        return None;
    }
    let (cc, sum, limit) = r.predicate(arg, true)?;
    let body_index = match cc {
        IntCC::UnsignedLessThanOrEqual => 0,
        IntCC::UnsignedGreaterThan => 1,
        _ => return None,
    };
    if !r.add(sum, at, 8) {
        return None;
    }
    let limit = r.invariant(limit)?;
    let body = trace(f, cert, blocks[body_index].block(&f.dfg.value_lists), false)?;
    let Data::Brif {
        arg,
        blocks: compared,
        ..
    } = f.dfg.insts[body.end]
    else {
        return None;
    };
    let (cc, a, b) = r.predicate(arg, true)?;
    let equal_index = match cc {
        IntCC::Equal => 0,
        IntCC::NotEqual => 1,
        _ => return None,
    };
    let difference = if r.constant(b) == Some(0) {
        a
    } else if r.constant(a) == Some(0) {
        b
    } else {
        return None;
    };
    let Data::Binary {
        opcode: Opcode::Bxor,
        args,
    } = f.dfg.insts[r.inst(difference)?]
    else {
        return None;
    };
    let mut bases = Vec::new();
    for value in args {
        let inst = r.inst(value)?;
        if f.dfg.value_type(f.dfg.inst_results(inst)[0]) != types::I64 {
            return None;
        }
        let Data::Load {
            arg, offset, flags, ..
        } = f.dfg.insts[inst]
        else {
            return None;
        };
        if i32::from(offset) != 0 || flags.endianness(Endianness::Little) != Endianness::Little {
            return None;
        }
        let Data::Binary {
            opcode: Opcode::Iadd,
            args,
        } = f.dfg.insts[r.inst(arg)?]
        else {
            return None;
        };
        let base = if r.value(args[0])? == at {
            r.invariant(args[1])?
        } else if r.value(args[1])? == at {
            r.invariant(args[0])?
        } else {
            return None;
        };
        bases.push(base);
    }
    let back = trace(
        f,
        cert,
        compared[equal_index].block(&f.dfg.value_lists),
        true,
    )?;
    let Data::Jump { destination, .. } = f.dfg.insts[back.end] else {
        return None;
    };
    let args = destination.args(&f.dfg.value_lists).collect::<Vec<_>>();
    if args.len() != 1 || !r.add(args[0].as_value()?, at, 8) {
        return None;
    }
    // The cycle must contain only exactly these pure scalar predicates,
    // addresses, equality and immutable loads. No debit/store/call/check can be
    // bypassed. A sole induction phi excludes an observed extra carried value.
    let loads = body
        .instructions
        .iter()
        .filter(|&&i| f.dfg.insts[i].opcode() == Opcode::Load)
        .count();
    if loads != 2 {
        return None;
    }
    for inst in header
        .instructions
        .iter()
        .chain(&body.instructions)
        .chain(&back.instructions)
    {
        if !matches!(
            f.dfg.insts[*inst].opcode(),
            Opcode::Iconst
                | Opcode::Iadd
                | Opcode::IaddImm
                | Opcode::Icmp
                | Opcode::Uextend
                | Opcode::Bxor
                | Opcode::Load
        ) && r.comparison_mask(*inst).is_none()
        {
            return None;
        }
        if f.dfg.insts[*inst].opcode() == Opcode::Load && !body.instructions.contains(inst) {
            return None;
        }
    }
    // Exactly one initial edge and the proved equal backedge. Do not redirect
    // an additional traversal whose entry facts have not been established.
    let incoming = context
        .cfg
        .pred_iter(cert.header)
        .map(|pred| pred.inst)
        .collect::<BTreeSet<_>>();
    if incoming.len() != 2
        || !incoming.contains(&back.end)
        || incoming.iter().any(|&inst| {
            inst != back.end && context.domtree.dominates(cert.header, inst, &f.layout)
        })
    {
        return None;
    }
    Some(Change {
        entry: incoming.into_iter().find(|&inst| inst != back.end)?,
        limit,
        bases: bases.try_into().ok()?,
        limit_check: header.end,
        limit_exit: blocks[1 - body_index].block(&f.dfg.value_lists),
        comparison: body.end,
        mismatch_edge: 1 - equal_index,
        difference,
    })
}
#[path="/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP/hosts/gpu/src/native_artifact/program/codegen/wide_equal_mismatch/mod.rs"] mod mismatch;
}}}}
