"""Publish source-built admitted-read bounds sharing and its repair."""
from pathlib import Path
from hashlib import sha256
import gzip
import io
import json
import subprocess
import tarfile

D = Path(__file__).resolve().parent
I = D.parent
Q = I.parent
W = Path('/Users/coreymontella/.codex/worktrees/pr995-runtime-integration/mech-shared-cold-epilogues.2L6obP')
P = W / 'benchmarks/mech-deflate/native-profile/native-compact-20261116'
E = P / 'evidence/compared-byte-bounds-20261119'
E.mkdir(exist_ok=True)
read = lambda p: json.loads(Path(p).read_text())
digest = lambda p: sha256(Path(p).read_bytes()).hexdigest()


def archive(path, files):
    pins = {}
    with path.open('wb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
            with tarfile.open(mode='w', fileobj=zipped) as tar:
                for name, file in sorted(files.items()):
                    data = file.read_bytes()
                    info = tarfile.TarInfo(name)
                    info.size, info.mtime, info.mode = len(data), 0, 0o644
                    tar.addfile(info, io.BytesIO(data))
                    pins[name] = {'bytes': len(data), 'sha256': sha256(data).hexdigest()}
    return pins


campaigns = {}
raw_files = {'compare-library.py': Q / 'compare-library.py'}
for path in D.glob('byte-bounds-geometry-panel-*-results.json'):
    campaign = read(path)
    assert campaign['complete']
    campaigns[path.stem] = campaign
    for row in campaign['runs']:
        folder = Path(row['run'])
        for file in folder.rglob('*'):
            if file.is_file() and (file.name in ['observations.json.gz', 'summary.json', 'pins.json', 'pins.sha256'] or file.suffix == '.stderr'):
                raw_files[str(Path(folder.name) / file.relative_to(folder))] = file

roles = {row['role'] for campaign in campaigns.values() for row in campaign['runs']}
roles |= {p.parent.name for p in D.glob('byte-bounds-*/receipt.json')}
roots = set(roles) | {p.name for p in D.glob('byte-bounds-*') if p.is_dir()}
# Both the failed temporary-SSA prototype and the repaired geometry source are archived.
for role in roles:
    path = D / role / 'linked-proof.json'
    if path.exists():
        roots.add(Path(read(path)['result']).relative_to(D).parts[0])
files = {}
for folder in sorted(roots):
    for file in (D / folder).rglob('*'):
        if not file.is_file():
            continue
        rel = file.relative_to(D)
        if 'compiler' in rel.parts and file.name == 'compile_profile':
            continue
        if file.suffix in ['.json', '.jsonl', '.py', '.log', '.rs', '.patch', '.txt', '.stderr', '.mec'] or file.name.endswith('.json.gz') or file.name == 'samples.xml':
            files[str(rel)] = file
        elif file.name == 'program.o' and file.parent.name == 'frontend' and 'canonical-counter-input' not in rel.parts:
            files[str(rel)] = file
for file in D.glob('*.py'):
    files[file.name] = file
for name in ['byte-bounds-geometry-panel.log', 'byte-bounds-geometry-matched-builds.log']:
    files[name] = D / name
files['canonical-program.mecb'] = D / 'byte-bounds-geometry-control/frontend/program.mecb'

profiles = {}
cases = {}
for role in sorted(roles):
    receipt = read(D / role / 'receipt.json')
    cases[role] = {key: receipt[key] for key in ['text_bytes', 'artifacts', 'compiler_sha256']}
    cases[role]['receipt'] = role + '/receipt.json'
    for item in receipt['flags'].get('MECH_COMPACT_PHASE_BLOCK_LAYOUT', '').split(';'):
        if item:
            path = Path(item.split('@', 1)[1])
            pin = digest(path)
            profiles[str(path)] = pin
            files['portable-profiles/' + pin + '.json'] = path

source_commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
build = read(D / 'byte-bounds-geometry-compiler/build.json')
identities = read(D / 'byte-bounds-geometry-compiler/source-identities.json')
for name, pin in identities.items():
    assert digest(W / name) == pin
    assert sha256(subprocess.check_output(['git', 'show', source_commit + ':' + name], cwd=W)).hexdigest() == pin
study = {
    'live_source_commit': source_commit,
    'live_source_inputs': identities,
    'live_source_archive_prefix': 'byte-bounds-geometry-compiler/source-inputs/',
    'live_compiler_sha256': build['compiler_sha256'],
    'objective': 'Earn the 63rd libdeflate runtime win while retaining every existing peer win and 81/81 Roc.',
    'qualified_selection': {'recipe': 'm1-immutable-current-reads', 'text_bytes': 63532, 'roc': 81, 'libdeflate': 62, 'worker_sha256': '834c7a7e423a69c46483a3dae74d9450949fdf142b5ad2dede894e0da3ca8693'},
    'experimental_promotions': [],
    'cases': cases,
    'profile_inputs': profiles,
    'campaigns': campaigns,
    'complete_builds': ['byte-bounds-geometry-matched-builds'],
    'compiler_provenance': {
        build['compiler_sha256']: {'base': build['source_base'], 'committed_implementation': source_commit, 'overlay': 'byte-bounds-geometry-compiler/source-inputs/'},
        '3b415338563dabc2dc521bff652ec90e90d51024167f626a95c11c41191109b4': {'base': '3da1be46552080131171bcabbeb43b02ec336e47', 'overlay': 'byte-bounds-compiler/source-inputs/', 'scope': 'First temporary-SSA prototype. Disabled and old-byte modes reproduce previous artifacts. The new mode failed during compilation, was repaired, and contributes no runtime observations.'},
    },
    'provenance_note': 'Geometry receipts identify the actual compiler base and complete overlay. The initial prototype failure and its repair are both retained. All timed geometry cases use the repaired source compiler.',
    'scope': 'Nineteen-case broad discovery, twenty-four balanced blocks per order. No full score or new peer win is claimed. Every latency input is an original-source emission; diagnostic counter clones are untimed. The codec and canonical bytecode are unchanged.',
}
pins = {'source-and-receipts.tar.gz': archive(E / 'source-and-receipts.tar.gz', files), 'raw-runtime.tar.gz': archive(E / 'raw-runtime.tar.gz', raw_files)}
(E / 'archive-files.json').write_text(json.dumps(pins, indent=2) + '\n')
(E / 'study.json').write_text(json.dumps(study, indent=2) + '\n')
print('Published', len(cases), 'emissions,', sum(len(c['runs']) for c in campaigns.values()), 'runtime orders,', len(files) + len(raw_files), 'archive entries', flush=True)
