use mech_gpu::native_artifact::compact_runtime::{Heap, NativeStatus, OwnerStorage, View};
use serde::Deserialize;
use std::{
    collections::BTreeMap,
    io::{BufRead, Write},
    time::{Duration, Instant},
};

#[path = "pinned_allocator.rs"]
mod pinned_allocator;

#[global_allocator]
static ALLOCATOR: pinned_allocator::PinnedMimalloc = pinned_allocator::PinnedMimalloc;

unsafe extern "C" {
    fn mech_compact_closed_v2(
        context: *mut std::ffi::c_void,
        input: *const u64,
        output: *mut u64,
    ) -> NativeStatus;
}

#[derive(Deserialize)]
struct Case {
    name: String,
    input: String,
    prefix: String,
    expected: String,
    capacity: usize,
}

struct PortLayout {
    words: usize,
    input: usize,
    output: usize,
}

impl PortLayout {
    fn read(metadata: &serde_json::Value) -> Self {
        assert_eq!(metadata["symbol"], "mech_compact_closed_v2");
        assert_eq!(metadata["output_words"], 6);
        let words = metadata["input_words"].as_u64().unwrap() as usize;
        let ports = metadata["inputs"].as_array().unwrap();
        assert_eq!(ports.len(), 2);
        let offset = |source_name| {
            let mut matches = ports.iter().filter(|port| {
                mech_engine::decode_source_input_name(port["name"].as_str().unwrap()).unwrap()
                    == source_name
            });
            let at = matches.next().unwrap()["input_offset"].as_u64().unwrap() as usize;
            assert!(matches.next().is_none());
            assert!(at.checked_add(6).unwrap() <= words);
            at
        };
        let input = offset("input");
        let output = offset("output");
        assert!(input.abs_diff(output) >= 6);
        Self {
            words,
            input,
            output,
        }
    }
}

struct Slot {
    input: Vec<u8>,
    current: Vec<u8>,
    arguments: Vec<u64>,
    output: View,
}

type Counters = [u64; 6];

struct Outcome {
    status: NativeStatus,
    returned: Option<Vec<u8>>,
    counters: Counters,
}

fn borrowed_view(backing: &Vec<u8>) -> View {
    [
        backing.as_ptr() as u64,
        backing.len() as u64,
        backing.capacity() as u64,
        1,
        backing.len() as u64,
        0,
    ]
}

impl Slot {
    fn new(input: &Vec<u8>, capacity: usize, ports: &PortLayout) -> Self {
        let mut input_copy = Vec::with_capacity(input.capacity());
        input_copy.extend_from_slice(input);
        assert_eq!(input_copy.capacity(), input.capacity());
        Self {
            input: input_copy,
            current: Vec::with_capacity(capacity),
            arguments: vec![0; ports.words],
            output: [0; 6],
        }
    }

    fn prepare(&mut self, prefix: &[u8], capacity: usize, ports: &PortLayout) {
        self.current.clear();
        self.current.extend_from_slice(prefix);
        assert_eq!(self.current.capacity(), capacity);
        self.output.fill(0);
        self.arguments[ports.input..ports.input + 6].copy_from_slice(&borrowed_view(&self.input));
        self.arguments[ports.output..ports.output + 6]
            .copy_from_slice(&borrowed_view(&self.current));
    }

    fn invoke(&mut self) -> Outcome {
        let mut storage = OwnerStorage::default();
        let mut heap = Heap::with_owner_storage(&mut storage);
        // SAFETY: the bound linked entry has two immutable U8 input views.
        // Both allocations remain live in the prepared slot. The fresh
        // invocation-local heap and output slot outlive the native call.
        let status = unsafe {
            mech_compact_closed_v2(
                (&mut heap as *mut Heap).cast(),
                self.arguments.as_ptr(),
                self.output.as_mut_ptr(),
            )
        };
        let returned = if status.status == 0 {
            // SAFETY: the linked success path returned the heap's final U8
            // view. take_u8 checks its exact geometry and sole ownership.
            Some(unsafe { heap.take_u8(self.output) }.expect("sole final output ownership"))
        } else {
            None
        };
        let counters = [
            heap.counters.payload_requests,
            heap.counters.requested_payload_bytes,
            heap.counters.initialized_bytes_copied,
            heap.counters.zeroed_bytes,
            heap.counters.peak_payload_bytes,
            heap.counters.live_payload_bytes,
        ];
        drop(heap);
        Outcome {
            status,
            returned,
            counters,
        }
    }
}

struct Batch<'a> {
    case: &'a Case,
    ports: &'a PortLayout,
    input: Vec<u8>,
    prefix: Vec<u8>,
    expected: Vec<u8>,
    slots: Vec<Slot>,
    outcomes: Vec<Outcome>,
}

impl<'a> Batch<'a> {
    fn new(case: &'a Case, ports: &'a PortLayout, len: usize) -> Self {
        let input = std::fs::read(&case.input).unwrap();
        let prefix = std::fs::read(&case.prefix).unwrap();
        let expected = std::fs::read(&case.expected).unwrap();
        assert!(prefix.len() < expected.len() && expected.len() <= case.capacity);
        assert!(expected.starts_with(&prefix));
        assert_eq!(
            miniz_oxide::inflate::decompress_to_vec(&expected[prefix.len()..]).unwrap(),
            input
        );
        let slots = (0..len)
            .map(|_| Slot::new(&input, case.capacity, ports))
            .collect();
        Self {
            case,
            ports,
            input,
            prefix,
            expected,
            slots,
            outcomes: Vec::with_capacity(len),
        }
    }

    fn read_clock(&mut self, counts: &mut BTreeMap<Counters, usize>) -> u64 {
        for slot in &mut self.slots {
            slot.prepare(&self.prefix, self.case.capacity, self.ports);
        }
        assert!(self.outcomes.is_empty());
        assert!(self.outcomes.capacity() >= self.slots.len());

        // The result array has capacity for all outcomes. This interval
        // includes the group loop, result writes and each full invocation
        // through the heap drop. Borrow setup and validation occur outside it.
        let start = Instant::now();
        self.outcomes
            .extend(self.slots.iter_mut().map(Slot::invoke));
        let elapsed_ns = u64::try_from(start.elapsed().as_nanos()).unwrap();

        assert_eq!(self.outcomes.len(), self.slots.len());
        for (slot, outcome) in self.slots.iter().zip(&self.outcomes) {
            assert_eq!(
                outcome.status.status, 0,
                "{}: native status {} at origin {}",
                self.case.name, outcome.status.status, outcome.status.origin
            );
            assert_eq!(
                outcome.counters[5], 0,
                "nonreturned payload must retire before heap drop"
            );
            let returned = outcome.returned.as_ref().unwrap();
            assert_eq!(*returned, self.expected);
            assert_eq!(returned.capacity(), self.case.capacity);
            assert_eq!(
                miniz_oxide::inflate::decompress_to_vec(&returned[self.prefix.len()..]).unwrap(),
                self.input
            );
            assert_eq!(slot.input, self.input);
            assert_eq!(slot.current, self.prefix);
            assert_ne!(returned.as_ptr(), slot.current.as_ptr());
            assert_ne!(returned.as_ptr(), slot.input.as_ptr());
            *counts.entry(outcome.counters).or_default() += 1;
        }
        // Each lane borrows its previous result on the next group. Keep all
        // current aliases live until every timed invocation has validated.
        for (slot, outcome) in self.slots.iter_mut().zip(self.outcomes.drain(..)) {
            slot.current = outcome.returned.unwrap();
        }
        elapsed_ns
    }
}

fn run(
    case: &Case,
    ports: &PortLayout,
    blocks: usize,
    readings: usize,
    per_read: usize,
    reader: &mut impl BufRead,
) {
    assert!(blocks > 0 && readings > 0 && (1..=1024).contains(&per_read));
    assert!(readings.checked_mul(per_read).unwrap() <= 8192);
    let mut batch = Batch::new(case, ports, per_read);
    println!("CASE_READY\t{}", case.name);
    std::io::stdout().flush().unwrap();

    let mut next = 0;
    while next < blocks {
        let mut command = [0];
        reader.read_exact(&mut command).unwrap();
        let mut counts = BTreeMap::new();
        match command[0] {
            b'W' => {
                let start = Instant::now();
                let mut groups = 0;
                while start.elapsed() < Duration::from_millis(200) {
                    batch.read_clock(&mut counts);
                    groups += 1;
                }
                let elapsed_ns = u64::try_from(start.elapsed().as_nanos()).unwrap();
                assert_eq!(counts.values().sum::<usize>(), groups * per_read);
                println!(
                    "WARMUP_DONE\t{}\t{}\t{elapsed_ns}",
                    case.name,
                    groups * per_read
                );
            }
            b'N' => {
                let clock_ns: Vec<_> = (0..readings)
                    .map(|_| batch.read_clock(&mut counts))
                    .collect();
                let validated_calls = counts.values().sum::<usize>();
                assert_eq!(validated_calls, readings * per_read);
                let row = serde_json::json!({
                    "case": case.name,
                    "sequence": next,
                    "calls_per_reading": per_read,
                    "elapsed_ns": clock_ns,
                    "validated_calls": validated_calls,
                    "input_bytes": batch.input.len(),
                    "prefix_bytes": batch.prefix.len(),
                    "raw_bytes": batch.expected.len() - batch.prefix.len(),
                    "capacity": case.capacity,
                    "exact_reference": true,
                    "independent_inflation": true,
                    "input_alias_unchanged": true,
                    "borrowed_output_alias_unchanged": true,
                    "counter_counts": counts.into_iter().collect::<Vec<_>>(),
                });
                println!("{row}");
                next += 1;
            }
            other => panic!("invalid case command byte {other}"),
        }
        std::io::stdout().flush().unwrap();
    }
    drop(batch);
    println!("CASE_DONE\t{}", case.name);
    std::io::stdout().flush().unwrap();
}

fn main() {
    let args: Vec<_> = std::env::args_os().skip(1).collect();
    assert_eq!(args.len(), 2);
    let metadata = serde_json::from_slice(&std::fs::read(&args[0]).unwrap()).unwrap();
    let ports = PortLayout::read(&metadata);
    let cases: Vec<Case> = serde_json::from_slice(&std::fs::read(&args[1]).unwrap()).unwrap();

    let mut reader = std::io::BufReader::new(std::io::stdin());
    println!("BATCH_SESSION_READY");
    std::io::stdout().flush().unwrap();
    loop {
        let mut line = String::new();
        assert!(reader.read_line(&mut line).unwrap() > 0);
        if line == "Q\n" {
            break;
        }
        let fields: Vec<_> = line.trim_end().split('\t').collect();
        let ["C", case, blocks, readings, per_read] = fields.as_slice() else {
            panic!("invalid case selection {line:?}");
        };
        run(
            &cases[case.parse::<usize>().unwrap()],
            &ports,
            blocks.parse().unwrap(),
            readings.parse().unwrap(),
            per_read.parse().unwrap(),
            &mut reader,
        );
    }
    eprintln!("CLEANUP private_payload_bytes=0 live_owner_records=0");
}
