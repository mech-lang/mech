"""Calibrate short Mech calls with separate one-call and batch-clock cohorts."""

import argparse
from collections import Counter, defaultdict
from hashlib import file_digest
from itertools import permutations
import json
from math import log, sqrt
import os
from pathlib import Path
import platform
from random import Random
from time import monotonic
import shutil
import subprocess
import sys

ACTORS = ("control", "duplicate-control", "candidate")
ORDERS = tuple(permutations(ACTORS))
CASES = ("empty", "one-stored", "seven-stored-prefix", "random-64")
CLEANUP = "CLEANUP private_payload_bytes=0 live_owner_records=0"
PROTOCOL = "prepared-slots-batch-clock-diagnostic-v1"
LEGACY = {"control": "mech-control", "candidate": "mech-experiment"}
BENCHMARK = Path("benchmarks/mech-deflate/native-profile/native-compact-20261116")
HERE = Path(__file__).resolve().parent


def digest(path):
    with Path(path).open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def pin(path):
    path = Path(path).resolve(strict=True)
    return {"path": str(path), "sha256": digest(path)}


def read(path):
    return json.loads(Path(path).read_text())


def create(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def acquire_environment():
    hardware, = json.loads(subprocess.check_output(
        ["/usr/sbin/system_profiler", "SPHardwareDataType", "-json"], text=True,
    ))["SPHardwareDataType"]
    return {
        "arch": platform.machine(),
        "os": subprocess.check_output(["/usr/bin/sw_vers"], text=True).strip(),
        "cpu": hardware["chip_type"],
        "device_model": hardware["machine_model"],
        "core_configuration": hardware["number_processors"],
        "python": platform.python_version(),
        "clock": "Rust std::time::Instant",
        "execution": "Serial full actor permutations, separate validated 200 ms warmups",
        "locale": "C",
        "timezone": "UTC",
        "removed_environment_keys": ("DYLD_*", "MECH_*", "LD_PRELOAD", "LD_LIBRARY_PATH"),
    }


def child_environment():
    return {
        **{name: value for name, value in os.environ.items()
           if not name.startswith(("DYLD_", "MECH_"))
           and name not in ("LD_PRELOAD", "LD_LIBRARY_PATH")},
        "LC_ALL": "C",
        "TZ": "UTC",
    }


def fixture_inventory(packet, policy):
    inventory = packet / "fixtures.json"
    assert digest(inventory) == policy["fixture_inventory_sha256"]
    rows = read(inventory)
    assert len(rows) == policy["named_cases"] == len({row["name"] for row in rows})
    for row in rows:
        hashes = [row["input_sha256"], Path(row["prefix"]).name, row["expected_sha256"]]
        for key, expected in zip(("input", "prefix", "expected"), hashes, strict=True):
            file = (packet / row[key]).resolve(strict=True)
            assert file.is_relative_to(packet) and digest(file) == expected, (row["name"], key)
            row[key] = str(file)
        prefix = Path(row["prefix"]).read_bytes()
        expected = Path(row["expected"]).read_bytes()
        assert expected.startswith(prefix) and len(prefix) == row["prefix_bytes"]
        assert len(expected) - len(prefix) == row["raw_bytes"] > 0
        assert Path(row["input"]).stat().st_size == row["input_bytes"]
    return rows


def relink(study, prior, label, folder, env):
    prior_key = LEGACY[label]
    legacy = {name: pin(folder / name) for name in ("program.o", "metadata.json", "runtime.json", "mech-worker")}
    for name, item in legacy.items():
        assert item["sha256"] == prior["bindings"][prior_key][name]["sha256"], (label, name)
    copied = study / label
    copied.mkdir()
    for name in ("program.o", "metadata.json"):
        shutil.copyfile(folder / name, copied / name)
        assert digest(copied / name) == legacy[name]["sha256"]
    old_command = read(folder / "runtime.json")["link"]
    assert old_command[:2] == ["rustc", "+nightly-2026-03-03"]
    command = old_command.copy()
    command[command.index(str(folder / "mech-worker"))] = str(copied / "batch-worker")
    object_arg = f"link-arg={folder / 'program.o'}"
    command[command.index(object_arg)] = f"link-arg={copied / 'program.o'}"
    worker, = [arg for arg in old_command if arg.endswith("/mech-worker.rs")]
    assert digest(Path(worker).with_name("pinned_allocator.rs")) == digest(study / "source/pinned_allocator.rs")
    command[command.index(worker)] = str(study / "source/batch_worker.rs")
    providers = []
    for arg in command:
        name = arg.split("=", 1)[-1]
        if name.startswith("/") and Path(name).is_file():
            providers.append(pin(name))
    with (copied / "build.log").open("x") as log_file:
        subprocess.run(command, env=env, stdout=log_file, stderr=subprocess.STDOUT, check=True)
    assert all(digest(item["path"]) == item["sha256"] for item in providers)
    return {
        "legacy": legacy,
        "command": command,
        "direct_link_inputs": providers,
        "object": pin(copied / "program.o"),
        "metadata": pin(copied / "metadata.json"),
        "worker": pin(copied / "batch-worker"),
    }


def schedule(selected, epochs, groups, blocks_per_order, calls, seed):
    rng = Random(seed)
    runs = []
    for epoch in range(epochs):
        cells = [(name, group) for name in selected for group in groups]
        rng.shuffle(cells)
        for case, group in cells:
            orders = list(ORDERS) * blocks_per_order
            warm = list(ACTORS)
            rng.shuffle(orders)
            rng.shuffle(warm)
            assert calls % group == 0
            runs.append({"epoch": epoch, "case": case, "warmup_order": warm,
                         "orders": orders, "calls_per_reading": group, "readings_per_block": calls // group})
    return runs


def prepare(study, repo, smoke):
    q = repo / ".qualification"
    packet = q / "native-review-pr/staging" / BENCHMARK
    historical = packet / "evidence/bound-71768-runtime"
    prior = read(historical / "plan.json")
    assert digest(historical / "plan.json") == (historical / "plan.sha256").read_text().strip()
    policy_file = packet / "qualification-policy-v1.json"
    assert digest(policy_file) == prior["policy"]["sha256"]
    policy = read(policy_file)
    assert (policy["runtime_resolution"], policy["bootstrap_coverage"], policy["bootstrap_resamples"]) == (0.005, 0.90, 8000)
    fixtures = fixture_inventory(packet, policy)
    study.mkdir()
    source = study / "source"
    source.mkdir()
    for file in (Path(__file__), HERE / "batch_worker.rs", q / "pinned-host-link/pinned_allocator.rs",
                 policy_file, packet / "qualification_records.py", packet / "qualification_timings.py"):
        shutil.copyfile(file, source / file.name)
    env = child_environment()
    actors = {
        "control": relink(study, prior, "control", q / "stale-cache-accounting/pinned-smaller", env),
        "candidate": relink(study, prior, "candidate", q / "native-size-20261117/source-aligned", env),
    }
    dup = study / "duplicate-control"
    dup.mkdir()
    for name in ("program.o", "metadata.json", "batch-worker"):
        shutil.copy2(study / "control" / name, dup / name)
    actors["duplicate-control"] = {
        "object": pin(dup / "program.o"), "metadata": pin(dup / "metadata.json"), "worker": pin(dup / "batch-worker"),
    }
    for key in ("object", "metadata", "worker"):
        assert actors["control"][key]["sha256"] == actors["duplicate-control"][key]["sha256"]
    assert len({actor["worker"]["sha256"] for actor in actors.values()}) == 2
    identities = [(p.st_dev, p.st_ino) for p in (
        Path(actor["worker"]["path"]).stat() for actor in actors.values()
    )]
    assert len(set(identities)) == 3

    environment = acquire_environment()
    assert environment["arch"] == "arm64" and environment["cpu"] == "Apple M1"
    create(study / "environment.json", environment)
    create(study / "fixtures.json", fixtures)
    create(study / "contract.json", {
        "protocol": PROTOCOL,
        "underlying_contract": read(historical / "contract.json"),
        "interval": "Prepared independent lanes. Clock includes the loop, reusable result writes and "
                    "each complete invocation through heap drop. Prior outputs stay live through validation. "
                    "Construction of caller buffers, arguments and output slots, validation and final output release are outside the clock.",
        "previous_receipt": pin(historical / "full-and-repeat-replay.json"),
        "previous_clock_quantization": pin(historical / "clock-quantization.json"),
        "decision_scope": "Diagnostic two-protocol A/A calibration. Qualified scores and decisions stay attached to their original workers and protocol.",
        "native_encoder_revision": "197ad8ff1272a9f411bd56f14f08efabba2553cd",
    })
    plan = {
        "protocol": PROTOCOL,
        "scope": "smoke" if smoke else "calibration",
        "previous_plan": pin(historical / "plan.json"),
        "environment": pin(study / "environment.json"),
        "contract": pin(study / "contract.json"),
        "sources": {file.name: pin(file) for file in sorted(source.iterdir())},
        "actors": actors,
        "fixtures": pin(study / "fixtures.json"),
        "compiler": subprocess.check_output(["rustc", "+nightly-2026-03-03", "-Vv"], text=True).strip(),
        "blocks_per_order": 1 if smoke else 32,
        "calls_per_actor_block": 16 if smoke else 2048,
        "groups": [1, 16] if smoke else [1, 256],
        "epochs": 1 if smoke else 2,
        "cases": list(CASES),
        "acquisition_seed": 9937176843,
        "bootstrap_seed": 9937176844,
        "stability_rule": "A/A bounds within +/-0.5% in both epochs and pooled, per case and clock arm.",
    }
    plan["runs"] = schedule(plan["cases"], plan["epochs"], plan["groups"], plan["blocks_per_order"],
                            plan["calls_per_actor_block"], plan["acquisition_seed"])
    create(study / "plan.json", plan)
    with (study / "plan.sha256").open("x") as stream:
        stream.write(digest(study / "plan.json") + "\n")
    print("Predeclared", study, digest(study / "plan.json"), flush=True)


def pinned_plan(study):
    p = study / "plan.json"
    assert digest(p) == (study / "plan.sha256").read_text().strip()
    plan = read(p)
    assert plan["protocol"] == PROTOCOL
    local = {"contract.json": plan["contract"], "environment.json": plan["environment"],
             "fixtures.json": plan["fixtures"]}
    local.update({f"source/{name}": entry for name, entry in plan["sources"].items()})
    for name, item in local.items():
        assert digest(study / name) == item["sha256"], name
    assert digest(__file__) == plan["sources"]["campaign.py"]["sha256"]
    assert plan["runs"] == json.loads(json.dumps(schedule(
        plan["cases"], plan["epochs"], plan["groups"], plan["blocks_per_order"],
        plan["calls_per_actor_block"], plan["acquisition_seed"],
    )))
    return plan


class Worker:
    def __init__(self, actor, fixtures, log_file, env):
        self.buffer = b""
        self.proc = subprocess.Popen(
            [actor["worker"]["path"], actor["metadata"]["path"], fixtures],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=log_file,
            env=env,
        )

    def send(self, commands):
        self.proc.stdin.write(commands.encode("ascii"))
        self.proc.stdin.flush()

    def receive(self):
        from select import select

        deadline = monotonic() + 60
        while b"\n" not in self.buffer:
            timeout = max(0., deadline - monotonic())
            assert select([self.proc.stdout], [], [], timeout)[0], "no worker reply in 60 seconds"
            chunk = os.read(self.proc.stdout.fileno(), 65536)
            assert chunk, ("truncated worker reply", self.proc.poll(), self.buffer)
            self.buffer += chunk
        line, self.buffer = self.buffer.split(b"\n", 1)
        return line.decode("utf-8")

    def case(self, index, fixture, blocks, readings, group):
        self.send(f"C\t{index}\t{blocks}\t{readings}\t{group}\n")
        assert self.receive() == f"CASE_READY\t{fixture}"

    def close(self):
        if self.proc.poll() is None:
            self.proc.terminate()
            self.proc.wait(timeout=10)
        self.proc.stdin.close()
        self.proc.stdout.close()


def validate(row, fixture, sequence, group, readings):
    assert row["case"] == fixture["name"] and row["sequence"] == sequence
    assert row["calls_per_reading"] == group and row["validated_calls"] == group * readings
    for key in ("input_bytes", "prefix_bytes", "capacity", "raw_bytes"):
        assert row[key] == fixture[key], (fixture["name"], key)
    for key in ("exact_reference", "independent_inflation", "input_alias_unchanged", "borrowed_output_alias_unchanged"):
        assert row[key] is True, (fixture["name"], key)
    times = row["elapsed_ns"]
    assert len(times) == readings and all(type(t) is int and t >= 0 for t in times)
    counters = row["counter_counts"]
    assert counters and len({tuple(values) for values, _ in counters}) == len(counters)
    for values, count in counters:
        assert len(values) == 6 and all(type(v) is int and v >= 0 for v in values)
        assert values[-1] == 0 and type(count) is int and count > 0
    assert sum(count for _, count in counters) == group * readings


def collect(study, smoke):
    from contextlib import ExitStack

    plan = pinned_plan(study)
    recorded = read(study / "environment.json")
    assert json.loads(json.dumps(acquire_environment())) == recorded
    inode_pairs = set()
    for actor in plan["actors"].values():
        for item in (actor["object"], actor["metadata"], actor["worker"], *actor.get("direct_link_inputs", [])):
            assert digest(item["path"]) == item["sha256"], item["path"]
        info = Path(actor["worker"]["path"]).stat()
        inode_pairs.add((info.st_dev, info.st_ino))
    assert len(inode_pairs) == 3
    fixtures = read(study / "fixtures.json")
    for fixture in fixtures:
        for key, expected in (("input", fixture["input_sha256"]), ("prefix", Path(fixture["prefix"]).name),
                              ("expected", fixture["expected_sha256"])):
            assert digest(fixture[key]) == expected, (fixture["name"], key)
    by_name = {fixture["name"]: (index, fixture) for index, fixture in enumerate(fixtures)}

    output = study / ("smoke" if smoke else "acquisition")
    output.mkdir()
    mode = "all-81-call-checks" if smoke else "clock-observations"
    create(output / "receipt.json", {
        "protocol": PROTOCOL,
        "plan_sha256": digest(study / "plan.json"),
        "mode": mode,
        "worker_inodes": sorted(inode_pairs),
    })
    env = child_environment()
    with ExitStack() as stack:
        raw = stack.enter_context((output / "observations.jsonl").open("x", buffering=1))
        warm = stack.enter_context((output / "warmups.jsonl").open("x", buffering=1))
        workers = {}
        for actor in ACTORS:
            stderr = stack.enter_context((output / f"{actor}.stderr").open("x"))
            worker = Worker(plan["actors"][actor], plan["fixtures"]["path"], stderr, env)
            stack.callback(worker.close)
            assert worker.receive() == "BATCH_SESSION_READY"
            workers[actor] = worker

        if smoke:
            runs = [{"case": case["name"], "orders": [ACTORS], "warmup_order": [],
                     "calls_per_reading": 1, "readings_per_block": 1} for case in fixtures]
        else:
            runs = plan["runs"]
        for run_index, run in enumerate(runs):
            fixture_index, fixture = by_name[run["case"]]
            group, readings = run["calls_per_reading"], run["readings_per_block"]
            for actor in ACTORS:
                workers[actor].case(fixture_index, run["case"], len(run["orders"]), readings, group)
            for actor in run["warmup_order"]:
                workers[actor].send("W")
                reply = workers[actor].receive()
                warm.write(json.dumps({"run": run_index, "actor": actor, "reply": reply}) + "\n")
                marker, name, calls, ns = reply.split("\t")
                assert marker == "WARMUP_DONE" and name == run["case"]
                assert int(calls) >= group and int(calls) % group == 0 and int(ns) >= 200_000_000
            for sequence, order in enumerate(run["orders"]):
                for actor in order:
                    worker = workers[actor]
                    worker.send("N")
                    reply = worker.receive()
                    raw.write(json.dumps({"run": run_index, "actor": actor, "reply": reply}, separators=(",", ":")) + "\n")
                    validate(json.loads(reply), fixture, sequence, group, readings)
            for actor in ACTORS:
                assert workers[actor].receive() == f"CASE_DONE\t{run['case']}"
            if not smoke:
                print(f"Acquired epoch {run['epoch'] + 1} {run['case']} with {group} calls per reading", flush=True)

        for worker in workers.values():
            worker.send("Q\n")
            assert worker.proc.wait(timeout=30) == 0
    assert all((output / f"{actor}.stderr").read_text().strip().endswith(CLEANUP) for actor in ACTORS)
    create(output / "complete.json", {
        "plan_sha256": digest(study / "plan.json"),
        "mode": mode,
        "runs": len(runs),
        "observations": pin(output / "observations.jsonl"),
        "warmups": pin(output / "warmups.jsonl"),
        "cleanup": {actor: pin(output / f"{actor}.stderr") for actor in ACTORS},
    })


def replay(study):
    plan = pinned_plan(study)
    output = study / "acquisition"
    complete = read(output / "complete.json")
    assert complete["plan_sha256"] == digest(study / "plan.json")
    assert complete["mode"] == "clock-observations" and complete["runs"] == len(plan["runs"])
    for key in ("observations", "warmups"):
        assert digest(output / f"{key}.jsonl") == complete[key]["sha256"]
    assert set(complete["cleanup"]) == set(ACTORS)
    for actor, done in complete["cleanup"].items():
        log_file = output / f"{actor}.stderr"
        assert digest(log_file) == done["sha256"]
        assert log_file.read_text().strip().endswith(CLEANUP)

    sys.path.insert(0, str(study / "source"))
    from qualification_timings import interval
    policy = read(study / "source/qualification-policy-v1.json")
    resolution = policy["runtime_resolution"]
    fixtures = {fixture["name"]: fixture for fixture in read(study / "fixtures.json")}
    cells = defaultdict(list)
    seed = plan["bootstrap_seed"]
    with (output / "observations.jsonl").open() as stream, (output / "warmups.jsonl").open() as warm:
        for run_index, run in enumerate(plan["runs"]):
            stats = {actor: Counter() for actor in ACTORS}
            group, readings = run["calls_per_reading"], run["readings_per_block"]
            fixture = fixtures[run["case"]]
            for actor in run["warmup_order"]:
                record = json.loads(next(warm))
                assert record["run"] == run_index and record["actor"] == actor
                token, name, count, elapsed = record["reply"].split("\t")
                assert token == "WARMUP_DONE" and name == run["case"]
                assert int(count) >= group and int(count) % group == 0 and int(elapsed) >= 200_000_000

            strata = {kind: {order: [] for order in ORDERS} for kind in ("aa", "ab")}
            for sequence, order in enumerate(run["orders"]):
                order = tuple(order)
                elapsed = {}
                for actor in order:
                    raw = json.loads(next(stream))
                    assert raw["run"] == run_index and raw["actor"] == actor
                    row = json.loads(raw["reply"])
                    validate(row, fixture, sequence, group, readings)
                    times = row["elapsed_ns"]
                    elapsed[actor] = sum(times)
                    stats[actor].update(times)
                control, duplicate, candidate = (elapsed[actor] for actor in ACTORS)
                assert min(control, duplicate, candidate) > 0, (run_index, sequence, elapsed)
                strata["aa"][order].append(log(duplicate / control))
                strata["ab"][order].append(log(candidate / sqrt(control * duplicate)))
            assert all(len(rows) == plan["blocks_per_order"] for kind in strata.values() for rows in kind.values())
            intervals = {kind: interval(list(rows.values()), seed + run_index, policy) for kind, rows in strata.items()}
            quantization = {
                actor: {"readings": counts.total(),
                        "zero_or_one_24mhz_tick": sum(counts[t] for t in (0, 41, 42)),
                        "mean_ns_per_call": sum(ns * n for ns, n in counts.items()) / (group * counts.total())}
                for actor, counts in stats.items()
            }
            row = {"epoch": run["epoch"], "intervals": intervals, "quantization": quantization}
            cells[(run["case"], group)].append((row, strata))
        assert not stream.readline() and not warm.readline()

    report = {}
    for cell_index, ((case, group), runs) in enumerate(sorted(cells.items())):
        assert {row["epoch"] for row, _ in runs} == set(range(plan["epochs"]))
        pooled = {
            kind: interval([values for _, strata in runs for values in strata[kind].values()],
                           seed + len(plan["runs"]) + cell_index, policy)
            for kind in ("aa", "ab")
        }
        rows = [row for row, _ in runs]
        aa = [row["intervals"]["aa"] for row in rows] + [pooled["aa"]]
        stable = all(b["lower"] >= -resolution and b["upper"] <= resolution for b in aa)
        ab = [row["intervals"]["ab"] for row in rows] + [pooled["ab"]]
        relation = ("unresolved AA" if not stable else
                    "candidate regression" if any(b["lower"] > resolution for b in ab) else
                    "candidate bounded" if all(b["upper"] <= resolution for b in ab) else "unresolved AB")
        report.setdefault(case, {})[str(group)] = {
            "runs": rows, "pooled": pooled, "aa_stable": stable, "candidate_relation": relation,
        }
    create(output / "replay.json", {
        "plan_sha256": digest(study / "plan.json"),
        "completion_sha256": digest(output / "complete.json"),
        "scope": "Diagnostic protocol. The existing qualification decision stays bound to its original protocol.",
        "resolution": resolution,
        "coverage": policy["bootstrap_coverage"],
        "resamples": policy["bootstrap_resamples"],
        "cases": report,
    })
    print(json.dumps({
        case: {group: {key: row[key] for key in ("aa_stable", "candidate_relation", "pooled")}
               for group, row in groups.items()}
        for case, groups in report.items()
    }, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("prepare", "checks", "acquire", "replay"))
    parser.add_argument("study", type=Path)
    parser.add_argument("--repo", type=Path, default=Path("/private/tmp/mech-shared-cold-epilogues.2L6obP"))
    parser.add_argument("--smoke-plan", action="store_true")
    args = parser.parse_args()
    study = args.study.resolve()
    if args.action == "prepare":
        prepare(study, args.repo.resolve(strict=True), args.smoke_plan)
    elif args.action == "replay":
        replay(study)
    else:
        assert not args.smoke_plan
        collect(study, args.action == "checks")
