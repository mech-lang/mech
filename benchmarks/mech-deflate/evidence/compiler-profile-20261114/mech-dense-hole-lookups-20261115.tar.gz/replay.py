from pathlib import Path
import hashlib
import json
import re
import statistics
import subprocess
import sys

packet = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_text())
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
state = read(packet / 'source-state.json')
selection = packet / 'selection'
profile_configuration = read(selection / 'configuration.json')
assert profile_configuration['source_commit'] == 'd26cf2c65eac2f5978cabba257bb8bebbe4b0a80'
assert profile_configuration['head'] == state['base_commit']
assert profile_configuration['compiler']['sha256'] == '5a1687ef2d82a3f73d8e04328e99dc72372498a215266d1d5ba1ec56bb71700e'
profile_results = read(selection / 'results.json')
assert len(profile_results) == 2 and all(r['all_outputs_match'] and r['excluded_from_primary'] and r['process']['exit_code'] == 0 for r in profile_results)
ssa_disassembly = (selection / 'ssa-hot-disassembly.txt').read_text()
assert re.search(r'100133cf4:\s+add\s+x9, x9, #8', ssa_disassembly)
assert re.search(r'100133cfc:\s+b\s+0x100133cc8', ssa_disassembly)
for name, image_base, caller_return_pc in [('sample-1',0x104540000,0x104673cf4),('sample-2',0x102908000,0x102a3bcf4)]:
    assert caller_return_pc - image_base + 0x100000000 == 0x100133cf4
    assert hex(caller_return_pc) in (selection / name / 'sample-001.txt').read_text()
subprocess.run([sys.executable,str(selection / 'analyze.py'),str(selection)],check=True,stdout=subprocess.PIPE)
assert pin(packet / 'candidate.patch')['sha256'] == state['patch_sha256']
for row in state['files']:
    assert pin(packet / 'reference-source' / row['path'])['sha256'] == row['sha256']
    assert pin(packet / 'candidate-source' / row['path'])['sha256'] == row['candidate_sha256']
commit_path = packet / 'qualification-commit.json'
commit = read(commit_path) if commit_path.exists() else dict(source_commit=None)
if commit_path.exists():
    assert commit['parent'] == state['base_commit']
    assert commit['entire_commit_diff_sha256'] == state['patch_sha256']
    assert commit['entire_commit_diff_matches_measured_patch']
excluded = read(packet / 'excluded-products.json')
assert excluded['control']['sha256'] == 'b72ff590c3ea6760f9a77372ba2bb6761f3b2d2885cdbef029ee040509bb51ba'
assert read(packet / 'candidate-build.json')['binary_sha256'] == excluded['candidate']['sha256']
for name in ['candidate-check', 'candidate-build', 'candidate-cli-check']:
    row = read(packet / (name + '.json'))
    assert row['exit_code'] == 0 and row['patch_sha256'] == state['patch_sha256']
assert read(packet / 'focused/build.json')['exit_code'] == read(packet / 'focused/test.json')['exit_code'] == 0
assert 'test result: ok. 29 passed; 0 failed' in (packet / 'focused/test.stdout.log').read_text()
for variant in ['reference','candidate']:
    assert (packet / (variant+'.rs')).read_bytes() == (packet / 'focused' / (variant+'.rs')).read_text().replace('use super::SSABuilder;','use crate::ssa::SSABuilder;').encode()
ir = read(packet / 'ir-comparison/result.json')
assert ir['paired_cases'] == 304 and ir['verified_functions'] == 608
assert pin(packet / 'ir-comparison/cases.jsonl')['sha256'] == ir['cases_sha256']
assert read(packet / 'ir-comparison/build.json')['exit_code'] == read(packet / 'ir-comparison/test.json')['exit_code'] == 0
assert read(packet / 'ir-comparison/test.json')['binary_sha256'] == excluded['ir-comparison/probe']['sha256']
ir_cases = [json.loads(line) for line in (packet / 'ir-comparison/cases.jsonl').read_text().splitlines()]
assert len(ir_cases) == 304 and all(r['identical'] for r in ir_cases)
for row in ir_cases:
    assert all(key in row['observation'] for key in ['raw_ir','raw_queries','raw_variable_definitions','raw_value_count','ir','queries','machine','effects'])
flags = read(packet / 'runtime-flags.json')
assert len(flags) == 61
reference = {name:pin(packet / 'reference' / name) for name in ['source.mec','program.mecb','program.o','metadata.json']}
native = read(packet / 'native-baseline-pins.json')
exe = native['executable']
assert exe == dict(bytes=2060440,sha256='d6c65cc3fb18acc4be77dce329962105bf0f2b56dd2623a12f466256463eca61')
capture = read(packet / 'link-command.json')
inputs = read(packet / 'native-link-inputs.json')
assert [(r['source'],r['bytes'],r['sha256']) for r in inputs] == [(r['source'],r['bytes'],r['sha256']) for r in capture['inputs']]
for row in inputs:
    assert pin(packet / row['path']) == {k:row[k] for k in ['bytes','sha256']}
for variant in ['control','candidate']:
    directory = packet / (variant + '-screen')
    assert read(directory / 'process.json')['exit_code'] == 0
    for name, item in reference.items():
        assert pin(directory / name) == item and (directory / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    assert pin(packet / ('link-' + variant) / 'worker') == exe
gates = read(packet / 'final-executable-results.json')
assert len(gates) == 2 and all(r['exit_code'] == 0 and r['matches_complete_baseline_executable'] and r['executable_sha256'] == exe['sha256'] for r in gates)
fixtures = read(packet / 'fixture-results.json')
assert len(fixtures) == 14
for row in fixtures:
    assert row['all_outputs_match'] and row['variants']['control'] == row['variants']['candidate']
    for variant in ['control','candidate']:
        entry = row['variants'][variant]
        assert entry['exit_code'] == 0 and len(entry['files']) == 4
        name = Path(row['fixture'].split(':')[-1]).stem
        directory = packet / 'fixtures' / name / variant
        for filename, item in entry['files'].items():
            assert pin(directory / filename) == item
            assert (directory / filename).read_bytes() == (packet / 'fixtures' / name / 'control' / filename).read_bytes()
rows = read(packet / 'cohort.json')
assert len(rows) == 8
order = ['control-1','candidate-1','candidate-2','control-2','candidate-3','control-3','control-4','candidate-4']
assert [r['name'] for r in rows] == order
for row in rows:
    directory = packet / row['name']
    assert row['compile'] == read(directory / 'compile.json') and row['process'] == read(directory / 'process.json')
    assert row['process']['exit_code'] == 0
    command = read(packet / (row['name'] + '-command.json'))
    assert command['binary_sha256'] == excluded[row['variant']]['sha256']
    assert command['flags'] == dict(flags, MECH_COMPACT_COMPILE_THREADS='2')
    for name, item in reference.items():
        assert pin(directory / name) == item and (directory / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    stamps = [json.loads(line) for line in (directory / 'stages.jsonl').read_text().splitlines()]
    for key, begin, end in [('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code'),('compaction_seconds','compact-stage: compact values before=','compact-stage: CFG cleanup')]:
        assert row[key] == next(s['elapsed'] for s in stamps if s['line'].startswith(end)) - next(s['elapsed'] for s in stamps if s['line'].startswith(begin))
    assert row['cleanup_including_compaction_seconds'] == row['cleanup_seconds'] + row['compaction_seconds']
    log = (directory / 'stderr.log').read_text()
    for key, pattern in [('max_rss_bytes',r'(\d+)  maximum resident set size'),('instructions',r'(\d+)  instructions retired'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]:
        assert row[key] == int(re.search(pattern,log).group(1))
fields = dict(compiler_seconds=lambda r:r['compile']['total_seconds'],whole_process_seconds=lambda r:r['process']['elapsed_seconds'])
for phase in ['parse','catalog','frontend','artifact','encode','native']:
    fields[phase+'_seconds'] = lambda r,p=phase: next(v['seconds'] for v in r['compile']['phases'] if v['phase']==p)
for key in ['canonical_lowering_seconds','preparation_seconds','numeric_generation_seconds','source_cfg_seconds','cleanup_including_compaction_seconds','cleanup_seconds','compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:
    fields[key] = lambda r,k=key:r[k]
summary = {}
for key, fn in fields.items():
    values = {v:[fn(r) for r in rows if r['variant']==v] for v in ['control','candidate']}
    base = statistics.mean(values['control'])
    values['mean_reduction_fraction'] = 1-statistics.mean(values['candidate'])/base if base else None
    summary[key] = values
assert read(packet / 'numerical-summary.json') == summary
native_path = packet / 'native-cohort.json'
native_rows = read(native_path) if native_path.exists() else []
assert len(native_rows) in [0,8]
native_summary = {}
for row in native_rows:
    directory = packet / row['name']
    receipt = read(directory / 'result.json')
    assert row == dict(receipt, name=row['name'], primary_cohort=True)
    assert row['compiler_exit_code'] == row['link_exit_code'] == 0 and row['matches_complete_baseline_executable']
    assert row['executable_bytes'] == exe['bytes'] and row['executable_sha256'] == exe['sha256'] and pin(directory / 'worker') == exe
    for name, item in reference.items():
        assert pin(directory / name) == item and (directory / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    assert abs(row['source_to_executable_seconds']-sum(row[k] for k in ['source_to_object_process_seconds','object_handoff_seconds','native_link_seconds'])) < 1e-8
if native_rows:
    for key in ['source_to_executable_seconds','source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']:
        values = {v:[r[key] for r in native_rows if r['variant']==v] for v in ['control','candidate']}
        values['mean_reduction_fraction'] = 1-statistics.mean(values['candidate'])/statistics.mean(values['control'])
        native_summary[key] = values
    blocks = []
    for block in [native_rows[:4],native_rows[4:]]:
        means = {v:statistics.mean(r['source_to_executable_seconds'] for r in block if r['variant']==v) for v in ['control','candidate']}
        means['mean_reduction_fraction'] = 1-means['candidate']/means['control']
        blocks.append(means)
    saved = read(packet / 'native-numerical-summary.json')
    assert saved['numerical_summary'] == native_summary and saved['balanced_blocks'] == blocks
else:
    blocks = []
if (packet / 'candidate-serial-gate').exists():
    serial = packet / 'candidate-serial-gate'
    assert read(serial / 'process.json')['exit_code'] == 0
    for name, item in reference.items():
        assert pin(serial / name) == item and (serial / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    serial_result = read(packet / 'link-candidate-serial/result.json')
    assert serial_result['matches_complete_baseline_executable'] and serial_result['executable_sha256'] == exe['sha256']
    assert pin(packet / 'link-candidate-serial/worker') == exe
result = dict(source_commit=commit['source_commit'],base_commit=state['base_commit'],patch_sha256=state['patch_sha256'],compiler=excluded,source_state=state,numerical_summary=summary,native_numerical_summary=native_summary,balanced_native_blocks=blocks,output_hashes=reference,final_executable=exe,fixture_pairs=14,focused_tests=29,paired_ir=ir,selection_profile=profile_results,checks={name:read(packet/(name+'.json')) for name in ['candidate-check','candidate-build','candidate-cli-check']},decision=read(packet/'decision.json'),scope='Dense prefix holes return absence without redundant sparse-map probes, using unchanged promotion invariant. Same storage/layout/thresholds/SSA scheduling/value creation,61flags/two workers/pinnedmimalloc. StandardB72 control versus standardcandidate, no PGO/nativeCPU. SelectedPGO5a1 profile diagnostics remain separate and excluded from primary means. Complete output/metadata/whole-exe identity required. No grammar/proof/program-runtime change or sub-ten-second claim.')
encoded = json.dumps(result,indent=2,sort_keys=True)+'\n'
saved = packet / 'summary.json'
if saved.exists():
    assert saved.read_text() == encoded
else:
    saved.write_text(encoded)
print(encoded,end='')
