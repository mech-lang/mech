#![allow(dead_code)]
extern crate alloc;
pub use cranelift_frontend::Variable;
#[path="reference.rs"] mod reference;
#[path="candidate.rs"] mod candidate;
