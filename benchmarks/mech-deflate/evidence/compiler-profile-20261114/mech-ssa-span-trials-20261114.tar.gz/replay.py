from pathlib import Path
import json,hashlib,re,statistics,tomllib
root=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
def pin(p):
 data=p.read_bytes();return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
state=read(root/'source-state.json');assert not state['production_changes_retained'] and state['production_source_restored'] and state['control_production_source_identical_to_base']
prior=read(root/'validation/qualified-nested-parser.json');receipt=read(root/'validation/qualified-nested-parser.archive.json');assert pin(root/'validation/qualified-nested-parser.json')['sha256']==receipt['replay_sha256'];expected=prior['output_hashes']
excluded={r['path']:r for r in read(root/'excluded-executables.json')}
stage_fields=[('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]
host_fields=[('max_rss_bytes',r'(\d+)  maximum resident set size'),('instructions',r'(\d+)  instructions retired'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]
order=['control-1','candidate-1','candidate-2','control-2','candidate-3','control-3','control-4','candidate-4']
def validate_cohort(raw,flags,expected,pins,key):
 rows=read(raw/'cohort.json');assert [r['name'] for r in rows]==order
 for name in ['control-screen','candidate-screen',*order]:
  variant=name.split('-')[0];d=raw/name;process=read(d/'process.json');assert process['exit_code']==0 and process['samples']==0 and process['sampling_error'] is None
  command=read(raw/(name+'-command.json'));assert command['flags']==flags and command['binary_sha256']==pins[variant]
  for filename,pinned in expected.items():assert pin(d/filename)==pinned and read(d/'output-check.json')[filename]==dict(pinned,**{key:True})
 for row in rows:
  d=raw/row['name'];assert row['compile']==read(d/'compile.json') and row['process']==read(d/'process.json') and row['files']==read(d/'output-check.json')
  assert row['variant']==row['name'].split('-')[0]
  stamps=[json.loads(line) for line in (d/'stages.jsonl').read_text().splitlines()]
  for field,begin,end in stage_fields:assert row[field]==next(s['elapsed'] for s in stamps if s['line'].startswith(end))-next(s['elapsed'] for s in stamps if s['line'].startswith(begin))
  for field,pattern in host_fields:assert row[field]==int(re.search(pattern,(d/'stderr.log').read_text()).group(1))
  if True:
   begin=next(s for s in stamps if s['line'].startswith('compact-stage: compact values before='));end=next(s for s in stamps if s['line'].startswith('compact-stage: CFG cleanup'));assert row['compaction_seconds']==end['elapsed']-begin['elapsed'];assert row['value_ids_before']==int(begin['line'].split('=')[-1])==20787570;assert row['value_ids_after']==int(next(s['line'] for s in stamps if s['line'].startswith('compact-values: retained=')).split('=')[-1])==1241393
  else:assert row['compaction_seconds']==0
  assert row['cleanup_including_compaction_seconds']==row['cleanup_seconds']+row['compaction_seconds']
 fixtures=read(raw/'fixture-results.json');assert len(fixtures)==14
 for record in fixtures:
  assert record['all_outputs_match'] and record['variants']['control']==record['variants']['candidate'] and record['variants']['control']['exit_code']==0 and len(record['variants']['control']['files'])==4
  name=Path(record['fixture']).stem if ':' not in record['fixture'] else record['fixture'].split(':')[-1]
  for variant,result in record['variants'].items():
   d=raw/'fixtures'/name/variant;command=read(d/'command.json');assert command['flags']==flags and command['binary_sha256']==pins[variant]
   for filename,pinned in result['files'].items():assert pin(d/filename)==pinned
   assert result['files']['source.mec']['sha256']==record['source_sha256']
 base=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase.mec').read_text();fragment=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase-states.mec').read_text();assembled=base.replace('+> sequence\n','+> sequence\n'+fragment+'\n',1).replace('phase-candidates(values, 1u64, 0u64, permitted, divisor)','#PhaseCandidates(values, permitted, divisor, 1u64, 0u64)',1);assert assembled==(raw/'fixture-inputs/numeric-nested-phase-states.mec').read_text()
 fields={'compiler_seconds':lambda r:r['compile']['total_seconds'],'whole_process_seconds':lambda r:r['process']['elapsed_seconds']}
 for phase in ['parse','catalog','frontend','artifact','encode','native']:fields[phase+'_seconds']=lambda r,p=phase:next(v['seconds'] for v in r['compile']['phases'] if v['phase']==p)
 for field in [f[0] for f in stage_fields]+['cleanup_including_compaction_seconds','compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:fields[field]=lambda r,k=field:r[k]
 qualified={field:{v:[fn(r) for r in rows if r['variant']==v] for v in ['control','candidate']} for field,fn in fields.items()}
 for values in qualified.values():
  mean=statistics.mean(values['control']);values['mean_reduction_fraction']=1-statistics.mean(values['candidate'])/mean if mean else None
 assert qualified==read(raw/'numerical-summary.json')
 blocks=[]
 for block in [rows[:4],rows[4:]]:
  blocks.append(dict(order=[r['name'] for r in block],compiler_mean_reduction_fraction=1-statistics.mean(r['compile']['total_seconds'] for r in block if r['variant']=='candidate')/statistics.mean(r['compile']['total_seconds'] for r in block if r['variant']=='control')))
 return dict(flags_count=len(flags),qualified=qualified,blocks=blocks,output_hashes=expected,compiler_binary_sha256=pins,fixture_output_comparisons=fixtures)


def apply_source_patch(base,patch):
 lines=base.splitlines(keepends=True);out=[];cursor=0;diff=patch.splitlines(keepends=True);assert sum(line.startswith('diff --git ') for line in diff)==1
 i=0
 while i<len(diff):
  match=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',diff[i])
  if not match:i+=1;continue
  at=int(match[1])-1;assert at>=cursor;out.extend(lines[cursor:at]);cursor=at;old_count=0;new_count=0;i+=1
  while i<len(diff) and not diff[i].startswith('@@ '):
   line=diff[i];tag=line[:1];assert tag in [' ','+','-']
   if tag in [' ','-']:assert lines[cursor]==line[1:];cursor+=1;old_count+=1
   if tag in [' ','+']:out.append(line[1:]);new_count+=1
   i+=1
  assert old_count==int(match[2] or 1) and new_count==int(match[4] or 1)
 out.extend(lines[cursor:]);return ''.join(out)
base_source=(root/'source/vendor/cranelift-frontend/src/ssa.rs').read_text();assert 'dense_base' not in base_source
variants={};profile_settings={}
for label,test_count,candidate_size in [('wide',17,72),('compact',18,64)]:
 raw=root/'trials'/label;build=read(raw/'candidate-build.json');control=read(raw/'control-origin.json');flags=read(raw/'runtime-flags.json');assert len(flags)==60 and build['exit_code']==0 and build['head']==state['base_commit'];assert control['source_commit']==state['control_source_commit']==prior['source_commit'] and control['sha256']==prior['compiler_binary_sha256']['candidate']
 assert excluded['trials/'+label+'/control']['sha256']==control['sha256'] and excluded['trials/'+label+'/candidate']['sha256']==build['binary_sha256']
 assert pin(raw/'candidate.patch')['sha256']==build['patch_sha256']==state['variants'][label]['patch_sha256'];assert pin(raw/'tested-source.patch')==pin(raw/'candidate.patch');assert pin(raw/'source-candidate.rs')['sha256']==state['variants'][label]['source_snapshot_sha256']
 candidate=(raw/'source-candidate.rs').read_text();assert apply_source_patch(base_source,(raw/'candidate.patch').read_text())==candidate
 marker='// Most variables have very few queried blocks.';assert base_source[:base_source.index(marker)]==candidate[:candidate.index(marker)];marker='// Each lookup usually touches a short predecessor chain';end='\n#[cfg(test)]\nmod tests';algorithm=base_source[base_source.index(marker):base_source.index(end)];assert algorithm==candidate[candidate.index(marker):candidate.index(end)]
 proof=read(raw/'source-equivalence-check.json');assert proof['ssa_traversal_cycle_handling_and_phi_construction_byte_identical'] and proof['ssa_algorithm_sha256']==hashlib.sha256(algorithm.encode()).hexdigest() and proof['dense_cell_bound_per_variable']==4 and proof['minimum_facts_for_promotion']==64
 assert read(raw/'probes/build.json')['exit_code']==read(raw/'probes/tests.json')['exit_code']==0 and read(raw/'probes/build.json')['patch_sha256']==build['patch_sha256'];assert f'test result: ok. {test_count} passed; 0 failed;' in (raw/'probes/tests.stdout').read_text()
 ir=read(raw/'probes/ir-result.json');assert ir['cases']==24 and ir['verified_functions']==48 and ir['identical_ir_aliases_query_values_side_effects_and_enumerations'];assert read(raw/'probes/ir-build.json')['exit_code']==read(raw/'probes/ir-run.json')['exit_code']==0
 data=(raw/'probes/ir-comparison.jsonl').read_bytes();assert len(data)==ir['bytes'] and hashlib.sha256(data).hexdigest()==ir['sha256'];cases=[json.loads(line) for line in data.splitlines()];assert len(cases)==24 and all(c['identical'] for c in cases);assert {(c['offset'],c['blocks'],c['looped'],c['reverse_sealing']) for c in cases}=={(o,n,l,r) for o in [0,4096,100000] for n in [65,257] for l in [False,True] for r in [False,True]}
 layout=[int(v) for v in (raw/'probes/layout.stdout').read_text().split()];assert layout==[64,candidate_size] and read(raw/'probes/layout-build.json')['exit_code']==0
 qualification=validate_cohort(raw,flags,expected,{'control':control['sha256'],'candidate':build['binary_sha256']},'matches_current_control_output');q=qualification['qualified'];assert q['source_cfg_seconds']['mean_reduction_fraction']<0 and q['instructions']['mean_reduction_fraction']<0 and all(b['compiler_mean_reduction_fraction']<0 for b in qualification['blocks'])
 for name in ['Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.toml']:profile_settings[name]=tomllib.loads((root/'source'/name).read_text())['profile']['compiler']
 variants[label]=dict(candidate_patch_sha256=build['patch_sha256'],source_snapshot_sha256=state['variants'][label]['source_snapshot_sha256'],candidate_rebuild_seconds=build['seconds'],focused_ssa_tests_passed=test_count,ir_comparison=ir,definition_record_bytes={'control':64,'candidate':candidate_size},decision=read(raw/'decision.json'),**qualification)
restoration=read(root/'trials/compact/restoration-and-next-target.json');assert restoration['restored_source_matches_git_base'] and restoration['base_commit']==state['base_commit']
words=(root/'source/hosts/gpu/src/native_artifact/codegen/common/ssa_words.rs').read_text();emit=(root/'source/hosts/gpu/src/native_artifact/program/compact/emit.rs').read_text();assert 'for slot in slots {' in words and 'b.def_var(variable, value);' in words and 'Zero is only a backend SSA seed.' in emit and 'Flow independently proves that' in emit
summary=dict(source_commit=state['base_commit'],control_source_commit=state['control_source_commit'],hardware=state['hardware'],decision='Reject both local-span definition-storage variants; production compiler source restored exactly',production_changes_retained=False,profile_settings=profile_settings,variants=variants,next_optimization_target=restoration['next_target'],scope=[
 'Two separate serial eight-observation ABBA/BAAB full-source cohorts; all sixteen primary observations remain separate by candidate. No pooling or cached/decoded-only substitute.',
 'Both candidates pass focused tests, 24 paired complete IR comparisons and fourteen successful fixture pairs. Every source, MBC, Object and complete metadata byte matches the retained program in both screens and all primary runs. Source construction and compiler instructions regress; both compiler-time blocks are slower for each variant.',
 'The first private definition record grows from 64 to 72 bytes. The compact record restores 64 bytes, but still regresses. Layout probes, sources, build/test/IR commands and all measurements remain. No individual cause is isolated from these observations.',
 'All SSA traversal, cycle handling and phi-construction code remains byte-identical. Only private storage and its tests were trialed. Pure replay reconstructs each candidate source from the retained base and measured patch and checks source, tests, IR, counters and output files.',
 'Builds, focused tests, IR/layout probes, fixtures, hashing, copying and archive work do not overlap primary timings. Observed compiler rebuilds are separate warm-cache Rust costs, excluded from Mech compilation; no matched cold-bootstrap comparison.',
 'Neither experiment is retained. Grammar, checked errors, current shape/factory/visit/ownership checks, scalar emission, finite admission, runtime accounting and backend settings remain. Machine code/metadata are identical; no new compressor-runtime latency campaign or CPU sampling campaign is claimed and no execution machinery is retired.',
 'Source inspection finds shared word homes defined together in entry, including zero backend seeds. This weakens the high-locality premise; no dynamic locality histogram or causal attribution was collected. Deferring unnecessary backend zero seeds is an unimplemented next hypothesis requiring correctness and runtime qualification.',
 'The retained nested-parser compiler remains current; full compilation is still above ten seconds.'
])
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
