extern crate alloc;
pub use cranelift_frontend::Variable;
#[allow(dead_code)] #[path="/private/tmp/mech-ssa-span-compact-20261114/probes/layout-control.rs"] mod control;
#[allow(dead_code)] #[path="/private/tmp/mech-ssa-span-compact-20261114/probes/layout-candidate.rs"] mod candidate;
fn main(){println!("{} {}", control::record_bytes(), candidate::record_bytes());}
