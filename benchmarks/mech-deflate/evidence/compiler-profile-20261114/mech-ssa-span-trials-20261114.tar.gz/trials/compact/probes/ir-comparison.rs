extern crate alloc;
pub use cranelift_frontend::Variable;
#[allow(dead_code)]
#[path = "/Users/cim310/.codex/worktrees/level12-compile-profile/mech/vendor/cranelift-frontend/src/ssa.rs"] mod ssa;
#[allow(dead_code)]
#[path = "/private/tmp/mech-ssa-span-compact-20261114/probes/ssa-before.rs"] mod reference;

use cranelift_codegen::cursor::{Cursor, FuncCursor};
use cranelift_codegen::entity::EntityRef;
use cranelift_codegen::ir::{self, Function, InstBuilder, Value, Block, Inst, types::I64, condcodes::IntCC};
trait Builder: Default {
 fn declare(&mut self, block:Block);
 fn pred(&mut self, block:Block, inst:Inst);
 fn def(&mut self, var:Variable,value:Value,block:Block);
 fn get(&mut self,func:&mut Function,var:Variable,block:Block)->(Value,Vec<Block>);
 fn seal(&mut self,block:Block,func:&mut Function)->Vec<Block>;
 fn values(&self,var:Variable)->Vec<Value>;
}
macro_rules! builder {
 ($ty:path)=>{impl Builder for $ty {
  fn declare(&mut self,b:Block){self.declare_block(b)}
  fn pred(&mut self,b:Block,i:Inst){self.declare_block_predecessor(b,i)}
  fn def(&mut self,v:Variable,x:Value,b:Block){self.def_var(v,x,b)}
  fn get(&mut self,f:&mut Function,v:Variable,b:Block)->(Value,Vec<Block>){let(x,e)=self.use_var(f,v,I64,b);(x,e.instructions_added_to_blocks)}
  fn seal(&mut self,b:Block,f:&mut Function)->Vec<Block>{self.seal_block(b,f).instructions_added_to_blocks}
  fn values(&self,v:Variable)->Vec<Value>{self.values_for_var(v).collect()}
 }};
}
builder!(ssa::SSABuilder);builder!(reference::SSABuilder);
fn observe<B:Builder>(offset:usize,n:usize,looped:bool,reverse:bool)->serde_json::Value {
 let mut f=Function::new();f.signature.returns.push(ir::AbiParam::new(I64));
 for _ in 0..offset {f.dfg.make_block();}
 let blocks=(0..n+1).map(|_|f.dfg.make_block()).collect::<Vec<_>>();
 let mut b=B::default();let vars=[Variable::new(0),Variable::new(1),Variable::new(2)];
 for &block in &blocks {f.layout.append_block(block);b.declare(block);}
 let mut queries=Vec::new();let mut effects=Vec::new();
 {
  let mut c=FuncCursor::new(&mut f).at_bottom(blocks[0]);
  for (i,&v) in vars.iter().enumerate(){let x=c.ins().iconst(I64,i as i64+1);b.def(v,x,blocks[0]);}
  let inst=c.ins().jump(blocks[1],&[]);b.pred(blocks[1],inst);
 }
 for i in 1..n {
  let mut values=Vec::new();
  for &var in &vars {let(x,e)=b.get(&mut f,var,blocks[i]);queries.push(x.as_u32());effects.push(e.iter().map(|x|x.as_u32()).collect::<Vec<_>>());values.push(x);}
  let mut c=FuncCursor::new(&mut f).at_bottom(blocks[i]);
  if i%3==0 {let x=c.ins().iadd_imm(values[0],(i%11) as i64);b.def(vars[0],x,blocks[i]);}
  if i%7==0 {let x=c.ins().iadd(values[0],values[1]);b.def(vars[1],x,blocks[i]);}
  if i==n-1 && looped {
   let cond=c.ins().icmp_imm(IntCC::SignedLessThan,values[0],47);
   let inst=c.ins().brif(cond,blocks[1],&[],blocks[n],&[]);b.pred(blocks[1],inst);b.pred(blocks[n],inst);
  } else {let inst=c.ins().jump(blocks[i+1],&[]);b.pred(blocks[i+1],inst);}
 }
 let(x,e)=b.get(&mut f,vars[0],blocks[n]);queries.push(x.as_u32());effects.push(e.iter().map(|x|x.as_u32()).collect::<Vec<_>>());FuncCursor::new(&mut f).at_bottom(blocks[n]).ins().return_(&[x]);
 let mut order=blocks.clone();if reverse{order.reverse();}
 for block in order {effects.push(b.seal(block,&mut f).iter().map(|x|x.as_u32()).collect::<Vec<_>>());}
 for &block in blocks.iter().rev() {for &var in &vars {let(x,e)=b.get(&mut f,var,block);queries.push(x.as_u32());effects.push(e.iter().map(|x|x.as_u32()).collect::<Vec<_>>());}}
 let flags=cranelift_codegen::settings::Flags::new(cranelift_codegen::settings::builder());cranelift_codegen::verify_function(&f,&flags).unwrap();
 let aliases=(0..f.dfg.num_values()).map(|i|{let v=Value::new(i);(v.as_u32(),f.dfg.resolve_aliases(v).as_u32(),f.dfg.value_type(v).to_string())}).collect::<Vec<_>>();
 let enumerations=vars.iter().map(|&var|b.values(var).iter().map(|v|v.as_u32()).collect::<Vec<_>>()).collect::<Vec<_>>();
 serde_json::json!({"ir":f.display().to_string(),"aliases":aliases,"queries":queries,"effects":effects,"enumerations":enumerations})
}
fn main(){
 for offset in [0,4096,100000] {for n in [65,257] {for looped in [false,true] {for reverse in [false,true] {
  let control=observe::<reference::SSABuilder>(offset,n,looped,reverse);let candidate=observe::<ssa::SSABuilder>(offset,n,looped,reverse);assert_eq!(control,candidate,"offset {offset} n {n} loop {looped} reverse {reverse}");
  println!("{}",serde_json::json!({"offset":offset,"blocks":n,"looped":looped,"reverse_sealing":reverse,"identical":true,"observation":candidate}));
 }}}}
}
