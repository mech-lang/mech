from pathlib import Path
import subprocess,json,hashlib,shutil
repo=Path.cwd();packet=Path('/private/tmp/mech-ssa-span-trials-packet-20261114');assert not packet.exists();base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert subprocess.check_output(['git','diff','HEAD','--','src','hosts','vendor','machines','Cargo.toml'])==b''
roots={'wide':Path('/private/tmp/mech-ssa-span-20261114'),'compact':Path('/private/tmp/mech-ssa-span-compact-20261114')};excluded=[];states={}
for label,raw in roots.items():
 build=json.loads((raw/'candidate-build.json').read_text());assert build['head']==base;assert hashlib.sha256((raw/'candidate.patch').read_bytes()).hexdigest()==build['patch_sha256'];states[label]={'base_commit':base,'patch_sha256':build['patch_sha256'],'source_snapshot_sha256':hashlib.sha256((raw/'source-candidate.rs').read_bytes()).hexdigest(),'decision':json.loads((raw/'decision.json').read_text())}
 for p in sorted(raw.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(raw);dest=Path('trials')/label/rel
  if rel.as_posix() in ['control','candidate'] or rel.parts[:2]==('probes','bin'):
   excluded.append({'path':dest.as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()});continue
  d=packet/dest;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
control=json.loads((roots['compact']/'control-origin.json').read_text());control_source=control['source_commit'];assert subprocess.check_output(['git','diff',control_source,base,'--','src','hosts','vendor','machines','Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.toml'])==b''
state={'base_commit':base,'retained_source_commit':base,'control_source_commit':control_source,'production_changes_retained':False,'production_source_restored':True,'control_production_source_identical_to_base':True,'variants':states,'hardware':'Apple M3 Air, 8 cores (4P+4E), 16 GB, macOS 26.2','rustc':subprocess.check_output(['rustc','-Vv'],text=True),'cargo':subprocess.check_output(['cargo','-V'],text=True)};(packet/'source-state.json').write_text(json.dumps(state,indent=2,sort_keys=True)+'\n');(packet/'excluded-executables.json').write_text(json.dumps(excluded,indent=2)+'\n')
paths=['Cargo.toml','Cargo.lock','.cargo/config.toml','LICENSE','vendor/cranelift-frontend/src/ssa.rs','hosts/gpu/src/native_artifact/AGENTS.md','hosts/gpu/src/native_artifact/codegen/common/ssa_words.rs','hosts/gpu/src/native_artifact/program/compact/emit.rs','hosts/gpu/tests/fixtures/native/deflate-huffman-LICENSES.md']
paths+=['benchmarks/mech-deflate/native-profile/'+n for n in ['Cargo.toml','Cargo.lock','compile_profile.rs','profile_compile.py','ssa_builder_tests.rs']]
paths+=['hosts/gpu/tests/fixtures/native/'+n+'.mec' for n in ['numeric-nested-phase','numeric-nested-phase-states','numeric-private-fixed-nested','numeric-changing-capture-tree','numeric-array-windows','numeric-multiple-children']]
for name in paths:
 d=packet/'source'/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(subprocess.check_output(['git','show',base+':'+name]))
validation=packet/'validation';validation.mkdir()
for suffix in ['.json','.archive.json']:shutil.copy2(repo/('benchmarks/mech-deflate/native-profile/nested-parser-compile-apple-m3-20261114'+suffix),validation/('qualified-nested-parser'+suffix))
shutil.copytree(Path('/private/tmp/mech-borrowed-schema-packet-20261114/licenses'),packet/'licenses')
for pattern in ['mech-*ssa-span*20261114.py','mech-*ssa-span*20261114.log']:
 for p in Path('/private/tmp').glob(pattern):
  if p.is_file():shutil.copy2(p,packet/p.name)
(packet/'README.txt').write_text('''Two rejected SSA definition-storage experiments, Apple M3, 2026-11-14.
Neither local-span variant is retained. Production source is restored exactly to
the pinned retained compiler. Each candidate has its own full source snapshot,
base-plus-patch pin, compiler rebuild, focused tests, complete IR comparison,
screen runs, fourteen fixture pairs and eight serial ABBA/BAAB full compiles.
Both variants preserve all source/MBC/Object/complete metadata bytes but regress
source-CFG construction and compiler instructions; both balanced compiler-time
blocks are slower. Layout measurements distinguish 64/72-byte first records and
64/64-byte compact records. Trials remain separate; no observations are pooled.
Source inspection finds shared word homes initialized together before source CFG
emission. Their common entry definition weakens the proposed locality benefit.
That is a source-based explanation, not a measured per-variable histogram or
causal isolation. Deferring unneeded backend zero seeds is a next hypothesis,
with input/constants, padding, boundary, error and runtime checks still required.
Executables are excluded and hash-pinned. Builds, tests, IR/layout probes,
fixtures, hashing, copying and archive work do not overlap primary timing.
Pure offline replay checks base/patch/source identity, raw measurements, tests,
IR and generated output bytes without compilers, benchmark execution, original
scratch paths or network. The sub-ten-second full-compilation goal remains open.
''');print(packet)
