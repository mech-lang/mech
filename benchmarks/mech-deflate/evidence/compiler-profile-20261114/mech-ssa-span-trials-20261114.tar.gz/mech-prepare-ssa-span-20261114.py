from pathlib import Path
import json,subprocess,shutil,hashlib
repo=Path.cwd();root=Path('/private/tmp/mech-ssa-span-20261114');root.mkdir();prior=Path('/private/tmp/mech-nested-parser-20261114');summary_path=repo/'benchmarks/mech-deflate/native-profile/nested-parser-compile-apple-m3-20261114.json';s=json.loads(summary_path.read_text())
control=root/'control';shutil.copy2(prior/'candidate',control);control.chmod(0o755);sha=hashlib.sha256(control.read_bytes()).hexdigest();assert sha==s['compiler_binary_sha256']['candidate'];(root/'control-origin.json').write_text(json.dumps({'source_commit':s['source_commit'],'sha256':sha,'copied_from':str(prior/'candidate'),'qualification_result':str(summary_path.relative_to(repo)),'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()},indent=2)+'\n');shutil.copy2(prior/'runtime-flags.json',root/'runtime-flags.json');(root/'reference').mkdir()
for n in ['source.mec','program.mecb','program.o','metadata.json']:shutil.copy2(prior/'candidate-1'/n,root/'reference'/n)
(root/'reference-pins.json').write_text(json.dumps({n:{'bytes':(root/'reference'/n).stat().st_size,'sha256':hashlib.sha256((root/'reference'/n).read_bytes()).hexdigest()} for n in ['source.mec','program.mecb','program.o','metadata.json']},indent=2,sort_keys=True)+'\n')
rows=[json.loads(line) for line in (prior/'candidate-build.jsonl').read_text().splitlines()];dependencies={}
for name in ['cranelift_codegen','cranelift_frontend']:
 matches=[r for r in rows if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')==name and r.get('profile',{}).get('opt_level')=='3'];assert len(matches)==1,(name,len(matches));files=[f for f in matches[0]['filenames'] if f.endswith('.rlib')];assert len(files)==1;dependencies[name]=files[0]
cmd=['rustc','--edition=2024','--crate-name','ssa_span_tests','-C','opt-level=3','-C','lto=thin','-D','warnings','-L','dependency=/private/tmp/mech-level12-compile-target/compiler/deps','--cfg','feature="std"']
for name,path in dependencies.items():cmd+=['--extern',name+'='+path]
probe=root/'probes';probe.mkdir();(probe/'bin').mkdir();cmd+=['--test',str(repo/'benchmarks/mech-deflate/native-profile/ssa_builder_tests.rs'),'-o',str(probe/'bin/ssa-tests')]
(probe/'recipe.json').write_text(json.dumps({'command':cmd,'dependencies':{n:{'path':p,'bytes':Path(p).stat().st_size,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()} for n,p in dependencies.items()},'scope':'Exact candidate vendored SSA module included by maintained focused wrapper; current coherent compiler-profile Cranelift dependencies and Thin LTO.'},indent=2)+'\n')
for name in ['mech-build-nested-parser-20261114.py','mech-run-nested-parser-20261114.py','mech-run-nested-parser-cohort-20261114.py','mech-nested-parser-fixtures-20261114.py','mech-qualify-nested-parser-20261114.py','mech-analyze-nested-parser-20261114.py']:
 p=Path('/private/tmp')/name;s=p.read_text().replace('nested-parser','ssa-span');(Path('/private/tmp')/name.replace('nested-parser','ssa-span')).write_text(s)
print(root)
