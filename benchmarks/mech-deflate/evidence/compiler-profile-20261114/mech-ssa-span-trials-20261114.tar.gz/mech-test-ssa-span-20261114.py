from pathlib import Path
import subprocess,time,os,json,hashlib
repo=Path.cwd();root=Path('/private/tmp/mech-ssa-span-20261114');p=root/'probes';recipe=json.loads((p/'recipe.json').read_text());patch=subprocess.check_output(['git','diff','HEAD','--binary']);(root/'tested-source.patch').write_bytes(patch);env=dict(os.environ,CARGO_MANIFEST_DIR=str(repo/'benchmarks/mech-deflate/native-profile'));cmd=recipe['command'];start=time.perf_counter();r=subprocess.run(cmd,capture_output=True,env=env);(p/'build.stdout').write_bytes(r.stdout);(p/'build.stderr').write_bytes(r.stderr);(p/'build.json').write_text(json.dumps({'command':cmd,'exit_code':r.returncode,'seconds':time.perf_counter()-start,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'patch_sha256':hashlib.sha256(patch).hexdigest()},indent=2)+'\n');print('BUILD',r.returncode,flush=True)
if r.returncode:print(r.stderr.decode());raise SystemExit(r.returncode)
cmd=[str(p/'bin/ssa-tests'),'--test-threads=2'];start=time.perf_counter()
with (p/'tests.stdout').open('wb') as stdout,(p/'tests.stderr').open('wb') as stderr:r=subprocess.run(cmd,stdout=stdout,stderr=stderr,env=env)
(p/'tests.json').write_text(json.dumps({'command':cmd,'exit_code':r.returncode,'seconds':time.perf_counter()-start},indent=2)+'\n');print('TESTS',r.returncode,flush=True);print((p/'tests.stdout').read_text()[-8000:]);print((p/'tests.stderr').read_text()[-2000:]);assert subprocess.check_output(['git','diff','HEAD','--binary'])==patch
raise SystemExit(r.returncode)
