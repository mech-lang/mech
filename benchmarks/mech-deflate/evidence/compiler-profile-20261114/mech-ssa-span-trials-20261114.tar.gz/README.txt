Two rejected SSA definition-storage experiments, Apple M3, 2026-11-14.
Neither local-span variant is retained. Production source is restored exactly to
the pinned retained compiler. Each candidate has its own full source snapshot,
base-plus-patch pin, compiler rebuild, focused tests, complete IR comparison,
screen runs, fourteen fixture pairs and eight serial ABBA/BAAB full compiles.
Both variants preserve all source/MBC/Object/complete metadata bytes but regress
source-CFG construction and compiler instructions; both balanced compiler-time
blocks are slower. Layout measurements distinguish 64/72-byte first records and
64/64-byte compact records. Trials remain separate; no observations are pooled.
Source inspection finds shared word homes initialized together before source CFG
emission. Their common entry definition weakens the proposed locality benefit.
That is a source-based explanation, not a measured per-variable histogram or
causal isolation. Deferring unneeded backend zero seeds is a next hypothesis,
with input/constants, padding, boundary, error and runtime checks still required.
Executables are excluded and hash-pinned. Builds, tests, IR/layout probes,
fixtures, hashing, copying and archive work do not overlap primary timing.
Pure offline replay checks base/patch/source identity, raw measurements, tests,
IR and generated output bytes without compilers, benchmark execution, original
scratch paths or network. The sub-ten-second full-compilation goal remains open.
