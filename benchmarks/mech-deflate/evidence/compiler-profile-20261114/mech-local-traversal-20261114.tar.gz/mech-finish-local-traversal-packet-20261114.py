from pathlib import Path
packet=Path('/private/tmp/mech-local-traversal-packet-20261114');old=Path('/private/tmp/mech-shared-schema-packet-20261114/replay.py').read_text();defs=old[old.index('stage_fields='):old.index('qualification=validate_cohort(')]
prefix='''from pathlib import Path
import json,hashlib,re,statistics,tomllib
root=Path(__file__).resolve().parent;raw=root/'compiler'
read=lambda p:json.loads(p.read_text())
def pin(p):
 data=p.read_bytes();return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
state=read(root/'source-state.json');build=read(raw/'candidate-build.json');control=read(raw/'control-origin.json');patch=pin(root/'source-change.patch');assert patch==pin(raw/'candidate.patch') and patch['sha256']==state['patch_sha256']==build['patch_sha256']
assert build['exit_code']==0 and build['head']==state['base_commit'] and state['control_production_source_identical_to_base']
prior=read(root/'validation/qualified-scope-graph.json');receipt=read(root/'validation/qualified-scope-graph.archive.json');assert pin(root/'validation/qualified-scope-graph.json')['sha256']==receipt['replay_sha256'];assert control['sha256']==prior['compiler_binary_sha256']['candidate'] and control['source_commit']==state['control_source_commit']==prior['source_commit']
flags=read(raw/'runtime-flags.json');assert len(flags)==60;expected=prior['output_hashes'];assert read(raw/'reference-pins.json')==expected
excluded={r['path']:r for r in read(root/'excluded-executables.json')};assert excluded['compiler/control']['sha256']==control['sha256'] and excluded['compiler/candidate']['sha256']==build['binary_sha256'] and 'compiler/topology-tests' in excluded
profile_settings={}
for name in ['Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.toml']:
 before=tomllib.loads((root/'source-base'/name).read_text());after=tomllib.loads((root/'source'/name).read_text());assert after['profile']==before['profile'];profile_settings[name]=after['profile']['compiler']
assert '--profile' in build['command'] and build['command'][build['command'].index('--profile')+1]=='compiler' and '--release' not in build['command']
'''
end='''qualification=validate_cohort(raw,flags,expected,{'control':control['sha256'],'candidate':build['binary_sha256']},'matches_current_control_output')
tests={}
for name in ['topology-build','topology-tests']:
 command=read(raw/(name+'-command.json'));assert command['exit_code']==0 and command['source_patch_sha256']==state['patch_sha256']==pin(raw/(name+'.patch'))['sha256'];tests[name]=command
assert re.findall(r'test result: ok\\. (\\d+) passed',(raw/'topology-tests.log').read_text())==['5']
assert 'visit_predecessors.rs' in (root/'source/benchmarks/mech-deflate/native-profile/visit_predecessors_tests.rs').read_text()
profile_path=raw/'profile';profile_command=read(profile_path/'command.json');assert profile_command['flags']==flags and profile_command['binary_sha256']==build['binary_sha256'] and profile_command['source_base_commit']==state['base_commit'] and profile_command['source_patch_sha256']==state['patch_sha256']
assert read(profile_path/'process.json')['exit_code']==0 and read(profile_path/'output-check.json')==expected
for filename,pinned in expected.items():assert pin(profile_path/'output'/filename)==pinned
samples=read(profile_path/'samples.json');assert len(samples)==1 and samples[0]['stage']=='numeric-helpers' and samples[0]['exit_code']==0
mapping=read(profile_path/'demangled-symbols.json');tables={};symbols=set()
for p in sorted(profile_path.glob('*-sample.txt')):
 text=p.read_text();symbols.update(re.findall(r'_R[A-Za-z0-9_]+',text));mapped=re.sub(r'_R[A-Za-z0-9_]+',lambda m:mapping[m.group(0)],text);assert mapped==p.with_name(p.stem+'-demangled.txt').read_text();parsed=[]
 for line in mapped[mapped.index('Sort by top of stack'):].splitlines()[1:]:
  match=re.match(r'\\s+(.*?)\\s+\\(in (.*?)\\)\\s+(\\d+)\\s*$',line)
  if match:parsed.append(dict(symbol=match[1],image=match[2],self_samples=int(match[3])))
  elif parsed:break
 assert parsed==read(p.with_name(p.stem+'-self.json'));tables[p.name]=[r for r in parsed if r['symbol']!='__ulock_wait'][:20]
assert set(mapping)==symbols and len(tables)==1
profile=dict(command=profile_command,samples=samples,completed_sample_files=len(tables),cpu_self_samples=tables,main_thread_waits_excluded=True)
summary=dict(source_commit=state['source_commit'],base_commit=state['base_commit'],control_source_commit=state['control_source_commit'],hardware=state['hardware'],decision='Retain proof-local numeric scope selection and indexed omitted-predecessor seeds; identical generated program bytes',candidate_patch_sha256=state['patch_sha256'],profile_settings=profile_settings,candidate_rebuild_seconds=build['seconds'],rebuild_scope='Observed locked/offline optimized-profile rebuild with existing Cargo caches. Excluded from Mech compilation timing; no matched cold-bootstrap comparison.',compiler_executable_bytes={v:excluded['compiler/'+v]['bytes'] for v in ['control','candidate']},rust_test_commands=tests,rust_tests_passed=5,diagnostic_candidate_profile=profile,exhaustive_target_query_contexts=6**6*32*5,seeded_pruning_contexts=128*512*3,scope=[
 'Eight serial fresh source-to-Object primary observations in ABBA then BAAB order, identical 60 runtime flags and compiler build profile. No cached Object or decoded-only substitute.',
 'Builds, tests, screens, fixtures, CPU sampling, hashing, copying and packet work do not overlap primary timing. All source, MBC, Object and complete metadata bytes match the qualified program in both screens and every primary observation; fourteen successful fixture pairs match all four files.',
 'Scope construction groups only current proof sites, preserving their relative order and ascending iteration order. Omitted-predecessor seeding uses reverse topology from this exact immutable prepared owner and current set/header. Descendant pruning is unchanged; no guard, scope-validity or visit answer is cached.',
 'Five exact production-module tests pass. Exhaustive target queries compare with the original full scan in 7,464,960 contexts including sparse and invalid target IDs; 196,608 seeded pruning contexts cover branches, duplicate edges, cycles, changed sets/headers and latch stops. These are index/graph tests, not a claim that GPU or runtime unit suites were rerun.',
 'Grammar, language, checked errors, direct scalar instruction emission, current shape/factory/visit/ownership proofs, finite admission, runtime accounting and backend optimization settings remain unchanged. No execution machinery is retired.',
 'Both subjects retain SSA value compaction and its measured cost. Generated machine code and complete metadata are byte-identical. No new compressor-runtime latency campaign is claimed. A separate current-candidate one-second helper CPU window preserves every output byte and all raw/demangled stacks, commands, self tables and existing demangler source/pin. Waits are excluded from hotspot tables; self counts are not phase-exclusive elapsed or exact line attribution. Earlier profiles retain their original pins. Complete compilation remains above ten seconds.'
],**qualification)
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
'''
(packet/'replay.py').write_text(prefix+defs+end)
