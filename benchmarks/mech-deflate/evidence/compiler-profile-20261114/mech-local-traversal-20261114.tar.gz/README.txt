Proof-local numeric traversal analysis, Apple M3, 2026-11-14.
Scope construction groups the current proof's sites in their original relative
order and ascending iteration order. Omitted-predecessor pruning queries reverse
edges from the exact prepared owner against the fresh current set/header. The
same descendant pruning and all actual guard/proof construction remain.
Five tests of the exact production index pass. An exhaustive target query is
compared against the original full scan in 7,464,960 graph/scope/header contexts,
and 196,608 seeded pruning cases compare final sets across branches and cycles.
Eight serial ABBA/BAAB fresh source-to-Object compiles and fourteen successful
fixture pairs use the same 60 flags/profile and reproduce all four output files.
Builds, tests, screens, fixtures, profiling, hashing, copying and archive work do
not overlap primary timing. All observations and adverse counters remain.
Compiler/test executables are excluded and pinned. A separate one-second current-candidate helper CPU window retains raw/mapped
stacks, commands, self tables and existing demangler source/pin, preserving all
output bytes. Waits are not CPU work; samples are not phase-exclusive elapsed
attribution. No new runtime latency suite is claimed. Earlier diagnostic CPU
profiles retain their original pins. The full ten-second goal
remains open. This complete packet is published in benchmarks at the user's
request. Python 3.11+ offline replay reconstructs the summary without compilers,
benchmarks, original scratch paths or external services.
