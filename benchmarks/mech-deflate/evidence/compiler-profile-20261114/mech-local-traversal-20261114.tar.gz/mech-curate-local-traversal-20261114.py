from pathlib import Path
import subprocess,json,hashlib,shutil
repo=Path.cwd();raw=Path('/private/tmp/mech-local-traversal-20261114');packet=Path('/private/tmp/mech-local-traversal-packet-20261114');assert not packet.exists()
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();build=json.loads((raw/'candidate-build.json').read_text());base=build['head'];control=json.loads((raw/'control-origin.json').read_text());control_source=control['source_commit']
summary_path=repo/'benchmarks/mech-deflate/native-profile/scope-graph-compile-apple-m3-20261114.json';receipt_path=summary_path.with_name(summary_path.stem+'.archive.json');prior=json.loads(summary_path.read_text());receipt=json.loads(receipt_path.read_text());assert hashlib.sha256(summary_path.read_bytes()).hexdigest()==receipt['replay_sha256'];assert control_source==prior['source_commit'] and control['sha256']==prior['compiler_binary_sha256']['candidate']
patch=subprocess.check_output(['git','diff','--binary',base,source]);assert patch==(raw/'candidate.patch').read_bytes();assert hashlib.sha256(patch).hexdigest()==build['patch_sha256']
assert subprocess.check_output(['git','diff',control_source,base,'--','src','hosts','vendor','machines','Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.toml'])==b''
excluded=[]
for p in sorted(raw.rglob('*')):
 if not p.is_file():continue
 rel=Path('compiler')/p.relative_to(raw)
 if p.name in ['control','candidate','topology-tests']:
  excluded.append(dict(path=rel.as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()));continue
 d=packet/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
(packet/'excluded-executables.json').write_text(json.dumps(excluded,indent=2)+'\n');(packet/'source-change.patch').write_bytes(patch)
state=dict(source_commit=source,base_commit=base,control_source_commit=control_source,control_production_source_identical_to_base=True,patch_sha256=hashlib.sha256(patch).hexdigest(),hardware='Apple M3 Air, 8 cores (4P+4E), 16 GB, macOS 26.2',rustc=subprocess.check_output(['rustc','-Vv'],text=True),cargo=subprocess.check_output(['cargo','-V'],text=True));(packet/'source-state.json').write_text(json.dumps(state,indent=2,sort_keys=True)+'\n')
changed=subprocess.check_output(['git','diff','--name-only',base,source],text=True).splitlines()
paths=changed+['Cargo.toml','Cargo.lock','.cargo/config.toml','LICENSE','hosts/gpu/src/native_artifact/AGENTS.md','hosts/gpu/src/native_artifact/program/prepare/mod.rs','hosts/gpu/src/native_artifact/program/prepare/readonly_numeric.rs','hosts/gpu/tests/fixtures/native/deflate-huffman-LICENSES.md']
paths+=['benchmarks/mech-deflate/native-profile/'+n for n in ['Cargo.toml','Cargo.lock','compile_profile.rs','profile_compile.py','visit_predecessors_tests.rs']]
paths+=['hosts/gpu/tests/fixtures/native/'+n+'.mec' for n in ['numeric-nested-phase','numeric-nested-phase-states','numeric-private-fixed-nested','numeric-changing-capture-tree','numeric-array-windows','numeric-multiple-children']]
for name in dict.fromkeys(paths):
 data=subprocess.check_output(['git','show',source+':'+name]);d=packet/'source'/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(data)
for name in [*changed,'Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.toml']:
 data=subprocess.check_output(['git','show',base+':'+name]);d=packet/'source-base'/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(data)
validation=packet/'validation';validation.mkdir();shutil.copy2(summary_path,validation/'qualified-scope-graph.json');shutil.copy2(receipt_path,validation/'qualified-scope-graph.archive.json')
shutil.copytree(Path('/private/tmp/mech-borrowed-schema-packet-20261114/licenses'),packet/'licenses')
for pattern in ['mech-*local-traversal*20261114.py','mech-*local-traversal*20261114.log']:
 for p in Path('/private/tmp').glob(pattern):
  if p.is_file():shutil.copy2(p,packet/p.name)
(packet/'README.txt').write_text('''Proof-local numeric traversal analysis, Apple M3, 2026-11-14.
Scope construction groups the current proof's sites in their original relative
order and ascending iteration order. Omitted-predecessor pruning queries reverse
edges from the exact prepared owner against the fresh current set/header. The
same descendant pruning and all actual guard/proof construction remain.
Five tests of the exact production index pass. An exhaustive target query is
compared against the original full scan in 7,464,960 graph/scope/header contexts,
and 196,608 seeded pruning cases compare final sets across branches and cycles.
Eight serial ABBA/BAAB fresh source-to-Object compiles and fourteen successful
fixture pairs use the same 60 flags/profile and reproduce all four output files.
Builds, tests, screens, fixtures, profiling, hashing, copying and archive work do
not overlap primary timing. All observations and adverse counters remain.
Compiler/test executables are excluded and pinned. A separate one-second current-candidate helper CPU window retains raw/mapped
stacks, commands, self tables and existing demangler source/pin, preserving all
output bytes. Waits are not CPU work; samples are not phase-exclusive elapsed
attribution. No new runtime latency suite is claimed. Earlier diagnostic CPU
profiles retain their original pins. The full ten-second goal
remains open. This complete packet is published in benchmarks at the user's
request. Python 3.11+ offline replay reconstructs the summary without compilers,
benchmarks, original scratch paths or external services.
''');print(packet,flush=True)
