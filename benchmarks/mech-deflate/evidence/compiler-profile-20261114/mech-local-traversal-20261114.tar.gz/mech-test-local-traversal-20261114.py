from pathlib import Path
import subprocess,time,json,hashlib
root=Path('/private/tmp/mech-local-traversal-20261114')
for name,cmd in [
 ('topology-build',['rustc','--edition','2024','--test','-O','benchmarks/mech-deflate/native-profile/visit_predecessors_tests.rs','-o',str(root/'topology-tests')]),
 ('topology-tests',[str(root/'topology-tests')]),
]:
 patch=subprocess.check_output(['git','diff','--binary']);(root/(name+'.patch')).write_bytes(patch);start=time.perf_counter()
 with (root/(name+'.log')).open('w') as out:p=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
 result=dict(command=cmd,exit_code=p.returncode,source_patch_sha256=hashlib.sha256(patch).hexdigest(),seconds=time.perf_counter()-start);(root/(name+'-command.json')).write_text(json.dumps(result,indent=2)+'\n');print(result,flush=True)
 assert subprocess.check_output(['git','diff','--binary'])==patch
 if p.returncode:raise SystemExit(p.returncode)
