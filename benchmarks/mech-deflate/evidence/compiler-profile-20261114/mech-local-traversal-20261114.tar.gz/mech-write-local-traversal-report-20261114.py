from pathlib import Path
import json
repo=Path.cwd();packet=Path('/private/tmp/mech-local-traversal-packet-20261114');s=json.loads((packet/'summary.json').read_text());q=s['qualified'];rows=[]
for key,label in [('compiler_seconds','Compiler, s'),('whole_process_seconds','Whole process, s'),('parse_seconds','Parse, s'),('frontend_seconds','Frontend, s'),('native_seconds','Native, s'),('canonical_lowering_seconds','Canonical lowering, s'),('preparation_seconds','Preparation, s'),('numeric_generation_seconds','Numeric generation, s'),('source_cfg_seconds','Source CFG, s'),('cleanup_including_compaction_seconds','Cleanup including compaction, s'),('compaction_seconds','Compaction, s'),('instructions','Retired instructions'),('max_rss_bytes','Peak RSS, bytes'),('peak_footprint_bytes','Peak footprint, bytes')]:
 v=q[key];fmt=(lambda x:f'{x:,}') if key in ['instructions','max_rss_bytes','peak_footprint_bytes'] else (lambda x:f'{x:.6f}')
 rows.append(f"| {label} | {fmt(min(v['control']))}–{fmt(max(v['control']))} | {fmt(min(v['candidate']))}–{fmt(max(v['candidate']))} | {-100*v['mean_reduction_fraction']:+.2f}% |")
report=f'''# Proof-local numeric traversal: compilation qualification

Complete fresh level-12 compilation takes **19.741–20.163 seconds** on the Apple
M3 Air. Eight matched runs show **2.77% lower whole-process time, 2.80% lower
compiler time, 18.01% lower numeric-helper generation time and 4.88% fewer
instructions**. Source, MBC, Object and complete metadata bytes remain identical.
Peak RSS is an adverse 0.028% higher. The ten-second compilation goal remains open.

Numeric traversal analysis previously enumerated every program iteration for each
helper and repeatedly filtered that helper's sites, even for unrelated loops.
It now groups only the current proof's sites, preserving their relative order and
the original ascending iteration order. Loops whose header is absent still get
no scope or proof.

Supported-prefix analysis also scanned every prepared visit to find edges from
omitted predecessors. It now queries the prepared owner's existing reverse-edge
index against the fresh current set and header. The same descendant pruning then
runs. Seed order and duplicates cannot change this monotone removal; discovery
already checked every retained site's successor shape. No scope-validity or guard
answer is cached. The original first-refusal query also keeps its source ordering.
These two compiler-only changes are qualified together; the measurements do not
isolate their individual savings.

Source `{s['source_commit']}`, parent `{s['base_commit']}`.
The frozen control comes from `{s['control_source_commit']}`; its production
source equals the documentation-only parent. Both subjects use the same opt-in
`compiler` profile, full fresh source-to-Object pipeline and 60 runtime flags.
Hardware: Apple M3 Air, 8 cores (4P+4E), 16 GB, macOS 26.2.

| Measurement | Control range (4 runs) | Candidate range (4 runs) | Mean change |
| --- | --- | --- | ---: |
'''+ '\n'.join(rows)+'''

Runs are serial control/candidate/candidate/control then
candidate/control/control/candidate. Both block means improve compiler time
(2.94% and 2.67%). Every candidate compiler, process, native, helper-generation and
instruction observation falls below every control. Every candidate RSS and peak
footprint observation is slightly above every control; no memory saving is claimed.
Parse, frontend, preparation, source CFG and canonical-lowering means are adverse
and retained. These finite cohorts are descriptive, not population estimates.
Both subjects include SSA value compaction and its measured cost. Native substages
are nested and must not be added to whole-process time.

Builds, tests, screens, fixtures, CPU sampling, hashing, copying and packet work do
not overlap primary timing. The observed 273.093-second optimized compiler rebuild
uses existing Cargo caches, is excluded from Mech compilation timings and is not
a matched cold-bootstrap comparison. Both screens and every primary output match
the qualified program byte for byte. Fourteen successful fixture pairs cover six
array/enum programs and eight checked scalar programs; all four files match.

Five tests compile the exact production reverse-edge module. The new target query
matches the original full scan in **7,464,960 graph/scope/header contexts**, including
sparse and out-of-range targets. **196,608 seeded pruning contexts** compare final
sets through branches, duplicate edges, cycles and latch stops. Existing owner
identity, changed-scope and first-refusal checks remain. These are topology tests
and compiler-output checks; GPU/runtime unit suites were not rerun for this trial.
No execution machinery is retired. Grammar, language, checked errors, direct
scalar emission, fresh shape/factory/visit/ownership proofs, admission limits,
runtime accounting and backend optimization settings retain their behavior.
Generated machine code and complete metadata are identical; no new compressor
runtime timing campaign is claimed.

A separate diagnostic compile samples one requested one-second helper window and
preserves all generated bytes. It retains raw/demangled stacks, commands, self
tables and the existing demangler's source/pin. The window includes 111 self
samples in tree-set insertion, 55 in definition-inventory initialization and 50
in word-level `required` liveness. Coordinator waits are excluded. These counts
are neither phase-exclusive elapsed measurements nor exact source-line attribution.
The next recorded candidates are packed word-level liveness and sharing descriptive
definition inventories within one immutable compilation. Neither is applied or
credited here. Earlier CPU profiles keep their original source pins.

The [compact result](../../benchmarks/mech-deflate/native-profile/local-traversal-compile-apple-m3-20261114.json)
and [receipt](../../benchmarks/mech-deflate/native-profile/local-traversal-compile-apple-m3-20261114.archive.json)
pin the complete [benchmark packet](../../benchmarks/mech-deflate/evidence/compiler-profile-20261114/README.md).
It contains exact source/base snapshots and patches, commands, flags, tests, raw
cohorts, outputs, the separate CPU profile and pure offline replay. Compiler/test
executables are excluded and hash-pinned. Python 3.11+ replay needs no compilers,
benchmark execution, original scratch paths or external services.
'''
(repo/'docs/design/native-local-traversal-compile-profile.md').write_text(report);(packet/'REPORT.md').write_text(report)
p=repo/'docs/design/native-compiler-process-profile.md';text=p.read_text().replace('**20.368–20.777 seconds per complete','**19.741–20.163 seconds per complete',1).replace('and [scope-sized validation](native-scope-graph-compile-profile.md).','[scope-sized validation](native-scope-graph-compile-profile.md),\nand [proof-local traversal](native-local-traversal-compile-profile.md).',1)
text+='''
The latest [proof-local traversal qualification](native-local-traversal-compile-profile.md)
removes unrelated-loop enumeration and full-program omitted-predecessor scans
from numeric helper analysis. Eight matched 60-flag compiles take 19.741–20.163
seconds: process time falls 2.77%, helper generation 18.01% and instructions 4.88%.
Peak RSS is an adverse 0.028% higher; parser and frontend means also rise. All
output bytes match. Five topology tests include exhaustive query comparisons;
fourteen fixture pairs also match. The thirteenth packet keeps all observations
and a separate current helper CPU window. The ten-second target remains open.
''';p.write_text(text)
p=repo/'benchmarks/mech-deflate/EXPERIMENTS.md';text=p.read_text();pos=text.index('Paths below name reports **inside the external bundle**.')
text=text[:pos]+'''The [proof-local traversal qualification](../../docs/design/native-local-traversal-compile-profile.md)
retains current-proof loop grouping and indexed omitted-predecessor seeds, with
fresh membership/header checks and unchanged descendant pruning. Eight matched
60-flag runs take 19.741–20.163 seconds: 2.77% less process time, 18.01% less helper
generation and 4.88% fewer instructions. Peak RSS is an adverse 0.028% higher.
All output bytes match; five topology tests and fourteen fixture pairs pass.
Its thirteenth packet retains both screens, every observation and a separate
current helper CPU window. The repository copy verifies/replays offline; older
archives remain unchanged.

'''+text[pos:];p.write_text(text)
p=repo/'benchmarks/mech-deflate/native-profile/README.md';text=p.read_text();text+='''
The [proof-local traversal result](../../../docs/design/native-local-traversal-compile-profile.md)
records fresh compilation at 19.741–20.163 seconds with unchanged generated bytes.
Its full archive, receipt and replay are in the
[compiler-profile evidence index](../evidence/compiler-profile-20261114/README.md).
''';p.write_text(text)
