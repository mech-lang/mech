from pathlib import Path
import hashlib,json,subprocess,shutil
repo=Path.cwd();root=Path('/private/tmp/mech-compiler-mimalloc-20261115');packet=Path('/private/tmp/mech-compiler-mimalloc-packet-20261115');packet.mkdir(exist_ok=False)
pin=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest());excluded=[];state=json.loads((root/'source-state.json').read_text());publication=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
for p in sorted(root.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(root)
 if rel.as_posix() in ['control','candidate']:
  excluded.append(dict(path=rel.as_posix(),**pin(p)));continue
 dest=packet/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
for row in json.loads((root/'fixture-results.json').read_text()):
 if row['fixture'].startswith('hosts/'):
  dest=packet/'fixture-inputs'/Path(row['fixture']).name;dest.parent.mkdir(exist_ok=True);dest.write_bytes(subprocess.check_output(['git','show',state['base_commit']+':'+row['fixture']]))
(packet/'publication-state.json').write_text(json.dumps(dict(source_revision=publication,source_base=state['base_commit'],decision=json.loads((root/'decision.json').read_text())['decision']),indent=2)+'\n');(packet/'excluded-compiler-products.json').write_text(json.dumps(excluded,indent=2)+'\n')
paths=['.cargo/config.toml','Cargo.toml','Cargo.lock','src/bin/mech.rs','benchmarks/mech-deflate/native-profile/Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.lock','benchmarks/mech-deflate/native-profile/compile_profile.rs','benchmarks/mech-deflate/native-profile/profile_compile.py','src/engine/src/artifact/model.rs','src/engine/src/resident/general/mod.rs','src/engine/Cargo.toml'];config=[]
for name in paths:
 p=packet/'source-config'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','show',state['base_commit']+':'+name]));config.append(dict(path=name,source_revision=state['base_commit'],**pin(p)))
(packet/'source-config-pins.json').write_text(json.dumps(config,indent=2)+'\n')
capture=json.loads(Path('/private/tmp/mech-pr973-refresh-20261115/link/capture/link-command.json').read_text());inputs=[]
for at,row in enumerate(capture['inputs']):
 p=Path(row['retained_path']);wanted={k:row[k] for k in ['bytes','sha256']};assert pin(p)==wanted
 rel=Path('native-link-inputs')/(str(at)+'-'+p.name);dest=packet/rel;dest.parent.mkdir(exist_ok=True);shutil.copy2(p,dest);inputs.append(dict(source=row['source'],path=rel.as_posix(),**wanted))
(packet/'native-link-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n');shutil.copytree('/private/tmp/mech-round2-planning-packet-20261114/licenses',packet/'licenses');validation=packet/'validation';validation.mkdir()
for suffix in ['.json','.archive.json']:shutil.copy2(repo/'benchmarks/mech-deflate/native-profile'/('scoped-source-apple-m3-20261115'+suffix),validation/('prior-qualified'+suffix))
for name in ['mech-build-compiler-mimalloc-20261115.py','mech-check-mimalloc-cli-20261115.py','mech-qualify-compiler-mimalloc-20261115.py','mech-curate-compiler-mimalloc-20261115.py','mech-qualify-mimalloc-serial-20261115.py','mech-prepare-mimalloc-replay-20261115.py']:shutil.copy2(Path('/private/tmp')/name,packet/name)
shutil.copy2('/private/tmp/mech-replay-compiler-mimalloc-20261115.py',packet/'replay.py')
(packet/'README.txt').write_text('''Compiler-executable allocator trial on currentDeflate/currentruntime.
Control is immutable retainedAE/source972. Candidate uses pinned mimalloc only
in the native rootCLI compiler and profiling executable through one shared
module; library consumers and emitted programs do not register that allocator.
No override/debug/secure allocator features, compiler algorithms or grammar
change. Cached crate archives and Cargo checksums are included. Lockfiles add
only two packages; some root lock package blocks are reordered, no upgrades.
All7source files, complete patch, commands, failed setup and realCLI checks,
reference outputs,14fixtures, balanced Object/fullnative observations when
performed, complete metadata/executable gates, fixed runtime inputs and pure
replay are retained. The root default CLI feature-gating error is reproduced
on unchanged baseline; explicit cranelift_build nativeCLI check is separate.
Compiler executables/dependency libraries are excluded and hash-pinned.
Primary timings are serial and uncontended; build/check, tests, screens and
archival are excluded. No new runtime performance campaign is claimed when
complete emitted executable bytes match. Sub10s remains open until verified.
''');print(packet)
