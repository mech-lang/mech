from pathlib import Path
import hashlib,json,re,statistics,tomllib
packet=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
cache={}
def pin(p):
 if p not in cache:cache[p]=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 return cache[p]
def apply(source,patch):
 lines=source.splitlines(keepends=True);diff=patch.splitlines(keepends=True);out=[];at=0;i=0
 while i<len(diff):
  m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',diff[i])
  if not m:i+=1;continue
  start=max(0,int(m[1])-1);assert start>=at;out.extend(lines[at:start]);at=start;i+=1
  while i<len(diff) and not diff[i].startswith('@@'):
   line=diff[i]
   if line.startswith(' '):assert lines[at]==line[1:];out.append(lines[at]);at+=1
   elif line.startswith('-'):assert lines[at]==line[1:];at+=1
   elif line.startswith('+'):out.append(line[1:])
   else:raise AssertionError(line)
   i+=1
 out.extend(lines[at:]);return ''.join(out)
def numerical(rows,fields):
 result={}
 for key,fn in fields.items():
  values={v:[fn(row) for row in rows if row['variant']==v] for v in ['control','candidate']}
  a=statistics.mean(values['control']);values['mean_reduction_fraction']=1-statistics.mean(values['candidate'])/a if a else None;result[key]=values
 return result
def blocks(rows,fields):
 result=[]
 for group in [rows[:4],rows[4:]]:
  block={}
  for key,fn in fields.items():
   item={v:statistics.mean(fn(row) for row in group if row['variant']==v) for v in ['control','candidate']};item['mean_reduction_fraction']=1-item['candidate']/item['control'] if item['control'] else None;block[key]=item
  result.append(block)
 return result

root=packet;state=read(root/'source-state.json');publication=read(root/'publication-state.json');decision=read(root/'decision.json');prior=read(root/'validation/prior-qualified.json')
assert pin(root/'validation/prior-qualified.json')['sha256']==read(root/'validation/prior-qualified.archive.json')['replay_sha256']
expected=prior['output_hashes'];control_binary=prior['compiler_binary_sha256']['candidate'];products={x['path']:x for x in read(root/'excluded-compiler-products.json')};binaries={v:products[v]['sha256'] for v in ['control','candidate']};assert binaries['control']==control_binary
exe=dict(bytes=2060440,sha256='d6c65cc3fb18acc4be77dce329962105bf0f2b56dd2623a12f466256463eca61')
for row in read(root/'source-config-pins.json'):assert pin(root/'source-config'/row['path'])=={k:row[k] for k in ['bytes','sha256']}
for row in read(root/'native-link-inputs.json'):assert pin(root/row['path'])=={k:row[k] for k in ['bytes','sha256']}
patch=(root/'candidate.patch').read_text();assert pin(root/'candidate.patch')['sha256']==state['patch_sha256']
sections={}
for part in re.split(r'(?m)(?=^diff --git )',patch):
 if not part:continue
 m=re.match(r'diff --git a/(\S+) b/(\S+)\n',part);assert m and m[1]==m[2];sections[m[1]]=part
assert set(sections)=={r['path'] for r in state['files']} and len(sections)==7
for row in state['files']:
 name=row['path'];new=(root/'candidate-source'/name).read_text();assert pin(root/'candidate-source'/name)['sha256']==row['candidate_sha256']
 if row['reference_sha256'] is None:assert name=='src/compiler_allocator.rs';old_source=''
 else:
  old_source=(root/'reference-source'/name).read_text();assert pin(root/'reference-source'/name)['sha256']==row['reference_sha256'] and old_source==(root/'source-config'/name).read_text()
 assert apply(old_source,sections[name])==new
for name,pkg in [('Cargo.lock','mech'),('benchmarks/mech-deflate/native-profile/Cargo.lock','mech-compression-native-profile')]:
 before=tomllib.loads((root/'reference-source'/name).read_text())['package'];after=tomllib.loads((root/'candidate-source'/name).read_text())['package'];a={(r['name'],r['version']):r for r in before};b={(r['name'],r['version']):r for r in after}
 assert set(b)-set(a)=={('mimalloc','0.1.39'),('libmimalloc-sys','0.1.35')}
 for key,item in a.items():
  if key[0]==pkg:item=dict(item,dependencies=sorted(item['dependencies']+['mimalloc']))
  assert b[key]==item
for row in read(root/'allocator-dependencies.json'):assert pin(root/'allocator-dependencies'/(row['name']+'-'+row['version']+'.crate'))['sha256']==row['sha256']
check=read(root/'candidate-check.json');build=read(root/'candidate-build.json');cli_check=read(root/'candidate-cli-check.json')
for row in [check,build,cli_check]:assert row['exit_code']==0 and row['base_commit']==state['base_commit'] and row['patch_sha256']==state['patch_sha256'] and row['CARGO_INCREMENTAL']=='0'
assert build['binary_sha256']==binaries['candidate']
cli=[json.loads(s) for s in (root/'candidate-cli-check.jsonl').read_text().splitlines()];cli=[x for x in cli if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('name')=='mech' and 'bin' in x['target']['kind']];assert len(cli)==1 and 'compiler' in cli[0]['features'] and 'cranelift_build' in cli[0]['features']
for package in ['mimalloc','libmimalloc-sys']:
 artifacts=[json.loads(s) for s in (root/'candidate-build.jsonl').read_text().splitlines()];artifacts=[x for x in artifacts if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('name')==package.replace('-','_') and x['target']['kind']==['lib']];assert len(artifacts)==1 and artifacts[0]['features']==[]
def errors(path):
 rows=[json.loads(x) for x in path.read_text().splitlines()];return [dict(message=x['message']['message'],code=x['message'].get('code',{}).get('code'),spans=[dict(file=s['file_name'],line=s['line_start']) for s in x['message']['spans'] if s['is_primary']]) for x in rows if x.get('reason')=='compiler-message' and x.get('message',{}).get('level')=='error']
first=root/'cli-default-first-attempt';assert read(first/'candidate-cli-check.json')['exit_code']==read(root/'baseline-cli-check.json')['exit_code']==101
failures=errors(first/'candidate-cli-check.jsonl');assert failures==errors(root/'baseline-cli-check.jsonl')==read(root/'cli-default-error-comparison.json')['errors'] and len(failures)==2
for row in read(root/'baseline-cli-check.json')['source_pins']:assert row['sha256']==pin(root/'reference-source'/row['path'])['sha256']
flags=read(root/'runtime-flags.json');wanted=dict(flags,MECH_COMPACT_COMPILE_THREADS='2');assert len(flags)==61 and read(root/'reference-pins.json')==expected
for name,item in expected.items():assert pin(root/'reference'/name)==item
order=[('control','control-1'),('candidate','candidate-1'),('candidate','candidate-2'),('control','control-2'),('candidate','candidate-3'),('control','control-3'),('control','control-4'),('candidate','candidate-4')]
rows=[];screens=[]
for variant,name in [('control','control-screen'),('candidate','candidate-screen')]+order:
 d=root/name;command=read(root/(name+'-command.json'));process=read(d/'process.json');comp=read(d/'compile.json');checks=read(d/'output-check.json')
 assert command['flags']==wanted and not command['profiling_excluded_from_primary'] and command['binary_sha256']==binaries[variant]
 assert process['exit_code']==0 and process['samples']==0 and process['sampling_error'] is None and process['elapsed_boundary']=='driver_start_to_process_wait_completion'
 assert process['elapsed_seconds']>comp['total_seconds']
 for filename,item in expected.items():assert pin(d/filename)==item and checks[filename]==dict(item,matches_current_control_output=True)
 row=dict(name=name,variant=variant,compile=comp,process=process,files=checks)
 if name.endswith('-screen'):screens.append(row);continue
 stamps=[json.loads(x) for x in (d/'stages.jsonl').read_text().splitlines()];elapsed=lambda prefix:next(x['elapsed'] for x in stamps if x['line'].startswith(prefix))
 for key,begin,end in [('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]:row[key]=elapsed(end)-elapsed(begin)
 row['compaction_seconds']=elapsed('compact-stage: CFG cleanup')-elapsed('compact-stage: compact values before=');row['cleanup_including_compaction_seconds']=row['cleanup_seconds']+row['compaction_seconds']
 for key,prefix in [('value_ids_before','compact-stage: compact values before='),('value_ids_after','compact-values: retained=')]:row[key]=int(next(x['line'] for x in stamps if x['line'].startswith(prefix)).split('=')[-1])
 for key,pattern in [('instructions',r'(\d+)  instructions retired'),('max_rss_bytes',r'(\d+)  maximum resident set size'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]:row[key]=int(re.search(pattern,(d/'stderr.log').read_text())[1])
 rows.append(row)
assert rows==read(root/'cohort.json')
fields=dict(compiler_seconds=lambda r:r['compile']['total_seconds'],whole_process_seconds=lambda r:r['process']['elapsed_seconds'])
for phase in ['parse','catalog','frontend','artifact','encode','native']:fields[phase+'_seconds']=lambda r,p=phase:next(x['seconds'] for x in r['compile']['phases'] if x['phase']==p)
for key in ['canonical_lowering_seconds','preparation_seconds','numeric_generation_seconds','source_cfg_seconds','cleanup_including_compaction_seconds','cleanup_seconds','compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:fields[key]=lambda r,k=key:r[k]
nums=numerical(rows,fields);assert nums==read(root/'numerical-summary.json')
fixtures=read(root/'fixture-results.json');assert len(fixtures)==14
for row in fixtures:
 name=row['fixture'].split(':')[-1] if ':' in row['fixture'] else Path(row['fixture']).stem
 assert pin(root/'fixture-inputs'/(name+'.mec'))['sha256']==row['source_sha256'] and row['all_outputs_match'] and row['variants']['control']==row['variants']['candidate']
 for variant in ['control','candidate']:
  d=root/'fixtures'/name/variant;cmd=read(d/'command.json');assert cmd['flags']==wanted and cmd['binary_sha256']==binaries[variant]
  assert row['variants'][variant]['exit_code']==0 and len(row['variants'][variant]['files'])==4
  for filename,item in row['variants'][variant]['files'].items():assert pin(d/filename)==item
links=read(root/'final-executable-results.json');assert len(links)==2
for variant,row in zip(['control','candidate'],links):
 d=root/('link-'+variant);assert row['variant']==variant and row['exit_code']==0 and row['matches_complete_baseline_executable'] and not row['fresh_runtime_campaign']
 assert pin(d/'worker')==exe==dict(bytes=row['executable_bytes'],sha256=row['executable_sha256']) and read(d/'command.json')['environment']=={'ZERO_AR_DATE':'1'}

serial=root/'candidate-serial-gate';assert read(serial/'process.json')['exit_code']==0
serial_command=read(root/'candidate-serial-gate-command.json');assert serial_command['flags']==dict(wanted,MECH_COMPACT_COMPILE_THREADS='0') and serial_command['binary_sha256']==binaries['candidate']
for filename,item in expected.items():assert pin(serial/filename)==item and read(serial/'output-check.json')[filename]==dict(item,matches_current_control_output=True)
serial_links=read(root/'serial-final-executable-results.json');assert len(serial_links)==1 and serial_links[0]['matches_complete_baseline_executable'] and pin(root/'link-candidate-serial/worker')==exe
failure=root/'serial-gate-sandbox-first-attempt';assert read(failure/'candidate-serial-gate/process.json')['exit_code']==1 and 'time: sysctl kern.clockrate: Operation not permitted' in (failure/'candidate-serial-gate/stderr.log').read_text()
for filename,item in expected.items():assert pin(failure/'candidate-serial-gate'/filename)==item
assert read(failure/'failure.json')['auto_review_rejection'] is False
pipeline=read(root/'qualification-pipeline.json');assert [r['stage'] for r in pipeline]==['screens','executable-gates','fixtures-object-cohort'] and all(r['state']=='complete' and r['exit_code']==0 for r in pipeline)
native_summary=None
if (root/'native-cohort.json').exists():
 native=read(root/'native-cohort.json');assert len(native)==8
 for row,(variant,name) in zip(native,[(v,'native-'+n) for v,n in order]):
  d=root/name;cmd=read(d/'command.json');actual=read(d/'result.json');assert row==dict(actual,name=name,primary_cohort=True) and row['variant']==variant and row['compiler_exit_code']==row['link_exit_code']==0 and row['matches_complete_baseline_executable']
  assert pin(d/'worker')==exe and cmd['flags']==wanted and cmd['compiler_sha256']==binaries[variant] and cmd['ZERO_AR_DATE']=='1'
  for filename,item in expected.items():assert pin(d/filename)==item and row['files'][filename]==dict(item,matches_frozen_reference=True)
 nf={key:(lambda r,k=key:r[k]) for key in ['source_to_executable_seconds','source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']};nnums=numerical(native,nf);nblocks=[]
 for group in [native[:4],native[4:]]:
  means={v:statistics.mean(row['source_to_executable_seconds'] for row in group if row['variant']==v) for v in ['control','candidate']};means['mean_reduction_fraction']=1-means['candidate']/means['control'];nblocks.append(means)
 saved=read(root/'native-numerical-summary.json');assert nnums==saved['numerical_summary'] and nblocks==saved['balanced_blocks'];native_summary=dict(numerical_summary=nnums,balanced_blocks=nblocks)
if decision['decision']=='retained':
 assert native_summary and all(x['mean_reduction_fraction']>0 for x in native_summary['balanced_blocks'])
 commit=read(root/'qualification-commit.json');assert commit['source_commit']==decision['source_commit']==publication['source_revision'] and commit['parent']==state['base_commit'] and commit['entire_commit_diff_sha256']==state['patch_sha256'] and set(commit['files'])==set(sections)
else:assert decision['decision']=='rejected' and decision['production_source_restored'] and decision['canonical_tool_sha256']==control_binary
summary=dict(source_revision=publication['source_revision'],source_base=state['base_commit'],source_patch_sha256=state['patch_sha256'],compiler_binary_sha256=binaries,decision=decision,check=check,build=build,native_cli_check=cli_check,default_cli_failure_comparison=read(root/'cli-default-error-comparison.json'),output_hashes=expected,final_executable=exe,program_flags_count=61,measured_compile_threads=2,fixture_pairs=14,numerical_summary=nums,balanced_blocks=blocks(rows,fields),preliminary_screens=screens,final_links=links,native=native_summary,scope=[
 'Pinned mimalloc in compiler executables only through one shared module, registered in the native rootCLI with compiler feature and in compile_profile. Library consumers and emitted programs keep their allocator. No override/debug/secure allocator features or compiler algorithm/grammar/proof/admission changes. Lockfiles add only mimalloc0.1.39/libmimalloc-sys0.1.35, with some root package-block ordering changes and no upgrades.',
 'Standard retainedAE/source972 control and currentDeflate/runtime. Eight primary source-to-Object and any separately recorded complete-executable observations use serial ABBA/BAAB order;61programflags+2workers common. Fixed adapter cached. Construction,checks,screens,fixtures and archival excluded; no heavy competing job overlaps primary timing. Alladverseobservations remain.',
 'Every source,bytecode,Object,complete metadata byte and cached complete executable matches. Fourteen fixturepairs match. No new emitted-program runtime performance campaign is claimed. Root defaultCLI check fails with the same two preexisting E0433feature-gating errors on original baseline and allocator candidate; real nativeCLI with explicit cranelift_build check passes. The first missing-source-checksum setup failure and default0 timing-counter sandbox denial are preserved; unchanged default0 retry passes allfiles/full-executable gates.',
 'Compiler executables/dependency libraries are excluded and hash-pinned. Pure replay checks saved sources/data and recomputes means/blocks without new compilation or timing. Complete compilation below ten seconds remains open until separately verified.'
])
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';saved=root/'summary.json'
if saved.exists():assert saved.read_text()==encoded
else:saved.write_text(encoded)
print(encoded,end='')
