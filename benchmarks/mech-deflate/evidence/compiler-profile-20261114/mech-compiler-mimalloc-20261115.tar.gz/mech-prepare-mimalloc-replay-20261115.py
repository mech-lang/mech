from pathlib import Path
import textwrap
old=Path('/private/tmp/mech-replay-known-origin-ssa-20261115.py').read_text();helpers=old[:old.index("state=read(packet/'source-state.json')")].replace('import hashlib,json,re,statistics','import hashlib,json,re,statistics,tomllib').replace('start=int(m[1])-1','start=max(0,int(m[1])-1)')
core=textwrap.dedent(old[old.index(" flags=read(root/'runtime-flags.json')"):old.index(" assert decision['decision']=='rejected'")])
prefix=r'''
root=packet;state=read(root/'source-state.json');publication=read(root/'publication-state.json');decision=read(root/'decision.json');prior=read(root/'validation/prior-qualified.json')
assert pin(root/'validation/prior-qualified.json')['sha256']==read(root/'validation/prior-qualified.archive.json')['replay_sha256']
expected=prior['output_hashes'];control_binary=prior['compiler_binary_sha256']['candidate'];products={x['path']:x for x in read(root/'excluded-compiler-products.json')};binaries={v:products[v]['sha256'] for v in ['control','candidate']};assert binaries['control']==control_binary
exe=dict(bytes=2060440,sha256='d6c65cc3fb18acc4be77dce329962105bf0f2b56dd2623a12f466256463eca61')
for row in read(root/'source-config-pins.json'):assert pin(root/'source-config'/row['path'])=={k:row[k] for k in ['bytes','sha256']}
for row in read(root/'native-link-inputs.json'):assert pin(root/row['path'])=={k:row[k] for k in ['bytes','sha256']}
patch=(root/'candidate.patch').read_text();assert pin(root/'candidate.patch')['sha256']==state['patch_sha256']
sections={}
for part in re.split(r'(?m)(?=^diff --git )',patch):
 if not part:continue
 m=re.match(r'diff --git a/(\S+) b/(\S+)\n',part);assert m and m[1]==m[2];sections[m[1]]=part
assert set(sections)=={r['path'] for r in state['files']} and len(sections)==7
for row in state['files']:
 name=row['path'];new=(root/'candidate-source'/name).read_text();assert pin(root/'candidate-source'/name)['sha256']==row['candidate_sha256']
 if row['reference_sha256'] is None:assert name=='src/compiler_allocator.rs';old_source=''
 else:
  old_source=(root/'reference-source'/name).read_text();assert pin(root/'reference-source'/name)['sha256']==row['reference_sha256'] and old_source==(root/'source-config'/name).read_text()
 assert apply(old_source,sections[name])==new
for name,pkg in [('Cargo.lock','mech'),('benchmarks/mech-deflate/native-profile/Cargo.lock','mech-compression-native-profile')]:
 before=tomllib.loads((root/'reference-source'/name).read_text())['package'];after=tomllib.loads((root/'candidate-source'/name).read_text())['package'];a={(r['name'],r['version']):r for r in before};b={(r['name'],r['version']):r for r in after}
 assert set(b)-set(a)=={('mimalloc','0.1.39'),('libmimalloc-sys','0.1.35')}
 for key,item in a.items():
  if key[0]==pkg:item=dict(item,dependencies=sorted(item['dependencies']+['mimalloc']))
  assert b[key]==item
for row in read(root/'allocator-dependencies.json'):assert pin(root/'allocator-dependencies'/(row['name']+'-'+row['version']+'.crate'))['sha256']==row['sha256']
check=read(root/'candidate-check.json');build=read(root/'candidate-build.json');cli_check=read(root/'candidate-cli-check.json')
for row in [check,build,cli_check]:assert row['exit_code']==0 and row['base_commit']==state['base_commit'] and row['patch_sha256']==state['patch_sha256'] and row['CARGO_INCREMENTAL']=='0'
assert build['binary_sha256']==binaries['candidate']
cli=[json.loads(s) for s in (root/'candidate-cli-check.jsonl').read_text().splitlines()];cli=[x for x in cli if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('name')=='mech' and 'bin' in x['target']['kind']];assert len(cli)==1 and 'compiler' in cli[0]['features'] and 'cranelift_build' in cli[0]['features']
for package in ['mimalloc','libmimalloc-sys']:
 artifacts=[json.loads(s) for s in (root/'candidate-build.jsonl').read_text().splitlines()];artifacts=[x for x in artifacts if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('name')==package.replace('-','_') and x['target']['kind']==['lib']];assert len(artifacts)==1 and artifacts[0]['features']==[]
def errors(path):
 rows=[json.loads(x) for x in path.read_text().splitlines()];return [dict(message=x['message']['message'],code=x['message'].get('code',{}).get('code'),spans=[dict(file=s['file_name'],line=s['line_start']) for s in x['message']['spans'] if s['is_primary']]) for x in rows if x.get('reason')=='compiler-message' and x.get('message',{}).get('level')=='error']
first=root/'cli-default-first-attempt';assert read(first/'candidate-cli-check.json')['exit_code']==read(root/'baseline-cli-check.json')['exit_code']==101
failures=errors(first/'candidate-cli-check.jsonl');assert failures==errors(root/'baseline-cli-check.jsonl')==read(root/'cli-default-error-comparison.json')['errors'] and len(failures)==2
for row in read(root/'baseline-cli-check.json')['source_pins']:assert row['sha256']==pin(root/'reference-source'/row['path'])['sha256']
'''
suffix=r'''
pipeline=read(root/'qualification-pipeline.json');assert [r['stage'] for r in pipeline]==['screens','executable-gates','fixtures-object-cohort'] and all(r['state']=='complete' and r['exit_code']==0 for r in pipeline)
native_summary=None
if (root/'native-cohort.json').exists():
 native=read(root/'native-cohort.json');assert len(native)==8
 for row,(variant,name) in zip(native,[(v,'native-'+n) for v,n in order]):
  d=root/name;cmd=read(d/'command.json');actual=read(d/'result.json');assert row==dict(actual,name=name,primary_cohort=True) and row['variant']==variant and row['compiler_exit_code']==row['link_exit_code']==0 and row['matches_complete_baseline_executable']
  assert pin(d/'worker')==exe and cmd['flags']==wanted and cmd['compiler_sha256']==binaries[variant] and cmd['ZERO_AR_DATE']=='1'
  for filename,item in expected.items():assert pin(d/filename)==item and row['files'][filename]==dict(item,matches_frozen_reference=True)
 nf={key:(lambda r,k=key:r[k]) for key in ['source_to_executable_seconds','source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']};nnums=numerical(native,nf);nblocks=[]
 for group in [native[:4],native[4:]]:
  means={v:statistics.mean(row['source_to_executable_seconds'] for row in group if row['variant']==v) for v in ['control','candidate']};means['mean_reduction_fraction']=1-means['candidate']/means['control'];nblocks.append(means)
 saved=read(root/'native-numerical-summary.json');assert nnums==saved['numerical_summary'] and nblocks==saved['balanced_blocks'];native_summary=dict(numerical_summary=nnums,balanced_blocks=nblocks)
if decision['decision']=='retained':
 assert native_summary and all(x['mean_reduction_fraction']>0 for x in native_summary['balanced_blocks'])
 commit=read(root/'qualification-commit.json');assert commit['source_commit']==decision['source_commit']==publication['source_revision'] and commit['parent']==state['base_commit'] and commit['entire_commit_diff_sha256']==state['patch_sha256'] and set(commit['files'])==set(sections)
else:assert decision['decision']=='rejected' and decision['production_source_restored'] and decision['canonical_tool_sha256']==control_binary
summary=dict(source_revision=publication['source_revision'],source_base=state['base_commit'],source_patch_sha256=state['patch_sha256'],compiler_binary_sha256=binaries,decision=decision,check=check,build=build,native_cli_check=cli_check,default_cli_failure_comparison=read(root/'cli-default-error-comparison.json'),output_hashes=expected,final_executable=exe,program_flags_count=61,measured_compile_threads=2,fixture_pairs=14,numerical_summary=nums,balanced_blocks=blocks(rows,fields),preliminary_screens=screens,final_links=links,native=native_summary,scope=[
 'Pinned mimalloc in compiler executables only through one shared module, registered in the native rootCLI with compiler feature and in compile_profile. Library consumers and emitted programs keep their allocator. No override/debug/secure allocator features or compiler algorithm/grammar/proof/admission changes. Lockfiles add only mimalloc0.1.39/libmimalloc-sys0.1.35, with some root package-block ordering changes and no upgrades.',
 'Standard retainedAE/source972 control and currentDeflate/runtime. Eight primary source-to-Object and any separately recorded complete-executable observations use serial ABBA/BAAB order;61programflags+2workers common. Fixed adapter cached. Construction,checks,screens,fixtures and archival excluded; no heavy competing job overlaps primary timing. Alladverseobservations remain.',
 'Every source,bytecode,Object,complete metadata byte and cached complete executable matches. Fourteen fixturepairs match. No new emitted-program runtime performance campaign is claimed. Root defaultCLI check fails with the same two preexisting E0433feature-gating errors on original baseline and allocator candidate; real nativeCLI with explicit cranelift_build check passes. The first missing-source-checksum setup failure is preserved.',
 'Compiler executables/dependency libraries are excluded and hash-pinned. Pure replay checks saved sources/data and recomputes means/blocks without new compilation or timing. Complete compilation below ten seconds remains open until separately verified.'
])
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';saved=root/'summary.json'
if saved.exists():assert saved.read_text()==encoded
else:saved.write_text(encoded)
print(encoded,end='')
'''
p=Path('/private/tmp/mech-replay-compiler-mimalloc-20261115.py');p.write_text(helpers+prefix+core+suffix);compile(p.read_text(),str(p),'exec');print('Replay prepared only; actual decision/native observations checked after qualification.')
