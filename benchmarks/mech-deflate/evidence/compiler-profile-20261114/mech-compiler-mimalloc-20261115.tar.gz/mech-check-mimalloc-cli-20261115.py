from pathlib import Path
import hashlib,json,os,subprocess,shutil,time
repo=Path.cwd();root=Path('/private/tmp/mech-compiler-mimalloc-20261115');state=json.loads((root/'source-state.json').read_text());preserved=root/'cli-default-first-attempt';preserved.mkdir();paths=['Cargo.toml','Cargo.lock','src/bin/mech.rs']
for p in root.glob('candidate-cli-check.*'):shutil.copy2(p,preserved/p.name)
env=dict(os.environ,CARGO_TARGET_DIR='/private/tmp/mech-level12-compile-target',CARGO_INCREMENTAL='0');assert not env.get('RUSTFLAGS') and not env.get('CARGO_ENCODED_RUSTFLAGS')
try:
 for name in paths:(repo/name).write_bytes((root/'reference-source'/name).read_bytes())
 command=['cargo','+nightly-2026-03-03','check','--locked','--offline','--profile','compiler','-j4','--manifest-path','Cargo.toml','--bin','mech','--message-format=json'];started=time.monotonic()
 with (root/'baseline-cli-check.jsonl').open('w') as stdout,(root/'baseline-cli-check.stderr').open('w') as stderr:completed=subprocess.run(command,cwd=repo,env=env,stdout=stdout,stderr=stderr)
 record=dict(command=command,exit_code=completed.returncode,seconds=time.monotonic()-started,scope='Original7931root manifest/lock/bin, no allocator registration or dependency. Benchmark-only files and unused allocator module are not consumed by this rootCLI build. Engine/native sources are unchanged.',source_pins=[dict(path=p,sha256=hashlib.sha256((repo/p).read_bytes()).hexdigest()) for p in paths]);(root/'baseline-cli-check.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
finally:
 for name in paths:(repo/name).write_bytes((root/'candidate-source'/name).read_bytes())
def errors(path):
 rows=[json.loads(x) for x in path.read_text().splitlines()];return [dict(message=x['message']['message'],code=x['message'].get('code',{}).get('code'),spans=[dict(file=s['file_name'],line=s['line_start']) for s in x['message']['spans'] if s['is_primary']]) for x in rows if x.get('reason')=='compiler-message' and x.get('message',{}).get('level')=='error']
a=errors(preserved/'candidate-cli-check.jsonl');b=errors(root/'baseline-cli-check.jsonl');assert a==b and len(a)==2 and all(x['code']=='E0433' and 'native_collection_templates' in x['message'] for x in a)
(root/'cli-default-error-comparison.json').write_text(json.dumps(dict(errors=a,identical_baseline_and_candidate=True,scope='Existing default feature-gating error, unrelated to allocator. Next check adds the actual native compiler feature cranelift_build to the same candidate.'),indent=2)+'\n')
command=['cargo','+nightly-2026-03-03','check','--locked','--offline','--profile','compiler','-j4','--manifest-path','Cargo.toml','--bin','mech','--features','cranelift_build','--message-format=json'];started=time.monotonic()
with (root/'candidate-cli-check.jsonl').open('w') as stdout,(root/'candidate-cli-check.stderr').open('w') as stderr:completed=subprocess.run(command,cwd=repo,env=env,stdout=stdout,stderr=stderr)
record=dict(command=command,base_commit=state['base_commit'],patch_sha256=state['patch_sha256'],exit_code=completed.returncode,seconds=time.monotonic()-started,CARGO_TARGET_DIR=env['CARGO_TARGET_DIR'],CARGO_INCREMENTAL='0',scope='Real root native CLI with its explicit cranelift_build feature; original default feature-gating failure compared againstbaseline and preserved.')
(root/'candidate-cli-check.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);assert completed.returncode==0
assert all((repo/row['path']).read_bytes()==(root/'candidate-source'/row['path']).read_bytes() for row in state['files'])
