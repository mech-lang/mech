from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
repo=Path.cwd();root=Path('/private/tmp/mech-compiler-mimalloc-20261115');state=json.loads((root/'source-state.json').read_text());paths=[r['path'] for r in state['files']];patch=(root/'candidate.patch').read_bytes();new_path='src/compiler_allocator.rs'
def current_patch():
 tracked=subprocess.check_output(['git','diff','--binary','--',*[p for p in paths if p!=new_path]]);added=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',new_path],capture_output=True);assert added.returncode==1;return tracked+added.stdout
def frozen():
 assert current_patch()==patch
 assert sorted(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines())==sorted(p for p in paths if p!=new_path)
 assert subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()==[new_path]
 assert all((repo/p).read_bytes()==(root/'candidate-source'/p).read_bytes() for p in paths)
frozen();env=dict(os.environ,CARGO_TARGET_DIR='/private/tmp/mech-level12-compile-target',CARGO_INCREMENTAL='0');assert not env.get('RUSTFLAGS') and not env.get('CARGO_ENCODED_RUSTFLAGS')
(root/'rustc-version.txt').write_text(subprocess.check_output(['rustc','+nightly-2026-03-03','-Vv'],text=True))
for name,manifest,stage,binary in [('check','benchmarks/mech-deflate/native-profile/Cargo.toml','check','compile_profile'),('build','benchmarks/mech-deflate/native-profile/Cargo.toml','build','compile_profile'),('cli-check','Cargo.toml','check','mech')]:
 frozen();command=['cargo','+nightly-2026-03-03',stage,'--locked','--offline','--profile','compiler','-j4','--manifest-path',manifest,'--bin',binary,'--message-format=json'];started=time.monotonic()
 with (root/('candidate-'+name+'.jsonl')).open('w') as stdout,(root/('candidate-'+name+'.stderr')).open('w') as stderr:completed=subprocess.run(command,cwd=repo,env=env,stdout=stdout,stderr=stderr)
 row=dict(command=command,base_commit=state['base_commit'],patch_sha256=hashlib.sha256(patch).hexdigest(),exit_code=completed.returncode,seconds=time.monotonic()-started,CARGO_TARGET_DIR=env['CARGO_TARGET_DIR'],CARGO_INCREMENTAL='0')
 if completed.returncode==0 and name=='build':
  rows=[json.loads(x) for x in (root/'candidate-build.jsonl').read_text().splitlines()];bins=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='compile_profile' and r.get('executable')];assert len(bins)==1;shutil.copy2(bins[0],root/'candidate');row.update(binary=str(root/'candidate'),binary_sha256=hashlib.sha256((root/'candidate').read_bytes()).hexdigest())
 (root/('candidate-'+name+'.json')).write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True);assert completed.returncode==0
frozen()
