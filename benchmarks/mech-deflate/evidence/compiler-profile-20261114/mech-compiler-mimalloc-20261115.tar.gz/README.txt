Compiler-executable allocator trial on currentDeflate/currentruntime.
Control is immutable retainedAE/source972. Candidate uses pinned mimalloc only
in the native rootCLI compiler and profiling executable through one shared
module; library consumers and emitted programs do not register that allocator.
No override/debug/secure allocator features, compiler algorithms or grammar
change. Cached crate archives and Cargo checksums are included. Lockfiles add
only two packages; some root lock package blocks are reordered, no upgrades.
All7source files, complete patch, commands, failed setup and realCLI checks,
reference outputs,14fixtures, balanced Object/fullnative observations when
performed, complete metadata/executable gates, fixed runtime inputs and pure
replay are retained. The root default CLI feature-gating error is reproduced
on unchanged baseline; explicit cranelift_build nativeCLI check is separate.
Compiler executables/dependency libraries are excluded and hash-pinned.
Primary timings are serial and uncontended; build/check, tests, screens and
archival are excluded. No new runtime performance campaign is claimed when
complete emitted executable bytes match. Sub10s remains open until verified.
