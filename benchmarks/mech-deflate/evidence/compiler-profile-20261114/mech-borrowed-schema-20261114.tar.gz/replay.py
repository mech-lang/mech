from pathlib import Path
import json,hashlib,re,statistics,subprocess,sys
root=Path(__file__).resolve().parent;raw=root/'compiler';read=lambda p:json.loads(p.read_text())
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
state=read(raw/'source-state.json');build=read(raw/'candidate-build.json');control=read(raw/'control-origin.json');prior=read(root/'validation/current-memory.json');prior_receipt=read(root/'validation/current-memory.archive.json')
assert pin(root/'validation/current-memory.json')['sha256']==prior_receipt['replay_sha256']
assert state['control_production_source_identical_to_base'] and build['exit_code']==0 and build['head']==state['base_commit']
assert pin(raw/'candidate.patch')==pin(root/'source-change.patch') and pin(raw/'candidate.patch')['sha256']==build['patch_sha256']==state['patch_sha256']
assert control['sha256']==prior['compiler_binary_sha256']=='355f6c9a44444be3a1db893d7b2298a415bc84675d88eaf896bad95d57011376'
assert build['binary_sha256']=='77fc1fa9d8b2c07204ab09f76b0980a0d1925d5f6c5387d0a236e1f5cc93dd33'
for r in read(root/'excluded-executables.json'):assert r['sha256']==(control['sha256'] if r['path']=='control' else build['binary_sha256'])
flags=read(raw/'runtime-flags.json');assert len(flags)==54 and flags['MECH_NORMALIZE_DEFAULTED_READ_SETUP']=='1'
expected=prior['output_hashes'];rows=read(raw/'cohort.json');assert [r['variant'] for r in rows]==['control','candidate','candidate','control']
for name in ['candidate-screen',*[r['name'] for r in rows]]:
 d=raw/name;assert read(d/'process.json')['exit_code']==0 and read(d/'process.json')['samples']==0
 command=read(raw/(name+'-command.json'));assert command['flags']==flags
 assert command['binary_sha256']==(control['sha256'] if name.startswith('control-') else build['binary_sha256'])
 for filename,pinned in expected.items():assert pin(d/filename)==pinned and read(d/'output-check.json')[filename]==dict(pinned,matches_previous_qualified_output=True)
for row in rows:
 d=raw/row['name'];assert row['compile']==read(d/'compile.json') and row['process']==read(d/'process.json') and row['files']==read(d/'output-check.json')
 stamps=[json.loads(line) for line in (d/'stages.jsonl').read_text().splitlines()]
 for key,begin,end in [('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]:assert row[key]==next(s['elapsed'] for s in stamps if s['line'].startswith(end))-next(s['elapsed'] for s in stamps if s['line'].startswith(begin))
 for key,pattern in [('max_rss_bytes',r'(\d+)  maximum resident set size'),('instructions',r'(\d+)  instructions retired'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]:assert row[key]==int(re.search(pattern,(d/'stderr.log').read_text()).group(1))

test_counts={}
for name,expected_counts in [('core-test',[188]),('core-contract-test',[0,7,14,3,17,21,9,34]),('core-serde-vectors',[2]),('frontend-tests',[60]),('codec-tests',[2])]:
 assert read(raw/(name+'-command.json'))['exit_code']==0
 counts=list(map(int,re.findall(r'test result: ok\. (\d+) passed',(raw/(name+'.log')).read_text())))
 assert counts==expected_counts
 test_counts[name]=sum(counts)
assert sum(test_counts.values())==357
assert read(raw/'core-no-std-command.json')['exit_code']==0
contracts=(root/'source/src/core/tests/schema_contract.rs').read_text()
assert 'finalize_body' in contracts and 'finalize_ref' in contracts
fixtures=read(raw/'fixture-results.json');assert len(fixtures)==14
for row in fixtures:
 assert row['all_outputs_match'] and row['variants']['control']==row['variants']['candidate'] and row['variants']['control']['exit_code']==0 and len(row['variants']['control']['files'])==4
 name=Path(row['fixture']).stem if ':' not in row['fixture'] else row['fixture'].split(':')[-1]
 for variant,record in row['variants'].items():
  d=raw/'fixtures'/name/variant;assert read(d/'command.json')['flags']==flags
  assert read(d/'command.json')['binary_sha256']==(control['sha256'] if variant=='control' else build['binary_sha256'])
  for filename,pinned in record['files'].items():assert pin(d/filename)==pinned
  assert record['files']['source.mec']['sha256']==row['source_sha256']
base=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase.mec').read_text();fragment=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase-states.mec').read_text();assembled=base.replace('+> sequence\n','+> sequence\n'+fragment+'\n',1).replace('phase-candidates(values, 1u64, 0u64, permitted, divisor)','#PhaseCandidates(values, permitted, divisor, 1u64, 0u64)',1);assert assembled==(raw/'fixture-inputs/numeric-nested-phase-states.mec').read_text()
fields={'compiler_seconds':lambda r:r['compile']['total_seconds'],'whole_process_seconds':lambda r:r['process']['elapsed_seconds'],'parse_seconds':lambda r:next(p['seconds'] for p in r['compile']['phases'] if p['phase']=='parse'),'frontend_seconds':lambda r:next(p['seconds'] for p in r['compile']['phases'] if p['phase']=='frontend'),'native_seconds':lambda r:next(p['seconds'] for p in r['compile']['phases'] if p['phase']=='native')}
for key in ['canonical_lowering_seconds','preparation_seconds','numeric_generation_seconds','source_cfg_seconds','cleanup_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:fields[key]=lambda r,key=key:r[key]
qualified={key:{v:[f(r) for r in rows if r['variant']==v] for v in ['control','candidate']} for key,f in fields.items()}
for record in qualified.values():record['mean_reduction_fraction']=1-statistics.mean(record['candidate'])/statistics.mean(record['control'])


census=json.loads(subprocess.check_output([sys.executable,str(root/'census.py')],text=True));assert census==read(raw/'backend-duplicate-census.json')
assert (census['functions'],census['unique_code_and_raw_relocation_groups'],census['duplicate_functions_beyond_first'])==(358,234,124)
assert census['object_sha256']==expected['program.o']['sha256']
summary={'source_commit':state['source_commit'],'base_commit':state['base_commit'],'hardware':state['hardware'],'decision':'Retain borrowed schema-environment finalization with all validation and generated bytes unchanged','flags_count':54,'qualified':qualified,'output_hashes':expected,'compiler_binary_sha256':{'control':control['sha256'],'candidate':build['binary_sha256']},'candidate_patch_sha256':state['patch_sha256'],'candidate_bootstrap_seconds':build['seconds'],'tests':dict(test_counts,total=357,no_std_check=True,complete_array_enum_fixtures=6,scalar_fixtures=8),'fixture_output_comparisons':fixtures,'backend_duplicate_census':census,'scope':[
 'Four serial ABBA fresh full source-to-Object observations with identical 54 existing runtime flags and host statistics. Compiler bootstrap, screen, tests, fixtures, diagnostic census and archiving are excluded. No competing work from this campaign overlaps primary timing.',
 'The owned finalizer and new finalize_ref/finalize_body methods use the same canonicalizer and ordered validation. The complete dimension environment is borrowed instead of cloned; the body is still owned. No semantic proof, catalog or factory-selection result is cached.',
 'Every declaration is still validated, including unused malformed declarations. Contract tests preserve component axis relationships, renumbering, bounds, original error precedence and visibility of draft mutation.',
 'All source, MBC, Object and complete metadata bytes match the current qualified reduction-rotation control in every primary observation and separate screen. All four outputs also match between subjects in six complete array/enum and eight checked scalar programs.',
 'All 357 Core, contract, serde-vector, frontend and codec tests pass, along with Core no_std checking. The initial no-default-feature canonical-vector target runs zero tests because of its serde gate; only the explicit two-test serde run counts as vector coverage.',
 'Compiler time, frontend time, retired instructions and peak RSS improve in this matched cohort. All unchanged-stage variation, including adverse native-stage observations, remains without causal attribution to this frontend change. Four compiles are descriptive, not a population estimate.',
 'A separate frozen-Object census observes 358 functions, 234 distinct byte/raw-relocation groups and 124 duplicate functions beyond the first. It includes inter-function alignment and is not an IR-equivalence proof or a validated backend cache key. No cached compilation is used.',
 'No new runtime-latency campaign is claimed; main/helper machine code and complete metadata remain byte-identical. State-fixture assembly provenance includes earlier attempts, not a new fragment-only launch.',
 'Grammar, language, current-visit/ownership checks, finite admission and backend optimization level are unchanged. Full fresh compilation remains above ten seconds.'
]}
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
