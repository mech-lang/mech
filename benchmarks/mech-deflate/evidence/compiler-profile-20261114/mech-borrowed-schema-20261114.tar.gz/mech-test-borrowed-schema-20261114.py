from pathlib import Path
import subprocess,time,json,os,re
root=Path('/private/tmp/mech-borrowed-schema-20261114')
base=['cargo','test','--locked','--offline','--release','-j2','--manifest-path','src/core/Cargo.toml','--no-default-features']
commands=[('core-test',base+['--lib']),('core-contract-test',base+['--test','type_system_builtin','--test','type_system_contract','--test','type_system_conversion','--test','type_system_solver','--test','schema_contract','--test','dimension_contract','--test','schema_dimension_relations','--test','canonical_schema_vectors']),('core-no-std',['cargo','check','--locked','--offline','--release','-j1','--manifest-path','src/core/Cargo.toml','--no-default-features','--features','no_std','--lib'])]
for name,cmd in commands:
 start=time.perf_counter()
 with (root/(name+'.log')).open('w') as log:p=subprocess.run(cmd,env=dict(os.environ,CARGO_TARGET_DIR='/private/tmp/mech-level12-core-test-target',CARGO_INCREMENTAL='0'),stdout=log,stderr=subprocess.STDOUT)
 record={'command':cmd,'exit_code':p.returncode,'seconds':time.perf_counter()-start,'CARGO_TARGET_DIR':'/private/tmp/mech-level12-core-test-target','CARGO_INCREMENTAL':'0'}
 (root/(name+'-command.json')).write_text(json.dumps(record,indent=2)+'\n');print(name,record,flush=True)
 assert p.returncode==0
 if name!='core-no-std':
  counts=[int(n) for n in re.findall(r'test result: ok\. (\d+) passed',(root/(name+'.log')).read_text())];assert sum(counts)>0;print('test counts',counts,flush=True)
