Borrow schema environments during finalization, Apple M3, 2026-11-14.
Retain the time/instruction/peak-RSS improvement. The consuming Core finalizer
and new borrowed methods share the same canonicalizer and validation order.
No declaration validation is skipped, including unused malformed declarations.
No semantic proof, factory selection or catalog result is cached. Mutable drafts
continue to reflect their current fields on every query. The component method
borrows the parent's environment and canonicalizes only its supplied body;
expected axis identity/renumbering and original error precedence are checked.
37 immediate clone/finalize sites and two component helpers avoid cloning the
entire dimension environment. Some changed call sites are existing test code;
all code is retained in the source patch rather than counted as production-only.
Core 188 unit tests, 105 contracts, 2 serialization-enabled canonical-vector
tests, 60 frontend and 2 codec tests pass (357 tests). The no-std check passes.
The initial no-default-feature canonical-vector target has zero tests because
of its serde gate. It is not counted as coverage; the explicit serde run runs
both vector tests. No test failure is concealed or converted into a pass.
Every output matches the current qualified runtime Object/metadata in the
screen, all four fresh source-to-Object ABBA observations and 14 complete
fixture pairs. The same 54 flags and host statistics apply to both frozen
subjects. Compiler bootstrap, tests, fixtures, screen, census and archiving are
excluded from primary timing; no work from this campaign overlaps that cohort.
All adverse unchanged-stage observations are retained without causal attribution.
Observed compiler/frontend time, instructions and peak RSS improve; four
compiles are descriptive observations, not a statistical population.
The separate machine-byte/relocation census finds duplicate helper bodies. It
is a future inspection target, not an IR-equivalence proof, valid cache key or
accepted machine-code cache. No cached compilation is used in this trial.
Grammar, language, normalized schemas, bytecode, current-visit/ownership checks,
finite runtime admission and optimization level remain unchanged. Generated
program bytes match exactly; no new runtime-latency campaign is claimed.
Compiler bootstrap is separately recorded. The ten-second full-process goal
remains open. The complete evidence archive is published under benchmarks/mech-deflate;
compiler executables are excluded. Run python3 replay.py
for pure offline numerical/output/test reconstruction without compilation.
