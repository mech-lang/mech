from pathlib import Path
import subprocess,json,hashlib,shutil
repo=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech');raw=Path('/private/tmp/mech-borrowed-schema-20261114');packet=Path('/private/tmp/mech-borrowed-schema-packet-20261114');assert not packet.exists()
source=subprocess.check_output(['git','rev-parse','2f4134024e'],cwd=repo,text=True).strip();base='0096434d1a487c73aa879a29ffc5b94cc56e1fd3';patch=subprocess.check_output(['git','diff','--binary',base,source],cwd=repo);assert patch==(raw/'candidate.patch').read_bytes()
assert subprocess.check_output(['git','diff','342937b4cba43ed57d08ca78648dde4b188d82b7',base,'--','src','hosts','vendor','machines','.cargo'],cwd=repo)==b''
(raw/'source-state.json').write_text(json.dumps({'source_commit':source,'base_commit':base,'patch_sha256':hashlib.sha256(patch).hexdigest(),'control_source_commit':'342937b4cba43ed57d08ca78648dde4b188d82b7','control_production_source_identical_to_base':True,'hardware':'Apple M3 Air, 8 cores (4P+4E), 16 GB, macOS 26.2','rustc':subprocess.check_output(['rustc','-Vv'],text=True),'cargo':subprocess.check_output(['cargo','-V'],text=True)},indent=2)+'\n')
excluded=[]
for p in sorted(raw.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(raw)
 if str(rel) in ['control','candidate']:
  excluded.append({'path':str(rel),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()});continue
 dest=packet/'compiler'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
(packet/'excluded-executables.json').write_text(json.dumps(excluded,indent=2)+'\n');(packet/'source-change.patch').write_bytes(patch)
paths=subprocess.check_output(['git','diff','--name-only',base,source],cwd=repo,text=True).splitlines();paths+=['benchmarks/mech-deflate/native-profile/'+n for n in ['Cargo.toml','Cargo.lock','compile_profile.rs','profile_compile.py']];paths+=['benchmarks/mech-deflate/experiment.py','.cargo/config.toml','LICENSE','hosts/gpu/tests/fixtures/native/deflate-huffman-LICENSES.md','hosts/gpu/src/native_artifact/program/runtime/composition_tests/nested_phase.rs']
paths+=['src/core/Cargo.toml','src/core/tests/dimension_contract.rs','src/core/tests/schema_dimension_relations.rs','src/core/tests/canonical_schema_vectors.rs','tests/architecture/value-system/canonical-encoding-v1-vectors.json','src/core/src/dimension.rs']
paths+=['hosts/gpu/tests/fixtures/native/'+n+'.mec' for n in ['numeric-nested-phase','numeric-nested-phase-states','numeric-private-fixed-nested','numeric-changing-capture-tree','numeric-array-windows','numeric-multiple-children']]
for name in paths:
 dest=packet/'source'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(subprocess.check_output(['git','show',source+':'+name],cwd=repo))
for name in ['mech-build-borrowed-schema-20261114.py','mech-test-borrowed-schema-20261114.py','mech-run-borrowed-schema-20261114.py','mech-run-borrowed-schema-cohort-20261114.py','mech-borrowed-schema-fixtures-20261114.py','mech-curate-borrowed-schema-20261114.py']:
 shutil.copy2(Path('/private/tmp')/name,packet/name)
for name in ['mech-borrowed-schema-build-driver-20261114.log','mech-borrowed-schema-screen-driver-20261114.log','mech-borrowed-schema-cohort-driver-20261114.log','mech-borrowed-schema-fixtures-driver-20261114.log']:
 shutil.copy2(Path('/private/tmp')/name,packet/name)
validation=packet/'validation';validation.mkdir();shutil.copy2(Path('/private/tmp/mech-rotation-integration-20261114/current-build.json'),validation/'control-build.json')
shutil.copy2(repo/'benchmarks/mech-deflate/native-profile/current-pipeline-memory-apple-m3-20261114.archive.json',validation/'current-memory.archive.json')
shutil.copy2(repo/'benchmarks/mech-deflate/native-profile/current-pipeline-memory-apple-m3-20261114.json',validation/'current-memory.json')
for name in ['mech-test-borrowed-schema-serde-20261114.py','mech-test-borrowed-schema-frontend-20261114.py','mech-census-native-duplicates-20261114.py','mech-borrowed-schema-test-driver-20261114.log','mech-borrowed-schema-serde-driver-20261114.log','mech-borrowed-schema-frontend-driver-20261114.log']:
 shutil.copy2(Path('/private/tmp')/name,packet/name)
shutil.copytree(repo/'benchmarks/mech-deflate/.experiments/compile-peers-apple-m3-20261113/packet/licenses',packet/'licenses')
(packet/'README.txt').write_text("""Borrow schema environments during finalization, Apple M3, 2026-11-14.
Retain the time/instruction/peak-RSS improvement. The consuming Core finalizer
and new borrowed methods share the same canonicalizer and validation order.
No declaration validation is skipped, including unused malformed declarations.
No semantic proof, factory selection or catalog result is cached. Mutable drafts
continue to reflect their current fields on every query. The component method
borrows the parent's environment and canonicalizes only its supplied body;
expected axis identity/renumbering and original error precedence are checked.
37 immediate clone/finalize sites and two component helpers avoid cloning the
entire dimension environment. Some changed call sites are existing test code;
all code is retained in the source patch rather than counted as production-only.
Core 188 unit tests, 105 contracts, 2 serialization-enabled canonical-vector
tests, 60 frontend and 2 codec tests pass (357 tests). The no-std check passes.
The initial no-default-feature canonical-vector target has zero tests because
of its serde gate. It is not counted as coverage; the explicit serde run runs
both vector tests. No test failure is concealed or converted into a pass.
Every output matches the current qualified runtime Object/metadata in the
screen, all four fresh source-to-Object ABBA observations and 14 complete
fixture pairs. The same 54 flags and host statistics apply to both frozen
subjects. Compiler bootstrap, tests, fixtures, screen, census and archiving are
excluded from primary timing; no work from this campaign overlaps that cohort.
All adverse unchanged-stage observations are retained without causal attribution.
Observed compiler/frontend time, instructions and peak RSS improve; four
compiles are descriptive observations, not a statistical population.
The separate machine-byte/relocation census finds duplicate helper bodies. It
is a future inspection target, not an IR-equivalence proof, valid cache key or
accepted machine-code cache. No cached compilation is used in this trial.
Grammar, language, normalized schemas, bytecode, current-visit/ownership checks,
finite runtime admission and optimization level remain unchanged. Generated
program bytes match exactly; no new runtime-latency campaign is claimed.
Compiler bootstrap is separately recorded. The ten-second full-process goal
remains open. Raw files and executables stay outside Git. Run python3 replay.py
for pure offline numerical/output/test reconstruction without compilation.
""");print(packet,flush=True)
