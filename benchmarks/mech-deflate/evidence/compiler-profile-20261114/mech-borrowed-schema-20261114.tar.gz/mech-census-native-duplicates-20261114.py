from pathlib import Path
import struct,json,hashlib,collections
p=Path('/private/tmp/mech-rotation-integration-20261114/stage-memory/program.o');b=p.read_bytes();off=32;sections=[];syminfo=None
for _ in range(struct.unpack_from('<I',b,16)[0]):
 cmd,size=struct.unpack_from('<II',b,off)
 if cmd==0x19:
  for i in range(struct.unpack_from('<I',b,off+64)[0]):
   o=off+72+i*80;sections.append({'name':b[o:o+16].rstrip(b'\0').decode(),'addr':struct.unpack_from('<Q',b,o+32)[0],'size':struct.unpack_from('<Q',b,o+40)[0],'offset':struct.unpack_from('<I',b,o+48)[0],'reloff':struct.unpack_from('<I',b,o+56)[0],'nreloc':struct.unpack_from('<I',b,o+60)[0]})
 if cmd==2:syminfo=struct.unpack_from('<IIII',b,off+8)
 off+=size
so,n,st,sz=syminfo;symbols=[]
for i in range(n):
 ix,typ,sec,desc,addr=struct.unpack_from('<IBBHQ',b,so+16*i);name=b[st+ix:b.index(0,st+ix)].decode();symbols.append({'name':name,'type':typ,'section':sec,'address':addr})
text_id=next(i for i,s in enumerate(sections,1) if s['name']=='__text');text=sections[text_id-1];funcs=sorted([s for s in symbols if (s['type']&0xe)==0xe and s['section']==text_id and s['name'].startswith('_mech_')],key=lambda s:s['address']);relocs=[struct.unpack_from('<iI',b,text['reloff']+8*i) for i in range(text['nreloc'])]
groups=collections.defaultdict(list)
for i,f in enumerate(funcs):
 start=f['address']-text['addr'];end=funcs[i+1]['address']-text['addr'] if i+1<len(funcs) else text['size'];code=b[text['offset']+start:text['offset']+end]
 r=[(a-start,word) for a,word in relocs if start<=a<end];key=(hashlib.sha256(code).hexdigest(),tuple(r));groups[key].append({'name':f['name'],'bytes_with_alignment':len(code)})
duplicates=[v for v in groups.values() if len(v)>1];result={'object_sha256':hashlib.sha256(b).hexdigest(),'functions':len(funcs),'unique_code_and_raw_relocation_groups':len(groups),'duplicate_functions_beyond_first':sum(len(g)-1 for g in duplicates),'duplicate_groups':sorted(duplicates,key=lambda g:len(g)*g[0]['bytes_with_alignment'],reverse=True),'scope':'Object-level byte/relocation census including inter-function alignment, not an IR equivalence proof or a validated compilation-cache key.'};dest=Path('/private/tmp/mech-borrowed-schema-20261114/backend-duplicate-census.json');dest.write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items() if k!='duplicate_groups'});print('largest groups',[(len(g),g[0]['bytes_with_alignment'],g[0]['name']) for g in result['duplicate_groups'][:8]])
