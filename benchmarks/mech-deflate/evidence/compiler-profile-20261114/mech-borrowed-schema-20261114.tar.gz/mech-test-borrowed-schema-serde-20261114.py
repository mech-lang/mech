from pathlib import Path
import subprocess,time,json,os,re
root=Path('/private/tmp/mech-borrowed-schema-20261114');cmd=['cargo','test','--locked','--offline','--release','-j2','--manifest-path','src/core/Cargo.toml','--no-default-features','--features','serde','--test','canonical_schema_vectors'];start=time.perf_counter()
with (root/'core-serde-vectors.log').open('w') as log:p=subprocess.run(cmd,env=dict(os.environ,CARGO_TARGET_DIR='/private/tmp/mech-level12-core-test-target',CARGO_INCREMENTAL='0'),stdout=log,stderr=subprocess.STDOUT)
r={'command':cmd,'exit_code':p.returncode,'seconds':time.perf_counter()-start,'CARGO_TARGET_DIR':'/private/tmp/mech-level12-core-test-target','CARGO_INCREMENTAL':'0'};(root/'core-serde-vectors-command.json').write_text(json.dumps(r,indent=2)+'\n');print(r,flush=True);assert p.returncode==0
counts=[int(n) for n in re.findall(r'test result: ok\. (\d+) passed',(root/'core-serde-vectors.log').read_text())];assert sum(counts)>0;print('test counts',counts,flush=True)
