from pathlib import Path
import hashlib
import json
import re
import statistics
import subprocess
import sys

packet = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_text())
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
state = read(packet / 'source-state.json')
selection = packet / 'selection'
proof = read(selection / 'conclusion.json')
assert proof['original_source_unchanged_since_c5b']
assert proof['compiler_sha256'] == 'c5b0b57e2cc870d3e024d2d2c38c9a478122da5f72faf3bbaa3a868cb494a56f'
for row in proof['samples']:
    assert row['caller_return_pc'] - row['image_base'] + row['preferred_text_address'] == row['normalized_return_pc'] == 0x1022cba08
    assert pin(selection / row['name'] / 'sample-001.txt')['sha256'] == row['raw_sha256']
    assert pin(selection / row['name'] / 'demangled.txt')['sha256'] == row['demangled_sha256']
    assert hex(row['caller_return_pc']) in (selection / row['name'] / 'caller-excerpt.txt').read_text()
assert re.search(r'segname __TEXT\s+vmaddr 0x0000000100000000', (selection / 'macho-headers.txt').read_text())
assert re.search(r'1022cb9f8:\s+lsl\s+x2,\s*x28,\s*#3', (selection / 'disassembly.txt').read_text())
assert re.search(r'1022cba04:\s+bl\s+', (selection / 'disassembly.txt').read_text())
subprocess.run([sys.executable,str(selection / 'analyze_profiles.py'),str(selection)],check=True,stdout=subprocess.PIPE)
assert pin(packet / 'candidate.patch')['sha256'] == state['patch_sha256']
for row in state['files']:
    assert pin(packet / 'reference-source' / row['path'])['sha256'] == row['sha256']
    assert pin(packet / 'candidate-source' / row['path'])['sha256'] == row['candidate_sha256']
commit_path = packet / 'qualification-commit.json'
commit = read(commit_path) if commit_path.exists() else dict(source_commit=None)
if commit_path.exists():
    assert commit['parent'] == state['base_commit']
    assert commit['entire_commit_diff_sha256'] == state['patch_sha256']
    assert commit['entire_commit_diff_matches_measured_patch']
excluded = read(packet / 'excluded-products.json')
assert excluded['control']['sha256'] == '95765da02083977c08a4cbe9368e841ef7922006a0a02f0e70b9cd2d5e1aea79'
assert read(packet / 'candidate-build.json')['binary_sha256'] == excluded['candidate']['sha256']
for name in ['candidate-check', 'candidate-build', 'candidate-cli-check']:
    row = read(packet / (name + '.json'))
    assert row['exit_code'] == 0 and row['patch_sha256'] == state['patch_sha256']
assert read(packet / 'focused/build.json')['exit_code'] == read(packet / 'focused/test.json')['exit_code'] == 0
assert 'test result: ok. 3 passed; 0 failed' in (packet / 'focused/test.stdout.log').read_text()
flags = read(packet / 'runtime-flags.json')
assert len(flags) == 61
reference = {name:pin(packet / 'reference' / name) for name in ['source.mec','program.mecb','program.o','metadata.json']}
native = read(packet / 'native-baseline-pins.json')
exe = native['executable']
assert exe == dict(bytes=2060440,sha256='d6c65cc3fb18acc4be77dce329962105bf0f2b56dd2623a12f466256463eca61')
capture = read(packet / 'link-command.json')
inputs = read(packet / 'native-link-inputs.json')
assert [(r['source'],r['bytes'],r['sha256']) for r in inputs] == [(r['source'],r['bytes'],r['sha256']) for r in capture['inputs']]
for row in inputs:
    assert pin(packet / row['path']) == {k:row[k] for k in ['bytes','sha256']}
for variant in ['control','candidate']:
    directory = packet / (variant + '-screen')
    assert read(directory / 'process.json')['exit_code'] == 0
    for name, item in reference.items():
        assert pin(directory / name) == item and (directory / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    assert pin(packet / ('link-' + variant) / 'worker') == exe
gates = read(packet / 'final-executable-results.json')
assert len(gates) == 2 and all(r['exit_code'] == 0 and r['matches_complete_baseline_executable'] and r['executable_sha256'] == exe['sha256'] for r in gates)
fixtures = read(packet / 'fixture-results.json')
assert len(fixtures) == 14
for row in fixtures:
    assert row['all_outputs_match'] and row['variants']['control'] == row['variants']['candidate']
    for variant in ['control','candidate']:
        entry = row['variants'][variant]
        assert entry['exit_code'] == 0 and len(entry['files']) == 4
        name = Path(row['fixture'].split(':')[-1]).stem
        directory = packet / 'fixtures' / name / variant
        for filename, item in entry['files'].items():
            assert pin(directory / filename) == item
            assert (directory / filename).read_bytes() == (packet / 'fixtures' / name / 'control' / filename).read_bytes()
rows = read(packet / 'cohort.json')
assert len(rows) == 8
order = ['control-1','candidate-1','candidate-2','control-2','candidate-3','control-3','control-4','candidate-4']
assert [r['name'] for r in rows] == order
for row in rows:
    directory = packet / row['name']
    assert row['compile'] == read(directory / 'compile.json') and row['process'] == read(directory / 'process.json')
    assert row['process']['exit_code'] == 0
    command = read(packet / (row['name'] + '-command.json'))
    assert command['binary_sha256'] == excluded[row['variant']]['sha256']
    assert command['flags'] == dict(flags, MECH_COMPACT_COMPILE_THREADS='2')
    for name, item in reference.items():
        assert pin(directory / name) == item and (directory / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    stamps = [json.loads(line) for line in (directory / 'stages.jsonl').read_text().splitlines()]
    for key, begin, end in [('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code'),('compaction_seconds','compact-stage: compact values before=','compact-stage: CFG cleanup')]:
        assert row[key] == next(s['elapsed'] for s in stamps if s['line'].startswith(end)) - next(s['elapsed'] for s in stamps if s['line'].startswith(begin))
    assert row['cleanup_including_compaction_seconds'] == row['cleanup_seconds'] + row['compaction_seconds']
    log = (directory / 'stderr.log').read_text()
    for key, pattern in [('max_rss_bytes',r'(\d+)  maximum resident set size'),('instructions',r'(\d+)  instructions retired'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]:
        assert row[key] == int(re.search(pattern,log).group(1))
fields = dict(compiler_seconds=lambda r:r['compile']['total_seconds'],whole_process_seconds=lambda r:r['process']['elapsed_seconds'])
for phase in ['parse','catalog','frontend','artifact','encode','native']:
    fields[phase+'_seconds'] = lambda r,p=phase: next(v['seconds'] for v in r['compile']['phases'] if v['phase']==p)
for key in ['canonical_lowering_seconds','preparation_seconds','numeric_generation_seconds','source_cfg_seconds','cleanup_including_compaction_seconds','cleanup_seconds','compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:
    fields[key] = lambda r,k=key:r[k]
summary = {}
for key, fn in fields.items():
    values = {v:[fn(r) for r in rows if r['variant']==v] for v in ['control','candidate']}
    base = statistics.mean(values['control'])
    values['mean_reduction_fraction'] = 1-statistics.mean(values['candidate'])/base if base else None
    summary[key] = values
assert read(packet / 'numerical-summary.json') == summary
native_path = packet / 'native-cohort.json'
native_rows = read(native_path) if native_path.exists() else []
assert len(native_rows) in [0,8]
native_summary = {}
for row in native_rows:
    directory = packet / row['name']
    receipt = read(directory / 'result.json')
    assert row == dict(receipt, name=row['name'], primary_cohort=True)
    assert row['compiler_exit_code'] == row['link_exit_code'] == 0 and row['matches_complete_baseline_executable']
    assert row['executable_bytes'] == exe['bytes'] and row['executable_sha256'] == exe['sha256'] and pin(directory / 'worker') == exe
    for name, item in reference.items():
        assert pin(directory / name) == item and (directory / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    assert abs(row['source_to_executable_seconds']-sum(row[k] for k in ['source_to_object_process_seconds','object_handoff_seconds','native_link_seconds'])) < 1e-8
if native_rows:
    for key in ['source_to_executable_seconds','source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']:
        values = {v:[r[key] for r in native_rows if r['variant']==v] for v in ['control','candidate']}
        values['mean_reduction_fraction'] = 1-statistics.mean(values['candidate'])/statistics.mean(values['control'])
        native_summary[key] = values
    blocks = []
    for block in [native_rows[:4],native_rows[4:]]:
        means = {v:statistics.mean(r['source_to_executable_seconds'] for r in block if r['variant']==v) for v in ['control','candidate']}
        means['mean_reduction_fraction'] = 1-means['candidate']/means['control']
        blocks.append(means)
    saved = read(packet / 'native-numerical-summary.json')
    assert saved['numerical_summary'] == native_summary and saved['balanced_blocks'] == blocks
else:
    blocks = []
if (packet / 'candidate-serial-gate').exists():
    serial = packet / 'candidate-serial-gate'
    assert read(serial / 'process.json')['exit_code'] == 0
    for name, item in reference.items():
        assert pin(serial / name) == item and (serial / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    serial_result = read(packet / 'link-candidate-serial/result.json')
    assert serial_result['matches_complete_baseline_executable'] and serial_result['executable_sha256'] == exe['sha256']
    assert pin(packet / 'link-candidate-serial/worker') == exe
result = dict(source_commit=commit['source_commit'],base_commit=state['base_commit'],patch_sha256=state['patch_sha256'],compiler=excluded,source_state=state,numerical_summary=summary,native_numerical_summary=native_summary,balanced_native_blocks=blocks,output_hashes=reference,final_executable=exe,fixture_pairs=14,focused_tests=3,checks={name:read(packet/(name+'.json')) for name in ['candidate-check','candidate-build','candidate-cli-check']},decision=read(packet/'decision.json'),scope='Immutable-CFG reachability queues each non-stop block once. Same full boolean results and32-rowFIFOcache, same61flags/twoworkers/pinnedmimalloc. Eight uncontended Object observations; complete source-to-executable cohort if present remains separate. Exactall4outputs/complete metadata/wholeexe before primary timing. No runtime/grammar/proof changes or sub-ten-second claim.')
encoded = json.dumps(result,indent=2,sort_keys=True)+'\n'
saved = packet / 'summary.json'
if saved.exists():
    assert saved.read_text() == encoded
else:
    saved.write_text(encoded)
print(encoded,end='')
