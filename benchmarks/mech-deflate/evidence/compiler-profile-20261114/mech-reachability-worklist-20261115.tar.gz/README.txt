Frozenonefile immutable-CFG reachability worklist optimization onbase6b29.
Control957/F077 versus candidateB72, same61flags,2workers,pinnedcompilerallocator.
SampledC5BcallerPCs fromtwo priorpublished37profiles bothnormalize0x1022cba08.
Boundeddisassemblyshows pendingVec successor bulkcopy, disprovingoldFIFOshift
guess.32rowmemo/eviction/Arcsemantics unchanged. Newtraversalmarksnonstopblocks
beforepush so eachisqueuedonce; fullfinalVec<bool> results/stopsemantics same.
Original512shortgraphs/cache tests plus duplicate/self/stoppedcycles allpass.
Compilercheck6.58236s/build250.46176s andrealnativeCLIcheck8.96788s pass;
focusedbuild2.16562s/test.39516s areoutsideprogramtimings. No setupfailures39.
Two completeexebytegates precede eightObjectABBA/BAAB observations.14fixturepairs,
eightseparatecompletebuilds andunpaireddefault0gate preserve all4artifacts,
complete metadata andentire2,060,440byteD6executable. Allprimaryruns serialwith
noheavybuild/test/profile/hash/archive overlap. Fixedruntimeadaptercached;
historicalfirstuse11.882560208s excluded. Completebuild15.694847->15.463704s
(-1.472734%)bothblocks faster. Cleanup-5.451483%,compiler-1.393529%,instructions
-0.406050%; alladverseparse/catalog/preparation/sourceCFG/link/memorymovement
remains. No grammar/proof/finiteaccounting/runtimechanges orsubtenclaim.
Sourceonefilecommit mustequalfrozenpatch8a313dd1. Compiler/testbinariesexcluded
andhashpinned. Everycommand/log,source/patch,observation/output/executable,
nativeinput,raw/demangledselectionprofiles,PC/disassemblyproof andpurereplay
remain. ProfilebinaryC5B isreferenced/hashpinned frompacket37;control957 from38.
