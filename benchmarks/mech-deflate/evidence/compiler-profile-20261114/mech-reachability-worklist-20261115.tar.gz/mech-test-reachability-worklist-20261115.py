from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import time

root = Path('/private/tmp/mech-reachability-worklist-20261115')
out = root / 'focused'
out.mkdir()
state = json.loads((root / 'source-state.json').read_text())
source = Path(state['files'][0]['path'])
assert hashlib.sha256(source.read_bytes()).hexdigest() == state['files'][0]['candidate_sha256']
assert subprocess.check_output(['git','diff','--binary']) == (root / 'candidate.patch').read_bytes()
shutil.copy2(source, out / 'reach.rs')
(out / 'harness.rs').write_text('mod reach;\n')
command = ['rustc','+nightly-2026-03-03','--edition=2024','--crate-name','reachability_worklist_tests','--test',str(out/'harness.rs'),'-C','opt-level=3','-C','lto=thin','-C','codegen-units=1','-D','warnings','-o',str(out/'tests')]
(out / 'configuration.json').write_text(json.dumps(dict(source=source.as_posix(),source_sha256=state['files'][0]['candidate_sha256'],scope='Exact production reachability module with all three unit tests: complete512shortgraph start/stop combinations, cache reuse/eviction/old rows, parallel successors/self/stopped cycles on1/2/17/65nodes. Independent BTreeSet traversal oracle. No source substitutions or runtime authority.'),indent=2)+'\n')
for stage,args in [('build',command),('test',[str(out/'tests'),'--nocapture'])]:
    started=time.monotonic()
    with (out/(stage+'.stdout.log')).open('w') as stdout,(out/(stage+'.stderr.log')).open('w') as stderr:
        completed=subprocess.run(args,stdout=stdout,stderr=stderr)
    row=dict(command=args,exit_code=completed.returncode,seconds=time.monotonic()-started,patch_sha256=state['patch_sha256'])
    (out/(stage+'.json')).write_text(json.dumps(row,indent=2)+'\n')
    print(json.dumps(dict(stage=stage,**row)),flush=True)
    assert completed.returncode==0
assert 'test result: ok. 3 passed; 0 failed' in (out/'test.stdout.log').read_text()
