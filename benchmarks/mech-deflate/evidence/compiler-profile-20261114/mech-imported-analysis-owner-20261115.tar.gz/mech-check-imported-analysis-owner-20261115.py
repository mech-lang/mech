from pathlib import Path
import json
import os
import subprocess
import time

root = Path('/private/tmp/mech-imported-analysis-owner-20261115')
state = json.loads((root / 'source-state.json').read_text())
assert subprocess.check_output(['git','diff','--binary']) == (root / 'candidate.patch').read_bytes()
assert json.loads((root / 'candidate-build.json').read_text())['exit_code'] == 0
assert json.loads((root / 'focused/test.json').read_text())['exit_code'] == 0
env = dict(os.environ,CARGO_TARGET_DIR='/private/tmp/mech-level12-compile-target',CARGO_INCREMENTAL='0')
assert not env.get('RUSTFLAGS') and not env.get('CARGO_ENCODED_RUSTFLAGS')
command = ['cargo','+nightly-2026-03-03','check','--locked','--offline','--profile','compiler','-j4','--manifest-path','Cargo.toml','--bin','mech','--features','cranelift_build','--message-format=json']
started = time.monotonic()
with (root / 'candidate-cli-check.jsonl').open('w') as stdout,(root / 'candidate-cli-check.stderr.log').open('w') as stderr:
    completed = subprocess.run(command,env=env,stdout=stdout,stderr=stderr)
row = dict(command=command,exit_code=completed.returncode,seconds=time.monotonic()-started,patch_sha256=state['patch_sha256'],base_commit=state['base_commit'])
(root / 'candidate-cli-check.json').write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps(row),flush=True)
assert completed.returncode == 0
assert subprocess.check_output(['git','diff','--binary']) == (root / 'candidate.patch').read_bytes()
