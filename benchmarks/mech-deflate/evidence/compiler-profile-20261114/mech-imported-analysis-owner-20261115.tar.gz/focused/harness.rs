use cranelift_codegen::Context;
use cranelift_codegen::ir::{AbiParam, InstBuilder, InstructionData, types};
// Reuse descriptive backend analyses only within this borrowed cleanup sequence.
// A zero-report suffix pass preserves layout, successor order and normalized
// aliases. Rebuilding identical argument-list storage does not invalidate them.
// Every reported mutation invalidates both facts before the existing cleanup.
struct ImportedAnalyses<'a> {
    context: &'a mut Context,
    graph_current: bool,
    aliases_current: bool,
}
impl<'a> ImportedAnalyses<'a> {
    fn new(context: &'a mut Context) -> Self {
        Self {
            context,
            graph_current: false,
            aliases_current: false,
        }
    }
    fn normalized(&mut self) {
        if !self.aliases_current {
            self.context.func.dfg.resolve_all_aliases();
            self.aliases_current = true;
        }
        self.graph();
    }
    fn graph(&mut self) {
        if !self.graph_current {
            self.context.compute_cfg();
            self.context.compute_domtree();
            self.graph_current = true;
        }
    }
    fn invalidate(&mut self) {
        // Includes successor reordering even when the edge set is unchanged.
        self.graph_current = false;
        self.aliases_current = false;
    }
}

#[cfg(test)] mod tests {
use super::*;
fn imported_analyses_fixture(
    seed: usize,
) -> (
    cranelift_codegen::Context,
    [cranelift_codegen::ir::Block; 7],
    cranelift_codegen::ir::Inst,
    cranelift_codegen::ir::Inst,
) {
    use cranelift_codegen::cursor::{Cursor, FuncCursor};
    let mut function = cranelift_codegen::ir::Function::new();
    function.signature.params = vec![AbiParam::new(types::I64); 2];
    function.signature.returns = vec![AbiParam::new(types::I64)];
    let blocks = std::array::from_fn(|_| function.dfg.make_block());
    let condition = function.dfg.append_block_param(blocks[0], types::I64);
    let input = function.dfg.append_block_param(blocks[0], types::I64);
    let carried = function.dfg.append_block_param(blocks[3], types::I64);
    let mut cursor = FuncCursor::new(&mut function);
    cursor.insert_block(blocks[0]);
    let branch = cursor.ins().brif(condition, blocks[1], &[], blocks[2], &[]);
    for index in if seed % 2 == 0 { [1, 2] } else { [2, 1] } {
        cursor.insert_block(blocks[index]);
        let value = cursor.ins().iadd_imm(input, (seed % 5 + index) as i64);
        cursor.ins().jump(blocks[3], &[value.into()]);
    }
    cursor.insert_block(blocks[3]);
    cursor.ins().brif(condition, blocks[4], &[], blocks[5], &[]);
    cursor.insert_block(blocks[4]);
    let next = cursor.ins().iadd_imm(carried, (seed % 3) as i64);
    cursor.ins().jump(blocks[3], &[next.into()]);
    cursor.insert_block(blocks[5]);
    let returned = cursor.ins().return_(&[carried]);
    cursor.insert_block(blocks[6]);
    let dead = cursor.ins().iconst(types::I64, seed as i64);
    cursor.ins().return_(&[dead]);
    (
        cranelift_codegen::Context::for_function(function),
        blocks,
        branch,
        returned,
    )
}

fn imported_analyses_match_fresh(context: &cranelift_codegen::Context, normalize: bool) {
    let mut fresh = cranelift_codegen::Context::for_function(context.func.clone());
    if normalize {
        fresh.func.dfg.resolve_all_aliases();
    }
    fresh.compute_cfg();
    fresh.compute_domtree();
    assert_eq!(
        context.func.display().to_string(),
        fresh.func.display().to_string()
    );
    assert_eq!(
        context.domtree.cfg_postorder(),
        fresh.domtree.cfg_postorder()
    );
    assert_eq!(
        context.domtree.cfg_rpo().collect::<Vec<_>>(),
        fresh.domtree.cfg_rpo().collect::<Vec<_>>()
    );
    for index in 0..context.func.dfg.num_blocks() {
        let block = cranelift_codegen::ir::Block::from_u32(index as u32);
        let predecessors = |context: &cranelift_codegen::Context| {
            context
                .cfg
                .pred_iter(block)
                .map(|pred| (pred.block, pred.inst))
                .collect::<Vec<_>>()
        };
        assert_eq!(predecessors(context), predecessors(&fresh));
        assert_eq!(
            context.cfg.succ_iter(block).collect::<Vec<_>>(),
            fresh.cfg.succ_iter(block).collect::<Vec<_>>()
        );
        assert_eq!(context.domtree.idom(block), fresh.domtree.idom(block));
        assert_eq!(
            context.domtree.children(block).collect::<Vec<_>>(),
            fresh.domtree.children(block).collect::<Vec<_>>()
        );
    }
    for index in 0..context.func.dfg.num_values() {
        let value = cranelift_codegen::ir::Value::from_u32(index as u32);
        assert_eq!(
            context.func.dfg.value_alias_dest_for_serialization(value),
            fresh.func.dfg.value_alias_dest_for_serialization(value)
        );
    }
}

#[test]
fn imported_analyses_reuse_matches_fresh_graphs_and_aliases() {
    for seed in 0..64 {
        let (mut context, _, _, _) = imported_analyses_fixture(seed);
        let mut analyses = ImportedAnalyses::new(&mut context);
        analyses.graph();
        imported_analyses_match_fresh(analyses.context, false);
        for _ in 0..5 {
            analyses.normalized();
            imported_analyses_match_fresh(analyses.context, true);
            analyses.graph();
            imported_analyses_match_fresh(analyses.context, false);
        }
    }
}

#[test]
fn imported_analyses_invalidate_successor_order_and_layout_changes() {
    for seed in 0..16 {
        let (mut context, blocks, branch, _) = imported_analyses_fixture(seed);
        let mut analyses = ImportedAnalyses::new(&mut context);
        analyses.normalized();
        let before = analyses.context.domtree.cfg_postorder().to_vec();
        let InstructionData::Brif {
            blocks: destinations,
            ..
        } = &mut analyses.context.func.dfg.insts[branch]
        else {
            unreachable!("fixture entry branch");
        };
        destinations.swap(0, 1);
        analyses.invalidate();
        analyses.graph();
        assert_ne!(before, analyses.context.domtree.cfg_postorder());
        imported_analyses_match_fresh(analyses.context, false);
        analyses.context.func.layout.remove_block(blocks[6]);
        analyses.invalidate();
        analyses.normalized();
        imported_analyses_match_fresh(analyses.context, true);
    }
}

#[test]
fn imported_analyses_graph_only_preserves_requested_alias_work() {
    for seed in 0..16 {
        let (mut context, _, _, returned) = imported_analyses_fixture(seed);
        let mut analyses = ImportedAnalyses::new(&mut context);
        analyses.normalized();
        let original = analyses.context.func.dfg.inst_args(returned)[0];
        let alias =
            cranelift_codegen::ir::Value::from_u32(analyses.context.func.dfg.num_values() as u32);
        analyses.context.func.dfg.make_invalid_value_for_parser();
        analyses
            .context
            .func
            .dfg
            .make_value_alias_for_serialization(original, alias);
        analyses.context.func.dfg.inst_args_mut(returned)[0] = alias;
        analyses.invalidate();
        analyses.graph();
        assert_eq!(analyses.context.func.dfg.inst_args(returned)[0], alias);
        imported_analyses_match_fresh(analyses.context, false);
        analyses.normalized();
        assert_eq!(analyses.context.func.dfg.inst_args(returned)[0], original);
        imported_analyses_match_fresh(analyses.context, true);
    }
}

}
