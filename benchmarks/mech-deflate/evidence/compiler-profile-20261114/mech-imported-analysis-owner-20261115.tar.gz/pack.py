from pathlib import Path
import hashlib,json,shutil,subprocess,sys
repo=Path.cwd();raw=Path('/private/tmp/mech-imported-analysis-owner-20261115');packet=Path('/private/tmp/mech-imported-analysis-owner-packet-20261115');source='a90a3d81d9f155242a29c593b1df49651cdc561c'
assert json.loads((packet/'decision.json').read_text())['retain_source_change'] is False
assert json.loads((packet/'restoration.json').read_text())['source_commit']==source
shutil.copy2(__file__,packet/'pack.py')
archive=Path('/private/tmp/mech-imported-analysis-owner-20261115.tar.gz');archive_path=Path('benchmarks/mech-deflate/evidence/compiler-profile-20261114')/archive.name
summary_path=Path('benchmarks/mech-deflate/native-profile/imported-analysis-owner-apple-m3-20261115.json');receipt_path=summary_path.with_suffix('.archive.json')
command=[sys.executable,'benchmarks/mech-deflate/experiment.py','pack','--revision',source,'--input',str(packet),'--output',str(archive)]
with (raw/'pack.stdout.log').open('w') as stdout,(raw/'pack.stderr.log').open('w') as stderr:result=subprocess.run(command,stdout=stdout,stderr=stderr)
assert result.returncode==0
receipt=json.loads((raw/'pack.stdout.log').read_text());assert receipt['source_revision']==source
shutil.copy2(archive,repo/archive_path);shutil.copy2(packet/'summary.json',repo/summary_path)
replay_bytes=(packet/'summary.json').read_bytes();receipt.update(publication='repository',repository='mech-lang/mech',repository_path=archive_path.as_posix(),replay_sha256=hashlib.sha256(replay_bytes).hexdigest(),replay_byte_identical=True)
(repo/receipt_path).write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
extracted=Path('/private/tmp/mech-imported-analysis-owner-repository-verified-20261115');assert not extracted.exists()
command=[sys.executable,'benchmarks/mech-deflate/experiment.py','verify',archive_path.as_posix(),'--receipt',receipt_path.as_posix(),'--extract',str(extracted),'--result',str(raw/'repository-verification.json')]
with (raw/'verify.stdout.log').open('w') as stdout,(raw/'verify.stderr.log').open('w') as stderr:result=subprocess.run(command,stdout=stdout,stderr=stderr)
assert result.returncode==0
verification=json.loads((raw/'repository-verification.json').read_text());receipt['verification']=verification
(repo/receipt_path).write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
with (raw/'repository-replay.stdout.log').open('w') as stdout,(raw/'repository-replay.stderr.log').open('w') as stderr:result=subprocess.run([sys.executable,str(extracted/'replay.py')],stdout=stdout,stderr=stderr)
assert result.returncode==0 and (raw/'repository-replay.stdout.log').read_bytes()==replay_bytes
index_path=repo/'benchmarks/mech-deflate/evidence/compiler-profile-20261114/index.json';index=json.loads(index_path.read_text());previous=json.loads(json.dumps(index['packets']));assert len(previous)==42 and index['total_archive_bytes']==1251344667
row=dict(archive=archive_path.as_posix(),bytes=receipt['bytes'],decision='Rejected: completebuild15.287110->15.281101s(-0.04%) withmixedblocks; source-to-Object component+0.05%, link-10.58%. Objectcompiler-0.35%, cleanup-1.01%, instructions-0.38%; sourceCFG+1.20%, compaction+4.33%,RSS+0.0127%. Exactartifacts/fullmetadata/wholeexe and14fixturepairs. ThreefocusedactualCranelift fresh-analysis tests cover64unchanged/16successororder+layout/16graph-onlyalias sequences. Auditedfivepass suffix/oneborrowedContext owner; originalguards/passorder/verification preserved. SourceandstdDD7 restored; PGO5a1 untouched; no usefulnewgain orsub10claim.',files=receipt['files'],receipt=receipt_path.as_posix(),sha256=receipt['sha256'],source_revision=source,summary=summary_path.as_posix())
index['packets'].append(row);index['total_archive_bytes']+=row['bytes'];assert index['packets'][:-1]==previous
index_path.write_text(json.dumps(index,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(receipt=receipt,total_archive_bytes=index['total_archive_bytes'],packets=len(index['packets'])),indent=2),flush=True)
