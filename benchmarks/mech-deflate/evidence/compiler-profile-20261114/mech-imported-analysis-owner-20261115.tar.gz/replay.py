from pathlib import Path
import hashlib
import json
import re
import statistics
import subprocess
import sys

packet = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_text())
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
state = read(packet / 'source-state.json')
assert pin(packet / 'candidate.patch')['sha256'] == state['patch_sha256']
for row in state['files']:
    assert pin(packet / 'reference-source' / row['path'])['sha256'] == row['sha256']
    assert pin(packet / 'candidate-source' / row['path'])['sha256'] == row['candidate_sha256']
commit_path = packet / 'qualification-commit.json'
commit = read(commit_path) if commit_path.exists() else dict(source_commit=None)
if commit_path.exists():
    assert commit['parent'] == state['base_commit']
    assert commit['entire_commit_diff_sha256'] == state['patch_sha256']
    assert commit['entire_commit_diff_matches_measured_patch']
excluded = read(packet / 'excluded-products.json')
assert excluded['control']['sha256'] == 'dd7dc5bc906325a213422a127a2e87ec134a3f8564b713dbbe50e1d1308571a0'
assert read(packet / 'candidate-build.json')['binary_sha256'] == excluded['candidate']['sha256']
for name in ['candidate-check', 'candidate-build', 'candidate-cli-check']:
    row = read(packet / (name + '.json'))
    assert row['exit_code'] == 0 and row['patch_sha256'] == state['patch_sha256']
assert read(packet / 'focused/build.json')['exit_code'] == read(packet / 'focused/test.json')['exit_code'] == 0
assert 'test result: ok. 3 passed; 0 failed' in (packet / 'focused/test.stdout.log').read_text()
source = (packet / 'candidate-source/hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/mod.rs').read_text()
start = source.index('// Reuse descriptive backend analyses'); end = source.index('\nmod boolean_conditions;',start)
assert source[start:end] in (packet / 'focused/harness.rs').read_text()
tests = (packet / 'candidate-source/hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/tests.rs').read_text()
assert tests[tests.index('fn imported_analyses_fixture('):] in (packet / 'focused/harness.rs').read_text()
focused = read(packet / 'focused/result.json')
assert focused == dict(unit_tests=3,unchanged_graph_seeds=64,successor_order_and_layout_seeds=16,graph_only_then_normalized_alias_seeds=16,all_fresh_analysis_comparisons_identical=True)
assert read(packet / 'focused/test.json')['binary_sha256'] == excluded['focused/tests']['sha256']
for row in read(packet / 'mutation-audit-source.json'):
    assert pin(packet / row['path']) == {key:row[key] for key in ['bytes','sha256']}
metadata_selection = read(packet / 'selection-metadata.json')
assert metadata_selection['reference_metadata_sha256'] == pin(packet / 'reference/metadata.json')['sha256']
metadata = read(packet / 'reference/metadata.json')
assert metadata_selection['main_cleanup'] == {key:metadata['cleanup'][key] for key in metadata_selection['main_cleanup']}
assert all(metadata_selection['main_cleanup'][key] == 0 for key in ['window_bounds_combined','ordered_capture_spans','adjacent_addresses_reused','selected_home_constant_operands','selected_home_merge_parameters','selected_increment_guards_removed'])
flags = read(packet / 'runtime-flags.json')
assert len(flags) == 61
reference = {name:pin(packet / 'reference' / name) for name in ['source.mec','program.mecb','program.o','metadata.json']}
native = read(packet / 'native-baseline-pins.json')
exe = native['executable']
assert exe == dict(bytes=2060440,sha256='d6c65cc3fb18acc4be77dce329962105bf0f2b56dd2623a12f466256463eca61')
capture = read(packet / 'link-command.json')
inputs = read(packet / 'native-link-inputs.json')
assert [(r['source'],r['bytes'],r['sha256']) for r in inputs] == [(r['source'],r['bytes'],r['sha256']) for r in capture['inputs']]
for row in inputs:
    assert pin(packet / row['path']) == {k:row[k] for k in ['bytes','sha256']}
for variant in ['control','candidate']:
    directory = packet / (variant + '-screen')
    assert read(directory / 'process.json')['exit_code'] == 0
    for name, item in reference.items():
        assert pin(directory / name) == item and (directory / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    assert pin(packet / ('link-' + variant) / 'worker') == exe
gates = read(packet / 'final-executable-results.json')
assert len(gates) == 2 and all(r['exit_code'] == 0 and r['matches_complete_baseline_executable'] and r['executable_sha256'] == exe['sha256'] for r in gates)
fixtures = read(packet / 'fixture-results.json')
assert len(fixtures) == 14
for row in fixtures:
    assert row['all_outputs_match'] and row['variants']['control'] == row['variants']['candidate']
    for variant in ['control','candidate']:
        entry = row['variants'][variant]
        assert entry['exit_code'] == 0 and len(entry['files']) == 4
        name = Path(row['fixture'].split(':')[-1]).stem
        directory = packet / 'fixtures' / name / variant
        for filename, item in entry['files'].items():
            assert pin(directory / filename) == item
            assert (directory / filename).read_bytes() == (packet / 'fixtures' / name / 'control' / filename).read_bytes()
rows = read(packet / 'cohort.json')
assert len(rows) == 8
order = ['control-1','candidate-1','candidate-2','control-2','candidate-3','control-3','control-4','candidate-4']
assert [r['name'] for r in rows] == order
for row in rows:
    directory = packet / row['name']
    assert row['compile'] == read(directory / 'compile.json') and row['process'] == read(directory / 'process.json')
    assert row['process']['exit_code'] == 0
    command = read(packet / (row['name'] + '-command.json'))
    assert command['binary_sha256'] == excluded[row['variant']]['sha256']
    assert command['flags'] == dict(flags, MECH_COMPACT_COMPILE_THREADS='2')
    for name, item in reference.items():
        assert pin(directory / name) == item and (directory / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    stamps = [json.loads(line) for line in (directory / 'stages.jsonl').read_text().splitlines()]
    for key, begin, end in [('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code'),('compaction_seconds','compact-stage: compact values before=','compact-stage: CFG cleanup')]:
        assert row[key] == next(s['elapsed'] for s in stamps if s['line'].startswith(end)) - next(s['elapsed'] for s in stamps if s['line'].startswith(begin))
    assert row['cleanup_including_compaction_seconds'] == row['cleanup_seconds'] + row['compaction_seconds']
    log = (directory / 'stderr.log').read_text()
    for key, pattern in [('max_rss_bytes',r'(\d+)  maximum resident set size'),('instructions',r'(\d+)  instructions retired'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]:
        assert row[key] == int(re.search(pattern,log).group(1))
fields = dict(compiler_seconds=lambda r:r['compile']['total_seconds'],whole_process_seconds=lambda r:r['process']['elapsed_seconds'])
for phase in ['parse','catalog','frontend','artifact','encode','native']:
    fields[phase+'_seconds'] = lambda r,p=phase: next(v['seconds'] for v in r['compile']['phases'] if v['phase']==p)
for key in ['canonical_lowering_seconds','preparation_seconds','numeric_generation_seconds','source_cfg_seconds','cleanup_including_compaction_seconds','cleanup_seconds','compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:
    fields[key] = lambda r,k=key:r[k]
summary = {}
for key, fn in fields.items():
    values = {v:[fn(r) for r in rows if r['variant']==v] for v in ['control','candidate']}
    base = statistics.mean(values['control'])
    values['mean_reduction_fraction'] = 1-statistics.mean(values['candidate'])/base if base else None
    summary[key] = values
assert read(packet / 'numerical-summary.json') == summary
native_path = packet / 'native-cohort.json'
native_rows = read(native_path) if native_path.exists() else []
assert len(native_rows) in [0,8]
native_summary = {}
for row in native_rows:
    directory = packet / row['name']
    receipt = read(directory / 'result.json')
    assert row == dict(receipt, name=row['name'], primary_cohort=True)
    assert row['compiler_exit_code'] == row['link_exit_code'] == 0 and row['matches_complete_baseline_executable']
    assert row['executable_bytes'] == exe['bytes'] and row['executable_sha256'] == exe['sha256'] and pin(directory / 'worker') == exe
    for name, item in reference.items():
        assert pin(directory / name) == item and (directory / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    assert abs(row['source_to_executable_seconds']-sum(row[k] for k in ['source_to_object_process_seconds','object_handoff_seconds','native_link_seconds'])) < 1e-8
if native_rows:
    for key in ['source_to_executable_seconds','source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']:
        values = {v:[r[key] for r in native_rows if r['variant']==v] for v in ['control','candidate']}
        values['mean_reduction_fraction'] = 1-statistics.mean(values['candidate'])/statistics.mean(values['control'])
        native_summary[key] = values
    blocks = []
    for block in [native_rows[:4],native_rows[4:]]:
        means = {v:statistics.mean(r['source_to_executable_seconds'] for r in block if r['variant']==v) for v in ['control','candidate']}
        means['mean_reduction_fraction'] = 1-means['candidate']/means['control']
        blocks.append(means)
    saved = read(packet / 'native-numerical-summary.json')
    assert saved['numerical_summary'] == native_summary and saved['balanced_blocks'] == blocks
else:
    blocks = []
if (packet / 'candidate-serial-gate').exists():
    serial = packet / 'candidate-serial-gate'
    assert read(serial / 'process.json')['exit_code'] == 0
    for name, item in reference.items():
        assert pin(serial / name) == item and (serial / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    serial_result = read(packet / 'link-candidate-serial/result.json')
    assert serial_result['matches_complete_baseline_executable'] and serial_result['executable_sha256'] == exe['sha256']
    assert pin(packet / 'link-candidate-serial/worker') == exe
result = dict(source_commit=commit['source_commit'],base_commit=state['base_commit'],patch_sha256=state['patch_sha256'],compiler=excluded,source_state=state,numerical_summary=summary,native_numerical_summary=native_summary,balanced_native_blocks=blocks,output_hashes=reference,final_executable=exe,fixture_pairs=14,focused_tests=3,focused_analysis_cases=focused,selection_metadata=metadata_selection,mutation_audit=read(packet/'mutation-audit.json'),checks={name:read(packet/(name+'.json')) for name in ['candidate-check','candidate-build','candidate-cli-check']},decision=read(packet/'decision.json'),scope='Borrowed same-Context owner reuses normalized aliases and complete CFG/dominator analyses only across audited no-change imported suffix passes. Every positive mutation invalidates, including successor ordering; samepasssequence/guards/verification, graph-onlystages preserved. Standarddd7 control versus standardcandidate, same61flags/two workers/pinnedmimalloc. Exact source/MBC/Object/fullmetadata/wholeexe gates before primary timing. No grammar/proof/permission cache or program-runtime change. CurrentbestPGO5a1/d26 remains separate; no new-source PGO or subten claim.')
encoded = json.dumps(result,indent=2,sort_keys=True)+'\n'
saved = packet / 'summary.json'
if saved.exists():
    assert saved.read_text() == encoded
else:
    saved.write_text(encoded)
print(encoded,end='')
