from pathlib import Path
import hashlib
import json
import shutil

repo = Path.cwd()
raw = Path('/private/tmp/mech-imported-analysis-owner-20261115')
packet = Path('/private/tmp/mech-imported-analysis-owner-packet-20261115')
packet.mkdir(exist_ok=False)
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
excluded = {}
for source in raw.rglob('*'):
    if not source.is_file():
        continue
    name = source.relative_to(raw)
    if name.as_posix() in ['control', 'candidate', 'focused/tests'] or (name.parts[0].startswith('focused') and source.suffix in ['.o', '.bc', '.rlib', '.rmeta']):
        excluded[name.as_posix()] = dict(path=str(source), **pin(source))
        continue
    dest = packet / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, dest)
(packet / 'excluded-products.json').write_text(json.dumps(excluded, indent=2) + '\n')
link = Path('/private/tmp/mech-pr973-refresh-20261115/link')
capture = json.loads((link / 'capture/link-command.json').read_text())
shutil.copy2(link / 'capture/link-command.json', packet / 'link-command.json')
shutil.copy2(link / 'baseline-pins.json', packet / 'native-baseline-pins.json')
shutil.copy2(link / 'build.json', packet / 'historical-adapter-build.json')
inputs = []
for number, row in enumerate(capture['inputs']):
    source = Path(row['retained_path'])
    assert pin(source) == {k:row[k] for k in ['bytes','sha256']}
    name = Path('native-link-inputs') / (str(number) + '-' + source.name)
    dest = packet / name
    dest.parent.mkdir(exist_ok=True)
    shutil.copy2(source, dest)
    inputs.append(dict(source=row['source'], path=name.as_posix(), **pin(dest)))
(packet / 'native-link-inputs.json').write_text(json.dumps(inputs, indent=2) + '\n')
shutil.copytree('/private/tmp/mech-round2-planning-packet-20261114/licenses', packet / 'licenses')
hardware = packet / 'hardware'
hardware.mkdir()
for name in ['cpu.txt','cpu-count.txt','memory.txt','os.txt']:
    shutil.copy2(Path('/private/tmp/mech-current-native-pgo-20261115') / name, hardware / name)
for name in ['mech-test-imported-analysis-owner-20261115.py',
             'mech-build-imported-analysis-owner-20261115.py',
             'mech-check-imported-analysis-owner-20261115.py',
             'mech-qualify-imported-analysis-owner-20261115.py',
             'mech-qualify-imported-analysis-owner-serial-20261115.py']:
    shutil.copy2(Path('/private/tmp') / name, packet / name)
shutil.copy2(repo / 'benchmarks/mech-deflate/native-profile/dense-hole-lookups-apple-m3-20261115.archive.json', packet / 'baseline-source-evidence-receipt.json')
audited = []
for name in ['window_bounds.rs','window_bounds/ordered_spans.rs','adjacent_addresses.rs','selected_homes.rs','selected_increments.rs']:
    relative = Path('hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup') / name
    source = repo / relative
    destination = packet / 'audited-passes' / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    audited.append(dict(source=relative.as_posix(),path=destination.relative_to(packet).as_posix(),**pin(source)))
(packet / 'mutation-audit-source.json').write_text(json.dumps(audited,indent=2)+'\n')
shutil.copy2(__file__, packet / 'curate.py')
shutil.copy2('/private/tmp/mech-replay-imported-analysis-owner-20261115.py', packet / 'replay.py')
print(packet)
