from pathlib import Path
import hashlib,json,subprocess,time
r=Path('/private/tmp/mech-imported-analysis-owner-20261115');out=r/'focused';assert json.loads((r/'candidate-build.json').read_text())['exit_code']==0;rows=[json.loads(x) for x in (r/'candidate-build.jsonl').read_text().splitlines()]
command=['rustc','+nightly-2026-03-03','--edition=2024','--crate-name','imported_analysis_owner_tests','--test',str(out/'harness.rs'),'-C','opt-level=3','-C','lto=thin','-C','codegen-units=1','-D','warnings','-o',str(out/'tests')];directories=set();dependencies=[]
for name in ['cranelift_codegen']:
 paths=[Path(p) for row in rows if row.get('reason')=='compiler-artifact' and row['target']['name']==name for p in row['filenames'] if p.endswith('.rlib')];assert len(paths)==1;path=paths[0];directories.add(path.parent);command+=['--extern',name+'='+str(path)];dependencies.append(dict(name=name,path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
for path in sorted(directories):command+=['-L','dependency='+str(path)]
(out/'command.json').write_text(json.dumps(dict(command=command,dependencies=dependencies,scope='Exact candidate ImportedAnalyses owner and allthree newproduction testbodies/helpers, extractedbyte-for-byte. Existing actualcandidate CraneliftContext/CFG/dominator/DFG implementations, notmodels. Comparefreshcontext recomputation including fullpredecessor/successor order, cachedRPO/postorder, immediate dominators/children, aliases andIR; test branchsuccessorswap withsameedges, layoutremoval andgraph-onlyaliasrequest separation.'),indent=2)+'\n')
start=time.monotonic()
with (out/'build.stdout.log').open('w') as stdout,(out/'build.stderr.log').open('w') as stderr:completed=subprocess.run(command,stdout=stdout,stderr=stderr)
row=dict(exit_code=completed.returncode,seconds=time.monotonic()-start);(out/'build.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True);assert completed.returncode==0
start=time.monotonic()
with (out/'test.stdout.log').open('w') as stdout,(out/'test.stderr.log').open('w') as stderr:completed=subprocess.run([str(out/'tests'),'--nocapture'],stdout=stdout,stderr=stderr)
row=dict(exit_code=completed.returncode,seconds=time.monotonic()-start,binary_sha256=hashlib.sha256((out/'tests').read_bytes()).hexdigest());(out/'test.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True);assert completed.returncode==0
(out/'result.json').write_text(json.dumps(dict(unit_tests=3,unchanged_graph_seeds=64,successor_order_and_layout_seeds=16,graph_only_then_normalized_alias_seeds=16,all_fresh_analysis_comparisons_identical=True),indent=2)+'\n')
