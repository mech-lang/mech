from pathlib import Path
import json
repo=Path.cwd();packet=Path('/private/tmp/mech-helper-liveness-packet-20261114');s=json.loads((packet/'summary.json').read_text());q=s['qualified'];rows=[]
for key,label in [('compiler_seconds','Compiler, s'),('whole_process_seconds','Whole process, s'),('parse_seconds','Parse, s'),('frontend_seconds','Frontend, s'),('native_seconds','Native, s'),('canonical_lowering_seconds','Canonical lowering, s'),('preparation_seconds','Preparation, s'),('numeric_generation_seconds','Numeric generation, s'),('source_cfg_seconds','Source CFG, s'),('cleanup_including_compaction_seconds','Cleanup including compaction, s'),('compaction_seconds','Compaction, s'),('instructions','Retired instructions'),('max_rss_bytes','Peak RSS, bytes'),('peak_footprint_bytes','Peak footprint, bytes')]:
 v=q[key];fmt=(lambda x:f'{x:,}') if key in ['instructions','max_rss_bytes','peak_footprint_bytes'] else (lambda x:f'{x:.6f}')
 rows.append(f"| {label} | {fmt(min(v['control']))}–{fmt(max(v['control']))} | {fmt(min(v['candidate']))}–{fmt(max(v['candidate']))} | {-100*v['mean_reduction_fraction']:+.2f}% |")
report=f'''# Packed helper liveness: compilation qualification

Complete fresh level-12 compilation takes **18.884–19.110 seconds** on the Apple
M3 Air. Eight matched runs show **3.74% lower whole-process time, 3.73% lower
compiler time, 24.15% lower numeric-helper generation time and 4.30% fewer
instructions**. Source, MBC, Object and complete metadata bytes remain identical.
Memory ranges overlap and no memory improvement is claimed. The ten-second
compilation goal remains open.

Helper liveness previously cloned and unioned ordered sets on repeated complete
graph sweeps. It now shares preparation's existing packed transfer kernel, using
query-local word ordinals. That kernel's transfer body is unchanged apart from
whitespace; its signature now supports both source u32 values and usize words.
The emitter's recording block is byte-for-byte unchanged. Aggregate and scalar
read/write effects, checked guards, handoff exports and selected edges retain
their existing behavior.

Local reads seed before local writes kill successor facts. Terminal outputs are
observed after each exit site's writes. Fallback nodes keep exactly their recorded
exports and no implicit result edge. The same 16M-cell cap bounds the two packed
planes to 256 MiB; larger products keep each caller's original solver. This cap
covers the two planes, not every graph/worklist allocation. No plan, resource,
guard, shape, visit or ownership result is cached. No execution machinery is retired.

Source `{s['source_commit']}`, parent `{s['base_commit']}`.
The frozen control comes from `{s['control_source_commit']}`; its production
source equals the documentation-only parent. Both subjects use the same opt-in
`compiler` profile, full fresh source-to-Object pipeline and 60 runtime flags.
Hardware: Apple M3 Air, 8 cores (4P+4E), 16 GB, macOS 26.2.

| Measurement | Control range (4 runs) | Candidate range (4 runs) | Mean change |
| --- | --- | --- | ---: |
'''+ '\n'.join(rows)+'''

Runs are serial control/candidate/candidate/control then
candidate/control/control/candidate. Both blocks improve compiler time (3.86%
and 3.61%). Every candidate compiler, process, native, helper-generation and
instruction observation falls below every control. Preparation is an adverse
1.31% higher, source CFG 1.14% higher and compaction 2.63% higher. All observations
remain. RSS and footprint means are effectively unchanged, with overlapping
ranges. These finite cohorts are descriptive, not population estimates. Both
subjects include SSA value compaction and its cost. Native substage intervals
are nested and must not be added to whole-process time.

Builds, tests, screens, fixtures, feature checks, hashing, copying and packet work
do not overlap primary timing. The observed 273.362-second compiler rebuild uses
existing Cargo caches, is excluded from Mech compilation timing and is not a
matched cold-bootstrap comparison. Both screens and every primary output match
the qualified program byte for byte. Fourteen successful fixture pairs cover six
array/enum programs and eight checked scalar programs, matching all four files.
Generated machine code and metadata are identical; no new compressor-runtime
latency or CPU sampling campaign is claimed.

All **18 unique focused tests pass**: 13 existing preparation cases and five helper
cases. The helper tests compare packed and forced original-set fallback paths
against an independent read-before-write path oracle on 512 seeded graph families,
including branches, cycles, duplicate/reordered sites, local and terminal writes,
fallback exits, missing headers, sparse usize IDs and scratch limits. Static
source checks separately verify the unchanged recording block and transfer body.
The full GPU/runtime unit suites were not rerun. Grammar, language, checked errors,
direct scalar emission, fresh proofs, finite admission, runtime accounting and
backend optimization settings keep their existing behavior.

An additional bare `canonical-native-program-runtime` check **fails on both parent
and candidate** with the same pre-existing unused-function errors for `derive` and
`derive_tree` in unchanged `readonly_numeric.rs`. No lint allowance is added and
this check is not counted as passing. The parent is checked from its exact Git
archive without altering the main worktree. Both commands, logs, source pins and
error comparison remain. The full compiler build used for measurement passes.
An early test-wrapper inner-doc-comment placement error is also preserved and
was fixed before any test or compiler measurement.

The next recorded target is `numeric_phase_bounds::Indices::definition`, which
creates fresh same-plan facts on every lookup. The prior pinned helper CPU window
contains inventory construction under that method. Keeping those descriptive
facts for one Indices lifetime is a future experiment; no saving is credited here.
Earlier CPU samples retain their original source pins.

The [compact result](../../benchmarks/mech-deflate/native-profile/helper-liveness-compile-apple-m3-20261114.json)
and [receipt](../../benchmarks/mech-deflate/native-profile/helper-liveness-compile-apple-m3-20261114.archive.json)
pin the complete [benchmark packet](../../benchmarks/mech-deflate/evidence/compiler-profile-20261114/README.md).
It contains source/base snapshots and patches, commands, flags, tests, raw cohorts,
outputs, corrections, feature-check failures and pure offline replay. Compiler/test
executables are excluded and hash-pinned. Python 3.11+ replay needs no compilers,
benchmark execution, original scratch paths or external services.
'''
(repo/'docs/design/native-helper-liveness-compile-profile.md').write_text(report);(packet/'REPORT.md').write_text(report)
p=repo/'docs/design/native-compiler-process-profile.md';text=p.read_text().replace('**19.741–20.163 seconds per complete','**18.884–19.110 seconds per complete',1).replace('and [proof-local traversal](native-local-traversal-compile-profile.md).','[proof-local traversal](native-local-traversal-compile-profile.md),\nand [packed helper liveness](native-helper-liveness-compile-profile.md).',1)
text+='''
The latest [packed-helper-liveness qualification](native-helper-liveness-compile-profile.md)
shares the existing bounded packed transfer kernel with exact helper effects.
Eight matched 60-flag compiles take 18.884–19.110 seconds: process time falls
3.74%, helper generation 24.15% and instructions 4.30%. Preparation, source CFG
and compaction means are adverse; memory ranges overlap. All generated bytes
match. Eighteen focused tests and fourteen fixture pairs pass. The fourteenth
packet also retains the same pre-existing bare runtime-only lint failure on both
parent and candidate, without waivers. The ten-second target remains open.
''';p.write_text(text)
p=repo/'benchmarks/mech-deflate/EXPERIMENTS.md';text=p.read_text();pos=text.index('Paths below name reports **inside the external bundle**.')
text=text[:pos]+'''The [packed-helper-liveness qualification](../../docs/design/native-helper-liveness-compile-profile.md)
shares preparation's existing packed transfer with exact emitter-recorded effects
and the original larger-query fallback. Eight matched 60-flag runs take
18.884–19.110 seconds: 3.74% less process time, 24.15% less helper generation and
4.30% fewer instructions, preserving all generated bytes. Preparation and source
CFG means are adverse; memory ranges overlap. All 18 focused tests and fourteen
fixture pairs pass. Its fourteenth packet includes static source equivalence,
all observations and the same pre-existing runtime-only lint failure on parent
and candidate. Offline replay reproduces the result; older archives stay unchanged.

'''+text[pos:];p.write_text(text)
p=repo/'benchmarks/mech-deflate/native-profile/README.md';text=p.read_text();text+='''
The [packed helper-liveness result](../../../docs/design/native-helper-liveness-compile-profile.md)
records fresh compilation at 18.884–19.110 seconds with identical generated bytes.
Its full archive and offline replay are in the
[compiler-profile evidence index](../evidence/compiler-profile-20261114/README.md).
''';p.write_text(text)
