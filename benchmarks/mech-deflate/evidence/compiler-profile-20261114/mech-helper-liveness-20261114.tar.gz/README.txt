Packed helper liveness, Apple M3, 2026-11-14.
The helper's exact aggregate/scalar recording adapter is unchanged byte for byte.
The old preparation packed transfer body is shared generically without changing
its algorithm, and all thirteen existing preparation liveness tests pass. Five
helper tests compare packed and forced original-set fallback paths with an
independent read-before-write path oracle, including cycles, terminals, local
writes, fallback exits, missing headers, sparse usize IDs and scratch caps.
All eighteen tests are unique. No whole GPU/runtime unit-suite rerun is claimed.
The optional bare runtime-only feature check fails in both parent and candidate
on the same two existing readonly_numeric unused-function lint errors. No
allowance is added and this feature check is not counted as passing.
The 16M-cell cap still bounds the two packed planes to 256 MiB; larger products
retain each caller's original fallback. Runtime proofs/guards and limits remain.
Eight serial ABBA/BAAB full-source compiles and fourteen fixture pairs use the
same 60 flags/profile and preserve all four output files. All observations and
adverse counters remain. Builds, tests, screens, fixtures, hashing, copying and
packet work do not overlap primary timing. Compiler/test executables are excluded
and hash-pinned. No new CPU sampling or compressor-runtime latency campaign is
claimed. The full ten-second goal remains open. This complete packet is published
in benchmarks at the user's request. Python 3.11+ replay is pure offline
validation/numerical reconstruction, without compilers, original paths or a service.
