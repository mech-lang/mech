from pathlib import Path
import subprocess,json,hashlib,shutil
repo=Path.cwd();raw=Path('/private/tmp/mech-helper-liveness-20261114');packet=Path('/private/tmp/mech-helper-liveness-packet-20261114');assert not packet.exists()
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();build=json.loads((raw/'candidate-build.json').read_text());base=build['head'];control=json.loads((raw/'control-origin.json').read_text());control_source=control['source_commit']
summary_path=repo/'benchmarks/mech-deflate/native-profile/local-traversal-compile-apple-m3-20261114.json';receipt_path=summary_path.with_name(summary_path.stem+'.archive.json');prior=json.loads(summary_path.read_text());receipt=json.loads(receipt_path.read_text());assert hashlib.sha256(summary_path.read_bytes()).hexdigest()==receipt['replay_sha256'];assert control_source==prior['source_commit'] and control['sha256']==prior['compiler_binary_sha256']['candidate']
patch=subprocess.check_output(['git','diff','--binary',base,source]);assert patch==(raw/'candidate.patch').read_bytes();assert hashlib.sha256(patch).hexdigest()==build['patch_sha256']
assert subprocess.check_output(['git','diff',control_source,base,'--','src','hosts','vendor','machines','Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.toml'])==b''
excluded=[]
for p in sorted(raw.rglob('*')):
 if not p.is_file():continue
 rel=Path('compiler')/p.relative_to(raw)
 if p.name in ['control','candidate','helper-tests','preparation-tests']:
  excluded.append(dict(path=rel.as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()));continue
 d=packet/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
(packet/'excluded-executables.json').write_text(json.dumps(excluded,indent=2)+'\n');(packet/'source-change.patch').write_bytes(patch)
state=dict(source_commit=source,base_commit=base,control_source_commit=control_source,control_production_source_identical_to_base=True,patch_sha256=hashlib.sha256(patch).hexdigest(),hardware='Apple M3 Air, 8 cores (4P+4E), 16 GB, macOS 26.2',rustc=subprocess.check_output(['rustc','-Vv'],text=True),cargo=subprocess.check_output(['cargo','-V'],text=True));(packet/'source-state.json').write_text(json.dumps(state,indent=2,sort_keys=True)+'\n')
changed=subprocess.check_output(['git','diff','--name-only',base,source],text=True).splitlines()
paths=changed+['Cargo.toml','Cargo.lock','.cargo/config.toml','LICENSE','hosts/gpu/src/native_artifact/AGENTS.md','hosts/gpu/src/native_artifact/program/prepare/mod.rs','hosts/gpu/src/native_artifact/program/prepare/readonly_numeric.rs','hosts/gpu/tests/fixtures/native/deflate-huffman-LICENSES.md']
paths+=['benchmarks/mech-deflate/native-profile/'+n for n in ['Cargo.toml','Cargo.lock','compile_profile.rs','profile_compile.py','visit_predecessors_tests.rs']]
paths+=['hosts/gpu/tests/fixtures/native/'+n+'.mec' for n in ['numeric-nested-phase','numeric-nested-phase-states','numeric-private-fixed-nested','numeric-changing-capture-tree','numeric-array-windows','numeric-multiple-children']]
for name in dict.fromkeys(paths):
 data=subprocess.check_output(['git','show',source+':'+name]);d=packet/'source'/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(data)
for name in [*changed,'Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.toml']:
 if subprocess.run(['git','cat-file','-e',base+':'+name],capture_output=True).returncode:continue
 data=subprocess.check_output(['git','show',base+':'+name]);d=packet/'source-base'/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(data)
validation=packet/'validation';validation.mkdir();shutil.copy2(summary_path,validation/'qualified-local-traversal.json');shutil.copy2(receipt_path,validation/'qualified-local-traversal.archive.json')
shutil.copytree(Path('/private/tmp/mech-borrowed-schema-packet-20261114/licenses'),packet/'licenses')
for pattern in ['mech-*helper-liveness*20261114.py','mech-*helper-liveness*20261114.log']:
 for p in Path('/private/tmp').glob(pattern):
  if p.is_file():shutil.copy2(p,packet/p.name)
(packet/'README.txt').write_text('''Packed helper liveness, Apple M3, 2026-11-14.
The helper's exact aggregate/scalar recording adapter is unchanged byte for byte.
The old preparation packed transfer body is shared generically without changing
its algorithm, and all thirteen existing preparation liveness tests pass. Five
helper tests compare packed and forced original-set fallback paths with an
independent read-before-write path oracle, including cycles, terminals, local
writes, fallback exits, missing headers, sparse usize IDs and scratch caps.
All eighteen tests are unique. No whole GPU/runtime unit-suite rerun is claimed.
The optional bare runtime-only feature check fails in both parent and candidate
on the same two existing readonly_numeric unused-function lint errors. No
allowance is added and this feature check is not counted as passing.
The 16M-cell cap still bounds the two packed planes to 256 MiB; larger products
retain each caller's original fallback. Runtime proofs/guards and limits remain.
Eight serial ABBA/BAAB full-source compiles and fourteen fixture pairs use the
same 60 flags/profile and preserve all four output files. All observations and
adverse counters remain. Builds, tests, screens, fixtures, hashing, copying and
packet work do not overlap primary timing. Compiler/test executables are excluded
and hash-pinned. No new CPU sampling or compressor-runtime latency campaign is
claimed. The full ten-second goal remains open. This complete packet is published
in benchmarks at the user's request. Python 3.11+ replay is pure offline
validation/numerical reconstruction, without compilers, original paths or a service.
''');print(packet,flush=True)
