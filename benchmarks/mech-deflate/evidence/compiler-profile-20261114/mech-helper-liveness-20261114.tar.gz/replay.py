from pathlib import Path
import json,hashlib,re,statistics,tomllib
root=Path(__file__).resolve().parent;raw=root/'compiler'
read=lambda p:json.loads(p.read_text())
def pin(p):
 data=p.read_bytes();return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
state=read(root/'source-state.json');build=read(raw/'candidate-build.json');control=read(raw/'control-origin.json');patch=pin(root/'source-change.patch');assert patch==pin(raw/'candidate.patch') and patch['sha256']==state['patch_sha256']==build['patch_sha256']
assert build['exit_code']==0 and build['head']==state['base_commit'] and state['control_production_source_identical_to_base']
prior=read(root/'validation/qualified-local-traversal.json');receipt=read(root/'validation/qualified-local-traversal.archive.json');assert pin(root/'validation/qualified-local-traversal.json')['sha256']==receipt['replay_sha256'];assert control['sha256']==prior['compiler_binary_sha256']['candidate'] and control['source_commit']==state['control_source_commit']==prior['source_commit']
flags=read(raw/'runtime-flags.json');assert len(flags)==60;expected=prior['output_hashes'];assert read(raw/'reference-pins.json')==expected
excluded={r['path']:r for r in read(root/'excluded-executables.json')};assert excluded['compiler/control']['sha256']==control['sha256'] and excluded['compiler/candidate']['sha256']==build['binary_sha256'] and 'compiler/helper-tests' in excluded and 'compiler/preparation-tests' in excluded
profile_settings={}
for name in ['Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.toml']:
 before=tomllib.loads((root/'source-base'/name).read_text());after=tomllib.loads((root/'source'/name).read_text());assert after['profile']==before['profile'];profile_settings[name]=after['profile']['compiler']
assert '--profile' in build['command'] and build['command'][build['command'].index('--profile')+1]=='compiler' and '--release' not in build['command']
stage_fields=[('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]
host_fields=[('max_rss_bytes',r'(\d+)  maximum resident set size'),('instructions',r'(\d+)  instructions retired'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]
order=['control-1','candidate-1','candidate-2','control-2','candidate-3','control-3','control-4','candidate-4']
def validate_cohort(raw,flags,expected,pins,key):
 rows=read(raw/'cohort.json');assert [r['name'] for r in rows]==order
 for name in ['control-screen','candidate-screen',*order]:
  variant=name.split('-')[0];d=raw/name;process=read(d/'process.json');assert process['exit_code']==0 and process['samples']==0 and process['sampling_error'] is None
  command=read(raw/(name+'-command.json'));assert command['flags']==flags and command['binary_sha256']==pins[variant]
  for filename,pinned in expected.items():assert pin(d/filename)==pinned and read(d/'output-check.json')[filename]==dict(pinned,**{key:True})
 for row in rows:
  d=raw/row['name'];assert row['compile']==read(d/'compile.json') and row['process']==read(d/'process.json') and row['files']==read(d/'output-check.json')
  assert row['variant']==row['name'].split('-')[0]
  stamps=[json.loads(line) for line in (d/'stages.jsonl').read_text().splitlines()]
  for field,begin,end in stage_fields:assert row[field]==next(s['elapsed'] for s in stamps if s['line'].startswith(end))-next(s['elapsed'] for s in stamps if s['line'].startswith(begin))
  for field,pattern in host_fields:assert row[field]==int(re.search(pattern,(d/'stderr.log').read_text()).group(1))
  if True:
   begin=next(s for s in stamps if s['line'].startswith('compact-stage: compact values before='));end=next(s for s in stamps if s['line'].startswith('compact-stage: CFG cleanup'));assert row['compaction_seconds']==end['elapsed']-begin['elapsed'];assert row['value_ids_before']==int(begin['line'].split('=')[-1])==20787570;assert row['value_ids_after']==int(next(s['line'] for s in stamps if s['line'].startswith('compact-values: retained=')).split('=')[-1])==1241393
  else:assert row['compaction_seconds']==0
  assert row['cleanup_including_compaction_seconds']==row['cleanup_seconds']+row['compaction_seconds']
 fixtures=read(raw/'fixture-results.json');assert len(fixtures)==14
 for record in fixtures:
  assert record['all_outputs_match'] and record['variants']['control']==record['variants']['candidate'] and record['variants']['control']['exit_code']==0 and len(record['variants']['control']['files'])==4
  name=Path(record['fixture']).stem if ':' not in record['fixture'] else record['fixture'].split(':')[-1]
  for variant,result in record['variants'].items():
   d=raw/'fixtures'/name/variant;command=read(d/'command.json');assert command['flags']==flags and command['binary_sha256']==pins[variant]
   for filename,pinned in result['files'].items():assert pin(d/filename)==pinned
   assert result['files']['source.mec']['sha256']==record['source_sha256']
 base=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase.mec').read_text();fragment=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase-states.mec').read_text();assembled=base.replace('+> sequence\n','+> sequence\n'+fragment+'\n',1).replace('phase-candidates(values, 1u64, 0u64, permitted, divisor)','#PhaseCandidates(values, permitted, divisor, 1u64, 0u64)',1);assert assembled==(raw/'fixture-inputs/numeric-nested-phase-states.mec').read_text()
 fields={'compiler_seconds':lambda r:r['compile']['total_seconds'],'whole_process_seconds':lambda r:r['process']['elapsed_seconds']}
 for phase in ['parse','frontend','native']:fields[phase+'_seconds']=lambda r,p=phase:next(v['seconds'] for v in r['compile']['phases'] if v['phase']==p)
 for field in [f[0] for f in stage_fields]+['cleanup_including_compaction_seconds','compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:fields[field]=lambda r,k=field:r[k]
 qualified={field:{v:[fn(r) for r in rows if r['variant']==v] for v in ['control','candidate']} for field,fn in fields.items()}
 for values in qualified.values():
  mean=statistics.mean(values['control']);values['mean_reduction_fraction']=1-statistics.mean(values['candidate'])/mean if mean else None
 assert qualified==read(raw/'numerical-summary.json')
 blocks=[]
 for block in [rows[:4],rows[4:]]:
  blocks.append(dict(order=[r['name'] for r in block],compiler_mean_reduction_fraction=1-statistics.mean(r['compile']['total_seconds'] for r in block if r['variant']=='candidate')/statistics.mean(r['compile']['total_seconds'] for r in block if r['variant']=='control')))
 return dict(flags_count=len(flags),qualified=qualified,blocks=blocks,output_hashes=expected,compiler_binary_sha256=pins,fixture_output_comparisons=fixtures)

qualification=validate_cohort(raw,flags,expected,{'control':control['sha256'],'candidate':build['binary_sha256']},'matches_current_control_output')
tests={}
for name in ['helper-build','helper-tests','preparation-build','preparation-tests']:
 command=read(raw/(name+'-command.json'));assert command['exit_code']==0 and command['source_patch_sha256']==state['patch_sha256']==pin(raw/(name+'.patch'))['sha256'];tests[name]=command
for name,count in [('helper-tests',5),('preparation-tests',13)]:assert re.findall(r'test result: ok\. (\d+) passed',(raw/(name+'.log')).read_text())==[str(count)]
check=read(raw/'runtime-only-check-command.json');parent_check=read(raw/'runtime-only-parent-check-command.json');assert check['exit_code']==parent_check['exit_code']==101 and check['source_commit']==state['source_commit'] and check['source_patch_sha256']==state['patch_sha256'] and parent_check['source_commit']==state['base_commit']
for name in ['runtime-only-check.log','runtime-only-parent-check.log']:
 diagnostics=re.findall(r'^error: function `(.*?)` is never used',(raw/name).read_text(),re.M);assert diagnostics==['derive','derive_tree']
 assert len(re.findall(r'^error:',(raw/name).read_text(),re.M))==3
base=root/'source-base/hosts/gpu/src/native_artifact/program';source=root/'source/hosts/gpu/src/native_artifact/program';before=(base/'codegen/minimal_liveness.rs').read_text();after=(source/'codegen/minimal_liveness.rs').read_text();old_record=before[before.index('impl WordAccess for Effects'):before.index('    let mut live = effects')];new_record=after[after.index('impl WordAccess for Effects'):after.index('    dataflow::required')];assert old_record==new_record
before=(base/'prepare/numeric_liveness.rs').read_text();old_kernel=before[before.index('fn dense_live_before_indexed('):before.index('\nfn solve_indexed(')];old_kernel=old_kernel[old_kernel.index('{'):];after=(source/'packed_liveness.rs').read_text();new_kernel=after[after.index('fn dense_live_before_indexed'):];new_kernel=new_kernel[new_kernel.index('{'):];normalize=lambda s:re.sub(r'\s+','',s);assert normalize(old_kernel)==normalize(new_kernel)
equivalence=read(raw/'source-equivalence-check.json');assert equivalence['emitter_recording_byte_identical'] and equivalence['dense_kernel_body_equal_ignoring_whitespace'];assert equivalence['emitter_recording_sha256']==hashlib.sha256(old_record.encode()).hexdigest() and equivalence['dense_kernel_body_sha256']==hashlib.sha256(normalize(old_kernel).encode()).hexdigest()
for name in ['helper_liveness_tests.rs','numeric_liveness_tests.rs']:assert 'packed_liveness.rs' in (root/'source/benchmarks/mech-deflate/native-profile'/name).read_text()
summary=dict(source_commit=state['source_commit'],base_commit=state['base_commit'],control_source_commit=state['control_source_commit'],hardware=state['hardware'],decision='Retain shared packed helper-liveness transfer with exact recorded effects and the original large-query fallback; identical generated program bytes',candidate_patch_sha256=state['patch_sha256'],profile_settings=profile_settings,candidate_rebuild_seconds=build['seconds'],rebuild_scope='Observed locked/offline optimized-profile rebuild with existing Cargo caches. Excluded from Mech compilation timing; no matched cold-bootstrap comparison.',compiler_executable_bytes={v:excluded['compiler/'+v]['bytes'] for v in ['control','candidate']},rust_test_commands=tests,rust_tests_passed=18,helper_tests=5,existing_preparation_tests=13,runtime_only_check=check,runtime_only_parent_check=parent_check,runtime_only_scope='Both revisions fail the same pre-existing readonly_numeric dead-code lint errors; this feature check is not counted as passing. No allowance is added.',source_equivalence_checks=equivalence,scope=[
 'Eight serial fresh source-to-Object primary observations in ABBA then BAAB order, identical 60 runtime flags and compiler build profile. No cached Object or decoded-only substitute.',
 'Builds, tests, screens, fixtures, CPU sampling, hashing, copying and packet work do not overlap primary timing. All source, MBC, Object and complete metadata bytes match the qualified program in both screens and every primary observation; fourteen successful fixture pairs match all four files.',
 'The helper emitter recording block remains byte-identical. The existing preparation packed transfer body is shared generically without algorithm changes. Query-local usize word ordinals preserve sparse/high IDs. Local reads seed before kills; terminal reads occur after local writes; fallback nodes retain exactly their exported reads and selected edges.',
 'The same 16M-cell cap bounds the two packed planes to 256 MiB. Above the cap, each caller retains its original fallback solver. Every plan, guard, ownership, visit, shape, factory, resource and selected-edge query remains fresh; no result cache or execution authority is added.',
 'All eighteen unique focused tests pass: thirteen existing preparation cases and five helper cases with an independent read-before-write path oracle over seeded graphs, cycles, duplicate edges, terminal writes, fallback exits, missing headers, sparse IDs, caps and forced original-set fallback. The optional runtime-only feature check fails in both parent and candidate on the same two pre-existing readonly_numeric unused-function errors, without an allowance; it is not counted as passing. Whole GPU/runtime unit suites were not rerun.',
 'Grammar, language, checked errors, direct scalar instruction emission, finite admission, runtime accounting and backend optimization settings remain unchanged. No execution machinery is retired.',
 'Both subjects retain SSA value compaction and its measured cost. Generated machine code and complete metadata are byte-identical. No new compressor-runtime latency or CPU sampling campaign is claimed. The prior helper CPU profile retains its source pins in the local-traversal packet. Complete compilation remains above ten seconds.'
],**qualification)
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
