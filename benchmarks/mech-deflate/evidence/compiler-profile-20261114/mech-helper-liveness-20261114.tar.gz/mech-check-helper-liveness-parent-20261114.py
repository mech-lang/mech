from pathlib import Path
import subprocess,tarfile,sys,os,json,time
root=Path('/private/tmp/mech-helper-liveness-20261114');parent=Path('/private/tmp/mech-helper-liveness-parent-20261114');parent.mkdir();revision=json.loads((root/'candidate-build.json').read_text())['head']
p=subprocess.Popen(['git','archive','--format=tar',revision],stdout=subprocess.PIPE)
with tarfile.open(fileobj=p.stdout,mode='r|') as archive:
 for member in archive:
  if member.name.startswith('benchmarks/mech-deflate/evidence/'):continue
  archive.extract(member,parent,filter='data')
assert p.wait()==0
cmd=['cargo','check','--locked','--offline','--profile','compiler','-j2','--manifest-path','hosts/gpu/Cargo.toml','--lib','--no-default-features','--features','canonical-native-program-runtime'];start=time.perf_counter()
with (root/'runtime-only-parent-check.log').open('w') as out:result=subprocess.run(cmd,cwd=parent,env=dict(os.environ,CARGO_TARGET_DIR='/private/tmp/mech-level12-compile-target',CARGO_INCREMENTAL='0'),stdout=out,stderr=subprocess.STDOUT)
receipt=dict(command=cmd,source_commit=revision,exit_code=result.returncode,seconds=time.perf_counter()-start,CARGO_TARGET_DIR='/private/tmp/mech-level12-compile-target',CARGO_INCREMENTAL='0',source_scope='Unchanged parent Git archive; benchmark evidence archives omitted from extraction. Main worktree source is untouched.');(root/'runtime-only-parent-check-command.json').write_text(json.dumps(receipt,indent=2)+'\n');print(receipt,flush=True);raise SystemExit(result.returncode)
