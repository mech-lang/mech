//! Immutable same-plan metadata preparation. No backend or execution authority.
use crate::native_artifact as native;
use crate::native_artifact::NativeValueSlot;
use crate::native_artifact::iteration_abi::NativeIterationVisit;
use crate::native_artifact::program::prepare::retirement::RetirementTables;
use mech_core::{FunctionCatalog, SchemaTable, Value};
use mech_engine::ProgramArtifact;
use mech_engine::native_artifact::{
    NativeDescriptorTemplatePool, NativeIterationAction, NativePreparedLibraryCall,
    NativeProgramArtifactPlan, NativeTextLineRetentionFrontier,
    prepare_native_program_library_call_with_descriptors,
};
use std::sync::Arc;

pub(in crate::native_artifact) mod borrowed_dictionary_values;
pub(in crate::native_artifact) mod call_cache;
pub(in crate::native_artifact) mod call_routes;
pub(in crate::native_artifact) mod cleanup_effects;
pub(in crate::native_artifact) mod composition;
pub(in crate::native_artifact) mod constant_owners;
pub(in crate::native_artifact) mod frame_retirement;
pub(in crate::native_artifact) mod numeric_phase;
pub(in crate::native_artifact) mod worker_values;

/// Canonical arguments are source operands or parent-piece owner pins. Numeric
/// SSA/reconciliation words never install managed owners in this bank.
pub(in crate::native_artifact) fn call_value_bound(
    plan: &NativeProgramArtifactPlan,
    compositions: &composition::Layout,
    window_owners: bool,
) -> usize {
    plan.blocks()
        .iter()
        .filter_map(|block| match block.action() {
            NativeIterationAction::LibraryCall { operands, .. } => Some(operands.len()),
            _ => None,
        })
        .max()
        .unwrap_or(0)
        .max(compositions.argument_values())
        .max(if window_owners { 2 } else { 0 })
}

/// Recomputed both on source preparation and independent build-image loading.
pub(in crate::native_artifact) fn prepare_frame_composition(
    plan: &NativeProgramArtifactPlan,
    frames: &mech_engine::native_artifact::NativeBufferFrames,
    calls: &mut [Option<NativePreparedLibraryCall>],
) -> Result<(), String> {
    for (site, call) in calls.iter_mut().enumerate() {
        let (Some(call), Some(action)) = (call, frames.action(site)) else {
            continue;
        };
        let NativeIterationAction::LibraryCall { operands, .. } = plan.blocks()[site].action()
        else {
            continue;
        };
        call.prepare_buffer_frame_composition(frames, action.operation(), operands)
            .map_err(str::to_owned)?;
    }
    Ok(())
}

#[derive(Debug)]
pub(in crate::native_artifact) struct ProgramMetadata {
    pub(in crate::native_artifact) plan: NativeProgramArtifactPlan,
    pub(in crate::native_artifact) schemas: Arc<SchemaTable>,
    // Query entries are prepared from their SAME sink step and fully checked
    // by validate_query_stages before this immutable descriptor can escape.
    // Runtime stage lookup never rebinds or clones those selected templates.
    pub(in crate::native_artifact) calls: Box<[Option<NativePreparedLibraryCall>]>,
    // Complete prepared-call inventory, independently rederived on image load.
    pub(in crate::native_artifact) call_cache: call_cache::Layout,
    pub(in crate::native_artifact) compositions: composition::Layout,
    // Derived from these exact calls/proofs, including independent image load.
    pub(in crate::native_artifact) call_routes: Box<[call_routes::LibraryCallRoute]>,
    pub(in crate::native_artifact) types: Box<[NativeValueSlot]>,
    pub(in crate::native_artifact) visits: Box<[NativeIterationVisit]>,
    pub(in crate::native_artifact) retirements: RetirementTables,
    // Zero only for constants with no all-path semantic runtime reader.
    // Independent image loading rederives the complete ownership inventory.
    pub(in crate::native_artifact) constant_bytes: Box<[u64]>,
    // Derived cache, recomputed from the exact bounds when an image is loaded.
    // It grants no independent authority and adds no serialized field.
    pub(in crate::native_artifact) constant_admission_bytes: u64,
    pub(in crate::native_artifact) scalar_bytes: u64,
    pub(in crate::native_artifact) observation_schema_bytes: u64,
    pub(in crate::native_artifact) max_library_inputs: usize,
    // Canonical argument owners only. Raw reconciliation words retain their
    // separately admitted legacy bound above. Recomputed on image loading.
    pub(in crate::native_artifact) max_call_values: usize,
    // Derived from this SAME immutable plan; callers cannot inject a region
    // from another artifact or rebind one to a different selected factory.
    // Same-plan last-use candidates are recomputed on every image load. The
    // runtime still checks exact current owners and exclusive core storage.
    pub(in crate::native_artifact) buffer_frames: mech_engine::native_artifact::NativeBufferFrames,
    // Derived from these exact frame lanes, including independent image load.
    pub(in crate::native_artifact) frame_retirements: frame_retirement::FrameRetirements,
    pub(in crate::native_artifact) cleanup_effects: cleanup_effects::Layout,
    pub(in crate::native_artifact) unsigned_buffer_calls:
        Box<[Option<mech_engine::native_artifact::NativeUnsignedBufferCall>]>,
    // Pure derived cache. Recomputed from the validated plan on image load;
    // it is neither serialized authority nor another preparation pipeline.
    pub(in crate::native_artifact) uniform_word_collections:
        Box<[mech_engine::native_artifact::NativeUniformWordCollection]>,
    pub(in crate::native_artifact) utf8_reads: utf8_reads::Layout,
    pub(in crate::native_artifact) numeric_maps: numeric_maps::Layout,
    pub(in crate::native_artifact) word_collections: Box<[word_collections::Region]>,
    pub(in crate::native_artifact) window_regions:
        Box<[mech_engine::native_artifact::NativeWindowRegion]>,
    pub(in crate::native_artifact) string_map_regions:
        Box<[mech_engine::native_artifact::NativeStringMapRegion]>,
    pub(in crate::native_artifact) scalar_aggregates:
        mech_engine::native_artifact::NativeScalarAggregates,
    // Complete same-plan candidate layout, preserved through standalone images.
    // Merely carrying this metadata does not select retained runtime storage.
    pub(in crate::native_artifact) map_owner_words:
        Option<mech_engine::native_artifact::NativeMapOwnerWords>,
    pub(in crate::native_artifact) frozen_maps: native::program::prepare::frozen_map::Layout,
    pub(in crate::native_artifact) borrowed_record_maps: borrowed_record_map::Layout,
    pub(in crate::native_artifact) matrix_map_keys: matrix_map_keys::Layout,
    pub(in crate::native_artifact) borrowed_map_keys: borrowed_map_keys::Layout,
    pub(in crate::native_artifact) generic_dictionary: generic_dictionary::Layout,
    pub(in crate::native_artifact) dictionary_seed_frames: dictionary_seed_frames::Layout,
    pub(in crate::native_artifact) borrowed_dictionary_values: borrowed_dictionary_values::Layout,
    pub(in crate::native_artifact) fixed_key_loops: fixed_key_loops::Layout,
    pub(in crate::native_artifact) map_admission: native::program::prepare::map_admission::Layout,
    pub(in crate::native_artifact) parallel: native::program::prepare::parallel::Layout,
    // Pure nonserialized storage inventory; rebuilt on every image path.
    pub(in crate::native_artifact) worker_value_slots:
        Box<[Option<crate::native_artifact::values::NativeValueSlotMap>]>,
    pub(in crate::native_artifact) borrowed_strings: native::program::prepare::borrowed::Layout,
    pub(in crate::native_artifact) closed_tails: native::program::prepare::tail::Layout,
    pub(in crate::native_artifact) selected_joins: native::program::prepare::selected_join::Layout,
    pub(in crate::native_artifact) line_matrices: native::program::prepare::line_matrix::Layout,
    pub(in crate::native_artifact) prefix: Option<native::program::prepare::prefix::Region>,
}

/// Exactly one owned plan and its derived metadata, shared by emission and
/// source-backed reconstruction. Complete frontiers are identity scratch.
pub(in crate::native_artifact) struct PreparedNativeProgram {
    metadata: ProgramMetadata,
    complete_frontiers: Box<[NativeTextLineRetentionFrontier]>,
    // Compiler-only source facts belong to this exact immutable Plan owner.
    // Never serialized or moved into runtime ProgramMetadata.
    #[cfg(feature = "canonical-native-program")]
    producer_element_reads: std::cell::OnceCell<std::collections::BTreeSet<(usize, u32)>>,
    #[cfg(feature = "canonical-native-program")]
    boolean_branch_targets: std::cell::OnceCell<Vec<Option<u32>>>,
}
impl PreparedNativeProgram {
    pub(in crate::native_artifact) fn prepare(
        artifact: &ProgramArtifact,
        catalog: &FunctionCatalog,
        plan: NativeProgramArtifactPlan,
    ) -> Result<Self, String> {
        if artifact.revision() != plan.program_revision() {
            return Err("mixed canonical revision mismatch".into());
        }
        plan.validate_current_visits().map_err(str::to_owned)?;
        let facts = plan.facts();
        let scalar_aggregates = facts.scalar_aggregates();
        // One same-plan ownership decision: retained native map words keep
        // their existing components, while disjoint private frames may use
        // admitted canonical owners. A managed value cannot occupy both.
        let (buffer_frames, map_owner_words) =
            facts.buffer_frame_owner_layouts().map_err(str::to_owned)?;
        let parallel =
            native::program::prepare::parallel::Layout::derive(&facts, &scalar_aggregates)
                .map_err(str::to_owned)?;
        let retirements =
            RetirementTables::derive(&plan, &scalar_aggregates).map_err(str::to_owned)?;
        let completion = (plan.transport_output_count() as u64)
            .checked_mul(64)
            .and_then(|n| n.checked_add((plan.iterations().len() as u64).checked_mul(8)?))
            .and_then(|n| n.checked_add(256))
            .ok_or("program completion overflow")?;
        let borrowed_strings =
            native::program::prepare::borrowed::Layout::derive(&plan, &scalar_aggregates)?;
        let string_map_regions = plan.string_map_regions().into_boxed_slice();
        let unsigned_buffer_calls = facts.unsigned_buffer_calls().into_boxed_slice();
        let selected_joins =
            native::program::prepare::selected_join::Layout::derive(&plan, &string_map_regions)?;
        let line_matrices = native::program::prepare::line_matrix::Layout::derive(&plan)?;
        let utf8_reads = utf8_reads::Layout::derive(&plan).map_err(str::to_owned)?;
        let numeric_maps = numeric_maps::Layout::derive(&plan).map_err(str::to_owned)?;
        let mut analysis_visits = native::iteration_abi::control_visits(
            plan.blocks(),
            plan.iterations().iter().map(Into::into),
            0,
        )
        .map_err(str::to_owned)?;
        let mut visits = native::iteration_abi::control_visits(
            plan.blocks(),
            plan.iterations().iter().map(Into::into),
            completion,
        )
        .map_err(str::to_owned)?;
        selected_joins
            .fund_visit_checks(&mut analysis_visits)
            .map_err(str::to_owned)?;
        selected_joins
            .fund_visit_checks(&mut visits)
            .map_err(str::to_owned)?;
        compose_work(
            &mut analysis_visits,
            &mut visits,
            |site| {
                Ok(if utf8_reads.at_header(site).is_some() {
                    utf8_reads::HEADER_WORK
                } else if numeric_maps.at_header(site).is_some() {
                    numeric_maps::HEADER_WORK
                } else {
                    0
                })
            },
            "native UTF8 lookup header work overflow",
        )?;
        // Derive this proof once from the SAME immutable plan. Both layout and
        // identity inspect the complete result, including unsupported/multiple
        // frontiers; no caller-provided or persistent proof cache is consulted.
        let line_retention_frontiers = facts.text_line_retention_frontiers();
        let prefix = native::program::prepare::prefix::derive_with_frontiers(
            &plan,
            &borrowed_strings,
            &analysis_visits,
            &scalar_aggregates,
            &line_retention_frontiers,
        )?;
        compose_work(
            &mut analysis_visits,
            &mut visits,
            |site| {
                borrowed_strings
                    .extra_work(site)?
                    .checked_add(native::program::prepare::prefix::extra_work(
                        prefix.as_ref(),
                        site,
                    ))
                    .ok_or("borrowed String visit work overflow")
            },
            "borrowed String visit work overflow",
        )?;
        compose_work(
            &mut analysis_visits,
            &mut visits,
            |site| native::program::prepare::map_owner::extra_work(&map_owner_words, site),
            "map owner visit work overflow",
        )?;
        let mut descriptor_templates = NativeDescriptorTemplatePool::default();
        let mut calls = (0..plan.blocks().len())
            .map(|site| {
                plan.prepared_library_template(site)
                    .map_err(str::to_owned)?
                    .map(|template| {
                        prepare_native_program_library_call_with_descriptors(
                            artifact,
                            template,
                            catalog,
                            &mut descriptor_templates,
                        )
                        .map_err(|error| error.to_string())
                    })
                    .transpose()
            })
            .collect::<Result<Box<[_]>, _>>()?;
        query_stages::validate_query_stages(&plan, &calls).map_err(str::to_owned)?;
        prepare_frame_composition(&plan, &buffer_frames, &mut calls)?;
        let matrix_map_keys = matrix_map_keys::Layout::derive(&plan, Some(&map_owner_words))
            .map_err(str::to_owned)?;
        let borrowed_map_keys =
            borrowed_map_keys::Layout::derive(&plan, &buffer_frames, &matrix_map_keys)
                .map_err(str::to_owned)?;
        let generic_dictionary =
            generic_dictionary::Layout::derive(&plan, &map_owner_words, &utf8_reads)
                .map_err(str::to_owned)?;
        compose_work(
            &mut analysis_visits,
            &mut visits,
            |site| Ok(generic_dictionary.extra_work(site)),
            "guarded dictionary publication work overflow",
        )?;
        let dictionary_seed_frames =
            dictionary_seed_frames::Layout::derive(&plan, &map_owner_words)
                .map_err(str::to_owned)?;
        let borrowed_dictionary_values = borrowed_dictionary_values::Layout::derive(
            &plan,
            Some(&map_owner_words),
            &borrowed_map_keys,
            &matrix_map_keys,
            &dictionary_seed_frames,
            &generic_dictionary,
        )
        .map_err(str::to_owned)?;
        let fixed_key_loops = fixed_key_loops::Layout::derive(
            &plan,
            Some(&map_owner_words),
            &borrowed_dictionary_values,
            &matrix_map_keys,
        )
        .map_err(str::to_owned)?;
        let closed_tails = native::program::prepare::tail::Layout::derive(
            &facts,
            &borrowed_strings,
            &analysis_visits,
            &scalar_aggregates,
            &map_owner_words,
            &buffer_frames,
            &calls,
            &fixed_key_loops,
        )?;
        compose_work(
            &mut analysis_visits,
            &mut visits,
            |site| Ok(closed_tails.extra_work(site)),
            "closed Tail work overflow",
        )?;
        let map_admission = native::program::prepare::map_admission::Layout::derive(
            &plan,
            &scalar_aggregates,
            Some(&map_owner_words),
            &analysis_visits,
            &closed_tails,
        )?;
        let visits: Box<[NativeIterationVisit]> = visits.into();
        let frame_retirements =
            frame_retirement::FrameRetirements::derive(&buffer_frames, plan.values().len())?;
        let cleanup_effects = cleanup_effects::Layout::derive(
            &plan,
            &retirements,
            &buffer_frames,
            &frame_retirements,
        )?;
        let compositions = composition::Layout::derive(
            &plan,
            &buffer_frames,
            &scalar_aggregates,
            &calls,
            &closed_tails,
            &visits,
            &frame_retirements,
            &map_admission,
        )?;
        let uniform_word_collections = facts.uniform_unsigned_collections().into_boxed_slice();
        let word_collections =
            word_collections::derive(&plan, &visits, &map_admission).into_boxed_slice();
        let window_regions = plan.window_regions().into_boxed_slice();
        let occupied_frame =
            frame_prefix_words(&plan, &scalar_aggregates, &borrowed_strings, &closed_tails)
                .ok_or("map owner frame prefix overflow")?;
        let map_owner_words = map_owner_words
            .after_frame_words(occupied_frame)
            .map_err(str::to_owned)?;
        // Programs without owner candidates keep no second copy of their
        // existing scalar slot/action/constant inventories in the descriptor.
        let map_owner_words = (!map_owner_words.regions().is_empty()).then_some(map_owner_words);
        let call_arity = plan
            .blocks()
            .iter()
            .filter_map(|block| match block.action() {
                NativeIterationAction::LibraryCall { operands, .. } => Some(operands.len()),
                _ => None,
            })
            .max()
            .unwrap_or(0);
        let max_call_values = call_value_bound(
            &plan,
            &compositions,
            !window_regions.is_empty() || !string_map_regions.is_empty(),
        );
        let max_library_inputs = call_arity
            .max(
                if window_regions.is_empty() && string_map_regions.is_empty() {
                    0
                } else {
                    5
                },
            )
            .max(
                borrowed_strings
                    .regions
                    .iter()
                    .map(|r| r.capture_words())
                    .max()
                    .unwrap_or(0),
            )
            .max(
                map_owner_words
                    .as_ref()
                    .map_or(0, native::program::prepare::map_owner::initial_words),
            )
            .max(
                closed_tails
                    .regions
                    .iter()
                    .filter_map(|r| r.numeric.as_ref())
                    .map(|p| p.words + if p.writes() { 4 } else { 2 })
                    .max()
                    .unwrap_or(0),
            )
            .max(usize::from(!parallel.regions.is_empty()))
            .max(
                closed_tails
                    .regions
                    .iter()
                    .filter_map(|region| region.captures.as_ref())
                    .map(|proof| proof.words() + 2)
                    .max()
                    .unwrap_or(0),
            )
            .max(if closed_tails.regions.is_empty() {
                0
            } else {
                4
            })
            .max(compositions.argument_words())
            .max(if word_collections.is_empty() { 0 } else { 3 });
        let types: Box<[_]> = plan
            .values()
            .iter()
            .chain(
                (0..plan.transport_output_count()).map(|index| plan.transport_output_type(index)),
            )
            .map(|ty| NativeValueSlot {
                schema: ty.schema(),
                key: ty.schema_key(),
            })
            .collect();
        validate_type_slots(&plan, artifact.schemas(), &types).map_err(str::to_owned)?;
        let constant_bytes = constant_owners::admission_bounds(&facts)?;
        let constant_admission_bytes = constant_admission_total(&constant_bytes)?;
        // Shared schema finalization avoids a schema clone, but ownership
        // admission still includes the complete schema context. Reserve a
        // conservative fixed scalar construction/import envelope BEFORE use.
        let observation_schema_bytes = artifact
            .schemas()
            .clone_allocation_bound_bytes()
            .ok_or("observation schema ownership bound overflows")?;
        let scalar_bytes = observation_schema_bytes
            .checked_add(Value::canonical_owner_allocation_bytes())
            .and_then(|n| n.checked_add(Value::memory_budget_claim_metadata_bytes()))
            .and_then(|n| n.checked_mul(4))
            .and_then(|n| n.checked_add(4096))
            .ok_or("scalar ownership bound overflows")?;
        // These complete inventories were derived above from this SAME
        // immutable plan. Hash every proof in its original order, including
        // proofs not selected by the capture prefix, without deriving again.
        let frozen_maps = map_owner_words
            .as_ref()
            .map(|owner| {
                native::program::prepare::frozen_map::Layout::derive(&plan, owner, &closed_tails)
            })
            .transpose()
            .map_err(str::to_owned)?
            .unwrap_or_default();
        let borrowed_record_maps = map_owner_words
            .as_ref()
            .map(|owner| borrowed_record_map::Layout::derive(&plan, owner))
            .transpose()
            .map_err(str::to_owned)?
            .unwrap_or_default();
        let call_routes = call_routes::derive(
            &plan,
            &buffer_frames,
            &unsigned_buffer_calls,
            &calls,
            &borrowed_map_keys,
        );
        let call_cache = call_cache::Layout::derive(&plan, &calls)?;
        let (scalar_aggregates, line_retention_frontiers) = facts.into_preparation_inventories();
        let mut metadata = ProgramMetadata {
            plan,
            schemas: Arc::new(artifact.schemas().clone()),
            calls,
            call_cache,
            compositions,
            call_routes,
            types,
            visits,
            retirements,
            constant_bytes,
            constant_admission_bytes,
            scalar_bytes,
            observation_schema_bytes,
            max_library_inputs,
            max_call_values,
            uniform_word_collections,
            utf8_reads,
            numeric_maps,
            word_collections,
            unsigned_buffer_calls,
            buffer_frames,
            frame_retirements,
            cleanup_effects,
            window_regions,
            string_map_regions,
            scalar_aggregates,
            map_owner_words,
            frozen_maps,
            borrowed_record_maps,
            matrix_map_keys,
            borrowed_map_keys,
            generic_dictionary,
            dictionary_seed_frames,
            borrowed_dictionary_values,
            fixed_key_loops,
            map_admission,
            parallel,
            worker_value_slots: Box::new([]),
            borrowed_strings,
            closed_tails,
            selected_joins,
            line_matrices,
            prefix,
        };
        utf8_reads::derive_replay_facts(&mut metadata).map_err(str::to_owned)?;
        metadata.worker_value_slots = worker_values::derive(&metadata)?;
        Ok(Self {
            metadata,
            complete_frontiers: line_retention_frontiers.into_boxed_slice(),
            #[cfg(feature = "canonical-native-program")]
            producer_element_reads: std::cell::OnceCell::new(),
            #[cfg(feature = "canonical-native-program")]
            boolean_branch_targets: std::cell::OnceCell::new(),
        })
    }

    #[cfg(feature = "canonical-native-program")]
    pub(in crate::native_artifact) fn boolean_branch_targets(&self) -> &[Option<u32>] {
        self.boolean_branch_targets.get_or_init(|| {
            crate::native_artifact::codegen::common::boolean_branches::derive(
                crate::native_artifact::codegen::control::plan::CodePlan::Program(self),
            )
        })
    }

    pub(in crate::native_artifact) fn plan(&self) -> &NativeProgramArtifactPlan {
        &self.metadata.plan
    }
    #[cfg(feature = "canonical-native-program")]
    pub(in crate::native_artifact) fn producer_element_reads(
        &self,
        derive: impl FnOnce(&NativeProgramArtifactPlan) -> std::collections::BTreeSet<(usize, u32)>,
    ) -> &std::collections::BTreeSet<(usize, u32)> {
        self.producer_element_reads
            .get_or_init(|| derive(self.plan()))
    }
    pub(in crate::native_artifact) fn metadata(&self) -> &ProgramMetadata {
        &self.metadata
    }
    pub(in crate::native_artifact) fn complete_frontiers(
        &self,
    ) -> &[NativeTextLineRetentionFrontier] {
        &self.complete_frontiers
    }
    pub(in crate::native_artifact) fn into_metadata(self) -> ProgramMetadata {
        self.metadata
    }
}

// Composition is shared; analysis completion and charged completion remain
// distinct. Evaluate each supplement once, in the established order.
fn compose_work(
    analysis: &mut [NativeIterationVisit],
    charged: &mut [NativeIterationVisit],
    mut extra: impl FnMut(usize) -> Result<u64, &'static str>,
    overflow: &'static str,
) -> Result<(), &'static str> {
    debug_assert_eq!(analysis.len(), charged.len());
    for (site, (analysis, charged)) in analysis.iter_mut().zip(charged).enumerate() {
        let extra = extra(site)?;
        analysis.work = analysis.work.checked_add(extra).ok_or(overflow)?;
        charged.work = charged.work.checked_add(extra).ok_or(overflow)?;
        debug_assert!(analysis.is_completion() || analysis.work == charged.work);
    }
    Ok(())
}

// The sole canonical frame-prefix formula. Owner relocation occurs only in
// preparation; later consumers inspect this existing assignment.
pub(in crate::native_artifact) fn frame_prefix_words(
    plan: &NativeProgramArtifactPlan,
    aggregates: &mech_engine::native_artifact::NativeScalarAggregates,
    borrowed: &native::program::prepare::borrowed::Layout,
    closed: &native::program::prepare::tail::Layout,
) -> Option<usize> {
    plan.values()
        .len()
        .checked_add(plan.iterations().len())
        .and_then(|n| n.checked_add(aggregates.words()))
        .and_then(|n| n.checked_add(borrowed.words))
        .and_then(|n| n.checked_add(closed.words))
}
impl ProgramMetadata {
    pub(in crate::native_artifact) fn local_words(&self) -> Result<usize, &'static str> {
        let prefix = frame_prefix_words(
            &self.plan,
            &self.scalar_aggregates,
            &self.borrowed_strings,
            &self.closed_tails,
        )
        .ok_or("local count overflow")?;
        let words = self
            .map_owner_words
            .as_ref()
            .map_or(Ok(prefix), native::program::prepare::map_owner::local_words)?;
        words
            .checked_add(self.compositions.words)
            .ok_or("parent local words overflow")
    }
}

/// Bind each retained key to this exact value index, complete definition and
/// authoritative schema-table entry. Preparation and independent image loading
/// share this check; a key valid elsewhere in the table grants no slot authority.
pub(in crate::native_artifact) fn validate_type_slots(
    plan: &NativeProgramArtifactPlan,
    schemas: &SchemaTable,
    slots: &[NativeValueSlot],
) -> Result<(), &'static str> {
    if slots.len() != plan.values().len() + plan.transport_output_count() {
        return Err("native type-slot count differs from plan");
    }
    for (ty, slot) in plan
        .values()
        .iter()
        .chain((0..plan.transport_output_count()).map(|i| plan.transport_output_type(i)))
        .zip(slots)
    {
        let entry = schemas
            .entry(ty.schema())
            .ok_or("native plan type lacks schema entry")?;
        if slot.schema != ty.schema()
            || slot.key != entry.key()
            || ty.definition() != entry.schema()
        {
            return Err("native type slot differs from exact plan definition and schema key");
        }
    }
    Ok(())
}

pub(in crate::native_artifact) mod captured_numeric;
pub(in crate::native_artifact) mod numeric_plan;
pub(in crate::native_artifact) mod numeric_tree;
mod phase_numeric;
pub(in crate::native_artifact) mod readonly_numeric;
pub(in crate::native_artifact) mod retirement;

pub(in crate::native_artifact) fn constant_admission_total(bounds: &[u64]) -> Result<u64, String> {
    bounds
        .iter()
        .try_fold(0u64, |sum, &bound| sum.checked_add(bound))
        .ok_or_else(|| "constant admission total overflows".to_owned())
}

pub(in crate::native_artifact) mod borrowed;
pub(in crate::native_artifact) mod borrowed_record_map;
pub(in crate::native_artifact) mod frozen_map;
pub(in crate::native_artifact) mod line_matrix;
pub(in crate::native_artifact) mod map_admission;
pub(in crate::native_artifact) mod map_owner;
pub(in crate::native_artifact) mod matrix_map_keys;
pub(in crate::native_artifact) mod packed_map;
pub(in crate::native_artifact) mod parallel;
pub(in crate::native_artifact) mod prefix;
pub(in crate::native_artifact) mod selected_join;
pub(in crate::native_artifact) mod tail;
pub(in crate::native_artifact) mod window_histogram;
pub(in crate::native_artifact) mod word_collections;

pub(in crate::native_artifact) mod numeric_maps;
pub(in crate::native_artifact) mod query_stages;
pub(in crate::native_artifact) mod utf8_reads;

pub(in crate::native_artifact) mod borrowed_map_keys;

pub(in crate::native_artifact) mod generic_dictionary;

pub(in crate::native_artifact) mod dictionary_seed_frames;

pub(in crate::native_artifact) mod fixed_key_loops;
