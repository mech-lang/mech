from pathlib import Path
import json,hashlib,re
root=Path(__file__).resolve().parent;raw=root/'integration';read=lambda p:json.loads(p.read_text())
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
build=read(raw/'current-build.json');ref=read(raw/'reference.json');prior=read(root/'validation/live-definitions-compile-apple-m3-20261114.json');receipt=read(root/'validation/live-definitions-compile-apple-m3-20261114.archive.json')
assert pin(root/'validation/live-definitions-compile-apple-m3-20261114.json')['sha256']==receipt['replay_sha256']
assert build['head']==ref['source_commit']=='342937b4cba43ed57d08ca78648dde4b188d82b7' and build['exit_code']==0
assert pin(raw/'current.patch')=={'bytes':0,'sha256':hashlib.sha256(b'').hexdigest()} and build['patch_sha256']==hashlib.sha256(b'').hexdigest()
assert read(root/'excluded-executables.json')[0]['sha256']==build['binary_sha256']
flags=read(raw/'runtime-flags.json');assert len(flags)==54
outputs=read(raw/'output-check.json');assert outputs==read(raw/'trace-output-check.json')
assert outputs['program.o']['sha256']==ref['expected_object_sha256']=='8f33516fb93e1614a02f64d6dec1bd92f68abc6c4824b468c71840da494141a7'
assert ref['expected_object_sha256'] in (root/'source/docs/design/native-reduction-rotation.md').read_text()
for name in ['source.mec','program.mecb']:assert outputs[name]==prior['output_hashes'][name]
assert outputs['program.o']!=prior['output_hashes']['program.o'] and outputs['metadata.json']!=prior['output_hashes']['metadata.json']
records={}
for name,command_name in [('stage-memory','command.json'),('trace-memory','trace-command.json')]:
 d=raw/name;assert read(d/'process.json')['exit_code']==0
 command=read(raw/command_name);assert command['binary_sha256']==build['binary_sha256'] and command['flags']==flags
 for filename,pinned in outputs.items():assert pin(d/filename)==pinned
 rows=[json.loads(l) for l in (d/'memory.jsonl').read_text().splitlines()]
 for row in rows:
  assert row['exit_code']==0
  a=row['stdout'].split();assert row['rss_bytes']==int(a[0])*1024 and row['virtual_bytes']==int(a[1])*1024
 assert all(a['observed_elapsed']<=b['observed_elapsed'] for a,b in zip(rows,rows[1:]))
 log=(d/'stderr.log').read_text();peaks={k:int(re.search(pattern,log).group(1)) for k,pattern in [('max_rss_bytes',r'(\d+)  maximum resident set size'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]}
 records[name]={'samples':len(rows),'errors':0,'compiler_seconds_diagnostic_only':read(d/'compile.json')['total_seconds'],**peaks}
 if name=='stage-memory':
  assert len(rows)==373
  selected=['compact-stage: canonical lowering','compact-stage: native module','compact-stage: source CFG','compact-stage: finalize SSA','compact-stage: CFG cleanup','compact-stage: machine code','compact-stage: machine code complete']
  records[name]['selected_boundaries']=[{'stage':s,'rss_bytes':next(r['rss_bytes'] for r in rows if r['stage']==s)} for s in selected]
  records[name]['numeric_function_boundaries']=sum(r['stage'].startswith('compact-stage: numeric phase') for r in rows);assert records[name]['numeric_function_boundaries']==344
 else:
  assert len(rows)==244
  largest=max(rows,key=lambda r:r['rss_bytes']);assert largest['last_stage']['line']=='compile-profile: phase=frontend'
  records[name]['largest_sample']={k:largest[k] for k in ['observed_elapsed','rss_bytes','virtual_bytes','last_stage']}
  records[name]['frontend_max_rss_bytes']=max(r['rss_bytes'] for r in rows if r['last_stage']['line']=='compile-profile: phase=frontend')
  records[name]['machine_code_max_rss_bytes']=max(r['rss_bytes'] for r in rows if r['last_stage']['line']=='compact-stage: machine code')
summary={'source_commit':ref['source_commit'],'decision':'Combined compiler reproduces independently qualified runtime Object; prioritize frontend dimension environment work after resident-memory trace','hardware':'Apple M3 Air, 8 cores (4P+4E), 16 GB, macOS 26.2','flags_count':54,'compiler_binary_sha256':build['binary_sha256'],'compiler_bootstrap_seconds':build['seconds'],'output_hashes':outputs,'diagnostics':records,'scope':[
 'The source already contains both qualified compiler-only changes and the independent nested-reduction runtime change. Source and MBC match our own prior profiling input; Object matches the new runtime reference exactly. No bytecode identity with the independently authored runtime packet is claimed.',
 'Two separately executed memory diagnostics, not primary timings or a new matched cohort. Both produce all four outputs byte-identically. Bootstrap and all PS overhead are excluded from prior primary compile ranges.',
 '373 asynchronous stage-boundary snapshots include 344 numeric function starts. A separate trace uses requested 100 ms sleeps between PS calls; its 244 actual timestamps, commands and active-stage labels are retained.',
 'The largest continuous RSS sample occurs during frontend semantic analysis and is close to the host process peak. Main machine-code samples reach less resident memory. Snapshots are not allocation attribution and cannot exclude unobserved intervening peaks or distinguish retained/shared/compressed pages.',
 'The source snapshots identify dimension cloning/canonicalization and backend reservations sized by historical DFG value counts as next hypotheses. No memory optimization or causal allocation claim is made by these diagnostics.',
 'Compiler source has no diagnostic patch. Full compilation remains above ten seconds. Raw data and executable remain outside source Git, with exact source/build/command/hash records. Public export awaits authorization.'
]}
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
