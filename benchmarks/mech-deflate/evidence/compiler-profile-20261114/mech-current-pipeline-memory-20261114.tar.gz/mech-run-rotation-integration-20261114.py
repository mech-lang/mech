from pathlib import Path
import json,os,subprocess,hashlib,sys,time
root=Path('/private/tmp/mech-rotation-integration-20261114');out=root/'stage-memory';assert not out.exists();flags=json.loads((root/'runtime-flags.json').read_text());assert len(flags)==54
env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')};env.update(flags)
cmd=[sys.executable,'/private/tmp/mech-profile-memory-stages-20261114.py',str(root/'current'),'benchmark',str(out),'compact'];(root/'command.json').write_text(json.dumps({'command':cmd,'flags':flags,'binary_sha256':hashlib.sha256((root/'current').read_bytes()).hexdigest(),'scope':'Combined-head integration with asynchronous stage-boundary RSS snapshots. Diagnostic only, not a matched timing cohort.'},indent=2)+'\n')
p=subprocess.run(cmd,env=env);assert p.returncode==0,p.returncode
pins={}
for n in ['source.mec','program.mecb','program.o','metadata.json']:
 b=(out/n).read_bytes();pins[n]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
for n in ['source.mec','program.mecb']:assert (out/n).read_bytes()==(Path('/private/tmp/mech-live-definitions-20261114/candidate-1')/n).read_bytes()
assert pins['program.o']['sha256']==json.loads((root/'reference.json').read_text())['expected_object_sha256'],'combined compiler differs from the independently qualified rotation Object'
(root/'output-check.json').write_text(json.dumps(pins,indent=2)+'\n');print('COMBINED OUTPUTS',json.dumps(pins),flush=True)
