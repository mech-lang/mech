from pathlib import Path
import shutil,json,hashlib,subprocess
repo=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech');raw=Path('/private/tmp/mech-rotation-integration-20261114');packet=Path('/private/tmp/mech-current-pipeline-memory-packet-20261114');assert not packet.exists();excluded=[]
for p in sorted(raw.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(raw)
 if str(rel)=='current':excluded.append({'path':str(rel),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()});continue
 dest=packet/'integration'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
(packet/'excluded-executables.json').write_text(json.dumps(excluded,indent=2)+'\n')
source=json.loads((raw/'reference.json').read_text())['source_commit']
paths=['src/core/src/dimension.rs','src/core/src/schema/validation.rs','src/core/src/type_system/resolved.rs','src/engine/src/source_semantics/frontend.rs','src/engine/src/source_semantics/comprehension.rs','LICENSE','.cargo/config.toml','docs/design/native-reduction-rotation.md','benchmarks/mech-deflate/native-profile/Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.lock','benchmarks/mech-deflate/native-profile/compile_profile.rs','benchmarks/mech-deflate/native-profile/profile_compile.py','vendor/cranelift-codegen/src/machinst/lower.rs','vendor/cranelift-codegen/src/egraph/mod.rs','vendor/cranelift-codegen/src/egraph/elaborate.rs','hosts/gpu/src/native_artifact/program/compact/phase_function.rs','hosts/gpu/src/native_artifact/program/prepare/mod.rs']
for name in paths:
 dest=packet/'source'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(subprocess.check_output(['git','show',source+':'+name],cwd=repo))
for name in ['mech-build-rotation-integration-20261114.py','mech-profile-memory-stages-20261114.py','mech-profile-memory-trace-20261114.py','mech-run-rotation-memory-trace-20261114.py','mech-rotation-memory-trace-driver-20261114.log','mech-run-rotation-integration-20261114.py','mech-curate-current-pipeline-memory-20261114.py','mech-rotation-integration-build-driver-20261114.log','mech-rotation-integration-driver-20261114.log']:
 shutil.copy2(Path('/private/tmp')/name,packet/name)
shutil.copytree(repo/'benchmarks/mech-deflate/.experiments/compile-peers-apple-m3-20261113/packet/licenses',packet/'licenses')
validation=packet/'validation';validation.mkdir()
for name in ['live-definitions-compile-apple-m3-20261114.json','live-definitions-compile-apple-m3-20261114.archive.json']:
 shutil.copy2(repo/'benchmarks/mech-deflate/native-profile'/name,validation/name)
(packet/'README.txt').write_text("""Combined PR 973 integration and process resident-memory diagnostics.
Source 342937b4 includes both qualified compiler-only optimizations and the new,
independently qualified reduction-rotation runtime code-generation change.
The rebuilt combined compiler reproduces its pinned 8f33516f... Object exactly.
Source/MBC match our previous complete source input. Metadata changes with the
independent runtime transformation and is pinned separately. Both diagnostic
runs produce all four outputs byte-identically to one another.
These are separate diagnostics, not new matched timing cohorts. First, 373
asynchronous stage-boundary RSS/virtual-size snapshots include 344 numeric
function boundaries. Then a separate process polls RSS after requested 100 ms
waits; 244 samples retain their actual timestamps and active-stage labels.
The continuous trace observes its largest RSS in frontend semantic analysis,
about 6.913 GiB versus the host peak 6.93 GiB. Main machine-code observations
reach about 4.906 GiB. These are resident snapshots, not allocation attribution;
they do not distinguish live, retained, shared or compressed pages, and cannot
exclude unobserved intervening peaks. The raw host peak counters remain.
PS overhead is outside all prior primary timing cohorts. No compiler source
instrumentation or functional change is introduced. Backend value-count-sized
reservations are still an inspection target; they are not established as the
cause of the largest peak. The memory trace prioritizes dimension environment
cloning/normalization, also prominent in the separately pinned CPU profile.
No memory fix or sub-ten-second result is claimed here. Executables remain
local, represented by exact source/build records and hashes. Raw files remain
outside Git. Run python3 replay.py for pure offline reconstruction.
""");print(packet)
