Combined PR 973 integration and process resident-memory diagnostics.
Source 342937b4 includes both qualified compiler-only optimizations and the new,
independently qualified reduction-rotation runtime code-generation change.
The rebuilt combined compiler reproduces its pinned 8f33516f... Object exactly.
Source/MBC match our previous complete source input. Metadata changes with the
independent runtime transformation and is pinned separately. Both diagnostic
runs produce all four outputs byte-identically to one another.
These are separate diagnostics, not new matched timing cohorts. First, 373
asynchronous stage-boundary RSS/virtual-size snapshots include 344 numeric
function boundaries. Then a separate process polls RSS after requested 100 ms
waits; 244 samples retain their actual timestamps and active-stage labels.
The continuous trace observes its largest RSS in frontend semantic analysis,
about 6.913 GiB versus the host peak 6.93 GiB. Main machine-code observations
reach about 4.906 GiB. These are resident snapshots, not allocation attribution;
they do not distinguish live, retained, shared or compressed pages, and cannot
exclude unobserved intervening peaks. The raw host peak counters remain.
PS overhead is outside all prior primary timing cohorts. No compiler source
instrumentation or functional change is introduced. Backend value-count-sized
reservations are still an inspection target; they are not established as the
cause of the largest peak. The memory trace prioritizes dimension environment
cloning/normalization, also prominent in the separately pinned CPU profile.
No memory fix or sub-ten-second result is claimed here. Executables remain
local, represented by exact source/build records and hashes. Raw files remain
outside Git. Run python3 replay.py for pure offline reconstruction.
