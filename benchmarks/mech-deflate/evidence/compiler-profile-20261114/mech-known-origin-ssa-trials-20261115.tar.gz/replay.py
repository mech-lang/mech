from pathlib import Path
import hashlib,json,re,statistics
packet=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
cache={}
def pin(p):
 if p not in cache:cache[p]=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 return cache[p]
def apply(source,patch):
 lines=source.splitlines(keepends=True);diff=patch.splitlines(keepends=True);out=[];at=0;i=0
 while i<len(diff):
  m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',diff[i])
  if not m:i+=1;continue
  start=int(m[1])-1;assert start>=at;out.extend(lines[at:start]);at=start;i+=1
  while i<len(diff) and not diff[i].startswith('@@'):
   line=diff[i]
   if line.startswith(' '):assert lines[at]==line[1:];out.append(lines[at]);at+=1
   elif line.startswith('-'):assert lines[at]==line[1:];at+=1
   elif line.startswith('+'):out.append(line[1:])
   else:raise AssertionError(line)
   i+=1
 out.extend(lines[at:]);return ''.join(out)
def numerical(rows,fields):
 result={}
 for key,fn in fields.items():
  values={v:[fn(row) for row in rows if row['variant']==v] for v in ['control','candidate']}
  a=statistics.mean(values['control']);values['mean_reduction_fraction']=1-statistics.mean(values['candidate'])/a if a else None;result[key]=values
 return result
def blocks(rows,fields):
 result=[]
 for group in [rows[:4],rows[4:]]:
  block={}
  for key,fn in fields.items():
   item={v:statistics.mean(fn(row) for row in group if row['variant']==v) for v in ['control','candidate']};item['mean_reduction_fraction']=1-item['candidate']/item['control'] if item['control'] else None;block[key]=item
  result.append(block)
 return result
state=read(packet/'source-state.json');products={row['path']:row for row in read(packet/'excluded-compiler-products.json')}
prior=read(packet/'validation/prior-qualified.json');assert pin(packet/'validation/prior-qualified.json')['sha256']==read(packet/'validation/prior-qualified.archive.json')['replay_sha256']
expected=prior['output_hashes'];control_binary=prior['compiler_binary_sha256']['candidate'];exe=dict(bytes=2060440,sha256='d6c65cc3fb18acc4be77dce329962105bf0f2b56dd2623a12f466256463eca61')
for row in read(packet/'source-config-pins.json'):assert pin(packet/'source-config'/row['path'])=={k:row[k] for k in ['bytes','sha256']}
for row in read(packet/'native-link-inputs.json'):assert pin(packet/row['path'])=={k:row[k] for k in ['bytes','sha256']}
trials=[]
for label,count in [('pending-only',30),('known-origin',32)]:
 root=packet/label;raw=read(root/'source-state.json');old=(root/'reference.rs').read_text();new=(root/'candidate.rs').read_text()
 assert pin(root/'reference.rs')['sha256']==raw['reference_sha256'] and pin(root/'candidate.rs')['sha256']==raw['candidate_sha256'] and pin(root/'candidate.patch')['sha256']==raw['patch_sha256']
 assert old==(packet/'source-config/vendor/cranelift-frontend/src/ssa.rs').read_text() and apply(old,(root/'candidate.patch').read_text())==new
 binaries={v:products[label+'/'+v]['sha256'] for v in ['control','candidate']};assert binaries['control']==control_binary
 check=read(root/'candidate-check.json');build=read(root/'candidate-build.json')
 for stage,row in [('check',check),('build',build)]:
  assert row['exit_code']==0 and row['base_commit']==raw['base_commit'] and row['patch_sha256']==raw['patch_sha256'] and row['CARGO_INCREMENTAL']=='0'
  assert row['command']==['cargo','+nightly-2026-03-03',stage,'--locked','--offline','--profile','compiler','-j4','--manifest-path','benchmarks/mech-deflate/native-profile/Cargo.toml','--bin','compile_profile','--message-format=json']
 assert build['binary_sha256']==binaries['candidate']
 test=root/'focused';assert read(test/'build.json')['exit_code']==read(test/'test.json')['exit_code']==0
 assert f'test result: ok. {count} passed; 0 failed' in (test/'test.stdout.log').read_text()
 assert read(test/'build.json')['binary_sha256']==products[label+'/focused/tests']['sha256']
 for variant,row in zip(['reference','candidate'],read(test/'command.json')['source_pins']):
  src=(root/(variant+'.rs')).read_text();assert hashlib.sha256(src.encode()).hexdigest()==row['original_sha256']
  assert (test/(variant+'.rs')).read_text()==src.replace('use crate::ssa::SSABuilder;','use super::SSABuilder;') and pin(test/(variant+'.rs'))['sha256']==row['harness_sha256']
 probe=root/'ir-comparison';proof=read(probe/'result.json');assert read(probe/'build.json')['exit_code']==read(probe/'test.json')['exit_code']==0
 assert read(probe/'test.json')['binary_sha256']==products[label+'/ir-comparison/probe']['sha256']
 cases=[json.loads(x) for x in (probe/'cases.jsonl').read_text().splitlines()];guards=[x for x in cases if x['case']=='guard'];other=[x for x in cases if x['case']!='guard']
 assert len(cases)==proof['paired_cases']==304 and len(guards)==144 and len(other)==160
 assert all(x['late_identical'] for x in guards) and all(x['identical'] for x in other)
 assert proof['cases_sha256']==pin(probe/'cases.jsonl')['sha256'] and proof['total_compiled_function_instances']==752
 old_differences=dict(compacted_ir=sum(x['reference']['ir']!=x['old_early']['ir'] for x in guards),machine=sum(x['reference']['machine']!=x['old_early']['machine'] for x in guards),any=sum(x['reference']!=x['old_early'] for x in guards))
 assert old_differences==dict(compacted_ir=87,machine=30,any=87)
 pproof=read(probe/'production-prefix-proof.json');marker='#[cfg(test)]\nmod tests'
 snapshot=probe/'probe-candidate.rs' if label=='pending-only' else root/'probe-candidate-before-extra-tests.rs'
 assert snapshot.read_text().split(marker)[0]==new.split(marker)[0]
 assert pproof['production_prefix_sha256']==hashlib.sha256(new.split(marker)[0].encode()).hexdigest()
 if label=='pending-only':assert pproof['current_full_source_sha256']==pin(root/'candidate.rs')['sha256'] and pproof['probe_full_source_sha256']==pin(snapshot)['sha256']
 else:assert pproof['identical_production_prefix'] and pproof['candidate_sha256']==pin(root/'candidate.rs')['sha256'] and pproof['probe_candidate_sha256']==pin(snapshot)['sha256']
 old_source=root/'old-early-forwarding.rs';old_pin=state['old_early_source'];assert pin(old_source)['sha256']==old_pin['sha256']
 assert hashlib.sha1(f'blob {old_source.stat().st_size}\0'.encode()+old_source.read_bytes()).hexdigest()==old_pin['git_blob']
 if label=='pending-only':
  failed=root/'ir-comparison-first-attempt';assert read(failed/'build.json')['exit_code']==1 and 'error[E0282]' in (failed/'build.stderr.log').read_text()
 decision=read(root/'decision.json');trial=dict(label=label,source_base=raw['base_commit'],source_patch_sha256=raw['patch_sha256'],compiler_binary_sha256=binaries,check=check,build=build,focused_test_count=count,focused_test=read(test/'test.json'),ir_comparison=proof,old_early_post_compaction_differences=old_differences,decision=decision)
 if label=='pending-only':
  assert decision['decision']=='superseded_without_primary_timing' and not (root/'cohort.json').exists();trials.append(trial);continue
 flags=read(root/'runtime-flags.json');wanted=dict(flags,MECH_COMPACT_COMPILE_THREADS='2');assert len(flags)==61 and read(root/'reference-pins.json')==expected
 for name,item in expected.items():assert pin(root/'reference'/name)==item
 order=[('control','control-1'),('candidate','candidate-1'),('candidate','candidate-2'),('control','control-2'),('candidate','candidate-3'),('control','control-3'),('control','control-4'),('candidate','candidate-4')]
 rows=[];screens=[]
 for variant,name in [('control','control-screen'),('candidate','candidate-screen')]+order:
  d=root/name;command=read(root/(name+'-command.json'));process=read(d/'process.json');comp=read(d/'compile.json');checks=read(d/'output-check.json')
  assert command['flags']==wanted and not command['profiling_excluded_from_primary'] and command['binary_sha256']==binaries[variant]
  assert process['exit_code']==0 and process['samples']==0 and process['sampling_error'] is None and process['elapsed_boundary']=='driver_start_to_process_wait_completion'
  assert process['elapsed_seconds']>comp['total_seconds']
  for filename,item in expected.items():assert pin(d/filename)==item and checks[filename]==dict(item,matches_current_control_output=True)
  row=dict(name=name,variant=variant,compile=comp,process=process,files=checks)
  if name.endswith('-screen'):screens.append(row);continue
  stamps=[json.loads(x) for x in (d/'stages.jsonl').read_text().splitlines()];elapsed=lambda prefix:next(x['elapsed'] for x in stamps if x['line'].startswith(prefix))
  for key,begin,end in [('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]:row[key]=elapsed(end)-elapsed(begin)
  row['compaction_seconds']=elapsed('compact-stage: CFG cleanup')-elapsed('compact-stage: compact values before=');row['cleanup_including_compaction_seconds']=row['cleanup_seconds']+row['compaction_seconds']
  for key,prefix in [('value_ids_before','compact-stage: compact values before='),('value_ids_after','compact-values: retained=')]:row[key]=int(next(x['line'] for x in stamps if x['line'].startswith(prefix)).split('=')[-1])
  for key,pattern in [('instructions',r'(\d+)  instructions retired'),('max_rss_bytes',r'(\d+)  maximum resident set size'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]:row[key]=int(re.search(pattern,(d/'stderr.log').read_text())[1])
  rows.append(row)
 assert rows==read(root/'cohort.json')
 fields=dict(compiler_seconds=lambda r:r['compile']['total_seconds'],whole_process_seconds=lambda r:r['process']['elapsed_seconds'])
 for phase in ['parse','catalog','frontend','artifact','encode','native']:fields[phase+'_seconds']=lambda r,p=phase:next(x['seconds'] for x in r['compile']['phases'] if x['phase']==p)
 for key in ['canonical_lowering_seconds','preparation_seconds','numeric_generation_seconds','source_cfg_seconds','cleanup_including_compaction_seconds','cleanup_seconds','compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:fields[key]=lambda r,k=key:r[k]
 nums=numerical(rows,fields);assert nums==read(root/'numerical-summary.json')
 fixtures=read(root/'fixture-results.json');assert len(fixtures)==14
 for row in fixtures:
  name=row['fixture'].split(':')[-1] if ':' in row['fixture'] else Path(row['fixture']).stem
  assert pin(root/'fixture-inputs'/(name+'.mec'))['sha256']==row['source_sha256'] and row['all_outputs_match'] and row['variants']['control']==row['variants']['candidate']
  for variant in ['control','candidate']:
   d=root/'fixtures'/name/variant;cmd=read(d/'command.json');assert cmd['flags']==wanted and cmd['binary_sha256']==binaries[variant]
   assert row['variants'][variant]['exit_code']==0 and len(row['variants'][variant]['files'])==4
   for filename,item in row['variants'][variant]['files'].items():assert pin(d/filename)==item
 links=read(root/'final-executable-results.json');assert len(links)==2
 for variant,row in zip(['control','candidate'],links):
  d=root/('link-'+variant);assert row['variant']==variant and row['exit_code']==0 and row['matches_complete_baseline_executable'] and not row['fresh_runtime_campaign']
  assert pin(d/'worker')==exe==dict(bytes=row['executable_bytes'],sha256=row['executable_sha256']) and read(d/'command.json')['environment']=={'ZERO_AR_DATE':'1'}
 assert decision['decision']=='rejected' and decision['production_source_restored'] and decision['canonical_tool_sha256']==control_binary
 assert not decision['primary_native_cohort_performed'] and not (root/'native-cohort.json').exists()
 pipeline=read(root/'qualification-pipeline.json');assert [x['stage'] for x in pipeline]==['screens','executable-gates','fixtures-object-cohort'] and all(x['state']=='complete' and x['exit_code']==0 for x in pipeline)
 for block in blocks(rows,fields):assert block['compiler_seconds']['mean_reduction_fraction']<0 and block['source_cfg_seconds']['mean_reduction_fraction']<0
 trial.update(numerical_summary=nums,balanced_blocks=blocks(rows,fields),preliminary_screens=screens,fixtures=14,final_links=links,value_compaction={v:sorted({(row['value_ids_before'],row['value_ids_after']) for row in rows if row['variant']==v}) for v in ['control','candidate']});trials.append(trial)
summary=dict(source_revision=state['source_revision'],output_hashes=expected,final_executable=exe,program_flags_count=61,measured_compile_threads=2,trials=trials,scope=[
 'Two late known-origin SSA prototypes keep original sealing times and CFG edges. Pending-only was built and tested, then superseded without primary program timing by the larger sealed-lookup shortcut. No performance rejection is inferred for the unmeasured prototype.',
 'Each prototype has304complete compacted IR,alias/type/definition,normalizedquery,sideeffect,unique-resolved-definition-set andmachine-byte pairs.144guardcases additionally compare the old early-sealing implementation after current compaction;87compacted IR and30machine-byte differences remain. Raw cached-variable enumeration order and duplicates are not equated.',
 'Known-origin qualification uses the retained source972 standard compiler and current Deflate/runtime. Eight primary source-to-Object observations use a serial ABBA/BAAB schedule;2workers and61programflags are common. No primary fullnative cohort is run because compiler and sourceCFG are already slower inbothblocks. Fixed adapter cached; compiler construction, first-use adapter build, screens, tests and archival excluded from primary timing. No heavy competing job overlaps primary cohorts.',
 'All4source/bytecode/Object/complete metadata files and both cached complete executable gates match. No new runtime speed campaign is claimed. Unknown values preserve original phi allocation order; no grammar/language change, weaker proof or scalar retirement. Complete compilation below ten seconds remains open.'
])
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';saved=packet/'summary.json'
if saved.exists():assert saved.read_text()==encoded
else:saved.write_text(encoded)
print(encoded,end='')
