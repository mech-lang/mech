from pathlib import Path
import json, statistics, subprocess, sys

root = Path('/private/tmp/mech-known-origin-ssa-20261115')
order = [('control','native-control-1'),('candidate','native-candidate-1'),('candidate','native-candidate-2'),('control','native-control-2'),('candidate','native-candidate-3'),('control','native-control-3'),('control','native-control-4'),('candidate','native-candidate-4')]
records = []
for variant, name in order:
    print('START', name, flush=True)
    subprocess.run([sys.executable, '/private/tmp/mech-known-origin-ssa-20261115/qualification-scripts/mech-run-native-inline-ssa-current-20261115.py', variant, name],check=True)
    row = json.loads((root/name/'result.json').read_text())
    row.update(name=name, primary_cohort=True)
    records.append(row)
    (root/'native-cohort.json').write_text(json.dumps(records,indent=2)+'\n')
fields=['source_to_executable_seconds','source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']
summary={}
for key in fields:
    values={v:[r[key] for r in records if r['variant']==v] for v in ['control','candidate']}
    values['mean_reduction_fraction']=1-statistics.mean(values['candidate'])/statistics.mean(values['control'])
    summary[key]=values
blocks=[]
for rows in [records[:4],records[4:]]:
    means={v:statistics.mean(r['source_to_executable_seconds'] for r in rows if r['variant']==v) for v in ['control','candidate']}
    means['mean_reduction_fraction']=1-means['candidate']/means['control']
    blocks.append(means)
out=dict(numerical_summary=summary,balanced_blocks=blocks,order=order,scope='Eight serial complete fresh source-to-executable compiles with the fixed current adapter cached; same61programflags plus2workers inboth. Frozenbfe3ee/source972 standard retained control versus known-origin SSA candidate; no PGO/nativeCPU flags. Separate from the eight source-to-Object primary runs and preliminary screens.')
(root/'native-numerical-summary.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2),flush=True)
