from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
repo=Path.cwd();root=Path('/private/tmp/mech-late-origin-ssa-20261115');state=json.loads((root/'source-state.json').read_text());source=repo/state['source_path'];patch=(root/'candidate.patch').read_bytes()
assert source.read_bytes()==(root/'candidate.rs').read_bytes() and subprocess.check_output(['git','diff','--binary','--',state['source_path']])==patch
assert subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()==[state['source_path']]
env=dict(os.environ,CARGO_TARGET_DIR='/private/tmp/mech-level12-compile-target',CARGO_INCREMENTAL='0');assert not env.get('RUSTFLAGS') and not env.get('CARGO_ENCODED_RUSTFLAGS')
(root/'rustc-version.txt').write_text(subprocess.check_output(['rustc','+nightly-2026-03-03','-Vv'],text=True))
for stage in ['check','build']:
    assert source.read_bytes()==(root/'candidate.rs').read_bytes()
    command=['cargo','+nightly-2026-03-03',stage,'--locked','--offline','--profile','compiler','-j4','--manifest-path','benchmarks/mech-deflate/native-profile/Cargo.toml','--bin','compile_profile','--message-format=json'];started=time.monotonic()
    with (root/('candidate-'+stage+'.jsonl')).open('w') as stdout,(root/('candidate-'+stage+'.stderr')).open('w') as stderr:completed=subprocess.run(command,cwd=repo,env=env,stdout=stdout,stderr=stderr)
    record=dict(command=command,base_commit=state['base_commit'],patch_sha256=hashlib.sha256(patch).hexdigest(),exit_code=completed.returncode,seconds=time.monotonic()-started,CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=env['CARGO_TARGET_DIR'])
    if completed.returncode==0 and stage=='build':
        rows=[json.loads(x) for x in (root/'candidate-build.jsonl').read_text().splitlines()];files=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='compile_profile' and r.get('executable')];assert len(files)==1;shutil.copy2(files[0],root/'candidate');record.update(binary=str(root/'candidate'),binary_sha256=hashlib.sha256((root/'candidate').read_bytes()).hexdigest())
    (root/('candidate-'+stage+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);assert completed.returncode==0
assert subprocess.check_output(['git','diff','--binary','--',state['source_path']])==patch
