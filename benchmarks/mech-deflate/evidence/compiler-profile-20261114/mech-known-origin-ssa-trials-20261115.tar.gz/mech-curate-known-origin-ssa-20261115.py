from pathlib import Path
import hashlib,json,shutil,subprocess
repo=Path.cwd();packet=Path('/private/tmp/mech-known-origin-ssa-packet-20261115');packet.mkdir(exist_ok=False)
roots={'pending-only':Path('/private/tmp/mech-late-origin-ssa-20261115'),'known-origin':Path('/private/tmp/mech-known-origin-ssa-20261115')}
pin=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
state=dict(source_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),trials={});excluded=[]
for label,root in roots.items():
 raw=json.loads((root/'source-state.json').read_text());decision=json.loads((root/'decision.json').read_text());state['trials'][label]=dict(source_base=raw['base_commit'],patch_sha256=raw['patch_sha256'],decision=decision['decision'])
 for p in sorted(root.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(root)
  if rel.as_posix() in ['control','candidate','focused/tests','ir-comparison/probe']:
   excluded.append(dict(path=label+'/'+rel.as_posix(),**pin(p)));continue
  dest=packet/label/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
 if (root/'fixture-results.json').exists():
  for row in json.loads((root/'fixture-results.json').read_text()):
   if row['fixture'].startswith('hosts/'):
    dest=packet/label/'fixture-inputs'/Path(row['fixture']).name;dest.parent.mkdir(exist_ok=True);dest.write_bytes(subprocess.check_output(['git','show',raw['base_commit']+':'+row['fixture']]))
state['old_early_source']=dict(source_revision='d4efd4465c5a8689016abd5b42e16f73e475af63',path='vendor/cranelift-frontend/src/ssa.rs',git_blob='4ba8166d666330eaa6f68ae11a40b8d4926122c5',sha256='42264be724c2343dcd82672a26da6df1c4b8b9c39ae88873de7b2065882f3b8c')
(packet/'source-state.json').write_text(json.dumps(state,indent=2)+'\n');(packet/'excluded-compiler-products.json').write_text(json.dumps(excluded,indent=2)+'\n')
base='bfe3ee58198a18c6039c638e434c7aa3800c4d5f';config=[]
paths=['.cargo/config.toml','Cargo.toml','Cargo.lock','benchmarks/mech-deflate/native-profile/Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.lock','benchmarks/mech-deflate/native-profile/compile_profile.rs','benchmarks/mech-deflate/native-profile/profile_compile.py','vendor/cranelift-frontend/Cargo.toml','vendor/cranelift-frontend/src/lib.rs','vendor/cranelift-frontend/src/variable.rs','vendor/cranelift-frontend/src/ssa.rs','vendor/cranelift-frontend/src/frontend.rs','hosts/gpu/src/native_artifact/program/compact/arrays.rs','hosts/gpu/src/native_artifact/program/compact/emit.rs','vendor/cranelift-codegen/src/ir/dfg.rs']
for name in paths:
 dest=packet/'source-config'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(subprocess.check_output(['git','show',base+':'+name]));config.append(dict(path=name,source_revision=base,**pin(dest)))
(packet/'source-config-pins.json').write_text(json.dumps(config,indent=2)+'\n')
capture=json.loads(Path('/private/tmp/mech-pr973-refresh-20261115/link/capture/link-command.json').read_text());inputs=[]
for at,row in enumerate(capture['inputs']):
 source=Path(row['retained_path']);wanted={k:row[k] for k in ['bytes','sha256']};assert pin(source)==wanted
 rel=Path('native-link-inputs')/(str(at)+'-'+source.name);dest=packet/rel;dest.parent.mkdir(exist_ok=True);shutil.copy2(source,dest);inputs.append(dict(source=row['source'],path=rel.as_posix(),**wanted))
(packet/'native-link-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
shutil.copytree('/private/tmp/mech-round2-planning-packet-20261114/licenses',packet/'licenses');validation=packet/'validation';validation.mkdir()
for suffix in ['.json','.archive.json']:shutil.copy2(repo/'benchmarks/mech-deflate/native-profile'/('scoped-source-apple-m3-20261115'+suffix),validation/('prior-qualified'+suffix))
for name in ['mech-build-late-origin-ssa-20261115.py','mech-test-late-origin-ssa-20261115.py','mech-make-late-origin-probe-20261115.py','mech-compare-late-origin-ssa-20261115.py','mech-build-known-origin-ssa-20261115.py','mech-test-known-origin-ssa-20261115.py','mech-make-known-origin-probe-20261115.py','mech-compare-known-origin-ssa-20261115.py','mech-qualify-known-origin-ssa-20261115.py','mech-curate-known-origin-ssa-20261115.py']:
 shutil.copy2(Path('/private/tmp')/name,packet/name)
shutil.copy2('/private/tmp/mech-replay-known-origin-ssa-20261115.py',packet/'replay.py')
(packet/'README.txt').write_text('''Late known-origin SSA work on the current Deflate/runtime.
Both prototypes keep original sealing time and CFG predecessors. The pending-only
prototype was built and tested then superseded, with no full program primary
timing; do not infer a speed regression for that unmeasured prototype. The larger
prototype also avoids allocation of already-known, immediately redundant sealed
join parameters. Unknown origins retain the exact original allocation path.
Each has304compacted IR/machine pairs and30or32unit tests.144guardcases also
compile old early-sealing SSA after current compaction:87IR and30machine-byte
differences remain, preserving the reason not to revive the old optimization.
All commands, snapshots, setup failures/corrections and adverse observations
remain. No grammar/language change, weakened proof/admission or scalar retirement.
Program runtime timings are not newly measured when complete images match.
Primary cohorts are serial, uncontended, with same61flags and2workers. Fixed
runtime adapter is cached. Compiler/test/probe executables are excluded and
hash-pinned; program executables and fixed native inputs are included. Pure
replay checks the saved data and recalculates measurements without recompiling.
''');print(packet)
