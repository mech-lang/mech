from pathlib import Path
root=Path('/private/tmp/mech-known-origin-ssa-20261115');s=Path('/private/tmp/mech-ssa-chain-roots-20261115/ir-comparison.rs').read_text()
s=s.replace('use cranelift_codegen::entity::EntityRef;','use cranelift_codegen::entity::EntityRef;\n#[allow(dead_code)] #[path="old-early-forwarding.rs"] mod old_early;')
s=s.replace(' fn values(&self,var:Variable)->Vec<Value>;',''' fn values(&self,var:Variable)->Vec<Value>;
 fn early()->bool;
 fn sealed(&self,b:Block)->bool;
 fn guard_seal(&mut self,b:Block,f:&mut Function,forward:bool)->Vec<Block>;''')
s=s.replace('($ty:path)=>{impl Builder for $ty {','($ty:path,$early:expr,$forward:ident)=>{impl Builder for $ty {')
s=s.replace('  fn values(&self,v:Variable)->Vec<Value>{self.values_for_var(v).collect()}','''  fn values(&self,v:Variable)->Vec<Value>{self.values_for_var(v).collect()}
  fn early()->bool{$early}
  fn sealed(&self,b:Block)->bool{self.is_sealed(b)}
  fn guard_seal(&mut self,b:Block,f:&mut Function,forward:bool)->Vec<Block>{if forward {self.$forward(b,f).instructions_added_to_blocks}else{self.seal_block(b,f).instructions_added_to_blocks}}''')
s=s.replace('builder!(ssa::SSABuilder);builder!(reference::SSABuilder);','builder!(ssa::SSABuilder,false,seal_block);builder!(reference::SSABuilder,false,seal_block);builder!(old_early::SSABuilder,true,seal_block_with_forwarding);')
a=s.index('fn snapshot<B:Builder>(');b=s.index('\nfn constant(',a)
snapshot=r'''fn snapshot<B:Builder>(mut f:Function,b:&B,vars:&[Variable],queries:Vec<u32>,effects:Vec<Vec<u32>>)->serde_json::Value {
 let flags=cranelift_codegen::settings::Flags::new(cranelift_codegen::settings::builder());cranelift_codegen::verify_function(&f,&flags).unwrap();
 let before=f.dfg.num_values();let mut dense=vec![None;before];let mut count=0u32;
 for (i,slot) in dense.iter_mut().enumerate(){if f.dfg.value_alias_dest_for_serialization(Value::new(i)).is_none(){*slot=Some(count);count+=1;}}
 let normalize=|v:Value|dense[f.dfg.resolve_aliases(v).as_u32() as usize].unwrap();
 let queries=queries.into_iter().map(|v|normalize(Value::from_u32(v))).collect::<Vec<_>>();
 let enumerations=vars.iter().map(|&var|{let mut values=b.values(var).into_iter().map(normalize).collect::<Vec<_>>();values.sort_unstable();values.dedup();values}).collect::<Vec<_>>();
 f.dfg.compact_values();assert_eq!(f.dfg.num_values(),count as usize);cranelift_codegen::verify_function(&f,&flags).unwrap();
 let aliases=(0..f.dfg.num_values()).map(|i|{let v=Value::new(i);(v.as_u32(),f.dfg.value_alias_dest_for_serialization(v).map(|v|v.as_u32()),f.dfg.resolve_aliases(v).as_u32(),f.dfg.value_type(v).to_string(),format!("{:?}",f.dfg.value_def(v)))}).collect::<Vec<_>>();
 let ir=f.display().to_string();
 use cranelift_codegen::settings::Configurable;let mut settings=cranelift_codegen::settings::builder();settings.set("opt_level","speed").unwrap();let isa=cranelift_codegen::isa::lookup_by_name("aarch64").unwrap().finish(cranelift_codegen::settings::Flags::new(settings)).unwrap();let mut context=cranelift_codegen::Context::for_function(f);let machine=context.compile(&*isa,&mut Default::default()).unwrap().buffer.data().to_vec();
 serde_json::json!({"ir":ir,"aliases_immediate_and_resolved_types_and_definitions":aliases,"queries":queries,"effects":effects,"unique_resolved_variable_definitions":enumerations,"machine":machine})
}
'''
s=s[:a]+snapshot+s[b:]
guards=r'''
fn guard_chain<B:Builder>(nvars:usize,n:usize,before:bool,status:bool,assign:bool,layout_seal:bool)->serde_json::Value {
 let mut f=Function::new();f.signature.params=vec![ir::AbiParam::new(I64);4];f.signature.returns.push(ir::AbiParam::new(I64));
 let mut blocks=Vec::new();let entry=f.dfg.make_block();let left=f.dfg.make_block();let right=f.dfg.make_block();let source=f.dfg.make_block();let error=f.dfg.make_block();blocks.extend([entry,left,right,source,error]);
 let mut b=B::default();for &block in &blocks{b.declare(block);}for _ in 0..4{f.dfg.append_block_param(entry,I64);}let error_status=f.dfg.append_block_param(error,I64);
 let args=f.dfg.block_params(entry).to_vec();let vars=(0..nvars).map(Variable::new).collect::<Vec<_>>();let mut queries=Vec::new();let mut effects:Vec<Vec<u32>>=Vec::new();
 f.layout.append_block(entry);let branch=FuncCursor::new(&mut f).at_bottom(entry).ins().brif(args[0],left,&[],right,&[]);b.pred(left,branch);b.pred(right,branch);effects.push(b.seal(entry,&mut f).iter().map(|v|v.as_u32()).collect());
 f.layout.append_block(source);let mut current=source;
 if before {for &var in &vars {let(v,e)=b.get(&mut f,var,I64,current);queries.push(v.as_u32());effects.push(e.iter().map(|v|v.as_u32()).collect());}}
 for ordinal in 0..n {
  let yes=f.dfg.make_block();let done=f.dfg.make_block();for block in [yes,done]{b.declare(block);blocks.push(block);}
  let branch=FuncCursor::new(&mut f).at_bottom(current).ins().brif(args[0],yes,&[],done,&[]);b.pred(yes,branch);b.pred(done,branch);
  if B::early(){effects.push(b.guard_seal(yes,&mut f,false).iter().map(|v|v.as_u32()).collect());}
  f.layout.append_block(yes);let mut c=FuncCursor::new(&mut f).at_bottom(yes);let old=c.ins().load(I64,ir::MemFlags::new(),args[3],0);let next=c.ins().iadd_imm(old,1);c.ins().store(ir::MemFlags::new(),next,args[3],0);
  if assign {let(v,e)=b.get(&mut f,vars[0],I64,yes);queries.push(v.as_u32());effects.push(e.iter().map(|v|v.as_u32()).collect());let next=FuncCursor::new(&mut f).at_bottom(yes).ins().iadd_imm(v,1);b.def(vars[0],next,yes);}
  let mut end=yes;
  if status {let good=f.dfg.make_block();b.declare(good);blocks.push(good);let status_value=FuncCursor::new(&mut f).at_bottom(yes).ins().iconst(I64,9);let branch=FuncCursor::new(&mut f).at_bottom(yes).ins().brif(args[1],error,&[status_value.into()],good,&[]);b.pred(error,branch);b.pred(good,branch);if B::early(){effects.push(b.guard_seal(good,&mut f,false).iter().map(|v|v.as_u32()).collect());}f.layout.append_block(good);end=good;}
  let jump=FuncCursor::new(&mut f).at_bottom(end).ins().jump(done,&[]);b.pred(done,jump);if B::early(){effects.push(b.guard_seal(done,&mut f,true).iter().map(|v|v.as_u32()).collect());}
  f.layout.append_block(done);current=done;
  for (index,&var) in vars.iter().enumerate(){let(v,e)=b.get(&mut f,var,I64,current);queries.push(v.as_u32());effects.push(e.iter().map(|v|v.as_u32()).collect());let mut c=FuncCursor::new(&mut f).at_bottom(current);let x=c.ins().iadd_imm(v,(ordinal+index) as i64);c.ins().store(ir::MemFlags::new(),x,args[3],8+(index*8) as i32);}
 }
 let(v,e)=b.get(&mut f,vars[0],I64,current);queries.push(v.as_u32());effects.push(e.iter().map(|v|v.as_u32()).collect());FuncCursor::new(&mut f).at_bottom(current).ins().return_(&[v]);
 for (block,value) in [(left,args[1]),(right,args[2])]{f.layout.append_block(block);for &var in &vars{b.def(var,value,block);}let jump=FuncCursor::new(&mut f).at_bottom(block).ins().jump(source,&[]);b.pred(source,jump);}
 f.layout.append_block(error);FuncCursor::new(&mut f).at_bottom(error).ins().return_(&[error_status]);
 let order=if layout_seal{f.layout.blocks().collect::<Vec<_>>()}else{blocks.clone()};for block in order{if !b.sealed(block){let e=b.seal(block,&mut f);effects.push(e.iter().map(|v|v.as_u32()).collect());}}
 // Early sealing has additional empty SideEffects observations; compare the
 // observable added-instruction lists while retaining the same query values.
 effects.retain(|items|!items.is_empty());snapshot(f,&b,&vars,queries,effects)
}
'''
s=s.replace('fn main(){',guards+r'''
fn main(){
 let mut old_differences=0;let mut cases=0;
 for nvars in [1,4,17]{for n in [1,8,64]{for before in [false,true]{for status in [false,true]{for assign in [false,true]{for layout_seal in [false,true]{
  let reference=guard_chain::<reference::SSABuilder>(nvars,n,before,status,assign,layout_seal);let late=guard_chain::<ssa::SSABuilder>(nvars,n,before,status,assign,layout_seal);let early=guard_chain::<old_early::SSABuilder>(nvars,n,before,status,assign,layout_seal);
  assert_eq!(reference,late,"late guard nvars={nvars} n={n} before={before} status={status} assign={assign} layout={layout_seal}");let equal=reference==early;if !equal{old_differences+=1;}
  println!("{}",serde_json::json!({"case":"guard","variables":nvars,"guards":n,"read_before_guard":before,"status_branch":status,"assignment":assign,"layout_sealing":layout_seal,"late_identical":true,"old_early_identical":equal,"reference":reference,"old_early":early}));cases+=1;
 }}}}}}
 eprintln!("guard cases={cases}, old early-sealing post-compaction differences={old_differences}");assert!(old_differences>0);
''',1)
(root/'ir-comparison.rs').write_text(s)
script=Path('/private/tmp/mech-compare-ssa-chain-roots-20261115.py').read_text().replace('mech-ssa-chain-roots-20261115','mech-known-origin-ssa-20261115').replace('ssa_chain_root_ir_comparison','late_origin_ssa_ir_comparison').replace('len(cases)==160','len(cases)==304').replace("all(x['identical'] for x in cases)","all(x.get('identical',x.get('late_identical')) for x in cases)")
# 3x3x2x2x2x2 = 144 guard triples plus the existing 160 independent cases.
script=script.replace('/private/tmp/mech-scoped-route-ranges-current-20261115/candidate-build.jsonl','/private/tmp/mech-owned-annotation-identity-20261115/candidate-build.jsonl')
Path('/private/tmp/mech-compare-known-origin-ssa-20261115.py').write_text(script)
print('generated304 post-compaction IR/machine cases,144also compare old earlysealing')
