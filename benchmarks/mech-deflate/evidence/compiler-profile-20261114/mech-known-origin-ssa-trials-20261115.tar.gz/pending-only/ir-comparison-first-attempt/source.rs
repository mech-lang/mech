extern crate alloc;
pub use cranelift_frontend::Variable;
#[allow(dead_code)]
#[path = "candidate.rs"] mod ssa;
#[allow(dead_code)]
#[path = "reference.rs"] mod reference;

use cranelift_codegen::cursor::{Cursor, FuncCursor};
use cranelift_codegen::entity::EntityRef;
#[allow(dead_code)] #[path="old-early-forwarding.rs"] mod old_early;
use cranelift_codegen::ir::{self, Function, InstBuilder, Value, Block, Inst, types::I64, condcodes::IntCC};
trait Builder: Default {
 fn declare(&mut self, block:Block);
 fn pred(&mut self, block:Block, inst:Inst);
 fn def(&mut self, var:Variable,value:Value,block:Block);
 fn get(&mut self,func:&mut Function,var:Variable,ty:ir::Type,block:Block)->(Value,Vec<Block>);
 fn seal(&mut self,block:Block,func:&mut Function)->Vec<Block>;
 fn values(&self,var:Variable)->Vec<Value>;
 fn early()->bool;
 fn sealed(&self,b:Block)->bool;
 fn guard_seal(&mut self,b:Block,f:&mut Function,forward:bool)->Vec<Block>;
}
macro_rules! builder {
 ($ty:path,$early:expr,$forward:ident)=>{impl Builder for $ty {
  fn declare(&mut self,b:Block){self.declare_block(b)}
  fn pred(&mut self,b:Block,i:Inst){self.declare_block_predecessor(b,i)}
  fn def(&mut self,v:Variable,x:Value,b:Block){self.def_var(v,x,b)}
  fn get(&mut self,f:&mut Function,v:Variable,t:ir::Type,b:Block)->(Value,Vec<Block>){let(x,e)=self.use_var(f,v,t,b);(x,e.instructions_added_to_blocks)}
  fn seal(&mut self,b:Block,f:&mut Function)->Vec<Block>{self.seal_block(b,f).instructions_added_to_blocks}
  fn values(&self,v:Variable)->Vec<Value>{self.values_for_var(v).collect()}
  fn early()->bool{$early}
  fn sealed(&self,b:Block)->bool{self.is_sealed(b)}
  fn guard_seal(&mut self,b:Block,f:&mut Function,forward:bool)->Vec<Block>{if forward {self.$forward(b,f).instructions_added_to_blocks}else{self.seal_block(b,f).instructions_added_to_blocks}}
 }};
}
builder!(ssa::SSABuilder,false,seal_block);builder!(reference::SSABuilder,false,seal_block);builder!(old_early::SSABuilder,true,seal_block_with_forwarding);
fn observe<B:Builder>(offset:usize,n:usize,looped:bool,reverse:bool)->serde_json::Value {
 let mut f=Function::new();f.signature.returns.push(ir::AbiParam::new(I64));
 for _ in 0..offset {f.dfg.make_block();}
 let blocks=(0..n+1).map(|_|f.dfg.make_block()).collect::<Vec<_>>();
 let mut b=B::default();let vars=[Variable::new(0),Variable::new(1),Variable::new(2)];
 for &block in &blocks {f.layout.append_block(block);b.declare(block);}
 let mut queries=Vec::new();let mut effects=Vec::new();
 {
  let mut c=FuncCursor::new(&mut f).at_bottom(blocks[0]);
  for (i,&v) in vars.iter().enumerate(){let x=c.ins().iconst(I64,i as i64+1);b.def(v,x,blocks[0]);}
  let inst=c.ins().jump(blocks[1],&[]);b.pred(blocks[1],inst);
 }
 for i in 1..n {
  let mut values=Vec::new();
  for &var in &vars {let(x,e)=b.get(&mut f,var,I64,blocks[i]);queries.push(x.as_u32());effects.push(e.iter().map(|x|x.as_u32()).collect::<Vec<_>>());values.push(x);}
  let mut c=FuncCursor::new(&mut f).at_bottom(blocks[i]);
  if i%3==0 {let x=c.ins().iadd_imm(values[0],(i%11) as i64);b.def(vars[0],x,blocks[i]);}
  if i%7==0 {let x=c.ins().iadd(values[0],values[1]);b.def(vars[1],x,blocks[i]);}
  if i==n-1 && looped {
   let cond=c.ins().icmp_imm(IntCC::SignedLessThan,values[0],47);
   let inst=c.ins().brif(cond,blocks[1],&[],blocks[n],&[]);b.pred(blocks[1],inst);b.pred(blocks[n],inst);
  } else {let inst=c.ins().jump(blocks[i+1],&[]);b.pred(blocks[i+1],inst);}
 }
 let(x,e)=b.get(&mut f,vars[0],I64,blocks[n]);queries.push(x.as_u32());effects.push(e.iter().map(|x|x.as_u32()).collect::<Vec<_>>());FuncCursor::new(&mut f).at_bottom(blocks[n]).ins().return_(&[x]);
 let mut order=blocks.clone();if reverse{order.reverse();}
 for block in order {effects.push(b.seal(block,&mut f).iter().map(|x|x.as_u32()).collect::<Vec<_>>());}
 for &block in blocks.iter().rev() {for &var in &vars {let(x,e)=b.get(&mut f,var,I64,block);queries.push(x.as_u32());effects.push(e.iter().map(|x|x.as_u32()).collect::<Vec<_>>());}}
 snapshot(f,&b,&vars,queries,effects)
}

fn snapshot<B:Builder>(mut f:Function,b:&B,vars:&[Variable],queries:Vec<u32>,effects:Vec<Vec<u32>>)->serde_json::Value {
 let flags=cranelift_codegen::settings::Flags::new(cranelift_codegen::settings::builder());cranelift_codegen::verify_function(&f,&flags).unwrap();
 let before=f.dfg.num_values();let mut dense=vec![None;before];let mut count=0u32;
 for (i,slot) in dense.iter_mut().enumerate(){if f.dfg.value_alias_dest_for_serialization(Value::new(i)).is_none(){*slot=Some(count);count+=1;}}
 let normalize=|v:Value|dense[f.dfg.resolve_aliases(v).as_u32() as usize].unwrap();
 let queries=queries.into_iter().map(|v|normalize(Value::from_u32(v))).collect::<Vec<_>>();
 let enumerations=vars.iter().map(|&var|{let mut values=b.values(var).into_iter().map(normalize).collect::<Vec<_>>();values.sort_unstable();values.dedup();values}).collect::<Vec<_>>();
 f.dfg.compact_values();assert_eq!(f.dfg.num_values(),count as usize);cranelift_codegen::verify_function(&f,&flags).unwrap();
 let aliases=(0..f.dfg.num_values()).map(|i|{let v=Value::new(i);(v.as_u32(),f.dfg.value_alias_dest_for_serialization(v).map(|v|v.as_u32()),f.dfg.resolve_aliases(v).as_u32(),f.dfg.value_type(v).to_string(),format!("{:?}",f.dfg.value_def(v)))}).collect::<Vec<_>>();
 let ir=f.display().to_string();
 use cranelift_codegen::settings::Configurable;let mut settings=cranelift_codegen::settings::builder();settings.set("opt_level","speed").unwrap();let isa=cranelift_codegen::isa::lookup_by_name("aarch64").unwrap().finish(cranelift_codegen::settings::Flags::new(settings)).unwrap();let mut context=cranelift_codegen::Context::for_function(f);let machine=context.compile(&*isa,&mut Default::default()).unwrap().buffer.data().to_vec();
 serde_json::json!({"ir":ir,"aliases_immediate_and_resolved_types_and_definitions":aliases,"queries":queries,"effects":effects,"unique_resolved_variable_definitions":enumerations,"machine":machine})
}

fn constant(c:&mut FuncCursor<'_>,ty:ir::Type,value:i64)->Value {
 if ty==ir::types::F64 {c.ins().f64const(ir::immediates::Ieee64::with_float(value as f64))}
 else if ty==ir::types::F32 {c.ins().f32const(ir::immediates::Ieee32::with_float(value as f32))}
 else {c.ins().iconst(ty,value)}
}
fn batch<B:Builder>(offset:usize,n:usize,mode:usize,reverse:bool,manual:bool,mixed:bool)->serde_json::Value {
 let mut f=Function::new();f.signature.returns.push(ir::AbiParam::new(I64));for _ in 0..offset {f.dfg.make_block();}
 let blocks=(0..4).map(|_|f.dfg.make_block()).collect::<Vec<_>>();let [entry,a,b,join]=blocks.as_slice()else{unreachable!()};let(entry,a,b,join)=(*entry,*a,*b,*join);
 let target=if mode==0{join}else{a};let manual_value=manual.then(||f.dfg.append_block_param(target,I64));
 let vars=(0..n).map(Variable::new).collect::<Vec<_>>();let types=(0..n).map(|i|if mixed {[I64,ir::types::I32,ir::types::F64,ir::types::F32][i%4]}else{I64}).collect::<Vec<_>>();
 let mut builder=B::default();for &block in &blocks {f.layout.append_block(block);builder.declare(block);}
 let mut queries=Vec::new();let mut effects=Vec::new();let mut initial=Vec::new();
 {
  let mut c=FuncCursor::new(&mut f).at_bottom(entry);
  for i in 0..n {let v=constant(&mut c,types[i],i as i64+1);builder.def(vars[i],v,entry);initial.push(v);}
  if mode==0 {let cond=c.ins().iconst(ir::types::I8,1);let branch=c.ins().brif(cond,a,&[],b,&[]);builder.pred(a,branch);builder.pred(b,branch);}
  else if mode==1 {let args=manual_value.map(|_|vec![initial[0].into()]).unwrap_or_default();let branch=c.ins().jump(a,&args);builder.pred(a,branch);}
  else {c.ins().return_(&[initial[0]]);}
 }
 if mode==0 {
  for block in [a,b] {
   let mut c=FuncCursor::new(&mut f).at_bottom(block);
   for i in 0..n {let v=if block==b && i%64==31 {constant(&mut c,types[i],1000+i as i64)}else{initial[i]};builder.def(vars[i],v,block);}
   let args=manual_value.map(|_|vec![initial[0].into()]).unwrap_or_default();let branch=c.ins().jump(join,&args);builder.pred(join,branch);
  }
  let mut order=(0..n).collect::<Vec<_>>();if reverse{order.reverse();}let mut last=initial[0];
  for i in order {let(v,e)=builder.get(&mut f,vars[i],types[i],join);queries.push(v.as_u32());effects.push(e.iter().map(|v|v.as_u32()).collect());if i==0{last=v;}}
  let mut c=FuncCursor::new(&mut f).at_bottom(join);let result=if let Some(manual)=manual_value{c.ins().iadd(manual,last)}else{last};c.ins().return_(&[result]);
 } else {
  let mut header=Vec::new();for i in 0..n {let(v,e)=builder.get(&mut f,vars[i],I64,a);queries.push(v.as_u32());effects.push(e.iter().map(|v|v.as_u32()).collect());header.push(v);}
  let local={let mut c=FuncCursor::new(&mut f).at_bottom(a);let local=c.ins().iconst(I64,0);let cond=c.ins().iconst(ir::types::I8,1);let branch=c.ins().brif(cond,b,&[],join,&[]);builder.pred(b,branch);builder.pred(join,branch);local};
  {
   let mut c=FuncCursor::new(&mut f).at_bottom(b);
   for i in 0..n {let value=match i%11 {0=>header[(i+1)%n],1=>header[i],2=>header[i-1],3 if manual=>manual_value.unwrap(),_=>if mode==2{local}else{initial[i]}};builder.def(vars[i],value,b);}
   let args=manual_value.map(|_|vec![(if mode==2{local}else{initial[0]}).into()]).unwrap_or_default();let branch=c.ins().jump(a,&args);builder.pred(a,branch);
  }
  FuncCursor::new(&mut f).at_bottom(join).ins().return_(&[header[0]]);
 }
 let mut order=blocks.clone();if reverse{order.reverse();}for block in order {effects.push(builder.seal(block,&mut f).iter().map(|v|v.as_u32()).collect());}
 for &block in &blocks {for i in 0..n {let(v,e)=builder.get(&mut f,vars[i],types[i],block);queries.push(v.as_u32());effects.push(e.iter().map(|v|v.as_u32()).collect());}}
 snapshot(f,&builder,&vars,queries,effects)
}

fn eager_chain<B:Builder>(offset:usize,n:usize,mode:usize,changed:bool,mixed:bool)->serde_json::Value {
 let mut f=Function::new();f.signature.returns.push(ir::AbiParam::new(I64));for _ in 0..offset {f.dfg.make_block();}
 let blocks=(0..n).map(|_|f.dfg.make_block()).collect::<Vec<_>>();let vars=(0..64).map(Variable::new).collect::<Vec<_>>();
 let types=(0..64).map(|i|if mixed {[I64,ir::types::I32,ir::types::F64,ir::types::F32][i%4]}else{I64}).collect::<Vec<_>>();
 let mut b=B::default();for &block in &blocks {f.layout.append_block(block);b.declare(block);}
 let mut initial=Vec::new();{let mut c=FuncCursor::new(&mut f).at_bottom(blocks[0]);for i in 0..64 {let v=constant(&mut c,types[i],i as i64+1);b.def(vars[i],v,blocks[0]);initial.push(v);}}
 let mut queries=Vec::new();let mut effects=Vec::new();let mut pending=Vec::new();
 for (i,&block) in blocks.iter().enumerate() {
  if i>0 && mode>0 && i%11==0 {pending.push(block);}else{effects.push(b.seal(block,&mut f).iter().map(|v|v.as_u32()).collect());}
  // Late first uses traverse long chains; earlier queries also test cached hits.
  if i%17==0 || i+1==n {for k in 0..64 {if k%3!=0 && i+1!=n {continue;}let(v,e)=b.get(&mut f,vars[k],types[k],block);queries.push(v.as_u32());effects.push(e.iter().map(|v|v.as_u32()).collect());}}
  if i>0 && i%13==0 {
   let mut c=FuncCursor::new(&mut f).at_bottom(block);
   for k in 0..16 {let v=if changed {constant(&mut c,types[k],1000+(i*64+k) as i64)}else{initial[k]};b.def(vars[k],v,block);}
  }
  if i+1<n {let inst=FuncCursor::new(&mut f).at_bottom(block).ins().jump(blocks[i+1],&[]);b.pred(blocks[i+1],inst);}
  else {let(v,e)=b.get(&mut f,vars[0],I64,block);queries.push(v.as_u32());effects.push(e.iter().map(|v|v.as_u32()).collect());FuncCursor::new(&mut f).at_bottom(block).ins().return_(&[v]);}
 }
 if mode==2 {pending.reverse();}for block in pending {effects.push(b.seal(block,&mut f).iter().map(|v|v.as_u32()).collect());}
 for &block in blocks.iter().rev().step_by(7) {for k in 0..64 {let(v,e)=b.get(&mut f,vars[k],types[k],block);queries.push(v.as_u32());effects.push(e.iter().map(|v|v.as_u32()).collect());}}
 snapshot(f,&b,&vars,queries,effects)
}


fn guard_chain<B:Builder>(nvars:usize,n:usize,before:bool,status:bool,assign:bool,layout_seal:bool)->serde_json::Value {
 let mut f=Function::new();f.signature.params=vec![ir::AbiParam::new(I64);4];f.signature.returns.push(ir::AbiParam::new(I64));
 let mut blocks=Vec::new();let entry=f.dfg.make_block();let left=f.dfg.make_block();let right=f.dfg.make_block();let source=f.dfg.make_block();let error=f.dfg.make_block();blocks.extend([entry,left,right,source,error]);
 let mut b=B::default();for &block in &blocks{b.declare(block);}for _ in 0..4{f.dfg.append_block_param(entry,I64);}let error_status=f.dfg.append_block_param(error,I64);
 let args=f.dfg.block_params(entry).to_vec();let vars=(0..nvars).map(Variable::new).collect::<Vec<_>>();let mut queries=Vec::new();let mut effects=Vec::new();
 f.layout.append_block(entry);let branch=FuncCursor::new(&mut f).at_bottom(entry).ins().brif(args[0],left,&[],right,&[]);b.pred(left,branch);b.pred(right,branch);effects.push(b.seal(entry,&mut f).iter().map(|v|v.as_u32()).collect());
 f.layout.append_block(source);let mut current=source;
 if before {for &var in &vars {let(v,e)=b.get(&mut f,var,I64,current);queries.push(v.as_u32());effects.push(e.iter().map(|v|v.as_u32()).collect());}}
 for ordinal in 0..n {
  let yes=f.dfg.make_block();let done=f.dfg.make_block();for block in [yes,done]{b.declare(block);blocks.push(block);}
  let branch=FuncCursor::new(&mut f).at_bottom(current).ins().brif(args[0],yes,&[],done,&[]);b.pred(yes,branch);b.pred(done,branch);
  if B::early(){effects.push(b.guard_seal(yes,&mut f,false).iter().map(|v|v.as_u32()).collect());}
  f.layout.append_block(yes);let mut c=FuncCursor::new(&mut f).at_bottom(yes);let old=c.ins().load(I64,ir::MemFlags::new(),args[3],0);let next=c.ins().iadd_imm(old,1);c.ins().store(ir::MemFlags::new(),next,args[3],0);
  if assign {let(v,e)=b.get(&mut f,vars[0],I64,yes);queries.push(v.as_u32());effects.push(e.iter().map(|v|v.as_u32()).collect());let next=FuncCursor::new(&mut f).at_bottom(yes).ins().iadd_imm(v,1);b.def(vars[0],next,yes);}
  let mut end=yes;
  if status {let good=f.dfg.make_block();b.declare(good);blocks.push(good);let status_value=FuncCursor::new(&mut f).at_bottom(yes).ins().iconst(I64,9);let branch=FuncCursor::new(&mut f).at_bottom(yes).ins().brif(args[1],error,&[status_value.into()],good,&[]);b.pred(error,branch);b.pred(good,branch);if B::early(){effects.push(b.guard_seal(good,&mut f,false).iter().map(|v|v.as_u32()).collect());}f.layout.append_block(good);end=good;}
  let jump=FuncCursor::new(&mut f).at_bottom(end).ins().jump(done,&[]);b.pred(done,jump);if B::early(){effects.push(b.guard_seal(done,&mut f,true).iter().map(|v|v.as_u32()).collect());}
  f.layout.append_block(done);current=done;
  for (index,&var) in vars.iter().enumerate(){let(v,e)=b.get(&mut f,var,I64,current);queries.push(v.as_u32());effects.push(e.iter().map(|v|v.as_u32()).collect());let mut c=FuncCursor::new(&mut f).at_bottom(current);let x=c.ins().iadd_imm(v,(ordinal+index) as i64);c.ins().store(ir::MemFlags::new(),x,args[3],8+(index*8) as i32);}
 }
 let(v,e)=b.get(&mut f,vars[0],I64,current);queries.push(v.as_u32());effects.push(e.iter().map(|v|v.as_u32()).collect());FuncCursor::new(&mut f).at_bottom(current).ins().return_(&[v]);
 for (block,value) in [(left,args[1]),(right,args[2])]{f.layout.append_block(block);for &var in &vars{b.def(var,value,block);}let jump=FuncCursor::new(&mut f).at_bottom(block).ins().jump(source,&[]);b.pred(source,jump);}
 f.layout.append_block(error);FuncCursor::new(&mut f).at_bottom(error).ins().return_(&[error_status]);
 let order=if layout_seal{f.layout.blocks().collect::<Vec<_>>()}else{blocks.clone()};for block in order{if !b.sealed(block){let e=b.seal(block,&mut f);effects.push(e.iter().map(|v|v.as_u32()).collect());}}
 // Early sealing has additional empty SideEffects observations; compare the
 // observable added-instruction lists while retaining the same query values.
 effects.retain(|items|!items.is_empty());snapshot(f,&b,&vars,queries,effects)
}

fn main(){
 let mut old_differences=0;let mut cases=0;
 for nvars in [1,4,17]{for n in [1,8,64]{for before in [false,true]{for status in [false,true]{for assign in [false,true]{for layout_seal in [false,true]{
  let reference=guard_chain::<reference::SSABuilder>(nvars,n,before,status,assign,layout_seal);let late=guard_chain::<ssa::SSABuilder>(nvars,n,before,status,assign,layout_seal);let early=guard_chain::<old_early::SSABuilder>(nvars,n,before,status,assign,layout_seal);
  assert_eq!(reference,late,"late guard nvars={nvars} n={n} before={before} status={status} assign={assign} layout={layout_seal}");let equal=reference==early;if !equal{old_differences+=1;}
  println!("{}",serde_json::json!({"case":"guard","variables":nvars,"guards":n,"read_before_guard":before,"status_branch":status,"assignment":assign,"layout_sealing":layout_seal,"late_identical":true,"old_early_identical":equal,"reference":reference,"old_early":early}));cases+=1;
 }}}}}}
 eprintln!("guard cases={cases}, old early-sealing post-compaction differences={old_differences}");assert!(old_differences>0);

 for offset in [0,4096,100000] {for n in [65,257] {for mode in 0..3 {for changed in [false,true] {for mixed in [false,true] {
 let old=eager_chain::<reference::SSABuilder>(offset,n,mode,changed,mixed);let new=eager_chain::<ssa::SSABuilder>(offset,n,mode,changed,mixed);assert_eq!(old,new,"eager offset={offset} n={n} mode={mode} changed={changed} mixed={mixed}");
 println!("{}",serde_json::json!({"case":"eager-chain","offset":offset,"blocks":n,"mode":mode,"changed":changed,"mixed_types":mixed,"identical":true,"observation":new}));
 }}}}}
 for offset in [0,4096,100000] {for n in [65,257] {for looped in [false,true] {for reverse in [false,true] {
  let old=observe::<reference::SSABuilder>(offset,n,looped,reverse);let new=observe::<ssa::SSABuilder>(offset,n,looped,reverse);assert_eq!(old,new,"chain offset={offset} n={n} looped={looped} reverse={reverse}");
  println!("{}",serde_json::json!({"case":"chain","offset":offset,"blocks":n,"looped":looped,"reverse_sealing":reverse,"identical":true,"observation":new}));
 }}}}
 for offset in [0,100000] {for n in [64,257] {for mode in 0..3 {for reverse in [false,true] {for manual in [false,true] {for mixed in [false,true] {
  if mode!=0 && mixed {continue;}
  let old=batch::<reference::SSABuilder>(offset,n,mode,reverse,manual,mixed);let new=batch::<ssa::SSABuilder>(offset,n,mode,reverse,manual,mixed);assert_eq!(old,new,"batch offset={offset} n={n} mode={mode} reverse={reverse} manual={manual} mixed={mixed}");
  println!("{}",serde_json::json!({"case":"batch","offset":offset,"variables":n,"mode":mode,"reverse_sealing":reverse,"manual_parameter":manual,"mixed_types":mixed,"identical":true,"observation":new}));
 }}}}}}
}
