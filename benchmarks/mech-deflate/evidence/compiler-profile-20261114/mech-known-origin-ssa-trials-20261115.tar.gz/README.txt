Late known-origin SSA work on the current Deflate/runtime.
Both prototypes keep original sealing time and CFG predecessors. The pending-only
prototype was built and tested then superseded, with no full program primary
timing; do not infer a speed regression for that unmeasured prototype. The larger
prototype also avoids allocation of already-known, immediately redundant sealed
join parameters. Unknown origins retain the exact original allocation path.
Each has304compacted IR/machine pairs and30or32unit tests.144guardcases also
compile old early-sealing SSA after current compaction:87IR and30machine-byte
differences remain, preserving the reason not to revive the old optimization.
All commands, snapshots, setup failures/corrections and adverse observations
remain. No grammar/language change, weakened proof/admission or scalar retirement.
Program runtime timings are not newly measured when complete images match.
Primary cohorts are serial, uncontended, with same61flags and2workers. Fixed
runtime adapter is cached. Compiler/test/probe executables are excluded and
hash-pinned; program executables and fixed native inputs are included. Pure
replay checks the saved data and recalculates measurements without recompiling.
