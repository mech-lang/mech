Integrated phase compilation workers, 2026-11-14.
This is the real Deflate compilation path, enabled by the internal scheduling
setting MECH_COMPACT_COMPILE_THREADS=2. Default0 retains serial compilation;
one-worker and serial paths are also byte-gated. Program codegen flags remain61.
Persistent workers own Contexts and machine compilation. The coordinator owns
checked IR construction/cleanup, shared DenseTables, decisions and all Object
events. A RecordedModule stages later declarations/data/functions and replays
them after the earlier definition. Reports use actual compiled code/stack data.
Two focused tests perform24 complete ordered Object comparisons (including
libcalls, repeated/anonymous declarations and data relocations) and original
earlier-publication-error precedence. Their first dependency-pinning attempt
finds a baseline rlib removed by Cargo rebuilding; no tests ran in that attempt.
The successful tests use the exact production module and real NativeCompileError
type, with production-equivalent backend error construction in a tiny harness.
Fourteen paired fixture programs, all full source/bytecode/Object/metadata and
final executable bytes match. A two-worker diagnostic queues340 real functions.
Eight source-to-Object ABBA/BAAB runs and eight complete source-to-executable
ABBA/BAAB runs are separate cohorts. The latter include the final link with a
frozen cached adapter. First-use adapter building is excluded. Preliminary
screens and the reversed-direction single full-executable pilot pair remain;
neither is pooled into primary means. Native per-build receipts inherit the
one-shot harness's primary_cohort:false; native-cohort.json records selected
cohort membership explicitly. No timings are rewritten.
Every raw observation, adverse phase/memory counter, exact source/patch,
test/fixture output, program Object, full executable and frozen native-link input
is included. Compiler/test executables are excluded and SHA-pinned. Pure replay
checks saved source/bytes/measurements without rerunning builds or timings.
Main parsing, frontend, preparation and main CFG/cleanup remain serial; this
does not establish the requested sub-ten-second complete compilation goal.
