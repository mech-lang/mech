extern crate alloc;
mod native_artifact {
    pub use mech_gpu::native_artifact::NativeCompileError;
    pub mod compiler {
        pub fn backend(error: impl std::fmt::Display) -> super::NativeCompileError {
            super::NativeCompileError::Backend(error.to_string())
        }
    }
}
#[path = "/Users/cim310/.codex/worktrees/level12-compile-profile/mech/hosts/gpu/src/native_artifact/program/compact/compile_jobs.rs"]
mod compile_jobs;
