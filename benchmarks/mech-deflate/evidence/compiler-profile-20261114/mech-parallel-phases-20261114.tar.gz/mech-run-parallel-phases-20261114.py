from pathlib import Path
import hashlib, json, os, subprocess, sys

root = Path('/private/tmp/mech-parallel-phases-20261114')
variant, name = sys.argv[1:3]
threads = int(sys.argv[3]) if len(sys.argv) > 3 else None
profile = len(sys.argv) > 4 and sys.argv[4] == 'profile'
assert threads in [None, 0, 1, 2, 4]
flags = json.loads((root/'runtime-flags.json').read_text())
assert len(flags) == 61 and flags['MECH_COMPACT_REUSE_OVERWRITTEN_RESULT'] == '1'
env = {k:v for k,v in os.environ.items() if not k.startswith('MECH_')}
env.update(flags)
if threads is not None: env['MECH_COMPACT_COMPILE_THREADS'] = str(threads)
if profile: env['MECH_PROFILE_COMPILE_JOBS'] = '1'
assert not (root/name).exists()
command = [sys.executable, 'benchmarks/mech-deflate/native-profile/profile_compile.py', str(root/variant), 'benchmark', str(root/name), 'compact']
(root/(name+'-command.json')).write_text(json.dumps({'command':command,'flags':{k:v for k,v in env.items() if k.startswith('MECH_')},'binary_sha256':hashlib.sha256((root/variant).read_bytes()).hexdigest(),'compile_threads':threads,'program_flags_count':len(flags),'profiling_excluded_from_primary':profile},indent=2)+'\n')
completed = subprocess.run(command,env=env)
assert completed.returncode == 0
checks = {}
for n in ['source.mec','program.mecb','program.o','metadata.json']:
    data = (root/name/n).read_bytes()
    checks[n] = {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'matches_current_control_output':data==(root/'reference'/n).read_bytes()}
(root/name/'output-check.json').write_text(json.dumps(checks,indent=2)+'\n')
print('OUTPUTS',name,json.dumps(checks),flush=True)
assert all(r['matches_current_control_output'] for r in checks.values()), 'parallel candidate changed a generated program output'
