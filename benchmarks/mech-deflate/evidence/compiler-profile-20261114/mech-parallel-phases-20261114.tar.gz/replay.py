from pathlib import Path
import hashlib, json, re, statistics

root = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_text())
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
state = read(root / 'source-state.json')
excluded = {r['path']: r for r in read(root / 'excluded-compiler-products.json')}
prior = read(root / 'validation/prior-qualified.json')
assert pin(root / 'validation/prior-qualified.json')['sha256'] == read(root / 'validation/prior-qualified.archive.json')['replay_sha256']
flags = read(root / 'runtime-flags.json')
assert len(flags) == 61 and flags['MECH_COMPACT_REUSE_OVERWRITTEN_RESULT'] == '1'
build = read(root / 'candidate-build.json')
assert build['exit_code'] == 0 and build['head'] == state['base_commit']
assert pin(root / 'candidate.patch')['sha256'] == build['patch_sha256']
assert excluded['candidate']['sha256'] == build['binary_sha256']
assert excluded['control']['sha256'] == prior['compiler_binary_sha256']['candidate']
def apply_source_patch(base,patch):
 lines=base.splitlines(keepends=True);out=[];cursor=0;diff=patch.splitlines(keepends=True);assert sum(line.startswith('diff --git ') for line in diff)==1
 i=0
 while i<len(diff):
  match=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',diff[i])
  if not match:i+=1;continue
  at=int(match[1]) if int(match[2] or 1)==0 else int(match[1])-1;assert at>=cursor;out.extend(lines[cursor:at]);cursor=at;old_count=0;new_count=0;i+=1
  while i<len(diff) and not diff[i].startswith('@@ '):
   line=diff[i];tag=line[:1];assert tag in [' ','+','-']
   if tag in [' ','-']:assert lines[cursor]==line[1:];cursor+=1;old_count+=1
   if tag in [' ','+']:out.append(line[1:]);new_count+=1
   i+=1
  assert old_count==int(match[2] or 1) and new_count==int(match[4] or 1)
 out.extend(lines[cursor:]);return ''.join(out)
patch = (root/'candidate.patch').read_text()
names = []
for block in patch.split('diff --git ')[1:]:
    block = 'diff --git ' + block
    match = re.match(r'diff --git a/(.+) b/\1\n', block)
    assert match
    name = match[1]; names.append(name)
    assert apply_source_patch((root/'source/control'/name).read_text() if (root/'source/control'/name).exists() else '', block) == (root/'source/candidate'/name).read_text()
assert set(names) == set(state['changed_paths']) and state['missing_control_paths'] == ['hosts/gpu/src/native_artifact/program/compact/compile_jobs.rs']
expected = prior['output_hashes']
assert read(root / 'reference-pins.json') == expected
for n, pinned in expected.items():
    assert pin(root / 'reference' / n) == pinned
order = [('control', 'control-1'), ('candidate', 'candidate-1'), ('candidate', 'candidate-2'), ('control', 'control-2'), ('candidate', 'candidate-3'), ('control', 'control-3'), ('control', 'control-4'), ('candidate', 'candidate-4')]
cohort = []
screens = []
for variant, name in [('control','control-screen'),('candidate','candidate-screen'),('candidate','single-worker-screen'),('candidate','serial-path-screen')] + order:
    d = root / name
    command = read(root / (name + '-command.json'))
    requested = command['compile_threads']
    wanted = dict(flags)
    if requested is not None: wanted['MECH_COMPACT_COMPILE_THREADS'] = str(requested)
    if command['profiling_excluded_from_primary']: wanted['MECH_PROFILE_COMPILE_JOBS'] = '1'
    assert command['flags'] == wanted and command['binary_sha256'] == excluded[variant]['sha256'] and command['program_flags_count'] == 61
    if not name.endswith('-screen'):
        assert not command['profiling_excluded_from_primary'] and requested == (2 if variant=='candidate' else None)
    if name in ['candidate-screen','single-worker-screen']:
        assert f'compact-compile-jobs: workers={requested} submitted=340' in (d/'stderr.log').read_text()
    process = read(d / 'process.json')
    assert process['exit_code'] == 0 and process['elapsed_boundary'] == 'driver_start_to_process_wait_completion'
    assert process['samples'] == 0 and process['sampling_error'] is None
    checks = read(d / 'output-check.json')
    for n, pinned in expected.items():
        assert pin(d / n) == pinned and checks[n] == dict(pinned, matches_current_control_output=True)
    row = dict(name=name, variant=variant, compile=read(d / 'compile.json'), process=process, files=checks)
    assert row['compile']['total_seconds'] < process['elapsed_seconds']
    if name.endswith('-screen'):
        screens.append(row)
        continue
    stamps = [json.loads(line) for line in (d / 'stages.jsonl').read_text().splitlines()]
    elapsed = lambda prefix: next(s['elapsed'] for s in stamps if s['line'].startswith(prefix))
    for key, begin, end in [('canonical_lowering_seconds', 'compact-stage: canonical lowering', 'compact-stage: preparation blocks='), ('preparation_seconds', 'compact-stage: preparation blocks=', 'compact-stage: native module'), ('numeric_generation_seconds', 'compact-stage: native module', 'compact-stage: typed layout'), ('source_cfg_seconds', 'compact-stage: source CFG', 'compact-stage: finalize SSA'), ('cleanup_seconds', 'compact-stage: CFG cleanup', 'compact-stage: machine code')]:
        row[key] = elapsed(end) - elapsed(begin)
    log = (d / 'stderr.log').read_text()
    for key, pattern in [('max_rss_bytes', r'(\d+)  maximum resident set size'), ('instructions', r'(\d+)  instructions retired'), ('peak_footprint_bytes', r'(\d+)  peak memory footprint')]:
        row[key] = int(re.search(pattern, log).group(1))
    row['compaction_seconds'] = elapsed('compact-stage: CFG cleanup') - elapsed('compact-stage: compact values before=')
    for key, prefix in [('value_ids_before', 'compact-stage: compact values before='), ('value_ids_after', 'compact-values: retained=')]:
        row[key] = int(next(s['line'] for s in stamps if s['line'].startswith(prefix)).split('=')[-1])
    assert (row['value_ids_before'], row['value_ids_after']) == (20798230, 1242559)
    row['cleanup_including_compaction_seconds'] = row['cleanup_seconds'] + row['compaction_seconds']
    cohort.append(row)
assert cohort == read(root / 'cohort.json')
fields = {'compiler_seconds': lambda r: r['compile']['total_seconds'], 'whole_process_seconds': lambda r: r['process']['elapsed_seconds']}
for phase in ['parse', 'catalog', 'frontend', 'artifact', 'encode', 'native']:
    fields[phase + '_seconds'] = lambda r, p=phase: next(v['seconds'] for v in r['compile']['phases'] if v['phase'] == p)
for key in ['canonical_lowering_seconds', 'preparation_seconds', 'numeric_generation_seconds', 'source_cfg_seconds', 'cleanup_including_compaction_seconds', 'cleanup_seconds', 'compaction_seconds', 'instructions', 'max_rss_bytes', 'peak_footprint_bytes']:
    fields[key] = lambda r, k=key: r[k]
numerical = {}
for key, fn in fields.items():
    values = {v: [fn(r) for r in cohort if r['variant'] == v] for v in ['control', 'candidate']}
    control = statistics.mean(values['control'])
    values['mean_reduction_fraction'] = 1 - statistics.mean(values['candidate']) / control if control else None
    numerical[key] = values
assert numerical == read(root / 'numerical-summary.json')
blocks = []
for rows in [cohort[:4], cohort[4:]]:
    block = {}
    for key in ['compiler_seconds','whole_process_seconds','numeric_generation_seconds','instructions']:
        means = {v: statistics.mean(fields[key](r) for r in rows if r['variant'] == v) for v in ['control', 'candidate']}
        block[key] = dict(means, mean_reduction_fraction=1-means['candidate']/means['control'])
        if key in ['compiler_seconds','whole_process_seconds','numeric_generation_seconds']: assert block[key]['mean_reduction_fraction'] > 0
    blocks.append(block)
fixtures = read(root / 'fixture-results.json')
assert len(fixtures) == 14
for row in fixtures:
    name = row['fixture'].split(':')[-1] if ':' in row['fixture'] else Path(row['fixture']).stem
    assert pin(root / 'fixture-inputs' / (name + '.mec'))['sha256'] == row['source_sha256']
    assert row['all_outputs_match'] and row['variants']['control'] == row['variants']['candidate']
    for variant in ['control', 'candidate']:
        d = root / 'fixtures' / name / variant
        command = read(d / 'command.json')
        assert command['flags'] == dict(flags, **({'MECH_COMPACT_COMPILE_THREADS':'2'} if variant=='candidate' else {})) and command['binary_sha256'] == excluded[variant]['sha256']
        assert row['variants'][variant]['exit_code'] == 0 and len(row['variants'][variant]['files']) == 4
        for n, pinned in row['variants'][variant]['files'].items():
            assert pin(d / n) == pinned
inputs = read(root / 'native-link-inputs.json')
for row in inputs:
    assert pin(root / row['path']) == dict(bytes=row['bytes'], sha256=row['sha256'])
links = read(root / 'final-executable-results.json')
assert len(links) == 2
for variant, row in zip(['control', 'candidate'], links):
    assert row['variant'] == variant and row['exit_code'] == 0 and row['matches_complete_baseline_executable'] and not row['fresh_runtime_campaign']
    assert row['executable_sha256'] == '557d0f5ef2b979e01851ae23b5b3944453a0bd9e772d68161be198916ca06c2c'
    assert pin(root / ('link-' + variant) / 'worker') == dict(bytes=row['executable_bytes'], sha256=row['executable_sha256'])
    assert read(root / ('link-' + variant) / 'result.json') == row
    command = read(root / ('link-' + variant) / 'command.json')
    assert command['environment'] == {'ZERO_AR_DATE': '1'}
    assert [(r['source'], r['bytes'], r['sha256']) for r in command['input_pins']] == [(r['source'], r['bytes'], r['sha256']) for r in inputs]
assert (root / 'link-control/worker').read_bytes() == (root / 'link-candidate/worker').read_bytes()
tests = read(root/'compile-jobs-tests.json')
assert tests['exit_code']==0 and tests['production_module_sha256']==pin(root/'source/candidate/hosts/gpu/src/native_artifact/program/compact/compile_jobs.rs')['sha256']
assert 'test result: ok. 2 passed; 0 failed' in (root/'compile-jobs-tests.stdout.log').read_text()
test_build = read(root/'compile-jobs-tests-build.json')
assert test_build['exit_code']==0 and test_build['binary_sha256']==excluded['compile-jobs-tests']['sha256']
check = read(root/'candidate-check.json')
assert check['exit_code']==0 and check['head']==state['base_commit'] and check['patch_sha256']==build['patch_sha256']
setup_failure = read(root/'focused-test-setup-failure.json')
assert setup_failure['error']=='FileNotFoundError'
native_builds = read(root/'native-build-observations.json')
assert len(native_builds) == 2
for row in native_builds:
    d = root/('native-build-'+row['variant'])
    assert row == read(d/'result.json') and row['cached_adapter_objects'] and not row['primary_cohort']
    assert row['compiler_exit_code'] == row['link_exit_code'] == 0 and row['matches_complete_baseline_executable']
    assert row['measurement_boundary'] == 'compiler_spawn_through_native_link_process_wait_completion'
    assert abs(row['source_to_executable_seconds']-sum(row[k] for k in ['source_to_object_process_seconds','object_handoff_seconds','native_link_seconds'])) < 1e-8
    command = read(d/'command.json'); assert command['flags'] == dict(flags, **({'MECH_COMPACT_COMPILE_THREADS':'2'} if row['variant']=='candidate' else {})) and command['ZERO_AR_DATE'] == '1' and command['compiler_sha256'] == excluded[row['variant']]['sha256']
    for n, pinned in expected.items(): assert pin(d/n) == pinned and row['files'][n] == dict(pinned, matches_frozen_reference=True)
    assert pin(d/'worker') == dict(bytes=row['executable_bytes'], sha256=row['executable_sha256']) and pin(d/'worker') == pin(root/'link-control/worker')
native_cohort = read(root/'native-cohort.json')
native_order = [('control','native-control-1'),('candidate','native-candidate-1'),('candidate','native-candidate-2'),('control','native-control-2'),('candidate','native-candidate-3'),('control','native-control-3'),('control','native-control-4'),('candidate','native-candidate-4')]
assert [(r['variant'],r['name']) for r in native_cohort] == native_order
for row in native_cohort:
    assert row['primary_cohort']
    d = root/row['name']; actual = read(d/'result.json')
    assert actual == dict({k:v for k,v in row.items() if k!='name'},primary_cohort=False)
    assert read(root/(row['name']+'-observation.json')) == [actual]
    assert actual['compiler_exit_code']==actual['link_exit_code']==0 and actual['cached_adapter_objects'] and actual['matches_complete_baseline_executable']
    assert abs(actual['source_to_executable_seconds']-sum(actual[k] for k in ['source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']))<1e-8
    command=read(d/'command.json');wanted=dict(flags,**({'MECH_COMPACT_COMPILE_THREADS':'2'} if row['variant']=='candidate' else {}))
    assert command['flags']==wanted and command['compiler_sha256']==excluded[row['variant']]['sha256'] and command['ZERO_AR_DATE']=='1'
    for n,pinned in expected.items():assert pin(d/n)==pinned and actual['files'][n]==dict(pinned,matches_frozen_reference=True)
    assert pin(d/'worker')==pin(root/'link-control/worker')
native_numerical={}
for key in ['source_to_executable_seconds','source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']:
    values={v:[r[key] for r in native_cohort if r['variant']==v] for v in ['control','candidate']}
    values['mean_reduction_fraction']=1-statistics.mean(values['candidate'])/statistics.mean(values['control'])
    native_numerical[key]=values
native_blocks=[]
for rows in [native_cohort[:4],native_cohort[4:]]:
    means={v:statistics.mean(r['source_to_executable_seconds'] for r in rows if r['variant']==v) for v in ['control','candidate']}
    means['mean_reduction_fraction']=1-means['candidate']/means['control'];native_blocks.append(means)
native_summary=dict(numerical_summary=native_numerical,balanced_blocks=native_blocks,order=[list(r) for r in native_order],scope='Eight serial complete fresh source-to-executable compiles with the fixed adapter cached; code flags61, scheduling2 on candidate, serial control. Separate from the eight source-to-Object primary runs and preliminary pilots.')
assert native_summary==read(root/'native-numerical-summary.json')
summary=dict(source_commit=state['source_commit'],base_commit=state['base_commit'],program_flags_count=61,qualified_compile_threads=2,default_compile_threads=0,compiler_binary_sha256={v:excluded[v]['sha256'] for v in ['control','candidate']},output_hashes=expected,numerical_summary=numerical,balanced_blocks=blocks,native_cohort=native_summary,preliminary_screens=screens,preliminary_native_builds=native_builds,final_links=links,worker_diagnostic_jobs=340,fixture_pairs=14,focused_tests=2,focused_object_comparisons=24,check=check,build=build,decision='Retain opt-in production phase workers with exact program/executable output and original ordered publication. Report complete native-build timing separately from source-to-Object timing.',scope=[
    'Real production Deflate codegen uses bounded persistent Context workers, with coordinator-owned declarations, data, choice dependencies, DenseTables and Object publication. Main checked IR construction/cleanup remains serial. The worker scheduling environment setting is separate from the same61 program flags; default0 remains serial.',
    'Two workers queue340 real function jobs. Zero-worker and one-worker full benchmark outputs also match. Two focused tests exercise24 complete Object comparisons over1/2/4workers and both submission orders, including libcall symbol order, repeated and anonymous declarations, function-address data relocations and earlier publication error precedence.',
    'Eight source-to-Object ABBA/BAAB runs and eight source-to-executable ABBA/BAAB runs are separate serial cohorts with no concurrent builds, tests, profiling or archival. Complete native builds include fresh source analysis, Object/metadata writes, handoff and final linking, reusing the frozen adapter. First-use adapter construction is excluded.',
    'All screens,14paired fixtures, both timing cohorts and both preliminary complete native builds reproduce every source/bytecode/Object/metadata byte and the full executable. No scalar retirement, grammar or language change, weakened proof checks or fresh runtime campaign is claimed.',
    'The original full-executable pilot pair is slower for the candidate and remains outside the balanced means. All adverse stages, memory and clock movement remain. Numeric helper time falls in both source-to-Object blocks; unrelated movement is observational. Per-build native receipts preserve the generic primary_cohort:false field while native-cohort.json records balanced membership explicitly.',
    'Candidate check/build and focused-test builds are separate from program compilation. The first focused-test dependency-pinning attempt finds a baseline Cargo rlib removed during rebuild; it executes no tests. The successful focused harness uses the exact production module and real NativeCompileError type with equivalent backend error construction.',
    'Compiler/test binaries are excluded and SHA-pinned. Source patches, every raw measurement, generated program/executable, frozen native linker input, fixture and test log remain. Pure replay validates saved observations without compiling or rerunning timings. The sub-ten-second complete-compilation goal remains open.'
])
encoded = json.dumps(summary, indent=2, sort_keys=True) + '\n'
p = root / 'summary.json'
if p.exists():
    assert p.read_text() == encoded
else:
    p.write_text(encoded)
print(encoded, end='')
