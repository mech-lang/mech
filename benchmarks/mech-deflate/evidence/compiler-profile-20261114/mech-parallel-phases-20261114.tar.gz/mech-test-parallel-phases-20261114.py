from pathlib import Path
import json, hashlib, subprocess, time

root = Path('/private/tmp/mech-parallel-phases-20261114')
artifacts = root/'candidate-build.jsonl'
rows = [json.loads(line) for line in artifacts.read_text().splitlines()]
command = ['rustc', '+nightly-2026-03-03', '--crate-name', 'compile_jobs_tests', '--edition=2024', '--test', str(root/'compile_jobs_tests.rs'), '-C', 'opt-level=3', '-C', 'lto=thin', '-C', 'codegen-units=1', '-D', 'warnings', '-L', 'dependency=/private/tmp/mech-level12-compile-target/compiler/deps', '-o', str(root/'compile-jobs-tests')]
pins = []
for name in ['mech_gpu','cranelift_codegen','cranelift_frontend','cranelift_module','cranelift_object','cranelift_native']:
    p = Path(next(p for row in rows if row.get('reason') == 'compiler-artifact' and row.get('target',{}).get('name') == name for p in row['filenames'] if p.endswith('.rlib')))
    command += ['--extern', name + '=' + str(p)]
    pins.append({'path': str(p), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()})
(root/'compile-jobs-tests-command.json').write_text(json.dumps({'command':command,'dependencies':pins,'scope':'Exact current production worker module, production NativeCompileError type from the frozen baseline GPU library; backend error construction matches production. Full compiler output gates are separate.'},indent=2)+'\n')
started = time.monotonic()
with (root/'compile-jobs-tests-build.stdout.log').open('w') as stdout, (root/'compile-jobs-tests-build.stderr.log').open('w') as stderr:
    completed = subprocess.run(command,stdout=stdout,stderr=stderr)
record={'exit_code':completed.returncode,'seconds':time.monotonic()-started}
if not completed.returncode:record['binary_sha256']=hashlib.sha256((root/'compile-jobs-tests').read_bytes()).hexdigest()
(root/'compile-jobs-tests-build.json').write_text(json.dumps(record,indent=2)+'\n');print(record,flush=True)
assert completed.returncode == 0
with (root/'compile-jobs-tests.stdout.log').open('w') as stdout,(root/'compile-jobs-tests.stderr.log').open('w') as stderr:
    completed=subprocess.run([str(root/'compile-jobs-tests'),'--nocapture'],stdout=stdout,stderr=stderr)
(root/'compile-jobs-tests.json').write_text(json.dumps({'exit_code':completed.returncode,'production_module_sha256':hashlib.sha256(Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech/hosts/gpu/src/native_artifact/program/compact/compile_jobs.rs').read_bytes()).hexdigest()},indent=2)+'\n');print((root/'compile-jobs-tests.stdout.log').read_text(),flush=True);assert completed.returncode == 0
