from pathlib import Path
import hashlib, json, shutil, subprocess

repo = Path.cwd()
raw = Path('/private/tmp/mech-parallel-phases-20261114')
packet = Path('/private/tmp/mech-parallel-phases-packet-20261114')
assert not packet.exists()
excluded = []
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
for p in sorted(raw.rglob('*')):
    if not p.is_file():
        continue
    rel = p.relative_to(raw)
    if rel.as_posix() in ['control', 'candidate', 'compile-jobs-tests']:
        excluded.append(dict(path=rel.as_posix(), **pin(p)))
        continue
    dest = packet / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, dest)
base = subprocess.check_output(['git', 'rev-parse', 'HEAD^'], text=True).strip()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert base == '0195125f11747fb5dccdeb02c482d4a0c85ccb1f'
assert subprocess.check_output(['git', 'diff', '--binary', base, head]) == (packet / 'candidate.patch').read_bytes()
sources = subprocess.check_output(['git','diff','--name-only',base,head],text=True).splitlines()
missing = []
for source in sources:
    for variant, revision in [('control',base),('candidate',head)]:
        content = subprocess.run(['git','show',revision+':'+source],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        if content.returncode:
            assert variant == 'control' and source.endswith('/compile_jobs.rs')
            missing.append(source); continue
        dest = packet/'source'/variant/source
        dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(content.stdout)
for name in ['Cargo.toml', 'Cargo.lock', 'compile_profile.rs', 'profile_compile.py']:
    dest = packet / 'source' / 'harness' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(subprocess.check_output(['git', 'show', head + ':benchmarks/mech-deflate/native-profile/' + name]))
for row in json.loads((packet / 'fixture-results.json').read_text()):
    name = row['fixture']
    if name.startswith('hosts/'):
        shutil.copy2(repo / name, packet / 'fixture-inputs' / Path(name).name)
prior = Path('/private/tmp/mech-round2-planning-packet-20261114')
shutil.copytree(prior / 'licenses', packet / 'licenses')
shutil.copytree(prior / 'native-link-inputs', packet / 'native-link-inputs')
shutil.copy2(prior / 'native-link-inputs.json', packet / 'native-link-inputs.json')
validation = packet / 'validation'
validation.mkdir()
for suffix in ['.json', '.archive.json']:
    shutil.copy2(repo / ('benchmarks/mech-deflate/native-profile/schema-cache-view-compile-apple-m3-20261114' + suffix), validation / ('prior-qualified' + suffix))
for p in Path('/private/tmp').glob('*parallel-phases*20261114.py'):
    if p.name != 'mech-replay-parallel-phases-20261114.py':
        shutil.copy2(p, packet / p.name)
shutil.copy2('/private/tmp/mech-replay-parallel-phases-20261114.py', packet / 'replay.py')
(packet / 'excluded-compiler-products.json').write_text(json.dumps(excluded, indent=2) + '\n')
(packet / 'source-state.json').write_text(json.dumps(dict(source_commit=head, base_commit=base, production_change='Real phase codegen workers with ordered declaration/data/function event replay and machine-derived report completion.',changed_paths=sources,missing_control_paths=missing,default_compile_threads=0,qualified_compile_threads=2, compiler_output_identity_required=True, native_link_inputs_from='mech-round2-planning-20261114.tar.gz', runtime_campaign_rerun=False), indent=2) + '\n')
(packet/'README.txt').write_text("""Integrated phase compilation workers, 2026-11-14.
This is the real Deflate compilation path, enabled by the internal scheduling
setting MECH_COMPACT_COMPILE_THREADS=2. Default0 retains serial compilation;
one-worker and serial paths are also byte-gated. Program codegen flags remain61.
Persistent workers own Contexts and machine compilation. The coordinator owns
checked IR construction/cleanup, shared DenseTables, decisions and all Object
events. A RecordedModule stages later declarations/data/functions and replays
them after the earlier definition. Reports use actual compiled code/stack data.
Two focused tests perform24 complete ordered Object comparisons (including
libcalls, repeated/anonymous declarations and data relocations) and original
earlier-publication-error precedence. Their first dependency-pinning attempt
finds a baseline rlib removed by Cargo rebuilding; no tests ran in that attempt.
The successful tests use the exact production module and real NativeCompileError
type, with production-equivalent backend error construction in a tiny harness.
Fourteen paired fixture programs, all full source/bytecode/Object/metadata and
final executable bytes match. A two-worker diagnostic queues340 real functions.
Eight source-to-Object ABBA/BAAB runs and eight complete source-to-executable
ABBA/BAAB runs are separate cohorts. The latter include the final link with a
frozen cached adapter. First-use adapter building is excluded. Preliminary
screens and the reversed-direction single full-executable pilot pair remain;
neither is pooled into primary means. Native per-build receipts inherit the
one-shot harness's primary_cohort:false; native-cohort.json records selected
cohort membership explicitly. No timings are rewritten.
Every raw observation, adverse phase/memory counter, exact source/patch,
test/fixture output, program Object, full executable and frozen native-link input
is included. Compiler/test executables are excluded and SHA-pinned. Pure replay
checks saved source/bytes/measurements without rerunning builds or timings.
Main parsing, frontend, preparation and main CFG/cleanup remain serial; this
does not establish the requested sub-ten-second complete compilation goal.
""")
print(packet)
