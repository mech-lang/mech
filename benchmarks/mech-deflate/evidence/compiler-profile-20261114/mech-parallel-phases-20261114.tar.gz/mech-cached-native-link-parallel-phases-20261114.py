from pathlib import Path
import hashlib, json, os, shutil, subprocess, time

root = Path('/private/tmp/mech-parallel-phases-20261114')
link = Path('/private/tmp/mech-round2-baseline-20261114/link')
capture = json.loads((link / 'capture/link-command.json').read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
expected = '557d0f5ef2b979e01851ae23b5b3944453a0bd9e772d68161be198916ca06c2c'
assert sha(link / 'worker-baseline') == expected
records = []
for variant in ['control', 'candidate']:
    directory = root / (variant + '-screen')
    program = directory / 'program.o'
    checks = json.loads((directory / 'output-check.json').read_text())
    assert all(r['matches_current_control_output'] for r in checks.values())
    shutil.copy2(program, link / 'program.o')
    for item in capture['inputs']:
        p = Path(item['source'])
        assert p.stat().st_size == item['bytes'] and sha(p) == item['sha256'], str(p)
    env = dict(os.environ, ZERO_AR_DATE='1')
    out = root / ('link-' + variant)
    out.mkdir()
    command = capture['command']
    (out / 'command.json').write_text(json.dumps({'command': command, 'environment': {'ZERO_AR_DATE': '1'}, 'source_object': str(program), 'input_pins': capture['inputs']}, indent=2) + '\n')
    started = time.monotonic()
    with (out / 'stdout.log').open('w') as stdout, (out / 'stderr.log').open('w') as stderr:
        completed = subprocess.run(command, env=env, stdout=stdout, stderr=stderr)
    seconds = time.monotonic() - started
    assert completed.returncode == 0
    executable = link / 'worker'
    record = {'variant': variant, 'exit_code': completed.returncode, 'link_seconds': seconds, 'executable_bytes': executable.stat().st_size, 'executable_sha256': sha(executable), 'matches_complete_baseline_executable': executable.read_bytes() == (link / 'worker-baseline').read_bytes(), 'measurement_boundary': 'cached_native_link_only', 'fresh_runtime_campaign': False}
    shutil.copy2(executable, out / 'worker')
    (out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
    records.append(record)
    print(json.dumps(record), flush=True)
    assert record['matches_complete_baseline_executable'] and record['executable_sha256'] == expected
(root / 'final-executable-results.json').write_text(json.dumps(records, indent=2) + '\n')
