from pathlib import Path

curate = Path('/private/tmp/mech-curate-schema-cache-view-20261114.py').read_text().replace('schema-cache-view', 'parallel-phases')
curate = curate.replace("'pending-schema-tests'", "'compile-jobs-tests'")
curate = curate.replace('4057eb4364d496c66bad911394249007b1426590', '0195125f11747fb5dccdeb02c482d4a0c85ccb1f')
start = curate.index('sources = ')
end = curate.index("for name in ['Cargo.toml'", start)
curate = curate[:start] + '''sources = subprocess.check_output(['git','diff','--name-only',base,head],text=True).splitlines()
missing = []
for source in sources:
    for variant, revision in [('control',base),('candidate',head)]:
        content = subprocess.run(['git','show',revision+':'+source],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        if content.returncode:
            assert variant == 'control' and source.endswith('/compile_jobs.rs')
            missing.append(source); continue
        dest = packet/'source'/variant/source
        dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(content.stdout)
''' + curate[end:]
curate = curate.replace(", 'pending_schema_tests.rs'", '')
curate = curate.replace('call-schema-borrow-compile-apple-m3-20261114', 'schema-cache-view-compile-apple-m3-20261114')
curate = curate.replace("glob('*schema-cache*20261114.py')", "glob('*parallel-phases*20261114.py')")
start = curate.index("probe = Path(")
end = curate.index("(packet / 'excluded-compiler-products.json')", start)
curate = curate[:start] + curate[end:]
curate = curate.replace("production_change='Preserve PendingSchema canonicalization cache owners through assembly and nested control visitors; raw drafts retain uncached finalization.'", "production_change='Real phase codegen workers with ordered declaration/data/function event replay and machine-derived report completion.',changed_paths=sources,missing_control_paths=missing,default_compile_threads=0,qualified_compile_threads=2")
start = curate.index("(packet / 'README.txt').write_text(")
curate = curate[:start] + '''(packet/'README.txt').write_text("""Integrated phase compilation workers, 2026-11-14.
This is the real Deflate compilation path, enabled by the internal scheduling
setting MECH_COMPACT_COMPILE_THREADS=2. Default0 retains serial compilation;
one-worker and serial paths are also byte-gated. Program codegen flags remain61.
Persistent workers own Contexts and machine compilation. The coordinator owns
checked IR construction/cleanup, shared DenseTables, decisions and all Object
events. A RecordedModule stages later declarations/data/functions and replays
them after the earlier definition. Reports use actual compiled code/stack data.
Two focused tests perform24 complete ordered Object comparisons (including
libcalls, repeated/anonymous declarations and data relocations) and original
earlier-publication-error precedence. Their first dependency-pinning attempt
finds a baseline rlib removed by Cargo rebuilding; no tests ran in that attempt.
The successful tests use the exact production module and real NativeCompileError
type, with production-equivalent backend error construction in a tiny harness.
Fourteen paired fixture programs, all full source/bytecode/Object/metadata and
final executable bytes match. A two-worker diagnostic queues340 real functions.
Eight source-to-Object ABBA/BAAB runs and eight complete source-to-executable
ABBA/BAAB runs are separate cohorts. The latter include the final link with a
frozen cached adapter. First-use adapter building is excluded. Preliminary
screens and the reversed-direction single full-executable pilot pair remain;
neither is pooled into primary means. Native per-build receipts inherit the
one-shot harness's primary_cohort:false; native-cohort.json records selected
cohort membership explicitly. No timings are rewritten.
Every raw observation, adverse phase/memory counter, exact source/patch,
test/fixture output, program Object, full executable and frozen native-link input
is included. Compiler/test executables are excluded and SHA-pinned. Pure replay
checks saved source/bytes/measurements without rerunning builds or timings.
Main parsing, frontend, preparation and main CFG/cleanup remain serial; this
does not establish the requested sub-ten-second complete compilation goal.
""")
print(packet)
'''
Path('/private/tmp/mech-curate-parallel-phases-20261114.py').write_text(curate)

replay = Path('/private/tmp/mech-replay-schema-cache-view-20261114.py').read_text()
replay = replay.replace("at=int(match[1])-1;assert at>=cursor;", "at=int(match[1]) if int(match[2] or 1)==0 else int(match[1])-1;assert at>=cursor;")
replay = replay.replace("assert apply_source_patch((root/'source/control'/name).read_text(), block)", "assert apply_source_patch((root/'source/control'/name).read_text() if (root/'source/control'/name).exists() else '', block)")
replay = replay.replace("assert set(names) == {'src/engine/src/source_semantics/'+n for n in ['frontend.rs','pending_schema.rs','application.rs','comprehension.rs']}", "assert set(names) == set(state['changed_paths']) and state['missing_control_paths'] == ['hosts/gpu/src/native_artifact/program/compact/compile_jobs.rs']")
replay = replay.replace("for variant, name in [('control', 'control-screen'), ('candidate', 'candidate-screen')] + order:", "for variant, name in [('control','control-screen'),('candidate','candidate-screen'),('candidate','single-worker-screen'),('candidate','serial-path-screen')] + order:")
old = "    assert command['flags'] == flags and command['binary_sha256'] == excluded[variant]['sha256']\n    assert not command['profiling_excluded_from_primary']"
new = '''    requested = command['compile_threads']
    wanted = dict(flags)
    if requested is not None: wanted['MECH_COMPACT_COMPILE_THREADS'] = str(requested)
    if command['profiling_excluded_from_primary']: wanted['MECH_PROFILE_COMPILE_JOBS'] = '1'
    assert command['flags'] == wanted and command['binary_sha256'] == excluded[variant]['sha256'] and command['program_flags_count'] == 61
    if not name.endswith('-screen'):
        assert not command['profiling_excluded_from_primary'] and requested == (2 if variant=='candidate' else None)
    if name in ['candidate-screen','single-worker-screen']:
        assert f'compact-compile-jobs: workers={requested} submitted=340' in (d/'stderr.log').read_text()'''
assert old in replay
replay = replay.replace(old,new)
replay = replay.replace("for key in ['compiler_seconds', 'whole_process_seconds', 'frontend_seconds', 'instructions']:", "for key in ['compiler_seconds','whole_process_seconds','numeric_generation_seconds','instructions']:")
replay = replay.replace("if key in ['frontend_seconds', 'instructions']: assert", "if key in ['compiler_seconds','whole_process_seconds','numeric_generation_seconds']: assert")
replay = replay.replace("        assert command['flags'] == flags and command['binary_sha256'] == excluded[variant]['sha256']", "        assert command['flags'] == dict(flags, **({'MECH_COMPACT_COMPILE_THREADS':'2'} if variant=='candidate' else {})) and command['binary_sha256'] == excluded[variant]['sha256']")
start = replay.index("tests = read(root/'pending-schema-tests.json')")
end = replay.index("native_builds = read(root/'native-build-observations.json')",start)
tests = '''tests = read(root/'compile-jobs-tests.json')
assert tests['exit_code']==0 and tests['production_module_sha256']==pin(root/'source/candidate/hosts/gpu/src/native_artifact/program/compact/compile_jobs.rs')['sha256']
assert 'test result: ok. 2 passed; 0 failed' in (root/'compile-jobs-tests.stdout.log').read_text()
test_build = read(root/'compile-jobs-tests-build.json')
assert test_build['exit_code']==0 and test_build['binary_sha256']==excluded['compile-jobs-tests']['sha256']
check = read(root/'candidate-check.json')
assert check['exit_code']==0 and check['head']==state['base_commit'] and check['patch_sha256']==build['patch_sha256']
setup_failure = read(root/'focused-test-setup-failure.json')
assert setup_failure['error']=='FileNotFoundError'
'''
replay = replay[:start]+tests+replay[end:]
replay = replay.replace("assert command['flags'] == flags and command['ZERO_AR_DATE'] == '1' and command['compiler_sha256'] == excluded[row['variant']]['sha256']", "assert command['flags'] == dict(flags, **({'MECH_COMPACT_COMPILE_THREADS':'2'} if row['variant']=='candidate' else {})) and command['ZERO_AR_DATE'] == '1' and command['compiler_sha256'] == excluded[row['variant']]['sha256']")
start = replay.index("probe = root/'parallel-boundary-probe'")
end = replay.index('encoded = json.dumps(',start)
tail = '''native_cohort = read(root/'native-cohort.json')
native_order = [('control','native-control-1'),('candidate','native-candidate-1'),('candidate','native-candidate-2'),('control','native-control-2'),('candidate','native-candidate-3'),('control','native-control-3'),('control','native-control-4'),('candidate','native-candidate-4')]
assert [(r['variant'],r['name']) for r in native_cohort] == native_order
for row in native_cohort:
    assert row['primary_cohort']
    d = root/row['name']; actual = read(d/'result.json')
    assert actual == dict({k:v for k,v in row.items() if k!='name'},primary_cohort=False)
    assert read(root/(row['name']+'-observation.json')) == [actual]
    assert actual['compiler_exit_code']==actual['link_exit_code']==0 and actual['cached_adapter_objects'] and actual['matches_complete_baseline_executable']
    assert abs(actual['source_to_executable_seconds']-sum(actual[k] for k in ['source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']))<1e-8
    command=read(d/'command.json');wanted=dict(flags,**({'MECH_COMPACT_COMPILE_THREADS':'2'} if row['variant']=='candidate' else {}))
    assert command['flags']==wanted and command['compiler_sha256']==excluded[row['variant']]['sha256'] and command['ZERO_AR_DATE']=='1'
    for n,pinned in expected.items():assert pin(d/n)==pinned and actual['files'][n]==dict(pinned,matches_frozen_reference=True)
    assert pin(d/'worker')==pin(root/'link-control/worker')
native_numerical={}
for key in ['source_to_executable_seconds','source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']:
    values={v:[r[key] for r in native_cohort if r['variant']==v] for v in ['control','candidate']}
    values['mean_reduction_fraction']=1-statistics.mean(values['candidate'])/statistics.mean(values['control'])
    native_numerical[key]=values
native_blocks=[]
for rows in [native_cohort[:4],native_cohort[4:]]:
    means={v:statistics.mean(r['source_to_executable_seconds'] for r in rows if r['variant']==v) for v in ['control','candidate']}
    means['mean_reduction_fraction']=1-means['candidate']/means['control'];native_blocks.append(means)
native_summary=dict(numerical_summary=native_numerical,balanced_blocks=native_blocks,order=[list(r) for r in native_order],scope='Eight serial complete fresh source-to-executable compiles with the fixed adapter cached; code flags61, scheduling2 on candidate, serial control. Separate from the eight source-to-Object primary runs and preliminary pilots.')
assert native_summary==read(root/'native-numerical-summary.json')
summary=dict(source_commit=state['source_commit'],base_commit=state['base_commit'],program_flags_count=61,qualified_compile_threads=2,default_compile_threads=0,compiler_binary_sha256={v:excluded[v]['sha256'] for v in ['control','candidate']},output_hashes=expected,numerical_summary=numerical,balanced_blocks=blocks,native_cohort=native_summary,preliminary_screens=screens,preliminary_native_builds=native_builds,final_links=links,worker_diagnostic_jobs=340,fixture_pairs=14,focused_tests=2,focused_object_comparisons=24,check=check,build=build,decision='Retain opt-in production phase workers with exact program/executable output and original ordered publication. Report complete native-build timing separately from source-to-Object timing.',scope=[
    'Real production Deflate codegen uses bounded persistent Context workers, with coordinator-owned declarations, data, choice dependencies, DenseTables and Object publication. Main checked IR construction/cleanup remains serial. The worker scheduling environment setting is separate from the same61 program flags; default0 remains serial.',
    'Two workers queue340 real function jobs. Zero-worker and one-worker full benchmark outputs also match. Two focused tests exercise24 complete Object comparisons over1/2/4workers and both submission orders, including libcall symbol order, repeated and anonymous declarations, function-address data relocations and earlier publication error precedence.',
    'Eight source-to-Object ABBA/BAAB runs and eight source-to-executable ABBA/BAAB runs are separate serial cohorts with no concurrent builds, tests, profiling or archival. Complete native builds include fresh source analysis, Object/metadata writes, handoff and final linking, reusing the frozen adapter. First-use adapter construction is excluded.',
    'All screens,14paired fixtures, both timing cohorts and both preliminary complete native builds reproduce every source/bytecode/Object/metadata byte and the full executable. No scalar retirement, grammar or language change, weakened proof checks or fresh runtime campaign is claimed.',
    'The original full-executable pilot pair is slower for the candidate and remains outside the balanced means. All adverse stages, memory and clock movement remain. Numeric helper time falls in both source-to-Object blocks; unrelated movement is observational. Per-build native receipts preserve the generic primary_cohort:false field while native-cohort.json records balanced membership explicitly.',
    'Candidate check/build and focused-test builds are separate from program compilation. The first focused-test dependency-pinning attempt finds a baseline Cargo rlib removed during rebuild; it executes no tests. The successful focused harness uses the exact production module and real NativeCompileError type with equivalent backend error construction.',
    'Compiler/test binaries are excluded and SHA-pinned. Source patches, every raw measurement, generated program/executable, frozen native linker input, fixture and test log remain. Pure replay validates saved observations without compiling or rerunning timings. The sub-ten-second complete-compilation goal remains open.'
])
'''
replay=replay[:start]+tail+replay[end:]
Path('/private/tmp/mech-replay-parallel-phases-20261114.py').write_text(replay)
print('prepared integrated worker evidence recipes')
