from pathlib import Path
import hashlib, json, os, shutil, subprocess, time

root = Path('/private/tmp/mech-parallel-phases-20261114')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
patch = subprocess.check_output(['git', 'diff', 'HEAD', '--binary'])
(root / 'candidate.patch').write_bytes(patch)
assert 'compile_jobs.rs' in patch.decode()
env = dict(os.environ, CARGO_TARGET_DIR='/private/tmp/mech-level12-compile-target', CARGO_INCREMENTAL='0')
for mode in ['check', 'build']:
    command = ['cargo', mode, '--locked', '--offline', '--profile', 'compiler', '-j4', '--manifest-path', 'benchmarks/mech-deflate/native-profile/Cargo.toml', '--bin', 'compile_profile', '--message-format=json']
    stem = 'candidate-' + mode
    started = time.monotonic()
    with (root / (stem + '.jsonl')).open('w') as stdout, (root / (stem + '.stderr')).open('w') as stderr:
        completed = subprocess.run(command, env=env, stdout=stdout, stderr=stderr)
    record = {'command': command, 'head': head, 'patch_sha256': hashlib.sha256(patch).hexdigest(), 'seconds': time.monotonic()-started, 'exit_code': completed.returncode, 'CARGO_TARGET_DIR': env['CARGO_TARGET_DIR'], 'CARGO_INCREMENTAL': '0'}
    if mode == 'build' and completed.returncode == 0:
        rows = [json.loads(line) for line in (root / (stem + '.jsonl')).read_text().splitlines()]
        binary = next(r['executable'] for r in rows if r.get('reason') == 'compiler-artifact' and r.get('target', {}).get('name') == 'compile_profile' and r.get('executable'))
        dest = root / 'candidate'
        shutil.copy2(binary, dest)
        dest.chmod(0o755)
        record.update(binary=str(dest), binary_sha256=hashlib.sha256(dest.read_bytes()).hexdigest())
    (root / (stem + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    assert patch == subprocess.check_output(['git', 'diff', 'HEAD', '--binary']) and head == subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
    if completed.returncode:
        raise SystemExit(completed.returncode)
