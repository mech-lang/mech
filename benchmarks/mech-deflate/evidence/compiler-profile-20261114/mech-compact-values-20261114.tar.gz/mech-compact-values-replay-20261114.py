from pathlib import Path
import json,hashlib,re,statistics
root=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
def pin(p):
 data=p.read_bytes();return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
state=read(root/'source-state.json');patch=pin(root/'source-change.patch');assert patch['sha256']==state['patch_sha256']
prior=read(root/'validation/qualified-predecessors.json');receipt=read(root/'validation/qualified-predecessors.archive.json');assert pin(root/'validation/qualified-predecessors.json')['sha256']==receipt['replay_sha256']
old=root/'historical55';current=root/'current60';old_build=read(old/'candidate-build.json');build=read(current/'candidate-build.json');control=read(current/'control-build.json')
assert old_build['head']==state['historical_base_commit'] and old_build['patch_sha256']==patch['sha256']==pin(old/'candidate.patch')['sha256']
assert build['head']==control['head']==state['source_commit'] and build['patch_sha256']==hashlib.sha256(b'').hexdigest()==pin(current/'candidate.patch')['sha256']
assert pin(current/'control.patch')['sha256']==control['patch_sha256']
assert pin(current/'source-change.patch')==patch
for record in [old_build,build,control]:assert record['exit_code']==0
old_control=read(old/'control-origin.json');assert old_control['source_commit']==state['historical_control_source_commit']==prior['source_commit'] and old_control['sha256']==prior['compiler_binary_sha256']['candidate']
current_control=read(current/'control-origin.json');restore=read(current/'source-restore.json');assert current_control['source_commit']==restore['control_source_commit']==state['base_commit'] and restore['source_commit']==state['source_commit'] and restore['patch_sha256']==patch['sha256']
assert current_control['sha256']==control['binary_sha256'] and current_control['patch_sha256']==control['patch_sha256']
flags55=read(old/'runtime-flags.json');flags60=read(current/'runtime-flags.json');assert len(flags55)==55 and len(flags60)==60
new_flags=['MECH_EMIT_REDUCTION_FALLTHROUGH','MECH_ARM64_SUBTRACT_BRANCH','MECH_ARM64_SUBTRACT_IMMEDIATE_BRANCH','MECH_ORDERED_SHORT_NARROW_ORDINAL','MECH_ORDERED_LAZY_REVERSE_CURSOR'];assert flags60==dict(flags55,**{key:'1' for key in new_flags})
expected55=prior['output_hashes'];expected60=read(current/'reference-pins.json');author=read(current/'author-program-check.json');assert author['output_hashes']==expected60 and author['object_matches_author_qualified_program'] and author['source_and_mbc_match_previous'] and author['metadata_pin_established_by_current_control']
assert expected60['program.o']['sha256']=='8a4c2b172798d06252055b20398cdbf9517b4b5be76730ea1824435ef89bbba4'
assert {k:v for k,v in expected60.items() if k!='program.o'}=={k:v for k,v in expected55.items() if k!='program.o'}
assert expected60['program.o']['sha256'] in (root/'source/docs/design/native-short-reduction-edges.md').read_text()
for raw,expected in [(old,expected55),(current,expected60)]:
 for name,pinned in expected.items():assert pin(raw/'reference'/name)==pinned
# Every omitted executable remains independently pinned to its original build.
excluded={r['path']:r for r in read(root/'excluded-executables.json')}
for label,raw,pins in [('historical55',old,{'control':old_control['sha256'],'candidate':old_build['binary_sha256']}),('current60',current,{'control':control['binary_sha256'],'candidate':build['binary_sha256']})]:
 for name,sha in pins.items():assert excluded[label+'/'+name]['sha256']==sha
stage_fields=[('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]
host_fields=[('max_rss_bytes',r'(\d+)  maximum resident set size'),('instructions',r'(\d+)  instructions retired'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]
order=['control-1','candidate-1','candidate-2','control-2','candidate-3','control-3','control-4','candidate-4']
def validate_cohort(raw,flags,expected,pins,key):
 rows=read(raw/'cohort.json');assert [r['name'] for r in rows]==order
 for name in ['control-screen','candidate-screen',*order]:
  variant=name.split('-')[0];d=raw/name;process=read(d/'process.json');assert process['exit_code']==0 and process['samples']==0 and process['sampling_error'] is None
  command=read(raw/(name+'-command.json'));assert command['flags']==flags and command['binary_sha256']==pins[variant]
  for filename,pinned in expected.items():assert pin(d/filename)==pinned and read(d/'output-check.json')[filename]==dict(pinned,**{key:True})
 for row in rows:
  d=raw/row['name'];assert row['compile']==read(d/'compile.json') and row['process']==read(d/'process.json') and row['files']==read(d/'output-check.json')
  assert row['variant']==row['name'].split('-')[0]
  stamps=[json.loads(line) for line in (d/'stages.jsonl').read_text().splitlines()]
  for field,begin,end in stage_fields:assert row[field]==next(s['elapsed'] for s in stamps if s['line'].startswith(end))-next(s['elapsed'] for s in stamps if s['line'].startswith(begin))
  for field,pattern in host_fields:assert row[field]==int(re.search(pattern,(d/'stderr.log').read_text()).group(1))
  if row['variant']=='candidate':
   begin=next(s for s in stamps if s['line'].startswith('compact-stage: compact values before='));end=next(s for s in stamps if s['line'].startswith('compact-stage: CFG cleanup'));assert row['compaction_seconds']==end['elapsed']-begin['elapsed'];assert row['value_ids_before']==int(begin['line'].split('=')[-1])==20787570;assert row['value_ids_after']==int(next(s['line'] for s in stamps if s['line'].startswith('compact-values: retained=')).split('=')[-1])==1241393
  else:assert row['compaction_seconds']==0
  assert row['cleanup_including_compaction_seconds']==row['cleanup_seconds']+row['compaction_seconds']
 test=read(raw/'index-tests-command.json');assert test['exit_code']==0 and test['source_patch_sha256']==pin(raw/'test-source.patch')['sha256']
 assert re.findall(r'test result: ok\. (\d+) passed',(raw/'index-tests.log').read_text())==['7']
 if raw==current:assert test['flags']==flags and test['source_patch_sha256']==hashlib.sha256(b'').hexdigest()
 else:assert test['source_patch_sha256']==patch['sha256']
 fixtures=read(raw/'fixture-results.json');assert len(fixtures)==14
 for record in fixtures:
  assert record['all_outputs_match'] and record['variants']['control']==record['variants']['candidate'] and record['variants']['control']['exit_code']==0 and len(record['variants']['control']['files'])==4
  name=Path(record['fixture']).stem if ':' not in record['fixture'] else record['fixture'].split(':')[-1]
  for variant,result in record['variants'].items():
   d=raw/'fixtures'/name/variant;command=read(d/'command.json');assert command['flags']==flags and command['binary_sha256']==pins[variant]
   for filename,pinned in result['files'].items():assert pin(d/filename)==pinned
   assert result['files']['source.mec']['sha256']==record['source_sha256']
 base=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase.mec').read_text();fragment=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase-states.mec').read_text();assembled=base.replace('+> sequence\n','+> sequence\n'+fragment+'\n',1).replace('phase-candidates(values, 1u64, 0u64, permitted, divisor)','#PhaseCandidates(values, permitted, divisor, 1u64, 0u64)',1);assert assembled==(raw/'fixture-inputs/numeric-nested-phase-states.mec').read_text()
 fields={'compiler_seconds':lambda r:r['compile']['total_seconds'],'whole_process_seconds':lambda r:r['process']['elapsed_seconds']}
 for phase in ['parse','frontend','native']:fields[phase+'_seconds']=lambda r,p=phase:next(v['seconds'] for v in r['compile']['phases'] if v['phase']==p)
 for field in [f[0] for f in stage_fields]+['cleanup_including_compaction_seconds','compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:fields[field]=lambda r,k=field:r[k]
 qualified={field:{v:[fn(r) for r in rows if r['variant']==v] for v in ['control','candidate']} for field,fn in fields.items()}
 for values in qualified.values():
  mean=statistics.mean(values['control']);values['mean_reduction_fraction']=1-statistics.mean(values['candidate'])/mean if mean else None
 assert qualified==read(raw/'numerical-summary.json')
 blocks=[]
 for block in [rows[:4],rows[4:]]:
  blocks.append(dict(order=[r['name'] for r in block],compiler_mean_reduction_fraction=1-statistics.mean(r['compile']['total_seconds'] for r in block if r['variant']=='candidate')/statistics.mean(r['compile']['total_seconds'] for r in block if r['variant']=='control')))
 return dict(flags_count=len(flags),qualified=qualified,blocks=blocks,output_hashes=expected,compiler_binary_sha256=pins,fixtures=fixtures,tests=dict(passed=7,native_machine_code_pairs=65,million_alias_stress=1000003),build_observations=dict(final_test_command_seconds=test['seconds'],cached_compiler_lookup_seconds=read(raw/'candidate-build.json')['seconds'],cold_bootstrap_claimed=False))
historical=validate_cohort(old,flags55,expected55,{'control':old_control['sha256'],'candidate':old_build['binary_sha256']},'matches_previous_qualified_output')
latest=validate_cohort(current,flags60,expected60,{'control':control['binary_sha256'],'candidate':build['binary_sha256']},'matches_current_control_output')
prototype=old/'prototype-v1';pb=read(prototype/'candidate-build.json');assert pb['exit_code']==0 and excluded['historical55/prototype-v1/candidate']['sha256']==pb['binary_sha256']
assert re.findall(r'test result: ok\. (\d+) passed',(prototype/'index-tests.log').read_text())==['5']
for filename,pinned in expected55.items():assert pin(prototype/'candidate-screen'/filename)==pinned
for name in ['01-tightened-test-unused-bindings','02-unused-metadata-alias-references','03-invalid-i128-constant-fixture','04-backend-unsupported-i32-split-fixture']:
 d=old/'corrections'/name;assert read(d/'index-tests-command.json')['exit_code']!=0 and pin(d/'test-source.patch')['sha256']==read(d/'index-tests-command.json')['source_patch_sha256']
assert 'use of retired value' in (old/'corrections/02-unused-metadata-alias-references/index-tests.log').read_text()
assert read(old/'intermediate-five-tests/index-tests-command.json')['exit_code']==0 and '5 passed' in (old/'intermediate-five-tests/index-tests.log').read_text()
def validate_profile(path,flags,expected,binary_sha):
 command=read(path/'command.json');assert command['flags']==flags and command['binary_sha256']==binary_sha
 process=read(path/'cpu/process.json');assert process['exit_code']==0 and read(path/'output-check.json')==expected
 for filename,pinned in expected.items():assert pin(path/'cpu'/filename)==pinned
 mapping=read(path/'demangled-symbols.json');symbols=set();tables={}
 for p in sorted((path/'cpu').glob('sample-*.txt')):
  if not re.fullmatch(r'sample-\d+\.txt',p.name):continue
  text=p.read_text();symbols.update(re.findall(r'_R[A-Za-z0-9_]+',text));mapped=re.sub(r'_R[A-Za-z0-9_]+',lambda m:mapping[m.group(0)],text);assert mapped==p.with_name(p.stem+'-demangled.txt').read_text();parsed=[]
  for line in mapped[mapped.index('Sort by top of stack'):].splitlines()[1:]:
   match=re.match(r'\s+(.*?)\s+\(in (.*?)\)\s+(\d+)\s*$',line)
   if match:parsed.append(dict(symbol=match[1],image=match[2],self_samples=int(match[3])))
   elif parsed:break
  assert parsed==read(p.with_name(p.stem+'-self.json'));tables[p.name]=parsed
 assert set(mapping)==symbols and len(tables)>0 and process['samples']>=len(tables)
 return dict(command=command,process=process,completed_sample_files=len(tables),first_window_cpu_self_samples=[r for r in next(iter(tables.values())) if r['symbol']!='__ulock_wait'][:20],main_thread_waits_excluded_from_hotspot_table=True)
profiles={'historical_control55':validate_profile(root/'profile',flags55,expected55,old_control['sha256']),'current_candidate60':validate_profile(root/'profile-current60',flags60,expected60,build['binary_sha256'])}
summary=dict(source_commit=state['source_commit'],base_commit=state['base_commit'],hardware=state['hardware'],decision='Retain post-producer SSA value compaction; exact generated code and complete metadata preserved on both separately matched bases',candidate_patch_sha256=state['patch_sha256'],historical55=historical,current60=latest,diagnostic_profiles=profiles,scope=[
 'Sixteen serial fresh source-to-Object primary observations: eight on the historical 55-flag base and eight on the latest 60-flag base. Each uses ABBA then BAAB order. Configurations and different generated programs are kept separate, never pooled. No cached Object or decoded-only substitute is used.',
 'Builds, tests, both screens, fixtures, profiling, copying, hashing and archiving do not overlap primary timing. Compaction cost is included in cleanup_including_compaction_seconds and in every compiler/whole-process total.',
 'The builder has finished and discarded all external Value handles before compaction. Aliases are flattened with the unchanged resolver; every reference is remapped before retired IDs are released. Original definition order, instruction/block identities, effects, layout, debug-label policy, current ownership checks and resource proofs remain. No semantic/factory/permission result is cached.',
 'All source, MBC, Object and complete metadata bytes match between subjects within each base. Both bases pass fourteen fixture pairs and the same seven production tests, including 65 supported exact native-code pairs and a million-alias stress case. The multi-result IR fixture is verified without claiming unsupported I32-isplit machine lowering.',
 'The current control reproduces the independently qualified short-reduction Object 8a4c2b17... from PR 973 source 1c09216698.... Its five new switches are enabled identically for both current subjects. Original 55-flag observations and output pins remain separately available.',
 'Both balanced blocks improve mean compiler time on each base. Overall elapsed ranges overlap and adverse RSS/footprint and unchanged-stage observations remain. These finite cohorts are descriptive, not population estimates. No selective best-run timing is used.',
 'The initial output-identical prototype, the two tightened metadata counterexamples, build/fixture corrections and intermediate passing tests remain with their exact patches and logs. Compiler executables are excluded and hash-pinned. Rebuilds and cached lookups are recorded without a cold-bootstrap claim.',
 'Both separate CPU profiles retain raw/mapped stacks, output bytes, commands, self-count tables, existing demangler source/pin and any unsuccessful sampling attempts. Main-thread waits are not CPU work; samples are not stage-exclusive elapsed time or exact source-line attribution.',
 'No new program-runtime latency campaign is claimed: generated machine code and complete metadata are byte-identical within each matched base. Grammar, language, direct scalar emission, checked errors, finite admission and backend optimization levels are unchanged. Full compilation remains above ten seconds.'
])
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
