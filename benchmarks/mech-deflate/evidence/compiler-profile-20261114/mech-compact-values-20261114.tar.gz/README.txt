Retired SSA value compaction, Apple M3, 2026-11-14.
The main IR contains 20,787,570 value IDs. A post-producer pass retains
1,241,393 actual definitions and remaps every use, with the original definition
order, instructions, blocks, layout, effects and metadata contracts preserved.
All external producer Value handles have been discarded before this pass runs.
Alias targets stay available until shared pooled arguments, unused jump and
exception tables, context items, union inputs and debug labels are rewritten.
The two idempotent remapping sweeps use a disjoint temporary namespace and
retain the ordinary path if that namespace would exceed BlockArg's payload.
No current source/ownership/shape/visit proof or factory result is cached.
Seven tests pass on both source bases, including 65 exact native machine-code
pairs, forward/backward aliases, 1,000,003 aliases, multi-result IR, shared pools,
unused metadata, exception pseudo-arguments, union inputs and debug labels.
The multi-result fixture is verified as IR; this AArch64 backend does not lower
its I32 isplit. That mistaken fixture invocation and an invalid I128 constant
fixture remain in corrections alongside an unused-binding build correction.
The first prototype's five tests and output-identical screen are retained.
Tightened tests exposed deleted alias references in unused metadata; both failed
tests and their patch remain. The corrected seven-test suite passes.
The historical 55-flag cohort has eight serial ABBA/BAAB full source-to-Object
runs. It is kept separate from eight new current 60-flag runs after integrating
PR 973's independently qualified short-reduction runtime change. The current
control reproduces the author's Object 8a4c2b17...; the candidate keeps every
source, MBC, Object and complete metadata byte identical. Each source base has
both screens and fourteen successful fixture pairs with all four outputs equal.
All primary compiles are fresh source-to-Object. Builds, tests, screens, fixtures,
profiling, copying, hashing and archiving do not overlap primary timing. Every
contrary observation, including overlapping elapsed ranges and adverse RSS,
remains. These finite cohorts are descriptive, not population estimates.
The prior-control 55-flag and current-candidate 60-flag CPU profiles each retain
two completed raw sample windows and a third unsuccessful attempt (exit 255),
plus every output byte, command,
raw/mapped symbol, existing demangler source/pin and self-count table. Main-thread
waits are not CPU work; these are not phase-exclusive elapsed measurements.
Rust rebuilds and subsequent cached executable lookups are recorded separately;
no cold bootstrap claim is made. Compiler executables are excluded and pinned.
Grammar, language, checked scalar emission, finite admission, current ownership
checks and backend optimization levels are unchanged. No new runtime timing
campaign is claimed: generated machine code and complete metadata are identical
within each matched base. The full ten-second goal remains open.
This complete evidence packet is published in benchmarks at the user's request.
Run python3 replay.py for pure offline validation/numerical reconstruction.
