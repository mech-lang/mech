from pathlib import Path
import subprocess,os,json,hashlib,sys
repo=Path.cwd();root=Path('/private/tmp/mech-compact-values-current-20261114');flags=json.loads((root/'runtime-flags.json').read_text());assert len(flags)==60
old=json.loads((repo/'benchmarks/mech-deflate/native-profile/visit-predecessors-compile-apple-m3-20261114.json').read_text());control=json.loads((root/'control-build.json').read_text());env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')};env.update(flags)
cmd=[sys.executable,'benchmarks/mech-deflate/native-profile/profile_compile.py',str(root/'control'),'benchmark',str(root/'control-screen'),'compact'];(root/'control-screen-command.json').write_text(json.dumps(dict(command=cmd,flags=flags,binary_sha256=control['binary_sha256']),indent=2)+'\n');subprocess.run(cmd,env=env,cwd=repo,check=True)
expected={}
for name in ['source.mec','program.mecb','program.o','metadata.json']:
 data=(root/'control-screen'/name).read_bytes();expected[name]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
for name in ['source.mec','program.mecb']:assert expected[name]==old['output_hashes'][name]
assert expected['program.o']['sha256']=='8a4c2b172798d06252055b20398cdbf9517b4b5be76730ea1824435ef89bbba4'
(root/'author-program-check.json').write_text(json.dumps(dict(author_source='1c09216698a3f4c3d5c33da150d1a9b3d1b48eaa',report='docs/design/native-short-reduction-edges.md',source_and_mbc_match_previous=True,object_matches_author_qualified_program=True,output_hashes=expected,metadata_pin_established_by_current_control=True),indent=2,sort_keys=True)+'\n')
(root/'reference').mkdir()
for name in expected:(root/'reference'/name).write_bytes((root/'control-screen'/name).read_bytes())
(root/'reference-pins.json').write_text(json.dumps(expected,indent=2,sort_keys=True)+'\n');(root/'control-screen/output-check.json').write_text(json.dumps({k:dict(v,matches_current_control_output=True) for k,v in expected.items()},indent=2)+'\n')
print('Control reproduces the author-qualified new Object; current full-output pins established',json.dumps(expected),flush=True)
