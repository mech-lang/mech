from pathlib import Path
import os,json,subprocess,hashlib,sys
repo=Path.cwd();raw=Path('/private/tmp/mech-compact-values-current-20261114');root=Path('/private/tmp/mech-after-compaction-profile-20261114');root.mkdir(exist_ok=False)
build=json.loads((raw/'candidate-build.json').read_text());binary=raw/'candidate';assert hashlib.sha256(binary.read_bytes()).hexdigest()==build['binary_sha256'];flags=json.loads((raw/'runtime-flags.json').read_text());assert len(flags)==60
source='57376165608ec32729ff99a04b601d52d8f64950';assert subprocess.check_output(['git','diff',source,'HEAD','--','src','hosts','vendor','machines'])==b''
cmd=[sys.executable,'benchmarks/mech-deflate/native-profile/profile_compile.py',str(binary),'benchmark',str(root/'cpu'),'compact','sample'];(root/'command.json').write_text(json.dumps(dict(command=cmd,flags=flags,binary_sha256=build['binary_sha256'],source_commit=source,scope='Separate diagnostic complete compile with CPU samples; excluded from primary timing.'),indent=2)+'\n')
env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')};env.update(flags);subprocess.run(cmd,env=env,cwd=repo,check=True)
expected=json.loads((raw/'reference-pins.json').read_text())
for name,pin in expected.items():
 data=(root/'cpu'/name).read_bytes();assert dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())==pin
(root/'output-check.json').write_text(json.dumps(expected,indent=2,sort_keys=True)+'\n');print('Every profiled output matches the current author-qualified program',flush=True)
