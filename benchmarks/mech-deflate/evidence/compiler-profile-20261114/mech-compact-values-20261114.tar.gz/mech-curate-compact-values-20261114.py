from pathlib import Path
import subprocess,json,hashlib,shutil
repo=Path.cwd();packet=Path('/private/tmp/mech-compact-values-packet-20261114');assert not packet.exists()
source='57376165608ec32729ff99a04b601d52d8f64950';base='1c09216698a3f4c3d5c33da150d1a9b3d1b48eaa';oldbase='4f90b1b4f00f6abfd8c1bd4e9730da7c6f482a48';oldsource='19c1fd7aaf'
patch=subprocess.check_output(['git','diff','--binary',base,source]);assert patch==Path('/private/tmp/mech-compact-values-20261114/candidate.patch').read_bytes()==Path('/private/tmp/mech-compact-values-current-20261114/source-change.patch').read_bytes()
excluded=[]
for label,dirname in [('historical55','mech-compact-values-20261114'),('current60','mech-compact-values-current-20261114')]:
 raw=Path('/private/tmp')/dirname
 for p in sorted(raw.rglob('*')):
  if not p.is_file():continue
  rel=Path(label)/p.relative_to(raw)
  if p.name in ['control','candidate']:
   excluded.append(dict(path=rel.as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()));continue
  d=packet/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
(packet/'excluded-executables.json').write_text(json.dumps(excluded,indent=2)+'\n');(packet/'source-change.patch').write_bytes(patch)
state=dict(source_commit=source,base_commit=base,historical_source_commit=subprocess.check_output(['git','rev-parse',oldsource],text=True).strip(),historical_base_commit=oldbase,historical_control_source_commit='40c33f0c75865483fa6bc140fb9b4413d23d7cd0',patch_sha256=hashlib.sha256(patch).hexdigest(),hardware='Apple M3 Air, 8 cores (4P+4E), 16 GB, macOS 26.2',rustc=subprocess.check_output(['rustc','-Vv'],text=True),cargo=subprocess.check_output(['cargo','-V'],text=True));(packet/'source-state.json').write_text(json.dumps(state,indent=2,sort_keys=True)+'\n')
paths=subprocess.check_output(['git','diff','--name-only',oldbase,source],text=True).splitlines()
paths+=['vendor/cranelift-codegen/LICENSE','vendor/cranelift-frontend/LICENSE','vendor/cranelift-codegen-meta/LICENSE','vendor/regalloc2/LICENSE']
paths+=['Cargo.lock','.cargo/config.toml','LICENSE','hosts/gpu/src/native_artifact/AGENTS.md','hosts/gpu/tests/fixtures/native/deflate-huffman-LICENSES.md','hosts/gpu/src/native_artifact/program/runtime/composition_tests/nested_phase.rs']
paths+=['benchmarks/mech-deflate/native-profile/'+n for n in ['Cargo.lock','compile_profile.rs','profile_compile.py']]
paths+=['hosts/gpu/tests/fixtures/native/'+n+'.mec' for n in ['numeric-nested-phase','numeric-nested-phase-states','numeric-private-fixed-nested','numeric-changing-capture-tree','numeric-array-windows','numeric-multiple-children']]
for name in sorted(set(paths)):
 d=packet/'source'/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(subprocess.check_output(['git','show',source+':'+name]))
validation=packet/'validation';validation.mkdir()
for suffix in ['.json','.archive.json']:shutil.copy2(repo/('benchmarks/mech-deflate/native-profile/visit-predecessors-compile-apple-m3-20261114'+suffix),validation/('qualified-predecessors'+suffix))
shutil.copytree(Path('/private/tmp/mech-borrowed-schema-packet-20261114/licenses'),packet/'licenses')
shutil.copytree(Path('/private/tmp/mech-after-predecessors-profile-20261114'),packet/'profile')
shutil.copytree(Path('/private/tmp/mech-after-compaction-profile-20261114'),packet/'profile-current60')
demangler=Path('/private/tmp/mech-compiler-process-profile-20261114/demangler')
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:
 d=packet/'profile/demangler-source'/name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(demangler/name,d)
patterns=['mech-*compact-values*20261114.py','mech-*compact-values*driver-20261114.log','mech-profile-after-predecessors-20261114.py','mech-demangle-after-predecessors-20261114.py','mech-after-predecessors-profile-driver-20261114.log','mech-profile-after-compaction-20261114.py','mech-demangle-after-compaction-20261114.py','mech-after-compaction-profile-driver-20261114.log']
for pattern in patterns:
 for src in Path('/private/tmp').glob(pattern):
  if src.is_file():shutil.copy2(src,packet/src.name)
(packet/'README.txt').write_text('''Retired SSA value compaction, Apple M3, 2026-11-14.
The main IR contains 20,787,570 value IDs. A post-producer pass retains
1,241,393 actual definitions and remaps every use, with the original definition
order, instructions, blocks, layout, effects and metadata contracts preserved.
All external producer Value handles have been discarded before this pass runs.
Alias targets stay available until shared pooled arguments, unused jump and
exception tables, context items, union inputs and debug labels are rewritten.
The two idempotent remapping sweeps use a disjoint temporary namespace and
retain the ordinary path if that namespace would exceed BlockArg's payload.
No current source/ownership/shape/visit proof or factory result is cached.
Seven tests pass on both source bases, including 65 exact native machine-code
pairs, forward/backward aliases, 1,000,003 aliases, multi-result IR, shared pools,
unused metadata, exception pseudo-arguments, union inputs and debug labels.
The multi-result fixture is verified as IR; this AArch64 backend does not lower
its I32 isplit. That mistaken fixture invocation and an invalid I128 constant
fixture remain in corrections alongside an unused-binding build correction.
The first prototype's five tests and output-identical screen are retained.
Tightened tests exposed deleted alias references in unused metadata; both failed
tests and their patch remain. The corrected seven-test suite passes.
The historical 55-flag cohort has eight serial ABBA/BAAB full source-to-Object
runs. It is kept separate from eight new current 60-flag runs after integrating
PR 973's independently qualified short-reduction runtime change. The current
control reproduces the author's Object 8a4c2b17...; the candidate keeps every
source, MBC, Object and complete metadata byte identical. Each source base has
both screens and fourteen successful fixture pairs with all four outputs equal.
All primary compiles are fresh source-to-Object. Builds, tests, screens, fixtures,
profiling, copying, hashing and archiving do not overlap primary timing. Every
contrary observation, including overlapping elapsed ranges and adverse RSS,
remains. These finite cohorts are descriptive, not population estimates.
The prior-control 55-flag and current-candidate 60-flag CPU profiles each retain
two completed raw sample windows and a third unsuccessful attempt (exit 255),
plus every output byte, command,
raw/mapped symbol, existing demangler source/pin and self-count table. Main-thread
waits are not CPU work; these are not phase-exclusive elapsed measurements.
Rust rebuilds and subsequent cached executable lookups are recorded separately;
no cold bootstrap claim is made. Compiler executables are excluded and pinned.
Grammar, language, checked scalar emission, finite admission, current ownership
checks and backend optimization levels are unchanged. No new runtime timing
campaign is claimed: generated machine code and complete metadata are identical
within each matched base. The full ten-second goal remains open.
This complete evidence packet is published in benchmarks at the user's request.
Run python3 replay.py for pure offline validation/numerical reconstruction.
''')
print(packet,flush=True)
