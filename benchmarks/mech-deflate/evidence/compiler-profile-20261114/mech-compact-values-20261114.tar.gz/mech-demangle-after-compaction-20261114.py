from pathlib import Path
import re,json,subprocess,hashlib
root=Path('/private/tmp/mech-after-compaction-profile-20261114');paths=sorted((root/'cpu').glob('sample-*.txt'));assert len(paths)==2
exe=Path('/private/tmp/mech-compiler-process-profile-20261114/demangler/target/release/mech-profile-demangle');assert exe.is_file()
symbols=sorted(set(s for p in paths for s in re.findall(r'_R[A-Za-z0-9_]+',p.read_text())));result=subprocess.check_output([str(exe)],input='\n'.join(symbols)+'\n',text=True).splitlines();assert len(result)==len(symbols);mapping=dict(zip(symbols,result));(root/'demangled-symbols.json').write_text(json.dumps(mapping,indent=2)+'\n');(root/'demangler-use.json').write_text(json.dumps(dict(command=[str(exe)],binary_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),scope='Existing rustc-demangle tool reused; not a new build.'),indent=2)+'\n')
for p in paths:
 s=re.sub(r'_R[A-Za-z0-9_]+',lambda m:mapping[m.group(0)],p.read_text());(p.with_name(p.stem+'-demangled.txt')).write_text(s);i=s.find('Sort by top of stack');rows=[]
 for line in s[i:].splitlines()[1:]:
  m=re.match(r'\s+(.*?)\s+\(in (.*?)\)\s+(\d+)\s*$',line)
  if m:rows.append(dict(symbol=m.group(1),image=m.group(2),self_samples=int(m.group(3))))
  elif rows:break
 (p.with_name(p.stem+'-self.json')).write_text(json.dumps(rows,indent=2)+'\n');print(p.name,[(x['self_samples'],x['symbol'][:210]) for x in rows[:12]])
