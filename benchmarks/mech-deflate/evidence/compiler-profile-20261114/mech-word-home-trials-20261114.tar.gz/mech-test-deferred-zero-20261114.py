from pathlib import Path
import subprocess,json,time,hashlib,os
repo=Path.cwd();root=Path('/private/tmp/mech-deferred-zero-20261114');probe=root/'probes';build=json.loads((root/'candidate-build.json').read_text());assert build['exit_code']==0
rows=[json.loads(line) for line in (root/'candidate-build.jsonl').read_text().splitlines()];deps={}
for name in ['cranelift_codegen','cranelift_frontend']:
 matches=[r for r in rows if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')==name and r.get('profile',{}).get('opt_level')=='3'];assert len(matches)==1
 paths=[p for p in matches[0]['filenames'] if p.endswith('.rlib')];assert len(paths)==1;deps[name]=paths[0]
cmd=['rustc','--edition=2024','--crate-name','ssa_words_probe','-C','opt-level=3','-C','lto=thin','-D','warnings','-L','dependency=/private/tmp/mech-level12-compile-target/compiler/deps','--cfg','feature="canonical-native-program"']
for name,path in deps.items():cmd+=['--extern',name+'='+path]
cmd+=['--test',str(probe/'ssa-words-probe.rs'),'-o',str(probe/'bin/ssa-words-tests')]
patch=subprocess.check_output(['git','diff','HEAD','--binary']);assert hashlib.sha256(patch).hexdigest()==build['patch_sha256'];(root/'tested-source.patch').write_bytes(patch)
record={'command':cmd,'dependencies':{n:{'path':p,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()} for n,p in deps.items()},'head':build['head'],'patch_sha256':build['patch_sha256'],'scope':'Exact production Words and its own tests, current candidate compiler-profile Cranelift libraries; unused CodePlan and error/offset interface shim disclosed in probe source; separate full compiler uses actual production interfaces.'}
start=time.perf_counter();p=subprocess.run(cmd,capture_output=True);record.update(exit_code=p.returncode,seconds=time.perf_counter()-start);(probe/'build.json').write_text(json.dumps(record,indent=2)+'\n');(probe/'build.stdout').write_bytes(p.stdout);(probe/'build.stderr').write_bytes(p.stderr);print('BUILD',p.returncode,flush=True)
if p.returncode:print(p.stderr.decode());raise SystemExit(p.returncode)
cmd=[str(probe/'bin/ssa-words-tests'),'--test-threads=2'];start=time.perf_counter();p=subprocess.run(cmd,capture_output=True);(probe/'tests.stdout').write_bytes(p.stdout);(probe/'tests.stderr').write_bytes(p.stderr);(probe/'tests.json').write_text(json.dumps({'command':cmd,'exit_code':p.returncode,'seconds':time.perf_counter()-start},indent=2)+'\n');print(p.stdout.decode());print(p.stderr.decode());assert subprocess.check_output(['git','diff','HEAD','--binary'])==patch;raise SystemExit(p.returncode)
