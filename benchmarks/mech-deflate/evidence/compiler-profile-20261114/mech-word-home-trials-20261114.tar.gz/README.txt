Word-home compiler experiments, Apple M3, 2026-11-14.
Deferred-zero initialization is not retained. The direct-indexing trial decision,
all favorable/adverse phases, raw observations, tested source snapshots and
base-plus-patch identities are recorded separately. No trial observations are
pooled. Compiler/probe executables and the unused prepared allocator archive are
excluded and hash-pinned. The 81-case runtime corpus was prepared but no runtime
worker was built/executed. Complete level-12 Objects are identical in both trials;
only two diagnostic metadata instruction counts differ in the zero-seed trial.
Word-home lookup preserves every metadata byte too. All fourteen fixture pairs
match in each trial. Full locked compiler-profile builds use actual production
interfaces; the focused Words harness discloses its unused CodePlan/error glue.
Pure offline replay validates the source patches, stored measurements, test logs,
SSA counts, fixture and program outputs, metadata differences and numerical
summaries. It needs no compiler, benchmark execution, original scratch paths or
network. It does not rerun historical measurements. See report.md and summary.json.
The sub-ten-second complete-compilation goal remains open.
