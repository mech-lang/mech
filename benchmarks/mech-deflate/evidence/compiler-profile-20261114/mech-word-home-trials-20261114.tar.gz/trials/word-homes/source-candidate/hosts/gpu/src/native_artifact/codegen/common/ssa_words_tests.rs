//! SSA boundary transport must keep the home's actual alias classification.
use super::*;
use cranelift_codegen::ir::{AbiParam, AliasRegion, Function, Opcode};
use cranelift_frontend::FunctionBuilderContext;

#[test]
fn ssa_home_spills_and_reloads_keep_the_boundary_memory_region() {
    for flags in [
        MemFlags::new(),
        MemFlags::new()
            .with_alias_region(Some(AliasRegion::Table))
            .with_notrap(),
        MemFlags::new()
            .with_alias_region(Some(AliasRegion::Heap))
            .with_notrap(),
    ] {
        let mut function = Function::new();
        function.signature.params.push(AbiParam::new(types::I64));
        function.signature.returns.push(AbiParam::new(types::I64));
        let mut context = FunctionBuilderContext::new();
        {
            let mut b = FunctionBuilder::new(&mut function, &mut context);
            let entry = b.create_block();
            b.append_block_params_for_function_params(entry);
            b.switch_to_block(entry);
            let locals = b.block_params(entry)[0];
            let variable = b.declare_var(types::I64);
            let initial = b.ins().iconst(types::I64, 41);
            b.def_var(variable, initial);
            let words = Words {
                variables: VariableHomes::new(BTreeMap::from([(3, (variable, flags))])),
                native_extent_slots: BTreeMap::new(),
                native_extent_values: RefCell::new(BTreeMap::new()),
            };
            let updated = b.ins().iadd_imm(initial, 1);
            words.write(&mut b, 3, updated);
            words.spill_all(&mut b, locals).unwrap();
            words
                .reload_live(&mut b, locals, &BTreeSet::from([3]))
                .unwrap();
            let value = words.read(&mut b, 3);
            b.ins().return_(&[value]);
            b.seal_all_blocks();
            b.finalize();
        }
        let operations = function
            .layout
            .blocks()
            .flat_map(|block| function.layout.block_insts(block))
            .filter(|&inst| {
                matches!(
                    function.dfg.insts[inst].opcode(),
                    Opcode::Load | Opcode::Store
                )
            })
            .map(|inst| function.dfg.insts[inst].memflags().unwrap())
            .collect::<Vec<_>>();
        assert_eq!(
            operations,
            vec![flags, flags],
            "a spill in another region cannot invalidate the boundary's cached load"
        );
    }
}

#[test]
fn direct_homes_preserve_sparse_extreme_and_ordered_slots() {
    let sets = [
        vec![],
        vec![0],
        vec![usize::MAX],
        (0..4096).collect(),
        (1_000_000..1_004_096).collect(),
        (usize::MAX - 4095..=usize::MAX).collect(),
        (0..4096).filter(|n| n % 3 != 1).collect(),
        vec![0, usize::MAX],
        vec![7, 1_000_000, usize::MAX - 1],
    ];
    for slots in sets {
        let expected = slots
            .iter()
            .enumerate()
            .map(|(index, &slot)| {
                let flags = match index % 3 {
                    0 => MemFlags::new(),
                    1 => MemFlags::new().with_alias_region(Some(AliasRegion::Table)),
                    _ => MemFlags::new()
                        .with_alias_region(Some(AliasRegion::Heap))
                        .with_notrap(),
                };
                (slot, (Variable::from_u32(index as u32), flags))
            })
            .collect::<BTreeMap<_, _>>();
        let homes = VariableHomes::new(expected.clone());
        assert_eq!(homes.slots(), expected.keys().copied().collect());
        for &slot in &slots {
            assert_eq!(homes.get(slot), expected.get(&slot));
            assert_eq!(homes[&slot], expected[&slot]);
            for neighbor in [slot.checked_sub(1), slot.checked_add(1)]
                .into_iter()
                .flatten()
            {
                assert_eq!(homes.get(neighbor), expected.get(&neighbor));
            }
        }
        let mut state = 0x1eaf_973c_27d1_3819u64;
        for _ in 0..10_000 {
            state ^= state << 13;
            state ^= state >> 7;
            state ^= state << 17;
            let slot = state as usize;
            assert_eq!(homes.get(slot), expected.get(&slot));
        }
        for slot in [0, 1, usize::MAX - 1, usize::MAX] {
            assert_eq!(homes.get(slot), expected.get(&slot));
        }
        if let VariableHomes::Dense { values, .. } = &homes {
            assert!(values.len() <= 2 * expected.len());
        }
    }
    let flags = MemFlags::new();
    let variable = Variable::from_u32(0);
    assert!(matches!(
        VariableHomes::new(BTreeMap::from([
            (100, (variable, flags)),
            (101, (variable, flags))
        ])),
        VariableHomes::Dense { .. }
    ));
    assert!(matches!(
        VariableHomes::new(BTreeMap::from([
            (0, (variable, flags)),
            (usize::MAX, (variable, flags))
        ])),
        VariableHomes::Sparse(_)
    ));
}
