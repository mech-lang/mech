#![allow(dead_code)]
// Exact production Words implementation and its own tests. Only the unused
// CodePlan interface and error/offset glue are supplied by this focused probe;
// the separately built full compiler uses the actual production interfaces.
mod native_artifact {
    #[derive(Debug)]
    pub enum NativeCompileError {
        InvalidPlan { node: Option<usize>, reason: &'static str },
    }
    pub mod compiler {
        use super::NativeCompileError;
        pub(in crate::native_artifact) fn offset(index: usize) -> Result<i32, NativeCompileError> {
            index.checked_mul(8).and_then(|v| i32::try_from(v).ok())
                .ok_or(NativeCompileError::InvalidPlan { node: None, reason: "transport offset exceeds ABI" })
        }
    }
    pub mod codegen {
        pub mod control {
            pub mod plan {
                #[derive(Clone, Copy)]
                pub struct CodePlan<'a>(std::marker::PhantomData<&'a ()>);
                pub struct Value(u64);
                impl Value { pub fn get(&self) -> u64 { self.0 } }
                impl CodePlan<'_> {
                    pub fn constant_count(self) -> usize { unreachable!("unused interface") }
                    pub fn constant(self, _: usize) -> Result<(Value, Option<u64>), crate::native_artifact::NativeCompileError> { unreachable!("unused interface") }
                }
            }
        }
        #[path = "/Users/cim310/.codex/worktrees/level12-compile-profile/mech/hosts/gpu/src/native_artifact/codegen/common/ssa_words.rs"]
        pub mod ssa_words;
    }
}
