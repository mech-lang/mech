//! SSA boundary transport must keep the home's actual alias classification.
use super::*;
use cranelift_codegen::ir::{AbiParam, AliasRegion, Function, Opcode};
use cranelift_frontend::FunctionBuilderContext;

fn zero_default_cfg(deferred: bool, looped: bool, boundary: bool) -> Function {
    let mut function = Function::new();
    function.signature.params = vec![AbiParam::new(types::I64); 2];
    function.signature.returns.push(AbiParam::new(types::I64));
    let mut context = FunctionBuilderContext::new();
    let mut b = FunctionBuilder::new(&mut function, &mut context);
    let entry = b.create_block();
    let yes = b.create_block();
    let no = b.create_block();
    let join = b.create_block();
    b.append_block_params_for_function_params(entry);
    b.switch_to_block(entry);
    b.seal_block(entry);
    let input = b.block_params(entry)[0];
    let locals = b.block_params(entry)[1];
    let zero = b.ins().iconst(types::I64, 0);
    let constant = b.ins().iconst(types::I64, 41);
    let words = Words::new_with_zero_defaults(
        &mut b,
        BTreeSet::from([0, 1, 2, 3]),
        |_, slot| {
            Ok(match slot {
                0 => Some(input),
                1 => Some(constant),
                _ => (!deferred).then_some(zero),
            })
        },
        |_| MemFlags::new(),
    )
    .unwrap();
    b.ins().brif(input, yes, &[], no, &[]);
    b.switch_to_block(yes);
    b.seal_block(yes);
    let updated = b.ins().iadd_imm(input, 1);
    words.write(&mut b, 2, updated);
    b.ins().jump(join, &[]);
    b.switch_to_block(no);
    b.seal_block(no);
    b.ins().jump(join, &[]);
    b.switch_to_block(join);
    b.seal_block(join);
    if looped {
        let header = b.create_block();
        let body = b.create_block();
        let exit = b.create_block();
        let counter = b.declare_var(types::I64);
        b.def_var(counter, zero);
        b.ins().jump(header, &[]);
        b.switch_to_block(header);
        let index = b.use_var(counter);
        let condition = b.ins().icmp(
            cranelift_codegen::ir::condcodes::IntCC::UnsignedLessThan,
            index,
            input,
        );
        b.ins().brif(condition, body, &[], exit, &[]);
        b.switch_to_block(body);
        b.seal_block(body);
        let previous = words.read(&mut b, 2);
        let padding = words.read(&mut b, 3);
        let updated = b.ins().iadd(previous, padding);
        let updated = b.ins().iadd_imm(updated, 1);
        words.write(&mut b, 2, updated);
        let next = b.ins().iadd_imm(index, 1);
        b.def_var(counter, next);
        b.ins().jump(header, &[]);
        b.seal_block(header);
        b.switch_to_block(exit);
        b.seal_block(exit);
    }
    if boundary {
        // The unwritten padding lane must spill as zero, never load from an
        // absent entry locals array, and retain its boundary memory policy.
        let live = BTreeSet::from([2, 3]);
        words.spill_live(&mut b, locals, &live).unwrap();
        words.reload_live(&mut b, locals, &live).unwrap();
    }
    let input = words.read(&mut b, 0);
    let constant = words.read(&mut b, 1);
    let value = words.read(&mut b, 2);
    let padding = words.read(&mut b, 3);
    let result = b.ins().iadd(input, constant);
    let result = b.ins().iadd(result, value);
    let result = b.ins().iadd(result, padding);
    b.ins().return_(&[result]);
    b.seal_all_blocks();
    b.finalize();
    function
}

fn machine(function: Function) -> Vec<u8> {
    use cranelift_codegen::settings::Configurable;
    let mut flags = cranelift_codegen::settings::builder();
    flags.set("opt_level", "speed").unwrap();
    let flags = cranelift_codegen::settings::Flags::new(flags);
    cranelift_codegen::verify_function(&function, &flags).unwrap();
    let isa = cranelift_codegen::isa::lookup_by_name("aarch64")
        .unwrap()
        .finish(flags)
        .unwrap();
    cranelift_codegen::Context::for_function(function)
        .compile(&*isa, &mut Default::default())
        .unwrap()
        .buffer
        .data()
        .to_vec()
}

#[test]
fn deferred_zero_preserves_branch_loop_padding_and_boundary_machine_code() {
    for looped in [false, true] {
        for boundary in [false, true] {
            assert_eq!(
                machine(zero_default_cfg(true, looped, boundary)),
                machine(zero_default_cfg(false, looped, boundary)),
                "looped={looped}, boundary={boundary}"
            );
        }
    }
}

#[test]
fn zero_defaults_do_not_emit_entry_loads_or_unused_initializers() {
    let mut function = Function::new();
    function.signature.returns.push(AbiParam::new(types::I64));
    let mut context = FunctionBuilderContext::new();
    let mut b = FunctionBuilder::new(&mut function, &mut context);
    let entry = b.create_block();
    b.switch_to_block(entry);
    b.seal_block(entry);
    let words = Words::new_with_zero_defaults(
        &mut b,
        (0..4096).collect(),
        |_, _| Ok(None),
        |_| MemFlags::new(),
    )
    .unwrap();
    assert_eq!(b.func.layout.block_insts(entry).count(), 0);
    let value = words.read(&mut b, 4095);
    b.ins().return_(&[value]);
    b.seal_all_blocks();
    b.finalize();
    let value = function.dfg.resolve_aliases(value);
    let inst = function.dfg.value_def(value).unwrap_inst();
    assert!(matches!(
        function.dfg.insts[inst],
        cranelift_codegen::ir::InstructionData::UnaryImm { imm, .. } if imm.bits() == 0
    ));
    assert_eq!(function.layout.block_insts(entry).count(), 2);
    cranelift_codegen::verify_function(
        &function,
        &cranelift_codegen::settings::Flags::new(cranelift_codegen::settings::builder()),
    )
    .unwrap();
}

#[test]
fn ssa_home_spills_and_reloads_keep_the_boundary_memory_region() {
    for flags in [
        MemFlags::new(),
        MemFlags::new()
            .with_alias_region(Some(AliasRegion::Table))
            .with_notrap(),
        MemFlags::new()
            .with_alias_region(Some(AliasRegion::Heap))
            .with_notrap(),
    ] {
        let mut function = Function::new();
        function.signature.params.push(AbiParam::new(types::I64));
        function.signature.returns.push(AbiParam::new(types::I64));
        let mut context = FunctionBuilderContext::new();
        {
            let mut b = FunctionBuilder::new(&mut function, &mut context);
            let entry = b.create_block();
            b.append_block_params_for_function_params(entry);
            b.switch_to_block(entry);
            let locals = b.block_params(entry)[0];
            let variable = b.declare_var(types::I64);
            let initial = b.ins().iconst(types::I64, 41);
            b.def_var(variable, initial);
            let words = Words {
                variables: BTreeMap::from([(3, (variable, flags))]),
                native_extent_slots: BTreeMap::new(),
                native_extent_values: RefCell::new(BTreeMap::new()),
            };
            let updated = b.ins().iadd_imm(initial, 1);
            words.write(&mut b, 3, updated);
            words.spill_all(&mut b, locals).unwrap();
            words
                .reload_live(&mut b, locals, &BTreeSet::from([3]))
                .unwrap();
            let value = words.read(&mut b, 3);
            b.ins().return_(&[value]);
            b.seal_all_blocks();
            b.finalize();
        }
        let operations = function
            .layout
            .blocks()
            .flat_map(|block| function.layout.block_insts(block))
            .filter(|&inst| {
                matches!(
                    function.dfg.insts[inst].opcode(),
                    Opcode::Load | Opcode::Store
                )
            })
            .map(|inst| function.dfg.insts[inst].memflags().unwrap())
            .collect::<Vec<_>>();
        assert_eq!(
            operations,
            vec![flags, flags],
            "a spill in another region cannot invalidate the boundary's cached load"
        );
    }
}
