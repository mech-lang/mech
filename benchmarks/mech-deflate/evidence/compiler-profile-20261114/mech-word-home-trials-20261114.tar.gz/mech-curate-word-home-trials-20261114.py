from pathlib import Path
import subprocess,json,hashlib,shutil
repo=Path.cwd();packet=Path('/private/tmp/mech-word-home-trials-packet-20261114');assert not packet.exists();roots={n:Path('/private/tmp/mech-'+n+'-20261114') for n in ['deferred-zero','word-homes']};base=json.loads((roots['word-homes']/'candidate-build.json').read_text())['head'];current=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();excluded=[]
for label,raw in roots.items():
 assert json.loads((raw/'candidate-build.json').read_text())['head']==base
 assert (raw/'decision.json').exists() and (raw/'source-candidate').is_dir()
 for p in sorted(raw.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(raw);dest=Path('trials')/label/rel
  if rel.as_posix() in ['control','candidate','runtime-worker/libmimalloc.a'] or rel.parts[:2]==('probes','bin'):
   excluded.append({'path':dest.as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()});continue
  d=packet/dest;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
control=json.loads((roots['word-homes']/'control-origin.json').read_text());assert subprocess.check_output(['git','diff',control['source_commit'],base,'--','src','hosts','vendor','machines','Cargo.toml','Cargo.lock','.cargo/config.toml'])==b''
state={'source_commit':current,'base_commit':base,'control_source_commit':control['source_commit'],'hardware':'Apple M3 Air, 8 cores (4P+4E), 16 GB, macOS 26.2','rustc':subprocess.check_output(['rustc','-Vv'],text=True),'cargo':subprocess.check_output(['cargo','-V'],text=True)}
(packet/'source-state.json').write_text(json.dumps(state,indent=2,sort_keys=True)+'\n');(packet/'excluded-executables.json').write_text(json.dumps(excluded,indent=2)+'\n')
paths=['Cargo.toml','Cargo.lock','.cargo/config.toml','LICENSE','hosts/gpu/src/native_artifact/AGENTS.md','hosts/gpu/src/native_artifact/codegen/common/ssa_words.rs','hosts/gpu/src/native_artifact/codegen/common/ssa_words_tests.rs','hosts/gpu/src/native_artifact/program/compact/emit.rs','hosts/gpu/src/native_artifact/codegen/control/plan.rs','vendor/cranelift-frontend/src/ssa.rs','hosts/gpu/tests/fixtures/native/deflate-huffman-LICENSES.md']
paths+=['benchmarks/mech-deflate/native-profile/'+n for n in ['Cargo.toml','Cargo.lock','compile_profile.rs','profile_compile.py']]
for name in paths:
 d=packet/'source'/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(subprocess.check_output(['git','show',base+':'+name]))
shutil.copytree(Path('/private/tmp/mech-borrowed-schema-packet-20261114/licenses'),packet/'licenses')
for pattern in ['mech-*deferred-zero*20261114.py','mech-*word-home*20261114.py','mech-*deferred-zero*20261114.log','mech-*word-home*20261114.log']:
 for p in Path('/private/tmp').glob(pattern):
  if p.is_file():shutil.copy2(p,packet/p.name)
shutil.copy2(Path('/private/tmp/mech-word-home-trials-replay-20261114.py'),packet/'replay.py')
shutil.copy2(repo/'docs/design/native-word-home-compile-profile.md',packet/'report.md')
(packet/'README.txt').write_text('''Word-home compiler experiments, Apple M3, 2026-11-14.
Deferred-zero initialization is not retained. The direct-indexing trial decision,
all favorable/adverse phases, raw observations, tested source snapshots and
base-plus-patch identities are recorded separately. No trial observations are
pooled. Compiler/probe executables and the unused prepared allocator archive are
excluded and hash-pinned. The 81-case runtime corpus was prepared but no runtime
worker was built/executed. Complete level-12 Objects are identical in both trials;
only two diagnostic metadata instruction counts differ in the zero-seed trial.
Word-home lookup preserves every metadata byte too. All fourteen fixture pairs
match in each trial. Full locked compiler-profile builds use actual production
interfaces; the focused Words harness discloses its unused CodePlan/error glue.
Pure offline replay validates the source patches, stored measurements, test logs,
SSA counts, fixture and program outputs, metadata differences and numerical
summaries. It needs no compiler, benchmark execution, original scratch paths or
network. It does not rerun historical measurements. See report.md and summary.json.
The sub-ten-second complete-compilation goal remains open.
''');print(packet)
