from pathlib import Path
import json,hashlib,re,statistics
root=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
def pin(p):
 data=p.read_bytes();return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def changes(a,b,path=''):
 if type(a)!=type(b):return {path:(a,b)}
 if isinstance(a,dict):
  assert a.keys()==b.keys();out={}
  for k in a:out.update(changes(a[k],b[k],path+'/'+k))
  return out
 if isinstance(a,list):
  assert len(a)==len(b);out={}
  for i,(x,y) in enumerate(zip(a,b)):out.update(changes(x,y,path+'/'+str(i)))
  return out
 return {} if a==b else {path:(a,b)}
def apply_patch(base,patch):
 lines=base.splitlines(keepends=True);out=[];cursor=0;diff=patch.splitlines(keepends=True);i=0
 while i<len(diff):
  match=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',diff[i])
  if not match:i+=1;continue
  at=int(match[1])-1;assert at>=cursor;out.extend(lines[cursor:at]);cursor=at;old_count=new_count=0;i+=1
  while i<len(diff) and not diff[i].startswith('@@ '):
   line=diff[i];tag=line[:1];assert tag in [' ','+','-']
   if tag in [' ','-']:assert lines[cursor]==line[1:];cursor+=1;old_count+=1
   if tag in [' ','+']:out.append(line[1:]);new_count+=1
   i+=1
  assert old_count==int(match[2] or 1) and new_count==int(match[4] or 1)
 out.extend(lines[cursor:]);return ''.join(out)
state=read(root/'source-state.json');excluded={r['path']:r for r in read(root/'excluded-executables.json')};results={}
base_order=['control-1','candidate-1','candidate-2','control-2','candidate-3','control-3','control-4','candidate-4']
stages=[('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]
fields=['canonical_lowering_seconds','preparation_seconds','numeric_generation_seconds','source_cfg_seconds','cleanup_seconds','compaction_seconds','cleanup_including_compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']
for label,test_count in [('deferred-zero',3),('word-homes',2)]:
 order=base_order+(['control-5','candidate-5','candidate-6','control-6','candidate-7','control-7','control-8','candidate-8'] if label=='word-homes' else [])
 raw=root/'trials'/label;build=read(raw/'candidate-build.json');control=read(raw/'control-origin.json');flags=read(raw/'runtime-flags.json');assert len(flags)==60 and build['exit_code']==0 and build['head']==state['base_commit']
 assert pin(raw/'candidate.patch')['sha256']==build['patch_sha256'];assert pin(raw/'tested-source.patch')==pin(raw/'candidate.patch')
 for variant,binary_sha in [('control',control['sha256']),('candidate',build['binary_sha256'])]:assert excluded['trials/'+label+'/'+variant]['sha256']==binary_sha
 sections=(raw/'candidate.patch').read_text().split('diff --git ')[1:];assert len(sections)==(3 if label=='deferred-zero' else 2)
 for section in sections:
  m=re.match(r'a/(\S+) b/(\S+)\n',section);assert m and m[1]==m[2];name=m[1];assert apply_patch((root/'source'/name).read_text(),section)==(raw/'source-candidate'/name).read_text()
 assert read(raw/'probes/build.json')['exit_code']==read(raw/'probes/tests.json')['exit_code']==0
 assert read(raw/'probes/build.json')['patch_sha256']==build['patch_sha256'];assert f'test result: ok. {test_count} passed; 0 failed;' in (raw/'probes/tests.stdout').read_text()
 reference=raw/'reference';expected=read(raw/'reference-pins.json');assert all(pin(reference/n)==p for n,p in expected.items());rows=read(raw/'cohort.json');assert [r['name'] for r in rows]==order
 observed={};outputs={}
 for name in ['candidate-screen','control-screen',*order]:
  d=raw/name;variant=name.split('-')[0];compile=read(d/'compile.json');process=read(d/'process.json');command=read(raw/(name+'-command.json'));assert process['exit_code']==0 and process['samples']==0 and process['sampling_error'] is None and command['flags']==flags
  assert command['binary_sha256']==(control['sha256'] if variant=='control' else build['binary_sha256']);assert process['source']=='benchmark' and process['mode']=='compact'
  checks=read(d/'output-check.json')
  for n in ['source.mec','program.mecb','program.o','metadata.json']:
   p=pin(d/n);assert p['sha256']==checks[n]['sha256'] and p['bytes']==checks[n]['bytes'];same=(d/n).read_bytes()==(reference/n).read_bytes();assert same==checks[n]['matches_current_control_output']
   if n!='metadata.json' or label=='word-homes' or variant=='control':assert same
  metadata_diff=changes(read(reference/'metadata.json'),read(d/'metadata.json'))
  expected_diff={'/cleanup/before_instructions':(1263768,1263770),'/cleanup/after_instructions':(141307,141309)} if label=='deferred-zero' and variant=='candidate' else {}
  assert metadata_diff==expected_diff
  output_pins={n:pin(d/n) for n in expected}
  if variant in outputs:assert outputs[variant]==output_pins
  else:outputs[variant]=output_pins
  stamps=[json.loads(line) for line in (d/'stages.jsonl').read_text().splitlines()];elapsed=lambda prefix:next(r['elapsed'] for r in stamps if r['line'].startswith(prefix));values={key:elapsed(end)-elapsed(begin) for key,begin,end in stages};values['compaction_seconds']=elapsed('compact-stage: CFG cleanup')-elapsed('compact-stage: compact values before=');values['cleanup_including_compaction_seconds']=values['cleanup_seconds']+values['compaction_seconds'];log=(d/'stderr.log').read_text()
  for key,pattern in [('max_rss_bytes',r'(\d+)  maximum resident set size'),('instructions',r'(\d+)  instructions retired'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]:values[key]=int(re.search(pattern,log)[1])
  before=int(next(r['line'] for r in stamps if r['line'].startswith('compact-stage: compact values before=')).split('=')[-1]);after=int(next(r['line'] for r in stamps if r['line'].startswith('compact-values: retained=')).split('=')[-1]);assert (before,after)==((20787574,1241395) if label=='deferred-zero' and variant=='candidate' else (20787570,1241393))
  values.update(compiler_seconds=compile['total_seconds'],whole_process_seconds=process['elapsed_seconds'])
  for p in ['parse','catalog','frontend','artifact','encode','native']:values[p+'_seconds']=next(r['seconds'] for r in compile['phases'] if r['phase']==p)
  if name in order:
   row=next(r for r in rows if r['name']==name);assert row['variant']==variant and row['compile']==compile and row['process']==process and row['files']==checks
   for key in fields:assert values[key]==row[key]
   observed[name]=values
 qualified={}
 for key in observed[order[0]]:
  q={v:[observed[n][key] for n in order if n.startswith(v)] for v in ['control','candidate']};q['mean_reduction_fraction']=1-statistics.mean(q['candidate'])/statistics.mean(q['control']);qualified[key]=q
 assert qualified==read(raw/'numerical-summary.json')
 blocks=[]
 for names in [order[i:i+4] for i in range(0,len(order),4)]:blocks.append({'order':names,'compiler_mean_change_percent':100*(statistics.mean(observed[n]['compiler_seconds'] for n in names if n.startswith('candidate'))/statistics.mean(observed[n]['compiler_seconds'] for n in names if n.startswith('control'))-1)})
 fixtures=read(raw/'fixture-results.json');assert len(fixtures)==14
 for fixture in fixtures:
  name=fixture['fixture'].split('/')[-1].removesuffix('.mec').split(':')[-1]
  variants=fixture['variants'];assert fixture['all_outputs_match'] and variants['control']==variants['candidate'] and variants['control']['exit_code']==0
  for variant in variants:
   for n,p in variants[variant]['files'].items():assert pin(raw/'fixtures'/name/variant/n)==p
 if label=='word-homes':
  before=(root/'source/hosts/gpu/src/native_artifact/codegen/common/ssa_words.rs').read_text();after=(raw/'source-candidate/hosts/gpu/src/native_artifact/codegen/common/ssa_words.rs').read_text();marker='impl Words {';normalized=after[after.index(marker):].replace('variables: VariableHomes::new(variables),','variables,').replace('&self.variables.slots()','&self.variables.keys().copied().collect()');assert normalized==before[before.index(marker):];proof=read(raw/'source-equivalence-check.json');assert hashlib.sha256(normalized.encode()).hexdigest()==proof['normalized_words_impl_sha256'] and proof['dense_capacity_bound_per_home']==2
 separate={}
 if label=='word-homes':
  for cohort,part in [('primary',slice(0,4)),('repeat',slice(4,8))]:
   q={}
   for key,values in qualified.items():
    v={variant:values[variant][part] for variant in ['control','candidate']};v['mean_reduction_fraction']=1-statistics.mean(v['candidate'])/statistics.mean(v['control']);q[key]=v
   assert q==read(raw/('numerical-summary-'+cohort+'.json'));separate[cohort]=q
 results[label]={'decision':read(raw/'decision.json'),'candidate_patch_sha256':build['patch_sha256'],'compiler_binary_sha256':{'control':control['sha256'],'candidate':build['binary_sha256']},'compiler_rebuild_seconds':build['seconds'],'focused_tests_passed':test_count,'fixtures_passed':14,'output_hashes':outputs,'blocks':blocks,'qualified':qualified,'separate_cohorts':separate}
summary={'source_commit':state['source_commit'],'base_commit':state['base_commit'],'control_source_commit':state['control_source_commit'],'hardware':state['hardware'],'trials':results,'scope':[
 'Separate serial ABBA/BAAB full-source cohorts: eight observations for deferred zero and sixteen for indexed homes, including a disclosed independent repeat. Original/repeat summaries and all four indexed-home block directions remain. Screens excluded; same 60 runtime flags and optimized compiler profile. Trials are not pooled.',
 'Builds, tests, corpus preparation, copying, hashing and archive work do not overlap primary timings. Compiler rebuilds use existing caches and are excluded from Mech compilation; no cold-bootstrap comparison.',
 'Deferred-zero initialization is not retained. Its Object is identical; only two diagnostic metadata instruction counts differ by two. Three focused tests include four identical machine-code comparisons. No new compressor-runtime latency campaign is claimed; the 81-case corpus was prepared but not executed.',
 'The word-home lookup trial preserves declaration/initialization and all Words method bodies after private storage normalization. Dense capacity is bounded at twice the home count; sparse and overflow cases retain ordered maps. Two tests include 90000 randomized probes and actual boundary memory-region checks.',
 'Every source, MBC, Object and complete metadata byte matches for the word-home trial and all fourteen fixture pairs of both trials. All fresh shape/factory/visit/ownership checks, constant validation, checked errors, resource admission, grammar, language and scalar emission remain.',
 'The sub-ten-second full-compilation goal remains open. Offline replay checks stored data and reconstructs summaries without compilers, benchmark execution, scratch paths or network; it does not rerun original measurements.'
]}
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
