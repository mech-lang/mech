from pathlib import Path
import datetime,json,os,re,subprocess,time
repo=Path.cwd()
root=Path('/private/tmp/mech-dimension-declaration-scan-20261115')
state=json.loads((root/'source-state.json').read_text())
assert subprocess.check_output(['git','diff','--binary'])==(root/'candidate.patch').read_bytes()
out=root/'core-tests'
out.mkdir(exist_ok=False)
env=dict(os.environ,CARGO_TARGET_DIR='/private/tmp/mech-level12-core-test-target',CARGO_INCREMENTAL='0')
assert not env.get('RUSTFLAGS') and not env.get('CARGO_ENCODED_RUSTFLAGS')
common=['cargo','+nightly-2026-03-03','test','--locked','--offline','--release','-j2','--manifest-path','src/core/Cargo.toml','--no-default-features']
contracts=['type_system_builtin','type_system_contract','type_system_conversion','type_system_solver','schema_contract','dimension_contract','schema_dimension_relations','canonical_schema_vectors','kind_scheme_contract','canonical_type_contract']
command=[*common]
for name in contracts:command+=['--test',name]
stages=[
 ('unit',[*common,'--lib']),
 ('contracts',command),
 ('serde-vectors',[*common,'--features','serde','--test','canonical_schema_vectors']),
 ('no-std',['cargo','+nightly-2026-03-03','check','--locked','--offline','--release','-j1','--manifest-path','src/core/Cargo.toml','--no-default-features','--features','no_std','--lib']),
]
records=[]
for stage,command in stages:
    assert subprocess.check_output(['git','diff','--binary'])==(root/'candidate.patch').read_bytes()
    row={'stage':stage,'command':command,'state':'running','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':state['base_commit'],'patch_sha256':state['patch_sha256']}
    records.append(row);(out/'pipeline.json').write_text(json.dumps(records,indent=2)+'\n')
    start=time.monotonic()
    with (out/(stage+'.stdout.log')).open('w') as stdout,(out/(stage+'.stderr.log')).open('w') as stderr:
        result=subprocess.run(command,env=env,stdout=stdout,stderr=stderr)
    row.update(state='complete' if result.returncode==0 else 'failed',exit_code=result.returncode,seconds=time.monotonic()-start)
    if result.returncode==0 and stage!='no-std':
        summaries=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed;', (out/(stage+'.stdout.log')).read_text())
        assert summaries and all(failed=='0' for _,failed in summaries)
        row['passed']=sum(int(passed) for passed,_ in summaries)
        row['suites']=len(summaries)
    (out/'pipeline.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    assert result.returncode==0
assert subprocess.check_output(['git','diff','--binary'])==(root/'candidate.patch').read_bytes()
