from pathlib import Path
import hashlib, json, os, shutil, subprocess, time, sys

root = Path('/private/tmp/mech-dimension-declaration-scan-20261115')
link = Path('/private/tmp/mech-pr973-refresh-20261115/link')
capture = json.loads((link / 'capture/link-command.json').read_text())
flags = json.loads((root / 'runtime-flags.json').read_text())
assert len(flags) == 61
env = {k: v for k, v in os.environ.items() if not k.startswith('MECH_')}
threads=int(sys.argv[3]);assert threads in [0,2]
env.update(flags);env['MECH_COMPACT_COMPILE_THREADS']=str(threads)
env['ZERO_AR_DATE'] = '1'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
records = []
for variant, name in [(sys.argv[1], sys.argv[2])]:
    directory = root / name
    assert not directory.exists()
    directory.mkdir()
    for item in capture['inputs']:
        if Path(item['source']).name != 'program.o':
            assert sha(Path(item['source'])) == item['sha256']
    run_env = dict(env)
    compile_command = [str(root / variant), 'benchmark', str(directory), 'compact']
    link_command = capture['command']
    (directory / 'command.json').write_text(json.dumps({'compile': compile_command, 'link': link_command, 'flags': {k:v for k,v in run_env.items() if k.startswith('MECH_')}, 'ZERO_AR_DATE': '1', 'compiler_sha256': sha(root / variant), 'adapter_preparation': 'Frozen adapter objects reused; all non-program input hashes checked before timing.'}, indent=2) + '\n')
    with (directory / 'compiler.stdout.jsonl').open('w') as stdout, (directory / 'compiler.stderr.log').open('w') as stderr:
        started = time.monotonic()
        completed = subprocess.run(compile_command, env=run_env, stdout=stdout, stderr=stderr)
        compiler_completed = time.monotonic()
    assert completed.returncode == 0
    shutil.copy2(directory / 'program.o', link / 'program.o')
    with (directory / 'link.stdout.log').open('w') as stdout, (directory / 'link.stderr.log').open('w') as stderr:
        link_started = time.monotonic()
        completed = subprocess.run(link_command, env=run_env, stdout=stdout, stderr=stderr)
        finished = time.monotonic()
    assert completed.returncode == 0
    checks = {}
    for filename in ['source.mec', 'program.mecb', 'program.o', 'metadata.json']:
        actual = directory / filename
        checks[filename] = {'bytes': actual.stat().st_size, 'sha256': sha(actual), 'matches_frozen_reference': actual.read_bytes() == (root / 'reference' / filename).read_bytes()}
    executable = link / 'worker'
    record = {'variant': variant, 'compile_threads': threads, 'compiler_exit_code': 0, 'link_exit_code': completed.returncode, 'source_to_executable_seconds': finished-started, 'source_to_object_process_seconds': compiler_completed-started, 'object_handoff_seconds': link_started-compiler_completed, 'native_link_seconds': finished-link_started, 'measurement_boundary': 'compiler_spawn_through_native_link_process_wait_completion', 'cached_adapter_objects': True, 'primary_cohort': True, 'files': checks, 'executable_bytes': executable.stat().st_size, 'executable_sha256': sha(executable), 'matches_complete_baseline_executable': executable.read_bytes() == (link/'worker-baseline').read_bytes()}
    shutil.copy2(executable, directory / 'worker')
    (directory / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
    records.append(record)
    (root / (name + '-observation.json')).write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    assert all(r['matches_frozen_reference'] for r in checks.values()) and record['matches_complete_baseline_executable']
