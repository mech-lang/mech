from pathlib import Path
import ast,hashlib,json,re,statistics,subprocess,sys
packet=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
pin=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
state=read(packet/'source-state.json')
assert pin(packet/'candidate.patch')['sha256']==state['patch_sha256']
assert [row['path'] for row in state['files']]==['src/core/src/dimension.rs']
for row in state['files']:
    assert pin(packet/'reference-source'/row['path'])==row['reference']
    assert pin(packet/'candidate-source'/row['path'])==row['candidate']
commit_path=packet/'qualification-commit.json'
commit=read(commit_path) if commit_path.exists() else dict(source_commit=None)
if commit_path.exists():
    assert commit['parent']==state['base_commit']
    assert commit['entire_commit_diff_sha256']==state['patch_sha256']
    assert commit['entire_commit_diff_matches_measured_patch']
excluded=read(packet/'excluded-products.json')
assert excluded['control']['sha256']==state['control']['sha256']
assert read(packet/'candidate-build.json')['binary_sha256']==excluded['candidate']['sha256']
for name in ['candidate-check','candidate-build','candidate-cli-check']:
    row=read(packet/(name+'.json'));assert row['exit_code']==0 and row['patch_sha256']==state['patch_sha256']
core_tests=read(packet/'core-tests/pipeline.json')
assert [row['stage'] for row in core_tests]==['unit','contracts','serde-vectors','no-std']
assert all(row['state']=='complete' and row['exit_code']==0 and row['patch_sha256']==state['patch_sha256'] for row in core_tests)
assert [(row['stage'],row.get('passed'),row.get('suites')) for row in core_tests]==[('unit',191,1),('contracts',110,10),('serde-vectors',2,1),('no-std',None,None)]
for row in core_tests:
    assert row['command'][:2]==['cargo','+nightly-2026-03-03'] and '--locked' in row['command'] and '--offline' in row['command'] and '--no-default-features' in row['command']
    if row['stage']!='no-std':
        found=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed;', (packet/'core-tests'/(row['stage']+'.stdout.log')).read_text())
        assert len(found)==row['suites'] and all(failed=='0' for _,failed in found)
        assert sum(int(passed) for passed,_ in found)==row['passed']
assert 'dimension::vector_tests::fused_declaration_scan_preserves_competing_first_errors ... ok' in (packet/'core-tests/unit.stdout.log').read_text()
products=read(packet/'core-tests/products.json');assert len(products)==12
for name,row in products.items():assert excluded['core-test-products/'+name]==row
selection=read(packet/'selection/scope.json')
assert selection['new_sampling_runs']==0 and selection['selection_only']
assert selection['canonical_dimension_named_leaf_counts']==[89,78]
assert read(packet/'selection/configuration.json')['source_commit']=='0c949505cc708c233e27c094aa67e105068d6823'

flags = read(packet / 'runtime-flags.json')
assert len(flags) == 61
reference = {name:pin(packet / 'reference' / name) for name in ['source.mec','program.mecb','program.o','metadata.json']}
native = read(packet / 'native-baseline-pins.json')
exe = native['executable']
assert exe == dict(bytes=2060440,sha256='d6c65cc3fb18acc4be77dce329962105bf0f2b56dd2623a12f466256463eca61')
capture = read(packet / 'link-command.json')
inputs = read(packet / 'native-link-inputs.json')
assert [(r['source'],r['bytes'],r['sha256']) for r in inputs] == [(r['source'],r['bytes'],r['sha256']) for r in capture['inputs']]
for row in inputs:
    assert pin(packet / row['path']) == {k:row[k] for k in ['bytes','sha256']}
for variant in ['control','candidate']:
    directory = packet / (variant + '-screen')
    assert read(directory / 'process.json')['exit_code'] == 0
    for name, item in reference.items():
        assert pin(directory / name) == item and (directory / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    assert pin(packet / ('link-' + variant) / 'worker') == exe
gates = read(packet / 'final-executable-results.json')
assert len(gates) == 2 and all(r['exit_code'] == 0 and r['matches_complete_baseline_executable'] and r['executable_sha256'] == exe['sha256'] for r in gates)
fixtures = read(packet / 'fixture-results.json')
assert len(fixtures) == 14
for row in fixtures:
    assert row['all_outputs_match'] and row['variants']['control'] == row['variants']['candidate']
    for variant in ['control','candidate']:
        entry = row['variants'][variant]
        assert entry['exit_code'] == 0 and len(entry['files']) == 4
        name = Path(row['fixture'].split(':')[-1]).stem
        directory = packet / 'fixtures' / name / variant
        for filename, item in entry['files'].items():
            assert pin(directory / filename) == item
            assert (directory / filename).read_bytes() == (packet / 'fixtures' / name / 'control' / filename).read_bytes()
jobs=read(packet/'jobs-diagnostic.json')
assert jobs['excluded_from_primary'] and jobs['all_outputs_and_complete_executable_identical']
observed=[]
for line in (packet/'candidate-jobs-diagnostic/stderr.log').read_text().splitlines():
    match=re.fullmatch(r'compact-compile-jobs: workers=(\d+) submitted=(\d+) cleanup=(\d+)',line)
    if match:observed.append(dict(workers=int(match[1]),submitted=int(match[2]),cleanup=int(match[3])))
assert jobs['rows']==observed and observed==[dict(workers=2,submitted=344,cleanup=48)]
for name,item in reference.items():assert pin(packet/'candidate-jobs-diagnostic'/name)==item
assert pin(packet/'link-candidate-jobs/worker')==exe
assert read(packet/'jobs-executable-results.json')[0]['matches_complete_baseline_executable']
assert read(packet/'candidate-jobs-diagnostic-command.json')['flags']==dict(flags,MECH_COMPACT_COMPILE_THREADS='2',MECH_PROFILE_COMPILE_JOBS='1')

rows = read(packet / 'cohort.json')
assert len(rows) == 8
order = ['control-1','candidate-1','candidate-2','control-2','candidate-3','control-3','control-4','candidate-4']
assert [r['name'] for r in rows] == order
for row in rows:
    directory = packet / row['name']
    assert row['compile'] == read(directory / 'compile.json') and row['process'] == read(directory / 'process.json')
    assert row['process']['exit_code'] == 0
    command = read(packet / (row['name'] + '-command.json'))
    assert command['binary_sha256'] == excluded[row['variant']]['sha256']
    assert command['flags'] == dict(flags, MECH_COMPACT_COMPILE_THREADS='2')
    for name, item in reference.items():
        assert pin(directory / name) == item and (directory / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    stamps = [json.loads(line) for line in (directory / 'stages.jsonl').read_text().splitlines()]
    for key, begin, end in [('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code'),('compaction_seconds','compact-stage: compact values before=','compact-stage: CFG cleanup')]:
        assert row[key] == next(s['elapsed'] for s in stamps if s['line'].startswith(end)) - next(s['elapsed'] for s in stamps if s['line'].startswith(begin))
    assert row['cleanup_including_compaction_seconds'] == row['cleanup_seconds'] + row['compaction_seconds']
    log = (directory / 'stderr.log').read_text()
    for key, pattern in [('max_rss_bytes',r'(\d+)  maximum resident set size'),('instructions',r'(\d+)  instructions retired'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]:
        assert row[key] == int(re.search(pattern,log).group(1))
fields = dict(compiler_seconds=lambda r:r['compile']['total_seconds'],whole_process_seconds=lambda r:r['process']['elapsed_seconds'])
for phase in ['parse','catalog','frontend','artifact','encode','native']:
    fields[phase+'_seconds'] = lambda r,p=phase: next(v['seconds'] for v in r['compile']['phases'] if v['phase']==p)
for key in ['canonical_lowering_seconds','preparation_seconds','numeric_generation_seconds','source_cfg_seconds','cleanup_including_compaction_seconds','cleanup_seconds','compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:
    fields[key] = lambda r,k=key:r[k]
summary = {}
for key, fn in fields.items():
    values = {v:[fn(r) for r in rows if r['variant']==v] for v in ['control','candidate']}
    base = statistics.mean(values['control'])
    values['mean_reduction_fraction'] = 1-statistics.mean(values['candidate'])/base if base else None
    summary[key] = values
assert read(packet / 'numerical-summary.json') == summary
native_path = packet / 'native-cohort.json'
native_rows = read(native_path) if native_path.exists() else []
assert len(native_rows) in [0,8]
native_summary = {}
for row in native_rows:
    directory = packet / row['name']
    receipt = read(directory / 'result.json')
    assert row == dict(receipt, name=row['name'], primary_cohort=True)
    assert row['compiler_exit_code'] == row['link_exit_code'] == 0 and row['matches_complete_baseline_executable']
    assert row['executable_bytes'] == exe['bytes'] and row['executable_sha256'] == exe['sha256'] and pin(directory / 'worker') == exe
    for name, item in reference.items():
        assert pin(directory / name) == item and (directory / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    assert abs(row['source_to_executable_seconds']-sum(row[k] for k in ['source_to_object_process_seconds','object_handoff_seconds','native_link_seconds'])) < 1e-8
if native_rows:
    for key in ['source_to_executable_seconds','source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']:
        values = {v:[r[key] for r in native_rows if r['variant']==v] for v in ['control','candidate']}
        values['mean_reduction_fraction'] = 1-statistics.mean(values['candidate'])/statistics.mean(values['control'])
        native_summary[key] = values
    blocks = []
    for block in [native_rows[:4],native_rows[4:]]:
        means = {v:statistics.mean(r['source_to_executable_seconds'] for r in block if r['variant']==v) for v in ['control','candidate']}
        means['mean_reduction_fraction'] = 1-means['candidate']/means['control']
        blocks.append(means)
    saved = read(packet / 'native-numerical-summary.json')
    assert saved['numerical_summary'] == native_summary and saved['balanced_blocks'] == blocks
else:
    blocks = []
if (packet / 'candidate-serial-gate').exists():
    serial = packet / 'candidate-serial-gate'
    assert read(serial / 'process.json')['exit_code'] == 0
    for name, item in reference.items():
        assert pin(serial / name) == item and (serial / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    serial_result = read(packet / 'link-candidate-serial/result.json')
    assert serial_result['matches_complete_baseline_executable'] and serial_result['executable_sha256'] == exe['sha256']
    assert pin(packet / 'link-candidate-serial/worker') == exe


algorithm=json.loads(subprocess.check_output([sys.executable,str(packet/'audit.py')]))
assert algorithm==read(packet/'algorithm-audit.json')
plan=read(packet/'qualification-plan.json')
driver=packet/'qualify.py'
assert pin(driver)['sha256']==plan['driver_sha256']
stages=next(ast.literal_eval(node.value) for node in ast.parse(driver.read_text()).body if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='stages' for t in node.targets))
assert [list(row) for row in stages]==plan['stages']
assert [row[0] for row in stages]==['screens','executable-gates','default-serial-byte-gate','jobs-diagnostic','fixtures-object-cohort','native-cohort']
pipeline=read(packet/'qualification-pipeline.json')
assert [row['stage'] for row in pipeline]==[row[0] for row in stages]
assert all(row['state']=='complete' and row['exit_code']==0 for row in pipeline)
for item in read(packet/'qualification-scripts/derivation-current.json'):
    assert pin(packet/'qualification-scripts/originals'/Path(item['original_path']).name)['sha256']==item['original_sha256']
    assert pin(packet/'qualification-scripts'/item['derived_name'])['sha256']==item['derived_sha256']
object_blocks=[]
for block in [rows[:4],rows[4:]]:
    values={}
    for key in ['compiler_seconds','whole_process_seconds','parse_seconds','source_cfg_seconds','frontend_seconds','instructions']:
        means={variant:statistics.mean(fields[key](row) for row in block if row['variant']==variant) for variant in ['control','candidate']}
        means['mean_reduction_fraction']=1-means['candidate']/means['control'];values[key]=means
    object_blocks.append(values)
decision=read(packet/'decision.json')
assert decision['control_complete_seconds']==statistics.mean(native_summary['source_to_executable_seconds']['control'])
assert decision['candidate_complete_seconds']==statistics.mean(native_summary['source_to_executable_seconds']['candidate'])
assert decision['native_reduction']==native_summary['source_to_executable_seconds']['mean_reduction_fraction'] and decision['native_blocks']==blocks
assert decision['object_adverse_fields']=={key:value for key,value in summary.items() if value['mean_reduction_fraction']<0}
assert decision['native_adverse_fields']=={key:value for key,value in native_summary.items() if value['mean_reduction_fraction']<0}
restoration=None
if decision['decision']=='reject':
    restoration=read(packet/'restoration.json')
    assert restoration==decision['restoration'] and restoration['source_restored']
    assert restoration['source_sha256']==state['files'][0]['reference']['sha256']
    assert restoration['canonical_sha256']==excluded['control']['sha256']
    assert restoration['selected_pgo_sha256']=='6fc6db8164c3f0a66fc5d968fd42f72fe5daf11ca8e89dea00b430530989a797'
else:
    assert decision['decision']=='retain' and commit_path.is_file() and isinstance(commit['source_commit'],str) and len(commit['source_commit'])==40 and commit['source_commit']==decision['retained_source_commit']
result=dict(source_commit=commit['source_commit'],base_commit=state['base_commit'],patch_sha256=state['patch_sha256'],compiler=excluded,source_state=state,numerical_summary=summary,native_numerical_summary=native_summary,balanced_native_blocks=blocks,object_balanced_blocks=object_blocks,output_hashes=reference,final_executable=exe,fixture_pairs=14,core_tests=core_tests,core_test_products=products,checks={name:read(packet/(name+'.json')) for name in ['candidate-check','candidate-build','candidate-cli-check']},decision=decision,algorithm_audit=algorithm,jobs_diagnostic=jobs,qualification_pipeline=pipeline,restoration=restoration,scope='One fresh full declaration scan collects complete ID validity, constant-bound classification and lifetime facts. Constant-only lifetime errors still follow all declaration-ID errors and precede root checks; mixed-bound normalization and first errors unchanged. No cache, inventory pruning, permission, storage layout, parameter/root identity or grammar/program-runtime change. Standard control/candidate same61flags/twoworkers, no nativeCPU/PGO overrides; all4outputs/fullmetadata/wholeexe and default0/344-48 gates. Actual current core unit/contract/serde/no_std checks and byte-identical reference oracle. No subten claim.')
encoded=json.dumps(result,indent=2,sort_keys=True)+'\n'
saved=packet/'summary.json'
if saved.exists():assert saved.read_text()==encoded
else:saved.write_text(encoded)
print(encoded,end='')
