from pathlib import Path
import hashlib,json,re

root=Path(__file__).resolve().parent
relative='src/core/src/dimension.rs'
reference=(root/'reference-source'/relative).read_text()
candidate=(root/'candidate-source'/relative).read_text()
def tokens(source):
    return [x for x in re.findall(r'//[^\n]*|/\*.*?\*/|"(?:\\.|[^"\\])*"|\w+|[^\s]',source,flags=re.S) if not x.startswith('//') and not x.startswith('/*')]
canonical='pub(crate) fn canonicalize_dimension_environment('
constant='fn canonicalize_constant_bounds('
before=reference[:reference.index(canonical)]
assert tokens(before)==tokens(candidate[:candidate.index(canonical)])
left=reference[reference.index(canonical):reference.index(constant)]
right=candidate[candidate.index(canonical):candidate.index(constant)]
assert tokens(left[left.index('    if root_references.is_empty()'):])==tokens(right[right.index('    if root_references.is_empty()'):])
old_marker='pub(crate) fn validate_declaration_ids('
new_marker='fn inspect_dimension_declarations('
old_constant=reference[reference.index(constant):reference.index(old_marker)]
new_constant=candidate[candidate.index(constant):candidate.index(new_marker)]
assert tokens(old_constant[old_constant.index('    let count ='):])==tokens(new_constant[new_constant.index('    let count ='):])
old_ids=reference[reference.index(old_marker):reference.index('fn ensure_known_references(')]
new_ids=candidate[candidate.index(new_marker):candidate.index('fn ensure_known_references(')]
old_checks=old_ids[old_ids.index('    for (index'):old_ids.rindex('    }\n    Ok(())')]
new_checks=new_ids[new_ids.index('    for (index'):new_ids.index('        constant_bounds = constant_bounds')]
assert tokens(old_checks)==tokens(new_checks)
assert new_ids.count('let mut constant_bounds = true;')==1
assert new_ids.count('let mut has_compile_time = false;')==1
assert new_ids.count('has_compile_time |= declaration.lifetime == DimensionLifetime::CompileTime;')==1
assert new_ids.count('Ok((constant_bounds, has_compile_time))')==1
assert tokens(reference[reference.index('fn ensure_known_references('):reference.index('#[cfg(test)]')])==tokens(candidate[candidate.index('fn ensure_known_references('):candidate.index('#[cfg(test)]')])
oracle='    fn reference_canonicalize_dimension_environment('
assert reference[reference.index(oracle):]==candidate[candidate.index(oracle):]
test_start='    #[test]\n    fn fused_declaration_scan_preserves_competing_first_errors()'
test_end='    #[test]\n    fn canonical_environment_matches_ordered_set_reference()'
tests=candidate[candidate.index('#[cfg(test)]'):]
a=tests.index(test_start);b=tests.index(test_end,a)
new_test=tests[a:b]
assert '0..8192_u64' in new_test and 'reference_canonicalize_dimension_environment' in new_test
tests=tests[:a]+tests[b:]
for argument in ['&declarations','&sparse']:
    tests=tests.replace('inspect_dimension_declarations('+argument+').map(|_| ())','validate_declaration_ids('+argument+')')
assert tokens(tests)==tokens(reference[reference.index('#[cfg(test)]'):])
state=json.loads((root/'source-state.json').read_text())
assert hashlib.sha256(candidate.encode()).hexdigest()==state['files'][0]['candidate']['sha256']
result=dict(full_original_id_check_order_identical=True,mixed_bounds_normalization_rootless_and_dependency_paths_identical=True,constant_bound_selection_mapping_and_root_order_identical=True,all_other_production_tokens_identical=True,original_reference_oracle_byte_identical=True,all_existing_tests_identical_except_helper_result_projection=True,new_competing_error_cases=8192*3,source_patch_sha256=state['patch_sha256'],scope='One fresh full declaration scan collects ID validity and pure constant/lifetime facts. Only constant-only lifetime refusal moves to the entry; mixed bounds retain original error order. No cached admission or pruned inventory.')
print(json.dumps(result,indent=2,sort_keys=True))
