from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time

root = Path('/private/tmp/mech-dimension-declaration-scan-20261115')
state = json.loads((root / 'source-state.json').read_text())
assert subprocess.check_output(['git', 'diff', '--binary']) == (root / 'candidate.patch').read_bytes()
assert json.loads((root / 'candidate-build.json').read_text())['exit_code'] == 0
assert json.loads((root / 'candidate-cli-check.json').read_text())['exit_code'] == 0
core_tests=json.loads((root/'core-tests/pipeline.json').read_text())
assert [row['stage'] for row in core_tests]==['unit','contracts','serde-vectors','no-std']
assert all(row['state']=='complete' and row['exit_code']==0 for row in core_tests)
assert [row['passed'] for row in core_tests if 'passed' in row]==[191,110,2]
assert json.loads((root/'algorithm-audit.json').read_text())['original_reference_oracle_byte_identical']
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
assert pin(root / 'control')['sha256'] == '6ce7a53b36d3677cf3b20d919657d2824b7d8561ef5eeaf254377626f27980ae'
assert pin(root / 'candidate')['sha256'] == json.loads((root / 'candidate-build.json').read_text())['binary_sha256']
assert len(json.loads((root/'runtime-flags.json').read_text())) == 61
for filename, expected in json.loads((root/'reference-pins.json').read_text()).items():
    assert pin(root/'reference'/filename) == expected
(root / 'qualification.json').write_text(json.dumps(dict(base_commit=state['base_commit'], patch_sha256=state['patch_sha256'], compiler={v:pin(root/v) for v in ['control','candidate']}, common_compile_threads=2, program_flags_count=61, scope=state['scope']), indent=2) + '\n')
env = {k:v for k,v in os.environ.items() if not k.startswith('MECH_')}
scripts = root / 'qualification-scripts'
stages = [('screens', 'mech-screen-dimension-declaration-scan-current-20261115.py'),
          ('executable-gates', 'mech-cached-native-link-dimension-declaration-scan-current-20261115.py'),
          ('default-serial-byte-gate','mech-qualify-dimension-declaration-scan-serial-stage-20261115.py'),
          ('jobs-diagnostic','mech-qualify-dimension-declaration-scan-jobs-20261115.py'),
          ('fixtures-object-cohort', 'mech-qualify-dimension-declaration-scan-current-20261115.py'),
          ('native-cohort','mech-native-cohort-dimension-declaration-scan-current-20261115.py')]
records = []
for stage, name in stages:
    command = [sys.executable, str(scripts / name)]
    row = dict(stage=stage, state='running', command=command, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    records.append(row)
    (root / 'qualification-pipeline.json').write_text(json.dumps(records, indent=2) + '\n')
    started = time.monotonic()
    with (root / (stage + '.stdout.log')).open('w') as stdout, (root / (stage + '.stderr.log')).open('w') as stderr:
        completed = subprocess.run(command, env=env, stdout=stdout, stderr=stderr)
    row.update(state='complete' if completed.returncode == 0 else 'failed', exit_code=completed.returncode, seconds=time.monotonic()-started)
    (root / 'qualification-pipeline.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    assert completed.returncode == 0
