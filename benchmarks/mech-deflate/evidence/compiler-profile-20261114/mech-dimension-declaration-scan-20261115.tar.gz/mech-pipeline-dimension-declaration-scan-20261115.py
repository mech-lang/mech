from pathlib import Path
import datetime,json,subprocess,sys,time
root=Path('/private/tmp/mech-dimension-declaration-scan-20261115')
assert json.loads((root/'candidate-build.json').read_text())['exit_code']==0
assert all(row['exit_code']==0 for row in json.loads((root/'core-tests/pipeline.json').read_text()))
assert subprocess.check_output(['git','diff','--binary'])==(root/'candidate.patch').read_bytes()
records=[]
for stage,path in [('cli-check','/private/tmp/mech-check-dimension-declaration-scan-20261115.py'),('qualification','/private/tmp/mech-qualify-dimension-declaration-scan-20261115.py')]:
 row={'stage':stage,'state':'running','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};records.append(row)
 (root/'pipeline.json').write_text(json.dumps(records,indent=2)+'\n')
 started=time.monotonic()
 with (root/(stage+'-driver.stdout.log')).open('w') as stdout,(root/(stage+'-driver.stderr.log')).open('w') as stderr:result=subprocess.run([sys.executable,path],stdout=stdout,stderr=stderr)
 row.update(state='complete' if result.returncode==0 else 'failed',exit_code=result.returncode,seconds=time.monotonic()-started)
 (root/'pipeline.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert result.returncode==0
