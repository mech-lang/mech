from pathlib import Path
import hashlib, json, re, statistics

packet = Path(__file__).resolve().parent
root = packet / 'qualification'
read = lambda p: json.loads(p.read_text())
pins = {}
def pin(path):
    if path not in pins:
        pins[path] = dict(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    return pins[path]

source = read(packet / 'source-state.json')
serial_setup=read(packet/'serial-gate-setup-failure/serial-gate-pipeline.json')
assert len(serial_setup)==1 and serial_setup[0]['exit_code']==2 and serial_setup[0]['state']=='failed'
assert "can't open file" in (packet/'serial-gate-setup-failure/serial-gate-0.stderr.log').read_text()
assert 'qualification/qualification-scripts/' in serial_setup[0]['command'][1]
revision = 'd26cf2c65eac2f5978cabba257bb8bebbe4b0a80'
assert source['source_commit'] == revision
configuration = read(packet / 'source-config-pins.json')
for item in configuration:
    assert pin(packet / 'source-config' / item['path']) == {k: item[k] for k in ['bytes', 'sha256']}
state = read(root / 'configuration.json')
assert state['source_commit'] == revision and state['common_compile_threads']==2 and state['program_flags_count']==61
excluded = {r['path']: r for r in read(packet / 'excluded-compiler-products.json')}
diagnostics = {}
builds = {mode: read(packet / (mode + '-build.json')) for mode in ['native-control', 'generate', 'use']}
for mode, build in builds.items():
    assert build['exit_code'] == 0 and build['source_commit'] == revision and build['mode'] == mode
    assert build['target'] == 'aarch64-apple-darwin' and build['cargo_jobs'] == 4 and build['CARGO_INCREMENTAL'] == '0'
    assert build['binary_sha256'] == excluded[mode]['sha256']
    flags = ['-D', 'warnings']
    flags += ['-C','target-cpu=native']
    if mode == 'generate': flags += ['-C', 'profile-generate=/private/tmp/mech-refreshed-native-pgo-20261115/raw']
    if mode == 'use': flags += ['-C', 'profile-use=/private/tmp/mech-refreshed-native-pgo-20261115/merged.profdata', '-C', 'llvm-args=-pgo-warn-missing-function']
    assert build['rustflags'] == flags
    assert build['command'] == ['cargo', '+nightly-2026-03-03', 'build', '--locked', '--offline', '--profile', 'compiler', '--target', 'aarch64-apple-darwin', '-j4', '--manifest-path', 'benchmarks/mech-deflate/native-profile/Cargo.toml', '--bin', 'compile_profile', '--message-format=json']
    artifacts = [json.loads(line) for line in (packet / (mode + '-build.jsonl')).read_text().splitlines()]
    matches = [r for r in artifacts if r.get('reason') == 'compiler-artifact' and r.get('target', {}).get('name') == 'compile_profile' and r.get('executable')]
    assert len(matches) == 1 and matches[0]['executable'].endswith('/aarch64-apple-darwin/compiler/compile_profile')
    assert artifacts[-1] == {'reason': 'build-finished', 'success': True}
    messages = [r['message'] for r in artifacts if r.get('reason') == 'compiler-message']
    diagnostics[mode] = dict(total=len(messages),warnings=sum(m['level']=='warning' for m in messages),missing_function=sum('no profile data available for function' in m['message'] for m in messages),hash_or_control_flow_mismatch=sum('hash mismatch' in m['message'] or 'control flow change' in m['message'] for m in messages))
    assert diagnostics[mode]['hash_or_control_flow_mismatch']==0
    if mode=='use':
        assert diagnostics[mode]['total']==diagnostics[mode]['warnings']==diagnostics[mode]['missing_function']
    else:
        assert diagnostics[mode]==dict(total=0,warnings=0,missing_function=0,hash_or_control_flow_mismatch=0)
control_reuse=read(packet/'control-reuse.json')
assert control_reuse['source_commit']==revision and control_reuse['sha256']=='b72ff590c3ea6760f9a77372ba2bb6761f3b2d2885cdbef029ee040509bb51ba'
assert excluded['control']['sha256']==control_reuse['sha256']
assert excluded['qualification/control']['sha256'] == control_reuse['sha256']
assert excluded['qualification/candidate']['sha256'] == builds['use']['binary_sha256']
binary_sha = {v: excluded['qualification/' + v]['sha256'] for v in ['control', 'candidate']}
assert 'LLVM version 22.1.0-rust-1.96.0-nightly' in (packet / 'llvm-profdata-version.txt').read_text()
profile_pins = read(packet / 'training/profile-pins.json')
assert len(profile_pins) == 8
assert {p.name for p in (packet / 'raw').glob('*.profraw')} == {Path(r['path']).name for r in profile_pins}
for item in profile_pins:
    assert pin(packet / 'raw' / Path(item['path']).name) == {k: item[k] for k in ['bytes', 'sha256']}
assert pin(packet / 'merged.profdata') == read(packet / 'training/merged-profile-pin.json')
merge = read(packet / 'training/merge-command.json')
assert merge == [(packet / 'llvm-profdata-path.txt').read_text().strip(), 'merge', '-o', '/private/tmp/mech-refreshed-native-pgo-20261115/merged.profdata'] + [r['path'] for r in profile_pins]
pipeline = read(packet / 'pipeline.json')
assert [r['stage'] for r in pipeline] == ['native-control','native-output-gates','generate','training','use']
assert all(r['state'] == 'complete' and r['exit_code'] == 0 for r in pipeline)

prior = read(packet / 'validation/prior-qualified.json')
assert pin(packet / 'validation/prior-qualified.json')['sha256'] == read(packet / 'validation/prior-qualified.archive.json')['replay_sha256']
expected = prior['output_hashes']
assert read(root / 'reference-pins.json') == expected
for filename, item in expected.items(): assert pin(root / 'reference' / filename) == item
flags = read(root / 'runtime-flags.json')
assert len(flags) == 61 and flags['MECH_COMPACT_REUSE_OVERWRITTEN_RESULT'] == '1'
runtime_flags=dict(flags,MECH_COMPACT_COMPILE_THREADS='2')
order = [('control','control-1'),('candidate','candidate-1'),('candidate','candidate-2'),('control','control-2'),('candidate','candidate-3'),('control','control-3'),('control','control-4'),('candidate','candidate-4')]
cohort, screens = [], []
for variant, name in [('control','control-screen'),('candidate','candidate-screen')] + order:
    directory = root / name
    command = read(root / (name + '-command.json'))
    assert command['flags'] == runtime_flags and command['binary_sha256'] == binary_sha[variant] and not command['profiling_excluded_from_primary']
    process = read(directory / 'process.json')
    assert process['exit_code'] == 0 and process['elapsed_boundary'] == 'driver_start_to_process_wait_completion'
    assert process['samples'] == 0 and process['sampling_error'] is None
    checks = read(directory / 'output-check.json')
    for filename, item in expected.items():
        assert pin(directory / filename) == item and checks[filename] == dict(item, matches_current_control_output=True)
    row = dict(name=name, variant=variant, compile=read(directory / 'compile.json'), process=process, files=checks)
    assert row['compile']['total_seconds'] < process['elapsed_seconds']
    if name.endswith('-screen'):
        screens.append(row)
        continue
    stamps = [json.loads(line) for line in (directory / 'stages.jsonl').read_text().splitlines()]
    elapsed = lambda prefix: next(s['elapsed'] for s in stamps if s['line'].startswith(prefix))
    for key, begin, end in [('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]:
        row[key] = elapsed(end) - elapsed(begin)
    log = (directory / 'stderr.log').read_text()
    for key, pattern in [('max_rss_bytes', r'(\d+)  maximum resident set size'), ('instructions', r'(\d+)  instructions retired'), ('peak_footprint_bytes', r'(\d+)  peak memory footprint')]:
        row[key] = int(re.search(pattern, log).group(1))
    row['compaction_seconds'] = elapsed('compact-stage: CFG cleanup') - elapsed('compact-stage: compact values before=')
    for key, prefix in [('value_ids_before','compact-stage: compact values before='),('value_ids_after','compact-values: retained=')]:
        row[key] = int(next(s['line'] for s in stamps if s['line'].startswith(prefix)).split('=')[-1])
    assert (row['value_ids_before'], row['value_ids_after']) == (21152385,1307512)
    row['cleanup_including_compaction_seconds'] = row['cleanup_seconds'] + row['compaction_seconds']
    cohort.append(row)
assert cohort == read(root / 'cohort.json')
fields = {'compiler_seconds': lambda r: r['compile']['total_seconds'], 'whole_process_seconds': lambda r: r['process']['elapsed_seconds']}
for phase in ['parse','catalog','frontend','artifact','encode','native']:
    fields[phase + '_seconds'] = lambda r, p=phase: next(v['seconds'] for v in r['compile']['phases'] if v['phase'] == p)
for key in ['canonical_lowering_seconds','preparation_seconds','numeric_generation_seconds','source_cfg_seconds','cleanup_including_compaction_seconds','cleanup_seconds','compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:
    fields[key] = lambda r, k=key: r[k]
numerical = {}
for key, fn in fields.items():
    values = {v: [fn(r) for r in cohort if r['variant'] == v] for v in ['control','candidate']}
    values['mean_reduction_fraction'] = 1 - statistics.mean(values['candidate']) / statistics.mean(values['control'])
    numerical[key] = values
assert numerical == read(root / 'numerical-summary.json')
blocks = []
for rows in [cohort[:4],cohort[4:]]:
    block = {}
    for key in ['compiler_seconds','whole_process_seconds','instructions']:
        means = {v: statistics.mean(fields[key](r) for r in rows if r['variant'] == v) for v in ['control','candidate']}
        block[key] = dict(means, mean_reduction_fraction=1-means['candidate']/means['control'])
    blocks.append(block)

fixtures = read(root / 'fixture-results.json')
assert len(fixtures) == 14
fixture_names = set()
for row in fixtures:
    name = row['fixture'].split(':')[-1] if ':' in row['fixture'] else Path(row['fixture']).stem
    fixture_names.add(name)
    assert pin(root / 'fixture-inputs' / (name + '.mec'))['sha256'] == row['source_sha256']
    assert row['all_outputs_match'] and row['variants']['control'] == row['variants']['candidate']
    assert row['variants']['control']['exit_code'] == 0 and len(row['variants']['control']['files']) == 4
    for variant in ['control','candidate']:
        directory = root / 'fixtures' / name / variant
        command = read(directory / 'command.json')
        assert command['flags'] == runtime_flags and command['binary_sha256'] == binary_sha[variant]
        for filename, item in row['variants'][variant]['files'].items(): assert pin(directory / filename) == item
training = read(packet / 'training/results.json')
training_names = {'level12-deflate','numeric-nested-phase','numeric-private-fixed-nested','numeric-array-windows','scalar-bool-equal','scalar-u64-add','scalar-i64-divide','scalar-f64-add'}
assert {r['name'] for r in training} == training_names
held_out = sorted(fixture_names - training_names)
assert len(held_out) == 7
for row in training:
    name = row['name']
    directory = packet / 'training' / name
    command = read(directory / 'command.json')
    assert command['runtime_flags'] == runtime_flags and command['instrumented_compiler_sha256'] == builds['generate']['binary_sha256']
    assert command['LLVM_PROFILE_FILE'] == '/private/tmp/mech-refreshed-native-pgo-20261115/raw/%m-%p.profraw'
    assert row['exit_code'] == 0 and len(row['files']) == 4
    reference = root / 'reference' if name == 'level12-deflate' else root / 'fixtures' / name / 'control'
    for filename, item in row['files'].items():
        actual = pin(directory / filename)
        assert item == dict(actual, matches_frozen_unprofiled_control=True) and actual == pin(reference / filename)
    pid = re.search(r'compile-profile: pid=(\d+)', (directory / 'stderr.log').read_text()).group(1)
    assert sum(Path(r['path']).name.endswith('-' + pid + '.profraw') for r in profile_pins) == 1

heldout = read(root / 'heldout-results.json')
assert [r['name'] for r in heldout] == ['numeric-nested-phase-states','numeric-changing-capture-tree','numeric-multiple-children','scalar-u64-divide','scalar-i64-add','scalar-i64-multiply','scalar-f64-divide']
assert set(r['name'] for r in heldout) == set(held_out)
for case in heldout:
    name = case['name']
    assert case['source'] == pin(root / 'fixture-inputs' / (name + '.mec'))
    observations = case['observations']
    assert [(r['variant'],r['run']) for r in observations] == [(v,int(n.rsplit('-',1)[1])) for v,n in order]
    for row in observations:
        directory = root / 'heldout' / name / (row['variant'] + '-' + str(row['run']))
        assert read(directory / 'process.json') == row
        command = read(directory / 'command.json')
        assert command['flags'] == runtime_flags and command['binary'] == {k:excluded['qualification/'+row['variant']][k] for k in ['bytes','sha256']}
        assert command['source'] == case['source'] and command['command'][:2] == ['/usr/bin/time','-lp']
        assert row['exit_code'] == 0 and row['output_matches'] and len(row['files']) == 4
        for filename,item in row['files'].items():
            assert pin(directory/filename) == item == pin(root/'fixtures'/name/'control'/filename)
        receipt = read(directory / 'compile.json')
        assert receipt['total_seconds'] == row['compiler_seconds'] < row['whole_process_seconds']
        log = (directory/'stderr.log').read_text()
        for key,pattern in [('instructions',r'(\d+)  instructions retired'),('max_rss_bytes',r'(\d+)  maximum resident set size')]:
            assert int(re.search(pattern,log).group(1)) == row[key]
    numerical_heldout = {}
    for key in ['whole_process_seconds','compiler_seconds','instructions','max_rss_bytes']:
        values = {v:[r[key] for r in observations if r['variant']==v] for v in ['control','candidate']}
        values['mean_reduction_fraction'] = 1-statistics.mean(values['candidate'])/statistics.mean(values['control'])
        numerical_heldout[key] = values
    assert numerical_heldout == case['numerical_summary']
    blocks_heldout = []
    for subset in [observations[:4],observations[4:]]:
        means={v:statistics.mean(r['whole_process_seconds'] for r in subset if r['variant']==v) for v in ['control','candidate']}
        means['mean_reduction_fraction']=1-means['candidate']/means['control']
        blocks_heldout.append(means)
    assert blocks_heldout == case['balanced_blocks']

inputs = read(packet / 'native-link-inputs.json')
for row in inputs: assert pin(packet / row['path']) == {k: row[k] for k in ['bytes','sha256']}
links = read(root / 'final-executable-results.json')
assert len(links) == 2
executable_pin = dict(bytes=2060440, sha256='d6c65cc3fb18acc4be77dce329962105bf0f2b56dd2623a12f466256463eca61')
for variant, row in zip(['control','candidate'],links):
    assert row['variant'] == variant and row['exit_code'] == 0 and row['matches_complete_baseline_executable'] and not row['fresh_runtime_campaign']
    assert pin(root / ('link-' + variant) / 'worker') == executable_pin == {k: row['executable_' + k] for k in ['bytes','sha256']}
    assert read(root / ('link-' + variant) / 'result.json') == row
    command = read(root / ('link-' + variant) / 'command.json')
    assert command['environment'] == {'ZERO_AR_DATE':'1'}
    assert [(r['source'],r['bytes'],r['sha256']) for r in command['input_pins']] == [(r['source'],r['bytes'],r['sha256']) for r in inputs]
native_order = [(v,'native-' + name) for v,name in order]
native = read(root / 'native-cohort.json')
assert [(r['variant'],r['name']) for r in native] == native_order
for row in native:
    directory = root / row['name']
    actual = read(directory / 'result.json')
    assert actual == {k:v for k,v in row.items() if k != 'name'}
    assert row['primary_cohort'] and row['cached_adapter_objects'] and row['compiler_exit_code'] == row['link_exit_code'] == 0
    assert row['matches_complete_baseline_executable'] and pin(directory / 'worker') == executable_pin
    assert abs(row['source_to_executable_seconds'] - sum(row[k] for k in ['source_to_object_process_seconds','object_handoff_seconds','native_link_seconds'])) < 1e-8
    command = read(directory / 'command.json')
    assert command['flags'] == runtime_flags and command['compiler_sha256'] == binary_sha[row['variant']] and command['ZERO_AR_DATE'] == '1'
    for filename, item in expected.items():
        assert pin(directory / filename) == item and row['files'][filename] == dict(item, matches_frozen_reference=True)
native_summary = read(root / 'native-numerical-summary.json')
native_numerical = {}
for key in ['source_to_executable_seconds','source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']:
    values = {v:[r[key] for r in native if r['variant'] == v] for v in ['control','candidate']}
    values['mean_reduction_fraction'] = 1-statistics.mean(values['candidate'])/statistics.mean(values['control'])
    native_numerical[key] = values
native_blocks = []
for rows in [native[:4],native[4:]]:
    means = {v:statistics.mean(r['source_to_executable_seconds'] for r in rows if r['variant'] == v) for v in ['control','candidate']}
    means['mean_reduction_fraction'] = 1-means['candidate']/means['control']
    native_blocks.append(means)
assert native_summary['numerical_summary'] == native_numerical and native_summary['balanced_blocks'] == native_blocks
assert native_summary['order'] == [list(r) for r in native_order]

summary = dict(
    source_commit=revision, compiler_binary_sha256=binary_sha, program_flags_count=61, common_compile_threads=2, control_reuse=control_reuse,
    compiler_builds=builds, compiler_build_diagnostics=diagnostics, pipeline=pipeline, source_config_pins=configuration,
    output_hashes=expected, final_executable=executable_pin,
    training_cases=8, held_out_fixture_names=held_out, fixture_pairs=14, held_out_compilation=heldout,
    raw_profiles=profile_pins, merged_profile=pin(packet/'merged.profdata'),
    numerical_summary=numerical, balanced_blocks=blocks, native_cohort=native_summary,
    preliminary_screens=screens, final_links=links,
)

qualification_pipeline=read(root/'pipeline.json')
assert [r['stage'] for r in qualification_pipeline]==['screens','cached-executable-gates','fixtures-object-cohort','heldout-cohorts','native-cohort']
assert all(r['state']=='complete' and r['exit_code']==0 for r in qualification_pipeline)
initial_screens=read(packet/'native-screen-results.json')
assert [r['mode'] for r in initial_screens]==['control','native-control']
for row in initial_screens:
    assert row['exit_code']==0 and row['matches_complete_baseline_executable'] and row['executable']==executable_pin
    directory=packet/('native-screen-'+row['mode'])
    for filename,item in expected.items():
        assert pin(directory/filename)==item and row['files'][filename]==dict(item,matches_frozen_reference=True)
    assert pin(directory/'worker')==executable_pin
for item in read(packet/'qualification-scripts/derivation.json'):
    assert pin(packet/'qualification-scripts/originals'/Path(item['original']).name)['sha256']==item['original_sha256']
    assert pin(packet/'qualification-scripts'/Path(item['derived']).name)['sha256']==item['derived_sha256']
assert state['subjects']=={v:{k:excluded['qualification/'+v][k] for k in ['bytes','sha256']} for v in ['control','candidate']}
decision=read(packet/'decision.json')
if decision['decision']=='retain':
    assert all(x['mean_reduction_fraction']>0 for x in native_blocks)
serial= root/'candidate-serial-gate'
for filename,item in expected.items():
    assert pin(serial/filename)==item
serial_result=read(root/'link-candidate-serial/result.json')
assert serial_result['matches_complete_baseline_executable'] and serial_result['executable_sha256']==executable_pin['sha256']
assert pin(root/'link-candidate-serial/worker')==executable_pin
summary.update(
    qualification_pipeline=qualification_pipeline,initial_native_cpu_output_gates=initial_screens,
    strategy='Current d26 retained source and program/runtime. Reuse qualified standard B72 control versus target-cpu=native plus instrumentation PGO. Same61programflags and2workers. Three newcompilerbuilds, standardcontrolnotrebuilt. Measurescombinedbuildconfiguration, no component/additive/historicalgain claim.',
    decision=decision,
    scope=[
        'Source d26 contains pinnedcompilerallocator/controlowners/actionoutputinventory/oncequeuedreachability. Newlybuilt nativeCPUcontrol/generate/use have explicit aarch64target,nightly2026-03-03,ThinLTOCGU1,j4,incremental0,-Dwarnings. Absoluteprofilepaths and matchingRustLLVM22profdata. StandardB72controlalreadyqualified39 isreused, notanewcontrolrebuild. Build/trainingexcludedprimary.',
        'Everytrainingoutput,14fixturepairs,56heldoutcompiles,eightObjectABBA/BAAB andeightcompletefreshsource-to-exe compiles preserveall4outputs/complete metadata. Two preliminarynativeCPUgates,twopreliminaryfinalPGOgates,eightprimarywholeexes anddefault0gate exactcurrentD6. No emitted-program/runtime/grammar/language/proof/accounting changes.',
        'All primaryruns serialaftereverybuildandtrainingfinishes; noheavybuild/test/profile/hash/archive overlap. Runtime/entryadaptercached withallnativeinputspinned; firstuseexcluded. Allstage/case/block/diagnostic/adverse resultsincluded; nopooledtinyprogrampercentage.',
        'Rawandmergedprofiles,sourceconfiguration,allbuild/training/qualificationlogs,scripts+derivation/everyprogramartifact/executable/nativeinput included. Compilerbinaries/dependencytarget/source snapshot excludedandhash/Git pinned. Pure replay checksprofiles,diagnostics,rawtimings/stages/counters andoutputs without recompilation orretiming. Subten remainsunproven.'
    ],
)

encoded = json.dumps(summary, indent=2, sort_keys=True) + '\n'
saved = packet / 'summary.json'
if saved.exists(): assert saved.read_text() == encoded
else: saved.write_text(encoded)
print(encoded, end='')
