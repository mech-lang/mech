CPU-native and instrumentation PGO on current retained compiler source d26cf2c65e.

The exact Git snapshot contains 36,457 files, excluding benchmark evidence. The
qualified standard B72 compiler is reused from packet 39. Three new compilers
(native CPU control, instrumented generator, and profile use) use the pinned
Rust nightly, explicit aarch64-apple-darwin target, compiler ThinLTO/CGU1 profile,
four Cargo jobs, disabled incremental compilation, and warnings-as-errors. All
program subjects use the same 61 flags and two workers. Compiler source is unchanged.

Both preliminary native CPU gates preserve every source/MBC/Object/complete
metadata byte and the entire current D6 executable. Eight fixed training programs
preserve their unprofiled outputs. Matching Rust LLVM 22 tools merge eight raw
profiles (269,301,792 bytes) into a 100,519,368-byte profile. Profile use reports
18,617 functions without training data and no hash/control-flow mismatches.

All compiler builds and training finish before primary measurements. Eight
source-to-Object ABBA/BAAB observations and eight separate complete fresh
source-to-executable builds run serially without overlapping heavy build, test,
profiling, hashing or archival. Fourteen paired fixtures and seven held-out cases
with eight balanced compiles each preserve all four outputs and complete metadata.
Every complete executable remains the same 2,060,440-byte D6 image. Fixed runtime
adapter and linker inputs are cached and pinned; historical adapter first use
(11.882560208 seconds) is excluded.

Complete builds improve 15.620738 to 14.027481 seconds (10.20%), with both blocks
faster. The Object cohort lowers compiler time 9.93%, instructions 13.00% and
parsing 18.23%. All held-out process/compiler/instruction means improve; both
process blocks improve for every case. Encoding (+14.27%), native link (+5.78%),
and all phase/memory/case/block observations remain. No percentages are pooled
across tiny programs or added to earlier source/parallel/PGO results. This measures
the combined compiler build configuration, without component attribution.

The extra default-serial gate first references the wrong relative helper path.
Python fails before any compiler executes. The original driver, command and logs
remain. Correcting that path preserves the frozen compiler/configuration and
passes every artifact and whole executable byte gate. Primary timings are unchanged.

All commands, build/training/qualification logs, source configuration, script
derivation, raw/merged profiles, program/fixture/executable bytes, native inputs
and pure replay are retained. Compiler binaries, target cache and unchanged source
snapshot are excluded and hash/Git pinned. The exact tar stream is recompressed
with gzip level 6 for transport, then every manifest/file/Git blob and pure replay
is verified. The selected PGO tool is root/use (5a1687); the Cargo-managed standard
B72 artifact is preserved. This qualification applies to source d26, the current
program/runtime and this Apple M3. The sub-ten-second objective remains unachieved.
