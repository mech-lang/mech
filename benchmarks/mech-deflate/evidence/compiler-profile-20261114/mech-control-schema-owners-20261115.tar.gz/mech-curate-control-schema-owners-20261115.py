from pathlib import Path
import hashlib,json,shutil,subprocess
repo=Path.cwd();root=Path('/private/tmp/mech-control-schema-owners-20261115');profiles=Path('/private/tmp/mech-mimalloc-current-profile-20261115');packet=Path('/private/tmp/mech-control-schema-owners-packet-20261115');packet.mkdir(exist_ok=False);pin=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest());state=json.loads((root/'source-state.json').read_text());excluded=[]
for p in sorted(root.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(root)
 if rel.as_posix() in ['control','candidate','focused/tests']:
  excluded.append(dict(path=rel.as_posix(),**pin(p)));continue
 dest=packet/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
for p in sorted(profiles.rglob('*')):
 if not p.is_file():continue
 rel=Path('profiles')/p.relative_to(profiles)
 if rel.as_posix()=='profiles/demangle':excluded.append(dict(path=rel.as_posix(),**pin(p)));continue
 dest=packet/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
for row in json.loads((root/'fixture-results.json').read_text()):
 if row['fixture'].startswith('hosts/'):
  dest=packet/'fixture-inputs'/Path(row['fixture']).name;dest.parent.mkdir(exist_ok=True);dest.write_bytes(subprocess.check_output(['git','show',state['base_commit']+':'+row['fixture']]))
publication=dict(source_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),source_base=state['base_commit'],decision=json.loads((root/'decision.json').read_text())['decision']);(packet/'publication-state.json').write_text(json.dumps(publication,indent=2)+'\n');(packet/'excluded-compiler-products.json').write_text(json.dumps(excluded,indent=2)+'\n')
paths=['.cargo/config.toml','Cargo.toml','Cargo.lock','src/compiler_allocator.rs','benchmarks/mech-deflate/native-profile/Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.lock','benchmarks/mech-deflate/native-profile/compile_profile.rs','benchmarks/mech-deflate/native-profile/profile_compile.py','src/engine/src/source_semantics/frontend.rs','src/engine/src/source_semantics/application.rs','src/engine/src/source_semantics/recursive_statement_functions.rs','src/engine/src/source_semantics/recursive_invariants.rs','src/engine/src/source_semantics/pending_schema.rs','src/engine/src/source_semantics/annotation_shape_identity.rs','src/core/src/dimension.rs','src/core/src/schema/validation.rs'];config=[]
for name in paths:
 p=packet/'source-config'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','show',state['base_commit']+':'+name]));config.append(dict(path=name,source_revision=state['base_commit'],**pin(p)))
(packet/'source-config-pins.json').write_text(json.dumps(config,indent=2)+'\n');capture=json.loads(Path('/private/tmp/mech-pr973-refresh-20261115/link/capture/link-command.json').read_text());inputs=[]
for at,row in enumerate(capture['inputs']):
 p=Path(row['retained_path']);wanted={k:row[k] for k in ['bytes','sha256']};assert pin(p)==wanted;rel=Path('native-link-inputs')/(str(at)+'-'+p.name);dest=packet/rel;dest.parent.mkdir(exist_ok=True);shutil.copy2(p,dest);inputs.append(dict(source=row['source'],path=rel.as_posix(),**wanted))
(packet/'native-link-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n');shutil.copytree('/private/tmp/mech-round2-planning-packet-20261114/licenses',packet/'licenses');validation=packet/'validation';validation.mkdir()
for suffix in ['.json','.archive.json']:shutil.copy2(repo/'benchmarks/mech-deflate/native-profile'/('compiler-mimalloc-apple-m3-20261115'+suffix),validation/('prior-qualified'+suffix))
for name in ['mech-build-control-schema-owners-20261115.py','mech-check-control-schema-draft-20261115.py','mech-test-control-schema-owners-20261115.py','mech-qualify-control-schema-owners-20261115.py','mech-profile-mimalloc-current-20261115.py','mech-analyze-mimalloc-current-profile-20261115.py','mech-curate-control-schema-owners-20261115.py','mech-check-qualify-control-schema-owners-20261115.py','mech-qualify-control-owner-serial-20261115.py','mech-prepare-control-owner-replay-20261115.py']:
 shutil.copy2(Path('/private/tmp')/name,packet/name)
shutil.copy2('/private/tmp/mech-replay-control-schema-owners-20261115.py',packet/'replay.py')
(packet/'README.txt').write_text('''Private control-schema owners on retained d834/mimalloc and currentDeflate/runtime.
Four frozen engine files keep exact existing PendingSchema owners in private
captures/parameters through original pure schema validation/handoff, and borrow
selection input during original fresh dimension remapping. No new cache, public
API, grammar, original inventory/identity/admission or fresh proof changes.
Current fe37 control and candidate use same61programflags+2workers/mimalloc.
All sources/patches/checks,13existing pureowner/annotation foundationtests,
14fixtures, balanced Object and native observations when performed, complete
outputs/metadata/executable gates, native inputs and wholecommit proof remain.
The foundation harness copies unchanged exact modules; it does not compile the
changed frontend sites, which are covered by wholeprogram/fixture gates.
Two earlier fresh fe37 stack diagnostics and their full output/exe gates are
included separately, outside all primary means. Corrected Callgraph-only
analysis and raw-to-demangled mapping replay exactly; waiting/inclusive stacks
are not CPU shares or timing improvements. Compiler/test/demangle executables
and dependency libraries are excluded and hashpinned. No program runtime
campaign is claimed when complete images match. Goalunder10 remains open.
''');print(packet)
