from pathlib import Path
import hashlib,json,shutil,subprocess,time
repo=Path.cwd();root=Path('/private/tmp/mech-control-schema-owners-20261115');out=root/'focused';out.mkdir();pins=[]
for name in ['pending_schema.rs','annotation_shape_identity.rs']:
 source=repo/'src/engine/src/source_semantics'/name;dest=out/name;shutil.copy2(source,dest);pins.append(dict(source_path=source.relative_to(repo).as_posix(),sha256=hashlib.sha256(source.read_bytes()).hexdigest(),path=name))
(out/'harness.rs').write_text('#![allow(dead_code)]\nmod pending_schema;\nmod annotation_shape_identity;\n')
rows=[json.loads(x) for x in Path('/private/tmp/mech-compiler-mimalloc-20261115/candidate-build.jsonl').read_text().splitlines()];files=[Path(p) for row in rows if row.get('reason')=='compiler-artifact' and row['target']['name']=='mech_core' for p in row['filenames'] if p.endswith('.rlib')];assert len(files)==1;core=files[0];command=['rustc','+nightly-2026-03-03','--edition=2024','--crate-name','control_schema_owner_foundation_tests','--test',str(out/'harness.rs'),'-C','opt-level=3','-C','lto=thin','-C','codegen-units=1','-D','warnings','-L','dependency='+str(core.parent),'--extern','mech_core='+str(core),'-o',str(out/'tests')]
(out/'command.json').write_text(json.dumps(dict(command=command,source_pins=pins,dependencies=[dict(name='mech_core',path=str(core),sha256=hashlib.sha256(core.read_bytes()).hexdigest())],scope='Exact unchanged production owner/annotation modules and their complete unit suites. Checks pure cache success/error/mutation and copy-on-write isolation used by new private control storage. This does not compile the changed frontend sites into the harness; whole-program/fixture byte gates cover those sites. No new tests or source substitutions.'),indent=2)+'\n')
for stage,args in [('build',command),('test',[str(out/'tests'),'--nocapture'])]:
 start=time.monotonic()
 with (out/(stage+'.stdout.log')).open('w') as stdout,(out/(stage+'.stderr.log')).open('w') as stderr:completed=subprocess.run(args,stdout=stdout,stderr=stderr)
 record=dict(exit_code=completed.returncode,seconds=time.monotonic()-start)
 if stage=='build' and completed.returncode==0:record['binary_sha256']=hashlib.sha256((out/'tests').read_bytes()).hexdigest()
 (out/(stage+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(dict(stage=stage,**record)),flush=True);assert completed.returncode==0
