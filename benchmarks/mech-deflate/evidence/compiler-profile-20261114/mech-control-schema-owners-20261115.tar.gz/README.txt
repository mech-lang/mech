Private control-schema owners on retained d834/mimalloc and currentDeflate/runtime.
Four frozen engine files keep exact existing PendingSchema owners in private
captures/parameters through original pure schema validation/handoff, and borrow
selection input during original fresh dimension remapping. No new cache, public
API, grammar, original inventory/identity/admission or fresh proof changes.
Current fe37 control and candidate use same61programflags+2workers/mimalloc.
All sources/patches/checks,13existing pureowner/annotation foundationtests,
14fixtures, balanced Object and native observations when performed, complete
outputs/metadata/executable gates, native inputs and wholecommit proof remain.
The foundation harness copies unchanged exact modules; it does not compile the
changed frontend sites, which are covered by wholeprogram/fixture gates.
Two earlier fresh fe37 stack diagnostics and their full output/exe gates are
included separately, outside all primary means. Corrected Callgraph-only
analysis and raw-to-demangled mapping replay exactly; waiting/inclusive stacks
are not CPU shares or timing improvements. Compiler/test/demangle executables
and dependency libraries are excluded and hashpinned. No program runtime
campaign is claimed when complete images match. Goalunder10 remains open.
