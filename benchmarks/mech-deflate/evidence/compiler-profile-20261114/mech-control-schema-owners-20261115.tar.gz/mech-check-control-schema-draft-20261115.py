from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
repo=Path.cwd();root=Path('/private/tmp/mech-control-schema-owners-20261115');draft=json.loads((root/'draft-state.json').read_text());attempt=root/'draft-check-1';attempt.mkdir();(attempt/'candidate.patch').write_bytes(subprocess.check_output(['git','diff','--binary']))
for name in draft['paths']:
 p=attempt/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/name,p)
command=['cargo','+nightly-2026-03-03','check','--locked','--offline','--profile','compiler','-j4','--manifest-path','benchmarks/mech-deflate/native-profile/Cargo.toml','--bin','compile_profile','--message-format=json'];env=dict(os.environ,CARGO_TARGET_DIR='/private/tmp/mech-level12-compile-target',CARGO_INCREMENTAL='0');assert not env.get('RUSTFLAGS') and not env.get('CARGO_ENCODED_RUSTFLAGS');started=time.monotonic()
with (attempt/'stdout.jsonl').open('w') as stdout,(attempt/'stderr.log').open('w') as stderr:completed=subprocess.run(command,env=env,stdout=stdout,stderr=stderr)
record=dict(command=command,exit_code=completed.returncode,seconds=time.monotonic()-started,patch_sha256=hashlib.sha256((attempt/'candidate.patch').read_bytes()).hexdigest());(attempt/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
for x in [json.loads(s) for s in (attempt/'stdout.jsonl').read_text().splitlines()]:
 if x.get('reason')=='compiler-message' and x.get('message',{}).get('level')=='error':print(x['message']['rendered'],flush=True)
