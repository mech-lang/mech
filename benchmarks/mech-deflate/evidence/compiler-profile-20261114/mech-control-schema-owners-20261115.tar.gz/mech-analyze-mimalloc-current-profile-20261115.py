from pathlib import Path
import argparse,collections,hashlib,json,re
parser=argparse.ArgumentParser();parser.add_argument('root',type=Path);args=parser.parse_args();r=args.root;out=[];mapping={};sourcepins=[]
for name in ['sample-1','sample-2']:
 raw=r/name/'sample-001.txt';dest=r/name/'demangled.txt';original=raw.read_text().splitlines();demangled=dest.read_text().splitlines();assert len(original)==len(demangled)
 for line,transformed in zip(original,demangled):
  start=line.find('_R')
  if start<0:start=line.find('_ZN')
  if start<0:assert line==transformed;continue
  end=next((i for i in range(start,len(line)) if line[i].isspace()),len(line));symbol=line[start:end];prefix=line[:start];suffix=line[end:];assert transformed.startswith(prefix) and transformed.endswith(suffix);value=transformed[len(prefix):len(transformed)-len(suffix)] if suffix else transformed[len(prefix):]
  assert symbol not in mapping or mapping[symbol]==value;mapping[symbol]=value;assert prefix+mapping[symbol]+suffix==transformed
 sourcepins.append(dict(sample=name,raw_sha256=hashlib.sha256(raw.read_bytes()).hexdigest(),demangled_sha256=hashlib.sha256(dest.read_bytes()).hexdigest()))
 lines=demangled;a=lines.index('Call graph:')+1;b=next(i for i,x in enumerate(lines) if x.startswith('Total number in stack'));stack=[];nodes=[]
 for line in lines[a:b]:
  match=re.match(r'^(.*?)(\d+) (.*?)(?:  \(in | \(in )',line)
  if not match:continue
  depth=match.start(2);node=dict(depth=depth,count=int(match[2]),function=match[3],children=[])
  while stack and stack[-1]['depth']>=depth:stack.pop()
  if stack:stack[-1]['children'].append(node)
  stack.append(node);nodes.append(node)
 counts=collections.Counter()
 for node in nodes:
  if not node['children']:counts[node['function']]+=node['count']
 paths=[]
 for i,node in enumerate(nodes):
  if 'canonicalize_dimension_environment' in node['function'] or ('to_vec' in node['function'] and 'DimensionParameterDeclaration' in node['function']):
   trail=[node['function']];d=node['depth']
   for p in reversed(nodes[:i]):
    if p['depth']<d:trail.append(p['function']);d=p['depth']
   paths.append(dict(samples=node['count'],path=list(reversed(trail))[-16:]))
 out.append(dict(sample=name,top_named_leaf_counts=counts.most_common(45),dimension_paths=paths,scope='Callgraph only, excludes flat summary table. Counts are sampled thread stacks, not exclusive CPU percentages; waiting leaves remain visible. Leafcounts have no children in parsed tree.'))
text=json.dumps(out,indent=2)+'\n';assert (r/'callgraph-analysis.json').read_text()==text
bridge=json.dumps(dict(source_pins=sourcepins,symbols=mapping,scope='Observed raw-to-demangled symbol pairs from hash-pinned rustc_demangle helper. Every prefix/suffix, line count and transformed symbol is checked; replay needs no compiler/demangler binary.'),indent=2,sort_keys=True)+'\n'
p=r/'demangle-symbols.json'
if p.exists():assert p.read_text()==bridge
else:p.write_text(bridge)
print(json.dumps(dict(samples=2,symbols=len(mapping),analysis_byte_identical=True)))
