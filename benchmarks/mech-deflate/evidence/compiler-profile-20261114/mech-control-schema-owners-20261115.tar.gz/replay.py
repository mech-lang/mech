from pathlib import Path
import hashlib,json,re,statistics,tomllib
packet=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
cache={}
def pin(p):
 if p not in cache:cache[p]=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 return cache[p]
def apply(source,patch):
 lines=source.splitlines(keepends=True);diff=patch.splitlines(keepends=True);out=[];at=0;i=0
 while i<len(diff):
  m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',diff[i])
  if not m:i+=1;continue
  start=max(0,int(m[1])-1);assert start>=at;out.extend(lines[at:start]);at=start;i+=1
  while i<len(diff) and not diff[i].startswith('@@'):
   line=diff[i]
   if line.startswith(' '):assert lines[at]==line[1:];out.append(lines[at]);at+=1
   elif line.startswith('-'):assert lines[at]==line[1:];at+=1
   elif line.startswith('+'):out.append(line[1:])
   else:raise AssertionError(line)
   i+=1
 out.extend(lines[at:]);return ''.join(out)
def numerical(rows,fields):
 result={}
 for key,fn in fields.items():
  values={v:[fn(row) for row in rows if row['variant']==v] for v in ['control','candidate']}
  a=statistics.mean(values['control']);values['mean_reduction_fraction']=1-statistics.mean(values['candidate'])/a if a else None;result[key]=values
 return result
def blocks(rows,fields):
 result=[]
 for group in [rows[:4],rows[4:]]:
  block={}
  for key,fn in fields.items():
   item={v:statistics.mean(fn(row) for row in group if row['variant']==v) for v in ['control','candidate']};item['mean_reduction_fraction']=1-item['candidate']/item['control'] if item['control'] else None;block[key]=item
  result.append(block)
 return result


root=packet;state=read(root/'source-state.json');publication=read(root/'publication-state.json');decision=read(root/'decision.json');prior=read(root/'validation/prior-qualified.json')
assert pin(root/'validation/prior-qualified.json')['sha256']==read(root/'validation/prior-qualified.archive.json')['replay_sha256']
expected=prior['output_hashes'];control_binary=prior['compiler_binary_sha256']['candidate'];products={x['path']:x for x in read(root/'excluded-compiler-products.json')};binaries={v:products[v]['sha256'] for v in ['control','candidate']};assert binaries['control']==control_binary=='fe37d6e76a4d847caf1751e6cd122694f0440bb7be32f5edc45512262d80830c'
exe=dict(bytes=2060440,sha256='d6c65cc3fb18acc4be77dce329962105bf0f2b56dd2623a12f466256463eca61')
for row in read(root/'source-config-pins.json'):assert pin(root/'source-config'/row['path'])=={k:row[k] for k in ['bytes','sha256']}
for row in read(root/'native-link-inputs.json'):assert pin(root/row['path'])=={k:row[k] for k in ['bytes','sha256']}
patch=(root/'candidate.patch').read_text();assert pin(root/'candidate.patch')['sha256']==state['patch_sha256'];sections={}
for part in re.split(r'(?m)(?=^diff --git )',patch):
 if not part:continue
 m=re.match(r'diff --git a/(\S+) b/(\S+)\n',part);assert m and m[1]==m[2];sections[m[1]]=part
assert set(sections)=={x['path'] for x in state['files']} and len(sections)==4
for row in state['files']:
 name=row['path'];before=(root/'reference-source'/name).read_text();after=(root/'candidate-source'/name).read_text()
 assert before==(root/'source-config'/name).read_text() and pin(root/'reference-source'/name)['sha256']==row['reference_sha256'] and pin(root/'candidate-source'/name)['sha256']==row['candidate_sha256'] and apply(before,sections[name])==after
check=read(root/'candidate-check.json');build=read(root/'candidate-build.json');cli_check=read(root/'candidate-cli-check.json')
for row in [check,build,cli_check]:assert row['exit_code']==0 and row['base_commit']==state['base_commit'] and row['patch_sha256']==state['patch_sha256'] and row['CARGO_INCREMENTAL']=='0'
assert build['binary_sha256']==binaries['candidate'];draft=read(root/'draft-check-1/result.json');assert draft['exit_code']==0 and draft['patch_sha256']==pin(root/'draft-check-1/candidate.patch')['sha256']
focused=root/'focused';assert read(focused/'build.json')['exit_code']==read(focused/'test.json')['exit_code']==0 and read(focused/'build.json')['binary_sha256']==products['focused/tests']['sha256'] and 'test result: ok. 13 passed; 0 failed' in (focused/'test.stdout.log').read_text()
for row in read(focused/'command.json')['source_pins']:
 assert pin(focused/row['path'])['sha256']==row['sha256'] and (focused/row['path']).read_bytes()==(root/'source-config'/row['source_path']).read_bytes()
profiles=root/'profiles';config=read(profiles/'configuration.json');assert config['compiler']['sha256']==binaries['control'] and config['source_commit']=='d834508336e4533320cea8587b3e0e7a53124a94'
profile_rows=read(profiles/'results.json');assert len(profile_rows)==2
for row in profile_rows:
 d=profiles/row['name'];command=read(profiles/(row['name']+'-command.json'));assert row['excluded_from_primary'] and command['profiling_excluded_from_primary'] and command['compiler']==config['compiler'] and command['flags']==config['flags']
 assert read(d/'process.json')==row['process'] and row['process']['exit_code']==0 and row['process']['samples']==1 and row['process']['sampling_error'] is None
 for name,item in expected.items():assert pin(d/name)==item and read(d/'output-check.json')[name]==dict(item,matches_reference=True)
 assert pin(profiles/(row['name']+'-link')/'worker')==exe and row['whole_executable_sha256']==exe['sha256']
assert products['profiles/demangle']['sha256']==read(profiles/'demangle-reuse.json')['binary_sha256']=='faa83f6c6622302f1f765f1ae06da11d42184ae4a0474a4652dcac44014e9e4d'
import subprocess,sys
analysis=json.loads(subprocess.check_output([sys.executable,str(root/'mech-analyze-mimalloc-current-profile-20261115.py'),str(profiles)]));assert analysis==dict(samples=2,symbols=991,analysis_byte_identical=True)
profile_analysis=read(profiles/'callgraph-analysis.json')
flags=read(root/'runtime-flags.json');wanted=dict(flags,MECH_COMPACT_COMPILE_THREADS='2');assert len(flags)==61 and read(root/'reference-pins.json')==expected
for name,item in expected.items():assert pin(root/'reference'/name)==item
order=[('control','control-1'),('candidate','candidate-1'),('candidate','candidate-2'),('control','control-2'),('candidate','candidate-3'),('control','control-3'),('control','control-4'),('candidate','candidate-4')]
rows=[];screens=[]
for variant,name in [('control','control-screen'),('candidate','candidate-screen')]+order:
 d=root/name;command=read(root/(name+'-command.json'));process=read(d/'process.json');comp=read(d/'compile.json');checks=read(d/'output-check.json')
 assert command['flags']==wanted and not command['profiling_excluded_from_primary'] and command['binary_sha256']==binaries[variant]
 assert process['exit_code']==0 and process['samples']==0 and process['sampling_error'] is None and process['elapsed_boundary']=='driver_start_to_process_wait_completion'
 assert process['elapsed_seconds']>comp['total_seconds']
 for filename,item in expected.items():assert pin(d/filename)==item and checks[filename]==dict(item,matches_current_control_output=True)
 row=dict(name=name,variant=variant,compile=comp,process=process,files=checks)
 if name.endswith('-screen'):screens.append(row);continue
 stamps=[json.loads(x) for x in (d/'stages.jsonl').read_text().splitlines()];elapsed=lambda prefix:next(x['elapsed'] for x in stamps if x['line'].startswith(prefix))
 for key,begin,end in [('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]:row[key]=elapsed(end)-elapsed(begin)
 row['compaction_seconds']=elapsed('compact-stage: CFG cleanup')-elapsed('compact-stage: compact values before=');row['cleanup_including_compaction_seconds']=row['cleanup_seconds']+row['compaction_seconds']
 for key,prefix in [('value_ids_before','compact-stage: compact values before='),('value_ids_after','compact-values: retained=')]:row[key]=int(next(x['line'] for x in stamps if x['line'].startswith(prefix)).split('=')[-1])
 for key,pattern in [('instructions',r'(\d+)  instructions retired'),('max_rss_bytes',r'(\d+)  maximum resident set size'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]:row[key]=int(re.search(pattern,(d/'stderr.log').read_text())[1])
 rows.append(row)
assert rows==read(root/'cohort.json')
fields=dict(compiler_seconds=lambda r:r['compile']['total_seconds'],whole_process_seconds=lambda r:r['process']['elapsed_seconds'])
for phase in ['parse','catalog','frontend','artifact','encode','native']:fields[phase+'_seconds']=lambda r,p=phase:next(x['seconds'] for x in r['compile']['phases'] if x['phase']==p)
for key in ['canonical_lowering_seconds','preparation_seconds','numeric_generation_seconds','source_cfg_seconds','cleanup_including_compaction_seconds','cleanup_seconds','compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:fields[key]=lambda r,k=key:r[k]
nums=numerical(rows,fields);assert nums==read(root/'numerical-summary.json')
fixtures=read(root/'fixture-results.json');assert len(fixtures)==14
for row in fixtures:
 name=row['fixture'].split(':')[-1] if ':' in row['fixture'] else Path(row['fixture']).stem
 assert pin(root/'fixture-inputs'/(name+'.mec'))['sha256']==row['source_sha256'] and row['all_outputs_match'] and row['variants']['control']==row['variants']['candidate']
 for variant in ['control','candidate']:
  d=root/'fixtures'/name/variant;cmd=read(d/'command.json');assert cmd['flags']==wanted and cmd['binary_sha256']==binaries[variant]
  assert row['variants'][variant]['exit_code']==0 and len(row['variants'][variant]['files'])==4
  for filename,item in row['variants'][variant]['files'].items():assert pin(d/filename)==item
links=read(root/'final-executable-results.json');assert len(links)==2
for variant,row in zip(['control','candidate'],links):
 d=root/('link-'+variant);assert row['variant']==variant and row['exit_code']==0 and row['matches_complete_baseline_executable'] and not row['fresh_runtime_campaign']
 assert pin(d/'worker')==exe==dict(bytes=row['executable_bytes'],sha256=row['executable_sha256']) and read(d/'command.json')['environment']=={'ZERO_AR_DATE':'1'}


serial=root/'candidate-serial-gate';assert read(serial/'process.json')['exit_code']==0
serial_command=read(root/'candidate-serial-gate-command.json');assert serial_command['flags']==dict(wanted,MECH_COMPACT_COMPILE_THREADS='0') and serial_command['binary_sha256']==binaries['candidate']
for filename,item in expected.items():assert pin(serial/filename)==item and read(serial/'output-check.json')[filename]==dict(item,matches_current_control_output=True)
serial_links=read(root/'serial-final-executable-results.json');assert len(serial_links)==1 and serial_links[0]['matches_complete_baseline_executable'] and pin(root/'link-candidate-serial/worker')==exe
pipeline=read(root/'qualification-pipeline.json');assert [r['stage'] for r in pipeline]==['screens','executable-gates','fixtures-object-cohort'] and all(r['state']=='complete' and r['exit_code']==0 for r in pipeline)
native_summary=None
if (root/'native-cohort.json').exists():
 native=read(root/'native-cohort.json');assert len(native)==8
 for row,(variant,name) in zip(native,[(v,'native-'+n) for v,n in order]):
  d=root/name;cmd=read(d/'command.json');actual=read(d/'result.json');assert row==dict(actual,name=name,primary_cohort=True) and row['variant']==variant and row['compiler_exit_code']==row['link_exit_code']==0 and row['matches_complete_baseline_executable']
  assert pin(d/'worker')==exe and cmd['flags']==wanted and cmd['compiler_sha256']==binaries[variant] and cmd['ZERO_AR_DATE']=='1'
  for filename,item in expected.items():assert pin(d/filename)==item and row['files'][filename]==dict(item,matches_frozen_reference=True)
 nf={key:(lambda r,k=key:r[k]) for key in ['source_to_executable_seconds','source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']};nnums=numerical(native,nf);nblocks=[]
 for group in [native[:4],native[4:]]:
  means={v:statistics.mean(row['source_to_executable_seconds'] for row in group if row['variant']==v) for v in ['control','candidate']};means['mean_reduction_fraction']=1-means['candidate']/means['control'];nblocks.append(means)
 saved=read(root/'native-numerical-summary.json');assert nnums==saved['numerical_summary'] and nblocks==saved['balanced_blocks'];native_summary=dict(numerical_summary=nnums,balanced_blocks=nblocks)
if decision['decision']=='retained':
 assert native_summary and all(x['mean_reduction_fraction']>0 for x in native_summary['balanced_blocks']);commit=read(root/'qualification-commit.json');assert commit['source_commit']==decision['source_commit']==publication['source_revision'] and commit['parent']==state['base_commit'] and commit['entire_commit_diff_sha256']==state['patch_sha256'] and set(commit['files'])==set(sections)
else:assert decision['decision']=='rejected' and decision['production_source_restored'] and decision['canonical_tool_sha256']==control_binary
summary=dict(source_revision=publication['source_revision'],source_base=state['base_commit'],source_patch_sha256=state['patch_sha256'],compiler_binary_sha256=binaries,decision=decision,check=check,build=build,native_cli_check=cli_check,foundation_test_count=13,foundation_tests=read(focused/'test.json'),output_hashes=expected,final_executable=exe,program_flags_count=61,measured_compile_threads=2,fixture_pairs=14,numerical_summary=nums,balanced_blocks=blocks(rows,fields),preliminary_screens=screens,final_links=links,native=native_summary,selection_profiles=profile_analysis,scope=[
 'Privatecontrol captures/parameters keep exact existing PendingSchema owners and their purecanonicaldata through original validation/handoff; no newcache. Mutation uses existing COW/invalidation. Alloriginalinventory/IDs/admission and freshshape/factory/currentvisit checks remain. Selectionborrows input during originalfreshremapping, withsame materializationfornoops. Fourfrozenenginefiles; no publicAPI/grammar/emittedprogramallocator change.',
 'Both standard compilerexecutables use retained pinnedmimalloc,61programflags and2workers/currentDeflate/runtime. EightObject and any separatelyrecorded complete-native observations use serialABBA/BAABorder, cachedfixedadapter and no competing heavy job. Compilerconstruction/checks, foundationtests, screens, profiles andarchival excludedfromprimary. Alladverseobservations remain.',
 'All4source/bytecode/Object/complete metadata files and everygated complete executable match;14fixturepairs pass. Foundationharness copies the unchanged exact owner/annotation modules with13existingtests; it does not compilechangedfrontend sites, whichwholeprogram/fixture gates cover. RealnativeCLIcheck uses cranelift_build. No freshprogramruntimecampaign or scalarretirement claimed.',
 'Twofresh fe37/d834 profiles precede thetrial and preserveall4outputs/fullcachedexe. AnalysisisboundedtoCallgraph, excludesflat table, reconstructs raw-to-demangled mappings and source selectionexactly. Waiting/inclusive stacks are notCPUshares or exclusivephaseclock claims. Compiler/test/demangle binaries are excludedandSHApinned; sourceandlogs included. Completecompilationbelow10seconds remainsopen.'
])
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';saved=root/'summary.json'
if saved.exists():assert saved.read_text()==encoded
else:saved.write_text(encoded)
print(encoded,end='')
