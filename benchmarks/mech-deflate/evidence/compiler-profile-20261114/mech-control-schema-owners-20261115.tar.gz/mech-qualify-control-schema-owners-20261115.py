from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
repo=Path.cwd();root=Path('/private/tmp/mech-control-schema-owners-20261115');state=json.loads((root/'source-state.json').read_text());scripts=root/'qualification-scripts';paths=[r['path'] for r in state['files']]
assert all(Path(name).read_bytes()==(root/'candidate-source'/name).read_bytes() for name in paths) and subprocess.check_output(['git','diff','--binary','--',*paths])==(root/'candidate.patch').read_bytes()
assert json.loads((root/'candidate-build.json').read_text())['exit_code']==json.loads((root/'focused/test.json').read_text())['exit_code']==0
assert json.loads((root/'candidate-cli-check.json').read_text())['exit_code']==0
assert 'test result: ok. 13 passed; 0 failed' in (root/'focused/test.stdout.log').read_text()
pin=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
binary={v:pin(root/v) for v in ['control','candidate']};assert binary['control']['sha256']=='fe37d6e76a4d847caf1751e6cd122694f0440bb7be32f5edc45512262d80830c'
assert binary['candidate']['sha256']==json.loads((root/'candidate-build.json').read_text())['binary_sha256']
(root/'qualification.json').write_text(json.dumps(dict(source_base=state['base_commit'],patch_sha256=pin(root/'candidate.patch')['sha256'],compiler=binary,common_compile_threads=2,program_flags_count=61,scope='Privatecontrol captures/parameters retain exact PendingSchema owner and existing purecanonicalcache. Firstvalidationdemands, fullinventory, u32identities,originalfirstrefusal and freshshape/factory/currentvisit checks unchanged. Selectionborrowsinputthroughfreshremapping, noopsmaterializeasbefore. Fourfrozenfiles e7base; controlretained d834mimalloc fe37. Same61flags+2workers/mimalloc inboth; exact4files/fullmetadata/wholeexe required. Serialuncontendedprimary; finishfrozenqualification ifremoteadvances.'),indent=2)+'\n')
env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')};records=[]
stages=[('screens','mech-screen-control-schema-owners-current-20261115.py'),('executable-gates','mech-cached-native-link-control-schema-owners-current-20261115.py'),('fixtures-object-cohort','mech-qualify-control-schema-owners-current-20261115.py')]
if '--object-only' not in sys.argv:
    stages.append(('native-cohort','mech-native-cohort-control-schema-owners-current-20261115.py'))
for stage,name in stages:
    command=[sys.executable,str(scripts/name)];row=dict(stage=stage,state='running',command=command,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(row);(root/'qualification-pipeline.json').write_text(json.dumps(records,indent=2)+'\n');started=time.monotonic()
    with (root/(stage+'.stdout.log')).open('w') as stdout,(root/(stage+'.stderr.log')).open('w') as stderr:completed=subprocess.run(command,cwd=repo,env=env,stdout=stdout,stderr=stderr)
    row.update(state='complete' if completed.returncode==0 else 'failed',exit_code=completed.returncode,seconds=time.monotonic()-started);(root/'qualification-pipeline.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True);assert completed.returncode==0
