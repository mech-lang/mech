from pathlib import Path
old=Path('/private/tmp/mech-replay-compiler-mimalloc-20261115.py').read_text();helpers=old[:old.index("root=packet;state=read(root/'source-state.json')")];core=old[old.index("flags=read(root/'runtime-flags.json')"):old.index("serial=root/'candidate-serial-gate'")]
prefix=r'''
root=packet;state=read(root/'source-state.json');publication=read(root/'publication-state.json');decision=read(root/'decision.json');prior=read(root/'validation/prior-qualified.json')
assert pin(root/'validation/prior-qualified.json')['sha256']==read(root/'validation/prior-qualified.archive.json')['replay_sha256']
expected=prior['output_hashes'];control_binary=prior['compiler_binary_sha256']['candidate'];products={x['path']:x for x in read(root/'excluded-compiler-products.json')};binaries={v:products[v]['sha256'] for v in ['control','candidate']};assert binaries['control']==control_binary=='fe37d6e76a4d847caf1751e6cd122694f0440bb7be32f5edc45512262d80830c'
exe=dict(bytes=2060440,sha256='d6c65cc3fb18acc4be77dce329962105bf0f2b56dd2623a12f466256463eca61')
for row in read(root/'source-config-pins.json'):assert pin(root/'source-config'/row['path'])=={k:row[k] for k in ['bytes','sha256']}
for row in read(root/'native-link-inputs.json'):assert pin(root/row['path'])=={k:row[k] for k in ['bytes','sha256']}
patch=(root/'candidate.patch').read_text();assert pin(root/'candidate.patch')['sha256']==state['patch_sha256'];sections={}
for part in re.split(r'(?m)(?=^diff --git )',patch):
 if not part:continue
 m=re.match(r'diff --git a/(\S+) b/(\S+)\n',part);assert m and m[1]==m[2];sections[m[1]]=part
assert set(sections)=={x['path'] for x in state['files']} and len(sections)==4
for row in state['files']:
 name=row['path'];before=(root/'reference-source'/name).read_text();after=(root/'candidate-source'/name).read_text()
 assert before==(root/'source-config'/name).read_text() and pin(root/'reference-source'/name)['sha256']==row['reference_sha256'] and pin(root/'candidate-source'/name)['sha256']==row['candidate_sha256'] and apply(before,sections[name])==after
check=read(root/'candidate-check.json');build=read(root/'candidate-build.json');cli_check=read(root/'candidate-cli-check.json')
for row in [check,build,cli_check]:assert row['exit_code']==0 and row['base_commit']==state['base_commit'] and row['patch_sha256']==state['patch_sha256'] and row['CARGO_INCREMENTAL']=='0'
assert build['binary_sha256']==binaries['candidate'];draft=read(root/'draft-check-1/result.json');assert draft['exit_code']==0 and draft['patch_sha256']==pin(root/'draft-check-1/candidate.patch')['sha256']
focused=root/'focused';assert read(focused/'build.json')['exit_code']==read(focused/'test.json')['exit_code']==0 and read(focused/'build.json')['binary_sha256']==products['focused/tests']['sha256'] and 'test result: ok. 13 passed; 0 failed' in (focused/'test.stdout.log').read_text()
for row in read(focused/'command.json')['source_pins']:
 assert pin(focused/row['path'])['sha256']==row['sha256'] and (focused/row['path']).read_bytes()==(root/'source-config'/row['source_path']).read_bytes()
profiles=root/'profiles';config=read(profiles/'configuration.json');assert config['compiler']['sha256']==binaries['control'] and config['source_commit']=='d834508336e4533320cea8587b3e0e7a53124a94'
profile_rows=read(profiles/'results.json');assert len(profile_rows)==2
for row in profile_rows:
 d=profiles/row['name'];command=read(profiles/(row['name']+'-command.json'));assert row['excluded_from_primary'] and command['profiling_excluded_from_primary'] and command['compiler']==config['compiler'] and command['flags']==config['flags']
 assert read(d/'process.json')==row['process'] and row['process']['exit_code']==0 and row['process']['samples']==1 and row['process']['sampling_error'] is None
 for name,item in expected.items():assert pin(d/name)==item and read(d/'output-check.json')[name]==dict(item,matches_reference=True)
 assert pin(profiles/(row['name']+'-link')/'worker')==exe and row['whole_executable_sha256']==exe['sha256']
assert products['profiles/demangle']['sha256']==read(profiles/'demangle-reuse.json')['binary_sha256']=='faa83f6c6622302f1f765f1ae06da11d42184ae4a0474a4652dcac44014e9e4d'
import subprocess,sys
analysis=json.loads(subprocess.check_output([sys.executable,str(root/'mech-analyze-mimalloc-current-profile-20261115.py'),str(profiles)]));assert analysis==dict(samples=2,symbols=991,analysis_byte_identical=True)
profile_analysis=read(profiles/'callgraph-analysis.json')
'''
suffix=r'''
pipeline=read(root/'qualification-pipeline.json');assert [r['stage'] for r in pipeline]==['screens','executable-gates','fixtures-object-cohort'] and all(r['state']=='complete' and r['exit_code']==0 for r in pipeline)
native_summary=None
if (root/'native-cohort.json').exists():
 native=read(root/'native-cohort.json');assert len(native)==8
 for row,(variant,name) in zip(native,[(v,'native-'+n) for v,n in order]):
  d=root/name;cmd=read(d/'command.json');actual=read(d/'result.json');assert row==dict(actual,name=name,primary_cohort=True) and row['variant']==variant and row['compiler_exit_code']==row['link_exit_code']==0 and row['matches_complete_baseline_executable']
  assert pin(d/'worker')==exe and cmd['flags']==wanted and cmd['compiler_sha256']==binaries[variant] and cmd['ZERO_AR_DATE']=='1'
  for filename,item in expected.items():assert pin(d/filename)==item and row['files'][filename]==dict(item,matches_frozen_reference=True)
 nf={key:(lambda r,k=key:r[k]) for key in ['source_to_executable_seconds','source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']};nnums=numerical(native,nf);nblocks=[]
 for group in [native[:4],native[4:]]:
  means={v:statistics.mean(row['source_to_executable_seconds'] for row in group if row['variant']==v) for v in ['control','candidate']};means['mean_reduction_fraction']=1-means['candidate']/means['control'];nblocks.append(means)
 saved=read(root/'native-numerical-summary.json');assert nnums==saved['numerical_summary'] and nblocks==saved['balanced_blocks'];native_summary=dict(numerical_summary=nnums,balanced_blocks=nblocks)
if decision['decision']=='retained':
 assert native_summary and all(x['mean_reduction_fraction']>0 for x in native_summary['balanced_blocks']);commit=read(root/'qualification-commit.json');assert commit['source_commit']==decision['source_commit']==publication['source_revision'] and commit['parent']==state['base_commit'] and commit['entire_commit_diff_sha256']==state['patch_sha256'] and set(commit['files'])==set(sections)
else:assert decision['decision']=='rejected' and decision['production_source_restored'] and decision['canonical_tool_sha256']==control_binary
summary=dict(source_revision=publication['source_revision'],source_base=state['base_commit'],source_patch_sha256=state['patch_sha256'],compiler_binary_sha256=binaries,decision=decision,check=check,build=build,native_cli_check=cli_check,foundation_test_count=13,foundation_tests=read(focused/'test.json'),output_hashes=expected,final_executable=exe,program_flags_count=61,measured_compile_threads=2,fixture_pairs=14,numerical_summary=nums,balanced_blocks=blocks(rows,fields),preliminary_screens=screens,final_links=links,native=native_summary,selection_profiles=profile_analysis,scope=[
 'Privatecontrol captures/parameters keep exact existing PendingSchema owners and their purecanonicaldata through original validation/handoff; no newcache. Mutation uses existing COW/invalidation. Alloriginalinventory/IDs/admission and freshshape/factory/currentvisit checks remain. Selectionborrows input during originalfreshremapping, withsame materializationfornoops. Fourfrozenenginefiles; no publicAPI/grammar/emittedprogramallocator change.',
 'Both standard compilerexecutables use retained pinnedmimalloc,61programflags and2workers/currentDeflate/runtime. EightObject and any separatelyrecorded complete-native observations use serialABBA/BAABorder, cachedfixedadapter and no competing heavy job. Compilerconstruction/checks, foundationtests, screens, profiles andarchival excludedfromprimary. Alladverseobservations remain.',
 'All4source/bytecode/Object/complete metadata files and everygated complete executable match;14fixturepairs pass. Foundationharness copies the unchanged exact owner/annotation modules with13existingtests; it does not compilechangedfrontend sites, whichwholeprogram/fixture gates cover. RealnativeCLIcheck uses cranelift_build. No freshprogramruntimecampaign or scalarretirement claimed.',
 'Twofresh fe37/d834 profiles precede thetrial and preserveall4outputs/fullcachedexe. AnalysisisboundedtoCallgraph, excludesflat table, reconstructs raw-to-demangled mappings and source selectionexactly. Waiting/inclusive stacks are notCPUshares or exclusivephaseclock claims. Compiler/test/demangle binaries are excludedandSHApinned; sourceandlogs included. Completecompilationbelow10seconds remainsopen.'
])
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';saved=root/'summary.json'
if saved.exists():assert saved.read_text()==encoded
else:saved.write_text(encoded)
print(encoded,end='')
'''
p=Path('/private/tmp/mech-replay-control-schema-owners-20261115.py');p.write_text(helpers+prefix+core+suffix);compile(p.read_text(),str(p),'exec');print('Preparedpure replay; no datareplay duringprimarycohort.')
