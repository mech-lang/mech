from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess, sys, time

root = Path('/private/tmp/mech-current-native-pgo-20261115')
pipeline = json.loads((root / 'pipeline.json').read_text())
assert [r['stage'] for r in pipeline] == ['control','native-control','native-output-gates','generate','training','use']
assert all(r['state'] == 'complete' and r['exit_code'] == 0 for r in pipeline)
source = root / 'source'
state = json.loads((root / 'source-state.json').read_text())
assert state['source_commit'] == 'aaef2a932bf81c7638c522dc777a2b78f0abcb5d'
out = root / 'qualification'
assert not out.exists()
out.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
for original, name in [('control','control'),('use','candidate')]:
    shutil.copy2(root / original, out / name)
    assert sha(out / name) == json.loads((root / (original + '-build.json')).read_text())['binary_sha256']
shutil.copytree(root / 'reference', out / 'reference')
for name in ['reference-pins.json','runtime-flags.json']:
    shutil.copy2(root / name, out / name)
shutil.copy2(source / 'benchmarks/mech-deflate/native-profile/profile_compile.py', root / 'qualification-scripts/profile_compile.py')
config = dict(
    source_commit=state['source_commit'], common_compile_threads=2, program_flags_count=61,
    subjects={v:dict(bytes=(out/v).stat().st_size,sha256=sha(out/v)) for v in ['control','candidate']},
    strategy='Standard compiler versus target-cpu=native plus instrumentation PGO, with the same current production source and two workers. No source transformation or independent/additive gain attribution.',
    primary_timing='All compiler tool builds and training have finished. Runs are serial, with no concurrent builds/tests/sampling/hashing/archival. Exact outputs, cached adapter and complete executable gates remain required.',
    scripts=json.loads((root/'qualification-scripts/derivation.json').read_text()),
)
(out / 'configuration.json').write_text(json.dumps(config, indent=2)+'\n')
env = {k:v for k,v in os.environ.items() if not k.startswith('MECH_')}
records = []
for stage, filename in [
    ('screens','mech-screen-pgo-current-20261115.py'),
    ('cached-executable-gates','mech-cached-native-link-pgo-current-20261115.py'),
    ('fixtures-and-object-cohort','mech-qualify-pgo-current-20261115.py'),
    ('heldout-cohorts','mech-heldout-pgo-current-20261115.py'),
    ('native-cohort','mech-native-cohort-pgo-current-20261115.py'),
]:
    script = root / 'qualification-scripts' / filename
    command = [sys.executable, str(script)]
    row = dict(stage=stage,command=command,state='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    records.append(row)
    (out/'pipeline.json').write_text(json.dumps(records,indent=2)+'\n')
    started = time.monotonic()
    with (out/(stage+'.stdout.log')).open('w') as stdout, (out/(stage+'.stderr.log')).open('w') as stderr:
        completed = subprocess.run(command,cwd=source,env=env,stdout=stdout,stderr=stderr)
    row.update(state='complete' if completed.returncode==0 else 'failed',exit_code=completed.returncode,seconds=time.monotonic()-started)
    (out/'pipeline.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    assert completed.returncode==0
