from pathlib import Path
import hashlib,json,shutil,subprocess

repo=Path.cwd();raw=Path('/private/tmp/mech-current-native-pgo-20261115');packet=Path('/private/tmp/mech-current-native-pgo-packet-20261115')
assert not packet.exists();packet.mkdir()
pin=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
excluded=[]
for p in sorted(raw.iterdir()):
    if p.name in ['source','target']:continue
    if p.name in ['control','native-control','generate','use']:
        excluded.append(dict(path=p.name,**pin(p)));continue
    for q in ([p] if p.is_file() else sorted(p.rglob('*'))):
        if not q.is_file():continue
        rel=q.relative_to(raw)
        if rel.as_posix() in ['qualification/control','qualification/candidate']:
            excluded.append(dict(path=rel.as_posix(),**pin(q)));continue
        dest=packet/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(q,dest)
state=json.loads((raw/'source-state.json').read_text());revision=state['source_commit']
paths=['.cargo/config.toml','Cargo.toml','Cargo.lock','benchmarks/mech-deflate/native-profile/Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.lock','benchmarks/mech-deflate/native-profile/compile_profile.rs','benchmarks/mech-deflate/native-profile/profile_compile.py']
source_pins=[]
for name in paths:
    data=subprocess.check_output(['git','show',revision+':'+name]);assert data==(raw/'source'/name).read_bytes()
    dest=packet/'source-config'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);source_pins.append(dict(path=name,**pin(dest)))
(packet/'source-config-pins.json').write_text(json.dumps(source_pins,indent=2)+'\n')
for row in json.loads((packet/'qualification/fixture-results.json').read_text()):
    name=row['fixture']
    if name.startswith('hosts/'):
        data=subprocess.check_output(['git','show',revision+':'+name]);assert data==(raw/'source'/name).read_bytes()
        (packet/'qualification/fixture-inputs'/Path(name).name).write_bytes(data)
prior=Path('/private/tmp/mech-round2-planning-packet-20261114')
for name in ['licenses','native-link-inputs']:shutil.copytree(prior/name,packet/name)
shutil.copy2(prior/'native-link-inputs.json',packet/'native-link-inputs.json')
validation=packet/'validation';validation.mkdir()
for suffix in ['.json','.archive.json']:
    name='parallel-phases-compile-apple-m3-20261114'+suffix
    shutil.copy2(repo/'benchmarks/mech-deflate/native-profile'/name,validation/('prior-qualified'+suffix))
originals=packet/'qualification-scripts/originals';originals.mkdir()
for row in json.loads((packet/'qualification-scripts/derivation.json').read_text()):
    p=Path(row['original']);assert pin(p)['sha256']==row['original_sha256'];shutil.copy2(p,originals/p.name)
for name in ['mech-setup-current-native-pgo-20261115.py','mech-current-native-pgo-pipeline-20261115.py','mech-prepare-current-native-pgo-qualification-20261115.py','mech-qualify-current-native-pgo-20261115.py','mech-prepare-current-native-pgo-evidence-20261115.py','mech-curate-current-native-pgo-20261115.py']:
    shutil.copy2(Path('/private/tmp')/name,packet/name)
shutil.copy2('/private/tmp/mech-replay-current-native-pgo-20261115.py',packet/'replay.py')
(packet/'excluded-compiler-products.json').write_text(json.dumps(excluded,indent=2)+'\n')
(packet/'README.txt').write_text('''Current-source native-CPU plus compiler PGO qualification, 2026-11-15.
Source aaef2a932bf81c7638c522dc777a2b78f0abcb5d includes retained frontend
changes and actual numeric phase workers. Both runtime subjects use the same61
program flags plus two workers. Standard compiler control is compared with
target-cpu=native plus instrumentation PGO. No separate or additive CPU/PGO
gain is claimed. No production source transformation is made by this trial.
Four compiler-tool builds, eight training programs,14fixture pairs,56balanced
held-out compiles,8primary Object runs and8separate complete executable builds
are retained. All primary runs are serial after all tool builds/training finish,
without concurrent heavy builds/tests/sampling/hashing/archival. All program
bytes and complete executables match. Fixed native runtime/entry adapter inputs
are pinned and cached; their first-use construction is excluded.
Frontend/memory and final-link adverse observations remain. Profile use emits
18607 missing-function warnings and no hash/CFG mismatch diagnostics; the full
Cargo JSON diagnostic log is retained. The initial denied hardware-metadata
read and resumed setup remain, with the immutable source snapshot reused.
Raw/merged profiles, source configuration, all scripts/logs, complete program
and fixture outputs, native inputs and pure replay are included. Compiler-tool
binaries/intermediates and unchanged compiler source are excluded and pinned;
the source commit and Rust/LLVM version/configuration are recorded.
Replay validates saved observations without rerunning measurements. No new
program-runtime campaign, scalar retirement, grammar/language change or weaker
proof check is claimed. Complete compilation below ten seconds remains open.
''')
print(packet)
