from pathlib import Path, PurePosixPath
import datetime, json, os, shutil, subprocess, tarfile, time

repo=Path.cwd()
root=Path('/private/tmp/mech-current-native-pgo-20261115')
assert not root.exists()
root.mkdir();source=root/'source';source.mkdir()
revision='aaef2a932bf81c7638c522dc777a2b78f0abcb5d'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==revision
assert subprocess.check_output(['git','diff','--name-only'],text=True)==''
started=time.monotonic()
process=subprocess.Popen(['git','archive','--format=tar',revision],stdout=subprocess.PIPE)
files=0;skipped=[]
with tarfile.open(fileobj=process.stdout,mode='r|') as archive:
    for entry in archive:
        path=PurePosixPath(entry.name)
        assert not path.is_absolute() and '..' not in path.parts
        if entry.name.startswith('benchmarks/mech-deflate/evidence/') and entry.name.endswith('.tar.gz'):
            skipped.append(entry.name);continue
        archive.extract(entry,source,filter='data')
        if entry.isfile():files+=1
assert process.wait()==0
state=dict(source_commit=revision,source_tree=subprocess.check_output(['git','rev-parse',revision+'^{tree}'],text=True).strip(),source_archive='Exact tracked Git archive; benchmark evidence archives excluded because Cargo does not compile them.',files_extracted=files,excluded_evidence_archives=skipped,seconds=time.monotonic()-started,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),experiment='Current production compiler: standard control, native-CPU control, native-CPU instrumentation/training/profile use. Same61programflags plus2workers. No production compiler source changes.')
(root/'source-state.json').write_text(json.dumps(state,indent=2)+'\n')
old=Path('/private/tmp/mech-parallel-phases-20261114')
shutil.copy2(old/'runtime-flags.json',root/'runtime-flags.json');shutil.copy2(old/'reference-pins.json',root/'reference-pins.json');shutil.copytree(old/'reference',root/'reference')
commands={
    'rustc-version':['rustc','+nightly-2026-03-03','-Vv'],
    'rustc-sysroot':['rustc','+nightly-2026-03-03','--print','sysroot'],
    'target-cpus':['rustc','+nightly-2026-03-03','--print','target-cpus','--target','aarch64-apple-darwin'],
    'generic-target-cfg':['rustc','+nightly-2026-03-03','--print','cfg','--target','aarch64-apple-darwin'],
    'native-target-cfg':['rustc','+nightly-2026-03-03','--print','cfg','--target','aarch64-apple-darwin','-C','target-cpu=native'],
    'cpu':['sysctl','-n','machdep.cpu.brand_string'],
    'cpu-count':['sysctl','-n','hw.ncpu'],
    'memory':['sysctl','-n','hw.memsize'],
    'os':['sw_vers','-productVersion'],
}
for name,command in commands.items():
    result=subprocess.run(command,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (root/(name+'.txt')).write_text(result.stdout)
    (root/(name+'.stderr')).write_text(result.stderr)
    assert result.returncode==0,(name,result.stderr)
sysroot=Path((root/'rustc-sysroot.txt').read_text().strip())
profdata=sysroot/'lib/rustlib/aarch64-apple-darwin/bin/llvm-profdata'
assert profdata.is_file()
(root/'llvm-profdata-path.txt').write_text(str(profdata)+'\n')
(root/'llvm-profdata-version.txt').write_text(subprocess.check_output([str(profdata),'--version'],text=True))
(root/'setup-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
print(json.dumps(state),flush=True)
