from pathlib import Path
import hashlib

old = Path('/private/tmp/mech-replay-round2-pgo-20261114.py').read_text()
text = old.replace('/private/tmp/mech-round2-pgo-20261114','/private/tmp/mech-current-native-pgo-20261115')
text = text.replace('fad53d24d9d2cad61262cb94932405fd9ee40341','aaef2a932bf81c7638c522dc777a2b78f0abcb5d')
def once(before, after):
    global text
    assert text.count(before)==1, (before[:100],text.count(before))
    text=text.replace(before,after)

once("curation_failure = read(packet / 'curation-first-attempt.json')\nassert curation_failure['exit_code'] == 1 and 'rust-toolchain.toml' in curation_failure['error']", "setup_failure = read(packet / 'setup-first-attempt/reason.json')\nassert 'sandbox denied sysctl' in setup_failure['error']\nassert 'Operation not permitted' in (packet/'setup-first-attempt/cpu.stderr').read_text()\nsetup_resume = read(packet/'setup-resume.json')\nassert setup_resume['exit_code']==0 and setup_resume['source_snapshot_reused']")
once("state = read(root / 'source-state.json')\nassert state['source_commit'] == revision and state['training_cases'] == 8 and state['held_out_fixture_cases'] == 7", "state = read(root / 'configuration.json')\nassert state['source_commit'] == revision and state['common_compile_threads']==2 and state['program_flags_count']==61")
once("for mode in ['control', 'generate', 'use']}", "for mode in ['control', 'native-control', 'generate', 'use']}")
once("    flags = ['-D', 'warnings']\n", "    flags = ['-D', 'warnings']\n    if mode != 'control': flags += ['-C','target-cpu=native']\n")
once("    assert diagnostics[mode] == (dict(total=18352,warnings=18352,missing_function=18352,hash_or_control_flow_mismatch=0) if mode=='use' else dict(total=0,warnings=0,missing_function=0,hash_or_control_flow_mismatch=0))", "    assert diagnostics[mode] == (dict(total=18607,warnings=18607,missing_function=18607,hash_or_control_flow_mismatch=0) if mode=='use' else dict(total=0,warnings=0,missing_function=0,hash_or_control_flow_mismatch=0))")
once("assert state['builds'] == {k: builds[k] for k in ['control', 'use']}\n", "")
once("assert [r['stage'] for r in pipeline] == ['generate', 'training', 'use']", "assert [r['stage'] for r in pipeline] == ['control','native-control','native-output-gates','generate','training','use']")
once("assert len(flags) == 61 and flags['MECH_COMPACT_REUSE_OVERWRITTEN_RESULT'] == '1'", "assert len(flags) == 61 and flags['MECH_COMPACT_REUSE_OVERWRITTEN_RESULT'] == '1'\nruntime_flags=dict(flags,MECH_COMPACT_COMPILE_THREADS='2')")
text=text.replace("command['flags'] == flags", "command['flags'] == runtime_flags")
text=text.replace("command['runtime_flags'] == flags", "command['runtime_flags'] == runtime_flags")
once('program_flags_count=61, curation_first_attempt=curation_failure,', 'program_flags_count=61, common_compile_threads=2, setup_first_attempt=setup_failure, setup_resume=setup_resume,')
extra = '''
qualification_pipeline=read(root/'pipeline.json')
assert [r['stage'] for r in qualification_pipeline]==['screens','cached-executable-gates','fixtures-and-object-cohort','heldout-cohorts','native-cohort']
assert all(r['state']=='complete' and r['exit_code']==0 for r in qualification_pipeline)
initial_screens=read(packet/'native-screen-results.json')
assert [r['mode'] for r in initial_screens]==['control','native-control']
for row in initial_screens:
    assert row['exit_code']==0 and row['matches_complete_baseline_executable'] and row['executable']==executable_pin
    directory=packet/('native-screen-'+row['mode'])
    for filename,item in expected.items():
        assert pin(directory/filename)==item and row['files'][filename]==dict(item,matches_frozen_reference=True)
    assert pin(directory/'worker')==executable_pin
for item in read(packet/'qualification-scripts/derivation.json'):
    assert pin(packet/'qualification-scripts/originals'/Path(item['original']).name)['sha256']==item['original_sha256']
    assert pin(packet/'qualification-scripts'/Path(item['derived']).name)['sha256']==item['derived_sha256']
assert state['subjects']=={v:{k:excluded['qualification/'+v][k] for k in ['bytes','sha256']} for v in ['control','candidate']}
summary.update(
    qualification_pipeline=qualification_pipeline, initial_native_cpu_output_gates=initial_screens,
    strategy='Combined target-cpu=native plus instrumentation PGO on current aaef production source; standard control and candidate both use two workers. No separate CPU-only/PGO-only or additive gain is claimed.',
    decision='Qualify the combined compiler build strategy: complete source-to-executable improves 8.22% in both blocks with every program/executable byte identical. Frontend and memory regressions remain. No compiler source transformation or sub-ten-second result is claimed.',
    scope=[
        'Frozen aaef source includes the retained frontend changes and real worker scheduler. Four compiler-tool builds use nightly2026-03-03, explicit aarch64-apple-darwin, compiler profile ThinLTO/CGU1, four Cargo jobs, incremental0 and warnings-as-errors. Standard control has no target-cpu override; other modes add target-cpu=native. Generate/use have absolute profile paths. Build and training time are excluded from program timings.',
        'Eight training programs reproduce unprofiled outputs;14 paired fixtures and56 balanced held-out compiles preserve all source/bytecode/Object/complete metadata. Every complete Deflate executable remains identical. No scalar retirement, grammar/language change, weaker proof or new program-runtime campaign is claimed.',
        'Eight serial ABBA/BAAB source-to-Object runs and eight separate complete executable builds use the same61programflags plus2workers in both subjects. No concurrent heavy build/test/sample/hash/archive work runs during primary cohorts. Fixed runtime/entry adapter objects are pinned and cached; source compilation is fresh.',
        'Both complete-build blocks improve about8.2%. Object process time/instructions also improve. Frontend time and memory are adverse, and native-link time rises observationally. Every observation, screen and per-case/block result remains; no tiny-program pooled percentage or unrelated-phase causal attribution is claimed.',
        'Profile use reports18607 functions without training data and no hash/control-flow mismatch diagnostics. All warnings remain in the build JSON log. Both standard/native-CPU initial output and executable gates pass; those screens establish no independent CPU-only speedup.',
        'The initial read-only hardware metadata query is denied by the default sandbox after source/Rust configuration capture. No build or test runs in that failed setup. Its script/logs/source-state remain; remaining metadata is resumed with scoped command approval, reusing the immutable snapshot.',
        'Raw/merged profiles, exact scripts and their derivation, every build/training/timing log, source configuration/harness, fixture/program/executable bytes and native linker inputs are included. Compiler binaries and intermediates are excluded/SHA-pinned; unchanged compiler source is pinned by Git revision. Pure replay validates saved evidence without rerunning compilation or timing. Complete compilation below ten seconds remains open.',
    ],
)
'''
once('encoded = json.dumps(summary, indent=2, sort_keys=True)', extra+'\nencoded = json.dumps(summary, indent=2, sort_keys=True)')
out=Path('/private/tmp/mech-replay-current-native-pgo-20261115.py')
compile(text,str(out),'exec');out.write_text(text)
print('prepared current-source replay',hashlib.sha256(text.encode()).hexdigest())
