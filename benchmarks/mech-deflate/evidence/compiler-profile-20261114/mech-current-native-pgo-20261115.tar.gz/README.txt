Current-source native-CPU plus compiler PGO qualification, 2026-11-15.
Source aaef2a932bf81c7638c522dc777a2b78f0abcb5d includes retained frontend
changes and actual numeric phase workers. Both runtime subjects use the same61
program flags plus two workers. Standard compiler control is compared with
target-cpu=native plus instrumentation PGO. No separate or additive CPU/PGO
gain is claimed. No production source transformation is made by this trial.
Four compiler-tool builds, eight training programs,14fixture pairs,56balanced
held-out compiles,8primary Object runs and8separate complete executable builds
are retained. All primary runs are serial after all tool builds/training finish,
without concurrent heavy builds/tests/sampling/hashing/archival. All program
bytes and complete executables match. Fixed native runtime/entry adapter inputs
are pinned and cached; their first-use construction is excluded.
Frontend/memory and final-link adverse observations remain. Profile use emits
18607 missing-function warnings and no hash/CFG mismatch diagnostics; the full
Cargo JSON diagnostic log is retained. The initial denied hardware-metadata
read and resumed setup remain, with the immutable source snapshot reused.
Raw/merged profiles, source configuration, all scripts/logs, complete program
and fixture outputs, native inputs and pure replay are included. Compiler-tool
binaries/intermediates and unchanged compiler source are excluded and pinned;
the source commit and Rust/LLVM version/configuration are recorded.
Replay validates saved observations without rerunning measurements. No new
program-runtime campaign, scalar retirement, grammar/language change or weaker
proof check is claimed. Complete compilation below ten seconds remains open.
