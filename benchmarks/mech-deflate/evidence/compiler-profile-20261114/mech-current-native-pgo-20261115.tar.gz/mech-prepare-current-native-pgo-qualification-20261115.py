from pathlib import Path
import hashlib, json

root = Path('/private/tmp/mech-current-native-pgo-20261115')
scripts = root / 'qualification-scripts'
assert not scripts.exists()
scripts.mkdir()
old_root = '/private/tmp/mech-round2-pgo-20261114/qualification'
new_root = str(root / 'qualification')
names = [
    'mech-run-pgo', 'mech-screen-pgo', 'mech-cached-native-link-pgo',
    'mech-pgo-fixtures', 'mech-run-pgo-cohort', 'mech-analyze-pgo',
    'mech-qualify-pgo', 'mech-run-native-pgo', 'mech-native-cohort-pgo',
    'mech-heldout-pgo',
]
mapping = {
    name + '-20261114.py': name + '-current-20261115.py'
    for name in names
}
records = []
for old_name, new_name in mapping.items():
    old = Path('/private/tmp') / old_name
    original = old.read_text()
    assert old_root in original
    text = original.replace(old_root, new_root)
    for a, b in mapping.items():
        text = text.replace('/private/tmp/' + a, str(scripts / b))
        text = text.replace("'" + a + "'", "'" + b + "'")
    # The qualification driver resolves its child names through /private/tmp.
    if old_name == 'mech-qualify-pgo-20261114.py':
        text = text.replace("Path('/private/tmp')/name", "Path(" + repr(str(scripts)) + ")/name")
    if 'env.update(flags)' in text:
        text = text.replace('env.update(flags)', "env.update(flags);env['MECH_COMPACT_COMPILE_THREADS']='2'")
    if old_name == 'mech-pgo-fixtures-20261114.py':
        text = text.replace("repo=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech')", "repo=Path(" + repr(str(root / 'source')) + ")")
        text = text.replace("'flags':flags,", "'flags':dict(flags,MECH_COMPACT_COMPILE_THREADS='2'),")
    if old_name == 'mech-heldout-pgo-20261114.py':
        text = text.replace('dict(command=command,flags=flags,', "dict(command=command,flags=dict(flags,MECH_COMPACT_COMPILE_THREADS='2'),")
    if old_name == 'mech-native-cohort-pgo-20261114.py':
        text = text.replace(
            'program flags61, frozen fad53 source, serial unprofiled control versus serial PGO compiler. No phase-worker scheduling enabled.',
            'same61programflags plus two workers in both subjects, frozen aaef source; standard unprofiled compiler versus native-CPU plus PGO compiler. Measures the combined strategy; no independent additive CPU/PGO gain is claimed.',
        )
    assert old_root not in text
    compile(text, str(scripts / new_name), 'exec')
    (scripts / new_name).write_text(text)
    records.append(dict(
        original=str(old), original_sha256=hashlib.sha256(original.encode()).hexdigest(),
        derived=str(scripts / new_name), derived_sha256=hashlib.sha256(text.encode()).hexdigest(),
    ))
(scripts / 'derivation.json').write_text(json.dumps(records, indent=2) + '\n')
print('prepared', len(records), 'qualification scripts; none executed')
