from pathlib import Path
packet=Path('/private/tmp/mech-visit-predecessors-packet-20261114')
old=Path('/private/tmp/mech-constant-bounds-packet-20261114/replay.py').read_text()
prefix=old[:old.index('test_counts={} ')] if 'test_counts={} ' in old else old[:old.index('test_counts={}\n')]
prefix=prefix.replace('qualified-indexed','qualified-constant-bounds').replace('d9b59276ca61471edaf63dea6b2ac4dc96f35bb4562a733dd27288f18c6162d9','CONTROL_BINARY').replace('e359f3ae5c65e7841ccc29531912be2cf54da90ccde601d12e1cfa977732f99f','7e6464ea83e3479fbc69386375560d011a38bd67a5d6c8911e19fce5e7d9af4c').replace('CONTROL_BINARY','e359f3ae5c65e7841ccc29531912be2cf54da90ccde601d12e1cfa977732f99f')
fixtures=old[old.index("fixtures=read(raw/'fixture-results.json')"):old.index("profile=root/'profile'")]
tests='''
test=read(raw/'index-tests-command.json');assert test['exit_code']==0 and test['source_patch_sha256']==state['patch_sha256']
assert pin(raw/'test-source.patch')==pin(raw/'candidate.patch')
assert re.findall(r'test result: ok\\. (\\d+) passed',(raw/'index-tests.log').read_text())==['4']
test_source=(root/'source/hosts/gpu/src/native_artifact/program/prepare/visit_predecessors_tests.rs').read_text()
assert 'choices.len().pow(6)' in test_source and 'let labels = [0, 1, 2, 9, u32::MAX as usize]' in test_source and 'let last = 65_535' in test_source
for filename,pinned in expected.items():assert pin(raw/'reference'/filename)==pinned
'''
summary='''
summary={'source_commit':state['source_commit'],'base_commit':state['base_commit'],'hardware':state['hardware'],'decision':'Retain prepared-owner reverse control edges for fresh scope entry checks; original first refusal and generated program bytes unchanged','flags_count':55,'qualified':qualified,'output_hashes':expected,'compiler_binary_sha256':{'control':control['sha256'],'candidate':build['binary_sha256']},'candidate_patch_sha256':state['patch_sha256'],'build_observations':{'test_and_compiler_build_seconds':test['seconds'],'subsequent_cached_binary_lookup_seconds':build['seconds'],'cold_bootstrap_claimed':False},'tests':{'production_module_tests':4,'exhaustive_reference_comparisons':6**6*2**5*5,'sparse_graph_nodes':65536,'complete_array_enum_fixtures':6,'scalar_fixtures':8},'fixture_output_comparisons':fixtures,'scope':[
 'Four serial ABBA fresh full source-to-Object observations use identical 55 flags and host statistics. Compiler builds, tests, both screens, fixtures, hashing, copying and archiving do not overlap primary timing. No cached Object or decoded-only substitute is used.',
 'The index stores only reverse control edges for one immutable prepared owner. Every scope query checks its current membership and header and returns the same first offending source as the old whole-program scan. Captured windows retain their original separate entry/fact contract. No current validity, ownership or proof answer is cached.',
 'All source, MBC, Object and complete metadata bytes match the previously qualified terminal-append program in both screens and every primary observation. All four outputs also match between subjects in six complete array/enum and eight checked scalar fixture pairs.',
 'Four production-module tests pass, including 7464960 exhaustive graph/scope/header comparisons with the original ordered scan, a 65536-node sparse graph, changed scopes and headers, separate owner topology, duplicates and out-of-range targets.',
 'The test command rebuilt compiler and tests. The later compiler build was already cached and is recorded separately, not claimed as a cold bootstrap.',
 'Compiler time, whole-process time, native generation and retired instructions improve with nonoverlapping matched ranges. Small memory differences and all adverse parse, frontend, canonical-lowering and preparation observations remain. Four runs are descriptive, not a population estimate; unchanged-stage differences have no causal attribution to this change.',
 'No new program-runtime latency campaign is claimed: machine code and complete metadata remain byte-identical. Direct scalar emission, checked errors, finite admission, current-visit ownership checks, grammar, language and backend optimization level are unchanged. Full fresh compilation remains above ten seconds.'
]}
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
'''
(packet/'replay.py').write_text(prefix+tests+fixtures+summary)
