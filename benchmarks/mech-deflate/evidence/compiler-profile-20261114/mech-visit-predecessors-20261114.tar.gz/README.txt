Prepared-owner visit predecessor index, Apple M3, 2026-11-14.
The prior published control CPU profile identifies numeric traversal analysis as
an outstanding cost. This change replaces repeated whole-program outside-entry
scans with reverse-edge lookups bound to the exact immutable prepared owner.
The index stores topology only. Every query checks its current scope and header,
keeps the original first offending source/diagnostic, and retains captured
windows' existing separate entry contract. No validity/proof result is cached.
Four production-module tests pass, including 7,464,960 exhaustive comparisons
against the original ordered scan, 65,536-node sparse graphs, mutated scopes and
headers, separate owner topology, duplicates and out-of-range targets.
Both screens, fourteen fixture pairs and all four serial ABBA fresh complete
source-to-Object observations retain all source, MBC, Object and metadata bytes.
Both subjects use the same 55 flags and host statistics. Tests/builds, screens,
fixtures, hashing, copying and archiving do not overlap primary timing.
The test driver rebuilt the compiler and tests in 86.91 seconds. The subsequent
0.114-second build merely located that existing compiler; it is not a cold
bootstrap measurement. All original commands/logs and binary pins remain.
All adverse phase observations and resource counters are retained. Four runs
are descriptive, not a population estimate. No new runtime latency campaign is
claimed: the complete generated program and metadata remain byte-identical.
Grammar, language, direct scalar emission, checked errors, finite admission,
current-visit ownership checks and backend optimization levels are unchanged.
The ten-second goal remains open. Compiler executables are excluded and pinned.
This complete packet is published in benchmarks at the user's request.
Run python3 replay.py for pure offline checks and numerical reconstruction;
it does not rerun timing, compile a program, or contact any external service.
