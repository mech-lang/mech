from pathlib import Path
import subprocess,json,hashlib,shutil
repo=Path.cwd();raw=Path('/private/tmp/mech-visit-predecessors-20261114');packet=Path('/private/tmp/mech-visit-predecessors-packet-20261114');assert not packet.exists()
source='40c33f0c75865483fa6bc140fb9b4413d23d7cd0';base='d36a53e9e2c51e197eafd2d9c7c44cf6ee5a8f0e';control_source='7d0c06d002758d029839c81a774d5e704e56d440'
patch=subprocess.check_output(['git','diff','--binary',base,source]);assert patch==(raw/'candidate.patch').read_bytes();assert subprocess.check_output(['git','diff',control_source,base,'--','src','hosts','vendor','machines'])==b''
excluded=[]
for p in sorted(raw.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(raw)
 if str(rel) in ['control','candidate']:
  excluded.append(dict(path=str(rel),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()));continue
 d=packet/'compiler'/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
(packet/'excluded-executables.json').write_text(json.dumps(excluded,indent=2)+'\n');(packet/'source-change.patch').write_bytes(patch)
(packet/'source-state.json').write_text(json.dumps(dict(source_commit=source,base_commit=base,control_source_commit=control_source,control_production_source_identical_to_base=True,patch_sha256=hashlib.sha256(patch).hexdigest(),hardware='Apple M3 Air, 8 cores (4P+4E), 16 GB, macOS 26.2',rustc=subprocess.check_output(['rustc','-Vv'],text=True),cargo=subprocess.check_output(['cargo','-V'],text=True)),indent=2,sort_keys=True)+'\n')
paths=subprocess.check_output(['git','diff','--name-only',base,source],text=True).splitlines()
paths+=['Cargo.lock','.cargo/config.toml','LICENSE','hosts/gpu/src/native_artifact/AGENTS.md','hosts/gpu/tests/fixtures/native/deflate-huffman-LICENSES.md','hosts/gpu/src/native_artifact/program/runtime/composition_tests/nested_phase.rs']
paths+=['benchmarks/mech-deflate/native-profile/'+n for n in ['Cargo.lock','compile_profile.rs','profile_compile.py']]
paths+=['hosts/gpu/tests/fixtures/native/'+n+'.mec' for n in ['numeric-nested-phase','numeric-nested-phase-states','numeric-private-fixed-nested','numeric-changing-capture-tree','numeric-array-windows','numeric-multiple-children']]
for name in paths:
 d=packet/'source'/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(subprocess.check_output(['git','show',source+':'+name]))
validation=packet/'validation';validation.mkdir()
for suffix in ['.json','.archive.json']:shutil.copy2(repo/('benchmarks/mech-deflate/native-profile/constant-bounds-compile-apple-m3-20261114'+suffix),validation/('qualified-constant-bounds'+suffix))
shutil.copytree(Path('/private/tmp/mech-borrowed-schema-packet-20261114/licenses'),packet/'licenses')
names=[f'mech-{op}-visit-predecessors-20261114.py' for op in ['build','test','run']]+['mech-run-visit-predecessors-cohort-20261114.py','mech-visit-predecessors-fixtures-20261114.py','mech-curate-visit-predecessors-20261114.py']
names += [f'mech-visit-predecessors-{op}-driver-20261114.log' for op in ['build','test','screen','control-screen','fixtures','cohort']]
for name in names:shutil.copy2(Path('/private/tmp')/name,packet/name)
(packet/'README.txt').write_text('''Prepared-owner visit predecessor index, Apple M3, 2026-11-14.
The prior published control CPU profile identifies numeric traversal analysis as
an outstanding cost. This change replaces repeated whole-program outside-entry
scans with reverse-edge lookups bound to the exact immutable prepared owner.
The index stores topology only. Every query checks its current scope and header,
keeps the original first offending source/diagnostic, and retains captured
windows' existing separate entry contract. No validity/proof result is cached.
Four production-module tests pass, including 7,464,960 exhaustive comparisons
against the original ordered scan, 65,536-node sparse graphs, mutated scopes and
headers, separate owner topology, duplicates and out-of-range targets.
Both screens, fourteen fixture pairs and all four serial ABBA fresh complete
source-to-Object observations retain all source, MBC, Object and metadata bytes.
Both subjects use the same 55 flags and host statistics. Tests/builds, screens,
fixtures, hashing, copying and archiving do not overlap primary timing.
The test driver rebuilt the compiler and tests in 86.91 seconds. The subsequent
0.114-second build merely located that existing compiler; it is not a cold
bootstrap measurement. All original commands/logs and binary pins remain.
All adverse phase observations and resource counters are retained. Four runs
are descriptive, not a population estimate. No new runtime latency campaign is
claimed: the complete generated program and metadata remain byte-identical.
Grammar, language, direct scalar emission, checked errors, finite admission,
current-visit ownership checks and backend optimization levels are unchanged.
The ten-second goal remains open. Compiler executables are excluded and pinned.
This complete packet is published in benchmarks at the user's request.
Run python3 replay.py for pure offline checks and numerical reconstruction;
it does not rerun timing, compile a program, or contact any external service.
''')
print(packet,flush=True)
