from pathlib import Path
import json,hashlib,re,statistics,subprocess,sys
root=Path(__file__).resolve().parent;raw=root/'compiler';read=lambda p:json.loads(p.read_text())
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
state=read(root/'source-state.json');build=read(raw/'candidate-build.json');control=read(raw/'control-origin.json');prior=read(root/'validation/qualified-constant-bounds.json');prior_receipt=read(root/'validation/qualified-constant-bounds.archive.json')
assert pin(root/'validation/qualified-constant-bounds.json')['sha256']==prior_receipt['replay_sha256']
assert state['control_production_source_identical_to_base'] and build['exit_code']==0 and build['head']==state['base_commit']
assert pin(raw/'candidate.patch')==pin(root/'source-change.patch') and pin(raw/'candidate.patch')['sha256']==build['patch_sha256']==state['patch_sha256']
assert control['sha256']==prior['compiler_binary_sha256']['candidate']=='e359f3ae5c65e7841ccc29531912be2cf54da90ccde601d12e1cfa977732f99f'
assert build['binary_sha256']=='7e6464ea83e3479fbc69386375560d011a38bd67a5d6c8911e19fce5e7d9af4c'
for r in read(root/'excluded-executables.json'):assert r['sha256']==(control['sha256'] if r['path']=='control' else build['binary_sha256'])
flags=read(raw/'runtime-flags.json');assert len(flags)==55 and flags['MECH_TERMINAL_BYTE_APPENDS']=='1' and flags['MECH_NORMALIZE_DEFAULTED_READ_SETUP']=='1'
expected=prior['output_hashes'];rows=read(raw/'cohort.json');assert [r['variant'] for r in rows]==['control','candidate','candidate','control']
for name in ['control-screen','candidate-screen',*[r['name'] for r in rows]]:
 d=raw/name;assert read(d/'process.json')['exit_code']==0 and read(d/'process.json')['samples']==0
 command=read(raw/(name+'-command.json'));assert command['flags']==flags
 assert command['binary_sha256']==(control['sha256'] if name.startswith('control-') else build['binary_sha256'])
 for filename,pinned in expected.items():assert pin(d/filename)==pinned and read(d/'output-check.json')[filename]==dict(pinned,matches_previous_qualified_output=True)
for row in rows:
 d=raw/row['name'];assert row['compile']==read(d/'compile.json') and row['process']==read(d/'process.json') and row['files']==read(d/'output-check.json')
 stamps=[json.loads(line) for line in (d/'stages.jsonl').read_text().splitlines()]
 for key,begin,end in [('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]:assert row[key]==next(s['elapsed'] for s in stamps if s['line'].startswith(end))-next(s['elapsed'] for s in stamps if s['line'].startswith(begin))
 for key,pattern in [('max_rss_bytes',r'(\d+)  maximum resident set size'),('instructions',r'(\d+)  instructions retired'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]:assert row[key]==int(re.search(pattern,(d/'stderr.log').read_text()).group(1))


test=read(raw/'index-tests-command.json');assert test['exit_code']==0 and test['source_patch_sha256']==state['patch_sha256']
assert pin(raw/'test-source.patch')==pin(raw/'candidate.patch')
assert re.findall(r'test result: ok\. (\d+) passed',(raw/'index-tests.log').read_text())==['4']
test_source=(root/'source/hosts/gpu/src/native_artifact/program/prepare/visit_predecessors_tests.rs').read_text()
assert 'choices.len().pow(6)' in test_source and 'let labels = [0, 1, 2, 9, u32::MAX as usize]' in test_source and 'let last = 65_535' in test_source
for filename,pinned in expected.items():assert pin(raw/'reference'/filename)==pinned
fixtures=read(raw/'fixture-results.json');assert len(fixtures)==14
for row in fixtures:
 assert row['all_outputs_match'] and row['variants']['control']==row['variants']['candidate'] and row['variants']['control']['exit_code']==0 and len(row['variants']['control']['files'])==4
 name=Path(row['fixture']).stem if ':' not in row['fixture'] else row['fixture'].split(':')[-1]
 for variant,record in row['variants'].items():
  d=raw/'fixtures'/name/variant;assert read(d/'command.json')['flags']==flags
  assert read(d/'command.json')['binary_sha256']==(control['sha256'] if variant=='control' else build['binary_sha256'])
  for filename,pinned in record['files'].items():assert pin(d/filename)==pinned
  assert record['files']['source.mec']['sha256']==row['source_sha256']
base=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase.mec').read_text();fragment=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase-states.mec').read_text();assembled=base.replace('+> sequence\n','+> sequence\n'+fragment+'\n',1).replace('phase-candidates(values, 1u64, 0u64, permitted, divisor)','#PhaseCandidates(values, permitted, divisor, 1u64, 0u64)',1);assert assembled==(raw/'fixture-inputs/numeric-nested-phase-states.mec').read_text()
fields={'compiler_seconds':lambda r:r['compile']['total_seconds'],'whole_process_seconds':lambda r:r['process']['elapsed_seconds'],'parse_seconds':lambda r:next(p['seconds'] for p in r['compile']['phases'] if p['phase']=='parse'),'frontend_seconds':lambda r:next(p['seconds'] for p in r['compile']['phases'] if p['phase']=='frontend'),'native_seconds':lambda r:next(p['seconds'] for p in r['compile']['phases'] if p['phase']=='native')}
for key in ['canonical_lowering_seconds','preparation_seconds','numeric_generation_seconds','source_cfg_seconds','cleanup_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:fields[key]=lambda r,key=key:r[key]
qualified={key:{v:[f(r) for r in rows if r['variant']==v] for v in ['control','candidate']} for key,f in fields.items()}
for record in qualified.values():record['mean_reduction_fraction']=1-statistics.mean(record['candidate'])/statistics.mean(record['control'])




summary={'source_commit':state['source_commit'],'base_commit':state['base_commit'],'hardware':state['hardware'],'decision':'Retain prepared-owner reverse control edges for fresh scope entry checks; original first refusal and generated program bytes unchanged','flags_count':55,'qualified':qualified,'output_hashes':expected,'compiler_binary_sha256':{'control':control['sha256'],'candidate':build['binary_sha256']},'candidate_patch_sha256':state['patch_sha256'],'build_observations':{'test_and_compiler_build_seconds':test['seconds'],'subsequent_cached_binary_lookup_seconds':build['seconds'],'cold_bootstrap_claimed':False},'tests':{'production_module_tests':4,'exhaustive_reference_comparisons':6**6*2**5*5,'sparse_graph_nodes':65536,'complete_array_enum_fixtures':6,'scalar_fixtures':8},'fixture_output_comparisons':fixtures,'scope':[
 'Four serial ABBA fresh full source-to-Object observations use identical 55 flags and host statistics. Compiler builds, tests, both screens, fixtures, hashing, copying and archiving do not overlap primary timing. No cached Object or decoded-only substitute is used.',
 'The index stores only reverse control edges for one immutable prepared owner. Every scope query checks its current membership and header and returns the same first offending source as the old whole-program scan. Captured windows retain their original separate entry/fact contract. No current validity, ownership or proof answer is cached.',
 'All source, MBC, Object and complete metadata bytes match the previously qualified terminal-append program in both screens and every primary observation. All four outputs also match between subjects in six complete array/enum and eight checked scalar fixture pairs.',
 'Four production-module tests pass, including 7464960 exhaustive graph/scope/header comparisons with the original ordered scan, a 65536-node sparse graph, changed scopes and headers, separate owner topology, duplicates and out-of-range targets.',
 'The test command rebuilt compiler and tests. The later compiler build was already cached and is recorded separately, not claimed as a cold bootstrap.',
 'Compiler time, whole-process time, native generation and retired instructions improve with nonoverlapping matched ranges. Small memory differences and all adverse parse, frontend, canonical-lowering and preparation observations remain. Four runs are descriptive, not a population estimate; unchanged-stage differences have no causal attribution to this change.',
 'No new program-runtime latency campaign is claimed: machine code and complete metadata remain byte-identical. Direct scalar emission, checked errors, finite admission, current-visit ownership checks, grammar, language and backend optimization level are unchanged. Full fresh compilation remains above ten seconds.'
]}
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
