from pathlib import Path
import json, subprocess, sys

root=Path('/private/tmp/mech-empty-repair-walk-20261114')
results=[]
for args in [['control','control-screen'],['candidate','candidate-screen']]:
    command=[sys.executable,'/private/tmp/mech-run-empty-repair-walk-20261114.py']+args
    completed=subprocess.run(command)
    results.append(dict(args=args,command=command,exit_code=completed.returncode))
    (root/'screen-status.json').write_text(json.dumps(results,indent=2)+'\n')
    if completed.returncode:raise SystemExit(completed.returncode)
