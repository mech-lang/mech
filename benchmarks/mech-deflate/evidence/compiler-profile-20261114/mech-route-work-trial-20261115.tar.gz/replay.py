from pathlib import Path
import hashlib,json,re,statistics

packet=Path(__file__).resolve().parent;root=packet/'trial'
read=lambda p:json.loads(p.read_text());pins={}
def pin(p):
 if p not in pins:pins[p]=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 return pins[p]
state=read(packet/'source-state.json');raw=read(root/'source-state.json')
assert state['source_revision']==state['base_commit']==raw['base_commit']=='aaef2a932bf81c7638c522dc777a2b78f0abcb5d'
assert state['decision']=='rejected' and state['production_source_restored']
assert pin(root/'candidate.patch')['sha256']==raw['patch_sha256']
assert pin(root/'candidate.rs')['sha256']==raw['production_module_sha256']
old=(root/'reference.rs').read_text();new=(root/'candidate.rs').read_text()
addition='''    // Without transport replacements every operand already names its current
    // value. The caller has checked ordinary edges before route discovery.
    if repairs.values().all(|map| map.is_empty()) {
        return;
    }
'''
assert new.count(addition)==1 and new.replace(addition,'',1)==old
products={r['path']:r for r in read(packet/'excluded-compiler-products.json')}
binaries={v:products['trial/'+v]['sha256'] for v in ['control','candidate']}
prior=read(packet/'validation/prior-qualified.json')
assert pin(packet/'validation/prior-qualified.json')['sha256']==read(packet/'validation/prior-qualified.archive.json')['replay_sha256']
assert binaries['control']==prior['compiler_binary_sha256']['candidate']==raw['control_binary_sha256']
expected=prior['output_hashes'];flags=read(root/'runtime-flags.json');assert len(flags)==61
wanted=dict(flags,MECH_COMPACT_COMPILE_THREADS='2')
config=read(packet/'source-config-pins.json')
for row in config:assert pin(packet/'source-config'/row['path'])=={k:row[k] for k in ['bytes','sha256']}
build=read(root/'candidate-build.json');check=read(root/'candidate-check.json')
for r in [check,build]:
 assert r['exit_code']==0 and r['head']==state['base_commit'] and r['patch_sha256']==raw['patch_sha256'] and r['CARGO_INCREMENTAL']=='0'
 assert r['original_constant_phi_source_sha256']==pin(packet/'source-config/vendor/cranelift-codegen/src/remove_constant_phis.rs')['sha256']
assert build['binary_sha256']==binaries['candidate']
tests=read(root/'rewrite-tests.json');test_build=read(root/'rewrite-tests-build.json');test_command=read(root/'rewrite-tests-command.json')
assert tests['exit_code']==test_build['exit_code']==0
assert test_build['binary_sha256']==products['trial/rewrite-tests']['sha256']
harness=(root/'rewrite_tests.rs').read_text()
for label,source in [('reference',old),('candidate',new)]:
 begin=source.index('fn rewrite(');end=source.index('\npub(super) fn optimize(',begin);body=source[begin:end]
 assert hashlib.sha256(body.encode()).hexdigest()==test_command['source_function_sha256'][label]
 assert body.replace('fn rewrite(','fn rewrite_'+label+'(',1) in harness
assert 'paired complete IR/alias/machine comparisons: 128' in (root/'rewrite-tests.stdout.log').read_text()
assert 'test result: ok. 1 passed; 0 failed' in (root/'rewrite-tests.stdout.log').read_text()
failure=root/'focused-first-attempt';assert read(failure/'rewrite-tests-build.json')['exit_code']==1
assert 'unused import' in (failure/'rewrite-tests-build.stderr.log').read_text()
assert read(root/'restored-production-tool.json')['sha256']==binaries['control']
order=[('control','control-1'),('candidate','candidate-1'),('candidate','candidate-2'),('control','control-2'),('candidate','candidate-3'),('control','control-3'),('control','control-4'),('candidate','candidate-4')]
rows=[];screens=[]
for variant,name in [('control','control-screen'),('candidate','candidate-screen')]+order:
 d=root/name;command=read(root/(name+'-command.json'));process=read(d/'process.json');compile=read(d/'compile.json');checks=read(d/'output-check.json')
 assert command['flags']==wanted and command['compile_threads']==2 and command['program_flags_count']==61 and not command['profiling_excluded_from_primary']
 assert command['binary_sha256']==binaries[variant]
 assert process['exit_code']==0 and process['samples']==0 and process['sampling_error'] is None
 assert process['elapsed_boundary']=='driver_start_to_process_wait_completion' and process['elapsed_seconds']>compile['total_seconds']
 for n,item in expected.items():assert pin(d/n)==item and checks[n]==dict(item,matches_current_control_output=True)
 row=dict(name=name,variant=variant,compile=compile,process=process,files=checks)
 if name.endswith('-screen'):screens.append(row);continue
 stamps=[json.loads(line) for line in (d/'stages.jsonl').read_text().splitlines()];elapsed=lambda prefix:next(s['elapsed'] for s in stamps if s['line'].startswith(prefix))
 for key,begin,end in [('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]:row[key]=elapsed(end)-elapsed(begin)
 log=(d/'stderr.log').read_text()
 for key,pattern in [('instructions',r'(\d+)  instructions retired'),('max_rss_bytes',r'(\d+)  maximum resident set size'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]:row[key]=int(re.search(pattern,log).group(1))
 row['compaction_seconds']=elapsed('compact-stage: CFG cleanup')-elapsed('compact-stage: compact values before=');row['cleanup_including_compaction_seconds']=row['cleanup_seconds']+row['compaction_seconds']
 for key,prefix in [('value_ids_before','compact-stage: compact values before='),('value_ids_after','compact-values: retained=')]:row[key]=int(next(s['line'] for s in stamps if s['line'].startswith(prefix)).split('=')[-1])
 assert (row['value_ids_before'],row['value_ids_after'])==(20798230,1242559)
 rows.append(row)
assert rows==read(root/'cohort.json')
fields={'compiler_seconds':lambda r:r['compile']['total_seconds'],'whole_process_seconds':lambda r:r['process']['elapsed_seconds']}
for phase in ['parse','catalog','frontend','artifact','encode','native']:fields[phase+'_seconds']=lambda r,p=phase:next(x['seconds'] for x in r['compile']['phases'] if x['phase']==p)
for key in ['canonical_lowering_seconds','preparation_seconds','numeric_generation_seconds','source_cfg_seconds','cleanup_including_compaction_seconds','cleanup_seconds','compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:fields[key]=lambda r,k=key:r[k]
numerical={}
for key,fn in fields.items():
 x={v:[fn(r) for r in rows if r['variant']==v] for v in ['control','candidate']};x['mean_reduction_fraction']=1-statistics.mean(x['candidate'])/statistics.mean(x['control']);numerical[key]=x
assert numerical==read(root/'numerical-summary.json')
blocks=[]
for subset in [rows[:4],rows[4:]]:
 block={}
 for key in ['compiler_seconds','whole_process_seconds','cleanup_including_compaction_seconds','instructions']:
  x={v:statistics.mean(fields[key](r) for r in subset if r['variant']==v) for v in ['control','candidate']};x['mean_reduction_fraction']=1-x['candidate']/x['control'];block[key]=x
 assert block['compiler_seconds']['mean_reduction_fraction']<0 and block['cleanup_including_compaction_seconds']['mean_reduction_fraction']<0
 blocks.append(block)
fixtures=read(root/'fixture-results.json');assert len(fixtures)==14
for row in fixtures:
 name=row['fixture'].split(':')[-1] if ':' in row['fixture'] else Path(row['fixture']).stem
 assert pin(root/'fixture-inputs'/(name+'.mec'))['sha256']==row['source_sha256'] and row['all_outputs_match'] and row['variants']['control']==row['variants']['candidate']
 for variant in ['control','candidate']:
  d=root/'fixtures'/name/variant;command=read(d/'command.json');assert command['flags']==wanted and command['binary_sha256']==binaries[variant]
  assert row['variants'][variant]['exit_code']==0 and len(row['variants'][variant]['files'])==4
  for n,item in row['variants'][variant]['files'].items():assert pin(d/n)==item
inputs=read(packet/'native-link-inputs.json')
for row in inputs:assert pin(packet/row['path'])=={k:row[k] for k in ['bytes','sha256']}
links=read(root/'final-executable-results.json');assert len(links)==2
for variant,row in zip(['control','candidate'],links):
 d=root/('link-'+variant);assert row['variant']==variant and row['exit_code']==0 and row['matches_complete_baseline_executable'] and not row['fresh_runtime_campaign']
 assert pin(d/'worker')==dict(bytes=row['executable_bytes'],sha256=row['executable_sha256'])==dict(bytes=1878568,sha256='557d0f5ef2b979e01851ae23b5b3944453a0bd9e772d68161be198916ca06c2c')
 command=read(d/'command.json');assert command['environment']=={'ZERO_AR_DATE':'1'}
 assert [(r['source'],r['bytes'],r['sha256']) for r in command['input_pins']]==[(r['source'],r['bytes'],r['sha256']) for r in inputs]
profiles=packet/'profiles';profile_state=read(profiles/'source-state.json')
assert profile_state['compiler_sha256']==binaries['control']==products['profiles/compiler']['sha256']
assert profile_state['source_commit']=='1090de011646c92e30c2d4b648ed0792c50f300d' and profile_state['compile_threads']==2
diagnostics=read(profiles/'results.json');assert len(diagnostics)==2
for row in diagnostics:
 d=profiles/row['name'];command=read(profiles/(row['name']+'-command.json'));assert command['flags']==wanted and command['profiling_excluded_from_primary'] and command['compiler_sha256']==binaries['control']
 assert row['exit_code']==0 and row['process']==read(d/'process.json') and row['process']['samples']==1 and row['process']['sampling_error'] is None
 samples=list(d.glob('sample-*.txt'));assert len(samples)==1 and 'Call graph:' in samples[0].read_text() and 'compile-profile' in samples[0].read_text()
 for n,item in expected.items():assert pin(d/n)==item and row['files'][n]==dict(item,matches_frozen_reference=True)
summary=dict(base_commit=state['base_commit'],source_revision=state['source_revision'],decision='rejected',production_source_restored=True,program_flags_count=61,common_compile_threads=2,compiler_binary_sha256=binaries,output_hashes=expected,build=build,check=check,focused_test=tests,focused_test_build=test_build,paired_complete_ir_alias_machine_comparisons=128,fixture_pairs=14,numerical_summary=numerical,balanced_blocks=blocks,preliminary_screens=screens,final_links=links,worker_stack_samples=diagnostics,scope=[
 'The trial skips operand-repair traversal only when all transport replacement maps are empty. Fresh ordinary-edge checks still run before route discovery. One exact-helper differential test passes128 complete IR/alias/machine comparisons over shared argument storage, loops and scoped integer/float replacements. Its first unused-import harness failure executes no tests and remains.',
 'Eight primary source-to-Object compiles run serially inABBA/BAAB order with same61flags+scheduling2 and no concurrent heavy build/test/profile/hash/archive work. Compiler phases and cleanup are slower in both blocks, with higher RSS; a tiny instruction saving does not establish a useful improvement. The source and qualified default profiling executable are restored. No balanced full-native cohort is run for the rejected trial.',
 'Both screens,14paired fixtures and both cached complete-executable gates reproduce every source/bytecode/Object/metadata/executable byte. No language/grammar change, weaker proof check, scalar retirement or fresh emitted-program runtime campaign is claimed.',
 'Two separate current-worker stack samples use the qualified source1090/compiler1d with same61flags+scheduling2 and unchanged outputs. Sampled process time and counters are diagnostic, excluded from primary means. Launcher/worker waiting observations are not CPU-time shares; no exclusive phase-time claim is made.',
 'All raw observations, source/patches, exact helper test/harness, failures, outputs, samples and native linker inputs are included. Compiler/test binaries and intermediates are excluded/SHA-pinned. Pure replay validates saved data without rebuilding/rerunning timing. Sub-ten-second complete compilation remains unachieved.'
])
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';saved=packet/'summary.json'
if saved.exists():assert saved.read_text()==encoded
else:saved.write_text(encoded)
print(encoded,end='')
