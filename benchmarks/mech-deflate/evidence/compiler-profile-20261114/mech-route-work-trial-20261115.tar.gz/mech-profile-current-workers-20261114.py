from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys

repo=Path.cwd()
root=Path('/private/tmp/mech-current-workers-profile-20261114')
assert not root.exists()
root.mkdir()
control=Path('/private/tmp/mech-parallel-phases-20261114/candidate')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(control)=='1d482447c6a395483a9c336820f23463c455e9f751ca1539d9371634464ac353'
shutil.copy2(control,root/'compiler')
prior=Path('/private/tmp/mech-parallel-phases-20261114')
flags=json.loads((prior/'runtime-flags.json').read_text())
assert len(flags)==61
(root/'runtime-flags.json').write_text(json.dumps(flags,indent=2)+'\n')
shutil.copy2(prior/'reference-pins.json',root/'reference-pins.json')
shutil.copytree(prior/'reference',root/'reference')
state=dict(source_commit='1090de011646c92e30c2d4b648ed0792c50f300d',integration_commit='ab59d593f4dcc3e457d8c462b459f60eaf80851e',compiler_sha256=sha(control),program_flags_count=61,compile_threads=2,scope='Separate diagnostic stack samples of the qualified current worker compiler with the original constant-phi pass restored. No primary timing or new compiler speedup is claimed.')
(root/'source-state.json').write_text(json.dumps(state,indent=2)+'\n')
env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}
env.update(flags)
env['MECH_COMPACT_COMPILE_THREADS']='2'
records=[]
for index in [1,2]:
    out=root/('sample-'+str(index))
    command=[sys.executable,'benchmarks/mech-deflate/native-profile/profile_compile.py',str(root/'compiler'),'benchmark',str(out),'compact','sample']
    (root/('sample-'+str(index)+'-command.json')).write_text(json.dumps(dict(command=command,flags=dict(flags,MECH_COMPACT_COMPILE_THREADS='2'),compiler_sha256=sha(control),profiling_excluded_from_primary=True),indent=2)+'\n')
    completed=subprocess.run(command,env=env,cwd=repo)
    record=dict(name=out.name,exit_code=completed.returncode)
    if completed.returncode==0:
        checks={}
        for name in ['source.mec','program.mecb','program.o','metadata.json']:
            checks[name]=dict(bytes=(out/name).stat().st_size,sha256=sha(out/name),matches_frozen_reference=(out/name).read_bytes()==(root/'reference'/name).read_bytes())
        (out/'output-check.json').write_text(json.dumps(checks,indent=2)+'\n')
        record.update(process=json.loads((out/'process.json').read_text()),files=checks)
    records.append(record)
    (root/'results.json').write_text(json.dumps(records,indent=2)+'\n')
    assert completed.returncode==0 and all(r['matches_frozen_reference'] for r in checks.values())
    print(json.dumps(record),flush=True)
