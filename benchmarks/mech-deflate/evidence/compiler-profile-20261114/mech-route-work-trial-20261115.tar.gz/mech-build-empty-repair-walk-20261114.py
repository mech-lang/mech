from pathlib import Path
import hashlib, json, os, shutil, subprocess, time

repo=Path.cwd()
root=Path('/private/tmp/mech-empty-repair-walk-20261114')
state=json.loads((root/'source-state.json').read_text())
source=repo/state['source_path']
patch=subprocess.check_output(['git','diff','--binary','--',state['source_path']])
assert subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()==[state['source_path']]
assert source.read_bytes()==(root/'candidate.rs').read_bytes()
assert patch==(root/'candidate.patch').read_bytes()
vendor='vendor/cranelift-codegen/src/remove_constant_phis.rs'
assert (repo/vendor).read_bytes()==subprocess.check_output(['git','show',state['base_commit']+':'+vendor])
pin=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=dict(os.environ,CARGO_TARGET_DIR='/private/tmp/mech-level12-compile-target',CARGO_INCREMENTAL='0')
for stage in ['check','build']:
    assert source.read_bytes()==(root/'candidate.rs').read_bytes()
    command=['cargo',stage,'--locked','--offline','--profile','compiler','-j4','--manifest-path','benchmarks/mech-deflate/native-profile/Cargo.toml','--bin','compile_profile','--message-format=json']
    started=time.perf_counter()
    with (root/('candidate-'+stage+'.jsonl')).open('w') as stdout,(root/('candidate-'+stage+'.stderr')).open('w') as stderr:
        completed=subprocess.run(command,cwd=repo,env=env,stdout=stdout,stderr=stderr)
    record=dict(command=command,head=state['base_commit'],patch_sha256=pin(root/'candidate.patch'),seconds=time.perf_counter()-started,exit_code=completed.returncode,CARGO_TARGET_DIR=env['CARGO_TARGET_DIR'],CARGO_INCREMENTAL='0',original_constant_phi_source_sha256=pin(repo/vendor))
    if completed.returncode==0 and stage=='build':
        rows=[json.loads(x) for x in (root/'candidate-build.jsonl').read_text().splitlines()]
        binaries=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='compile_profile' and r.get('executable')]
        assert len(binaries)==1
        shutil.copy2(binaries[0],root/'candidate')
        record.update(binary=str(root/'candidate'),binary_sha256=pin(root/'candidate'))
    (root/('candidate-'+stage+'.json')).write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record),flush=True)
    if completed.returncode:raise SystemExit(completed.returncode)
assert source.read_bytes()==(root/'candidate.rs').read_bytes()
assert subprocess.check_output(['git','diff','--binary','--',state['source_path']])==patch
