Empty repair-walk trial and current worker stack diagnostics, campaign2026-11-14/15.
The trial adds an early return when every transport replacement map is empty.
Original ordinary-edge checks remain before route discovery. Production source
and the default profiling executable are restored after rejection. Cargo's last
trial library is stale and the next default build must recompile restored source.
One focused test compares128 complete IR/alias/machine outcomes using exact
original and candidate helper bodies; only their function names change. Shared
branch-argument storage, loops and scoped integer/float replacement maps are
covered. Pinned original control Cranelift APIs are independent of the active
default-target build. An unused-import harness compile failure executes no
tests and remains. The correction changes no production source.
Both full-output screens,14paired fixtures and both cached complete-executable
link gates pass. Eight primary source-to-Object compiles run serially inABBA/BAAB
order, same61programflags+scheduling2, with no concurrent heavy work. Compiler
phases and cleanup are slower in both blocks and compiler RSS rises; the tiny
instruction saving does not justify retention. No balanced full-native cohort
is run for the rejected trial. Every adverse observation remains.
Two separate external stack samples use the qualified current worker compiler
(source1090,compilerSHA1d482447...). Both have one successful sample attempt and
match all program outputs. Sampled process times/counters are diagnostic and
excluded from primary means. Launcher/worker waiting stacks are not CPU-time
shares; stack observations do not establish exclusive phase costs.
No grammar/language change, weaker check, scalar retirement or fresh emitted
program runtime campaign is claimed. Objects/metadata and full executables stay
byte-identical. Compiler/test binaries and intermediates are excluded/SHA-pinned.
All source/patches, tests, failures, commands, raw timing/profiling data, generated
programs and frozen native linker inputs are included. Pure replay checks saved
data/calculations without rerunning builds or timings. Under10seconds remains open.
