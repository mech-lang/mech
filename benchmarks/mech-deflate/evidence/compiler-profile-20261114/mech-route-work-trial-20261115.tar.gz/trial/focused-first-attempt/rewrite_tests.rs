use cranelift_codegen::{Context, dominator_tree::DominatorTree, flowgraph::ControlFlowGraph};
use cranelift_codegen::cursor::{Cursor, FuncCursor};
use cranelift_codegen::ir::{AbiParam, Block, BlockCall, Function, InstBuilder, InstructionData, MemFlags, Value, types};
use cranelift_frontend::{FunctionBuilder, FunctionBuilderContext};
use std::collections::BTreeMap;
fn rewrite_reference(
    f: &mut Function,
    dom: &DominatorTree,
    repairs: &BTreeMap<Block, BTreeMap<Value, Value>>,
) {
    enum Step {
        Enter(Block),
        Leave(Vec<(Value, Option<Value>)>),
    }
    let Some(entry) = f.layout.entry_block() else {
        return;
    };
    let mut steps = vec![Step::Enter(entry)];
    let mut active = BTreeMap::new();
    while let Some(step) = steps.pop() {
        match step {
            Step::Leave(undo) => {
                for (old, prior) in undo.into_iter().rev() {
                    if let Some(value) = prior {
                        active.insert(old, value);
                    } else {
                        active.remove(&old);
                    }
                }
            }
            Step::Enter(block) => {
                let mut undo = Vec::new();
                if let Some(map) = repairs.get(&block) {
                    for (&old, &new) in map {
                        undo.push((old, active.insert(old, new)));
                    }
                }
                let instructions = f.layout.block_insts(block).collect::<Vec<_>>();
                for inst in instructions {
                    for value in f.dfg.inst_args_mut(inst) {
                        if let Some(&new) = active.get(value) {
                            *value = new;
                        }
                    }
                    let dfg = &mut f.dfg;
                    for call in dfg.insts[inst]
                        .branch_destination_mut(&mut dfg.jump_tables, &mut dfg.exception_tables)
                    {
                        let args = call
                            .args(&dfg.value_lists)
                            .map(|arg| {
                                let old = arg.as_value().expect("ordinary checked edge");
                                active.get(&old).copied().unwrap_or(old).into()
                            })
                            .collect::<Vec<_>>();
                        *call = BlockCall::new(
                            call.block(&dfg.value_lists),
                            args,
                            &mut dfg.value_lists,
                        );
                    }
                }
                steps.push(Step::Leave(undo));
                steps.extend(dom.children(block).map(Step::Enter));
            }
        }
    }
}

fn rewrite_candidate(
    f: &mut Function,
    dom: &DominatorTree,
    repairs: &BTreeMap<Block, BTreeMap<Value, Value>>,
) {
    // Without transport replacements every operand already names its current
    // value. The caller has checked ordinary edges before route discovery.
    if repairs.values().all(|map| map.is_empty()) {
        return;
    }
    enum Step {
        Enter(Block),
        Leave(Vec<(Value, Option<Value>)>),
    }
    let Some(entry) = f.layout.entry_block() else {
        return;
    };
    let mut steps = vec![Step::Enter(entry)];
    let mut active = BTreeMap::new();
    while let Some(step) = steps.pop() {
        match step {
            Step::Leave(undo) => {
                for (old, prior) in undo.into_iter().rev() {
                    if let Some(value) = prior {
                        active.insert(old, value);
                    } else {
                        active.remove(&old);
                    }
                }
            }
            Step::Enter(block) => {
                let mut undo = Vec::new();
                if let Some(map) = repairs.get(&block) {
                    for (&old, &new) in map {
                        undo.push((old, active.insert(old, new)));
                    }
                }
                let instructions = f.layout.block_insts(block).collect::<Vec<_>>();
                for inst in instructions {
                    for value in f.dfg.inst_args_mut(inst) {
                        if let Some(&new) = active.get(value) {
                            *value = new;
                        }
                    }
                    let dfg = &mut f.dfg;
                    for call in dfg.insts[inst]
                        .branch_destination_mut(&mut dfg.jump_tables, &mut dfg.exception_tables)
                    {
                        let args = call
                            .args(&dfg.value_lists)
                            .map(|arg| {
                                let old = arg.as_value().expect("ordinary checked edge");
                                active.get(&old).copied().unwrap_or(old).into()
                            })
                            .collect::<Vec<_>>();
                        *call = BlockCall::new(
                            call.block(&dfg.value_lists),
                            args,
                            &mut dfg.value_lists,
                        );
                    }
                }
                steps.push(Step::Leave(undo));
                steps.extend(dom.children(block).map(Step::Enter));
            }
        }
    }
}

fn fixture(seed: usize) -> (Function, Block, Block, Vec<(Value,Value)>) {
    let mut f=Function::new();
    f.signature.params=vec![AbiParam::new(types::I64),AbiParam::new(types::F64),AbiParam::new(types::I32)];
    f.signature.returns=vec![AbiParam::new(types::I64)];
    let mut fc=FunctionBuilderContext::new();
    let mut b=FunctionBuilder::new(&mut f,&mut fc);
    let entry=b.create_block();let left=b.create_block();let right=b.create_block();let header=b.create_block();let latch=b.create_block();let done=b.create_block();
    b.append_block_params_for_function_params(entry);
    for ty in [types::I64,types::F64,types::I64,types::F64] { b.append_block_param(header,ty); }
    b.switch_to_block(entry);let args=b.block_params(entry).to_vec();
    b.ins().brif(args[2],left,&[],right,&[]);
    let first;let second;
    if seed%2==0 {
        b.switch_to_block(left);first=b.ins().jump(header,&[args[0].into(),args[1].into(),args[0].into(),args[1].into()]);
        b.switch_to_block(right);second=b.ins().jump(header,&[args[0].into(),args[1].into(),args[0].into(),args[1].into()]);
    } else {
        b.switch_to_block(right);first=b.ins().jump(header,&[args[0].into(),args[1].into(),args[0].into(),args[1].into()]);
        b.switch_to_block(left);second=b.ins().jump(header,&[args[0].into(),args[1].into(),args[0].into(),args[1].into()]);
    }
    // Identical ordinary branches intentionally share pooled argument storage.
    let shared=match b.func.dfg.insts[first] { InstructionData::Jump{destination,..}=>destination,_=>unreachable!() };
    if let InstructionData::Jump{destination,..}=&mut b.func.dfg.insts[second] { *destination=shared; }
    b.switch_to_block(header);let p=b.block_params(header).to_vec();
    let sum=b.ins().iadd(p[0],args[0]);let fp=b.ins().fadd(p[1],args[1]);
    for i in 0..seed%5 { let _=b.ins().iadd_imm(sum,i as i64); }
    b.ins().brif(args[2],latch,&[],done,&[]);
    b.switch_to_block(latch);b.ins().jump(header,&[sum.into(),fp.into(),p[2].into(),p[3].into()]);
    b.switch_to_block(done);let bits=b.ins().bitcast(types::I64,MemFlags::new(),args[1]);let x=b.ins().iadd(p[0],args[0]);let result=b.ins().bxor(x,bits);b.ins().return_(&[result]);
    b.seal_all_blocks();b.finalize();
    (f,entry,header,vec![(args[0],p[2]),(args[1],p[3])])
}
fn machine(f: Function)->Vec<u8> {
    use cranelift_codegen::{isa,settings::{self,Configurable}};
    let mut flags=settings::builder();flags.set("opt_level","speed").unwrap();
    let isa=isa::lookup_by_name("aarch64").unwrap().finish(settings::Flags::new(flags)).unwrap();
    let mut c=Context::for_function(f);c.compile(&*isa,&mut Default::default()).unwrap().buffer.data().to_vec()
}
#[test]
fn shared_argument_storage_and_scoped_integer_float_repairs_match_original() {
    let flags=cranelift_codegen::settings::Flags::new(cranelift_codegen::settings::builder());
    let mut comparisons=0;
    for seed in 0..32 {
        for kind in 0..4 {
            let (original,entry,header,pairs)=fixture(seed);
            cranelift_codegen::verify_function(&original,&flags).unwrap();
            let mut repairs=BTreeMap::new();
            if kind!=0 { repairs.insert(entry,BTreeMap::new());repairs.insert(header,BTreeMap::new()); }
            if kind>=2 { repairs.insert(header,pairs.into_iter().take(if kind==2 {1}else{2}).collect()); }
            let mut before=original.clone();let mut after=original;
            let cfg=ControlFlowGraph::with_function(&before);let dom=DominatorTree::with_function(&before,&cfg);
            let after_cfg=ControlFlowGraph::with_function(&after);let after_dom=DominatorTree::with_function(&after,&after_cfg);
            rewrite_reference(&mut before,&dom,&repairs);rewrite_candidate(&mut after,&after_dom,&repairs);
            cranelift_codegen::verify_function(&before,&flags).unwrap();cranelift_codegen::verify_function(&after,&flags).unwrap();
            assert_eq!(format!("{}",before.display()),format!("{}",after.display()),"seed={seed} kind={kind}");
            assert_eq!(before.dfg.num_values(),after.dfg.num_values());
            for value in before.dfg.values() { assert_eq!(before.dfg.value_def(value),after.dfg.value_def(value)); }
            assert_eq!(machine(before),machine(after),"seed={seed} kind={kind}");comparisons+=1;
        }
    }
    assert_eq!(comparisons,128);println!("paired complete IR/alias/machine comparisons: {comparisons}");
}
