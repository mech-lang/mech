from pathlib import Path
import hashlib,json,shutil,subprocess

repo=Path.cwd();packet=Path('/private/tmp/mech-route-work-trial-packet-20261115');assert not packet.exists();packet.mkdir()
pin=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
excluded=[]
for name,raw,products in [('trial',Path('/private/tmp/mech-empty-repair-walk-20261114'),{'control','candidate','rewrite-tests'}),('profiles',Path('/private/tmp/mech-current-workers-profile-20261114'),{'compiler'})]:
 for source in sorted(raw.rglob('*')):
  if not source.is_file():continue
  rel=source.relative_to(raw)
  if rel.as_posix() in products or source.name.endswith('.rcgu.o') or source.suffix=='.rmeta':
   excluded.append(dict(path=name+'/'+rel.as_posix(),**pin(source)));continue
  dest=packet/name/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest)
base='aaef2a932bf81c7638c522dc777a2b78f0abcb5d'
source_path='hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/threaded_edges/mod.rs'
assert (repo/source_path).read_bytes()==subprocess.check_output(['git','show',base+':'+source_path])==(packet/'trial/reference.rs').read_bytes()
for row in json.loads((packet/'trial/fixture-results.json').read_text()):
 name=row['fixture']
 if name.startswith('hosts/'):
  content=subprocess.check_output(['git','show',base+':'+name]);assert hashlib.sha256(content).hexdigest()==row['source_sha256'];(packet/'trial/fixture-inputs'/Path(name).name).write_bytes(content)
config=[]
for name in ['.cargo/config.toml','benchmarks/mech-deflate/native-profile/Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.lock','benchmarks/mech-deflate/native-profile/compile_profile.rs','benchmarks/mech-deflate/native-profile/profile_compile.py','vendor/cranelift-codegen/src/remove_constant_phis.rs']:
 dest=packet/'source-config'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(subprocess.check_output(['git','show',base+':'+name]));config.append(dict(path=name,**pin(dest)))
(packet/'source-config-pins.json').write_text(json.dumps(config,indent=2)+'\n')
prior=Path('/private/tmp/mech-round2-planning-packet-20261114')
for name in ['licenses','native-link-inputs']:shutil.copytree(prior/name,packet/name)
shutil.copy2(prior/'native-link-inputs.json',packet/'native-link-inputs.json')
validation=packet/'validation';validation.mkdir()
for suffix in ['.json','.archive.json']:
 shutil.copy2(repo/'benchmarks/mech-deflate/native-profile'/('parallel-phases-compile-apple-m3-20261114'+suffix),validation/('prior-qualified'+suffix))
for pattern in ['*empty-repair-walk*20261114.py','*current-workers*20261114.py']:
 for script in Path('/private/tmp').glob(pattern):shutil.copy2(script,packet/script.name)
for name in ['mech-profile-current-workers-20261114.stdout.log','mech-profile-current-workers-20261114.stderr.log']:
 shutil.copy2(Path('/private/tmp')/name,packet/name)
shutil.copy2('/private/tmp/mech-curate-route-work-trial-20261115.py',packet/'curate.py');shutil.copy2('/private/tmp/mech-replay-route-work-trial-20261115.py',packet/'replay.py')
(packet/'excluded-compiler-products.json').write_text(json.dumps(excluded,indent=2)+'\n')
(packet/'source-state.json').write_text(json.dumps(dict(base_commit=base,source_revision=base,source_path=source_path,decision='rejected',production_source_restored=True,program_flags_count=61,common_compile_threads=2),indent=2)+'\n')
(packet/'README.txt').write_text('''Empty repair-walk trial and current worker stack diagnostics, campaign2026-11-14/15.
The trial adds an early return when every transport replacement map is empty.
Original ordinary-edge checks remain before route discovery. Production source
and the default profiling executable are restored after rejection. Cargo's last
trial library is stale and the next default build must recompile restored source.
One focused test compares128 complete IR/alias/machine outcomes using exact
original and candidate helper bodies; only their function names change. Shared
branch-argument storage, loops and scoped integer/float replacement maps are
covered. Pinned original control Cranelift APIs are independent of the active
default-target build. An unused-import harness compile failure executes no
tests and remains. The correction changes no production source.
Both full-output screens,14paired fixtures and both cached complete-executable
link gates pass. Eight primary source-to-Object compiles run serially inABBA/BAAB
order, same61programflags+scheduling2, with no concurrent heavy work. Compiler
phases and cleanup are slower in both blocks and compiler RSS rises; the tiny
instruction saving does not justify retention. No balanced full-native cohort
is run for the rejected trial. Every adverse observation remains.
Two separate external stack samples use the qualified current worker compiler
(source1090,compilerSHA1d482447...). Both have one successful sample attempt and
match all program outputs. Sampled process times/counters are diagnostic and
excluded from primary means. Launcher/worker waiting stacks are not CPU-time
shares; stack observations do not establish exclusive phase costs.
No grammar/language change, weaker check, scalar retirement or fresh emitted
program runtime campaign is claimed. Objects/metadata and full executables stay
byte-identical. Compiler/test binaries and intermediates are excluded/SHA-pinned.
All source/patches, tests, failures, commands, raw timing/profiling data, generated
programs and frozen native linker inputs are included. Pure replay checks saved
data/calculations without rerunning builds or timings. Under10seconds remains open.
''')
print(packet)
