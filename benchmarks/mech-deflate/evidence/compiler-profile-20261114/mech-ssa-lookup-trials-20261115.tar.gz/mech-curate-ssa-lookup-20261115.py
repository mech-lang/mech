from pathlib import Path
import hashlib,json,shutil,subprocess
repo=Path.cwd();packet=Path('/private/tmp/mech-ssa-lookup-packet-20261115');packet.mkdir(exist_ok=False)
roots={'inline-first':Path('/private/tmp/mech-inline-ssa-defs-20261115'),'shared-roots':Path('/private/tmp/mech-ssa-chain-roots-20261115')}
pin=lambda path:dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
excluded=[];state=dict(source_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),trials={})
for label,root in roots.items():
 raw=json.loads((root/'source-state.json').read_text());decision=json.loads((root/'decision.json').read_text());rows=json.loads((root/'cohort.json').read_text());state['trials'][label]=dict(source_base=raw['base_commit'],decision=decision['decision'],value_compaction=[rows[0]['value_ids_before'],rows[0]['value_ids_after']])
 for path in sorted(root.rglob('*')):
  if not path.is_file():continue
  rel=path.relative_to(root)
  if rel.as_posix() in ['control','candidate','focused/tests','ir-comparison/probe']:
   excluded.append(dict(path=label+'/'+rel.as_posix(),**pin(path)));continue
  dest=packet/label/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,dest)
 for row in json.loads((root/'fixture-results.json').read_text()):
  if row['fixture'].startswith('hosts/'):
   dest=packet/label/'fixture-inputs'/Path(row['fixture']).name
   dest.parent.mkdir(exist_ok=True);dest.write_bytes(subprocess.check_output(['git','show',raw['base_commit']+':'+row['fixture']]))
(packet/'source-state.json').write_text(json.dumps(state,indent=2)+'\n');(packet/'excluded-compiler-products.json').write_text(json.dumps(excluded,indent=2)+'\n')
base='f19531c3b016b551fb7d4bb8f2a3d4adca4f42d7';paths=['.cargo/config.toml','Cargo.toml','Cargo.lock','benchmarks/mech-deflate/native-profile/Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.lock','benchmarks/mech-deflate/native-profile/compile_profile.rs','benchmarks/mech-deflate/native-profile/profile_compile.py','vendor/cranelift-frontend/Cargo.toml','vendor/cranelift-frontend/src/lib.rs','vendor/cranelift-frontend/src/variable.rs','vendor/cranelift-frontend/src/ssa.rs','hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/threaded_edges/mod.rs','hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/threaded_edges/route.rs'];config=[]
for name in paths:
 content=subprocess.check_output(['git','show',base+':'+name]);dest=packet/'source-config'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(content);config.append(dict(path=name,source_revision=base,**pin(dest)))
(packet/'source-config-pins.json').write_text(json.dumps(config,indent=2)+'\n')
capture=json.loads(Path('/private/tmp/mech-pr973-refresh-20261115/link/capture/link-command.json').read_text());inputs=[]
for at,row in enumerate(capture['inputs']):
 path=Path(row['retained_path']);wanted={k:row[k] for k in ['bytes','sha256']};assert pin(path)==wanted
 rel=Path('native-link-inputs')/(str(at)+'-'+path.name);dest=packet/rel;dest.parent.mkdir(exist_ok=True);shutil.copy2(path,dest);inputs.append(dict(source=row['source'],path=rel.as_posix(),**wanted))
(packet/'native-link-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
shutil.copytree('/private/tmp/mech-round2-planning-packet-20261114/licenses',packet/'licenses');validation=packet/'validation';validation.mkdir()
for suffix in ['.json','.archive.json']:shutil.copy2(repo/'benchmarks/mech-deflate/native-profile'/('scoped-source-apple-m3-20261115'+suffix),validation/('prior-qualified'+suffix))
for name in ['mech-build-inline-ssa-defs-20261115.py','mech-test-inline-ssa-defs-20261115.py','mech-qualify-inline-ssa-defs-20261115.py','mech-build-ssa-chain-roots-20261115.py','mech-test-ssa-chain-roots-20261115.py','mech-compare-ssa-chain-roots-20261115.py','mech-qualify-ssa-chain-roots-20261115.py','mech-prepare-ssa-lookup-replay-20261115.py','mech-curate-ssa-lookup-20261115.py']:shutil.copy2(Path('/private/tmp')/name,packet/name)
shutil.copy2('/private/tmp/mech-replay-ssa-lookup-20261115.py',packet/'replay.py')
(packet/'README.txt').write_text('''SSA lookup trials on the current Deflate/runtime and scoped-source compiler.
Inline-first storage (base972) and shared predecessor roots (basef195) each
use the same qualified AE control, standard compiler profile,61programflags
and2workers. Decisions, complete source/patches, command logs, focused tests,
all14fixtures, eight primary Object observations and cached full-executable
gates are retained per trial. All raw adverse measurements remain.
Construction of the optimized compiler, focused tests, cached link gates and
archival are excluded from primary timing and never overlap primary cohorts.
All program source/bytecode/Object/complete metadata and gated whole-exe bytes
match. No grammar/language change, weaker proof, scalar retirement or new
program-runtime timing campaign is claimed. Compiler/test executables and
dependency libraries are excluded and hash-pinned; executable program images
and fixed native adapter inputs are included. Source snapshots and unchanged
profile/Variable types are included. Pure replay verifies saved files and
recomputes means/blocks without external paths, compiler or new timing.
''');print(packet)
