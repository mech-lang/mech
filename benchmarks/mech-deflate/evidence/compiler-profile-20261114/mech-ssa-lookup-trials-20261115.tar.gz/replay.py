from pathlib import Path
import hashlib,json,re,statistics
packet=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
pins={}
def pin(path):
 if path not in pins:pins[path]=dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
 return pins[path]
def apply(source,patch):
 lines=source.splitlines(keepends=True);diff=patch.splitlines(keepends=True);result=[];position=0;i=0
 while i<len(diff):
  match=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',diff[i])
  if not match:i+=1;continue
  start=int(match[1])-1;assert start>=position;result.extend(lines[position:start]);position=start;i+=1
  while i<len(diff) and not diff[i].startswith('@@'):
   line=diff[i]
   if line.startswith(' '):assert lines[position]==line[1:];result.append(lines[position]);position+=1
   elif line.startswith('-'):assert lines[position]==line[1:];position+=1
   elif line.startswith('+'):result.append(line[1:])
   else:raise AssertionError(line)
   i+=1
 result.extend(lines[position:]);return ''.join(result)
state=read(packet/'source-state.json');prior=read(packet/'validation/prior-qualified.json')
assert pin(packet/'validation/prior-qualified.json')['sha256']==read(packet/'validation/prior-qualified.archive.json')['replay_sha256']
expected=prior['output_hashes'];qualified_binary=prior['compiler_binary_sha256']['candidate']
products={r['path']:r for r in read(packet/'excluded-compiler-products.json')}
for row in read(packet/'source-config-pins.json'):assert pin(packet/'source-config'/row['path'])=={k:row[k] for k in ['bytes','sha256']}
inputs=read(packet/'native-link-inputs.json')
for row in inputs:assert pin(packet/row['path'])=={k:row[k] for k in ['bytes','sha256']}
executable_pin=dict(bytes=2060440,sha256='d6c65cc3fb18acc4be77dce329962105bf0f2b56dd2623a12f466256463eca61')
trials=[]
for label in ['inline-first','shared-roots']:
 root=packet/label;raw=read(root/'source-state.json');trial_state=state['trials'][label];decision=read(root/'decision.json')
 assert raw['base_commit']==trial_state['source_base']
 old=(root/'reference.rs').read_text();new=(root/'candidate.rs').read_text()
 assert pin(root/'reference.rs')['sha256']==raw['reference_sha256']
 assert pin(root/'candidate.rs')['sha256']==raw['candidate_sha256']
 assert pin(root/'candidate.patch')['sha256']==raw['patch_sha256']
 assert old==(packet/'source-config/vendor/cranelift-frontend/src/ssa.rs').read_text()
 assert apply(old,(root/'candidate.patch').read_text())==new
 binaries={v:products[label+'/'+v]['sha256'] for v in ['control','candidate']}
 assert binaries['control']==qualified_binary
 flags=read(root/'runtime-flags.json');assert len(flags)==61;wanted=dict(flags,MECH_COMPACT_COMPILE_THREADS='2')
 assert read(root/'reference-pins.json')==expected
 build=read(root/'candidate-build.json');check=read(root/'candidate-check.json')
 for row in [build,check]:
  assert row['exit_code']==0 and row['base_commit']==raw['base_commit'] and row['patch_sha256']==raw['patch_sha256'] and row['CARGO_INCREMENTAL']=='0'
  assert row['command']==['cargo','+nightly-2026-03-03',('check' if row is check else 'build'),'--locked','--offline','--profile','compiler','-j4','--manifest-path','benchmarks/mech-deflate/native-profile/Cargo.toml','--bin','compile_profile','--message-format=json']
 assert build['binary_sha256']==binaries['candidate']
 pipeline=read(root/'qualification-pipeline.json');assert [r['stage'] for r in pipeline]==['screens','executable-gates','fixtures-object-cohort'] and all(r['state']=='complete' and r['exit_code']==0 for r in pipeline)
 tests=root/'focused';assert read(tests/'test.json')['exit_code']==read(tests/'build.json')['exit_code']==0
 assert read(tests/'build.json')['binary_sha256']==products[label+'/focused/tests']['sha256']
 count=29 if label=='inline-first' else 30
 assert f'test result: ok. {count} passed; 0 failed' in (tests/'test.stdout.log').read_text()
 command=read(tests/'command.json')
 for variant,row in zip(['reference','candidate'],command['source_pins']):
  source=(root/(variant+'.rs')).read_text();assert hashlib.sha256(source.encode()).hexdigest()==row['original_sha256']
  assert (tests/(variant+'.rs')).read_text()==source.replace('use crate::ssa::SSABuilder;','use super::SSABuilder;')
  assert pin(tests/(variant+'.rs'))['sha256']==row['harness_sha256']
 proof=None
 if label=='inline-first':
  start='// Each lookup usually touches';end='#[cfg(test)]\nmod tests'
  assert old[old.index(start):old.index(end)]==new[new.index(start):new.index(end)]
  assert pin(tests/'harness.rs')['bytes']>0
 else:
  failed=root/'sandbox-first-attempt';failure=read(failed/'failure.json')
  assert read(failed/'control-screen/process.json')['exit_code']==1
  assert 'time: sysctl kern.clockrate: Operation not permitted' in (failed/'control-screen/stderr.log').read_text()
  assert read(failed/'qualification-pipeline.json')[0]['state']=='failed'
  for name,item in expected.items():
   assert pin(failed/'control-screen'/name)==item
   assert failure['files'][name]==dict(item,matches_current_control_output=True)
  probe=root/'ir-comparison';proof=read(probe/'result.json')
  assert read(probe/'build.json')['exit_code']==read(probe/'test.json')['exit_code']==0
  assert read(probe/'test.json')['binary_sha256']==products[label+'/ir-comparison/probe']['sha256']
  cases=[json.loads(x) for x in (probe/'cases.jsonl').read_text().splitlines()]
  assert len(cases)==proof['paired_cases']==160 and proof['verified_functions']==320 and all(r['identical'] for r in cases)
  assert proof['cases_sha256']==pin(probe/'cases.jsonl')['sha256']
  assert '#[path = "candidate.rs"] mod ssa;' in (root/'ir-comparison.rs').read_text()
  assert '#[path = "reference.rs"] mod reference;' in (root/'ir-comparison.rs').read_text()
 order=[('control','control-1'),('candidate','candidate-1'),('candidate','candidate-2'),('control','control-2'),('candidate','candidate-3'),('control','control-3'),('control','control-4'),('candidate','candidate-4')]
 rows=[];screens=[]
 for variant,name in [('control','control-screen'),('candidate','candidate-screen')]+order:
  d=root/name;command=read(root/(name+'-command.json'));process=read(d/'process.json');compile=read(d/'compile.json');checks=read(d/'output-check.json')
  assert command['flags']==wanted and not command['profiling_excluded_from_primary']
  assert command['binary_sha256']==binaries[variant]
  assert process['exit_code']==0 and process['samples']==0 and process['sampling_error'] is None
  assert process['elapsed_boundary']=='driver_start_to_process_wait_completion' and process['elapsed_seconds']>compile['total_seconds']
  for n,item in expected.items():assert pin(d/n)==item and checks[n]==dict(item,matches_current_control_output=True)
  row=dict(name=name,variant=variant,compile=compile,process=process,files=checks)
  if name.endswith('-screen'):screens.append(row);continue
  stamps=[json.loads(line) for line in (d/'stages.jsonl').read_text().splitlines()];elapsed=lambda prefix:next(s['elapsed'] for s in stamps if s['line'].startswith(prefix))
  for key,begin,end in [('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]:row[key]=elapsed(end)-elapsed(begin)
  log=(d/'stderr.log').read_text()
  for key,pattern in [('instructions',r'(\d+)  instructions retired'),('max_rss_bytes',r'(\d+)  maximum resident set size'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]:row[key]=int(re.search(pattern,log).group(1))
  row['compaction_seconds']=elapsed('compact-stage: CFG cleanup')-elapsed('compact-stage: compact values before=');row['cleanup_including_compaction_seconds']=row['cleanup_seconds']+row['compaction_seconds']
  for key,prefix in [('value_ids_before','compact-stage: compact values before='),('value_ids_after','compact-values: retained=')]:row[key]=int(next(s['line'] for s in stamps if s['line'].startswith(prefix)).split('=')[-1])
  assert (row['value_ids_before'],row['value_ids_after'])==tuple(trial_state['value_compaction'])
  rows.append(row)
 assert rows==read(root/'cohort.json')
 fields={'compiler_seconds':lambda r:r['compile']['total_seconds'],'whole_process_seconds':lambda r:r['process']['elapsed_seconds']}
 for phase in ['parse','catalog','frontend','artifact','encode','native']:fields[phase+'_seconds']=lambda r,p=phase:next(x['seconds'] for x in r['compile']['phases'] if x['phase']==p)
 for key in ['canonical_lowering_seconds','preparation_seconds','numeric_generation_seconds','source_cfg_seconds','cleanup_including_compaction_seconds','cleanup_seconds','compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:fields[key]=lambda r,k=key:r[k]
 numerical={}
 for key,fn in fields.items():
  x={v:[fn(r) for r in rows if r['variant']==v] for v in ['control','candidate']};x['mean_reduction_fraction']=1-statistics.mean(x['candidate'])/statistics.mean(x['control']);numerical[key]=x
 assert numerical==read(root/'numerical-summary.json')
 blocks=[]
 for subset in [rows[:4],rows[4:]]:
  block={}
  for key in fields:
   x={v:statistics.mean(fields[key](r) for r in subset if r['variant']==v) for v in ['control','candidate']};x['mean_reduction_fraction']=1-x['candidate']/x['control'];block[key]=x
  blocks.append(block)
 fixtures=read(root/'fixture-results.json');assert len(fixtures)==14
 for row in fixtures:
  name=row['fixture'].split(':')[-1] if ':' in row['fixture'] else Path(row['fixture']).stem
  assert pin(root/'fixture-inputs'/(name+'.mec'))['sha256']==row['source_sha256'] and row['all_outputs_match'] and row['variants']['control']==row['variants']['candidate']
  for variant in ['control','candidate']:
   d=root/'fixtures'/name/variant;command=read(d/'command.json');assert command['flags']==wanted and command['binary_sha256']==binaries[variant]
   assert row['variants'][variant]['exit_code']==0 and len(row['variants'][variant]['files'])==4
   for n,item in row['variants'][variant]['files'].items():assert pin(d/n)==item


 links=read(root/'final-executable-results.json');assert len(links)==2
 for variant,row in zip(['control','candidate'],links):
  directory=root/('link-'+variant);command=read(directory/'command.json')
  assert row['variant']==variant and row['exit_code']==0 and row['matches_complete_baseline_executable'] and not row['fresh_runtime_campaign']
  assert pin(directory/'worker')==executable_pin==dict(bytes=row['executable_bytes'],sha256=row['executable_sha256'])
  assert command['environment']=={'ZERO_AR_DATE':'1'}
  assert [(r['source'],r['bytes'],r['sha256']) for r in command['input_pins']]==[(r['source'],r['bytes'],r['sha256']) for r in inputs]
 if label=='inline-first':
  assert decision['decision']=='rejected' and decision['production_source_restored']
  for block in blocks:
   for key in ['compiler_seconds','source_cfg_seconds','instructions']:assert block[key]['mean_reduction_fraction']<0
 if decision['decision']=='rejected':assert decision['production_source_restored'] and decision['canonical_tool_sha256']==qualified_binary
 trials.append(dict(label=label,source_base=raw['base_commit'],patch_sha256=raw['patch_sha256'],decision=decision,compiler_binary_sha256=binaries,build=build,check=check,focused_test_count=count,focused_test=read(tests/'test.json'),focused_test_build=read(tests/'build.json'),complete_ir_equivalence=proof,fixture_pairs=14,numerical_summary=numerical,balanced_blocks=blocks,preliminary_screens=screens,final_links=links))
summary=dict(source_revision=state['source_revision'],program_flags_count=61,common_compile_threads=2,output_hashes=expected,final_executable=executable_pin,trials=trials,scope=[
 'Two independently frozen SSA lookup trials use the retained scoped-source compiler and current Deflate/runtime. Inline-first storage base972 and shared-roots basef195 differ only in publication documentation outside the measured SSA patch. Both controls use the same qualified AE binary. No percentages from earlier smaller programs or PGO are added.',
 'Each trial has eight primary source-to-Object compiles in serial ABBA/BAAB order,14paired fixtures,29or30full copied-module tests and two cached complete-executable gates. No heavy build/test/sampling/hash/archive overlaps primary timing. Native adapter inputs are pinned/cached, and these two link gates are excluded from compilation means.',
 'Inline-first keeps the64-byte record and original SSA algorithm but worsens compiler/sourceCFG/instructions in both blocks. Shared topology applies only to sealed predecessor chains with exact unique definition and disables permanently on any SSA parameter or differing definition;160paired complete IR/alias/query/side-effect/enumeration cases verify both implementations. Measured decisions and every adverse observation remain.',
 'Allsource/bytecode/Object/complete metadata and gated whole-executable bytes match. Rejected production patches and canonical compiler tool are restored. Compiler/test executables and dependency libraries are excluded and SHA-pinned. No grammar/language change, weaker fresh proof, scalar retirement or fresh emitted-program runtime campaign is claimed. Complete compilation below ten seconds remains unachieved.'
])
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';saved=packet/'summary.json'
if saved.exists():assert saved.read_text()==encoded
else:saved.write_text(encoded)
print(encoded,end='')
