from pathlib import Path
import hashlib,json,subprocess,time
root=Path('/private/tmp/mech-inline-ssa-defs-20261115');out=root/'focused';assert not out.exists();out.mkdir();pins=[]
for variant in ['reference','candidate']:
    original=(root/(variant+'.rs')).read_text();assert original.count('use crate::ssa::SSABuilder;')==1
    text=original.replace('use crate::ssa::SSABuilder;','use super::SSABuilder;');p=out/(variant+'.rs');p.write_text(text);pins.append(dict(path=str(p),original_sha256=hashlib.sha256(original.encode()).hexdigest(),harness_sha256=hashlib.sha256(text.encode()).hexdigest(),change='Only the test import points to its own copied module; all production code is exact.'))
harness='''#![allow(dead_code)]
extern crate alloc;
pub use cranelift_frontend::Variable;
#[path="reference.rs"] mod reference;
#[path="candidate.rs"] mod candidate;
''';(out/'harness.rs').write_text(harness)
rows=[json.loads(x) for x in Path('/private/tmp/mech-scoped-route-ranges-current-20261115/candidate-build.jsonl').read_text().splitlines()]
command=['rustc','+nightly-2026-03-03','--crate-name','inline_ssa_tests','--edition=2024','--test',str(out/'harness.rs'),'-C','opt-level=3','-C','lto=thin','-C','codegen-units=1','-D','warnings','-o',str(out/'tests')];dependencies=[];directories=set()
for name in ['cranelift_codegen','cranelift_frontend','log']:
    files=[Path(p) for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']==name for p in r['filenames'] if p.endswith('.rlib')];assert len(files)==1
    p=files[0];command+=['--extern',name+'='+str(p)];directories.add(p.parent);dependencies.append(dict(name=name,path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
for p in sorted(directories):command+=['-L','dependency='+str(p)]
(out/'command.json').write_text(json.dumps(dict(command=command,source_pins=pins,dependencies=dependencies,scope='Exact entire original and candidate SSA modules, each with its complete module unit suite. Only crate::ssa test import changes to super::SSABuilder so both suites test their own module. Public Variable type unchanged; all SSA traversal code is byte-identical. Includes50,000-operation BTreeMap oracle, inline/dense/sparse promotions, pendingNone, ordered enumeration, cycles/joins/SSA cases and record-size check. Not a whole-library Cargo test or whole-library no_std build.'),indent=2)+'\n')
started=time.monotonic()
with (out/'build.stdout.log').open('w') as stdout,(out/'build.stderr.log').open('w') as stderr:completed=subprocess.run(command,stdout=stdout,stderr=stderr)
row=dict(exit_code=completed.returncode,seconds=time.monotonic()-started)
if completed.returncode==0:row['binary_sha256']=hashlib.sha256((out/'tests').read_bytes()).hexdigest()
(out/'build.json').write_text(json.dumps(row,indent=2)+'\n');assert completed.returncode==0
started=time.monotonic()
with (out/'test.stdout.log').open('w') as stdout,(out/'test.stderr.log').open('w') as stderr:completed=subprocess.run([str(out/'tests'),'--nocapture'],stdout=stdout,stderr=stderr)
row=dict(exit_code=completed.returncode,seconds=time.monotonic()-started);(out/'test.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True);raise SystemExit(completed.returncode)
