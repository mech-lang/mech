from pathlib import Path
import hashlib,json,subprocess,time
root=Path('/private/tmp/mech-ssa-chain-roots-20261115');out=root/'ir-comparison';out.mkdir();rows=[json.loads(x) for x in Path('/private/tmp/mech-scoped-route-ranges-current-20261115/candidate-build.jsonl').read_text().splitlines()]
command=['rustc','+nightly-2026-03-03','--edition=2024','--crate-name','ssa_chain_root_ir_comparison','-C','opt-level=3','-C','lto=thin','-C','codegen-units=1','-D','warnings'];directories=set();deps=[]
for name in ['cranelift_codegen','cranelift_frontend','log','serde_json']:
 files=[Path(p) for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']==name for p in r['filenames'] if p.endswith('.rlib')];assert len(files)==1;path=files[0];command+=['--extern',name+'='+str(path)];directories.add(path.parent);deps.append(dict(name=name,path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
for path in sorted(directories):command+=['-L','dependency='+str(path)]
command += [str(root/'ir-comparison.rs'),'-o',str(out/'probe')];(out/'command.json').write_text(json.dumps(dict(command=command,dependencies=deps),indent=2)+'\n');start=time.monotonic()
with (out/'build.stdout.log').open('w') as stdout,(out/'build.stderr.log').open('w') as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr)
row=dict(exit_code=r.returncode,seconds=time.monotonic()-start);(out/'build.json').write_text(json.dumps(row,indent=2)+'\n');print(row,flush=True);assert r.returncode==0
start=time.monotonic()
with (out/'cases.jsonl').open('w') as stdout,(out/'test.stderr.log').open('w') as stderr:r=subprocess.run([str(out/'probe')],stdout=stdout,stderr=stderr)
row=dict(exit_code=r.returncode,seconds=time.monotonic()-start,binary_sha256=hashlib.sha256((out/'probe').read_bytes()).hexdigest());(out/'test.json').write_text(json.dumps(row,indent=2)+'\n');print(row,flush=True);assert r.returncode==0
cases=[json.loads(x) for x in (out/'cases.jsonl').read_text().splitlines()];assert len(cases)==160 and all(x['identical'] for x in cases)
(out/'result.json').write_text(json.dumps(dict(paired_cases=len(cases),verified_functions=2*len(cases),identical_complete_ir_aliases_types_definitions_queries_effects_and_enumerations=True,cases_sha256=hashlib.sha256((out/'cases.jsonl').read_bytes()).hexdigest()),indent=2)+'\n')
