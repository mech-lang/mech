SSA lookup trials on the current Deflate/runtime and scoped-source compiler.
Inline-first storage (base972) and shared predecessor roots (basef195) each
use the same qualified AE control, standard compiler profile,61programflags
and2workers. Decisions, complete source/patches, command logs, focused tests,
all14fixtures, eight primary Object observations and cached full-executable
gates are retained per trial. All raw adverse measurements remain.
Construction of the optimized compiler, focused tests, cached link gates and
archival are excluded from primary timing and never overlap primary cohorts.
All program source/bytecode/Object/complete metadata and gated whole-exe bytes
match. No grammar/language change, weaker proof, scalar retirement or new
program-runtime timing campaign is claimed. Compiler/test executables and
dependency libraries are excluded and hash-pinned; executable program images
and fixed native adapter inputs are included. Source snapshots and unchanged
profile/Variable types are included. Pure replay verifies saved files and
recomputes means/blocks without external paths, compiler or new timing.
