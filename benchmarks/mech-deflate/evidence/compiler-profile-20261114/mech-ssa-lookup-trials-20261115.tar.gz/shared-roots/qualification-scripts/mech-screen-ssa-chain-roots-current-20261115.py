from pathlib import Path
import subprocess, sys, json

root=Path('/private/tmp/mech-ssa-chain-roots-20261115')
rows=[]
for variant in ['control','candidate']:
    command=[sys.executable,'/private/tmp/mech-ssa-chain-roots-20261115/qualification-scripts/mech-run-ssa-chain-roots-current-20261115.py',variant,variant+'-screen']
    completed=subprocess.run(command)
    rows.append(dict(variant=variant,exit_code=completed.returncode,command=command))
    (root/'screen-status.json').write_text(json.dumps(rows,indent=2)+'\n')
    if completed.returncode:raise SystemExit(completed.returncode)
