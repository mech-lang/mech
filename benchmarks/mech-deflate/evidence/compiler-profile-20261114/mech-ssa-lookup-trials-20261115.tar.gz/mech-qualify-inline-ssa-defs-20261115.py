from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
repo=Path.cwd();root=Path('/private/tmp/mech-inline-ssa-defs-20261115');state=json.loads((root/'source-state.json').read_text());scripts=root/'qualification-scripts';source=Path(state['source_path'])
assert source.read_bytes()==(root/'candidate.rs').read_bytes() and subprocess.check_output(['git','diff','--binary','--',state['source_path']])==(root/'candidate.patch').read_bytes()
assert json.loads((root/'candidate-build.json').read_text())['exit_code']==json.loads((root/'focused/test.json').read_text())['exit_code']==0
assert 'test result: ok. 29 passed; 0 failed' in (root/'focused/test.stdout.log').read_text()
pin=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
binary={v:pin(root/v) for v in ['control','candidate']};assert binary['control']['sha256']=='ae517d6c58d4620b999fa43c9138ee804dda85521fffb1611717541545108d01'
assert binary['candidate']['sha256']==json.loads((root/'candidate-build.json').read_text())['binary_sha256']
(root/'qualification.json').write_text(json.dumps(dict(source_base=state['base_commit'],patch_sha256=pin(root/'candidate.patch')['sha256'],compiler=binary,common_compile_threads=2,program_flags_count=61,scope='Private SSA definition storage only: inline the first definition without widening the64-bit record or changing SSA algorithm. Frozen972/newDeflate/newruntime standard control and candidate use the same61flags+2workers. Exact files/current full executable required. Primary cohorts serial without concurrent heavy work. Finish this frozen qualification if remote advances; integrate later.'),indent=2)+'\n')
env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')};records=[]
stages=[('screens','mech-screen-inline-ssa-current-20261115.py'),('executable-gates','mech-cached-native-link-inline-ssa-current-20261115.py'),('fixtures-object-cohort','mech-qualify-inline-ssa-current-20261115.py')]
if '--object-only' not in sys.argv:
    stages.append(('native-cohort','mech-native-cohort-inline-ssa-current-20261115.py'))
for stage,name in stages:
    command=[sys.executable,str(scripts/name)];row=dict(stage=stage,state='running',command=command,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(row);(root/'qualification-pipeline.json').write_text(json.dumps(records,indent=2)+'\n');started=time.monotonic()
    with (root/(stage+'.stdout.log')).open('w') as stdout,(root/(stage+'.stderr.log')).open('w') as stderr:completed=subprocess.run(command,cwd=repo,env=env,stdout=stdout,stderr=stderr)
    row.update(state='complete' if completed.returncode==0 else 'failed',exit_code=completed.returncode,seconds=time.monotonic()-started);(root/'qualification-pipeline.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True);assert completed.returncode==0
