Current compiler parallel requalification on frozen source 12c500108660.
Only scheduling zero/two changes; same immutable c5b0 compiler, 61 program flags,
current source/runtime, fixed cached native adapter and every linker input.
Two excluded complete byte gates precede eight uncontended ABBA/BAAB builds.
All source/MBC/Object/complete metadata and whole executable bytes must match.
Native adapter first use is excluded (11.882560208 seconds in preceding packet).
Two separate current compiler 20sec/5ms stack diagnostics are excluded from all
primary timing. Waiting and inclusive counts are not CPU shares. Original raw
and demangled stacks, symbol mapping, analysis and sample outputs remain.
The setup failure uses a wrong source-proof filename; no compiler executes.
Its original script and traceback remain; corrected driver references the
existing qualification-commit.json. The optional process-list shell command
was denied by the sandbox; no automatic approval review rejection occurred.
The worker implementation is unchanged since source 1090de011646. Compiler and
demangler binaries are excluded and hash-pinned. Native linker inputs, every
complete output/executable, scripts, commands and logs are retained. No source
optimization, new runtime timing or sub-ten-second result is claimed. Pure
replay validates observations and regenerates summaries without compilation.
