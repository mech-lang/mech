from pathlib import Path
import hashlib
import json
import shutil
import subprocess

repo = Path.cwd()
raw = Path('/private/tmp/mech-current-parallel-20261115')
packet = Path('/private/tmp/mech-current-parallel-packet-20261115')
packet.mkdir(exist_ok=False)
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
shutil.copytree(raw, packet / 'parallel')
shutil.copytree('/private/tmp/mech-current-parallel-setup-failure-20261115', packet / 'setup-failure')
for stream in ['stdout', 'stderr']:
    shutil.copy2(Path('/private/tmp/mech-current-parallel-20261115-driver.' + stream + '.log'), packet / ('driver.' + stream + '.log'))
profile = Path('/private/tmp/mech-control-owner-current-profile-20261115')
excluded = {'compiler': json.loads((raw / 'configuration.json').read_text())['compiler']}
for source in profile.rglob('*'):
    if not source.is_file():
        continue
    name = source.relative_to(profile)
    if name.as_posix() == 'demangle':
        excluded['demangler'] = dict(path=str(source), **pin(source))
        continue
    dest = packet / 'profiles' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, dest)
shutil.copy2('/private/tmp/mech-analyze-control-owner-current-profile-20261115.py', packet / 'analyze_profiles.py')
shutil.copy2('/private/tmp/mech-profile-control-owner-current-20261115.py', packet / 'profile.py')
inputs = []
capture = json.loads((raw / 'link-command.json').read_text())
for number, row in enumerate(capture['inputs']):
    source = Path(row['retained_path'])
    assert pin(source) == {k: row[k] for k in ['bytes', 'sha256']}
    name = Path('native-link-inputs') / (str(number) + '-' + source.name)
    dest = packet / name
    dest.parent.mkdir(exist_ok=True)
    shutil.copy2(source, dest)
    inputs.append(dict(source=row['source'], path=name.as_posix(), **pin(dest)))
(packet / 'native-link-inputs.json').write_text(json.dumps(inputs, indent=2) + '\n')
revision = '12c50010866066952345c63223bce770cf7578b1'
worker = '1090de011646c92e30c2d4b648ed0792c50f300d'
paths = subprocess.check_output(['git', 'diff-tree', '--no-commit-id', '--name-only', '-r', worker], text=True).splitlines()
assert len(paths) == 7
pins = []
for name in paths:
    data = subprocess.check_output(['git', 'show', revision + ':' + name])
    assert data == subprocess.check_output(['git', 'show', worker + ':' + name])
    dest = packet / 'worker-source' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    pins.append(dict(path=name, unchanged_since_worker_commit=True, **pin(dest)))
(packet / 'worker-source-pins.json').write_text(json.dumps(pins, indent=2) + '\n')
qualified = Path('/private/tmp/mech-control-schema-owners-20261115')
for name in ['source-state.json', 'qualification-commit.json', 'candidate-build.json', 'candidate-check.json', 'candidate.patch']:
    shutil.copy2(qualified / name, packet / ('retained-' + name))
shutil.copytree(qualified / 'candidate-source', packet / 'retained-source')
shutil.copy2(repo / 'benchmarks/mech-deflate/native-profile/control-schema-owners-apple-m3-20261115.archive.json', packet / 'preceding-source-evidence-receipt.json')
hardware = packet / 'hardware'
hardware.mkdir()
for name in ['cpu.txt', 'cpu-count.txt', 'memory.txt', 'os.txt']:
    shutil.copy2(Path('/private/tmp/mech-current-native-pgo-20261115') / name, hardware / name)
shutil.copytree('/private/tmp/mech-round2-planning-packet-20261114/licenses', packet / 'licenses')
(packet / 'excluded-products.json').write_text(json.dumps(excluded, indent=2) + '\n')
shutil.copy2(__file__, packet / 'curate.py')
shutil.copy2('/private/tmp/mech-replay-current-parallel-20261115.py', packet / 'replay.py')
(packet / 'README.txt').write_text('''Current compiler parallel requalification on frozen source 12c500108660.
Only scheduling zero/two changes; same immutable c5b0 compiler, 61 program flags,
current source/runtime, fixed cached native adapter and every linker input.
Two excluded complete byte gates precede eight uncontended ABBA/BAAB builds.
All source/MBC/Object/complete metadata and whole executable bytes must match.
Native adapter first use is excluded (11.882560208 seconds in preceding packet).
Two separate current compiler 20sec/5ms stack diagnostics are excluded from all
primary timing. Waiting and inclusive counts are not CPU shares. Original raw
and demangled stacks, symbol mapping, analysis and sample outputs remain.
The setup failure uses a wrong source-proof filename; no compiler executes.
Its original script and traceback remain; corrected driver references the
existing qualification-commit.json. The optional process-list shell command
was denied by the sandbox; no automatic approval review rejection occurred.
The worker implementation is unchanged since source 1090de011646. Compiler and
demangler binaries are excluded and hash-pinned. Native linker inputs, every
complete output/executable, scripts, commands and logs are retained. No source
optimization, new runtime timing or sub-ten-second result is claimed. Pure
replay validates observations and regenerates summaries without compilation.
''')
print(packet)
