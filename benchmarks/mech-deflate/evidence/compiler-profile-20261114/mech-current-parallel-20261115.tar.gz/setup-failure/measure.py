from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import statistics
import subprocess
import time

repo = Path.cwd()
root = Path('/private/tmp/mech-current-parallel-20261115')
root.mkdir(exist_ok=False)
qualified = Path('/private/tmp/mech-control-schema-owners-20261115')
binary = qualified / 'candidate'
link = Path('/private/tmp/mech-pr973-refresh-20261115/link')
capture = json.loads((link / 'capture/link-command.json').read_text())
flags = json.loads((qualified / 'runtime-flags.json').read_text())
assert len(flags) == 61
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
assert not any(k.startswith('MIMALLOC_') for k in os.environ)

def pin(path):
    return dict(bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

compiler = dict(path=str(binary), **pin(binary))
assert compiler['sha256'] == 'c5b0b57e2cc870d3e024d2d2c38c9a478122da5f72faf3bbaa3a868cb494a56f'
expected_exe = dict(bytes=2060440,
                    sha256='d6c65cc3fb18acc4be77dce329962105bf0f2b56dd2623a12f466256463eca61')
assert pin(link / 'worker-baseline') == expected_exe
shutil.copytree(qualified / 'reference', root / 'reference')
reference = {name: pin(root / 'reference' / name) for name in
             ['source.mec', 'program.mecb', 'program.o', 'metadata.json']}
shutil.copy2(__file__, root / 'measure.py')
shutil.copy2(link / 'capture/link-command.json', root / 'link-command.json')
shutil.copy2(qualified / 'source-commit-proof.json', root / 'retained-source-commit-proof.json')
order = [('serial', 1), ('parallel', 1), ('parallel', 2), ('serial', 2),
         ('parallel', 3), ('serial', 3), ('serial', 4), ('parallel', 4)]
subjects = {'serial': 0, 'parallel': 2}
config = dict(
    source_commit='12c50010866066952345c63223bce770cf7578b1',
    evidence_head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    compiler=compiler, flags=flags, subjects=subjects, order=order,
    reference=reference, executable=expected_exe,
    started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope='Current retained compiler; only scheduling zero/two differs. Two preliminary byte gates, then eight uncontended ABBA/BAAB complete fresh source-to-executable builds. Fixed runtime/adapter inputs cached and pinned. No concurrent heavy build/test/profile/hash/archive. Hashes and output checks outside timed boundary. No source change, new runtime timing, or sub-ten-second claim.')
(root / 'configuration.json').write_text(json.dumps(config, indent=2) + '\n')

def run(variant, name, primary):
    directory = root / name
    directory.mkdir()
    for item in capture['inputs']:
        if Path(item['source']).name != 'program.o':
            assert pin(Path(item['source'])) == {k: item[k] for k in ['bytes', 'sha256']}
    assert pin(binary)['sha256'] == compiler['sha256']
    env = {k: v for k, v in os.environ.items() if not k.startswith('MECH_')}
    env.update(flags)
    env['MECH_COMPACT_COMPILE_THREADS'] = str(subjects[variant])
    env['ZERO_AR_DATE'] = '1'
    command = [str(binary), 'benchmark', str(directory), 'compact']
    (directory / 'command.json').write_text(json.dumps(dict(
        compile=command, link=capture['command'], compiler=compiler,
        flags={k: v for k, v in env.items() if k.startswith('MECH_')},
        ZERO_AR_DATE='1', input_pins=capture['inputs'], primary_cohort=primary), indent=2) + '\n')
    with (directory / 'compiler.stdout.jsonl').open('w') as stdout, (directory / 'compiler.stderr.log').open('w') as stderr:
        started = time.monotonic()
        completed = subprocess.run(command, cwd=repo, env=env, stdout=stdout, stderr=stderr)
        compiler_completed = time.monotonic()
    assert completed.returncode == 0
    shutil.copy2(directory / 'program.o', link / 'program.o')
    with (directory / 'link.stdout.log').open('w') as stdout, (directory / 'link.stderr.log').open('w') as stderr:
        link_started = time.monotonic()
        linked = subprocess.run(capture['command'], cwd=repo, env=env, stdout=stdout, stderr=stderr)
        finished = time.monotonic()
    assert linked.returncode == 0
    checks = {name: dict(**pin(directory / name), matches_frozen_reference=
                        (directory / name).read_bytes() == (root / 'reference' / name).read_bytes())
              for name in reference}
    shutil.copy2(link / 'worker', directory / 'worker')
    result = dict(name=name, variant=variant, workers=subjects[variant],
                  compiler_exit_code=completed.returncode, link_exit_code=linked.returncode,
                  source_to_executable_seconds=finished - started,
                  source_to_object_process_seconds=compiler_completed - started,
                  object_handoff_seconds=link_started - compiler_completed,
                  native_link_seconds=finished - link_started,
                  files=checks, executable=pin(directory / 'worker'),
                  matches_complete_baseline_executable=(directory / 'worker').read_bytes() == (link / 'worker-baseline').read_bytes(),
                  primary_cohort=primary, cached_adapter_objects=True)
    (directory / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    assert all(row['matches_frozen_reference'] for row in checks.values())
    assert result['matches_complete_baseline_executable'] and result['executable'] == expected_exe
    print(json.dumps(dict(name=name, primary_cohort=primary,
                         seconds=result['source_to_executable_seconds'], all_bytes_match=True)), flush=True)
    return result

gates = [run('serial', 'gate-serial', False), run('parallel', 'gate-parallel', False)]
(root / 'gates.json').write_text(json.dumps(gates, indent=2) + '\n')
records = []
for variant, number in order:
    records.append(run(variant, f'{variant}-{number}', True))
    (root / 'cohort.json').write_text(json.dumps(records, indent=2) + '\n')
fields = ['source_to_executable_seconds', 'source_to_object_process_seconds',
          'object_handoff_seconds', 'native_link_seconds']
summary = {}
for key in fields:
    values = {v: [row[key] for row in records if row['variant'] == v] for v in subjects}
    values['means'] = {v: statistics.mean(values[v]) for v in subjects}
    values['mean_reduction_fraction'] = 1 - values['means']['parallel'] / values['means']['serial']
    summary[key] = values
blocks = []
for rows in [records[:4], records[4:]]:
    means = {v: statistics.mean(row['source_to_executable_seconds'] for row in rows if row['variant'] == v) for v in subjects}
    means['mean_reduction_fraction'] = 1 - means['parallel'] / means['serial']
    blocks.append(means)
result = dict(configuration=config, numerical_summary=summary, balanced_blocks=blocks,
              all_four_outputs_identical=True, all_complete_executables_identical=True)
(root / 'numerical-summary.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(means=summary['source_to_executable_seconds']['means'], blocks=blocks)), flush=True)
