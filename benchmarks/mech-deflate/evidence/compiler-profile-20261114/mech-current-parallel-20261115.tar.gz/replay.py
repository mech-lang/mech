from pathlib import Path
import hashlib
import json
import statistics
import subprocess
import sys

packet = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_text())
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
root = packet / 'parallel'
config = read(root / 'configuration.json')
assert config['source_commit'] == '12c50010866066952345c63223bce770cf7578b1'
assert config['compiler'] == read(packet / 'excluded-products.json')['compiler']
assert config['compiler']['sha256'] == 'c5b0b57e2cc870d3e024d2d2c38c9a478122da5f72faf3bbaa3a868cb494a56f'
assert len(config['flags']) == 61 and config['subjects'] == dict(serial=0, parallel=2)
assert read(packet / 'retained-qualification-commit.json')['entire_commit_diff_matches_measured_patch']
assert pin(packet / 'retained-candidate.patch')['sha256'] == '320944e9ee9f5509a1379d5ae3eeb4921af47598a9034ce1201c62999f41ea46'
assert read(packet / 'retained-candidate-build.json')['binary_sha256'] == config['compiler']['sha256']
assert 'FileNotFoundError' in (packet / 'setup-failure/driver.stderr.log').read_text()
assert not (packet / 'setup-failure/configuration.json').exists()
for row in read(packet / 'worker-source-pins.json'):
    assert row['unchanged_since_worker_commit'] and pin(packet / 'worker-source' / row['path']) == {k: row[k] for k in ['bytes', 'sha256']}
inputs = read(packet / 'native-link-inputs.json')
capture = read(root / 'link-command.json')
assert [(r['source'], r['bytes'], r['sha256']) for r in inputs] == [(r['source'], r['bytes'], r['sha256']) for r in capture['inputs']]
for row in inputs:
    assert pin(packet / row['path']) == {k: row[k] for k in ['bytes', 'sha256']}
reference = config['reference']
for name, item in reference.items():
    assert pin(root / 'reference' / name) == item
gates = read(root / 'gates.json')
records = read(root / 'cohort.json')
assert len(gates) == 2 and len(records) == 8
assert [(r['variant'], int(r['name'].rsplit('-', 1)[1])) for r in records] == [tuple(r) for r in config['order']]
internal = []
for row in gates + records:
    directory = root / row['name']
    assert read(directory / 'result.json') == row
    assert row['compiler_exit_code'] == row['link_exit_code'] == 0
    assert row['workers'] == config['subjects'][row['variant']]
    assert row['cached_adapter_objects'] and row['primary_cohort'] == (row in records)
    command = read(directory / 'command.json')
    assert command['compiler'] == config['compiler'] and command['link'] == capture['command']
    assert command['flags'] == dict(config['flags'], MECH_COMPACT_COMPILE_THREADS=str(row['workers']))
    assert command['input_pins'] == capture['inputs'] and command['ZERO_AR_DATE'] == '1'
    for name, item in reference.items():
        assert pin(directory / name) == item and row['files'][name] == dict(item, matches_frozen_reference=True)
        assert (directory / name).read_bytes() == (root / 'reference' / name).read_bytes()
    assert row['executable'] == config['executable'] == pin(directory / 'worker')
    assert row['matches_complete_baseline_executable']
    assert abs(row['source_to_executable_seconds'] - sum(row[k] for k in ['source_to_object_process_seconds', 'object_handoff_seconds', 'native_link_seconds'])) < 1e-8
    receipt = read(directory / 'compile.json')
    assert receipt['total_seconds'] < row['source_to_object_process_seconds']
    if row in records:
        internal.append(dict(name=row['name'], variant=row['variant'], compile=receipt))
summary = {}
for key in ['source_to_executable_seconds', 'source_to_object_process_seconds', 'object_handoff_seconds', 'native_link_seconds']:
    values = {v: [row[key] for row in records if row['variant'] == v] for v in config['subjects']}
    values['means'] = {v: statistics.mean(values[v]) for v in config['subjects']}
    values['mean_reduction_fraction'] = 1 - values['means']['parallel'] / values['means']['serial']
    summary[key] = values
blocks = []
for rows in [records[:4], records[4:]]:
    means = {v: statistics.mean(row['source_to_executable_seconds'] for row in rows if row['variant'] == v) for v in config['subjects']}
    means['mean_reduction_fraction'] = 1 - means['parallel'] / means['serial']
    blocks.append(means)
saved = dict(configuration=config, numerical_summary=summary, balanced_blocks=blocks,
             all_four_outputs_identical=True, all_complete_executables_identical=True)
assert read(root / 'numerical-summary.json') == saved
phases = {}
for phase in ['total', 'parse', 'catalog', 'frontend', 'native', 'artifact', 'encode']:
    values = {v: [r['compile']['total_seconds'] if phase == 'total' else next(x['seconds'] for x in r['compile']['phases'] if x['phase'] == phase) for r in internal if r['variant'] == v] for v in config['subjects']}
    values['means'] = {v: statistics.mean(values[v]) for v in config['subjects']}
    values['mean_reduction_fraction'] = 1 - values['means']['parallel'] / values['means']['serial']
    phases[phase + '_seconds'] = values
profile = packet / 'profiles'
profile_config = read(profile / 'configuration.json')
assert profile_config['source_commit'] == config['source_commit'] and profile_config['compiler'] == config['compiler']
profiles = read(profile / 'results.json')
assert len(profiles) == 2
for row in profiles:
    directory = profile / row['name']
    assert row['excluded_from_primary'] and row['all_outputs_match']
    assert row['process'] == read(directory / 'process.json')
    assert row['process']['exit_code'] == 0 and row['process']['samples'] == 1 and row['process']['sampling_error'] is None
    for name, item in reference.items():
        assert pin(directory / name) == item and (directory / name).read_bytes() == (root / 'reference' / name).read_bytes()
    assert pin(profile / (row['name'] + '-link') / 'worker') == config['executable']
subprocess.run([sys.executable, str(packet / 'analyze_profiles.py'), str(profile)], check=True, stdout=subprocess.PIPE)
result = dict(source_commit=config['source_commit'], compiler=config['compiler'],
              configuration=config, numerical_summary=summary, balanced_blocks=blocks,
              internal_phase_summary=phases, output_hashes=reference,
              final_executable=config['executable'], primary_builds=8,
              excluded_preliminary_gates=gates, excluded_profiles=profiles,
              all_four_outputs_identical=True, all_complete_executables_identical=True,
              setup_failures=[dict(stage='source-proof filename before compiler execution', corrected=True)],
              scope='Current unchanged compiler scheduling comparison; primary complete fresh source-to-executable boundary with cached pinned runtime/adapter. No exclusive CPU-share or new runtime-speed claim. Default remains serial. All observations retained; no sub-ten-second result.')
encoded = json.dumps(result, indent=2, sort_keys=True) + '\n'
saved = packet / 'summary.json'
if saved.exists():
    assert saved.read_text() == encoded
else:
    saved.write_text(encoded)
print(encoded, end='')
