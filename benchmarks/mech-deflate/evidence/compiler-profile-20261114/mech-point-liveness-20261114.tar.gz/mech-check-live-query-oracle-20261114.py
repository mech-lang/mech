from pathlib import Path
import json,time,hashlib,sys
root=Path('/private/tmp/mech-live-query-profile-20261114');sys.path.insert(0,str(root));from oracle import live_before
manifest=json.loads((root/'graph-manifest.json').read_text());records=[];start=time.perf_counter()
for row in manifest['graphs']:
 path=root/row['path'];data=path.read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'];next,reads,defs,entry,expected=json.loads(data);actual=live_before(next,reads,defs,entry);assert actual==expected,row['query'];records.append({'query':row['query'],'exact_expected':True,'live_values':len(actual)})
 if len(records)%100==0:print('CHECKED',len(records),flush=True)
(root/'oracle-results.json').write_text(json.dumps({'graphs':len(records),'seconds_outside_primary':time.perf_counter()-start,'all_exact':True,'oracle_source_sha256':hashlib.sha256((root/'oracle.py').read_bytes()).hexdigest(),'scope':'Independent full-bitset worklist propagation over original captured graphs; no bounded per-value search, compiler execution or benchmark timing.','results':records},indent=2)+'\n');print('PASS',len(records),'original query results independently re-solved',flush=True)
