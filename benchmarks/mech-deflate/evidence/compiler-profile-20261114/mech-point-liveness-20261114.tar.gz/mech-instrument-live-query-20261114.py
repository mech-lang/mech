from pathlib import Path
import json,hashlib,subprocess
repo=Path.cwd();root=Path('/private/tmp/mech-live-query-profile-20261114');name='hosts/gpu/src/native_artifact/program/prepare/numeric_exits.rs';source=subprocess.check_output(['git','show','HEAD:'+name],text=True);p=source
needle='''    // Query-local ordinals replace per-node source-ID tree allocations. Each
'''
assert p.count(needle)==1
p=p.replace(needle,'''    let profile_mode = std::env::var("MECH_PROFILE_EXIT_LIVENESS").ok();
    let profiling = profile_mode.is_some();
    let detailed = profile_mode.as_deref() == Some("detail");
    let profile_started = profiling.then(std::time::Instant::now);
    let mut action_read_ns = 0u128;
    let mut edge_condition_ns = 0u128;
    static QUERY: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
    let query = profiling.then(|| QUERY.fetch_add(1, std::sync::atomic::Ordering::Relaxed));
'''+needle)
needle='''        let mut used = BTreeSet::new();''';assert p.count(needle)==1;p=p.replace(needle,'''        let read_started = detailed.then(std::time::Instant::now);
'''+needle)
needle='''        let mut successors = if site == tail.latch() as usize || site == tail.finish() as usize {''';assert p.count(needle)==1;p=p.replace(needle,'''        if let Some(started) = read_started {
            action_read_ns += started.elapsed().as_nanos();
        }
        let edge_started = detailed.then(std::time::Instant::now);
'''+needle)
needle='''        pending.extend(&successors);''';assert p.count(needle)==1;p=p.replace(needle,'''        if let Some(started) = edge_started {
            edge_condition_ns += started.elapsed().as_nanos();
        }
'''+needle)
needle='''    let definitions = definitions::selected(facts, &ordinals, &reads, wanted)?;''';assert p.count(needle)==1;p=p.replace(needle,'''    let graph_done = profiling.then(std::time::Instant::now);
'''+needle+'''
    let definitions_done = profiling.then(std::time::Instant::now);''')
needle='''    Ok(liveness::live_before_indexed(&next, &reads, &definitions, ordinals[start]))''';assert p.count(needle)==1;p=p.replace(needle,'''    let reindex_done = profiling.then(std::time::Instant::now);
    let live = liveness::live_before_indexed(&next, &reads, &definitions, ordinals[start]);
    let solver_done = profiling.then(std::time::Instant::now);
    if let Some(started) = profile_started {
        let graph_done = graph_done.unwrap();
        let definitions_done = definitions_done.unwrap();
        let reindex_done = reindex_done.unwrap();
        let solver_done = solver_done.unwrap();
        let nodes = next.len();
        let edges = next.iter().map(Vec::len).sum::<usize>();
        let mut read_histogram = [0usize; 6];
        let mut read_occurrences = 0usize;
        for used in &reads {
            read_histogram[used.len().min(5)] += 1;
            read_occurrences += used.len();
        }
        let definition_occurrences = definitions.iter().map(Vec::len).sum::<usize>();
        let drop_started = std::time::Instant::now();
        drop(definitions);
        drop(pending);
        drop(reads);
        drop(next);
        drop(ordinals);
        let drop_seconds = drop_started.elapsed().as_secs_f64();
        eprintln!("exit-liveness-profile: {}", serde_json::json!({
            "query": query.unwrap(), "mode": profile_mode, "start": start,
            "root": tail.header(), "latch": tail.latch(), "finish": tail.finish(),
            "plan_blocks": plan.blocks().len(), "plan_values": plan.values().len(),
            "known_predicates": known.len(), "wanted": wanted.map(BTreeSet::len),
            "nodes": nodes, "edges": edges, "read_occurrences": read_occurrences,
            "read_histogram_0_1_2_3_4_5plus": read_histogram,
            "definition_occurrences": definition_occurrences, "live_values": live.len(),
            "graph_read_seconds": (graph_done - started).as_secs_f64(),
            "definition_seconds": (definitions_done - graph_done).as_secs_f64(),
            "reindex_seconds": (reindex_done - definitions_done).as_secs_f64(),
            "solver_seconds": (solver_done - reindex_done).as_secs_f64(),
            "core_seconds": (solver_done - started).as_secs_f64(),
            "drop_seconds": drop_seconds,
            "action_read_seconds": action_read_ns as f64 / 1e9,
            "edge_condition_seconds": edge_condition_ns as f64 / 1e9
        }));
    }
    Ok(live)''')
(root/'instrumented-numeric-exits.rs').write_text(p);(root/'instrumentation-plan.json').write_text(json.dumps({'file':name,'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'original_sha256':hashlib.sha256(source.encode()).hexdigest(),'instrumented_unformatted_sha256':hashlib.sha256(p.encode()).hexdigest(),'modes':{'summary':'Four query-stage clocks plus cleanup; no per-node clock. Post-core statistics and log formatting are outside core timings.','detail':'Adds per-node clocks around action-read construction and edge/condition processing. Timer overhead is disclosed; no detailed-profile time qualifies a performance change.'},'scope':'Diagnostic only; preserve outputs against the fresh 61-flag baseline; no execution/runtime shortcut. Drop order matches the ordinary owned temporaries. All profiling work excluded from primary timing cohorts.'},indent=2)+'\n');print(root/'instrumented-numeric-exits.rs')
