Bounded exact exit liveness at the requested start, Apple M3, 2026-11-14.
Retained source and measured patch are pinned in source-state.json. The source
commit matches the exact tested/measured patch. A fresh current 61-flag baseline
is separate from all historical 60-flag cohorts. Eight serial matched complete
compiles preserve every source/MBC/Object/metadata byte and lower time and
instructions; compiler RSS increases 1.93%. Both balanced blocks improve.
The original solver's 790 graph inputs and full expected results, two diagnostic
profiles, both complete kernel experiment streams, independent Python oracle,
production source/tests, all build commands and the failed short-link attempt
remain. Compiler/probe executables are excluded and hash-pinned; interpreter
caches are omitted. Normal compiler-profile Thin LTO is used for qualification.
No profiling/capture code is retained and no runtime execution machinery changes.
Pure offline replay checks the source patches, full cohort, outputs, tests,
profiles, raw kernel data and independently re-solves all graph inputs without
compilers, benchmark execution, original scratch paths or network. It does not
rerun the timing measurements. See report.md and summary.json.
The sub-ten-second complete-compilation goal remains open.
