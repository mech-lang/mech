from pathlib import Path
import json,hashlib,re,statistics,tomllib,math,importlib.util,sys
sys.dont_write_bytecode=True
root=Path(__file__).resolve().parent;raw=root/'compiler'
read=lambda p:json.loads(p.read_text())
def pin(p):
 data=p.read_bytes();return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
state=read(root/'source-state.json');build=read(raw/'candidate-build.json');control=read(raw/'control-origin.json');control_build=read(raw/'control-build.json');flags=read(raw/'runtime-flags.json');expected=read(raw/'reference-pins.json')
assert state['production_changes_retained'] and state['git_commit_patch_byte_identical_to_measured_patch'];assert len(flags)==61 and flags['MECH_COMPACT_REUSE_OVERWRITTEN_RESULT']=='1'
assert build['exit_code']==control_build['exit_code']==0 and build['head']==control_build['head']==state['base_commit']==control['source_commit'] and control['sha256']==control_build['binary_sha256']
assert pin(root/'source-change.patch')==pin(raw/'candidate.patch')==pin(raw/'candidate-tested.patch') and pin(raw/'candidate.patch')['sha256']==state['patch_sha256']==build['patch_sha256']
assert (raw/'control.patch').read_bytes()==b''
excluded={r['path']:r for r in read(root/'excluded-executables.json')}
for variant,record in [('control',control_build),('candidate',build),('instrumented',read(raw/'instrumented-build.json')),('graph-dump',read(raw/'graph-dump-build.json'))]:
 assert record['exit_code']==0 and excluded['compiler/'+variant]['sha256']==record['binary_sha256'];assert record['command'][record['command'].index('--profile')+1]=='compiler' and '--release' not in record['command']
profile_settings={}
for name in ['Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.toml']:
 before=tomllib.loads((root/'source-base'/name).read_text());after=tomllib.loads((root/'source'/name).read_text());assert before['profile']==after['profile'];profile_settings[name]=after['profile']['compiler']
stage_fields=[('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]
host_fields=[('max_rss_bytes',r'(\d+)  maximum resident set size'),('instructions',r'(\d+)  instructions retired'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]
order=['control-1','candidate-1','candidate-2','control-2','candidate-3','control-3','control-4','candidate-4']
def validate_cohort(raw,flags,expected,pins,key):
 rows=read(raw/'cohort.json');assert [r['name'] for r in rows]==order
 for name in ['control-screen','candidate-screen',*order]:
  variant=name.split('-')[0];d=raw/name;process=read(d/'process.json');assert process['exit_code']==0 and process['samples']==0 and process['sampling_error'] is None
  command=read(raw/(name+'-command.json'));assert command['flags']==flags and command['binary_sha256']==pins[variant]
  for filename,pinned in expected.items():assert pin(d/filename)==pinned and read(d/'output-check.json')[filename]==dict(pinned,**{key:True})
 for row in rows:
  d=raw/row['name'];assert row['compile']==read(d/'compile.json') and row['process']==read(d/'process.json') and row['files']==read(d/'output-check.json')
  assert row['variant']==row['name'].split('-')[0]
  stamps=[json.loads(line) for line in (d/'stages.jsonl').read_text().splitlines()]
  for field,begin,end in stage_fields:assert row[field]==next(s['elapsed'] for s in stamps if s['line'].startswith(end))-next(s['elapsed'] for s in stamps if s['line'].startswith(begin))
  for field,pattern in host_fields:assert row[field]==int(re.search(pattern,(d/'stderr.log').read_text()).group(1))
  if True:
   begin=next(s for s in stamps if s['line'].startswith('compact-stage: compact values before='));end=next(s for s in stamps if s['line'].startswith('compact-stage: CFG cleanup'));assert row['compaction_seconds']==end['elapsed']-begin['elapsed'];assert row['value_ids_before']==int(begin['line'].split('=')[-1])==20798230;assert row['value_ids_after']==int(next(s['line'] for s in stamps if s['line'].startswith('compact-values: retained=')).split('=')[-1])==1242559
  else:assert row['compaction_seconds']==0
  assert row['cleanup_including_compaction_seconds']==row['cleanup_seconds']+row['compaction_seconds']
 fixtures=read(raw/'fixture-results.json');assert len(fixtures)==14
 for record in fixtures:
  assert record['all_outputs_match'] and record['variants']['control']==record['variants']['candidate'] and record['variants']['control']['exit_code']==0 and len(record['variants']['control']['files'])==4
  name=Path(record['fixture']).stem if ':' not in record['fixture'] else record['fixture'].split(':')[-1]
  for variant,result in record['variants'].items():
   d=raw/'fixtures'/name/variant;command=read(d/'command.json');assert command['flags']==flags and command['binary_sha256']==pins[variant]
   for filename,pinned in result['files'].items():assert pin(d/filename)==pinned
   assert result['files']['source.mec']['sha256']==record['source_sha256']
 base=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase.mec').read_text();fragment=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase-states.mec').read_text();assembled=base.replace('+> sequence\n','+> sequence\n'+fragment+'\n',1).replace('phase-candidates(values, 1u64, 0u64, permitted, divisor)','#PhaseCandidates(values, permitted, divisor, 1u64, 0u64)',1);assert assembled==(raw/'fixture-inputs/numeric-nested-phase-states.mec').read_text()
 fields={'compiler_seconds':lambda r:r['compile']['total_seconds'],'whole_process_seconds':lambda r:r['process']['elapsed_seconds']}
 for phase in ['parse','catalog','frontend','artifact','encode','native']:fields[phase+'_seconds']=lambda r,p=phase:next(v['seconds'] for v in r['compile']['phases'] if v['phase']==p)
 for field in [f[0] for f in stage_fields]+['cleanup_including_compaction_seconds','compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:fields[field]=lambda r,k=field:r[k]
 qualified={field:{v:[fn(r) for r in rows if r['variant']==v] for v in ['control','candidate']} for field,fn in fields.items()}
 for values in qualified.values():
  mean=statistics.mean(values['control']);values['mean_reduction_fraction']=1-statistics.mean(values['candidate'])/mean if mean else None
 assert qualified==read(raw/'numerical-summary.json')
 blocks=[]
 for block in [rows[:4],rows[4:]]:
  blocks.append(dict(order=[r['name'] for r in block],compiler_mean_reduction_fraction=1-statistics.mean(r['compile']['total_seconds'] for r in block if r['variant']=='candidate')/statistics.mean(r['compile']['total_seconds'] for r in block if r['variant']=='control')))
 return dict(flags_count=len(flags),qualified=qualified,blocks=blocks,output_hashes=expected,compiler_binary_sha256=pins,fixture_output_comparisons=fixtures)


def apply_patch(base,patch):
 lines=base.splitlines(keepends=True);out=[];cursor=0;diff=patch.splitlines(keepends=True);i=0
 while i<len(diff):
  match=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',diff[i])
  if not match:i+=1;continue
  at=max(0,int(match[1])-1);assert at>=cursor;out.extend(lines[cursor:at]);cursor=at;old_count=new_count=0;i+=1
  while i<len(diff) and not diff[i].startswith('@@ '):
   line=diff[i];tag=line[:1];assert tag in [' ','+','-']
   if tag in [' ','-']:assert lines[cursor]==line[1:];cursor+=1;old_count+=1
   if tag in [' ','+']:out.append(line[1:]);new_count+=1
   i+=1
  assert old_count==int(match[2] or 1) and new_count==int(match[4] or 1)
 out.extend(lines[cursor:]);return ''.join(out)
sections=(root/'source-change.patch').read_text().split('diff --git ')[1:];assert len(sections)==3
for section in sections:
 m=re.match(r'a/(\S+) b/(\S+)\n',section);assert m and m[1]==m[2];name=m[1];p=root/'source-base'/name;original=p.read_text() if p.exists() else '';candidate=(root/'source'/name).read_text();assert apply_patch(original,section)==candidate==(raw/'source-candidate'/name).read_text()
for name in ['hosts/gpu/src/native_artifact/program/prepare/numeric_exits.rs','hosts/gpu/src/native_artifact/program/prepare/numeric_exit_definitions.rs','hosts/gpu/src/native_artifact/program/packed_liveness.rs','src/engine/src/native_artifact/program_facts.rs']:
 assert (root/'source-base'/name).read_bytes()==(root/'source'/name).read_bytes()
name='hosts/gpu/src/native_artifact/program/prepare/numeric_liveness.rs';old=(root/'source-base'/name).read_text();new=(root/'source'/name).read_text();normalized=new.replace('#[path = "numeric_point_liveness.rs"]\nmod point;\n\n','');begin=normalized.index('    // On broad graphs with sparse reads');finish=normalized.index('    if let Some(live) = dense_live_before_indexed',begin);normalized=normalized[:begin]+normalized[finish:];assert normalized==old
trial=(raw/'point_liveness_trial.rs').read_text();actual=(root/'source/hosts/gpu/src/native_artifact/program/prepare/numeric_point_liveness.rs').read_text();trial=trial[trial.index('fn solve('):];actual=actual[actual.index('fn solve('):actual.index('\n#[cfg(test)]')];assert ''.join(trial.split())==''.join(actual.split());proof=read(raw/'candidate-source-equivalence.json');assert hashlib.sha256(''.join(actual.split()).encode()).hexdigest()==proof['function_normalized_sha256'] and proof['patch_sha256']==build['patch_sha256']
assert read(raw/'candidate-test-build.json')['exit_code']==read(raw/'candidate-tests.json')['exit_code']==0 and read(raw/'candidate-test-build.json')['patch_sha256']==build['patch_sha256'];assert 'test result: ok. 16 passed; 0 failed;' in (raw/'candidate-tests.stdout').read_text()
assert read(raw/'point-tests.json')['exit_code']==0 and 'test result: ok. 15 passed; 0 failed;' in (raw/'point-tests.stdout').read_text()
failed=read(raw/'graph-dump-no-lto-build.json');assert failed['exit_code']==101 and 'lto=off' in failed['command'];assert pin(raw/'graph-dump-no-lto.patch')==pin(raw/'graph-dump.patch')
errors=[json.loads(line) for line in (raw/'graph-dump-no-lto-build.jsonl').read_text().splitlines() if json.loads(line).get('reason')=='compiler-message'];assert any('could not parse bitcode object file' in r['message'].get('rendered','') for r in errors)
for variant,folder in [('instrumented','source-instrumented'),('graph-dump','source-graph-dump')]:
 record=read(raw/(variant+'-build.json'));assert pin(raw/(variant+'.patch'))['sha256']==record['patch_sha256'];sections=(raw/(variant+'.patch')).read_text().split('diff --git ')[1:];assert len(sections)==1;name='hosts/gpu/src/native_artifact/program/prepare/numeric_exits.rs';assert apply_patch((root/'source-base'/name).read_text(),sections[0])==(raw/folder/name).read_text()
qualification=validate_cohort(raw,flags,expected,{'control':control['sha256'],'candidate':build['binary_sha256']},'matches_current_control_output')
for name in ['control-baseline-1','control-baseline-2','instrumented-summary','instrumented-detail','graph-capture']:
 d=raw/name;assert read(d/'process.json')['exit_code']==0 and read(d/'process.json')['samples']==0
 for filename,pinned in expected.items():assert pin(d/filename)==pinned and read(d/'output-check.json')[filename]==dict(pinned,matches_current_control_output=True)
time_fields=['graph_read_seconds','definition_seconds','reindex_seconds','solver_seconds','drop_seconds','core_seconds','action_read_seconds','edge_condition_seconds'];profiles=read(raw/'profile-analysis.json');structural=[]
for mode in ['summary','detail']:
 rows=read(raw/('instrumented-'+mode)/'liveness-profiles.json');assert len(rows)==790 and [r['query'] for r in rows]==list(range(790));s=profiles['profiles'][mode];assert s['queries']==790
 for field in time_fields:assert s['totals'][field]==sum(r[field] for r in rows)
 for field,result in [('nodes','visited_nodes'),('edges','edges'),('read_occurrences','read_occurrences'),('definition_occurrences','definition_occurrences')]:assert s[result]==sum(r[field] for r in rows)
 histogram=[sum(r['read_histogram_0_1_2_3_4_5plus'][i] for r in rows) for i in range(6)];assert s['read_histogram_0_1_2_3_4_5plus']==histogram and s['nonempty_read_sets']==sum(histogram[1:])
 assert s['wanted_queries']==sum(r['wanted'] is not None for r in rows) and s['known_predicate_queries']==sum(r['known_predicates']!=0 for r in rows)
 for r in rows:assert r['mode']==mode and r['nodes']==sum(r['read_histogram_0_1_2_3_4_5plus']) and math.isclose(r['core_seconds'],sum(r[k] for k in ['graph_read_seconds','definition_seconds','reindex_seconds','solver_seconds']),rel_tol=1e-12,abs_tol=1e-10)
 structural.append([{k:v for k,v in r.items() if k not in time_fields+['mode']} for r in rows]);assert s['top_queries']==sorted(rows,key=lambda r:r['core_seconds']+r['drop_seconds'],reverse=True)[:20]
 command=read(raw/('instrumented-'+mode+'-command.json'));assert command['flags']==dict(flags,MECH_PROFILE_EXIT_LIVENESS=mode) and command['binary_sha256']==excluded['compiler/instrumented']['sha256']
assert structural[0]==structural[1] and profiles['summary_and_detail_structural_counts_identical']
last='';query_stages=[]
for line in (raw/'instrumented-summary/stages.jsonl').read_text().splitlines():
 r=json.loads(line)
 if r['line'].startswith('compact-stage: '):last=r['line']
 if r['line'].startswith('exit-liveness-profile: '):query_stages.append(last)
assert len(query_stages)==790 and all(s=='compact-stage: preparation blocks=41039 values=22460' for s in query_stages)
manifest=read(raw/'graph-manifest.json');assert manifest['queries']==790 and manifest['source_commit']==state['base_commit'];spec=importlib.util.spec_from_file_location('point_liveness_independent_oracle',raw/'oracle.py');oracle=importlib.util.module_from_spec(spec);spec.loader.exec_module(oracle);assert pin(raw/'oracle.py')['sha256']==read(raw/'oracle-results.json')['oracle_source_sha256'];assert read(raw/'oracle-results.json')['all_exact']
shapes=[];bytes_total=0;eligible=set()
for index,row in enumerate(manifest['graphs']):
 assert row['query']==index and pin(raw/row['path'])=={k:row[k] for k in ['bytes','sha256']};next,reads,definitions,start,live=read(raw/row['path']);assert len(next)==len(reads)==len(definitions)==row['nodes'] and sum(map(len,next))==row['edges'] and sum(map(len,reads))==row['reads'] and sum(map(len,definitions))==row['definitions'] and len(live)==row['live_values'] and start==0
 for values in reads+definitions+[live]:assert values==sorted(set(values))
 assert oracle.live_before(next,reads,definitions,start)==live,index
 expected_shape=structural[0][index];assert expected_shape['nodes']==len(next) and expected_shape['edges']==row['edges'] and expected_shape['read_occurrences']==row['reads'] and expected_shape['definition_occurrences']==row['definitions'] and expected_shape['live_values']==len(live)
 shapes.append((len(next),row['reads'],len(live)));bytes_total+=row['bytes']
 if len(next)>=1024 and row['reads']<=len(next):eligible.add(index)
assert bytes_total==manifest['bytes']==176143814 and len(eligible)==299
kernel={}
for name,factors,gated in [('point-bench',[0,1,4,16],False),('point-bench-gated',[0,16,64,256],True)]:
 assert read(raw/(name+'-build.json'))['exit_code']==read(raw/(name+'-run.json'))['exit_code']==0;assert excluded['compiler/'+name]['sha256']==read(raw/(name+'-build.json'))['binary_sha256'];rows=[json.loads(line) for line in (raw/(name+'-observations.jsonl')).read_text().splitlines()];assert len(rows)==790*2*4 and {(r['query'],r['repeat'],r['factor']) for r in rows}=={(q,i,f) for q in range(790) for i in range(2) for f in factors}
 result={}
 for r in rows:
  n,reads,live=shapes[r['query']];assert r['nodes']==n and r['read_occurrences']==reads and r['live_values']==live and r['exact_expected'] and r['budget']==min(n*r['factor'],16777216) and r['steps']<=r['budget']
  if gated:assert r['attempted']==bool(r['factor'] and r['query'] in eligible)
 for factor in factors:
  part=[r for r in rows if r['factor']==factor]
  if gated:q=dict(observations=len(part),seconds=sum(r['seconds'] for r in part),attempts=sum(r['attempted'] for r in part),successes=sum(r['point_succeeded'] for r in part),fallbacks=sum(r['attempted'] and not r['point_succeeded'] for r in part),steps=sum(r['steps'] for r in part),per_repeat=[sum(r['seconds'] for r in part if r['repeat']==i) for i in [0,1]])
  else:q=dict(observations=len(part),seconds=sum(r['seconds'] for r in part),point_successes=sum(r['point_succeeded'] for r in part),fallbacks=sum(not r['point_succeeded'] for r in part) if factor else None,steps=sum(r['steps'] for r in part),per_repeat=[sum(r['seconds'] for r in part if r['repeat']==i) for i in [0,1]])
  result[str(factor)]=q
 assert result==read(raw/(name+'-summary.json'));kernel[name]=result
assert kernel['point-bench-gated']['64']['successes']==598 and kernel['point-bench-gated']['64']['fallbacks']==0
assert all(b['compiler_mean_reduction_fraction']>0 for b in qualification['blocks']);assert qualification['qualified']['compiler_seconds']['mean_reduction_fraction']>0 and qualification['qualified']['instructions']['mean_reduction_fraction']>0 and qualification['qualified']['max_rss_bytes']['mean_reduction_fraction']<0
summary=dict(source_commit=state['source_commit'],base_commit=state['base_commit'],control_source_commit=state['control_source_commit'],hardware=state['hardware'],decision=read(raw/'decision.json'),candidate_patch_sha256=state['patch_sha256'],profile_settings=profile_settings,candidate_rebuild_seconds=build['seconds'],control_rebuild_seconds=control_build['seconds'],focused_tests_passed=16,diagnostic_profiles=profiles,kernel_experiments=kernel,graph_oracle={'graphs':790,'bytes':bytes_total,'all_exact':True,'eligible_for_point_search':299,'oracle_source_sha256':pin(raw/'oracle.py')['sha256']},scope=[
 'Fresh current 61-flag control; eight serial ABBA/BAAB complete source-to-Object observations. Historical 60-flag cohorts and separate screens/baseline observations are not pooled. Both compiler-time blocks improve; every program and fixture byte matches.',
 'Builds, tests, profiling, capture, kernel/oracle work, copying, hashing and archive work do not overlap primary compiles. Candidate bootstrap overlaps the separate offline oracle; bootstrap numbers use existing caches and are not isolated matched or cold-bootstrap comparisons.',
 'The caller still constructs and validates each entire exact graph, predicate context and definition inventory in the original order. Only the pure solution is changed. Broad sparse-read graphs try a bounded reverse search at the requested start; original packed/sparse fallback remains.',
 'All 790 original query inputs and expected results are captured and independently re-solved with a different full-bitset worklist. All 12640 kernel observations assert exact results; prototype search matches production body. Eligibility scans are outside kernel timers but included in complete compiler timings.',
 'Temporary diagnostic/capture code is not retained. Summary and detail profiles preserve graph/result cardinalities and every output byte. Detail clocks add substantial overhead and do not qualify a performance change. Failed no-LTO capture link is preserved; qualification uses ordinary optimized compiler-profile Thin LTO.',
 'Maximum compiler RSS and footprint increase; all adverse phases and every observation remain. No isolated cause is assigned to memory/unrelated-stage movement. No new compressor-runtime latency campaign is claimed: Object and complete metadata are identical. No scalar execution machinery is retired.',
 'Grammar, language, checked errors, direct scalar emission, fresh shape/factory/visit/ownership checks, finite admission, accounting and backend settings remain. Full compilation remains above ten seconds. Pure replay checks stored data and independent graph results; it does not rerun timings.'
],**qualification)
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
