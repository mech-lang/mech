from pathlib import Path
import subprocess,json,hashlib,shutil
repo=Path.cwd();raw=Path('/private/tmp/mech-live-query-profile-20261114');packet=Path('/private/tmp/mech-point-liveness-packet-20261114');assert not packet.exists();retained=json.loads((raw/'retained-source.json').read_text());base=retained['base_commit'];source=retained['source_commit'];assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
assert subprocess.check_output(['git','diff','HEAD','--','src','hosts','vendor','machines','Cargo.toml','Cargo.lock','.cargo/config.toml'])==b''
assert subprocess.check_output(['git','diff',base,source,'--binary'])==(raw/'candidate.patch').read_bytes()
executables={'control','instrumented','graph-dump','candidate','point-tests','point-bench','point-bench-gated','candidate-numeric-tests'};excluded=[]
for p in sorted(raw.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(raw)
 if '__pycache__' in rel.parts:continue
 dest=Path('compiler')/rel
 if rel.as_posix() in executables:
  excluded.append({'path':dest.as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()});continue
 d=packet/dest;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
state={**retained,'control_source_commit':base,'patch_sha256':retained['measured_patch_sha256'],'hardware':'Apple M3 Air, 8 cores (4P+4E), 16 GB, macOS 26.2','flags_count':61,'rustc':subprocess.check_output(['rustc','-Vv'],text=True),'cargo':subprocess.check_output(['cargo','-V'],text=True)};(packet/'source-state.json').write_text(json.dumps(state,indent=2,sort_keys=True)+'\n');(packet/'excluded-executables.json').write_text(json.dumps(excluded,indent=2)+'\n');shutil.copy2(raw/'candidate.patch',packet/'source-change.patch')
paths=['Cargo.toml','Cargo.lock','.cargo/config.toml','LICENSE','hosts/gpu/Cargo.toml','hosts/gpu/src/native_artifact/AGENTS.md','hosts/gpu/src/native_artifact/program/prepare/numeric_exits.rs','hosts/gpu/src/native_artifact/program/prepare/numeric_exit_definitions.rs','hosts/gpu/src/native_artifact/program/prepare/numeric_liveness.rs','hosts/gpu/src/native_artifact/program/prepare/numeric_liveness_tests.rs','hosts/gpu/src/native_artifact/program/prepare/numeric_point_liveness.rs','hosts/gpu/src/native_artifact/program/prepare/numeric_point_liveness_tests.rs','hosts/gpu/src/native_artifact/program/packed_liveness.rs','hosts/gpu/src/native_artifact/program/codegen/minimal_liveness_dataflow.rs','src/engine/src/native_artifact/program_facts.rs','hosts/gpu/tests/fixtures/native/deflate-huffman-LICENSES.md']
paths+=['benchmarks/mech-deflate/native-profile/'+n for n in ['Cargo.toml','Cargo.lock','compile_profile.rs','profile_compile.py','numeric_liveness_tests.rs']]
paths+=['hosts/gpu/tests/fixtures/native/'+n+'.mec' for n in ['numeric-nested-phase','numeric-nested-phase-states','numeric-private-fixed-nested','numeric-changing-capture-tree','numeric-array-windows','numeric-multiple-children']]
for revision,folder in [(base,'source-base'),(source,'source')]:
 tracked=set(subprocess.check_output(['git','ls-tree','-r','--name-only',revision],text=True).splitlines())
 for name in paths:
  if name not in tracked:continue
  d=packet/folder/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(subprocess.check_output(['git','show',revision+':'+name]))
shutil.copytree(Path('/private/tmp/mech-borrowed-schema-packet-20261114/licenses'),packet/'licenses')
for pattern in ['mech-*live-query*20261114.py','mech-*point-liveness*20261114.py','mech-*live-query*20261114.log']:
 for p in Path('/private/tmp').glob(pattern):
  if p.is_file():shutil.copy2(p,packet/p.name)
shutil.copy2(repo/'docs/design/native-point-liveness-compile-profile.md',packet/'report.md')
(packet/'README.txt').write_text('''Bounded exact exit liveness at the requested start, Apple M3, 2026-11-14.
Retained source and measured patch are pinned in source-state.json. The source
commit matches the exact tested/measured patch. A fresh current 61-flag baseline
is separate from all historical 60-flag cohorts. Eight serial matched complete
compiles preserve every source/MBC/Object/metadata byte and lower time and
instructions; compiler RSS increases 1.93%. Both balanced blocks improve.
The original solver's 790 graph inputs and full expected results, two diagnostic
profiles, both complete kernel experiment streams, independent Python oracle,
production source/tests, all build commands and the failed short-link attempt
remain. Compiler/probe executables are excluded and hash-pinned; interpreter
caches are omitted. Normal compiler-profile Thin LTO is used for qualification.
No profiling/capture code is retained and no runtime execution machinery changes.
Pure offline replay checks the source patches, full cohort, outputs, tests,
profiles, raw kernel data and independently re-solves all graph inputs without
compilers, benchmark execution, original scratch paths or network. It does not
rerun the timing measurements. See report.md and summary.json.
The sub-ten-second complete-compilation goal remains open.
''');print(packet)
