#[path = "/Users/cim310/.codex/worktrees/level12-compile-profile/mech/hosts/gpu/src/native_artifact/program/packed_liveness.rs"]
pub(crate) mod packed_liveness;
mod native_artifact { pub(crate) mod program { pub(crate) use crate::packed_liveness; } }
#[path = "/Users/cim310/.codex/worktrees/level12-compile-profile/mech/hosts/gpu/src/native_artifact/program/prepare/numeric_liveness.rs"]
mod original;
#[path = "point_liveness_trial.rs"]
mod point;
use std::collections::BTreeSet;
use std::time::Instant;
type Graph = (Vec<Vec<usize>>,Vec<BTreeSet<u32>>,Vec<Vec<u32>>,usize,BTreeSet<u32>);
fn main() {
 let args=std::env::args().skip(1).collect::<Vec<_>>();assert_eq!(args.len(),2);
 let directory=std::path::Path::new(&args[0]);let repeats:usize=args[1].parse().unwrap();
 let mut files=std::fs::read_dir(directory).unwrap().map(|e|e.unwrap().path()).filter(|p|p.extension().is_some_and(|x|x=="json")).collect::<Vec<_>>();files.sort();assert_eq!(files.len(),790);
 let factors=[0usize,1,4,16];
 for (query,path) in files.iter().enumerate() {
  let graph:Graph=serde_json::from_slice(&std::fs::read(path).unwrap()).unwrap();
  let (next,reads,defs,start,expected)=graph;
  assert_eq!(original::live_before_indexed(&next,&reads,&defs,start),expected);
  for repeat in 0..repeats {
   let order=if (query+repeat)%2==0 {vec![0,1,2,3]}else{vec![3,2,1,0]};
   for mode in order {
    let factor=factors[mode];let budget=next.len().saturating_mul(factor).min(packed_liveness::MAX_DENSE_CELLS);
    let started=Instant::now();
    let (live,point_succeeded,steps)=if factor==0 {
     (original::live_before_indexed(std::hint::black_box(&next),std::hint::black_box(&reads),std::hint::black_box(&defs),start),false,0)
    } else {
     let (answer,steps)=point::solve(std::hint::black_box(&next),std::hint::black_box(&reads),std::hint::black_box(&defs),start,budget);
     let success=answer.is_some();let live=answer.unwrap_or_else(||original::live_before_indexed(&next,&reads,&defs,start));(live,success,steps)
    };
    let seconds=started.elapsed().as_secs_f64();assert_eq!(live,expected,"query={query} factor={factor}");assert!(steps<=budget);
    println!("{}",serde_json::json!({"query":query,"repeat":repeat,"factor":factor,"nodes":next.len(),"read_occurrences":reads.iter().map(BTreeSet::len).sum::<usize>(),"budget":budget,"steps":steps,"point_succeeded":point_succeeded,"seconds":seconds,"live_values":live.len(),"exact_expected":true}));
   }
  }
 }
}
