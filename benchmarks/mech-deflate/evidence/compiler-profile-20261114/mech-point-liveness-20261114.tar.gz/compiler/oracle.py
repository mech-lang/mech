"""Independent whole-set backward dataflow; no bounded per-value search."""
from collections import deque

def live_before(next, reads, definitions, start):
    values=sorted({v for row in reads for v in row})
    if not values:return []
    bits={value:1<<index for index,value in enumerate(values)}
    parents=[[] for _ in next]
    for site,successors in enumerate(next):
        for successor in successors:parents[successor].append(site)
    live=[];kills=[]
    for read,defined in zip(reads,definitions):
        used=0;kill=0
        for value in read:used|=bits[value]
        for value in defined:kill|=bits.get(value,0)
        live.append(used);kills.append(kill)
    pending=deque(site for site in range(len(next)-1,-1,-1) if live[site])
    queued=bytearray(bool(mask) for mask in live)
    while pending:
        site=pending.popleft();queued[site]=0
        for parent in parents[site]:
            added=live[site]&~kills[parent]&~live[parent]
            if added:
                live[parent]|=added
                if not queued[parent]:queued[parent]=1;pending.append(parent)
    return [value for index,value in enumerate(values) if (live[start]>>index)&1]
