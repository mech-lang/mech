from pathlib import Path
import json
import statistics

repo = Path.cwd()
raw = Path('/private/tmp/mech-compiler-fat-lto-pgo-20261115')
prefix = 'compiler-fat-lto-pgo-apple-m3-20261115'
result = repo / 'benchmarks/mech-deflate/native-profile' / (prefix + '.json')
data = json.loads(result.read_text())
decision = data['decision']
retained = decision['decision'] == 'retain'
native = data['native_cohort']['numerical_summary']
numeric = data['numerical_summary']
isolation = data['parallel_isolation_numerical_summary']
mean = lambda row, subject: statistics.mean(row[subject])
change = lambda row: f"{-100 * row['mean_reduction_fraction']:+.3f}%"
report_name = 'native-fat-lto-pgo-compile-profile.md'
report_path = repo / 'docs/design' / report_name
assert not report_path.exists()

def table(rows):
    lines = ['| Work | ThinLTO control | Full LTO candidate | Change |', '| --- | ---: | ---: | ---: |']
    for label, row, counter in rows:
        fmt = ',.2f' if counter else '.6f'
        lines.append(f"| {label} | {mean(row, 'control'):{fmt}} | {mean(row, 'candidate'):{fmt}} | {change(row)} |")
    return '\n'.join(lines)

def adverse(rows):
    values = [f"{name} {change(row)}" for name, row in rows.items() if row['mean_reduction_fraction'] < 0]
    return '; '.join(values) if values else 'None in this cohort.'

native_table = table([(name, native[key], False) for name, key in [
    ('Complete source to executable', 'source_to_executable_seconds'),
    ('Source-to-Object process', 'source_to_object_process_seconds'),
    ('Object handoff', 'object_handoff_seconds'),
    ('Final native link', 'native_link_seconds'),
]])
object_table = table([(name, numeric[key], counter) for name, key, counter in [
    ('Internal compiler', 'compiler_seconds', False),
    ('Parser', 'parse_seconds', False),
    ('Checked frontend', 'frontend_seconds', False),
    ('Native preparation', 'preparation_seconds', False),
    ('Numeric helper generation', 'numeric_generation_seconds', False),
    ('Main source CFG', 'source_cfg_seconds', False),
    ('Cleanup including compaction', 'cleanup_including_compaction_seconds', False),
    ('Retired instructions', 'instructions', True),
    ('Maximum RSS bytes', 'max_rss_bytes', True),
]])
heldout_lines = ['| Held-out program | Process time change | Internal compiler change | Instruction change |', '| --- | ---: | ---: | ---: |']
for case in data['held_out_compilation']:
    nums = case['numerical_summary']
    heldout_lines.append(f"| {case['name']} | {change(nums['whole_process_seconds'])} | {change(nums['compiler_seconds'])} | {change(nums['instructions'])} |")
heldout_adverse = '\n'.join(f"- {case['name']}: {adverse(case['numerical_summary'])}" for case in data['held_out_compilation'])
native_blocks = ', '.join(f"{-100 * row['mean_reduction_fraction']:+.3f}%" for row in data['native_cohort']['balanced_blocks'])
object_blocks = ', '.join(f"{-100 * row['compiler_seconds']['mean_reduction_fraction']:+.3f}%" for row in data['balanced_blocks'])
isolated = isolation['source_to_executable_seconds']
training = next(row['seconds'] for row in data['pipeline'] if row['stage'] == 'training')
best_sentence = ('The full-LTO configuration is retained as the fastest qualified compiler.' if retained else 'The full-LTO configuration is rejected; the qualified ThinLTO compiler `8043` remains selected.')
main = native['source_to_executable_seconds']
headline = f"Complete fresh Deflate compilation measures **{mean(main, 'control'):.6f} to {mean(main, 'candidate'):.6f} seconds ({change(main)})**. {best_sentence} Both use the exact same source, native CPU tuning and their own PGO. PGO fully counts toward the compilation goal."
if not retained:
    headline += f" The separate Object compiler cohort changes {change(numeric['compiler_seconds'])}, with both blocks slower; parsing changes {change(numeric['parse_seconds'])}. This fails the consistency criterion fixed before timing."
report = f'''# Full LTO with fresh compiler PGO

{headline}

## Frozen configuration and complete builds

Source is `ef5e255e817eb5bbc6df61b094a3741b31c49da2`. Control is the existing qualified ThinLTO compiler `8043`; the candidate changes compiler LTO strategy to full/fat LTO with explicit `CARGO_PROFILE_COMPILER_LTO=fat` and `CARGO_PROFILE_COMPILER_CODEGEN_UNITS=1` on both instrumented and profile-use builds. Cargo's verbose final Rustc invocations independently verify `lto=fat`, one codegen unit, native CPU and the candidate's own fresh profile. No production source or generated-program setting changes.

Both subjects use nightly-2026-03-03, explicit `aarch64-apple-darwin`, four Cargo jobs, incremental compilation disabled, `-D warnings`, native CPU and the same predetermined eight-program training corpus. Every program compilation uses the same 61 runtime flags and two workers. Source assembly through final native-link completion is the primary boundary. The runtime and entry adapter are cached and pinned; historical first-use adapter construction of 11.882560208 seconds is separate.

{native_table}

Times are seconds. Each primary cohort has eight serial ABBA/BAAB observations, four per subject. Complete-build block changes are {native_blocks}. All builds and training finish before qualification, and no heavy builds, tests, sampling, hashing or packaging overlap primary timing. Retention was fixed before candidate timing: complete-build mean and both blocks, plus separate Object compiler mean and both blocks, must all improve. All exact-output gates must pass.

The original selected `8043` primary mean of 13.414825 seconds and its later 13.275817-second control repeat are separate historical cohorts. Only the direct matched control/candidate observations above measure this LTO change; no historical or component percentages are added.

## Compiler phases and held-out programs

{object_table}

Durations are seconds; instruction and RSS rows are raw counts and bytes. Object compiler block changes are {object_blocks}. Phase intervals are wall-clock boundaries rather than exclusive CPU attribution. Adverse Object fields: {adverse(numeric)}. Adverse complete-build fields: {adverse(native)}.

{chr(10).join(heldout_lines)}

All heldout adverse fields remain:

{heldout_adverse}

Training is fixed to Deflate, numeric-nested-phase, numeric-private-fixed-nested, numeric-array-windows, scalar-bool-equal, scalar-u64-add, scalar-i64-divide and scalar-f64-add. The seven disjoint heldouts are small scalar/numeric programs; this does not measure generalization to unrelated substantial programs. Each has its own eight serial observations, with no pooled tiny-program percentage.

A separate same-candidate-binary worker-count cohort measures **{mean(isolated, 'serial'):.6f} to {mean(isolated, 'parallel'):.6f} seconds ({change(isolated)})** for serial versus two workers. It remains separate from the LTO comparison. Default `MECH_COMPACT_COMPILE_THREADS=0` remains serial; `=2` enables the existing workers.

## Output identity and reproduction

Instrumented compiler construction takes {data['compiler_builds']['generate']['seconds']:.3f} seconds, training {training:.3f} seconds and profile-use construction {data['compiler_builds']['use']['seconds']:.3f} seconds. These are excluded from Deflate compilation timing. Profile-use construction emits {data['compiler_build_diagnostics']['use']['missing_function']:,} missing-function warnings and zero profile hash/control-flow mismatches; all diagnostics are retained. Candidate SHA-256 is `{data['compiler_binary_sha256']['candidate']}`. The merged profile is {data['merged_profile']['bytes']:,} bytes, SHA-256 `{data['merged_profile']['sha256']}`.

All eight training outputs, 14 fixture pairs, 56 heldout compilations, eight Object observations, default-serial and real-worker gates preserve source, bytecode, Object and complete metadata. The worker diagnostic records 344 submitted jobs, including 48 cleanup-and-machine jobs. All 20 complete executable images reproduce every byte of the frozen 2,060,440-byte executable, SHA-256 `d6c65cc3fb18acc4be77dce329962105bf0f2b56dd2623a12f466256463eca61`. Emitted program code and runtime inputs are identical; no separate runtime timing campaign is claimed.

The fifty-second [repository packet](../../benchmarks/mech-deflate/evidence/compiler-profile-20261114/README.md) retains every command, diagnostic, observation, complete output/executable, native link input, configuration, plan, script and derivation. Eight raw profiles and the merged profile are stored losslessly and stream-verified. Compiler binaries, dependency targets and the full source checkout are excluded and hash/Git pinned. Fresh extraction verifies the repository archive and replays the entire [summary](../../benchmarks/mech-deflate/native-profile/{prefix}.json) byte-identically. Compilation below ten seconds remains open.
'''
assert not decision['goal_sub10_achieved'], 'Update goal audit and report wording before documenting a sub-ten result.'
report_path.write_text(report)

paragraph = f"The [full-LTO compiler comparison]({{link}}) is **{'retained' if retained else 'rejected'}**. Complete fresh builds measure **{mean(main, 'control'):.6f} to {mean(main, 'candidate'):.6f} seconds ({change(main)})** against the fastest qualified ThinLTO compiler, with both using exact current source, native CPU and fresh PGO. Parser time is {mean(numeric['parse_seconds'], 'control'):.6f} versus {mean(numeric['parse_seconds'], 'candidate'):.6f} seconds. All full outputs, complete metadata and 20 executable images match. The fifty-second packet retains all diagnostics, adverse fields, fixed eight-program profiles, seven small heldouts and exact Rustc LTO invocations; fresh repository extraction verifies/replays byte-identically. {best_sentence} The sub-ten-second goal stays open."
for name, link in [
    ('benchmarks/mech-deflate/native-profile/README.md', '../../../docs/design/' + report_name),
    ('benchmarks/mech-deflate/EXPERIMENTS.md', '../../docs/design/' + report_name),
]:
    path = repo / name
    text = path.read_text()
    assert report_name not in text
    path.write_text(text.rstrip() + '\n\n' + paragraph.format(link=link) + '\n')

base = repo / 'benchmarks/mech-deflate/evidence/compiler-profile-20261114'
index = json.loads((base / 'index.json').read_text())
assert len(index['packets']) == 52
receipt = json.loads((result.with_suffix('.archive.json')).read_text())
readme = base / 'README.md'
text = readme.read_text()
assert 'Fifty-one complete' in text and 'All fifty-one repository' in text
text = text.replace('Fifty-one complete', 'Fifty-two complete').replace('All fifty-one repository', 'All fifty-two repository')
text = text.replace('1,728,255,374 bytes (1,728.3 MB)', f"{index['total_archive_bytes']:,} bytes ({index['total_archive_bytes']/1_000_000:,.1f} MB)")
lines = text.splitlines()
positions = [i for i, line in enumerate(lines) if line.startswith('|')]
assert positions
archive = 'mech-compiler-fat-lto-pgo-20261115.tar.gz'
row = f"| Full LTO with fresh compiler PGO | {'Retained' if retained else 'Rejected'}: complete build {change(main)}; exact program and executable bytes. | [{archive}]({archive}) | [Receipt](../../native-profile/{prefix}.archive.json) / [result](../../native-profile/{prefix}.json) | {receipt['files']:,} |"
lines.insert(positions[-1] + 1, row)
text = '\n'.join(lines).rstrip() + '\n\n' + paragraph.format(link='../../../../docs/design/' + report_name) + '\n'
readme.write_text(text)
print(json.dumps({'report':str(report_path),'decision':decision['decision'],'complete_control_seconds':mean(main,'control'),'complete_candidate_seconds':mean(main,'candidate'),'packets':52},indent=2))
