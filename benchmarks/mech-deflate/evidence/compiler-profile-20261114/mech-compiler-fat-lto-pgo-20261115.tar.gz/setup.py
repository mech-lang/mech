from pathlib import Path, PurePosixPath
import ast
import datetime
import hashlib
import json
import shutil
import subprocess
import tarfile
import time
import tomllib

repo=Path.cwd()
root=Path('/private/tmp/mech-compiler-fat-lto-pgo-20261115')
prior=Path('/private/tmp/mech-dimension-native-pgo-20261115')
standard=Path('/private/tmp/mech-dimension-declaration-scan-20261115')
revision='ef5e255e817eb5bbc6df61b094a3741b31c49da2'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pin=lambda p:dict(bytes=p.stat().st_size,sha256=sha(p))
assert not root.exists()
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
assert not subprocess.check_output(['git','diff',revision,'HEAD','--','src','vendor','hosts','machines','Cargo.toml','Cargo.lock','.cargo','benchmarks/mech-deflate/native-profile/Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.lock','benchmarks/mech-deflate/native-profile/compile_profile.rs','benchmarks/mech-deflate/native-profile/profile_compile.py'])
assert sha(prior/'use')=='8043d93d27b948371aee38027df898a9024e47a1ffa112b47a1913f8329e40ad'
parser_trial=Path('/private/tmp/mech-parser-frame-payloads-20261115')
assert json.loads((parser_trial/'decision.json').read_text())['decision']=='reject'
assert json.loads((parser_trial/'restoration.json').read_text())['source_restored']
root.mkdir();source=root/'source';source.mkdir()
command=['git','archive','--format=tar',revision,'--','.',':(exclude)benchmarks/mech-deflate/evidence']
started=time.monotonic()
with (root/'source-archive.stderr.log').open('w') as stderr:
    process=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=stderr)
    files=0
    with tarfile.open(fileobj=process.stdout,mode='r|') as archive:
        for entry in archive:
            path=PurePosixPath(entry.name);assert not path.is_absolute() and '..' not in path.parts
            archive.extract(entry,source,filter='data');files+=entry.isfile()
    assert process.wait()==0
assert tomllib.loads((source/'.cargo/config.toml').read_text())['build']['rustflags']==['-D','warnings']
for p in [source/'Cargo.toml',source/'benchmarks/mech-deflate/native-profile/Cargo.toml']:
    profile=tomllib.loads(p.read_text())['profile']['compiler'];assert profile['lto']=='thin' and profile['codegen-units']==1
state=dict(source_commit=revision,evidence_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),source_tree=subprocess.check_output(['git','rev-parse',revision+'^{tree}'],text=True).strip(),archive_command=command,files_extracted=files,seconds=time.monotonic()-started,created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Exact same retained production source as fastest8043. Only compiler link-time-optimization configuration changes: new subject uses explicit CARGO_PROFILE_COMPILER_LTO=fat and own fresh nativeCPU PGO. No source or emitted-program compiler setting change. Both valid configurations count fully toward the compilation goal.',setup_complete=False)
(root/'source-state.json').write_text(json.dumps(state,indent=2)+'\n')
shutil.copy2(prior/'use',root/'control')
for original,dest in [(standard/'reference','reference'),(standard/'fixtures','fixture-reference'),(prior/'fixture-input-template','fixture-input-template')]:shutil.copytree(original,root/dest)
for original,name in [(standard/'fixture-results.json','fixture-reference-results.json'),(standard/'runtime-flags.json','runtime-flags.json'),(prior/'fixed-corpus-plan.json','fixed-corpus-plan.json')]:shutil.copy2(original,root/name)
assert len(json.loads((root/'runtime-flags.json').read_text()))==61
assert pin(root/'fixture-input-template/numeric-nested-phase-states.mec')==dict(bytes=2905,sha256='541ec270c88fdd50d9fd6e9e06df69f80840336c306ea67caffc40f18ab871a4')
shutil.copy2(repo/'benchmarks/mech-deflate/native-profile/dimension-native-pgo-apple-m3-20261115.archive.json',root/'control-source-evidence-receipt.json')
for name in ['rustc-version.txt','rustc-sysroot.txt','target-cpus.txt','generic-target-cfg.txt','native-target-cfg.txt','cpu.txt','cpu-count.txt','memory.txt','os.txt','llvm-profdata-path.txt','llvm-profdata-version.txt','setup-commands.json']:
    shutil.copy2(prior/name,root/name)
assert subprocess.check_output(['rustc','+nightly-2026-03-03','-Vv'],text=True)==(root/'rustc-version.txt').read_text()
assert Path((root/'llvm-profdata-path.txt').read_text().strip()).is_file()
(root/'control-reuse.json').write_text(json.dumps(dict(binary=str(root/'control'),**pin(root/'control'),source_commit=revision,source_evidence_packet=49,build=json.loads((prior/'use-build.json').read_text()),profile_sha256='8691e0be35ba3c8816c22f361a5040b266ea89d14a3355d1a61fad73154bc9f7',scope='Qualified fastest8043 with nativeCPU/ThinLTO/CGU1 and fixed8 PGO. New candidate uses same source/settings/corpus/workers except explicit FatLTO and its own fresh profile. No reused thin profile for the new subject.'),indent=2)+'\n')
(root/'configuration-plan.json').write_text(json.dumps(dict(control=dict(lto='thin',native_cpu=True,codegen_units=1,fresh_profile_from_packet49=True),candidate=dict(lto='fat',native_cpu=True,codegen_units=1,own_fresh_generate_train_use=True),training='Same fixed8 corpus and7 heldouts, declared before outcomes; no feedback selection.',requirements='All source/bytecode/Object/fullmetadata/complete-executable gates pass. Compare complete source-to-executable means and both balanced blocks; all Object phases/counters and adverse results retained. No inferred benefit or added historical percentages.',measurement='Every compiler build/training finishes before primary serial uncontended timing. Bootstrap can overlap publication of completed trial51; bootstrap durations are excluded from Deflate compilation timings. No concurrent heavy work during primary measurement.',effective_configuration_proof='Cargo verbose stderr retains actual final rustc invocation and LTO flag. Both Cargo manifests remain exactly pinned with original thin profile; explicit environment override applies only to this isolated subject.'),indent=2)+'\n')
original=Path('/private/tmp/mech-dimension-native-pgo-pipeline-20261115.py')
text=original.read_text().replace(str(prior),str(root))
before="assert sha(root/'control')=='3c09f358909db5ab07d09a9ee78a16d3de83f58d9f181f750985e7f3a88653f3'"
after="assert sha(root/'control')=='8043d93d27b948371aee38027df898a9024e47a1ffa112b47a1913f8329e40ad'"
assert text.count(before)==1;text=text.replace(before,after)
before="CARGO_INCREMENTAL='0',CARGO_ENCODED_RUSTFLAGS="
after="CARGO_INCREMENTAL='0',CARGO_PROFILE_COMPILER_LTO='fat',CARGO_PROFILE_COMPILER_CODEGEN_UNITS='1',CARGO_ENCODED_RUSTFLAGS="
assert text.count(before)==1;text=text.replace(before,after)
before="'--bin','compile_profile','--message-format=json'"
after="'--bin','compile_profile','--verbose','--message-format=json'"
assert text.count(before)==1;text=text.replace(before,after)
before="mode=mode,rustflags=rustflags,target="
after="mode=mode,CARGO_PROFILE_COMPILER_LTO='fat',CARGO_PROFILE_COMPILER_CODEGEN_UNITS='1',rustflags=rustflags,target="
assert text.count(before)==1;text=text.replace(before,after)
ast.parse(text)
derived=Path('/private/tmp/mech-compiler-fat-lto-pgo-pipeline-20261115.py');assert not derived.exists();derived.write_text(text)
shutil.copy2(original,root/'original-build-pipeline.py');shutil.copy2(derived,root/'build-pipeline.py');shutil.copy2(__file__,root/'setup.py')
(root/'build-derivation.json').write_text(json.dumps(dict(original=str(original),original_sha256=sha(original),derived=str(derived),derived_sha256=sha(derived),changes='New isolated root; qualified8043 control; explicit FatLTO/CGU1 environment override and actual rustc invocation via Cargo verbose. Same source and all nativeCPU/profile-generate/profile-use/runtime flags; own fresh8 profiles.'),indent=2)+'\n')
state['setup_complete']=True;(root/'source-state.json').write_text(json.dumps(state,indent=2)+'\n')
print(json.dumps(state,indent=2))
