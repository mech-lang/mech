from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

repo = Path.cwd()
raw = Path('/private/tmp/mech-compiler-fat-lto-pgo-20261115')
packet = Path('/private/tmp/mech-compiler-fat-lto-pgo-packet-20261115')
assert all(r['state']=='complete' and r['exit_code']==0 for r in json.loads((raw/'qualification/pipeline.json').read_text()))
packet.mkdir(exist_ok=False)
pin = lambda p: dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
excluded = []
for p in sorted(raw.iterdir()):
    if p.name in ['source','target','raw','merged.profdata']:
        continue
    if p.name in ['control','generate','use']:
        excluded.append(dict(path=p.name,**pin(p)))
        continue
    for q in ([p] if p.is_file() else sorted(p.rglob('*'))):
        if not q.is_file(): continue
        rel = q.relative_to(raw)
        if rel.as_posix() in ['qualification/control','qualification/candidate']:
            excluded.append(dict(path=rel.as_posix(),**pin(q)))
            continue
        dest = packet/rel
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(q,dest)
state = json.loads((raw/'source-state.json').read_text())
paths = ['.cargo/config.toml','Cargo.toml','Cargo.lock','benchmarks/mech-deflate/native-profile/Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.lock','benchmarks/mech-deflate/native-profile/compile_profile.rs','benchmarks/mech-deflate/native-profile/profile_compile.py','src/syntax/src/document/parser/canonical/base/continuation.rs']
source_pins = []
for name in paths:
    data = (raw/'source'/name).read_bytes()
    assert data==subprocess.check_output(['git','show',state['source_commit']+':'+name])
    dest = packet/'source-config'/name
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(data)
    source_pins.append(dict(path=name,**pin(dest)))
(packet/'source-config-pins.json').write_text(json.dumps(source_pins,indent=2)+'\n')
for row in json.loads((packet/'qualification/fixture-results.json').read_text()):
    name=row['fixture']
    if name.startswith('hosts/'):
        data=subprocess.check_output(['git','show',state['source_commit']+':'+name])
        assert data==(raw/'source'/name).read_bytes()
        (packet/'qualification/fixture-inputs'/Path(name).name).write_bytes(data)
validation=packet/'validation';validation.mkdir()
for suffix in ['.json','.archive.json']:
    shutil.copy2(repo/('benchmarks/mech-deflate/native-profile/dimension-native-pgo-apple-m3-20261115'+suffix),validation/('prior-qualified'+suffix))
reference=json.loads((validation/'prior-qualified.json').read_text())['output_hashes']
assert all(pin(packet/'qualification/reference'/n)==v for n,v in reference.items())
(packet/'qualification/reference-pins.json').write_text(json.dumps(reference,indent=2)+'\n')
link=Path('/private/tmp/mech-pr973-refresh-20261115/link')
capture=json.loads((link/'capture/link-command.json').read_text())
for source,dest in [('capture/link-command.json','link-command.json'),('baseline-pins.json','native-baseline-pins.json'),('build.json','historical-adapter-build.json')]:shutil.copy2(link/source,packet/dest)
inputs=[]
for i,row in enumerate(capture['inputs']):
    source=Path(row['retained_path']);assert pin(source)=={k:row[k] for k in ['bytes','sha256']}
    rel=Path('native-link-inputs')/(str(i)+'-'+source.name)
    dest=packet/rel;dest.parent.mkdir(exist_ok=True);shutil.copy2(source,dest)
    inputs.append(dict(source=row['source'],path=rel.as_posix(),**pin(dest)))
(packet/'native-link-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
shutil.copytree('/private/tmp/mech-round2-planning-packet-20261114/licenses',packet/'licenses')
originals=packet/'qualification-scripts/originals';originals.mkdir()
for row in json.loads((packet/'qualification-scripts/derivation.json').read_text()):
    source=Path(row['original']);assert pin(source)['sha256']==row['original_sha256'];shutil.copy2(source,originals/source.name)
shutil.copy2(raw/'qualification-pipeline.py',packet/'qualify.py')
shutil.copy2('/private/tmp/mech-replay-compiler-fat-lto-pgo-20261115.py',packet/'replay.py')
shutil.copy2(__file__,packet/'curate.py')
members={}
paths=sorted((raw/'raw').glob('*.profraw'))+[raw/'merged.profdata']
assert len(paths)==9
bundle=packet/'profiles.tar.xz'
with tarfile.open(bundle,'w:xz',preset=9) as archive:
    for p in paths:
        name=p.relative_to(raw).as_posix();members[name]=pin(p)
        info=archive.gettarinfo(str(p),arcname=name);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
        with p.open('rb') as content:archive.addfile(info,content)
actual={}
with tarfile.open(bundle,'r|xz') as archive:
    for member in archive:
        assert member.isfile() and member.name not in actual
        digest=hashlib.sha256();size=0
        with archive.extractfile(member) as content:
            while chunk:=content.read(1024*1024):size+=len(chunk);digest.update(chunk)
        actual[member.name]=dict(bytes=size,sha256=digest.hexdigest())
assert actual==members
(packet/'profile-storage.json').write_text(json.dumps(dict(format=1,path=bundle.name,codec='xz',preset=9,**pin(bundle),members=members,scope='Lossless storage of all eight original raw profiles and merged profile; every extracted byte verified against original pins. Original files unchanged.'),indent=2,sort_keys=True)+'\n')
(packet/'excluded-compiler-products.json').write_text(json.dumps(excluded,indent=2)+'\n')
print(json.dumps(dict(packet=str(packet),profile_bytes=sum(r['bytes'] for r in members.values()),bundle=pin(bundle)),indent=2))
