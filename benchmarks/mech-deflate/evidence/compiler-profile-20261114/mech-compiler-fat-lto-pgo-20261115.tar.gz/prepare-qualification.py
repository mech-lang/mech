from pathlib import Path
import ast
import hashlib
import json
import shutil

old=Path('/private/tmp/mech-dimension-native-pgo-20261115')
root=Path('/private/tmp/mech-compiler-fat-lto-pgo-20261115')
scripts=root/'qualification-scripts'
assert not scripts.exists();scripts.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pin=lambda p:dict(bytes=p.stat().st_size,sha256=sha(p))
records=[]
for original in sorted((old/'qualification-scripts').glob('*.py')):
    text=original.read_text();assert str(old) in text
    text=text.replace(str(old),str(root))
    if original.name=='mech-native-cohort-refreshed-native-pgo-current-20261115.py':
        before='Frozen ef5/3c09 standard compiler versus nativeCPU plus current instrumentation PGO; same source/program/runtime. Combined configuration comparison, no additive component claim. No emitted-program allocator changes; compiler nativeCPU/PGO overrides are the subject.'
        after='Same ef5 source and program/runtime: current fastest8043 ThinLTO/nativeCPU/PGO versus FatLTO/nativeCPU with own fresh PGO, both CGU1. Same fixed8 training corpus,61program flags and2workers. Direct LTO strategy comparison, no component or historical percentages added. Both configurations count fully toward the compilation goal.'
        assert text.count(before)==1;text=text.replace(before,after)
    assert str(old) not in text
    ast.parse(text);dest=scripts/original.name;dest.write_text(text)
    records.append(dict(original=str(original),original_sha256=sha(original),derived=dest.name,derived_sha256=sha(dest)))
assert len(records)==18
(scripts/'derivation.json').write_text(json.dumps(records,indent=2)+'\n')

original=Path('/private/tmp/mech-qualify-dimension-native-pgo-20261115.py')
text=original.read_text().replace(str(old),str(root))
before="out = root / 'qualification'"
preflight="""assert not any(k.startswith('MIMALLOC_') for k in os.environ)
import shlex
rustc_proofs={}
for mode in ['generate','use']:
    build=json.loads((root/(mode+'-build.json')).read_text())
    assert build['exit_code']==0 and build['source_commit']==state['source_commit']
    assert build['CARGO_PROFILE_COMPILER_LTO']=='fat' and build['CARGO_PROFILE_COMPILER_CODEGEN_UNITS']=='1'
    messages=[json.loads(line) for line in (root/(mode+'-build.jsonl')).read_text().splitlines()]
    assert messages[-1]=={'reason':'build-finished','success':True}
    warnings=[v['message'] for v in messages if v.get('reason')=='compiler-message']
    assert not any('hash mismatch' in v['message'] or 'control flow change' in v['message'] for v in warnings)
    lines=[line for line in (root/(mode+'-build.stderr')).read_text().splitlines() if 'Running `' in line and '--crate-name compile_profile ' in line]
    assert len(lines)==1
    line=lines[0];argv=shlex.split(line.split('Running `',1)[1].removesuffix('`'))
    flags=[argv[i+1] for i,v in enumerate(argv[:-1]) if v=='-C']+[v[2:] for v in argv if v.startswith('-C') and v!='-C']
    expected_profile=('profile-generate='+str(root/'raw')) if mode=='generate' else ('profile-use='+str(root/'merged.profdata'))
    assert all(v in flags for v in ['lto=fat','codegen-units=1','target-cpu=native',expected_profile])
    rustc_proofs[mode]=dict(line=line,argv=argv,codegen_flags=flags,line_sha256=hashlib.sha256(line.encode()).hexdigest())
for name in ['numeric-nested-phase-states.mec','assembly.json']:
    assert (root/'fixture-input-template'/name).is_file()
assert hashlib.sha256((root/'fixture-input-template/numeric-nested-phase-states.mec').read_bytes()).hexdigest()=='541ec270c88fdd50d9fd6e9e06df69f80840336c306ea67caffc40f18ab871a4'
(root/'qualified-rustc-invocations.json').write_text(json.dumps(rustc_proofs,indent=2)+'\\n')
"""
assert text.count(before)==1;text=text.replace(before,preflight+'\n'+before)
before="config = dict(source_commit=state['source_commit'],common_compile_threads=2,program_flags_count=61,"
after="config = dict(source_commit=state['source_commit'],compiler_lto=dict(control='thin',candidate='fat'),native_cpu=True,codegen_units=1,common_compile_threads=2,program_flags_count=61,"
assert text.count(before)==1;text=text.replace(before,after)
before='Qualified standard3c09 compiler versus current nativeCPU plus instrumentation PGO. Same source/program/runtime and61flags/twoworkers; measures combined compiler build configuration. No additive/historical gain claim.'
after='Direct current-fastest8043 ThinLTO versus FatLTO with own fresh PGO. Both use exact ef5 source, nativeCPU/CGU1, same predetermined fixed8 corpus, runtime,61program flags and2workers. LTO strategy is the candidate; both valid optimized configurations count fully. No component or historical percentages added.'
assert text.count(before)==1;text=text.replace(before,after)
tree=ast.parse(text)
loops=[n for n in ast.walk(tree) if isinstance(n,ast.For) and isinstance(n.target,ast.Tuple) and [getattr(v,'id','') for v in n.target.elts]==['stage','name']]
assert len(loops)==1
stages=ast.literal_eval(loops[0].iter)
assert [s for s,_ in stages]==['screens','cached-executable-gates','serial-default-gate','real-worker-diagnostic','fixtures-object-cohort','heldout-cohorts','native-cohort','parallel-isolation']
assert all((scripts/n).is_file() for _,n in stages)
assert str(old) not in text
dest=Path('/private/tmp/mech-qualify-compiler-fat-lto-pgo-20261115.py');assert not dest.exists();dest.write_text(text)
shutil.copy2(original,root/'original-qualification-pipeline.py');shutil.copy2(dest,root/'qualification-pipeline.py')
required=[root/'fixture-input-template/numeric-nested-phase-states.mec',root/'fixture-input-template/assembly.json',root/'source/benchmarks/mech-deflate/native-profile/profile_compile.py',root/'runtime-flags.json']
for name in ['numeric-nested-phase','numeric-private-fixed-nested','numeric-changing-capture-tree','numeric-array-windows','numeric-multiple-children']:
    required.append(root/'source/hosts/gpu/tests/fixtures/native'/(name+'.mec'))
assert all(p.is_file() for p in required)
required_pins=[dict(path=str(p.relative_to(root)),**pin(p)) for p in required]
plan=dict(source_commit='ef5e255e817eb5bbc6df61b094a3741b31c49da2',qualification_driver_sha256=sha(dest),actual_ast_stages=[dict(stage=s,helper=n,helper_sha256=sha(scripts/n)) for s,n in stages],required_non_script_inputs=required_pins,scope='Prepared before any new compiler-use timing. Both subjects have the same production source; fresh FatLTO instrumentation/training/use and actual rustc flags must pass preflight. Every heavy build/training/publication step finishes before serial uncontended primary observations.')
(root/'qualification-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(root/'qualification-derivation.json').write_text(json.dumps(dict(original=str(original),original_sha256=sha(original),derived=str(dest),derived_sha256=sha(dest),helpers=records,changes='New isolated root and explicit ThinLTO/FatLTO same-source strategy; actual rustc invocation/profile flags and zero CFG/hash mismatches checked before timing. All18helpers/all8stages present; unchanged template and source fixture dependencies validated.'),indent=2)+'\n')
(root/'retention-plan.json').write_text(json.dumps(dict(created_before_candidate_timing=True,required='All full output/metadata/whole-executable gates pass. Full-native mean and both balanced blocks improve; separate Object compiler mean and both balanced blocks improve. Retain only a consistent complete-build gain; all adverse fields, heldouts and failed attempts remain.',scope='Same-source exact ef5, ThinLTO8043 versus FatLTO candidate with own fresh PGO. No inferred benefit or cumulative percentages.'),indent=2)+'\n')
shutil.copy2(__file__,root/'prepare-qualification.py')
print(json.dumps(dict(helpers=len(records),stages=stages,required_inputs=len(required_pins),driver_sha256=sha(dest)),indent=2))
