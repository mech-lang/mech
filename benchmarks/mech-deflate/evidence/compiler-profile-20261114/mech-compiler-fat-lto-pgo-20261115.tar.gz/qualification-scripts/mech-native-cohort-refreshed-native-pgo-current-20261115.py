from pathlib import Path
import json, statistics, subprocess, sys

root = Path('/private/tmp/mech-compiler-fat-lto-pgo-20261115/qualification')
order = [('control','native-control-1'),('candidate','native-candidate-1'),('candidate','native-candidate-2'),('control','native-control-2'),('candidate','native-candidate-3'),('control','native-control-3'),('control','native-control-4'),('candidate','native-candidate-4')]
records = []
for variant, name in order:
    print('START', name, flush=True)
    subprocess.run([sys.executable, '/private/tmp/mech-compiler-fat-lto-pgo-20261115/qualification-scripts/mech-run-native-refreshed-native-pgo-current-20261115.py', variant, name],check=True)
    row = json.loads((root/name/'result.json').read_text())
    row.update(name=name, primary_cohort=True)
    records.append(row)
    (root/'native-cohort.json').write_text(json.dumps(records,indent=2)+'\n')
fields=['source_to_executable_seconds','source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']
summary={}
for key in fields:
    values={v:[r[key] for r in records if r['variant']==v] for v in ['control','candidate']}
    values['mean_reduction_fraction']=1-statistics.mean(values['candidate'])/statistics.mean(values['control'])
    summary[key]=values
blocks=[]
for rows in [records[:4],records[4:]]:
    means={v:statistics.mean(r['source_to_executable_seconds'] for r in rows if r['variant']==v) for v in ['control','candidate']}
    means['mean_reduction_fraction']=1-means['candidate']/means['control']
    blocks.append(means)
out=dict(numerical_summary=summary,balanced_blocks=blocks,order=order,scope='Eight serial fresh source-to-executable compiles with current fixed adapter cached; same61programflags,2workers and pinnedmimalloc inboth compilerexecutables. Same ef5 source and program/runtime: current fastest8043 ThinLTO/nativeCPU/PGO versus FatLTO/nativeCPU with own fresh PGO, both CGU1. Same fixed8 training corpus,61program flags and2workers. Direct LTO strategy comparison, no component or historical percentages added. Both configurations count fully toward the compilation goal. Separate from Object observations and screens.')
(root/'native-numerical-summary.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2),flush=True)
