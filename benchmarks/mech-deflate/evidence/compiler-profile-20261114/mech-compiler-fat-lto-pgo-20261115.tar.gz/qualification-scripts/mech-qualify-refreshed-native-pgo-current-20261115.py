from pathlib import Path
import subprocess,sys,json
root=Path('/private/tmp/mech-compiler-fat-lto-pgo-20261115/qualification')
for name in ['mech-parallel-native-pgo-fixtures-current-20261115.py','mech-run-refreshed-native-pgo-cohort-current-20261115.py']:
 subprocess.run([sys.executable,str(Path('/private/tmp/mech-compiler-fat-lto-pgo-20261115/qualification-scripts')/name)],check=True)
rows=json.loads((root/'cohort.json').read_text());(root/'cohort-unexpanded.json').write_text(json.dumps(rows,indent=2)+'\n')
for name,block in [('first',rows[:4]),('second',rows[4:])]: (root/('cohort-'+name+'.json')).write_text(json.dumps(block,indent=2)+'\n')
subprocess.run([sys.executable,'/private/tmp/mech-compiler-fat-lto-pgo-20261115/qualification-scripts/mech-analyze-refreshed-native-pgo-current-20261115.py'],check=True)
