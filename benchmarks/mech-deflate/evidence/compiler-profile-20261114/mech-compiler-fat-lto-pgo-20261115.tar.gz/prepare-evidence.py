from pathlib import Path
import ast
import hashlib
import json
import shutil

root=Path('/private/tmp/mech-compiler-fat-lto-pgo-20261115')
old_root='/private/tmp/mech-dimension-native-pgo-20261115'
old_packet='/private/tmp/mech-dimension-native-pgo-packet-20261115'
new_packet='/private/tmp/mech-compiler-fat-lto-pgo-packet-20261115'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
records=[]
def replace(text,before,after):
    assert text.count(before)==1,before
    return text.replace(before,after)
def save(original,destination,text):
    ast.parse(text)
    originals=root/'evidence-originals';originals.mkdir(exist_ok=True)
    derived=root/'evidence-derived';derived.mkdir(exist_ok=True)
    assert not destination.exists()
    shutil.copy2(original,originals/original.name);destination.write_text(text);shutil.copy2(destination,derived/destination.name)
    records.append(dict(original=str(originals/original.name),original_sha256=sha(original),derived=str(derived/destination.name),derived_sha256=sha(destination)))

original=Path('/private/tmp/mech-replay-dimension-native-pgo-20261115.py')
text=original.read_text().replace(old_root,str(root))
text=replace(text,"'--bin', 'compile_profile', '--message-format=json'","'--bin', 'compile_profile', '--verbose', '--message-format=json'")
text=replace(text,"control_reuse['sha256']=='3c09f358909db5ab07d09a9ee78a16d3de83f58d9f181f750985e7f3a88653f3'","control_reuse['sha256']=='8043d93d27b948371aee38027df898a9024e47a1ffa112b47a1913f8329e40ad'")
text=replace(text,"prior['compiler']['candidate']['sha256']==control_reuse['sha256']","prior['compiler_binary_sha256']['candidate']==control_reuse['sha256']")
text=replace(text,"assert all(x['mean_reduction_fraction']>0 for x in native_blocks)","assert all(x['mean_reduction_fraction']>0 for x in native_blocks) and all(x['compiler_seconds']['mean_reduction_fraction']>0 for x in blocks)\nassert decision['object_blocks']==blocks")
text=replace(text,'Current ef5 retained dimension-scan source and program/runtime. Reuse qualified standard3c09 control versus target-cpu=native plus instrumentation PGO. Same 61 program flags and two workers. Two new compiler builds; standard control reused. Measures combined build configuration with no component or historical gain claim.','Direct same-source ef5 current-fastest8043 ThinLTO versus FatLTO with own fresh PGO. Both use nativeCPU/CGU1, fixed8 training corpus,61program flags and2workers. LTO strategy is the candidate. Both valid optimized configurations fully count toward the compilation goal; no component or historical percentages added.')
text=replace(text,'Deflate itself is in training: this is workload-tuned PGO, not proof of broad compiler gains. Seven heldouts are small fixtures. Fresh instrument/train/use for exact ef5 source. Explicit aarch64 target, nightly-2026-03-03, compiler ThinLTO/CGU1, j4, incremental0 and -Dwarnings. Absolute profile paths and matching Rust LLVM22 profdata. Standard3c09 from qualified packet48 reused. Native-only subject omitted; no component gain claimed. Builds/training excluded from primary means.','Both subjects use legitimate PGO with the same predetermined eight-program corpus including Deflate. Same exact ef5 source, nativeCPU/CGU1, nightly2026-03-03, aarch64 target, j4, incremental0 and -Dwarnings. Candidate explicit FatLTO environment override is verified against both actual final Rustc invocations; control uses qualified ThinLTO8043. Seven fixed scalar/numeric heldouts retain every observation. Compiler builds/training are outside Deflate compilation timing.')
text=replace(text,'Subten remains unproven.','The goal is evaluated from complete source-to-executable measurements and exact output gates; no component gains are added.')
proof="""assert state['compiler_lto']==dict(control='thin',candidate='fat') and state['native_cpu'] and state['codegen_units']==1
import shlex
rustc_proofs=read(packet/'qualified-rustc-invocations.json')
assert set(rustc_proofs)=={'generate','use'}
for mode,build in builds.items():
    assert build['CARGO_PROFILE_COMPILER_LTO']=='fat' and build['CARGO_PROFILE_COMPILER_CODEGEN_UNITS']=='1'
    item=rustc_proofs[mode]
    lines=[line for line in (packet/(mode+'-build.stderr')).read_text().splitlines() if 'Running `' in line and '--crate-name compile_profile ' in line]
    assert lines==[item['line']] and hashlib.sha256(item['line'].encode()).hexdigest()==item['line_sha256']
    argv=shlex.split(item['line'].split('Running `',1)[1].removesuffix('`'));assert argv==item['argv']
    flags=[argv[i+1] for i,v in enumerate(argv[:-1]) if v=='-C']+[v[2:] for v in argv if v.startswith('-C') and v!='-C']
    assert flags==item['codegen_flags']
    profile=('profile-generate='+str('/private/tmp/mech-compiler-fat-lto-pgo-20261115/raw')) if mode=='generate' else ('profile-use='+str('/private/tmp/mech-compiler-fat-lto-pgo-20261115/merged.profdata'))
    assert all(v in flags for v in ['lto=fat','codegen-units=1','target-cpu=native',profile])
summary.update(effective_rustc_invocations=rustc_proofs,compiler_lto=dict(control='thin',candidate='fat'),retention_plan=read(packet/'retention-plan.json'))

"""
text=replace(text,'encoded = json.dumps(summary, indent=2, sort_keys=True)',proof+'encoded = json.dumps(summary, indent=2, sort_keys=True)')
save(original,Path('/private/tmp/mech-replay-compiler-fat-lto-pgo-20261115.py'),text)

original=Path('/private/tmp/mech-curate-parser-frame-native-pgo-20261115.py')
text=original.read_text().replace('/private/tmp/mech-parser-frame-native-pgo-20261115',str(root)).replace('/private/tmp/mech-parser-frame-native-pgo-packet-20261115',new_packet).replace('/private/tmp/mech-replay-parser-frame-native-pgo-20261115.py','/private/tmp/mech-replay-compiler-fat-lto-pgo-20261115.py')
before="""    if name==state['source_files'][0]['path']:
        assert pin(raw/'source'/name)==state['source_files'][0]['candidate']
    else:
        assert data==subprocess.check_output(['git','show',state['base_commit']+':'+name])"""
after="    assert data==subprocess.check_output(['git','show',state['source_commit']+':'+name])"
text=replace(text,before,after)
text=text.replace("state['base_commit']","state['source_commit']")
assert "source_files" not in text
save(original,Path('/private/tmp/mech-curate-compiler-fat-lto-pgo-20261115.py'),text)

for label in ['pack','publish']:
    original=Path('/private/tmp/mech-'+label+'-dimension-native-pgo-20261115.py')
    text=original.read_text().replace(old_root,str(root)).replace(old_packet,new_packet).replace('mech-dimension-native-pgo-','mech-compiler-fat-lto-pgo-').replace('dimension-native-pgo-apple-m3-','compiler-fat-lto-pgo-apple-m3-')
    if label=='publish':
        text=replace(text,'assert len(previous)==48 and index[\'total_archive_bytes\']==1536980034','assert len(previous)==51 and index[\'total_archive_bytes\']==1728255374')
    save(original,Path('/private/tmp/mech-'+label+'-compiler-fat-lto-pgo-20261115.py'),text)

original=Path('/private/tmp/mech-decide-dimension-native-pgo-20261115.py')
text=original.read_text().replace(old_root,str(root))
before="retained = main['mean_reduction_fraction'] > 0 and all(row['mean_reduction_fraction'] > 0 for row in native['balanced_blocks'])"
after="""cohort=read(qualification/'cohort.json')
object_blocks=[]
for subset in [cohort[:4],cohort[4:]]:
    fields={}
    for key,get in [('compiler_seconds',lambda r:r['compile']['total_seconds']),('whole_process_seconds',lambda r:r['process']['elapsed_seconds']),('instructions',lambda r:r['instructions'])]:
        means={v:statistics.mean(get(r) for r in subset if r['variant']==v) for v in ['control','candidate']}
        fields[key]=dict(means,mean_reduction_fraction=1-means['candidate']/means['control'])
    object_blocks.append(fields)
retained = main['mean_reduction_fraction'] > 0 and all(row['mean_reduction_fraction'] > 0 for row in native['balanced_blocks']) and numeric['compiler_seconds']['mean_reduction_fraction']>0 and all(row['compiler_seconds']['mean_reduction_fraction']>0 for row in object_blocks)"""
text=replace(text,before,after)
text=replace(text,'fresh nativeCPU+PGO build configuration on current dimension-scan source ef5','FatLTO with own fresh PGO versus current fastest ThinLTO8043 on the same ef5 source')
text=replace(text,'object_adverse_fields=adverse, heldout_adverse_fields=heldout_adverse,','object_adverse_fields=adverse, object_blocks=object_blocks, heldout_adverse_fields=heldout_adverse,')
text=replace(text,'previous_qualified_pgo_seconds=13.596783062268514','previous_qualified_pgo_seconds=13.414824520470574')
text=replace(text,'Historical 0c949 source, separate cohort. No direct comparative gain inferred.','Prior primary13.414825 on same-source qualified8043; prior control repeat13.275817 is separate. Only this new direct matched cohort measures the LTO strategy change.')
save(original,Path('/private/tmp/mech-decide-compiler-fat-lto-pgo-20261115.py'),text)
(root/'evidence-derivation.json').write_text(json.dumps(records,indent=2)+'\n')
shutil.copy2(__file__,root/'prepare-evidence.py')
print(json.dumps(dict(derived_helpers=len(records),source_commit='ef5e255e817eb5bbc6df61b094a3741b31c49da2',scope='Preparation only; no decision/curation/packing/publication until complete qualification.'),indent=2))
