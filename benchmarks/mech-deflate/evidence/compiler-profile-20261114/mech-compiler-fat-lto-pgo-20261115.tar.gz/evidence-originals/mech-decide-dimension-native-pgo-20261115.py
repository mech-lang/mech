from pathlib import Path
import json
import statistics

root = Path('/private/tmp/mech-dimension-native-pgo-20261115')
qualification = root / 'qualification'
read = lambda path: json.loads(path.read_text())
native = read(qualification / 'native-numerical-summary.json')
numeric = read(qualification / 'numerical-summary.json')
isolation = read(qualification / 'parallel-isolation-summary.json')
heldout = read(qualification / 'heldout-results.json')
pipeline = read(qualification / 'pipeline.json')
assert all(row['state'] == 'complete' and row['exit_code'] == 0 for row in pipeline)
main = native['numerical_summary']['source_to_executable_seconds']
serial = isolation['numerical_summary']['source_to_executable_seconds']
control_mean = statistics.mean(main['control'])
candidate_mean = statistics.mean(main['candidate'])
retained = main['mean_reduction_fraction'] > 0 and all(row['mean_reduction_fraction'] > 0 for row in native['balanced_blocks'])
adverse = {key: row for key, row in numeric.items() if row['mean_reduction_fraction'] < 0}
heldout_adverse = {case['name']: {key: row for key, row in case['numerical_summary'].items() if row['mean_reduction_fraction'] < 0} for case in heldout}
description = (
    f"{'Retained' if retained else 'Rejected'} fresh nativeCPU+PGO build configuration on current dimension-scan source ef5: "
    f"complete build {control_mean:.6f}->{candidate_mean:.6f}s ({main['mean_reduction_fraction']*100:.2f}% reduction); "
    f"separate same-PGO-binary serial/two-worker comparison {statistics.mean(serial['serial']):.6f}->{statistics.mean(serial['parallel']):.6f}s "
    f"({serial['mean_reduction_fraction']*100:.2f}% reduction). Exact source/bytecode/Object/complete metadata and all 20 executables; "
    "default 0 and real 344-job/48-cleanup gates; fixed 8-program training and 7 heldouts. All adverse fields retained. "
    "No production source, grammar, runtime or output changes; two compiler builds outside primary timing, adapter cached. No additive or sub-ten claim."
)
decision = dict(
    decision='retain' if retained else 'reject', description=description,
    generalization=dict(label='Deflate-trained PGO', benchmark_in_training=True, heldout_count=7, heldout_scope='Small scalar and numeric fixtures; no unrelated substantial-program qualification. Does not establish broad compiler speedup.', unprofiled_current_parallel_qualification='packet48, separate cohort'),
    source_commit='ef5e255e817eb5bbc6df61b094a3741b31c49da2',
    control_complete_seconds=control_mean, candidate_complete_seconds=candidate_mean,
    native_reduction=main['mean_reduction_fraction'], native_blocks=native['balanced_blocks'],
    isolated_serial_seconds=statistics.mean(serial['serial']),
    isolated_two_worker_seconds=statistics.mean(serial['parallel']),
    isolated_reduction=serial['mean_reduction_fraction'],
    isolated_blocks=isolation['balanced_blocks'],
    object_adverse_fields=adverse, heldout_adverse_fields=heldout_adverse,
    source_changes=False, previous_qualified_pgo_seconds=13.596783062268514,
    previous_pgo_scope='Historical 0c949 source, separate cohort. No direct comparative gain inferred.',
    goal_sub10_achieved=retained and candidate_mean < 10,
)
(root / 'decision.json').write_text(json.dumps(decision, indent=2, sort_keys=True) + '\n')
print(json.dumps(decision, indent=2, sort_keys=True))
