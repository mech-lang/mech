from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

root = Path('/private/tmp/mech-compiler-fat-lto-pgo-20261115')
pipeline = json.loads((root/'pipeline.json').read_text())
assert [r['stage'] for r in pipeline] == ['generate','training','use']
assert all(r['state']=='complete' and r['exit_code']==0 for r in pipeline)
source = root / 'source'
state = json.loads((root/'source-state.json').read_text())
assert state['source_commit']=='ef5e255e817eb5bbc6df61b094a3741b31c49da2'
assert not any(k.startswith('MIMALLOC_') for k in os.environ)
import shlex
rustc_proofs={}
for mode in ['generate','use']:
    build=json.loads((root/(mode+'-build.json')).read_text())
    assert build['exit_code']==0 and build['source_commit']==state['source_commit']
    assert build['CARGO_PROFILE_COMPILER_LTO']=='fat' and build['CARGO_PROFILE_COMPILER_CODEGEN_UNITS']=='1'
    messages=[json.loads(line) for line in (root/(mode+'-build.jsonl')).read_text().splitlines()]
    assert messages[-1]=={'reason':'build-finished','success':True}
    warnings=[v['message'] for v in messages if v.get('reason')=='compiler-message']
    assert not any('hash mismatch' in v['message'] or 'control flow change' in v['message'] for v in warnings)
    lines=[line for line in (root/(mode+'-build.stderr')).read_text().splitlines() if 'Running `' in line and '--crate-name compile_profile ' in line]
    assert len(lines)==1
    line=lines[0];argv=shlex.split(line.split('Running `',1)[1].removesuffix('`'))
    flags=[argv[i+1] for i,v in enumerate(argv[:-1]) if v=='-C']+[v[2:] for v in argv if v.startswith('-C') and v!='-C']
    expected_profile=('profile-generate='+str(root/'raw')) if mode=='generate' else ('profile-use='+str(root/'merged.profdata'))
    assert all(v in flags for v in ['lto=fat','codegen-units=1','target-cpu=native',expected_profile])
    rustc_proofs[mode]=dict(line=line,argv=argv,codegen_flags=flags,line_sha256=hashlib.sha256(line.encode()).hexdigest())
for name in ['numeric-nested-phase-states.mec','assembly.json']:
    assert (root/'fixture-input-template'/name).is_file()
assert hashlib.sha256((root/'fixture-input-template/numeric-nested-phase-states.mec').read_bytes()).hexdigest()=='541ec270c88fdd50d9fd6e9e06df69f80840336c306ea67caffc40f18ab871a4'
(root/'qualified-rustc-invocations.json').write_text(json.dumps(rustc_proofs,indent=2)+'\n')

out = root / 'qualification'
out.mkdir(exist_ok=False)
sha = lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for original,name in [('control','control'),('use','candidate')]:
    shutil.copy2(root/original,out/name)
    expected = json.loads((root/'control-reuse.json').read_text())['sha256'] if original=='control' else json.loads((root/'use-build.json').read_text())['binary_sha256']
    assert sha(out/name)==expected
shutil.copytree(root/'reference',out/'reference')
shutil.copy2(root/'runtime-flags.json',out/'runtime-flags.json')
config = dict(source_commit=state['source_commit'],compiler_lto=dict(control='thin',candidate='fat'),native_cpu=True,codegen_units=1,common_compile_threads=2,program_flags_count=61,
              subjects={v:dict(bytes=(out/v).stat().st_size,sha256=sha(out/v)) for v in ['control','candidate']},
              strategy='Direct current-fastest8043 ThinLTO versus FatLTO with own fresh PGO. Both use exact ef5 source, nativeCPU/CGU1, same predetermined fixed8 corpus, runtime,61program flags and2workers. LTO strategy is the candidate; both valid optimized configurations count fully. No component or historical percentages added.',
              primary_timing='Every compiler build and training finished before qualification. Serial/uncontended cohorts, no heavy builds/tests/profiling/hashing/archival overlap. Exactall4outputs/complete metadata and whole currentD6exe gates precede primary timing. Fixedruntime/adapter cached.',
              scripts=json.loads((root/'qualification-scripts/derivation.json').read_text()))
(out/'configuration.json').write_text(json.dumps(config,indent=2)+'\n')
env = {k:v for k,v in os.environ.items() if not k.startswith('MECH_')}
records=[]
for stage,name in [('screens', 'mech-screen-refreshed-native-pgo-current-20261115.py'), ('cached-executable-gates', 'mech-cached-native-link-refreshed-native-pgo-current-20261115.py'), ('serial-default-gate', 'mech-qualify-parallel-native-pgo-serial-20261115.py'), ('real-worker-diagnostic', 'mech-qualify-parallel-native-pgo-jobs-20261115.py'), ('fixtures-object-cohort', 'mech-qualify-refreshed-native-pgo-current-20261115.py'), ('heldout-cohorts', 'mech-heldout-refreshed-native-pgo-20261115.py'), ('native-cohort', 'mech-native-cohort-refreshed-native-pgo-current-20261115.py'), ('parallel-isolation', 'mech-native-parallel-isolation-cohort-20261115.py')]:
    command = [sys.executable,str(root/'qualification-scripts'/name)]
    row = dict(stage=stage,state='running',command=command,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    records.append(row)
    (out/'pipeline.json').write_text(json.dumps(records,indent=2)+'\n')
    started=time.monotonic()
    with (out/(stage+'.stdout.log')).open('w') as stdout,(out/(stage+'.stderr.log')).open('w') as stderr:
        completed=subprocess.run(command,cwd=source,env=env,stdout=stdout,stderr=stderr)
    row.update(state='complete' if completed.returncode==0 else 'failed',exit_code=completed.returncode,seconds=time.monotonic()-started)
    (out/'pipeline.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    assert completed.returncode==0
