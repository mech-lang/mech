from pathlib import Path
import json
import statistics

repo = Path.cwd()
base = repo / 'benchmarks/mech-deflate/native-profile'
summary = json.loads((base / 'parallel-native-pgo-apple-m3-20261115.json').read_text())
receipt = json.loads((base / 'parallel-native-pgo-apple-m3-20261115.archive.json').read_text())
index_path = repo / 'benchmarks/mech-deflate/evidence/compiler-profile-20261114/index.json'
index = json.loads(index_path.read_text())
assert len(index['packets']) == 45
native = summary['native_cohort']['numerical_summary']
object_values = summary['numerical_summary']
isolation = summary['parallel_isolation_numerical_summary']
mean = statistics.mean
value = lambda rows, subject: mean(rows[subject])
change = lambda rows: -100 * rows['mean_reduction_fraction']
main = native['source_to_executable_seconds']
parallel = isolation['source_to_executable_seconds']
full_blocks = summary['native_cohort']['balanced_blocks']
parallel_blocks = summary['parallel_isolation_balanced_blocks']
table = []
for label, key in [('Complete source to executable', 'source_to_executable_seconds'), ('Source-to-Object process', 'source_to_object_process_seconds'), ('Final native link', 'native_link_seconds')]:
    rows = native[key]
    table.append(f"| {label} | {value(rows,'control'):.6f} s | {value(rows,'candidate'):.6f} s | {change(rows):+.2f}% |")
stage_table = []
for label, key in [('Internal compiler', 'compiler_seconds'), ('Parser', 'parse_seconds'), ('Checked frontend', 'frontend_seconds'), ('Native preparation', 'preparation_seconds'), ('Numeric helper generation', 'numeric_generation_seconds'), ('Main source CFG', 'source_cfg_seconds'), ('Cleanup including compaction', 'cleanup_including_compaction_seconds'), ('Instructions retired', 'instructions')]:
    rows = object_values[key]
    stage_table.append(f"| {label} | {value(rows,'control'):.6f} | {value(rows,'candidate'):.6f} | {change(rows):+.2f}% |")
heldout_table = []
for case in summary['held_out_compilation']:
    rows = case['numerical_summary']
    heldout_table.append(f"| {case['name']} | {change(rows['whole_process_seconds']):+.2f}% | {change(rows['compiler_seconds']):+.2f}% | {change(rows['instructions']):+.2f}% |")
adverse = ', '.join(f"{key} {change(rows):+.2f}%" for key, rows in object_values.items() if rows['mean_reduction_fraction'] < 0) or 'none'
description = f"""# Fresh PGO for the expanded parallel compiler

Complete fresh Deflate source-to-executable builds average **{value(main,'candidate'):.6f} seconds** with native-CPU tuning and fresh PGO, versus **{value(main,'control'):.6f} seconds** for the standard compiler ({main['mean_reduction_fraction']*100:.2f}% faster). Both use source `0c949505cc708c233e27c094aa67e105068d6823`, the same 61 program flags and two workers. All complete executable bytes match.

This is **Deflate-trained PGO**: Deflate is one of eight training programs. Seven disjoint held-out scalar/numeric fixtures improve, but they are small; the numeric inputs are 1,264, 1,258 and 1,633 bytes. This qualification does not establish gains on unrelated substantial programs. Native-CPU tuning is also specific to this hardware. The standard compiler remains a separate baseline. No component percentages or historical gains are added.

A separate eight-build comparison changes only worker count on one immutable PGO compiler: **{value(parallel,'serial'):.6f} seconds serial versus {value(parallel,'parallel'):.6f} seconds with two workers ({parallel['mean_reduction_fraction']*100:.2f}% faster)**. Its blocks change {-100*parallel_blocks[0]['mean_reduction_fraction']:+.2f}% and {-100*parallel_blocks[1]['mean_reduction_fraction']:+.2f}%. The standard-compiler [parallel qualification](native-parallel-phase-cleanup-compile-profile.md) remains separate. Default `MECH_COMPACT_COMPILE_THREADS=0` is serial; `=2` enables workers.

## Complete build boundary

| Boundary | Standard | Native CPU + PGO | Change |
| --- | ---: | ---: | ---: |
{chr(10).join(table)}

The complete-build blocks improve {100*full_blocks[0]['mean_reduction_fraction']:.2f}% and {100*full_blocks[1]['mean_reduction_fraction']:.2f}%. Each observation starts fresh source assembly and ends after the final native link process completes. The fixed runtime/entry adapter is cached and hash-pinned; historical first-use adapter construction of 11.882560208 seconds is excluded. Every primary observation runs serially without overlapping heavy builds, tests, sampling, hashing or packaging.

## Compiler work and held-out results

The separate eight-observation Object cohort records these means; stage durations are seconds and instruction counts are whole counts.

| Work | Standard | Native CPU + PGO | Change |
| --- | ---: | ---: | ---: |
{chr(10).join(stage_table)}

Adverse Object fields: {adverse}. Every field, observation and balanced block remains in the [complete result](../../benchmarks/mech-deflate/native-profile/parallel-native-pgo-apple-m3-20261115.json), including held-out memory movement and native-link/handoff movement. These are observed intervals, not exclusive CPU attribution.

| Held-out program | Process time change | Internal compiler change | Instruction change |
| --- | ---: | ---: | ---: |
{chr(10).join(heldout_table)}

These 56 held-out compilations use ABBA/BAAB order per case. No pooled tiny-program percentage stands in for large-program evidence. A stronger generalization test would train without Deflate and evaluate unrelated substantial programs.

## Build configuration and exact-output gates

The immutable standard compiler is the qualified source-0c949 binary with SHA-256 `6ce7a53b36d3677cf3b20d919657d2824b7d8561ef5eeaf254377626f27980ae`. Fresh instrumented and profile-use builds use nightly-2026-03-03, explicit `aarch64-apple-darwin`, compiler ThinLTO/CGU1, four Cargo jobs, incremental compilation disabled, preserved `-D warnings`, native CPU, absolute profile paths and the matching Rust LLVM profdata. A native-only subject is omitted; the measured subject combines CPU tuning and PGO. No production source or program/runtime allocator changes are made.

The fixed training set is Deflate, numeric-nested-phase, numeric-private-fixed-nested, numeric-array-windows, scalar-bool-equal, scalar-u64-add, scalar-i64-divide and scalar-f64-add. All eight instrumented outputs match the frozen standard reference. All raw profiles and the merged profile are retained and pinned inside a lossless nested XZ archive. Streaming replay verifies each original member against its existing hash; the outer archive uses the maintained gzip pack/verify tools. The initial flat 110,387,554-byte packet is recorded before this packaging-only change. Instrumented build takes {summary['compiler_builds']['generate']['seconds']:.3f} seconds and profile-use build takes {summary['compiler_builds']['use']['seconds']:.3f} seconds; both are excluded from Deflate timing.

Both preliminary complete-executable gates, the default-serial gate and an excluded real-job diagnostic pass before primary timing. The diagnostic records 344 jobs, including 48 cleanup-and-machine jobs. Every main output, complete metadata, 14 fixture pairs and all 20 authoritative complete executables match the frozen source/bytecode/Object/metadata/executable bytes. The complete 2,060,440-byte executable remains SHA-256 `d6c65cc3fb18acc4be77dce329962105bf0f2b56dd2623a12f466256463eca61`. No runtime timing campaign substitutes for this identity.

The first qualification wrapper silently omitted planned default-serial/isolation stages because its derivation searched for helper filenames that had not been renamed. That attempt was interrupted; its entire partial Object cohort is excluded. Original driver, commands, logs, outputs and interruption are preserved. The corrected driver is checked through its actual AST against every declared stage and helper path before fresh qualification. No compiler rebuild or configuration change occurs between attempts. All corrected gates and cohorts pass. Curation also initially copied historical helper filenames; that footer was corrected before the first replay, with both versions retained and no observation changes.

The forty-fifth [repository packet](../../benchmarks/mech-deflate/evidence/compiler-profile-20261114/README.md) includes all profiles, scripts/derivation, logs, observations, program outputs/executables and fixed native inputs. Compiler binaries, dependency targets and the complete source checkout are excluded and hash/Git pinned. Fresh extraction verifies the repository archive and replays every numerical summary and accepted output byte-for-byte. Compilation below ten seconds remains open.
"""
report = repo / 'docs/design/native-parallel-pgo-compile-profile.md'
assert not report.exists()
report.write_text(description)
paragraph = f"""## Fresh PGO for expanded workers: Deflate-trained

The fresh [PGO qualification]({{link}}) on source `0c949505cc` measures complete source-to-executable builds **{value(main,'control'):.6f} to {value(main,'candidate'):.6f} seconds ({main['mean_reduction_fraction']*100:.2f}% faster)**. A separate same-PGO-binary serial/two-worker comparison measures **{value(parallel,'serial'):.6f} to {value(parallel,'parallel'):.6f} seconds ({parallel['mean_reduction_fraction']*100:.2f}% faster)**. Both preserve every executable byte; the experiments remain separate.

Deflate is included in training. All seven disjoint small heldouts improve, which does not establish broad gains on unrelated substantial programs. The standard compiler remains separately reported. The forty-fifth packet includes raw/merged profiles, every adverse field, all outputs and 20 authoritative executables, the interrupted/excluded wrapper attempt and the corrected stage audit. Fresh repository extraction verifies and replays exactly. No source/language/runtime changes or sub-ten claim.
"""
for path, link in [(base/'README.md','../../../docs/design/native-parallel-pgo-compile-profile.md'), (repo/'benchmarks/mech-deflate/EXPERIMENTS.md','../../docs/design/native-parallel-pgo-compile-profile.md')]:
    with path.open('a') as output:
        output.write('\n'+paragraph.format(link=link))
path = repo / 'benchmarks/mech-deflate/evidence/compiler-profile-20261114/README.md'
text = path.read_text().replace('Forty-four complete evidence packets', 'Forty-five complete evidence packets').replace('All forty-four repository copies', 'All forty-five repository copies')
text = text.replace('1,339,519,056 bytes (1,339.5 MB)', f"{index['total_archive_bytes']:,} bytes ({index['total_archive_bytes']/1e6:,.1f} MB)")
lines = text.splitlines()
at = next(i for i, line in enumerate(lines) if line.startswith('| Expanded general-phase cleanup workers |'))
lines.insert(at+1, f"| Fresh PGO for expanded workers (Deflate-trained) | Complete build {value(main,'candidate'):.3f}s; matched standard improvement {main['mean_reduction_fraction']*100:.2f}%; separate PGO serial/two-worker gain {parallel['mean_reduction_fraction']*100:.2f}%. Seven small heldouts improve; no broad generalization claim. All outputs/20 authoritative executables exact; interrupted wrapper attempt retained/excluded. | [mech-parallel-native-pgo-20261115.tar.gz](mech-parallel-native-pgo-20261115.tar.gz) | [Receipt](../../native-profile/parallel-native-pgo-apple-m3-20261115.archive.json) / [result](../../native-profile/parallel-native-pgo-apple-m3-20261115.json) | {receipt['files']:,} |")
path.write_text('\n'.join(lines)+'\n\n'+paragraph.format(link='../../../../docs/design/native-parallel-pgo-compile-profile.md'))
path = repo / 'docs/design/native-parallel-compilation.md'
text = path.read_text()
at = text.index('The first [integrated implementation]')
text = text[:at]+f"The fresh [Deflate-trained PGO qualification](native-parallel-pgo-compile-profile.md) on this source measures {value(main,'candidate'):.3f}-second complete builds. Its separate same-PGO-binary comparison measures {value(parallel,'serial'):.3f} seconds serial versus {value(parallel,'parallel'):.3f} seconds with two workers ({parallel['mean_reduction_fraction']*100:.2f}% faster). PGO includes Deflate in training; seven small heldouts do not establish broad generalization. Standard compiler results above remain separate.\n\n"+text[at:]
path.write_text(text)
print(report)
