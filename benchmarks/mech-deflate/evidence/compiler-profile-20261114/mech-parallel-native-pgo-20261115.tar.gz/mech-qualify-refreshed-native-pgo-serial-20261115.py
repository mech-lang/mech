from pathlib import Path
import datetime,json,subprocess,sys,time
r=Path('/private/tmp/mech-refreshed-native-pgo-20261115/qualification');commands=[[sys.executable,str(r.parent/'qualification-scripts/mech-run-refreshed-native-pgo-serial-gate-20261115.py'),'candidate','candidate-serial-gate'],[sys.executable,str(r.parent/'qualification-scripts/mech-cached-native-link-refreshed-native-pgo-serial-20261115.py')]];records=[]
for i,command in enumerate(commands):
 row=dict(command=command,state='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(row);(r/'serial-gate-pipeline.json').write_text(json.dumps(records,indent=2)+'\n');started=time.monotonic()
 with (r/('serial-gate-'+str(i)+'.stdout.log')).open('w') as stdout,(r/('serial-gate-'+str(i)+'.stderr.log')).open('w') as stderr:completed=subprocess.run(command,cwd=r.parent/'source',stdout=stdout,stderr=stderr)
 row.update(state='complete' if completed.returncode==0 else 'failed',exit_code=completed.returncode,seconds=time.monotonic()-started);(r/'serial-gate-pipeline.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True);assert completed.returncode==0
