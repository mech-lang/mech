from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess, time, tomllib

root=Path('/private/tmp/mech-refreshed-native-pgo-20261115')
source=root/'source'
state=json.loads((root/'source-state.json').read_text())
assert state['setup_complete'] and state['source_commit']=='d26cf2c65eac2f5978cabba257bb8bebbe4b0a80'
assert tomllib.loads((source/'.cargo/config.toml').read_text())['build']['rustflags']==['-D','warnings']
flags=json.loads((root/'runtime-flags.json').read_text());assert len(flags)==61
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pin=lambda p:dict(bytes=p.stat().st_size,sha256=sha(p))
runtime={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}
runtime.update(flags);runtime['MECH_COMPACT_COMPILE_THREADS']='2'
records=[]
assert not (root/'pipeline.json').exists()
assert not any(k.startswith('MIMALLOC_') for k in os.environ)
assert sha(root/'control')=='b72ff590c3ea6760f9a77372ba2bb6761f3b2d2885cdbef029ee040509bb51ba'
(root/'runtime-environment.json').write_text(json.dumps(dict(flags=dict(flags,MECH_COMPACT_COMPILE_THREADS='2'),MIMALLOC_overrides={},scope='Build/train only; no primary timing until all builds and gates finish.'),indent=2)+'\n')

def stage(name,run):
    row=dict(stage=name,state='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    records.append(row);(root/'pipeline.json').write_text(json.dumps(records,indent=2)+'\n')
    started=time.monotonic()
    try:
        run()
    except BaseException as error:
        row.update(state='failed',seconds=time.monotonic()-started,error=repr(error))
        (root/'pipeline.json').write_text(json.dumps(records,indent=2)+'\n')
        raise
    row.update(state='complete',seconds=time.monotonic()-started,exit_code=0)
    (root/'pipeline.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)

def build(mode):
    rustflags=['-D','warnings']
    if mode!='control':rustflags+=['-C','target-cpu=native']
    if mode=='generate':
        profile=root/'raw';profile.mkdir();assert not list(profile.iterdir())
        rustflags+=['-C','profile-generate='+str(profile)]
    if mode=='use':
        assert (root/'merged.profdata').is_file()
        rustflags+=['-C','profile-use='+str(root/'merged.profdata'),'-C','llvm-args=-pgo-warn-missing-function']
    env=dict(os.environ,CARGO_TARGET_DIR=str(root/'target'),CARGO_INCREMENTAL='0',CARGO_ENCODED_RUSTFLAGS='\x1f'.join(rustflags));env.pop('RUSTFLAGS',None)
    command=['cargo','+nightly-2026-03-03','build','--locked','--offline','--profile','compiler','--target','aarch64-apple-darwin','-j4','--manifest-path','benchmarks/mech-deflate/native-profile/Cargo.toml','--bin','compile_profile','--message-format=json']
    started=time.perf_counter()
    with (root/(mode+'-build.jsonl')).open('w') as stdout,(root/(mode+'-build.stderr')).open('w') as stderr:
        completed=subprocess.run(command,cwd=source,env=env,stdout=stdout,stderr=stderr)
    record=dict(command=command,source_commit=state['source_commit'],mode=mode,rustflags=rustflags,target='aarch64-apple-darwin',cargo_jobs=4,CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(root/'target'),seconds=time.perf_counter()-started,exit_code=completed.returncode)
    if completed.returncode==0:
        rows=[json.loads(x) for x in (root/(mode+'-build.jsonl')).read_text().splitlines()]
        binaries=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='compile_profile' and r.get('executable')]
        assert len(binaries)==1
        shutil.copy2(binaries[0],root/mode);record.update(binary=str(root/mode),binary_sha256=sha(root/mode))
    (root/(mode+'-build.json')).write_text(json.dumps(record,indent=2)+'\n')
    assert completed.returncode==0

def screen_native():
    records=[]
    link=Path('/private/tmp/mech-pr973-refresh-20261115/link')
    capture=json.loads((link/'capture/link-command.json').read_text())
    for mode in ['control','native-control']:
        out=root/('native-screen-'+mode);out.mkdir()
        command=[str(root/mode),'benchmark',str(out),'compact']
        (out/'command.json').write_text(json.dumps(dict(command=command,flags=dict(flags,MECH_COMPACT_COMPILE_THREADS='2'),compiler_sha256=sha(root/mode),scope='Preliminary native-CPU output and executable gate only; excluded from primary timing.'),indent=2)+'\n')
        with (out/'stdout.jsonl').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
            completed=subprocess.run(command,cwd=source,env=runtime,stdout=stdout,stderr=stderr)
        checks={}
        for name in ['source.mec','program.mecb','program.o','metadata.json']:
            checks[name]=dict(**pin(out/name),matches_frozen_reference=(out/name).read_bytes()==(root/'reference'/name).read_bytes())
        record=dict(mode=mode,exit_code=completed.returncode,files=checks)
        (out/'output-check.json').write_text(json.dumps(checks,indent=2)+'\n')
        assert completed.returncode==0 and all(r['matches_frozen_reference'] for r in checks.values())
        shutil.copy2(out/'program.o',link/'program.o')
        for item in capture['inputs']:
            assert pin(Path(item['source']))=={k:item[k] for k in ['bytes','sha256']}
        with (out/'link.stdout.log').open('w') as stdout,(out/'link.stderr.log').open('w') as stderr:
            completed=subprocess.run(capture['command'],env=dict(runtime,ZERO_AR_DATE='1'),stdout=stdout,stderr=stderr)
        assert completed.returncode==0 and (link/'worker').read_bytes()==(link/'worker-baseline').read_bytes()
        shutil.copy2(link/'worker',out/'worker');record.update(executable=pin(out/'worker'),matches_complete_baseline_executable=True)
        (out/'result.json').write_text(json.dumps(record,indent=2)+'\n');records.append(record)
        (root/'native-screen-results.json').write_text(json.dumps(records,indent=2)+'\n')

def train():
    out=root/'training';out.mkdir();inputs=out/'inputs';inputs.mkdir()
    env=dict(runtime,LLVM_PROFILE_FILE=str(root/'raw/%m-%p.profraw'))
    assert not list((root/'raw').glob('*.profraw'))
    cases=[('level12-deflate','benchmark'),('numeric-nested-phase','hosts/gpu/tests/fixtures/native/numeric-nested-phase.mec'),('numeric-private-fixed-nested','hosts/gpu/tests/fixtures/native/numeric-private-fixed-nested.mec'),('numeric-array-windows','hosts/gpu/tests/fixtures/native/numeric-array-windows.mec')]
    scalar={'scalar-bool-equal':'left<bool> == right<bool>\n','scalar-u64-add':'left<u64> + right<u64>\n','scalar-i64-divide':'left<i64> / right<i64>\n','scalar-f64-add':'left<f64> + right<f64>\n'}
    for name,text in scalar.items():
        path=inputs/(name+'.mec');path.write_text(text);cases.append((name,str(path)))
    results=[]
    prior=root
    for name,program in cases:
        directory=out/name;directory.mkdir()
        command=[str(root/'generate'),program,str(directory),'compact']
        (directory/'command.json').write_text(json.dumps(dict(command=command,runtime_flags=dict(flags,MECH_COMPACT_COMPILE_THREADS='2'),LLVM_PROFILE_FILE=env['LLVM_PROFILE_FILE'],instrumented_compiler_sha256=sha(root/'generate'),scope='Instrumented training only; no compiler performance qualification.'),indent=2)+'\n')
        started=time.monotonic()
        with (directory/'stdout.jsonl').open('w') as stdout,(directory/'stderr.log').open('w') as stderr:
            completed=subprocess.run(command,cwd=source,env=env,stdout=stdout,stderr=stderr)
        expected=root/'reference' if name=='level12-deflate' else root/'fixture-reference'/name/'control'
        checks={filename:dict(**pin(directory/filename),matches_frozen_unprofiled_control=(directory/filename).read_bytes()==(expected/filename).read_bytes()) for filename in ['source.mec','program.mecb','program.o','metadata.json']}
        results.append(dict(name=name,exit_code=completed.returncode,training_process_seconds=time.monotonic()-started,files=checks))
        (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
        assert completed.returncode==0 and all(r['matches_frozen_unprofiled_control'] for r in checks.values())
    raw=sorted((root/'raw').glob('*.profraw'));assert len(raw)==8
    (out/'profile-pins.json').write_text(json.dumps([dict(path=str(p),**pin(p)) for p in raw],indent=2)+'\n')
    tool=(root/'llvm-profdata-path.txt').read_text().strip();command=[tool,'merge','-o',str(root/'merged.profdata')]+[str(p) for p in raw]
    (out/'merge-command.json').write_text(json.dumps(command,indent=2)+'\n')
    with (out/'merge.stdout.log').open('w') as stdout,(out/'merge.stderr.log').open('w') as stderr:
        subprocess.run(command,stdout=stdout,stderr=stderr,check=True)
    (out/'merged-profile-pin.json').write_text(json.dumps(pin(root/'merged.profdata'),indent=2)+'\n')

stage('native-control',lambda:build('native-control'))
stage('native-output-gates',screen_native)
stage('generate',lambda:build('generate'))
stage('training',train)
stage('use',lambda:build('use'))
