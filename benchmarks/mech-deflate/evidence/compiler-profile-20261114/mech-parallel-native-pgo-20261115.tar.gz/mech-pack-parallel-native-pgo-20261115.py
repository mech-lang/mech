from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import sys

packet=Path('/private/tmp/mech-parallel-native-pgo-packet-20261115')
intermediate=Path('/private/tmp/mech-parallel-native-pgo-profilebundle-fastpack-20261115.tar.gz')
archive=Path('/private/tmp/mech-parallel-native-pgo-20261115.tar.gz')
command=[sys.executable,'benchmarks/mech-deflate/experiment.py','pack','--revision','0c949505cc708c233e27c094aa67e105068d6823','--input',str(packet),'--output',str(intermediate)]
completed=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
assert completed.returncode==0,completed.stderr
receipt=json.loads(completed.stdout)
assert not archive.exists()
with gzip.open(intermediate,'rb') as source,archive.open('xb') as output:
    with gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0,compresslevel=9) as dest:
        shutil.copyfileobj(source,dest,1024*1024)
receipt.update(archive_name=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),compression=dict(codec='gzip',level=9,mtime=0,method='Recompress exact tar stream from maintained pack tool; manifest/Git blobs/file bytes unchanged.',intermediate_sha256=receipt['sha256'],intermediate_bytes=receipt['bytes']))
Path(str(archive)+'.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps(receipt,indent=2,sort_keys=True))
