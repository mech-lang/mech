from pathlib import Path
import hashlib
import json
import lzma
import shutil
import tarfile

packet = Path('/private/tmp/mech-parallel-native-pgo-packet-20261115')
bundle = packet / 'profiles.tar.xz'
paths = sorted((packet / 'raw').glob('*.profraw')) + [packet / 'merged.profdata']
assert len(paths) == 9 and all(path.is_file() for path in paths)
pin = lambda path: dict(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
expected = {path.relative_to(packet).as_posix(): pin(path) for path in paths}
with lzma.open(bundle, 'xb', preset=9) as compressed:
    with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as archive:
        for path in paths:
            info = tarfile.TarInfo(path.relative_to(packet).as_posix())
            info.size = path.stat().st_size
            info.mtime = 0
            info.mode = 0o644
            with path.open('rb') as source:
                archive.addfile(info, source)
observed = {}
with tarfile.open(bundle, 'r|xz') as archive:
    for member in archive:
        assert member.isfile() and member.name in expected and member.name not in observed
        digest = hashlib.sha256()
        size = 0
        with archive.extractfile(member) as source:
            while chunk := source.read(1024 * 1024):
                size += len(chunk)
                digest.update(chunk)
        observed[member.name] = dict(bytes=size, sha256=digest.hexdigest())
assert observed == expected
receipt = dict(format=1, codec='xz', preset=9, path=bundle.name, **pin(bundle), members=expected,
               scope='Lossless nested storage of every original raw and merged profile byte. Stream verification equals all existing training pins before removing only redundant curated copies. Original raw experiment files are unchanged.')
(packet / 'profile-storage.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
shutil.rmtree(packet / 'raw')
(packet / 'merged.profdata').unlink()
shutil.copy2(__file__, packet / 'store-profiles.py')
print(json.dumps(receipt, indent=2, sort_keys=True), flush=True)
