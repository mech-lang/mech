from pathlib import Path, PurePosixPath
import datetime
import hashlib
import json
import shutil
import subprocess
import tarfile
import time
import tomllib

repo = Path.cwd()
root = Path('/private/tmp/mech-parallel-native-pgo-20261115')
root.mkdir(exist_ok=False)
source = root / 'source'
source.mkdir()
revision = '0c949505cc708c233e27c094aa67e105068d6823'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only',revision,'HEAD','--','src','hosts','vendor','Cargo.toml','Cargo.lock','.cargo','benchmarks/mech-deflate/native-profile/compile_profile.rs','benchmarks/mech-deflate/native-profile/Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.lock'],text=True).strip()
command = ['git','archive','--format=tar',revision,'--','.',':(exclude)benchmarks/mech-deflate/evidence']
started = time.monotonic()
process = subprocess.Popen(command,stdout=subprocess.PIPE,stderr=(root/'source-archive.stderr.log').open('w'))
files = 0
with tarfile.open(fileobj=process.stdout,mode='r|') as archive:
    for entry in archive:
        path = PurePosixPath(entry.name)
        assert not path.is_absolute() and '..' not in path.parts
        archive.extract(entry,source,filter='data')
        files += entry.isfile()
assert process.wait() == 0
assert tomllib.loads((source/'.cargo/config.toml').read_text())['build']['rustflags'] == ['-D','warnings']
state = dict(source_commit=revision,evidence_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),source_tree=subprocess.check_output(['git','rev-parse',revision+'^{tree}'],text=True).strip(),archive_command=command,excluded_path='benchmarks/mech-deflate/evidence (raw archives/index do not enter compilation)',files_extracted=files,seconds=time.monotonic()-started,created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Current retained source/compiler/program/runtime. Reuse immutable qualified standard6CE control; build nativeCPU instrumentation/training and nativeCPU profile use (no native-only subject or component-gain claim) with same compiler profile/61flags/twoworkers. No compiler production source edits. No cross-image additive gain.')
(root/'source-state.json').write_text(json.dumps(state,indent=2)+'\n')
prior = Path('/private/tmp/mech-parallel-phase-cleanup-20261115')
shutil.copy2(prior/'candidate',root/'control')
assert hashlib.sha256((root/'control').read_bytes()).hexdigest() == '6ce7a53b36d3677cf3b20d919657d2824b7d8561ef5eeaf254377626f27980ae'
shutil.copytree(prior/'reference',root/'reference')
shutil.copy2(prior/'runtime-flags.json',root/'runtime-flags.json')
shutil.copytree(prior/'fixtures',root/'fixture-reference')
shutil.copy2(prior/'fixture-results.json',root/'fixture-reference-results.json')
shutil.copy2(repo/'benchmarks/mech-deflate/native-profile/parallel-phase-cleanup-apple-m3-20261115.archive.json',root/'control-source-evidence-receipt.json')
commands = {
    'rustc-version':['rustc','+nightly-2026-03-03','-Vv'],
    'rustc-sysroot':['rustc','+nightly-2026-03-03','--print','sysroot'],
    'target-cpus':['rustc','+nightly-2026-03-03','--print','target-cpus','--target','aarch64-apple-darwin'],
    'generic-target-cfg':['rustc','+nightly-2026-03-03','--print','cfg','--target','aarch64-apple-darwin'],
    'native-target-cfg':['rustc','+nightly-2026-03-03','--print','cfg','--target','aarch64-apple-darwin','-C','target-cpu=native'],
    'cpu':['sysctl','-n','machdep.cpu.brand_string'],
    'cpu-count':['sysctl','-n','hw.ncpu'],
    'memory':['sysctl','-n','hw.memsize'],
    'os':['sw_vers','-productVersion'],
}
for name, args in commands.items():
    result = subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    (root/(name+'.txt')).write_text(result.stdout)
    (root/(name+'.stderr.log')).write_text(result.stderr)
    assert result.returncode == 0,(name,result.stderr)
sysroot = Path((root/'rustc-sysroot.txt').read_text().strip())
profdata = sysroot/'lib/rustlib/aarch64-apple-darwin/bin/llvm-profdata'
assert profdata.is_file()
(root/'llvm-profdata-path.txt').write_text(str(profdata)+'\n')
(root/'llvm-profdata-version.txt').write_text(subprocess.check_output([str(profdata),'--version'],text=True))
(root/'setup-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
(root/'control-reuse.json').write_text(json.dumps(dict(binary=str(root/'control'),bytes=(root/'control').stat().st_size,sha256=hashlib.sha256((root/'control').read_bytes()).hexdigest(),source_commit=revision,source_evidence_packet=44,standard_build= json.loads((prior/'candidate-build.json').read_text()),scope='No duplicate standard compiler rebuild. Exact retained 6CE standard compiler; nativeCPU+PGO candidate is a combined compiler-build configuration comparison. Explicit target used for every newly built compiler.'),indent=2)+'\n')
state['setup_complete'] = True
(root/'source-state.json').write_text(json.dumps(state,indent=2)+'\n')
print(json.dumps(state),flush=True)
