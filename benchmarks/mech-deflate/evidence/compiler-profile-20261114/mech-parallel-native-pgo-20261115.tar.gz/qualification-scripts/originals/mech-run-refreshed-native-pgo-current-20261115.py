from pathlib import Path
import json,subprocess,os,sys,hashlib,shutil
repo=Path.cwd();root=Path('/private/tmp/mech-refreshed-native-pgo-20261115/qualification');variant,name=sys.argv[1:3];mode=sys.argv[3] if len(sys.argv)>3 else None
flags=json.loads((root/'runtime-flags.json').read_text());assert len(flags)==61 and flags['MECH_COMPACT_REUSE_OVERWRITTEN_RESULT']=='1';env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')};env.update(flags);env['MECH_COMPACT_COMPILE_THREADS']='2'
if mode:assert mode in ['summary','detail'];env['MECH_PROFILE_EXIT_LIVENESS']=mode
cmd=[sys.executable,'benchmarks/mech-deflate/native-profile/profile_compile.py',str(root/variant),'benchmark',str(root/name),'compact'];assert not (root/name).exists();(root/(name+'-command.json')).write_text(json.dumps({'command':cmd,'flags':{k:v for k,v in env.items() if k.startswith('MECH_')},'binary_sha256':hashlib.sha256((root/variant).read_bytes()).hexdigest(),'profiling_excluded_from_primary':bool(mode)},indent=2)+'\n');p=subprocess.run(cmd,env=env,cwd=repo)
if p.returncode:raise SystemExit(p.returncode)
reference=root/'reference'
assert reference.is_dir(), 'Frozen current-source reference must be supplied before qualification'
report={}
for n in ['source.mec','program.mecb','program.o','metadata.json']:
 data=(root/name/n).read_bytes();report[n]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'matches_current_control_output':data==(reference/n).read_bytes()}
(root/name/'output-check.json').write_text(json.dumps(report,indent=2)+'\n');print('OUTPUTS',name,json.dumps(report),flush=True);assert all(r['matches_current_control_output'] for r in report.values()),'candidate/profiling changed generated output'
profiles=[]
for line in (root/name/'stderr.log').read_text().splitlines():
 if line.startswith('exit-liveness-profile: '):profiles.append(json.loads(line[len('exit-liveness-profile: '):]))
if mode:
 assert profiles and all(r['mode']==mode for r in profiles);assert [r['query'] for r in profiles]==list(range(len(profiles)))
 (root/name/'liveness-profiles.json').write_text(json.dumps(profiles,indent=2,sort_keys=True)+'\n');print('PROFILE_QUERIES',len(profiles),flush=True)
else:assert not profiles
