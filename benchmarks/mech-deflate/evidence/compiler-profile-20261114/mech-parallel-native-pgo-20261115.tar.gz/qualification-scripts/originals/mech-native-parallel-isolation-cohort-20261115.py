from pathlib import Path
import json,statistics,subprocess,sys
r=Path('/private/tmp/mech-parallel-phase-cleanup-20261115');script=r/'qualification-scripts/mech-run-native-parallel-isolation-20261115.py'
order=[(0,'threads0-1'),(2,'threads2-1'),(2,'threads2-2'),(0,'threads0-2'),(2,'threads2-3'),(0,'threads0-3'),(0,'threads0-4'),(2,'threads2-4')];rows=[]
for threads,name in order:
 command=[sys.executable,str(script),'candidate',name,str(threads)];print('START',name,flush=True);subprocess.run(command,check=True);row=json.loads((r/name/'result.json').read_text());row['name']=name;rows.append(row);(r/'parallel-isolation-cohort.json').write_text(json.dumps(rows,indent=2)+'\n')
summary={}
for key in ['source_to_executable_seconds','source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']:
 values={label:[row[key] for row in rows if row['compile_threads']==threads] for label,threads in [('serial',0),('parallel',2)]};values['mean_reduction_fraction']=1-statistics.mean(values['parallel'])/statistics.mean(values['serial']);summary[key]=values
blocks=[]
for block in [rows[:4],rows[4:]]:
 values={label:statistics.mean(row['source_to_executable_seconds'] for row in block if row['compile_threads']==threads) for label,threads in [('serial',0),('parallel',2)]};values['mean_reduction_fraction']=1-values['parallel']/values['serial'];blocks.append(values)
result=dict(numerical_summary=summary,balanced_blocks=blocks,order=order,scope='Separate pure worker-count comparison0versus2withonefrozen candidatecompiler executable, same61programflags/currentruntime/cache. ABBA/BAAB eightuncontendedfullbuilds. Thisdoesnot pooloraddtheold2versusnew2compiler comparison, Objectcohort orpreviousPGO gains.')
(r/'parallel-isolation-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
