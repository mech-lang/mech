Frozen3file same-plan direct action output inventory optimization on base08019220f0.
OldC5B versus new957 compiler, same61programflags,2workers,pinnedcompilerallocator.
No grammar/language, eligibility/proof, finite admission/accounting or emitted
program changes. Original live_before/scopes ordering and complete per-phase
scope/type/definition/read queries remain. One lazy complete sorted output map
is shared by exact immutable NativeProgramFacts owner; no authority is cached.
Seven focused tests and realnativeCLIcheck pass. Firstfocusedlink setup fails
on Apple libLTO15/RustLLVM22 bitcode mismatch; no tests execute. Originalfailure
anddriver remain. MatchingRustThinLTO retry passes withoutsourcechange.
Two exactfullnativegates precede primarytimings. Fourteenfixturepairs and eight
Object ABBA/BAAB observations retain every4output/fullmetadata byte. Eight
separate fullnative builds and an unpaireddefault0gate retain entireexecutable.
Compiler/build/test/profile/hash/archive jobs do not overlap primarytiming.
Runtime/entryadapter cached and every nativeinput pinned. Firstuse11.882560208s
is historicalandexcluded. Complete source-to-exe16.032216->15.689968s(-2.13475%),
bothblocks improve. Preparation-20.4824%,instructions-2.02725%; alladversefields
andtheinitialslightlyslowercompletepair remain. No newruntimecampaign or
subtensecondresult claimed. Sourcethreefilecommit mustexactlymatchfrozenpatch.
Compiler/test executables and setupobjectproducts excludedandhashpinned.
Everyprogramartifact/executable,nativeinput,source/patch,command/log,setupfailure,
rawobservationandpureoffline replay remain. PriorcurrentC5B profiles are already
publishedinpacket37; its hashpinnedreceipt references theirselectionevidence.
