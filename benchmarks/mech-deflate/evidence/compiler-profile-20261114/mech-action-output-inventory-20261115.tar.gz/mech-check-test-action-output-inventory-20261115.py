from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path('/private/tmp/mech-action-output-inventory-20261115')
state = json.loads((root / 'source-state.json').read_text())
assert subprocess.check_output(['git', 'diff', '--binary']) == (root / 'candidate.patch').read_bytes()
assert json.loads((root / 'candidate-build.json').read_text())['exit_code'] == 0
env = dict(os.environ, CARGO_TARGET_DIR='/private/tmp/mech-level12-compile-target', CARGO_INCREMENTAL='0')
assert not env.get('RUSTFLAGS') and not env.get('CARGO_ENCODED_RUSTFLAGS')

def run(stage, command, directory):
    started = time.monotonic()
    with (directory / (stage + '.stdout.log')).open('w') as stdout, (directory / (stage + '.stderr.log')).open('w') as stderr:
        completed = subprocess.run(command, env=env, stdout=stdout, stderr=stderr)
    row = dict(command=command, exit_code=completed.returncode, seconds=time.monotonic()-started,
               base_commit=state['base_commit'], patch_sha256=state['patch_sha256'])
    (directory / (stage + '.json')).write_text(json.dumps(row, indent=2) + '\n')
    print(json.dumps(dict(stage=stage, **row)), flush=True)
    assert completed.returncode == 0

out = root / 'focused'
out.mkdir()
source = Path('benchmarks/mech-deflate/native-profile/exit_definitions_tests.rs')
rows = [json.loads(line) for line in (root / 'candidate-build.jsonl').read_text().splitlines()]
dependencies = []
command = ['rustc', '+nightly-2026-03-03', '--edition=2024', '--crate-name', 'action_output_inventory_tests', '--test', str(source), '-C', 'opt-level=3', '-C', 'lto=thin', '-C', 'codegen-units=1', '-D', 'warnings']
for name in ['mech_engine', 'mech_core', 'mech_syntax', 'mech_stdlib', 'serde_json']:
    files = [Path(p) for row in rows if row.get('reason') == 'compiler-artifact' and row.get('target', {}).get('name') == name for p in row['filenames'] if p.endswith('.rlib')]
    assert len(files) == 1, (name, files)
    dependency = files[0]
    if not dependencies:
        command += ['-L', 'dependency=' + str(dependency.parent)]
    dependencies.append(dict(name=name, path=str(dependency), sha256=hashlib.sha256(dependency.read_bytes()).hexdigest()))
    command += ['--extern', name + '=' + str(dependency)]
command += ['-o', str(out / 'tests')]
(out / 'configuration.json').write_text(json.dumps(dict(source=str(source), source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(), dependencies=dependencies, scope='Existing exact production definition selection plus new actual engine same-plan output inventory API. Original/decoded plans, cache reuse/order/uniqueness, duplicate/sparse invalid IDs, whole-inventory error demand and plan owner isolation. Malformed metadata confined to descriptive queries, never emission/admission/execution.'), indent=2) + '\n')
run('build', command, out)
run('test', [str(out / 'tests'), '--nocapture'], out)
assert 'test result: ok. 7 passed; 0 failed' in (out / 'test.stdout.log').read_text()
run('candidate-cli-check', ['cargo', '+nightly-2026-03-03', 'check', '--locked', '--offline', '--profile', 'compiler', '-j4', '--manifest-path', 'Cargo.toml', '--bin', 'mech', '--features', 'cranelift_build', '--message-format=json'], root)
assert subprocess.check_output(['git', 'diff', '--binary']) == (root / 'candidate.patch').read_bytes()
