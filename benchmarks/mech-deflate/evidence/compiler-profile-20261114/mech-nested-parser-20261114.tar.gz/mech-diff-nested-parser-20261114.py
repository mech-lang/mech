from pathlib import Path
import subprocess,json,time,os,hashlib
repo=Path.cwd();root=Path('/private/tmp/mech-nested-parser-20261114');p=root/'probes';prefix=json.loads((root/'probe-recipe.json').read_text())['command_prefix'];env=dict(os.environ,CARGO_MANIFEST_DIR=str(repo/'src/syntax'));patch=subprocess.check_output(['git','diff','HEAD','--binary'])
for variant in ['control','candidate']:
 for kind in ['differential','timing']:
  src=p/(variant+'-'+kind+'.rs')
  if kind=='timing':
   text=Path('/private/tmp/mech-parser-dispatch-probes-20261113/final/main.rs').read_text();base=root/'control-source' if variant=='control' else repo;src.write_text(text.replace('#[path = "src/syntax/src/document/mod.rs"]','#[path = '+json.dumps(str(base/'src/syntax/src/document/mod.rs'))+']'))
  cmd=[*prefix,'--crate-name','canonical_nested_parser_'+variant+'_'+kind,str(src),'-o',str(p/'bin'/(variant+'-'+kind))];start=time.perf_counter();r=subprocess.run(cmd,capture_output=True,env=env);(p/(variant+'-'+kind+'-build.stderr')).write_bytes(r.stderr);record={'command':cmd,'exit_code':r.returncode,'seconds':time.perf_counter()-start};(p/(variant+'-'+kind+'-build.json')).write_text(json.dumps(record,indent=2)+'\n');print(variant,kind,'build',r.returncode,flush=True)
  if r.returncode:print(r.stderr.decode());raise SystemExit(r.returncode)
 cases=(p/'differential-cases.jsonl').read_bytes();cmd=[str(p/'bin'/(variant+'-differential'))];start=time.perf_counter();r=subprocess.run(cmd,input=cases,capture_output=True,env=env);(p/(variant+'-differential.jsonl')).write_bytes(r.stdout);(p/(variant+'-differential.stderr')).write_bytes(r.stderr);(p/(variant+'-differential-run.json')).write_text(json.dumps({'command':cmd,'exit_code':r.returncode,'seconds':time.perf_counter()-start},indent=2)+'\n');print(variant,'differential',r.returncode,flush=True)
  # Every input result must be present, including refusals/recovery diagnostics.
 if r.returncode:print(r.stderr.decode());raise SystemExit(r.returncode)
 assert len(r.stdout.splitlines())==len(cases.splitlines())
a=(p/'control-differential.jsonl').read_bytes();b=(p/'candidate-differential.jsonl').read_bytes();result={'cases':len(cases.splitlines()),'control_sha256':hashlib.sha256(a).hexdigest(),'candidate_sha256':hashlib.sha256(b).hexdigest(),'bytes':len(a),'byte_identical':a==b};(p/'differential-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
assert a==b
observations=[]
for variant,name in [('control','control-1'),('candidate','candidate-1'),('candidate','candidate-2'),('control','control-2')]:
 cmd=[str(p/'bin'/(variant+'-timing')),str(root/'reference/source.mec'),'1'];r=subprocess.run(cmd,capture_output=True,env=env);(p/(name+'-timing.stdout')).write_bytes(r.stdout);(p/(name+'-timing.stderr')).write_bytes(r.stderr);assert r.returncode==0;row={'variant':variant,'name':name,'command':cmd,'result':json.loads(r.stdout)};observations.append(row);print(json.dumps(row),flush=True)
(p/'timing-screen.json').write_text(json.dumps(observations,indent=2)+'\n');assert subprocess.check_output(['git','diff','HEAD','--binary'])==patch
