from pathlib import Path
import subprocess,json,time,os,hashlib
repo=Path.cwd();root=Path('/private/tmp/mech-nested-parser-20261114');p=root/'probes';recipe=json.loads((root/'probe-recipe.json').read_text());cmd=[*recipe['command_prefix'],'--crate-name','canonical_nested_parser_unit','--test',str(p/'unit.rs'),'-o',str(p/'bin/parser-tests')]
patch=subprocess.check_output(['git','diff','HEAD','--binary']);(root/'tested-source.patch').write_bytes(patch)
env=dict(os.environ,CARGO_MANIFEST_DIR=str(repo/'src/syntax'));start=time.perf_counter()
r=subprocess.run(cmd,capture_output=True,env=env);(p/'unit-build.stdout').write_bytes(r.stdout);(p/'unit-build.stderr').write_bytes(r.stderr);record={'command':cmd,'exit_code':r.returncode,'seconds':time.perf_counter()-start,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'patch_sha256':hashlib.sha256(patch).hexdigest()};(p/'unit-build.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
if r.returncode:print(r.stderr.decode());raise SystemExit(r.returncode)
cmd=[str(p/'bin/parser-tests'),'--test-threads=2'];start=time.perf_counter()
with (p/'unit-tests.stdout').open('wb') as out,(p/'unit-tests.stderr').open('wb') as err:r=subprocess.run(cmd,env=env,stdout=out,stderr=err)
record={'command':cmd,'exit_code':r.returncode,'seconds':time.perf_counter()-start};(p/'unit-tests.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);print((p/'unit-tests.stdout').read_text()[-7000:]);print((p/'unit-tests.stderr').read_text()[-3000:]);assert subprocess.check_output(['git','diff','HEAD','--binary'])==patch
raise SystemExit(r.returncode)
