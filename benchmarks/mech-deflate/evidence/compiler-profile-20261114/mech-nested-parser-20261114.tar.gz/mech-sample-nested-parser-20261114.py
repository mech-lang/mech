from pathlib import Path
import subprocess,json,os,time,threading,queue,hashlib
root=Path('/private/tmp/mech-nested-parser-20261114');out=root/'profile';out.mkdir();flags=json.loads((root/'runtime-flags.json').read_text());env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')};env.update(flags)
cmd=[str(root/'candidate'),'benchmark',str(out),'compact'];(out/'command.json').write_text(json.dumps({'command':cmd,'flags':flags,'binary_sha256':hashlib.sha256((root/'candidate').read_bytes()).hexdigest(),'scope':'Separate diagnostic compile after all unprofiled primary observations; sampled durations are excluded from qualification.'},indent=2)+'\n')
start=time.monotonic();jobs=queue.Queue();records=[]
with (out/'stdout.jsonl').open('w') as stdout:
 process=subprocess.Popen(cmd,env=env,stdout=stdout,stderr=subprocess.PIPE,text=True,bufsize=1)
 def sample_jobs():
  while (job:=jobs.get()) is not None:
   name,trigger=job;path=out/(name+'.sample.txt');command=['/usr/bin/sample',str(process.pid),'1','5','-mayDie','-file',str(path)];begin=time.monotonic()-start
   with (out/(name+'.sample.log')).open('w') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
   record={'phase':name,'trigger':trigger,'command':command,'started':begin,'finished':time.monotonic()-start,'exit_code':r.returncode,'sample_present':path.exists()};records.append(record);(out/'samples.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(record),flush=True)
 worker=threading.Thread(target=sample_jobs);worker.start();seen=set()
 with (out/'stderr.log').open('w') as raw,(out/'stages.jsonl').open('w') as staged:
  for line in process.stderr:
   raw.write(line);raw.flush();row={'elapsed':time.monotonic()-start,'line':line.rstrip()};staged.write(json.dumps(row)+'\n');staged.flush()
   for name,prefix in [('parse','compile-profile: pid='),('frontend','compile-profile: phase=frontend'),('preparation','compact-stage: preparation blocks='),('helpers','compact-stage: native module'),('source-cfg','compact-stage: source CFG'),('cleanup','compact-stage: CFG cleanup'),('backend','compact-stage: machine code')]:
    if name not in seen and line.startswith(prefix):seen.add(name);jobs.put((name,row))
 code=process.wait();jobs.put(None);worker.join()
(out/'process.json').write_text(json.dumps({'exit_code':code,'elapsed_seconds':time.monotonic()-start,'samples':len(records),'scope':'diagnostic only; not a primary timing observation'},indent=2)+'\n');assert code==0 and len(records)==7 and all(r['exit_code']==0 and r['sample_present'] for r in records)
checks={}
for n in ['source.mec','program.mecb','program.o','metadata.json']:
 data=(out/n).read_bytes();assert data==(root/'reference'/n).read_bytes();checks[n]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'matches_current_control_output':True}
(out/'output-check.json').write_text(json.dumps(checks,indent=2)+'\n')
