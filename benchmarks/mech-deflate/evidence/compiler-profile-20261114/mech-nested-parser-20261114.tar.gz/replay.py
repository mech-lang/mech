from pathlib import Path
import json,hashlib,re,statistics,tomllib
root=Path(__file__).resolve().parent;raw=root/'compiler'
read=lambda p:json.loads(p.read_text())
def pin(p):
 data=p.read_bytes();return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
state=read(root/'source-state.json');build=read(raw/'candidate-build.json');control=read(raw/'control-origin.json');patch=pin(root/'source-change.patch');assert patch==pin(raw/'candidate.patch') and patch['sha256']==state['patch_sha256']==build['patch_sha256']
assert build['exit_code']==0 and build['head']==state['base_commit'] and state['control_production_source_identical_to_base']
prior=read(root/'validation/qualified-exit-definitions.json');receipt=read(root/'validation/qualified-exit-definitions.archive.json');assert pin(root/'validation/qualified-exit-definitions.json')['sha256']==receipt['replay_sha256'];assert control['sha256']==prior['compiler_binary_sha256']['candidate'] and control['source_commit']==state['control_source_commit']==prior['source_commit']
flags=read(raw/'runtime-flags.json');assert len(flags)==60;expected=prior['output_hashes'];assert read(raw/'reference-pins.json')==expected
excluded={r['path']:r for r in read(root/'excluded-executables.json')};assert excluded['compiler/control']['sha256']==control['sha256'] and excluded['compiler/candidate']['sha256']==build['binary_sha256'] 
profile_settings={}
for name in ['Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.toml']:
 before=tomllib.loads((root/'source-base'/name).read_text());after=tomllib.loads((root/'source'/name).read_text());assert after['profile']==before['profile'];profile_settings[name]=after['profile']['compiler']
assert '--profile' in build['command'] and build['command'][build['command'].index('--profile')+1]=='compiler' and '--release' not in build['command']
stage_fields=[('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]
host_fields=[('max_rss_bytes',r'(\d+)  maximum resident set size'),('instructions',r'(\d+)  instructions retired'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]
order=['control-1','candidate-1','candidate-2','control-2','candidate-3','control-3','control-4','candidate-4']
def validate_cohort(raw,flags,expected,pins,key):
 rows=read(raw/'cohort.json');assert [r['name'] for r in rows]==order
 for name in ['control-screen','candidate-screen',*order]:
  variant=name.split('-')[0];d=raw/name;process=read(d/'process.json');assert process['exit_code']==0 and process['samples']==0 and process['sampling_error'] is None
  command=read(raw/(name+'-command.json'));assert command['flags']==flags and command['binary_sha256']==pins[variant]
  for filename,pinned in expected.items():assert pin(d/filename)==pinned and read(d/'output-check.json')[filename]==dict(pinned,**{key:True})
 for row in rows:
  d=raw/row['name'];assert row['compile']==read(d/'compile.json') and row['process']==read(d/'process.json') and row['files']==read(d/'output-check.json')
  assert row['variant']==row['name'].split('-')[0]
  stamps=[json.loads(line) for line in (d/'stages.jsonl').read_text().splitlines()]
  for field,begin,end in stage_fields:assert row[field]==next(s['elapsed'] for s in stamps if s['line'].startswith(end))-next(s['elapsed'] for s in stamps if s['line'].startswith(begin))
  for field,pattern in host_fields:assert row[field]==int(re.search(pattern,(d/'stderr.log').read_text()).group(1))
  if True:
   begin=next(s for s in stamps if s['line'].startswith('compact-stage: compact values before='));end=next(s for s in stamps if s['line'].startswith('compact-stage: CFG cleanup'));assert row['compaction_seconds']==end['elapsed']-begin['elapsed'];assert row['value_ids_before']==int(begin['line'].split('=')[-1])==20787570;assert row['value_ids_after']==int(next(s['line'] for s in stamps if s['line'].startswith('compact-values: retained=')).split('=')[-1])==1241393
  else:assert row['compaction_seconds']==0
  assert row['cleanup_including_compaction_seconds']==row['cleanup_seconds']+row['compaction_seconds']
 fixtures=read(raw/'fixture-results.json');assert len(fixtures)==14
 for record in fixtures:
  assert record['all_outputs_match'] and record['variants']['control']==record['variants']['candidate'] and record['variants']['control']['exit_code']==0 and len(record['variants']['control']['files'])==4
  name=Path(record['fixture']).stem if ':' not in record['fixture'] else record['fixture'].split(':')[-1]
  for variant,result in record['variants'].items():
   d=raw/'fixtures'/name/variant;command=read(d/'command.json');assert command['flags']==flags and command['binary_sha256']==pins[variant]
   for filename,pinned in result['files'].items():assert pin(d/filename)==pinned
   assert result['files']['source.mec']['sha256']==record['source_sha256']
 base=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase.mec').read_text();fragment=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase-states.mec').read_text();assembled=base.replace('+> sequence\n','+> sequence\n'+fragment+'\n',1).replace('phase-candidates(values, 1u64, 0u64, permitted, divisor)','#PhaseCandidates(values, permitted, divisor, 1u64, 0u64)',1);assert assembled==(raw/'fixture-inputs/numeric-nested-phase-states.mec').read_text()
 fields={'compiler_seconds':lambda r:r['compile']['total_seconds'],'whole_process_seconds':lambda r:r['process']['elapsed_seconds']}
 for phase in ['parse','catalog','frontend','artifact','encode','native']:fields[phase+'_seconds']=lambda r,p=phase:next(v['seconds'] for v in r['compile']['phases'] if v['phase']==p)
 for field in [f[0] for f in stage_fields]+['cleanup_including_compaction_seconds','compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:fields[field]=lambda r,k=field:r[k]
 qualified={field:{v:[fn(r) for r in rows if r['variant']==v] for v in ['control','candidate']} for field,fn in fields.items()}
 for values in qualified.values():
  mean=statistics.mean(values['control']);values['mean_reduction_fraction']=1-statistics.mean(values['candidate'])/mean if mean else None
 assert qualified==read(raw/'numerical-summary.json')
 blocks=[]
 for block in [rows[:4],rows[4:]]:
  blocks.append(dict(order=[r['name'] for r in block],compiler_mean_reduction_fraction=1-statistics.mean(r['compile']['total_seconds'] for r in block if r['variant']=='candidate')/statistics.mean(r['compile']['total_seconds'] for r in block if r['variant']=='control')))
 return dict(flags_count=len(flags),qualified=qualified,blocks=blocks,output_hashes=expected,compiler_binary_sha256=pins,fixture_output_comparisons=fixtures)

qualification=validate_cohort(raw,flags,expected,{'control':control['sha256'],'candidate':build['binary_sha256']},'matches_current_control_output')
proof=read(raw/'source-equivalence-check.json');assert set(proof['changed_files'])=={'src/syntax/src/document/parser/canonical/base/continuation.rs','src/syntax/src/document/parser/canonical/prediction.rs','src/syntax/src/document/parser/canonical/prediction_tests.rs'}
name='src/syntax/src/document/parser/canonical/prediction.rs';before=(root/'source-base'/name).read_text();after=(root/'source'/name).read_text()
a='    let cache = p\n        .state\n        .base_storage\n        .prediction\n        .get_or_insert_with(|| alloc::boxed::Box::new([None; base::NON_FIXED_RULES.len()]));';b='    let cache =\n        cache.get_or_insert_with(|| alloc::boxed::Box::new([None; base::NON_FIXED_RULES.len()]));'
assert a in before and b in after;before=before.replace(a,'    CACHE');after=after.replace(b,'    CACHE').replace('    cache: &mut Option<alloc::boxed::Box<[Option<Plan>; base::NON_FIXED_RULES.len()]>>,\n','',1);assert before==after
assert proof['normalized_prediction_source_sha256']==hashlib.sha256(before.encode()).hexdigest() and all(proof[k] for k in ['prediction_admission_and_summary_calculations_byte_identical_except_explicit_cache_borrow','grammar_productions_and_shared_specifications_unchanged','changes_limited_to_nested_dispatch_cache_borrow_and_tests'])
probe=raw/'probes';unit=read(probe/'unit-build.json');tests=read(probe/'unit-tests.json');assert unit['exit_code']==tests['exit_code']==0 and unit['head']==state['base_commit'] and unit['patch_sha256']==state['patch_sha256'];assert pin(raw/'tested-source.patch')==pin(root/'source-change.patch')
text=(probe/'unit-tests.stdout').read_text();assert 'test result: ok. 526 passed; 0 failed;' in text
for name in ['nested_base_predictions_keep_complete_traces_across_work_slices','nested_predictions_survive_input_sealing_and_suspended_storage','prediction_cache_returns_from_nested_calls_to_the_same_parser']:assert name+' ... ok' in text
cases=(probe/'differential-cases.jsonl').read_bytes().splitlines();assert len(cases)==1667
comparison=read(probe/'differential-result.json');assert comparison['byte_identical'] and comparison['cases']==1667
for variant in ['control','candidate']:
 for kind in ['differential','timing']:assert read(probe/(variant+'-'+kind+'-build.json'))['exit_code']==0
 assert read(probe/(variant+'-differential-run.json'))['exit_code']==0
 data=(probe/(variant+'-differential.jsonl')).read_bytes();assert len(data)==comparison['bytes'] and hashlib.sha256(data).hexdigest()==comparison[variant+'_sha256'];assert len(data.splitlines())==1667
assert comparison['control_sha256']==comparison['candidate_sha256']
screens=read(probe/'timing-screen.json');assert [r['variant'] for r in screens]==['control','candidate','candidate','control'];semantic=None
for row in screens:
 observed=read(probe/(row['name']+'-timing.stdout'));assert observed==row['result'];fields={k:v for k,v in observed.items() if k!='seconds'}
 if semantic is None:semantic=fields
 else:assert fields==semantic
assert semantic['source_bytes']==expected['source.mec']['bytes'] and semantic['parser_steps']==1967640 and semantic['events_emitted']==434637 and semantic['new_node_count']==92316 and semantic['recovery_bytes']==0
profile=raw/'profile';profile_command=read(profile/'command.json');assert profile_command['flags']==flags and profile_command['binary_sha256']==build['binary_sha256'];samples=read(profile/'samples.json');assert [s['phase'] for s in samples]==['parse','frontend','preparation','helpers','source-cfg','cleanup','backend']
assert read(profile/'process.json')['exit_code']==0 and len(samples)==7
for sample in samples:assert sample['exit_code']==0 and sample['sample_present'] and (profile/(sample['phase']+'.sample.txt')).is_file()
for name,pinned in expected.items():assert pin(profile/name)==pinned and read(profile/'output-check.json')[name]==dict(pinned,matches_current_control_output=True)
cpu=read(profile/'self-sample-summary.json');names=read(profile/'symbols.json');reconstructed={}
for sample in samples:
 phase=sample['phase'];text=(profile/(phase+'.sample.txt')).read_text();text=re.sub(r'\b_R[A-Za-z0-9_]+',lambda m:names[m[0]],text);assert text==(profile/(phase+'.sample.demangled.txt')).read_text()
 section=text.split('Sort by top of stack, same collapsed (when >= 5):\n',1)[1].split('\nBinary Images:',1)[0];active=[];waiting=[]
 for line in section.splitlines():
  match=re.match(r'\s*(.*?)\s+\(in ([^)]+)\)\s+(\d+)\s*$',line)
  if not match:continue
  row={'symbol':match[1],'image':match[2],'self_samples':int(match[3])};(waiting if any(x in match[1] for x in ['wait','pthread_join','semaphore','kevent']) else active).append(row)
 reconstructed[phase]={'top_self_at_least_5':active,'waiting_excluded':waiting}
assert cpu['windows']==reconstructed and read(raw/'format-check.json')['exit_code']==0
summary=dict(source_commit=state['source_commit'],base_commit=state['base_commit'],control_source_commit=state['control_source_commit'],hardware=state['hardware'],decision='Retain nested existing canonical base predictions; exact cache owner, original accounting, unchanged grammar and identical generated program bytes',candidate_patch_sha256=state['patch_sha256'],profile_settings=profile_settings,candidate_rebuild_seconds=build['seconds'],rebuild_scope='Observed locked/offline optimized-profile rebuild with existing Cargo caches. Excluded from Mech compilation timing; no matched cold-bootstrap comparison.',compiler_executable_bytes={v:excluded['compiler/'+v]['bytes'] for v in ['control','candidate']},source_equivalence_checks=proof,document_unit_tests_passed=526,parser_differential=comparison,standalone_parser_screen=screens,parser_public_observations=semantic,diagnostic_sample_windows=samples,diagnostic_cpu_samples=cpu,next_optimization_target=read(raw/'next-target.json'),scope=[
 'Eight serial fresh source-to-Object primary observations in ABBA then BAAB order, identical 60 runtime flags and compiler build profile. No cached Object or decoded-only substitute. Both subjects retain SSA compaction and its elapsed cost.',
 'Builds, tests, standalone probes, fixtures, sampling, hashing, copying and archive work do not overlap primary timing. Both screens, all primary runs and fourteen successful fixture pairs match source, MBC, Object and complete metadata bytes.',
 'Existing bounded grammar-derived predictions now apply before charging every eligible pending base Call frame, including nested calls. The same active continuation owns the fixed grammar-summary cache until storage returns to the same parser. No semantic-result or cross-visit cache is added.',
 'All prediction admission, logical work, fuel/event limits, peaks, rewind summaries, Unicode/context boundaries and grammar calculations remain byte-identical except for the explicit cache borrow. Shared base/operator specifications and grammar productions are unchanged.',
 '526 production document-module unit tests and 1,667 complete control/candidate parse comparisons pass. New tests cover work slices around 4096, resource limits, Unicode, input sealing, suspension/resumption and cache ownership. Standalone probes link the same coherent pinned release dependency set; only SourceLocation records come from mech-core. Full production builds use current locked compiler-profile dependencies.',
 'Standalone parser elapsed values are screening diagnostics, distinct from full compiler timing. Seven separate one-second CPU windows on a diagnostic full compile are excluded from qualification. Samples can cross phase boundaries and include waiting threads; they are not exclusive elapsed-time attribution.',
 'The generated machine code and complete metadata remain identical. Direct scalar emission, checked errors, fresh current shape/factory/visit/ownership checks, finite admission, resource accounting and backend settings remain. No execution machinery is retired and no new compressor-runtime latency campaign is claimed.',
 'Setup failures and every observation remain in the archive. Complete compilation remains above ten seconds.'
],**qualification)
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
