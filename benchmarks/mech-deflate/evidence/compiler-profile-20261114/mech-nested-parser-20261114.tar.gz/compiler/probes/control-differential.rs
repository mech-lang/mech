extern crate alloc;
#[path="/private/tmp/mech-nested-parser-20261114/control-source/src/syntax/src/document/mod.rs"] pub mod document;
use document::*;
use std::io::BufRead;
fn tree(node:&GreenNode,out:&mut Vec<serde_json::Value>){
 out.push(serde_json::json!(["start",node.id.0,node.kind as u16,node.flags.0,node.text_len.0,node.structural_hash]));
 for child in node.children.iter(){match child {
   GreenElement::Node(node)=>tree(node,out),
   GreenElement::Token(t)=>out.push(serde_json::json!(["token",t.id.0,t.kind as u16,t.flags.0,t.text_len.0,t.text_hash])),
 }}
 out.push(serde_json::json!(["finish"]));
}
fn main(){
 for line in std::io::stdin().lock().lines(){
  let case:serde_json::Value=serde_json::from_str(&line.unwrap()).unwrap();
  let mut config=ParseConfig::default();
  if let Some(value)=case.get("fuel"){config.limits.fuel=value.as_u64().unwrap();}
  if let Some(value)=case.get("events"){config.limits.max_events=value.as_u64().unwrap() as u32;}
  if let Some(value)=case.get("nesting"){config.limits.max_nesting=value.as_u64().unwrap() as u32;}
  if let Some(value)=case.get("diagnostics"){config.limits.max_diagnostics=value.as_u64().unwrap() as u32;}
  if let Some(value)=case.get("recovery"){config.limits.max_recovery_bytes=value.as_u64().unwrap() as u32;}
  let parsed=parse_canonical_document(TextSnapshot::new(DocumentId(0x50524f47),Revision(1),case["text"].as_str().unwrap()).unwrap(),config);
  let mut nodes=Vec::new();tree(&parsed.root,&mut nodes);
  println!("{}",serde_json::json!({"id":case["id"],"tree":nodes,"diagnostics":parsed.diagnostics.iter().collect::<Vec<_>>(),"stats":format!("{:?}",parsed.stats),"restarts":format!("{:?}",parsed.restarts)}));
 }
}
