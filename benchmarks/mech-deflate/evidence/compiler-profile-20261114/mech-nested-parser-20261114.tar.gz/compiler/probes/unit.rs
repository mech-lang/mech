extern crate alloc;
#[path="/Users/cim310/.codex/worktrees/level12-compile-profile/mech/src/syntax/src/document/mod.rs"] pub mod document;
#[cfg(test)] #[path="/Users/cim310/.codex/worktrees/level12-compile-profile/mech/src/core/tests/support/allocation_probe.rs"] mod allocation_probe;
#[cfg(test)] #[global_allocator] static TEST_ALLOCATOR:allocation_probe::ProbeAllocator=allocation_probe::ProbeAllocator;
