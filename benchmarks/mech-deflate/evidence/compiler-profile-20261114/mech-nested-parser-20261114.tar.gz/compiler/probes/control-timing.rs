extern crate alloc;
#[path = "/private/tmp/mech-nested-parser-20261114/control-source/src/syntax/src/document/mod.rs"]
pub mod document;
use document::{AstNode,DocumentId,DocumentSyntax,ParseConfig,Revision,TextSnapshot,parse_canonical_document};
fn main(){
 let args:Vec<_>=std::env::args().collect();
 let source=std::fs::read_to_string(&args[1]).unwrap();
 let repetitions:usize=args.get(2).map_or(1,|s|s.parse().unwrap());
 for _ in 0..repetitions {
  let start=std::time::Instant::now();
  let parsed=parse_canonical_document(TextSnapshot::new(DocumentId(0x50524f47),Revision(1),source.as_str()).unwrap(),ParseConfig::default());
  assert!(parsed.is_strictly_clean(),"{:?}",parsed.diagnostics);
  std::hint::black_box(DocumentSyntax::cast(parsed.syntax()).unwrap());
  let seconds=start.elapsed().as_secs_f64();
  println!("{}",serde_json::json!({"seconds":seconds,"structural_hash":parsed.root.structural_hash,"parser_steps":parsed.stats.parser_steps,"events_emitted":parsed.stats.events_emitted,"recovery_bytes":parsed.stats.recovery_bytes,"new_node_count":parsed.stats.new_node_count,"source_bytes":source.len()}));
 }
}
