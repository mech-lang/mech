from pathlib import Path
import subprocess,json,shutil,hashlib,tarfile,io
repo=Path.cwd();root=Path('/private/tmp/mech-nested-parser-20261114');root.mkdir();prior=Path('/private/tmp/mech-exit-definitions-20261114')
summary_path=repo/'benchmarks/mech-deflate/native-profile/exit-definitions-compile-apple-m3-20261114.json';summary=json.loads(summary_path.read_text());control=root/'control';shutil.copy2(prior/'candidate',control);control.chmod(0o755);sha=hashlib.sha256(control.read_bytes()).hexdigest();assert sha==summary['compiler_binary_sha256']['candidate']
(root/'control-origin.json').write_text(json.dumps({'source_commit':summary['source_commit'],'sha256':sha,'copied_from':str(prior/'candidate'),'qualification_result':str(summary_path.relative_to(repo)),'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()},indent=2)+'\n');shutil.copy2(prior/'runtime-flags.json',root/'runtime-flags.json');(root/'reference').mkdir()
for n in ['source.mec','program.mecb','program.o','metadata.json']:shutil.copy2(prior/'candidate-1'/n,root/'reference'/n)
(root/'reference-pins.json').write_text(json.dumps({n:{'bytes':(root/'reference'/n).stat().st_size,'sha256':hashlib.sha256((root/'reference'/n).read_bytes()).hexdigest()} for n in ['source.mec','program.mecb','program.o','metadata.json']},indent=2,sort_keys=True)+'\n')
archive=subprocess.check_output(['git','archive','HEAD','src/syntax']);snapshot=root/'control-source';snapshot.mkdir()
with tarfile.open(fileobj=io.BytesIO(archive)) as t:t.extractall(snapshot,filter='data')
rows=[json.loads(line) for line in (prior/'candidate-build.jsonl').read_text().splitlines()];dependencies={}
for name in ['serde','serde_json','smallvec','mech_core','unicode_segmentation']:
 matches=[row for row in rows if row.get('reason')=='compiler-artifact' and row.get('target',{}).get('name')==name]
 assert len(matches)==1,(name,len(matches));files=[x for x in matches[0]['filenames'] if x.endswith('.rlib')];assert len(files)==1;dependencies[name]=files[0]
old=json.loads(Path('/private/tmp/mech-parser-dispatch-probes-20261113/final/unit-build.json').read_text())['command'];dependencies['proptest']=next(old[i+1].split('=',1)[1] for i,x in enumerate(old[:-1]) if x=='--extern' and old[i+1].startswith('proptest='))
syntax=next(row for row in rows if row.get('reason')=='compiler-artifact' and row.get('target',{}).get('name')=='mech_syntax')
recipe=['rustc','--edition=2024','-C','opt-level=3','-D','warnings','-L','dependency=/private/tmp/mech-level12-compile-target/compiler/deps','-L','dependency=/private/tmp/mech-level12-compile-target/release/deps']
for feature in syntax['features']:recipe+=['--cfg','feature='+json.dumps(feature)]
for name,path in dependencies.items():assert Path(path).is_file();recipe+=['--extern',name+'='+path]
(root/'probe-recipe.json').write_text(json.dumps({'command_prefix':recipe,'dependencies':{n:{'path':p,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()} for n,p in dependencies.items()},'features':syntax['features']},indent=2)+'\n')
probe=root/'probes';probe.mkdir();(probe/'bin').mkdir()
(probe/'unit.rs').write_text('extern crate alloc;\n#[path='+json.dumps(str(repo/'src/syntax/src/document/mod.rs'))+'] pub mod document;\n#[cfg(test)] #[path='+json.dumps(str(repo/'src/core/tests/support/allocation_probe.rs'))+'] mod allocation_probe;\n#[cfg(test)] #[global_allocator] static TEST_ALLOCATOR:allocation_probe::ProbeAllocator=allocation_probe::ProbeAllocator;\n')
source=Path('/private/tmp/mech-parser-probes-20261113/final/differential.rs').read_text()
for variant,base in [('control',snapshot),('candidate',repo)]:
 (probe/(variant+'-differential.rs')).write_text(source.replace('#[path="src/syntax/src/document/mod.rs"]','#[path='+json.dumps(str(base/'src/syntax/src/document/mod.rs'))+']'))
shutil.copy2('/private/tmp/mech-parser-probes-20261113/differential-cases.jsonl',probe/'differential-cases.jsonl')
print(root)
