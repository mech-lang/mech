Nested canonical base predictions, Apple M3, 2026-11-14.
Existing grammar-derived predictions apply before any pending base call frame is
charged, including nested calls. The active continuation owns its existing cache
until storage returns to the same parser. Prediction admission, summary work,
Unicode/context checks, fuel, peak requirements, rewinds and grammar remain.
526 actual production document-module unit tests and 1,667 complete original/
candidate parse comparisons use a coherent pinned release dependency set. These
standalone probes use mech-core only for the SourceLocation record; current
locked compiler-profile dependencies are independently used for full compilation.
Standalone timings are screening observations, not full compiler qualification.
All primary observations, commands, outputs and failed setup attempts remain.
Builds, probes, tests, fixtures, sampling, copying, hashing and packet work do not
overlap primary timings. A separate seven-window CPU diagnostic is excluded.
All source/MBC/Object/complete metadata bytes match. Executables are excluded and
pinned. Pure offline replay checks and reconstructs the compact result without
compilers, benchmark execution, original scratch paths or external services.
