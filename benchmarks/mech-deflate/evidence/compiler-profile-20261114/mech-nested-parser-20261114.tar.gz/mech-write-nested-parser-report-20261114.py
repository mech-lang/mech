from pathlib import Path
import json,statistics,subprocess
repo=Path.cwd();s=json.loads(Path('/private/tmp/mech-nested-parser-packet-20261114/summary.json').read_text());q=s['qualified'];base=lambda p:subprocess.check_output(['git','show',s['source_commit']+':'+p.relative_to(repo).as_posix()],text=True)
mean=lambda k,v:statistics.mean(q[k][v]);rng=lambda k,v:f"{min(q[k][v]):.3f}–{max(q[k][v]):.3f}";change=lambda k:format(100*(mean(k,'candidate')/mean(k,'control')-1),'+.4f' if k in ['max_rss_bytes','peak_footprint_bytes'] else '+.2f')+'%'
rows=[]
for label,k,unit in [('Complete process','whole_process_seconds','s'),('Compiler phases','compiler_seconds','s'),('Parsing','parse_seconds','s'),('Catalog','catalog_seconds','s'),('Frontend','frontend_seconds','s'),('Artifact','artifact_seconds','s'),('Bytecode encoding','encode_seconds','s'),('Native','native_seconds','s'),('Canonical lowering','canonical_lowering_seconds','s'),('Preparation','preparation_seconds','s'),('Numeric helper generation','numeric_generation_seconds','s'),('Source CFG construction','source_cfg_seconds','s'),('Cleanup including compaction','cleanup_including_compaction_seconds','s'),('CFG cleanup','cleanup_seconds','s'),('Value compaction','compaction_seconds','s'),('Retired instructions','instructions','G'),('Maximum RSS','max_rss_bytes','GB'),('Peak footprint','peak_footprint_bytes','GB')]:
 d=1e9 if unit in ['G','GB'] else 1;rows.append(f"| {label} | {mean(k,'control')/d:.4f} {unit} | {mean(k,'candidate')/d:.4f} {unit} | {change(k)} |")
report=f'''# Nested canonical parser predictions

Complete fresh level-12 source-to-Object compilation takes
**{rng('whole_process_seconds','candidate')} seconds** on the Apple M3 Air,
compared with **{rng('whole_process_seconds','control')} seconds** for the matched
control. Parsing changes **{change('parse_seconds')}**, compiler phases
**{change('compiler_seconds')}**, whole-process time **{change('whole_process_seconds')}**
and compiler instructions **{change('instructions')}**. Both balanced blocks
improve. The sub-ten-second compilation goal remains open.

The parser previously applied its existing grammar-derived prediction only
when entering a base continuation. Nested calls still built checkpoints, rule
frames and failed alternatives. The same bounded prediction now runs before
charging any eligible pending base call, including nested calls. Its logical
work already includes that call frame, so no extra charge is added. The active
continuation borrows its own existing cache and returns it to the same parser
with its storage after completion.

This removes unnecessary execution within the current parser architecture.
Grammar productions, shared base/operator specifications, Unicode handling and
language stay unchanged. Source comparisons confirm that all prediction admission
and summary calculations are byte-identical except for borrowing the cache
explicitly. No semantic-result cache or cross-visit proof is added.

The source is `{s['source_commit']}`, measured against control
`{s['control_source_commit']}` with build base `{s['base_commit']}`.
The exact source patch, dependency pins and executable hashes are retained.

## Matched full compilation

Eight serial observations run ABBA then BAAB with identical 60 runtime flags,
toolchain and opt-in `compiler` build profile. Each starts a fresh process and
compiles the full source through parsing, frontend, canonical artifact, bytecode,
native Object and complete metadata. SSA value compaction and its cost remain
in both subjects. Builds, tests, standalone probes, fixtures, CPU sampling,
hashing, copying and archive work do not overlap the primary observations.

The table contains arithmetic means of all aggregate comparison fields. Phase
and nested-stage intervals overlap and are not additive. Adverse values and all
individual observations remain in the report/result; unrelated-phase changes
are not attributed to the parser. Eight observations are not a population estimate.

| Measurement | Control mean | Candidate mean | Change |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(rows)+f'''

Preparation is an adverse {change('preparation_seconds')}, cleanup including
compaction {change('cleanup_including_compaction_seconds')}, bytecode encoding
{change('encode_seconds')} and memory slightly higher with overlapping ranges.
The two balanced-block compiler mean changes are
{(-100*s['blocks'][0]['compiler_mean_reduction_fraction']):+.2f}% and
{(-100*s['blocks'][1]['compiler_mean_reduction_fraction']):+.2f}%.
Every candidate whole-process, compiler, parse and instruction observation is
below every matched control observation.

The separate observed compiler-executable rebuild takes
**{s['candidate_rebuild_seconds']:.3f} seconds**, using existing Cargo caches.
It is excluded from Mech compilation and is not a matched cold-bootstrap
comparison. Both screen runs remain in the packet; the first candidate launch's
startup overhead is excluded from the primary cohort.

## Parser equivalence and program speed

All **526 production document-module unit tests pass**. Existing ASCII-head,
Unicode, fuel/event/nesting, recovery, incremental and stream controls remain.
New comparisons exercise work slices 1, 4095, 4096, 4097, 8192 and unbounded,
resource limits, input sealing, suspended state and return of the nested cache
to the same parser.

A separate **1,667-case** original/candidate comparison preserves complete trees,
node/token identities, diagnostics, public statistics and restart records
byte-for-byte. Both 4,684,363-byte result streams have SHA-256
`{s['parser_differential']['candidate_sha256']}`.
The full compressor retains 1,967,640 parser steps, 434,637 emitted events,
92,316 final nodes and zero recovery bytes.

Standalone unit/differential probes use the same coherent, hash-pinned release
dependency set for both subjects; their document module imports mech-core only
for the SourceLocation record. They compile the actual current document-module
source. The full production compiler independently builds with its current
locked compiler-profile dependencies. Standalone timing screens (about
2.44–2.48 seconds versus 2.06–2.10 seconds) are kept separately from the
production compilation cohort above.

Every source, MBC, Object and complete metadata byte matches the qualified
program in both screens and all primary observations. Fourteen successful
fixture pairs also match all four files, including numeric phases, nested and
changing captures, array windows and Bool/U64/I64/F64 scalar controls. Generated
instructions and metadata are identical. There is no new compressor-runtime
latency campaign and no scalar execution machinery is retired. Fresh shape,
factory, visit and ownership checks, checked errors, finite admission, runtime
accounting and backend settings remain on their existing execution paths.

Probe setup corrections remain visible: duplicate Cargo artifacts first stopped
dependency selection; mixed Thin-LTO/non-LTO dependencies caused two linking
failures before using the coherent release set. A new test's mutable reference
to a constant was replaced with a local allowance variable. No warning allowance
or production policy change was added. Final warnings-as-errors probe builds,
all 526 tests, production build and formatting checks pass.

## Current CPU work and next target

A separate fresh full compile captures seven requested one-second CPU windows
at five-millisecond intervals, triggered by stage markers. These diagnostics are
excluded from timing qualification and also reproduce every output byte. The
following are built-in top-of-stack self counts at least five. Waiting states
are retained in raw samples and separated from active symbols. Windows can
cross stage boundaries; these counts are not exclusive elapsed-time shares.

| Window | Selected active self counts |
| --- | --- |
| Parse | Journal chunk mutation 24; base dispatch 20; memory move 13; tree sink 9 |
| Frontend | Dimension canonicalization 35; declaration-vector cloning 32; schema embedding 9 |
| Preparation | Exact exit liveness query 79; memory move 9; ordered-map insertion 7 |
| Helpers | Freeing 17; definition inventory initialization 9; CFG recomputation 8 |
| Source CFG | SSA nonlocal lookup 64; variable-definition insertion 24; sparse-map growth 15 |
| Cleanup | Ordered pipeline 20; constant-phi removal 16; parameter removal 13; dominance 9; verifier 8 |
| Backend | Register-bundle allocation 21; allocator initialization 17; memory move 16 |

The next hypothesis is improving **SSA variable-definition storage**, preserving
every existing lookup/insert result, pending-None state, traversal, alias creation
and ordered enumeration. Its current dense region begins at block zero, so late
locally clustered IDs remain hashed unless the whole prefix is dense. A bounded
local span may avoid hash growth without changing SSA construction. Sparse IDs,
allocation bounds and ordered enumeration both below/above a span need explicit
controls. This is unimplemented and no saving is credited here. The previously
rejected SSA-forwarding shortcut remains rejected.

Batch removal of already-selected block parameters is a secondary candidate.
Existing callers already delete rightmost first; batching must preserve raw
Value IDs, retained parameter order, aliases and branch arguments while improving
on that baseline. Neither current validation nor execution checks are removed.

## Reproduce the results

The [compact result](../../benchmarks/mech-deflate/native-profile/nested-parser-compile-apple-m3-20261114.json),
[receipt](../../benchmarks/mech-deflate/native-profile/nested-parser-compile-apple-m3-20261114.archive.json)
and [complete packet index](../../benchmarks/mech-deflate/evidence/compiler-profile-20261114/README.md)
pin every observation, source and patch, input, command, output, correction,
CPU window and license. Compiler/probe executables are excluded and hash-pinned.
The maintained verifier checks the published repository copy, manifest, safe
paths and every file. Pure offline `python3 replay.py` reconstructs the result
and checks stored outputs/samples without a compiler, benchmark execution,
original scratch paths or network.
'''
(repo/'docs/design/native-nested-parser-compile-profile.md').write_text(report)
p=repo/'docs/design/native-compiler-process-profile.md';text=base(p);text=text.replace('18.690–19.107 seconds per complete',rng('whole_process_seconds','candidate')+' seconds per complete',1).replace('and [selected exit definitions](native-exit-definitions-compile-profile.md).','[selected exit definitions](native-exit-definitions-compile-profile.md),\nand [nested parser predictions](native-nested-parser-compile-profile.md).',1);text+=f'''\nThe latest [nested-parser qualification](native-nested-parser-compile-profile.md)
applies existing grammar-derived predictions to nested base calls, with exact
logical work and continuation-owned cache storage. Eight matched 60-flag complete
compiles take {rng('whole_process_seconds','candidate')} seconds: parsing changes
{change('parse_seconds')}, process time {change('whole_process_seconds')} and
instructions {change('instructions')}. Preparation and cleanup are adverse; all
phases and counters remain. All generated bytes match. There are 526 passing
document-module units, 1,667 identical full parse comparisons and fourteen fixture
pairs. Its seventeenth complete packet also includes seven separate CPU windows.
Those point to SSA variable lookup/storage and CFG cleanup as further targets.
The ten-second goal remains open.\n''';p.write_text(text)
p=repo/'benchmarks/mech-deflate/native-profile/README.md';p.write_text(base(p)+f'''\nThe [nested parser qualification](../../../docs/design/native-nested-parser-compile-profile.md)
applies existing bounded predictions to nested base calls without changing grammar
or logical work. Eight matched complete processes take
{rng('whole_process_seconds','candidate')} seconds ({change('whole_process_seconds')}
mean change); parsing changes {change('parse_seconds')}. Generated bytes match.
All 526 document-module units, 1,667 full parse comparisons and fourteen fixture
pairs pass. Seven separate CPU windows, all adverse values and setup failures
are in the seventeenth [complete packet](../evidence/compiler-profile-20261114/README.md).
''')
p=repo/'benchmarks/mech-deflate/EXPERIMENTS.md';p.write_text(base(p)+f'''\n## Nested parser predictions, 2026-11-14\n\nThe [report](../../docs/design/native-nested-parser-compile-profile.md) records
{rng('whole_process_seconds','candidate')} seconds for complete fresh level-12
compilation across eight matched observations. Parsing changes
{change('parse_seconds')}, process time {change('whole_process_seconds')} and
compiler instructions {change('instructions')}. Grammar and logical work remain.
Generated bytes match; 526 document-module units, 1,667 full parse comparisons
and fourteen fixture pairs pass. The [complete packet](evidence/compiler-profile-20261114/README.md)
keeps every observation, adverse counter, setup failure and seven separate CPU
windows. The current profiles point to SSA lookup/storage and CFG cleanup.
The ten-second goal remains open.\n''')
