from pathlib import Path
import subprocess,json,hashlib,shutil,tarfile,io
repo=Path.cwd();raw=Path('/private/tmp/mech-nested-parser-20261114');packet=Path('/private/tmp/mech-nested-parser-packet-20261114');assert not packet.exists()
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();build=json.loads((raw/'candidate-build.json').read_text());base=build['head'];control=json.loads((raw/'control-origin.json').read_text());control_source=control['source_commit']
summary_path=repo/'benchmarks/mech-deflate/native-profile/exit-definitions-compile-apple-m3-20261114.json';receipt_path=summary_path.with_name(summary_path.stem+'.archive.json');prior=json.loads(summary_path.read_text());receipt=json.loads(receipt_path.read_text());assert hashlib.sha256(summary_path.read_bytes()).hexdigest()==receipt['replay_sha256'];assert control_source==prior['source_commit'] and control['sha256']==prior['compiler_binary_sha256']['candidate']
patch=subprocess.check_output(['git','diff','--binary',base,source]);assert patch==(raw/'candidate.patch').read_bytes();assert hashlib.sha256(patch).hexdigest()==build['patch_sha256']
assert subprocess.check_output(['git','diff',control_source,base,'--','src','hosts','vendor','machines','Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.toml'])==b''
excluded=[]
for p in sorted(raw.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(raw);dest=Path('compiler')/rel
 if rel.as_posix() in ['control','candidate'] or rel.parts[:2]==('probes','bin'):
  excluded.append(dict(path=dest.as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()));continue
 d=packet/dest;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
(packet/'excluded-executables.json').write_text(json.dumps(excluded,indent=2)+'\n');(packet/'source-change.patch').write_bytes(patch)
state=dict(source_commit=source,base_commit=base,control_source_commit=control_source,control_production_source_identical_to_base=True,patch_sha256=hashlib.sha256(patch).hexdigest(),hardware='Apple M3 Air, 8 cores (4P+4E), 16 GB, macOS 26.2',rustc=subprocess.check_output(['rustc','-Vv'],text=True),cargo=subprocess.check_output(['cargo','-V'],text=True));(packet/'source-state.json').write_text(json.dumps(state,indent=2,sort_keys=True)+'\n')
changed=subprocess.check_output(['git','diff','--name-only',base,source],text=True).splitlines();(packet/'source').mkdir()
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',source,'src/syntax']))) as t:t.extractall(packet/'source',filter='data')
paths=changed+['vendor/cranelift-frontend/src/ssa.rs', 'vendor/cranelift-codegen/src/ir/dfg.rs', 'vendor/cranelift-codegen/src/remove_constant_phis.rs', 'hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/local_phis/mod.rs', 'hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/dead_values/mod.rs']+['Cargo.toml','Cargo.lock','.cargo/config.toml','LICENSE','hosts/gpu/src/native_artifact/AGENTS.md','src/core/tests/support/allocation_probe.rs','hosts/gpu/tests/fixtures/native/deflate-huffman-LICENSES.md']
paths+=['benchmarks/mech-deflate/native-profile/'+n for n in ['Cargo.toml','Cargo.lock','compile_profile.rs','profile_compile.py']]
paths+=['hosts/gpu/tests/fixtures/native/'+n+'.mec' for n in ['numeric-nested-phase','numeric-nested-phase-states','numeric-private-fixed-nested','numeric-changing-capture-tree','numeric-array-windows','numeric-multiple-children']]
for name in dict.fromkeys(paths):
 data=subprocess.check_output(['git','show',source+':'+name]);d=packet/'source'/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(data)
for name in [*changed,'Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.toml']:
 data=subprocess.check_output(['git','show',base+':'+name]);d=packet/'source-base'/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(data)
validation=packet/'validation';validation.mkdir();shutil.copy2(summary_path,validation/'qualified-exit-definitions.json');shutil.copy2(receipt_path,validation/'qualified-exit-definitions.archive.json');shutil.copytree(Path('/private/tmp/mech-borrowed-schema-packet-20261114/licenses'),packet/'licenses')
for pattern in ['mech-*nested-parser*20261114.py','mech-*nested-parser*20261114.log']:
 for p in Path('/private/tmp').glob(pattern):
  if p.is_file():shutil.copy2(p,packet/p.name)
(packet/'README.txt').write_text('''Nested canonical base predictions, Apple M3, 2026-11-14.
Existing grammar-derived predictions apply before any pending base call frame is
charged, including nested calls. The active continuation owns its existing cache
until storage returns to the same parser. Prediction admission, summary work,
Unicode/context checks, fuel, peak requirements, rewinds and grammar remain.
526 actual production document-module unit tests and 1,667 complete original/
candidate parse comparisons use a coherent pinned release dependency set. These
standalone probes use mech-core only for the SourceLocation record; current
locked compiler-profile dependencies are independently used for full compilation.
Standalone timings are screening observations, not full compiler qualification.
All primary observations, commands, outputs and failed setup attempts remain.
Builds, probes, tests, fixtures, sampling, copying, hashing and packet work do not
overlap primary timings. A separate seven-window CPU diagnostic is excluded.
All source/MBC/Object/complete metadata bytes match. Executables are excluded and
pinned. Pure offline replay checks and reconstructs the compact result without
compilers, benchmark execution, original scratch paths or external services.
''');print(packet)
