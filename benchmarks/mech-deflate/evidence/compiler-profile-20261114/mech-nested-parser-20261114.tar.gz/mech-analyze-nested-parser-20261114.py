from pathlib import Path
import json,statistics
root=Path('/private/tmp/mech-nested-parser-20261114');blocks=[json.loads((root/name).read_text()) for name in ['cohort-first.json','cohort-second.json']];rows=sum(blocks,[])
for row in rows:
 d=root/row['name'];stamps=[json.loads(line) for line in (d/'stages.jsonl').read_text().splitlines()]
 if True:
  start=next(s for s in stamps if s['line'].startswith('compact-stage: compact values before='));end=next(s for s in stamps if s['line'].startswith('compact-stage: CFG cleanup'));row['compaction_seconds']=end['elapsed']-start['elapsed'];row['value_ids_before']=int(start['line'].split('=')[-1]);row['value_ids_after']=int(next(s['line'] for s in stamps if s['line'].startswith('compact-values: retained=')).split('=')[-1])
 else:row['compaction_seconds']=0
 row['cleanup_including_compaction_seconds']=row['cleanup_seconds']+row['compaction_seconds']
(root/'cohort.json').write_text(json.dumps(rows,indent=2)+'\n')
fields={'compiler_seconds':lambda r:r['compile']['total_seconds'],'whole_process_seconds':lambda r:r['process']['elapsed_seconds']}
for phase in ['parse','catalog','frontend','artifact','encode','native']:fields[phase+'_seconds']=lambda r,p=phase:next(v['seconds'] for v in r['compile']['phases'] if v['phase']==p)
for key in ['canonical_lowering_seconds','preparation_seconds','numeric_generation_seconds','source_cfg_seconds','cleanup_including_compaction_seconds','cleanup_seconds','compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:fields[key]=lambda r,k=key:r[k]
qualified={key:{v:[fn(r) for r in rows if r['variant']==v] for v in ['control','candidate']} for key,fn in fields.items()}
for key,values in qualified.items():
 control=statistics.mean(values['control']);values['mean_reduction_fraction']=1-statistics.mean(values['candidate'])/control if control else None
 print(key,json.dumps(values))
for block in blocks:
 print('block', [r['name'] for r in block],'compiler_change_percent',100*(statistics.mean(r['compile']['total_seconds'] for r in block if r['variant']=='candidate')/statistics.mean(r['compile']['total_seconds'] for r in block if r['variant']=='control')-1))
(root/'numerical-summary.json').write_text(json.dumps(qualified,indent=2,sort_keys=True)+'\n')
