from pathlib import Path
import hashlib,json,re
root=Path(__file__).resolve().parent
relative='src/syntax/src/document/parser/tree_cache.rs'
reference=(root/'reference-source'/relative).read_text()
candidate=(root/'candidate-source'/relative).read_text()
def tokens(source):
 ts=[x for x in re.findall(r'//[^\n]*|/\*.*?\*/|"(?:\\.|[^"\\])*"|\w+|[^\s]',source,flags=re.S) if not x.startswith('//') and not x.startswith('/*')]
 return [x for i,x in enumerate(ts) if not (x==',' and i+1<len(ts) and ts[i+1]==')')]
source=candidate
signature="""    fn element(
        frames: &mut [Frame],
        root: &mut Option<Arc<GreenNode>>,
        work: &mut CacheWork,
        element: GreenElement,
    ) -> Result<(), BuildError> {"""
assert source.count(signature)==1
source=source.replace(signature,'    fn element(&mut self, element: GreenElement) -> Result<(), BuildError> {',1)
a=source.index('    fn element(');b=source.index('    pub fn advance(',a)
helper=source[a:b].replace('frames.last_mut()', 'self.frames.last_mut()').replace('work.child_storage_nodes', 'self.work.child_storage_nodes').replace('root.replace(node)', 'self.root.replace(node)')
source=source[:a]+helper+source[b:]
source,count=re.subn(r'Self::element\(\s*&mut self\.frames,\s*&mut self\.root,\s*&mut self\.work,', 'self.element(',source);assert count==4
assert source.count('let mut events = None;')==1
source=source.replace('let mut events = None;','',1)
old="""let event = events
                .get_or_insert_with(|| self.events.iter_range(self.at..self.end))
                .next()"""
assert source.count(old)==1
source=source.replace(old,'let event = self.events.get(index)',1)
assert source.count('events = None;')==1
source=source.replace('events = None;','',1)
assert tokens(source)==tokens(reference), 'other production token change'
state=json.loads((root/'source-state.json').read_text())
assert hashlib.sha256(candidate.encode()).hexdigest()==state['files'][0]['candidate']['sha256']
result=dict(all_other_production_tokens_identical=True,optional_trailing_argument_commas_ignored=True,element_helper_body_identical_after_field_borrow_split=True,event_lookup_only_borrowed_iter_range=True,lazy_cursor_init_and_cached_jump_reset=True,no_persistent_state_layout_arc_allocation_or_grammar_change=True,patch_sha256=state['patch_sha256'])
print(json.dumps(result,indent=2,sort_keys=True))
