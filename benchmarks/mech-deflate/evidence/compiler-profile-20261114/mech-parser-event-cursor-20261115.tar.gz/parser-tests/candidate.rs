
extern crate alloc;
#[path="/private/tmp/mech-parser-event-cursor-20261115/candidate-source/src/syntax/src/document/mod.rs"] pub mod document;
use document::*;
use std::io::BufRead;
fn tree(node:&GreenNode,out:&mut Vec<serde_json::Value>){
 out.push(serde_json::json!(["start",node.id.0,node.kind as u16,node.flags.0,node.text_len.0,node.structural_hash]));
 for child in node.children.iter(){match child{
  GreenElement::Node(node)=>tree(node,out),
  GreenElement::Token(t)=>out.push(serde_json::json!(["token",t.id.0,t.kind as u16,t.flags.0,t.text_len.0,t.text_hash])),
 }}
 out.push(serde_json::json!(["finish"]));
}
fn report(parsed:&SyntaxSnapshot)->serde_json::Value{
 let mut nodes=Vec::new();tree(&parsed.root,&mut nodes);
 serde_json::json!({"tree":nodes,"diagnostics":parsed.diagnostics.iter().collect::<Vec<_>>(),"stats":format!("{:?}",parsed.stats),"restarts":format!("{:?}",parsed.restarts)})
}
fn drain(stream:&mut DocumentStream,mut progress:StreamProgress,allowance:u64)->u64{
 let mut polls=0;
 while progress==StreamProgress::NeedsProcessing{
  progress=stream.advance(allowance).progress;polls+=1;
  assert!(polls<2_000_000);
 }
 assert_ne!(progress,StreamProgress::Limited);
 polls
}
fn main(){
 for line in std::io::stdin().lock().lines(){
  let case:serde_json::Value=serde_json::from_str(&line.unwrap()).unwrap();
  let mut config=ParseConfig::default();
  if let Some(value)=case.get("fuel"){config.limits.fuel=value.as_u64().unwrap();}
  if let Some(value)=case.get("events"){config.limits.max_events=value.as_u64().unwrap() as u32;}
  if let Some(value)=case.get("nesting"){config.limits.max_nesting=value.as_u64().unwrap() as u32;}
  if let Some(value)=case.get("diagnostics"){config.limits.max_diagnostics=value.as_u64().unwrap() as u32;}
  if let Some(value)=case.get("recovery"){config.limits.max_recovery_bytes=value.as_u64().unwrap() as u32;}
  if let Some(chunks)=case.get("chunks"){
   let allowance=case["allowance"].as_u64().unwrap();
   let mut stream=DocumentStream::new(DocumentId(0x50524f47),config);
   let mut trace=Vec::new();
   for chunk in chunks.as_array().unwrap(){
    let zero=stream.advance(0);
    trace.push(serde_json::json!({"zero":format!("{:?}",zero.progress),"work":format!("{:?}",zero.work)}));
    let update=stream.append(chunk.as_str().unwrap(),allowance).unwrap();
    let first=serde_json::json!({"progress":format!("{:?}",update.progress),"accepted":update.accepted_bytes,"syntax":format!("{:?}",update.syntax),"diagnostics":format!("{:?}",update.diagnostics),"work":format!("{:?}",update.work)});
    let polls=drain(&mut stream,update.progress,allowance);
    trace.push(serde_json::json!({"first":first,"polls":polls,"drained_work":format!("{:?}",stream.work())}));
   }
   let update=stream.finish(allowance);
   let polls=drain(&mut stream,update.progress,allowance);
   let parsed=stream.materialize().unwrap();
   println!("{}",serde_json::json!({"id":case["id"],"snapshot":report(&parsed),"trace":trace,"finish_polls":polls,"work":format!("{:?}",stream.work())}));
  }else{
   let parsed=parse_canonical_document(TextSnapshot::new(DocumentId(0x50524f47),Revision(1),case["text"].as_str().unwrap()).unwrap(),config);
   println!("{}",serde_json::json!({"id":case["id"],"snapshot":report(&parsed)}));
  }
 }
}
