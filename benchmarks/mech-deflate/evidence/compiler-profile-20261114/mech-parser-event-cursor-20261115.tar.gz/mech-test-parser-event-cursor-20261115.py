from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,time

repo=Path.cwd()
root=Path('/private/tmp/mech-parser-event-cursor-20261115')
state=json.loads((root/'source-state.json').read_text())
assert subprocess.check_output(['git','diff','--binary'])==(root/'candidate.patch').read_bytes()
assert json.loads((root/'candidate-build.json').read_text())['exit_code']==0
probe=root/'parser-tests'
assert not probe.exists()
(probe/'bin').mkdir(parents=True)
for variant in ['reference','candidate']:
    target=root/(variant+'-source')/'src/syntax'
    saved=(target/'src/document/parser/tree_cache.rs').read_bytes()
    shutil.copytree(repo/'src/syntax',target,dirs_exist_ok=True)
    (target/'src/document/parser/tree_cache.rs').write_bytes(saved)
rows=[json.loads(line) for line in (root/'candidate-build.jsonl').read_text().splitlines()]
dependency_origin=json.loads(Path('/private/tmp/mech-nested-parser-20261114/probe-recipe.json').read_text())
dependencies={name:row['path'] for name,row in dependency_origin['dependencies'].items()}
for name,path in dependencies.items():
    assert hashlib.file_digest(Path(path).open('rb'),'sha256').hexdigest()==dependency_origin['dependencies'][name]['sha256']
syntax=next(row for row in rows if row.get('reason')=='compiler-artifact' and row.get('target',{}).get('name')=='mech_syntax')
prefix=['rustc','+nightly-2026-03-03','--edition=2024','-C','opt-level=3','-D','warnings','-L','dependency=/private/tmp/mech-level12-compile-target/compiler/deps','-L','dependency=/private/tmp/mech-level12-compile-target/release/deps']
for feature in syntax['features']:
    prefix+=['--cfg','feature='+json.dumps(feature)]
for name,path in dependencies.items():
    assert Path(path).is_file()
    prefix+=['--extern',name+'='+path]
recipe={'command_prefix':prefix,'features':syntax['features'],'dependency_scope':'Coherent pinned release probe libraries reused from packet17; mech_core is used only for SourceLocation. Primary compiler check/build/gates use current locked compiler dependencies. First mixed ThinLTO rlib standalone link failure retained.','dependencies':{name:{'path':path,'bytes':Path(path).stat().st_size,'sha256':hashlib.file_digest(Path(path).open('rb'),'sha256').hexdigest()} for name,path in dependencies.items()}}
(probe/'recipe.json').write_text(json.dumps(recipe,indent=2)+'\n')
env=dict(os.environ,CARGO_MANIFEST_DIR=str(repo/'src/syntax'))
def run(name,command,stdin=None):
    start=time.monotonic()
    with (probe/(name+'.stdout')).open('wb') as out,(probe/(name+'.stderr')).open('wb') as err:
        completed=subprocess.run(command,env=env,input=stdin,stdout=out,stderr=err)
    row={'command':command,'exit_code':completed.returncode,'seconds':time.monotonic()-start,'base_commit':state['base_commit'],'patch_sha256':state['patch_sha256']}
    (probe/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    assert completed.returncode==0,(name,(probe/(name+'.stderr')).read_text()[-5000:])
    return row
unit='extern crate alloc;\n#[path='+json.dumps(str(root/'candidate-source/src/syntax/src/document/mod.rs'))+'] pub mod document;\n#[cfg(test)] #[path='+json.dumps(str(repo/'src/core/tests/support/allocation_probe.rs'))+'] mod allocation_probe;\n#[cfg(test)] #[global_allocator] static TEST_ALLOCATOR:allocation_probe::ProbeAllocator=allocation_probe::ProbeAllocator;\n'
(probe/'unit.rs').write_text(unit)
run('unit-build',[*prefix,'--crate-name','parser_event_cursor_unit','--test',str(probe/'unit.rs'),'-o',str(probe/'bin/unit')])
run('unit-tests',[str(probe/'bin/unit'),'--test-threads=2'])
out=(probe/'unit-tests.stdout').read_text()
match=re.search(r'test result: ok\. (\d+) passed; (\d+) failed;',out)
assert match and match[2]=='0'
(probe/'unit-result.json').write_text(json.dumps({'passed':int(match[1]),'failed':0,'actual_complete_document_module':True},indent=2)+'\n')
source=r'''
extern crate alloc;
#[path="DOCUMENT_MODULE"] pub mod document;
use document::*;
use std::io::BufRead;
fn tree(node:&GreenNode,out:&mut Vec<serde_json::Value>){
 out.push(serde_json::json!(["start",node.id.0,node.kind as u16,node.flags.0,node.text_len.0,node.structural_hash]));
 for child in node.children.iter(){match child{
  GreenElement::Node(node)=>tree(node,out),
  GreenElement::Token(t)=>out.push(serde_json::json!(["token",t.id.0,t.kind as u16,t.flags.0,t.text_len.0,t.text_hash])),
 }}
 out.push(serde_json::json!(["finish"]));
}
fn report(parsed:&SyntaxSnapshot)->serde_json::Value{
 let mut nodes=Vec::new();tree(&parsed.root,&mut nodes);
 serde_json::json!({"tree":nodes,"diagnostics":parsed.diagnostics.iter().collect::<Vec<_>>(),"stats":format!("{:?}",parsed.stats),"restarts":format!("{:?}",parsed.restarts)})
}
fn drain(stream:&mut DocumentStream,mut progress:StreamProgress,allowance:u64)->u64{
 let mut polls=0;
 while progress==StreamProgress::NeedsProcessing{
  progress=stream.advance(allowance).progress;polls+=1;
  assert!(polls<2_000_000);
 }
 assert_ne!(progress,StreamProgress::Limited);
 polls
}
fn main(){
 for line in std::io::stdin().lock().lines(){
  let case:serde_json::Value=serde_json::from_str(&line.unwrap()).unwrap();
  let mut config=ParseConfig::default();
  if let Some(value)=case.get("fuel"){config.limits.fuel=value.as_u64().unwrap();}
  if let Some(value)=case.get("events"){config.limits.max_events=value.as_u64().unwrap() as u32;}
  if let Some(value)=case.get("nesting"){config.limits.max_nesting=value.as_u64().unwrap() as u32;}
  if let Some(value)=case.get("diagnostics"){config.limits.max_diagnostics=value.as_u64().unwrap() as u32;}
  if let Some(value)=case.get("recovery"){config.limits.max_recovery_bytes=value.as_u64().unwrap() as u32;}
  if let Some(chunks)=case.get("chunks"){
   let allowance=case["allowance"].as_u64().unwrap();
   let mut stream=DocumentStream::new(DocumentId(0x50524f47),config);
   let mut trace=Vec::new();
   for chunk in chunks.as_array().unwrap(){
    let zero=stream.advance(0);
    trace.push(serde_json::json!({"zero":format!("{:?}",zero.progress),"work":format!("{:?}",zero.work)}));
    let update=stream.append(chunk.as_str().unwrap(),allowance).unwrap();
    let first=serde_json::json!({"progress":format!("{:?}",update.progress),"accepted":update.accepted_bytes,"syntax":format!("{:?}",update.syntax),"diagnostics":format!("{:?}",update.diagnostics),"work":format!("{:?}",update.work)});
    let polls=drain(&mut stream,update.progress,allowance);
    trace.push(serde_json::json!({"first":first,"polls":polls,"drained_work":format!("{:?}",stream.work())}));
   }
   let update=stream.finish(allowance);
   let polls=drain(&mut stream,update.progress,allowance);
   let parsed=stream.materialize().unwrap();
   println!("{}",serde_json::json!({"id":case["id"],"snapshot":report(&parsed),"trace":trace,"finish_polls":polls,"work":format!("{:?}",stream.work())}));
  }else{
   let parsed=parse_canonical_document(TextSnapshot::new(DocumentId(0x50524f47),Revision(1),case["text"].as_str().unwrap()).unwrap(),config);
   println!("{}",serde_json::json!({"id":case["id"],"snapshot":report(&parsed)}));
  }
 }
}
'''
cases=[json.loads(line) for line in Path('/private/tmp/mech-parser-probes-20261113/differential-cases.jsonl').read_text().splitlines()]
original_count=len(cases)
benchmark=next(p for p in Path('/private/tmp/mech-ssa-descending-chain-20261115').rglob('source.mec') if p.stat().st_size==164243 and hashlib.sha256(p.read_bytes()).hexdigest()=='55cb2e698afb73da536164504b991dd514be855c9f4da9c3aadd046a55e1dba4')
cases.append({'id':'current-level12-entire-source','text':benchmark.read_text()})
texts=['x := 1\n','x := (1 + 2)\ny := [1, 2, 3]\n','-- λ🦀\nx := "é"\n','1..=10\n1. first\n','x := '+('('*48)+'1'+(')'*48)+'\n','x := [0u32 | i <- 0u64..=259u64, i < 259u64]\n',chr(96)*3+'mech\nx := 1\n'+chr(96)*3+'\n','x := [1, 2\n']
for i,text in enumerate(texts):
    for allowance in [1,2,4,13,4095,4096,4097]:
        for pieces in [1,3]:
            cuts=[j*len(text)//pieces for j in range(pieces+1)]
            chunks=[text[a:b] for a,b in zip(cuts,cuts[1:])]
            cases.append({'id':f'stream-{i}-{allowance}-{pieces}','text':text,'allowance':allowance,'chunks':chunks})
data=('\n'.join(json.dumps(case,ensure_ascii=False) for case in cases)+'\n').encode()
(probe/'cases.jsonl').write_bytes(data)
for variant in ['reference','candidate']:
    text=source.replace('"DOCUMENT_MODULE"',json.dumps(str(root/(variant+'-source')/'src/syntax/src/document/mod.rs')))
    filename=probe/(variant+'.rs');filename.write_text(text)
    run(variant+'-build',[*prefix,'--crate-name','parser_event_cursor_'+variant,str(filename),'-o',str(probe/'bin'/variant)])
    run(variant+'-run',[str(probe/'bin'/variant)],data)
a=(probe/'reference-run.stdout').read_bytes();b=(probe/'candidate-run.stdout').read_bytes()
result={'cases':len(cases),'original_cases':original_count,'streaming_cases':112,'whole_benchmark_case':True,'byte_identical':a==b,'reference_sha256':hashlib.sha256(a).hexdigest(),'candidate_sha256':hashlib.sha256(b).hexdigest(),'bytes':len(a),'complete_tree_ids_tokens_diagnostics_stats_restarts_and_stream_work':True}
if a!=b:
    result['differing_case_indices']=[i for i,(left,right) in enumerate(zip(a.splitlines(),b.splitlines())) if left!=right]
(probe/'differential-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
assert a==b,result
assert subprocess.check_output(['git','diff','--binary'])==(root/'candidate.patch').read_bytes()
