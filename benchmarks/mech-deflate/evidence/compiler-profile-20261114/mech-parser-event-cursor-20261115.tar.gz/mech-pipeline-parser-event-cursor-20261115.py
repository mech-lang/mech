from pathlib import Path
import json,subprocess,time,sys
root=Path('/private/tmp/mech-parser-event-cursor-20261115')
assert json.loads((root/'parser-tests/differential-result.json').read_text())['byte_identical']
assert json.loads((root/'parser-tests/unit-result.json').read_text())['passed']==526
records=[]
for stage,script in [('cli-check','/private/tmp/mech-check-parser-event-cursor-20261115.py'),('qualification','/private/tmp/mech-qualify-parser-event-cursor-20261115.py')]:
 start=time.monotonic()
 with (root/(stage+'-driver.stdout.log')).open('w') as stdout,(root/(stage+'-driver.stderr.log')).open('w') as stderr:result=subprocess.run([sys.executable,script],stdout=stdout,stderr=stderr)
 row={'stage':stage,'exit_code':result.returncode,'seconds':time.monotonic()-start};records.append(row)
 (root/'pipeline.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert result.returncode==0
