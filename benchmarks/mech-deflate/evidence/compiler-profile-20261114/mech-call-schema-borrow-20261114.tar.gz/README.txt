Call-argument schema borrowing qualification, 2026-11-14.
All eight primary runs, both preliminary screens, fourteen paired fixtures,
build inputs/logs, exact production patch/source, and final native links remain.
Compiler executables are excluded and SHA-pinned; every generated program file,
complete executable, and frozen native-link object/archive input is included.
The two preliminary screens have different startup gaps and are excluded from
the balanced eight-run performance cohort. The complete process uses the new
precise process.wait completion boundary; historical polling cohorts are separate.
The final-link observations use cached runtime/adapter objects and do not measure
whole source-to-executable latency. Every complete executable byte is identical.
The original runtime campaign is not rerun because the generated code is exact.
There are no language, grammar, optimization-decision, or ownership-proof changes.
Primary frontend, compiler and instruction means improve in both balanced blocks;
unrelated native-stage movement and slower parsing/catalog/cleanup observations
are reported without crediting them to the frontend source change.
Pure replay validates all stored measurements, source patch, program output bytes,
fixture sources, native inputs and executable identity without recompiling or
rerunning timings. Sub-ten-second compilation remains an open goal.
