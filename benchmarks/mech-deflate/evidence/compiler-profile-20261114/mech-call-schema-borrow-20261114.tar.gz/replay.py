from pathlib import Path
import hashlib, json, re, statistics

root = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_text())
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
state = read(root / 'source-state.json')
excluded = {r['path']: r for r in read(root / 'excluded-compiler-products.json')}
prior = read(root / 'validation/prior-qualified.json')
assert pin(root / 'validation/prior-qualified.json')['sha256'] == read(root / 'validation/prior-qualified.archive.json')['replay_sha256']
flags = read(root / 'runtime-flags.json')
assert len(flags) == 61 and flags['MECH_COMPACT_REUSE_OVERWRITTEN_RESULT'] == '1'
build = read(root / 'candidate-build.json')
assert build['exit_code'] == 0 and build['head'] == state['base_commit']
assert pin(root / 'candidate.patch')['sha256'] == build['patch_sha256']
assert excluded['candidate']['sha256'] == build['binary_sha256']
assert excluded['control']['sha256'] == prior['compiler_binary_sha256']['candidate']
base_source = (root / 'source/control/src/engine/src/source_semantics/frontend.rs').read_text()
candidate_source = (root / 'source/candidate/src/engine/src/source_semantics/frontend.rs').read_text()
before = '''                let schema = if index == 0 && destination.is_some() {
                    destination.clone().unwrap()
                } else {
                    self.schema_draft_of(*input)?.into_owned()
                };'''
after = '''                let schema = match (index, destination.as_ref()) {
                    (0, Some(schema)) => schema,
                    _ => self.schema_draft(*input)?,
                };'''
assert base_source.count(before) == 1 and base_source.replace(before, after) == candidate_source
patch = (root / 'candidate.patch').read_text()
assert patch.count('diff --git ') == 1 and all(line in patch for line in ['-                    destination.clone().unwrap()', '-                    self.schema_draft_of(*input)?.into_owned()', '+                    _ => self.schema_draft(*input)?,'])
expected = prior['output_hashes']
assert read(root / 'reference-pins.json') == expected
for n, pinned in expected.items():
    assert pin(root / 'reference' / n) == pinned
order = [('control', 'control-1'), ('candidate', 'candidate-1'), ('candidate', 'candidate-2'), ('control', 'control-2'), ('candidate', 'candidate-3'), ('control', 'control-3'), ('control', 'control-4'), ('candidate', 'candidate-4')]
cohort = []
screens = []
for variant, name in [('control', 'control-screen'), ('candidate', 'candidate-screen')] + order:
    d = root / name
    command = read(root / (name + '-command.json'))
    assert command['flags'] == flags and command['binary_sha256'] == excluded[variant]['sha256']
    assert not command['profiling_excluded_from_primary']
    process = read(d / 'process.json')
    assert process['exit_code'] == 0 and process['elapsed_boundary'] == 'driver_start_to_process_wait_completion'
    assert process['samples'] == 0 and process['sampling_error'] is None
    checks = read(d / 'output-check.json')
    for n, pinned in expected.items():
        assert pin(d / n) == pinned and checks[n] == dict(pinned, matches_current_control_output=True)
    row = dict(name=name, variant=variant, compile=read(d / 'compile.json'), process=process, files=checks)
    assert row['compile']['total_seconds'] < process['elapsed_seconds']
    if name.endswith('-screen'):
        screens.append(row)
        continue
    stamps = [json.loads(line) for line in (d / 'stages.jsonl').read_text().splitlines()]
    elapsed = lambda prefix: next(s['elapsed'] for s in stamps if s['line'].startswith(prefix))
    for key, begin, end in [('canonical_lowering_seconds', 'compact-stage: canonical lowering', 'compact-stage: preparation blocks='), ('preparation_seconds', 'compact-stage: preparation blocks=', 'compact-stage: native module'), ('numeric_generation_seconds', 'compact-stage: native module', 'compact-stage: typed layout'), ('source_cfg_seconds', 'compact-stage: source CFG', 'compact-stage: finalize SSA'), ('cleanup_seconds', 'compact-stage: CFG cleanup', 'compact-stage: machine code')]:
        row[key] = elapsed(end) - elapsed(begin)
    log = (d / 'stderr.log').read_text()
    for key, pattern in [('max_rss_bytes', r'(\d+)  maximum resident set size'), ('instructions', r'(\d+)  instructions retired'), ('peak_footprint_bytes', r'(\d+)  peak memory footprint')]:
        row[key] = int(re.search(pattern, log).group(1))
    row['compaction_seconds'] = elapsed('compact-stage: CFG cleanup') - elapsed('compact-stage: compact values before=')
    for key, prefix in [('value_ids_before', 'compact-stage: compact values before='), ('value_ids_after', 'compact-values: retained=')]:
        row[key] = int(next(s['line'] for s in stamps if s['line'].startswith(prefix)).split('=')[-1])
    assert (row['value_ids_before'], row['value_ids_after']) == (20798230, 1242559)
    row['cleanup_including_compaction_seconds'] = row['cleanup_seconds'] + row['compaction_seconds']
    cohort.append(row)
assert cohort == read(root / 'cohort.json')
fields = {'compiler_seconds': lambda r: r['compile']['total_seconds'], 'whole_process_seconds': lambda r: r['process']['elapsed_seconds']}
for phase in ['parse', 'catalog', 'frontend', 'artifact', 'encode', 'native']:
    fields[phase + '_seconds'] = lambda r, p=phase: next(v['seconds'] for v in r['compile']['phases'] if v['phase'] == p)
for key in ['canonical_lowering_seconds', 'preparation_seconds', 'numeric_generation_seconds', 'source_cfg_seconds', 'cleanup_including_compaction_seconds', 'cleanup_seconds', 'compaction_seconds', 'instructions', 'max_rss_bytes', 'peak_footprint_bytes']:
    fields[key] = lambda r, k=key: r[k]
numerical = {}
for key, fn in fields.items():
    values = {v: [fn(r) for r in cohort if r['variant'] == v] for v in ['control', 'candidate']}
    control = statistics.mean(values['control'])
    values['mean_reduction_fraction'] = 1 - statistics.mean(values['candidate']) / control if control else None
    numerical[key] = values
assert numerical == read(root / 'numerical-summary.json')
blocks = []
for rows in [cohort[:4], cohort[4:]]:
    block = {}
    for key in ['compiler_seconds', 'whole_process_seconds', 'frontend_seconds', 'instructions']:
        means = {v: statistics.mean(fields[key](r) for r in rows if r['variant'] == v) for v in ['control', 'candidate']}
        block[key] = dict(means, mean_reduction_fraction=1-means['candidate']/means['control'])
        assert block[key]['mean_reduction_fraction'] > 0
    blocks.append(block)
fixtures = read(root / 'fixture-results.json')
assert len(fixtures) == 14
for row in fixtures:
    name = row['fixture'].split(':')[-1] if ':' in row['fixture'] else Path(row['fixture']).stem
    assert pin(root / 'fixture-inputs' / (name + '.mec'))['sha256'] == row['source_sha256']
    assert row['all_outputs_match'] and row['variants']['control'] == row['variants']['candidate']
    for variant in ['control', 'candidate']:
        d = root / 'fixtures' / name / variant
        command = read(d / 'command.json')
        assert command['flags'] == flags and command['binary_sha256'] == excluded[variant]['sha256']
        assert row['variants'][variant]['exit_code'] == 0 and len(row['variants'][variant]['files']) == 4
        for n, pinned in row['variants'][variant]['files'].items():
            assert pin(d / n) == pinned
inputs = read(root / 'native-link-inputs.json')
for row in inputs:
    assert pin(root / row['path']) == dict(bytes=row['bytes'], sha256=row['sha256'])
links = read(root / 'final-executable-results.json')
assert len(links) == 2
for variant, row in zip(['control', 'candidate'], links):
    assert row['variant'] == variant and row['exit_code'] == 0 and row['matches_complete_baseline_executable'] and not row['fresh_runtime_campaign']
    assert row['executable_sha256'] == '557d0f5ef2b979e01851ae23b5b3944453a0bd9e772d68161be198916ca06c2c'
    assert pin(root / ('link-' + variant) / 'worker') == dict(bytes=row['executable_bytes'], sha256=row['executable_sha256'])
    assert read(root / ('link-' + variant) / 'result.json') == row
    command = read(root / ('link-' + variant) / 'command.json')
    assert command['environment'] == {'ZERO_AR_DATE': '1'}
    assert [(r['source'], r['bytes'], r['sha256']) for r in command['input_pins']] == [(r['source'], r['bytes'], r['sha256']) for r in inputs]
assert (root / 'link-control/worker').read_bytes() == (root / 'link-candidate/worker').read_bytes()
summary = dict(source_commit=state['source_commit'], base_commit=state['base_commit'], flags_count=61, compiler_binary_sha256={v: excluded[v]['sha256'] for v in ['control', 'candidate']}, output_hashes=expected, decision='Retained: borrowed call-argument schemas, unchanged program bytes and exact complete executable; small frontend and instruction reduction.', numerical_summary=numerical, balanced_blocks=blocks, fixture_pairs=len(fixtures), preliminary_screens=screens, build=build, final_links=links, scope=[
    'The eight-run serial ABBA/BAAB cohort excludes screens, fixtures, linking, builds and profiling. Process timing uses process.wait completion; historical polling measurements remain separate.',
    'Only call-argument schema borrowing changes. The exact ResolvedType constructor, overload selection, context checks, schema validation, proof visits and error anchoring remain.',
    'The separate preceding diagnostic observed 15497 shared materializations copying 5911032 declaration entries at this call site. No diagnostic instrumentation is retained or timed here.',
    'Frontend, compiler, process and instruction means improve in both balanced blocks. The frontend mean saving is small; unrelated native-stage movement is observational and is not attributed to the source change. Parsing, catalog and cleanup means increase slightly and remain in the raw and numerical results.',
    'All source, bytecode, Object and complete metadata bytes match, as do fourteen paired scalar/numeric fixtures and the complete final executable. No scalar retirement or fresh runtime campaign is claimed.',
    'Final links use frozen native adapter inputs and canonical paths with ZERO_AR_DATE=1. They measure cached native linking only, not whole source-to-executable completion.',
    'Compiler executables are SHA-pinned and excluded. All generated program files, full executables, frozen native linker inputs, source, patches, commands and raw measurements remain. Pure replay checks saved observations without rerunning compilers or timings.',
    'Parallel function compilation remains a documented architecture, not an implemented or qualified speedup. The sub-ten-second compilation goal remains open.'
])
encoded = json.dumps(summary, indent=2, sort_keys=True) + '\n'
p = root / 'summary.json'
if p.exists():
    assert p.read_text() == encoded
else:
    p.write_text(encoded)
print(encoded, end='')
