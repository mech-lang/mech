from pathlib import Path
import hashlib, json, shutil, subprocess

repo = Path.cwd()
raw = Path('/private/tmp/mech-call-schema-borrow-20261114')
packet = Path('/private/tmp/mech-call-schema-borrow-packet-20261114')
assert not packet.exists()
excluded = []
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
for p in sorted(raw.rglob('*')):
    if not p.is_file():
        continue
    rel = p.relative_to(raw)
    if rel.as_posix() in ['control', 'candidate']:
        excluded.append(dict(path=rel.as_posix(), **pin(p)))
        continue
    dest = packet / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, dest)
base = subprocess.check_output(['git', 'rev-parse', 'HEAD^'], text=True).strip()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert base == 'bb9c4b35919174c6d5daf28542609ff4f7682bc8'
assert subprocess.check_output(['git', 'diff', '--binary', base, head]) == (packet / 'candidate.patch').read_bytes()
source = 'src/engine/src/source_semantics/frontend.rs'
for variant, revision in [('control', base), ('candidate', head)]:
    dest = packet / 'source' / variant / source
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(subprocess.check_output(['git', 'show', revision + ':' + source]))
for name in ['Cargo.toml', 'Cargo.lock', 'compile_profile.rs', 'profile_compile.py']:
    dest = packet / 'source' / 'harness' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(subprocess.check_output(['git', 'show', head + ':benchmarks/mech-deflate/native-profile/' + name]))
for row in json.loads((packet / 'fixture-results.json').read_text()):
    name = row['fixture']
    if name.startswith('hosts/'):
        shutil.copy2(repo / name, packet / 'fixture-inputs' / Path(name).name)
prior = Path('/private/tmp/mech-round2-planning-packet-20261114')
shutil.copytree(prior / 'licenses', packet / 'licenses')
shutil.copytree(prior / 'native-link-inputs', packet / 'native-link-inputs')
shutil.copy2(prior / 'native-link-inputs.json', packet / 'native-link-inputs.json')
validation = packet / 'validation'
validation.mkdir()
for suffix in ['.json', '.archive.json']:
    shutil.copy2(repo / ('benchmarks/mech-deflate/native-profile/point-liveness-compile-apple-m3-20261114' + suffix), validation / ('prior-qualified' + suffix))
for p in Path('/private/tmp').glob('*call-schema-borrow*20261114.py'):
    if p.name != 'mech-replay-call-schema-borrow-20261114.py':
        shutil.copy2(p, packet / p.name)
shutil.copy2('/private/tmp/mech-replay-call-schema-borrow-20261114.py', packet / 'replay.py')
(packet / 'excluded-compiler-products.json').write_text(json.dumps(excluded, indent=2) + '\n')
(packet / 'source-state.json').write_text(json.dumps(dict(source_commit=head, base_commit=base, production_change='Borrow call-argument schemas while retaining the exact ResolvedType constructor, overload resolution, and error anchoring.', compiler_output_identity_required=True, native_link_inputs_from='mech-round2-planning-20261114.tar.gz', runtime_campaign_rerun=False), indent=2) + '\n')
(packet / 'README.txt').write_text('''Call-argument schema borrowing qualification, 2026-11-14.
All eight primary runs, both preliminary screens, fourteen paired fixtures,
build inputs/logs, exact production patch/source, and final native links remain.
Compiler executables are excluded and SHA-pinned; every generated program file,
complete executable, and frozen native-link object/archive input is included.
The two preliminary screens have different startup gaps and are excluded from
the balanced eight-run performance cohort. The complete process uses the new
precise process.wait completion boundary; historical polling cohorts are separate.
The final-link observations use cached runtime/adapter objects and do not measure
whole source-to-executable latency. Every complete executable byte is identical.
The original runtime campaign is not rerun because the generated code is exact.
There are no language, grammar, optimization-decision, or ownership-proof changes.
Primary frontend, compiler and instruction means improve in both balanced blocks;
unrelated native-stage movement and slower parsing/catalog/cleanup observations
are reported without crediting them to the frontend source change.
Pure replay validates all stored measurements, source patch, program output bytes,
fixture sources, native inputs and executable identity without recompiling or
rerunning timings. Sub-ten-second compilation remains an open goal.
''')
print(packet)
