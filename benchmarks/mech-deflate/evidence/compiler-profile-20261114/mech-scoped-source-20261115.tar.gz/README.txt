Scoped source range facts, retained source972039beaaf9f04a609393905b518f4c16cbab67.
Frozen934/newDeflate/newruntime control versus two-file source-map borrowing/
scoped restoration. Both subjects same61programflags plus2workers, standard
compiler profile withoutPGO/nativeCPU overrides. Eight Object and eight separate
complete executable cohorts are serial and uncontended. All raw observations,
adverse counters, exact sources/patches,14fixtures, whole executables and native
inputs remain. Predecessor213 build/test data is superseded before timing by
the934 refresh; changed module bytes are identical and its5tests/112IR-machine
pairs/1760route queries apply exactly. Both harness failures remain. Default0
output/executable gate and two current-source stack samples are diagnostic and
excluded from primary means. The demangler helper's setup typo is preserved.
Compiler/test/analysis executables and intermediates are excluded/SHA-pinned;
dependency cache/toolchain and unchanged compiler sources are not redistributed.
Pure replay checks saved data without rebuilding or rerunning measurements.
No grammar/language change, weaker proof, scalar retirement or fresh program
runtime campaign is claimed. Complete compilation below ten seconds is open.
