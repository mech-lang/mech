from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time

repo=Path.cwd();root=Path('/private/tmp/mech-scoped-source-profile-20261115');assert not root.exists();root.mkdir()
qualified=Path('/private/tmp/mech-scoped-route-ranges-current-20261115');binary=qualified/'candidate';reference=json.loads((qualified/'reference-pins.json').read_text());flags=json.loads((qualified/'runtime-flags.json').read_text());assert len(flags)==61
pin=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
assert pin(binary)['sha256']=='ae517d6c58d4620b999fa43c9138ee804dda85521fffb1611717541545108d01'
commit=json.loads((qualified/'source-commit.json').read_text());records=[]
(root/'configuration.json').write_text(json.dumps(dict(compiler=pin(binary),source_commit=commit['commit'],source_delta_commit_base=commit['parent'],measured_source_base='934bde961d47555db3fa45bc5c28d36ad1c0930a',flags=flags,scope='Separate default-serial output gate followed by two current-qualified-compiler stack diagnostics. Sampled process/counter data is excluded from primary means; no exclusive CPU-time inference from waiting/inclusive stacks.'),indent=2)+'\n')
for name,workers,sample in [('serial-output-gate',0,False),('sample-1',2,True),('sample-2',2,True)]:
    out=root/name;env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')};env.update(flags);env['MECH_COMPACT_COMPILE_THREADS']=str(workers)
    command=[sys.executable,'benchmarks/mech-deflate/native-profile/profile_compile.py',str(binary),'benchmark',str(out),'compact']+(['sample'] if sample else [])
    (root/(name+'-command.json')).write_text(json.dumps(dict(command=command,flags=dict(flags,MECH_COMPACT_COMPILE_THREADS=str(workers)),compiler=pin(binary),profiling_excluded_from_primary=True),indent=2)+'\n')
    started=time.monotonic()
    with (root/(name+'.stdout.log')).open('w') as stdout,(root/(name+'.stderr.log')).open('w') as stderr:completed=subprocess.run(command,cwd=repo,env=env,stdout=stdout,stderr=stderr)
    checks={n:dict(**pin(out/n),matches_frozen_reference=(out/n).read_bytes()==(qualified/'reference'/n).read_bytes()) for n in reference}
    row=dict(name=name,workers=workers,sampled=sample,exit_code=completed.returncode,wrapper_seconds=time.monotonic()-started,process=json.loads((out/'process.json').read_text()),files=checks);records.append(row);(root/'results.json').write_text(json.dumps(records,indent=2)+'\n');assert completed.returncode==0 and all(v['matches_frozen_reference'] for v in checks.values())
    if sample:assert row['process']['samples']>=1 and row['process']['sampling_error'] is None
    else:
        link=Path('/private/tmp/mech-pr973-refresh-20261115/link');capture=json.loads((link/'capture/link-command.json').read_text());shutil.copy2(out/'program.o',link/'program.o')
        for item in capture['inputs']:assert pin(Path(item['source']))=={k:item[k] for k in ['bytes','sha256']}
        with (out/'link.stdout.log').open('w') as stdout,(out/'link.stderr.log').open('w') as stderr:completed=subprocess.run(capture['command'],env=dict(env,ZERO_AR_DATE='1'),stdout=stdout,stderr=stderr)
        assert completed.returncode==0 and (link/'worker').read_bytes()==(link/'worker-baseline').read_bytes();shutil.copy2(link/'worker',out/'worker');row.update(executable=pin(out/'worker'),matches_complete_baseline_executable=True)
        (root/'results.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,'output gate passed',flush=True)
