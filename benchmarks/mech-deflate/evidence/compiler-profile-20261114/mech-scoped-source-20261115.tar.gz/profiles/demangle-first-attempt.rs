#![feature(rustc_private)]
extern crate rustc_demangle;
use std::io::{self, BufRead, Write};
fn main() {
    let mut output = io::BufWriter::new(io::stdout().lock());
    for line in io::stdin().lock().lines() {
        let line = line.unwrap();
        if let Some(start) = line.find("_R").or_else(|| line.find("_ZN")) {
            let end = line[start..].find(char::is_whitespace).map_or(line.len(), |n| start+n);
            writeln!(output, "{}{: #}{}", &line[..start], rustc_demangle::demangle(&line[start..end]), &line[end..]).unwrap();
        } else {
            writeln!(output, "{line}").unwrap();
        }
    }
}
