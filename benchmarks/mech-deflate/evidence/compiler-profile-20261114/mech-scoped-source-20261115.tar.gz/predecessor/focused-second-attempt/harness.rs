#![allow(dead_code)]
mod native_artifact { pub mod program { pub mod prepare { pub mod word_collections { pub mod bounds { include!("range.rs"); } } } pub mod codegen { pub mod cfg_cleanup {
#[path="/private/tmp/mech-scoped-route-ranges-20261115/focused/word_ranges/mod.rs"] mod word_ranges;
#[path="/private/tmp/mech-scoped-route-ranges-20261115/focused/boolean_words.rs"] mod boolean_words;
#[path="/private/tmp/mech-scoped-route-ranges-20261115/focused/boolean_conditions.rs"] mod boolean_conditions;
pub(super) use boolean_conditions::masked_integer_comparison;
#[path="/private/tmp/mech-scoped-route-ranges-20261115/focused/before/mod.rs"] mod before;
#[path="/private/tmp/mech-scoped-route-ranges-20261115/focused/after/mod.rs"] mod after;
#[cfg(test)] mod focused { include!("/private/tmp/mech-scoped-route-ranges-20261115/focused/tests.rs"); }
} } } }
