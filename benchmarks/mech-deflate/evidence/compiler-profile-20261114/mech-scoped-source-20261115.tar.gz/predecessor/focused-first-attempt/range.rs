#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(in crate::native_artifact) struct Range(pub u64, pub u64);
impl Range {
    pub(in crate::native_artifact) fn bit_and(self, other: Self) -> Self {
        if self.0 == self.1 && other.0 == other.1 {
            let value = self.0 & other.0;
            return Self(value, value);
        }
        Self(0, self.1.min(other.1))
    }
    pub(in crate::native_artifact) fn wrapping_mul(self, other: Self) -> Self {
        // If the entire interval fits, no product wraps. Otherwise retain the
        // full unsigned range; saturated upper MAX is valid for every residue.
        Self(0, self.1.saturating_mul(other.1))
    }
}
