
use cranelift_codegen::{Context, ir::{AbiParam, InstBuilder, InstructionData as Data, MemFlags, Opcode, types}, ir::condcodes::IntCC};
use cranelift_frontend::{FunctionBuilder, FunctionBuilderContext};
const ASSERT: u64=u64::MAX-17;
const OVERFLOW: u64=u64::MAX-18;
const MULTIPLIER: u64=0x9e37_79b9;
fn fixture(variant: &str) -> Context {
    let mut c = Context::new();
    c.func.signature.params = vec![AbiParam::new(types::I64); 4];
    c.func.signature.returns = vec![AbiParam::new(types::I64)];
    let mut fc = FunctionBuilderContext::new();
    {
        let mut b = FunctionBuilder::new(&mut c.func, &mut fc);
        let entry = b.create_block();
        let header = b.create_block();
        let dispatch = b.create_block();
        let loop_test = b.create_block();
        let body = b.create_block();
        let guard = b.create_block();
        let stored = b.create_block();
        let done = b.create_block();
        let finish = b.create_block();
        let join = b.create_block();
        let bad_assert = b.create_block();
        let bad_overflow = b.create_block();
        b.append_block_params_for_function_params(entry);
        for ty in [types::I64, types::I64, types::I64, types::F64] {
            b.append_block_param(header, ty);
        }
        b.switch_to_block(entry);
        let args = b.block_params(entry).to_vec();
        let zero = b.ins().iconst(types::I64, 0);
        let one = b.ins().iconst(types::I64, 1);
        let payload = b.ins().bitcast(types::F64, MemFlags::new(), args[0]);
        b.ins().jump(
            header,
            &[zero.into(), zero.into(), args[0].into(), payload.into()],
        );
        b.switch_to_block(header);
        let h = b.block_params(header).to_vec();
        if variant == "effect" {
            b.ins().store(MemFlags::new(), h[0], args[3], 8);
        }
        let loaded = if variant == "load" {
            Some(b.ins().load(types::I64, MemFlags::new(), args[3], 8))
        } else {
            None
        };
        let opaque = if variant == "opaque" {
            Some(b.ins().iadd(h[0], args[2]))
        } else {
            None
        };
        let step = b.ins().icmp_imm(IntCC::Equal, h[0], 0);
        b.ins().brif(step, dispatch, &[], finish, &[]);
        b.switch_to_block(dispatch);
        if variant == "merge" {
            b.ins().brif(args[2], loop_test, &[], join, &[]);
        } else {
            b.ins().jump(loop_test, &[]);
        }
        b.switch_to_block(loop_test);
        let more = b.ins().icmp(IntCC::UnsignedLessThan, h[1], args[1]);
        b.ins().brif(more, body, &[], done, &[]);
        let sum;
        b.switch_to_block(body);
        if variant == "overflow-first" {
            let (s, overflow) = b.ins().uadd_overflow(h[2], one);
            sum = s;
            b.ins().brif(overflow, bad_overflow, &[], guard, &[]);
            b.switch_to_block(guard);
            b.ins().brif(args[2], stored, &[], bad_assert, &[]);
        } else {
            b.ins().brif(args[2], guard, &[], bad_assert, &[]);
            b.switch_to_block(guard);
            let (s, overflow) = b.ins().uadd_overflow(h[2], one);
            sum = s;
            b.ins().brif(overflow, bad_overflow, &[], stored, &[]);
        }
        b.switch_to_block(stored);
        let next = b.ins().iadd(h[1], one);
        b.ins().store(MemFlags::new(), next, args[3], 0);
        b.ins()
            .jump(header, &[zero.into(), next.into(), sum.into(), h[3].into()]);
        b.switch_to_block(done);
        let total = b.ins().iadd_imm(h[2], 17);
        let bits = b.ins().bitcast(types::I64, MemFlags::new(), h[3]);
        let bits = b.ins().bxor(bits, args[2]);
        let payload = b.ins().bitcast(types::F64, MemFlags::new(), bits);
        if variant == "duplicate" {
            let other_total = b.ins().iadd_imm(h[2], 33);
            let old_bits = b.ins().bitcast(types::I64, MemFlags::new(), h[3]);
            let bits = b.ins().bnot(args[2]);
            let bits = b.ins().bxor(old_bits, bits);
            let other = b.ins().bitcast(types::F64, MemFlags::new(), bits);
            b.ins().brif(
                args[2],
                header,
                &[one.into(), h[1].into(), total.into(), payload.into()],
                header,
                &[one.into(), h[1].into(), other_total.into(), other.into()],
            );
        } else {
            b.ins().jump(
                header,
                &[one.into(), h[1].into(), total.into(), payload.into()],
            );
        }
        b.switch_to_block(finish);
        if variant == "merge" {
            let marker = b.ins().iconst(types::I64, 0x55);
            b.ins().store(MemFlags::new(), marker, args[3], 8);
        }
        b.ins().jump(join, &[]);
        b.switch_to_block(join);
        let scaled = b.ins().imul_imm(h[2], MULTIPLIER as i64);
        let bits = b.ins().bitcast(types::I64, MemFlags::new(), h[3]);
        let mut result = b.ins().bxor(scaled, bits);
        if let Some(loaded) = loaded {
            result = b.ins().bxor(result, loaded);
        }
        if let Some(opaque) = opaque {
            result = b.ins().bxor(result, opaque);
        }
        b.ins().return_(&[result]);
        b.switch_to_block(bad_assert);
        let error = b.ins().iconst(types::I64, ASSERT as i64);
        b.ins().return_(&[error]);
        b.switch_to_block(bad_overflow);
        let error = b.ins().iconst(types::I64, OVERFLOW as i64);
        b.ins().return_(&[error]);
        b.seal_all_blocks();
        b.finalize();
    }
    c
}

fn machine(mut c: Context)->Vec<u8> {
    use cranelift_codegen::{isa,settings::{self,Configurable}};
    let mut flags=settings::builder();flags.set("opt_level","speed").unwrap();
    let isa=isa::lookup_by_name("aarch64").unwrap().finish(settings::Flags::new(flags)).unwrap();
    c.compile(&*isa,&mut Default::default()).unwrap().buffer.data().to_vec()
}
#[test]
fn route_plans_restore_source_facts_and_complete_optimizer_matches_original() {
    let flags=cranelift_codegen::settings::Flags::new(cranelift_codegen::settings::builder());
    let mut complete=0;let mut plans=0;let mut successful=0;
    for variant in ["normal","duplicate","overflow-first","effect","load","merge","opaque"] {
        for one in [0u64,1,2,u64::MAX] {
            for zero in [0u64,1] {
                for share in [false,true] {
                    let mut original=fixture(variant);
                    let insts=original.func.layout.blocks().flat_map(|b|original.func.layout.block_insts(b)).collect::<Vec<_>>();
                    for inst in insts {
                        let dfg=&mut original.func.dfg;
                        if let Data::UnaryImm{opcode:Opcode::Iconst,imm}=&mut dfg.insts[inst] {
                            match imm.bits() {0=>*imm=(zero as i64).into(),1=>*imm=(one as i64).into(),_=>{}}
                        }
                        if share && let Data::Brif{blocks,..}=&mut dfg.insts[inst] {
                            if blocks[0].block(&dfg.value_lists)==blocks[1].block(&dfg.value_lists) { blocks[1]=blocks[0]; }
                        }
                    }
                    cranelift_codegen::verify_function(&original.func,&flags).unwrap();
                    original.compute_cfg();original.compute_domtree();
                    for mode in 0..5 {
                        let old=super::before::diagnostic_plans(&original.func,&original.cfg,&original.domtree,mode);
                        let new=super::after::diagnostic_plans(&original.func,&original.cfg,&original.domtree,mode);
                        assert_eq!(old,new,"{variant} one={one} zero={zero} shared={share} mode={mode}");
                        plans+=old.len();successful+=old.iter().filter(|r|r.is_some()).count();
                    }
                    let mut before=Context::for_function(original.func.clone());let mut after=Context::for_function(original.func);
                    before.compute_cfg();before.compute_domtree();after.compute_cfg();after.compute_domtree();
                    let a=super::before::optimize(&mut before.func,&before.cfg,&before.domtree);
                    let b=super::after::optimize(&mut after.func,&after.cfg,&after.domtree);
                    assert_eq!((a.candidates,a.threaded_edges,a.selected_conditions,a.repair_parameters),(b.candidates,b.threaded_edges,b.selected_conditions,b.repair_parameters));
                    cranelift_codegen::verify_function(&before.func,&flags).unwrap();cranelift_codegen::verify_function(&after.func,&flags).unwrap();
                    assert_eq!(before.func.display().to_string(),after.func.display().to_string());
                    assert_eq!(before.func.dfg.num_values(),after.func.dfg.num_values());
                    for value in before.func.dfg.values(){assert_eq!(before.func.dfg.value_def(value),after.func.dfg.value_def(value));}
                    assert_eq!(machine(before),machine(after));complete+=1;
                }
            }
        }
    }
    assert_eq!(complete,112);assert!(successful>0);
    println!("complete IR/alias/machine comparisons: {complete}; route queries/restorations: {plans}; successful plans: {successful}");
}
