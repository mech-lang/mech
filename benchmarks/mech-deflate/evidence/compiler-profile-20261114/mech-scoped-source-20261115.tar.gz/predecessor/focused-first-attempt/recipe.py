from pathlib import Path
import hashlib,json,re,shutil,subprocess,time

repo=Path.cwd();root=Path('/private/tmp/mech-scoped-route-ranges-20261115');out=root/'focused';assert not out.exists();out.mkdir()
prefix='hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/'
pins=[]
def save(relative,text):
    p=out/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
    pins.append(dict(path=relative,sha256=hashlib.sha256(text.encode()).hexdigest()))
for name in ['word_ranges/mod.rs','word_ranges/condition.rs','boolean_words.rs']:
    text=(repo/(prefix+name)).read_text()
    text=text.replace('#[cfg(test)]\nmod tests;\n','')
    save(name,text)
support=(repo/(prefix+'threaded_edges/test_support.rs')).read_text()
fixture=support[support.index('pub(super) fn fixture('):support.index('\npub(super) fn define(')]
fixture=fixture.replace('pub(super) fn fixture(module: &JITModule, variant: &str)', 'fn fixture(variant: &str)',1).replace('let mut c = module.make_context();','let mut c = Context::new();',1)
assert 'module' not in fixture
edge_source=(root/'before'/(prefix+'threaded_edges/mod.rs')).read_text()
edge_source=edge_source[edge_source.index('    let mut edges = Vec::new();'):edge_source.index('    report.candidates = edges.len();')]
for variant in ['before','after']:
    directory=out/variant;directory.mkdir()
    for name in ['mod.rs','route.rs','values.rs','visits.rs']:
        relative=prefix+'threaded_edges/'+name
        snapshot=root/('before' if variant=='before' else 'candidate-source')/relative
        text=snapshot.read_text() if snapshot.exists() else (repo/relative).read_text()
        if name=='mod.rs':
            assert text.count('#[cfg(test)]\nmod test_support;\n#[cfg(test)]\nmod tests;')==1
            text=text.replace('#[cfg(test)]\nmod test_support;\n#[cfg(test)]\nmod tests;','')
            call='route::find(f, dom, edge, known.clone(), &mut visits)' if variant=='before' else 'route::find(f, dom, edge, &mut known, &mut visits)'
            # The wrapper compares every saved plan field and checks the entire
            # shared map after every return, including early refusals.
            text+='''
pub(super) fn diagnostic_plans(f: &Function, cfg: &ControlFlowGraph, dom: &DominatorTree, mode: usize) -> Vec<Option<String>> {
    let mut known=super::boolean_words::derive(f,cfg);
    if mode==1 { known.clear(); }
    if mode>=2 {
        for value in f.dfg.values() {
            let value=f.dfg.resolve_aliases(value);
            let ty=f.dfg.value_type(value);
            if ty.is_int() && !ty.is_vector() && (1..=64).contains(&ty.bits()) {
                known.insert(value,match mode {2=>super::word_ranges::Range(0,0),3=>super::word_ranges::Range(1,1),_=>super::word_ranges::Range(0,u64::MAX>>(64-ty.bits()))});
            }
        }
    }
    let original=known.clone();
'''+edge_source+'''
    let mut visits=visits::Visits::new(f.dfg.num_blocks());
    edges.into_iter().map(|edge| {
        let plan='''+call+''';
        assert_eq!(known,original,"source ranges escaped the route query");
        plan.map(|p|format!("{:?}/{}/{:?}/{:?}/{:?}/{:?}/{:?}/{:?}/{}",p.edge.inst,p.edge.ordinal,p.edge.target,p.edge.args,p.target,p.args,p.skipped,p.repairs,p.conditions))
    }).collect()
}
'''
        save(variant+'/'+name,text)
bounds=(repo/'hosts/gpu/src/native_artifact/program/prepare/word_collections/bounds.rs').read_text()
range_code=bounds[bounds.index('#[derive(Clone, Copy, Debug, Eq, PartialEq)]'):bounds.index('    pub(super) fn kind(kind: Kind)')]+ '}\n'
save('range.rs',range_code)
tests=r'''
use cranelift_codegen::{Context, ir::{AbiParam, InstBuilder, InstructionData as Data, MemFlags, Opcode, types}, ir::condcodes::IntCC};
use cranelift_frontend::{FunctionBuilder, FunctionBuilderContext};
const ASSERT: u64=u64::MAX-17;
const OVERFLOW: u64=u64::MAX-18;
const MULTIPLIER: u64=0x9e37_79b9;
FIXTURE
fn machine(mut c: Context)->Vec<u8> {
    use cranelift_codegen::{isa,settings::{self,Configurable}};
    let mut flags=settings::builder();flags.set("opt_level","speed").unwrap();
    let isa=isa::lookup_by_name("aarch64").unwrap().finish(settings::Flags::new(flags)).unwrap();
    c.compile(&*isa,&mut Default::default()).unwrap().buffer.data().to_vec()
}
#[test]
fn route_plans_restore_source_facts_and_complete_optimizer_matches_original() {
    let flags=cranelift_codegen::settings::Flags::new(cranelift_codegen::settings::builder());
    let mut complete=0;let mut plans=0;let mut successful=0;
    for variant in ["normal","duplicate","overflow-first","effect","load","merge","opaque"] {
        for one in [0u64,1,2,u64::MAX] {
            for zero in [0u64,1] {
                for share in [false,true] {
                    let mut original=fixture(variant);
                    let insts=original.func.layout.blocks().flat_map(|b|original.func.layout.block_insts(b)).collect::<Vec<_>>();
                    for inst in insts {
                        let dfg=&mut original.func.dfg;
                        if let Data::UnaryImm{opcode:Opcode::Iconst,imm}=&mut dfg.insts[inst] {
                            match imm.bits() {0=>*imm=(zero as i64).into(),1=>*imm=(one as i64).into(),_=>{}}
                        }
                        if share && let Data::Brif{blocks,..}=&mut dfg.insts[inst] {
                            if blocks[0].block(&dfg.value_lists)==blocks[1].block(&dfg.value_lists) { blocks[1]=blocks[0]; }
                        }
                    }
                    cranelift_codegen::verify_function(&original.func,&flags).unwrap();
                    original.compute_cfg();original.compute_domtree();
                    for mode in 0..5 {
                        let old=super::before::diagnostic_plans(&original.func,&original.cfg,&original.domtree,mode);
                        let new=super::after::diagnostic_plans(&original.func,&original.cfg,&original.domtree,mode);
                        assert_eq!(old,new,"{variant} one={one} zero={zero} shared={share} mode={mode}");
                        plans+=old.len();successful+=old.iter().filter(|r|r.is_some()).count();
                    }
                    let mut before=Context::for_function(original.func.clone());let mut after=Context::for_function(original.func);
                    before.compute_cfg();before.compute_domtree();after.compute_cfg();after.compute_domtree();
                    let a=super::before::optimize(&mut before.func,&before.cfg,&before.domtree);
                    let b=super::after::optimize(&mut after.func,&after.cfg,&after.domtree);
                    assert_eq!((a.candidates,a.threaded_edges,a.selected_conditions,a.repair_parameters),(b.candidates,b.threaded_edges,b.selected_conditions,b.repair_parameters));
                    cranelift_codegen::verify_function(&before.func,&flags).unwrap();cranelift_codegen::verify_function(&after.func,&flags).unwrap();
                    assert_eq!(before.func.display().to_string(),after.func.display().to_string());
                    assert_eq!(before.func.dfg.num_values(),after.func.dfg.num_values());
                    for value in before.func.dfg.values(){assert_eq!(before.func.dfg.value_def(value),after.func.dfg.value_def(value));}
                    assert_eq!(machine(before),machine(after));complete+=1;
                }
            }
        }
    }
    assert_eq!(complete,112);assert!(successful>0);
    println!("complete IR/alias/machine comparisons: {complete}; route queries/restorations: {plans}; successful plans: {successful}");
}
'''.replace('FIXTURE',fixture)
save('tests.rs',tests)
harness='''#![allow(dead_code)]
mod native_artifact { pub mod program { pub mod prepare { pub mod word_collections { pub mod bounds { include!("range.rs"); } } } pub mod codegen { pub mod cfg_cleanup {
#[path="WORD"] mod word_ranges;
#[path="BOOL"] mod boolean_words;
#[path="BEFORE"] mod before;
#[path="AFTER"] mod after;
#[cfg(test)] mod focused { include!("TESTS"); }
} } } }
'''
for marker,name in [('WORD','word_ranges/mod.rs'),('BOOL','boolean_words.rs'),('BEFORE','before/mod.rs'),('AFTER','after/mod.rs'),('TESTS','tests.rs')]:harness=harness.replace(marker,str(out/name))
save('harness.rs',harness)
rows=[json.loads(x) for x in Path('/private/tmp/mech-round2-pgo-20261114/control-build.jsonl').read_text().splitlines()]
command=['rustc','+nightly-2026-03-03','--crate-name','scoped_route_ranges_tests','--edition=2024','--test',str(out/'harness.rs'),'-C','opt-level=3','-C','lto=thin','-C','codegen-units=1','-D','warnings','-o',str(out/'tests')]
deps=[];directory=None
for name in ['cranelift_codegen','cranelift_frontend','serde']:
    files=[Path(p) for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']==name for p in r['filenames'] if p.endswith('.rlib')]
    assert len(files)==1
    p=files[0];deps.append(dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()));command+=['--extern',name+'='+str(p)]
    if directory is None:directory=p.parent
    else:assert directory==p.parent
command+=['-L','dependency='+str(directory)]
(out/'command.json').write_text(json.dumps(dict(command=command,dependencies=deps,source_pins=pins,scope='Exact old/new production optimizer and route bodies; only automatic repository test modules are removed. Same unchanged range analysis/Boolean derivation and route value/visit modules. Diagnostic wrapper compares every plan field and checks complete source-map restoration after every query under five map modes. Original repository fixture builder changes only its context constructor/signature for the independent harness. Pinned frozen-control Cranelift dependencies keep this separate from the active compiler-tool build.'),indent=2)+'\n')
started=time.monotonic()
with (out/'build.stdout.log').open('w') as stdout,(out/'build.stderr.log').open('w') as stderr:completed=subprocess.run(command,stdout=stdout,stderr=stderr)
row=dict(exit_code=completed.returncode,seconds=time.monotonic()-started)
if completed.returncode==0:row['binary_sha256']=hashlib.sha256((out/'tests').read_bytes()).hexdigest()
(out/'build.json').write_text(json.dumps(row,indent=2)+'\n');assert completed.returncode==0
started=time.monotonic()
with (out/'test.stdout.log').open('w') as stdout,(out/'test.stderr.log').open('w') as stderr:completed=subprocess.run([str(out/'tests'),'--nocapture'],stdout=stdout,stderr=stderr)
row=dict(exit_code=completed.returncode,seconds=time.monotonic()-started);(out/'test.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True);raise SystemExit(completed.returncode)
