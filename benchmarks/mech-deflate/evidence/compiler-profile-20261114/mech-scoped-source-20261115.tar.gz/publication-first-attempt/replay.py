from pathlib import Path
import hashlib,json,re,statistics
packet=Path(__file__).resolve().parent;root=packet/'trial';read=lambda p:json.loads(p.read_text());pins={}
def pin(p):
 if p not in pins:pins[p]=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 return pins[p]
state=read(packet/'source-state.json');raw=read(root/'source-state.json');commit=read(root/'source-commit.json')
assert state['source_revision']==commit['commit']=='972039beaaf9f04a609393905b518f4c16cbab67'
assert state['source_base']==raw['base_commit']=='934bde961d47555db3fa45bc5c28d36ad1c0930a'
assert commit['full_commit_diff_matches_measured_patch'] and commit['full_commit_diff_sha256']==pin(root/'candidate-git.patch')['sha256']==raw['measured_patch_sha256']
assert len(commit['files'])==2 and sorted(commit['files'])==sorted(r['path'] for r in raw['files'])
for row in raw['files']:
 name=row['path'];assert pin(root/'before'/name)['sha256']==row['before_sha256'] and pin(root/'candidate-source'/name)['sha256']==row['after_sha256']
 assert (root/'before'/name).read_bytes()==(packet/'predecessor/before'/name).read_bytes()
 assert (root/'candidate-source'/name).read_bytes()==(packet/'predecessor/candidate-source'/name).read_bytes()
for row in read(packet/'source-config-pins.json'):assert pin(packet/'source-config'/row['path'])=={k:row[k] for k in ['bytes','sha256']}
products={r['path']:r for r in read(packet/'excluded-compiler-products.json')}
binaries={v:products['trial/'+v]['sha256'] for v in ['control','candidate']}
prior=read(packet/'validation/prior-qualified.json');assert pin(packet/'validation/prior-qualified.json')['sha256']==read(packet/'validation/prior-qualified.archive.json')['replay_sha256']
assert binaries['control']==prior['compiler']['sha256'] and read(root/'decision.json')['decision']=='retain'
expected=prior['output_hashes'];assert read(root/'reference-pins.json')==expected
flags=read(root/'runtime-flags.json');assert len(flags)==61;wanted=dict(flags,MECH_COMPACT_COMPILE_THREADS='2')
build=read(root/'candidate-build.json');check=read(root/'candidate-check.json')
for row in [build,check]:assert row['exit_code']==0 and row['base_commit']==state['source_base'] and row['patch_sha256']==raw['measured_patch_sha256'] and row['CARGO_INCREMENTAL']=='0'
assert build['binary_sha256']==binaries['candidate']
pipeline=read(root/'qualification-pipeline.json');assert [r['stage'] for r in pipeline]==['screens','executable-gates','fixtures-object-cohort','native-cohort'] and all(r['state']=='complete' and r['exit_code']==0 for r in pipeline)
tests=packet/'predecessor/focused';assert read(tests/'test.json')['exit_code']==read(tests/'build.json')['exit_code']==0
assert read(tests/'build.json')['binary_sha256']==products['predecessor/focused/tests']['sha256']
test_output=(tests/'test.stdout.log').read_text();assert 'test result: ok. 5 passed; 0 failed' in test_output and 'complete IR/alias/machine comparisons: 112; route queries/restorations: 1760; successful plans: 456' in test_output
for row in read(tests/'command.json')['source_pins']:assert pin(tests/row['path'])['sha256']==row['sha256']
for variant,folder in [('before','before'),('after','candidate-source')]:
 for row in raw['files']:
  name=Path(row['path']).name;actual=(tests/variant/name).read_text();source=(root/folder/row['path']).read_text()
  if name=='mod.rs':source=source.replace('#[cfg(test)]\nmod test_support;\n#[cfg(test)]\nmod tests;','');assert actual.startswith(source) and 'fn diagnostic_plans' in actual[len(source):]
  else:assert actual==source
first=packet/'predecessor/focused-first-attempt';assert read(first/'build.json')['exit_code']==1 and 'unresolved import' in (first/'build.stderr.log').read_text() and "can't find crate for `serde`" in (first/'build.stderr.log').read_text()
second=packet/'predecessor/focused-second-attempt';assert read(second/'test.json')['exit_code']==101 and 'cfg had unexpected predecessor' in (second/'test.stderr.log').read_text() and '4 passed; 1 failed' in (second/'test.stdout.log').read_text()

order=[('control','control-1'),('candidate','candidate-1'),('candidate','candidate-2'),('control','control-2'),('candidate','candidate-3'),('control','control-3'),('control','control-4'),('candidate','candidate-4')]
rows=[];screens=[]
for variant,name in [('control','control-screen'),('candidate','candidate-screen')]+order:
 d=root/name;command=read(root/(name+'-command.json'));process=read(d/'process.json');compile=read(d/'compile.json');checks=read(d/'output-check.json')
 assert command['flags']==wanted and not command['profiling_excluded_from_primary']
 assert command['binary_sha256']==binaries[variant]
 assert process['exit_code']==0 and process['samples']==0 and process['sampling_error'] is None
 assert process['elapsed_boundary']=='driver_start_to_process_wait_completion' and process['elapsed_seconds']>compile['total_seconds']
 for n,item in expected.items():assert pin(d/n)==item and checks[n]==dict(item,matches_current_control_output=True)
 row=dict(name=name,variant=variant,compile=compile,process=process,files=checks)
 if name.endswith('-screen'):screens.append(row);continue
 stamps=[json.loads(line) for line in (d/'stages.jsonl').read_text().splitlines()];elapsed=lambda prefix:next(s['elapsed'] for s in stamps if s['line'].startswith(prefix))
 for key,begin,end in [('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]:row[key]=elapsed(end)-elapsed(begin)
 log=(d/'stderr.log').read_text()
 for key,pattern in [('instructions',r'(\d+)  instructions retired'),('max_rss_bytes',r'(\d+)  maximum resident set size'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]:row[key]=int(re.search(pattern,log).group(1))
 row['compaction_seconds']=elapsed('compact-stage: CFG cleanup')-elapsed('compact-stage: compact values before=');row['cleanup_including_compaction_seconds']=row['cleanup_seconds']+row['compaction_seconds']
 for key,prefix in [('value_ids_before','compact-stage: compact values before='),('value_ids_after','compact-values: retained=')]:row[key]=int(next(s['line'] for s in stamps if s['line'].startswith(prefix)).split('=')[-1])
 assert (row['value_ids_before'],row['value_ids_after'])==tuple(state['value_compaction'])
 rows.append(row)
assert rows==read(root/'cohort.json')
fields={'compiler_seconds':lambda r:r['compile']['total_seconds'],'whole_process_seconds':lambda r:r['process']['elapsed_seconds']}
for phase in ['parse','catalog','frontend','artifact','encode','native']:fields[phase+'_seconds']=lambda r,p=phase:next(x['seconds'] for x in r['compile']['phases'] if x['phase']==p)
for key in ['canonical_lowering_seconds','preparation_seconds','numeric_generation_seconds','source_cfg_seconds','cleanup_including_compaction_seconds','cleanup_seconds','compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:fields[key]=lambda r,k=key:r[k]
numerical={}
for key,fn in fields.items():
 x={v:[fn(r) for r in rows if r['variant']==v] for v in ['control','candidate']};x['mean_reduction_fraction']=1-statistics.mean(x['candidate'])/statistics.mean(x['control']);numerical[key]=x
assert numerical==read(root/'numerical-summary.json')
blocks=[]
for subset in [rows[:4],rows[4:]]:
 block={}
 for key in ['compiler_seconds','whole_process_seconds','cleanup_including_compaction_seconds','instructions']:
  x={v:statistics.mean(fields[key](r) for r in subset if r['variant']==v) for v in ['control','candidate']};x['mean_reduction_fraction']=1-x['candidate']/x['control'];block[key]=x
 assert block['compiler_seconds']['mean_reduction_fraction']>0 and block['cleanup_including_compaction_seconds']['mean_reduction_fraction']>0
 blocks.append(block)
fixtures=read(root/'fixture-results.json');assert len(fixtures)==14
for row in fixtures:
 name=row['fixture'].split(':')[-1] if ':' in row['fixture'] else Path(row['fixture']).stem
 assert pin(root/'fixture-inputs'/(name+'.mec'))['sha256']==row['source_sha256'] and row['all_outputs_match'] and row['variants']['control']==row['variants']['candidate']
 for variant in ['control','candidate']:
  d=root/'fixtures'/name/variant;command=read(d/'command.json');assert command['flags']==wanted and command['binary_sha256']==binaries[variant]
  assert row['variants'][variant]['exit_code']==0 and len(row['variants'][variant]['files'])==4
  for n,item in row['variants'][variant]['files'].items():assert pin(d/n)==item

inputs = read(packet / 'native-link-inputs.json')
for row in inputs: assert pin(packet / row['path']) == {k: row[k] for k in ['bytes','sha256']}
links = read(root / 'final-executable-results.json')
assert len(links) == 2
executable_pin = dict(bytes=2060440, sha256='d6c65cc3fb18acc4be77dce329962105bf0f2b56dd2623a12f466256463eca61')
for variant, row in zip(['control','candidate'],links):
    assert row['variant'] == variant and row['exit_code'] == 0 and row['matches_complete_baseline_executable'] and not row['fresh_runtime_campaign']
    assert pin(root / ('link-' + variant) / 'worker') == executable_pin == {k: row['executable_' + k] for k in ['bytes','sha256']}
    assert read(root / ('link-' + variant) / 'result.json') == row
    command = read(root / ('link-' + variant) / 'command.json')
    assert command['environment'] == {'ZERO_AR_DATE':'1'}
    assert [(r['source'],r['bytes'],r['sha256']) for r in command['input_pins']] == [(r['source'],r['bytes'],r['sha256']) for r in inputs]
native_order = [(v,'native-' + name) for v,name in order]
native = read(root / 'native-cohort.json')
assert [(r['variant'],r['name']) for r in native] == native_order
for row in native:
    directory = root / row['name']
    actual = read(directory / 'result.json')
    assert actual == {k:v for k,v in row.items() if k != 'name'}
    assert row['primary_cohort'] and row['cached_adapter_objects'] and row['compiler_exit_code'] == row['link_exit_code'] == 0
    assert row['matches_complete_baseline_executable'] and pin(directory / 'worker') == executable_pin
    assert abs(row['source_to_executable_seconds'] - sum(row[k] for k in ['source_to_object_process_seconds','object_handoff_seconds','native_link_seconds'])) < 1e-8
    command = read(directory / 'command.json')
    assert command['flags'] == wanted and command['compiler_sha256'] == binary_sha[row['variant']] and command['ZERO_AR_DATE'] == '1'
    for filename, item in expected.items():
        assert pin(directory / filename) == item and row['files'][filename] == dict(item, matches_frozen_reference=True)
native_summary = read(root / 'native-numerical-summary.json')
native_numerical = {}
for key in ['source_to_executable_seconds','source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']:
    values = {v:[r[key] for r in native if r['variant'] == v] for v in ['control','candidate']}
    values['mean_reduction_fraction'] = 1-statistics.mean(values['candidate'])/statistics.mean(values['control'])
    native_numerical[key] = values
native_blocks = []
for rows in [native[:4],native[4:]]:
    means = {v:statistics.mean(r['source_to_executable_seconds'] for r in rows if r['variant'] == v) for v in ['control','candidate']}
    means['mean_reduction_fraction'] = 1-means['candidate']/means['control']
    assert means['mean_reduction_fraction'] > 0
    native_blocks.append(means)
assert native_summary['numerical_summary'] == native_numerical and native_summary['balanced_blocks'] == native_blocks
assert native_summary['order'] == [list(r) for r in native_order]


profiles=packet/'profiles';profile_config=read(profiles/'configuration.json');assert profile_config['source_commit']==state['source_revision'] and profile_config['compiler']['sha256']==binaries['candidate']
diagnostics=read(profiles/'results.json');assert [r['name'] for r in diagnostics]==['serial-output-gate','sample-1','sample-2']
for row in diagnostics:
 directory=profiles/row['name'];command=read(profiles/(row['name']+'-command.json'));assert command['flags']==dict(flags,MECH_COMPACT_COMPILE_THREADS=str(row['workers'])) and command['compiler']['sha256']==binaries['candidate'] and command['profiling_excluded_from_primary']
 assert row['exit_code']==0 and row['process']==read(directory/'process.json') and row['process']['sampling_error'] is None
 for name,item in expected.items():assert pin(directory/name)==item and row['files'][name]==dict(item,matches_frozen_reference=True)
 if row['sampled']:
  assert row['workers']==2 and row['process']['samples']==1
  files=list(directory.glob('sample-*.txt'));assert len(files)==1 and 'Call graph:' in files[0].read_text() and 'compile-profile' in files[0].read_text()
 else:assert row['workers']==0 and row['process']['samples']==0 and row['matches_complete_baseline_executable'] and row['executable']==executable_pin==pin(directory/'worker')
assert read(profiles/'demangle-first-attempt.json')['exit_code']==1 and read(profiles/'demangle-build.json')['exit_code']==0
assert read(profiles/'demangle-build.json')['binary_sha256']==products['profiles/demangle']['sha256']
summary=dict(source_revision=state['source_revision'],source_base=state['source_base'],source_commit=commit,decision='retain',program_flags_count=61,common_compile_threads=2,compiler_binary_sha256=binaries,output_hashes=expected,final_executable=executable_pin,build=build,check=check,paired_complete_ir_alias_machine_comparisons=112,route_queries_with_full_source_map_restoration=1760,successful_route_plans=456,fixture_pairs=14,numerical_summary=numerical,balanced_blocks=blocks,native_cohort=native_summary,preliminary_screens=screens,final_links=links,serial_gate_and_current_profiles=diagnostics,scope=[
 'Borrow the current pass source-range map and temporarily narrow at most one branch condition; restore the exact prior entry on every exit before another edge. All original route-local facts and proof checks remain. Current Deflate/runtime baseline934, retained source972, identical measured two-file diff. No grammar/language change or fresh-proof bypass.',
 'Eight source-to-Object and eight separate complete executable compiles run serially inABBA/BAAB order with same61flags plus2workers in both subjects. No concurrent heavy build/test/sample/hash/archive work during primary timing. Complete native builds reuse freshly pinned current runtime/entry adapter inputs; first-use construction is excluded.',
 'Cleanup13.21%,instructions3.26%,compiler phases2.45%and complete build2.68%improve, with both blocks faster. Slight RSS/footprint and other stage increases remain. Every source/bytecode/Object/complete metadata and full native executable byte matches; no scalar retirement or new program-runtime campaign is claimed.',
 'Five focused tests compare112 complete IR/alias/machine pairs and1760 route queries under five source-map modes,456successfulplans, with complete source-map restoration checked after every query. Actual changed source files are byte-identical across the predecessor213 build and refreshed934 candidate. Both initial harness failures remain; missing dependency/module setup executes no tests, and the next harness omits CFG refresh after the original optimizer changes edges. Fixes change no production source.',
 'After primary cohorts, the qualified source972 compiler passes the default0worker full-output/executable gate and two separate2worker stack samples. Sampled process/counter data is diagnostic, excluded from primary means; waiting/inclusive stacks are not phase CPU percentages. Raw and demangled samples, Rust helper/source/receipts and its format-string setup failure remain.',
 'All superseded predecessor build/test data, exact source/patches, commands/logs, complete outputs/executables, current native inputs and pure replay are included. Compiler/test/analysis executables and intermediates are excluded/SHA-pinned. Replay checks saved data without rebuilding/rerunning timings. Sub-ten-second compilation remains unachieved.'
])
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';saved=packet/'summary.json'
if saved.exists():assert saved.read_text()==encoded
else:saved.write_text(encoded)
print(encoded,end='')
