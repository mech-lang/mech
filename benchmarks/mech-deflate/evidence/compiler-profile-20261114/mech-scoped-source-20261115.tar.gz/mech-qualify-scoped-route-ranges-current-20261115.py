from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time

repo=Path.cwd();root=Path('/private/tmp/mech-scoped-route-ranges-current-20261115');scripts=root/'qualification-scripts';state=json.loads((root/'source-state.json').read_text())
assert state['base_commit']=='934bde961d47555db3fa45bc5c28d36ad1c0930a'
assert json.loads((root/'candidate-build.json').read_text())['exit_code']==0
paths=[r['path'] for r in state['files']]
assert subprocess.check_output(['git','diff','--binary','--',*paths])==(root/'candidate-git.patch').read_bytes()
for row in state['files']:
    assert (repo/row['path']).read_bytes()==(root/'candidate-source'/row['path']).read_bytes()
    assert (root/'candidate-source'/row['path']).read_bytes()==(Path(state['focused_predecessor'])/'candidate-source'/row['path']).read_bytes()
assert json.loads((Path(state['focused_predecessor'])/'focused/test.json').read_text())['exit_code']==0
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
binary={v:dict(bytes=(root/v).stat().st_size,sha256=sha(root/v)) for v in ['control','candidate']}
assert binary['candidate']['sha256']==json.loads((root/'candidate-build.json').read_text())['binary_sha256']
assert binary['control']['sha256']=='62d4c538752bfe12bc787baea855e1a93c88495c4ef22afe4175235c1eca9647'
config=dict(source_base=state['base_commit'],patch_sha256=sha(root/'candidate-git.patch'),compiler=binary,common_compile_threads=2,program_flags_count=61,focused_predecessor=state['focused_predecessor'],scope='Frozen934/newDeflate/newruntime standard compiler versus scoped source-range-map restoration. Actual changed module snapshots are byte-identical to the passing112completeIR/machine/1760route-query tests. Four outputs/current complete executable must match. No other heavy jobs during primary cohorts. Finish this frozen qualification if remote advances; integrate/recheck afterward.')
(root/'qualification.json').write_text(json.dumps(config,indent=2)+'\n')
env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')};records=[]
for stage,filename in [('screens','mech-screen-scoped-route-current-20261115.py'),('executable-gates','mech-cached-native-link-scoped-route-current-20261115.py'),('fixtures-object-cohort','mech-qualify-scoped-route-current-20261115.py'),('native-cohort','mech-native-cohort-scoped-route-current-20261115.py')]:
    command=[sys.executable,str(scripts/filename)];row=dict(stage=stage,state='running',command=command,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(row);(root/'qualification-pipeline.json').write_text(json.dumps(records,indent=2)+'\n');started=time.monotonic()
    with (root/(stage+'.stdout.log')).open('w') as stdout,(root/(stage+'.stderr.log')).open('w') as stderr:completed=subprocess.run(command,cwd=repo,env=env,stdout=stdout,stderr=stderr)
    row.update(state='complete' if completed.returncode==0 else 'failed',seconds=time.monotonic()-started,exit_code=completed.returncode);(root/'qualification-pipeline.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True);assert completed.returncode==0
