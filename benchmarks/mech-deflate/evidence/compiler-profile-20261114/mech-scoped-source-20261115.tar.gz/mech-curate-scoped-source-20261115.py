from pathlib import Path
import hashlib,json,shutil,subprocess

repo=Path.cwd();packet=Path('/private/tmp/mech-scoped-source-packet-20261115');assert not packet.exists();packet.mkdir()
pin=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
roots={'trial':Path('/private/tmp/mech-scoped-route-ranges-current-20261115'),'predecessor':Path('/private/tmp/mech-scoped-route-ranges-20261115'),'profiles':Path('/private/tmp/mech-scoped-source-profile-20261115')};excluded=[]
for label,root in roots.items():
 for p in sorted(root.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(root);name=rel.as_posix()
  omit=name in ['control','candidate','demangle'] or (name.startswith('focused') and p.name=='tests')
  if omit:excluded.append(dict(path=label+'/'+name,**pin(p)));continue
  dest=packet/label/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
trial=roots['trial'];commit=json.loads((trial/'source-commit.json').read_text());rows=json.loads((trial/'cohort.json').read_text());state=dict(source_revision=commit['commit'],source_base=json.loads((trial/'source-state.json').read_text())['base_commit'],value_compaction=[rows[0]['value_ids_before'],rows[0]['value_ids_after']]);(packet/'source-state.json').write_text(json.dumps(state,indent=2)+'\n')
paths=['.cargo/config.toml','Cargo.toml','Cargo.lock','benchmarks/mech-deflate/native-profile/Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.lock','benchmarks/mech-deflate/native-profile/compile_profile.rs','benchmarks/mech-deflate/native-profile/profile_compile.py','hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/threaded_edges/test_support.rs','hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/threaded_edges/values.rs','hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/threaded_edges/visits.rs','hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/word_ranges/mod.rs','hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/word_ranges/condition.rs','hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/boolean_words.rs','hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/boolean_conditions.rs','hosts/gpu/src/native_artifact/program/prepare/word_collections/bounds.rs'];pins=[]
for name in paths:
 content=subprocess.check_output(['git','show',state['source_revision']+':'+name]);dest=packet/'source-config'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(content);pins.append(dict(path=name,**pin(dest)))
(packet/'source-config-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
for row in json.loads((trial/'fixture-results.json').read_text()):
 if row['fixture'].startswith('hosts/'):(packet/'trial/fixture-inputs'/Path(row['fixture']).name).write_bytes(subprocess.check_output(['git','show',state['source_base']+':'+row['fixture']]))
capture=json.loads(Path('/private/tmp/mech-pr973-refresh-20261115/link/capture/link-command.json').read_text());inputs=[]
for at,row in enumerate(capture['inputs']):
 p=Path(row['retained_path']);wanted={k:row[k] for k in ['bytes','sha256']};assert pin(p)==wanted
 rel=Path('native-link-inputs')/(str(at)+'-'+p.name);dest=packet/rel;dest.parent.mkdir(exist_ok=True);shutil.copy2(p,dest);inputs.append(dict(source=row['source'],path=rel.as_posix(),**wanted))
(packet/'native-link-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n');(packet/'excluded-compiler-products.json').write_text(json.dumps(excluded,indent=2)+'\n')
shutil.copytree('/private/tmp/mech-round2-planning-packet-20261114/licenses',packet/'licenses');validation=packet/'validation';validation.mkdir()
for suffix in ['.json','.archive.json']:shutil.copy2(repo/'benchmarks/mech-deflate/native-profile'/('refreshed-parallel-apple-m3-20261115'+suffix),validation/('prior-qualified'+suffix))
for name in ['mech-draft-scoped-route-ranges-20261115.py','mech-build-scoped-route-ranges-20261115.py','mech-build-scoped-route-ranges-current-20261115.py','mech-test-scoped-route-ranges-20261115.py','mech-qualify-scoped-route-ranges-current-20261115.py','mech-profile-scoped-source-20261115.py','mech-prepare-scoped-source-evidence-20261115.py','mech-curate-scoped-source-20261115.py']:shutil.copy2(Path('/private/tmp')/name,packet/name)
shutil.copy2('/private/tmp/mech-replay-scoped-source-20261115.py',packet/'replay.py')
(packet/'README.txt').write_text('''Scoped source range facts, retained source972039beaaf9f04a609393905b518f4c16cbab67.
Frozen934/newDeflate/newruntime control versus two-file source-map borrowing/
scoped restoration. Both subjects same61programflags plus2workers, standard
compiler profile withoutPGO/nativeCPU overrides. Eight Object and eight separate
complete executable cohorts are serial and uncontended. All raw observations,
adverse counters, exact sources/patches,14fixtures, whole executables and native
inputs remain. Predecessor213 build/test data is superseded before timing by
the934 refresh; changed module bytes are identical and its5tests/112IR-machine
pairs/1760route queries apply exactly. Both harness failures remain. Default0
output/executable gate and two current-source stack samples are diagnostic and
excluded from primary means. The demangler helper's setup typo is preserved.
Compiler/test/analysis executables and intermediates are excluded/SHA-pinned;
dependency cache/toolchain and unchanged compiler sources are not redistributed.
Pure replay checks saved data without rebuilding or rerunning measurements.
No grammar/language change, weaker proof, scalar retirement or fresh program
runtime campaign is claimed. Complete compilation below ten seconds is open.
''');print(packet)
