from pathlib import Path
import difflib, hashlib, json, subprocess

repo = Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech')
root = Path('/private/tmp/mech-scoped-route-ranges-20261115')
assert not root.exists()
root.mkdir()
base = subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
prefix = 'hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/threaded_edges/'
paths = [prefix+'mod.rs', prefix+'route.rs']
patch = []
records = []
for relative in paths:
    old = (repo / relative).read_text()
    assert old == subprocess.check_output(['git','show',base+':'+relative],cwd=repo,text=True)
    new = old
    if relative.endswith('/mod.rs'):
        assert new.count('let known = super::boolean_words::derive(f, cfg);') == 1
        new = new.replace('let known = super::boolean_words::derive(f, cfg);','let mut known = super::boolean_words::derive(f, cfg);')
        assert new.count('route::find(f, dom, edge, known.clone(), &mut visits)') == 1
        new = new.replace('route::find(f, dom, edge, known.clone(), &mut visits)','route::find(f, dom, edge, &mut known, &mut visits)')
    else:
        anchor = 'pub(super) fn find(\n'
        assert new.count(anchor) == 1
        helper = '''// A route narrows at most one source-edge fact. Restore that entry when
// discovery finishes, including every early refusal, before the next edge.
struct SourceRanges<'a> {
    known: &'a mut BTreeMap<Value, Range>,
    prior: Option<(Value, Option<Range>)>,
}

impl Drop for SourceRanges<'_> {
    fn drop(&mut self) {
        if let Some((value, prior)) = self.prior {
            if let Some(range) = prior {
                self.known.insert(value, range);
            } else {
                self.known.remove(&value);
            }
        }
    }
}

'''
        new = new.replace(anchor,helper+anchor)
        assert new.count('mut known: BTreeMap<Value, Range>,') == 1
        new = new.replace('mut known: BTreeMap<Value, Range>,', 'known: &mut BTreeMap<Value, Range>,')
        anchor = '    if let Data::Brif { arg, .. } = f.dfg.insts[edge.inst] {'
        assert new.count(anchor) == 1
        new = new.replace(anchor,'    let mut source_ranges = SourceRanges { known, prior: None };\n'+anchor)
        assert new.count('let bound = known\n') == 1
        new = new.replace('let bound = known\n', 'let bound = source_ranges.known\n')
        assert new.count('            known.insert(arg, bound);') == 1
        new = new.replace('            known.insert(arg, bound);','            source_ranges.prior = Some((arg, source_ranges.known.insert(arg, bound)));')
        anchor = '    // A constant current tag is the witness; unrestricted payload words alone\n'
        assert new.count(anchor) == 1
        new = new.replace(anchor,'    let source_known = &*source_ranges.known;\n'+anchor)
        new = new.replace('values::source(f, v, &known)','values::source(f, v, source_known)')
        assert new.count('    let source_known = known;\n') == 1
        new = new.replace('    let source_known = known;\n','')
        new = new.replace('&source_known', 'source_known')
        # Everything after source binding is unchanged except removal of an
        # unnecessary reference to the now-borrowed source map.
        old_body = old.split('    let mut known = BTreeMap::new();\n',1)[1]
        new_body = new.split('    let mut known = BTreeMap::new();\n',1)[1]
        assert new_body == old_body.replace('&source_known','source_known')
    for side, text in [('before',old),('after',new)]:
        p = root / side / relative
        p.parent.mkdir(parents=True,exist_ok=True)
        p.write_text(text)
    patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative))
    records.append(dict(path=relative,before_sha256=hashlib.sha256(old.encode()).hexdigest(),after_sha256=hashlib.sha256(new.encode()).hexdigest()))
text = ''.join(patch)
(root/'candidate.patch').write_text(text)
(root/'draft.json').write_text(json.dumps(dict(base_commit=base,patch_sha256=hashlib.sha256(text.encode()).hexdigest(),files=records,state='Draft only, not applied/built/tested/measured. The current native-CPU+PGO qualification remains separate.'),indent=2)+'\n')
print('drafted two-file patch without changing production source')
