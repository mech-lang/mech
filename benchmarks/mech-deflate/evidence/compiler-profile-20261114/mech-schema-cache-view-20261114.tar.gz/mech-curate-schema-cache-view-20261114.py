from pathlib import Path
import hashlib, json, shutil, subprocess

repo = Path.cwd()
raw = Path('/private/tmp/mech-schema-cache-view-20261114')
packet = Path('/private/tmp/mech-schema-cache-view-packet-20261114')
assert not packet.exists()
excluded = []
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
for p in sorted(raw.rglob('*')):
    if not p.is_file():
        continue
    rel = p.relative_to(raw)
    if rel.as_posix() in ['control', 'candidate', 'pending-schema-tests']:
        excluded.append(dict(path=rel.as_posix(), **pin(p)))
        continue
    dest = packet / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, dest)
base = subprocess.check_output(['git', 'rev-parse', 'HEAD^'], text=True).strip()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert base == '4057eb4364d496c66bad911394249007b1426590'
assert subprocess.check_output(['git', 'diff', '--binary', base, head]) == (packet / 'candidate.patch').read_bytes()
sources = ['src/engine/src/source_semantics/' + n for n in ['frontend.rs', 'pending_schema.rs', 'application.rs', 'comprehension.rs']]
for source in sources:
    for variant, revision in [('control', base), ('candidate', head)]:
        dest = packet / 'source' / variant / source
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(subprocess.check_output(['git', 'show', revision + ':' + source]))
for name in ['Cargo.toml', 'Cargo.lock', 'compile_profile.rs', 'profile_compile.py', 'pending_schema_tests.rs']:
    dest = packet / 'source' / 'harness' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(subprocess.check_output(['git', 'show', head + ':benchmarks/mech-deflate/native-profile/' + name]))
for row in json.loads((packet / 'fixture-results.json').read_text()):
    name = row['fixture']
    if name.startswith('hosts/'):
        shutil.copy2(repo / name, packet / 'fixture-inputs' / Path(name).name)
prior = Path('/private/tmp/mech-round2-planning-packet-20261114')
shutil.copytree(prior / 'licenses', packet / 'licenses')
shutil.copytree(prior / 'native-link-inputs', packet / 'native-link-inputs')
shutil.copy2(prior / 'native-link-inputs.json', packet / 'native-link-inputs.json')
validation = packet / 'validation'
validation.mkdir()
for suffix in ['.json', '.archive.json']:
    shutil.copy2(repo / ('benchmarks/mech-deflate/native-profile/call-schema-borrow-compile-apple-m3-20261114' + suffix), validation / ('prior-qualified' + suffix))
for p in Path('/private/tmp').glob('*schema-cache*20261114.py'):
    if p.name != 'mech-replay-schema-cache-view-20261114.py':
        shutil.copy2(p, packet / p.name)
shutil.copy2('/private/tmp/mech-replay-schema-cache-view-20261114.py', packet / 'replay.py')
probe = Path('/private/tmp/mech-parallel-object-boundary-20261114')
assert json.loads((probe / 'run.json').read_text())['exit_code'] == 0
for p in sorted(probe.rglob('*')):
    if not p.is_file(): continue
    dest = Path('parallel-boundary-probe') / p.relative_to(probe)
    if p.name == 'probe':
        excluded.append(dict(path=dest.as_posix(), **pin(p))); continue
    d = packet / dest; d.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(p, d)
shutil.copy2('/private/tmp/mech-parallel-object-boundary-20261114.rs', packet/'parallel-boundary-probe/probe.rs')
shutil.copy2('/private/tmp/mech-build-parallel-object-boundary-20261114.py', packet/'parallel-boundary-probe/build-and-run.py')
(packet / 'excluded-compiler-products.json').write_text(json.dumps(excluded, indent=2) + '\n')
(packet / 'source-state.json').write_text(json.dumps(dict(source_commit=head, base_commit=base, production_change='Preserve PendingSchema canonicalization cache owners through assembly and nested control visitors; raw drafts retain uncached finalization.', compiler_output_identity_required=True, native_link_inputs_from='mech-round2-planning-20261114.tar.gz', runtime_campaign_rerun=False), indent=2) + '\n')
(packet / 'README.txt').write_text("""Schema cache owner reuse and parallel backend boundary evidence, 2026-11-14.
The private borrowed schema view retains existing PendingSchema cache ownership
through schema-table assembly and nested control visitors. Raw drafts retain
their original path. Pure canonicalization and mutation invalidation are unchanged;
fresh shape, factory, ownership and visit proofs are not cached or skipped.
Five focused production cache tests, fourteen paired fixtures, both screens,
eight serial primary compiles and full executable byte gates pass.
Frontend and retired-instruction reductions repeat in both balanced blocks;
whole-compiler time is effectively flat with mixed blocks. All adverse native,
source-CFG, parser, catalog and memory observations remain. Two separate complete
source-to-executable observations reuse the fixed adapter and are outside the
primary source-to-Object cohort. First-use adapter construction is excluded.
The standalone worker probe compares serial publication against one, two and
four workers over two synthetic native functions with local/imported calls and
data relocations. All 24 Object/optimized-IR/metric comparisons pass. It is not
a production Mech scheduler or a measured Deflate parallel speedup. Its first
direct-link failure (LLVM bitcode/system LTO mismatch) and ThinLTO repair remain.
Every generated program file, executable and native link input is included.
Compiler/probe/test executables are excluded and SHA-pinned. Pure replay checks
saved observations and bytes without rerunning compilers or timings. The
sub-ten-second compilation goal remains open.
""")
print(packet)
