from pathlib import Path
import hashlib, json, re, statistics

root = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_text())
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
state = read(root / 'source-state.json')
excluded = {r['path']: r for r in read(root / 'excluded-compiler-products.json')}
prior = read(root / 'validation/prior-qualified.json')
assert pin(root / 'validation/prior-qualified.json')['sha256'] == read(root / 'validation/prior-qualified.archive.json')['replay_sha256']
flags = read(root / 'runtime-flags.json')
assert len(flags) == 61 and flags['MECH_COMPACT_REUSE_OVERWRITTEN_RESULT'] == '1'
build = read(root / 'candidate-build.json')
assert build['exit_code'] == 0 and build['head'] == state['base_commit']
assert pin(root / 'candidate.patch')['sha256'] == build['patch_sha256']
assert excluded['candidate']['sha256'] == build['binary_sha256']
assert excluded['control']['sha256'] == prior['compiler_binary_sha256']['candidate']
def apply_source_patch(base,patch):
 lines=base.splitlines(keepends=True);out=[];cursor=0;diff=patch.splitlines(keepends=True);assert sum(line.startswith('diff --git ') for line in diff)==1
 i=0
 while i<len(diff):
  match=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',diff[i])
  if not match:i+=1;continue
  at=int(match[1])-1;assert at>=cursor;out.extend(lines[cursor:at]);cursor=at;old_count=0;new_count=0;i+=1
  while i<len(diff) and not diff[i].startswith('@@ '):
   line=diff[i];tag=line[:1];assert tag in [' ','+','-']
   if tag in [' ','-']:assert lines[cursor]==line[1:];cursor+=1;old_count+=1
   if tag in [' ','+']:out.append(line[1:]);new_count+=1
   i+=1
  assert old_count==int(match[2] or 1) and new_count==int(match[4] or 1)
 out.extend(lines[cursor:]);return ''.join(out)
patch = (root/'candidate.patch').read_text()
names = []
for block in patch.split('diff --git ')[1:]:
    block = 'diff --git ' + block
    match = re.match(r'diff --git a/(.+) b/\1\n', block)
    assert match
    name = match[1]; names.append(name)
    assert apply_source_patch((root/'source/control'/name).read_text(), block) == (root/'source/candidate'/name).read_text()
assert set(names) == {'src/engine/src/source_semantics/'+n for n in ['frontend.rs','pending_schema.rs','application.rs','comprehension.rs']}
expected = prior['output_hashes']
assert read(root / 'reference-pins.json') == expected
for n, pinned in expected.items():
    assert pin(root / 'reference' / n) == pinned
order = [('control', 'control-1'), ('candidate', 'candidate-1'), ('candidate', 'candidate-2'), ('control', 'control-2'), ('candidate', 'candidate-3'), ('control', 'control-3'), ('control', 'control-4'), ('candidate', 'candidate-4')]
cohort = []
screens = []
for variant, name in [('control', 'control-screen'), ('candidate', 'candidate-screen')] + order:
    d = root / name
    command = read(root / (name + '-command.json'))
    assert command['flags'] == flags and command['binary_sha256'] == excluded[variant]['sha256']
    assert not command['profiling_excluded_from_primary']
    process = read(d / 'process.json')
    assert process['exit_code'] == 0 and process['elapsed_boundary'] == 'driver_start_to_process_wait_completion'
    assert process['samples'] == 0 and process['sampling_error'] is None
    checks = read(d / 'output-check.json')
    for n, pinned in expected.items():
        assert pin(d / n) == pinned and checks[n] == dict(pinned, matches_current_control_output=True)
    row = dict(name=name, variant=variant, compile=read(d / 'compile.json'), process=process, files=checks)
    assert row['compile']['total_seconds'] < process['elapsed_seconds']
    if name.endswith('-screen'):
        screens.append(row)
        continue
    stamps = [json.loads(line) for line in (d / 'stages.jsonl').read_text().splitlines()]
    elapsed = lambda prefix: next(s['elapsed'] for s in stamps if s['line'].startswith(prefix))
    for key, begin, end in [('canonical_lowering_seconds', 'compact-stage: canonical lowering', 'compact-stage: preparation blocks='), ('preparation_seconds', 'compact-stage: preparation blocks=', 'compact-stage: native module'), ('numeric_generation_seconds', 'compact-stage: native module', 'compact-stage: typed layout'), ('source_cfg_seconds', 'compact-stage: source CFG', 'compact-stage: finalize SSA'), ('cleanup_seconds', 'compact-stage: CFG cleanup', 'compact-stage: machine code')]:
        row[key] = elapsed(end) - elapsed(begin)
    log = (d / 'stderr.log').read_text()
    for key, pattern in [('max_rss_bytes', r'(\d+)  maximum resident set size'), ('instructions', r'(\d+)  instructions retired'), ('peak_footprint_bytes', r'(\d+)  peak memory footprint')]:
        row[key] = int(re.search(pattern, log).group(1))
    row['compaction_seconds'] = elapsed('compact-stage: CFG cleanup') - elapsed('compact-stage: compact values before=')
    for key, prefix in [('value_ids_before', 'compact-stage: compact values before='), ('value_ids_after', 'compact-values: retained=')]:
        row[key] = int(next(s['line'] for s in stamps if s['line'].startswith(prefix)).split('=')[-1])
    assert (row['value_ids_before'], row['value_ids_after']) == (20798230, 1242559)
    row['cleanup_including_compaction_seconds'] = row['cleanup_seconds'] + row['compaction_seconds']
    cohort.append(row)
assert cohort == read(root / 'cohort.json')
fields = {'compiler_seconds': lambda r: r['compile']['total_seconds'], 'whole_process_seconds': lambda r: r['process']['elapsed_seconds']}
for phase in ['parse', 'catalog', 'frontend', 'artifact', 'encode', 'native']:
    fields[phase + '_seconds'] = lambda r, p=phase: next(v['seconds'] for v in r['compile']['phases'] if v['phase'] == p)
for key in ['canonical_lowering_seconds', 'preparation_seconds', 'numeric_generation_seconds', 'source_cfg_seconds', 'cleanup_including_compaction_seconds', 'cleanup_seconds', 'compaction_seconds', 'instructions', 'max_rss_bytes', 'peak_footprint_bytes']:
    fields[key] = lambda r, k=key: r[k]
numerical = {}
for key, fn in fields.items():
    values = {v: [fn(r) for r in cohort if r['variant'] == v] for v in ['control', 'candidate']}
    control = statistics.mean(values['control'])
    values['mean_reduction_fraction'] = 1 - statistics.mean(values['candidate']) / control if control else None
    numerical[key] = values
assert numerical == read(root / 'numerical-summary.json')
blocks = []
for rows in [cohort[:4], cohort[4:]]:
    block = {}
    for key in ['compiler_seconds', 'whole_process_seconds', 'frontend_seconds', 'instructions']:
        means = {v: statistics.mean(fields[key](r) for r in rows if r['variant'] == v) for v in ['control', 'candidate']}
        block[key] = dict(means, mean_reduction_fraction=1-means['candidate']/means['control'])
        if key in ['frontend_seconds', 'instructions']: assert block[key]['mean_reduction_fraction'] > 0
    blocks.append(block)
fixtures = read(root / 'fixture-results.json')
assert len(fixtures) == 14
for row in fixtures:
    name = row['fixture'].split(':')[-1] if ':' in row['fixture'] else Path(row['fixture']).stem
    assert pin(root / 'fixture-inputs' / (name + '.mec'))['sha256'] == row['source_sha256']
    assert row['all_outputs_match'] and row['variants']['control'] == row['variants']['candidate']
    for variant in ['control', 'candidate']:
        d = root / 'fixtures' / name / variant
        command = read(d / 'command.json')
        assert command['flags'] == flags and command['binary_sha256'] == excluded[variant]['sha256']
        assert row['variants'][variant]['exit_code'] == 0 and len(row['variants'][variant]['files']) == 4
        for n, pinned in row['variants'][variant]['files'].items():
            assert pin(d / n) == pinned
inputs = read(root / 'native-link-inputs.json')
for row in inputs:
    assert pin(root / row['path']) == dict(bytes=row['bytes'], sha256=row['sha256'])
links = read(root / 'final-executable-results.json')
assert len(links) == 2
for variant, row in zip(['control', 'candidate'], links):
    assert row['variant'] == variant and row['exit_code'] == 0 and row['matches_complete_baseline_executable'] and not row['fresh_runtime_campaign']
    assert row['executable_sha256'] == '557d0f5ef2b979e01851ae23b5b3944453a0bd9e772d68161be198916ca06c2c'
    assert pin(root / ('link-' + variant) / 'worker') == dict(bytes=row['executable_bytes'], sha256=row['executable_sha256'])
    assert read(root / ('link-' + variant) / 'result.json') == row
    command = read(root / ('link-' + variant) / 'command.json')
    assert command['environment'] == {'ZERO_AR_DATE': '1'}
    assert [(r['source'], r['bytes'], r['sha256']) for r in command['input_pins']] == [(r['source'], r['bytes'], r['sha256']) for r in inputs]
assert (root / 'link-control/worker').read_bytes() == (root / 'link-candidate/worker').read_bytes()
tests = read(root/'pending-schema-tests.json')
assert tests['exit_code'] == 0 and tests['production_module_sha256'] == pin(root/'source/candidate'/tests['production_module'])['sha256']
assert 'test result: ok. 5 passed; 0 failed' in (root/'pending-schema-tests.stdout.log').read_text()
test_build = read(root/'pending-schema-tests-build.json')
assert test_build['exit_code'] == 0 and test_build['test_binary_sha256'] == excluded['pending-schema-tests']['sha256']
native_builds = read(root/'native-build-observations.json')
assert len(native_builds) == 2
for row in native_builds:
    d = root/('native-build-'+row['variant'])
    assert row == read(d/'result.json') and row['cached_adapter_objects'] and not row['primary_cohort']
    assert row['compiler_exit_code'] == row['link_exit_code'] == 0 and row['matches_complete_baseline_executable']
    assert row['measurement_boundary'] == 'compiler_spawn_through_native_link_process_wait_completion'
    assert abs(row['source_to_executable_seconds']-sum(row[k] for k in ['source_to_object_process_seconds','object_handoff_seconds','native_link_seconds'])) < 1e-8
    command = read(d/'command.json'); assert command['flags'] == flags and command['ZERO_AR_DATE'] == '1' and command['compiler_sha256'] == excluded[row['variant']]['sha256']
    for n, pinned in expected.items(): assert pin(d/n) == pinned and row['files'][n] == dict(pinned, matches_frozen_reference=True)
    assert pin(d/'worker') == dict(bytes=row['executable_bytes'], sha256=row['executable_sha256']) and pin(d/'worker') == pin(root/'link-control/worker')
probe = root/'parallel-boundary-probe'
probe_build = read(probe/'build.json'); probe_run = read(probe/'run.json')
assert probe_build['exit_code'] == probe_run['exit_code'] == 0
assert probe_build['binary_sha256'] == excluded['parallel-boundary-probe/probe']['sha256']
assert pin(probe/'probe.rs')['sha256'] == probe_build['source_sha256'] == probe_run['source_sha256']
assert probe_run['worker_counts'] == [1,2,4] and probe_run['repeats_each'] == 8
assert len(probe_run['objects']) == 25 and len({r['sha256'] for r in probe_run['objects']}) == 1
for row in probe_run['objects']: assert pin(probe/'output'/row['name']) == dict(bytes=row['bytes'], sha256=row['sha256'])
assert '24 exact Object, optimized-IR and compiled-metric comparisons passed' in (probe/'run.stdout.log').read_text()
assert read(probe/'failed-system-lto-build.json')['exit_code'] == 1 and 'could not parse bitcode object file' in (probe/'failed-system-lto-build.stderr.log').read_text()
assert '-C' in read(probe/'build-command.json') and 'lto=thin' in read(probe/'build-command.json')
summary = dict(source_commit=state['source_commit'], base_commit=state['base_commit'], flags_count=61, compiler_binary_sha256={v: excluded[v]['sha256'] for v in ['control','candidate']}, output_hashes=expected, decision='Retained targeted work reduction: preserve existing PendingSchema cache owners through assembly and nested visitors. Whole-compiler time effectively flat, with mixed blocks; complete program and executable bytes identical.', numerical_summary=numerical, balanced_blocks=blocks, fixture_pairs=len(fixtures), focused_cache_tests=5, preliminary_screens=screens, build=build, final_links=links, full_native_build_observations=native_builds, parallel_boundary_probe=dict(build=probe_build, run=probe_run, failed_link=read(probe/'failed-system-lto-build.json')), scope=[
    'Eight serial primary compiles use ABBA/BAAB ordering and precise process completion. Screens, fixtures, tests, linking, builds and standalone probe work are excluded. Historical polling cohorts remain separate.',
    'Only private borrowed schema views and their callers change, preserving visitation/insertion order and existing pure canonicalization, errors and mutation invalidation. Owner-backed requests use PendingSchema; raw drafts retain their original finalization. Fresh source, shape, factory, ownership and visit proofs remain.',
    'Frontend and instruction means improve in both balanced blocks. Whole-compiler and process means are effectively flat and their block directions are mixed; no reliable overall compiler saving is established. Native/source-CFG, parsing, catalog and RSS adverse observations remain in full.',
    'Five focused production cache tests include uniquely-owned cached-success mutation, shared ownership/error repair and concurrent readers. Fourteen paired fixtures and every full source/bytecode/Object/metadata/final executable byte match. No scalar retirement or fresh runtime campaign is claimed.',
    'Two separate source-to-executable observations include fresh source analysis, program Object output, object handoff and final native linking. They reuse frozen adapter objects, exclude first-use adapter construction and are not a balanced improvement cohort.',
    'The standalone Cranelift boundary probe uses two synthetic native functions, local/imported calls, data references and a data relocation. It compares complete Object bytes, optimized IR and compiled metrics against serial publication for 1/2/4 workers, eight repeats each. All 24 pass. It is not a production Mech scheduler, deterministic competing-error proof or a Deflate parallel speedup measurement.',
    'The probe first fails direct linking because LLVM22 bitcode meets system LLVM15 LTO. Rebuilding the same probe with Rust ThinLTO succeeds; both setup observations remain. Compiler/probe/test executables are excluded and hash-pinned, all generated program/native-input bytes remain. Pure replay validates saved data without running compilers or timings.',
    'Parallel Mech compilation and sub-ten-second compilation remain unachieved. The architectural design still requires a one-worker production split and explicit phase-variant dependencies before scheduling.'
])
encoded = json.dumps(summary, indent=2, sort_keys=True) + '\n'
p = root / 'summary.json'
if p.exists():
    assert p.read_text() == encoded
else:
    p.write_text(encoded)
print(encoded, end='')
