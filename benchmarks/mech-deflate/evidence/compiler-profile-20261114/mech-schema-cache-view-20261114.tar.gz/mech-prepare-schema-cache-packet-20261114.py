from pathlib import Path

old = Path('/private/tmp/mech-curate-call-schema-borrow-20261114.py').read_text()
curate = old.replace('call-schema-borrow', 'schema-cache-view')
curate = curate.replace("['control', 'candidate']:", "['control', 'candidate', 'pending-schema-tests']:")
curate = curate.replace("bb9c4b35919174c6d5daf28542609ff4f7682bc8", "4057eb4364d496c66bad911394249007b1426590")
start = curate.index("source = 'src/engine/")
end = curate.index("for name in ['Cargo.toml'", start)
curate = curate[:start] + '''sources = ['src/engine/src/source_semantics/' + n for n in ['frontend.rs', 'pending_schema.rs', 'application.rs', 'comprehension.rs']]
for source in sources:
    for variant, revision in [('control', base), ('candidate', head)]:
        dest = packet / 'source' / variant / source
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(subprocess.check_output(['git', 'show', revision + ':' + source]))
''' + curate[end:]
curate = curate.replace("'profile_compile.py']:", "'profile_compile.py', 'pending_schema_tests.rs']:")
curate = curate.replace('point-liveness-compile-apple-m3-20261114', 'call-schema-borrow-compile-apple-m3-20261114')
curate = curate.replace("for p in Path('/private/tmp').glob('*schema-cache-view*20261114.py'):", "for p in Path('/private/tmp').glob('*schema-cache*20261114.py'):")
at = curate.index("(packet / 'excluded-compiler-products.json')")
probe = '''probe = Path('/private/tmp/mech-parallel-object-boundary-20261114')
assert json.loads((probe / 'run.json').read_text())['exit_code'] == 0
for p in sorted(probe.rglob('*')):
    if not p.is_file(): continue
    dest = Path('parallel-boundary-probe') / p.relative_to(probe)
    if p.name == 'probe':
        excluded.append(dict(path=dest.as_posix(), **pin(p))); continue
    d = packet / dest; d.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(p, d)
shutil.copy2('/private/tmp/mech-parallel-object-boundary-20261114.rs', packet/'parallel-boundary-probe/probe.rs')
shutil.copy2('/private/tmp/mech-build-parallel-object-boundary-20261114.py', packet/'parallel-boundary-probe/build-and-run.py')
'''
curate = curate[:at] + probe + curate[at:]
curate = curate.replace("production_change='Borrow call-argument schemas while retaining the exact ResolvedType constructor, overload resolution, and error anchoring.'", "production_change='Preserve PendingSchema canonicalization cache owners through assembly and nested control visitors; raw drafts retain uncached finalization.'")
start = curate.index("(packet / 'README.txt').write_text(")
curate = curate[:start] + '''(packet / 'README.txt').write_text("""Schema cache owner reuse and parallel backend boundary evidence, 2026-11-14.
The private borrowed schema view retains existing PendingSchema cache ownership
through schema-table assembly and nested control visitors. Raw drafts retain
their original path. Pure canonicalization and mutation invalidation are unchanged;
fresh shape, factory, ownership and visit proofs are not cached or skipped.
Five focused production cache tests, fourteen paired fixtures, both screens,
eight serial primary compiles and full executable byte gates pass.
Frontend and retired-instruction reductions repeat in both balanced blocks;
whole-compiler time is effectively flat with mixed blocks. All adverse native,
source-CFG, parser, catalog and memory observations remain. Two separate complete
source-to-executable observations reuse the fixed adapter and are outside the
primary source-to-Object cohort. First-use adapter construction is excluded.
The standalone worker probe compares serial publication against one, two and
four workers over two synthetic native functions with local/imported calls and
data relocations. All 24 Object/optimized-IR/metric comparisons pass. It is not
a production Mech scheduler or a measured Deflate parallel speedup. Its first
direct-link failure (LLVM bitcode/system LTO mismatch) and ThinLTO repair remain.
Every generated program file, executable and native link input is included.
Compiler/probe/test executables are excluded and SHA-pinned. Pure replay checks
saved observations and bytes without rerunning compilers or timings. The
sub-ten-second compilation goal remains open.
""")
print(packet)
'''
Path('/private/tmp/mech-curate-schema-cache-view-20261114.py').write_text(curate)

replay = Path('/private/tmp/mech-replay-call-schema-borrow-20261114.py').read_text()
start = replay.index('base_source = ')
end = replay.index('expected = prior', start)
helper = Path('/private/tmp/mech-ssa-span-trials-packet-20261114/replay.py').read_text()
helper = helper[helper.index('def apply_source_patch('):helper.index('base_source=')]
apply = '''patch = (root/'candidate.patch').read_text()
names = []
for block in patch.split('diff --git ')[1:]:
    block = 'diff --git ' + block
    match = re.match(r'diff --git a/(.+) b/\\1\\n', block)
    assert match
    name = match[1]; names.append(name)
    assert apply_source_patch((root/'source/control'/name).read_text(), block) == (root/'source/candidate'/name).read_text()
assert set(names) == {'src/engine/src/source_semantics/'+n for n in ['frontend.rs','pending_schema.rs','application.rs','comprehension.rs']}
'''
replay = replay[:start] + helper + apply + replay[end:]
replay = replay.replace("        assert block[key]['mean_reduction_fraction'] > 0", "        if key in ['frontend_seconds', 'instructions']: assert block[key]['mean_reduction_fraction'] > 0")
at = replay.index('summary = dict(')
checks = '''tests = read(root/'pending-schema-tests.json')
assert tests['exit_code'] == 0 and tests['production_module_sha256'] == pin(root/'source/candidate'/tests['production_module'])['sha256']
assert 'test result: ok. 5 passed; 0 failed' in (root/'pending-schema-tests.stdout.log').read_text()
test_build = read(root/'pending-schema-tests-build.json')
assert test_build['exit_code'] == 0 and test_build['test_binary_sha256'] == excluded['pending-schema-tests']['sha256']
native_builds = read(root/'native-build-observations.json')
assert len(native_builds) == 2
for row in native_builds:
    d = root/('native-build-'+row['variant'])
    assert row == read(d/'result.json') and row['cached_adapter_objects'] and not row['primary_cohort']
    assert row['compiler_exit_code'] == row['link_exit_code'] == 0 and row['matches_complete_baseline_executable']
    assert row['measurement_boundary'] == 'compiler_spawn_through_native_link_process_wait_completion'
    assert abs(row['source_to_executable_seconds']-sum(row[k] for k in ['source_to_object_process_seconds','object_handoff_seconds','native_link_seconds'])) < 1e-8
    command = read(d/'command.json'); assert command['flags'] == flags and command['ZERO_AR_DATE'] == '1' and command['compiler_sha256'] == excluded[row['variant']]['sha256']
    for n, pinned in expected.items(): assert pin(d/n) == pinned and row['files'][n] == dict(pinned, matches_frozen_reference=True)
    assert pin(d/'worker') == dict(bytes=row['executable_bytes'], sha256=row['executable_sha256']) and pin(d/'worker') == pin(root/'link-control/worker')
probe = root/'parallel-boundary-probe'
probe_build = read(probe/'build.json'); probe_run = read(probe/'run.json')
assert probe_build['exit_code'] == probe_run['exit_code'] == 0
assert probe_build['binary_sha256'] == excluded['parallel-boundary-probe/probe']['sha256']
assert pin(probe/'probe.rs')['sha256'] == probe_build['source_sha256'] == probe_run['source_sha256']
assert probe_run['worker_counts'] == [1,2,4] and probe_run['repeats_each'] == 8
assert len(probe_run['objects']) == 25 and len({r['sha256'] for r in probe_run['objects']}) == 1
for row in probe_run['objects']: assert pin(probe/'output'/row['name']) == dict(bytes=row['bytes'], sha256=row['sha256'])
assert '24 exact Object, optimized-IR and compiled-metric comparisons passed' in (probe/'run.stdout.log').read_text()
assert read(probe/'failed-system-lto-build.json')['exit_code'] == 1 and 'could not parse bitcode object file' in (probe/'failed-system-lto-build.stderr.log').read_text()
assert '-C' in read(probe/'build-command.json') and 'lto=thin' in read(probe/'build-command.json')
'''
replay = replay[:at] + checks + replay[at:]
start = replay.index('summary = dict(')
end = replay.index('encoded = json.dumps(', start)
replay = replay[:start] + '''summary = dict(source_commit=state['source_commit'], base_commit=state['base_commit'], flags_count=61, compiler_binary_sha256={v: excluded[v]['sha256'] for v in ['control','candidate']}, output_hashes=expected, decision='Retained targeted work reduction: preserve existing PendingSchema cache owners through assembly and nested visitors. Whole-compiler time effectively flat, with mixed blocks; complete program and executable bytes identical.', numerical_summary=numerical, balanced_blocks=blocks, fixture_pairs=len(fixtures), focused_cache_tests=5, preliminary_screens=screens, build=build, final_links=links, full_native_build_observations=native_builds, parallel_boundary_probe=dict(build=probe_build, run=probe_run, failed_link=read(probe/'failed-system-lto-build.json')), scope=[
    'Eight serial primary compiles use ABBA/BAAB ordering and precise process completion. Screens, fixtures, tests, linking, builds and standalone probe work are excluded. Historical polling cohorts remain separate.',
    'Only private borrowed schema views and their callers change, preserving visitation/insertion order and existing pure canonicalization, errors and mutation invalidation. Owner-backed requests use PendingSchema; raw drafts retain their original finalization. Fresh source, shape, factory, ownership and visit proofs remain.',
    'Frontend and instruction means improve in both balanced blocks. Whole-compiler and process means are effectively flat and their block directions are mixed; no reliable overall compiler saving is established. Native/source-CFG, parsing, catalog and RSS adverse observations remain in full.',
    'Five focused production cache tests include uniquely-owned cached-success mutation, shared ownership/error repair and concurrent readers. Fourteen paired fixtures and every full source/bytecode/Object/metadata/final executable byte match. No scalar retirement or fresh runtime campaign is claimed.',
    'Two separate source-to-executable observations include fresh source analysis, program Object output, object handoff and final native linking. They reuse frozen adapter objects, exclude first-use adapter construction and are not a balanced improvement cohort.',
    'The standalone Cranelift boundary probe uses two synthetic native functions, local/imported calls, data references and a data relocation. It compares complete Object bytes, optimized IR and compiled metrics against serial publication for 1/2/4 workers, eight repeats each. All 24 pass. It is not a production Mech scheduler, deterministic competing-error proof or a Deflate parallel speedup measurement.',
    'The probe first fails direct linking because LLVM22 bitcode meets system LLVM15 LTO. Rebuilding the same probe with Rust ThinLTO succeeds; both setup observations remain. Compiler/probe/test executables are excluded and hash-pinned, all generated program/native-input bytes remain. Pure replay validates saved data without running compilers or timings.',
    'Parallel Mech compilation and sub-ten-second compilation remain unachieved. The architectural design still requires a one-worker production split and explicit phase-variant dependencies before scheduling.'
])
''' + replay[end:]
Path('/private/tmp/mech-replay-schema-cache-view-20261114.py').write_text(replay)
print('prepared schema cache packet recipes')
