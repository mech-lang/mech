from pathlib import Path
import json, subprocess, hashlib, shutil, time

root = Path('/private/tmp/mech-parallel-object-boundary-20261114')
for name in ['build-command.json', 'build.json', 'build.stdout.log', 'build.stderr.log']:
    dest = root / ('failed-system-lto-' + name)
    assert not dest.exists()
    shutil.copy2(root / name, dest)
command = json.loads((root / 'build-command.json').read_text())
command += ['-C', 'lto=thin', '-C', 'codegen-units=1']
(root / 'build-command.json').write_text(json.dumps(command, indent=2) + '\n')
started = time.monotonic()
with (root / 'build.stdout.log').open('w') as stdout, (root / 'build.stderr.log').open('w') as stderr:
    completed = subprocess.run(command, stdout=stdout, stderr=stderr)
record = {'exit_code': completed.returncode, 'seconds': time.monotonic()-started, 'source_sha256': hashlib.sha256(Path('/private/tmp/mech-parallel-object-boundary-20261114.rs').read_bytes()).hexdigest(), 'scope': 'Standalone API-boundary probe; excluded from Deflate performance timings.'}
if completed.returncode == 0:
    record['binary_sha256'] = hashlib.sha256((root / 'probe').read_bytes()).hexdigest()
(root / 'build.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
assert completed.returncode == 0
command = [str(root / 'probe'), str(root / 'output')]
with (root / 'run.stdout.log').open('w') as stdout, (root / 'run.stderr.log').open('w') as stderr:
    completed = subprocess.run(command, stdout=stdout, stderr=stderr)
result = {'command': command, 'exit_code': completed.returncode, 'scope': 'Two synthetic native functions with data and function relocations; exact Object, optimized IR and compiled metrics against serial publication. No production scheduler or timing speedup.', 'source_sha256': record['source_sha256']}
if completed.returncode == 0:
    files = sorted((root / 'output').glob('*.o'))
    result['objects'] = [{'name': p.name, 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
    assert len(files) == 25 and len({r['sha256'] for r in result['objects']}) == 1
    result['worker_counts'] = [1, 2, 4]
    result['repeats_each'] = 8
(root / 'run.json').write_text(json.dumps(result, indent=2) + '\n')
print((root / 'run.stdout.log').read_text(), flush=True)
assert completed.returncode == 0
