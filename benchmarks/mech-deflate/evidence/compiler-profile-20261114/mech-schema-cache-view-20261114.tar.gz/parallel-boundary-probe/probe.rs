//! Standalone API-boundary experiment, not the production Mech scheduler.
use cranelift_codegen::{Context, ir::{AbiParam, InstBuilder, MemFlags, types}, isa::OwnedTargetIsa, settings::{self, Configurable}};
use cranelift_control::ControlPlane;
use cranelift_frontend::{FunctionBuilder, FunctionBuilderContext};
use cranelift_module::{DataDescription, FuncId, Linkage, Module, ModuleReloc, default_libcall_names};
use cranelift_object::{ObjectBuilder, ObjectModule};
use std::{sync::{Arc, Mutex, mpsc}, thread};

struct Job { ordinal: usize, id: FuncId, context: Context }

fn compile(mut job: Job, isa: &OwnedTargetIsa) -> Job {
    job.context.compile(isa.as_ref(), &mut ControlPlane::default()).unwrap();
    job
}

fn run(workers: usize, output: &std::path::Path) -> (Vec<u8>, Vec<String>, Vec<(u32, u64, usize)>) {
    let mut flags = settings::builder();
    for (key, value) in [("opt_level", "none"), ("is_pic", "true"), ("preserve_frame_pointers", "true"), ("unwind_info", "true")] {
        flags.set(key, value).unwrap();
    }
    let isa = cranelift_native::builder().unwrap().finish(settings::Flags::new(flags)).unwrap();
    let mut module = ObjectModule::new(ObjectBuilder::new(isa.clone(), "parallel_boundary_probe", default_libcall_names()).unwrap());
    let mut signature = module.make_signature();
    signature.params.push(AbiParam::new(types::I64));
    signature.returns.push(AbiParam::new(types::I64));
    let first = module.declare_function("first", Linkage::Export, &signature).unwrap();
    let data = module.declare_data("constant", Linkage::Local, false, false).unwrap();
    let external = module.declare_function("external", Linkage::Import, &signature).unwrap();
    let second = module.declare_function("second", Linkage::Local, &signature).unwrap();
    let mut jobs = Vec::new();
    for (ordinal, id) in [first, second].into_iter().enumerate() {
        let mut context = module.make_context();
        context.func.signature = signature.clone();
        let mut scratch = FunctionBuilderContext::new();
        {
            let mut builder = FunctionBuilder::new(&mut context.func, &mut scratch);
            let entry = builder.create_block();
            builder.append_block_params_for_function_params(entry);
            builder.switch_to_block(entry);
            let input = builder.block_params(entry)[0];
            let result = if ordinal == 0 {
                let callee = module.declare_func_in_func(second, builder.func);
                let call = builder.ins().call(callee, &[input]);
                let result = builder.inst_results(call)[0];
                let global = module.declare_data_in_func(data, builder.func);
                let address = builder.ins().global_value(module.target_config().pointer_type(), global);
                let constant = builder.ins().load(types::I64, MemFlags::new(), address, 0);
                let sum = builder.ins().iadd(result, constant);
                let callee = module.declare_func_in_func(external, builder.func);
                let call = builder.ins().call(callee, &[sum]);
                builder.inst_results(call)[0]
            } else {
                builder.ins().imul_imm(input, 2)
            };
            builder.ins().return_(&[result]);
            builder.seal_all_blocks();
            builder.finalize();
        }
        context.verify(module.isa()).unwrap();
        jobs.push(Job { ordinal, id, context });
    }
    let mut description = DataDescription::new();
    description.define(vec![0; 16].into_boxed_slice());
    let reference = module.declare_func_in_data(first, &mut description);
    description.write_function_addr(8, reference);
    let mut ir = Vec::new();
    let mut metrics = Vec::new();
    if workers == 0 {
        for mut job in jobs {
            module.define_function(job.id, &mut job.context).unwrap();
            let code = job.context.compiled_code().unwrap();
            metrics.push((code.code_info().total_size, code.buffer.alignment as u64, code.buffer.relocs().len()));
            ir.push(job.context.func.display().to_string());
            if job.ordinal == 0 { module.define_data(data, &description).unwrap(); }
        }
    } else {
        let (send, receive) = mpsc::sync_channel::<Job>(2);
        let receive = Arc::new(Mutex::new(receive));
        let (done, results) = mpsc::channel();
        thread::scope(|scope| {
            for _ in 0..workers {
                let receive = receive.clone();
                let done = done.clone();
                let isa = isa.clone();
                scope.spawn(move || loop {
                    let job = { receive.lock().unwrap().recv() };
                    let Ok(job) = job else { break };
                    done.send(compile(job, &isa)).unwrap();
                });
            }
            drop(done);
            for job in jobs { send.send(job).unwrap(); }
            drop(send);
            let mut compiled: Vec<_> = results.into_iter().collect();
            compiled.sort_by_key(|job| job.ordinal);
            for job in compiled {
                let code = job.context.compiled_code().unwrap();
                let alignment = code.buffer.alignment as u64;
                let relocs = code.buffer.relocs().iter().map(|reloc| ModuleReloc::from_mach_reloc(reloc, &job.context.func, job.id)).collect::<Vec<_>>();
                module.define_function_bytes(job.id, alignment, code.buffer.data(), &relocs).unwrap();
                metrics.push((code.code_info().total_size, alignment, relocs.len()));
                ir.push(job.context.func.display().to_string());
                if job.ordinal == 0 { module.define_data(data, &description).unwrap(); }
            }
        });
    }
    let bytes = module.finish().emit().unwrap();
    std::fs::write(output, &bytes).unwrap();
    (bytes, ir, metrics)
}

fn main() {
    let root = std::path::PathBuf::from(std::env::args_os().nth(1).unwrap());
    std::fs::create_dir_all(&root).unwrap();
    let baseline = run(0, &root.join("serial.o"));
    for workers in [1, 2, 4] {
        for repeat in 0..8 {
            let actual = run(workers, &root.join(format!("workers-{workers}-{repeat}.o")));
            assert_eq!(actual, baseline);
        }
    }
    std::fs::write(root.join("optimized-ir.txt"), baseline.1.join("\n")).unwrap();
    println!("serial vs 1/2/4 workers: 24 exact Object, optimized-IR and compiled-metric comparisons passed; functions={} relocations={}", baseline.1.len(), baseline.2.iter().map(|r|r.2).sum::<usize>());
}
