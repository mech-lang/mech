Schema cache owner reuse and parallel backend boundary evidence, 2026-11-14.
The private borrowed schema view retains existing PendingSchema cache ownership
through schema-table assembly and nested control visitors. Raw drafts retain
their original path. Pure canonicalization and mutation invalidation are unchanged;
fresh shape, factory, ownership and visit proofs are not cached or skipped.
Five focused production cache tests, fourteen paired fixtures, both screens,
eight serial primary compiles and full executable byte gates pass.
Frontend and retired-instruction reductions repeat in both balanced blocks;
whole-compiler time is effectively flat with mixed blocks. All adverse native,
source-CFG, parser, catalog and memory observations remain. Two separate complete
source-to-executable observations reuse the fixed adapter and are outside the
primary source-to-Object cohort. First-use adapter construction is excluded.
The standalone worker probe compares serial publication against one, two and
four workers over two synthetic native functions with local/imported calls and
data relocations. All 24 Object/optimized-IR/metric comparisons pass. It is not
a production Mech scheduler or a measured Deflate parallel speedup. Its first
direct-link failure (LLVM bitcode/system LTO mismatch) and ThinLTO repair remain.
Every generated program file, executable and native link input is included.
Compiler/probe/test executables are excluded and SHA-pinned. Pure replay checks
saved observations and bytes without rerunning compilers or timings. The
sub-ten-second compilation goal remains open.
