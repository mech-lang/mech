from pathlib import Path
import hashlib, json, subprocess, time

repo = Path.cwd()
root = Path('/private/tmp/mech-schema-cache-view-20261114')
rows = [json.loads(line) for line in (root / 'candidate-build.jsonl').read_text().splitlines()]
core = next(path for row in rows if row.get('reason') == 'compiler-artifact' and row.get('target', {}).get('name') == 'mech_core' for path in row['filenames'] if path.endswith('.rlib'))
out = root / 'pending-schema-tests'
source = 'benchmarks/mech-deflate/native-profile/pending_schema_tests.rs'
command = ['rustc', '+nightly-2026-03-03', '--edition=2024', '--test', source, '-C', 'opt-level=3', '-D', 'warnings', '--extern', 'mech_core=' + core, '-L', 'dependency=' + str(Path(core).parent), '-o', str(out)]
started = time.monotonic()
with (root / 'pending-schema-tests-build.stdout.log').open('w') as stdout, (root / 'pending-schema-tests-build.stderr.log').open('w') as stderr:
    completed = subprocess.run(command, cwd=repo, stdout=stdout, stderr=stderr)
record = {'command': command, 'seconds': time.monotonic()-started, 'exit_code': completed.returncode, 'core_sha256': hashlib.sha256(Path(core).read_bytes()).hexdigest()}
if completed.returncode == 0:
    record['test_binary_sha256'] = hashlib.sha256(out.read_bytes()).hexdigest()
(root / 'pending-schema-tests-build.json').write_text(json.dumps(record, indent=2) + '\n')
assert completed.returncode == 0
command = [str(out), '--nocapture']
with (root / 'pending-schema-tests.stdout.log').open('w') as stdout, (root / 'pending-schema-tests.stderr.log').open('w') as stderr:
    completed = subprocess.run(command, stdout=stdout, stderr=stderr)
(root / 'pending-schema-tests.json').write_text(json.dumps({'command': command, 'exit_code': completed.returncode, 'source': source, 'production_module': 'src/engine/src/source_semantics/pending_schema.rs', 'production_module_sha256': hashlib.sha256((repo/'src/engine/src/source_semantics/pending_schema.rs').read_bytes()).hexdigest()}, indent=2) + '\n')
print(record, flush=True)
print((root / 'pending-schema-tests.stdout.log').read_text(), flush=True)
assert completed.returncode == 0
