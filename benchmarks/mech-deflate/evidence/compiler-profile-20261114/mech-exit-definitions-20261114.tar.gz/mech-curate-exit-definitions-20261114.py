from pathlib import Path
import subprocess,json,hashlib,shutil
repo=Path.cwd();raw=Path('/private/tmp/mech-exit-definitions-20261114');packet=Path('/private/tmp/mech-exit-definitions-packet-20261114');assert not packet.exists()
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();build=json.loads((raw/'candidate-build.json').read_text());base=build['head'];control=json.loads((raw/'control-origin.json').read_text());control_source=control['source_commit']
summary_path=repo/'benchmarks/mech-deflate/native-profile/index-facts-compile-apple-m3-20261114.json';receipt_path=summary_path.with_name(summary_path.stem+'.archive.json');prior=json.loads(summary_path.read_text());receipt=json.loads(receipt_path.read_text());assert hashlib.sha256(summary_path.read_bytes()).hexdigest()==receipt['replay_sha256'];assert control_source==prior['source_commit'] and control['sha256']==prior['compiler_binary_sha256']['candidate']
patch=subprocess.check_output(['git','diff','--binary',base,source]);assert patch==(raw/'candidate.patch').read_bytes();assert hashlib.sha256(patch).hexdigest()==build['patch_sha256']
assert subprocess.check_output(['git','diff',control_source,base,'--','src','hosts','vendor','machines','Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.toml'])==b''
excluded=[]
for p in sorted(raw.rglob('*')):
 if not p.is_file():continue
 rel=Path('compiler')/p.relative_to(raw)
 if p.name in ['control','candidate','topology-tests']:
  excluded.append(dict(path=rel.as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()));continue
 d=packet/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
(packet/'excluded-executables.json').write_text(json.dumps(excluded,indent=2)+'\n');(packet/'source-change.patch').write_bytes(patch)
state=dict(source_commit=source,base_commit=base,control_source_commit=control_source,control_production_source_identical_to_base=True,patch_sha256=hashlib.sha256(patch).hexdigest(),hardware='Apple M3 Air, 8 cores (4P+4E), 16 GB, macOS 26.2',rustc=subprocess.check_output(['rustc','-Vv'],text=True),cargo=subprocess.check_output(['cargo','-V'],text=True));(packet/'source-state.json').write_text(json.dumps(state,indent=2,sort_keys=True)+'\n')
changed=subprocess.check_output(['git','diff','--name-only',base,source],text=True).splitlines()
paths=changed+['Cargo.toml','Cargo.lock','.cargo/config.toml','LICENSE','hosts/gpu/src/native_artifact/AGENTS.md','hosts/gpu/src/native_artifact/program/prepare/mod.rs','hosts/gpu/src/native_artifact/program/prepare/readonly_numeric.rs','hosts/gpu/src/native_artifact/program/codegen/numeric_compact.rs','src/engine/src/native_artifact/program_facts.rs','src/engine/src/native_artifact/fusion_semantics.rs','hosts/gpu/tests/fixtures/native/deflate-huffman-LICENSES.md']
paths+=['benchmarks/mech-deflate/native-profile/'+n for n in ['Cargo.toml','Cargo.lock','compile_profile.rs','profile_compile.py','visit_predecessors_tests.rs']]
paths+=['hosts/gpu/tests/fixtures/native/'+n+'.mec' for n in ['numeric-nested-phase','numeric-nested-phase-states','numeric-private-fixed-nested','numeric-changing-capture-tree','numeric-array-windows','numeric-multiple-children']]
for name in dict.fromkeys(paths):
 data=subprocess.check_output(['git','show',source+':'+name]);d=packet/'source'/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(data)
for name in [*changed,'Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.toml']:
 obj=subprocess.run(['git','show',base+':'+name],capture_output=True)
 if obj.returncode:continue
 d=packet/'source-base'/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(obj.stdout)
validation=packet/'validation';validation.mkdir();shutil.copy2(summary_path,validation/'qualified-index-facts.json');shutil.copy2(receipt_path,validation/'qualified-index-facts.archive.json')
shutil.copytree(Path('/private/tmp/mech-borrowed-schema-packet-20261114/licenses'),packet/'licenses')
for pattern in ['mech-*exit-definitions*20261114.py','mech-*exit-definitions*20261114.log']:
 for p in Path('/private/tmp').glob(pattern):
  if p.is_file():shutil.copy2(p,packet/p.name)
(packet/'README.txt').write_text("""Selected exit-query definitions, Apple M3, 2026-11-14.
Each current exit query still visits and validates its exact selected graph in
its original order. The first former definition demand remains even for empty
read sets, validating the whole immutable same-plan inventory including unused
producers. After that demand only values read in the graph are visited. Empty
or wholly out-of-range wanted sets and zero-value plans retain no-demand
behavior. Definition/graph/current-visit policies and liveness are unchanged.
No engine API, language, serialized format or persistent/current proof cache is
added. Original/decoded graph subsets and malformed/empty/duplicate cases compare
the exact production selection with the former value loop in focused Rust tests.
Sixteen primary observations use ABBA/BAAB twice; all runs and the reason for
additional observations are retained. Overall compiler time is effectively flat
with mixed block directions; only small preparation/instruction work reduction
is credited. All commands, outputs and failed attempts are retained.
Compiler executables are excluded and pinned. Builds, screens, fixtures, tests,
sampling, copying, hashing and archive work do not overlap primary timing.
Both subjects use the same compiler profile, 60 flags and complete fresh source
pipeline including SSA compaction. No execution machinery is retired. Python
3.11+ replay is pure offline validation/reconstruction without compilers,
benchmarks, original scratch paths or external services.
""");print(packet,flush=True)
