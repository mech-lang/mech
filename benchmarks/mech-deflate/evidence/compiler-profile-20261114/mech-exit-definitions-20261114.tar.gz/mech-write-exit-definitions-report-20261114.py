from pathlib import Path
import json,statistics,subprocess
repo=Path.cwd();base=lambda p:subprocess.check_output(['git','show','HEAD:'+p.relative_to(repo).as_posix()],text=True);s=json.loads(Path('/private/tmp/mech-exit-definitions-packet-20261114/summary.json').read_text());q=s['qualified']
mean=lambda k,v:statistics.mean(q[k][v])
rng=lambda k,v:f"{min(q[k][v]):.3f}–{max(q[k][v]):.3f}"
change=lambda k:format(100*(mean(k,'candidate')/mean(k,'control')-1), "+.4f" if k in ['max_rss_bytes','peak_footprint_bytes'] else "+.2f")+"%"
rows=[]
for label,k,unit in [('Complete process','whole_process_seconds','s'),('Compiler phases','compiler_seconds','s'),('Parsing','parse_seconds','s'),('Catalog','catalog_seconds','s'),('Artifact','artifact_seconds','s'),('Bytecode encoding','encode_seconds','s'),('Frontend','frontend_seconds','s'),('Native','native_seconds','s'),('Canonical lowering','canonical_lowering_seconds','s'),('Preparation','preparation_seconds','s'),('Numeric helper generation','numeric_generation_seconds','s'),('Source CFG construction','source_cfg_seconds','s'),('Cleanup including compaction','cleanup_including_compaction_seconds','s'),('CFG cleanup','cleanup_seconds','s'),('Value compaction','compaction_seconds','s'),('Retired instructions','instructions','G'),('Maximum RSS','max_rss_bytes','GB'),('Peak footprint','peak_footprint_bytes','GB')]:
 divisor=1e9 if unit in ['G','GB'] else 1
 rows.append(f"| {label} | {mean(k,'control')/divisor:.4f} {unit} | {mean(k,'candidate')/divisor:.4f} {unit} | {change(k)} |")
report=f'''# Selected exit-query definitions

The latest complete fresh level-12 source-to-Object process takes
**{rng('whole_process_seconds','candidate')} seconds** on the Apple M3 Air,
compared with **{rng('whole_process_seconds','control')} seconds** for the matched
control. Total compiler time is essentially flat (**{change('compiler_seconds')}** mean):
two balanced blocks are slower and two faster. An overall compiler-wall
improvement is unestablished. The mean process change is
**{change('whole_process_seconds')}** and
preparation changes **{change('preparation_seconds')}**. The compiler instruction
count changes **{change('instructions')}**. Complete compilation remains above
the ten-second goal.

The former exit liveness query checked its exact graph and read sets, then
scanned every plan value (22,460 for this compressor), looking up definitions
even for values never read by that query. The first lookup already builds and
validates the entire immutable definition inventory. The new selection preserves
that first demand, then visits only sorted distinct valid read IDs. It removes
the full-plan read bitmap and value scan from each query.

The source is `{s['source_commit']}`, measured against production control
`{s['control_source_commit']}`, with build base `{s['base_commit']}`. The exact
source patch and executable hashes are in the compact result and full packet.
There is no new engine API, grammar production, language change, serialized
format, global cache or persistent/current-visit proof.

## Matched full compilation

Sixteen serial observations use ABBA then BAAB order twice, the same 60 runtime flags,
toolchain, optimized `compiler` profile and full source pipeline. Both subjects
include SSA value compaction and its elapsed cost. Each run starts a new process,
parses the full source, constructs the canonical artifact, emits bytecode and
produces native Object and complete metadata. No cached Object or decoded-only
substitute is used. Builds, tests, screens, fixtures, sampling, hashing, copying
and archive work do not overlap the primary observations.

The table contains arithmetic means of all aggregate comparison fields. Phase
and nested-stage intervals overlap and are not additive. All primary observations
and full phase traces remain in the raw packet. Overlapping ranges and sixteen
observations do not establish a population estimate or isolate unrelated phases.

| Measurement | Control mean | Candidate mean | Change |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(rows)+f'''

All four balanced block results and all individual values are retained in
the [compact result](../../benchmarks/mech-deflate/native-profile/exit-definitions-compile-apple-m3-20261114.json).
The first eight observations suggested a small mean improvement, but their
compiler-time block directions disagreed (+0.18% and -0.97%). Eight additional
observations tested that uncertainty without replacing any run. Their block
changes are +0.67% and -0.16%. The initial and repeated cohorts, reason for
repetition, all values and the aggregate are retained. Every candidate retires
fewer instructions than every control, while preparation ranges overlap. The
retained claim is a small work reduction, with total compiler time effectively
flat.

The separate observed compiler-executable rebuild takes **{s['candidate_rebuild_seconds']:.3f}
seconds**, using existing Cargo caches. It is excluded from Mech compilation
timing and is not a matched cold-bootstrap comparison. The test build timings,
including the failed initial setup, are separately recorded in the raw packet.

## Validation and program speed

All source, MBC, Object and complete metadata bytes match the qualified current
program in both screens and every primary observation. Fourteen successful
fixture pairs also reproduce all four files, including numeric phases, nested
and changing captures, array windows, and Bool/U64/I64/F64 scalar controls.
The generated instructions and metadata are identical; no new compressor-runtime
latency campaign is claimed. No scalar execution machinery is retired.

All **{s['focused_rust_tests_passed']} focused Rust tests pass**: four production
selection tests and thirteen existing liveness tests. There are **15,360**
original/decoded random graph/subset comparisons against the previous full-value
loop, plus explicit cases for malformed unused producers, empty read/wanted
sets, invalid read/wanted IDs, zero-value plans, duplicate records, site-less
inputs and unselected/out-of-range definition sites. Independent facts owners
prevent one side from initializing the other's inventory.

The first definition lookup still validates all producers even if the read set
is empty. When the previous loop made no demand (no values, an empty wanted set,
or only wanted IDs outside the value range), the new selection makes none.
Byte comparisons verify that graph traversal/read validation and remaining
exit/liveness logic are unchanged. Current shape/factory/visit/ownership checks,
finite admission, checked errors and runtime accounting retain their existing
execution paths. Earlier bare runtime-only lint failures keep their original
source pins in the helper-liveness packet; they were not rerun or waived here.

Both new Rust files pass `rustfmt --check`. The existing caller file fails the
same check on parent and candidate due to its unchanged long liveness-call line;
the commands and both outputs are recorded. No formatting mutation changes the
measured source.

The initial integration test build failed with E0599 because the harness called
a nonexistent plan-loading method. The corrected test uses the existing confined
image loader with the exact source artifact schema table. The failed command,
source patch and logs remain in the packet. This correction changes test setup.

## Reproduce the results

The [raw packet index](../../benchmarks/mech-deflate/evidence/compiler-profile-20261114/README.md)
and [receipt](../../benchmarks/mech-deflate/native-profile/exit-definitions-compile-apple-m3-20261114.archive.json)
pin the complete repository archive: every observation, command, flag set,
fixture, source snapshot and patch, correction, raw output, hash and license.
Compiler executables are excluded and hash-pinned. The maintained `experiment.py`
verifier checks the published repository copy, its manifest, safe paths and every
file; pure offline `python3 replay.py` reconstructs this result byte-for-byte
without a compiler, benchmark, original scratch path or network.

The next parser candidate is applying existing bounded predictions to nested
base-rule calls while preserving logical work, Unicode, limits, resumptions,
trees and diagnostics. It has no measured saving in this packet.
'''
(repo/'docs/design/native-exit-definitions-compile-profile.md').write_text(report)
p=repo/'docs/design/native-compiler-process-profile.md';text=base(p);text=text.replace('18.691–18.903 seconds per complete',rng('whole_process_seconds','candidate')+' seconds per complete',1).replace('and [index-range definition facts](native-index-facts-compile-profile.md).','[index-range definition facts](native-index-facts-compile-profile.md),\nand [selected exit definitions](native-exit-definitions-compile-profile.md).',1)
text+=f'''\nThe latest [exit-definition qualification](native-exit-definitions-compile-profile.md)
retains the original full-inventory validation demand and visits only values read
by each exact exit query. Sixteen matched 60-flag complete compiles take
{rng('whole_process_seconds','candidate')} seconds: process time changes
{change('whole_process_seconds')}, preparation {change('preparation_seconds')} and
instructions {change('instructions')}. Overall compiler time is effectively flat;
two balanced blocks get slower and two faster. All phases and adverse measurements appear
in the report. All generated bytes match; seventeen focused tests and fourteen
fixture pairs pass. The sixteenth complete packet includes every observation,
source patch, failed test setup and pure offline replay. The ten-second goal
remains open.\n''';p.write_text(text)
p=repo/'benchmarks/mech-deflate/native-profile/README.md';text=base(p)+f'''\nThe [selected exit-definition qualification](../../../docs/design/native-exit-definitions-compile-profile.md)
preserves whole-inventory validation and removes full-value enumeration from
individual exit queries. Sixteen matched complete processes take
{rng('whole_process_seconds','candidate')} seconds ({change('whole_process_seconds')}
mean change); preparation changes {change('preparation_seconds')}. Overall
compiler time is effectively flat with mixed block directions. All generated
bytes match. Seventeen focused Rust tests and fourteen fixture pairs pass.
Every phase, adverse counter and failed setup is retained in the sixteenth
[complete repository packet](../evidence/compiler-profile-20261114/README.md).
''';p.write_text(text)
p=repo/'benchmarks/mech-deflate/EXPERIMENTS.md';text=base(p)+f'''\n## Selected exit definitions, 2026-11-14\n\nThe [qualification report](../../docs/design/native-exit-definitions-compile-profile.md)
records sixteen serial matched complete level-12 compiles:
{rng('whole_process_seconds','candidate')} seconds, process change
{change('whole_process_seconds')}, preparation {change('preparation_seconds')},
instructions {change('instructions')}. Compiler time is effectively flat with
two slower and two faster balanced blocks. All output bytes match; seventeen focused
Rust tests and fourteen fixture pairs pass. The original first definition demand
still validates unused malformed producers. All phase/counter observations and
the failed initial test setup remain in the
[complete repository packet](evidence/compiler-profile-20261114/README.md).
The ten-second goal remains open.\n''';p.write_text(text)
