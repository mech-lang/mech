from pathlib import Path
import subprocess,time,os,json,hashlib
root=Path('/private/tmp/mech-exit-definitions-20261114');cmd=['cargo','test','--locked','--offline','--profile','compiler','-j2','--manifest-path','benchmarks/mech-deflate/native-profile/Cargo.toml','--features','std','--test','exit_definitions','--test','numeric_liveness','--','--nocapture']
assert not (root/'tests.json').exists()
patch=subprocess.check_output(['git','diff','HEAD','--binary']);start=time.perf_counter()
with (root/'tests.stdout').open('wb') as out,(root/'tests.stderr').open('wb') as err:p=subprocess.run(cmd,env=dict(os.environ,CARGO_TARGET_DIR='/private/tmp/mech-level12-compile-target',CARGO_INCREMENTAL='0'),stdout=out,stderr=err)
r={'command':cmd,'seconds':time.perf_counter()-start,'exit_code':p.returncode,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'patch_sha256':hashlib.sha256(patch).hexdigest()};(root/'tests.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
assert subprocess.check_output(['git','diff','HEAD','--binary'])==patch
raise SystemExit(p.returncode)
