from pathlib import Path
import json,hashlib,re,statistics,tomllib
root=Path(__file__).resolve().parent;raw=root/'compiler'
read=lambda p:json.loads(p.read_text())
def pin(p):
 data=p.read_bytes();return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
state=read(root/'source-state.json');build=read(raw/'candidate-build.json');control=read(raw/'control-origin.json');patch=pin(root/'source-change.patch');assert patch==pin(raw/'candidate.patch') and patch['sha256']==state['patch_sha256']==build['patch_sha256']
assert build['exit_code']==0 and build['head']==state['base_commit'] and state['control_production_source_identical_to_base']
prior=read(root/'validation/qualified-index-facts.json');receipt=read(root/'validation/qualified-index-facts.archive.json');assert pin(root/'validation/qualified-index-facts.json')['sha256']==receipt['replay_sha256'];assert control['sha256']==prior['compiler_binary_sha256']['candidate'] and control['source_commit']==state['control_source_commit']==prior['source_commit']
flags=read(raw/'runtime-flags.json');assert len(flags)==60;expected=prior['output_hashes'];assert read(raw/'reference-pins.json')==expected
excluded={r['path']:r for r in read(root/'excluded-executables.json')};assert excluded['compiler/control']['sha256']==control['sha256'] and excluded['compiler/candidate']['sha256']==build['binary_sha256'] 
profile_settings={}
for name in ['Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.toml']:
 before=tomllib.loads((root/'source-base'/name).read_text());after=tomllib.loads((root/'source'/name).read_text());assert after['profile']==before['profile'];profile_settings[name]=after['profile']['compiler']
assert '--profile' in build['command'] and build['command'][build['command'].index('--profile')+1]=='compiler' and '--release' not in build['command']
stage_fields=[('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]
host_fields=[('max_rss_bytes',r'(\d+)  maximum resident set size'),('instructions',r'(\d+)  instructions retired'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]
order=['control-1','candidate-1','candidate-2','control-2','candidate-3','control-3','control-4','candidate-4','control-5','candidate-5','candidate-6','control-6','candidate-7','control-7','control-8','candidate-8']
def validate_cohort(raw,flags,expected,pins,key):
 rows=read(raw/'cohort.json');assert [r['name'] for r in rows]==order
 for name in ['control-screen','candidate-screen',*order]:
  variant=name.split('-')[0];d=raw/name;process=read(d/'process.json');assert process['exit_code']==0 and process['samples']==0 and process['sampling_error'] is None
  command=read(raw/(name+'-command.json'));assert command['flags']==flags and command['binary_sha256']==pins[variant]
  for filename,pinned in expected.items():assert pin(d/filename)==pinned and read(d/'output-check.json')[filename]==dict(pinned,**{key:True})
 for row in rows:
  d=raw/row['name'];assert row['compile']==read(d/'compile.json') and row['process']==read(d/'process.json') and row['files']==read(d/'output-check.json')
  assert row['variant']==row['name'].split('-')[0]
  stamps=[json.loads(line) for line in (d/'stages.jsonl').read_text().splitlines()]
  for field,begin,end in stage_fields:assert row[field]==next(s['elapsed'] for s in stamps if s['line'].startswith(end))-next(s['elapsed'] for s in stamps if s['line'].startswith(begin))
  for field,pattern in host_fields:assert row[field]==int(re.search(pattern,(d/'stderr.log').read_text()).group(1))
  if True:
   begin=next(s for s in stamps if s['line'].startswith('compact-stage: compact values before='));end=next(s for s in stamps if s['line'].startswith('compact-stage: CFG cleanup'));assert row['compaction_seconds']==end['elapsed']-begin['elapsed'];assert row['value_ids_before']==int(begin['line'].split('=')[-1])==20787570;assert row['value_ids_after']==int(next(s['line'] for s in stamps if s['line'].startswith('compact-values: retained=')).split('=')[-1])==1241393
  else:assert row['compaction_seconds']==0
  assert row['cleanup_including_compaction_seconds']==row['cleanup_seconds']+row['compaction_seconds']
 fixtures=read(raw/'fixture-results.json');assert len(fixtures)==14
 for record in fixtures:
  assert record['all_outputs_match'] and record['variants']['control']==record['variants']['candidate'] and record['variants']['control']['exit_code']==0 and len(record['variants']['control']['files'])==4
  name=Path(record['fixture']).stem if ':' not in record['fixture'] else record['fixture'].split(':')[-1]
  for variant,result in record['variants'].items():
   d=raw/'fixtures'/name/variant;command=read(d/'command.json');assert command['flags']==flags and command['binary_sha256']==pins[variant]
   for filename,pinned in result['files'].items():assert pin(d/filename)==pinned
   assert result['files']['source.mec']['sha256']==record['source_sha256']
 base=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase.mec').read_text();fragment=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase-states.mec').read_text();assembled=base.replace('+> sequence\n','+> sequence\n'+fragment+'\n',1).replace('phase-candidates(values, 1u64, 0u64, permitted, divisor)','#PhaseCandidates(values, permitted, divisor, 1u64, 0u64)',1);assert assembled==(raw/'fixture-inputs/numeric-nested-phase-states.mec').read_text()
 fields={'compiler_seconds':lambda r:r['compile']['total_seconds'],'whole_process_seconds':lambda r:r['process']['elapsed_seconds']}
 for phase in ['parse','catalog','frontend','artifact','encode','native']:fields[phase+'_seconds']=lambda r,p=phase:next(v['seconds'] for v in r['compile']['phases'] if v['phase']==p)
 for field in [f[0] for f in stage_fields]+['cleanup_including_compaction_seconds','compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:fields[field]=lambda r,k=field:r[k]
 qualified={field:{v:[fn(r) for r in rows if r['variant']==v] for v in ['control','candidate']} for field,fn in fields.items()}
 for values in qualified.values():
  mean=statistics.mean(values['control']);values['mean_reduction_fraction']=1-statistics.mean(values['candidate'])/mean if mean else None
 assert qualified==read(raw/'numerical-summary.json')
 blocks=[]
 for block in [rows[i:i+4] for i in range(0,len(rows),4)]:
  blocks.append(dict(order=[r['name'] for r in block],compiler_mean_reduction_fraction=1-statistics.mean(r['compile']['total_seconds'] for r in block if r['variant']=='candidate')/statistics.mean(r['compile']['total_seconds'] for r in block if r['variant']=='control')))
 return dict(flags_count=len(flags),qualified=qualified,blocks=blocks,output_hashes=expected,compiler_binary_sha256=pins,fixture_output_comparisons=fixtures)

qualification=validate_cohort(raw,flags,expected,{'control':control['sha256'],'candidate':build['binary_sha256']},'matches_current_control_output')
name='hosts/gpu/src/native_artifact/program/prepare/numeric_exits.rs'
before=(root/'source-base'/name).read_text();after=(root/'source'/name).read_text()
old_marker='    // Only a value read in this selected graph';new_marker='    let definitions = definitions::selected(facts, &ordinals, &reads, wanted)?;'
left=before[:before.index(old_marker)];assert left==after[:after.index(new_marker)]
marker='    for successors in &mut next {'
right=before[before.index(marker):];assert right==after[after.index(marker):].replace('#[path = "numeric_exit_definitions.rs"]\nmod definitions;\n\n','',1)
proof=read(raw/'source-equivalence-check.json')
assert proof==dict(graph_and_read_validation_byte_identical=True,graph_and_read_validation_sha256=hashlib.sha256(left.encode()).hexdigest(),remaining_exit_logic_and_liveness_call_byte_identical=True,remaining_exit_logic_sha256=hashlib.sha256(right.encode()).hexdigest(),whole_definition_inventory_still_validated_on_first_demand=True,engine_definition_api_unchanged=True)
facts=(root/'source/src/engine/src/native_artifact/program_facts.rs').read_text();assert 'definitions: OnceCell::new()' in facts and '.get_or_init(|| definitions(self.plan()))' in facts
selection=(root/'source/hosts/gpu/src/native_artifact/program/prepare/numeric_exit_definitions.rs').read_text()
assert 'facts.definition_sites(value)?;' in selection and 'first.filter(' in selection and 'values.sort_unstable();' in selection and 'values.dedup();' in selection
unit=read(raw/'tests.json');assert unit['exit_code']==0 and unit['head']==state['base_commit'] and unit['patch_sha256']==state['patch_sha256']
stdout=(raw/'tests.stdout').read_text();outcomes=re.findall(r'test result: ok\. (\d+) passed; 0 failed;',stdout);assert len(outcomes)==2
unit_count=sum(map(int,outcomes));assert unit_count>=4
for case in ['selected_definitions_match_original_and_decoded_graph_subsets','unread_invalid_producers_keep_the_first_definition_error','zero_values_preserve_the_absence_of_definition_demand','duplicate_records_and_nonlocal_definitions_keep_order_and_set_semantics']:
 assert f'test {case} ... ok' in stdout
failure=raw/'corrections/test-plan-loading-api';failed=read(failure/'tests.json');assert failed['exit_code']==101 and 'E0599' in (failure/'tests.stderr').read_text() and (failure/'tests.stdout').read_text().strip()==''
assert pin(failure/'source.patch')['sha256']==failed['patch_sha256']
def patch_sections(path):
 return {part.split('\n',1)[0]:part for part in path.read_text().split('diff --git ')[1:]}
old_sections=patch_sections(failure/'source.patch');new_sections=patch_sections(root/'source-change.patch');assert old_sections.keys()==new_sections.keys()
for name,section in old_sections.items():
 if 'exit_definitions_tests.rs' not in name:assert section==new_sections[name]
format_checks=read(raw/'format-checks/results.json');assert [x['exit_code'] for x in format_checks['checks']]==[1,1,0]
assert (raw/'format-checks/parent-numeric-exits.rs').read_text()==before
initial=read(raw/'cohort-initial.json');assert read(raw/'cohort.json')[:8]==initial
reason=read(raw/'additional-runs-reason.json');assert reason['order']==order[8:]
summary=dict(source_commit=state['source_commit'],base_commit=state['base_commit'],control_source_commit=state['control_source_commit'],hardware=state['hardware'],decision='Retain small preparation/instruction work reduction; overall compiler-time improvement unestablished; original first inventory demand and identical program bytes',candidate_patch_sha256=state['patch_sha256'],profile_settings=profile_settings,candidate_rebuild_seconds=build['seconds'],rebuild_scope='Observed locked/offline optimized-profile rebuild with existing Cargo caches. Excluded from Mech compilation timing; no matched cold-bootstrap comparison.',compiler_executable_bytes={v:excluded['compiler/'+v]['bytes'] for v in ['control','candidate']},source_equivalence_checks=proof,focused_rust_tests_passed=unit_count,format_checks=format_checks,additional_runs_reason=reason,timing_interpretation='Overall compiler time is effectively flat in sixteen observations: two balanced blocks are slower and two faster. The small preparation/instruction reduction is retained without claiming a demonstrated overall compiler-wall improvement.',scope=[
 'Sixteen serial fresh source-to-Object primary observations in ABBA then BAAB order repeated twice, identical 60 runtime flags and compiler build profile. No cached Object or decoded-only substitute.',
 'Builds, tests, screens, fixtures, CPU profiling, hashing, copying and packet work do not overlap primary timing. Source, MBC, Object and complete metadata bytes match the qualified program in both screens and all primary observations; fourteen successful fixture pairs match all four files.',
 'Each exact exit graph and its reads are visited and checked in the original order. The original first definition demand still validates the whole immutable inventory including unused malformed producers, even with empty reads. Empty/invalid-only wanted sets and zero-value plans retain absence of demand.',
 'After the first inventory demand, sorted distinct valid read IDs replace a full-plan bitmap and value scan. Site-less definitions, unselected/out-of-range sites and duplicate records retain the former semantics. No new engine API, global cache, persistent proof, changed graph or reused current-visit answer is introduced.',
 'Four focused production-selection tests compare the old full-value loop on 15,360 original/decoded random graph/subset comparisons plus malformed unused producers, empty queries, zero-value plans, invalid read IDs and duplicate/nonlocal records. The existing liveness tests also run; all test commands and outcomes are retained.',
 'Byte comparisons confirm graph/read validation and remaining exit logic/liveness calls are unchanged. Grammar, language, checked errors, scalar instructions, current shape/factory/visit/ownership proofs, finite admission, runtime accounting and backend settings remain. No execution machinery is retired.',
 'Generated machine code and complete metadata are byte-identical. No new compressor-runtime latency or CPU sampling campaign is claimed. Prior bare runtime-only lint failures keep their source pins in the helper-liveness packet. Both subjects retain SSA compaction and its cost. Complete compilation remains above ten seconds.'
],**qualification)
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
