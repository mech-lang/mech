from pathlib import Path
packet=Path('/private/tmp/mech-exit-definitions-packet-20261114')
old=Path('/private/tmp/mech-index-facts-packet-20261114/replay.py').read_text()
prefix=old[:old.index('stage_fields=')].replace('qualified-helper-liveness','qualified-index-facts')
body=old[old.index('stage_fields='):old.index('qualification=validate_cohort(')].replace("['parse','frontend','native']","['parse','catalog','frontend','artifact','encode','native']")
body=body.replace("'control-4','candidate-4']", "'control-4','candidate-4','control-5','candidate-5','candidate-6','control-6','candidate-7','control-7','control-8','candidate-8']")
body=body.replace("[rows[:4],rows[4:]]", "[rows[i:i+4] for i in range(0,len(rows),4)]")
end=r'''qualification=validate_cohort(raw,flags,expected,{'control':control['sha256'],'candidate':build['binary_sha256']},'matches_current_control_output')
name='hosts/gpu/src/native_artifact/program/prepare/numeric_exits.rs'
before=(root/'source-base'/name).read_text();after=(root/'source'/name).read_text()
old_marker='    // Only a value read in this selected graph';new_marker='    let definitions = definitions::selected(facts, &ordinals, &reads, wanted)?;'
left=before[:before.index(old_marker)];assert left==after[:after.index(new_marker)]
marker='    for successors in &mut next {'
right=before[before.index(marker):];assert right==after[after.index(marker):].replace('#[path = "numeric_exit_definitions.rs"]\nmod definitions;\n\n','',1)
proof=read(raw/'source-equivalence-check.json')
assert proof==dict(graph_and_read_validation_byte_identical=True,graph_and_read_validation_sha256=hashlib.sha256(left.encode()).hexdigest(),remaining_exit_logic_and_liveness_call_byte_identical=True,remaining_exit_logic_sha256=hashlib.sha256(right.encode()).hexdigest(),whole_definition_inventory_still_validated_on_first_demand=True,engine_definition_api_unchanged=True)
facts=(root/'source/src/engine/src/native_artifact/program_facts.rs').read_text();assert 'definitions: OnceCell::new()' in facts and '.get_or_init(|| definitions(self.plan()))' in facts
selection=(root/'source/hosts/gpu/src/native_artifact/program/prepare/numeric_exit_definitions.rs').read_text()
assert 'facts.definition_sites(value)?;' in selection and 'first.filter(' in selection and 'values.sort_unstable();' in selection and 'values.dedup();' in selection
unit=read(raw/'tests.json');assert unit['exit_code']==0 and unit['head']==state['base_commit'] and unit['patch_sha256']==state['patch_sha256']
stdout=(raw/'tests.stdout').read_text();outcomes=re.findall(r'test result: ok\. (\d+) passed; 0 failed;',stdout);assert len(outcomes)==2
unit_count=sum(map(int,outcomes));assert unit_count>=4
for case in ['selected_definitions_match_original_and_decoded_graph_subsets','unread_invalid_producers_keep_the_first_definition_error','zero_values_preserve_the_absence_of_definition_demand','duplicate_records_and_nonlocal_definitions_keep_order_and_set_semantics']:
 assert f'test {case} ... ok' in stdout
failure=raw/'corrections/test-plan-loading-api';failed=read(failure/'tests.json');assert failed['exit_code']==101 and 'E0599' in (failure/'tests.stderr').read_text() and (failure/'tests.stdout').read_text().strip()==''
assert pin(failure/'source.patch')['sha256']==failed['patch_sha256']
def patch_sections(path):
 return {part.split('\n',1)[0]:part for part in path.read_text().split('diff --git ')[1:]}
old_sections=patch_sections(failure/'source.patch');new_sections=patch_sections(root/'source-change.patch');assert old_sections.keys()==new_sections.keys()
for name,section in old_sections.items():
 if 'exit_definitions_tests.rs' not in name:assert section==new_sections[name]
format_checks=read(raw/'format-checks/results.json');assert [x['exit_code'] for x in format_checks['checks']]==[1,1,0]
assert (raw/'format-checks/parent-numeric-exits.rs').read_text()==before
initial=read(raw/'cohort-initial.json');assert read(raw/'cohort.json')[:8]==initial
reason=read(raw/'additional-runs-reason.json');assert reason['order']==order[8:]
summary=dict(source_commit=state['source_commit'],base_commit=state['base_commit'],control_source_commit=state['control_source_commit'],hardware=state['hardware'],decision='Retain small preparation/instruction work reduction; overall compiler-time improvement unestablished; original first inventory demand and identical program bytes',candidate_patch_sha256=state['patch_sha256'],profile_settings=profile_settings,candidate_rebuild_seconds=build['seconds'],rebuild_scope='Observed locked/offline optimized-profile rebuild with existing Cargo caches. Excluded from Mech compilation timing; no matched cold-bootstrap comparison.',compiler_executable_bytes={v:excluded['compiler/'+v]['bytes'] for v in ['control','candidate']},source_equivalence_checks=proof,focused_rust_tests_passed=unit_count,format_checks=format_checks,additional_runs_reason=reason,timing_interpretation='Overall compiler time is effectively flat in sixteen observations: two balanced blocks are slower and two faster. The small preparation/instruction reduction is retained without claiming a demonstrated overall compiler-wall improvement.',scope=[
 'Sixteen serial fresh source-to-Object primary observations in ABBA then BAAB order repeated twice, identical 60 runtime flags and compiler build profile. No cached Object or decoded-only substitute.',
 'Builds, tests, screens, fixtures, CPU profiling, hashing, copying and packet work do not overlap primary timing. Source, MBC, Object and complete metadata bytes match the qualified program in both screens and all primary observations; fourteen successful fixture pairs match all four files.',
 'Each exact exit graph and its reads are visited and checked in the original order. The original first definition demand still validates the whole immutable inventory including unused malformed producers, even with empty reads. Empty/invalid-only wanted sets and zero-value plans retain absence of demand.',
 'After the first inventory demand, sorted distinct valid read IDs replace a full-plan bitmap and value scan. Site-less definitions, unselected/out-of-range sites and duplicate records retain the former semantics. No new engine API, global cache, persistent proof, changed graph or reused current-visit answer is introduced.',
 'Four focused production-selection tests compare the old full-value loop on 15,360 original/decoded random graph/subset comparisons plus malformed unused producers, empty queries, zero-value plans, invalid read IDs and duplicate/nonlocal records. The existing liveness tests also run; all test commands and outcomes are retained.',
 'Byte comparisons confirm graph/read validation and remaining exit logic/liveness calls are unchanged. Grammar, language, checked errors, scalar instructions, current shape/factory/visit/ownership proofs, finite admission, runtime accounting and backend settings remain. No execution machinery is retired.',
 'Generated machine code and complete metadata are byte-identical. No new compressor-runtime latency or CPU sampling campaign is claimed. Prior bare runtime-only lint failures keep their source pins in the helper-liveness packet. Both subjects retain SSA compaction and its cost. Complete compilation remains above ten seconds.'
],**qualification)
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
'''
(packet/'replay.py').write_text(prefix+body+end)
