Selected exit-query definitions, Apple M3, 2026-11-14.
Each current exit query still visits and validates its exact selected graph in
its original order. The first former definition demand remains even for empty
read sets, validating the whole immutable same-plan inventory including unused
producers. After that demand only values read in the graph are visited. Empty
or wholly out-of-range wanted sets and zero-value plans retain no-demand
behavior. Definition/graph/current-visit policies and liveness are unchanged.
No engine API, language, serialized format or persistent/current proof cache is
added. Original/decoded graph subsets and malformed/empty/duplicate cases compare
the exact production selection with the former value loop in focused Rust tests.
Sixteen primary observations use ABBA/BAAB twice; all runs and the reason for
additional observations are retained. Overall compiler time is effectively flat
with mixed block directions; only small preparation/instruction work reduction
is credited. All commands, outputs and failed attempts are retained.
Compiler executables are excluded and pinned. Builds, screens, fixtures, tests,
sampling, copying, hashing and archive work do not overlap primary timing.
Both subjects use the same compiler profile, 60 flags and complete fresh source
pipeline including SSA compaction. No execution machinery is retired. Python
3.11+ replay is pure offline validation/reconstruction without compilers,
benchmarks, original scratch paths or external services.
