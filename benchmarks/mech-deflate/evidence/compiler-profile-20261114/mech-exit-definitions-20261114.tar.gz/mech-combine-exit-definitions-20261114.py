from pathlib import Path
import json,subprocess,sys
root=Path('/private/tmp/mech-exit-definitions-20261114');rows=json.loads((root/'cohort-repeat.json').read_text())
assert [r['name'] for r in rows]==['control-5','candidate-5','candidate-6','control-6','candidate-7','control-7','control-8','candidate-8']
for name,block in [('third',rows[:4]),('fourth',rows[4:])]:
 (root/('cohort-'+name+'.json')).write_text(json.dumps(block,indent=2)+'\n')
p=Path('/private/tmp/mech-analyze-exit-definitions-20261114.py');s=p.read_text().replace("['cohort-first.json','cohort-second.json']","['cohort-first.json','cohort-second.json','cohort-third.json','cohort-fourth.json']");p.write_text(s)
subprocess.run([sys.executable,str(p)],check=True)
