from pathlib import Path
import subprocess,json,hashlib,shutil
repo=Path.cwd();packet=Path('/private/tmp/mech-scope-graph-packet-20261114');assert not packet.exists()
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();base='c58562fdc38350b6e3b49fce3ba49ca220e529de';control_source='610f3692c0ad0b894d6537f206a79a4de8833ede'
raw=Path('/private/tmp/mech-scope-graph-20261114');patch=subprocess.check_output(['git','diff','--binary',base,source]);assert patch==(raw/'candidate.patch').read_bytes()
assert subprocess.check_output(['git','diff',control_source,base,'--','src','hosts','vendor','machines','Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.toml'])==b''
excluded=[]
for p in sorted(raw.rglob('*')):
 if not p.is_file():continue
 rel=Path('compiler')/p.relative_to(raw)
 if p.name in ['control','candidate','graph-tests']:
  excluded.append(dict(path=rel.as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()));continue
 d=packet/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
(packet/'excluded-executables.json').write_text(json.dumps(excluded,indent=2)+'\n');(packet/'source-change.patch').write_bytes(patch)
state=dict(source_commit=source,base_commit=base,control_source_commit=control_source,control_production_source_identical_to_base=True,patch_sha256=hashlib.sha256(patch).hexdigest(),hardware='Apple M3 Air, 8 cores (4P+4E), 16 GB, macOS 26.2',rustc=subprocess.check_output(['rustc','-Vv'],text=True),cargo=subprocess.check_output(['cargo','-V'],text=True));(packet/'source-state.json').write_text(json.dumps(state,indent=2,sort_keys=True)+'\n')
changed=subprocess.check_output(['git','diff','--name-only',base,source],text=True).splitlines()
paths=changed+['Cargo.toml','Cargo.lock','.cargo/config.toml','LICENSE','src/engine/src/native_artifact/definition_set.rs','src/engine/src/native_artifact/program.rs','src/engine/src/native_artifact/iteration_abi.rs','hosts/gpu/tests/fixtures/native/deflate-huffman-LICENSES.md']
paths+=['benchmarks/mech-deflate/native-profile/'+n for n in ['Cargo.lock','compile_profile.rs','profile_compile.py']]
paths+=['hosts/gpu/tests/fixtures/native/'+n+'.mec' for n in ['numeric-nested-phase','numeric-nested-phase-states','numeric-private-fixed-nested','numeric-changing-capture-tree','numeric-array-windows','numeric-multiple-children']]
for name in dict.fromkeys(paths):
 d=packet/'source'/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(subprocess.check_output(['git','show',source+':'+name]))
for name in [*changed,'Cargo.toml']:
 if subprocess.run(['git','cat-file','-e',base+':'+name],capture_output=True).returncode:continue
 d=packet/'source-base'/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(subprocess.check_output(['git','show',base+':'+name]))
validation=packet/'validation';validation.mkdir()
for suffix in ['.json','.archive.json']:shutil.copy2(repo/('benchmarks/mech-deflate/native-profile/compiler-lto-compile-apple-m3-20261114'+suffix),validation/('qualified-shared-schema'+suffix))
shutil.copytree(Path('/private/tmp/mech-borrowed-schema-packet-20261114/licenses'),packet/'licenses')
for pattern in ['mech-*scope-graph*20261114.py','mech-*scope-graph*20261114.log','mech-scope-graph-check*20261114.jsonl','mech-scope-graph-check*20261114.stderr','mech-scope-graph-check-suggestions-20261114.json']:
 for p in Path('/private/tmp').glob(pattern):
  if p.is_file():shutil.copy2(p,packet/p.name)
shutil.copytree(Path('/private/tmp/mech-native-after-sharing-20261114'),packet/'profile')
demangler=Path('/private/tmp/mech-compiler-process-profile-20261114/demangler')
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:
 d=packet/'profile/demangler-source'/name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(demangler/name,d)
for name in ['mech-profile-native-shared-schema-20261114.py','mech-demangle-native-shared-schema-20261114.py','mech-native-after-sharing-driver-20261114.log']:
 shutil.copy2(Path('/private/tmp')/name,packet/name)
(packet/'README.txt').write_text('''Current-scope validation topology, Apple M3, 2026-11-14.
Pending qualification. All observations, commands, source snapshots and generated
outputs remain here. Compiler/test executables are excluded and pinned.
Four direct graph tests duplicate the four tests included in the 152 passing
engine native-artifact tests; these are 152 unique tests. The discovery callback,
predecessor lists, ready order and fresh definition proof preserve their original
semantics. The original conservative admission limit remains unchanged.
The separate five-window CPU profile uses the qualified control, preserves every
output byte and is excluded from primary timing. It keeps raw/demangled stacks,
self tables, all sampler commands and existing demangler source/pin. Main-thread
waits are not CPU work; self counts are not phase-exclusive elapsed attribution.
This complete packet is published in benchmarks at the user's request. Python
3.11+ replay is pure offline reconstruction without compilers or benchmarks.
''')
print(packet,flush=True)
