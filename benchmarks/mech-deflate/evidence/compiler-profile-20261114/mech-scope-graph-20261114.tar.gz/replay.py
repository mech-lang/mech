from pathlib import Path
import json,hashlib,re,statistics,tomllib
root=Path(__file__).resolve().parent;raw=root/'compiler'
read=lambda p:json.loads(p.read_text())
def pin(p):
 data=p.read_bytes();return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
state=read(root/'source-state.json');build=read(raw/'candidate-build.json');control=read(raw/'control-origin.json');patch=pin(root/'source-change.patch');assert patch==pin(raw/'candidate.patch') and patch['sha256']==state['patch_sha256']==build['patch_sha256']
assert build['exit_code']==0 and build['head']==state['base_commit'] and state['control_production_source_identical_to_base']
prior=read(root/'validation/qualified-shared-schema.json');receipt=read(root/'validation/qualified-shared-schema.archive.json');assert pin(root/'validation/qualified-shared-schema.json')['sha256']==receipt['replay_sha256'];assert control['sha256']==prior['compiler_binary_sha256']['candidate'] and control['source_commit']==state['control_source_commit']==prior['source_commit']
flags=read(raw/'runtime-flags.json');assert len(flags)==60;expected=prior['output_hashes'];assert read(raw/'reference-pins.json')==expected
excluded={r['path']:r for r in read(root/'excluded-executables.json')};assert excluded['compiler/control']['sha256']==control['sha256'] and excluded['compiler/candidate']['sha256']==build['binary_sha256']
profile_settings={}
for name in ['Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.toml']:
 before=tomllib.loads((root/'source-base'/name).read_text());after=tomllib.loads((root/'source'/name).read_text());assert after['profile']==before['profile'];profile_settings[name]=after['profile']['compiler']
assert '--profile' in build['command'] and build['command'][build['command'].index('--profile')+1]=='compiler' and '--release' not in build['command']
stage_fields=[('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]
host_fields=[('max_rss_bytes',r'(\d+)  maximum resident set size'),('instructions',r'(\d+)  instructions retired'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]
order=['control-1','candidate-1','candidate-2','control-2','candidate-3','control-3','control-4','candidate-4']
def validate_cohort(raw,flags,expected,pins,key):
 rows=read(raw/'cohort.json');assert [r['name'] for r in rows]==order
 for name in ['control-screen','candidate-screen',*order]:
  variant=name.split('-')[0];d=raw/name;process=read(d/'process.json');assert process['exit_code']==0 and process['samples']==0 and process['sampling_error'] is None
  command=read(raw/(name+'-command.json'));assert command['flags']==flags and command['binary_sha256']==pins[variant]
  for filename,pinned in expected.items():assert pin(d/filename)==pinned and read(d/'output-check.json')[filename]==dict(pinned,**{key:True})
 for row in rows:
  d=raw/row['name'];assert row['compile']==read(d/'compile.json') and row['process']==read(d/'process.json') and row['files']==read(d/'output-check.json')
  assert row['variant']==row['name'].split('-')[0]
  stamps=[json.loads(line) for line in (d/'stages.jsonl').read_text().splitlines()]
  for field,begin,end in stage_fields:assert row[field]==next(s['elapsed'] for s in stamps if s['line'].startswith(end))-next(s['elapsed'] for s in stamps if s['line'].startswith(begin))
  for field,pattern in host_fields:assert row[field]==int(re.search(pattern,(d/'stderr.log').read_text()).group(1))
  if True:
   begin=next(s for s in stamps if s['line'].startswith('compact-stage: compact values before='));end=next(s for s in stamps if s['line'].startswith('compact-stage: CFG cleanup'));assert row['compaction_seconds']==end['elapsed']-begin['elapsed'];assert row['value_ids_before']==int(begin['line'].split('=')[-1])==20787570;assert row['value_ids_after']==int(next(s['line'] for s in stamps if s['line'].startswith('compact-values: retained=')).split('=')[-1])==1241393
  else:assert row['compaction_seconds']==0
  assert row['cleanup_including_compaction_seconds']==row['cleanup_seconds']+row['compaction_seconds']
 fixtures=read(raw/'fixture-results.json');assert len(fixtures)==14
 for record in fixtures:
  assert record['all_outputs_match'] and record['variants']['control']==record['variants']['candidate'] and record['variants']['control']['exit_code']==0 and len(record['variants']['control']['files'])==4
  name=Path(record['fixture']).stem if ':' not in record['fixture'] else record['fixture'].split(':')[-1]
  for variant,result in record['variants'].items():
   d=raw/'fixtures'/name/variant;command=read(d/'command.json');assert command['flags']==flags and command['binary_sha256']==pins[variant]
   for filename,pinned in result['files'].items():assert pin(d/filename)==pinned
   assert result['files']['source.mec']['sha256']==record['source_sha256']
 base=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase.mec').read_text();fragment=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase-states.mec').read_text();assembled=base.replace('+> sequence\n','+> sequence\n'+fragment+'\n',1).replace('phase-candidates(values, 1u64, 0u64, permitted, divisor)','#PhaseCandidates(values, permitted, divisor, 1u64, 0u64)',1);assert assembled==(raw/'fixture-inputs/numeric-nested-phase-states.mec').read_text()
 fields={'compiler_seconds':lambda r:r['compile']['total_seconds'],'whole_process_seconds':lambda r:r['process']['elapsed_seconds']}
 for phase in ['parse','frontend','native']:fields[phase+'_seconds']=lambda r,p=phase:next(v['seconds'] for v in r['compile']['phases'] if v['phase']==p)
 for field in [f[0] for f in stage_fields]+['cleanup_including_compaction_seconds','compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:fields[field]=lambda r,k=field:r[k]
 qualified={field:{v:[fn(r) for r in rows if r['variant']==v] for v in ['control','candidate']} for field,fn in fields.items()}
 for values in qualified.values():
  mean=statistics.mean(values['control']);values['mean_reduction_fraction']=1-statistics.mean(values['candidate'])/mean if mean else None
 assert qualified==read(raw/'numerical-summary.json')
 blocks=[]
 for block in [rows[:4],rows[4:]]:
  blocks.append(dict(order=[r['name'] for r in block],compiler_mean_reduction_fraction=1-statistics.mean(r['compile']['total_seconds'] for r in block if r['variant']=='candidate')/statistics.mean(r['compile']['total_seconds'] for r in block if r['variant']=='control')))
 return dict(flags_count=len(flags),qualified=qualified,blocks=blocks,output_hashes=expected,compiler_binary_sha256=pins,fixture_output_comparisons=fixtures)

qualification=validate_cohort(raw,flags,expected,{'control':control['sha256'],'candidate':build['binary_sha256']},'matches_current_control_output')
tests={}
for name,count in [('graph-tests',4),('engine-tests',152)]:
 command=read(raw/(name+'-command.json'));assert command['exit_code']==0 and command['source_patch_sha256']==state['patch_sha256']==pin(raw/(name+'.patch'))['sha256']
 counts=list(map(int,re.findall(r'test result: ok\. (\d+) passed',(raw/(name+'.log')).read_text())));assert counts==[count];tests[name]=dict(command=command,passed=count)
graph_build=read(raw/'graph-build-command.json');assert graph_build['exit_code']==0 and graph_build['source_patch_sha256']==state['patch_sha256']==pin(raw/'graph-build.patch')['sha256'];assert 'compiler/graph-tests' in excluded
assert 'scope_graph.rs' in (root/'source/benchmarks/mech-deflate/native-profile/scope_graph_tests.rs').read_text()
profile_path=root/'profile';profile_command=read(profile_path/'command.json');assert profile_command['flags']==flags and profile_command['binary_sha256']==control['sha256'] and state['control_source_commit'].startswith(profile_command['source_commit'])
assert read(profile_path/'process.json')['exit_code']==0 and read(profile_path/'output-check.json')==expected
for filename,pinned in expected.items():assert pin(profile_path/'output'/filename)==pinned
samples=read(profile_path/'samples.json');assert len(samples)==5 and all(row['exit_code']==0 for row in samples)
mapping=read(profile_path/'demangled-symbols.json');tables={};symbols=set()
for p in sorted(profile_path.glob('*-sample.txt')):
 text=p.read_text();symbols.update(re.findall(r'_R[A-Za-z0-9_]+',text));mapped=re.sub(r'_R[A-Za-z0-9_]+',lambda m:mapping[m.group(0)],text);assert mapped==p.with_name(p.stem+'-demangled.txt').read_text();parsed=[]
 for line in mapped[mapped.index('Sort by top of stack'):].splitlines()[1:]:
  match=re.match(r'\s+(.*?)\s+\(in (.*?)\)\s+(\d+)\s*$',line)
  if match:parsed.append(dict(symbol=match[1],image=match[2],self_samples=int(match[3])))
  elif parsed:break
 assert parsed==read(p.with_name(p.stem+'-self.json'));tables[p.name]=[r for r in parsed if r['symbol']!='__ulock_wait'][:15]
assert set(mapping)==symbols and len(tables)==5
profile=dict(command=profile_command,samples=samples,completed_sample_files=len(tables),cpu_self_samples=tables,main_thread_waits_excluded=True)
summary=dict(source_commit=state['source_commit'],base_commit=state['base_commit'],control_source_commit=state['control_source_commit'],hardware=state['hardware'],decision='Retain scope-sized topology and definition-row storage in fresh current-visit validation; identical generated program bytes',candidate_patch_sha256=state['patch_sha256'],profile_settings=profile_settings,candidate_rebuild_seconds=build['seconds'],rebuild_scope='Observed locked/offline optimized-profile rebuild with existing Cargo caches. Excluded from Mech compilation timing; no matched cold-bootstrap comparison.',compiler_executable_bytes={v:excluded['compiler/'+v]['bytes'] for v in ['control','candidate']},rust_tests=tests,unique_engine_tests=152,duplicate_direct_graph_tests=4,diagnostic_control_profile=profile,scope=[
 'Eight serial fresh source-to-Object primary observations in ABBA then BAAB order, identical 60 runtime flags and compiler build profile. No cached Object or decoded-only substitute.',
 'Builds, tests, CPU sampling, screens, fixtures, hashing, copying and packet work do not overlap primary timing. All source, MBC, Object and complete metadata bytes match the qualified program in both screens and every primary observation; fourteen successful fixture pairs match all four files.',
 'Current-visit validation remains fresh on every call. Only topology scratch storage changes: a single ordinal scratch table serves per-call scope graphs, and only reachable scope nodes own edges and definition rows. The original DFS callback order, predecessor order, ready order and proof transfer remain. No definition, scope or execution authority is cached across calls.',
 'The original conservative definition-table admission calculation and limit remain unchanged. Grammar, language, checked errors, native scalar emission, runtime accounting, factory selection and backend optimization settings remain unchanged.',
 'Final source passes 152 engine native-artifact tests including four graph tests. Four standalone runs of those production graph tests are duplicate coverage, not four additional unique tests.',
 'The separate control CPU profile contains five requested one-second stage windows with raw and demangled stacks, commands, self tables, existing demangler source/pin and identical output bytes. Main-thread waits are excluded from CPU hotspot tables. Samples are not phase-exclusive elapsed or exact source-line attribution.',
 'Both subjects include retired-value compaction and its measured cost. Generated machine code and complete metadata are byte-identical. No new compressor-runtime timing campaign is claimed. Complete compilation remains above ten seconds.'
],**qualification)
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
