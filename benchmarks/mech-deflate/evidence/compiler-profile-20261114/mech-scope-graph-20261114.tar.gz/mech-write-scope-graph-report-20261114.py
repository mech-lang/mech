from pathlib import Path
import json
repo=Path.cwd();packet=Path('/private/tmp/mech-scope-graph-packet-20261114');s=json.loads((packet/'summary.json').read_text());q=s['qualified'];rows=[]
for key,label in [('compiler_seconds','Compiler, s'),('whole_process_seconds','Whole process, s'),('parse_seconds','Parse, s'),('frontend_seconds','Frontend, s'),('native_seconds','Native, s'),('canonical_lowering_seconds','Canonical lowering, s'),('preparation_seconds','Preparation, s'),('numeric_generation_seconds','Numeric generation, s'),('source_cfg_seconds','Source CFG, s'),('cleanup_including_compaction_seconds','Cleanup including compaction, s'),('compaction_seconds','Compaction, s'),('instructions','Retired instructions'),('max_rss_bytes','Peak RSS, bytes'),('peak_footprint_bytes','Peak footprint, bytes')]:
 v=q[key];fmt=(lambda x:f'{x:,}') if key in ['instructions','max_rss_bytes','peak_footprint_bytes'] else (lambda x:f'{x:.6f}')
 rows.append(f"| {label} | {fmt(min(v['control']))}–{fmt(max(v['control']))} | {fmt(min(v['candidate']))}–{fmt(max(v['candidate']))} | {-100*v['mean_reduction_fraction']:+.2f}% |")
report=f'''# Scope-sized current-visit validation: compilation qualification

Complete fresh level-12 compilation takes **20.368–20.777 seconds** on the Apple
M3 Air. Eight matched runs show **3.44% lower whole-process time, 3.75% lower
compiler time, 15.83% lower preparation time and 2.37% fewer instructions**.
All source, MBC, Object and complete metadata bytes remain identical. Peak RSS
is an adverse 0.008% higher with overlapping ranges; no memory improvement is
claimed. The full ten-second compilation goal remains open.

The validator previously allocated incoming edges, degrees, reachability and
definition-row owners for every program block during each nested scope check.
The level-12 program has 41,039 source-plan blocks, while individual scopes need
only their reachable subset. One ordinal scratch table now serves a validation
call; each scope owns its own reachable graph and definition rows. Nested checks
cannot overwrite a parent's local edges. Discovery still invokes its checks in
the original DFS order, predecessor lists retain insertion order, and the proof
uses the same initial source order and edge-driven ready queue. Only immutable
collapsed topology is retained during each scope check; every definition proof
is fresh. No proof survives a validation call.

The original conservative definition-table size calculation and admission limit
remain unchanged. The existing definition-transfer body, semantic reads/writes,
checked errors, grammar, language, scalar instruction emission, factory selection,
runtime accounting and generated-program optimization settings retain their
existing behavior. No execution machinery is retired.

Source `{s['source_commit']}`, parent `{s['base_commit']}`.
The frozen control comes from `{s['control_source_commit']}`; its production
source equals the documentation-only parent. Both subjects use the same opt-in
`compiler` build profile, full fresh source-to-Object pipeline and 60 runtime
flags. Hardware: Apple M3 Air, 8 cores (4P+4E), 16 GB, macOS 26.2.

| Measurement | Control range (4 runs) | Candidate range (4 runs) | Mean change |
| --- | --- | --- | ---: |
'''+ '\n'.join(rows)+'''

Runs are serial control/candidate/candidate/control then
candidate/control/control/candidate. Both blocks improve compiler time (3.51%
and 3.99%). Every candidate compiler, process, native, preparation and instruction
observation falls below every control. Parse time is an adverse 0.72% higher;
compaction is 1.89% higher and both memory means are slightly higher. All contrary
observations remain. These finite cohorts are descriptive, not population
estimates. Both subjects include retired SSA value compaction and its measured
cost. Native substage durations are nested, not additional whole-process costs.

Builds, tests, screens, fixture compiles, CPU sampling, hashing, copying and packet
work do not overlap primary timing. The observed 403.891-second compiler rebuild
uses existing Cargo caches, is excluded from Mech compilation timing and is not
a matched cold-bootstrap comparison. Both screens and all eight primary runs
reproduce every qualified output byte. Fourteen successful fixture pairs cover
six complete array/enum programs and eight checked scalar programs, also matching
all four output files. Generated program code and metadata are byte-identical;
no new compressor-runtime timing campaign is claimed.

The final source passes **152 engine native-artifact tests, including four new
graph tests**. Those tests compare original discovery/failure order and incoming
edges over seeded graphs, acyclic ready order, duplicate edges, cycles, high sparse
IDs, nested/repeated queries and invalid sites. An earlier direct run of the exact
production module's four tests duplicates this coverage and is not counted again.
The control copy initially lacked execution permission; its failed warmup exits
126 before compiler execution and remains outside primary timing. Repairing only
the file mode preserves its frozen bytes and hash. A packet-curation correction
for an unnecessary nonexistent source path also remains separately recorded.

A separate diagnostic control compile samples five requested one-second windows:
preparation, numeric helpers, source CFG, cleanup and main machine-code emission.
All output bytes match. The packet retains every command, raw/demangled sample,
self table and the existing demangler's source/pin. Main-thread waits are excluded
from hotspot tables. Samples are neither phase-exclusive elapsed measurements nor
exact source-line attribution. They identify repeated liveness, scope-table work,
helper traversal analysis, SSA lookup, phi removal and register allocation as
remaining work. A recorded next experiment targets the full-program omitted-edge
scan in `Scope::supported_prefix`; no saving from that future change is claimed.

The [compact result](../../benchmarks/mech-deflate/native-profile/scope-graph-compile-apple-m3-20261114.json)
and [receipt](../../benchmarks/mech-deflate/native-profile/scope-graph-compile-apple-m3-20261114.archive.json)
pin the complete [benchmark evidence packet](../../benchmarks/mech-deflate/evidence/compiler-profile-20261114/README.md).
It includes exact source/base snapshots and patches, flags, commands, raw timings,
all outputs, test logs, corrections and pure offline replay. Compiler and test
executables are excluded and hash-pinned. Python 3.11+ replay reconstructs the
summary without compilers, benchmarks, original scratch paths or external services.
'''
(repo/'docs/design/native-scope-graph-compile-profile.md').write_text(report);(packet/'REPORT.md').write_text(report)
p=repo/'docs/design/native-compiler-process-profile.md';text=p.read_text().replace('**21.196–21.415 seconds per complete','**20.368–20.777 seconds per complete',1).replace('and [shared pending schemas](native-shared-schema-compile-profile.md).','[shared pending schemas](native-shared-schema-compile-profile.md),\nand [scope-sized validation](native-scope-graph-compile-profile.md).',1)
text+='''
The next [scope-topology qualification](native-scope-graph-compile-profile.md)
allocates current-visit validation rows and edges only for each reachable scope.
All checks and the conservative admission limit remain. Eight matched 60-flag
compiles take 20.368–20.777 seconds: process time falls 3.44%, preparation 15.83%
and instructions 2.37%. Peak RSS is an adverse 0.008% higher with overlapping
ranges. All generated bytes match, and 152 engine tests pass. The twelfth packet
retains five diagnostic control CPU windows, all measurements, fourteen fixture
pairs, screens, corrections and pure offline replay. The ten-second target remains open.
''';p.write_text(text)
p=repo/'benchmarks/mech-deflate/EXPERIMENTS.md';text=p.read_text();pos=text.index('Paths below name reports **inside the external bundle**.')
text=text[:pos]+'''The [scope-sized validation qualification](../../docs/design/native-scope-graph-compile-profile.md)
retains scope-local topology and definition-row owners with fresh proof checks
and the original conservative admission limit. Eight matched 60-flag runs take
20.368–20.777 seconds: 3.44% less whole-process time, 15.83% less preparation and
2.37% fewer instructions. Peak RSS is an adverse 0.008% higher. All output bytes
match; 152 engine tests pass. Its twelfth packet retains five diagnostic control
CPU windows, both screens, fourteen fixture pairs, every observation and correction.
The repository copy verifies and replays offline; earlier archives remain unchanged.

'''+text[pos:];p.write_text(text)
p=repo/'benchmarks/mech-deflate/native-profile/README.md';text=p.read_text();text+='''
The [scope-sized validation result](../../../docs/design/native-scope-graph-compile-profile.md)
records fresh compilation at 20.368–20.777 seconds, preserving every generated
byte and the original admission limit. Its complete packet is in the same
[compiler-profile evidence index](../evidence/compiler-profile-20261114/README.md).
''';p.write_text(text)
