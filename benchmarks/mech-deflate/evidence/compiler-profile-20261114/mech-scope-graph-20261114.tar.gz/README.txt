Current-scope validation topology, Apple M3, 2026-11-14.
Matched qualification retained. All observations, commands, source snapshots and generated
outputs remain here. Compiler/test executables are excluded and pinned.
Four direct graph tests duplicate the four tests included in the 152 passing
engine native-artifact tests; these are 152 unique tests. The discovery callback,
predecessor lists, ready order and fresh definition proof preserve their original
semantics. The original conservative admission limit remains unchanged.
The separate five-window CPU profile uses the qualified control, preserves every
output byte and is excluded from primary timing. It keeps raw/demangled stacks,
self tables, all sampler commands and existing demangler source/pin. Main-thread
waits are not CPU work; self counts are not phase-exclusive elapsed attribution.
This complete packet is published in benchmarks at the user's request. Python
3.11+ replay is pure offline reconstruction without compilers or benchmarks.
