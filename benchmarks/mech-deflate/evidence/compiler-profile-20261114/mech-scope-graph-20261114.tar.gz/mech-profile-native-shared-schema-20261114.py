from pathlib import Path
import os,json,subprocess,hashlib,threading,time,re
repo=Path.cwd();raw=Path('/private/tmp/mech-shared-schema-20261114');root=Path('/private/tmp/mech-native-after-sharing-20261114');root.mkdir()
binary=raw/'candidate';build=json.loads((raw/'candidate-build.json').read_text());assert hashlib.sha256(binary.read_bytes()).hexdigest()==build['binary_sha256']
assert subprocess.check_output(['git','diff','610f3692c0','HEAD','--','src','hosts','vendor','machines'])==b''
flags=json.loads((raw/'runtime-flags.json').read_text());env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')};env.update(flags)
cmd=['/usr/bin/time','-lp',str(binary),'benchmark',str(root/'output'),'compact'];(root/'output').mkdir()
(root/'command.json').write_text(json.dumps(dict(command=cmd,flags=flags,binary_sha256=build['binary_sha256'],source_commit='610f3692c0',scope='Separate diagnostic stage CPU profile; excluded from primary timings.'),indent=2)+'\n')
started=time.monotonic();pid=None;threads=[];observations=[];latest=None
markers={'compact-stage: preparation blocks=':'preparation','compact-stage: native module':'numeric-helpers','compact-stage: source CFG':'source-cfg','compact-stage: CFG cleanup':'cleanup','compact-stage: machine code':'machine-code'}
def sample(name,trigger):
 command=['/usr/bin/sample',str(pid),'1','1','-mayDie','-file',str(root/(name+'-sample.txt'))]
 row=dict(stage=name,command=command,start_seconds=time.monotonic()-started,trigger=trigger)
 with (root/(name+'-sample.log')).open('w') as log:p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 row.update(exit_code=p.returncode,end_seconds=time.monotonic()-started,last_stage=latest);observations.append(row)
with (root/'output/stdout.jsonl').open('w') as stdout,(root/'output/stderr.log').open('w') as stderr,(root/'output/stages.jsonl').open('w') as stamps:
 p=subprocess.Popen(cmd,cwd=repo,env=env,stdout=stdout,stderr=subprocess.PIPE,text=True,bufsize=1)
 for line in p.stderr:
  latest=line.rstrip();stderr.write(line);stderr.flush();row=dict(elapsed=time.monotonic()-started,line=latest);stamps.write(json.dumps(row)+'\n');stamps.flush()
  m=re.search(r'compile-profile: pid=(\d+)',line)
  if m:pid=int(m.group(1))
  for marker,name in list(markers.items()):
   if line.startswith(marker):
    assert pid;print('SAMPLE',name,flush=True);t=threading.Thread(target=sample,args=(name,row));t.start();threads.append(t);del markers[marker];break
 status=p.wait()
for t in threads:t.join()
(root/'samples.json').write_text(json.dumps(sorted(observations,key=lambda x:x['start_seconds']),indent=2)+'\n');(root/'process.json').write_text(json.dumps(dict(exit_code=status,elapsed_seconds=time.monotonic()-started),indent=2)+'\n');assert status==0 and not markers
expected=json.loads((raw/'reference-pins.json').read_text())
for name,pin in expected.items():
 data=(root/'output'/name).read_bytes();assert dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())==pin
(root/'output-check.json').write_text(json.dumps(expected,indent=2,sort_keys=True)+'\n');print('All output bytes preserved',flush=True)
