from pathlib import Path
packet=Path('/private/tmp/mech-scope-graph-packet-20261114');old=Path('/private/tmp/mech-shared-schema-packet-20261114/replay.py').read_text();prefix=old[:old.index('stage_fields=')].replace('qualified-compiler-lto','qualified-shared-schema')
defs=old[old.index('stage_fields='):old.index("qualification=validate_cohort(")]
end='''qualification=validate_cohort(raw,flags,expected,{'control':control['sha256'],'candidate':build['binary_sha256']},'matches_current_control_output')
tests={}
for name,count in [('graph-tests',4),('engine-tests',152)]:
 command=read(raw/(name+'-command.json'));assert command['exit_code']==0 and command['source_patch_sha256']==state['patch_sha256']==pin(raw/(name+'.patch'))['sha256']
 counts=list(map(int,re.findall(r'test result: ok\\. (\\d+) passed',(raw/(name+'.log')).read_text())));assert counts==[count];tests[name]=dict(command=command,passed=count)
graph_build=read(raw/'graph-build-command.json');assert graph_build['exit_code']==0 and graph_build['source_patch_sha256']==state['patch_sha256']==pin(raw/'graph-build.patch')['sha256'];assert 'compiler/graph-tests' in excluded
assert 'scope_graph.rs' in (root/'source/benchmarks/mech-deflate/native-profile/scope_graph_tests.rs').read_text()
profile_path=root/'profile';profile_command=read(profile_path/'command.json');assert profile_command['flags']==flags and profile_command['binary_sha256']==control['sha256'] and state['control_source_commit'].startswith(profile_command['source_commit'])
assert read(profile_path/'process.json')['exit_code']==0 and read(profile_path/'output-check.json')==expected
for filename,pinned in expected.items():assert pin(profile_path/'output'/filename)==pinned
samples=read(profile_path/'samples.json');assert len(samples)==5 and all(row['exit_code']==0 for row in samples)
mapping=read(profile_path/'demangled-symbols.json');tables={};symbols=set()
for p in sorted(profile_path.glob('*-sample.txt')):
 text=p.read_text();symbols.update(re.findall(r'_R[A-Za-z0-9_]+',text));mapped=re.sub(r'_R[A-Za-z0-9_]+',lambda m:mapping[m.group(0)],text);assert mapped==p.with_name(p.stem+'-demangled.txt').read_text();parsed=[]
 for line in mapped[mapped.index('Sort by top of stack'):].splitlines()[1:]:
  match=re.match(r'\\s+(.*?)\\s+\\(in (.*?)\\)\\s+(\\d+)\\s*$',line)
  if match:parsed.append(dict(symbol=match[1],image=match[2],self_samples=int(match[3])))
  elif parsed:break
 assert parsed==read(p.with_name(p.stem+'-self.json'));tables[p.name]=[r for r in parsed if r['symbol']!='__ulock_wait'][:15]
assert set(mapping)==symbols and len(tables)==5
profile=dict(command=profile_command,samples=samples,completed_sample_files=len(tables),cpu_self_samples=tables,main_thread_waits_excluded=True)
summary=dict(source_commit=state['source_commit'],base_commit=state['base_commit'],control_source_commit=state['control_source_commit'],hardware=state['hardware'],decision='Retain scope-sized topology and definition-row storage in fresh current-visit validation; identical generated program bytes',candidate_patch_sha256=state['patch_sha256'],profile_settings=profile_settings,candidate_rebuild_seconds=build['seconds'],rebuild_scope='Observed locked/offline optimized-profile rebuild with existing Cargo caches. Excluded from Mech compilation timing; no matched cold-bootstrap comparison.',compiler_executable_bytes={v:excluded['compiler/'+v]['bytes'] for v in ['control','candidate']},rust_tests=tests,unique_engine_tests=152,duplicate_direct_graph_tests=4,diagnostic_control_profile=profile,scope=[
 'Eight serial fresh source-to-Object primary observations in ABBA then BAAB order, identical 60 runtime flags and compiler build profile. No cached Object or decoded-only substitute.',
 'Builds, tests, CPU sampling, screens, fixtures, hashing, copying and packet work do not overlap primary timing. All source, MBC, Object and complete metadata bytes match the qualified program in both screens and every primary observation; fourteen successful fixture pairs match all four files.',
 'Current-visit validation remains fresh on every call. Only topology scratch storage changes: a single ordinal scratch table serves per-call scope graphs, and only reachable scope nodes own edges and definition rows. The original DFS callback order, predecessor order, ready order and proof transfer remain. No definition, scope or execution authority is cached across calls.',
 'The original conservative definition-table admission calculation and limit remain unchanged. Grammar, language, checked errors, native scalar emission, runtime accounting, factory selection and backend optimization settings remain unchanged.',
 'Final source passes 152 engine native-artifact tests including four graph tests. Four standalone runs of those production graph tests are duplicate coverage, not four additional unique tests.',
 'The separate control CPU profile contains five requested one-second stage windows with raw and demangled stacks, commands, self tables, existing demangler source/pin and identical output bytes. Main-thread waits are excluded from CPU hotspot tables. Samples are not phase-exclusive elapsed or exact source-line attribution.',
 'Both subjects include retired-value compaction and its measured cost. Generated machine code and complete metadata are byte-identical. No new compressor-runtime timing campaign is claimed. Complete compilation remains above ten seconds.'
],**qualification)
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
'''
(packet/'replay.py').write_text(prefix+defs+end)
