from pathlib import Path
import json
repo=Path.cwd();packet=Path('/private/tmp/mech-index-facts-packet-20261114');s=json.loads((packet/'summary.json').read_text());q=s['qualified'];rows=[]
for key,label in [('compiler_seconds','Compiler, s'),('whole_process_seconds','Whole process, s'),('parse_seconds','Parse, s'),('frontend_seconds','Frontend, s'),('native_seconds','Native, s'),('canonical_lowering_seconds','Canonical lowering, s'),('preparation_seconds','Preparation, s'),('numeric_generation_seconds','Numeric generation, s'),('source_cfg_seconds','Source CFG, s'),('cleanup_including_compaction_seconds','Cleanup including compaction, s'),('compaction_seconds','Compaction, s'),('instructions','Retired instructions'),('max_rss_bytes','Peak RSS, bytes'),('peak_footprint_bytes','Peak footprint, bytes')]:
 v=q[key];fmt=(lambda x:f'{x:,}') if key in ['instructions','max_rss_bytes','peak_footprint_bytes'] else (lambda x:f'{x:.6f}')
 rows.append(f"| {label} | {fmt(min(v['control']))}–{fmt(max(v['control']))} | {fmt(min(v['candidate']))}–{fmt(max(v['candidate']))} | {-100*v['mean_reduction_fraction']:+.2f}% |")
report=f'''# Index-range definition facts: compilation qualification

Complete fresh level-12 compilation takes **18.691–18.903 seconds** on the Apple
M3 Air. Eight matched runs show **1.61% lower whole-process time, 1.79% lower
compiler time, 10.74% lower numeric-helper generation time and 2.06% fewer
instructions**. Source, MBC, Object and complete metadata bytes remain identical.
Memory is an adverse 0.0068% higher with overlapping ranges. The ten-second
compilation goal remains open.

`Indices::definition` previously constructed new same-plan descriptive facts on
every lookup. The range walk looks up each nonconstant definition during discovery
and again when finishing it, repeatedly rebuilding the complete definition table.
Each analyzer now owns one `NativeProgramFacts` scratch object borrowing exactly
its own immutable `CodePlan`. The table is still constructed on first demand and
is discarded with the analyzer. No facts survive a rewrite or different owner.

The entire `proves` method, supported-operation selection and scalar-range
arithmetic remain byte-for-byte unchanged. Unique-definition filtering,
conservative ambiguous/opaque/cyclic handling, constant enumeration and each
current minimum comparison keep their existing behavior. No new range, guard,
resource, shape, ownership or current-visit answer is cached. No execution
machinery is retired; grammar, language, checked errors, direct scalar emission,
admission limits, runtime accounting and backend settings retain their behavior.

Source `{s['source_commit']}`, parent `{s['base_commit']}`.
The frozen control comes from `{s['control_source_commit']}`; its production
source equals the documentation-only parent. Both subjects use the same opt-in
`compiler` profile, full fresh source-to-Object pipeline and 60 runtime flags.
Hardware: Apple M3 Air, 8 cores (4P+4E), 16 GB, macOS 26.2.

| Measurement | Control range (4 runs) | Candidate range (4 runs) | Mean change |
| --- | --- | --- | ---: |
'''+ '\n'.join(rows)+'''

Runs are serial control/candidate/candidate/control then
candidate/control/control/candidate. Both blocks improve compiler time (1.26%
and 2.31%). Every candidate compiler, process, native, helper-generation and
instruction observation falls below every control. Cleanup including compaction
is an adverse 1.34% higher; its ranges overlap. Both memory means are slightly
higher with overlapping ranges, so no memory saving is claimed. All observations
remain. These finite cohorts are descriptive, not population estimates. Both
subjects include SSA value compaction and its cost; native intervals are nested.

Builds, screens, fixtures, hashing, copying and archive work do not overlap primary
timing. The observed 273.188-second compiler rebuild uses existing Cargo caches,
is excluded from Mech compilation timing and is not a matched cold-bootstrap
comparison. Both screens and every primary output match the qualified program
byte for byte. Fourteen successful fixture pairs cover six array/enum programs
and eight checked scalar programs, matching all four files. Generated program
machine code and metadata remain identical; no new compressor-runtime timing
campaign is claimed.

This field-lifetime change is verified by the successful production compiler build,
complete compressor and fixture output checks, and static comparison of the exact
range/guard calculation body. No new Rust unit-suite run or CPU sampling campaign
is claimed. The prior 18 focused tests and bare runtime-only lint failures keep
their original source pins in the helper-liveness packet. This file is only used
by native code generation; the unrelated bare-feature failure is not rerun or
silenced here. The packet also retains a replay-source-pattern correction for
rustfmt line wrapping; compiler source and observations are unchanged by it.

The next recorded candidate is `numeric_exits::live_query`, which still loops over
all plan values and queries definitions even for unread values. A borrowed
same-plan inventory could avoid those repeated lookups, provided the original
first-demand validation behavior is preserved for empty/wanted subsets and
invalid unused definitions. No lookup/validation removal or saving from that
future work is applied or credited here.

The [compact result](../../benchmarks/mech-deflate/native-profile/index-facts-compile-apple-m3-20261114.json)
and [receipt](../../benchmarks/mech-deflate/native-profile/index-facts-compile-apple-m3-20261114.archive.json)
pin the complete [benchmark packet](../../benchmarks/mech-deflate/evidence/compiler-profile-20261114/README.md).
It includes source/base snapshots and patches, lazy-constructor source, commands,
flags, raw cohorts, outputs, corrections and pure offline replay. Compiler
executables are excluded and hash-pinned. Python 3.11+ replay needs no compilers,
benchmark execution, original scratch paths or external services.
'''
(repo/'docs/design/native-index-facts-compile-profile.md').write_text(report);(packet/'REPORT.md').write_text(report)
p=repo/'docs/design/native-compiler-process-profile.md';text=p.read_text().replace('**18.884–19.110 seconds per complete','**18.691–18.903 seconds per complete',1).replace('and [packed helper liveness](native-helper-liveness-compile-profile.md).','[packed helper liveness](native-helper-liveness-compile-profile.md),\nand [index-range definition facts](native-index-facts-compile-profile.md).',1)
text+='''
The latest [index-range facts qualification](native-index-facts-compile-profile.md)
keeps descriptive definitions for one exact analyzer lifetime, with lazy first
demand and unchanged range/guard calculations. Eight matched 60-flag compiles
take 18.691–18.903 seconds: process time falls 1.61%, helper generation 10.74%
and instructions 2.06%. Cleanup is an adverse 1.34% higher; memory is slightly
higher with overlapping ranges. All program and fixture output bytes match.
The fifteenth packet retains all observations and static source comparisons.
The ten-second target remains open.
''';p.write_text(text)
p=repo/'benchmarks/mech-deflate/EXPERIMENTS.md';text=p.read_text();pos=text.index('Paths below name reports **inside the external bundle**.')
text=text[:pos]+'''The [index-range definition-facts qualification](../../docs/design/native-index-facts-compile-profile.md)
retains one lazy descriptive facts object for each exact analyzer lifetime, with
byte-identical range calculations. Eight matched 60-flag runs take 18.691–18.903
seconds: 1.61% less process time, 10.74% less helper generation and 2.06% fewer
instructions. Cleanup is an adverse 1.34% higher; memory ranges overlap. All
compressor and fourteen fixture-pair outputs match. Its fifteenth packet retains
both screens, all observations, constructor/source comparisons and offline replay.
Earlier tests and feature-check failures keep their original source pins.

'''+text[pos:];p.write_text(text)
p=repo/'benchmarks/mech-deflate/native-profile/README.md';text=p.read_text();text+='''
The [index-range facts result](../../../docs/design/native-index-facts-compile-profile.md)
records fresh compilation at 18.691–18.903 seconds with identical generated bytes.
Its full archive and offline replay are in the
[compiler-profile evidence index](../evidence/compiler-profile-20261114/README.md).
''';p.write_text(text)
