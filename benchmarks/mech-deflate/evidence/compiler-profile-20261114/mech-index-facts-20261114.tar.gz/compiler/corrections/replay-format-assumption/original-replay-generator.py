from pathlib import Path
packet=Path('/private/tmp/mech-index-facts-packet-20261114');old=Path('/private/tmp/mech-local-traversal-packet-20261114/replay.py').read_text();prefix=old[:old.index('stage_fields=')].replace('qualified-scope-graph','qualified-helper-liveness').replace("and 'compiler/topology-tests' in excluded",'')
defs=old[old.index('stage_fields='):old.index('qualification=validate_cohort(')]
end='''qualification=validate_cohort(raw,flags,expected,{'control':control['sha256'],'candidate':build['binary_sha256']},'matches_current_control_output')
name='hosts/gpu/src/native_artifact/program/codegen/numeric_phase_bounds.rs';before=(root/'source-base'/name).read_text();after=(root/'source'/name).read_text();old_range=before[before.index('    pub(super) fn proves('):];new_range=after[after.index('    pub(super) fn proves('):];assert old_range==new_range
proof=read(raw/'source-equivalence-check.json');assert proof['range_proof_and_scalar_arithmetic_byte_identical'] and proof['range_proof_and_scalar_arithmetic_sha256']==hashlib.sha256(old_range.encode()).hexdigest()
facts=(root/'source/src/engine/src/native_artifact/program_facts.rs').read_text();assert 'definitions: OnceCell::new()' in facts and '.get_or_init(|| definitions(self.plan()))' in facts and proof['definition_inventory_initialized_lazily']
assert 'definition_facts: Option<NativeProgramFacts<' in after and 'self.definition_facts.as_ref()?.definition_sites(value)' in after
summary=dict(source_commit=state['source_commit'],base_commit=state['base_commit'],control_source_commit=state['control_source_commit'],hardware=state['hardware'],decision='Retain one lazy immutable definition-facts borrow for each index-range analyzer; identical generated program bytes',candidate_patch_sha256=state['patch_sha256'],profile_settings=profile_settings,candidate_rebuild_seconds=build['seconds'],rebuild_scope='Observed locked/offline optimized-profile rebuild with existing Cargo caches. Excluded from Mech compilation timing; no matched cold-bootstrap comparison.',compiler_executable_bytes={v:excluded['compiler/'+v]['bytes'] for v in ['control','candidate']},source_equivalence_checks=proof,scope=[
 'Eight serial fresh source-to-Object primary observations in ABBA then BAAB order, identical 60 runtime flags and compiler build profile. No cached Object or decoded-only substitute.',
 'Builds, screens, fixtures, CPU profiling, hashing, copying and packet work do not overlap primary timing. All source, MBC, Object and complete metadata bytes match the qualified program in both screens and every primary observation; fourteen successful fixture pairs match all four files.',
 'Only the compiler index-range analyzer lifetime changes. Each Indices owner borrows exactly its own immutable CodePlan and stores one NativeProgramFacts scratch object. Definition construction remains lazy on first lookup. No current guard, resource, range or visit answer is newly cached; objects are discarded with their analyzer.',
 'The complete proves method, supported-operation selection and scalar-range arithmetic remain byte-identical to the parent, checked against source snapshots. Unique-definition filtering, conservative ambiguous/opaque/cyclic handling and current minimum checks remain.',
 'Production compiler build and complete program/fixture output checks qualify this field-lifetime change. No new Rust unit-suite execution, CPU sampling or compressor-runtime latency campaign is claimed. Prior focused tests and the pre-existing bare runtime-only lint failures retain their source pins in the helper-liveness packet.',
 'Grammar, language, checked errors, direct scalar instructions, current shape/factory/visit/ownership proofs, finite admission, runtime accounting and backend settings remain unchanged. No execution machinery is retired.',
 'Both subjects retain SSA value compaction and its measured cost. Generated machine code and complete metadata are byte-identical. Complete compilation remains above ten seconds.'
],**qualification)
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
'''
(packet/'replay.py').write_text(prefix+defs+end)
