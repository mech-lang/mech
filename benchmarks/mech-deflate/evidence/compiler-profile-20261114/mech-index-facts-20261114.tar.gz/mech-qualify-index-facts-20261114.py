from pathlib import Path
import subprocess,sys,json
root=Path('/private/tmp/mech-index-facts-20261114')
for args in [
 ['mech-run-index-facts-20261114.py','control','control-screen'],
 ['mech-index-facts-fixtures-20261114.py'],
 ['mech-run-index-facts-cohort-20261114.py'],
]:
 subprocess.run([sys.executable,str(Path('/private/tmp')/args[0]),*args[1:]],check=True)
rows=json.loads((root/'cohort.json').read_text())
(root/'cohort-unexpanded.json').write_text(json.dumps(rows,indent=2)+'\n')
for label,block in [('first',rows[:4]),('second',rows[4:])]:
 (root/('cohort-'+label+'.json')).write_text(json.dumps(block,indent=2)+'\n')
subprocess.run([sys.executable,'/private/tmp/mech-analyze-index-facts-20261114.py'],check=True)
