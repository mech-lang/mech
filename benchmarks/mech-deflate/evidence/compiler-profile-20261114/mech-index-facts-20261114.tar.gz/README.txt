Index-range definition facts lifetime, Apple M3, 2026-11-14.
One NativeProgramFacts borrow now belongs to each exact Indices owner. The
inventory remains lazy and immutable; the range/guard calculations and scalar
arithmetic are byte-identical. No current proof answer, persistent validated flag,
cross-plan or cross-visit cache is added. This is a compiler-only lifetime change.
Eight serial ABBA/BAAB fresh full-source compiles and fourteen successful fixture
pairs use identical 60 flags/profile and reproduce all four generated files.
Both screens, all observations and adverse counters remain. Builds, screens,
fixtures, CPU profiling, hashing, copying and archive work do not overlap primary
timing. Compiler executables are excluded and pinned. No Rust unit-suite rerun,
new compressor-runtime latency or CPU sampling campaign is claimed. Earlier tests
and the pre-existing bare runtime-only lint failures retain their original source
pins in the prior packet. No execution machinery is retired. The full ten-second
goal remains open. This complete packet is published in benchmarks at the user's
request. Python 3.11+ replay is pure offline validation/reconstruction without
compilers, benchmarks, original scratch paths or external services.
