from pathlib import Path
import subprocess,os,time,json
root=Path('/private/tmp/mech-guard-seal-20261114')
cmd=['cargo','test','--locked','--offline','--release','-j2','--manifest-path','benchmarks/mech-deflate/native-profile/Cargo.toml','--test','ssa_builder']
start=time.perf_counter()
with (root/'ssa-tests.log').open('w') as log:p=subprocess.run(cmd,env=dict(os.environ,CARGO_TARGET_DIR='/private/tmp/mech-level12-compile-target',CARGO_INCREMENTAL='0'),stdout=log,stderr=subprocess.STDOUT)
record={'command':cmd,'exit_code':p.returncode,'seconds':time.perf_counter()-start,'CARGO_TARGET_DIR':'/private/tmp/mech-level12-compile-target','CARGO_INCREMENTAL':'0'}
(root/'ssa-test-command.json').write_text(json.dumps(record,indent=2)+'\n');print(record,flush=True);raise SystemExit(p.returncode)
