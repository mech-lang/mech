SSA ownership-join forwarding trial, Apple M3, 2026-11-14.
Decision: reject. The provisional source change was reverted before updating PR 973.
Matched fresh full source-to-Object ABBA compilation is faster, but the generated
main function changes and repeated runtime cohorts show slowdowns. Candidate
peak RSS is also higher, with nonoverlapping matched ranges. All adverse
observations, initial failed test oracle and superseded guard-only screen remain.
Primary comparisons enable the same complete 54 existing runtime flags, including
MECH_NORMALIZE_DEFAULTED_READ_SETUP. Earlier exploratory screens pin 53 flags and
are not pooled with the primary cohort. Source and MBC match between variants;
Object and metadata do not. Control Object exactly matches the previous qualified
fast runtime Object from the reduction-bound carry packet.
16 focused SSA tests pass, including deferred/unsealed origin and actual one-arm
assignment controls. These tests and 81-case output correctness do not establish
runtime nonregression; runtime timing rejects the trial.
Both linked workers share the maintained Heap runtime, pinned libmimalloc-sys
0.1.35 build with default features disabled, identical ported timing/validation
closure, compiler/runtime libraries and corpus. The allocator is built once for
both subjects; it is not claimed byte-identical to historical allocator objects.
81 smokes execute 486 checked observations plus disclosed startup warmups.
Primary timing uses four process groups and 12 alternating blocks/group for all
81 cases. Short-call blocks contain 256 or 32 observations as disclosed; large
calls contain one. Nine suspect/noisy cases are repeated with eight groups,
preserving the original cohort. Initial/final observations, 200 ms process
warmups and validation are excluded from primary samples. The separate reference
is the same control program, outside paired timing, not Roc or libdeflate.
Exact golden raw output, independent inflation, preserved input/output aliases,
capacity and six allocation/copy/zeroing metrics are checked for every worker
observation. This historical diagnostic boundary times the complete compact call,
Heap construction, output transfer and private cleanup, with prepared arguments;
ordinary exact resource admission/accounting/publication recovery is outside it.
Do not treat it as a production-entry latency benchmark or compare its absolute
values across independently linked historical cohorts.
Compiler bootstrap, runtime worker builds, allocator build, diagnostic screens,
correctness smokes and corpus recovery are outside primary timing. No builds,
tests, fixtures or CPU profiles overlap matched primary observations.
No grammar or language change. No backend opt-level reduction. Generated main
code/stack changes; no exact cause of runtime slowdown is established here.
Raw files remain outside source Git. Compiler/worker executables and build target
are represented by exact hashes/commands. Prior downloaded archives are pinned
in the exclusion inventory; selected recovered sources/corpus/verification data
are retained. Run python3 replay.py for pure offline reconstruction.
