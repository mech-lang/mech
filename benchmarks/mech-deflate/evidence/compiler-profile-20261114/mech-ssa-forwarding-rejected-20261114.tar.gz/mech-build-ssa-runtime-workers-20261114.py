from pathlib import Path
import json,subprocess,hashlib,os,time,shutil
root=Path('/private/tmp/mech-guard-seal-20261114');rows=[json.loads(l) for l in (root/'candidate-build.jsonl').read_text().splitlines()]
libs={}
for name in ['mech_gpu','mech_engine','serde','serde_json','miniz_oxide']:
 matches=[r for r in rows if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')==name and any(p.endswith('.rlib') for p in r['filenames'])];assert len(matches)==1
 libs[name]=next(p for p in matches[0]['filenames'] if p.endswith('.rlib'))
records=[json.loads(l) for l in (root/'runtime-allocator-build.jsonl').read_text().splitlines()];build=next(r for r in records if r.get('reason')=='build-script-executed' and 'libmimalloc-sys' in r['package_id']);allocator=Path(build['out_dir'])/'libmimalloc.a'
shutil.copy2(allocator,root/'runtime-worker/libmimalloc.a');allocator=root/'runtime-worker/libmimalloc.a'
pins={name:{'path':str(p),'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()} for name,p in libs.items()};pins['allocator']={'path':str(allocator),'sha256':hashlib.sha256(allocator.read_bytes()).hexdigest()};(root/'runtime-link-inputs.json').write_text(json.dumps(pins,indent=2)+'\n')
for variant in ['control','candidate']:
 obj=root/(variant+'-1')/'program.o';exe=root/'runtime-worker'/('worker-'+variant)
 cmd=['rustc','+nightly-2026-03-03','--edition=2024','-C','opt-level=3','-D','warnings','-L','dependency=/private/tmp/mech-level12-compile-target/release/deps',str(root/'runtime-worker/worker.rs'),'-o',str(exe)]
 for name,p in libs.items():cmd+=['--extern',name+'='+p]
 cmd+=['-C','link-arg='+str(allocator),'-C','link-arg='+str(obj)]
 start=time.perf_counter()
 with (root/('runtime-'+variant+'-build.stdout')).open('w') as out,(root/('runtime-'+variant+'-build.stderr')).open('w') as err:p=subprocess.run(cmd,stdout=out,stderr=err)
 record={'command':cmd,'exit_code':p.returncode,'seconds':time.perf_counter()-start,'object_sha256':hashlib.sha256(obj.read_bytes()).hexdigest(),'worker_source_sha256':hashlib.sha256((root/'runtime-worker/worker.rs').read_bytes()).hexdigest()}
 if p.returncode==0:record['binary_sha256']=hashlib.sha256(exe.read_bytes()).hexdigest()
 (root/('runtime-'+variant+'-build.json')).write_text(json.dumps(record,indent=2)+'\n');print(record,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
