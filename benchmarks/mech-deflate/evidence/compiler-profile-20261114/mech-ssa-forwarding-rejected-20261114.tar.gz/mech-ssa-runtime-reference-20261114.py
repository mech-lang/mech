import subprocess,sys,json
worker,metadata,cases,index=sys.argv[1:];count=15
p=subprocess.run([worker,metadata,cases,index,str(count)],input='N'*(count+2),capture_output=True,text=True,timeout=60)
print(p.stdout,end='');print(p.stderr,end='',file=sys.stderr);p.check_returncode();lines=p.stdout.splitlines();assert lines[0]=='SESSION_READY' and len(lines)==count+3
rows=[json.loads(line) for line in lines[1:]];selected=[r for r in rows if not r['warmup'] and not r['profile']];assert len(selected)==count
for r in selected:print('rep\tcontrol-baseline\t'+str(r['sample'])+'\t'+str(round(r['seconds']*1e9)))
