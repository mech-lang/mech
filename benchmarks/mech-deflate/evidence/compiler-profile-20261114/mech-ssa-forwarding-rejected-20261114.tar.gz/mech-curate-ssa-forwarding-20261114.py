from pathlib import Path
import subprocess,json,hashlib,shutil
repo=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech'); raw=Path('/private/tmp/mech-guard-seal-20261114'); packet=Path('/private/tmp/mech-ssa-forwarding-packet-20261114');assert not packet.exists()
source='d4efd4465c5a8689016abd5b42e16f73e475af63';base='416a4b40e0aaea46e523c0a96faafd12006cd885'
patch=subprocess.check_output(['git','diff','--binary',base,source],cwd=repo);assert patch==(raw/'candidate.patch').read_bytes()
state={'source_commit':source,'base_commit':base,'patch_sha256':hashlib.sha256(patch).hexdigest(),'hardware':'Apple M3 Air, 8 cores (4P+4E), 16 GB, macOS 26.2','decision':'Reject provisional SSA forwarding: faster compilation, repeated generated-program runtime slowdowns. Reverted before updating PR 973.','rustc':subprocess.check_output(['rustc','-Vv'],text=True),'cargo':subprocess.check_output(['cargo','-V'],text=True)}
(raw/'source-state.json').write_text(json.dumps(state,indent=2)+'\n');excluded=[]
for p in sorted(raw.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(raw)
 if rel in [Path('control'),Path('candidate'),Path('guard-only'),Path('runtime-worker/worker-control'),Path('runtime-worker/worker-candidate')] or rel.parts[0] in ['runtime-allocator-target','prior-runtime-download']:
  excluded.append({'path':str(rel),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()});continue
 dest=packet/'trial'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
(packet/'excluded-build-and-download-files.json').write_text(json.dumps(excluded,indent=2)+'\n');(packet/'source-change.patch').write_bytes(patch)
paths=subprocess.check_output(['git','diff','--name-only',base,source],cwd=repo,text=True).splitlines()
paths+=['benchmarks/mech-deflate/native-profile/'+name for name in ['Cargo.toml','Cargo.lock','compile_profile.rs','profile_compile.py']]
paths+=['benchmarks/mech-deflate/experiment.py','.cargo/config.toml','LICENSE','hosts/gpu/tests/fixtures/native/deflate-huffman-LICENSES.md','hosts/gpu/src/native_artifact/program/compiler.rs','hosts/gpu/src/native_artifact/program/compact/emit.rs']
for name in set(paths):
 dest=packet/'source'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(subprocess.check_output(['git','show',source+':'+name],cwd=repo))
for name in ['mech-build-guard-seal-20261114.py','mech-run-guard-seal-20261114.py','mech-run-guard-seal-cohort-20261114.py','mech-test-guard-seal-20261114.py','mech-prepare-ssa-runtime-20261114.py','mech-build-runtime-allocator-20261114.py','mech-build-ssa-runtime-workers-20261114.py','mech-smoke-ssa-runtime-20261114.py','mech-run-ssa-runtime-20261114.py','mech-repeat-ssa-runtime-20261114.py','mech-ssa-runtime-reference-20261114.py','mech-curate-ssa-forwarding-20261114.py']:
 shutil.copy2(Path('/private/tmp')/name,packet/name)
for name in ['mech-ssa-runtime-smoke-driver-20261114.log','mech-ssa-runtime-primary-driver-20261114.log','mech-ssa-runtime-repeat-driver-20261114.log']:
 shutil.copy2(Path('/private/tmp')/name,packet/name)
validation=packet/'validation';validation.mkdir()
for name in ['lexical-index-compile-apple-m3-20261114.json','lexical-index-compile-apple-m3-20261114.archive.json']:
 shutil.copy2(repo/'benchmarks/mech-deflate/native-profile'/name,validation/name)
shutil.copy2(Path('/private/tmp/mech-lexical-index-20261114/candidate-build.json'),validation/'control-build.json')
allocator=Path('/Users/cim310/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/libmimalloc-sys-0.1.35');shutil.copytree(allocator,packet/'allocator-source',ignore=shutil.ignore_patterns('.git','target'))
licenses=repo/'benchmarks/mech-deflate/.experiments/compile-peers-apple-m3-20261113/packet/licenses';shutil.copytree(licenses,packet/'licenses')
(packet/'README.txt').write_text('''SSA ownership-join forwarding trial, Apple M3, 2026-11-14.
Decision: reject. The provisional source change was reverted before updating PR 973.
Matched fresh full source-to-Object ABBA compilation is faster, but the generated
main function changes and repeated runtime cohorts show slowdowns. Candidate
peak RSS is also higher, with nonoverlapping matched ranges. All adverse
observations, initial failed test oracle and superseded guard-only screen remain.
Primary comparisons enable the same complete 54 existing runtime flags, including
MECH_NORMALIZE_DEFAULTED_READ_SETUP. Earlier exploratory screens pin 53 flags and
are not pooled with the primary cohort. Source and MBC match between variants;
Object and metadata do not. Control Object exactly matches the previous qualified
fast runtime Object from the reduction-bound carry packet.
16 focused SSA tests pass, including deferred/unsealed origin and actual one-arm
assignment controls. These tests and 81-case output correctness do not establish
runtime nonregression; runtime timing rejects the trial.
Both linked workers share the maintained Heap runtime, pinned libmimalloc-sys
0.1.35 build with default features disabled, identical ported timing/validation
closure, compiler/runtime libraries and corpus. The allocator is built once for
both subjects; it is not claimed byte-identical to historical allocator objects.
81 smokes execute 486 checked observations plus disclosed startup warmups.
Primary timing uses four process groups and 12 alternating blocks/group for all
81 cases. Short-call blocks contain 256 or 32 observations as disclosed; large
calls contain one. Nine suspect/noisy cases are repeated with eight groups,
preserving the original cohort. Initial/final observations, 200 ms process
warmups and validation are excluded from primary samples. The separate reference
is the same control program, outside paired timing, not Roc or libdeflate.
Exact golden raw output, independent inflation, preserved input/output aliases,
capacity and six allocation/copy/zeroing metrics are checked for every worker
observation. This historical diagnostic boundary times the complete compact call,
Heap construction, output transfer and private cleanup, with prepared arguments;
ordinary exact resource admission/accounting/publication recovery is outside it.
Do not treat it as a production-entry latency benchmark or compare its absolute
values across independently linked historical cohorts.
Compiler bootstrap, runtime worker builds, allocator build, diagnostic screens,
correctness smokes and corpus recovery are outside primary timing. No builds,
tests, fixtures or CPU profiles overlap matched primary observations.
No grammar or language change. No backend opt-level reduction. Generated main
code/stack changes; no exact cause of runtime slowdown is established here.
Raw files remain outside source Git. Compiler/worker executables and build target
are represented by exact hashes/commands. Prior downloaded archives are pinned
in the exclusion inventory; selected recovered sources/corpus/verification data
are retained. Run python3 replay.py for pure offline reconstruction.
''')
print(packet,flush=True)
