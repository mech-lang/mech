from pathlib import Path
import json,subprocess,time,statistics,hashlib,sys
root=Path('/private/tmp/mech-guard-seal-20261114'); repo=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech')
chosen=['prefix-natural-16384','prefix-natural-65535','prefix-natural-65536','prefix-natural-65537','prefix-repeated-32769','prefix-repeated-33027','prefix-repeated-1048576','heldout-mixed-131073','reymont-prefix-16384']
specs=root/'runtime-repeat-specs'; specs.mkdir(); out=root/'runtime-repeat';out.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in chosen:
 p=root/'runtime-specs'/(name+'.json');spec=json.loads(p.read_text());spec['groups']=8
 spec['repeat_provenance']={'original_spec_sha256':sha(p),'selection':'All original all-group >1.005 suspects, natural 16 KiB and 64 KiB neighbors, largest original noisy median and large repeated case, mixed heldout and reymont 16 KiB. All original results retained.','decision':'No automatic tolerance grants acceptance. This is a disclosed repeat, not a replacement.'}
 (specs/(name+'.json')).write_text(json.dumps(spec,indent=2)+'\n')
(root/'runtime-repeat-geometry.json').write_text(json.dumps({'cases':chosen,'groups':8,'blocks':12,'samples':'Identical to original per-case geometry','spec_pins':[{ 'path':str(p),'sha256':sha(p)} for p in sorted(specs.glob('*.json'))]},indent=2)+'\n')
rows=[]
for name in chosen:
 spec=specs/(name+'.json');cmd=[sys.executable,'benchmarks/mech-deflate/experiment.py','measure','--spec',str(spec),'--output',str(out/name)];print('START',name,flush=True);start=time.perf_counter()
 with (out/(name+'.driver.log')).open('w') as f:p=subprocess.run(cmd,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
 (out/(name+'.command.json')).write_text(json.dumps({'command':cmd,'exit_code':p.returncode,'seconds_outside_primary':time.perf_counter()-start},indent=2)+'\n')
 if p.returncode:print('FAILED',name,(out/(name+'.driver.log')).read_text()[-2000:],flush=True);raise SystemExit(p.returncode)
 groups=[];ratios=[]
 for i in range(8):
  result=json.loads((out/name/('group'+str(i))/'results.json').read_text());assert len(result['blocks'])==12 and 'failure' not in result
  paired=[b['after_over_before'] for b in result['blocks']];ratios+=paired;groups.append(statistics.median(paired))
 row={'case':name,'group_median_paired_block_ratios':groups,'median_paired_block_ratio':statistics.median(ratios),'timed_calls_each':96*json.loads(spec.read_text())['samples']};rows.append(row)
 (root/'runtime-repeat-results.json').write_text(json.dumps(rows,indent=2)+'\n'); print('RESULT',json.dumps(row),flush=True)
print('COMPLETE nine disclosed repeats',flush=True)
