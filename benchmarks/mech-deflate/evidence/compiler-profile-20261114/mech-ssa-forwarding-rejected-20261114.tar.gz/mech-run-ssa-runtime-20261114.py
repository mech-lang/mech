from pathlib import Path
import json,subprocess,sys,hashlib,time,math,statistics
root=Path('/private/tmp/mech-guard-seal-20261114');repo=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech');cases=json.loads((root/'runtime-cases.json').read_text());smokes={r['case']:r for r in json.loads((root/'runtime-smoke-results.json').read_text())};output=root/'runtime-primary';output.mkdir();specs=root/'runtime-specs';specs.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
workers={variant:root/'runtime-worker'/('worker-'+variant) for variant in ['control','candidate']}
metadata={variant:root/(variant+'-1')/'metadata.json' for variant in workers}
common_pins=[root/'runtime-cases.json',root/'runtime-worker/worker.rs',root/'runtime-worker/pinned_allocator.rs',root/'runtime-worker/libmimalloc.a',Path('/private/tmp/mech-ssa-runtime-reference-20261114.py'),*workers.values(),*metadata.values(),root/'control-1/program.o',root/'candidate-1/program.o']
rows=[]
# Predeclared full matrix: four process groups, 12 alternating blocks/group.
# Short calls need enough within-block samples; large inputs keep 48 paired
# blocks without turning warmups, validation or profiles into primary samples.
for index,case in enumerate(cases):
 samples=256 if case['input_bytes']<=7 else 32 if case['input_bytes']<=1024 else 1
 groups=4;blocks=12;count=blocks*samples;expected=dict(smokes[case['name']]['metrics'])
 expected.update({key:case[key] for key in ['input_bytes','prefix_bytes','raw_bytes','capacity']});expected.update(case=case['name'],exact_reference=True,independent_inflation=True,input_alias_unchanged=True,borrowed_output_alias_unchanged=True)
 commands={label:[str(workers[v]),str(metadata[v]),str(root/'runtime-cases.json'),str(index),str(count)] for label,v in [('before','control'),('after','candidate')]}
 pins=common_pins+[Path(case[key]) for key in ['input','prefix','expected']]
 spec={'case':case['name'],'commands':commands,'groups':groups,'blocks':blocks,'samples':samples,'pins':[{'path':str(p),'sha256':sha(p)} for p in pins],'expected':{label:expected for label in ['before','after']},'reference':{'command':[sys.executable,'/private/tmp/mech-ssa-runtime-reference-20261114.py',str(workers['control']),str(metadata['control']),str(root/'runtime-cases.json'),str(index)],'row_prefix':'rep\tcontrol-baseline\t','expected_observations':15,'nanoseconds_column':3,'role':'same control program, outside paired primary timing'},'scope':'Diagnostic complete compact execution including actual heap construction, output transfer and private cleanup. Prepared borrowed arguments and validation excluded identically. Both workers use the same maintained runtime and allocator. Each process performs a disclosed 200 ms startup warmup; initial/final observations are excluded.'}
 path=specs/(case['name']+'.json');path.write_text(json.dumps(spec,indent=2)+'\n')
# Freeze geometry for all 81 cases before the first measurement starts.
geometry={'cases':len(cases),'case_order':[c['name'] for c in cases],'groups':4,'blocks_per_group':12,'block_samples_rule':'256 for <=7 bytes; 32 for 8..1024 bytes; 1 for >1024 bytes','spec_pins':[{ 'path':str(p),'sha256':sha(p)} for p in sorted(specs.glob('*.json'))],'analysis':'Keep every group and observation. Inspect per-case paired block medians and all four process-group ratios. Do not retain a runtime regression merely because compilation improves. Repeat a suspect case as a disclosed separate cohort, preserving the original.'}
(root/'runtime-geometry.json').write_text(json.dumps(geometry,indent=2)+'\n')
for index,case in enumerate(cases):
 path=specs/(case['name']+'.json');dest=output/case['name'];cmd=[sys.executable,'benchmarks/mech-deflate/experiment.py','measure','--spec',str(path),'--output',str(dest)];start=time.perf_counter();print('START',index+1,case['name'],flush=True)
 with (output/(case['name']+'.driver.log')).open('w') as log:p=subprocess.run(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
 receipt={'command':cmd,'exit_code':p.returncode,'seconds_outside_primary':time.perf_counter()-start};(output/(case['name']+'.command.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 if p.returncode:print('FAILED',case['name'],(output/(case['name']+'.driver.log')).read_text()[-2500:],flush=True);raise SystemExit(p.returncode)
 results=[json.loads((dest/('group'+str(g))/'results.json').read_text()) for g in range(4)];group_ratios=[];ratios=[]
 for result in results:
  assert len(result['blocks'])==12 and 'failure' not in result
  paired=[b['after_over_before'] for b in result['blocks']];ratios+=paired;group_ratios.append(statistics.median(paired))
 row={'case':case['name'],'group_median_paired_block_ratios':group_ratios,'median_paired_block_ratio':statistics.median(ratios),'timed_calls_each':4*12*json.loads(path.read_text())['samples'],'suspect_all_groups_over_1_005':all(v>1.005 for v in group_ratios)};rows.append(row);(root/'runtime-primary-results.json').write_text(json.dumps(rows,indent=2)+'\n');print('RESULT',index+1,json.dumps(row),flush=True)
print('COMPLETE all 81 cases; every observation retained',flush=True)
