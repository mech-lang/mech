from pathlib import Path
import subprocess,json,time,hashlib
root=Path('/private/tmp/mech-guard-seal-20261114');cases=json.loads((root/'runtime-cases.json').read_text());output=root/'runtime-smokes';output.mkdir();records=[]
metrics=['payload_allocation_requests','requested_payload_bytes','initialized_bytes_copied','zeroed_bytes','peak_private_payload_bytes','nonreturned_private_bytes_at_return']
for index,case in enumerate(cases):
 rows={}
 for variant in ['control','candidate']:
  d=output/case['name']/variant;d.mkdir(parents=True);worker=root/'runtime-worker'/('worker-'+variant);metadata=root/(variant+'-1')/'metadata.json';cmd=[str(worker),str(metadata),str(root/'runtime-cases.json'),str(index),'1'];start=time.perf_counter()
  p=subprocess.run(cmd,input='NNN',text=True,capture_output=True,timeout=60)
  (d/'stdout.jsonl').write_text(p.stdout);(d/'stderr.log').write_text(p.stderr)
  record={'command':cmd,'exit_code':p.returncode,'seconds_outside_primary':time.perf_counter()-start,'binary_sha256':hashlib.sha256(worker.read_bytes()).hexdigest(),'timing_excluded_from_primary':True};(d/'command.json').write_text(json.dumps(record,indent=2)+'\n')
  assert p.returncode==0,(case['name'],variant,p.stderr[-1600:]);lines=p.stdout.splitlines();assert lines[0]=='SESSION_READY' and len(lines)==4,(case['name'],variant,lines[:2]);observations=[json.loads(line) for line in lines[1:]]
  assert p.stderr.endswith('CLEANUP bytes=0 nodes=0\n') and 'WARMUP calls=' in p.stderr
  for r in observations:
   for key in ['exact_reference','independent_inflation','input_alias_unchanged','borrowed_output_alias_unchanged']:assert r[key]
   assert r['case']==case['name'] and all(r[key]==case[key] for key in ['input_bytes','prefix_bytes','raw_bytes','capacity'])
  rows[variant]={key:observations[1][key] for key in metrics}
  assert all({key:r[key] for key in metrics}==rows[variant] for r in observations)
 assert rows['control']==rows['candidate'],(case['name'],rows)
 records.append({'case':case['name'],'control_and_candidate_metrics_identical':True,'metrics':rows['control'],'checked_observations':6});(root/'runtime-smoke-results.json').write_text(json.dumps(records,indent=2)+'\n');print(index+1,case['name'],'six checked calls, metrics match',flush=True)
assert len(records)==81;print('PASS 486 checked calls plus disclosed warmups; 81 cases, both variants, all six payload metrics identical',flush=True)
