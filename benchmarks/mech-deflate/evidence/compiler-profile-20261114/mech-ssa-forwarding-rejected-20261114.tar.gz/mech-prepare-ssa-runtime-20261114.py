from pathlib import Path
import json,hashlib,tarfile,shutil,zlib,re
root=Path('/private/tmp/mech-guard-seal-20261114');source=root/'runtime-source-discovery';corpus=root/'runtime-corpus';corpus.mkdir()
old={row['name']:row for row in json.loads((source/'r224-fixture-bytes.json').read_text())};cases=json.loads((source/'r270-fixtures.json').read_text());assert len(cases)==81
archive=root/'prior-runtime-download/r248-work-ledger-prefix-scaling-bd9447eb91f2.tar.gz';pins=[]
with tarfile.open(archive) as t:
 manifest=json.loads(t.extractfile('evidence/manifest.json').read())
 # Each extracted input is checked against the current 81-case descriptor and
 # the archive itself is already pinned by its full public SHA-256.
 for original in cases:
  row=dict(original);name=row['name'];assert re.fullmatch(r'[a-z0-9-]+',name);folder=corpus/name;folder.mkdir()
  if name in old:
   data={key:bytes.fromhex(old[name][key+'_hex']) for key in ['input','prefix','expected']}
  else:
   data={key:t.extractfile('evidence/prefix-fixtures/'+name+'/'+filename).read() for key,filename in [('input','input.input'),('prefix','output.prefix'),('expected','expected.deflate')]}
  for key,b in data.items():
   filename={'input':'input','prefix':'prefix','expected':'expected.deflate'}[key];p=folder/filename;p.write_bytes(b);row[key]=str(p)
   digest=hashlib.sha256(b).hexdigest()
   if key+'_sha256' in row:assert digest==row[key+'_sha256'],(name,key)
   pins.append({'case':name,'kind':key,'path':str(p),'bytes':len(b),'sha256':digest})
  assert len(data['input'])==row['input_bytes'] and len(data['prefix'])==row['prefix_bytes']
  assert data['expected'].startswith(data['prefix']) and len(data['expected'])-len(data['prefix'])==row['raw_bytes']
  assert zlib.decompress(data['expected'][len(data['prefix']):],-15)==data['input']
  original.clear();original.update(row)
 for name in ['evidence/corpus-provenance-discrepancy.json','evidence/frozen-streams/natural-source.json','evidence/prepare-prefix-fixtures.py']:
  (source/('r248-'+Path(name).name)).write_bytes(t.extractfile(name).read())
(root/'runtime-cases.json').write_text(json.dumps(cases,indent=2)+'\n');(root/'runtime-corpus-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
worker=root/'runtime-worker';worker.mkdir()
s=(source/'r224-mech-worker.rs').read_text();s=s.replace('#[path = "array-runtime.rs"]\nmod arrays;','use mech_gpu::native_artifact::compact_runtime as arrays;').replace('#[path = "/private/tmp/mech-child-prepayment-round163-20261105/pinned_allocator.rs"]','#[path = "pinned_allocator.rs"]')
s=s.replace('    println!("CASE_READY\\t{}", case.name);\n    std::io::stdout().flush().unwrap();\n','')
s=s.replace('        let mut sample=0usize;', '''        let warm_start=Instant::now();let mut warm_calls=0u64;
        while warm_start.elapsed()<std::time::Duration::from_millis(200) {
            drop(execute(usize::MAX));warm_calls+=1;
        }
        eprintln!("WARMUP calls={warm_calls} seconds={}",warm_start.elapsed().as_secs_f64());
        println!("SESSION_READY");std::io::stdout().flush().unwrap();
        let mut sample=0usize;''')
s=s.replace('    println!("CASE_DONE\\t{}", case.name);','    eprintln!("CLEANUP bytes=0 nodes=0");')
s=s[:s.index('fn main() {')]+'''fn main() {
    let args=std::env::args().skip(1).collect::<Vec<_>>();assert_eq!(args.len(),4);
    let metadata:serde_json::Value=serde_json::from_slice(&std::fs::read(&args[0]).unwrap()).unwrap();
    let cases:Vec<Case>=serde_json::from_slice(&std::fs::read(&args[1]).unwrap()).unwrap();
    let index:usize=args[2].parse().unwrap();let samples:usize=args[3].parse().unwrap();
    let mut reader=std::io::BufReader::new(std::io::stdin());
    run(&cases[index],samples,&metadata,&mut reader);
}
'''
(worker/'worker.rs').write_text(s)
s=(source/'r270-pinned_allocator.rs').read_text().replace('use the exact mimalloc object linked by the pinned reference host.','use the same pinned mimalloc build for control and candidate.')
(worker/'pinned_allocator.rs').write_text(s)
# Exact timing/validation closure stays byte-identical through the port.
def closure(s):return s[s.index('    let mut execute=|sample:usize| {'):s.index('\n        let mut sample=0usize;') if '\n        let mut sample=0usize;' in s else s.index('\n        let warm_start=Instant::now();')]
# The closure's body ends before the newly inserted startup warmup.
original=(source/'r224-mech-worker.rs').read_text();a=original[original.index('    let mut execute=|sample:usize| {'):original.index('\n        let mut sample=0usize;')];b=s if False else (worker/'worker.rs').read_text();b=b[b.index('    let mut execute=|sample:usize| {'):b.index('\n        let warm_start=Instant::now();')];assert a==b
(root/'runtime-worker-port.json').write_text(json.dumps({'original_worker_source_sha256':hashlib.sha256(original.encode()).hexdigest(),'worker_source_sha256':hashlib.sha256((worker/'worker.rs').read_bytes()).hexdigest(),'timing_and_validation_closure_byte_identical':True,'heap':'maintained mech_gpu::native_artifact::compact_runtime','allocator':'libmimalloc-sys 0.1.35, default features disabled, shared compiled archive for both subjects','protocol':'single-case session adapted to maintained experiment.py measure; 200 ms disclosed startup warmup; initial/final observations excluded','cases':len(cases),'input_and_reference_files_checked':len(pins),'all_references_independently_inflate':True,'source_and_algorithm_unchanged':True,'scope':'Diagnostic compact call and actual heap construction, final output ownership transfer and private cleanup, with prepared borrowed arguments. Ordinary resource admission is outside this historical benchmark boundary.'},indent=2)+'\n')
print('81 cases restored, all hashes and independent inflations verified')
