from pathlib import Path
import subprocess,os,json,time
root=Path('/private/tmp/mech-guard-seal-20261114');manifest=root/'runtime-allocator/Cargo.toml';cmd=['cargo','build','--offline','--release','-j2','--manifest-path',str(manifest),'--message-format=json'];start=time.perf_counter();target=root/'runtime-allocator-target'
with (root/'runtime-allocator-build.jsonl').open('w') as out,(root/'runtime-allocator-build.stderr').open('w') as err:p=subprocess.run(cmd,env=dict(os.environ,CARGO_TARGET_DIR=str(target),CARGO_INCREMENTAL='0'),stdout=out,stderr=err)
record={'command':cmd,'exit_code':p.returncode,'seconds':time.perf_counter()-start,'CARGO_TARGET_DIR':str(target),'CARGO_INCREMENTAL':'0'};(root/'runtime-allocator-build.json').write_text(json.dumps(record,indent=2)+'\n');print(record);raise SystemExit(p.returncode)
