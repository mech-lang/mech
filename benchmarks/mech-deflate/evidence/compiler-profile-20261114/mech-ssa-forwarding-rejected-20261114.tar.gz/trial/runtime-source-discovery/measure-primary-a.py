from pathlib import Path
from itertools import permutations
import hashlib,json,math,os,select,statistics,subprocess,time,sys,gzip
r=Path(__file__).resolve().parent;b=Path('/private/tmp/mech-matched-comparison-round224-20261109');out=r/'primary-a';out.mkdir(exist_ok=True);fixtures=r/'fixtures.json';cases=json.loads(fixtures.read_text());parent=Path('/private/tmp/mech-isolated-thread-round268-20261110');retained=Path('/private/tmp/mech-loop-thread-combination-round246-20261109');metadata=parent/'full-image/original/metadata.json';variants={'before':[str(parent/'mech-worker'),str(metadata),str(fixtures)],'after':['/private/tmp/mech-wide-tier-round270-20261110/mech-worker','/private/tmp/mech-wide-tier-round270-20261110/full-image/original/metadata.json',str(fixtures)],'reference': ['/private/tmp/mech-matched-comparison-round224-20261109/reference-worker',str(metadata),str(fixtures)]}
assert not[p for p in subprocess.check_output(['ps','-Ao','comm='],text=True).splitlines()if Path(p.strip()).name in {'cargo','rustc','clang','roc','producer','candidate-tests','tests','census-tests','census-worker','reference-census-worker','xctrace','input-census-worker','path-worker','inspect-latch'}]
started=[]
class Worker:
 def __init__(self,name):
  self.name=name;self.buffer=b'';self.log=(out/(name+'.stdout')).open('ab');self.err=(out/(name+'.stderr')).open('ab');self.p=subprocess.Popen(variants[name],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.err);started.append(self);assert self.line()=='SESSION_READY'
 def line(self):
  while b'\n'not in self.buffer:
   if not select.select([self.p.stdout],[],[],60)[0]:raise TimeoutError(('external response watchdog',self.name))
   z=os.read(self.p.stdout.fileno(),65536);assert z,(self.name,self.p.poll());self.buffer+=z
  z,self.buffer=self.buffer.split(b'\n',1);self.log.write(z+b'\n');self.log.flush();return z.decode()
 def send(self,s):self.p.stdin.write(s.encode());self.p.stdin.flush()
 def close(self):self.send('Q\n');self.p.stdin.close();assert self.p.wait()==0;self.log.close();self.err.close()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();pins={k:{'command':v,'binary_sha256':sha(v[0])}for k,v in variants.items()};pins['object_sha256']=sha(Path('/private/tmp/mech-wide-tier-round270-20261110/full-image/original/object.o'));expected_inputs=json.loads((r/'source-pins.json').read_text());assert Path(variants['after'][0])==r/'mech-worker';assert Path(variants['after'][1])==r/'full-image/original/metadata.json';assert pins['object_sha256']==expected_inputs['candidate_object']['sha256'];assert pins['before']['binary_sha256']!=pins['after']['binary_sha256'];assert not list(out.glob('*/observations.json*')) or (out/'summary.json').exists();assert pins['after']['binary_sha256']==expected_inputs['candidate_worker']['sha256'];assert pins['after']['binary_sha256']==json.loads((r/'mech-worker-build.json').read_text())['binary_sha256'];(out/'pins.json').write_text(json.dumps(pins,indent=2)+'\n');summary=json.loads((out/'summary.json').read_text())if(out/'summary.json').exists()else[]
try:
 ws={s:Worker(s)for s in variants}
 for index in range(len(cases)):
  c=cases[index];name=c['name'];
  if any(v['case']==name for v in summary):continue
  folder=out/name;folder.mkdir();historical=None
  n=512 if name in ['empty','one-stored','seven-stored-prefix']else(64 if c['input_bytes']<=1024 else 1);count=n*24;observed={s:[]for s in ws};warmups={};blocks=[]
  for side,w in ws.items():w.send(f'C\t{index}\t{count}\n');assert w.line()=='CASE_READY\t'+name
  order=list(ws)if index%2==0 else list(reversed(ws))
  for s in order:
   ws[s].send('W');warm=ws[s].line().split('\t');assert warm[:2]==['WARMUP_DONE',name]and int(warm[2])>0 and float(warm[3])>=.2;warmups[s]={'calls':int(warm[2]),'wall_seconds':float(warm[3])}
  def valid(v):assert v['case']==name and v['exact_reference']and v['independent_inflation']and v['input_alias_unchanged']and v['borrowed_output_alias_unchanged'];assert all(v[k]==c[k]for k in ['input_bytes','prefix_bytes','raw_bytes','capacity'])
  for s,w in ws.items():w.send('N');v=json.loads(w.line());valid(v);assert v['warmup'];observed[s].append(v)
  for block,order in enumerate(list(permutations(variants))*4):
   means={};medians={}
   for s in order:
    ws[s].send('N'*n);values=[json.loads(ws[s].line())for _ in range(n)]
    for v in values:valid(v);assert not v['warmup']and not v['profile']
    observed[s]+=values;means[s]=statistics.mean(v['seconds']for v in values);medians[s]=statistics.median(v['seconds']for v in values)
   blocks.append({'block':block,'order':order,'means':means,'medians':medians})
  for s,w in ws.items():w.send('N');v=json.loads(w.line());valid(v);assert v['profile'];observed[s].append(v);assert w.line()=='CASE_DONE\t'+name
  med={s:statistics.median(v['seconds']for v in a if not v['warmup']and not v['profile'])for s,a in observed.items()};bm={s:statistics.median(v['means'][s]for v in blocks)for s in ws};quant={s:{str(q):sorted(v['seconds']for v in a if not v['warmup']and not v['profile'])[int((count-1)*q)]for q in [.05,.5,.95]}for s,a in observed.items()};row={'case':name,'input_bytes':c['input_bytes'],'retained_samples_each':count,'block_size':n,'blocks':24,'warmups':warmups,'medians':med,'median_block_means':bm,'quantiles':quant,'multiples_of_reference':{k:v/med['reference']if med['reference']else None for k,v in med.items()},'after_over_before':med['after']/med['before'],'blockmean_after_over_before':bm['after']/bm['before'],'original_1_05_gate':med['after']<=1.05*med['before'],'blockmean_1_05_gate':bm['after']<=1.05*bm['before'],'historical_reference_seconds':historical,'fixed_level_12_both':True,'runtime_input_both':True,'borrowed_output_both':True,'validation_same_library_and_placement':True,'clock_same_pinned_Rust_Instant':True,'existing25_case':index<25,'controlled_prefix':index>=25,'family':c.get('family'),'eight_byte_reference_ceiling':med['after']<=med['reference'] if name=='eight-literals' else None,'compiler_change':True,'algorithm_change':False}
  (folder/'observations.json.gz').write_bytes(gzip.compress((json.dumps({'blocks':blocks,'observations':observed},indent=2)+'\n').encode(),compresslevel=6,mtime=0));(folder/'summary.json').write_text(json.dumps(row,indent=2)+'\n');summary.append(row);(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(row),flush=True)
 for w in ws.values():w.close()
 assert all((out/(name+'.stderr')).read_text().endswith('CLEANUP private_payload_bytes=0 live_owner_records=0\n')for name in ['before','after']);assert(out/'reference.stderr').read_text().endswith('CLEANUP reference_input_and_output_roots_released=1\n')
 (out/'complete.json').write_text(json.dumps({'cases':len(cases),'original_cases':25,'controlled_prefix_cases':len(cases)-25,'all_outputs_exact_and_independent_inflate':True,'warmups_200ms_each':True,'alternating_balanced_order':True,'clock_same':True,'validation_matched':True,'ownership_mode':'borrowed prepared output preserved on both','guarded_assertion_length_floors':True,'direct_vector_truth_branch':True,'whole_phase_capacity':True},indent=2)+'\n')
finally:
 for w in started:
  if w.p.poll()is None:w.p.terminate();w.p.wait()
  w.log.close();w.err.close()
