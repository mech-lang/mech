from pathlib import Path
import hashlib
import json
import re
import shutil

r=Path(__file__).resolve().parent
base=Path('/private/tmp/mech-isolated-thread-round268-20261110')
old_parent='/private/tmp/mech-border-loops-round264-20261110'
for name in ('measure-primary-a.py','measure-primary-b.py','measure-cpu.py','measure-memory.py'):
    text=(base/name).read_text().replace(str(base),str(r)).replace(old_parent,str(base))
    (r/name).write_text(text)
for name in ('analyze-primary.py','analyze-counters.py'):
    text=(base/name).read_text().replace("'round':268","'round':270").replace("unchanged from R264","unchanged from R268")
    (r/name).write_text(text)
text=(base/'profile-border-pcs.py').read_text()
text=text.replace(old_parent,str(base))
text=text.replace("'prefix-repeated-32768', 'prefix-periodic-32768', 'eight-literals'",
                  "'prefix-repeated-33027', 'prefix-periodic-32768', 'eight-literals'")
text=text.replace("'tests', 'worker', 'producer', 'reference'",
                  "'tests', 'worker', 'producer', 'reference', 'libdeflate-worker', 'after-cpu', 'after-memory'")
(r/'profile-border-pcs.py').write_text(text)
for name in ('prepare-profile.py','analyze-profile.py'):
    shutil.copyfile(base/name,r/name)

for n in ('candidate-qualified-tests','all81-original-smokes','all81-decoded-smokes','matching-controls',
          'path-controls','alias-controls','decoded-exact','focused-wide-tests','frontier-screen'):
    assert json.loads((r/(n+'.json')).read_text())['exit']==0,n
assert re.search(r'728 passed; 0 failed; 0 ignored; 0 measured; 7 filtered out',
                 (r/'candidate-qualified-tests.stdout').read_text())
for form in ('original','decoded'):
    data=json.loads((r/f'all81-{form}-smokes-data.json').read_text())
    assert data['cases']==81 and data['correct_calls']==162
    assert all(all(row[k] for k in ('exact_reference','independent_inflation','input_alias_unchanged',
                                    'borrowed_output_alias_unchanged'))
               for row in data['observations'])
for name in ('tiered-check','tiered-alias-check'):
    data=json.loads((r/'witnesses'/f'{name}-witness-summary.json').read_text())
    assert data['original_decoded_exact'] and data['forms']==2
matches=json.loads((r/'matching-qualification.json').read_text())
assert matches['native_calls']==5788 and matches['final_private_payload_bytes']==0
image=r/'full-image/original'
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
emission=json.loads((r/'tiered/emission.json').read_text())['original']
for name in ('object.o','metadata.json'):
    assert sha(image/name)==sha(r/'full-image/decoded'/name)==emission[name]
screen=json.loads((r/'screen-counted-tiers/pins.json').read_text())
assert sha(r/'mech-worker')==screen['actors']['tiered']['binary_sha256']
assert sha(image/'metadata.json')==screen['actors']['tiered']['metadata_sha256']
pinned=json.loads((base/'source-pins.json').read_text())
pinned['candidate_object']={'sha256':sha(image/'object.o')}
pinned['candidate_worker']={'sha256':sha(r/'mech-worker')}
pinned['retained_object']={'sha256':sha(base/'full-image/original/object.o')}
pinned['retained_worker']={'sha256':sha(base/'mech-worker')}
(r/'source-pins.json').write_text(json.dumps(pinned,indent=2)+'\n')
print('Qualified 728 tests, 324 full smokes, 5,788 matching calls and 98 path/alias witnesses.')
