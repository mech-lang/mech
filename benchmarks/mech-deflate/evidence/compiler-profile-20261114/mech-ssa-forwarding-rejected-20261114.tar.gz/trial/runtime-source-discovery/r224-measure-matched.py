from pathlib import Path
from itertools import permutations
import hashlib,json,math,os,select,statistics,subprocess,time
r=Path(__file__).resolve().parent;b=Path('/private/tmp/mech-matrix-fallback-round223-20261109');out=r/'primary';out.mkdir(exist_ok=True);fixtures=r/'fixtures.json';cases=json.loads(fixtures.read_text());metadata=b/'optimized-image/original/metadata.json';variants={'mech':[str(r/'mech-worker'),str(metadata),str(fixtures)],'reference':[str(r/'reference-worker'),str(metadata),str(fixtures)]}
assert not[p for p in subprocess.check_output(['ps','-Ao','comm='],text=True).splitlines()if Path(p.strip()).name in {'cargo','rustc','clang','roc','producer'}]
started=[]
class Worker:
 def __init__(self,name):
  self.name=name;self.buffer=b'';self.log=(out/(name+'.stdout')).open('wb');self.err=(out/(name+'.stderr')).open('wb');self.p=subprocess.Popen(variants[name],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.err);started.append(self);assert self.line()=='SESSION_READY'
 def line(self):
  while b'\n'not in self.buffer:
   if not select.select([self.p.stdout],[],[],60)[0]:raise TimeoutError(('external response watchdog',self.name))
   z=os.read(self.p.stdout.fileno(),65536);assert z,(self.name,self.p.poll());self.buffer+=z
  z,self.buffer=self.buffer.split(b'\n',1);self.log.write(z+b'\n');self.log.flush();return z.decode()
 def send(self,s):self.p.stdin.write(s.encode());self.p.stdin.flush()
 def close(self):self.send('Q\n');self.p.stdin.close();assert self.p.wait()==0;self.log.close();self.err.close()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();pins={k:{'command':v,'binary_sha256':sha(v[0])}for k,v in variants.items()};pins['object_sha256']=sha(b/'optimized-image/original/object.o');(out/'pins.json').write_text(json.dumps(pins,indent=2)+'\n');overrides={v['case']:v for v in json.loads((b/'reference-restoration.json').read_text())};summary=[]
try:
 ws={s:Worker(s)for s in variants}
 for index in [19,10,16,15,9,3,18]+[i for i in range(len(cases))if i not in [19,10,16,15,9,3,18]]:
  c=cases[index];name=c['name'];folder=out/name;folder.mkdir();historical=None
  if index<20:
   ref=overrides.get(name,{}).get('reference',c['reference']);expected=overrides.get(name,{}).get('sha256',c['reference_sha256']);assert sha(ref)==expected
   p=subprocess.run([ref,'12'],capture_output=True,text=True);(folder/'historical-reference.stdout').write_text(p.stdout);(folder/'historical-reference.stderr').write_text(p.stderr);p.check_returncode();reps=[l.split('\t')for l in p.stdout.splitlines()if l.startswith('rep\troc-deflate\t')];assert len(reps)==256;assert all(int(v[4])==c['raw_bytes']for v in reps);historical=statistics.median(int(v[3])for v in reps)/1e9
  n=512 if name in ['empty','one-stored','seven-stored-prefix']else(64 if c['input_bytes']<=1024 else 1);count=n*24;observed={s:[]for s in ws};warmups={};blocks=[]
  for side,w in ws.items():w.send(f'C\t{index}\t{count}\n');assert w.line()=='CASE_READY\t'+name
  order=list(ws)if index%2==0 else list(reversed(ws))
  for s in order:
   ws[s].send('W');warm=ws[s].line().split('\t');assert warm[:2]==['WARMUP_DONE',name]and int(warm[2])>0 and float(warm[3])>=.2;warmups[s]={'calls':int(warm[2]),'wall_seconds':float(warm[3])}
  def valid(v):assert v['case']==name and v['exact_reference']and v['independent_inflation']and v['input_alias_unchanged']and v['borrowed_output_alias_unchanged'];assert all(v[k]==c[k]for k in ['input_bytes','prefix_bytes','raw_bytes','capacity'])
  for s,w in ws.items():w.send('N');v=json.loads(w.line());valid(v);assert v['warmup'];observed[s].append(v)
  for block,order in enumerate(list(permutations(variants))*12):
   means={};medians={}
   for s in order:
    ws[s].send('N'*n);values=[json.loads(ws[s].line())for _ in range(n)]
    for v in values:valid(v);assert not v['warmup']and not v['profile']
    observed[s]+=values;means[s]=statistics.mean(v['seconds']for v in values);medians[s]=statistics.median(v['seconds']for v in values)
   blocks.append({'block':block,'order':order,'means':means,'medians':medians})
  for s,w in ws.items():w.send('N');v=json.loads(w.line());valid(v);assert v['profile'];observed[s].append(v);assert w.line()=='CASE_DONE\t'+name
  med={s:statistics.median(v['seconds']for v in a if not v['warmup']and not v['profile'])for s,a in observed.items()};bm={s:statistics.median(v['means'][s]for v in blocks)for s in ws};quant={s:{str(q):sorted(v['seconds']for v in a if not v['warmup']and not v['profile'])[int((count-1)*q)]for q in [.05,.5,.95]}for s,a in observed.items()};row={'case':name,'input_bytes':c['input_bytes'],'retained_samples_each':count,'block_size':n,'blocks':24,'warmups':warmups,'medians':med,'median_block_means':bm,'quantiles':quant,'matched_mech_over_reference':med['mech']/med['reference']if med['reference']else None,'matched_blockmean_ratio':bm['mech']/bm['reference'],'historical_reference_seconds':historical,'same_mech_over_historical_reference':med['mech']/historical if historical else None,'fixed_level_12_both':True,'runtime_input_both':True,'borrowed_output_both':True,'validation_same_library_and_placement':True,'clock_same_pinned_Rust_Instant':True,'original20_case':index<20,'compiler_or_algorithm_change':False}
  (folder/'observations.json').write_text(json.dumps({'blocks':blocks,'observations':observed},indent=2)+'\n');(folder/'summary.json').write_text(json.dumps(row,indent=2)+'\n');summary.append(row);(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(row),flush=True)
 for w in ws.values():w.close()
 assert(out/'mech.stderr').read_text().endswith('CLEANUP private_payload_bytes=0 live_owner_records=0\n');assert(out/'reference.stderr').read_text().endswith('CLEANUP reference_input_and_output_roots_released=1\n')
 (out/'complete.json').write_text(json.dumps({'cases':len(cases),'original_cases':20,'heldout_cases':len(cases)-20,'all_outputs_exact_and_independent_inflate':True,'warmups_200ms_each':True,'alternating_balanced_order':True,'clock_same':True,'validation_matched':True,'ownership_mode':'borrowed prepared output preserved on both','native_compressor_source_object_unchanged':True},indent=2)+'\n')
finally:
 for w in started:
  if w.p.poll()is None:w.p.terminate();w.p.wait()
  w.log.close();w.err.close()
