from pathlib import Path
import hashlib
import json
import subprocess

r = Path(__file__).resolve().parent
streams = r / 'frozen-streams'
old = {v['name']: v for v in json.loads((r / 'fixtures.json').read_text())}
length = 1_048_576
state = 0x12345678
noise = bytearray()
for _ in range(length):
    state ^= (state << 13) & 0xffffffff
    state ^= state >> 17
    state ^= (state << 5) & 0xffffffff
    state &= 0xffffffff
    noise.append(state >> 24)
(streams / 'random.input').write_bytes(noise)
periodic = Path(old['33027-periodic-window']['input']).read_bytes()
period = next((n for n in range(1, 1025) if periodic == (periodic[:n] * ((len(periodic) + n - 1) // n))[:len(periodic)]), None)
assert period is not None, 'Review the existing periodic generator before extending it'
seed = periodic[:period]
(streams / 'periodic.input').write_bytes((seed * ((length + period - 1) // period))[:length])
repeated = Path(old['repeated-32769']['input']).read_bytes()
assert len(set(repeated)) == 1
(streams / 'repeated.input').write_bytes(repeated[:1] * length)
sizes = [1024, 4096, 8192, 16384, 32767, 32768, 32769, 33027, 65535, 65536, 65537, 131072, 262144, 1048576]
reference = Path('/private/tmp/mech-matched-comparison-round224-20261109/reference-worker')
rows = []
families = []
root = r / 'prefix-fixtures'
root.mkdir(exist_ok=False)
for family in ['natural', 'random', 'periodic', 'repeated']:
    stream = (streams / (family + '.input')).read_bytes()
    assert len(stream) == length
    families.append(dict(family=family, bytes=len(stream), sha256=hashlib.sha256(stream).hexdigest(), generator='official same-stream corpus prefix' if family == 'natural' else 'xorshift32(0x12345678), high byte per step' if family == 'random' else f'existing periodic seed, period{period}' if family == 'periodic' else f'existing single repeated byte{repeated[0]}'))
    for size in sizes:
        name = f'prefix-{family}-{size}'
        folder = root / name
        folder.mkdir()
        data = stream[:size]
        (folder / 'input.input').write_bytes(data)
        (folder / 'output.prefix').write_bytes(b'')
        # Pinned Deflate.compress_bound: min_block_length=5000, five bytes per block.
        capacity = size + 5 * max(1, (size + 4999) // 5000)
        command = [str(reference), '--oracle', str(folder / 'input.input'), str(folder / 'output.prefix'), str(capacity), str(folder / 'expected.deflate')]
        result = subprocess.run(command, capture_output=True, text=True)
        (folder / 'oracle.stdout').write_text(result.stdout)
        (folder / 'oracle.stderr').write_text(result.stderr)
        result.check_returncode()
        receipt = json.loads(result.stdout)
        assert receipt['independent_inflation'] and receipt['aliases_preserved']
        expected = (folder / 'expected.deflate').read_bytes()
        rows.append(dict(name=name, family=family, input=str(folder / 'input.input'), prefix=str(folder / 'output.prefix'), expected=str(folder / 'expected.deflate'), capacity=capacity, input_bytes=size, prefix_bytes=0, raw_bytes=len(expected), input_sha256=hashlib.sha256(data).hexdigest(), expected_sha256=hashlib.sha256(expected).hexdigest(), frozen_stream_sha256=hashlib.sha256(stream).hexdigest(), exact_prefix=True, reference_command=command))
        print(name, len(expected), flush=True)
(r / 'prefix-fixtures.json').write_text(json.dumps(rows, indent=2) + '\n')
(r / 'prefix-streams.json').write_text(json.dumps(dict(families=families, sizes=sizes, cases=len(rows), one_binary_per_implementation=True, source_and_algorithm_unchanged=True, allowances_increased=False), indent=2) + '\n')
print('All56 same-stream prefix references independently inflate; inputs frozen through1MiB.')
