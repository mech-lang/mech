use mech_engine::{CanonicalSourceFrontend, ProgramArtifact};
use mech_syntax::document::{
    AstNode, DocumentId, DocumentSyntax, ParseConfig, Revision, TextSnapshot,
    parse_canonical_document,
};
fn source(text: &str) -> ProgramArtifact {
    let parsed = parse_canonical_document(
        TextSnapshot::new(DocumentId(203), Revision(1), text).unwrap(),
        ParseConfig::default(),
    );
    assert!(parsed.is_strictly_clean(), "{:?}", parsed.diagnostics);
    CanonicalSourceFrontend
        .compile_document_with_catalog(
            &DocumentSyntax::cast(parsed.syntax()).unwrap(),
            mech_stdlib::source_catalog(),
        )
        .unwrap()
        .compile_artifact()
        .unwrap()
}
fn run() {
    let args = std::env::args().skip(1).collect::<Vec<_>>();
    assert!((2..=4).contains(&args.len()));
    let input = std::path::Path::new(&args[0]);
    let from_source = input.extension().and_then(|v| v.to_str()) == Some("mec");
    let artifact = if from_source {
        source(&std::fs::read_to_string(input).unwrap())
    } else {
        mech_engine::decode_program_artifact_bytecode_v1(&std::fs::read(input).unwrap()).unwrap()
    };
    let encoded = mech_engine::encode_program_artifact_bytecode_v1(&artifact).unwrap();
    if !from_source {
        assert_eq!(encoded, std::fs::read(input).unwrap());
    }
    let decoded = mech_engine::decode_program_artifact_bytecode_v1(&encoded).unwrap();
    assert_eq!(
        mech_engine::encode_program_artifact_bytecode_v1(&decoded).unwrap(),
        encoded
    );
    if args.iter().any(|s|s=="--inventory-only") {
        let inventory = mech_gpu::native_artifact::compact_native_layout_for_diagnostic(
            &artifact, &mech_stdlib::source_catalog()).unwrap();
        std::fs::write(&args[1],serde_json::to_vec_pretty(&inventory).unwrap()).unwrap();
        return;
    }
    for (index, (name, value)) in [("original", &artifact), ("decoded", &decoded)]
        .into_iter()
        .enumerate()
    {
        if index != 0 && args.get(2).is_some_and(|s| s == "--once") {
            break;
        }
        if index == 0 && args.get(2).is_some_and(|s| s == "--decoded") {
            continue;
        }

        let (object, mut metadata) =
            mech_gpu::native_artifact::emit_compact_closed_object_with_phase_observer_for_diagnostic(
                value,
                &mech_stdlib::source_catalog(),
                args.iter().any(|s| s == "--phase-observe"),
            )
            .unwrap();
        metadata["source_input_form"] = serde_json::json!(if from_source {
            "source"
        } else {
            "pinned bytecode"
        });
        let folder = std::path::Path::new(&args[1]).join(name);
        std::fs::create_dir_all(&folder).unwrap();
        std::fs::write(folder.join("object.o"), object).unwrap();
        std::fs::write(
            folder.join("metadata.json"),
            serde_json::to_vec_pretty(&metadata).unwrap(),
        )
        .unwrap();
        println!(
            "{}",
            serde_json::json!({"form": name, "code_bytes":metadata["code_bytes"], "stack_bytes":metadata["stack_bytes"], "calls":metadata["calls"], "input_words":metadata["input_words"], "output_words":metadata["output_words"], "contract":metadata["contract"]})
        );
    }
}
fn main() {
    std::thread::Builder::new()
        .stack_size(32 * 1024 * 1024)
        .spawn(run)
        .unwrap()
        .join()
        .unwrap();
}
