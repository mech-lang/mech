use mech_core::{
    ManagedMemoryBudget, Value, ValueDataDraft as Data,
    snapshot::{SnapshotValidationContext, ValueDraft},
};
use mech_engine::{
    CanonicalSourceFrontend, ProgramArtifact,
};
use mech_gpu::native_artifact::NativeProgramLimitMode;
use mech_syntax::document::{
    AstNode, DocumentId, DocumentSyntax, ParseConfig, Revision, TextSnapshot,
    parse_canonical_document,
};

fn artifact(text: &str) -> Result<ProgramArtifact, String> {
    let parsed = parse_canonical_document(
        TextSnapshot::new(DocumentId(195), Revision(1), text).unwrap(),
        ParseConfig::default(),
    );
    if !parsed.is_strictly_clean() {
        return Err(format!("syntax: {:?}", parsed.diagnostics));
    }
    CanonicalSourceFrontend
        .compile_document_with_catalog(
            &DocumentSyntax::cast(parsed.syntax()).unwrap(),
            mech_stdlib::source_catalog(),
        )
        .map_err(|e| format!("source: {e:?}"))?
        .compile_artifact()
        .map_err(|e| format!("artifact: {e:?}"))
}
fn import(
    a: &ProgramArtifact,
    named: &[(&str, Data)],
    memory: &ManagedMemoryBudget,
    rows: u64,
    columns: u64,
) -> Vec<Value> {
    a.inputs()
        .iter()
        .map(|port| {
            let name = mech_engine::decode_source_input_name(&port.name).unwrap();
            let data = named.iter().find(|(n, _)| *n == name).unwrap().1.clone();
            let shape_values = match &data {
                Data::Matrix(v) => mech_core::shape_for_resolved_extents(
                    a.schemas().get(port.schema).unwrap(),
                    &if name == "bytes" { [rows, columns] } else { [1, v.len() as u64] },
                )
                .unwrap()
                .parameter_values()
                .to_vec()
                .into_boxed_slice(),
                _ => Box::new([]),
            };
            let value = ValueDraft {
                schema: port.schema,
                shape_values,
                data,
            }
            .finalize(&SnapshotValidationContext::new(a.schemas()))
            .unwrap();
            let mut reserve = memory
                .reserve_capacity(value.memory_budget_admission_bytes(memory).unwrap())
                .unwrap();
            value.into_memory_budget(&mut reserve).unwrap()
        })
        .collect()
}
#[path = "array-runtime.rs"]
mod arrays;
#[path = "/private/tmp/mech-child-prepayment-round163-20261105/pinned_allocator.rs"]
mod pinned_allocator;
#[global_allocator]
static ALLOCATOR: pinned_allocator::PinnedMimalloc = pinned_allocator::PinnedMimalloc;
use std::{cell::RefCell, collections::BTreeMap};
thread_local! { static VISITS:RefCell<BTreeMap<u64,[u64;2]>>=RefCell::new(BTreeMap::new()); }
#[unsafe(no_mangle)]
pub extern "C" fn mech_compact_phase_observe(_: u64, header: u64, selected: u64) -> u64 {
    VISITS.with(|v| v.borrow_mut().entry(header).or_default()[usize::from(selected != 0)] += 1);
    0
}
#[repr(C)]
#[derive(Debug)]
struct Outcome {
    status: u64,
    origin: u64,
}
unsafe extern "C" {
    fn mech_compact_closed_v2(
        heap: *mut std::ffi::c_void,
        input: *const u64,
        output: *mut u64,
    ) -> Outcome;
}

fn inspect(output: &[u64], alias: bool, width: u8) -> (Vec<Vec<u64>>, Vec<[u64; 3]>) {
    let mut values = vec![];
    let mut shapes = vec![];
    for at in [0].into_iter().chain(if alias { Some(6) } else { None }) {
        let v = &output[at..at + 6];
        assert_eq!(v[1], v[3] * v[4]);
        assert!(v[1] <= v[2]);
        let data = if v[1] == 0 {
            vec![]
        } else {
            unsafe {
                match width {
                    1 => std::slice::from_raw_parts(v[0] as *const u8, v[1] as usize)
                        .iter()
                        .map(|&v| v as u64)
                        .collect(),
                    2 => std::slice::from_raw_parts(v[0] as *const u16, v[1] as usize)
                        .iter()
                        .map(|&v| v as u64)
                        .collect(),
                    4 => std::slice::from_raw_parts(v[0] as *const u32, v[1] as usize)
                        .iter()
                        .map(|&v| v as u64)
                        .collect(),
                    8 => std::slice::from_raw_parts(v[0] as *const u64, v[1] as usize).to_vec(),
                    _ => unreachable!(),
                }
            }
        };
        values.push(data);
        shapes.push([v[2], v[3], v[4]]);
    }
    (values, shapes)
}

#[derive(Clone, Debug)]
struct Case {
    bytes: Vec<u8>, rows: u64, columns: u64,
    left: u64, right: u64, start: u64, limit: u64, rounds: u64,
    allowed: bool, enabled: bool, results: Vec<u64>,
}
fn byte(c: &Case, at: u64) -> u8 {
    if at >= c.bytes.len() as u64 { return 0; }
    c.bytes[((at % c.rows) * c.columns + at / c.rows) as usize]
}
fn word(c: &Case, at: u64) -> u64 {
    if c.bytes.len() < 8 || at > c.bytes.len() as u64 - 8 { return 0; }
    u64::from_le_bytes(std::array::from_fn(|i| byte(c, at + i as u64)))
}
fn oracle(c: &Case, mode: &str) -> Result<Vec<u64>, u64> {
    if !c.allowed { return Err(9); }
    let mut results = c.results.clone();
    if !c.enabled { return Ok(results); }
    for turn in 0..c.rounds {
        let (left, right) = if turn & 1 == 0 { (c.left, c.right) } else { (c.right, c.left) };
        let _four = c.start.checked_add(32).ok_or(1u64)?;
        let mut at = c.start;
        loop {
            let end = at.checked_add(8).ok_or(1u64)?;
            if end > c.limit { break; }
            let mut difference = word(c, right.wrapping_add(at)) ^ word(c, left.wrapping_add(at));
            if mode == "fallible" { difference = difference.checked_add(1).ok_or(1u64)?; }
            if difference != if mode == "fallible" { 1 } else { 0 } {
                at = at.wrapping_add((difference.trailing_zeros() as u64) >> 3);
                *results.first_mut().ok_or(0x19401u64)? = at;
                break;
            }
            at = at.wrapping_add(if mode == "stride12" { 12 } else { 8 });
        }
        // A mismatching word has already finished the word/tail computation.
        // Re-evaluate whether that branch fired without assuming byte-at-a-time
        // equivalence for source word reads that deliberately default to zero.
        let mut scan = c.start;
        let mut mismatched = false;
        while scan.checked_add(8).ok_or(1u64)? <= c.limit {
            let mut d = word(c, right.wrapping_add(scan)) ^ word(c, left.wrapping_add(scan));
            if mode == "fallible" { d = d.checked_add(1).ok_or(1u64)?; }
            if d != if mode == "fallible" { 1 } else { 0 } { mismatched = true; break; }
            scan = scan.wrapping_add(if mode == "stride12" { 12 } else { 8 });
        }
        if !mismatched {
            while at < c.limit && byte(c, left.wrapping_add(at)) == byte(c, right.wrapping_add(at)) { at = at.wrapping_add(1); }
            *results.first_mut().ok_or(0x19401u64)? = at;
        }
    }
    Ok(results)
}
fn cases() -> Vec<Case> {
    let base = Case { bytes: vec![0; 768], rows: 1, columns: 768,
        left: 400, right: 32, start: 0, limit: 258, rounds: 3,
        allowed: true, enabled: true, results: vec![777,888,999] };
    let mut variants = vec![base.clone()];
    for position in 0..258 {
        let mut c = base.clone(); c.bytes[32 + position] = 1u8 << (position % 8); variants.push(c);
    }
    for start in [0,1,3,7,8,9,15,16,17,31,32,33,63,64,129,250,257,258,259] {
        for limit in [0,1,7,8,9,15,16,17,31,32,33,64,65,257,258] {
            variants.push(Case { start, limit, ..base.clone() });
        }
    }
    for offset in 0..16 { variants.push(Case { left: 400+offset, right: 32+offset, start: 3, ..base.clone() }); }
    for (rows,columns) in [(2,384),(384,2),(768,1)] {
        let mut c = Case { rows,columns,..base.clone() }; c.bytes[47]=21; variants.push(c);
    }
    for (length,rows,columns) in [(0,1,0),(0,0,3),(7,1,7),(8,8,1),(9,1,9),(15,1,15),(16,2,8),(17,1,17)] {
        variants.push(Case { bytes: vec![0;length], rows,columns,..base.clone() });
    }
    for (left,right,start,limit) in [
        (1,0,0,258),(2,1,1,257),(400,399,0,258),(400,400,0,258),
        (u64::MAX,0,0,258),(0,u64::MAX,1,258),(0,0,0,258),
        (400,32,u64::MAX,0),(400,32,u64::MAX-31,0),
        (400,32,u64::MAX-32,0),(400,32,0,u64::MAX),
    ] {
        // A maximum loop limit with equal default words would be unbounded;
        // force an immediate mismatch while retaining the exact overflow gate.
        let mut c = Case { left,right,start,limit,..base.clone() };
        if limit == u64::MAX { c.bytes[32] = 1; }
        variants.push(c);
    }
    variants.push(Case { allowed: false, start: u64::MAX, ..base.clone() });
    variants.push(Case { enabled: false, start: u64::MAX, limit:u64::MAX, ..base.clone() });
    variants.push(Case { rounds:0, start:u64::MAX, ..base.clone() });
    variants.push(Case { results:vec![], ..base.clone() });
    variants.push(Case { results:vec![], enabled:false, ..base.clone() });
    let mut answer = Vec::new();
    for case in variants { answer.push(case); answer.push(base.clone()); }
    answer
}
fn run() {
    let mut gate=arrays::Heap::new();let mut view=[0u64;6];
    assert_eq!(unsafe {arrays::mech_compact_allocate(&mut gate,13,1,1,0,view.as_mut_ptr())},0);
    unsafe {*(view[0] as *mut u8)=42;(*(view[5] as *mut arrays::Owner)).references=2;}
    view[1]=1;view[4]=1;assert_eq!(unsafe {gate.take_u8(view)},Err(arrays::INVALID));
    unsafe {(*(view[5] as *mut arrays::Owner)).references=1;}
    let held=unsafe {gate.take_u8(view)}.unwrap();assert_eq!(held,[42]);assert_eq!(held.capacity(),13);drop((held,gate));
    let args = std::env::args().skip(1).collect::<Vec<_>>(); assert_eq!(args.len(), 5);
    let meta:serde_json::Value = serde_json::from_slice(&std::fs::read(&args[0]).unwrap()).unwrap();
    let a = artifact(&std::fs::read_to_string(&args[1]).unwrap()).unwrap();
    let baseline_bytes=std::fs::read(&args[4]).unwrap();
    let baseline:serde_json::Value=serde_json::from_slice(&baseline_bytes).unwrap();
    let mode = &args[2]; let mut cases = cases();
    if mode != "normal" {
        let length=cases.len();cases=cases.into_iter().enumerate().filter(|(i,_)|*i<32 || *i%48==0 || *i+34>=length).map(|(_,v)|v).collect();
        let mut overflow=cases[0].clone();overflow.bytes[32..40].fill(255);cases.push(overflow);cases.push(cases[0].clone());
    }
    let memory = NativeProgramLimitMode::NoLimits.memory_budget();
    let mut output = vec![0x5555555555555555;meta["output_words"].as_u64().unwrap() as usize];
    let mut publication:Option<(arrays::Heap,Vec<u64>)> = None;
    let mut rows = Vec::new(); let mut selected=0; let mut rejected=0; let mut resident_capped=0; 
    for (index,c) in cases.iter().enumerate() {
        let named = vec![
            ("bytes",Data::Matrix(c.bytes.iter().copied().map(Data::U8).collect::<Vec<_>>().into())),
            ("results",Data::Matrix(c.results.iter().copied().map(Data::U64).collect::<Vec<_>>().into())),
            ("left",Data::U64(c.left)),("right",Data::U64(c.right)),
            ("start",Data::U64(c.start)),("limit",Data::U64(c.limit)),("rounds",Data::U64(c.rounds)),
            ("allowed",Data::Bool(c.allowed)),("enabled",Data::Bool(c.enabled)),
        ];
        let values = import(&a,&named,&memory,c.rows,c.columns);
        let aliases=values.clone();
        let capped=baseline["rows"][index]["resident_default_cap"].as_bool().unwrap();
        if capped {resident_capped+=1;}
        let mut input=vec![0;meta["input_words"].as_u64().unwrap() as usize];
        for p in meta["inputs"].as_array().unwrap() {
            let name=mech_engine::decode_source_input_name(p["name"].as_str().unwrap()).unwrap();
            let at=p["input_offset"].as_u64().unwrap() as usize;
            match &named.iter().find(|(n,_)|*n==name).unwrap().1 {
                Data::Matrix(_) => {
                    let view=if name=="bytes" {[c.bytes.as_ptr() as u64,c.bytes.len() as u64,c.bytes.len() as u64,c.rows,c.columns,0]}
                        else {[c.results.as_ptr() as u64,c.results.len() as u64,c.results.len() as u64,1,c.results.len() as u64,0]};
                    input[at..at+6].copy_from_slice(&view);
                }
                Data::U64(v)=>input[at]=*v, Data::Bool(v)=>input[at]=u64::from(*v), _=>unreachable!(),
            }
        }
        let old=output.clone(); let prior=publication.as_ref().map(|(_,v)|inspect(v,true,8));
        let before_bytes=c.bytes.clone();let before_results=c.results.clone();
        let mut heap=arrays::Heap::new(); VISITS.with(|v|v.borrow_mut().clear());
        let actual=unsafe { mech_compact_closed_v2((&mut heap as *mut arrays::Heap).cast(),input.as_ptr(),output.as_mut_ptr()) };
        let expected=oracle(c,mode); assert_eq!(actual.status,expected.as_ref().err().copied().unwrap_or(0),"{index} {c:?}");
        assert_eq!(c.bytes,before_bytes);assert_eq!(c.results,before_results);
        for (value,alias) in values.iter().zip(&aliases) { assert!(value.shares_frozen_storage(alias)); }
        if let Some((_,v))=&publication { assert_eq!(inspect(v,true,8),prior.unwrap()); }
        let current;
        if let Ok(answer)=expected {
            let observed=inspect(&output,true,8);assert_eq!(observed.0,vec![answer.clone(),c.results.clone()],"{index} {c:?}");
            if let Some((mut h,_))=publication.take() {h.discard_private();assert_eq!(h.counters.live_payload_bytes,0);}
            current=serde_json::json!(observed);publication=Some((heap,output.clone()));
        } else {
            assert_eq!(old,output,"partial publication");
            heap.discard_private();assert_eq!(heap.counters.live_payload_bytes,0);current=serde_json::Value::Null;rejected+=1;
        }
        let visits=VISITS.with(|v|v.borrow().clone());if visits.values().any(|v|v[1]>0){selected+=1;}
        rows.push(serde_json::json!({"case":index,"status":actual.status,"origin":actual.origin,"current":current,"visits":visits,"aliases_unchanged":true,"prior_publication_unchanged":true,"resident_default_cap":capped}));
    }
    if let Some((mut h,_))=publication.take() {h.discard_private();assert_eq!(h.counters.live_payload_bytes,0);}
    assert_eq!((memory.used_bytes(),memory.retained_snapshot_nodes()),(0,0));
    let normalize = |value: serde_json::Value| {
        value.as_array().unwrap().iter().cloned().map(|mut row| {
            row.as_object_mut().unwrap().remove("visits");
            row
        }).collect::<Vec<_>>()
    };
    assert_eq!(normalize(serde_json::to_value(&rows).unwrap()),normalize(baseline["rows"].clone()),"changed source value/status/origin/alias");
    std::fs::write(&args[3],serde_json::to_vec_pretty(&serde_json::json!({"cases":rows.len(),"rows":rows,"selected_cases":selected,"rejected":rejected,"reused_resident_default_cap_cases":resident_capped,"new_resident_calls":0,"prior_resident_observations_reused":true,"final_managed_bytes":0,"final_managed_nodes":0,"final_private_payload_bytes":0})).unwrap()).unwrap();
    println!("MATCH_CONTROLS_PASS {} selected={selected} rejected={rejected}",cases.len());
}
fn main(){std::thread::Builder::new().stack_size(32*1024*1024).spawn(run).unwrap().join().unwrap();}
