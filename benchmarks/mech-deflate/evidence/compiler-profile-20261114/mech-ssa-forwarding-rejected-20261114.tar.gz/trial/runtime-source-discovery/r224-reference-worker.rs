#[path = "/private/tmp/mech-child-prepayment-round163-20261105/pinned_allocator.rs"]
mod pinned_allocator;
#[global_allocator]
static ALLOCATOR: pinned_allocator::PinnedMimalloc = pinned_allocator::PinnedMimalloc;
use serde::Deserialize;
use std::{ffi::{CStr,c_char},io::{BufRead,Write},time::Instant};
#[repr(C)]
#[derive(Clone,Copy)]
struct RocList { elements:*mut u8, length:usize, capacity_or_alloc_ptr:usize }
unsafe extern "C" {
 fn roc_compress(input:RocList,output:RocList)->RocList;
 fn mi_malloc(n:usize)->*mut u8;
 fn mi_malloc_aligned(n:usize,a:usize)->*mut u8;
 fn mi_realloc(p:*mut u8,n:usize)->*mut u8;
 fn mi_realloc_aligned(p:*mut u8,n:usize,a:usize)->*mut u8;
 fn mi_free(p:*mut u8);
}
#[unsafe(no_mangle)]
unsafe extern "C" fn roc_alloc(n:usize,a:usize)->*mut u8 { let p=unsafe{if a<=16{mi_malloc(n.max(1))}else{mi_malloc_aligned(n.max(1),a)}};assert!(!p.is_null());p }
#[unsafe(no_mangle)]
unsafe extern "C" fn roc_dealloc(p:*mut u8,_a:usize){unsafe{mi_free(p)}}
#[unsafe(no_mangle)]
unsafe extern "C" fn roc_realloc(p:*mut u8,n:usize,a:usize)->*mut u8 {let q=unsafe{if a<=16{mi_realloc(p,n.max(1))}else{mi_realloc_aligned(p,n.max(1),a)}};assert!(!q.is_null());q}
#[unsafe(no_mangle)]
unsafe extern "C" fn roc_dbg(p:*const u8,n:usize){let bytes=unsafe{std::slice::from_raw_parts(p,n)};let _=std::io::stderr().write_all(bytes);eprintln!();}
#[unsafe(no_mangle)]
unsafe extern "C" fn roc_crashed(p:*const u8,n:usize)->! {unsafe{roc_dbg(p,n)};std::process::abort()}
#[unsafe(no_mangle)]
unsafe extern "C" fn roc_expect_failed(p:*const u8,n:usize)->! {unsafe{roc_crashed(p,n)}}
impl RocList {
 fn make(data:&[u8],capacity:usize)->Self {assert!(capacity>=data.len());if capacity==0{return Self{elements:std::ptr::null_mut(),length:0,capacity_or_alloc_ptr:0}};let bytes=capacity.checked_add(8).unwrap();let rc=unsafe{roc_alloc(bytes,8)};unsafe{rc.cast::<usize>().write(1);std::ptr::copy_nonoverlapping(data.as_ptr(),rc.add(8),data.len())};Self{elements:unsafe{rc.add(8)},length:data.len(),capacity_or_alloc_ptr:capacity.checked_mul(2).unwrap()} }
 fn allocation(self)->*mut usize {let p=if self.capacity_or_alloc_ptr&1!=0{(self.capacity_or_alloc_ptr&!1)as *mut u8}else{self.elements};((p as usize)&!7)as *mut usize}
 fn rc(self)->usize {if self.elements.is_null(){return 0};unsafe{self.allocation().sub(1).read()} }
 fn retained(self)->Self {if !self.elements.is_null(){unsafe{let p=self.allocation().sub(1);let n=p.read();if n!=0{p.write(n.checked_add(1).unwrap())}}};self}
 fn release(self){if !self.elements.is_null(){unsafe{let p=self.allocation().sub(1);let n=p.read();if n!=0{p.write(n-1);if n==1{roc_dealloc(p.cast(),8)}}}}}
 fn bytes(&self)->&[u8]{if self.length==0{&[]}else{unsafe{std::slice::from_raw_parts(self.elements,self.length)}}}
 fn capacity(self)->usize{assert_eq!(self.capacity_or_alloc_ptr&1,0,"whole output must retain an ordinary capacity");self.capacity_or_alloc_ptr>>1}
}
#[derive(Deserialize)]
struct Case {name:String,input:String,prefix:String,expected:String,capacity:usize}
fn run(case:&Case,samples:usize,reader:&mut impl BufRead){
 let input=std::fs::read(&case.input).unwrap();let prefix=std::fs::read(&case.prefix).unwrap();let expected=std::fs::read(&case.expected).unwrap();
 assert_eq!(&expected[..prefix.len()],prefix);assert_eq!(miniz_oxide::inflate::decompress_to_vec(&expected[prefix.len()..]).unwrap(),input);
 let input_list=RocList::make(&input,input.len());let mut current=RocList::make(&prefix,case.capacity);
 println!("CASE_READY\t{}",case.name);std::io::stdout().flush().unwrap();
 {let mut execute=|sample:usize| {
assert_eq!(current.rc(),1);
  current.length=prefix.len();assert_eq!(current.capacity(),case.capacity);unsafe{std::ptr::copy_nonoverlapping(prefix.as_ptr(),current.elements,prefix.len())};
  let input_arg=input_list.retained();let output_arg=current.retained();let prior=current.elements;
  let start=Instant::now();let returned=unsafe{roc_compress(input_arg,output_arg)};let seconds=start.elapsed().as_secs_f64();
  assert_eq!(returned.bytes(),expected);assert_eq!(returned.capacity(),case.capacity);assert_eq!(miniz_oxide::inflate::decompress_to_vec(&returned.bytes()[prefix.len()..]).unwrap(),input_list.bytes());
  assert_eq!(current.bytes(),prefix);assert_eq!(input_list.rc(),if input.is_empty(){0}else{1});assert_eq!(current.rc(),1);assert_eq!(returned.rc(),1);assert_ne!(returned.elements,prior,"held borrowed output cannot be consumed");
  let raw=returned.length-prefix.len();current.release();current=returned;

serde_json::json!({"case":case.name,"sample":sample,"warmup":sample==0,"profile":sample==samples+1,"seconds":seconds,"input_bytes":input.len(),"prefix_bytes":prefix.len(),"raw_bytes":raw,"capacity":case.capacity,"exact_reference":true,"independent_inflation":true,"input_alias_unchanged":true,"borrowed_output_alias_unchanged":true,"ownership_mode":"borrowed input and prepared output; actual held references survive call","level":12,"runtime_input":true,"clock":"Rust std::time::Instant; identical pinned toolchain and validation library as Mech","boundary":"complete pure compress_into call, including scratch construction and cleanup; preparation, reference cloning, validation, logging, previous-output drop excluded"})
};

        let mut sample=0usize;
        while sample<samples+2 {
            let mut command=[0u8;1];reader.read_exact(&mut command).unwrap();
            if command==*b"W" {
                let warm_start=Instant::now();let mut calls=0u64;
                while warm_start.elapsed()<std::time::Duration::from_millis(200) {
                    let value=execute(usize::MAX);drop(value);calls+=1;
                }
                println!("WARMUP_DONE\t{}\t{calls}\t{}",case.name,warm_start.elapsed().as_secs_f64());
            } else {
                assert_eq!(command,*b"N");let value=execute(sample);println!("{value}");sample+=1;
            }
            std::io::stdout().flush().unwrap();
        }
}
 input_list.release();current.release();println!("CASE_DONE\t{}",case.name);std::io::stdout().flush().unwrap();
}
fn entry(args:Vec<String>){
 if args.len()==5 && args[0]=="--oracle" {
  use sha2::Digest;
  let input=std::fs::read(&args[1]).unwrap();let prefix=std::fs::read(&args[2]).unwrap();let capacity=args[3].parse().unwrap();assert!(!std::path::Path::new(&args[4]).exists());
  let source=RocList::make(&input,input.len());let prepared=RocList::make(&prefix,capacity);let returned=unsafe{roc_compress(source.retained(),prepared.retained())};
  assert_eq!(&returned.bytes()[..prefix.len()],prefix);assert_eq!(miniz_oxide::inflate::decompress_to_vec(&returned.bytes()[prefix.len()..]).unwrap(),input);assert_eq!(source.bytes(),input);assert_eq!(prepared.bytes(),prefix);assert_eq!(returned.capacity(),capacity);
  std::fs::write(&args[4],returned.bytes()).unwrap();println!("{}",serde_json::json!({"oracle_generated":true,"input_bytes":input.len(),"prefix_bytes":prefix.len(),"raw_bytes":returned.length-prefix.len(),"capacity":capacity,"sha256":sha2::Sha256::digest(returned.bytes()).iter().map(|b|format!("{b:02x}")).collect::<String>(),"independent_inflation":true,"aliases_preserved":true,"runtime_input":true,"fixed_level":12}));returned.release();source.release();prepared.release();return;
 }
 assert_eq!(args.len(),2);let cases:Vec<Case>=serde_json::from_slice(&std::fs::read(&args[1]).unwrap()).unwrap();println!("SESSION_READY");std::io::stdout().flush().unwrap();let mut reader=std::io::BufReader::new(std::io::stdin());loop{let mut line=String::new();assert!(reader.read_line(&mut line).unwrap()>0);if line=="Q\n"{break}let fields=line.trim_end().split('\t').collect::<Vec<_>>();assert_eq!(fields.len(),3);assert_eq!(fields[0],"C");run(&cases[fields[1].parse::<usize>().unwrap()],fields[2].parse().unwrap(),&mut reader)}eprintln!("CLEANUP reference_input_and_output_roots_released=1");}
#[unsafe(no_mangle)]
unsafe extern "C" fn main(argc:i32,argv:*const *const c_char)->i32 {let args=(1..argc).map(|i|unsafe{CStr::from_ptr(*argv.add(i as usize))}.to_str().unwrap().to_owned()).collect();entry(args);0}
