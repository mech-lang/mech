"""Measure one fused subtract and comparison at all four admitted hot entries."""
from pathlib import Path
import re
import struct
import subprocess
import sys

root = Path(__file__).resolve().parent
carry, current, history, _, corpus = root.parents[:5]
sys.path.insert(0, str(history))
from composed_record_count import trial
from measure_second_hint import configure, mod

prior = carry/'candidate'
image = carry/'decoded/decoded/object.o'
control = prior/'mech-worker'
names = tuple(f'mech_compact_numeric_{site}_no_growth_composed'
              for site in (12419, 15296, 26895, 31086))
cases = ('empty','one-stored','seven-stored-prefix','eight-literals',
         'prefix-natural-16384','prefix-natural-32767','prefix-natural-32768',
         'prefix-natural-32769','prefix-natural-65536','heldout-window-32767',
         'heldout-window-32768','heldout-slides-65537','prefix-natural-131072',
         'prefix-natural-262144','prefix-natural-1048576','prefix-random-1048576',
         'prefix-repeated-1048576')

def object_patch():
    data = image.read_bytes()
    output = bytearray(data)
    sections, _ = trial.isolate.macho(data)
    base, _, section, _, _, _ = sections[b'__TEXT', b'__text']
    symbols = trial.isolate.symbols(image)
    rows = {}
    for name in names:
        (start,) = symbols['_'+name]
        lines = subprocess.check_output(['xcrun','llvm-objdump',
              '--disassemble-symbols=_'+name, image],text=True).splitlines()
        found=[]
        for index, line in enumerate(lines[:-2]):
            compare = re.fullmatch(r'\s*([0-9a-f]+):\s+([0-9a-f]{8})\s+cmp\s+x(\d+), x(\d+)', line)
            jump = re.fullmatch(r'\s*([0-9a-f]+):\s+([0-9a-f]{8})\s+b\.hs\s+0x([0-9a-f]+).*',lines[index+1])
            diff = re.fullmatch(r'\s*([0-9a-f]+):\s+([0-9a-f]{8})\s+sub\s+x(\d+), x(\d+), x(\d+)',lines[index+2])
            if not compare or not jump or not diff:continue
            if compare[3] != diff[5] or compare[4] != diff[4]:continue
            found.append((compare,jump,diff))
        (compare, jump, diff), = found
        loc = int(compare[1],16)
        section_body = (start, start + trial.read(carry/'machine.json')[name]['bytes_stack'][1][0])
        assert section_body[0] < loc < section_body[1]-12
        assert int(jump[1],16) == loc+4 and int(diff[1],16) == loc+8
        assert int(jump[3],16) > loc+12
        dest = int(diff[3])
        assert dest not in (int(compare[3]),int(compare[4]),31)
        smaller = int(compare[3])
        larger = int(compare[4])
        cmp_bits = 0xEB00001F | (larger << 16) | (smaller << 5)
        diff_bits = 0xCB000000 | (smaller << 16) | (larger << 5) | dest
        assert cmp_bits == int(compare[2],16) and diff_bits == int(diff[2],16)
        branch_bits = int(jump[2],16)
        assert branch_bits & 15 == 2
        # There are no other branches into the original subtraction. The
        # zero-trip edge does not read its destination before redefining it.
        for line in lines:
            edge=re.search(r'\b(?:b(?:\.[a-z]+)?|cbz|cbnz|tbz|tbnz)\s+[^<>]*?0x([0-9a-f]+) <',line)
            if edge: assert int(edge[1],16) != loc+8, line
        location = section + loc-base
        assert struct.unpack_from('<III',data,location)==(cmp_bits,branch_bits,diff_bits)
        result = (diff_bits | 0x20000000, branch_bits & ~15 | 9, 0xd503201f)
        struct.pack_into('<III', output, location,*result)
        rows[name] = {'body_address':start, 'site':loc, 'file_offset':location,
                      'before':(cmp_bits,branch_bits,diff_bits), 'after':result,
                      'difference_sink':'selected successor only'}
        print(name, hex(loc), 'SUBS, B.LS, NOP', flush=True)
    patch=root/'object.o'
    patch.write_bytes(output)
    assert trial.isolate.symbols(patch)==symbols
    trial.write(root/'machine.json',rows)

def link():
    trial.receipt.ROOT=root
    pin=trial.read(prior/'link.json')
    output=root/'mech-worker'
    command=[a.replace('link-arg='+str(image),'link-arg='+str(root/'object.o')) for a in pin['command']]
    assert command!=pin['command']
    command[command.index('-o')+1]=str(output)
    trial.receipt.stage('link',command,pin['flags'])
    d=trial.read(root/'machine.json')
    a, b = (p.read_bytes() for p in (control, output))
    sections,commands=trial.isolate.macho(a)
    assert (sections,commands)==trial.isolate.macho(b)
    n,s=[trial.isolate.symbols(p) for p in (control,output)]
    assert n==s
    addr,_,off,*_=sections[b'__TEXT',b'__text']
    (uuid,uuid_size),=commands[0x1b]
    (sig,_),=commands[0x1d]
    sa,ss=struct.unpack_from('<II',a,sig+8)
    omits=[(uuid+8,uuid+uuid_size),(sa,sa+ss)]
    for name,row in d.items():
        at=n['_'+name][0]+row['site']-row['body_address']-addr+off
        assert struct.unpack_from('<III',a,at)==tuple(row['before'])
        assert struct.unpack_from('<III',b,at)==tuple(row['after'])
        omits.append((at,at+12))
    assert trial.isolate.masked(a,omits)==trial.isolate.masked(b,omits)
    tag='compiled-carry-fused-subtraction'
    trial.receipt.stage('qualify',[sys.executable,'-B',trial.RUN/'verify-worker.py',
                                   output,mod.DESCRIPTOR,tag])
    proof=trial.read(trial.RUN/(tag+'-qualification.json'))
    assert proof['verified'] and proof['complete_smokes']==162
    trial.write(root/'qualification.json',proof)
    for case in ('oracle','boundaries'):
        old=carry/'direct'/('build-'+case+'.json')
        pin=trial.read(old)
        args=[str(root/'object.o') if a==str(image) else a for a in pin['command']]
        worker=root/(case+'-direct')
        args[args.index('-o')+1]=str(worker)
        trial.receipt.stage('build-'+case,args,pin['flags'])
        symbols=trial.isolate.symbols(worker)
        (entry,)=symbols['_mech_compact_closed_v2']
        (normal,)=symbols['_mech_compact_numeric_15296_no_growth']
        (composed,)=symbols['_mech_compact_numeric_15296_no_growth_composed']
        trial.receipt.stage(case,[worker,str(normal-entry),str(composed-entry)])
        assert (root/(case+'.stdout')).read_bytes()==(carry/'direct'/(case+'.stdout')).read_bytes()

def timing(step):
    mod.CASES = cases
    mod.CONFIRM = cases
    configure(root,control,root/'mech-worker')
    mod.timing(step)

for arg in sys.argv[1:]:
    if arg=='prepare':
        object_patch()
        link()
    else:
        timing(arg)
