"""Build and qualify the recurrence bound representation on the unchanged source."""
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
current, history, _, corpus = root.parents[:4]
sys.path.insert(0, str(history))
from composed_record_count import trial
from measure_second_hint import configure, mod

prior = history / 'roc-parity-baseline-80ddb85f4b/first-owner-slot/final'
frozen = history / 'defaulted-read-compiler-final'
control = frozen / 'decoded/decoded/object.o'
cases = (
    'empty', 'one-stored', 'seven-stored-prefix', 'eight-literals',
    'prefix-natural-16384', 'prefix-natural-32767', 'prefix-natural-32768',
    'prefix-natural-32769', 'prefix-natural-33027', 'heldout-slides-65537',
    'prefix-natural-65536', 'prefix-natural-131072', 'prefix-natural-262144',
    'prefix-natural-1048576', 'prefix-random-1048576', 'prefix-repeated-1048576',
)

def build():
    trial.receipt.ROOT = root
    library = root / 'libmech_gpu_parity.rlib'
    for name in ('build-library', 'build-producer'):
        pin = trial.read(current / (name + '.json'))
        args = [a.replace(str(current / library.name), str(library)) for a in pin['command']]
        args[args.index('-o') + 1] = str(library if name == 'build-library' else root / 'producer')
        trial.receipt.stage(name, args, pin['flags'], timestamp=True)
        print(name, trial.read(root / (name + '.json'))['seconds'], flush=True)

def emit(mode):
    trial.receipt.ROOT = root
    out = root / mode
    out.mkdir(exist_ok=True)
    if mode == 'decoded':
        path, form = frozen / 'decoded/source.mbc', '--decoded'
    else:
        path, form = corpus / 'benchmark-source.mec', '--once'
    pin = trial.read(frozen / ('emit-' + mode + '.json'))
    flags = {k: v for k, v in pin['flags'].items() if not k.startswith('MECH_INSPECT_')}
    flags['MECH_CARRY_REDUCTION_BOUND'] = '1'
    flags['MECH_INSPECT_PHASE_CLIF'] = str(out / 'mech_compact_numeric_15296_no_growth_composed.clif')
    trial.receipt.stage('emit-' + mode, [root / 'producer', path, out, form], flags, timestamp=True)
    image = out / mode / 'object.o'
    print(mode, trial.digest(image), control.read_bytes() == image.read_bytes(), flush=True)
    for line in (root / ('emit-' + mode + '.stderr')).read_text().splitlines():
        if 'adjusted reduction bound' in line:
            print(line, flush=True)

def link():
    target = root / 'candidate'
    target.mkdir(exist_ok=True)
    trial.receipt.ROOT = target
    image = root / 'decoded/decoded/object.o'
    pin = trial.read(prior / 'link.json')
    args = [a.replace('link-arg=' + str(control), 'link-arg=' + str(image)) for a in pin['command']]
    assert args != pin['command']
    worker = target / 'mech-worker'
    args[args.index('-o') + 1] = str(worker)
    trial.receipt.stage('link', args, pin['flags'])
    tag = 'compiled-carry-bound'
    trial.receipt.stage('qualify', [sys.executable, '-B', trial.RUN / 'verify-worker.py',
                                    worker, mod.DESCRIPTOR, tag])
    receipt = trial.read(trial.RUN / (tag + '-qualification.json'))
    assert receipt['verified'] and receipt['complete_smokes'] == 162
    trial.write(target / 'qualification.json', receipt)
    print('162 exact independent-inflate smoke checks', flush=True)

def timing(step):
    mod.CASES = cases
    mod.CONFIRM = cases
    target = root / 'candidate'
    configure(target, prior / 'mech-worker', target / 'mech-worker')
    mod.timing(step)

for action in sys.argv[1:]:
    if action == 'build':
        build()
    elif action in ('decoded', 'original'):
        emit(action)
    elif action == 'link':
        link()
    else:
        timing(action)
