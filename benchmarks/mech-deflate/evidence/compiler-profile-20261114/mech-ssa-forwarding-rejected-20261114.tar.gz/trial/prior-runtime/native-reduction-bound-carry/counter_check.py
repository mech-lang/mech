from pathlib import Path
import gzip
import json
from statistics import median
import sys

root = Path(__file__).resolve().parent
current, history, _, corpus = root.parents[:4]
sys.path.insert(0, str(history))
from composed_record_count import trial
from measure_second_hint import configure, mod

prior = history/'roc-parity-baseline-80ddb85f4b/first-owner-slot/final'
config = corpus/'integrated-hosted-diagnostic'
image = root/'decoded/decoded/object.o'
old = history/'defaulted-read-compiler-final/decoded/decoded/object.o'
target = root/'candidate'
cases = ('empty','one-stored','seven-stored-prefix','eight-literals','prefix-natural-16384',
         'prefix-natural-32768','prefix-natural-1048576','heldout-slides-65537',
         'prefix-random-1048576','prefix-repeated-1048576')

def setup(mode):
    stage = root / ('probe-'+mode)
    stage.mkdir()
    pin = trial.read(prior/('probe-after/link-'+mode+'.json'))
    worker = stage/('mech-'+mode)
    command = [a.replace('link-arg='+str(old),'link-arg='+str(image)) for a in pin['command']]
    assert command != pin['command']
    command[command.index('-o')+1] = str(worker)
    trial.receipt.ROOT = stage
    trial.receipt.stage('link', command, pin['flags'])

def measure(mode):
    configure(target, prior/'mech-worker', target/'mech-worker')
    pins = mod.pins()
    previous = trial.read(prior/mode/'pins.json')
    worker = root/('probe-'+mode)/('mech-'+mode)
    workers = {'reference':previous['reference'], 'before':previous['after'],
               'after':{'command':[str(worker), mod.DESCRIPTOR, str(mod.FIXTURES)],
                        'binary_sha256':trial.digest(worker),'metadata_sha256':trial.digest(mod.DESCRIPTOR)}}
    for actor in workers.values():
        mod.CONTRACT.check_worker(actor)
    mod.CONTRACT.configure(target)
    mod.CONTRACT.COUNTER_CASES = cases
    mod.CONTRACT.checked_pins = lambda: pins | {'cohorts':{mode:workers},
                                                'fixture_inventory_sha256':trial.digest(mod.FIXTURES)}
    mod.execute(config/('measure-'+mode+'.py'),[])
    data = {}
    for case in cases:
        with gzip.open(target/mode/case/'observations.json.gz','rt') as source:
            body = json.load(source)
        data[case] = {}
        for actor, rows in body['observations'].items():
            samples = [row for row in rows if not row['warmup'] and not row['profile']]
            assert len(samples) == 24
            keys = ('instructions','cycles','lifetime_peak_physical') if mode=='cpu' else (
                'allocation_requests','allocation_bytes','reallocations','peak_live_bytes')
            if mode == 'memory':
                keys = [k for k in keys if k in samples[0]]
            data[case][actor] = {key:median(r[key] for r in samples) for key in keys}
        print(case, data[case], flush=True)
    trial.write(target/mode/'counters.json', data)

args = sys.argv[1:]
for arg in args:
    mode, action = arg.split('-')
    (setup if action=='setup' else measure)(mode)
