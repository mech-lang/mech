
/private/tmp/mech-pr973-merged-compression-20261112/matcher-min-select-dd33fb316f/read-temporary-root-bbc8791a5a/defaulted-read-compiler-final/decoded/decoded/object.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000000000f100 <_mech_compact_numeric_15296_no_growth_composed>:
    f100: d503237f     	pacibsp
    f104: a9bf7bfd     	stp	x29, x30, [sp, #-0x10]!
    f108: 910003fd     	mov	x29, sp
    f10c: a9bf73fb     	stp	x27, x28, [sp, #-0x10]!
    f110: a9bf6bf9     	stp	x25, x26, [sp, #-0x10]!
    f114: a9bf63f7     	stp	x23, x24, [sp, #-0x10]!
    f118: a9bf5bf5     	stp	x21, x22, [sp, #-0x10]!
    f11c: a9bf53f3     	stp	x19, x20, [sp, #-0x10]!
    f120: d10203ff     	sub	sp, sp, #0x80
    f124: f9406c2e     	ldr	x14, [x1, #0xd8]
    f128: f80603ee     	stur	x14, [sp, #0x60]
    f12c: f9400024     	ldr	x4, [x1]
    f130: f9400427     	ldr	x7, [x1, #0x8]
    f134: f940082b     	ldr	x11, [x1, #0x10]
    f138: f9400c20     	ldr	x0, [x1, #0x18]
    f13c: f9401028     	ldr	x8, [x1, #0x20]
    f140: f80683e8     	stur	x8, [sp, #0x68]
    f144: f940142f     	ldr	x15, [x1, #0x28]
    f148: f9401825     	ldr	x5, [x1, #0x30]
    f14c: f9401c26     	ldr	x6, [x1, #0x38]
    f150: f9402023     	ldr	x3, [x1, #0x40]
    f154: f9402423     	ldr	x3, [x1, #0x48]
    f158: f9402829     	ldr	x9, [x1, #0x50]
    f15c: f80703e9     	stur	x9, [sp, #0x70]
    f160: f9402c29     	ldr	x9, [x1, #0x58]
    f164: f9403023     	ldr	x3, [x1, #0x60]
    f168: f9403423     	ldr	x3, [x1, #0x68]
    f16c: f940382a     	ldr	x10, [x1, #0x70]
    f170: f9403c23     	ldr	x3, [x1, #0x78]
    f174: f9404023     	ldr	x3, [x1, #0x80]
    f178: f9404423     	ldr	x3, [x1, #0x88]
    f17c: f9404823     	ldr	x3, [x1, #0x90]
    f180: f9404c28     	ldr	x8, [x1, #0x98]
    f184: f9405028     	ldr	x8, [x1, #0xa0]
    f188: f9405428     	ldr	x8, [x1, #0xa8]
    f18c: f9405828     	ldr	x8, [x1, #0xb0]
    f190: f9405c28     	ldr	x8, [x1, #0xb8]
    f194: f9406028     	ldr	x8, [x1, #0xc0]
    f198: f9406428     	ldr	x8, [x1, #0xc8]
    f19c: f940682c     	ldr	x12, [x1, #0xd0]
    f1a0: d10004ed     	sub	x13, x7, #0x1
    f1a4: f100009f     	cmp	x4, #0x0
    f1a8: 54000321     	b.ne	0xf20c <_mech_compact_numeric_15296_no_growth_composed+0x10c>
    f1ac: f900044b     	str	x11, [x2, #0x8]
    f1b0: f9000840     	str	x0, [x2, #0x10]
    f1b4: f84683e1     	ldur	x1, [sp, #0x68]
    f1b8: f9000c41     	str	x1, [x2, #0x18]
    f1bc: f900104f     	str	x15, [x2, #0x20]
    f1c0: f900144c     	str	x12, [x2, #0x28]
    f1c4: f900184b     	str	x11, [x2, #0x30]
    f1c8: f9001c40     	str	x0, [x2, #0x38]
    f1cc: f900204c     	str	x12, [x2, #0x40]
    f1d0: f84683e0     	ldur	x0, [sp, #0x68]
    f1d4: f9002440     	str	x0, [x2, #0x48]
    f1d8: f900284f     	str	x15, [x2, #0x50]
    f1dc: f84603e0     	ldur	x0, [sp, #0x60]
    f1e0: f9002c40     	str	x0, [x2, #0x58]
    f1e4: d2800001     	mov	x1, #0x0                ; =0
    f1e8: aa0103e0     	mov	x0, x1
    f1ec: 910203ff     	add	sp, sp, #0x80
    f1f0: a8c153f3     	ldp	x19, x20, [sp], #0x10
    f1f4: a8c15bf5     	ldp	x21, x22, [sp], #0x10
    f1f8: a8c163f7     	ldp	x23, x24, [sp], #0x10
    f1fc: a8c16bf9     	ldp	x25, x26, [sp], #0x10
    f200: a8c173fb     	ldp	x27, x28, [sp], #0x10
    f204: a8c17bfd     	ldp	x29, x30, [sp], #0x10
    f208: d65f0fff     	retab
    f20c: eb0601bf     	cmp	x13, x6
    f210: 540018c2     	b.hs	0xf528 <_mech_compact_numeric_15296_no_growth_composed+0x428>
    f214: b86d78af     	ldr	w15, [x5, x13, lsl #2]
    f218: d350fdf4     	lsr	x20, x15, #16
    f21c: eb09029f     	cmp	x20, x9
    f220: 54001882     	b.hs	0xf530 <_mech_compact_numeric_15296_no_growth_composed+0x430>
    f224: f84703e7     	ldur	x7, [sp, #0x70]
    f228: b87478f5     	ldr	w21, [x7, x20, lsl #2]
    f22c: b4001860     	cbz	x0, 0xf538 <_mech_compact_numeric_15296_no_growth_composed+0x438>
    f230: d1002167     	sub	x7, x11, #0x8
    f234: d37df008     	lsl	x8, x0, #3
    f238: b86868f7     	ldr	w23, [x7, x8]
    f23c: 92403de7     	and	x7, x15, #0xffff
    f240: cb0701b3     	sub	x19, x13, x7
    f244: d2800016     	mov	x22, #0x0               ; =0
    f248: 0b1702a7     	add	w7, w21, w23
    f24c: 2a0703f7     	mov	w23, w7
    f250: 52800027     	mov	w7, #0x1                ; =1
    f254: 2a1424f4     	orr	w20, w7, w20, lsl #9
    f258: aa1303f5     	mov	x21, x19
    f25c: eb0d02bf     	cmp	x21, x13
    f260: 54000861     	b.ne	0xf36c <_mech_compact_numeric_15296_no_growth_composed+0x26c>
    f264: aa1482ed     	orr	x13, x23, x20, lsl #32
    f268: f820796d     	str	x13, [x11, x0, lsl #3]
    f26c: 92403de7     	and	x7, x15, #0xffff
    f270: f10000ff     	cmp	x7, #0x0
    f274: 540001e1     	b.ne	0xf2b0 <_mech_compact_numeric_15296_no_growth_composed+0x1b0>
    f278: f940082f     	ldr	x15, [x1, #0x10]
    f27c: f9401838     	ldr	x24, [x1, #0x30]
    f280: f9401c27     	ldr	x7, [x1, #0x38]
    f284: f9402839     	ldr	x25, [x1, #0x50]
    f288: f9402c3a     	ldr	x26, [x1, #0x58]
    f28c: d100048e     	sub	x14, x4, #0x1
    f290: 9280001b     	mov	x27, #-0x1              ; =-1
    f294: 9100041c     	add	x28, x0, #0x1
    f298: cb0403f4     	neg	x20, x4
    f29c: eb1301df     	cmp	x14, x19
    f2a0: fa479262     	ccmp	x19, x7, #0x2, ls
    f2a4: fa5b9004     	ccmp	x0, x27, #0x4, ls
    f2a8: fa541382     	ccmp	x28, x20, #0x2, ne
    f2ac: 540000c9     	b.ls	0xf2c4 <_mech_compact_numeric_15296_no_growth_composed+0x1c4>
    f2b0: d1000484     	sub	x4, x4, #0x1
    f2b4: d100066d     	sub	x13, x19, #0x1
    f2b8: 91000400     	add	x0, x0, #0x1
    f2bc: aa0003ef     	mov	x15, x0
    f2c0: 17ffffb9     	b	0xf1a4 <_mech_compact_numeric_15296_no_growth_composed+0xa4>
    f2c4: d1000484     	sub	x4, x4, #0x1
    f2c8: 91000400     	add	x0, x0, #0x1
    f2cc: f100009f     	cmp	x4, #0x0
    f2d0: 54000120     	b.eq	0xf2f4 <_mech_compact_numeric_15296_no_growth_composed+0x1f4>
    f2d4: d1000665     	sub	x5, x19, #0x1
    f2d8: b8657b05     	ldr	w5, [x24, x5, lsl #2]
    f2dc: 92403ca6     	and	x6, x5, #0xffff
    f2e0: f10000df     	cmp	x6, #0x0
    f2e4: 54000081     	b.ne	0xf2f4 <_mech_compact_numeric_15296_no_growth_composed+0x1f4>
    f2e8: d350fca5     	lsr	x5, x5, #16
    f2ec: eb1a00bf     	cmp	x5, x26
    f2f0: 54000283     	b.lo	0xf340 <_mech_compact_numeric_15296_no_growth_composed+0x240>
    f2f4: f9406c2e     	ldr	x14, [x1, #0xd8]
    f2f8: f80603ee     	stur	x14, [sp, #0x60]
    f2fc: f940082b     	ldr	x11, [x1, #0x10]
    f300: f9401025     	ldr	x5, [x1, #0x20]
    f304: f80683e5     	stur	x5, [sp, #0x68]
    f308: f9401825     	ldr	x5, [x1, #0x30]
    f30c: f9401c26     	ldr	x6, [x1, #0x38]
    f310: f9402829     	ldr	x9, [x1, #0x50]
    f314: f80703e9     	stur	x9, [sp, #0x70]
    f318: f9402c29     	ldr	x9, [x1, #0x58]
    f31c: f940382a     	ldr	x10, [x1, #0x70]
    f320: f9404827     	ldr	x7, [x1, #0x90]
    f324: f9404c27     	ldr	x7, [x1, #0x98]
    f328: f9405827     	ldr	x7, [x1, #0xb0]
    f32c: f9405c27     	ldr	x7, [x1, #0xb8]
    f330: f940682c     	ldr	x12, [x1, #0xd0]
    f334: d100066d     	sub	x13, x19, #0x1
    f338: aa0003ef     	mov	x15, x0
    f33c: 17ffff9a     	b	0xf1a4 <_mech_compact_numeric_15296_no_growth_composed+0xa4>
    f340: b8657b26     	ldr	w6, [x25, x5, lsl #2]
    f344: 0b0d00c6     	add	w6, w6, w13
    f348: 2a0603e6     	mov	w6, w6
    f34c: 52800027     	mov	w7, #0x1                ; =1
    f350: 2a0524e5     	orr	w5, w7, w5, lsl #9
    f354: aa0580cd     	orr	x13, x6, x5, lsl #32
    f358: f82079ed     	str	x13, [x15, x0, lsl #3]
    f35c: d1000484     	sub	x4, x4, #0x1
    f360: d1000673     	sub	x19, x19, #0x1
    f364: 91000400     	add	x0, x0, #0x1
    f368: 17ffffd9     	b	0xf2cc <_mech_compact_numeric_15296_no_growth_composed+0x1cc>
    f36c: eb0602bf     	cmp	x21, x6
    f370: 54000e82     	b.hs	0xf540 <_mech_compact_numeric_15296_no_growth_composed+0x440>
    f374: b87578b8     	ldr	w24, [x5, x21, lsl #2]
    f378: 90000007     	adrp	x7, 0xf000 <_mech_compact_numeric_15296_vector+0x580>
    f37c: f94000e7     	ldr	x7, [x7]
    f380: d350ff1a     	lsr	x26, x24, #16
    f384: 387a48e7     	ldrb	w7, [x7, w26, uxtw]
    f388: b867787b     	ldr	w27, [x3, x7, lsl #2]
    f38c: 92403f18     	and	x24, x24, #0xffff
    f390: d1000f07     	sub	x7, x24, #0x3
    f394: f103fcff     	cmp	x7, #0xff
    f398: 54000d88     	b.hi	0xf548 <_mech_compact_numeric_15296_no_growth_composed+0x448>
    f39c: d1000b07     	sub	x7, x24, #0x2
    f3a0: eb0702df     	cmp	x22, x7
    f3a4: 540008e2     	b.hs	0xf4c0 <_mech_compact_numeric_15296_no_growth_composed+0x3c0>
    f3a8: d1000b07     	sub	x7, x24, #0x2
    f3ac: cb1600e7     	sub	x7, x7, x22
    f3b0: f10040ff     	cmp	x7, #0x10
    f3b4: 54000282     	b.hs	0xf404 <_mech_compact_numeric_15296_no_growth_composed+0x304>
    f3b8: 91000ed9     	add	x25, x22, #0x3
    f3bc: b879794e     	ldr	w14, [x10, x25, lsl #2]
    f3c0: cb190019     	sub	x25, x0, x25
    f3c4: 8b190d7c     	add	x28, x11, x25, lsl #3
    f3c8: f8797979     	ldr	x25, [x11, x25, lsl #3]
    f3cc: 0b0e0368     	add	w8, w27, w14
    f3d0: 0b19010e     	add	w14, w8, w25
    f3d4: 6b1701df     	cmp	w14, w23
    f3d8: 9a9731d9     	csel	x25, x14, x23, lo
    f3dc: 11000ec8     	add	w8, w22, #0x3
    f3e0: 2a1a2508     	orr	w8, w8, w26, lsl #9
    f3e4: 9a943114     	csel	x20, x8, x20, lo
    f3e8: f10004ff     	cmp	x7, #0x1
    f3ec: 54000660     	b.eq	0xf4b8 <_mech_compact_numeric_15296_no_growth_composed+0x3b8>
    f3f0: 910012c7     	add	x7, x22, #0x4
    f3f4: 910006c8     	add	x8, x22, #0x1
    f3f8: d1000b0e     	sub	x14, x24, #0x2
    f3fc: cb0801d6     	sub	x22, x14, x8
    f400: 14000023     	b	0xf48c <_mech_compact_numeric_15296_no_growth_composed+0x38c>
    f404: 4e040ee1     	dup.4s	v1, w23
    f408: 4f07e7e7     	movi.16b	v7, #0xff
    f40c: 927ef4e7     	and	x7, x7, #0xfffffffffffffffc
    f410: 8b0702d7     	add	x23, x22, x7
    f414: 4ea71ce0     	mov.16b	v0, v7
    f418: eb1702df     	cmp	x22, x23
    f41c: 54000563     	b.lo	0xf4c8 <_mech_compact_numeric_15296_no_growth_composed+0x3c8>
    f420: d1000b07     	sub	x7, x24, #0x2
    f424: 6e014030     	ext.16b	v16, v1, v1, #0x8
    f428: 6eb06c30     	umin.4s	v16, v1, v16
    f42c: 4ea00a11     	rev64.4s	v17, v16
    f430: 6eb16e10     	umin.4s	v16, v16, v17
    f434: 0e043e19     	mov.s	w25, v16[0]
    f438: 6eb08c30     	cmeq.4s	v16, v1, v16
    f43c: 6e671c10     	bsl.16b	v16, v0, v7
    f440: 6e104211     	ext.16b	v17, v16, v16, #0x8
    f444: 6eb16e10     	umin.4s	v16, v16, v17
    f448: 4ea00a11     	rev64.4s	v17, v16
    f44c: 6eb16e10     	umin.4s	v16, v16, v17
    f450: 0e043e0e     	mov.s	w14, v16[0]
    f454: 11000dc8     	add	w8, w14, #0x3
    f458: 2a1a2516     	orr	w22, w8, w26, lsl #9
    f45c: 12800008     	mov	w8, #-0x1               ; =-1
    f460: 6b0801df     	cmp	w14, w8
    f464: 9a9412d4     	csel	x20, x22, x20, ne
    f468: eb0702ff     	cmp	x23, x7
    f46c: 54000262     	b.hs	0xf4b8 <_mech_compact_numeric_15296_no_growth_composed+0x3b8>
    f470: 91000ee7     	add	x7, x23, #0x3
    f474: d1000c0e     	sub	x14, x0, #0x3
    f478: 8b0e0d6e     	add	x14, x11, x14, lsl #3
    f47c: d10006e8     	sub	x8, x23, #0x1
    f480: cb080ddc     	sub	x28, x14, x8, lsl #3
    f484: d1000b0e     	sub	x14, x24, #0x2
    f488: cb1701d6     	sub	x22, x14, x23
    f48c: b8677948     	ldr	w8, [x10, x7, lsl #2]
    f490: b85f8f8e     	ldr	w14, [x28, #-0x8]!
    f494: 0b080368     	add	w8, w27, w8
    f498: 0b0e0108     	add	w8, w8, w14
    f49c: 6b19011f     	cmp	w8, w25
    f4a0: 9a993119     	csel	x25, x8, x25, lo
    f4a4: 2a1a24ee     	orr	w14, w7, w26, lsl #9
    f4a8: 910004e7     	add	x7, x7, #0x1
    f4ac: 9a9431d4     	csel	x20, x14, x20, lo
    f4b0: f10006d6     	subs	x22, x22, #0x1
    f4b4: 54fffec1     	b.ne	0xf48c <_mech_compact_numeric_15296_no_growth_composed+0x38c>
    f4b8: 2a1903f7     	mov	w23, w25
    f4bc: d1000b16     	sub	x22, x24, #0x2
    f4c0: 910006b5     	add	x21, x21, #0x1
    f4c4: 17ffff66     	b	0xf25c <_mech_compact_numeric_15296_no_growth_composed+0x15c>
    f4c8: 91003147     	add	x7, x10, #0xc
    f4cc: d37ef6c8     	lsl	x8, x22, #2
    f4d0: 3ce868e2     	ldr	q2, [x7, x8]
    f4d4: d1000c07     	sub	x7, x0, #0x3
    f4d8: 8b070d67     	add	x7, x11, x7, lsl #3
    f4dc: cb160ce7     	sub	x7, x7, x22, lsl #3
    f4e0: 3cde80fe     	ldur	q30, [x7, #-0x18]
    f4e4: 3cdf80ff     	ldur	q31, [x7, #-0x8]
    f4e8: 910012c7     	add	x7, x22, #0x4
    f4ec: 4e040f63     	dup.4s	v3, w27
    f4f0: 4ea28462     	add.4s	v2, v3, v2
    f4f4: 9c000463     	ldr	q3, 0xf580 <_mech_compact_numeric_15296_no_growth_composed+0x480>
    f4f8: 4e0323c3     	tbl.16b	v3, { v30, v31 }, v3
    f4fc: 4ea38442     	add.4s	v2, v2, v3
    f500: 6ea16c5f     	umin.4s	v31, v2, v1
    f504: 6ea2343b     	cmhi.4s	v27, v1, v2
    f508: 4e040ec1     	dup.4s	v1, w22
    f50c: 9c000422     	ldr	q2, 0xf590 <_mech_compact_numeric_15296_no_growth_composed+0x490>
    f510: 4ea28421     	add.4s	v1, v1, v2
    f514: 6e601c3b     	bsl.16b	v27, v1, v0
    f518: aa0703f6     	mov	x22, x7
    f51c: 4ebb1f60     	mov.16b	v0, v27
    f520: 4ebf1fe1     	mov.16b	v1, v31
    f524: 17ffffbd     	b	0xf418 <_mech_compact_numeric_15296_no_growth_composed+0x318>
    f528: d280000f     	mov	x15, #0x0               ; =0
    f52c: 17ffff3b     	b	0xf218 <_mech_compact_numeric_15296_no_growth_composed+0x118>
    f530: d2800015     	mov	x21, #0x0               ; =0
    f534: 17ffff3e     	b	0xf22c <_mech_compact_numeric_15296_no_growth_composed+0x12c>
    f538: d2800017     	mov	x23, #0x0               ; =0
    f53c: 17ffff40     	b	0xf23c <_mech_compact_numeric_15296_no_growth_composed+0x13c>
    f540: d2800018     	mov	x24, #0x0               ; =0
    f544: 17ffff8d     	b	0xf378 <_mech_compact_numeric_15296_no_growth_composed+0x278>
    f548: d28794a0     	mov	x0, #0x3ca5             ; =15525
    f54c: f9000040     	str	x0, [x2]
    f550: d2800120     	mov	x0, #0x9                ; =9
    f554: d28794a1     	mov	x1, #0x3ca5             ; =15525
    f558: 910203ff     	add	sp, sp, #0x80
    f55c: a8c153f3     	ldp	x19, x20, [sp], #0x10
    f560: a8c15bf5     	ldp	x21, x22, [sp], #0x10
    f564: a8c163f7     	ldp	x23, x24, [sp], #0x10
    f568: a8c16bf9     	ldp	x25, x26, [sp], #0x10
    f56c: a8c173fb     	ldp	x27, x28, [sp], #0x10
    f570: a8c17bfd     	ldp	x29, x30, [sp], #0x10
    f574: d65f0fff     	retab
		...
    f580: 1b1a1918     	madd	w24, w8, w26, w6
    f584: 13121110     	sbfiz	w16, w8, #14, #5
    f588: 0b0a0908     	add	w8, w8, w10, lsl #2
    f58c: 03020100     	<unknown>
    f590: 00000000     	udf	#0x0
    f594: 00000001     	udf	#0x1
    f598: 00000002     	udf	#0x2
    f59c: 00000003     	udf	#0x3
		...
