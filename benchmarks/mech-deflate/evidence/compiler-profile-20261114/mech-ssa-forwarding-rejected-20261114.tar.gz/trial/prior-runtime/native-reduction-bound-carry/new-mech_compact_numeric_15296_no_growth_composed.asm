
/private/tmp/mech-pr973-merged-compression-20261112/matcher-min-select-dd33fb316f/read-temporary-root-bbc8791a5a/parity-short-lowering-7bd03fbb1f/generated-carry/decoded/decoded/object.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000000000f100 <_mech_compact_numeric_15296_no_growth_composed>:
    f100: d503237f     	pacibsp
    f104: a9bf7bfd     	stp	x29, x30, [sp, #-0x10]!
    f108: 910003fd     	mov	x29, sp
    f10c: a9bf73fb     	stp	x27, x28, [sp, #-0x10]!
    f110: a9bf6bf9     	stp	x25, x26, [sp, #-0x10]!
    f114: a9bf63f7     	stp	x23, x24, [sp, #-0x10]!
    f118: a9bf5bf5     	stp	x21, x22, [sp, #-0x10]!
    f11c: a9bf53f3     	stp	x19, x20, [sp, #-0x10]!
    f120: d10203ff     	sub	sp, sp, #0x80
    f124: f9406c2e     	ldr	x14, [x1, #0xd8]
    f128: f80603ee     	stur	x14, [sp, #0x60]
    f12c: f9400024     	ldr	x4, [x1]
    f130: f940042d     	ldr	x13, [x1, #0x8]
    f134: f940082b     	ldr	x11, [x1, #0x10]
    f138: f9400c20     	ldr	x0, [x1, #0x18]
    f13c: f9401028     	ldr	x8, [x1, #0x20]
    f140: f80683e8     	stur	x8, [sp, #0x68]
    f144: f940142f     	ldr	x15, [x1, #0x28]
    f148: f9401825     	ldr	x5, [x1, #0x30]
    f14c: f9401c26     	ldr	x6, [x1, #0x38]
    f150: f9402023     	ldr	x3, [x1, #0x40]
    f154: f9402423     	ldr	x3, [x1, #0x48]
    f158: f9402829     	ldr	x9, [x1, #0x50]
    f15c: f80703e9     	stur	x9, [sp, #0x70]
    f160: f9402c29     	ldr	x9, [x1, #0x58]
    f164: f9403023     	ldr	x3, [x1, #0x60]
    f168: f9403423     	ldr	x3, [x1, #0x68]
    f16c: f940382a     	ldr	x10, [x1, #0x70]
    f170: f9403c23     	ldr	x3, [x1, #0x78]
    f174: f9404023     	ldr	x3, [x1, #0x80]
    f178: f9404423     	ldr	x3, [x1, #0x88]
    f17c: f9404823     	ldr	x3, [x1, #0x90]
    f180: f9404c27     	ldr	x7, [x1, #0x98]
    f184: f9405027     	ldr	x7, [x1, #0xa0]
    f188: f9405427     	ldr	x7, [x1, #0xa8]
    f18c: f9405827     	ldr	x7, [x1, #0xb0]
    f190: f9405c27     	ldr	x7, [x1, #0xb8]
    f194: f9406027     	ldr	x7, [x1, #0xc0]
    f198: f9406427     	ldr	x7, [x1, #0xc8]
    f19c: f940682c     	ldr	x12, [x1, #0xd0]
    f1a0: d10005ad     	sub	x13, x13, #0x1
    f1a4: f100009f     	cmp	x4, #0x0
    f1a8: 54000321     	b.ne	0xf20c <_mech_compact_numeric_15296_no_growth_composed+0x10c>
    f1ac: f900044b     	str	x11, [x2, #0x8]
    f1b0: f9000840     	str	x0, [x2, #0x10]
    f1b4: f84683e1     	ldur	x1, [sp, #0x68]
    f1b8: f9000c41     	str	x1, [x2, #0x18]
    f1bc: f900104f     	str	x15, [x2, #0x20]
    f1c0: f900144c     	str	x12, [x2, #0x28]
    f1c4: f900184b     	str	x11, [x2, #0x30]
    f1c8: f9001c40     	str	x0, [x2, #0x38]
    f1cc: f900204c     	str	x12, [x2, #0x40]
    f1d0: f84683e0     	ldur	x0, [sp, #0x68]
    f1d4: f9002440     	str	x0, [x2, #0x48]
    f1d8: f900284f     	str	x15, [x2, #0x50]
    f1dc: f84603e0     	ldur	x0, [sp, #0x60]
    f1e0: f9002c40     	str	x0, [x2, #0x58]
    f1e4: d2800001     	mov	x1, #0x0                ; =0
    f1e8: aa0103e0     	mov	x0, x1
    f1ec: 910203ff     	add	sp, sp, #0x80
    f1f0: a8c153f3     	ldp	x19, x20, [sp], #0x10
    f1f4: a8c15bf5     	ldp	x21, x22, [sp], #0x10
    f1f8: a8c163f7     	ldp	x23, x24, [sp], #0x10
    f1fc: a8c16bf9     	ldp	x25, x26, [sp], #0x10
    f200: a8c173fb     	ldp	x27, x28, [sp], #0x10
    f204: a8c17bfd     	ldp	x29, x30, [sp], #0x10
    f208: d65f0fff     	retab
    f20c: eb0601bf     	cmp	x13, x6
    f210: 54001862     	b.hs	0xf51c <_mech_compact_numeric_15296_no_growth_composed+0x41c>
    f214: b86d78af     	ldr	w15, [x5, x13, lsl #2]
    f218: d350fdf4     	lsr	x20, x15, #16
    f21c: eb09029f     	cmp	x20, x9
    f220: 54001822     	b.hs	0xf524 <_mech_compact_numeric_15296_no_growth_composed+0x424>
    f224: f84703e7     	ldur	x7, [sp, #0x70]
    f228: b87478f5     	ldr	w21, [x7, x20, lsl #2]
    f22c: b4001800     	cbz	x0, 0xf52c <_mech_compact_numeric_15296_no_growth_composed+0x42c>
    f230: d1002167     	sub	x7, x11, #0x8
    f234: d37df008     	lsl	x8, x0, #3
    f238: b86868f7     	ldr	w23, [x7, x8]
    f23c: 92403de7     	and	x7, x15, #0xffff
    f240: cb0701b3     	sub	x19, x13, x7
    f244: d280005c     	mov	x28, #0x2               ; =2
    f248: 0b1702a7     	add	w7, w21, w23
    f24c: 2a0703f6     	mov	w22, w7
    f250: 52800027     	mov	w7, #0x1                ; =1
    f254: 2a1424f4     	orr	w20, w7, w20, lsl #9
    f258: aa1303f5     	mov	x21, x19
    f25c: eb0d02bf     	cmp	x21, x13
    f260: 54000861     	b.ne	0xf36c <_mech_compact_numeric_15296_no_growth_composed+0x26c>
    f264: aa1482cd     	orr	x13, x22, x20, lsl #32
    f268: f820796d     	str	x13, [x11, x0, lsl #3]
    f26c: 92403de7     	and	x7, x15, #0xffff
    f270: f10000ff     	cmp	x7, #0x0
    f274: 540001e1     	b.ne	0xf2b0 <_mech_compact_numeric_15296_no_growth_composed+0x1b0>
    f278: f940082f     	ldr	x15, [x1, #0x10]
    f27c: f9401834     	ldr	x20, [x1, #0x30]
    f280: f9401c27     	ldr	x7, [x1, #0x38]
    f284: f9402835     	ldr	x21, [x1, #0x50]
    f288: f9402c36     	ldr	x22, [x1, #0x58]
    f28c: d100048e     	sub	x14, x4, #0x1
    f290: 92800017     	mov	x23, #-0x1              ; =-1
    f294: 91000418     	add	x24, x0, #0x1
    f298: cb0403f9     	neg	x25, x4
    f29c: eb1301df     	cmp	x14, x19
    f2a0: fa479262     	ccmp	x19, x7, #0x2, ls
    f2a4: fa579004     	ccmp	x0, x23, #0x4, ls
    f2a8: fa591302     	ccmp	x24, x25, #0x2, ne
    f2ac: 540000c9     	b.ls	0xf2c4 <_mech_compact_numeric_15296_no_growth_composed+0x1c4>
    f2b0: d1000484     	sub	x4, x4, #0x1
    f2b4: d100066d     	sub	x13, x19, #0x1
    f2b8: 91000400     	add	x0, x0, #0x1
    f2bc: aa0003ef     	mov	x15, x0
    f2c0: 17ffffb9     	b	0xf1a4 <_mech_compact_numeric_15296_no_growth_composed+0xa4>
    f2c4: d1000484     	sub	x4, x4, #0x1
    f2c8: 91000400     	add	x0, x0, #0x1
    f2cc: f100009f     	cmp	x4, #0x0
    f2d0: 54000120     	b.eq	0xf2f4 <_mech_compact_numeric_15296_no_growth_composed+0x1f4>
    f2d4: d1000665     	sub	x5, x19, #0x1
    f2d8: b8657a85     	ldr	w5, [x20, x5, lsl #2]
    f2dc: 92403ca6     	and	x6, x5, #0xffff
    f2e0: f10000df     	cmp	x6, #0x0
    f2e4: 54000081     	b.ne	0xf2f4 <_mech_compact_numeric_15296_no_growth_composed+0x1f4>
    f2e8: d350fca5     	lsr	x5, x5, #16
    f2ec: eb1600bf     	cmp	x5, x22
    f2f0: 54000283     	b.lo	0xf340 <_mech_compact_numeric_15296_no_growth_composed+0x240>
    f2f4: f9406c2e     	ldr	x14, [x1, #0xd8]
    f2f8: f80603ee     	stur	x14, [sp, #0x60]
    f2fc: f940082b     	ldr	x11, [x1, #0x10]
    f300: f9401025     	ldr	x5, [x1, #0x20]
    f304: f80683e5     	stur	x5, [sp, #0x68]
    f308: f9401825     	ldr	x5, [x1, #0x30]
    f30c: f9401c26     	ldr	x6, [x1, #0x38]
    f310: f9402829     	ldr	x9, [x1, #0x50]
    f314: f80703e9     	stur	x9, [sp, #0x70]
    f318: f9402c29     	ldr	x9, [x1, #0x58]
    f31c: f940382a     	ldr	x10, [x1, #0x70]
    f320: f9404827     	ldr	x7, [x1, #0x90]
    f324: f9404c27     	ldr	x7, [x1, #0x98]
    f328: f9405827     	ldr	x7, [x1, #0xb0]
    f32c: f9405c27     	ldr	x7, [x1, #0xb8]
    f330: f940682c     	ldr	x12, [x1, #0xd0]
    f334: d100066d     	sub	x13, x19, #0x1
    f338: aa0003ef     	mov	x15, x0
    f33c: 17ffff9a     	b	0xf1a4 <_mech_compact_numeric_15296_no_growth_composed+0xa4>
    f340: b8657aa6     	ldr	w6, [x21, x5, lsl #2]
    f344: 0b0d00c6     	add	w6, w6, w13
    f348: 2a0603e6     	mov	w6, w6
    f34c: 52800027     	mov	w7, #0x1                ; =1
    f350: 2a0524e5     	orr	w5, w7, w5, lsl #9
    f354: aa0580cd     	orr	x13, x6, x5, lsl #32
    f358: f82079ed     	str	x13, [x15, x0, lsl #3]
    f35c: d1000484     	sub	x4, x4, #0x1
    f360: d1000673     	sub	x19, x19, #0x1
    f364: 91000400     	add	x0, x0, #0x1
    f368: 17ffffd9     	b	0xf2cc <_mech_compact_numeric_15296_no_growth_composed+0x1cc>
    f36c: eb0602bf     	cmp	x21, x6
    f370: 54000e22     	b.hs	0xf534 <_mech_compact_numeric_15296_no_growth_composed+0x434>
    f374: b87578b9     	ldr	w25, [x5, x21, lsl #2]
    f378: 90000007     	adrp	x7, 0xf000 <_mech_compact_numeric_15296_vector+0x580>
    f37c: f94000e7     	ldr	x7, [x7]
    f380: d350ff37     	lsr	x23, x25, #16
    f384: 387748e7     	ldrb	w7, [x7, w23, uxtw]
    f388: b8677878     	ldr	w24, [x3, x7, lsl #2]
    f38c: 92403f39     	and	x25, x25, #0xffff
    f390: d1000f27     	sub	x7, x25, #0x3
    f394: f103fcff     	cmp	x7, #0xff
    f398: 54000d28     	b.hi	0xf53c <_mech_compact_numeric_15296_no_growth_composed+0x43c>
    f39c: eb19039f     	cmp	x28, x25
    f3a0: 540008a2     	b.hs	0xf4b4 <_mech_compact_numeric_15296_no_growth_composed+0x3b4>
    f3a4: cb1c0327     	sub	x7, x25, x28
    f3a8: f10040ff     	cmp	x7, #0x10
    f3ac: 54000242     	b.hs	0xf3f4 <_mech_compact_numeric_15296_no_growth_composed+0x2f4>
    f3b0: 9100079a     	add	x26, x28, #0x1
    f3b4: b87a794e     	ldr	w14, [x10, x26, lsl #2]
    f3b8: cb1a001a     	sub	x26, x0, x26
    f3bc: 8b1a0d7b     	add	x27, x11, x26, lsl #3
    f3c0: f87a797a     	ldr	x26, [x11, x26, lsl #3]
    f3c4: 0b0e0308     	add	w8, w24, w14
    f3c8: 0b1a010e     	add	w14, w8, w26
    f3cc: 6b1601df     	cmp	w14, w22
    f3d0: 9a9631da     	csel	x26, x14, x22, lo
    f3d4: 11000788     	add	w8, w28, #0x1
    f3d8: 2a172508     	orr	w8, w8, w23, lsl #9
    f3dc: 9a943114     	csel	x20, x8, x20, lo
    f3e0: f10004ff     	cmp	x7, #0x1
    f3e4: 54000640     	b.eq	0xf4ac <_mech_compact_numeric_15296_no_growth_composed+0x3ac>
    f3e8: 91000b9c     	add	x28, x28, #0x2
    f3ec: d10004e7     	sub	x7, x7, #0x1
    f3f0: 14000024     	b	0xf480 <_mech_compact_numeric_15296_no_growth_composed+0x380>
    f3f4: d1000b9a     	sub	x26, x28, #0x2
    f3f8: 4e040ec1     	dup.4s	v1, w22
    f3fc: 4f07e7e3     	movi.16b	v3, #0xff
    f400: 927ef4e7     	and	x7, x7, #0xfffffffffffffffc
    f404: 8b070356     	add	x22, x26, x7
    f408: 4ea31c60     	mov.16b	v0, v3
    f40c: eb16035f     	cmp	x26, x22
    f410: 54000563     	b.lo	0xf4bc <_mech_compact_numeric_15296_no_growth_composed+0x3bc>
    f414: d1000b27     	sub	x7, x25, #0x2
    f418: 6e014026     	ext.16b	v6, v1, v1, #0x8
    f41c: 6ea66c26     	umin.4s	v6, v1, v6
    f420: 4ea008c7     	rev64.4s	v7, v6
    f424: 6ea76cc6     	umin.4s	v6, v6, v7
    f428: 0e043cda     	mov.s	w26, v6[0]
    f42c: 6ea68c25     	cmeq.4s	v5, v1, v6
    f430: 6e631c05     	bsl.16b	v5, v0, v3
    f434: 6e0540a6     	ext.16b	v6, v5, v5, #0x8
    f438: 6ea66ca6     	umin.4s	v6, v5, v6
    f43c: 4ea008c7     	rev64.4s	v7, v6
    f440: 6ea76cc6     	umin.4s	v6, v6, v7
    f444: 0e043cce     	mov.s	w14, v6[0]
    f448: 11000dc8     	add	w8, w14, #0x3
    f44c: 2a17251b     	orr	w27, w8, w23, lsl #9
    f450: 12800008     	mov	w8, #-0x1               ; =-1
    f454: 6b0801df     	cmp	w14, w8
    f458: 9a941374     	csel	x20, x27, x20, ne
    f45c: eb0702df     	cmp	x22, x7
    f460: 54000262     	b.hs	0xf4ac <_mech_compact_numeric_15296_no_growth_composed+0x3ac>
    f464: 91000edc     	add	x28, x22, #0x3
    f468: d1000c0e     	sub	x14, x0, #0x3
    f46c: 8b0e0d6e     	add	x14, x11, x14, lsl #3
    f470: d10006c7     	sub	x7, x22, #0x1
    f474: cb070ddb     	sub	x27, x14, x7, lsl #3
    f478: d1000b2e     	sub	x14, x25, #0x2
    f47c: cb1601c7     	sub	x7, x14, x22
    f480: b87c794e     	ldr	w14, [x10, x28, lsl #2]
    f484: b85f8f68     	ldr	w8, [x27, #-0x8]!
    f488: 0b0e030e     	add	w14, w24, w14
    f48c: 0b0801ce     	add	w14, w14, w8
    f490: 6b1a01df     	cmp	w14, w26
    f494: 9a9a31da     	csel	x26, x14, x26, lo
    f498: 2a17278e     	orr	w14, w28, w23, lsl #9
    f49c: 9100079c     	add	x28, x28, #0x1
    f4a0: 9a9431d4     	csel	x20, x14, x20, lo
    f4a4: f10004e7     	subs	x7, x7, #0x1
    f4a8: 54fffec1     	b.ne	0xf480 <_mech_compact_numeric_15296_no_growth_composed+0x380>
    f4ac: 2a1a03f6     	mov	w22, w26
    f4b0: aa1903fc     	mov	x28, x25
    f4b4: 910006b5     	add	x21, x21, #0x1
    f4b8: 17ffff69     	b	0xf25c <_mech_compact_numeric_15296_no_growth_composed+0x15c>
    f4bc: 91003147     	add	x7, x10, #0xc
    f4c0: d37ef748     	lsl	x8, x26, #2
    f4c4: 3ce868fb     	ldr	q27, [x7, x8]
    f4c8: d1000c07     	sub	x7, x0, #0x3
    f4cc: 8b070d67     	add	x7, x11, x7, lsl #3
    f4d0: cb1a0ce7     	sub	x7, x7, x26, lsl #3
    f4d4: 3cde80fe     	ldur	q30, [x7, #-0x18]
    f4d8: 3cdf80ff     	ldur	q31, [x7, #-0x8]
    f4dc: 91001347     	add	x7, x26, #0x4
    f4e0: 4e040f1c     	dup.4s	v28, w24
    f4e4: 4ebb879b     	add.4s	v27, v28, v27
    f4e8: 9c00045a     	ldr	q26, 0xf570 <_mech_compact_numeric_15296_no_growth_composed+0x470>
    f4ec: 4e1a23dc     	tbl.16b	v28, { v30, v31 }, v26
    f4f0: 4ebc877c     	add.4s	v28, v27, v28
    f4f4: 6ea16f9b     	umin.4s	v27, v28, v1
    f4f8: 6ebc3437     	cmhi.4s	v23, v1, v28
    f4fc: 4e040f5c     	dup.4s	v28, w26
    f500: 9c00041d     	ldr	q29, 0xf580 <_mech_compact_numeric_15296_no_growth_composed+0x480>
    f504: 4ebd879c     	add.4s	v28, v28, v29
    f508: 6e601f97     	bsl.16b	v23, v28, v0
    f50c: aa0703fa     	mov	x26, x7
    f510: 4eb71ee0     	mov.16b	v0, v23
    f514: 4ebb1f61     	mov.16b	v1, v27
    f518: 17ffffbd     	b	0xf40c <_mech_compact_numeric_15296_no_growth_composed+0x30c>
    f51c: d280000f     	mov	x15, #0x0               ; =0
    f520: 17ffff3e     	b	0xf218 <_mech_compact_numeric_15296_no_growth_composed+0x118>
    f524: d2800015     	mov	x21, #0x0               ; =0
    f528: 17ffff41     	b	0xf22c <_mech_compact_numeric_15296_no_growth_composed+0x12c>
    f52c: d2800017     	mov	x23, #0x0               ; =0
    f530: 17ffff43     	b	0xf23c <_mech_compact_numeric_15296_no_growth_composed+0x13c>
    f534: d2800019     	mov	x25, #0x0               ; =0
    f538: 17ffff90     	b	0xf378 <_mech_compact_numeric_15296_no_growth_composed+0x278>
    f53c: d28794a0     	mov	x0, #0x3ca5             ; =15525
    f540: f9000040     	str	x0, [x2]
    f544: d2800120     	mov	x0, #0x9                ; =9
    f548: d28794a1     	mov	x1, #0x3ca5             ; =15525
    f54c: 910203ff     	add	sp, sp, #0x80
    f550: a8c153f3     	ldp	x19, x20, [sp], #0x10
    f554: a8c15bf5     	ldp	x21, x22, [sp], #0x10
    f558: a8c163f7     	ldp	x23, x24, [sp], #0x10
    f55c: a8c16bf9     	ldp	x25, x26, [sp], #0x10
    f560: a8c173fb     	ldp	x27, x28, [sp], #0x10
    f564: a8c17bfd     	ldp	x29, x30, [sp], #0x10
    f568: d65f0fff     	retab
    f56c: 00000000     	udf	#0x0
    f570: 1b1a1918     	madd	w24, w8, w26, w6
    f574: 13121110     	sbfiz	w16, w8, #14, #5
    f578: 0b0a0908     	add	w8, w8, w10, lsl #2
    f57c: 03020100     	<unknown>
    f580: 00000000     	udf	#0x0
    f584: 00000001     	udf	#0x1
    f588: 00000002     	udf	#0x2
    f58c: 00000003     	udf	#0x3
		...
