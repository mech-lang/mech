"""Check ordinary native output, retention of linked addresses, and direct parser controls."""
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
current, history, _, corpus = root.parents[:4]
sys.path.insert(0, str(history))
from composed_record_count import SYMBOL, trial
from measure_second_hint import mod

prior = history / 'roc-parity-baseline-80ddb85f4b/first-owner-slot/final'
known = history / 'roc-parity-baseline-80ddb85f4b/short-scalar/direct'

def machine():
    entries = trial.read(root / 'machine.json')
    expected = {
        f'mech_compact_numeric_{site}_no_growth_composed'
        for site in (12419, 15296, 26895, 31086)
    }
    assert set(entries) == expected
    assert all(row['addresses'][0] == row['addresses'][1] and row['addresses'][2] == row['addresses'][3]
               for row in entries.values())
    control, new = [path.read_bytes() for path in (prior/'mech-worker', root/'candidate/mech-worker')]
    sections, commands = trial.isolate.macho(control)
    assert (sections, commands) == trial.isolate.macho(new)
    assert len(control) == len(new)
    a, _, start, *_ = sections[b'__TEXT', b'__text']
    (uuid, uuid_span), = commands[0x1b]
    (signature, _), = commands[0x1d]
    import struct
    sa, ss = struct.unpack_from('<II', control, signature + 8)
    excludes = [(uuid+8, uuid+uuid_span),(sa,sa+ss)]
    for row in entries.values():
        pc = row['addresses'][2]-a+start
        width = max(item[0] for item in row['bytes_stack'])
        excludes.append((pc,pc+width))
    assert trial.isolate.masked(control, excludes) == trial.isolate.masked(new, excludes)
    print('linked executable identical outside four composed variants, UUID and signature', flush=True)

def direct():
    output = root/'direct'
    output.mkdir(exist_ok=True)
    trial.receipt.ROOT = output
    image = root/'decoded/decoded/object.o'
    for case in ('oracle','boundaries'):
        pin = trial.read(known / ('build-'+case+'-candidate.json'))
        command = [str(image) if arg.endswith('/short-scalar/object.o') else arg for arg in pin['command']]
        if command == pin['command']:
            (arg,) = [arg for arg in command if arg.endswith('/object.o')]
            command[command.index(arg)] = str(image)
        cmd = output / case
        command[command.index('-o')+1] = str(cmd)
        trial.receipt.stage('build-'+case, command, pin['flags'])
        symbols = trial.isolate.symbols(cmd)
        entry, = symbols['_mech_compact_closed_v2']
        sites = [str(symbols['_'+symbol][0]-entry) for symbol in (SYMBOL.removesuffix('_composed'), SYMBOL)]
        trial.receipt.stage(case, [cmd, *sites])
        actual = (output/(case+'.stdout')).read_text()
        assert actual == (known/(case+'-retained.stdout')).read_text()
        print(actual.strip(), flush=True)

def original():
    old, new = [root/f/f/'object.o' for f in ('decoded','original')]
    assert old.read_bytes() == new.read_bytes()
    am,bm = [trial.read(path.with_name('metadata.json')) for path in (old, new)]
    expected = bm.pop('source_input_form')
    assert am.pop('source_input_form') != expected and am == bm
    for flavor, md in [('original',new.with_name('metadata.json')), ('decoded',old.with_name('metadata.json'))]:
        trial.receipt.ROOT = root/'candidate'
        tag = 'compiled-carry-bound-' + flavor + '-restored-fixtures'
        trial.receipt.stage('qualify-restored-'+flavor, [sys.executable, '-B', trial.RUN/'verify-worker.py',
                                               root/'candidate/mech-worker', md, tag])
        receipt = trial.read(trial.RUN/(tag+'-qualification.json'))
        assert receipt['verified'] and receipt['complete_smokes'] == 162
        trial.write(trial.receipt.ROOT/('qualification-'+flavor+'.json'),receipt)
    print('original/decoded identical Object; 324 exact linked checks', flush=True)

for action in sys.argv[1:]:
    globals()[action]()
