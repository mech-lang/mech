"""Capture and attribute CPU-time samples on the exact matched binaries."""
from pathlib import Path
from hashlib import file_digest
import json
import re
import sys

root = Path(__file__).resolve().parent
run = root.parents[3]
here = root/'profiles'
here.mkdir(exist_ok=True)
sys.path.insert(0,str(run/'frontier-profiles-ef7819f6c9'))
import recovery_contract as contract

cases=('prefix-natural-1048576','heldout-slides-65537')
actors=('mech-experiment','roc','libdeflate')
pins=json.loads((root/'candidate/full-repeat/pins.json').read_text())
contract.ROOT=here
contract.assert_idle()
for actor in actors:
    pin=pins['actors'][actor]
    for index, key in [(0,'binary_sha256'),(1,'metadata_sha256')]:
        if key in pin:
            with open(pin['command'][index],'rb') as stream:
                assert file_digest(stream,'sha256').hexdigest()==pin[key]
contract.checked_pins=lambda: pins
contract.PROFILE_CASES=cases
helper=run/'integrated-checked-in/capture-profiles.py'
program=helper.read_text()
program=program.replace("pins = json.loads((root / 'library-all/pins.json').read_text())","pins = anchor_pins")
program=program.replace('actor = path.name','actor = path.parent.name')
program=program.replace("Path(command[0]).name == 'mech-worker'","actor == CANDIDATE")
ifelse='assert result.get(\'exact_reference\', result.get(\'matches_reference_bytes\'))'
program=program.replace(ifelse, """if actor == 'libdeflate':
                        assert result['level'] == 12 and result['version'] == '1.26'
                        assert result['matches_reference_bytes'] == expected_lib[case]['matches_reference_bytes']
                        assert result['output_sha256'] == expected_lib[case]['output_sha256']
                    else:
                        assert result['exact_reference']""")
start=program.index('plan = [')
end=program.index('\nassert len(cases)',start)
program=program[:start]+'''plan = [(case, pins['actors'][actor], root / actor / case)
        for case in PROFILE_CASES for actor in selected]
'''+program[end:]
lib=Path(pins['actors']['libdeflate']['command'][0]).parent
expected={r['case']:r for r in json.loads((lib/'smoke-result.json').read_text())}
sys.argv=[str(helper), *sys.argv[1:]]
exec(compile(program,str(helper),'exec'),
     {'__file__':str(helper),'__name__':'__main__','selected':actors,'expected_lib':expected})

helper=run/'integrated-checked-in/summarize-profiles.py'
body=helper.read_text().split('\nfrom recovery_contract import (',1)[0]
body=body.replace('pcs.most_common(20)','pcs.most_common()')
scope={'__file__':str(helper)}
exec(compile(body,str(helper),'exec'),scope)
records={}
for actor in actors:
    records[actor]={}
    for case in cases:
        report=scope['sample_profile'](here/actor/case,all_symbols=True)
        assert report['worker_sha256']==pins['actors'][actor]['binary_sha256']
        assert sum(value for _,value in report['mapped_pc_counts'])==report['running_timer_pcs']
        records[actor][case]=report
        print(actor,case,report['running_timer_pcs'], report['mapped_pc_counts'][:4],flush=True)
(here/'summary.json').write_text(json.dumps(records,indent=2)+'\n')
