from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
history = root.parents[1]
previous = history/'defaulted-read-compiler-final/focus'
repo = Path('/private/tmp/mech-pr973-publish-20261112')
sources = repo/'hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup'
sys.path.insert(0, str(history))
from composed_record_count import trial

folder = root/'focus'
folder.mkdir(exist_ok=True)
main = folder/'main.rs'
main.write_text(f'''mod native_artifact {{
    #![allow(dead_code)]
    mod program {{
        mod codegen {{
            mod cfg_cleanup {{
                #[path = "{previous/'composed_reads.rs'}"]
                mod composed_reads;
                #[path = "{previous/'word_ranges.rs'}"]
                mod word_ranges;
                #[path = "{previous/'boolean_conditions.rs'}"]
                mod boolean_conditions;
                pub(super) use boolean_conditions::masked_integer_comparison;
                #[path = "{previous/'window_bounds.rs'}"]
                mod window_bounds;
                #[path = "{sources/'boolean_words.rs'}"]
                mod boolean_words;
                #[path = "{sources/'selected_ranges.rs'}"]
                mod selected_ranges;
                #[path = "{sources/'reduction_bound.rs'}"]
                mod reduction_bound;
            }}
        }}
    }}
}}
''')
pin = trial.read(previous/'build-focused.json')
command = [a.replace(str(previous/'main.rs'),str(main)).replace(str(previous/'test'),str(folder/'test'))
           for a in pin['command']]
trial.receipt.ROOT = folder
trial.receipt.stage('build', command, pin['flags'])
trial.receipt.stage('test', [folder/'test','reduction_bound::tests','--nocapture'])
print((folder/'test.stdout').read_text(),flush=True)
