"""Compare emitted parser bodies, root entry, and linked addresses."""
from hashlib import sha256
from pathlib import Path
import json
import subprocess
import sys

root = Path(__file__).resolve().parent
s, h, _, p = root.parents[:4]
sys.path.insert(0, str(p / 'reduction-variant-isolation-4fff511238'))
import isolate

def read(path):
    return json.loads(path.read_text())

def take(path, syms):
    blob = path.read_bytes()
    pos, _, start, *_ = isolate.macho(blob)[0][b'__TEXT', b'__text']
    def span(name, length):
        (address,) = syms['_' + name]
        at = start + address - pos
        return blob[at:at + length]
    return span

def phases(article):
    if isinstance(article, list):
        for nested in article:
            yield from phases(nested)
    elif isinstance(article, dict):
        if article.keys() >= {'symbol', 'code_bytes', 'stack_bytes'}:
            yield article
        for item in article.values():
            if isinstance(item, (list, dict)):
                yield from phases(item)

a = h / 'defaulted-read-compiler-final/decoded/decoded'
b = root / 'decoded/decoded'
control = h / 'roc-parity-baseline-80ddb85f4b/first-owner-slot/final'
paths = [a / 'object.o', b / 'object.o', control / 'mech-worker', root / 'candidate/mech-worker']
names = [isolate.symbols(path) for path in paths]
objects = [take(path, syms) for path, syms in zip(paths[:2], names[:2])]
before, after = (read(path / 'metadata.json') for path in (a, b))
meta = [ {v['symbol']: v for v in phases([m, m['numeric_phases']])} for m in (before, after) ]
assert meta[0].keys() == meta[1].keys()
data = {}
for symbol in sorted(meta[0]):
    summaries = [(row[symbol]['code_bytes'], row[symbol]['stack_bytes']) for row in meta]
    payloads = [image(symbol, length) for image, (length, _) in zip(objects, summaries)]
    bodies_identical = payloads[0] == payloads[1]
    if summaries[0] != summaries[1] or not bodies_identical:
        addresses = [table['_' + symbol][0] for table in names]
        data[symbol] = dict(bytes_stack=summaries, addresses=addresses,
                            sha256=[sha256(body).hexdigest() for body in payloads],
                            identical=bodies_identical)
        print(symbol, summaries, [hex(x) for x in addresses], 'delta', addresses[3] - addresses[2])
for name in ('mech_compact_closed_v2', 'mech_compact_numeric_15296_no_growth_composed'):
    for actor, path in zip(('old', 'new'), paths[:2]):
        if name == 'mech_compact_closed_v2':
            cmd = ['xcrun', 'llvm-objdump', '--disassemble-symbols=_' + name, path]
        else:
            cmd = ['xcrun', 'llvm-objdump', '--disassemble-symbols=_' + name, path]
        raw = subprocess.check_output(cmd, text=True)
        (root / f'{actor}-{name}.asm').write_text(raw)
(root / 'machine.json').write_text(json.dumps(data, indent=2) + '\n')
