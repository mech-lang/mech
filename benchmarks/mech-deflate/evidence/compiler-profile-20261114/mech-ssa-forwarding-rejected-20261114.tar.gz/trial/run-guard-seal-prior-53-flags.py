from pathlib import Path
import os,json,subprocess,sys,hashlib
repo=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech');root=Path('/private/tmp/mech-guard-seal-20261114');prior=Path('/private/tmp/mech-lexical-index-20261114')
flags=json.loads((prior/'candidate-1-command.json').read_text())['flags'];assert len(flags)==53
env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')};env.update(flags)
variant,name=sys.argv[1:3];cmd=[sys.executable,'benchmarks/mech-deflate/native-profile/profile_compile.py',str(root/variant),'benchmark',str(root/name),'compact']
assert not (root/name).exists(),f'existing observation {name}'
(root/(name+'-command.json')).write_text(json.dumps({'command':cmd,'flags':flags,'binary_sha256':hashlib.sha256((root/variant).read_bytes()).hexdigest()},indent=2)+'\n')
p=subprocess.run(cmd,env=env,cwd=repo)
if p.returncode:raise SystemExit(p.returncode)
report={}
for filename in ['source.mec','program.mecb','program.o','metadata.json']:
 data=(root/name/filename).read_bytes();previous=(prior/'candidate-1'/filename).read_bytes()
 report[filename]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'matches_previous_qualified_output':data==previous}
(root/name/'output-check.json').write_text(json.dumps(report,indent=2)+'\n');print('OUTPUTS',name,json.dumps(report),flush=True)
if not name.startswith('candidate-screen'):assert all(row['matches_previous_qualified_output'] for row in report.values()),'qualified output changed'
