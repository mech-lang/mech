from pathlib import Path
import hashlib,json,re,statistics,math,zlib
root=Path(__file__).resolve().parent;raw=root/'trial';read=lambda p:json.loads(p.read_text());original=Path('/private/tmp/mech-guard-seal-20261114')
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
state=read(raw/'source-state.json');build=read(raw/'candidate-build.json');control=read(raw/'control-origin.json');excluded={r['path']:r for r in read(root/'excluded-build-and-download-files.json')}
assert build['exit_code']==0 and build['head']==state['base_commit']
assert pin(raw/'candidate.patch')==pin(root/'source-change.patch')
assert pin(raw/'candidate.patch')['sha256']==state['patch_sha256']==build['patch_sha256']
assert build['binary_sha256']=='e5eaebe0383a489a4c5177078bb3643bf3a3bc611c43882a33b3e055e44cf776'
assert control['sha256']=='f56537463758c6ab00403d7bdead4a1caba2c44342bb9abae9fccb58bd49c522'
assert excluded['candidate']['sha256']==build['binary_sha256'] and excluded['control']['sha256']==control['sha256']
assert read(raw/'forwarding-initial-candidate-build.json')['binary_sha256']==build['binary_sha256']
prior=read(root/'validation/lexical-index-compile-apple-m3-20261114.json');assert prior['compiler_binary_sha256']['candidate']==control['sha256']
flags=read(raw/'runtime-flags.json');assert len(flags)==54 and flags['MECH_NORMALIZE_DEFAULTED_READ_SETUP']=='1'
assert read(raw/'runtime-flags-discovery.json')['prior_profile_flags_count']==53
rows=read(raw/'cohort.json');assert [r['variant'] for r in rows]==['control','candidate','candidate','control']
outputs={v:{n:pin(raw/(v+'-1')/n) for n in ['source.mec','program.mecb','program.o','metadata.json']} for v in ['control','candidate']}
assert outputs['control']['source.mec']==outputs['candidate']['source.mec'] and outputs['control']['program.mecb']==outputs['candidate']['program.mecb']
assert outputs['control']['program.o']['sha256']=='b125164d7e8ba9d4e98cb4b467b3194bb14a6d8cafe411600359c6f67943c703'
assert outputs['candidate']['program.o']['sha256']=='66bface4f334fd291e6f8e048884e027e6134cdc9164c378938052697155cd87'
for row in rows:
 d=raw/row['name'];assert read(d/'compile.json')==row['compile'] and read(d/'process.json')==row['process'] and row['process']['exit_code']==0 and row['process']['samples']==0
 command=read(raw/(row['name']+'-command.json'));assert command['flags']==flags and command['binary_sha256']==(build['binary_sha256'] if row['variant']=='candidate' else control['sha256'])
 for filename,pinned in outputs[row['variant']].items():assert pin(d/filename)==pinned and {k:row['files'][filename][k] for k in ['bytes','sha256']}==pinned
 stamps=[json.loads(l) for l in (d/'stages.jsonl').read_text().splitlines()]
 for key,begin,end in [('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]:assert row[key]==next(s['elapsed'] for s in stamps if s['line'].startswith(end))-next(s['elapsed'] for s in stamps if s['line'].startswith(begin))
 for key,pattern in [('max_rss_bytes',r'(\d+)  maximum resident set size'),('instructions',r'(\d+)  instructions retired'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]:assert row[key]==int(re.search(pattern,(d/'stderr.log').read_text()).group(1))
assert read(raw/'ssa-test-command.json')['exit_code']==0
assert re.findall(r'test result: ok\. (\d+) passed',(raw/'ssa-tests.log').read_text())==['16']
assert read(raw/'ssa-test-command.json.initial-test-oracle')['exit_code']==101
assert 'FAILED' in (raw/'ssa-tests.log.initial-test-oracle').read_text()
for screen in ['candidate-screen','candidate-screen-forwarding']:
 assert len(read(raw/(screen+'-command.json'))['flags'])==53
 assert read(raw/screen/'process.json')['exit_code']==0
# All referenced files are checked from local packet paths or explicit excluded executable hashes.
def pinned_path(p):
 p=Path(p)
 if p.is_relative_to(original):
  rel=p.relative_to(original);q=raw/rel
  return pin(q)['sha256'] if q.exists() else excluded[str(rel)]['sha256']
 q=root/p.name;assert q.exists(),str(p);return pin(q)['sha256']
cases=read(raw/'runtime-cases.json');assert len(cases)==81
for item in read(raw/'runtime-corpus-pins.json'):
 p=raw/Path(item['path']).relative_to(original);assert pin(p)=={k:item[k] for k in ['bytes','sha256']}
for case in cases:
 def data(key):return (raw/Path(case[key]).relative_to(original)).read_bytes()
 assert data('expected').startswith(data('prefix'))
 assert zlib.decompress(data('expected')[len(data('prefix')):],-15)==data('input')
metrics=['payload_allocation_requests','requested_payload_bytes','initialized_bytes_copied','zeroed_bytes','peak_private_payload_bytes','nonreturned_private_bytes_at_return']
smokes=read(raw/'runtime-smoke-results.json');assert len(smokes)==81 and sum(r['checked_observations'] for r in smokes)==486
smoke_by={r['case']:r for r in smokes};checked_smokes=0
for case in cases:
 sm=smoke_by[case['name']];assert sm['control_and_candidate_metrics_identical'] and sm['checked_observations']==6
 for variant in ['control','candidate']:
  d=raw/'runtime-smokes'/case['name']/variant;assert read(d/'command.json')['exit_code']==0
  lines=(d/'stdout.jsonl').read_text().splitlines();assert lines.pop(0)=='SESSION_READY';assert len(lines)==3
  assert (d/'stderr.log').read_text().endswith('CLEANUP bytes=0 nodes=0\n')
  for line in lines:
   row=json.loads(line);assert all(row[k]==sm['metrics'][k] for k in metrics)
   assert all(row[k] is True for k in ['exact_reference','independent_inflation','input_alias_unchanged','borrowed_output_alias_unchanged']);checked_smokes+=1
# Rebuild every paired block from raw worker journal observations. Warmups and profile calls remain excluded.
def replay_runtime(directory,geometry_name,result_name):
 geometry=read(raw/geometry_name)
 for p in geometry['spec_pins']:assert pinned_path(p['path'])==p['sha256']
 expected_rows=read(raw/result_name);result=[];total_primary=0;total_all=0;zero_seconds=0
 for expected in expected_rows:
  name=expected['case'];d=raw/directory/name;spec=read(d/'spec.json');groups=spec['groups'];blocks=spec['blocks'];samples=spec['samples'];group_ratios=[];ratios=[];all_times={'before':[],'after':[]};group_summaries=[]
  for p in spec['pins']:assert pinned_path(p['path'])==p['sha256']
  assert spec['expected']['before']==spec['expected']['after'] and {k:spec['expected']['before'][k] for k in metrics}==smoke_by[name]['metrics']
  ref=read(d/'reference.json');assert ref['exit']==0 and ref['observations']==15
  ref_lines=(d/'reference.stdout').read_text().splitlines();ref_values=[int(l.split('\t')[3]) for l in ref_lines if l.startswith('rep\tcontrol-baseline\t')];assert len(ref_values)==15 and statistics.median(ref_values)/1e9==ref['median_seconds']
  for g in range(groups):
   gd=d/('group'+str(g));record=read(gd/'results.json');assert 'failure' not in record and record['group']==g and len(record['blocks'])==blocks
   times={}
   for label in ['before','after']:
    obs=record['all_observations'][label];lines=(gd/(label+'.stdout')).read_text().splitlines();assert lines.pop(0)=='SESSION_READY';assert [json.loads(l) for l in lines]==obs
    assert len(obs)==blocks*samples+2 and obs[0]['warmup'] and obs[-1]['profile']
    assert (gd/(label+'.stderr')).read_text().endswith('CLEANUP bytes=0 nodes=0\n')
    for row in obs:
     assert row['seconds']>=0 and math.isfinite(row['seconds'])
     zero_seconds+=int(row['seconds']==0)
     assert all(row[k]==v for k,v in spec['expected'][label].items())
    primary=obs[1:-1];assert all(not row['warmup'] and not row['profile'] for row in primary)
    times[label]=[row['seconds'] for row in primary];all_times[label]+=times[label]
   group=[]
   for b,block in enumerate(record['blocks']):
    med={label:statistics.median(times[label][b*samples:(b+1)*samples]) for label in times};ratio=med['after']/med['before']
    assert med==block['medians'] and ratio==block['after_over_before'] and block['block']==b
    assert block['order']==(['before','after'] if (b+g)%2==0 else ['after','before']);group.append(ratio)
   ratios+=group;group_ratios.append(statistics.median(group));med={label:statistics.median(times[label]) for label in times};group_summaries.append({'group':g,'medians':med,'after_over_before':med['after']/med['before']})
  assert group_summaries==read(d/'groups.json')
  summary=read(d/'summary.json');med={label:statistics.median(all_times[label]) for label in all_times}
  assert summary['medians']==med and summary['after_over_before']==med['after']/med['before'] and summary['median_block_ratio']==statistics.median(ratios)
  assert summary['primary_observations']==groups*blocks*samples*2 and summary['all_observations']==groups*(blocks*samples+2)*2
  assert summary['improving_blocks']==sum(v<1 for v in ratios) and summary['adverse_blocks']==sum(v>1 for v in ratios)
  assert summary['geometric_block_ratio']==math.exp(statistics.mean(math.log(v) for v in ratios))
  row={'case':name,'group_median_paired_block_ratios':group_ratios,'median_paired_block_ratio':statistics.median(ratios),'timed_calls_each':groups*blocks*samples}
  if 'suspect_all_groups_over_1_005' in expected:row['suspect_all_groups_over_1_005']=all(v>1.005 for v in group_ratios)
  assert row==expected;result.append(row);total_primary+=summary['primary_observations'];total_all+=summary['all_observations']
 return {'cases':len(result),'primary_observations':total_primary,'all_checked_observations':total_all,'zero_seconds_observations_retained':zero_seconds,'results':result}
primary=replay_runtime('runtime-primary','runtime-geometry.json','runtime-primary-results.json');repeat=replay_runtime('runtime-repeat','runtime-repeat-geometry.json','runtime-repeat-results.json');assert primary['cases']==81 and repeat['cases']==9
fields={'compiler_seconds':lambda r:r['compile']['total_seconds'],'whole_process_seconds':lambda r:r['process']['elapsed_seconds'],'parse_seconds':lambda r:next(p['seconds'] for p in r['compile']['phases'] if p['phase']=='parse'),'frontend_seconds':lambda r:next(p['seconds'] for p in r['compile']['phases'] if p['phase']=='frontend'),'native_seconds':lambda r:next(p['seconds'] for p in r['compile']['phases'] if p['phase']=='native')}
for key in ['canonical_lowering_seconds','preparation_seconds','numeric_generation_seconds','source_cfg_seconds','cleanup_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:fields[key]=lambda r,key=key:r[key]
qualified={key:{v:[f(r) for r in rows if r['variant']==v] for v in ['control','candidate']} for key,f in fields.items()}
for record in qualified.values():record['mean_reduction_fraction']=1-statistics.mean(record['candidate'])/statistics.mean(record['control'])
summary={'source_commit':state['source_commit'],'base_commit':state['base_commit'],'decision':state['decision'],'flags_count':len(flags),'hardware':state['hardware'],'qualified_compiler':qualified,'output_hashes':outputs,'compiler_binary_sha256':{'control':control['sha256'],'candidate':build['binary_sha256']},'candidate_patch_sha256':state['patch_sha256'],'tests':{'focused_ssa':16,'checked_smoke_observations':checked_smokes,'corpus_files':243},'runtime_primary':primary,'runtime_repeat':repeat,'scope':[
 'Reject provisional SSA forwarding; reverted before updating PR 973. Faster compilation does not justify repeated compressor runtime slowdowns.',
 'Fresh complete source-to-Object ABBA with the same 54 existing runtime flags for both subjects. Earlier 53-flag screens are diagnostic only.',
 'Source and MBC match; native Object and metadata differ. Control Object exactly matches the prior qualified fast reduction-bound runtime Object.',
 'Observed candidate RSS is higher with nonoverlapping matched ranges. No memory saving is claimed. Four compiles are descriptive observations.',
 'All 81 runtime cases pass exact raw output, independent inflation, alias/capacity and six memory-work checks. The maintained balanced measure entry retains every observation.',
 'Nine disclosed repeats preserve the original 81-case cohort. Their block medians do not constitute independent population samples. No automatic tolerance grants acceptance.',
 'Both runtime subjects share maintained Heap code, the same freshly built pinned mimalloc 0.1.35 archive and the same timing/validation closure. No byte-identical legacy allocator or cross-cohort absolute runtime comparison is claimed.',
 'The historical diagnostic runtime boundary includes actual Heap construction, compact execution, output transfer and private cleanup with prepared borrowed arguments; ordinary exact admission/accounting/publication recovery is outside it.',
 'The separate reference is the same control program outside paired primary timing, not Roc or libdeflate.',
 'No builds, tests, fixtures or sampling overlap primary timing. Bootstrap, screens, smokes and untimed profiles/warmups are excluded.',
 'The initial test oracle incorrectly examined Jump ordinary operands. Correct destination-argument validation and expanded deferred-origin tests pass; the failed command/log and superseded guard-only trial remain.',
 'No grammar, language, allocator algorithm, runtime admission or backend opt-level change is retained. The runtime slowdown cause is not established by this trial. The sub-ten-second full compilation goal remains open.'
]}
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
