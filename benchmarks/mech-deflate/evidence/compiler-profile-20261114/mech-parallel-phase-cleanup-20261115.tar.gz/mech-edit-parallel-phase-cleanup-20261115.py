from pathlib import Path
p=Path('hosts/gpu/src/native_artifact/program/compact/phase_function.rs');s=p.read_text()
# The pure cleanup consumes only presence, never the private proof identity.
a=s.index('fn optimize_phase(');s=s[:a]+s[a:].replace('private: Option<&PrivatePhase>,','private: bool,',1).replace('private.is_some()', 'private')
# Change only optimize_phase call argument lists, preserving all real witnesses
# for emission and post-cleanup proof checks on the coordinator.
pos=0
while True:
 a=s.find('} = optimize_phase(',pos)
 if a<0:break
 b=s.index(')?;',a);part=s[a:b];assert '\n        private,\n' in part;part=part.replace('\n        private,\n','\n        private.is_some(),\n');s=s[:a]+part+s[b:];pos=a+len(part)
a=s.index('                    optimize_phase(');b=s.index(')?;',a);part=s[a:b];assert '\n                        private,\n' in part;part=part.replace('\n                        private,\n','\n                        private.is_some(),\n');s=s[:a]+part+s[b:]
# Wrap the unchanged serial preparation entry and add an eligible-general entry.
a=s.index('pub(super) fn prepare<M: Module>(');brace=s.index('{',a);sig=s[a:brace];args='''module, prepared, id, observe, input_words, output_words, fixed_count,
        vectors, private, no_growth, literal_views, dense_tables, suffix'''
public=sig+'''{
    match prepare_impl('''+args+''', false)? {
        General::Ready(ready) => Ok(ready),
        General::Deferred(_) => unreachable!("serial preparation cannot defer cleanup"),
    }
}

'''
general=sig.replace('fn prepare<','fn prepare_general<').replace('    suffix: &str,\n','    suffix: &str,\n    defer: bool,\n').replace('Result<Prepared,','Result<General,')+'''{
    prepare_impl('''+args+''', defer)
}

'''
implsig=sig.replace('pub(super) fn prepare<','fn prepare_impl<').replace('    suffix: &str,\n','    suffix: &str,\n    defer_general: bool,\n').replace('Result<Prepared,','Result<General,')
s=s[:a]+public+general+implsig+s[brace:]
# Defer only the general case whose remaining preparation has no Module work.
a=s.index('    let PhaseCleanup {',s.index('fn prepare_impl(') if 'fn prepare_impl(' in s else s.index('fn prepare_impl<'))
b=s.index('    let pack_halfwords',a);old=s[a:b];call=old[old.index('optimize_phase('):];call=call.replace('private.is_some()', 'private.is_some()')
s=s[:a]+'''    let possible_histogram = std::env::var_os("MECH_GROUP_PACKED_HISTOGRAM").is_some()
        && !observe
        && proof.phase.is_none()
        && proof.exits.is_empty()
        && proof.prepaid_sites.is_empty()
        && proof.arrays.iter().all(|array| !array.appends)
        && module.isa().endianness() == cranelift_codegen::ir::Endianness::Little;
    if defer_general
        && vectors.is_none()
        && no_growth.is_none()
        && literal_views.is_empty()
        && !possible_histogram
        && ["MECH_INSPECT_PHASE_CLIF", "MECH_INSPECT_PHASE_VCODE", "MECH_COMPACT_FAILURE_DIR"]
            .iter().all(|name| std::env::var_os(name).is_none())
    {
        let input = SummaryInput {
            function,
            entry_bounds: report.phase_entry_bounds.iter()
                .map(|&(array, minimum)| (array, minimum, proof.arrays[array].appends)).collect(),
            header,
            exit: region.tail.exit(),
            symbol,
            input_words,
            output_words,
            fixed_count,
            actual_unit_append_growth: true,
        };
        return Ok(General::Deferred(DeferredGeneral {
            context, controls, report: std::sync::Arc::new(report),
            private: private.is_some(), input,
        }));
    }
    let phase_cleanup = '''+call+'''    let cleanup = &phase_cleanup.cleanup;
'''+s[b:]
# Move metadata construction into one shared routine, with the exact same body.
for line in ['    let pack_sites = word_loops.read_pack_sites.clone();\n','    let read_guards = word_loops.proven_scalar_read_guards.clone();\n','    let write_guards = word_loops.proven_scalar_write_guards.clone();\n','    let reused_reads = word_loops.reused_scalar_reads.clone();\n','    let reused_operands = word_loops.reused_scalar_operands.clone();\n']:
 assert s.count(line)==1;s=s.replace(line,'',1)
a=s.index('    let changed_writes = report.proven_changed_writes.clone();');b=s.index('\nfn phase_ir<',a);original=s[a:b];body=original[original.index('    let changed_writes'):original.rindex('\n}')]
body=body.replace('    let exit = region.tail.exit();\n','').replace('    let actual_unit_append_growth = no_growth.is_none();\n','').replace('    Ok(Prepared {','    Prepared {');assert body.endswith('    })');body=body[:-6]+'    }'
regular='''    Ok(General::Ready(finish_preparation(
        context, &report, phase_cleanup,
        SummaryInput { function, entry_bounds, header, exit: region.tail.exit(), symbol,
            input_words, output_words, fixed_count, actual_unit_append_growth: no_growth.is_none() },
        future_write_hints, histogram, composed, vcode_path,
    )))
}

struct SummaryInput {
    function: FuncId,
    entry_bounds: Vec<(usize, u64, bool)>,
    header: usize,
    exit: u32,
    symbol: String,
    input_words: usize,
    output_words: usize,
    fixed_count: usize,
    actual_unit_append_growth: bool,
}

fn finish_preparation(
    context: Context,
    report: &numeric_compact::Report,
    phase_cleanup: PhaseCleanup,
    input: SummaryInput,
    future_write_hints: Vec<cfg_cleanup::future_store::Hint>,
    histogram: Option<serde_json::Value>,
    composed: Option<Composed>,
    vcode_path: Option<std::path::PathBuf>,
) -> Prepared {
    let SummaryInput { function, entry_bounds, header, exit, symbol, input_words,
        output_words, fixed_count, actual_unit_append_growth } = input;
    let PhaseCleanup { bit_counts, cleanup, equality, threaded, vector_predicates,
        width_guards, window_bounds } = phase_cleanup;
    let pack_sites = report.read_pack_sites.clone();
    let read_guards = report.proven_scalar_read_guards.clone();
    let write_guards = report.proven_scalar_write_guards.clone();
    let reused_reads = report.reused_scalar_reads.clone();
    let reused_operands = report.reused_scalar_operands.clone();
'''+body+'\n}\n'
s=s[:a]+regular+s[b:]
# Add the deferred state next to existing machine-only pending state.
a=s.index('impl Prepared {')
state='''pub(super) enum General {
    Ready(Prepared),
    Deferred(DeferredGeneral),
}
pub(super) struct DeferredGeneral {
    context: Context,
    controls: CompilationControls,
    report: std::sync::Arc<numeric_compact::Report>,
    private: bool,
    input: SummaryInput,
}
pub(super) enum GeneralPending {
    Ready(Pending),
    Deferred {
        ticket: super::super::compile_jobs::Ticket<(Context, PhaseCleanup)>,
        report: std::sync::Arc<numeric_compact::Report>,
        input: SummaryInput,
    },
}
impl General {
    pub(super) fn entry_bounds(&self) -> &[(usize, u64, bool)] {
        match self {
            Self::Ready(ready) => ready.entry_bounds(),
            Self::Deferred(ready) => &ready.input.entry_bounds,
        }
    }
    pub(super) fn define<M: Module>(self, module: &mut M) -> Result<Compiled, NativeCompileError> {
        match self {
            Self::Ready(ready) => ready.define(module),
            Self::Deferred(ready) => ready.optimize(module.isa())?.define(module),
        }
    }
    pub(super) fn start(self, pool: &super::super::compile_jobs::Pool)
        -> Result<GeneralPending, NativeCompileError>
    {
        match self {
            Self::Ready(ready) => ready.start(pool).map(GeneralPending::Ready),
            Self::Deferred(ready) => {
                let DeferredGeneral { mut context, controls, report, private, input } = ready;
                let worker_report = report.clone();
                let symbol = input.symbol.clone();
                let input_words = input.input_words;
                let output_words = input.output_words;
                let ticket = pool.submit_work(move |isa| {
                    let cleanup = optimize_phase(&mut context, &controls, isa, &worker_report,
                        &symbol, input_words, output_words, None, private, None, true)?;
                    let context = super::super::compile_jobs::compile(context, isa)?;
                    Ok((context, cleanup))
                })?;
                Ok(GeneralPending::Deferred { ticket, report, input })
            }
        }
    }
}
impl DeferredGeneral {
    fn optimize(mut self, isa: &dyn TargetIsa) -> Result<Prepared, NativeCompileError> {
        let cleanup = optimize_phase(&mut self.context, &self.controls, isa, &self.report,
            &self.input.symbol, self.input.input_words, self.input.output_words,
            None, self.private, None, true)?;
        Ok(finish_preparation(self.context, &self.report, cleanup, self.input,
            Vec::new(), None, None, None))
    }
}
impl GeneralPending {
    pub(super) fn finish<M: Module>(self, module: &mut M) -> Result<Compiled, NativeCompileError> {
        match self {
            Self::Ready(pending) => pending.finish(module),
            Self::Deferred { ticket, report, input } => {
                let (context, cleanup) = ticket.wait()?;
                let Prepared { context, details } = finish_preparation(context, &report,
                    cleanup, input, Vec::new(), None, None, None);
                super::super::compile_jobs::publish(module, details.function, &context)?;
                details.finish(context)
            }
        }
    }
}

'''
s=s[:a]+state+s[a:];p.write_text(s)
# Only the general phase opts into the broader job; vector preparation/ledger
# ordering remains the existing implementation.
p=Path('hosts/gpu/src/native_artifact/program/compact/phases.rs');s=p.read_text();a=s.index('        let ready = function::prepare(');b=s.index('        let entry_bounds',a);chunk=s[a:b].replace('function::prepare(', 'function::prepare_general(');chunk=chunk.replace('            "",\n','            "",\n            pool.is_some(),\n');assert chunk!=s[a:b] and 'pool.is_some()' in chunk;s=s[:a]+chunk+s[b:];p.write_text(s)
print('Implemented eligible general cleanup+machine jobs; proof identities and all Module effects remain coordinator-owned.')
