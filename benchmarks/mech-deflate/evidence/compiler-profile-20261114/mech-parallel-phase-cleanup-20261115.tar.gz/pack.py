from pathlib import Path
import hashlib,json,shutil,subprocess,sys
repo=Path.cwd();raw=Path('/private/tmp/mech-parallel-phase-cleanup-20261115');packet=Path('/private/tmp/mech-parallel-phase-cleanup-packet-20261115');source='0c949505cc708c233e27c094aa67e105068d6823'
assert json.loads((packet/'qualification-commit.json').read_text())['source_commit']==source
shutil.copy2(__file__,packet/'pack.py')
archive=Path('/private/tmp/mech-parallel-phase-cleanup-20261115.tar.gz');archive_path=Path('benchmarks/mech-deflate/evidence/compiler-profile-20261114')/archive.name
summary_path=Path('benchmarks/mech-deflate/native-profile/parallel-phase-cleanup-apple-m3-20261115.json');receipt_path=summary_path.with_suffix('.archive.json')
command=[sys.executable,'benchmarks/mech-deflate/experiment.py','pack','--revision',source,'--input',str(packet),'--output',str(archive)]
with (raw/'pack.stdout.log').open('w') as stdout,(raw/'pack.stderr.log').open('w') as stderr:result=subprocess.run(command,stdout=stdout,stderr=stderr)
assert result.returncode==0
receipt=json.loads((raw/'pack.stdout.log').read_text());assert receipt['source_revision']==source
shutil.copy2(archive,repo/archive_path);shutil.copy2(packet/'summary.json',repo/summary_path)
replay_bytes=(packet/'summary.json').read_bytes();receipt.update(publication='repository',repository='mech-lang/mech',repository_path=archive_path.as_posix(),replay_sha256=hashlib.sha256(replay_bytes).hexdigest(),replay_byte_identical=True)
(repo/receipt_path).write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
extracted=Path('/private/tmp/mech-parallel-phase-cleanup-repository-verified-20261115');assert not extracted.exists()
command=[sys.executable,'benchmarks/mech-deflate/experiment.py','verify',archive_path.as_posix(),'--receipt',receipt_path.as_posix(),'--extract',str(extracted),'--result',str(raw/'repository-verification.json')]
with (raw/'verify.stdout.log').open('w') as stdout,(raw/'verify.stderr.log').open('w') as stderr:result=subprocess.run(command,stdout=stdout,stderr=stderr)
assert result.returncode==0
verification=json.loads((raw/'repository-verification.json').read_text());receipt['verification']=verification
(repo/receipt_path).write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
with (raw/'repository-replay.stdout.log').open('w') as stdout,(raw/'repository-replay.stderr.log').open('w') as stderr:result=subprocess.run([sys.executable,str(extracted/'replay.py')],stdout=stdout,stderr=stderr)
assert result.returncode==0 and (raw/'repository-replay.stdout.log').read_bytes()==replay_bytes
index_path=repo/'benchmarks/mech-deflate/evidence/compiler-profile-20261114/index.json';index=json.loads(index_path.read_text());previous=json.loads(json.dumps(index['packets']));assert len(previous)==43 and index['total_archive_bytes']==1285470680
row=dict(archive=archive_path.as_posix(),bytes=receipt['bytes'],decision='Retained expandedworkerarchitecture: eligiblegeneralcleanup+machinejobs overlapvectorpreparation. Standardold2/new2 fullbuild15.398425->15.130134s(-1.74%),bothblocks; Objectcompiler-1.61%, helpergeneration-12.68%, instructions+0.0352%. Separate samecandidatebinary0/2 fullbuild15.553768->15.218166s(-2.16%),bothblocks. Diagnostic344submitted/48cleanup provesactualuse. Exactall4outputs/fullmetadata/fullD6exe,14fixturepairs, default0gate. Fouractualworkertests/36Object comparisons/errorprecedence pass. Originalproofidentities/Moduleeffects/publication/errororder andmetadata staycoordinator-owned; no unsafeSend/grammar/runtimechange. Default0serial/2optin; bestPGO14.027481onolderd26remainsseparate untilnewqualification.',files=receipt['files'],receipt=receipt_path.as_posix(),sha256=receipt['sha256'],source_revision=source,summary=summary_path.as_posix())
index['packets'].append(row);index['total_archive_bytes']+=row['bytes'];assert index['packets'][:-1]==previous
index_path.write_text(json.dumps(index,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(receipt=receipt,total_archive_bytes=index['total_archive_bytes'],packets=len(index['packets'])),indent=2),flush=True)
