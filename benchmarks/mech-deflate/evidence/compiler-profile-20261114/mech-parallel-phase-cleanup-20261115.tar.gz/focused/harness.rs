mod native_artifact {
    pub use mech_gpu::native_artifact::NativeCompileError;
    pub mod compiler {
        use super::NativeCompileError;
        pub fn backend(error: impl std::fmt::Display) -> NativeCompileError {
            NativeCompileError::Backend(error.to_string())
        }
    }
}
#[path="candidate.rs"] mod jobs;
