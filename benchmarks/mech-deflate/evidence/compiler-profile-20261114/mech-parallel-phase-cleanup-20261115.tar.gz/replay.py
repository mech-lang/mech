from pathlib import Path
import hashlib
import json
import re
import statistics
import subprocess
import sys

packet = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_text())
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
state = read(packet / 'source-state.json')
assert pin(packet / 'candidate.patch')['sha256'] == state['patch_sha256']
for row in state['files']:
    assert pin(packet / 'reference-source' / row['path'])['sha256'] == row['sha256']
    assert pin(packet / 'candidate-source' / row['path'])['sha256'] == row['candidate_sha256']
commit_path = packet / 'qualification-commit.json'
commit = read(commit_path) if commit_path.exists() else dict(source_commit=None)
if commit_path.exists():
    assert commit['parent'] == state['base_commit']
    assert commit['entire_commit_diff_sha256'] == state['patch_sha256']
    assert commit['entire_commit_diff_matches_measured_patch']
excluded = read(packet / 'excluded-products.json')
assert excluded['control']['sha256'] == 'dd7dc5bc906325a213422a127a2e87ec134a3f8564b713dbbe50e1d1308571a0'
assert read(packet / 'candidate-build.json')['binary_sha256'] == excluded['candidate']['sha256']
for name in ['candidate-check', 'candidate-build', 'candidate-cli-check']:
    row = read(packet / (name + '.json'))
    assert row['exit_code'] == 0 and row['patch_sha256'] == state['patch_sha256']
assert read(packet / 'focused/build.json')['exit_code'] == read(packet / 'focused/test.json')['exit_code'] == 0
assert 'test result: ok. 4 passed; 0 failed' in (packet / 'focused/test.stdout.log').read_text()
worker = 'hosts/gpu/src/native_artifact/program/compact/compile_jobs.rs'
assert (packet / 'focused/candidate.rs').read_bytes() == (packet / 'candidate-source' / worker).read_bytes()
focused = read(packet / 'focused/result.json')
assert focused == dict(unit_tests=4,ordered_object_comparisons=24,owned_cleanup_object_and_ir_comparisons=12,worker_counts=[1,2,4],existing_earlier_publication_error_gate=True,typed_cleanup_error_order=True,all_pass=True)
assert read(packet / 'focused/test.json')['binary_sha256'] == excluded['focused/tests']['sha256']
for row in read(packet / 'supporting-source.json'):
    assert pin(packet / row['path']) == {key:row[key] for key in ['bytes','sha256']}
base = packet / 'reference-source/hosts/gpu/src/native_artifact/program/compact'
candidate = packet / 'candidate-source/hosts/gpu/src/native_artifact/program/compact'
left=(base/'phase_function.rs').read_text();right=(candidate/'phase_function.rs').read_text();tokens=lambda value:re.sub(r'\s+','',value)
a=left.index('fn optimize_phase(');original=left[a:].replace('private: Option<&PrivatePhase>,','private: bool,',1).replace('private.is_some()','private')
assert tokens(original)==tokens(right[right.index('fn optimize_phase('):])
def source_function(value,needle):
    start=value.index(needle);brace=value.index('{',start);depth=1;end=brace+1
    while depth:
        if value[end]=='{':depth+=1
        elif value[end]=='}':depth-=1
        end+=1
    return value[start:end]
assert tokens(source_function(left,'fn phase_ir<'))==tokens(source_function(right,'fn phase_ir<'))
a=left.index('    let finish_report: FinishReport');b=left.index('    Ok(Prepared {',a);a2=right.index('    let finish_report: FinishReport');b2=right.index('    Prepared {',a2);assert tokens(left[a:b])==tokens(right[a2:b2])
first=(base/'phases.rs').read_text();second=(candidate/'phases.rs').read_text();a=first.index('            // Complete and publish the earlier function');b=first.index('        let mut summary = general.summary;',a);a2=second.index('            // Complete and publish the earlier function');b2=second.index('        let mut summary = general.summary;',a2);assert tokens(first[a:b])==tokens(second[a2:b2])
assert all(read(packet/'architecture-audit.json')[key] for key in ['pure_cleanup_tokens_identical_except_private_presence_type','phase_ir_tokens_unchanged','complete_finish_report_closure_tokens_unchanged','coordinator_publication_replay_and_error_order_tokens_unchanged'])
flags = read(packet / 'runtime-flags.json')
assert len(flags) == 61
reference = {name:pin(packet / 'reference' / name) for name in ['source.mec','program.mecb','program.o','metadata.json']}
native = read(packet / 'native-baseline-pins.json')
exe = native['executable']
assert exe == dict(bytes=2060440,sha256='d6c65cc3fb18acc4be77dce329962105bf0f2b56dd2623a12f466256463eca61')
capture = read(packet / 'link-command.json')
inputs = read(packet / 'native-link-inputs.json')
assert [(r['source'],r['bytes'],r['sha256']) for r in inputs] == [(r['source'],r['bytes'],r['sha256']) for r in capture['inputs']]
for row in inputs:
    assert pin(packet / row['path']) == {k:row[k] for k in ['bytes','sha256']}
for variant in ['control','candidate']:
    directory = packet / (variant + '-screen')
    assert read(directory / 'process.json')['exit_code'] == 0
    for name, item in reference.items():
        assert pin(directory / name) == item and (directory / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    assert pin(packet / ('link-' + variant) / 'worker') == exe
gates = read(packet / 'final-executable-results.json')
assert len(gates) == 2 and all(r['exit_code'] == 0 and r['matches_complete_baseline_executable'] and r['executable_sha256'] == exe['sha256'] for r in gates)
fixtures = read(packet / 'fixture-results.json')
assert len(fixtures) == 14
for row in fixtures:
    assert row['all_outputs_match'] and row['variants']['control'] == row['variants']['candidate']
    for variant in ['control','candidate']:
        entry = row['variants'][variant]
        assert entry['exit_code'] == 0 and len(entry['files']) == 4
        name = Path(row['fixture'].split(':')[-1]).stem
        directory = packet / 'fixtures' / name / variant
        for filename, item in entry['files'].items():
            assert pin(directory / filename) == item
            assert (directory / filename).read_bytes() == (packet / 'fixtures' / name / 'control' / filename).read_bytes()
jobs = read(packet / 'jobs-diagnostic.json')
assert jobs['excluded_from_primary'] and jobs['all_outputs_and_complete_executable_identical']
observed=[]
for line in (packet / 'candidate-jobs-diagnostic/stderr.log').read_text().splitlines():
    match=re.fullmatch(r'compact-compile-jobs: workers=(\d+) submitted=(\d+) cleanup=(\d+)',line)
    if match:observed.append(dict(workers=int(match[1]),submitted=int(match[2]),cleanup=int(match[3])))
assert jobs['rows']==observed and observed and all(row['workers']==2 and row['submitted']>=row['cleanup'] for row in observed)
assert sum(row['cleanup'] for row in observed)>0
for name,item in reference.items():assert pin(packet/'candidate-jobs-diagnostic'/name)==item and (packet/'candidate-jobs-diagnostic'/name).read_bytes()==(packet/'reference'/name).read_bytes()
assert pin(packet/'link-candidate-jobs/worker')==exe
assert len(read(packet/'jobs-executable-results.json'))==1 and read(packet/'jobs-executable-results.json')[0]['matches_complete_baseline_executable']
assert read(packet/'candidate-jobs-diagnostic-command.json')['flags']==dict(flags,MECH_COMPACT_COMPILE_THREADS='2',MECH_PROFILE_COMPILE_JOBS='1')
assert read(packet/'candidate-jobs-diagnostic-command.json')['profiling_excluded_from_primary']
rows = read(packet / 'cohort.json')
assert len(rows) == 8
order = ['control-1','candidate-1','candidate-2','control-2','candidate-3','control-3','control-4','candidate-4']
assert [r['name'] for r in rows] == order
for row in rows:
    directory = packet / row['name']
    assert row['compile'] == read(directory / 'compile.json') and row['process'] == read(directory / 'process.json')
    assert row['process']['exit_code'] == 0
    command = read(packet / (row['name'] + '-command.json'))
    assert command['binary_sha256'] == excluded[row['variant']]['sha256']
    assert command['flags'] == dict(flags, MECH_COMPACT_COMPILE_THREADS='2')
    for name, item in reference.items():
        assert pin(directory / name) == item and (directory / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    stamps = [json.loads(line) for line in (directory / 'stages.jsonl').read_text().splitlines()]
    for key, begin, end in [('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code'),('compaction_seconds','compact-stage: compact values before=','compact-stage: CFG cleanup')]:
        assert row[key] == next(s['elapsed'] for s in stamps if s['line'].startswith(end)) - next(s['elapsed'] for s in stamps if s['line'].startswith(begin))
    assert row['cleanup_including_compaction_seconds'] == row['cleanup_seconds'] + row['compaction_seconds']
    log = (directory / 'stderr.log').read_text()
    for key, pattern in [('max_rss_bytes',r'(\d+)  maximum resident set size'),('instructions',r'(\d+)  instructions retired'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]:
        assert row[key] == int(re.search(pattern,log).group(1))
fields = dict(compiler_seconds=lambda r:r['compile']['total_seconds'],whole_process_seconds=lambda r:r['process']['elapsed_seconds'])
for phase in ['parse','catalog','frontend','artifact','encode','native']:
    fields[phase+'_seconds'] = lambda r,p=phase: next(v['seconds'] for v in r['compile']['phases'] if v['phase']==p)
for key in ['canonical_lowering_seconds','preparation_seconds','numeric_generation_seconds','source_cfg_seconds','cleanup_including_compaction_seconds','cleanup_seconds','compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:
    fields[key] = lambda r,k=key:r[k]
summary = {}
for key, fn in fields.items():
    values = {v:[fn(r) for r in rows if r['variant']==v] for v in ['control','candidate']}
    base = statistics.mean(values['control'])
    values['mean_reduction_fraction'] = 1-statistics.mean(values['candidate'])/base if base else None
    summary[key] = values
assert read(packet / 'numerical-summary.json') == summary
native_path = packet / 'native-cohort.json'
native_rows = read(native_path) if native_path.exists() else []
assert len(native_rows) in [0,8]
native_summary = {}
for row in native_rows:
    directory = packet / row['name']
    receipt = read(directory / 'result.json')
    assert row == dict(receipt, name=row['name'], primary_cohort=True)
    assert row['compiler_exit_code'] == row['link_exit_code'] == 0 and row['matches_complete_baseline_executable']
    assert row['executable_bytes'] == exe['bytes'] and row['executable_sha256'] == exe['sha256'] and pin(directory / 'worker') == exe
    for name, item in reference.items():
        assert pin(directory / name) == item and (directory / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    assert abs(row['source_to_executable_seconds']-sum(row[k] for k in ['source_to_object_process_seconds','object_handoff_seconds','native_link_seconds'])) < 1e-8
if native_rows:
    for key in ['source_to_executable_seconds','source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']:
        values = {v:[r[key] for r in native_rows if r['variant']==v] for v in ['control','candidate']}
        values['mean_reduction_fraction'] = 1-statistics.mean(values['candidate'])/statistics.mean(values['control'])
        native_summary[key] = values
    blocks = []
    for block in [native_rows[:4],native_rows[4:]]:
        means = {v:statistics.mean(r['source_to_executable_seconds'] for r in block if r['variant']==v) for v in ['control','candidate']}
        means['mean_reduction_fraction'] = 1-means['candidate']/means['control']
        blocks.append(means)
    saved = read(packet / 'native-numerical-summary.json')
    assert saved['numerical_summary'] == native_summary and saved['balanced_blocks'] == blocks
else:
    blocks = []
iso_rows = read(packet/'parallel-isolation-cohort.json')
assert len(iso_rows)==8 and [row['compile_threads'] for row in iso_rows]==[0,2,2,0,2,0,0,2]
for row in iso_rows:
    directory=packet/row['name']; receipt=read(directory/'result.json');assert row==dict(receipt,name=row['name'])
    assert row['variant']=='candidate' and row['compiler_exit_code']==row['link_exit_code']==0 and row['matches_complete_baseline_executable']
    assert pin(directory/'worker')==exe
    command=read(directory/'command.json');assert command['compiler_sha256']==excluded['candidate']['sha256'] and command['flags']==dict(flags,MECH_COMPACT_COMPILE_THREADS=str(row['compile_threads']))
    for name,item in reference.items():assert pin(directory/name)==item and (directory/name).read_bytes()==(packet/'reference'/name).read_bytes()
    assert abs(row['source_to_executable_seconds']-sum(row[key] for key in ['source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']))<1e-8
iso_summary={}
for key in ['source_to_executable_seconds','source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']:
    values={label:[row[key] for row in iso_rows if row['compile_threads']==threads] for label,threads in [('serial',0),('parallel',2)]};values['mean_reduction_fraction']=1-statistics.mean(values['parallel'])/statistics.mean(values['serial']);iso_summary[key]=values
iso_blocks=[]
for block in [iso_rows[:4],iso_rows[4:]]:
    means={label:statistics.mean(row['source_to_executable_seconds'] for row in block if row['compile_threads']==threads) for label,threads in [('serial',0),('parallel',2)]};means['mean_reduction_fraction']=1-means['parallel']/means['serial'];iso_blocks.append(means)
assert read(packet/'parallel-isolation-summary.json')['numerical_summary']==iso_summary and read(packet/'parallel-isolation-summary.json')['balanced_blocks']==iso_blocks
if (packet / 'candidate-serial-gate').exists():
    serial = packet / 'candidate-serial-gate'
    assert read(serial / 'process.json')['exit_code'] == 0
    for name, item in reference.items():
        assert pin(serial / name) == item and (serial / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    serial_result = read(packet / 'link-candidate-serial/result.json')
    assert serial_result['matches_complete_baseline_executable'] and serial_result['executable_sha256'] == exe['sha256']
    assert pin(packet / 'link-candidate-serial/worker') == exe
result = dict(source_commit=commit['source_commit'],base_commit=state['base_commit'],patch_sha256=state['patch_sha256'],compiler=excluded,source_state=state,numerical_summary=summary,native_numerical_summary=native_summary,balanced_native_blocks=blocks,output_hashes=reference,final_executable=exe,fixture_pairs=14,focused_tests=4,focused_worker_tests=focused,architecture_audit=read(packet/'architecture-audit.json'),jobs_diagnostic=jobs,parallel_isolation_numerical_summary=iso_summary,parallel_isolation_balanced_blocks=iso_blocks,checks={name:read(packet/(name+'.json')) for name in ['candidate-check','candidate-build','candidate-cli-check']},decision=read(packet/'decision.json'),scope='Eligible general numeric phases run owned cleanup+machine tasks in existing boundedworkerpool. Coordinator retains checkedIR/proofidentities, ordered Modulepublication/errorprecedence andmetadatafinish. No rawproofsharing/unsafeSend/grammar/runtime change. StandardDD7control versusstandardcandidate, same61flags/twoworkers/pinnedmimalloc; default0bytegate andexcludedreal-jobdiagnostic before timing. Exactall4outputs/fullmetadata/wholeexe. CurrentbestPGO5a1/d26 separate; no additive/newPGO orsubten claim.')
encoded = json.dumps(result,indent=2,sort_keys=True)+'\n'
saved = packet / 'summary.json'
if saved.exists():
    assert saved.read_text() == encoded
else:
    saved.write_text(encoded)
print(encoded,end='')
