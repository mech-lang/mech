from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time

root=Path('/private/tmp/mech-parser-frame-native-pgo-20261115')
out=root/'qualification'
read=lambda p:json.loads(p.read_text())
recovery=read(root/'fixture-template-recovery.json')
old=read(out/'pipeline.json')
assert old==recovery['initial_pipeline']
assert old[-1]['state']=='failed' and all(r['state']=='complete' for r in old[:4])
records=old[:4]
env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')}
assert not any(k.startswith('MIMALLOC_') for k in env)
assert hashlib.sha256((root/'source/src/syntax/src/document/parser/canonical/base/continuation.rs').read_bytes()).hexdigest()=='ae1f0bd867da11ecaa24d6f02ddb3e5718993d53203d6848118ea4c943228903'
assert hashlib.sha256(Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech/src/syntax/src/document/parser/canonical/base/continuation.rs').read_bytes()).hexdigest()=='ae1f0bd867da11ecaa24d6f02ddb3e5718993d53203d6848118ea4c943228903'
for stage,name in [('fixtures-object-cohort','mech-qualify-refreshed-native-pgo-current-20261115.py'),('heldout-cohorts','mech-heldout-refreshed-native-pgo-20261115.py'),('native-cohort','mech-native-cohort-refreshed-native-pgo-current-20261115.py'),('parallel-isolation','mech-native-parallel-isolation-cohort-20261115.py')]:
    command=[sys.executable,str(root/'qualification-scripts'/name)]
    row=dict(stage=stage,state='running',command=command,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    records.append(row);(out/'pipeline.json').write_text(json.dumps(records,indent=2)+'\n')
    started=time.monotonic()
    with (out/(stage+'.stdout.log')).open('w') as stdout,(out/(stage+'.stderr.log')).open('w') as stderr:
        completed=subprocess.run(command,cwd=root/'source',env=env,stdout=stdout,stderr=stderr)
    row.update(state='complete' if completed.returncode==0 else 'failed',exit_code=completed.returncode,seconds=time.monotonic()-started)
    (out/'pipeline.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    assert completed.returncode==0
