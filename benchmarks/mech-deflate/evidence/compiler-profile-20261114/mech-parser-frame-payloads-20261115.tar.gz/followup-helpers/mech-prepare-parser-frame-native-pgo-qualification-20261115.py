from pathlib import Path
import ast
import hashlib
import json
import shutil

old = Path('/private/tmp/mech-dimension-native-pgo-20261115')
root = Path('/private/tmp/mech-parser-frame-native-pgo-20261115')
scripts = root / 'qualification-scripts'
assert not scripts.exists()
scripts.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
records = []
for original in sorted((old / 'qualification-scripts').glob('*.py')):
    text = original.read_text()
    assert str(old) in text
    derived = text.replace(str(old), str(root))
    if original.name == 'mech-native-cohort-refreshed-native-pgo-current-20261115.py':
        before = 'Frozen ef5/3c09 standard compiler versus nativeCPU plus current instrumentation PGO; same source/program/runtime. Combined configuration comparison, no additive component claim. No emitted-program allocator changes; compiler nativeCPU/PGO overrides are the subject.'
        after = 'Current fastest8043 versus frozen parser83150caf candidate with its own fresh PGO. Same compiler settings, predetermined eight-program training corpus, program/runtime and worker count; source differs by the pinned parser patch. Direct complete-build comparison; no inferred or additive gain. Both use legitimate nativeCPU/PGO compiler optimization.'
        assert derived.count(before) == 1
        derived = derived.replace(before, after)
    ast.parse(derived)
    assert str(old) not in derived
    destination = scripts / original.name
    destination.write_text(derived)
    records.append(dict(original=str(original), original_sha256=sha(original), derived=destination.name, derived_sha256=sha(destination)))
assert len(records) == 18
(scripts / 'derivation.json').write_text(json.dumps(records, indent=2) + '\n')

original = Path('/private/tmp/mech-qualify-dimension-native-pgo-20261115.py')
text = original.read_text().replace(str(old), str(root))
before = "assert state['source_commit']=='ef5e255e817eb5bbc6df61b094a3741b31c49da2'"
after = "assert state['source_commit'] is None and state['base_commit']=='25615f1d575fd5cb7c91d4dcd3d8d01edf9e3ef3' and state['source_patch_sha256']=='83150caf57750bfb169986010eef403e5f7a4cd1c9b0e2c7318b3a9e98bf2a68'\nassert sha_source(Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech/src/syntax/src/document/parser/canonical/base/continuation.rs')) == state['source_files'][0]['candidate']['sha256']\nassert sha_source(source/'src/syntax/src/document/parser/canonical/base/continuation.rs') == state['source_files'][0]['candidate']['sha256']"
assert text.count(before) == 1
text = text.replace(before, "sha_source = lambda p:hashlib.sha256(p.read_bytes()).hexdigest()\n" + after)
before = "config = dict(source_commit=state['source_commit'],common_compile_threads=2,program_flags_count=61,"
after = "config = dict(source_commit=state['source_commit'],base_commit=state['base_commit'],source_patch_sha256=state['source_patch_sha256'],source_identity=state['source_identity'],common_compile_threads=2,program_flags_count=61,"
assert text.count(before) == 1
text = text.replace(before, after)
before = 'Qualified standard3c09 compiler versus current nativeCPU plus instrumentation PGO. Same source/program/runtime and61flags/twoworkers; measures combined compiler build configuration. No additive/historical gain claim.'
after = 'Direct current-fastest8043 versus frozen parser83150caf candidate with its own fresh instrumentation PGO. Same nativeCPU/ThinLTO/CGU1 settings, predetermined fixed8 corpus, runtime,61program flags and2workers. Parser source patch is the candidate; no additive/historical gain claim. Both compiler configurations count fully toward sub10.'
assert text.count(before) == 1
text = text.replace(before, after)
tree = ast.parse(text)
stages = [node for node in ast.walk(tree) if isinstance(node, ast.For) and isinstance(node.target, ast.Tuple) and [getattr(e, 'id', '') for e in node.target.elts] == ['stage', 'name']]
assert len(stages) == 1
plan = ast.literal_eval(stages[0].iter)
assert [s for s, _ in plan] == ['screens','cached-executable-gates','serial-default-gate','real-worker-diagnostic','fixtures-object-cohort','heldout-cohorts','native-cohort','parallel-isolation']
assert all((scripts / name).exists() for _, name in plan)
assert str(old) not in text
destination = Path('/private/tmp/mech-qualify-parser-frame-native-pgo-20261115.py')
assert not destination.exists()
destination.write_text(text)
shutil.copy2(original, root / 'original-qualification-pipeline.py')
shutil.copy2(destination, root / 'qualification-pipeline.py')
audit = dict(original=str(original), original_sha256=sha(original), derived=str(destination), derived_sha256=sha(destination), helpers=records, actual_ast_plan=plan, all_eight_stages_present=True, frozen_source_identity=json.loads((root/'source-state.json').read_text()), scope='Prepared while instrumented compiler builds. No qualification or primary observations launched by this setup. Full gates precede primary timing; all compiler builds/training must finish first.')
(root / 'qualification-derivation.json').write_text(json.dumps(audit, indent=2) + '\n')
shutil.copy2(Path(__file__), root / 'prepare-qualification.py')
print(json.dumps(dict(helpers=len(records), stages=plan, driver_sha256=sha(destination)), indent=2))
