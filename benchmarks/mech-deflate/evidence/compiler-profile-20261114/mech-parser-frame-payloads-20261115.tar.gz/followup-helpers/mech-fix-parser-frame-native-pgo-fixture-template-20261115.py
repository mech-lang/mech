from pathlib import Path
import ast
import hashlib
import json
import shutil

root=Path('/private/tmp/mech-parser-frame-native-pgo-20261115')
q=root/'qualification'
prior=Path('/private/tmp/mech-dimension-native-pgo-20261115')
read=lambda p:json.loads(p.read_text())
pin=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
rows=read(q/'pipeline.json')
assert len(rows)==5 and all(r['state']=='complete' and r['exit_code']==0 for r in rows[:4])
assert rows[-1]['stage']=='fixtures-object-cohort' and rows[-1]['state']=='failed' and rows[-1]['exit_code']==1
assert not any(p.is_file() for p in (q/'fixtures').rglob('*'))
assert not any(p.is_file() for p in (q/'fixture-inputs').rglob('*'))
assert not (q/'cohort.json').exists()
failure=q/'fixture-template-setup-failure';failure.mkdir()
for source,name in [(q/'pipeline.json','pipeline.json'),(q/'fixtures-object-cohort.stdout.log','stdout.log'),(q/'fixtures-object-cohort.stderr.log','stderr.log'),(root/'qualification-pipeline.stdout.log','driver.stdout.log'),(root/'qualification-pipeline.stderr.log','driver.stderr.log')]:shutil.copy2(source,failure/name)
dest=root/'fixture-input-template';assert not dest.exists();dest.mkdir()
templates=[]
for name in ['numeric-nested-phase-states.mec','assembly.json']:
    source=prior/'fixture-input-template'/name
    shutil.copy2(source,dest/name)
    assert (dest/name).read_bytes()==source.read_bytes()
    templates.append(dict(name=name,original=str(source),**pin(source)))
driver=root/'qualification-pipeline.py'
tree=ast.parse(driver.read_text())
loop=next(n for n in ast.walk(tree) if isinstance(n,ast.For) and isinstance(n.target,ast.Tuple) and [getattr(v,'id','') for v in n.target.elts]==['stage','name'])
steps=ast.literal_eval(loop.iter);assert len(steps)==8
remaining=steps[4:]
assert [r['stage'] for r in rows]==[s for s,_ in steps[:5]]
for label,name in remaining:assert (root/'qualification-scripts'/name).exists()
metadata=dict(reason='Initial setup omitted the two unchanged fixture-input-template files. Failure happened before any fixture compiler invocation or primary Object/native observation. Four completed output/default/jobs stages are preserved; remaining four stages resume with identical helpers, binaries, flags and frozen source.',initial_pipeline=rows,initial_pipeline_pin=pin(failure/'pipeline.json'),template_files=templates,initial_qualification_driver=pin(driver),initial_completed_prefix=4,remaining_stages=remaining,empty_fixture_directories_before_fix=True,no_primary_object_or_native_observation_before_failure=True)
(root/'fixture-template-recovery.json').write_text(json.dumps(metadata,indent=2)+'\n')
shutil.copy2(__file__,root/'fix-fixture-template.py')
print(json.dumps(dict(completed_prefix=4,remaining_stages=remaining,templates=templates),indent=2))
