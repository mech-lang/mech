from pathlib import Path
import ast
import hashlib
import json
import shutil

root = Path('/private/tmp/mech-parser-frame-native-pgo-20261115')
trial = Path('/private/tmp/mech-parser-frame-payloads-20261115')
old_root = '/private/tmp/mech-dimension-native-pgo-20261115'
base = '25615f1d575fd5cb7c91d4dcd3d8d01edf9e3ef3'
patch = '83150caf57750bfb169986010eef403e5f7a4cd1c9b0e2c7318b3a9e98bf2a68'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
records = []
def replace(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after)
def save(original, destination, text):
    ast.parse(text)
    original_copy = root / 'evidence-originals' / original.name
    original_copy.parent.mkdir(exist_ok=True)
    assert not original_copy.exists()
    shutil.copy2(original, original_copy)
    destination.write_text(text)
    derived_copy = root / 'evidence-derived' / destination.name
    derived_copy.parent.mkdir(exist_ok=True)
    shutil.copy2(destination, derived_copy)
    records.append(dict(original=str(original_copy), original_sha256=sha(original_copy), derived=str(derived_copy), derived_sha256=sha(derived_copy)))

original = Path('/private/tmp/mech-replay-dimension-native-pgo-20261115.py')
text = original.read_text().replace(old_root, str(root))
text = replace(text, "revision = 'ef5e255e817eb5bbc6df61b094a3741b31c49da2'\nassert source['source_commit'] == revision", f"revision = '{base}'\nassert source['source_commit'] is None and source['base_commit']==revision and source['source_patch_sha256']=='{patch}'\nassert pin(packet/'candidate.patch')['sha256']==source['source_patch_sha256']")
text = replace(text, "assert state['source_commit'] == revision and state['common_compile_threads']==2 and state['program_flags_count']==61", "assert state['source_commit'] is None and state['base_commit']==revision and state['source_patch_sha256']==source['source_patch_sha256'] and state['common_compile_threads']==2 and state['program_flags_count']==61")
text = replace(text, "build['source_commit'] == revision", "build['source_commit'] is None and build['base_commit']==revision and build['source_patch_sha256']==source['source_patch_sha256']")
text = replace(text, "control_reuse['source_commit']==revision and control_reuse['sha256']=='3c09f358909db5ab07d09a9ee78a16d3de83f58d9f181f750985e7f3a88653f3'", "control_reuse['source_commit']=='ef5e255e817eb5bbc6df61b094a3741b31c49da2' and control_reuse['sha256']=='8043d93d27b948371aee38027df898a9024e47a1ffa112b47a1913f8329e40ad'")
text = replace(text, "prior['source_commit']==revision and prior['compiler']['candidate']['sha256']==control_reuse['sha256']", "prior['source_commit']==control_reuse['source_commit'] and prior['compiler_binary_sha256']['candidate']==control_reuse['sha256']")
text = replace(text, "source_commit=revision, compiler_binary_sha256=binary_sha", "source_commit=None, base_commit=revision, source_patch_sha256=source['source_patch_sha256'], source_identity=source['source_identity'], compiler_binary_sha256=binary_sha")
text = replace(text, "assert all(x['mean_reduction_fraction']>0 for x in native_blocks)", "assert all(x['mean_reduction_fraction']>0 for x in native_blocks) and all(x['compiler_seconds']['mean_reduction_fraction']>0 for x in blocks)\nassert decision['object_blocks']==blocks")
text = replace(text, "Current ef5 retained dimension-scan source and program/runtime. Reuse qualified standard3c09 control versus target-cpu=native plus instrumentation PGO. Same 61 program flags and two workers. Two new compiler builds; standard control reused. Measures combined build configuration with no component or historical gain claim.", "Direct current-fastest8043 versus frozen parser83150caf candidate with own fresh PGO; same nativeCPU/ThinLTO/CGU1 settings, fixed8 training corpus,61program flags and2workers. Both configurations count fully toward the goal. Source identity is base25615 plus exact frozen patch; any later retained Git commit is linked by the parent packet.")
text = replace(text, "Deflate itself is in training: this is workload-tuned PGO, not proof of broad compiler gains. Seven heldouts are small fixtures. Fresh instrument/train/use for exact ef5 source. Explicit aarch64 target, nightly-2026-03-03, compiler ThinLTO/CGU1, j4, incremental0 and -Dwarnings. Absolute profile paths and matching Rust LLVM22 profdata. Standard3c09 from qualified packet48 reused. Native-only subject omitted; no component gain claimed. Builds/training excluded from primary means.", "Both subjects use legitimate PGO compiler optimization with the same predetermined eight-program corpus including Deflate. Fresh candidate instrument/train/use matches the frozen base-plus-patch source. Seven fixed scalar/numeric heldouts retain every observation. Explicit aarch64 target, nightly2026-03-03, ThinLTO/CGU1, nativeCPU, j4, incremental0, -Dwarnings and matching Rust LLVM22 profdata. Compiler builds/training are outside Deflate compilation timing.")
text = replace(text, "Compiler binaries, dependency target and full source snapshot excluded and hash/Git pinned.", "Compiler binaries and dependency target excluded and hash pinned; exact source is base Git revision plus frozen patch, with compiler configuration and candidate parser bytes retained.")
save(original, Path('/private/tmp/mech-replay-parser-frame-native-pgo-20261115.py'), text)

original = Path('/private/tmp/mech-replay-parser-frame-payloads-20261115.py')
text = original.read_text()
text = replace(text, "if decision['decision']=='retain':\n    assert commit['source_commit'] and all(row['mean_reduction_fraction']>0 for row in blocks)", "optimized=json.loads(subprocess.check_output([sys.executable,str(packet/'optimized/replay.py')]))\nassert optimized['base_commit']==state['base_commit'] and optimized['source_patch_sha256']==state['patch_sha256']\nassert optimized['decision']['decision']==decision['decision']\nresult['optimized_followup']=optimized\nif decision['decision']=='retain':\n    assert commit['source_commit'] and all(row['mean_reduction_fraction']>0 for row in optimized['native_cohort']['balanced_blocks'])")
text = replace(text, 'no candidate PGO gain inferred.', 'standard cohorts and direct fastest-configuration follow-up remain separate; no component gains added.')
save(original, original, text)

original = Path('/private/tmp/mech-curate-parser-frame-payloads-20261115.py')
text = original.read_text()
text = replace(text, "print(packet)", "shutil.copytree('/private/tmp/mech-parser-frame-native-pgo-packet-20261115',packet/'optimized')\nprint(packet)")
save(original, original, text)
(root/'evidence-derivation.json').write_text(json.dumps(records,indent=2)+'\n')
driver = root/'qualification-pipeline.py'
tree = ast.parse(driver.read_text())
loop = next(n for n in ast.walk(tree) if isinstance(n,ast.For) and isinstance(n.target,ast.Tuple) and [getattr(e,'id','') for e in n.target.elts]==['stage','name'])
stages = ast.literal_eval(loop.iter)
(root/'qualification-plan.json').write_text(json.dumps(dict(qualification_driver_sha256=sha(driver),actual_ast_stages=[dict(stage=s,helper=n,helper_sha256=sha(root/'qualification-scripts'/n)) for s,n in stages]),indent=2)+'\n')
shutil.copy2(__file__,root/'prepare-evidence.py')
print(json.dumps(dict(derived=len(records),stages=len(stages)),indent=2))
