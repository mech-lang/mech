from pathlib import Path,PurePosixPath
import ast,datetime,hashlib,json,shutil,subprocess,tarfile,time,tomllib

repo=Path.cwd();root=Path('/private/tmp/mech-parser-frame-native-pgo-20261115');trial=Path('/private/tmp/mech-parser-frame-payloads-20261115');prior=Path('/private/tmp/mech-dimension-native-pgo-20261115')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
state=json.loads((trial/'source-state.json').read_text());base=state['base_commit'];patch=(trial/'candidate.patch').read_bytes()
assert not root.exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==base
assert subprocess.check_output(['git','diff','--binary'])==patch
assert state['patch_sha256']=='83150caf57750bfb169986010eef403e5f7a4cd1c9b0e2c7318b3a9e98bf2a68'
assert all(row['state']=='complete' and row['exit_code']==0 for row in json.loads((trial/'qualification-pipeline.json').read_text()))
assert sha(prior/'use')=='8043d93d27b948371aee38027df898a9024e47a1ffa112b47a1913f8329e40ad'
root.mkdir();source=root/'source';source.mkdir();command=['git','archive','--format=tar',base,'--','.',':(exclude)benchmarks/mech-deflate/evidence'];started=time.monotonic();files=0
with (root/'source-archive.stderr.log').open('w') as error:
    process=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=error)
    with tarfile.open(fileobj=process.stdout,mode='r|') as archive:
        for member in archive:
            path=PurePosixPath(member.name);assert not path.is_absolute() and '..' not in path.parts
            archive.extract(member,source,filter='data');files+=member.isfile()
    assert process.wait()==0
for item in state['files']:
    path=source/item['path'];assert sha(path)==item['reference']['sha256'];path.write_bytes((trial/'candidate-source'/item['path']).read_bytes());assert sha(path)==item['candidate']['sha256']
assert tomllib.loads((source/'.cargo/config.toml').read_text())['build']['rustflags']==['-D','warnings']
source_state=dict(source_commit=None,base_commit=base,source_patch_sha256=state['patch_sha256'],source_identity=base+'+patch:'+state['patch_sha256'],source_files=state['files'],snapshot_method='Git archive base excluding raw evidence, then replace only frozen one-file candidate; original/candidate hashes and entire workspace patch checked.',archive_command=command,archive_files=files,seconds=time.monotonic()-started,created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),setup_complete=False,scope='Frozen uncommitted parser frame payload candidate. Fresh instrumentation/training/use, same fixed8 corpus. Matched control is prior qualified optimized8043; source differs only by measured83150caf patch. No source commit before useful qualified gain; no inferred or additive standard/PGO improvement.')
(root/'source-state.json').write_text(json.dumps(source_state,indent=2)+'\n');shutil.copy2(trial/'candidate.patch',root/'candidate.patch');shutil.copy2(prior/'use',root/'control');shutil.copytree(trial/'reference',root/'reference');shutil.copytree(trial/'fixtures',root/'fixture-reference');shutil.copy2(trial/'fixture-results.json',root/'fixture-reference-results.json');shutil.copy2(trial/'runtime-flags.json',root/'runtime-flags.json');assert len(json.loads((root/'runtime-flags.json').read_text()))==61
shutil.copy2(repo/'benchmarks/mech-deflate/native-profile/dimension-native-pgo-apple-m3-20261115.archive.json',root/'control-source-evidence-receipt.json')
for filename in ['rustc-version.txt','rustc-sysroot.txt','target-cpus.txt','generic-target-cfg.txt','native-target-cfg.txt','cpu.txt','cpu-count.txt','memory.txt','os.txt','llvm-profdata-path.txt','llvm-profdata-version.txt']:
    shutil.copy2(prior/filename,root/filename)
assert subprocess.check_output(['rustc','+nightly-2026-03-03','-Vv'],text=True)==(root/'rustc-version.txt').read_text()
profile_tool=Path((root/'llvm-profdata-path.txt').read_text().strip());assert profile_tool.is_file()
(root/'control-reuse.json').write_text(json.dumps(dict(binary=str(root/'control'),bytes=(root/'control').stat().st_size,sha256=sha(root/'control'),source_commit='ef5e255e817eb5bbc6df61b094a3741b31c49da2',source_evidence_packet=49,build=json.loads((prior/'use-build.json').read_text()),profile_sha256='8691e0be35ba3c8816c22f361a5040b266ea89d14a3355d1a61fad73154bc9f7',scope='Immutable current best8043; nativeCPU+PGO, same corpus/flags/2workers. New candidate is fresh source+own PGO. Direct matched current-best/candidate timing; standard cohorts remain separate.'),indent=2)+'\n')
plan=json.loads((prior/'fixed-corpus-plan.json').read_text());plan['scope']='Same fixed eight training and seven disjoint heldout cases, selected before this new optimized build. Deflate included. No candidate corpus selection from heldout results.';(root/'fixed-corpus-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
original=Path('/private/tmp/mech-dimension-native-pgo-pipeline-20261115.py');s=original.read_text().replace(str(prior),str(root)).replace("state['source_commit']=='ef5e255e817eb5bbc6df61b094a3741b31c49da2'","state['source_commit'] is None and state['base_commit']=='25615f1d575fd5cb7c91d4dcd3d8d01edf9e3ef3' and state['source_patch_sha256']=='83150caf57750bfb169986010eef403e5f7a4cd1c9b0e2c7318b3a9e98bf2a68'").replace('3c09f358909db5ab07d09a9ee78a16d3de83f58d9f181f750985e7f3a88653f3','8043d93d27b948371aee38027df898a9024e47a1ffa112b47a1913f8329e40ad')
s=s.replace("record=dict(command=command,source_commit=state['source_commit'],", "record=dict(command=command,source_commit=state['source_commit'],base_commit=state['base_commit'],source_patch_sha256=state['source_patch_sha256'],source_identity=state['source_identity'],")
ast.parse(s);derived=Path('/private/tmp/mech-parser-frame-native-pgo-pipeline-20261115.py');assert not derived.exists();derived.write_text(s);shutil.copy2(original,root/'original-build-pipeline.py');shutil.copy2(derived,root/'build-pipeline.py');shutil.copy2(__file__,root/'setup.py');(root/'build-derivation.json').write_text(json.dumps(dict(original=str(original),original_sha256=sha(original),derived=str(derived),derived_sha256=sha(derived),change='New isolated root; prior optimized8043 control; exact frozen base+patch provenance replaces committed-source assertion. Fresh raw8 training and use flags unchanged.'),indent=2)+'\n')
source_state['setup_complete']=True;(root/'source-state.json').write_text(json.dumps(source_state,indent=2)+'\n');print(json.dumps(source_state),flush=True)
