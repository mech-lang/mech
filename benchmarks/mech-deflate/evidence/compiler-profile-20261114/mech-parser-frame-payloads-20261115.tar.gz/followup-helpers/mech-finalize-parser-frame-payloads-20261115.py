from pathlib import Path
import hashlib
import json
import shutil
import subprocess

repo=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech')
raw=Path('/private/tmp/mech-parser-frame-payloads-20261115')
optimized=Path('/private/tmp/mech-parser-frame-native-pgo-20261115')
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
state=read(raw/'source-state.json')
decision=read(raw/'decision.json')
pgodecision=read(optimized/'decision.json')
assert decision['decision']==pgodecision['decision']
assert all(r['state']=='complete' and r['exit_code']==0 for r in read(optimized/'qualification/pipeline.json'))
git=lambda *args:subprocess.check_output(['git',*args],cwd=repo)
assert git('rev-parse','HEAD').decode().strip()==state['base_commit']
assert not git('diff','--cached','--name-only')
assert hashlib.sha256(git('diff','--binary','HEAD')).hexdigest()==state['patch_sha256']
assert len(state['files'])==1
name=state['files'][0]['path'];source=repo/name
assert sha(source)==state['files'][0]['candidate']['sha256']
selected=Path('/private/tmp/mech-dimension-native-pgo-20261115/use')
profile=Path('/private/tmp/mech-dimension-native-pgo-20261115/merged.profdata')
assert sha(selected)=='8043d93d27b948371aee38027df898a9024e47a1ffa112b47a1913f8329e40ad'
assert sha(profile)=='8691e0be35ba3c8816c22f361a5040b266ea89d14a3355d1a61fad73154bc9f7'
if decision['decision']=='retain':
    assert all(r['mean_reduction_fraction']>0 for r in pgodecision['native_blocks'])
    assert all(r['compiler_seconds']['mean_reduction_fraction']>0 for r in pgodecision['object_blocks'])
    subprocess.run(['git','add','--',name],cwd=repo,check=True)
    with (raw/'source-commit.stdout.log').open('w') as stdout,(raw/'source-commit.stderr.log').open('w') as stderr:
        result=subprocess.run(['git','commit','-m','syntax: shrink canonical parser continuation frames'],cwd=repo,stdout=stdout,stderr=stderr)
    assert result.returncode==0
    commit=git('rev-parse','HEAD').decode().strip()
    parent=git('rev-parse','HEAD^').decode().strip();assert parent==state['base_commit']
    patch=git('diff','--binary',parent,commit)
    assert hashlib.sha256(patch).hexdigest()==state['patch_sha256']
    assert patch==(raw/'candidate.patch').read_bytes()
    (raw/'entire-source-commit.patch').write_bytes(patch)
    proof=dict(source_commit=commit,parent=parent,entire_commit_diff_sha256=hashlib.sha256(patch).hexdigest(),files=[name],entire_commit_diff_matches_measured_patch=True,optimized_build_source_identity=read(optimized/'source-state.json')['source_identity'],scope='Candidate compiler built before commit from archived base plus exact patch; entire later one-file source commit matches measured patch. Build source_commit remains null in original records.')
    (raw/'qualification-commit.json').write_text(json.dumps(proof,indent=2)+'\n')
    decision.update(source_commit=commit,retained_source_commit=commit)
    pgodecision.update(retained_source_commit=commit,qualification_commit=proof)
    disposition=proof
else:
    assert decision['decision']=='reject'
    reference=raw/'reference-source'/name
    assert sha(reference)==state['files'][0]['reference']['sha256']
    source.write_bytes(reference.read_bytes())
    canonical=Path('/private/tmp/mech-level12-compile-target/compiler/compile_profile')
    assert sha(raw/'control')=='3c09f358909db5ab07d09a9ee78a16d3de83f58d9f181f750985e7f3a88653f3'
    shutil.copy2(raw/'control',canonical)
    assert not git('diff','--binary','HEAD')
    disposition=dict(source_restored=True,source_path=name,source_sha256=sha(source),canonical_sha256=sha(canonical),selected_pgo_sha256=sha(selected),selected_profile_sha256=sha(profile),workspace_source_diff_empty=True,source_mtime_ns=source.stat().st_mtime_ns,cargo_cache_note='Compiler-profile dependency libraries remain from rejected C824 candidate until a genuine rebuild; restored parser source has fresh mtime. Canonical standard3c09 and qualified fastest8043 are independently restored/preserved. Isolated candidate PGO target never used as a reference.',scope='Restore only the exact frozen one-file candidate and canonical developer tool after all qualifications; preserve every raw candidate output/profile and both candidate binaries.')
    (raw/'restoration.json').write_text(json.dumps(disposition,indent=2)+'\n')
    decision['restoration']=disposition
(raw/'decision.json').write_text(json.dumps(decision,indent=2,sort_keys=True)+'\n')
(optimized/'decision.json').write_text(json.dumps(pgodecision,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(decision=decision['decision'],disposition=disposition),indent=2))
