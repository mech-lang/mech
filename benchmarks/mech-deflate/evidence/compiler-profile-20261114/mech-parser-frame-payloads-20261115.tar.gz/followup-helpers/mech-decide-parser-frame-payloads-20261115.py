from pathlib import Path
import json
import statistics

raw=Path('/private/tmp/mech-parser-frame-payloads-20261115')
optimized=Path('/private/tmp/mech-parser-frame-native-pgo-20261115')
q=optimized/'qualification'
read=lambda p:json.loads(p.read_text())
pipeline=read(q/'pipeline.json')
assert len(pipeline)==8 and all(r['state']=='complete' and r['exit_code']==0 for r in pipeline)
native=read(q/'native-numerical-summary.json')
numeric=read(q/'numerical-summary.json')
isolation=read(q/'parallel-isolation-summary.json')
heldout=read(q/'heldout-results.json')
cohort=read(q/'cohort.json')
main=native['numerical_summary']['source_to_executable_seconds']
serial=isolation['numerical_summary']['source_to_executable_seconds']
object_blocks=[]
for block in [cohort[:4],cohort[4:]]:
    fields={}
    for key,get in [('compiler_seconds',lambda r:r['compile']['total_seconds']),('whole_process_seconds',lambda r:r['process']['elapsed_seconds']),('instructions',lambda r:r['instructions'])]:
        means={v:statistics.mean(get(r) for r in block if r['variant']==v) for v in ['control','candidate']}
        fields[key]=dict(means,mean_reduction_fraction=1-means['candidate']/means['control'])
    object_blocks.append(fields)
retained=(main['mean_reduction_fraction']>0 and all(r['mean_reduction_fraction']>0 for r in native['balanced_blocks']) and numeric['compiler_seconds']['mean_reduction_fraction']>0 and all(r['compiler_seconds']['mean_reduction_fraction']>0 for r in object_blocks))
control=statistics.mean(main['control']);candidate=statistics.mean(main['candidate'])
optimized_decision=dict(decision='retain' if retained else 'reject',source_commit=None,base_commit=read(optimized/'source-state.json')['base_commit'],source_patch_sha256=read(optimized/'source-state.json')['source_patch_sha256'],source_changes=True,description=f"{'Retained' if retained else 'Rejected'} frozen parser frame payload candidate with own fresh PGO: direct current-fastest8043 comparison {control:.6f}->{candidate:.6f}s ({main['mean_reduction_fraction']*100:.3f}% reduction). All original standard observations retained separately; both subjects use the same legitimate optimized build configuration.",generalization=dict(label='Deflate-trained PGO',benchmark_in_training=True,heldout_count=7,heldout_scope='Fixed scalar and numeric fixtures; every observation retained. PGO counts fully toward the compilation goal.'),control_complete_seconds=control,candidate_complete_seconds=candidate,native_reduction=main['mean_reduction_fraction'],native_blocks=native['balanced_blocks'],object_blocks=object_blocks,isolated_serial_seconds=statistics.mean(serial['serial']),isolated_two_worker_seconds=statistics.mean(serial['parallel']),isolated_reduction=serial['mean_reduction_fraction'],isolated_blocks=isolation['balanced_blocks'],object_adverse_fields={k:v for k,v in numeric.items() if v['mean_reduction_fraction']<0},native_adverse_fields={k:v for k,v in native['numerical_summary'].items() if v['mean_reduction_fraction']<0},heldout_adverse_fields={case['name']:{k:v for k,v in case['numerical_summary'].items() if v['mean_reduction_fraction']<0} for case in heldout},goal_sub10_achieved=retained and candidate<10,retention_plan='followup-retention-plan.json')
(optimized/'decision.json').write_text(json.dumps(optimized_decision,indent=2,sort_keys=True)+'\n')
standard_native=read(raw/'native-numerical-summary.json')
standard_numeric=read(raw/'numerical-summary.json')
standard=standard_native['numerical_summary']['source_to_executable_seconds']
decision=dict(decision=optimized_decision['decision'],source_commit=None,retained_source_commit=None,description=f"{'Retained' if retained else 'Rejected'} parser frame80->32B payload-storage candidate. Direct current-fastest8043 versus candidate with own PGO: {control:.6f}->{candidate:.6f}s ({main['mean_reduction_fraction']*100:.3f}% reduction). Separate standard comparison: {statistics.mean(standard['control']):.6f}->{statistics.mean(standard['candidate']):.6f}s ({standard['mean_reduction_fraction']*100:.3f}% reduction); parser {standard_numeric['parse_seconds']['mean_reduction_fraction']*100:.3f}% and instructions {standard_numeric['instructions']['mean_reduction_fraction']*100:.3f}% lower. All full outputs/metadata/whole executables and parser identity/accounting checks exact. Every adverse phase, block, heldout and setup failure retained. No added component gains or subten claim.",control_complete_seconds=statistics.mean(standard['control']),candidate_complete_seconds=statistics.mean(standard['candidate']),native_reduction=standard['mean_reduction_fraction'],native_blocks=standard_native['balanced_blocks'],object_adverse_fields={k:v for k,v in standard_numeric.items() if v['mean_reduction_fraction']<0},native_adverse_fields={k:v for k,v in standard_native['numerical_summary'].items() if v['mean_reduction_fraction']<0},optimized_followup=dict(control_complete_seconds=control,candidate_complete_seconds=candidate,native_reduction=main['mean_reduction_fraction'],native_blocks=native['balanced_blocks'],object_blocks=object_blocks,decision=optimized_decision['decision']),retention_basis='Direct current-fastest configuration; all correctness gates and Object/full-native mean plus both balanced blocks must improve. Initial standard criterion failed and remains published. Independent follow-up plan declared before fresh optimized compiler timing.',goal_sub10_achieved=retained and candidate<10)
(raw/'decision.json').write_text(json.dumps(decision,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(decision=decision['decision'],control_complete_seconds=control,candidate_complete_seconds=candidate,native_blocks=native['balanced_blocks'],object_blocks=object_blocks,source_commit=None),indent=2))
