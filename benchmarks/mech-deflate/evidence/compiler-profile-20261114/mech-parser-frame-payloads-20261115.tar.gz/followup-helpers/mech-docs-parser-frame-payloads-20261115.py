from pathlib import Path
import json
import statistics

repo=Path.cwd()
raw=Path('/private/tmp/mech-parser-frame-payloads-20261115')
packet=Path('/private/tmp/mech-parser-frame-payloads-packet-20261115')
read=lambda p:json.loads(p.read_text())
result=read(packet/'summary.json');decision=result['decision'];optimized=result['optimized_followup']
receipt=read(repo/'benchmarks/mech-deflate/native-profile/parser-frame-payloads-apple-m3-20261115.archive.json')
index=read(repo/'benchmarks/mech-deflate/evidence/compiler-profile-20261114/index.json')
assert len(index['packets'])==51 and receipt['replay_byte_identical']
mean=lambda item,v:statistics.mean(item[v])
change=lambda item:-100*item['mean_reduction_fraction']
standard=result['native_numerical_summary'];numeric=result['numerical_summary'];fast=optimized['native_cohort']['numerical_summary'];fastnum=optimized['numerical_summary']
retained=decision['decision']=='retain'
best=mean(fast['source_to_executable_seconds'],'candidate') if retained else 13.414824520470574
rows=[]
for label,table,key in [('Standard complete source to executable',standard,'source_to_executable_seconds'),('Standard Object internal compiler',numeric,'compiler_seconds'),('Standard Object parser',numeric,'parse_seconds'),('Standard Object instructions',numeric,'instructions'),('Standard Object maximum RSS',numeric,'max_rss_bytes'),('Optimized complete source to executable',fast,'source_to_executable_seconds'),('Optimized Object internal compiler',fastnum,'compiler_seconds'),('Optimized Object parser',fastnum,'parse_seconds'),('Optimized Object instructions',fastnum,'instructions'),('Optimized Object maximum RSS',fastnum,'max_rss_bytes')]:
    r=table[key];rows.append(f'| {label} | {mean(r,"control"):.6f} | {mean(r,"candidate"):.6f} | {change(r):+.4f}% |')
adverse=lambda table:', '.join(f'{k} {change(v):+.3f}%' for k,v in table.items() if v['mean_reduction_fraction']<0) or 'none'
blocktext=lambda blocks:', '.join(f'{-100*r["mean_reduction_fraction"]:+.3f}%' for r in blocks)
source=result['source_commit'] if retained else result['base_commit']
disposition=(f'The entire retained one-file source commit `{source}` matches frozen patch `{result["patch_sha256"]}`. The optimized compiler was built from the exact base-plus-patch snapshot before that commit; original build records explicitly retain `source_commit: null`, and the later entire-commit proof links them.' if retained else 'The exact original parser source and canonical standard compiler are restored. Cargo dependency libraries still reflect the rejected candidate until a genuine rebuild; the restored parser source has a fresh mtime. Qualified compiler `8043` and profile `8691` are unchanged. Both candidate binaries and all candidate profiles remain preserved outside the checkout.')
report=f'''# Parser continuation payload-storage trial

The candidate is **{'retained' if retained else 'rejected and restored'}** after a direct comparison with the fastest qualified compiler. Optimized complete builds measure **{mean(fast['source_to_executable_seconds'],'control'):.6f} to {mean(fast['source_to_executable_seconds'],'candidate'):.6f} seconds ({change(fast['source_to_executable_seconds']):+.3f}%)**. The selected verified complete-build result is **{best:.6f} seconds**. PGO fully counts toward the compilation goal; compiler settings are recorded for reproduction.

## Frozen change and parser behavior

Base is `25615f1d575fd5cb7c91d4dcd3d8d01edf9e3ef3`; whole one-file patch SHA-256 is `{result['patch_sha256']}`. In canonical base continuations, Exit/Unless checkpoints move to a paired typed LIFO vector at their original capture and restore phases. Unicode escape state uses owned boxes carried through the same phases, with one reusable allocation whose fields are freshly overwritten. Ordinary frames shrink **80 to 32 bytes** on this target. This changes storage only: original grammar, phase order, prediction ownership, logical work/fuel, first refusal and identity allocation remain.

**528 actual complete document-module unit tests** and **1,976 exact reference/candidate parser cases** pass. Those include the complete Deflate program and 308 streaming cases covering 22 texts, seven allowance sizes and two chunk schemes. Complete trees, node/token IDs, diagnostics, statistics, restart state, progress and work/fuel accounting match across 20,376,437 bytes per subject. The independent token audit reconstructs the entire original production algorithm after reversing explicit storage changes. Genuine compiler check/build and the native CLI check with `cranelift_build` pass.

## Complete-build and Object observations

| Boundary | Original | Candidate | Change |
| --- | ---: | ---: | ---: |
{chr(10).join(rows)}

Times are seconds; instructions and maximum RSS are raw counts and bytes. Each primary cohort has eight serial ABBA/BAAB observations, four per subject. Standard and optimized cohorts remain separate. The initial standard criterion failed: complete builds slow {change(standard['source_to_executable_seconds']):.3f}% despite parser time falling {-change(numeric['parse_seconds']):.3f}% and retired instructions falling {-change(numeric['instructions']):.3f}%. Before any fresh optimized timing, an independent follow-up plan required a direct fastest-configuration gain in both full-native and Object means and both balanced blocks. No parser reduction was added to an earlier complete-build result.

Standard native block changes: {blocktext(result['balanced_native_blocks'])}. Optimized native block changes: {blocktext(optimized['native_cohort']['balanced_blocks'])}. Optimized Object compiler block changes: {blocktext([r['compiler_seconds'] for r in optimized['balanced_blocks']])}. All favorable and adverse phases, blocks, counters and heldout observations are in the [complete result](../../benchmarks/mech-deflate/native-profile/parser-frame-payloads-apple-m3-20261115.json).

Standard adverse Object fields: {adverse(numeric)}. Optimized adverse Object fields: {adverse(fastnum)}. Optimized adverse complete-build fields: {adverse(fast)}.

Both optimized subjects use nativeCPU, ThinLTO/CGU1, pinned compiler-only mimalloc, nightly2026-03-03, explicit aarch64 target, four Cargo jobs, incremental0 and -Dwarnings. The candidate uses its own fresh instrumentation profile from the unchanged predetermined eight-program corpus, including Deflate. Seven predetermined scalar/numeric heldouts retain every observation. All builds/training finish before primary timing; no heavy build/test/profile/hash/archive work overlaps it. Every cohort uses the same 61 program flags and two workers. Complete builds start fresh source assembly and end after native link completion, with fixed runtime/adapter inputs cached and pinned. Historical first-use adapter construction remains separate.

## Exact outputs and published evidence

Every source, MBC, Object and **complete metadata** byte matches in all main observations and both sets of 14 fixture pairs. Standard and optimized default-serial and real-worker diagnostics pass, including 344 jobs and 48 cleanup-and-machine jobs. All **32 qualification executable images**, plus the two selection-profile images, reproduce all 2,060,440 bytes of the current executable, SHA-256 `d6c65cc3fb18acc4be77dce329962105bf0f2b56dd2623a12f466256463eca61`. Emitted program code and runtime inputs are unchanged.

Two fresh 1ms stack diagnostics of the current fastest compiler selected the frame storage target. Their full raw samples, validated demangling, thread/ancestry counts and actual-symbol disassembly are retained separately from primary timing. Counts are callgraph observations rather than exclusive CPU percentages. All setup failures remain. The optimized fixture setup initially omitted two unchanged template files and stopped before any fixture compiler invocation or primary cohort; four completed gates remain intact and the remaining four stages resume with identical helpers after copying the pinned templates. Pure replay checks the preserved failure, exact prefix, recovered bytes and actual resume AST. The inherited test recipe's historical link-failure wording is explicitly distinguished from this trial's successful tests.

{disposition}

The fifty-first [repository packet](../../benchmarks/mech-deflate/evidence/compiler-profile-20261114/README.md) includes the full source snapshots/patch, tests/audit, every command/log/observation/output/executable, both compiler configurations, all fresh raw/merged profiles in verified lossless storage, fixed native inputs, plans/derivation and {'entire source-commit proof' if retained else 'restoration proof'}. Compiler/test binaries and dependency targets are excluded and hash-pinned. Fresh repository extraction verifies every manifest/blob and replays the full nested result byte-identically. Compilation below ten seconds remains open.
'''
(repo/'docs/design/native-parser-frame-payloads-compile-trial.md').write_text(report)
paragraph=f"The [parser continuation payload-storage trial](../../../docs/design/native-parser-frame-payloads-compile-trial.md) is {'retained' if retained else 'rejected/restored'}. Frames shrink 80 to 32 bytes; the separate standard parser improves {-change(numeric['parse_seconds']):.3f}% but complete builds slow {change(standard['source_to_executable_seconds']):.3f}%. Direct current-fastest8043 versus candidate with own fresh PGO measures **{mean(fast['source_to_executable_seconds'],'control'):.6f} to {mean(fast['source_to_executable_seconds'],'candidate'):.6f} seconds ({change(fast['source_to_executable_seconds']):+.3f}%)**. All 528 units,1,976 complete parser identity/accounting pairs, both sets of14fixtures, full metadata and32qualification executables match. The fifty-first packet retains all adverse data, selection profiles, fresh raw/merged PGO profiles and {'whole source-commit proof' if retained else 'restoration proof'}; fresh extraction verifies/replays exactly. Selected complete-build time is {best:.6f}s; PGO fully counts."
for name in ['benchmarks/mech-deflate/native-profile/README.md','benchmarks/mech-deflate/EXPERIMENTS.md']:
    p=repo/name;text=p.read_text();assert 'native-parser-frame-payloads-compile-trial.md' not in text
    if name.endswith('EXPERIMENTS.md'):paragraph_to_write=paragraph.replace('../../../docs/','../../docs/')
    else:paragraph_to_write=paragraph
    p.write_text(text.rstrip()+'\n\n'+paragraph_to_write+'\n')
p=repo/'benchmarks/mech-deflate/evidence/compiler-profile-20261114/README.md';text=p.read_text()
text=text.replace('Fifty complete evidence packets','Fifty-one complete evidence packets',1).replace('All fifty repository copies','All fifty-one repository copies',1)
assert text.count('1,634,023,219 bytes (1,634.0 MB)')==1
text=text.replace('1,634,023,219 bytes (1,634.0 MB)',f"{index['total_archive_bytes']:,} bytes ({index['total_archive_bytes']/1_000_000:,.1f} MB)",1)
lines=text.splitlines();at=next(i for i,line in enumerate(lines) if line.startswith('| Packed dense SSA slots |'))+1
lines.insert(at,f"| Parser continuation payload storage | {'Retained' if retained else 'Rejected/restored'}: frames80->32B; standard parser -5.13%, fullbuild +0.94%. Direct fastest-config complete build {mean(fast['source_to_executable_seconds'],'control'):.6f}->{mean(fast['source_to_executable_seconds'],'candidate'):.6f}s ({change(fast['source_to_executable_seconds']):+.3f}%); exact parser/full-output/executable bytes. | [mech-parser-frame-payloads-20261115.tar.gz](mech-parser-frame-payloads-20261115.tar.gz) | [Receipt](../../native-profile/parser-frame-payloads-apple-m3-20261115.archive.json) / [result](../../native-profile/parser-frame-payloads-apple-m3-20261115.json) | {receipt['files']:,} |")
p.write_text('\n'.join(lines)+'\n')
print(json.dumps(dict(decision=decision['decision'],best_seconds=best,report='docs/design/native-parser-frame-payloads-compile-trial.md'),indent=2))
