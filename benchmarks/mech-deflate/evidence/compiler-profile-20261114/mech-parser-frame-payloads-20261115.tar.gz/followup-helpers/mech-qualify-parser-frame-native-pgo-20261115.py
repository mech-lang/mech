from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

root = Path('/private/tmp/mech-parser-frame-native-pgo-20261115')
pipeline = json.loads((root/'pipeline.json').read_text())
assert [r['stage'] for r in pipeline] == ['generate','training','use']
assert all(r['state']=='complete' and r['exit_code']==0 for r in pipeline)
source = root / 'source'
state = json.loads((root/'source-state.json').read_text())
sha_source = lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert state['source_commit'] is None and state['base_commit']=='25615f1d575fd5cb7c91d4dcd3d8d01edf9e3ef3' and state['source_patch_sha256']=='83150caf57750bfb169986010eef403e5f7a4cd1c9b0e2c7318b3a9e98bf2a68'
assert sha_source(Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech/src/syntax/src/document/parser/canonical/base/continuation.rs')) == state['source_files'][0]['candidate']['sha256']
assert sha_source(source/'src/syntax/src/document/parser/canonical/base/continuation.rs') == state['source_files'][0]['candidate']['sha256']
out = root / 'qualification'
out.mkdir(exist_ok=False)
sha = lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for original,name in [('control','control'),('use','candidate')]:
    shutil.copy2(root/original,out/name)
    expected = json.loads((root/'control-reuse.json').read_text())['sha256'] if original=='control' else json.loads((root/'use-build.json').read_text())['binary_sha256']
    assert sha(out/name)==expected
shutil.copytree(root/'reference',out/'reference')
shutil.copy2(root/'runtime-flags.json',out/'runtime-flags.json')
config = dict(source_commit=state['source_commit'],base_commit=state['base_commit'],source_patch_sha256=state['source_patch_sha256'],source_identity=state['source_identity'],common_compile_threads=2,program_flags_count=61,
              subjects={v:dict(bytes=(out/v).stat().st_size,sha256=sha(out/v)) for v in ['control','candidate']},
              strategy='Direct current-fastest8043 versus frozen parser83150caf candidate with its own fresh instrumentation PGO. Same nativeCPU/ThinLTO/CGU1 settings, predetermined fixed8 corpus, runtime,61program flags and2workers. Parser source patch is the candidate; no additive/historical gain claim. Both compiler configurations count fully toward sub10.',
              primary_timing='Every compiler build and training finished before qualification. Serial/uncontended cohorts, no heavy builds/tests/profiling/hashing/archival overlap. Exactall4outputs/complete metadata and whole currentD6exe gates precede primary timing. Fixedruntime/adapter cached.',
              scripts=json.loads((root/'qualification-scripts/derivation.json').read_text()))
(out/'configuration.json').write_text(json.dumps(config,indent=2)+'\n')
env = {k:v for k,v in os.environ.items() if not k.startswith('MECH_')}
records=[]
for stage,name in [('screens', 'mech-screen-refreshed-native-pgo-current-20261115.py'), ('cached-executable-gates', 'mech-cached-native-link-refreshed-native-pgo-current-20261115.py'), ('serial-default-gate', 'mech-qualify-parallel-native-pgo-serial-20261115.py'), ('real-worker-diagnostic', 'mech-qualify-parallel-native-pgo-jobs-20261115.py'), ('fixtures-object-cohort', 'mech-qualify-refreshed-native-pgo-current-20261115.py'), ('heldout-cohorts', 'mech-heldout-refreshed-native-pgo-20261115.py'), ('native-cohort', 'mech-native-cohort-refreshed-native-pgo-current-20261115.py'), ('parallel-isolation', 'mech-native-parallel-isolation-cohort-20261115.py')]:
    command = [sys.executable,str(root/'qualification-scripts'/name)]
    row = dict(stage=stage,state='running',command=command,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    records.append(row)
    (out/'pipeline.json').write_text(json.dumps(records,indent=2)+'\n')
    started=time.monotonic()
    with (out/(stage+'.stdout.log')).open('w') as stdout,(out/(stage+'.stderr.log')).open('w') as stderr:
        completed=subprocess.run(command,cwd=source,env=env,stdout=stdout,stderr=stderr)
    row.update(state='complete' if completed.returncode==0 else 'failed',exit_code=completed.returncode,seconds=time.monotonic()-started)
    (out/'pipeline.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    assert completed.returncode==0
