//! Shared hidden support for direct canonical source-rule contract tests.
//!
//! These helpers deliberately parse physical source fragments. They are not
//! public parser roots and must not be used by production document parsing.

use alloc::sync::Arc;

use crate::document::{
    DiagnosticAnchor, DiagnosticStore, GreenNode, IdGenerator, NodeFlags, NodeIndex, ParseStats,
    RuleId, SyntaxKind, SyntaxNode, TextRange, TextSnapshot,
};

use super::super::rule::rules;
use super::super::{LexicalMode, ParseConfig, Parser, sink};
use super::combinator::Attempt;
use super::{
    control_operators, declarations, document, imports, kinds, literals, operators, paths,
    pattern_primitives, recursive_core, source_imports, structure_shell, subscript_primitives,
};

/// Parse one rule from the generated document closure as a deterministic
/// source prefix.
pub(super) fn parse_canonical_document_rule_for_test(
    source: TextSnapshot,
    rule: RuleId,
    config: ParseConfig,
) -> Option<CanonicalSourceRuleSnapshot> {
    document::supports(rule).then(|| {
        parse_source_rule_prefix(source, rule, config, |parser| {
            document::parse_rule(parser, rule)
        })
    })
}

/// The exact combined declaration grammar direct-rule surface.
pub(crate) const DECLARATION_RULES: &[RuleId; 21] = &[
    rules::SOURCE_IMPORT_TAIL,
    rules::SOURCE_PATH_COMPONENT_TOKEN,
    rules::SOURCE_PATH_COMPONENT,
    rules::SOURCE_MEC_PATH,
    rules::SOURCE_MEC_PATH_WILDCARD_SUFFIX,
    rules::RELATIVE_SOURCE_IMPORT_SPECIFIER,
    rules::ABSOLUTE_SOURCE_IMPORT_SPECIFIER,
    rules::BARE_SOURCE_IMPORT_SPECIFIER,
    rules::URI_SCHEME_PART,
    rules::SOURCE_IMPORT_URI_SCHEME,
    rules::URI_SOURCE_IMPORT_SPECIFIER,
    rules::SOURCE_IMPORT_SPECIFIER,
    rules::IMPORT_DECLARATION,
    rules::EXPORT_DECLARATION,
    rules::CONTEXT_DECLARATION,
    rules::CONTEXT_BASE_CONTEXT,
    rules::CONTEXT_BASE_RESOURCE_URI,
    rules::CONTEXT_CAPABILITY_DECLARATION,
    rules::CONTEXT_CAPABILITY_PATH_TOKEN,
    rules::CONTEXT_CAPABILITY_PATH,
    rules::CONTEXT_CAPABILITY_SCOPE,
];

/// The exact combined executable-primitive surface.
pub(crate) const PRIMITIVE_RULES: &[RuleId; 15] = &[
    rules::STATEMENT_SEPARATOR,
    rules::SELECT_ALL,
    rules::SWIZZLE_SUBSCRIPT,
    rules::DOT_SUBSCRIPT,
    rules::DOT_SUBSCRIPT_INT,
    rules::WILDCARD,
    rules::SPREAD_OPERATOR,
    rules::OP_ASSIGN_OPERATOR,
    rules::ADD_ASSIGN_OPERATOR,
    rules::SUB_ASSIGN_OPERATOR,
    rules::MUL_ASSIGN_OPERATOR,
    rules::DIV_ASSIGN_OPERATOR,
    rules::EXP_ASSIGN_OPERATOR,
    rules::SEND_OPERATOR,
    rules::GUARD_OPERATOR,
];

/// The exact closed structure-shell surface.
pub(crate) const STRUCTURE_RULES: &[RuleId; 10] = &[
    rules::MATRIX_START,
    rules::MATRIX_END,
    rules::TABLE_START,
    rules::TABLE_END,
    rules::TABLE_SEPARATOR,
    rules::TABLE_HORZ,
    rules::TABLE_TOP,
    rules::ROW_SEPARATOR,
    rules::EMPTY_MAP,
    rules::EMPTY_SET,
];

/// The exact direct-rule outcome, including local committed recovery.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(super) enum CanonicalRuleOutcome {
    NoMatch,
    Matched,
    Committed,
}

impl From<Attempt> for CanonicalRuleOutcome {
    fn from(value: Attempt) -> Self {
        match value {
            Attempt::NoMatch => Self::NoMatch,
            Attempt::Matched => Self::Matched,
            Attempt::Committed => Self::Committed,
        }
    }
}

/// A narrow prefix snapshot used to exercise canonical source productions.
#[derive(Clone, Debug)]
pub(super) struct CanonicalSourceRuleSnapshot {
    pub source: TextSnapshot,
    pub rule: RuleId,
    pub root: Arc<GreenNode>,
    pub diagnostics: DiagnosticStore,
    pub nodes: NodeIndex,
    pub stats: ParseStats,
    pub outcome: CanonicalRuleOutcome,
    pub matched: bool,
    pub consumed: TextRange,
}

impl CanonicalSourceRuleSnapshot {
    pub fn syntax(&self) -> SyntaxNode {
        SyntaxNode::new_root_at(self.root.clone(), self.source.clone(), self.consumed.start)
    }

    pub fn is_strictly_clean(&self) -> bool {
        self.outcome == CanonicalRuleOutcome::Matched
            && self.diagnostics.is_empty()
            && !self.root.flags.intersects(
                NodeFlags::ERROR
                    | NodeFlags::MISSING
                    | NodeFlags::CONTAINS_ERROR
                    | NodeFlags::CONTAINS_MISSING,
            )
    }
}

/// Parse a single canonical production as a deterministic source prefix.
///
/// This remains internal test support: callers select one already-closed
/// production and receive its lossless fragment snapshot. Physical source is
/// intentionally preserved, including whitespace for diagnostic reporting.
pub(crate) fn parse_source_rule_prefix(
    source: TextSnapshot,
    rule: RuleId,
    config: ParseConfig,
    parse: impl FnOnce(&mut Parser<'_>) -> Attempt,
) -> CanonicalSourceRuleSnapshot {
    let mut ids = IdGenerator::new();
    let mut parser = Parser::new(
        &source,
        LexicalMode::CanonicalSourceFragment,
        config,
        &mut ids,
    );
    parser.set_resource_rule(rule);
    let fragment = parser.start();
    let start = parser.offset();
    let outcome = parse(&mut parser);
    fragment.complete(&mut parser, SyntaxKind::CanonicalFragment);
    // Finalizing an exhausted parser owns the unparsed remainder. Capture the
    // completed range and committed outcome after that resource envelope exists.
    if parser.is_halted() {
        parser.consume_resource_remainder();
    }
    let outcome = if parser.is_halted() {
        Attempt::Committed
    } else {
        outcome
    };
    let matched = outcome.accepted();
    let end = parser.offset();
    let output = parser.finish();
    // A valid zero-event budget cannot form the outer fragment. Return the
    // same bounded failed snapshot as the public parser instead of making a
    // test-support resource limit an assertion failure.
    let sink_result = sink(&output.events, &source, &mut ids).ok();
    let root = sink_result
        .as_ref()
        .map(|result| result.root.clone())
        .unwrap_or_else(|| {
            Arc::new(GreenNode {
                id: ids.node(),
                kind: SyntaxKind::CanonicalFragment,
                text_len: TextRange::new(start, end).len(),
                children: Default::default(),
                flags: NodeFlags::ERROR | NodeFlags::CONTAINS_ERROR,
                structural_hash: 0,
            })
        });

    let mut diagnostics = DiagnosticStore::new(source.revision());
    for mut pending in output.diagnostics.iter().cloned() {
        if let Some(event) = pending.event
            && let Some(node) = output
                .events
                .get(event)
                .and_then(|event| match event {
                    crate::document::parser::event::Event::Start { identity, .. } => {
                        identity.as_ref()
                    }
                    _ => None,
                })
                .or_else(|| {
                    sink_result
                        .as_ref()
                        .and_then(|result| result.event_nodes.get(&event))
                })
        {
            pending.diagnostic.primary = DiagnosticAnchor::Element {
                element: crate::document::SyntaxElementId::Node(*node),
                relative: pending.relative,
            };
        }
        diagnostics.push(pending.diagnostic);
    }

    let consumed = TextRange::new(start, end);
    let nodes = NodeIndex::build_at(&root, consumed.start);
    let mut stats = output.stats;
    stats.new_node_count = nodes.node_count() as u64;
    CanonicalSourceRuleSnapshot {
        source,
        rule,
        root,
        diagnostics,
        nodes,
        stats,
        outcome: outcome.into(),
        matched,
        consumed,
    }
}

/// Parse one exact literal, path, and kind grammar production as a deterministic source prefix.
///
/// This hidden test surface deliberately exposes only the selected closed
/// island. It is not a production parser root and does not dispatch any
/// enclosing literal, kind, variable, expression, or document production.
pub(super) fn parse_canonical_literal_path_kind_rule_for_test(
    source: TextSnapshot,
    rule: RuleId,
    config: ParseConfig,
) -> Option<CanonicalSourceRuleSnapshot> {
    is_literal_path_kind_rule(rule).then(|| {
        parse_source_rule_prefix(source, rule, config, |parser| match rule {
            rules::EMPTY => literals::parse_empty(parser),
            rules::ATOM => literals::parse_atom(parser),
            rules::STRING => literals::parse_string(parser),
            rules::UTF8_STRING => literals::parse_utf8_string(parser),
            rules::RAW_STRING => literals::parse_raw_string(parser),
            rules::BOOLEAN => literals::parse_boolean(parser),
            rules::TRUE_LITERAL => literals::parse_true_literal(parser),
            rules::FALSE_LITERAL => literals::parse_false_literal(parser),
            rules::NUMBER => literals::parse_number(parser),
            rules::COMPLEX_NUMBER => literals::parse_complex_number(parser),
            rules::REAL_NUMBER => literals::parse_real_number(parser),
            rules::UNTYPED_REAL_NUMBER => literals::parse_untyped_real_number(parser),
            rules::RATIONAL_LITERAL => literals::parse_rational_literal(parser),
            rules::SCIENTIFIC_LITERAL => literals::parse_scientific_literal(parser),
            rules::FLOAT_DECIMAL_START => literals::parse_float_decimal_start(parser),
            rules::FLOAT_FULL => literals::parse_float_full(parser),
            rules::FLOAT_LITERAL => literals::parse_float_literal(parser),
            rules::INTEGER_LITERAL => literals::parse_integer_literal(parser),
            rules::TYPED_INTEGER => literals::parse_typed_integer(parser),
            rules::UNTYPED_INTEGER => literals::parse_untyped_integer(parser),
            rules::DECIMAL_LITERAL => literals::parse_decimal_literal(parser),
            rules::HEXADECIMAL_LITERAL => literals::parse_hexadecimal_literal(parser),
            rules::OCTAL_LITERAL => literals::parse_octal_literal(parser),
            rules::BINARY_LITERAL => literals::parse_binary_literal(parser),
            rules::CONTEXT_ADDRESS_PATH_TOKEN => paths::parse_context_address_path_token(parser),
            rules::CONTEXT_ADDRESS_PATH => paths::parse_context_address_path(parser),
            rules::PREFIXED_CONTEXT_PATH => paths::parse_prefixed_context_path(parser),
            rules::KIND_ANY => kinds::parse_kind_any(parser),
            rules::KIND_EMPTY => kinds::parse_kind_empty(parser),
            rules::KIND_ATOM => kinds::parse_kind_atom(parser),
            _ => unreachable!(
                "literal, path, and kind grammar support guard rejects every other RuleId"
            ),
        })
    })
}

/// Parse one exact expression grammar operator production as a deterministic source
/// prefix. This hidden surface deliberately exposes only the closed operator
/// layer; it does not introduce a production parser root.
pub(super) fn parse_canonical_expression_rule_for_test(
    source: TextSnapshot,
    rule: RuleId,
    config: ParseConfig,
) -> Option<CanonicalSourceRuleSnapshot> {
    operators::supports(rule).then(|| {
        parse_source_rule_prefix(source, rule, config, |parser| {
            operators::parse_rule(parser, rule)
                .expect("expression grammar support guard accepts this RuleId")
        })
    })
}

/// Parse one exact module-import production as a deterministic
/// source prefix. This hidden surface exposes only the closed module-import
/// layer and deliberately does not introduce an import parser root.
pub(super) fn parse_canonical_module_import_rule_for_test(
    source: TextSnapshot,
    rule: RuleId,
    config: ParseConfig,
) -> Option<CanonicalSourceRuleSnapshot> {
    imports::supports(rule).then(|| {
        parse_source_rule_prefix(source, rule, config, |parser| {
            imports::parse_rule(parser, rule)
                .expect("module import grammar support guard accepts this RuleId")
        })
    })
}

/// Parse one exact declaration or source-import production as a
/// deterministic source prefix. This hidden surface stays within the closed
/// island and does not introduce a statement or document parser root.
pub(super) fn parse_canonical_declaration_rule_for_test(
    source: TextSnapshot,
    rule: RuleId,
    config: ParseConfig,
) -> Option<CanonicalSourceRuleSnapshot> {
    DECLARATION_RULES.contains(&rule).then(|| {
        parse_source_rule_prefix(source, rule, config, |parser| {
            source_imports::parse_rule(parser, rule)
                .or_else(|| declarations::parse_rule(parser, rule))
                .expect("declaration grammar support guard accepts this RuleId")
        })
    })
}

/// Parse one exact executable primitive as a deterministic source
/// prefix. This hidden surface deliberately does not introduce a subscript,
/// pattern, statement, expression, state-machine, or document root.
pub(super) fn parse_canonical_primitive_rule_for_test(
    source: TextSnapshot,
    rule: RuleId,
    config: ParseConfig,
) -> Option<CanonicalSourceRuleSnapshot> {
    PRIMITIVE_RULES.contains(&rule).then(|| {
        parse_source_rule_prefix(source, rule, config, |parser| {
            subscript_primitives::parse_rule(parser, rule)
                .or_else(|| pattern_primitives::parse_rule(parser, rule))
                .or_else(|| control_operators::parse_rule(parser, rule))
                .expect("executable primitives support guard accepts this RuleId")
        })
    })
}

/// Parse one exact structure-shell rule as a deterministic source
/// prefix. This hidden surface deliberately does not introduce a matrix,
/// table, map, set, structure, expression, or document root.
pub(super) fn parse_canonical_structure_rule_for_test(
    source: TextSnapshot,
    rule: RuleId,
    config: ParseConfig,
) -> Option<CanonicalSourceRuleSnapshot> {
    STRUCTURE_RULES.contains(&rule).then(|| {
        parse_source_rule_prefix(source, rule, config, |parser| {
            structure_shell::parse_rule(parser, rule)
                .expect("structure grammar support guard accepts this RuleId")
        })
    })
}

/// Parse one canonical recursive-core rule as a deterministic source
/// prefix for focused recursive grammar tests.
pub(super) fn parse_canonical_executable_rule_for_test(
    source: TextSnapshot,
    rule: RuleId,
    config: ParseConfig,
) -> Option<CanonicalSourceRuleSnapshot> {
    recursive_core::supports(rule).then(|| {
        parse_source_rule_prefix(source, rule, config, |parser| {
            recursive_core::parse_rule(parser, rule)
                .expect("executable grammar support guard accepts this RuleId")
        })
    })
}

fn is_literal_path_kind_rule(rule: RuleId) -> bool {
    matches!(
        rule,
        rules::EMPTY
            | rules::ATOM
            | rules::STRING
            | rules::UTF8_STRING
            | rules::RAW_STRING
            | rules::BOOLEAN
            | rules::TRUE_LITERAL
            | rules::FALSE_LITERAL
            | rules::NUMBER
            | rules::COMPLEX_NUMBER
            | rules::REAL_NUMBER
            | rules::UNTYPED_REAL_NUMBER
            | rules::RATIONAL_LITERAL
            | rules::SCIENTIFIC_LITERAL
            | rules::FLOAT_DECIMAL_START
            | rules::FLOAT_FULL
            | rules::FLOAT_LITERAL
            | rules::INTEGER_LITERAL
            | rules::TYPED_INTEGER
            | rules::UNTYPED_INTEGER
            | rules::DECIMAL_LITERAL
            | rules::HEXADECIMAL_LITERAL
            | rules::OCTAL_LITERAL
            | rules::BINARY_LITERAL
            | rules::CONTEXT_ADDRESS_PATH_TOKEN
            | rules::CONTEXT_ADDRESS_PATH
            | rules::PREFIXED_CONTEXT_PATH
            | rules::KIND_ANY
            | rules::KIND_EMPTY
            | rules::KIND_ATOM
    )
}

#[cfg(test)]
mod tests {
    use crate::document::{DocumentId, Revision};

    use super::*;

    #[test]
    fn literal_path_kind_helper_accepts_exactly_the_closed_30_rule_set() {
        let source = TextSnapshot::new(DocumentId(1), Revision(0), "").unwrap();
        let component_rules = [
            rules::EMPTY,
            rules::ATOM,
            rules::STRING,
            rules::UTF8_STRING,
            rules::RAW_STRING,
            rules::BOOLEAN,
            rules::TRUE_LITERAL,
            rules::FALSE_LITERAL,
            rules::NUMBER,
            rules::COMPLEX_NUMBER,
            rules::REAL_NUMBER,
            rules::UNTYPED_REAL_NUMBER,
            rules::RATIONAL_LITERAL,
            rules::SCIENTIFIC_LITERAL,
            rules::FLOAT_DECIMAL_START,
            rules::FLOAT_FULL,
            rules::FLOAT_LITERAL,
            rules::INTEGER_LITERAL,
            rules::TYPED_INTEGER,
            rules::UNTYPED_INTEGER,
            rules::DECIMAL_LITERAL,
            rules::HEXADECIMAL_LITERAL,
            rules::OCTAL_LITERAL,
            rules::BINARY_LITERAL,
            rules::CONTEXT_ADDRESS_PATH_TOKEN,
            rules::CONTEXT_ADDRESS_PATH,
            rules::PREFIXED_CONTEXT_PATH,
            rules::KIND_ANY,
            rules::KIND_EMPTY,
            rules::KIND_ATOM,
        ];
        assert_eq!(component_rules.len(), 30);
        for rule in component_rules {
            assert!(
                parse_canonical_literal_path_kind_rule_for_test(
                    source.clone(),
                    rule,
                    ParseConfig::default(),
                )
                .is_some(),
                "{rule:?}"
            );
        }
        assert!(
            parse_canonical_literal_path_kind_rule_for_test(
                source,
                rules::LITERAL,
                ParseConfig::default(),
            )
            .is_none()
        );
    }

    #[test]
    fn expression_helper_accepts_exactly_the_closed_53_rule_set() {
        let source = TextSnapshot::new(DocumentId(1), Revision(0), "").unwrap();
        assert_eq!(operators::EXPRESSION_OPERATOR_RULES.len(), 53);
        for rule in operators::EXPRESSION_OPERATOR_RULES {
            assert!(
                parse_canonical_expression_rule_for_test(
                    source.clone(),
                    *rule,
                    ParseConfig::default(),
                )
                .is_some(),
                "{rule:?}"
            );
        }
        assert!(
            parse_canonical_expression_rule_for_test(
                source,
                rules::EXPRESSION,
                ParseConfig::default(),
            )
            .is_none()
        );
    }

    #[test]
    fn module_import_helper_accepts_exactly_the_closed_19_rule_set() {
        let source = TextSnapshot::new(DocumentId(1), Revision(0), "").unwrap();
        assert_eq!(imports::MODULE_IMPORT_RULES.len(), 19);
        for rule in imports::MODULE_IMPORT_RULES {
            assert!(
                parse_canonical_module_import_rule_for_test(
                    source.clone(),
                    *rule,
                    ParseConfig::default(),
                )
                .is_some(),
                "{rule:?}"
            );
        }
        assert!(
            parse_canonical_module_import_rule_for_test(
                source,
                rules::IMPORT_DECLARATION,
                ParseConfig::default(),
            )
            .is_none()
        );
    }
}
