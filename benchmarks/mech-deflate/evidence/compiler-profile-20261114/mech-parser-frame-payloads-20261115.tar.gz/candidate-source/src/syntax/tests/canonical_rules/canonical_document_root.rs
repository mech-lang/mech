use std::fs;
use std::path::PathBuf;

use crate::document::parser::canonical::parse_canonical_document_rule_for_test;
use crate::document::parser::rules;
use crate::document::{
    AstNode, CodeBlockSyntax, DocumentId, DocumentSyntax, ParseConfig, ParseLimits,
    RecursiveSyntaxNode, Revision, SyntaxKind, SyntaxNode, TextSnapshot, compact_debug_tree,
    parse_canonical_document, reconstruct_source, validate_lossless,
};

fn repository_root() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../..")
}

fn source(text: &str) -> TextSnapshot {
    TextSnapshot::new(DocumentId(0x2d7), Revision(1), text).unwrap()
}

fn piece_source(parts: &[&str]) -> TextSnapshot {
    let mut snapshot = TextSnapshot::new(DocumentId(0x2d8), Revision(1), "").unwrap();
    for part in parts {
        snapshot = snapshot.append((*part).to_owned()).unwrap();
    }
    snapshot
}

fn find(node: SyntaxNode, kind: SyntaxKind) -> Option<SyntaxNode> {
    if node.kind() == kind {
        return Some(node);
    }
    node.children().find_map(|child| find(child, kind))
}

fn count(node: &SyntaxNode, kind: SyntaxKind) -> usize {
    usize::from(node.kind() == kind)
        + node
            .children()
            .map(|child| count(&child, kind))
            .sum::<usize>()
}

#[test]
fn canonical_document_root_owns_the_whole_source_fixture_corpus() {
    for (id, path, accepted) in [
        (
            "compiler",
            "tests/fixtures/syntax-source-boundary/compiler.mec",
            true,
        ),
        (
            "config",
            "tests/fixtures/syntax-source-boundary/config.mec",
            true,
        ),
        (
            "document",
            "tests/fixtures/syntax-source-boundary/document.mec",
            true,
        ),
        (
            "empty",
            "tests/fixtures/syntax-source-boundary/empty.mec",
            true,
        ),
        (
            "executable",
            "tests/fixtures/syntax-source-boundary/executable.mec",
            true,
        ),
        (
            "interactive",
            "tests/fixtures/syntax-source-boundary/interactive.mec",
            true,
        ),
        (
            "malformed",
            "tests/fixtures/syntax-source-boundary/malformed.mec",
            false,
        ),
        (
            "resolver-index",
            "tests/fixtures/syntax-source-boundary/resolver-index.mec",
            true,
        ),
        (
            "wasm-document",
            "tests/fixtures/syntax-source-boundary/wasm-document.mec",
            true,
        ),
    ] {
        let text = fs::read_to_string(repository_root().join(path)).unwrap();
        let snapshot = parse_canonical_document(source(&text), ParseConfig::default());
        validate_lossless(&snapshot.root, &snapshot.source).unwrap();
        assert_eq!(
            reconstruct_source(&snapshot.root, &snapshot.source).unwrap(),
            text,
            "{}",
            id
        );
        assert_eq!(snapshot.syntax().kind(), SyntaxKind::Document);
        let document = DocumentSyntax::cast(snapshot.syntax()).unwrap();
        if accepted {
            assert!(
                snapshot.diagnostics.is_empty(),
                "{}: {:#?}",
                id,
                snapshot.diagnostics.as_slice()
            );
            if id != "empty" {
                assert!(!document.sections().is_empty(), "{}", id);
            }
        } else {
            assert!(!snapshot.diagnostics.is_empty(), "{}", id);
        }
    }
}

#[test]
fn canonical_document_is_the_supported_document_root() {
    let parsed = parse_canonical_document(source("answer := 42\n"), ParseConfig::default());
    assert_eq!(parsed.syntax().kind(), SyntaxKind::Document);
}

#[test]
fn standalone_ranges_keep_executable_document_ownership() {
    for text in [
        "1..10\n",
        "1..=10\n",
        "1..2..9\n",
        "1..2..=9\n",
        "-3..=3\n",
        "1.5..=3.5\r\n",
    ] {
        let parsed = parse_canonical_document(source(text), ParseConfig::default());
        assert!(
            parsed.is_strictly_clean(),
            "{text:?}: {:?}",
            parsed.diagnostics
        );
        validate_lossless(&parsed.root, &parsed.source).unwrap();
        assert_eq!(
            reconstruct_source(&parsed.root, &parsed.source).unwrap(),
            text
        );
        assert_eq!(
            count(&parsed.syntax(), SyntaxKind::RangeExpression),
            1,
            "{text:?}"
        );
        assert_eq!(count(&parsed.syntax(), SyntaxKind::MechCode), 1, "{text:?}");
        assert_eq!(
            count(&parsed.syntax(), SyntaxKind::OrderedListItem),
            0,
            "{text:?}"
        );
    }
}

#[test]
fn ordered_list_markers_do_not_split_adjacent_range_periods() {
    use crate::document::parser::canonical::CanonicalRuleOutcome;

    for text in ["1..10\n", "1..=10\n", "1..2..9\n", "1..2..=9\n"] {
        let parsed = parse_canonical_document_rule_for_test(
            source(text),
            rules::ORDERED_LIST_ITEM,
            ParseConfig::default(),
        )
        .unwrap();
        assert_eq!(parsed.outcome, CanonicalRuleOutcome::NoMatch, "{text:?}");
        assert!(parsed.consumed.is_empty(), "{text:?}");
        assert!(parsed.diagnostics.is_empty(), "{text:?}");
    }
    for (text, items) in [
        ("1.first\n2.second\n", 2),
        ("1. first\n", 1),
        ("1. .dot-prefixed prose\n", 1),
    ] {
        let parsed = parse_canonical_document(source(text), ParseConfig::default());
        assert!(
            parsed.is_strictly_clean(),
            "{text:?}: {:?}",
            parsed.diagnostics
        );
        validate_lossless(&parsed.root, &parsed.source).unwrap();
        assert_eq!(
            reconstruct_source(&parsed.root, &parsed.source).unwrap(),
            text
        );
        assert_eq!(
            count(&parsed.syntax(), SyntaxKind::OrderedListItem),
            items,
            "{text:?}"
        );
        assert_eq!(
            count(&parsed.syntax(), SyntaxKind::RangeExpression),
            0,
            "{text:?}"
        );
        assert_eq!(count(&parsed.syntax(), SyntaxKind::MechCode), 0, "{text:?}");
    }
}

#[test]
fn typed_document_exposes_title_front_matter_sections_and_fences() {
    let text = fs::read_to_string(
        repository_root().join("tests/fixtures/syntax-source-boundary/document.mec"),
    )
    .unwrap();
    let snapshot = parse_canonical_document(source(&text), ParseConfig::default());
    let document = DocumentSyntax::cast(snapshot.syntax()).unwrap();
    let title = document.title().expect("title");
    let front_matter = title.front_matter().expect("title front matter");
    let keys = front_matter
        .keys()
        .into_iter()
        .map(|key| key.syntax().text().unwrap())
        .collect::<Vec<_>>();
    assert_eq!(keys, ["author", "section"]);
    assert!(!document.sections().is_empty());

    let fence = find(snapshot.syntax(), SyntaxKind::CodeBlock)
        .and_then(CodeBlockSyntax::cast)
        .expect("fenced code block");
    let delimiters = fence
        .delimiters()
        .into_iter()
        .map(|token| token.text().unwrap())
        .collect::<Vec<_>>();
    assert_eq!(delimiters, ["~~~", "~~~"]);
}

#[test]
fn mismatched_fence_is_lossless_and_diagnostic() {
    let text = "```mech\nanswer\n~~~\n";
    let snapshot = parse_canonical_document(source(text), ParseConfig::default());
    validate_lossless(&snapshot.root, &snapshot.source).unwrap();
    assert_eq!(
        reconstruct_source(&snapshot.root, &snapshot.source).unwrap(),
        text
    );
    assert!(!snapshot.diagnostics.is_empty());
    let fence = find(snapshot.syntax(), SyntaxKind::CodeBlock)
        .and_then(CodeBlockSyntax::cast)
        .expect("mismatched fence must retain typed code-block structure");
    assert_eq!(fence.delimiters().len(), 2);
    let document = DocumentSyntax::cast(snapshot.syntax()).unwrap();
    assert!(
        document
            .missing_tokens()
            .iter()
            .any(|token| token.kind() == SyntaxKind::GraveCodeBlockSigil)
    );
}

#[test]
fn committed_statement_recovery_is_not_replaced_by_a_short_expression() {
    let snapshot = parse_canonical_document(source("x :=\n"), ParseConfig::default());
    validate_lossless(&snapshot.root, &snapshot.source).unwrap();
    assert!(!snapshot.diagnostics.is_empty());
    assert!(find(snapshot.syntax(), SyntaxKind::VariableDefine).is_some());
}

#[test]
fn recursive_recovery_retains_owned_children_and_later_document_units() {
    for (first, owner_kind, child_kind, children, closer, code) in [
        (
            "(1,,3)",
            SyntaxKind::Tuple,
            SyntaxKind::IntegerLiteral,
            2,
            Some(")"),
            "syntax/missing-tuple-item",
        ),
        (
            "{1: 2, 3:, 4: 5}",
            SyntaxKind::Map,
            SyntaxKind::MapEntry,
            3,
            Some("}"),
            "syntax/missing-mapping-value",
        ),
        (
            "{1 + | x <- xs}",
            SyntaxKind::SetComprehension,
            SyntaxKind::Generator,
            1,
            Some("}"),
            "syntax/missing-operator-operand",
        ),
        (
            "# -> :next",
            SyntaxKind::FsmPipe,
            SyntaxKind::FsmStateTransition,
            1,
            None,
            "syntax/missing-fsm-name",
        ),
    ] {
        let text = format!("{first}\nafter := 9\n");
        let parsed = parse_canonical_document(source(&text), ParseConfig::default());
        validate_lossless(&parsed.root, &parsed.source).unwrap();
        assert_eq!(
            reconstruct_source(&parsed.root, &parsed.source).unwrap(),
            text
        );
        let owner = find(parsed.syntax(), owner_kind)
            .unwrap_or_else(|| panic!("{first}: {}", compact_debug_tree(&parsed.syntax())));
        assert_eq!(owner.text().unwrap().trim(), first, "{first}");
        assert_eq!(count(&owner, child_kind), children, "{first}");
        assert!(
            find(owner.clone(), SyntaxKind::Missing).is_some(),
            "{first}"
        );
        if let Some(closer) = closer {
            let token = owner
                .children_with_tokens()
                .into_iter()
                .filter_map(|element| match element {
                    crate::document::SyntaxElement::Token(token) => Some(token),
                    _ => None,
                })
                .find(|token| token.text().is_ok_and(|text| text == closer))
                .expect("physical closer remains a direct token of the recovered owner");
            assert!(!token.flags().contains(crate::document::TokenFlags::MISSING));
        }
        assert!(
            parsed
                .diagnostics
                .iter()
                .any(|diagnostic| diagnostic.code.as_str() == code && diagnostic.rule.is_some()),
            "{first}: {:?}",
            parsed.diagnostics
        );
        let later = find(parsed.syntax(), SyntaxKind::VariableDefine)
            .expect("later document definition survives recovery");
        assert_eq!(later.text().unwrap().trim(), "after := 9", "{first}");
        assert!(later.range().start >= owner.range().end);
    }
}

#[test]
fn comment_selection_preserves_complete_recursive_negation() {
    let expression = parse_canonical_document(source("--x\n"), ParseConfig::default());
    assert!(
        expression.is_strictly_clean(),
        "{:#?}",
        expression.diagnostics
    );
    assert_eq!(count(&expression.syntax(), SyntaxKind::NegateFactor), 2);
    assert_eq!(count(&expression.syntax(), SyntaxKind::Comment), 0);

    let comment = parse_canonical_document(source("-- note\n"), ParseConfig::default());
    assert!(comment.is_strictly_clean(), "{:#?}", comment.diagnostics);
    assert_eq!(count(&comment.syntax(), SyntaxKind::Comment), 1);
    assert_eq!(count(&comment.syntax(), SyntaxKind::Expression), 0);
}

#[test]
fn comment_selection_preserves_whitespace_and_committed_expression_recovery() {
    let comment = parse_canonical_document_rule_for_test(
        source("\n  -- note"),
        rules::MECH_CODE_ALT,
        ParseConfig::default(),
    )
    .unwrap();
    assert!(comment.is_strictly_clean(), "{:#?}", comment.diagnostics);
    let comment_node = find(comment.syntax(), SyntaxKind::Comment).expect("typed comment");
    assert_eq!(comment_node.range().start.0, 3);

    let expression = parse_canonical_document(source("--x +\n"), ParseConfig::default());
    assert!(!expression.is_strictly_clean());
    assert_eq!(count(&expression.syntax(), SyntaxKind::NegateFactor), 2);
    assert_eq!(count(&expression.syntax(), SyntaxKind::Comment), 0);
}

#[test]
fn distinctive_document_openers_recover_required_closers() {
    #[cfg(feature = "mika")]
    {
        let mika = parse_canonical_document(source("~∘~⸢text\n"), ParseConfig::default());
        assert!(!mika.is_strictly_clean());
        assert!(find(mika.syntax(), SyntaxKind::MikaSection).is_some());
        assert!(mika.diagnostics.iter().any(|diagnostic| {
            diagnostic.code.as_str() == "syntax/missing-mika-section-closer"
        }));
    }

    let inline = parse_canonical_document(source("Text {{x := 1}\n"), ParseConfig::default());
    assert!(!inline.is_strictly_clean());
    assert!(find(inline.syntax(), SyntaxKind::InlineMechCode).is_some());
    assert!(
        inline
            .diagnostics
            .iter()
            .any(|diagnostic| { diagnostic.code.as_str() == "syntax/missing-inline-mech-closer" })
    );

    let empty_inline = parse_canonical_document(source("Text {{"), ParseConfig::default());
    assert!(!empty_inline.is_strictly_clean());
    assert!(find(empty_inline.syntax(), SyntaxKind::InlineMechCode).is_some());
    assert!(
        empty_inline
            .diagnostics
            .iter()
            .any(|diagnostic| { diagnostic.code.as_str() == "syntax/missing-inline-mech-body" })
    );

    for text in ["```", "```mech"] {
        let fence = parse_canonical_document(source(text), ParseConfig::default());
        assert!(!fence.is_strictly_clean(), "{text:?}");
        assert!(find(fence.syntax(), SyntaxKind::CodeBlock).is_some());
        assert!(fence.diagnostics.iter().any(|diagnostic| {
            diagnostic.code.as_str() == "syntax/missing-codeblock-header-newline"
        }));
    }
}

#[cfg(feature = "mika")]
#[test]
fn mika_glyph_roles_are_determined_by_position() {
    let micro = parse_canonical_document(source("╭◉╮\n"), ParseConfig::default());
    assert!(micro.is_strictly_clean(), "{:#?}", micro.diagnostics);
    assert!(find(micro.syntax(), SyntaxKind::MicroMika).is_some());
    assert_eq!(count(&micro.syntax(), SyntaxKind::MikaNose), 1);
    assert_eq!(count(&micro.syntax(), SyntaxKind::MikaEyeLeft), 0);
    assert_eq!(count(&micro.syntax(), SyntaxKind::MikaEyeRight), 0);

    let mini = parse_canonical_document(source("(◉◯◉)\n"), ParseConfig::default());
    assert!(mini.is_strictly_clean(), "{:#?}", mini.diagnostics);
    assert!(find(mini.syntax(), SyntaxKind::MiniMika).is_some());
    assert_eq!(count(&mini.syntax(), SyntaxKind::MikaNose), 1);
    assert_eq!(count(&mini.syntax(), SyntaxKind::MikaEyeLeft), 1);
    assert_eq!(count(&mini.syntax(), SyntaxKind::MikaEyeRight), 1);
}

#[test]
fn consecutive_underlined_subtitles_start_distinct_sections() {
    let snapshot = parse_canonical_document(
        source("1.First\n-----\n2.Second\n------\n"),
        ParseConfig::default(),
    );
    assert!(snapshot.is_strictly_clean(), "{:#?}", snapshot.diagnostics);
    let document = DocumentSyntax::cast(snapshot.syntax()).unwrap();
    assert_eq!(document.sections().len(), 2);
    assert_eq!(count(document.syntax(), SyntaxKind::UlSubtitle), 2);
}

#[test]
fn annotated_underlined_subtitles_do_not_require_source_ordinals() {
    let snapshot = parse_canonical_document(
        source("calculation @compute\n-----------\nresult := 1\n"),
        ParseConfig::default(),
    );
    assert!(
        snapshot.is_strictly_clean(),
        "{:#?}\n{}",
        snapshot.diagnostics,
        compact_debug_tree(&snapshot.syntax())
    );
    let document = DocumentSyntax::cast(snapshot.syntax()).unwrap();
    assert_eq!(document.sections().len(), 1);
    assert_eq!(count(document.syntax(), SyntaxKind::UlSubtitle), 1);
}

#[test]
fn document_resource_limits_remain_hard_and_lossless() {
    let text = "x := [1, 2, 3]\n".repeat(64);
    let limits = ParseLimits {
        fuel: 64,
        max_events: 96,
        max_diagnostics: 4,
        max_recovery_bytes: 4_096,
        ..ParseLimits::default()
    };
    let snapshot = parse_canonical_document(source(&text), ParseConfig { limits });
    assert!(snapshot.stats.events_emitted <= u64::from(limits.max_events));
    assert!(snapshot.diagnostics.len() <= limits.max_diagnostics as usize);
    validate_lossless(&snapshot.root, &snapshot.source).unwrap();
    assert_eq!(
        reconstruct_source(&snapshot.root, &snapshot.source).unwrap(),
        text
    );
}

#[test]
fn piece_backed_documents_match_contiguous_documents() {
    let text = "# Demo\n\n~~~mech\nanswer := 42\n~~~\n";
    let contiguous = parse_canonical_document(source(text), ParseConfig::default());
    let piece_backed = parse_canonical_document(
        piece_source(&["# De", "mo\n\n~", "~~mech\nans", "wer := 42\n~~", "~\n"]),
        ParseConfig::default(),
    );
    assert_eq!(
        compact_debug_tree(&piece_backed.syntax()),
        compact_debug_tree(&contiguous.syntax())
    );
    assert_eq!(
        piece_backed.diagnostics.as_slice(),
        contiguous.diagnostics.as_slice()
    );
    validate_lossless(&piece_backed.root, &piece_backed.source).unwrap();
}

#[test]
fn repeated_document_units_remain_measured_linear() {
    const SLACK: u64 = 2_048;
    let measurements = [8_usize, 16, 32]
        .into_iter()
        .map(|size| {
            let text = "answer := 1\n".repeat(size);
            let parsed = parse_canonical_document(source(&text), ParseConfig::default());
            assert!(
                parsed.is_strictly_clean(),
                "{size}: {:#?}",
                parsed.diagnostics
            );
            validate_lossless(&parsed.root, &parsed.source).unwrap();
            (parsed.stats.parser_steps, parsed.stats.events_emitted)
        })
        .collect::<Vec<_>>();
    for pair in measurements.windows(2) {
        let (small_steps, small_events) = pair[0];
        let (large_steps, large_events) = pair[1];
        assert!(
            large_steps <= small_steps.saturating_mul(2).saturating_add(SLACK),
            "parser steps were not linear: {measurements:?}"
        );
        assert!(
            large_events <= small_events.saturating_mul(2).saturating_add(SLACK),
            "parser events were not linear: {measurements:?}"
        );
    }
}

#[test]
fn committed_negation_must_reach_a_terminal_before_displacing_a_comment() {
    for text in ["--- heading\n", "---- heading\n", "  --- heading\r\n"] {
        let parsed = parse_canonical_document(source(text), ParseConfig::default());
        assert!(
            parsed.is_strictly_clean(),
            "{text:?}: {:?}",
            parsed.diagnostics
        );
        assert_eq!(count(&parsed.syntax(), SyntaxKind::Comment), 1);
        assert_eq!(count(&parsed.syntax(), SyntaxKind::Expression), 0);
        validate_lossless(&parsed.root, &parsed.source).unwrap();
        assert_eq!(
            reconstruct_source(&parsed.root, &parsed.source).unwrap(),
            text
        );
    }
    for (text, clean) in [("---x\n", true), ("--x +\n", false)] {
        let parsed = parse_canonical_document(source(text), ParseConfig::default());
        assert_eq!(parsed.is_strictly_clean(), clean);
        assert_eq!(count(&parsed.syntax(), SyntaxKind::Comment), 0);
        assert!(count(&parsed.syntax(), SyntaxKind::NegateFactor) >= 2);
    }
}

#[test]
fn comment_arbitration_does_not_spend_the_recovery_budget() {
    for (limit, copies) in [(0, 4), (1, 32), (65_536, 10_000)] {
        let text = "--- heading\n".repeat(copies);
        let config = ParseConfig {
            limits: ParseLimits {
                max_recovery_bytes: limit,
                fuel: 100_000_000,
                ..ParseLimits::default()
            },
        };
        let parsed = parse_canonical_document(source(&text), config);
        assert!(
            parsed.is_strictly_clean(),
            "limit={limit}, copies={copies}: {:?}",
            parsed.diagnostics
        );
        assert_eq!(parsed.stats.recovery_bytes, 0);
        assert_eq!(count(&parsed.syntax(), SyntaxKind::Comment), copies);
        validate_lossless(&parsed.root, &parsed.source).unwrap();
        assert_eq!(
            reconstruct_source(&parsed.root, &parsed.source).unwrap(),
            text
        );
    }
    // The probe's scoped policy must not disable real recovery on later code.
    let parsed =
        parse_canonical_document(source("--- heading\nx := [1,,2]\n"), ParseConfig::default());
    assert!(!parsed.is_strictly_clean());
    assert!(parsed.stats.recovery_bytes > 0);
    assert_eq!(count(&parsed.syntax(), SyntaxKind::Comment), 1);
    let parsed = parse_canonical_document(
        source("--x +\n"),
        ParseConfig {
            limits: ParseLimits {
                max_recovery_bytes: 0,
                ..ParseLimits::default()
            },
        },
    );
    assert!(!parsed.is_strictly_clean());
    assert_eq!(count(&parsed.syntax(), SyntaxKind::Comment), 0);
    assert_eq!(parsed.stats.recovery_bytes, 0);
}

#[test]
fn function_terminators_do_not_force_a_trailing_slice() {
    for text in [
        "identity(value<f32>) = result<f32> :=\n  result := value.\n",
        "identity(value<f32>) = result<f32> :=\n  result := value.",
    ] {
        let snapshot = parse_canonical_document(source(text), ParseConfig::default());
        assert!(snapshot.is_strictly_clean(), "{:?}", snapshot.diagnostics);
        assert_eq!(count(&snapshot.syntax(), SyntaxKind::FunctionDefine), 1);
    }
}

#[test]
fn nested_numbered_subtitles_keep_document_ownership_before_expression_recovery() {
    let text = "(5.1.1) Predictor\n\nx := (1 + 2)\n\n(5.3.2) Validation\n\nx + 1\n(1) + 2\n";
    let parsed = parse_canonical_document(source(text), ParseConfig::default());
    assert!(parsed.diagnostics.is_empty(), "{:#?}", parsed.diagnostics);
    assert_eq!(count(&parsed.syntax(), SyntaxKind::Subtitle), 2);
    assert_eq!(count(&parsed.syntax(), SyntaxKind::VariableDefine), 1);
    assert_eq!(
        reconstruct_source(&parsed.root, &parsed.source).unwrap(),
        text
    );
}
