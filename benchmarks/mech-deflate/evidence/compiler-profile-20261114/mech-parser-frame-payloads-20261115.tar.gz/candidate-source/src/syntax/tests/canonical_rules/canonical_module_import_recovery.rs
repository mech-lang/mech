use crate::document::parser::canonical::{
    CanonicalRuleOutcome, parse_canonical_module_import_rule_for_test,
};
use crate::document::parser::rules;
use crate::document::{
    DocumentId, ExpectedSyntax, FixApplicability, ParseConfig, RecoveryAction, Revision, RuleId,
    SyntaxKind, SyntaxNode, TextRange, TextSize, TextSnapshot, TokenFlags,
};

fn source(text: &str) -> TextSnapshot {
    TextSnapshot::new(DocumentId(927), Revision(0), text).unwrap()
}

fn parse(
    text: &str,
    rule: RuleId,
) -> crate::document::parser::canonical::CanonicalSourceRuleSnapshot {
    parse_canonical_module_import_rule_for_test(source(text), rule, ParseConfig::default())
        .unwrap_or_else(|| panic!("{rule:?} is not a module import grammar direct rule"))
}

fn find_node(root: &SyntaxNode, kind: SyntaxKind) -> Option<SyntaxNode> {
    if root.kind() == kind {
        return Some(root.clone());
    }
    root.children().find_map(|child| find_node(&child, kind))
}

fn diagnostic_codes(
    parsed: &crate::document::parser::canonical::CanonicalSourceRuleSnapshot,
) -> Vec<String> {
    parsed
        .diagnostics
        .iter()
        .map(|diagnostic| diagnostic.code.as_str().to_owned())
        .collect()
}

fn assert_committed(rule: RuleId, input: &str, expected_codes: &[&str]) {
    let parsed = parse(input, rule);
    assert!(parsed.matched, "{rule:?} on {input:?}");
    assert_eq!(parsed.outcome, CanonicalRuleOutcome::Committed, "{input:?}");
    assert_eq!(
        diagnostic_codes(&parsed),
        expected_codes
            .iter()
            .map(|code| (*code).to_owned())
            .collect::<Vec<_>>(),
        "{input:?}",
    );
}

#[test]
fn intrinsic_segments_commit_to_a_local_missing_name() {
    for (rule, input) in [
        (rules::MODULE_IMPORT_INTRINSIC_SEGMENT, "_"),
        (rules::MODULE_IMPORT_PATH, "math/_"),
        (rules::MODULE_IMPORT, "+> math/_"),
    ] {
        let parsed = parse(input, rule);
        assert!(parsed.matched, "{input:?}");
        assert_eq!(parsed.outcome, CanonicalRuleOutcome::Committed, "{input:?}");
        let diagnostic = parsed.diagnostics.iter().next().unwrap();
        assert_eq!(
            diagnostic.code.as_str(),
            "syntax/missing-module-import-intrinsic-name",
            "{input:?}",
        );
        assert_eq!(
            diagnostic.expected,
            vec![ExpectedSyntax::Production(
                "module-import-name-segment".into()
            )],
        );
        assert!(diagnostic.fixes.is_empty());
        assert!(find_node(&parsed.syntax(), SyntaxKind::Missing).is_some());
    }
}

#[test]
fn context_alias_and_completed_alias_operator_have_local_recovery() {
    assert_committed(
        rules::MODULE_IMPORT,
        "+> alias :=",
        &["syntax/missing-module-import-alias-target"],
    );
    assert_committed(
        rules::MODULE_IMPORT,
        "+> alias := math",
        &["syntax/missing-module-import-aliased-item-separator"],
    );
    assert_committed(
        rules::MODULE_IMPORT,
        "+> alias := math/",
        &["syntax/missing-module-import-aliased-item"],
    );
    assert_committed(
        rules::MODULE_IMPORT,
        "+> @ctx :=",
        &["syntax/missing-module-import-alias-target"],
    );

    let plain = parse("+> alias", rules::MODULE_IMPORT);
    assert!(plain.is_strictly_clean());
    assert_eq!(plain.outcome, CanonicalRuleOutcome::Matched);
    assert!(find_node(&plain.syntax(), SyntaxKind::ModuleOnlyImport).is_some());
}

#[test]
fn context_alias_prefixes_commit_with_required_structure() {
    assert_committed(
        rules::MODULE_IMPORT,
        "+> @",
        &["syntax/missing-module-import-context-alias"],
    );
    assert_committed(
        rules::MODULE_IMPORT,
        "+> @ctx",
        &["syntax/missing-module-import-alias-operator"],
    );

    let missing_equal = parse("+> @ctx :", rules::MODULE_IMPORT);
    assert_eq!(missing_equal.outcome, CanonicalRuleOutcome::Committed);
    assert_eq!(
        diagnostic_codes(&missing_equal),
        ["syntax/missing-module-import-alias-equal"]
    );
    assert!(
        missing_equal
            .syntax()
            .tokens()
            .into_iter()
            .any(|token| token.kind() == SyntaxKind::Colon
                && !token.flags().contains(TokenFlags::MISSING))
    );
    assert!(
        missing_equal
            .syntax()
            .tokens()
            .into_iter()
            .any(|token| token.kind() == SyntaxKind::Equal
                && token.flags().contains(TokenFlags::MISSING))
    );

    assert_committed(
        rules::MODULE_IMPORT,
        "+> @ctx :=",
        &["syntax/missing-module-import-alias-target"],
    );
    assert_committed(
        rules::MODULE_IMPORT,
        "+> @ctx := math",
        &["syntax/missing-module-import-aliased-item-separator"],
    );

    let slash_context = parse("+> @ctx/path := math/sin", rules::MODULE_IMPORT);
    assert_eq!(slash_context.outcome, CanonicalRuleOutcome::Committed);
    assert_eq!(
        diagnostic_codes(&slash_context),
        ["syntax/invalid-module-import-context-alias"]
    );
    let primary = slash_context
        .diagnostics
        .iter()
        .next()
        .unwrap()
        .primary
        .resolve(slash_context.source.revision(), &slash_context.nodes)
        .unwrap();
    assert_eq!(primary.start, TextSize(7));
    assert!(
        find_node(&slash_context.syntax(), SyntaxKind::Error).is_some(),
        "a slash-continuing context alias must retain its structural error"
    );
}

#[test]
fn module_suffix_and_group_commit_points_remain_local() {
    assert_committed(
        rules::MODULE_IMPORT,
        "+> math/",
        &["syntax/missing-module-import-suffix"],
    );
    assert_committed(
        rules::MODULE_IMPORT,
        "+> math/{",
        &[
            "syntax/missing-module-import-group-item",
            "syntax/unclosed-module-import-group",
        ],
    );
    assert_committed(
        rules::MODULE_IMPORT,
        "+> math/{}",
        &["syntax/missing-module-import-group-item"],
    );
    assert_committed(
        rules::MODULE_IMPORT,
        "+> math/{sin,",
        &[
            "syntax/missing-module-import-group-item",
            "syntax/unclosed-module-import-group",
        ],
    );
}

#[test]
fn missing_group_closer_inserts_a_zero_width_brace_with_a_fix() {
    let parsed = parse("+> math/{sin", rules::MODULE_IMPORT);
    assert_eq!(parsed.outcome, CanonicalRuleOutcome::Committed);
    let diagnostic = parsed
        .diagnostics
        .iter()
        .find(|diagnostic| diagnostic.code.as_str() == "syntax/unclosed-module-import-group")
        .unwrap();
    assert_eq!(
        diagnostic.expected,
        vec![ExpectedSyntax::Token(SyntaxKind::RightBrace)]
    );
    assert_eq!(
        diagnostic.recovery,
        Some(RecoveryAction::Insert {
            syntax: ExpectedSyntax::Token(SyntaxKind::RightBrace),
            at: TextSize(12),
        })
    );
    assert_eq!(diagnostic.fixes.len(), 1);
    assert_eq!(
        diagnostic.fixes[0].applicability,
        FixApplicability::MachineApplicable
    );

    let missing = find_node(&parsed.syntax(), SyntaxKind::Missing).unwrap();
    let braces = missing
        .tokens()
        .into_iter()
        .filter(|token| token.kind() == SyntaxKind::RightBrace)
        .collect::<Vec<_>>();
    assert_eq!(braces.len(), 1);
    assert_eq!(braces[0].range(), TextRange::empty(TextSize(12)));
    assert!(braces[0].flags().contains(TokenFlags::MISSING));
}

#[test]
fn shared_sigil_alone_never_commits_recovery() {
    for input in ["", "+", "+>", "+> ", "+>\nmath", "+> /", "+⟩ math"] {
        let parsed = parse(input, rules::MODULE_IMPORT);
        assert!(!parsed.matched, "{input:?}");
        assert_eq!(parsed.outcome, CanonicalRuleOutcome::NoMatch, "{input:?}");
        assert_eq!(
            parsed.consumed,
            TextRange::empty(TextSize::ZERO),
            "{input:?}"
        );
        assert!(parsed.diagnostics.is_empty(), "{input:?}");
    }
}

#[test]
fn module_import_resource_exhaustion_keeps_nested_recovery_owners_lossless() {
    use crate::document::parser::canonical::parse_canonical_module_import_rule_for_test;
    use crate::document::{DocumentId, Revision, TextSnapshot, validate_lossless_range};
    for input in [
        "+> @ctx/path;next",
        "+> @ctx/💡\u{301}\r\nnext",
        "+> @ctx :",
        "+> @",
        "+> alias := math/",
        "+> math/{sin,}",
        "+> math/{_}",
    ] {
        for fuel in 0..=80 {
            for max_events in [8, 16, 64, 1024] {
                let mut config = ParseConfig::default();
                config.limits.fuel = fuel;
                config.limits.max_events = max_events;
                let source = TextSnapshot::new(DocumentId(826), Revision(0), input).unwrap();
                let parsed = parse_canonical_module_import_rule_for_test(
                    source,
                    rules::MODULE_IMPORT,
                    config,
                )
                .unwrap();
                validate_lossless_range(&parsed.root, &parsed.source, parsed.consumed)
                    .unwrap_or_else(|error| {
                        panic!("{input:?}, fuel {fuel}, events {max_events}: {error:?}")
                    });
            }
        }
    }
}
