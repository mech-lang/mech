from pathlib import Path
import ast,hashlib,json

tmp=Path('/private/tmp');root=tmp/'mech-parser-frame-payloads-20261115';rows=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def derive(label,transform):
    p=tmp/('mech-'+label+'-parser-event-cursor-20261115.py');s=p.read_text().replace('parser-event-cursor','parser-frame-payloads').replace('6ce7a53b36d3677cf3b20d919657d2824b7d8561ef5eeaf254377626f27980ae','3c09f358909db5ab07d09a9ee78a16d3de83f58d9f181f750985e7f3a88653f3').replace('6fc6db8164c3f0a66fc5d968fd42f72fe5daf11ca8e89dea00b430530989a797','8043d93d27b948371aee38027df898a9024e47a1ffa112b47a1913f8329e40ad');s=transform(s);ast.parse(s);q=tmp/('mech-'+label+'-parser-frame-payloads-20261115.py');assert not q.exists();q.write_text(s);rows.append(dict(original=str(p),original_sha256=sha(p),derived=str(q),derived_sha256=sha(q)))
def replay(s):
    s=s.replace('src/syntax/src/document/parser/tree_cache.rs','src/syntax/src/document/parser/canonical/base/continuation.rs').replace('passed=526','passed=528').replace('526 passed','528 passed').replace("['cases']==1780","['cases']==1976").replace("['streaming_cases']==112","['streaming_cases']==308")
    a=s.index("failed=packet/'parser-tests-initial-link-failure'");b=s.index('flags = read(',a)
    s=s[:a]+s[b:]
    s=s.replace('derivation-current.json','derivation.json').replace("item['original_name']","Path(item['original']).name").replace("item['original_path']","item['original']").replace("item['derived_name']","item['derived']")
    a=s.index("scope='Borrowed sequential event iterator");b=s.index("')\n",a)+2
    s=s[:a]+"scope='Smaller parser continuation frames: original phase operations reconstructed exactly after reversing typed checkpoint storage and owned Unicode payload reuse. Original grammar, logical work/fuel, resource first refusal and identities unchanged. Standard3c09 versus frozen candidate, same61flags/2workers; all full outputs/metadata/executable gates. Current8043 1ms stack diagnostics select the candidate and are excluded from primary timing; no candidate PGO gain inferred. All setup issues retained; no subten claim.')"+s[b:]
    a=s.index('encoded = json.dumps(result')
    extra="""selection=packet/'selection'
configuration=read(selection/'configuration.json')
assert configuration['compiler']['sha256']=='8043d93d27b948371aee38027df898a9024e47a1ffa112b47a1913f8329e40ad'
assert configuration['source_commit']=='ef5e255e817eb5bbc6df61b094a3741b31c49da2' and configuration['head']==state['base_commit']
assert configuration['flags']==dict(flags,MECH_COMPACT_COMPILE_THREADS='2')
profile_results=read(selection/'results.json')
assert len(profile_results)==2
for item in profile_results:
    assert item['all_outputs_match'] and item['excluded_from_primary'] and item['process']['exit_code']==0 and item['process']['sampling_error'] is None
    assert item['whole_executable_sha256']==exe['sha256']
    for name,expected in reference.items():assert pin(selection/item['name']/name)==expected
    assert pin(selection/(item['name']+'-link')/'worker')==exe
helper=read(selection/'helper-derivation.json')
assert pin(selection/'profile_compile.py')['sha256']==helper['derived_sha256'] and pin(selection/'profile_compile-original.py')['sha256']==helper['original_sha256']
old_helper=(selection/'profile_compile-original.py').read_text()
assert old_helper.replace('"20",\\n                            "5",','"20",\\n                            "1",')==(selection/'profile_compile.py').read_text()
for script in ['analyze.py','focused-analysis.py']:
    command=[sys.executable,str(selection/script)]
    if script=='analyze.py':command.append(str(selection))
    subprocess.run(command,check=True,stdout=subprocess.PIPE)
focused=read(selection/'focused-analysis.json')
assert [item['coordinator_wait_leaf_samples'] for item in focused]==[107,84]
assert read(selection/'base-symbol.json')['binary_sha256']==configuration['compiler']['sha256']
assert read(selection/'setup-first-attempt.json')['generator_exit_code']==1
assert read(selection/'setup-first-attempt.json')['dependent_launch_exit_code']==2
assert read(packet/'audit-first-attempt.json')['exit_code']==1
if decision['decision']=='retain':
    assert commit['source_commit'] and all(row['mean_reduction_fraction']>0 for row in blocks)
    assert (packet/'entire-source-commit.patch').read_bytes()==(packet/'candidate.patch').read_bytes()
result.update(selection_profiles=profile_results,selection_focused_analysis=focused,selection_symbol_bridge=read(selection/'demangle-symbols.json'))

"""
    return s[:a]+extra+s[a:]
derive('replay',replay)
def curate(s):
    s=s.replace("Path('/private/tmp/mech-parallel-native-pgo-20261115')","Path('/private/tmp/mech-dimension-native-pgo-20261115')").replace('ssa-descending-chain-apple-m3','dimension-native-pgo-apple-m3').replace('parallel-phase-cleanup-apple-m3','dimension-declaration-scan-apple-m3').replace('derivation-current.json','derivation.json').replace("row['original_path']","row['original']")
    return s
derive('curate',curate)
p=tmp/'mech-pack-packed-ssa-slots-20261115.py';s=p.read_text().replace('packed-ssa-slots','parser-frame-payloads').replace('0ab8308a795a11c919d0aac36e42920b4001ed2b','25615f1d575fd5cb7c91d4dcd3d8d01edf9e3ef3').replace("len(previous)==49 and index['total_archive_bytes']==1592290023","len(previous)==50 and index['total_archive_bytes']==1634023219");ast.parse(s);q=tmp/'mech-pack-parser-frame-payloads-20261115.py';assert not q.exists();q.write_text(s);rows.append(dict(original=str(p),original_sha256=sha(p),derived=str(q),derived_sha256=sha(q)))
(root/'evidence-derivation.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Prepared current parser trial replay/curation/publication helpers.')
