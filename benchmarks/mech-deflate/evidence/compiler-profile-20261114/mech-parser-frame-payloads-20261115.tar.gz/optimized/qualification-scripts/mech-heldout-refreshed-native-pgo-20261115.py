from pathlib import Path
import hashlib, json, os, re, statistics, subprocess, time

root = Path('/private/tmp/mech-parser-frame-native-pgo-20261115/qualification')
repo = Path.cwd()
out = root / 'heldout'
assert not out.exists()
out.mkdir()
flags = json.loads((root / 'runtime-flags.json').read_text())
assert len(flags) == 61
env = {k:v for k,v in os.environ.items() if not k.startswith('MECH_')}
env.update(flags);env['MECH_COMPACT_COMPILE_THREADS']='2'
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
binaries = {v:pin(root/v) for v in ['control','candidate']}
cases = ['numeric-nested-phase-states','numeric-changing-capture-tree','numeric-multiple-children','scalar-u64-divide','scalar-i64-add','scalar-i64-multiply','scalar-f64-divide']
order = [('control',1),('candidate',1),('candidate',2),('control',2),('candidate',3),('control',3),('control',4),('candidate',4)]
rows = []
for name in cases:
    source = root / 'fixture-inputs' / (name + '.mec')
    if not source.exists(): source = repo / 'hosts/gpu/tests/fixtures/native' / (name + '.mec')
    expected = {n:pin(root/'fixtures'/name/'control'/n) for n in ['source.mec','program.mecb','program.o','metadata.json']}
    source_pin = pin(source)
    observations = []
    for variant, number in order:
        directory = out / name / (variant + '-' + str(number))
        directory.mkdir(parents=True)
        command = ['/usr/bin/time','-lp',str(root/variant),str(source),str(directory),'compact']
        (directory/'command.json').write_text(json.dumps(dict(command=command,flags=dict(flags,MECH_COMPACT_COMPILE_THREADS='2'),binary=binaries[variant],source=source_pin),indent=2)+'\n')
        with (directory/'stdout.jsonl').open('w') as stdout,(directory/'stderr.log').open('w') as stderr:
            started = time.monotonic()
            completed = subprocess.run(command,cwd=repo,env=env,stdout=stdout,stderr=stderr)
            finished = time.monotonic()
        files = {n:pin(directory/n) for n in expected}
        receipt = json.loads((directory/'compile.json').read_text())
        log = (directory/'stderr.log').read_text()
        row = dict(variant=variant,run=number,exit_code=completed.returncode,whole_process_seconds=finished-started,compiler_seconds=receipt['total_seconds'],files=files,output_matches=files==expected)
        for key, pattern in [('instructions',r'(\d+)  instructions retired'),('max_rss_bytes',r'(\d+)  maximum resident set size')]: row[key]=int(re.search(pattern,log).group(1))
        (directory/'process.json').write_text(json.dumps(row,indent=2)+'\n')
        observations.append(row)
        assert completed.returncode == 0 and row['output_matches']
    numerical = {}
    for key in ['whole_process_seconds','compiler_seconds','instructions','max_rss_bytes']:
        values = {v:[r[key] for r in observations if r['variant']==v] for v in ['control','candidate']}
        values['mean_reduction_fraction'] = 1-statistics.mean(values['candidate'])/statistics.mean(values['control'])
        numerical[key] = values
    blocks = []
    for subset in [observations[:4],observations[4:]]:
        means={v:statistics.mean(r['whole_process_seconds'] for r in subset if r['variant']==v) for v in ['control','candidate']}
        means['mean_reduction_fraction']=1-means['candidate']/means['control']
        blocks.append(means)
    rows.append(dict(name=name,source=source_pin,observations=observations,numerical_summary=numerical,balanced_blocks=blocks))
    (root/'heldout-results.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(name,json.dumps({k:{v:statistics.mean(x[v]) for v in ['control','candidate']} for k,x in numerical.items()}),flush=True)
