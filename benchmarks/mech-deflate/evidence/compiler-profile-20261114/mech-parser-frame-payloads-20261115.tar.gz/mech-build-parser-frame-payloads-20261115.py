from pathlib import Path
import hashlib, json, os, shutil, subprocess, time

repo = Path.cwd()
root = Path('/private/tmp/mech-parser-frame-payloads-20261115')
state = json.loads((root/'source-state.json').read_text())
paths = [r['path'] for r in state['files']]
patch = (root/'candidate.patch').read_bytes()
assert subprocess.check_output(['git','diff','--binary','--',*paths]) == patch
assert sorted(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()) == sorted(paths)
for relative in paths:
    assert (repo/relative).read_bytes() == (root/'candidate-source'/relative).read_bytes()
env = dict(os.environ,CARGO_TARGET_DIR='/private/tmp/mech-level12-compile-target',CARGO_INCREMENTAL='0')
for name in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS']:
    assert not env.get(name), 'unexpected compiler flags'
version = subprocess.check_output(['rustc','+nightly-2026-03-03','-Vv'],text=True)
(root/'rustc-version.txt').write_text(version)
for stage in ['check','build']:
    assert subprocess.check_output(['git','diff','--binary','--',*paths]) == patch
    command=['cargo','+nightly-2026-03-03',stage,'--locked','--offline','--profile','compiler','-j4','--manifest-path','benchmarks/mech-deflate/native-profile/Cargo.toml','--bin','compile_profile','--message-format=json']
    started=time.monotonic()
    with (root/('candidate-'+stage+'.jsonl')).open('w') as stdout,(root/('candidate-'+stage+'.stderr')).open('w') as stderr:
        completed=subprocess.run(command,cwd=repo,env=env,stdout=stdout,stderr=stderr)
    row=dict(command=command,base_commit=state['base_commit'],patch_sha256=hashlib.sha256(patch).hexdigest(),exit_code=completed.returncode,seconds=time.monotonic()-started,CARGO_TARGET_DIR=env['CARGO_TARGET_DIR'],CARGO_INCREMENTAL='0')
    if completed.returncode==0 and stage=='build':
        rows=[json.loads(x) for x in (root/'candidate-build.jsonl').read_text().splitlines()]
        binaries=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='compile_profile' and r.get('executable')]
        assert len(binaries)==1
        shutil.copy2(binaries[0],root/'candidate')
        row.update(binary=str(root/'candidate'),binary_sha256=hashlib.sha256((root/'candidate').read_bytes()).hexdigest())
    (root/('candidate-'+stage+'.json')).write_text(json.dumps(row,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    assert completed.returncode==0
assert subprocess.check_output(['git','diff','--binary','--',*paths]) == patch
