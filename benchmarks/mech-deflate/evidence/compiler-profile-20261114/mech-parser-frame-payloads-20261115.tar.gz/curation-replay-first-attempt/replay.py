from pathlib import Path
import ast,hashlib,json,re,statistics,subprocess,sys
packet=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
pin=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
state=read(packet/'source-state.json')
assert pin(packet/'candidate.patch')['sha256']==state['patch_sha256']
for row in state['files']:
    assert pin(packet/'reference-source'/row['path'])==row['reference']
    assert pin(packet/'candidate-source'/row['path'])==row['candidate']
assert [row['path'] for row in state['files']]==['src/syntax/src/document/parser/canonical/base/continuation.rs']
left={p.relative_to(packet/'reference-source'):p for p in (packet/'reference-source').rglob('*') if p.is_file()}
right={p.relative_to(packet/'candidate-source'):p for p in (packet/'candidate-source').rglob('*') if p.is_file()}
assert left.keys()==right.keys()
assert [str(p) for p in left if left[p].read_bytes()!=right[p].read_bytes()]==[state['files'][0]['path']]
commit_path=packet/'qualification-commit.json'
commit=read(commit_path) if commit_path.exists() else dict(source_commit=None)
if commit_path.exists():
    assert commit['parent']==state['base_commit']
    assert commit['entire_commit_diff_sha256']==state['patch_sha256']
    assert commit['entire_commit_diff_matches_measured_patch']
excluded=read(packet/'excluded-products.json')
assert excluded['control']['sha256']=='3c09f358909db5ab07d09a9ee78a16d3de83f58d9f181f750985e7f3a88653f3'
assert read(packet/'candidate-build.json')['binary_sha256']==excluded['candidate']['sha256']
for name in ['candidate-check','candidate-build','candidate-cli-check']:
    item=read(packet/(name+'.json'))
    assert item['exit_code']==0 and item['patch_sha256']==state['patch_sha256']
tests=packet/'parser-tests'
for name in ['unit-build','unit-tests','reference-build','reference-run','candidate-build','candidate-run']:
    item=read(tests/(name+'.json'));assert item['exit_code']==0 and item['patch_sha256']==state['patch_sha256']
unit=read(tests/'unit-result.json')
assert unit==dict(passed=528,failed=0,actual_complete_document_module=True)
assert 'test result: ok. 528 passed; 0 failed' in (tests/'unit-tests.stdout').read_text()
differential=read(tests/'differential-result.json')
a=(tests/'reference-run.stdout').read_bytes();b=(tests/'candidate-run.stdout').read_bytes()
cases=[json.loads(line) for line in (tests/'cases.jsonl').read_text().splitlines()]
assert a==b and len(a)==differential['bytes'] and differential['byte_identical']
assert hashlib.sha256(a).hexdigest()==differential['reference_sha256']==differential['candidate_sha256']
assert len(cases)==len(a.splitlines())==differential['cases']==1976
assert differential['original_cases']==1667
assert sum('chunks' in case for case in cases)==differential['streaming_cases']==308
bench=next(case for case in cases if case['id']=='current-level12-entire-source')
assert hashlib.sha256(bench['text'].encode()).hexdigest()=='55cb2e698afb73da536164504b991dd514be855c9f4da9c3aadd046a55e1dba4'
observations=[json.loads(line) for line in a.splitlines()]
for case,observed in zip(cases,observations):
    assert case['id']==observed['id']
    assert {'tree','diagnostics','stats','restarts'}==set(observed['snapshot'])
    if 'chunks' in case:assert {'trace','finish_polls','work'}<=set(observed)
for variant in ['reference','candidate']:
    path=packet/(variant+'-source')/'src/syntax/src/document/mod.rs'
    source=(tests/(variant+'.rs')).read_text()
    original_path=str(Path('/private/tmp/mech-parser-frame-payloads-20261115')/(variant+'-source')/'src/syntax/src/document/mod.rs')
    assert source.count(json.dumps(original_path))==1
    normalized=source.replace(json.dumps(original_path),'"DOCUMENT_MODULE"')
    if variant=='reference':reference_probe=normalized
    else:assert normalized==reference_probe
flags = read(packet / 'runtime-flags.json')
assert len(flags) == 61
reference = {name:pin(packet / 'reference' / name) for name in ['source.mec','program.mecb','program.o','metadata.json']}
native = read(packet / 'native-baseline-pins.json')
exe = native['executable']
assert exe == dict(bytes=2060440,sha256='d6c65cc3fb18acc4be77dce329962105bf0f2b56dd2623a12f466256463eca61')
capture = read(packet / 'link-command.json')
inputs = read(packet / 'native-link-inputs.json')
assert [(r['source'],r['bytes'],r['sha256']) for r in inputs] == [(r['source'],r['bytes'],r['sha256']) for r in capture['inputs']]
for row in inputs:
    assert pin(packet / row['path']) == {k:row[k] for k in ['bytes','sha256']}
for variant in ['control','candidate']:
    directory = packet / (variant + '-screen')
    assert read(directory / 'process.json')['exit_code'] == 0
    for name, item in reference.items():
        assert pin(directory / name) == item and (directory / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    assert pin(packet / ('link-' + variant) / 'worker') == exe
gates = read(packet / 'final-executable-results.json')
assert len(gates) == 2 and all(r['exit_code'] == 0 and r['matches_complete_baseline_executable'] and r['executable_sha256'] == exe['sha256'] for r in gates)
fixtures = read(packet / 'fixture-results.json')
assert len(fixtures) == 14
for row in fixtures:
    assert row['all_outputs_match'] and row['variants']['control'] == row['variants']['candidate']
    for variant in ['control','candidate']:
        entry = row['variants'][variant]
        assert entry['exit_code'] == 0 and len(entry['files']) == 4
        name = Path(row['fixture'].split(':')[-1]).stem
        directory = packet / 'fixtures' / name / variant
        for filename, item in entry['files'].items():
            assert pin(directory / filename) == item
            assert (directory / filename).read_bytes() == (packet / 'fixtures' / name / 'control' / filename).read_bytes()
jobs=read(packet/'jobs-diagnostic.json')
assert jobs['excluded_from_primary'] and jobs['all_outputs_and_complete_executable_identical']
observed=[]
for line in (packet/'candidate-jobs-diagnostic/stderr.log').read_text().splitlines():
    match=re.fullmatch(r'compact-compile-jobs: workers=(\d+) submitted=(\d+) cleanup=(\d+)',line)
    if match:observed.append(dict(workers=int(match[1]),submitted=int(match[2]),cleanup=int(match[3])))
assert jobs['rows']==observed and observed==[dict(workers=2,submitted=344,cleanup=48)]
for name,item in reference.items():assert pin(packet/'candidate-jobs-diagnostic'/name)==item
assert pin(packet/'link-candidate-jobs/worker')==exe
assert read(packet/'jobs-executable-results.json')[0]['matches_complete_baseline_executable']
assert read(packet/'candidate-jobs-diagnostic-command.json')['flags']==dict(flags,MECH_COMPACT_COMPILE_THREADS='2',MECH_PROFILE_COMPILE_JOBS='1')

rows = read(packet / 'cohort.json')
assert len(rows) == 8
order = ['control-1','candidate-1','candidate-2','control-2','candidate-3','control-3','control-4','candidate-4']
assert [r['name'] for r in rows] == order
for row in rows:
    directory = packet / row['name']
    assert row['compile'] == read(directory / 'compile.json') and row['process'] == read(directory / 'process.json')
    assert row['process']['exit_code'] == 0
    command = read(packet / (row['name'] + '-command.json'))
    assert command['binary_sha256'] == excluded[row['variant']]['sha256']
    assert command['flags'] == dict(flags, MECH_COMPACT_COMPILE_THREADS='2')
    for name, item in reference.items():
        assert pin(directory / name) == item and (directory / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    stamps = [json.loads(line) for line in (directory / 'stages.jsonl').read_text().splitlines()]
    for key, begin, end in [('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code'),('compaction_seconds','compact-stage: compact values before=','compact-stage: CFG cleanup')]:
        assert row[key] == next(s['elapsed'] for s in stamps if s['line'].startswith(end)) - next(s['elapsed'] for s in stamps if s['line'].startswith(begin))
    assert row['cleanup_including_compaction_seconds'] == row['cleanup_seconds'] + row['compaction_seconds']
    log = (directory / 'stderr.log').read_text()
    for key, pattern in [('max_rss_bytes',r'(\d+)  maximum resident set size'),('instructions',r'(\d+)  instructions retired'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]:
        assert row[key] == int(re.search(pattern,log).group(1))
fields = dict(compiler_seconds=lambda r:r['compile']['total_seconds'],whole_process_seconds=lambda r:r['process']['elapsed_seconds'])
for phase in ['parse','catalog','frontend','artifact','encode','native']:
    fields[phase+'_seconds'] = lambda r,p=phase: next(v['seconds'] for v in r['compile']['phases'] if v['phase']==p)
for key in ['canonical_lowering_seconds','preparation_seconds','numeric_generation_seconds','source_cfg_seconds','cleanup_including_compaction_seconds','cleanup_seconds','compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:
    fields[key] = lambda r,k=key:r[k]
summary = {}
for key, fn in fields.items():
    values = {v:[fn(r) for r in rows if r['variant']==v] for v in ['control','candidate']}
    base = statistics.mean(values['control'])
    values['mean_reduction_fraction'] = 1-statistics.mean(values['candidate'])/base if base else None
    summary[key] = values
assert read(packet / 'numerical-summary.json') == summary
native_path = packet / 'native-cohort.json'
native_rows = read(native_path) if native_path.exists() else []
assert len(native_rows) in [0,8]
native_summary = {}
for row in native_rows:
    directory = packet / row['name']
    receipt = read(directory / 'result.json')
    assert row == dict(receipt, name=row['name'], primary_cohort=True)
    assert row['compiler_exit_code'] == row['link_exit_code'] == 0 and row['matches_complete_baseline_executable']
    assert row['executable_bytes'] == exe['bytes'] and row['executable_sha256'] == exe['sha256'] and pin(directory / 'worker') == exe
    for name, item in reference.items():
        assert pin(directory / name) == item and (directory / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    assert abs(row['source_to_executable_seconds']-sum(row[k] for k in ['source_to_object_process_seconds','object_handoff_seconds','native_link_seconds'])) < 1e-8
if native_rows:
    for key in ['source_to_executable_seconds','source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']:
        values = {v:[r[key] for r in native_rows if r['variant']==v] for v in ['control','candidate']}
        values['mean_reduction_fraction'] = 1-statistics.mean(values['candidate'])/statistics.mean(values['control'])
        native_summary[key] = values
    blocks = []
    for block in [native_rows[:4],native_rows[4:]]:
        means = {v:statistics.mean(r['source_to_executable_seconds'] for r in block if r['variant']==v) for v in ['control','candidate']}
        means['mean_reduction_fraction'] = 1-means['candidate']/means['control']
        blocks.append(means)
    saved = read(packet / 'native-numerical-summary.json')
    assert saved['numerical_summary'] == native_summary and saved['balanced_blocks'] == blocks
else:
    blocks = []
if (packet / 'candidate-serial-gate').exists():
    serial = packet / 'candidate-serial-gate'
    assert read(serial / 'process.json')['exit_code'] == 0
    for name, item in reference.items():
        assert pin(serial / name) == item and (serial / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    serial_result = read(packet / 'link-candidate-serial/result.json')
    assert serial_result['matches_complete_baseline_executable'] and serial_result['executable_sha256'] == exe['sha256']
    assert pin(packet / 'link-candidate-serial/worker') == exe

algorithm=json.loads(subprocess.check_output([sys.executable,str(packet/'audit.py')]))
assert algorithm==read(packet/'algorithm-audit.json')
plan=read(packet/'qualification-plan.json')
driver=packet/'qualify.py'
assert pin(driver)['sha256']==plan['driver_sha256']
stages=next(ast.literal_eval(node.value) for node in ast.parse(driver.read_text()).body if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='stages' for t in node.targets))
assert [list(row) for row in stages]==plan['stages']
assert [row[0] for row in stages]==['screens','executable-gates','default-serial-byte-gate','jobs-diagnostic','fixtures-object-cohort','native-cohort']
pipeline=read(packet/'qualification-pipeline.json')
assert [row['stage'] for row in pipeline]==[row[0] for row in stages]
assert all(row['state']=='complete' and row['exit_code']==0 for row in pipeline)
for item in read(packet/'qualification-scripts/derivation.json'):
    assert pin(packet/'qualification-scripts/originals'/Path(item['original']).name)['sha256']==item['original_sha256']
    assert pin(packet/'qualification-scripts'/item['derived'])['sha256']==item['derived_sha256']
object_blocks=[]
for block in [rows[:4],rows[4:]]:
    values={}
    for key in ['compiler_seconds','whole_process_seconds','parse_seconds','source_cfg_seconds','instructions']:
        means={variant:statistics.mean(fields[key](row) for row in block if row['variant']==variant) for variant in ['control','candidate']}
        means['mean_reduction_fraction']=1-means['candidate']/means['control'];values[key]=means
    object_blocks.append(values)
decision=read(packet/'decision.json')
assert decision['control_complete_seconds']==statistics.mean(native_summary['source_to_executable_seconds']['control'])
assert decision['candidate_complete_seconds']==statistics.mean(native_summary['source_to_executable_seconds']['candidate'])
assert decision['native_reduction']==native_summary['source_to_executable_seconds']['mean_reduction_fraction'] and decision['native_blocks']==blocks
assert decision['object_adverse_fields']=={key:value for key,value in summary.items() if value['mean_reduction_fraction']<0}
assert decision['native_adverse_fields']=={key:value for key,value in native_summary.items() if value['mean_reduction_fraction']<0}
restoration=None
if decision['decision']=='reject':
    restoration=read(packet/'restoration.json')
    assert restoration==decision['restoration'] and restoration['source_restored']
    assert restoration['source_sha256']==state['files'][0]['reference']['sha256']
    assert restoration['canonical_sha256']==excluded['control']['sha256']
    assert restoration['selected_pgo_sha256']=='8043d93d27b948371aee38027df898a9024e47a1ffa112b47a1913f8329e40ad'
else:
    assert decision['decision']=='retain' and commit['source_commit']==decision['retained_source_commit']
result=dict(source_commit=commit['source_commit'],base_commit=state['base_commit'],patch_sha256=state['patch_sha256'],compiler=excluded,source_state=state,numerical_summary=summary,native_numerical_summary=native_summary,balanced_native_blocks=blocks,object_balanced_blocks=object_blocks,output_hashes=reference,final_executable=exe,fixture_pairs=14,document_unit_tests=unit,parser_differential=differential,checks={name:read(packet/(name+'.json')) for name in ['candidate-check','candidate-build','candidate-cli-check']},decision=decision,algorithm_audit=algorithm,jobs_diagnostic=jobs,qualification_pipeline=pipeline,restoration=restoration,scope='Smaller parser continuation frames: original phase operations reconstructed exactly after reversing typed checkpoint storage and owned Unicode payload reuse. Original grammar, logical work/fuel, resource first refusal and identities unchanged. Standard3c09 versus frozen candidate, same61flags/2workers; all full outputs/metadata/executable gates. Current8043 1ms stack diagnostics select the candidate and are excluded from primary timing; standard cohorts and direct fastest-configuration follow-up remain separate; no component gains added. All setup issues retained; no subten claim.')
selection=packet/'selection'
configuration=read(selection/'configuration.json')
assert configuration['compiler']['sha256']=='8043d93d27b948371aee38027df898a9024e47a1ffa112b47a1913f8329e40ad'
assert configuration['source_commit']=='ef5e255e817eb5bbc6df61b094a3741b31c49da2' and configuration['head']==state['base_commit']
assert configuration['flags']==dict(flags,MECH_COMPACT_COMPILE_THREADS='2')
profile_results=read(selection/'results.json')
assert len(profile_results)==2
for item in profile_results:
    assert item['all_outputs_match'] and item['excluded_from_primary'] and item['process']['exit_code']==0 and item['process']['sampling_error'] is None
    assert item['whole_executable_sha256']==exe['sha256']
    for name,expected in reference.items():assert pin(selection/item['name']/name)==expected
    assert pin(selection/(item['name']+'-link')/'worker')==exe
helper=read(selection/'helper-derivation.json')
assert pin(selection/'profile_compile.py')['sha256']==helper['derived_sha256'] and pin(selection/'profile_compile-original.py')['sha256']==helper['original_sha256']
old_helper=(selection/'profile_compile-original.py').read_text()
assert old_helper.replace('"20",\n                            "5",','"20",\n                            "1",')==(selection/'profile_compile.py').read_text()
for script in ['analyze.py','focused-analysis.py','allocation-analysis.py']:
    command=[sys.executable,str(selection/script)]
    if script=='analyze.py':command.append(str(selection))
    subprocess.run(command,check=True,stdout=subprocess.PIPE)
focused=read(selection/'focused-analysis.json')
assert [item['coordinator_wait_leaf_samples'] for item in focused]==[107,84]
assert read(selection/'base-symbol.json')['binary_sha256']==configuration['compiler']['sha256']
assert read(selection/'setup-first-attempt.json')['generator_exit_code']==1
assert read(selection/'setup-first-attempt.json')['dependent_launch_exit_code']==2
assert read(packet/'audit-first-attempt.json')['exit_code']==1
optimized=json.loads(subprocess.check_output([sys.executable,str(packet/'optimized/replay.py')]))
assert optimized['base_commit']==state['base_commit'] and optimized['source_patch_sha256']==state['patch_sha256']
assert optimized['decision']['decision']==decision['decision']
result['optimized_followup']=optimized
if decision['decision']=='retain':
    assert commit['source_commit'] and all(row['mean_reduction_fraction']>0 for row in optimized['native_cohort']['balanced_blocks'])
    assert (packet/'entire-source-commit.patch').read_bytes()==(packet/'candidate.patch').read_bytes()
result.update(selection_profiles=profile_results,selection_focused_analysis=focused,selection_allocation_analysis=read(selection/'allocation-analysis.json'),selection_symbol_bridge=read(selection/'demangle-symbols.json'))

encoded=json.dumps(result,indent=2,sort_keys=True)+'\n'
saved=packet/'summary.json'
if saved.exists():assert saved.read_text()==encoded
else:saved.write_text(encoded)
print(encoded,end='')
