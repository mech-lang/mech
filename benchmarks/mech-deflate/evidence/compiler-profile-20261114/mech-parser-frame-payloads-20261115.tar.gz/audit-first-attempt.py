from pathlib import Path
import hashlib,json,re

def tokens(text):
    parts=re.findall(r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|[A-Za-z_]\w*|\d+|[^\s]',text)
    return ' '.join(part for part in parts if not part.startswith(('//','/*')))

def audit(root):
    old=(root/'reference.rs').read_text().split('#[cfg(test)]\nmod tests {')[0]
    new=(root/'candidate.rs').read_text().split('#[cfg(test)]\nmod tests {')[0]
    value=tokens(new)
    def replace(before,after,count=1):
        nonlocal value
        before,after=tokens(before),tokens(after)
        assert value.count(before)==count,(before,value.count(before),count)
        value=value.replace(before,after)
    replace('checkpoints:Vec<ParserCheckpoint>,','')
    replace('unicode_spare:Option<Box<UnicodeEscape>>,','')
    replace('debug_assert!(self.storage.checkpoints.is_empty());','',2)
    replace('Exit,','Exit(ParserCheckpoint),')
    replace('Unless(RuleId),','Unless(ParserCheckpoint,RuleId),')
    replace('Box<UnicodeEscape>','UnicodeEscape',5)
    replace('self.storage.checkpoints.push(parser.checkpoint());','')
    replace('self.push(Frame::Unless(rule));','self.push(Frame::Unless(parser.checkpoint(),rule));')
    replace('self.storage.checkpoints.push(checkpoint);','')
    replace('self.push(Frame::Exit);','self.push(Frame::Exit(checkpoint));')
    replace('Frame::Exit => {let checkpoint=self.storage.checkpoints.pop().expect("base rule checkpoint");','Frame::Exit(checkpoint)=>{')
    replace('Frame::Unless(rule)=>{let checkpoint=self.storage.checkpoints.pop().expect("base unless checkpoint");','Frame::Unless(checkpoint,rule)=>{')
    replace('self.storage.unicode_spare=Some(state);','',5)
    constructor='UnicodeEscape {checkpoint:parser.checkpoint(),start:parser.offset(),scalar:Some(0),digits:0,}'
    before='let state='+constructor+'; let state=if let Some(mut spare)=self.storage.unicode_spare.take(){*spare=state;spare}else{Box::new(state)};self.push(Frame::UnicodePrefix(state,0));'
    after='self.push(Frame::UnicodePrefix('+constructor+',0));'
    # The original multiline call has a trailing comma after its last argument.
    after='self.push(Frame::UnicodePrefix('+constructor+',0,));'
    replace(before,after)
    assert value==tokens(old)
    return dict(original_logical_production_tokens_reconstructed=True,logical_tokens_sha256=hashlib.sha256(value.encode()).hexdigest(),same_rule_phase_sequence_prediction_and_resource_work=True,checkpoint_lifo_pairs_same_capture_and_restore=True,unicode_payload_every_field_fresh_each_use=True,no_grammar_or_permission_changes=True,scope='Reverse only the explicit physical payload representations, paired checkpoint storage, debug assertions and owned spare-box lifecycle. Original production token stream then matches exactly; behavior additionally checked by full units/differential snapshots.')

if __name__=='__main__':
    root=Path(__file__).resolve().parent;result=audit(root);encoded=json.dumps(result,indent=2,sort_keys=True)+'\n';p=root/'algorithm-audit.json'
    if p.exists():assert p.read_text()==encoded
    else:p.write_text(encoded)
    print(encoded,end='')
