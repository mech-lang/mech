from pathlib import Path
import ast,datetime,hashlib,json,subprocess,sys,time

root=Path('/private/tmp/mech-parser-frame-payloads-20261115')
state=json.loads((root/'source-state.json').read_text())
assert subprocess.check_output(['git','diff','--binary'])==(root/'candidate.patch').read_bytes()
rows=[]
stages=[('parser-tests','test'),('compiler-build','build'),('native-cli','check')]
scripts=[]
for stage,label in stages:
    script=Path('/private/tmp/mech-'+label+'-parser-frame-payloads-20261115.py')
    ast.parse(script.read_text());scripts.append(dict(stage=stage,path=str(script),sha256=hashlib.sha256(script.read_bytes()).hexdigest()))
(root/'test-build-plan.json').write_text(json.dumps(dict(stages=scripts,source_patch_sha256=state['patch_sha256'],scope='Serial exact document units/differentials first, then genuine compiler check/build, then native CLI check. No measurements until all stages finish.'),indent=2)+'\n')
for stage,label in stages:
    command=[sys.executable,'/private/tmp/mech-'+label+'-parser-frame-payloads-20261115.py']
    row=dict(stage=stage,state='running',command=command,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());rows.append(row);(root/'test-build-pipeline.json').write_text(json.dumps(rows,indent=2)+'\n');started=time.monotonic()
    with (root/(stage+'.stdout.log')).open('w') as out,(root/(stage+'.stderr.log')).open('w') as err:result=subprocess.run(command,stdout=out,stderr=err)
    row.update(state='complete' if result.returncode==0 else 'failed',exit_code=result.returncode,seconds=time.monotonic()-started);(root/'test-build-pipeline.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True);assert result.returncode==0
