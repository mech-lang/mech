from pathlib import Path
import json,re,subprocess,sys
r=Path('/private/tmp/mech-packed-ssa-slots-20261115');scripts=r/'qualification-scripts'
commands=[[sys.executable,str(scripts/'mech-run-packed-ssa-slots-jobs-20261115.py'),'candidate','candidate-jobs-diagnostic'],[sys.executable,str(scripts/'mech-cached-native-link-packed-ssa-slots-jobs-20261115.py')]]
for command in commands:subprocess.run(command,check=True)
rows=[]
for line in (r/'candidate-jobs-diagnostic/stderr.log').read_text().splitlines():
 m=re.fullmatch(r'compact-compile-jobs: workers=(\d+) submitted=(\d+) cleanup=(\d+)',line)
 if m:rows.append(dict(workers=int(m[1]),submitted=int(m[2]),cleanup=int(m[3])))
assert rows and all(row['workers']==2 and row['submitted']>=row['cleanup'] for row in rows)
assert sum(row['cleanup'] for row in rows)>0,'No eligible cleanup jobs reached the measured compressor'
assert all(row['matches_complete_baseline_executable'] for row in json.loads((r/'jobs-executable-results.json').read_text()))
result=dict(rows=rows,excluded_from_primary=True,all_outputs_and_complete_executable_identical=True)
(r/'jobs-diagnostic.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
