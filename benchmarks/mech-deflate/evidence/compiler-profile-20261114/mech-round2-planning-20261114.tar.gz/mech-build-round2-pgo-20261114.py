from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
root=Path('/private/tmp/mech-round2-pgo-20261114');source=root/'source';mode=sys.argv[1];assert mode in ['control','generate','use']
state=json.loads((root/'source-state.json').read_text());flags=['-D','warnings'];target='aarch64-apple-darwin'
if mode=='generate':
    profile=root/'raw';profile.mkdir(exist_ok=True);assert not list(profile.iterdir());flags+=['-C','profile-generate='+str(profile)]
if mode=='use':
    profile=root/'merged.profdata';assert profile.is_file();flags+=['-C','profile-use='+str(profile),'-C','llvm-args=-pgo-warn-missing-function']
env=dict(os.environ,CARGO_TARGET_DIR=str(root/'target'),CARGO_INCREMENTAL='0',CARGO_ENCODED_RUSTFLAGS='\x1f'.join(flags));env.pop('RUSTFLAGS',None)
cmd=['cargo','+nightly-2026-03-03','build','--locked','--offline','--profile','compiler','--target',target,'-j4','--manifest-path','benchmarks/mech-deflate/native-profile/Cargo.toml','--bin','compile_profile','--message-format=json']
start=time.perf_counter()
with (root/(mode+'-build.jsonl')).open('wb') as out,(root/(mode+'-build.stderr')).open('wb') as err:
    result=subprocess.run(cmd,env=env,cwd=source,stdout=out,stderr=err)
record=dict(command=cmd,source_commit=state['source_commit'],mode=mode,rustflags=flags,target=target,cargo_jobs=4,CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(root/'target'),seconds=time.perf_counter()-start,exit_code=result.returncode)
if result.returncode==0:
    rows=[json.loads(x) for x in (root/(mode+'-build.jsonl')).read_text().splitlines()]
    binary=next(r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='compile_profile' and r.get('executable'))
    dest=root/mode;shutil.copy2(binary,dest);dest.chmod(0o755);record.update(binary=str(dest),binary_sha256=hashlib.sha256(dest.read_bytes()).hexdigest())
(root/(mode+'-build.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);raise SystemExit(result.returncode)
