from pathlib import Path
import hashlib,json,shutil,subprocess,sys,time
root=Path('/private/tmp/mech-round2-baseline-20261114/link');obj=Path(sys.argv[1]);label=sys.argv[2]
pins=json.loads((root/'input-pins.json').read_text())
for info in pins['dependency_archives_and_macros']:
    p=Path(info['path']);assert p.stat().st_size==info['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==info['sha256']
for name,info in pins['sources'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==info['sha256']
reference=json.loads(Path('/private/tmp/mech-round2-baseline-20261114/reference-pins.json').read_text())['program.o'];data=obj.read_bytes();assert len(data)==reference['bytes'] and hashlib.sha256(data).hexdigest()==reference['sha256']
shutil.copy2(obj,root/'program.o')
cmd=['rustc','+nightly-2026-03-03','--edition=2024','--crate-name','frozen_level12_worker','-C','opt-level=3','-C','lto=thin','-C','codegen-units=1','-D','warnings','-L','dependency='+str(root/'deps'),str(root/'worker.rs'),'-o',str(root/'worker')]
for name,info in pins['direct_libraries'].items():cmd+=['--extern',name+'='+info['path']]
cmd+=['-C','link-arg='+str(root/'libmimalloc.a'),'-C','link-arg='+str(root/'program.o')]
start=time.perf_counter()
with (root/(label+'-build.stdout')).open('wb') as out,(root/(label+'-build.stderr')).open('wb') as err:result=subprocess.run(cmd,stdout=out,stderr=err)
record=dict(command=cmd,label=label,seconds=time.perf_counter()-start,exit_code=result.returncode,object_sha256=reference['sha256'],scope='Separate frozen Rust wrapper compilation and final link; excluded from Mech source-to-Object timing.')
if result.returncode==0:
    data=(root/'worker').read_bytes();record.update(binary_bytes=len(data),binary_sha256=hashlib.sha256(data).hexdigest());shutil.copy2(root/'worker',root/('worker-'+label))
    if label!='baseline':
        baseline=json.loads((root/'baseline-build.json').read_text());record['matches_baseline_executable']=record['binary_sha256']==baseline['binary_sha256'];assert record['matches_baseline_executable'],record
(root/(label+'-build.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);raise SystemExit(result.returncode)
