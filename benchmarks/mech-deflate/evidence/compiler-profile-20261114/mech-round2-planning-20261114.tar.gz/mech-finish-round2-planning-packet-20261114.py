from pathlib import Path
packet=Path('/private/tmp/mech-round2-planning-packet-20261114')
old=Path('/private/tmp/mech-ssa-span-trials-packet-20261114/replay.py').read_text();apply=old[old.index('def apply_source_patch('):old.index('base_source=')]
prefix='''from pathlib import Path
import hashlib,json,re,statistics,struct
root=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_text())
def pin(p):
 b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
state=read(root/'source-state.json');baseline=root/'baseline';diagnostic=root/'diagnostic';prior=read(root/'validation/qualified-point-liveness.json');receipt=read(root/'validation/qualified-point-liveness.archive.json');assert pin(root/'validation/qualified-point-liveness.json')['sha256']==receipt['replay_sha256'];expected=prior['output_hashes'];excluded={r['path']:r for r in read(root/'excluded-compiler-products.json')}
assert state['source_commit']=='fad53d24d9d2cad61262cb94932405fd9ee40341' and not state['production_instrumentation_retained'] and not state['parallel_mech_compilation_implemented'] and not state['pgo_profile_generation_started']
assert state['control_source_commit']==prior['source_commit'] and excluded['baseline/control']['sha256']==prior['compiler_binary_sha256']['candidate']
'''
end='''
assert apply_source_patch((baseline/'profile_compile-before.py').read_text(),(baseline/'measurement.patch').read_text())==(baseline/'profile_compile-after.py').read_text()==(root/'source/benchmarks/mech-deflate/native-profile/profile_compile.py').read_text()
failed=read(diagnostic/'instrumented-build.json');build=read(diagnostic/'instrumented-v2-build.json');assert failed['exit_code']==101 and build['exit_code']==0 and build['head']==state['source_commit'];assert pin(diagnostic/'instrumented-v2.patch')['sha256']==build['patch_sha256']==state['diagnostic_patch_sha256'] and excluded['diagnostic/instrumented-v2']['sha256']==build['binary_sha256'];assert pin(diagnostic/'instrumented.patch')['sha256']==failed['patch_sha256']
for block in (diagnostic/'instrumented-v2.patch').read_text().split('diff --git ')[1:]:
 block='diff --git '+block;match=re.match(r'diff --git a/(.+) b/\\1\\n',block);assert match;name=match[1];assert apply_source_patch((diagnostic/'source-base'/name).read_text(),block)==(diagnostic/'source-instrumented'/name).read_text()
flags=read(baseline/'runtime-flags.json');assert len(flags)==61 and flags==read(diagnostic/'runtime-flags.json') and flags['MECH_COMPACT_REUSE_OVERWRITTEN_RESULT']=='1'
controls=[]
for folder,name,binary in [(baseline,'precise-control-1',prior['compiler_binary_sha256']['candidate']),(baseline,'precise-control-2',prior['compiler_binary_sha256']['candidate']),(diagnostic,'diagnostic-1',build['binary_sha256'])]:
 d=folder/name;process=read(d/'process.json');assert process['exit_code']==0 and process['elapsed_boundary']=='driver_start_to_process_wait_completion' and process['samples']==0;command=read(folder/(name+'-command.json'));assert command['flags']==flags and command['binary_sha256']==binary
 for n,pinned in expected.items():assert pin(d/n)==pinned and read(d/'output-check.json')[n]==dict(pinned,matches_current_control_output=True)
 compile=read(d/'compile.json');assert process['elapsed_seconds']>=compile['total_seconds']
 if folder==baseline:controls.append(dict(name=name,process_seconds=process['elapsed_seconds'],compiler_seconds=compile['total_seconds']))
checks=read(baseline/'completion-check.json');assert len(checks)==10
for r in checks:
 actual=read(baseline/f"completion-{r['variant']}-{r['repeat']}"/'process.json');assert actual==r['driver_receipt'] and actual['exit_code']==0
 if r['variant']=='after':assert actual['elapsed_boundary']=='driver_start_to_process_wait_completion'
rows=[json.loads(x) for x in (diagnostic/'diagnostic-1/stages.jsonl').read_text().splitlines()];schemas=[];ssa=[];cleanup=[];main=False
for row in rows:
 line=row['line']
 if line.startswith('compact-stage: CFG cleanup'):main=True
 if line.startswith('compact-stage: machine code'):main=False
 if line.startswith('schema-work-profile: '):
  m=re.fullmatch(r'schema-work-profile: kind=(\\S+) file=(\\S+) line=(\\d+) calls=(\\d+) dimensions=(\\d+)',line);assert m;schemas.append(dict(kind=m[1],file=m[2],line=int(m[3]),calls=int(m[4]),dimensions=int(m[5])))
 if line.startswith('ssa-work-profile: '):ssa.append({k:int(v) for k,v in re.findall(r'(\\w+): (\\d+)',line)})
 if line.startswith('cleanup-pass-profile: '):
  m=re.fullmatch(r'cleanup-pass-profile: pass=(\\S+) seconds=([0-9.]+)',line);assert m;cleanup.append(dict(pass_name=m[1],seconds=float(m[2]),main_cleanup=main,elapsed=row['elapsed']))
totals={kind:{k:sum(r[k] for r in schemas if r['kind']==kind) for k in ['calls','dimensions']} for kind in sorted({r['kind'] for r in schemas})}
ssa_sum={k:(max(r[k] for r in ssa) if k=='max_alias_chain' else sum(r[k] for r in ssa)) for k in ssa[0]};assert ssa_sum['sealed_sentinels']+ssa_sum['unsealed_sentinels']==ssa_sum['retired_sentinels']+ssa_sum['retained_sentinels']
passes={scope:{name:{'calls':sum(1 for r in cleanup if r['pass_name']==name and r['main_cleanup']==(scope=='main')),'seconds':sum(r['seconds'] for r in cleanup if r['pass_name']==name and r['main_cleanup']==(scope=='main'))} for name in sorted({r['pass_name'] for r in cleanup})} for scope in ['main','other']}
result=dict(schema_totals=totals,ssa_totals=ssa_sum,ssa_function_records=len(ssa),cleanup=passes,scope='Instrumented diagnostic only; clocks and counter work excluded from performance qualification.');assert read(diagnostic/'work-counters.json')==dict(summary=result,schema_sites=schemas,ssa_functions=ssa,cleanup_events=cleanup)
link=baseline/'link';inputs=read(link/'input-pins.json')
for info in inputs['dependency_archives_and_macros']:assert excluded['baseline/link/deps/'+Path(info['path']).name]['sha256']==info['sha256']
for name,pinned in inputs['sources'].items():assert pin(link/name)==pinned
linked=read(link/'baseline-build.json');assert linked['exit_code']==0 and pin(link/'worker-baseline')==dict(bytes=linked['binary_bytes'],sha256=linked['binary_sha256']) and pin(link/'worker')==pin(link/'worker-baseline') and linked['object_sha256']==expected['program.o']['sha256']
capture=link/'capture';native=read(capture/'link-command.json');assert native['exit_code']==0;native_inputs=read(root/'native-link-inputs.json');assert len(native_inputs)==len(native['inputs'])
for row,actual in zip(native_inputs,native['inputs']):assert row['source']==actual['source'] and pin(root/row['path'])==dict(bytes=actual['bytes'],sha256=actual['sha256'])
successes=read(capture/'relink-deterministic-results.json');assert len(successes)==3
for r in successes:assert r['exit_code']==0 and r['matches_baseline_executable'] and r['binary_sha256']==linked['binary_sha256'] and r['ZERO_AR_DATE']=='1'
rejected={}
for name in ['relink-results.json','relink-stable-basenames-results.json','relink-canonical-results.json']:
 trial=read(capture/name);assert len(trial)==1 and trial[0]['exit_code']==0 and not trial[0]['matches_baseline_executable'] and trial[0]['binary_sha256']!=linked['binary_sha256'];rejected[name]=trial
assert pin(capture/'relink-first-different-executable')['sha256']==rejected['relink-results.json'][0]['binary_sha256'];assert pin(capture/'relink-stable-basenames-different-executable')['sha256']==rejected['relink-stable-basenames-results.json'][0]['binary_sha256']
decision=read(capture/'decision.json');assert decision['canonical_object_paths_and_deterministic_link_environment_required'] and decision['ZERO_AR_DATE']=='1' and decision['executable_sha256']==linked['binary_sha256']
pgo=read(root/'pgo-setup/control-build.json');assert pgo['exit_code']==0 and pgo['source_commit']==state['source_commit'] and pgo['rustflags']==['-D','warnings'] and pgo['target']=='aarch64-apple-darwin' and pgo['binary_sha256']==excluded['pgo-setup/control']['sha256'];assert 'LLVM version 22.1.0' in (root/'pgo-setup/llvm-profdata-version.txt').read_text()
meta=read(baseline/'reference/metadata.json');phases=meta['numeric_phases'];shape=dict(numeric_phases=len(phases),vector_candidates=sum('vector_variant' in x for x in phases),private_phases=sum('private_fixed_nested' in x for x in phases),no_growth_variants=sum('no_growth_variant' in x for x in phases),composed_variants=sum('composed_variant' in x for x in phases))
summary=dict(source_commit=state['source_commit'],control_source_commit=state['control_source_commit'],flags_count=61,output_hashes=expected,precise_controls=controls,process_boundary='driver_start_to_process_wait_completion',completion_calibration=checks,diagnostic_build_seconds=build['seconds'],failed_diagnostic_build_seconds=failed['seconds'],work_counters=result,program_structure=shape,final_link=dict(adapter_build=linked,native_link_observations=successes,rejected_direct_link_trials=rejected,decision=decision),pgo_setup=pgo,parallel_mech_compilation_implemented=False,scope=[
 'Precise process completion replaces the old polling tail; no compiler optimization is credited to the clock correction. Two controls reproduce the frozen current outputs. Their startup gaps differ; they are baseline observations, not a matched improvement cohort.',
 'Separate diagnostic code records schema requests/clones, SSA work and partial cleanup component clocks. All four output files match. Instrumentation is removed. Context pass clocks include nested verification; the built-in Cranelift pass table is empty and supplies no timings. Resolver counts include the added cached-predecessor probe.',
 'Cloned dimension entries are repeated entries across materializations, not distinct declarations. SSA suffix shifts concern builder sentinel removal, not constant-phi cleanup. Only 264011 of 20078161 sealed sentinels meet the cached-predecessor opportunity; no broader shortcut is implemented.',
 'The frozen runtime/adapter and three warm native links reproduce every complete executable byte. Three earlier direct-link trials fail the byte gate; paths and N_OSO timestamps explain required link-input identity. These are link-only observations, not a matched complete source-to-executable gain or implemented parallel compiler speedup.',
 'Program executables and native linker inputs remain in this packet. Compiler executables and the 989580160-byte coherent Rust dependency bundle are excluded and hash-pinned. Pure replay validates stored bytes/counters/measurements and source patches without compiling or rerunning timings.',
 'The PGO control is built from a separate pinned source snapshot with an explicit target and warnings-as-errors. Matching LLVM profile tools are installed. No instrumented training/profile-use build or PGO performance result is claimed; bootstrap/adapter builds overlap and are not isolated comparisons.',
 'The parallel architecture keeps declarations, shared tables, variant choices and Object publication ordered, with bounded function-local workers. This design and the separate unqualified borrowing candidate do not establish the sub-ten-second objective.'
])
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
'''
(packet/'replay.py').write_text(prefix+apply+end)
print(packet/'replay.py')
