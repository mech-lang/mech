Precise timing, current work counters and parallel-build design, 2026-11-14.
Two complete fresh controls and the separate diagnostic reproduce all fixed
source/MBC/Object/metadata bytes. Diagnostic work counts and partial per-pass
clocks are excluded from performance qualification. The failed warnings-as-errors
build and successful rebuild remain. Instrumentation is removed from production.
The fixed runtime/adapter is compiled and linked once, then its captured native
objects reproduce the complete executable in three warm native links. Three
failed direct-link attempts retain their hashes, commands and logs. Stable
object paths and ZERO_AR_DATE=1 are needed for exact current Mach-O metadata.
Final program executables and native-link inputs are included for byte checks.
Compiler executables and the large coherent Rust dependency bundle are excluded
and hash-pinned. No parallel Mech compiler speedup is claimed. The architectural
proposal records variant dependencies, module ownership and ordered publication.
PGO setup includes its pinned-source control build and matching LLVM tools, but
no instrumented training/profile-use result or PGO saving. Bootstrap and adapter
build costs are separate and overlap; neither is an isolated comparison.
Pure replay checks the stored measurements, source patches, output bytes,
counters and final executable identity. It does not rerun compilers or timings.
The sub-ten-second full-compilation goal remains open.
