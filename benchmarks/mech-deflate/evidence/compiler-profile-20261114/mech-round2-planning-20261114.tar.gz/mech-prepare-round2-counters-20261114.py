from pathlib import Path
import subprocess,json,shutil
repo=Path.cwd();root=Path('/private/tmp/mech-round2-counters-20261114');assert not root.exists();root.mkdir()
base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert subprocess.check_output(['git','diff','HEAD','--binary'])==b''
def modify(name,change):
 p=repo/name;s=p.read_text();d=root/'source-base'/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_text(s);p.write_text(change(s))
def schema(s):
 s=s.replace('    pub(super) fn into_owned(self) -> SchemaDraft {','    #[track_caller]\n    pub(super) fn into_owned(self) -> SchemaDraft {\n        profile("into_owned", &self.0.draft);\n        if Arc::strong_count(&self.0) > 1 { profile("into_owned_shared_clone", &self.0.draft); }')
 s=s.replace('    pub(super) fn finalize_ref(&self) -> Result<Schema, SemanticModelError> {','    #[track_caller]\n    pub(super) fn finalize_ref(&self) -> Result<Schema, SemanticModelError> {\n        profile(if self.0.canonical.get().is_some() { "pending_hit" } else { "pending_miss" }, &self.0.draft);')
 s=s.replace('    fn finalize_source_schema(&self)', '    #[track_caller]\n    fn finalize_source_schema(&self)')
 old='''impl FinalizeSourceSchema for SchemaDraft {
    #[track_caller]
    fn finalize_source_schema(&self) -> Result<Schema, SemanticModelError> {
        self.finalize_ref()'''
 new=old.replace('        self.finalize_ref()', '        profile("raw_finalization", self);\n        self.finalize_ref()');assert old in s;s=s.replace(old,new)
 s+='''
std::thread_local! {
    static PROFILE: std::cell::RefCell<std::collections::BTreeMap<(&'static str, &'static str, u32), (u64,u64)>> = std::cell::RefCell::new(std::collections::BTreeMap::new());
}
#[track_caller]
fn profile(kind: &'static str, draft: &SchemaDraft) {
    let at = std::panic::Location::caller();
    PROFILE.with(|p| { let mut p=p.borrow_mut(); let row=p.entry((kind,at.file(),at.line())).or_default(); row.0+=1;row.1+=draft.dimension_parameters.len() as u64; });
}
pub(super) fn profile_report() {
    PROFILE.with(|p| { for ((kind,file,line),(calls,dimensions)) in std::mem::take(&mut *p.borrow_mut()) {
        eprintln!("schema-work-profile: kind={kind} file={file} line={line} calls={calls} dimensions={dimensions}");
    }});
}
'''
 return s
modify('src/engine/src/source_semantics/pending_schema.rs',schema)
def front(s):
 old='''        document_lowering::compile_document_with_catalog(
            document,
            self.nominal_origin.as_ref(),
            catalog,
        )'''
 new=old.replace('        document_lowering','        let result = document_lowering')+';\n        pending_schema::profile_report();\n        result'
 assert s.count(old)==1;return s.replace(old,new)
modify('src/engine/src/source_semantics/frontend.rs',front)
def cleanup(s):
 names=['context.compute_cfg','context.compute_domtree','context.eliminate_unreachable_code','context.remove_constant_phis','context.func.dfg.resolve_all_aliases','preheaders::normalize','local_phis::simplify','unsigned_intervals::combine','selected_ranges::fold','known_widths::fold','dead_values::eliminate','identity_routes::forward','threaded_edges::forward']
 replacements=[]
 for name in names:
  start=0
  while True:
   at=s.find(name+'(',start)
   if at<0:break
   stop=at+len(name);depth=0
   for end in range(stop,len(s)):
    if s[end]=='(':depth+=1
    if s[end]==')':
     depth-=1
     if depth==0:break
   expression=s[at:end+1];replacements.append((at,end+1,'profile_cleanup("'+name+'", || '+expression+')'));start=end+1
 for at,end,value in sorted(replacements,reverse=True):s=s[:at]+value+s[end:]
 for expression in ['fold_identities(&mut context.func)','fold(&mut context.func)']:
  s=s.replace(expression,'profile_cleanup("'+expression.split('(')[0]+'", || '+expression+')')
 s+='''
fn profile_cleanup<T>(pass: &'static str, run: impl FnOnce() -> T) -> T {
    let start = std::time::Instant::now();
    let result = run();
    eprintln!("cleanup-pass-profile: pass={pass} seconds={:.9}", start.elapsed().as_secs_f64());
    result
}
'''
 return s
modify('hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/mod.rs',cleanup)
def compiler(s):
 old='''    Ok((module.finish().emit().map_err(backend)?, metadata))'''
 assert s.count(old)==2
 # Only the compact entry, which occurs first in this source, emits the report.
 return s.replace(old,'''    let bytes = module.finish().emit().map_err(backend)?;
    eprintln!("cranelift-pass-profile:\\n{}", cranelift_codegen::timing::take_current());
    Ok((bytes, metadata))''',1)
modify('hosts/gpu/src/native_artifact/program/compiler.rs',compiler)
def ssa(s):
 marker='/// Structure containing the data relevant the construction of SSA'
 module='''mod work_profile {
    use cranelift_codegen::ir::{Function, Value};
    #[derive(Clone, Copy, Debug, Default)]
    pub(super) struct Counts {
        pub find_calls: u64, pub predecessor_steps: u64,
        pub sealed_sentinels: u64, pub unsealed_sentinels: u64,
        pub retired_sentinels: u64, pub retained_sentinels: u64,
        pub equal_cached_candidates: u64, pub candidate_predecessors: u64,
        pub shifted_suffix_values: u64, pub alias_resolutions: u64,
        pub alias_links: u64, pub max_alias_chain: u64,
    }
    std::thread_local! { static COUNTS: core::cell::Cell<Counts> = core::cell::Cell::new(Counts::default()); }
    pub(super) fn add(update: impl FnOnce(&mut Counts)) { COUNTS.with(|c| {let mut v=c.get();update(&mut v);c.set(v);}); }
    pub(super) fn resolve(func: &Function, value: Value) -> Value {
        let mut root=value;let mut links=0;
        while let Some(next)=func.dfg.value_alias_dest_for_serialization(root) {root=next;links+=1;}
        add(|c| {c.alias_resolutions+=1;c.alias_links+=links;c.max_alias_chain=c.max_alias_chain.max(links);});
        func.dfg.resolve_aliases(value)
    }
    pub(super) fn report() { COUNTS.with(|c| {let v=c.take();if v.find_calls!=0 {std::eprintln!("ssa-work-profile: {v:?}");}}); }
}

'''
 assert s.count(marker)==1;s=s.replace(marker,module+marker)
 marker='''        // Try to find an existing definition along single-predecessor edges first.'''
 assert s.count(marker)==1;s=s.replace(marker,'        work_profile::add(|c| c.find_calls += 1);\n'+marker)
 marker='''        while let Some(pred) = self.ssa_blocks[block].single_predecessor.expand() {'''
 assert s.count(marker)==1;s=s.replace(marker,marker+'\n            work_profile::add(|c| c.predecessor_steps += 1);')
 marker='''        let val = func.dfg.append_block_param(block, ty);'''
 probe='''        let predecessors=self.ssa_blocks[block].predecessors.as_slice(&self.inst_pool);
        if matches!(self.ssa_blocks[block].sealed, Sealed::Yes) {
            work_profile::add(|c| c.sealed_sentinels += 1);
            if !predecessors.is_empty() {
                let mut common=None;let mut eligible=true;
                for &branch in predecessors {
                    let predecessor=func.layout.inst_block(branch).unwrap();
                    let Some(value)=var_defs.get(&predecessor).copied().unwrap_or_default().expand() else {eligible=false;break;};
                    let value=work_profile::resolve(func,value);
                    if common.is_some_and(|old| old!=value) {eligible=false;break;}
                    common=Some(value);
                }
                if eligible {work_profile::add(|c| {c.equal_cached_candidates+=1;c.candidate_predecessors+=predecessors.len() as u64;});}
            }
        } else {work_profile::add(|c| c.unsealed_sentinels += 1);}
'''
 assert s.count(marker)==1;s=s.replace(marker,probe+marker)
 s=s.replace('.map(|&val| func.dfg.resolve_aliases(val))','.map(|&val| work_profile::resolve(func, val))')
 marker='''            func.dfg.remove_block_param(sentinel);'''
 assert s.count(marker)==1;s=s.replace(marker,'''            let cranelift_codegen::ir::ValueDef::Param(owner, index)=func.dfg.value_def(sentinel) else {unreachable!()};
            work_profile::add(|c| {c.retired_sentinels+=1;c.shifted_suffix_values+=(func.dfg.block_params(owner).len()-index as usize-1) as u64;});
'''+marker)
 marker='''            // There is disagreement in the predecessors on which value to use so we have'''
 assert s.count(marker)==1;s=s.replace(marker,'            work_profile::add(|c| c.retained_sentinels += 1);\n'+marker)
 marker='''    pub fn clear(&mut self) {'''
 assert s.count(marker)==1;s=s.replace(marker,marker+'\n        work_profile::report();')
 return s
modify('vendor/cranelift-frontend/src/ssa.rs',ssa)
(root/'source-state.json').write_text(json.dumps({'base_commit':base,'profiling_excluded_from_primary':True},indent=2)+'\n')
print(root)
