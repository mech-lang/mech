from pathlib import Path
import hashlib,json,shutil,subprocess
repo=Path.cwd();packet=Path('/private/tmp/mech-round2-planning-packet-20261114');assert not packet.exists();excluded=[]
roots={'baseline':Path('/private/tmp/mech-round2-baseline-20261114'),'diagnostic':Path('/private/tmp/mech-round2-counters-20261114')}
for label,raw in roots.items():
 for p in sorted(raw.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(raw);dest=Path(label)/rel
  if label=='baseline' and rel.parts[:2]==('link','deps'):continue
  if rel.as_posix() in ['control','instrumented-v2']:
   excluded.append(dict(path=dest.as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()));continue
  d=packet/dest;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
link=roots['baseline']/'link';pins=json.loads((link/'input-pins.json').read_text())
for info in pins['dependency_archives_and_macros']:
 excluded.append(dict(path='baseline/link/deps/'+Path(info['path']).name,bytes=info['bytes'],sha256=info['sha256']))
native=json.loads((link/'capture/link-command.json').read_text());native_pins=[]
for at,info in enumerate(native['inputs']):
 src=Path(info['retained_path']);dest=Path('native-link-inputs')/str(at)/src.name;p=packet/dest;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,p);data=p.read_bytes();assert len(data)==info['bytes'] and hashlib.sha256(data).hexdigest()==info['sha256'];native_pins.append(dict(source=info['source'],path=dest.as_posix(),bytes=info['bytes'],sha256=info['sha256']))
(packet/'native-link-inputs.json').write_text(json.dumps(native_pins,indent=2)+'\n')
pgo=Path('/private/tmp/mech-round2-pgo-20261114')
for p in sorted(pgo.iterdir()):
 if p.is_file() and p.name!='control':
  d=packet/'pgo-setup'/p.name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
p=pgo/'control';excluded.append(dict(path='pgo-setup/control',bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
base='fad53d24d9d2cad61262cb94932405fd9ee40341'
paths=['Cargo.toml','Cargo.lock','.cargo/config.toml','LICENSE','hosts/gpu/src/native_artifact/AGENTS.md','hosts/gpu/src/native_artifact/codegen/backend.rs','hosts/gpu/src/native_artifact/program/compact/phases.rs','hosts/gpu/src/native_artifact/program/compact/phase_function.rs','hosts/gpu/src/native_artifact/program/compact/emit.rs']
paths+=['benchmarks/mech-deflate/native-profile/'+n for n in ['Cargo.toml','Cargo.lock','compile_profile.rs','profile_compile.py']]
for name in paths:
 p=packet/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','show',base+':'+name]))
validation=packet/'validation';validation.mkdir()
for suffix in ['.json','.archive.json']:shutil.copy2(repo/('benchmarks/mech-deflate/native-profile/point-liveness-compile-apple-m3-20261114'+suffix),validation/('qualified-point-liveness'+suffix))
shutil.copytree(Path('/private/tmp/mech-borrowed-schema-packet-20261114/licenses'),packet/'licenses')
for pattern in ['*round2*20261114.py']:
 for p in Path('/private/tmp').glob(pattern):
  if p.is_file():shutil.copy2(p,packet/p.name)
shutil.copy2(repo/'docs/design/native-parallel-compilation.md',packet/'parallel-design.md')
state=dict(source_commit=base,control_source_commit='ab4e6d8bc6f0128b1899c292838c36470295424a',diagnostic_patch_sha256=json.loads((roots['diagnostic']/'instrumented-v2-build.json').read_text())['patch_sha256'],production_instrumentation_retained=False,parallel_mech_compilation_implemented=False,pgo_profile_generation_started=False,scope='Baseline/counter/link design evidence. Borrowing candidate is separate pending work and is not measured or qualified here.')
(packet/'source-state.json').write_text(json.dumps(state,indent=2,sort_keys=True)+'\n');(packet/'excluded-compiler-products.json').write_text(json.dumps(excluded,indent=2)+'\n')
(packet/'README.txt').write_text('''Precise timing, current work counters and parallel-build design, 2026-11-14.
Two complete fresh controls and the separate diagnostic reproduce all fixed
source/MBC/Object/metadata bytes. Diagnostic work counts and partial per-pass
clocks are excluded from performance qualification. The failed warnings-as-errors
build and successful rebuild remain. Instrumentation is removed from production.
The fixed runtime/adapter is compiled and linked once, then its captured native
objects reproduce the complete executable in three warm native links. Three
failed direct-link attempts retain their hashes, commands and logs. Stable
object paths and ZERO_AR_DATE=1 are needed for exact current Mach-O metadata.
Final program executables and native-link inputs are included for byte checks.
Compiler executables and the large coherent Rust dependency bundle are excluded
and hash-pinned. No parallel Mech compiler speedup is claimed. The architectural
proposal records variant dependencies, module ownership and ordered publication.
PGO setup includes its pinned-source control build and matching LLVM tools, but
no instrumented training/profile-use result or PGO saving. Bootstrap and adapter
build costs are separate and overlap; neither is an isolated comparison.
Pure replay checks the stored measurements, source patches, output bytes,
counters and final executable identity. It does not rerun compilers or timings.
The sub-ten-second full-compilation goal remains open.
''');print(packet)
