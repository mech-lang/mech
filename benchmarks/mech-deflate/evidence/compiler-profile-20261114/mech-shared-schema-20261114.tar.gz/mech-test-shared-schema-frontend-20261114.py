from pathlib import Path
import subprocess,os,time,json,hashlib
root=Path('/private/tmp/mech-shared-schema-20261114')
base=['cargo','test','--locked','--offline','--release','-j2','--manifest-path','src/engine/Cargo.toml','--lib','--no-default-features','--features','full_compiler,async,native-artifact,native-plan,sequence_buffers,pure_text,mech-core/full,mech-core/math_pow,mech-syntax/full']
for name,filter in [('frontend-tests','source_semantics'),('codec-tests','artifact::bytecode::tests')]:
 cmd=base+[filter];patch=subprocess.check_output(['git','diff','--binary']);(root/(name+'.patch')).write_bytes(patch);start=time.perf_counter()
 with (root/(name+'.log')).open('w') as out:
  p=subprocess.run(cmd,env=dict(os.environ,CARGO_TARGET_DIR='/private/tmp/mech-level12-compile-target',CARGO_INCREMENTAL='0'),stdout=out,stderr=subprocess.STDOUT)
 result={'command':cmd,'exit_code':p.returncode,'source_patch_sha256':hashlib.sha256(patch).hexdigest(),'seconds':time.perf_counter()-start,'CARGO_TARGET_DIR':'/private/tmp/mech-level12-compile-target','CARGO_INCREMENTAL':'0'}
 (root/(name+'-command.json')).write_text(json.dumps(result,indent=2)+'\n');print(result,flush=True)
 assert subprocess.check_output(['git','diff','--binary'])==patch
 if p.returncode:raise SystemExit(p.returncode)
