from pathlib import Path
import json
repo=Path.cwd();packet=Path('/private/tmp/mech-shared-schema-packet-20261114');s=json.loads((packet/'summary.json').read_text());q=s['qualified']
rows=[]
for key,label in [('compiler_seconds','Compiler, s'),('whole_process_seconds','Whole process, s'),('parse_seconds','Parse, s'),('frontend_seconds','Frontend, s'),('native_seconds','Native, s'),('canonical_lowering_seconds','Canonical lowering, s'),('preparation_seconds','Preparation, s'),('numeric_generation_seconds','Numeric generation, s'),('source_cfg_seconds','Source CFG, s'),('cleanup_including_compaction_seconds','Cleanup including compaction, s'),('compaction_seconds','Compaction, s'),('instructions','Retired instructions'),('max_rss_bytes','Peak RSS, bytes'),('peak_footprint_bytes','Peak footprint, bytes')]:
 v=q[key];fmt=(lambda x:f'{x:,}') if key in ['instructions','max_rss_bytes','peak_footprint_bytes'] else (lambda x:f'{x:.6f}')
 rows.append(f"| {label} | {fmt(min(v['control']))}–{fmt(max(v['control']))} | {fmt(min(v['candidate']))}–{fmt(max(v['candidate']))} | {-100*v['mean_reduction_fraction']:+.2f}% |")
report=f'''# Shared pending frontend schemas: compilation qualification

Complete fresh level-12 compilation takes **21.196–21.415 seconds** on the Apple
M3 Air. Eight matched runs show **2.46% lower whole-process time, 2.37% lower
compiler time, 18.85% lower frontend time and 3.27% fewer instructions**. Peak
RSS falls 1.38%. Source, MBC, Object and complete metadata bytes remain identical.
The full ten-second compilation goal remains open.

The frontend previously copied complete dimension-declaration arrays when it
cloned pending schemas and repeated pure canonicalization on immutable drafts.
Its private pending values now share an immutable schema owner. A mutable access
makes the draft private and invalidates its cached canonical schema or error,
including the case where the owner was already unique. Read-only annotation and
output-schema queries borrow drafts; explicit owned boundaries still materialize
them. Core's public `SchemaDraft` and runtime validation are unchanged.

Only pure schema data and its deterministic validation result are cached. Current
shape, factory, visit, resource and ownership proofs are checked as before. Errors
are still anchored at the caller. Unused malformed dimension declarations remain
validated. No grammar or language change, interpreter fallback, backend setting
change or runtime optimization is part of this trial.

Source `{s['source_commit']}`, parent `{s['base_commit']}`.
The frozen control comes from `{s['control_source_commit']}`; its production
source equals the documentation-only parent. Both subjects use the same opt-in
`compiler` build profile, full fresh source-to-Object pipeline and 60 runtime
flags. Hardware: Apple M3 Air, 8 cores (4P+4E), 16 GB, macOS 26.2.

| Measurement | Control range (4 runs) | Candidate range (4 runs) | Mean change |
| --- | --- | --- | ---: |
'''+ '\n'.join(rows)+'''

Runs are serial control/candidate/candidate/control then
candidate/control/control/candidate. Both blocks improve compiler time (2.61%
and 2.13%). Every candidate compiler, process, instruction and peak RSS observation
falls below every control. Native time is an adverse 0.46% higher; parse and
several native substage means also increase. All observations remain. These finite
cohorts are descriptive, not population estimates. Both subjects include retired
SSA value compaction and its measured cost.

Builds, tests, screens, fixture compiles, hashing, copying and packet work do not
overlap primary timing. The observed 401.050-second optimized compiler rebuild
uses existing Cargo caches, is excluded from Mech compilation timings and is not
a matched cold-bootstrap comparison. Both screens and all eight primary runs
reproduce every qualified output byte. Fourteen successful fixture pairs cover
six complete array/enum programs and eight checked scalar programs, also matching
all four output files. Generated program code and metadata are byte-identical;
no new compressor-runtime timing campaign or CPU sampling is claimed.

The final source passes **64 frontend tests, including four owner tests, and two
codec tests: 66 unique tests**. The new tests use the production owner module and
cover copy-on-write/cache invalidation, cached errors and repair, unused invalid
declarations, 512 seeded drafts with four mutation branches, owned materialization
and concurrent readers. An earlier standalone four-test pass duplicates the owner
tests and predates four test-fixture constructor repairs; it is not counted again.
Type-integration failures and the failed full-suite build remain in the packet.

The [compact result](../../benchmarks/mech-deflate/native-profile/shared-schema-compile-apple-m3-20261114.json)
and [receipt](../../benchmarks/mech-deflate/native-profile/shared-schema-compile-apple-m3-20261114.archive.json)
pin the complete [benchmark evidence packet](../../benchmarks/mech-deflate/evidence/compiler-profile-20261114/README.md).
It includes exact source/base snapshots and patches, flags, commands, raw timings,
all output files, test logs, corrections, compiler executable hashes and pure
offline replay. Compiler executables are excluded. Python 3.11+ replay reconstructs
the summary without compiling, running benchmarks or contacting an external service.
'''
(repo/'docs/design/native-shared-schema-compile-profile.md').write_text(report);(packet/'REPORT.md').write_text(report)
p=repo/'docs/design/native-compiler-process-profile.md';text=p.read_text().replace('**21.830–22.051 seconds per complete','**21.196–21.415 seconds per complete',1).replace('and the [optimized compiler build](native-compiler-lto-compile-profile.md).','the [optimized compiler build](native-compiler-lto-compile-profile.md),\nand [shared pending schemas](native-shared-schema-compile-profile.md).',1)
text+='''
The latest [shared-schema qualification](native-shared-schema-compile-profile.md)
removes repeated pending-draft copying and pure canonicalization in the frontend.
Eight matched 60-flag compiles take 21.196–21.415 seconds: whole-process time falls
2.46%, frontend time 18.85%, instructions 3.27% and peak RSS 1.38%. Native time is
an adverse 0.46% higher. All generated bytes match, and the final source passes
66 unique frontend/codec tests. Its eleventh packet retains every observation,
both screens, fourteen fixture pairs, source patches and integration failures.
The ten-second target remains open.
''';p.write_text(text)
p=repo/'benchmarks/mech-deflate/EXPERIMENTS.md';text=p.read_text();pos=text.index('Paths below name reports **inside the external bundle**.')
text=text[:pos]+'''The [shared-pending-schema qualification](../../docs/design/native-shared-schema-compile-profile.md)
retains private copy-on-write draft owners and pure exact-owner canonicalization.
Eight matched 60-flag runs take 21.196–21.415 seconds: 2.46% less whole-process
time, 18.85% less frontend time, 3.27% fewer instructions and 1.38% lower peak RSS.
Native time is an adverse 0.46% higher. All output bytes match; 66 unique frontend
and codec tests pass. The eleventh packet retains both screens, fourteen fixture
pairs, all observations, exact source and failures. Pure offline replay reproduces
the result; prior archives remain unchanged.

'''+text[pos:];p.write_text(text)
p=repo/'benchmarks/mech-deflate/native-profile/README.md';text=p.read_text();text+='''
The latest [shared-schema compiler result](../../../docs/design/native-shared-schema-compile-profile.md)
records complete fresh compilation at 21.196–21.415 seconds, with identical
generated bytes. Complete packets, receipts and offline replay are indexed in
[compiler-profile evidence](../evidence/compiler-profile-20261114/README.md).
''';p.write_text(text)
