//! Selected state updates use the maintained selection and assignment operations.

use super::*;

impl SemanticBuilder {
    /// A transition-local mutable binding is an SSA value, not retained
    /// document state. Each write consumes the preceding local version.
    pub(super) fn document_local_assignment(
        &mut self,
        name: &str,
        current: PendingValue,
        target: &SliceRefSyntax,
        expression: &ExpressionSyntax,
        arithmetic: Option<&str>,
        statement: &SyntaxNode,
    ) -> Result<PendingValue, SourceSemanticError> {
        let expected = self.schema_draft_of(current)?;
        let mut value = if arithmetic.is_none() && target.subscripts().is_none() {
            self.expression_with_expected(expression, Some(ExpectedSchema::Value(&expected)))?
                .0
        } else {
            self.expression(expression)?.0
        };
        if let Some(subscripts) = target.subscripts() {
            value = self.document_selected_update(
                current,
                &subscripts.items(),
                value,
                arithmetic,
                statement,
                expression.syntax(),
            )?;
        } else if let Some(operation) = arithmetic {
            let Some((inputs, schema)) =
                self.resolve_maintained_call(operation, vec![current, value], statement)?
            else {
                return Err(internal(
                    SourceSemanticAnchor::for_node(statement),
                    format!("assignment operation {operation} has no maintained type declaration"),
                ));
            };
            value = self.emit_with_schema_draft(
                operation,
                inputs,
                schema,
                statement,
                "local-update",
                None,
            );
        }
        value = self.conform_schema_draft(
            value,
            &expected,
            expression.syntax(),
            "source-semantics/incompatible-assignment-kind",
            "assignment value does not satisfy the local binding's schema",
        )?;
        self.bindings
            .insert(name.to_owned(), PendingBinding::MutableLocal(value));
        Ok(value)
    }

    pub(super) fn document_selected_update(
        &mut self,
        base: PendingValue,
        items: &[SubscriptItemSyntax],
        mut replacement: PendingValue,
        arithmetic: Option<&str>,
        statement: &SyntaxNode,
        value_syntax: &SyntaxNode,
    ) -> Result<PendingValue, SourceSemanticError> {
        let Some((item, remaining)) = items.split_first() else {
            if let Some(operation) = arithmetic {
                let Some((inputs, schema)) =
                    self.resolve_maintained_call(operation, vec![base, replacement], statement)?
                else {
                    return Err(internal(
                        SourceSemanticAnchor::for_node(statement),
                        format!(
                            "assignment operation {operation} has no maintained type declaration"
                        ),
                    ));
                };
                replacement = self.emit_with_schema_draft(
                    operation,
                    inputs,
                    schema,
                    statement,
                    "state-update",
                    None,
                );
            }
            let expected = self.schema_draft_of(base)?;
            return self.conform_assignment_value(replacement, expected.into(), value_syntax);
        };
        let schema = self.schema_draft_of(base)?;
        if !matches!(
            schema.body,
            SchemaBody::Matrix { .. }
                | SchemaBody::Record(_)
                | SchemaBody::Table { .. }
                | SchemaBody::Tuple(_)
                | SchemaBody::Map { .. }
        ) {
            return Err(SourceSemanticError {
                code: "source-semantics/unsupported-assignment-target",
                message: "assignment selection requires a mutable collection".to_owned(),
                anchor: SourceSemanticAnchor::for_node(item.syntax()),
            });
        }
        if items.len() > 1
            && arithmetic.is_some()
            && matches!(&schema.body, SchemaBody::Matrix { element, .. }
                if !matches!(element.as_ref(), SchemaBody::Matrix { .. } | SchemaBody::Record(_) | SchemaBody::Table { .. } | SchemaBody::Tuple(_) | SchemaBody::Map { .. }))
            && items.iter().all(|item| {
                matches!(
                    item,
                    SubscriptItemSyntax::Bracket(_) | SubscriptItemSyntax::Brace(_)
                )
            })
        {
            return self.document_nested_matrix_update(
                base,
                items,
                replacement,
                arithmetic.unwrap(),
                statement,
                value_syntax,
            );
        }
        let read_selection = !remaining.is_empty()
            || (arithmetic.is_some() && !matches!(schema.body, SchemaBody::Matrix { .. }));
        let (selected, selected_schema, selectors, operation) = match item {
            SubscriptItemSyntax::Bracket(bracket) => {
                let selectors = self.subscript_values(&bracket.values())?;
                self.document_assignment_selection(base, selectors, item.syntax(), read_selection)?
            }
            SubscriptItemSyntax::Brace(brace) => {
                let selectors = self.subscript_values(&brace.values())?;
                self.document_assignment_selection(base, selectors, item.syntax(), read_selection)?
            }
            SubscriptItemSyntax::Dot(dot) => {
                let field = self.required(dot.identifier(), dot.syntax(), "a selected field")?;
                let name = node_text(field.syntax())?;
                let selected = self.select_field(base, &name, item.syntax())?;
                let selector = self.constant_exact(
                    SchemaBody::Id,
                    ValueDataDraft::Id(mech_core::hash_str(&name)),
                );
                (
                    Some(selected),
                    self.schema_draft_of(selected)?.into_owned(),
                    vec![selector],
                    "core/assign/collection-entry",
                )
            }
            SubscriptItemSyntax::DotInteger(dot) => {
                let integer = self.required(dot.integer(), dot.syntax(), "a selected ordinal")?;
                let text = canonical_numeric_text(integer.syntax())?;
                let suffix = integer_literal_suffix(&integer)?;
                let (schema, data) = decode_number(&text, None, suffix)
                    .ok_or_else(|| missing_kind_child(dot.syntax(), "a valid selected ordinal"))?;
                let selector = self.constant(schema, data);
                self.document_assignment_selection(
                    base,
                    vec![Some(selector)],
                    item.syntax(),
                    read_selection,
                )?
            }
            SubscriptItemSyntax::Swizzle(swizzle) => {
                let selected = self.select(base, item)?;
                let replacement = self.document_selected_update(
                    selected,
                    remaining,
                    replacement,
                    arithmetic,
                    statement,
                    value_syntax,
                )?;
                let mut updated = base;
                for (ordinal, name) in swizzle.identifiers().enumerate() {
                    let name = node_text(name.syntax())?;
                    let ordinal = self.constant_exact(
                        SchemaBody::Index,
                        ValueDataDraft::Index((ordinal + 1) as u64),
                    );
                    let value =
                        self.select_values(replacement, vec![Some(ordinal)], item.syntax())?;
                    let field = self.constant_exact(
                        SchemaBody::Id,
                        ValueDataDraft::Id(mech_core::hash_str(&name)),
                    );
                    updated = self.emit_with_schema_draft(
                        "core/assign/collection-entry",
                        vec![updated, value, field],
                        schema.clone(),
                        statement,
                        "state-update",
                        None,
                    );
                }
                return Ok(updated);
            }
        };
        if remaining.is_empty()
            && let Some(arithmetic) = arithmetic
            && matches!(schema.body, SchemaBody::Matrix { .. })
            && matches!(
                operation,
                "core/assign/indexed-axis"
                    | "core/assign/indexed-rows"
                    | "core/assign/indexed-columns"
                    | "core/assign/indexed-rectangle"
            )
        {
            // A gather followed by arithmetic and replacement loses repeated
            // selector occurrences. Carry the update into the addressed RMW
            // owner so each occurrence reads the current candidate value.
            let declaration = self.source_type_declaration(arithmetic).map_err(|_| {
                internal(
                    SourceSemanticAnchor::for_node(statement),
                    format!("assignment operation {arithmetic} has no maintained type declaration"),
                )
            })?;
            let (inputs, _) = self.resolve_declared_call_with_destination(
                arithmetic,
                vec![base, replacement],
                statement,
                declaration,
                Some(selected_schema),
            )?;
            let replacement = inputs[1];
            let operation = format!("{operation}/{}", arithmetic.strip_prefix("math/").unwrap());
            let mut inputs = vec![base, replacement];
            inputs.extend(selectors);
            return Ok(self.emit_with_schema_draft(
                &operation,
                inputs,
                schema,
                statement,
                "state-update",
                None,
            ));
        }
        let replacement = if remaining.is_empty() && arithmetic.is_none() {
            self.conform_assignment_value(replacement, selected_schema, value_syntax)?
        } else {
            self.document_selected_update(
                selected.expect("nested and arithmetic assignments retain the selected read"),
                remaining,
                replacement,
                arithmetic,
                statement,
                value_syntax,
            )?
        };
        let mut inputs = vec![base, replacement];
        inputs.extend(selectors);
        Ok(self.emit_with_schema_draft(operation, inputs, schema, statement, "state-update", None))
    }

    fn document_nested_matrix_update(
        &mut self,
        base: PendingValue,
        items: &[SubscriptItemSyntax],
        replacement: PendingValue,
        arithmetic: &str,
        statement: &SyntaxNode,
        _value_syntax: &SyntaxNode,
    ) -> Result<PendingValue, SourceSemanticError> {
        let schema = self.schema_draft_of(base)?;
        let SchemaBody::Matrix { .. } = &schema.body else {
            unreachable!()
        };
        // The final RMW owner retains the complete selector chain. This keeps
        // turn-varying selector populations live without materializing a dense
        // selected-value proxy or a base-sized identity-address matrix.
        let mut selected_schema = schema.clone();
        let mut selection_plan = Vec::new();
        for item in items {
            let selectors = match item {
                SubscriptItemSyntax::Bracket(bracket) => {
                    self.subscript_values(&bracket.values())?
                }
                SubscriptItemSyntax::Brace(brace) => self.subscript_values(&brace.values())?,
                _ => unreachable!("nested matrix updates admit bracket and brace selectors"),
            };
            let mode = match selectors.as_slice() {
                [None] => 1,
                [Some(_)] => 2,
                [Some(_), None] => 3,
                [None, Some(_)] => 4,
                [Some(_), Some(_)] => 5,
                [None, None] => 6,
                _ => unreachable!("selection validation checks arity"),
            };
            let (_, selectors, next_schema) =
                self.prepare_selection_schema(selected_schema.into(), selectors, item.syntax())?;
            selection_plan
                .push(self.constant_exact(SchemaBody::Index, ValueDataDraft::Index(mode)));
            selection_plan.extend(selectors);
            selected_schema = next_schema.into();
        }
        let declaration = self.source_type_declaration(arithmetic).map_err(|_| {
            internal(
                SourceSemanticAnchor::for_node(statement),
                format!("assignment operation {arithmetic} has no maintained type declaration"),
            )
        })?;
        let (inputs, _) = self.resolve_declared_call_with_destination(
            arithmetic,
            vec![base, replacement],
            statement,
            declaration,
            Some(selected_schema.into()),
        )?;
        let operation = format!(
            "core/assign/nested/{}",
            arithmetic.strip_prefix("math/").unwrap()
        );
        let mut inputs = vec![base, inputs[1]];
        inputs.extend(selection_plan);
        Ok(
            self.emit_with_schema_draft(
                &operation,
                inputs,
                schema,
                statement,
                "state-update",
                None,
            ),
        )
    }

    fn conform_assignment_value(
        &mut self,
        replacement: PendingValue,
        mut expected: SchemaDraft,
        syntax: &SyntaxNode,
    ) -> Result<PendingValue, SourceSemanticError> {
        // Maintained matrix assignment broadcasts scalar replacement values.
        if !matches!(
            self.schema_draft_of(replacement)?.body,
            SchemaBody::Matrix { .. }
        ) && let SchemaBody::Matrix { element, .. } = &expected.body
        {
            expected.body = *element.clone();
        }
        self.conform_schema_draft(
            replacement,
            &expected,
            syntax,
            "source-semantics/incompatible-assignment-kind",
            "assignment value does not satisfy the selected binding's schema",
        )
    }

    fn document_assignment_selection(
        &mut self,
        base: PendingValue,
        selectors: Vec<Option<PendingValue>>,
        syntax: &SyntaxNode,
        read: bool,
    ) -> Result<
        (
            Option<PendingValue>,
            SchemaDraft,
            Vec<PendingValue>,
            &'static str,
        ),
        SourceSemanticError,
    > {
        // Validate once through the read-selection authority, but emit a read
        // only when nested or mixed-kind arithmetic actually consumes it.
        // Whole-value writes preserve the destination geometry.
        let selection = if matches!(selectors.as_slice(), [None] | [None, None]) {
            PendingSelection {
                operation: None,
                inputs: vec![base],
                schema: self.schema_draft_of(base)?.into(),
            }
        } else {
            self.prepare_selection(base, selectors.clone(), syntax)?
        };
        let selected_schema = selection.schema.clone();
        let selected =
            (read || selection.operation.is_none()).then(|| self.emit_selection(selection, syntax));
        let operation = match selectors.as_slice() {
            [None] | [None, None] => "core/assign/whole-value",
            [Some(_), None] => "core/assign/indexed-rows",
            [None, Some(_)] => "core/assign/indexed-columns",
            [Some(_), Some(_)] => "core/assign/indexed-rectangle",
            [Some(_)] => match self.schema_draft_of(base)?.body {
                SchemaBody::Map { .. } => "core/assign/collection-entry",
                SchemaBody::Tuple(_) => "core/assign/single-element",
                _ => "core/assign/indexed-axis",
            },
            _ => unreachable!("selection validation checks arity"),
        };
        Ok((
            selected,
            selected_schema,
            selectors.into_iter().flatten().collect(),
            operation,
        ))
    }
}
