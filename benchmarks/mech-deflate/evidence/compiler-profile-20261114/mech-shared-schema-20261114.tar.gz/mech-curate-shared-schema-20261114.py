from pathlib import Path
import subprocess,json,hashlib,shutil
repo=Path.cwd();packet=Path('/private/tmp/mech-shared-schema-packet-20261114');assert not packet.exists()
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();base='f18b1b20c25fd20efc8ce06c8664c72197e7cd52';control_source='7306a0097a2a8e52bf263bb9d600a5e4ed8b417d'
raw=Path('/private/tmp/mech-shared-schema-20261114');patch=subprocess.check_output(['git','diff','--binary',base,source]);assert patch==(raw/'candidate.patch').read_bytes()
assert subprocess.check_output(['git','diff',control_source,base,'--','src','hosts','vendor','machines','Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.toml'])==b''
excluded=[]
for p in sorted(raw.rglob('*')):
 if not p.is_file():continue
 rel=Path('compiler')/p.relative_to(raw)
 if p.name in ['control','candidate']:
  excluded.append(dict(path=rel.as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()));continue
 d=packet/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
(packet/'excluded-executables.json').write_text(json.dumps(excluded,indent=2)+'\n');(packet/'source-change.patch').write_bytes(patch)
state=dict(source_commit=source,base_commit=base,control_source_commit=control_source,control_production_source_identical_to_base=True,patch_sha256=hashlib.sha256(patch).hexdigest(),hardware='Apple M3 Air, 8 cores (4P+4E), 16 GB, macOS 26.2',rustc=subprocess.check_output(['rustc','-Vv'],text=True),cargo=subprocess.check_output(['cargo','-V'],text=True));(packet/'source-state.json').write_text(json.dumps(state,indent=2,sort_keys=True)+'\n')
changed=subprocess.check_output(['git','diff','--name-only',base,source],text=True).splitlines()
paths=changed+['Cargo.toml','Cargo.lock','.cargo/config.toml','LICENSE','src/core/src/schema/mod.rs','src/core/src/schema/validation.rs','src/core/src/schema/dimension_relations.rs','src/core/src/dimension.rs','hosts/gpu/tests/fixtures/native/deflate-huffman-LICENSES.md']
paths+=['benchmarks/mech-deflate/native-profile/'+n for n in ['Cargo.lock','compile_profile.rs','profile_compile.py']]
paths+=['hosts/gpu/tests/fixtures/native/'+n+'.mec' for n in ['numeric-nested-phase','numeric-nested-phase-states','numeric-private-fixed-nested','numeric-changing-capture-tree','numeric-array-windows','numeric-multiple-children']]
for name in dict.fromkeys(paths):
 d=packet/'source'/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(subprocess.check_output(['git','show',source+':'+name]))
for name in [*changed,'Cargo.toml']:
 if subprocess.run(['git','cat-file','-e',base+':'+name],capture_output=True).returncode:continue
 d=packet/'source-base'/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(subprocess.check_output(['git','show',base+':'+name]))
validation=packet/'validation';validation.mkdir()
for suffix in ['.json','.archive.json']:shutil.copy2(repo/('benchmarks/mech-deflate/native-profile/compiler-lto-compile-apple-m3-20261114'+suffix),validation/('qualified-compiler-lto'+suffix))
shutil.copytree(Path('/private/tmp/mech-borrowed-schema-packet-20261114/licenses'),packet/'licenses')
for pattern in ['mech-*shared-schema*20261114.py','mech-*shared-schema*20261114.log','mech-shared-schema-check*20261114.jsonl','mech-shared-schema-check*20261114.stderr','mech-shared-schema-check-suggestions-20261114.json']:
 for p in Path('/private/tmp').glob(pattern):
  if p.is_file():shutil.copy2(p,packet/p.name)
(packet/'README.txt').write_text('''Shared pending frontend schemas, Apple M3, 2026-11-14.
The private frontend owner shares immutable schema drafts and pure canonical
schema/error data. Every mutable access invalidates the cache, including unique
owners. Core SchemaDraft, runtime proof checks and language rules are unchanged.
Eight serial ABBA/BAAB fresh source-to-Object compiles use identical 60 flags
and the same opt-in compiler profile. All four output files match in both
screens, all eight observations and all fourteen successful fixture pairs.
Compiler builds, tests, screens, fixtures, hashing, copying and packet work do
not overlap primary timing. Adverse native/parse/stage observations remain.
Final source passes 64 frontend tests (including four owner tests) and two codec
tests: 66 unique tests. An earlier standalone four-test run duplicates those
owner tests and precedes four test-fixture constructor repairs. That earlier
success is not counted again. All type-integration failures and the failed
full-suite build remain with the exact available patches and raw diagnostics.
The observed 401-second compiler rebuild is not a cold-bootstrap comparison and
is excluded from Mech compilation timings. Compiler executables are excluded
and pinned. Generated program bytes are identical; no new runtime timing
campaign is claimed. The sub-ten-second full-compilation goal remains open.
This packet is published in benchmarks at the user's request. Python 3.11+
replay is pure offline validation/reconstruction, without compilers, benchmarks,
original scratch paths or an external service.
''')
print(packet,flush=True)
