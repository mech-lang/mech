//! Copy-on-write schema storage for one frontend's pending values.
//! Canonicalization is pure schema data; no shape, factory or visit proof lives here.
use mech_core::{Schema, SchemaDraft, SemanticModelError};
use std::borrow::Borrow;
use std::fmt;
use std::ops::{Deref, DerefMut};
use std::sync::{Arc, OnceLock};

#[derive(Clone)]
pub(super) struct PendingSchema(Arc<Data>);

struct Data {
    draft: SchemaDraft,
    canonical: OnceLock<Result<Schema, SemanticModelError>>,
}

impl Clone for Data {
    fn clone(&self) -> Self {
        Self { draft: self.draft.clone(), canonical: OnceLock::new() }
    }
}

impl From<SchemaDraft> for PendingSchema {
    fn from(draft: SchemaDraft) -> Self {
        Self(Arc::new(Data { draft, canonical: OnceLock::new() }))
    }
}
impl From<PendingSchema> for SchemaDraft {
    fn from(schema: PendingSchema) -> Self { schema.into_owned() }
}

impl PendingSchema {
    pub(super) fn into_owned(self) -> SchemaDraft {
        match Arc::try_unwrap(self.0) {
            Ok(data) => data.draft,
            Err(data) => data.draft.clone(),
        }
    }
    pub(super) fn finalize_ref(&self) -> Result<Schema, SemanticModelError> {
        self.0.canonical.get_or_init(|| self.0.draft.finalize_ref()).clone()
    }
    pub(super) fn finalize(self) -> Result<Schema, SemanticModelError> {
        self.finalize_ref()
    }
}

impl Deref for PendingSchema {
    type Target = SchemaDraft;
    fn deref(&self) -> &SchemaDraft { &self.0.draft }
}
impl DerefMut for PendingSchema {
    fn deref_mut(&mut self) -> &mut SchemaDraft {
        let data = Arc::make_mut(&mut self.0);
        // Even a unique owner may have been finalized before this mutation.
        data.canonical.take();
        &mut data.draft
    }
}
impl Borrow<SchemaDraft> for PendingSchema {
    fn borrow(&self) -> &SchemaDraft { self }
}
impl fmt::Debug for PendingSchema {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result { self.deref().fmt(f) }
}
impl PartialEq for PendingSchema {
    fn eq(&self, rhs: &Self) -> bool { self.deref() == rhs.deref() }
}
impl Eq for PendingSchema {}
impl PartialEq<SchemaDraft> for PendingSchema {
    fn eq(&self, rhs: &SchemaDraft) -> bool { self.deref() == rhs }
}
impl PartialEq<PendingSchema> for SchemaDraft {
    fn eq(&self, rhs: &PendingSchema) -> bool { self == rhs.deref() }
}

pub(super) trait FinalizeSourceSchema {
    fn finalize_source_schema(&self) -> Result<Schema, SemanticModelError>;
}
impl FinalizeSourceSchema for PendingSchema {
    fn finalize_source_schema(&self) -> Result<Schema, SemanticModelError> { self.finalize_ref() }
}
impl FinalizeSourceSchema for SchemaDraft {
    fn finalize_source_schema(&self) -> Result<Schema, SemanticModelError> { self.finalize_ref() }
}
