from pathlib import Path
packet=Path('/private/tmp/mech-shared-schema-packet-20261114');old=Path('/private/tmp/mech-compiler-lto-packet-20261114/replay.py').read_text();defs=old[old.index('stage_fields='):old.index('def validate_cohort(')];fn=old[old.index('def validate_cohort('):old.index('def validate_profile(')]
prefix='''from pathlib import Path
import json,hashlib,re,statistics,tomllib
root=Path(__file__).resolve().parent;raw=root/'compiler'
read=lambda p:json.loads(p.read_text())
def pin(p):
 data=p.read_bytes();return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
state=read(root/'source-state.json');build=read(raw/'candidate-build.json');control=read(raw/'control-origin.json');patch=pin(root/'source-change.patch');assert patch==pin(raw/'candidate.patch') and patch['sha256']==state['patch_sha256']==build['patch_sha256']
assert build['exit_code']==0 and build['head']==state['base_commit'] and state['control_production_source_identical_to_base']
prior=read(root/'validation/qualified-compiler-lto.json');receipt=read(root/'validation/qualified-compiler-lto.archive.json');assert pin(root/'validation/qualified-compiler-lto.json')['sha256']==receipt['replay_sha256'];assert control['sha256']==prior['compiler_binary_sha256']['candidate'] and control['source_commit']==state['control_source_commit']==prior['source_commit']
flags=read(raw/'runtime-flags.json');assert len(flags)==60;expected=prior['output_hashes'];assert read(raw/'reference-pins.json')==expected
excluded={r['path']:r for r in read(root/'excluded-executables.json')};assert excluded['compiler/control']['sha256']==control['sha256'] and excluded['compiler/candidate']['sha256']==build['binary_sha256']
profile_settings={}
for name in ['Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.toml']:
 before=tomllib.loads((root/'source-base'/name).read_text());after=tomllib.loads((root/'source'/name).read_text());assert after['profile']==before['profile'];profile_settings[name]=after['profile']['compiler']
assert '--profile' in build['command'] and build['command'][build['command'].index('--profile')+1]=='compiler' and '--release' not in build['command']
'''
end='''
qualification=validate_cohort(raw,flags,expected,{'control':control['sha256'],'candidate':build['binary_sha256']},'matches_current_control_output')
tests={}
for name,count in [('frontend',64),('codec',2)]:
 command=read(raw/(name+'-tests-command.json'));assert command['exit_code']==0 and command['source_patch_sha256']==state['patch_sha256']==pin(raw/(name+'-tests.patch'))['sha256']
 counts=list(map(int,re.findall(r'test result: ok\\. (\\d+) passed',(raw/(name+'-tests.log')).read_text())));assert counts==[count];tests[name]=dict(command=command,passed=count)
early=read(raw/'owner-tests-command.json');failure=read(raw/'corrections/frontend-test-boundaries/frontend-tests-command.json');assert early['exit_code']==0 and failure['exit_code']==101;assert early['source_patch_sha256']==failure['source_patch_sha256']==pin(raw/'owner-tests.patch')['sha256']==pin(raw/'corrections/frontend-test-boundaries/frontend-tests.patch')['sha256'];assert re.findall(r'test result: ok\\. (\\d+) passed',(raw/'owner-tests.log').read_text())==['4']
assert 'pending_schema.rs' in (root/'source/benchmarks/mech-deflate/native-profile/pending_schema_tests.rs').read_text()
summary=dict(source_commit=state['source_commit'],base_commit=state['base_commit'],control_source_commit=state['control_source_commit'],hardware=state['hardware'],decision='Retain private copy-on-write pending frontend schemas and exact-owner pure canonicalization; identical generated program bytes',candidate_patch_sha256=state['patch_sha256'],profile_settings=profile_settings,candidate_rebuild_seconds=build['seconds'],rebuild_scope='Observed locked/offline optimized-profile rebuild with existing Cargo caches. Excluded from program compilation timing; no matched cold-bootstrap comparison.',compiler_executable_bytes={v:excluded['compiler/'+v]['bytes'] for v in ['control','candidate']},rust_tests=tests,unique_final_rust_tests=66,earlier_duplicate_owner_tests=4,scope=[
 'Eight serial fresh source-to-Object primary observations in ABBA then BAAB order, identical 60 runtime flags and compiler build profile. No cached Object or decoded-only substitute.',
 'Builds, tests, screens, fixtures, hashing, copying and packet work do not overlap primary timing. All source, MBC, Object and complete metadata bytes match the qualified program in both screens and every primary observation; fourteen successful fixture pairs also match all four files.',
 'Only private frontend draft ownership, borrowing and pure immutable schema/error canonicalization change. Mutation invalidates the exact-owner cache including unique owners. Public Core SchemaDraft, grammar, language, checked errors, finite admission, current shape/factory/visit/ownership proofs and direct scalar emission remain unchanged.',
 'Final source passes 64 frontend tests including four production-module owner tests, plus two codec tests. An earlier standalone run of those four owner tests is duplicate coverage and precedes four test-fixture constructor repairs. Integration failures and their raw diagnostics remain.',
 'Both balanced blocks improve compiler time. Every candidate compiler/process/instruction/RSS observation is below every control. Native and parse mean times and several native substage means are adverse and retained. Finite cohorts are descriptive, not population estimates.',
 'Both subjects include retired-value compaction and its measured cost. Generated machine code and complete metadata are byte-identical. No new compressor-runtime timing campaign or new CPU sampling is claimed. Complete compilation remains above ten seconds.'
],**qualification)
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
'''
(packet/'replay.py').write_text(prefix+defs+fn+end)
