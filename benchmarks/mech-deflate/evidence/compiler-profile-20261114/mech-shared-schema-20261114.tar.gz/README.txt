Shared pending frontend schemas, Apple M3, 2026-11-14.
The private frontend owner shares immutable schema drafts and pure canonical
schema/error data. Every mutable access invalidates the cache, including unique
owners. Core SchemaDraft, runtime proof checks and language rules are unchanged.
Eight serial ABBA/BAAB fresh source-to-Object compiles use identical 60 flags
and the same opt-in compiler profile. All four output files match in both
screens, all eight observations and all fourteen successful fixture pairs.
Compiler builds, tests, screens, fixtures, hashing, copying and packet work do
not overlap primary timing. Adverse native/parse/stage observations remain.
Final source passes 64 frontend tests (including four owner tests) and two codec
tests: 66 unique tests. An earlier standalone four-test run duplicates those
owner tests and precedes four test-fixture constructor repairs. That earlier
success is not counted again. All type-integration failures and the failed
full-suite build remain with the exact available patches and raw diagnostics.
The observed 401-second compiler rebuild is not a cold-bootstrap comparison and
is excluded from Mech compilation timings. Compiler executables are excluded
and pinned. Generated program bytes are identical; no new runtime timing
campaign is claimed. The sub-ten-second full-compilation goal remains open.
This packet is published in benchmarks at the user's request. Python 3.11+
replay is pure offline validation/reconstruction, without compilers, benchmarks,
original scratch paths or an external service.
