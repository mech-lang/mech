//! A Constant-Phi-Node removal pass.

use crate::dominator_tree::DominatorTree;
use crate::ir;
use crate::ir::Function;
use crate::ir::{Block, BlockArg, BlockCall, Inst, Value};
use crate::timing;
use crate::{FxHashMap, FxHashSet};
use bumpalo::Bump;
use cranelift_entity::SecondaryMap;
use smallvec::SmallVec;

// A note on notation.  For the sake of clarity, this file uses the phrase
// "formal parameters" to mean the `Value`s listed in the block head, and
// "actual parameters" to mean the `Value`s passed in a branch or a jump:
//
// block4(v16: i32, v18: i32):            <-- formal parameters
//   ...
//   brif v27, block7(v22, v24), block6   <-- actual parameters

// This transformation pass (conceptually) partitions all values in the
// function into two groups:
//
// * Group A: values defined by block formal parameters, except for the entry block.
//
// * Group B: All other values: that is, values defined by instructions,
//   and the formals of the entry block.
//
// For each value in Group A, it attempts to establish whether it will have
// the value of exactly one member of Group B.  If so, the formal parameter is
// deleted, all corresponding actual parameters (in jumps/branches to the
// defining block) are deleted, and a rename is inserted.
//
// The entry block is special-cased because (1) we don't know what values flow
// to its formals and (2) in any case we can't change its formals.
//
// Work proceeds in three phases.
//
// * Phase 1: examine all instructions.  For each block, make up a useful
//   grab-bag of information, `BlockSummary`, that summarises the block's
//   formals and jump/branch instruction.  This is used by Phases 2 and 3.
//
// * Phase 2: for each value in Group A, try to find a single Group B value
//   that flows to it. The finite None -> One -> Many lattice is solved with
//   a worklist over dependencies encoded from the summaries. Only changes
//   propagate; instructions are not rescanned. The resulting fixed point is
//   stored in a `SolverState`.
//
// * Phase 3: using the `SolverState` and `BlockSummary`, edit the function to
//   remove redundant formals and actuals, and to insert suitable renames.
//
// Note that the effectiveness of the analysis depends on on the fact that
// there are no copy instructions in Cranelift's IR.  If there were, the
// computation of `actual_absval` in Phase 2 would have to be extended to
// chase through such copies.
//
// For large functions, the analysis cost using the new AArch64 backend is about
// 0.6% of the non-optimising compile time, as measured by instruction counts.
// This transformation usually pays for itself several times over, though, by
// reducing the isel/regalloc cost downstream.  Gains of up to 7% have been
// seen for large functions.

/// The `Value`s (Group B) that can flow to a formal parameter (Group A).
#[derive(Clone, Copy, Debug, PartialEq)]
enum AbstractValue {
    /// Two or more values flow to this formal.
    Many,

    /// Exactly one value, as stated, flows to this formal.  The `Value`s that
    /// can appear here are exactly: `Value`s defined by `Inst`s, plus the
    /// `Value`s defined by the formals of the entry block.  Note that this is
    /// exactly the set of `Value`s that are *not* tracked in the solver below
    /// (see `SolverState`).
    One(Value /*Group B*/),

    /// No value flows to this formal.
    None,
}

impl AbstractValue {
    fn join(self, other: AbstractValue) -> AbstractValue {
        match (self, other) {
            // Joining with `None` has no effect
            (AbstractValue::None, p2) => p2,
            (p1, AbstractValue::None) => p1,
            // Joining with `Many` produces `Many`
            (AbstractValue::Many, _p2) => AbstractValue::Many,
            (_p1, AbstractValue::Many) => AbstractValue::Many,
            // The only interesting case
            (AbstractValue::One(v1), AbstractValue::One(v2)) => {
                if v1 == v2 {
                    AbstractValue::One(v1)
                } else {
                    AbstractValue::Many
                }
            }
        }
    }

    fn is_one(self) -> bool {
        matches!(self, AbstractValue::One(_))
    }
}

#[derive(Clone, Copy, Debug)]
struct OutEdge<'a> {
    /// An instruction that transfers control.
    inst: Inst,
    /// The index into branch_destinations for this instruction that corresponds
    /// to this edge.
    branch_index: u32,
    /// The block that control is transferred to.
    block: Block,
    /// The arguments to that block.
    ///
    /// These values can be from both groups A and B.
    args: &'a [BlockArg],
}

impl<'a> OutEdge<'a> {
    /// Construct a new `OutEdge` for the given instruction.
    ///
    /// Returns `None` if this is an edge without any block arguments, which
    /// means we can ignore it for this analysis's purposes.
    #[inline]
    fn new(
        bump: &'a Bump,
        dfg: &ir::DataFlowGraph,
        inst: Inst,
        branch_index: usize,
        block: BlockCall,
    ) -> Option<Self> {
        let inst_var_args = block.args(&dfg.value_lists);

        // Skip edges without params.
        if inst_var_args.len() == 0 {
            return None;
        }

        Some(OutEdge {
            inst,
            branch_index: branch_index as u32,
            block: block.block(&dfg.value_lists),
            args: bump.alloc_slice_fill_iter(
                inst_var_args.map(|arg| arg.map_value(|value| dfg.resolve_aliases(value))),
            ),
        })
    }
}

/// For some block, a useful bundle of info.  The `Block` itself is not stored
/// here since it will be the key in the associated `FxHashMap` -- see
/// `summaries` below.  For the `SmallVec` tuning params: most blocks have
/// few parameters, hence `4`.  And almost all blocks have either one or two
/// successors, hence `2`.
#[derive(Clone, Debug, Default)]
struct BlockSummary<'a> {
    /// Formal parameters for this `Block`.
    ///
    /// These values are from group A.
    formals: &'a [Value],

    /// Each outgoing edge from this block.
    ///
    /// We don't bother to include transfers that pass zero parameters
    /// since that makes more work for the solver for no purpose.
    ///
    /// We optimize for the case where a branch instruction has up to two
    /// outgoing edges, as unconditional jumps and conditional branches are
    /// more prominent than br_table.
    dests: SmallVec<[OutEdge<'a>; 2]>,
}

impl<'a> BlockSummary<'a> {
    /// Construct a new `BlockSummary`, using `values` as its backing storage.
    #[inline]
    fn new(bump: &'a Bump, formals: &[Value]) -> Self {
        Self {
            formals: bump.alloc_slice_copy(formals),
            dests: Default::default(),
        }
    }
}

/// Solver state.  This holds a AbstractValue for each formal parameter, except
/// for those from the entry block.
struct SolverState {
    absvals: FxHashMap<Value /*Group A*/, AbstractValue>,
}

impl SolverState {
    fn new() -> Self {
        Self {
            absvals: FxHashMap::default(),
        }
    }

    fn get(&self, actual: Value) -> AbstractValue {
        *self
            .absvals
            .get(&actual)
            .unwrap_or_else(|| panic!("SolverState::get: formal param {actual:?} is untracked?!"))
    }

    #[cfg(any(test, feature = "std"))]
    fn maybe_get(&self, actual: Value) -> Option<&AbstractValue> {
        self.absvals.get(&actual)
    }

    #[cfg(any(test, feature = "std"))]
    fn set(&mut self, actual: Value, lp: AbstractValue) {
        match self.absvals.insert(actual, lp) {
            Some(_old_lp) => {}
            None => panic!("SolverState::set: formal param {actual:?} is untracked?!"),
        }
    }
}

struct SolverWork {
    dependencies: usize,
    processed: usize,
}

// Formals only move None -> One -> Many. Encode their outgoing dependencies
// once, then revisit only the successors of a changed formal.
fn solve_worklist(
    summaries: &SecondaryMap<Block, BlockSummary<'_>>,
    postorder: &[Block],
    entry_block: Block,
) -> (SolverState, SolverWork) {
    let mut formals = alloc::vec::Vec::new();
    let mut indices = FxHashMap::<Value, usize>::default();
    for block in postorder.iter().rev().copied() {
        if block == entry_block {
            continue;
        }
        for &formal in summaries[block].formals {
            assert!(indices.insert(formal, formals.len()).is_none());
            formals.push(formal);
        }
    }
    let mut values = alloc::vec![AbstractValue::None; formals.len()];
    let mut edges = alloc::vec::Vec::new();
    let mut counts = alloc::vec![0usize; formals.len()];
    for block in postorder.iter().rev().copied() {
        for edge in &summaries[block].dests {
            assert!(edge.block != entry_block);
            let targets = summaries[edge.block].formals;
            assert_eq!(edge.args.len(), targets.len());
            for (&formal, actual) in targets.iter().zip(edge.args) {
                let destination = indices[&formal];
                let seed = match actual {
                    BlockArg::Value(actual) => match indices.get(actual) {
                        Some(&source) => {
                            edges.push((source, destination));
                            counts[source] += 1;
                            continue;
                        }
                        None => AbstractValue::One(*actual),
                    },
                    _ => AbstractValue::Many,
                };
                values[destination] = values[destination].join(seed);
            }
        }
    }
    let dependencies = edges.len();
    let mut offsets = alloc::vec::Vec::with_capacity(formals.len() + 1);
    offsets.push(0usize);
    for &count in &counts {
        offsets.push(offsets.last().unwrap() + count);
    }
    counts.copy_from_slice(&offsets[..formals.len()]);
    let mut successors = alloc::vec![0usize; dependencies];
    for (source, destination) in edges {
        successors[counts[source]] = destination;
        counts[source] += 1;
    }
    drop(counts);
    drop(indices);
    let mut queued = alloc::vec![false; formals.len()];
    let mut queue = alloc::vec::Vec::new();
    for (index, value) in values.iter().enumerate() {
        if *value != AbstractValue::None {
            queue.push(index);
            queued[index] = true;
        }
    }
    let mut processed = 0;
    while processed < queue.len() {
        let source = queue[processed];
        processed += 1;
        queued[source] = false;
        let actual = values[source];
        for &destination in &successors[offsets[source]..offsets[source + 1]] {
            let previous = values[destination];
            let next = previous.join(actual);
            if next != previous {
                values[destination] = next;
                if !queued[destination] {
                    queue.push(destination);
                    queued[destination] = true;
                }
            }
        }
    }
    let mut state = SolverState::new();
    for (formal, value) in formals.into_iter().zip(values) {
        assert!(state.absvals.insert(formal, value).is_none());
    }
    (
        state,
        SolverWork {
            dependencies,
            processed,
        },
    )
}

// Keep the original full-sweep solver as an opt-in pre-mutation oracle.
#[cfg(any(test, feature = "std"))]
fn solve_reference(
    summaries: &SecondaryMap<Block, BlockSummary<'_>>,
    postorder: &[Block],
    entry_block: Block,
) -> (SolverState, usize) {
    // Set up initial solver state
    let mut state = SolverState::new();

    for b in postorder.iter().rev().copied() {
        // For each block, get the formals
        if b == entry_block {
            continue;
        }
        let formals = summaries[b].formals;
        for formal in formals {
            let mb_old_absval = state.absvals.insert(*formal, AbstractValue::None);
            assert!(mb_old_absval.is_none());
        }
    }

    // Solve: repeatedly traverse the blocks in reverse postorder, until there
    // are no changes.
    let mut iter_no = 0;
    loop {
        iter_no += 1;
        let mut changed = false;

        for src in postorder.iter().rev().copied() {
            let src_summary = &summaries[src];
            for edge in &src_summary.dests {
                assert!(edge.block != entry_block);
                // By contrast, the dst block must have a summary.  Phase 1
                // will have only included an entry in `src_summary.dests` if
                // that branch/jump carried at least one parameter.  So the
                // dst block does take parameters, so it must have a summary.
                let dst_summary = &summaries[edge.block];
                let dst_formals = &dst_summary.formals;
                assert_eq!(edge.args.len(), dst_formals.len());
                for (formal, actual) in dst_formals.iter().zip(edge.args) {
                    // Find the abstract value for `actual`.  If it is a block
                    // formal parameter then the most recent abstract value is
                    // to be found in the solver state.  If not, then it's a
                    // real value defining point (not a phi), in which case
                    // return it itself.
                    let actual_absval = match actual {
                        BlockArg::Value(actual) => match state.maybe_get(*actual) {
                            Some(pt) => *pt,
                            None => AbstractValue::One(*actual),
                        },
                        _ => AbstractValue::Many,
                    };

                    // And `join` the new value with the old.
                    let formal_absval_old = state.get(*formal);
                    let formal_absval_new = formal_absval_old.join(actual_absval);
                    if formal_absval_new != formal_absval_old {
                        changed = true;
                        state.set(*formal, formal_absval_new);
                    }
                }
            }
        }

        if !changed {
            break;
        }
    }

    (state, iter_no)
}

/// Detect phis in `func` that will only ever produce one value, using a
/// classic forward dataflow analysis.  Then remove them.
#[inline(never)]
pub fn do_remove_constant_phis(func: &mut Function, domtree: &mut DominatorTree) {
    remove_constant_phis_with_solver(func, domtree, PhiSolver::Worklist);
}

enum PhiSolver {
    Worklist,
    #[cfg(test)]
    Reference,
}

#[inline(always)]
fn remove_constant_phis_with_solver(
    func: &mut Function,
    domtree: &mut DominatorTree,
    solver: PhiSolver,
) {
    let _tt = timing::remove_constant_phis();
    debug_assert!(domtree.is_valid());

    // Phase 1 of 3: for each block, make a summary containing all relevant
    // info.  The solver will iterate over the summaries, rather than having
    // to inspect each instruction in each block.
    let bump =
        Bump::with_capacity(domtree.cfg_postorder().len() * 4 * core::mem::size_of::<Value>());
    let mut summaries =
        SecondaryMap::<Block, BlockSummary>::with_capacity(domtree.cfg_postorder().len());

    for b in domtree.cfg_rpo().copied() {
        let formals = func.dfg.block_params(b);
        let mut summary = BlockSummary::new(&bump, formals);

        for inst in func.layout.block_insts(b) {
            for (ix, dest) in func.dfg.insts[inst]
                .branch_destination(&func.dfg.jump_tables, &func.dfg.exception_tables)
                .iter()
                .enumerate()
            {
                if let Some(edge) = OutEdge::new(&bump, &func.dfg, inst, ix, *dest) {
                    summary.dests.push(edge);
                }
            }
        }

        // Ensure the invariant that all blocks (except for the entry) appear
        // in the summary, *unless* they have neither formals nor any
        // param-carrying branches/jumps.
        if formals.len() > 0 || summary.dests.len() > 0 {
            summaries[b] = summary;
        }
    }

    // Phase 2 of 3: propagate `AbstractValue`s through formal dependencies.
    // The set of
    // tracked `Value`s is exactly Group A as described above.

    let entry_block = func
        .layout
        .entry_block()
        .expect("remove_constant_phis: entry block unknown");

    let (state, work) = match solver {
        PhiSolver::Worklist => solve_worklist(&summaries, domtree.cfg_postorder(), entry_block),
        #[cfg(test)]
        PhiSolver::Reference => {
            let (state, iterations) =
                solve_reference(&summaries, domtree.cfg_postorder(), entry_block);
            (
                state,
                SolverWork {
                    dependencies: 0,
                    processed: iterations,
                },
            )
        }
    };
    #[cfg(feature = "std")]
    {
        static VERIFY: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
        if *VERIFY.get_or_init(|| std::env::var_os("MECH_VERIFY_CONSTANT_PHI_SOLVER").is_some()) {
            let (reference, iterations) =
                solve_reference(&summaries, domtree.cfg_postorder(), entry_block);
            assert!(
                state.absvals == reference.absvals,
                "constant-phi solver maps differ"
            );
            std::eprintln!(
                "constant-phi-oracle: formals={} dependencies={} processed={} reference_iterations={}",
                state.absvals.len(),
                work.dependencies,
                work.processed,
                iterations
            );
        }
    }

    let mut n_consts = 0;
    for absval in state.absvals.values() {
        if absval.is_one() {
            n_consts += 1;
        }
    }

    // Phase 3 of 3: edit the function to remove constant formals, using the
    // summaries and the final solver state as a guide.

    // Make up a set of blocks that need editing.
    let mut need_editing = FxHashSet::<Block>::default();
    for (block, summary) in summaries.iter() {
        if block == entry_block {
            continue;
        }
        for formal in summary.formals {
            let formal_absval = state.get(*formal);
            if formal_absval.is_one() {
                need_editing.insert(block);
                break;
            }
        }
    }

    // Firstly, deal with the formals.  For each formal which is redundant,
    // remove it, and also add a reroute from it to the constant value which
    // it we know it to be.
    for b in &need_editing {
        let mut del_these = SmallVec::<[(Value, Value); 32]>::new();
        let formals: &[Value] = func.dfg.block_params(*b);
        for formal in formals {
            // The state must give an absval for `formal`.
            if let AbstractValue::One(replacement_val) = state.get(*formal) {
                del_these.push((*formal, replacement_val));
            }
        }
        // We can delete the formals in any order.  However,
        // `remove_block_param` works by sliding backwards all arguments to
        // the right of the value it is asked to delete.  Hence when removing more
        // than one formal, it is significantly more efficient to ask it to
        // remove the rightmost formal first, and hence this `rev()`.
        for (redundant_formal, replacement_val) in del_these.into_iter().rev() {
            func.dfg.remove_block_param(redundant_formal);
            func.dfg.change_to_alias(redundant_formal, replacement_val);
        }
    }

    // Secondly, visit all branch insns.  If the destination has had its
    // formals changed, change the actuals accordingly.  Don't scan all insns,
    // rather just visit those as listed in the summaries we prepared earlier.
    let mut old_actuals = alloc::vec::Vec::new();
    for summary in summaries.values() {
        for edge in &summary.dests {
            if !need_editing.contains(&edge.block) {
                continue;
            }

            let dfg = &mut func.dfg;
            let dests = dfg.insts[edge.inst]
                .branch_destination_mut(&mut dfg.jump_tables, &mut dfg.exception_tables);
            let block = &mut dests[edge.branch_index as usize];

            old_actuals.extend(block.args(&dfg.value_lists));

            // Check that the numbers of arguments make sense.
            let formals = &summaries[edge.block].formals;
            assert_eq!(formals.len(), old_actuals.len());

            // Filter out redundant block arguments.
            let mut formals = formals.iter();
            old_actuals.retain(|_| {
                let formal_i = formals.next().unwrap();
                !state.get(*formal_i).is_one()
            });

            // Replace the block with a new one that only includes the non-redundant arguments.
            // This leaks the value list from the old block,
            // https://github.com/bytecodealliance/wasmtime/issues/5451 for more information.
            let destination = block.block(&dfg.value_lists);
            *block = BlockCall::new(destination, old_actuals.drain(..), &mut dfg.value_lists);
        }
    }

    log::debug!(
        "do_remove_constant_phis: done, {} work items on {} dependencies.   {} formals, of which {} const.",
        work.processed,
        work.dependencies,
        state.absvals.len(),
        n_consts
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cursor::{Cursor, FuncCursor};
    use crate::flowgraph::ControlFlowGraph;
    use crate::ir::{AbiParam, InstBuilder, types};
    use alloc::vec::Vec;

    fn summaries<'a>(
        bump: &'a Bump,
        formals: &[Vec<Value>],
        edges: &[(usize, usize, Vec<BlockArg>)],
    ) -> (SecondaryMap<Block, BlockSummary<'a>>, Vec<Block>) {
        let blocks: Vec<_> = (0..formals.len())
            .map(|index| Block::from_u32((index * 3 + 7) as u32))
            .collect();
        let mut summaries = SecondaryMap::new();
        for (block, formals) in blocks.iter().zip(formals) {
            summaries[*block] = BlockSummary::new(bump, formals);
        }
        for (index, (source, destination, args)) in edges.iter().enumerate() {
            summaries[blocks[*source]].dests.push(OutEdge {
                inst: Inst::from_u32(index as u32),
                branch_index: 0,
                block: blocks[*destination],
                args: bump.alloc_slice_copy(args),
            });
        }
        (summaries, blocks)
    }

    // An independent interpretation: walk each formal's incoming graph and
    // collect defining roots. This has no forward lattice iteration or queue.
    fn roots_oracle(
        summaries: &SecondaryMap<Block, BlockSummary<'_>>,
        blocks: &[Block],
    ) -> FxHashMap<Value, AbstractValue> {
        let mut incoming = FxHashMap::<Value, Vec<BlockArg>>::default();
        for &block in &blocks[1..] {
            for &formal in summaries[block].formals {
                incoming.insert(formal, Vec::new());
            }
        }
        for &block in blocks {
            for edge in &summaries[block].dests {
                for (&formal, &actual) in summaries[edge.block].formals.iter().zip(edge.args) {
                    incoming.get_mut(&formal).unwrap().push(actual);
                }
            }
        }
        incoming
            .keys()
            .map(|&formal| {
                let mut seen = FxHashSet::default();
                let mut roots = FxHashSet::default();
                let mut pending = alloc::vec![BlockArg::Value(formal)];
                let mut opaque = false;
                while let Some(actual) = pending.pop() {
                    match actual {
                        BlockArg::Value(value) => {
                            if !seen.insert(value) {
                                continue;
                            }
                            if let Some(actuals) = incoming.get(&value) {
                                pending.extend(actuals);
                            } else {
                                roots.insert(value);
                            }
                        }
                        _ => opaque = true,
                    }
                }
                let value = if opaque || roots.len() > 1 {
                    AbstractValue::Many
                } else if let Some(&root) = roots.iter().next() {
                    AbstractValue::One(root)
                } else {
                    AbstractValue::None
                };
                (formal, value)
            })
            .collect()
    }

    fn compare_graph(formals: &[Vec<Value>], edges: &[(usize, usize, Vec<BlockArg>)]) {
        let bump = Bump::new();
        let (summaries, blocks) = summaries(&bump, formals, edges);
        let postorder: Vec<_> = blocks.iter().rev().copied().collect();
        let (actual, work) = solve_worklist(&summaries, &postorder, blocks[0]);
        let (reference, _) = solve_reference(&summaries, &postorder, blocks[0]);
        assert_eq!(actual.absvals, reference.absvals);
        assert_eq!(actual.absvals, roots_oracle(&summaries, &blocks));
        assert!(work.processed <= 2 * actual.absvals.len());
    }

    #[test]
    fn unseeded_cycles_duplicates_conflicts_and_exception_arguments() {
        let value = |n| Value::from_u32(n);
        let formals: Vec<_> = (0..7).map(|n| alloc::vec![value(100 + n)]).collect();
        let edges = alloc::vec![
            (1, 2, alloc::vec![value(101).into()]),
            (2, 1, alloc::vec![value(102).into()]),
            (0, 3, alloc::vec![value(100).into()]),
            (0, 3, alloc::vec![value(100).into()]),
            (3, 3, alloc::vec![value(103).into()]),
            (0, 4, alloc::vec![value(100).into()]),
            (3, 4, alloc::vec![value(999).into()]),
            (0, 5, alloc::vec![BlockArg::TryCallRet(0)]),
            (5, 6, alloc::vec![value(105).into()]),
            (0, 6, alloc::vec![BlockArg::TryCallExn(1)]),
        ];
        compare_graph(&formals, &edges);
        let bump = Bump::new();
        let (summaries, blocks) = summaries(&bump, &formals, &edges);
        let postorder: Vec<_> = blocks.iter().rev().copied().collect();
        let (actual, _) = solve_worklist(&summaries, &postorder, blocks[0]);
        assert_eq!(actual.get(value(101)), AbstractValue::None);
        assert_eq!(actual.get(value(102)), AbstractValue::None);
        assert_eq!(actual.get(value(103)), AbstractValue::One(value(100)));
        for formal in 104..107 {
            assert_eq!(actual.get(value(formal)), AbstractValue::Many);
        }
    }

    #[test]
    fn sparse_generated_graphs_match_both_independent_oracles() {
        fn next(state: &mut u64) -> usize {
            *state ^= *state << 13;
            *state ^= *state >> 7;
            *state ^= *state << 17;
            (*state >> 16) as usize
        }
        for seed in 1..=512u64 {
            let mut state = seed;
            let count = 2 + next(&mut state) % 31;
            let formals: Vec<Vec<Value>> = (0..count)
                .map(|block| {
                    (0..1 + next(&mut state) % 4)
                        .map(|slot| Value::from_u32((10_000 + block * 19 + slot * 2) as u32))
                        .collect()
                })
                .collect();
            let mut edges = Vec::new();
            for source in 0..count {
                for _ in 0..next(&mut state) % 4 {
                    let destination = 1 + next(&mut state) % (count - 1);
                    let args = formals[destination]
                        .iter()
                        .map(|_| match next(&mut state) % 13 {
                            0 => BlockArg::TryCallRet(0),
                            1 => BlockArg::TryCallExn(0),
                            2 => Value::from_u32(200_000).into(),
                            3 => Value::from_u32(200_001).into(),
                            _ => {
                                let block = next(&mut state) % count;
                                formals[block][next(&mut state) % formals[block].len()].into()
                            }
                        })
                        .collect();
                    edges.push((source, destination, args));
                }
            }
            compare_graph(&formals, &edges);
        }
    }

    #[test]
    fn reverse_chain_propagates_once_instead_of_repeated_full_sweeps() {
        let count = 256;
        let formals: Vec<_> = (0..count)
            .map(|n| alloc::vec![Value::from_u32(n as u32)])
            .collect();
        let mut edges = alloc::vec![(0, count - 1, alloc::vec![formals[0][0].into()])];
        for source in 2..count {
            edges.push((source, source - 1, alloc::vec![formals[source][0].into()]));
        }
        let bump = Bump::new();
        let (summaries, blocks) = summaries(&bump, &formals, &edges);
        let postorder: Vec<_> = blocks.iter().rev().copied().collect();
        let (actual, work) = solve_worklist(&summaries, &postorder, blocks[0]);
        let (reference, iterations) = solve_reference(&summaries, &postorder, blocks[0]);
        assert_eq!(actual.absvals, reference.absvals);
        assert_eq!(work.processed, count - 1);
        assert!(iterations >= count - 2);
    }

    fn loop_function(seed: usize) -> Function {
        let mut func = Function::new();
        func.signature.params = alloc::vec![
            AbiParam::new(types::I64),
            AbiParam::new(types::I64),
            AbiParam::new(types::I32),
        ];
        func.signature.returns = alloc::vec![AbiParam::new(types::I64)];
        let blocks: Vec<_> = (0..7).map(|_| func.dfg.make_block()).collect();
        let left = func.dfg.append_block_param(blocks[0], types::I64);
        let right = func.dfg.append_block_param(blocks[0], types::I64);
        let cond = func.dfg.append_block_param(blocks[0], types::I32);
        let parameters: Vec<_> = (0..1 + seed % 9)
            .map(|_| func.dfg.append_block_param(blocks[3], types::I64))
            .collect();
        let result = func.dfg.append_block_param(blocks[5], types::I64);
        let unreachable = func.dfg.append_block_param(blocks[6], types::I64);
        let mut alias = left;
        for _ in 0..seed % 17 {
            let next = Value::from_u32(func.dfg.num_values() as u32);
            func.dfg.make_invalid_value_for_parser();
            func.dfg.make_value_alias_for_serialization(alias, next);
            alias = next;
        }
        let left_args: Vec<_> = parameters.iter().map(|_| alias.into()).collect();
        let right_args: Vec<_> = parameters
            .iter()
            .enumerate()
            .map(|(slot, _)| if slot % 3 == seed % 3 { right } else { alias }.into())
            .collect();
        let mut cursor = FuncCursor::new(&mut func);
        cursor.insert_block(blocks[0]);
        cursor.ins().brif(cond, blocks[1], &[], blocks[2], &[]);
        cursor.insert_block(blocks[1]);
        cursor.ins().jump(blocks[3], &left_args);
        cursor.insert_block(blocks[2]);
        cursor.ins().jump(blocks[3], &right_args);
        cursor.insert_block(blocks[3]);
        cursor
            .ins()
            .brif(cond, blocks[4], &[], blocks[5], &[parameters[0].into()]);
        cursor.insert_block(blocks[4]);
        let mut back: Vec<_> = parameters.iter().map(|&v| BlockArg::Value(v)).collect();
        if seed % 2 == 0 {
            let constant = cursor.ins().iconst(types::I64, 1);
            back[0] = cursor.ins().iadd(parameters[0], constant).into();
        }
        cursor.ins().jump(blocks[3], &back);
        cursor.insert_block(blocks[5]);
        cursor.ins().return_(&[result]);
        cursor.insert_block(blocks[6]);
        cursor.ins().jump(blocks[6], &[unreachable.into()]);
        func
    }

    #[test]
    fn complete_post_pass_ir_and_aliases_match_on_loops_and_unreachable_blocks() {
        let flags = crate::settings::Flags::new(crate::settings::builder());
        for seed in 0..72 {
            let original = loop_function(seed);
            crate::verify_function(&original, &flags).unwrap();
            let mut candidate = original.clone();
            let mut reference = original;
            let cfg = ControlFlowGraph::with_function(&candidate);
            let mut dom = DominatorTree::with_function(&candidate, &cfg);
            let reference_cfg = ControlFlowGraph::with_function(&reference);
            let mut reference_dom = DominatorTree::with_function(&reference, &reference_cfg);
            do_remove_constant_phis(&mut candidate, &mut dom);
            remove_constant_phis_with_solver(
                &mut reference,
                &mut reference_dom,
                PhiSolver::Reference,
            );
            crate::verify_function(&candidate, &flags).unwrap();
            crate::verify_function(&reference, &flags).unwrap();
            assert_eq!(
                alloc::format!("{}", candidate.display()),
                alloc::format!("{}", reference.display()),
                "seed={seed}"
            );
            assert_eq!(candidate.dfg.num_values(), reference.dfg.num_values());
            for value in candidate.dfg.values() {
                assert_eq!(
                    candidate.dfg.resolve_aliases(value),
                    reference.dfg.resolve_aliases(value)
                );
                assert_eq!(
                    candidate.dfg.value_def(value),
                    reference.dfg.value_def(value)
                );
            }
        }
    }
}
