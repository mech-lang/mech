extern crate alloc;
pub use cranelift_codegen::{dominator_tree, ir, timing, FxHashMap, FxHashSet, cursor, flowgraph, settings, verify_function};
#[allow(dead_code)]
#[path = "/Users/cim310/.codex/worktrees/level12-compile-profile/mech/vendor/cranelift-codegen/src/remove_constant_phis.rs"]
mod production;
