#![no_std]
extern crate alloc;
pub use cranelift_codegen::{dominator_tree, ir, timing, FxHashMap, FxHashSet};
#[path = "/Users/cim310/.codex/worktrees/level12-compile-profile/mech/vendor/cranelift-codegen/src/remove_constant_phis.rs"]
pub mod production;
