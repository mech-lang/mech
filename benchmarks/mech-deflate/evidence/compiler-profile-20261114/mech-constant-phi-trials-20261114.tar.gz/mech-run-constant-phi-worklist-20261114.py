from pathlib import Path
import hashlib, json, os, re, subprocess, sys

root = Path('/private/tmp/mech-constant-phi-worklist-20261114')
variant, name = sys.argv[1:3]
oracle = len(sys.argv) > 3 and sys.argv[3] == 'oracle'
assert not oracle or variant == 'candidate'
flags = json.loads((root/'runtime-flags.json').read_text())
assert len(flags) == 61
env = {k:v for k,v in os.environ.items() if not k.startswith('MECH_')}
env.update(flags)
env['MECH_COMPACT_COMPILE_THREADS'] = '2'
if oracle: env['MECH_VERIFY_CONSTANT_PHI_SOLVER'] = '1'
assert not (root/name).exists()
command = [sys.executable,'benchmarks/mech-deflate/native-profile/profile_compile.py',str(root/variant),'benchmark',str(root/name),'compact']
(root/(name+'-command.json')).write_text(json.dumps(dict(command=command,flags={k:v for k,v in env.items() if k.startswith('MECH_')},binary_sha256=hashlib.sha256((root/variant).read_bytes()).hexdigest(),compile_threads=2,program_flags_count=61,profiling_excluded_from_primary=oracle),indent=2)+'\n')
completed = subprocess.run(command,env=env)
assert completed.returncode == 0
checks = {}
for filename in ['source.mec','program.mecb','program.o','metadata.json']:
    data = (root/name/filename).read_bytes()
    checks[filename] = dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),matches_current_control_output=data==(root/'reference'/filename).read_bytes())
(root/name/'output-check.json').write_text(json.dumps(checks,indent=2)+'\n')
print('OUTPUTS',name,json.dumps(checks),flush=True)
assert all(r['matches_current_control_output'] for r in checks.values())
profiles=[]
for line in (root/name/'stderr.log').read_text().splitlines():
    match=re.fullmatch(r'constant-phi-oracle: formals=(\d+) dependencies=(\d+) processed=(\d+) reference_iterations=(\d+)',line)
    if match:profiles.append(dict(zip(['formals','dependencies','processed','reference_iterations'],map(int,match.groups()))))
if oracle:
    assert profiles
    (root/name/'constant-phi-profiles.json').write_text(json.dumps(profiles,indent=2)+'\n')
    print('ORACLE_CALLS',len(profiles),flush=True)
else: assert not profiles
