from pathlib import Path
import hashlib, json, os, shutil, subprocess, time

repo = Path.cwd()
root = Path('/private/tmp/mech-constant-phi-worklist-20261114')
state = json.loads((root / 'source-state.json').read_text())
source = repo / state['source_path']
patch = subprocess.check_output(['git','diff','--binary','--',state['source_path']])
assert subprocess.check_output(['git','diff','--name-only'],text=True).splitlines() == [state['source_path']]
assert source.read_bytes() == (root / 'candidate.rs').read_bytes()
assert patch == (root / 'candidate.patch').read_bytes()
pin = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

# Check the exact pass's production cfg with no std imports in this crate.
# Dependencies are the already built std Cranelift API: this is a module-level
# no_std/configuration check, not a whole-Cranelift no_std feature build.
harness = root / 'no_std_module.rs'
harness.write_text('#![no_std]\nextern crate alloc;\npub use cranelift_codegen::{dominator_tree, ir, timing, FxHashMap, FxHashSet};\n#[path = ' + json.dumps(str(source)) + ']\npub mod production;\n')
test = json.loads((root / 'focused-tests-command.json').read_text())
command = ['rustc','+nightly-2026-03-03','--crate-name','constant_phi_no_std_module','--edition=2024','--crate-type=rlib','--emit=metadata',str(harness),'-D','warnings','-L','dependency=/private/tmp/mech-level12-compile-target/compiler/deps','-o',str(root/'no-std-module.rmeta')]
for item in test['dependencies']:
    path = Path(item['path'])
    assert pin(path) == item['sha256']
    name = path.name[3:].split('-')[0]
    command += ['--extern', name + '=' + str(path)]
started = time.perf_counter()
with (root/'no-std-module.stdout.log').open('w') as stdout, (root/'no-std-module.stderr.log').open('w') as stderr:
    completed = subprocess.run(command,stdout=stdout,stderr=stderr)
record = dict(command=command,exit_code=completed.returncode,seconds=time.perf_counter()-started,scope='Exact production module cfg without std; dependencies retain the pinned std Cranelift public API. Not a whole-library no_std build.')
(root/'no-std-module.json').write_text(json.dumps(record,indent=2)+'\n')
assert completed.returncode == 0

env = dict(os.environ,CARGO_TARGET_DIR='/private/tmp/mech-level12-compile-target',CARGO_INCREMENTAL='0')
for stage in ['check','build']:
    assert source.read_bytes() == (root/'candidate.rs').read_bytes()
    command = ['cargo',stage,'--locked','--offline','--profile','compiler','-j4','--manifest-path','benchmarks/mech-deflate/native-profile/Cargo.toml','--bin','compile_profile','--message-format=json']
    started = time.perf_counter()
    with (root/('candidate-'+stage+'.jsonl')).open('w') as stdout, (root/('candidate-'+stage+'.stderr')).open('w') as stderr:
        completed = subprocess.run(command,cwd=repo,env=env,stdout=stdout,stderr=stderr)
    record = dict(command=command,head=state['base_commit'],patch_sha256=pin(root/'candidate.patch'),seconds=time.perf_counter()-started,exit_code=completed.returncode,CARGO_TARGET_DIR=env['CARGO_TARGET_DIR'],CARGO_INCREMENTAL='0')
    if completed.returncode == 0 and stage == 'build':
        rows = [json.loads(line) for line in (root/'candidate-build.jsonl').read_text().splitlines()]
        binaries = [r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='compile_profile' and r.get('executable')]
        assert len(binaries) == 1
        shutil.copy2(binaries[0],root/'candidate')
        record.update(binary=str(root/'candidate'),binary_sha256=pin(root/'candidate'))
    (root/('candidate-'+stage+'.json')).write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record),flush=True)
    if completed.returncode: raise SystemExit(completed.returncode)
assert source.read_bytes() == (root/'candidate.rs').read_bytes()
assert subprocess.check_output(['git','diff','--binary','--',state['source_path']]) == patch
