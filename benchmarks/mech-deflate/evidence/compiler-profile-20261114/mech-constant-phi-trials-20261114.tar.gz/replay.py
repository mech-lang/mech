from pathlib import Path
from collections import Counter
import hashlib, json, re, statistics

packet = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_text())
cached = {}
def pin(path):
    if path not in cached:
        cached[path] = dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    return cached[path]

def apply_patch(base, patch):
    lines=base.splitlines(keepends=True);out=[];cursor=0;diff=patch.splitlines(keepends=True);i=0
    assert sum(line.startswith('diff --git ') for line in diff)==1
    while i<len(diff):
        match=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',diff[i])
        if not match:i+=1;continue
        at=int(match[1]) if int(match[2] or 1)==0 else int(match[1])-1
        assert at>=cursor
        out.extend(lines[cursor:at]);cursor=at;old_count=0;new_count=0;i+=1
        while i<len(diff) and not diff[i].startswith('@@ '):
            line=diff[i];tag=line[:1];assert tag in [' ','+','-']
            if tag in [' ','-']:assert lines[cursor]==line[1:];cursor+=1;old_count+=1
            if tag in [' ','+']:out.append(line[1:]);new_count+=1
            i+=1
        assert old_count==int(match[2] or 1) and new_count==int(match[4] or 1)
    out.extend(lines[cursor:]);return ''.join(out)

state=read(packet/'source-state.json');decisions=read(packet/'decisions.json')
assert state['base_commit']==decisions['base_commit']=='ab59d593f4dcc3e457d8c462b459f60eaf80851e'
assert state['retained_trial']==decisions['retained_trial']
assert state['source_path']=='vendor/cranelift-codegen/src/remove_constant_phis.rs'
assert state['program_flags_count']==61 and state['common_compile_threads']==2
excluded={r['path']:r for r in read(packet/'excluded-compiler-products.json')}
prior=read(packet/'validation/prior-qualified.json')
assert pin(packet/'validation/prior-qualified.json')['sha256']==read(packet/'validation/prior-qualified.archive.json')['replay_sha256']
expected=prior['output_hashes']
for row in read(packet/'source-config-pins.json'):
    assert pin(packet/'source-config'/row['path'])=={k:row[k] for k in ['bytes','sha256']}
inputs=read(packet/'native-link-inputs.json')
for row in inputs:assert pin(packet/row['path'])=={k:row[k] for k in ['bytes','sha256']}
order=[('control','control-1'),('candidate','candidate-1'),('candidate','candidate-2'),('control','control-2'),('candidate','candidate-3'),('control','control-3'),('control','control-4'),('candidate','candidate-4')]
exe=dict(bytes=1878568,sha256='557d0f5ef2b979e01851ae23b5b3944453a0bd9e772d68161be198916ca06c2c')

def replay_trial(name):
    root=packet/'trials'/name
    raw_state=read(root/'source-state.json')
    assert raw_state['base_commit']==state['base_commit']
    assert raw_state['source_path']==state['source_path']
    assert pin(root/'candidate.patch')['sha256']==raw_state['patch_sha256']
    assert pin(root/'candidate.rs')['sha256']==raw_state['production_module_sha256']
    original=(root/'reference.rs').read_text();candidate=(root/'candidate.rs').read_text()
    assert apply_patch(original,(root/'candidate.patch').read_text())==candidate
    sections=read(root/'unchanged-pass-sections.json')
    for section,begin,end in [('summary_construction','    // Phase 1 of 3:','    // Phase 2 of 3:'),('ir_edits','    // Phase 3 of 3:','    log::debug!(')]:
        old=original[original.index(begin):original.index(end,original.index(begin))]
        new=candidate[candidate.index(begin):candidate.index(end,candidate.index(begin))]
        assert old==new and sections[section]==dict(byte_identical=True,reference_sha256=hashlib.sha256(old.encode()).hexdigest(),candidate_sha256=hashlib.sha256(new.encode()).hexdigest())
    binaries={v:excluded['trials/'+name+'/'+v]['sha256'] for v in ['control','candidate']}
    assert binaries['control']==prior['compiler_binary_sha256']['candidate']==raw_state['control_binary_sha256']
    build=read(root/'candidate-build.json');check=read(root/'candidate-check.json')
    for record in [check,build]:
        assert record['exit_code']==0 and record['head']==state['base_commit'] and record['patch_sha256']==raw_state['patch_sha256']
        assert record['CARGO_INCREMENTAL']=='0'
    assert build['binary_sha256']==binaries['candidate']
    tests=read(root/'focused-tests.json');test_build=read(root/'focused-tests-build.json');test_command=read(root/'focused-tests-command.json')
    assert tests['exit_code']==test_build['exit_code']==0
    assert test_build['binary_sha256']==excluded['trials/'+name+'/constant-phi-tests']['sha256']
    assert test_command['production_module_sha256']==pin(root/'candidate.rs')['sha256']
    assert 'test result: ok. 4 passed; 0 failed' in (root/'focused-tests.stdout.log').read_text()
    assert 'for seed in 1..=512u64' in candidate and 'for seed in 0..72' in candidate
    no_std=read(root/'no-std-module.json');assert no_std['exit_code']==0 and 'Not a whole-library no_std build.' in no_std['scope']
    flags=read(root/'runtime-flags.json');assert len(flags)==61 and flags['MECH_COMPACT_REUSE_OVERWRITTEN_RESULT']=='1'
    wanted=dict(flags,MECH_COMPACT_COMPILE_THREADS='2')
    assert read(root/'reference-pins.json')==expected
    for filename,item in expected.items():assert pin(root/'reference'/filename)==item
    rows=[];screens=[]
    for variant,label in [('control','control-screen'),('candidate','oracle-screen'),('candidate','candidate-screen')]+order:
        directory=root/label;command=read(root/(label+'-command.json'));oracle=label=='oracle-screen'
        assert command['flags']==dict(wanted,**({'MECH_VERIFY_CONSTANT_PHI_SOLVER':'1'} if oracle else {}))
        assert command['compile_threads']==2 and command['program_flags_count']==61 and command['profiling_excluded_from_primary']==oracle
        assert command['binary_sha256']==binaries[variant]
        process=read(directory/'process.json');compile=read(directory/'compile.json');checks=read(directory/'output-check.json')
        assert process['exit_code']==0 and process['samples']==0 and process['sampling_error'] is None
        assert process['elapsed_boundary']=='driver_start_to_process_wait_completion' and process['elapsed_seconds']>compile['total_seconds']
        for filename,item in expected.items():
            assert pin(directory/filename)==item and checks[filename]==dict(item,matches_current_control_output=True)
        row=dict(name=label,variant=variant,compile=compile,process=process,files=checks)
        if label.endswith('-screen'):
            screens.append(row);continue
        stamps=[json.loads(line) for line in (directory/'stages.jsonl').read_text().splitlines()]
        elapsed=lambda prefix:next(s['elapsed'] for s in stamps if s['line'].startswith(prefix))
        for key,begin,end in [('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]:row[key]=elapsed(end)-elapsed(begin)
        log=(directory/'stderr.log').read_text()
        assert 'constant-phi-oracle:' not in log
        for key,pattern in [('instructions',r'(\d+)  instructions retired'),('max_rss_bytes',r'(\d+)  maximum resident set size'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]:row[key]=int(re.search(pattern,log).group(1))
        row['compaction_seconds']=elapsed('compact-stage: CFG cleanup')-elapsed('compact-stage: compact values before=')
        row['cleanup_including_compaction_seconds']=row['cleanup_seconds']+row['compaction_seconds']
        for key,prefix in [('value_ids_before','compact-stage: compact values before='),('value_ids_after','compact-values: retained=')]:row[key]=int(next(s['line'] for s in stamps if s['line'].startswith(prefix)).split('=')[-1])
        assert (row['value_ids_before'],row['value_ids_after'])==(20798230,1242559)
        rows.append(row)
    assert rows==read(root/'cohort.json')
    fields={'compiler_seconds':lambda r:r['compile']['total_seconds'],'whole_process_seconds':lambda r:r['process']['elapsed_seconds']}
    for phase in ['parse','catalog','frontend','artifact','encode','native']:fields[phase+'_seconds']=lambda r,p=phase:next(x['seconds'] for x in r['compile']['phases'] if x['phase']==p)
    for key in ['canonical_lowering_seconds','preparation_seconds','numeric_generation_seconds','source_cfg_seconds','cleanup_including_compaction_seconds','cleanup_seconds','compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:fields[key]=lambda r,k=key:r[k]
    numerical={}
    for key,fn in fields.items():
        values={v:[fn(r) for r in rows if r['variant']==v] for v in ['control','candidate']}
        values['mean_reduction_fraction']=1-statistics.mean(values['candidate'])/statistics.mean(values['control'])
        numerical[key]=values
    assert numerical==read(root/'numerical-summary.json')
    blocks=[]
    for subset in [rows[:4],rows[4:]]:
        block={}
        for key in ['compiler_seconds','whole_process_seconds','cleanup_including_compaction_seconds','instructions']:
            means={v:statistics.mean(fields[key](r) for r in subset if r['variant']==v) for v in ['control','candidate']}
            block[key]=dict(means,mean_reduction_fraction=1-means['candidate']/means['control'])
        blocks.append(block)
    profiles=[]
    for line in (root/'oracle-screen/stderr.log').read_text().splitlines():
        match=re.fullmatch(r'constant-phi-oracle: formals=(\d+) dependencies=(\d+) processed=(\d+) reference_iterations=(\d+)',line)
        if match:profiles.append(dict(zip(['formals','dependencies','processed','reference_iterations'],map(int,match.groups()))))
    assert profiles==read(root/'oracle-screen/constant-phi-profiles.json') and len(profiles)==1782
    assert all(r['processed']<=2*r['formals'] and r['reference_iterations']>=1 for r in profiles)
    oracle=dict(calls=len(profiles),totals={k:sum(r[k] for r in profiles) for k in profiles[0]},reference_iteration_distribution={str(k):v for k,v in sorted(Counter(r['reference_iterations'] for r in profiles).items())})
    assert oracle['totals']==dict(formals=1744572,dependencies=2826224,processed=2887809,reference_iterations=4982)
    fixtures=read(root/'fixture-results.json');assert len(fixtures)==14
    for row in fixtures:
        filename=row['fixture'];fixture=filename.split(':')[-1] if ':' in filename else Path(filename).stem
        assert pin(root/'fixture-inputs'/(fixture+'.mec'))['sha256']==row['source_sha256']
        assert row['all_outputs_match'] and row['variants']['control']==row['variants']['candidate']
        for variant in ['control','candidate']:
            directory=root/'fixtures'/fixture/variant;command=read(directory/'command.json')
            assert command['flags']==wanted and command['binary_sha256']==binaries[variant]
            assert row['variants'][variant]['exit_code']==0 and len(row['variants'][variant]['files'])==4
            for filename,item in row['variants'][variant]['files'].items():assert pin(directory/filename)==item
    links=read(root/'final-executable-results.json');assert len(links)==2
    for variant,row in zip(['control','candidate'],links):
        directory=root/('link-'+variant);command=read(directory/'command.json')
        assert row['variant']==variant and row['exit_code']==0 and row['matches_complete_baseline_executable'] and not row['fresh_runtime_campaign']
        assert pin(directory/'worker')==exe==dict(bytes=row['executable_bytes'],sha256=row['executable_sha256'])
        assert read(directory/'result.json')==row and command['environment']=={'ZERO_AR_DATE':'1'}
        assert [(r['source'],r['bytes'],r['sha256']) for r in command['input_pins']]==[(r['source'],r['bytes'],r['sha256']) for r in inputs]
    failures=[]
    if name=='hashmap-rebuild':
        for attempt in ['first','second']:
            directory=root/('focused-harness-'+attempt+'-attempt')
            failed=read(directory/'focused-tests-build.json')
            assert failed['exit_code']==1
            log=(directory/'focused-tests-build.stderr.log').read_text()
            if attempt=='first':assert 'cannot find module or crate `log`' in log
            else:assert 'could not parse bitcode object file' in log and 'LLVM version 15.0.0' in log
            failures.append(dict(attempt=attempt,build=failed,reason=read(directory/'reason.json')))
    native_summary=None
    if (root/'native-cohort.json').exists():
        native=read(root/'native-cohort.json');native_order=[(v,'native-'+label) for v,label in order]
        assert [(r['variant'],r['name']) for r in native]==native_order
        for row in native:
            directory=root/row['name'];actual=read(directory/'result.json');command=read(directory/'command.json')
            assert actual=={k:v for k,v in row.items() if k!='name'}
            assert row['primary_cohort'] and row['cached_adapter_objects'] and row['compiler_exit_code']==row['link_exit_code']==0
            assert row['matches_complete_baseline_executable'] and pin(directory/'worker')==exe
            assert abs(row['source_to_executable_seconds']-sum(row[k] for k in ['source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']))<1e-8
            assert command['flags']==wanted and command['compiler_sha256']==binaries[row['variant']] and command['ZERO_AR_DATE']=='1'
            assert read(root/(row['name']+'-observation.json'))==[actual]
            for filename,item in expected.items():
                assert pin(directory/filename)==item and row['files'][filename]==dict(item,matches_frozen_reference=True)
        native_numerical={}
        for key in ['source_to_executable_seconds','source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']:
            values={v:[r[key] for r in native if r['variant']==v] for v in ['control','candidate']}
            values['mean_reduction_fraction']=1-statistics.mean(values['candidate'])/statistics.mean(values['control'])
            native_numerical[key]=values
        native_blocks=[]
        for subset in [native[:4],native[4:]]:
            means={v:statistics.mean(r['source_to_executable_seconds'] for r in subset if r['variant']==v) for v in ['control','candidate']}
            means['mean_reduction_fraction']=1-means['candidate']/means['control'];native_blocks.append(means)
        native_summary=read(root/'native-numerical-summary.json')
        assert native_summary['numerical_summary']==native_numerical and native_summary['balanced_blocks']==native_blocks
        assert native_summary['order']==[list(r) for r in native_order]
    return dict(source_state=raw_state,compiler_binary_sha256=binaries,check=check,build=build,focused_tests=tests,focused_test_build=test_build,module_no_std_check=no_std,unchanged_pass_sections=sections,preliminary_screens=screens,numerical_summary=numerical,balanced_blocks=blocks,oracle=oracle,fixture_pairs=14,final_links=links,focused_harness_failures=failures,native_cohort=native_summary)

trials={name:replay_trial(name) for name in ['hashmap-rebuild','compact-index']}
assert (packet/'trials/hashmap-rebuild/reference.rs').read_bytes()==(packet/'trials/compact-index/reference.rs').read_bytes()
assert trials['hashmap-rebuild']['numerical_summary']['cleanup_including_compaction_seconds']['mean_reduction_fraction']<0
assert trials['hashmap-rebuild']['numerical_summary']['instructions']['mean_reduction_fraction']<0
assert decisions['trials']['hashmap-rebuild']['decision']=='rejected'
retained=state['retained_trial']
if retained:
    assert retained=='compact-index' and decisions['source_commit']==state['source_revision']
    selected=trials[retained]
    assert decisions['trials'][retained]['decision']=='retained'
    assert selected['native_cohort'] is not None
    for block in selected['balanced_blocks']:
        for key in ['compiler_seconds','cleanup_including_compaction_seconds','instructions']:
            assert block[key]['mean_reduction_fraction']>0
    assert selected['native_cohort']['numerical_summary']['source_to_executable_seconds']['mean_reduction_fraction']>0
else:
    assert decisions['source_commit'] is None and state['source_revision']==state['base_commit']
    assert decisions['trials']['compact-index']['decision']=='rejected'

summary=dict(
    base_commit=state['base_commit'],source_revision=state['source_revision'],
    retained_trial=retained,decisions=decisions,program_flags_count=61,common_compile_threads=2,
    output_hashes=expected,final_executable=exe,trials=trials,
    scope=[
        'Two constant-phi solver layouts compare with the same current production compiler on baseab59. Both subjects use the same61 program flags plus scheduling2; compiler PGO is disabled and its earlier frozen-source result remains separate.',
        'Each layout passes four focused tests:512 generated graphs against full-sweep and independent root-graph oracles,72 complete post-pass IR/alias comparisons, plus cycle/conflict/duplicate/exception/reverse-chain cases. The module no_std configuration check uses pinned std Cranelift APIs and is not a whole-library no_std build.',
        'Each full benchmark diagnostic matches1782 complete solver maps before mutation. Summary construction and IR edits are byte-identical to the original. Every source/bytecode/Object/metadata output,14fixture pairs per layout and both initial complete-executable gates match. No grammar/language change, weaker proof check, scalar retirement or fresh emitted-program runtime campaign is claimed.',
        'Each primary source-to-Object cohort contains eight serial ABBA/BAAB compiles with precise process completion and macOS instruction/memory counters. Diagnostics/screens, compiler checking/rebuilding and test builds are separate. Any retained layout also has eight balanced complete source-to-executable compiles with the fixed adapter cached. No concurrent heavy build/test/profile/hash/archive work runs during primary timing.',
        'The first layout is rejected: cleanup and instructions rise in both blocks despite slightly favorable whole-compiler means and mixed compiler blocks. Every raw observation and adverse stage/memory/block result remains. Two early direct-harness setup/link failures execute no tests and remain; production source is unchanged in their correction.',
        'Exact source snapshots/patches, commands, logs, raw timings, generated programs/executables and fixed native inputs are included. Compiler/test executables and compiler intermediates are excluded/SHA-pinned. Unchanged sources/toolchain/dependency cache are pinned rather than redistributed. Pure replay validates saved observations without rerunning builds or timings. The complete-compilation goal below ten seconds remains open.'
    ])
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n'
saved=packet/'summary.json'
if saved.exists():assert saved.read_text()==encoded
else:saved.write_text(encoded)
print(encoded,end='')
