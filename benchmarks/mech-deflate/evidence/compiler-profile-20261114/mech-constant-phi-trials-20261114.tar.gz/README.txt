Constant-phi propagation trials, 2026-11-14.
Both trials start at ab59d593f4dcc3e457d8c462b459f60eaf80851e and compare
against the same qualified production compiler. Both subjects use the same61
program flags and MECH_COMPACT_COMPILE_THREADS=2. PGO is not enabled in either
trial. The earlier frozen-source PGO result must remain separate.
The first layout builds a dependency graph and then rebuilds a final hash map.
The compact-index revision retains Value-to-u32 indices and vector states,
indexes destinations by their block range, and packs graph/queue node IDs.
The original full-sweep solver is an optional pre-mutation complete-map oracle;
one solver supplies production edits. Summary construction and the IR-editing
sections remain byte-identical. Four focused tests in each trial cover512
generated graphs against full-sweep and independent root-graph oracles,72
complete post-pass IR/alias comparisons, cycles, conflicts, duplicates,
exception arguments and a reverse chain. The direct harness pins production
Cranelift APIs. Its first two setup/link failures are preserved. A separate
module no_std cfg check uses std Cranelift dependencies; it is explicitly not
a whole-library no_std build.
Each full benchmark oracle run checks every tracked abstract value before IR
mutation. All source/bytecode/Object/metadata gates,14paired fixtures per trial
and both initial complete-executable link gates are included. Primary eight-run
source-to-Object cohorts run serially inABBA/BAAB order, with no concurrent heavy
builds, tests, profiling, hashing or archival. Diagnostics/screens are separate.
Any retained trial additionally has eight balanced full source-to-executable
builds with the same fixed adapter cached. The authoritative final choices and
any source commit are in decisions.json. Every adverse time/instruction/memory
observation remains; no grammar/language change, weaker proof check, scalar
retirement or fresh emitted-program runtime campaign is claimed.
All raw measurements, commands, source snapshots/patches, test outputs,
generated programs/executables and frozen native linker inputs are included.
Compiler/test executables and compiler intermediates are excluded/SHA-pinned.
Unchanged compiler source, toolchain and dependency cache are pinned rather
than redistributed. Pure replay checks saved evidence and calculations without
rerunning builds or timings. Sub-ten-second complete compilation remains open.
