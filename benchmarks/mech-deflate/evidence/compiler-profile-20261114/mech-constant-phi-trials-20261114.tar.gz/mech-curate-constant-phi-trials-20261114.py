from pathlib import Path
import hashlib, json, shutil, subprocess

repo = Path.cwd()
packet = Path('/private/tmp/mech-constant-phi-trials-packet-20261114')
assert not packet.exists()
decision_path = Path('/private/tmp/mech-constant-phi-decisions-20261114.json')
decisions = json.loads(decision_path.read_text())
base = 'ab59d593f4dcc3e457d8c462b459f60eaf80851e'
assert decisions['base_commit'] == base
packet.mkdir()
shutil.copy2(decision_path, packet / 'decisions.json')
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
excluded = []
roots = {
    'hashmap-rebuild': Path('/private/tmp/mech-constant-phi-worklist-20261114'),
    'compact-index': Path('/private/tmp/mech-constant-phi-indexed-20261114'),
}
for name, raw in roots.items():
    destroot = packet / 'trials' / name
    for source in sorted(raw.rglob('*')):
        if not source.is_file():
            continue
        relative = source.relative_to(raw)
        is_compiler = relative.as_posix() in ['control','candidate','constant-phi-tests']
        is_compiler |= source.suffix == '.rmeta' or source.name.endswith('.rcgu.o')
        if is_compiler:
            excluded.append(dict(path='trials/'+name+'/'+relative.as_posix(), **pin(source)))
            continue
        target = destroot / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
    for row in json.loads((destroot/'fixture-results.json').read_text()):
        filename = row['fixture']
        if filename.startswith('hosts/'):
            content = subprocess.check_output(['git','show',base+':'+filename])
            assert hashlib.sha256(content).hexdigest() == row['source_sha256']
            (destroot/'fixture-inputs'/Path(filename).name).write_bytes(content)
source_path = 'vendor/cranelift-codegen/src/remove_constant_phis.rs'
original = subprocess.check_output(['git','show',base+':'+source_path])
assert all((raw/'reference.rs').read_bytes() == original for raw in roots.values())
retained = decisions['retained_trial']
if retained:
    revision = decisions['source_commit']
    assert retained in roots
    assert subprocess.check_output(['git','diff','--binary',base,revision,'--',source_path]) == (roots[retained]/'candidate.patch').read_bytes()
else:
    revision = base
    assert (repo/source_path).read_bytes() == original
source_pins = []
for name in ['.cargo/config.toml','Cargo.toml','Cargo.lock','benchmarks/mech-deflate/native-profile/Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.lock','benchmarks/mech-deflate/native-profile/compile_profile.rs','benchmarks/mech-deflate/native-profile/profile_compile.py']:
    content = subprocess.check_output(['git','show',base+':'+name])
    target = packet/'source-config'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(content)
    source_pins.append(dict(path=name,**pin(target)))
(packet/'source-config-pins.json').write_text(json.dumps(source_pins,indent=2)+'\n')
prior = Path('/private/tmp/mech-round2-planning-packet-20261114')
for name in ['licenses','native-link-inputs']:
    shutil.copytree(prior/name,packet/name)
shutil.copy2(prior/'native-link-inputs.json',packet/'native-link-inputs.json')
validation = packet/'validation'
validation.mkdir()
for suffix in ['.json','.archive.json']:
    name = 'parallel-phases-compile-apple-m3-20261114'+suffix
    shutil.copy2(repo/'benchmarks/mech-deflate/native-profile'/name,validation/('prior-qualified'+suffix))
for source in sorted(Path('/private/tmp').glob('*constant-phi*20261114.py')):
    if source.name != 'mech-replay-constant-phi-trials-20261114.py':
        shutil.copy2(source,packet/source.name)
shutil.copy2('/private/tmp/mech-replay-constant-phi-trials-20261114.py',packet/'replay.py')
(packet/'excluded-compiler-products.json').write_text(json.dumps(excluded,indent=2)+'\n')
(packet/'source-state.json').write_text(json.dumps(dict(base_commit=base,source_revision=revision,source_path=source_path,retained_trial=retained,trials=list(roots),program_flags_count=61,common_compile_threads=2),indent=2)+'\n')
(packet/'README.txt').write_text('''Constant-phi propagation trials, 2026-11-14.
Both trials start at ab59d593f4dcc3e457d8c462b459f60eaf80851e and compare
against the same qualified production compiler. Both subjects use the same61
program flags and MECH_COMPACT_COMPILE_THREADS=2. PGO is not enabled in either
trial. The earlier frozen-source PGO result must remain separate.
The first layout builds a dependency graph and then rebuilds a final hash map.
The compact-index revision retains Value-to-u32 indices and vector states,
indexes destinations by their block range, and packs graph/queue node IDs.
The original full-sweep solver is an optional pre-mutation complete-map oracle;
one solver supplies production edits. Summary construction and the IR-editing
sections remain byte-identical. Four focused tests in each trial cover512
generated graphs against full-sweep and independent root-graph oracles,72
complete post-pass IR/alias comparisons, cycles, conflicts, duplicates,
exception arguments and a reverse chain. The direct harness pins production
Cranelift APIs. Its first two setup/link failures are preserved. A separate
module no_std cfg check uses std Cranelift dependencies; it is explicitly not
a whole-library no_std build.
Each full benchmark oracle run checks every tracked abstract value before IR
mutation. All source/bytecode/Object/metadata gates,14paired fixtures per trial
and both initial complete-executable link gates are included. Primary eight-run
source-to-Object cohorts run serially inABBA/BAAB order, with no concurrent heavy
builds, tests, profiling, hashing or archival. Diagnostics/screens are separate.
Any retained trial additionally has eight balanced full source-to-executable
builds with the same fixed adapter cached. The authoritative final choices and
any source commit are in decisions.json. Every adverse time/instruction/memory
observation remains; no grammar/language change, weaker proof check, scalar
retirement or fresh emitted-program runtime campaign is claimed.
All raw measurements, commands, source snapshots/patches, test outputs,
generated programs/executables and frozen native linker inputs are included.
Compiler/test executables and compiler intermediates are excluded/SHA-pinned.
Unchanged compiler source, toolchain and dependency cache are pinned rather
than redistributed. Pure replay checks saved evidence and calculations without
rerunning builds or timings. Sub-ten-second complete compilation remains open.
''')
print(packet)
