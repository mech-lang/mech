from pathlib import Path
import subprocess,sys,json
root=Path('/private/tmp/mech-constant-phi-worklist-20261114')
for name in ['mech-constant-phi-worklist-fixtures-20261114.py','mech-run-constant-phi-worklist-cohort-20261114.py']:
 subprocess.run([sys.executable,str(Path('/private/tmp')/name)],check=True)
rows=json.loads((root/'cohort.json').read_text());(root/'cohort-unexpanded.json').write_text(json.dumps(rows,indent=2)+'\n')
for name,block in [('first',rows[:4]),('second',rows[4:])]: (root/('cohort-'+name+'.json')).write_text(json.dumps(block,indent=2)+'\n')
subprocess.run([sys.executable,'/private/tmp/mech-analyze-constant-phi-worklist-20261114.py'],check=True)
