from pathlib import Path
packet=Path('/private/tmp/mech-constant-bounds-packet-20261114')
s=Path('/private/tmp/mech-borrowed-schema-packet-20261114/replay.py').read_text();s=s[:s.index('census=json.loads')]
s=s.replace("state=read(raw/'source-state.json')", "state=read(root/'source-state.json')").replace('current-memory','qualified-indexed').replace("prior['compiler_binary_sha256']", "prior['compiler_binary_sha256']['candidate']")
s=s.replace('355f6c9a44444be3a1db893d7b2298a415bc84675d88eaf896bad95d57011376','d9b59276ca61471edaf63dea6b2ac4dc96f35bb4562a733dd27288f18c6162d9').replace('77fc1fa9d8b2c07204ab09f76b0980a0d1925d5f6c5387d0a236e1f5cc93dd33','e359f3ae5c65e7841ccc29531912be2cf54da90ccde601d12e1cfa977732f99f')
s=s.replace("len(flags)==54", "len(flags)==55 and flags['MECH_TERMINAL_BYTE_APPENDS']=='1'").replace("['candidate-screen',*[r['name'] for r in rows]]", "['control-screen','candidate-screen',*[r['name'] for r in rows]]")
s=s.replace("('core-test',[188])", "('core-test',[190])").replace('==357','==359')
s+='''
profile=root/'profile';command=read(profile/'command.json');assert command['flags']==flags and command['binary_sha256']==control['sha256'] and command['source_commit']==state['control_source_commit'] and command['documentation_only_head']==state['base_commit']
process=read(profile/'cpu/process.json');assert process['exit_code']==0 and process['samples']==2 and process['sampling_error'] is None
assert read(profile/'output-check.json')==expected
for filename,pinned in expected.items():assert pin(profile/'cpu'/filename)==pinned
mapping=read(profile/'demangled-symbols.json');symbols=set();sample_tables={}
for index in [1,2]:
 path=profile/'cpu'/f'sample-{index:03d}.txt';rawtext=path.read_text();symbols.update(re.findall(r'_R[A-Za-z0-9_]+',rawtext));demangled=re.sub(r'_R[A-Za-z0-9_]+',lambda m:mapping[m.group(0)],rawtext)
 assert demangled==path.with_name(path.stem+'-demangled.txt').read_text()
 parsed=[]
 for line in demangled[demangled.index('Sort by top of stack'):].splitlines()[1:]:
  match=re.match(r'\\s+(.*?)\\s+\\(in (.*?)\\)\\s+(\\d+)\\s*$',line)
  if match:parsed.append({'symbol':match[1],'image':match[2],'self_samples':int(match[3])})
  elif parsed:break
 assert parsed==read(path.with_name(path.stem+'-self.json'));sample_tables[index]=parsed
assert set(mapping)==symbols
needles=['mech_core::dimension::canonicalize_dimension_environment','<alloc::boxed::Box<[mech_core::dimension::DimensionParameterDeclaration]> as core::clone::Clone>::clone','mech_core::dimension::normalize_dimension','mech_gpu::native_artifact::program::codegen::numeric_traversal::analyze','<cranelift_frontend::ssa::SSABuilder>::use_var_nonlocal','mech_gpu::native_artifact::program::prepare::phase_numeric::exits::liveness::live_before_indexed']
hot={name:next(row['self_samples'] for row in sample_tables[1] if row['symbol']==name) for name in needles};assert list(hot.values())==[319,112,97,211,168,132]
source=(root/'source/src/core/src/dimension.rs').read_text();assert 'fn constant_bound_environments_preserve_reference_parameters_and_root_order' in source and 'for seed in 0..256usize' in source and 'fn constant_bound_selection_preserves_unused_validation_and_fallback_error_priority' in source
summary={'source_commit':state['source_commit'],'base_commit':state['base_commit'],'hardware':state['hardware'],'decision':'Retain canonicalization of independent constant bounds without dependency arrays; all validation and generated program bytes unchanged','flags_count':55,'qualified':qualified,'output_hashes':expected,'compiler_binary_sha256':{'control':control['sha256'],'candidate':build['binary_sha256']},'candidate_patch_sha256':state['patch_sha256'],'candidate_bootstrap_seconds':build['seconds'],'tests':dict(test_counts,total=359,no_std_check=True,complete_array_enum_fixtures=6,scalar_fixtures=8),'fixture_output_comparisons':fixtures,'diagnostic_profile':{'compiler_binary_sha256':control['sha256'],'process':process,'first_window_self_samples':hot,'main_thread_waits_excluded_from_hotspot_table':True,'scope':'Separate complete compile with two CPU sampling windows spanning multiple phases. Self samples are observations, not stage-exclusive elapsed time or exact source-line attribution. Existing demangler/source/pin and every raw/mapped stack remain.'},'scope':[
 'Four serial ABBA fresh full source-to-Object observations with identical 55 runtime flags and host statistics. Compiler builds, tests, both screens, fixtures, sampling and archive work do not overlap primary timing. No cached Object or decoded-only substitute is used.',
 'Constant lower and optional upper bounds are already normalized and have no dependency edges. The fast path preserves global ID validation, ordered lifetime checks including unused declarations, root errors, explicit declaration-prefix order and inferred first-occurrence order.',
 'Any expression, parameter or hole bound retains the unchanged generic normalization/DFS path and its original error order. No schema, current shape, lifetime witness, semantic proof or factory selection result is cached; every current draft is checked on each call.',
 'All source, MBC, Object and complete metadata bytes match the previously qualified terminal-append program in both screens and every primary observation. All four outputs also match between subjects in six complete array/enum and eight checked scalar fixtures.',
 'All 359 Core, contract, explicit serde-vector, frontend and codec tests pass, along with Core no_std checking. The gated no-default-feature canonical-vector target runs zero tests and is not counted as coverage. Existing 16384 seeded canonical/reference comparisons remain; added coverage checks 256 larger constant-bound environments plus unused-invalid/fallback/first-error cases.',
 'Compiler/frontend time, retired instructions, peak RSS and footprint improve with nonoverlapping matched ranges. All adverse parse, preparation and cleanup observations remain without causal attribution to this Core change. Four compiles are descriptive, not a population estimate.',
 'The separate CPU profile on the current qualified control identifies canonicalization, declaration cloning and normalization. It preserves all output bytes. Main-thread join waits are not CPU work. Symbol mapping and self-count tables are reconstructed from retained raw samples; no exact phase/line attribution is claimed.',
 'No new program-runtime latency campaign is claimed: generated machine code and complete metadata are byte-identical. Direct scalar emission, checked errors, finite resource admission, current-visit ownership checks, grammar, language and backend optimization level are unchanged. Full fresh compilation remains above ten seconds.'
]}
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
'''
(packet/'replay.py').write_text(s)
