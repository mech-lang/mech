from pathlib import Path
import subprocess,json,hashlib,shutil
repo=Path.cwd();raw=Path('/private/tmp/mech-constant-bounds-20261114');packet=Path('/private/tmp/mech-constant-bounds-packet-20261114');assert not packet.exists()
source='7d0c06d002758d029839c81a774d5e704e56d440';base='6176af3925b0f0f8aef173c5deadc63576bb8994';patch=subprocess.check_output(['git','diff','--binary',base,source]);assert patch==(raw/'candidate.patch').read_bytes();assert subprocess.check_output(['git','diff','619386076692d819778fdc5c53579b3b7604b062',base,'--','src','hosts','vendor','machines'])==b''
excluded=[]
for p in sorted(raw.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(raw)
 if str(rel) in ['control','candidate']:
  excluded.append(dict(path=str(rel),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()));continue
 d=packet/'compiler'/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
(packet/'excluded-executables.json').write_text(json.dumps(excluded,indent=2)+'\n');(packet/'source-change.patch').write_bytes(patch)
(packet/'source-state.json').write_text(json.dumps(dict(source_commit=source,base_commit=base,control_source_commit='619386076692d819778fdc5c53579b3b7604b062',control_production_source_identical_to_base=True,patch_sha256=hashlib.sha256(patch).hexdigest(),hardware='Apple M3 Air, 8 cores (4P+4E), 16 GB, macOS 26.2',rustc=subprocess.check_output(['rustc','-Vv'],text=True),cargo=subprocess.check_output(['cargo','-V'],text=True)),indent=2,sort_keys=True)+'\n')
paths=['src/core/src/dimension.rs','src/core/Cargo.toml','src/core/src/schema/mod.rs','src/core/src/schema/validation.rs','src/core/tests/schema_contract.rs','src/core/tests/dimension_contract.rs','src/core/tests/schema_dimension_relations.rs','src/core/tests/canonical_schema_vectors.rs','tests/architecture/value-system/canonical-encoding-v1-vectors.json','Cargo.lock','.cargo/config.toml','LICENSE','hosts/gpu/tests/fixtures/native/deflate-huffman-LICENSES.md','hosts/gpu/src/native_artifact/program/runtime/composition_tests/nested_phase.rs']
paths+=['benchmarks/mech-deflate/native-profile/'+n for n in ['Cargo.toml','Cargo.lock','compile_profile.rs','profile_compile.py']]
paths+=['hosts/gpu/tests/fixtures/native/'+n+'.mec' for n in ['numeric-nested-phase','numeric-nested-phase-states','numeric-private-fixed-nested','numeric-changing-capture-tree','numeric-array-windows','numeric-multiple-children']]
for name in paths:
 d=packet/'source'/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(subprocess.check_output(['git','show',source+':'+name]))
profile=Path('/private/tmp/mech-after-indexing-profile-20261114');shutil.copytree(profile,packet/'profile')
demangler=Path('/private/tmp/mech-compiler-process-profile-20261114/demangler')
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:
 d=packet/'profile/demangler-source'/name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(demangler/name,d)
validation=packet/'validation';validation.mkdir()
for suffix in ['.json','.archive.json']:shutil.copy2(repo/('benchmarks/mech-deflate/native-profile/indexed-liveness-compile-apple-m3-20261114'+suffix),validation/('qualified-indexed'+suffix))
shutil.copytree(Path('/private/tmp/mech-borrowed-schema-packet-20261114/licenses'),packet/'licenses')
names=['mech-profile-after-indexing-20261114.py','mech-demangle-after-indexing-20261114.py','mech-curate-constant-bounds-20261114.py']
names += [f'mech-{op}-constant-bounds-20261114.py' for op in ['build','test','run']]
names += ['mech-test-constant-bounds-serde-20261114.py','mech-test-constant-bounds-frontend-20261114.py','mech-run-constant-bounds-cohort-20261114.py','mech-constant-bounds-fixtures-20261114.py']
names += [f'mech-constant-bounds-{op}-driver-20261114.log' for op in ['build','test','serde','frontend','screen','control-screen','fixtures','cohort']]
names += ['mech-after-indexing-profile-driver-20261114.log']
for name in names:shutil.copy2(Path('/private/tmp')/name,packet/name)
(packet/'README.txt').write_text('''Canonicalize independent constant bounds, Apple M3, 2026-11-14.
A fresh whole-compile CPU sample on the qualified control identifies dimension
canonicalization, declaration cloning and normalization as frontend costs. Both
raw samples, complete call graphs, symbol mapping, self-count extraction and
existing demangler source/pin remain. Main-thread join waits are not CPU work.
The profiled compile preserves every output byte and is excluded from primary
timing. Sampling windows span multiple phases; self counts are observations,
not stage-exclusive elapsed measurements or exact source-line attribution.
The new path accepts only already canonical constant lower/optional upper
bounds, with no dependency edges. It retains full global ID validation,
ordered lifetime checks (including unused declarations), root errors, explicit
prefix order and first-occurrence inferred order. Bounds with expressions,
parameters or holes retain the unchanged generic path and its error order.
No schema/proof result is cached. Mutable drafts are checked on each call.
All 359 tests pass: Core190, contracts105, serde vectors2, frontend60, codec2;
Core no_std checking passes. The gated zero-test vector target is not coverage.
Four serial ABBA fresh full source-to-Object runs use the same 55 flags and
host statistics. Both screens, all fourteen fixture pairs and all primary
observations preserve source, MBC, Object and complete metadata bytes. Compiler
builds, tests, sampling, fixtures and archiving do not overlap primary timing.
All adverse unchanged-stage observations and resource counters remain; four
compiles are descriptive, not a population estimate. No new program runtime
latency campaign is claimed. Grammar, language, direct scalar emission, current
ownership/visit checks, finite admission and backend optimization are unchanged.
The full ten-second goal remains open. Compiler executables are excluded and
hash-pinned; the complete evidence bundle is published in benchmarks. Run
python3 replay.py for independent pure offline reconstruction.
''');print(packet,flush=True)
