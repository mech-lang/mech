from pathlib import Path
import os,json,subprocess,hashlib,sys
repo=Path.cwd();root=Path('/private/tmp/mech-after-indexing-profile-20261114');root.mkdir(exist_ok=False)
qualified=json.loads((repo/'benchmarks/mech-deflate/native-profile/indexed-liveness-compile-apple-m3-20261114.json').read_text());binary=Path('/private/tmp/mech-indexed-liveness-current-20261114/candidate');assert hashlib.sha256(binary.read_bytes()).hexdigest()==qualified['compiler_binary_sha256']['candidate']
assert subprocess.check_output(['git','diff','619386076692d819778fdc5c53579b3b7604b062','HEAD','--','src','hosts','vendor','machines'])==b''
flags=json.loads(Path('/private/tmp/mech-indexed-liveness-current-20261114/runtime-flags.json').read_text());assert len(flags)==55
cmd=[sys.executable,'benchmarks/mech-deflate/native-profile/profile_compile.py',str(binary),'benchmark',str(root/'cpu'),'compact','sample'];(root/'command.json').write_text(json.dumps(dict(command=cmd,flags=flags,binary_sha256=qualified['compiler_binary_sha256']['candidate'],source_commit=qualified['source_commit'],documentation_only_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),scope='Diagnostic CPU sampling only; excluded from primary timing.'),indent=2)+'\n')
env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')};env.update(flags);p=subprocess.run(cmd,env=env,cwd=repo);assert p.returncode==0
for name,pin in qualified['output_hashes'].items():
 b=(root/'cpu'/name).read_bytes();assert dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())==pin
(root/'output-check.json').write_text(json.dumps(qualified['output_hashes'],indent=2,sort_keys=True)+'\n');print('Every profiled output matches the qualified current program.',flush=True)
