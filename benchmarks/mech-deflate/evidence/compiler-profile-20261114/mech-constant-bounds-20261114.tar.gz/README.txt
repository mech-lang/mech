Canonicalize independent constant bounds, Apple M3, 2026-11-14.
A fresh whole-compile CPU sample on the qualified control identifies dimension
canonicalization, declaration cloning and normalization as frontend costs. Both
raw samples, complete call graphs, symbol mapping, self-count extraction and
existing demangler source/pin remain. Main-thread join waits are not CPU work.
The profiled compile preserves every output byte and is excluded from primary
timing. Sampling windows span multiple phases; self counts are observations,
not stage-exclusive elapsed measurements or exact source-line attribution.
The new path accepts only already canonical constant lower/optional upper
bounds, with no dependency edges. It retains full global ID validation,
ordered lifetime checks (including unused declarations), root errors, explicit
prefix order and first-occurrence inferred order. Bounds with expressions,
parameters or holes retain the unchanged generic path and its error order.
No schema/proof result is cached. Mutable drafts are checked on each call.
All 359 tests pass: Core190, contracts105, serde vectors2, frontend60, codec2;
Core no_std checking passes. The gated zero-test vector target is not coverage.
Four serial ABBA fresh full source-to-Object runs use the same 55 flags and
host statistics. Both screens, all fourteen fixture pairs and all primary
observations preserve source, MBC, Object and complete metadata bytes. Compiler
builds, tests, sampling, fixtures and archiving do not overlap primary timing.
All adverse unchanged-stage observations and resource counters remain; four
compiles are descriptive, not a population estimate. No new program runtime
latency campaign is claimed. Grammar, language, direct scalar emission, current
ownership/visit checks, finite admission and backend optimization are unchanged.
The full ten-second goal remains open. Compiler executables are excluded and
hash-pinned; the complete evidence bundle is published in benchmarks. Run
python3 replay.py for independent pure offline reconstruction.
