from pathlib import Path
import json,hashlib,re,statistics,subprocess,sys
root=Path(__file__).resolve().parent;raw=root/'compiler';read=lambda p:json.loads(p.read_text())
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
state=read(root/'source-state.json');build=read(raw/'candidate-build.json');control=read(raw/'control-origin.json');prior=read(root/'validation/qualified-indexed.json');prior_receipt=read(root/'validation/qualified-indexed.archive.json')
assert pin(root/'validation/qualified-indexed.json')['sha256']==prior_receipt['replay_sha256']
assert state['control_production_source_identical_to_base'] and build['exit_code']==0 and build['head']==state['base_commit']
assert pin(raw/'candidate.patch')==pin(root/'source-change.patch') and pin(raw/'candidate.patch')['sha256']==build['patch_sha256']==state['patch_sha256']
assert control['sha256']==prior['compiler_binary_sha256']['candidate']=='d9b59276ca61471edaf63dea6b2ac4dc96f35bb4562a733dd27288f18c6162d9'
assert build['binary_sha256']=='e359f3ae5c65e7841ccc29531912be2cf54da90ccde601d12e1cfa977732f99f'
for r in read(root/'excluded-executables.json'):assert r['sha256']==(control['sha256'] if r['path']=='control' else build['binary_sha256'])
flags=read(raw/'runtime-flags.json');assert len(flags)==55 and flags['MECH_TERMINAL_BYTE_APPENDS']=='1' and flags['MECH_NORMALIZE_DEFAULTED_READ_SETUP']=='1'
expected=prior['output_hashes'];rows=read(raw/'cohort.json');assert [r['variant'] for r in rows]==['control','candidate','candidate','control']
for name in ['control-screen','candidate-screen',*[r['name'] for r in rows]]:
 d=raw/name;assert read(d/'process.json')['exit_code']==0 and read(d/'process.json')['samples']==0
 command=read(raw/(name+'-command.json'));assert command['flags']==flags
 assert command['binary_sha256']==(control['sha256'] if name.startswith('control-') else build['binary_sha256'])
 for filename,pinned in expected.items():assert pin(d/filename)==pinned and read(d/'output-check.json')[filename]==dict(pinned,matches_previous_qualified_output=True)
for row in rows:
 d=raw/row['name'];assert row['compile']==read(d/'compile.json') and row['process']==read(d/'process.json') and row['files']==read(d/'output-check.json')
 stamps=[json.loads(line) for line in (d/'stages.jsonl').read_text().splitlines()]
 for key,begin,end in [('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]:assert row[key]==next(s['elapsed'] for s in stamps if s['line'].startswith(end))-next(s['elapsed'] for s in stamps if s['line'].startswith(begin))
 for key,pattern in [('max_rss_bytes',r'(\d+)  maximum resident set size'),('instructions',r'(\d+)  instructions retired'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]:assert row[key]==int(re.search(pattern,(d/'stderr.log').read_text()).group(1))

test_counts={}
for name,expected_counts in [('core-test',[190]),('core-contract-test',[0,7,14,3,17,21,9,34]),('core-serde-vectors',[2]),('frontend-tests',[60]),('codec-tests',[2])]:
 assert read(raw/(name+'-command.json'))['exit_code']==0
 counts=list(map(int,re.findall(r'test result: ok\. (\d+) passed',(raw/(name+'.log')).read_text())))
 assert counts==expected_counts
 test_counts[name]=sum(counts)
assert sum(test_counts.values())==359
assert read(raw/'core-no-std-command.json')['exit_code']==0
contracts=(root/'source/src/core/tests/schema_contract.rs').read_text()
assert 'finalize_body' in contracts and 'finalize_ref' in contracts
fixtures=read(raw/'fixture-results.json');assert len(fixtures)==14
for row in fixtures:
 assert row['all_outputs_match'] and row['variants']['control']==row['variants']['candidate'] and row['variants']['control']['exit_code']==0 and len(row['variants']['control']['files'])==4
 name=Path(row['fixture']).stem if ':' not in row['fixture'] else row['fixture'].split(':')[-1]
 for variant,record in row['variants'].items():
  d=raw/'fixtures'/name/variant;assert read(d/'command.json')['flags']==flags
  assert read(d/'command.json')['binary_sha256']==(control['sha256'] if variant=='control' else build['binary_sha256'])
  for filename,pinned in record['files'].items():assert pin(d/filename)==pinned
  assert record['files']['source.mec']['sha256']==row['source_sha256']
base=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase.mec').read_text();fragment=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase-states.mec').read_text();assembled=base.replace('+> sequence\n','+> sequence\n'+fragment+'\n',1).replace('phase-candidates(values, 1u64, 0u64, permitted, divisor)','#PhaseCandidates(values, permitted, divisor, 1u64, 0u64)',1);assert assembled==(raw/'fixture-inputs/numeric-nested-phase-states.mec').read_text()
fields={'compiler_seconds':lambda r:r['compile']['total_seconds'],'whole_process_seconds':lambda r:r['process']['elapsed_seconds'],'parse_seconds':lambda r:next(p['seconds'] for p in r['compile']['phases'] if p['phase']=='parse'),'frontend_seconds':lambda r:next(p['seconds'] for p in r['compile']['phases'] if p['phase']=='frontend'),'native_seconds':lambda r:next(p['seconds'] for p in r['compile']['phases'] if p['phase']=='native')}
for key in ['canonical_lowering_seconds','preparation_seconds','numeric_generation_seconds','source_cfg_seconds','cleanup_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:fields[key]=lambda r,key=key:r[key]
qualified={key:{v:[f(r) for r in rows if r['variant']==v] for v in ['control','candidate']} for key,f in fields.items()}
for record in qualified.values():record['mean_reduction_fraction']=1-statistics.mean(record['candidate'])/statistics.mean(record['control'])



profile=root/'profile';command=read(profile/'command.json');assert command['flags']==flags and command['binary_sha256']==control['sha256'] and command['source_commit']==state['control_source_commit'] and command['documentation_only_head']==state['base_commit']
process=read(profile/'cpu/process.json');assert process['exit_code']==0 and process['samples']==2 and process['sampling_error'] is None
assert read(profile/'output-check.json')==expected
for filename,pinned in expected.items():assert pin(profile/'cpu'/filename)==pinned
mapping=read(profile/'demangled-symbols.json');symbols=set();sample_tables={}
for index in [1,2]:
 path=profile/'cpu'/f'sample-{index:03d}.txt';rawtext=path.read_text();symbols.update(re.findall(r'_R[A-Za-z0-9_]+',rawtext));demangled=re.sub(r'_R[A-Za-z0-9_]+',lambda m:mapping[m.group(0)],rawtext)
 assert demangled==path.with_name(path.stem+'-demangled.txt').read_text()
 parsed=[]
 for line in demangled[demangled.index('Sort by top of stack'):].splitlines()[1:]:
  match=re.match(r'\s+(.*?)\s+\(in (.*?)\)\s+(\d+)\s*$',line)
  if match:parsed.append({'symbol':match[1],'image':match[2],'self_samples':int(match[3])})
  elif parsed:break
 assert parsed==read(path.with_name(path.stem+'-self.json'));sample_tables[index]=parsed
assert set(mapping)==symbols
needles=['mech_core::dimension::canonicalize_dimension_environment','<alloc::boxed::Box<[mech_core::dimension::DimensionParameterDeclaration]> as core::clone::Clone>::clone','mech_core::dimension::normalize_dimension','mech_gpu::native_artifact::program::codegen::numeric_traversal::analyze','<cranelift_frontend::ssa::SSABuilder>::use_var_nonlocal','mech_gpu::native_artifact::program::prepare::phase_numeric::exits::liveness::live_before_indexed']
hot={name:next(row['self_samples'] for row in sample_tables[1] if row['symbol']==name) for name in needles};assert list(hot.values())==[319,112,97,211,168,132]
source=(root/'source/src/core/src/dimension.rs').read_text();assert 'fn constant_bound_environments_preserve_reference_parameters_and_root_order' in source and 'for seed in 0..256usize' in source and 'fn constant_bound_selection_preserves_unused_validation_and_fallback_error_priority' in source
summary={'source_commit':state['source_commit'],'base_commit':state['base_commit'],'hardware':state['hardware'],'decision':'Retain canonicalization of independent constant bounds without dependency arrays; all validation and generated program bytes unchanged','flags_count':55,'qualified':qualified,'output_hashes':expected,'compiler_binary_sha256':{'control':control['sha256'],'candidate':build['binary_sha256']},'candidate_patch_sha256':state['patch_sha256'],'candidate_bootstrap_seconds':build['seconds'],'tests':dict(test_counts,total=359,no_std_check=True,complete_array_enum_fixtures=6,scalar_fixtures=8),'fixture_output_comparisons':fixtures,'diagnostic_profile':{'compiler_binary_sha256':control['sha256'],'process':process,'first_window_self_samples':hot,'main_thread_waits_excluded_from_hotspot_table':True,'scope':'Separate complete compile with two CPU sampling windows spanning multiple phases. Self samples are observations, not stage-exclusive elapsed time or exact source-line attribution. Existing demangler/source/pin and every raw/mapped stack remain.'},'scope':[
 'Four serial ABBA fresh full source-to-Object observations with identical 55 runtime flags and host statistics. Compiler builds, tests, both screens, fixtures, sampling and archive work do not overlap primary timing. No cached Object or decoded-only substitute is used.',
 'Constant lower and optional upper bounds are already normalized and have no dependency edges. The fast path preserves global ID validation, ordered lifetime checks including unused declarations, root errors, explicit declaration-prefix order and inferred first-occurrence order.',
 'Any expression, parameter or hole bound retains the unchanged generic normalization/DFS path and its original error order. No schema, current shape, lifetime witness, semantic proof or factory selection result is cached; every current draft is checked on each call.',
 'All source, MBC, Object and complete metadata bytes match the previously qualified terminal-append program in both screens and every primary observation. All four outputs also match between subjects in six complete array/enum and eight checked scalar fixtures.',
 'All 359 Core, contract, explicit serde-vector, frontend and codec tests pass, along with Core no_std checking. The gated no-default-feature canonical-vector target runs zero tests and is not counted as coverage. Existing 16384 seeded canonical/reference comparisons remain; added coverage checks 256 larger constant-bound environments plus unused-invalid/fallback/first-error cases.',
 'Compiler/frontend time, retired instructions, peak RSS and footprint improve with nonoverlapping matched ranges. All adverse parse, preparation and cleanup observations remain without causal attribution to this Core change. Four compiles are descriptive, not a population estimate.',
 'The separate CPU profile on the current qualified control identifies canonicalization, declaration cloning and normalization. It preserves all output bytes. Main-thread join waits are not CPU work. Symbol mapping and self-count tables are reconstructed from retained raw samples; no exact phase/line attribution is claimed.',
 'No new program-runtime latency campaign is claimed: generated machine code and complete metadata are byte-identical. Direct scalar emission, checked errors, finite resource admission, current-visit ownership checks, grammar, language and backend optimization level are unchanged. Full fresh compilation remains above ten seconds.'
]}
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
