from pathlib import Path
import hashlib
import json
import re

def tokens(text):
    pieces = re.findall(r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|[A-Za-z_]\w*|\d+|[^\s]', text)
    return [piece for piece in pieces if not piece.startswith(('//', '/*'))]

def audit(root):
    old = (root / 'reference.rs').read_text()
    new = (root / 'candidate.rs').read_text()
    begin = '    fn find_var('
    before = '        // Try to find an existing definition along single-predecessor edges first.'
    after = "        // We've promised to return the most recent block where `var` was defined"
    next_method = '    /// Declares a new basic block'
    tests = '#[cfg(test)]\nmod tests {'
    assert tokens(old[:old.index(begin)]) == tokens(new[:new.index(begin)])
    assert tokens(old[old.index(begin):old.index(before)]) == tokens(new[new.index(begin):new.index(before)])
    assert tokens(old[old.index(after):old.index(next_method)]) == tokens(new[new.index(after):new.index(next_method)])
    assert tokens(old[old.index(next_method):old.index(tests)]) == tokens(new[new.index(next_method):new.index(tests)])
    original = old[old.index('        while let Some(pred)', old.index(before)):old.index(after)].strip()
    fallback = new[new.index('                    while let Some(pred)', new.index(before)):new.index('                    break;\n                }', new.index('                    while let Some(pred)', new.index(before)))].strip()
    assert tokens(original) == tokens(fallback)
    return dict(
        production_before_find_var_identical=True,
        function_signature_identical=True,
        original_fallback_loop_identical=True,
        parameter_creation_and_sealed_lookup_tail_identical=True,
        remaining_production_identical=True,
        original_fallback_loop_tokens_sha256=hashlib.sha256(' '.join(tokens(original)).encode()).hexdigest(),
        parameter_creation_tail_tokens_sha256=hashlib.sha256(' '.join(tokens(old[old.index(after):old.index(next_method)])).encode()).hexdigest(),
        scope='Only read-only decreasing-chain lookup is added before the identical old fallback and parameter-creation path. Two focused unit tests are added after production code. No SSA storage, sealing, variable/type/value identity or permission logic changes.',
    )

if __name__ == '__main__':
    root = Path(__file__).resolve().parent
    result = audit(root)
    encoded = json.dumps(result, indent=2, sort_keys=True) + '\n'
    saved = root / 'algorithm-audit.json'
    if saved.exists():
        assert saved.read_text() == encoded
    else:
        saved.write_text(encoded)
    print(encoded, end='')
