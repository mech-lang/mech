from pathlib import Path
import json,hashlib,re,statistics
root=Path(__file__).resolve().parent;raw=root/'compiler';read=lambda p:json.loads(p.read_text())
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
state=read(raw/'source-state.json');build=read(raw/'candidate-build.json');control=read(raw/'control-origin.json');prior=read(root/'validation/accepted-visits.json');prior_receipt=read(root/'validation/accepted-visits.archive.json')
assert pin(root/'validation/accepted-visits.json')['sha256']==prior_receipt['replay_sha256']
assert state['control_production_source_identical_to_base'] and build['exit_code']==0 and build['head']==state['base_commit']
assert pin(raw/'candidate.patch')==pin(root/'source-change.patch') and pin(raw/'candidate.patch')['sha256']==build['patch_sha256']==state['patch_sha256']
assert control['sha256']==prior['compiler_binary_sha256']['candidate']=='1c59c80c62a7a11bc4693090a8b3618aa159b474908f4ab5a2a40dd38d8cd158'
assert build['binary_sha256']=='c19a4f73a4642287bb754c4fed499ea1eaf82845f29883a2662715c7ed30ac2b'
for r in read(root/'excluded-executables.json'):assert r['sha256']==(control['sha256'] if r['path']=='control' else build['binary_sha256'])
flags=read(raw/'runtime-flags.json');assert len(flags)==54 and flags['MECH_NORMALIZE_DEFAULTED_READ_SETUP']=='1'
expected=prior['output_hashes'];rows=read(raw/'cohort.json');assert [r['variant'] for r in rows]==['control','candidate','candidate','control']
for name in ['candidate-screen',*[r['name'] for r in rows]]:
 d=raw/name;assert read(d/'process.json')['exit_code']==0 and read(d/'process.json')['samples']==0
 command=read(raw/(name+'-command.json'));assert command['flags']==flags
 assert command['binary_sha256']==(control['sha256'] if name.startswith('control-') else build['binary_sha256'])
 for filename,pinned in expected.items():assert pin(d/filename)==pinned and read(d/'output-check.json')[filename]==dict(pinned,matches_previous_qualified_output=True)
for row in rows:
 d=raw/row['name'];assert row['compile']==read(d/'compile.json') and row['process']==read(d/'process.json') and row['files']==read(d/'output-check.json')
 stamps=[json.loads(line) for line in (d/'stages.jsonl').read_text().splitlines()]
 for key,begin,end in [('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]:assert row[key]==next(s['elapsed'] for s in stamps if s['line'].startswith(end))-next(s['elapsed'] for s in stamps if s['line'].startswith(begin))
 for key,pattern in [('max_rss_bytes',r'(\d+)  maximum resident set size'),('instructions',r'(\d+)  instructions retired'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]:assert row[key]==int(re.search(pattern,(d/'stderr.log').read_text()).group(1))
assert read(raw/'liveness-test-command.json')['exit_code']==0 and re.findall(r'test result: ok\. (\d+) passed',(raw/'liveness-tests.log').read_text())==['11']
source=(root/'source/hosts/gpu/src/native_artifact/program/prepare/numeric_liveness_tests.rs').read_text();assert 'fn unread_and_unselected_definition_facts_do_not_affect_liveness' in source and 'for seed in 0..256u32' in source

fixtures=read(raw/'fixture-results.json');assert len(fixtures)==14
for row in fixtures:
 assert row['all_outputs_match'] and row['variants']['control']==row['variants']['candidate'] and row['variants']['control']['exit_code']==0 and len(row['variants']['control']['files'])==4
 name=Path(row['fixture']).stem if ':' not in row['fixture'] else row['fixture'].split(':')[-1]
 for variant,record in row['variants'].items():
  d=raw/'fixtures'/name/variant;assert read(d/'command.json')['flags']==flags
  assert read(d/'command.json')['binary_sha256']==(control['sha256'] if variant=='control' else build['binary_sha256'])
  for filename,pinned in record['files'].items():assert pin(d/filename)==pinned
  assert record['files']['source.mec']['sha256']==row['source_sha256']
base=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase.mec').read_text();fragment=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase-states.mec').read_text();assembled=base.replace('+> sequence\n','+> sequence\n'+fragment+'\n',1).replace('phase-candidates(values, 1u64, 0u64, permitted, divisor)','#PhaseCandidates(values, permitted, divisor, 1u64, 0u64)',1);assert assembled==(raw/'fixture-inputs/numeric-nested-phase-states.mec').read_text()
fields={'compiler_seconds':lambda r:r['compile']['total_seconds'],'whole_process_seconds':lambda r:r['process']['elapsed_seconds'],'parse_seconds':lambda r:next(p['seconds'] for p in r['compile']['phases'] if p['phase']=='parse'),'frontend_seconds':lambda r:next(p['seconds'] for p in r['compile']['phases'] if p['phase']=='frontend'),'native_seconds':lambda r:next(p['seconds'] for p in r['compile']['phases'] if p['phase']=='native')}
for key in ['canonical_lowering_seconds','preparation_seconds','numeric_generation_seconds','source_cfg_seconds','cleanup_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:fields[key]=lambda r,key=key:r[key]
qualified={key:{v:[f(r) for r in rows if r['variant']==v] for v in ['control','candidate']} for key,f in fields.items()}
for record in qualified.values():record['mean_reduction_fraction']=1-statistics.mean(record['candidate'])/statistics.mean(record['control'])

# The instrumented compile is a separate diagnostic; reconstruct its counters,
# query grouping and nested graph/solver intervals without treating it as primary.
diag=root/'diagnostic';q=[json.loads(line.split('liveness-query: ',1)[1]) for line in (diag/'query-profile/stderr.log').read_text().splitlines() if line.startswith('liveness-query: ')]
assert q==read(diag/'queries.json') and len(q)==790
contexts=[json.dumps({k:r[k] for k in ['plan_diagnostic_address','header','latch','finish','returned','start','known','wanted']},sort_keys=True) for r in q];assert len(set(contexts))==790
assert len({r['header'] for r in q})==299 and read(diag/'restoration.json')['restored_to_HEAD']
assert pin(diag/'numeric_exits.original.rs')['sha256']==read(diag/'restoration.json')['restored_sha256']
assert pin(diag/'numeric_exits.instrumented.rs')['sha256']==read(diag/'restoration.json')['instrumented_sha256']
db=read(diag/'profile-build.json');assert db['exit_code']==0 and db['head']==state['base_commit'] and pin(diag/'profile.patch')['sha256']==db['patch_sha256']
assert read(diag/'query-profile/process.json')['exit_code']==0
command=read(diag/'query-profile-command.json');assert len(command['flags'])==55 and command['flags']['MECH_PROFILE_LIVENESS_QUERIES']=='1' and command['binary_sha256']==db['binary_sha256']
for name,pinned in expected.items():assert pin(diag/'query-profile'/name)==pinned
diagnostic={'queries':len(q),'exact_duplicate_contexts':0,'tail_headers':299,'graph_seconds':sum(r['graph_seconds'] for r in q),'solver_seconds':sum(r['solve_seconds'] for r in q),'materialized_definition_pairs':sum(r['definition_pairs'] for r in q),'reachable_sites':sum(r['reachable_sites'] for r in q),'median_reachable_sites':statistics.median(r['reachable_sites'] for r in q),'median_definition_pairs':statistics.median(r['definition_pairs'] for r in q),'median_live_values':statistics.median(r['live_values'] for r in q),'wanted_queries':sum(r['wanted'] is not None for r in q),'scope':'Separate temporary diagnostic before the functional edit. No primary timing claim. Address labels are not cache/proof identities.'}
summary={'source_commit':state['source_commit'],'base_commit':state['base_commit'],'hardware':state['hardware'],'decision':'Retain selected liveness definition materialization with unchanged validation and generated bytes','flags_count':54,'qualified':qualified,'output_hashes':expected,'compiler_binary_sha256':{'control':control['sha256'],'candidate':build['binary_sha256']},'candidate_patch_sha256':state['patch_sha256'],'candidate_bootstrap_seconds':build['seconds'],'diagnostic':diagnostic,'tests':{'liveness':11,'irrelevant_definition_graphs':256,'starts_per_graph':9,'complete_array_enum_fixtures':6,'scalar_fixtures':8},'fixture_output_comparisons':fixtures,'scope':[
 'Four serial ABBA fresh full source-to-Object observations with the same 54 existing runtime flags and host statistics. Bootstrap, screen, tests, fixtures, diagnostic and archiving are excluded. No competing work overlaps primary timing.',
 'Every query retains the same selected graph, action/terminator reads, predicate context, tail stops and original ordered definition lookups/validation, including unread values. No semantic proof or liveness result is cached.',
 'Only materialized kill facts are filtered to values read in the selected graph and sites belonging to that graph. Unread values cannot seed liveness; outside sites cannot kill a selected fact. Out-of-range read IDs retain their prior solver behavior.',
 'The separate diagnostic observes 790 distinct exact contexts, median 284 selected sites, median 23850 definition facts and median nine live values. Its graph/solver timers are nested in preparation and are not primary timing observations.',
 'All source, MBC, Object and complete metadata bytes match the previously qualified fast control in every primary observation and separate screen. All four outputs also match between subjects in six array/enum and eight checked scalar programs.',
 'All 11 liveness tests pass, including dense/sparse/reference agreement after removing irrelevant definitions on 256 cyclic/branching graphs and nine starts per graph, unused high IDs and outside definition sites.',
 'Candidate peak RSS is higher with nonoverlapping matched ranges; no memory saving is claimed. All adverse counters and unchanged-stage elapsed variation remain, without causal attribution to this filter. Four compiles are descriptive, not a population estimate.',
 'No new runtime latency campaign is claimed; main/helper machine code and metadata remain byte-identical. The copied complete state fixture assembly provenance includes earlier attempts, not a new fragment-only launch.',
 'Diagnostic instrumentation is restored before the functional edit. Its complete source, patch, build, query logs, restored-source hashes and outputs remain. Diagnostic addresses are observations, never semantic cache keys.',
 'Grammar, language, current-visit/ownership checks, error order, finite admission and backend optimization level are unchanged. Full compilation remains above ten seconds.'
]}
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
