from pathlib import Path
import subprocess,time,os,json,hashlib,shutil,sys
root=Path('/private/tmp/mech-live-definitions-20261114');root.mkdir(exist_ok=True)
name=sys.argv[1];head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();patch=subprocess.check_output(['git','diff','--binary']);(root/(name+'.patch')).write_bytes(patch)
cmd=['cargo','build','--locked','--offline','--release','-j2','--manifest-path','benchmarks/mech-deflate/native-profile/Cargo.toml','--bin','compile_profile','--message-format=json']
start=time.perf_counter()
with (root/(name+'-build.jsonl')).open('wb') as out,(root/(name+'-build.stderr')).open('wb') as err:p=subprocess.run(cmd,env=dict(os.environ,CARGO_TARGET_DIR='/private/tmp/mech-level12-compile-target',CARGO_INCREMENTAL='0'),stdout=out,stderr=err)
result={'command':cmd,'head':head,'patch_sha256':hashlib.sha256(patch).hexdigest(),'seconds':time.perf_counter()-start,'exit_code':p.returncode,'CARGO_TARGET_DIR':'/private/tmp/mech-level12-compile-target','CARGO_INCREMENTAL':'0'}
if not p.returncode:
 rows=[json.loads(line) for line in (root/(name+'-build.jsonl')).read_text().splitlines()]
 exe=next(row['executable'] for row in rows if row.get('reason')=='compiler-artifact' and row.get('target',{}).get('name')=='compile_profile' and row.get('executable'))
 dest=root/name;shutil.copy2(exe,dest);dest.chmod(0o755);result.update(binary=str(dest),binary_sha256=hashlib.sha256(dest.read_bytes()).hexdigest())
 assert subprocess.check_output(['git','diff','--binary'])==patch,'source changed during compiler build'
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head,'HEAD changed during compiler build'
(root/(name+'-build.json')).write_text(json.dumps(result,indent=2)+'\n');print(result,flush=True);raise SystemExit(p.returncode)
