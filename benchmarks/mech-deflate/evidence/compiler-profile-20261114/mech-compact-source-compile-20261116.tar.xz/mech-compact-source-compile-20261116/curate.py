from pathlib import Path
import hashlib,json,os,sys,subprocess,shutil,tarfile,struct,time,datetime,traceback
repo=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech');packet=Path('/private/tmp/mech-compact-source-compile-packet-20261116');integration=Path('/private/tmp/mech-compact-integration-20261116');pgo=Path('/private/tmp/mech-parser-lexical-native-pgo-20261116')
jobpath=Path('/private/tmp/mech-compact-source-compile-curation-job-20261116.json');record={'state':'running','pid':os.getpid(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def save(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def pin(path):
 with path.open('rb') as stream:return {'bytes':path.stat().st_size,'sha256':hashlib.file_digest(stream,'sha256').hexdigest()}
def executable(path):
 with path.open('rb') as stream:header=stream.read(16)
 return len(header)==16 and struct.unpack_from('<I',header,0)[0]==0xfeedfacf and struct.unpack_from('<I',header,12)[0]==2
save(jobpath,record)
try:
 assert json.loads((integration/'final/cohort/job.json').read_text())['exit_code']==0
 packet.mkdir(exist_ok=False);copied=[];excluded=[]
 def copy(source,destination):
  target=packet/destination;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target);actual=pin(target);assert actual==pin(source);copied.append({'source':str(source),'path':str(destination),**actual})
 roots=[(integration,'integration'),(Path('/private/tmp/mech-smaller39e-handoff-20261116'),'handoff'),(Path('/private/tmp/mech-smaller39e-full-native-20261116'),'new-source-current-backend'),(Path('/private/tmp/mech-smaller39e-current-compiler-20261116'),'new-source-screen')]
 for source,prefix in roots:
  for path in sorted(source.rglob('*')):
   if not path.is_file():continue
   relative=path.relative_to(source)
   is_compiler=(prefix=='integration' and (path.name in ['compile_profile','emit_compact_size'] or ('tests' in relative.parts and executable(path))))
   if is_compiler:excluded.append({'source':str(path),'reason':'Compiler/test executable; source, construction commands and exact hash retained; program executables remain included.',**pin(path)});continue
   copy(path,Path(prefix)/relative)
 for path in sorted(pgo.rglob('*')):
  if not path.is_file():continue
  relative=path.relative_to(pgo)
  if relative.parts[0] in ['target','source','raw'] or relative==Path('merged.profdata'):continue
  if executable(path):excluded.append({'source':str(path),'reason':'Frontend compiler executable; source, configuration, fresh profiles and exact hash retained.',**pin(path)});continue
  copy(path,Path('pgo/records')/relative)
 # Reconstructable frontend source patch and all six actual edited files.
 state=json.loads((pgo/'source-state.json').read_text())
 for row in state['source_files']:
  path=pgo/'source'/row['path'];assert pin(path)['sha256']==row['candidate_sha256'];copy(path,Path('pgo/source-files')/row['path'])
 profiles=[]
 for path in [*sorted((pgo/'raw').glob('*.profraw')),pgo/'merged.profdata']:
  profiles.append({'source':str(path),'member':str(path.relative_to(pgo)),**pin(path)})
 assert len(profiles)==9
 (packet/'pgo').mkdir(exist_ok=True)
 with tarfile.open(packet/'pgo/profiles.tar.gz','w:gz',compresslevel=1) as archive:
  for row in profiles:
   info=tarfile.TarInfo(row['member']);info.size=row['bytes'];info.mode=0o644;info.mtime=0
   with Path(row['source']).open('rb') as stream:archive.addfile(info,stream)
 save(packet/'pgo/profiles.json',profiles)
 # Exact supplied compiler recipe, including the pinned final machine facts.
 for path in sorted((repo/'benchmarks/mech-deflate/native-profile/compact-size').rglob('*')):
  if path.is_file() and '__pycache__' not in path.parts:copy(path,Path('compiler-recipe')/path.relative_to(repo/'benchmarks/mech-deflate/native-profile/compact-size'))
 source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert source_commit=='4e8fd9351a9e6219c5cf2150a08f97f70362e815'
 parents=subprocess.check_output(['git','show','-s','--format=%P',source_commit],cwd=repo,text=True).strip().split();assert parents==['79d138cdd9bf49ae05631473f5dba9628ecc24f2','b2729eb6660a81a91f77f8c3bb2b9d1d66590220']
 finalstate=json.loads((integration/'final/source-state/state.json').read_text())
 for row in finalstate['files']:
  data=subprocess.check_output(['git','show',source_commit+':'+row['path']],cwd=repo);assert hashlib.sha256(data).hexdigest()==row['sha256']
 save(packet/'provenance.json',{'source_commit':source_commit,'parents':parents,'all_measured_final_source_files_match_commit':True,'frontend_source':state,'scope':'New source full compile qualification. The earlier164KB original-source18-helper qualification was planned but never run. Preserve it as unrun; current243KB source is qualified here. Serial primary mean6.027732s; no arithmetic addition of separate gains. Compiler bootstrap, diagnostic failures, all prior/current backend and runtime cohorts remain separately identified.','metadata':'Fresh prepared metadata and complete Object identity checked. The exact supplied recipe copies its recorded final machine facts as metadata after those checks; no claim of generic final metadata regeneration.','runtime':'Final retains b272 runtime exactly. Earlier cohorts kept the compile-speed branch64-page threshold; final has supplied4-page threshold. All original cohort bytes and decisions retained.'})
 save(packet/'excluded-executables.json',excluded);save(packet/'curation.json',{'copied_files':copied,'source_directories':[str(p) for p,_ in roots],'profile_storage':'All8 raw and1 merged profiles losslessly stored in nested profiles.tar.gz. No profile bytes omitted.','no_measurement_repeated_for_postprocessing':True})
 copy(Path('/private/tmp/mech-replay-compact-source-compile-20261116.py'),Path('replay.py'))
 with (packet/'replay-first.stdout').open('w') as out,(packet/'replay-first.stderr').open('w') as err:r=subprocess.run([sys.executable,str(packet/'replay.py'),str(packet),str(packet/'result.json')],stdout=out,stderr=err)
 assert r.returncode==0,'initial numerical replay'
 entries=[{'path':str(path.relative_to(packet)),**pin(path)} for path in sorted(packet.rglob('*')) if path.is_file() and path.name!='manifest.json'];save(packet/'manifest.json',{'format':1,'files':entries,'file_count_without_manifest':len(entries),'uncompressed_bytes_without_manifest':sum(row['bytes'] for row in entries)})
 verify=packet.with_name(packet.name+'-replayed.json')
 with packet.with_name(packet.name+'-verify.stdout').open('w') as out,packet.with_name(packet.name+'-verify.stderr').open('w') as err:r=subprocess.run([sys.executable,str(packet/'replay.py'),str(packet),str(verify)],stdout=out,stderr=err)
 assert r.returncode==0 and verify.read_bytes()==(packet/'result.json').read_bytes()
 record.update(state='complete',exit_code=0,files=len(entries)+1,manifest=pin(packet/'manifest.json'),summary=pin(packet/'result.json'),packet=str(packet))
except BaseException as error:record.update(state='failed',exit_code=1,error=repr(error));traceback.print_exc()
record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save(jobpath,record);print(json.dumps(record),flush=True);raise SystemExit(record['exit_code'])
