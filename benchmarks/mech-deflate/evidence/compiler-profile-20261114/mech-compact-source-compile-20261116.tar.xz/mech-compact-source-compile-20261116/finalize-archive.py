from pathlib import Path
import hashlib,json,subprocess,shutil,tarfile,lzma,sys
packet=Path('/private/tmp/mech-compact-source-compile-packet-20261116');repo=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech');name='mech-compact-source-compile-20261116'
def pin(path):
 with path.open('rb') as stream:return {'bytes':path.stat().st_size,'sha256':hashlib.file_digest(stream,'sha256').hexdigest()}
def save(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
assert json.loads(Path('/private/tmp/mech-compact-source-compile-repack-job-20261116.json').read_text())['exit_code']==0
shutil.copy2(packet/'README.txt',packet/'storage-first/README-before-xz.txt');shutil.copy2('/private/tmp/mech-compact-source-compile-receipt-20261116.json',packet/'storage-first/xz-receipt.json')
p=packet/'README.txt';p.write_text(p.read_text().replace('pgo/profiles.tar.gz','pgo/profiles.tar.xz')+'Historical gzip packing records are retained under storage-first and storage-reencoding.json. The current profiles and outer packet use lossless XZ; every raw profile is verified by replay.\n')
shutil.copy2(__file__,packet/'finalize-archive.py')
entries=[{'path':str(path.relative_to(packet)),**pin(path)} for path in sorted(packet.rglob('*')) if path.is_file() and path!=packet/'manifest.json'];save(packet/'manifest.json',{'format':1,'files':entries,'file_count_without_manifest':len(entries),'uncompressed_bytes_without_manifest':sum(r['bytes'] for r in entries)})
result=Path('/private/tmp/mech-compact-source-compile-final-replay.json')
r=subprocess.run([sys.executable,str(packet/'replay.py'),str(packet),str(result)],check=True,capture_output=True,text=True);assert result.read_bytes()==(packet/'result.json').read_bytes()
archive=Path('/private/tmp')/(name+'.tar.xz')
with lzma.LZMAFile(archive,'w',filters=[{'id':lzma.FILTER_LZMA2,'preset':3,'dict_size':1<<26}]) as compressed:
 with tarfile.open(fileobj=compressed,mode='w|') as tar:
  for path in sorted(packet.rglob('*')):
   if not path.is_file():continue
   info=tarfile.TarInfo(name+'/'+str(path.relative_to(packet)));info.size=path.stat().st_size;info.mode=path.stat().st_mode&0o777;info.mtime=0
   with path.open('rb') as stream:tar.addfile(info,stream)
destination=repo/'benchmarks/mech-deflate/evidence/compiler-profile-20261114'/archive.name;shutil.copy2(archive,destination);assert pin(destination)==pin(archive) and archive.stat().st_size<100*1024*1024
receipt=json.loads(Path('/private/tmp/mech-compact-source-compile-receipt-20261116.json').read_text());receipt.update(**pin(archive),files=len(entries)+1,evidence_files=len(entries)+1,uncompressed_bytes=sum(row['bytes'] for row in entries)+(packet/'manifest.json').stat().st_size,manifest_sha256=pin(packet/'manifest.json')['sha256'],replay_sha256=pin(packet/'result.json')['sha256'])
save(Path('/private/tmp/mech-compact-source-compile-receipt-20261116.json'),receipt);print(json.dumps({'archive_bytes':receipt['bytes'],'files':receipt['files'],'sha256':receipt['sha256'],'replay_byte_identical':True}))
