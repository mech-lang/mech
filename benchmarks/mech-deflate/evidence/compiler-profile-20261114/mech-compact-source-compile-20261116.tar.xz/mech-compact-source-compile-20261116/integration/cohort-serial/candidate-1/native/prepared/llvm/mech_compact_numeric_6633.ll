target triple = "arm64-apple-macosx26.0.0"

declare i64 @"mech_compact_allocate"(i64, i64, i64, i64, i64, i64)
declare i64 @"mech_compact_free"(i64, i64)
declare i64 @"mech_compact_writable"(i64, i64, i64, i64, i64, i64, i64)
declare i64 @"memmove"(i64, i64, i64)
declare void @llvm.trap()
define { i64, i64 } @"mech_compact_numeric_6633"(i64 %v0, i64 %v1, i64 %v2) #0 align 128 {
block0:
  %ss0 = alloca [48 x i8], align 8
  %ss1 = alloca [48 x i8], align 8
  %v3 = add i64 0, 0
  %t0 = inttoptr i64 %v1 to ptr
  %t1 = getelementptr i8, ptr %t0, i64 96
  %v5 = load i64, ptr %t1, align 1
  %t2 = inttoptr i64 %v1 to ptr
  %t3 = getelementptr i8, ptr %t2, i64 104
  %v6 = load i64, ptr %t3, align 1
  %v8 = add i64 0, 0
  %v9 = add i64 0, 0
  %v10 = add i64 0, 1
  %v11 = add i64 0, 259
  %v12 = add i64 0, 515
  %v13 = add i64 0, 8
  %v14 = add i64 0, 9
  %v15 = add i64 0, 16
  %v16 = add i64 0, 547
  %v17 = add i64 0, 78
  %v18 = add i64 0, 4294967295
  %t4 = inttoptr i64 %v1 to ptr
  %v21 = load i64, ptr %t4, align 1
  %t5 = inttoptr i64 %v1 to ptr
  %t6 = getelementptr i8, ptr %t5, i64 8
  %v22 = load i64, ptr %t6, align 1
  %t7 = inttoptr i64 %v1 to ptr
  %t8 = getelementptr i8, ptr %t7, i64 16
  %v23 = load i64, ptr %t8, align 1
  %t9 = inttoptr i64 %v1 to ptr
  %t10 = getelementptr i8, ptr %t9, i64 24
  %v24 = load i64, ptr %t10, align 1
  %t11 = inttoptr i64 %v1 to ptr
  %t12 = getelementptr i8, ptr %t11, i64 32
  %v25 = load i64, ptr %t12, align 1
  %t13 = inttoptr i64 %v1 to ptr
  %t14 = getelementptr i8, ptr %t13, i64 40
  %v26 = load i64, ptr %t14, align 1
  %t15 = inttoptr i64 %v1 to ptr
  %t16 = getelementptr i8, ptr %t15, i64 48
  %v27 = load i64, ptr %t16, align 1
  %t17 = inttoptr i64 %v1 to ptr
  %t18 = getelementptr i8, ptr %t17, i64 56
  %v28 = load i64, ptr %t18, align 1
  %t19 = inttoptr i64 %v1 to ptr
  %t20 = getelementptr i8, ptr %t19, i64 64
  %v29 = load i64, ptr %t20, align 1
  %t21 = inttoptr i64 %v1 to ptr
  %t22 = getelementptr i8, ptr %t21, i64 72
  %v30 = load i64, ptr %t22, align 1
  %t23 = inttoptr i64 %v1 to ptr
  %t24 = getelementptr i8, ptr %t23, i64 80
  %v31 = load i64, ptr %t24, align 1
  %t25 = inttoptr i64 %v1 to ptr
  %t26 = getelementptr i8, ptr %t25, i64 88
  %v32 = load i64, ptr %t26, align 1
  br label %edge0
block6:
  %v428 = phi i64 [ %v24, %edge0 ], [ %v382, %edge2 ]
  br label %edge1
block7:
  br label %edge2
block8:
  br label %edge3
block10:
  br label %edge4
block11:
  br label %edge5
block12:
  br label %edge6
block13:
  br label %edge7
block14:
  br label %edge8
block15:
  br label %edge9
block16:
  br label %edge10
block17:
  %t27 = icmp ult i64 %v428, %v16
  %v70 = zext i1 %t27 to i8
  br label %edge11
block18:
  %v707 = and i8 %v70, 1
  %t28 = icmp ne i8 %v707, 0
  br i1 %t28, label %edge12, label %edge13
block19:
  %v438 = phi i64 [ %v102, %edge24 ], [ %v8, %edge26 ]
  %v443 = phi i64 [ %v428, %edge24 ], [ %v428, %edge26 ]
  %v714 = phi i8 [ %v715, %edge24 ], [ %v716, %edge26 ]
  br label %edge14
block20:
  br label %edge15
block21:
  br label %edge16
block22:
  %v87 = add i64 %v428, %v10
  br label %edge17
block123:
  br label %edge18
block23:
  %v94 = add i64 %v87, 18446744073709551615
  %t29 = icmp ult i64 %v94, %v30
  %v95 = zext i1 %t29 to i8
  %t30 = icmp ne i8 %v95, 0
  br i1 %t30, label %edge19, label %edge20
block126:
  %v96 = add i64 0, 103169
  br label %edge21
block125:
  %v99 = mul i64 %v94, 2
  %v101 = add i64 %v29, %v99
  %t31 = inttoptr i64 %v101 to ptr
  %t32 = load i16, ptr %t31, align 1
  %v102 = zext i16 %t32 to i64
  br label %edge22
block124:
  %v103 = add i64 0, 6651
  %t33 = inttoptr i64 %v2 to ptr
  store i64 %v103, ptr %t33, align 1
  br label %edge23
block24:
  %v715 = add i8 0, 1
  br label %edge24
block26:
  br label %edge25
block27:
  %v716 = add i8 0, 0
  br label %edge26
block28:
  br label %edge27
block29:
  %v120 = and i64 %v14, 63
  %t34 = and i64 %v120, 63
  %v121 = lshr i64 %v438, %t34
  br label %edge28
block30:
  %t35 = icmp ult i64 %v443, %v11
  %v126 = zext i1 %t35 to i8
  br label %edge29
block31:
  %v708 = and i8 %v126, 1
  %t36 = icmp ne i8 %v708, 0
  br i1 %t36, label %edge30, label %edge31
block32:
  %v581 = phi i64 [ %v22, %edge35 ], [ %v463, %edge46 ]
  br label %edge32
block33:
  br label %edge33
block34:
  br label %edge34
block35:
  br label %edge35
block37:
  br label %edge36
block38:
  %t37 = icmp ult i64 %v443, %v12
  %v151 = zext i1 %t37 to i8
  br label %edge37
block39:
  %v709 = and i8 %v151, 1
  %t38 = icmp ne i8 %v709, 0
  br i1 %t38, label %edge38, label %edge39
block40:
  %v463 = phi i64 [ %v21, %edge43 ], [ %v17, %edge45 ]
  br label %edge40
block41:
  br label %edge41
block42:
  br label %edge42
block43:
  br label %edge43
block45:
  br label %edge44
block46:
  br label %edge45
block47:
  br label %edge46
block48:
  %v710 = and i8 %v714, 1
  %t39 = icmp ne i8 %v710, 0
  br i1 %t39, label %edge47, label %edge48
block49:
  %v582 = phi i64 [ %v506, %edge71 ], [ %v9, %edge73 ]
  %v717 = phi i8 [ %v718, %edge71 ], [ %v719, %edge73 ]
  br label %edge49
block50:
  br label %edge50
block51:
  br label %edge51
block52:
  br label %edge52
block53:
  br label %edge53
block54:
  br label %edge54
block55:
  br label %edge55
block56:
  br label %edge56
block57:
  br label %edge57
block58:
  br label %edge58
block59:
  %t40 = icmp ult i64 %v443, %v26
  %v210 = zext i1 %t40 to i8
  br label %edge59
block60:
  %v711 = and i8 %v210, 1
  %t41 = icmp ne i8 %v711, 0
  br i1 %t41, label %edge60, label %edge61
block61:
  %v506 = phi i64 [ %v238, %edge67 ], [ %v9, %edge69 ]
  br label %edge62
block62:
  br label %edge63
block63:
  br label %edge64
block64:
  %v227 = add i64 %v443, %v10
  br label %edge65
block65:
  %v232 = add i64 %v227, 18446744073709551615
  %v235 = mul i64 %v232, 4
  %v237 = add i64 %v25, %v235
  %t42 = inttoptr i64 %v237 to ptr
  %t43 = load i32, ptr %t42, align 1
  %v238 = zext i32 %t43 to i64
  br label %edge66
block66:
  br label %edge67
block68:
  br label %edge68
block69:
  br label %edge69
block70:
  br label %edge70
block71:
  %v718 = add i8 0, 1
  br label %edge71
block73:
  br label %edge72
block74:
  %v719 = add i8 0, 0
  br label %edge73
block75:
  %t44 = zext i64 %v121 to i128
  %t45 = zext i64 %v15 to i128
  %t46 = mul i128 %t44, %t45
  %t47 = lshr i128 %t46, 64
  %v268 = trunc i128 %t47 to i64
  %t48 = icmp eq i64 %v268, 0
  %v269 = zext i1 %t48 to i8
  %v270 = add i64 0, 1
  %t49 = icmp ne i8 %v269, 0
  br i1 %t49, label %edge74, label %edge75
block179:
  %v271 = mul i64 %v121, %v15
  br label %edge76
block178:
  %v272 = add i64 0, 6704
  %t50 = inttoptr i64 %v2 to ptr
  store i64 %v272, ptr %t50, align 1
  br label %edge77
block76:
  %v276 = add i64 %v581, %v271
  %t51 = icmp uge i64 %v276, %v581
  %v277 = zext i1 %t51 to i8
  %v278 = add i64 0, 1
  %t52 = icmp ne i8 %v277, 0
  br i1 %t52, label %edge78, label %edge79
block181:
  br label %edge80
block180:
  %v279 = add i64 0, 6705
  %t53 = inttoptr i64 %v2 to ptr
  store i64 %v279, ptr %t53, align 1
  br label %edge81
block77:
  br label %edge82
block78:
  %t54 = zext i64 %v276 to i128
  %t55 = zext i64 %v23 to i128
  %t56 = mul i128 %t54, %t55
  %t57 = lshr i128 %t56, 64
  %v286 = trunc i128 %t57 to i64
  %t58 = icmp eq i64 %v286, 0
  %v287 = zext i1 %t58 to i8
  %v288 = add i64 0, 1
  %t59 = icmp ne i8 %v287, 0
  br i1 %t59, label %edge83, label %edge84
block184:
  %v289 = mul i64 %v276, %v23
  br label %edge85
block183:
  %v290 = add i64 0, 6707
  %t60 = inttoptr i64 %v2 to ptr
  store i64 %v290, ptr %t60, align 1
  br label %edge86
block79:
  %t61 = icmp uge i64 %v13, %v23
  %v294 = zext i1 %t61 to i8
  %v295 = add i64 0, 1
  %t62 = icmp ne i8 %v294, 0
  br i1 %t62, label %edge87, label %edge88
block186:
  %v296 = sub i64 %v13, %v23
  br label %edge89
block185:
  %v297 = add i64 0, 6708
  %t63 = inttoptr i64 %v2 to ptr
  store i64 %v297, ptr %t63, align 1
  br label %edge90
block80:
  %t64 = zext i64 %v582 to i128
  %t65 = zext i64 %v296 to i128
  %t66 = mul i128 %t64, %t65
  %t67 = lshr i128 %t66, 64
  %v300 = trunc i128 %t67 to i64
  %t68 = icmp eq i64 %v300, 0
  %v301 = zext i1 %t68 to i8
  %v302 = add i64 0, 1
  %t69 = icmp ne i8 %v301, 0
  br i1 %t69, label %edge91, label %edge92
block188:
  %v303 = mul i64 %v582, %v296
  br label %edge93
block187:
  %v304 = add i64 0, 6709
  %t70 = inttoptr i64 %v2 to ptr
  store i64 %v304, ptr %t70, align 1
  br label %edge94
block81:
  %v308 = add i64 %v289, %v303
  %t71 = icmp uge i64 %v308, %v289
  %v309 = zext i1 %t71 to i8
  %v310 = add i64 0, 1
  %t72 = icmp ne i8 %v309, 0
  br i1 %t72, label %edge95, label %edge96
block190:
  br label %edge97
block189:
  %v311 = add i64 0, 6710
  %t73 = inttoptr i64 %v2 to ptr
  store i64 %v311, ptr %t73, align 1
  br label %edge98
block82:
  br label %edge99
block192:
  %t74 = icmp eq i64 %v13, 0
  br i1 %t74, label %trap75, label %ok75
trap75:
  call void @llvm.trap()
  unreachable
ok75:
  %v317 = udiv i64 %v308, %v13
  br label %edge100
block83:
  %v322 = and i64 %v317, %v18
  br label %edge101
block84:
  br label %edge102
block195:
  br label %edge103
block85:
  %v712 = and i8 %v717, 1
  %t76 = icmp ne i8 %v712, 0
  br i1 %t76, label %edge104, label %edge105
block86:
  %v536 = phi i64 [ %v443, %edge116 ]
  br label %edge106
block88:
  br label %edge107
block89:
  %v343 = add i64 %v443, %v10
  br label %edge108
block90:
  %v348 = add i64 %v343, 18446744073709551615
  %t77 = icmp ult i64 %v348, %v26
  %v349 = zext i1 %t77 to i8
  %t78 = icmp ne i8 %v349, 0
  br i1 %t78, label %edge109, label %edge110
block203:
  %v350 = add i64 0, 103169
  br label %edge111
block202:
  %v353 = mul i64 %v348, 4
  %v355 = add i64 %v25, %v353
  br label %edge112
block205:
  %v357 = trunc i64 %v322 to i32
  %t79 = inttoptr i64 %v355 to ptr
  store i32 %v357, ptr %t79, align 1
  br label %edge113
block204:
  br label %edge114
block201:
  %v358 = add i64 0, 6719
  %t80 = inttoptr i64 %v2 to ptr
  store i64 %v358, ptr %t80, align 1
  br label %edge115
block91:
  br label %edge116
block95:
  br label %edge117
block98:
  br label %edge118
block99:
  %v382 = add i64 %v536, %v10
  br label %edge119
block215:
  br label %edge120
block100:
  br label %edge121
block101:
  br label %edge122
block3:
  %t81 = inttoptr i64 %v2 to ptr
  %t82 = getelementptr i8, ptr %t81, i64 8
  store i64 %v25, ptr %t82, align 1
  %t83 = inttoptr i64 %v2 to ptr
  %t84 = getelementptr i8, ptr %t83, i64 16
  store i64 %v26, ptr %t84, align 1
  %t85 = inttoptr i64 %v2 to ptr
  %t86 = getelementptr i8, ptr %t85, i64 24
  store i64 %v27, ptr %t86, align 1
  %t87 = inttoptr i64 %v2 to ptr
  %t88 = getelementptr i8, ptr %t87, i64 32
  store i64 %v28, ptr %t88, align 1
  %t89 = inttoptr i64 %v2 to ptr
  %t90 = getelementptr i8, ptr %t89, i64 40
  store i64 %v25, ptr %t90, align 1
  %t91 = inttoptr i64 %v2 to ptr
  %t92 = getelementptr i8, ptr %t91, i64 48
  store i64 %v26, ptr %t92, align 1
  %t93 = inttoptr i64 %v2 to ptr
  %t94 = getelementptr i8, ptr %t93, i64 56
  store i64 %v6, ptr %t94, align 1
  %t95 = inttoptr i64 %v2 to ptr
  %t96 = getelementptr i8, ptr %t95, i64 64
  store i64 %v27, ptr %t96, align 1
  %t97 = inttoptr i64 %v2 to ptr
  %t98 = getelementptr i8, ptr %t97, i64 72
  store i64 %v28, ptr %t98, align 1
  %t99 = inttoptr i64 %v2 to ptr
  %t100 = getelementptr i8, ptr %t99, i64 80
  store i64 %v5, ptr %t100, align 1
  br label %edge123
block5:
  %v35 = phi i64 [ %v96, %edge23 ], [ %v270, %edge77 ], [ %v278, %edge81 ], [ %v288, %edge86 ], [ %v295, %edge90 ], [ %v302, %edge94 ], [ %v310, %edge98 ], [ %v350, %edge115 ]
  br label %edge124
block2:
  %t101 = insertvalue { i64, i64 } poison, i64 %v3, 0
  %t102 = insertvalue { i64, i64 } %t101, i64 %v3, 1
  ret { i64, i64 } %t102
block1:
  %v4 = phi i64 [ %v35, %edge124 ]
  %t103 = inttoptr i64 %v2 to ptr
  %v414 = load i64, ptr %t103, align 1
  %t104 = insertvalue { i64, i64 } poison, i64 %v4, 0
  %t105 = insertvalue { i64, i64 } %t104, i64 %v414, 1
  ret { i64, i64 } %t105
edge0:
  br label %block6
edge1:
  br label %block8
edge2:
  br label %block6
edge3:
  br label %block10
edge4:
  br label %block11
edge5:
  br label %block12
edge6:
  br label %block13
edge7:
  br label %block14
edge8:
  br label %block15
edge9:
  br label %block16
edge10:
  br label %block17
edge11:
  br label %block18
edge12:
  br label %block21
edge13:
  br label %block20
edge14:
  br label %block28
edge15:
  br label %block26
edge16:
  br label %block22
edge17:
  br label %block123
edge18:
  br label %block23
edge19:
  br label %block125
edge20:
  br label %block126
edge21:
  br label %block124
edge22:
  br label %block24
edge23:
  br label %block5
edge24:
  br label %block19
edge25:
  br label %block27
edge26:
  br label %block19
edge27:
  br label %block29
edge28:
  br label %block30
edge29:
  br label %block31
edge30:
  br label %block34
edge31:
  br label %block33
edge32:
  br label %block48
edge33:
  br label %block37
edge34:
  br label %block35
edge35:
  br label %block32
edge36:
  br label %block38
edge37:
  br label %block39
edge38:
  br label %block42
edge39:
  br label %block41
edge40:
  br label %block47
edge41:
  br label %block45
edge42:
  br label %block43
edge43:
  br label %block40
edge44:
  br label %block46
edge45:
  br label %block40
edge46:
  br label %block32
edge47:
  br label %block51
edge48:
  br label %block50
edge49:
  br label %block75
edge50:
  br label %block73
edge51:
  br label %block52
edge52:
  br label %block53
edge53:
  br label %block55
edge54:
  br label %block71
edge55:
  br label %block56
edge56:
  br label %block57
edge57:
  br label %block58
edge58:
  br label %block59
edge59:
  br label %block60
edge60:
  br label %block63
edge61:
  br label %block62
edge62:
  br label %block70
edge63:
  br label %block68
edge64:
  br label %block64
edge65:
  br label %block65
edge66:
  br label %block66
edge67:
  br label %block61
edge68:
  br label %block69
edge69:
  br label %block61
edge70:
  br label %block54
edge71:
  br label %block49
edge72:
  br label %block74
edge73:
  br label %block49
edge74:
  br label %block179
edge75:
  br label %block178
edge76:
  br label %block76
edge77:
  br label %block5
edge78:
  br label %block181
edge79:
  br label %block180
edge80:
  br label %block77
edge81:
  br label %block5
edge82:
  br label %block78
edge83:
  br label %block184
edge84:
  br label %block183
edge85:
  br label %block79
edge86:
  br label %block5
edge87:
  br label %block186
edge88:
  br label %block185
edge89:
  br label %block80
edge90:
  br label %block5
edge91:
  br label %block188
edge92:
  br label %block187
edge93:
  br label %block81
edge94:
  br label %block5
edge95:
  br label %block190
edge96:
  br label %block189
edge97:
  br label %block82
edge98:
  br label %block5
edge99:
  br label %block192
edge100:
  br label %block83
edge101:
  br label %block84
edge102:
  br label %block195
edge103:
  br label %block85
edge104:
  br label %block88
edge105:
  br label %block3
edge106:
  br label %block95
edge107:
  br label %block89
edge108:
  br label %block90
edge109:
  br label %block202
edge110:
  br label %block203
edge111:
  br label %block201
edge112:
  br label %block205
edge113:
  br label %block204
edge114:
  br label %block91
edge115:
  br label %block5
edge116:
  br label %block86
edge117:
  br label %block98
edge118:
  br label %block99
edge119:
  br label %block215
edge120:
  br label %block100
edge121:
  br label %block101
edge122:
  br label %block7
edge123:
  br label %block2
edge124:
  br label %block1
}

attributes #0 = { noinline uwtable "frame-pointer"="all" }
