target triple = "arm64-apple-macosx26.0.0"

declare i64 @"mech_compact_allocate"(i64, i64, i64, i64, i64, i64)
declare i64 @"mech_compact_free"(i64, i64)
declare i64 @"mech_compact_writable"(i64, i64, i64, i64, i64, i64, i64)
declare i64 @"memmove"(i64, i64, i64)

define { i64, i64 } @"mech_compact_numeric_4673_vector"(i64 %v0, i64 %v1, i64 %v2) #0 align 128 {
block0:
  %ss0 = alloca [48 x i8], align 8
  %ss1 = alloca [48 x i8], align 8
  %v3 = add i64 0, 0
  %v8 = add i64 0, 0
  %v9 = add i64 0, 0
  %v10 = add i64 0, 1
  %v11 = add i64 0, 16
  %v12 = add i64 0, 1023
  %v13 = add i64 0, 4294967295
  %t0 = inttoptr i64 %v1 to ptr
  %v16 = load i64, ptr %t0, align 1
  %t1 = inttoptr i64 %v1 to ptr
  %t2 = getelementptr i8, ptr %t1, i64 8
  %v17 = load i64, ptr %t2, align 1
  %t3 = inttoptr i64 %v1 to ptr
  %t4 = getelementptr i8, ptr %t3, i64 16
  %v18 = load i64, ptr %t4, align 1
  %t5 = inttoptr i64 %v1 to ptr
  %t6 = getelementptr i8, ptr %t5, i64 24
  %v19 = load i64, ptr %t6, align 1
  %t7 = inttoptr i64 %v1 to ptr
  %t8 = getelementptr i8, ptr %t7, i64 32
  %v20 = load i64, ptr %t8, align 1
  %t9 = inttoptr i64 %v1 to ptr
  %t10 = getelementptr i8, ptr %t9, i64 40
  %v21 = load i64, ptr %t10, align 1
  %t11 = inttoptr i64 %v1 to ptr
  %t12 = getelementptr i8, ptr %t11, i64 48
  %v22 = load i64, ptr %t12, align 1
  %t13 = inttoptr i64 %v1 to ptr
  %t14 = getelementptr i8, ptr %t13, i64 56
  %v23 = load i64, ptr %t14, align 1
  %t15 = inttoptr i64 %v1 to ptr
  %t16 = getelementptr i8, ptr %t15, i64 64
  %v24 = load i64, ptr %t16, align 1
  %t17 = inttoptr i64 %v1 to ptr
  %t18 = getelementptr i8, ptr %t17, i64 72
  %v25 = load i64, ptr %t18, align 1
  %t19 = inttoptr i64 %v1 to ptr
  %t20 = getelementptr i8, ptr %t19, i64 80
  %v26 = load i64, ptr %t20, align 1
  %t21 = inttoptr i64 %v1 to ptr
  %t22 = getelementptr i8, ptr %t21, i64 88
  %v27 = load i64, ptr %t22, align 1
  %t23 = inttoptr i64 %v1 to ptr
  %t24 = getelementptr i8, ptr %t23, i64 96
  %v28 = load i64, ptr %t24, align 1
  %t25 = inttoptr i64 %v1 to ptr
  %t26 = getelementptr i8, ptr %t25, i64 104
  %v29 = load i64, ptr %t26, align 1
  br label %edge0
block6:
  %v412 = phi i64 [ %v16, %edge0 ], [ %v375, %edge2 ]
  %v413 = phi i64 [ %v17, %edge0 ], [ %v613, %edge2 ]
  br label %edge1
block7:
  br label %edge2
block8:
  br label %edge3
block9:
  br label %edge4
block10:
  br label %edge5
block11:
  br label %edge6
block12:
  br label %edge7
block13:
  br label %edge8
block14:
  br label %edge9
block15:
  br label %edge10
block16:
  %t27 = icmp uge i64 %v412, %v10
  %v62 = zext i1 %t27 to i8
  br label %edge11
block17:
  %v608 = and i8 %v62, 1
  %t28 = icmp ne i8 %v608, 0
  br i1 %t28, label %edge12, label %edge13
block18:
  %v508 = phi i64 [ %v432, %edge97 ], [ %v413, %edge100 ]
  %v514 = phi i64 [ %v412, %edge97 ], [ %v412, %edge100 ]
  br label %edge14
block19:
  br label %edge15
block20:
  br label %edge16
block21:
  br label %edge17
block22:
  br label %edge18
block23:
  br label %edge19
block24:
  br label %edge20
block25:
  br label %edge21
block26:
  br label %edge22
block27:
  br label %edge23
block28:
  %t29 = icmp ult i64 %v412, %v27
  %v96 = zext i1 %t29 to i8
  br label %edge24
block29:
  %v609 = and i8 %v96, 1
  %t30 = icmp ne i8 %v609, 0
  br i1 %t30, label %edge25, label %edge26
block30:
  br label %edge27
block32:
  br label %edge28
block33:
  %v113 = add i64 %v412, %v10
  br label %edge29
block34:
  %v118 = add i64 %v113, 18446744073709551615
  %v121 = mul i64 %v118, 8
  %v123 = add i64 %v26, %v121
  %t31 = inttoptr i64 %v123 to ptr
  %v124 = load i64, ptr %t31, align 1
  br label %edge30
block35:
  br label %edge31
block39:
  br label %edge32
block40:
  br label %edge33
block41:
  br label %edge34
block42:
  %v432 = phi i64 [ %v413, %edge34 ], [ %v302, %edge36 ]
  %v433 = phi i64 [ %v124, %edge34 ], [ %v311, %edge36 ]
  br label %edge35
block43:
  br label %edge36
block44:
  br label %edge37
block45:
  br label %edge38
block46:
  br label %edge39
block47:
  br label %edge40
block48:
  br label %edge41
block49:
  br label %edge42
block50:
  br label %edge43
block51:
  br label %edge44
block52:
  %t32 = icmp ugt i64 %v433, %v9
  %v179 = zext i1 %t32 to i8
  br label %edge45
block53:
  %v610 = and i8 %v179, 1
  %t33 = icmp ne i8 %v610, 0
  br i1 %t33, label %edge46, label %edge47
block54:
  br label %edge48
block55:
  br label %edge49
block56:
  br label %edge50
block57:
  br label %edge51
block58:
  br label %edge52
block59:
  br label %edge53
block60:
  br label %edge54
block61:
  br label %edge55
block62:
  br label %edge56
block63:
  br label %edge57
block64:
  %t34 = icmp ult i64 %v432, %v19
  %v213 = zext i1 %t34 to i8
  br label %edge58
block65:
  %v611 = and i8 %v213, 1
  %t35 = icmp ne i8 %v611, 0
  br i1 %t35, label %edge59, label %edge60
block66:
  %v468 = phi i64 [ %v241, %edge66 ], [ %v8, %edge68 ]
  br label %edge61
block67:
  br label %edge62
block68:
  br label %edge63
block69:
  %v230 = add i64 %v432, %v10
  br label %edge64
block70:
  %v235 = add i64 %v230, 18446744073709551615
  %v238 = mul i64 %v235, 4
  %v240 = add i64 %v18, %v238
  %t36 = inttoptr i64 %v240 to ptr
  %t37 = load i32, ptr %t36, align 1
  %v241 = zext i32 %t37 to i64
  br label %edge65
block71:
  br label %edge66
block73:
  br label %edge67
block74:
  br label %edge68
block75:
  br label %edge69
block76:
  br label %edge70
block77:
  %v262 = and i64 %v468, %v12
  br label %edge71
block78:
  %v267 = and i64 %v11, 63
  %t38 = and i64 %v267, 63
  %v268 = shl i64 %v412, %t38
  br label %edge72
block79:
  %v273 = and i64 %v268, %v13
  br label %edge73
block80:
  br label %edge74
block186:
  br label %edge75
block81:
  %v283 = add i64 %v262, %v10
  br label %edge76
block82:
  %v288 = add i64 %v283, 18446744073709551615
  %t39 = icmp ult i64 %v288, %v23
  %v289 = zext i1 %t39 to i8
  %t40 = icmp ne i8 %v289, 0
  br i1 %t40, label %edge77, label %edge78
block190:
  %v290 = add i64 0, 103169
  br label %edge79
block189:
  %v293 = mul i64 %v288, 4
  %v295 = add i64 %v22, %v293
  br label %edge80
block192:
  %v297 = trunc i64 %v273 to i32
  %t41 = inttoptr i64 %v295 to ptr
  store i32 %v297, ptr %t41, align 1
  br label %edge81
block191:
  br label %edge82
block188:
  %v298 = add i64 0, 4753
  %t42 = inttoptr i64 %v2 to ptr
  store i64 %v298, ptr %t42, align 1
  br label %edge83
block83:
  %v302 = add i64 %v432, %v10
  %t43 = icmp uge i64 %v302, %v432
  %v303 = zext i1 %t43 to i8
  %v304 = add i64 0, 1
  %t44 = icmp ne i8 %v303, 0
  br i1 %t44, label %edge84, label %edge85
block194:
  br label %edge86
block193:
  %v305 = add i64 0, 4754
  %t45 = inttoptr i64 %v2 to ptr
  store i64 %v305, ptr %t45, align 1
  br label %edge87
block84:
  br label %edge88
block196:
  %v311 = sub i64 %v433, %v10
  br label %edge89
block85:
  br label %edge90
block86:
  br label %edge91
block88:
  br label %edge92
block89:
  br label %edge93
block90:
  br label %edge94
block91:
  br label %edge95
block92:
  br label %edge96
block93:
  br label %edge97
block95:
  br label %edge98
block96:
  br label %edge99
block97:
  br label %edge100
block98:
  br label %edge101
block99:
  br label %edge102
block100:
  %v613 = phi i64 [ %v413, %edge26 ], [ %v508, %edge102 ]
  %v614 = phi i64 [ %v412, %edge26 ], [ %v514, %edge102 ]
  %v612 = and i8 %v62, 1
  %t46 = icmp ne i8 %v612, 0
  br i1 %t46, label %edge103, label %edge104
block101:
  br label %edge105
block102:
  br label %edge106
block103:
  br label %edge107
block104:
  %t47 = icmp uge i64 %v614, %v10
  %v373 = zext i1 %t47 to i8
  %v374 = add i64 0, 1
  %t48 = icmp ne i8 %v373, 0
  br i1 %t48, label %edge108, label %edge109
block217:
  %v375 = sub i64 %v614, %v10
  br label %edge110
block216:
  %v376 = add i64 0, 4775
  %t49 = inttoptr i64 %v2 to ptr
  store i64 %v376, ptr %t49, align 1
  br label %edge111
block105:
  br label %edge112
block106:
  br label %edge113
block108:
  br label %edge114
block109:
  br label %edge115
block110:
  br label %edge116
block3:
  %t50 = inttoptr i64 %v2 to ptr
  %t51 = getelementptr i8, ptr %t50, i64 8
  store i64 %v22, ptr %t51, align 1
  %t52 = inttoptr i64 %v2 to ptr
  %t53 = getelementptr i8, ptr %t52, i64 16
  store i64 %v23, ptr %t53, align 1
  %t54 = inttoptr i64 %v2 to ptr
  %t55 = getelementptr i8, ptr %t54, i64 24
  store i64 %v24, ptr %t55, align 1
  %t56 = inttoptr i64 %v2 to ptr
  %t57 = getelementptr i8, ptr %t56, i64 32
  store i64 %v25, ptr %t57, align 1
  %t58 = inttoptr i64 %v2 to ptr
  %t59 = getelementptr i8, ptr %t58, i64 40
  store i64 %v22, ptr %t59, align 1
  %t60 = inttoptr i64 %v2 to ptr
  %t61 = getelementptr i8, ptr %t60, i64 48
  store i64 %v23, ptr %t61, align 1
  %t62 = inttoptr i64 %v1 to ptr
  %t63 = getelementptr i8, ptr %t62, i64 120
  %v6 = load i64, ptr %t63, align 1
  %t64 = inttoptr i64 %v2 to ptr
  %t65 = getelementptr i8, ptr %t64, i64 56
  store i64 %v6, ptr %t65, align 1
  %t66 = inttoptr i64 %v2 to ptr
  %t67 = getelementptr i8, ptr %t66, i64 64
  store i64 %v24, ptr %t67, align 1
  %t68 = inttoptr i64 %v2 to ptr
  %t69 = getelementptr i8, ptr %t68, i64 72
  store i64 %v25, ptr %t69, align 1
  %t70 = inttoptr i64 %v1 to ptr
  %t71 = getelementptr i8, ptr %t70, i64 112
  %v5 = load i64, ptr %t71, align 1
  %t72 = inttoptr i64 %v2 to ptr
  %t73 = getelementptr i8, ptr %t72, i64 80
  store i64 %v5, ptr %t73, align 1
  br label %edge117
block5:
  %v33 = phi i64 [ %v290, %edge83 ], [ %v304, %edge87 ], [ %v374, %edge111 ]
  br label %edge118
block2:
  %t74 = insertvalue { i64, i64 } poison, i64 %v3, 0
  %t75 = insertvalue { i64, i64 } %t74, i64 %v3, 1
  ret { i64, i64 } %t75
block1:
  %v4 = phi i64 [ %v33, %edge118 ]
  %t76 = inttoptr i64 %v2 to ptr
  %v401 = load i64, ptr %t76, align 1
  %t77 = insertvalue { i64, i64 } poison, i64 %v4, 0
  %t78 = insertvalue { i64, i64 } %t77, i64 %v401, 1
  ret { i64, i64 } %t78
edge0:
  br label %block6
edge1:
  br label %block8
edge2:
  br label %block6
edge3:
  br label %block10
edge4:
  br label %block3
edge5:
  br label %block11
edge6:
  br label %block12
edge7:
  br label %block13
edge8:
  br label %block14
edge9:
  br label %block15
edge10:
  br label %block16
edge11:
  br label %block17
edge12:
  br label %block20
edge13:
  br label %block19
edge14:
  br label %block98
edge15:
  br label %block95
edge16:
  br label %block21
edge17:
  br label %block22
edge18:
  br label %block24
edge19:
  br label %block40
edge20:
  br label %block25
edge21:
  br label %block26
edge22:
  br label %block27
edge23:
  br label %block28
edge24:
  br label %block29
edge25:
  br label %block32
edge26:
  br label %block100
edge27:
  br label %block39
edge28:
  br label %block33
edge29:
  br label %block34
edge30:
  br label %block35
edge31:
  br label %block30
edge32:
  br label %block23
edge33:
  br label %block41
edge34:
  br label %block42
edge35:
  br label %block44
edge36:
  br label %block42
edge37:
  br label %block46
edge38:
  br label %block92
edge39:
  br label %block47
edge40:
  br label %block48
edge41:
  br label %block49
edge42:
  br label %block50
edge43:
  br label %block51
edge44:
  br label %block52
edge45:
  br label %block53
edge46:
  br label %block56
edge47:
  br label %block55
edge48:
  br label %block91
edge49:
  br label %block88
edge50:
  br label %block57
edge51:
  br label %block58
edge52:
  br label %block60
edge53:
  br label %block76
edge54:
  br label %block61
edge55:
  br label %block62
edge56:
  br label %block63
edge57:
  br label %block64
edge58:
  br label %block65
edge59:
  br label %block68
edge60:
  br label %block67
edge61:
  br label %block75
edge62:
  br label %block73
edge63:
  br label %block69
edge64:
  br label %block70
edge65:
  br label %block71
edge66:
  br label %block66
edge67:
  br label %block74
edge68:
  br label %block66
edge69:
  br label %block59
edge70:
  br label %block77
edge71:
  br label %block78
edge72:
  br label %block79
edge73:
  br label %block80
edge74:
  br label %block186
edge75:
  br label %block81
edge76:
  br label %block82
edge77:
  br label %block189
edge78:
  br label %block190
edge79:
  br label %block188
edge80:
  br label %block192
edge81:
  br label %block191
edge82:
  br label %block83
edge83:
  br label %block5
edge84:
  br label %block194
edge85:
  br label %block193
edge86:
  br label %block84
edge87:
  br label %block5
edge88:
  br label %block196
edge89:
  br label %block85
edge90:
  br label %block86
edge91:
  br label %block43
edge92:
  br label %block89
edge93:
  br label %block90
edge94:
  br label %block54
edge95:
  br label %block45
edge96:
  br label %block93
edge97:
  br label %block18
edge98:
  br label %block96
edge99:
  br label %block97
edge100:
  br label %block18
edge101:
  br label %block99
edge102:
  br label %block100
edge103:
  br label %block103
edge104:
  br label %block102
edge105:
  br label %block110
edge106:
  br label %block108
edge107:
  br label %block104
edge108:
  br label %block217
edge109:
  br label %block216
edge110:
  br label %block105
edge111:
  br label %block5
edge112:
  br label %block106
edge113:
  br label %block7
edge114:
  br label %block109
edge115:
  br label %block101
edge116:
  br label %block9
edge117:
  br label %block2
edge118:
  br label %block1
}

attributes #0 = { noinline uwtable "frame-pointer"="all" }
