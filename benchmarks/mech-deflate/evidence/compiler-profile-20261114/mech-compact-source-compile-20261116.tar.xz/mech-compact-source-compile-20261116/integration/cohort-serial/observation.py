from pathlib import Path
import json,subprocess,time,os,sys,hashlib,shutil,datetime,traceback
root=Path('/private/tmp/mech-compact-integration-20261116');repo=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech')
pilot=Path(sys.argv[1]);pilot.mkdir(exist_ok=False)
record={'state':'waiting_for_setup','pid':os.getpid(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def pin(path):
 with path.open('rb') as stream:return {'bytes':path.stat().st_size,'sha256':hashlib.file_digest(stream,'sha256').hexdigest()}
save(pilot/'job.json',record)
try:
 for job in ['build-job.json','preflight-job.json','adapter-job.json']:
  while json.loads((root/job).read_text())['state'] not in ['complete','failed']:time.sleep(1)
  assert json.loads((root/job).read_text())['exit_code']==0,job
 frontend=Path(sys.argv[2]);assert pin(frontend)['sha256'] in ['8043d93d27b948371aee38027df898a9024e47a1ffa112b47a1913f8329e40ad','fff62585955d94a490d58daec4bd11a448f973cc4fe90fd46965f01aee296075']
 fixtures=repo/'benchmarks/mech-deflate/native-profile/compact-size/fixtures'
 source=fixtures/'source.mec';out=pilot/'frontend';out.mkdir()
 env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')};env['ZERO_AR_DATE']='1'
 commands={'frontend':[str(frontend),str(source),str(out),'frontend'],'native':[sys.executable,'-B',str(root/'rebuild-profiled.py'),str(fixtures.parent/'rebuild.py'),str(pilot/'native-commands.json'),str(pilot/'native'),'--llvm-bin','/opt/homebrew/opt/llvm@22/bin','--emitter',str(root/'emit_compact_size'),'--program',str(out/'program.mecb'),'--compile-threads','0'],'link':json.loads((root/'link-command.json').read_text())}
 save(pilot/'commands.json',{'commands':commands,'frontend':pin(frontend),'emitter':pin(root/'emit_compact_size'),'scope':'One fresh source-to-runnable-executable observation in the declared balanced cohort. Source read, parse, checked frontend, canonical bytecode, fresh prepared Object and LLVM IR, LLVM optimization/codegen, assembly/composition and native executable link all included. Fixed generic runtime and entry adapter cached as in historical 13.41s boundary. No pinned Object or IR used as generated input. Compiler bootstrap excluded. Serial emitter, optimized parser frontend; balanced cohort, four observations per frontend.'})
 for item in json.loads((root/'link-inputs.json').read_text()):assert pin(Path(item['path']))=={k:item[k] for k in ['bytes','sha256']}
 record['state']='source_to_executable';save(pilot/'job.json',record)
 with (pilot/'frontend.stdout').open('w') as outlog,(pilot/'frontend.stderr').open('w') as err:
  start=time.perf_counter();r=subprocess.run(commands['frontend'],cwd=repo,env=env,stdout=outlog,stderr=err);front_done=time.perf_counter()
 assert r.returncode==0
 with (pilot/'native.stdout').open('w') as outlog,(pilot/'native.stderr').open('w') as err:r=subprocess.run(commands['native'],cwd=repo,env=env,stdout=outlog,stderr=err)
 native_done=time.perf_counter();assert r.returncode==0
 shutil.copy2(pilot/'native/program.o',root/'link/program.o')
 with (pilot/'link.stdout').open('w') as outlog,(pilot/'link.stderr').open('w') as err:
  link_start=time.perf_counter();r=subprocess.run(commands['link'],cwd=repo,env=env,stdout=outlog,stderr=err);end=time.perf_counter()
 assert r.returncode==0
 files={name:{**pin((pilot/'frontend' if name in ['source.mec','program.mecb'] else pilot/'native')/name),'matches_reference':((pilot/'frontend' if name in ['source.mec','program.mecb'] else pilot/'native')/name).read_bytes()==(Path('/private/tmp/mech-smaller39e-handoff-20261116')/name).read_bytes()} for name in ['source.mec','program.mecb','program.o','metadata.json']}
 image=pin(root/'link/worker');same=(root/'link/worker').read_bytes()==(root/'reference-worker').read_bytes();assert all(row['matches_reference'] for row in files.values()) and same
 shutil.copy2(root/'link/worker',pilot/'worker')
 result={'source_to_executable_seconds':end-start,'frontend_process_seconds':front_done-start,'native_recipe_seconds':native_done-front_done,'native_link_seconds':end-link_start,'handoff_seconds':link_start-native_done,'files':files,'executable':image,'complete_executable_matches_supplied_object_reference':same,'scope':'Complete observation from fixed ABBA/BAAB cohort. No heavy work overlaps this timer; all bootstrap/preflight/adapter jobs complete first. All program inputs freshly generated from source; fixed runtime and generic entry adapter cached.'}
 save(pilot/'result.json',result);record.update(state='complete',exit_code=0,source_to_executable_seconds=end-start)
except BaseException as error:record.update(state='failed',exit_code=1,error=repr(error));traceback.print_exc()
record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save(pilot/'job.json',record);print(json.dumps(record),flush=True);raise SystemExit(record['exit_code'])
