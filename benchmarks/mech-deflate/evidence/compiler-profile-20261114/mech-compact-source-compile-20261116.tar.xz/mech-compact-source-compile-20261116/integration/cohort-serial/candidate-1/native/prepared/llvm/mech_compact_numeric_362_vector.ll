target triple = "arm64-apple-macosx26.0.0"

declare i64 @"mech_compact_allocate"(i64, i64, i64, i64, i64, i64)
declare i64 @"mech_compact_free"(i64, i64)
declare i64 @"mech_compact_writable"(i64, i64, i64, i64, i64, i64, i64)
declare i64 @"memmove"(i64, i64, i64)

define { i64, i64 } @"mech_compact_numeric_362_vector"(i64 %v0, i64 %v1, i64 %v2) #0 align 128 {
block0:
  %ss0 = alloca [48 x i8], align 8
  %ss1 = alloca [48 x i8], align 8
  %v3 = add i64 0, 0
  %t0 = inttoptr i64 %v1 to ptr
  %t1 = getelementptr i8, ptr %t0, i64 88
  %v5 = load i64, ptr %t1, align 1
  %t2 = inttoptr i64 %v1 to ptr
  %t3 = getelementptr i8, ptr %t2, i64 96
  %v6 = load i64, ptr %t3, align 1
  %v8 = add i64 0, 0
  %v9 = add i64 0, 1
  %v10 = add i64 0, 1
  %t4 = inttoptr i64 %v1 to ptr
  %v13 = load i64, ptr %t4, align 1
  %t5 = inttoptr i64 %v1 to ptr
  %t6 = getelementptr i8, ptr %t5, i64 8
  %v14 = load i64, ptr %t6, align 1
  %t7 = inttoptr i64 %v1 to ptr
  %t8 = getelementptr i8, ptr %t7, i64 16
  %v15 = load i64, ptr %t8, align 1
  %t9 = inttoptr i64 %v1 to ptr
  %t10 = getelementptr i8, ptr %t9, i64 24
  %v16 = load i64, ptr %t10, align 1
  %t11 = inttoptr i64 %v1 to ptr
  %t12 = getelementptr i8, ptr %t11, i64 32
  %v17 = load i64, ptr %t12, align 1
  %t13 = inttoptr i64 %v1 to ptr
  %t14 = getelementptr i8, ptr %t13, i64 40
  %v18 = load i64, ptr %t14, align 1
  %t15 = inttoptr i64 %v1 to ptr
  %t16 = getelementptr i8, ptr %t15, i64 48
  %v19 = load i64, ptr %t16, align 1
  %t17 = inttoptr i64 %v1 to ptr
  %t18 = getelementptr i8, ptr %t17, i64 56
  %v20 = load i64, ptr %t18, align 1
  %t19 = inttoptr i64 %v1 to ptr
  %t20 = getelementptr i8, ptr %t19, i64 64
  %v21 = load i64, ptr %t20, align 1
  %t21 = inttoptr i64 %v1 to ptr
  %t22 = getelementptr i8, ptr %t21, i64 72
  %v22 = load i64, ptr %t22, align 1
  %t23 = inttoptr i64 %v1 to ptr
  %t24 = getelementptr i8, ptr %t23, i64 80
  %v23 = load i64, ptr %t24, align 1
  br label %edge0
block6:
  %v222 = phi i64 [ %v15, %edge0 ], [ %v179, %edge2 ]
  br label %edge1
block7:
  br label %edge2
block8:
  br label %edge3
block9:
  br label %edge4
block10:
  br label %edge5
block11:
  br label %edge6
block12:
  br label %edge7
block13:
  br label %edge8
block14:
  br label %edge9
block15:
  br label %edge10
block16:
  %t25 = icmp ult i64 %v222, %v14
  %v57 = zext i1 %t25 to i8
  br label %edge11
block17:
  %v314 = and i8 %v57, 1
  %t26 = icmp ne i8 %v314, 0
  br i1 %t26, label %edge12, label %edge13
block18:
  %v237 = phi i64 [ %v222, %edge46 ], [ %v222, %edge48 ]
  br label %edge14
block19:
  br label %edge15
block20:
  br label %edge16
block21:
  %v74 = add i64 %v13, %v222
  %t27 = icmp uge i64 %v74, %v13
  %v75 = zext i1 %t27 to i8
  %v76 = add i64 0, 1
  %t28 = icmp ne i8 %v75, 0
  br i1 %t28, label %edge17, label %edge18
block69:
  br label %edge19
block68:
  %v77 = add i64 0, 378
  %t29 = inttoptr i64 %v2 to ptr
  store i64 %v77, ptr %t29, align 1
  br label %edge20
block22:
  br label %edge21
block23:
  %t30 = icmp ult i64 %v74, %v21
  %v84 = zext i1 %t30 to i8
  br label %edge22
block24:
  %v315 = and i8 %v84, 1
  %t31 = icmp ne i8 %v315, 0
  br i1 %t31, label %edge23, label %edge24
block25:
  %v233 = phi i64 [ %v114, %edge32 ], [ %v8, %edge34 ]
  br label %edge25
block26:
  br label %edge26
block27:
  br label %edge27
block28:
  %v101 = add i64 %v74, %v9
  br label %edge28
block77:
  br label %edge29
block29:
  %v108 = add i64 %v101, 18446744073709551615
  %v113 = add i64 %v20, %v108
  %t32 = inttoptr i64 %v113 to ptr
  %t33 = load i8, ptr %t32, align 1
  %v114 = zext i8 %t33 to i64
  br label %edge30
block30:
  br label %edge31
block31:
  br label %edge32
block33:
  br label %edge33
block34:
  br label %edge34
block35:
  %v132 = add i64 %v233, %v9
  %t34 = icmp uge i64 %v132, %v233
  %v133 = zext i1 %t34 to i8
  %v134 = add i64 0, 1
  %t35 = icmp ne i8 %v133, 0
  br i1 %t35, label %edge35, label %edge36
block85:
  br label %edge37
block84:
  %v135 = add i64 0, 392
  %t36 = inttoptr i64 %v2 to ptr
  store i64 %v135, ptr %t36, align 1
  br label %edge38
block36:
  %v139 = add i64 %v132, 18446744073709551615
  %t37 = icmp ult i64 %v139, %v17
  %v140 = zext i1 %t37 to i8
  %t38 = icmp ne i8 %v140, 0
  br i1 %t38, label %edge39, label %edge40
block88:
  %v141 = add i64 0, 103169
  br label %edge41
block87:
  %v146 = add i64 %v16, %v139
  br label %edge42
block90:
  %v148 = trunc i64 %v10 to i8
  %t39 = inttoptr i64 %v146 to ptr
  store i8 %v148, ptr %t39, align 1
  br label %edge43
block89:
  br label %edge44
block86:
  %v149 = add i64 0, 393
  %t40 = inttoptr i64 %v2 to ptr
  store i64 %v149, ptr %t40, align 1
  br label %edge45
block37:
  br label %edge46
block39:
  br label %edge47
block40:
  br label %edge48
block41:
  %t41 = icmp ult i64 %v237, %v14
  %v162 = zext i1 %t41 to i8
  br label %edge49
block42:
  %v316 = and i8 %v162, 1
  %t42 = icmp ne i8 %v316, 0
  br i1 %t42, label %edge50, label %edge51
block43:
  br label %edge52
block44:
  br label %edge53
block45:
  br label %edge54
block46:
  %v179 = add i64 %v237, %v9
  br label %edge55
block101:
  br label %edge56
block47:
  br label %edge57
block48:
  br label %edge58
block50:
  br label %edge59
block51:
  br label %edge60
block52:
  br label %edge61
block3:
  %t43 = inttoptr i64 %v2 to ptr
  %t44 = getelementptr i8, ptr %t43, i64 8
  store i64 %v16, ptr %t44, align 1
  %t45 = inttoptr i64 %v2 to ptr
  %t46 = getelementptr i8, ptr %t45, i64 16
  store i64 %v17, ptr %t46, align 1
  %t47 = inttoptr i64 %v2 to ptr
  %t48 = getelementptr i8, ptr %t47, i64 24
  store i64 %v18, ptr %t48, align 1
  %t49 = inttoptr i64 %v2 to ptr
  %t50 = getelementptr i8, ptr %t49, i64 32
  store i64 %v19, ptr %t50, align 1
  %t51 = inttoptr i64 %v2 to ptr
  %t52 = getelementptr i8, ptr %t51, i64 40
  store i64 %v16, ptr %t52, align 1
  %t53 = inttoptr i64 %v2 to ptr
  %t54 = getelementptr i8, ptr %t53, i64 48
  store i64 %v17, ptr %t54, align 1
  %t55 = inttoptr i64 %v2 to ptr
  %t56 = getelementptr i8, ptr %t55, i64 56
  store i64 %v6, ptr %t56, align 1
  %t57 = inttoptr i64 %v2 to ptr
  %t58 = getelementptr i8, ptr %t57, i64 64
  store i64 %v18, ptr %t58, align 1
  %t59 = inttoptr i64 %v2 to ptr
  %t60 = getelementptr i8, ptr %t59, i64 72
  store i64 %v19, ptr %t60, align 1
  %t61 = inttoptr i64 %v2 to ptr
  %t62 = getelementptr i8, ptr %t61, i64 80
  store i64 %v5, ptr %t62, align 1
  br label %edge62
block5:
  %v26 = phi i64 [ %v76, %edge20 ], [ %v134, %edge38 ], [ %v141, %edge45 ]
  br label %edge63
block2:
  %t63 = insertvalue { i64, i64 } poison, i64 %v3, 0
  %t64 = insertvalue { i64, i64 } %t63, i64 %v3, 1
  ret { i64, i64 } %t64
block1:
  %v4 = phi i64 [ %v26, %edge63 ]
  %t65 = inttoptr i64 %v2 to ptr
  %v209 = load i64, ptr %t65, align 1
  %t66 = insertvalue { i64, i64 } poison, i64 %v4, 0
  %t67 = insertvalue { i64, i64 } %t66, i64 %v209, 1
  ret { i64, i64 } %t67
edge0:
  br label %block6
edge1:
  br label %block8
edge2:
  br label %block6
edge3:
  br label %block10
edge4:
  br label %block3
edge5:
  br label %block11
edge6:
  br label %block12
edge7:
  br label %block13
edge8:
  br label %block14
edge9:
  br label %block15
edge10:
  br label %block16
edge11:
  br label %block17
edge12:
  br label %block20
edge13:
  br label %block19
edge14:
  br label %block41
edge15:
  br label %block39
edge16:
  br label %block21
edge17:
  br label %block69
edge18:
  br label %block68
edge19:
  br label %block22
edge20:
  br label %block5
edge21:
  br label %block23
edge22:
  br label %block24
edge23:
  br label %block27
edge24:
  br label %block26
edge25:
  br label %block35
edge26:
  br label %block33
edge27:
  br label %block28
edge28:
  br label %block77
edge29:
  br label %block29
edge30:
  br label %block30
edge31:
  br label %block31
edge32:
  br label %block25
edge33:
  br label %block34
edge34:
  br label %block25
edge35:
  br label %block85
edge36:
  br label %block84
edge37:
  br label %block36
edge38:
  br label %block5
edge39:
  br label %block87
edge40:
  br label %block88
edge41:
  br label %block86
edge42:
  br label %block90
edge43:
  br label %block89
edge44:
  br label %block37
edge45:
  br label %block5
edge46:
  br label %block18
edge47:
  br label %block40
edge48:
  br label %block18
edge49:
  br label %block42
edge50:
  br label %block45
edge51:
  br label %block44
edge52:
  br label %block52
edge53:
  br label %block50
edge54:
  br label %block46
edge55:
  br label %block101
edge56:
  br label %block47
edge57:
  br label %block48
edge58:
  br label %block7
edge59:
  br label %block51
edge60:
  br label %block43
edge61:
  br label %block9
edge62:
  br label %block2
edge63:
  br label %block1
}

attributes #0 = { noinline uwtable "frame-pointer"="all" }
