target triple = "arm64-apple-macosx26.0.0"

declare i64 @"mech_compact_allocate"(i64, i64, i64, i64, i64, i64)
declare i64 @"mech_compact_free"(i64, i64)
declare i64 @"mech_compact_writable"(i64, i64, i64, i64, i64, i64, i64)
declare i64 @"memmove"(i64, i64, i64)
declare void @llvm.trap()
define { i64, i64 } @"mech_compact_numeric_2821"(i64 %v0, i64 %v1, i64 %v2) #0 align 128 {
block0:
  %ss0 = alloca [48 x i8], align 8
  %ss1 = alloca [48 x i8], align 8
  %v3 = add i64 0, 0
  %t0 = inttoptr i64 %v1 to ptr
  %t1 = getelementptr i8, ptr %t0, i64 88
  %v5 = load i64, ptr %t1, align 1
  %t2 = inttoptr i64 %v1 to ptr
  %t3 = getelementptr i8, ptr %t2, i64 96
  %v6 = load i64, ptr %t3, align 1
  %v8 = add i64 0, 0
  %v9 = add i64 0, 1
  %v10 = add i64 0, 1
  %v11 = add i64 0, 0
  %t4 = inttoptr i64 %v1 to ptr
  %v14 = load i64, ptr %t4, align 1
  %t5 = inttoptr i64 %v1 to ptr
  %t6 = getelementptr i8, ptr %t5, i64 8
  %v15 = load i64, ptr %t6, align 1
  %t7 = inttoptr i64 %v1 to ptr
  %t8 = getelementptr i8, ptr %t7, i64 16
  %v16 = load i64, ptr %t8, align 1
  %t9 = inttoptr i64 %v1 to ptr
  %t10 = getelementptr i8, ptr %t9, i64 24
  %v17 = load i64, ptr %t10, align 1
  %t11 = inttoptr i64 %v1 to ptr
  %t12 = getelementptr i8, ptr %t11, i64 32
  %v18 = load i64, ptr %t12, align 1
  %t13 = inttoptr i64 %v1 to ptr
  %t14 = getelementptr i8, ptr %t13, i64 40
  %v19 = load i64, ptr %t14, align 1
  %t15 = inttoptr i64 %v1 to ptr
  %t16 = getelementptr i8, ptr %t15, i64 48
  %v20 = load i64, ptr %t16, align 1
  %t17 = inttoptr i64 %v1 to ptr
  %t18 = getelementptr i8, ptr %t17, i64 56
  %v21 = load i64, ptr %t18, align 1
  %t19 = inttoptr i64 %v1 to ptr
  %t20 = getelementptr i8, ptr %t19, i64 64
  %v22 = load i64, ptr %t20, align 1
  %t21 = inttoptr i64 %v1 to ptr
  %t22 = getelementptr i8, ptr %t21, i64 72
  %v23 = load i64, ptr %t22, align 1
  %t23 = inttoptr i64 %v1 to ptr
  %t24 = getelementptr i8, ptr %t23, i64 80
  %v24 = load i64, ptr %t24, align 1
  br label %edge0
block6:
  %v308 = phi i64 [ %v16, %edge0 ], [ %v265, %edge2 ]
  br label %edge1
block7:
  br label %edge2
block8:
  br label %edge3
block10:
  br label %edge4
block11:
  br label %edge5
block12:
  br label %edge6
block13:
  br label %edge7
block14:
  br label %edge8
block15:
  br label %edge9
block16:
  %t25 = icmp ult i64 %v308, %v15
  %v58 = zext i1 %t25 to i8
  br label %edge10
block17:
  %v446 = and i8 %v58, 1
  %t26 = icmp ne i8 %v446, 0
  br i1 %t26, label %edge11, label %edge12
block18:
  %v348 = phi i64 [ %v308, %edge73 ]
  br label %edge13
block20:
  br label %edge14
block21:
  %v75 = add i64 %v14, %v308
  %t27 = icmp uge i64 %v75, %v14
  %v76 = zext i1 %t27 to i8
  %v77 = add i64 0, 1
  %t28 = icmp ne i8 %v76, 0
  br i1 %t28, label %edge15, label %edge16
block95:
  br label %edge17
block94:
  %v78 = add i64 0, 2837
  %t29 = inttoptr i64 %v2 to ptr
  store i64 %v78, ptr %t29, align 1
  br label %edge18
block22:
  br label %edge19
block23:
  br label %edge20
block24:
  br label %edge21
block25:
  br label %edge22
block26:
  br label %edge23
block27:
  br label %edge24
block28:
  br label %edge25
block29:
  %t30 = icmp ult i64 %v75, %v18
  %v99 = zext i1 %t30 to i8
  br label %edge26
block30:
  %v447 = and i8 %v99, 1
  %t31 = icmp ne i8 %v447, 0
  br i1 %t31, label %edge27, label %edge28
block31:
  %v317 = phi i64 [ %v136, %edge37 ], [ %v11, %edge39 ]
  br label %edge29
block32:
  br label %edge30
block33:
  br label %edge31
block34:
  %v116 = add i64 %v75, %v10
  br label %edge32
block35:
  %v121 = add i64 %v116, 18446744073709551615
  %t32 = icmp eq i64 %v19, 1
  %v124 = zext i1 %t32 to i8
  %t33 = icmp eq i64 %v20, 1
  %v125 = zext i1 %t33 to i8
  %v126 = or i8 %v124, %v125
  %t34 = icmp ne i8 %v126, 0
  br i1 %t34, label %edge33, label %edge34
block110:
  %t35 = icmp eq i64 %v19, 0
  br i1 %t35, label %trap36, label %ok36
trap36:
  call void @llvm.trap()
  unreachable
ok36:
  %v128 = udiv i64 %v121, %v19
  %v129 = mul i64 %v128, %v19
  %v130 = sub i64 %v121, %v129
  %v131 = mul i64 %v130, %v20
  %v132 = add i64 %v131, %v128
  br label %edge35
block111:
  %v127 = phi i64 [ %v121, %edge33 ], [ %v132, %edge35 ]
  %v135 = add i64 %v17, %v127
  %t37 = inttoptr i64 %v135 to ptr
  %t38 = load i8, ptr %t37, align 1
  %v136 = zext i8 %t38 to i64
  br label %edge36
block36:
  br label %edge37
block38:
  br label %edge38
block39:
  br label %edge39
block40:
  br label %edge40
block41:
  br label %edge41
block42:
  br label %edge42
block43:
  br label %edge43
block44:
  br label %edge44
block45:
  br label %edge45
block46:
  br label %edge46
block47:
  br label %edge47
block48:
  br label %edge48
block49:
  %t39 = icmp ult i64 %v317, %v22
  %v174 = zext i1 %t39 to i8
  br label %edge49
block50:
  %v448 = and i8 %v174, 1
  %t40 = icmp ne i8 %v448, 0
  br i1 %t40, label %edge50, label %edge51
block51:
  %v337 = phi i64 [ %v201, %edge57 ], [ %v8, %edge59 ]
  br label %edge52
block52:
  br label %edge53
block53:
  br label %edge54
block54:
  %v190 = add i64 %v317, %v10
  br label %edge55
block55:
  %v195 = add i64 %v190, 18446744073709551615
  %v198 = mul i64 %v195, 4
  %v200 = add i64 %v21, %v198
  %t41 = inttoptr i64 %v200 to ptr
  %t42 = load i32, ptr %t41, align 1
  %v201 = zext i32 %t42 to i64
  br label %edge56
block56:
  br label %edge57
block58:
  br label %edge58
block59:
  br label %edge59
block60:
  br label %edge60
block61:
  %v220 = add i64 %v337, %v9
  %t43 = icmp ule i64 %v220, 4294967295
  %v221 = zext i1 %t43 to i8
  %v222 = add i64 0, 1
  %t44 = icmp ne i8 %v221, 0
  br i1 %t44, label %edge61, label %edge62
block138:
  br label %edge63
block137:
  %v223 = add i64 0, 2879
  %t45 = inttoptr i64 %v2 to ptr
  store i64 %v223, ptr %t45, align 1
  br label %edge64
block62:
  %v226 = add i64 %v317, %v10
  br label %edge65
block63:
  %v231 = add i64 %v226, 18446744073709551615
  %t46 = icmp ult i64 %v231, %v22
  %v232 = zext i1 %t46 to i8
  %t47 = icmp ne i8 %v232, 0
  br i1 %t47, label %edge66, label %edge67
block142:
  %v233 = add i64 0, 103169
  br label %edge68
block141:
  %v236 = mul i64 %v231, 4
  %v238 = add i64 %v21, %v236
  br label %edge69
block144:
  %v240 = trunc i64 %v220 to i32
  %t48 = inttoptr i64 %v238 to ptr
  store i32 %v240, ptr %t48, align 1
  br label %edge70
block143:
  br label %edge71
block140:
  %v241 = add i64 0, 2881
  %t49 = inttoptr i64 %v2 to ptr
  store i64 %v241, ptr %t49, align 1
  br label %edge72
block64:
  br label %edge73
block68:
  br label %edge74
block71:
  br label %edge75
block72:
  %v265 = add i64 %v348, %v10
  br label %edge76
block154:
  br label %edge77
block73:
  br label %edge78
block74:
  br label %edge79
block3:
  %t50 = inttoptr i64 %v2 to ptr
  %t51 = getelementptr i8, ptr %t50, i64 8
  store i64 %v21, ptr %t51, align 1
  %t52 = inttoptr i64 %v2 to ptr
  %t53 = getelementptr i8, ptr %t52, i64 16
  store i64 %v22, ptr %t53, align 1
  %t54 = inttoptr i64 %v2 to ptr
  %t55 = getelementptr i8, ptr %t54, i64 24
  store i64 %v23, ptr %t55, align 1
  %t56 = inttoptr i64 %v2 to ptr
  %t57 = getelementptr i8, ptr %t56, i64 32
  store i64 %v24, ptr %t57, align 1
  %t58 = inttoptr i64 %v2 to ptr
  %t59 = getelementptr i8, ptr %t58, i64 40
  store i64 %v21, ptr %t59, align 1
  %t60 = inttoptr i64 %v2 to ptr
  %t61 = getelementptr i8, ptr %t60, i64 48
  store i64 %v22, ptr %t61, align 1
  %t62 = inttoptr i64 %v2 to ptr
  %t63 = getelementptr i8, ptr %t62, i64 56
  store i64 %v6, ptr %t63, align 1
  %t64 = inttoptr i64 %v2 to ptr
  %t65 = getelementptr i8, ptr %t64, i64 64
  store i64 %v23, ptr %t65, align 1
  %t66 = inttoptr i64 %v2 to ptr
  %t67 = getelementptr i8, ptr %t66, i64 72
  store i64 %v24, ptr %t67, align 1
  %t68 = inttoptr i64 %v2 to ptr
  %t69 = getelementptr i8, ptr %t68, i64 80
  store i64 %v5, ptr %t69, align 1
  br label %edge80
block5:
  %v27 = phi i64 [ %v77, %edge18 ], [ %v222, %edge64 ], [ %v233, %edge72 ]
  br label %edge81
block2:
  %t70 = insertvalue { i64, i64 } poison, i64 %v3, 0
  %t71 = insertvalue { i64, i64 } %t70, i64 %v3, 1
  ret { i64, i64 } %t71
block1:
  %v4 = phi i64 [ %v27, %edge81 ]
  %t72 = inttoptr i64 %v2 to ptr
  %v295 = load i64, ptr %t72, align 1
  %t73 = insertvalue { i64, i64 } poison, i64 %v4, 0
  %t74 = insertvalue { i64, i64 } %t73, i64 %v295, 1
  ret { i64, i64 } %t74
edge0:
  br label %block6
edge1:
  br label %block8
edge2:
  br label %block6
edge3:
  br label %block10
edge4:
  br label %block11
edge5:
  br label %block12
edge6:
  br label %block13
edge7:
  br label %block14
edge8:
  br label %block15
edge9:
  br label %block16
edge10:
  br label %block17
edge11:
  br label %block20
edge12:
  br label %block3
edge13:
  br label %block68
edge14:
  br label %block21
edge15:
  br label %block95
edge16:
  br label %block94
edge17:
  br label %block22
edge18:
  br label %block5
edge19:
  br label %block23
edge20:
  br label %block25
edge21:
  br label %block41
edge22:
  br label %block26
edge23:
  br label %block27
edge24:
  br label %block28
edge25:
  br label %block29
edge26:
  br label %block30
edge27:
  br label %block33
edge28:
  br label %block32
edge29:
  br label %block40
edge30:
  br label %block38
edge31:
  br label %block34
edge32:
  br label %block35
edge33:
  br label %block111
edge34:
  br label %block110
edge35:
  br label %block111
edge36:
  br label %block36
edge37:
  br label %block31
edge38:
  br label %block39
edge39:
  br label %block31
edge40:
  br label %block24
edge41:
  br label %block42
edge42:
  br label %block43
edge43:
  br label %block45
edge44:
  br label %block61
edge45:
  br label %block46
edge46:
  br label %block47
edge47:
  br label %block48
edge48:
  br label %block49
edge49:
  br label %block50
edge50:
  br label %block53
edge51:
  br label %block52
edge52:
  br label %block60
edge53:
  br label %block58
edge54:
  br label %block54
edge55:
  br label %block55
edge56:
  br label %block56
edge57:
  br label %block51
edge58:
  br label %block59
edge59:
  br label %block51
edge60:
  br label %block44
edge61:
  br label %block138
edge62:
  br label %block137
edge63:
  br label %block62
edge64:
  br label %block5
edge65:
  br label %block63
edge66:
  br label %block141
edge67:
  br label %block142
edge68:
  br label %block140
edge69:
  br label %block144
edge70:
  br label %block143
edge71:
  br label %block64
edge72:
  br label %block5
edge73:
  br label %block18
edge74:
  br label %block71
edge75:
  br label %block72
edge76:
  br label %block154
edge77:
  br label %block73
edge78:
  br label %block74
edge79:
  br label %block7
edge80:
  br label %block2
edge81:
  br label %block1
}

attributes #0 = { noinline uwtable "frame-pointer"="all" }
