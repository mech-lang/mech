target triple = "arm64-apple-macosx26.0.0"

declare i64 @"mech_compact_allocate"(i64, i64, i64, i64, i64, i64)
declare i64 @"mech_compact_free"(i64, i64)
declare i64 @"mech_compact_writable"(i64, i64, i64, i64, i64, i64, i64)
declare i64 @"memmove"(i64, i64, i64)

define { i64, i64 } @"mech_compact_numeric_3872"(i64 %v0, i64 %v1, i64 %v2) #0 align 128 {
block0:
  %ss0 = alloca [48 x i8], align 8
  %ss1 = alloca [48 x i8], align 8
  %v3 = add i64 0, 0
  %t0 = inttoptr i64 %v1 to ptr
  %t1 = getelementptr i8, ptr %t0, i64 96
  %v5 = load i64, ptr %t1, align 1
  %t2 = inttoptr i64 %v1 to ptr
  %t3 = getelementptr i8, ptr %t2, i64 104
  %v6 = load i64, ptr %t3, align 1
  %v8 = add i64 0, 0
  %v9 = add i64 0, 0
  %v10 = add i64 0, 1
  %v11 = add i64 0, 10
  %v12 = add i64 0, 4294967295
  %t4 = inttoptr i64 %v1 to ptr
  %v15 = load i64, ptr %t4, align 1
  %t5 = inttoptr i64 %v1 to ptr
  %t6 = getelementptr i8, ptr %t5, i64 8
  %v16 = load i64, ptr %t6, align 1
  %t7 = inttoptr i64 %v1 to ptr
  %t8 = getelementptr i8, ptr %t7, i64 16
  %v17 = load i64, ptr %t8, align 1
  %t9 = inttoptr i64 %v1 to ptr
  %t10 = getelementptr i8, ptr %t9, i64 24
  %v18 = load i64, ptr %t10, align 1
  %t11 = inttoptr i64 %v1 to ptr
  %t12 = getelementptr i8, ptr %t11, i64 32
  %v19 = load i64, ptr %t12, align 1
  %t13 = inttoptr i64 %v1 to ptr
  %t14 = getelementptr i8, ptr %t13, i64 40
  %v20 = load i64, ptr %t14, align 1
  %t15 = inttoptr i64 %v1 to ptr
  %t16 = getelementptr i8, ptr %t15, i64 48
  %v21 = load i64, ptr %t16, align 1
  %t17 = inttoptr i64 %v1 to ptr
  %t18 = getelementptr i8, ptr %t17, i64 56
  %v22 = load i64, ptr %t18, align 1
  %t19 = inttoptr i64 %v1 to ptr
  %t20 = getelementptr i8, ptr %t19, i64 64
  %v23 = load i64, ptr %t20, align 1
  %t21 = inttoptr i64 %v1 to ptr
  %t22 = getelementptr i8, ptr %t21, i64 72
  %v24 = load i64, ptr %t22, align 1
  %t23 = inttoptr i64 %v1 to ptr
  %t24 = getelementptr i8, ptr %t23, i64 80
  %v25 = load i64, ptr %t24, align 1
  %t25 = inttoptr i64 %v1 to ptr
  %t26 = getelementptr i8, ptr %t25, i64 88
  %v26 = load i64, ptr %t26, align 1
  br label %edge0
block6:
  %v320 = phi i64 [ %v17, %edge0 ], [ %v268, %edge2 ]
  %v321 = phi i64 [ %v18, %edge0 ], [ %v496, %edge2 ]
  br label %edge1
block7:
  br label %edge2
block8:
  br label %edge3
block9:
  br label %edge4
block10:
  br label %edge5
block11:
  br label %edge6
block12:
  br label %edge7
block13:
  br label %edge8
block14:
  br label %edge9
block15:
  br label %edge10
block16:
  br label %edge11
block17:
  %t27 = icmp ult i64 %v320, %v16
  %v64 = zext i1 %t27 to i8
  br label %edge12
block18:
  %v490 = and i8 %v64, 1
  %t28 = icmp ne i8 %v490, 0
  br i1 %t28, label %edge13, label %edge14
block19:
  %v337 = phi i64 [ %v336, %edge38 ], [ %v8, %edge40 ]
  %v497 = phi i8 [ %v498, %edge38 ], [ %v499, %edge40 ]
  br label %edge15
block20:
  br label %edge16
block21:
  br label %edge17
block22:
  %v81 = add i64 %v15, %v320
  br label %edge18
block23:
  br label %edge19
block24:
  br label %edge20
block25:
  br label %edge21
block26:
  br label %edge22
block27:
  br label %edge23
block28:
  br label %edge24
block29:
  br label %edge25
block30:
  %t29 = icmp ult i64 %v81, %v20
  %v103 = zext i1 %t29 to i8
  br label %edge26
block31:
  %v491 = and i8 %v103, 1
  %t30 = icmp ne i8 %v491, 0
  br i1 %t30, label %edge27, label %edge28
block32:
  %v336 = phi i64 [ %v131, %edge34 ], [ %v8, %edge36 ]
  br label %edge29
block33:
  br label %edge30
block34:
  br label %edge31
block35:
  %v120 = add i64 %v81, %v10
  br label %edge32
block36:
  %v125 = add i64 %v120, 18446744073709551615
  %v128 = mul i64 %v125, 4
  %v130 = add i64 %v19, %v128
  %t31 = inttoptr i64 %v130 to ptr
  %t32 = load i32, ptr %t31, align 1
  %v131 = zext i32 %t32 to i64
  br label %edge33
block37:
  br label %edge34
block39:
  br label %edge35
block40:
  br label %edge36
block41:
  br label %edge37
block42:
  %v498 = add i8 0, 1
  br label %edge38
block44:
  br label %edge39
block45:
  %v499 = add i8 0, 0
  br label %edge40
block46:
  br label %edge41
block47:
  %t33 = icmp ne i64 %v337, %v9
  %v163 = zext i1 %t33 to i8
  br label %edge42
block48:
  %v168 = and i64 %v11, 63
  %t34 = and i64 %v168, 63
  %v169 = shl i64 %v337, %t34
  br label %edge43
block49:
  %v174 = or i64 %v320, %v169
  br label %edge44
block50:
  %v179 = and i64 %v174, %v12
  br label %edge45
block51:
  br label %edge46
block129:
  br label %edge47
block52:
  %v492 = and i8 %v163, 1
  %t35 = icmp ne i8 %v492, 0
  br i1 %t35, label %edge48, label %edge49
block53:
  %v361 = phi i64 [ %v321, %edge60 ]
  %v374 = phi i64 [ %v320, %edge60 ]
  br label %edge50
block55:
  br label %edge51
block56:
  %v200 = add i64 %v321, %v10
  br label %edge52
block57:
  %v205 = add i64 %v200, 18446744073709551615
  %t36 = icmp ult i64 %v205, %v24
  %v206 = zext i1 %t36 to i8
  %t37 = icmp ne i8 %v206, 0
  br i1 %t37, label %edge53, label %edge54
block137:
  %v207 = add i64 0, 103169
  br label %edge55
block136:
  %v210 = mul i64 %v205, 4
  %v212 = add i64 %v23, %v210
  br label %edge56
block139:
  %v214 = trunc i64 %v179 to i32
  %t38 = inttoptr i64 %v212 to ptr
  store i32 %v214, ptr %t38, align 1
  br label %edge57
block138:
  br label %edge58
block135:
  %v215 = add i64 0, 3925
  %t39 = inttoptr i64 %v2 to ptr
  store i64 %v215, ptr %t39, align 1
  br label %edge59
block58:
  br label %edge60
block62:
  br label %edge61
block63:
  %v372 = phi i64 [ %v374, %edge68 ]
  br label %edge62
block65:
  br label %edge63
block66:
  %v239 = add i64 %v361, %v10
  %t40 = icmp uge i64 %v239, %v361
  %v240 = zext i1 %t40 to i8
  %v241 = add i64 0, 1
  %t41 = icmp ne i8 %v240, 0
  br i1 %t41, label %edge64, label %edge65
block149:
  br label %edge66
block148:
  %v242 = add i64 0, 3934
  %t42 = inttoptr i64 %v2 to ptr
  store i64 %v242, ptr %t42, align 1
  br label %edge67
block67:
  br label %edge68
block71:
  %v495 = phi i64 [ %v320, %edge49 ], [ %v372, %edge62 ]
  %v496 = phi i64 [ %v321, %edge49 ], [ %v239, %edge62 ]
  %v494 = and i8 %v497, 1
  %t43 = icmp ne i8 %v494, 0
  br i1 %t43, label %edge69, label %edge70
block72:
  br label %edge71
block73:
  br label %edge72
block74:
  br label %edge73
block75:
  %v268 = add i64 %v495, %v10
  br label %edge74
block159:
  br label %edge75
block76:
  br label %edge76
block77:
  br label %edge77
block79:
  br label %edge78
block80:
  br label %edge79
block81:
  br label %edge80
block82:
  br label %edge81
block3:
  %t44 = inttoptr i64 %v2 to ptr
  %t45 = getelementptr i8, ptr %t44, i64 8
  store i64 %v23, ptr %t45, align 1
  %t46 = inttoptr i64 %v2 to ptr
  %t47 = getelementptr i8, ptr %t46, i64 16
  store i64 %v24, ptr %t47, align 1
  %t48 = inttoptr i64 %v2 to ptr
  %t49 = getelementptr i8, ptr %t48, i64 24
  store i64 %v25, ptr %t49, align 1
  %t50 = inttoptr i64 %v2 to ptr
  %t51 = getelementptr i8, ptr %t50, i64 32
  store i64 %v26, ptr %t51, align 1
  %t52 = inttoptr i64 %v2 to ptr
  %t53 = getelementptr i8, ptr %t52, i64 40
  store i64 %v496, ptr %t53, align 1
  %t54 = inttoptr i64 %v2 to ptr
  %t55 = getelementptr i8, ptr %t54, i64 48
  store i64 %v23, ptr %t55, align 1
  %t56 = inttoptr i64 %v2 to ptr
  %t57 = getelementptr i8, ptr %t56, i64 56
  store i64 %v24, ptr %t57, align 1
  %t58 = inttoptr i64 %v2 to ptr
  %t59 = getelementptr i8, ptr %t58, i64 64
  store i64 %v6, ptr %t59, align 1
  %t60 = inttoptr i64 %v2 to ptr
  %t61 = getelementptr i8, ptr %t60, i64 72
  store i64 %v25, ptr %t61, align 1
  %t62 = inttoptr i64 %v2 to ptr
  %t63 = getelementptr i8, ptr %t62, i64 80
  store i64 %v26, ptr %t63, align 1
  %t64 = inttoptr i64 %v2 to ptr
  %t65 = getelementptr i8, ptr %t64, i64 88
  store i64 %v5, ptr %t65, align 1
  br label %edge82
block5:
  %v29 = phi i64 [ %v207, %edge59 ], [ %v241, %edge67 ]
  br label %edge83
block2:
  %t66 = insertvalue { i64, i64 } poison, i64 %v3, 0
  %t67 = insertvalue { i64, i64 } %t66, i64 %v3, 1
  ret { i64, i64 } %t67
block1:
  %v4 = phi i64 [ %v29, %edge83 ]
  %t68 = inttoptr i64 %v2 to ptr
  %v306 = load i64, ptr %t68, align 1
  %t69 = insertvalue { i64, i64 } poison, i64 %v4, 0
  %t70 = insertvalue { i64, i64 } %t69, i64 %v306, 1
  ret { i64, i64 } %t70
edge0:
  br label %block6
edge1:
  br label %block8
edge2:
  br label %block6
edge3:
  br label %block10
edge4:
  br label %block3
edge5:
  br label %block11
edge6:
  br label %block12
edge7:
  br label %block13
edge8:
  br label %block14
edge9:
  br label %block15
edge10:
  br label %block16
edge11:
  br label %block17
edge12:
  br label %block18
edge13:
  br label %block21
edge14:
  br label %block20
edge15:
  br label %block46
edge16:
  br label %block44
edge17:
  br label %block22
edge18:
  br label %block23
edge19:
  br label %block24
edge20:
  br label %block26
edge21:
  br label %block42
edge22:
  br label %block27
edge23:
  br label %block28
edge24:
  br label %block29
edge25:
  br label %block30
edge26:
  br label %block31
edge27:
  br label %block34
edge28:
  br label %block33
edge29:
  br label %block41
edge30:
  br label %block39
edge31:
  br label %block35
edge32:
  br label %block36
edge33:
  br label %block37
edge34:
  br label %block32
edge35:
  br label %block40
edge36:
  br label %block32
edge37:
  br label %block25
edge38:
  br label %block19
edge39:
  br label %block45
edge40:
  br label %block19
edge41:
  br label %block47
edge42:
  br label %block48
edge43:
  br label %block49
edge44:
  br label %block50
edge45:
  br label %block51
edge46:
  br label %block129
edge47:
  br label %block52
edge48:
  br label %block55
edge49:
  br label %block71
edge50:
  br label %block62
edge51:
  br label %block56
edge52:
  br label %block57
edge53:
  br label %block136
edge54:
  br label %block137
edge55:
  br label %block135
edge56:
  br label %block139
edge57:
  br label %block138
edge58:
  br label %block58
edge59:
  br label %block5
edge60:
  br label %block53
edge61:
  br label %block65
edge62:
  br label %block71
edge63:
  br label %block66
edge64:
  br label %block149
edge65:
  br label %block148
edge66:
  br label %block67
edge67:
  br label %block5
edge68:
  br label %block63
edge69:
  br label %block74
edge70:
  br label %block73
edge71:
  br label %block82
edge72:
  br label %block79
edge73:
  br label %block75
edge74:
  br label %block159
edge75:
  br label %block76
edge76:
  br label %block77
edge77:
  br label %block7
edge78:
  br label %block80
edge79:
  br label %block81
edge80:
  br label %block72
edge81:
  br label %block9
edge82:
  br label %block2
edge83:
  br label %block1
}

attributes #0 = { noinline uwtable "frame-pointer"="all" }
