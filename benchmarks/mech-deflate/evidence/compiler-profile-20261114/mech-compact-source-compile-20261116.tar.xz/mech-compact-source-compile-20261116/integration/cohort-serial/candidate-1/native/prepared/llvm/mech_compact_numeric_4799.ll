target triple = "arm64-apple-macosx26.0.0"

declare i64 @"mech_compact_allocate"(i64, i64, i64, i64, i64, i64)
declare i64 @"mech_compact_free"(i64, i64)
declare i64 @"mech_compact_writable"(i64, i64, i64, i64, i64, i64, i64)
declare i64 @"memmove"(i64, i64, i64)

define { i64, i64 } @"mech_compact_numeric_4799"(i64 %v0, i64 %v1, i64 %v2) #0 align 128 {
block0:
  %ss0 = alloca [48 x i8], align 8
  %ss1 = alloca [48 x i8], align 8
  %v3 = add i64 0, 0
  %t0 = inttoptr i64 %v1 to ptr
  %t1 = getelementptr i8, ptr %t0, i64 80
  %v5 = load i64, ptr %t1, align 1
  %t2 = inttoptr i64 %v1 to ptr
  %t3 = getelementptr i8, ptr %t2, i64 88
  %v6 = load i64, ptr %t3, align 1
  %v8 = add i64 0, 0
  %v9 = add i64 0, 0
  %v10 = add i64 0, 1
  %v11 = add i64 0, 4294967295
  %t4 = inttoptr i64 %v1 to ptr
  %v14 = load i64, ptr %t4, align 1
  %t5 = inttoptr i64 %v1 to ptr
  %t6 = getelementptr i8, ptr %t5, i64 8
  %v15 = load i64, ptr %t6, align 1
  %t7 = inttoptr i64 %v1 to ptr
  %t8 = getelementptr i8, ptr %t7, i64 16
  %v16 = load i64, ptr %t8, align 1
  %t9 = inttoptr i64 %v1 to ptr
  %t10 = getelementptr i8, ptr %t9, i64 24
  %v17 = load i64, ptr %t10, align 1
  %t11 = inttoptr i64 %v1 to ptr
  %t12 = getelementptr i8, ptr %t11, i64 32
  %v18 = load i64, ptr %t12, align 1
  %t13 = inttoptr i64 %v1 to ptr
  %t14 = getelementptr i8, ptr %t13, i64 40
  %v19 = load i64, ptr %t14, align 1
  %t15 = inttoptr i64 %v1 to ptr
  %t16 = getelementptr i8, ptr %t15, i64 48
  %v20 = load i64, ptr %t16, align 1
  %t17 = inttoptr i64 %v1 to ptr
  %t18 = getelementptr i8, ptr %t17, i64 56
  %v21 = load i64, ptr %t18, align 1
  %t19 = inttoptr i64 %v1 to ptr
  %t20 = getelementptr i8, ptr %t19, i64 64
  %v22 = load i64, ptr %t20, align 1
  %t21 = inttoptr i64 %v1 to ptr
  %t22 = getelementptr i8, ptr %t21, i64 72
  %v23 = load i64, ptr %t22, align 1
  br label %edge0
block6:
  %v320 = phi i64 [ %v15, %edge0 ], [ %v280, %edge2 ]
  br label %edge1
block7:
  br label %edge2
block8:
  br label %edge3
block9:
  br label %edge4
block10:
  br label %edge5
block11:
  br label %edge6
block12:
  br label %edge7
block13:
  br label %edge8
block14:
  br label %edge9
block15:
  %t23 = icmp ule i64 %v320, %v14
  %v53 = zext i1 %t23 to i8
  br label %edge10
block16:
  %v414 = and i8 %v53, 1
  %t24 = icmp ne i8 %v414, 0
  br i1 %t24, label %edge11, label %edge12
block17:
  br label %edge13
block18:
  br label %edge14
block19:
  br label %edge15
block20:
  %t25 = icmp uge i64 %v320, %v10
  %v70 = zext i1 %t25 to i8
  %v71 = add i64 0, 1
  %t26 = icmp ne i8 %v70, 0
  br i1 %t26, label %edge16, label %edge17
block95:
  %v72 = sub i64 %v320, %v10
  br label %edge18
block94:
  %v73 = add i64 0, 4814
  %t27 = inttoptr i64 %v2 to ptr
  store i64 %v73, ptr %t27, align 1
  br label %edge19
block21:
  br label %edge20
block22:
  br label %edge21
block23:
  br label %edge22
block24:
  br label %edge23
block25:
  br label %edge24
block26:
  br label %edge25
block27:
  br label %edge26
block28:
  %t28 = icmp ult i64 %v72, %v21
  %v94 = zext i1 %t28 to i8
  br label %edge27
block29:
  %v415 = and i8 %v94, 1
  %t29 = icmp ne i8 %v415, 0
  br i1 %t29, label %edge28, label %edge29
block30:
  %v332 = phi i64 [ %v122, %edge35 ], [ %v8, %edge37 ]
  br label %edge30
block31:
  br label %edge31
block32:
  br label %edge32
block33:
  %v111 = add i64 %v72, %v10
  br label %edge33
block34:
  %v116 = add i64 %v111, 18446744073709551615
  %v119 = mul i64 %v116, 4
  %v121 = add i64 %v20, %v119
  %t30 = inttoptr i64 %v121 to ptr
  %t31 = load i32, ptr %t30, align 1
  %v122 = zext i32 %t31 to i64
  br label %edge34
block35:
  br label %edge35
block37:
  br label %edge36
block38:
  br label %edge37
block39:
  br label %edge38
block40:
  br label %edge39
block116:
  %v143 = sub i64 %v320, %v10
  br label %edge40
block41:
  br label %edge41
block42:
  br label %edge42
block43:
  br label %edge43
block44:
  br label %edge44
block45:
  br label %edge45
block46:
  br label %edge46
block47:
  br label %edge47
block48:
  %t32 = icmp ult i64 %v143, %v17
  %v165 = zext i1 %t32 to i8
  br label %edge48
block49:
  %v416 = and i8 %v165, 1
  %t33 = icmp ne i8 %v416, 0
  br i1 %t33, label %edge49, label %edge50
block50:
  %v343 = phi i64 [ %v193, %edge56 ], [ %v9, %edge58 ]
  br label %edge51
block51:
  br label %edge52
block52:
  br label %edge53
block53:
  %v182 = add i64 %v143, %v10
  br label %edge54
block54:
  %v187 = add i64 %v182, 18446744073709551615
  %v190 = mul i64 %v187, 8
  %v192 = add i64 %v16, %v190
  %t34 = inttoptr i64 %v192 to ptr
  %v193 = load i64, ptr %t34, align 1
  br label %edge55
block55:
  br label %edge56
block57:
  br label %edge57
block58:
  br label %edge58
block59:
  br label %edge59
block60:
  %v212 = and i64 %v343, %v11
  br label %edge60
block61:
  br label %edge61
block138:
  br label %edge62
block62:
  br label %edge63
block63:
  br label %edge64
block64:
  %v227 = add i64 %v332, %v212
  br label %edge65
block65:
  %v232 = and i64 %v227, %v11
  br label %edge66
block66:
  br label %edge67
block144:
  br label %edge68
block67:
  br label %edge69
block68:
  %v245 = and i64 %v10, 63
  %t35 = and i64 %v245, 63
  %v246 = shl i64 %v232, %t35
  br label %edge70
block69:
  %v251 = and i64 %v246, %v11
  br label %edge71
block70:
  br label %edge72
block149:
  br label %edge73
block71:
  %v261 = add i64 %v320, %v10
  br label %edge74
block72:
  %v266 = add i64 %v261, 18446744073709551615
  %t36 = icmp ult i64 %v266, %v21
  %v267 = zext i1 %t36 to i8
  %t37 = icmp ne i8 %v267, 0
  br i1 %t37, label %edge75, label %edge76
block153:
  %v268 = add i64 0, 103169
  br label %edge77
block152:
  %v271 = mul i64 %v266, 4
  %v273 = add i64 %v20, %v271
  br label %edge78
block155:
  %v275 = trunc i64 %v251 to i32
  %t38 = inttoptr i64 %v273 to ptr
  store i32 %v275, ptr %t38, align 1
  br label %edge79
block154:
  br label %edge80
block151:
  %v276 = add i64 0, 4868
  %t39 = inttoptr i64 %v2 to ptr
  store i64 %v276, ptr %t39, align 1
  br label %edge81
block73:
  %v280 = add i64 %v320, %v10
  %t40 = icmp uge i64 %v280, %v320
  %v281 = zext i1 %t40 to i8
  %v282 = add i64 0, 1
  %t41 = icmp ne i8 %v281, 0
  br i1 %t41, label %edge82, label %edge83
block157:
  br label %edge84
block156:
  %v283 = add i64 0, 4869
  %t42 = inttoptr i64 %v2 to ptr
  store i64 %v283, ptr %t42, align 1
  br label %edge85
block74:
  br label %edge86
block75:
  br label %edge87
block77:
  br label %edge88
block78:
  br label %edge89
block79:
  br label %edge90
block3:
  %t43 = inttoptr i64 %v2 to ptr
  %t44 = getelementptr i8, ptr %t43, i64 8
  store i64 %v20, ptr %t44, align 1
  %t45 = inttoptr i64 %v2 to ptr
  %t46 = getelementptr i8, ptr %t45, i64 16
  store i64 %v21, ptr %t46, align 1
  %t47 = inttoptr i64 %v2 to ptr
  %t48 = getelementptr i8, ptr %t47, i64 24
  store i64 %v22, ptr %t48, align 1
  %t49 = inttoptr i64 %v2 to ptr
  %t50 = getelementptr i8, ptr %t49, i64 32
  store i64 %v23, ptr %t50, align 1
  %t51 = inttoptr i64 %v2 to ptr
  %t52 = getelementptr i8, ptr %t51, i64 40
  store i64 %v20, ptr %t52, align 1
  %t53 = inttoptr i64 %v2 to ptr
  %t54 = getelementptr i8, ptr %t53, i64 48
  store i64 %v21, ptr %t54, align 1
  %t55 = inttoptr i64 %v2 to ptr
  %t56 = getelementptr i8, ptr %t55, i64 56
  store i64 %v6, ptr %t56, align 1
  %t57 = inttoptr i64 %v2 to ptr
  %t58 = getelementptr i8, ptr %t57, i64 64
  store i64 %v22, ptr %t58, align 1
  %t59 = inttoptr i64 %v2 to ptr
  %t60 = getelementptr i8, ptr %t59, i64 72
  store i64 %v23, ptr %t60, align 1
  %t61 = inttoptr i64 %v2 to ptr
  %t62 = getelementptr i8, ptr %t61, i64 80
  store i64 %v5, ptr %t62, align 1
  br label %edge91
block5:
  %v26 = phi i64 [ %v71, %edge19 ], [ %v268, %edge81 ], [ %v282, %edge85 ]
  br label %edge92
block2:
  %t63 = insertvalue { i64, i64 } poison, i64 %v3, 0
  %t64 = insertvalue { i64, i64 } %t63, i64 %v3, 1
  ret { i64, i64 } %t64
block1:
  %v4 = phi i64 [ %v26, %edge92 ]
  %t65 = inttoptr i64 %v2 to ptr
  %v308 = load i64, ptr %t65, align 1
  %t66 = insertvalue { i64, i64 } poison, i64 %v4, 0
  %t67 = insertvalue { i64, i64 } %t66, i64 %v308, 1
  ret { i64, i64 } %t67
edge0:
  br label %block6
edge1:
  br label %block8
edge2:
  br label %block6
edge3:
  br label %block10
edge4:
  br label %block3
edge5:
  br label %block11
edge6:
  br label %block12
edge7:
  br label %block13
edge8:
  br label %block14
edge9:
  br label %block15
edge10:
  br label %block16
edge11:
  br label %block19
edge12:
  br label %block18
edge13:
  br label %block79
edge14:
  br label %block77
edge15:
  br label %block20
edge16:
  br label %block95
edge17:
  br label %block94
edge18:
  br label %block21
edge19:
  br label %block5
edge20:
  br label %block22
edge21:
  br label %block24
edge22:
  br label %block40
edge23:
  br label %block25
edge24:
  br label %block26
edge25:
  br label %block27
edge26:
  br label %block28
edge27:
  br label %block29
edge28:
  br label %block32
edge29:
  br label %block31
edge30:
  br label %block39
edge31:
  br label %block37
edge32:
  br label %block33
edge33:
  br label %block34
edge34:
  br label %block35
edge35:
  br label %block30
edge36:
  br label %block38
edge37:
  br label %block30
edge38:
  br label %block23
edge39:
  br label %block116
edge40:
  br label %block41
edge41:
  br label %block42
edge42:
  br label %block44
edge43:
  br label %block60
edge44:
  br label %block45
edge45:
  br label %block46
edge46:
  br label %block47
edge47:
  br label %block48
edge48:
  br label %block49
edge49:
  br label %block52
edge50:
  br label %block51
edge51:
  br label %block59
edge52:
  br label %block57
edge53:
  br label %block53
edge54:
  br label %block54
edge55:
  br label %block55
edge56:
  br label %block50
edge57:
  br label %block58
edge58:
  br label %block50
edge59:
  br label %block43
edge60:
  br label %block61
edge61:
  br label %block138
edge62:
  br label %block62
edge63:
  br label %block63
edge64:
  br label %block64
edge65:
  br label %block65
edge66:
  br label %block66
edge67:
  br label %block144
edge68:
  br label %block67
edge69:
  br label %block68
edge70:
  br label %block69
edge71:
  br label %block70
edge72:
  br label %block149
edge73:
  br label %block71
edge74:
  br label %block72
edge75:
  br label %block152
edge76:
  br label %block153
edge77:
  br label %block151
edge78:
  br label %block155
edge79:
  br label %block154
edge80:
  br label %block73
edge81:
  br label %block5
edge82:
  br label %block157
edge83:
  br label %block156
edge84:
  br label %block74
edge85:
  br label %block5
edge86:
  br label %block75
edge87:
  br label %block7
edge88:
  br label %block78
edge89:
  br label %block17
edge90:
  br label %block9
edge91:
  br label %block2
edge92:
  br label %block1
}

attributes #0 = { noinline uwtable "frame-pointer"="all" }
