target triple = "arm64-apple-macosx26.0.0"

declare i64 @"mech_compact_allocate"(i64, i64, i64, i64, i64, i64)
declare i64 @"mech_compact_free"(i64, i64)
declare i64 @"mech_compact_writable"(i64, i64, i64, i64, i64, i64, i64)
declare i64 @"memmove"(i64, i64, i64)
declare void @llvm.trap()
define { i64, i64 } @"mech_compact_numeric_362"(i64 %v0, i64 %v1, i64 %v2) #0 align 128 {
block0:
  %ss0 = alloca [48 x i8], align 8
  %ss1 = alloca [48 x i8], align 8
  %v3 = add i64 0, 0
  %t0 = inttoptr i64 %v1 to ptr
  %t1 = getelementptr i8, ptr %t0, i64 88
  %v5 = load i64, ptr %t1, align 1
  %t2 = inttoptr i64 %v1 to ptr
  %t3 = getelementptr i8, ptr %t2, i64 96
  %v6 = load i64, ptr %t3, align 1
  %v8 = add i64 0, 0
  %v9 = add i64 0, 1
  %v10 = add i64 0, 1
  %t4 = inttoptr i64 %v1 to ptr
  %v13 = load i64, ptr %t4, align 1
  %t5 = inttoptr i64 %v1 to ptr
  %t6 = getelementptr i8, ptr %t5, i64 8
  %v14 = load i64, ptr %t6, align 1
  %t7 = inttoptr i64 %v1 to ptr
  %t8 = getelementptr i8, ptr %t7, i64 16
  %v15 = load i64, ptr %t8, align 1
  %t9 = inttoptr i64 %v1 to ptr
  %t10 = getelementptr i8, ptr %t9, i64 24
  %v16 = load i64, ptr %t10, align 1
  %t11 = inttoptr i64 %v1 to ptr
  %t12 = getelementptr i8, ptr %t11, i64 32
  %v17 = load i64, ptr %t12, align 1
  %t13 = inttoptr i64 %v1 to ptr
  %t14 = getelementptr i8, ptr %t13, i64 40
  %v18 = load i64, ptr %t14, align 1
  %t15 = inttoptr i64 %v1 to ptr
  %t16 = getelementptr i8, ptr %t15, i64 48
  %v19 = load i64, ptr %t16, align 1
  %t17 = inttoptr i64 %v1 to ptr
  %t18 = getelementptr i8, ptr %t17, i64 56
  %v20 = load i64, ptr %t18, align 1
  %t19 = inttoptr i64 %v1 to ptr
  %t20 = getelementptr i8, ptr %t19, i64 64
  %v21 = load i64, ptr %t20, align 1
  %t21 = inttoptr i64 %v1 to ptr
  %t22 = getelementptr i8, ptr %t21, i64 72
  %v22 = load i64, ptr %t22, align 1
  %t23 = inttoptr i64 %v1 to ptr
  %t24 = getelementptr i8, ptr %t23, i64 80
  %v23 = load i64, ptr %t24, align 1
  br label %edge0
block6:
  %v231 = phi i64 [ %v15, %edge0 ], [ %v188, %edge2 ]
  br label %edge1
block7:
  br label %edge2
block8:
  br label %edge3
block9:
  br label %edge4
block10:
  br label %edge5
block11:
  br label %edge6
block12:
  br label %edge7
block13:
  br label %edge8
block14:
  br label %edge9
block15:
  br label %edge10
block16:
  %t25 = icmp ult i64 %v231, %v14
  %v57 = zext i1 %t25 to i8
  br label %edge11
block17:
  %v336 = and i8 %v57, 1
  %t26 = icmp ne i8 %v336, 0
  br i1 %t26, label %edge12, label %edge13
block18:
  %v245 = phi i64 [ %v231, %edge49 ], [ %v231, %edge51 ]
  br label %edge14
block19:
  br label %edge15
block20:
  br label %edge16
block21:
  %v74 = add i64 %v13, %v231
  %t27 = icmp uge i64 %v74, %v13
  %v75 = zext i1 %t27 to i8
  %v76 = add i64 0, 1
  %t28 = icmp ne i8 %v75, 0
  br i1 %t28, label %edge17, label %edge18
block69:
  br label %edge19
block68:
  %v77 = add i64 0, 378
  %t29 = inttoptr i64 %v2 to ptr
  store i64 %v77, ptr %t29, align 1
  br label %edge20
block22:
  br label %edge21
block23:
  %t30 = icmp ult i64 %v74, %v21
  %v84 = zext i1 %t30 to i8
  br label %edge22
block24:
  %v337 = and i8 %v84, 1
  %t31 = icmp ne i8 %v337, 0
  br i1 %t31, label %edge23, label %edge24
block25:
  %v241 = phi i64 [ %v123, %edge35 ], [ %v8, %edge37 ]
  br label %edge25
block26:
  br label %edge26
block27:
  br label %edge27
block28:
  %v101 = add i64 %v74, %v9
  br label %edge28
block77:
  br label %edge29
block29:
  %v108 = add i64 %v101, 18446744073709551615
  %t32 = icmp eq i64 %v22, 1
  %v111 = zext i1 %t32 to i8
  %t33 = icmp eq i64 %v23, 1
  %v112 = zext i1 %t33 to i8
  %v113 = or i8 %v111, %v112
  %t34 = icmp ne i8 %v113, 0
  br i1 %t34, label %edge30, label %edge31
block79:
  %t35 = icmp eq i64 %v22, 0
  br i1 %t35, label %trap36, label %ok36
trap36:
  call void @llvm.trap()
  unreachable
ok36:
  %v115 = udiv i64 %v108, %v22
  %v116 = mul i64 %v115, %v22
  %v117 = sub i64 %v108, %v116
  %v118 = mul i64 %v117, %v23
  %v119 = add i64 %v118, %v115
  br label %edge32
block80:
  %v114 = phi i64 [ %v108, %edge30 ], [ %v119, %edge32 ]
  %v122 = add i64 %v20, %v114
  %t37 = inttoptr i64 %v122 to ptr
  %t38 = load i8, ptr %t37, align 1
  %v123 = zext i8 %t38 to i64
  br label %edge33
block30:
  br label %edge34
block31:
  br label %edge35
block33:
  br label %edge36
block34:
  br label %edge37
block35:
  %v141 = add i64 %v241, %v9
  %t39 = icmp uge i64 %v141, %v241
  %v142 = zext i1 %t39 to i8
  %v143 = add i64 0, 1
  %t40 = icmp ne i8 %v142, 0
  br i1 %t40, label %edge38, label %edge39
block87:
  br label %edge40
block86:
  %v144 = add i64 0, 392
  %t41 = inttoptr i64 %v2 to ptr
  store i64 %v144, ptr %t41, align 1
  br label %edge41
block36:
  %v148 = add i64 %v141, 18446744073709551615
  %t42 = icmp ult i64 %v148, %v17
  %v149 = zext i1 %t42 to i8
  %t43 = icmp ne i8 %v149, 0
  br i1 %t43, label %edge42, label %edge43
block90:
  %v150 = add i64 0, 103169
  br label %edge44
block89:
  %v155 = add i64 %v16, %v148
  br label %edge45
block92:
  %v157 = trunc i64 %v10 to i8
  %t44 = inttoptr i64 %v155 to ptr
  store i8 %v157, ptr %t44, align 1
  br label %edge46
block91:
  br label %edge47
block88:
  %v158 = add i64 0, 393
  %t45 = inttoptr i64 %v2 to ptr
  store i64 %v158, ptr %t45, align 1
  br label %edge48
block37:
  br label %edge49
block39:
  br label %edge50
block40:
  br label %edge51
block41:
  %t46 = icmp ult i64 %v245, %v14
  %v171 = zext i1 %t46 to i8
  br label %edge52
block42:
  %v338 = and i8 %v171, 1
  %t47 = icmp ne i8 %v338, 0
  br i1 %t47, label %edge53, label %edge54
block43:
  br label %edge55
block44:
  br label %edge56
block45:
  br label %edge57
block46:
  %v188 = add i64 %v245, %v9
  br label %edge58
block103:
  br label %edge59
block47:
  br label %edge60
block48:
  br label %edge61
block50:
  br label %edge62
block51:
  br label %edge63
block52:
  br label %edge64
block3:
  %t48 = inttoptr i64 %v2 to ptr
  %t49 = getelementptr i8, ptr %t48, i64 8
  store i64 %v16, ptr %t49, align 1
  %t50 = inttoptr i64 %v2 to ptr
  %t51 = getelementptr i8, ptr %t50, i64 16
  store i64 %v17, ptr %t51, align 1
  %t52 = inttoptr i64 %v2 to ptr
  %t53 = getelementptr i8, ptr %t52, i64 24
  store i64 %v18, ptr %t53, align 1
  %t54 = inttoptr i64 %v2 to ptr
  %t55 = getelementptr i8, ptr %t54, i64 32
  store i64 %v19, ptr %t55, align 1
  %t56 = inttoptr i64 %v2 to ptr
  %t57 = getelementptr i8, ptr %t56, i64 40
  store i64 %v16, ptr %t57, align 1
  %t58 = inttoptr i64 %v2 to ptr
  %t59 = getelementptr i8, ptr %t58, i64 48
  store i64 %v17, ptr %t59, align 1
  %t60 = inttoptr i64 %v2 to ptr
  %t61 = getelementptr i8, ptr %t60, i64 56
  store i64 %v6, ptr %t61, align 1
  %t62 = inttoptr i64 %v2 to ptr
  %t63 = getelementptr i8, ptr %t62, i64 64
  store i64 %v18, ptr %t63, align 1
  %t64 = inttoptr i64 %v2 to ptr
  %t65 = getelementptr i8, ptr %t64, i64 72
  store i64 %v19, ptr %t65, align 1
  %t66 = inttoptr i64 %v2 to ptr
  %t67 = getelementptr i8, ptr %t66, i64 80
  store i64 %v5, ptr %t67, align 1
  br label %edge65
block5:
  %v26 = phi i64 [ %v76, %edge20 ], [ %v143, %edge41 ], [ %v150, %edge48 ]
  br label %edge66
block2:
  %t68 = insertvalue { i64, i64 } poison, i64 %v3, 0
  %t69 = insertvalue { i64, i64 } %t68, i64 %v3, 1
  ret { i64, i64 } %t69
block1:
  %v4 = phi i64 [ %v26, %edge66 ]
  %t70 = inttoptr i64 %v2 to ptr
  %v218 = load i64, ptr %t70, align 1
  %t71 = insertvalue { i64, i64 } poison, i64 %v4, 0
  %t72 = insertvalue { i64, i64 } %t71, i64 %v218, 1
  ret { i64, i64 } %t72
edge0:
  br label %block6
edge1:
  br label %block8
edge2:
  br label %block6
edge3:
  br label %block10
edge4:
  br label %block3
edge5:
  br label %block11
edge6:
  br label %block12
edge7:
  br label %block13
edge8:
  br label %block14
edge9:
  br label %block15
edge10:
  br label %block16
edge11:
  br label %block17
edge12:
  br label %block20
edge13:
  br label %block19
edge14:
  br label %block41
edge15:
  br label %block39
edge16:
  br label %block21
edge17:
  br label %block69
edge18:
  br label %block68
edge19:
  br label %block22
edge20:
  br label %block5
edge21:
  br label %block23
edge22:
  br label %block24
edge23:
  br label %block27
edge24:
  br label %block26
edge25:
  br label %block35
edge26:
  br label %block33
edge27:
  br label %block28
edge28:
  br label %block77
edge29:
  br label %block29
edge30:
  br label %block80
edge31:
  br label %block79
edge32:
  br label %block80
edge33:
  br label %block30
edge34:
  br label %block31
edge35:
  br label %block25
edge36:
  br label %block34
edge37:
  br label %block25
edge38:
  br label %block87
edge39:
  br label %block86
edge40:
  br label %block36
edge41:
  br label %block5
edge42:
  br label %block89
edge43:
  br label %block90
edge44:
  br label %block88
edge45:
  br label %block92
edge46:
  br label %block91
edge47:
  br label %block37
edge48:
  br label %block5
edge49:
  br label %block18
edge50:
  br label %block40
edge51:
  br label %block18
edge52:
  br label %block42
edge53:
  br label %block45
edge54:
  br label %block44
edge55:
  br label %block52
edge56:
  br label %block50
edge57:
  br label %block46
edge58:
  br label %block103
edge59:
  br label %block47
edge60:
  br label %block48
edge61:
  br label %block7
edge62:
  br label %block51
edge63:
  br label %block43
edge64:
  br label %block9
edge65:
  br label %block2
edge66:
  br label %block1
}

attributes #0 = { noinline uwtable "frame-pointer"="all" }
