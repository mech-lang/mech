target triple = "arm64-apple-macosx26.0.0"

declare i64 @"mech_compact_allocate"(i64, i64, i64, i64, i64, i64)
declare i64 @"mech_compact_free"(i64, i64)
declare i64 @"mech_compact_writable"(i64, i64, i64, i64, i64, i64, i64)
declare i64 @"memmove"(i64, i64, i64)

define { i64, i64 } @"mech_compact_numeric_3956_vector"(i64 %v0, i64 %v1, i64 %v2) #0 align 128 {
block0:
  %ss0 = alloca [48 x i8], align 8
  %ss1 = alloca [48 x i8], align 8
  %v3 = add i64 0, 0
  %v8 = add i64 0, 0
  %v9 = add i64 0, 0
  %v10 = add i64 0, 1
  %v11 = add i64 0, 8
  %v12 = add i64 0, 255
  %t0 = inttoptr i64 %v1 to ptr
  %v15 = load i64, ptr %t0, align 1
  %t1 = inttoptr i64 %v1 to ptr
  %t2 = getelementptr i8, ptr %t1, i64 8
  %v16 = load i64, ptr %t2, align 1
  %t3 = inttoptr i64 %v1 to ptr
  %t4 = getelementptr i8, ptr %t3, i64 16
  %v17 = load i64, ptr %t4, align 1
  %t5 = inttoptr i64 %v1 to ptr
  %t6 = getelementptr i8, ptr %t5, i64 24
  %v18 = load i64, ptr %t6, align 1
  %t7 = inttoptr i64 %v1 to ptr
  %t8 = getelementptr i8, ptr %t7, i64 32
  %v19 = load i64, ptr %t8, align 1
  %t9 = inttoptr i64 %v1 to ptr
  %t10 = getelementptr i8, ptr %t9, i64 40
  %v20 = load i64, ptr %t10, align 1
  br label %edge0
block6:
  %v535 = phi i64 [ %v16, %edge0 ], [ %v497, %edge2 ]
  br label %edge1
block7:
  br label %edge2
block8:
  br label %edge3
block9:
  br label %edge4
block10:
  br label %edge5
block11:
  br label %edge6
block12:
  br label %edge7
block13:
  br label %edge8
block14:
  %v47 = and i64 %v535, %v12
  br label %edge9
block15:
  %t11 = icmp ne i64 %v47, %v9
  %v52 = zext i1 %t11 to i8
  %v53 = zext i8 %v52 to i64
  br label %edge10
block16:
  %t12 = icmp ult i64 %v47, %v15
  %v58 = zext i1 %t12 to i8
  %v59 = zext i8 %v58 to i64
  br label %edge11
block17:
  %v64 = and i64 %v53, %v59
  br label %edge12
block18:
  %v819 = and i64 %v64, 1
  %t13 = icmp ne i64 %v819, 0
  br i1 %t13, label %edge13, label %edge14
block19:
  %v666 = phi i64 [ %v535, %edge136 ]
  br label %edge15
block20:
  br label %edge16
block21:
  br label %edge17
block22:
  br label %edge18
block23:
  br label %edge19
block24:
  %v544 = phi i64 [ %v47, %edge19 ], [ %v448, %edge21 ]
  br label %edge20
block25:
  br label %edge21
block26:
  br label %edge22
block28:
  br label %edge23
block29:
  br label %edge24
block30:
  br label %edge25
block31:
  br label %edge26
block32:
  br label %edge27
block33:
  %t14 = icmp ult i64 %v544, %v15
  %v113 = zext i1 %t14 to i8
  br label %edge28
block34:
  %v820 = and i8 %v113, 1
  %t15 = icmp ne i8 %v820, 0
  br i1 %t15, label %edge29, label %edge30
block35:
  %v648 = phi i64 [ %v544, %edge128 ]
  br label %edge31
block37:
  br label %edge32
block38:
  br label %edge33
block39:
  br label %edge34
block40:
  br label %edge35
block41:
  br label %edge36
block42:
  br label %edge37
block43:
  br label %edge38
block44:
  br label %edge39
block45:
  %t16 = icmp ult i64 %v544, %v18
  %v147 = zext i1 %t16 to i8
  br label %edge40
block46:
  %v821 = and i8 %v147, 1
  %t17 = icmp ne i8 %v821, 0
  br i1 %t17, label %edge41, label %edge42
block47:
  %v571 = phi i64 [ %v175, %edge48 ], [ %v8, %edge50 ]
  br label %edge43
block48:
  br label %edge44
block49:
  br label %edge45
block50:
  %v164 = add i64 %v544, %v10
  br label %edge46
block51:
  %v169 = add i64 %v164, 18446744073709551615
  %v172 = mul i64 %v169, 4
  %v174 = add i64 %v17, %v172
  %t18 = inttoptr i64 %v174 to ptr
  %t19 = load i32, ptr %t18, align 1
  %v175 = zext i32 %t19 to i64
  br label %edge47
block52:
  br label %edge48
block54:
  br label %edge49
block55:
  br label %edge50
block56:
  br label %edge51
block57:
  br label %edge52
block58:
  br label %edge53
block59:
  %v575 = phi i64 [ %v544, %edge53 ], [ %v584, %edge55 ]
  br label %edge54
block60:
  br label %edge55
block61:
  br label %edge56
block62:
  br label %edge57
block63:
  br label %edge58
block64:
  br label %edge59
block65:
  br label %edge60
block66:
  br label %edge61
block67:
  br label %edge62
block68:
  %t20 = icmp uge i64 %v575, %v47
  %v228 = zext i1 %t20 to i8
  br label %edge63
block69:
  %v822 = and i8 %v228, 1
  %t21 = icmp ne i8 %v822, 0
  br i1 %t21, label %edge64, label %edge65
block70:
  %v584 = phi i64 [ %v247, %edge73 ], [ %v575, %edge75 ]
  %v626 = phi i64 [ %v575, %edge73 ], [ %v575, %edge75 ]
  %v834 = phi i8 [ %v835, %edge73 ], [ %v836, %edge75 ]
  br label %edge66
block71:
  br label %edge67
block72:
  br label %edge68
block73:
  %t22 = icmp uge i64 %v575, %v47
  %v245 = zext i1 %t22 to i8
  %v246 = add i64 0, 1
  %t23 = icmp ne i8 %v245, 0
  br i1 %t23, label %edge69, label %edge70
block226:
  %v247 = sub i64 %v575, %v47
  br label %edge71
block225:
  %v248 = add i64 0, 4027
  %t24 = inttoptr i64 %v2 to ptr
  store i64 %v248, ptr %t24, align 1
  br label %edge72
block74:
  %v835 = add i8 0, 1
  br label %edge73
block76:
  br label %edge74
block77:
  %v836 = add i8 0, 0
  br label %edge75
block78:
  %v823 = and i8 %v834, 1
  %t25 = icmp ne i8 %v823, 0
  br i1 %t25, label %edge76, label %edge77
block79:
  %v618 = phi i64 [ %v319, %edge97 ], [ %v571, %edge99 ]
  br label %edge78
block80:
  br label %edge79
block81:
  br label %edge80
block82:
  br label %edge81
block83:
  br label %edge82
block84:
  br label %edge83
block85:
  br label %edge84
block86:
  br label %edge85
block87:
  br label %edge86
block88:
  br label %edge87
block89:
  %t26 = icmp ult i64 %v584, %v18
  %v291 = zext i1 %t26 to i8
  br label %edge88
block90:
  %v824 = and i8 %v291, 1
  %v832 = add i8 0, 0
  %t27 = icmp ne i8 %v824, 0
  br i1 %t27, label %edge89, label %edge90
block91:
  br label %edge91
block93:
  br label %edge92
block94:
  %v308 = add i64 %v584, %v10
  br label %edge93
block95:
  %v313 = add i64 %v308, 18446744073709551615
  %v316 = mul i64 %v313, 4
  %v318 = add i64 %v17, %v316
  %t28 = inttoptr i64 %v318 to ptr
  %t29 = load i32, ptr %t28, align 1
  %v319 = zext i32 %t29 to i64
  br label %edge94
block96:
  br label %edge95
block100:
  br label %edge96
block101:
  br label %edge97
block103:
  br label %edge98
block104:
  br label %edge99
block105:
  %t30 = icmp ugt i64 %v618, %v571
  %v349 = zext i1 %t30 to i8
  br label %edge100
block106:
  %v825 = and i8 %v349, 1
  %t31 = icmp ne i8 %v825, 0
  br i1 %t31, label %edge101, label %edge102
block107:
  %v719 = phi i64 [ %v618, %edge106 ], [ %v571, %edge108 ]
  %v837 = phi i8 [ %v838, %edge106 ], [ %v839, %edge108 ]
  br label %edge103
block108:
  br label %edge104
block109:
  br label %edge105
block110:
  %v838 = add i8 0, 1
  br label %edge106
block112:
  br label %edge107
block113:
  %v839 = add i8 0, 0
  br label %edge108
block114:
  %v829 = phi i8 [ %v832, %edge90 ], [ %v837, %edge103 ]
  %v830 = phi i64 [ %v571, %edge90 ], [ %v719, %edge103 ]
  %v377 = add i64 %v626, %v10
  br label %edge109
block115:
  %v382 = add i64 %v377, 18446744073709551615
  %t32 = icmp ult i64 %v382, %v18
  %v383 = zext i1 %t32 to i8
  %t33 = icmp ne i8 %v383, 0
  br i1 %t33, label %edge110, label %edge111
block270:
  %v384 = add i64 0, 103169
  br label %edge112
block269:
  %v387 = mul i64 %v382, 4
  %v389 = add i64 %v17, %v387
  br label %edge113
block272:
  %v391 = trunc i64 %v830 to i32
  %t34 = inttoptr i64 %v389 to ptr
  store i32 %v391, ptr %t34, align 1
  br label %edge114
block271:
  br label %edge115
block268:
  %v392 = add i64 0, 4070
  %t35 = inttoptr i64 %v2 to ptr
  store i64 %v392, ptr %t35, align 1
  br label %edge116
block116:
  %v826 = and i8 %v829, 1
  %t36 = icmp ne i8 %v826, 0
  br i1 %t36, label %edge117, label %edge118
block117:
  br label %edge119
block118:
  br label %edge120
block119:
  br label %edge121
block120:
  br label %edge122
block121:
  br label %edge123
block123:
  br label %edge124
block124:
  br label %edge125
block125:
  br label %edge126
block126:
  br label %edge127
block127:
  br label %edge128
block131:
  br label %edge129
block134:
  br label %edge130
block135:
  %v448 = add i64 %v648, %v10
  br label %edge131
block293:
  br label %edge132
block136:
  br label %edge133
block137:
  br label %edge134
block145:
  br label %edge135
block146:
  br label %edge136
block147:
  %v831 = phi i64 [ %v666, %edge15 ], [ %v535, %edge30 ]
  %v828 = and i8 %v52, 1
  %t37 = icmp ne i8 %v828, 0
  br i1 %t37, label %edge137, label %edge138
block148:
  br label %edge139
block149:
  br label %edge140
block150:
  br label %edge141
block151:
  %v496 = and i64 %v11, 63
  %t38 = and i64 %v496, 63
  %v497 = lshr i64 %v831, %t38
  br label %edge142
block152:
  br label %edge143
block153:
  br label %edge144
block155:
  br label %edge145
block156:
  br label %edge146
block157:
  br label %edge147
block3:
  %t39 = inttoptr i64 %v2 to ptr
  %t40 = getelementptr i8, ptr %t39, i64 8
  store i64 %v17, ptr %t40, align 1
  %t41 = inttoptr i64 %v2 to ptr
  %t42 = getelementptr i8, ptr %t41, i64 16
  store i64 %v18, ptr %t42, align 1
  %t43 = inttoptr i64 %v2 to ptr
  %t44 = getelementptr i8, ptr %t43, i64 24
  store i64 %v19, ptr %t44, align 1
  %t45 = inttoptr i64 %v2 to ptr
  %t46 = getelementptr i8, ptr %t45, i64 32
  store i64 %v20, ptr %t46, align 1
  %t47 = inttoptr i64 %v2 to ptr
  %t48 = getelementptr i8, ptr %t47, i64 40
  store i64 %v17, ptr %t48, align 1
  %t49 = inttoptr i64 %v2 to ptr
  %t50 = getelementptr i8, ptr %t49, i64 48
  store i64 %v18, ptr %t50, align 1
  %t51 = inttoptr i64 %v1 to ptr
  %t52 = getelementptr i8, ptr %t51, i64 56
  %v6 = load i64, ptr %t52, align 1
  %t53 = inttoptr i64 %v2 to ptr
  %t54 = getelementptr i8, ptr %t53, i64 56
  store i64 %v6, ptr %t54, align 1
  %t55 = inttoptr i64 %v2 to ptr
  %t56 = getelementptr i8, ptr %t55, i64 64
  store i64 %v19, ptr %t56, align 1
  %t57 = inttoptr i64 %v2 to ptr
  %t58 = getelementptr i8, ptr %t57, i64 72
  store i64 %v20, ptr %t58, align 1
  %t59 = inttoptr i64 %v1 to ptr
  %t60 = getelementptr i8, ptr %t59, i64 48
  %v5 = load i64, ptr %t60, align 1
  %t61 = inttoptr i64 %v2 to ptr
  %t62 = getelementptr i8, ptr %t61, i64 80
  store i64 %v5, ptr %t62, align 1
  br label %edge148
block5:
  %v22 = phi i64 [ %v246, %edge72 ], [ %v384, %edge116 ]
  br label %edge149
block2:
  %t63 = insertvalue { i64, i64 } poison, i64 %v3, 0
  %t64 = insertvalue { i64, i64 } %t63, i64 %v3, 1
  ret { i64, i64 } %t64
block1:
  %v4 = phi i64 [ %v22, %edge149 ]
  %t65 = inttoptr i64 %v2 to ptr
  %v523 = load i64, ptr %t65, align 1
  %t66 = insertvalue { i64, i64 } poison, i64 %v4, 0
  %t67 = insertvalue { i64, i64 } %t66, i64 %v523, 1
  ret { i64, i64 } %t67
edge0:
  br label %block6
edge1:
  br label %block8
edge2:
  br label %block6
edge3:
  br label %block10
edge4:
  br label %block3
edge5:
  br label %block11
edge6:
  br label %block12
edge7:
  br label %block13
edge8:
  br label %block14
edge9:
  br label %block15
edge10:
  br label %block16
edge11:
  br label %block17
edge12:
  br label %block18
edge13:
  br label %block21
edge14:
  br label %block20
edge15:
  br label %block147
edge16:
  br label %block145
edge17:
  br label %block22
edge18:
  br label %block23
edge19:
  br label %block24
edge20:
  br label %block26
edge21:
  br label %block24
edge22:
  br label %block28
edge23:
  br label %block29
edge24:
  br label %block30
edge25:
  br label %block31
edge26:
  br label %block32
edge27:
  br label %block33
edge28:
  br label %block34
edge29:
  br label %block37
edge30:
  br label %block147
edge31:
  br label %block131
edge32:
  br label %block38
edge33:
  br label %block39
edge34:
  br label %block41
edge35:
  br label %block57
edge36:
  br label %block42
edge37:
  br label %block43
edge38:
  br label %block44
edge39:
  br label %block45
edge40:
  br label %block46
edge41:
  br label %block49
edge42:
  br label %block48
edge43:
  br label %block56
edge44:
  br label %block54
edge45:
  br label %block50
edge46:
  br label %block51
edge47:
  br label %block52
edge48:
  br label %block47
edge49:
  br label %block55
edge50:
  br label %block47
edge51:
  br label %block40
edge52:
  br label %block58
edge53:
  br label %block59
edge54:
  br label %block61
edge55:
  br label %block59
edge56:
  br label %block63
edge57:
  br label %block126
edge58:
  br label %block64
edge59:
  br label %block65
edge60:
  br label %block66
edge61:
  br label %block67
edge62:
  br label %block68
edge63:
  br label %block69
edge64:
  br label %block72
edge65:
  br label %block71
edge66:
  br label %block78
edge67:
  br label %block76
edge68:
  br label %block73
edge69:
  br label %block226
edge70:
  br label %block225
edge71:
  br label %block74
edge72:
  br label %block5
edge73:
  br label %block70
edge74:
  br label %block77
edge75:
  br label %block70
edge76:
  br label %block81
edge77:
  br label %block80
edge78:
  br label %block105
edge79:
  br label %block103
edge80:
  br label %block82
edge81:
  br label %block83
edge82:
  br label %block85
edge83:
  br label %block101
edge84:
  br label %block86
edge85:
  br label %block87
edge86:
  br label %block88
edge87:
  br label %block89
edge88:
  br label %block90
edge89:
  br label %block93
edge90:
  br label %block114
edge91:
  br label %block100
edge92:
  br label %block94
edge93:
  br label %block95
edge94:
  br label %block96
edge95:
  br label %block91
edge96:
  br label %block84
edge97:
  br label %block79
edge98:
  br label %block104
edge99:
  br label %block79
edge100:
  br label %block106
edge101:
  br label %block109
edge102:
  br label %block108
edge103:
  br label %block114
edge104:
  br label %block112
edge105:
  br label %block110
edge106:
  br label %block107
edge107:
  br label %block113
edge108:
  br label %block107
edge109:
  br label %block115
edge110:
  br label %block269
edge111:
  br label %block270
edge112:
  br label %block268
edge113:
  br label %block272
edge114:
  br label %block271
edge115:
  br label %block116
edge116:
  br label %block5
edge117:
  br label %block119
edge118:
  br label %block118
edge119:
  br label %block125
edge120:
  br label %block123
edge121:
  br label %block120
edge122:
  br label %block121
edge123:
  br label %block60
edge124:
  br label %block124
edge125:
  br label %block117
edge126:
  br label %block62
edge127:
  br label %block127
edge128:
  br label %block35
edge129:
  br label %block134
edge130:
  br label %block135
edge131:
  br label %block293
edge132:
  br label %block136
edge133:
  br label %block137
edge134:
  br label %block25
edge135:
  br label %block146
edge136:
  br label %block19
edge137:
  br label %block150
edge138:
  br label %block149
edge139:
  br label %block157
edge140:
  br label %block155
edge141:
  br label %block151
edge142:
  br label %block152
edge143:
  br label %block153
edge144:
  br label %block7
edge145:
  br label %block156
edge146:
  br label %block148
edge147:
  br label %block9
edge148:
  br label %block2
edge149:
  br label %block1
}

attributes #0 = { noinline uwtable "frame-pointer"="all" }
