target triple = "arm64-apple-macosx26.0.0"

declare i64 @"mech_compact_allocate"(i64, i64, i64, i64, i64, i64)
declare i64 @"mech_compact_free"(i64, i64)
declare i64 @"mech_compact_writable"(i64, i64, i64, i64, i64, i64, i64)
declare i64 @"memmove"(i64, i64, i64)

define { i64, i64 } @"mech_compact_numeric_4879"(i64 %v0, i64 %v1, i64 %v2) #0 align 128 {
block0:
  %ss0 = alloca [48 x i8], align 8
  %ss1 = alloca [48 x i8], align 8
  %v3 = add i64 0, 0
  %t0 = inttoptr i64 %v1 to ptr
  %t1 = getelementptr i8, ptr %t0, i64 112
  %v5 = load i64, ptr %t1, align 1
  %t2 = inttoptr i64 %v1 to ptr
  %t3 = getelementptr i8, ptr %t2, i64 120
  %v6 = load i64, ptr %t3, align 1
  %t4 = inttoptr i64 %v1 to ptr
  %t5 = getelementptr i8, ptr %t4, i64 128
  %v7 = load i64, ptr %t5, align 1
  %t6 = inttoptr i64 %v1 to ptr
  %t7 = getelementptr i8, ptr %t6, i64 136
  %v8 = load i64, ptr %t7, align 1
  %v10 = add i64 0, 0
  %v11 = add i64 0, 1
  %v12 = add i64 0, 0
  %v13 = add i64 0, 1
  %v14 = add i64 0, 8
  %v15 = add i64 0, 16
  %v16 = add i64 0, 255
  %v17 = add i64 0, 4294967295
  %v18 = add i64 0, 0
  %t8 = inttoptr i64 %v1 to ptr
  %v21 = load i64, ptr %t8, align 1
  %t9 = inttoptr i64 %v1 to ptr
  %t10 = getelementptr i8, ptr %t9, i64 8
  %v22 = load i64, ptr %t10, align 1
  %t11 = inttoptr i64 %v1 to ptr
  %t12 = getelementptr i8, ptr %t11, i64 16
  %v23 = load i64, ptr %t12, align 1
  %t13 = inttoptr i64 %v1 to ptr
  %t14 = getelementptr i8, ptr %t13, i64 24
  %v24 = load i64, ptr %t14, align 1
  %t15 = inttoptr i64 %v1 to ptr
  %t16 = getelementptr i8, ptr %t15, i64 32
  %v25 = load i64, ptr %t16, align 1
  %t17 = inttoptr i64 %v1 to ptr
  %t18 = getelementptr i8, ptr %t17, i64 40
  %v26 = load i64, ptr %t18, align 1
  %t19 = inttoptr i64 %v1 to ptr
  %t20 = getelementptr i8, ptr %t19, i64 48
  %v27 = load i64, ptr %t20, align 1
  %t21 = inttoptr i64 %v1 to ptr
  %t22 = getelementptr i8, ptr %t21, i64 56
  %v28 = load i64, ptr %t22, align 1
  %t23 = inttoptr i64 %v1 to ptr
  %t24 = getelementptr i8, ptr %t23, i64 64
  %v29 = load i64, ptr %t24, align 1
  %t25 = inttoptr i64 %v1 to ptr
  %t26 = getelementptr i8, ptr %t25, i64 72
  %v30 = load i64, ptr %t26, align 1
  %t27 = inttoptr i64 %v1 to ptr
  %t28 = getelementptr i8, ptr %t27, i64 80
  %v31 = load i64, ptr %t28, align 1
  %t29 = inttoptr i64 %v1 to ptr
  %t30 = getelementptr i8, ptr %t29, i64 88
  %v32 = load i64, ptr %t30, align 1
  %t31 = inttoptr i64 %v1 to ptr
  %t32 = getelementptr i8, ptr %t31, i64 96
  %v33 = load i64, ptr %t32, align 1
  %t33 = inttoptr i64 %v1 to ptr
  %t34 = getelementptr i8, ptr %t33, i64 104
  %v34 = load i64, ptr %t34, align 1
  br label %edge0
block6:
  %v586 = phi i64 [ %v22, %edge0 ], [ %v531, %edge2 ]
  br label %edge1
block7:
  br label %edge2
block8:
  br label %edge3
block9:
  br label %edge4
block10:
  br label %edge5
block11:
  br label %edge6
block12:
  br label %edge7
block13:
  br label %edge8
block14:
  br label %edge9
block15:
  br label %edge10
block16:
  %t35 = icmp ult i64 %v586, %v21
  %v67 = zext i1 %t35 to i8
  br label %edge11
block17:
  %v883 = and i8 %v67, 1
  %t36 = icmp ne i8 %v883, 0
  br i1 %t36, label %edge12, label %edge13
block18:
  br label %edge14
block19:
  br label %edge15
block20:
  br label %edge16
block21:
  br label %edge17
block22:
  br label %edge18
block23:
  br label %edge19
block24:
  br label %edge20
block25:
  br label %edge21
block26:
  br label %edge22
block27:
  br label %edge23
block28:
  %t37 = icmp ult i64 %v586, %v24
  %v101 = zext i1 %t37 to i8
  br label %edge24
block29:
  %v884 = and i8 %v101, 1
  %t38 = icmp ne i8 %v884, 0
  br i1 %t38, label %edge25, label %edge26
block30:
  %v601 = phi i64 [ %v129, %edge32 ], [ %v10, %edge34 ]
  br label %edge27
block31:
  br label %edge28
block32:
  br label %edge29
block33:
  %v118 = add i64 %v586, %v13
  br label %edge30
block34:
  %v123 = add i64 %v118, 18446744073709551615
  %v126 = mul i64 %v123, 4
  %v128 = add i64 %v23, %v126
  %t39 = inttoptr i64 %v128 to ptr
  %t40 = load i32, ptr %t39, align 1
  %v129 = zext i32 %t40 to i64
  br label %edge31
block35:
  br label %edge32
block37:
  br label %edge33
block38:
  br label %edge34
block39:
  br label %edge35
block40:
  br label %edge36
block41:
  %v150 = and i64 %v15, 63
  %t41 = and i64 %v150, 63
  %v151 = lshr i64 %v601, %t41
  br label %edge37
block42:
  br label %edge38
block44:
  br label %edge39
block45:
  %v892 = add i8 0, 0
  br label %edge40
block46:
  %t42 = icmp eq i64 %v151, %v12
  %v167 = zext i1 %t42 to i8
  br label %edge41
block47:
  %v885 = and i8 %v167, 1
  %t43 = icmp ne i8 %v885, 0
  br i1 %t43, label %edge42, label %edge43
block48:
  %v682 = phi i64 [ %v586, %edge48 ], [ %v586, %edge152 ]
  br label %edge44
block49:
  br label %edge45
block50:
  br label %edge46
block51:
  br label %edge47
block52:
  br label %edge48
block54:
  br label %edge49
block55:
  br label %edge50
block56:
  br label %edge51
block57:
  br label %edge52
block58:
  br label %edge53
block59:
  br label %edge54
block60:
  br label %edge55
block61:
  br label %edge56
block62:
  %t44 = icmp ult i64 %v151, %v28
  %v210 = zext i1 %t44 to i8
  br label %edge57
block63:
  %v886 = and i8 %v210, 1
  %t45 = icmp ne i8 %v886, 0
  br i1 %t45, label %edge58, label %edge59
block64:
  %v632 = phi i64 [ %v238, %edge65 ], [ %v10, %edge67 ]
  br label %edge60
block65:
  br label %edge61
block66:
  br label %edge62
block67:
  %v227 = add i64 %v151, %v13
  br label %edge63
block68:
  %v232 = add i64 %v227, 18446744073709551615
  %v235 = mul i64 %v232, 4
  %v237 = add i64 %v27, %v235
  %t46 = inttoptr i64 %v237 to ptr
  %t47 = load i32, ptr %t46, align 1
  %v238 = zext i32 %t47 to i64
  br label %edge64
block69:
  br label %edge65
block71:
  br label %edge66
block72:
  br label %edge67
block73:
  br label %edge68
block74:
  %v257 = add i64 %v632, %v11
  %t48 = icmp ule i64 %v257, 4294967295
  %v258 = zext i1 %t48 to i8
  %v259 = add i64 0, 1
  %t49 = icmp ne i8 %v258, 0
  br i1 %t49, label %edge69, label %edge70
block220:
  br label %edge71
block219:
  %v260 = add i64 0, 4950
  %t50 = inttoptr i64 %v2 to ptr
  store i64 %v260, ptr %t50, align 1
  br label %edge72
block75:
  %v264 = add i64 %v151, %v13
  br label %edge73
block76:
  %v269 = add i64 %v264, 18446744073709551615
  %t51 = icmp ult i64 %v269, %v28
  %v270 = zext i1 %t51 to i8
  %t52 = icmp ne i8 %v270, 0
  br i1 %t52, label %edge74, label %edge75
block224:
  %v271 = add i64 0, 103169
  br label %edge76
block223:
  %v274 = mul i64 %v269, 4
  %v276 = add i64 %v27, %v274
  br label %edge77
block226:
  %v278 = trunc i64 %v257 to i32
  %t53 = inttoptr i64 %v276 to ptr
  store i32 %v278, ptr %t53, align 1
  br label %edge78
block225:
  br label %edge79
block222:
  %v279 = add i64 0, 4952
  %t54 = inttoptr i64 %v2 to ptr
  store i64 %v279, ptr %t54, align 1
  br label %edge80
block77:
  br label %edge81
block78:
  %v285 = and i64 %v632, %v16
  br label %edge82
block79:
  br label %edge83
block80:
  br label %edge84
block81:
  br label %edge85
block82:
  br label %edge86
block83:
  br label %edge87
block84:
  br label %edge88
block85:
  br label %edge89
block86:
  %t55 = icmp ult i64 %v285, %v32
  %v307 = zext i1 %t55 to i8
  br label %edge90
block87:
  %v887 = and i8 %v307, 1
  %t56 = icmp ne i8 %v887, 0
  br i1 %t56, label %edge91, label %edge92
block88:
  %v650 = phi i64 [ %v335, %edge98 ], [ %v18, %edge100 ]
  br label %edge93
block89:
  br label %edge94
block90:
  br label %edge95
block91:
  %v324 = add i64 %v285, %v13
  br label %edge96
block92:
  %v329 = add i64 %v324, 18446744073709551615
  %v334 = add i64 %v31, %v329
  %t57 = inttoptr i64 %v334 to ptr
  %t58 = load i8, ptr %t57, align 1
  %v335 = zext i8 %t58 to i64
  br label %edge97
block93:
  br label %edge98
block95:
  br label %edge99
block96:
  br label %edge100
block97:
  br label %edge101
block98:
  br label %edge102
block99:
  %v356 = and i64 %v14, 63
  %t59 = and i64 %v356, 63
  %v357 = lshr i64 %v632, %t59
  br label %edge103
block100:
  br label %edge104
block101:
  br label %edge105
block102:
  br label %edge106
block103:
  br label %edge107
block104:
  br label %edge108
block105:
  br label %edge109
block106:
  br label %edge110
block107:
  %t60 = icmp ult i64 %v357, %v32
  %v379 = zext i1 %t60 to i8
  br label %edge111
block108:
  %v888 = and i8 %v379, 1
  %t61 = icmp ne i8 %v888, 0
  br i1 %t61, label %edge112, label %edge113
block109:
  %v660 = phi i64 [ %v407, %edge119 ], [ %v18, %edge121 ]
  br label %edge114
block110:
  br label %edge115
block111:
  br label %edge116
block112:
  %v396 = add i64 %v357, %v13
  br label %edge117
block113:
  %v401 = add i64 %v396, 18446744073709551615
  %v406 = add i64 %v31, %v401
  %t62 = inttoptr i64 %v406 to ptr
  %t63 = load i8, ptr %t62, align 1
  %v407 = zext i8 %t63 to i64
  br label %edge118
block114:
  br label %edge119
block116:
  br label %edge120
block117:
  br label %edge121
block118:
  br label %edge122
block119:
  br label %edge123
block120:
  %v428 = and i64 %v14, 63
  %t64 = and i64 %v428, 63
  %v429 = shl i64 %v650, %t64
  br label %edge124
block121:
  %v433 = or i64 %v429, %v660
  br label %edge125
block122:
  %t65 = icmp uge i64 %v15, %v151
  %v438 = zext i1 %t65 to i8
  %v439 = add i64 0, 1
  %t66 = icmp ne i8 %v438, 0
  br i1 %t66, label %edge126, label %edge127
block273:
  %v440 = sub i64 %v15, %v151
  br label %edge128
block272:
  %v441 = add i64 0, 5000
  %t67 = inttoptr i64 %v2 to ptr
  store i64 %v441, ptr %t67, align 1
  br label %edge129
block123:
  %v445 = and i64 %v440, 63
  %t68 = and i64 %v445, 63
  %v446 = lshr i64 %v433, %t68
  br label %edge130
block124:
  %v451 = and i64 %v446, %v17
  br label %edge131
block125:
  br label %edge132
block277:
  br label %edge133
block126:
  br label %edge134
block127:
  %v464 = and i64 %v15, 63
  %t69 = and i64 %v464, 63
  %v465 = shl i64 %v151, %t69
  br label %edge135
block128:
  %v470 = or i64 %v451, %v465
  br label %edge136
block129:
  %v475 = and i64 %v470, %v17
  br label %edge137
block130:
  br label %edge138
block283:
  br label %edge139
block131:
  br label %edge140
block132:
  br label %edge141
block133:
  br label %edge142
block134:
  %v493 = add i64 %v586, %v13
  br label %edge143
block135:
  %v498 = add i64 %v493, 18446744073709551615
  %t70 = icmp ult i64 %v498, %v24
  %v499 = zext i1 %t70 to i8
  %t71 = icmp ne i8 %v499, 0
  br i1 %t71, label %edge144, label %edge145
block290:
  %v500 = add i64 0, 103169
  br label %edge146
block289:
  %v503 = mul i64 %v498, 4
  %v505 = add i64 %v23, %v503
  br label %edge147
block292:
  %v507 = trunc i64 %v475 to i32
  %t72 = inttoptr i64 %v505 to ptr
  store i32 %v507, ptr %t72, align 1
  br label %edge148
block291:
  br label %edge149
block288:
  %v508 = add i64 0, 5013
  %t73 = inttoptr i64 %v2 to ptr
  store i64 %v508, ptr %t73, align 1
  br label %edge150
block136:
  br label %edge151
block137:
  br label %edge152
block138:
  br label %edge153
block139:
  %v893 = add i8 0, 1
  br label %edge154
block140:
  %v890 = phi i64 [ %v586, %edge40 ], [ %v682, %edge154 ]
  %v891 = phi i8 [ %v892, %edge40 ], [ %v893, %edge154 ]
  %v889 = and i8 %v891, 1
  %t74 = icmp ne i8 %v889, 0
  br i1 %t74, label %edge155, label %edge156
block141:
  br label %edge157
block142:
  br label %edge158
block143:
  br label %edge159
block144:
  %v531 = add i64 %v890, %v13
  br label %edge160
block302:
  br label %edge161
block145:
  br label %edge162
block146:
  br label %edge163
block148:
  br label %edge164
block149:
  br label %edge165
block150:
  br label %edge166
block3:
  %t75 = inttoptr i64 %v2 to ptr
  %t76 = getelementptr i8, ptr %t75, i64 8
  store i64 %v23, ptr %t76, align 1
  %t77 = inttoptr i64 %v2 to ptr
  %t78 = getelementptr i8, ptr %t77, i64 16
  store i64 %v24, ptr %t78, align 1
  %t79 = inttoptr i64 %v2 to ptr
  %t80 = getelementptr i8, ptr %t79, i64 24
  store i64 %v25, ptr %t80, align 1
  %t81 = inttoptr i64 %v2 to ptr
  %t82 = getelementptr i8, ptr %t81, i64 32
  store i64 %v26, ptr %t82, align 1
  %t83 = inttoptr i64 %v2 to ptr
  %t84 = getelementptr i8, ptr %t83, i64 40
  store i64 %v23, ptr %t84, align 1
  %t85 = inttoptr i64 %v2 to ptr
  %t86 = getelementptr i8, ptr %t85, i64 48
  store i64 %v24, ptr %t86, align 1
  %t87 = inttoptr i64 %v2 to ptr
  %t88 = getelementptr i8, ptr %t87, i64 56
  store i64 %v7, ptr %t88, align 1
  %t89 = inttoptr i64 %v2 to ptr
  %t90 = getelementptr i8, ptr %t89, i64 64
  store i64 %v25, ptr %t90, align 1
  %t91 = inttoptr i64 %v2 to ptr
  %t92 = getelementptr i8, ptr %t91, i64 72
  store i64 %v26, ptr %t92, align 1
  %t93 = inttoptr i64 %v2 to ptr
  %t94 = getelementptr i8, ptr %t93, i64 80
  store i64 %v5, ptr %t94, align 1
  %t95 = inttoptr i64 %v2 to ptr
  %t96 = getelementptr i8, ptr %t95, i64 88
  store i64 %v27, ptr %t96, align 1
  %t97 = inttoptr i64 %v2 to ptr
  %t98 = getelementptr i8, ptr %t97, i64 96
  store i64 %v28, ptr %t98, align 1
  %t99 = inttoptr i64 %v2 to ptr
  %t100 = getelementptr i8, ptr %t99, i64 104
  store i64 %v8, ptr %t100, align 1
  %t101 = inttoptr i64 %v2 to ptr
  %t102 = getelementptr i8, ptr %t101, i64 112
  store i64 %v29, ptr %t102, align 1
  %t103 = inttoptr i64 %v2 to ptr
  %t104 = getelementptr i8, ptr %t103, i64 120
  store i64 %v30, ptr %t104, align 1
  %t105 = inttoptr i64 %v2 to ptr
  %t106 = getelementptr i8, ptr %t105, i64 128
  store i64 %v6, ptr %t106, align 1
  br label %edge167
block5:
  %v38 = phi i64 [ %v259, %edge72 ], [ %v271, %edge80 ], [ %v439, %edge129 ], [ %v500, %edge150 ]
  br label %edge168
block2:
  %t107 = insertvalue { i64, i64 } poison, i64 %v3, 0
  %t108 = insertvalue { i64, i64 } %t107, i64 %v3, 1
  ret { i64, i64 } %t108
block1:
  %v4 = phi i64 [ %v38, %edge168 ]
  %t109 = inttoptr i64 %v2 to ptr
  %v564 = load i64, ptr %t109, align 1
  %t110 = insertvalue { i64, i64 } poison, i64 %v4, 0
  %t111 = insertvalue { i64, i64 } %t110, i64 %v564, 1
  ret { i64, i64 } %t111
edge0:
  br label %block6
edge1:
  br label %block8
edge2:
  br label %block6
edge3:
  br label %block10
edge4:
  br label %block3
edge5:
  br label %block11
edge6:
  br label %block12
edge7:
  br label %block13
edge8:
  br label %block14
edge9:
  br label %block15
edge10:
  br label %block16
edge11:
  br label %block17
edge12:
  br label %block20
edge13:
  br label %block19
edge14:
  br label %block46
edge15:
  br label %block44
edge16:
  br label %block21
edge17:
  br label %block22
edge18:
  br label %block24
edge19:
  br label %block40
edge20:
  br label %block25
edge21:
  br label %block26
edge22:
  br label %block27
edge23:
  br label %block28
edge24:
  br label %block29
edge25:
  br label %block32
edge26:
  br label %block31
edge27:
  br label %block39
edge28:
  br label %block37
edge29:
  br label %block33
edge30:
  br label %block34
edge31:
  br label %block35
edge32:
  br label %block30
edge33:
  br label %block38
edge34:
  br label %block30
edge35:
  br label %block23
edge36:
  br label %block41
edge37:
  br label %block42
edge38:
  br label %block18
edge39:
  br label %block45
edge40:
  br label %block140
edge41:
  br label %block47
edge42:
  br label %block50
edge43:
  br label %block49
edge44:
  br label %block138
edge45:
  br label %block54
edge46:
  br label %block51
edge47:
  br label %block52
edge48:
  br label %block48
edge49:
  br label %block55
edge50:
  br label %block56
edge51:
  br label %block58
edge52:
  br label %block74
edge53:
  br label %block59
edge54:
  br label %block60
edge55:
  br label %block61
edge56:
  br label %block62
edge57:
  br label %block63
edge58:
  br label %block66
edge59:
  br label %block65
edge60:
  br label %block73
edge61:
  br label %block71
edge62:
  br label %block67
edge63:
  br label %block68
edge64:
  br label %block69
edge65:
  br label %block64
edge66:
  br label %block72
edge67:
  br label %block64
edge68:
  br label %block57
edge69:
  br label %block220
edge70:
  br label %block219
edge71:
  br label %block75
edge72:
  br label %block5
edge73:
  br label %block76
edge74:
  br label %block223
edge75:
  br label %block224
edge76:
  br label %block222
edge77:
  br label %block226
edge78:
  br label %block225
edge79:
  br label %block77
edge80:
  br label %block5
edge81:
  br label %block78
edge82:
  br label %block79
edge83:
  br label %block80
edge84:
  br label %block82
edge85:
  br label %block98
edge86:
  br label %block83
edge87:
  br label %block84
edge88:
  br label %block85
edge89:
  br label %block86
edge90:
  br label %block87
edge91:
  br label %block90
edge92:
  br label %block89
edge93:
  br label %block97
edge94:
  br label %block95
edge95:
  br label %block91
edge96:
  br label %block92
edge97:
  br label %block93
edge98:
  br label %block88
edge99:
  br label %block96
edge100:
  br label %block88
edge101:
  br label %block81
edge102:
  br label %block99
edge103:
  br label %block100
edge104:
  br label %block101
edge105:
  br label %block103
edge106:
  br label %block119
edge107:
  br label %block104
edge108:
  br label %block105
edge109:
  br label %block106
edge110:
  br label %block107
edge111:
  br label %block108
edge112:
  br label %block111
edge113:
  br label %block110
edge114:
  br label %block118
edge115:
  br label %block116
edge116:
  br label %block112
edge117:
  br label %block113
edge118:
  br label %block114
edge119:
  br label %block109
edge120:
  br label %block117
edge121:
  br label %block109
edge122:
  br label %block102
edge123:
  br label %block120
edge124:
  br label %block121
edge125:
  br label %block122
edge126:
  br label %block273
edge127:
  br label %block272
edge128:
  br label %block123
edge129:
  br label %block5
edge130:
  br label %block124
edge131:
  br label %block125
edge132:
  br label %block277
edge133:
  br label %block126
edge134:
  br label %block127
edge135:
  br label %block128
edge136:
  br label %block129
edge137:
  br label %block130
edge138:
  br label %block283
edge139:
  br label %block131
edge140:
  br label %block132
edge141:
  br label %block133
edge142:
  br label %block134
edge143:
  br label %block135
edge144:
  br label %block289
edge145:
  br label %block290
edge146:
  br label %block288
edge147:
  br label %block292
edge148:
  br label %block291
edge149:
  br label %block136
edge150:
  br label %block5
edge151:
  br label %block137
edge152:
  br label %block48
edge153:
  br label %block139
edge154:
  br label %block140
edge155:
  br label %block143
edge156:
  br label %block142
edge157:
  br label %block150
edge158:
  br label %block148
edge159:
  br label %block144
edge160:
  br label %block302
edge161:
  br label %block145
edge162:
  br label %block146
edge163:
  br label %block7
edge164:
  br label %block149
edge165:
  br label %block141
edge166:
  br label %block9
edge167:
  br label %block2
edge168:
  br label %block1
}

attributes #0 = { noinline uwtable "frame-pointer"="all" }
