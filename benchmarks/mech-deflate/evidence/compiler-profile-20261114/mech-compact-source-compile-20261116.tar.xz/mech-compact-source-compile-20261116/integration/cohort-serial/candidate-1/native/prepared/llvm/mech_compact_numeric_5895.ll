target triple = "arm64-apple-macosx26.0.0"

declare i64 @"mech_compact_allocate"(i64, i64, i64, i64, i64, i64)
declare i64 @"mech_compact_free"(i64, i64)
declare i64 @"mech_compact_writable"(i64, i64, i64, i64, i64, i64, i64)
declare i64 @"memmove"(i64, i64, i64)

define { i64, i64 } @"mech_compact_numeric_5895"(i64 %v0, i64 %v1, i64 %v2) #0 align 128 {
block0:
  %ss0 = alloca [48 x i8], align 8
  %ss1 = alloca [48 x i8], align 8
  %v3 = add i64 0, 0
  %t0 = inttoptr i64 %v1 to ptr
  %t1 = getelementptr i8, ptr %t0, i64 104
  %v5 = load i64, ptr %t1, align 1
  %t2 = inttoptr i64 %v1 to ptr
  %t3 = getelementptr i8, ptr %t2, i64 112
  %v6 = load i64, ptr %t3, align 1
  %v8 = add i64 0, 0
  %v9 = add i64 0, 0
  %v10 = add i64 0, 0
  %v11 = add i64 0, 1
  %v12 = add i64 0, 9
  %v13 = add i64 0, 10
  %v14 = add i64 0, 13
  %v15 = add i64 0, 16
  %v16 = add i64 0, 288
  %v17 = add i64 0, 547
  %v18 = add i64 0, 511
  %v19 = add i64 0, 4294967295
  %t4 = inttoptr i64 %v1 to ptr
  %v22 = load i64, ptr %t4, align 1
  %t5 = inttoptr i64 %v1 to ptr
  %t6 = getelementptr i8, ptr %t5, i64 8
  %v23 = load i64, ptr %t6, align 1
  %t7 = inttoptr i64 %v1 to ptr
  %t8 = getelementptr i8, ptr %t7, i64 16
  %v24 = load i64, ptr %t8, align 1
  %t9 = inttoptr i64 %v1 to ptr
  %t10 = getelementptr i8, ptr %t9, i64 24
  %v25 = load i64, ptr %t10, align 1
  %t11 = inttoptr i64 %v1 to ptr
  %t12 = getelementptr i8, ptr %t11, i64 32
  %v26 = load i64, ptr %t12, align 1
  %t13 = inttoptr i64 %v1 to ptr
  %t14 = getelementptr i8, ptr %t13, i64 40
  %v27 = load i64, ptr %t14, align 1
  %t15 = inttoptr i64 %v1 to ptr
  %t16 = getelementptr i8, ptr %t15, i64 48
  %v28 = load i64, ptr %t16, align 1
  %t17 = inttoptr i64 %v1 to ptr
  %t18 = getelementptr i8, ptr %t17, i64 56
  %v29 = load i64, ptr %t18, align 1
  %t19 = inttoptr i64 %v1 to ptr
  %t20 = getelementptr i8, ptr %t19, i64 64
  %v30 = load i64, ptr %t20, align 1
  %t21 = inttoptr i64 %v1 to ptr
  %t22 = getelementptr i8, ptr %t21, i64 72
  %v31 = load i64, ptr %t22, align 1
  %t23 = inttoptr i64 %v1 to ptr
  %t24 = getelementptr i8, ptr %t23, i64 80
  %v32 = load i64, ptr %t24, align 1
  %t25 = inttoptr i64 %v1 to ptr
  %t26 = getelementptr i8, ptr %t25, i64 88
  %v33 = load i64, ptr %t26, align 1
  %t27 = inttoptr i64 %v1 to ptr
  %t28 = getelementptr i8, ptr %t27, i64 96
  %v34 = load i64, ptr %t28, align 1
  br label %edge0
block6:
  %v385 = phi i64 [ %v22, %edge0 ], [ %v348, %edge2 ]
  br label %edge1
block7:
  br label %edge2
block8:
  br label %edge3
block10:
  br label %edge4
block11:
  br label %edge5
block12:
  br label %edge6
block13:
  br label %edge7
block14:
  br label %edge8
block15:
  %t29 = icmp ult i64 %v385, %v17
  %v63 = zext i1 %t29 to i8
  br label %edge9
block16:
  %v679 = and i8 %v63, 1
  %t30 = icmp ne i8 %v679, 0
  br i1 %t30, label %edge10, label %edge11
block17:
  %v395 = phi i64 [ %v95, %edge22 ], [ %v8, %edge24 ]
  %v494 = phi i64 [ %v385, %edge22 ], [ %v385, %edge24 ]
  %v686 = phi i8 [ %v687, %edge22 ], [ %v688, %edge24 ]
  br label %edge12
block18:
  br label %edge13
block19:
  br label %edge14
block20:
  %v80 = add i64 %v385, %v11
  br label %edge15
block116:
  br label %edge16
block21:
  %v87 = add i64 %v80, 18446744073709551615
  %t31 = icmp ult i64 %v87, %v32
  %v88 = zext i1 %t31 to i8
  %t32 = icmp ne i8 %v88, 0
  br i1 %t32, label %edge17, label %edge18
block119:
  %v89 = add i64 0, 103169
  br label %edge19
block118:
  %v92 = mul i64 %v87, 2
  %v94 = add i64 %v31, %v92
  %t33 = inttoptr i64 %v94 to ptr
  %t34 = load i16, ptr %t33, align 1
  %v95 = zext i16 %t34 to i64
  br label %edge20
block117:
  %v96 = add i64 0, 5911
  %t35 = inttoptr i64 %v2 to ptr
  store i64 %v96, ptr %t35, align 1
  br label %edge21
block22:
  %v687 = add i8 0, 1
  br label %edge22
block24:
  br label %edge23
block25:
  %v688 = add i8 0, 0
  br label %edge24
block26:
  br label %edge25
block27:
  %v113 = and i64 %v395, %v18
  br label %edge26
block28:
  %v117 = and i64 %v12, 63
  %t36 = and i64 %v117, 63
  %v118 = lshr i64 %v395, %t36
  br label %edge27
block29:
  %v680 = and i8 %v686, 1
  %t37 = icmp ne i8 %v680, 0
  br i1 %t37, label %edge28, label %edge29
block30:
  %v463 = phi i64 [ %v201, %edge54 ], [ %v10, %edge56 ]
  %v689 = phi i8 [ %v690, %edge54 ], [ %v691, %edge56 ]
  br label %edge30
block31:
  br label %edge31
block32:
  br label %edge32
block33:
  br label %edge33
block34:
  br label %edge34
block35:
  br label %edge35
block36:
  br label %edge36
block37:
  br label %edge37
block38:
  br label %edge38
block39:
  br label %edge39
block40:
  %t38 = icmp ult i64 %v113, %v28
  %v151 = zext i1 %t38 to i8
  br label %edge40
block41:
  %v681 = and i8 %v151, 1
  %t39 = icmp ne i8 %v681, 0
  br i1 %t39, label %edge41, label %edge42
block42:
  %v430 = phi i64 [ %v179, %edge48 ], [ %v9, %edge50 ]
  br label %edge43
block43:
  br label %edge44
block44:
  br label %edge45
block45:
  %v168 = add i64 %v113, %v11
  br label %edge46
block46:
  %v173 = add i64 %v168, 18446744073709551615
  %v176 = mul i64 %v173, 4
  %v178 = add i64 %v27, %v176
  %t40 = inttoptr i64 %v178 to ptr
  %t41 = load i32, ptr %t40, align 1
  %v179 = zext i32 %t41 to i64
  br label %edge47
block47:
  br label %edge48
block49:
  br label %edge49
block50:
  br label %edge50
block51:
  br label %edge51
block52:
  br label %edge52
block53:
  %v200 = and i64 %v15, 63
  %t42 = and i64 %v200, 63
  %v201 = lshr i64 %v430, %t42
  br label %edge53
block54:
  %v690 = add i8 0, 1
  br label %edge54
block56:
  br label %edge55
block57:
  %v691 = add i8 0, 0
  br label %edge56
block58:
  %t43 = icmp ult i64 %v113, %v16
  %v217 = zext i1 %t43 to i8
  br label %edge57
block59:
  %v682 = and i8 %v217, 1
  %t44 = icmp ne i8 %v682, 0
  br i1 %t44, label %edge58, label %edge59
block60:
  %v468 = phi i64 [ %v14, %edge63 ], [ %v13, %edge65 ]
  br label %edge60
block61:
  br label %edge61
block62:
  br label %edge62
block63:
  br label %edge63
block65:
  br label %edge64
block66:
  br label %edge65
block67:
  %t45 = icmp ne i64 %v463, %v10
  %v245 = zext i1 %t45 to i8
  br label %edge66
block68:
  %v683 = and i8 %v245, 1
  %t46 = icmp ne i8 %v683, 0
  br i1 %t46, label %edge67, label %edge68
block69:
  %v474 = phi i64 [ %v463, %edge72 ], [ %v468, %edge74 ]
  br label %edge69
block70:
  br label %edge70
block71:
  br label %edge71
block72:
  br label %edge72
block74:
  br label %edge73
block75:
  br label %edge74
block76:
  %v684 = and i8 %v689, 1
  %t47 = icmp ne i8 %v684, 0
  br i1 %t47, label %edge75, label %edge76
block77:
  %v488 = phi i64 [ %v494, %edge98 ]
  br label %edge77
block79:
  br label %edge78
block80:
  %v284 = add i64 %v474, %v118
  %t48 = icmp uge i64 %v284, %v474
  %v285 = zext i1 %t48 to i8
  %v286 = add i64 0, 1
  %t49 = icmp ne i8 %v285, 0
  br i1 %t49, label %edge79, label %edge80
block179:
  br label %edge81
block178:
  %v287 = add i64 0, 5971
  %t50 = inttoptr i64 %v2 to ptr
  store i64 %v287, ptr %t50, align 1
  br label %edge82
block81:
  %t51 = zext i64 %v284 to i128
  %t52 = zext i64 %v15 to i128
  %t53 = mul i128 %t51, %t52
  %t54 = lshr i128 %t53, 64
  %v291 = trunc i128 %t54 to i64
  %t55 = icmp eq i64 %v291, 0
  %v292 = zext i1 %t55 to i8
  %v293 = add i64 0, 1
  %t56 = icmp ne i8 %v292, 0
  br i1 %t56, label %edge83, label %edge84
block181:
  %v294 = mul i64 %v284, %v15
  br label %edge85
block180:
  %v295 = add i64 0, 5972
  %t57 = inttoptr i64 %v2 to ptr
  store i64 %v295, ptr %t57, align 1
  br label %edge86
block82:
  %v299 = and i64 %v294, %v19
  br label %edge87
block83:
  br label %edge88
block184:
  br label %edge89
block84:
  %v309 = add i64 %v494, %v11
  br label %edge90
block85:
  %v314 = add i64 %v309, 18446744073709551615
  %t58 = icmp ult i64 %v314, %v24
  %v315 = zext i1 %t58 to i8
  %t59 = icmp ne i8 %v315, 0
  br i1 %t59, label %edge91, label %edge92
block188:
  %v316 = add i64 0, 103169
  br label %edge93
block187:
  %v319 = mul i64 %v314, 4
  %v321 = add i64 %v23, %v319
  br label %edge94
block190:
  %v323 = trunc i64 %v299 to i32
  %t60 = inttoptr i64 %v321 to ptr
  store i32 %v323, ptr %t60, align 1
  br label %edge95
block189:
  br label %edge96
block186:
  %v324 = add i64 0, 5976
  %t61 = inttoptr i64 %v2 to ptr
  store i64 %v324, ptr %t61, align 1
  br label %edge97
block86:
  br label %edge98
block90:
  br label %edge99
block93:
  br label %edge100
block94:
  %v348 = add i64 %v488, %v11
  br label %edge101
block200:
  br label %edge102
block95:
  br label %edge103
block96:
  br label %edge104
block3:
  %t62 = inttoptr i64 %v2 to ptr
  %t63 = getelementptr i8, ptr %t62, i64 8
  store i64 %v23, ptr %t63, align 1
  %t64 = inttoptr i64 %v2 to ptr
  %t65 = getelementptr i8, ptr %t64, i64 16
  store i64 %v24, ptr %t65, align 1
  %t66 = inttoptr i64 %v2 to ptr
  %t67 = getelementptr i8, ptr %t66, i64 24
  store i64 %v25, ptr %t67, align 1
  %t68 = inttoptr i64 %v2 to ptr
  %t69 = getelementptr i8, ptr %t68, i64 32
  store i64 %v26, ptr %t69, align 1
  %t70 = inttoptr i64 %v2 to ptr
  %t71 = getelementptr i8, ptr %t70, i64 40
  store i64 %v23, ptr %t71, align 1
  %t72 = inttoptr i64 %v2 to ptr
  %t73 = getelementptr i8, ptr %t72, i64 48
  store i64 %v24, ptr %t73, align 1
  %t74 = inttoptr i64 %v2 to ptr
  %t75 = getelementptr i8, ptr %t74, i64 56
  store i64 %v6, ptr %t75, align 1
  %t76 = inttoptr i64 %v2 to ptr
  %t77 = getelementptr i8, ptr %t76, i64 64
  store i64 %v25, ptr %t77, align 1
  %t78 = inttoptr i64 %v2 to ptr
  %t79 = getelementptr i8, ptr %t78, i64 72
  store i64 %v26, ptr %t79, align 1
  %t80 = inttoptr i64 %v2 to ptr
  %t81 = getelementptr i8, ptr %t80, i64 80
  store i64 %v5, ptr %t81, align 1
  br label %edge105
block5:
  %v38 = phi i64 [ %v89, %edge21 ], [ %v286, %edge82 ], [ %v293, %edge86 ], [ %v316, %edge97 ]
  br label %edge106
block2:
  %t82 = insertvalue { i64, i64 } poison, i64 %v3, 0
  %t83 = insertvalue { i64, i64 } %t82, i64 %v3, 1
  ret { i64, i64 } %t83
block1:
  %v4 = phi i64 [ %v38, %edge106 ]
  %t84 = inttoptr i64 %v2 to ptr
  %v374 = load i64, ptr %t84, align 1
  %t85 = insertvalue { i64, i64 } poison, i64 %v4, 0
  %t86 = insertvalue { i64, i64 } %t85, i64 %v374, 1
  ret { i64, i64 } %t86
edge0:
  br label %block6
edge1:
  br label %block8
edge2:
  br label %block6
edge3:
  br label %block10
edge4:
  br label %block11
edge5:
  br label %block12
edge6:
  br label %block13
edge7:
  br label %block14
edge8:
  br label %block15
edge9:
  br label %block16
edge10:
  br label %block19
edge11:
  br label %block18
edge12:
  br label %block26
edge13:
  br label %block24
edge14:
  br label %block20
edge15:
  br label %block116
edge16:
  br label %block21
edge17:
  br label %block118
edge18:
  br label %block119
edge19:
  br label %block117
edge20:
  br label %block22
edge21:
  br label %block5
edge22:
  br label %block17
edge23:
  br label %block25
edge24:
  br label %block17
edge25:
  br label %block27
edge26:
  br label %block28
edge27:
  br label %block29
edge28:
  br label %block32
edge29:
  br label %block31
edge30:
  br label %block58
edge31:
  br label %block56
edge32:
  br label %block33
edge33:
  br label %block34
edge34:
  br label %block36
edge35:
  br label %block52
edge36:
  br label %block37
edge37:
  br label %block38
edge38:
  br label %block39
edge39:
  br label %block40
edge40:
  br label %block41
edge41:
  br label %block44
edge42:
  br label %block43
edge43:
  br label %block51
edge44:
  br label %block49
edge45:
  br label %block45
edge46:
  br label %block46
edge47:
  br label %block47
edge48:
  br label %block42
edge49:
  br label %block50
edge50:
  br label %block42
edge51:
  br label %block35
edge52:
  br label %block53
edge53:
  br label %block54
edge54:
  br label %block30
edge55:
  br label %block57
edge56:
  br label %block30
edge57:
  br label %block59
edge58:
  br label %block62
edge59:
  br label %block61
edge60:
  br label %block67
edge61:
  br label %block65
edge62:
  br label %block63
edge63:
  br label %block60
edge64:
  br label %block66
edge65:
  br label %block60
edge66:
  br label %block68
edge67:
  br label %block71
edge68:
  br label %block70
edge69:
  br label %block76
edge70:
  br label %block74
edge71:
  br label %block72
edge72:
  br label %block69
edge73:
  br label %block75
edge74:
  br label %block69
edge75:
  br label %block79
edge76:
  br label %block3
edge77:
  br label %block90
edge78:
  br label %block80
edge79:
  br label %block179
edge80:
  br label %block178
edge81:
  br label %block81
edge82:
  br label %block5
edge83:
  br label %block181
edge84:
  br label %block180
edge85:
  br label %block82
edge86:
  br label %block5
edge87:
  br label %block83
edge88:
  br label %block184
edge89:
  br label %block84
edge90:
  br label %block85
edge91:
  br label %block187
edge92:
  br label %block188
edge93:
  br label %block186
edge94:
  br label %block190
edge95:
  br label %block189
edge96:
  br label %block86
edge97:
  br label %block5
edge98:
  br label %block77
edge99:
  br label %block93
edge100:
  br label %block94
edge101:
  br label %block200
edge102:
  br label %block95
edge103:
  br label %block96
edge104:
  br label %block7
edge105:
  br label %block2
edge106:
  br label %block1
}

attributes #0 = { noinline uwtable "frame-pointer"="all" }
