target triple = "arm64-apple-macosx26.0.0"

declare i64 @"mech_compact_allocate"(i64, i64, i64, i64, i64, i64)
declare i64 @"mech_compact_free"(i64, i64)
declare i64 @"mech_compact_writable"(i64, i64, i64, i64, i64, i64, i64)
declare i64 @"memmove"(i64, i64, i64)

define { i64, i64 } @"mech_compact_numeric_2821_vector"(i64 %v0, i64 %v1, i64 %v2) #0 align 128 {
block0:
  %ss0 = alloca [48 x i8], align 8
  %ss1 = alloca [48 x i8], align 8
  %v3 = add i64 0, 0
  %t0 = inttoptr i64 %v1 to ptr
  %t1 = getelementptr i8, ptr %t0, i64 88
  %v5 = load i64, ptr %t1, align 1
  %t2 = inttoptr i64 %v1 to ptr
  %t3 = getelementptr i8, ptr %t2, i64 96
  %v6 = load i64, ptr %t3, align 1
  %v8 = add i64 0, 0
  %v9 = add i64 0, 1
  %v10 = add i64 0, 1
  %v11 = add i64 0, 0
  %t4 = inttoptr i64 %v1 to ptr
  %v14 = load i64, ptr %t4, align 1
  %t5 = inttoptr i64 %v1 to ptr
  %t6 = getelementptr i8, ptr %t5, i64 8
  %v15 = load i64, ptr %t6, align 1
  %t7 = inttoptr i64 %v1 to ptr
  %t8 = getelementptr i8, ptr %t7, i64 16
  %v16 = load i64, ptr %t8, align 1
  %t9 = inttoptr i64 %v1 to ptr
  %t10 = getelementptr i8, ptr %t9, i64 24
  %v17 = load i64, ptr %t10, align 1
  %t11 = inttoptr i64 %v1 to ptr
  %t12 = getelementptr i8, ptr %t11, i64 32
  %v18 = load i64, ptr %t12, align 1
  %t13 = inttoptr i64 %v1 to ptr
  %t14 = getelementptr i8, ptr %t13, i64 40
  %v19 = load i64, ptr %t14, align 1
  %t15 = inttoptr i64 %v1 to ptr
  %t16 = getelementptr i8, ptr %t15, i64 48
  %v20 = load i64, ptr %t16, align 1
  %t17 = inttoptr i64 %v1 to ptr
  %t18 = getelementptr i8, ptr %t17, i64 56
  %v21 = load i64, ptr %t18, align 1
  %t19 = inttoptr i64 %v1 to ptr
  %t20 = getelementptr i8, ptr %t19, i64 64
  %v22 = load i64, ptr %t20, align 1
  %t21 = inttoptr i64 %v1 to ptr
  %t22 = getelementptr i8, ptr %t21, i64 72
  %v23 = load i64, ptr %t22, align 1
  %t23 = inttoptr i64 %v1 to ptr
  %t24 = getelementptr i8, ptr %t23, i64 80
  %v24 = load i64, ptr %t24, align 1
  br label %edge0
block6:
  %v299 = phi i64 [ %v16, %edge0 ], [ %v256, %edge2 ]
  br label %edge1
block7:
  br label %edge2
block8:
  br label %edge3
block10:
  br label %edge4
block11:
  br label %edge5
block12:
  br label %edge6
block13:
  br label %edge7
block14:
  br label %edge8
block15:
  br label %edge9
block16:
  %t25 = icmp ult i64 %v299, %v15
  %v58 = zext i1 %t25 to i8
  br label %edge10
block17:
  %v421 = and i8 %v58, 1
  %t26 = icmp ne i8 %v421, 0
  br i1 %t26, label %edge11, label %edge12
block18:
  %v332 = phi i64 [ %v299, %edge70 ]
  br label %edge13
block20:
  br label %edge14
block21:
  %v75 = add i64 %v14, %v299
  %t27 = icmp uge i64 %v75, %v14
  %v76 = zext i1 %t27 to i8
  %v77 = add i64 0, 1
  %t28 = icmp ne i8 %v76, 0
  br i1 %t28, label %edge15, label %edge16
block95:
  br label %edge17
block94:
  %v78 = add i64 0, 2837
  %t29 = inttoptr i64 %v2 to ptr
  store i64 %v78, ptr %t29, align 1
  br label %edge18
block22:
  br label %edge19
block23:
  br label %edge20
block24:
  br label %edge21
block25:
  br label %edge22
block26:
  br label %edge23
block27:
  br label %edge24
block28:
  br label %edge25
block29:
  %t30 = icmp ult i64 %v75, %v18
  %v99 = zext i1 %t30 to i8
  br label %edge26
block30:
  %v422 = and i8 %v99, 1
  %t31 = icmp ne i8 %v422, 0
  br i1 %t31, label %edge27, label %edge28
block31:
  %v309 = phi i64 [ %v127, %edge34 ], [ %v11, %edge36 ]
  br label %edge29
block32:
  br label %edge30
block33:
  br label %edge31
block34:
  %v116 = add i64 %v75, %v10
  br label %edge32
block35:
  %v121 = add i64 %v116, 18446744073709551615
  %v126 = add i64 %v17, %v121
  %t32 = inttoptr i64 %v126 to ptr
  %t33 = load i8, ptr %t32, align 1
  %v127 = zext i8 %t33 to i64
  br label %edge33
block36:
  br label %edge34
block38:
  br label %edge35
block39:
  br label %edge36
block40:
  br label %edge37
block41:
  br label %edge38
block42:
  br label %edge39
block43:
  br label %edge40
block44:
  br label %edge41
block45:
  br label %edge42
block46:
  br label %edge43
block47:
  br label %edge44
block48:
  br label %edge45
block49:
  %t34 = icmp ult i64 %v309, %v22
  %v165 = zext i1 %t34 to i8
  br label %edge46
block50:
  %v423 = and i8 %v165, 1
  %t35 = icmp ne i8 %v423, 0
  br i1 %t35, label %edge47, label %edge48
block51:
  %v322 = phi i64 [ %v192, %edge54 ], [ %v8, %edge56 ]
  br label %edge49
block52:
  br label %edge50
block53:
  br label %edge51
block54:
  %v181 = add i64 %v309, %v10
  br label %edge52
block55:
  %v186 = add i64 %v181, 18446744073709551615
  %v189 = mul i64 %v186, 4
  %v191 = add i64 %v21, %v189
  %t36 = inttoptr i64 %v191 to ptr
  %t37 = load i32, ptr %t36, align 1
  %v192 = zext i32 %t37 to i64
  br label %edge53
block56:
  br label %edge54
block58:
  br label %edge55
block59:
  br label %edge56
block60:
  br label %edge57
block61:
  %v211 = add i64 %v322, %v9
  %t38 = icmp ule i64 %v211, 4294967295
  %v212 = zext i1 %t38 to i8
  %v213 = add i64 0, 1
  %t39 = icmp ne i8 %v212, 0
  br i1 %t39, label %edge58, label %edge59
block136:
  br label %edge60
block135:
  %v214 = add i64 0, 2879
  %t40 = inttoptr i64 %v2 to ptr
  store i64 %v214, ptr %t40, align 1
  br label %edge61
block62:
  %v217 = add i64 %v309, %v10
  br label %edge62
block63:
  %v222 = add i64 %v217, 18446744073709551615
  %t41 = icmp ult i64 %v222, %v22
  %v223 = zext i1 %t41 to i8
  %t42 = icmp ne i8 %v223, 0
  br i1 %t42, label %edge63, label %edge64
block140:
  %v224 = add i64 0, 103169
  br label %edge65
block139:
  %v227 = mul i64 %v222, 4
  %v229 = add i64 %v21, %v227
  br label %edge66
block142:
  %v231 = trunc i64 %v211 to i32
  %t43 = inttoptr i64 %v229 to ptr
  store i32 %v231, ptr %t43, align 1
  br label %edge67
block141:
  br label %edge68
block138:
  %v232 = add i64 0, 2881
  %t44 = inttoptr i64 %v2 to ptr
  store i64 %v232, ptr %t44, align 1
  br label %edge69
block64:
  br label %edge70
block68:
  br label %edge71
block71:
  br label %edge72
block72:
  %v256 = add i64 %v332, %v10
  br label %edge73
block152:
  br label %edge74
block73:
  br label %edge75
block74:
  br label %edge76
block3:
  %t45 = inttoptr i64 %v2 to ptr
  %t46 = getelementptr i8, ptr %t45, i64 8
  store i64 %v21, ptr %t46, align 1
  %t47 = inttoptr i64 %v2 to ptr
  %t48 = getelementptr i8, ptr %t47, i64 16
  store i64 %v22, ptr %t48, align 1
  %t49 = inttoptr i64 %v2 to ptr
  %t50 = getelementptr i8, ptr %t49, i64 24
  store i64 %v23, ptr %t50, align 1
  %t51 = inttoptr i64 %v2 to ptr
  %t52 = getelementptr i8, ptr %t51, i64 32
  store i64 %v24, ptr %t52, align 1
  %t53 = inttoptr i64 %v2 to ptr
  %t54 = getelementptr i8, ptr %t53, i64 40
  store i64 %v21, ptr %t54, align 1
  %t55 = inttoptr i64 %v2 to ptr
  %t56 = getelementptr i8, ptr %t55, i64 48
  store i64 %v22, ptr %t56, align 1
  %t57 = inttoptr i64 %v2 to ptr
  %t58 = getelementptr i8, ptr %t57, i64 56
  store i64 %v6, ptr %t58, align 1
  %t59 = inttoptr i64 %v2 to ptr
  %t60 = getelementptr i8, ptr %t59, i64 64
  store i64 %v23, ptr %t60, align 1
  %t61 = inttoptr i64 %v2 to ptr
  %t62 = getelementptr i8, ptr %t61, i64 72
  store i64 %v24, ptr %t62, align 1
  %t63 = inttoptr i64 %v2 to ptr
  %t64 = getelementptr i8, ptr %t63, i64 80
  store i64 %v5, ptr %t64, align 1
  br label %edge77
block5:
  %v27 = phi i64 [ %v77, %edge18 ], [ %v213, %edge61 ], [ %v224, %edge69 ]
  br label %edge78
block2:
  %t65 = insertvalue { i64, i64 } poison, i64 %v3, 0
  %t66 = insertvalue { i64, i64 } %t65, i64 %v3, 1
  ret { i64, i64 } %t66
block1:
  %v4 = phi i64 [ %v27, %edge78 ]
  %t67 = inttoptr i64 %v2 to ptr
  %v286 = load i64, ptr %t67, align 1
  %t68 = insertvalue { i64, i64 } poison, i64 %v4, 0
  %t69 = insertvalue { i64, i64 } %t68, i64 %v286, 1
  ret { i64, i64 } %t69
edge0:
  br label %block6
edge1:
  br label %block8
edge2:
  br label %block6
edge3:
  br label %block10
edge4:
  br label %block11
edge5:
  br label %block12
edge6:
  br label %block13
edge7:
  br label %block14
edge8:
  br label %block15
edge9:
  br label %block16
edge10:
  br label %block17
edge11:
  br label %block20
edge12:
  br label %block3
edge13:
  br label %block68
edge14:
  br label %block21
edge15:
  br label %block95
edge16:
  br label %block94
edge17:
  br label %block22
edge18:
  br label %block5
edge19:
  br label %block23
edge20:
  br label %block25
edge21:
  br label %block41
edge22:
  br label %block26
edge23:
  br label %block27
edge24:
  br label %block28
edge25:
  br label %block29
edge26:
  br label %block30
edge27:
  br label %block33
edge28:
  br label %block32
edge29:
  br label %block40
edge30:
  br label %block38
edge31:
  br label %block34
edge32:
  br label %block35
edge33:
  br label %block36
edge34:
  br label %block31
edge35:
  br label %block39
edge36:
  br label %block31
edge37:
  br label %block24
edge38:
  br label %block42
edge39:
  br label %block43
edge40:
  br label %block45
edge41:
  br label %block61
edge42:
  br label %block46
edge43:
  br label %block47
edge44:
  br label %block48
edge45:
  br label %block49
edge46:
  br label %block50
edge47:
  br label %block53
edge48:
  br label %block52
edge49:
  br label %block60
edge50:
  br label %block58
edge51:
  br label %block54
edge52:
  br label %block55
edge53:
  br label %block56
edge54:
  br label %block51
edge55:
  br label %block59
edge56:
  br label %block51
edge57:
  br label %block44
edge58:
  br label %block136
edge59:
  br label %block135
edge60:
  br label %block62
edge61:
  br label %block5
edge62:
  br label %block63
edge63:
  br label %block139
edge64:
  br label %block140
edge65:
  br label %block138
edge66:
  br label %block142
edge67:
  br label %block141
edge68:
  br label %block64
edge69:
  br label %block5
edge70:
  br label %block18
edge71:
  br label %block71
edge72:
  br label %block72
edge73:
  br label %block152
edge74:
  br label %block73
edge75:
  br label %block74
edge76:
  br label %block7
edge77:
  br label %block2
edge78:
  br label %block1
}

attributes #0 = { noinline uwtable "frame-pointer"="all" }
