from pathlib import Path
import json,subprocess,time,os,sys,statistics,datetime,traceback
root=Path('/private/tmp/mech-compact-integration-20261116');cohort=root/'cohort-serial'
subjects={'control':Path('/private/tmp/mech-dimension-native-pgo-20261115/use'),'candidate':Path('/private/tmp/mech-parser-lexical-native-pgo-20261116/use')}
order=['control','candidate','candidate','control','candidate','control','control','candidate'];rows=[];counts={k:0 for k in subjects}
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
record={'pid':os.getpid(),'state':'running','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};save(cohort/'job.json',record)
save(cohort/'configuration.json',{'order':order,'subjects':{k:str(v) for k,v in subjects.items()},'same_source_and_native_pipeline':True,'native_emitter_workers':0,'boundary':'Single wall-clock interval from launching the frontend on fresh .mec source through fresh canonical bytecode, all native and LLVM stages, Object assembly/composition, and final executable linking. Compiler bootstrap and fixed runtime/entry-adapter construction excluded consistently with historical total. No generated MBC, Object or IR cache. All setup/builds complete, no concurrent heavy work.','comparison':'Only optimized parser frontend differs. Both frontends use legitimate native CPU tuning, ThinLTO, CGU1, mimalloc, and their own PGO from the same fixed eight-program training corpus; this new source was not in that corpus. Same merged native emitter and LLVM22.1.8. Four complete fresh builds each; all outputs and whole executables byte checked.'})
try:
 for variant in order:
  counts[variant]+=1;name=variant+'-'+str(counts[variant]);directory=cohort/name
  command=[sys.executable,str(cohort/'observation.py'),str(directory),str(subjects[variant])]
  with (cohort/(name+'.wrapper.stdout')).open('w') as out,(cohort/(name+'.wrapper.stderr')).open('w') as err:r=subprocess.run(command,stdout=out,stderr=err)
  assert r.returncode==0,(name,r.returncode)
  row=json.loads((directory/'result.json').read_text());row.update(name=name,variant=variant);rows.append(row);save(cohort/'observations.json',rows)
  print(json.dumps({'name':name,'source_to_executable_seconds':row['source_to_executable_seconds']}),flush=True)
 fields=['source_to_executable_seconds','frontend_process_seconds','native_recipe_seconds','native_link_seconds','handoff_seconds']
 means={field:{variant:statistics.mean(row[field] for row in rows if row['variant']==variant) for variant in subjects} for field in fields}
 blocks=[]
 for block in [rows[:4],rows[4:]]:
  values={variant:statistics.mean(row['source_to_executable_seconds'] for row in block if row['variant']==variant) for variant in subjects};values['reduction_fraction']=1-values['candidate']/values['control'];blocks.append(values)
 phases={}
 for variant in subjects:
  for row in [r for r in rows if r['variant']==variant]:
   receipt=json.loads((cohort/row['name']/'frontend/compile.json').read_text())
   for phase in receipt['phases']:phases.setdefault(phase['phase'],{}).setdefault(variant,[]).append(phase['seconds'])
 summary={'means':means,'balanced_blocks':blocks,'full_build_reduction_fraction':1-means['source_to_executable_seconds']['candidate']/means['source_to_executable_seconds']['control'],'frontend_phase_means':{phase:{v:statistics.mean(values) for v,values in per_variant.items()} for phase,per_variant in phases.items()},'all_source_MBC_Object_and_complete_metadata_exact':all(all(p['matches_reference'] for p in row['files'].values()) for row in rows),'all_complete_executable_images_match_supplied_Object_reference':all(row['complete_executable_matches_supplied_object_reference'] for row in rows),'object_text_bytes':55956,'observations':len(rows),'scope':'Same source, same complete small-object pipeline, same final executable. The historical 13.41s used a different source; it is not a controlled compiler speedup comparison.'}
 save(cohort/'summary.json',summary);record.update(state='complete',exit_code=0)
except BaseException as error:record.update(state='failed',exit_code=1,error=repr(error));traceback.print_exc()
record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save(cohort/'job.json',record);print(json.dumps(record),flush=True);raise SystemExit(record['exit_code'])
