target triple = "arm64-apple-macosx26.0.0"

declare i64 @"mech_compact_allocate"(i64, i64, i64, i64, i64, i64)
declare i64 @"mech_compact_free"(i64, i64)
declare i64 @"mech_compact_writable"(i64, i64, i64, i64, i64, i64, i64)
declare i64 @"memmove"(i64, i64, i64)

define { i64, i64 } @"mech_compact_numeric_8026"(i64 %v0, i64 %v1, i64 %v2) #0 align 128 {
block0:
  %ss0 = alloca [48 x i8], align 8
  %ss1 = alloca [48 x i8], align 8
  %v3 = add i64 0, 0
  %t0 = inttoptr i64 %v1 to ptr
  %t1 = getelementptr i8, ptr %t0, i64 56
  %v5 = load i64, ptr %t1, align 1
  %t2 = inttoptr i64 %v1 to ptr
  %t3 = getelementptr i8, ptr %t2, i64 64
  %v6 = load i64, ptr %t3, align 1
  %v8 = add i64 0, 0
  %v9 = add i64 0, 1
  %t4 = inttoptr i64 %v1 to ptr
  %v12 = load i64, ptr %t4, align 1
  %t5 = inttoptr i64 %v1 to ptr
  %t6 = getelementptr i8, ptr %t5, i64 8
  %v13 = load i64, ptr %t6, align 1
  %t7 = inttoptr i64 %v1 to ptr
  %t8 = getelementptr i8, ptr %t7, i64 16
  %v14 = load i64, ptr %t8, align 1
  %t9 = inttoptr i64 %v1 to ptr
  %t10 = getelementptr i8, ptr %t9, i64 24
  %v15 = load i64, ptr %t10, align 1
  %t11 = inttoptr i64 %v1 to ptr
  %t12 = getelementptr i8, ptr %t11, i64 32
  %v16 = load i64, ptr %t12, align 1
  %t13 = inttoptr i64 %v1 to ptr
  %t14 = getelementptr i8, ptr %t13, i64 40
  %v17 = load i64, ptr %t14, align 1
  %t15 = inttoptr i64 %v1 to ptr
  %t16 = getelementptr i8, ptr %t15, i64 48
  %v18 = load i64, ptr %t16, align 1
  br label %edge0
block6:
  %v240 = phi i64 [ %v14, %edge0 ], [ %v197, %edge2 ]
  br label %edge1
block7:
  br label %edge2
block8:
  br label %edge3
block9:
  br label %edge4
block10:
  br label %edge5
block11:
  br label %edge6
block12:
  br label %edge7
block13:
  br label %edge8
block14:
  br label %edge9
block15:
  %t17 = icmp ult i64 %v240, %v13
  %v49 = zext i1 %t17 to i8
  br label %edge10
block16:
  %v335 = and i8 %v49, 1
  %t18 = icmp ne i8 %v335, 0
  br i1 %t18, label %edge11, label %edge12
block17:
  %v254 = phi i64 [ %v255, %edge33 ], [ %v240, %edge35 ]
  %v319 = phi i64 [ %v251, %edge33 ], [ %v8, %edge35 ]
  br label %edge13
block18:
  br label %edge14
block19:
  br label %edge15
block20:
  %v66 = add i64 %v12, %v240
  %t19 = icmp uge i64 %v66, %v12
  %v67 = zext i1 %t19 to i8
  %v68 = add i64 0, 1
  %t20 = icmp ne i8 %v67, 0
  br i1 %t20, label %edge16, label %edge17
block75:
  br label %edge18
block74:
  %v69 = add i64 0, 8041
  %t21 = inttoptr i64 %v2 to ptr
  store i64 %v69, ptr %t21, align 1
  br label %edge19
block21:
  br label %edge20
block22:
  %t22 = icmp ult i64 %v66, %v16
  %v76 = zext i1 %t22 to i8
  br label %edge21
block23:
  %v336 = and i8 %v76, 1
  %t23 = icmp ne i8 %v336, 0
  br i1 %t23, label %edge22, label %edge23
block24:
  %v251 = phi i64 [ %v106, %edge30 ], [ %v8, %edge32 ]
  %v255 = phi i64 [ %v240, %edge30 ], [ %v240, %edge32 ]
  br label %edge24
block25:
  br label %edge25
block26:
  br label %edge26
block27:
  %v93 = add i64 %v66, %v9
  br label %edge27
block83:
  br label %edge28
block28:
  %v100 = add i64 %v93, 18446744073709551615
  %v103 = mul i64 %v100, 4
  %v105 = add i64 %v15, %v103
  %t24 = inttoptr i64 %v105 to ptr
  %t25 = load i32, ptr %t24, align 1
  %v106 = zext i32 %t25 to i64
  br label %edge29
block29:
  br label %edge30
block31:
  br label %edge31
block32:
  br label %edge32
block33:
  br label %edge33
block35:
  br label %edge34
block36:
  br label %edge35
block37:
  %t26 = icmp ult i64 %v254, %v13
  %v133 = zext i1 %t26 to i8
  br label %edge36
block38:
  %v337 = and i8 %v133, 1
  %t27 = icmp ne i8 %v337, 0
  br i1 %t27, label %edge37, label %edge38
block39:
  %v271 = phi i64 [ %v254, %edge51 ], [ %v254, %edge53 ]
  br label %edge39
block40:
  br label %edge40
block41:
  br label %edge41
block42:
  %v150 = add i64 %v254, %v9
  br label %edge42
block99:
  br label %edge43
block43:
  %v157 = add i64 %v150, 18446744073709551615
  %t28 = icmp ult i64 %v157, %v16
  %v158 = zext i1 %t28 to i8
  %t29 = icmp ne i8 %v158, 0
  br i1 %t29, label %edge44, label %edge45
block102:
  %v159 = add i64 0, 103169
  br label %edge46
block101:
  %v162 = mul i64 %v157, 4
  %v164 = add i64 %v15, %v162
  br label %edge47
block104:
  %v166 = trunc i64 %v319 to i32
  %t30 = inttoptr i64 %v164 to ptr
  store i32 %v166, ptr %t30, align 1
  br label %edge48
block103:
  br label %edge49
block100:
  %v167 = add i64 0, 8064
  %t31 = inttoptr i64 %v2 to ptr
  store i64 %v167, ptr %t31, align 1
  br label %edge50
block44:
  br label %edge51
block46:
  br label %edge52
block47:
  br label %edge53
block48:
  %t32 = icmp ult i64 %v271, %v13
  %v180 = zext i1 %t32 to i8
  br label %edge54
block49:
  %v338 = and i8 %v180, 1
  %t33 = icmp ne i8 %v338, 0
  br i1 %t33, label %edge55, label %edge56
block50:
  br label %edge57
block51:
  br label %edge58
block52:
  br label %edge59
block53:
  %v197 = add i64 %v271, %v9
  br label %edge60
block115:
  br label %edge61
block54:
  br label %edge62
block55:
  br label %edge63
block57:
  br label %edge64
block58:
  br label %edge65
block59:
  br label %edge66
block3:
  %t34 = inttoptr i64 %v2 to ptr
  %t35 = getelementptr i8, ptr %t34, i64 8
  store i64 %v15, ptr %t35, align 1
  %t36 = inttoptr i64 %v2 to ptr
  %t37 = getelementptr i8, ptr %t36, i64 16
  store i64 %v16, ptr %t37, align 1
  %t38 = inttoptr i64 %v2 to ptr
  %t39 = getelementptr i8, ptr %t38, i64 24
  store i64 %v17, ptr %t39, align 1
  %t40 = inttoptr i64 %v2 to ptr
  %t41 = getelementptr i8, ptr %t40, i64 32
  store i64 %v18, ptr %t41, align 1
  %t42 = inttoptr i64 %v2 to ptr
  %t43 = getelementptr i8, ptr %t42, i64 40
  store i64 %v15, ptr %t43, align 1
  %t44 = inttoptr i64 %v2 to ptr
  %t45 = getelementptr i8, ptr %t44, i64 48
  store i64 %v16, ptr %t45, align 1
  %t46 = inttoptr i64 %v2 to ptr
  %t47 = getelementptr i8, ptr %t46, i64 56
  store i64 %v6, ptr %t47, align 1
  %t48 = inttoptr i64 %v2 to ptr
  %t49 = getelementptr i8, ptr %t48, i64 64
  store i64 %v17, ptr %t49, align 1
  %t50 = inttoptr i64 %v2 to ptr
  %t51 = getelementptr i8, ptr %t50, i64 72
  store i64 %v18, ptr %t51, align 1
  %t52 = inttoptr i64 %v2 to ptr
  %t53 = getelementptr i8, ptr %t52, i64 80
  store i64 %v5, ptr %t53, align 1
  br label %edge67
block5:
  %v20 = phi i64 [ %v68, %edge19 ], [ %v159, %edge50 ]
  br label %edge68
block2:
  %t54 = insertvalue { i64, i64 } poison, i64 %v3, 0
  %t55 = insertvalue { i64, i64 } %t54, i64 %v3, 1
  ret { i64, i64 } %t55
block1:
  %v4 = phi i64 [ %v20, %edge68 ]
  %t56 = inttoptr i64 %v2 to ptr
  %v227 = load i64, ptr %t56, align 1
  %t57 = insertvalue { i64, i64 } poison, i64 %v4, 0
  %t58 = insertvalue { i64, i64 } %t57, i64 %v227, 1
  ret { i64, i64 } %t58
edge0:
  br label %block6
edge1:
  br label %block8
edge2:
  br label %block6
edge3:
  br label %block10
edge4:
  br label %block3
edge5:
  br label %block11
edge6:
  br label %block12
edge7:
  br label %block13
edge8:
  br label %block14
edge9:
  br label %block15
edge10:
  br label %block16
edge11:
  br label %block19
edge12:
  br label %block18
edge13:
  br label %block37
edge14:
  br label %block35
edge15:
  br label %block20
edge16:
  br label %block75
edge17:
  br label %block74
edge18:
  br label %block21
edge19:
  br label %block5
edge20:
  br label %block22
edge21:
  br label %block23
edge22:
  br label %block26
edge23:
  br label %block25
edge24:
  br label %block33
edge25:
  br label %block31
edge26:
  br label %block27
edge27:
  br label %block83
edge28:
  br label %block28
edge29:
  br label %block29
edge30:
  br label %block24
edge31:
  br label %block32
edge32:
  br label %block24
edge33:
  br label %block17
edge34:
  br label %block36
edge35:
  br label %block17
edge36:
  br label %block38
edge37:
  br label %block41
edge38:
  br label %block40
edge39:
  br label %block48
edge40:
  br label %block46
edge41:
  br label %block42
edge42:
  br label %block99
edge43:
  br label %block43
edge44:
  br label %block101
edge45:
  br label %block102
edge46:
  br label %block100
edge47:
  br label %block104
edge48:
  br label %block103
edge49:
  br label %block44
edge50:
  br label %block5
edge51:
  br label %block39
edge52:
  br label %block47
edge53:
  br label %block39
edge54:
  br label %block49
edge55:
  br label %block52
edge56:
  br label %block51
edge57:
  br label %block59
edge58:
  br label %block57
edge59:
  br label %block53
edge60:
  br label %block115
edge61:
  br label %block54
edge62:
  br label %block55
edge63:
  br label %block7
edge64:
  br label %block58
edge65:
  br label %block50
edge66:
  br label %block9
edge67:
  br label %block2
edge68:
  br label %block1
}

attributes #0 = { noinline uwtable "frame-pointer"="all" }
