from pathlib import Path
import json,subprocess,time,os,sys,hashlib,shutil,datetime,traceback
root=Path('/private/tmp/mech-compact-integration-20261116/final')
repo=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech')
old=Path('/private/tmp/mech-pr973-refresh-20261115/link')
link=root/'link';link.mkdir(exist_ok=False)
record={'state':'waiting_for_compiler_libraries','pid':os.getpid(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def pin(path):
 with path.open('rb') as stream:return {'bytes':path.stat().st_size,'sha256':hashlib.file_digest(stream,'sha256').hexdigest()}
save(root/'adapter-job.json',record)
try:
 while json.loads((root/'build-job.json').read_text())['state']=='running':time.sleep(1)
 assert json.loads((root/'build-job.json').read_text())['exit_code']==0
 for name in ['worker.rs','pinned_allocator.rs','libmimalloc.a']:shutil.copy2(old/name,link/name)
 capture=link/'capture';capture.mkdir()
 script=(old/'capture/capture-linker.py').read_text().replace(str(old/'capture'),str(capture))
 (capture/'capture-linker.py').write_text(script);(capture/'capture-linker.py').chmod(0o755)
 shutil.copy2(repo/'benchmarks/mech-deflate/native-profile/compact-size/fixtures/prepared.o',link/'program.o')
 # Use the supplied small Object only for the independent executable reference.
 shutil.copy2(Path('/private/tmp/mech-smaller39e-handoff-20261116/program.o'),link/'program.o')
 rows=[json.loads(line) for line in (root/'build.jsonl').read_text().splitlines()]
 command=['rustc','+nightly-2026-03-03','--edition=2024','--crate-name','compact_size_runtime_worker','-C','opt-level=3','-C','lto=thin','-C','codegen-units=1','-D','warnings',str(link/'worker.rs'),'-o',str(link/'worker')]
 deps=[];directories=set()
 for name in ['mech_gpu','mech_engine','serde','serde_json','miniz_oxide']:
  paths=[Path(p) for row in rows if row.get('reason')=='compiler-artifact' and row['target']['name']==name for p in row['filenames'] if p.endswith('.rlib')]
  assert len(paths)==1,(name,paths)
  path=paths[0];directories.add(path.parent);command+=['--extern',name+'='+str(path)];deps.append({'name':name,'path':str(path),**pin(path)})
 for directory in sorted(directories):command+=['-L','dependency='+str(directory)]
 command+=['-C','link-arg='+str(link/'libmimalloc.a'),'-C','link-arg='+str(link/'program.o'),'-C','linker='+str(capture/'capture-linker.py')]
 save(link/'build-command.json',{'command':command,'dependencies':deps,'source_pins':{name:pin(link/name) for name in ['worker.rs','pinned_allocator.rs','libmimalloc.a']},'scope':'One-time fixed runtime and generic entry adapter construction, excluded consistently from program compilation timing.'})
 record['state']='building_fixed_runtime_adapter';save(root/'adapter-job.json',record)
 env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')};env['ZERO_AR_DATE']='1'
 start=time.perf_counter()
 with (link/'build.stdout').open('w') as out,(link/'build.stderr').open('w') as err:r=subprocess.run(command,cwd=repo,env=env,stdout=out,stderr=err)
 save(link/'build.json',{'seconds':time.perf_counter()-start,'exit_code':r.returncode});assert r.returncode==0
 captured=json.loads((capture/'link-command.json').read_text());command=captured['relink_command'];save(root/'link-command.json',command)
 static=[]
 for item in captured['inputs']:
  path=Path(item['retained_path'])
  if path.name=='program.o':continue
  assert pin(path)=={key:item[key] for key in ['bytes','sha256']}
  static.append({'path':str(path),**pin(path)})
 save(root/'link-inputs.json',static)
 with (link/'reference.stdout').open('w') as out,(link/'reference.stderr').open('w') as err:r=subprocess.run(command,cwd=repo,env=env,stdout=out,stderr=err)
 assert r.returncode==0;shutil.copy2(link/'worker',root/'reference-worker');save(root/'reference-executable.json',pin(root/'reference-worker'))
 case=Path('/private/tmp/mech-smaller39e-full-native-20261116/smoke-inputs/cases.json')
 metadata=repo/'benchmarks/mech-deflate/native-profile/compact-size/fixtures/metadata.json'
 cmd=[str(root/'reference-worker'),str(metadata),str(case),'0','0']
 with (link/'empty.stdout').open('w') as out,(link/'empty.stderr').open('w') as err:r=subprocess.run(cmd,cwd=repo,env=env,input=b'NN',stdout=out,stderr=err)
 save(link/'empty.json',{'command':cmd,'exit_code':r.returncode});assert r.returncode==0
 record.update(state='complete',exit_code=0,executable=pin(root/'reference-worker'),static_input_count=len(static))
except BaseException as error:record.update(state='failed',exit_code=1,error=repr(error));traceback.print_exc()
record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save(root/'adapter-job.json',record);print(json.dumps(record),flush=True);raise SystemExit(record['exit_code'])
