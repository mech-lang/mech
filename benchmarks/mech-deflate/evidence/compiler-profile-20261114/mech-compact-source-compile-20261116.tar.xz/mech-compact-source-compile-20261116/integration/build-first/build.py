from pathlib import Path
import json,subprocess,time,os,hashlib,datetime,traceback
root=Path('/private/tmp/mech-compact-integration-20261116')
cwd=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech')
command=['cargo','+nightly-2026-03-03','build','--locked','--offline','--profile','compiler','-j4','--manifest-path','benchmarks/mech-deflate/native-profile/Cargo.toml','--bin','emit_compact_size','--bin','compile_profile','--message-format=json']
env=dict(os.environ,CARGO_TARGET_DIR='/private/tmp/mech-level12-compile-target',CARGO_INCREMENTAL='0',CARGO_ENCODED_RUSTFLAGS='-D\x1fwarnings')
env.pop('RUSTFLAGS',None)
record={'state':'running','pid':os.getpid(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'compiler_build_excluded_from_program_timing':True,'rustflags':['-D','warnings'],'profile':'compiler: opt3, ThinLTO, CGU1','target_dir':env['CARGO_TARGET_DIR']}
(root/'build-job.json').write_text(json.dumps(record,indent=2)+'\n')
start=time.perf_counter()
try:
 with (root/'build.jsonl').open('w') as out,(root/'build.stderr').open('w') as err:
  result=subprocess.run(command,cwd=cwd,env=env,stdout=out,stderr=err)
 record.update(state='complete' if result.returncode==0 else 'failed',exit_code=result.returncode,seconds=time.perf_counter()-start)
 if result.returncode==0:
  import shutil
  for line in (root/'build.jsonl').read_text().splitlines():
   row=json.loads(line)
   if row.get('reason')=='compiler-artifact' and row.get('executable') and row['target']['name'] in ['compile_profile','emit_compact_size']:
    name=row['target']['name'];shutil.copy2(row['executable'],root/name)
    record.setdefault('binaries',{})[name]={'bytes':(root/name).stat().st_size,'sha256':hashlib.sha256((root/name).read_bytes()).hexdigest()}
except BaseException as error:
 record.update(state='failed',error=repr(error),exit_code=1);traceback.print_exc()
record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(root/'build-job.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
raise SystemExit(record['exit_code'])
