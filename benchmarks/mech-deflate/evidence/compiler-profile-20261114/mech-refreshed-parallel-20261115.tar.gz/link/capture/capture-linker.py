#!/usr/bin/env python3
from pathlib import Path
import sys,subprocess,json,hashlib,shutil,time
root=Path('/private/tmp/mech-pr973-refresh-20261115/link/capture');args=sys.argv[1:];pinned=[];relink=[];skip=False
for at,arg in enumerate(args):
    if arg=='-o':relink.append(arg);skip=True;continue
    if skip:relink.append(arg);skip=False;continue
    p=Path(arg)
    if p.is_file() and p.suffix in ['.o','.a','.rlib']:
        digest=hashlib.sha256(p.read_bytes()).hexdigest();info=dict(source=arg,bytes=p.stat().st_size,sha256=digest)
        if p.suffix=='.o' and p.name!='program.o':
            dest=root/(str(at)+'-'+p.name);shutil.copy2(p,dest);info['retained_path']=str(dest);relink.append(str(dest))
        else:info['retained_path']=arg;relink.append(arg)
        pinned.append(info)
    else:relink.append(arg)
record=dict(command=['/usr/bin/cc',*args],relink_command=['/usr/bin/cc',*relink],inputs=pinned)
(root/'link-command.json').write_text(json.dumps(record,indent=2)+'\n');start=time.perf_counter();result=subprocess.run(record['command']);record.update(exit_code=result.returncode,link_seconds=time.perf_counter()-start);(root/'link-command.json').write_text(json.dumps(record,indent=2)+'\n');raise SystemExit(result.returncode)
