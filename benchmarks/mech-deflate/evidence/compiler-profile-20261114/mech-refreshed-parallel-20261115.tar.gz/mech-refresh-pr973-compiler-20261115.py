from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time

repo=Path.cwd();root=Path('/private/tmp/mech-pr973-refresh-20261115');assert not root.exists();root.mkdir()
assert subprocess.check_output(['git','status','--porcelain'],text=True)==''
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert subprocess.run(['git','merge-base','--is-ancestor','9e34dc07e0',revision]).returncode==0
pin=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
paths=['.cargo/config.toml','Cargo.toml','Cargo.lock','benchmarks/mech-deflate/native-profile/Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.lock','benchmarks/mech-deflate/native-profile/compile_profile.rs','benchmarks/mech-deflate/native-profile/profile_compile.py','hosts/gpu/src/native_artifact/compact_runtime/mod.rs','hosts/gpu/src/native_artifact/compact_runtime/zero_pages.rs','hosts/gpu/tests/fixtures/native/deflate-compress-controller.mec','hosts/gpu/tests/fixtures/native/deflate_assembly.rs']
records=[]
for name in paths:
    data=subprocess.check_output(['git','show',revision+':'+name]);assert data==(repo/name).read_bytes()
    dest=root/'source-config'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);records.append(dict(path=name,**pin(dest)))
shutil.copy2('/private/tmp/mech-parallel-phases-20261114/runtime-flags.json',root/'runtime-flags.json')
flags=json.loads((root/'runtime-flags.json').read_text());assert len(flags)==61
state=dict(source_commit=revision,new_pr_source_commit=subprocess.check_output(['git','rev-parse','9e34dc07e0'],text=True).strip(),source_pins=records,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Refresh standard compiler and current Deflate program/runtime after PR973 advanced. No source optimization is applied. Previous scoped-map candidate is preserved separately and must be rebuilt/requalified against this baseline. Screens exclude primary timing; new native adapter/executable pins are still required.')
(root/'source-state.json').write_text(json.dumps(state,indent=2)+'\n')
(root/'rustc-version.txt').write_text(subprocess.check_output(['rustc','+nightly-2026-03-03','-Vv'],text=True))
env=dict(os.environ,CARGO_TARGET_DIR='/private/tmp/mech-level12-compile-target',CARGO_INCREMENTAL='0')
assert not env.get('RUSTFLAGS') and not env.get('CARGO_ENCODED_RUSTFLAGS')
for stage in ['check','build']:
    assert subprocess.check_output(['git','status','--porcelain'],text=True)==''
    command=['cargo','+nightly-2026-03-03',stage,'--locked','--offline','--profile','compiler','-j4','--manifest-path','benchmarks/mech-deflate/native-profile/Cargo.toml','--bin','compile_profile','--message-format=json']
    started=time.monotonic()
    with (root/('control-'+stage+'.jsonl')).open('w') as stdout,(root/('control-'+stage+'.stderr')).open('w') as stderr:completed=subprocess.run(command,cwd=repo,env=env,stdout=stdout,stderr=stderr)
    row=dict(command=command,source_commit=revision,exit_code=completed.returncode,seconds=time.monotonic()-started,CARGO_TARGET_DIR=env['CARGO_TARGET_DIR'],CARGO_INCREMENTAL='0')
    if completed.returncode==0 and stage=='build':
        rows=[json.loads(x) for x in (root/'control-build.jsonl').read_text().splitlines()]
        binaries=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='compile_profile' and r.get('executable')];assert len(binaries)==1
        shutil.copy2(binaries[0],root/'control');row.update(binary=str(root/'control'),**pin(root/'control'))
    (root/('control-'+stage+'.json')).write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True);assert completed.returncode==0
assert subprocess.check_output(['git','status','--porcelain'],text=True)==''
runtime={k:v for k,v in os.environ.items() if not k.startswith('MECH_')};runtime.update(flags);runtime['MECH_COMPACT_COMPILE_THREADS']='2'
out=root/'control-screen';out.mkdir();command=[str(root/'control'),'benchmark',str(out),'compact']
(out/'command.json').write_text(json.dumps(dict(command=command,flags=dict(flags,MECH_COMPACT_COMPILE_THREADS='2'),binary=pin(root/'control'),scope='Initial fresh updated-PR source/bytecode/Object/metadata pins; not a primary timing.'),indent=2)+'\n')
started=time.monotonic()
with (out/'stdout.jsonl').open('w') as stdout,(out/'stderr.log').open('w') as stderr:completed=subprocess.run(command,cwd=repo,env=runtime,stdout=stdout,stderr=stderr)
row=dict(exit_code=completed.returncode,process_seconds=time.monotonic()-started);(out/'process.json').write_text(json.dumps(row,indent=2)+'\n');assert completed.returncode==0
reference=root/'reference';reference.mkdir()
for name in ['source.mec','program.mecb','program.o','metadata.json']:shutil.copy2(out/name,reference/name)
pins={name:pin(reference/name) for name in ['source.mec','program.mecb','program.o','metadata.json']};(root/'reference-pins.json').write_text(json.dumps(pins,indent=2,sort_keys=True)+'\n');state.update(reference_pins=pins,control_screen_complete=True)
(root/'source-state.json').write_text(json.dumps(state,indent=2)+'\n');print('UPDATED_REFERENCE',json.dumps(pins),flush=True)
