Updated PR973 parallel requalification, frozen934bde961d after9e34 source/runtime changes.
One standard compiler binary, same61programflags, scheduling0versus2. Eight
serial ABBA/BAAB complete source-to-executable observations, all four artifacts
and full native executable exact. Fresh updated-runtime adapter and every link
input are pinned; first-use adapter build is separate from primary timings.
The mean is0.16%slower with two workers and blocks are mixed. No useful updated
workload parallel gain is established; default remains serial. Earlier smaller
workload1.57%result stays separate. Every raw observation, source/runtime/worker
snapshot, command/log, output/executable and native input remains. All seven
worker source files are unchanged since1090. Compiler binaries/rlibs/toolchain
are excluded and pinned. The hardware receipt is reused from the same host's
preceding current-source experiment. No new runtime campaign or scalar
retirement is claimed. Pure replay checks saved data without rerunning builds
or timings. Complete compilation below ten seconds remains open.
