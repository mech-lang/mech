from pathlib import Path
import datetime,hashlib,json,os,shutil,statistics,subprocess,time

root=Path('/private/tmp/mech-pr973-refresh-20261115');out=root/'parallel';assert not out.exists();out.mkdir()
link=root/'link';capture=json.loads((link/'capture/link-command.json').read_text());native=json.loads((link/'baseline-pins.json').read_text());reference=json.loads((root/'reference-pins.json').read_text())
flags=json.loads((root/'runtime-flags.json').read_text());assert len(flags)==61
pin=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
binary=pin(root/'control');assert binary=={k:json.loads((root/'control-build.json').read_text())[k] for k in ['bytes','sha256']}
for item in capture['inputs']:assert pin(Path(item['source']))=={k:item[k] for k in ['bytes','sha256']}
assert pin(link/'worker-baseline')==native['executable']
subjects={'serial':0,'parallel':2};order=[('serial',1),('parallel',1),('parallel',2),('serial',2),('parallel',3),('serial',3),('serial',4),('parallel',4)]
config=dict(source_commit=json.loads((root/'source-state.json').read_text())['source_commit'],compiler=binary,program_flags=flags,subjects=subjects,order=order,reference=reference,native=native,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Eight serial ABBA/BAAB complete fresh source-to-executable compiles on updated PR973. One standard compiler binary; only scheduling0/2 differs. Fresh current runtime adapter is cached/pinned. No concurrent heavy build/test/sample/hash/archive work during primary runs. Post-run hashes are outside the recorded boundary. No source optimization applied.')
(out/'configuration.json').write_text(json.dumps(config,indent=2)+'\n');records=[]
for variant,number in order:
    name=variant+'-'+str(number);directory=out/name;directory.mkdir()
    env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')};env.update(flags);env['MECH_COMPACT_COMPILE_THREADS']=str(subjects[variant]);env['ZERO_AR_DATE']='1'
    compile_command=[str(root/'control'),'benchmark',str(directory),'compact'];link_command=capture['command']
    (directory/'command.json').write_text(json.dumps(dict(compile=compile_command,link=link_command,flags=dict(flags,MECH_COMPACT_COMPILE_THREADS=str(subjects[variant])),ZERO_AR_DATE='1',compiler=binary),indent=2)+'\n')
    with (directory/'compiler.stdout.jsonl').open('w') as stdout,(directory/'compiler.stderr.log').open('w') as stderr:
        started=time.monotonic();completed=subprocess.run(compile_command,env=env,stdout=stdout,stderr=stderr);compiler_completed=time.monotonic()
    assert completed.returncode==0
    shutil.copy2(directory/'program.o',link/'program.o')
    with (directory/'link.stdout.log').open('w') as stdout,(directory/'link.stderr.log').open('w') as stderr:
        link_started=time.monotonic();completed=subprocess.run(link_command,env=env,stdout=stdout,stderr=stderr);finished=time.monotonic()
    assert completed.returncode==0
    checks={n:dict(**pin(directory/n),matches_frozen_reference=(directory/n).read_bytes()==(root/'reference'/n).read_bytes()) for n in reference}
    row=dict(name=name,variant=variant,workers=subjects[variant],compiler_exit_code=0,link_exit_code=0,source_to_executable_seconds=finished-started,source_to_object_process_seconds=compiler_completed-started,object_handoff_seconds=link_started-compiler_completed,native_link_seconds=finished-link_started,files=checks,executable=pin(link/'worker'),matches_complete_baseline_executable=(link/'worker').read_bytes()==(link/'worker-baseline').read_bytes(),primary_cohort=True,cached_adapter_objects=True)
    shutil.copy2(link/'worker',directory/'worker');(directory/'result.json').write_text(json.dumps(row,indent=2)+'\n');records.append(row);(out/'cohort.json').write_text(json.dumps(records,indent=2)+'\n')
    assert all(r['matches_frozen_reference'] for r in checks.values()) and row['matches_complete_baseline_executable'] and row['executable']==native['executable']
    print(name,row['source_to_executable_seconds'],flush=True)
summary={}
for key in ['source_to_executable_seconds','source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']:
    values={v:[r[key] for r in records if r['variant']==v] for v in subjects};values['mean_reduction_fraction']=1-statistics.mean(values['parallel'])/statistics.mean(values['serial']);summary[key]=values
blocks=[]
for subset in [records[:4],records[4:]]:
    means={v:statistics.mean(r['source_to_executable_seconds'] for r in subset if r['variant']==v) for v in subjects};means['mean_reduction_fraction']=1-means['parallel']/means['serial'];blocks.append(means)
result=dict(numerical_summary=summary,balanced_blocks=blocks,configuration=config);(out/'numerical-summary.json').write_text(json.dumps(result,indent=2)+'\n');print('SUMMARY',json.dumps(result),flush=True)
