from pathlib import Path
import hashlib,json,os,shutil,subprocess,time

root=Path('/private/tmp/mech-pr973-refresh-20261115');link=root/'link';assert not link.exists();link.mkdir();capture=link/'capture';capture.mkdir()
old=Path('/private/tmp/mech-round2-baseline-20261114/link')
pin=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
reference=json.loads((root/'reference-pins.json').read_text());assert pin(root/'reference/program.o')==reference['program.o']
for name in ['worker.rs','pinned_allocator.rs','libmimalloc.a']:shutil.copy2(old/name,link/name)
shutil.copy2(root/'reference/program.o',link/'program.o')
script=(old/'capture/capture-linker.py').read_text().replace(str(old/'capture'),str(capture));(capture/'capture-linker.py').write_text(script);(capture/'capture-linker.py').chmod(0o755)
rows=[json.loads(x) for x in (root/'control-build.jsonl').read_text().splitlines()]
command=['rustc','+nightly-2026-03-03','--edition=2024','--crate-name','frozen_level12_worker','-C','opt-level=3','-C','lto=thin','-C','codegen-units=1','-D','warnings',str(link/'worker.rs'),'-o',str(link/'worker')]
dependencies=[];directories=set()
for name in ['mech_gpu','mech_engine','serde','serde_json','miniz_oxide']:
    files=[Path(p) for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']==name for p in r['filenames'] if p.endswith('.rlib')];assert len(files)==1,(name,files)
    p=files[0];dependencies.append(dict(name=name,path=str(p),**pin(p)));directories.add(p.parent);command+=['--extern',name+'='+str(p)]
for path in sorted(directories):command+=['-L','dependency='+str(path)]
command+=['-C','link-arg='+str(link/'libmimalloc.a'),'-C','link-arg='+str(link/'program.o'),'-C','linker='+str(capture/'capture-linker.py')]
env=dict(os.environ,ZERO_AR_DATE='1');(capture/'rustc-command.json').write_text(json.dumps(dict(command=command,environment={'ZERO_AR_DATE':'1'},dependencies=dependencies,source_commit=json.loads((root/'source-state.json').read_text())['source_commit'],adapter_sources={n:pin(link/n) for n in ['worker.rs','pinned_allocator.rs','libmimalloc.a']},scope='Fresh runtime/entry adapter for updated PR973. Uses current-control rlibs, including new runtime allocation policy. Build excluded from Mech program timings; all final link inputs are frozen below.'),indent=2)+'\n')
started=time.monotonic()
with (link/'build.stdout.log').open('w') as stdout,(link/'build.stderr.log').open('w') as stderr:completed=subprocess.run(command,env=env,stdout=stdout,stderr=stderr)
row=dict(exit_code=completed.returncode,seconds=time.monotonic()-started);(link/'build.json').write_text(json.dumps(row,indent=2)+'\n');assert completed.returncode==0
shutil.copy2(link/'worker',link/'worker-baseline');baseline=pin(link/'worker-baseline');record=json.loads((capture/'link-command.json').read_text());assert record['exit_code']==0
temporary=Path(os.environ.get('TMPDIR','/private/tmp')).resolve()
for item in record['inputs']:
    p=Path(item['source'])
    if not p.exists():
        assert p.resolve().is_relative_to(link.resolve()) or p.resolve().is_relative_to(temporary),(p,temporary)
        retained=Path(item['retained_path']);assert pin(retained)=={k:item[k] for k in ['bytes','sha256']};p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(retained,p)
    assert pin(p)=={k:item[k] for k in ['bytes','sha256']}
relinks=[]
for number in range(2):
    started=time.monotonic()
    with (capture/('relink-'+str(number)+'.stdout.log')).open('w') as stdout,(capture/('relink-'+str(number)+'.stderr.log')).open('w') as stderr:completed=subprocess.run(record['command'],env=env,stdout=stdout,stderr=stderr)
    row=dict(run=number,exit_code=completed.returncode,seconds=time.monotonic()-started,executable=pin(link/'worker'),matches_complete_baseline_executable=(link/'worker').read_bytes()==(link/'worker-baseline').read_bytes());relinks.append(row);(capture/'relinks.json').write_text(json.dumps(relinks,indent=2)+'\n');assert completed.returncode==0 and row['matches_complete_baseline_executable']
(link/'baseline-pins.json').write_text(json.dumps(dict(executable=baseline,program_object=reference['program.o'],runtime_source_commit=json.loads((root/'source-state.json').read_text())['source_commit'],measurement_boundary='Fresh adapter construction separate; later complete source-to-executable cohorts reuse these exact fixed inputs and native link command.'),indent=2)+'\n')
print('UPDATED_NATIVE_BASELINE',json.dumps(baseline),flush=True)
