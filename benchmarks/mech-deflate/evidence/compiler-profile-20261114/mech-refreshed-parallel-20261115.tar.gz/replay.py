from pathlib import Path
import hashlib,json,statistics

packet=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
pin=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
revision='934bde961d47555db3fa45bc5c28d36ad1c0930a'
state=read(packet/'source-state.json');assert state['source_commit']==revision and state['control_screen_complete']
for row in state['source_pins']:assert pin(packet/'source-config'/row['path'])=={k:row[k] for k in ['bytes','sha256']}
for row in read(packet/'worker-source-pins.json'):
    assert row['unchanged_since_worker_commit'] and pin(packet/'worker-source'/row['path'])=={k:row[k] for k in ['bytes','sha256']}
build=read(packet/'control-build.json');check=read(packet/'control-check.json');excluded=read(packet/'excluded-compiler-products.json')
assert build['source_commit']==check['source_commit']==revision and build['exit_code']==check['exit_code']==0
assert {k:build[k] for k in ['bytes','sha256']}==excluded['control']
artifacts=[json.loads(x) for x in (packet/'control-build.jsonl').read_text().splitlines()];assert artifacts[-1]==dict(reason='build-finished',success=True)
flags=read(packet/'runtime-flags.json');assert len(flags)==61 and flags['MECH_COMPACT_REUSE_OVERWRITTEN_RESULT']=='1'
reference=read(packet/'reference-pins.json');assert reference==state['reference_pins']
for directory in ['reference','control-screen']:
    for name,row in reference.items():assert pin(packet/directory/name)==row
assert read(packet/'control-screen/process.json')['exit_code']==0
native=read(packet/'link/baseline-pins.json');assert native['runtime_source_commit']==revision and native['program_object']==reference['program.o']
executable=native['executable'];assert pin(packet/'link/worker-baseline')==executable
assert read(packet/'link/build.json')['exit_code']==0
inputs=read(packet/'native-link-inputs.json');capture=read(packet/'link/capture/link-command.json');assert capture['exit_code']==0
assert [(r['source'],r['bytes'],r['sha256']) for r in inputs]==[(r['source'],r['bytes'],r['sha256']) for r in capture['inputs']]
for row in inputs:assert pin(packet/row['path'])=={k:row[k] for k in ['bytes','sha256']}
relinks=read(packet/'link/capture/relinks.json');assert len(relinks)==2 and all(r['exit_code']==0 and r['matches_complete_baseline_executable'] and r['executable']==executable for r in relinks)
configuration=read(packet/'parallel/configuration.json');assert configuration['source_commit']==revision and configuration['compiler']==excluded['control'] and configuration['program_flags']==flags
assert configuration['subjects']==dict(serial=0,parallel=2) and configuration['reference']==reference and configuration['native']==native
order=[('serial',1),('parallel',1),('parallel',2),('serial',2),('parallel',3),('serial',3),('serial',4),('parallel',4)]
assert configuration['order']==[list(x) for x in order]
records=read(packet/'parallel/cohort.json');assert [(r['variant'],int(r['name'].rsplit('-',1)[1])) for r in records]==order
internal=[]
for row in records:
    directory=packet/'parallel'/row['name'];assert read(directory/'result.json')==row
    assert row['workers']==configuration['subjects'][row['variant']] and row['compiler_exit_code']==row['link_exit_code']==0 and row['primary_cohort'] and row['cached_adapter_objects']
    command=read(directory/'command.json');assert command['compiler']==excluded['control'] and command['flags']==dict(flags,MECH_COMPACT_COMPILE_THREADS=str(row['workers'])) and command['ZERO_AR_DATE']=='1' and command['link']==capture['command']
    for name,item in reference.items():assert pin(directory/name)==item and row['files'][name]==dict(item,matches_frozen_reference=True)
    assert row['executable']==executable==pin(directory/'worker') and row['matches_complete_baseline_executable']
    assert abs(row['source_to_executable_seconds']-sum(row[k] for k in ['source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']))<1e-8
    receipt=read(directory/'compile.json');assert receipt['total_seconds']<row['source_to_object_process_seconds']
    internal.append(dict(name=row['name'],variant=row['variant'],compile=receipt))
summary={}
for key in ['source_to_executable_seconds','source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']:
    values={v:[r[key] for r in records if r['variant']==v] for v in ['serial','parallel']};values['mean_reduction_fraction']=1-statistics.mean(values['parallel'])/statistics.mean(values['serial']);summary[key]=values
blocks=[]
for rows in [records[:4],records[4:]]:
    means={v:statistics.mean(r['source_to_executable_seconds'] for r in rows if r['variant']==v) for v in ['serial','parallel']};means['mean_reduction_fraction']=1-means['parallel']/means['serial'];blocks.append(means)
saved=read(packet/'parallel/numerical-summary.json');assert saved==dict(numerical_summary=summary,balanced_blocks=blocks,configuration=configuration)
phases={}
for phase in ['total','parse','catalog','frontend','native','artifact','encode']:
    values={v:[r['compile']['total_seconds'] if phase=='total' else next(x['seconds'] for x in r['compile']['phases'] if x['phase']==phase) for r in internal if r['variant']==v] for v in ['serial','parallel']};values['mean_reduction_fraction']=1-statistics.mean(values['parallel'])/statistics.mean(values['serial']);phases[phase+'_seconds']=values
result=dict(source_commit=revision,remote_source_commit=state['new_pr_source_commit'],compiler=excluded['control'],program_flags_count=61,subjects=configuration['subjects'],output_hashes=reference,final_executable=executable,compiler_check=check,compiler_build=build,adapter_build=read(packet/'link/build.json'),cached_relinks=relinks,numerical_summary=summary,balanced_blocks=blocks,internal_phase_summary=phases,configuration=configuration,decision='No useful updated-workload parallel speedup established: complete build mean is0.16%slower with mixed blocks. Keep default serial; opt-in2workers remains output-correct. Earlier smaller-workload1.57%gain stays separate.',scope=['UpdatedPR934 includes9e34 Deflate and runtime allocation changes. Bytecode/Object/descriptor grow from the earlier workload; timings are not pooled with earlier source. All seven worker implementation files are unchanged since1090.','One standard compiler binary, same61programflags, only scheduling0/2 differs. Eight serial ABBA/BAAB complete fresh source-to-executable builds use freshly rebuilt/pinned current runtime/entry adapter objects. Adapter first-use construction is excluded and separately recorded. No concurrent heavy build/test/sample/hash/archive work during primary timing.','Every source/bytecode/Object/complete metadata and full executable byte matches in all8builds. No scalar retirement, new program runtime campaign, weakened proof check or grammar/language change is claimed. No new source-to-Object counter cohort or exclusive cleanup timing is claimed.','Both timing blocks and all adverse/phase observations remain. Raw commands/logs, source/runtime/worker snapshots, every output/executable, native inputs and pure replay are included. Compiler binary and rlibs/toolchain are excluded/hash-pinned. Pure replay checks saved data without rerunning compilation/timing. Complete compilation below ten seconds remains open.'])
encoded=json.dumps(result,indent=2,sort_keys=True)+'\n';saved=packet/'summary.json'
if saved.exists():assert saved.read_text()==encoded
else:saved.write_text(encoded)
print(encoded,end='')
