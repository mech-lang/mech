from pathlib import Path
import hashlib,json,shutil,subprocess

repo=Path.cwd();raw=Path('/private/tmp/mech-pr973-refresh-20261115');packet=Path('/private/tmp/mech-refreshed-parallel-packet-20261115');assert not packet.exists();packet.mkdir()
pin=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
excluded={}
for p in raw.rglob('*'):
    if not p.is_file():continue
    rel=p.relative_to(raw)
    if rel.as_posix()=='control':excluded['control']=pin(p);continue
    if rel.parts[0]=='link' and p.suffix in ['.o','.a','.bc','.rlib','.rmeta','.dylib']:continue
    dest=packet/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
capture=json.loads((raw/'link/capture/link-command.json').read_text());inputs=[]
for at,row in enumerate(capture['inputs']):
    p=Path(row['retained_path']);expected={k:row[k] for k in ['bytes','sha256']};assert pin(p)==expected
    rel=Path('native-link-inputs')/(str(at)+'-'+p.name);dest=packet/rel;dest.parent.mkdir(exist_ok=True);shutil.copy2(p,dest);inputs.append(dict(source=row['source'],path=rel.as_posix(),**expected))
(packet/'native-link-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n');(packet/'excluded-compiler-products.json').write_text(json.dumps(excluded,indent=2)+'\n')
revision=json.loads((raw/'source-state.json').read_text())['source_commit'];worker='1090de011646c92e30c2d4b648ed0792c50f300d'
paths=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',worker],text=True).splitlines();assert len(paths)==7
pins=[]
for name in paths:
    content=subprocess.check_output(['git','show',revision+':'+name]);assert content==subprocess.check_output(['git','show',worker+':'+name])
    dest=packet/'worker-source'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(content);pins.append(dict(path=name,unchanged_since_worker_commit=True,**pin(dest)))
(packet/'worker-source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
shutil.copytree('/private/tmp/mech-round2-planning-packet-20261114/licenses',packet/'licenses')
hardware=packet/'hardware';hardware.mkdir()
for name in ['cpu.txt','cpu-count.txt','memory.txt','os.txt']:
    shutil.copy2(Path('/private/tmp/mech-current-native-pgo-20261115')/name,hardware/name)
for name in ['mech-refresh-pr973-compiler-20261115.py','mech-refresh-pr973-adapter-20261115.py','mech-measure-refreshed-parallel-20261115.py','mech-curate-refreshed-parallel-20261115.py']:shutil.copy2(Path('/private/tmp')/name,packet/name)
shutil.copy2('/private/tmp/mech-replay-refreshed-parallel-20261115.py',packet/'replay.py')
(packet/'README.txt').write_text('''Updated PR973 parallel requalification, frozen934bde961d after9e34 source/runtime changes.
One standard compiler binary, same61programflags, scheduling0versus2. Eight
serial ABBA/BAAB complete source-to-executable observations, all four artifacts
and full native executable exact. Fresh updated-runtime adapter and every link
input are pinned; first-use adapter build is separate from primary timings.
The mean is0.16%slower with two workers and blocks are mixed. No useful updated
workload parallel gain is established; default remains serial. Earlier smaller
workload1.57%result stays separate. Every raw observation, source/runtime/worker
snapshot, command/log, output/executable and native input remains. All seven
worker source files are unchanged since1090. Compiler binaries/rlibs/toolchain
are excluded and pinned. The hardware receipt is reused from the same host's
preceding current-source experiment. No new runtime campaign or scalar
retirement is claimed. Pure replay checks saved data without rerunning builds
or timings. Complete compilation below ten seconds remains open.
''')
print(packet)
