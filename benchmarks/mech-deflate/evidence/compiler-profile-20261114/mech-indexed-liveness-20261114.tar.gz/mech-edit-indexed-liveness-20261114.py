from pathlib import Path
p=Path('hosts/gpu/src/native_artifact/program/prepare/numeric_liveness.rs');old=p.read_text();s=old
s=s.replace('fn from_values(values: &BTreeSet<u32>) -> Self {','fn from_values(values: impl IntoIterator<Item = u32>) -> Self {').replace('        for &value in values {','        for value in values {',1)
a=s.index('struct Liveness {');b=s.index('// Two flat word planes',a)
s=s[:a]+'''/// Nodes use query-local ordinals. No source-ID tree lookup or reindexing is
/// needed while building predecessors or solving the selected graph. Definition
/// lists are sorted/deduplicated by the caller's original ordered value loop.
pub(super) fn live_before_indexed(
    next: &[Vec<usize>],
    reads: &[BTreeSet<u32>],
    definitions: &[Vec<u32>],
    start: usize,
) -> BTreeSet<u32> {
    if let Some(live) = dense_live_before_indexed(next, reads, definitions, start, MAX_DENSE_CELLS) {
        return live;
    }
    let (live, _, _) = solve_indexed(next, reads, definitions);
    live[start].values()
}

'''+s[b:]
s=s.replace('fn dense_live_before(\n    next: &BTreeMap<usize, Vec<usize>>,\n    reads: &BTreeMap<usize, BTreeSet<u32>>,\n    definitions: &BTreeMap<usize, BTreeSet<u32>>,','fn dense_live_before_indexed(\n    next: &[Vec<usize>],\n    reads: &[BTreeSet<u32>],\n    definitions: &[Vec<u32>],',1)
s=s.replace('''    let sites = next.keys().copied().collect::<Vec<_>>();
    let mut values = sites
        .iter()
        .flat_map(|site| reads[site].iter().copied())''','''    let mut values = reads
        .iter()
        .flat_map(|values| values.iter().copied())''',1)
a=s.index('fn dense_live_before_indexed(');b=s.index('\nfn solve(',a);dense=s[a:b]
dense=dense.replace('sites.len()','next.len()').replace('next.values().enumerate()','next.iter().enumerate()').replace('parents[sites.binary_search(successor).unwrap()].push(index);','parents[*successor].push(index);').replace('for (index, site) in sites.iter().enumerate() {','for index in 0..next.len() {').replace('&reads[site]','&reads[index]').replace('if let Some(definitions) = definitions.get(site) {','{\n            let definitions = &definitions[index];').replace('let offset = sites.binary_search(&start).unwrap() * width;','let offset = start * width;')
s=s[:a]+dense+s[b:]
a=s.index('fn solve(');b=s.index('\n#[cfg(test)]\nfn solve_liveness',a)
solve=s[a:b];solve=solve.replace('fn solve(\n    next: &BTreeMap<usize, Vec<usize>>,\n    reads: &BTreeMap<usize, BTreeSet<u32>>,\n    definitions: &BTreeMap<usize, BTreeSet<u32>>,\n) -> (Liveness, usize, usize) {\n    let sites = next.keys().copied().collect::<Vec<_>>();','fn solve_indexed(\n    next: &[Vec<usize>],\n    reads: &[BTreeSet<u32>],\n    definitions: &[Vec<u32>],\n) -> (Vec<Words>, usize, usize) {')
solve=solve.replace('sites.len()','next.len()').replace('next.values().enumerate()','next.iter().enumerate()').replace('predecessors[sites.binary_search(successor).unwrap()].push(index);','predecessors[*successor].push(index);').replace('''    let mut live = sites
        .iter()
        .map(|site| Words::from_values(&reads[site]))''','''    let mut live = reads
        .iter()
        .map(|values| Words::from_values(values.iter().copied()))''')
x=solve.index('    let kills = sites');y=solve.index('    let mut queued',x);solve=solve[:x]+'''    let kills = definitions.iter().map(|values| Words::from_values(values.iter().copied())).collect::<Vec<_>>();
'''+solve[y:];solve=solve.replace('(Liveness { sites, live }, visits, propagated_facts)','(live, visits, propagated_facts)')
s=s[:a]+solve+s[b:]
a=s.index('#[cfg(test)]\nfn solve_liveness');s=s[:a]+'''// Preserve the source-ID adapters for the independent reference/property tests.
// Production constructs query-local ordinals directly in the original DFS order.
#[cfg(test)]
struct Liveness { sites: Vec<usize>, live: Vec<Words> }
#[cfg(test)]
impl Liveness {
    fn at(&self, site: usize) -> BTreeSet<u32> {
        self.live[self.sites.binary_search(&site).unwrap()].values()
    }
}
#[cfg(test)]
fn indexed_inputs(
    next: &BTreeMap<usize, Vec<usize>>,
    reads: &BTreeMap<usize, BTreeSet<u32>>,
    definitions: &BTreeMap<usize, BTreeSet<u32>>,
) -> (Vec<usize>, Vec<Vec<usize>>, Vec<BTreeSet<u32>>, Vec<Vec<u32>>) {
    let sites = next.keys().copied().collect::<Vec<_>>();
    let edges = next.values().map(|edges| edges.iter().map(|site| sites.binary_search(site).unwrap()).collect()).collect();
    let reads = sites.iter().map(|site| reads[site].clone()).collect();
    let definitions = sites.iter().map(|site| definitions.get(site).map(|v| v.iter().copied().collect()).unwrap_or_default()).collect();
    (sites, edges, reads, definitions)
}
#[cfg(test)]
fn live_before(next: &BTreeMap<usize, Vec<usize>>, reads: &BTreeMap<usize, BTreeSet<u32>>, definitions: &BTreeMap<usize, BTreeSet<u32>>, start: usize) -> BTreeSet<u32> {
    let (sites, next, reads, definitions) = indexed_inputs(next, reads, definitions);
    live_before_indexed(&next, &reads, &definitions, sites.binary_search(&start).unwrap())
}
#[cfg(test)]
fn dense_live_before(next: &BTreeMap<usize, Vec<usize>>, reads: &BTreeMap<usize, BTreeSet<u32>>, definitions: &BTreeMap<usize, BTreeSet<u32>>, start: usize, max_cells: usize) -> Option<BTreeSet<u32>> {
    let (sites, next, reads, definitions) = indexed_inputs(next, reads, definitions);
    dense_live_before_indexed(&next, &reads, &definitions, sites.binary_search(&start).unwrap(), max_cells)
}
#[cfg(test)]
fn solve(next: &BTreeMap<usize, Vec<usize>>, reads: &BTreeMap<usize, BTreeSet<u32>>, definitions: &BTreeMap<usize, BTreeSet<u32>>) -> (Liveness, usize, usize) {
    let (sites, next, reads, definitions) = indexed_inputs(next, reads, definitions);
    let (live, visits, facts) = solve_indexed(&next, &reads, &definitions);
    (Liveness { sites, live }, visits, facts)
}

'''+s[a:];assert 'sites' not in s[s.index('fn dense_live_before_indexed'):s.index('// Preserve the source-ID')];p.write_text(s)
p=Path('hosts/gpu/src/native_artifact/program/prepare/numeric_exits.rs');s=p.read_text();a=s.index('fn live_query(');b=s.index('\n#[path = "numeric_liveness.rs"]',a);part=s[a:b]
part=part.replace('''    let mut next = BTreeMap::new();
    let mut reads = BTreeMap::<usize, BTreeSet<u32>>::new();''','''    // Query-local ordinals replace per-node source-ID tree allocations. Each
    // query still visits and validates its exact graph in the original order.
    let mut ordinals = vec![usize::MAX; plan.blocks().len()];
    let mut next = Vec::new();
    let mut reads = Vec::<BTreeSet<u32>>::new();''').replace('if next.contains_key(&site) {','if ordinals[site] != usize::MAX {').replace('''        next.insert(site, successors);''','''        ordinals[site] = next.len();
        next.push(successors);''').replace('        reads.insert(site, used);','        reads.push(used);').replace('reads.values().flatten()','reads.iter().flatten()').replace('    let mut definitions = BTreeMap::<usize, BTreeSet<u32>>::new();','    let mut definitions = vec![Vec::<u32>::new(); next.len()];')
x=part.index('''            if let Some(site) = definition.site()''');y=part.index('\n        }\n    }\n    Ok(liveness::live_before',x)
part=part[:x]+'''            if let Some(site) = definition.site()
                && let Some(&index) = ordinals.get(site as usize)
                && index != usize::MAX
            {
                let killed = &mut definitions[index];
                // The outer value loop is ordered. Repeated definition records
                // keep the original set semantics without allocating a tree.
                if killed.last() != Some(&(value as u32)) {
                    killed.push(value as u32);
                }
            }'''+part[y:]
part=part.replace('    Ok(liveness::live_before(&next, &reads, &definitions, start))','''    for successors in &mut next {
        for successor in successors {
            *successor = ordinals[*successor];
        }
    }
    Ok(liveness::live_before_indexed(&next, &reads, &definitions, ordinals[start]))''');assert 'next.contains' not in part and 'reads.insert' not in part;s=s[:a]+part+s[b:];p.write_text(s)
print('Converted selected graph construction and both solvers to query-local ordinals.')
