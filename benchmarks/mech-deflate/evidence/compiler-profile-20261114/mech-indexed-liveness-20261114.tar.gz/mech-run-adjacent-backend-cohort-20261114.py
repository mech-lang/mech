from pathlib import Path
import subprocess,json,re,sys
root=Path('/private/tmp/mech-adjacent-backend-20261114');repo=Path.cwd()
for variant,name in [('control','control-1'),('candidate','candidate-1'),('candidate','candidate-2'),('control','control-2')]:
 print('START',name,flush=True);subprocess.run([sys.executable,'/private/tmp/mech-run-adjacent-backend-20261114.py',variant,name],cwd=repo,check=True)
rows=[]
for variant,name in [('control','control-1'),('candidate','candidate-1'),('candidate','candidate-2'),('control','control-2')]:
 d=root/name;row={'name':name,'variant':variant,'compile':json.loads((d/'compile.json').read_text()),'process':json.loads((d/'process.json').read_text()),'files':json.loads((d/'output-check.json').read_text())}
 stamps=[json.loads(line) for line in (d/'stages.jsonl').read_text().splitlines()]
 for key,begin,end in [('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]:row[key]=next(s['elapsed'] for s in stamps if s['line'].startswith(end))-next(s['elapsed'] for s in stamps if s['line'].startswith(begin))
 log=(d/'stderr.log').read_text()
 for key,pattern in [('max_rss_bytes',r'(\d+)  maximum resident set size'),('instructions',r'(\d+)  instructions retired'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]:row[key]=int(re.search(pattern,log).group(1))
 rows.append(row)
(root/'cohort.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2),flush=True)
