from pathlib import Path
import json,hashlib,re,statistics,math
root=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
state=read(root/'source-state.json');old=read(root/'validation/qualified-54-flags.json');oldreceipt=read(root/'validation/qualified-54-flags.archive.json')
assert pin(root/'validation/qualified-54-flags.json')['sha256']==oldreceipt['replay_sha256']
labels=['backend-hash','backend-adjacent','indexed-initial','indexed-current'];roots={name:root/'experiments'/name for name in labels}
flags=read(roots['backend-hash']/'runtime-flags.json');assert len(flags)==54
for name in ['backend-adjacent','indexed-initial']:assert read(roots[name]/'runtime-flags.json')==flags
currentflags=dict(flags,MECH_TERMINAL_BYTE_APPENDS='1');assert read(roots['indexed-current']/'runtime-flags.json')==currentflags
builds={name:read(p/'candidate-build.json') for name,p in roots.items()};controls={name:read(p/'control-origin.json')['sha256'] for name,p in roots.items()}
for name,p in roots.items():
 b=builds[name];assert b['exit_code']==0 and pin(p/'candidate.patch')['sha256']==b['patch_sha256']
 assert b['head']==state['base_commit' if name=='indexed-current' else 'old_base_commit']
 if name!='indexed-current':assert controls[name]==old['compiler_binary_sha256']['candidate']=='77fc1fa9d8b2c07204ab09f76b0980a0d1925d5f6c5387d0a236e1f5cc93dd33'
assert pin(root/'source-change.patch')['sha256']==state['patch_sha256']==builds['indexed-current']['patch_sha256']==builds['indexed-initial']['patch_sha256']
assert (roots['indexed-current']/'candidate.patch').read_bytes()==(root/'source-change.patch').read_bytes()
controlbuild=read(roots['indexed-current']/'control-build.json');assert controlbuild['exit_code']==0 and controlbuild['head']==state['base_commit'] and (roots['indexed-current']/'control.patch').read_bytes()==b''
assert controlbuild['binary_sha256']==controls['indexed-current']=='89a1d14c7da02e2516cd628cce1185a183cb6fb870236d4b9b64f689677492e3'
assert builds['indexed-current']['binary_sha256']=='d9b59276ca61471edaf63dea6b2ac4dc96f35bb4562a733dd27288f18c6162d9'
excluded=read(root/'excluded-executables.json');assert len(excluded)==8
for item in excluded:
 _,label,variant=item['path'].split('/');assert item['sha256']==(controls[label] if variant=='control' else builds[label]['binary_sha256'])
current=roots['indexed-current'];pins=read(current/'qualified-output-pins.json');qualification=read(current/'baseline-qualification.json');assert qualification['output_hashes']==pins and qualification['base_commit']==state['base_commit']
assert pins['program.o']['sha256']==qualification['expected_native_object']=='38b194ec2c931fbd5d584ace06bdaba1efb59381e64eef1d662a5f2f12bd96b4'
assert pins['program.o']['sha256'] in (root/'sources/indexed-current/docs/design/native-terminal-byte-appends.md').read_text()
for name in ['source.mec','program.mecb']:assert pins[name]==old['output_hashes'][name]

def observation(label,name,variant,expected,expectedflags,check=True):
 p=roots[label];d=p/name;c=read(d/'compile.json');process=read(d/'process.json');assert process['exit_code']==0 and process['samples']==0
 command=read(p/(name+'-command.json'));assert command['flags']==expectedflags
 assert command['binary_sha256']==(controls[label] if variant=='control' else builds[label]['binary_sha256'])
 for filename,pinned in expected.items():
  assert pin(d/filename)==pinned
  if check:assert read(d/'output-check.json')[filename]==dict(pinned,matches_previous_qualified_output=True)
 return {'compile':c,'process':process}

diagnosticflags=dict(flags,MECH_PROFILE_PHASE_BACKEND='1')
screens={}
for label in ['backend-hash','backend-adjacent']:
 screens[label]=observation(label,'candidate-screen','candidate',old['output_hashes'],diagnosticflags)
 match=re.search(r'phase-backend: hits=(\d+) misses=(\d+)',(roots[label]/'candidate-screen/stderr.log').read_text());assert match
 screens[label]['reuse']={'hits':int(match[1]),'misses':int(match[2])}
assert screens['backend-hash']['reuse']=={'hits':46,'misses':298} and screens['backend-adjacent']['reuse']=={'hits':123,'misses':221}
screens['indexed-initial']=observation('indexed-initial','candidate-screen','candidate',old['output_hashes'],flags)
screens['current-control']=observation('indexed-current','control-screen','control',pins,currentflags,False)
screens['current-candidate']=observation('indexed-current','candidate-screen','candidate',pins,currentflags)

def cohort(label,expected,expectedflags):
 p=roots[label];rows=read(p/'cohort.json');assert [r['variant'] for r in rows]==['control','candidate','candidate','control']
 for r in rows:
  d=p/r['name'];o=observation(label,r['name'],r['variant'],expected,expectedflags);assert r['compile']==o['compile'] and r['process']==o['process'] and r['files']==read(d/'output-check.json')
  stamps=[json.loads(line) for line in (d/'stages.jsonl').read_text().splitlines()]
  for key,begin,end in [('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]:assert r[key]==next(s['elapsed'] for s in stamps if s['line'].startswith(end))-next(s['elapsed'] for s in stamps if s['line'].startswith(begin))
  for key,pattern in [('max_rss_bytes',r'(\d+)  maximum resident set size'),('instructions',r'(\d+)  instructions retired'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]:assert r[key]==int(re.search(pattern,(d/'stderr.log').read_text()).group(1))
 fields={'compiler_seconds':lambda r:r['compile']['total_seconds'],'whole_process_seconds':lambda r:r['process']['elapsed_seconds']}
 for phase in ['parse','frontend','native']:fields[phase+'_seconds']=lambda r,phase=phase:next(p['seconds'] for p in r['compile']['phases'] if p['phase']==phase)
 for key in ['canonical_lowering_seconds','preparation_seconds','numeric_generation_seconds','source_cfg_seconds','cleanup_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:fields[key]=lambda r,key=key:r[key]
 qualified={key:{v:[f(r) for r in rows if r['variant']==v] for v in ['control','candidate']} for key,f in fields.items()}
 for record in qualified.values():
  assert all(math.isfinite(v) and v>0 for group in ['control','candidate'] for v in record[group]);record['mean_reduction_fraction']=1-statistics.mean(record['candidate'])/statistics.mean(record['control'])
 return qualified
rejected=cohort('backend-adjacent',old['output_hashes'],flags);qualified=cohort('indexed-current',pins,currentflags)
decision=read(roots['backend-adjacent']/'decision.json');assert decision['source_restore_base']==state['old_base_commit'] and decision['source_restore_patch_sha256']==builds['backend-adjacent']['patch_sha256']
for key,record in decision['qualified'].items():assert record['control']==rejected[key]['control'] and record['candidate']==rejected[key]['candidate'] and record['candidate_mean_change_fraction']==-rejected[key]['mean_reduction_fraction']
assert 'AssertionError: existing observation control-1' in (roots['backend-adjacent']/'cohort-launch-attempt-1.log').read_text()

for label,stem,count in [('backend-hash','backend-tests',7),('backend-adjacent','backend-tests',7),('indexed-initial','liveness-tests',13),('indexed-current','liveness-tests',13)]:
 p=roots[label];assert read(p/(stem+'-command.json'))['exit_code']==0
 assert re.findall(r'test result: ok\. (\d+) passed',(p/(stem+'.log')).read_text())==[str(count)]
for attempt in range(1,5):assert read(roots['backend-hash']/f'backend-tests-attempt-{attempt}-command.json')['exit_code']!=0
assert '6 passed; 1 failed' in (roots['backend-hash']/'backend-tests-attempt-4.log').read_text()

def fixtures(label,expectedflags):
 p=roots[label];rows=read(p/'fixture-results.json');assert len(rows)==14
 for row in rows:
  assert row['all_outputs_match'] and row['variants']['control']==row['variants']['candidate'] and row['variants']['control']['exit_code']==0 and len(row['variants']['control']['files'])==4
  name=row['fixture'].rsplit(':',1)[-1] if ':' in row['fixture'] else Path(row['fixture']).stem
  for variant,record in row['variants'].items():
   d=p/'fixtures'/name/variant;command=read(d/'command.json');assert command['flags']==expectedflags and command['binary_sha256']==(controls[label] if variant=='control' else builds[label]['binary_sha256'])
   for filename,pinned in record['files'].items():assert pin(d/filename)==pinned
   assert record['files']['source.mec']['sha256']==row['source_sha256']
 return rows
initialfixtures=fixtures('indexed-initial',flags);currentfixtures=fixtures('indexed-current',currentflags)
source=root/'sources/indexed-current/hosts/gpu/tests/fixtures/native';base=(source/'numeric-nested-phase.mec').read_text();fragment=(source/'numeric-nested-phase-states.mec').read_text();assembled=base.replace('+> sequence\n','+> sequence\n'+fragment+'\n',1).replace('phase-candidates(values, 1u64, 0u64, permitted, divisor)','#PhaseCandidates(values, permitted, divisor, 1u64, 0u64)',1)
for label in ['indexed-initial','indexed-current']:assert assembled==(roots[label]/'fixture-inputs/numeric-nested-phase-states.mec').read_text()
assert read(roots['indexed-initial']/'pre-integration.json')['flags_count']==54
s=(root/'sources/indexed-current/hosts/gpu/src/native_artifact/program/prepare/numeric_liveness_tests.rs').read_text();assert 'for seed in 0..128usize' in s and 'for order in 0..4' in s and 'const N: usize = 17' in s
assert 'phase_backend' not in (root/'sources/indexed-current/benchmarks/mech-deflate/native-profile/Cargo.toml').read_text()
summary={'source_commit':state['source_commit'],'base_commit':state['base_commit'],'hardware':state['hardware'],'decision':'Retain query-local liveness graph indexing; reject both backend-reuse prototypes','flags_count':55,'qualified':qualified,'output_hashes':pins,'compiler_binary_sha256':{'control':controls['indexed-current'],'candidate':builds['indexed-current']['binary_sha256']},'candidate_patch_sha256':state['patch_sha256'],'compiler_builds':{'control':controlbuild,'candidate_build_check':builds['indexed-current'],'candidate_build_and_test':read(current/'liveness-tests-command.json')},'tests':{'liveness':13,'reference_graph_seeds':128,'node_orders_per_graph':4,'starts_per_graph':17,'complete_array_enum_fixtures':6,'scalar_fixtures':8},'fixture_output_comparisons':currentfixtures,'rejected_backend_trial':{'base_commit':state['old_base_commit'],'qualified':rejected,'screen_observations':{name:screens[name] for name in ['backend-hash','backend-adjacent']},'candidate_patch_sha256':{name:builds[name]['patch_sha256'] for name in ['backend-hash','backend-adjacent']},'tests_per_prototype':7,'transient_corrections_retained':{'failed_build_or_test_attempts':4,'launcher_stopped_before_compilation':1},'decision':decision['reason']},'preintegration':{'base_commit':state['old_base_commit'],'flags_count':54,'tests':13,'fixture_pairs':14,'candidate_screen':screens['indexed-initial'],'scope':'Separate diagnostics before updating PR 973; no primary cohort was launched on this base.'},'current_screens':{name:screens[name] for name in ['current-control','current-candidate']},'scope':[
 'Four serial ABBA fresh full source-to-Object observations on current PR 973 base ada4fa, identical 55 existing runtime flags and host statistics. Builds, tests, screens, fixtures, profiles and archive work do not overlap primary timing. No cached Object or cross-process compiled output is used.',
 'The current control reproduces the independently qualified terminal-append Object. Every source, MBC, Object and complete metadata byte matches between subjects in all current observations and 14 fixture pairs. No new runtime-latency campaign is claimed.',
 'Only graph representation changes: query-local indices preserve original DFS traversal, action/terminator reads, predicate facts, root stops and all original ordered definition lookups/validation, including unread values. Sorted duplicate definition records retain set semantics.',
 'Dense and sparse solvers keep the same read-before-definition transfer and fixed point, now using indexed edges and predecessor rows. Final escaping values remain sorted sets. No graph, predicate, semantic proof, ownership decision or liveness answer is cached.',
 'Thirteen solver tests pass on both bases. Added differential coverage compares dense and sparse results against the original reference on 128 graphs, four node orderings and 17 starts, including cycles, duplicate edges, definition duplicates, word boundaries and maximum u32 IDs.',
 'Compiler time, preparation time and retired instructions improve. Both current candidate compiler/process observations are below both controls. Peak RSS is essentially flat and ranges overlap; no memory saving is claimed. All adverse unchanged-stage and footprint observations remain without causal attribution. Four compiles are descriptive, not a population estimate.',
 'The rejected adjacent backend prototype reuses 123/344 exact stencils but saves only 1.80% of numeric generation; full compiler time is worse and instructions essentially flat. Its whole-process saving includes a much larger interval outside the compiler timer in its first control. The hash-indexed prototype is only a superseded diagnostic screen with 46/344 reuses.',
 'All prototype patches, reconstructed/source snapshots, output bytes, transient build/test corrections and failed-launch logs remain. The launcher failure stops on an existing-output assertion before starting a compiler; prior evidence is unchanged. No backend-reuse code is retained in production.',
 'The earlier 54-flag graph screen and fixture pairs are separate diagnostics, not pooled with the 55-flag qualification. Compiler build activity is separate; Cargo test builds the compiler too, and later cached build checks are not cold bootstrap measurements.',
 'Grammar, language, finite admission, current-visit ownership checks, direct scalar emission and backend optimization level are unchanged by this compiler optimization. The full fresh-compilation ten-second goal remains open.'
]}
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
