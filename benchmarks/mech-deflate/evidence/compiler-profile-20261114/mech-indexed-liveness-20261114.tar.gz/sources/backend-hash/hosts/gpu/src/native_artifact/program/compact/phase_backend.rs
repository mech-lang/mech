//! Reuse identical backend inputs only within one fresh phase-compilation batch.
//! All source admission, lowering and phase optimization still run for each body.
use cranelift_codegen::{
    CodegenResult, CompiledCode, Context,
    control::ControlPlane,
    ir::function::{FunctionParameters, FunctionStencil},
    isa::TargetIsa,
    settings,
};
use std::collections::HashMap;
use std::collections::hash_map::DefaultHasher;
use std::hash::{Hash, Hasher};

#[derive(PartialEq)]
struct Target {
    name: &'static str,
    triple: String,
    shared: settings::Flags,
    specific: Vec<String>,
}
impl Target {
    fn of(isa: &dyn TargetIsa) -> Self {
        Self {
            name: isa.name(),
            triple: isa.triple().to_string(),
            shared: isa.flags().clone(),
            specific: isa.isa_flags().iter().map(ToString::to_string).collect(),
        }
    }
}

struct Entry {
    input: FunctionStencil,
    // The public stencil compiler returns an unexported concrete type. Retain
    // its parameter application without adding serialization or a vendor API.
    finish: Box<dyn Fn(&FunctionParameters) -> CompiledCode>,
}

#[derive(Default)]
pub(super) struct PhaseBackend {
    target: Option<Target>,
    entries: HashMap<u64, Vec<Entry>>,
    retained_insts: usize,
    pub hits: usize,
    pub misses: usize,
}
impl PhaseBackend {
    pub fn compile(
        &mut self,
        isa: &dyn TargetIsa,
        context: &mut Context,
        disassemble: bool,
    ) -> CodegenResult<CompiledCode> {
        // A diagnostic requests its own context/disassembly. Do not substitute
        // another definition's text or context state, even for identical IR.
        if disassemble {
            return context
                .compile_stencil(isa, &mut ControlPlane::default())
                .map(|code| code.apply_params(&context.func.params));
        }
        let target = Target::of(isa);
        if self.target.as_ref() != Some(&target) {
            self.entries.clear();
            self.retained_insts = 0;
            self.target = Some(target);
        }
        let mut hash = DefaultHasher::new();
        context.func.stencil.hash(&mut hash);
        let key = hash.finish();
        if let Some(entry) = self.entries.get(&key).and_then(|bucket| {
            bucket
                .iter()
                .find(|entry| entry.input == context.func.stencil)
        }) {
            // Keep the backend's configured verifier on the current input.
            // Hashes select a bucket; full stencil equality establishes reuse.
            context.verify_if(isa)?;
            self.hits += 1;
            return Ok((entry.finish)(&context.func.params));
        }
        self.misses += 1;
        // Bound retained IR, and release the entire batch before the main entry.
        // Exceeding the budget only loses reuse; it never changes generated code.
        let insts = context.func.dfg.num_insts();
        let retain = insts <= 8192 && self.retained_insts + insts <= 131072;
        let input = retain.then(|| context.func.stencil.clone());
        let output = context.compile_stencil(isa, &mut ControlPlane::default())?;
        if let Some(input) = input {
            self.retained_insts += insts;
            let retained = output.clone();
            self.entries.entry(key).or_default().push(Entry {
                input,
                finish: Box::new(move |params| retained.clone().apply_params(params)),
            });
        }
        Ok(output.apply_params(&context.func.params))
    }
}

#[cfg(test)]
#[path = "phase_backend_tests.rs"]
mod tests;
