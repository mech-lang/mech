//! Compile the same checked numeric plan under an explicit entry contract.
use super::*;
use crate::native_artifact::{
    codegen::control::CfgCleanup,
    program::codegen::{numeric_compact, wide_equal},
};
use cfg_cleanup::composed_reads::{Admission, Capture, DenseTables, Literal, View};
use cranelift_codegen::{Context, ir::Signature, isa::TargetIsa};

pub(super) struct Composed {
    pub function: FuncId,
    pub admission: Admission,
    pub summary: serde_json::Value,
}

pub(super) struct Compiled {
    pub function: FuncId,
    pub entry_bounds: Vec<(usize, u64, bool)>,
    pub summary: serde_json::Value,
    pub code: Vec<u8>,
    pub composed: Option<Composed>,
}
pub(super) fn define<M: Module>(
    module: &mut M,
    phase_backend: &mut super::backend::PhaseBackend,
    prepared: &PreparedNativeProgram,
    id: usize,
    observe: bool,
    input_words: usize,
    output_words: usize,
    fixed_count: usize,
    vectors: Option<&VectorContract>,
    private: Option<&PrivatePhase>,
    no_growth: Option<&NoGrowth>,
    literal_views: &BTreeMap<usize, Literal>,
    dense_tables: &mut DenseTables,
    suffix: &str,
) -> Result<Compiled, NativeCompileError> {
    let code = CodePlan::Program(prepared);
    let closed = &prepared.metadata().closed_tails;
    let region = &closed.regions[id];
    let header = region.tail.header() as usize;
    let proof = region
        .numeric
        .as_ref()
        .ok_or_else(|| backend("phase lacks checked numeric proof"))?;
    let controls = CompilationControls::new(OptimizationOptions::default());
    let symbol = format!("mech_compact_numeric_{header}{suffix}");
    let mut signature = module.make_signature();
    signature.params = vec![AbiParam::new(types::I64); 3];
    signature.returns = vec![AbiParam::new(types::I64); 2];
    let (mut context, report) = phase_ir(
        module, code, region, &signature, &controls, observe, vectors, private, no_growth, false,
    )?;
    let function = module
        .declare_function(&symbol, Linkage::Local, &signature)
        .map_err(backend)?;
    eprintln!("compact-stage: numeric phase {symbol}");
    if let Err(error) = context.verify(module.isa()) {
        if let Some(path) = std::env::var_os("MECH_COMPACT_FAILURE_DIR") {
            let root = std::path::PathBuf::from(path);
            std::fs::create_dir_all(&root).map_err(backend)?;
            std::fs::write(
                root.join(format!("{symbol}.clif")),
                context.func.display().to_string(),
            )
            .map_err(backend)?;
            std::fs::write(root.join(format!("{symbol}.proof")), format!("{proof:#?}"))
                .map_err(backend)?;
        }
        return Err(backend(format!("{symbol}: {error:?}")));
    }
    let PhaseCleanup {
        bit_counts,
        cleanup,
        equality,
        threaded,
        vector_predicates,
        width_guards,
        window_bounds,
    } = optimize_phase(
        &mut context,
        &controls,
        module.isa(),
        &report,
        &symbol,
        input_words,
        output_words,
        vectors,
        private,
        no_growth,
        true,
    )?;
    let pack_halfwords = cfg!(target_arch = "aarch64")
        && module.isa().endianness() == cranelift_codegen::ir::Endianness::Little
        && std::env::var_os("MECH_PACK_PRIVATE_HALFWORD_READS").is_some();
    let reuse_lengths = std::env::var_os("MECH_REUSE_ADMITTED_VIEW_LENGTHS").is_some();
    if (pack_halfwords || reuse_lengths)
        && !observe
        && cleanup.enabled
        && let Some(vectors) = vectors
        && !vectors.admitted_lengths.is_empty()
        && private.is_some_and(|contract| contract.permits(proof))
        && let Some(loads) = phase_storage::input_word_loads(&context.func, input_words)
    {
        let packet = numeric_minimal::input_words(proof, region.tail.carrier().get())?;
        let input_word = |word| {
            let at = packet.binary_search(&word).ok()?;
            let mut values = loads.iter().filter(|(_, pair)| pair.1 == at);
            let (&value, _) = values.next()?;
            values.next().is_none().then_some(value)
        };
        if pack_halfwords {
            let mut floors = BTreeMap::new();
            for &(array, minimum) in &vectors.admitted_lengths {
                let view = &proof.arrays[array];
                if view.width != 2 || !view.writable {
                    continue;
                }
                if let (Some(pointer), Some(bytes)) =
                    (input_word(proof.view(array)), minimum.checked_mul(2))
                {
                    floors.insert(pointer, bytes);
                }
            }
            if !floors.is_empty() {
                context.flowgraph();
                let packed = cfg_cleanup::packed_halfword_reads::fold(
                    &mut context.func,
                    &context.cfg,
                    &context.domtree,
                    &floors,
                );
                if packed != 0 {
                    context.verify(module.isa()).map_err(backend)?;
                    if std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() {
                        eprintln!("{symbol} packed private halfword loads: {packed}");
                    }
                }
            }
        }
        if reuse_lengths {
            let floors: BTreeMap<_, _> = vectors
                .admitted_lengths
                .iter()
                .filter_map(|&(array, minimum)| {
                    input_word(proof.view(array) + 1).map(|length| (length, minimum))
                })
                .collect();
            if !floors.is_empty() {
                let folded = cfg_cleanup::admitted_lengths::fold(&mut context.func, &floors);
                if folded != 0 {
                    context.flowgraph();
                    context.verify(module.isa()).map_err(backend)?;
                    if std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() {
                        eprintln!("{symbol} reused admitted view lengths: {folded}");
                    }
                }
            }
        }
    }
    if !observe
        && cleanup.enabled
        && vectors.is_some()
        && std::env::var_os("MECH_SHARE_CLAMP_DECISIONS").is_some()
    {
        context.flowgraph();
        let reused =
            cfg_cleanup::shared_clamp::fold(&mut context.func, &context.cfg, &context.domtree);
        if reused != 0 {
            context.flowgraph();
            context.verify(module.isa()).map_err(backend)?;
            if std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() {
                eprintln!("{symbol} shared clamp decisions: {reused}");
            }
        }
    }
    if cfg!(target_arch = "aarch64")
        && !observe
        && cleanup.enabled
        && vectors.is_some()
        && std::env::var_os("MECH_SHORT_CIRCUIT_COMPARISON_BRANCHES").is_some()
    {
        context.flowgraph();
        let changed = cfg_cleanup::selected_continuations::comparison_chain::fold(
            &mut context.func,
            &context.cfg,
            &context.domtree,
        );
        if changed != 0 {
            context.flowgraph();
            context.verify(module.isa()).map_err(backend)?;
            if std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() {
                eprintln!("{symbol} short-circuited comparison branches: {changed}");
            }
        }
    }
    let mut future_write_hints = Vec::new();
    if !observe
        && cleanup.enabled
        && module.isa().name() == "aarch64"
        && !report.fixed_view_writes.is_empty()
        && let Some(vectors) = vectors
    {
        context.flowgraph();
        if std::env::var_os("MECH_PREFETCH_PRIVATE_WRITES").is_some() {
            future_write_hints = cfg_cleanup::future_store::insert(
                &mut context.func,
                &context.cfg,
                &context.domtree,
                &report.fixed_view_writes,
                &vectors.admitted_lengths,
                std::env::var_os("MECH_PREFETCH_SECOND_PRIVATE_WRITE").is_some(),
            );
        }
        if !future_write_hints.is_empty() {
            context.verify(module.isa()).map_err(backend)?;
        }
    }
    if !observe
        && cleanup.enabled
        && pack_halfwords
        && std::env::var_os("MECH_SCHEDULE_INDEPENDENT_PRIVATE_READS").is_some()
        && let Some(vectors) = vectors
        && private.is_some_and(|contract| contract.permits(proof))
        && let Some(loads) = phase_storage::input_word_loads(&context.func, input_words)
    {
        let packet = numeric_minimal::input_words(proof, region.tail.carrier().get())?;
        let mut views = Vec::new();
        let mut bases = BTreeMap::new();
        for (array, definition) in proof.arrays.iter().enumerate() {
            if !definition.writable || definition.appends {
                continue;
            }
            let Some(at) = packet.binary_search(&proof.view(array)).ok() else {
                continue;
            };
            let mut matches = loads.iter().filter(|(_, pair)| pair.1 == at);
            let Some((&base, _)) = matches.next() else {
                continue;
            };
            if matches.next().is_some() {
                continue;
            }
            let width = definition.width;
            let minimum_bytes = vectors
                .admitted_lengths
                .iter()
                .find_map(|&(at, length)| {
                    (at == array)
                        .then(|| length.checked_mul(u64::from(width)))
                        .flatten()
                })
                .unwrap_or(0);
            bases.insert(array, base);
            views.push(cfg_cleanup::independent_private_read::View {
                base,
                element_bytes: width,
                minimum_bytes,
            });
        }
        let writes = report
            .fixed_view_writes
            .iter()
            .filter_map(|write| bases.get(&write.array).map(|&base| (write.store, base)))
            .collect();
        context.flowgraph();
        if cfg_cleanup::independent_private_read::schedule(
            &mut context.func,
            &context.cfg,
            &context.domtree,
            &views,
            &writes,
        ) {
            context.verify(module.isa()).map_err(backend)?;
            if std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() {
                eprintln!("{symbol} scheduled independent private read");
            }
        }
    }
    let word_loops = &report;
    let pack_sites = word_loops.read_pack_sites.clone();
    let read_guards = word_loops.proven_scalar_read_guards.clone();
    let write_guards = word_loops.proven_scalar_write_guards.clone();
    let reused_reads = word_loops.reused_scalar_reads.clone();
    let reused_operands = word_loops.reused_scalar_operands.clone();
    let mut histogram = None;
    if std::env::var_os("MECH_GROUP_PACKED_HISTOGRAM").is_some()
        && !observe
        && no_growth.is_none()
        && proof.phase.is_none()
        && proof.exits.is_empty()
        && proof.prepaid_sites.is_empty()
        && proof.arrays.iter().all(|array| !array.appends)
        && module.isa().endianness() == cranelift_codegen::ir::Endianness::Little
        && let Some(loads) = phase_storage::input_word_loads(&context.func, input_words)
    {
        let packet = numeric_minimal::input_words(proof, region.tail.carrier().get())?;
        let word_at = |word| packet.iter().position(|&at| at == word);
        let mut nodes = Vec::new();
        let mut bins = Vec::new();
        for (array, definition) in proof.arrays.iter().enumerate() {
            let destination = match (definition.width, definition.writable) {
                (8, false) => &mut nodes,
                (4, true) => &mut bins,
                _ => continue,
            };
            if let (Some(pointer_word), Some(length_word)) =
                (word_at(proof.view(array)), word_at(proof.view(array) + 1))
            {
                destination.push(View {
                    array,
                    pointer_word,
                    length_word,
                    width: definition.width,
                    literal: None,
                });
            }
        }
        if !nodes.is_empty() && !bins.is_empty() {
            let mut grouped = module.make_context();
            grouped.func = context.func.clone();
            if let Some(admission) = cfg_cleanup::grouped_histogram::optimize(
                &mut grouped,
                word_loops.machine_header,
                &loads,
                &nodes,
                &bins,
            ) {
                let name = format!("{symbol}_grouped");
                let grouped_id = module
                    .declare_function(&name, Linkage::Local, &signature)
                    .map_err(backend)?;
                grouped.verify(module.isa()).map_err(backend)?;
                let inspection = std::env::var_os("MECH_INSPECT_PHASE_CLIF")
                    .map(std::path::PathBuf::from)
                    .filter(|path| path.file_stem().is_some_and(|stem| stem == name.as_str()));
                if let Some(path) = &inspection {
                    std::fs::write(path, grouped.func.display().to_string()).map_err(backend)?;
                    grouped.set_disasm(true);
                }
                module
                    .define_function(grouped_id, &mut grouped)
                    .map_err(backend)?;
                let machine = grouped
                    .compiled_code()
                    .ok_or_else(|| backend("grouped phase lacks code"))?;
                if let Some(path) = inspection {
                    let vcode = machine
                        .vcode
                        .as_ref()
                        .ok_or_else(|| backend("grouped phase VCode was not emitted"))?;
                    std::fs::write(path.with_extension("vcode"), vcode).map_err(backend)?;
                }
                histogram = Some(serde_json::json!({
                    "symbol": name,
                    "admission": admission,
                    "code_bytes": machine.code_info().total_size,
                    "stack_bytes": compiled_stack_bytes(&machine.buffer)?,
                }));
                let fast = module.declare_func_in_func(grouped_id, &mut context.func);
                cfg_cleanup::grouped_histogram::guard_entry(&mut context, admission, fast);
                context.verify(module.isa()).map_err(backend)?;
            }
        }
    }
    let mut composed = None;
    if let Some(contract) = no_growth
        && !literal_views.is_empty()
    {
        let packet = numeric_minimal::input_words(proof, region.tail.carrier().get())?;
        let word_at = |word| packet.iter().position(|&at| at == word);
        let views = proof
            .arrays
            .iter()
            .enumerate()
            .filter_map(|(array, definition)| {
                if definition.writable || definition.appends {
                    return None;
                }
                let pointer_word = word_at(proof.view(array))?;
                let length_word = word_at(proof.view(array) + 1)?;
                Some(View {
                    array,
                    pointer_word,
                    length_word,
                    width: definition.width,
                    literal: literal_views.get(&array).cloned(),
                })
            })
            .collect::<Vec<_>>();
        if let Some(countdown_word) = word_at(contract.countdown)
            && let Some(loads) = phase_storage::input_word_loads(&context.func, input_words)
        {
            let mut candidate = module.make_context();
            candidate.func = context.func.clone();
            let capture = Capture {
                packet_loads: &loads,
                views: &views,
                header: word_loops.machine_header,
                countdown_word,
            };
            if let Some(admission) = cfg_cleanup::compose_readonly_lookups(
                &controls,
                &mut candidate,
                module,
                dense_tables,
                &capture,
            )? {
                let mut composed_header = capture.header;
                // Select the countdown only for this independently admitted
                // immutable lookup variant. Re-emit from the same numeric
                // proof and verify its own composition before substitution.
                if admission.immutable_code_bytes.is_some()
                    && !word_loops.reduction_completions.is_empty()
                    && std::env::var_os("MECH_REDUCTION_COUNTDOWN").is_some()
                {
                    let (mut fast, fast_report) = phase_ir(
                        module, code, region, &signature, &controls, observe, vectors, private,
                        no_growth, true,
                    )?;
                    optimize_phase(
                        &mut fast,
                        &controls,
                        module.isa(),
                        &fast_report,
                        &symbol,
                        input_words,
                        output_words,
                        vectors,
                        private,
                        no_growth,
                        false,
                    )?;
                    if let Some(loads) = phase_storage::input_word_loads(&fast.func, input_words) {
                        let fast_capture = Capture {
                            packet_loads: &loads,
                            header: fast_report.machine_header,
                            ..capture
                        };
                        if let Some(fast_admission) = cfg_cleanup::compose_readonly_lookups(
                            &controls,
                            &mut fast,
                            module,
                            dense_tables,
                            &fast_capture,
                        )? && fast_admission == admission
                        {
                            composed_header = fast_capture.header;
                            candidate = fast;
                        }
                    }
                }
                let name = format!("{symbol}_composed");
                if admission.immutable_code_bytes.is_some()
                    && std::env::var_os("MECH_FORWARD_ZERO_TRIP_REDUCTIONS").is_some()
                {
                    candidate.flowgraph();
                    if cfg_cleanup::identity_routes::zero_trip::fold(
                        &mut candidate.func,
                        &candidate.cfg,
                        &candidate.domtree,
                    ) {
                        candidate.flowgraph();
                        candidate.verify(module.isa()).map_err(backend)?;
                        if std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() {
                            eprintln!("{name} forwarded zero-trip reduction");
                        }
                    }
                }
                if admission.immutable_code_bytes.is_some()
                    && module.isa().name() == "aarch64"
                    && module.isa().endianness() == cranelift_codegen::ir::Endianness::Little
                    && std::env::var_os("MECH_NORMALIZE_DEFAULTED_READ_SETUP").is_some()
                    && proof.arrays[contract.array].width == 8
                    && let Some(output_base) = word_at(proof.view(contract.array))
                    && let Some(loads) =
                        phase_storage::input_word_loads(&candidate.func, input_words)
                {
                    candidate.flowgraph();
                    let capture = Capture {
                        packet_loads: &loads,
                        header: composed_header,
                        ..capture
                    };
                    let changes = cfg_cleanup::defaulted_read_setup::optimize(
                        &mut candidate.func,
                        &candidate.cfg,
                        &candidate.domtree,
                        &capture,
                        admission.cursor_word,
                        output_base,
                    );
                    candidate.flowgraph();
                    candidate.verify(module.isa()).map_err(backend)?;
                    if std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() {
                        eprintln!("{name} defaulted read setup: {changes:?}");
                    }
                }
                if admission.immutable_code_bytes.is_some()
                    && std::env::var_os("MECH_CARRY_REDUCTION_BOUND").is_some()
                {
                    candidate.flowgraph();
                    if cfg_cleanup::reduction_bound::carry(
                        &mut candidate.func,
                        &candidate.cfg,
                        &candidate.domtree,
                    ) {
                        candidate.verify(module.isa()).map_err(backend)?;
                        if std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() {
                            eprintln!("{name} carries an adjusted reduction bound");
                        }
                    }
                }
                if admission.immutable_code_bytes.is_some()
                    && std::env::var_os("MECH_CARRY_REDUCTION_BOUND").is_some()
                {
                    candidate.flowgraph();
                    if cfg_cleanup::reduction_rotation::rotate(
                        &mut candidate.func,
                        &candidate.cfg,
                        &candidate.domtree,
                    ) {
                        candidate.flowgraph();
                        candidate.verify(module.isa()).map_err(backend)?;
                        if std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() {
                            eprintln!("{name} rotated nested reduction");
                        }
                    }
                }
                let id = module
                    .declare_function(&name, Linkage::Local, &signature)
                    .map_err(backend)?;
                let inspect_path = std::env::var_os("MECH_INSPECT_PHASE_CLIF")
                    .map(std::path::PathBuf::from)
                    .filter(|path| path.file_stem().is_some_and(|stem| stem == name.as_str()));
                if let Some(path) = &inspect_path {
                    std::fs::write(path, candidate.func.display().to_string()).map_err(backend)?;
                    candidate.set_disasm(true);
                }
                module
                    .define_function(id, &mut candidate)
                    .map_err(backend)?;
                let machine = candidate
                    .compiled_code()
                    .ok_or_else(|| backend("composed phase lacks code"))?;
                if let Some(path) = inspect_path {
                    let vcode = machine
                        .vcode
                        .as_ref()
                        .ok_or_else(|| backend("composed VCode was not emitted"))?;
                    std::fs::write(path.with_extension("vcode"), vcode).map_err(backend)?;
                }
                composed = Some(Composed {
                    function: id,
                    admission,
                    summary: serde_json::json!({"symbol":name,"admission":admission,
                        "code_bytes":machine.code_info().total_size,
                        "stack_bytes":compiled_stack_bytes(&machine.buffer)?,
                        "scratch_bytes":if admission.immutable_code_bytes.is_some() { 0 } else { admission.cells_per_bank * 8 }}),
                });
            }
        }
    }
    if let Some(path) = std::env::var_os("MECH_INSPECT_PHASE_CLIF") {
        let path = std::path::PathBuf::from(path);
        if path.file_stem().is_some_and(|name| name == symbol.as_str()) {
            std::fs::write(&path, context.func.display().to_string()).map_err(backend)?;
            std::fs::write(path.with_extension("proof.txt"), format!("{proof:#?}"))
                .map_err(backend)?;
        }
    }
    let vcode_path = std::env::var_os("MECH_INSPECT_PHASE_VCODE")
        .map(std::path::PathBuf::from)
        .filter(|path| path.file_stem().is_some_and(|name| name == symbol.as_str()));
    if vcode_path.is_some() {
        context.set_disasm(true);
    }
    let compiled = phase_backend
        .compile(module.isa(), &mut context, vcode_path.is_some())
        .map_err(backend)?;
    let relocations = compiled.buffer.relocs().iter().map(|reloc| {
        cranelift_module::ModuleReloc::from_mach_reloc(reloc, &context.func, function)
    }).collect::<Vec<_>>();
    module.define_function_bytes(
        function,
        u64::from(compiled.buffer.alignment),
        compiled.buffer.data(),
        &relocations,
    ).map_err(backend)?;
    if let Some(path) = vcode_path {
        let text = compiled
            .vcode
            .as_ref()
            .ok_or_else(|| backend("phase VCode diagnostic was not emitted"))?;
        std::fs::write(path, text).map_err(backend)?;
    }
    let entry_bounds = report
        .phase_entry_bounds
        .iter()
        .map(|&(array, minimum)| (array, minimum, proof.arrays[array].appends))
        .collect::<Vec<_>>();
    let changed_writes = report.proven_changed_writes.clone();
    let private_writes = report.private_write_sites.clone();
    let mut summary = serde_json::json!({"read_pack_sites":pack_sites,"wider_equal_loops":equality.wider,"private_write_sites":private_writes,"proven_changed_writes":changed_writes,"phase_entry_bounds":entry_bounds,"header":header,"exit":region.tail.exit(),"symbol":symbol,
        "code_bytes":compiled.code_info().total_size,"stack_bytes":compiled_stack_bytes(&compiled.buffer)?,
        "input_words":input_words,"output_words":output_words,
        "fixed_writable_capacities":fixed_count,"fixed_length_entry_gate":fixed_count != 0,
        "actual_unit_append_growth":no_growth.is_none(),"unique_writable_owner_gate":true,"cleanup":cleanup});
    summary["bit_counts"] = serde_json::json!(bit_counts);
    if let Some(hint) = future_write_hints.first() {
        summary["future_write_hint"] = serde_json::json!(hint);
    }
    if let Some(hint) = future_write_hints.get(1) {
        summary["second_future_write_hint"] = serde_json::json!(hint);
    }
    if let Some(report) = vector_predicates {
        summary["private_vector_predicates"] = serde_json::json!(report);
    }
    if width_guards != 0 {
        summary["proved_width_guards"] = serde_json::json!(width_guards);
    }
    if window_bounds != 0 {
        summary["shared_window_bounds"] = serde_json::json!(window_bounds);
    }
    if !equality.reused.is_empty() {
        summary["reused_shifted_equality_loops"] = serde_json::json!(equality.reused);
    }
    if !equality.prefixes.is_empty() {
        summary["forwarded_equality_ends"] = serde_json::json!(equality.prefixes);
    }
    if let Some(threaded) = threaded {
        summary["threaded_after_growth_isolation"] = serde_json::json!(threaded);
    }
    if !read_guards.is_empty() {
        summary["proven_scalar_read_guards"] = serde_json::json!(read_guards);
    }
    if !write_guards.is_empty() {
        summary["proven_scalar_write_guards"] = serde_json::json!(write_guards);
    }
    if !reused_reads.is_empty() {
        summary["reused_scalar_reads"] = serde_json::json!(reused_reads);
    }
    if !reused_operands.is_empty() {
        summary["reused_scalar_operands"] = serde_json::json!(reused_operands);
    }
    if let Some(histogram) = histogram {
        summary["grouped_histogram"] = histogram;
    }

    Ok(Compiled {
        function,
        entry_bounds,
        summary,
        code: compiled.buffer.data().to_vec(),
        composed,
    })
}

fn phase_ir<M: Module>(
    module: &mut M,
    code: CodePlan<'_>,
    region: &crate::native_artifact::program::prepare::tail::Region,
    signature: &Signature,
    controls: &CompilationControls,
    observe: bool,
    vectors: Option<&VectorContract>,
    private: Option<&PrivatePhase>,
    no_growth: Option<&NoGrowth>,
    countdown: bool,
) -> Result<(Context, numeric_compact::Report), NativeCompileError> {
    let report;
    let mut context = module.make_context();
    context.func.signature = signature.clone();
    let mut fb = FunctionBuilderContext::new();
    {
        let mut b = FunctionBuilder::new(&mut context.func, &mut fb);
        let begin = b.create_block();
        b.append_block_params_for_function_params(begin);
        b.switch_to_block(begin);
        let args = b.block_params(begin).to_vec();
        let zero = b.ins().iconst(types::I64, 0);
        let error = b.create_block();
        b.append_block_param(error, types::I64);
        b.set_cold_block(error);
        let done = b.create_block();
        let storage = Arrays::new(module, &mut b, args[0], observe)?;
        let native = numeric_minimal::Boundary::new(
            &mut b,
            args[1],
            args[2],
            region,
            Some(&storage),
            private,
            no_growth,
        )?;
        report = numeric_compact::emit(
            controls, &mut b, code, region, &native, vectors, private, no_growth, done, error,
            countdown,
        )?;
        b.switch_to_block(done);
        b.ins().return_(&[zero, zero]);
        b.switch_to_block(error);
        let status = b.block_params(error)[0];
        let at = b.ins().load(types::I64, MemFlags::new(), args[2], 0);
        b.ins().return_(&[status, at]);
        b.seal_all_blocks();
        b.finalize();
    }
    Ok((context, report))
}

struct PhaseCleanup {
    bit_counts: usize,
    cleanup: CfgCleanup,
    equality: wide_equal::Outcome,
    threaded: Option<serde_json::Value>,
    vector_predicates: Option<serde_json::Value>,
    width_guards: usize,
    window_bounds: usize,
}

fn optimize_phase(
    context: &mut Context,
    controls: &CompilationControls,
    isa: &dyn TargetIsa,
    report: &numeric_compact::Report,
    symbol: &str,
    input_words: usize,
    output_words: usize,
    vectors: Option<&VectorContract>,
    private: Option<&PrivatePhase>,
    no_growth: Option<&NoGrowth>,
    report_diagnostics: bool,
) -> Result<PhaseCleanup, NativeCompileError> {
    // Numeric phases have their own sealed SSA; never match through packets.
    let mut bit_counts =
        crate::native_artifact::codegen::common::bit_counts::optimize(&mut context.func);
    let cleanup = cfg_cleanup::optimize(controls, context, isa)?;
    let word_loops = report;
    // Resolve literal admission flags before allocating the already selected
    // capacity-proved reduction. Keep other native routines on the usual pass.
    if no_growth.is_some()
        && !word_loops.reduction_completions.is_empty()
        && cfg_cleanup::fold_bitwise_constants(controls, &mut context.func) != 0
    {
        cfg_cleanup::optimize(controls, context, isa)?;
    }
    let equality = crate::native_artifact::program::codegen::wide_equal::optimize(
        context,
        &word_loops.compact_word_loops,
        private.is_some()
            && vectors.is_some()
            && std::env::var_os("MECH_REUSE_EQUALITY_PREFIX").is_some(),
    );
    // Named experimental condition: growth state is absent from this callee.
    let threaded = if no_growth.is_some()
        && std::env::var_os("MECH_THREAD_AFTER_GROWTH_ISOLATION").is_some()
    {
        Some(cfg_cleanup::thread_loop_edges(controls, context, isa)?)
    } else {
        None
    };
    if no_growth.is_some() && std::env::var_os("MECH_CHECKED_APPEND_RUN").is_some() {
        let outcome = crate::native_artifact::program::codegen::append_run::optimize(
            context,
            word_loops.machine_header,
            std::env::var_os("MECH_SPLIT_APPEND_DESCRIPTORS")
                .map(|value| (input_words, value == "all")),
            report_diagnostics
                && isa.name() == "aarch64"
                && isa.endianness() == cranelift_codegen::ir::Endianness::Little
                && std::env::var_os("MECH_PAIR_CHECKED_APPENDS").is_some(),
        );
        if std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() {
            eprintln!("{symbol} checked append run: {outcome:?}");
        }
    }
    if no_growth.is_some() && std::env::var_os("MECH_NARROW_MASKED_ARITHMETIC").is_some() {
        let narrowed =
            crate::native_artifact::program::codegen::low_word::narrow(&mut context.func);
        if std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() {
            eprintln!("{symbol} low-word operations: {narrowed}");
        }
    }
    // A completed ordered reduction names its own selected continuation.
    // Only those edges enter the existing acyclic forwarding proof.
    if no_growth.is_some() && !word_loops.reduction_completions.is_empty() {
        let report = cfg_cleanup::forward_identity_routes_from(
            controls,
            context,
            isa,
            Some(&word_loops.reduction_completions),
        )?;
        if std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() {
            eprintln!(
                "{symbol} completed reduction routes: {}",
                serde_json::to_string(&report).unwrap()
            );
        }
    }
    let vector_predicates = if private.is_some()
        && vectors.is_some()
        && std::env::var_os("MECH_PRIVATE_VECTOR_PREDICATES").is_some()
    {
        let report = cfg_cleanup::refine_current_predicates(controls, context, isa)?;
        if std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() && report.removed_branches != 0 {
            eprintln!(
                "{symbol} selected-edge predicates: {} branches",
                report.removed_branches
            );
        }
        Some(report)
    } else {
        None
    };
    let width_guards = if private.is_some()
        && vectors.is_some()
        && std::env::var_os("MECH_PRIVATE_VECTOR_WIDTHS").is_some()
    {
        let removed = cfg_cleanup::fold_proved_widths(controls, context, isa)?;
        if removed != 0 && std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() {
            eprintln!("{symbol} proved-width guards: {removed}");
        }
        removed
    } else {
        0
    };
    let window_bounds = if private.is_some() && vectors.is_some() {
        cfg_cleanup::combine_window_bounds(controls, context, isa)?
    } else {
        0
    };
    let paired_spans = if private.is_some()
        && vectors.is_some()
        && !equality.reused.is_empty()
        && std::env::var_os("MECH_ORDERED_CAPTURE_SPANS").is_some()
    {
        cfg_cleanup::fold_ordered_capture_spans(controls, context, isa)?
    } else {
        0
    };
    if paired_spans != 0 && std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() {
        eprintln!("{symbol} ordered capture spans: {paired_spans}");
    }
    if private.is_some()
        && vectors.is_some()
        && std::env::var_os("MECH_ADJACENT_ADDRESSES").is_some()
    {
        let changed = cfg_cleanup::reuse_adjacent_addresses(controls, context, isa)?;
        if changed != 0 && std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() {
            eprintln!("{symbol} adjacent typed accesses: {changed}");
        }
    }
    if std::env::var_os("MECH_SHARE_REPEATED_BOUNDS").is_some() {
        let changed = cfg_cleanup::share_repeated_bounds(controls, context, isa)?;
        if changed != 0 && std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() {
            eprintln!("{symbol} repeated bounds checks: {changed}");
        }
    }
    if private.is_some()
        && vectors.is_some()
        && std::env::var_os("MECH_DEFER_EXIT_PACKET_WORDS").is_some()
    {
        let changed = super::phase_storage::sink_exit_packet_words(
            &mut context.func,
            input_words,
            output_words,
        );
        if changed != 0 {
            context.verify(isa).map_err(backend)?;
            if std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() {
                eprintln!("{symbol} deferred exit packet words: {changed}");
            }
        }
    }
    if private.is_some()
        && vectors.is_some()
        && std::env::var_os("MECH_REUSE_DOMINATING_WINDOW_FACTS").is_some()
    {
        let changed = cfg_cleanup::reuse_dominating_window_facts(controls, context, isa)?;
        if changed != 0 && std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() {
            eprintln!("{symbol} reused dominating window facts: {changed}");
        }
    }
    if private.is_some()
        && vectors.is_some()
        && std::env::var_os("MECH_PROVE_SCALAR_SPANS").is_some()
    {
        let changed = cfg_cleanup::prove_scalar_spans(controls, context, isa)?;
        if changed != 0 && std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() {
            eprintln!("{symbol} proved scalar spans: {changed}");
        }
    }
    if private.is_some()
        && vectors.is_some()
        && std::env::var_os("MECH_PROVE_PACKED_BASE_SPANS").is_some()
    {
        let proved = cfg_cleanup::prove_packed_bases(controls, context, isa)?;
        if proved != 0 && std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() {
            eprintln!("{symbol} proved packed base spans: {proved}");
        }
    }
    if private.is_some()
        && vectors.is_some()
        && std::env::var_os("MECH_REUSE_SELECTED_READ_BOUND").is_some()
    {
        let changed = cfg_cleanup::reuse_selected_read_bounds(controls, context, isa)?;
        if changed != 0 && std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() {
            eprintln!("{symbol} reused selected readable bounds: {changed}");
        }
    }
    if private.is_some()
        && vectors.is_some()
        && std::env::var_os("MECH_COALESCE_EQUAL_JOIN_ARGUMENTS").is_some()
    {
        let removed = cfg_cleanup::coalesce_equal_join_arguments(controls, context, isa)?;
        if removed != 0 && std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() {
            eprintln!("{symbol} merged equal block arguments: {removed}");
        }
    }
    if private.is_some()
        && vectors.is_some()
        && cleanup.enabled
        && std::env::var_os("MECH_FORWARD_SELECTED_CONTINUATIONS").is_some()
    {
        context.compute_cfg();
        context.compute_domtree();
        let forwarded = cfg_cleanup::selected_continuations::optimize(
            &mut context.func,
            &context.cfg,
            &context.domtree,
        );
        if forwarded != 0 {
            context.compute_cfg();
            context.compute_domtree();
            if cfg!(target_arch = "aarch64")
                && std::env::var_os("MECH_NORMALIZE_SELECTED_LOOP_TEST").is_some()
            {
                context.eliminate_unreachable_code(isa).map_err(backend)?;
                context.compute_cfg();
                context.compute_domtree();
                let normalized = cfg_cleanup::selected_continuations::branch_form::optimize(
                    &mut context.func,
                    &context.domtree,
                );
                if normalized != 0 {
                    context.compute_cfg();
                    context.compute_domtree();
                    if std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() {
                        eprintln!("{symbol} normalized selected loop tests: {normalized}");
                    }
                }
            }
            context.verify(isa).map_err(backend)?;
            if std::env::var_os("MECH_INSPECT_PHASE_CLIF").is_some() {
                eprintln!("{symbol} forwarded selected continuations: {forwarded}");
            }
        }
    }
    // Late forwarding may expose a complete idiom without crossing a phase.
    bit_counts += crate::native_artifact::codegen::common::bit_counts::optimize(&mut context.func);
    let threaded = threaded
        .filter(|_| report_diagnostics)
        .map(|report| serde_json::json!(report));
    let vector_predicates = vector_predicates
        .filter(|report| report_diagnostics && report.removed_branches != 0)
        .map(|report| serde_json::json!(report));
    Ok(PhaseCleanup {
        bit_counts,
        cleanup,
        equality,
        threaded,
        vector_predicates,
        width_guards,
        window_bounds,
    })
}
