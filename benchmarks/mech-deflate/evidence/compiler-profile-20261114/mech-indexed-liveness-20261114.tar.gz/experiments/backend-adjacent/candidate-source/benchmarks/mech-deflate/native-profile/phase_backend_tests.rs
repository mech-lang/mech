//! Exercise the exact per-compilation backend reuse and parameter relocation.
#[path = "../../../hosts/gpu/src/native_artifact/program/compact/phase_backend.rs"]
mod phase_backend;
