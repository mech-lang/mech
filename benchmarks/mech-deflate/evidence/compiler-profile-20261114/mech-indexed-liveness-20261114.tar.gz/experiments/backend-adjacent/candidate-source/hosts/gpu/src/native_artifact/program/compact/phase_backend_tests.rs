use super::*;
use cranelift_codegen::cursor::{Cursor, FuncCursor};
use cranelift_codegen::ir::{
    AbiParam, ExtFuncData, ExternalName, InstBuilder, SourceLoc, UserExternalName, UserFuncName,
    types,
};
use cranelift_codegen::settings::Configurable;
use cranelift_frontend::{FunctionBuilder, FunctionBuilderContext};
use cranelift_module::{FuncId, ModuleReloc, ModuleRelocTarget};

fn isa(opt: &str) -> cranelift_codegen::isa::OwnedTargetIsa {
    let mut flags = settings::builder();
    flags.set("opt_level", opt).unwrap();
    flags.set("enable_verifier", "true").unwrap();
    cranelift_native::builder()
        .unwrap()
        .finish(settings::Flags::new(flags))
        .unwrap()
}
fn function(value: i64, base: u32, imported: Option<u32>) -> Context {
    let mut context = Context::new();
    context.func.name = UserFuncName::user(0, base);
    context
        .func
        .signature
        .params
        .push(AbiParam::new(types::I64));
    context
        .func
        .signature
        .returns
        .push(AbiParam::new(types::I64));
    let callee = imported.map(|index| {
        let signature = context.func.signature.clone();
        let signature = context.func.import_signature(signature);
        let name = context
            .func
            .declare_imported_user_function(UserExternalName::new(0, index));
        context.func.import_function(ExtFuncData {
            name: ExternalName::User(name),
            signature,
            colocated: false,
            patchable: false,
        })
    });
    let mut fb = FunctionBuilderContext::new();
    let mut b = FunctionBuilder::new(&mut context.func, &mut fb);
    let entry = b.create_block();
    b.append_block_params_for_function_params(entry);
    b.switch_to_block(entry);
    b.set_srcloc(SourceLoc::new(base));
    let input = b.block_params(entry)[0];
    let result = if let Some(callee) = callee {
        let call = b.ins().call(callee, &[input]);
        b.inst_results(call)[0]
    } else {
        b.ins().iadd_imm(input, value)
    };
    b.ins().return_(&[result]);
    b.seal_all_blocks();
    b.finalize();
    context
}
fn ordinary(isa: &dyn TargetIsa, original: &Context) -> CompiledCode {
    let mut context = Context::new();
    context.func = original.func.clone();
    context
        .compile(isa, &mut ControlPlane::default())
        .unwrap()
        .clone()
}
#[test]
fn exact_input_reuse_applies_current_source_parameters_and_owns_its_input() {
    let isa = isa("speed");
    let mut compiler = PhaseBackend::default();
    let mut first = function(17, 100, None);
    let first_expected = ordinary(&*isa, &first);
    assert_eq!(
        compiler.compile(&*isa, &mut first, false).unwrap(),
        first_expected
    );
    // Backend compilation mutates the first context, and callers may discard it.
    drop(first);
    let mut second = function(17, 800, None);
    let second_expected = ordinary(&*isa, &second);
    assert_eq!(
        compiler.compile(&*isa, &mut second, false).unwrap(),
        second_expected
    );
    assert_eq!((compiler.hits, compiler.misses), (1, 1));
    assert_ne!(
        first_expected.buffer.get_srclocs_sorted(),
        second_expected.buffer.get_srclocs_sorted()
    );
}
#[test]
fn equivalent_stencils_relocate_to_each_current_imported_function() {
    let isa = isa("speed");
    let mut compiler = PhaseBackend::default();
    for imported in [7, 19] {
        let mut context = function(0, imported, Some(imported));
        let expected = ordinary(&*isa, &context);
        let result = compiler.compile(&*isa, &mut context, false).unwrap();
        assert_eq!(result, expected);
        let relocations = result
            .buffer
            .relocs()
            .iter()
            .map(|r| ModuleReloc::from_mach_reloc(r, &context.func, FuncId::from_u32(100)))
            .collect::<Vec<_>>();
        assert!(!relocations.is_empty());
        assert!(
            relocations
                .iter()
                .all(|r| matches!(r.name, ModuleRelocTarget::User { namespace: 0, index } if index == imported))
        );
    }
    assert_eq!((compiler.hits, compiler.misses), (1, 1));
}
#[test]
fn different_ir_and_target_settings_compile_independently() {
    let optimized = isa("speed");
    let unoptimized = isa("none");
    let mut compiler = PhaseBackend::default();
    for (isa, value) in [(&*optimized, 17), (&*optimized, 18), (&*unoptimized, 18)] {
        let mut context = function(value, 100, None);
        let expected = ordinary(isa, &context);
        assert_eq!(
            compiler.compile(isa, &mut context, false).unwrap(),
            expected
        );
    }
    assert_eq!((compiler.hits, compiler.misses), (0, 3));
}
fn insert_dead_arithmetic(context: &mut Context, count: usize) {
    let entry = context.func.layout.blocks().next().unwrap();
    let first = context.func.layout.first_inst(entry).unwrap();
    let input = context.func.dfg.block_params(entry)[0];
    let mut cursor = FuncCursor::new(&mut context.func).at_inst(first);
    for _ in 0..count {
        cursor.ins().iadd_imm(input, 1);
    }
}
#[test]
fn identical_machine_bytes_do_not_substitute_for_exact_ir_equality() {
    let isa = isa("speed");
    let mut compiler = PhaseBackend::default();
    let mut first = function(17, 100, None);
    let mut second = function(17, 100, None);
    insert_dead_arithmetic(&mut second, 1);
    assert!(first.func.stencil != second.func.stencil);
    let first_expected = ordinary(&*isa, &first);
    let second_expected = ordinary(&*isa, &second);
    assert_eq!(first_expected.buffer.data(), second_expected.buffer.data());
    assert_eq!(
        compiler.compile(&*isa, &mut first, false).unwrap(),
        first_expected
    );
    assert_eq!(
        compiler.compile(&*isa, &mut second, false).unwrap(),
        second_expected
    );
    assert_eq!((compiler.hits, compiler.misses), (0, 2));
}
#[test]
fn malformed_current_input_remains_an_error_and_is_not_retained() {
    let isa = isa("speed");
    let mut compiler = PhaseBackend::default();
    compiler
        .compile(&*isa, &mut function(17, 100, None), false)
        .unwrap();
    let retained = compiler.previous.as_ref().unwrap().input.clone();
    let mut invalid = function(17, 100, None);
    invalid.func.signature.returns.clear();
    assert!(compiler.compile(&*isa, &mut invalid, false).is_err());
    assert!(compiler.previous.is_none());
    let _ = retained;
    assert_eq!(compiler.hits, 0);
}
#[test]
fn oversized_input_is_not_retained_and_a_new_batch_starts_empty() {
    let isa = isa("speed");
    let mut compiler = PhaseBackend::default();
    let mut original = function(17, 100, None);
    insert_dead_arithmetic(&mut original, 8192);
    for _ in 0..2 {
        let mut context = Context::new();
        context.func = original.func.clone();
        let expected = ordinary(&*isa, &context);
        assert_eq!(
            compiler.compile(&*isa, &mut context, false).unwrap(),
            expected
        );
    }
    assert_eq!((compiler.hits, compiler.misses), (0, 2));
    assert!(compiler.previous.is_none());
    assert!(PhaseBackend::default().previous.is_none());
}
#[test]
fn requested_disassembly_is_emitted_from_its_own_context() {
    let isa = isa("speed");
    let mut compiler = PhaseBackend::default();
    compiler
        .compile(&*isa, &mut function(17, 100, None), false)
        .unwrap();
    let mut diagnostic = function(17, 800, None);
    diagnostic.set_disasm(true);
    let result = compiler.compile(&*isa, &mut diagnostic, true).unwrap();
    assert!(result.vcode.is_some());
    assert_eq!((compiler.hits, compiler.misses), (0, 1));
}
