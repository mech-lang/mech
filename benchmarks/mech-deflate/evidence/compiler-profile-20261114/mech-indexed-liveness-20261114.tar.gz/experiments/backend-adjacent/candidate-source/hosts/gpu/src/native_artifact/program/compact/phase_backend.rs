//! Reuse identical backend inputs only within one fresh phase-compilation batch.
//! All source admission, lowering and phase optimization still run for each body.
use cranelift_codegen::{
    CodegenResult, CompiledCode, Context,
    control::ControlPlane,
    ir::function::{FunctionParameters, FunctionStencil},
    isa::TargetIsa,
    settings,
};

#[derive(PartialEq)]
struct Target {
    name: &'static str,
    triple: String,
    shared: settings::Flags,
    specific: Vec<String>,
}
impl Target {
    fn of(isa: &dyn TargetIsa) -> Self {
        Self {
            name: isa.name(),
            triple: isa.triple().to_string(),
            shared: isa.flags().clone(),
            specific: isa.isa_flags().iter().map(ToString::to_string).collect(),
        }
    }
}

struct Entry {
    input: FunctionStencil,
    // The public stencil compiler returns an unexported concrete type. Retain
    // its parameter application without adding serialization or a vendor API.
    finish: Box<dyn Fn(&FunctionParameters) -> CompiledCode>,
}

#[derive(Default)]
pub(super) struct PhaseBackend {
    target: Option<Target>,
    previous: Option<Entry>,
    pub hits: usize,
    pub misses: usize,
}
impl PhaseBackend {
    pub fn compile(
        &mut self,
        isa: &dyn TargetIsa,
        context: &mut Context,
        disassemble: bool,
    ) -> CodegenResult<CompiledCode> {
        // A diagnostic requests its own context/disassembly. Do not substitute
        // another definition's text or context state, even for identical IR.
        if disassemble {
            return context
                .compile_stencil(isa, &mut ControlPlane::default())
                .map(|code| code.apply_params(&context.func.params));
        }
        let target = Target::of(isa);
        if self.target.as_ref() != Some(&target) {
            self.previous = None;
            self.target = Some(target);
        }
        if let Some(entry) = self
            .previous
            .as_ref()
            .filter(|entry| entry.input == context.func.stencil)
        {
            // Keep the backend's configured verifier on the current input.
            // Only full stencil equality establishes reuse; no hash is involved.
            context.verify_if(isa)?;
            self.hits += 1;
            return Ok((entry.finish)(&context.func.params));
        }
        self.misses += 1;
        // General/vector alternatives are emitted consecutively. Retain only
        // the immediately preceding input, bounded by both IR and value count.
        // Release it before compiling a different body and drop the batch before
        // the main entry. Oversized bodies simply use the ordinary backend.
        self.previous = None;
        let retain = context.func.dfg.num_insts() <= 8192 && context.func.dfg.num_values() <= 32768;
        let input = retain.then(|| context.func.stencil.clone());
        let output = context.compile_stencil(isa, &mut ControlPlane::default())?;
        if let Some(input) = input {
            let retained = output.clone();
            self.previous = Some(Entry {
                input,
                finish: Box::new(move |params| retained.clone().apply_params(params)),
            });
        }
        Ok(output.apply_params(&context.func.params))
    }
}

#[cfg(test)]
#[path = "phase_backend_tests.rs"]
mod tests;
