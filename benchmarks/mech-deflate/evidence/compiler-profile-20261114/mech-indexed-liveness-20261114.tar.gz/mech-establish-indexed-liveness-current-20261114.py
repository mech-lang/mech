from pathlib import Path
import os,json,subprocess,sys,hashlib
repo=Path.cwd();root=Path('/private/tmp/mech-indexed-liveness-current-20261114');flags=json.loads((root/'runtime-flags.json').read_text());assert len(flags)==55 and flags['MECH_TERMINAL_BYTE_APPENDS']=='1'
name='control-screen';assert not (root/name).exists();binary=root/'control';cmd=[sys.executable,'benchmarks/mech-deflate/native-profile/profile_compile.py',str(binary),'benchmark',str(root/name),'compact']
env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')};env.update(flags)
(root/(name+'-command.json')).write_text(json.dumps(dict(command=cmd,flags=flags,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest()),indent=2)+'\n')
subprocess.run(cmd,cwd=repo,env=env,check=True)
pins={n:dict(bytes=(root/name/n).stat().st_size,sha256=hashlib.sha256((root/name/n).read_bytes()).hexdigest()) for n in ['source.mec','program.mecb','program.o','metadata.json']}
assert pins['source.mec']['sha256']=='331e659e92181d803b3d87218effe88f711c2e8ecad9f31838fc50991de1c5c9'
assert pins['program.mecb']['sha256']=='a2a551911949f8c5fdc64273a43662c2a9c4953b853136c19d196692fdac45a7'
assert pins['program.o']['sha256']=='38b194ec2c931fbd5d584ace06bdaba1efb59381e64eef1d662a5f2f12bd96b4'
(root/'qualified-output-pins.json').write_text(json.dumps(pins,indent=2,sort_keys=True)+'\n')
(root/'baseline-qualification.json').write_text(json.dumps(dict(base_commit='ada4fa0062984fa9687e179f72f6d6b3acbad58e',flags_count=55,expected_native_object='38b194ec2c931fbd5d584ace06bdaba1efb59381e64eef1d662a5f2f12bd96b4',reference_report='docs/design/native-terminal-byte-appends.md at ada4fa0062984fa9687e179f72f6d6b3acbad58e',metadata_scope='Complete metadata for the current clean-source control is established by this observation. The former 54-flag metadata is not its reference.',output_hashes=pins),indent=2,sort_keys=True)+'\n');print('Current runtime baseline reproduces its published Object.',flush=True)
