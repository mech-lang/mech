from pathlib import Path
import subprocess,json,hashlib,shutil,os,re
repo=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech');packet=Path('/private/tmp/mech-indexed-liveness-packet-20261114');assert not packet.exists();packet.mkdir()
base='ada4fa0062984fa9687e179f72f6d6b3acbad58e';oldbase='1ce14381f2c3428a20c0c727a07c4943995a3795';source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
raw=Path('/private/tmp/mech-indexed-liveness-current-20261114');patch=subprocess.check_output(['git','diff','--binary',base,source],cwd=repo);assert patch==(raw/'candidate.patch').read_bytes()
paths=subprocess.check_output(['git','diff','--name-only',base,source],cwd=repo,text=True).splitlines();assert len(paths)==3 and all('/prepare/numeric_' in p for p in paths)
state=dict(source_commit=source,base_commit=base,old_base_commit=oldbase,patch_sha256=hashlib.sha256(patch).hexdigest(),hardware='Apple M3 Air, 8 cores (4P+4E), 16 GB, macOS 26.2',rustc=subprocess.check_output(['rustc','-Vv'],text=True),cargo=subprocess.check_output(['cargo','-V'],text=True))
(packet/'source-state.json').write_text(json.dumps(state,indent=2,sort_keys=True)+'\n');(packet/'source-change.patch').write_bytes(patch)
roots={'backend-hash':'mech-phase-backend-20261114','backend-adjacent':'mech-adjacent-backend-20261114','indexed-initial':'mech-indexed-liveness-20261114','indexed-current':'mech-indexed-liveness-current-20261114'}
excluded=[]
for label,dirname in roots.items():
 root=Path('/private/tmp')/dirname
 for p in sorted(root.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(root)
  if str(rel) in ['control','candidate']:
   excluded.append(dict(path=f'experiments/{label}/{rel}',bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()));continue
  d=packet/'experiments'/label/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
(packet/'excluded-executables.json').write_text(json.dumps(excluded,indent=2)+'\n')
# Reconstruct the complete superseded hash-indexed source from its pinned base
# and exact recorded patch, in an isolated directory without a Git index.
hashpatch=packet/'experiments/backend-hash/candidate.patch';snapshot=packet/'sources/backend-hash';snapshot.mkdir(parents=True)
hashpaths=re.findall(r'^diff --git a/(\S+) b/(\S+)$',hashpatch.read_text(),re.M);assert len(hashpaths)==7
for left,name in hashpaths:
 assert left==name and '..' not in Path(name).parts and not Path(name).is_absolute()
 p=snapshot/name;p.parent.mkdir(parents=True,exist_ok=True);r=subprocess.run(['git','show',oldbase+':'+name],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
 if not r.returncode:p.write_bytes(r.stdout)
 else:assert name in ['hosts/gpu/src/native_artifact/program/compact/phase_backend.rs','hosts/gpu/src/native_artifact/program/compact/phase_backend_tests.rs','benchmarks/mech-deflate/native-profile/phase_backend_tests.rs']
env={k:v for k,v in os.environ.items() if k not in ['GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE']};subprocess.run(['git','apply',str(hashpatch)],cwd=snapshot,env=env,check=True)
shutil.copytree(packet/'experiments/backend-adjacent/candidate-source',packet/'sources/backend-adjacent')
sourcepaths=paths+['benchmarks/mech-deflate/native-profile/'+n for n in ['Cargo.toml','Cargo.lock','compile_profile.rs','profile_compile.py','numeric_liveness_tests.rs']]+['benchmarks/mech-deflate/experiment.py','.cargo/config.toml','LICENSE','hosts/gpu/Cargo.toml','docs/design/native-terminal-byte-appends.md','hosts/gpu/tests/fixtures/native/deflate-huffman-LICENSES.md','hosts/gpu/src/native_artifact/program/runtime/composition_tests/nested_phase.rs']
sourcepaths+=['hosts/gpu/src/native_artifact/'+n for n in ['program/compiler.rs','program/compact/emit.rs','program/compact/terminal_appends.rs','compact_runtime/mod.rs','compact_runtime/terminal_appends.rs']]
sourcepaths+=['vendor/cranelift-codegen/src/'+n for n in ['context.rs','ir/function.rs','machinst/mod.rs']]
sourcepaths+=['hosts/gpu/tests/fixtures/native/'+n+'.mec' for n in ['numeric-nested-phase','numeric-nested-phase-states','numeric-private-fixed-nested','numeric-changing-capture-tree','numeric-array-windows','numeric-multiple-children']]
for name in sourcepaths:
 d=packet/'sources/indexed-current'/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(subprocess.check_output(['git','show',source+':'+name],cwd=repo))
validation=packet/'validation';validation.mkdir()
for suffix in ['.json','.archive.json']:shutil.copy2(repo/('benchmarks/mech-deflate/native-profile/borrowed-schema-compile-apple-m3-20261114'+suffix),validation/('qualified-54-flags'+suffix))
shutil.copytree(Path('/private/tmp/mech-borrowed-schema-packet-20261114/licenses'),packet/'licenses')
scripts=['mech-curate-indexed-liveness-20261114.py','mech-close-backend-trials-20261114.py','mech-edit-indexed-liveness-20261114.py']
for prefix in ['phase-backend','adjacent-backend','indexed-liveness','indexed-liveness-current']:
 scripts += [f'mech-{op}-{prefix}-20261114.py' for op in ['build','test','run']]
 scripts += [f'mech-run-{prefix}-cohort-20261114.py'] if prefix in ['phase-backend','adjacent-backend','indexed-liveness'] else ['mech-run-indexed-liveness-current-cohort-20261114.py']
scripts+=['mech-establish-indexed-liveness-current-20261114.py','mech-indexed-liveness-fixtures-20261114.py','mech-indexed-liveness-current-fixtures-20261114.py']
for name in scripts:
 p=Path('/private/tmp')/name;assert p.is_file(),name;shutil.copy2(p,packet/name)
logs=['mech-phase-backend-build-driver-20261114.log','mech-phase-backend-test-driver-20261114.log','mech-phase-backend-screen-driver-20261114.log','mech-adjacent-backend-build-driver-20261114.log','mech-adjacent-backend-test-driver-20261114.log','mech-adjacent-backend-screen-driver-20261114.log','mech-adjacent-backend-cohort-driver-20261114.log','mech-indexed-liveness-build-driver-20261114.log','mech-indexed-liveness-test-driver-20261114.log','mech-indexed-liveness-screen-driver-20261114.log','mech-indexed-liveness-fixtures-driver-20261114.log','mech-indexed-liveness-current-control-build-driver-20261114.log','mech-indexed-liveness-current-candidate-build-driver-20261114.log','mech-indexed-liveness-current-test-driver-20261114.log','mech-indexed-liveness-current-reference-driver-20261114.log','mech-indexed-liveness-current-screen-driver-20261114.log','mech-indexed-liveness-current-fixtures-driver-20261114.log','mech-indexed-liveness-current-cohort-driver-20261114.log']
for name in logs:shutil.copy2(Path('/private/tmp')/name,packet/name)
(packet/'README.txt').write_text('''Query-local liveness graph indexing, Apple M3, 2026-11-14.
The current matched qualification uses both frozen compilers on base ada4fa,
with the same complete 55 flags including terminal byte appends. The current
control reproduces that runtime change's published Object. Source, bytecode,
Object and complete metadata match between subjects in every observation.
The earlier 54-flag screen and 14 fixture pairs precede the PR update and are
separate diagnostics, never pooled with current primary timing.
Two backend-reuse approaches are rejected: a hash-indexed diagnostic finds
46/344 exact stencils; one-entry reuse finds 123/344 but saves only 1.80% of
numeric generation, with compiler time 0.62% worse and instructions essentially
flat. Its apparent whole-process saving includes a larger interval outside the
compiler timer in the first control. No useful overall saving is established.
Both complete candidate patches, source snapshots, tests and all observations
remain. Transient build/test/launcher corrections remain as logs with patches
where captured and are never performance observations. The failed launcher
stops on an existing-output assertion before starting a compile.
No backend cache is retained in production. The accepted liveness change
constructs the same query graph in original DFS/error order with local indices,
keeps every original ordered definition lookup including unread values, and
uses the same dense/sparse fixed point with read-before-definition kills.
No plan, predicates, proof, liveness answer or ownership result is cached.
All current visits and finite runtime/resource checks remain. Grammar, language,
backend optimization level, direct scalar codegen and generated program speed
are preserved through byte-identical program output. No new runtime latency
campaign is claimed. Both 13-test runs and 14 fixture pairs are retained.
Compiler builds, tests, screens, fixtures and archiving do not overlap either
primary cohort. Cargo test also builds the compiler binary; later fast cargo
build checks are not claimed as cold compiler bootstraps. Complete build logs
and wall times are separate from fresh source-to-Object process measurements.
The full ten-second goal remains open. This complete compressed evidence is
published under benchmarks/mech-deflate; compiler executables are excluded and
hash-pinned. Run python3 replay.py for independent offline reconstruction.
''');print(packet,flush=True)
