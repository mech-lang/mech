from pathlib import Path
import json,subprocess,os,hashlib
repo=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech');root=Path('/private/tmp/mech-indexed-liveness-current-20261114');out=root/'fixtures';out.mkdir(exist_ok=True)
flags=json.loads((root/'runtime-flags.json').read_text());env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')};env.update(flags)
inputs=root/'fixture-inputs';inputs.mkdir(exist_ok=True)
import shutil
for filename in ['numeric-nested-phase-states.mec','assembly.json']:
 shutil.copy2(Path('/private/tmp/mech-numeric-facts-20261113/fixture-inputs')/filename,inputs/filename)
names=['numeric-nested-phase','numeric-nested-phase-states','numeric-private-fixed-nested','numeric-changing-capture-tree','numeric-array-windows','numeric-multiple-children']
scalars={'scalar-bool-equal':'left<bool> == right<bool>\n','scalar-u64-add':'left<u64> + right<u64>\n','scalar-u64-divide':'left<u64> / right<u64>\n','scalar-i64-add':'left<i64> + right<i64>\n','scalar-i64-multiply':'left<i64> * right<i64>\n','scalar-i64-divide':'left<i64> / right<i64>\n','scalar-f64-add':'left<f64> + right<f64>\n','scalar-f64-divide':'left<f64> / right<f64>\n'}
for name,text in scalars.items():(inputs/(name+'.mec')).write_text(text)
names+=list(scalars)
results=[]
for name in names:
 fixture=(inputs/(name+'.mec')) if name=='numeric-nested-phase-states' or name in scalars else repo/'hosts/gpu/tests/fixtures/native'/(name+'.mec');record={'fixture':('generated:'+name if name in scalars else 'assembled:numeric-nested-phase-states' if name=='numeric-nested-phase-states' else str(fixture.relative_to(repo))),'source_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),'variants':{}}
 for variant in ['control','candidate']:
  directory=out/name/variant;directory.mkdir(parents=True,exist_ok=True)
  cmd=[str(root/variant),str(fixture),str(directory),'compact']
  command={'command':cmd,'flags':flags,'binary_sha256':hashlib.sha256((root/variant).read_bytes()).hexdigest()};(directory/'command.json').write_text(json.dumps(command,indent=2)+'\n')
  with (directory/'stdout.jsonl').open('w') as stdout,(directory/'stderr.log').open('w') as stderr:p=subprocess.run(cmd,cwd=repo,env=env,stdout=stdout,stderr=stderr)
  files={}
  for filename in ['source.mec','program.mecb','program.o','metadata.json']:
   path=directory/filename
   if path.exists():files[filename]={'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
  record['variants'][variant]={'exit_code':p.returncode,'files':files}
 record['all_outputs_match']=record['variants']['control']==record['variants']['candidate']
 results.append(record);(root/'fixture-results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,record['variants']['control']['exit_code'],record['variants']['candidate']['exit_code'],record['all_outputs_match'],flush=True)
 assert record['all_outputs_match']
assert all(row['variants']['control']['exit_code']==0 and len(row['variants']['control']['files'])==4 for row in results),'a pinned fixture did not compile successfully'
