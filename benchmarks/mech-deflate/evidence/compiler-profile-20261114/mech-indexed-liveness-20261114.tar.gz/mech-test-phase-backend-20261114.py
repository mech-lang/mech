from pathlib import Path
import subprocess,os,time,json
root=Path('/private/tmp/mech-phase-backend-20261114');root.mkdir(exist_ok=True)
command=['cargo','test','--locked','--offline','--release','-j2','--manifest-path','benchmarks/mech-deflate/native-profile/Cargo.toml','--test','phase_backend']
start=time.perf_counter()
with (root/'backend-tests.log').open('wb') as f:p=subprocess.run(command,env=dict(os.environ,CARGO_TARGET_DIR='/private/tmp/mech-level12-compile-target',CARGO_INCREMENTAL='0'),stdout=f,stderr=subprocess.STDOUT)
result=dict(command=command,exit_code=p.returncode,seconds=time.perf_counter()-start,CARGO_TARGET_DIR='/private/tmp/mech-level12-compile-target',CARGO_INCREMENTAL='0')
(root/'backend-tests-command.json').write_text(json.dumps(result,indent=2)+'\n');print(result,flush=True)
raise SystemExit(p.returncode)
