from pathlib import Path
import subprocess,hashlib,json,statistics,shutil
repo=Path.cwd();root=Path('/private/tmp/mech-adjacent-backend-20261114');build=json.loads((root/'candidate-build.json').read_text());patch=subprocess.check_output(['git','diff','--binary']);assert patch==(root/'candidate.patch').read_bytes();assert hashlib.sha256(patch).hexdigest()==build['patch_sha256'];assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==build['head']
paths=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines();snapshot=root/'candidate-source'
for name in paths:
 p=repo/name;d=snapshot/name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
rows=json.loads((root/'cohort.json').read_text());fields={'compiler_seconds':lambda r:r['compile']['total_seconds'],'whole_process_seconds':lambda r:r['process']['elapsed_seconds']}
for k in ['numeric_generation_seconds','preparation_seconds','source_cfg_seconds','cleanup_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:fields[k]=lambda r,k=k:r[k]
qualified={k:{v:[f(r) for r in rows if r['variant']==v] for v in ['control','candidate']} for k,f in fields.items()}
for r in qualified.values():r['candidate_mean_change_fraction']=statistics.mean(r['candidate'])/statistics.mean(r['control'])-1
(root/'decision.json').write_text(json.dumps(dict(decision='Reject both backend-reuse implementations. Preserve byte-identical output evidence, but no useful total compiler/instruction saving is established.',qualified=qualified,reason='Adjacent reuse finds 123/344 exact inputs but numeric generation falls only 1.80%; compiler time rises 0.62%, instructions fall only 0.041%, while whole process falls 1.43%. These mixed observations do not justify retaining the added compilation machinery.',source_restore_base=build['head'],source_restore_patch_sha256=build['patch_sha256'],changed_files=paths),indent=2,sort_keys=True)+'\n')
for name in paths:
 p=repo/name;result=subprocess.run(['git','show','HEAD:'+name],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
 if result.returncode==0:p.write_bytes(result.stdout)
 else:p.unlink()
print('Preserved trial source and decision; restored',len(paths),'source files to HEAD.')
