Query-local liveness graph indexing, Apple M3, 2026-11-14.
The current matched qualification uses both frozen compilers on base ada4fa,
with the same complete 55 flags including terminal byte appends. The current
control reproduces that runtime change's published Object. Source, bytecode,
Object and complete metadata match between subjects in every observation.
The earlier 54-flag screen and 14 fixture pairs precede the PR update and are
separate diagnostics, never pooled with current primary timing.
Two backend-reuse approaches are rejected: a hash-indexed diagnostic finds
46/344 exact stencils; one-entry reuse finds 123/344 but saves only 1.80% of
numeric generation, with compiler time 0.62% worse and instructions essentially
flat. Its apparent whole-process saving includes a larger interval outside the
compiler timer in the first control. No useful overall saving is established.
Both complete candidate patches, source snapshots, tests and all observations
remain. Transient build/test/launcher corrections remain as logs with patches
where captured and are never performance observations. The failed launcher
stops on an existing-output assertion before starting a compile.
No backend cache is retained in production. The accepted liveness change
constructs the same query graph in original DFS/error order with local indices,
keeps every original ordered definition lookup including unread values, and
uses the same dense/sparse fixed point with read-before-definition kills.
No plan, predicates, proof, liveness answer or ownership result is cached.
All current visits and finite runtime/resource checks remain. Grammar, language,
backend optimization level, direct scalar codegen and generated program speed
are preserved through byte-identical program output. No new runtime latency
campaign is claimed. Both 13-test runs and 14 fixture pairs are retained.
Compiler builds, tests, screens, fixtures and archiving do not overlap either
primary cohort. Cargo test also builds the compiler binary; later fast cargo
build checks are not claimed as cold compiler bootstraps. Complete build logs
and wall times are separate from fresh source-to-Object process measurements.
The full ten-second goal remains open. This complete compressed evidence is
published under benchmarks/mech-deflate; compiler executables are excluded and
hash-pinned. Run python3 replay.py for independent offline reconstruction.
