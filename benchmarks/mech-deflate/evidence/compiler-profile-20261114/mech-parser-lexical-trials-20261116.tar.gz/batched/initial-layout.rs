extern crate alloc;
#[path="/private/tmp/mech-parser-lexical-reuse-20261115/candidate/document/mod.rs"]pub mod document;
fn main(){println!("{}",serde_json::json!({"continuation":std::mem::size_of::<document::parser::canonical::base::continuation::Continuation>(),"frame_storage":std::mem::size_of::<document::parser::canonical::base::continuation::FrameStorage>()}));}
