    /// Append complete pages together. Retained snapshots still own their old
    /// chunks; the current last page needs at most one mutable lookup per fill.
    pub(crate) fn extend(&mut self, values: impl IntoIterator<Item = T>) {
        let mut values = values.into_iter();
        loop {
            let remaining = PAGE - self.len % PAGE;
            let mut batch = SmallVec::<[T; PAGE]>::new();
            for _ in 0..remaining {
                let Some(value) = values.next() else { break; };
                batch.push(value);
            }
            if batch.is_empty() { return; }
            let count = batch.len();
            self.changed_from = self.changed_from.min(self.len);
            if self.len % PAGE == 0 {
                self.allocations += 1;
                self.allocations += self.items.push(Chunk(Arc::new(batch)));
            } else {
                self.chunk_mut(self.len / PAGE).expect("last journal page").extend(batch);
            }
            self.len += count;
            self.mutations += count as u64;
        }
    }
