    #[test]
    fn batched_appends_preserve_retained_snapshots_and_partial_pages() {
        for prefix in 0..=20 { for count in 0..=20 {
            let mut journal=Journal::default();
            let mut expected=Vec::new();
            for value in 0..prefix { journal.push(value); expected.push(value); }
            let retained=journal.clone();let before=journal.mutations;
            journal.extend(100..100+count);expected.extend(100..100+count);
            same(&journal,&expected);same(&retained,&(0..prefix).collect::<Vec<_>>());
            assert_eq!(journal.mutations-before,count as u64);
            for len in (0..=expected.len()).rev() {
                let saved=journal.clone();let saved_expected=expected.clone();
                journal.truncate(len);expected.truncate(len);
                journal.extend([200,201,202,203,204]);expected.extend([200,201,202,203,204]);
                same(&journal,&expected);same(&saved,&saved_expected);
            }
        }}
    }
