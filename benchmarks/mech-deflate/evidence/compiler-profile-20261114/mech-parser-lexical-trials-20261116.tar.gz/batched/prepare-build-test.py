from pathlib import Path
import difflib,hashlib,json,os,shutil,subprocess,time
repo=Path.cwd();old=Path('/private/tmp/mech-parser-lexical-reuse-direct-20261115');root=Path('/private/tmp/mech-parser-lexical-reuse-batched-20261115');root.mkdir(exist_ok=False)
for v in ['reference','candidate']:shutil.copytree(old/v,root/v)
shutil.copytree(old/'tests',root/'tests')
for n in ['source.mec','recipe.json']:shutil.copy2(old/n,root/n)
shutil.copy2(__file__,root/'prepare-build-test.py')
inputs=Path('/private/tmp/mech-parser-lexical-reuse-input-20261115')
for n in ['journal-extend.rs','journal-extend-test.rs','batch-replay.rs']:shutil.copy2(inputs/n,root/n)
def replace(rel,before,after):
 p=root/'candidate/document'/rel;s=p.read_text();assert s.count(before)==1,(str(rel),before[:120],s.count(before));p.write_text(s.replace(before,after))
cont=Path('parser/canonical/base/continuation.rs');rec=Path('parser/canonical/base/recognition.rs')
replace(Path('parser/canonical/base/mod.rs'),'mod recognition;','pub(super) mod recognition;')
replace(cont,'    pub(super) recognition: super::recognition::Cache,\n','')
replace(cont,'    capture: Option<super::recognition::Capture>,\n','')
replace(cont,'            capture: None,\n','')
replace(cont,'prediction: Option<Box<[Option<super::super::prediction::Plan>; super::NON_FIXED_RULES.len()]>>','prediction: Option<Box<super::recognition::Storage>>')
p=root/'candidate/document'/cont;s=p.read_text();start=s.index('                if final_input && self.capture.is_none() && !parser.is_halted()');end=s.index('                self.node(parser, kind);',start)
s=s[:start]+'''                if final_input && !parser.is_halted() {
                    let state = self.storage.prediction.get_or_insert_with(|| Box::new(super::recognition::Storage::default()));
                    let cache = &mut state.memo;
                    if cache.capture.is_none() && cache.kind(rule, kind, first, rest).is_some() {
                        if let Some((work, raw)) = cache.replay(parser, rule, checkpoint.rule_depth, *allowance + 1) {
                            let exit = self.storage.frames.pop().expect("pending repeated-node exit");
                            debug_assert!(matches!(exit, Frame::Exit(_)));
                            parser.state.rules.truncate(checkpoint.rule_depth);
                            *allowance -= work - 1;
                            self.work += work - 1;
                            self.raw_range = Some(raw);
                            self.result = true;
                            return;
                        }
                        cache.capture = Some(super::recognition::Capture::new(parser, rule, kind, self.storage.frames.len() - 1, checkpoint, self.work - 1));
                    }
                }
'''+s[end:];p.write_text(s)
replace(cont,'''                    if self.capture.as_ref().is_some_and(|capture| capture.depth == self.storage.frames.len()) {
                        let capture = self.capture.take().expect("completed lexical capture");
                        capture.complete(&mut self.storage.recognition, parser, self.result, self.work, self.raw_range);
                    }''','''                    if self.storage.prediction.as_ref().and_then(|state| state.memo.capture.as_ref()).is_some_and(|capture| capture.depth == self.storage.frames.len()) {
                        let cache = &mut self.storage.prediction.as_mut().expect("lexical cache owner").memo;
                        let capture = cache.capture.take().expect("completed lexical capture");
                        capture.complete(cache, parser, self.result, self.work, self.raw_range);
                    }''')
replace(cont,'                    if let Some(capture) = &mut self.capture { capture.raw(parser); }','                    if let Some(capture) = self.storage.prediction.as_mut().and_then(|state| state.memo.capture.as_mut()) { capture.raw(parser); }')
replace(rec,'    slots: Vec<Option<Entry>>,','    slots: Vec<Option<Entry>>,\n    pub(super) capture: Option<Capture>,')
storage='''
// Retain prediction and recognition state behind the existing storage pointer.
// Active continuations and the outer parser frame enums keep their old sizes.
pub(in super::super) struct Storage {
    plans: [Option<super::super::prediction::Plan>; super::NON_FIXED_RULES.len()],
    pub(super) memo: Cache,
}
impl Default for Storage {
    fn default() -> Self { Self { plans: [None; super::NON_FIXED_RULES.len()], memo: Cache::default() } }
}
impl core::ops::Deref for Storage {
    type Target = [Option<super::super::prediction::Plan>; super::NON_FIXED_RULES.len()];
    fn deref(&self) -> &Self::Target { &self.plans }
}
impl core::ops::DerefMut for Storage {
    fn deref_mut(&mut self) -> &mut Self::Target { &mut self.plans }
}
'''
replace(rec,'#[derive(Default)]\npub(super) struct Cache',storage+'\n#[derive(Default)]\npub(super) struct Cache')
p=root/'candidate/document'/rec;s=p.read_text();start=s.index('        let marker = p.start();');end=s.index('        p.state.fuel -= entry.charges;',start);s=s[:start]+(root/'batch-replay.rs').read_text()+s[end:];p.write_text(s)
replace(rec,'        p.state.base_storage.recognition.disabled=disabled;','        p.state.base_storage.prediction.get_or_insert_with(|| alloc::boxed::Box::new(Storage::default())).memo.disabled=disabled;')
replace(rec,'        let hits=p.state.base_storage.recognition.hits;','        let hits=p.state.base_storage.prediction.as_ref().map_or(0,|state|state.memo.hits);')
pred=Path('parser/canonical/prediction.rs')
replace(pred,'cache: &mut Option<alloc::boxed::Box<[Option<Plan>; base::NON_FIXED_RULES.len()]>>,','cache: &mut Option<alloc::boxed::Box<base::recognition::Storage>>,')
replace(pred,'cache.get_or_insert_with(|| alloc::boxed::Box::new([None; base::NON_FIXED_RULES.len()]));','cache.get_or_insert_with(|| alloc::boxed::Box::new(base::recognition::Storage::default()));')
journal=Path('parser/journal.rs')
replace(journal,'    pub(crate) fn truncate(&mut self, len: usize) {',(root/'journal-extend.rs').read_text()+'\n    pub(crate) fn truncate(&mut self, len: usize) {')
replace(journal,'    #[test]\n    fn retained_pages_survive_mutations_and_rewinds_at_every_page_boundary() {',(root/'journal-extend-test.rs').read_text()+'\n    #[test]\n    fn retained_pages_survive_mutations_and_rewinds_at_every_page_boundary() {')
patch='';pins=[]
for rel in [Path('parser/canonical/base/mod.rs'),cont,rec,pred,journal]:
 before=root/'reference/document'/rel;after=root/'candidate/document'/rel;b=before.read_text()if before.exists()else''
 patch+=''.join(difflib.unified_diff(b.splitlines(keepends=True),after.read_text().splitlines(keepends=True),fromfile='a/src/syntax/src/document/'+str(rel)if before.exists()else'/dev/null',tofile='b/src/syntax/src/document/'+str(rel)))
 pins.append(dict(path=str(rel),reference_sha256=hashlib.sha256(before.read_bytes()).hexdigest()if before.exists()else None,candidate_sha256=hashlib.sha256(after.read_bytes()).hexdigest()))
(root/'candidate.patch').write_text(patch);state=json.loads((old/'source-state.json').read_text());state.update(patch_sha256=hashlib.sha256(patch.encode()).hexdigest(),files=pins,scope='Bounded flat lexical recognition cache with state behind the existing prediction storage pointer and batched exact Start/Token/Finish journal appends. Same old grammar/cold path, fresh node identity and original materialization queue, exact logical fuel/work/rewinds/peaks, conservative resource admission. No continuation-size growth, source/native setting or grammar changes. Previous two variants remain separately measured and unchanged. No production edits.');(root/'source-state.json').write_text(json.dumps(state,indent=2)+'\n')
recipe=json.loads((root/'recipe.json').read_text());env=dict(os.environ,CARGO_MANIFEST_DIR=str(repo/'src/syntax'));records=[]
def run(n,command):
 start=time.monotonic()
 with(root/(n+'.stdout')).open('wb')as out,(root/(n+'.stderr')).open('wb')as err:r=subprocess.run(command,env=env,stdout=out,stderr=err)
 row=dict(stage=n,command=command,exit_code=r.returncode,seconds=time.monotonic()-start);records.append(row);(root/'pipeline.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True);assert r.returncode==0,(root/(n+'.stderr')).read_text()[-5500:]
for label in ['unit','reference','candidate']:(root/(label+'.rs')).write_text((old/(label+'.rs')).read_text().replace(str(old),str(root)))
run('unit-build',recipe['command_prefix']+['--crate-name','parser_lexical_reuse_batched_units','--test',str(root/'unit.rs'),'-o',str(root/'unit')]);run('unit-tests',[str(root/'unit'),'--test-threads=2'])
for v in ['reference','candidate']:run(v+'-build',recipe['command_prefix']+['--crate-name','parser_lexical_reuse_batched_'+v,str(root/(v+'.rs')),'-o',str(root/(v+'-probe'))])
