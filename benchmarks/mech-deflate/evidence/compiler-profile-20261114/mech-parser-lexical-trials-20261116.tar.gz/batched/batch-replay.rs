        let start = p.state.events.len();
        let identity = p.ids.node();
        let node = core::iter::once(Event::Start {
            identity: Some(identity), cached: None, kind: entry.kind, flags: NodeFlags::NONE,
        });
        let tokens = entry.tokens.iter().enumerate().map(|(index, &kind)| {
            let at = key.start + TextSize(index as u32);
            Event::Token { kind, range: TextRange::new(at, at + TextSize(1)), flags: TokenFlags::NONE }
        });
        p.state.events.extend(node.chain(tokens).chain(core::iter::once(Event::Finish)));
        p.state.covered_end = p.state.covered_end.max(entry.end);
        let range = p.cursor.bump_bytes((entry.end - key.start).0);
        debug_assert_eq!(range, Some(TextRange::new(key.start, entry.end)));
        p.state.tree_cache.enqueue(&p.state.events, start, key.start, identity);
