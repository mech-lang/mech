from pathlib import Path
import difflib,hashlib,json,os,shutil,subprocess,time
repo=Path.cwd();root=Path('/private/tmp/mech-parser-lexical-reuse-batched-20261115');first=root/'first-build';first.mkdir(exist_ok=False)
for n in ['candidate.patch','source-state.json','pipeline.json','unit-build.stdout','unit-build.stderr']:shutil.copy2(root/n,first/n)
shutil.copy2('/private/tmp/mech-parser-lexical-reuse-batched-20261115.stderr.log',first/'setup.stderr.log');shutil.copy2(__file__,root/'fix-build.py')
p=root/'candidate/document/parser/canonical/base/continuation.rs';s=p.read_text();before='    prediction: Option<Box<super::recognition::Storage>>';assert s.count(before)==1;p.write_text(s.replace(before,'    pub(super) prediction: Option<Box<super::recognition::Storage>>'))
(root/'setup-repair.json').write_text(json.dumps(dict(failure='New sibling-module tests accessed the private prediction storage field.',repair='Make the existing field visible to the containing base module only; unchanged layout and no public API change.',initial_unit_build_exit_code=1,initial_tests_or_timings_ran=False),indent=2)+'\n')
patch='';pins=[]
for rel in ['parser/canonical/base/mod.rs','parser/canonical/base/continuation.rs','parser/canonical/base/recognition.rs','parser/canonical/prediction.rs','parser/journal.rs']:
 before=root/'reference/document'/rel;after=root/'candidate/document'/rel;b=before.read_text()if before.exists()else''
 patch+=''.join(difflib.unified_diff(b.splitlines(keepends=True),after.read_text().splitlines(keepends=True),fromfile='a/src/syntax/src/document/'+rel if before.exists()else'/dev/null',tofile='b/src/syntax/src/document/'+rel));pins.append(dict(path=rel,reference_sha256=hashlib.sha256(before.read_bytes()).hexdigest()if before.exists()else None,candidate_sha256=hashlib.sha256(after.read_bytes()).hexdigest()))
(root/'candidate.patch').write_text(patch);state=json.loads((root/'source-state.json').read_text());state.update(patch_sha256=hashlib.sha256(patch.encode()).hexdigest(),files=pins);(root/'source-state.json').write_text(json.dumps(state,indent=2)+'\n')
recipe=json.loads((root/'recipe.json').read_text());env=dict(os.environ,CARGO_MANIFEST_DIR=str(repo/'src/syntax'));records=[]
def run(n,command):
 start=time.monotonic()
 with(root/(n+'.stdout')).open('wb')as out,(root/(n+'.stderr')).open('wb')as err:r=subprocess.run(command,env=env,stdout=out,stderr=err)
 row=dict(stage=n,command=command,exit_code=r.returncode,seconds=time.monotonic()-start);records.append(row);(root/'pipeline.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True);assert r.returncode==0,(root/(n+'.stderr')).read_text()[-5500:]
run('unit-build',recipe['command_prefix']+['--crate-name','parser_lexical_reuse_batched_units','--test',str(root/'unit.rs'),'-o',str(root/'unit')]);run('unit-tests',[str(root/'unit'),'--test-threads=2'])
for v in ['reference','candidate']:run(v+'-build',recipe['command_prefix']+['--crate-name','parser_lexical_reuse_batched_'+v,str(root/(v+'.rs')),'-o',str(root/(v+'-probe'))])
