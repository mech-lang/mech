from pathlib import Path

packet=Path('/private/tmp/mech-ssa-batch-seal-packet-20261114')
old=Path('/private/tmp/mech-index-facts-packet-20261114/replay.py').read_text()
body=old[old.index('stage_fields='):old.index('qualification=validate_cohort(')]
body=body.replace("['parse','frontend','native']","['parse','catalog','frontend','artifact','encode','native']").replace('==20787570','==20798230').replace('==1241393','==1242559')
old=Path('/private/tmp/mech-ssa-span-trials-packet-20261114/replay.py').read_text()
apply=old[old.index('def apply_source_patch('):old.index('base_source=')]
prefix='''from pathlib import Path
import json,hashlib,re,statistics,tomllib
root=Path(__file__).resolve().parent;raw=root/'compiler'
read=lambda p:json.loads(p.read_text())
def pin(p):
 data=p.read_bytes();return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
state=read(root/'source-state.json');assert not state['production_changes_retained'] and state['production_source_restored'] and state['control_production_source_identical_to_base']
prior=read(root/'validation/qualified-point-liveness.json');receipt=read(root/'validation/qualified-point-liveness.archive.json');assert pin(root/'validation/qualified-point-liveness.json')['sha256']==receipt['replay_sha256'];expected=prior['output_hashes']
excluded={r['path']:r for r in read(root/'excluded-build-products.json')}
'''
end='''
base=(root/'source/vendor/cranelift-frontend/src/ssa.rs').read_text();candidate=(raw/'source-candidate.rs').read_text();build=read(raw/'candidate-build.json');control=read(raw/'control-origin.json');flags=read(raw/'runtime-flags.json')
assert build['head']==control['base_commit']==state['base_commit']==state['retained_source_commit'];assert control['source_commit']==state['control_source_commit']==prior['source_commit']
assert control['sha256']==prior['compiler_binary_sha256']['candidate']==excluded['compiler/control']['sha256'];assert build['binary_sha256']==excluded['compiler/candidate']['sha256'] and build['exit_code']==0
assert pin(raw/'candidate.patch')['sha256']==build['patch_sha256']==state['candidate_patch_sha256'];assert pin(raw/'candidate.patch')==pin(raw/'tested-source.patch');assert apply_source_patch(base,(raw/'candidate.patch').read_text())==candidate
assert (raw/'probes/ssa-before.rs').read_text()==base
assert len(flags)==61 and flags['MECH_COMPACT_REUSE_OVERWRITTEN_RESULT']=='1';assert expected==read(raw/'reference-pins.json')
for name,pinned in expected.items():assert pin(raw/'reference'/name)==pinned
tests=read(raw/'probes/build.json');assert tests['patch_sha256']==build['patch_sha256'] and tests['head']==state['base_commit'] and tests['exit_code']==read(raw/'probes/tests.json')['exit_code']==0
assert 'test result: ok. 15 passed; 0 failed;' in (raw/'probes/tests.stdout').read_text()
deps=read(raw/'probes/dependencies.json')
for name,info in deps.items():
 assert info['sha256']==tests['dependencies'][name]['sha256']==excluded['compiler/probes/pinned-deps/'+Path(info['pinned_path']).name]['sha256']
ir=read(raw/'probes/ir-result.json');assert ir['cases']==88 and ir['verified_functions']==176 and ir['identical_ir_aliases_query_values_side_effects_and_enumerations']
assert read(raw/'probes/ir-build.json')['exit_code']==read(raw/'probes/ir-run.json')['exit_code']==0 and read(raw/'probes/ir-build.json')['dependencies']==deps
data=(raw/'probes/ir-comparison.jsonl').read_bytes();assert len(data)==ir['bytes'] and hashlib.sha256(data).hexdigest()==ir['sha256'];cases=[json.loads(line) for line in data.splitlines()];assert len(cases)==88 and all(c['identical'] for c in cases)
qualification=validate_cohort(raw,flags,expected,{'control':control['sha256'],'candidate':build['binary_sha256']},'matches_current_control_output')
q=qualification['qualified'];assert q['source_cfg_seconds']['mean_reduction_fraction']<0 and q['compiler_seconds']['mean_reduction_fraction']<0 and all(b['compiler_mean_reduction_fraction']<0 for b in qualification['blocks'])
decision=read(raw/'decision.json');assert not decision['retain'] and decision['production_source_restored'] and decision['restored_base_commit']==state['base_commit'] and decision['restored_source_sha256']==hashlib.sha256(base.encode()).hexdigest()
for key,field in [('source_cfg_change_percent','source_cfg_seconds'),('compiler_change_percent','compiler_seconds'),('instructions_change_percent','instructions'),('whole_process_change_percent','whole_process_seconds'),('max_rss_change_percent','max_rss_bytes')]:assert decision[key]==-100*q[field]['mean_reduction_fraction']
parallelism=read(raw/'build-parallelism.json');assert parallelism['completed_candidate_cargo_jobs']==2 and parallelism['subsequent_cargo_jobs']==4 and parallelism['logical_cpus']==8 and parallelism['memory_bytes']==17179869184 and parallelism['completed_candidate_build_seconds']==build['seconds']
assert '-j2' in build['command'] and "'-j4'" in (root/'mech-build-ssa-batch-seal-20261114.py').read_text()
profiles={name:tomllib.loads((root/'source'/name).read_text())['profile']['compiler'] for name in ['Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.toml']}
for value in profiles.values():assert value['lto']=='thin' and value['codegen-units']==1
summary=dict(source_commit=state['base_commit'],control_source_commit=state['control_source_commit'],hardware=state['hardware'],candidate_patch_sha256=build['patch_sha256'],candidate_rebuild_seconds=build['seconds'],production_changes_retained=False,decision=decision,focused_ssa_tests_passed=15,ir_comparison=ir,build_parallelism=parallelism,profile_settings=profiles,scope=[
 'One eight-observation serial ABBA/BAAB complete source-to-Object cohort using the current 61 runtime flags. Screens remain separately recorded. No historical 60-flag timings are pooled.',
 'All source, canonical bytecode, Object and complete metadata bytes match in both screens, all eight observations and fourteen successful fixture pairs. Fifteen focused SSA tests and 88 paired complete IR/alias/query/enumeration comparisons pass; 176 generated IR functions are independently verified.',
 'Source CFG construction is slower, both balanced compiler-time blocks are slower, and retired instructions are effectively unchanged. No useful compiler-work saving is established. Every adverse phase and memory observation remains; one candidate RSS observation is higher than its other three observations. No causal memory explanation is established.',
 'The candidate batches independent known trivial block parameters, retaining sentinel allocation and the original fallback for unknown, nontrivial or dependent merges. It is rejected and production source is restored exactly. Grammar, language, shape/factory/visit/ownership checks, direct scalar code generation, checked errors, finite admission and runtime accounting remain.',
 'Builds, tests, IR probes, fixtures, hashing, copying and archive work do not overlap primary measurements. The warm-cache Rust compiler rebuild takes 275.189 seconds with two Cargo jobs and is excluded from Mech compilation; no cold-bootstrap or matched build comparison is claimed.',
 'Four Cargo jobs are selected for later Rust rebuilds on this eight-core, 16 GB host. There is no measured four-job build or speedup. The rebuilt crates form a dependency chain. Thin LTO and one codegen unit remain; changing Rust codegen partitioning would need new compiler and program-performance qualification.',
 'Compiler/probe executables and copied dependency libraries are excluded and hash-pinned. Pure offline replay reconstructs the trial source from its base and patch, validates every retained output and recomputes the numerical summary; it does not rerun timings or a new compressor-runtime latency campaign.',
 'The retained point-liveness compiler remains current. Full level-12 compilation remains above ten seconds; separate function compilation is an architectural parallelism boundary to assess, not an implemented or measured speedup.'
],**qualification)
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
'''
(packet/'replay.py').write_text(prefix+body+apply+end)
print(packet/'replay.py')
