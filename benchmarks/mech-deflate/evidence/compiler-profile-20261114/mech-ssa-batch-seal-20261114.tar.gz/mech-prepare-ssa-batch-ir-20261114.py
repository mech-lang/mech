from pathlib import Path
root=Path('/private/tmp/mech-ssa-batch-seal-20261114');p=root/'probes';old=Path('/private/tmp/mech-ssa-span-compact-20261114/probes/ir-comparison.rs').read_text();prefix=old[:old.index('fn observe')].replace('/private/tmp/mech-ssa-span-compact-20261114','/private/tmp/mech-ssa-batch-seal-20261114');prefix=prefix.replace('fn get(&mut self,func:&mut Function,var:Variable,block:Block)','fn get(&mut self,func:&mut Function,var:Variable,ty:ir::Type,block:Block)').replace('fn get(&mut self,f:&mut Function,v:Variable,b:Block)','fn get(&mut self,f:&mut Function,v:Variable,t:ir::Type,b:Block)').replace('self.use_var(f,v,I64,b)','self.use_var(f,v,t,b)')
observe=old[old.index('fn observe'):old.index('fn main')]
for a,b in [('b.get(&mut f,var,blocks[i])','b.get(&mut f,var,I64,blocks[i])'),('b.get(&mut f,vars[0],blocks[n])','b.get(&mut f,vars[0],I64,blocks[n])'),('b.get(&mut f,var,block)','b.get(&mut f,var,I64,block)')]:observe=observe.replace(a,b)
observe=observe[:observe.index(' let flags=')]+''' snapshot(f,&b,&vars,queries,effects)
}
'''
extra=r'''
fn snapshot<B:Builder>(f:Function,b:&B,vars:&[Variable],queries:Vec<u32>,effects:Vec<Vec<u32>>)->serde_json::Value {
 let flags=cranelift_codegen::settings::Flags::new(cranelift_codegen::settings::builder());cranelift_codegen::verify_function(&f,&flags).unwrap();
 let aliases=(0..f.dfg.num_values()).map(|i|{let v=Value::new(i);(v.as_u32(),f.dfg.value_alias_dest_for_serialization(v).map(|v|v.as_u32()),f.dfg.resolve_aliases(v).as_u32(),f.dfg.value_type(v).to_string(),format!("{:?}",f.dfg.value_def(v)))}).collect::<Vec<_>>();
 let enumerations=vars.iter().map(|&v|b.values(v).iter().map(|v|v.as_u32()).collect::<Vec<_>>()).collect::<Vec<_>>();
 serde_json::json!({"ir":f.display().to_string(),"aliases_immediate_and_resolved_types_and_definitions":aliases,"queries":queries,"effects":effects,"enumerations":enumerations})
}
fn constant(c:&mut FuncCursor<'_>,ty:ir::Type,value:i64)->Value {
 if ty==ir::types::F64 {c.ins().f64const(ir::immediates::Ieee64::with_float(value as f64))}
 else if ty==ir::types::F32 {c.ins().f32const(ir::immediates::Ieee32::with_float(value as f32))}
 else {c.ins().iconst(ty,value)}
}
fn batch<B:Builder>(offset:usize,n:usize,mode:usize,reverse:bool,manual:bool,mixed:bool)->serde_json::Value {
 let mut f=Function::new();f.signature.returns.push(ir::AbiParam::new(I64));for _ in 0..offset {f.dfg.make_block();}
 let blocks=(0..4).map(|_|f.dfg.make_block()).collect::<Vec<_>>();let [entry,a,b,join]=blocks.as_slice()else{unreachable!()};let(entry,a,b,join)=(*entry,*a,*b,*join);
 let target=if mode==0{join}else{a};let manual_value=manual.then(||f.dfg.append_block_param(target,I64));
 let vars=(0..n).map(Variable::new).collect::<Vec<_>>();let types=(0..n).map(|i|if mixed {[I64,ir::types::I32,ir::types::F64,ir::types::F32][i%4]}else{I64}).collect::<Vec<_>>();
 let mut builder=B::default();for &block in &blocks {f.layout.append_block(block);builder.declare(block);}
 let mut queries=Vec::new();let mut effects=Vec::new();let mut initial=Vec::new();
 {
  let mut c=FuncCursor::new(&mut f).at_bottom(entry);
  for i in 0..n {let v=constant(&mut c,types[i],i as i64+1);builder.def(vars[i],v,entry);initial.push(v);}
  if mode==0 {let cond=c.ins().iconst(ir::types::I8,1);let branch=c.ins().brif(cond,a,&[],b,&[]);builder.pred(a,branch);builder.pred(b,branch);}
  else if mode==1 {let args=manual_value.map(|_|vec![initial[0].into()]).unwrap_or_default();let branch=c.ins().jump(a,&args);builder.pred(a,branch);}
  else {c.ins().return_(&[initial[0]]);}
 }
 if mode==0 {
  for block in [a,b] {
   let mut c=FuncCursor::new(&mut f).at_bottom(block);
   for i in 0..n {let v=if block==b && i%64==31 {constant(&mut c,types[i],1000+i as i64)}else{initial[i]};builder.def(vars[i],v,block);}
   let args=manual_value.map(|_|vec![initial[0].into()]).unwrap_or_default();let branch=c.ins().jump(join,&args);builder.pred(join,branch);
  }
  let mut order=(0..n).collect::<Vec<_>>();if reverse{order.reverse();}let mut last=initial[0];
  for i in order {let(v,e)=builder.get(&mut f,vars[i],types[i],join);queries.push(v.as_u32());effects.push(e.iter().map(|v|v.as_u32()).collect());if i==0{last=v;}}
  let mut c=FuncCursor::new(&mut f).at_bottom(join);let result=if let Some(manual)=manual_value{c.ins().iadd(manual,last)}else{last};c.ins().return_(&[result]);
 } else {
  let mut header=Vec::new();for i in 0..n {let(v,e)=builder.get(&mut f,vars[i],I64,a);queries.push(v.as_u32());effects.push(e.iter().map(|v|v.as_u32()).collect());header.push(v);}
  let local={let mut c=FuncCursor::new(&mut f).at_bottom(a);let local=c.ins().iconst(I64,0);let cond=c.ins().iconst(ir::types::I8,1);let branch=c.ins().brif(cond,b,&[],join,&[]);builder.pred(b,branch);builder.pred(join,branch);local};
  {
   let mut c=FuncCursor::new(&mut f).at_bottom(b);
   for i in 0..n {let value=match i%11 {0=>header[(i+1)%n],1=>header[i],2=>header[i-1],3 if manual=>manual_value.unwrap(),_=>if mode==2{local}else{initial[i]}};builder.def(vars[i],value,b);}
   let args=manual_value.map(|_|vec![(if mode==2{local}else{initial[0]}).into()]).unwrap_or_default();let branch=c.ins().jump(a,&args);builder.pred(a,branch);
  }
  FuncCursor::new(&mut f).at_bottom(join).ins().return_(&[header[0]]);
 }
 let mut order=blocks.clone();if reverse{order.reverse();}for block in order {effects.push(builder.seal(block,&mut f).iter().map(|v|v.as_u32()).collect());}
 for &block in &blocks {for i in 0..n {let(v,e)=builder.get(&mut f,vars[i],types[i],block);queries.push(v.as_u32());effects.push(e.iter().map(|v|v.as_u32()).collect());}}
 snapshot(f,&builder,&vars,queries,effects)
}
fn main(){
 for offset in [0,4096,100000] {for n in [65,257] {for looped in [false,true] {for reverse in [false,true] {
  let old=observe::<reference::SSABuilder>(offset,n,looped,reverse);let new=observe::<ssa::SSABuilder>(offset,n,looped,reverse);assert_eq!(old,new,"chain offset={offset} n={n} looped={looped} reverse={reverse}");
  println!("{}",serde_json::json!({"case":"chain","offset":offset,"blocks":n,"looped":looped,"reverse_sealing":reverse,"identical":true,"observation":new}));
 }}}}
 for offset in [0,100000] {for n in [64,257] {for mode in 0..3 {for reverse in [false,true] {for manual in [false,true] {for mixed in [false,true] {
  if mode!=0 && mixed {continue;}
  let old=batch::<reference::SSABuilder>(offset,n,mode,reverse,manual,mixed);let new=batch::<ssa::SSABuilder>(offset,n,mode,reverse,manual,mixed);assert_eq!(old,new,"batch offset={offset} n={n} mode={mode} reverse={reverse} manual={manual} mixed={mixed}");
  println!("{}",serde_json::json!({"case":"batch","offset":offset,"variables":n,"mode":mode,"reverse_sealing":reverse,"manual_parameter":manual,"mixed_types":mixed,"identical":true,"observation":new}));
 }}}}}}
}
'''
(p/'ir-comparison.rs').write_text(prefix+observe+extra)
