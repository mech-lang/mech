from pathlib import Path
import json,subprocess,hashlib,time
root=Path('/private/tmp/mech-ssa-batch-seal-20261114');p=root/'probes'
cmd=['rustc','--edition=2024','--crate-name','ssa_batch_seal_ir_comparison','-C','opt-level=3','-C','lto=thin','-D','warnings','-L','dependency=/private/tmp/mech-level12-compile-target/compiler/deps','--cfg','feature="std"'];deps=json.loads((p/'dependencies.json').read_text())
for name,info in deps.items():
 path=info['pinned_path'];assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==info['sha256'];cmd+=['--extern',name+'='+path]
cmd+=[str(p/'ir-comparison.rs'),'-o',str(p/'bin/ir-comparison')];start=time.perf_counter();r=subprocess.run(cmd,capture_output=True);(p/'ir-build.stdout').write_bytes(r.stdout);(p/'ir-build.stderr').write_bytes(r.stderr);(p/'ir-build.json').write_text(json.dumps({'command':cmd,'dependencies':deps,'exit_code':r.returncode,'seconds':time.perf_counter()-start},indent=2)+'\n');print('BUILD',r.returncode,flush=True)
if r.returncode:print(r.stderr.decode());raise SystemExit(r.returncode)
cmd=[str(p/'bin/ir-comparison')];start=time.perf_counter()
with (p/'ir-comparison.jsonl').open('wb') as out,(p/'ir-comparison.stderr').open('wb') as err:r=subprocess.run(cmd,stdout=out,stderr=err)
(p/'ir-run.json').write_text(json.dumps({'command':cmd,'exit_code':r.returncode,'seconds':time.perf_counter()-start},indent=2)+'\n');print('RUN',r.returncode,flush=True)
if r.returncode:print((p/'ir-comparison.stderr').read_text()[-8000:]);raise SystemExit(r.returncode)
data=(p/'ir-comparison.jsonl').read_bytes();cases=[json.loads(x) for x in data.splitlines()];assert len(cases)==88 and all(c['identical'] for c in cases)
result={'cases':len(cases),'verified_functions':2*len(cases),'identical_ir_aliases_query_values_side_effects_and_enumerations':True,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'scope':'Both exact old/new builder implementations build the same original control-flow graphs with low/high block IDs, diamonds, dependent and unreachable loops, manual parameters, integer/floating types and forward/reverse sealing. Each full function is independently verified; complete IR, raw alias mappings, query results, side effects and values-for-var order compare exactly.'};(p/'ir-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
