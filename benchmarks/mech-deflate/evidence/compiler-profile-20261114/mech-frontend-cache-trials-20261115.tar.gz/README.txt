Two independent frontend-cache trials, frozen f6cde and current Deflate/runtime.
Both use the qualified AE/source972 control, 61 flags plus two workers and the
standard compiler profile without PGO or native-CPU overrides.

The normalized-type cache improves frontend about 16 ms but makes the complete
compiler slower in both balanced blocks. Preserving the existing canonical
schema owner in annotation comparison saves about 58 ms in frontend work, but
complete executable builds are flat with mixed blocks (+0.13% mean). Both
changes are rejected; production source and the qualified AE tool are restored.

Each trial contains complete sources/patches, commands/logs, 15 or 28 focused
tests, fourteen fixture pairs, eight primary Object compiles and two cached
whole-executable gates. Annotation comparison also has eight complete source-
to-executable builds. All primary observations run serially, without concurrent
heavy builds, tests, sampling, hashing or archival. Fixed native adapter inputs
are cached; their first-use construction is excluded. Every program and gated
executable byte matches. Compiler/test executables and dependency libraries are
excluded and hash-pinned.

Historical source972 stack diagnostics support target selection only. The first
exploratory parser included the flat top-of-stack table; its initial result and
the corrected bounded recipe remain. No CPU-share or timing claim follows from
those call paths. Initial annotation test-count prose undercounted the existing
suite; unchanged stdout records 28 passes and the correction is recorded.

Pure offline replay applies both patches and reconstructs every mean, block and
byte gate. No grammar/language change, weaker fresh proof, scalar retirement or
new emitted-program runtime campaign is claimed. Complete compilation below ten
seconds remains open. The prepared default-serial gate was not needed or run
for these rejected changes.
