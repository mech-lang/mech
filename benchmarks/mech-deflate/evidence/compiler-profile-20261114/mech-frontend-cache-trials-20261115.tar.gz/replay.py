from pathlib import Path
import hashlib,importlib.util,json,re,statistics
packet=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_text());pins={}
def pin(path):
 if path not in pins:pins[path]=dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
 return pins[path]
def apply(source,patch):
 lines=source.splitlines(keepends=True);diff=patch.splitlines(keepends=True);result=[];position=0;i=0
 while i<len(diff):
  match=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',diff[i])
  if not match:i+=1;continue
  start=int(match[1])-1;assert start>=position;result.extend(lines[position:start]);position=start;i+=1
  while i<len(diff) and not diff[i].startswith('@@'):
   line=diff[i]
   if line.startswith(' '):assert lines[position]==line[1:];result.append(lines[position]);position+=1
   elif line.startswith('-'):assert lines[position]==line[1:];position+=1
   elif line.startswith('+'):result.append(line[1:])
   else:raise AssertionError(line)
   i+=1
 result.extend(lines[position:]);return ''.join(result)
state=read(packet/'source-state.json');prior=read(packet/'validation/prior-qualified.json')
assert pin(packet/'validation/prior-qualified.json')['sha256']==read(packet/'validation/prior-qualified.archive.json')['replay_sha256']
expected=prior['output_hashes'];qualified_binary=prior['compiler_binary_sha256']['candidate'];products={r['path']:r for r in read(packet/'excluded-compiler-products.json')}
for row in read(packet/'source-config-pins.json'):assert pin(packet/'source-config'/row['path'])=={k:row[k] for k in ['bytes','sha256']}
inputs=read(packet/'native-link-inputs.json')
for row in inputs:assert pin(packet/row['path'])=={k:row[k] for k in ['bytes','sha256']}
executable_pin=dict(bytes=2060440,sha256='d6c65cc3fb18acc4be77dce329962105bf0f2b56dd2623a12f466256463eca61')
trials=[]
for label in ['resolved-types','owned-annotation']:
 root=packet/label;raw=read(root/'source-state.json');trial_state=state['trials'][label];decision=read(root/'decision.json')
 assert raw['base_commit']==trial_state['source_base']=='f6cdecef644a7eb9e2091b685542b2ae5e405da8'
 assert pin(root/'candidate.patch')['sha256']==raw['patch_sha256']
 parts=[p for p in re.split(r'(?=^diff --git )',(root/'candidate.patch').read_text(),flags=re.M) if p]
 assert len(parts)==len(raw['files'])
 for row in raw['files']:
  name=row['path'];old=(root/'before'/name).read_text();new=(root/'candidate-source'/name).read_text()
  assert pin(root/'before'/name)['sha256']==row['before_sha256'] and pin(root/'candidate-source'/name)['sha256']==row['after_sha256']
  assert old==(packet/'source-config'/name).read_text()
  changes=[part for part in parts if part.splitlines()[0]=='diff --git a/'+name+' b/'+name];assert len(changes)==1
  assert apply(old,changes[0])==new
 binaries={v:products[label+'/'+v]['sha256'] for v in ['control','candidate']};assert binaries['control']==qualified_binary
 flags=read(root/'runtime-flags.json');assert len(flags)==61;wanted=dict(flags,MECH_COMPACT_COMPILE_THREADS='2');assert read(root/'reference-pins.json')==expected
 build=read(root/'candidate-build.json');check=read(root/'candidate-check.json')
 for row in [build,check]:
  assert row['exit_code']==0 and row['base_commit']==raw['base_commit'] and row['patch_sha256']==raw['patch_sha256'] and row['CARGO_INCREMENTAL']=='0'
 assert build['binary_sha256']==binaries['candidate']
 pipeline=read(root/'qualification-pipeline.json');assert [r['stage'] for r in pipeline]==['screens','executable-gates','fixtures-object-cohort'] and all(r['state']=='complete' and r['exit_code']==0 for r in pipeline)
 tests=root/'focused';assert read(tests/'test.json')['exit_code']==read(tests/'build.json')['exit_code']==0
 assert read(tests/'build.json')['binary_sha256']==products[label+'/focused/tests']['sha256']
 count=15 if label=='resolved-types' else 28
 assert f'test result: ok. {count} passed; 0 failed' in (tests/'test.stdout.log').read_text()
 for row in read(tests/'command.json')['source_pins']:
  path=row['variant']+'.rs' if label=='resolved-types' else row['path'];folder='before' if row['variant']=='reference' else 'candidate-source'
  assert (tests/path).read_bytes()==(root/folder/row['source_path']).read_bytes() and pin(tests/path)['sha256']==row['sha256']
 if label=='owned-annotation':
  name='src/engine/src/source_semantics/pending_schema.rs';old=(root/'before'/name).read_text();new=(root/'candidate-source'/name).read_text();marker='#[cfg(test)]\nmod tests'
  assert old[:old.index(marker)]==new[:new.index(marker)]
  name='src/engine/src/source_semantics/annotation_shape_identity.rs';old=(root/'before'/name).read_text();new=(root/'candidate-source'/name).read_text();begin='    mech_core::schema_dimension_parameter_mapping(';end='\n#[cfg(test)]'
  assert old[old.index(begin):old.index(end)]==new[new.index(begin):new.index(end)]
 order=[('control','control-1'),('candidate','candidate-1'),('candidate','candidate-2'),('control','control-2'),('candidate','candidate-3'),('control','control-3'),('control','control-4'),('candidate','candidate-4')]
 rows=[];screens=[]
 for variant,name in [('control','control-screen'),('candidate','candidate-screen')]+order:
  d=root/name;command=read(root/(name+'-command.json'));process=read(d/'process.json');compile=read(d/'compile.json');checks=read(d/'output-check.json')
  assert command['flags']==wanted and not command['profiling_excluded_from_primary']
  assert command['binary_sha256']==binaries[variant]
  assert process['exit_code']==0 and process['samples']==0 and process['sampling_error'] is None
  assert process['elapsed_boundary']=='driver_start_to_process_wait_completion' and process['elapsed_seconds']>compile['total_seconds']
  for n,item in expected.items():assert pin(d/n)==item and checks[n]==dict(item,matches_current_control_output=True)
  row=dict(name=name,variant=variant,compile=compile,process=process,files=checks)
  if name.endswith('-screen'):screens.append(row);continue
  stamps=[json.loads(line) for line in (d/'stages.jsonl').read_text().splitlines()];elapsed=lambda prefix:next(s['elapsed'] for s in stamps if s['line'].startswith(prefix))
  for key,begin,end in [('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]:row[key]=elapsed(end)-elapsed(begin)
  log=(d/'stderr.log').read_text()
  for key,pattern in [('instructions',r'(\d+)  instructions retired'),('max_rss_bytes',r'(\d+)  maximum resident set size'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]:row[key]=int(re.search(pattern,log).group(1))
  row['compaction_seconds']=elapsed('compact-stage: CFG cleanup')-elapsed('compact-stage: compact values before=');row['cleanup_including_compaction_seconds']=row['cleanup_seconds']+row['compaction_seconds']
  for key,prefix in [('value_ids_before','compact-stage: compact values before='),('value_ids_after','compact-values: retained=')]:row[key]=int(next(s['line'] for s in stamps if s['line'].startswith(prefix)).split('=')[-1])
  assert (row['value_ids_before'],row['value_ids_after'])==tuple(trial_state['value_compaction'])
  rows.append(row)
 assert rows==read(root/'cohort.json')
 fields={'compiler_seconds':lambda r:r['compile']['total_seconds'],'whole_process_seconds':lambda r:r['process']['elapsed_seconds']}
 for phase in ['parse','catalog','frontend','artifact','encode','native']:fields[phase+'_seconds']=lambda r,p=phase:next(x['seconds'] for x in r['compile']['phases'] if x['phase']==p)
 for key in ['canonical_lowering_seconds','preparation_seconds','numeric_generation_seconds','source_cfg_seconds','cleanup_including_compaction_seconds','cleanup_seconds','compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:fields[key]=lambda r,k=key:r[k]
 numerical={}
 for key,fn in fields.items():
  x={v:[fn(r) for r in rows if r['variant']==v] for v in ['control','candidate']};x['mean_reduction_fraction']=1-statistics.mean(x['candidate'])/statistics.mean(x['control']);numerical[key]=x
 assert numerical==read(root/'numerical-summary.json')
 blocks=[]
 for subset in [rows[:4],rows[4:]]:
  block={}
  for key in fields:
   x={v:statistics.mean(fields[key](r) for r in subset if r['variant']==v) for v in ['control','candidate']};x['mean_reduction_fraction']=1-x['candidate']/x['control'];block[key]=x
  blocks.append(block)
 fixtures=read(root/'fixture-results.json');assert len(fixtures)==14
 for row in fixtures:
  name=row['fixture'].split(':')[-1] if ':' in row['fixture'] else Path(row['fixture']).stem
  assert pin(root/'fixture-inputs'/(name+'.mec'))['sha256']==row['source_sha256'] and row['all_outputs_match'] and row['variants']['control']==row['variants']['candidate']
  for variant in ['control','candidate']:
   d=root/'fixtures'/name/variant;command=read(d/'command.json');assert command['flags']==wanted and command['binary_sha256']==binaries[variant]
   assert row['variants'][variant]['exit_code']==0 and len(row['variants'][variant]['files'])==4
   for n,item in row['variants'][variant]['files'].items():assert pin(d/n)==item



 links=read(root/'final-executable-results.json');assert len(links)==2
 for variant,row in zip(['control','candidate'],links):
  directory=root/('link-'+variant);command=read(directory/'command.json')
  assert row['variant']==variant and row['exit_code']==0 and row['matches_complete_baseline_executable'] and not row['fresh_runtime_campaign']
  assert pin(directory/'worker')==executable_pin==dict(bytes=row['executable_bytes'],sha256=row['executable_sha256'])
  assert command['environment']=={'ZERO_AR_DATE':'1'}
  assert [(r['source'],r['bytes'],r['sha256']) for r in command['input_pins']]==[(r['source'],r['bytes'],r['sha256']) for r in inputs]
 native_summary=None
 if (root/'native-cohort.json').exists():
  native_order = [(v,'native-' + name) for v,name in order]
  native = read(root / 'native-cohort.json')
  assert [(r['variant'],r['name']) for r in native] == native_order
  for row in native:
      directory = root / row['name']
      actual = read(directory / 'result.json')
      assert actual == {k:v for k,v in row.items() if k != 'name'}
      assert row['primary_cohort'] and row['cached_adapter_objects'] and row['compiler_exit_code'] == row['link_exit_code'] == 0
      assert row['matches_complete_baseline_executable'] and pin(directory / 'worker') == executable_pin
      assert abs(row['source_to_executable_seconds'] - sum(row[k] for k in ['source_to_object_process_seconds','object_handoff_seconds','native_link_seconds'])) < 1e-8
      command = read(directory / 'command.json')
      assert command['flags'] == wanted and command['compiler_sha256'] == binaries[row['variant']] and command['ZERO_AR_DATE'] == '1'
      for filename, item in expected.items():
          assert pin(directory / filename) == item and row['files'][filename] == dict(item, matches_frozen_reference=True)
  native_summary = read(root / 'native-numerical-summary.json')
  native_numerical = {}
  for key in ['source_to_executable_seconds','source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']:
      values = {v:[r[key] for r in native if r['variant'] == v] for v in ['control','candidate']}
      values['mean_reduction_fraction'] = 1-statistics.mean(values['candidate'])/statistics.mean(values['control'])
      native_numerical[key] = values
  native_blocks = []
  for rows in [native[:4],native[4:]]:
      means = {v:statistics.mean(r['source_to_executable_seconds'] for r in rows if r['variant'] == v) for v in ['control','candidate']}
      means['mean_reduction_fraction'] = 1-means['candidate']/means['control']
      if decision['decision']=='retain':assert means['mean_reduction_fraction'] > 0
      native_blocks.append(means)
  assert native_summary['numerical_summary'] == native_numerical and native_summary['balanced_blocks'] == native_blocks
  assert native_summary['order'] == [list(r) for r in native_order]

 commit=None;serial=None
 if decision['decision']=='retain':
  assert label=='owned-annotation' and native_summary is not None
  commit=read(root/'source-commit.json');assert commit['full_commit_diff_matches_measured_patch'] and commit['full_commit_diff_sha256']==raw['patch_sha256'] and sorted(commit['files'])==sorted(r['path'] for r in raw['files'])
  assert commit['parent']==raw['base_commit'] and commit['commit']==state['source_revision']
  serial=root/'serial-output-gate';serial_row=read(serial/'result.json');assert serial_row['exit_code']==0 and serial_row['compile_threads']==0 and serial_row['compiler_sha256']==binaries['candidate'] and serial_row['matches_complete_baseline_executable']
  assert pin(serial/'worker')==executable_pin
  for name,item in expected.items():assert pin(serial/name)==item and serial_row['files'][name]==dict(item,matches_frozen_reference=True)
  serial=serial_row
 else:assert decision['production_source_restored'] and decision['canonical_tool_sha256']==qualified_binary
 trials.append(dict(label=label,source_base=raw['base_commit'],source_commit=commit,patch_sha256=raw['patch_sha256'],decision=decision,compiler_binary_sha256=binaries,build=build,check=check,focused_test_count=count,focused_test=read(tests/'test.json'),fixture_pairs=14,numerical_summary=numerical,balanced_blocks=blocks,preliminary_screens=screens,final_links=links,native_cohort=native_summary,default_serial_gate=serial))
selection_pins=read(packet/'profile-selection-pins.json')
assert selection_pins['source_archive_sha256']==read(packet/'validation/prior-qualified.archive.json')['sha256']
assert selection_pins['source_revision']==prior['source_revision']
for item in selection_pins['files']:assert pin(packet/item['path'])=={key:item[key] for key in ['bytes','sha256']}
selection=packet/'selection-profiles';spec=importlib.util.spec_from_file_location('frontend_profile_paths',packet/'mech-profile-paths-frontend-cache-20261115.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
assert module.extract(selection)==read(packet/'resolved-types/profile-target-paths.json')
assert module.extract(selection,False)==read(packet/'resolved-types/profile-analysis-first-attempt/profile-target-paths.json')
summary=dict(source_revision=state['source_revision'],program_flags_count=61,common_compile_threads=2,output_hashes=expected,final_executable=executable_pin,trials=trials,profile_selection='Two historical scoped-source stack diagnostics bound to call-graph section; first exploratory parser included flat table, preserved and reconstructed. Call paths are descriptive, never CPU shares or measured savings.',scope=[
 'Two independent frontend-cache trials against the same retained scoped-source compiler AE and current Deflate/runtime, frozenf6cde. Normalized-type cache is rejected:frontend about16ms faster/instructions lower, but compiler/process slower inbothblocks andRSS higher. It is absent from the annotation-owner candidate.',
 'Annotation equivalence retains existing exact pending owner and its pure canonical schema cache; no new cache or validation bypass. Both lazy canonicalization demands, errors, fresh dimension relation mapping and downstream conversion checks retain order. Core canonicalization and production PendingSchema implementation are unchanged; tests check cache use, both demands, error/repair and mutation invalidation.',
 'Each trial has15or28exact copied-module tests,14paired fixtures,eight serial source-to-Object compiles inABBA/BAAB order andtwo cached complete-executable gates. Additional complete source-to-executable cohort/default0 gate exists only as explicitly recorded. No heavy build/test/profile/hash/archive overlaps primary timing; fixed current adapter inputs are cached and its first-use construction excluded.',
 'Every source/bytecode/Object/complete metadata and gated whole executable byte matches. All raw observations and adverse counters remain. Compiler/test executables and dependency libraries are excluded and hash-pinned. Pure replay applies patches and reconstructs summaries/blocks/byte gates without a compiler or new timing. No grammar/language change, weaker fresh proof, scalar retirement or new program-runtime campaign is claimed. Complete compilation below ten seconds remains open.'
])
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';saved=packet/'summary.json'
if saved.exists():assert saved.read_text()==encoded
else:saved.write_text(encoded)
print(encoded,end='')
