from pathlib import Path
import hashlib,json,shutil,subprocess
repo=Path.cwd();packet=Path('/private/tmp/mech-frontend-cache-packet-20261115');packet.mkdir(exist_ok=False)
roots={'resolved-types':Path('/private/tmp/mech-pending-resolved-types-20261115'),'owned-annotation':Path('/private/tmp/mech-owned-annotation-identity-20261115')}
pin=lambda path:dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
state=dict(source_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),trials={});excluded=[]
for label,root in roots.items():
 raw=json.loads((root/'source-state.json').read_text());decision=json.loads((root/'decision.json').read_text());rows=json.loads((root/'cohort.json').read_text());state['trials'][label]=dict(source_base=raw['base_commit'],decision=decision['decision'],value_compaction=[rows[0]['value_ids_before'],rows[0]['value_ids_after']])
 for path in sorted(root.rglob('*')):
  if not path.is_file():continue
  rel=path.relative_to(root)
  if rel.as_posix() in ['control','candidate','focused/tests']:
   excluded.append(dict(path=label+'/'+rel.as_posix(),**pin(path)));continue
  dest=packet/label/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,dest)
 for row in json.loads((root/'fixture-results.json').read_text()):
  if row['fixture'].startswith('hosts/'):
   dest=packet/label/'fixture-inputs'/Path(row['fixture']).name;dest.parent.mkdir(exist_ok=True);dest.write_bytes(subprocess.check_output(['git','show',raw['base_commit']+':'+row['fixture']]))
(packet/'source-state.json').write_text(json.dumps(state,indent=2)+'\n');(packet/'excluded-compiler-products.json').write_text(json.dumps(excluded,indent=2)+'\n')
base='f6cdecef644a7eb9e2091b685542b2ae5e405da8';paths=['.cargo/config.toml','Cargo.toml','Cargo.lock','benchmarks/mech-deflate/native-profile/Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.lock','benchmarks/mech-deflate/native-profile/compile_profile.rs','benchmarks/mech-deflate/native-profile/profile_compile.py','benchmarks/mech-deflate/native-profile/pending_schema_tests.rs','src/engine/src/source_semantics/pending_schema.rs','src/engine/src/source_semantics/frontend.rs','src/engine/src/source_semantics/annotation_shape_identity.rs','src/core/src/type_system/resolved.rs','src/core/src/type_system/diagnostic.rs','src/core/src/dimension.rs','src/core/src/schema/validation.rs'];config=[]
for name in paths:
 dest=packet/'source-config'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(subprocess.check_output(['git','show',base+':'+name]));config.append(dict(path=name,source_revision=base,**pin(dest)))
(packet/'source-config-pins.json').write_text(json.dumps(config,indent=2)+'\n')
capture=json.loads(Path('/private/tmp/mech-pr973-refresh-20261115/link/capture/link-command.json').read_text());inputs=[]
for at,row in enumerate(capture['inputs']):
 path=Path(row['retained_path']);wanted={k:row[k] for k in ['bytes','sha256']};assert pin(path)==wanted
 rel=Path('native-link-inputs')/(str(at)+'-'+path.name);dest=packet/rel;dest.parent.mkdir(exist_ok=True);shutil.copy2(path,dest);inputs.append(dict(source=row['source'],path=rel.as_posix(),**wanted))
(packet/'native-link-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
shutil.copytree('/private/tmp/mech-round2-planning-packet-20261114/licenses',packet/'licenses');validation=packet/'validation';validation.mkdir()
for suffix in ['.json','.archive.json']:shutil.copy2(repo/'benchmarks/mech-deflate/native-profile'/('scoped-source-apple-m3-20261115'+suffix),validation/('prior-qualified'+suffix))
selection=[]
for name in ['sample-1','sample-2']:
 source=Path('/private/tmp/mech-scoped-source-profile-20261115')/name/'demangled.txt';verified=Path('/private/tmp/mech-scoped-source-repository-verified-20261115/profiles')/name/'demangled.txt';assert source.read_bytes()==verified.read_bytes()
 rel=Path('selection-profiles')/name/'demangled.txt';dest=packet/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest);selection.append(dict(path=rel.as_posix(),**pin(dest)))
(packet/'profile-selection-pins.json').write_text(json.dumps(dict(source_archive_sha256='ac02c8c6ad673852b37c019753baaa881ae8676d6c4bbe76e157e6dd69b4d438',source_revision='972039beaaf9f04a609393905b518f4c16cbab67',files=selection,scope='Historical diagnostic selection only; call-graph paths are not CPU shares or candidate timing.'),indent=2)+'\n')
for name in ['mech-build-pending-resolved-types-20261115.py','mech-test-pending-resolved-types-20261115.py','mech-qualify-pending-resolved-types-20261115.py','mech-build-owned-annotation-identity-20261115.py','mech-test-owned-annotation-identity-20261115.py','mech-qualify-owned-annotation-identity-20261115.py','mech-owned-annotation-serial-gate-20261115.py','mech-profile-paths-frontend-cache-20261115.py','mech-prepare-frontend-cache-replay-20261115.py','mech-curate-frontend-cache-20261115.py']:shutil.copy2(Path('/private/tmp')/name,packet/name)
shutil.copy2('/private/tmp/mech-replay-frontend-cache-20261115.py',packet/'replay.py')
(packet/'README.txt').write_text('''Two independent frontend-cache trials, frozen f6cde and current Deflate/runtime.
Both use the qualified AE/source972 control, 61 flags plus two workers and the
standard compiler profile without PGO or native-CPU overrides.

The normalized-type cache improves frontend about 16 ms but makes the complete
compiler slower in both balanced blocks. Preserving the existing canonical
schema owner in annotation comparison saves about 58 ms in frontend work, but
complete executable builds are flat with mixed blocks (+0.13% mean). Both
changes are rejected; production source and the qualified AE tool are restored.

Each trial contains complete sources/patches, commands/logs, 15 or 28 focused
tests, fourteen fixture pairs, eight primary Object compiles and two cached
whole-executable gates. Annotation comparison also has eight complete source-
to-executable builds. All primary observations run serially, without concurrent
heavy builds, tests, sampling, hashing or archival. Fixed native adapter inputs
are cached; their first-use construction is excluded. Every program and gated
executable byte matches. Compiler/test executables and dependency libraries are
excluded and hash-pinned.

Historical source972 stack diagnostics support target selection only. The first
exploratory parser included the flat top-of-stack table; its initial result and
the corrected bounded recipe remain. No CPU-share or timing claim follows from
those call paths. Initial annotation test-count prose undercounted the existing
suite; unchanged stdout records 28 passes and the correction is recorded.

Pure offline replay applies both patches and reconstructs every mean, block and
byte gate. No grammar/language change, weaker fresh proof, scalar retirement or
new emitted-program runtime campaign is claimed. Complete compilation below ten
seconds remains open. The prepared default-serial gate was not needed or run
for these rejected changes.
''');print(packet)
