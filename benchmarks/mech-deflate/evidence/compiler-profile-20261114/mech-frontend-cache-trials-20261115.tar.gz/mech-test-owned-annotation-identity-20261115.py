from pathlib import Path
import hashlib,json,subprocess,time
repo=Path.cwd();root=Path('/private/tmp/mech-owned-annotation-identity-20261115');out=root/'focused';out.mkdir(exist_ok=False);pins=[]
for variant,folder in [('reference','before'),('candidate','candidate-source')]:
 directory=out/variant;directory.mkdir()
 for name in ['pending_schema.rs','annotation_shape_identity.rs']:
  relative='src/engine/src/source_semantics/'+name;dest=directory/name;dest.write_bytes((root/folder/relative).read_bytes());pins.append(dict(variant=variant,source_path=relative,path=variant+'/'+name,sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),scope='Exact complete production module and unit tests; no import/source substitutions.'))
 (directory/'mod.rs').write_text('mod pending_schema;\nmod annotation_shape_identity;\n')
(out/'harness.rs').write_text('''#![allow(dead_code)]
#[path="reference/mod.rs"] mod reference;
#[path="candidate/mod.rs"] mod candidate;
''')
rows=[json.loads(x) for x in Path('/private/tmp/mech-pending-resolved-types-20261115/candidate-build.jsonl').read_text().splitlines()];files=[Path(p) for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='mech_core' for p in r['filenames'] if p.endswith('.rlib')];assert len(files)==1;core=files[0]
command=['rustc','+nightly-2026-03-03','--edition=2024','--crate-name','owned_annotation_identity_tests','--test',str(out/'harness.rs'),'-C','opt-level=3','-C','lto=thin','-C','codegen-units=1','-D','warnings','-L','dependency='+str(core.parent),'--extern','mech_core='+str(core),'-o',str(out/'tests')]
(out/'command.json').write_text(json.dumps(dict(command=command,source_pins=pins,dependencies=[dict(name='mech_core',path=str(core),sha256=hashlib.sha256(core.read_bytes()).hexdigest())],scope='Both complete exact production modules and unit suites, reference13 plus candidate15 (28 total). Existing record renaming/bounds/persistent axes and schema cache tests; new pending-owner equivalence cache/success/error/mutation checks and both canonicalization demands despite invalid first argument. Not whole-library Cargo/no_std test.'),indent=2)+'\n')
started=time.monotonic()
with (out/'build.stdout.log').open('w') as stdout,(out/'build.stderr.log').open('w') as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr)
row=dict(exit_code=r.returncode,seconds=time.monotonic()-started)
if r.returncode==0:row['binary_sha256']=hashlib.sha256((out/'tests').read_bytes()).hexdigest()
(out/'build.json').write_text(json.dumps(row,indent=2)+'\n');print(row,flush=True);assert r.returncode==0
started=time.monotonic()
with (out/'test.stdout.log').open('w') as stdout,(out/'test.stderr.log').open('w') as stderr:r=subprocess.run([str(out/'tests'),'--nocapture'],stdout=stdout,stderr=stderr)
row=dict(exit_code=r.returncode,seconds=time.monotonic()-started);(out/'test.json').write_text(json.dumps(row,indent=2)+'\n');print(row,flush=True);raise SystemExit(r.returncode)
