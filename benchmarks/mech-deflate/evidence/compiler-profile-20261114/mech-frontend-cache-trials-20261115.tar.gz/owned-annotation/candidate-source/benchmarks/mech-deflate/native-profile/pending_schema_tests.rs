//! Exercise the production frontend schema owner independently of GPU setup.
#[path = "../../../src/engine/src/source_semantics/pending_schema.rs"]
mod pending_schema;

#[path = "../../../src/engine/src/source_semantics/annotation_shape_identity.rs"]
mod annotation_shape_identity;
