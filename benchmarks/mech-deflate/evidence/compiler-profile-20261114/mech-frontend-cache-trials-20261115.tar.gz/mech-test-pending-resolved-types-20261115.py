from pathlib import Path
import hashlib,json,subprocess,time
repo=Path.cwd();root=Path('/private/tmp/mech-pending-resolved-types-20261115');out=root/'focused';out.mkdir(exist_ok=False);name='src/engine/src/source_semantics/pending_schema.rs';pins=[]
for variant,folder in [('reference','before'),('candidate','candidate-source')]:
 source=root/folder/name;dest=out/(variant+'.rs');dest.write_bytes(source.read_bytes());pins.append(dict(variant=variant,source_path=name,sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),scope='Exact entire production module including its complete unit suite; no source/import substitutions.'))
(out/'harness.rs').write_text('''#![allow(dead_code)]
#[path="reference.rs"] mod reference;
#[path="candidate.rs"] mod candidate;
''')
rows=[json.loads(x) for x in Path('/private/tmp/mech-ssa-chain-roots-20261115/candidate-build.jsonl').read_text().splitlines()];files=[Path(p) for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='mech_core' for p in r['filenames'] if p.endswith('.rlib')];assert len(files)==1;core=files[0]
command=['rustc','+nightly-2026-03-03','--edition=2024','--crate-name','pending_resolved_types_tests','--test',str(out/'harness.rs'),'-C','opt-level=3','-C','lto=thin','-C','codegen-units=1','-D','warnings','-L','dependency='+str(core.parent),'--extern','mech_core='+str(core),'-o',str(out/'tests')]
(out/'command.json').write_text(json.dumps(dict(command=command,source_pins=pins,dependencies=[dict(name='mech_core',path=str(core),sha256=hashlib.sha256(core.read_bytes()).hexdigest())],scope='Both exact production PendingSchema modules and full module unit suites, original5 plus candidate10 tests. Normalized type comparison includes complete predicate evidence, lazy demand, error/unused declarations, mutation/repair, shared and unique owners, raw vs pending views and concurrent readers. Not a whole-library Cargo/no_std test.'),indent=2)+'\n')
started=time.monotonic()
with (out/'build.stdout.log').open('w') as stdout,(out/'build.stderr.log').open('w') as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr)
row=dict(exit_code=r.returncode,seconds=time.monotonic()-started)
if r.returncode==0:row['binary_sha256']=hashlib.sha256((out/'tests').read_bytes()).hexdigest()
(out/'build.json').write_text(json.dumps(row,indent=2)+'\n');print(row,flush=True);assert r.returncode==0
started=time.monotonic()
with (out/'test.stdout.log').open('w') as stdout,(out/'test.stderr.log').open('w') as stderr:r=subprocess.run([str(out/'tests'),'--nocapture'],stdout=stdout,stderr=stderr)
row=dict(exit_code=r.returncode,seconds=time.monotonic()-started);(out/'test.json').write_text(json.dumps(row,indent=2)+'\n');print(row,flush=True);raise SystemExit(r.returncode)
