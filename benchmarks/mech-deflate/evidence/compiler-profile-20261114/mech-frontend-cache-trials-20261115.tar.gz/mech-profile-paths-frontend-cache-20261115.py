from pathlib import Path
import argparse,json,re

def extract(root,call_graph_only=True):
 result=[]
 for name in ['sample-1','sample-2']:
  lines=(root/name/'demangled.txt').read_text().splitlines()
  if call_graph_only:
   begin=lines.index('Call graph:')+1;end=next(i for i,line in enumerate(lines) if line.startswith('Total number in stack'))
   lines=lines[begin:end]
  stack=[];hits=[]
  for line in lines:
   match=re.match(r'^(.*?)(\d+) (.*?)(?:  \(in | \(in )',line)
   if not match:continue
   depth=match.start(2);function=match[3]
   while stack and stack[-1][0]>=depth:stack.pop()
   stack.append((depth,function,int(match[2])))
   if 'canonicalize_dimension_environment' in function:
    path=[function for _,function,_ in stack]
    hits.append(dict(samples=int(match[2]),path=[function[-450:] for function in path[-12:]],resolved_type_caller=any('ResolvedType' in function for function in path)))
  result.append(dict(sample=name,canonicalization_paths=hits))
 return result

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--profiles-root',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--include-flat-tables',action='store_true');args=parser.parse_args()
 args.output.write_text(json.dumps(extract(args.profiles_root,not args.include_flat_tables),indent=2)+'\n')
