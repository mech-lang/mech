from pathlib import Path
import json, subprocess, sys, time

root = Path('/private/tmp/mech-round2-pgo-20261114')
stages = [
    ['mech-build-round2-pgo-20261114.py', 'generate'],
    ['mech-train-round2-pgo-20261114.py'],
    ['mech-build-round2-pgo-20261114.py', 'use'],
]
records = []
assert not (root / 'pipeline.json').exists()
for args in stages:
    command = [sys.executable, str(Path('/private/tmp') / args[0])] + args[1:]
    name = args[1] if len(args) > 1 else 'training'
    record = {'stage': name, 'command': command, 'state': 'running'}
    records.append(record)
    (root / 'pipeline.json').write_text(json.dumps(records, indent=2) + '\n')
    started = time.monotonic()
    completed = subprocess.run(command)
    record.update(state='complete' if completed.returncode == 0 else 'failed', seconds=time.monotonic()-started, exit_code=completed.returncode)
    (root / 'pipeline.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    if completed.returncode:
        raise SystemExit(completed.returncode)
