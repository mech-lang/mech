from pathlib import Path
import hashlib, json, os, shutil, subprocess, time

root = Path('/private/tmp/mech-round2-pgo-20261114')
repo = root / 'source'
flags = json.loads(Path('/private/tmp/mech-call-schema-borrow-20261114/runtime-flags.json').read_text())
assert len(flags) == 61
build = json.loads((root / 'generate-build.json').read_text())
assert build['exit_code'] == 0 and build['mode'] == 'generate'
assert hashlib.sha256((root / 'generate').read_bytes()).hexdigest() == build['binary_sha256']
output = root / 'training'
assert not output.exists()
output.mkdir()
env = {k: v for k, v in os.environ.items() if not k.startswith('MECH_')}
env.update(flags)
env['LLVM_PROFILE_FILE'] = str(root / 'raw' / '%m-%p.profraw')
assert not list((root / 'raw').glob('*.profraw'))
fixtures = [
    ('level12-deflate', 'benchmark'),
    ('numeric-nested-phase', 'hosts/gpu/tests/fixtures/native/numeric-nested-phase.mec'),
    ('numeric-private-fixed-nested', 'hosts/gpu/tests/fixtures/native/numeric-private-fixed-nested.mec'),
    ('numeric-array-windows', 'hosts/gpu/tests/fixtures/native/numeric-array-windows.mec'),
]
scalars = {'scalar-bool-equal': 'left<bool> == right<bool>\n', 'scalar-u64-add': 'left<u64> + right<u64>\n', 'scalar-i64-divide': 'left<i64> / right<i64>\n', 'scalar-f64-add': 'left<f64> + right<f64>\n'}
inputs = output / 'inputs'
inputs.mkdir()
for name, text in scalars.items():
    (inputs / (name + '.mec')).write_text(text)
    fixtures.append((name, str(inputs / (name + '.mec'))))
records = []
reference = Path('/private/tmp/mech-call-schema-borrow-20261114')
for name, source in fixtures:
    directory = output / name
    directory.mkdir()
    command = [str(root / 'generate'), source, str(directory), 'compact']
    (directory / 'command.json').write_text(json.dumps({'command': command, 'runtime_flags': flags, 'LLVM_PROFILE_FILE': env['LLVM_PROFILE_FILE'], 'instrumented_compiler_sha256': build['binary_sha256'], 'scope': 'Instrumented compiler training only; no performance qualification.'}, indent=2) + '\n')
    started = time.monotonic()
    with (directory / 'stdout.jsonl').open('w') as stdout, (directory / 'stderr.log').open('w') as stderr:
        completed = subprocess.run(command, cwd=repo, env=env, stdout=stdout, stderr=stderr)
    record = {'name': name, 'exit_code': completed.returncode, 'training_process_seconds': time.monotonic()-started, 'files': {}}
    assert completed.returncode == 0
    expected = reference / 'reference' if name == 'level12-deflate' else reference / 'fixtures' / name / 'control'
    for filename in ['source.mec', 'program.mecb', 'program.o', 'metadata.json']:
        data = (directory / filename).read_bytes()
        record['files'][filename] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'matches_frozen_unprofiled_control': data == (expected / filename).read_bytes()}
    records.append(record)
    (output / 'results.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    assert all(r['matches_frozen_unprofiled_control'] for r in record['files'].values())
raw_files = sorted((root / 'raw').glob('*.profraw'))
assert raw_files
pins = [{'path': str(p), 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in raw_files]
(output / 'profile-pins.json').write_text(json.dumps(pins, indent=2) + '\n')
profdata = (root / 'llvm-profdata-path.txt').read_text().strip()
command = [profdata, 'merge', '-o', str(root / 'merged.profdata')] + [str(p) for p in raw_files]
(output / 'merge-command.json').write_text(json.dumps(command, indent=2) + '\n')
with (output / 'merge.stdout.log').open('w') as stdout, (output / 'merge.stderr.log').open('w') as stderr:
    subprocess.run(command, stdout=stdout, stderr=stderr, check=True)
merged = root / 'merged.profdata'
(output / 'merged-profile-pin.json').write_text(json.dumps({'bytes': merged.stat().st_size, 'sha256': hashlib.sha256(merged.read_bytes()).hexdigest()}, indent=2) + '\n')
