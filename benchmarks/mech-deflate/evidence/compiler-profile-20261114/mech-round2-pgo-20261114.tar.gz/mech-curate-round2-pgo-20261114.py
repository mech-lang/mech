from pathlib import Path
import hashlib, json, shutil, subprocess

repo = Path.cwd()
raw = Path('/private/tmp/mech-round2-pgo-20261114')
packet = Path('/private/tmp/mech-round2-pgo-packet-20261114')
assert not packet.exists()
packet.mkdir()
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
excluded = []
for p in sorted(raw.iterdir()):
    if p.name in ['source', 'target']:
        continue
    if p.name in ['control', 'generate', 'use']:
        excluded.append(dict(path=p.name, **pin(p)))
        continue
    if p.is_file():
        shutil.copy2(p, packet / p.name)
    elif p.name in ['raw', 'training', 'qualification']:
        for q in sorted(p.rglob('*')):
            if not q.is_file():
                continue
            rel = q.relative_to(raw)
            if rel.as_posix() in ['qualification/control', 'qualification/candidate']:
                excluded.append(dict(path=rel.as_posix(), **pin(q)))
                continue
            dest = packet / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(q, dest)
state = json.loads((raw / 'source-state.json').read_text())
revision = state['source_commit']
source_paths = [
    '.cargo/config.toml', 'Cargo.toml', 'Cargo.lock',
    'benchmarks/mech-deflate/native-profile/Cargo.toml',
    'benchmarks/mech-deflate/native-profile/Cargo.lock',
    'benchmarks/mech-deflate/native-profile/compile_profile.rs',
    'benchmarks/mech-deflate/native-profile/profile_compile.py',
]
source_pins = []
for name in source_paths:
    content = subprocess.check_output(['git', 'show', revision + ':' + name])
    assert content == (raw / 'source' / name).read_bytes()
    dest = packet / 'source-config' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(content)
    source_pins.append(dict(path=name, **pin(dest)))
(packet / 'source-config-pins.json').write_text(json.dumps(source_pins, indent=2) + '\n')
for row in json.loads((packet / 'qualification/fixture-results.json').read_text()):
    name = row['fixture']
    if name.startswith('hosts/'):
        dest = packet / 'qualification/fixture-inputs' / Path(name).name
        content = subprocess.check_output(['git', 'show', revision + ':' + name])
        assert content == (repo / name).read_bytes()
        dest.write_bytes(content)
prior = Path('/private/tmp/mech-round2-planning-packet-20261114')
for name in ['licenses', 'native-link-inputs']:
    shutil.copytree(prior / name, packet / name)
shutil.copy2(prior / 'native-link-inputs.json', packet / 'native-link-inputs.json')
validation = packet / 'validation'
validation.mkdir()
for suffix in ['.json', '.archive.json']:
    name = 'parallel-phases-compile-apple-m3-20261114' + suffix
    shutil.copy2(repo / 'benchmarks/mech-deflate/native-profile' / name, validation / ('prior-qualified' + suffix))
for p in sorted(Path('/private/tmp').glob('*pgo*20261114.py')):
    if p.name != 'mech-replay-round2-pgo-20261114.py':
        shutil.copy2(p, packet / p.name)
shutil.copy2('/private/tmp/mech-replay-round2-pgo-20261114.py', packet / 'replay.py')
(packet / 'excluded-compiler-products.json').write_text(json.dumps(excluded, indent=2) + '\n')
(packet / 'README.txt').write_text('''Compiler-only instrumentation PGO, 2026-11-14.
The control, instrumented and profile-use compilers use the same frozen tracked
source fad53d24d9d2cad61262cb94932405fd9ee40341, explicit aarch64-apple-darwin
target, compiler profile (ThinLTO, one codegen unit), nightly-2026-03-03, four
Cargo jobs, incremental0 and warnings-as-errors. Source configuration/harness
files are included and checked against the frozen checkout. Other compiler
source is pinned by that Git commit; the dependency cache and Rust/LLVM
toolchain are not redistributed. No production source change is claimed.
Eight fixed programs train the instrumented compiler. All training outputs are
byte-identical to their unprofiled controls. Eight raw profiles, merged profile,
matching llvm-profdata version/path, merge command, all build/training logs and
commands are included. Compiler executables are excluded and SHA-pinned.
Fourteen paired output fixtures include seven held-out programs. Those seven
also receive separate eight-run ABBA/BAAB compile cohorts (56 compiles); a large
first-control startup outlier and every per-case time/counter/block remain.
Two preliminary
source-to-Object screens and cached-native-link gates precede primary timings.
Eight ABBA/BAAB source-to-Object runs and eight separate ABBA/BAAB complete
source-to-executable builds run serially, without concurrent build/test/profile
or archival work. The fixed runtime adapter is cached and pinned; every program
compile is fresh. No scalar retirement, language/grammar change or new emitted
program runtime campaign is claimed. The full executable stays byte-identical.
The slow first Object control, adverse frontend/encode timing and footprint
movement remain in the full data. Preliminary screens are not pooled into means.
This pair predates two schema changes and the integrated workers; its improvement
must not be added to their percentages. Combined-source PGO is not qualified.
The first evidence-curation recipe requests a nonexistent rust-toolchain.toml;
its failure and recipe remain. It ran after timings and executes no builds.
Every Cargo command already pins the toolchain explicitly; curation uses the
actual source configuration files.
Pure replay validates saved outputs, profiles, commands and timing calculations;
it does not rerun builds or measurements. Complete compilation below ten seconds
is still unachieved.
''')
print(packet)
