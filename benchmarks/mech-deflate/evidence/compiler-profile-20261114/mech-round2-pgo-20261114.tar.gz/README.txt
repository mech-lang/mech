Compiler-only instrumentation PGO, 2026-11-14.
The control, instrumented and profile-use compilers use the same frozen tracked
source fad53d24d9d2cad61262cb94932405fd9ee40341, explicit aarch64-apple-darwin
target, compiler profile (ThinLTO, one codegen unit), nightly-2026-03-03, four
Cargo jobs, incremental0 and warnings-as-errors. Source configuration/harness
files are included and checked against the frozen checkout. Other compiler
source is pinned by that Git commit; the dependency cache and Rust/LLVM
toolchain are not redistributed. No production source change is claimed.
Eight fixed programs train the instrumented compiler. All training outputs are
byte-identical to their unprofiled controls. Eight raw profiles, merged profile,
matching llvm-profdata version/path, merge command, all build/training logs and
commands are included. Compiler executables are excluded and SHA-pinned.
Fourteen paired output fixtures include seven held-out programs. Those seven
also receive separate eight-run ABBA/BAAB compile cohorts (56 compiles); a large
first-control startup outlier and every per-case time/counter/block remain.
Two preliminary
source-to-Object screens and cached-native-link gates precede primary timings.
Eight ABBA/BAAB source-to-Object runs and eight separate ABBA/BAAB complete
source-to-executable builds run serially, without concurrent build/test/profile
or archival work. The fixed runtime adapter is cached and pinned; every program
compile is fresh. No scalar retirement, language/grammar change or new emitted
program runtime campaign is claimed. The full executable stays byte-identical.
The slow first Object control, adverse frontend/encode timing and footprint
movement remain in the full data. Preliminary screens are not pooled into means.
This pair predates two schema changes and the integrated workers; its improvement
must not be added to their percentages. Combined-source PGO is not qualified.
The first evidence-curation recipe requests a nonexistent rust-toolchain.toml;
its failure and recipe remain. It ran after timings and executes no builds.
Every Cargo command already pins the toolchain explicitly; curation uses the
actual source configuration files.
Pure replay validates saved outputs, profiles, commands and timing calculations;
it does not rerun builds or measurements. Complete compilation below ten seconds
is still unachieved.
