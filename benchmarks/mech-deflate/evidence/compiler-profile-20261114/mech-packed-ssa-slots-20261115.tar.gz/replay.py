from pathlib import Path
import ast
import importlib.util
import hashlib
import json
import re
import statistics
import subprocess
import sys

packet = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_text())
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
state = read(packet / 'source-state.json')
profile_results=[]
selection_inspection=read(packet/'selection.json')
assert selection_inspection['state'].startswith('Inspection only')
assert pin(packet / 'candidate.patch')['sha256'] == state['patch_sha256']
for row in state['files']:
    assert pin(packet / 'reference-source' / row['path']) == row['reference']
    assert pin(packet / 'candidate-source' / row['path']) == row['candidate']
commit_path = packet / 'qualification-commit.json'
commit = read(commit_path) if commit_path.exists() else dict(source_commit=None)
if commit_path.exists():
    assert commit['parent'] == state['base_commit']
    assert commit['entire_commit_diff_sha256'] == state['patch_sha256']
    assert commit['entire_commit_diff_matches_measured_patch']
excluded = read(packet / 'excluded-products.json')
assert excluded['control']['sha256'] == '3c09f358909db5ab07d09a9ee78a16d3de83f58d9f181f750985e7f3a88653f3'
assert read(packet / 'candidate-build.json')['binary_sha256'] == excluded['candidate']['sha256']
for name in ['candidate-check', 'candidate-build', 'candidate-cli-check']:
    row = read(packet / (name + '.json'))
    assert row['exit_code'] == 0 and row['patch_sha256'] == state['patch_sha256']
assert read(packet / 'focused/build.json')['exit_code'] == read(packet / 'focused/test.json')['exit_code'] == 0
assert 'test result: ok. 31 passed; 0 failed' in (packet / 'focused/test.stdout.log').read_text()
for variant in ['reference','candidate']:
    assert (packet / (variant+'.rs')).read_bytes() == (packet / 'focused' / (variant+'.rs')).read_text().replace('use super::SSABuilder;','use crate::ssa::SSABuilder;').encode()
ir = read(packet / 'ir-comparison/result.json')
assert ir['paired_cases'] == 328 and ir['verified_functions'] == 656
assert pin(packet / 'ir-comparison/cases.jsonl')['sha256'] == ir['cases_sha256']
assert read(packet / 'ir-comparison/build.json')['exit_code'] == read(packet / 'ir-comparison/test.json')['exit_code'] == 0
assert read(packet / 'ir-comparison/test.json')['binary_sha256'] == excluded['ir-comparison/probe']['sha256']
ir_cases = [json.loads(line) for line in (packet / 'ir-comparison/cases.jsonl').read_text().splitlines()]
assert len(ir_cases) == 328 and all(r['identical'] for r in ir_cases)
for row in ir_cases:
    assert all(key in row['observation'] for key in ['raw_ir','raw_queries','raw_variable_definitions','raw_value_count','ir','queries','machine','effects'])
flags = read(packet / 'runtime-flags.json')
assert len(flags) == 61
reference = {name:pin(packet / 'reference' / name) for name in ['source.mec','program.mecb','program.o','metadata.json']}
native = read(packet / 'native-baseline-pins.json')
exe = native['executable']
assert exe == dict(bytes=2060440,sha256='d6c65cc3fb18acc4be77dce329962105bf0f2b56dd2623a12f466256463eca61')
capture = read(packet / 'link-command.json')
inputs = read(packet / 'native-link-inputs.json')
assert [(r['source'],r['bytes'],r['sha256']) for r in inputs] == [(r['source'],r['bytes'],r['sha256']) for r in capture['inputs']]
for row in inputs:
    assert pin(packet / row['path']) == {k:row[k] for k in ['bytes','sha256']}
for variant in ['control','candidate']:
    directory = packet / (variant + '-screen')
    assert read(directory / 'process.json')['exit_code'] == 0
    for name, item in reference.items():
        assert pin(directory / name) == item and (directory / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    assert pin(packet / ('link-' + variant) / 'worker') == exe
gates = read(packet / 'final-executable-results.json')
assert len(gates) == 2 and all(r['exit_code'] == 0 and r['matches_complete_baseline_executable'] and r['executable_sha256'] == exe['sha256'] for r in gates)
fixtures = read(packet / 'fixture-results.json')
assert len(fixtures) == 14
for row in fixtures:
    assert row['all_outputs_match'] and row['variants']['control'] == row['variants']['candidate']
    for variant in ['control','candidate']:
        entry = row['variants'][variant]
        assert entry['exit_code'] == 0 and len(entry['files']) == 4
        name = Path(row['fixture'].split(':')[-1]).stem
        directory = packet / 'fixtures' / name / variant
        for filename, item in entry['files'].items():
            assert pin(directory / filename) == item
            assert (directory / filename).read_bytes() == (packet / 'fixtures' / name / 'control' / filename).read_bytes()
jobs=read(packet/'jobs-diagnostic.json')
assert jobs['excluded_from_primary'] and jobs['all_outputs_and_complete_executable_identical']
observed=[]
for line in (packet/'candidate-jobs-diagnostic/stderr.log').read_text().splitlines():
    match=re.fullmatch(r'compact-compile-jobs: workers=(\d+) submitted=(\d+) cleanup=(\d+)',line)
    if match:observed.append(dict(workers=int(match[1]),submitted=int(match[2]),cleanup=int(match[3])))
assert jobs['rows']==observed and observed==[dict(workers=2,submitted=344,cleanup=48)]
for name,item in reference.items():assert pin(packet/'candidate-jobs-diagnostic'/name)==item
assert pin(packet/'link-candidate-jobs/worker')==exe
assert read(packet/'jobs-executable-results.json')[0]['matches_complete_baseline_executable']
assert read(packet/'candidate-jobs-diagnostic-command.json')['flags']==dict(flags,MECH_COMPACT_COMPILE_THREADS='2',MECH_PROFILE_COMPILE_JOBS='1')

rows = read(packet / 'cohort.json')
assert len(rows) == 8
order = ['control-1','candidate-1','candidate-2','control-2','candidate-3','control-3','control-4','candidate-4']
assert [r['name'] for r in rows] == order
for row in rows:
    directory = packet / row['name']
    assert row['compile'] == read(directory / 'compile.json') and row['process'] == read(directory / 'process.json')
    assert row['process']['exit_code'] == 0
    command = read(packet / (row['name'] + '-command.json'))
    assert command['binary_sha256'] == excluded[row['variant']]['sha256']
    assert command['flags'] == dict(flags, MECH_COMPACT_COMPILE_THREADS='2')
    for name, item in reference.items():
        assert pin(directory / name) == item and (directory / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    stamps = [json.loads(line) for line in (directory / 'stages.jsonl').read_text().splitlines()]
    for key, begin, end in [('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code'),('compaction_seconds','compact-stage: compact values before=','compact-stage: CFG cleanup')]:
        assert row[key] == next(s['elapsed'] for s in stamps if s['line'].startswith(end)) - next(s['elapsed'] for s in stamps if s['line'].startswith(begin))
    assert row['cleanup_including_compaction_seconds'] == row['cleanup_seconds'] + row['compaction_seconds']
    log = (directory / 'stderr.log').read_text()
    for key, pattern in [('max_rss_bytes',r'(\d+)  maximum resident set size'),('instructions',r'(\d+)  instructions retired'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]:
        assert row[key] == int(re.search(pattern,log).group(1))
fields = dict(compiler_seconds=lambda r:r['compile']['total_seconds'],whole_process_seconds=lambda r:r['process']['elapsed_seconds'])
for phase in ['parse','catalog','frontend','artifact','encode','native']:
    fields[phase+'_seconds'] = lambda r,p=phase: next(v['seconds'] for v in r['compile']['phases'] if v['phase']==p)
for key in ['canonical_lowering_seconds','preparation_seconds','numeric_generation_seconds','source_cfg_seconds','cleanup_including_compaction_seconds','cleanup_seconds','compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:
    fields[key] = lambda r,k=key:r[k]
summary = {}
for key, fn in fields.items():
    values = {v:[fn(r) for r in rows if r['variant']==v] for v in ['control','candidate']}
    base = statistics.mean(values['control'])
    values['mean_reduction_fraction'] = 1-statistics.mean(values['candidate'])/base if base else None
    summary[key] = values
assert read(packet / 'numerical-summary.json') == summary
native_path = packet / 'native-cohort.json'
native_rows = read(native_path) if native_path.exists() else []
assert len(native_rows) in [0,8]
native_summary = {}
for row in native_rows:
    directory = packet / row['name']
    receipt = read(directory / 'result.json')
    assert row == dict(receipt, name=row['name'], primary_cohort=True)
    assert row['compiler_exit_code'] == row['link_exit_code'] == 0 and row['matches_complete_baseline_executable']
    assert row['executable_bytes'] == exe['bytes'] and row['executable_sha256'] == exe['sha256'] and pin(directory / 'worker') == exe
    for name, item in reference.items():
        assert pin(directory / name) == item and (directory / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    assert abs(row['source_to_executable_seconds']-sum(row[k] for k in ['source_to_object_process_seconds','object_handoff_seconds','native_link_seconds'])) < 1e-8
if native_rows:
    for key in ['source_to_executable_seconds','source_to_object_process_seconds','object_handoff_seconds','native_link_seconds']:
        values = {v:[r[key] for r in native_rows if r['variant']==v] for v in ['control','candidate']}
        values['mean_reduction_fraction'] = 1-statistics.mean(values['candidate'])/statistics.mean(values['control'])
        native_summary[key] = values
    blocks = []
    for block in [native_rows[:4],native_rows[4:]]:
        means = {v:statistics.mean(r['source_to_executable_seconds'] for r in block if r['variant']==v) for v in ['control','candidate']}
        means['mean_reduction_fraction'] = 1-means['candidate']/means['control']
        blocks.append(means)
    saved = read(packet / 'native-numerical-summary.json')
    assert saved['numerical_summary'] == native_summary and saved['balanced_blocks'] == blocks
else:
    blocks = []
if (packet / 'candidate-serial-gate').exists():
    serial = packet / 'candidate-serial-gate'
    assert read(serial / 'process.json')['exit_code'] == 0
    for name, item in reference.items():
        assert pin(serial / name) == item and (serial / name).read_bytes() == (packet / 'reference' / name).read_bytes()
    serial_result = read(packet / 'link-candidate-serial/result.json')
    assert serial_result['matches_complete_baseline_executable'] and serial_result['executable_sha256'] == exe['sha256']
    assert pin(packet / 'link-candidate-serial/worker') == exe
result = dict(source_commit=commit['source_commit'],base_commit=state['base_commit'],patch_sha256=state['patch_sha256'],compiler=excluded,source_state=state,numerical_summary=summary,native_numerical_summary=native_summary,balanced_native_blocks=blocks,output_hashes=reference,final_executable=exe,fixture_pairs=14,focused_tests=31,paired_ir=ir,selection_inspection=selection_inspection,checks={name:read(packet/(name+'.json')) for name in ['candidate-check','candidate-build','candidate-cli-check']},decision=read(packet/'decision.json'),scope='Dense SSA slots store packed values plus presence in five bytes, preserving presentNone. Unchanged sparse map/promotion, SSA algorithm, errors and identities; only copied return projections. Standard3c09 versus standard candidate with same61flags/2workers and pinnedmimalloc. Current best optimized8043/profile8691 preserved; no fresh candidate PGO qualification or inferred historical gain. No new sampling. All full source/MBC/Object/metadata/executable gates; default0/344-48jobs. No grammar/proof/runtime changes.')
spec=importlib.util.spec_from_file_location('ssa_algorithm_audit',packet/'audit.py');audit_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit_module)
algorithm=audit_module.audit(packet);assert algorithm==read(packet/'algorithm-audit.json')
plan=read(packet/'qualification-plan.json');driver=packet/'mech-qualify-packed-ssa-slots-20261115.py';assert pin(driver)['sha256']==plan['driver_sha256']
assignments=[node for node in ast.parse(driver.read_text()).body if isinstance(node,ast.Assign) and any(isinstance(target,ast.Name) and target.id=='stages' for target in node.targets)]
assert len(assignments)==1 and [list(row) for row in ast.literal_eval(assignments[0].value)]==plan['stages']
pipeline=read(packet/'qualification-pipeline.json');assert [row['stage'] for row in pipeline]==[row[0] for row in plan['stages']]
assert all(row['state']=='complete' and row['exit_code']==0 for row in pipeline)
for item in read(packet/'qualification-scripts/derivation.json'):
    assert pin(packet/'qualification-scripts/originals'/Path(item['original']).name)['sha256']==item['original_sha256']
    assert pin(packet/'qualification-scripts'/item['derived'])['sha256']==item['derived_sha256']
decision=read(packet/'decision.json');restoration=read(packet/'restoration.json')
if decision['decision']=='reject':
    assert restoration==decision['restoration'] and restoration['source_restored']
    assert restoration['source_sha256']==state['files'][0]['reference']['sha256'] and restoration['canonical_sha256']==excluded['control']['sha256']
else:
    assert decision['decision']=='retain' and commit['source_commit'] and not restoration['source_restored']
    assert restoration['source_sha256']==state['files'][0]['candidate']['sha256'] and restoration['canonical_sha256']==excluded['candidate']['sha256']
    assert pin(packet/'entire-source-commit.patch')['sha256']==state['patch_sha256']
    assert (packet/'entire-source-commit.patch').read_bytes()==(packet/'candidate.patch').read_bytes()
    assert all(row['mean_reduction_fraction']>0 for row in blocks)
assert restoration['selected_pgo_sha256']=='8043d93d27b948371aee38027df898a9024e47a1ffa112b47a1913f8329e40ad'
assert decision['control_complete_seconds']==statistics.mean(native_summary['source_to_executable_seconds']['control'])
assert decision['candidate_complete_seconds']==statistics.mean(native_summary['source_to_executable_seconds']['candidate'])
assert decision['native_reduction']==native_summary['source_to_executable_seconds']['mean_reduction_fraction'] and decision['native_blocks']==blocks
assert decision['object_adverse_fields']=={key:value for key,value in summary.items() if value['mean_reduction_fraction']<0}
object_blocks=[]
for block in [rows[:4],rows[4:]]:
    values={}
    for key in ['compiler_seconds','whole_process_seconds','source_cfg_seconds','instructions']:
        means={variant:statistics.mean(fields[key](row) for row in block if row['variant']==variant) for variant in ['control','candidate']}
        means['mean_reduction_fraction']=1-means['candidate']/means['control'];values[key]=means
    object_blocks.append(values)

result.update(algorithm_audit=algorithm,jobs_diagnostic=jobs,qualification_pipeline=pipeline,object_balanced_blocks=object_blocks,restoration=restoration)

encoded = json.dumps(result,indent=2,sort_keys=True)+'\n'
saved = packet / 'summary.json'
if saved.exists():
    assert saved.read_text() == encoded
else:
    saved.write_text(encoded)
print(encoded,end='')
