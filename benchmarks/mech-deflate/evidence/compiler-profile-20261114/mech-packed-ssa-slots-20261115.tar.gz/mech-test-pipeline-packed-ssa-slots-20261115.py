from pathlib import Path
import datetime,json,subprocess,sys,time
r=Path('/private/tmp/mech-packed-ssa-slots-20261115');rows=[]
for stage,name in [('focused','test'),('ir-comparison','compare'),('candidate-build','build'),('native-cli','check')]:
 command=[sys.executable,'/private/tmp/mech-'+name+'-packed-ssa-slots-20261115.py'];row=dict(stage=stage,command=command,state='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());rows.append(row);(r/'test-pipeline.json').write_text(json.dumps(rows,indent=2)+'\n');started=time.monotonic()
 with (r/(stage+'-pipeline.stdout.log')).open('w') as stdout,(r/(stage+'-pipeline.stderr.log')).open('w') as stderr:completed=subprocess.run(command,stdout=stdout,stderr=stderr)
 row.update(state='complete' if completed.returncode==0 else 'failed',exit_code=completed.returncode,seconds=time.monotonic()-started);(r/'test-pipeline.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True);assert completed.returncode==0
