from pathlib import Path
import ast,hashlib,json

tmp=Path('/private/tmp');root=tmp/'mech-packed-ssa-slots-20261115'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pin=lambda p:dict(bytes=p.stat().st_size,sha256=sha(p))
p=root/'source-state.json';state=json.loads(p.read_text())
for row in state['files']:
    row['reference']=pin(root/'reference-source'/row['path']);row['candidate']=pin(root/'candidate-source'/row['path'])
p.write_text(json.dumps(state,indent=2)+'\n')
p=root/'qualification-plan.json';plan=json.loads(p.read_text());plan['stages']=plan['actual_ast_stages'];p.write_text(json.dumps(plan,indent=2)+'\n')
records=[]
def derive(label,transform):
    p=tmp/('mech-'+label+'-ssa-descending-chain-20261115.py');s=p.read_text().replace('ssa-descending-chain','packed-ssa-slots').replace('6ce7a53b36d3677cf3b20d919657d2824b7d8561ef5eeaf254377626f27980ae','3c09f358909db5ab07d09a9ee78a16d3de83f58d9f181f750985e7f3a88653f3').replace('6fc6db8164c3f0a66fc5d968fd42f72fe5daf11ca8e89dea00b430530989a797','8043d93d27b948371aee38027df898a9024e47a1ffa112b47a1913f8329e40ad')
    s=transform(s);ast.parse(s);q=tmp/('mech-'+label+'-packed-ssa-slots-20261115.py');assert not q.exists();q.write_text(s);records.append(dict(original=str(p),original_sha256=sha(p),derived=str(q),derived_sha256=sha(q)))
def replay(s):
    a=s.index("selection = packet / 'current-profile'");b=s.index("assert pin(packet / 'candidate.patch')",a)
    s=s[:a]+"profile_results=[]\nselection_inspection=read(packet/'selection.json')\nassert selection_inspection['state'].startswith('Inspection only')\n"+s[b:]
    s=s.replace('32 passed; 0 failed','31 passed; 0 failed').replace('focused_tests=32','focused_tests=31').replace('selection_profile=profile_results','selection_inspection=selection_inspection')
    a=s.index("scope='Strictly decreasing");b=s.index("')\n",a)+2
    s=s[:a]+"scope='Dense SSA slots store packed values plus presence in five bytes, preserving presentNone. Unchanged sparse map/promotion, SSA algorithm, errors and identities; only copied return projections. Standard3c09 versus standard candidate with same61flags/2workers and pinnedmimalloc. Current best optimized8043/profile8691 preserved; no fresh candidate PGO qualification or inferred historical gain. No new sampling. All full source/MBC/Object/metadata/executable gates; default0/344-48jobs. No grammar/proof/runtime changes.')"+s[b:]
    a=s.index("assert decision['decision']=='reject'");b=s.index("assert decision['control_complete_seconds']",a)
    conditional="""if decision['decision']=='reject':
    assert restoration==decision['restoration'] and restoration['source_restored']
    assert restoration['source_sha256']==state['files'][0]['reference']['sha256'] and restoration['canonical_sha256']==excluded['control']['sha256']
else:
    assert decision['decision']=='retain' and commit['source_commit'] and not restoration['source_restored']
    assert restoration['source_sha256']==state['files'][0]['candidate']['sha256'] and restoration['canonical_sha256']==excluded['candidate']['sha256']
    assert pin(packet/'entire-source-commit.patch')['sha256']==state['patch_sha256']
    assert (packet/'entire-source-commit.patch').read_bytes()==(packet/'candidate.patch').read_bytes()
    assert all(row['mean_reduction_fraction']>0 for row in blocks)
assert restoration['selected_pgo_sha256']=='8043d93d27b948371aee38027df898a9024e47a1ffa112b47a1913f8329e40ad'
"""
    return s[:a]+conditional+s[b:]
derive('replay',replay)
def curate(s):
    s=s.replace("Path('/private/tmp/mech-parallel-native-pgo-20261115')", "Path('/private/tmp/mech-dimension-native-pgo-20261115')")
    s=s.replace('parallel-native-pgo-apple-m3','dimension-native-pgo-apple-m3').replace('parallel-phase-cleanup-apple-m3','dimension-declaration-scan-apple-m3').replace('profile-selection-evidence-receipt','selection-evidence-receipt')
    return s
derive('curate',curate)
def pack(s):
    s=s.replace("source='db1498fe94873117fd5b9e5e8b4a7864efe0aa2d'", "source=json.loads((packet/'decision.json').read_text()).get('source_commit') or '0ab8308a795a11c919d0aac36e42920b4001ed2b'")
    s=s.replace("assert json.loads((packet/'decision.json').read_text())['decision']=='reject'", "assert json.loads((packet/'decision.json').read_text())['decision'] in ['retain','reject']")
    s=s.replace("assert json.loads((packet/'source-state.json').read_text())['base_commit']==source and json.loads((packet/'restoration.json').read_text())['source_restored']", "assert json.loads((packet/'source-state.json').read_text())['base_commit']=='0ab8308a795a11c919d0aac36e42920b4001ed2b'")
    s=s.replace("assert len(previous)==45 and index['total_archive_bytes']==1404964141", "assert len(previous)==49 and index['total_archive_bytes']==1592290023")
    return s
derive('pack',pack)
(root/'evidence-derivation.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(records,indent=2))
