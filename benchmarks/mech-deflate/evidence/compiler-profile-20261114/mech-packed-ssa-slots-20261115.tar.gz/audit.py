from pathlib import Path
import hashlib,json,re

def tokens(text):
    pieces=re.findall(r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|[A-Za-z_]\w*|\d+|[^\s]',text)
    return [x for x in pieces if not x.startswith(('//','/*'))]

def audit(root):
    old=(root/'reference.rs').read_text();new=(root/'candidate.rs').read_text()
    begin='#[derive(Default)]\nstruct VisitSet';end='#[cfg(test)]\nmod tests {'
    tail=old[old.index(begin):old.index(end)]
    tail,n=re.subn(r'\.get\(&block\)\s*\.copied\(\)', '.get(&block)',tail)
    assert n==2
    assert tokens(tail)==tokens(new[new.index(begin):new.index(end)])
    prefix='// Most variables have very few queried blocks.'
    assert old[:old.index(prefix)]==new[:new.index(prefix)]
    def method(text,start,end):return text[text.index(start):text.index(end,text.index(start))]
    before=method(old,'    fn insert(', '    fn values(')
    after=method(new,'    fn insert(', '    fn values(')
    before=before.replace('self.dense.resize(size, None)','self.dense.resize(size, DenseDefinition::default())')
    before=before.replace('self.dense[at] = Some(*value)','self.dense[at] = DenseDefinition { value: *value, present: true, }')
    assert tokens(before)==tokens(after)
    assert 'unsafe' not in new[new.index(prefix):new.index(begin)]
    return dict(ssa_algorithm_tokens_identical_after_two_get_copy_projections=True,unchanged_sparse_map_and_promotion_algorithm=True,unchanged_source_prefix=True,unchanged_generation_cycles_sealing_value_allocation_and_predecessor_algorithms=True,no_unsafe_or_identity_range_restriction=True,algorithm_tokens_sha256=hashlib.sha256(' '.join(tokens(tail)).encode()).hexdigest(),scope='Representation only. Separate presence byte preserves absent versus presentNone. Packed fields copied by value; existing map oracle and raw/compacted IR/machine comparison are independent behavior gates.')

if __name__=='__main__':
    root=Path(__file__).resolve().parent;result=audit(root);encoded=json.dumps(result,indent=2,sort_keys=True)+'\n';p=root/'algorithm-audit.json'
    if p.exists():assert p.read_text()==encoded
    else:p.write_text(encoded)
    print(encoded,end='')
