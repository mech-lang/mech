from pathlib import Path
import hashlib,json,statistics,subprocess

repo=Path.cwd();root=Path('/private/tmp/mech-packed-ssa-slots-20261115')
read=lambda p:json.loads(p.read_text());pin=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
pipeline=read(root/'qualification-pipeline.json');assert len(pipeline)==6 and all(r['state']=='complete' and r['exit_code']==0 for r in pipeline)
native=read(root/'native-numerical-summary.json');obj=read(root/'numerical-summary.json');main=native['numerical_summary']['source_to_executable_seconds'];rows=read(root/'cohort.json')
blocks=[]
for block in [rows[:4],rows[4:]]:
    values={v:statistics.mean(r['compile']['total_seconds'] for r in block if r['variant']==v) for v in ['control','candidate']}
    values['mean_reduction_fraction']=1-values['candidate']/values['control'];blocks.append(values)
retain=main['mean_reduction_fraction']>0 and all(b['mean_reduction_fraction']>0 for b in native['balanced_blocks']) and obj['compiler_seconds']['mean_reduction_fraction']>0 and all(b['mean_reduction_fraction']>0 for b in blocks)
control,candidate=(statistics.mean(main[v]) for v in ['control','candidate'])
decision=dict(decision='retain' if retain else 'reject',source_commit=None,description=f"{'Retained' if retain else 'Rejected'} packed dense SSA slots: standard complete compilation {control:.6f}->{candidate:.6f}s ({-100*main['mean_reduction_fraction']:+.3f}%); all31units/328paired raw+compactedIR/machine cases and every full output/metadata/executable match. Same61flags/2workers, build configuration unchanged. All adverse fields retained. Current best optimized8043 remains13.414825s; this source is not yet separately PGO-qualified.",control_complete_seconds=control,candidate_complete_seconds=candidate,native_reduction=main['mean_reduction_fraction'],native_blocks=native['balanced_blocks'],object_compiler_blocks=blocks,object_adverse_fields={k:v for k,v in obj.items() if v['mean_reduction_fraction']<0},current_best_seconds=13.414824520470574,current_best_sha256='8043d93d27b948371aee38027df898a9024e47a1ffa112b47a1913f8329e40ad',new_source_pgo_qualified=False,restoration=None)
assert subprocess.check_output(['git','diff','--binary'])==(root/'candidate.patch').read_bytes()
state=read(root/'source-state.json');path=repo/state['files'][0]['path']
assert pin(path)==state['files'][0]['candidate']
if not retain:
    import shutil
    path.write_bytes((root/'reference.rs').read_bytes())
    shutil.copy2(root/'control','/private/tmp/mech-level12-compile-target/compiler/compile_profile')
    assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
    restored=True
else:
    restored=False
restoration=dict(source_restored=restored,source_sha256=pin(path)['sha256'],canonical_sha256=pin(Path('/private/tmp/mech-level12-compile-target/compiler/compile_profile'))['sha256'],selected_pgo_sha256=pin(Path('/private/tmp/mech-dimension-native-pgo-20261115/use'))['sha256'],cache_note='Canonical standard3c09 restored; Cargo rlibs still reflect rejected packed candidate. Fresh restored source mtime forces genuine rebuild before treating cached libraries as reference.' if restored else 'Canonical6b57 and Cargo libraries match frozen packed source. Earlier optimized8043/sourceef5 preserved separately; fresh candidate PGO not qualified.')
assert restoration['selected_pgo_sha256']==decision['current_best_sha256']
(root/'restoration.json').write_text(json.dumps(restoration,indent=2)+'\n');decision['restoration']=restoration
(root/'decision.json').write_text(json.dumps(decision,indent=2,sort_keys=True)+'\n');print(json.dumps(decision,indent=2,sort_keys=True))
