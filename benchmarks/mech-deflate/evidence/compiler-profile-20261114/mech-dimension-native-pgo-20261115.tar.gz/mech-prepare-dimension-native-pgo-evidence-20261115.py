from pathlib import Path
import ast
import hashlib
import json

tmp = Path('/private/tmp')
raw = tmp/'mech-dimension-native-pgo-20261115'
old = tmp/'mech-parallel-native-pgo-20261115'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
common = {
    'mech-parallel-native-pgo': 'mech-dimension-native-pgo',
    'parallel-native-pgo-apple-m3': 'dimension-native-pgo-apple-m3',
    '0c949505cc708c233e27c094aa67e105068d6823': 'ef5e255e817eb5bbc6df61b094a3741b31c49da2',
    '6ce7a53b36d3677cf3b20d919657d2824b7d8561ef5eeaf254377626f27980ae': '3c09f358909db5ab07d09a9ee78a16d3de83f58d9f181f750985e7f3a88653f3',
}
records = []
def derive(label, transform=lambda text:text):
    original = tmp/('mech-'+label+'-parallel-native-pgo-20261115.py')
    derived = tmp/('mech-'+label+'-dimension-native-pgo-20261115.py')
    text = original.read_text()
    for before, after in common.items():
        text = text.replace(before, after)
    text = transform(text)
    ast.parse(text)
    assert not derived.exists()
    derived.write_text(text)
    records.append(dict(original=str(original), original_sha256=sha(original), derived=str(derived), derived_sha256=sha(derived)))
    return derived

def replay(text):
    start = text.index("failure=read(packet/'qualification-order-failure/interruption.json')")
    end = text.index("revision = '", start)
    proof = """plan=read(packet/'qualification-plan.json')
driver=packet/'qualify.py'
assert pin(driver)['sha256']==plan['qualification_driver_sha256']
loops=[node for node in ast.parse(driver.read_text()).body if isinstance(node,ast.For) and isinstance(node.target,ast.Tuple) and [v.id for v in node.target.elts]==['stage','name']]
assert len(loops)==1
actual_steps=ast.literal_eval(loops[0].iter)
assert [row[0] for row in actual_steps]==['screens', 'cached-executable-gates', 'serial-default-gate', 'real-worker-diagnostic', 'fixtures-object-cohort', 'heldout-cohorts', 'native-cohort', 'parallel-isolation']
assert [dict(stage=stage,helper=name,helper_sha256=pin(packet/'qualification-scripts'/name)['sha256']) for stage,name in actual_steps]==plan['actual_ast_stages']
assert all((packet/'qualification-scripts'/name).is_file() for stage,name in actual_steps)

"""
    text = text[:start]+proof+text[end:]
    text = '\n'.join(line for line in text.split('\n') if not line.startswith("assert excluded['qualification-order-failure/"))
    start = text.index("original_pipeline=read(packet/'qualification-order-failure/pipeline.json')")
    end = text.index("assert state['subjects']", start)
    text = text[:start]+text[end:]
    text = text.replace('Current 0c949 retained expanded-worker source', 'Current ef5 retained dimension-scan source').replace('qualified standard 6CE control', 'qualified standard3c09 control').replace('exact 0c949 source', 'exact ef5 source').replace('Standard6CE from qualified packet44', 'Standard3c09 from qualified packet48')
    needle = "assert {r['name'] for r in training} == training_names\n"
    addition = """fixed=read(packet/'fixed-corpus-plan.json')
assert set(fixed['training'])==training_names and fixed['benchmark_in_training']
assert fixed['leave_deflate_out_plan']['training']==fixed['training'][1:]
assert fixed['heldout']==['numeric-nested-phase-states','numeric-changing-capture-tree','numeric-multiple-children','scalar-u64-divide','scalar-i64-add','scalar-i64-multiply','scalar-f64-divide']
case_profiles=[]
for case in training:
    item=read(packet/'training'/case['name']/'profile-pin.json')
    assert item in profile_pins
    assert pin(packet/'raw'/Path(item['path']).name)=={key:item[key] for key in ['bytes','sha256']}
    case_profiles.append(item['path'])
assert len(set(case_profiles))==8
"""
    assert text.count(needle)==1
    return text.replace(needle, needle+addition)

derive('replay', replay)
def curate(text):
    text = text.replace('parallel-phase-cleanup-apple-m3-20261115', 'dimension-declaration-scan-apple-m3-20261115')
    start = text.index("for name in ['mech-setup-")
    end = text.index("shutil.copy2(__file__,packet/'curate.py')", start)
    names = ['mech-setup-dimension-native-pgo-20261115.py', 'mech-dimension-native-pgo-pipeline-20261115.py', 'mech-qualify-dimension-native-pgo-20261115.py', 'mech-prepare-dimension-native-pgo-qualification-20261115.py', 'mech-prepare-dimension-native-pgo-evidence-20261115.py', 'mech-pack-dimension-native-pgo-20261115.py', 'mech-publish-dimension-native-pgo-20261115.py', 'mech-decide-dimension-native-pgo-20261115.py']
    footer = 'for name in '+repr(names)+":\n    shutil.copy2(Path('/private/tmp')/name,packet/name)\n"
    text = text[:start]+footer+text[end:]
    return text.replace('mech-replay-parallel-native-pgo', 'mech-replay-dimension-native-pgo')
derive('curate', curate)
original = tmp/'mech-store-parallel-native-pgo-profiles-20261115.py'
derived = tmp/'mech-store-dimension-native-pgo-profiles-20261115.py'
text = original.read_text().replace('mech-parallel-native-pgo', 'mech-dimension-native-pgo')
ast.parse(text)
assert not derived.exists()
derived.write_text(text)
records.append(dict(original=str(original), original_sha256=sha(original), derived=str(derived), derived_sha256=sha(derived)))
derive('pack')
def publish(text):
    text = text.replace('assert len(previous)==44 and index[\'total_archive_bytes\']==1339519056', 'assert len(previous)==48 and index[\'total_archive_bytes\']==1536980034')
    assert 'len(previous)==48' in text
    return text
derive('publish', publish)
def decide(text):
    return text.replace('current expanded-worker source 0c949', 'current dimension-scan source ef5').replace('14.027480958262458', '13.596783062268514').replace('Historical d26 source', 'Historical 0c949 source').replace('unprofiled_current_parallel_qualification=\'packet44, separate cohort\'', 'unprofiled_current_parallel_qualification=\'packet48, separate cohort\'').replace('goal_sub10_achieved=False', 'goal_sub10_achieved=retained and candidate_mean < 10')
derive('decide', decide)
(raw/'evidence-derivation.json').write_text(json.dumps(records, indent=2)+'\n')
print(json.dumps(records, indent=2))
