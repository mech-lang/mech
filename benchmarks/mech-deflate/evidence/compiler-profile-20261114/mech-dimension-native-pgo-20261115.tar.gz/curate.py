from pathlib import Path
import hashlib
import json
import shutil
import subprocess

repo=Path.cwd()
raw=Path('/private/tmp/mech-dimension-native-pgo-20261115')
packet=Path('/private/tmp/mech-dimension-native-pgo-packet-20261115')
packet.mkdir(exist_ok=False)
pin=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
excluded=[]
for p in sorted(raw.iterdir()):
    if p.name in ['source','target']:
        continue
    if p.name in ['control','native-control','generate','use']:
        excluded.append(dict(path=p.name,**pin(p)))
        continue
    for q in ([p] if p.is_file() else sorted(p.rglob('*'))):
        if not q.is_file():
            continue
        rel=q.relative_to(raw)
        if rel.as_posix() in ['qualification/control','qualification/candidate','qualification-order-failure/control','qualification-order-failure/candidate']:
            excluded.append(dict(path=rel.as_posix(),**pin(q)))
            continue
        dest=packet/rel
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(q,dest)
revision=json.loads((raw/'source-state.json').read_text())['source_commit']
paths=['.cargo/config.toml','Cargo.toml','Cargo.lock',
       'benchmarks/mech-deflate/native-profile/Cargo.toml',
       'benchmarks/mech-deflate/native-profile/Cargo.lock',
       'benchmarks/mech-deflate/native-profile/compile_profile.rs',
       'benchmarks/mech-deflate/native-profile/profile_compile.py']
source_pins=[]
for name in paths:
    data=subprocess.check_output(['git','show',revision+':'+name])
    assert data==(raw/'source'/name).read_bytes()
    dest=packet/'source-config'/name
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(data)
    source_pins.append(dict(path=name,**pin(dest)))
(packet/'source-config-pins.json').write_text(json.dumps(source_pins,indent=2)+'\n')
for row in json.loads((packet/'qualification/fixture-results.json').read_text()):
    name=row['fixture']
    if name.startswith('hosts/'):
        data=subprocess.check_output(['git','show',revision+':'+name])
        assert data==(raw/'source'/name).read_bytes()
        (packet/'qualification/fixture-inputs'/Path(name).name).write_bytes(data)
prior=repo/'benchmarks/mech-deflate/native-profile'
validation=packet/'validation'
validation.mkdir()
for suffix in ['.json','.archive.json']:
    shutil.copy2(prior/('dimension-declaration-scan-apple-m3-20261115'+suffix),validation/('prior-qualified'+suffix))
reference=json.loads((validation/'prior-qualified.json').read_text())['output_hashes']
assert all(pin(packet/'qualification/reference'/name)==item for name,item in reference.items())
(packet/'qualification/reference-pins.json').write_text(json.dumps(reference,indent=2)+'\n')
link=Path('/private/tmp/mech-pr973-refresh-20261115/link')
capture=json.loads((link/'capture/link-command.json').read_text())
shutil.copy2(link/'capture/link-command.json',packet/'link-command.json')
shutil.copy2(link/'baseline-pins.json',packet/'native-baseline-pins.json')
shutil.copy2(link/'build.json',packet/'historical-adapter-build.json')
inputs=[]
for at,row in enumerate(capture['inputs']):
    p=Path(row['retained_path'])
    assert pin(p)=={k:row[k] for k in ['bytes','sha256']}
    rel=Path('native-link-inputs')/(str(at)+'-'+p.name)
    dest=packet/rel
    dest.parent.mkdir(exist_ok=True)
    shutil.copy2(p,dest)
    inputs.append(dict(source=row['source'],path=rel.as_posix(),**pin(dest)))
(packet/'native-link-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
shutil.copytree('/private/tmp/mech-round2-planning-packet-20261114/licenses',packet/'licenses')
originals=packet/'qualification-scripts/originals'
originals.mkdir()
for row in json.loads((packet/'qualification-scripts/derivation.json').read_text()):
    p=Path(row['original'])
    assert pin(p)['sha256']==row['original_sha256']
    shutil.copy2(p,originals/p.name)
for name in ['mech-setup-dimension-native-pgo-20261115.py', 'mech-dimension-native-pgo-pipeline-20261115.py', 'mech-qualify-dimension-native-pgo-20261115.py', 'mech-prepare-dimension-native-pgo-qualification-20261115.py', 'mech-prepare-dimension-native-pgo-evidence-20261115.py', 'mech-pack-dimension-native-pgo-20261115.py', 'mech-publish-dimension-native-pgo-20261115.py', 'mech-decide-dimension-native-pgo-20261115.py', 'mech-docs-dimension-native-pgo-20261115.py']:
    shutil.copy2(Path('/private/tmp')/name,packet/name)
shutil.copy2(__file__,packet/'curate.py')
shutil.copy2('/private/tmp/mech-replay-dimension-native-pgo-20261115.py',packet/'replay.py')
for subdir in ['evidence-originals','evidence-derived']:
    (packet/subdir).mkdir()
for row in json.loads((raw/'evidence-derivation.json').read_text()):
    for key, subdir in [('original','evidence-originals'),('derived','evidence-derived')]:
        path=Path(row[key])
        assert pin(path)['sha256']==row[key+'_sha256']
        shutil.copy2(path,packet/subdir/path.name)
(packet/'excluded-compiler-products.json').write_text(json.dumps(excluded,indent=2)+'\n')
print(packet)
