from pathlib import Path
import ast
import datetime
import hashlib
import json
import shutil
import subprocess
import sys
import time

repo = Path.cwd()
root = Path('/private/tmp/mech-dimension-native-pgo-20261115')
rows = json.loads((root/'qualification/pipeline.json').read_text())
assert len(rows)==8 and all(row['state']=='complete' and row['exit_code']==0 for row in rows)
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
sha = lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
path = root/'evidence-derivation.json'
derivation = json.loads(path.read_text())
for item in derivation:
    original, derived = Path(item['original']), Path(item['derived'])
    assert sha(original)==item['original_sha256']
    ast.parse(derived.read_text())
    item['derived_sha256']=sha(derived)
    item['final_preexecution_audit']='Final current-source helper hashes; include and replay-check originals/derived recipes. All compiler builds and timed qualification already complete; no measurements changed.'
path.write_text(json.dumps(derivation,indent=2)+'\n')
shutil.copy2(__file__,root/'finish.py')
records=[]
stages=[('decision','mech-decide-dimension-native-pgo-20261115.py'),('curate','mech-curate-dimension-native-pgo-20261115.py'),('profile-storage','mech-store-dimension-native-pgo-profiles-20261115.py'),('replay','/private/tmp/mech-dimension-native-pgo-packet-20261115/replay.py'),('pack','mech-pack-dimension-native-pgo-20261115.py'),('publish-verify-replay','mech-publish-dimension-native-pgo-20261115.py'),('docs','mech-docs-dimension-native-pgo-20261115.py')]
for name, helper in stages:
    script=Path(helper) if helper.startswith('/') else Path('/private/tmp')/helper
    command=[sys.executable,str(script)]
    row=dict(stage=name,state='running',command=command,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    records.append(row);(root/'finish-pipeline.json').write_text(json.dumps(records,indent=2)+'\n')
    started=time.monotonic()
    with (root/(name+'.stdout.log')).open('w') as stdout,(root/(name+'.stderr.log')).open('w') as stderr:
        result=subprocess.run(command,cwd=repo,stdout=stdout,stderr=stderr)
    row.update(state='complete' if result.returncode==0 else 'failed',seconds=time.monotonic()-started,exit_code=result.returncode)
    (root/'finish-pipeline.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
    assert result.returncode==0
