from pathlib import Path
import ast
import hashlib
import json
import shutil

root = Path('/private/tmp/mech-dimension-native-pgo-20261115')
prior = Path('/private/tmp/mech-parallel-native-pgo-20261115')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
scripts = root/'qualification-scripts'
scripts.mkdir(exist_ok=False)
shutil.copytree('/private/tmp/mech-dimension-declaration-scan-20261115/fixture-inputs', root/'fixture-input-template')
replacements = {
    str(prior): str(root),
    '/private/tmp/mech-numeric-facts-20261113/fixture-inputs': str(root/'fixture-input-template'),
    '0c949505cc708c233e27c094aa67e105068d6823': 'ef5e255e817eb5bbc6df61b094a3741b31c49da2',
    'Frozen 0c949/6CE standard compiler': 'Frozen ef5/3c09 standard compiler',
}
derivation = []
for original in sorted((prior/'qualification-scripts').glob('*.py')):
    text = original.read_text()
    for before, after in replacements.items():
        text = text.replace(before, after)
    tree = ast.parse(text)
    assert str(prior) not in text
    derived = scripts/original.name
    derived.write_text(text)
    derivation.append(dict(original=str(original), original_sha256=sha(original), derived=derived.name, derived_sha256=sha(derived)))
(scripts/'derivation.json').write_text(json.dumps(derivation, indent=2)+'\n')
original = Path('/private/tmp/mech-qualify-parallel-native-pgo-20261115.py')
text = original.read_text()
for before, after in replacements.items():
    text = text.replace(before, after)
text = text.replace('Qualified standard 6CE compiler', 'Qualified standard3c09 compiler')
tree = ast.parse(text)
loops = [node for node in ast.walk(tree) if isinstance(node, ast.For) and isinstance(node.target, ast.Tuple) and [getattr(x, 'id', '') for x in node.target.elts] == ['stage', 'name']]
assert len(loops) == 1
stages = ast.literal_eval(loops[0].iter)
expected = ['screens', 'cached-executable-gates', 'serial-default-gate', 'real-worker-diagnostic', 'fixtures-object-cohort', 'heldout-cohorts', 'native-cohort', 'parallel-isolation']
assert [stage for stage, name in stages] == expected
assert len(derivation) == 18
assert all((scripts/name).is_file() for stage, name in stages)
for script in scripts.glob('*.py'):
    for node in ast.walk(ast.parse(script.read_text())):
        if isinstance(node, ast.Constant) and isinstance(node.value, str) and node.value.startswith(str(scripts)):
            assert Path(node.value).exists(), (script.name, node.value)
derived = Path('/private/tmp/mech-qualify-dimension-native-pgo-20261115.py')
assert not derived.exists()
derived.write_text(text)
shutil.copy2(derived, root/'qualify.py')
shutil.copy2(original, root/'original-qualify.py')
shutil.copy2(__file__, root/'prepare-qualification.py')
plan = dict(source_commit='ef5e255e817eb5bbc6df61b094a3741b31c49da2', control_sha256=sha(root/'control'), qualification_driver_sha256=sha(derived), actual_ast_stages=[dict(stage=stage, helper=name, helper_sha256=sha(scripts/name)) for stage, name in stages], helpers=18, primary_cohorts=dict(object=['control1', 'candidate1', 'candidate2', 'control2', 'candidate3', 'control3', 'control4', 'candidate4'], native='Same ABBA/BAAB order, separate fresh compiles.', isolation='Candidate binary only, 0/2 workers, separate ABBA/BAAB.'), scope='All builds/training finish before this driver. Complete source/MBC/Object/metadata and executable gates. Default0 and real344/48 jobs are actual driver stages, verified from AST. Same61 program flags and2workers for control/candidate; adapter cached. Historical observations are not pooled or added.')
(root/'qualification-plan.json').write_text(json.dumps(plan, indent=2)+'\n')
print(json.dumps(plan, indent=2))
