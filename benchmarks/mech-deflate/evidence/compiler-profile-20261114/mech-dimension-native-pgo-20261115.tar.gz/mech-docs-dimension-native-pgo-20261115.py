from pathlib import Path
import json
import statistics

repo = Path.cwd()
base = repo/'benchmarks/mech-deflate/native-profile'
summary = json.loads((base/'dimension-native-pgo-apple-m3-20261115.json').read_text())
receipt = json.loads((base/'dimension-native-pgo-apple-m3-20261115.archive.json').read_text())
index = json.loads((repo/'benchmarks/mech-deflate/evidence/compiler-profile-20261114/index.json').read_text())
assert len(index['packets']) == 49
assert summary['source_commit'] == 'ef5e255e817eb5bbc6df61b094a3741b31c49da2'
native = summary['native_cohort']['numerical_summary']
obj = summary['numerical_summary']
iso = summary['parallel_isolation_numerical_summary']
mean = statistics.mean
value = lambda rows, name: mean(rows[name])
change = lambda rows: -100*rows['mean_reduction_fraction']
main = native['source_to_executable_seconds']
parallel = iso['source_to_executable_seconds']
decision = summary['decision']
full_blocks = summary['native_cohort']['balanced_blocks']
heldout = summary['held_out_compilation']
faster_heldouts = sum(case['numerical_summary']['whole_process_seconds']['mean_reduction_fraction'] > 0 for case in heldout)
table = []
for label, key in [('Complete source to executable', 'source_to_executable_seconds'), ('Source-to-Object process', 'source_to_object_process_seconds'), ('Object handoff', 'object_handoff_seconds'), ('Final native link', 'native_link_seconds')]:
    rows = native[key]
    table.append(f"| {label} | {value(rows,'control'):.6f} s | {value(rows,'candidate'):.6f} s | {change(rows):+.2f}% |")
stage_table = []
for label, key in [('Internal compiler', 'compiler_seconds'), ('Parser', 'parse_seconds'), ('Checked frontend', 'frontend_seconds'), ('Native preparation', 'preparation_seconds'), ('Numeric helper generation', 'numeric_generation_seconds'), ('Main source CFG', 'source_cfg_seconds'), ('Cleanup including compaction', 'cleanup_including_compaction_seconds'), ('Instructions retired', 'instructions'), ('Maximum RSS', 'max_rss_bytes')]:
    rows = obj[key]
    stage_table.append(f"| {label} | {value(rows,'control'):.6f} | {value(rows,'candidate'):.6f} | {change(rows):+.2f}% |")
heldout_table = []
for case in heldout:
    rows = case['numerical_summary']
    heldout_table.append(f"| {case['name']} | {change(rows['whole_process_seconds']):+.2f}% | {change(rows['compiler_seconds']):+.2f}% | {change(rows['instructions']):+.2f}% |")
adverse = ', '.join(f"{key} {change(rows):+.2f}%" for key, rows in obj.items() if rows['mean_reduction_fraction'] < 0) or 'none'
status = 'retained' if decision['decision'] == 'retain' else 'rejected'
description = f"""# Fresh PGO after dimension declaration scanning

Complete fresh Deflate source-to-executable builds average **{value(main,'candidate'):.6f} seconds** with native CPU tuning and fresh PGO, versus **{value(main,'control'):.6f} seconds** for the standard compiler ({change(main):+.2f}%). Both use source `ef5e255e817eb5bbc6df61b094a3741b31c49da2`, the same 61 program flags and two compiler workers. The combined compiler configuration is {status}; every complete executable byte matches.

The preceding [source optimization](native-dimension-declaration-scan-compile-profile.md) measured the standard compiler at 14.971381 seconds. That is a separate cohort. The earlier [Deflate-trained PGO result](native-parallel-pgo-compile-profile.md), 13.596783 seconds, belongs to source `0c949505cc`. This experiment rebuilds instrumentation and profile use from current source. It does not reuse the older profiles, add percentages or infer an old-versus-new PGO improvement from separate historical means.

## Complete build boundary

| Boundary | Standard | Native CPU + PGO | Change |
| --- | ---: | ---: | ---: |
{chr(10).join(table)}

The two balanced complete-build blocks change {-100*full_blocks[0]['mean_reduction_fraction']:+.2f}% and {-100*full_blocks[1]['mean_reduction_fraction']:+.2f}%. Four observations per subject use serial ABBA/BAAB order. Every observation starts fresh source assembly and ends after the final native link process completes. The fixed runtime and entry adapter are cached and hash-pinned; historical first-use adapter construction of 11.882560208 seconds is separate. All compiler builds and training finish before qualification. No heavy build, test, sampling, hashing or packaging overlaps primary timing.

A separate eight-build cohort changes only worker count on one immutable current PGO binary: **{value(parallel,'serial'):.6f} seconds serial versus {value(parallel,'parallel'):.6f} seconds with two workers ({change(parallel):+.2f}%)**. It is separate from the standard/PGO comparison. Default `MECH_COMPACT_COMPILE_THREADS=0` remains serial; `=2` enables workers.

## Compiler work and held-out fixtures

The separate eight-observation Object cohort records seconds for durations and whole counts for instructions and bytes.

| Work | Standard | Native CPU + PGO | Change |
| --- | ---: | ---: | ---: |
{chr(10).join(stage_table)}

Adverse Object fields: {adverse}. All observations, stage stamps, counters, blocks and adverse native-link/handoff results remain in the [complete summary](../../benchmarks/mech-deflate/native-profile/dimension-native-pgo-apple-m3-20261115.json). Intervals do not represent exclusive CPU attribution.

| Held-out program | Process time change | Internal compiler change | Instruction change |
| --- | ---: | ---: | ---: |
{chr(10).join(heldout_table)}

The fixed training corpus is Deflate, numeric-nested-phase, numeric-private-fixed-nested, numeric-array-windows, scalar-bool-equal, scalar-u64-add, scalar-i64-divide and scalar-f64-add. Deflate is included in this training corpus. The seven disjoint heldouts are small scalar/numeric fixtures; {faster_heldouts} of seven improve in whole-process time. This does not establish gains on unrelated substantial programs. Each heldout uses its own eight serial ABBA/BAAB observations; no pooled tiny-program percentage is used.

The corpus and an additional seven-profile set excluding Deflate were fixed before any new compiler build or observed outcome. The latter configuration is only a recorded plan and is not built or qualified here. Native CPU tuning is hardware specific, and no CPU-only subject is measured. The comparison therefore measures CPU tuning and PGO together.

## Reproduction and unchanged program

The standard control is the qualified current-source compiler with SHA-256 `3c09f358909db5ab07d09a9ee78a16d3de83f58d9f181f750985e7f3a88653f3`. Fresh instrumented and profile-use builds use nightly-2026-03-03, explicit `aarch64-apple-darwin`, compiler ThinLTO/CGU1, four Cargo jobs, incremental compilation disabled, preserved `-D warnings`, native CPU and matching Rust LLVM profdata. Instrumented construction takes {summary['compiler_builds']['generate']['seconds']:.3f} seconds; profile-use construction takes {summary['compiler_builds']['use']['seconds']:.3f} seconds. Both and training are excluded from Deflate timing. All diagnostics, including missing-function warnings, are retained.

All eight training outputs, 14 fixture pairs, 56 heldout compilations, eight Object observations, two preliminary executable gates, default-serial gate, real-worker diagnostic, eight primary native builds and eight serial/two-worker native builds preserve the complete applicable outputs. The worker diagnostic records 344 submitted jobs including 48 cleanup-and-machine jobs. All 20 complete executables match the frozen 2,060,440-byte executable, SHA-256 `d6c65cc3fb18acc4be77dce329962105bf0f2b56dd2623a12f466256463eca61`. Source, bytecode, Object and complete metadata all match. No separate runtime timing campaign is claimed; the executable images are identical.

The qualification driver is checked from its actual AST against all eight planned stages and helper hashes before running. The forty-ninth [repository packet](../../benchmarks/mech-deflate/evidence/compiler-profile-20261114/README.md) retains every raw profile, merged profile, per-case profile association, source configuration, recipe/derivation, diagnostic, observation, output, complete executable and fixed native link input. All profile bytes are stored losslessly in a nested XZ archive and stream-verified against their original pins. Compiler binaries, dependency targets and full source checkout are excluded and hash/Git pinned. Fresh repository extraction verifies the archive and replays its full summary byte-identically. Compilation below ten seconds remains open.
"""
report = repo/'docs/design/native-dimension-pgo-compile-profile.md'
assert not report.exists()
report.write_text(description)
paragraph = f"""The fresh [current-source PGO qualification]({{link}}) measures complete Deflate compilation **{value(main,'control'):.6f} to {value(main,'candidate'):.6f} seconds ({change(main):+.2f}%)** on source `ef5e255e81`, with both subjects using two workers. Every complete executable byte matches. The separate same-PGO-binary serial/two-worker cohort measures {value(parallel,'serial'):.6f} to {value(parallel,'parallel'):.6f} seconds ({change(parallel):+.2f}%). These experiments remain separate from the earlier 14.971381-second standard result and 13.596783-second older-source PGO result. Deflate is included in the fixed eight-program training corpus; seven small heldouts do not establish broad generalization. The forty-ninth packet preserves all profiles, diagnostic/adverse fields, observations, complete outputs and 20 complete executables. Fresh extraction verifies and replays byte-identically. No production source, grammar or runtime changes; the sub-ten-second goal remains open.
"""
for path, link in [(base/'README.md', '../../../docs/design/native-dimension-pgo-compile-profile.md'), (repo/'benchmarks/mech-deflate/EXPERIMENTS.md', '../../docs/design/native-dimension-pgo-compile-profile.md')]:
    with path.open('a') as out:
        out.write('\n'+paragraph.format(link=link))
path = repo/'benchmarks/mech-deflate/evidence/compiler-profile-20261114/README.md'
text = path.read_text().replace('Forty-eight complete evidence packets', 'Forty-nine complete evidence packets').replace('All forty-eight repository copies', 'All forty-nine repository copies')
text = text.replace('1,536,980,034 bytes (1,537.0 MB)', f"{index['total_archive_bytes']:,} bytes ({index['total_archive_bytes']/1e6:,.1f} MB)")
lines = text.splitlines()
at = next(i for i, line in enumerate(lines) if line.startswith('| Fused dimension declaration scans |'))
lines.insert(at+1, f"| Fresh PGO after dimension scanning (Deflate-trained) | {status.capitalize()}: complete build {value(main,'candidate'):.3f}s; matched standard change {change(main):+.2f}%. Seven small heldouts; no broad generalization claim. All outputs/20 executables exact. | [mech-dimension-native-pgo-20261115.tar.gz](mech-dimension-native-pgo-20261115.tar.gz) | [Receipt](../../native-profile/dimension-native-pgo-apple-m3-20261115.archive.json) / [result](../../native-profile/dimension-native-pgo-apple-m3-20261115.json) | {receipt['files']:,} |")
path.write_text('\n'.join(lines)+'\n\n'+paragraph.format(link='../../../../docs/design/native-dimension-pgo-compile-profile.md'))
print(report)
