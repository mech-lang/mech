from pathlib import Path, PurePosixPath
import ast
import datetime
import hashlib
import json
import shutil
import subprocess
import tarfile
import time
import tomllib

repo = Path.cwd()
root = Path('/private/tmp/mech-dimension-native-pgo-20261115')
revision = 'ef5e255e817eb5bbc6df61b094a3741b31c49da2'
standard = Path('/private/tmp/mech-dimension-declaration-scan-20261115')
older_pgo = Path('/private/tmp/mech-parallel-native-pgo-20261115')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert not root.exists()
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--name-only', revision, 'HEAD', '--', 'src', 'hosts', 'vendor', 'Cargo.toml', 'Cargo.lock', '.cargo', 'benchmarks/mech-deflate/native-profile/compile_profile.rs', 'benchmarks/mech-deflate/native-profile/Cargo.toml', 'benchmarks/mech-deflate/native-profile/Cargo.lock'], text=True).strip()
assert sha(standard/'candidate') == '3c09f358909db5ab07d09a9ee78a16d3de83f58d9f181f750985e7f3a88653f3'
assert sha(older_pgo/'use') == '6fc6db8164c3f0a66fc5d968fd42f72fe5daf11ca8e89dea00b430530989a797'
root.mkdir()
source = root/'source'
source.mkdir()
command = ['git', 'archive', '--format=tar', revision, '--', '.', ':(exclude)benchmarks/mech-deflate/evidence']
started = time.monotonic()
process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=(root/'source-archive.stderr.log').open('w'))
files = 0
with tarfile.open(fileobj=process.stdout, mode='r|') as archive:
    for entry in archive:
        path = PurePosixPath(entry.name)
        assert not path.is_absolute() and '..' not in path.parts
        archive.extract(entry, source, filter='data')
        files += entry.isfile()
assert process.wait() == 0
assert tomllib.loads((source/'.cargo/config.toml').read_text())['build']['rustflags'] == ['-D', 'warnings']
state = dict(source_commit=revision, evidence_head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(), source_tree=subprocess.check_output(['git', 'rev-parse', revision+'^{tree}'], text=True).strip(), archive_command=command, excluded_path='benchmarks/mech-deflate/evidence (raw archives/index do not enter compilation)', files_extracted=files, seconds=time.monotonic()-started, created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), scope='Current retained dimension-scan source. Reuse qualified standard3c09 as same-source control. Build fresh nativeCPU instrumentation/training and nativeCPU profile use. Fixed eight training cases include Deflate; no broad generalization or additive historical speedup claim. No production source edits.')
(root/'source-state.json').write_text(json.dumps(state, indent=2)+'\n')
shutil.copy2(standard/'candidate', root/'control')
shutil.copytree(standard/'reference', root/'reference')
shutil.copy2(standard/'runtime-flags.json', root/'runtime-flags.json')
assert json.loads((root/'runtime-flags.json').read_text()) == json.loads((older_pgo/'runtime-flags.json').read_text())
assert len(json.loads((root/'runtime-flags.json').read_text())) == 61
shutil.copytree(standard/'fixtures', root/'fixture-reference')
shutil.copy2(standard/'fixture-results.json', root/'fixture-reference-results.json')
shutil.copy2(repo/'benchmarks/mech-deflate/native-profile/dimension-declaration-scan-apple-m3-20261115.archive.json', root/'control-source-evidence-receipt.json')
commands = {
    'rustc-version': ['rustc', '+nightly-2026-03-03', '-Vv'],
    'rustc-sysroot': ['rustc', '+nightly-2026-03-03', '--print', 'sysroot'],
    'target-cpus': ['rustc', '+nightly-2026-03-03', '--print', 'target-cpus', '--target', 'aarch64-apple-darwin'],
    'generic-target-cfg': ['rustc', '+nightly-2026-03-03', '--print', 'cfg', '--target', 'aarch64-apple-darwin'],
    'native-target-cfg': ['rustc', '+nightly-2026-03-03', '--print', 'cfg', '--target', 'aarch64-apple-darwin', '-C', 'target-cpu=native'],
    'cpu': ['sysctl', '-n', 'machdep.cpu.brand_string'],
    'cpu-count': ['sysctl', '-n', 'hw.ncpu'],
    'memory': ['sysctl', '-n', 'hw.memsize'],
    'os': ['sw_vers', '-productVersion'],
}
for name, args in commands.items():
    result = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    (root/(name+'.txt')).write_text(result.stdout)
    (root/(name+'.stderr.log')).write_text(result.stderr)
    assert result.returncode == 0, (name, result.stderr)
sysroot = Path((root/'rustc-sysroot.txt').read_text().strip())
profdata = sysroot/'lib/rustlib/aarch64-apple-darwin/bin/llvm-profdata'
assert profdata.is_file()
(root/'llvm-profdata-path.txt').write_text(str(profdata)+'\n')
(root/'llvm-profdata-version.txt').write_text(subprocess.check_output([str(profdata), '--version'], text=True))
(root/'setup-commands.json').write_text(json.dumps(commands, indent=2)+'\n')
(root/'control-reuse.json').write_text(json.dumps(dict(binary=str(root/'control'), bytes=(root/'control').stat().st_size, sha256=sha(root/'control'), source_commit=revision, source_evidence_packet=48, standard_build=json.loads((standard/'candidate-build.json').read_text()), scope='Exact retained standard3c09; no duplicate standard build. Combined nativeCPU+PGO comparison on same current source. Older PGO6fc/profile7174 preserved in separate root, never substituted.'), indent=2)+'\n')
training = ['level12-deflate', 'numeric-nested-phase', 'numeric-private-fixed-nested', 'numeric-array-windows', 'scalar-bool-equal', 'scalar-u64-add', 'scalar-i64-divide', 'scalar-f64-add']
heldout = ['numeric-nested-phase-states', 'numeric-changing-capture-tree', 'numeric-multiple-children', 'scalar-u64-divide', 'scalar-i64-add', 'scalar-i64-multiply', 'scalar-f64-divide']
(root/'fixed-corpus-plan.json').write_text(json.dumps(dict(training=training, heldout=heldout, benchmark_in_training=True, label='Deflate-trained PGO', leave_deflate_out_plan=dict(training=training[1:], selection='Fixed before any new compiler build or outcomes; may merge an additional seven-profile set from the fresh raw eight. No heldout feedback may select inputs.', qualification_pending=True), scope='Same predetermined packet45 corpus; small heldouts do not establish broad generalization.'), indent=2)+'\n')
original = Path('/private/tmp/mech-parallel-native-pgo-pipeline-20261115.py')
text = original.read_text()
replacements = {
    '/private/tmp/mech-parallel-native-pgo-20261115': str(root),
    '0c949505cc708c233e27c094aa67e105068d6823': revision,
    '6ce7a53b36d3677cf3b20d919657d2824b7d8561ef5eeaf254377626f27980ae': sha(root/'control'),
}
for before, after in replacements.items():
    assert before in text
    text = text.replace(before, after)
before = "        started=time.monotonic()\n        with (directory/'stdout.jsonl').open('w') as stdout,(directory/'stderr.log').open('w') as stderr:\n"
after = "        raw_before=set((root/'raw').glob('*.profraw'))\n"+before
assert text.count(before) == 1
text = text.replace(before, after)
before = "        expected=root/'reference' if name=='level12-deflate' else root/'fixture-reference'/name/'control'\n"
after = "        raw_new=set((root/'raw').glob('*.profraw'))-raw_before\n        assert len(raw_new)==1\n        (directory/'profile-pin.json').write_text(json.dumps(dict(path=str(next(iter(raw_new))),**pin(next(iter(raw_new)))),indent=2)+'\\n')\n"+before
assert text.count(before) == 1
text = text.replace(before, after)
ast.parse(text)
derived = Path('/private/tmp/mech-dimension-native-pgo-pipeline-20261115.py')
assert not derived.exists()
derived.write_text(text)
shutil.copy2(original, root/'original-build-pipeline.py')
shutil.copy2(derived, root/'build-pipeline.py')
shutil.copy2(__file__, root/'setup.py')
(root/'build-derivation.json').write_text(json.dumps(dict(original=str(original), original_sha256=sha(original), derived=str(derived), derived_sha256=sha(derived), replacements=replacements, additional_change='Record each training case fresh raw profile before/after; fixed leave-Deflate-out set declared before outcomes.'), indent=2)+'\n')
state['setup_complete'] = True
(root/'source-state.json').write_text(json.dumps(state, indent=2)+'\n')
print(json.dumps(state), flush=True)
