from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path('/private/tmp/mech-batch-phi-params-20261115');out=r/'focused';assert json.loads((r/'candidate-build.json').read_text())['exit_code']==0
rows=[json.loads(x) for x in (r/'candidate-build.jsonl').read_text().splitlines()]
command=['rustc','+nightly-2026-03-03','--edition=2024','--crate-name','batch_phi_parameter_tests','--test',str(out/'harness.rs'),'-C','opt-level=3','-C','lto=thin','-C','codegen-units=1','-D','warnings','-o',str(out/'tests')];directories=set();dependencies=[]
for name in ['cranelift_codegen','cranelift_native','cranelift_entity','bumpalo','smallvec','log','serde_json']:
 paths=[Path(p) for row in rows if row.get('reason')=='compiler-artifact' and row['target']['name']==name for p in row['filenames'] if p.endswith('.rlib')];assert len(paths)==1;path=paths[0];directories.add(path.parent);command+=['--extern',name+'='+str(path)];dependencies.append(dict(name=name,path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
for path in sorted(directories):command+=['-L','dependency='+str(path)]
(out/'command.json').write_text(json.dumps(dict(command=command,dependencies=dependencies,scope='Exact entire old/new constant-phi modules, actualcandidateDFG API fromfrozencompilerbuild, exactnewDFGunitfunctionbodies extractedfromcandidate snapshot. 2047 masks+20wide/poolcases and128 pairedcompleteIR/aliases/types/params/AArch64machine cases.'),indent=2)+'\n')
start=time.monotonic()
with (out/'build.stdout.log').open('w') as stdout,(out/'build.stderr.log').open('w') as stderr:completed=subprocess.run(command,stdout=stdout,stderr=stderr)
row=dict(exit_code=completed.returncode,seconds=time.monotonic()-start);(out/'build.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True);assert completed.returncode==0
start=time.monotonic();env=dict(os.environ,MECH_BATCH_PHI_TEST_OUTPUT=str(out))
with (out/'test.stdout.log').open('w') as stdout,(out/'test.stderr.log').open('w') as stderr:completed=subprocess.run([str(out/'tests'),'--nocapture'],env=env,stdout=stdout,stderr=stderr)
row=dict(exit_code=completed.returncode,seconds=time.monotonic()-start,binary_sha256=hashlib.sha256((out/'tests').read_bytes()).hexdigest());(out/'test.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True);assert completed.returncode==0
cases=[json.loads(x) for x in (out/'ir-cases.jsonl').read_text().splitlines()];assert len(cases)==128 and all(r['identical'] for r in cases);(out/'result.json').write_text(json.dumps(dict(unit_tests=3,small_masks=2047,wide_cases=20,paired_ir_cases=128,all_identical=True,cases_sha256=hashlib.sha256((out/'ir-cases.jsonl').read_bytes()).hexdigest()),indent=2)+'\n')
