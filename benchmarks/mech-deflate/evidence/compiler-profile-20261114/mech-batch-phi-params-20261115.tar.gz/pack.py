from pathlib import Path
import hashlib,json,shutil,subprocess,sys
repo=Path.cwd();raw=Path('/private/tmp/mech-batch-phi-params-20261115');packet=Path('/private/tmp/mech-batch-phi-params-packet-20261115');source='5d0b9cec8b8dd1bbc367db97a51268199accf1a1'
assert json.loads((packet/'decision.json').read_text())['retain_source_change'] is False
assert json.loads((packet/'restoration.json').read_text())['source_commit']==source
shutil.copy2(__file__,packet/'pack.py')
archive=Path('/private/tmp/mech-batch-phi-params-20261115.tar.gz');archive_path=Path('benchmarks/mech-deflate/evidence/compiler-profile-20261114')/archive.name
summary_path=Path('benchmarks/mech-deflate/native-profile/batch-phi-params-apple-m3-20261115.json');receipt_path=summary_path.with_suffix('.archive.json')
command=[sys.executable,'benchmarks/mech-deflate/experiment.py','pack','--revision',source,'--input',str(packet),'--output',str(archive)]
with (raw/'pack.stdout.log').open('w') as stdout,(raw/'pack.stderr.log').open('w') as stderr:result=subprocess.run(command,stdout=stdout,stderr=stderr)
assert result.returncode==0
receipt=json.loads((raw/'pack.stdout.log').read_text());assert receipt['source_revision']==source
shutil.copy2(archive,repo/archive_path);shutil.copy2(packet/'summary.json',repo/summary_path)
replay_bytes=(packet/'summary.json').read_bytes();receipt.update(publication='repository',repository='mech-lang/mech',repository_path=archive_path.as_posix(),replay_sha256=hashlib.sha256(replay_bytes).hexdigest(),replay_byte_identical=True)
(repo/receipt_path).write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
extracted=Path('/private/tmp/mech-batch-phi-params-repository-verified-20261115');assert not extracted.exists()
command=[sys.executable,'benchmarks/mech-deflate/experiment.py','verify',archive_path.as_posix(),'--receipt',receipt_path.as_posix(),'--extract',str(extracted),'--result',str(raw/'repository-verification.json')]
with (raw/'verify.stdout.log').open('w') as stdout,(raw/'verify.stderr.log').open('w') as stderr:result=subprocess.run(command,stdout=stdout,stderr=stderr)
assert result.returncode==0
verification=json.loads((raw/'repository-verification.json').read_text());receipt['verification']=verification
(repo/receipt_path).write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
with (raw/'repository-replay.stdout.log').open('w') as stdout,(raw/'repository-replay.stderr.log').open('w') as stderr:result=subprocess.run([sys.executable,str(extracted/'replay.py')],stdout=stdout,stderr=stderr)
assert result.returncode==0 and (raw/'repository-replay.stdout.log').read_bytes()==replay_bytes
index_path=repo/'benchmarks/mech-deflate/evidence/compiler-profile-20261114/index.json';index=json.loads(index_path.read_text());previous=json.loads(json.dumps(index['packets']));assert len(previous)==41 and index['total_archive_bytes']==1212354076
row=dict(archive=archive_path.as_posix(),bytes=receipt['bytes'],decision='Rejected: completebuild15.414733->15.444185s(+0.19%) withmixedblocks, despite Objectcompiler-0.66%, cleanup-2.58% andinstructions-0.82%. Allartifacts/fullmetadata/wholeexe exact. Threefocusedtests,2047removal masks,20widecases,128completeIR/alias/type/parameter/machine pairs pass. Stablebatch onlychanges selectedparameter bookkeeping; unchangedsolver/replacements/aliasorder. OriginalsourceandstdDD7 restored, PGO5a1 untouched; no newdefaultserial gate ornewPGOqualification.',files=receipt['files'],receipt=receipt_path.as_posix(),sha256=receipt['sha256'],source_revision=source,summary=summary_path.as_posix())
index['packets'].append(row);index['total_archive_bytes']+=row['bytes'];assert index['packets'][:-1]==previous
index_path.write_text(json.dumps(index,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(receipt=receipt,total_archive_bytes=index['total_archive_bytes'],packets=len(index['packets'])),indent=2),flush=True)
