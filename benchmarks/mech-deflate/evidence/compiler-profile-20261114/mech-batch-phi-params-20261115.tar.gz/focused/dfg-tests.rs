use cranelift_codegen::ir::{DataFlowGraph, types};
use alloc::vec::Vec;
    #[test]
    fn batch_block_parameter_removal_matches_repeated_masks() {
        for count in 0..=10 {
            for mask in 0..1u32 << count {
                let mut reference = DataFlowGraph::new();
                let block = reference.make_block();
                let other = reference.make_block();
                let types = [types::I8, types::I16, types::I32, types::I64, types::F32];
                let params = (0..count)
                    .map(|index| reference.append_block_param(block, types[index % types.len()]))
                    .collect::<Vec<_>>();
                reference.append_block_param(other, types::F64);
                let removed = params
                    .iter()
                    .enumerate()
                    .filter_map(|(index, &value)| (mask & (1 << index) != 0).then_some(value))
                    .collect::<Vec<_>>();
                let mut batch = reference.clone();
                for &value in removed.iter().rev() {
                    reference.remove_block_param(value);
                }
                batch.remove_block_params(block, removed.iter().copied());
                assert_eq!(reference.block_params(block), batch.block_params(block));
                assert_eq!(reference.block_params(other), batch.block_params(other));
                assert_eq!(reference.num_values(), batch.num_values());
                for value in params {
                    assert_eq!(reference.value_def(value), batch.value_def(value));
                    assert_eq!(reference.value_type(value), batch.value_type(value));
                    assert_eq!(
                        reference.value_is_attached(value),
                        batch.value_is_attached(value)
                    );
                }
                for ty in [types::I64, types::F32] {
                    assert_eq!(
                        reference.append_block_param(block, ty),
                        batch.append_block_param(block, ty)
                    );
                }
                assert_eq!(reference.block_params(block), batch.block_params(block));
            }
        }
    }

    #[test]
    fn batch_block_parameter_removal_at_pool_and_ordinal_boundaries() {
        for count in [31, 32, 33, 255, 256, 257, 1023, 1024, 1025, 65_535] {
            for all in [false, true] {
                let mut reference = DataFlowGraph::new();
                let block = reference.make_block();
                let params = (0..count)
                    .map(|_| reference.append_block_param(block, types::I64))
                    .collect::<Vec<_>>();
                let removed = params
                    .iter()
                    .enumerate()
                    .filter_map(|(index, &value)| {
                        (all || [0, count / 3, count / 2, count - 1].contains(&index))
                            .then_some(value)
                    })
                    .collect::<Vec<_>>();
                let mut batch = reference.clone();
                for &value in removed.iter().rev() {
                    reference.remove_block_param(value);
                }
                batch.remove_block_params(block, removed.iter().copied());
                assert_eq!(reference.block_params(block), batch.block_params(block));
                for value in params {
                    assert_eq!(reference.value_def(value), batch.value_def(value));
                    assert_eq!(reference.value_type(value), batch.value_type(value));
                    assert_eq!(
                        reference.value_is_attached(value),
                        batch.value_is_attached(value)
                    );
                }
                assert_eq!(
                    reference.append_block_param(block, types::I32),
                    batch.append_block_param(block, types::I32)
                );
                assert_eq!(reference.block_params(block), batch.block_params(block));
            }
        }
    }
