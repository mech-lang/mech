extern crate alloc;
pub use cranelift_codegen::{dominator_tree, ir, timing, FxHashMap, FxHashSet};
#[allow(dead_code)] #[path="reference.rs"] mod reference;
#[allow(dead_code)] #[path="candidate.rs"] mod candidate;
#[path="dfg-tests.rs"] mod dfg_tests;
use cranelift_codegen::cursor::{Cursor, FuncCursor};
use cranelift_codegen::ir::{AbiParam,BlockArg,Function,InstBuilder,Value,types};
use cranelift_codegen::dominator_tree::DominatorTree;
use cranelift_codegen::flowgraph::ControlFlowGraph;
use cranelift_codegen::settings::{self,Configurable};
    fn loop_function(seed: usize, width: usize) -> Function {
        let mut func = Function::new();
        func.signature.params = alloc::vec![
            AbiParam::new(types::I64),
            AbiParam::new(types::I64),
            AbiParam::new(types::I32),
        ];
        func.signature.returns = alloc::vec![AbiParam::new(types::I64)];
        let blocks: Vec<_> = (0..7).map(|_| func.dfg.make_block()).collect();
        let left = func.dfg.append_block_param(blocks[0], types::I64);
        let right = func.dfg.append_block_param(blocks[0], types::I64);
        let cond = func.dfg.append_block_param(blocks[0], types::I32);
        let parameters: Vec<_> = (0..width)
            .map(|_| func.dfg.append_block_param(blocks[3], types::I64))
            .collect();
        let result = func.dfg.append_block_param(blocks[5], types::I64);
        let unreachable = func.dfg.append_block_param(blocks[6], types::I64);
        let mut alias = left;
        for _ in 0..seed % 17 {
            let next = Value::from_u32(func.dfg.num_values() as u32);
            func.dfg.make_invalid_value_for_parser();
            func.dfg.make_value_alias_for_serialization(alias, next);
            alias = next;
        }
        let left_args: Vec<_> = parameters.iter().map(|_| alias.into()).collect();
        let right_args: Vec<_> = parameters
            .iter()
            .enumerate()
            .map(|(slot, _)| if slot % 3 == seed % 3 { right } else { alias }.into())
            .collect();
        let mut cursor = FuncCursor::new(&mut func);
        cursor.insert_block(blocks[0]);
        cursor.ins().brif(cond, blocks[1], &[], blocks[2], &[]);
        cursor.insert_block(blocks[1]);
        cursor.ins().jump(blocks[3], &left_args);
        cursor.insert_block(blocks[2]);
        cursor.ins().jump(blocks[3], &right_args);
        cursor.insert_block(blocks[3]);
        cursor
            .ins()
            .brif(cond, blocks[4], &[], blocks[5], &[parameters[0].into()]);
        cursor.insert_block(blocks[4]);
        let mut back: Vec<_> = parameters.iter().map(|&v| BlockArg::Value(v)).collect();
        if seed % 2 == 0 {
            let constant = cursor.ins().iconst(types::I64, 1);
            back[0] = cursor.ins().iadd(parameters[0], constant).into();
        }
        cursor.ins().jump(blocks[3], &back);
        cursor.insert_block(blocks[5]);
        cursor.ins().return_(&[result]);
        cursor.insert_block(blocks[6]);
        cursor.ins().jump(blocks[6], &[unreachable.into()]);
        func
    }


fn snapshot(mut function:Function) -> serde_json::Value {
 let flags=settings::Flags::new(settings::builder());cranelift_codegen::verify_function(&function,&flags).unwrap();
 let values=(0..function.dfg.num_values()).map(|i|{let v=Value::from_u32(i as u32);(i,function.dfg.value_alias_dest_for_serialization(v).map(|v|v.as_u32()),function.dfg.resolve_aliases(v).as_u32(),function.dfg.value_type(v).to_string(),format!("{:?}",function.dfg.value_def(v)))}).collect::<Vec<_>>();
 let blocks=function.layout.blocks().map(|b|(b.as_u32(),function.dfg.block_params(b).iter().map(|v|v.as_u32()).collect::<Vec<_>>())).collect::<Vec<_>>();
 let text=function.display().to_string();
 let mut settings=settings::builder();settings.set("opt_level","speed").unwrap();settings.set("is_pic","true").unwrap();let isa=cranelift_native::builder().unwrap().finish(settings::Flags::new(settings)).unwrap();
 let mut context=cranelift_codegen::Context::new();std::mem::swap(&mut context.func,&mut function);context.compile(isa.as_ref(),&mut Default::default()).unwrap();
 serde_json::json!({"ir":text,"values":values,"block_parameters":blocks,"machine":context.compiled_code().unwrap().buffer.data()})
}
#[test]
fn constant_phi_complete_ir_aliases_types_parameters_and_machine_code_match() {
 let widths=[1,2,3,8,31,32,33,64,127,128,129,255,256,257,511,512];let mut records=Vec::new();
 for seed in 0..128 {
  let width=widths[seed%widths.len()];let original=loop_function(seed,width);let flags=settings::Flags::new(settings::builder());cranelift_codegen::verify_function(&original,&flags).unwrap();
  let mut left=original.clone();let mut right=original;
  let cfg=ControlFlowGraph::with_function(&left);let mut dom=DominatorTree::with_function(&left,&cfg);reference::do_remove_constant_phis(&mut left,&mut dom);
  let cfg=ControlFlowGraph::with_function(&right);let mut dom=DominatorTree::with_function(&right,&cfg);candidate::do_remove_constant_phis(&mut right,&mut dom);
  let left=snapshot(left);let right=snapshot(right);assert_eq!(left,right,"seed={seed},width={width}");records.push(serde_json::json!({"seed":seed,"width":width,"identical":true,"observation":right}));
 }
 let directory=std::env::var_os("MECH_BATCH_PHI_TEST_OUTPUT").expect("explicit evidence output");let root=std::path::PathBuf::from(directory);let text=records.iter().map(|r|serde_json::to_string(r).unwrap()+"\n").collect::<String>();std::fs::write(root.join("ir-cases.jsonl"),text).unwrap();
}
