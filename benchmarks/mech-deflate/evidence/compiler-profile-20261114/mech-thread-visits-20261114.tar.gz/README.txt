Reusable CFG visit marks, Apple M3, 2026-11-14.
Retain compiler time saving. A block-indexed generation array replaces the
membership-only BTreeSet rebuilt for each value in loop-edge live-out analysis.
No graph, predicate, ownership, liveness, traversal order, error/admission or
optimization decision changes. Scratch storage lives only during optimization
of one immutable native CFG. Each walk starts fresh; generation wrap clears all
marks. There is no semantic proof cache and no reuse across graphs.
Four serial full source-to-Object ABBA observations use the same 54 existing
runtime flags, host process statistics and frozen executables. Compiler bootstrap,
a separate screen, tests and fixtures are excluded. No builds, tests, fixtures,
profiling or archive work overlap the primary timing cohort.
All source, MBC, native Object and complete metadata bytes match the previously
qualified fast 54-flag compressor, for every primary observation and the screen.
The control production source is identical to this trial's base after reverting
the preceding rejected SSA construction candidate. Every output also matches
between control/candidate in six complete additional array/enum programs and
eight Bool/U64/I64/F64 scalar programs, including checked division.
Two focused tests pass. 1,048,576 four-block graph/root/owner-stop combinations
compare complete DFS visitation order with BTreeSet, including cycles and
repeated pending blocks. A separate sparse-ID/overflow test covers generation
wrap. The enum-state helper is assembled by the existing maintained test helper;
any copied historical fragment-only failure is provenance, not a new launch.
Candidate peak RSS is higher with nonoverlapping ranges. This is not a memory
saving. Unchanged-stage timing variation is not attributed to visit marks.
Generated program bytes remain exactly identical, including numeric helpers,
main machine code and metadata. No new compressor runtime latency campaign is
claimed; the preceding rejected trial independently timed this exact control
Object. Do not confuse byte identity here with that rejected candidate's changed
Object and observed slowdowns. Its compact receipt and full replayed result are
included for provenance, with all adverse measurements retained there.
No grammar, language or runtime speed/opt-level tradeoff. Full compilation still
exceeds ten seconds. Source and evidence decisions are separate commits. Raw
files stay outside source Git; compiler executables are represented by source,
commands, hashes and build records. Run python3 replay.py without compiling or
executing generated programs for pure offline reconstruction.
