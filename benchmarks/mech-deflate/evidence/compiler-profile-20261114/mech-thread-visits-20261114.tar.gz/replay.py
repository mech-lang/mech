from pathlib import Path
import json,hashlib,re,statistics
root=Path(__file__).resolve().parent;raw=root/'compiler';read=lambda p:json.loads(p.read_text())
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
state=read(raw/'source-state.json');build=read(raw/'candidate-build.json');control=read(raw/'control-origin.json');prior=read(root/'validation/rejected-ssa.json');prior_receipt=read(root/'validation/rejected-ssa.archive.json')
assert pin(root/'validation/rejected-ssa.json')['sha256']==prior_receipt['replay_sha256']
assert state['control_production_source_identical_to_base'] and build['exit_code']==0 and build['head']==state['base_commit']
assert pin(raw/'candidate.patch')==pin(root/'source-change.patch') and pin(raw/'candidate.patch')['sha256']==build['patch_sha256']==state['patch_sha256']
assert control['sha256']==prior['compiler_binary_sha256']['control']=='f56537463758c6ab00403d7bdead4a1caba2c44342bb9abae9fccb58bd49c522'
assert build['binary_sha256']=='1c59c80c62a7a11bc4693090a8b3618aa159b474908f4ab5a2a40dd38d8cd158'
for r in read(root/'excluded-executables.json'):assert r['sha256']==(control['sha256'] if r['path']=='control' else build['binary_sha256'])
flags=read(raw/'runtime-flags.json');assert len(flags)==54 and flags['MECH_NORMALIZE_DEFAULTED_READ_SETUP']=='1'
expected=prior['output_hashes']['control'];rows=read(raw/'cohort.json');assert [r['variant'] for r in rows]==['control','candidate','candidate','control']
for name in ['candidate-screen',*[r['name'] for r in rows]]:
 d=raw/name;assert read(d/'process.json')['exit_code']==0 and read(d/'process.json')['samples']==0
 command=read(raw/(name+'-command.json'));assert command['flags']==flags
 assert command['binary_sha256']==(control['sha256'] if name.startswith('control-') else build['binary_sha256'])
 for filename,pinned in expected.items():assert pin(d/filename)==pinned and read(d/'output-check.json')[filename]==dict(pinned,matches_previous_qualified_output=True)
for row in rows:
 d=raw/row['name'];assert row['compile']==read(d/'compile.json') and row['process']==read(d/'process.json') and row['files']==read(d/'output-check.json')
 stamps=[json.loads(line) for line in (d/'stages.jsonl').read_text().splitlines()]
 for key,begin,end in [('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]:assert row[key]==next(s['elapsed'] for s in stamps if s['line'].startswith(end))-next(s['elapsed'] for s in stamps if s['line'].startswith(begin))
 for key,pattern in [('max_rss_bytes',r'(\d+)  maximum resident set size'),('instructions',r'(\d+)  instructions retired'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]:assert row[key]==int(re.search(pattern,(d/'stderr.log').read_text()).group(1))
assert read(raw/'visits-test-command.json')['exit_code']==0 and re.findall(r'test result: ok\. (\d+) passed',(raw/'visits-tests.log').read_text())==['2']
source=(root/'source/hosts/gpu/src/native_artifact/program/codegen/cfg_cleanup/threaded_edges/visits.rs').read_text();assert 'assert_eq!(comparisons, 1_048_576)' in source and 'fn generation_wrap_retains_no_visits' in source
fixtures=read(raw/'fixture-results.json');assert len(fixtures)==14
for row in fixtures:
 assert row['all_outputs_match'] and row['variants']['control']==row['variants']['candidate'] and row['variants']['control']['exit_code']==0 and len(row['variants']['control']['files'])==4
 name=Path(row['fixture']).stem if ':' not in row['fixture'] else row['fixture'].split(':')[-1]
 for variant,record in row['variants'].items():
  d=raw/'fixtures'/name/variant;assert read(d/'command.json')['flags']==flags
  assert read(d/'command.json')['binary_sha256']==(control['sha256'] if variant=='control' else build['binary_sha256'])
  for filename,pinned in record['files'].items():assert pin(d/filename)==pinned
  assert record['files']['source.mec']['sha256']==row['source_sha256']
base=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase.mec').read_text();fragment=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase-states.mec').read_text();assembled=base.replace('+> sequence\n','+> sequence\n'+fragment+'\n',1).replace('phase-candidates(values, 1u64, 0u64, permitted, divisor)','#PhaseCandidates(values, permitted, divisor, 1u64, 0u64)',1);assert assembled==(raw/'fixture-inputs/numeric-nested-phase-states.mec').read_text()
fields={'compiler_seconds':lambda r:r['compile']['total_seconds'],'whole_process_seconds':lambda r:r['process']['elapsed_seconds'],'parse_seconds':lambda r:next(p['seconds'] for p in r['compile']['phases'] if p['phase']=='parse'),'frontend_seconds':lambda r:next(p['seconds'] for p in r['compile']['phases'] if p['phase']=='frontend'),'native_seconds':lambda r:next(p['seconds'] for p in r['compile']['phases'] if p['phase']=='native')}
for key in ['canonical_lowering_seconds','preparation_seconds','numeric_generation_seconds','source_cfg_seconds','cleanup_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:fields[key]=lambda r,key=key:r[key]
qualified={key:{v:[f(r) for r in rows if r['variant']==v] for v in ['control','candidate']} for key,f in fields.items()}
for record in qualified.values():record['mean_reduction_fraction']=1-statistics.mean(record['candidate'])/statistics.mean(record['control'])
summary={'source_commit':state['source_commit'],'base_commit':state['base_commit'],'hardware':state['hardware'],'decision':'Retain reusable membership-only visitation storage for loop-edge live-out analysis','flags_count':54,'qualified':qualified,'output_hashes':expected,'compiler_binary_sha256':{'control':control['sha256'],'candidate':build['binary_sha256']},'candidate_patch_sha256':state['patch_sha256'],'candidate_bootstrap_seconds':build['seconds'],'tests':{'focused':2,'differential_graph_walks':1048576,'complete_array_enum_fixtures':6,'scalar_fixtures':8},'fixture_output_comparisons':fixtures,'scope':[
 'Four serial ABBA fresh full source-to-Object observations. No builds, tests, fixtures, CPU profiles or archiving overlap primary timing. Bootstrap and the separate screen are excluded.',
 'Same 54 existing runtime flags and host process statistics for both frozen subjects; current runtime flag discovery comes from the rejected SSA packet, whose 53-flag screens are not pooled.',
 'The prior provisional SSA construction candidate was reverted. Control production source is identical to this trial base, and exact output identity includes its previously qualified fast 54-flag Object.',
 'Only membership-only BTreeSet visitation storage changes. Each value still gets a fresh visited set with the same DFS order, definition-owner stop, dominance checks and live-out decisions. Predicate/ownership/range/admission checks are unchanged.',
 'Scratch marks belong to one optimization invocation on one immutable CFG. No semantic proof is cached or reused across graphs. Generation wrap clears all marks.',
 'All source, MBC, native Object and complete metadata bytes match between every subject, the independent screen and prior qualified fast runtime output. All four outputs also match for six complete array/enum and eight Bool/U64/I64/F64 checked scalar programs.',
 '1,048,576 graph/root/owner combinations compare exact DFS order with ordered sets, including cycles and repeated pending entries. Sparse block IDs and generation overflow are checked separately.',
 'Candidate peak RSS is higher with nonoverlapping ranges; no memory saving is claimed. Unchanged-stage elapsed variation is not attributed to visitation storage. Four compile observations are descriptive, not a statistical population.',
 'No new runtime-speed measurement campaign is claimed. Generated program bytes remain exactly identical, unlike the reverted SSA candidate whose runtime timing found slowdowns.',
 'The copied enum-state assembly provenance includes historical attempts, not a new fragment-only launch. Source, bytecode, Object and metadata comparisons all succeed on complete assembled programs.',
 'No grammar, language, generated-program behavior or backend optimization level change. Full compilation still exceeds ten seconds.'
]}
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
