from pathlib import Path
import subprocess,json,hashlib,shutil
repo=Path('/Users/cim310/.codex/worktrees/level12-compile-profile/mech');raw=Path('/private/tmp/mech-thread-visits-20261114');packet=Path('/private/tmp/mech-thread-visits-packet-20261114');assert not packet.exists()
source=subprocess.check_output(['git','rev-parse','8ab9ce063e'],cwd=repo,text=True).strip();base='66a0d39a9bbc3cee6b89d1407dca4aed0a93dd1a';patch=subprocess.check_output(['git','diff','--binary',base,source],cwd=repo);assert patch==(raw/'candidate.patch').read_bytes()
assert subprocess.check_output(['git','diff','89f84855d203cd40a133b0c866b8c727fd0d9ffc',base,'--','src','hosts','vendor','machines','.cargo'],cwd=repo)==b''
(raw/'source-state.json').write_text(json.dumps({'source_commit':source,'base_commit':base,'patch_sha256':hashlib.sha256(patch).hexdigest(),'control_source_commit':'89f84855d203cd40a133b0c866b8c727fd0d9ffc','control_production_source_identical_to_base':True,'hardware':'Apple M3 Air, 8 cores (4P+4E), 16 GB, macOS 26.2','rustc':subprocess.check_output(['rustc','-Vv'],text=True),'cargo':subprocess.check_output(['cargo','-V'],text=True)},indent=2)+'\n')
excluded=[]
for p in sorted(raw.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(raw)
 if str(rel) in ['control','candidate']:
  excluded.append({'path':str(rel),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()});continue
 dest=packet/'compiler'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
(packet/'excluded-executables.json').write_text(json.dumps(excluded,indent=2)+'\n');(packet/'source-change.patch').write_bytes(patch)
paths=subprocess.check_output(['git','diff','--name-only',base,source],cwd=repo,text=True).splitlines();paths+=['benchmarks/mech-deflate/native-profile/'+n for n in ['Cargo.lock','compile_profile.rs','profile_compile.py']];paths+=['benchmarks/mech-deflate/experiment.py','.cargo/config.toml','LICENSE','hosts/gpu/tests/fixtures/native/deflate-huffman-LICENSES.md','hosts/gpu/src/native_artifact/program/runtime/composition_tests/nested_phase.rs']
paths+=['hosts/gpu/tests/fixtures/native/'+n+'.mec' for n in ['numeric-nested-phase','numeric-nested-phase-states','numeric-private-fixed-nested','numeric-changing-capture-tree','numeric-array-windows','numeric-multiple-children']]
for name in paths:
 dest=packet/'source'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(subprocess.check_output(['git','show',source+':'+name],cwd=repo))
for name in ['mech-build-thread-visits-20261114.py','mech-test-thread-visits-20261114.py','mech-run-thread-visits-20261114.py','mech-run-thread-visits-cohort-20261114.py','mech-thread-visits-fixtures-20261114.py','mech-curate-thread-visits-20261114.py']:
 shutil.copy2(Path('/private/tmp')/name,packet/name)
for name in ['mech-thread-visits-build-driver-20261114.log','mech-thread-visits-screen-driver-20261114.log','mech-thread-visits-cohort-driver-20261114.log','mech-thread-visits-fixtures-driver-20261114.log']:
 shutil.copy2(Path('/private/tmp')/name,packet/name)
validation=packet/'validation';validation.mkdir();shutil.copy2(Path('/private/tmp/mech-lexical-index-20261114/candidate-build.json'),validation/'control-build.json')
shutil.copy2(Path('/private/tmp/mech-ssa-forwarding-rejected-20261114.tar.gz.json'),validation/'rejected-ssa.archive.json');shutil.copy2(Path('/private/tmp/mech-ssa-forwarding-packet-20261114/summary.json'),validation/'rejected-ssa.json')
shutil.copytree(repo/'benchmarks/mech-deflate/.experiments/compile-peers-apple-m3-20261113/packet/licenses',packet/'licenses')
(packet/'README.txt').write_text('''Reusable CFG visit marks, Apple M3, 2026-11-14.
Retain compiler time saving. A block-indexed generation array replaces the
membership-only BTreeSet rebuilt for each value in loop-edge live-out analysis.
No graph, predicate, ownership, liveness, traversal order, error/admission or
optimization decision changes. Scratch storage lives only during optimization
of one immutable native CFG. Each walk starts fresh; generation wrap clears all
marks. There is no semantic proof cache and no reuse across graphs.
Four serial full source-to-Object ABBA observations use the same 54 existing
runtime flags, host process statistics and frozen executables. Compiler bootstrap,
a separate screen, tests and fixtures are excluded. No builds, tests, fixtures,
profiling or archive work overlap the primary timing cohort.
All source, MBC, native Object and complete metadata bytes match the previously
qualified fast 54-flag compressor, for every primary observation and the screen.
The control production source is identical to this trial's base after reverting
the preceding rejected SSA construction candidate. Every output also matches
between control/candidate in six complete additional array/enum programs and
eight Bool/U64/I64/F64 scalar programs, including checked division.
Two focused tests pass. 1,048,576 four-block graph/root/owner-stop combinations
compare complete DFS visitation order with BTreeSet, including cycles and
repeated pending blocks. A separate sparse-ID/overflow test covers generation
wrap. The enum-state helper is assembled by the existing maintained test helper;
any copied historical fragment-only failure is provenance, not a new launch.
Candidate peak RSS is higher with nonoverlapping ranges. This is not a memory
saving. Unchanged-stage timing variation is not attributed to visit marks.
Generated program bytes remain exactly identical, including numeric helpers,
main machine code and metadata. No new compressor runtime latency campaign is
claimed; the preceding rejected trial independently timed this exact control
Object. Do not confuse byte identity here with that rejected candidate's changed
Object and observed slowdowns. Its compact receipt and full replayed result are
included for provenance, with all adverse measurements retained there.
No grammar, language or runtime speed/opt-level tradeoff. Full compilation still
exceeds ten seconds. Source and evidence decisions are separate commits. Raw
files stay outside source Git; compiler executables are represented by source,
commands, hashes and build records. Run python3 replay.py without compiling or
executing generated programs for pure offline reconstruction.
''');print(packet,flush=True)
