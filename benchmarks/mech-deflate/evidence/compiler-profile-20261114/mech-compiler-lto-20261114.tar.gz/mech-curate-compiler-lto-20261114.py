from pathlib import Path
import subprocess,json,hashlib,shutil
repo=Path.cwd();packet=Path('/private/tmp/mech-compiler-lto-packet-20261114');assert not packet.exists();source='7306a0097a2a8e52bf263bb9d600a5e4ed8b417d';base='1252fcb3ce6443967080f7c437a35ade655d09c2';control_source='57376165608ec32729ff99a04b601d52d8f64950'
patch=subprocess.check_output(['git','diff','--binary',base,source]);assert patch==Path('/private/tmp/mech-compiler-lto-20261114/candidate.patch').read_bytes();assert subprocess.check_output(['git','diff',control_source,base,'--','src','hosts','vendor','machines','Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.toml'])==b''
excluded=[]
for label,dirname in [('compiler','mech-compiler-lto-20261114'),('trials/forwarding','mech-forwarding-compaction-20261114'),('trials/ordinary-sealing','mech-early-seal-20261114')]:
 raw=Path('/private/tmp')/dirname
 for p in sorted(raw.rglob('*')):
  if not p.is_file():continue
  rel=Path(label)/p.relative_to(raw)
  if p.name in ['control','candidate']:
   excluded.append(dict(path=rel.as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()));continue
  d=packet/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
(packet/'excluded-executables.json').write_text(json.dumps(excluded,indent=2)+'\n');(packet/'source-change.patch').write_bytes(patch)
state=dict(source_commit=source,base_commit=base,control_source_commit=control_source,control_production_source_identical_to_base=True,patch_sha256=hashlib.sha256(patch).hexdigest(),hardware='Apple M3 Air, 8 cores (4P+4E), 16 GB, macOS 26.2',rustc=subprocess.check_output(['rustc','-Vv'],text=True),cargo=subprocess.check_output(['cargo','-V'],text=True));(packet/'source-state.json').write_text(json.dumps(state,indent=2,sort_keys=True)+'\n')
paths=['Cargo.toml','Cargo.lock','.cargo/config.toml','LICENSE','vendor/cranelift-codegen/LICENSE','vendor/cranelift-frontend/LICENSE','vendor/cranelift-codegen-meta/LICENSE','vendor/regalloc2/LICENSE','vendor/cranelift-frontend/src/frontend.rs','vendor/cranelift-frontend/src/ssa.rs','hosts/gpu/src/native_artifact/program/compact/arrays.rs','hosts/gpu/src/native_artifact/program/compact/emit.rs','hosts/gpu/src/native_artifact/AGENTS.md','hosts/gpu/tests/fixtures/native/deflate-huffman-LICENSES.md','hosts/gpu/src/native_artifact/program/runtime/composition_tests/nested_phase.rs','docs/design/native-ssa-forwarding-compile-trial.md']
paths+=['benchmarks/mech-deflate/native-profile/'+n for n in ['Cargo.toml','Cargo.lock','compile_profile.rs','profile_compile.py','ssa_builder_tests.rs','compact_values_tests.rs']]
paths+=['hosts/gpu/tests/fixtures/native/'+n+'.mec' for n in ['numeric-nested-phase','numeric-nested-phase-states','numeric-private-fixed-nested','numeric-changing-capture-tree','numeric-array-windows','numeric-multiple-children']]
for name in paths:
 d=packet/'source'/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(subprocess.check_output(['git','show',source+':'+name]))
for name in ['Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.toml']:
 d=packet/'source-base'/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(subprocess.check_output(['git','show',base+':'+name]))
validation=packet/'validation';validation.mkdir()
for suffix in ['.json','.archive.json']:shutil.copy2(repo/('benchmarks/mech-deflate/native-profile/compact-values-compile-apple-m3-20261114'+suffix),validation/('qualified-compaction'+suffix))
shutil.copytree(Path('/private/tmp/mech-borrowed-schema-packet-20261114/licenses'),packet/'licenses');shutil.copytree(Path('/private/tmp/mech-after-lto-profile-20261114'),packet/'profile')
demangler=Path('/private/tmp/mech-compiler-process-profile-20261114/demangler')
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:
 d=packet/'profile/demangler-source'/name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(demangler/name,d)
patterns=['mech-*compiler-lto*20261114.py','mech-*compiler-lto*driver-20261114.log','mech-*forwarding-compaction*20261114.py','mech-*forwarding-compaction*driver-20261114.log','mech-*early-seal*20261114.py','mech-*early-seal*driver-20261114.log','mech-forwarding-after-compaction-original-20261114.patch','mech-profile-after-lto-20261114.py','mech-demangle-after-lto-20261114.py','mech-after-lto-profile-driver-20261114.log']
for pattern in patterns:
 for p in Path('/private/tmp').glob(pattern):
  if p.is_file():shutil.copy2(p,packet/p.name)
(packet/'README.txt').write_text('''Optimized compiler build profile, Apple M3, 2026-11-14.
The production workspace and focused harness define an opt-in compiler profile
inheriting release, with Thin LTO and one codegen unit. Ordinary release/runtime
builds are unchanged. The observed optimized compiler bootstrap takes 608.571
seconds and is separate from fresh Mech source-to-Object compilation timings.
Eight serial ABBA/BAAB compiles use identical 60 flags and reproduce all source,
MBC, Object and complete metadata bytes. Fourteen successful fixture pairs do
likewise. Both screens and every observation remain, including the slower
frontend/parse means and all memory counters. No builds, tests, CPU profiles,
hashing, copying or archive work overlap primary timing. Compiler executables
are excluded and pinned. No cold bootstrap comparison is claimed.
The SSA forwarding retry after compaction passes 23 tests but still changes
Object/metadata. It remains rejected; no new runtime nonregression is claimed.
Ordinary early sealing passes 21 tests and all output bytes, but its screen
does not demonstrate reduced construction work. It is not retained or promoted
to a qualified timing cohort. Both exact source snapshots, patches, binaries'
pins, commands, test logs, outputs, decisions and original observations remain.
The CPU profile is separate from primary timing and preserves every output byte.
It retains every completed raw/mapped sample, self table, existing demangler
source/pin and unsuccessful sampling attempt. Main-thread waits are not CPU
work; self counts are not phase-exclusive elapsed or exact line attribution.
This change adds no grammar, language, interpreter fallback, resource weakening
or current-proof cache. Generated programs and metadata are identical; ordinary
runtime release builds remain unchanged. No new runtime timing campaign is
claimed. The full ten-second source-compilation goal remains open.
This complete evidence packet is published in benchmarks at the user's request.
Run python3 replay.py for pure offline validation/numerical reconstruction;
replay does not compile a program, rerun timings or contact an external service.
''');print(packet,flush=True)
