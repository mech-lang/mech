from pathlib import Path
packet=Path('/private/tmp/mech-compiler-lto-packet-20261114');old=Path('/private/tmp/mech-compact-values-replay-20261114.py').read_text();defs=old[old.index('stage_fields='):old.index('def validate_cohort(')];fn=old[old.index('def validate_cohort('):old.index('historical=validate_cohort(')]
a=fn.index(" test=read(raw/'index-tests-command.json')");b=fn.index(" fixtures=read(raw/'fixture-results.json')",a);fn=fn[:a]+fn[b:];fn=fn.replace("if row['variant']=='candidate':","if True:");fn=fn[:fn.rfind(' return dict(')]+" return dict(flags_count=len(flags),qualified=qualified,blocks=blocks,output_hashes=expected,compiler_binary_sha256=pins,fixture_output_comparisons=fixtures)\n"
profile=old[old.index('def validate_profile('):old.index("profiles={'historical_control55'")]
prefix='''from pathlib import Path
import json,hashlib,re,statistics,tomllib
root=Path(__file__).resolve().parent;raw=root/'compiler'
read=lambda p:json.loads(p.read_text())
def pin(p):
 data=p.read_bytes();return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
state=read(root/'source-state.json');build=read(raw/'candidate-build.json');control=read(raw/'control-origin.json');patch=pin(root/'source-change.patch');assert patch==pin(raw/'candidate.patch') and patch['sha256']==state['patch_sha256']==build['patch_sha256']
assert build['exit_code']==0 and build['head']==state['base_commit'] and state['control_production_source_identical_to_base']
prior=read(root/'validation/qualified-compaction.json');receipt=read(root/'validation/qualified-compaction.archive.json');assert pin(root/'validation/qualified-compaction.json')['sha256']==receipt['replay_sha256'];assert control['sha256']==prior['current60']['compiler_binary_sha256']['candidate'] and control['source_commit']==state['control_source_commit']==prior['source_commit']
flags=read(raw/'runtime-flags.json');assert len(flags)==60;expected=prior['current60']['output_hashes'];assert read(raw/'reference-pins.json')==expected
excluded={r['path']:r for r in read(root/'excluded-executables.json')};assert excluded['compiler/control']['sha256']==control['sha256'] and excluded['compiler/candidate']['sha256']==build['binary_sha256']
profile_settings={}
for name in ['Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.toml']:
 before=tomllib.loads((root/'source-base'/name).read_text());after=tomllib.loads((root/'source'/name).read_text());assert after['profile']==dict(before['profile'],compiler={'inherits':'release','lto':'thin','codegen-units':1});profile_settings[name]=after['profile']['compiler']
assert '--profile' in build['command'] and build['command'][build['command'].index('--profile')+1]=='compiler' and '--release' not in build['command']
'''
end='''
qualification=validate_cohort(raw,flags,expected,{'control':control['sha256'],'candidate':build['binary_sha256']},'matches_current_control_output')
trials={}
for name,counts in [('forwarding',[7,16]),('ordinary-sealing',[7,14])]:
 d=root/'trials'/name;test=read(d/'index-tests-command.json');b=read(d/'candidate-build.json');assert test['exit_code']==b['exit_code']==0 and test['source_patch_sha256']==b['patch_sha256']==pin(d/'test-source.patch')['sha256']==pin(d/'candidate.patch')['sha256'];assert b['head']==state['base_commit']
 assert sorted(map(int,re.findall(r'test result: ok\\. (\\d+) passed',(d/'index-tests.log').read_text())))==counts
 assert excluded['trials/'+name+'/candidate']['sha256']==b['binary_sha256'] and excluded['trials/'+name+'/control']['sha256']==control['sha256']
 decision=read(d/'decision.json');assert decision['retained_in_worktree'] is False
 out=read(d/'candidate-screen/output-check.json');assert out['source.mec']['matches_current_control_output'] and out['program.mecb']['matches_current_control_output']
 for filename,pinned in out.items():assert pin(d/'candidate-screen'/filename)=={'bytes':pinned['bytes'],'sha256':pinned['sha256']}
 if name=='forwarding':assert not out['program.o']['matches_current_control_output'] and not out['metadata.json']['matches_current_control_output']
 else:assert all(v['matches_current_control_output'] for v in out.values())
 trials[name]=dict(decision=decision['decision'],rust_tests_passed=sum(counts),process=read(d/'candidate-screen/process.json'),output_checks=out,compiler_binary_sha256=b['binary_sha256'])
profile=validate_profile(root/'profile',flags,expected,build['binary_sha256'])
summary=dict(source_commit=state['source_commit'],base_commit=state['base_commit'],hardware=state['hardware'],decision='Retain opt-in production compiler profile with Thin LTO and one codegen unit; ordinary release and generated program bytes unchanged',candidate_patch_sha256=state['patch_sha256'],profile_settings=profile_settings,candidate_bootstrap_seconds=build['seconds'],bootstrap_scope='Observed first optimized-profile build with locked/offline Cargo and existing registry/other-profile caches; excluded from program compilation timing. No matched cold-bootstrap comparison is claimed.',compiler_executable_bytes={v:excluded['compiler/'+v]['bytes'] for v in ['control','candidate']},diagnostic_trials=trials,diagnostic_profile=profile,scope=[
 'Eight serial fresh source-to-Object primary observations in ABBA then BAAB order. Both subjects use identical 60 runtime flags, full production pipeline and existing native optimization level. No cached Object or decoded-only substitute is used.',
 'Compiler builds, tests, both screens, fixture compiles, CPU sampling, hashing, copying and archive work do not overlap primary timing. Every source, MBC, Object and complete metadata byte matches the previously qualified program in both screens and every primary observation.',
 'All fourteen successful fixture pairs reproduce all four output files between subjects. These are compiler-output checks, not a claim that Rust unit suites were rerun under the new profile. Rust tests for both discarded construction trials remain separately identified.',
 'Only an opt-in Cargo compiler build profile is added, identically in the production workspace and focused harness. It inherits release, enables Thin LTO and one codegen unit. All existing release/runtime profile settings remain unchanged. Source parsing, validation, native code generation, current ownership proofs, resource admission and generated-program optimization settings are unchanged.',
 'Both balanced blocks improve mean compiler and whole-process time; all candidate elapsed/compiler/instruction observations fall below all controls. Frontend and parse means are adverse and retained. Memory differences are small, with overlapping ranges. These finite cohorts are descriptive, not population estimates.',
 'The SSA forwarding retry remains rejected after compaction: it passes 23 tests but still changes generated Object and metadata, with no new runtime nonregression campaign claimed. Ordinary early sealing passes 21 tests and output checks but its screen does not demonstrate less construction work; it is not promoted to primary qualification. Both complete trials and source snapshots remain.',
 'The separate post-LTO CPU profile preserves output bytes and retains all raw/mapped samples, self tables, command, executable pin, existing demangler source and any failed sampling attempts. Main-thread waits are not CPU work; counts are not phase-exclusive elapsed or exact source-line attribution.',
 'Generated machine code and complete metadata are byte-identical and ordinary runtime builds are unchanged. No new program-runtime latency campaign is claimed. Grammar, language, direct scalar instructions, checked errors, finite admission and backend optimization level are unchanged. Full source compilation remains above ten seconds.'
],**qualification)
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
'''
(packet/'replay.py').write_text(prefix+defs+fn+profile+end)
