Optimized compiler build profile, Apple M3, 2026-11-14.
The production workspace and focused harness define an opt-in compiler profile
inheriting release, with Thin LTO and one codegen unit. Ordinary release/runtime
builds are unchanged. The observed optimized compiler bootstrap takes 608.571
seconds and is separate from fresh Mech source-to-Object compilation timings.
Eight serial ABBA/BAAB compiles use identical 60 flags and reproduce all source,
MBC, Object and complete metadata bytes. Fourteen successful fixture pairs do
likewise. Both screens and every observation remain, including the slower
frontend/parse means and all memory counters. No builds, tests, CPU profiles,
hashing, copying or archive work overlap primary timing. Compiler executables
are excluded and pinned. No cold bootstrap comparison is claimed.
The SSA forwarding retry after compaction passes 23 tests but still changes
Object/metadata. It remains rejected; no new runtime nonregression is claimed.
Ordinary early sealing passes 21 tests and all output bytes, but its screen
does not demonstrate reduced construction work. It is not retained or promoted
to a qualified timing cohort. Both exact source snapshots, patches, binaries'
pins, commands, test logs, outputs, decisions and original observations remain.
The CPU profile is separate from primary timing and preserves every output byte.
It retains every completed raw/mapped sample, self table, existing demangler
source/pin and unsuccessful sampling attempt. Main-thread waits are not CPU
work; self counts are not phase-exclusive elapsed or exact line attribution.
This change adds no grammar, language, interpreter fallback, resource weakening
or current-proof cache. Generated programs and metadata are identical; ordinary
runtime release builds remain unchanged. No new runtime timing campaign is
claimed. The full ten-second source-compilation goal remains open.
This complete evidence packet is published in benchmarks at the user's request.
Run python3 replay.py for pure offline validation/numerical reconstruction;
replay does not compile a program, rerun timings or contact an external service.
