from pathlib import Path
import json,hashlib,re,statistics,tomllib
root=Path(__file__).resolve().parent;raw=root/'compiler'
read=lambda p:json.loads(p.read_text())
def pin(p):
 data=p.read_bytes();return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
state=read(root/'source-state.json');build=read(raw/'candidate-build.json');control=read(raw/'control-origin.json');patch=pin(root/'source-change.patch');assert patch==pin(raw/'candidate.patch') and patch['sha256']==state['patch_sha256']==build['patch_sha256']
assert build['exit_code']==0 and build['head']==state['base_commit'] and state['control_production_source_identical_to_base']
prior=read(root/'validation/qualified-compaction.json');receipt=read(root/'validation/qualified-compaction.archive.json');assert pin(root/'validation/qualified-compaction.json')['sha256']==receipt['replay_sha256'];assert control['sha256']==prior['current60']['compiler_binary_sha256']['candidate'] and control['source_commit']==state['control_source_commit']==prior['source_commit']
flags=read(raw/'runtime-flags.json');assert len(flags)==60;expected=prior['current60']['output_hashes'];assert read(raw/'reference-pins.json')==expected
excluded={r['path']:r for r in read(root/'excluded-executables.json')};assert excluded['compiler/control']['sha256']==control['sha256'] and excluded['compiler/candidate']['sha256']==build['binary_sha256']
profile_settings={}
for name in ['Cargo.toml','benchmarks/mech-deflate/native-profile/Cargo.toml']:
 before=tomllib.loads((root/'source-base'/name).read_text());after=tomllib.loads((root/'source'/name).read_text());assert after['profile']==dict(before['profile'],compiler={'inherits':'release','lto':'thin','codegen-units':1});profile_settings[name]=after['profile']['compiler']
assert '--profile' in build['command'] and build['command'][build['command'].index('--profile')+1]=='compiler' and '--release' not in build['command']
stage_fields=[('canonical_lowering_seconds','compact-stage: canonical lowering','compact-stage: preparation blocks='),('preparation_seconds','compact-stage: preparation blocks=','compact-stage: native module'),('numeric_generation_seconds','compact-stage: native module','compact-stage: typed layout'),('source_cfg_seconds','compact-stage: source CFG','compact-stage: finalize SSA'),('cleanup_seconds','compact-stage: CFG cleanup','compact-stage: machine code')]
host_fields=[('max_rss_bytes',r'(\d+)  maximum resident set size'),('instructions',r'(\d+)  instructions retired'),('peak_footprint_bytes',r'(\d+)  peak memory footprint')]
order=['control-1','candidate-1','candidate-2','control-2','candidate-3','control-3','control-4','candidate-4']
def validate_cohort(raw,flags,expected,pins,key):
 rows=read(raw/'cohort.json');assert [r['name'] for r in rows]==order
 for name in ['control-screen','candidate-screen',*order]:
  variant=name.split('-')[0];d=raw/name;process=read(d/'process.json');assert process['exit_code']==0 and process['samples']==0 and process['sampling_error'] is None
  command=read(raw/(name+'-command.json'));assert command['flags']==flags and command['binary_sha256']==pins[variant]
  for filename,pinned in expected.items():assert pin(d/filename)==pinned and read(d/'output-check.json')[filename]==dict(pinned,**{key:True})
 for row in rows:
  d=raw/row['name'];assert row['compile']==read(d/'compile.json') and row['process']==read(d/'process.json') and row['files']==read(d/'output-check.json')
  assert row['variant']==row['name'].split('-')[0]
  stamps=[json.loads(line) for line in (d/'stages.jsonl').read_text().splitlines()]
  for field,begin,end in stage_fields:assert row[field]==next(s['elapsed'] for s in stamps if s['line'].startswith(end))-next(s['elapsed'] for s in stamps if s['line'].startswith(begin))
  for field,pattern in host_fields:assert row[field]==int(re.search(pattern,(d/'stderr.log').read_text()).group(1))
  if True:
   begin=next(s for s in stamps if s['line'].startswith('compact-stage: compact values before='));end=next(s for s in stamps if s['line'].startswith('compact-stage: CFG cleanup'));assert row['compaction_seconds']==end['elapsed']-begin['elapsed'];assert row['value_ids_before']==int(begin['line'].split('=')[-1])==20787570;assert row['value_ids_after']==int(next(s['line'] for s in stamps if s['line'].startswith('compact-values: retained=')).split('=')[-1])==1241393
  else:assert row['compaction_seconds']==0
  assert row['cleanup_including_compaction_seconds']==row['cleanup_seconds']+row['compaction_seconds']
 fixtures=read(raw/'fixture-results.json');assert len(fixtures)==14
 for record in fixtures:
  assert record['all_outputs_match'] and record['variants']['control']==record['variants']['candidate'] and record['variants']['control']['exit_code']==0 and len(record['variants']['control']['files'])==4
  name=Path(record['fixture']).stem if ':' not in record['fixture'] else record['fixture'].split(':')[-1]
  for variant,result in record['variants'].items():
   d=raw/'fixtures'/name/variant;command=read(d/'command.json');assert command['flags']==flags and command['binary_sha256']==pins[variant]
   for filename,pinned in result['files'].items():assert pin(d/filename)==pinned
   assert result['files']['source.mec']['sha256']==record['source_sha256']
 base=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase.mec').read_text();fragment=(root/'source/hosts/gpu/tests/fixtures/native/numeric-nested-phase-states.mec').read_text();assembled=base.replace('+> sequence\n','+> sequence\n'+fragment+'\n',1).replace('phase-candidates(values, 1u64, 0u64, permitted, divisor)','#PhaseCandidates(values, permitted, divisor, 1u64, 0u64)',1);assert assembled==(raw/'fixture-inputs/numeric-nested-phase-states.mec').read_text()
 fields={'compiler_seconds':lambda r:r['compile']['total_seconds'],'whole_process_seconds':lambda r:r['process']['elapsed_seconds']}
 for phase in ['parse','frontend','native']:fields[phase+'_seconds']=lambda r,p=phase:next(v['seconds'] for v in r['compile']['phases'] if v['phase']==p)
 for field in [f[0] for f in stage_fields]+['cleanup_including_compaction_seconds','compaction_seconds','instructions','max_rss_bytes','peak_footprint_bytes']:fields[field]=lambda r,k=field:r[k]
 qualified={field:{v:[fn(r) for r in rows if r['variant']==v] for v in ['control','candidate']} for field,fn in fields.items()}
 for values in qualified.values():
  mean=statistics.mean(values['control']);values['mean_reduction_fraction']=1-statistics.mean(values['candidate'])/mean if mean else None
 assert qualified==read(raw/'numerical-summary.json')
 blocks=[]
 for block in [rows[:4],rows[4:]]:
  blocks.append(dict(order=[r['name'] for r in block],compiler_mean_reduction_fraction=1-statistics.mean(r['compile']['total_seconds'] for r in block if r['variant']=='candidate')/statistics.mean(r['compile']['total_seconds'] for r in block if r['variant']=='control')))
 return dict(flags_count=len(flags),qualified=qualified,blocks=blocks,output_hashes=expected,compiler_binary_sha256=pins,fixture_output_comparisons=fixtures)
def validate_profile(path,flags,expected,binary_sha):
 command=read(path/'command.json');assert command['flags']==flags and command['binary_sha256']==binary_sha
 process=read(path/'cpu/process.json');assert process['exit_code']==0 and read(path/'output-check.json')==expected
 for filename,pinned in expected.items():assert pin(path/'cpu'/filename)==pinned
 mapping=read(path/'demangled-symbols.json');symbols=set();tables={}
 for p in sorted((path/'cpu').glob('sample-*.txt')):
  if not re.fullmatch(r'sample-\d+\.txt',p.name):continue
  text=p.read_text();symbols.update(re.findall(r'_R[A-Za-z0-9_]+',text));mapped=re.sub(r'_R[A-Za-z0-9_]+',lambda m:mapping[m.group(0)],text);assert mapped==p.with_name(p.stem+'-demangled.txt').read_text();parsed=[]
  for line in mapped[mapped.index('Sort by top of stack'):].splitlines()[1:]:
   match=re.match(r'\s+(.*?)\s+\(in (.*?)\)\s+(\d+)\s*$',line)
   if match:parsed.append(dict(symbol=match[1],image=match[2],self_samples=int(match[3])))
   elif parsed:break
  assert parsed==read(p.with_name(p.stem+'-self.json'));tables[p.name]=parsed
 assert set(mapping)==symbols and len(tables)>0 and process['samples']>=len(tables)
 return dict(command=command,process=process,completed_sample_files=len(tables),first_window_cpu_self_samples=[r for r in next(iter(tables.values())) if r['symbol']!='__ulock_wait'][:20],main_thread_waits_excluded_from_hotspot_table=True)

qualification=validate_cohort(raw,flags,expected,{'control':control['sha256'],'candidate':build['binary_sha256']},'matches_current_control_output')
trials={}
for name,counts in [('forwarding',[7,16]),('ordinary-sealing',[7,14])]:
 d=root/'trials'/name;test=read(d/'index-tests-command.json');b=read(d/'candidate-build.json');assert test['exit_code']==b['exit_code']==0 and test['source_patch_sha256']==b['patch_sha256']==pin(d/'test-source.patch')['sha256']==pin(d/'candidate.patch')['sha256'];assert b['head']==state['base_commit']
 assert sorted(map(int,re.findall(r'test result: ok\. (\d+) passed',(d/'index-tests.log').read_text())))==counts
 assert excluded['trials/'+name+'/candidate']['sha256']==b['binary_sha256'] and excluded['trials/'+name+'/control']['sha256']==control['sha256']
 decision=read(d/'decision.json');assert decision['retained_in_worktree'] is False
 out=read(d/'candidate-screen/output-check.json');assert out['source.mec']['matches_current_control_output'] and out['program.mecb']['matches_current_control_output']
 for filename,pinned in out.items():assert pin(d/'candidate-screen'/filename)=={'bytes':pinned['bytes'],'sha256':pinned['sha256']}
 if name=='forwarding':assert not out['program.o']['matches_current_control_output'] and not out['metadata.json']['matches_current_control_output']
 else:assert all(v['matches_current_control_output'] for v in out.values())
 trials[name]=dict(decision=decision['decision'],rust_tests_passed=sum(counts),process=read(d/'candidate-screen/process.json'),output_checks=out,compiler_binary_sha256=b['binary_sha256'])
profile=validate_profile(root/'profile',flags,expected,build['binary_sha256'])
summary=dict(source_commit=state['source_commit'],base_commit=state['base_commit'],hardware=state['hardware'],decision='Retain opt-in production compiler profile with Thin LTO and one codegen unit; ordinary release and generated program bytes unchanged',candidate_patch_sha256=state['patch_sha256'],profile_settings=profile_settings,candidate_bootstrap_seconds=build['seconds'],bootstrap_scope='Observed first optimized-profile build with locked/offline Cargo and existing registry/other-profile caches; excluded from program compilation timing. No matched cold-bootstrap comparison is claimed.',compiler_executable_bytes={v:excluded['compiler/'+v]['bytes'] for v in ['control','candidate']},diagnostic_trials=trials,diagnostic_profile=profile,scope=[
 'Eight serial fresh source-to-Object primary observations in ABBA then BAAB order. Both subjects use identical 60 runtime flags, full production pipeline and existing native optimization level. No cached Object or decoded-only substitute is used.',
 'Compiler builds, tests, both screens, fixture compiles, CPU sampling, hashing, copying and archive work do not overlap primary timing. Every source, MBC, Object and complete metadata byte matches the previously qualified program in both screens and every primary observation.',
 'All fourteen successful fixture pairs reproduce all four output files between subjects. These are compiler-output checks, not a claim that Rust unit suites were rerun under the new profile. Rust tests for both discarded construction trials remain separately identified.',
 'Only an opt-in Cargo compiler build profile is added, identically in the production workspace and focused harness. It inherits release, enables Thin LTO and one codegen unit. All existing release/runtime profile settings remain unchanged. Source parsing, validation, native code generation, current ownership proofs, resource admission and generated-program optimization settings are unchanged.',
 'Both balanced blocks improve mean compiler and whole-process time; all candidate elapsed/compiler/instruction observations fall below all controls. Frontend and parse means are adverse and retained. Memory differences are small, with overlapping ranges. These finite cohorts are descriptive, not population estimates.',
 'The SSA forwarding retry remains rejected after compaction: it passes 23 tests but still changes generated Object and metadata, with no new runtime nonregression campaign claimed. Ordinary early sealing passes 21 tests and output checks but its screen does not demonstrate less construction work; it is not promoted to primary qualification. Both complete trials and source snapshots remain.',
 'The separate post-LTO CPU profile preserves output bytes and retains all raw/mapped samples, self tables, command, executable pin, existing demangler source and any failed sampling attempts. Main-thread waits are not CPU work; counts are not phase-exclusive elapsed or exact source-line attribution.',
 'Generated machine code and complete metadata are byte-identical and ordinary runtime builds are unchanged. No new program-runtime latency campaign is claimed. Grammar, language, direct scalar instructions, checked errors, finite admission and backend optimization level are unchanged. Full source compilation remains above ten seconds.'
],**qualification)
encoded=json.dumps(summary,indent=2,sort_keys=True)+'\n';p=root/'summary.json'
if p.exists():assert p.read_text()==encoded
else:p.write_text(encoded)
print(encoded,end='')
