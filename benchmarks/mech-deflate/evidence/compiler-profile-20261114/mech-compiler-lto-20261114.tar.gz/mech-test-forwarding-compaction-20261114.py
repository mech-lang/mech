from pathlib import Path
import subprocess,os,time,json,hashlib
root=Path('/private/tmp/mech-forwarding-compaction-20261114');patch=subprocess.check_output(['git','diff','--binary']);(root/'test-source.patch').write_bytes(patch)
command=['cargo','test','--locked','--offline','--release','-j2','--manifest-path','benchmarks/mech-deflate/native-profile/Cargo.toml','--test','ssa_builder','--test','compact_values'];start=time.perf_counter()
flags=json.loads((root/'runtime-flags.json').read_text());env={k:v for k,v in os.environ.items() if not k.startswith('MECH_')};env.update(flags);env.update(CARGO_TARGET_DIR='/private/tmp/mech-level12-compile-target',CARGO_INCREMENTAL='0')
with (root/'index-tests.log').open('wb') as f:p=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT)
record=dict(command=command,flags=flags,exit_code=p.returncode,seconds=time.perf_counter()-start,source_patch_sha256=hashlib.sha256(patch).hexdigest(),CARGO_TARGET_DIR='/private/tmp/mech-level12-compile-target',CARGO_INCREMENTAL='0');(root/'index-tests-command.json').write_text(json.dumps(record,indent=2)+'\n');assert subprocess.check_output(['git','diff','--binary'])==patch;print(record,flush=True);raise SystemExit(p.returncode)
