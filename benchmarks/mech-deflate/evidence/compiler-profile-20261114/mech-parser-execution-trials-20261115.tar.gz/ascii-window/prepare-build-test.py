from pathlib import Path
import difflib,hashlib,json,os,shutil,subprocess,time

repo=Path.cwd();root=Path('/private/tmp/mech-parser-ascii-window-20261115');root.mkdir(exist_ok=False)
assert subprocess.check_output(['git','diff','--','src/syntax'])==b''
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
shutil.copy2(__file__,root/'prepare-build-test.py')
for variant in ['reference','candidate']:
    shutil.copytree(repo/'src/syntax/src/document',root/variant/'document')
shutil.copytree(repo/'src/syntax/tests',root/'tests')
shutil.copy2('/private/tmp/mech-parser-execution-census-20261115/source.mec',root/'source.mec')
recipe=json.loads(Path('/private/tmp/mech-parser-execution-census-20261115/recipe.json').read_text())
(root/'recipe.json').write_text(json.dumps(recipe,indent=2)+'\n')

rel='parser/grapheme_scan.rs';path=root/'candidate/document'/rel;source=path.read_text()
def replace(before,after):
    global source
    assert source.count(before)==1,(before,source.count(before))
    source=source.replace(before,after)
replace('pub(crate) struct ScanWork {\n    pub calls: u64,','pub(crate) struct ScanWork {\n    /// Charged Unicode-call units, preserving the original bounded scanner work.\n    pub calls: u64,')
replace('    pub work: ScanWork,\n}', '    pub work: ScanWork,\n    #[cfg(test)]\n    disable_ascii_window_for_test: bool,\n}')
replace('            work: ScanWork::default(),\n', '            work: ScanWork::default(),\n            #[cfg(test)]\n            disable_ascii_window_for_test: false,\n')
replace('    /// One allowance unit permits one Unicode-library call with at most one\n    /// forward scalar and one preceding scalar (eight bytes). Context requests\n    /// are suspended and charged too.','''    /// One allowance unit reserves one original Unicode-library call with at
    /// most one forward scalar and one preceding scalar (eight bytes). An ASCII
    /// window can combine two such calls, charging their original two units.
    /// Context requests are suspended and charged too.''')
needle='    /// One allowance unit reserves one original Unicode-library call'
helper='''    fn ascii_window<S: ScanSource + ?Sized>(
        &mut self,
        source: &S,
        end: TextSize,
        allowance: &mut u64,
    ) -> Option<ScanProgress> {
        #[cfg(test)]
        if self.disable_ascii_window_for_test {
            return None;
        }
        let at = self.cursor.cur_cursor();
        let next = at.checked_add(1)?;
        if *allowance < 2 || self.start.to_usize() != at || next >= end.to_usize() {
            return None;
        }
        let first = source.scan_byte_at(at)?;
        let following = source.scan_byte_at(next)?;
        if !(b' '..=b'~').contains(&first) || !following.is_ascii() {
            return None;
        }
        let mut bytes = [0_u8; 3];
        let prior = usize::from(at > 0);
        if prior > 0 {
            let byte = source.scan_byte_at(at - 1)?;
            if !byte.is_ascii() {
                return None;
            }
            bytes[0] = byte;
        }
        bytes[prior] = first;
        bytes[prior + 1] = following;
        let text = core::str::from_utf8(&bytes[..prior + 2]).ok()?;
        // Supplying the ASCII successor avoids a NextChunk round trip. Keep a
        // local cursor until the same Unicode authority confirms the boundary.
        let mut cursor = self.cursor.clone();
        if cursor.next_boundary(text, at - prior) != Ok(Some(next)) {
            return None;
        }
        self.cursor = cursor;
        let range = TextRange::new(self.start, TextSize(next as u32));
        self.start = range.end;
        *allowance -= 2;
        self.work.calls += 2;
        self.work.forward_bytes += 2;
        self.work.lookbehind_bytes += (prior + 1) as u64;
        Some(ScanProgress::Grapheme(range))
    }

'''
replace(needle,helper+needle)
replace('            let at = self.cursor.cur_cursor();','            if let Some(progress) = self.ascii_window(source, end, allowance) {\n                return progress;\n            }\n            let at = self.cursor.cur_cursor();')
test='''
    #[test]
    fn ascii_windows_preserve_original_cursor_work_and_unicode_suffixes() {
        fn trace(text: &str, offset: usize, allowance: u64, original: bool)
            -> alloc::vec::Vec<(ScanProgress, ScanWork, alloc::string::String)>
        {
            let end = TextSize::checked_from_usize(text.len()).unwrap();
            let start = TextSize::checked_from_usize(offset).unwrap();
            let mut scan = GraphemeScan::new(start, Some(end));
            scan.disable_ascii_window_for_test = original;
            let mut result = alloc::vec::Vec::new();
            loop {
                let mut remaining = allowance;
                let progress = scan.advance(text, end, true, &mut remaining);
                result.push((progress, scan.work, alloc::format!("{:?}", scan.cursor)));
                assert!(result.len() < 256);
                match progress {
                    ScanProgress::End => break,
                    ScanProgress::Grapheme(_) | ScanProgress::NeedsProcessing => {}
                    other => panic!("sealed valid scanner source: {other:?}"),
                }
            }
            result
        }
        for first in b' '..=b'~' {
            for second in 0..=127_u8 {
                for prefix in ["", "x", "\\r", "\\n", "é"] {
                    let text = alloc::format!("{prefix}{}{}é\\u{301}🇦🇧", first as char, second as char);
                    for allowance in [1, 2, 3, u64::MAX] {
                        assert_eq!(trace(&text, prefix.len(), allowance, false),
                                   trace(&text, prefix.len(), allowance, true),
                                   "source {text:?}, allowance {allowance}");
                    }
                }
            }
        }
    }
'''
last=source.rfind('\n}');assert last>0;source=source[:last]+'\n'+test+source[last:];path.write_text(source)
original=root/'reference/document'/rel
patch=''.join(difflib.unified_diff(original.read_text().splitlines(keepends=True),path.read_text().splitlines(keepends=True),fromfile='a/src/syntax/src/document/'+rel,tofile='b/src/syntax/src/document/'+rel))
(root/'candidate.patch').write_text(patch)
(root/'source-state.json').write_text(json.dumps(dict(base_commit=head,production_source_commit='ef5e255e817eb5bbc6df61b094a3741b31c49da2',patch_sha256=hashlib.sha256(patch.encode()).hexdigest(),production_edits=False,scope='One-file bounded ASCII scan window. Same pinned GraphemeCursor authority and exact cursor state; combine two one-scalar chunks into <=3 ASCII bytes while charging original two work units, bytes and lookbehind. Original scanner for Unicode neighbours, EOF, low allowances and suspended scalar/context scans. No grammar, language, fuel/event/admission or metadata change. Independent every-ASCII-pair cursor/work traces with Unicode suffixes. Both prior prototypes excluded.'),indent=2)+'\n')
env=dict(os.environ,CARGO_MANIFEST_DIR=str(repo/'src/syntax'));records=[]
def run(name,command):
    started=time.monotonic()
    with (root/(name+'.stdout')).open('wb') as out,(root/(name+'.stderr')).open('wb') as err:result=subprocess.run(command,env=env,stdout=out,stderr=err)
    row=dict(stage=name,command=command,exit_code=result.returncode,seconds=time.monotonic()-started);records.append(row);(root/'pipeline.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
    assert result.returncode==0,(name,(root/(name+'.stderr')).read_text()[-7000:])
unit='extern crate alloc;\n#[path='+json.dumps(str(root/'candidate/document/mod.rs'))+'] pub mod document;\n#[cfg(test)] #[path='+json.dumps(str(repo/'src/core/tests/support/allocation_probe.rs'))+'] mod allocation_probe;\n#[cfg(test)] #[global_allocator] static TEST_ALLOCATOR:allocation_probe::ProbeAllocator=allocation_probe::ProbeAllocator;\n'
(root/'unit.rs').write_text(unit)
run('unit-build',recipe['command_prefix']+['--crate-name','parser_ascii_window_units','--test',str(root/'unit.rs'),'-o',str(root/'unit')])
run('unit-tests',[str(root/'unit'),'--test-threads=2'])
wrapper=Path('/private/tmp/mech-parser-classified-actions-20261115/reference.rs').read_text()
old_path='/private/tmp/mech-parser-classified-actions-20261115/reference/document/mod.rs'
for variant in ['reference','candidate']:
    path=root/(variant+'.rs');path.write_text(wrapper.replace(old_path,str(root/variant/'document/mod.rs')))
    run(variant+'-build',recipe['command_prefix']+['--crate-name','parser_ascii_window_'+variant,str(path),'-o',str(root/(variant+'-probe'))])
assert subprocess.check_output(['git','diff','--','src/syntax'])==b''
print('Unchanged production unit suite and standalone builds complete; parse screening pending.',flush=True)
