from pathlib import Path
import hashlib,json,statistics,subprocess,time

root=Path('/private/tmp/mech-parser-ascii-window-20261115')
pipeline=json.loads((root/'pipeline.json').read_text())
assert [r['stage'] for r in pipeline]==['unit-build','unit-tests','reference-build','candidate-build']
assert all(r['exit_code']==0 for r in pipeline)
assert 'test result: ok. 527 passed; 0 failed;' in (root/'unit-tests.stdout').read_text()
out=root/'parse-screen';out.mkdir(exist_ok=False)
pin=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
config=dict(scope='Standalone bounded ASCII Unicode-scan-window screening only. Prior prototypes excluded. Exact complete actual document module from same source/features/coherent dependencies; default allocator and opt-level3, no PGO. Fresh process and source read per observation. Timer wraps parse_canonical_document including tree construction, before JSON serialization. All tests/builds/hashing/publication finish before runs. No full-native or fastest-compiler gain inferred.',source=pin(root/'source.mec'),patch_sha256=json.loads((root/'source-state.json').read_text())['patch_sha256'],binaries={v:pin(root/(v+'-probe')) for v in ['reference','candidate']},order=['reference','candidate','candidate','reference','candidate','reference','reference','candidate'],promotion_plan='Before observations: exact complete parse output and 527 production document units required; parser mean reduction >=10% with both balanced blocks faster before promoting to complete compiler qualification. Any smaller or adverse result remains, with no retained gain or sub-ten claim.')
(out/'configuration.json').write_text(json.dumps(config,indent=2)+'\n')
rows=[];counts={'reference':0,'candidate':0}
for variant in config['order']:
    counts[variant]+=1;name=variant+'-'+str(counts[variant]);command=[str(root/(variant+'-probe')),str(root/'source.mec')]
    start=time.monotonic()
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
        result=subprocess.run(command,stdout=stdout,stderr=stderr)
    elapsed=time.monotonic()-start
    assert result.returncode==0,(name,result.returncode)
    timers=[json.loads(line) for line in (out/(name+'.stderr')).read_text().splitlines()]
    assert len(timers)==1 and set(timers[0])=={'parse_seconds'}
    row=dict(variant=variant,name=name,command=command,exit_code=result.returncode,parse_seconds=timers[0]['parse_seconds'],whole_probe_seconds=elapsed)
    rows.append(row);(out/'cohort.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
# Validate all bytes only after every timed process has exited.
outputs={row['name']:pin(out/(row['name']+'.stdout')) for row in rows}
assert len({(v['bytes'],v['sha256']) for v in outputs.values()})==1
reference=Path('/private/tmp/mech-parser-execution-census-20261115/reference-run.stdout')
assert next(iter(outputs.values()))==pin(reference)
numbers={v:[r['parse_seconds'] for r in rows if r['variant']==v] for v in ['reference','candidate']}
means={v:statistics.mean(numbers[v]) for v in numbers}
blocks=[]
for subset in [rows[:4],rows[4:]]:
    values={v:statistics.mean(r['parse_seconds'] for r in subset if r['variant']==v) for v in numbers}
    values['mean_reduction_fraction']=1-values['candidate']/values['reference'];blocks.append(values)
reduction=1-means['candidate']/means['reference']
summary=dict(numbers=numbers,means=means,mean_reduction_fraction=reduction,balanced_blocks=blocks,outputs=outputs,exact_complete_parse=True,production_document_units=527,promotion_criterion_met=reduction>=.1 and all(b['mean_reduction_fraction']>0 for b in blocks),scope=config['scope'])
(out/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n');print(json.dumps(summary,indent=2,sort_keys=True),flush=True)
