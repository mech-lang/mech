
extern crate alloc;
#[path="/private/tmp/mech-parser-ascii-window-20261115/reference/document/mod.rs"] pub mod document;
use document::*;
fn tree(node:&GreenNode,out:&mut Vec<serde_json::Value>){out.push(serde_json::json!(["start",node.id.0,node.kind as u16,node.flags.0,node.text_len.0,node.structural_hash]));for child in node.children.iter(){match child{GreenElement::Node(n)=>tree(n,out),GreenElement::Token(t)=>out.push(serde_json::json!(["token",t.id.0,t.kind as u16,t.flags.0,t.text_len.0,t.text_hash]))}}out.push(serde_json::json!(["finish"]));}
fn main(){let args=std::env::args().collect::<Vec<_>>();let text=std::fs::read_to_string(&args[1]).unwrap();let started=std::time::Instant::now();let parsed=parse_canonical_document(TextSnapshot::new(DocumentId(0x50524f47),Revision(1),text).unwrap(),ParseConfig::default());eprintln!("{}",serde_json::json!({"parse_seconds":started.elapsed().as_secs_f64()}));let mut nodes=Vec::new();tree(&parsed.root,&mut nodes);println!("{}",serde_json::json!({"tree":nodes,"diagnostics":parsed.diagnostics.iter().collect::<Vec<_>>(),"stats":format!("{:?}",parsed.stats),"restarts":format!("{:?}",parsed.restarts)}));}
