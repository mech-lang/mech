use std::ops::{Deref, DerefMut};

// Reduce the actual Core projection to its Box<[T]> and identical Deref APIs.
// The allocation planner/custom allocator does not change these reborrows.
struct Projection(Box<[u64]>);
impl Deref for Projection {
    type Target = [u64];
    fn deref(&self) -> &[u64] {
        &self.0
    }
}
impl DerefMut for Projection {
    fn deref_mut(&mut self) -> &mut [u64] {
        &mut self.0
    }
}
struct Storage(Projection);
impl Storage {
    fn values(&self) -> &[u64] {
        &self.0
    }
    fn values_mut(&mut self) -> &mut [u64] {
        &mut self.0
    }
}
#[inline(never)]
fn helper(storage: &mut Storage, payload: u64) {
    storage.values_mut()[0] = payload;
    storage.values_mut()[1] = 1;
}
fn main() {
    let mode = std::env::args().nth(1).expect("shared or fresh");
    let mut storage = Storage(Projection(vec![17, 1].into_boxed_slice()));
    let pointer = storage.values().as_ptr();
    // Model synchronous generated reads, with no retained Rust slice binding.
    assert_eq!(unsafe { pointer.read() }, 17);
    helper(&mut storage, 23);
    let after = match mode.as_str() {
        "shared" => pointer,
        "fresh" => storage.values().as_ptr(),
        _ => panic!("unknown mode"),
    };
    assert_eq!(unsafe { after.read() }, 23);
    helper(&mut storage, 31);
    let after = match mode.as_str() {
        "shared" => pointer,
        "fresh" => storage.values().as_ptr(),
        _ => unreachable!(),
    };
    assert_eq!(unsafe { after.read() }, 31);
    println!("read17 -> helper23 -> read23 -> helper31 -> read31");
}
