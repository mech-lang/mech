from pathlib import Path
import subprocess,json,time
r=Path('/private/tmp/mech-frame-reads-round30-20261029')
w=Path('/private/tmp/mech-deflate-linear-stack')
commands=[('selected',['python3',str(r/'primary/qualify-selected.py')]),('linked',['python3',str(r/'linked/qualify.py')]),('architecture',['python3','/private/tmp/mech-final-static-20261028.py'])]
results=[]
for name,c in commands:
 start=time.monotonic(); p=subprocess.run(c,cwd=w,text=True,capture_output=True)
 (r/('final-'+name+'.log')).write_text(p.stdout+p.stderr)
 row={'name':name,'command':c,'exit':p.returncode,'seconds':time.monotonic()-start}
 results.append(row);(r/'final-qualification.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(row),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
