from pathlib import Path
import subprocess,json,time
r=Path('/private/tmp/mech-frame-reads-round30-20261029');w=Path('/private/tmp/mech-deflate-linear-stack')
commands=[['/private/tmp/mech-profile-ci-python-20261030/bin/python','-c','import yaml;assert yaml.__version__=="6.0.3";import sys;sys.path.insert(0,"scripts");from ci_test_inventory import inventory_gaps;g=inventory_gaps();print(g);assert not g'],['sh','scripts/check-unsafe-boundaries.sh'],['cargo','fmt','--all','--check'],['git','diff','--check']]
rows=[]
for i,c in enumerate(commands):
 t=time.monotonic();p=subprocess.run(c,cwd=w,capture_output=True,text=True)
 (r/f'architecture-recovery-{i}.log').write_text(p.stdout+p.stderr)
 row={'command':c,'exit':p.returncode,'seconds':time.monotonic()-t};rows.append(row)
 (r/'architecture-recovery.json').write_text(json.dumps({'prior':'first8 checks passed; original 9th failed because prior temporary interpreter no longer had yaml; retained failed receipt; restore pinnedPyYAML6.0.3 in new temporary environment and execute only remaining4 checks','checks':rows},indent=2)+'\n')
 print(json.dumps(row),flush=True);p.check_returncode()
