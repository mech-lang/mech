use mech_core::{MemoryObjectOwner,NodeId,ResourceDemand,WorkDemand,MemoryBudgetLimits};
#[unsafe(no_mangle)]
pub fn budget_first_case(output:u64,compute:u64,maxout:u64,maxcompute:u64)->u64 {
 mech_core::first_call_memory_budget_violation(MemoryObjectOwner::NodeOutput {node:NodeId::new(7),port:0}, ResourceDemand {output_elements:output,work:WorkDemand{compute,..Default::default()},..Default::default()},0,0,MemoryBudgetLimits {max_output_elements:Some(maxout),max_compute_work:Some(maxcompute),..Default::default()}).map_or(0,|v|v.dimension as u64+1)
}
#[unsafe(no_mangle)]
pub fn budget_full_case(output:u64,compute:u64,maxout:u64,maxcompute:u64)->u64 {
 mech_core::evaluate_call_memory_budget(MemoryObjectOwner::NodeOutput {node:NodeId::new(7),port:0}, ResourceDemand {output_elements:output,work:WorkDemand{compute,..Default::default()},..Default::default()},0,0,MemoryBudgetLimits {max_output_elements:Some(maxout),max_compute_work:Some(maxcompute),..Default::default()}).first().map_or(0,|v|v.dimension as u64+1)
}
