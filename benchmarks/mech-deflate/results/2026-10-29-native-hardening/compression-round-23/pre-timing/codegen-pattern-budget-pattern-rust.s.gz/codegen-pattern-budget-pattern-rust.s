	.build_version macos, 11, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_budget_first_case
	.p2align	2
_budget_first_case:
	.cfi_startproc
	mov	w8, #7
	cmp	x1, x3
	csel	x8, x8, xzr, hi
	cmp	x0, x2
	csinc	x0, x8, xzr, ls
	ret
	.cfi_endproc

	.globl	_budget_full_case
	.p2align	2
_budget_full_case:
	.cfi_startproc
	sub	sp, sp, #304
	.cfi_def_cfa_offset 304
	stp	x20, x19, [sp, #272]
	stp	x29, x30, [sp, #288]
	add	x29, sp, #288
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #48]
	str	q0, [sp, #32]
	stp	xzr, x0, [sp, #80]
	str	wzr, [sp, #96]
	stp	xzr, x1, [sp]
	stp	xzr, xzr, [sp, #16]
	mov	w8, #1
	stp	x8, x2, [sp, #104]
	str	xzr, [sp, #120]
	str	xzr, [sp, #136]
	str	xzr, [sp, #152]
	str	xzr, [sp, #168]
	str	xzr, [sp, #184]
	stp	x8, x3, [sp, #200]
	str	xzr, [sp, #216]
	str	xzr, [sp, #232]
	str	xzr, [sp, #248]
	str	wzr, [sp, #264]
	mov	x1, sp
	add	x4, sp, #104
	mov	x0, #3
	movk	x0, #7, lsl #32
	mov	x2, #0
	mov	x3, #0
	bl	__RNvNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget27evaluate_call_memory_budget
	cbz	x1, LBB1_3
	cbz	x0, LBB1_3
	ldrb	w8, [x0, #24]
	add	x19, x8, #1
	b	LBB1_4
LBB1_3:
	mov	x19, #0
	mov	x2, #0
	cbz	x1, LBB1_5
LBB1_4:
	lsl	x1, x1, #5
	mov	w2, #8
	bl	__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc
	mov	x2, x19
LBB1_5:
	mov	x0, x2
	.cfi_def_cfa wsp, 304
	ldp	x29, x30, [sp, #288]
	ldp	x20, x19, [sp, #272]
	add	sp, sp, #304
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	ret
	.cfi_endproc

.subsections_via_symbols
