typedef unsigned long long u64;
u64 budget_c_case(u64 output,u64 compute,u64 maxout,u64 maxcompute) {
 if(output>maxout)return 1;
 if(compute>maxcompute)return 7;
 return 0;
}
