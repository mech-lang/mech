	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 15, 0	sdk_version 26, 0
	.globl	_budget_c_case                  ; -- Begin function budget_c_case
	.p2align	2
_budget_c_case:                         ; @budget_c_case
	.cfi_startproc
; %bb.0:
	mov	w8, #7                          ; =0x7
	cmp	x1, x3
	csel	x8, x8, xzr, hi
	cmp	x0, x2
	csinc	x0, x8, xzr, ls
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
