	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 15, 0	sdk_version 26, 0
	.globl	_pair_fold                      ; -- Begin function pair_fold
	.p2align	2
_pair_fold:                             ; @pair_fold
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB0_4
LBB0_1:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x0], #4
	ldrb	w9, [x1], #1
	umull	x9, w9, w8
	adds	x3, x3, x9
	b.hs	LBB0_5
; %bb.2:                                ;   in Loop: Header=BB0_1 Depth=1
	adds	x4, x4, x8, lsl #3
	b.hs	LBB0_5
; %bb.3:                                ;   in Loop: Header=BB0_1 Depth=1
	subs	x2, x2, #1
	b.ne	LBB0_1
LBB0_4:
	mov	x0, x3
	mov	x1, x4
	ret
LBB0_5:
	brk	#0x1
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
