#include <stdint.h>
#include <stddef.h>
typedef struct { uint64_t dynamic, fixed; } Pair;
Pair pair_fold(const uint32_t *words, const uint8_t *lens, size_t len, uint64_t dynamic, uint64_t fixed) {
  for(size_t i=0;i<len;i++) {
    uint64_t term, flat;
    if(__builtin_mul_overflow((uint64_t)words[i],(uint64_t)lens[i],&term) ||
       __builtin_add_overflow(dynamic,term,&dynamic) ||
       __builtin_mul_overflow((uint64_t)words[i],8ull,&flat) ||
       __builtin_add_overflow(fixed,flat,&fixed)) __builtin_trap();
  }
  return (Pair){dynamic,fixed};
}
