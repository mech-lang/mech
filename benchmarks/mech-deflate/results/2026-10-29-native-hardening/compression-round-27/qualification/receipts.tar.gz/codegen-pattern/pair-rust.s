	.build_version macos, 11, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_pair_fold
	.p2align	2
_pair_fold:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
LBB0_1:
	cbz	x2, LBB0_5
	ldr	w8, [x0], #4
	ldrb	w9, [x1], #1
	umull	x9, w9, w8
	adds	x3, x9, x3
	b.hs	LBB0_6
	sub	x2, x2, #1
	adds	x4, x4, x8, lsl #3
	b.lo	LBB0_1
Lloh0:
	adrp	x0, l_anon.16e9e8c0dd96e9ff00565e35c331ccf6.0@PAGE
Lloh1:
	add	x0, x0, l_anon.16e9e8c0dd96e9ff00565e35c331ccf6.0@PAGEOFF
Lloh2:
	adrp	x2, l_anon.16e9e8c0dd96e9ff00565e35c331ccf6.2@PAGE
Lloh3:
	add	x2, x2, l_anon.16e9e8c0dd96e9ff00565e35c331ccf6.2@PAGEOFF
	mov	w1, #8
	bl	__RNvNtCsgDHHaSskbIF_4core6option13expect_failed
LBB0_5:
	mov	x0, x3
	mov	x1, x4
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
LBB0_6:
	.cfi_restore_state
Lloh4:
	adrp	x0, l_anon.16e9e8c0dd96e9ff00565e35c331ccf6.0@PAGE
Lloh5:
	add	x0, x0, l_anon.16e9e8c0dd96e9ff00565e35c331ccf6.0@PAGEOFF
Lloh6:
	adrp	x2, l_anon.16e9e8c0dd96e9ff00565e35c331ccf6.3@PAGE
Lloh7:
	add	x2, x2, l_anon.16e9e8c0dd96e9ff00565e35c331ccf6.3@PAGEOFF
	mov	w1, #8
	bl	__RNvNtCsgDHHaSskbIF_4core6option13expect_failed
	.loh AdrpAdd	Lloh2, Lloh3
	.loh AdrpAdd	Lloh0, Lloh1
	.loh AdrpAdd	Lloh6, Lloh7
	.loh AdrpAdd	Lloh4, Lloh5
	.cfi_endproc

	.section	__TEXT,__literal8,8byte_literals
l_anon.16e9e8c0dd96e9ff00565e35c331ccf6.0:
	.ascii	"overflow"

	.section	__TEXT,__cstring,cstring_literals
l_anon.16e9e8c0dd96e9ff00565e35c331ccf6.1:
	.asciz	"/private/tmp/mech-scalar-results-round27-20261029/codegen-pattern/pair.rs"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.16e9e8c0dd96e9ff00565e35c331ccf6.2:
	.quad	l_anon.16e9e8c0dd96e9ff00565e35c331ccf6.1
	.asciz	"I\000\000\000\000\000\000\000\007\000\000\000I\000\000"

	.p2align	3, 0x0
l_anon.16e9e8c0dd96e9ff00565e35c331ccf6.3:
	.quad	l_anon.16e9e8c0dd96e9ff00565e35c331ccf6.1
	.asciz	"I\000\000\000\000\000\000\000\006\000\000\000Q\000\000"

.subsections_via_symbols
