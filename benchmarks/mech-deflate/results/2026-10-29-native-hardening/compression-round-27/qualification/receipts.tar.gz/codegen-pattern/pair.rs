#[unsafe(no_mangle)]
pub unsafe fn pair_fold(words: *const u32, lens: *const u8, len: usize, mut dynamic:u64, mut fixed:u64) -> (u64,u64) {
    for i in 0..len {
        let word=u64::from(unsafe { *words.add(i) });
        let width=u64::from(unsafe { *lens.add(i) });
        dynamic=dynamic.checked_add(word.checked_mul(width).expect("overflow")).expect("overflow");
        fixed=fixed.checked_add(word.checked_mul(8).expect("overflow")).expect("overflow");
    }
    (dynamic,fixed)
}
