use mech_core::{ValueDataDraft as D,snapshot::{SnapshotValidationContext,ValueDraft}};
use mech_engine::CanonicalSourceFrontend;
use mech_gpu::native_artifact::{JitProgramArtifact,NativeProgramLimitMode};
use mech_syntax::document::{AstNode,DocumentId,DocumentSyntax,ParseConfig,Revision,TextSnapshot,parse_canonical_document};
#[path="/private/tmp/mech-deflate-linear-stack/src/core/tests/support/allocation_probe.rs"]
mod allocation_probe;
#[global_allocator]
static ALLOCATOR:allocation_probe::ProbeAllocator=allocation_probe::ProbeAllocator;
fn main(){
 assert_eq!(allocation_probe::measured(||7).0,7);
 let source=std::fs::read_to_string("/private/tmp/mech-nested-frames-round20-20261029/nested.mec").unwrap();
 let catalog=mech_stdlib::source_catalog();let mode=NativeProgramLimitMode::NoLimits;
 let parsed=parse_canonical_document(TextSnapshot::new(DocumentId(19),Revision(1),source.as_str()).unwrap(),ParseConfig::default());assert!(parsed.is_strictly_clean());
 let original=CanonicalSourceFrontend.compile_document_with_catalog(&DocumentSyntax::cast(parsed.syntax()).unwrap(),catalog.clone()).unwrap().compile_artifact().unwrap();
 let decoded=mech_engine::decode_program_artifact_bytecode_v1(&mech_engine::encode_program_artifact_bytecode_v1(&original).unwrap()).unwrap();
 for(form,artifact)in[("original",original),("decoded",decoded)]{
  let jit=JitProgramArtifact::compile_with_limits(&artifact,&catalog,mode.compilation()).unwrap();let memory=mode.memory_budget();let mut output=vec![None;artifact.outputs().len()];
  for(index,(capacity,marker,allowed,divisor))in[(16,7u64,true,3u64),(305257,91,true,2),(16,13,false,0),(305257,37,true,0),(16,u64::MAX,true,1),(305257,19,true,4)].into_iter().enumerate(){
   let args=artifact.inputs().iter().map(|port|{
    let name=mech_engine::decode_source_input_name(&port.name).unwrap();let data=match name.as_str(){"capacity"=>D::U64(capacity),"marker"=>D::U64(marker),"allowed"=>D::Bool(allowed),"divisor"=>D::U64(divisor),_=>panic!()};
    let value=ValueDraft{schema:port.schema,shape_values:Box::new([]),data}.finalize(&SnapshotValidationContext::new(artifact.schemas())).unwrap();let mut claim=memory.reserve_capacity(value.memory_budget_admission_bytes(&memory).unwrap()).unwrap();value.into_memory_budget(&mut claim).unwrap()
   }).collect::<Vec<_>>();let aliases=args.clone();let prior=output.clone();let before=(memory.used_bytes(),memory.retained_snapshot_nodes());
   let start=std::time::Instant::now();let(result,requests,requested_bytes)=allocation_probe::measured_with_bytes(||jit.evaluate_into(&args,&mut output,mode.execution(),&memory));let seconds=start.elapsed().as_secs_f64();
   let stats=if !allowed||divisor==0||marker==u64::MAX{
    assert!(result.is_err());assert_eq!((memory.used_bytes(),memory.retained_snapshot_nodes()),before);assert!(output.iter().zip(&prior).all(|(a,b)|a.as_ref().unwrap().shares_frozen_storage(b.as_ref().unwrap())));None
   }else{let report=result.as_ref().unwrap();let value=output.last().unwrap().as_ref().unwrap();assert_eq!(value.canonical_data_draft().unwrap(),D::Matrix(vec![D::U64(marker+12/divisor)].into()));let mech_core::ValueData::Matrix(matrix)=value.data()else{panic!()};Some((report.work,report.visits,matrix.unsigned_buffer_capacity()))};
   assert!(args.iter().zip(&aliases).all(|(a,b)|a.shares_frozen_storage(b)));
   println!("{}",serde_json::json!({"kind":"nested-frame-composition","form":form,"case":index,"capacity":capacity,"work_visits_capacity":stats,"error":result.err().map(|e|format!("{e:?}")),"allocation_requests":requests,"requested_bytes":requested_bytes,"seconds":seconds,"private_frame_fields":jit.descriptor().plan().facts().buffer_frames().elements()}));
  }
  drop(output);assert_eq!((memory.used_bytes(),memory.retained_snapshot_nodes()),(0,0));
 }
}
