use mech_core::{ManagedMemoryBudget,ReactiveInstanceId,ValueDataDraft as D,snapshot::{ValueDraft,SnapshotValidationContext}};
use mech_engine::{CanonicalSourceFrontend,resident::{activate,ActivationFacts,CapturedValueInput}};
use mech_syntax::document::{AstNode,DocumentId,DocumentSyntax,ParseConfig,Revision,TextSnapshot,parse_canonical_document};
fn main(){
 let args=std::env::args().collect::<Vec<_>>();let source=std::fs::read_to_string(&args[1]).unwrap();let parsed=parse_canonical_document(TextSnapshot::new(DocumentId(0x50524f47),Revision(1),source.as_str()).unwrap(),ParseConfig::default());assert!(parsed.is_strictly_clean());let original=CanonicalSourceFrontend.compile_document_with_catalog(&DocumentSyntax::cast(parsed.syntax()).unwrap(),mech_stdlib::source_catalog()).unwrap().compile_artifact().unwrap();let bytes=mech_engine::encode_program_artifact_bytecode_v1(&original).unwrap();std::fs::write(&args[2],&bytes).unwrap();let decoded=mech_engine::decode_program_artifact_bytecode_v1(&bytes).unwrap();
 for(form,artifact)in[("original",original),("decoded",decoded)]{for count in[0u64,3,1]{
  let memory=ManagedMemoryBudget::new(16*1024*1024);
  let values=artifact.inputs().iter().map(|input|{let name=mech_engine::decode_source_input_name(&input.name).unwrap();let data=match name.as_str(){"values"=>D::Matrix((0..count).map(|i|D::U64(17+i)).collect()),"words"=>D::Matrix((0..count+1).map(|i|D::U32(29+i as u32)).collect()),"marker"=>D::U64(count+91),_=>panic!()};let shape_values:Box<[u64]>=if let D::Matrix(xs)=&data{mech_core::shape_for_resolved_extents(artifact.schemas().get(input.schema).unwrap(),&[1,xs.len()as u64]).unwrap().parameter_values().to_vec().into()}else{Box::new([])};let value=ValueDraft{schema:input.schema,shape_values,data}.finalize(&SnapshotValidationContext::new(artifact.schemas())).unwrap();let mut claim=memory.reserve_capacity(value.memory_budget_admission_bytes(&memory).unwrap()).unwrap();value.into_memory_budget(&mut claim).unwrap()}).collect::<Vec<_>>();
  let mut instance=activate(ReactiveInstanceId::new(0x50524f47,0),&artifact,&mech_stdlib::source_catalog(),&ActivationFacts::default()).unwrap();
  let captured=instance.plan.inputs.iter().map(|input|CapturedValueInput{slot:input.slot,value:&values[artifact.inputs().iter().position(|v|v.slot==input.artifact_slot).unwrap()]}).collect::<Vec<_>>();
  let outcome=instance.prepare_turn_values(&captured).map_err(|e|format!("{e:?}")).and_then(|turn|turn.publish().map_err(|e|format!("{e:?}")));
  println!("{}",serde_json::json!({"form":form,"count":count,"result":outcome.map(|_|"published")}));
 }}
}
