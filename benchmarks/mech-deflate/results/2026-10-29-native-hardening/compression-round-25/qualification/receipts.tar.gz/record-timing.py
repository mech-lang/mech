from pathlib import Path
import datetime,hashlib,json,subprocess,sys,tarfile
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'primary-fixed'
result=subprocess.run([sys.executable,str(p/'run.py')])
o=w/'benchmarks/mech-deflate/results/2026-10-29-native-hardening/compression-round-25/timing';o.mkdir()
files=[f for f in p.iterdir() if f.suffix in ['.json','.py','.stdout','.stderr','.txt','.log']]
with tarfile.open(o/'receipts.tar.gz','w:gz') as tar:
 for f in sorted(files):tar.add(f,arcname=str(f.relative_to(r)),recursive=False)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
(o/'manifest.json').write_text(json.dumps({'schema':'mech.optimization.receipts.v1','head':head,'exit':result.returncode,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':[{'path':str(f.relative_to(r)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in sorted(files)]},indent=2)+'\n')
if (p/'results.json').exists():
 v=json.loads((p/'results.json').read_text());(o/'results.json').write_text(json.dumps(v,indent=2)+'\n')
 if result.returncode==0:
  text=f"# Reserved append timing checkpoint\n\nProduction {head}, parent25edefcc657cc410dc4be8b71dfd50da8818041b, IR127/work93/ABI36/bytecode14. Unchanged pinned source/artifact, algorithms/tables, real buffers, source allocations, mimalloc and evaluate_into boundary.\n\nProtected full8-byte compression: {v['controls']['before']['multiple_of_roc']:.9f}× to {v['controls']['after']['multiple_of_roc']:.9f}×Roc; {v['controls']['before']['median_seconds']*1000:.9f}ms to {v['controls']['after']['median_seconds']*1000:.9f}ms, fresh reference{v['reference_seconds']*1000:.9f}ms/{v['reference_samples']} samples. {100*(1-v['after_over_before']):.6f}% elapsed reduction, {v['speedup']:.9f}× speedup. Four alternating pairs, twelve primary/control, all observations retained. Separate{v['profile_repetitions']}-repetition profile excluded. Exact10 raw bytes, independent inflation, capacity13, final0 bytes/nodes pass. Work {v['controls']['before']['all_observations'][0]['work']}→{v['controls']['after']['all_observations'][0]['work']} with unchanged route prices. No larger-input claim.\n\n352 actual Core tests and19 focused capacity/append/image checks pass before measurement; all12 architecture checks pass. Further component/scalar qualification follows this immediately committed packet. No next optimization has started.\n"
  (o.parent/'TIMING.md').write_text(text)
subprocess.run(['git','add',str(o.parent)],cwd=w,check=True)
subprocess.run(['git','commit','-m','Record first reserved append compression timing and fresh profile'],cwd=w,check=True)
raise SystemExit(result.returncode)
