from pathlib import Path
import hashlib,json,subprocess,time
r=Path(__file__).resolve().parent;o=r/'runtime-census';binary=o/'gpu-unit-tests'
commands=[('runtime-cohort',['native_artifact::program::runtime::','--skip','complete_unchanged_knucleotide_body_uses_the_owned_emitted_map','--nocapture','--test-threads=1']),('memory-admission',['native_artifact::memory::admission_tests::typed_transport_admission_includes_exact_initialization_metadata','--exact','--nocapture','--test-threads=1']),('closed-tail-fuel',['native_artifact::work::tests::closed_tail_fuel_observes_the_same_spent_account_and_declines_nested_scopes','--exact','--nocapture','--test-threads=1'])]
for label,filters in commands:
 assert not (o/(label+'.json')).exists()
 command=[str(binary)]+filters;start=time.monotonic();p=subprocess.run(command,capture_output=True,text=True,timeout=300)
 (o/(label+'.log')).write_text(p.stdout+p.stderr);(o/(label+'.json')).write_text(json.dumps({'command':command,'exit':p.returncode,'seconds':time.monotonic()-start,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'skipped':'The selected catalog omits stats; the unchanged whole-knucleotide map test has a documented clean-parent failure.' if label=='runtime-cohort' else None},indent=2)+'\n')
 print(p.stdout[-500:]+p.stderr[-500:],flush=True);p.check_returncode()
 assert '0 passed;' not in p.stdout
