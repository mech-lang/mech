use mech_engine::CanonicalSourceFrontend;
use mech_syntax::document::{AstNode,DocumentId,DocumentSyntax,ParseConfig,Revision,TextSnapshot,parse_canonical_document};
fn main() {
 let args=std::env::args().skip(1).collect::<Vec<_>>(); assert_eq!(args.len(),2);
 let text=std::fs::read_to_string(&args[0]).unwrap();
 let parsed=parse_canonical_document(TextSnapshot::new(DocumentId(71),Revision(1),text).unwrap(),ParseConfig::default());
 assert!(parsed.is_strictly_clean());
 let artifact=CanonicalSourceFrontend.compile_document_with_catalog(&DocumentSyntax::cast(parsed.syntax()).unwrap(),mech_stdlib::source_catalog()).unwrap().compile_artifact().unwrap();
 std::fs::write(&args[1],mech_engine::encode_program_artifact_bytecode_v1(&artifact).unwrap()).unwrap();
}
