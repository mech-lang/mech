from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).resolve().parent;p=r.parent/'final-primary';b=json.loads((p/'current-build.json').read_text())
c=b['command'][:-3];j=c.index('-C',c.index('-C')+2);del c[j:j+2];c += [str(r/'producer.rs'),'-o',str(r/'producer')]
rows=[]
def run(label,c):
 x=subprocess.run(c,capture_output=True,text=True,timeout=120)
 (r/(label+'.stdout')).write_text(x.stdout);(r/(label+'.stderr')).write_text(x.stderr)
 rows.append({'label':label,'command':c,'exit':x.returncode})
 (r/'commands.json').write_text(json.dumps(rows,indent=2)+'\n')
 return x
run('build',c).check_returncode()
run('encode',[str(r/'producer'),str(r.parent/'old-length-alternate.mec'),str(r/'alternate.mbc')]).check_returncode()
for label,binary in [('parent',p/'before'),('current',p/'current')]:
 x=run(label,[str(binary),str(r/'alternate.mbc'),'0'])
 assert x.returncode!=0
 assert 'WitnessTypeMismatch' in x.stderr, x.stderr
 assert 'node: NodeId(5)' in x.stderr or 'node: 5' in x.stderr, x.stderr
 assert 'MEASURING' not in x.stderr
(r/'disposition.json').write_text(json.dumps({'classification':'inherited','parent':'25edefcc657cc410dc4be8b71dfd50da8818041b','fixture':'old-length-alternate.mec','condition':'Both frozen clean-parent binary and current binary reject native lowering with WitnessTypeMismatch node5 before measurement; alternate fixture replaced by the valid guarded source for required stale-length proof. No frontend change.','source_sha256':hashlib.sha256((r.parent/'old-length-alternate.mec').read_bytes()).hexdigest(),'bytecode_sha256':hashlib.sha256((r/'alternate.mbc').read_bytes()).hexdigest(),'observations':rows},indent=2)+'\n')
print('Inherited alternate fixture mismatch reproduced before execution')
