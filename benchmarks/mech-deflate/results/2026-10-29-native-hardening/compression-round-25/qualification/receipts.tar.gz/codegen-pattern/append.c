#include <stdint.h>
#include <stddef.h>
size_t c_append_reserved(uint64_t *data, size_t capacity, size_t length, size_t count, uint64_t word) {
 if (length > capacity || count > capacity - length) return length;
 for (size_t i = 0; i < count; ++i) data[length + i] = word;
 return length + count;
}
