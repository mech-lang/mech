	.build_version macos, 11, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_rust_append_reserved
	.p2align	2
_rust_append_reserved:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	subs	x9, x1, x2
	b.lo	LBB0_8
	cmp	x3, x9
	b.hi	LBB0_8
	mov	x8, x1
	adds	x1, x3, x2
	b.hs	LBB0_9
	cmp	x1, x8
	b.hi	LBB0_9
	cbz	x3, LBB0_7
	lsl	x8, x3, #3
	add	x9, x0, x2, lsl #3
LBB0_6:
	str	x4, [x9], #8
	subs	x8, x8, #8
	b.ne	LBB0_6
LBB0_7:
	mov	x2, x1
LBB0_8:
	mov	x0, x2
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
LBB0_9:
	.cfi_restore_state
Lloh0:
	adrp	x3, l_anon.d78f0b2f206dcfffe5a64b4a73425fa1.1@PAGE
Lloh1:
	add	x3, x3, l_anon.d78f0b2f206dcfffe5a64b4a73425fa1.1@PAGEOFF
	mov	x0, x2
	mov	x2, x8
	bl	__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc

	.section	__TEXT,__cstring,cstring_literals
l_anon.d78f0b2f206dcfffe5a64b4a73425fa1.0:
	.asciz	"/private/tmp/mech-append-loops-round25-20261029/codegen-pattern/append.rs"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.d78f0b2f206dcfffe5a64b4a73425fa1.1:
	.quad	l_anon.d78f0b2f206dcfffe5a64b4a73425fa1.0
	.asciz	"I\000\000\000\000\000\000\000\004\000\000\000\027\000\000"

.subsections_via_symbols
