100029b7c:	5f 03 0b eb	cmp	x26, x11
100029b80:	69 04 00 54	b.ls	0x100029c0c
100029b84:	0b 7b 6b 78	ldrh	w11, [x24, x11, lsl #1]
100029b88:	1f 01 0b eb	cmp	x8, x11
100029b8c:	c2 12 ff 54	b.hs	0x100027de4
100029b90:	ac fb fe b5	cbnz	x12, 0x100027b04
100029b94:	94 f8 ff 17	b	0x100027de4
100029b98:	08 00 80 d2	mov	x8, #0x0
100029b9c:	9f f8 ff 17	b	0x100027e18
100029ba0:	0b 00 80 d2	mov	x11, #0x0
100029ba4:	f5 fe ff 17	b	0x100029778
100029ba8:	ed 03 04 aa	mov	x13, x4
100029bac:	ec 03 17 aa	mov	x12, x23
100029bb0:	eb 03 06 aa	mov	x11, x6
100029bb4:	e8 23 41 f9	ldr	x8, [sp, #0x240]
100029bb8:	ee ab 40 f9	ldr	x14, [sp, #0x150]
100029bbc:	df 01 08 eb	cmp	x14, x8
100029bc0:	e0 02 00 54	b.eq	0x100029c1c
100029bc4:	e0 47 41 f9	ldr	x0, [sp, #0x288]
100029bc8:	ee 23 41 f9	ldr	x14, [sp, #0x240]
100029bcc:	e1 03 0e aa	mov	x1, x14
100029bd0:	e2 03 41 f9	ldr	x2, [sp, #0x200]
100029bd4:	17 1a 00 94	bl	_roc_cold_shim.roc_builtins_list_slack_unique
100029bd8:	ee 5f 01 f9	str	x14, [sp, #0x2b8]
100029bdc:	08 00 0e 8b	add	x8, x0, x14
100029be0:	e8 23 01 f9	str	x8, [sp, #0x240]
100029be4:	e7 9f 41 f9	ldr	x7, [sp, #0x338]
100029be8:	e3 a3 41 f9	ldr	x3, [sp, #0x340]
100029bec:	e6 03 0b aa	mov	x6, x11
100029bf0:	f7 03 0c aa	mov	x23, x12
100029bf4:	e4 03 0d aa	mov	x4, x13
100029bf8:	b6 f7 94 52	mov	w22, #0xa7bd
100029bfc:	b6 c6 a3 72	movk	w22, #0x1e35, lsl #16
100029c00:	fe 73 41 f9	ldr	x30, [sp, #0x2e0]
100029c04:	04 a4 04 4f	movi.8h	v4, #0x80, lsl #8
100029c08:	f1 fe ff 17	b	0x1000297cc
100029c0c:	0b 00 80 d2	mov	x11, #0x0
100029c10:	1f 01 0b eb	cmp	x8, x11
100029c14:	e3 fb ff 54	b.lo	0x100029b90
100029c18:	73 f8 ff 17	b	0x100027de4
100029c1c:	e8 bb 54 a9	ldp	x8, x14, [sp, #0x148]
100029c20:	1f 01 0e eb	cmp	x8, x14
100029c24:	40 01 00 54	b.eq	0x100029c4c
100029c28:	e0 47 41 f9	ldr	x0, [sp, #0x288]
100029c2c:	ee ab 40 f9	ldr	x14, [sp, #0x150]
100029c30:	e1 03 0e aa	mov	x1, x14
100029c34:	e2 03 41 f9	ldr	x2, [sp, #0x200]
100029c38:	fe 19 00 94	bl	_roc_cold_shim.roc_builtins_list_slack_unique
100029c3c:	ee 23 01 f9	str	x14, [sp, #0x240]
100029c40:	08 00 0e 8b	add	x8, x0, x14
100029c44:	e8 ab 00 f9	str	x8, [sp, #0x150]
100029c48:	df ff ff 17	b	0x100029bc4
100029c4c:	e8 03 41 f9	ldr	x8, [sp, #0x200]
100029c50:	c8 01 00 37	tbnz	w8, #0x0, 0x100029c88
100029c54:	e8 03 41 f9	ldr	x8, [sp, #0x200]
100029c58:	08 fd 41 d3	lsr	x8, x8, #1
100029c5c:	ee a7 40 f9	ldr	x14, [sp, #0x148]
100029c60:	1f 01 0e eb	cmp	x8, x14
100029c64:	20 01 00 54	b.eq	0x100029c88
100029c68:	e0 47 41 f9	ldr	x0, [sp, #0x288]
100029c6c:	ee a7 40 f9	ldr	x14, [sp, #0x148]
100029c70:	e1 03 0e aa	mov	x1, x14
100029c74:	e2 03 41 f9	ldr	x2, [sp, #0x200]
100029c78:	ee 19 00 94	bl	_roc_cold_shim.roc_builtins_list_slack_unique
100029c7c:	08 00 0e 8b	add	x8, x0, x14
100029c80:	e8 bb 14 a9	stp	x8, x14, [sp, #0x148]
100029c84:	e9 ff ff 17	b	0x100029c28
100029c88:	e0 47 41 f9	ldr	x0, [sp, #0x288]
100029c8c:	e1 a7 40 f9	ldr	x1, [sp, #0x148]
100029c90:	e2 03 41 f9	ldr	x2, [sp, #0x200]
100029c94:	23 00 80 52	mov	w3, #0x1
100029c98:	04 01 80 52	mov	w4, #0x8
100029c9c:	25 00 80 52	mov	w5, #0x1
100029ca0:	8e 19 00 94	bl	_roc_cold_shim.roc_builtins_list_reserve_for_append
100029ca4:	e0 47 01 f9	str	x0, [sp, #0x288]
100029ca8:	e1 a7 00 f9	str	x1, [sp, #0x148]
100029cac:	e2 03 01 f9	str	x2, [sp, #0x200]
100029cb0:	ee ff ff 17	b	0x100029c68
