	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 15, 0	sdk_version 26, 0
	.globl	_c_append_reserved              ; -- Begin function c_append_reserved
	.p2align	2
_c_append_reserved:                     ; @c_append_reserved
	.cfi_startproc
; %bb.0:
	subs	x8, x1, x2
	b.lo	LBB0_6
; %bb.1:
	cmp	x8, x3
	b.lo	LBB0_6
; %bb.2:
	cbz	x3, LBB0_5
; %bb.3:
	add	x8, x0, x2, lsl #3
	mov	x9, x3
LBB0_4:                                 ; =>This Inner Loop Header: Depth=1
	str	x4, [x8], #8
	subs	x9, x9, #1
	b.ne	LBB0_4
LBB0_5:
	add	x2, x3, x2
LBB0_6:
	mov	x0, x2
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
