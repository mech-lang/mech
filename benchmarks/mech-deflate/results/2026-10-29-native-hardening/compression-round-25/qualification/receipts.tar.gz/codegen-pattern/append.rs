#[unsafe(no_mangle)]
pub fn rust_append_reserved(data: &mut [u64], length: usize, count: usize, word: u64) -> usize {
 if length > data.len() || count > data.len() - length { return length; }
 for cell in &mut data[length..length + count] { *cell = word; }
 length + count
}
