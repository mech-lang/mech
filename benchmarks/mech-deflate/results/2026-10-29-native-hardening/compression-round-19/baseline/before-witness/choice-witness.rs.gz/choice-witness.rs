use mech_core::{ValueDataDraft as D,snapshot::{SnapshotValidationContext,ValueDraft}};
use mech_engine::CanonicalSourceFrontend;
use mech_gpu::native_artifact::{JitProgramArtifact,NativeProgramLimitMode};
use mech_syntax::document::{AstNode,DocumentId,DocumentSyntax,ParseConfig,Revision,TextSnapshot,parse_canonical_document};
#[path="/private/tmp/mech-deflate-linear-stack/src/core/tests/support/allocation_probe.rs"]
mod allocation_probe;
#[global_allocator]
static ALLOCATOR:allocation_probe::ProbeAllocator=allocation_probe::ProbeAllocator;
fn main(){
 assert_eq!(allocation_probe::measured(||7).0,7);
 let source=std::fs::read_to_string("/private/tmp/mech-scalar-records-round19-20261029/choice.mec").unwrap();
 let catalog=mech_stdlib::source_catalog();let mode=NativeProgramLimitMode::NoLimits;
 let parsed=parse_canonical_document(TextSnapshot::new(DocumentId(19),Revision(1),source.as_str()).unwrap(),ParseConfig::default());assert!(parsed.is_strictly_clean());
 let original=CanonicalSourceFrontend.compile_document_with_catalog(&DocumentSyntax::cast(parsed.syntax()).unwrap(),catalog.clone()).unwrap().compile_artifact().unwrap();
 let decoded=mech_engine::decode_program_artifact_bytecode_v1(&mech_engine::encode_program_artifact_bytecode_v1(&original).unwrap()).unwrap();
 for(form,artifact)in[("original",original),("decoded",decoded)]{
  let jit=JitProgramArtifact::compile_with_limits(&artifact,&catalog,mode.compilation()).unwrap();let memory=mode.memory_budget();let mut output=vec![None;artifact.outputs().len()];
  for(index,(steps,branch,best,item,cp))in[(0,true,0xfedc_ba98u32,19,300u64),(1,true,7,0x8765_4321,400),(7,false,91,113,500),(2,true,u32::MAX,0x8000_0000,600),(1,true,13,17,u64::MAX),(64,true,31,79,900)].into_iter().enumerate(){
   let args=artifact.inputs().iter().map(|port|{
    let name=mech_engine::decode_source_input_name(&port.name).unwrap();let data=match name.as_str(){"steps"=>D::U64(steps),"branch"=>D::Bool(branch),"best"=>D::U32(best),"item"=>D::U32(item),"cp"=>D::U64(cp),_=>panic!()};
    let value=ValueDraft{schema:port.schema,shape_values:Box::new([]),data}.finalize(&SnapshotValidationContext::new(artifact.schemas())).unwrap();let mut claim=memory.reserve_capacity(value.memory_budget_admission_bytes(&memory).unwrap()).unwrap();value.into_memory_budget(&mut claim).unwrap()
   }).collect::<Vec<_>>();let aliases=args.clone();let prior=output.clone();let before=(memory.used_bytes(),memory.retained_snapshot_nodes());
   let start=std::time::Instant::now();let(result,requests,requested_bytes)=allocation_probe::measured_with_bytes(||jit.evaluate_into(&args,&mut output,mode.execution(),&memory));let seconds=start.elapsed().as_secs_f64();
   let stats=if cp==u64::MAX{
    assert!(result.is_err());assert_eq!((memory.used_bytes(),memory.retained_snapshot_nodes()),before);assert!(output.iter().zip(&prior).all(|(a,b)|a.as_ref().unwrap().shares_frozen_storage(b.as_ref().unwrap())));None
   }else{let report=result.as_ref().unwrap();let n=if branch{steps}else{0};let(l,r)=if n%2==0{(best,item)}else{(item,best)};assert_eq!(output.last().unwrap().as_ref().unwrap().canonical_data_draft().unwrap(),D::U64(u64::from(l)*65537+u64::from(r)+cp+n));Some((report.work,report.visits))};
   assert!(args.iter().zip(&aliases).all(|(a,b)|a.shares_frozen_storage(b)));
   println!("{}",serde_json::json!({"kind":"private-scalar-record-state-machine","form":form,"case":index,"steps":steps,"branch":branch,"work_visits":stats,"error":result.err().map(|e|format!("{e:?}")),"allocation_requests":requests,"requested_bytes":requested_bytes,"seconds":seconds,"private_record_values":jit.descriptor().plan().values().iter().enumerate().filter(|(i,t)|matches!(t.definition().body(),mech_core::SchemaBody::Record(_))&&jit.descriptor().plan().scalar_aggregates().slot_at(*i).is_some()).count()}));
  }
  drop(output);assert_eq!((memory.used_bytes(),memory.retained_snapshot_nodes()),(0,0));
 }
}
