use mech_core::{SchemaBody, ValueData};
use mech_engine::native_artifact::{NativeControlLoop as Loop, NativeIterationAction as Action, NativeMatchAction as Scalar, NativeMatchValue as Value};
fn describe(plan: &mech_engine::native_artifact::NativeProgramArtifactPlan, action: &Action) -> serde_json::Value {
    match action {
        Action::LibraryCall { template, operands, output } => {
            let selector = if template.primitive() == mech_engine::native_artifact::NativeCollectionPrimitive::RecordFieldAccess {
                let constant = plan.constants().iter().find(|c| c.value() == operands[1]);
                constant.and_then(|c| {
                    let ValueData::Id(id) = c.constant().data() else { return None };
                    let SchemaBody::Record(fields) = template.inputs()[0].body() else { return None };
                    Some(serde_json::json!({"constant_id": id,"matching_fields":fields.iter().enumerate().filter(|(_,f)|mech_core::hash_str(&f.name)==*id).map(|(i,f)|serde_json::json!({"ordinal":i,"name":f.name,"kind":format!("{:?}",f.schema)})).collect::<Vec<_>>()}))
                })
            } else { None };
            serde_json::json!({"kind":"call","primitive":format!("{:?}",template.primitive()),"operands":operands.iter().map(|v|v.get()).collect::<Vec<_>>(),"output":output.get(),"selector":selector})
        }
        Action::Scalar(Scalar::Copy {source,output}) => serde_json::json!({"kind":"copy","source":source.get(),"output":output.get()}),
        Action::Structural {source,path,observation,output} => serde_json::json!({"kind":"structural","source":source.get(),"path":format!("{path:?}"),"observation":format!("{observation:?}"),"output":output.get()}),
        other => serde_json::json!({"kind":format!("{other:?}")}),
    }
}
fn main() {
    let artifact = mech_engine::decode_program_artifact_bytecode_v1(&std::fs::read("/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc").unwrap()).unwrap();
    let plan = mech_engine::native_artifact::lower_native_program_artifact_with_definition_table_limit(&artifact,&mech_stdlib::source_catalog(),mech_gpu::native_artifact::NativeProgramLimitMode::NoLimits.compilation().max_definition_table_bytes).unwrap();
    let facts=plan.facts(); let aggregates=facts.scalar_aggregates(); let frames=facts.buffer_frames();
    let mut edges=vec![Vec::<Value>::new();plan.values().len()];
    fn link(edges:&mut [Vec<Value>],a:Value,b:Value){edges[a.get()as usize].push(b);edges[b.get()as usize].push(a);}
    for block in plan.blocks(){if let Action::Scalar(Scalar::Copy{source,output})=block.action(){link(&mut edges,*source,*output);}}
    for control in plan.iterations(){match control{
        Loop::Tail(t)=>{link(&mut edges,t.seed(),t.carrier());link(&mut edges,t.next(),t.carrier());link(&mut edges,t.returned(),t.result());},
        Loop::Iteration(t)=>{link(&mut edges,t.seed(),t.carrier());link(&mut edges,t.next(),t.carrier());link(&mut edges,t.carrier(),t.result());},
        _=>{}
    }}
    let trace:serde_json::Value=serde_json::from_slice(&std::fs::read("/private/tmp/mech-helper-costs-round16-20261029/one-evaluation-call-trace.json").unwrap()).unwrap();
    let mut components=Vec::new();
    for site in [12797usize,15674,27273]{
        let block=&plan.blocks()[site];let Action::LibraryCall{output,template,..}=block.action()else{panic!()};
        assert_eq!(template.primitive(),mech_engine::native_artifact::NativeCollectionPrimitive::CompositePack(3));
        let reached=trace["call_sites"].as_array().unwrap().iter().find(|r|r["site"]==site).unwrap();
        assert_eq!(reached["origin"],format!("{:?}",block.origin()));
        let mut pending=vec![*output];let mut seen=std::collections::BTreeMap::new();
        while let Some(value)=pending.pop(){if seen.insert(value.get(),value).is_none(){pending.extend_from_slice(&edges[value.get()as usize]);}}
        let values=seen.into_values().map(|value|{
            let ty=&plan.values()[value.get()as usize];
            serde_json::json!({"value":value.get(),"body":format!("{:?}",ty.definition().body()),"parameters":ty.definition().dimension_parameters().len(),"scalar_aggregate":aggregates.slot(value),"buffer_frame":frames.slot(value),"public_input":(0..plan.transport_input_count()).any(|i|plan.transport_input_value(i)==value),"public_output":(0..plan.transport_output_count()).any(|i|plan.transport_output_value(i)==value),"definitions":facts.definition_sites(value.get()).unwrap().iter().map(|d|serde_json::json!({"role":format!("{:?}",d.role()),"site":d.site(),"action":d.site().map(|i|describe(&plan,plan.blocks()[i as usize].action()))})).collect::<Vec<_>>(),"reads":facts.read_roles(value).unwrap().iter().map(|read|serde_json::json!({"role":format!("{read:?}"),"action":if let mech_engine::native_artifact::NativeProgramReadRole::Action(i)=*read{Some(describe(&plan,plan.blocks()[i as usize].action()))}else{None}})).collect::<Vec<_>>()})
        }).collect::<Vec<_>>();
        components.push(serde_json::json!({"site":site,"origin":format!("{:?}",block.origin()),"iteration":block.iteration(),"retained_calls":reached["calls"],"baseline_rejection":"NativeScalarAggregates::words rejects Record; pack and selected RecordFieldAccess observation are unsupported; NativeBufferFrames requires an eligible buffer/compound sibling","values":values}));
    }
    println!("{}",serde_json::json!({"compiler":"7f96b935684f15d3a09bbd9a4b949b29d6a625e0","fresh_compression":false,"basis":"current value-level copy/result transport graph plus exact mapped retained round16 sites","components":components}));
}
