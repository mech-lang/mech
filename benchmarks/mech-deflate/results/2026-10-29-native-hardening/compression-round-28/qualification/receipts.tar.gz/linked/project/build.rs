use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::PathBuf};

const EXPECTED: &str = "{\"Cargo.toml\":\"56dc9e648a498da815e50ad9be7a34ccd5a3bef08eede042212272dd96d5fdde\",\"application.mec\":\"93e917922fa4057f846d080f8502b280b89ee06ae42ea078e8f4c4147d409431\",\"factory-profile.json\":\"37da5b8455f00f3b6e0e4579be1c9745ee15ffda90f47987de5240baf4cd2538\",\"native-descriptor.bin\":\"e179f1bebc6396656f0d2f5283d444b386e9f5b4154e03ce2ab38325f432764e\",\"native-descriptor.json\":\"a6b57e07017e58f1a5a2c959e34bd1c6796c9a9a74201c3f247a5c35a30cfeb9\",\"object-identity.bin\":\"2d7da73a2e8b0a4d5b7e04c6f200885c9f57db6df2996b85869a95b109108a4c\",\"program.mecb\":\"c2554b843138f4d65d055d01d02d55058e38e8a156dba758264916d1fc82f66f\",\"program.o\":\"912ce41749bf7d1ab0583f48aae3ca0b242924a3ce59da1cf81c61cbfe575af8\",\"rust-toolchain.toml\":\"19219593d7dba33a75623287af94da940a93fac92eeef99e8fff9b7fd804fcf9\",\"src/main.rs\":\"292df19f8713c6e8079dac2972175401420c733a90ccfd3871ae136069d698f6\"}";
fn digest(bytes: &[u8]) -> String {
    Sha256::digest(bytes)
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect()
}
fn main() {
    assert_eq!(
        std::env::var("HOST").unwrap(),
        std::env::var("TARGET").unwrap(),
        "canonical native object is host-only"
    );
    let root = PathBuf::from(std::env::var_os("CARGO_MANIFEST_DIR").unwrap());
    let expected: BTreeMap<String, String> = serde_json::from_str(EXPECTED).unwrap();
    let manifest_bytes = fs::read(root.join("linked-manifest.json")).unwrap();
    let manifest: serde_json::Value = serde_json::from_slice(&manifest_bytes).unwrap();
    assert_eq!(manifest["schema"], "mech.canonical-linked-program-application.v1");
    let mut pins: BTreeMap<String, String> =
        serde_json::from_value(manifest["pins"].clone()).unwrap();
    let script = pins.remove("build.rs").expect("build script pin");
    assert_eq!(
        digest(&fs::read(root.join("build.rs")).unwrap()),
        script,
        "build script changed"
    );
    assert_eq!(pins, expected, "manifest generated-input pins changed");
    for (name, hash) in expected {
        assert_eq!(
            digest(&fs::read(root.join(&name)).unwrap()),
            hash,
            "changed generated input {name}"
        );
        println!("cargo:rerun-if-changed={name}");
    }
    println!("cargo:rerun-if-changed=linked-manifest.json");
    println!("cargo:rerun-if-changed=build.rs");
    println!("cargo:rustc-link-arg={}", root.join("program.o").display());
}
