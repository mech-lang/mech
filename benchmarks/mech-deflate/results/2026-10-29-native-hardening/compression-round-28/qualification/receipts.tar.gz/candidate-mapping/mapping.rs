use mech_engine::native_artifact::{NativeControlLoop,lower_native_program_artifact_with_definition_table_limit};
fn main(){
 let a=mech_engine::decode_program_artifact_bytecode_v1(&std::fs::read("/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc").unwrap()).unwrap();
 let p=lower_native_program_artifact_with_definition_table_limit(&a,&mech_stdlib::source_catalog(),u64::MAX).unwrap();
 let facts=p.facts();let frames=facts.buffer_frames();let mut rows=Vec::new();
 for (iteration,l) in p.iterations().iter().enumerate(){if ![21,25,168,170,188,190,220,434].contains(&iteration){continue;} if let NativeControlLoop::Tail(t)=l{
  let ty=&p.values()[t.returned().get() as usize];
  let constants=p.constants().iter().filter(|c|matches!(c.constant().data(), mech_core::ValueData::U64(_) | mech_core::ValueData::I64(_))).map(|c|serde_json::json!({"value":c.value().get(),"data":format!("{:?}",c.constant().data())})).collect::<Vec<_>>();
  let actions=p.blocks().iter().enumerate().filter(|(_,b)|b.iteration()==Some(iteration as u32)).map(|(site,b)|{
   let action=match b.action(){mech_engine::native_artifact::NativeIterationAction::LibraryCall{template,..}=>format!("Library::{:?}",template.primitive()),other=>format!("{other:?}")};
   serde_json::json!({"site":site,"action":action,"frame":frames.action(site).map(|f|format!("{:?}",f.operation())),"aggregate":facts.scalar_aggregates().action(site).map(|a|format!("{a:?}"))})
  }).collect::<Vec<_>>();
  rows.push(serde_json::json!({"iteration":iteration,"header":t.header(),"origin":t.origin(),"caller_result":t.result().get(),"returned":t.returned().get(),"result_type":format!("{:?}",ty.definition()),"scalar_result_slot":facts.scalar_aggregates().slot(t.returned()),"result_fields":frames.fields(t.returned()).map(|f|format!("{f:?}")),"carrier_fields":frames.fields(t.carrier()).map(|f|format!("{f:?}")),"actions":actions,"scalar_constants":constants,"tail":format!("{t:?}"),"children":p.iterations().iter().enumerate().filter(|(_,l)|matches!(l, NativeControlLoop::Tail(c) if c.parent()==Some(iteration as u32))).map(|(i,c)|serde_json::json!({"iteration":i,"control":format!("{c:?}")})).collect::<Vec<_>>()}));
 }}
 std::fs::write("/private/tmp/mech-child-loops-round28-20261029/candidate-mapping/mapping.json",serde_json::to_vec_pretty(&rows).unwrap()).unwrap();
}
