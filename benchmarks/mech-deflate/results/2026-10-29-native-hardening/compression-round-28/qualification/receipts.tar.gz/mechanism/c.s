	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 15, 0	sdk_version 26, 0
	.globl	_checked_frame_word             ; -- Begin function checked_frame_word
	.p2align	2
_checked_frame_word:                    ; @checked_frame_word
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	add	x8, x0, x1, lsl #4
	ldr	x8, [x8, #8]
	cmp	x8, #1
	b.ne	LBB0_3
; %bb.1:
	lsl	x8, x1, #1
	ldr	x0, [x0, x8, lsl #3]
	lsr	x8, x0, #32
	cbnz	x8, LBB0_3
; %bb.2:
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB0_3:
	bl	_invalid
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
