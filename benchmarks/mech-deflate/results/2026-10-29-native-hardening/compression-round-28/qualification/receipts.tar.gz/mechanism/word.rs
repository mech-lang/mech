unsafe extern "C" { fn invalid() -> !; }
#[unsafe(no_mangle)]
pub unsafe extern "C" fn checked_frame_word(bank: *const u64, at: usize) -> u64 {
    // SAFETY: caller owns the admitted bank and proves the two-word lane range.
    if unsafe { *bank.add(at * 2 + 1) } != 1 { unsafe { invalid() } }
    let word = unsafe { *bank.add(at * 2) };
    if word > u32::MAX as u64 { unsafe { invalid() } }
    word
}
