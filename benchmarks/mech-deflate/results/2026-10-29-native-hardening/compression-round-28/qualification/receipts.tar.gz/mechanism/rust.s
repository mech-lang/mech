	.build_version macos, 11, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_checked_frame_word
	.p2align	2
_checked_frame_word:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	add	x8, x0, x1, lsl #4
	ldr	x9, [x8, #8]
	cmp	x9, #1
	b.ne	LBB0_3
	ldr	x0, [x8]
	lsr	x8, x0, #32
	cbnz	x8, LBB0_3
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
LBB0_3:
	.cfi_restore_state
	bl	_invalid
	.cfi_endproc

.subsections_via_symbols
