from pathlib import Path
import hashlib,json,shutil,tarfile,subprocess
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');o=w/'benchmarks/mech-deflate/results/2026-10-29-native-hardening/compression-round-28';q=o/'qualification';q.mkdir()
files=[]
allowed={'.rs','.py','.json','.log','.s','.mec','.toml','.lock','.stdout','.stderr','.txt','.in'}
for p in sorted(r.rglob('*')):
 rel=p.relative_to(r)
 if any(x in {'cargo-target','target','reference-pinned','primary'} for x in rel.parts):continue
 if not p.is_file() or p.suffix not in allowed:continue
 files.append((p,str(rel)))
logs=Path('/private/tmp/mech-linear-restack-20261026/validation')
for p in sorted(logs.glob('round28-*')):
 if p.suffix in {'.json','.log'}:files.append((p,'validation/'+p.name))
assert len({name for _,name in files})==len(files)
with tarfile.open(q/'receipts.tar.gz','w:gz') as tar:
 for p,name in files:tar.add(p,arcname=name,recursive=False)
manifest={'schema':'mech.optimization.receipts.v1','scope':'Rejected pure private frame scalar-read experiment. Prototype46aece8b8 was qualified and measured; source/tests restored to reviewed d818db593a in880ee6337. All primary/scalar observations are already separately immediately committed.','files':[{'path':n,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p,n in files]}
(q/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name,target in [('census-comparison.json','census-comparison.json'),('partitioned-profile.json','partitioned-profile.json'),('restored-source-identity.json','restored-source-identity.json'),('rollback.json','rollback.json'),('object-audit/sections.json','object-sections.json'),('linked2/closure.json','linked-closure.json')]:shutil.copyfile(r/name,q/target)
t=json.loads((r/'primary/results.json').read_text());s=json.loads((r/'primary/scalar-results.json').read_text());b=t['controls']['before'];a=t['controls']['after']
assert '237 passed; 0 failed' in (r/'full-components-final.log').read_text()
assert '301 passed; 0 failed' in (r/'gpu-units/runtime.log').read_text()
assert json.loads((logs/'round28-architecture-final.json').read_text())['exit']==0
# Confirm no live or proposed compiler change is hidden in the result packet.
assert not subprocess.check_output(['git','diff','d818db593a707ebc37c602e14084dde1af0948fa','--','hosts/gpu','src','machines','benchmarks/mech-deflate/native-profile'],cwd=w,text=True).strip()
text=f'''# Private frame scalar-read experiment: not retained

The requested scalar-aggregate numeric-loop integration is already retained in production562a15efb08345b7d2daad3cb3deb43805d9c9b3 and reviewed checkpoint **d818db593a707ebc37c602e14084dde1af0948fa**. Its [round27 packet](../compression-round-27/CLOSURE.md) records the five reached scalar-pair reductions, sixth unreached candidate, existing aggregate slots/actions, independent image validation, checked/fallback synchronization and **27.748924× →20.259555×Roc (26.989763% elapsed reduction)**. That capability remains intact.

This adjacent transport experiment did not establish a material gain and **is not retained**. PR base **eacb00fcb3352fbbf3d4dddb7b983f4c130f4a7b**. Experiment base **d818db593a707ebc37c602e14084dde1af0948fa**; parent witness/design **ad4c1d6ef83fa7d0b21a047d002b9102b9c9a1b9**; prototype **46aece8b8**; immediately committed timing/profile **73f1ef0fb**; immediately committed scalar controls **953daf6b5**; restoration **880ee63378427e34071264f1ca56989e29ef1e2a**. Final compiler/runtime/tests/harness tree identities equald818 exactly; [mechanical proof](qualification/restored-source-identity.json). Final IR/work/ABI/bytecode **129/93/36/14**. No pointer loan, native frame-read emitter, new eligibility or new test obligation survives. This packet adds experiment evidence only.

## Mechanism and qualification

Reached parent/child boundaries remain ordinary. Rather than remove their leaf guard without a nested ownership/funding proof, the prototype tried exact structural scalar projections around those children. It loaned the session's existing two-word payload/current-validity bank to generated checked loads through one call-scoped private local. It reused the existing owner, checked schema/bits/currentness, cleared the pointer after entry, kept runtime ABI36 and source work prices, and independently rederived path admission on restoration. Only projections with **empty retirement inventories** qualified:808 static sites,656 reached helper calls.1211 static retiring projections/945 reached calls kept their complete helper and ordering; selected record/library calls and managed projections were unchanged.

This scope followed an actual failure: deleting a projection helper also deleted last-use retirement, retaining old array references. The original prototype passed235/237 component tests but failed the unchanged reservation-copy and zero-clone tests. A real-visit anchor alone still failed both. Requiring empty action.retire inventories fixed both without changing allowances or expected values. This is useful rejection evidence for any later attempt to combine scalar transport with frame retirement.

The final prototype passes **552 maintained Rust checks**: GPU runtime301 + exact transport admission1 + closed-fuel1; existing component cohort237, including five new focused checks; selected scalar8 + bits3; actual linked process1. Focused11 overlaps the237 and is not extra. One separate complete-program callback census passes and adds no performance observation. All12 architecture/catalog/inventory/unsafe/warnings/format checks pass. No allowlist, warning, work price or allowance changes.

Focused checks cover all seven scalar kinds and exact float bits; original/decoded artifacts and independent image restoration; fresh recursive arguments and toggled Bool around a real child; repeated/changing evaluations; assertion/arithmetic/load order; tight native/library funding; unchanged previously published aliases; cleanup and retry. The actual generated linked Object and descriptor execute3→0(assertion before division)→2 with outputs4→unchanged4→6 and recovery. The linked orchestration uses the same public generator and maintained retry driver via direct Cargo CLI, rather than claiming that the mech_build Rust test launcher ran. Runtime-only closure excludes parser/JIT/compiler features. Its first-Dwarnings build rejected codegen-only named proof fields; the final tuple proof removes that warning and the actual build/run passes. [Linked closure](qualification/linked-closure.json).

Production default build: `cargo build --release --locked --offline --manifest-path benchmarks/mech-deflate/native-profile/Cargo.toml --message-format=json --bin native_frame_transport --bin artifact_review`. Runtime test dependencies add only `--features mech-runtime/compiler`. GPU production features: aot/canonical-native/canonical-native-program/canonical-native-program-runtime/canonical-native-runtime/jit. Nightly2026-03-03,aarch64mac,jobs1,incremental0,opt3 production,opt1 maintained integration bodies,opt0 actual GPU unit root,-Dwarnings. The linked project uses canonical-native-program-runtime/canonical-native-runtime with the generated selected Core/Engine profile. Every actual command, feature set, hash, test count and output is in the [{len(files)}-file receipt manifest](qualification/manifest.json). Engine/Core implementation is unchanged and their earlier tests are not counted fresh.

## Complete small-case measurement

Protected unchanged complete eight-byte `abcdefgh`, level12. **{b['multiple_of_roc']:.9f}× →{a['multiple_of_roc']:.9f}×Roc**, **{b['median_seconds']*1000:.9f}→{a['median_seconds']*1000:.9f}ms**, fresh reference **{t['reference_seconds']*1000:.9f}ms/20,000 observations**. Pooled-median elapsed reduction **{100*(1-t['after_over_before']):.9f}%**. Four fixed alternating process pairs,12 primary/control, all40 observations retained; separate677-repetition profile excluded. No compiler/test/audit/other benchmark ran concurrently with protected primary/profile or scalar measurement. Same pinned mimalloc2.1.7, same evaluate_into-only harness; compilation, reserve13, clear/rebind, verification and drop remain excluded. Every observation checks exact ten bytes, independent inflation, input aliases, capacity13 and final0 bytes/nodes. [Immediate primary packet](timing/manifest.json).

Pair ratios1.056861721/0.962506649/1.030815791/0.962274997 all favor the first binary in the process pair, regardless of whether it is before or after. Median paired ratio **{t['median_paired_ratio']:.9f}**. This does **not** establish the requested larger win. Do not call the pooled1.99% a reliably retained improvement or compare its fresh reference against older rounds as a new speedup.

The actual callback census confirms the intended mechanism: visits14894→14661; helpers9500→8844; helpers at frame-labelled sites7161→6505; eligible pure-projection helpers656→0. Work **45060848918→45060870730** and transport4758520→4758528, with unchanged prices. Conservative funded paths account for changed route work; identical logical work was not required. [Census](qualification/census-comparison.json).

Object text **12923596→13669120 bytes (+745524)**; whole Object12924328→13669848; stack108032→108208. The code-growth cost and new pointer/eligibility machinery are not justified by this result. [Object sections](qualification/object-sections.json).

The separate samples contain1283/1292 weights. Prototype partition:334 frame,250 ordinary visit,261 other helper,126 selected call,321 remaining. Repeated runtime frame_scalars::read contributes32 exclusive weights; that is a demonstrated cost of recomputing the proof, not an elapsed-time attribution. Counts and samples are diagnostic, not guaranteed removable percentages. [Profiles](qualification/partitioned-profile.json). Mechanism-only C/Rust controls emit direct payload/currentness loads, bit checks and a cold invalid path; zero control executions or elapsed comparisons. Actual reference binary inspection retains a typed-register loop at100018044..100018064; no exact anonymous frame-layout/source association is claimed.

All12 protected scalar controls pass unchanged≤1.05, maximum direct ratio **{max(v['after_over_before'] for v in s['controls'] if v['case']!='scalar-loop'):.9f}**, identical allocation requests/bytes and zero scalar-loop allocation slope. [Immediate scalar packet](scalar/manifest.json). These controls qualify the rejected prototype; no new final compiler is claimed.

## Failure ledger and source integrity

- Clean-parent witness:1 pass,1 expected selection failure; ordinary values already correct.
- First prototype compiler build: mutable report reborrow E0499; fixed before final build.
- First broad component qualification:235 pass/2 introduced copy failures. Keeping visit anchors did not resolve them. Empty-retirement eligibility resolves both; final237 pass unchanged.
- Initial standalone focused test harness: unused linked fixture alias under-Dwarnings; used the fixture through its existing alias. Final focused11 passes.
- First runtime-only linked build: codegen-only proof fields trigger dead_code under-Dwarnings; tuple proof resolves it. Final actual linked build/run passes.
- A broader linked dependency Cargo profile was intentionally stopped when it selected unnecessary compiler dependencies and math rebuilding. Narrow dependencies complete; cancellation is orchestration, not a compiler failure. All attempts and exits are archived.
- No introduced failure remains in final source because the experiment is removed. Inherited limitations from the reviewed round27 packet remain inherited and were not reopened: resident nested-record/alternate geometry, default resident matchfinder policy denials, omitted not/xor all-primitives case and absent-stats whole-knucleotide case. Larger-input/full-input timing, unrelated Engine/Core reruns, and the original linked Rust test launcher remain skipped. CI is cancelled by user direction and is not green; PR remains draft.

The unchanged source freshly reproduces **4,138,627** measured bytecode bytes; decoded reencoding agrees. Source/artifact SHA256 **331e659e92181d803b3d87218effe88f711c2e8ecad9f31838fc50991de1c5c9** / **a2a551911949f8c5fdc64273a43662c2a9c4953b853136c19d196692fdac45a7**. Compressor revision **671077457ff7ef3a3d44caf715a3fc595addf379**; reference compiler **d99c7b838fb05bb1047eb0c18d4d06d0f86f345d**. Algorithms, tables, depth300/nice258, near-EOF limits,262144/U16 tree,1500513/U32 cache, original allocation sites and timing boundaries are unchanged. Mech performs compression.

The final retained compiler is the reviewed scalar-aggregate implementation, whose qualified original result remains20.259555×. This experiment also freshly measured that exact retained binary at20.886173× against its own fresh reference; neither is a larger-input throughput result. No final compiler retiming is necessary after byte-identical restoration. The1× objective remains active. Next bounded evidence should inspect actual replacement copies, ownership handoff and denial reasons on current reached sites before choosing another ownership change; any proposed parent/child composition still needs its own exact ownership/funding witness.
'''
(o/'CLOSURE.md').write_text(text)
print('archive_files',len(files),'archive_bytes',(q/'receipts.tar.gz').stat().st_size)
