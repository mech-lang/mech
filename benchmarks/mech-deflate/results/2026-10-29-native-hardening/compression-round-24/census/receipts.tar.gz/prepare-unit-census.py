from pathlib import Path
import hashlib,json,re,shutil
r=Path(__file__).resolve().parent;o=r/'unit-census';o.mkdir();w=Path('/private/tmp/mech-deflate-linear-stack')
original=Path('/private/tmp/mech-timing-round.rs').read_text();prefix=original.split('fn main() {',1)[0].replace('use std::{sync::Arc, time::Instant};','use std::sync::Arc;')
start=original.split('fn main() {',1)[1]
start=start.replace('let args=std::env::args().skip(1).collect::<Vec<_>>(); assert_eq!(args.len(), 2,"ARTIFACT SAMPLES"); let samples:usize=args[1].parse().unwrap();', 'let artifact_path="/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc";')
start=start.replace('&args[0]','artifact_path').replace('let at=Instant::now();','')
start=re.sub(r' eprintln!\("\{\}",serde_json::json!\(\{"phase":"compiled","seconds":at.elapsed\(\).as_secs_f64\(\)\}\)\);','',start)
start=start.replace('for sample in 0..=samples + 1 {','for sample in 0..=1 {')
needle='eprintln!("MEASURING {sample}");let start=Instant::now();let report=jit.evaluate_into(&args,&mut output,mode.execution(),&memory).unwrap();let seconds=start.elapsed().as_secs_f64();'
assert needle in start
start=start.replace(needle,'''let report=if sample==0 {jit.evaluate_into(&args,&mut output,mode.execution(),&memory).unwrap()} else {counted(&jit,&args,&mut output,mode.execution(),&memory)};assert_eq!(report.work,222049095608);''')
start=re.sub(r'  println!\("\{\}",serde_json::json!\(\{.*?\}\)\);', '  let _=(before,sample);', start)
helpers=r'''
use std::cell::{Cell,RefCell};
use std::collections::BTreeMap;
use std::ffi::c_void;
use crate::native_artifact::program::{protocol::abi::{Frame,Helper},runtime::{self,NativeProgramExecutionLimits,NativeProgramExecutionReport}};
type Admit=unsafe extern "C" fn(*mut c_void,u64)->u64;
#[derive(Default)]
struct Counts { admits:BTreeMap<u64,u64>,helpers:BTreeMap<(u64,u64),u64>,examples:BTreeMap<(u64,u64),Vec<[u64;3]>> }
thread_local! {
 static OBS:RefCell<Counts>=RefCell::new(Counts::default());
 static SAVED_HELPER:Cell<Option<Helper>>=const {Cell::new(None)};
 static SAVED_ADMIT:Cell<Option<Admit>>=const {Cell::new(None)};
}
unsafe extern "C" fn counted_admit(raw:*mut c_void,site:u64)->u64 {
 OBS.with(|v| *v.borrow_mut().admits.entry(site).or_default()+=1);
 match SAVED_ADMIT.with(Cell::get) {
  Some(call)=>unsafe {call(raw,site)},
  None=>crate::native_artifact::abi::STATUS_ABI,
 }
}
unsafe extern "C" fn counted_helper(raw:*mut c_void,site:u64,operation:u64,first:u64,second:u64,third:u64,result:*mut u64)->u64 {
 OBS.with(|v| {let mut v=v.borrow_mut();let key=(site,operation);*v.helpers.entry(key).or_default()+=1;let e=v.examples.entry(key).or_default();if e.len()<3 {e.push([first,second,third]);}});
 match SAVED_HELPER.with(Cell::get) {
  Some(call)=>unsafe {call(raw,site,operation,first,second,third,result)},
  None=>crate::native_artifact::abi::STATUS_ABI,
 }
}
fn counted(jit:&JitProgramArtifact,inputs:&[Value],outputs:&mut [Option<Value>],limits:NativeProgramExecutionLimits,memory:&ManagedMemoryBudget)->NativeProgramExecutionReport {
 OBS.with(|v|*v.borrow_mut()=Counts::default());
 let entry=jit.test_checked_entry();
 let report=runtime::execute(jit.descriptor(),|frame:*mut Frame| {
  // Same synchronous entry/callback restoration as the maintained admission probe.
  let previous=unsafe {((*frame).base.admit_next,(*frame).helper)};
  SAVED_ADMIT.with(|v|v.set(Some(previous.0)));SAVED_HELPER.with(|v|v.set(Some(previous.1)));
  unsafe {(*frame).base.admit_next=counted_admit;(*frame).helper=counted_helper;}
  let status=unsafe {entry(frame)};
  unsafe {(*frame).base.admit_next=previous.0;(*frame).helper=previous.1;}
  SAVED_ADMIT.with(|v|v.set(None));SAVED_HELPER.with(|v|v.set(None));status
 },inputs,outputs,limits,memory).unwrap();
 let obs=OBS.with(|v|std::mem::take(&mut *v.borrow_mut()));
 let plan=jit.descriptor().plan();let layout=&jit.descriptor().metadata().buffer_frames;
 let mut rows=Vec::new();
 for (site,block) in plan.blocks().iter().enumerate() {
  let admits=obs.admits.get(&(site as u64)).copied().unwrap_or(0);
  let helpers=obs.helpers.iter().filter(|((s,_),_)|*s==site as u64).map(|(&(s,operation),&count)|serde_json::json!({"operation":operation,"count":count,"first_words":obs.examples[&(s,operation)]})).collect::<Vec<_>>();
  if admits==0&&helpers.is_empty(){continue;}
  let action=match block.action(){mech_engine::native_artifact::NativeIterationAction::LibraryCall{template,..}=>format!("Library::{:?}",template.primitive()),other=>format!("{other:?}")};
  rows.push(serde_json::json!({"site":site,"origin":block.origin(),"iteration":block.iteration(),"action":action,"frame":layout.action(site).map(|a|format!("{:?}",a.operation())),"admits":admits,"helpers":helpers}));
 }
 let totals=serde_json::json!({"schema":"mech.private-helper-census.v1","head":"9fa5dfb3dc780672dbe33139f870780fc4d1682a","source_artifact_sha256":"a2a551911949f8c5fdc64273a43662c2a9c4953b853136c19d196692fdac45a7","performance_observations":0,"scope":"One complete decoded eight-byte compression, second visit, actual checked JIT entry/runtime. Only callback wrappers observe arguments and delegate unchanged. Diagnostic metadata allocations and all elapsed values excluded from performance results.","report":format!("{report:?}"),"admits":obs.admits.values().sum::<u64>(),"helper_calls":obs.helpers.values().sum::<u64>(),"rows":rows});
 std::fs::write("/private/tmp/mech-frame-loops-round24-20261029/unit-census/counts.json",serde_json::to_vec_pretty(&totals).unwrap()).unwrap();
 report
}
#[test]
fn complete_compressor_private_helper_census() {
'''
source=prefix+helpers+start
assert 'Instant' not in source and 'elapsed' not in source.split('fn complete_compressor_private_helper_census()',1)[1]
(o/'probe.rs').write_text(source)
manifest=[]
def adapt(src,dst,special):
 text=src.read_text()
 pattern=r'(?m)^(?:#\[path\s*=\s*"([^"]+)"\]\n)?((?:pub(?:\([^)]+\))?\s+)?mod\s+)(\w+);'
 def replace(m):
  explicit,decl,name=m.groups()
  if name in special:path=special[name]
  elif explicit:path=(src.parent/explicit).resolve()
  else:
   path=src.parent/(name+'.rs')
   if not path.exists():path=src.parent/name/'mod.rs'
  assert path.exists(),path
  return '#[path = '+json.dumps(str(path))+']\n'+decl+name+';'
 text=re.sub(pattern,replace,text)
 def includes(m):return m[1]+'('+json.dumps(str((src.parent/m[2]).resolve()))+')'
 text=re.sub(r'(include_(?:str|bytes)!)\("([^"]+)"\)',includes,text)
 dst.write_text(text)
 manifest.append({'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'adapted':str(dst),'adapted_sha256':hashlib.sha256(dst.read_bytes()).hexdigest()})
native=w/'hosts/gpu/src/native_artifact/mod.rs';adapter=o/'native_artifact.rs';adapter.touch()
adapt(native,adapter,{})
with adapter.open('a') as f:f.write('\n#[path = '+json.dumps(str(o/'probe.rs'))+']\nmod census;\n')
adapt(w/'hosts/gpu/src/lib.rs',o/'lib.rs',{'native_artifact':adapter})
(o/'source-adapter.json').write_text(json.dumps({'adaptation':'Absolute module/include paths plus a single diagnostic module under native_artifact; all maintained production function bodies unchanged. No workspace source edit.','files':manifest},indent=2)+'\n')
s=Path('/private/tmp/mech-scalar-paths-round22-20261029/unit-build.py').read_text()
s=s.replace("metadata=json.loads((r/'default-metadata.json').read_text())","metadata=json.loads(Path('/private/tmp/mech-scalar-paths-round22-20261029/default-metadata.json').read_text())")
s=s.replace("str(workspace/'hosts/gpu/src/lib.rs')","str(r/'unit-census/lib.rs')")
s=s.replace("'admission_tests','numeric_fuel_tests'","'complete_compressor_private_helper_census'")
(r/'unit-build.py').write_text(s)
print('Prepared adapted actual GPU unit root with one diagnostic module')
