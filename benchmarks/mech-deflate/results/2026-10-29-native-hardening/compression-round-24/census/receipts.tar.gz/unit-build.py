from pathlib import Path
import hashlib,json,os,subprocess,time,sys
r=Path(__file__).resolve().parent
stage=sys.argv[1];logname=sys.argv[2];out=r/stage;out.mkdir()
workspace=Path('/private/tmp/mech-deflate-linear-stack');logs=Path('/private/tmp/mech-linear-restack-20261026/validation')
rows=[json.loads(l) for l in (logs/logname).read_text().splitlines() if l.startswith('{')]
assert rows[-1]=={'reason':'build-finished','success':True}
metadata=json.loads(Path('/private/tmp/mech-scalar-paths-round22-20261029/default-metadata.json').read_text())
package=next(p for p in metadata['packages'] if p['name']=='mech-gpu')
node=next(n for n in metadata['resolve']['nodes'] if n['id']==package['id'])
libs={}
for dep in node['deps']:
 matches=[x for x in rows if x.get('reason')=='compiler-artifact' and x['package_id']==dep['pkg'] and 'custom-build' not in x['target']['kind']]
 if matches:
  paths=[Path(p) for p in matches[-1]['filenames'] if p.endswith(('.rlib','.dylib'))]
  if paths:libs[dep['name']]=paths[0]
for name in ['mech_syntax','mech_runtime','mech_stdlib']:
 matches=[x for x in rows if x.get('reason')=='compiler-artifact' and x['target']['name']==name and 'custom-build' not in x['target']['kind']]
 assert len(matches)==1,(name,len(matches))
 libs[name]=next(Path(p) for p in matches[0]['filenames'] if p.endswith('.rlib'))
tempfile=json.loads(Path('/private/tmp/mech-multi-results-round21-20261029/corruption-corrected/nested-component-build.json').read_text())['tempfile']
assert hashlib.sha256(Path(tempfile['path']).read_bytes()).hexdigest()==tempfile['sha256']
libs['tempfile']=Path(tempfile['path'])
features=next(x['features'] for x in rows if x.get('reason')=='compiler-artifact' and x['target']['name']=='mech_gpu')
command=['/Users/coreymontella/.rustup/toolchains/nightly-2026-03-03-aarch64-apple-darwin/bin/rustc','--edition=2024','--crate-name','mech_gpu','--test','-C','opt-level=0','-C','link-arg=/private/tmp/roc-deflate-repro-20261024/roc-deflate/benchmark/echo-clock/targets/arm64mac/mimalloc.o','-D','warnings','-L','dependency=/private/tmp/mech-live-control-target/release/deps']
for feature in features:command+=['--cfg',f'feature="{feature}"']
for name,path in libs.items():assert path.is_file(),path;command+=['--extern',name+'='+str(path)]
command+=[str(r/'unit-census/lib.rs'),'-o',str(out/'gpu-unit-tests')]
env={**os.environ,'CARGO_MANIFEST_DIR':str(workspace/'hosts/gpu'),'CARGO_PKG_NAME':'mech-gpu','CARGO_PKG_VERSION':'0.3.5','CARGO_PKG_VERSION_MAJOR':'0','CARGO_PKG_VERSION_MINOR':'3','CARGO_PKG_VERSION_PATCH':'5','CARGO_PKG_DESCRIPTION':package['description']}
start=time.monotonic();p=subprocess.run(command,capture_output=True,text=True,env=env)
(out/'build.log').write_text(p.stdout+p.stderr);(out/'build.json').write_text(json.dumps({'command':command,'exit':p.returncode,'seconds':time.monotonic()-start,'features':features,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=workspace,text=True).strip(),'dirty':subprocess.check_output(['git','status','--porcelain'],cwd=workspace,text=True),'gpu_source_sha256':hashlib.sha256(b''.join(name.encode()+b'\0'+hashlib.sha256((workspace/name).read_bytes()).digest() for name in subprocess.check_output(['git','ls-files','hosts/gpu/src'],cwd=workspace,text=True).splitlines())).hexdigest(),'libraries':{name:{'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()} for name,path in libs.items()}},indent=2)+'\n')
print(p.stderr[-6000:],flush=True);p.check_returncode()
command=[str(out/'gpu-unit-tests'),'complete_compressor_private_helper_census','--nocapture','--test-threads=1']
start=time.monotonic();p=subprocess.run(command,capture_output=True,text=True,timeout=300)
(out/'run.log').write_text(p.stdout+p.stderr);(out/'run.json').write_text(json.dumps({'command':command,'exit':p.returncode,'seconds':time.monotonic()-start,'binary_sha256':hashlib.sha256((out/'gpu-unit-tests').read_bytes()).hexdigest()},indent=2)+'\n')
print(p.stdout[-9000:]+p.stderr[-4000:],flush=True);p.check_returncode()
