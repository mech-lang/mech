import collections,json,os,traceback
from pathlib import Path
import lldb
ROOT=Path('/private/tmp/mech-frame-loops-round24-20261029/census')
active=False
helper=None
counts=collections.Counter()
examples={}
markers=[]
def reg(frame,name):return frame.FindRegister(name).GetValueAsUnsigned()
def on_helper(frame,location,internal_dict):
 global active
 if not active:return False
 try:
  site=reg(frame,'x1');operation=reg(frame,'x2');words=[reg(frame,'x3'),reg(frame,'x4'),reg(frame,'x5')]
  assert site<1000000,site
  key=(site,operation);counts[key]+=1
  e=examples.setdefault(key,{'first':[],'last':None})
  if len(e['first'])<3:e['first'].append(words)
  e['last']=words
 except Exception:
  (ROOT/'callback-error.txt').write_text(traceback.format_exc());return True
 return False
def on_marker(frame,location,internal_dict):
 global active
 try:
  stage=reg(frame,'x0');sample=reg(frame,'x1');pid=frame.GetThread().GetProcess().GetProcessID()
  markers.append({'stage':stage,'sample':sample})
  (ROOT/'live.json').write_text(json.dumps({'pid':pid,'markers':markers})+'\n')
  if sample!=1:return False
  if stage==0:
   active=True;helper.SetEnabled(True)
  else:
   helper.SetEnabled(False);active=False
   rows=[{'site':s,'operation':op,'count':n,**examples[(s,op)]} for (s,op),n in sorted(counts.items(),key=lambda kv:(-kv[1],kv[0]))]
   (ROOT/'counts.json').write_text(json.dumps({'schema':'mech.private-helper-census.v1','compiler_head':'9fa5dfb3dc780672dbe33139f870780fc4d1682a','scope':'One complete eight-byte main-artifact invocation; sample1/profile-tagged. Seed,clear,rebind,verification andall other invocations excluded. Debugger elapsed rows are not performance observations.','markers':markers,'helper_calls':sum(counts.values()),'unique_site_operations':len(rows),'rows':rows},indent=2)+'\n')
 except Exception:
  (ROOT/'callback-error.txt').write_text(traceback.format_exc());return True
 return False
def entry_breakpoint(target,name):
 found=target.FindFunctions(name,lldb.eFunctionNameTypeFull);assert found.GetSize()==1,(name,found.GetSize())
 c=found.GetContextAtIndex(0);function=c.GetFunction();symbol=c.GetSymbol()
 address=function.GetStartAddress() if function.IsValid() else symbol.GetStartAddress()
 assert address.IsValid(),name
 b=target.BreakpointCreateBySBAddress(address);assert b.GetNumLocations()==1,(name,b.GetNumLocations())
 return b
def __lldb_init_module(debugger,internal_dict):
 global helper
 t=debugger.GetSelectedTarget()
 helper=entry_breakpoint(t,'mech_gpu::native_artifact::program::runtime::hooks::helper')
 helper.SetScriptCallbackFunction(__name__+'.on_helper');helper.SetEnabled(False)
 marker=entry_breakpoint(t,'mech_trace_marker');marker.SetScriptCallbackFunction(__name__+'.on_marker')
 print('CENSUS_READY exact-entry breakpoints; main sample1 only',flush=True)
