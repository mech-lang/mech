from pathlib import Path
import hashlib,json,os,signal,subprocess,time
r=Path(__file__).resolve().parent
binary=r/'census';artifact=Path('/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc')
assert hashlib.sha256(artifact.read_bytes()).hexdigest()=='a2a551911949f8c5fdc64273a43662c2a9c4953b853136c19d196692fdac45a7'
cmd=['lldb','--no-lldbinit','-b','-o','settings set target.disable-aslr false','-o','command script import '+str(r/'census_hooks.py'),'-o','run','-o','process status','--',str(binary),str(artifact),'0']
assert not (r/'debugger.stdout').exists()
t=time.monotonic()
with (r/'debugger.stdout').open('w') as out,(r/'debugger.stderr').open('w') as err:
 p=subprocess.Popen(cmd,stdout=out,stderr=err,start_new_session=True)
 try:code=p.wait(timeout=240);timed_out=False
 except subprocess.TimeoutExpired:
  timed_out=True
  if (r/'live.json').exists():
   child=json.loads((r/'live.json').read_text())['pid']
   try:os.kill(child,signal.SIGTERM)
   except ProcessLookupError:pass
  os.killpg(p.pid,signal.SIGTERM)
  try:code=p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
receipt={'command':cmd,'exit':code,'process_seconds':time.monotonic()-t,'timed_out':timed_out,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'primary_performance_observations':0,'scope':'Diagnostic debugger census only; all printed elapsed rows excluded from performance results.'}
(r/'debugger.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(receipt,flush=True);print((r/'debugger.stdout').read_text()[-4500:]);print((r/'debugger.stderr').read_text()[-2500:])
assert code==0 and not timed_out
assert (r/'counts.json').exists() and not (r/'callback-error.txt').exists()
assert 'CLEANUP bytes=0 nodes=0' in (r/'debugger.stdout').read_text()+(r/'debugger.stderr').read_text()
