use mech_core::{ManagedMemoryBudget, Value, ValueData, ValueDataDraft as Data, snapshot::{SequenceView, SnapshotValidationContext, ValueDraft}};
use mech_engine::{CanonicalSourceFrontend, ProgramArtifact};
use crate::native_artifact::{JitProgramArtifact, NativeProgramLimitMode};
use mech_syntax::document::{AstNode, DocumentId, DocumentSyntax, ParseConfig, Revision, TextSnapshot, parse_canonical_document};
use std::sync::Arc;
#[path = "/private/tmp/mech-linear-restack-20261026/complete-focused/src/pinned_allocator.rs"]
mod pinned_allocator;
#[global_allocator]
static ALLOCATOR: pinned_allocator::PinnedMimalloc = pinned_allocator::PinnedMimalloc;
fn source(text: &str) -> ProgramArtifact {
 let parsed = parse_canonical_document(TextSnapshot::new(DocumentId(71), Revision(1), text).unwrap(), ParseConfig::default());
 assert!(parsed.is_strictly_clean());
 CanonicalSourceFrontend.compile_document_with_catalog(&DocumentSyntax::cast(parsed.syntax()).unwrap(), mech_stdlib::source_catalog()).unwrap().compile_artifact().unwrap()
}
fn words(value: &Value) -> &[u8] { let ValueData::Matrix(m) = value.data() else { panic!() }; let SequenceView::U8(bytes) = m.elements() else { panic!() }; bytes }
fn capacity(value: &Value) -> usize { let ValueData::Matrix(m) = value.data() else { panic!() }; m.unsigned_buffer_capacity().unwrap() }
fn import(artifact: &ProgramArtifact, input: &[(String, Data)], memory: &ManagedMemoryBudget) -> Vec<Value> {
 let schemas=Arc::new(artifact.schemas().clone());
 artifact.inputs().iter().map(|port| {
  let name=mech_engine::decode_source_input_name(&port.name).unwrap();
  let data=input.iter().find(|(n,_)| *n==name).unwrap().1.clone();
  let shape_values: Box<[u64]>=if let Data::Matrix(values)=&data {mech_core::shape_for_resolved_extents(schemas.get(port.schema).unwrap(), &[1,values.len() as u64]).unwrap().parameter_values().into()} else {Box::new([])};
  let v=ValueDraft{schema:port.schema,shape_values,data}.finalize(&SnapshotValidationContext::with_shared_schemas(&schemas)).unwrap();
  let mut admission=memory.reserve_capacity(v.memory_budget_admission_bytes(memory).unwrap()).unwrap();v.into_memory_budget(&mut admission).unwrap()
 }).collect()
}
fn rebind(v: &Value, a: &ProgramArtifact, schema: mech_core::SchemaId, memory: &ManagedMemoryBudget) -> Value {
 let shape=mech_core::shape_for_resolved_extents(a.schemas().get(schema).unwrap(), &[1,words(v).len() as u64]).unwrap();
 let x=v.rebind(schema, &shape,a.schemas()).unwrap();assert!(x.shares_frozen_storage(v));
 let mut reserve=memory.reserve_capacity(x.memory_budget_admission_bytes(memory).unwrap()).unwrap();x.into_memory_budget(&mut reserve).unwrap()
}

use std::cell::{Cell,RefCell};
use std::collections::BTreeMap;
use std::ffi::c_void;
use crate::native_artifact::program::{protocol::abi::{Frame,Helper},runtime::{self,NativeProgramExecutionLimits,NativeProgramExecutionReport}};
type Admit=unsafe extern "C" fn(*mut c_void,u64)->u64;
#[derive(Default)]
struct Counts { admits:BTreeMap<u64,u64>,helpers:BTreeMap<(u64,u64),u64>,examples:BTreeMap<(u64,u64),Vec<[u64;3]>> }
thread_local! {
 static OBS:RefCell<Counts>=RefCell::new(Counts::default());
 static SAVED_HELPER:Cell<Option<Helper>>=const {Cell::new(None)};
 static SAVED_ADMIT:Cell<Option<Admit>>=const {Cell::new(None)};
}
unsafe extern "C" fn counted_admit(raw:*mut c_void,site:u64)->u64 {
 OBS.with(|v| *v.borrow_mut().admits.entry(site).or_default()+=1);
 match SAVED_ADMIT.with(Cell::get) {
  Some(call)=>unsafe {call(raw,site)},
  None=>crate::native_artifact::abi::STATUS_ABI,
 }
}
unsafe extern "C" fn counted_helper(raw:*mut c_void,site:u64,operation:u64,first:u64,second:u64,third:u64,result:*mut u64)->u64 {
 OBS.with(|v| {let mut v=v.borrow_mut();let key=(site,operation);*v.helpers.entry(key).or_default()+=1;let e=v.examples.entry(key).or_default();if e.len()<3 {e.push([first,second,third]);}});
 match SAVED_HELPER.with(Cell::get) {
  Some(call)=>unsafe {call(raw,site,operation,first,second,third,result)},
  None=>crate::native_artifact::abi::STATUS_ABI,
 }
}
fn counted(jit:&JitProgramArtifact,inputs:&[Value],outputs:&mut [Option<Value>],limits:NativeProgramExecutionLimits,memory:&ManagedMemoryBudget)->NativeProgramExecutionReport {
 OBS.with(|v|*v.borrow_mut()=Counts::default());
 let entry=jit.test_checked_entry();
 let report=runtime::execute(jit.descriptor(),|frame:*mut Frame| {
  // Same synchronous entry/callback restoration as the maintained admission probe.
  let previous=unsafe {((*frame).base.admit_next,(*frame).helper)};
  SAVED_ADMIT.with(|v|v.set(Some(previous.0)));SAVED_HELPER.with(|v|v.set(Some(previous.1)));
  unsafe {(*frame).base.admit_next=counted_admit;(*frame).helper=counted_helper;}
  let status=unsafe {entry(frame)};
  unsafe {(*frame).base.admit_next=previous.0;(*frame).helper=previous.1;}
  SAVED_ADMIT.with(|v|v.set(None));SAVED_HELPER.with(|v|v.set(None));status
 },inputs,outputs,limits,memory).unwrap();
 let obs=OBS.with(|v|std::mem::take(&mut *v.borrow_mut()));
 let plan=jit.descriptor().plan();let layout=&jit.descriptor().metadata().buffer_frames;
 let mut rows=Vec::new();
 for (site,block) in plan.blocks().iter().enumerate() {
  let admits=obs.admits.get(&(site as u64)).copied().unwrap_or(0);
  let helpers=obs.helpers.iter().filter(|((s,_),_)|*s==site as u64).map(|(&(s,operation),&count)|serde_json::json!({"operation":operation,"count":count,"first_words":obs.examples[&(s,operation)]})).collect::<Vec<_>>();
  if admits==0&&helpers.is_empty(){continue;}
  let action=match block.action(){mech_engine::native_artifact::NativeIterationAction::LibraryCall{template,..}=>format!("Library::{:?}",template.primitive()),other=>format!("{other:?}")};
  rows.push(serde_json::json!({"site":site,"origin":block.origin(),"iteration":block.iteration(),"action":action,"frame":layout.action(site).map(|a|format!("{:?}",a.operation())),"admits":admits,"helpers":helpers}));
 }
 let totals=serde_json::json!({"schema":"mech.private-helper-census.v1","head":"dbb935b3285cb4862e3056ca0675bc59b530f9b3","source_artifact_sha256":"a2a551911949f8c5fdc64273a43662c2a9c4953b853136c19d196692fdac45a7","performance_observations":0,"scope":"One complete decoded eight-byte compression, second visit, actual checked JIT entry/runtime. Only callback wrappers observe arguments and delegate unchanged. Diagnostic metadata allocations and all elapsed values excluded from performance results.","report":format!("{report:?}"),"admits":obs.admits.values().sum::<u64>(),"helper_calls":obs.helpers.values().sum::<u64>(),"rows":rows});
 std::fs::write("/private/tmp/mech-frame-loops-round24-20261029/after-unit-census/counts.json",serde_json::to_vec_pretty(&totals).unwrap()).unwrap();
 report
}
#[test]
fn complete_compressor_private_helper_census() {

 let artifact_path="/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc";
 let artifact=mech_engine::decode_program_artifact_bytecode_v1(&std::fs::read(artifact_path).unwrap()).unwrap();
 let mode=NativeProgramLimitMode::NoLimits; let catalog=mech_stdlib::source_catalog();
 let jit=JitProgramArtifact::compile_with_limits(&artifact,&catalog,mode.compilation()).unwrap();

 let seed=source("+> sequence\nsequence/with-capacity(0u8, 13u64)\n");
 let clear=source("+> sequence\nsequence/clear(buffer<[u8]>)\n");
 let sj=JitProgramArtifact::compile_with_limits(&seed,&catalog,mode.compilation()).unwrap();
 let cj=JitProgramArtifact::compile_with_limits(&clear,&catalog,mode.compilation()).unwrap();
 let memory=mode.memory_budget(); let mut result=vec![None;seed.outputs().len()];sj.evaluate_into(&[],&mut result,mode.execution(),&memory).unwrap();
 let mut current=result.last_mut().unwrap().take().unwrap();drop(result);
 let input=b"abcdefgh";let expected=[75,76,74,78,73,77,75,207,0,0];
 let mut args=import(&artifact,&[("input".into(),Data::Matrix(input.iter().copied().map(Data::U8).collect())),("output".into(),Data::Matrix(vec![].into()))],&memory);
 let out_index=artifact.inputs().iter().position(|p| mech_engine::decode_source_input_name(&p.name).unwrap()=="output").unwrap();
 let in_index=1-out_index;let alias=args[in_index].clone();
 let mut output=vec![None;artifact.outputs().len()];
 let mut expected_work=None;
 for sample in 0..=1 {
  let cleared_args=vec![rebind(&current,&clear,clear.inputs()[0].schema,&memory)];drop(current);
  let mut cleared=vec![None;clear.outputs().len()];cj.evaluate_into(&cleared_args,&mut cleared,mode.execution(),&memory).unwrap();
  let empty=cleared.last_mut().unwrap().take().unwrap();drop((cleared,cleared_args));assert_eq!(capacity(&empty),13);assert!(words(&empty).is_empty());
  args[out_index]=rebind(&empty,&artifact,artifact.inputs()[out_index].schema,&memory);drop(empty);
  output.fill(None);let before=words(&args[out_index]).as_ptr() as usize;
  let report=if sample==0 {jit.evaluate_into(&args,&mut output,mode.execution(),&memory).unwrap()} else {counted(&jit,&args,&mut output,mode.execution(),&memory)};assert_eq!(report.work,*expected_work.get_or_insert(report.work));
  current=output.last_mut().unwrap().take().unwrap();assert_eq!(words(&current),expected);assert_eq!(capacity(&current),13);
  assert_eq!(miniz_oxide::inflate::decompress_to_vec(words(&current)).unwrap(),input);assert!(args[in_index].shares_frozen_storage(&alias));assert_eq!(words(&alias),input);assert!(words(&args[out_index]).is_empty());
  let _=(before,sample);
 }
 drop((args,output,current,alias));assert_eq!(memory.used_bytes(),0);assert_eq!(memory.retained_snapshot_nodes(),0);eprintln!("CLEANUP bytes=0 nodes=0");
}
