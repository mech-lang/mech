use mech_engine::native_artifact::{NativeControlLoop,lower_native_program_artifact_with_definition_table_limit};
fn main(){
 let a=mech_engine::decode_program_artifact_bytecode_v1(&std::fs::read("/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc").unwrap()).unwrap();
 let p=lower_native_program_artifact_with_definition_table_limit(&a,&mech_stdlib::source_catalog(),u64::MAX).unwrap();
 let facts=p.facts();let frames=facts.buffer_frames();let mut rows=Vec::new();
 for (iteration,l) in p.iterations().iter().enumerate(){if let NativeControlLoop::Tail(t)=l{
  if ![5031,5105,5311,5397,39196].contains(&t.header()){continue;}
  let returned=t.returned().get();let needle=format!("NativeMatchValue({returned})");let result=t.result().get();let caller=format!("NativeMatchValue({result})");let ty=&p.values()[returned as usize];
  let uses=p.blocks().iter().enumerate().filter_map(|(site,b)|{
   let action=format!("{:?}",b.action());let frame=frames.action(site).map(|f|format!("{:?}",f.operation()));
   (action.contains(&needle)||action.contains(&caller)||frame.as_ref().is_some_and(|s|s.contains(&needle)||s.contains(&caller))).then(||serde_json::json!({"site":site,"origin":b.origin(),"iteration":b.iteration(),"action":action,"frame":frame}))
  }).collect::<Vec<_>>();
  rows.push(serde_json::json!({"iteration":iteration,"header":t.header(),"tail":format!("{t:?}"),"returned":returned,"caller_result":result,"result_type":format!("{:?}",ty.definition()),"result_fields":frames.fields(t.returned()).map(|f|format!("{f:?}")),"producers_and_direct_consumers":uses}));
 }}
 std::fs::write("/private/tmp/mech-frame-loops-round24-20261029/candidate-consumers/mapping.json",serde_json::to_vec_pretty(&rows).unwrap()).unwrap();
}
