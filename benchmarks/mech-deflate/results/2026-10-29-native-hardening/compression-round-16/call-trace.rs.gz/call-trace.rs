use super::*;
use std::cell::RefCell;
use std::collections::BTreeMap;
thread_local! {static TRACE: RefCell<Option<BTreeMap<usize,(u64,u128)>>> = const {RefCell::new(None)};}
pub(super) struct Span(Option<(usize,std::time::Instant)>);
pub(super) fn enter(site:usize)->Span {Span(TRACE.with_borrow(|t|t.as_ref().map(|_|(site,std::time::Instant::now()))))}
impl Drop for Span {fn drop(&mut self){if let Some((site,start))=self.0 {let elapsed=start.elapsed().as_nanos();TRACE.with_borrow_mut(|t|if let Some(t)=t {let e=t.entry(site).or_default();e.0+=1;e.1+=elapsed;});}}}
fn bytes(v:&Value)->&[u8]{let ValueData::Matrix(m)=v.data() else{panic!()};let mech_core::snapshot::SequenceView::U8(b)=m.elements() else{panic!()};b}
#[test]
fn goal_trace_one_unchanged_complete_eight_byte_evaluation(){
 let a=mech_engine::decode_program_artifact_bytecode_v1(&std::fs::read("/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc").unwrap()).unwrap();
 let mode=crate::native_artifact::NativeProgramLimitMode::NoLimits;
 let catalog=mech_stdlib::source_catalog();
 let jit=crate::native_artifact::JitProgramArtifact::compile_with_limits(&a,&catalog,mode.compilation()).unwrap();
 let [seed,_]=super::call_cache_tests::artifacts("+> sequence\nsequence/with-capacity(0u8, 13u64)\n");
 let sj=crate::native_artifact::JitProgramArtifact::compile_with_limits(&seed,&catalog,mode.compilation()).unwrap();
 let memory=mode.memory_budget();let mut out=vec![None;seed.outputs().len()];sj.evaluate_into(&[],&mut out,mode.execution(),&memory).unwrap();
 let output=out.last_mut().unwrap().take().unwrap();drop(out);
 let mut args=Vec::new();
 for port in a.inputs(){
  let name=mech_engine::decode_source_input_name(&port.name).unwrap();
  let v=if name=="input"{ValueDraft{schema:port.schema,shape_values:mech_core::shape_for_resolved_extents(a.schemas().get(port.schema).unwrap(),&[1,8]).unwrap().parameter_values().into(),data:ValueDataDraft::Matrix(b"abcdefgh".iter().copied().map(ValueDataDraft::U8).collect())}.finalize(&SnapshotValidationContext::new(a.schemas())).unwrap()}else{let shape=mech_core::shape_for_resolved_extents(a.schemas().get(port.schema).unwrap(),&[1,0]).unwrap();output.rebind(port.schema,&shape,a.schemas()).unwrap()};
  let mut admission=memory.reserve_capacity(v.memory_budget_admission_bytes(&memory).unwrap()).unwrap();args.push(v.into_memory_budget(&mut admission).unwrap());
 }
 drop(output);
 let mut out=vec![None;a.outputs().len()];
 TRACE.with_borrow_mut(|t|{assert!(t.is_none());*t=Some(BTreeMap::new())});
 let report=jit.evaluate_into(&args,&mut out,mode.execution(),&memory).unwrap();
 let counts=TRACE.with_borrow_mut(|t|t.take().unwrap());
 assert_eq!(bytes(out.last().unwrap().as_ref().unwrap()),[75,76,74,78,73,77,75,207,0,0]);
 let rows=counts.into_iter().map(|(site,(count,nanos))|{let block=&jit.descriptor().metadata().plan.blocks()[site];let call=jit.descriptor().metadata().calls[site].as_ref().unwrap();serde_json::json!({"site":site,"calls":count,"diagnostic_system_nanoseconds":nanos,"iteration":block.iteration(),"primitive":format!("{:?}",call.template().primitive()),"origin":format!("{:?}",block.origin()),"input_parameters":call.template().inputs().iter().map(|s|s.dimension_parameters().len()).collect::<Vec<_>>(),"output_parameters":call.template().output().dimension_parameters().len()})}).collect::<Vec<_>>();
 let result=serde_json::json!({"diagnostic_only":true,"primary_timing":false,"input_bytes":8,"single_evaluation":true,"source_unchanged":true,"work":report.work,"visits":report.visits,"call_sites":rows});
 std::fs::write("/private/tmp/mech-helper-costs-round16-20261029/one-evaluation-timed-call-trace.json",serde_json::to_vec_pretty(&result).unwrap()).unwrap();
 println!("DIAGNOSTIC_CALL_TRACE {}",result);
 drop((args,out));assert_eq!((memory.used_bytes(),memory.retained_snapshot_nodes()),(0,0));
}
