use mech_core::{ValueData,ValueDataDraft as D,snapshot::{ValueDraft,SnapshotValidationContext}};
use mech_engine::{CanonicalSourceFrontend,native_artifact::{NativeIterationAction as A,NativeLibraryWorkBudget,NativePreparedLibraryCallCache,lower_native_program_artifact,prepare_native_program_library_call}};
use mech_gpu::native_artifact::NativeProgramLimitMode;
use mech_syntax::document::{AstNode,DocumentId,DocumentSyntax,ParseConfig,Revision,TextSnapshot,parse_canonical_document};
fn main(){
 let source="+> sequence\ntext := payload<string>\nstep(x<u64>) => (next<u64>) := next := x + sequence/length(text).\nseed<u64> |4> step\n";
 let parsed=parse_canonical_document(TextSnapshot::new(DocumentId(9),Revision(1),source).unwrap(),ParseConfig::default());assert!(parsed.is_strictly_clean());let c=mech_stdlib::source_catalog();let a=CanonicalSourceFrontend.compile_document_with_catalog(&DocumentSyntax::cast(parsed.syntax()).unwrap(),c.clone()).unwrap().compile_artifact().unwrap();
 let p=lower_native_program_artifact(&a,&c).unwrap();
 let templates=p.blocks().iter().filter_map(|b|if let A::LibraryCall{template,..}=b.action(){Some(template)}else{None}).collect::<Vec<_>>();assert_eq!(templates.len(),1);let call=prepare_native_program_library_call(&a,templates[0],&c).unwrap();
 let mech_core::ResolvedOperationContract::Declared(contract)=call.template().contract() else{panic!()};
 let mode=NativeProgramLimitMode::NoLimits;
 for finite in [false,true]{
  let memory=mode.memory_budget();let work=NativeLibraryWorkBudget::new(u64::MAX,u64::MAX,&memory).unwrap();let mut cache=NativePreparedLibraryCallCache::default();let mut limits=mode.execution().library;if finite{limits.max_temporary_bytes=Some(128*1024*1024)}
  let mut out=None;
  let mut rows=Vec::new();
  for (text,expected) in [("abc",3),("e\u{301}A",2),("xyzq",4)]{
   let v=ValueDraft{schema:contract.inputs[0].schema,shape_values:Box::new([]),data:D::String(text.into())}.finalize(&SnapshotValidationContext::new(a.schemas())).unwrap();let mut budget=memory.reserve_capacity(v.memory_budget_admission_bytes(&memory).unwrap()).unwrap();let v=v.into_memory_budget(&mut budget).unwrap();drop(budget);
   let before=work.used();call.invoke_current_cached(&mut cache,&[Some(v)],&mut out,limits,&work).unwrap();assert!(matches!(out.as_ref().unwrap().data(),ValueData::U64(n) if *n==expected));
   out=None;let demand=cache.retained_metadata_demand(&work).unwrap();rows.push(serde_json::json!({"text":text,"expected":expected,"metadata_bytes":demand.turn_peak_bytes,"metadata_nodes":demand.retained_nodes,"work_before":before,"work_after":work.used()}));
   if finite{assert!(demand.turn_peak_bytes>0)}else{assert_eq!(demand.turn_peak_bytes,0)}
  }
  println!("{}",serde_json::json!({"diagnostic":"optional-binding-headroom","compiler":"ebc559b2bdd30c0d1417e765c7ea87fab8d5491a","policy":if finite{"finite temporary-policy control; not primary benchmark"}else{"unchanged NoLimits"},"rows":rows}));
  drop((out,cache,work));assert_eq!((memory.used_bytes(),memory.retained_snapshot_nodes()),(0,0));
 }
}
