use mech_engine::native_artifact::{lower_native_program_artifact_with_definition_table_limit, prepare_native_program_library_call, NativeIterationAction as A};
use std::collections::BTreeMap;
fn run(){
 let a=mech_engine::decode_program_artifact_bytecode_v1(&std::fs::read("/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc").unwrap()).unwrap();
 let c=mech_stdlib::source_catalog();
 let p=lower_native_program_artifact_with_definition_table_limit(&a,&c,u64::MAX).unwrap();
 let f=p.facts().buffer_frames();
 let mut rows=Vec::new();let mut kinds=BTreeMap::<String,usize>::new();
 for (site,b) in p.blocks().iter().enumerate(){
  let A::LibraryCall{template,operands,..}=b.action() else{continue};
  if b.iteration().is_none() || f.action(site).is_some(){continue}
  let call=prepare_native_program_library_call(&a,template,&c).unwrap();
  if call.supports_unsigned_matrix_element()||call.supports_unsigned_matrix_length()||call.supports_unsigned_matrix_replace()||call.supports_unsigned_buffer()||call.record_scalar_field_kind().is_some(){continue}
  let kind=format!("{:?}",template.primitive());*kinds.entry(kind.clone()).or_default()+=1;
  rows.push(serde_json::json!({"site":site,"primitive":kind,"selector_name":operands.get(1).and_then(|operand|p.constants().iter().find(|c|c.value()==*operand)).and_then(|c|if let mech_core::ValueData::Id(id)=c.constant().data(){if let mech_core::SchemaBody::Record(fields)=template.inputs()[0].body(){fields.iter().find(|f|mech_core::hash_str(&f.name)==*id).map(|f|f.name.clone())}else{None}}else{None}),"iteration":b.iteration(),"origin":format!("{:?}",b.origin()),"inputs":template.inputs().iter().map(|s|format!("{:?}",s.body())).collect::<Vec<_>>(),"output":format!("{:?}",template.output().body()),"input_parameters":template.inputs().iter().map(|s|s.dimension_parameters().len()).collect::<Vec<_>>(),"output_parameters":template.output().dimension_parameters().len()}));
 }
 println!("{}",serde_json::json!({"counts":kinds,"canonical_repeated_candidates":rows}));
}
fn main(){std::thread::Builder::new().stack_size(32*1024*1024).spawn(run).unwrap().join().unwrap()}
