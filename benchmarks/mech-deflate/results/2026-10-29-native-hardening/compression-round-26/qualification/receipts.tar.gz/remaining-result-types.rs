use mech_engine::native_artifact::{NativeControlLoop,lower_native_program_artifact_with_definition_table_limit};
fn main(){
 let a=mech_engine::decode_program_artifact_bytecode_v1(&std::fs::read("/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc").unwrap()).unwrap();
 let p=lower_native_program_artifact_with_definition_table_limit(&a,&mech_stdlib::source_catalog(),u64::MAX).unwrap();
 let facts=p.facts();let frames=facts.buffer_frames();let mut rows=Vec::new();
 for (iteration,l) in p.iterations().iter().enumerate(){if ![142,424,425,426,427].contains(&iteration){continue;} if let NativeControlLoop::Tail(t)=l{
  let ty=&p.values()[t.returned().get() as usize];
  let actions=p.blocks().iter().enumerate().filter(|(_,b)|b.iteration()==Some(iteration as u32)).map(|(site,b)|{
   let action=match b.action(){mech_engine::native_artifact::NativeIterationAction::LibraryCall{template,..}=>format!("Library::{:?}",template.primitive()),other=>format!("{other:?}")};
   serde_json::json!({"site":site,"action":action,"frame":frames.action(site).map(|f|format!("{:?}",f.operation()))})
  }).collect::<Vec<_>>();
  rows.push(serde_json::json!({"iteration":iteration,"header":t.header(),"returned":t.returned().get(),"result_type":format!("{:?}",ty.definition()),"scalar_result_slot":facts.scalar_aggregates().slot(t.returned()),"result_fields":frames.fields(t.returned()).map(|f|format!("{f:?}")),"carrier_fields":frames.fields(t.carrier()).map(|f|format!("{f:?}")),"actions":actions}));
 }}
 std::fs::write("/private/tmp/mech-field-retirement-round26-20261029/remaining-result-types.json",serde_json::to_vec_pretty(&rows).unwrap()).unwrap();
}
