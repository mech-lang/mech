10001e80c:	7e 02 00 37	tbnz	w30, #0x0, 0x10001e858
10001e810:	9e 00 00 b4	cbz	x30, 0x10001e820
10001e814:	e8 82 5f f8	ldur	x8, [x23, #-0x8]
10001e818:	1f 05 00 f1	cmp	x8, #0x1
10001e81c:	e1 01 00 54	b.ne	0x10001e858
10001e820:	08 00 80 d2	mov	x8, #0x0
10001e824:	e9 02 08 8b	add	x9, x23, x8
10001e828:	20 05 40 ad	ldp	q0, q1, [x9]
10001e82c:	22 0d 41 ad	ldp	q2, q3, [x9, #0x20]
10001e830:	00 2c 64 6e	uqsub.8h	v0, v0, v4
10001e834:	21 2c 64 6e	uqsub.8h	v1, v1, v4
10001e838:	42 2c 64 6e	uqsub.8h	v2, v2, v4
10001e83c:	63 2c 64 6e	uqsub.8h	v3, v3, v4
10001e840:	20 05 00 ad	stp	q0, q1, [x9]
10001e844:	22 0d 01 ad	stp	q2, q3, [x9, #0x20]
10001e848:	08 01 01 91	add	x8, x8, #0x40
10001e84c:	1f 81 40 f1	cmp	x8, #0x20, lsl #12
10001e850:	a1 fe ff 54	b.ne	0x10001e824
10001e854:	3f 00 00 14	b	0x10001e950
10001e858:	f6 03 19 aa	mov	x22, x25
10001e85c:	f9 03 1e aa	mov	x25, x30
10001e860:	f8 03 01 aa	mov	x24, x1
10001e864:	fc 03 06 aa	mov	x28, x6
10001e868:	ff eb 0e f9	str	xzr, [sp, #0x1dd0]
10001e86c:	ff e7 0e f9	str	xzr, [sp, #0x1dc8]
10001e870:	ff ef 0e f9	str	xzr, [sp, #0x1dd8]
10001e874:	e0 83 26 91	add	x0, sp, #0x9a0
10001e878:	e1 07 40 91	add	x1, sp, #0x1, lsl #12
10001e87c:	21 20 37 91	add	x1, x1, #0xdc8
10001e880:	22 00 a0 52	mov	w2, #0x10000
10001e884:	43 00 80 52	mov	w3, #0x2
10001e888:	24 00 80 52	mov	w4, #0x1
10001e88c:	6f 4c 00 94	bl	_list.RocList.reallocate
10001e890:	04 a4 04 4f	movi.8h	v4, #0x80, lsl #8
10001e894:	08 00 80 d2	mov	x8, #0x0
10001e898:	f3 d3 44 f9	ldr	x19, [sp, #0x9a0]
10001e89c:	f5 db 44 f9	ldr	x21, [sp, #0x9b0]
10001e8a0:	69 02 17 cb	sub	x9, x19, x23
10001e8a4:	3f 01 01 f1	cmp	x9, #0x40
10001e8a8:	e3 01 00 54	b.lo	0x10001e8e4
10001e8ac:	e8 82 00 91	add	x8, x23, #0x20
10001e8b0:	69 82 00 91	add	x9, x19, #0x20
10001e8b4:	0a fc 9f 52	mov	w10, #0xffe0
10001e8b8:	00 05 7f ad	ldp	q0, q1, [x8, #-0x20]
10001e8bc:	02 0d c2 ac	ldp	q2, q3, [x8], #0x40
10001e8c0:	00 2c 64 6e	uqsub.8h	v0, v0, v4
10001e8c4:	21 2c 64 6e	uqsub.8h	v1, v1, v4
10001e8c8:	42 2c 64 6e	uqsub.8h	v2, v2, v4
10001e8cc:	63 2c 64 6e	uqsub.8h	v3, v3, v4
10001e8d0:	20 05 3f ad	stp	q0, q1, [x9, #-0x20]
10001e8d4:	22 0d 82 ac	stp	q2, q3, [x9], #0x40
10001e8d8:	4a 81 00 f1	subs	x10, x10, #0x20
10001e8dc:	e1 fe ff 54	b.ne	0x10001e8b8
10001e8e0:	08 fc 9f 52	mov	w8, #0xffe0
10001e8e4:	1f 05 00 b1	cmn	x8, #0x1
10001e8e8:	00 f0 05 54	b.eq	0x10002a6e8
10001e8ec:	e9 7a e8 78	ldrsh	w9, [x23, x8, lsl #1]
10001e8f0:	2a 01 11 52	eor	w10, w9, #0x8000
10001e8f4:	49 3d 49 0a	and	w9, w10, w9, lsr #15
10001e8f8:	69 7a 28 78	strh	w9, [x19, x8, lsl #1]
10001e8fc:	08 05 00 91	add	x8, x8, #0x1
10001e900:	1f 41 40 f1	cmp	x8, #0x10, lsl #12
10001e904:	01 ff ff 54	b.ne	0x10001e8e4
10001e908:	f7 d3 04 f9	str	x23, [sp, #0x9a0]
10001e90c:	e8 d7 04 f9	str	x8, [sp, #0x9a8]
10001e910:	f9 db 04 f9	str	x25, [sp, #0x9b0]
10001e914:	e0 83 26 91	add	x0, sp, #0x9a0
10001e918:	2a 46 00 94	bl	_roc_llvm_rc_decref_25_single_thread
10001e91c:	04 a4 04 4f	movi.8h	v4, #0x80, lsl #8
10001e920:	f7 03 13 aa	mov	x23, x19
10001e924:	fe 03 15 aa	mov	x30, x21
10001e928:	e2 9f 41 f9	ldr	x2, [sp, #0x338]
10001e92c:	e3 a3 41 f9	ldr	x3, [sp, #0x340]
10001e930:	a4 f7 94 52	mov	w4, #0xa7bd
10001e934:	a4 c6 a3 72	movk	w4, #0x1e35, lsl #16
10001e938:	e5 97 41 f9	ldr	x5, [sp, #0x328]
10001e93c:	e6 03 1c aa	mov	x6, x28
10001e940:	e1 03 18 aa	mov	x1, x24
10001e944:	f9 03 16 aa	mov	x25, x22
10001e948:	f6 8f 41 f9	ldr	x22, [sp, #0x318]
10001e94c:	f8 93 41 f9	ldr	x24, [sp, #0x320]
10001e950:	94 22 40 91	add	x20, x20, #0x8, lsl #12
