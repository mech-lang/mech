#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
uint32_t *cow_store(uint32_t *data, size_t length, size_t at, uint32_t word, int unique) {
 if (at >= length) return NULL;
 if (!unique) { uint32_t *copy = malloc(length * sizeof(uint32_t)); if (!copy) return NULL; memcpy(copy, data, length * sizeof(uint32_t)); data = copy; }
 data[at] = word; return data;
}
