	.build_version macos, 11, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc4sync15UniqueArcUninitINtNtBL_3vec3VecmENtNtBL_5alloc6GlobalEECscTcGdWpZ4K1_3cow:
	.cfi_startproc
	stp	x20, x19, [sp, #-32]!
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_remember_state
	ldrb	w8, [x0, #24]
	strb	wzr, [x0, #24]
	cmp	w8, #1
	b.ne	LBB0_4
	ldp	x1, x19, [x0, #8]
	ldr	x8, [x0]
	mov	x0, x8
	bl	__RNvNtCsgKscDXrlV49_5alloc4sync32arcinner_layout_for_value_layout
	cbz	x1, LBB0_3
	mov	x2, x0
	mov	x0, x19
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	b	__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc
LBB0_3:
	.cfi_restore_state
	.cfi_remember_state
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	ret
LBB0_4:
	.cfi_restore_state
Lloh0:
	adrp	x0, l_anon.29d6fee4d3184fff3c462a4ea9699c93.1@PAGE
Lloh1:
	add	x0, x0, l_anon.29d6fee4d3184fff3c462a4ea9699c93.1@PAGEOFF
	bl	__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc

	.globl	__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcINtNtB7_3vec3VecmEE9drop_slowCscTcGdWpZ4K1_3cow
	.p2align	2
__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcINtNtB7_3vec3VecmEE9drop_slowCscTcGdWpZ4K1_3cow:
	.cfi_startproc
	stp	x20, x19, [sp, #-32]!
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_remember_state
	ldr	x19, [x0]
	ldr	x8, [x19, #16]
	cbz	x8, LBB1_2
	ldr	x0, [x19, #24]
	lsl	x1, x8, #2
	mov	w2, #4
	bl	__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc
LBB1_2:
	cmn	x19, #1
	b.eq	LBB1_5
	add	x8, x19, #8
	mov	x9, #-1
	ldaddl	x9, x8, [x8]
	cmp	x8, #1
	b.ne	LBB1_5
	dmb	ishld
	mov	x0, x19
	mov	w1, #40
	mov	w2, #8
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	b	__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc
LBB1_5:
	.cfi_restore_state
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	ret
	.cfi_endproc

	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
lCPI2_0:
	.quad	8
	.quad	24
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_cow_store
	.p2align	2
_cow_store:
Lfunc_begin0:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception0
	sub	sp, sp, #144
	.cfi_def_cfa_offset 144
	stp	x28, x27, [sp, #48]
	stp	x26, x25, [sp, #64]
	stp	x24, x23, [sp, #80]
	stp	x22, x21, [sp, #96]
	stp	x20, x19, [sp, #112]
	stp	x29, x30, [sp, #128]
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_remember_state
	mov	w8, #1
	ldadd	x8, x8, [x0]
	tbnz	x8, #63, LBB2_31
	mov	x21, x2
	mov	x20, x1
	mov	x19, x0
	str	x0, [sp, #8]
	ldr	x8, [x0, #32]
	cbz	x8, LBB2_17
	ldr	x8, [x19, #24]
	ldr	w26, [x8]
	str	x19, [sp, #16]
	mov	x8, #-1
	ldaddl	x8, x8, [x19]
	cmp	x8, #1
	b.ne	LBB2_4
LBB2_3:
	dmb	ishld
	add	x0, sp, #16
	bl	__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcINtNtB7_3vec3VecmEE9drop_slowCscTcGdWpZ4K1_3cow
LBB2_4:
	mov	w8, #1
	casa	x8, xzr, [x19]
	cmp	x8, #1
	b.ne	LBB2_7
	ldr	x8, [x19, #8]
	cmp	x8, #1
	b.ne	LBB2_18
	stlr	x8, [x19]
	mov	x22, x19
	b	LBB2_15
LBB2_7:
	ldp	x23, x27, [x19, #24]
Ltmp0:
	mov	w0, #8
	mov	w1, #24
	bl	__RNvNtCsgKscDXrlV49_5alloc4sync32arcinner_layout_for_value_layout
Ltmp1:
	mov	x25, x0
	mov	x24, x1
	cbz	x1, LBB2_24
	bl	__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x24
	mov	x1, x25
	bl	__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc
	mov	x22, x0
	cbz	x0, LBB2_25
LBB2_10:
	mov	w8, #1
	dup.2d	v0, x8
	str	q0, [x22]
	str	x22, [sp, #32]
Lloh2:
	adrp	x9, lCPI2_0@PAGE
Lloh3:
	ldr	q0, [x9, lCPI2_0@PAGEOFF]
	str	q0, [sp, #16]
	strb	w8, [sp, #40]
	cbz	x27, LBB2_26
	lsl	x24, x27, #2
	bl	__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x24
	mov	w1, #4
	bl	__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc
	cbz	x0, LBB2_30
	mov	x25, x0
	mov	x1, x23
	mov	x2, x24
	bl	_memcpy
	stp	x27, x25, [x22, #16]
	str	x27, [x22, #32]
	mov	x8, #-1
	ldaddl	x8, x8, [x19]
	cmp	x8, #1
	b.ne	LBB2_14
LBB2_13:
	dmb	ishld
	add	x0, sp, #8
	bl	__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcINtNtB7_3vec3VecmEE9drop_slowCscTcGdWpZ4K1_3cow
LBB2_14:
	str	x22, [sp, #8]
LBB2_15:
	ldr	x1, [x22, #32]
	cmp	x20, x1
	b.hs	LBB2_29
	ldr	x8, [x22, #24]
	add	w9, w21, w26
	add	w9, w9, #3
	str	w9, [x8, x20, lsl #2]
	mov	x0, x22
	.cfi_def_cfa wsp, 144
	ldp	x29, x30, [sp, #128]
	ldp	x20, x19, [sp, #112]
	ldp	x22, x21, [sp, #96]
	ldp	x24, x23, [sp, #80]
	ldp	x26, x25, [sp, #64]
	ldp	x28, x27, [sp, #48]
	add	sp, sp, #144
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	ret
LBB2_17:
	.cfi_restore_state
	mov	w26, #0
	str	x19, [sp, #16]
	mov	x8, #-1
	ldaddl	x8, x8, [x19]
	cmp	x8, #1
	b.eq	LBB2_3
	b	LBB2_4
LBB2_18:
Ltmp10:
	mov	w0, #8
	mov	w1, #24
	bl	__RNvNtCsgKscDXrlV49_5alloc4sync32arcinner_layout_for_value_layout
Ltmp11:
	mov	x24, x0
	mov	x23, x1
	cbz	x1, LBB2_27
	bl	__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x23
	mov	x1, x24
	bl	__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc
	mov	x22, x0
	cbz	x0, LBB2_28
LBB2_21:
	mov	w8, #1
	dup.2d	v0, x8
	str	q0, [x22]
	ldr	q0, [x19, #16]
	ldr	x8, [x19, #32]
	str	x8, [x22, #32]
	str	q0, [x22, #16]
	str	x22, [sp, #8]
	cmn	x19, #1
	b.eq	LBB2_15
	add	x8, x19, #8
	mov	x9, #-1
	ldaddl	x9, x8, [x8]
	cmp	x8, #1
	b.ne	LBB2_15
	dmb	ishld
	mov	x0, x19
	mov	w1, #40
	mov	w2, #8
	bl	__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc
	b	LBB2_15
LBB2_24:
	mov	x22, x25
	cbnz	x25, LBB2_10
LBB2_25:
Ltmp8:
	mov	x0, x25
	mov	x1, x24
	bl	__RNvNtCsgKscDXrlV49_5alloc5alloc18handle_alloc_error
Ltmp9:
	b	LBB2_31
LBB2_26:
	mov	w25, #4
	stp	x27, x25, [x22, #16]
	str	x27, [x22, #32]
	mov	x8, #-1
	ldaddl	x8, x8, [x19]
	cmp	x8, #1
	b.eq	LBB2_13
	b	LBB2_14
LBB2_27:
	mov	x22, x24
	cbnz	x24, LBB2_21
LBB2_28:
Ltmp12:
	mov	x0, x24
	mov	x1, x23
	bl	__RNvNtCsgKscDXrlV49_5alloc5alloc18handle_alloc_error
Ltmp13:
	b	LBB2_31
LBB2_29:
Ltmp15:
Lloh4:
	adrp	x2, l_anon.29d6fee4d3184fff3c462a4ea9699c93.3@PAGE
Lloh5:
	add	x2, x2, l_anon.29d6fee4d3184fff3c462a4ea9699c93.3@PAGEOFF
	mov	x19, x22
	mov	x0, x20
	bl	__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check
Ltmp16:
	b	LBB2_31
LBB2_30:
Ltmp2:
	mov	w0, #4
	mov	x1, x24
	bl	__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error
Ltmp3:
LBB2_31:
	brk	#0x1
LBB2_32:
Ltmp4:
	mov	x20, x0
Ltmp5:
	add	x0, sp, #16
	bl	__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc4sync15UniqueArcUninitINtNtBL_3vec3VecmENtNtBL_5alloc6GlobalEECscTcGdWpZ4K1_3cow
Ltmp6:
	b	LBB2_37
LBB2_33:
Ltmp7:
	bl	__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup
LBB2_34:
Ltmp14:
	mov	x8, #-1
	cmn	x19, #1
	b.eq	LBB2_39
	mov	x20, x0
	add	x9, x19, #8
	ldaddl	x8, x8, [x9]
	cmp	x8, #1
	b.ne	LBB2_37
	dmb	ishld
	mov	x0, x19
	mov	w1, #40
	mov	w2, #8
	bl	__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc
LBB2_37:
	mov	x0, x20
	b	LBB2_39
LBB2_38:
Ltmp17:
LBB2_39:
	mov	x8, #-1
	ldaddl	x8, x8, [x19]
	cmp	x8, #1
	b.ne	LBB2_41
	dmb	ishld
	mov	x19, x0
	add	x0, sp, #8
	bl	__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcINtNtB7_3vec3VecmEE9drop_slowCscTcGdWpZ4K1_3cow
	mov	x0, x19
LBB2_41:
	bl	__Unwind_Resume
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdd	Lloh4, Lloh5
Lfunc_end0:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table2:
Lexception0:
	.byte	255
	.byte	155
	.uleb128 Lttbase0-Lttbaseref0
Lttbaseref0:
	.byte	1
	.uleb128 Lcst_end0-Lcst_begin0
Lcst_begin0:
	.uleb128 Ltmp0-Lfunc_begin0
	.uleb128 Ltmp1-Ltmp0
	.uleb128 Ltmp17-Lfunc_begin0
	.byte	0
	.uleb128 Ltmp1-Lfunc_begin0
	.uleb128 Ltmp10-Ltmp1
	.byte	0
	.byte	0
	.uleb128 Ltmp10-Lfunc_begin0
	.uleb128 Ltmp11-Ltmp10
	.uleb128 Ltmp14-Lfunc_begin0
	.byte	0
	.uleb128 Ltmp8-Lfunc_begin0
	.uleb128 Ltmp9-Ltmp8
	.uleb128 Ltmp17-Lfunc_begin0
	.byte	0
	.uleb128 Ltmp12-Lfunc_begin0
	.uleb128 Ltmp13-Ltmp12
	.uleb128 Ltmp14-Lfunc_begin0
	.byte	0
	.uleb128 Ltmp15-Lfunc_begin0
	.uleb128 Ltmp16-Ltmp15
	.uleb128 Ltmp17-Lfunc_begin0
	.byte	0
	.uleb128 Ltmp2-Lfunc_begin0
	.uleb128 Ltmp3-Ltmp2
	.uleb128 Ltmp4-Lfunc_begin0
	.byte	0
	.uleb128 Ltmp5-Lfunc_begin0
	.uleb128 Ltmp6-Ltmp5
	.uleb128 Ltmp7-Lfunc_begin0
	.byte	1
	.uleb128 Ltmp6-Lfunc_begin0
	.uleb128 Lfunc_end0-Ltmp6
	.byte	0
	.byte	0
Lcst_end0:
	.byte	127
	.byte	0
	.p2align	2, 0x0
Lttbase0:
	.byte	0
	.p2align	2, 0x0

	.section	__TEXT,__cstring,cstring_literals
l_anon.29d6fee4d3184fff3c462a4ea9699c93.0:
	.asciz	"/rustc/ec818fda361ca216eb186f5cf45131bd9c776bb4/library/alloc/src/sync.rs"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.29d6fee4d3184fff3c462a4ea9699c93.1:
	.quad	l_anon.29d6fee4d3184fff3c462a4ea9699c93.0
	.asciz	"I\000\000\000\000\000\000\000\300\020\000\000\037\000\000"

	.section	__TEXT,__cstring,cstring_literals
l_anon.29d6fee4d3184fff3c462a4ea9699c93.2:
	.asciz	"/private/tmp/mech-field-retirement-round26-20261029/codegen-pattern/cow.rs"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.29d6fee4d3184fff3c462a4ea9699c93.3:
	.quad	l_anon.29d6fee4d3184fff3c462a4ea9699c93.2
	.asciz	"J\000\000\000\000\000\000\000\b\000\000\000\037\000\000"

.subsections_via_symbols
