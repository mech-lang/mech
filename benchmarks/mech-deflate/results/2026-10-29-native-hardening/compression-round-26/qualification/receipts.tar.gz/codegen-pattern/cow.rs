use std::sync::Arc;
#[unsafe(no_mangle)]
pub fn cow_store(original: Arc<Vec<u32>>, at: usize, incoming: u32) -> Arc<Vec<u32>> {
 let state = (original.clone(), 3u64);
 let (mut projected, tag) = state;
 let old = original.first().copied().unwrap_or(0);
 drop(original);
 Arc::make_mut(&mut projected)[at] = old.wrapping_add(incoming).wrapping_add(tag as u32);
 projected
}
