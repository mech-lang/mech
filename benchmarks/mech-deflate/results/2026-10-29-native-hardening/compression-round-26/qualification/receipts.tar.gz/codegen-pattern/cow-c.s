	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 15, 0	sdk_version 26, 0
	.globl	_cow_store                      ; -- Begin function cow_store
	.p2align	2
_cow_store:                             ; @cow_store
	.cfi_startproc
; %bb.0:
	cmp	x2, x1
	b.hs	LBB0_6
; %bb.1:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	cbnz	w4, LBB0_4
; %bb.2:
	mov	x23, x2
	mov	x22, x3
	mov	x20, x0
	lsl	x19, x1, #2
	mov	x0, x19
	bl	_malloc
	cbz	x0, LBB0_5
; %bb.3:
	mov	x21, x0
	mov	x1, x20
	mov	x2, x19
	bl	_memcpy
	mov	x0, x21
	mov	x3, x22
	mov	x2, x23
LBB0_4:
	str	w3, [x0, x2, lsl #2]
LBB0_5:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB0_6:
	mov	x0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
