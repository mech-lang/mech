from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).resolve().parent;logs=Path('/private/tmp/mech-linear-restack-20261026/validation')
a=[json.loads(l) for l in (logs/'round26-packed-alias-release.log').read_text().splitlines() if l.startswith('{')]
b=[json.loads(l) for l in (logs/'round25-reserved-view-release.log').read_text().splitlines() if l.startswith('{')]
assert a[-1]=={'reason':'build-finished','success':True}
rows={}
for name in ['mech_core','mech_engine','mech_gpu','mech_stdlib','mech_math','mech_compare','mech_logic']:
 x=next(v for v in a if v.get('reason')=='compiler-artifact' and v['target']['name']==name)
 y=next(v for v in b if v.get('reason')=='compiler-artifact' and v['target']['name']==name)
 assert x['features']==y['features'],name
 rows[name]={'before':y['features'],'after':x['features'],'same':True}
(r/'feature-comparison.json').write_text(json.dumps(rows,indent=2)+'\n')
x=next(v for v in a if v.get('reason')=='compiler-artifact' and v['target']['name']=='native_frame_transport')
f=Path(x['executable']);out=r/'primary/frame-after';assert not out.exists();shutil.copy2(f,out)
(r/'primary/frame-after.json').write_text(json.dumps({'path':str(f),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'features':x['features'],'frozen_default_profile':True},indent=2)+'\n')
print('Exact production feature sets match R25; default scalar binary frozen')
