from pathlib import Path
import hashlib,json,re
r=Path(__file__).resolve().parent;o=r/'ownership-probe';o.mkdir();w=Path('/private/tmp/mech-deflate-linear-stack')
source=Path('/private/tmp/mech-append-loops-round25-20261029/after-unit-census/probe.rs').read_text()
source=source.replace('/private/tmp/mech-append-loops-round25-20261029/after-unit-census/counts.json',str(o/'counts.json')).replace('4056f93118f499515048dac61d9d52558ef03aef','1b36e77f894a0cacff81802df7b2de0af86f95d5')
source=source.replace('examples:BTreeMap<(u64,u64),Vec<[u64;3]>>','examples:BTreeMap<(u64,u64),Vec<[u64;3]>>, stores:Vec<serde_json::Value>')
old=''' match SAVED_HELPER.with(Cell::get) {
  Some(call)=>unsafe {call(raw,site,operation,first,second,third,result)},
  None=>crate::native_artifact::abi::STATUS_ABI,
 }'''
new=''' let note=if operation==0 { inspect_store(unsafe { &*raw.cast::<super::Invocation<'_, '_, '_>>() }, site as usize) } else { None };
 let status=match SAVED_HELPER.with(Cell::get) {
  Some(call)=>unsafe {call(raw,site,operation,first,second,third,result)},
  None=>crate::native_artifact::abi::STATUS_ABI,
 };
 if let Some(mut note)=note {
  let context=unsafe { &*raw.cast::<super::Invocation<'_, '_, '_>>() };
  let output=context.state.arena.test_current_slots()[note.output as usize].as_ref();
  let after=output.and_then(matrix_address);
  note.row["status"]=status.into();
  note.row["after_pointer"]=serde_json::json!(after.map(|x|x.0));
  note.row["copied"]=serde_json::json!(after.is_some_and(|x|x.0!=note.pointer));
  OBS.with(|v|v.borrow_mut().stores.push(note.row));
 }
 status'''
assert old in source;source=source.replace(old,new)
source=source.replace('"helper_calls":obs.helpers.values().sum::<u64>(),"rows":rows','"helper_calls":obs.helpers.values().sum::<u64>(),"stores":obs.stores,"rows":rows')
source+='''
struct StoreNote { pointer:usize, output:u32, row:serde_json::Value }
fn matrix_address(value:&Value)->Option<(usize,usize,usize)> {
 let ValueData::Matrix(matrix)=value.data() else {return None;};
 Some(match matrix.elements() {
  SequenceView::U8(v)=>(v.as_ptr() as usize,v.len(),1),
  SequenceView::U16(v)=>(v.as_ptr() as usize,v.len(),2),
  SequenceView::U32(v)=>(v.as_ptr() as usize,v.len(),4),
  SequenceView::U64(v)=>(v.as_ptr() as usize,v.len(),8),_=>return None,
 })
}
fn inspect_store(context:&super::Invocation<'_, '_, '_>,site:usize)->Option<StoreNote> {
 use mech_engine::native_artifact::NativeIterationAction as Action;
 let metadata=context.descriptor.metadata();
 let call=metadata.calls.get(site)?.as_ref()?;
 if !call.supports_unsigned_matrix_replace(){return None;}
 let Action::LibraryCall{operands,output,..}=metadata.plan.blocks()[site].action() else{return None;};
 let source=context.state.arena.test_current_slots()[operands[0].get() as usize].as_ref()?;
 let (pointer,length,width)=matrix_address(source)?;
 let arena=context.state.arena.test_current_slots().iter().enumerate().filter_map(|(slot,v)|v.as_ref().is_some_and(|v|v.shares_frozen_storage(source)).then_some(slot)).collect::<Vec<_>>();
 let frames=context.state.buffer_frames.test_owner_slots().iter().enumerate().filter_map(|(lane,v)|v.as_ref().is_some_and(|v|v.shares_frozen_storage(source)).then_some(lane)).collect::<Vec<_>>();
 let mut frame_names=Vec::new();
 for value in 0..metadata.plan.values().len(){
  if let Some(fields)=metadata.buffer_frames.fields_at(value){
   for (ordinal,field) in fields.iter().enumerate(){
    if let mech_engine::native_artifact::NativeBufferFrameLane::Managed{at}=field.lane(){
     if frames.contains(&at){frame_names.push(serde_json::json!({"value":value,"ordinal":ordinal,"lane":at}));}
    }
   }
  }
 }
 let proof=metadata.unsigned_buffer_calls.get(site)?.as_ref()?;
 Some(StoreNote{pointer,output:output.get(),row:serde_json::json!({"site":site,"origin":metadata.plan.blocks()[site].origin(),"iteration":metadata.plan.blocks()[site].iteration(),"source":operands[0].get(),"output":output.get(),"length":length,"width":width,"capacity":if let ValueData::Matrix(m)=source.data(){m.unsigned_buffer_capacity()}else{None},"pointer":pointer,"arena_aliases":arena,"frame_aliases":frames,"frame_names":frame_names,"retirable_arena":proof.owned_source_slots().iter().map(|x|x.get()).collect::<Vec<_>>()})})
}
'''
(o/'probe.rs').write_text(source)
manifest=[]
def adapt(src,dst,special,extra=''):
 text=src.read_text();pattern=r'(?m)^(?:#\[path\s*=\s*"([^"]+)"\]\n)?((?:pub(?:\([^)]+\))?\s+)?mod\s+)(\w+);'
 def replace(m):
  explicit,decl,name=m.groups()
  if name in special:path=special[name]
  elif explicit:path=(src.parent/explicit).resolve()
  else:
   path=src.parent/(name+'.rs')
   if not path.exists():path=src.parent/name/'mod.rs'
  assert path.exists(),path
  return '#[path = '+json.dumps(str(path))+']\n'+decl+name+';'
 text=re.sub(pattern,replace,text)
 text=re.sub(r'(include_(?:str|bytes)!)\("([^"]+)"\)',lambda m:m[1]+'('+json.dumps(str((src.parent/m[2]).resolve()))+')',text)
 dst.write_text(text+extra);manifest.append({'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'adapted':str(dst),'adapted_sha256':hashlib.sha256(dst.read_bytes()).hexdigest()})
for name in ['lib.rs','native_artifact.rs','program.rs','runtime.rs','invocation.rs','values.rs','buffer_frames.rs']:(o/name).touch()
adapt(w/'hosts/gpu/src/lib.rs',o/'lib.rs',{'native_artifact':o/'native_artifact.rs'})
adapt(w/'hosts/gpu/src/native_artifact/mod.rs',o/'native_artifact.rs',{'program':o/'program.rs','values':o/'values.rs'})
adapt(w/'hosts/gpu/src/native_artifact/program/mod.rs',o/'program.rs',{'runtime':o/'runtime.rs'})
adapt(w/'hosts/gpu/src/native_artifact/program/runtime/mod.rs',o/'runtime.rs',{'invocation':o/'invocation.rs','buffer_frames':o/'buffer_frames.rs'})
adapt(w/'hosts/gpu/src/native_artifact/program/runtime/invocation/mod.rs',o/'invocation.rs',{},'\n#[path = '+json.dumps(str(o/'probe.rs'))+']\nmod ownership_probe;\n')
adapt(w/'hosts/gpu/src/native_artifact/values/mod.rs',o/'values.rs',{},'''\nimpl NativeValueArena<'_> { fn test_current_slots(&self)->&[Option<Value>]{self.values.values()} }\n'''.replace('fn test_current_slots','pub(in crate::native_artifact) fn test_current_slots'))
adapt(w/'hosts/gpu/src/native_artifact/program/runtime/buffer_frames.rs',o/'buffer_frames.rs',{},'''\nimpl BufferFrames { pub(super) fn test_owner_slots(&self)->&[Option<Value>]{self.inner.as_ref().map_or(&[],|i|i.owners.values())} }\n''')
(o/'source-adapter.json').write_text(json.dumps({'adaptation':'Only absolute module/include paths, one diagnostic child module and read-only unmetered test getters for existing arena/frame owner slots. Maintained execution bodies unchanged. No Value clone, weak identity, loan, mutation or debit is added by observation. Actual saved callbacks run unchanged. All timings excluded.','files':manifest},indent=2)+'\n')
s=Path('/private/tmp/mech-append-loops-round25-20261029/after-unit-build.py').read_text().replace("str(r/'after-unit-census/lib.rs')","str(r/'ownership-probe/lib.rs')")
(r/'unit-build.py').write_text(s)
print('Prepared actual-root read-only ownership diagnostic')
