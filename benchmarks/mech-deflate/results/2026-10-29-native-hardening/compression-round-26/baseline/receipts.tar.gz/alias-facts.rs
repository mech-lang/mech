use mech_engine::native_artifact::{NativeProgramReadRole as Read,NativeControlLoop,lower_native_program_artifact_with_definition_table_limit};
fn main(){
 let artifact=mech_engine::decode_program_artifact_bytecode_v1(&std::fs::read("/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc").unwrap()).unwrap();
 let plan=lower_native_program_artifact_with_definition_table_limit(&artifact,&mech_stdlib::source_catalog(),u64::MAX).unwrap();let facts=plan.facts();let mut rows=Vec::new();
 for value in [882,883,908,909,1745,1828]{
  let key=plan.blocks().iter().find_map(|b| match b.action(){
   mech_engine::native_artifact::NativeIterationAction::LibraryCall{operands,output,..}=>operands.iter().copied().chain([*output]).find(|v|v.get()==value),
   mech_engine::native_artifact::NativeIterationAction::Scalar(mech_engine::native_artifact::NativeMatchAction::Copy{source,output})=>[*source,*output].into_iter().find(|v|v.get()==value),_=>None}).unwrap();
  let reads=facts.read_roles(key).unwrap().iter().map(|role|{
   let site=match *role{Read::Action(s)|Read::Terminator(s)=>Some(s),Read::LoopSeed(id)=>Some(match &plan.iterations()[id as usize]{NativeControlLoop::Tail(t)=>t.initialize(),NativeControlLoop::Iteration(t)=>t.initialize(),_=>u32::MAX}),Read::LoopNext(id)=>Some(match &plan.iterations()[id as usize]{NativeControlLoop::Tail(t)=>t.latch(),NativeControlLoop::Iteration(t)=>t.latch(),_=>u32::MAX}),Read::LoopReturned(id)=>Some(match &plan.iterations()[id as usize]{NativeControlLoop::Tail(t)=>t.finish(),_=>u32::MAX}),_=>None};
   serde_json::json!({"role":format!("{role:?}"),"site":site,"block":site.and_then(|s|plan.blocks().get(s as usize)).map(|b|format!("{b:?}"))})
  }).collect::<Vec<_>>();
  rows.push(serde_json::json!({"value":value,"type":format!("{:?}",plan.values()[value as usize].definition()),"scope":format!("{:?}",plan.value_scopes()[value as usize]),"definitions":facts.definition_sites(value).unwrap().iter().map(|d|serde_json::json!({"role":format!("{d:?}"),"block":d.site().map(|s|format!("{:?}",plan.blocks()[s as usize]))})).collect::<Vec<_>>(),"reads":reads}));
 }
 std::fs::write("/private/tmp/mech-field-retirement-round26-20261029/alias-facts.json",serde_json::to_vec_pretty(&rows).unwrap()).unwrap();
}
