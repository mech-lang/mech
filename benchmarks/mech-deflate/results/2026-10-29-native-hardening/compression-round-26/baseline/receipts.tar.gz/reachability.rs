use mech_engine::native_artifact::{NativeIterationAction as A,NativeMatchAction as S,NativeProgramReadRole as R,lower_native_program_artifact_with_definition_table_limit};
fn main(){
 let a=mech_engine::decode_program_artifact_bytecode_v1(&std::fs::read("/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc").unwrap()).unwrap();let p=lower_native_program_artifact_with_definition_table_limit(&a,&mech_stdlib::source_catalog(),u64::MAX).unwrap();let f=p.facts();let mut out=Vec::new();
 for (value,frontier) in [(883,2216),(883,2365),(882,1038)]{
  let key=p.blocks().iter().find_map(|b|match b.action(){A::LibraryCall{operands,output,..}=>operands.iter().copied().chain([*output]).find(|v|v.get()==value),A::Scalar(S::Copy{source,output})=>[*source,*output].into_iter().find(|v|v.get()==value),_=>None}).unwrap();
  let reads=f.read_roles(key).unwrap();let definitions=f.definition_sites(value).unwrap();let mut pending=f.successors(frontier).unwrap().into_iter().flatten().map(|s|(s,vec![frontier,s])).collect::<Vec<_>>();let mut seen=vec![false;p.blocks().len()];let mut found=None;
  while let Some((site,path))=pending.pop(){if core::mem::replace(&mut seen[site as usize],true){continue;}if reads.iter().any(|r|matches!(r,R::Action(s) if *s==site)){found=Some((site,path));break;}if definitions.iter().any(|d|d.site()==Some(site)){continue;}if reads.iter().any(|r|matches!(r,R::Terminator(s) if *s==site)){found=Some((site,path));break;}for next in f.successors(site).unwrap().into_iter().flatten(){let mut path=path.clone();path.push(next);pending.push((next,path));}}
  out.push(serde_json::json!({"value":value,"frontier":frontier,"future_action_or_terminator_read_before_redefinition":found,"other_reads":reads.iter().filter(|r|!matches!(r,R::Action(_)|R::Terminator(_))).map(|r|format!("{r:?}")).collect::<Vec<_>>() }));
 }
 std::fs::write("/private/tmp/mech-field-retirement-round26-20261029/reachability.json",serde_json::to_vec_pretty(&out).unwrap()).unwrap();
}
