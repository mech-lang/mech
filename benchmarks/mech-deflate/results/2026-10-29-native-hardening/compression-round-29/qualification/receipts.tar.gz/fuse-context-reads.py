from pathlib import Path
p=Path('/private/tmp/mech-deflate-linear-stack/src/engine/src/resident/budget.rs');s=p.read_text()
a=s.index('    pub fn unscoped_remaining(&self)');b=s.index('    /// Identity of the account',a)
s=s[:a]+'''    pub fn unscoped_remaining(&self) -> Option<(u64, u64)> {
        CONTROL_WORK_CONTEXT.with(|context| {
            if context.active.borrow().is_some() || context.scope.borrow().is_some() {
                return None;
            }
            let state = self.account.borrow();
            let local = unscoped_local_remaining_at_limits(&state, context.limits.get())?;
            if let Some(worker) = &state.worker {
                let shared = worker.remaining()?;
                Some((local.0.min(shared.0), local.1.min(shared.1)))
            } else {
                Some(local)
            }
        })
    }

'''+s[b:]
a=s.index('    pub(in crate::resident) fn has_matching_active_scope(&self)');b=s.index('    /// Generated scalar/control work',a)
s=s[:a]+'''    pub(in crate::resident) fn has_matching_active_scope(&self) -> bool {
        CONTROL_WORK_CONTEXT.with(|context| {
            context.active.borrow().as_ref()
                .is_some_and(|current| std::rc::Rc::ptr_eq(current, &self.account))
                && context.scope.borrow().as_ref()
                    .is_some_and(|scope| std::rc::Rc::ptr_eq(&scope.total, &self.account))
        })
    }

'''+s[b:]
a=s.index('        with_control_work(|active| {',s.index('    pub fn with_call_limits<T>'))
b=s.index('\n    }\n}\n\nstruct ControlWorkScope',a)
s=s[:a]+'''        CONTROL_WORK_CONTEXT.with(|context| {
            let active = &context.active;
            let previous = {
                let mut current = active.borrow_mut();
                if current.as_ref().is_some_and(|account| !Rc::ptr_eq(account, &self.account)) {
                    return Err(ResidentKernelError::InvalidInput);
                }
                current.replace(self.account.clone())
            };
            let _account = AccountGuard(active, previous);
            let scope = &context.scope;
            let previous = scope.replace(Some(ControlWorkScope {
                total: self.account.clone(),
                observed: ControlWork::default(),
            }));
            let _scope = ScopeGuard(scope, previous);
            let used = self.used();
            let limits = &context.limits;
            let previous = limits.get();
            let enclosing = previous.unwrap_or((u64::MAX, u64::MAX));
            limits.set(Some((
                used.0.saturating_add(compute).min(enclosing.0),
                used.1.saturating_add(comparison).min(enclosing.1),
            )));
            let _limits = LimitGuard(limits, previous);
            Ok(execute())
        })'''+s[b:]
a=s.index('fn unscoped_local_remaining(account:');b=s.index('    Some((\n',a)
s=s[:a]+'''fn unscoped_local_remaining(account: &ControlWorkAccount) -> Option<(u64, u64)> {
    with_control_root_limits(|limits| unscoped_local_remaining_at_limits(account, limits.get()))
}

#[cfg(feature = "native-artifact")]
fn unscoped_local_remaining_at_limits(
    account: &ControlWorkAccount,
    limits: Option<(u64, u64)>,
) -> Option<(u64, u64)> {
    let root = limits.unwrap_or((u64::MAX, u64::MAX));
'''+s[b:]
# Preserve the same checked preview and worker availability while sharing TLS.
a=s.index('pub(in crate::resident) fn preview_control_work(');b=s.index('\npub(crate) fn observe_control_work',a)
block=s[a:b];block=block.replace('with_control_work_scope(|active| {','CONTROL_WORK_CONTEXT.with(|context| {\n        let active = &context.scope;');block=block.replace('checked_control_account_work(\n','checked_control_account_work_at_limits(\n');block=block.replace('        )\n        .map(drop)','            context.limits.get(),\n        )\n        .map(drop)');s=s[:a]+block+s[b:]
a=s.index('pub(crate) fn observe_control_work(');b=s.index('\n#[cfg(all(test, feature = "native-artifact"))]',a)
block=s[a:b];block=block.replace('with_control_work_scope(|active| {','CONTROL_WORK_CONTEXT.with(|context| {\n        let active = &context.scope;').replace('charge_control_account(\n','charge_control_account_at_limits(\n');block=block.replace('        )?;\n        scope.observed','            context.limits.get(),\n        )?;\n        scope.observed');s=s[:a]+block+s[b:]
# Add the preview helper with an explicit current cap; worker preview remains.
a=s.index('fn checked_control_account_work(\n');b=s.index('    let next = checked_local_control_account_work',a)
s=s[:a]+'''fn checked_control_account_work(
    account: &ControlWorkAccount,
    compute: u64,
    comparison: u64,
) -> Result<ControlWork, ResidentKernelError> {
    with_control_root_limits(|limits| {
        checked_control_account_work_at_limits(account, compute, comparison, limits.get())
    })
}

fn checked_control_account_work_at_limits(
    account: &ControlWorkAccount,
    compute: u64,
    comparison: u64,
    limits: Option<(u64, u64)>,
) -> Result<ControlWork, ResidentKernelError> {
'''+s[b:]
a=s.index('fn checked_control_account_work_at_limits(');left=s[:a];right=s[a:].replace('let next = checked_local_control_account_work(account, compute, comparison)?;','let next = checked_local_control_account_work_at_limits(account, compute, comparison, limits)?;',1);s=left+right
p.write_text(s)
