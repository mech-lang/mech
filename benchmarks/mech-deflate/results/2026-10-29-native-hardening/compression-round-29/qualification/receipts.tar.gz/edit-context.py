from pathlib import Path
import re
w=Path('/private/tmp/mech-deflate-linear-stack');paths=[w/'src/engine/src/resident'/n for n in ['budget.rs','native_worker_budget.rs','native_worker_credits.rs','borrowed_metadata_scan_tests.rs','native_worker_budget_tests.rs']]
for p in paths:
 s=p.read_text()
 for old,new in [('CONTROL_WORK_SCOPE','with_control_work_scope'),('CONTROL_ROOT_LIMITS','with_control_root_limits'),('CONTROL_WORK','with_control_work')]:
  s=re.sub(r'\b'+old+r'\s*\.with',new,s)
 p.write_text(s)
p=paths[0];s=p.read_text();old='''thread_local! {
    static CONTROL_WORK: std::cell::RefCell<Option<std::rc::Rc<std::cell::RefCell<ControlWorkAccount>>>> = const { std::cell::RefCell::new(None) };
    static CONTROL_WORK_SCOPE: std::cell::RefCell<Option<ControlWorkScope>> = const { std::cell::RefCell::new(None) };
    static CONTROL_ROOT_LIMITS: std::cell::Cell<Option<(u64, u64)>> = const { std::cell::Cell::new(None) };
    static PLANNING_STEPS: std::cell::RefCell<Option<PlanningSteps>> = const { std::cell::RefCell::new(None) };
}
''';assert old in s
new='''// One thread-local address for the existing account, observer and relative
// caps. Independent cells preserve the original reentrant borrow boundaries;
// holding a field reference does not borrow the whole context across execution.
struct ControlWorkContext {
    active: std::cell::RefCell<Option<std::rc::Rc<std::cell::RefCell<ControlWorkAccount>>>>,
    scope: std::cell::RefCell<Option<ControlWorkScope>>,
    limits: std::cell::Cell<Option<(u64, u64)>>,
}
thread_local! {
    static CONTROL_WORK_CONTEXT: ControlWorkContext = const { ControlWorkContext {
        active: std::cell::RefCell::new(None),
        scope: std::cell::RefCell::new(None),
        limits: std::cell::Cell::new(None),
    } };
    static PLANNING_STEPS: std::cell::RefCell<Option<PlanningSteps>> = const { std::cell::RefCell::new(None) };
}
#[inline]
fn with_control_work<T>(
    call: impl FnOnce(&std::cell::RefCell<Option<std::rc::Rc<std::cell::RefCell<ControlWorkAccount>>>>) -> T,
) -> T {
    CONTROL_WORK_CONTEXT.with(|context| call(&context.active))
}
#[inline]
fn with_control_work_scope<T>(call: impl FnOnce(&std::cell::RefCell<Option<ControlWorkScope>>) -> T) -> T {
    CONTROL_WORK_CONTEXT.with(|context| call(&context.scope))
}
#[inline]
fn with_control_root_limits<T>(call: impl FnOnce(&std::cell::Cell<Option<(u64, u64)>>) -> T) -> T {
    CONTROL_WORK_CONTEXT.with(|context| call(&context.limits))
}
''';s=s.replace(old,new)
a=s.index('    pub fn charge(&self, compute: u64, comparison: u64)');b=s.index('    /// Preview the same account',a)
s=s[:a]+'''    pub fn charge(&self, compute: u64, comparison: u64) -> Result<(), ResidentKernelError> {
        CONTROL_WORK_CONTEXT.with(|context| self.charge_in_context(context, compute, comparison))
    }

    /// Apply an additional caller compute ceiling before the existing account
    /// checks. This cannot grant fuel or replace any shared/relative/worker cap.
    /// Native callers retain ceiling/overflow precedence over a foreign scope.
    pub fn charge_compute_with_limit(
        &self,
        compute: u64,
        limit: u64,
    ) -> Result<(), ResidentKernelError> {
        let exceeded = |required| ResidentKernelError::ResourceLimit {
            phase: mech_core::ResidentResourcePhase::Admission,
            dimension: MemoryBudgetDimension::ComputeWork,
            required,
            limit,
        };
        let required = self.account.borrow().used.compute.checked_add(compute)
            .ok_or_else(|| exceeded(u64::MAX))?;
        if required > limit {
            return Err(exceeded(required));
        }
        CONTROL_WORK_CONTEXT.with(|context| self.charge_in_context(context, compute, 0))
    }

    #[inline]
    fn charge_in_context(
        &self,
        context: &ControlWorkContext,
        compute: u64,
        comparison: u64,
    ) -> Result<(), ResidentKernelError> {
        if context.active.borrow().as_ref()
            .is_some_and(|current| !std::rc::Rc::ptr_eq(current, &self.account)) {
            return Err(ResidentKernelError::InvalidInput);
        }
        charge_control_account_at_limits(
            &mut self.account.borrow_mut(), compute, comparison, context.limits.get(),
        )
    }

'''+s[b:]
# Keep shared helpers for worker callers; hot context-aware callers pass the
# exact same current relative cap without resolving another TLS descriptor.
a=s.index('fn checked_local_control_account_work(\n');b=s.index('    let compute_limit = account.compute_limit.min(root_compute);',a)
oldprefix=s[a:b]
newprefix='''fn checked_local_control_account_work(
    account: &ControlWorkAccount,
    compute: u64,
    comparison: u64,
) -> Result<ControlWork, ResidentKernelError> {
    with_control_root_limits(|limits| {
        checked_local_control_account_work_at_limits(account, compute, comparison, limits.get())
    })
}

fn checked_local_control_account_work_at_limits(
    account: &ControlWorkAccount,
    compute: u64,
    comparison: u64,
    limits: Option<(u64, u64)>,
) -> Result<ControlWork, ResidentKernelError> {
    let (root_compute, root_comparison) = limits.unwrap_or((u64::MAX, u64::MAX));
'''
s=s[:a]+newprefix+s[b:]
a=s.index('fn charge_control_account(\n');b=s.index('    // A real debit checks and commits',a)
s=s[:a]+'''fn charge_control_account(
    account: &mut ControlWorkAccount,
    compute: u64,
    comparison: u64,
) -> Result<(), ResidentKernelError> {
    with_control_root_limits(|limits| {
        charge_control_account_at_limits(account, compute, comparison, limits.get())
    })
}

fn charge_control_account_at_limits(
    account: &mut ControlWorkAccount,
    compute: u64,
    comparison: u64,
    limits: Option<(u64, u64)>,
) -> Result<(), ResidentKernelError> {
'''+s[b:]
# Only the actual-debit helper below this boundary, not the preview helper.
a=s.index('fn charge_control_account_at_limits(');before=s[:a];tail=s[a:].replace('let next = checked_local_control_account_work(account, compute, comparison)?;','let next = checked_local_control_account_work_at_limits(account, compute, comparison, limits)?;',1);s=before+tail
p.write_text(s)
