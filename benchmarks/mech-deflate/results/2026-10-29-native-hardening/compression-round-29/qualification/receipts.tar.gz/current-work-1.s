/private/tmp/mech-ownership-round29-20261029/primary/current:
(__TEXT,__text) section
__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit:
10230d120:	ff 03 02 d1	sub	sp, sp, #0x80
10230d124:	f4 4f 06 a9	stp	x20, x19, [sp, #0x60]
10230d128:	fd 7b 07 a9	stp	x29, x30, [sp, #0x70]
10230d12c:	fd c3 01 91	add	x29, sp, #0x70
10230d130:	13 00 40 f9	ldr	x19, [x0]
10230d134:	69 0a 40 f9	ldr	x9, [x19, #0x10]
10230d138:	0a 00 f0 92	mov	x10, #0x7fffffffffffffff
10230d13c:	3f 01 0a eb	cmp	x9, x10
10230d140:	62 03 00 54	b.hs	0x10230d1ac
10230d144:	2a 05 00 91	add	x10, x9, #0x1
10230d148:	6a 0a 00 f9	str	x10, [x19, #0x10]
10230d14c:	6a 1e 40 f9	ldr	x10, [x19, #0x38]
10230d150:	4a 01 01 ab	adds	x10, x10, x1
10230d154:	22 03 00 54	b.hs	0x10230d1b8
10230d158:	69 0a 00 f9	str	x9, [x19, #0x10]
10230d15c:	5f 01 02 eb	cmp	x10, x2
10230d160:	e9 00 00 54	b.ls	0x10230d17c
10230d164:	c9 c0 80 52	mov	w9, #0x606
10230d168:	09 01 00 79	strh	w9, [x8]
10230d16c:	29 00 80 52	mov	w9, #0x1
10230d170:	09 09 00 39	strb	w9, [x8, #0x2]
10230d174:	0a 89 00 a9	stp	x10, x2, [x8, #0x8]
10230d178:	4d 00 00 14	b	0x10230d2ac
10230d17c:	60 c0 00 d0	adrp	x0, 6158 ; 0x103b1b000
10230d180:	00 a0 14 91	add	x0, x0, #0x528
10230d184:	09 00 40 f9	ldr	x9, [x0]
10230d188:	20 01 3f d6	blr	x9
10230d18c:	09 20 41 39	ldrb	w9, [x0, #0x48]
10230d190:	3f 05 00 71	cmp	w9, #0x1
10230d194:	60 03 00 54	b.eq	0x10230d200
10230d198:	3f 09 00 71	cmp	w9, #0x2
10230d19c:	e1 01 00 54	b.ne	0x10230d1d8
10230d1a0:	a0 be 00 d0	adrp	x0, 6102 ; 0x103ae3000
10230d1a4:	00 00 3b 91	add	x0, x0, #0xec0
10230d1a8:	2a 5c 2b 94	bl	__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error
10230d1ac:	c0 be 00 90	adrp	x0, 6104 ; 0x103ae5000
10230d1b0:	00 e0 12 91	add	x0, x0, #0x4b8
10230d1b4:	d4 5d 2b 94	bl	__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed
10230d1b8:	ca c0 80 52	mov	w10, #0x606
10230d1bc:	0a 01 00 79	strh	w10, [x8]
10230d1c0:	2a 00 80 52	mov	w10, #0x1
10230d1c4:	0a 09 00 39	strb	w10, [x8, #0x2]
10230d1c8:	0a 00 80 92	mov	x10, #-0x1
10230d1cc:	0a 89 00 a9	stp	x10, x2, [x8, #0x8]
10230d1d0:	69 0a 00 f9	str	x9, [x19, #0x10]
10230d1d4:	36 00 00 14	b	0x10230d2ac
10230d1d8:	29 31 00 d0	adrp	x9, 1574 ; 0x102933000
10230d1dc:	29 51 1c 91	add	x9, x9, #0x714
10230d1e0:	e1 03 00 a9	stp	x1, x0, [sp]
10230d1e4:	e1 03 09 aa	mov	x1, x9
10230d1e8:	f4 03 08 aa	mov	x20, x8
10230d1ec:	f9 19 2a 94	bl	__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register
10230d1f0:	e1 03 40 a9	ldp	x1, x0, [sp]
10230d1f4:	e8 03 14 aa	mov	x8, x20
10230d1f8:	29 00 80 52	mov	w9, #0x1
10230d1fc:	09 20 01 39	strb	w9, [x0, #0x48]
10230d200:	09 10 40 f9	ldr	x9, [x0, #0x20]
10230d204:	0a 00 f0 92	mov	x10, #0x7fffffffffffffff
10230d208:	3f 01 0a eb	cmp	x9, x10
10230d20c:	82 05 00 54	b.hs	0x10230d2bc
10230d210:	09 14 40 f9	ldr	x9, [x0, #0x28]
10230d214:	3f 01 00 f1	cmp	x9, #0x0
10230d218:	24 11 53 fa	ccmp	x9, x19, #0x4, ne
10230d21c:	a1 03 00 54	b.ne	0x10230d290
10230d220:	f4 03 08 aa	mov	x20, x8
10230d224:	68 0a 40 f9	ldr	x8, [x19, #0x10]
10230d228:	08 05 00 b5	cbnz	x8, 0x10230d2c8
10230d22c:	e2 03 01 aa	mov	x2, x1
10230d230:	08 00 80 92	mov	x8, #-0x1
10230d234:	68 0a 00 f9	str	x8, [x19, #0x10]
10230d238:	00 0c c0 3d	ldr	q0, [x0, #0x30]
10230d23c:	e0 07 80 3d	str	q0, [sp, #0x10]
10230d240:	08 20 40 f9	ldr	x8, [x0, #0x40]
10230d244:	e8 13 00 f9	str	x8, [sp, #0x20]
10230d248:	e0 e3 00 91	add	x0, sp, #0x38
10230d24c:	61 62 00 91	add	x1, x19, #0x18
10230d250:	e4 43 00 91	add	x4, sp, #0x10
10230d254:	03 00 80 d2	mov	x3, #0x0
10230d258:	db 61 00 94	bl	__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits
10230d25c:	68 0a 40 f9	ldr	x8, [x19, #0x10]
10230d260:	08 05 00 91	add	x8, x8, #0x1
10230d264:	68 0a 00 f9	str	x8, [x19, #0x10]
10230d268:	e9 e3 40 39	ldrb	w9, [sp, #0x38]
10230d26c:	e0 93 c3 3c	ldur	q0, [sp, #0x39]
10230d270:	e1 93 c4 3c	ldur	q1, [sp, #0x49]
10230d274:	e0 87 00 ad	stp	q0, q1, [sp, #0x10]
10230d278:	e8 2f 40 f9	ldr	x8, [sp, #0x58]
10230d27c:	e8 f3 02 f8	stur	x8, [sp, #0x2f]
10230d280:	3f 25 00 71	cmp	w9, #0x9
10230d284:	e8 03 14 aa	mov	x8, x20
10230d288:	61 00 00 54	b.ne	0x10230d294
10230d28c:	c5 ff ff 17	b	0x10230d1a0
10230d290:	09 00 80 52	mov	w9, #0x0
10230d294:	09 01 00 39	strb	w9, [x8]
10230d298:	e0 87 40 ad	ldp	q0, q1, [sp, #0x10]
10230d29c:	00 11 80 3c	stur	q0, [x8, #0x1]
10230d2a0:	01 11 81 3c	stur	q1, [x8, #0x11]
10230d2a4:	e9 f3 42 f8	ldur	x9, [sp, #0x2f]
10230d2a8:	09 11 00 f9	str	x9, [x8, #0x20]
10230d2ac:	fd 7b 47 a9	ldp	x29, x30, [sp, #0x70]
10230d2b0:	f4 4f 46 a9	ldp	x20, x19, [sp, #0x60]
10230d2b4:	ff 03 02 91	add	sp, sp, #0x80
10230d2b8:	c0 03 5f d6	ret
10230d2bc:	c0 be 00 90	adrp	x0, 6104 ; 0x103ae5000
10230d2c0:	00 c0 11 91	add	x0, x0, #0x470
10230d2c4:	90 5d 2b 94	bl	__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed
10230d2c8:	c0 be 00 90	adrp	x0, 6104 ; 0x103ae5000
10230d2cc:	00 20 12 91	add	x0, x0, #0x488
10230d2d0:	81 5d 2b 94	bl	__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed
10230d2d4:	68 0a 40 f9	ldr	x8, [x19, #0x10]
10230d2d8:	08 05 00 91	add	x8, x8, #0x1
10230d2dc:	68 0a 00 f9	str	x8, [x19, #0x10]
10230d2e0:	bb 62 2b 94	bl	0x102de5dcc ; symbol stub for: __Unwind_Resume
