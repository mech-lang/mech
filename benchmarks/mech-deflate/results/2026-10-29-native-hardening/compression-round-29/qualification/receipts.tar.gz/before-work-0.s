/private/tmp/mech-ownership-round29-20261029/primary/before:
(__TEXT,__text) section
__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge:
1014ab0bc:	ff 43 02 d1	sub	sp, sp, #0x90
1014ab0c0:	fa 67 04 a9	stp	x26, x25, [sp, #0x40]
1014ab0c4:	f8 5f 05 a9	stp	x24, x23, [sp, #0x50]
1014ab0c8:	f6 57 06 a9	stp	x22, x21, [sp, #0x60]
1014ab0cc:	f4 4f 07 a9	stp	x20, x19, [sp, #0x70]
1014ab0d0:	fd 7b 08 a9	stp	x29, x30, [sp, #0x80]
1014ab0d4:	fd 03 02 91	add	x29, sp, #0x80
1014ab0d8:	f6 03 03 aa	mov	x22, x3
1014ab0dc:	f4 03 02 aa	mov	x20, x2
1014ab0e0:	f5 03 01 aa	mov	x21, x1
1014ab0e4:	f8 03 00 aa	mov	x24, x0
1014ab0e8:	f3 03 08 aa	mov	x19, x8
1014ab0ec:	f7 03 00 aa	mov	x23, x0
1014ab0f0:	f9 8e 41 f8	ldr	x25, [x23, #0x18]!
1014ab0f4:	b9 04 00 b4	cbz	x25, 0x1014ab188
1014ab0f8:	1a 23 00 91	add	x26, x24, #0x8
1014ab0fc:	e0 03 17 aa	mov	x0, x23
1014ab100:	21 4e 39 94	bl	__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget4used
1014ab104:	08 0b 40 f9	ldr	x8, [x24, #0x10]
1014ab108:	09 00 16 ab	adds	x9, x0, x22
1014ab10c:	62 05 00 54	b.hs	0x1014ab1b8
1014ab110:	3f 01 08 eb	cmp	x9, x8
1014ab114:	c9 00 00 54	b.ls	0x1014ab12c
1014ab118:	ca 00 80 52	mov	w10, #0x6
1014ab11c:	6a 02 00 39	strb	w10, [x19]
1014ab120:	69 a2 00 a9	stp	x9, x8, [x19, #0x8]
1014ab124:	75 52 03 29	stp	w21, w20, [x19, #0x18]
1014ab128:	3f 00 00 14	b	0x1014ab224
1014ab12c:	f9 04 00 b4	cbz	x25, 0x1014ab1c8
1014ab130:	e8 23 00 91	add	x8, sp, #0x8
1014ab134:	e0 03 17 aa	mov	x0, x23
1014ab138:	e1 03 16 aa	mov	x1, x22
1014ab13c:	02 00 80 d2	mov	x2, #0x0
1014ab140:	1d 4e 39 94	bl	__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge
1014ab144:	e9 23 40 39	ldrb	w9, [sp, #0x8]
1014ab148:	3f 21 00 71	cmp	w9, #0x8
1014ab14c:	00 04 00 54	b.eq	0x1014ab1cc
1014ab150:	eb 27 40 39	ldrb	w11, [sp, #0x9]
1014ab154:	e8 2b 41 a9	ldp	x8, x10, [sp, #0x10]
1014ab158:	3f 19 00 71	cmp	w9, #0x6
1014ab15c:	e1 03 00 54	b.ne	0x1014ab1d8
1014ab160:	7f 19 00 71	cmp	w11, #0x6
1014ab164:	a1 03 00 54	b.ne	0x1014ab1d8
1014ab168:	09 1d 00 12	and	w9, w8, #0xff
1014ab16c:	0b fd 48 d3	lsr	x11, x8, #8
1014ab170:	0c fd 50 d3	lsr	x12, x8, #16
1014ab174:	cd 00 80 52	mov	w13, #0x6
1014ab178:	e8 03 0a aa	mov	x8, x10
1014ab17c:	ea 03 15 aa	mov	x10, x21
1014ab180:	ee 03 14 aa	mov	x14, x20
1014ab184:	1c 00 00 14	b	0x1014ab1f4
1014ab188:	5d 4b 39 94	bl	__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope
1014ab18c:	c0 00 00 36	tbz	w0, #0x0, 0x1014ab1a4
1014ab190:	e8 00 80 52	mov	w8, #0x7
1014ab194:	68 02 00 39	strb	w8, [x19]
1014ab198:	7f 06 00 f9	str	xzr, [x19, #0x8]
1014ab19c:	7f 1e 00 b9	str	wzr, [x19, #0x1c]
1014ab1a0:	20 00 00 14	b	0x1014ab220
1014ab1a4:	fa 03 18 aa	mov	x26, x24
1014ab1a8:	40 8f 40 f8	ldr	x0, [x26, #0x8]!
1014ab1ac:	08 0b 40 f9	ldr	x8, [x24, #0x10]
1014ab1b0:	09 00 16 ab	adds	x9, x0, x22
1014ab1b4:	e3 fa ff 54	b.lo	0x1014ab110
1014ab1b8:	c9 00 80 52	mov	w9, #0x6
1014ab1bc:	69 02 00 39	strb	w9, [x19]
1014ab1c0:	09 00 80 92	mov	x9, #-0x1
1014ab1c4:	d7 ff ff 17	b	0x1014ab120
1014ab1c8:	49 03 00 f9	str	x9, [x26]
1014ab1cc:	c8 01 80 52	mov	w8, #0xe
1014ab1d0:	68 02 00 39	strb	w8, [x19]
1014ab1d4:	14 00 00 14	b	0x1014ab224
1014ab1d8:	ec 1f 40 79	ldrh	w12, [sp, #0xe]
1014ab1dc:	ed a3 40 b8	ldur	w13, [sp, #0xa]
1014ab1e0:	ac 81 0c aa	orr	x12, x13, x12, lsl #32
1014ab1e4:	4e fd 60 d3	lsr	x14, x10, #32
1014ab1e8:	e0 03 c2 3c	ldur	q0, [sp, #0x20]
1014ab1ec:	e0 0f 80 3d	str	q0, [sp, #0x30]
1014ab1f0:	ed 00 80 52	mov	w13, #0x7
1014ab1f4:	6b 1d 78 d3	ubfiz	x11, x11, #8, #8
1014ab1f8:	6b 41 0c aa	orr	x11, x11, x12, lsl #16
1014ab1fc:	e9 03 09 2a	mov	w9, w9
1014ab200:	69 01 09 aa	orr	x9, x11, x9
1014ab204:	ea 03 0a 2a	mov	w10, w10
1014ab208:	4a 81 0e aa	orr	x10, x10, x14, lsl #32
1014ab20c:	6d 02 00 39	strb	w13, [x19]
1014ab210:	69 a2 00 a9	stp	x9, x8, [x19, #0x8]
1014ab214:	6a 0e 00 f9	str	x10, [x19, #0x18]
1014ab218:	e0 0f c0 3d	ldr	q0, [sp, #0x30]
1014ab21c:	60 0a 80 3d	str	q0, [x19, #0x20]
1014ab220:	75 52 06 29	stp	w21, w20, [x19, #0x30]
1014ab224:	fd 7b 48 a9	ldp	x29, x30, [sp, #0x80]
1014ab228:	f4 4f 47 a9	ldp	x20, x19, [sp, #0x70]
1014ab22c:	f6 57 46 a9	ldp	x22, x21, [sp, #0x60]
1014ab230:	f8 5f 45 a9	ldp	x24, x23, [sp, #0x50]
1014ab234:	fa 67 44 a9	ldp	x26, x25, [sp, #0x40]
1014ab238:	ff 43 02 91	add	sp, sp, #0x90
1014ab23c:	c0 03 5f d6	ret
