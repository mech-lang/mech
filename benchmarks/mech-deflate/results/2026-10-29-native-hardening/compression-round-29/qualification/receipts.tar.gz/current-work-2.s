/private/tmp/mech-ownership-round29-20261029/primary/current:
(__TEXT,__text) section
__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge:
10230d598:	ff 43 02 d1	sub	sp, sp, #0x90
10230d59c:	f4 4f 07 a9	stp	x20, x19, [sp, #0x70]
10230d5a0:	fd 7b 08 a9	stp	x29, x30, [sp, #0x80]
10230d5a4:	fd 03 02 91	add	x29, sp, #0x80
10230d5a8:	f3 03 00 aa	mov	x19, x0
10230d5ac:	60 c0 00 d0	adrp	x0, 6158 ; 0x103b1b000
10230d5b0:	00 a0 14 91	add	x0, x0, #0x528
10230d5b4:	09 00 40 f9	ldr	x9, [x0]
10230d5b8:	20 01 3f d6	blr	x9
10230d5bc:	09 20 41 39	ldrb	w9, [x0, #0x48]
10230d5c0:	3f 05 00 71	cmp	w9, #0x1
10230d5c4:	40 02 00 54	b.eq	0x10230d60c
10230d5c8:	3f 09 00 71	cmp	w9, #0x2
10230d5cc:	81 00 00 54	b.ne	0x10230d5dc
10230d5d0:	a0 be 00 d0	adrp	x0, 6102 ; 0x103ae3000
10230d5d4:	00 00 3b 91	add	x0, x0, #0xec0
10230d5d8:	1e 5b 2b 94	bl	__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error
10230d5dc:	29 31 00 d0	adrp	x9, 1574 ; 0x102933000
10230d5e0:	29 51 1c 91	add	x9, x9, #0x714
10230d5e4:	e1 03 01 a9	stp	x1, x0, [sp, #0x10]
10230d5e8:	e1 03 09 aa	mov	x1, x9
10230d5ec:	e8 07 00 f9	str	x8, [sp, #0x8]
10230d5f0:	f4 03 02 aa	mov	x20, x2
10230d5f4:	f7 18 2a 94	bl	__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register
10230d5f8:	e1 03 41 a9	ldp	x1, x0, [sp, #0x10]
10230d5fc:	e2 03 14 aa	mov	x2, x20
10230d600:	e8 07 40 f9	ldr	x8, [sp, #0x8]
10230d604:	29 00 80 52	mov	w9, #0x1
10230d608:	09 20 01 39	strb	w9, [x0, #0x48]
10230d60c:	09 10 40 f9	ldr	x9, [x0, #0x20]
10230d610:	0a 00 f0 92	mov	x10, #0x7fffffffffffffff
10230d614:	3f 01 0a eb	cmp	x9, x10
10230d618:	c2 05 00 54	b.hs	0x10230d6d0
10230d61c:	73 02 40 f9	ldr	x19, [x19]
10230d620:	09 14 40 f9	ldr	x9, [x0, #0x28]
10230d624:	3f 01 00 f1	cmp	x9, #0x0
10230d628:	24 11 53 fa	ccmp	x9, x19, #0x4, ne
10230d62c:	c1 03 00 54	b.ne	0x10230d6a4
10230d630:	69 0a 40 f9	ldr	x9, [x19, #0x10]
10230d634:	49 05 00 b5	cbnz	x9, 0x10230d6dc
10230d638:	f4 03 08 aa	mov	x20, x8
10230d63c:	08 00 80 92	mov	x8, #-0x1
10230d640:	68 0a 00 f9	str	x8, [x19, #0x10]
10230d644:	00 0c c0 3d	ldr	q0, [x0, #0x30]
10230d648:	e0 0b 80 3d	str	q0, [sp, #0x20]
10230d64c:	08 20 40 f9	ldr	x8, [x0, #0x40]
10230d650:	e8 1b 00 f9	str	x8, [sp, #0x30]
10230d654:	a0 e3 00 d1	sub	x0, x29, #0x38
10230d658:	e8 03 01 aa	mov	x8, x1
10230d65c:	61 62 00 91	add	x1, x19, #0x18
10230d660:	e4 83 00 91	add	x4, sp, #0x20
10230d664:	e3 03 02 aa	mov	x3, x2
10230d668:	e2 03 08 aa	mov	x2, x8
10230d66c:	d6 60 00 94	bl	__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits
10230d670:	68 0a 40 f9	ldr	x8, [x19, #0x10]
10230d674:	08 05 00 91	add	x8, x8, #0x1
10230d678:	68 0a 00 f9	str	x8, [x19, #0x10]
10230d67c:	a9 83 5c 38	ldurb	w9, [x29, #-0x38]
10230d680:	a0 93 dc 3c	ldur	q0, [x29, #-0x37]
10230d684:	a1 93 dd 3c	ldur	q1, [x29, #-0x27]
10230d688:	e0 07 01 ad	stp	q0, q1, [sp, #0x20]
10230d68c:	a8 83 5e f8	ldur	x8, [x29, #-0x18]
10230d690:	e8 f3 03 f8	stur	x8, [sp, #0x3f]
10230d694:	3f 25 00 71	cmp	w9, #0x9
10230d698:	e8 03 14 aa	mov	x8, x20
10230d69c:	61 00 00 54	b.ne	0x10230d6a8
10230d6a0:	cc ff ff 17	b	0x10230d5d0
10230d6a4:	09 00 80 52	mov	w9, #0x0
10230d6a8:	09 01 00 39	strb	w9, [x8]
10230d6ac:	e0 07 41 ad	ldp	q0, q1, [sp, #0x20]
10230d6b0:	00 11 80 3c	stur	q0, [x8, #0x1]
10230d6b4:	01 11 81 3c	stur	q1, [x8, #0x11]
10230d6b8:	e9 f3 43 f8	ldur	x9, [sp, #0x3f]
10230d6bc:	09 11 00 f9	str	x9, [x8, #0x20]
10230d6c0:	fd 7b 48 a9	ldp	x29, x30, [sp, #0x80]
10230d6c4:	f4 4f 47 a9	ldp	x20, x19, [sp, #0x70]
10230d6c8:	ff 43 02 91	add	sp, sp, #0x90
10230d6cc:	c0 03 5f d6	ret
10230d6d0:	c0 be 00 90	adrp	x0, 6104 ; 0x103ae5000
10230d6d4:	00 c0 11 91	add	x0, x0, #0x470
10230d6d8:	8b 5c 2b 94	bl	__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed
10230d6dc:	c0 be 00 90	adrp	x0, 6104 ; 0x103ae5000
10230d6e0:	00 20 12 91	add	x0, x0, #0x488
10230d6e4:	7c 5c 2b 94	bl	__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed
10230d6e8:	68 0a 40 f9	ldr	x8, [x19, #0x10]
10230d6ec:	08 05 00 91	add	x8, x8, #0x1
10230d6f0:	68 0a 00 f9	str	x8, [x19, #0x10]
10230d6f4:	b6 61 2b 94	bl	0x102de5dcc ; symbol stub for: __Unwind_Resume
