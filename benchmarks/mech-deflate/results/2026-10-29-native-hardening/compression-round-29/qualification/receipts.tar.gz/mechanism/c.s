	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 15, 0	sdk_version 26, 0
	.globl	_separate_fields                ; -- Begin function separate_fields
	.p2align	2
_separate_fields:                       ; @separate_fields
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh0:
	adrp	x0, _old_active@TLVPPAGE
Lloh1:
	ldr	x0, [x0, _old_active@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
Lloh2:
	adrp	x0, _old_relative@TLVPPAGE
Lloh3:
	ldr	x0, [x0, _old_relative@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	cmp	x9, #0
	ccmp	x9, x8, #4, ne
	b.ne	LBB0_3
; %bb.1:
	ldr	x9, [x8, #8]
	adds	x9, x9, x1
	b.lo	LBB0_4
; %bb.2:
	mov	w0, #2                          ; =0x2
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB0_3:
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB0_4:
	ldr	x10, [x0]
	ldr	x11, [x8, #24]
	cmp	x11, x10
	csel	x10, x11, x10, lo
	cmp	x9, x10
	b.ls	LBB0_6
; %bb.5:
	mov	w0, #3                          ; =0x3
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB0_6:
	mov	x11, x0
	ldr	x10, [x8, #16]
	ldr	x12, [x8, #32]
	mov	w0, #3                          ; =0x3
	cmp	x10, x12
	b.hi	LBB0_9
; %bb.7:
	ldr	x11, [x11, #8]
	cmp	x10, x11
	b.hi	LBB0_9
; %bb.8:
	mov	x0, #0                          ; =0x0
	str	x9, [x8, #8]
LBB0_9:
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpLdr	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.globl	_shared_context                 ; -- Begin function shared_context
	.p2align	2
_shared_context:                        ; @shared_context
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh4:
	adrp	x0, _context@TLVPPAGE
Lloh5:
	ldr	x0, [x0, _context@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	cmp	x9, #0
	ccmp	x9, x8, #4, ne
	b.ne	LBB1_3
; %bb.1:
	ldr	x9, [x8, #8]
	adds	x9, x9, x1
	b.lo	LBB1_4
; %bb.2:
	mov	w0, #2                          ; =0x2
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB1_3:
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB1_4:
	ldr	x10, [x0, #8]
	ldr	x11, [x8, #24]
	cmp	x11, x10
	csel	x10, x11, x10, lo
	cmp	x9, x10
	b.ls	LBB1_6
; %bb.5:
	mov	w0, #3                          ; =0x3
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB1_6:
	mov	x11, x0
	ldr	x10, [x8, #16]
	ldr	x12, [x8, #32]
	mov	w0, #3                          ; =0x3
	cmp	x10, x12
	b.hi	LBB1_9
; %bb.7:
	ldr	x11, [x11, #16]
	cmp	x10, x11
	b.hi	LBB1_9
; %bb.8:
	mov	x0, #0                          ; =0x0
	str	x9, [x8, #8]
LBB1_9:
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh4, Lloh5
	.cfi_endproc
                                        ; -- End function
.tbss _old_active$tlv$init, 8, 3        ; @old_active

	.section	__DATA,__thread_vars,thread_local_variables
	.globl	_old_active
_old_active:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_old_active$tlv$init

.tbss _old_relative$tlv$init, 16, 3     ; @old_relative

	.globl	_old_relative
_old_relative:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_old_relative$tlv$init

.tbss _context$tlv$init, 24, 3          ; @context

	.globl	_context
_context:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_context$tlv$init

.subsections_via_symbols
