use std::cell::Cell;
#[derive(Clone,Copy)]
struct Context{active:u64,compute:u64,comparison:u64}
thread_local!{static OLD_ACTIVE:Cell<u64>=const{Cell::new(0)};static OLD_LIMITS:Cell<(u64,u64)>=const{Cell::new((u64::MAX,u64::MAX))};static CONTEXT:Cell<Context>=const{Cell::new(Context{active:0,compute:u64::MAX,comparison:u64::MAX})};}
#[repr(C)]
pub struct Account{identity:u64,compute:u64,comparison:u64,limit_compute:u64,limit_comparison:u64}
fn debit(a:&mut Account,n:u64,c:Context)->u64{if c.active!=0&&c.active!=a.identity{return 1;}let Some(next)=a.compute.checked_add(n)else{return 2;};if next>a.limit_compute.min(c.compute)||a.comparison>a.limit_comparison||a.comparison>c.comparison{return 3;}a.compute=next;0}
#[unsafe(no_mangle)]
pub extern "C" fn separate_fields(a:&mut Account,n:u64)->u64{let active=OLD_ACTIVE.with(Cell::get);let(compute,comparison)=OLD_LIMITS.with(Cell::get);debit(a,n,Context{active,compute,comparison})}
#[unsafe(no_mangle)]
pub extern "C" fn shared_context(a:&mut Account,n:u64)->u64{let c=CONTEXT.with(Cell::get);debit(a,n,c)}
#[unsafe(no_mangle)]
pub extern "C" fn set_context(active:u64,compute:u64,comparison:u64){OLD_ACTIVE.with(|v|v.set(active));OLD_LIMITS.with(|v|v.set((compute,comparison)));CONTEXT.with(|v|v.set(Context{active,compute,comparison}));}
