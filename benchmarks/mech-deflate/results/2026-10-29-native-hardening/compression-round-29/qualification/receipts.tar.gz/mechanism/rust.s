	.build_version macos, 11, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_separate_fields
	.p2align	2
_separate_fields:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	mov	x8, x0
Lloh0:
	adrp	x0, __RNvNCNKNvCs9VsNjlPUTq_7context10OLD_ACTIVE0s_023___RUST_STD_INTERNAL_VAL@TLVPPAGE
Lloh1:
	ldr	x0, [x0, __RNvNCNKNvCs9VsNjlPUTq_7context10OLD_ACTIVE0s_023___RUST_STD_INTERNAL_VAL@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
Lloh2:
	adrp	x0, __RNvNCNKNvCs9VsNjlPUTq_7context10OLD_LIMITS0s_023___RUST_STD_INTERNAL_VAL@TLVPPAGE
Lloh3:
	ldr	x0, [x0, __RNvNCNKNvCs9VsNjlPUTq_7context10OLD_LIMITS0s_023___RUST_STD_INTERNAL_VAL@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x8]
	cmp	x9, #0
	ccmp	x9, x10, #4, ne
	b.ne	LBB0_5
	ldr	x9, [x8, #8]
	adds	x9, x9, x1
	b.hs	LBB0_8
	ldr	x10, [x0]
	ldr	x11, [x8, #24]
	cmp	x10, x11
	csel	x10, x10, x11, lo
	cmp	x9, x10
	b.hi	LBB0_4
	ldr	x10, [x0, #8]
	ldr	x11, [x8, #16]
	ldr	x12, [x8, #32]
	cmp	x11, x10
	ccmp	x11, x12, #2, ls
	b.ls	LBB0_7
LBB0_4:
	mov	w0, #3
	b	LBB0_6
LBB0_5:
	mov	w0, #1
LBB0_6:
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
LBB0_7:
	.cfi_restore_state
	mov	x0, #0
	str	x9, [x8, #8]
	b	LBB0_6
LBB0_8:
	mov	w0, #2
	b	LBB0_6
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpLdr	Lloh0, Lloh1
	.cfi_endproc

	.globl	_set_context
	.p2align	2
_set_context:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh4:
	adrp	x0, __RNvNCNKNvCs9VsNjlPUTq_7context10OLD_ACTIVE0s_023___RUST_STD_INTERNAL_VAL@TLVPPAGE
Lloh5:
	ldr	x0, [x0, __RNvNCNKNvCs9VsNjlPUTq_7context10OLD_ACTIVE0s_023___RUST_STD_INTERNAL_VAL@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	str	x8, [x0]
Lloh6:
	adrp	x0, __RNvNCNKNvCs9VsNjlPUTq_7context10OLD_LIMITS0s_023___RUST_STD_INTERNAL_VAL@TLVPPAGE
Lloh7:
	ldr	x0, [x0, __RNvNCNKNvCs9VsNjlPUTq_7context10OLD_LIMITS0s_023___RUST_STD_INTERNAL_VAL@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	stp	x1, x2, [x0]
Lloh8:
	adrp	x0, __RNvNCNKNvCs9VsNjlPUTq_7context7CONTEXT0s_023___RUST_STD_INTERNAL_VAL@TLVPPAGE
Lloh9:
	ldr	x0, [x0, __RNvNCNKNvCs9VsNjlPUTq_7context7CONTEXT0s_023___RUST_STD_INTERNAL_VAL@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	stp	x8, x1, [x0]
	str	x2, [x0, #16]
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh4, Lloh5
	.cfi_endproc

	.globl	_shared_context
	.p2align	2
_shared_context:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	mov	x8, x0
Lloh10:
	adrp	x0, __RNvNCNKNvCs9VsNjlPUTq_7context7CONTEXT0s_023___RUST_STD_INTERNAL_VAL@TLVPPAGE
Lloh11:
	ldr	x0, [x0, __RNvNCNKNvCs9VsNjlPUTq_7context7CONTEXT0s_023___RUST_STD_INTERNAL_VAL@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	ldr	x10, [x8]
	cmp	x9, #0
	ccmp	x9, x10, #4, ne
	b.ne	LBB2_4
	ldr	x9, [x8, #8]
	adds	x9, x9, x1
	b.hs	LBB2_9
	ldr	x10, [x0, #8]
	ldr	x11, [x8, #24]
	cmp	x10, x11
	csel	x10, x10, x11, lo
	cmp	x9, x10
	b.ls	LBB2_6
	mov	w0, #3
	b	LBB2_5
LBB2_4:
	mov	w0, #1
LBB2_5:
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
LBB2_6:
	.cfi_restore_state
	mov	x11, x0
	ldr	x10, [x8, #16]
	ldr	x12, [x8, #32]
	mov	w0, #3
	cmp	x10, x12
	b.hi	LBB2_5
	ldr	x11, [x11, #16]
	cmp	x10, x11
	b.hi	LBB2_5
	mov	x0, #0
	str	x9, [x8, #8]
	b	LBB2_5
LBB2_9:
	mov	w0, #2
	b	LBB2_5
	.loh AdrpLdr	Lloh10, Lloh11
	.cfi_endproc

.tbss __RNvNCNKNvCs9VsNjlPUTq_7context10OLD_ACTIVE0s_023___RUST_STD_INTERNAL_VAL$tlv$init, 8, 3

	.section	__DATA,__thread_vars,thread_local_variables
__RNvNCNKNvCs9VsNjlPUTq_7context10OLD_ACTIVE0s_023___RUST_STD_INTERNAL_VAL:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	__RNvNCNKNvCs9VsNjlPUTq_7context10OLD_ACTIVE0s_023___RUST_STD_INTERNAL_VAL$tlv$init

	.section	__DATA,__thread_data,thread_local_regular
	.p2align	3, 0x0
__RNvNCNKNvCs9VsNjlPUTq_7context10OLD_LIMITS0s_023___RUST_STD_INTERNAL_VAL$tlv$init:
	.space	16,255

	.section	__DATA,__thread_vars,thread_local_variables
__RNvNCNKNvCs9VsNjlPUTq_7context10OLD_LIMITS0s_023___RUST_STD_INTERNAL_VAL:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	__RNvNCNKNvCs9VsNjlPUTq_7context10OLD_LIMITS0s_023___RUST_STD_INTERNAL_VAL$tlv$init

	.section	__DATA,__thread_data,thread_local_regular
	.p2align	3, 0x0
__RNvNCNKNvCs9VsNjlPUTq_7context7CONTEXT0s_023___RUST_STD_INTERNAL_VAL$tlv$init:
	.ascii	"\000\000\000\000\000\000\000\000\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"

	.section	__DATA,__thread_vars,thread_local_variables
__RNvNCNKNvCs9VsNjlPUTq_7context7CONTEXT0s_023___RUST_STD_INTERNAL_VAL:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	__RNvNCNKNvCs9VsNjlPUTq_7context7CONTEXT0s_023___RUST_STD_INTERNAL_VAL$tlv$init

.subsections_via_symbols
