/private/tmp/mech-ownership-round29-20261029/primary/current:
(__TEXT,__text) section
__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge:
10151cbcc:	ff 03 02 d1	sub	sp, sp, #0x80
10151cbd0:	f8 5f 04 a9	stp	x24, x23, [sp, #0x40]
10151cbd4:	f6 57 05 a9	stp	x22, x21, [sp, #0x50]
10151cbd8:	f4 4f 06 a9	stp	x20, x19, [sp, #0x60]
10151cbdc:	fd 7b 07 a9	stp	x29, x30, [sp, #0x70]
10151cbe0:	fd c3 01 91	add	x29, sp, #0x70
10151cbe4:	f4 03 02 aa	mov	x20, x2
10151cbe8:	f5 03 01 aa	mov	x21, x1
10151cbec:	e9 03 00 aa	mov	x9, x0
10151cbf0:	f3 03 08 aa	mov	x19, x8
10151cbf4:	08 8c 41 f8	ldr	x8, [x0, #0x18]!
10151cbf8:	a8 02 00 b4	cbz	x8, 0x10151cc4c
10151cbfc:	22 09 40 f9	ldr	x2, [x9, #0x10]
10151cc00:	e8 23 00 91	add	x8, sp, #0x8
10151cc04:	e1 03 03 aa	mov	x1, x3
10151cc08:	46 c1 37 94	bl	__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit
10151cc0c:	e8 23 40 39	ldrb	w8, [sp, #0x8]
10151cc10:	1f 21 00 71	cmp	w8, #0x8
10151cc14:	e0 06 00 54	b.eq	0x10151ccf0
10151cc18:	eb 27 40 39	ldrb	w11, [sp, #0x9]
10151cc1c:	ea 27 41 a9	ldp	x10, x9, [sp, #0x10]
10151cc20:	1f 19 00 71	cmp	w8, #0x6
10151cc24:	60 09 46 7a	ccmp	w11, #0x6, #0x0, eq
10151cc28:	a0 03 00 54	b.eq	0x10151cc9c
10151cc2c:	ec 1f 40 79	ldrh	w12, [sp, #0xe]
10151cc30:	ed a3 40 b8	ldur	w13, [sp, #0xa]
10151cc34:	ac 81 0c aa	orr	x12, x13, x12, lsl #32
10151cc38:	2d fd 60 d3	lsr	x13, x9, #32
10151cc3c:	e0 03 c2 3c	ldur	q0, [sp, #0x20]
10151cc40:	e0 0f 80 3d	str	q0, [sp, #0x30]
10151cc44:	ee 00 80 52	mov	w14, #0x7
10151cc48:	1c 00 00 14	b	0x10151ccb8
10151cc4c:	f6 03 03 aa	mov	x22, x3
10151cc50:	f7 03 09 aa	mov	x23, x9
10151cc54:	3a bf 37 94	bl	__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope
10151cc58:	c0 00 00 36	tbz	w0, #0x0, 0x10151cc70
10151cc5c:	e8 00 80 52	mov	w8, #0x7
10151cc60:	68 02 00 39	strb	w8, [x19]
10151cc64:	7f 06 00 f9	str	xzr, [x19, #0x8]
10151cc68:	7f 1e 00 b9	str	wzr, [x19, #0x1c]
10151cc6c:	1e 00 00 14	b	0x10151cce4
10151cc70:	ea a2 40 a9	ldp	x10, x8, [x23, #0x8]
10151cc74:	4a 01 16 ab	adds	x10, x10, x22
10151cc78:	c2 04 00 54	b.hs	0x10151cd10
10151cc7c:	5f 01 08 eb	cmp	x10, x8
10151cc80:	69 03 00 54	b.ls	0x10151ccec
10151cc84:	c9 00 80 52	mov	w9, #0x6
10151cc88:	69 02 00 39	strb	w9, [x19]
10151cc8c:	6a 06 00 f9	str	x10, [x19, #0x8]
10151cc90:	68 0a 00 f9	str	x8, [x19, #0x10]
10151cc94:	75 52 03 29	stp	w21, w20, [x19, #0x18]
10151cc98:	18 00 00 14	b	0x10151ccf8
10151cc9c:	48 1d 00 12	and	w8, w10, #0xff
10151cca0:	4b fd 48 d3	lsr	x11, x10, #8
10151cca4:	4c fd 50 d3	lsr	x12, x10, #16
10151cca8:	ce 00 80 52	mov	w14, #0x6
10151ccac:	ea 03 09 aa	mov	x10, x9
10151ccb0:	e9 03 15 aa	mov	x9, x21
10151ccb4:	ed 03 14 aa	mov	x13, x20
10151ccb8:	6e 02 00 39	strb	w14, [x19]
10151ccbc:	6b 1d 78 d3	ubfiz	x11, x11, #8, #8
10151ccc0:	6b 41 0c aa	orr	x11, x11, x12, lsl #16
10151ccc4:	e8 03 08 2a	mov	w8, w8
10151ccc8:	68 01 08 aa	orr	x8, x11, x8
10151cccc:	68 aa 00 a9	stp	x8, x10, [x19, #0x8]
10151ccd0:	e8 03 09 2a	mov	w8, w9
10151ccd4:	08 81 0d aa	orr	x8, x8, x13, lsl #32
10151ccd8:	68 0e 00 f9	str	x8, [x19, #0x18]
10151ccdc:	e0 0f c0 3d	ldr	q0, [sp, #0x30]
10151cce0:	60 0a 80 3d	str	q0, [x19, #0x20]
10151cce4:	75 52 06 29	stp	w21, w20, [x19, #0x30]
10151cce8:	04 00 00 14	b	0x10151ccf8
10151ccec:	ea 06 00 f9	str	x10, [x23, #0x8]
10151ccf0:	c8 01 80 52	mov	w8, #0xe
10151ccf4:	68 02 00 39	strb	w8, [x19]
10151ccf8:	fd 7b 47 a9	ldp	x29, x30, [sp, #0x70]
10151ccfc:	f4 4f 46 a9	ldp	x20, x19, [sp, #0x60]
10151cd00:	f6 57 45 a9	ldp	x22, x21, [sp, #0x50]
10151cd04:	f8 5f 44 a9	ldp	x24, x23, [sp, #0x40]
10151cd08:	ff 03 02 91	add	sp, sp, #0x80
10151cd0c:	c0 03 5f d6	ret
10151cd10:	c9 00 80 52	mov	w9, #0x6
10151cd14:	69 02 00 39	strb	w9, [x19]
10151cd18:	09 00 80 92	mov	x9, #-0x1
10151cd1c:	69 06 00 f9	str	x9, [x19, #0x8]
10151cd20:	dc ff ff 17	b	0x10151cc90
