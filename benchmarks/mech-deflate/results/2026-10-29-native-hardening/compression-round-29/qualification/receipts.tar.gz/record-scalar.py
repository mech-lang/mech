from pathlib import Path
import datetime,hashlib,json,subprocess,sys,tarfile
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'primary'
result=subprocess.run([sys.executable,str(p/'scalar-controls.py')])
o=w/'benchmarks/mech-deflate/results/2026-10-29-native-hardening/compression-round-29/scalar';o.mkdir()
files=[f for f in p.iterdir() if f.is_file() and (f.name.startswith('scalar-') or f.name.startswith('frame-')) and f.suffix in ['.json','.py','.stdout','.stderr','.log']]
passed=False
if (p/'scalar-results.json').exists():
 v=json.loads((p/'scalar-results.json').read_text());(o/'results.json').write_text(json.dumps(v,indent=2)+'\n');passed=result.returncode==0 and v['direct_controls_pass'] and v['scalar_loop_allocation_slope_zero']
with tarfile.open(o/'receipts.tar.gz','w:gz') as tar:
 for f in sorted(files):tar.add(f,arcname=str(f.relative_to(r)),recursive=False)
(o/'manifest.json').write_text(json.dumps({'schema':'mech.optimization.receipts.v1','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'exit':result.returncode,'passed':passed,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':[{'path':str(f.relative_to(r)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in sorted(files)]},indent=2)+'\n')
subprocess.run(['git','add',str(o)],cwd=w,check=True)
subprocess.run(['git','commit','-m','Record protected scalar controls after shared work context'],cwd=w,check=True)
assert passed,'Scalar qualification failed; all raw observations committed'
