/private/tmp/mech-ownership-round29-20261029/primary/current:
(__TEXT,__text) section
__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits:
1023259c4:	ff 43 02 d1	sub	sp, sp, #0x90
1023259c8:	fa 67 04 a9	stp	x26, x25, [sp, #0x40]
1023259cc:	f8 5f 05 a9	stp	x24, x23, [sp, #0x50]
1023259d0:	f6 57 06 a9	stp	x22, x21, [sp, #0x60]
1023259d4:	f4 4f 07 a9	stp	x20, x19, [sp, #0x70]
1023259d8:	fd 7b 08 a9	stp	x29, x30, [sp, #0x80]
1023259dc:	fd 03 02 91	add	x29, sp, #0x80
1023259e0:	88 00 40 b9	ldr	w8, [x4]
1023259e4:	89 a8 40 a9	ldp	x9, x10, [x4, #0x8]
1023259e8:	2b b0 44 a9	ldp	x11, x12, [x1, #0x48]
1023259ec:	3f 01 0b eb	cmp	x9, x11
1023259f0:	29 31 8b 9a	csel	x9, x9, x11, lo
1023259f4:	5f 01 0c eb	cmp	x10, x12
1023259f8:	4a 31 8c 9a	csel	x10, x10, x12, lo
1023259fc:	1f 01 00 71	cmp	w8, #0x0
102325a00:	28 11 8b 9a	csel	x8, x9, x11, ne
102325a04:	4c 11 8c 9a	csel	x12, x10, x12, ne
102325a08:	29 10 40 f9	ldr	x9, [x1, #0x20]
102325a0c:	38 01 02 ab	adds	x24, x9, x2
102325a10:	82 0b 00 54	b.hs	0x102325b80
102325a14:	29 14 40 f9	ldr	x9, [x1, #0x28]
102325a18:	39 01 03 ab	adds	x25, x9, x3
102325a1c:	22 0b 00 54	b.hs	0x102325b80
102325a20:	29 18 40 f9	ldr	x9, [x1, #0x30]
102325a24:	29 01 18 ab	adds	x9, x9, x24
102325a28:	c2 0a 00 54	b.hs	0x102325b80
102325a2c:	2a 1c 40 f9	ldr	x10, [x1, #0x38]
102325a30:	4d 01 19 ab	adds	x13, x10, x25
102325a34:	62 0a 00 54	b.hs	0x102325b80
102325a38:	3f 01 08 eb	cmp	x9, x8
102325a3c:	89 00 00 54	b.ls	0x102325a4c
102325a40:	cb 00 80 52	mov	w11, #0x6
102325a44:	ca 00 80 52	mov	w10, #0x6
102325a48:	07 00 00 14	b	0x102325a64
102325a4c:	bf 01 0c eb	cmp	x13, x12
102325a50:	29 02 00 54	b.ls	0x102325a94
102325a54:	ca 00 80 52	mov	w10, #0x6
102325a58:	ab 00 80 52	mov	w11, #0x5
102325a5c:	e8 03 0c aa	mov	x8, x12
102325a60:	e9 03 0d aa	mov	x9, x13
102325a64:	0a 00 00 39	strb	w10, [x0]
102325a68:	0b 04 00 39	strb	w11, [x0, #0x1]
102325a6c:	2a 00 80 52	mov	w10, #0x1
102325a70:	0a 08 00 39	strb	w10, [x0, #0x2]
102325a74:	09 a0 00 a9	stp	x9, x8, [x0, #0x8]
102325a78:	fd 7b 48 a9	ldp	x29, x30, [sp, #0x80]
102325a7c:	f4 4f 47 a9	ldp	x20, x19, [sp, #0x70]
102325a80:	f6 57 46 a9	ldp	x22, x21, [sp, #0x60]
102325a84:	f8 5f 45 a9	ldp	x24, x23, [sp, #0x50]
102325a88:	fa 67 44 a9	ldp	x26, x25, [sp, #0x40]
102325a8c:	ff 43 02 91	add	sp, sp, #0x90
102325a90:	c0 03 5f d6	ret
102325a94:	28 2c 40 f9	ldr	x8, [x1, #0x58]
102325a98:	c8 03 00 b4	cbz	x8, 0x102325b10
102325a9c:	fa 03 01 aa	mov	x26, x1
102325aa0:	f7 03 00 aa	mov	x23, x0
102325aa4:	00 41 00 91	add	x0, x8, #0x10
102325aa8:	f5 03 03 aa	mov	x21, x3
102325aac:	f6 03 02 aa	mov	x22, x2
102325ab0:	cd 3a 00 94	bl	__RNvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workers11lock_escrow
102325ab4:	f3 03 00 aa	mov	x19, x0
102325ab8:	f4 03 01 aa	mov	x20, x1
102325abc:	e0 63 00 91	add	x0, sp, #0x18
102325ac0:	61 42 00 91	add	x1, x19, #0x10
102325ac4:	e2 03 16 aa	mov	x2, x22
102325ac8:	e3 03 15 aa	mov	x3, x21
102325acc:	ec 9f ff 97	bl	__RNvMs0_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workers7creditsNtB7_6Escrow11direct_next
102325ad0:	f5 63 40 39	ldrb	w21, [sp, #0x18]
102325ad4:	bf 22 00 71	cmp	w21, #0x8
102325ad8:	41 02 00 54	b.ne	0x102325b20
102325adc:	68 e2 11 91	add	x8, x19, #0x478
102325ae0:	e0 03 c2 3c	ldur	q0, [sp, #0x20]
102325ae4:	00 01 80 3d	str	q0, [x8]
102325ae8:	d4 00 00 37	tbnz	w20, #0x0, 0x102325b00
102325aec:	a8 bf 00 d0	adrp	x8, 6134 ; 0x103b1b000
102325af0:	08 a1 2f 91	add	x8, x8, #0xbe8
102325af4:	08 01 40 f9	ldr	x8, [x8]
102325af8:	1f f9 40 f2	tst	x8, #0x7fffffffffffffff
102325afc:	61 04 00 54	b.ne	0x102325b88
102325b00:	60 02 40 f9	ldr	x0, [x19]
102325b04:	eb 77 29 94	bl	__RNvMNtNtNtNtNtCsgirOGyZpP7g_3std3sys3pal4unix4sync5mutexNtB2_5Mutex6unlock
102325b08:	e0 03 17 aa	mov	x0, x23
102325b0c:	e1 03 1a aa	mov	x1, x26
102325b10:	38 64 02 a9	stp	x24, x25, [x1, #0x20]
102325b14:	08 01 80 52	mov	w8, #0x8
102325b18:	08 00 00 39	strb	w8, [x0]
102325b1c:	d7 ff ff 17	b	0x102325a78
102325b20:	e8 93 41 b8	ldur	w8, [sp, #0x19]
102325b24:	e8 13 00 b9	str	w8, [sp, #0x10]
102325b28:	e8 1f 40 b9	ldr	w8, [sp, #0x1c]
102325b2c:	e8 33 01 b8	stur	w8, [sp, #0x13]
102325b30:	f6 63 42 a9	ldp	x22, x24, [sp, #0x20]
102325b34:	e0 03 c3 3c	ldur	q0, [sp, #0x30]
102325b38:	e0 03 80 3d	str	q0, [sp]
102325b3c:	d4 00 00 37	tbnz	w20, #0x0, 0x102325b54
102325b40:	a8 bf 00 d0	adrp	x8, 6134 ; 0x103b1b000
102325b44:	08 a1 2f 91	add	x8, x8, #0xbe8
102325b48:	08 01 40 f9	ldr	x8, [x8]
102325b4c:	1f f9 40 f2	tst	x8, #0x7fffffffffffffff
102325b50:	61 02 00 54	b.ne	0x102325b9c
102325b54:	60 02 40 f9	ldr	x0, [x19]
102325b58:	d6 77 29 94	bl	__RNvMNtNtNtNtNtCsgirOGyZpP7g_3std3sys3pal4unix4sync5mutexNtB2_5Mutex6unlock
102325b5c:	f5 02 00 39	strb	w21, [x23]
102325b60:	e8 13 40 b9	ldr	w8, [sp, #0x10]
102325b64:	e8 12 00 b8	stur	w8, [x23, #0x1]
102325b68:	e8 33 41 b8	ldur	w8, [sp, #0x13]
102325b6c:	e8 06 00 b9	str	w8, [x23, #0x4]
102325b70:	f6 e2 00 a9	stp	x22, x24, [x23, #0x8]
102325b74:	e0 03 c0 3d	ldr	q0, [sp]
102325b78:	e0 82 81 3c	stur	q0, [x23, #0x18]
102325b7c:	bf ff ff 17	b	0x102325a78
102325b80:	4a 00 80 52	mov	w10, #0x2
102325b84:	b8 ff ff 17	b	0x102325a64
102325b88:	0d fa 2a 94	bl	__RNvNtNtCsgirOGyZpP7g_3std9panicking11panic_count17is_zero_slow_path
102325b8c:	a0 fb 07 37	tbnz	w0, #0x0, 0x102325b00
102325b90:	28 00 80 52	mov	w8, #0x1
102325b94:	68 22 00 39	strb	w8, [x19, #0x8]
102325b98:	da ff ff 17	b	0x102325b00
102325b9c:	08 fa 2a 94	bl	__RNvNtNtCsgirOGyZpP7g_3std9panicking11panic_count17is_zero_slow_path
102325ba0:	a0 fd 07 37	tbnz	w0, #0x0, 0x102325b54
102325ba4:	28 00 80 52	mov	w8, #0x1
102325ba8:	68 22 00 39	strb	w8, [x19, #0x8]
102325bac:	ea ff ff 17	b	0x102325b54
102325bb0:	f5 03 00 aa	mov	x21, x0
102325bb4:	81 02 00 12	and	w1, w20, #0x1
102325bb8:	e0 03 13 aa	mov	x0, x19
102325bbc:	cd 05 ff 97	bl	__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtNtCsgirOGyZpP7g_3std4sync6poison5mutex10MutexGuardINtNtB4_6option6OptionINtNtCsgKscDXrlV49_5alloc4sync3ArcNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn14TurnMemoryPlanEEEEB2B_
102325bc0:	e0 03 15 aa	mov	x0, x21
102325bc4:	82 00 2b 94	bl	0x102de5dcc ; symbol stub for: __Unwind_Resume
102325bc8:	88 fb 2a 94	bl	__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup
