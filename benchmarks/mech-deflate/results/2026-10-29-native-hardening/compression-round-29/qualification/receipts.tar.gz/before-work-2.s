/private/tmp/mech-ownership-round29-20261029/primary/before:
(__TEXT,__text) section
__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22charge_control_account:
102313268:	ff 43 02 d1	sub	sp, sp, #0x90
10231326c:	fa 67 04 a9	stp	x26, x25, [sp, #0x40]
102313270:	f8 5f 05 a9	stp	x24, x23, [sp, #0x50]
102313274:	f6 57 06 a9	stp	x22, x21, [sp, #0x60]
102313278:	f4 4f 07 a9	stp	x20, x19, [sp, #0x70]
10231327c:	fd 7b 08 a9	stp	x29, x30, [sp, #0x80]
102313280:	fd 03 02 91	add	x29, sp, #0x80
102313284:	f3 03 00 aa	mov	x19, x0
102313288:	a0 bf 00 90	adrp	x0, 6132 ; 0x103b07000
10231328c:	00 e0 13 91	add	x0, x0, #0x4f8
102313290:	08 00 40 f9	ldr	x8, [x0]
102313294:	00 01 3f d6	blr	x8
102313298:	08 00 40 f9	ldr	x8, [x0]
10231329c:	1f 09 00 f1	cmp	x8, #0x2
1023132a0:	00 0d 00 54	b.eq	0x102313440
1023132a4:	09 a8 40 a9	ldp	x9, x10, [x0, #0x8]
1023132a8:	2b b0 44 a9	ldp	x11, x12, [x1, #0x48]
1023132ac:	3f 01 0b eb	cmp	x9, x11
1023132b0:	29 31 8b 9a	csel	x9, x9, x11, lo
1023132b4:	5f 01 0c eb	cmp	x10, x12
1023132b8:	4a 31 8c 9a	csel	x10, x10, x12, lo
1023132bc:	1f 01 00 72	tst	w8, #0x1
1023132c0:	28 11 8b 9a	csel	x8, x9, x11, ne
1023132c4:	4c 11 8c 9a	csel	x12, x10, x12, ne
1023132c8:	29 10 40 f9	ldr	x9, [x1, #0x20]
1023132cc:	38 01 02 ab	adds	x24, x9, x2
1023132d0:	42 0b 00 54	b.hs	0x102313438
1023132d4:	29 14 40 f9	ldr	x9, [x1, #0x28]
1023132d8:	39 01 03 ab	adds	x25, x9, x3
1023132dc:	e2 0a 00 54	b.hs	0x102313438
1023132e0:	29 18 40 f9	ldr	x9, [x1, #0x30]
1023132e4:	29 01 18 ab	adds	x9, x9, x24
1023132e8:	82 0a 00 54	b.hs	0x102313438
1023132ec:	2a 1c 40 f9	ldr	x10, [x1, #0x38]
1023132f0:	4d 01 19 ab	adds	x13, x10, x25
1023132f4:	22 0a 00 54	b.hs	0x102313438
1023132f8:	3f 01 08 eb	cmp	x9, x8
1023132fc:	89 00 00 54	b.ls	0x10231330c
102313300:	cb 00 80 52	mov	w11, #0x6
102313304:	ca 00 80 52	mov	w10, #0x6
102313308:	07 00 00 14	b	0x102313324
10231330c:	bf 01 0c eb	cmp	x13, x12
102313310:	29 02 00 54	b.ls	0x102313354
102313314:	ca 00 80 52	mov	w10, #0x6
102313318:	ab 00 80 52	mov	w11, #0x5
10231331c:	e8 03 0c aa	mov	x8, x12
102313320:	e9 03 0d aa	mov	x9, x13
102313324:	6a 02 00 39	strb	w10, [x19]
102313328:	6b 06 00 39	strb	w11, [x19, #0x1]
10231332c:	2a 00 80 52	mov	w10, #0x1
102313330:	6a 0a 00 39	strb	w10, [x19, #0x2]
102313334:	69 a2 00 a9	stp	x9, x8, [x19, #0x8]
102313338:	fd 7b 48 a9	ldp	x29, x30, [sp, #0x80]
10231333c:	f4 4f 47 a9	ldp	x20, x19, [sp, #0x70]
102313340:	f6 57 46 a9	ldp	x22, x21, [sp, #0x60]
102313344:	f8 5f 45 a9	ldp	x24, x23, [sp, #0x50]
102313348:	fa 67 44 a9	ldp	x26, x25, [sp, #0x40]
10231334c:	ff 43 02 91	add	sp, sp, #0x90
102313350:	c0 03 5f d6	ret
102313354:	28 2c 40 f9	ldr	x8, [x1, #0x58]
102313358:	88 03 00 b4	cbz	x8, 0x1023133c8
10231335c:	fa 03 01 aa	mov	x26, x1
102313360:	00 41 00 91	add	x0, x8, #0x10
102313364:	f6 03 03 aa	mov	x22, x3
102313368:	f7 03 02 aa	mov	x23, x2
10231336c:	81 40 00 94	bl	__RNvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workers11lock_escrow
102313370:	f4 03 00 aa	mov	x20, x0
102313374:	f5 03 01 aa	mov	x21, x1
102313378:	e0 63 00 91	add	x0, sp, #0x18
10231337c:	81 42 00 91	add	x1, x20, #0x10
102313380:	e2 03 17 aa	mov	x2, x23
102313384:	e3 03 16 aa	mov	x3, x22
102313388:	9d ae ff 97	bl	__RNvMs0_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workers7creditsNtB7_6Escrow11direct_next
10231338c:	f6 63 40 39	ldrb	w22, [sp, #0x18]
102313390:	df 22 00 71	cmp	w22, #0x8
102313394:	21 02 00 54	b.ne	0x1023133d8
102313398:	88 e2 11 91	add	x8, x20, #0x478
10231339c:	e0 03 c2 3c	ldur	q0, [sp, #0x20]
1023133a0:	00 01 80 3d	str	q0, [x8]
1023133a4:	d5 00 00 37	tbnz	w21, #0x0, 0x1023133bc
1023133a8:	a8 bf 00 90	adrp	x8, 6132 ; 0x103b07000
1023133ac:	08 a1 30 91	add	x8, x8, #0xc28
1023133b0:	08 01 40 f9	ldr	x8, [x8]
1023133b4:	1f f9 40 f2	tst	x8, #0x7fffffffffffffff
1023133b8:	a1 04 00 54	b.ne	0x10231344c
1023133bc:	80 02 40 f9	ldr	x0, [x20]
1023133c0:	79 9a 29 94	bl	__RNvMNtNtNtNtNtCsgirOGyZpP7g_3std3sys3pal4unix4sync5mutexNtB2_5Mutex6unlock
1023133c4:	e1 03 1a aa	mov	x1, x26
1023133c8:	38 64 02 a9	stp	x24, x25, [x1, #0x20]
1023133cc:	08 01 80 52	mov	w8, #0x8
1023133d0:	68 02 00 39	strb	w8, [x19]
1023133d4:	d9 ff ff 17	b	0x102313338
1023133d8:	e8 93 41 b8	ldur	w8, [sp, #0x19]
1023133dc:	e8 13 00 b9	str	w8, [sp, #0x10]
1023133e0:	e8 1f 40 b9	ldr	w8, [sp, #0x1c]
1023133e4:	e8 33 01 b8	stur	w8, [sp, #0x13]
1023133e8:	f7 63 42 a9	ldp	x23, x24, [sp, #0x20]
1023133ec:	e0 03 c3 3c	ldur	q0, [sp, #0x30]
1023133f0:	e0 03 80 3d	str	q0, [sp]
1023133f4:	d5 00 00 37	tbnz	w21, #0x0, 0x10231340c
1023133f8:	a8 bf 00 90	adrp	x8, 6132 ; 0x103b07000
1023133fc:	08 a1 30 91	add	x8, x8, #0xc28
102313400:	08 01 40 f9	ldr	x8, [x8]
102313404:	1f f9 40 f2	tst	x8, #0x7fffffffffffffff
102313408:	c1 02 00 54	b.ne	0x102313460
10231340c:	80 02 40 f9	ldr	x0, [x20]
102313410:	65 9a 29 94	bl	__RNvMNtNtNtNtNtCsgirOGyZpP7g_3std3sys3pal4unix4sync5mutexNtB2_5Mutex6unlock
102313414:	76 02 00 39	strb	w22, [x19]
102313418:	e8 13 40 b9	ldr	w8, [sp, #0x10]
10231341c:	68 12 00 b8	stur	w8, [x19, #0x1]
102313420:	e8 33 41 b8	ldur	w8, [sp, #0x13]
102313424:	68 06 00 b9	str	w8, [x19, #0x4]
102313428:	77 e2 00 a9	stp	x23, x24, [x19, #0x8]
10231342c:	e0 03 c0 3d	ldr	q0, [sp]
102313430:	60 82 81 3c	stur	q0, [x19, #0x18]
102313434:	c1 ff ff 17	b	0x102313338
102313438:	4a 00 80 52	mov	w10, #0x2
10231343c:	ba ff ff 17	b	0x102313324
102313440:	e0 bd 00 90	adrp	x0, 6076 ; 0x103acf000
102313444:	00 80 39 91	add	x0, x0, #0xe60
102313448:	34 18 2b 94	bl	__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error
10231344c:	8e 18 2b 94	bl	__RNvNtNtCsgirOGyZpP7g_3std9panicking11panic_count17is_zero_slow_path
102313450:	60 fb 07 37	tbnz	w0, #0x0, 0x1023133bc
102313454:	28 00 80 52	mov	w8, #0x1
102313458:	88 22 00 39	strb	w8, [x20, #0x8]
10231345c:	d8 ff ff 17	b	0x1023133bc
102313460:	89 18 2b 94	bl	__RNvNtNtCsgirOGyZpP7g_3std9panicking11panic_count17is_zero_slow_path
102313464:	40 fd 07 37	tbnz	w0, #0x0, 0x10231340c
102313468:	28 00 80 52	mov	w8, #0x1
10231346c:	88 22 00 39	strb	w8, [x20, #0x8]
102313470:	e7 ff ff 17	b	0x10231340c
102313474:	f3 03 00 aa	mov	x19, x0
102313478:	a1 02 00 12	and	w1, w21, #0x1
10231347c:	e0 03 14 aa	mov	x0, x20
102313480:	d6 13 ff 97	bl	__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtNtCsgirOGyZpP7g_3std4sync6poison5mutex10MutexGuardINtNtB4_6option6OptionINtNtCsgKscDXrlV49_5alloc4sync3ArcNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn14TurnMemoryPlanEEEEB2B_
102313484:	e0 03 13 aa	mov	x0, x19
102313488:	03 1f 2b 94	bl	0x102ddb094 ; symbol stub for: __Unwind_Resume
10231348c:	09 1a 2b 94	bl	__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup
