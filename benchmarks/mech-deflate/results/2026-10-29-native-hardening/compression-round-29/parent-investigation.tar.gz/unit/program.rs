//! Canonical managed-program owners.
#[cfg(feature = "canonical-native-program-runtime")]
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/program/prepare/mod.rs"]
pub(in crate::native_artifact) mod prepare;
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/program/protocol/mod.rs"]
pub(in crate::native_artifact) mod protocol;

#[cfg(feature = "canonical-native-program")]
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/program/application.rs"]
pub(in crate::native_artifact) mod application;
#[cfg(feature = "canonical-native-program")]
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/program/compiler.rs"]
pub(in crate::native_artifact) mod compiler;
#[cfg(feature = "canonical-native-program-runtime")]
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/program/image/mod.rs"]
pub(in crate::native_artifact) mod image;
#[cfg(feature = "canonical-native-program-runtime")]
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/program/limits.rs"]
pub(in crate::native_artifact) mod limits;
#[cfg(feature = "canonical-native-program-runtime")]
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/program/linked.rs"]
pub(in crate::native_artifact) mod linked;
#[cfg(feature = "canonical-native-program-runtime")]
#[path = "/private/tmp/mech-ownership-round29-20261029/unit/runtime.rs"]
pub(in crate::native_artifact) mod runtime;

#[cfg(feature = "canonical-native")]
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/program/codegen/mod.rs"]
pub(in crate::native_artifact) mod codegen;
