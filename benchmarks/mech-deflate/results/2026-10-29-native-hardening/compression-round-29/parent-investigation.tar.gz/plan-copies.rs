use mech_engine::native_artifact::{lower_native_program_artifact_with_definition_table_limit,NativeIterationAction as A,NativeMatchAction as S,NativeControlLoop as L};
use std::collections::{BTreeMap,BTreeSet};
fn main(){
 let root=std::path::Path::new("/private/tmp/mech-ownership-round29-20261029");
 let rows:serde_json::Value=serde_json::from_slice(&std::fs::read(root.join("census/copies.json")).unwrap()).unwrap();
 let artifact=mech_engine::decode_program_artifact_bytecode_v1(&std::fs::read("/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc").unwrap()).unwrap();
 let p=lower_native_program_artifact_with_definition_table_limit(&artifact,&mech_stdlib::source_catalog(),u64::MAX).unwrap();
 let facts=p.facts();let proofs=p.unsigned_buffer_calls();let mut handles=BTreeMap::new();
 for b in p.blocks(){match b.action(){A::LibraryCall{operands,output,..}=>{handles.extend(operands.iter().map(|v|(v.get(),*v)));handles.insert(output.get(),*output);},A::Structural{source,output,..}|A::Scalar(S::Copy{source,output})=>{handles.insert(source.get(),*source);handles.insert(output.get(),*output);},_=>{}}}
 for l in p.iterations(){match l{L::Tail(t)=>{for v in [t.seed(),t.next(),t.carrier(),t.returned(),t.result()]{handles.insert(v.get(),v);}},L::Iteration(t)=>{for v in [t.seed(),t.next(),t.carrier()]{handles.insert(v.get(),v);}},_=>{}}}
 let mut wanted=BTreeSet::new();let mut sites=BTreeSet::new();
 for r in rows.as_array().unwrap(){let site=r["site"].as_u64().unwrap()as usize;sites.insert(site);wanted.insert(r["source"].as_u64().unwrap()as u32);for a in r["remaining_arena_aliases"].as_array().unwrap(){wanted.insert(a[0].as_u64().unwrap()as u32);}}
 let mut values=Vec::new();for id in wanted{let value=handles[&id];let definitions=facts.definition_sites(id).unwrap().iter().map(|d|serde_json::json!({"site":d.site(),"iteration":d.iteration(),"role":format!("{:?}",d.role()),"action":d.site().map(|s|format!("{:?}",p.blocks()[s as usize].action()))})).collect::<Vec<_>>();values.push(serde_json::json!({"value":id,"reads":facts.read_roles(value).unwrap().iter().map(|r|format!("{r:?}")).collect::<Vec<_>>(),"definitions":definitions}));}
 let sites=sites.into_iter().map(|site|{let proof=proofs[site].as_ref().unwrap();serde_json::json!({"site":site,"iteration":p.blocks()[site].iteration(),"source":proof.source().map(|v|v.get()),"owned_source_slots":proof.owned_source_slots().iter().map(|v|v.get()).collect::<Vec<_>>()})}).collect::<Vec<_>>();
 std::fs::write(root.join("plan-copies.json"),serde_json::to_vec_pretty(&serde_json::json!({"sites":sites,"values":values})).unwrap()).unwrap();
}
