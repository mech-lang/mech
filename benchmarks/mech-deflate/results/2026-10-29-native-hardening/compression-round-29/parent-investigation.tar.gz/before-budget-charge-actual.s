/private/tmp/mech-child-loops-round28-20261029/primary/before:
(__TEXT,__text) section
__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge:
1022fe9b4:	ff 03 01 d1	sub	sp, sp, #0x40
1022fe9b8:	f4 4f 02 a9	stp	x20, x19, [sp, #0x20]
1022fe9bc:	fd 7b 03 a9	stp	x29, x30, [sp, #0x30]
1022fe9c0:	fd c3 00 91	add	x29, sp, #0x30
1022fe9c4:	13 00 40 f9	ldr	x19, [x0]
1022fe9c8:	40 c0 00 b0	adrp	x0, 6153 ; 0x103b07000
1022fe9cc:	00 60 15 91	add	x0, x0, #0x558
1022fe9d0:	09 00 40 f9	ldr	x9, [x0]
1022fe9d4:	20 01 3f d6	blr	x9
1022fe9d8:	09 40 40 39	ldrb	w9, [x0, #0x10]
1022fe9dc:	3f 05 00 71	cmp	w9, #0x1
1022fe9e0:	00 02 00 54	b.eq	0x1022fea20
1022fe9e4:	3f 09 00 71	cmp	w9, #0x2
1022fe9e8:	81 00 00 54	b.ne	0x1022fe9f8
1022fe9ec:	80 be 00 b0	adrp	x0, 6097 ; 0x103acf000
1022fe9f0:	00 80 39 91	add	x0, x0, #0xe60
1022fe9f4:	c9 6a 2b 94	bl	__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error
1022fe9f8:	e9 10 00 f0	adrp	x9, 543 ; 0x10251d000
1022fe9fc:	29 f1 38 91	add	x9, x9, #0xe3c
1022fea00:	e1 03 01 a9	stp	x1, x0, [sp, #0x10]
1022fea04:	e1 03 09 aa	mov	x1, x9
1022fea08:	e8 0b 00 a9	stp	x8, x2, [sp]
1022fea0c:	ae 2c 2a 94	bl	__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register
1022fea10:	e1 03 41 a9	ldp	x1, x0, [sp, #0x10]
1022fea14:	e8 0b 40 a9	ldp	x8, x2, [sp]
1022fea18:	29 00 80 52	mov	w9, #0x1
1022fea1c:	09 40 00 39	strb	w9, [x0, #0x10]
1022fea20:	09 00 40 f9	ldr	x9, [x0]
1022fea24:	0a 00 f0 92	mov	x10, #0x7fffffffffffffff
1022fea28:	3f 01 0a eb	cmp	x9, x10
1022fea2c:	02 03 00 54	b.hs	0x1022fea8c
1022fea30:	09 04 40 f9	ldr	x9, [x0, #0x8]
1022fea34:	3f 01 00 f1	cmp	x9, #0x0
1022fea38:	24 11 53 fa	ccmp	x9, x19, #0x4, ne
1022fea3c:	e1 01 00 54	b.ne	0x1022fea78
1022fea40:	69 0a 40 f9	ldr	x9, [x19, #0x10]
1022fea44:	a9 02 00 b5	cbnz	x9, 0x1022fea98
1022fea48:	09 00 80 92	mov	x9, #-0x1
1022fea4c:	69 0a 00 f9	str	x9, [x19, #0x10]
1022fea50:	e9 03 01 aa	mov	x9, x1
1022fea54:	61 62 00 91	add	x1, x19, #0x18
1022fea58:	e0 03 08 aa	mov	x0, x8
1022fea5c:	e3 03 02 aa	mov	x3, x2
1022fea60:	e2 03 09 aa	mov	x2, x9
1022fea64:	01 52 00 94	bl	__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22charge_control_account
1022fea68:	68 0a 40 f9	ldr	x8, [x19, #0x10]
1022fea6c:	08 05 00 91	add	x8, x8, #0x1
1022fea70:	68 0a 00 f9	str	x8, [x19, #0x10]
1022fea74:	02 00 00 14	b	0x1022fea7c
1022fea78:	1f 01 00 39	strb	wzr, [x8]
1022fea7c:	fd 7b 43 a9	ldp	x29, x30, [sp, #0x30]
1022fea80:	f4 4f 42 a9	ldp	x20, x19, [sp, #0x20]
1022fea84:	ff 03 01 91	add	sp, sp, #0x40
1022fea88:	c0 03 5f d6	ret
1022fea8c:	80 be 00 d0	adrp	x0, 6098 ; 0x103ad0000
1022fea90:	00 c0 29 91	add	x0, x0, #0xa70
1022fea94:	4e 6c 2b 94	bl	__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed
1022fea98:	80 be 00 f0	adrp	x0, 6099 ; 0x103ad1000
1022fea9c:	00 40 14 91	add	x0, x0, #0x510
1022feaa0:	3f 6c 2b 94	bl	__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed
1022feaa4:	68 0a 40 f9	ldr	x8, [x19, #0x10]
1022feaa8:	08 05 00 91	add	x8, x8, #0x1
1022feaac:	68 0a 00 f9	str	x8, [x19, #0x10]
1022feab0:	79 71 2b 94	bl	0x102ddb094 ; symbol stub for: __Unwind_Resume
