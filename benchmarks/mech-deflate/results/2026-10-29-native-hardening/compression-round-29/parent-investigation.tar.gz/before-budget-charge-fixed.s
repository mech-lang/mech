/private/tmp/mech-child-loops-round28-20261029/primary/before:
(__TEXT,__text) section
Can't find -dis-symname: _RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge
