from pathlib import Path
import json,os,subprocess,time,hashlib
r=Path('/private/tmp/mech-ownership-round29-20261029');out=r/'parent-work';w=Path('/private/tmp/mech-deflate-linear-stack');cmd=json.loads((r/'build-command.json').read_text());cmd[-1]=str(out/'gpu-unit-tests')
meta=json.loads(Path('/private/tmp/mech-scalar-paths-round22-20261029/default-metadata.json').read_text());pkg=next(p for p in meta['packages'] if p['name']=='mech-gpu')
env={**os.environ,'CARGO_MANIFEST_DIR':str(w/'hosts/gpu'),'CARGO_PKG_NAME':'mech-gpu','CARGO_PKG_VERSION':'0.3.5','CARGO_PKG_VERSION_MAJOR':'0','CARGO_PKG_VERSION_MINOR':'3','CARGO_PKG_VERSION_PATCH':'5','CARGO_PKG_DESCRIPTION':pkg['description']}
for label,c in [('build',cmd),('run',[str(out/'gpu-unit-tests'),'native_artifact::work::tests::','--nocapture','--test-threads=1'])]:
 t=time.monotonic();p=subprocess.run(c,capture_output=True,text=True,env=env,timeout=180)
 (out/(label+'.log')).write_text(p.stdout+p.stderr);(out/(label+'.json')).write_text(json.dumps({'command':c,'exit':p.returncode,'seconds':time.monotonic()-t,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'production_dirty':subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True),'performance_observations':0,'adaptation':'Absolute module paths and diagnostic-only observation around the actual unchanged unsigned replacement call. No source Value clones or ownership mutations by observer.'},indent=2)+'\n');print(p.stdout[-1800:]+p.stderr[-5000:],flush=True);p.check_returncode()
