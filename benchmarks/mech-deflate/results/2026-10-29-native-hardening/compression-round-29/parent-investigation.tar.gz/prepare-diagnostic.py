from pathlib import Path
import json,re
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/mech-child-loops-round28-20261029')
u=r/'unit';u.mkdir();c=r/'census';c.mkdir()
files={w/'hosts/gpu/src/native_artifact/program/mod.rs':u/'program.rs',w/'hosts/gpu/src/native_artifact/program/runtime/mod.rs':u/'runtime.rs',w/'hosts/gpu/src/native_artifact/program/runtime/invocation/mod.rs':u/'invocation.rs',w/'hosts/gpu/src/native_artifact/program/runtime/invocation/word_updates.rs':u/'word_updates.rs'}
def adapt(source):
 lines=source.read_text().splitlines();out=[]
 for line in lines:
  path=re.fullmatch(r'(\s*#\[path = )"([^"]+)"(\])',line)
  if path:
   out.append(path[1]+json.dumps(str((source.parent/path[2]).resolve()))+path[3]);continue
  m=re.fullmatch(r'((?:pub(?:\([^)]*\))? )?)mod (\w+);',line)
  if m and not (out and out[-1].lstrip().startswith('#[path = ')):
   p=source.parent/(m[2]+'.rs')
   if not p.exists():p=source.parent/m[2]/'mod.rs'
   assert p.exists(),p
   out.append('#[path = '+json.dumps(str(files.get(p,p)))+']')
  out.append(line)
 return '\n'.join(out)+'\n'
for source,out in files.items():out.write_text(adapt(source))
s=(old/'after-unit-census/native_artifact.rs').read_text().replace(str(w/'hosts/gpu/src/native_artifact/program/mod.rs'),str(u/'program.rs')).replace(str(old/'after-unit-census/probe.rs'),str(c/'probe.rs'))
(u/'native_artifact.rs').write_text(s)
s=(old/'after-unit-census/lib.rs').read_text().replace(str(old/'after-unit-census/native_artifact.rs'),str(u/'native_artifact.rs'))
(u/'lib.rs').write_text(s)
s=(old/'after-unit-census/probe.rs').read_text().replace(str(old/'after-unit-census/counts.json'),str(c/'counts.json')).replace('46aece8b8', 'd75177747')
# The original probe had a full production SHA in metadata; bind this source explicitly.
s=re.sub(r'"head":"[^"]+"','"head":"d75177747b6870d32265b5410c000b789552060b"',s)
s=s.replace('OBS.with(|v|*v.borrow_mut()=Counts::default());','OBS.with(|v|*v.borrow_mut()=Counts::default());\n COPY_OBS.with(|v|v.borrow_mut().clear());COPY_ENABLED.with(|v|v.set(true));')
s=s.replace('let obs=OBS.with(|v|std::mem::take(&mut *v.borrow_mut()));','COPY_ENABLED.with(|v|v.set(false));\n let copies=COPY_OBS.with(|v|std::mem::take(&mut *v.borrow_mut()));\n std::fs::write("'+str(c/'copies.json')+'",serde_json::to_vec_pretty(&copies).unwrap()).unwrap();\n let obs=OBS.with(|v|std::mem::take(&mut *v.borrow_mut()));')
s += r'''
thread_local! {
 static COPY_ENABLED:Cell<bool>=const {Cell::new(false)};
 static COPY_OBS:RefCell<Vec<serde_json::Value>>=const {RefCell::new(Vec::new())};
}
pub(crate) fn copy_enabled()->bool {COPY_ENABLED.with(Cell::get)}
pub(crate) fn record_copy(v:serde_json::Value){COPY_OBS.with(|rows|rows.borrow_mut().push(v));}
pub(crate) fn matrix_info(v:&Value)->(usize,usize,usize,usize) {
 let ValueData::Matrix(m)=v.data()else{panic!("expected unsigned matrix")};
 let (len,width,ptr)=match m.elements(){SequenceView::U8(v)=>(v.len(),1,v.as_ptr()as usize),SequenceView::U16(v)=>(v.len(),2,v.as_ptr()as usize),SequenceView::U32(v)=>(v.len(),4,v.as_ptr()as usize),SequenceView::U64(v)=>(v.len(),8,v.as_ptr()as usize),_=>panic!("expected packed unsigned")};
 (len,width,m.unsigned_buffer_capacity().unwrap(),ptr)
}
pub(crate) fn aliases(v:&Value,source:&Value)->usize {
 if v.shares_frozen_storage(source){return 1;}
 0
}
'''
(c/'probe.rs').write_text(s)
p=u/'word_updates.rs';s=p.read_text();marker='        let (value, _changed) = call\n'
assert marker in s
before=r'''
        let diagnostic = if crate::native_artifact::census::copy_enabled() {
            let info=crate::native_artifact::census::matrix_info(&source);
            let arena_aliases=(0..descriptor.metadata().plan.values().len()).filter_map(|slot|self.state.arena.test_current_value(slot as u32).map(|v|(slot,crate::native_artifact::census::aliases(v,&source)))).filter(|(_,n)|*n!=0).collect::<Vec<_>>();
            let mut frame_aliases=std::collections::BTreeSet::new();
            for slot in 0..descriptor.metadata().plan.values().len() {
                if let Some(fields)=descriptor.metadata().buffer_frames.fields_at(slot) {
                    for field in fields {
                        if let mech_engine::native_artifact::NativeBufferFrameLane::Managed{at}=field.lane()
                            && let Some((Some(owner),_))=self.state.buffer_frames.current_leaf(*field)
                            && crate::native_artifact::census::aliases(owner,&source)!=0 {
                            frame_aliases.insert(at);
                        }
                    }
                }
            }
            Some((info,serde_json::json!({"site":site,"iteration":descriptor.metadata().plan.blocks()[site].iteration(),"source":operands[0].get(),"output":output.get(),"length":info.0,"width":info.1,"capacity":info.2,"payload_before":info.3,"owned_source_slots":proof.owned_source_slots().iter().map(|v|v.get()).collect::<Vec<_>>(),"may_consume":!proof.owned_source_slots().is_empty(),"remaining_arena_aliases":arena_aliases,"remaining_frame_aliases":frame_aliases,"same_budget_admitted":source.memory_budget_retained_bytes(&self.state.library.memory_budget()).is_some()})))
        } else {None};
        let (value, changed) = call
'''
s=s.replace(marker,before)
marker='        self.state\n            .arena\n            .put(output.get(), &value, &mut self.state.control.work)?;'
after=r'''
        if let Some((info,mut row))=diagnostic {
            let after=crate::native_artifact::census::matrix_info(&value);
            row["changed"]=serde_json::json!(changed);row["payload_after"]=serde_json::json!(after.3);
            row["capacity_after"]=serde_json::json!(after.2);
            row["core_transfer_succeeded"]=serde_json::json!(changed&&info.3==after.3);
            row["copied_bytes"]=serde_json::json!(if changed&&info.3!=after.3 {info.0*info.1}else{0});
            crate::native_artifact::census::record_copy(row);
        }
'''
assert marker in s;s=s.replace(marker,after+marker)
p.write_text(s)
b=json.loads((old/'gpu-units/build.json').read_text());cmd=b['command'][:];cmd[-3:]=[str(u/'lib.rs'),'-o',str(r/'gpu-unit-tests')];(r/'build-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
print('prepared',str(r))
