from pathlib import Path
import datetime,hashlib,json,os,subprocess,time,tarfile
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');o=r/'isolated-profile';o.mkdir();p=r/'linked-primary'
active=subprocess.check_output(['ps','-Ao','comm='],text=True).splitlines();blocked={'rustc','cargo','gpu-unit-tests','nested-component-tests','artifact_review','native_frame_transport','before','current','frame-before','frame-after','engine-tests','core-unit-tests'};assert not [x for x in active if Path(x.strip()).name in blocked]
artifact=Path('/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc');assert hashlib.sha256(artifact.read_bytes()).hexdigest()=='a2a551911949f8c5fdc64273a43662c2a9c4953b853136c19d196692fdac45a7'
for label,binary,work in [(label,p/label/'worker',json.loads((p/label/'binding.json').read_text())['expected_work']) for label in ['after']]:
 command=[str(binary),str(artifact),'693'];sampled=False;started=time.monotonic();sample_result=None
 with (o/(label+'.stdout')).open('wb') as out,(o/(label+'.stderr')).open('wb') as err:
  process=subprocess.Popen(command,stdout=out,stderr=err)
  try:
   while process.poll() is None:
    if not sampled and 'MEASURING 1\n' in (o/(label+'.stderr')).read_text():
     sampled=True;sample_command=['sample',str(process.pid),'2','-file',str(o/(label+'.sample.txt'))];sample_result=subprocess.run(sample_command,capture_output=True,text=True);(o/(label+'-sampler.log')).write_text(sample_result.stdout+sample_result.stderr)
    time.sleep(.005)
   code=process.wait()
  finally:
   if process.poll() is None:process.terminate();process.wait(timeout=10)
 # Preserve the raw sample and resolve missing main-image symbols explicitly.
 raw=(o/(label+'.sample.txt')).read_text()
 import re
 addresses=list(dict.fromkeys(re.findall(r'\?\?\?  \(in worker\).*?\[(0x[0-9a-f]+)\]',raw)))
 if addresses:
  image=re.search(r'load address (0x[0-9a-f]+)',raw)[1]
  resolve_command=['atos','-o',str(binary),'-arch','arm64','-l',image,*addresses]
  resolved=subprocess.run(resolve_command,capture_output=True,text=True);resolved.check_returncode()
  symbols=resolved.stdout.splitlines();assert len(symbols)==len(addresses)
  mapping=dict(zip(addresses,symbols))
  updated=[]
  for line in raw.splitlines(keepends=True):
   match=re.search(r'\?\?\?  \(in worker\).*?\[(0x[0-9a-f]+)\]',line)
   if match:
    symbol=mapping[match[1]].split(' (in ',1)[0].strip()
    line=line.replace('???',symbol,1)
   updated.append(line)
  (o/(label+'.resolved.sample.txt')).write_text(''.join(updated))
  (o/(label+'-symbolization.json')).write_text(json.dumps({'command':resolve_command,'exit':resolved.returncode,'resolved_addresses':len(addresses),'mapping':mapping},indent=2)+'\n')
 rows=[json.loads(l) for l in (o/(label+'.stdout')).read_text().splitlines()]
 receipt={'label':label,'command':command,'exit':code,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'artifact_sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'sample_command':sample_command if sampled else None,'sample_exit':sample_result.returncode if sample_result else None,'all_observations_excluded_from_primary':True,'performance_comparison_claimed':False,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':len(rows)}
 (o/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 assert code==0 and sampled and sample_result.returncode==0
 assert len(rows)==695 and all(x['exact_reference'] and x['independent_inflation'] and x['capacity']==13 and x['work']==work for x in rows)
 assert (o/(label+'.stderr')).read_text().endswith('CLEANUP bytes=0 nodes=0\n')
 subprocess.run(['python3',str(r/'archive.py'),'profile-isolated-'+label,*map(str,[f for f in o.iterdir() if f.is_file() and f.name.startswith(label)]),str(r/'profile-isolated.py')],cwd=w,check=True)
 print(label,'PROFILE_COMPLETE',len(rows),'diagnostic observations,all excluded',flush=True)
