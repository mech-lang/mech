from pathlib import Path
import datetime,hashlib,json,os,select,shutil,statistics,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/mech-shared-shadows-round51-20261031');p=r/'refresh';p.mkdir();binding=old/'linked-primary/after';sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
artifact=Path('/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc');reference=Path('/private/tmp/mech-deflate-profiling-20261028/roc-profile');b=json.loads((binding/'binding.json').read_text());assert sha(binding/'worker')==b['worker_sha256'];assert sha(artifact)=='a2a551911949f8c5fdc64273a43662c2a9c4953b853136c19d196692fdac45a7';assert sha(artifact.with_suffix('.mec'))=='331e659e92181d803b3d87218effe88f711c2e8ecad9f31838fc50991de1c5c9';assert sha(reference)=='3941ef59b2c9343d0493cc6b6d14ca4803e6bd27acfe520b1fb59d9b63026324'
for name,pin in b['pins'].items():assert sha(binding/name)==pin['sha256']
for lib in b['libraries'].values():assert sha(lib['path'])==lib['sha256']
for f in [r/'owners/memory-trace']:
 if f.exists():
  assert json.loads((f.parent/'run.json').read_text())['exit']==0
  (p/'completed-owner-cleanup.json').write_text(json.dumps({'path':str(f),'bytes':f.stat().st_size,'sha256':sha(f),'free_before':shutil.disk_usage('/private/tmp').free},indent=2)+'\n');f.unlink()
active=subprocess.check_output(['ps','-Ao','comm='],text=True).splitlines();blocked={'rustc','cargo','tests','gpu-unit-tests','worker','roc-profile','native_frame_transport','memory-trace'};assert not [x for x in active if Path(x.strip()).name in blocked]
(p/'binding.json').write_text(json.dumps({**b,'retained_published_head':'70847471ba06c9e395f9628eb1b19c7b11ea82f6','measurement_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'scope':'Fresh current-state profile only. No production compiler change in round 52, no before/after improvement claim. Exact retained round-51 executable/Object/image, common dependency graph, allocator, source, bytecode and timer.'},indent=2)+'\n')
def archive(stage,files):
 subprocess.run(['python3',str(r/'archive.py'),stage,*map(str,files),str(r/'refresh.py')],cwd=w,check=True)
def run(name,cmd,extra=None):
 qpath=p/name;qpath.mkdir();t=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
 for stream in ['stdout','stderr']:(qpath/('run.'+stream)).write_text(getattr(q,stream))
 receipt={'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-t,'binary_sha256':sha(cmd[0]),'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),**(extra or {})};(qpath/'run.json').write_text(json.dumps(receipt,indent=2)+'\n');q.check_returncode();return qpath,q
refpath,q=run('reference-primary',[str(reference),'12']);refrows=[line.split('\t') for line in q.stdout.splitlines() if line.startswith('rep\troc-deflate\t')];assert len(refrows)==20000;ref=statistics.median(int(row[3]) for row in refrows)/1e9;(refpath/'summary.json').write_text(json.dumps({'observations':len(refrows),'median_seconds':ref},indent=2)+'\n');archive('refresh-primary-reference',[refpath,p/'binding.json',r/'archive.py']);print('REFERENCE',ref,flush=True)
medians=[];allrows=[]
for prep in range(3):
 d=p/f'primary-{prep}';d.mkdir();cmd=[str(binding/'worker'),str(artifact),'512'];receipt={'preparation':prep,'command':cmd,'steady_observations':512,'reference_seconds':ref,'work':60260219686,'scope':'One independently prepared current executable; no A/B contrast. Sequential preparations, one warmup and one extra profile observation excluded.'};rows=[];failure=None
 with (d/'run.stderr').open('w') as err,(d/'run.stdout').open('w') as out:
  process=subprocess.Popen(cmd,cwd=w,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,bufsize=1,env={**os.environ,'MECH_BENCH_SESSION':'1'});print('PREPARING',prep,process.pid,flush=True)
  def read():
   while not select.select([process.stdout],[],[],50)[0]:
    assert process.poll() is None;print('LIVE_WAIT',process.pid,flush=True)
   line=process.stdout.readline();assert line;out.write(line);out.flush();return line
  try:
   assert read()=='SESSION_READY\n'
   for i in range(514):
    process.stdin.write('N');process.stdin.flush();row=json.loads(read());rows.append(row);assert row['exact_reference'] and row['independent_inflation'] and row['capacity']==13 and row['input_bytes']==8 and row['raw_bytes']==10 and row['work']==60260219686
   process.stdin.close();receipt['exit']=process.wait();assert receipt['exit']==0
  except BaseException as e:failure=repr(e);receipt['failure']=failure
  finally:
   if process.poll() is None:process.terminate();process.wait()
 receipt['rows']=rows;(d/'run.json').write_text(json.dumps(receipt,indent=2)+'\n');archive('refresh-primary-preparation-'+str(prep),[d])
 if failure:raise RuntimeError(failure)
 assert (d/'run.stderr').read_text().endswith('CLEANUP bytes=0 nodes=0\n');steady=[x for x in rows if not x['warmup'] and not x['profile']];assert len(steady)==512;allrows+=steady;median=statistics.median(x['seconds'] for x in steady);medians.append(median);print('CURRENT',prep,median,median/ref,flush=True)
summary={'scope':'Fresh current-state elapsed, not an optimization comparison. Three independent preparations, 1536 steady calls plus six excluded warmup/profile calls. One shared fresh reference. No larger-input result.','reference_seconds':ref,'reference_observations':20000,'preparation_seconds':medians,'preparation_multiples':[x/ref for x in medians],'pooled_seconds':statistics.median(x['seconds'] for x in allrows),'steady_observations':1536};summary['multiple_of_reference']=summary['pooled_seconds']/ref;(p/'primary-summary.json').write_text(json.dumps(summary,indent=2)+'\n');archive('refresh-primary-summary',[p/'primary-summary.json']);print('ELAPSED',json.dumps(summary),flush=True)
for kind,n,count in [('cpu',32,34),('memory',8,10)]:
 # Build only the consumer; retained matched compiler libraries and Object/image remain unchanged.
 base=json.loads((old/f'counters/after/{kind}-build.json').read_text());cmd=base['command'].copy();binary=p/kind;cmd[-1]=str(binary);at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(kind+'-build.'+stream)).write_text(getattr(q,stream))
 (p/(kind+'-build.json')).write_text(json.dumps({**base,'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'source_sha256':sha(cmd[-3]),'scope':'Same retained matched libraries, unchanged counter source, Object/image and pinned allocator; optimized warnings-as-errors consumer build.'},indent=2)+'\n');q.check_returncode()
 for label,binpath,args,expected in [('reference',Path('/private/tmp/mech-deep-profile-20261030')/('reference-'+kind),['12'],32),('current',binary,[str(artifact),str(n)],count)]:
  d,q=run(label+'-'+kind,[str(binpath),*args],{'scope':'Separate diagnostic; no instrumented elapsed in primary. Same respective exact libraries/Object/image and allocator.'})
  counters=[json.loads(line.removeprefix('ALLOC_PROBE ')) for line in q.stderr.splitlines() if line.startswith('ALLOC_PROBE ')];assert len(counters)==expected
  if label=='reference':assert q.stdout.count('rep\troc-deflate\t')==20000
  else:
   rows=[json.loads(line) for line in q.stdout.splitlines() if line.startswith('{')];assert len(rows)==count and all(x['exact_reference'] and x['independent_inflation'] and x['capacity']==13 and x['work']==60260219686 for x in rows);assert q.stderr.endswith('CLEANUP bytes=0 nodes=0\n')
  files=[d]
  if label=='current':files += [p/(kind+'-build.'+x) for x in ['json','stdout','stderr']]
  archive('refresh-'+label+'-'+kind,files);print('COUNTERS',label,kind,len(counters),flush=True)
 binary.unlink()
for script in ['profile-isolated.py','profile-reference.py']:
 subprocess.run(['python3',str(r/script)],cwd=w,check=True)
print('REFRESH COMPLETE',flush=True)
