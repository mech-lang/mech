//! Capacity-bearing sequence calls remain ordinary selected library visits.
use super::{Error, Invocation, invalid};
use mech_engine::native_artifact::{NativeIterationAction as Action, NativeScalarKind as K};

impl Invocation<'_, '_, '_> {
    pub(super) fn unsigned_buffer_call(
        &mut self,
        site: usize,
        words: &[u64],
    ) -> Result<bool, Error> {
        let descriptor = self.descriptor;
        let Some(proof) = descriptor
            .metadata()
            .unsigned_buffer_calls
            .get(site)
            .and_then(Option::as_ref)
        else {
            return Ok(false);
        };
        let Some(call) = descriptor.metadata().calls[site].as_ref() else {
            return Err(invalid("buffer call lost its selected factory"));
        };
        if !call.supports_unsigned_buffer() || proof.site() as usize != site {
            return Err(invalid("buffer call differs from selected site"));
        }
        let Action::LibraryCall {
            operands, output, ..
        } = descriptor.metadata().plan.blocks()[site].action()
        else {
            return Err(invalid("buffer helper outside library call"));
        };
        if words.len() != operands.len()
            || descriptor.metadata().plan.values()[output.get() as usize]
                .scalar_kind()
                .is_some()
        {
            return Err(invalid("buffer output transport differs"));
        }
        for (index, operand) in operands.iter().enumerate() {
            let kind = descriptor.metadata().plan.values()[operand.get() as usize].scalar_kind();
            if Some(*operand) == proof.source() || Some(*operand) == proof.sublist() {
                if kind.is_some() || words[index] != 0 {
                    return Err(invalid("buffer source is not a managed owner"));
                }
            } else if !matches!(kind, Some(K::U8 | K::U16 | K::U32 | K::U64)) {
                return Err(invalid("buffer scalar operand kind differs"));
            }
        }
        if self.has_uninventoried_private_owners() {
            return Ok(false);
        }
        let coexistence = self.selected_join_coexistence(None)?;
        // Fixed table/header checks and optional alias retirement share the
        // invocation's existing finite native ledger. No arena-wide sweep runs.
        let checks = (proof.owned_source_slots().len() as u64)
            .checked_mul(64)
            .and_then(|n| n.checked_add(512))
            .ok_or_else(|| invalid("buffer ownership work overflow"))?;
        self.state
            .control
            .work
            .charge(crate::native_artifact::NativeExecutionPhase::Setup, checks)?;
        // Borrow before retiring destination aliases: self-append must keep the
        // old backing immutable while its selected range is read.
        let sublist = proof
            .sublist()
            .map(|value| {
                self.state
                    .arena
                    .copy_current(value.get(), &mut self.state.control.work)
            })
            .transpose()?;
        let source = proof
            .source()
            .map(|source| {
                self.state
                    .arena
                    .copy_current(source.get(), &mut self.state.control.work)
            })
            .transpose()?;
        if let Some(source) = source.as_ref() {
            for slot in proof.owned_source_slots() {
                self.state.arena.retire_current_matching(
                    slot.get(),
                    source,
                    &mut self.state.control.work,
                )?;
            }
        }
        let diagnostic_geometry = source.as_ref().and_then(|value| {
            let mech_core::ValueData::Matrix(matrix) = value.data() else { return None; };
            Some((matrix.elements().len(), matrix.unsigned_buffer_capacity()?))
        });
        let diagnostic_target = diagnostic_geometry.is_some_and(|(_, capacity)| capacity == 305257)
            || (proof.source().is_none() && words.get(1) == Some(&305257));
        if diagnostic_target {
            eprintln!("BUFFER_CALL_BEGIN site={} operation={:?} source={:?} length_capacity={:?} may_consume={} retirement_slots={:?}", site, call.template().primitive(), proof.source().map(|v|v.get()), diagnostic_geometry, !proof.owned_source_slots().is_empty(), proof.owned_source_slots().iter().map(|v|v.get()).collect::<Vec<_>>());
        }
        if diagnostic_geometry.is_some_and(|(length, capacity)| capacity == 305257 && length == 258)
            || diagnostic_geometry.is_some_and(|(_, capacity)| capacity == 305257)
                && call.template().primitive() == mech_engine::native_artifact::NativeCollectionPrimitive::SequenceClear
        {
            if let Some(source) = source.as_ref() {
                let metadata = descriptor.metadata();
                eprintln!("OWNER_CENSUS_BEGIN site={site}");
                for slot in 0..metadata.plan.values().len() {
                    if self.state.arena.native_entry_preview(slot as u32, &self.state.control.work)?
                        .is_some_and(|owner| owner.shares_frozen_storage(source)) {
                        eprintln!("OWNER_CANONICAL slot={slot}");
                    }
                    if let Some(fields) = metadata.buffer_frames.fields_at(slot) {
                        fn visit(invocation: &Invocation<'_, '_, '_>, source: &mech_core::Value, slot: usize,
                            fields: &[mech_engine::native_artifact::NativeBufferFrameField]) {
                            let layout = &invocation.descriptor.metadata().buffer_frames;
                            for field in fields {
                                if let Some(children) = layout.children(*field) {
                                    visit(invocation, source, slot, children);
                                } else if invocation.state.buffer_frames.current_leaf(*field)
                                    .and_then(|(owner, _)| owner)
                                    .is_some_and(|owner| owner.shares_frozen_storage(source)) {
                                    eprintln!("OWNER_FRAME slot={slot} lane={:?}", field.lane());
                                }
                            }
                        }
                        visit(self, source, slot, fields);
                    }
                }
                eprintln!("OWNER_CENSUS_END site={site}");
            }
        }
        let result = call
            .unsigned_buffer_with_sublist(
                source,
                words
                    .get(if sublist.is_some() { 2 } else { 1 })
                    .copied()
                    .unwrap_or(0),
                words.get(if sublist.is_some() { 3 } else { 2 }).copied(),
                sublist,
                !proof.owned_source_slots().is_empty(),
                self.limits,
                &self.state.library,
                coexistence,
            )
            .map_err(|error| Error::Library {
                origin: descriptor.metadata().plan.blocks()[site].origin(),
                error,
            })?;
        if diagnostic_target { eprintln!("BUFFER_CALL_END site={site}"); }
        self.state
            .arena
            .put(output.get(), &result, &mut self.state.control.work)?;
        Ok(true)
    }
}
