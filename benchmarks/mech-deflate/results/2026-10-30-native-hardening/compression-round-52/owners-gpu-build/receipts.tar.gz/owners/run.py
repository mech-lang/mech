from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).resolve().parent;r=p.parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/mech-shared-shadows-round51-20261031')
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
b=json.loads((old/'final-release.json').read_text());libs=json.loads((old/'final-libraries.json').read_text());source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
for value in libs.values():assert sha(value['path'])==value['sha256']
pin=json.loads((p/'source-pin.json').read_text());pin['overlay_files']=[{'path':str(f.relative_to(p)),'sha256':sha(f)} for f in [p/'source/native_artifact/program/runtime/invocation/unsigned_buffers.rs',p/'allocation_stacks.c',p/'allocation_profile.rs']];pin.pop('overlay_sha256',None);(p/'source-pin.json').write_text(json.dumps(pin,indent=2)+'\n')
def run(label,cmd,env=None,where=p):
 t=time.monotonic();q=subprocess.run(cmd,cwd=w,env={**os.environ,**(env or {})},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(where/(label+'.'+stream)).write_text(getattr(q,stream))
 row={'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-t,'environment':env or {},'scope':'Diagnostic-only; timing/counters excluded from all performance claims. Same respective fresh GPU/Object/image and frozen seven other libraries.'};(where/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n');print(label,q.returncode,flush=True)
 if q.returncode:print(q.stderr[-7000:],flush=True)
 q.check_returncode();return q,row
cmd=b['command'].copy();cmd[-3]=str(p/'source/lib.rs');cmd[-1]=str(p/'variants/after/libmech_gpu.rlib');q,row=run('gpu-build',cmd,b['environment']);row.update(source_head=source_head,base_compiler_source=b['source_head'],libraries=libs);(p/'variants/after/build.json').write_text(json.dumps(row,indent=2)+'\n')
libs['mech_gpu']={**libs['mech_gpu'],'path':cmd[-1],'sha256':sha(cmd[-1])};(p/'variants/after/libraries.json').write_text(json.dumps(libs,indent=2)+'\n')
subprocess.run(['python3',str(p/'archive.py'),'gpu-build',str(p/'gpu-build.json'),str(p/'gpu-build.stdout'),str(p/'gpu-build.stderr'),str(p/'source/native_artifact/program/runtime/invocation/unsigned_buffers.rs'),str(p/'source-pin.json'),str(p/'variants/after/build.json'),str(p/'variants/after/libraries.json'),str(p/'run.py')],cwd=w,check=True)
subprocess.run(['python3',str(p/'linked-build.py'),'after'],cwd=w,check=True)
inc=Path('/private/tmp/mech-deep-profile-20261030/include');run('probe-build',['clang','-O3','-std=c11','-Wall','-Wextra','-Werror','-DPROBE_MEMORY=1','-I'+str(inc),'-I'+str(p),'-c',str(p/'allocation_stacks.c'),'-o',str(p/'stacks.o')])
base=json.loads((old/'counters/after/memory-build.json').read_text());cmd=base['command'].copy()
for i,a in enumerate(cmd):
 if i and cmd[i-1]=='--extern' and a.startswith('mech_gpu='):cmd[i]='mech_gpu='+libs['mech_gpu']['path']
 if a.startswith('link-arg=') and a.endswith('/object.o'):cmd[i]='link-arg='+str(p/'linked-primary/after/object.o')
 if a.startswith('link-arg=') and a.endswith('/memory_profile.o'):cmd[i]='link-arg='+str(p/'stacks.o')
cmd[1:1]=['-L','dependency='+str(p/'variants/after')]
s=(old/'counters/after/memory.rs').read_text().replace(str(old/'counters/allocation_profile.rs'),str(p/'allocation_profile.rs')).replace(str(old/'linked-primary/after/descriptor.json'),str(p/'linked-primary/after/descriptor.json'));(p/'memory.rs').write_text(s);cmd[-3]=str(p/'memory.rs');cmd[-1]=str(p/'memory-trace');run('worker-build',cmd)
q,row=run('run',[str(p/'memory-trace'),'/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc','1'])
rows=[json.loads(x) for x in q.stdout.splitlines() if x.startswith('{')];assert len(rows)==3 and all(x['work']==60260219686 and x['capacity']==13 and x['exact_reference'] and x['independent_inflation'] for x in rows);assert q.stderr.endswith('CLEANUP bytes=0 nodes=0\n')
row.update(libraries=libs,source_pin=pin,binary_sha256=sha(p/'memory-trace'),object_sha256=sha(p/'linked-primary/after/object.o'),image_sha256=sha(p/'linked-primary/after/descriptor.json'),observations=3,performance_claimed=False);(p/'run.json').write_text(json.dumps(row,indent=2)+'\n')
files=[p/name for name in ['run.json','run.stdout','run.stderr','gpu-build.json','probe-build.json','probe-build.stdout','probe-build.stderr','worker-build.json','worker-build.stdout','worker-build.stderr','memory.rs','allocation_stacks.c','allocation_profile.h','allocation_profile.rs','source-pin.json','run.py']]
subprocess.run(['python3',str(p/'archive.py'),'allocation-attribution',*map(str,files)],cwd=w,check=True)
print('CURRENT ATTRIBUTION COMPLETE',flush=True)
