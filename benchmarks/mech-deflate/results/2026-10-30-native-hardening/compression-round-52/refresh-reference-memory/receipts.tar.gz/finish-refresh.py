from pathlib import Path
import hashlib,json,subprocess,time
r=Path(__file__).resolve().parent;p=r/'refresh';w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/mech-shared-shadows-round51-20261031');sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
assert json.loads((p/'current-cpu/run.json').read_text())['exit']==0
if (p/'cpu').exists():(p/'cpu').unlink()
base=json.loads((old/'counters/after/memory-build.json').read_text());cmd=base['command'].copy();binary=p/'memory';cmd[-1]=str(binary);at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
for stream in ['stdout','stderr']:(p/('memory-build.'+stream)).write_text(getattr(q,stream))
(p/'memory-build.json').write_text(json.dumps({**base,'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'source_sha256':sha(cmd[-3]),'scope':'Retained matched libraries, unchanged counter source, Object/image and pinned allocator; optimized warnings-as-errors consumer build.'},indent=2)+'\n');q.check_returncode()
for label,binpath,args,count in [('reference',Path('/private/tmp/mech-deep-profile-20261030/reference-memory'),['12'],32),('current',binary,['/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc','8'],10)]:
 d=p/(label+'-memory');d.mkdir();cmd=[str(binpath),*args];at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
 for stream in ['stdout','stderr']:(d/('run.'+stream)).write_text(getattr(q,stream))
 (d/'run.json').write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'binary_sha256':sha(binpath),'scope':'Separate allocation diagnostic; no instrumented elapsed in primary. Same retained coherent libraries and Object/image as primary, unchanged pinned allocator.'},indent=2)+'\n')
 counters=[json.loads(x.removeprefix('ALLOC_PROBE ')) for x in q.stderr.splitlines() if x.startswith('ALLOC_PROBE ')];assert len(counters)==count
 if label=='reference':assert q.stdout.count('rep\troc-deflate\t')==20000
 else:
  rows=[json.loads(x) for x in q.stdout.splitlines() if x.startswith('{')];assert len(rows)==count and all(x['work']==60260219686 and x['capacity']==13 and x['exact_reference'] and x['independent_inflation'] for x in rows);assert q.stderr.endswith('CLEANUP bytes=0 nodes=0\n')
 files=[d,r/'finish-refresh.py']
 if label=='current':files += [p/('memory-build.'+x) for x in ['json','stdout','stderr']]
 subprocess.run(['python3',str(r/'archive.py'),'refresh-'+label+'-memory',*map(str,files)],cwd=w,check=True);q.check_returncode();print('MEMORY',label,len(counters),flush=True)
binary.unlink()
for script in ['profile-isolated.py','profile-reference.py']:
 subprocess.run(['python3',str(r/script)],cwd=w,check=True)
print('REFRESH COMPLETE',flush=True)
