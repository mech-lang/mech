from pathlib import Path
from collections import deque
import gzip,hashlib,json,sys,tarfile
out=Path(sys.argv[1]);archive=Path(sys.argv[2])
with tarfile.open(archive,'r:gz') as t:raw=gzip.decompress(t.extractfile('compiled-artifact/descriptor.json.gz').read())
sha=hashlib.sha256(raw).hexdigest();assert sha=='1b4dbdd2fb0c1f9f51ae7e9dd0bc931bbc2804e6cb949653461d6348c31615c9';p=json.loads(raw)['descriptor']['plan'];blocks=p['blocks'];source=7335;frontier=12806

def short_action(a):
 if 'LibraryCall' in a:
  v=a['LibraryCall'];return {'LibraryCall':{'operation':v['template']['selected_key'],'operands':v['operands'],'output':v['output']}}
 return a

def successors(site):
 t=blocks[site]['terminator']
 if 'Scalar' in t:
  t=t['Scalar']
  if isinstance(t,dict):
   if 'Jump' in t:return [t['Jump']]
   if 'Branch' in t or 'LiteralBranch' in t:
    v=next(iter(t.values()));return [v['yes'],v['no']]
  return []
 if 'TailHeader' in t:return [t['TailHeader']['body']]
 if 'Header' in t:return [t['Header']['body'],t['Header']['exit']]
 raise AssertionError(t)

def writes(site):
 a=blocks[site]['action']
 if 'LibraryCall' in a or 'Structural' in a:return next(iter(a.values()))['output']==source
 if 'Scalar' in a and isinstance(a['Scalar'],dict):return next(iter(a['Scalar'].values())).get('output')==source
 return False

def reads(site):
 a=short_action(blocks[site]['action'])
 if 'LibraryCall' in a:return source in a['LibraryCall']['operands']
 if 'Structural' in a:return a['Structural']['source']==source
 if 'Scalar' in a and isinstance(a['Scalar'],dict):
  v=next(iter(a['Scalar'].values()));return v.get('source')==source or source in v.get('operands',[])
 return False
q=deque((n,[n]) for n in successors(frontier));seen=set();path=None
while q:
 site,route=q.popleft()
 if site in seen:continue
 seen.add(site)
 if reads(site):path=route;break
 if writes(site):continue
 q.extend((n,route+[n]) for n in successors(site))
assert path[-1]==12825;assert not any(writes(n) for n in path)
selected=sorted(set([12424,12433,12434,12806,12825,*path]));alias=[]
for i,b in enumerate(blocks):
 a=short_action(b['action']);v=next(iter(a.values()))
 if isinstance(v,dict) and v.get('output')==7382:alias.append({'site':i,'action':a})
result={'scope':'Diagnostic source-CFG witness only, not an execution or ownership proof. Actual read roles/eligibility remain the Engine policy. This illustrates the selected append and the conservative reachable old-source Copy at the repeated conditional. No branch exclusion is implemented.','image_sha256':sha,'source_value':source,'append_frontier':frontier,'future_old_source_read_path':path,'source_predicate':7343,'known_other_canonical_owner_at_first_append':7382,'other_owner_definitions':alias,'blocks':[{'site':i,'action':short_action(blocks[i]['action']),'terminator':blocks[i]['terminator'],'iteration':blocks[i]['iteration']} for i in selected]}
out.write_text(json.dumps(result,indent=2)+'\n');print('GRAPH WITNESS',path,'alias definition',alias)
