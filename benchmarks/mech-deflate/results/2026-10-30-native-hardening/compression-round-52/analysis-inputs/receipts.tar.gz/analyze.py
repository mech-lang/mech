from pathlib import Path
from collections import Counter
import csv,hashlib,json,re,statistics,subprocess,sys
r=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent;p=r/'refresh';med=statistics.median
load=lambda f:json.loads(f.read_text())
def rows(name,stream='stderr'):
 lines=(p/name/('run.'+stream)).read_text().splitlines()
 return [json.loads(x if stream=='stdout' else x.removeprefix('ALLOC_PROBE ')) for x in lines if (x.startswith('{') if stream=='stdout' else x.startswith('ALLOC_PROBE '))]
def steady(xs):return [x for x in xs if not x['warmup'] and not x['profile']]
refrows=[x.split('\t') for x in (p/'reference-primary/run.stdout').read_text().splitlines() if x.startswith('rep\troc-deflate\t')];assert len(refrows)==20000;reference=med(int(x[3]) for x in refrows)/1e9;allrows=[];preparations=[]
for i in range(3):
 lines=(p/f'primary-{i}/run.stdout').read_text().splitlines();assert lines[0]=='SESSION_READY';xs=[json.loads(x) for x in lines[1:]];assert len(xs)==514 and all(x['work']==60260219686 and x['capacity']==13 and x['exact_reference'] and x['independent_inflation'] and x['input_bytes']==8 and x['raw_bytes']==10 for x in xs);assert (p/f'primary-{i}/run.stderr').read_text().endswith('CLEANUP bytes=0 nodes=0\n');xs=steady(xs);assert len(xs)==512;allrows+=xs;sec=med(x['seconds'] for x in xs);preparations.append({'preparation':i,'seconds':sec,'multiple_of_reference':sec/reference})
cpu={'reference':rows('reference-cpu'),'current':steady(rows('current-cpu','stdout'))};mem={'reference':rows('reference-memory'),'current':rows('current-memory')[1:-1]};assert all(len(xs)==32 for xs in cpu.values());assert len(mem['reference'])==32 and len(mem['current'])==8
fields=['instructions','cycles','rss_after','physical_after','lifetime_peak_physical','pageins'];memory_fields=['allocation_requests','requested_bytes','deallocation_calls','reallocations','relocating_reallocations','relocating_realloc_copy_upper_bound','live_usable_before','live_usable_after','peak_live_usable','incremental_peak_live_usable','rss_after','physical_after','pageins']
cpu_summary={label:{k:med(x[k] for x in xs) for k in fields} for label,xs in cpu.items()};memory_summary={label:{k:med(x[k] for x in xs) for k in memory_fields} for label,xs in mem.items()}
for xs in [*cpu.values(),*mem.values()]:assert all(x['pageins']==0 for x in xs)
for i in range(1,9):assert mem['current'][i-1]['sample']==i
hist=mem['current'][0]['large_allocations'];assert all(x['large_allocations']==hist for x in mem['current']);assert any(x=={'bytes':2442056,'count':35} for x in hist)
def trace(name):
 s=(r/name/'run.stderr').read_text();body=s.split('MEASURING 1\n',1)[1].split('MEASURING 2\n',1)[0];call=None;events=[];censuses=[];current=None
 for line in body.splitlines():
  if line.startswith('BUFFER_CALL_BEGIN'):
   m=re.match(r'BUFFER_CALL_BEGIN site=(\d+) operation=(.*?) source=(.*?) length_capacity=(.*?) may_consume=(.*?) retirement_slots=(.*)',line);assert m
   geometry=re.findall(r'\d+',m[4]);call={'site':int(m[1]),'operation':m[2],'source':m[3],'length':int(geometry[0]) if geometry else None,'capacity':int(geometry[1]) if geometry else None,'may_consume':m[5]=='true','retirement_slots':[int(x) for x in re.findall(r'\d+',m[6])]}
  elif line.startswith('BUFFER_CALL_END'):call=None
  elif line.startswith('ALLOCATION_EVENT'):
   n=int(re.search(r'bytes=(\d+)',line)[1])
   if n==2442056:assert call is not None;events.append({**call,'requested_bytes':n})
  elif line.startswith('OWNER_CENSUS_BEGIN'):current={**call,'canonical':[],'frames':[]}
  elif line.startswith('OWNER_CANONICAL'):current['canonical'].append(int(line.split('slot=')[1]))
  elif line.startswith('OWNER_FRAME'):current['frames'].append(line)
  elif line.startswith('OWNER_CENSUS_END'):censuses.append(current);current=None
 return events,censuses
alloc,_=trace('probe');owner_alloc,census=trace('owners');assert alloc==owner_alloc;assert len(alloc)==35;operations=Counter(x['operation'] for x in alloc);assert operations=={'SequenceWithCapacity':1,'SequenceAppend':32,'SequenceClear':2};assert all(not x['may_consume'] for x in alloc if x['operation']=='SequenceAppend');assert all(x['may_consume'] for x in alloc if x['operation']=='SequenceClear')
path_bytes=sum(x['length']*8 for x in alloc if x['operation']=='SequenceAppend');assert path_bytes==66944
subprocess.run(['python3',str(r/'profile_analysis.py'),str(r),str(r/'profile.json')],check=True,stdout=subprocess.DEVNULL)
result={'scope':'Current-state refresh of retained round 51; no new production optimization or before/after gain. Only full eight-byte level-12 compression. Separate primary, hardware, memory, and sample cohorts.','elapsed':{'reference_seconds':reference,'reference_observations':20000,'current_seconds':med(x['seconds'] for x in allrows),'current_multiple':med(x['seconds'] for x in allrows)/reference,'independent_preparations':preparations,'steady_observations':len(allrows),'excluded_warmup_profile_observations':6},'cpu':{'observations_per_label':32,'uncorrected_boundary_overhead':True,'medians':cpu_summary,'instruction_multiple':cpu_summary['current']['instructions']/cpu_summary['reference']['instructions'],'cycle_multiple':cpu_summary['current']['cycles']/cpu_summary['reference']['cycles']},'memory':{'reference_observations':32,'current_steady_observations':8,'medians':memory_summary,'large_current_allocations':hist,'peak_scope':'Tracked allocator live high water; prepared compiler/catalog/image state included. Post-call OS memory is not peak RSS. Whole input prepared outside timer; no streaming or large-input claim.'},'path_attribution':{'performance_claimed':False,'per_complete_call_large_reservations':len(alloc),'per_operation':dict(operations),'requested_bytes':2442056*len(alloc),'derived_initialized_bytes_copied_by_these_fallback_appends':path_bytes,'copy_scope':'Derived from reached lengths and unchanged U64 primitive implementation; clears/initial reservation copy zero elements. Not total program copy volume.','allocations':alloc,'known_owner_census':census,'owner_scope':'Canonical arena and private-frame holdings after existing candidate retirement only. Local source itself, caches and external holders are not counted; this grants no exclusive ownership proof.'},'profiles':load(r/'profile.json')['profiles'],'contracts':{'work':60260219686,'source_comparison_work_prior_qualified':47612,'raw_output':[75,76,74,78,73,77,75,207,0,0],'capacity':13,'managed_cleanup_bytes':0,'managed_cleanup_nodes':0,'input_alias_checks':True,'independent_inflation':True,'source_and_bytecode_unchanged':True},'compiler':load(p/'binding.json')}
(r/'metrics.json').write_text(json.dumps(result,indent=2)+'\n')
with (r/'metrics.csv').open('w',newline='') as f:
 writer=csv.writer(f);writer.writerow(['metric','reference','current','current_over_reference'])
 writer.writerow(['elapsed_seconds',reference,result['elapsed']['current_seconds'],result['elapsed']['current_multiple']])
 for k in ['instructions','cycles','rss_after','physical_after']:writer.writerow([k,cpu_summary['reference'][k],cpu_summary['current'][k],cpu_summary['current'][k]/cpu_summary['reference'][k]])
 for k in ['allocation_requests','requested_bytes','peak_live_usable','incremental_peak_live_usable']:writer.writerow([k,memory_summary['reference'][k],memory_summary['current'][k],memory_summary['current'][k]/memory_summary['reference'][k]])
print(json.dumps({'elapsed':result['elapsed'],'cpu':result['cpu'],'memory':result['memory']['medians'],'path':{k:v for k,v in result['path_attribution'].items() if k not in {'allocations','known_owner_census'}},'profile':result['profiles']['current']['ancestry_unions']},indent=2))
