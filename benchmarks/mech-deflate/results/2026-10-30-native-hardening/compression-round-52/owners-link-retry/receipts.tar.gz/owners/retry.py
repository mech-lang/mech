from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
b=json.loads((p/'worker-build.json').read_text());t=time.monotonic();q=subprocess.run(b['command'],cwd=w,capture_output=True,text=True)
for stream in ['stdout','stderr']:(p/('worker-build-retry.'+stream)).write_text(getattr(q,stream))
(p/'worker-build-retry.json').write_text(json.dumps({**b,'exit':q.returncode,'seconds':time.monotonic()-t,'retry_reason':'Environmental ENOSPC only; same exact command and sources after deleting terminal diagnostic executables'},indent=2)+'\n')
subprocess.run(['python3',str(p/'archive.py'),'link-retry',*[str(p/('worker-build-retry.'+x)) for x in ['json','stdout','stderr']],str(p/'retry.py')],cwd=w,check=True)
if q.returncode:print(q.stderr[-1000:],flush=True)
q.check_returncode();cmd=[str(p/'memory-trace'),'/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc','1'];t=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
for stream in ['stdout','stderr']:(p/('run.'+stream)).write_text(getattr(q,stream))
rows=[json.loads(x) for x in q.stdout.splitlines() if x.startswith('{')];receipt={'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-t,'libraries':json.loads((p/'variants/after/libraries.json').read_text()),'source_pin':json.loads((p/'source-pin.json').read_text()),'binary_sha256':sha(p/'memory-trace'),'object_sha256':sha(p/'linked-primary/after/object.o'),'image_sha256':sha(p/'linked-primary/after/descriptor.json'),'observations':len(rows),'performance_claimed':False,'scope':'Diagnostic-only owner census and target allocation stacks; instrumented time and counts excluded from all performance claims.'};(p/'run.json').write_text(json.dumps(receipt,indent=2)+'\n')
subprocess.run(['python3',str(p/'archive.py'),'allocation-attribution',str(p/'run.json'),str(p/'run.stdout'),str(p/'run.stderr'),str(p/'retry.py'),str(p/'memory.rs'),str(p/'allocation_stacks.c'),str(p/'allocation_profile.rs'),str(p/'source-pin.json')],cwd=w,check=True)
q.check_returncode();assert len(rows)==3 and all(x['work']==60260219686 and x['capacity']==13 and x['exact_reference'] and x['independent_inflation'] for x in rows);assert q.stderr.endswith('CLEANUP bytes=0 nodes=0\n');print('OWNER CENSUS COMPLETE',len(rows),flush=True)
