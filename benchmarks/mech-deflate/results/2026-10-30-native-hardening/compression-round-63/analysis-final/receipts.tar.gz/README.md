# R63 current frame-shape guard harness — prepared, not executed

Baseline is accepted R62 after, with build source `ded89a9c0014fe66734be22ee6a3170e7ec10448` and reviewed checkpoint `a9a97af9861e9fa26532c8dc9d6b7ddd975a54f1`. Historical build records retain their original source identity; the checkpoint is not substituted as their build source.

This directory contains scratch-only scripts. No compiler, test, compressor, benchmark, Git mutation or public repository write has been performed during preparation. Running the scripts is the root agent's next authorized step; `archive.py` will write and commit compressed receipts only when executed by that root workflow.

## Exact dependency rebuild

`build-changed.py` uses the four retained R59 crate rustc command/environment receipts, in dependency order:

1. `/private/tmp/mech-cached-schema-key-round59-20261031/variants/after/mech_engine.json` → R63 `variants/after/build-mech_engine`.
2. `mech_compute.json` → `build-mech_compute`.
3. `mech_stdlib.json` → `build-mech_stdlib`.
4. `mech_runtime.json` → `build-mech_runtime`.
5. Accepted R62 `final-release.json` GPU rustc command → R63 `variants/after/libmech_gpu.rlib`.

Flags, features, toolchain, allocator link arguments and warnings-as-errors are retained. Current source paths remain in the authoritative checkout. Core, math, syntax, bytecode and all external crates are unchanged artifacts. Before compilation their hashes are checked against the R62 library and auxiliary manifests; after compilation every frozen overlay artifact is rehashed. The script stages a single dependency search overlay: unchanged project artifacts from R62's frozen graph, unchanged external artifacts from the retained Cargo dependency directory, and newly compiled Engine/Compute/Stdlib/Runtime outputs. All old dependency search paths are removed from the candidate crate commands. This prevents old Engine-dependent project libraries from being mixed into the rebuilt graph while avoiding a math rebuild. No Cargo operation is used.

The exact original dependency root is `/private/tmp/mech-pointer-locality-round62-20261031/variants/after/dependency`, which resolves to R59's immutable dependency graph. Original external artifacts are under `/private/tmp/mech-live-control-target/release/deps`. Output files and frozen inputs receive explicit hashes in `final-libraries.json`, `auxiliary-dependencies.json`, `frozen-inputs.json` and per-build receipts.

## Setup and serial execution

Wait for the owner's focused tests and final two-guard patch. Update `configuration.json` with that successful parent test receipt and any new GPU test filters/counts. Counts currently reflect the committed baseline: runtime 329 and CI 35, including the pointer-snapshot regression. Component 236, connected 8, path 1, scalar/frame controls and architecture selections are retained unchanged.

After reviewing/committing the exact source and tests, freeze the source delta:

```sh
python3 freeze-source.py ADDITIONAL_CHANGED_TEST_SOURCE_PATHS
python3 build-changed.py
python3 run-remaining.py
```

Pass only actual extra test/source paths to `freeze-source.py`. The two production files are already listed in configuration. The gate rejects any unreviewed source-file change or dirty worktree and records exact production/full source diff hashes. Test-driven count increases must identify the new tests.

`run-remaining.py` requires nonzero successful parent focused evidence, builds current GPU test source against the new graph, runs existing focused regressions plus configured new cases, and verifies the full runtime inventory. It then runs `run-cohorts.py` serially: fresh candidate emission/link/smoke; primary; counters; complete allocation census; Mech sampling; reference sampling. Full existing qualifications run afterward. No parallel build is scheduled during measurements.

## Image, program and timing preservation

The baseline linked worker, Object, descriptor and metadata are retained under symlinks to R62 after. Baseline provenance receipts are copied unchanged, including their original paths. Candidate `linked-build.py` emits a fresh Object/image/metadata and requires all three hashes and sizes to equal that baseline exactly before primary execution. Its normalized worker source must also agree.

Compressor source hash `331e659e92181d803b3d87218effe88f711c2e8ecad9f31838fc50991de1c5c9`, bytecode hash `a2a551911949f8c5fdc64273a43662c2a9c4953b853136c19d196692fdac45a7`, complete eight-byte computation, expected output, independent inflation, source allocation sites and capacities, output capacity 13/clear/reuse, pinned allocator and evaluate_into boundary are unchanged. Logical work remains 60,260,219,686.

Primary measurement retains four prepared executable pairs, sixteen alternating blocks per pair, 31 timed calls per block/variant and a newly measured 20,000-call reference. No historical elapsed samples are substituted. CPU, heap, census and CPU-time samples are separate cohorts. No speedup is assumed in these scripts.

## Allocation hypothesis and pending work

The baseline remains 8,173 requests, 98,228,396 requested bytes and 162 reallocations. Existing evidence attributes at most 68 requests/1,024 bytes to these shape-validation paths at five sites, predicting 8,105/98,227,372 if all are eliminated. This is a ceiling, not an observed result. The memory counter requires stable observed totals within each variant; only the baseline totals are fixed. The after census must reconcile exactly with the independently recorded after heap counter and all requests must symbolize. No separate instrumented branch variant is needed if the complete census establishes the precise family disappears. That establishes the executed family delta, not an invented per-branch trace.

Parent/candidate focused tests, actual build/tests, all measurement results, allocation family comparison, instruction/cycle comparisons, analysis/replay/report and retain/reject decision remain pending. No R62 result or contrary observation is relabeled as R63. R63-specific reporting should be written after those receipts exist.

The source gate now includes the frame-shape proof file as a third production file. The final parent Engine qualification directory is `engine-parent-constructor`; candidate is `engine-after-overlay`. Six `frame_shape::tests::` tests and the full_compiler/native-artifact/sequence_buffers profile are separately inventoried and executed. Initial dependency-search and malformed-schema-fixture failures remain distinct from the expected parent complete-axis assertion rejection. `host-manifest-note.json` records the harmless preflight alias; no running build script was changed.

Allocation-family provenance: `baseline/census.json` is the retained R62 census (ae2452719ce2d535ab0528d207d1cf9109da2d5b9b96f0ae3bbe449f5e3a1cee). It is historical attribution evidence, reconciled by total requests/bytes/reallocations with the freshly run R63 before heap cohort. The R63 candidate census is fresh. Primary, hardware counters, heap counters and samples are freshly executed on both variants; the historical baseline trace is explicitly separate.
