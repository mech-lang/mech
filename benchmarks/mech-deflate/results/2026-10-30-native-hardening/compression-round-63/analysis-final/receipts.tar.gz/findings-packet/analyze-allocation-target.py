#!/usr/bin/env python3
"""Reconstruct R62 frame-shape allocation families from the complete census.

Reads retained receipts only; never builds or runs a compiler/compressor.
"""
import collections
import hashlib
import json
from pathlib import Path
import re

ROOT = Path('/private/tmp/mech-pointer-locality-round62-20261031')
OUT = Path(__file__).parent
CENSUS = ROOT / 'sites-after/census.json'
data = json.loads(CENSUS.read_text())
sites = data['sites']


def contains(site, needle):
    return any(needle in frame for frame in site['frames'])


def summarize(indices):
    selected = [sites[index] for index in sorted(indices)]
    sizes = collections.Counter()
    for site in selected:
        sizes[(site['kind'], site['bytes_each'])] += site['count']
    return {
        'requests': sum(site['count'] for site in selected),
        'requested_bytes': sum(site['requested_bytes'] for site in selected),
        'unique_stacks': len(selected),
        'sizes': [{'kind': kind, 'bytes_each': size, 'count': count}
                  for (kind, size), count in sorted(sizes.items())],
        'census_indices': sorted(indices),
    }


flat = {i for i, site in enumerate(sites) if contains(site, 'admit_buffer_frame_inputs')}
composed = {i for i, site in enumerate(sites) if contains(site, 'admit_buffer_frame_composition')}
solver = {i for i, site in enumerate(sites) if contains(site, 'shape_for_resolved_extents')}
frame = flat | composed
assert not flat & composed
assert not frame & solver
assert all(contains(sites[i], 'FrameShapeRecipe8validate') for i in flat)
assert all('<deduplicated_symbol>' in sites[i]['frames'][2] for i in composed)
assert sum(site['count'] for site in sites) == data['requests'] == data['counter']['allocation_requests']
assert sum(site['requested_bytes'] for site in sites) == data['counter']['requested_bytes']

groups = collections.defaultdict(set)
for i in frame:
    entry = next(frame for frame in sites[i]['frames'] if 'mech_canonical_program_entry_v1' in frame)
    offset = int(re.search(r'\+ (\d+)$', entry)[1])
    groups[('flat' if i in flat else 'composed', offset)].add(i)

families = {'flat_frame_shape_validation': summarize(flat),
            'composed_frame_admission': summarize(composed),
            'combined_candidate_ceiling': summarize(frame),
            'separate_resolved_extent_solver': summarize(solver)}
report = {
    'scope': 'Allocation requests/bytes from one complete diagnostic invocation; not primary elapsed, retired instructions, all branch visits, or proved candidate eligibility.',
    'compiler_checkpoint': 'a9a97af9861e9fa26532c8dc9d6b7ddd975a54f1',
    'census': {'path': str(CENSUS), 'sha256': hashlib.sha256(CENSUS.read_bytes()).hexdigest(),
               'trace': data['trace'], 'requests': data['requests'],
               'requested_bytes': data['counter']['requested_bytes']},
    'families': families,
    'frame_solver_overlap': summarize(frame & solver),
    'entry_return_groups': [{'family': family, 'entry_return_offset': offset,
                             **summarize(indices)} for (family, offset), indices in sorted(groups.items())],
    'conditional_prediction_if_every_candidate_allocation_disappears': {
        'requests': data['requests'] - families['combined_candidate_ceiling']['requests'],
        'requested_bytes': data['counter']['requested_bytes'] - families['combined_candidate_ceiling']['requested_bytes'],
        'reallocations': data['counter']['reallocations'],
        'solver_requests_unchanged': families['separate_resolved_extent_solver']['requests'],
    },
    'qualification': [
        'Flat allocation stacks name FrameShapeRecipe::validate directly.',
        'Composed stacks identify the complete composition-admission ancestry, but the immediate allocation caller is deduplicated; shape-validation identity is a source/pattern inference.',
        'Nonempty output-parameter allocations identify five allocating validation visits. Zero-allocation validation visits and branch outcomes cannot be counted from this census.',
        'The complete_axes safety predicate may reduce eligibility;68 requests is a conditional ceiling until candidate census comparison.',
        'The preserved census executable pin points to a removed file; bounded disassembly failed without rebuilding.',
    ],
    'candidate_stacks': [{'census_index': i, **sites[i]} for i in sorted(frame)],
}
(OUT / 'allocation-families.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: report[key] for key in ('families', 'entry_return_groups', 'conditional_prediction_if_every_candidate_allocation_disappears')}, indent=2))
