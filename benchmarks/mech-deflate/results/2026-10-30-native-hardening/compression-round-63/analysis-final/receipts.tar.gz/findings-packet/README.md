# R63 frame-shape validation allocation target

This is an independent analysis of the complete retained R62 allocation census, reviewed against clean compiler HEAD `a9a97af9861e9fa26532c8dc9d6b7ddd975a54f1`. It executes no compiler or compressor and makes no elapsed-time prediction. `allocation-target-ledger.json` retains the census SHA-256, all eleven relevant full stacks, original program-entry return offsets, allocation sizes, input executable pin and exact counts.

## Exact observed family and conditional expectation

The R62 census contains8,173 successful allocation requests and98,228,396 requested bytes. All events reconcile with the separate counters retained in that census. Full stack ancestry identifies:

| Family | Requests | Requested bytes | Qualification |
|---|---:|---:|---|
| Flat private-frame shape validation |32|496|Stacks explicitly name `FrameShapeRecipe::validate`.|
| Composed private-frame admission |36|528|Complete composition ancestry is explicit; immediate allocation callee is deduplicated. Its shape-validation identity is a source/pattern inference.|
| Combined candidate ceiling |68|1,024|Eligibility remains conditional on the actual new predicate.|
| Separate output-shape solver |806|11,730|No overlap with either frame family.|

The68 requests consist of63 current-child parameter copies requesting512bytes and five temporary output-parameter arrays requesting512bytes. These requests use allocation/zeroed allocation; none are reallocations. Array lengths and the single output allocation in each source validation explain five allocating visits. Zero-allocation validation visits and branch outcomes are invisible to this census.

| Family | Generated-entry return offset | Requests | Bytes | Current-child copies | Output array |
|---|---:|---:|---:|---|---|
| Flat |83,108|21|336|19×8 +1×16 bytes|168 bytes|
| Flat |7,821,040|11|160|10×8 bytes|80 bytes|
| Composed |5,818,736|11|160|10×8 bytes|80 bytes|
| Composed |6,735,580|14|208|13×8 bytes|104 bytes|
| Composed |6,735,828|11|160|10×8 bytes|80 bytes|

These offsets identify return addresses in this exact R62 executable, not universal source IDs. Flat and composed sets are disjoint. Their intersection with the complete `shape_for_resolved_extents` ancestry is empty. That solver's806 requests include its own retained result array and temporaries; they must not be credited to this change.

**Conditional prediction:** if all68 candidate requests disappear and no other allocation changes occur, the next census should show8,105 requests and98,227,372 requested bytes. Reallocations should remain162 and the separate solver should remain806 requests/11,730bytes. This is a ceiling, not proof that all calls followed the ordinary footprint fallback or that the new guard accepts them.

The source review discovered a necessary restriction for nonmatrix fields with nested dimension parameters. The candidate's immutable `complete_axes` proof must keep unsupported cases on the existing validating path. The current compressor's matrix elements with closed records remain a candidate, but actual census comparison decides their allocation eligibility. Canonical construction, ordinary fallback, resource admission, errors and publication retain their existing semantics.

## Optional bounded diagnostic if the family delta is unexpected

No additional diagnostic build is needed merely to count allocations that demonstrably disappear. If the measured family delta differs from the expectation, add diagnostic-only fixed atomic counters separated into flat and composed paths:

1. Ordinary footprint fallback completed successfully.
2. Shape recipe present, including complete-axes eligible/ineligible.
3. `matches_current` returned true or false after successful fallback.
4. Existing `validate` entered and succeeded.
5. On fallback-success + complete-axes + match-true only: count nonempty current-child parameter arrays, output parameter array presence, and their total requested bytes.

Place the observation after the existing footprint loop completes and before the current shape gate. Leave the existing validation call and charge/reservation order intact in the diagnostic build. Use fixed `AtomicU64` counters with relaxed operations; reset and read them outside the evaluated invocation. Do not allocate trace strings, grow maps, capture stacks, or insert counters in each dimension expression. The optional request estimate is the number of nonempty child parameter slices plus one when the output parameter count is nonzero; bytes are eight times their total parameter lengths. Those counters measure branch eligibility; the allocation census alone measures saved requests and does not establish total visits.

## Provenance limits and failed command

The composed family's two immediate allocation return PCs are0x101c9200c and0x101c920e0, reported as a deduplicated callee at offsets324 and536. They account exclusively for33 child-copy requests/264bytes and three output arrays/264bytes under the composition admission ancestry. The complete outer ancestry is known; the unnamed leaf is not being presented as independently symbol-resolved.

A bounded disassembly attempt used:

```
xcrun llvm-objdump -d --no-show-raw-insn \
  --start-address=0x1014b1ec8 --stop-address=0x1014b23c8 \
  /private/tmp/mech-pointer-locality-round62-20261031/sites-after/memory-census
```

It exited1 because that retained executable had already been removed. Its original pin records170,118,656bytes and SHA-256 `45056b2e9a885230f8983e2f25261f5f7641f4613e3e470a0069cebd49ce3bb8`. This is an **environmental missing-artifact failure**, not a compiler or semantic failure. No rebuild was attempted. The JSON records the command and error explicitly.

This census is independent of the earlier ARM64 pointer-attribution correction. It also does not re-count the completed600-request schema-key optimization. `analyze-allocation-target.py` reproduces the allocation sets directly from the retained R62 census using full ancestry and checks both disjointness and counter reconciliation.
