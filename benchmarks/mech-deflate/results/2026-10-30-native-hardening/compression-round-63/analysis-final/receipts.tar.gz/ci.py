from pathlib import Path
import json,re,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'ci';p.mkdir(exist_ok=True)
configuration=json.loads((r/'configuration.json').read_text());expected=configuration['gpu_ci_expected']
selection=['locals_snapshot','composition_tests','parent_continuation_is_single_use','native_runtime_consolidation','buffer_frames::tests::batching','buffer_frames::tests::transfer','work::retirement::tests','exhausted_retirement_generation','cleanup_effects::tests','numeric_shadow','numeric_words::tests','numeric_first_change'];selection+=configuration['extra_gpu_test_filters'];unit=str(r/'units-after/gpu-unit-tests')
results=[json.loads((p/'workflow-python.json').read_text())];assert results[0]['exit']==0 and results[0]['executed_tests']==132
for label,flags in [('inventory',['--list']),('selected',['--nocapture','--test-threads=1'])]:
 cmd=[unit,*selection,*flags];at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True);(p/(label+'.stdout')).write_text(q.stdout);(p/(label+'.stderr')).write_text(q.stderr)
 row={'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'expected_tests':expected}
 if label=='inventory':row['listed_tests']=len(re.findall(r': test$',q.stdout,re.M));observed=row['listed_tests']
 else:
  m=re.search(r'test result: ok. (\d+) passed; 0 failed;',q.stdout);row['executed_tests']=int(m[1]) if m else None;observed=row['executed_tests']
 results.append(row);(p/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(label,row,flush=True)
 subprocess.run(['python3',str(r/'archive.py'),'ci-'+label,str(p/(label+'.stdout')),str(p/(label+'.stderr')),str(p/'results.json'),str(r/'ci.py')],cwd=w,check=True)
 if q.returncode:print(q.stdout[-2200:]+q.stderr[-2200:],flush=True)
 q.check_returncode();assert observed==expected,row
 if label=='inventory':assert 'numeric_words::tests::unit_dimension_addresses_emit_no_division_and_keep_general_geometry: test' in q.stdout

 if label=='inventory':assert 'delayed_numeric_first_changes_preserve_current_scalars_two_arrays_and_retry: test' in q.stdout

engine=str(r/'engine-after-overlay/engine-tests')
for label,flags in [('engine-inventory',['--list']),('engine-selected',['--nocapture','--test-threads=1'])]:
 cmd=[engine,'frame_shape::tests::',*flags];at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 row={'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'expected_tests':6,'features':'Retained Engine unit feature profile; CI schedules full_compiler,native-artifact,sequence_buffers. Actual retained rustc cfg list is in engine-after-overlay/build.json.'}
 if label=='engine-inventory':row['listed_tests']=len(re.findall(r': test$',q.stdout,re.M));observed=row['listed_tests']
 else:
  m=re.search(r'test result: ok. (\d+) passed; 0 failed;',q.stdout);row['executed_tests']=int(m[1]) if m else None;observed=row['executed_tests']
 (p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 subprocess.run(['python3',str(r/'archive.py'),'ci-'+label,str(p/(label+'.json')),str(p/(label+'.stdout')),str(p/(label+'.stderr')),str(r/'ci.py')],cwd=w,check=True)
 q.check_returncode();assert observed==6,row
