"""Execute the scheduled six Engine frame-shape tests from the retained feature profile."""
from pathlib import Path
import json,re,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'ci';p.mkdir(exist_ok=True)
root=r/'engine-after-overlay';base=json.loads((root/'build.json').read_text());assert base['exit']==0
required=['full_compiler','native-artifact','sequence_buffers']
for feature in required:assert 'feature="'+feature+'"' in base['command'],feature
for label,flags in [('inventory',['--list']),('selected',['--nocapture','--test-threads=1'])]:
 command=[str(root/'engine-tests'),'frame_shape::tests::',*flags];start=time.monotonic();q=subprocess.run(command,cwd=w,capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/('engine-'+label+'.'+stream)).write_text(getattr(q,stream))
 row={'command':command,'exit':q.returncode,'seconds':time.monotonic()-start,'expected_tests':6,'required_features':required,'build_receipt':'engine-after-overlay/build.json','test_source_head':base['test_source_head'],'scope':'Actual local execution of the newly scheduled Engine feature-profile selection; this is not a claim of completed remote CI.'}
 if label=='inventory':row['listed_tests']=len(re.findall(r': test$',q.stdout,re.M));observed=row['listed_tests']
 else:
  match=re.search(r'test result: ok. (\d+) passed; 0 failed;',q.stdout);row['executed_tests']=int(match[1]) if match else None;observed=row['executed_tests']
 (p/('engine-'+label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 subprocess.run(['python3',str(r/'archive.py'),'ci-engine-'+label,str(p/('engine-'+label+'.json')),str(p/('engine-'+label+'.stdout')),str(p/('engine-'+label+'.stderr')),str(r/'ci-engine.py')],cwd=w,check=True)
 print('ENGINE_CI',label,q.returncode,observed,flush=True)
 if q.returncode:print(q.stdout[-3000:]+q.stderr[-3000:],flush=True)
 q.check_returncode();assert observed==6,row
