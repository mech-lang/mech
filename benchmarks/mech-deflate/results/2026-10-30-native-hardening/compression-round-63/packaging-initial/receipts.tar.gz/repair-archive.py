from pathlib import Path
import hashlib,io,json,os,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');packet=w/'benchmarks/mech-deflate/results/2026-10-30-native-hardening/compression-round-63';p=r/'packaging-initial';p.mkdir()
archive=packet/'build-host/receipts.tar.gz';shutil.copy2(archive,p/'original-build-host-receipts.tar.gz')
shutil.copy2(r/'reconstruction.stderr',p/'replay.stderr')
manifest=json.loads((archive.parent/'manifest.json').read_text());pins={x['path']:x for x in manifest['files']}
repaired=[]
with tarfile.open(archive) as old,tarfile.open(str(archive)+'.new','w:gz') as new:
 for member in old:
  if member.isfile():data=old.extractfile(member).read()
  else:
   assert member.issym(),(member.name,member.type)
   data=(r/member.name).read_bytes();repaired.append({'path':member.name,'linkname':member.linkname})
  pin=pins[member.name];assert len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256']
  member.type=tarfile.REGTYPE;member.linkname='';member.size=len(data);new.addfile(member,io.BytesIO(data))
os.replace(str(archive)+'.new',archive)
# Keep this metadata file ordinary for subsequent consumers and archival.
f=r/'variants/after/host.json';data=f.read_bytes();f.unlink();f.write_bytes(data)
script=r/'archive.py';s=script.read_text();assert "tarfile.open(p/'receipts.tar.gz','w:gz')" in s;s=s.replace("tarfile.open(p/'receipts.tar.gz','w:gz')","tarfile.open(p/'receipts.tar.gz','w:gz',dereference=True)");script.write_text(s)
row={'command':['python3',str(packet/'reconstruct.py'),str(r/'replay-final')],'exit':1,'classification':'introduced receipt packaging','repaired':repaired,'disposition':'Root-created host metadata symlink was archived as a symlink rather than regular content. Preserve original archive and failure, replace that member with the exact manifest-hash-verified bytes, retain regular metadata, and dereference future archived inputs. No compiler, test or performance change.'};(p/'receipt.json').write_text(json.dumps(row,indent=2)+'\n')
f=r/'prior-failures.json';rows=json.loads(f.read_text());rows.append({'receipt':'packaging-initial/receipt.json','classification':row['classification'],'disposition':row['disposition']});f.write_text(json.dumps(rows,indent=2)+'\n')
subprocess.run(['python3',str(script),'packaging-initial',str(p),str(r/'repair-archive.py'),str(script)],check=True)
subprocess.run(['git','add',str(archive)],cwd=w,check=True);subprocess.run(['git','-c','gc.auto=0','commit','-m','Make host build receipt portable using its verified regular bytes'],cwd=w,check=True)
q=subprocess.run(['python3',str(r/'finalize-analysis.py')],capture_output=True,text=True);(r/'finalization.stdout').write_text(q.stdout);(r/'finalization.stderr').write_text(q.stderr);q.check_returncode()
paths=[str(r/x['path']) for x in json.loads((packet/'analysis-final/manifest.json').read_text())['files']]
subprocess.run(['python3',str(script),'analysis-portable',*paths,str(r/'runtime-execute.py'),str(r/'repair-archive.py')],check=True)
for name in ['analyze.py','allocation_analysis.py','binary_identity.py','validation.py','render-report.py','reconstruct.py','profile_analysis.py','finalize-analysis.py','allocation-families.json','profile-numbers.json','validation.json','binary-audit.json']:
 shutil.copy2(r/name,packet/name)
for name in ['scorecard.json','scorecard.csv']:shutil.copy2(r/'analysis'/name,packet/name)
shutil.copy2(r/'report.md',packet/'REPORT.md')
cmd=['python3',str(packet/'reconstruct.py'),str(r/'replay-portable')];q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
(r/'reconstruction-portable.stdout').write_text(q.stdout);(r/'reconstruction-portable.stderr').write_text(q.stderr)
print(q.stdout[-2000:]+q.stderr[-2000:],flush=True);q.check_returncode();d=json.loads(q.stdout);d.update(command=cmd,exit=q.returncode);(packet/'reconstruction.json').write_text(json.dumps(d,indent=2)+'\n')
