"""Rebuild the exact Engine-dependent graph; never rebuild frozen math/Core/syntax."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack')
old=Path('/private/tmp/mech-pointer-locality-round62-20261031');commands_root=Path('/private/tmp/mech-cached-schema-key-round59-20261031/variants/after')
p=r/'variants/after';dep=p/'dependency';sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
changed=['mech_engine','mech_compute','mech_stdlib','mech_runtime']
libs=json.loads((old/'final-libraries.json').read_text());old_aux=json.loads((old/'auxiliary-dependencies.json').read_text());gpu=json.loads((old/'final-release.json').read_text())
commands={name:json.loads((commands_root/(name+'.json')).read_text()) for name in changed}
for name,pin in libs.items():assert sha(pin['path'])==pin['sha256'],name
for pin in old_aux['files']:assert sha(pin['path'])==pin['sha256'],pin['path']
scope=json.loads((r/'source-scope.json').read_text());base=scope['baseline_checkpoint']
assert hashlib.sha256(subprocess.check_output(['git','diff',base,'--',*scope['production_files']],cwd=w)).hexdigest()==scope['production_diff_sha256']
assert hashlib.sha256(subprocess.check_output(['git','diff',base,'--','src','hosts/gpu/src'],cwd=w)).hexdigest()==scope['complete_source_diff_sha256']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
assert not (p/'libmech_gpu.rlib').exists(),'Never overwrite a candidate'
assert not any((p/('build-'+name)).exists() for name in changed),'Use a new named attempt after failure'
dep.mkdir(parents=True,exist_ok=True)
def changing(path):return any(path.name.startswith('lib'+name+'-') or path.name.startswith('lib'+name+'.') for name in changed+['mech_gpu'])
def link(path):
 target=dep/path.name
 if target.exists():assert target.resolve()==path.resolve() or sha(target)==sha(path),(target,path)
 else:target.symlink_to(path.resolve())
# One dependency search directory prevents old project libraries from being
# selected through the historical Cargo target. External crates remain frozen.
external_dirs={Path(a.split('=',1)[1]) for row in [*commands.values(),gpu] for a in row['command'] if a.startswith('dependency=') and '/mech-live-control-target/' in a}
for directory in sorted(external_dirs):
 for f in directory.iterdir():
  if f.is_file() and f.suffix in {'.rlib','.rmeta','.dylib','.so'} and not f.name.startswith('libmech_'):link(f)
for f in (old/'variants/after/dependency').iterdir():
 if f.is_file() and not changing(f):link(f)
# Explicit frozen libraries include plain-name math artifacts outside Cargo deps.
for name,pin in libs.items():
 if name not in changed+['mech_gpu']:link(Path(pin['path']))
frozen=[{'path':str(f),'sha256':sha(f),'bytes':f.stat().st_size,'resolved_path':str(f.resolve())} for f in sorted(dep.iterdir())]
(r/'frozen-inputs.json').write_text(json.dumps({'baseline':str(old),'files':frozen},indent=2)+'\n')
def remap(command):
 out=[];i=0
 while i<len(command):
  a=command[i]
  if a=='-L' and i+1<len(command) and command[i+1].startswith('dependency='):i+=2;continue
  if a=='--extern':
   key,path=command[i+1].split('=',1);target=dep/Path(path).name
   assert target.exists(),(key,path,target)
   out += [a,key+'='+str(target)];i+=2;continue
  out.append(a);i+=1
 out[1:1]=['-L','dependency='+str(dep)]
 return out
results=[]
def run(name,command,environment):
 start=time.monotonic();q=subprocess.run(command,cwd=w,env={**os.environ,**environment},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(name+'.'+stream)).write_text(getattr(q,stream))
 row={'command':command,'environment':environment,'source_head':head,'exit':q.returncode,'seconds':time.monotonic()-start,'scope':'Retained exact release flags/features/toolchain; frozen Core, math, syntax and external crates. Serial coherent Engine -> Compute/Stdlib/Runtime -> GPU rebuild.'}
 (p/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n');results.append(row)
 subprocess.run(['python3',str(r/'archive.py'),'build-'+name,str(p/(name+'.json')),str(p/(name+'.stdout')),str(p/(name+'.stderr')),str(r/'build-changed.py')],cwd=w,check=True)
 print('BUILD',name,q.returncode,row['seconds'],flush=True)
 if q.returncode:print(q.stderr[-7000:],flush=True)
 q.check_returncode();return row
for name in changed:
 row=commands[name];cmd=remap(row['command']);out=p/('build-'+name);out.mkdir();cmd[cmd.index('--out-dir')+1]=str(out)
 run(name,cmd,row['environment'])
 generated=[f for f in out.iterdir() if f.suffix in {'.rlib','.rmeta'}];assert len(generated)==2,(name,generated)
 for f in generated:shutil.copy2(f,dep/f.name)
cmd=remap(gpu['command']);assert cmd[-3]==str(w/'hosts/gpu/src/lib.rs') and cmd[-2]=='-o';cmd[-1]=str(p/'libmech_gpu.rlib');host=run('host',cmd,gpu['environment'])
for name,item in libs.items():
 target=p/'libmech_gpu.rlib' if name=='mech_gpu' else dep/Path(item['path']).name
 assert target.exists(),(name,target)
 item.update(path=str(target),sha256=sha(target))
for pin in frozen:assert sha(pin['path'])==pin['sha256'],pin['path']
for name in ['mech_core','mech_syntax']:
 assert libs[name]['sha256']==json.loads((old/'final-libraries.json').read_text())[name]['sha256']
assert any('libmech_math' in pin['path'] for pin in frozen),'Frozen math must be explicitly retained'
aux={'scope':'Coherent R63 Engine-dependent graph; immutable Core/math/syntax/external files retained by hash. No shared old Engine/Stdlib/Runtime/Compute artifacts on candidate dependency search path.','files':[{'path':str(f),'sha256':sha(f),'bytes':f.stat().st_size} for f in sorted(dep.iterdir()) if f.suffix in {'.rlib','.rmeta'} and f.name.startswith('libmech_')]}
implementation={'candidate_build_source':head,'baseline_build_source':gpu['source_head'],'baseline_checkpoint':base,'baseline_directory':str(old),'rebuilt_crates':changed+['mech_gpu'],'scope':'Existing flat/composed frame-shape guards plus preparation-only complete-axis proof. Unchanged compressor source, bytecode, source allocation sites, algorithm, resource pricing, allocator, output reuse and evaluate_into timing. Fresh Object/image/metadata must equal the retained R62 baseline byte-for-byte.','allocation_expectation':json.loads((r/'allocation-target.json').read_text())}
for target,data in [(p/'libraries.json',libs),(r/'final-libraries.json',libs),(r/'final-release.json',host),(r/'auxiliary-dependencies.json',aux),(p/'build-summary.json',{'source_head':head,'builds':results}),(r/'implementation.json',implementation)]:target.write_text(json.dumps(data,indent=2)+'\n')
subprocess.run(['python3',str(r/'archive.py'),'release-frozen',str(p/'libraries.json'),str(r/'final-release.json'),str(r/'auxiliary-dependencies.json'),str(r/'frozen-inputs.json'),str(p/'build-summary.json'),str(r/'implementation.json'),str(r/'allocation-target.json'),str(r/'source-scope.json'),str(r/'production.patch'),str(r/'source.patch'),str(r/'build-changed.py')],cwd=w,check=True)
print('COHERENT_R63_GRAPH',head,flush=True)
