from pathlib import Path
import hashlib,json,subprocess,time
r=Path(__file__).resolve().parent;p=r/'sites-after';w=Path('/private/tmp/mech-deflate-linear-stack');s=r
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
base=json.loads((s/'counters/after/memory-build.json').read_text())
for name,pin in base['libraries'].items():assert sha(pin['path'])==pin['sha256'],name
binding=json.loads((s/'linked-primary/after/binding.json').read_text())
for name,pin in binding['pins'].items():assert sha(s/'linked-primary/after'/name)==pin['sha256'],name
(p/'binding.json').write_text(json.dumps({'source':base['compiler_source'],'libraries':base['libraries'],'linked_binding':binding,'diagnostic_only':True,'scope':'All requests during second complete eight-byte evaluate_into; unchanged optimized libraries, Object/image, source, allocator and timer.'},indent=2)+'\n')
active=subprocess.check_output(['ps','-Ao','comm='],text=True).splitlines();assert not [x for x in active if Path(x.strip()).name in {'rustc','cargo','tests','gpu-unit-tests','worker','roc-profile','native_frame_transport'}]
env=subprocess.check_output(['ps','-Ao','pid,ppid,etime,%cpu,rss,comm'],text=True);(p/'environment-before.txt').write_text(env)
source=(s/'counters/after/memory.rs').read_text().replace(str(s/'counters/allocation_profile.rs'),str(p/'allocation_profile.rs'));(p/'memory.rs').write_text(source)
def archive(stage,files):subprocess.run(['python3',str(r/'archive.py'),'sites-after-'+stage,*map(str,files)],cwd=w,check=True)
def run(name,cmd):
 at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(name+'.'+stream)).write_text(getattr(q,stream))
 (p/(name+'.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'elapsed_seconds':time.monotonic()-at},indent=2)+'\n')
 archive(name,[p/(name+ext) for ext in ['.json','.stdout','.stderr']]+[r/'sites-after.py',p/'allocation_sites.c',p/'allocation_profile.rs',p/'allocation_profile.h',p/'usage.c',p/'usage.h',p/'memory.rs',p/'binding.json',p/'environment-before.txt',p/'probe-pin.json'])
 print(name,q.returncode,flush=True)
 if q.returncode:print(q.stderr[-5000:],flush=True)
 q.check_returncode();return q
if (p/'sites.o').exists():
 pin=json.loads((p/'probe-pin.json').read_text());assert pin['exit']==0 and sha(p/'sites.o')==pin['object_sha256'] and sha(p/'allocation_sites.c')==pin['source_sha256'] and sha(p/'allocation_profile.h')==pin['header_sha256']
else:
 run('probe-build',['clang','-O3','-std=c11','-Wall','-Wextra','-Werror','-DPROBE_MEMORY=1','-I/private/tmp/mech-deep-profile-20261030/include','-I'+str(p),'-c',str(p/'allocation_sites.c'),'-o',str(p/'sites.o')])
cmd=base['command'].copy();cmd[cmd.index('link-arg='+str(s/'counters/memory_profile.o'))]='link-arg='+str(p/'sites.o');cmd[-3]=str(p/'memory.rs');cmd[-1]=str(p/'memory-census')
run('consumer-build',cmd)
(p/'consumer-pin.json').write_text(json.dumps({'path':str(p/'memory-census'),'sha256':sha(p/'memory-census'),'bytes':(p/'memory-census').stat().st_size},indent=2)+'\n')
q=run('run',[str(p/'memory-census'),'/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc','1'])
rows=[json.loads(x) for x in q.stdout.splitlines() if x.startswith('{')];assert len(rows)==3 and all(x['exact_reference'] and x['independent_inflation'] and x['work']==60260219686 and x['capacity']==13 for x in rows)
assert q.stderr.endswith('CLEANUP bytes=0 nodes=0\n')
traces=[json.loads(x.removeprefix('ALLOC_TRACE ')) for x in q.stderr.splitlines() if x.startswith('ALLOC_TRACE ')];events=[json.loads(x.removeprefix('ALLOC_EVENT ')) for x in q.stderr.splitlines() if x.startswith('ALLOC_EVENT ')];stats=[json.loads(x.removeprefix('ALLOC_PROBE ')) for x in q.stderr.splitlines() if x.startswith('ALLOC_PROBE ')];assert len(traces)==1 and len(stats)==3
assert len(events)==traces[0]['events']==stats[1]['allocation_requests']
assert sum(e['bytes'] for e in events)==stats[1]['requested_bytes']
assert sum(e['kind']=='realloc' for e in events)==stats[1]['reallocations']
expected=[json.loads(x.removeprefix('ALLOC_PROBE ')) for x in (r/'counters/after-memory/run.stderr').read_text().splitlines() if x.startswith('ALLOC_PROBE ')][1]
for key in ['allocation_requests','requested_bytes','reallocations']:assert stats[1][key]==expected[key],key
assert len(events)==json.loads((r/'allocation-observed.json').read_text())['allocation_requests']
pcs=sorted({pc for e in events for pc in e['pcs']});symbols={};commands=[]
for i in range(0,len(pcs),64):
 chunk=pcs[i:i+64];cmd=['atos','-o',str(p/'memory-census'),'-l',traces[0]['image_load'],*chunk];z=subprocess.run(cmd,capture_output=True,text=True,check=True);lines=z.stdout.splitlines();assert len(lines)==len(chunk);symbols.update(zip(chunk,lines));commands.append({'command':cmd,'stderr':z.stderr,'exit':z.returncode})
(p/'symbols.json').write_text(json.dumps(symbols,indent=2)+'\n');(p/'symbolize.json').write_text(json.dumps(commands,indent=2)+'\n')
from collections import Counter
sizes=Counter();sites=Counter();bytes_by_site=Counter();site_meta={}
for e in events:
 sizes[(e['kind'],e['bytes'])]+=1
 frames=tuple(symbols[pc] for pc in e['pcs']);key=(e['kind'],e['bytes'],frames);sites[key]+=1;bytes_by_site[key]+=e['bytes'];site_meta[key]=e['pcs']
top=[{'kind':key[0],'bytes_each':key[1],'count':n,'requested_bytes':bytes_by_site[key],'frames':list(key[2]),'pcs':site_meta[key]} for key,n in sites.most_common()]
summary={'trace':traces[0],'counter':stats[1],'requests':len(events),'unique_stacks_with_size_and_kind':len(top),'unique_pcs':len(pcs),'sizes':[{'kind':k[0],'bytes_each':k[1],'count':n,'requested_bytes':k[1]*n} for k,n in sizes.most_common()],'sites':top}
assert sum(x['count'] for x in summary['sites'])==len(events)
(p/'census.json').write_text(json.dumps(summary,indent=2)+'\n');archive('attribution',[p/'census.json',p/'symbols.json',p/'symbolize.json',p/'consumer-pin.json',r/'sites-after.py'])
print('CENSUS',json.dumps({'requests':len(events),'sites':len(top),'pcs':len(pcs),'top':[{'count':x['count'],'bytes_each':x['bytes_each'],'frames':x['frames'][:10]} for x in top[:0]]}),flush=True)

(p/'memory-census').unlink()
