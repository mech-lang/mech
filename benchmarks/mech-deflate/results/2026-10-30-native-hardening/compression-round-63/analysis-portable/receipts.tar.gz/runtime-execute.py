from pathlib import Path
import json,re,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'units-after'
expected=json.loads((r/'configuration.json').read_text())['gpu_runtime_expected']
cmd=[str(p/'gpu-unit-tests'),'native_artifact::program::runtime::','--skip','complete_unchanged_knucleotide_body_uses_the_owned_emitted_map','--nocapture','--test-threads=1']
at=time.monotonic()
with (p/'runtime.stdout').open('w') as out,(p/'runtime.stderr').open('w') as err:q=subprocess.run(cmd,cwd=w,stdout=out,stderr=err)
s=(p/'runtime.stdout').read_text();m=re.search(r'test result: (?:ok|FAILED). (\d+) passed; (\d+) failed;',s)
row={'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'expected_tests':expected,'executed_tests':int(m[1])+int(m[2]) if m else None,'passed_tests':int(m[1]) if m else None,'failed_tests':int(m[2]) if m else None,'compiler_source':json.loads((r/'final-release.json').read_text())['source_head'],'production_dependencies':str(r/'final-libraries.json'),'scope':'Fresh current GPU runtime execution, including snapshot regression. Existing reduced-catalog knucleotide exclusion retained; no inventory substituted for execution.'}
(p/'runtime.json').write_text(json.dumps(row,indent=2)+'\n')
subprocess.run(['python3',str(r/'archive.py'),'qualification-runtime',str(p/'runtime.json'),str(p/'runtime.stdout'),str(p/'runtime.stderr'),str(r/'runtime-execute.py')],cwd=w,check=True)
print(json.dumps(row),flush=True)
if q.returncode:print(s[-5000:]+(p/'runtime.stderr').read_text()[-5000:],flush=True)
q.check_returncode();assert row['executed_tests']==expected and row['failed_tests']==0
