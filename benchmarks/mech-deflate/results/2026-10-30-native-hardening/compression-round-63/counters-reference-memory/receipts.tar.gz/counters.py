from pathlib import Path
import hashlib,json,shutil,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');root=r/'counters';root.mkdir();old=Path('/private/tmp/mech-buffer-ownership-round38-20261030/diagnostics');deep=Path('/private/tmp/mech-deep-profile-20261030')
for name in ['usage.c','usage.h','cpu_usage.rs','allocation_profile.c','allocation_profile.h','allocation_profile.rs','usage.o','memory_profile.o']:shutil.copy2(old/name,root/name)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();builds={}
for label in ['before','after']:
 p=root/label;p.mkdir();binding=r/'linked-primary'/label;meta=json.loads((binding/'metadata.json').read_text());base=json.loads((binding/'worker-build.json').read_text());libs=base['libraries']
 for i,a in enumerate(base['command']):
  if a.startswith('link-arg=') and a.endswith('/object.o'):base['command'][i]='link-arg='+str(binding/'object.o')
 prefix='unsafe extern "C" {\n #[link_name="'+meta['identity_symbol']+'"] static LINKED_IDENTITY:[u8;mech_gpu::native_artifact::NATIVE_PROGRAM_LINK_IDENTITY_BYTES];\n #[link_name="'+meta['entry_symbol']+'"] fn linked_entry(frame:*mut std::ffi::c_void)->u64;\n}\n'
 needle='let jit=JitProgramArtifact::compile_with_limits(&artifact,&catalog,mode.compilation()).unwrap();'
 replacement='// SAFETY: binding.json pins this exact unchanged same-build Object/image, libraries and allocator; linked symbols remain live.\n let jit=unsafe {mech_gpu::native_artifact::LinkedProgramArtifact::from_build_owned_image(include_bytes!("'+str(binding/'descriptor.json')+'"),&catalog,&LINKED_IDENTITY,linked_entry)}.unwrap();'
 for kind in ['cpu','memory']:
  source=(old/(kind+'.rs')).read_text().replace(str(old),str(root));assert source.count(needle)==1;source=prefix+source.replace(needle,replacement).replace('"phase":"compiled"','"phase":"linked-compressor-image-restored"');f=p/(kind+'.rs');f.write_text(source)
  cmd=base['command'].copy();cmd[-3]=str(f);cmd[-1]=str(p/kind);extra=['-C','link-arg='+str(root/'usage.o')]
  if kind=='memory':extra+=['-C','link-arg='+str(root/'memory_profile.o')]
  cmd[-3:-3]=extra;builds[label+'-'+kind]=(cmd,p,base)
active=subprocess.check_output(['ps','-Ao','comm='],text=True).splitlines();assert not [x for x in active if Path(x.strip()).name in {'rustc','cargo','tests','gpu-unit-tests','worker','roc-profile','native_frame_transport'}]
artifact='/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc'
jobs=[('reference-cpu',deep/'reference-cpu',['12'],32),('before-cpu',root/'before/cpu',[artifact,'32'],34),('after-cpu',root/'after/cpu',[artifact,'32'],34),('reference-memory',deep/'reference-memory',['12'],32),('before-memory',root/'before/memory',[artifact,'8'],10),('after-memory',root/'after/memory',[artifact,'8'],10)]
for name,binary,args,count in jobs:
 if name in builds:
  cmd,p,base=builds[name];kind=name.rsplit('-',1)[1];at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
  for stream in ['stdout','stderr']:(p/(kind+'-build.'+stream)).write_text(getattr(q,stream))
  (p/(kind+'-build.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'libraries':base['libraries'],'compiler_source':base['compiler_source'],'auxiliary_dependencies':base['auxiliary_dependencies']},indent=2)+'\n')
  if q.returncode:print(q.stderr[-4000:],flush=True)
  q.check_returncode()
 p=root/name;p.mkdir();cmd=[str(binary),*args];at=time.monotonic()
 with (p/'run.stdout').open('w') as out,(p/'run.stderr').open('w') as err:q=subprocess.run(cmd,cwd=w,stdout=out,stderr=err)
 (p/'run.json').write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'binary_sha256':sha(binary),'scope':'Same respective coherent optimized libraries and same-build Object/images as primary. Separate CPU/memory cohorts; all instrumented elapsed is excluded from primary.'},indent=2)+'\n');q.check_returncode();out=(p/'run.stdout').read_text();err=(p/'run.stderr').read_text()
 if name.startswith('reference'):
  rows=[json.loads(line.removeprefix('ALLOC_PROBE ')) for line in err.splitlines() if line.startswith('ALLOC_PROBE ')];assert len(rows)==count and out.count('rep\troc-deflate\t')==20000
 else:
  label,kind=name.rsplit('-',1);rows=[json.loads(line) for line in out.splitlines() if line.startswith('{')];assert len(rows)==count and all(row['exact_reference'] and row['independent_inflation'] and row['capacity']==13 and row['work']==60260219686 for row in rows);assert err.endswith('CLEANUP bytes=0 nodes=0\n')
 if name in ['before-memory','after-memory']:
  allocations=[json.loads(line.removeprefix('ALLOC_PROBE ')) for line in err.splitlines() if line.startswith('ALLOC_PROBE ')]
  assert len(allocations)==10 and len(allocations[1:])==9
  observed={(row['allocation_requests'],row['requested_bytes'],row['reallocations']) for row in allocations[1:]}
  assert len(observed)==1,(name,observed)
  if name=='before-memory':assert observed=={(8173,98228396,162)},observed
  else:(r/'allocation-observed.json').write_text(json.dumps({'allocation_requests':allocations[1]['allocation_requests'],'requested_bytes':allocations[1]['requested_bytes'],'reallocations':allocations[1]['reallocations'],'diagnostic_only':True,'expectation':json.loads((r/'allocation-target.json').read_text())},indent=2)+'\n')
 files=[p,r/'counters.py']+[root/n for n in ['usage.c','usage.h','cpu_usage.rs','allocation_profile.c','allocation_profile.h','allocation_profile.rs']]
 if not name.startswith('reference'):files += [root/label/(kind+suffix) for suffix in ['.rs','-build.json','-build.stdout','-build.stderr']]
 subprocess.run(['python3',str(r/'archive.py'),'counters-'+name,*map(str,files)],cwd=w,check=True);print(name,'COMPLETE',len(rows),flush=True)
 if not name.startswith('reference'):binary.unlink()
