"""Compile focused Engine tests with current frozen dependencies, then qualify."""
from pathlib import Path
import hashlib,json,os,re,subprocess,sys,tarfile,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack')
phase=sys.argv[1];assert phase in ['parent','after']
p=r/('engine-'+phase);p.mkdir()
baseline='a9a97af9861e9fa26532c8dc9d6b7ddd975a54f1'
files=['native_collection_buffer_frames.rs','native_collection_frame_composition.rs','native_collection_frame_shape.rs']
source_root=w/'src/engine/src/resident/general'
candidate={name:(source_root/name).read_bytes() for name in files}
prior={name:subprocess.check_output(['git','show',baseline+':src/engine/src/resident/general/'+name],cwd=w) for name in files}
marker=b'#[cfg(test)]\nmod tests {'
shape='native_collection_frame_shape.rs'
tests=candidate[shape][candidate[shape].index(marker):candidate[shape].rindex(b'\nimpl FrameShapeRecipe {')]
prior[shape]=prior[shape][:prior[shape].index(marker)]+tests+prior[shape][prior[shape].rindex(b'\nimpl FrameShapeRecipe {'):]
with tarfile.open(w/'benchmarks/mech-deflate/results/2026-10-30-native-hardening/compression-round-42/unit-engine-build/receipts.tar.gz') as tar:
 base=json.load(tar.extractfile('units/engine-build.json'))
old=Path('/private/tmp/mech-pointer-locality-round62-20261031')
libs=json.loads(((old if phase=='parent' else r)/'final-libraries.json').read_text())
dep=(old if phase=='parent' else r)/'variants/after/dependency'
cmd=base['command'].copy();cmd[-3]=str(w/'src/engine/src/lib.rs');cmd[-1]=str(p/'engine-tests')
for i,a in enumerate(cmd):
 if i and cmd[i-1]=='--extern':
  name,path=a.split('=',1);target=Path(libs[name]['path']) if name in libs else dep/Path(path).name
  if target.exists():cmd[i]=name+'='+str(target)
for i in range(len(cmd)-1,0,-1):
 if cmd[i].startswith('dependency=') and cmd[i-1]=='-L':del cmd[i-1:i+1]
cmd[1:1]=['-L','dependency='+str(dep)]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip()
env=base['environment'];env['CARGO_MANIFEST_DIR']=str(w/'src/engine')
current=prior if phase=='parent' else candidate
for name,data in current.items():(p/name).write_bytes(data)
def run(name,command,count=None,inventory=False,expected_exit=0):
 start=time.monotonic();q=subprocess.run(command,cwd=w,env={**os.environ,**env},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(name+'.'+stream)).write_text(getattr(q,stream))
 row={'command':command,'environment':env,'exit':q.returncode,'expected_exit':expected_exit,'seconds':time.monotonic()-start,'phase':phase,'test_source_head':head,'baseline_checkpoint':baseline,'libraries':libs,'production_source_sha256':{n:hashlib.sha256(data).hexdigest() for n,data in current.items()},'scope':'Retained Engine unit opt0 warnings-as-errors features; parent production with current focused tests, or candidate production. Frozen Core/math/syntax dependencies; no benchmark timing.'}
 if count is not None:
  if inventory:row['listed_tests']=len(re.findall(r': test$',q.stdout,re.M));observed=row['listed_tests']
  else:
   m=re.search(r'test result: (?:ok|FAILED). (\d+) passed; (\d+) failed;',q.stdout);row['passed_tests']=int(m[1]) if m else None;row['failed_tests']=int(m[2]) if m else None;row['executed_tests']=int(m[1])+int(m[2]) if m else None;observed=row['executed_tests']
  row['expected_tests']=count
 (p/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 subprocess.run(['python3',str(r/'archive.py'),'engine-'+phase+'-'+name,*map(str,[p/(name+'.'+s) for s in ['json','stdout','stderr']]),str(r/'engine-focused.py'),*map(str,[p/n for n in files])],cwd=w,check=True)
 print(phase,name,q.returncode,row.get('executed_tests',row.get('listed_tests')),flush=True)
 if q.returncode!=expected_exit:print(q.stdout[-5000:]+q.stderr[-6000:],flush=True)
 assert q.returncode==expected_exit,(name,q.returncode)
 if count is not None:assert observed==count,(name,row)
try:
 for name,data in current.items():(source_root/name).write_bytes(data)
 run('build',cmd)
finally:
 for name,data in candidate.items():(source_root/name).write_bytes(data)
for label,filter,exit in [('caller','ordinary_frame_fallback_preserves_nested_output_overflow_and_retry',0),('opaque','opaque_record_matrices_keep_fresh_shape_relations_without_footprint_recipe',0),('coverage','frame_shape_guard_preserves_nested_output_overflow_after_fallback',101 if phase=='parent' else 0)]:
 run(label+'-inventory',[cmd[-1],filter,'--list'],1,True)
 run(label,[cmd[-1],filter,'--nocapture','--test-threads=1'],1,expected_exit=exit)
if phase=='after':
 run('all-inventory',[cmd[-1],'native_collection_prepared::frame_shape::tests::','--list'],6,True)
 run('all',[cmd[-1],'native_collection_prepared::frame_shape::tests::','--nocapture','--test-threads=1'],6)
print('ENGINE_FOCUSED_DONE',phase,flush=True)
