from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/mech-unique-admission-round48-20261031');before=json.loads((old/'final-libraries.json').read_text());p=r/'variants/after';p.mkdir(parents=True);b=json.loads((old/'final-release.json').read_text());source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip()
for info in before.values():assert hashlib.sha256(Path(info['path']).read_bytes()).hexdigest()==info['sha256']
(r/'variants/before').mkdir();(r/'variants/before/libraries.json').write_text(json.dumps(before,indent=2)+'\n')
cmd=b['command'].copy();cmd[-1]=str(p/'libmech_gpu.rlib');t=time.monotonic();q=subprocess.run(cmd,cwd=w,env={**os.environ,**b['environment']},capture_output=True,text=True)
for stream in ['stdout','stderr']:(p/('build.'+stream)).write_text(getattr(q,stream))
row={'command':cmd,'environment':b['environment'],'cwd':str(w),'source_head':source,'exit':q.returncode,'seconds':time.monotonic()-t,'profile':'Exactly retained optimized GPU flags/features against the same immutable round-48 Core/Engine/Stdlib/Compute and common dependencies; only GPU cleanup execution changes. Test-only counters compile out.'};(p/'build.json').write_text(json.dumps(row,indent=2)+'\n')
subprocess.run(['python3',str(r/'archive.py'),'release-build',str(p/'build.json'),str(p/'build.stdout'),str(p/'build.stderr'),str(r/'build.py')],cwd=w,check=True)
if q.returncode:print(q.stderr[-7000:],flush=True)
q.check_returncode();after={**before,'mech_gpu':{**before['mech_gpu'],'path':str(p/'libmech_gpu.rlib'),'sha256':hashlib.sha256((p/'libmech_gpu.rlib').read_bytes()).hexdigest()}}
(p/'libraries.json').write_text(json.dumps(after,indent=2)+'\n');(r/'final-libraries.json').write_text(json.dumps(after,indent=2)+'\n');(r/'final-release.json').write_text(json.dumps(row,indent=2)+'\n');(r/'frozen-compute').symlink_to(old/'variants/after/dependency',target_is_directory=True);(p/'dependency').symlink_to(old/'variants/after/dependency',target_is_directory=True)
aux=json.loads((old/'auxiliary-dependencies.json').read_text());(r/'auxiliary-dependencies.json').write_text(json.dumps(aux,indent=2)+'\n')
subprocess.run(['python3',str(r/'archive.py'),'release-pins',str(r/'final-libraries.json'),str(r/'final-release.json'),str(r/'auxiliary-dependencies.json'),str(r/'variants/before/libraries.json')],cwd=w,check=True)
print('GPU RELEASE COMPLETE',row['seconds'],flush=True)
