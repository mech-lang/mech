//! Original ordered lexical cleanup, shared by ordinary tail boundaries.
use super::*;
use std::sync::atomic::{AtomicU64, Ordering};
// Isolated mechanism counters, excluded from all performance claims.
static CLEANUP_COUNTS: [AtomicU64; 6] = [const { AtomicU64::new(0) }; 6];
fn note(index: usize, amount: u64) { CLEANUP_COUNTS[index].fetch_add(amount, Ordering::Relaxed); }
// SAFETY: unique isolated-build symbols expose counters only, never pointers or authority.
#[unsafe(no_mangle)]
extern "C" fn mech_cleanup_domain_probe_reset() {
    for count in &CLEANUP_COUNTS { count.store(0, Ordering::Relaxed); }
}
// SAFETY: paired with the isolated counter reset above.
#[unsafe(no_mangle)]
extern "C" fn mech_cleanup_domain_probe_get(index: u32) -> u64 {
    CLEANUP_COUNTS.get(index as usize).map_or(u64::MAX, |n| n.load(Ordering::Relaxed))
}

use crate::native_artifact::program::prepare::frame_retirement::FrameRetirements;

pub(super) fn run(
    slots: &[u64],
    recipes: &FrameRetirements,
    frames: &mut buffer_frames::BufferFrames,
    arena: &mut NativeValueArena<'_>,
    work: &mut NativeWorkMeter,
) -> Result<bool, NativeProgramExecutionError> {
    work.charge(NativeExecutionPhase::Setup, amount(slots.len(), 16, 64)?)?;
    // The original scan price is paid first. Preview only current validity and
    // immutable recipe costs; an unsupported or denied group stays ordered.
    if let Some((total, charges)) = preview(slots, recipes, frames, arena, work)
        && charges > 1
        && let Some(mut paid) = work.try_retirement_batch(total)
    {
        note(0, 1);
        note(1, slots.len() as u64);
        for &slot in slots {
            if frames.retire_prepaid(recipes, slot as u32, &mut paid)? {
                // The same batch preview checked this selected container's
                // canonical slot is empty. Only its frame can hold storage;
                // retain the original arena price on the existing paid loan.
                note(2, 1);
                paid.pay(32)?;
            } else {
                note(3, 1);
                arena.retire_current_prepaid(slot as u32, &mut paid)?;
            }
        }
        paid.finish()?;
        #[cfg(all(test, feature = "canonical-native-program"))]
        BATCHES.with(|count| count.set(count.get() + 1));
        return Ok(true);
    }
    note(4, 1);
    for &slot in slots {
        frames.retire(recipes, slot as u32, work)?;
        arena.retire_current(slot as u32, work)?;
    }
    Ok(false)
}

fn preview(
    slots: &[u64],
    recipes: &FrameRetirements,
    frames: &buffer_frames::BufferFrames,
    arena: &NativeValueArena<'_>,
    work: &NativeWorkMeter,
) -> Option<(u64, usize)> {
    let mut total = 0u64;
    let mut charges = slots.len();
    for &slot in slots {
        let slot = u32::try_from(slot).ok()?;
        if let Some((charge, _)) = recipes.get(slot as usize) {
            // This recipe is derived only for selected frame containers, not
            // their projected canonical fields. An unexpected canonical
            // definition conservatively keeps the entire original ordered path.
            if !frames.has_retirement_backing() { return None; }
            if arena.native_entry_preview(slot, work).ok()?.is_some() {
                note(5, 1);
                return None;
            }
            total = total.checked_add(charge)?;
            charges = charges.checked_add(1)?;
        } else if !arena.native_retirement_available(slot, work).ok()? {
            return None;
        }
        total = total.checked_add(32)?;
    }
    Some((total, charges))
}

#[cfg(all(test, feature = "canonical-native-program"))]
thread_local! {
    static BATCHES: std::cell::Cell<u64> = const { std::cell::Cell::new(0) };
}

#[cfg(all(test, feature = "canonical-native-program"))]
pub(super) fn take_observation() -> u64 {
    BATCHES.with(|count| count.replace(0))
}
