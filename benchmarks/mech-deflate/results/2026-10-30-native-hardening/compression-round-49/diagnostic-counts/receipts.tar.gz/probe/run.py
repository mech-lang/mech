from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).resolve().parent;r=p.parent;w=Path('/private/tmp/mech-deflate-linear-stack');b=json.loads((r/'final-release.json').read_text());libs=json.loads((r/'final-libraries.json').read_text());cmd=b['command'].copy();cmd[-3]=str(p/'source/lib.rs');cmd[-1]=str(p/'variants/after/libmech_gpu.rlib');at=time.monotonic();q=subprocess.run(cmd,cwd=w,env={**os.environ,**b['environment']},capture_output=True,text=True)
for stream in ['stdout','stderr']:(p/('build.'+stream)).write_text(getattr(q,stream))
receipt={**b,'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'profile':'Isolated GPU source overlay with six counters; excluded from every performance comparison. All other dependencies and flags match the retained candidate.'};(p/'variants/after/build.json').write_text(json.dumps(receipt,indent=2)+'\n')
subprocess.run(['python3',str(p/'archive.py'),'build',str(p/'variants/after/build.json'),str(p/'build.stdout'),str(p/'build.stderr'),str(p/'source/native_artifact/program/runtime/retirement.rs'),str(p/'source-pin.json'),str(p/'run.py')],cwd=w,check=True)
if q.returncode:print(q.stderr[-6000:],flush=True)
q.check_returncode();libs['mech_gpu']={**libs['mech_gpu'],'path':str(p/'variants/after/libmech_gpu.rlib'),'sha256':hashlib.sha256((p/'variants/after/libmech_gpu.rlib').read_bytes()).hexdigest()};(p/'variants/after/libraries.json').write_text(json.dumps(libs,indent=2)+'\n')
subprocess.run(['python3',str(p/'linked-build.py'),'after'],cwd=w,check=True)
f=p/'linked-primary/after';s=(f/'worker.rs').read_text();i=s.index('use mech_core::');s=s[:i]+'''// SAFETY: these counter-only symbols belong to this exact isolated GPU build.
unsafe extern "C" { fn mech_cleanup_domain_probe_reset(); fn mech_cleanup_domain_probe_get(index:u32)->u64; }
fn cleanup_counts()->[u64;6]{std::array::from_fn(|i|unsafe{mech_cleanup_domain_probe_get(i as u32)})}
'''+s[i:];needle='eprintln!("MEASURING {sample}");let start=';assert s.count(needle)==1;s=s.replace(needle,'unsafe{mech_cleanup_domain_probe_reset()};'+needle);needle='"work":report.work';assert s.count(needle)==1;s=s.replace(needle,'"cleanup_counts":cleanup_counts(),"comparison_work":report.comparison_work,"work":report.work');(f/'counter-worker.rs').write_text(s)
b=json.loads((f/'worker-build.json').read_text());cmd=b['command'].copy();cmd[-3]=str(f/'counter-worker.rs');cmd[-1]=str(f/'counter-worker');at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
for stream in ['stdout','stderr']:(f/('counter-build.'+stream)).write_text(getattr(q,stream))
(f/'counter-build.json').write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'libraries':libs,'scope':'Same respective isolated probe graph and fresh same-build Object/image.'},indent=2)+'\n')
if q.returncode:print(q.stderr[-5000:],flush=True)
q.check_returncode();cmd=[str(f/'counter-worker'),'/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc','8'];q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
for stream in ['stdout','stderr']:(f/('counter-run.'+stream)).write_text(getattr(q,stream))
rows=[json.loads(x) for x in q.stdout.splitlines() if x.startswith('{')];assert q.returncode==0,q.stderr;assert len(rows)==10
for row in rows:
 assert row['exact_reference'] and row['independent_inflation'] and row['work']==60260219686 and row['comparison_work']==47612 and row['capacity']==13
 batches,slots,omitted,canonical,ordered,unexpected=row['cleanup_counts'];assert slots==omitted+canonical and omitted>0 and unexpected==0
assert all(row['cleanup_counts']==rows[1]['cleanup_counts'] for row in rows[1:-1]);assert q.stderr.endswith('CLEANUP bytes=0 nodes=0\n')
result={'command':cmd,'exit':q.returncode,'observations':8,'counter_names':json.loads((p/'source-pin.json').read_text())['counter_names'],'counts':rows[1]['cleanup_counts'],'scope':'Exact mechanism count during complete eight-byte level-12 evaluation. Isolated instrumented source overlay, excluded from all timing/counter/allocation comparisons; no main-checkout source mutation.','retained_logical_work':60260219686,'comparison_work':47612,'performance_claimed':False};(p/'result.json').write_text(json.dumps(result,indent=2)+'\n')
subprocess.run(['python3',str(p/'archive.py'),'counts',str(p/'result.json'),str(f/'counter-worker.rs'),str(f/'counter-build.json'),str(f/'counter-build.stdout'),str(f/'counter-build.stderr'),str(f/'counter-run.stdout'),str(f/'counter-run.stderr'),str(p/'run.py')],cwd=w,check=True)
print('ACTUAL CLEANUP COUNTS',json.dumps(result),flush=True)
