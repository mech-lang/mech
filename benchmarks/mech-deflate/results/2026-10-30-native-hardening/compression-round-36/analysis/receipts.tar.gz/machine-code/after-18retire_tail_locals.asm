
/private/tmp/mech-retirement-round36-20261030/workers/after:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001015c139c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals>:
1015c139c: d10643ff    	sub	sp, sp, #0x190
1015c13a0: a9136ffc    	stp	x28, x27, [sp, #0x130]
1015c13a4: a91467fa    	stp	x26, x25, [sp, #0x140]
1015c13a8: a9155ff8    	stp	x24, x23, [sp, #0x150]
1015c13ac: a91657f6    	stp	x22, x21, [sp, #0x160]
1015c13b0: a9174ff4    	stp	x20, x19, [sp, #0x170]
1015c13b4: a9187bfd    	stp	x29, x30, [sp, #0x180]
1015c13b8: 910603fd    	add	x29, sp, #0x180
1015c13bc: aa0303f5    	mov	x21, x3
1015c13c0: aa0203f6    	mov	x22, x2
1015c13c4: aa0103f4    	mov	x20, x1
1015c13c8: f9002fe0    	str	x0, [sp, #0x58]
1015c13cc: f9424839    	ldr	x25, [x1, #0x490]
1015c13d0: f9400b28    	ldr	x8, [x25, #0x10]
1015c13d4: f100091f    	cmp	x8, #0x2
1015c13d8: 54000281    	b.ne	0x1015c1428 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x8c>
1015c13dc: 9101c3e8    	add	x8, sp, #0x70
1015c13e0: aa1403e0    	mov	x0, x20
1015c13e4: aa1603e1    	mov	x1, x22
1015c13e8: 97fffcf4    	bl	0x1015c07b8 <__RNvMNtNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime4maps5owner6frozen16frozen_map_callsNtNtBa_10invocation10Invocation13retire_frozen>
1015c13ec: b94073e8    	ldr	w8, [sp, #0x70]
1015c13f0: 7100191f    	cmp	w8, #0x6
1015c13f4: 540005c1    	b.ne	0x1015c14ac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x110>
1015c13f8: f9424e9a    	ldr	x26, [x20, #0x498]
1015c13fc: f9425681    	ldr	x1, [x20, #0x4a8]
1015c1400: f942334a    	ldr	x10, [x26, #0x460]
1015c1404: f9423749    	ldr	x9, [x26, #0x468]
1015c1408: 2a1603e8    	mov	w8, w22
1015c140c: eb08013f    	cmp	x9, x8
1015c1410: fa4a8020    	ccmp	x1, x10, #0x0, hi
1015c1414: 540006a0    	b.eq	0x1015c14e8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x14c>
1015c1418: 9000d3c8    	adrp	x8, 0x103039000 <_anon.19b44b453da724831023c27de6e0b6f2.100+0xf48>
1015c141c: 91164d08    	add	x8, x8, #0x593
1015c1420: 52800509    	mov	w9, #0x28               ; =40
1015c1424: 14000059    	b	0x1015c1588 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x1ec>
1015c1428: f9402f38    	ldr	x24, [x25, #0x58]
1015c142c: f942f308    	ldr	x8, [x24, #0x5e0]
1015c1430: b4003a28    	cbz	x8, 0x1015c1b74 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x7d8>
1015c1434: f9433b13    	ldr	x19, [x24, #0x670]
1015c1438: f000d3a8    	adrp	x8, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c143c: 9102e108    	add	x8, x8, #0xb8
1015c1440: 5280018c    	mov	w12, #0xc               ; =12
1015c1444: 52800349    	mov	w9, #0x1a               ; =26
1015c1448: d37afe6a    	lsr	x10, x19, #58
1015c144c: b50039aa    	cbnz	x10, 0x1015c1b80 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x7e4>
1015c1450: d37ae66d    	lsl	x13, x19, #6
1015c1454: b10101bf    	cmn	x13, #0x40
1015c1458: 54000b20    	b.eq	0x1015c15bc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x220>
1015c145c: f943371a    	ldr	x26, [x24, #0x668]
1015c1460: 910101b7    	add	x23, x13, #0x40
1015c1464: f9418b28    	ldr	x8, [x25, #0x310]
1015c1468: b4000328    	cbz	x8, 0x1015c14cc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x130>
1015c146c: f9418722    	ldr	x2, [x25, #0x308]
1015c1470: 9101c3e8    	add	x8, sp, #0x70
1015c1474: 910c4320    	add	x0, x25, #0x310
1015c1478: aa1703e1    	mov	x1, x23
1015c147c: 9435634d    	bl	0x10231a1b0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>
1015c1480: 3941c3e8    	ldrb	w8, [sp, #0x70]
1015c1484: 7100211f    	cmp	w8, #0x8
1015c1488: 54000bc0    	b.eq	0x1015c1600 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x264>
1015c148c: a94723ed    	ldp	x13, x8, [sp, #0x70]
1015c1490: f94043e9    	ldr	x9, [sp, #0x80]
1015c1494: 92403daa    	and	x10, x13, #0xffff
1015c1498: f118195f    	cmp	x10, #0x606
1015c149c: 54000821    	b.ne	0x1015c15a0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x204>
1015c14a0: 5280000b    	mov	w11, #0x0               ; =0
1015c14a4: 528000cc    	mov	w12, #0x6               ; =6
1015c14a8: 14000045    	b	0x1015c15bc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x220>
1015c14ac: ad4487e0    	ldp	q0, q1, [sp, #0x90]
1015c14b0: f9402fe8    	ldr	x8, [sp, #0x58]
1015c14b4: ad010500    	stp	q0, q1, [x8, #0x20]
1015c14b8: 3dc02fe0    	ldr	q0, [sp, #0xb0]
1015c14bc: 3d801100    	str	q0, [x8, #0x40]
1015c14c0: ad4383e1    	ldp	q1, q0, [sp, #0x70]
1015c14c4: ad000101    	stp	q1, q0, [x8]
1015c14c8: 14000045    	b	0x1015c15dc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x240>
1015c14cc: 94356140    	bl	0x1023199cc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope>
1015c14d0: 360002e0    	tbz	w0, #0x0, 0x1015c152c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x190>
1015c14d4: d2800008    	mov	x8, #0x0                ; =0
1015c14d8: 5280000b    	mov	w11, #0x0               ; =0
1015c14dc: 5280000a    	mov	w10, #0x0               ; =0
1015c14e0: 528000ec    	mov	w12, #0x7               ; =7
1015c14e4: 14000036    	b	0x1015c15bc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x220>
1015c14e8: 8b080508    	add	x8, x8, x8, lsl #1
1015c14ec: 8b350100    	add	x0, x8, w21, uxtb
1015c14f0: eb01001f    	cmp	x0, x1
1015c14f4: 54004002    	b.hs	0x1015c1cf4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x958>
1015c14f8: 91000408    	add	x8, x0, #0x1
1015c14fc: eb01011f    	cmp	x8, x1
1015c1500: 54004002    	b.hs	0x1015c1d00 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x964>
1015c1504: f942528a    	ldr	x10, [x20, #0x4a0]
1015c1508: f860794b    	ldr	x11, [x10, x0, lsl #3]
1015c150c: 8b090529    	add	x9, x9, x9, lsl #1
1015c1510: 91000529    	add	x9, x9, #0x1
1015c1514: eb09017f    	cmp	x11, x9
1015c1518: 540001e2    	b.hs	0x1015c1554 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x1b8>
1015c151c: 9000d3c8    	adrp	x8, 0x103039000 <_anon.19b44b453da724831023c27de6e0b6f2.100+0xf48>
1015c1520: 9115cd08    	add	x8, x8, #0x573
1015c1524: 52800409    	mov	w9, #0x20               ; =32
1015c1528: 14000018    	b	0x1015c1588 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x1ec>
1015c152c: f9418328    	ldr	x8, [x25, #0x300]
1015c1530: f9418729    	ldr	x9, [x25, #0x308]
1015c1534: ab170108    	adds	x8, x8, x23
1015c1538: 540036c2    	b.hs	0x1015c1c10 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x874>
1015c153c: eb09011f    	cmp	x8, x9
1015c1540: 540005e9    	b.ls	0x1015c15fc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x260>
1015c1544: 5280000b    	mov	w11, #0x0               ; =0
1015c1548: 5280000a    	mov	w10, #0x0               ; =0
1015c154c: 528000cc    	mov	w12, #0x6               ; =6
1015c1550: 1400001b    	b	0x1015c15bc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x220>
1015c1554: f8687948    	ldr	x8, [x10, x8, lsl #3]
1015c1558: eb0b0117    	subs	x23, x8, x11
1015c155c: 1a9f27e9    	cset	w9, lo
1015c1560: eb01011f    	cmp	x8, x1
1015c1564: 1a9f952c    	csinc	w12, w9, wzr, ls
1015c1568: 8b0b0d56    	add	x22, x10, x11, lsl #3
1015c156c: 9000d3c8    	adrp	x8, 0x103039000 <_anon.19b44b453da724831023c27de6e0b6f2.100+0xf48>
1015c1570: 91154d08    	add	x8, x8, #0x553
1015c1574: 7100019f    	cmp	w12, #0x0
1015c1578: 9a96111b    	csel	x27, x8, x22, ne
1015c157c: 52800409    	mov	w9, #0x20               ; =32
1015c1580: 9a971138    	csel	x24, x9, x23, ne
1015c1584: 340008ac    	cbz	w12, 0x1015c1698 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x2fc>
1015c1588: f9402feb    	ldr	x11, [sp, #0x58]
1015c158c: b900017f    	str	wzr, [x11]
1015c1590: 5280018a    	mov	w10, #0xc               ; =12
1015c1594: a900a16a    	stp	x10, x8, [x11, #0x8]
1015c1598: f9000d69    	str	x9, [x11, #0x18]
1015c159c: 14000010    	b	0x1015c15dc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x240>
1015c15a0: d360fd2a    	lsr	x10, x9, #32
1015c15a4: 3cc883e0    	ldur	q0, [sp, #0x88]
1015c15a8: 3d801be0    	str	q0, [sp, #0x60]
1015c15ac: 528000ec    	mov	w12, #0x7               ; =7
1015c15b0: aa0903eb    	mov	x11, x9
1015c15b4: aa0803e9    	mov	x9, x8
1015c15b8: aa0d03e8    	mov	x8, x13
1015c15bc: f9402fed    	ldr	x13, [sp, #0x58]
1015c15c0: b90001bf    	str	wzr, [x13]
1015c15c4: a900a1ac    	stp	x12, x8, [x13, #0x8]
1015c15c8: f9000da9    	str	x9, [x13, #0x18]
1015c15cc: 290429ab    	stp	w11, w10, [x13, #0x20]
1015c15d0: 3dc01be0    	ldr	q0, [sp, #0x60]
1015c15d4: 3c8281a0    	stur	q0, [x13, #0x28]
1015c15d8: b90039bf    	str	wzr, [x13, #0x38]
1015c15dc: a9587bfd    	ldp	x29, x30, [sp, #0x180]
1015c15e0: a9574ff4    	ldp	x20, x19, [sp, #0x170]
1015c15e4: a95657f6    	ldp	x22, x21, [sp, #0x160]
1015c15e8: a9555ff8    	ldp	x24, x23, [sp, #0x150]
1015c15ec: a95467fa    	ldp	x26, x25, [sp, #0x140]
1015c15f0: a9536ffc    	ldp	x28, x27, [sp, #0x130]
1015c15f4: 910643ff    	add	sp, sp, #0x190
1015c15f8: d65f03c0    	ret
1015c15fc: f9018328    	str	x8, [x25, #0x300]
1015c1600: b4ffeef3    	cbz	x19, 0x1015c13dc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x40>
1015c1604: d280001b    	mov	x27, #0x0               ; =0
1015c1608: d2800017    	mov	x23, #0x0               ; =0
1015c160c: d37bea7c    	lsl	x28, x19, #5
1015c1610: 52801413    	mov	w19, #0xa0              ; =160
1015c1614: 14000005    	b	0x1015c1628 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x28c>
1015c1618: 9102437b    	add	x27, x27, #0x90
1015c161c: 910006f7    	add	x23, x23, #0x1
1015c1620: f100839c    	subs	x28, x28, #0x20
1015c1624: 54ffedc0    	b.eq	0x1015c13dc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x40>
1015c1628: f8420740    	ldr	x0, [x26], #0x20
1015c162c: f942f701    	ldr	x1, [x24, #0x5e8]
1015c1630: eb01001f    	cmp	x0, x1
1015c1634: 540033c2    	b.hs	0x1015c1cac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x910>
1015c1638: f942f308    	ldr	x8, [x24, #0x5e0]
1015c163c: 9b132008    	madd	x8, x0, x19, x8
1015c1640: b9409908    	ldr	w8, [x8, #0x98]
1015c1644: 6b16011f    	cmp	w8, w22
1015c1648: 54fffe81    	b.ne	0x1015c1618 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x27c>
1015c164c: f9402b21    	ldr	x1, [x25, #0x50]
1015c1650: eb0102ff    	cmp	x23, x1
1015c1654: 54003322    	b.hs	0x1015c1cb8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x91c>
1015c1658: f9402728    	ldr	x8, [x25, #0x48]
1015c165c: 8b1b0108    	add	x8, x8, x27
1015c1660: 3dc00100    	ldr	q0, [x8]
1015c1664: 3d801fe0    	str	q0, [sp, #0x70]
1015c1668: ad418101    	ldp	q1, q0, [x8, #0x30]
1015c166c: ad408903    	ldp	q3, q2, [x8, #0x10]
1015c1670: ad040be3    	stp	q3, q2, [sp, #0x80]
1015c1674: ad0503e1    	stp	q1, q0, [sp, #0xa0]
1015c1678: ad428500    	ldp	q0, q1, [x8, #0x50]
1015c167c: ad438d02    	ldp	q2, q3, [x8, #0x70]
1015c1680: ad070fe2    	stp	q2, q3, [sp, #0xe0]
1015c1684: ad0607e0    	stp	q0, q1, [sp, #0xc0]
1015c1688: f900011f    	str	xzr, [x8]
1015c168c: 9101c3e0    	add	x0, sp, #0x70
1015c1690: 97ff8e27    	bl	0x1015a4f2c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime4maps5owner5spans4LaneEEB1g_>
1015c1694: 17ffffe1    	b	0x1015c1618 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x27c>
1015c1698: 92800088    	mov	x8, #-0x5               ; =-5
1015c169c: f2e1ffe8    	movk	x8, #0xfff, lsl #48
1015c16a0: eb0802ff    	cmp	x23, x8
1015c16a4: 54002c08    	b.hi	0x1015c1c24 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x888>
1015c16a8: f941e334    	ldr	x20, [x25, #0x3c0]
1015c16ac: d37ceee8    	lsl	x8, x23, #4
1015c16b0: 91010115    	add	x21, x8, #0x40
1015c16b4: f9418b28    	ldr	x8, [x25, #0x310]
1015c16b8: b4000328    	cbz	x8, 0x1015c171c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x380>
1015c16bc: f9418722    	ldr	x2, [x25, #0x308]
1015c16c0: 9101c3e8    	add	x8, sp, #0x70
1015c16c4: 910c4320    	add	x0, x25, #0x310
1015c16c8: aa1503e1    	mov	x1, x21
1015c16cc: 943562b9    	bl	0x10231a1b0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>
1015c16d0: 3941c3e8    	ldrb	w8, [sp, #0x70]
1015c16d4: 7100211f    	cmp	w8, #0x8
1015c16d8: 540004a0    	b.eq	0x1015c176c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x3d0>
1015c16dc: a94757e8    	ldp	x8, x21, [sp, #0x70]
1015c16e0: f94043ed    	ldr	x13, [sp, #0x80]
1015c16e4: 92403d09    	and	x9, x8, #0xffff
1015c16e8: f118193f    	cmp	x9, #0x606
1015c16ec: 54000300    	b.eq	0x1015c174c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x3b0>
1015c16f0: 4e080da0    	dup.2d	v0, x13
1015c16f4: 9000d3e9    	adrp	x9, 0x10303d000 <_anon.19b44b453da724831023c27de6e0b6f2.893+0xcba>
1015c16f8: 3dc03921    	ldr	q1, [x9, #0xe0]
1015c16fc: 6ee14400    	ushl.2d	v0, v0, v1
1015c1700: 0ea12800    	xtn.2s	v0, v0
1015c1704: 3cc883e1    	ldur	q1, [sp, #0x88]
1015c1708: 3c9803a1    	stur	q1, [x29, #-0x80]
1015c170c: 528000f6    	mov	w22, #0x7               ; =7
1015c1710: aa1503ed    	mov	x13, x21
1015c1714: aa0803f5    	mov	x21, x8
1015c1718: 1400000f    	b	0x1015c1754 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x3b8>
1015c171c: 943560ac    	bl	0x1023199cc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope>
1015c1720: 360000a0    	tbz	w0, #0x0, 0x1015c1734 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x398>
1015c1724: d2800015    	mov	x21, #0x0               ; =0
1015c1728: 6f00e400    	movi.2d	v0, #0000000000000000
1015c172c: 528000f6    	mov	w22, #0x7               ; =7
1015c1730: 14000009    	b	0x1015c1754 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x3b8>
1015c1734: f9418328    	ldr	x8, [x25, #0x300]
1015c1738: f941872d    	ldr	x13, [x25, #0x308]
1015c173c: ab150115    	adds	x21, x8, x21
1015c1740: 54002b02    	b.hs	0x1015c1ca0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x904>
1015c1744: eb0d02bf    	cmp	x21, x13
1015c1748: 54000109    	b.ls	0x1015c1768 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x3cc>
1015c174c: 6f00e400    	movi.2d	v0, #0000000000000000
1015c1750: 528000d6    	mov	w22, #0x6               ; =6
1015c1754: f9402fec    	ldr	x12, [sp, #0x58]
1015c1758: 52800008    	mov	w8, #0x0                ; =0
1015c175c: d2800009    	mov	x9, #0x0                ; =0
1015c1760: 6f00e401    	movi.2d	v1, #0000000000000000
1015c1764: 140000ad    	b	0x1015c1a18 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x67c>
1015c1768: f9018335    	str	x21, [x25, #0x300]
1015c176c: b4001217    	cbz	x23, 0x1015c19ac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x610>
1015c1770: f9417f28    	ldr	x8, [x25, #0x2f8]
1015c1774: d37df2e9    	lsl	x9, x23, #3
1015c1778: 8b0902dc    	add	x28, x22, x9
1015c177c: f9408335    	ldr	x21, [x25, #0x100]
1015c1780: eb15011f    	cmp	x8, x21
1015c1784: 54000ec1    	b.ne	0x1015c195c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x5c0>
1015c1788: f9418f28    	ldr	x8, [x25, #0x318]
1015c178c: f940872a    	ldr	x10, [x25, #0x108]
1015c1790: eb0a011f    	cmp	x8, x10
1015c1794: fa401904    	ccmp	x8, #0x0, #0x4, ne
1015c1798: 54000e21    	b.ne	0x1015c195c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x5c0>
1015c179c: a952af28    	ldp	x8, x11, [x25, #0x128]
1015c17a0: f9002be8    	str	x8, [sp, #0x50]
1015c17a4: a9552333    	ldp	x19, x8, [x25, #0x150]
1015c17a8: f9001fe8    	str	x8, [sp, #0x38]
1015c17ac: f9426b48    	ldr	x8, [x26, #0x4d0]
1015c17b0: f90027e8    	str	x8, [sp, #0x48]
1015c17b4: f9426748    	ldr	x8, [x26, #0x4c8]
1015c17b8: f90023e8    	str	x8, [sp, #0x40]
1015c17bc: f9427348    	ldr	x8, [x26, #0x4e0]
1015c17c0: a902a3ea    	stp	x10, x8, [sp, #0x28]
1015c17c4: b4000594    	cbz	x20, 0x1015c1874 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x4d8>
1015c17c8: d2800001    	mov	x1, #0x0                ; =0
1015c17cc: d2c00028    	mov	x8, #0x100000000        ; =4294967296
1015c17d0: eb08017f    	cmp	x11, x8
1015c17d4: 9a88316a    	csel	x10, x11, x8, lo
1015c17d8: a94333ed    	ldp	x13, x12, [sp, #0x30]
1015c17dc: aa0b03f8    	mov	x24, x11
1015c17e0: 14000003    	b	0x1015c17ec <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x450>
1015c17e4: f1002129    	subs	x9, x9, #0x8
1015c17e8: 540009c0    	b.eq	0x1015c1920 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x584>
1015c17ec: f84086c0    	ldr	x0, [x22], #0x8
1015c17f0: eb0a001f    	cmp	x0, x10
1015c17f4: 54000b42    	b.hs	0x1015c195c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x5c0>
1015c17f8: d37ae408    	lsl	x8, x0, #6
1015c17fc: f9402beb    	ldr	x11, [sp, #0x50]
1015c1800: f8686968    	ldr	x8, [x11, x8]
1015c1804: b40000c8    	cbz	x8, 0x1015c181c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x480>
1015c1808: eb00019f    	cmp	x12, x0
1015c180c: 54002829    	b.ls	0x1015c1d10 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x974>
1015c1810: f8607a68    	ldr	x8, [x19, x0, lsl #3]
1015c1814: b100051f    	cmn	x8, #0x1
1015c1818: 54000a20    	b.eq	0x1015c195c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x5c0>
1015c181c: b100843f    	cmn	x1, #0x21
1015c1820: 540009e8    	b.hi	0x1015c195c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x5c0>
1015c1824: 91008021    	add	x1, x1, #0x20
1015c1828: f94027e8    	ldr	x8, [sp, #0x48]
1015c182c: eb08001f    	cmp	x0, x8
1015c1830: 54fffda2    	b.hs	0x1015c17e4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x448>
1015c1834: f94023e8    	ldr	x8, [sp, #0x40]
1015c1838: 8b00150b    	add	x11, x8, x0, lsl #5
1015c183c: f9400168    	ldr	x8, [x11]
1015c1840: f100051f    	cmp	x8, #0x1
1015c1844: 54fffd01    	b.ne	0x1015c17e4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x448>
1015c1848: a940a160    	ldp	x0, x8, [x11, #0x8]
1015c184c: eb00011f    	cmp	x8, x0
1015c1850: fa4d2102    	ccmp	x8, x13, #0x2, hs
1015c1854: 540021c8    	b.hi	0x1015c1c8c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x8f0>
1015c1858: f9400d68    	ldr	x8, [x11, #0x18]
1015c185c: ab010101    	adds	x1, x8, x1
1015c1860: 540007e2    	b.hs	0x1015c195c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x5c0>
1015c1864: b10006ff    	cmn	x23, #0x1
1015c1868: 540007a0    	b.eq	0x1015c195c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x5c0>
1015c186c: 910006f7    	add	x23, x23, #0x1
1015c1870: 17ffffdd    	b	0x1015c17e4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x448>
1015c1874: d2800008    	mov	x8, #0x0                ; =0
1015c1878: d37beae1    	lsl	x1, x23, #5
1015c187c: d2c0002a    	mov	x10, #0x100000000       ; =4294967296
1015c1880: eb0a017f    	cmp	x11, x10
1015c1884: aa0b03ec    	mov	x12, x11
1015c1888: 9a8a316a    	csel	x10, x11, x10, lo
1015c188c: aa1303ee    	mov	x14, x19
1015c1890: 14000003    	b	0x1015c189c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x500>
1015c1894: d1002129    	sub	x9, x9, #0x8
1015c1898: b4000409    	cbz	x9, 0x1015c1918 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x57c>
1015c189c: f84086c0    	ldr	x0, [x22], #0x8
1015c18a0: eb0a001f    	cmp	x0, x10
1015c18a4: 540005c2    	b.hs	0x1015c195c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x5c0>
1015c18a8: d37ae40b    	lsl	x11, x0, #6
1015c18ac: f9402bed    	ldr	x13, [sp, #0x50]
1015c18b0: f86b69ab    	ldr	x11, [x13, x11]
1015c18b4: b40000eb    	cbz	x11, 0x1015c18d0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x534>
1015c18b8: f9401feb    	ldr	x11, [sp, #0x38]
1015c18bc: eb00017f    	cmp	x11, x0
1015c18c0: 54002289    	b.ls	0x1015c1d10 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x974>
1015c18c4: f86079cb    	ldr	x11, [x14, x0, lsl #3]
1015c18c8: b100057f    	cmn	x11, #0x1
1015c18cc: 54000480    	b.eq	0x1015c195c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x5c0>
1015c18d0: f1008108    	subs	x8, x8, #0x20
1015c18d4: 54000440    	b.eq	0x1015c195c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x5c0>
1015c18d8: f94027eb    	ldr	x11, [sp, #0x48]
1015c18dc: eb0b001f    	cmp	x0, x11
1015c18e0: 54fffda2    	b.hs	0x1015c1894 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x4f8>
1015c18e4: d37be80b    	lsl	x11, x0, #5
1015c18e8: f94023ed    	ldr	x13, [sp, #0x40]
1015c18ec: f86b69ab    	ldr	x11, [x13, x11]
1015c18f0: f100057f    	cmp	x11, #0x1
1015c18f4: 54fffd01    	b.ne	0x1015c1894 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x4f8>
1015c18f8: f94023e8    	ldr	x8, [sp, #0x40]
1015c18fc: 8b001508    	add	x8, x8, x0, lsl #5
1015c1900: a940a100    	ldp	x0, x8, [x8, #0x8]
1015c1904: eb00011f    	cmp	x8, x0
1015c1908: f9401be2    	ldr	x2, [sp, #0x30]
1015c190c: fa422102    	ccmp	x8, x2, #0x2, hs
1015c1910: 54000269    	b.ls	0x1015c195c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x5c0>
1015c1914: 140000df    	b	0x1015c1c90 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x8f4>
1015c1918: aa1803f7    	mov	x23, x24
1015c191c: aa0c03f8    	mov	x24, x12
1015c1920: f1000aff    	cmp	x23, #0x2
1015c1924: 540001c3    	b.lo	0x1015c195c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x5c0>
1015c1928: 910be320    	add	x0, x25, #0x2f8
1015c192c: 97fe4895    	bl	0x101553b80 <__RNvMNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4work10retirementNtB4_15NativeWorkMeter20try_retirement_batch>
1015c1930: f90013e0    	str	x0, [sp, #0x20]
1015c1934: b4000140    	cbz	x0, 0x1015c195c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x5c0>
1015c1938: aa0103f7    	mov	x23, x1
1015c193c: f9000ff8    	str	x24, [sp, #0x18]
1015c1940: aa1503f8    	mov	x24, x21
1015c1944: f9426f49    	ldr	x9, [x26, #0x4d8]
1015c1948: b000d3f5    	adrp	x21, 0x10303e000 <_anon.cfed166831d39e946c5b7edabfe8ad4e.59+0x428>
1015c194c: 910232b5    	add	x21, x21, #0x8c
1015c1950: 52800548    	mov	w8, #0x2a               ; =42
1015c1954: a900a7e8    	stp	x8, x9, [sp, #0x8]
1015c1958: 14000043    	b	0x1015c1a64 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x6c8>
1015c195c: b8408775    	ldr	w21, [x27], #0x8
1015c1960: 9101c3e0    	add	x0, sp, #0x70
1015c1964: 91132342    	add	x2, x26, #0x4c8
1015c1968: 910be324    	add	x4, x25, #0x2f8
1015c196c: aa1403e1    	mov	x1, x20
1015c1970: aa1503e3    	mov	x3, x21
1015c1974: 97ffb289    	bl	0x1015ae398 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire>
1015c1978: b94073e8    	ldr	w8, [sp, #0x70]
1015c197c: 7100191f    	cmp	w8, #0x6
1015c1980: 540001e1    	b.ne	0x1015c19bc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x620>
1015c1984: 9101c3e8    	add	x8, sp, #0x70
1015c1988: 9103c320    	add	x0, x25, #0xf0
1015c198c: 910be322    	add	x2, x25, #0x2f8
1015c1990: aa1503e1    	mov	x1, x21
1015c1994: 940026fd    	bl	0x1015cb588 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena14retire_current>
1015c1998: 3941c3e8    	ldrb	w8, [sp, #0x70]
1015c199c: 7100511f    	cmp	w8, #0x14
1015c19a0: 540002a1    	b.ne	0x1015c19f4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x658>
1015c19a4: eb1c037f    	cmp	x27, x28
1015c19a8: 54fffda1    	b.ne	0x1015c195c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x5c0>
1015c19ac: 528000c8    	mov	w8, #0x6                ; =6
1015c19b0: f9402fe9    	ldr	x9, [sp, #0x58]
1015c19b4: b9000128    	str	w8, [x9]
1015c19b8: 17ffff09    	b	0x1015c15dc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x240>
1015c19bc: 3941d3ea    	ldrb	w10, [sp, #0x74]
1015c19c0: 784753e9    	ldurh	w9, [sp, #0x75]
1015c19c4: 781a43a9    	sturh	w9, [x29, #-0x5c]
1015c19c8: 3941dfe9    	ldrb	w9, [sp, #0x77]
1015c19cc: 381a63a9    	sturb	w9, [x29, #-0x5a]
1015c19d0: a947d7f6    	ldp	x22, x21, [sp, #0x78]
1015c19d4: 9278dec9    	and	x9, x22, #0xffffffffffffff00
1015c19d8: f94047ed    	ldr	x13, [sp, #0x88]
1015c19dc: fd404be0    	ldr	d0, [sp, #0x90]
1015c19e0: 3cc983e3    	ldur	q3, [sp, #0x98]
1015c19e4: fd4057e1    	ldr	d1, [sp, #0xa8]
1015c19e8: 3dc02fe2    	ldr	q2, [sp, #0xb0]
1015c19ec: ad3c0ba3    	stp	q3, q2, [x29, #-0x80]
1015c19f0: 14000009    	b	0x1015c1a14 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x678>
1015c19f4: a94757f6    	ldp	x22, x21, [sp, #0x70]
1015c19f8: f94043ed    	ldr	x13, [sp, #0x80]
1015c19fc: fd4047e0    	ldr	d0, [sp, #0x88]
1015c1a00: 3dc027e1    	ldr	q1, [sp, #0x90]
1015c1a04: 3c9803a1    	stur	q1, [x29, #-0x80]
1015c1a08: fd4053e1    	ldr	d1, [sp, #0xa0]
1015c1a0c: 9278dec9    	and	x9, x22, #0xffffffffffffff00
1015c1a10: 52800048    	mov	w8, #0x2                ; =2
1015c1a14: f9402fec    	ldr	x12, [sp, #0x58]
1015c1a18: 92401ecb    	and	x11, x22, #0xff
1015c1a1c: b9000188    	str	w8, [x12]
1015c1a20: aa0b0128    	orr	x8, x9, x11
1015c1a24: 3900118a    	strb	w10, [x12, #0x4]
1015c1a28: 785a43a9    	ldurh	w9, [x29, #-0x5c]
1015c1a2c: 78005189    	sturh	w9, [x12, #0x5]
1015c1a30: 385a63a9    	ldurb	w9, [x29, #-0x5a]
1015c1a34: 39001d89    	strb	w9, [x12, #0x7]
1015c1a38: a900d588    	stp	x8, x21, [x12, #0x8]
1015c1a3c: f9000d8d    	str	x13, [x12, #0x18]
1015c1a40: fd001180    	str	d0, [x12, #0x20]
1015c1a44: ad7c03a2    	ldp	q2, q0, [x29, #-0x80]
1015c1a48: 3c828182    	stur	q2, [x12, #0x28]
1015c1a4c: fd001d81    	str	d1, [x12, #0x38]
1015c1a50: 3d801180    	str	q0, [x12, #0x40]
1015c1a54: 17fffee2    	b	0x1015c15dc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x240>
1015c1a58: f900035f    	str	xzr, [x26]
1015c1a5c: eb1c037f    	cmp	x27, x28
1015c1a60: 54000c80    	b.eq	0x1015c1bf0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x854>
1015c1a64: b8408779    	ldr	w25, [x27], #0x8
1015c1a68: f94027e8    	ldr	x8, [sp, #0x48]
1015c1a6c: eb19011f    	cmp	x8, x25
1015c1a70: f94013ea    	ldr	x10, [sp, #0x20]
1015c1a74: 54000449    	b.ls	0x1015c1afc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x760>
1015c1a78: f94023e8    	ldr	x8, [sp, #0x40]
1015c1a7c: 8b191508    	add	x8, x8, x25, lsl #5
1015c1a80: f9400109    	ldr	x9, [x8]
1015c1a84: f100053f    	cmp	x9, #0x1
1015c1a88: 540003a1    	b.ne	0x1015c1afc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x760>
1015c1a8c: a9408500    	ldp	x0, x1, [x8, #0x8]
1015c1a90: eb000023    	subs	x3, x1, x0
1015c1a94: f9401be9    	ldr	x9, [sp, #0x30]
1015c1a98: fa492022    	ccmp	x1, x9, #0x2, hs
1015c1a9c: 54001248    	b.hi	0x1015c1ce4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x948>
1015c1aa0: f9400d08    	ldr	x8, [x8, #0x18]
1015c1aa4: eb0802ff    	cmp	x23, x8
1015c1aa8: aa1703e9    	mov	x9, x23
1015c1aac: 9a8833f7    	csel	x23, xzr, x8, lo
1015c1ab0: aa0903fa    	mov	x26, x9
1015c1ab4: eb08013f    	cmp	x9, x8
1015c1ab8: 528001c8    	mov	w8, #0xe                ; =14
1015c1abc: 52800189    	mov	w9, #0xc                ; =12
1015c1ac0: 9a883128    	csel	x8, x9, x8, lo
1015c1ac4: 9278dec9    	and	x9, x22, #0xffffffffffffff00
1015c1ac8: aa090116    	orr	x22, x8, x9
1015c1acc: 54000ba3    	b.lo	0x1015c1c40 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x8a4>
1015c1ad0: f9400be8    	ldr	x8, [sp, #0x10]
1015c1ad4: 52800309    	mov	w9, #0x18               ; =24
1015c1ad8: 9b092002    	madd	x2, x0, x9, x8
1015c1adc: 9101c3e0    	add	x0, sp, #0x70
1015c1ae0: aa1403e1    	mov	x1, x20
1015c1ae4: 97ffac34    	bl	0x1015acbb4 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames16apply_retirement>
1015c1ae8: b94073e8    	ldr	w8, [sp, #0x70]
1015c1aec: 7100191f    	cmp	w8, #0x6
1015c1af0: 54000ac1    	b.ne	0x1015c1c48 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x8ac>
1015c1af4: cb170357    	sub	x23, x26, x23
1015c1af8: f94013ea    	ldr	x10, [sp, #0x20]
1015c1afc: f9400148    	ldr	x8, [x10]
1015c1b00: eb18011f    	cmp	x8, x24
1015c1b04: 54000401    	b.ne	0x1015c1b84 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x7e8>
1015c1b08: f9401148    	ldr	x8, [x10, #0x20]
1015c1b0c: b4000088    	cbz	x8, 0x1015c1b1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x780>
1015c1b10: f94017e9    	ldr	x9, [sp, #0x28]
1015c1b14: eb09011f    	cmp	x8, x9
1015c1b18: 54000441    	b.ne	0x1015c1ba0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x804>
1015c1b1c: f10082f7    	subs	x23, x23, #0x20
1015c1b20: 540004e3    	b.lo	0x1015c1bbc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x820>
1015c1b24: f9400fe8    	ldr	x8, [sp, #0x18]
1015c1b28: eb19011f    	cmp	x8, x25
1015c1b2c: 54000549    	b.ls	0x1015c1bd4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x838>
1015c1b30: f9402be8    	ldr	x8, [sp, #0x50]
1015c1b34: 8b19191a    	add	x26, x8, x25, lsl #6
1015c1b38: f9400348    	ldr	x8, [x26]
1015c1b3c: b4fff908    	cbz	x8, 0x1015c1a5c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x6c0>
1015c1b40: f9401fe8    	ldr	x8, [sp, #0x38]
1015c1b44: eb19011f    	cmp	x8, x25
1015c1b48: 54000ec9    	b.ls	0x1015c1d20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x984>
1015c1b4c: f8797a68    	ldr	x8, [x19, x25, lsl #3]
1015c1b50: b100051f    	cmn	x8, #0x1
1015c1b54: 54000ba0    	b.eq	0x1015c1cc8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x92c>
1015c1b58: 91000508    	add	x8, x8, #0x1
1015c1b5c: f8397a68    	str	x8, [x19, x25, lsl #3]
1015c1b60: f9400348    	ldr	x8, [x26]
1015c1b64: b4fff7a8    	cbz	x8, 0x1015c1a58 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x6bc>
1015c1b68: aa1a03e0    	mov	x0, x26
1015c1b6c: 97ff9535    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c1b70: 17ffffba    	b	0x1015c1a58 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x6bc>
1015c1b74: 90012080    	adrp	x0, 0x1039d1000 <_anon.19b44b453da724831023c27de6e0b6f2.288+0x250>
1015c1b78: 91336000    	add	x0, x0, #0xcd8
1015c1b7c: 9460c672    	bl	0x102df3544 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1015c1b80: 17fffe8f    	b	0x1015c15bc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x220>
1015c1b84: d2800009    	mov	x9, #0x0                ; =0
1015c1b88: 52800048    	mov	w8, #0x2                ; =2
1015c1b8c: b000d3d5    	adrp	x21, 0x10303a000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x3b8>
1015c1b90: 9104bab5    	add	x21, x21, #0x12e
1015c1b94: 528005ed    	mov	w13, #0x2f              ; =47
1015c1b98: 52800276    	mov	w22, #0x13              ; =19
1015c1b9c: 17ffff9e    	b	0x1015c1a14 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x678>
1015c1ba0: d2800009    	mov	x9, #0x0                ; =0
1015c1ba4: 52800048    	mov	w8, #0x2                ; =2
1015c1ba8: b000d3d5    	adrp	x21, 0x10303a000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x3b8>
1015c1bac: 9104bab5    	add	x21, x21, #0x12e
1015c1bb0: 528005ed    	mov	w13, #0x2f              ; =47
1015c1bb4: 52800196    	mov	w22, #0xc               ; =12
1015c1bb8: 17ffff97    	b	0x1015c1a14 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x678>
1015c1bbc: d2800009    	mov	x9, #0x0                ; =0
1015c1bc0: 52800048    	mov	w8, #0x2                ; =2
1015c1bc4: 52800196    	mov	w22, #0xc               ; =12
1015c1bc8: f9402fec    	ldr	x12, [sp, #0x58]
1015c1bcc: 5280054d    	mov	w13, #0x2a              ; =42
1015c1bd0: 17ffff92    	b	0x1015c1a18 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x67c>
1015c1bd4: d2800009    	mov	x9, #0x0                ; =0
1015c1bd8: 52800048    	mov	w8, #0x2                ; =2
1015c1bdc: b000d3d5    	adrp	x21, 0x10303a000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x3b8>
1015c1be0: 9104bab5    	add	x21, x21, #0x12e
1015c1be4: 528005ed    	mov	w13, #0x2f              ; =47
1015c1be8: 528001d6    	mov	w22, #0xe               ; =14
1015c1bec: 17ffff8a    	b	0x1015c1a14 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x678>
1015c1bf0: b4ffedf7    	cbz	x23, 0x1015c19ac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x610>
1015c1bf4: 52800008    	mov	w8, #0x0                ; =0
1015c1bf8: d2800009    	mov	x9, #0x0                ; =0
1015c1bfc: 52800196    	mov	w22, #0xc               ; =12
1015c1c00: 5280064d    	mov	w13, #0x32              ; =50
1015c1c04: f000d3d5    	adrp	x21, 0x10303c000 <_anon.19b44b453da724831023c27de6e0b6f2.686+0xd1d>
1015c1c08: 9137cab5    	add	x21, x21, #0xdf2
1015c1c0c: 17ffff82    	b	0x1015c1a14 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x678>
1015c1c10: 5280000b    	mov	w11, #0x0               ; =0
1015c1c14: 5280000a    	mov	w10, #0x0               ; =0
1015c1c18: 92800008    	mov	x8, #-0x1               ; =-1
1015c1c1c: 528000cc    	mov	w12, #0x6               ; =6
1015c1c20: 17fffe67    	b	0x1015c15bc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x220>
1015c1c24: 52800008    	mov	w8, #0x0                ; =0
1015c1c28: d2800009    	mov	x9, #0x0                ; =0
1015c1c2c: 52800196    	mov	w22, #0xc               ; =12
1015c1c30: 5280034d    	mov	w13, #0x1a              ; =26
1015c1c34: f000d3b5    	adrp	x21, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c1c38: 9102e2b5    	add	x21, x21, #0xb8
1015c1c3c: 17ffff76    	b	0x1015c1a14 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x678>
1015c1c40: 52800008    	mov	w8, #0x0                ; =0
1015c1c44: 1400000e    	b	0x1015c1c7c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x8e0>
1015c1c48: 3941d3ea    	ldrb	w10, [sp, #0x74]
1015c1c4c: 784753e9    	ldurh	w9, [sp, #0x75]
1015c1c50: 781a43a9    	sturh	w9, [x29, #-0x5c]
1015c1c54: 3941dfe9    	ldrb	w9, [sp, #0x77]
1015c1c58: 381a63a9    	sturb	w9, [x29, #-0x5a]
1015c1c5c: a947d7f6    	ldp	x22, x21, [sp, #0x78]
1015c1c60: f94047e9    	ldr	x9, [sp, #0x88]
1015c1c64: f90007e9    	str	x9, [sp, #0x8]
1015c1c68: fd404be0    	ldr	d0, [sp, #0x90]
1015c1c6c: 3cc983e3    	ldur	q3, [sp, #0x98]
1015c1c70: fd4057e1    	ldr	d1, [sp, #0xa8]
1015c1c74: 3dc02fe2    	ldr	q2, [sp, #0xb0]
1015c1c78: ad3c0ba3    	stp	q3, q2, [x29, #-0x80]
1015c1c7c: 9278dec9    	and	x9, x22, #0xffffffffffffff00
1015c1c80: f9402fec    	ldr	x12, [sp, #0x58]
1015c1c84: f94007ed    	ldr	x13, [sp, #0x8]
1015c1c88: 17ffff64    	b	0x1015c1a18 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x67c>
1015c1c8c: f9401be2    	ldr	x2, [sp, #0x30]
1015c1c90: f0012063    	adrp	x3, 0x1039d0000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.102+0x210>
1015c1c94: 91386063    	add	x3, x3, #0xe18
1015c1c98: aa0803e1    	mov	x1, x8
1015c1c9c: 9460c6be    	bl	0x102df3794 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015c1ca0: 6f00e400    	movi.2d	v0, #0000000000000000
1015c1ca4: 92800015    	mov	x21, #-0x1              ; =-1
1015c1ca8: 17fffeaa    	b	0x1015c1750 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x3b4>
1015c1cac: 90012082    	adrp	x2, 0x1039d1000 <_anon.19b44b453da724831023c27de6e0b6f2.288+0x250>
1015c1cb0: 9133c042    	add	x2, x2, #0xcf0
1015c1cb4: 9460c64b    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c1cb8: 90012082    	adrp	x2, 0x1039d1000 <_anon.19b44b453da724831023c27de6e0b6f2.288+0x250>
1015c1cbc: 91342042    	add	x2, x2, #0xd08
1015c1cc0: aa1703e0    	mov	x0, x23
1015c1cc4: 9460c647    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c1cc8: d2800009    	mov	x9, #0x0                ; =0
1015c1ccc: 52800048    	mov	w8, #0x2                ; =2
1015c1cd0: b000d3d5    	adrp	x21, 0x10303a000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x3b8>
1015c1cd4: 9104bab5    	add	x21, x21, #0x12e
1015c1cd8: 528005ed    	mov	w13, #0x2f              ; =47
1015c1cdc: 52800256    	mov	w22, #0x12              ; =18
1015c1ce0: 17ffff4d    	b	0x1015c1a14 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x678>
1015c1ce4: aa0903e2    	mov	x2, x9
1015c1ce8: f0012063    	adrp	x3, 0x1039d0000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.102+0x210>
1015c1cec: 91386063    	add	x3, x3, #0xe18
1015c1cf0: 9460c6a9    	bl	0x102df3794 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015c1cf4: f0012062    	adrp	x2, 0x1039d0000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.102+0x210>
1015c1cf8: 9137a042    	add	x2, x2, #0xde8
1015c1cfc: 9460c639    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c1d00: f0012062    	adrp	x2, 0x1039d0000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.102+0x210>
1015c1d04: 91380042    	add	x2, x2, #0xe00
1015c1d08: aa0803e0    	mov	x0, x8
1015c1d0c: 9460c635    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c1d10: b0012082    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c1d14: 91116042    	add	x2, x2, #0x458
1015c1d18: f9401fe1    	ldr	x1, [sp, #0x38]
1015c1d1c: 9460c631    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c1d20: b0012082    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c1d24: 91110042    	add	x2, x2, #0x440
1015c1d28: aa1903e0    	mov	x0, x25
1015c1d2c: f9401fe1    	ldr	x1, [sp, #0x38]
1015c1d30: 9460c62c    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c1d34: f900035f    	str	xzr, [x26]
1015c1d38: 9460cb1d    	bl	0x102df49ac <dyld_stub_binder+0x102df49ac>
