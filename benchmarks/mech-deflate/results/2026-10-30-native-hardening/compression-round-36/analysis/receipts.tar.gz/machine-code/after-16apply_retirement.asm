
/private/tmp/mech-retirement-round36-20261030/workers/after:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001015acbb4 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames16apply_retirement>:
1015acbb4: a9bc5ff8    	stp	x24, x23, [sp, #-0x40]!
1015acbb8: a90157f6    	stp	x22, x21, [sp, #0x10]
1015acbbc: a9024ff4    	stp	x20, x19, [sp, #0x20]
1015acbc0: a9037bfd    	stp	x29, x30, [sp, #0x30]
1015acbc4: 9100c3fd    	add	x29, sp, #0x30
1015acbc8: aa0003f3    	mov	x19, x0
1015acbcc: b40004c1    	cbz	x1, 0x1015acc64 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames16apply_retirement+0xb0>
1015acbd0: b4000443    	cbz	x3, 0x1015acc58 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames16apply_retirement+0xa4>
1015acbd4: aa0103f4    	mov	x20, x1
1015acbd8: 8b030468    	add	x8, x3, x3, lsl #1
1015acbdc: d37df116    	lsl	x22, x8, #3
1015acbe0: 91002057    	add	x23, x2, #0x8
1015acbe4: 14000005    	b	0x1015acbf8 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames16apply_retirement+0x44>
1015acbe8: f90002bf    	str	xzr, [x21]
1015acbec: 910062f7    	add	x23, x23, #0x18
1015acbf0: f10062d6    	subs	x22, x22, #0x18
1015acbf4: 54000320    	b.eq	0x1015acc58 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames16apply_retirement+0xa4>
1015acbf8: b85f82e8    	ldur	w8, [x23, #-0x8]
1015acbfc: 36000188    	tbz	w8, #0x0, 0x1015acc2c <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames16apply_retirement+0x78>
1015acc00: f9407a81    	ldr	x1, [x20, #0xf0]
1015acc04: f94002e0    	ldr	x0, [x23]
1015acc08: eb01001f    	cmp	x0, x1
1015acc0c: 540004a2    	b.hs	0x1015acca0 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames16apply_retirement+0xec>
1015acc10: f9407688    	ldr	x8, [x20, #0xe8]
1015acc14: 8b001915    	add	x21, x8, x0, lsl #6
1015acc18: f94002a8    	ldr	x8, [x21]
1015acc1c: b4fffe68    	cbz	x8, 0x1015acbe8 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames16apply_retirement+0x34>
1015acc20: aa1503e0    	mov	x0, x21
1015acc24: 97ffe907    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015acc28: 17fffff0    	b	0x1015acbe8 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames16apply_retirement+0x34>
1015acc2c: f9408e82    	ldr	x2, [x20, #0x118]
1015acc30: a8c186e0    	ldp	x0, x1, [x23], #0x18
1015acc34: eb000028    	subs	x8, x1, x0
1015acc38: fa422022    	ccmp	x1, x2, #0x2, hs
1015acc3c: 540002c8    	b.hi	0x1015acc94 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames16apply_retirement+0xe0>
1015acc40: f9408a89    	ldr	x9, [x20, #0x110]
1015acc44: 8b000d20    	add	x0, x9, x0, lsl #3
1015acc48: d37df101    	lsl	x1, x8, #3
1015acc4c: 94611f82    	bl	0x102df4a54 <dyld_stub_binder+0x102df4a54>
1015acc50: f10062d6    	subs	x22, x22, #0x18
1015acc54: 54fffd21    	b.ne	0x1015acbf8 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames16apply_retirement+0x44>
1015acc58: 528000c8    	mov	w8, #0x6                ; =6
1015acc5c: b9000268    	str	w8, [x19]
1015acc60: 14000008    	b	0x1015acc80 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames16apply_retirement+0xcc>
1015acc64: b900027f    	str	wzr, [x19]
1015acc68: 52800188    	mov	w8, #0xc                ; =12
1015acc6c: b000d469    	adrp	x9, 0x103039000 <_anon.19b44b453da724831023c27de6e0b6f2.100+0xf48>
1015acc70: 91188129    	add	x9, x9, #0x620
1015acc74: a900a668    	stp	x8, x9, [x19, #0x8]
1015acc78: 52800368    	mov	w8, #0x1b               ; =27
1015acc7c: f9000e68    	str	x8, [x19, #0x18]
1015acc80: a9437bfd    	ldp	x29, x30, [sp, #0x30]
1015acc84: a9424ff4    	ldp	x20, x19, [sp, #0x20]
1015acc88: a94157f6    	ldp	x22, x21, [sp, #0x10]
1015acc8c: a8c45ff8    	ldp	x24, x23, [sp], #0x40
1015acc90: d65f03c0    	ret
1015acc94: 90012123    	adrp	x3, 0x1039d0000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.102+0x210>
1015acc98: 913b6063    	add	x3, x3, #0xed8
1015acc9c: 94611abe    	bl	0x102df3794 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015acca0: 90012122    	adrp	x2, 0x1039d0000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.102+0x210>
1015acca4: 913bc042    	add	x2, x2, #0xef0
1015acca8: 94611a4e    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015accac: f90002bf    	str	xzr, [x21]
1015accb0: 94611f3f    	bl	0x102df49ac <dyld_stub_binder+0x102df49ac>
