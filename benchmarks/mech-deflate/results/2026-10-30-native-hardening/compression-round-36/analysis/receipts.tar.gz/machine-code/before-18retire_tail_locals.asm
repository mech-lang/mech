
/private/tmp/mech-retirement-round36-20261030/workers/before:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001015bdbf4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals>:
1015bdbf4: d105c3ff    	sub	sp, sp, #0x170
1015bdbf8: a9116ffc    	stp	x28, x27, [sp, #0x110]
1015bdbfc: a91267fa    	stp	x26, x25, [sp, #0x120]
1015bdc00: a9135ff8    	stp	x24, x23, [sp, #0x130]
1015bdc04: a91457f6    	stp	x22, x21, [sp, #0x140]
1015bdc08: a9154ff4    	stp	x20, x19, [sp, #0x150]
1015bdc0c: a9167bfd    	stp	x29, x30, [sp, #0x160]
1015bdc10: 910583fd    	add	x29, sp, #0x160
1015bdc14: b9000fe3    	str	w3, [sp, #0xc]
1015bdc18: aa0203f6    	mov	x22, x2
1015bdc1c: aa0103f4    	mov	x20, x1
1015bdc20: aa0003f3    	mov	x19, x0
1015bdc24: f9424838    	ldr	x24, [x1, #0x490]
1015bdc28: f9400b08    	ldr	x8, [x24, #0x10]
1015bdc2c: f100091f    	cmp	x8, #0x2
1015bdc30: 54000281    	b.ne	0x1015bdc80 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x8c>
1015bdc34: 9101c3e8    	add	x8, sp, #0x70
1015bdc38: aa1403e0    	mov	x0, x20
1015bdc3c: aa1603e1    	mov	x1, x22
1015bdc40: 97fffcf4    	bl	0x1015bd010 <__RNvMNtNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime4maps5owner6frozen16frozen_map_callsNtNtBa_10invocation10Invocation13retire_frozen>
1015bdc44: b94073e8    	ldr	w8, [sp, #0x70]
1015bdc48: 7100191f    	cmp	w8, #0x6
1015bdc4c: 540005e1    	b.ne	0x1015bdd08 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x114>
1015bdc50: f9424e97    	ldr	x23, [x20, #0x498]
1015bdc54: f9425681    	ldr	x1, [x20, #0x4a8]
1015bdc58: f94232ea    	ldr	x10, [x23, #0x460]
1015bdc5c: f94236e9    	ldr	x9, [x23, #0x468]
1015bdc60: 2a1603e8    	mov	w8, w22
1015bdc64: eb08013f    	cmp	x9, x8
1015bdc68: fa4a8020    	ccmp	x1, x10, #0x0, hi
1015bdc6c: 540006a0    	b.eq	0x1015bdd40 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x14c>
1015bdc70: b000d3e8    	adrp	x8, 0x10303a000 <_anon.14153027747eb97b5e1b8a22004538d2.98+0x11b0>
1015bdc74: 910d7508    	add	x8, x8, #0x35d
1015bdc78: 52800509    	mov	w9, #0x28               ; =40
1015bdc7c: 14000053    	b	0x1015bddc8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x1d4>
1015bdc80: f9402f19    	ldr	x25, [x24, #0x58]
1015bdc84: f942f328    	ldr	x8, [x25, #0x5e0]
1015bdc88: b40020c8    	cbz	x8, 0x1015be0a0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x4ac>
1015bdc8c: f9433b35    	ldr	x21, [x25, #0x670]
1015bdc90: f000d3c8    	adrp	x8, 0x103038000 <_anon.6283f84d1d139f8f117b6935f97d7394.486+0xcd7>
1015bdc94: 91394108    	add	x8, x8, #0xe50
1015bdc98: 5280018c    	mov	w12, #0xc               ; =12
1015bdc9c: 52800349    	mov	w9, #0x1a               ; =26
1015bdca0: d37afeaa    	lsr	x10, x21, #58
1015bdca4: b500204a    	cbnz	x10, 0x1015be0ac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x4b8>
1015bdca8: d37ae6ad    	lsl	x13, x21, #6
1015bdcac: b10101bf    	cmn	x13, #0x40
1015bdcb0: 54000a20    	b.eq	0x1015bddf4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x200>
1015bdcb4: f943373a    	ldr	x26, [x25, #0x668]
1015bdcb8: 910101b7    	add	x23, x13, #0x40
1015bdcbc: f9418b08    	ldr	x8, [x24, #0x310]
1015bdcc0: b4000328    	cbz	x8, 0x1015bdd24 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x130>
1015bdcc4: f9418702    	ldr	x2, [x24, #0x308]
1015bdcc8: 9101c3e8    	add	x8, sp, #0x70
1015bdccc: 910c4300    	add	x0, x24, #0x310
1015bdcd0: aa1703e1    	mov	x1, x23
1015bdcd4: 94357312    	bl	0x10231a91c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>
1015bdcd8: 3941c3e8    	ldrb	w8, [sp, #0x70]
1015bdcdc: 7100211f    	cmp	w8, #0x8
1015bdce0: 54000aa0    	b.eq	0x1015bde34 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x240>
1015bdce4: a94737e8    	ldp	x8, x13, [sp, #0x70]
1015bdce8: f94043e9    	ldr	x9, [sp, #0x80]
1015bdcec: 92403d0a    	and	x10, x8, #0xffff
1015bdcf0: f118195f    	cmp	x10, #0x606
1015bdcf4: 54000741    	b.ne	0x1015bdddc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x1e8>
1015bdcf8: 5280000a    	mov	w10, #0x0               ; =0
1015bdcfc: 528000cc    	mov	w12, #0x6               ; =6
1015bdd00: aa0d03e8    	mov	x8, x13
1015bdd04: 1400003c    	b	0x1015bddf4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x200>
1015bdd08: ad4487e0    	ldp	q0, q1, [sp, #0x90]
1015bdd0c: ad010660    	stp	q0, q1, [x19, #0x20]
1015bdd10: 3dc02fe0    	ldr	q0, [sp, #0xb0]
1015bdd14: 3d801260    	str	q0, [x19, #0x40]
1015bdd18: ad4383e1    	ldp	q1, q0, [sp, #0x70]
1015bdd1c: ad000261    	stp	q1, q0, [x19]
1015bdd20: 1400003c    	b	0x1015bde10 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x21c>
1015bdd24: 94357105    	bl	0x10231a138 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope>
1015bdd28: 360002e0    	tbz	w0, #0x0, 0x1015bdd84 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x190>
1015bdd2c: 5280000b    	mov	w11, #0x0               ; =0
1015bdd30: 5280000a    	mov	w10, #0x0               ; =0
1015bdd34: d2800008    	mov	x8, #0x0                ; =0
1015bdd38: 528000ec    	mov	w12, #0x7               ; =7
1015bdd3c: 1400002e    	b	0x1015bddf4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x200>
1015bdd40: 8b080508    	add	x8, x8, x8, lsl #1
1015bdd44: b9400fea    	ldr	w10, [sp, #0xc]
1015bdd48: 8b2a0100    	add	x0, x8, w10, uxtb
1015bdd4c: eb01001f    	cmp	x0, x1
1015bdd50: 54001e22    	b.hs	0x1015be114 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x520>
1015bdd54: 91000408    	add	x8, x0, #0x1
1015bdd58: eb01011f    	cmp	x8, x1
1015bdd5c: 54001e22    	b.hs	0x1015be120 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x52c>
1015bdd60: f9425296    	ldr	x22, [x20, #0x4a0]
1015bdd64: f8607ad9    	ldr	x25, [x22, x0, lsl #3]
1015bdd68: 8b090529    	add	x9, x9, x9, lsl #1
1015bdd6c: 91000529    	add	x9, x9, #0x1
1015bdd70: eb09033f    	cmp	x25, x9
1015bdd74: 540001c2    	b.hs	0x1015bddac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x1b8>
1015bdd78: b000d3e8    	adrp	x8, 0x10303a000 <_anon.14153027747eb97b5e1b8a22004538d2.98+0x11b0>
1015bdd7c: 910cf508    	add	x8, x8, #0x33d
1015bdd80: 14000011    	b	0x1015bddc4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x1d0>
1015bdd84: f9418308    	ldr	x8, [x24, #0x300]
1015bdd88: f9418709    	ldr	x9, [x24, #0x308]
1015bdd8c: ab170108    	adds	x8, x8, x23
1015bdd90: 54001902    	b.hs	0x1015be0b0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x4bc>
1015bdd94: eb09011f    	cmp	x8, x9
1015bdd98: 540004c9    	b.ls	0x1015bde30 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x23c>
1015bdd9c: 5280000b    	mov	w11, #0x0               ; =0
1015bdda0: 5280000a    	mov	w10, #0x0               ; =0
1015bdda4: 528000cc    	mov	w12, #0x6               ; =6
1015bdda8: 14000013    	b	0x1015bddf4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x200>
1015bddac: f8687ad5    	ldr	x21, [x22, x8, lsl #3]
1015bddb0: eb1902ba    	subs	x26, x21, x25
1015bddb4: fa4122a2    	ccmp	x21, x1, #0x2, hs
1015bddb8: 540008a9    	b.ls	0x1015bdecc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x2d8>
1015bddbc: b000d3e8    	adrp	x8, 0x10303a000 <_anon.14153027747eb97b5e1b8a22004538d2.98+0x11b0>
1015bddc0: 910c7508    	add	x8, x8, #0x31d
1015bddc4: 52800409    	mov	w9, #0x20               ; =32
1015bddc8: b900027f    	str	wzr, [x19]
1015bddcc: 5280018a    	mov	w10, #0xc               ; =12
1015bddd0: a900a26a    	stp	x10, x8, [x19, #0x8]
1015bddd4: f9000e69    	str	x9, [x19, #0x18]
1015bddd8: 1400000e    	b	0x1015bde10 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x21c>
1015bdddc: aa0903ea    	mov	x10, x9
1015bdde0: d360fd2b    	lsr	x11, x9, #32
1015bdde4: 3cc883e0    	ldur	q0, [sp, #0x88]
1015bdde8: 3d801be0    	str	q0, [sp, #0x60]
1015bddec: 528000ec    	mov	w12, #0x7               ; =7
1015bddf0: aa0d03e9    	mov	x9, x13
1015bddf4: b900027f    	str	wzr, [x19]
1015bddf8: a900a26c    	stp	x12, x8, [x19, #0x8]
1015bddfc: f9000e69    	str	x9, [x19, #0x18]
1015bde00: 29042e6a    	stp	w10, w11, [x19, #0x20]
1015bde04: 3dc01be0    	ldr	q0, [sp, #0x60]
1015bde08: 3c828260    	stur	q0, [x19, #0x28]
1015bde0c: b9003a7f    	str	wzr, [x19, #0x38]
1015bde10: a9567bfd    	ldp	x29, x30, [sp, #0x160]
1015bde14: a9554ff4    	ldp	x20, x19, [sp, #0x150]
1015bde18: a95457f6    	ldp	x22, x21, [sp, #0x140]
1015bde1c: a9535ff8    	ldp	x24, x23, [sp, #0x130]
1015bde20: a95267fa    	ldp	x26, x25, [sp, #0x120]
1015bde24: a9516ffc    	ldp	x28, x27, [sp, #0x110]
1015bde28: 9105c3ff    	add	sp, sp, #0x170
1015bde2c: d65f03c0    	ret
1015bde30: f9018308    	str	x8, [x24, #0x300]
1015bde34: b4fff015    	cbz	x21, 0x1015bdc34 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x40>
1015bde38: d280001b    	mov	x27, #0x0               ; =0
1015bde3c: d2800017    	mov	x23, #0x0               ; =0
1015bde40: d37beabc    	lsl	x28, x21, #5
1015bde44: 52801415    	mov	w21, #0xa0              ; =160
1015bde48: 14000005    	b	0x1015bde5c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x268>
1015bde4c: 9102437b    	add	x27, x27, #0x90
1015bde50: 910006f7    	add	x23, x23, #0x1
1015bde54: f100839c    	subs	x28, x28, #0x20
1015bde58: 54ffeee0    	b.eq	0x1015bdc34 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x40>
1015bde5c: f8420740    	ldr	x0, [x26], #0x20
1015bde60: f942f721    	ldr	x1, [x25, #0x5e8]
1015bde64: eb01001f    	cmp	x0, x1
1015bde68: 54001482    	b.hs	0x1015be0f8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x504>
1015bde6c: f942f328    	ldr	x8, [x25, #0x5e0]
1015bde70: 9b152008    	madd	x8, x0, x21, x8
1015bde74: b9409908    	ldr	w8, [x8, #0x98]
1015bde78: 6b16011f    	cmp	w8, w22
1015bde7c: 54fffe81    	b.ne	0x1015bde4c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x258>
1015bde80: f9402b01    	ldr	x1, [x24, #0x50]
1015bde84: eb0102ff    	cmp	x23, x1
1015bde88: 540013e2    	b.hs	0x1015be104 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x510>
1015bde8c: f9402708    	ldr	x8, [x24, #0x48]
1015bde90: 8b1b0108    	add	x8, x8, x27
1015bde94: 3dc00100    	ldr	q0, [x8]
1015bde98: 3d801fe0    	str	q0, [sp, #0x70]
1015bde9c: ad418101    	ldp	q1, q0, [x8, #0x30]
1015bdea0: ad408903    	ldp	q3, q2, [x8, #0x10]
1015bdea4: ad040be3    	stp	q3, q2, [sp, #0x80]
1015bdea8: ad0503e1    	stp	q1, q0, [sp, #0xa0]
1015bdeac: ad428500    	ldp	q0, q1, [x8, #0x50]
1015bdeb0: ad438d02    	ldp	q2, q3, [x8, #0x70]
1015bdeb4: ad070fe2    	stp	q2, q3, [sp, #0xe0]
1015bdeb8: ad0607e0    	stp	q0, q1, [sp, #0xc0]
1015bdebc: f900011f    	str	xzr, [x8]
1015bdec0: 9101c3e0    	add	x0, sp, #0x70
1015bdec4: 97ff90b0    	bl	0x1015a2184 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime4maps5owner5spans4LaneEEB1g_>
1015bdec8: 17ffffe1    	b	0x1015bde4c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x258>
1015bdecc: d37cff48    	lsr	x8, x26, #60
1015bded0: b5000fa8    	cbnz	x8, 0x1015be0c4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x4d0>
1015bded4: d37cef48    	lsl	x8, x26, #4
1015bded8: b101051f    	cmn	x8, #0x41
1015bdedc: 54000f48    	b.hi	0x1015be0c4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x4d0>
1015bdee0: 91010114    	add	x20, x8, #0x40
1015bdee4: f9418b08    	ldr	x8, [x24, #0x310]
1015bdee8: b4000228    	cbz	x8, 0x1015bdf2c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x338>
1015bdeec: f9418702    	ldr	x2, [x24, #0x308]
1015bdef0: 9101c3e8    	add	x8, sp, #0x70
1015bdef4: 910c4300    	add	x0, x24, #0x310
1015bdef8: aa1403e1    	mov	x1, x20
1015bdefc: 94357288    	bl	0x10231a91c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>
1015bdf00: 3941c3e8    	ldrb	w8, [sp, #0x70]
1015bdf04: 7100211f    	cmp	w8, #0x8
1015bdf08: 54000500    	b.eq	0x1015bdfa8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x3b4>
1015bdf0c: a94723ed    	ldp	x13, x8, [sp, #0x70]
1015bdf10: f94043e9    	ldr	x9, [sp, #0x80]
1015bdf14: 92403daa    	and	x10, x13, #0xffff
1015bdf18: f118195f    	cmp	x10, #0x606
1015bdf1c: 540002a1    	b.ne	0x1015bdf70 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x37c>
1015bdf20: 5280000b    	mov	w11, #0x0               ; =0
1015bdf24: 528000cc    	mov	w12, #0x6               ; =6
1015bdf28: 14000019    	b	0x1015bdf8c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x398>
1015bdf2c: 94357083    	bl	0x10231a138 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope>
1015bdf30: 360000c0    	tbz	w0, #0x0, 0x1015bdf48 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x354>
1015bdf34: d2800008    	mov	x8, #0x0                ; =0
1015bdf38: 5280000b    	mov	w11, #0x0               ; =0
1015bdf3c: 5280000a    	mov	w10, #0x0               ; =0
1015bdf40: 528000ec    	mov	w12, #0x7               ; =7
1015bdf44: 14000012    	b	0x1015bdf8c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x398>
1015bdf48: f9418308    	ldr	x8, [x24, #0x300]
1015bdf4c: f9418709    	ldr	x9, [x24, #0x308]
1015bdf50: ab140108    	adds	x8, x8, x20
1015bdf54: 54000c82    	b.hs	0x1015be0e4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x4f0>
1015bdf58: eb09011f    	cmp	x8, x9
1015bdf5c: 54000249    	b.ls	0x1015bdfa4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x3b0>
1015bdf60: 5280000b    	mov	w11, #0x0               ; =0
1015bdf64: 5280000a    	mov	w10, #0x0               ; =0
1015bdf68: 528000cc    	mov	w12, #0x6               ; =6
1015bdf6c: 14000008    	b	0x1015bdf8c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x398>
1015bdf70: d360fd2a    	lsr	x10, x9, #32
1015bdf74: 3cc883e0    	ldur	q0, [sp, #0x88]
1015bdf78: 3d8007e0    	str	q0, [sp, #0x10]
1015bdf7c: 528000ec    	mov	w12, #0x7               ; =7
1015bdf80: aa0903eb    	mov	x11, x9
1015bdf84: aa0803e9    	mov	x9, x8
1015bdf88: aa0d03e8    	mov	x8, x13
1015bdf8c: b900027f    	str	wzr, [x19]
1015bdf90: 3900226c    	strb	w12, [x19, #0x8]
1015bdf94: a9012668    	stp	x8, x9, [x19, #0x10]
1015bdf98: 29042a6b    	stp	w11, w10, [x19, #0x20]
1015bdf9c: 3dc007e0    	ldr	q0, [sp, #0x10]
1015bdfa0: 17ffff9a    	b	0x1015bde08 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x214>
1015bdfa4: f9018308    	str	x8, [x24, #0x300]
1015bdfa8: eb1902bf    	cmp	x21, x25
1015bdfac: 54000300    	b.eq	0x1015be00c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x418>
1015bdfb0: 9101c3f5    	add	x21, sp, #0x70
1015bdfb4: d37df35a    	lsl	x26, x26, #3
1015bdfb8: 8b190ed6    	add	x22, x22, x25, lsl #3
1015bdfbc: b84086d4    	ldr	w20, [x22], #0x8
1015bdfc0: f941e301    	ldr	x1, [x24, #0x3c0]
1015bdfc4: 9101c3e0    	add	x0, sp, #0x70
1015bdfc8: 911322e2    	add	x2, x23, #0x4c8
1015bdfcc: 910be304    	add	x4, x24, #0x2f8
1015bdfd0: aa1403e3    	mov	x3, x20
1015bdfd4: 97ffb4f8    	bl	0x1015ab3b4 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire>
1015bdfd8: b94073e8    	ldr	w8, [sp, #0x70]
1015bdfdc: 7100191f    	cmp	w8, #0x6
1015bdfe0: 540001c1    	b.ne	0x1015be018 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x424>
1015bdfe4: 9101c3e8    	add	x8, sp, #0x70
1015bdfe8: 9103c300    	add	x0, x24, #0xf0
1015bdfec: 910be302    	add	x2, x24, #0x2f8
1015bdff0: aa1403e1    	mov	x1, x20
1015bdff4: 94002662    	bl	0x1015c797c <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena14retire_current>
1015bdff8: 3941c3e8    	ldrb	w8, [sp, #0x70]
1015bdffc: 7100511f    	cmp	w8, #0x14
1015be000: 54000281    	b.ne	0x1015be050 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x45c>
1015be004: f100235a    	subs	x26, x26, #0x8
1015be008: 54fffda1    	b.ne	0x1015bdfbc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x3c8>
1015be00c: 528000c8    	mov	w8, #0x6                ; =6
1015be010: b9000268    	str	w8, [x19]
1015be014: 17ffff7f    	b	0x1015bde10 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x21c>
1015be018: 3941d3e9    	ldrb	w9, [sp, #0x74]
1015be01c: 3cc853e0    	ldur	q0, [sp, #0x85]
1015be020: 3c815260    	stur	q0, [x19, #0x15]
1015be024: 3cc252a0    	ldur	q0, [x21, #0x25]
1015be028: 3c825260    	stur	q0, [x19, #0x25]
1015be02c: 3cc352a0    	ldur	q0, [x21, #0x35]
1015be030: 3c835260    	stur	q0, [x19, #0x35]
1015be034: 3dc02fe0    	ldr	q0, [sp, #0xb0]
1015be038: 3d801260    	str	q0, [x19, #0x40]
1015be03c: 3cc753e0    	ldur	q0, [sp, #0x75]
1015be040: 3c805260    	stur	q0, [x19, #0x5]
1015be044: b9000268    	str	w8, [x19]
1015be048: 39001269    	strb	w9, [x19, #0x4]
1015be04c: 17ffff71    	b	0x1015bde10 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x21c>
1015be050: ad4387e0    	ldp	q0, q1, [sp, #0x70]
1015be054: ad0107e0    	stp	q0, q1, [sp, #0x20]
1015be058: 3dc027e2    	ldr	q2, [sp, #0x90]
1015be05c: 3d8013e2    	str	q2, [sp, #0x40]
1015be060: f94053e8    	ldr	x8, [sp, #0xa0]
1015be064: f9002be8    	str	x8, [sp, #0x50]
1015be068: 3c8743e0    	stur	q0, [sp, #0x74]
1015be06c: 3c8843e1    	stur	q1, [sp, #0x84]
1015be070: 3c8242a2    	stur	q2, [x21, #0x24]
1015be074: f80342a8    	stur	x8, [x21, #0x34]
1015be078: 52800048    	mov	w8, #0x2                ; =2
1015be07c: b9000268    	str	w8, [x19]
1015be080: ad4387e0    	ldp	q0, q1, [sp, #0x70]
1015be084: 3c804260    	stur	q0, [x19, #0x4]
1015be088: 3c814261    	stur	q1, [x19, #0x14]
1015be08c: 3dc027e0    	ldr	q0, [sp, #0x90]
1015be090: 3c824260    	stur	q0, [x19, #0x24]
1015be094: 3cc2c2a0    	ldur	q0, [x21, #0x2c]
1015be098: 3d800e60    	str	q0, [x19, #0x30]
1015be09c: 17ffff5d    	b	0x1015bde10 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x21c>
1015be0a0: d0012080    	adrp	x0, 0x1039d0000 <_anon.14153027747eb97b5e1b8a22004538d2.207+0xc0>
1015be0a4: 913ee000    	add	x0, x0, #0xfb8
1015be0a8: 9460d6de    	bl	0x102df3c20 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1015be0ac: 17ffff52    	b	0x1015bddf4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x200>
1015be0b0: 5280000b    	mov	w11, #0x0               ; =0
1015be0b4: 5280000a    	mov	w10, #0x0               ; =0
1015be0b8: 92800008    	mov	x8, #-0x1               ; =-1
1015be0bc: 528000cc    	mov	w12, #0x6               ; =6
1015be0c0: 17ffff4d    	b	0x1015bddf4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x200>
1015be0c4: b900027f    	str	wzr, [x19]
1015be0c8: 52800188    	mov	w8, #0xc                ; =12
1015be0cc: d000d3c9    	adrp	x9, 0x103038000 <_anon.6283f84d1d139f8f117b6935f97d7394.486+0xcd7>
1015be0d0: 91394129    	add	x9, x9, #0xe50
1015be0d4: a900a668    	stp	x8, x9, [x19, #0x8]
1015be0d8: 52800348    	mov	w8, #0x1a               ; =26
1015be0dc: f9000e68    	str	x8, [x19, #0x18]
1015be0e0: 17ffff4c    	b	0x1015bde10 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x21c>
1015be0e4: 5280000b    	mov	w11, #0x0               ; =0
1015be0e8: 5280000a    	mov	w10, #0x0               ; =0
1015be0ec: 92800008    	mov	x8, #-0x1               ; =-1
1015be0f0: 528000cc    	mov	w12, #0x6               ; =6
1015be0f4: 17ffffa6    	b	0x1015bdf8c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals+0x398>
1015be0f8: d0012082    	adrp	x2, 0x1039d0000 <_anon.14153027747eb97b5e1b8a22004538d2.207+0xc0>
1015be0fc: 913f4042    	add	x2, x2, #0xfd0
1015be100: 9460d6ef    	bl	0x102df3cbc <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015be104: d0012082    	adrp	x2, 0x1039d0000 <_anon.14153027747eb97b5e1b8a22004538d2.207+0xc0>
1015be108: 913fa042    	add	x2, x2, #0xfe8
1015be10c: aa1703e0    	mov	x0, x23
1015be110: 9460d6eb    	bl	0x102df3cbc <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015be114: d0012082    	adrp	x2, 0x1039d0000 <_anon.14153027747eb97b5e1b8a22004538d2.207+0xc0>
1015be118: 91032042    	add	x2, x2, #0xc8
1015be11c: 9460d6e8    	bl	0x102df3cbc <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015be120: d0012082    	adrp	x2, 0x1039d0000 <_anon.14153027747eb97b5e1b8a22004538d2.207+0xc0>
1015be124: 91038042    	add	x2, x2, #0xe0
1015be128: aa0803e0    	mov	x0, x8
1015be12c: 9460d6e4    	bl	0x102df3cbc <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
