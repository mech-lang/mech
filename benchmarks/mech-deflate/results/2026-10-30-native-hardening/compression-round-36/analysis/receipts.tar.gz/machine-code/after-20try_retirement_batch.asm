
/private/tmp/mech-retirement-round36-20261030/workers/after:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101553b80 <__RNvMNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4work10retirementNtB4_15NativeWorkMeter20try_retirement_batch>:
101553b80: d10183ff    	sub	sp, sp, #0x60
101553b84: a90357f6    	stp	x22, x21, [sp, #0x30]
101553b88: a9044ff4    	stp	x20, x19, [sp, #0x40]
101553b8c: a9057bfd    	stp	x29, x30, [sp, #0x50]
101553b90: 910143fd    	add	x29, sp, #0x50
101553b94: aa0103f3    	mov	x19, x1
101553b98: aa0003f4    	mov	x20, x0
101553b9c: aa0003f5    	mov	x21, x0
101553ba0: f8418ea8    	ldr	x8, [x21, #0x18]!
101553ba4: f85f82b6    	ldur	x22, [x21, #-0x8]
101553ba8: b40000e8    	cbz	x8, 0x101553bc4 <__RNvMNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4work10retirementNtB4_15NativeWorkMeter20try_retirement_batch+0x44>
101553bac: aa1503e0    	mov	x0, x21
101553bb0: 94371a92    	bl	0x10231a5f8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget4used>
101553bb4: eb0002c8    	subs	x8, x22, x0
101553bb8: fa532100    	ccmp	x8, x19, #0x0, hs
101553bbc: 540000c2    	b.hs	0x101553bd4 <__RNvMNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4work10retirementNtB4_15NativeWorkMeter20try_retirement_batch+0x54>
101553bc0: 14000035    	b	0x101553c94 <__RNvMNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4work10retirementNtB4_15NativeWorkMeter20try_retirement_batch+0x114>
101553bc4: f85f02a0    	ldur	x0, [x21, #-0x10]
101553bc8: eb0002c8    	subs	x8, x22, x0
101553bcc: fa532100    	ccmp	x8, x19, #0x0, hs
101553bd0: 54000623    	b.lo	0x101553c94 <__RNvMNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4work10retirementNtB4_15NativeWorkMeter20try_retirement_batch+0x114>
101553bd4: f94002a8    	ldr	x8, [x21]
101553bd8: b40001c8    	cbz	x8, 0x101553c10 <__RNvMNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4work10retirementNtB4_15NativeWorkMeter20try_retirement_batch+0x90>
101553bdc: aa1503e0    	mov	x0, x21
101553be0: 943721b1    	bl	0x10231c2a4 <__RNvMs3_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workersNtB7_23NativeLibraryWorkBudget16is_worker_budget>
101553be4: 37000580    	tbnz	w0, #0x0, 0x101553c94 <__RNvMNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4work10retirementNtB4_15NativeWorkMeter20try_retirement_batch+0x114>
101553be8: 910023e8    	add	x8, sp, #0x8
101553bec: aa1503e0    	mov	x0, x21
101553bf0: 9437179a    	bl	0x102319a58 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
101553bf4: f94007e8    	ldr	x8, [sp, #0x8]
101553bf8: f100051f    	cmp	x8, #0x1
101553bfc: 540004c1    	b.ne	0x101553c94 <__RNvMNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4work10retirementNtB4_15NativeWorkMeter20try_retirement_batch+0x114>
101553c00: f9400be8    	ldr	x8, [sp, #0x10]
101553c04: eb13011f    	cmp	x8, x19
101553c08: 54000463    	b.lo	0x101553c94 <__RNvMNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4work10retirementNtB4_15NativeWorkMeter20try_retirement_batch+0x114>
101553c0c: 14000003    	b	0x101553c18 <__RNvMNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4work10retirementNtB4_15NativeWorkMeter20try_retirement_batch+0x98>
101553c10: 9437176f    	bl	0x1023199cc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope>
101553c14: 37000400    	tbnz	w0, #0x0, 0x101553c94 <__RNvMNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4work10retirementNtB4_15NativeWorkMeter20try_retirement_batch+0x114>
101553c18: f94002a8    	ldr	x8, [x21]
101553c1c: b4000388    	cbz	x8, 0x101553c8c <__RNvMNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4work10retirementNtB4_15NativeWorkMeter20try_retirement_batch+0x10c>
101553c20: f9400a82    	ldr	x2, [x20, #0x10]
101553c24: 910023e8    	add	x8, sp, #0x8
101553c28: aa1503e0    	mov	x0, x21
101553c2c: aa1303e1    	mov	x1, x19
101553c30: 94371960    	bl	0x10231a1b0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>
101553c34: 394023e8    	ldrb	w8, [sp, #0x8]
101553c38: 7100211f    	cmp	w8, #0x8
101553c3c: 540004a0    	b.eq	0x101553cd0 <__RNvMNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4work10retirementNtB4_15NativeWorkMeter20try_retirement_batch+0x150>
101553c40: 7100191f    	cmp	w8, #0x6
101553c44: 54000081    	b.ne	0x101553c54 <__RNvMNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4work10retirementNtB4_15NativeWorkMeter20try_retirement_batch+0xd4>
101553c48: 394027e9    	ldrb	w9, [sp, #0x9]
101553c4c: 7100193f    	cmp	w9, #0x6
101553c50: 54000220    	b.eq	0x101553c94 <__RNvMNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4work10retirementNtB4_15NativeWorkMeter20try_retirement_batch+0x114>
101553c54: 7100111f    	cmp	w8, #0x4
101553c58: 540001e1    	b.ne	0x101553c94 <__RNvMNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4work10retirementNtB4_15NativeWorkMeter20try_retirement_batch+0x114>
101553c5c: a941d3e1    	ldp	x1, x20, [sp, #0x18]
101553c60: f94017f5    	ldr	x21, [sp, #0x28]
101553c64: b4000081    	cbz	x1, 0x101553c74 <__RNvMNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4work10retirementNtB4_15NativeWorkMeter20try_retirement_batch+0xf4>
101553c68: f9400be0    	ldr	x0, [sp, #0x10]
101553c6c: 52800022    	mov	w2, #0x1                ; =1
101553c70: 97aad633    	bl	0x10000953c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
101553c74: b4000115    	cbz	x21, 0x101553c94 <__RNvMNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4work10retirementNtB4_15NativeWorkMeter20try_retirement_batch+0x114>
101553c78: aa1403e0    	mov	x0, x20
101553c7c: aa1503e1    	mov	x1, x21
101553c80: 52800022    	mov	w2, #0x1                ; =1
101553c84: 97aad62e    	bl	0x10000953c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
101553c88: 14000003    	b	0x101553c94 <__RNvMNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4work10retirementNtB4_15NativeWorkMeter20try_retirement_batch+0x114>
101553c8c: 94371750    	bl	0x1023199cc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope>
101553c90: 36000100    	tbz	w0, #0x0, 0x101553cb0 <__RNvMNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4work10retirementNtB4_15NativeWorkMeter20try_retirement_batch+0x130>
101553c94: d2800000    	mov	x0, #0x0                ; =0
101553c98: aa1303e1    	mov	x1, x19
101553c9c: a9457bfd    	ldp	x29, x30, [sp, #0x50]
101553ca0: a9444ff4    	ldp	x20, x19, [sp, #0x40]
101553ca4: a94357f6    	ldp	x22, x21, [sp, #0x30]
101553ca8: 910183ff    	add	sp, sp, #0x60
101553cac: d65f03c0    	ret
101553cb0: d2800000    	mov	x0, #0x0                ; =0
101553cb4: f9400688    	ldr	x8, [x20, #0x8]
101553cb8: ab130108    	adds	x8, x8, x19
101553cbc: 54fffee2    	b.hs	0x101553c98 <__RNvMNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4work10retirementNtB4_15NativeWorkMeter20try_retirement_batch+0x118>
101553cc0: f9400a89    	ldr	x9, [x20, #0x10]
101553cc4: eb09011f    	cmp	x8, x9
101553cc8: 54fffe88    	b.hi	0x101553c98 <__RNvMNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4work10retirementNtB4_15NativeWorkMeter20try_retirement_batch+0x118>
101553ccc: f9000688    	str	x8, [x20, #0x8]
101553cd0: aa1403e0    	mov	x0, x20
101553cd4: 17fffff1    	b	0x101553c98 <__RNvMNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4work10retirementNtB4_15NativeWorkMeter20try_retirement_batch+0x118>
