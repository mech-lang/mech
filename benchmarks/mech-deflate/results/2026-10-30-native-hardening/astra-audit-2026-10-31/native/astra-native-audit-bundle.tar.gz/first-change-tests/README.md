# Delayed first-change regression draft

Apply `tests.patch` independently of `../first-change-spill.patch` and run it on parent and candidate. Exact unit selector:

```
native_artifact::program::runtime::tests::numeric_first_change::delayed_numeric_first_changes_preserve_current_scalars_two_arrays_and_retry
```

Feature profile: `canonical-native-program`, GPU library test binary. Equivalent Cargo command (prefer the parent's already frozen direct-rustc graph):

```
cargo +nightly-2026-03-03 test --locked --offline -p mech-gpu --no-default-features --features canonical-native-program --lib delayed_numeric_first_changes_preserve_current_scalars_two_arrays_and_retry -- --nocapture --test-threads=1
```

Exactly one test should execute. Because its module is under `runtime::tests`, the retained `native_artifact::program::runtime::` inventory increases from327 to328. This test does not add an integration case or change the native-composition selection count.

The program uses two one-cell arrays, writes unchanged values on early visits and first changes the arrays at visits3 and5. Current `i`, `end`, accumulated `total`, accumulated `checksum`, and a changing Boolean are observed at the actual native first-change helper; several newly computed scalars must also survive both callbacks before the recursive transfer. An independent Rust model establishes the final result and expected carrier state. Original and decoded artifacts must agree on work. The input sequence includes real shared backing, a callback lane-capacity rejection, an original clone-admission rejection, changed fresh inputs, retry, unchanged previously published values and full cleanup.

The observer and execution wrapper remain in the existing audited `runtime/tests.rs` owner; the new case module contains no unsafe code, and no unsafe-boundary allowlist expansion is required.

The callback-capacity corruption changes only `Invocation.argument_capacity` while the generated entry is suspended in its first-change helper, then restores it. It provokes the real checked callback word read before loan settlement. The generated pre-call guard uses an entry-hoisted SSA capacity; this test deliberately does not claim to corrupt or exercise that guard. Testing that exact guard would need a separate private codegen fixture or a larger test seam and is not included in the bounded patch.

This audit agent formatted and source-reviewed the draft; it did not apply, compile or run it. In particular, the focused first run must confirm the derived carrier scalar ordering agrees with the source function parameter order assumed by the oracle. No performance claim follows from this test.
