# R61 first-change snapshot deletion: exact static reconciliation

Actual candidate Object SHA-256: `4e222709764d92ac2b2b74e06a7237d3b901bf07cf095e1c23a7751c0dd8269d`. Parent/candidate are retained under R60 and R61 `linked-primary/after`. Source/typed-IR identity is unchanged. These are static encoded instructions and stack accesses; primary elapsed and hardware counters are separate parent-owned cohorts.

| Quantity | R60 | R61 | Change |
|---|---:|---:|---:|
| Text bytes |13,806,352|13,082,688|−723,664|
| Machine entry stack bytes |108,880|105,552|−3,328|
| Encoded instructions |3,451,588|3,270,672|−180,916|
| UDIV |101|101|0|
| MSUB |16|16|0|
| Scalar stack loads |628,971|593,954|−35,017|
| Scalar stack stores |144,326|137,100|−7,226|
| High-offset indexed stack loads |468,335|438,478|−29,857|
| High-offset indexed stack stores |117,001|111,582|−5,419|
| Original-locals pointer loads |181,076|165,897|−15,179|
| Argument-lane pointer loads |31,255|31,199|−56|

**The deleted original-local snapshots reconcile exactly.** R60 metadata has312 static first-change bridges. Summing each region's `register_words × first_change_boundaries.len()` gives28,774 source-local stores. The Object loses35,975 `str` plus25 `stur`, totaling36,000 scalar stores. Of those,7,226 are machine-stack stores. The remaining `36,000−7,226 =28,774` precisely matches the deleted explicit local-bank snapshot stores. `snapshot-store-proof.json` retains every region, bridge list and term of that sum. These312 static bridges are distinct from the168 executed transitions measured in the earlier complete-call census.

The Object also loses34,977 `ldr` plus40 `ldur`, totaling35,017 scalar loads; the stack census independently finds exactly35,017 fewer scalar stack loads. Thus the net scalar-load reduction in this comparison is entirely register spills/reloads; there is no reduction in the count of encoded algorithm-data loads. This is a static aggregate identity, not a per-site proof that every non-stack instruction is byte-identical. Branch/register placement changes remain possible.

Pointer roles are determined from the unchanged ABI entry loads and saved prologue excerpts. Locals move from stack slot0x1a8d8 to0x19bd0; arguments from0x1a8b0 to0x19ba8. Context, admission callback, helper callback, result pointer and native-frame pointer load counts remain unchanged; the argument-capacity load count decreases3. See `pointer-delta.json` and `before/after-prologue.asm`.

**The underlying large-function allocation issue remains.** R61 still reloads the locals pointer165,897 times in the Object, compared with118,456 before vector addressing (+47,441). Argument-pointer reloads remain31,199 versus15,523 (+15,676). The snapshot change removes real useless exports and improves its surrounding allocation, but it does not establish a cure for the broader global-pointer spill behavior. The two-split regalloc fallback remains a hypothesis to trace, not an established root cause. The next diagnostic described in `../r60-stack-audit/README.md` is still justified.

The parent reports a separate matched timing improvement13.54858657→13.35954240 times the contemporaneous reference (1.395305%, four of four pairs and57 of64 blocks), retired instructions42,439,545.5→42,253,819 (0.437626%), and cycles down0.201954%. This audit did not execute those cohorts or independently reconstruct their timing aggregates; use the parent's retained primary/counter receipts for provenance and acceptance.

`binary-audit.json` combines full Object opcode comparison, input hashes, pointer counts and the store reconciliation. The same combined report is written at the parent-requested R61 root, with detailed files in R61 `binary-audit/`. `../compare-native-objects.py` and `../audit-stack-reloads.py` reproduce static portions without compiling or executing a compressor.
