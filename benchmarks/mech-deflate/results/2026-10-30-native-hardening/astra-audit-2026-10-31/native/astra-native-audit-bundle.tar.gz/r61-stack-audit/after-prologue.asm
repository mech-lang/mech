
/private/tmp/mech-first-change-spill-round61-20261031/linked-primary/after/object.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_mech_canonical_program_entry_v1>:
       0: d503237f     	pacibsp
       4: a9bf7bfd     	stp	x29, x30, [sp, #-0x10]!
       8: 910003fd     	mov	x29, sp
       c: a9bf73fb     	stp	x27, x28, [sp, #-0x10]!
      10: a9bf6bf9     	stp	x25, x26, [sp, #-0x10]!
      14: a9bf63f7     	stp	x23, x24, [sp, #-0x10]!
      18: a9bf5bf5     	stp	x21, x22, [sp, #-0x10]!
      1c: a9bf53f3     	stp	x19, x20, [sp, #-0x10]!
      20: 52937e10     	mov	w16, #0x9bf0            ; =39920
      24: 72a00030     	movk	w16, #0x1, lsl #16
      28: cb3063ff     	sub	sp, sp, x16
      2c: f80003e0     	stur	x0, [sp]
      30: d280006f     	mov	x15, #0x3               ; =3
      34: f100001f     	cmp	x0, #0x0
      38: 54603920     	b.eq	0xc075c <_mech_canonical_program_entry_v1+0xc075c>
      3c: 92800000     	mov	x0, #-0x1               ; =-1
      40: f84003e1     	ldur	x1, [sp]
      44: f9002420     	str	x0, [x1, #0x48]
      48: f84003e0     	ldur	x0, [sp]
      4c: f9400001     	ldr	x1, [x0]
      50: d280006f     	mov	x15, #0x3               ; =3
      54: f100943f     	cmp	x1, #0x25
      58: 54603841     	b.ne	0xc0760 <_mech_canonical_program_entry_v1+0xc0760>
      5c: f84003e0     	ldur	x0, [sp]
      60: f9400401     	ldr	x1, [x0, #0x8]
      64: d280006f     	mov	x15, #0x3               ; =3
      68: f100083f     	cmp	x1, #0x2
      6c: 546037c1     	b.ne	0xc0764 <_mech_canonical_program_entry_v1+0xc0764>
      70: f84003e0     	ldur	x0, [sp]
      74: f9400801     	ldr	x1, [x0, #0x10]
      78: d280006f     	mov	x15, #0x3               ; =3
      7c: d28bc180     	mov	x0, #0x5e0c             ; =24076
      80: eb00003f     	cmp	x1, x0
      84: 54603721     	b.ne	0xc0768 <_mech_canonical_program_entry_v1+0xc0768>
      88: f84003e0     	ldur	x0, [sp]
      8c: f9400c01     	ldr	x1, [x0, #0x18]
      90: d280006f     	mov	x15, #0x3               ; =3
      94: f100043f     	cmp	x1, #0x1
      98: 546036a1     	b.ne	0xc076c <_mech_canonical_program_entry_v1+0xc076c>
      9c: f84003e0     	ldur	x0, [sp]
      a0: f9401005     	ldr	x5, [x0, #0x20]
      a4: f9401401     	ldr	x1, [x0, #0x28]
      a8: f9401804     	ldr	x4, [x0, #0x30]
      ac: f9401c03     	ldr	x3, [x0, #0x38]
      b0: f9402002     	ldr	x2, [x0, #0x40]
      b4: d280006f     	mov	x15, #0x3               ; =3
      b8: f10000bf     	cmp	x5, #0x0
      bc: 546035a0     	b.eq	0xc0770 <_mech_canonical_program_entry_v1+0xc0770>
      c0: d280006f     	mov	x15, #0x3               ; =3
      c4: f100003f     	cmp	x1, #0x0
      c8: 54603560     	b.eq	0xc0774 <_mech_canonical_program_entry_v1+0xc0774>
      cc: d280006f     	mov	x15, #0x3               ; =3
      d0: f100009f     	cmp	x4, #0x0
      d4: 54603520     	b.eq	0xc0778 <_mech_canonical_program_entry_v1+0xc0778>
      d8: d280006f     	mov	x15, #0x3               ; =3
      dc: f100007f     	cmp	x3, #0x0
      e0: 52937910     	mov	w16, #0x9bc8            ; =39880
      e4: 72a00030     	movk	w16, #0x1, lsl #16
      e8: f830ebe3     	str	x3, [sp, x16, sxtx]
      ec: 54603480     	b.eq	0xc077c <_mech_canonical_program_entry_v1+0xc077c>
      f0: d280006f     	mov	x15, #0x3               ; =3
      f4: f100005f     	cmp	x2, #0x0
      f8: 52937810     	mov	w16, #0x9bc0            ; =39872
      fc: 72a00030     	movk	w16, #0x1, lsl #16
     100: f830ebe2     	str	x2, [sp, x16, sxtx]
     104: 546033e0     	b.eq	0xc0780 <_mech_canonical_program_entry_v1+0xc0780>
     108: f84003e0     	ldur	x0, [sp]
     10c: f9402803     	ldr	x3, [x0, #0x50]
     110: f9402c06     	ldr	x6, [x0, #0x58]
     114: f9403002     	ldr	x2, [x0, #0x60]
     118: f9403400     	ldr	x0, [x0, #0x68]
     11c: 52937410     	mov	w16, #0x9ba0            ; =39840
     120: 72a00030     	movk	w16, #0x1, lsl #16
     124: f830ebe0     	str	x0, [sp, x16, sxtx]
     128: d280006f     	mov	x15, #0x3               ; =3
     12c: f100007f     	cmp	x3, #0x0
     130: 52937710     	mov	w16, #0x9bb8            ; =39864
     134: 72a00030     	movk	w16, #0x1, lsl #16
     138: f830ebe3     	str	x3, [sp, x16, sxtx]
     13c: 54603240     	b.eq	0xc0784 <_mech_canonical_program_entry_v1+0xc0784>
     140: d280006f     	mov	x15, #0x3               ; =3
     144: f10000df     	cmp	x6, #0x0
     148: 52937610     	mov	w16, #0x9bb0            ; =39856
     14c: 72a00030     	movk	w16, #0x1, lsl #16
     150: f830ebe6     	str	x6, [sp, x16, sxtx]
     154: 546031a0     	b.eq	0xc0788 <_mech_canonical_program_entry_v1+0xc0788>
     158: d280006f     	mov	x15, #0x3               ; =3
     15c: f100005f     	cmp	x2, #0x0
     160: 52937510     	mov	w16, #0x9ba8            ; =39848
     164: 72a00030     	movk	w16, #0x1, lsl #16
     168: f830ebe2     	str	x2, [sp, x16, sxtx]
     16c: 54603100     	b.eq	0xc078c <_mech_canonical_program_entry_v1+0xc078c>
     170: f84003e0     	ldur	x0, [sp]
     174: f9403804     	ldr	x4, [x0, #0x70]
     178: d280006f     	mov	x15, #0x3               ; =3
     17c: f100049f     	cmp	x4, #0x1
     180: 54603088     	b.hi	0xc0790 <_mech_canonical_program_entry_v1+0xc0790>
     184: f100009f     	cmp	x4, #0x0
     188: f80f03e4     	stur	x4, [sp, #0xf0]
     18c: 54006421     	b.ne	0xe10 <_mech_canonical_program_entry_v1+0xe10>
     190: d280000b     	mov	x11, #0x0               ; =0
     194: f900142b     	str	x11, [x1, #0x28]
     198: f900202b     	str	x11, [x1, #0x40]
     19c: f80e83eb     	stur	x11, [sp, #0xe8]
     1a0: d2800026     	mov	x6, #0x1                ; =1
     1a4: f9002426     	str	x6, [x1, #0x48]
     1a8: f80e03e6     	stur	x6, [sp, #0xe0]
     1ac: d2802037     	mov	x23, #0x101             ; =257
     1b0: f9002837     	str	x23, [x1, #0x50]
     1b4: d2804038     	mov	x24, #0x201             ; =513
     1b8: f9002c38     	str	x24, [x1, #0x58]
     1bc: d2806020     	mov	x0, #0x301              ; =769
     1c0: f9003020     	str	x0, [x1, #0x60]
     1c4: d2808020     	mov	x0, #0x401              ; =1025
     1c8: f9003420     	str	x0, [x1, #0x68]
     1cc: d280c020     	mov	x0, #0x601              ; =1537
     1d0: f9003820     	str	x0, [x1, #0x70]
     1d4: d2810020     	mov	x0, #0x801              ; =2049
     1d8: f9003c20     	str	x0, [x1, #0x78]
     1dc: d2818020     	mov	x0, #0xc01              ; =3073
     1e0: f9004020     	str	x0, [x1, #0x80]
     1e4: d2820020     	mov	x0, #0x1001             ; =4097
     1e8: f9004420     	str	x0, [x1, #0x88]
     1ec: d2830020     	mov	x0, #0x1801             ; =6145
     1f0: f9004820     	str	x0, [x1, #0x90]
     1f4: d2840020     	mov	x0, #0x2001             ; =8193
     1f8: f9004c20     	str	x0, [x1, #0x98]
     1fc: d2860020     	mov	x0, #0x3001             ; =12289
