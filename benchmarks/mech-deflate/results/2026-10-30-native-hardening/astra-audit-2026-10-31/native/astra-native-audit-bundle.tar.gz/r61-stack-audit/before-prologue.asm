
/private/tmp/mech-vector-address-round60-20261031/linked-primary/after/object.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_mech_canonical_program_entry_v1>:
       0: d503237f     	pacibsp
       4: a9bf7bfd     	stp	x29, x30, [sp, #-0x10]!
       8: 910003fd     	mov	x29, sp
       c: a9bf73fb     	stp	x27, x28, [sp, #-0x10]!
      10: a9bf6bf9     	stp	x25, x26, [sp, #-0x10]!
      14: a9bf63f7     	stp	x23, x24, [sp, #-0x10]!
      18: a9bf5bf5     	stp	x21, x22, [sp, #-0x10]!
      1c: a9bf53f3     	stp	x19, x20, [sp, #-0x10]!
      20: 52951e10     	mov	w16, #0xa8f0            ; =43248
      24: 72a00030     	movk	w16, #0x1, lsl #16
      28: cb3063ff     	sub	sp, sp, x16
      2c: f80003e0     	stur	x0, [sp]
      30: d280006f     	mov	x15, #0x3               ; =3
      34: f100001f     	cmp	x0, #0x0
      38: 54603700     	b.eq	0xc0718 <_mech_canonical_program_entry_v1+0xc0718>
      3c: 92800000     	mov	x0, #-0x1               ; =-1
      40: f84003e1     	ldur	x1, [sp]
      44: f9002420     	str	x0, [x1, #0x48]
      48: f84003e0     	ldur	x0, [sp]
      4c: f9400001     	ldr	x1, [x0]
      50: d280006f     	mov	x15, #0x3               ; =3
      54: f100943f     	cmp	x1, #0x25
      58: 54603621     	b.ne	0xc071c <_mech_canonical_program_entry_v1+0xc071c>
      5c: f84003e0     	ldur	x0, [sp]
      60: f9400401     	ldr	x1, [x0, #0x8]
      64: d280006f     	mov	x15, #0x3               ; =3
      68: f100083f     	cmp	x1, #0x2
      6c: 546035a1     	b.ne	0xc0720 <_mech_canonical_program_entry_v1+0xc0720>
      70: f84003e0     	ldur	x0, [sp]
      74: f9400801     	ldr	x1, [x0, #0x10]
      78: d280006f     	mov	x15, #0x3               ; =3
      7c: d28bc180     	mov	x0, #0x5e0c             ; =24076
      80: eb00003f     	cmp	x1, x0
      84: 54603501     	b.ne	0xc0724 <_mech_canonical_program_entry_v1+0xc0724>
      88: f84003e0     	ldur	x0, [sp]
      8c: f9400c01     	ldr	x1, [x0, #0x18]
      90: d280006f     	mov	x15, #0x3               ; =3
      94: f100043f     	cmp	x1, #0x1
      98: 54603481     	b.ne	0xc0728 <_mech_canonical_program_entry_v1+0xc0728>
      9c: f84003e0     	ldur	x0, [sp]
      a0: f9401005     	ldr	x5, [x0, #0x20]
      a4: f9401401     	ldr	x1, [x0, #0x28]
      a8: f9401804     	ldr	x4, [x0, #0x30]
      ac: f9401c03     	ldr	x3, [x0, #0x38]
      b0: f9402002     	ldr	x2, [x0, #0x40]
      b4: d280006f     	mov	x15, #0x3               ; =3
      b8: f10000bf     	cmp	x5, #0x0
      bc: 54603380     	b.eq	0xc072c <_mech_canonical_program_entry_v1+0xc072c>
      c0: d280006f     	mov	x15, #0x3               ; =3
      c4: f100003f     	cmp	x1, #0x0
      c8: 54603340     	b.eq	0xc0730 <_mech_canonical_program_entry_v1+0xc0730>
      cc: d280006f     	mov	x15, #0x3               ; =3
      d0: f100009f     	cmp	x4, #0x0
      d4: 54603300     	b.eq	0xc0734 <_mech_canonical_program_entry_v1+0xc0734>
      d8: d280006f     	mov	x15, #0x3               ; =3
      dc: f100007f     	cmp	x3, #0x0
      e0: 52951a10     	mov	w16, #0xa8d0            ; =43216
      e4: 72a00030     	movk	w16, #0x1, lsl #16
      e8: f830ebe3     	str	x3, [sp, x16, sxtx]
      ec: 54603260     	b.eq	0xc0738 <_mech_canonical_program_entry_v1+0xc0738>
      f0: d280006f     	mov	x15, #0x3               ; =3
      f4: f100005f     	cmp	x2, #0x0
      f8: 52951910     	mov	w16, #0xa8c8            ; =43208
      fc: 72a00030     	movk	w16, #0x1, lsl #16
     100: f830ebe2     	str	x2, [sp, x16, sxtx]
     104: 546031c0     	b.eq	0xc073c <_mech_canonical_program_entry_v1+0xc073c>
     108: f84003e0     	ldur	x0, [sp]
     10c: f940280b     	ldr	x11, [x0, #0x50]
     110: f9402c06     	ldr	x6, [x0, #0x58]
     114: f940300a     	ldr	x10, [x0, #0x60]
     118: f940340c     	ldr	x12, [x0, #0x68]
     11c: 52951510     	mov	w16, #0xa8a8            ; =43176
     120: 72a00030     	movk	w16, #0x1, lsl #16
     124: f830ebec     	str	x12, [sp, x16, sxtx]
     128: d280006f     	mov	x15, #0x3               ; =3
     12c: f100017f     	cmp	x11, #0x0
     130: 52951810     	mov	w16, #0xa8c0            ; =43200
     134: 72a00030     	movk	w16, #0x1, lsl #16
     138: f830ebeb     	str	x11, [sp, x16, sxtx]
     13c: 54603020     	b.eq	0xc0740 <_mech_canonical_program_entry_v1+0xc0740>
     140: d280006f     	mov	x15, #0x3               ; =3
     144: f10000df     	cmp	x6, #0x0
     148: 52951710     	mov	w16, #0xa8b8            ; =43192
     14c: 72a00030     	movk	w16, #0x1, lsl #16
     150: f830ebe6     	str	x6, [sp, x16, sxtx]
     154: 54602f80     	b.eq	0xc0744 <_mech_canonical_program_entry_v1+0xc0744>
     158: d280006f     	mov	x15, #0x3               ; =3
     15c: f100015f     	cmp	x10, #0x0
     160: 52951610     	mov	w16, #0xa8b0            ; =43184
     164: 72a00030     	movk	w16, #0x1, lsl #16
     168: f830ebea     	str	x10, [sp, x16, sxtx]
     16c: 54602ee0     	b.eq	0xc0748 <_mech_canonical_program_entry_v1+0xc0748>
     170: f84003e0     	ldur	x0, [sp]
     174: f940380e     	ldr	x14, [x0, #0x70]
     178: d280006f     	mov	x15, #0x3               ; =3
     17c: f10005df     	cmp	x14, #0x1
     180: 54602e68     	b.hi	0xc074c <_mech_canonical_program_entry_v1+0xc074c>
     184: f10001df     	cmp	x14, #0x0
     188: f80f03ee     	stur	x14, [sp, #0xf0]
     18c: 540063c1     	b.ne	0xe04 <_mech_canonical_program_entry_v1+0xe04>
     190: d2800006     	mov	x6, #0x0                ; =0
     194: f9001426     	str	x6, [x1, #0x28]
     198: f9002026     	str	x6, [x1, #0x40]
     19c: f80e83e6     	stur	x6, [sp, #0xe8]
     1a0: d2800037     	mov	x23, #0x1               ; =1
     1a4: f9002437     	str	x23, [x1, #0x48]
     1a8: d2802038     	mov	x24, #0x101             ; =257
     1ac: f9002838     	str	x24, [x1, #0x50]
     1b0: d2804039     	mov	x25, #0x201             ; =513
     1b4: f9002c39     	str	x25, [x1, #0x58]
     1b8: d2806020     	mov	x0, #0x301              ; =769
     1bc: f9003020     	str	x0, [x1, #0x60]
     1c0: d2808020     	mov	x0, #0x401              ; =1025
     1c4: f9003420     	str	x0, [x1, #0x68]
     1c8: d280c020     	mov	x0, #0x601              ; =1537
     1cc: f9003820     	str	x0, [x1, #0x70]
     1d0: d2810020     	mov	x0, #0x801              ; =2049
     1d4: f9003c20     	str	x0, [x1, #0x78]
     1d8: d2818020     	mov	x0, #0xc01              ; =3073
     1dc: f9004020     	str	x0, [x1, #0x80]
     1e0: d2820020     	mov	x0, #0x1001             ; =4097
     1e4: f9004420     	str	x0, [x1, #0x88]
     1e8: d2830020     	mov	x0, #0x1801             ; =6145
     1ec: f9004820     	str	x0, [x1, #0x90]
     1f0: d2840020     	mov	x0, #0x2001             ; =8193
     1f4: f9004c20     	str	x0, [x1, #0x98]
     1f8: d2860020     	mov	x0, #0x3001             ; =12289
     1fc: f9005020     	str	x0, [x1, #0xa0]
