# Native instruction audit at R56

Reviewed immutable checkpoint: `46617b61f3ccf0e4a6ddf27fe37f9f4003016ac4`.
Object: `/private/tmp/mech-buffer-liveness-round56-20261031/linked-primary/after/object.o`, expected SHA-256 `1a8bb46e9f78fec2147b3242fab5651e470f86ba0347f4f11c7f1aedd5008777`.
Metadata reports 13,046,668 code bytes and 108,368 machine entry stack bytes.

This is a static source/Object audit. It contains no new compressor run, timing, allocation measurement, or hardware-instruction measurement. Counts of source sites, spill words, or assembly instructions are not dynamic execution counts. The retained R56 whole-call measurement remains 42,996,202.5 retired instructions; its 161/1,314 exclusive generated-entry sample weights are CPU samples and cannot be multiplied into an instruction ledger.

## 1. Newly identified: two divisions for statically one-dimensional arrays

`program/codegen/numeric_words.rs:164–188` emits row-major addressing for column-major linear indexing as:

```
row = ordinal % rows
column = ordinal / rows
physical = row * columns + column
```

This runs even when the exact validated matrix schema contains a `Constant(1)` row or column dimension. In either case `physical == ordinal`, so the division, remainder, dimension reloads and multiply/add are unnecessary. The original one-based ordinal/bounds check must still happen first.

The retained Object contains this actual site-797 sequence:

```
0x2039c  cbz  x1, failure
0x203a0  udiv x5, x21, x1
0x203a4  msub x13, x5, x1, x21
0x203a8  cbz  x1, failure
0x203ac  udiv x5, x21, x1
0x203b0  mov  w16, #0xa4e8
0x203b4  movk w16, #1, lsl #16
0x203b8  ldr  x14, [sp, x16, sxtx]
0x203bc  madd x5, x13, x14, x5
0x203c0  ldrb w13, [x0, x5]
```

The two divisions have identical dividend/divisor. Cranelift has not combined the separate `urem`/`udiv` operations. This is a distinct opportunity from the review's redundant `at < length`, checked `at + 1`, and second bounds check.

Source site 797 belongs to native read-only header 775. Its actual view witness is source site 790 (`sequence/length`), whose matrix schema is `Matrix(W8, [Constant(1), Parameter(0)])`. `src/engine/src/resident/general/native_collection_word_reads.rs:213–283` validates the current source schema ID, retained schema key, parameter count, canonical value, current account membership and shape before returning the borrowed view. Therefore the code generator can derive unit-dimensional geometry from that exact existing witness. It does not need a new serialized permission bit or an invocation-to-invocation shape cache.

Reconstructible static inventory, counted against the actual entry witness rather than only the eventual access schema:

| Emitted context | Numeric load/store sites | Existing witness has a unit dimension |
|---|---:|---:|
| Read-only numeric loops | 86 | 74 |
| Numeric write loops | 763 | 759 |
| Parent numeric segments | 29 | 29 |
| Total | 878 | 862 |

These are static emitted sites, not visits. The 168 first-change transitions and other dynamic figures elsewhere in the review are different quantities. Do not predict a percentage timing win from 862/878.

Draft production patch: `vector-address/production.patch` (three codegen files). Draft tests: `vector-address/tests.patch` (one emitter test and two original/decoded runtime tests). They were formatted in the scratch directory and were not built by this audit agent. The root agent owns applying, compiling, qualification and measurement. The drafts preserve the general rectangular path exactly and preserve current load bounds, work envelopes and failure routing.

A separate later experiment could compute the general rectangular quotient once and derive `remainder = ordinal - quotient * rows`, removing the second division even for non-vectors. Keep it separate for attribution.

## 2. Narrow next transport experiment: omit the first-change local snapshot

`program/codegen/numeric_boundary.rs:23` invokes `words.spill_all(b, locals)` before every first-change callback. The rest of this function already transports exactly what that callback consumes:

- Lines 24–28 clear the current region's local ready flag before the argument-capacity guard or callback can fail.
- Lines 29–49 write every current scalar carrier field, index and incoming element to the separate argument lane.
- Lines 51–58 pass current compute/comparison fuel as the callback operands.
- Lines 60–88 reload only the newly returned fuel, data pointer, private flag and optional append geometry/capacity from the argument lane.
- Lines 90–93 restore the ready flag after successful callback completion.

`runtime/invocation/numeric_writes.rs:41–45` reads index/incoming from the argument lane and closes the original loan with `end_closed_tail(..., mode=5)`. Its scalar carrier synchronization also reads that lane. The callback uses no original-local-array pointer: `Invocation` retains `arguments`, capacity and result, not native locals. `resume_numeric_after_write` returns current fuel through arguments and restores the same account's partial loan.

Failure handling supports a narrow experiment as well:

- A failing argument-capacity guard encounters ready=0 at generated abort.
- A callback rejection records `context.error`; `runtime/session/mod.rs:1305–1307` returns that exact error before inspecting terminal frame data.
- The generated abort checks the region's ready flag, which is already zero; it does not need the redundant snapshot for that region.
- Other SSA values remain live across the callback under the backend's ordinary call-clobber rules. Those register spills are distinct from copying every source local back into the public local bank.

Proposed bounded change: remove only the `spill_all` at first-change materialization. Keep every explicit ready store, capacity check, argument write, fuel operand, reload, charge and cleanup path. Do not remove all exit spills as part of this experiment. No new general liveness solver or serialized metadata is needed for this first test.

Required acceptance includes originals and decoded artifacts; more than one active SSA scalar and more than one array; a no-op store before the first real change; changed owner/arguments across calls; failure during original clone/admission; late assertion/arithmetic/load rejection after first change; finite-fuel exit with current carrier; unchanged prior publication and aliases; retry and final zero managed ownership. Existing focused tests already cover many of these:

- `runtime/numeric_fuel_tests.rs:125` numeric write fuel exit.
- `runtime/numeric_fuel_tests.rs:135` mixed-result fuel exit.
- `tests/support/canonical_program_numeric_write_recovery.rs:104` late assertion/arithmetic/load failures.
- The same file at lines 195 and 248: exact/one-short fuel and original first-copy admission.

Measure whole-call instructions and timing, plus code/stack changes. The number of removed explicit local writes is not a complete prediction because register allocation can shift.

## 3. Broader opportunity: boundary liveness and the large native frame

`codegen/common/ssa_words.rs:23–37` creates a local-backed SSA home for every selected source/scratch word. `spill_all`, lines 55–60, exports all of those homes. Read-only/write numeric generation invokes it at successful exit, fuel bailout, error, bounds fallback and first-change boundaries.

For header 775, retained metadata reports 31 register words. At a normal successful exit, the existing boundary operations consume:

1. Three state/fuel words.
2. Two scalar fields of the carrier.
3. One returned scalar, value 854, copied to the caller result at the ordinary exit.

That is six boundary values, versus 31 spilled words. The other 25 include internal arithmetic/branch results, geometry and constants. This is a concrete example for a future boundary-specific proof, not a license to reuse the same six-word set at bounds or fuel exits. Bounds fallback additionally needs its exact original scalar operands; append reconciliation needs current length; finite-fuel continuation needs its current live frontier; aggregate/frame results need their actual returned lanes.

Across all 239 emitted numeric loops, the retained source operands prove at least 1,199 constant words are included in spill sets: 161 across 51 read-only regions and 1,038 across 188 write regions. Their total reported register-word counts are 2,425 and 13,973. These are counts per one static exit of each region, not actual per-compression stores. The script intentionally treats the constant number as a lower bound, because it does not infer every aggregate operand.

The architecture already contains the needed pattern: `program/codegen/packed_loop/loop_bounds/mod.rs:215–300` computes continuation liveness, and `packed_loop/steady/mod.rs:423` and `:1256` use `Words::spill_live`. Numeric loops can adopt that vocabulary for each boundary rather than inventing an unrelated transport subsystem. The existing packed-loop proof is map/tag-specific and cannot simply be reused without numeric view/fuel/first-change requirements.

The main Object prologue reserves 108,272 bytes after six 16-byte register-pair saves, matching the 108,368-byte metadata total. Its large frame requires repeated `mov` + `movk` + indexed `ldr/str` sequences for ordinary pointer spills. The column reload at `0x203b0` above is one such example. Numeric loops still emit into the common native function, while existing loop outlining is currently restricted to proved packed-map loops. Reducing boundary live ranges before trying general numeric outlining is a smaller, more attributable next step. Neither metadata size nor static spill count establishes the dynamic gain; use the same matched small timing and instruction cohorts after each isolated change.

## Reconstruction

Run:

```
python3 /private/tmp/mech-astra-audit-20261031/audit-native-instructions.py
```

The script reads retained R56 Object/descriptor/metadata and exact source blobs at the reviewed SHA. It writes source hashes, the complete witness-site inventory, constant-spill lower bounds, header-775 proof/continuation data and bounded Object disassembly to `native-instruction-evidence/`. It never builds a compiler, executes a compressor, samples a process or mutates the repository. Run it outside the primary timing window to keep the host quiet.
