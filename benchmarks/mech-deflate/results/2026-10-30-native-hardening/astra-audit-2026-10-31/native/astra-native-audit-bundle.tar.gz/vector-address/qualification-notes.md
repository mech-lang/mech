# Vector-address candidate qualification handoff

Authoritative draft files are `production.patch` and `tests.patch`, plus formatted full source copies under `hosts/`. The short standalone `numeric_address_tests.rs`, `readonly-test.rs`, and `write-test.rs` files in this directory are initial drafts; do not apply those raw fragments.

## Exact new tests

Under `canonical-native-program`, the GPU unit test is:

```
native_artifact::program::codegen::numeric_words::tests::unit_dimension_addresses_emit_no_division_and_keep_general_geometry
```

Under the same feature, the `canonical_artifact_program` integration binary gains:

```
numeric_tail_qualification::cases::numeric_static_vector_and_rectangular_reads_keep_bounds_aliases_and_retry
numeric_write_qualification::cases::numeric_static_vector_writes_preserve_current_shapes_and_first_change_aliases
```

The two integration cases can be applied and run on parent and candidate. The emitter test calls the candidate's new `linear_address` signature and its module declaration accompanies production, so it cannot run unchanged against the parent. The retained baseline Object disassembly provides direct counterfactual evidence: source797 contains two divisions, with a unit-dimension witness. Do not label a baseline compilation failure of this new-signature test as a semantic regression.

Feature-profile equivalents (root should reuse its frozen direct-rustc dependency graph to avoid rebuilding unrelated dependencies):

```
cargo +nightly-2026-03-03 test --locked --offline -p mech-gpu --no-default-features --features canonical-native-program --test canonical_artifact_program numeric_static_vector -- --nocapture --test-threads=1
cargo +nightly-2026-03-03 test --locked --offline -p mech-gpu --no-default-features --features canonical-native-program --lib unit_dimension_addresses_emit_no_division_and_keep_general_geometry -- --nocapture --test-threads=1
```

The first command must execute exactly two tests; the second exactly one. Run the integration selection on both parent and candidate; run the emitter test on candidate. Existing frozen test executables accept the same trailing filters and `--nocapture --test-threads=1`, omitting Cargo's argument separator.

## CI and retained qualification counts

`.github/workflows/ci-full.yml:674–677` already runs the complete `canonical_artifact_program` integration binary with `canonical-native-program`; both new semantic cases are scheduled automatically. Their `numeric_tail_qualification` and `numeric_write_qualification` prefixes are also already included in the retained component runner, increasing that count from 234 to 236.

The codegen emitter unit test is not matched by the present native-composition list/run filters at lines 714–723. Add `numeric_words::tests` to both selections and change that exact inventory guard from 32 to 33 (current R59 parent). Alternatively schedule a separate exactly-one unit test step. The canonical-native-only `native_artifact::` unit selection does not compile this canonical-native-program-only module, so it is not a substitute.

The retained runtime qualification selects `native_artifact::program::runtime::`; its 327-test inventory does not change. Preparation two, work-values32, connected composition8 and path mechanism1 likewise do not change. The new codegen test is one additional distinct unit test, not a new runtime unit.

## Scope and limits

The test input helper detects a zero-parameter fixed matrix schema and supplies an empty parameter array. It therefore preserves static row, column and rectangular shapes. Independent read/write index oracles preserve column-major source selection into row-major backing. The `(1,0)` read case exercises an empty admitted view, a failing first access and recovery; the empty success executes no modulo/division in the independent oracle.

All widths1/2/4/8 are covered by the generated-IR geometry check. New end-to-end semantic cases use U32, original and decoded artifacts, fixed vectors and a 2×3 rectangle, changed inputs, aliases, successful prefixes, bounds rejection, unchanged previous publication and recovery. Existing broader numeric qualification covers other widths and failure classes.

This audit agent has formatted and reviewed these drafts but has not built, applied or executed them. Root owns compiler validation and measured before/after acceptance.
