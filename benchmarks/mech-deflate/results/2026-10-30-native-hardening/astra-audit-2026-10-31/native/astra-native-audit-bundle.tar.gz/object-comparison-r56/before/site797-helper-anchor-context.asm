; These windows are anchored by mov x1,#797, the source-call argument.
; Inspect actual successful bounds edge and byte load before treating
; them as the precise native source797 load. No addresses are reused
; blindly across Objects. Overlapping windows are intentional.

; Anchor 0x1ed14
   1ea14:      	movk	w16, #0x1, lsl #16
   1ea18:      	ldr	x0, [sp, x16, sxtx]
   1ea1c:      	blr	x7
   1ea20:      	mov	x1, #0x2                ; =2
   1ea24:      	mov	w16, #0x3b20            ; =15136
   1ea28:      	movk	w16, #0x1, lsl #16
   1ea2c:      	str	x1, [sp, x16, sxtx]
   1ea30:      	cmp	x0, #0x0
   1ea34:      	b.ne	0xede18 <_mech_canonical_program_entry_v1+0xede18>
   1ea38:      	mov	w16, #0xa6d0            ; =42704
   1ea3c:      	movk	w16, #0x1, lsl #16
   1ea40:      	ldr	x13, [sp, x16, sxtx]
   1ea44:      	b	0x1ea54 <_mech_canonical_program_entry_v1+0x1ea54>
   1ea48:      	mov	w16, #0xa6d0            ; =42704
   1ea4c:      	movk	w16, #0x1, lsl #16
   1ea50:      	ldr	x13, [sp, x16, sxtx]
   1ea54:      	mov	w16, #0xa6d0            ; =42704
   1ea58:      	movk	w16, #0x1, lsl #16
   1ea5c:      	ldr	x13, [sp, x16, sxtx]
   1ea60:      	ldr	x0, [x13, #0x1af0]
   1ea64:      	ldr	x1, [x13, #0xcf8]
   1ea68:      	cmp	x0, x1
   1ea6c:      	b.eq	0x1eaf0 <_mech_canonical_program_entry_v1+0x1eaf0>
   1ea70:      	mov	x1, #0x320              ; =800
   1ea74:      	ldur	x0, [sp]
   1ea78:      	str	x1, [x0, #0x48]
   1ea7c:      	mov	w0, #0xd870             ; =55408
   1ea80:      	movk	w0, #0x2, lsl #16
   1ea84:      	mov	w16, #0xa6d0            ; =42704
   1ea88:      	movk	w16, #0x1, lsl #16
   1ea8c:      	ldr	x13, [sp, x16, sxtx]
   1ea90:      	ldr	x0, [x13, x0]
   1ea94:      	cmp	x0, #0x0
   1ea98:      	b.ne	0x1ead0 <_mech_canonical_program_entry_v1+0x1ead0>
   1ea9c:      	mov	w16, #0xa6c0            ; =42688
   1eaa0:      	movk	w16, #0x1, lsl #16
   1eaa4:      	ldr	x7, [sp, x16, sxtx]
   1eaa8:      	mov	w16, #0xa6c8            ; =42696
   1eaac:      	movk	w16, #0x1, lsl #16
   1eab0:      	ldr	x0, [sp, x16, sxtx]
   1eab4:      	blr	x7
   1eab8:      	mov	x1, #0x2                ; =2
   1eabc:      	mov	w16, #0x3b20            ; =15136
   1eac0:      	movk	w16, #0x1, lsl #16
   1eac4:      	str	x1, [sp, x16, sxtx]
   1eac8:      	cmp	x0, #0x0
   1eacc:      	b.ne	0xede1c <_mech_canonical_program_entry_v1+0xede1c>
   1ead0:      	ldur	x0, [sp]
   1ead4:      	mov	w16, #0xa558            ; =42328
   1ead8:      	movk	w16, #0x1, lsl #16
   1eadc:      	ldr	x1, [sp, x16, sxtx]
   1eae0:      	mov	w16, #0x3b20            ; =15136
   1eae4:      	movk	w16, #0x1, lsl #16
   1eae8:      	str	x1, [sp, x16, sxtx]
   1eaec:      	b	0xc7043c <_mech_canonical_program_entry_v1+0xc7043c>
   1eaf0:      	mov	x0, #0x321              ; =801
   1eaf4:      	ldur	x1, [sp]
   1eaf8:      	str	x0, [x1, #0x48]
   1eafc:      	mov	w0, #0xd870             ; =55408
   1eb00:      	movk	w0, #0x2, lsl #16
   1eb04:      	mov	w16, #0xa6d0            ; =42704
   1eb08:      	movk	w16, #0x1, lsl #16
   1eb0c:      	ldr	x13, [sp, x16, sxtx]
   1eb10:      	ldr	x0, [x13, x0]
   1eb14:      	cmp	x0, #0x0
   1eb18:      	b.ne	0x1eb54 <_mech_canonical_program_entry_v1+0x1eb54>
   1eb1c:      	mov	x1, #0x321              ; =801
   1eb20:      	mov	w16, #0xa6c0            ; =42688
   1eb24:      	movk	w16, #0x1, lsl #16
   1eb28:      	ldr	x7, [sp, x16, sxtx]
   1eb2c:      	mov	w16, #0xa6c8            ; =42696
   1eb30:      	movk	w16, #0x1, lsl #16
   1eb34:      	ldr	x0, [sp, x16, sxtx]
   1eb38:      	blr	x7
   1eb3c:      	mov	x1, #0x2                ; =2
   1eb40:      	mov	w16, #0x3b20            ; =15136
   1eb44:      	movk	w16, #0x1, lsl #16
   1eb48:      	str	x1, [sp, x16, sxtx]
   1eb4c:      	cmp	x0, #0x0
   1eb50:      	b.ne	0xede20 <_mech_canonical_program_entry_v1+0xede20>
   1eb54:      	mov	x0, #0x322              ; =802
   1eb58:      	ldur	x1, [sp]
   1eb5c:      	str	x0, [x1, #0x48]
   1eb60:      	mov	w0, #0xd870             ; =55408
   1eb64:      	movk	w0, #0x2, lsl #16
   1eb68:      	mov	w16, #0xa6d0            ; =42704
   1eb6c:      	movk	w16, #0x1, lsl #16
   1eb70:      	ldr	x13, [sp, x16, sxtx]
   1eb74:      	ldr	x0, [x13, x0]
   1eb78:      	cmp	x0, #0x0
   1eb7c:      	b.ne	0x1ebc8 <_mech_canonical_program_entry_v1+0x1ebc8>
   1eb80:      	mov	x1, #0x322              ; =802
   1eb84:      	mov	w16, #0xa6c0            ; =42688
   1eb88:      	movk	w16, #0x1, lsl #16
   1eb8c:      	ldr	x7, [sp, x16, sxtx]
   1eb90:      	mov	w16, #0xa6c8            ; =42696
   1eb94:      	movk	w16, #0x1, lsl #16
   1eb98:      	ldr	x0, [sp, x16, sxtx]
   1eb9c:      	blr	x7
   1eba0:      	mov	x6, #0x2                ; =2
   1eba4:      	mov	w16, #0x3b20            ; =15136
   1eba8:      	movk	w16, #0x1, lsl #16
   1ebac:      	str	x6, [sp, x16, sxtx]
   1ebb0:      	cmp	x0, #0x0
   1ebb4:      	b.ne	0xede24 <_mech_canonical_program_entry_v1+0xede24>
   1ebb8:      	mov	w16, #0xa6d0            ; =42704
   1ebbc:      	movk	w16, #0x1, lsl #16
   1ebc0:      	ldr	x13, [sp, x16, sxtx]
   1ebc4:      	b	0x1ebd4 <_mech_canonical_program_entry_v1+0x1ebd4>
   1ebc8:      	mov	w16, #0xa6d0            ; =42704
   1ebcc:      	movk	w16, #0x1, lsl #16
   1ebd0:      	ldr	x13, [sp, x16, sxtx]
   1ebd4:      	mov	w16, #0xa6d0            ; =42704
   1ebd8:      	movk	w16, #0x1, lsl #16
   1ebdc:      	ldr	x13, [sp, x16, sxtx]
   1ebe0:      	ldr	x0, [x13, #0x218]
   1ebe4:      	str	x0, [x13, #0x1af8]
   1ebe8:      	b	0x1ef70 <_mech_canonical_program_entry_v1+0x1ef70>
   1ebec:      	mov	x0, #0x31b              ; =795
   1ebf0:      	ldur	x1, [sp]
   1ebf4:      	str	x0, [x1, #0x48]
   1ebf8:      	mov	w0, #0xd870             ; =55408
   1ebfc:      	movk	w0, #0x2, lsl #16
   1ec00:      	mov	w16, #0xa6d0            ; =42704
   1ec04:      	movk	w16, #0x1, lsl #16
   1ec08:      	ldr	x13, [sp, x16, sxtx]
   1ec0c:      	ldr	x2, [x13, x0]
   1ec10:      	cmp	x2, #0x0
   1ec14:      	b.ne	0x1ec50 <_mech_canonical_program_entry_v1+0x1ec50>
   1ec18:      	mov	x1, #0x31b              ; =795
   1ec1c:      	mov	w16, #0xa6c0            ; =42688
   1ec20:      	movk	w16, #0x1, lsl #16
   1ec24:      	ldr	x7, [sp, x16, sxtx]
   1ec28:      	mov	w16, #0xa6c8            ; =42696
   1ec2c:      	movk	w16, #0x1, lsl #16
   1ec30:      	ldr	x0, [sp, x16, sxtx]
   1ec34:      	blr	x7
   1ec38:      	mov	x1, #0x2                ; =2
   1ec3c:      	mov	w16, #0x3b20            ; =15136
   1ec40:      	movk	w16, #0x1, lsl #16
   1ec44:      	str	x1, [sp, x16, sxtx]
   1ec48:      	cmp	x0, #0x0
   1ec4c:      	b.ne	0xede28 <_mech_canonical_program_entry_v1+0xede28>
   1ec50:      	mov	x1, #0x31c              ; =796
   1ec54:      	ldur	x0, [sp]
   1ec58:      	str	x1, [x0, #0x48]
   1ec5c:      	mov	w8, #0xd870             ; =55408
   1ec60:      	movk	w8, #0x2, lsl #16
   1ec64:      	mov	w16, #0xa6d0            ; =42704
   1ec68:      	movk	w16, #0x1, lsl #16
   1ec6c:      	ldr	x13, [sp, x16, sxtx]
   1ec70:      	ldr	x11, [x13, x8]
   1ec74:      	cmp	x11, #0x0
   1ec78:      	b.ne	0x1ecc0 <_mech_canonical_program_entry_v1+0x1ecc0>
   1ec7c:      	mov	w16, #0xa6c0            ; =42688
   1ec80:      	movk	w16, #0x1, lsl #16
   1ec84:      	ldr	x7, [sp, x16, sxtx]
   1ec88:      	mov	w16, #0xa6c8            ; =42696
   1ec8c:      	movk	w16, #0x1, lsl #16
   1ec90:      	ldr	x0, [sp, x16, sxtx]
   1ec94:      	blr	x7
   1ec98:      	mov	x1, #0x2                ; =2
   1ec9c:      	mov	w16, #0x3b20            ; =15136
   1eca0:      	movk	w16, #0x1, lsl #16
   1eca4:      	str	x1, [sp, x16, sxtx]
   1eca8:      	cmp	x0, #0x0
   1ecac:      	b.ne	0xede2c <_mech_canonical_program_entry_v1+0xede2c>
   1ecb0:      	mov	w16, #0xa6d0            ; =42704
   1ecb4:      	movk	w16, #0x1, lsl #16
   1ecb8:      	ldr	x13, [sp, x16, sxtx]
   1ecbc:      	b	0x1eccc <_mech_canonical_program_entry_v1+0x1eccc>
   1ecc0:      	mov	w16, #0xa6d0            ; =42704
   1ecc4:      	movk	w16, #0x1, lsl #16
   1ecc8:      	ldr	x13, [sp, x16, sxtx]
   1eccc:      	mov	w16, #0xa6d0            ; =42704
   1ecd0:      	movk	w16, #0x1, lsl #16
   1ecd4:      	ldr	x13, [sp, x16, sxtx]
   1ecd8:      	ldr	x0, [x13, #0x1ac0]
   1ecdc:      	ldr	x1, [x13, #0x278]
   1ece0:      	adds	x15, x0, x1
   1ece4:      	cset	x0, hs
   1ece8:      	mov	x1, #0x1                ; =1
   1ecec:      	mov	w16, #0x3b20            ; =15136
   1ecf0:      	movk	w16, #0x1, lsl #16
   1ecf4:      	str	x1, [sp, x16, sxtx]
   1ecf8:      	uxtb	w0, w0
   1ecfc:      	cmp	w0, #0x0
   1ed00:      	b.ne	0xede30 <_mech_canonical_program_entry_v1+0xede30>
   1ed04:      	mov	w16, #0xa6d0            ; =42704
   1ed08:      	movk	w16, #0x1, lsl #16
   1ed0c:      	ldr	x13, [sp, x16, sxtx]
   1ed10:      	str	x15, [x13, #0x1b00]
   1ed14:      	mov	x1, #0x31d              ; =797
   1ed18:      	ldur	x0, [sp]
   1ed1c:      	str	x1, [x0, #0x48]
   1ed20:      	mov	x19, x1
   1ed24:      	mov	w0, #0xd870             ; =55408
   1ed28:      	movk	w0, #0x2, lsl #16
   1ed2c:      	mov	w16, #0xa6d0            ; =42704
   1ed30:      	movk	w16, #0x1, lsl #16
   1ed34:      	ldr	x13, [sp, x16, sxtx]
   1ed38:      	ldr	x0, [x13, x0]
   1ed3c:      	cmp	x0, #0x0
   1ed40:      	b.ne	0x1ed7c <_mech_canonical_program_entry_v1+0x1ed7c>
   1ed44:      	mov	w16, #0xa6c0            ; =42688
   1ed48:      	movk	w16, #0x1, lsl #16
   1ed4c:      	ldr	x7, [sp, x16, sxtx]
   1ed50:      	mov	w16, #0xa6c8            ; =42696
   1ed54:      	movk	w16, #0x1, lsl #16
   1ed58:      	ldr	x0, [sp, x16, sxtx]
   1ed5c:      	mov	x1, x19
   1ed60:      	blr	x7
   1ed64:      	mov	x5, #0x2                ; =2
   1ed68:      	mov	w16, #0x3b20            ; =15136
   1ed6c:      	movk	w16, #0x1, lsl #16
   1ed70:      	str	x5, [sp, x16, sxtx]
   1ed74:      	cmp	x0, #0x0
   1ed78:      	b.ne	0xede34 <_mech_canonical_program_entry_v1+0xede34>
   1ed7c:      	mov	x0, #0x3                ; =3
   1ed80:      	mov	w16, #0x3b20            ; =15136
   1ed84:      	movk	w16, #0x1, lsl #16
   1ed88:      	str	x0, [sp, x16, sxtx]
   1ed8c:      	mov	w16, #0xa6a0            ; =42656
   1ed90:      	movk	w16, #0x1, lsl #16
   1ed94:      	ldr	x0, [sp, x16, sxtx]
   1ed98:      	cmp	x0, #0x2
   1ed9c:      	b.lo	0xede38 <_mech_canonical_program_entry_v1+0xede38>
   1eda0:      	mov	x5, #0x0                ; =0
   1eda4:      	mov	w16, #0xa6a8            ; =42664
   1eda8:      	movk	w16, #0x1, lsl #16
   1edac:      	ldr	x9, [sp, x16, sxtx]
   1edb0:      	str	x5, [x9]
   1edb4:      	mov	w16, #0xa6d0            ; =42704
   1edb8:      	movk	w16, #0x1, lsl #16
   1edbc:      	ldr	x13, [sp, x16, sxtx]
   1edc0:      	ldr	x0, [x13, #0x1b00]
   1edc4:      	str	x0, [x9, #0x8]
   1edc8:      	mov	x0, #0x2                ; =2
   1edcc:      	mov	x1, x19
   1edd0:      	mov	w16, #0xa6b8            ; =42680
   1edd4:      	movk	w16, #0x1, lsl #16
   1edd8:      	ldr	x9, [sp, x16, sxtx]
   1eddc:      	mov	w16, #0x3b20            ; =15136
   1ede0:      	movk	w16, #0x1, lsl #16
   1ede4:      	str	x0, [sp, x16, sxtx]
   1ede8:      	mov	w16, #0xa6c8            ; =42696
   1edec:      	movk	w16, #0x1, lsl #16
   1edf0:      	ldr	x0, [sp, x16, sxtx]
   1edf4:      	mov	w16, #0xa6a8            ; =42664
   1edf8:      	movk	w16, #0x1, lsl #16
   1edfc:      	ldr	x3, [sp, x16, sxtx]
   1ee00:      	mov	w16, #0x3b20            ; =15136
   1ee04:      	movk	w16, #0x1, lsl #16
   1ee08:      	ldr	x4, [sp, x16, sxtx]
   1ee0c:      	mov	w16, #0xa6b0            ; =42672
   1ee10:      	movk	w16, #0x1, lsl #16
   1ee14:      	ldr	x6, [sp, x16, sxtx]
   1ee18:      	mov	x2, x5
   1ee1c:      	blr	x9
   1ee20:      	cmp	x0, #0x0
   1ee24:      	b.ne	0xede3c <_mech_canonical_program_entry_v1+0xede3c>
   1ee28:      	mov	w16, #0xa6b0            ; =42672
   1ee2c:      	movk	w16, #0x1, lsl #16
   1ee30:      	ldr	x6, [sp, x16, sxtx]
   1ee34:      	ldr	x0, [x6]
   1ee38:      	mov	w16, #0xa6d0            ; =42704
   1ee3c:      	movk	w16, #0x1, lsl #16
   1ee40:      	ldr	x13, [sp, x16, sxtx]
   1ee44:      	str	x0, [x13, #0x1b08]
   1ee48:      	mov	x0, #0x31e              ; =798
   1ee4c:      	ldur	x10, [sp]
   1ee50:      	str	x0, [x10, #0x48]
   1ee54:      	mov	w0, #0xd870             ; =55408
   1ee58:      	movk	w0, #0x2, lsl #16
   1ee5c:      	mov	w16, #0xa6d0            ; =42704
   1ee60:      	movk	w16, #0x1, lsl #16
   1ee64:      	ldr	x13, [sp, x16, sxtx]
   1ee68:      	ldr	x0, [x13, x0]
   1ee6c:      	cmp	x0, #0x0
   1ee70:      	b.ne	0x1eebc <_mech_canonical_program_entry_v1+0x1eebc>
   1ee74:      	mov	x1, #0x31e              ; =798
   1ee78:      	mov	w16, #0xa6c0            ; =42688
   1ee7c:      	movk	w16, #0x1, lsl #16
   1ee80:      	ldr	x7, [sp, x16, sxtx]
   1ee84:      	mov	w16, #0xa6c8            ; =42696
   1ee88:      	movk	w16, #0x1, lsl #16
   1ee8c:      	ldr	x0, [sp, x16, sxtx]
   1ee90:      	blr	x7
   1ee94:      	mov	x1, #0x2                ; =2
   1ee98:      	mov	w16, #0x3b20            ; =15136
   1ee9c:      	movk	w16, #0x1, lsl #16
   1eea0:      	str	x1, [sp, x16, sxtx]
   1eea4:      	cmp	x0, #0x0
   1eea8:      	b.ne	0xede40 <_mech_canonical_program_entry_v1+0xede40>
   1eeac:      	mov	w16, #0xa6d0            ; =42704
   1eeb0:      	movk	w16, #0x1, lsl #16
   1eeb4:      	ldr	x13, [sp, x16, sxtx]
   1eeb8:      	b	0x1eec8 <_mech_canonical_program_entry_v1+0x1eec8>
   1eebc:      	mov	w16, #0xa6d0            ; =42704
   1eec0:      	movk	w16, #0x1, lsl #16
   1eec4:      	ldr	x13, [sp, x16, sxtx]
   1eec8:      	mov	w16, #0xa6d0            ; =42704
   1eecc:      	movk	w16, #0x1, lsl #16
   1eed0:      	ldr	x13, [sp, x16, sxtx]
   1eed4:      	ldr	x0, [x13, #0x1b08]
   1eed8:      	str	x0, [x13, #0x1b10]
   1eedc:      	mov	x0, #0x31f              ; =799
   1eee0:      	ldur	x1, [sp]
   1eee4:      	str	x0, [x1, #0x48]
   1eee8:      	mov	w0, #0xd870             ; =55408
   1eeec:      	movk	w0, #0x2, lsl #16
   1eef0:      	mov	w16, #0xa6d0            ; =42704
   1eef4:      	movk	w16, #0x1, lsl #16
   1eef8:      	ldr	x13, [sp, x16, sxtx]
   1eefc:      	ldr	x0, [x13, x0]
   1ef00:      	cmp	x0, #0x0
   1ef04:      	b.ne	0x1ef50 <_mech_canonical_program_entry_v1+0x1ef50>
   1ef08:      	mov	x1, #0x31f              ; =799
   1ef0c:      	mov	w16, #0xa6c0            ; =42688
   1ef10:      	movk	w16, #0x1, lsl #16
   1ef14:      	ldr	x7, [sp, x16, sxtx]
   1ef18:      	mov	w16, #0xa6c8            ; =42696
   1ef1c:      	movk	w16, #0x1, lsl #16
   1ef20:      	ldr	x0, [sp, x16, sxtx]
   1ef24:      	blr	x7
   1ef28:      	mov	x1, #0x2                ; =2
   1ef2c:      	mov	w16, #0x3b20            ; =15136
   1ef30:      	movk	w16, #0x1, lsl #16
   1ef34:      	str	x1, [sp, x16, sxtx]
   1ef38:      	cmp	x0, #0x0
   1ef3c:      	b.ne	0xede44 <_mech_canonical_program_entry_v1+0xede44>
   1ef40:      	mov	w16, #0xa6d0            ; =42704
   1ef44:      	movk	w16, #0x1, lsl #16
   1ef48:      	ldr	x13, [sp, x16, sxtx]
   1ef4c:      	b	0x1ef5c <_mech_canonical_program_entry_v1+0x1ef5c>
   1ef50:      	mov	w16, #0xa6d0            ; =42704
   1ef54:      	movk	w16, #0x1, lsl #16
   1ef58:      	ldr	x13, [sp, x16, sxtx]
   1ef5c:      	mov	w16, #0xa6d0            ; =42704
   1ef60:      	movk	w16, #0x1, lsl #16
   1ef64:      	ldr	x13, [sp, x16, sxtx]
   1ef68:      	ldr	x0, [x13, #0x1b10]
   1ef6c:      	str	x0, [x13, #0x1af8]
   1ef70:      	mov	x0, #0x319              ; =793
   1ef74:      	ldur	x1, [sp]
   1ef78:      	str	x0, [x1, #0x48]
   1ef7c:      	mov	w0, #0xd870             ; =55408
   1ef80:      	movk	w0, #0x2, lsl #16
   1ef84:      	mov	w16, #0xa6d0            ; =42704
   1ef88:      	movk	w16, #0x1, lsl #16
   1ef8c:      	ldr	x13, [sp, x16, sxtx]
   1ef90:      	ldr	x0, [x13, x0]
   1ef94:      	cmp	x0, #0x0
   1ef98:      	b.ne	0x1efd4 <_mech_canonical_program_entry_v1+0x1efd4>
   1ef9c:      	mov	x1, #0x319              ; =793
   1efa0:      	mov	w16, #0xa6c0            ; =42688
   1efa4:      	movk	w16, #0x1, lsl #16
   1efa8:      	ldr	x7, [sp, x16, sxtx]
   1efac:      	mov	w16, #0xa6c8            ; =42696
   1efb0:      	movk	w16, #0x1, lsl #16
   1efb4:      	ldr	x0, [sp, x16, sxtx]
   1efb8:      	blr	x7
   1efbc:      	mov	x14, #0x2               ; =2
   1efc0:      	mov	w16, #0x3b20            ; =15136
   1efc4:      	movk	w16, #0x1, lsl #16
   1efc8:      	str	x14, [sp, x16, sxtx]
   1efcc:      	cmp	x0, #0x0
   1efd0:      	b.ne	0xede48 <_mech_canonical_program_entry_v1+0xede48>
   1efd4:      	mov	x1, #0x323              ; =803
   1efd8:      	ldur	x0, [sp]
   1efdc:      	str	x1, [x0, #0x48]
   1efe0:      	mov	w5, #0xd870             ; =55408
   1efe4:      	movk	w5, #0x2, lsl #16
   1efe8:      	mov	w16, #0xa6d0            ; =42704
   1efec:      	movk	w16, #0x1, lsl #16
   1eff0:      	ldr	x13, [sp, x16, sxtx]
   1eff4:      	ldr	x8, [x13, x5]
   1eff8:      	cmp	x8, #0x0
   1effc:      	b.ne	0x1f044 <_mech_canonical_program_entry_v1+0x1f044>
   1f000:      	mov	w16, #0xa6c0            ; =42688
   1f004:      	movk	w16, #0x1, lsl #16
   1f008:      	ldr	x7, [sp, x16, sxtx]
   1f00c:      	mov	w16, #0xa6c8            ; =42696
   1f010:      	movk	w16, #0x1, lsl #16
   1f014:      	ldr	x0, [sp, x16, sxtx]

; Anchor 0x20284
   1ff84:      	movk	w16, #0x1, lsl #16
   1ff88:      	ldr	x7, [sp, x16, sxtx]
   1ff8c:      	mov	w16, #0xa6c8            ; =42696
   1ff90:      	movk	w16, #0x1, lsl #16
   1ff94:      	ldr	x0, [sp, x16, sxtx]
   1ff98:      	blr	x7
   1ff9c:      	mov	x11, #0x2               ; =2
   1ffa0:      	mov	w16, #0x3b20            ; =15136
   1ffa4:      	movk	w16, #0x1, lsl #16
   1ffa8:      	str	x11, [sp, x16, sxtx]
   1ffac:      	cmp	x0, #0x0
   1ffb0:      	b.ne	0xf046c <_mech_canonical_program_entry_v1+0xf046c>
   1ffb4:      	mov	w16, #0xa6d0            ; =42704
   1ffb8:      	movk	w16, #0x1, lsl #16
   1ffbc:      	ldr	x13, [sp, x16, sxtx]
   1ffc0:      	mov	w16, #0xa6d0            ; =42704
   1ffc4:      	movk	w16, #0x1, lsl #16
   1ffc8:      	ldr	x13, [sp, x16, sxtx]
   1ffcc:      	ldr	x0, [x13, #0x1b48]
   1ffd0:      	str	x0, [x13, #0x1b30]
   1ffd4:      	b	0x200c0 <_mech_canonical_program_entry_v1+0x200c0>
   1ffd8:      	mov	x0, #0x32f              ; =815
   1ffdc:      	ldur	x1, [sp]
   1ffe0:      	str	x0, [x1, #0x48]
   1ffe4:      	mov	w16, #0xa6b0            ; =42672
   1ffe8:      	movk	w16, #0x1, lsl #16
   1ffec:      	ldr	x6, [sp, x16, sxtx]
   1fff0:      	ldr	x0, [x6]
   1fff4:      	cmp	x0, #0x0
   1fff8:      	b.ne	0x20034 <_mech_canonical_program_entry_v1+0x20034>
   1fffc:      	mov	x1, #0x32f              ; =815
   20000:      	mov	w16, #0xa6c0            ; =42688
   20004:      	movk	w16, #0x1, lsl #16
   20008:      	ldr	x7, [sp, x16, sxtx]
   2000c:      	mov	w16, #0xa6c8            ; =42696
   20010:      	movk	w16, #0x1, lsl #16
   20014:      	ldr	x0, [sp, x16, sxtx]
   20018:      	blr	x7
   2001c:      	mov	x1, #0x2                ; =2
   20020:      	mov	w16, #0x3b20            ; =15136
   20024:      	movk	w16, #0x1, lsl #16
   20028:      	str	x1, [sp, x16, sxtx]
   2002c:      	cmp	x0, #0x0
   20030:      	b.ne	0xf04a4 <_mech_canonical_program_entry_v1+0xf04a4>
   20034:      	mov	x0, #0x330              ; =816
   20038:      	ldur	x4, [sp]
   2003c:      	str	x0, [x4, #0x48]
   20040:      	mov	w16, #0xa6b0            ; =42672
   20044:      	movk	w16, #0x1, lsl #16
   20048:      	ldr	x6, [sp, x16, sxtx]
   2004c:      	ldr	x0, [x6]
   20050:      	cmp	x0, #0x0
   20054:      	b.eq	0x20068 <_mech_canonical_program_entry_v1+0x20068>
   20058:      	mov	w16, #0xa6d0            ; =42704
   2005c:      	movk	w16, #0x1, lsl #16
   20060:      	ldr	x13, [sp, x16, sxtx]
   20064:      	b	0x200ac <_mech_canonical_program_entry_v1+0x200ac>
   20068:      	mov	x1, #0x330              ; =816
   2006c:      	mov	w16, #0xa6c0            ; =42688
   20070:      	movk	w16, #0x1, lsl #16
   20074:      	ldr	x7, [sp, x16, sxtx]
   20078:      	mov	w16, #0xa6c8            ; =42696
   2007c:      	movk	w16, #0x1, lsl #16
   20080:      	ldr	x0, [sp, x16, sxtx]
   20084:      	blr	x7
   20088:      	mov	x1, #0x2                ; =2
   2008c:      	mov	w16, #0x3b20            ; =15136
   20090:      	movk	w16, #0x1, lsl #16
   20094:      	str	x1, [sp, x16, sxtx]
   20098:      	cmp	x0, #0x0
   2009c:      	b.ne	0xf0508 <_mech_canonical_program_entry_v1+0xf0508>
   200a0:      	mov	w16, #0xa6d0            ; =42704
   200a4:      	movk	w16, #0x1, lsl #16
   200a8:      	ldr	x13, [sp, x16, sxtx]
   200ac:      	mov	w16, #0xa6d0            ; =42704
   200b0:      	movk	w16, #0x1, lsl #16
   200b4:      	ldr	x13, [sp, x16, sxtx]
   200b8:      	ldr	x5, [x13, #0x2a0]
   200bc:      	str	x5, [x13, #0x1b30]
   200c0:      	mov	x1, #0x32d              ; =813
   200c4:      	ldur	x0, [sp]
   200c8:      	str	x1, [x0, #0x48]
   200cc:      	mov	w16, #0xa6c0            ; =42688
   200d0:      	movk	w16, #0x1, lsl #16
   200d4:      	ldr	x7, [sp, x16, sxtx]
   200d8:      	mov	w16, #0xa6c8            ; =42696
   200dc:      	movk	w16, #0x1, lsl #16
   200e0:      	ldr	x0, [sp, x16, sxtx]
   200e4:      	blr	x7
   200e8:      	mov	x1, #0x2                ; =2
   200ec:      	mov	w16, #0x3b20            ; =15136
   200f0:      	movk	w16, #0x1, lsl #16
   200f4:      	str	x1, [sp, x16, sxtx]
   200f8:      	cmp	x0, #0x0
   200fc:      	b.ne	0xf050c <_mech_canonical_program_entry_v1+0xf050c>
   20100:      	mov	x12, #0x341             ; =833
   20104:      	ldur	x0, [sp]
   20108:      	str	x12, [x0, #0x48]
   2010c:      	mov	w16, #0xa6b0            ; =42672
   20110:      	movk	w16, #0x1, lsl #16
   20114:      	ldr	x6, [sp, x16, sxtx]
   20118:      	ldr	x13, [x6]
   2011c:      	cmp	x13, #0x0
   20120:      	b.eq	0x20134 <_mech_canonical_program_entry_v1+0x20134>
   20124:      	mov	w16, #0xa6d0            ; =42704
   20128:      	movk	w16, #0x1, lsl #16
   2012c:      	ldr	x13, [sp, x16, sxtx]
   20130:      	b	0x20178 <_mech_canonical_program_entry_v1+0x20178>
   20134:      	mov	x1, #0x341              ; =833
   20138:      	mov	w16, #0xa6c0            ; =42688
   2013c:      	movk	w16, #0x1, lsl #16
   20140:      	ldr	x7, [sp, x16, sxtx]
   20144:      	mov	w16, #0xa6c8            ; =42696
   20148:      	movk	w16, #0x1, lsl #16
   2014c:      	ldr	x0, [sp, x16, sxtx]
   20150:      	blr	x7
   20154:      	mov	x6, #0x2                ; =2
   20158:      	mov	w16, #0x3b20            ; =15136
   2015c:      	movk	w16, #0x1, lsl #16
   20160:      	str	x6, [sp, x16, sxtx]
   20164:      	cmp	x0, #0x0
   20168:      	b.ne	0xf0510 <_mech_canonical_program_entry_v1+0xf0510>
   2016c:      	mov	w16, #0xa6d0            ; =42704
   20170:      	movk	w16, #0x1, lsl #16
   20174:      	ldr	x13, [sp, x16, sxtx]
   20178:      	mov	w16, #0xa6d0            ; =42704
   2017c:      	movk	w16, #0x1, lsl #16
   20180:      	ldr	x13, [sp, x16, sxtx]
   20184:      	ldr	x0, [x13, #0x1b30]
   20188:      	str	x0, [x13, #0x1990]
   2018c:      	b	0x205e0 <_mech_canonical_program_entry_v1+0x205e0>
   20190:      	mov	x4, #0x1                ; =1
   20194:      	adds	x4, x9, x4
   20198:      	cset	x5, hs
   2019c:      	uxtb	w5, w5
   201a0:      	cmp	w5, #0x0
   201a4:      	b.ne	0xf0514 <_mech_canonical_program_entry_v1+0xf0514>
   201a8:      	cmp	x9, x2
   201ac:      	cset	x23, lo
   201b0:      	cmp	x9, x2
   201b4:      	b.lo	0x201cc <_mech_canonical_program_entry_v1+0x201cc>
   201b8:      	cmp	x9, x2
   201bc:      	b.lo	0xf0518 <_mech_canonical_program_entry_v1+0xf0518>
   201c0:      	mov	x19, #0x0               ; =0
   201c4:      	mov	x28, x10
   201c8:      	b	0x203d8 <_mech_canonical_program_entry_v1+0x203d8>
   201cc:      	mov	x5, #0x1                ; =1
   201d0:      	adds	x24, x9, x5
   201d4:      	cset	x5, hs
   201d8:      	uxtb	w5, w5
   201dc:      	cmp	w5, #0x0
   201e0:      	b.ne	0xf051c <_mech_canonical_program_entry_v1+0xf051c>
   201e4:      	sub	x21, x24, #0x1
   201e8:      	cmp	x21, x2
   201ec:      	b.lo	0x2039c <_mech_canonical_program_entry_v1+0x2039c>
   201f0:      	b	0x8c75f8 <_mech_canonical_program_entry_v1+0x8c75f8>
   201f4:      	mov	w0, #0xd878             ; =55416
   201f8:      	movk	w0, #0x2, lsl #16
   201fc:      	mov	w16, #0xa6d0            ; =42704
   20200:      	movk	w16, #0x1, lsl #16
   20204:      	ldr	x13, [sp, x16, sxtx]
   20208:      	ldr	x3, [x13, x0]
   2020c:      	mov	w0, #0xd880             ; =55424
   20210:      	movk	w0, #0x2, lsl #16
   20214:      	ldr	x4, [x13, x0]
   20218:      	mov	x0, #0x0                ; =0
   2021c:      	mov	w1, #0xd870             ; =55408
   20220:      	movk	w1, #0x2, lsl #16
   20224:      	str	x0, [x13, x1]
   20228:      	mov	x0, #0x3                ; =3
   2022c:      	mov	w16, #0x3b20            ; =15136
   20230:      	movk	w16, #0x1, lsl #16
   20234:      	str	x0, [sp, x16, sxtx]
   20238:      	mov	w16, #0xa6a0            ; =42656
   2023c:      	movk	w16, #0x1, lsl #16
   20240:      	ldr	x0, [sp, x16, sxtx]
   20244:      	cmp	x0, #0xc
   20248:      	b.lo	0xf0520 <_mech_canonical_program_entry_v1+0xf0520>
   2024c:      	mov	w0, #0xee78             ; =61048
   20250:      	movk	w0, #0x2, lsl #16
   20254:      	mov	w16, #0xa6d0            ; =42704
   20258:      	movk	w16, #0x1, lsl #16
   2025c:      	ldr	x13, [sp, x16, sxtx]
   20260:      	ldr	x0, [x13, x0]
   20264:      	mov	w16, #0xa6a8            ; =42664
   20268:      	movk	w16, #0x1, lsl #16
   2026c:      	ldr	x9, [sp, x16, sxtx]
   20270:      	str	x0, [x9, #0x10]
   20274:      	mov	w0, #0xee80             ; =61056
   20278:      	movk	w0, #0x2, lsl #16
   2027c:      	ldr	x0, [x13, x0]
   20280:      	str	x0, [x9, #0x18]
   20284:      	mov	x1, #0x31d              ; =797
   20288:      	mov	x2, #-0x9               ; =-9
   2028c:      	mov	x0, #0x2                ; =2
   20290:      	mov	w16, #0xa6b8            ; =42680
   20294:      	movk	w16, #0x1, lsl #16
   20298:      	ldr	x9, [sp, x16, sxtx]
   2029c:      	mov	w16, #0x3b20            ; =15136
   202a0:      	movk	w16, #0x1, lsl #16
   202a4:      	str	x0, [sp, x16, sxtx]
   202a8:      	mov	w16, #0xa6c8            ; =42696
   202ac:      	movk	w16, #0x1, lsl #16
   202b0:      	ldr	x0, [sp, x16, sxtx]
   202b4:      	mov	w16, #0x3b20            ; =15136
   202b8:      	movk	w16, #0x1, lsl #16
   202bc:      	ldr	x5, [sp, x16, sxtx]
   202c0:      	mov	w16, #0xa6b0            ; =42672
   202c4:      	movk	w16, #0x1, lsl #16
   202c8:      	ldr	x6, [sp, x16, sxtx]
   202cc:      	blr	x9
   202d0:      	cmp	x0, #0x0
   202d4:      	b.ne	0xf0524 <_mech_canonical_program_entry_v1+0xf0524>
   202d8:      	mov	x0, #0x3                ; =3
   202dc:      	mov	w16, #0x3b20            ; =15136
   202e0:      	movk	w16, #0x1, lsl #16
   202e4:      	str	x0, [sp, x16, sxtx]
   202e8:      	mov	w16, #0xa6a0            ; =42656
   202ec:      	movk	w16, #0x1, lsl #16
   202f0:      	ldr	x0, [sp, x16, sxtx]
   202f4:      	cmp	x0, #0x2
   202f8:      	b.lo	0xf063c <_mech_canonical_program_entry_v1+0xf063c>
   202fc:      	mov	x5, #0x0                ; =0
   20300:      	mov	w16, #0xa6a8            ; =42664
   20304:      	movk	w16, #0x1, lsl #16
   20308:      	ldr	x9, [sp, x16, sxtx]
   2030c:      	str	x5, [x9]
   20310:      	mov	w16, #0xa6d0            ; =42704
   20314:      	movk	w16, #0x1, lsl #16
   20318:      	ldr	x13, [sp, x16, sxtx]
   2031c:      	ldr	x0, [x13, #0x1b00]
   20320:      	str	x0, [x9, #0x8]
   20324:      	mov	x1, #0x31d              ; =797
   20328:      	mov	x0, #0x2                ; =2
   2032c:      	mov	w16, #0xa6b8            ; =42680
   20330:      	movk	w16, #0x1, lsl #16
   20334:      	ldr	x9, [sp, x16, sxtx]
   20338:      	mov	w16, #0x3b20            ; =15136
   2033c:      	movk	w16, #0x1, lsl #16
   20340:      	str	x0, [sp, x16, sxtx]
   20344:      	mov	w16, #0xa6c8            ; =42696
   20348:      	movk	w16, #0x1, lsl #16
   2034c:      	ldr	x0, [sp, x16, sxtx]
   20350:      	mov	w16, #0xa6a8            ; =42664
   20354:      	movk	w16, #0x1, lsl #16
   20358:      	ldr	x3, [sp, x16, sxtx]
   2035c:      	mov	w16, #0x3b20            ; =15136
   20360:      	movk	w16, #0x1, lsl #16
   20364:      	ldr	x4, [sp, x16, sxtx]
   20368:      	mov	w16, #0xa6b0            ; =42672
   2036c:      	movk	w16, #0x1, lsl #16
   20370:      	ldr	x6, [sp, x16, sxtx]
   20374:      	mov	x2, x5
   20378:      	blr	x9
   2037c:      	cmp	x0, #0x0
   20380:      	b.ne	0xf0640 <_mech_canonical_program_entry_v1+0xf0640>
   20384:      	mov	x0, #0x3                ; =3
   20388:      	mov	w16, #0x3b20            ; =15136
   2038c:      	movk	w16, #0x1, lsl #16
   20390:      	str	x0, [sp, x16, sxtx]
   20394:      	ldur	x0, [sp]
   20398:      	b	0xc7043c <_mech_canonical_program_entry_v1+0xc7043c>
   2039c:      	cbz	x1, 0xbdcd4 <_mech_canonical_program_entry_v1+0xbdcd4>
   203a0:      	udiv	x5, x21, x1
   203a4:      	msub	x13, x5, x1, x21
   203a8:      	cbz	x1, 0xbdcd8 <_mech_canonical_program_entry_v1+0xbdcd8>
   203ac:      	udiv	x5, x21, x1
   203b0:      	mov	w16, #0xa4e8            ; =42216
   203b4:      	movk	w16, #0x1, lsl #16
   203b8:      	ldr	x14, [sp, x16, sxtx]
   203bc:      	madd	x5, x13, x14, x5
   203c0:      	ldrb	w13, [x0, x5]
   203c4:      	uxtb	w19, w13
   203c8:      	mov	x13, x19
   203cc:      	mov	x14, x19
   203d0:      	mov	x21, x24
   203d4:      	mov	x28, x10
   203d8:      	adds	x24, x28, x19
   203dc:      	cset	x5, hs
   203e0:      	uxtb	w5, w5
   203e4:      	cmp	w5, #0x0
   203e8:      	b.ne	0xf0644 <_mech_canonical_program_entry_v1+0xf0644>
   203ec:      	mov	x3, #0x6d30             ; =27952
   203f0:      	sub	x11, x11, x3
   203f4:      	uxtb	w26, w26
   203f8:      	uxtb	w23, w23
   203fc:      	str	x24, [sp, #0x330]
   20400:      	str	x24, [sp, #0x328]
   20404:      	str	x4, [sp, #0x320]
   20408:      	mov	x27, x9
   2040c:      	mov	x25, x4
   20410:      	mov	x15, x24
   20414:      	mov	x10, x24
   20418:      	mov	x24, x2
   2041c:      	mov	x9, x4
   20420:      	mov	x7, x4
   20424:      	mov	x5, x0
   20428:      	b	0x1da40 <_mech_canonical_program_entry_v1+0x1da40>
   2042c:      	str	x1, [sp, #0x310]
   20430:      	ldr	x25, [sp, #0x2e8]
   20434:      	ldr	x24, [sp, #0x2f0]
   20438:      	ldr	x14, [sp, #0x2f8]
   2043c:      	mov	w16, #0xa4f0            ; =42224
   20440:      	movk	w16, #0x1, lsl #16
   20444:      	ldr	x13, [sp, x16, sxtx]
   20448:      	ldr	x12, [sp, #0x2c0]
   2044c:      	ldr	x10, [sp, #0x2c8]
   20450:      	mov	x8, x27
   20454:      	ldr	x7, [sp, #0x2d0]
   20458:      	mov	x5, x26
   2045c:      	ldr	x1, [sp, #0x2d8]
   20460:      	ldr	x0, [sp, #0x2e0]
   20464:      	mov	x15, #0x1               ; =1
   20468:      	adds	x26, x23, x15
   2046c:      	cset	x15, hs
   20470:      	uxtb	w15, w15
   20474:      	cmp	w15, #0x0
   20478:      	b.ne	0xf07e0 <_mech_canonical_program_entry_v1+0xf07e0>
   2047c:      	mov	w16, #0xa528            ; =42280
   20480:      	movk	w16, #0x1, lsl #16
   20484:      	ldr	x0, [sp, x16, sxtx]
   20488:      	mov	w16, #0xa508            ; =42248
   2048c:      	movk	w16, #0x1, lsl #16
   20490:      	ldr	x1, [sp, x16, sxtx]
   20494:      	uxtb	w14, w13
   20498:      	uxtb	w2, w2
   2049c:      	str	x26, [sp, #0x2f8]
   204a0:      	str	x28, [sp, #0x2f0]
   204a4:      	str	x22, [sp, #0x2e8]
   204a8:      	str	x26, [sp, #0x2e0]
   204ac:      	str	x28, [sp, #0x2d8]
   204b0:      	str	x22, [sp, #0x2d0]
   204b4:      	str	x26, [sp, #0x2c8]
   204b8:      	str	x9, [sp, #0x2b8]
   204bc:      	mov	w16, #0xa510            ; =42256
   204c0:      	movk	w16, #0x1, lsl #16
   204c4:      	ldr	x27, [sp, x16, sxtx]
   204c8:      	mov	x25, x22
   204cc:      	ldr	x24, [sp, #0x300]
   204d0:      	ldr	x13, [sp, #0x308]
   204d4:      	mov	x10, x8
   204d8:      	mov	x8, x1
   204dc:      	mov	x7, x23
   204e0:      	mov	x23, x26
   204e4:      	mov	x1, x5
   204e8:      	mov	x5, x12
   204ec:      	mov	x12, x0
   204f0:      	mov	x0, x28
   204f4:      	b	0x1a870 <_mech_canonical_program_entry_v1+0x1a870>
   204f8:      	mov	x10, #0x2b8             ; =696
   204fc:      	ldur	x0, [sp]
   20500:      	str	x10, [x0, #0x48]
   20504:      	mov	w16, #0xa6b0            ; =42672
   20508:      	movk	w16, #0x1, lsl #16
   2050c:      	ldr	x6, [sp, x16, sxtx]
   20510:      	ldr	x11, [x6]
   20514:      	cmp	x11, #0x0
   20518:      	b.ne	0x20554 <_mech_canonical_program_entry_v1+0x20554>
   2051c:      	mov	x1, #0x2b8              ; =696
   20520:      	mov	w16, #0xa6c0            ; =42688
   20524:      	movk	w16, #0x1, lsl #16
   20528:      	ldr	x7, [sp, x16, sxtx]
   2052c:      	mov	w16, #0xa6c8            ; =42696
   20530:      	movk	w16, #0x1, lsl #16
   20534:      	ldr	x0, [sp, x16, sxtx]
   20538:      	blr	x7
   2053c:      	mov	x15, #0x2               ; =2
   20540:      	mov	w16, #0x3b20            ; =15136
   20544:      	movk	w16, #0x1, lsl #16
   20548:      	str	x15, [sp, x16, sxtx]
   2054c:      	cmp	x0, #0x0
   20550:      	b.ne	0xf087c <_mech_canonical_program_entry_v1+0xf087c>
   20554:      	mov	x0, #0x2b9              ; =697
   20558:      	ldur	x1, [sp]
   2055c:      	str	x0, [x1, #0x48]
   20560:      	mov	w16, #0xa6b0            ; =42672
   20564:      	movk	w16, #0x1, lsl #16
   20568:      	ldr	x6, [sp, x16, sxtx]
   2056c:      	ldr	x0, [x6]
   20570:      	cmp	x0, #0x0
   20574:      	b.eq	0x20588 <_mech_canonical_program_entry_v1+0x20588>
   20578:      	mov	w16, #0xa6d0            ; =42704
   2057c:      	movk	w16, #0x1, lsl #16
   20580:      	ldr	x13, [sp, x16, sxtx]
   20584:      	b	0x205cc <_mech_canonical_program_entry_v1+0x205cc>

; Anchor 0x20324
   20024:      	movk	w16, #0x1, lsl #16
   20028:      	str	x1, [sp, x16, sxtx]
   2002c:      	cmp	x0, #0x0
   20030:      	b.ne	0xf04a4 <_mech_canonical_program_entry_v1+0xf04a4>
   20034:      	mov	x0, #0x330              ; =816
   20038:      	ldur	x4, [sp]
   2003c:      	str	x0, [x4, #0x48]
   20040:      	mov	w16, #0xa6b0            ; =42672
   20044:      	movk	w16, #0x1, lsl #16
   20048:      	ldr	x6, [sp, x16, sxtx]
   2004c:      	ldr	x0, [x6]
   20050:      	cmp	x0, #0x0
   20054:      	b.eq	0x20068 <_mech_canonical_program_entry_v1+0x20068>
   20058:      	mov	w16, #0xa6d0            ; =42704
   2005c:      	movk	w16, #0x1, lsl #16
   20060:      	ldr	x13, [sp, x16, sxtx]
   20064:      	b	0x200ac <_mech_canonical_program_entry_v1+0x200ac>
   20068:      	mov	x1, #0x330              ; =816
   2006c:      	mov	w16, #0xa6c0            ; =42688
   20070:      	movk	w16, #0x1, lsl #16
   20074:      	ldr	x7, [sp, x16, sxtx]
   20078:      	mov	w16, #0xa6c8            ; =42696
   2007c:      	movk	w16, #0x1, lsl #16
   20080:      	ldr	x0, [sp, x16, sxtx]
   20084:      	blr	x7
   20088:      	mov	x1, #0x2                ; =2
   2008c:      	mov	w16, #0x3b20            ; =15136
   20090:      	movk	w16, #0x1, lsl #16
   20094:      	str	x1, [sp, x16, sxtx]
   20098:      	cmp	x0, #0x0
   2009c:      	b.ne	0xf0508 <_mech_canonical_program_entry_v1+0xf0508>
   200a0:      	mov	w16, #0xa6d0            ; =42704
   200a4:      	movk	w16, #0x1, lsl #16
   200a8:      	ldr	x13, [sp, x16, sxtx]
   200ac:      	mov	w16, #0xa6d0            ; =42704
   200b0:      	movk	w16, #0x1, lsl #16
   200b4:      	ldr	x13, [sp, x16, sxtx]
   200b8:      	ldr	x5, [x13, #0x2a0]
   200bc:      	str	x5, [x13, #0x1b30]
   200c0:      	mov	x1, #0x32d              ; =813
   200c4:      	ldur	x0, [sp]
   200c8:      	str	x1, [x0, #0x48]
   200cc:      	mov	w16, #0xa6c0            ; =42688
   200d0:      	movk	w16, #0x1, lsl #16
   200d4:      	ldr	x7, [sp, x16, sxtx]
   200d8:      	mov	w16, #0xa6c8            ; =42696
   200dc:      	movk	w16, #0x1, lsl #16
   200e0:      	ldr	x0, [sp, x16, sxtx]
   200e4:      	blr	x7
   200e8:      	mov	x1, #0x2                ; =2
   200ec:      	mov	w16, #0x3b20            ; =15136
   200f0:      	movk	w16, #0x1, lsl #16
   200f4:      	str	x1, [sp, x16, sxtx]
   200f8:      	cmp	x0, #0x0
   200fc:      	b.ne	0xf050c <_mech_canonical_program_entry_v1+0xf050c>
   20100:      	mov	x12, #0x341             ; =833
   20104:      	ldur	x0, [sp]
   20108:      	str	x12, [x0, #0x48]
   2010c:      	mov	w16, #0xa6b0            ; =42672
   20110:      	movk	w16, #0x1, lsl #16
   20114:      	ldr	x6, [sp, x16, sxtx]
   20118:      	ldr	x13, [x6]
   2011c:      	cmp	x13, #0x0
   20120:      	b.eq	0x20134 <_mech_canonical_program_entry_v1+0x20134>
   20124:      	mov	w16, #0xa6d0            ; =42704
   20128:      	movk	w16, #0x1, lsl #16
   2012c:      	ldr	x13, [sp, x16, sxtx]
   20130:      	b	0x20178 <_mech_canonical_program_entry_v1+0x20178>
   20134:      	mov	x1, #0x341              ; =833
   20138:      	mov	w16, #0xa6c0            ; =42688
   2013c:      	movk	w16, #0x1, lsl #16
   20140:      	ldr	x7, [sp, x16, sxtx]
   20144:      	mov	w16, #0xa6c8            ; =42696
   20148:      	movk	w16, #0x1, lsl #16
   2014c:      	ldr	x0, [sp, x16, sxtx]
   20150:      	blr	x7
   20154:      	mov	x6, #0x2                ; =2
   20158:      	mov	w16, #0x3b20            ; =15136
   2015c:      	movk	w16, #0x1, lsl #16
   20160:      	str	x6, [sp, x16, sxtx]
   20164:      	cmp	x0, #0x0
   20168:      	b.ne	0xf0510 <_mech_canonical_program_entry_v1+0xf0510>
   2016c:      	mov	w16, #0xa6d0            ; =42704
   20170:      	movk	w16, #0x1, lsl #16
   20174:      	ldr	x13, [sp, x16, sxtx]
   20178:      	mov	w16, #0xa6d0            ; =42704
   2017c:      	movk	w16, #0x1, lsl #16
   20180:      	ldr	x13, [sp, x16, sxtx]
   20184:      	ldr	x0, [x13, #0x1b30]
   20188:      	str	x0, [x13, #0x1990]
   2018c:      	b	0x205e0 <_mech_canonical_program_entry_v1+0x205e0>
   20190:      	mov	x4, #0x1                ; =1
   20194:      	adds	x4, x9, x4
   20198:      	cset	x5, hs
   2019c:      	uxtb	w5, w5
   201a0:      	cmp	w5, #0x0
   201a4:      	b.ne	0xf0514 <_mech_canonical_program_entry_v1+0xf0514>
   201a8:      	cmp	x9, x2
   201ac:      	cset	x23, lo
   201b0:      	cmp	x9, x2
   201b4:      	b.lo	0x201cc <_mech_canonical_program_entry_v1+0x201cc>
   201b8:      	cmp	x9, x2
   201bc:      	b.lo	0xf0518 <_mech_canonical_program_entry_v1+0xf0518>
   201c0:      	mov	x19, #0x0               ; =0
   201c4:      	mov	x28, x10
   201c8:      	b	0x203d8 <_mech_canonical_program_entry_v1+0x203d8>
   201cc:      	mov	x5, #0x1                ; =1
   201d0:      	adds	x24, x9, x5
   201d4:      	cset	x5, hs
   201d8:      	uxtb	w5, w5
   201dc:      	cmp	w5, #0x0
   201e0:      	b.ne	0xf051c <_mech_canonical_program_entry_v1+0xf051c>
   201e4:      	sub	x21, x24, #0x1
   201e8:      	cmp	x21, x2
   201ec:      	b.lo	0x2039c <_mech_canonical_program_entry_v1+0x2039c>
   201f0:      	b	0x8c75f8 <_mech_canonical_program_entry_v1+0x8c75f8>
   201f4:      	mov	w0, #0xd878             ; =55416
   201f8:      	movk	w0, #0x2, lsl #16
   201fc:      	mov	w16, #0xa6d0            ; =42704
   20200:      	movk	w16, #0x1, lsl #16
   20204:      	ldr	x13, [sp, x16, sxtx]
   20208:      	ldr	x3, [x13, x0]
   2020c:      	mov	w0, #0xd880             ; =55424
   20210:      	movk	w0, #0x2, lsl #16
   20214:      	ldr	x4, [x13, x0]
   20218:      	mov	x0, #0x0                ; =0
   2021c:      	mov	w1, #0xd870             ; =55408
   20220:      	movk	w1, #0x2, lsl #16
   20224:      	str	x0, [x13, x1]
   20228:      	mov	x0, #0x3                ; =3
   2022c:      	mov	w16, #0x3b20            ; =15136
   20230:      	movk	w16, #0x1, lsl #16
   20234:      	str	x0, [sp, x16, sxtx]
   20238:      	mov	w16, #0xa6a0            ; =42656
   2023c:      	movk	w16, #0x1, lsl #16
   20240:      	ldr	x0, [sp, x16, sxtx]
   20244:      	cmp	x0, #0xc
   20248:      	b.lo	0xf0520 <_mech_canonical_program_entry_v1+0xf0520>
   2024c:      	mov	w0, #0xee78             ; =61048
   20250:      	movk	w0, #0x2, lsl #16
   20254:      	mov	w16, #0xa6d0            ; =42704
   20258:      	movk	w16, #0x1, lsl #16
   2025c:      	ldr	x13, [sp, x16, sxtx]
   20260:      	ldr	x0, [x13, x0]
   20264:      	mov	w16, #0xa6a8            ; =42664
   20268:      	movk	w16, #0x1, lsl #16
   2026c:      	ldr	x9, [sp, x16, sxtx]
   20270:      	str	x0, [x9, #0x10]
   20274:      	mov	w0, #0xee80             ; =61056
   20278:      	movk	w0, #0x2, lsl #16
   2027c:      	ldr	x0, [x13, x0]
   20280:      	str	x0, [x9, #0x18]
   20284:      	mov	x1, #0x31d              ; =797
   20288:      	mov	x2, #-0x9               ; =-9
   2028c:      	mov	x0, #0x2                ; =2
   20290:      	mov	w16, #0xa6b8            ; =42680
   20294:      	movk	w16, #0x1, lsl #16
   20298:      	ldr	x9, [sp, x16, sxtx]
   2029c:      	mov	w16, #0x3b20            ; =15136
   202a0:      	movk	w16, #0x1, lsl #16
   202a4:      	str	x0, [sp, x16, sxtx]
   202a8:      	mov	w16, #0xa6c8            ; =42696
   202ac:      	movk	w16, #0x1, lsl #16
   202b0:      	ldr	x0, [sp, x16, sxtx]
   202b4:      	mov	w16, #0x3b20            ; =15136
   202b8:      	movk	w16, #0x1, lsl #16
   202bc:      	ldr	x5, [sp, x16, sxtx]
   202c0:      	mov	w16, #0xa6b0            ; =42672
   202c4:      	movk	w16, #0x1, lsl #16
   202c8:      	ldr	x6, [sp, x16, sxtx]
   202cc:      	blr	x9
   202d0:      	cmp	x0, #0x0
   202d4:      	b.ne	0xf0524 <_mech_canonical_program_entry_v1+0xf0524>
   202d8:      	mov	x0, #0x3                ; =3
   202dc:      	mov	w16, #0x3b20            ; =15136
   202e0:      	movk	w16, #0x1, lsl #16
   202e4:      	str	x0, [sp, x16, sxtx]
   202e8:      	mov	w16, #0xa6a0            ; =42656
   202ec:      	movk	w16, #0x1, lsl #16
   202f0:      	ldr	x0, [sp, x16, sxtx]
   202f4:      	cmp	x0, #0x2
   202f8:      	b.lo	0xf063c <_mech_canonical_program_entry_v1+0xf063c>
   202fc:      	mov	x5, #0x0                ; =0
   20300:      	mov	w16, #0xa6a8            ; =42664
   20304:      	movk	w16, #0x1, lsl #16
   20308:      	ldr	x9, [sp, x16, sxtx]
   2030c:      	str	x5, [x9]
   20310:      	mov	w16, #0xa6d0            ; =42704
   20314:      	movk	w16, #0x1, lsl #16
   20318:      	ldr	x13, [sp, x16, sxtx]
   2031c:      	ldr	x0, [x13, #0x1b00]
   20320:      	str	x0, [x9, #0x8]
   20324:      	mov	x1, #0x31d              ; =797
   20328:      	mov	x0, #0x2                ; =2
   2032c:      	mov	w16, #0xa6b8            ; =42680
   20330:      	movk	w16, #0x1, lsl #16
   20334:      	ldr	x9, [sp, x16, sxtx]
   20338:      	mov	w16, #0x3b20            ; =15136
   2033c:      	movk	w16, #0x1, lsl #16
   20340:      	str	x0, [sp, x16, sxtx]
   20344:      	mov	w16, #0xa6c8            ; =42696
   20348:      	movk	w16, #0x1, lsl #16
   2034c:      	ldr	x0, [sp, x16, sxtx]
   20350:      	mov	w16, #0xa6a8            ; =42664
   20354:      	movk	w16, #0x1, lsl #16
   20358:      	ldr	x3, [sp, x16, sxtx]
   2035c:      	mov	w16, #0x3b20            ; =15136
   20360:      	movk	w16, #0x1, lsl #16
   20364:      	ldr	x4, [sp, x16, sxtx]
   20368:      	mov	w16, #0xa6b0            ; =42672
   2036c:      	movk	w16, #0x1, lsl #16
   20370:      	ldr	x6, [sp, x16, sxtx]
   20374:      	mov	x2, x5
   20378:      	blr	x9
   2037c:      	cmp	x0, #0x0
   20380:      	b.ne	0xf0640 <_mech_canonical_program_entry_v1+0xf0640>
   20384:      	mov	x0, #0x3                ; =3
   20388:      	mov	w16, #0x3b20            ; =15136
   2038c:      	movk	w16, #0x1, lsl #16
   20390:      	str	x0, [sp, x16, sxtx]
   20394:      	ldur	x0, [sp]
   20398:      	b	0xc7043c <_mech_canonical_program_entry_v1+0xc7043c>
   2039c:      	cbz	x1, 0xbdcd4 <_mech_canonical_program_entry_v1+0xbdcd4>
   203a0:      	udiv	x5, x21, x1
   203a4:      	msub	x13, x5, x1, x21
   203a8:      	cbz	x1, 0xbdcd8 <_mech_canonical_program_entry_v1+0xbdcd8>
   203ac:      	udiv	x5, x21, x1
   203b0:      	mov	w16, #0xa4e8            ; =42216
   203b4:      	movk	w16, #0x1, lsl #16
   203b8:      	ldr	x14, [sp, x16, sxtx]
   203bc:      	madd	x5, x13, x14, x5
   203c0:      	ldrb	w13, [x0, x5]
   203c4:      	uxtb	w19, w13
   203c8:      	mov	x13, x19
   203cc:      	mov	x14, x19
   203d0:      	mov	x21, x24
   203d4:      	mov	x28, x10
   203d8:      	adds	x24, x28, x19
   203dc:      	cset	x5, hs
   203e0:      	uxtb	w5, w5
   203e4:      	cmp	w5, #0x0
   203e8:      	b.ne	0xf0644 <_mech_canonical_program_entry_v1+0xf0644>
   203ec:      	mov	x3, #0x6d30             ; =27952
   203f0:      	sub	x11, x11, x3
   203f4:      	uxtb	w26, w26
   203f8:      	uxtb	w23, w23
   203fc:      	str	x24, [sp, #0x330]
   20400:      	str	x24, [sp, #0x328]
   20404:      	str	x4, [sp, #0x320]
   20408:      	mov	x27, x9
   2040c:      	mov	x25, x4
   20410:      	mov	x15, x24
   20414:      	mov	x10, x24
   20418:      	mov	x24, x2
   2041c:      	mov	x9, x4
   20420:      	mov	x7, x4
   20424:      	mov	x5, x0
   20428:      	b	0x1da40 <_mech_canonical_program_entry_v1+0x1da40>
   2042c:      	str	x1, [sp, #0x310]
   20430:      	ldr	x25, [sp, #0x2e8]
   20434:      	ldr	x24, [sp, #0x2f0]
   20438:      	ldr	x14, [sp, #0x2f8]
   2043c:      	mov	w16, #0xa4f0            ; =42224
   20440:      	movk	w16, #0x1, lsl #16
   20444:      	ldr	x13, [sp, x16, sxtx]
   20448:      	ldr	x12, [sp, #0x2c0]
   2044c:      	ldr	x10, [sp, #0x2c8]
   20450:      	mov	x8, x27
   20454:      	ldr	x7, [sp, #0x2d0]
   20458:      	mov	x5, x26
   2045c:      	ldr	x1, [sp, #0x2d8]
   20460:      	ldr	x0, [sp, #0x2e0]
   20464:      	mov	x15, #0x1               ; =1
   20468:      	adds	x26, x23, x15
   2046c:      	cset	x15, hs
   20470:      	uxtb	w15, w15
   20474:      	cmp	w15, #0x0
   20478:      	b.ne	0xf07e0 <_mech_canonical_program_entry_v1+0xf07e0>
   2047c:      	mov	w16, #0xa528            ; =42280
   20480:      	movk	w16, #0x1, lsl #16
   20484:      	ldr	x0, [sp, x16, sxtx]
   20488:      	mov	w16, #0xa508            ; =42248
   2048c:      	movk	w16, #0x1, lsl #16
   20490:      	ldr	x1, [sp, x16, sxtx]
   20494:      	uxtb	w14, w13
   20498:      	uxtb	w2, w2
   2049c:      	str	x26, [sp, #0x2f8]
   204a0:      	str	x28, [sp, #0x2f0]
   204a4:      	str	x22, [sp, #0x2e8]
   204a8:      	str	x26, [sp, #0x2e0]
   204ac:      	str	x28, [sp, #0x2d8]
   204b0:      	str	x22, [sp, #0x2d0]
   204b4:      	str	x26, [sp, #0x2c8]
   204b8:      	str	x9, [sp, #0x2b8]
   204bc:      	mov	w16, #0xa510            ; =42256
   204c0:      	movk	w16, #0x1, lsl #16
   204c4:      	ldr	x27, [sp, x16, sxtx]
   204c8:      	mov	x25, x22
   204cc:      	ldr	x24, [sp, #0x300]
   204d0:      	ldr	x13, [sp, #0x308]
   204d4:      	mov	x10, x8
   204d8:      	mov	x8, x1
   204dc:      	mov	x7, x23
   204e0:      	mov	x23, x26
   204e4:      	mov	x1, x5
   204e8:      	mov	x5, x12
   204ec:      	mov	x12, x0
   204f0:      	mov	x0, x28
   204f4:      	b	0x1a870 <_mech_canonical_program_entry_v1+0x1a870>
   204f8:      	mov	x10, #0x2b8             ; =696
   204fc:      	ldur	x0, [sp]
   20500:      	str	x10, [x0, #0x48]
   20504:      	mov	w16, #0xa6b0            ; =42672
   20508:      	movk	w16, #0x1, lsl #16
   2050c:      	ldr	x6, [sp, x16, sxtx]
   20510:      	ldr	x11, [x6]
   20514:      	cmp	x11, #0x0
   20518:      	b.ne	0x20554 <_mech_canonical_program_entry_v1+0x20554>
   2051c:      	mov	x1, #0x2b8              ; =696
   20520:      	mov	w16, #0xa6c0            ; =42688
   20524:      	movk	w16, #0x1, lsl #16
   20528:      	ldr	x7, [sp, x16, sxtx]
   2052c:      	mov	w16, #0xa6c8            ; =42696
   20530:      	movk	w16, #0x1, lsl #16
   20534:      	ldr	x0, [sp, x16, sxtx]
   20538:      	blr	x7
   2053c:      	mov	x15, #0x2               ; =2
   20540:      	mov	w16, #0x3b20            ; =15136
   20544:      	movk	w16, #0x1, lsl #16
   20548:      	str	x15, [sp, x16, sxtx]
   2054c:      	cmp	x0, #0x0
   20550:      	b.ne	0xf087c <_mech_canonical_program_entry_v1+0xf087c>
   20554:      	mov	x0, #0x2b9              ; =697
   20558:      	ldur	x1, [sp]
   2055c:      	str	x0, [x1, #0x48]
   20560:      	mov	w16, #0xa6b0            ; =42672
   20564:      	movk	w16, #0x1, lsl #16
   20568:      	ldr	x6, [sp, x16, sxtx]
   2056c:      	ldr	x0, [x6]
   20570:      	cmp	x0, #0x0
   20574:      	b.eq	0x20588 <_mech_canonical_program_entry_v1+0x20588>
   20578:      	mov	w16, #0xa6d0            ; =42704
   2057c:      	movk	w16, #0x1, lsl #16
   20580:      	ldr	x13, [sp, x16, sxtx]
   20584:      	b	0x205cc <_mech_canonical_program_entry_v1+0x205cc>
   20588:      	mov	x1, #0x2b9              ; =697
   2058c:      	mov	w16, #0xa6c0            ; =42688
   20590:      	movk	w16, #0x1, lsl #16
   20594:      	ldr	x7, [sp, x16, sxtx]
   20598:      	mov	w16, #0xa6c8            ; =42696
   2059c:      	movk	w16, #0x1, lsl #16
   205a0:      	ldr	x0, [sp, x16, sxtx]
   205a4:      	blr	x7
   205a8:      	mov	x1, #0x2                ; =2
   205ac:      	mov	w16, #0x3b20            ; =15136
   205b0:      	movk	w16, #0x1, lsl #16
   205b4:      	str	x1, [sp, x16, sxtx]
   205b8:      	cmp	x0, #0x0
   205bc:      	b.ne	0xf0904 <_mech_canonical_program_entry_v1+0xf0904>
   205c0:      	mov	w16, #0xa6d0            ; =42704
   205c4:      	movk	w16, #0x1, lsl #16
   205c8:      	ldr	x13, [sp, x16, sxtx]
   205cc:      	mov	w16, #0xa6d0            ; =42704
   205d0:      	movk	w16, #0x1, lsl #16
   205d4:      	ldr	x13, [sp, x16, sxtx]
   205d8:      	ldr	x0, [x13, #0x2a0]
   205dc:      	str	x0, [x13, #0x1990]
   205e0:      	mov	x1, #0x2b6              ; =694
   205e4:      	ldur	x0, [sp]
   205e8:      	str	x1, [x0, #0x48]
   205ec:      	mov	w16, #0xa6c0            ; =42688
   205f0:      	movk	w16, #0x1, lsl #16
   205f4:      	ldr	x7, [sp, x16, sxtx]
   205f8:      	mov	w16, #0xa6c8            ; =42696
   205fc:      	movk	w16, #0x1, lsl #16
   20600:      	ldr	x0, [sp, x16, sxtx]
   20604:      	blr	x7
   20608:      	mov	x1, #0x2                ; =2
   2060c:      	mov	w16, #0x3b20            ; =15136
   20610:      	movk	w16, #0x1, lsl #16
   20614:      	str	x1, [sp, x16, sxtx]
   20618:      	cmp	x0, #0x0
   2061c:      	b.ne	0xf0930 <_mech_canonical_program_entry_v1+0xf0930>
   20620:      	mov	x0, #0x342              ; =834
   20624:      	ldur	x14, [sp]

