
/private/tmp/mech-buffer-liveness-round56-20261031/linked-primary/after/object.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_mech_canonical_program_entry_v1>:
   201a0: 710000bf     	cmp	w5, #0x0
   201a4: 54681b81     	b.ne	0xf0514 <_mech_canonical_program_entry_v1+0xf0514>
   201a8: eb02013f     	cmp	x9, x2
   201ac: 9a9f27f7     	cset	x23, lo
   201b0: eb02013f     	cmp	x9, x2
   201b4: 540000c3     	b.lo	0x201cc <_mech_canonical_program_entry_v1+0x201cc>
   201b8: eb02013f     	cmp	x9, x2
   201bc: 54681ae3     	b.lo	0xf0518 <_mech_canonical_program_entry_v1+0xf0518>
   201c0: d2800013     	mov	x19, #0x0               ; =0
   201c4: aa0a03fc     	mov	x28, x10
   201c8: 14000084     	b	0x203d8 <_mech_canonical_program_entry_v1+0x203d8>
   201cc: d2800025     	mov	x5, #0x1                ; =1
   201d0: ab050138     	adds	x24, x9, x5
   201d4: 9a9f37e5     	cset	x5, hs
   201d8: 53001ca5     	uxtb	w5, w5
   201dc: 710000bf     	cmp	w5, #0x0
   201e0: 546819e1     	b.ne	0xf051c <_mech_canonical_program_entry_v1+0xf051c>
   201e4: d1000715     	sub	x21, x24, #0x1
   201e8: eb0202bf     	cmp	x21, x2
   201ec: 54000d83     	b.lo	0x2039c <_mech_canonical_program_entry_v1+0x2039c>
   201f0: 14229d02     	b	0x8c75f8 <_mech_canonical_program_entry_v1+0x8c75f8>
   201f4: 529b0f00     	mov	w0, #0xd878             ; =55416
   201f8: 72a00040     	movk	w0, #0x2, lsl #16
   201fc: 5294da10     	mov	w16, #0xa6d0            ; =42704
   20200: 72a00030     	movk	w16, #0x1, lsl #16
   20204: f870ebed     	ldr	x13, [sp, x16, sxtx]
   20208: f86069a3     	ldr	x3, [x13, x0]
   2020c: 529b1000     	mov	w0, #0xd880             ; =55424
   20210: 72a00040     	movk	w0, #0x2, lsl #16
   20214: f86069a4     	ldr	x4, [x13, x0]
   20218: d2800000     	mov	x0, #0x0                ; =0
   2021c: 529b0e01     	mov	w1, #0xd870             ; =55408
   20220: 72a00041     	movk	w1, #0x2, lsl #16
   20224: f82169a0     	str	x0, [x13, x1]
   20228: d2800060     	mov	x0, #0x3                ; =3
   2022c: 52876410     	mov	w16, #0x3b20            ; =15136
   20230: 72a00030     	movk	w16, #0x1, lsl #16
   20234: f830ebe0     	str	x0, [sp, x16, sxtx]
   20238: 5294d410     	mov	w16, #0xa6a0            ; =42656
   2023c: 72a00030     	movk	w16, #0x1, lsl #16
   20240: f870ebe0     	ldr	x0, [sp, x16, sxtx]
   20244: f100301f     	cmp	x0, #0xc
   20248: 546816c3     	b.lo	0xf0520 <_mech_canonical_program_entry_v1+0xf0520>
   2024c: 529dcf00     	mov	w0, #0xee78             ; =61048
   20250: 72a00040     	movk	w0, #0x2, lsl #16
   20254: 5294da10     	mov	w16, #0xa6d0            ; =42704
   20258: 72a00030     	movk	w16, #0x1, lsl #16
   2025c: f870ebed     	ldr	x13, [sp, x16, sxtx]
   20260: f86069a0     	ldr	x0, [x13, x0]
   20264: 5294d510     	mov	w16, #0xa6a8            ; =42664
   20268: 72a00030     	movk	w16, #0x1, lsl #16
   2026c: f870ebe9     	ldr	x9, [sp, x16, sxtx]
   20270: f9000920     	str	x0, [x9, #0x10]
   20274: 529dd000     	mov	w0, #0xee80             ; =61056
   20278: 72a00040     	movk	w0, #0x2, lsl #16
   2027c: f86069a0     	ldr	x0, [x13, x0]
   20280: f9000d20     	str	x0, [x9, #0x18]
   20284: d28063a1     	mov	x1, #0x31d              ; =797
   20288: 92800102     	mov	x2, #-0x9               ; =-9
   2028c: d2800040     	mov	x0, #0x2                ; =2
   20290: 5294d710     	mov	w16, #0xa6b8            ; =42680
   20294: 72a00030     	movk	w16, #0x1, lsl #16
   20298: f870ebe9     	ldr	x9, [sp, x16, sxtx]
   2029c: 52876410     	mov	w16, #0x3b20            ; =15136
   202a0: 72a00030     	movk	w16, #0x1, lsl #16
   202a4: f830ebe0     	str	x0, [sp, x16, sxtx]
   202a8: 5294d910     	mov	w16, #0xa6c8            ; =42696
   202ac: 72a00030     	movk	w16, #0x1, lsl #16
   202b0: f870ebe0     	ldr	x0, [sp, x16, sxtx]
   202b4: 52876410     	mov	w16, #0x3b20            ; =15136
   202b8: 72a00030     	movk	w16, #0x1, lsl #16
   202bc: f870ebe5     	ldr	x5, [sp, x16, sxtx]
   202c0: 5294d610     	mov	w16, #0xa6b0            ; =42672
   202c4: 72a00030     	movk	w16, #0x1, lsl #16
   202c8: f870ebe6     	ldr	x6, [sp, x16, sxtx]
   202cc: d63f0120     	blr	x9
   202d0: f100001f     	cmp	x0, #0x0
   202d4: 54681281     	b.ne	0xf0524 <_mech_canonical_program_entry_v1+0xf0524>
   202d8: d2800060     	mov	x0, #0x3                ; =3
   202dc: 52876410     	mov	w16, #0x3b20            ; =15136
   202e0: 72a00030     	movk	w16, #0x1, lsl #16
   202e4: f830ebe0     	str	x0, [sp, x16, sxtx]
   202e8: 5294d410     	mov	w16, #0xa6a0            ; =42656
   202ec: 72a00030     	movk	w16, #0x1, lsl #16
   202f0: f870ebe0     	ldr	x0, [sp, x16, sxtx]
   202f4: f100081f     	cmp	x0, #0x2
   202f8: 54681a23     	b.lo	0xf063c <_mech_canonical_program_entry_v1+0xf063c>
   202fc: d2800005     	mov	x5, #0x0                ; =0
   20300: 5294d510     	mov	w16, #0xa6a8            ; =42664
   20304: 72a00030     	movk	w16, #0x1, lsl #16
   20308: f870ebe9     	ldr	x9, [sp, x16, sxtx]
   2030c: f9000125     	str	x5, [x9]
   20310: 5294da10     	mov	w16, #0xa6d0            ; =42704
   20314: 72a00030     	movk	w16, #0x1, lsl #16
   20318: f870ebed     	ldr	x13, [sp, x16, sxtx]
   2031c: f94d81a0     	ldr	x0, [x13, #0x1b00]
   20320: f9000520     	str	x0, [x9, #0x8]
   20324: d28063a1     	mov	x1, #0x31d              ; =797
   20328: d2800040     	mov	x0, #0x2                ; =2
   2032c: 5294d710     	mov	w16, #0xa6b8            ; =42680
   20330: 72a00030     	movk	w16, #0x1, lsl #16
   20334: f870ebe9     	ldr	x9, [sp, x16, sxtx]
   20338: 52876410     	mov	w16, #0x3b20            ; =15136
   2033c: 72a00030     	movk	w16, #0x1, lsl #16
   20340: f830ebe0     	str	x0, [sp, x16, sxtx]
   20344: 5294d910     	mov	w16, #0xa6c8            ; =42696
   20348: 72a00030     	movk	w16, #0x1, lsl #16
   2034c: f870ebe0     	ldr	x0, [sp, x16, sxtx]
   20350: 5294d510     	mov	w16, #0xa6a8            ; =42664
   20354: 72a00030     	movk	w16, #0x1, lsl #16
   20358: f870ebe3     	ldr	x3, [sp, x16, sxtx]
   2035c: 52876410     	mov	w16, #0x3b20            ; =15136
   20360: 72a00030     	movk	w16, #0x1, lsl #16
   20364: f870ebe4     	ldr	x4, [sp, x16, sxtx]
   20368: 5294d610     	mov	w16, #0xa6b0            ; =42672
   2036c: 72a00030     	movk	w16, #0x1, lsl #16
   20370: f870ebe6     	ldr	x6, [sp, x16, sxtx]
   20374: aa0503e2     	mov	x2, x5
   20378: d63f0120     	blr	x9
   2037c: f100001f     	cmp	x0, #0x0
   20380: 54681601     	b.ne	0xf0640 <_mech_canonical_program_entry_v1+0xf0640>
   20384: d2800060     	mov	x0, #0x3                ; =3
   20388: 52876410     	mov	w16, #0x3b20            ; =15136
   2038c: 72a00030     	movk	w16, #0x1, lsl #16
   20390: f830ebe0     	str	x0, [sp, x16, sxtx]
   20394: f84003e0     	ldur	x0, [sp]
   20398: 14314029     	b	0xc7043c <_mech_canonical_program_entry_v1+0xc7043c>
   2039c: b44ec9c1     	cbz	x1, 0xbdcd4 <_mech_canonical_program_entry_v1+0xbdcd4>
   203a0: 9ac10aa5     	udiv	x5, x21, x1
   203a4: 9b01d4ad     	msub	x13, x5, x1, x21
   203a8: b44ec981     	cbz	x1, 0xbdcd8 <_mech_canonical_program_entry_v1+0xbdcd8>
   203ac: 9ac10aa5     	udiv	x5, x21, x1
   203b0: 52949d10     	mov	w16, #0xa4e8            ; =42216
   203b4: 72a00030     	movk	w16, #0x1, lsl #16
   203b8: f870ebee     	ldr	x14, [sp, x16, sxtx]
   203bc: 9b0e15a5     	madd	x5, x13, x14, x5
   203c0: 3865680d     	ldrb	w13, [x0, x5]
   203c4: 53001db3     	uxtb	w19, w13
   203c8: aa1303ed     	mov	x13, x19
   203cc: aa1303ee     	mov	x14, x19
   203d0: aa1803f5     	mov	x21, x24
   203d4: aa0a03fc     	mov	x28, x10
   203d8: ab130398     	adds	x24, x28, x19
   203dc: 9a9f37e5     	cset	x5, hs
   203e0: 53001ca5     	uxtb	w5, w5
   203e4: 710000bf     	cmp	w5, #0x0
   203e8: 546812e1     	b.ne	0xf0644 <_mech_canonical_program_entry_v1+0xf0644>
   203ec: d28da603     	mov	x3, #0x6d30             ; =27952
