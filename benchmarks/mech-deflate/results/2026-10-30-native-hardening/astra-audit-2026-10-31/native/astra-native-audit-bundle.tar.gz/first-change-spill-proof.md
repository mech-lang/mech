# First-change snapshot omission: one-line candidate

Baseline source: `46617b61f3ccf0e4a6ddf27fe37f9f4003016ac4`.
Patch: `first-change-spill.patch`; removes only `words.spill_all(b, locals)?` at `hosts/gpu/src/native_artifact/program/codegen/numeric_boundary.rs:23`. Not applied, built or measured by this audit agent.

## Read/write inventory

The compiler keeps the source region's current values in SSA. Before `NumericWritePrepare`, it currently copies all these words to `locals` and then separately transports the actual callback inputs. The whole-local copy has no identified reader at this boundary.

| Data | Authoritative current location / consumer | Necessary emission retained |
|---|---|---|
| Failure source site | Frame `error_node` / final typed diagnostic | `set_origin`, line22 |
| Region ready flag | Original locals / generated abort and successful continuation | Store0 atlines25–27, store1 atlines90–93 |
| Scalar carrier fields | SSA→arguments→`synchronize_numeric_carrier(mode5)` | Lines29–37 |
| Source index and incoming word | SSA→arguments→`prepare_numeric_write` lines41–42 | Lines39–49 |
| Current finite compute/comparison fuel | SSA→callback arguments→`end_closed_tail(mode5)` | Lines51–58 |
| Current managed owners and private state | `BufferFrames` inside the invocation | Existing callback accesses; no local word owns these values |
| New address/private flag/current fuel | Callback→arguments→SSA | Lines60–88 |
| Appended length/rows/columns/capacity | Callback→arguments→SSA | Optional reloads lines66–72 |
| Other live arithmetic values | SSA values across ordinary native callback | Backend call-clobber preservation; not this explicit local-bank copy |

`Invocation` has an argument pointer, result pointer, current descriptor, frame/arena owners and control state, but no pointer to the generated local array. The helper ABI receives neither that array nor an arbitrary view of it. `prepare_numeric_write`, `end_closed_tail`, `synchronize_numeric_carrier`, and `resume_numeric_after_write` read and write the separate argument lane and retained runtime state.

## Path analysis

**Successful replacement or append.** The existing helper synchronizes scalar carrier arguments and settles the old finite loan, executes the original selected replacement/append with its current validation/copy/consume/admission, wraps the returned exclusive buffer in the private continuation, writes the new address/fuel to arguments, then establishes the partial loan on the same account. All later source reads use SSA; the returned lanes are explicitly refreshed. The eliminated local snapshot is not reloaded on this path.

**Insufficient argument capacity.** The ready flag is stored0 before `require_argument_words`. Its failed guard reaches the common generated abort, whose `tail::leave` checks ready before reading fuel or carrier fields. With ready0, this region's old local snapshot is not read. The same guard, origin, ABI status and terminal outstanding-loan validation remain. This is malformed/private-ABI coverage, not a normal admission decline; do not silently turn it into a source error.

**Runtime argument/callback rejection.** The helper callback first checks result-lane identity and records the exact error on failure. On return, `runtime/session/mod.rs:1305–1307` returns `context.error` before inspecting terminal native-frame fields. Because ready is already0, generated abort cannot attempt a second loan settlement using stale locals. Existing private owners are cleaned up on failed invocation as before.

**Rejected optimization entry or capacity fallback.** `begin_numeric_views` declines before the compiled numeric body and before this materialization boundary; that ordinary route is unchanged. A native append-capacity/header-fuel miss goes through `readonly_numeric.rs`'s existing `bailout` block and its existing full spill, also unchanged. `prepare_numeric_write` itself has no 'decline and continue ordinary' success result: it either finishes the original operation and resumes the native loan or returns an error. A copied versus consumed backing choice happens inside the original selected operation and consumes the same explicit arguments.

**Failed original operation or private continuation admission.** `prepare_numeric_write` invokes `end_closed_tail(mode5)` before the selected operation and before fallible metadata/private-owner construction. All current scalar fields are already in arguments and synchronized. Errors retain their original source, spent prefix, cleanups and publication atomicity. No omitted local word participates in the original operation's arguments or ownership permission.

**Failure before settlement.** Malformed operation/site/private-state checks can reject before `end_closed_tail`. The helper records `context.error`; failed invocation teardown still owns the original private/runtime state. The local ready0 behavior already exists and is unchanged. Removing an unread snapshot does not grant a different recovery path or settle work differently.

**Failed final publication.** This candidate changes only first-change materialization. Numeric successful-exit spilling, `tail::leave(mode0)`, managed freeze/result synchronization and final published-output admission remain unchanged. The parent or caller observes the result only after those existing boundaries. A failure there still preserves the previously published output.

**Resumed ordinary or numeric parent.** The proof for the numeric child excludes callbacks/child regions from its successful interior. Parent execution is suspended while first-change runs, and the helper cannot read its locals. The child resumes using retained SSA, then its existing full normal-exit spill and return boundary provide the result and carrier state. Parent continuation checks, segment frontier transport and child-exit cleanup are unchanged. Shared native scratch lifetimes still rely on the existing runtime state, not on this redundant first-change snapshot.

**Retry.** A rejected invocation does not publish its source locals as outputs. Its temporary owners and current private state are destroyed through the original cleanup. The next admitted invocation initializes its inputs, ready flags, views and arguments again. Existing success→failure→success tests are essential here; stale internal SSA initialization loads must never be treated as externally observable source values.

## Existing acceptance tests to run

Rust GPU unit tests:

- `numeric_fuel_exit_synchronizes_current_carrier_then_cleans_up_and_retries`
- `numeric_write_fuel_exit_freezes_current_cells_without_renewing_admission`
- `numeric_mixed_result_fuel_exit_freezes_current_cells_and_terminal_frame`
- `shared_scratch_refreshes_views_arguments_and_recovers_after_failure`
- `ordinary_scalar_child_keeps_current_boolean_words_errors_and_retry`

`canonical_artifact_program` integration tests (exact suffixes):

- `numeric_writes_late_assertion_arithmetic_load_failures_leave_publication_and_retry`
- `numeric_writes_finite_exact_one_short_failure_then_success`
- `numeric_writes_first_copy_uses_original_clone_admission_and_recovers`
- `numeric_writes_refresh_owners_and_scalars_under_an_ordinary_parent`
- `numeric_writes_distinct_fields_with_actual_aliases_remain_independent`
- `numeric_writes_noop_changes_preserve_the_original_backing`
- `numeric_writes_all_unsigned_widths_rectangular_geometry_and_empty_visits`
- `append_lengths_capacity_exhaustion_current_arguments_aliases_and_recovery`
- `append_finite_denials_preserve_prior_publication_and_retry`

The existing no-op test never transitions to a changed element. Add one small focused witness if these tests do not already establish all of: several current scalar values survive across a first write delayed by no-op visits; two arrays first change at different source sites; current Boolean/aggregate return; and a failed first-change callback followed by retry. A private ABI test should corrupt argument capacity immediately before the selected first-change guard and compare the unchanged rejection/cleanup behavior. Do not report this malformed-capacity coverage as established solely by the source audit.

Also retain owned-image reconstruction, linked execution, exact complete eight-byte output, work60260219686/comparison47612, alias/capacity13/cleanup controls, and matched instructions/cycles/elapsed. The review's168 observed first-change transitions bound how often the specific bridge ran in that retained cohort; they do not by themselves quantify the eliminated instruction total. No performance claim is established until measured.
