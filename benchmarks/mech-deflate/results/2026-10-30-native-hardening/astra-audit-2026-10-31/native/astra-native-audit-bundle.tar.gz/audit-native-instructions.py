#!/usr/bin/env python3
"""Reconstruct static native-geometry/transport evidence; never runs a compressor."""
import argparse, collections, hashlib, json, pathlib, subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--retained', type=pathlib.Path, default=pathlib.Path('/private/tmp/mech-buffer-liveness-round56-20261031'))
parser.add_argument('--repo', type=pathlib.Path, default=pathlib.Path('/private/tmp/mech-deflate-linear-stack'))
parser.add_argument('--out', type=pathlib.Path, default=pathlib.Path('/private/tmp/mech-astra-audit-20261031/native-instruction-evidence'))
args = parser.parse_args()
args.out.mkdir(parents=True, exist_ok=True)
base = args.retained/'linked-primary/after'
metadata = json.loads((base/'metadata.json').read_text())
descriptor = json.loads((base/'descriptor.json').read_text())['descriptor']
plan = descriptor['plan']
source_head = '46617b61f3ccf0e4a6ddf27fe37f9f4003016ac4'

def digest(path):
    return hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()

def geometry(witness):
    dims = plan['blocks'][witness]['action']['LibraryCall']['template']['inputs'][0]['body']['Matrix']['dimensions']
    return dims, len(dims) == 2 and any(d == {'Constant': 1} for d in dims)

accesses = []
for key in ['readonly_numeric_regions', 'numeric_write_regions']:
    for region in metadata[key]:
        proof = region['proof']
        for site, action in proof['actions']:
            if not isinstance(action, dict) or not any(k in action for k in ['Read', 'Write']):
                continue
            kind = next(iter(action))
            array = proof['arrays'][action[kind]['array']]
            dims, unit = geometry(array['witness'])
            accesses.append(dict(context=key, header=region['header'], site=site, kind=kind, witness=array['witness'], dimensions=dims, static_unit_dimension=unit))
segment_views = {}
for parent in metadata['numeric_parent_partitions']['parents']:
    for segment in parent['segments']:
        numeric = segment.get('numeric')
        if numeric:
            for site, action in numeric['actions']:
                if isinstance(action, dict) and 'Read' in action:
                    view = numeric['views'][action['Read']['array']]
                    segment_views[site] = view
for region in metadata['compiled_numeric_segments']:
    for site, width in region['typed_loads']:
        witness = segment_views[site]['witness']
        dims, unit = geometry(witness)
        accesses.append(dict(context='compiled_numeric_segments', header=region['entry'], site=site, kind='Read', witness=witness, dimensions=dims, static_unit_dimension=unit))
summary = {}
for kind in sorted({a['context'] for a in accesses}):
    group = [a for a in accesses if a['context'] == kind]
    summary[kind] = dict(static_access_sites=len(group), static_unit_dimension_sites=sum(a['static_unit_dimension'] for a in group))

# Lower bound only: scalar/ordinary call operands suffice to prove these
# constants occur in source_slots. Do not pretend this counts all aggregate uses.
constants = {c['value'] for c in plan['constants'] if plan['values'][c['value']].get('scalar') is not None}
constant_rows = []
for kind in ['compiled_readonly_numeric_loops', 'compiled_numeric_write_loops']:
    for region in metadata[kind]:
        used = set()
        for site in region['source_sites']:
            action = plan['blocks'][site]['action']
            scalar = action.get('Scalar', {})
            if isinstance(scalar, dict):
                if 'Primitive' in scalar:
                    used.update(scalar['Primitive']['operands'])
                if 'Copy' in scalar:
                    used.add(scalar['Copy']['source'])
            if 'LibraryCall' in action:
                used.update(action['LibraryCall']['operands'])
        constant_rows.append(dict(context=kind, header=region['header'], register_words=region['register_words'], constant_slots_lower_bound=sorted(used & constants)))

excerpt_ranges = {'vector-read797': (0x2039c, 0x203c8), 'main-prologue': (0, 0x34), 'ordinary-high-stack-transport': (0xe0, 0x128)}
for name, (start, stop) in excerpt_ranges.items():
    command = ['xcrun', 'llvm-objdump', '-d', f'--start-address={start}', f'--stop-address={stop}', str(base/'object.o')]
    output = subprocess.run(command, check=True, text=True, capture_output=True)
    (args.out/(name+'.asm')).write_text(output.stdout)
    (args.out/(name+'-command.json')).write_text(json.dumps(command, indent=2)+'\n')

sources = {
    'numeric-address': 'hosts/gpu/src/native_artifact/program/codegen/numeric_words.rs',
    'numeric-leaf': 'hosts/gpu/src/native_artifact/program/codegen/readonly_numeric.rs',
    'numeric-first-change': 'hosts/gpu/src/native_artifact/program/codegen/numeric_boundary.rs',
    'ssa-words': 'hosts/gpu/src/native_artifact/codegen/common/ssa_words.rs',
    'tail-boundaries': 'hosts/gpu/src/native_artifact/program/codegen/tail.rs',
    'runtime-native-view': 'src/engine/src/resident/general/native_collection_word_reads.rs',
    'runtime-numeric-materialization': 'hosts/gpu/src/native_artifact/program/runtime/invocation/numeric_writes.rs',
    'runtime-numeric-synchronization': 'hosts/gpu/src/native_artifact/program/runtime/invocation/readonly_numeric.rs',
    'existing-continuation-liveness': 'hosts/gpu/src/native_artifact/program/codegen/packed_loop/loop_bounds/mod.rs',
    'existing-live-spills': 'hosts/gpu/src/native_artifact/program/codegen/packed_loop/steady/mod.rs',
}
source_receipts = {}
for name, path in sources.items():
    raw = subprocess.check_output(['git', 'show', f'{source_head}:{path}'], cwd=args.repo)
    (args.out/(name+'.rs')).write_bytes(raw)
    source_receipts[name] = dict(path=path, revision=source_head, sha256=hashlib.sha256(raw).hexdigest())

region775 = next(r for r in metadata['readonly_numeric_regions'] if r['header'] == 775)
report = {
    'scope': 'Static retained R56 evidence only. No compiler execution, compression, hardware counter collection, or timing. Static site/store counts are not dynamic counts or elapsed predictions.',
    'revision': source_head,
    'inputs': {name: {'path': str(base/name), 'sha256': digest(base/name)} for name in ['object.o', 'metadata.json', 'descriptor.json']},
    'metadata': {key: metadata[key] for key in ['code_bytes', 'stack_bytes', 'compiled_cfg_cleanup']},
    'geometry_summary': summary,
    'geometry_accesses': accesses,
    'constant_spill_lower_bound': constant_rows,
    'constant_spill_totals': {key: {'regions': sum(r['context']==key for r in constant_rows), 'spill_all_words_per_one_static_exit': sum(r['register_words'] for r in constant_rows if r['context']==key), 'constant_words_lower_bound': sum(len(r['constant_slots_lower_bound']) for r in constant_rows if r['context']==key)} for key in ['compiled_readonly_numeric_loops', 'compiled_numeric_write_loops']},
    'header775': {'proof': region775, 'tail': plan['iterations'][24], 'ordinary_exit': plan['blocks'][810], 'emission': next(r for r in metadata['compiled_readonly_numeric_loops'] if r['header']==775)},
    'source_receipts': source_receipts,
}
(args.out/'audit.json').write_text(json.dumps(report, indent=2, sort_keys=True)+'\n')
print(json.dumps({'output': str(args.out/'audit.json'), 'geometry': summary, 'constant_spills': report['constant_spill_totals']}, indent=2))
