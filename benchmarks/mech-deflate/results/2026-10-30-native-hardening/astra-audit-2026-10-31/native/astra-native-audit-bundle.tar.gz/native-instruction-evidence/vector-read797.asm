
/private/tmp/mech-buffer-liveness-round56-20261031/linked-primary/after/object.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_mech_canonical_program_entry_v1>:
   2039c: b44ec9c1     	cbz	x1, 0xbdcd4 <_mech_canonical_program_entry_v1+0xbdcd4>
   203a0: 9ac10aa5     	udiv	x5, x21, x1
   203a4: 9b01d4ad     	msub	x13, x5, x1, x21
   203a8: b44ec981     	cbz	x1, 0xbdcd8 <_mech_canonical_program_entry_v1+0xbdcd8>
   203ac: 9ac10aa5     	udiv	x5, x21, x1
   203b0: 52949d10     	mov	w16, #0xa4e8            ; =42216
   203b4: 72a00030     	movk	w16, #0x1, lsl #16
   203b8: f870ebee     	ldr	x14, [sp, x16, sxtx]
   203bc: 9b0e15a5     	madd	x5, x13, x14, x5
   203c0: 3865680d     	ldrb	w13, [x0, x5]
   203c4: 53001db3     	uxtb	w19, w13
