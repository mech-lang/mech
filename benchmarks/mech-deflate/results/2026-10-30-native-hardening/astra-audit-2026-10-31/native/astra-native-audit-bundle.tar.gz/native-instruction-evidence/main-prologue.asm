
/private/tmp/mech-buffer-liveness-round56-20261031/linked-primary/after/object.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_mech_canonical_program_entry_v1>:
       0: d503237f     	pacibsp
       4: a9bf7bfd     	stp	x29, x30, [sp, #-0x10]!
       8: 910003fd     	mov	x29, sp
       c: a9bf73fb     	stp	x27, x28, [sp, #-0x10]!
      10: a9bf6bf9     	stp	x25, x26, [sp, #-0x10]!
      14: a9bf63f7     	stp	x23, x24, [sp, #-0x10]!
      18: a9bf5bf5     	stp	x21, x22, [sp, #-0x10]!
      1c: a9bf53f3     	stp	x19, x20, [sp, #-0x10]!
      20: 5294de10     	mov	w16, #0xa6f0            ; =42736
      24: 72a00030     	movk	w16, #0x1, lsl #16
      28: cb3063ff     	sub	sp, sp, x16
      2c: f80003e0     	stur	x0, [sp]
      30: d280006f     	mov	x15, #0x3               ; =3
