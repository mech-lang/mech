
/private/tmp/mech-buffer-liveness-round56-20261031/linked-primary/after/object.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_mech_canonical_program_entry_v1>:
      e0: 5294d910     	mov	w16, #0xa6c8            ; =42696
      e4: 72a00030     	movk	w16, #0x1, lsl #16
      e8: f830ebe3     	str	x3, [sp, x16, sxtx]
      ec: 546b0d40     	b.eq	0xd6294 <_mech_canonical_program_entry_v1+0xd6294>
      f0: d280006f     	mov	x15, #0x3               ; =3
      f4: f100005f     	cmp	x2, #0x0
      f8: 5294d810     	mov	w16, #0xa6c0            ; =42688
      fc: 72a00030     	movk	w16, #0x1, lsl #16
     100: f830ebe2     	str	x2, [sp, x16, sxtx]
     104: 546b0ca0     	b.eq	0xd6298 <_mech_canonical_program_entry_v1+0xd6298>
     108: f84003e0     	ldur	x0, [sp]
     10c: f9402803     	ldr	x3, [x0, #0x50]
     110: f9402c06     	ldr	x6, [x0, #0x58]
     114: f9403002     	ldr	x2, [x0, #0x60]
     118: f9403400     	ldr	x0, [x0, #0x68]
     11c: 5294d410     	mov	w16, #0xa6a0            ; =42656
     120: 72a00030     	movk	w16, #0x1, lsl #16
     124: f830ebe0     	str	x0, [sp, x16, sxtx]
