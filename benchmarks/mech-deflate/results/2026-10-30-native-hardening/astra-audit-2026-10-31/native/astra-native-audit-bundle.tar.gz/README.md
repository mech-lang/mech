# Astra native-instruction audit packet

Audit baseline: reviewed R56 source `46617b61f3ccf0e4a6ddf27fe37f9f4003016ac4`; retained Object SHA-256 `1a8bb46e9f78fec2147b3242fab5651e470f86ba0347f4f11c7f1aedd5008777`. R59's cached-schema-key optimization is handled separately by the parent agent. This packet does not claim R59/R60 performance results.

## Findings and evidence

1. **Proved unit-dimension numeric addressing:** 862 of 878 static numeric access sites have an existing exact entry witness proving one matrix dimension equals1. Nevertheless, the actual baseline ARM64 source797 load emits two identical `udiv` instructions, a remainder `msub`, zero guards and multiply/add address reconstruction. `native-instruction-audit.md` gives source paths and reasoning; `native-instruction-evidence/audit.json` provides every witness and access. `vector-address/production.patch` removes that address reconstruction only when the existing schema proves a unit dimension; the rectangular path and bounds/work/error behavior remain unchanged. `vector-address/tests.patch` supplies one emission test and two original/decoded semantic tests. `vector-address/qualification-notes.md` gives exact selectors and CI inventory updates. Static eligibility is not dynamic frequency or a predicted percentage gain.
2. **One unnecessary first-change local snapshot:** `first-change-spill.patch` removes one `spill_all` before first-change materialization. `first-change-spill-proof.md` inventories callback inputs, ready flags, success/failure/fuel/publication/parent routes and existing focused tests. No observable input to this callback was found in that local snapshot: the maintained ABI passes current scalar carrier, index, incoming word and fuel explicitly. This is a proposed isolated experiment, not a measured or applied change. The separate `first-change-tests/tests.patch` now drafts a delayed-first-change/current-SSA witness with original/decoded artifacts, actual shared aliases, current callback arguments, clone rejection and callback lane-capacity rejection; `first-change-tests/README.md` gives the exact selector and limits. It is not yet built or executed. The generated pre-call capacity guard remains distinct and has no new direct corruption fixture.
3. **Broader boundary liveness / large entry frame:** the baseline machine entry frame is108,368 bytes. Header775 spills31 words at ordinary exit although six boundary words suffice there; that subset is not valid for every exit. At least1,199 source constant words occur among spill sets across239 numeric regions. Existing packed-loop continuation analysis and `spill_live` show an architectural route to narrower boundary snapshots. These counts are static lower bounds, not per-invocation stores. Broad liveness or outlining work is not part of either patch.
4. **Separate future general-matrix reduction:** current `urem` plus `udiv` emits duplicated division even for rectangles. Computing quotient once and deriving remainder by multiply/subtract is a potential next isolated experiment. It is not in the vector patch and has no new test or measured claim here.

## R60 follow-up: a newly measured backend sensitivity

`r60-stack-audit/README.md` is the detailed follow-up investigation brief. The candidate removed1,724 divisions and862 remainder instructions, but generated text grew759,684 bytes. A static stack census attributes most added code to original-locals pointer reloads (+62,620) and argument-lane pointer reloads (+15,732), with other stack reloads decreasing. Exact role mappings, matched source796 assembly and dependency-source hashes are retained. regalloc2's two-split per-use fallback is confirmed code but its responsibility for this specific allocation event remains a hypothesis requiring a filtered register-allocation trace. No threshold was changed. The parent owns R60's separate dynamic measurements and acceptance decision.

## R61 follow-up: first-change snapshot deletion

`r61-stack-audit/README.md` records exact before/after reconciliation. The312 static bridge sites contained28,774 explicit local-bank stores; the Object loses36,000 scalar stores, of which7,226 were machine-stack stores, leaving exactly28,774. All35,017 fewer scalar loads are stack reloads. Text shrinks723,664 bytes and machine stack3,328 bytes, while the vector division removals remain. Locals-pointer reloads decrease15,179 but are still47,441 above R59, so the broader pointer-allocation issue persists. Dynamic timing/counter acceptance belongs to the parent; this agent produced static audits only.

## Reproduction

`audit-native-instructions.py` reconstructs source blobs at the exact baseline commit, input hashes, witness inventory, constant-spill lower bounds and bounded disassembly from retained R56 receipts. Default output is `native-instruction-evidence/`. This ran successfully without compiler or compressor execution.

`compare-native-objects.py` streams actual Object disassembly and records opcode counts (including UDIV/MSUB), generated code/stack values from both metadata and descriptor, all input hashes and source797 helper-argument contexts. It accepts `--before DIR`, optional `--after DIR`, and `--out DIR`; each input directory must hold Object/metadata/descriptor. The output is a static binary audit, not retired instructions. It does not keep a giant assembly dump or run the executable. Candidate addresses are recovered from explicit source-call arguments rather than reusing baseline offsets; the context must still be inspected to identify the exact successful load edge. The known-hash R56 Object also receives a separately verified focused source797 excerpt.

Example for parent-controlled before/after artifacts:

```
python3 compare-native-objects.py --before /path/to/R59/linked-primary/after --after /path/to/R60/linked-primary/after --out /path/to/R60/static-object-audit
```

`object-comparison-r56/` is the baseline-only static opcode receipt. Each receipt stores the exact `llvm-objdump` command and stderr. Dynamic instructions, allocation census, paired elapsed measurements, failure/retry qualification and candidate acceptance remain the parent agent's separate work.

## Handling drafts

No production repository edits, Git mutations, compiler builds, compressor executions or performance runs were performed by this audit agent. The patches remain separate for attribution. Prefer the two `.patch` files under `vector-address/`; short raw source fragments there are initial scratch drafts and are not the authoritative corrected test copies. Source snapshots under `native-instruction-evidence/` are immutable baseline evidence, not replacement production files.
