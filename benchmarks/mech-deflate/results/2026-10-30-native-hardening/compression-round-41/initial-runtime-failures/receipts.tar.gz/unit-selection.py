from pathlib import Path
import json,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'unit-selection';p.mkdir(exist_ok=False)
for label,selection,expected in [('runtime','native_artifact::program::runtime::',315),('work','native_artifact::work::',31)]:
 cmd=[str(r/'green/gpu-unit-tests'),selection,'--nocapture','--test-threads=1'];at=time.monotonic()
 with (p/(label+'.stdout')).open('w') as out,(p/(label+'.stderr')).open('w') as err:q=subprocess.run(cmd,cwd=w,stdout=out,stderr=err)
 (p/(label+'.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'expected_tests':expected},indent=2)+'\n');print(label,q.returncode,(p/(label+'.stdout')).read_text()[-1500:],flush=True);q.check_returncode();assert ('test result: ok. '+str(expected)+' passed; 0 failed;') in (p/(label+'.stdout')).read_text()
 subprocess.run(['python3',str(r/'archive.py'),'unit-'+label,str(p/(label+'.stdout')),str(p/(label+'.stderr')),str(p/(label+'.json')),str(r/'unit-selection.py')],cwd=w,check=True)
