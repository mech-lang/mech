unsafe extern "C" { #[link_name="mech_canonical_program_identity_v1_cb573847662071ace79d778c86925dbfea4281d310876de54dbc585634fc9592"] static LINKED_IDENTITY:[u8;mech_gpu::native_artifact::NATIVE_PROGRAM_LINK_IDENTITY_BYTES]; #[link_name="mech_canonical_program_entry_v1"] fn linked_entry(frame:*mut std::ffi::c_void)->u64; }
use mech_core::{ManagedMemoryBudget,Value,ValueDataDraft as Data,snapshot::{SnapshotValidationContext,ValueDraft}};
use mech_engine::{CanonicalSourceFrontend,ProgramArtifact};
use mech_gpu::native_artifact::NativeProgramLimitMode;
use mech_syntax::document::{AstNode,DocumentId,DocumentSyntax,ParseConfig,Revision,TextSnapshot,parse_canonical_document};
use std::sync::Arc;
fn source(text: &str) -> ProgramArtifact {
 let parsed = parse_canonical_document(TextSnapshot::new(DocumentId(71), Revision(1), text).unwrap(), ParseConfig::default());
 assert!(parsed.is_strictly_clean());
 CanonicalSourceFrontend.compile_document_with_catalog(&DocumentSyntax::cast(parsed.syntax()).unwrap(), mech_stdlib::source_catalog()).unwrap().compile_artifact().unwrap()
}
fn import(artifact: &ProgramArtifact, input: &[(String, Data)], memory: &ManagedMemoryBudget) -> Vec<Value> {
 let schemas=Arc::new(artifact.schemas().clone());
 artifact.inputs().iter().map(|port| {
  let name=mech_engine::decode_source_input_name(&port.name).unwrap();
  let data=input.iter().find(|(n,_)| *n==name).unwrap().1.clone();
  let shape_values: Box<[u64]>=if let Data::Matrix(values)=&data {mech_core::shape_for_resolved_extents(schemas.get(port.schema).unwrap(), &[1,values.len() as u64]).unwrap().parameter_values().into()} else {Box::new([])};
  let v=ValueDraft{schema:port.schema,shape_values,data}.finalize(&SnapshotValidationContext::with_shared_schemas(&schemas)).unwrap();
  let mut admission=memory.reserve_capacity(v.memory_budget_admission_bytes(memory).unwrap()).unwrap();v.into_memory_budget(&mut admission).unwrap()
 }).collect()
}

fn main(){
 let original=source(include_str!("/private/tmp/mech-projection-round41-20261030/linked-acceptance/source.mec"));
 let decoded=mech_engine::decode_program_artifact_bytecode_v1(&mech_engine::encode_program_artifact_bytecode_v1(&original).unwrap()).unwrap();
 let mode=NativeProgramLimitMode::NoLimits;let catalog=mech_stdlib::source_catalog();
 // SAFETY: the script pins the exact same-build Object/image, linked identity and live entry.
 let linked=unsafe{mech_gpu::native_artifact::LinkedProgramArtifact::from_build_owned_image(include_bytes!("/private/tmp/mech-projection-round41-20261030/linked-acceptance/descriptor.json"),&catalog,&LINKED_IDENTITY,linked_entry)}.unwrap();
 let mut executions=0;
 for artifact in [original,decoded]{
  let memory=mode.memory_budget();let mut published=vec![None;artifact.outputs().len()];
  for (word,left,flag,allowed,divisor,empty,error) in [(3u8,2u64,true,true,1u64,false,None),(9,3,false,true,2,false,None),(3,2,true,false,0,true,Some("Integrity")),(3,2,false,true,1,true,Some("Library")),(3,2,true,true,0,false,Some("Arithmetic")),(11,0,false,true,3,false,None)]{
   let args=import(&artifact,&[("a".into(),Data::Matrix(if empty{vec![]}else{vec![Data::U8(word)]}.into())),("b".into(),Data::Matrix(vec![Data::U16(17)].into())),("c".into(),Data::Matrix(vec![Data::U32(23)].into())),("d".into(),Data::Matrix(vec![Data::U64(29)].into())),("left".into(),Data::U64(left)),("number".into(),Data::U64(2)),("flag".into(),Data::Bool(flag)),("steps".into(),Data::U64(2)),("allowed".into(),Data::Bool(allowed)),("divisor".into(),Data::U64(divisor))],&memory);
   let aliases=args.clone();let before=args.iter().map(|v|v.canonical_data_draft().unwrap()).collect::<Vec<_>>();let prior=published.clone();let retained=(memory.used_bytes(),memory.retained_snapshot_nodes());
   let result=linked.evaluate_into(&args,&mut published,mode.execution(),&memory);
   if let Some(error)=error{let receipt=format!("{:?}",result.unwrap_err());assert!(receipt.contains(error),"{receipt}");assert!(published.iter().zip(&prior).all(|(a,b)|a.as_ref().unwrap().shares_frozen_storage(b.as_ref().unwrap())));assert_eq!((memory.used_bytes(),memory.retained_snapshot_nodes()),retained);}
   else{result.unwrap();let sum=u64::from(word)+17*10+23*100+29*1000;let expected=(2+(left+1)*(sum+2)+u64::from(flag^(left%2!=0)))/divisor;assert_eq!(published[0].as_ref().unwrap().canonical_data_draft().unwrap(),Data::U64(expected));}
   assert_eq!(args.iter().map(|v|v.canonical_data_draft().unwrap()).collect::<Vec<_>>(),before);assert!(args.iter().zip(&aliases).all(|(a,b)|a.shares_frozen_storage(b)));executions+=1;
  }
  drop(published);assert_eq!((memory.used_bytes(),memory.retained_snapshot_nodes()),(0,0));
 }
 println!("{}",serde_json::json!({"qualification":"linked managed projection ordered errors aliases and recovery","executions":executions,"artifact_forms":2,"exact_results":true,"zero_cleanup":true}));
}
