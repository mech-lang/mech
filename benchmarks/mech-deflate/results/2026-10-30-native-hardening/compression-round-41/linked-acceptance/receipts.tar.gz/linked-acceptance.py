from pathlib import Path
import hashlib,json,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'linked-acceptance';p.mkdir()
base=json.loads((r/'linked-primary/after/worker-build.json').read_text());worker=(r/'linked-primary/after/worker.rs').read_text()
source_fn=worker[worker.index('fn source('):worker.index('fn words(')]
import_fn=worker[worker.index('fn import('):worker.index('fn rebind(')]
imports='''use mech_core::{ManagedMemoryBudget,Value,ValueDataDraft as Data,snapshot::{SnapshotValidationContext,ValueDraft}};
use mech_engine::{CanonicalSourceFrontend,ProgramArtifact};
use mech_gpu::native_artifact::NativeProgramLimitMode;
use mech_syntax::document::{AstNode,DocumentId,DocumentSyntax,ParseConfig,Revision,TextSnapshot,parse_canonical_document};
use std::sync::Arc;
'''
fixture=w/'hosts/gpu/tests/fixtures/native/frame-projection-batch.mec';(p/'source.mec').write_bytes(fixture.read_bytes())
def run(label,cmd):
 at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True);(p/(label+'.stdout')).write_text(q.stdout);(p/(label+'.stderr')).write_text(q.stderr);(p/(label+'.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'compiler_source':base['compiler_source'],'libraries':base['libraries']},indent=2)+'\n')
 if q.returncode:print(q.stdout[-2500:]+q.stderr[-5000:],flush=True)
 q.check_returncode();print(label,'COMPLETE',flush=True)
cmd_base=base['command'].copy();at=cmd_base.index('-C',cmd_base.index('--extern')) if False else None
# Remove only the full-compressor Object argument; every other dependency and flag remains pinned.
i=cmd_base.index('link-arg='+str(r/'linked-primary/after/object.o'));assert cmd_base[i-1]=='-C';del cmd_base[i-1:i+1]
source='''use mech_engine::CanonicalSourceFrontend;use mech_engine::ProgramArtifact;
use mech_gpu::native_artifact::{NativeProgramLimitMode,emit_program_object_with_limits};
use mech_syntax::document::{AstNode,DocumentId,DocumentSyntax,ParseConfig,Revision,TextSnapshot,parse_canonical_document};
'''+source_fn+'''fn main(){let artifact=source(include_str!("'''+str(p/'source.mec')+'''"));let object=emit_program_object_with_limits(&artifact,&mech_stdlib::source_catalog(),NativeProgramLimitMode::NoLimits.compilation()).unwrap();let p=std::path::Path::new("'''+str(p)+'''");std::fs::write(p.join("object.o"),object.bytes()).unwrap();std::fs::write(p.join("descriptor.json"),object.descriptor().encode_build_owned_image().unwrap()).unwrap();std::fs::write(p.join("metadata.json"),serde_json::to_vec_pretty(&object.metadata()).unwrap()).unwrap();}'''
(p/'emit.rs').write_text(source);cmd=cmd_base.copy();cmd[-3]=str(p/'emit.rs');cmd[-1]=str(p/'emit');run('emit-build',cmd);run('emit',[str(p/'emit')])
meta=json.loads((p/'metadata.json').read_text());identity=meta['identity_symbol'];entry=meta['entry_symbol']
prefix='unsafe extern "C" { #[link_name="'+identity+'"] static LINKED_IDENTITY:[u8;mech_gpu::native_artifact::NATIVE_PROGRAM_LINK_IDENTITY_BYTES]; #[link_name="'+entry+'"] fn linked_entry(frame:*mut std::ffi::c_void)->u64; }\n'
body='''
fn main(){
 let original=source(include_str!("SOURCE_PATH"));
 let decoded=mech_engine::decode_program_artifact_bytecode_v1(&mech_engine::encode_program_artifact_bytecode_v1(&original).unwrap()).unwrap();
 let mode=NativeProgramLimitMode::NoLimits;let catalog=mech_stdlib::source_catalog();
 // SAFETY: the script pins the exact same-build Object/image, linked identity and live entry.
 let linked=unsafe{mech_gpu::native_artifact::LinkedProgramArtifact::from_build_owned_image(include_bytes!("IMAGE_PATH"),&catalog,&LINKED_IDENTITY,linked_entry)}.unwrap();
 let mut executions=0;
 for artifact in [original,decoded]{
  let memory=mode.memory_budget();let mut published=vec![None;artifact.outputs().len()];
  for (word,left,flag,allowed,divisor,empty,error) in [(3u8,2u64,true,true,1u64,false,None),(9,3,false,true,2,false,None),(3,2,true,false,0,true,Some("Integrity")),(3,2,false,true,1,true,Some("Library")),(3,2,true,true,0,false,Some("Arithmetic")),(11,0,false,true,3,false,None)]{
   let args=import(&artifact,&[("a".into(),Data::Matrix(if empty{vec![]}else{vec![Data::U8(word)]}.into())),("b".into(),Data::Matrix(vec![Data::U16(17)].into())),("c".into(),Data::Matrix(vec![Data::U32(23)].into())),("d".into(),Data::Matrix(vec![Data::U64(29)].into())),("left".into(),Data::U64(left)),("number".into(),Data::U64(2)),("flag".into(),Data::Bool(flag)),("steps".into(),Data::U64(2)),("allowed".into(),Data::Bool(allowed)),("divisor".into(),Data::U64(divisor))],&memory);
   let aliases=args.clone();let before=args.iter().map(|v|v.canonical_data_draft().unwrap()).collect::<Vec<_>>();let prior=published.clone();let retained=(memory.used_bytes(),memory.retained_snapshot_nodes());
   let result=linked.evaluate_into(&args,&mut published,mode.execution(),&memory);
   if let Some(error)=error{let receipt=format!("{:?}",result.unwrap_err());assert!(receipt.contains(error),"{receipt}");assert!(published.iter().zip(&prior).all(|(a,b)|a.as_ref().unwrap().shares_frozen_storage(b.as_ref().unwrap())));assert_eq!((memory.used_bytes(),memory.retained_snapshot_nodes()),retained);}
   else{result.unwrap();let sum=u64::from(word)+17*10+23*100+29*1000;let expected=(2+(left+1)*(sum+2)+u64::from(flag^(left%2!=0)))/divisor;assert_eq!(published[0].as_ref().unwrap().canonical_data_draft().unwrap(),Data::U64(expected));}
   assert_eq!(args.iter().map(|v|v.canonical_data_draft().unwrap()).collect::<Vec<_>>(),before);assert!(args.iter().zip(&aliases).all(|(a,b)|a.shares_frozen_storage(b)));executions+=1;
  }
  drop(published);assert_eq!((memory.used_bytes(),memory.retained_snapshot_nodes()),(0,0));
 }
 println!("{}",serde_json::json!({"qualification":"linked managed projection ordered errors aliases and recovery","executions":executions,"artifact_forms":2,"exact_results":true,"zero_cleanup":true}));
}
'''.replace('SOURCE_PATH',str(p/'source.mec')).replace('IMAGE_PATH',str(p/'descriptor.json'))
(p/'worker.rs').write_text(prefix+imports+source_fn+import_fn+body);cmd=cmd_base.copy();cmd[-3]=str(p/'worker.rs');cmd[-1]=str(p/'worker');cmd[-3:-3]=['-C','link-arg='+str(p/'object.o')];run('worker-build',cmd);run('run',[str(p/'worker')]);assert json.loads((p/'run.stdout').read_text())['executions']==12
(p/'pins.json').write_text(json.dumps({name:hashlib.sha256((p/name).read_bytes()).hexdigest() for name in ['source.mec','object.o','descriptor.json','metadata.json','worker']},indent=2)+'\n')
files=[f for f in p.iterdir() if f.is_file() and f.name not in {'emit','worker','object.o','descriptor.json'}]
subprocess.run(['python3',str(r/'archive.py'),'linked-acceptance',*map(str,files),str(r/'linked-acceptance.py')],cwd=w,check=True)
