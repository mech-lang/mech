
/private/tmp/mech-projection-round41-20261030/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001015e0c5c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action>:
1015e0c5c:     	stp	x28, x27, [sp, #-0x60]!
1015e0c60:     	stp	x26, x25, [sp, #0x10]
1015e0c64:     	stp	x24, x23, [sp, #0x20]
1015e0c68:     	stp	x22, x21, [sp, #0x30]
1015e0c6c:     	stp	x20, x19, [sp, #0x40]
1015e0c70:     	stp	x29, x30, [sp, #0x50]
1015e0c74:     	add	x29, sp, #0x50
1015e0c78:     	sub	sp, sp, #0x4c0
1015e0c7c:     	str	xzr, [sp]
1015e0c80:     	ldr	x27, [x1, #0x498]
1015e0c84:     	ldr	x8, [x27, #0x498]
1015e0c88:     	cmp	x2, x8
1015e0c8c:     	b.hs	0x1015e0d58 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xfc>
1015e0c90:     	mov	x22, x5
1015e0c94:     	mov	x23, x4
1015e0c98:     	mov	x20, x2
1015e0c9c:     	mov	x21, x1
1015e0ca0:     	add	x26, sp, #0x400
1015e0ca4:     	ldr	x8, [x27, #0x490]
1015e0ca8:     	mov	w9, #0x28               ; =40
1015e0cac:     	madd	x24, x2, x9, x8
1015e0cb0:     	ldr	w8, [x24]
1015e0cb4:     	cmp	w8, #0x1
1015e0cb8:     	b.gt	0x1015e0d3c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xe0>
1015e0cbc:     	cbnz	w8, 0x1015e0d6c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x110>
1015e0cc0:     	cbnz	x3, 0x1015e0fac <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x350>
1015e0cc4:     	ldr	x1, [x27, #0x378]
1015e0cc8:     	cmp	x20, x1
1015e0ccc:     	b.hs	0x1015e1f9c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1340>
1015e0cd0:     	ldr	x8, [x27, #0x370]
1015e0cd4:     	mov	w9, #0x170              ; =368
1015e0cd8:     	madd	x8, x20, x9, x8
1015e0cdc:     	ldp	x10, x9, [x8]
1015e0ce0:     	cmp	x10, #0x2
1015e0ce4:     	sbcs	xzr, x9, xzr
1015e0ce8:     	b.hs	0x1015e1184 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x528>
1015e0cec:     	ldr	w9, [x8, #0x130]
1015e0cf0:     	ldr	w10, [x24, #0x4]
1015e0cf4:     	cmp	w9, w10
1015e0cf8:     	b.ne	0x1015e11a0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x544>
1015e0cfc:     	ldr	x9, [x8, #0x128]
1015e0d00:     	cmp	x22, x9
1015e0d04:     	b.ne	0x1015e11a0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x544>
1015e0d08:     	stp	x24, x0, [sp, #0x38]
1015e0d0c:     	add	x9, x27, #0x480
1015e0d10:     	ldr	x8, [x8, #0x120]
1015e0d14:     	str	x8, [sp, #0x30]
1015e0d18:     	lsl	x8, x22, #2
1015e0d1c:     	stp	x8, x9, [sp, #0x18]
1015e0d20:     	cbz	x22, 0x1015e1340 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6e4>
1015e0d24:     	mov	x26, #0x0               ; =0
1015e0d28:     	mov	x25, #0x0               ; =0
1015e0d2c:     	ldr	x24, [x21, #0x490]
1015e0d30:     	ldr	x19, [sp, #0x18]
1015e0d34:     	str	x24, [sp, #0x28]
1015e0d38:     	b	0x1015e0df0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x194>
1015e0d3c:     	cmp	w8, #0x2
1015e0d40:     	b.ne	0x1015e0d58 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xfc>
1015e0d44:     	cbz	x3, 0x1015e0f98 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x33c>
1015e0d48:     	cmp	x3, #0x12
1015e0d4c:     	b.ne	0x1015e0fac <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x350>
1015e0d50:     	cbnz	x22, 0x1015e0fac <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x350>
1015e0d54:     	b	0x1015e1008 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x3ac>
1015e0d58:     	mov	w8, #0x2                ; =2
1015e0d5c:     	str	x8, [x0, #0x8]
1015e0d60:     	mov	w8, #0x6                ; =6
1015e0d64:     	str	w8, [x0]
1015e0d68:     	b	0x1015e0fc8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
1015e0d6c:     	cmp	x3, #0x1
1015e0d70:     	b.ne	0x1015e0fac <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x350>
1015e0d74:     	cbnz	x22, 0x1015e0fac <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x350>
1015e0d78:     	mov	x19, x0
1015e0d7c:     	add	x0, sp, #0x400
1015e0d80:     	mov	x1, x21
1015e0d84:     	mov	x2, x20
1015e0d88:     	bl	0x1015f400c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation10needs_move>
1015e0d8c:     	ldr	w8, [sp, #0x400]
1015e0d90:     	cmp	w8, #0x1
1015e0d94:     	b.ne	0x1015e0fe8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x38c>
1015e0d98:     	ldr	w3, [sp, #0x404]
1015e0d9c:     	ldr	w4, [sp, #0x408]
1015e0da0:     	ldp	w8, w9, [x24, #0x4]
1015e0da4:     	cmp	w3, w8
1015e0da8:     	ccmp	w4, w9, #0x0, eq
1015e0dac:     	b.eq	0x1015e11bc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x560>
1015e0db0:     	str	wzr, [x19]
1015e0db4:     	mov	w8, #0xc                ; =12
1015e0db8:     	strb	w8, [x19, #0x8]
1015e0dbc:     	adrp	x8, 0x10774f000 <_anon.9fbf84db36233a693e1db665f769ea71.111+0x137b>
1015e0dc0:     	add	x8, x8, #0x97b
1015e0dc4:     	mov	w9, #0x2e               ; =46
1015e0dc8:     	b	0x1015e1000 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x3a4>
1015e0dcc:     	ldp	q0, q1, [sp, #0x2f0]
1015e0dd0:     	ldp	q2, q3, [sp, #0x310]
1015e0dd4:     	stp	q2, q3, [x24, #0x20]
1015e0dd8:     	stp	q0, q1, [x24]
1015e0ddc:     	add	x26, x26, #0x40
1015e0de0:     	add	x25, x25, #0x1
1015e0de4:     	subs	x19, x19, #0x4
1015e0de8:     	ldr	x24, [sp, #0x28]
1015e0dec:     	b.eq	0x1015e1340 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6e4>
1015e0df0:     	str	x19, [sp, #0x48]
1015e0df4:     	ldr	x8, [x27, #0x358]
1015e0df8:     	ldr	x9, [sp, #0x30]
1015e0dfc:     	ldr	w1, [x9, x25, lsl #2]
1015e0e00:     	cmp	x8, x1
1015e0e04:     	b.ls	0x1015e1f88 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x132c>
1015e0e08:     	ldr	x8, [x27, #0x350]
1015e0e0c:     	mov	w9, #0x140              ; =320
1015e0e10:     	umaddl	x8, w1, w9, x8
1015e0e14:     	ldrb	w9, [x8, #0x124]
1015e0e18:     	cmp	w9, #0x7
1015e0e1c:     	b.ne	0x1015e0ee0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x284>
1015e0e20:     	cmp	x25, x22
1015e0e24:     	b.hs	0x1015e1fac <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1350>
1015e0e28:     	ldr	x8, [x23, x25, lsl #3]
1015e0e2c:     	cbnz	x8, 0x1015e1500 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x8a4>
1015e0e30:     	ldr	x8, [x27, #0x488]
1015e0e34:     	cmp	x8, x1
1015e0e38:     	b.ls	0x1015e0e70 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x214>
1015e0e3c:     	ldr	x8, [sp, #0x20]
1015e0e40:     	ldr	x8, [x8]
1015e0e44:     	mov	w9, #0x18               ; =24
1015e0e48:     	umaddl	x8, w1, w9, x8
1015e0e4c:     	ldr	x9, [x8]
1015e0e50:     	cmp	x9, #0x1
1015e0e54:     	b.ne	0x1015e0e70 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x214>
1015e0e58:     	ldp	x8, x9, [x8, #0x8]
1015e0e5c:     	adds	x8, x8, x9
1015e0e60:     	b.hs	0x1015e0e70 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x214>
1015e0e64:     	ldr	x9, [x27, #0x4a8]
1015e0e68:     	cmp	x8, x9
1015e0e6c:     	b.ls	0x1015e0f30 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2d4>
1015e0e70:     	add	x8, sp, #0x400
1015e0e74:     	add	x0, x24, #0xf0
1015e0e78:     	add	x2, x24, #0x2f8
1015e0e7c:     	bl	0x1015fca18 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
1015e0e80:     	ldr	x8, [sp, #0x400]
1015e0e84:     	add	x9, sp, #0x400
1015e0e88:     	ldur	q0, [x9, #0x8]
1015e0e8c:     	ldur	q1, [x9, #0x18]
1015e0e90:     	stp	q0, q1, [sp, #0x50]
1015e0e94:     	ldur	q0, [x9, #0x28]
1015e0e98:     	str	q0, [sp, #0x70]
1015e0e9c:     	ldur	x9, [x9, #0x38]
1015e0ea0:     	str	x9, [sp, #0x80]
1015e0ea4:     	cbz	x8, 0x1015e1540 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x8e4>
1015e0ea8:     	mov	w28, #0x0               ; =0
1015e0eac:     	ldp	q0, q1, [sp, #0x50]
1015e0eb0:     	add	x10, sp, #0x2f0
1015e0eb4:     	stur	q0, [x10, #0x8]
1015e0eb8:     	stur	q1, [x10, #0x18]
1015e0ebc:     	ldr	q0, [sp, #0x70]
1015e0ec0:     	stur	q0, [x10, #0x28]
1015e0ec4:     	ldr	x9, [sp, #0x80]
1015e0ec8:     	stur	x9, [x10, #0x38]
1015e0ecc:     	str	x8, [sp, #0x2f0]
1015e0ed0:     	ldr	x1, [x24, #0xd8]
1015e0ed4:     	cmp	x25, x1
1015e0ed8:     	b.lo	0x1015e0f48 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2ec>
1015e0edc:     	b	0x1015e0f84 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x328>
1015e0ee0:     	cmp	x25, x22
1015e0ee4:     	b.hs	0x1015e1fc0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1364>
1015e0ee8:     	ldr	x8, [x23, x25, lsl #3]
1015e0eec:     	cmp	w9, #0x3
1015e0ef0:     	b.gt	0x1015e0f0c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2b0>
1015e0ef4:     	sub	w9, w9, #0x1
1015e0ef8:     	cmp	w9, #0x3
1015e0efc:     	b.lo	0x1015e0f30 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2d4>
1015e0f00:     	cmp	x8, #0x2
1015e0f04:     	b.lo	0x1015e0f30 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2d4>
1015e0f08:     	b	0x1015e1590 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x934>
1015e0f0c:     	cmp	w9, #0x4
1015e0f10:     	b.eq	0x1015e0f28 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2cc>
1015e0f14:     	cmp	w9, #0x5
1015e0f18:     	b.ne	0x1015e0f68 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x30c>
1015e0f1c:     	cmp	x8, #0x10, lsl #12      ; =0x10000
1015e0f20:     	b.lo	0x1015e0f30 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2d4>
1015e0f24:     	b	0x1015e1590 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x934>
1015e0f28:     	cmp	x8, #0x100
1015e0f2c:     	b.hs	0x1015e1590 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x934>
1015e0f30:     	mov	x8, #0x0                ; =0
1015e0f34:     	mov	w28, #0x1               ; =1
1015e0f38:     	str	x8, [sp, #0x2f0]
1015e0f3c:     	ldr	x1, [x24, #0xd8]
1015e0f40:     	cmp	x25, x1
1015e0f44:     	b.hs	0x1015e0f84 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x328>
1015e0f48:     	ldr	x28, [x24, #0xd0]
1015e0f4c:     	add	x24, x28, x26
1015e0f50:     	ldr	x8, [x24]
1015e0f54:     	ldr	x19, [sp, #0x48]
1015e0f58:     	cbz	x8, 0x1015e0dcc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x170>
1015e0f5c:     	add	x0, x28, x26
1015e0f60:     	bl	0x1015d8c24 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015e0f64:     	b	0x1015e0dcc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x170>
1015e0f68:     	lsr	x8, x8, #32
1015e0f6c:     	cbnz	x8, 0x1015e1590 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x934>
1015e0f70:     	mov	w28, #0x1               ; =1
1015e0f74:     	str	x8, [sp, #0x2f0]
1015e0f78:     	ldr	x1, [x24, #0xd8]
1015e0f7c:     	cmp	x25, x1
1015e0f80:     	b.lo	0x1015e0f48 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2ec>
1015e0f84:     	adrp	x2, 0x108105000 <_anon.26abaa7ef148023673534f8ef223f1d8.123+0x140>
1015e0f88:     	add	x2, x2, #0xf90
1015e0f8c:     	mov	x0, x25
1015e0f90:     	bl	0x103bfb67c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015e0f94:     	b	0x1015e2080 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1424>
1015e0f98:     	cmp	x22, #0x2
1015e0f9c:     	b.ne	0x1015e0fac <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x350>
1015e0fa0:     	ldp	x9, x8, [x23]
1015e0fa4:     	orr	x8, x9, x8
1015e0fa8:     	cbz	x8, 0x1015e1008 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x3ac>
1015e0fac:     	str	wzr, [x0]
1015e0fb0:     	mov	w8, #0xc                ; =12
1015e0fb4:     	strb	w8, [x0, #0x8]
1015e0fb8:     	adrp	x8, 0x10774f000 <_anon.9fbf84db36233a693e1db665f769ea71.111+0x137b>
1015e0fbc:     	add	x8, x8, #0xaae
1015e0fc0:     	mov	w9, #0x34               ; =52
1015e0fc4:     	stp	x8, x9, [x0, #0x10]
1015e0fc8:     	add	sp, sp, #0x4c0
1015e0fcc:     	ldp	x29, x30, [sp, #0x50]
1015e0fd0:     	ldp	x20, x19, [sp, #0x40]
1015e0fd4:     	ldp	x22, x21, [sp, #0x30]
1015e0fd8:     	ldp	x24, x23, [sp, #0x20]
1015e0fdc:     	ldp	x26, x25, [sp, #0x10]
1015e0fe0:     	ldp	x28, x27, [sp], #0x60
1015e0fe4:     	ret
1015e0fe8:     	str	wzr, [x19]
1015e0fec:     	mov	w8, #0xc                ; =12
1015e0ff0:     	str	w8, [x19, #0x8]
1015e0ff4:     	adrp	x8, 0x10774d000 <_anon.26abaa7ef148023673534f8ef223f1d8.125+0x1d3>
1015e0ff8:     	add	x8, x8, #0x8df
1015e0ffc:     	mov	w9, #0x27               ; =39
1015e1000:     	stp	x8, x9, [x19, #0x10]
1015e1004:     	b	0x1015e0fc8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
1015e1008:     	ldr	x1, [x27, #0x378]
1015e100c:     	cmp	x20, x1
1015e1010:     	b.hs	0x1015e1fd4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1378>
1015e1014:     	stp	x24, x0, [sp, #0x38]
1015e1018:     	ldr	x8, [x27, #0x370]
1015e101c:     	mov	w9, #0x170              ; =368
1015e1020:     	madd	x26, x20, x9, x8
1015e1024:     	cbz	x3, 0x1015e12b4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x658>
1015e1028:     	cmp	x3, #0x12
1015e102c:     	b.ne	0x1015e1308 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6ac>
1015e1030:     	ldp	x9, x8, [x26]
1015e1034:     	eor	x9, x9, #0x3
1015e1038:     	orr	x8, x9, x8
1015e103c:     	cbnz	x8, 0x1015e1308 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6ac>
1015e1040:     	ldr	w22, [x26, #0x28]
1015e1044:     	ldr	x8, [sp, #0x38]
1015e1048:     	ldr	w8, [x8, #0x4]
1015e104c:     	cmp	w22, w8
1015e1050:     	b.ne	0x1015e1308 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6ac>
1015e1054:     	ldr	w24, [x26, #0x2c]
1015e1058:     	ldr	x8, [sp, #0x38]
1015e105c:     	ldr	w8, [x8, #0x8]
1015e1060:     	cmp	w24, w8
1015e1064:     	b.ne	0x1015e1308 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6ac>
1015e1068:     	mov	x25, #0x0               ; =0
1015e106c:     	mov	w28, #0x3               ; =3
1015e1070:     	add	x0, x27, #0x480
1015e1074:     	mov	x1, x22
1015e1078:     	bl	0x1015f3f58 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine15native_artifact13buffer_framesNtB5_18NativeBufferFrames6fields>
1015e107c:     	cbz	x0, 0x1015e151c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x8c0>
1015e1080:     	ldr	x8, [sp, #0x38]
1015e1084:     	ldr	x23, [x8, #0x10]
1015e1088:     	cmp	x23, x1
1015e108c:     	b.hs	0x1015e151c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x8c0>
1015e1090:     	add	x8, x0, x23, lsl #5
1015e1094:     	ldrb	w9, [x8]
1015e1098:     	cmp	w9, #0x2
1015e109c:     	b.ne	0x1015e1744 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xae8>
1015e10a0:     	ldp	x8, x9, [x8, #0x8]
1015e10a4:     	adds	x8, x8, x9
1015e10a8:     	b.hs	0x1015e1744 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xae8>
1015e10ac:     	ldr	x9, [x27, #0x4a8]
1015e10b0:     	cmp	x8, x9
1015e10b4:     	b.hi	0x1015e1744 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xae8>
1015e10b8:     	cmp	x28, #0x2
1015e10bc:     	sbcs	xzr, x25, xzr
1015e10c0:     	b.hs	0x1015e18b0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xc54>
1015e10c4:     	ldr	x1, [x26, #0x128]
1015e10c8:     	cmp	x1, #0x1
1015e10cc:     	b.ls	0x1015e204c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13f0>
1015e10d0:     	ldr	x8, [x26, #0x120]
1015e10d4:     	ldr	x25, [x21, #0x490]
1015e10d8:     	ldr	w1, [x8, #0x4]
1015e10dc:     	add	x8, sp, #0x400
1015e10e0:     	add	x0, x25, #0xf0
1015e10e4:     	add	x2, x25, #0x2f8
1015e10e8:     	bl	0x1015fca18 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
1015e10ec:     	add	x8, sp, #0x400
1015e10f0:     	ldur	q0, [x8, #0x8]
1015e10f4:     	ldur	q1, [x8, #0x18]
1015e10f8:     	stp	q0, q1, [sp, #0x150]
1015e10fc:     	ldur	q0, [x8, #0x28]
1015e1100:     	str	q0, [sp, #0x170]
1015e1104:     	ldr	x8, [sp, #0x400]
1015e1108:     	ldr	x9, [sp, #0x438]
1015e110c:     	str	x9, [sp, #0x180]
1015e1110:     	cbz	x8, 0x1015e19b8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xd5c>
1015e1114:     	ldp	q0, q1, [sp, #0x150]
1015e1118:     	add	x9, sp, #0x230
1015e111c:     	stur	q0, [x9, #0x48]
1015e1120:     	stur	q1, [x9, #0x58]
1015e1124:     	ldr	q0, [sp, #0x170]
1015e1128:     	stur	q0, [x9, #0x68]
1015e112c:     	ldr	x9, [sp, #0x180]
1015e1130:     	str	x9, [sp, #0x2a8]
1015e1134:     	str	x8, [sp, #0x270]
1015e1138:     	ldr	x1, [x27, #0x400]
1015e113c:     	cmp	x20, x1
1015e1140:     	b.hs	0x1015e2070 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1414>
1015e1144:     	ldr	x8, [x27, #0x3f8]
1015e1148:     	mov	w9, #0x1f0              ; =496
1015e114c:     	madd	x23, x20, x9, x8
1015e1150:     	ldp	x9, x8, [x23]
1015e1154:     	eor	x9, x9, #0x2
1015e1158:     	orr	x8, x9, x8
1015e115c:     	cbnz	x8, 0x1015e19d8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xd7c>
1015e1160:     	ldr	x10, [sp, #0x40]
1015e1164:     	str	wzr, [x10]
1015e1168:     	mov	w8, #0xc                ; =12
1015e116c:     	adrp	x9, 0x10774d000 <_anon.26abaa7ef148023673534f8ef223f1d8.125+0x1d3>
1015e1170:     	add	x9, x9, #0x926
1015e1174:     	stp	x8, x9, [x10, #0x8]
1015e1178:     	mov	w8, #0x23               ; =35
1015e117c:     	str	x8, [x10, #0x18]
1015e1180:     	b	0x1015e1e60 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1204>
1015e1184:     	str	wzr, [x0]
1015e1188:     	mov	w8, #0xc                ; =12
1015e118c:     	strb	w8, [x0, #0x8]
1015e1190:     	adrp	x8, 0x10774f000 <_anon.9fbf84db36233a693e1db665f769ea71.111+0x137b>
1015e1194:     	add	x8, x8, #0x953
1015e1198:     	mov	w9, #0x28               ; =40
1015e119c:     	b	0x1015e0fc4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x368>
1015e11a0:     	str	wzr, [x0]
1015e11a4:     	mov	w8, #0xc                ; =12
1015e11a8:     	strb	w8, [x0, #0x8]
1015e11ac:     	adrp	x8, 0x10774f000 <_anon.9fbf84db36233a693e1db665f769ea71.111+0x137b>
1015e11b0:     	add	x8, x8, #0x931
1015e11b4:     	mov	w9, #0x22               ; =34
1015e11b8:     	b	0x1015e0fc4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x368>
1015e11bc:     	stp	x24, x19, [sp, #0x38]
1015e11c0:     	ldr	x25, [x21, #0x490]
1015e11c4:     	add	x0, sp, #0x400
1015e11c8:     	add	x1, x25, #0x3c0
1015e11cc:     	add	x2, x27, #0x480
1015e11d0:     	add	x5, x25, #0x2f8
1015e11d4:     	bl	0x1015df5dc <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames4copy>
1015e11d8:     	ldr	w8, [sp, #0x400]
1015e11dc:     	cmp	w8, #0x6
1015e11e0:     	b.ne	0x1015e18ec <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xc90>
1015e11e4:     	mov	x22, #0x0               ; =0
1015e11e8:     	ldr	x9, [sp, #0x38]
1015e11ec:     	ldr	x8, [x9, #0x20]
1015e11f0:     	cbz	x8, 0x1015e132c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6d0>
1015e11f4:     	ldr	x23, [x9, #0x18]
1015e11f8:     	lsl	x24, x8, #2
1015e11fc:     	b	0x1015e1208 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5ac>
1015e1200:     	subs	x24, x24, #0x4
1015e1204:     	b.eq	0x1015e132c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6d0>
1015e1208:     	ldr	w20, [x23], #0x4
1015e120c:     	ldr	x1, [x25, #0x3c0]
1015e1210:     	add	x0, sp, #0x400
1015e1214:     	add	x2, x27, #0x4c8
1015e1218:     	add	x4, x25, #0x2f8
1015e121c:     	mov	x3, x20
1015e1220:     	bl	0x1015e0054 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire>
1015e1224:     	ldr	w9, [sp, #0x400]
1015e1228:     	ldrb	w8, [sp, #0x404]
1015e122c:     	cmp	w9, #0x6
1015e1230:     	b.ne	0x1015e138c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x730>
1015e1234:     	tbnz	w8, #0x0, 0x1015e1200 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5a4>
1015e1238:     	add	x8, sp, #0x400
1015e123c:     	add	x0, x25, #0xf0
1015e1240:     	add	x2, x25, #0x2f8
1015e1244:     	mov	x1, x20
1015e1248:     	bl	0x1015fd298 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena14retire_current>
1015e124c:     	ldrb	w8, [sp, #0x400]
1015e1250:     	cmp	w8, #0x14
1015e1254:     	b.eq	0x1015e1200 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5a4>
1015e1258:     	ldr	q0, [sp, #0x400]
1015e125c:     	ldr	q1, [sp, #0x410]
1015e1260:     	stp	q0, q1, [sp, #0x2f0]
1015e1264:     	ldr	q2, [sp, #0x420]
1015e1268:     	str	q2, [sp, #0x310]
1015e126c:     	ldr	x8, [sp, #0x430]
1015e1270:     	str	x8, [sp, #0x320]
1015e1274:     	stur	q0, [x26, #0x4]
1015e1278:     	stur	q1, [x26, #0x14]
1015e127c:     	stur	q2, [x26, #0x24]
1015e1280:     	stur	x8, [x26, #0x34]
1015e1284:     	mov	w8, #0x2                ; =2
1015e1288:     	ldr	x9, [sp, #0x40]
1015e128c:     	str	w8, [x9]
1015e1290:     	ldr	q0, [sp, #0x400]
1015e1294:     	ldr	q1, [sp, #0x410]
1015e1298:     	stur	q0, [x9, #0x4]
1015e129c:     	stur	q1, [x9, #0x14]
1015e12a0:     	ldr	q0, [sp, #0x420]
1015e12a4:     	stur	q0, [x9, #0x24]
1015e12a8:     	ldur	q0, [x26, #0x2c]
1015e12ac:     	str	q0, [x9, #0x30]
1015e12b0:     	b	0x1015e0fc8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
1015e12b4:     	ldp	x28, x25, [x26]
1015e12b8:     	cmp	x28, #0x2
1015e12bc:     	sbcs	xzr, x25, xzr
1015e12c0:     	b.hs	0x1015e1308 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6ac>
1015e12c4:     	ldr	x8, [x26, #0x128]
1015e12c8:     	cmp	x8, #0x2
1015e12cc:     	b.ne	0x1015e1308 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6ac>
1015e12d0:     	ldr	x8, [x26, #0x120]
1015e12d4:     	ldr	w22, [x8]
1015e12d8:     	ldr	x8, [sp, #0x38]
1015e12dc:     	ldr	w8, [x8, #0x4]
1015e12e0:     	cmp	w22, w8
1015e12e4:     	b.ne	0x1015e1308 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6ac>
1015e12e8:     	ldr	w24, [x26, #0x130]
1015e12ec:     	ldr	x8, [sp, #0x38]
1015e12f0:     	ldr	w8, [x8, #0x8]
1015e12f4:     	cmp	w24, w8
1015e12f8:     	b.ne	0x1015e1308 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6ac>
1015e12fc:     	ldr	x8, [x26, #0x10]
1015e1300:     	cmp	x8, #0xb
1015e1304:     	b.eq	0x1015e1070 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x414>
1015e1308:     	ldr	x10, [sp, #0x40]
1015e130c:     	str	wzr, [x10]
1015e1310:     	mov	w8, #0xc                ; =12
1015e1314:     	strb	w8, [x10, #0x8]
1015e1318:     	adrp	x8, 0x10774f000 <_anon.9fbf84db36233a693e1db665f769ea71.111+0x137b>
1015e131c:     	add	x8, x8, #0xa83
1015e1320:     	mov	w9, #0x2b               ; =43
1015e1324:     	stp	x8, x9, [x10, #0x10]
1015e1328:     	b	0x1015e0fc8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
1015e132c:     	ldr	x9, [sp, #0x40]
1015e1330:     	stp	x22, x21, [x9, #0x8]
1015e1334:     	mov	w8, #0x6                ; =6
1015e1338:     	str	w8, [x9]
1015e133c:     	b	0x1015e0fc8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
1015e1340:     	ldr	x1, [x27, #0x400]
1015e1344:     	cmp	x20, x1
1015e1348:     	b.hs	0x1015e1fe4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1388>
1015e134c:     	ldr	x8, [x27, #0x3f8]
1015e1350:     	mov	w9, #0x1f0              ; =496
1015e1354:     	madd	x28, x20, x9, x8
1015e1358:     	ldp	x9, x8, [x28]
1015e135c:     	eor	x9, x9, #0x2
1015e1360:     	orr	x8, x9, x8
1015e1364:     	ldr	x19, [sp, #0x40]
1015e1368:     	cbnz	x8, 0x1015e13c4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x768>
1015e136c:     	str	wzr, [x19]
1015e1370:     	mov	w8, #0xc                ; =12
1015e1374:     	adrp	x9, 0x10774d000 <_anon.26abaa7ef148023673534f8ef223f1d8.125+0x1d3>
1015e1378:     	add	x9, x9, #0x8bc
1015e137c:     	stp	x8, x9, [x19, #0x8]
1015e1380:     	mov	w8, #0x23               ; =35
1015e1384:     	str	x8, [x19, #0x18]
1015e1388:     	b	0x1015e0fc8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
1015e138c:     	ldur	q0, [x26, #0x15]
1015e1390:     	ldr	x10, [sp, #0x40]
1015e1394:     	stur	q0, [x10, #0x15]
1015e1398:     	ldur	q0, [x26, #0x25]
1015e139c:     	stur	q0, [x10, #0x25]
1015e13a0:     	ldur	q0, [x26, #0x35]
1015e13a4:     	stur	q0, [x10, #0x35]
1015e13a8:     	ldr	q0, [sp, #0x440]
1015e13ac:     	str	q0, [x10, #0x40]
1015e13b0:     	ldur	q0, [x26, #0x5]
1015e13b4:     	stur	q0, [x10, #0x5]
1015e13b8:     	str	w9, [x10]
1015e13bc:     	strb	w8, [x10, #0x4]
1015e13c0:     	b	0x1015e0fc8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
1015e13c4:     	add	x24, sp, #0x400
1015e13c8:     	add	x8, sp, #0x400
1015e13cc:     	mov	x0, x21
1015e13d0:     	mov	w1, #0x0                ; =0
1015e13d4:     	bl	0x1016027f4 <__RNvMs_NtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
1015e13d8:     	ldr	w8, [sp, #0x400]
1015e13dc:     	tbz	w8, #0x0, 0x1015e1410 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x7b4>
1015e13e0:     	ldur	q0, [x24, #0x18]
1015e13e4:     	ldur	q1, [x24, #0x28]
1015e13e8:     	ldur	q2, [x24, #0x38]
1015e13ec:     	stp	q1, q2, [sp, #0x310]
1015e13f0:     	ldur	q3, [x24, #0x48]
1015e13f4:     	str	q3, [sp, #0x330]
1015e13f8:     	ldur	q4, [x24, #0x8]
1015e13fc:     	stp	q4, q0, [sp, #0x2f0]
1015e1400:     	stp	q1, q2, [x19, #0x20]
1015e1404:     	str	q3, [x19, #0x40]
1015e1408:     	stp	q4, q0, [x19]
1015e140c:     	b	0x1015e0fc8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
1015e1410:     	ldr	x10, [sp, #0x30]
1015e1414:     	ldr	x8, [sp, #0x18]
1015e1418:     	add	x8, x10, x8
1015e141c:     	ldur	q0, [x24, #0x48]
1015e1420:     	ldur	q1, [x24, #0x58]
1015e1424:     	stp	q0, q1, [sp, #0x330]
1015e1428:     	ldur	x9, [x24, #0x68]
1015e142c:     	str	x9, [sp, #0x350]
1015e1430:     	ldur	q2, [x24, #0x8]
1015e1434:     	str	q2, [sp, #0x2f0]
1015e1438:     	ldur	q3, [x24, #0x38]
1015e143c:     	ldur	q4, [x24, #0x18]
1015e1440:     	ldur	q5, [x24, #0x28]
1015e1444:     	stp	q2, q4, [sp, #0x90]
1015e1448:     	stp	q5, q3, [sp, #0xb0]
1015e144c:     	str	x9, [sp, #0xf0]
1015e1450:     	stp	q0, q1, [sp, #0xd0]
1015e1454:     	str	x10, [sp, #0x400]
1015e1458:     	str	x8, [sp, #0x408]
1015e145c:     	add	x0, sp, #0x400
1015e1460:     	add	x1, x27, #0x480
1015e1464:     	bl	0x1015dbf40 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_>
1015e1468:     	ldr	x25, [x21, #0x490]
1015e146c:     	ldr	x2, [x25, #0xd8]
1015e1470:     	cmp	x22, x2
1015e1474:     	add	x26, sp, #0x400
1015e1478:     	tbz	w0, #0x0, 0x1015e15b0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x954>
1015e147c:     	b.hi	0x1015e1f1c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12c0>
1015e1480:     	ldr	x1, [x25, #0xd0]
1015e1484:     	ldp	q0, q1, [x21, #0x80]
1015e1488:     	str	q0, [sp, #0x480]
1015e148c:     	str	q1, [sp, #0x490]
1015e1490:     	ldr	x8, [x21, #0xa0]
1015e1494:     	str	x8, [sp, #0x4a0]
1015e1498:     	ldp	q0, q1, [x21, #0x40]
1015e149c:     	str	q0, [sp, #0x440]
1015e14a0:     	str	q1, [sp, #0x450]
1015e14a4:     	ldp	q1, q0, [x21, #0x60]
1015e14a8:     	str	q0, [sp, #0x470]
1015e14ac:     	str	q1, [sp, #0x460]
1015e14b0:     	ldp	q0, q1, [x21]
1015e14b4:     	str	q0, [sp, #0x400]
1015e14b8:     	str	q1, [sp, #0x410]
1015e14bc:     	ldp	q1, q0, [x21, #0x20]
1015e14c0:     	add	x8, x25, #0x3b8
1015e14c4:     	str	q0, [sp, #0x430]
1015e14c8:     	str	q1, [sp, #0x420]
1015e14cc:     	add	x9, sp, #0x90
1015e14d0:     	stp	x8, x9, [sp, #0x8]
1015e14d4:     	add	x9, sp, #0x400
1015e14d8:     	str	x9, [sp]
1015e14dc:     	add	x8, sp, #0xf8
1015e14e0:     	add	x5, x25, #0x3c0
1015e14e4:     	mov	x0, x28
1015e14e8:     	mov	x2, x22
1015e14ec:     	mov	x3, x23
1015e14f0:     	mov	x4, x22
1015e14f4:     	mov	x6, #0x0                ; =0
1015e14f8:     	bl	0x1015953d0 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_>
1015e14fc:     	b	0x1015e1620 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x9c4>
1015e1500:     	ldr	x10, [sp, #0x40]
1015e1504:     	str	wzr, [x10]
1015e1508:     	mov	w8, #0xc                ; =12
1015e150c:     	strb	w8, [x10, #0x8]
1015e1510:     	adrp	x8, 0x10774f000 <_anon.9fbf84db36233a693e1db665f769ea71.111+0x137b>
1015e1514:     	add	x8, x8, #0x8dc
1015e1518:     	b	0x1015e1320 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6c4>
1015e151c:     	ldr	x10, [sp, #0x40]
1015e1520:     	str	wzr, [x10]
1015e1524:     	mov	w8, #0xc                ; =12
1015e1528:     	adrp	x9, 0x10774d000 <_anon.26abaa7ef148023673534f8ef223f1d8.125+0x1d3>
1015e152c:     	add	x9, x9, #0x906
1015e1530:     	stp	x8, x9, [x10, #0x8]
1015e1534:     	mov	w8, #0x20               ; =32
1015e1538:     	str	x8, [x10, #0x18]
1015e153c:     	b	0x1015e0fc8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
1015e1540:     	ldp	q0, q1, [sp, #0x50]
1015e1544:     	add	x9, sp, #0x400
1015e1548:     	stur	q0, [x9, #0x4]
1015e154c:     	stur	q1, [x9, #0x14]
1015e1550:     	ldr	q0, [sp, #0x70]
1015e1554:     	stur	q0, [x9, #0x24]
1015e1558:     	ldr	x8, [sp, #0x80]
1015e155c:     	stur	x8, [x9, #0x34]
1015e1560:     	ldr	q0, [sp, #0x400]
1015e1564:     	ldr	q1, [sp, #0x410]
1015e1568:     	ldr	x10, [sp, #0x40]
1015e156c:     	stur	q0, [x10, #0x4]
1015e1570:     	mov	w8, #0x2                ; =2
1015e1574:     	str	w8, [x10]
1015e1578:     	stur	q1, [x10, #0x14]
1015e157c:     	ldr	q0, [sp, #0x420]
1015e1580:     	stur	q0, [x10, #0x24]
1015e1584:     	ldur	q0, [x9, #0x2c]
1015e1588:     	str	q0, [x10, #0x30]
1015e158c:     	b	0x1015e0fc8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
1015e1590:     	ldr	x10, [sp, #0x40]
1015e1594:     	str	wzr, [x10]
1015e1598:     	mov	w8, #0xc                ; =12
1015e159c:     	strb	w8, [x10, #0x8]
1015e15a0:     	adrp	x8, 0x10774f000 <_anon.9fbf84db36233a693e1db665f769ea71.111+0x137b>
1015e15a4:     	add	x8, x8, #0x907
1015e15a8:     	mov	w9, #0x2a               ; =42
1015e15ac:     	b	0x1015e1324 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6c8>
1015e15b0:     	b.hi	0x1015e1f30 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12d4>
1015e15b4:     	ldr	x1, [x25, #0xd0]
1015e15b8:     	ldp	q0, q1, [x21, #0x80]
1015e15bc:     	str	q0, [sp, #0x480]
1015e15c0:     	str	q1, [sp, #0x490]
1015e15c4:     	ldr	x8, [x21, #0xa0]
1015e15c8:     	str	x8, [sp, #0x4a0]
1015e15cc:     	ldp	q0, q1, [x21, #0x40]
1015e15d0:     	str	q0, [sp, #0x440]
1015e15d4:     	str	q1, [sp, #0x450]
1015e15d8:     	ldp	q1, q0, [x21, #0x60]
1015e15dc:     	str	q0, [sp, #0x470]
1015e15e0:     	str	q1, [sp, #0x460]
1015e15e4:     	ldp	q0, q1, [x21]
1015e15e8:     	str	q0, [sp, #0x400]
1015e15ec:     	str	q1, [sp, #0x410]
1015e15f0:     	ldp	q1, q0, [x21, #0x20]
1015e15f4:     	str	q0, [sp, #0x430]
1015e15f8:     	str	q1, [sp, #0x420]
1015e15fc:     	add	x8, sp, #0xf8
1015e1600:     	add	x5, sp, #0x400
1015e1604:     	add	x6, x25, #0x3b8
1015e1608:     	add	x7, sp, #0x90
1015e160c:     	mov	x0, x28
1015e1610:     	mov	x2, x22
1015e1614:     	mov	x3, x23
1015e1618:     	mov	x4, x22
1015e161c:     	bl	0x1027f60a0 <__RNvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared13buffer_framesNtB6_25NativePreparedLibraryCall24admit_buffer_frame_words>
1015e1620:     	ldrb	w8, [sp, #0xf8]
1015e1624:     	cmp	w8, #0x2e
1015e1628:     	b.ne	0x1015e16c8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xa6c>
1015e162c:     	ldr	x2, [x25, #0xd8]
1015e1630:     	cmp	x22, x2
1015e1634:     	b.hi	0x1015e1f44 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e8>
1015e1638:     	ldr	x6, [x25, #0xd0]
1015e163c:     	ldp	x4, x8, [sp, #0x30]
1015e1640:     	ldr	w3, [x8, #0x4]
1015e1644:     	add	x8, x25, #0x2f8
1015e1648:     	stp	x22, x8, [sp, #0x8]
1015e164c:     	add	x0, sp, #0x400
1015e1650:     	add	x1, x25, #0x3c0
1015e1654:     	add	x2, x27, #0x480
1015e1658:     	str	x23, [sp]
1015e165c:     	mov	x5, x22
1015e1660:     	mov	x7, x22
1015e1664:     	bl	0x1015df900 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames4pack>
1015e1668:     	ldr	x2, [x25, #0xd8]
1015e166c:     	cmp	x22, x2
1015e1670:     	b.hi	0x1015e1f70 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1314>
1015e1674:     	ldr	x0, [x25, #0xd0]
1015e1678:     	str	xzr, [sp, #0x2f0]
1015e167c:     	add	x2, sp, #0x2f0
1015e1680:     	mov	x1, x22
1015e1684:     	bl	0x1015d22f8 <__RNvXNtNtCsgDHHaSskbIF_4core5slice10specializeSINtNtB6_6option6OptionNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEINtB2_8SpecFillBI_E9spec_fillCs29QkOtpKx6e_8mech_gpu>
1015e1688:     	ldr	w8, [sp, #0x400]
1015e168c:     	cmp	w8, #0x6
1015e1690:     	b.eq	0x1015e11e4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x588>
1015e1694:     	ldur	q0, [x26, #0x14]
1015e1698:     	ldr	x9, [sp, #0x40]
1015e169c:     	stur	q0, [x9, #0x14]
1015e16a0:     	ldur	q0, [x26, #0x24]
1015e16a4:     	stur	q0, [x9, #0x24]
1015e16a8:     	ldur	q0, [x26, #0x34]
1015e16ac:     	stur	q0, [x9, #0x34]
1015e16b0:     	ldr	q0, [sp, #0x440]
1015e16b4:     	str	q0, [x9, #0x40]
1015e16b8:     	ldur	q0, [x26, #0x4]
1015e16bc:     	stur	q0, [x9, #0x4]
1015e16c0:     	str	w8, [x9]
1015e16c4:     	b	0x1015e0fc8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
1015e16c8:     	ldr	x2, [x25, #0xd8]
1015e16cc:     	cmp	x22, x2
1015e16d0:     	b.hi	0x1015e1f58 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12fc>
1015e16d4:     	ldr	x0, [x25, #0xd0]
1015e16d8:     	str	xzr, [sp, #0x400]
1015e16dc:     	add	x2, sp, #0x400
1015e16e0:     	mov	x1, x22
1015e16e4:     	bl	0x1015d22f8 <__RNvXNtNtCsgDHHaSskbIF_4core5slice10specializeSINtNtB6_6option6OptionNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEINtB2_8SpecFillBI_E9spec_fillCs29QkOtpKx6e_8mech_gpu>
1015e16e8:     	ldr	x1, [x27, #0x378]
1015e16ec:     	cmp	x20, x1
1015e16f0:     	b.hs	0x1015e1ff4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1398>
1015e16f4:     	ldr	x8, [x27, #0x370]
1015e16f8:     	mov	w9, #0x170              ; =368
1015e16fc:     	madd	x8, x20, x9, x8
1015e1700:     	ldr	w9, [x8, #0x158]
1015e1704:     	add	x10, sp, #0xf8
1015e1708:     	add	x8, x8, #0x148
1015e170c:     	ldr	q0, [x8]
1015e1710:     	ldp	q1, q2, [x10]
1015e1714:     	ldr	x11, [sp, #0x40]
1015e1718:     	stur	q1, [x11, #0x18]
1015e171c:     	stur	q2, [x11, #0x28]
1015e1720:     	ldr	q1, [x10, #0x20]
1015e1724:     	stur	q1, [x11, #0x38]
1015e1728:     	ldr	x8, [sp, #0x128]
1015e172c:     	str	x8, [x11, #0x48]
1015e1730:     	mov	w8, #0x3                ; =3
1015e1734:     	str	w8, [x11]
1015e1738:     	stur	q0, [x11, #0x4]
1015e173c:     	str	w9, [x11, #0x14]
1015e1740:     	b	0x1015e0fc8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
1015e1744:     	ldr	x25, [x21, #0x490]
1015e1748:     	ldr	x1, [x25, #0x3c0]
1015e174c:     	add	x0, sp, #0x400
1015e1750:     	add	x2, x27, #0x480
1015e1754:     	add	x5, x25, #0x2f8
1015e1758:     	mov	x3, x22
1015e175c:     	mov	x4, x23
1015e1760:     	bl	0x1015e02bc <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames7project>
1015e1764:     	ldr	w8, [sp, #0x400]
1015e1768:     	cmp	w8, #0x6
1015e176c:     	b.ne	0x1015e1864 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xc08>
1015e1770:     	add	x8, sp, #0x400
1015e1774:     	ldur	q0, [x8, #0x38]
1015e1778:     	ldur	q1, [x8, #0x28]
1015e177c:     	ldur	q2, [x8, #0x18]
1015e1780:     	ldur	q3, [x8, #0x8]
1015e1784:     	stp	q3, q2, [sp, #0x230]
1015e1788:     	stp	q1, q0, [sp, #0x250]
1015e178c:     	ldp	x9, x8, [x26]
1015e1790:     	mov	w10, #0x1               ; =1
1015e1794:     	cmp	x10, x9
1015e1798:     	ngcs	xzr, x8
1015e179c:     	b.lo	0x1015e1c4c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xff0>
1015e17a0:     	ldr	x8, [x26, #0x128]
1015e17a4:     	cmp	x8, #0x2
1015e17a8:     	b.lo	0x1015e2014 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13b8>
1015e17ac:     	ldr	x8, [x26, #0x120]
1015e17b0:     	ldr	w1, [x8, #0x4]
1015e17b4:     	mov	w22, #0x1               ; =1
1015e17b8:     	add	x8, sp, #0x400
1015e17bc:     	add	x0, x25, #0xf0
1015e17c0:     	add	x2, x25, #0x2f8
1015e17c4:     	bl	0x1015fca18 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
1015e17c8:     	add	x8, sp, #0x400
1015e17cc:     	ldur	q0, [x8, #0x8]
1015e17d0:     	ldur	q1, [x8, #0x18]
1015e17d4:     	stp	q0, q1, [sp, #0x2b0]
1015e17d8:     	ldur	q0, [x8, #0x28]
1015e17dc:     	str	q0, [sp, #0x2d0]
1015e17e0:     	ldr	x8, [sp, #0x400]
1015e17e4:     	ldr	x9, [sp, #0x438]
1015e17e8:     	str	x9, [sp, #0x2e0]
1015e17ec:     	cbz	x8, 0x1015e1914 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xcb8>
1015e17f0:     	ldp	q0, q1, [sp, #0x2b0]
1015e17f4:     	add	x9, sp, #0x230
1015e17f8:     	stur	q0, [x9, #0x48]
1015e17fc:     	stur	q1, [x9, #0x58]
1015e1800:     	ldr	q0, [sp, #0x2d0]
1015e1804:     	add	x26, sp, #0x230
1015e1808:     	stur	q0, [x9, #0x68]
1015e180c:     	ldr	x9, [sp, #0x2e0]
1015e1810:     	str	x9, [sp, #0x2a8]
1015e1814:     	str	x8, [sp, #0x270]
1015e1818:     	ldr	x1, [x27, #0x400]
1015e181c:     	cmp	x20, x1
1015e1820:     	b.hs	0x1015e205c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1400>
1015e1824:     	ldr	x8, [x27, #0x3f8]
1015e1828:     	mov	w9, #0x1f0              ; =496
1015e182c:     	madd	x22, x20, x9, x8
1015e1830:     	ldp	x9, x8, [x22]
1015e1834:     	eor	x9, x9, #0x2
1015e1838:     	orr	x8, x9, x8
1015e183c:     	cbnz	x8, 0x1015e1964 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xd08>
1015e1840:     	ldr	x10, [sp, #0x40]
1015e1844:     	str	wzr, [x10]
1015e1848:     	mov	w8, #0xc                ; =12
1015e184c:     	adrp	x9, 0x10774d000 <_anon.26abaa7ef148023673534f8ef223f1d8.125+0x1d3>
1015e1850:     	add	x9, x9, #0x949
1015e1854:     	stp	x8, x9, [x10, #0x8]
1015e1858:     	mov	w8, #0x2a               ; =42
1015e185c:     	str	x8, [x10, #0x18]
1015e1860:     	b	0x1015e1dec <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1190>
1015e1864:     	add	x10, sp, #0x400
1015e1868:     	ldur	q0, [x10, #0x14]
1015e186c:     	ldur	q1, [x10, #0x24]
1015e1870:     	ldur	q2, [x10, #0x34]
1015e1874:     	stp	q1, q2, [sp, #0x310]
1015e1878:     	ldr	w9, [sp, #0x444]
1015e187c:     	str	w9, [sp, #0x330]
1015e1880:     	ldur	q3, [x10, #0x4]
1015e1884:     	stp	q3, q0, [sp, #0x2f0]
1015e1888:     	ldr	x10, [sp, #0x448]
1015e188c:     	ldr	x11, [sp, #0x40]
1015e1890:     	stur	q0, [x11, #0x14]
1015e1894:     	stur	q1, [x11, #0x24]
1015e1898:     	stur	q2, [x11, #0x34]
1015e189c:     	str	w9, [x11, #0x44]
1015e18a0:     	stur	q3, [x11, #0x4]
1015e18a4:     	str	w8, [x11]
1015e18a8:     	str	x10, [x11, #0x48]
1015e18ac:     	b	0x1015e0fc8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
1015e18b0:     	ldr	x25, [x21, #0x490]
1015e18b4:     	add	x0, sp, #0x400
1015e18b8:     	add	x1, x25, #0x3c0
1015e18bc:     	add	x2, x27, #0x480
1015e18c0:     	add	x6, x25, #0x2f8
1015e18c4:     	mov	x3, x22
1015e18c8:     	mov	x4, x23
1015e18cc:     	mov	x5, x24
1015e18d0:     	bl	0x1015de970 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames17project_composite>
1015e18d4:     	ldr	w8, [sp, #0x400]
1015e18d8:     	cmp	w8, #0x6
1015e18dc:     	b.ne	0x1015e18ec <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xc90>
1015e18e0:     	mov	x22, #0x0               ; =0
1015e18e4:     	add	x26, sp, #0x400
1015e18e8:     	b	0x1015e11e8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x58c>
1015e18ec:     	ldr	q0, [sp, #0x420]
1015e18f0:     	ldr	q1, [sp, #0x430]
1015e18f4:     	ldr	x8, [sp, #0x40]
1015e18f8:     	stp	q0, q1, [x8, #0x20]
1015e18fc:     	ldr	q0, [sp, #0x440]
1015e1900:     	str	q0, [x8, #0x40]
1015e1904:     	ldr	q0, [sp, #0x410]
1015e1908:     	ldr	q1, [sp, #0x400]
1015e190c:     	stp	q1, q0, [x8]
1015e1910:     	b	0x1015e0fc8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
1015e1914:     	ldp	q0, q1, [sp, #0x2b0]
1015e1918:     	add	x9, sp, #0x400
1015e191c:     	stur	q0, [x9, #0x4]
1015e1920:     	stur	q1, [x9, #0x14]
1015e1924:     	ldr	q0, [sp, #0x2d0]
1015e1928:     	stur	q0, [x9, #0x24]
1015e192c:     	ldr	x8, [sp, #0x2e0]
1015e1930:     	stur	x8, [x9, #0x34]
1015e1934:     	ldr	q0, [sp, #0x400]
1015e1938:     	ldr	q1, [sp, #0x410]
1015e193c:     	ldr	x10, [sp, #0x40]
1015e1940:     	stur	q0, [x10, #0x4]
1015e1944:     	mov	w8, #0x2                ; =2
1015e1948:     	str	w8, [x10]
1015e194c:     	stur	q1, [x10, #0x14]
1015e1950:     	ldr	q0, [sp, #0x420]
1015e1954:     	stur	q0, [x10, #0x24]
1015e1958:     	ldur	q0, [x9, #0x2c]
1015e195c:     	str	q0, [x10, #0x30]
1015e1960:     	b	0x1015e1df8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x119c>
1015e1964:     	add	x24, sp, #0x400
1015e1968:     	add	x8, sp, #0x400
1015e196c:     	mov	x0, x21
1015e1970:     	mov	w1, #0x0                ; =0
1015e1974:     	bl	0x1016027f4 <__RNvMs_NtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
1015e1978:     	ldr	x8, [sp, #0x400]
1015e197c:     	cmp	x8, #0x1
1015e1980:     	b.ne	0x1015e1a2c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xdd0>
1015e1984:     	ldur	q0, [x24, #0x18]
1015e1988:     	ldur	q1, [x24, #0x28]
1015e198c:     	ldur	q2, [x24, #0x38]
1015e1990:     	stp	q1, q2, [sp, #0x310]
1015e1994:     	ldur	q3, [x24, #0x48]
1015e1998:     	str	q3, [sp, #0x330]
1015e199c:     	ldur	q4, [x24, #0x8]
1015e19a0:     	stp	q4, q0, [sp, #0x2f0]
1015e19a4:     	ldr	x8, [sp, #0x40]
1015e19a8:     	stp	q1, q2, [x8, #0x20]
1015e19ac:     	str	q3, [x8, #0x40]
1015e19b0:     	stp	q4, q0, [x8]
1015e19b4:     	b	0x1015e1dec <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1190>
1015e19b8:     	ldp	q0, q1, [sp, #0x150]
1015e19bc:     	add	x9, sp, #0x400
1015e19c0:     	stur	q0, [x9, #0x4]
1015e19c4:     	stur	q1, [x9, #0x14]
1015e19c8:     	ldr	q0, [sp, #0x170]
1015e19cc:     	stur	q0, [x9, #0x24]
1015e19d0:     	ldr	x8, [sp, #0x180]
1015e19d4:     	b	0x1015e155c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x900>
1015e19d8:     	add	x24, sp, #0x400
1015e19dc:     	add	x8, sp, #0x400
1015e19e0:     	mov	x0, x21
1015e19e4:     	mov	w1, #0x0                ; =0
1015e19e8:     	bl	0x1016027f4 <__RNvMs_NtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
1015e19ec:     	ldr	x8, [sp, #0x400]
1015e19f0:     	cmp	x8, #0x1
1015e19f4:     	b.ne	0x1015e1ad8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xe7c>
1015e19f8:     	ldur	q0, [x24, #0x18]
1015e19fc:     	ldur	q1, [x24, #0x28]
1015e1a00:     	ldur	q2, [x24, #0x38]
1015e1a04:     	stp	q1, q2, [sp, #0x310]
1015e1a08:     	ldur	q3, [x24, #0x48]
1015e1a0c:     	str	q3, [sp, #0x330]
1015e1a10:     	ldur	q4, [x24, #0x8]
1015e1a14:     	stp	q4, q0, [sp, #0x2f0]
1015e1a18:     	ldr	x8, [sp, #0x40]
1015e1a1c:     	stp	q1, q2, [x8, #0x20]
1015e1a20:     	str	q3, [x8, #0x40]
1015e1a24:     	stp	q4, q0, [x8]
1015e1a28:     	b	0x1015e1e60 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1204>
1015e1a2c:     	ldur	q0, [x24, #0x48]
1015e1a30:     	ldur	q1, [x24, #0x58]
1015e1a34:     	stp	q0, q1, [sp, #0x330]
1015e1a38:     	ldur	x8, [x24, #0x68]
1015e1a3c:     	str	x8, [sp, #0x350]
1015e1a40:     	ldur	q2, [x24, #0x8]
1015e1a44:     	ldur	q3, [x24, #0x18]
1015e1a48:     	stp	q2, q3, [sp, #0x2f0]
1015e1a4c:     	ldur	q4, [x24, #0x38]
1015e1a50:     	ldur	q5, [x24, #0x28]
1015e1a54:     	stp	q2, q3, [sp, #0x360]
1015e1a58:     	stp	q5, q4, [sp, #0x380]
1015e1a5c:     	str	x8, [sp, #0x3c0]
1015e1a60:     	stp	q0, q1, [sp, #0x3a0]
1015e1a64:     	ldr	x8, [sp, #0x230]
1015e1a68:     	cbz	x8, 0x1015e1bc0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xf64>
1015e1a6c:     	ldp	q0, q1, [x21, #0x80]
1015e1a70:     	str	q0, [sp, #0x480]
1015e1a74:     	str	q1, [sp, #0x490]
1015e1a78:     	ldr	x8, [x21, #0xa0]
1015e1a7c:     	str	x8, [sp, #0x4a0]
1015e1a80:     	ldp	q0, q1, [x21, #0x40]
1015e1a84:     	str	q0, [sp, #0x440]
1015e1a88:     	str	q1, [sp, #0x450]
1015e1a8c:     	ldp	q1, q0, [x21, #0x60]
1015e1a90:     	str	q0, [sp, #0x470]
1015e1a94:     	str	q1, [sp, #0x460]
1015e1a98:     	ldp	q0, q1, [x21]
1015e1a9c:     	str	q0, [sp, #0x400]
1015e1aa0:     	str	q1, [sp, #0x410]
1015e1aa4:     	ldp	q1, q0, [x21, #0x20]
1015e1aa8:     	str	q0, [sp, #0x430]
1015e1aac:     	str	q1, [sp, #0x420]
1015e1ab0:     	add	x8, sp, #0x3c8
1015e1ab4:     	add	x1, sp, #0x270
1015e1ab8:     	add	x3, sp, #0x230
1015e1abc:     	add	x4, sp, #0x400
1015e1ac0:     	add	x5, x25, #0x3b8
1015e1ac4:     	add	x6, sp, #0x360
1015e1ac8:     	mov	x0, x22
1015e1acc:     	mov	x2, x23
1015e1ad0:     	bl	0x1027f6444 <__RNvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared13buffer_framesNtB6_25NativePreparedLibraryCall25admit_buffer_record_field>
1015e1ad4:     	b	0x1015e1c34 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xfd8>
1015e1ad8:     	ldur	q0, [x24, #0x48]
1015e1adc:     	ldur	q1, [x24, #0x58]
1015e1ae0:     	stp	q0, q1, [sp, #0x330]
1015e1ae4:     	ldur	x8, [x24, #0x68]
1015e1ae8:     	str	x8, [sp, #0x350]
1015e1aec:     	ldur	q2, [x24, #0x8]
1015e1af0:     	ldur	q3, [x24, #0x18]
1015e1af4:     	stp	q2, q3, [sp, #0x2f0]
1015e1af8:     	ldur	q4, [x24, #0x38]
1015e1afc:     	ldur	q5, [x24, #0x28]
1015e1b00:     	stp	q2, q3, [sp, #0x190]
1015e1b04:     	stp	q5, q4, [sp, #0x1b0]
1015e1b08:     	str	x8, [sp, #0x1f0]
1015e1b0c:     	stp	q0, q1, [sp, #0x1d0]
1015e1b10:     	ldr	x8, [sp, #0x38]
1015e1b14:     	ldr	x7, [x8, #0x10]
1015e1b18:     	ldp	q0, q1, [x21, #0x80]
1015e1b1c:     	str	q0, [sp, #0x480]
1015e1b20:     	str	q1, [sp, #0x490]
1015e1b24:     	ldr	x8, [x21, #0xa0]
1015e1b28:     	str	x8, [sp, #0x4a0]
1015e1b2c:     	ldp	q0, q1, [x21, #0x40]
1015e1b30:     	str	q0, [sp, #0x440]
1015e1b34:     	str	q1, [sp, #0x450]
1015e1b38:     	ldp	q1, q0, [x21, #0x60]
1015e1b3c:     	str	q0, [sp, #0x470]
1015e1b40:     	str	q1, [sp, #0x460]
1015e1b44:     	ldp	q0, q1, [x21]
1015e1b48:     	str	q0, [sp, #0x400]
1015e1b4c:     	str	q1, [sp, #0x410]
1015e1b50:     	ldp	q1, q0, [x21, #0x20]
1015e1b54:     	add	x8, x25, #0x3b8
1015e1b58:     	str	q0, [sp, #0x430]
1015e1b5c:     	str	q1, [sp, #0x420]
1015e1b60:     	add	x9, sp, #0x190
1015e1b64:     	stp	x8, x9, [sp, #0x8]
1015e1b68:     	add	x9, sp, #0x400
1015e1b6c:     	adrp	x1, 0x10774f000 <_anon.9fbf84db36233a693e1db665f769ea71.111+0x137b>
1015e1b70:     	add	x1, x1, #0x9b0
1015e1b74:     	str	x9, [sp]
1015e1b78:     	add	x8, sp, #0x1f8
1015e1b7c:     	add	x5, x25, #0x3c0
1015e1b80:     	add	x6, sp, #0x270
1015e1b84:     	adrp	x3, 0x107752000 <_anon.9fbf84db36233a693e1db665f769ea71.381+0x28e0>
1015e1b88:     	add	x3, x3, #0xac0
1015e1b8c:     	mov	x0, x23
1015e1b90:     	mov	w2, #0x2                ; =2
1015e1b94:     	mov	w4, #0x2                ; =2
1015e1b98:     	bl	0x10159561c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_>
1015e1b9c:     	ldrb	w8, [sp, #0x1f8]
1015e1ba0:     	cmp	w8, #0x2e
1015e1ba4:     	b.ne	0x1015e1e24 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x11c8>
1015e1ba8:     	add	x0, sp, #0x270
1015e1bac:     	bl	0x1015d8c24 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015e1bb0:     	ldr	x8, [sp, #0x38]
1015e1bb4:     	ldr	x23, [x8, #0x10]
1015e1bb8:     	ldr	w24, [x8, #0x8]
1015e1bbc:     	b	0x1015e18b4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xc58>
1015e1bc0:     	ldr	w3, [sp, #0x248]
1015e1bc4:     	ldur	q0, [x26, #0x8]
1015e1bc8:     	str	q0, [sp, #0x2f0]
1015e1bcc:     	ldp	q0, q1, [x21, #0x80]
1015e1bd0:     	str	q0, [sp, #0x480]
1015e1bd4:     	str	q1, [sp, #0x490]
1015e1bd8:     	ldr	x8, [x21, #0xa0]
1015e1bdc:     	str	x8, [sp, #0x4a0]
1015e1be0:     	ldp	q0, q1, [x21, #0x40]
1015e1be4:     	str	q0, [sp, #0x440]
1015e1be8:     	str	q1, [sp, #0x450]
1015e1bec:     	ldp	q1, q0, [x21, #0x60]
1015e1bf0:     	str	q0, [sp, #0x470]
1015e1bf4:     	str	q1, [sp, #0x460]
1015e1bf8:     	ldp	q0, q1, [x21]
1015e1bfc:     	str	q0, [sp, #0x400]
1015e1c00:     	str	q1, [sp, #0x410]
1015e1c04:     	ldp	q1, q0, [x21, #0x20]
1015e1c08:     	str	q0, [sp, #0x430]
1015e1c0c:     	str	q1, [sp, #0x420]
1015e1c10:     	add	x8, sp, #0x3c8
1015e1c14:     	add	x1, sp, #0x270
1015e1c18:     	add	x4, sp, #0x2f0
1015e1c1c:     	add	x5, sp, #0x400
1015e1c20:     	add	x6, x25, #0x3b8
1015e1c24:     	add	x7, sp, #0x360
1015e1c28:     	mov	x0, x22
1015e1c2c:     	mov	x2, x23
1015e1c30:     	bl	0x1027f60fc <__RNvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared13buffer_framesNtB6_25NativePreparedLibraryCall24admit_buffer_record_word>
1015e1c34:     	ldrb	w8, [sp, #0x3c8]
1015e1c38:     	cmp	w8, #0x2e
1015e1c3c:     	b.ne	0x1015e1db0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1154>
1015e1c40:     	mov	w22, #0x1               ; =1
1015e1c44:     	add	x0, sp, #0x270
1015e1c48:     	bl	0x1015d8c24 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015e1c4c:     	ldr	x8, [x27, #0x358]
1015e1c50:     	ldr	x9, [sp, #0x38]
1015e1c54:     	ldr	w1, [x9, #0x8]
1015e1c58:     	cmp	x8, x1
1015e1c5c:     	b.ls	0x1015e2008 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13ac>
1015e1c60:     	ldr	x8, [x27, #0x350]
1015e1c64:     	mov	w9, #0x140              ; =320
1015e1c68:     	umaddl	x9, w1, w9, x8
1015e1c6c:     	ldr	x8, [sp, #0x230]
1015e1c70:     	cbz	x8, 0x1015e1d54 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x10f8>
1015e1c74:     	ldp	q0, q1, [sp, #0x230]
1015e1c78:     	str	q0, [sp, #0x400]
1015e1c7c:     	str	q1, [sp, #0x410]
1015e1c80:     	ldp	q0, q1, [sp, #0x250]
1015e1c84:     	str	q0, [sp, #0x420]
1015e1c88:     	str	q1, [sp, #0x430]
1015e1c8c:     	ldr	x8, [x27, #0x440]
1015e1c90:     	cmp	x8, x1
1015e1c94:     	b.ls	0x1015e2034 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13d8>
1015e1c98:     	ldr	x8, [x27, #0x438]
1015e1c9c:     	mov	w10, #0x24              ; =36
1015e1ca0:     	umaddl	x8, w1, w10, x8
1015e1ca4:     	ldr	w10, [sp, #0x438]
1015e1ca8:     	ldr	w11, [x8, #0x20]
1015e1cac:     	cmp	w10, w11
1015e1cb0:     	b.ne	0x1015e1d24 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x10c8>
1015e1cb4:     	ldp	q0, q1, [sp, #0x240]
1015e1cb8:     	stp	q0, q1, [sp, #0x2f0]
1015e1cbc:     	ldr	x10, [sp, #0x2f0]
1015e1cc0:     	ldr	x11, [sp, #0x2f8]
1015e1cc4:     	ldp	x12, x13, [x8]
1015e1cc8:     	ldr	x14, [sp, #0x300]
1015e1ccc:     	ldr	x15, [sp, #0x308]
1015e1cd0:     	ldp	x16, x8, [x8, #0x10]
1015e1cd4:     	cmp	x10, x12
1015e1cd8:     	ccmp	x11, x13, #0x0, eq
1015e1cdc:     	ccmp	x14, x16, #0x0, eq
1015e1ce0:     	ccmp	x15, x8, #0x0, eq
1015e1ce4:     	b.ne	0x1015e1d24 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x10c8>
1015e1ce8:     	ldrb	w8, [x9, #0x124]
1015e1cec:     	cmp	w8, #0x7
1015e1cf0:     	b.ne	0x1015e1d24 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x10c8>
1015e1cf4:     	add	x8, sp, #0x2f0
1015e1cf8:     	add	x0, x25, #0xf0
1015e1cfc:     	add	x2, sp, #0x400
1015e1d00:     	add	x3, x25, #0x2f8
1015e1d04:     	bl	0x1015fe520 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena3put>
1015e1d08:     	ldrb	w8, [sp, #0x2f0]
1015e1d0c:     	cmp	w8, #0x14
1015e1d10:     	b.ne	0x1015e1e6c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1210>
1015e1d14:     	mov	w22, #0x0               ; =0
1015e1d18:     	add	x0, sp, #0x400
1015e1d1c:     	bl	0x1015d8c24 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015e1d20:     	b	0x1015e18e0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xc84>
1015e1d24:     	ldr	x10, [sp, #0x40]
1015e1d28:     	str	wzr, [x10]
1015e1d2c:     	mov	w8, #0xc                ; =12
1015e1d30:     	strb	w8, [x10, #0x8]
1015e1d34:     	adrp	x8, 0x10774f000 <_anon.9fbf84db36233a693e1db665f769ea71.111+0x137b>
1015e1d38:     	add	x8, x8, #0xa59
1015e1d3c:     	mov	w9, #0x2a               ; =42
1015e1d40:     	stp	x8, x9, [x10, #0x10]
1015e1d44:     	mov	w22, #0x0               ; =0
1015e1d48:     	add	x0, sp, #0x400
1015e1d4c:     	bl	0x1015d8c24 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015e1d50:     	b	0x1015e0fc8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
1015e1d54:     	ldr	w8, [sp, #0x248]
1015e1d58:     	ldr	w10, [x9, #0x130]
1015e1d5c:     	cmp	w8, w10
1015e1d60:     	b.ne	0x1015e1efc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12a0>
1015e1d64:     	ldrb	w8, [sp, #0x239]
1015e1d68:     	ldr	x21, [sp, #0x240]
1015e1d6c:     	ldrb	w10, [sp, #0x238]
1015e1d70:     	ldrb	w9, [x9, #0x124]
1015e1d74:     	cmp	w10, #0x2
1015e1d78:     	b.le	0x1015e1d98 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x113c>
1015e1d7c:     	cmp	w10, #0x4
1015e1d80:     	b.gt	0x1015e1e0c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x11b0>
1015e1d84:     	cmp	w10, #0x3
1015e1d88:     	b.ne	0x1015e1ecc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1270>
1015e1d8c:     	cmp	w9, #0x3
1015e1d90:     	b.eq	0x1015e1ef0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1294>
1015e1d94:     	b	0x1015e1efc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12a0>
1015e1d98:     	cbz	w10, 0x1015e1eb4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1258>
1015e1d9c:     	cmp	w10, #0x1
1015e1da0:     	b.ne	0x1015e1ec0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1264>
1015e1da4:     	cmp	w9, #0x1
1015e1da8:     	b.eq	0x1015e1ef0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1294>
1015e1dac:     	b	0x1015e1efc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12a0>
1015e1db0:     	ldr	x1, [x27, #0x370]
1015e1db4:     	ldr	x2, [x27, #0x378]
1015e1db8:     	add	x0, sp, #0x400
1015e1dbc:     	add	x4, sp, #0x3c8
1015e1dc0:     	mov	x3, x20
1015e1dc4:     	bl	0x1015dc71c <__RNCNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions8_0Be_>
1015e1dc8:     	ldr	q0, [sp, #0x420]
1015e1dcc:     	ldr	q1, [sp, #0x430]
1015e1dd0:     	ldr	x8, [sp, #0x40]
1015e1dd4:     	stp	q0, q1, [x8, #0x20]
1015e1dd8:     	ldr	q0, [sp, #0x440]
1015e1ddc:     	str	q0, [x8, #0x40]
1015e1de0:     	ldr	q0, [sp, #0x410]
1015e1de4:     	ldr	q1, [sp, #0x400]
1015e1de8:     	stp	q1, q0, [x8]
1015e1dec:     	mov	w22, #0x1               ; =1
1015e1df0:     	add	x0, sp, #0x270
1015e1df4:     	bl	0x1015d8c24 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015e1df8:     	ldr	x8, [sp, #0x230]
1015e1dfc:     	cbz	x8, 0x1015e0fc8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
1015e1e00:     	add	x0, sp, #0x230
1015e1e04:     	bl	0x1015d8c24 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015e1e08:     	b	0x1015e0fc8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
1015e1e0c:     	cmp	w10, #0x5
1015e1e10:     	b.ne	0x1015e1ee4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1288>
1015e1e14:     	cmp	w9, #0x5
1015e1e18:     	b.ne	0x1015e1efc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12a0>
1015e1e1c:     	ldrh	w21, [sp, #0x23a]
1015e1e20:     	b	0x1015e1ef0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1294>
1015e1e24:     	ldr	x1, [x27, #0x370]
1015e1e28:     	ldr	x2, [x27, #0x378]
1015e1e2c:     	add	x0, sp, #0x400
1015e1e30:     	add	x4, sp, #0x1f8
1015e1e34:     	mov	x3, x20
1015e1e38:     	bl	0x1015dc688 <__RNCNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions6_0Be_>
1015e1e3c:     	ldr	q0, [sp, #0x420]
1015e1e40:     	ldr	q1, [sp, #0x430]
1015e1e44:     	ldr	x8, [sp, #0x40]
1015e1e48:     	stp	q0, q1, [x8, #0x20]
1015e1e4c:     	ldr	q0, [sp, #0x440]
1015e1e50:     	str	q0, [x8, #0x40]
1015e1e54:     	ldr	q0, [sp, #0x410]
1015e1e58:     	ldr	q1, [sp, #0x400]
1015e1e5c:     	stp	q1, q0, [x8]
1015e1e60:     	add	x0, sp, #0x270
1015e1e64:     	bl	0x1015d8c24 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015e1e68:     	b	0x1015e0fc8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
1015e1e6c:     	add	x10, sp, #0x230
1015e1e70:     	ldur	w9, [x10, #0xc1]
1015e1e74:     	ldr	x11, [sp, #0x40]
1015e1e78:     	stur	w9, [x11, #0x9]
1015e1e7c:     	ldr	w9, [sp, #0x2f4]
1015e1e80:     	str	w9, [x11, #0xc]
1015e1e84:     	ldr	q0, [sp, #0x310]
1015e1e88:     	stur	q0, [x11, #0x28]
1015e1e8c:     	ldr	x9, [sp, #0x320]
1015e1e90:     	str	x9, [x11, #0x38]
1015e1e94:     	ldr	d0, [sp, #0x308]
1015e1e98:     	ldur	q1, [x10, #0xc8]
1015e1e9c:     	mov	w9, #0x2                ; =2
1015e1ea0:     	str	w9, [x11]
1015e1ea4:     	strb	w8, [x11, #0x8]
1015e1ea8:     	str	q1, [x11, #0x10]
1015e1eac:     	str	d0, [x11, #0x20]
1015e1eb0:     	b	0x1015e1d44 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x10e8>
1015e1eb4:     	cbnz	w9, 0x1015e1efc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12a0>
1015e1eb8:     	and	x21, x8, #0x1
1015e1ebc:     	b	0x1015e1ef0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1294>
1015e1ec0:     	cmp	w9, #0x2
1015e1ec4:     	b.eq	0x1015e1ef0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1294>
1015e1ec8:     	b	0x1015e1efc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12a0>
1015e1ecc:     	cmp	w9, #0x4
1015e1ed0:     	b.ne	0x1015e1efc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12a0>
1015e1ed4:     	mov	w22, #0x1               ; =1
1015e1ed8:     	mov	x21, x8
1015e1edc:     	add	x26, sp, #0x400
1015e1ee0:     	b	0x1015e11e8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x58c>
1015e1ee4:     	cmp	w9, #0x6
1015e1ee8:     	b.ne	0x1015e1efc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12a0>
1015e1eec:     	ldr	w21, [sp, #0x23c]
1015e1ef0:     	mov	w22, #0x1               ; =1
1015e1ef4:     	add	x26, sp, #0x400
1015e1ef8:     	b	0x1015e11e8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x58c>
1015e1efc:     	ldr	x10, [sp, #0x40]
1015e1f00:     	str	wzr, [x10]
1015e1f04:     	mov	w8, #0xc                ; =12
1015e1f08:     	strb	w8, [x10, #0x8]
1015e1f0c:     	adrp	x8, 0x10774f000 <_anon.9fbf84db36233a693e1db665f769ea71.111+0x137b>
1015e1f10:     	add	x8, x8, #0xa30
1015e1f14:     	mov	w9, #0x29               ; =41
1015e1f18:     	b	0x1015e1324 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6c8>
1015e1f1c:     	adrp	x3, 0x108105000 <_anon.26abaa7ef148023673534f8ef223f1d8.123+0x140>
1015e1f20:     	add	x3, x3, #0xf30
1015e1f24:     	mov	x0, #0x0                ; =0
1015e1f28:     	mov	x1, x22
1015e1f2c:     	bl	0x103bfb830 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015e1f30:     	adrp	x3, 0x108105000 <_anon.26abaa7ef148023673534f8ef223f1d8.123+0x140>
1015e1f34:     	add	x3, x3, #0xeb8
1015e1f38:     	mov	x0, #0x0                ; =0
1015e1f3c:     	mov	x1, x22
1015e1f40:     	bl	0x103bfb830 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015e1f44:     	adrp	x3, 0x108105000 <_anon.26abaa7ef148023673534f8ef223f1d8.123+0x140>
1015e1f48:     	add	x3, x3, #0xf18
1015e1f4c:     	mov	x0, #0x0                ; =0
1015e1f50:     	mov	x1, x22
1015e1f54:     	bl	0x103bfb830 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015e1f58:     	adrp	x3, 0x108105000 <_anon.26abaa7ef148023673534f8ef223f1d8.123+0x140>
1015e1f5c:     	add	x3, x3, #0xee8
1015e1f60:     	mov	x0, #0x0                ; =0
1015e1f64:     	mov	x1, x22
1015e1f68:     	bl	0x103bfb830 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015e1f6c:     	b	0x1015e2080 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1424>
1015e1f70:     	adrp	x3, 0x108105000 <_anon.26abaa7ef148023673534f8ef223f1d8.123+0x140>
1015e1f74:     	add	x3, x3, #0xf00
1015e1f78:     	mov	x0, #0x0                ; =0
1015e1f7c:     	mov	x1, x22
1015e1f80:     	bl	0x103bfb830 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015e1f84:     	b	0x1015e2080 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1424>
1015e1f88:     	adrp	x2, 0x108105000 <_anon.26abaa7ef148023673534f8ef223f1d8.123+0x140>
1015e1f8c:     	add	x2, x2, #0xf48
1015e1f90:     	mov	x0, x1
1015e1f94:     	mov	x1, x8
1015e1f98:     	bl	0x103bfb67c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015e1f9c:     	adrp	x2, 0x108105000 <_anon.26abaa7ef148023673534f8ef223f1d8.123+0x140>
1015e1fa0:     	add	x2, x2, #0xe88
1015e1fa4:     	mov	x0, x20
1015e1fa8:     	bl	0x103bfb67c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015e1fac:     	adrp	x2, 0x108105000 <_anon.26abaa7ef148023673534f8ef223f1d8.123+0x140>
1015e1fb0:     	add	x2, x2, #0xf60
1015e1fb4:     	mov	x0, x25
1015e1fb8:     	mov	x1, x22
1015e1fbc:     	bl	0x103bfb67c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015e1fc0:     	adrp	x2, 0x108105000 <_anon.26abaa7ef148023673534f8ef223f1d8.123+0x140>
1015e1fc4:     	add	x2, x2, #0xf78
1015e1fc8:     	mov	x0, x25
1015e1fcc:     	mov	x1, x22
1015e1fd0:     	bl	0x103bfb67c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015e1fd4:     	adrp	x2, 0x108105000 <_anon.26abaa7ef148023673534f8ef223f1d8.123+0x140>
1015e1fd8:     	add	x2, x2, #0xfa8
1015e1fdc:     	mov	x0, x20
1015e1fe0:     	bl	0x103bfb67c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015e1fe4:     	adrp	x2, 0x108105000 <_anon.26abaa7ef148023673534f8ef223f1d8.123+0x140>
1015e1fe8:     	add	x2, x2, #0xea0
1015e1fec:     	mov	x0, x20
1015e1ff0:     	bl	0x103bfb67c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015e1ff4:     	adrp	x2, 0x108105000 <_anon.26abaa7ef148023673534f8ef223f1d8.123+0x140>
1015e1ff8:     	add	x2, x2, #0xed0
1015e1ffc:     	mov	x0, x20
1015e2000:     	bl	0x103bfb67c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015e2004:     	b	0x1015e2080 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1424>
1015e2008:     	adrp	x2, 0x108106000 <_anon.9fbf84db36233a693e1db665f769ea71.220+0x600>
1015e200c:     	add	x2, x2, #0x20
1015e2010:     	b	0x1015e2020 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13c4>
1015e2014:     	adrp	x2, 0x108105000 <_anon.26abaa7ef148023673534f8ef223f1d8.123+0x140>
1015e2018:     	add	x2, x2, #0xff0
1015e201c:     	mov	w1, #0x1                ; =1
1015e2020:     	mov	w22, #0x1               ; =1
1015e2024:     	mov	x0, x1
1015e2028:     	mov	x1, x8
1015e202c:     	bl	0x103bfb67c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015e2030:     	b	0x1015e2080 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1424>
1015e2034:     	adrp	x2, 0x108106000 <_anon.9fbf84db36233a693e1db665f769ea71.220+0x600>
1015e2038:     	add	x2, x2, #0x38
1015e203c:     	mov	x0, x1
1015e2040:     	mov	x1, x8
1015e2044:     	bl	0x103bfb67c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015e2048:     	b	0x1015e2080 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1424>
1015e204c:     	adrp	x2, 0x108105000 <_anon.26abaa7ef148023673534f8ef223f1d8.123+0x140>
1015e2050:     	add	x2, x2, #0xfc0
1015e2054:     	mov	w0, #0x1                ; =1
1015e2058:     	bl	0x103bfb67c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015e205c:     	adrp	x2, 0x108106000 <_anon.9fbf84db36233a693e1db665f769ea71.220+0x600>
1015e2060:     	add	x2, x2, #0x8
1015e2064:     	mov	x0, x20
1015e2068:     	bl	0x103bfb67c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015e206c:     	b	0x1015e2080 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1424>
1015e2070:     	adrp	x2, 0x108105000 <_anon.26abaa7ef148023673534f8ef223f1d8.123+0x140>
1015e2074:     	add	x2, x2, #0xfd8
1015e2078:     	mov	x0, x20
1015e207c:     	bl	0x103bfb67c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015e2080:     	brk	#0x1
1015e2084:     	mov	x19, x0
1015e2088:     	add	x0, sp, #0x400
1015e208c:     	bl	0x1015d8c24 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015e2090:     	b	0x1015e2130 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14d4>
1015e2094:     	mov	x19, x0
1015e2098:     	add	x0, sp, #0x270
1015e209c:     	bl	0x1015d8c24 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015e20a0:     	b	0x1015e2130 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14d4>
1015e20a4:     	mov	x19, x0
1015e20a8:     	add	x0, sp, #0x270
1015e20ac:     	bl	0x1015d8c24 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015e20b0:     	mov	w22, #0x1               ; =1
1015e20b4:     	b	0x1015e20bc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1460>
1015e20b8:     	mov	x19, x0
1015e20bc:     	cbz	w22, 0x1015e2130 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14d4>
1015e20c0:     	ldr	x8, [sp, #0x230]
1015e20c4:     	cbz	x8, 0x1015e2130 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14d4>
1015e20c8:     	add	x0, sp, #0x230
1015e20cc:     	bl	0x1015d8c24 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015e20d0:     	b	0x1015e2130 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14d4>
1015e20d4:     	add	x8, x28, x26
1015e20d8:     	ldp	q0, q1, [sp, #0x2f0]
1015e20dc:     	ldp	q2, q3, [sp, #0x310]
1015e20e0:     	stp	q2, q3, [x8, #0x20]
1015e20e4:     	stp	q0, q1, [x8]
1015e20e8:     	bl	0x103bfca48 <dyld_stub_binder+0x103bfca48>
1015e20ec:     	mov	x19, x0
1015e20f0:     	tbnz	w28, #0x0, 0x1015e2130 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14d4>
1015e20f4:     	add	x0, sp, #0x2f0
1015e20f8:     	bl	0x1015d8c24 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015e20fc:     	b	0x1015e2130 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14d4>
1015e2100:     	bl	0x103bfb664 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1015e2104:     	mov	x19, x0
1015e2108:     	ldr	w8, [sp, #0x400]
1015e210c:     	cmp	w8, #0x6
1015e2110:     	b.eq	0x1015e2130 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14d4>
1015e2114:     	add	x0, sp, #0x400
1015e2118:     	bl	0x1015d9524 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
1015e211c:     	mov	x0, x19
1015e2120:     	bl	0x103bfca48 <dyld_stub_binder+0x103bfca48>
1015e2124:     	mov	x19, x0
1015e2128:     	add	x0, sp, #0xf8
1015e212c:     	bl	0x1015d97f4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs29QkOtpKx6e_8mech_gpu>
1015e2130:     	mov	x0, x19
1015e2134:     	bl	0x103bfca48 <dyld_stub_binder+0x103bfca48>
