
/private/tmp/mech-projection-round41-20261030/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101526764 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action>:
101526764:     	stp	x28, x27, [sp, #-0x60]!
101526768:     	stp	x26, x25, [sp, #0x10]
10152676c:     	stp	x24, x23, [sp, #0x20]
101526770:     	stp	x22, x21, [sp, #0x30]
101526774:     	stp	x20, x19, [sp, #0x40]
101526778:     	stp	x29, x30, [sp, #0x50]
10152677c:     	add	x29, sp, #0x50
101526780:     	sub	sp, sp, #0x4c0
101526784:     	str	xzr, [sp]
101526788:     	ldr	x27, [x1, #0x498]
10152678c:     	ldr	x8, [x27, #0x4a8]
101526790:     	cmp	x2, x8
101526794:     	b.hs	0x101526860 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xfc>
101526798:     	mov	x22, x5
10152679c:     	mov	x23, x4
1015267a0:     	mov	x20, x2
1015267a4:     	mov	x21, x1
1015267a8:     	add	x26, sp, #0x400
1015267ac:     	ldr	x8, [x27, #0x4a0]
1015267b0:     	mov	w9, #0x28               ; =40
1015267b4:     	madd	x24, x2, x9, x8
1015267b8:     	ldr	w8, [x24]
1015267bc:     	cmp	w8, #0x1
1015267c0:     	b.gt	0x101526844 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xe0>
1015267c4:     	cbnz	w8, 0x101526874 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x110>
1015267c8:     	cbnz	x3, 0x101526ab4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x350>
1015267cc:     	ldr	x1, [x27, #0x378]
1015267d0:     	cmp	x20, x1
1015267d4:     	b.hs	0x101527aa4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1340>
1015267d8:     	ldr	x8, [x27, #0x370]
1015267dc:     	mov	w9, #0x170              ; =368
1015267e0:     	madd	x8, x20, x9, x8
1015267e4:     	ldp	x10, x9, [x8]
1015267e8:     	cmp	x10, #0x2
1015267ec:     	sbcs	xzr, x9, xzr
1015267f0:     	b.hs	0x101526c8c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x528>
1015267f4:     	ldr	w9, [x8, #0x130]
1015267f8:     	ldr	w10, [x24, #0x4]
1015267fc:     	cmp	w9, w10
101526800:     	b.ne	0x101526ca8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x544>
101526804:     	ldr	x9, [x8, #0x128]
101526808:     	cmp	x22, x9
10152680c:     	b.ne	0x101526ca8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x544>
101526810:     	stp	x24, x0, [sp, #0x38]
101526814:     	add	x9, x27, #0x490
101526818:     	ldr	x8, [x8, #0x120]
10152681c:     	str	x8, [sp, #0x30]
101526820:     	lsl	x8, x22, #2
101526824:     	stp	x8, x9, [sp, #0x18]
101526828:     	cbz	x22, 0x101526e48 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6e4>
10152682c:     	mov	x26, #0x0               ; =0
101526830:     	mov	x25, #0x0               ; =0
101526834:     	ldr	x24, [x21, #0x490]
101526838:     	ldr	x19, [sp, #0x18]
10152683c:     	str	x24, [sp, #0x28]
101526840:     	b	0x1015268f8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x194>
101526844:     	cmp	w8, #0x2
101526848:     	b.ne	0x101526860 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xfc>
10152684c:     	cbz	x3, 0x101526aa0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x33c>
101526850:     	cmp	x3, #0x12
101526854:     	b.ne	0x101526ab4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x350>
101526858:     	cbnz	x22, 0x101526ab4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x350>
10152685c:     	b	0x101526b10 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x3ac>
101526860:     	mov	w8, #0x2                ; =2
101526864:     	str	x8, [x0, #0x8]
101526868:     	mov	w8, #0x6                ; =6
10152686c:     	str	w8, [x0]
101526870:     	b	0x101526ad0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
101526874:     	cmp	x3, #0x1
101526878:     	b.ne	0x101526ab4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x350>
10152687c:     	cbnz	x22, 0x101526ab4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x350>
101526880:     	mov	x19, x0
101526884:     	add	x0, sp, #0x400
101526888:     	mov	x1, x21
10152688c:     	mov	x2, x20
101526890:     	bl	0x101539aa4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation10needs_move>
101526894:     	ldr	w8, [sp, #0x400]
101526898:     	cmp	w8, #0x1
10152689c:     	b.ne	0x101526af0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x38c>
1015268a0:     	ldr	w3, [sp, #0x404]
1015268a4:     	ldr	w4, [sp, #0x408]
1015268a8:     	ldp	w8, w9, [x24, #0x4]
1015268ac:     	cmp	w3, w8
1015268b0:     	ccmp	w4, w9, #0x0, eq
1015268b4:     	b.eq	0x101526cc4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x560>
1015268b8:     	str	wzr, [x19]
1015268bc:     	mov	w8, #0xc                ; =12
1015268c0:     	strb	w8, [x19, #0x8]
1015268c4:     	adrp	x8, 0x107752000 <_anon.45e389ad4f82eaa9758c115126120daa.142+0x1162>
1015268c8:     	add	x8, x8, #0xb3f
1015268cc:     	mov	w9, #0x2e               ; =46
1015268d0:     	b	0x101526b08 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x3a4>
1015268d4:     	ldp	q0, q1, [sp, #0x2f0]
1015268d8:     	ldp	q2, q3, [sp, #0x310]
1015268dc:     	stp	q2, q3, [x24, #0x20]
1015268e0:     	stp	q0, q1, [x24]
1015268e4:     	add	x26, x26, #0x40
1015268e8:     	add	x25, x25, #0x1
1015268ec:     	subs	x19, x19, #0x4
1015268f0:     	ldr	x24, [sp, #0x28]
1015268f4:     	b.eq	0x101526e48 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6e4>
1015268f8:     	str	x19, [sp, #0x48]
1015268fc:     	ldr	x8, [x27, #0x358]
101526900:     	ldr	x9, [sp, #0x30]
101526904:     	ldr	w1, [x9, x25, lsl #2]
101526908:     	cmp	x8, x1
10152690c:     	b.ls	0x101527a90 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x132c>
101526910:     	ldr	x8, [x27, #0x350]
101526914:     	mov	w9, #0x140              ; =320
101526918:     	umaddl	x8, w1, w9, x8
10152691c:     	ldrb	w9, [x8, #0x124]
101526920:     	cmp	w9, #0x7
101526924:     	b.ne	0x1015269e8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x284>
101526928:     	cmp	x25, x22
10152692c:     	b.hs	0x101527ab4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1350>
101526930:     	ldr	x8, [x23, x25, lsl #3]
101526934:     	cbnz	x8, 0x101527008 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x8a4>
101526938:     	ldr	x8, [x27, #0x498]
10152693c:     	cmp	x8, x1
101526940:     	b.ls	0x101526978 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x214>
101526944:     	ldr	x8, [sp, #0x20]
101526948:     	ldr	x8, [x8]
10152694c:     	mov	w9, #0x18               ; =24
101526950:     	umaddl	x8, w1, w9, x8
101526954:     	ldr	x9, [x8]
101526958:     	cmp	x9, #0x1
10152695c:     	b.ne	0x101526978 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x214>
101526960:     	ldp	x8, x9, [x8, #0x8]
101526964:     	adds	x8, x8, x9
101526968:     	b.hs	0x101526978 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x214>
10152696c:     	ldr	x9, [x27, #0x4b8]
101526970:     	cmp	x8, x9
101526974:     	b.ls	0x101526a38 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2d4>
101526978:     	add	x8, sp, #0x400
10152697c:     	add	x0, x24, #0xf0
101526980:     	add	x2, x24, #0x2f8
101526984:     	bl	0x10154244c <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
101526988:     	ldr	x8, [sp, #0x400]
10152698c:     	add	x9, sp, #0x400
101526990:     	ldur	q0, [x9, #0x8]
101526994:     	ldur	q1, [x9, #0x18]
101526998:     	stp	q0, q1, [sp, #0x50]
10152699c:     	ldur	q0, [x9, #0x28]
1015269a0:     	str	q0, [sp, #0x70]
1015269a4:     	ldur	x9, [x9, #0x38]
1015269a8:     	str	x9, [sp, #0x80]
1015269ac:     	cbz	x8, 0x101527048 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x8e4>
1015269b0:     	mov	w28, #0x0               ; =0
1015269b4:     	ldp	q0, q1, [sp, #0x50]
1015269b8:     	add	x10, sp, #0x2f0
1015269bc:     	stur	q0, [x10, #0x8]
1015269c0:     	stur	q1, [x10, #0x18]
1015269c4:     	ldr	q0, [sp, #0x70]
1015269c8:     	stur	q0, [x10, #0x28]
1015269cc:     	ldr	x9, [sp, #0x80]
1015269d0:     	stur	x9, [x10, #0x38]
1015269d4:     	str	x8, [sp, #0x2f0]
1015269d8:     	ldr	x1, [x24, #0xd8]
1015269dc:     	cmp	x25, x1
1015269e0:     	b.lo	0x101526a50 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2ec>
1015269e4:     	b	0x101526a8c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x328>
1015269e8:     	cmp	x25, x22
1015269ec:     	b.hs	0x101527ac8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1364>
1015269f0:     	ldr	x8, [x23, x25, lsl #3]
1015269f4:     	cmp	w9, #0x3
1015269f8:     	b.gt	0x101526a14 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2b0>
1015269fc:     	sub	w9, w9, #0x1
101526a00:     	cmp	w9, #0x3
101526a04:     	b.lo	0x101526a38 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2d4>
101526a08:     	cmp	x8, #0x2
101526a0c:     	b.lo	0x101526a38 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2d4>
101526a10:     	b	0x101527098 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x934>
101526a14:     	cmp	w9, #0x4
101526a18:     	b.eq	0x101526a30 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2cc>
101526a1c:     	cmp	w9, #0x5
101526a20:     	b.ne	0x101526a70 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x30c>
101526a24:     	cmp	x8, #0x10, lsl #12      ; =0x10000
101526a28:     	b.lo	0x101526a38 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2d4>
101526a2c:     	b	0x101527098 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x934>
101526a30:     	cmp	x8, #0x100
101526a34:     	b.hs	0x101527098 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x934>
101526a38:     	mov	x8, #0x0                ; =0
101526a3c:     	mov	w28, #0x1               ; =1
101526a40:     	str	x8, [sp, #0x2f0]
101526a44:     	ldr	x1, [x24, #0xd8]
101526a48:     	cmp	x25, x1
101526a4c:     	b.hs	0x101526a8c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x328>
101526a50:     	ldr	x28, [x24, #0xd0]
101526a54:     	add	x24, x28, x26
101526a58:     	ldr	x8, [x24]
101526a5c:     	ldr	x19, [sp, #0x48]
101526a60:     	cbz	x8, 0x1015268d4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x170>
101526a64:     	add	x0, x28, x26
101526a68:     	bl	0x10151e1a8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
101526a6c:     	b	0x1015268d4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x170>
101526a70:     	lsr	x8, x8, #32
101526a74:     	cbnz	x8, 0x101527098 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x934>
101526a78:     	mov	w28, #0x1               ; =1
101526a7c:     	str	x8, [sp, #0x2f0]
101526a80:     	ldr	x1, [x24, #0xd8]
101526a84:     	cmp	x25, x1
101526a88:     	b.lo	0x101526a50 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2ec>
101526a8c:     	adrp	x2, 0x10810c000 <_anon.45e389ad4f82eaa9758c115126120daa.251+0x50>
101526a90:     	add	x2, x2, #0x558
101526a94:     	mov	x0, x25
101526a98:     	bl	0x103c06154 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101526a9c:     	b	0x101527b88 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1424>
101526aa0:     	cmp	x22, #0x2
101526aa4:     	b.ne	0x101526ab4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x350>
101526aa8:     	ldp	x9, x8, [x23]
101526aac:     	orr	x8, x9, x8
101526ab0:     	cbz	x8, 0x101526b10 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x3ac>
101526ab4:     	str	wzr, [x0]
101526ab8:     	mov	w8, #0xc                ; =12
101526abc:     	strb	w8, [x0, #0x8]
101526ac0:     	adrp	x8, 0x107752000 <_anon.45e389ad4f82eaa9758c115126120daa.142+0x1162>
101526ac4:     	add	x8, x8, #0xc6e
101526ac8:     	mov	w9, #0x34               ; =52
101526acc:     	stp	x8, x9, [x0, #0x10]
101526ad0:     	add	sp, sp, #0x4c0
101526ad4:     	ldp	x29, x30, [sp, #0x50]
101526ad8:     	ldp	x20, x19, [sp, #0x40]
101526adc:     	ldp	x22, x21, [sp, #0x30]
101526ae0:     	ldp	x24, x23, [sp, #0x20]
101526ae4:     	ldp	x26, x25, [sp, #0x10]
101526ae8:     	ldp	x28, x27, [sp], #0x60
101526aec:     	ret
101526af0:     	str	wzr, [x19]
101526af4:     	mov	w8, #0xc                ; =12
101526af8:     	str	w8, [x19, #0x8]
101526afc:     	adrp	x8, 0x107750000 <_anon.99dc88c6b0d3d7e47e3fc43c7734dd3a.287+0xa0>
101526b00:     	add	x8, x8, #0xaf8
101526b04:     	mov	w9, #0x27               ; =39
101526b08:     	stp	x8, x9, [x19, #0x10]
101526b0c:     	b	0x101526ad0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
101526b10:     	ldr	x1, [x27, #0x378]
101526b14:     	cmp	x20, x1
101526b18:     	b.hs	0x101527adc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1378>
101526b1c:     	stp	x24, x0, [sp, #0x38]
101526b20:     	ldr	x8, [x27, #0x370]
101526b24:     	mov	w9, #0x170              ; =368
101526b28:     	madd	x26, x20, x9, x8
101526b2c:     	cbz	x3, 0x101526dbc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x658>
101526b30:     	cmp	x3, #0x12
101526b34:     	b.ne	0x101526e10 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6ac>
101526b38:     	ldp	x9, x8, [x26]
101526b3c:     	eor	x9, x9, #0x3
101526b40:     	orr	x8, x9, x8
101526b44:     	cbnz	x8, 0x101526e10 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6ac>
101526b48:     	ldr	w22, [x26, #0x28]
101526b4c:     	ldr	x8, [sp, #0x38]
101526b50:     	ldr	w8, [x8, #0x4]
101526b54:     	cmp	w22, w8
101526b58:     	b.ne	0x101526e10 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6ac>
101526b5c:     	ldr	w24, [x26, #0x2c]
101526b60:     	ldr	x8, [sp, #0x38]
101526b64:     	ldr	w8, [x8, #0x8]
101526b68:     	cmp	w24, w8
101526b6c:     	b.ne	0x101526e10 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6ac>
101526b70:     	mov	x25, #0x0               ; =0
101526b74:     	mov	w28, #0x3               ; =3
101526b78:     	add	x0, x27, #0x490
101526b7c:     	mov	x1, x22
101526b80:     	bl	0x1015399f0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine15native_artifact13buffer_framesNtB5_18NativeBufferFrames6fields>
101526b84:     	cbz	x0, 0x101527024 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x8c0>
101526b88:     	ldr	x8, [sp, #0x38]
101526b8c:     	ldr	x23, [x8, #0x10]
101526b90:     	cmp	x23, x1
101526b94:     	b.hs	0x101527024 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x8c0>
101526b98:     	add	x8, x0, x23, lsl #5
101526b9c:     	ldrb	w9, [x8]
101526ba0:     	cmp	w9, #0x2
101526ba4:     	b.ne	0x10152724c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xae8>
101526ba8:     	ldp	x8, x9, [x8, #0x8]
101526bac:     	adds	x8, x8, x9
101526bb0:     	b.hs	0x10152724c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xae8>
101526bb4:     	ldr	x9, [x27, #0x4b8]
101526bb8:     	cmp	x8, x9
101526bbc:     	b.hi	0x10152724c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xae8>
101526bc0:     	cmp	x28, #0x2
101526bc4:     	sbcs	xzr, x25, xzr
101526bc8:     	b.hs	0x1015273b8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xc54>
101526bcc:     	ldr	x1, [x26, #0x128]
101526bd0:     	cmp	x1, #0x1
101526bd4:     	b.ls	0x101527b54 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13f0>
101526bd8:     	ldr	x8, [x26, #0x120]
101526bdc:     	ldr	x25, [x21, #0x490]
101526be0:     	ldr	w1, [x8, #0x4]
101526be4:     	add	x8, sp, #0x400
101526be8:     	add	x0, x25, #0xf0
101526bec:     	add	x2, x25, #0x2f8
101526bf0:     	bl	0x10154244c <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
101526bf4:     	add	x8, sp, #0x400
101526bf8:     	ldur	q0, [x8, #0x8]
101526bfc:     	ldur	q1, [x8, #0x18]
101526c00:     	stp	q0, q1, [sp, #0x150]
101526c04:     	ldur	q0, [x8, #0x28]
101526c08:     	str	q0, [sp, #0x170]
101526c0c:     	ldr	x8, [sp, #0x400]
101526c10:     	ldr	x9, [sp, #0x438]
101526c14:     	str	x9, [sp, #0x180]
101526c18:     	cbz	x8, 0x1015274c0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xd5c>
101526c1c:     	ldp	q0, q1, [sp, #0x150]
101526c20:     	add	x9, sp, #0x230
101526c24:     	stur	q0, [x9, #0x48]
101526c28:     	stur	q1, [x9, #0x58]
101526c2c:     	ldr	q0, [sp, #0x170]
101526c30:     	stur	q0, [x9, #0x68]
101526c34:     	ldr	x9, [sp, #0x180]
101526c38:     	str	x9, [sp, #0x2a8]
101526c3c:     	str	x8, [sp, #0x270]
101526c40:     	ldr	x1, [x27, #0x400]
101526c44:     	cmp	x20, x1
101526c48:     	b.hs	0x101527b78 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1414>
101526c4c:     	ldr	x8, [x27, #0x3f8]
101526c50:     	mov	w9, #0x1f0              ; =496
101526c54:     	madd	x23, x20, x9, x8
101526c58:     	ldp	x9, x8, [x23]
101526c5c:     	eor	x9, x9, #0x2
101526c60:     	orr	x8, x9, x8
101526c64:     	cbnz	x8, 0x1015274e0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xd7c>
101526c68:     	ldr	x10, [sp, #0x40]
101526c6c:     	str	wzr, [x10]
101526c70:     	mov	w8, #0xc                ; =12
101526c74:     	adrp	x9, 0x107750000 <_anon.99dc88c6b0d3d7e47e3fc43c7734dd3a.287+0xa0>
101526c78:     	add	x9, x9, #0xb3f
101526c7c:     	stp	x8, x9, [x10, #0x8]
101526c80:     	mov	w8, #0x23               ; =35
101526c84:     	str	x8, [x10, #0x18]
101526c88:     	b	0x101527968 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1204>
101526c8c:     	str	wzr, [x0]
101526c90:     	mov	w8, #0xc                ; =12
101526c94:     	strb	w8, [x0, #0x8]
101526c98:     	adrp	x8, 0x107752000 <_anon.45e389ad4f82eaa9758c115126120daa.142+0x1162>
101526c9c:     	add	x8, x8, #0xb17
101526ca0:     	mov	w9, #0x28               ; =40
101526ca4:     	b	0x101526acc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x368>
101526ca8:     	str	wzr, [x0]
101526cac:     	mov	w8, #0xc                ; =12
101526cb0:     	strb	w8, [x0, #0x8]
101526cb4:     	adrp	x8, 0x107752000 <_anon.45e389ad4f82eaa9758c115126120daa.142+0x1162>
101526cb8:     	add	x8, x8, #0xaf5
101526cbc:     	mov	w9, #0x22               ; =34
101526cc0:     	b	0x101526acc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x368>
101526cc4:     	stp	x24, x19, [sp, #0x38]
101526cc8:     	ldr	x25, [x21, #0x490]
101526ccc:     	add	x0, sp, #0x400
101526cd0:     	add	x1, x25, #0x3c0
101526cd4:     	add	x2, x27, #0x490
101526cd8:     	add	x5, x25, #0x2f8
101526cdc:     	bl	0x101525464 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames4copy>
101526ce0:     	ldr	w8, [sp, #0x400]
101526ce4:     	cmp	w8, #0x6
101526ce8:     	b.ne	0x1015273f4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xc90>
101526cec:     	mov	x22, #0x0               ; =0
101526cf0:     	ldr	x9, [sp, #0x38]
101526cf4:     	ldr	x8, [x9, #0x20]
101526cf8:     	cbz	x8, 0x101526e34 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6d0>
101526cfc:     	ldr	x23, [x9, #0x18]
101526d00:     	lsl	x24, x8, #2
101526d04:     	b	0x101526d10 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5ac>
101526d08:     	subs	x24, x24, #0x4
101526d0c:     	b.eq	0x101526e34 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6d0>
101526d10:     	ldr	w20, [x23], #0x4
101526d14:     	ldr	x1, [x25, #0x3c0]
101526d18:     	add	x0, sp, #0x400
101526d1c:     	add	x2, x27, #0x4d8
101526d20:     	add	x4, x25, #0x2f8
101526d24:     	mov	x3, x20
101526d28:     	bl	0x101525edc <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire>
101526d2c:     	ldr	w9, [sp, #0x400]
101526d30:     	ldrb	w8, [sp, #0x404]
101526d34:     	cmp	w9, #0x6
101526d38:     	b.ne	0x101526e94 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x730>
101526d3c:     	tbnz	w8, #0x0, 0x101526d08 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5a4>
101526d40:     	add	x8, sp, #0x400
101526d44:     	add	x0, x25, #0xf0
101526d48:     	add	x2, x25, #0x2f8
101526d4c:     	mov	x1, x20
101526d50:     	bl	0x101542ccc <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena14retire_current>
101526d54:     	ldrb	w8, [sp, #0x400]
101526d58:     	cmp	w8, #0x14
101526d5c:     	b.eq	0x101526d08 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5a4>
101526d60:     	ldr	q0, [sp, #0x400]
101526d64:     	ldr	q1, [sp, #0x410]
101526d68:     	stp	q0, q1, [sp, #0x2f0]
101526d6c:     	ldr	q2, [sp, #0x420]
101526d70:     	str	q2, [sp, #0x310]
101526d74:     	ldr	x8, [sp, #0x430]
101526d78:     	str	x8, [sp, #0x320]
101526d7c:     	stur	q0, [x26, #0x4]
101526d80:     	stur	q1, [x26, #0x14]
101526d84:     	stur	q2, [x26, #0x24]
101526d88:     	stur	x8, [x26, #0x34]
101526d8c:     	mov	w8, #0x2                ; =2
101526d90:     	ldr	x9, [sp, #0x40]
101526d94:     	str	w8, [x9]
101526d98:     	ldr	q0, [sp, #0x400]
101526d9c:     	ldr	q1, [sp, #0x410]
101526da0:     	stur	q0, [x9, #0x4]
101526da4:     	stur	q1, [x9, #0x14]
101526da8:     	ldr	q0, [sp, #0x420]
101526dac:     	stur	q0, [x9, #0x24]
101526db0:     	ldur	q0, [x26, #0x2c]
101526db4:     	str	q0, [x9, #0x30]
101526db8:     	b	0x101526ad0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
101526dbc:     	ldp	x28, x25, [x26]
101526dc0:     	cmp	x28, #0x2
101526dc4:     	sbcs	xzr, x25, xzr
101526dc8:     	b.hs	0x101526e10 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6ac>
101526dcc:     	ldr	x8, [x26, #0x128]
101526dd0:     	cmp	x8, #0x2
101526dd4:     	b.ne	0x101526e10 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6ac>
101526dd8:     	ldr	x8, [x26, #0x120]
101526ddc:     	ldr	w22, [x8]
101526de0:     	ldr	x8, [sp, #0x38]
101526de4:     	ldr	w8, [x8, #0x4]
101526de8:     	cmp	w22, w8
101526dec:     	b.ne	0x101526e10 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6ac>
101526df0:     	ldr	w24, [x26, #0x130]
101526df4:     	ldr	x8, [sp, #0x38]
101526df8:     	ldr	w8, [x8, #0x8]
101526dfc:     	cmp	w24, w8
101526e00:     	b.ne	0x101526e10 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6ac>
101526e04:     	ldr	x8, [x26, #0x10]
101526e08:     	cmp	x8, #0xb
101526e0c:     	b.eq	0x101526b78 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x414>
101526e10:     	ldr	x10, [sp, #0x40]
101526e14:     	str	wzr, [x10]
101526e18:     	mov	w8, #0xc                ; =12
101526e1c:     	strb	w8, [x10, #0x8]
101526e20:     	adrp	x8, 0x107752000 <_anon.45e389ad4f82eaa9758c115126120daa.142+0x1162>
101526e24:     	add	x8, x8, #0xc43
101526e28:     	mov	w9, #0x2b               ; =43
101526e2c:     	stp	x8, x9, [x10, #0x10]
101526e30:     	b	0x101526ad0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
101526e34:     	ldr	x9, [sp, #0x40]
101526e38:     	stp	x22, x21, [x9, #0x8]
101526e3c:     	mov	w8, #0x6                ; =6
101526e40:     	str	w8, [x9]
101526e44:     	b	0x101526ad0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
101526e48:     	ldr	x1, [x27, #0x400]
101526e4c:     	cmp	x20, x1
101526e50:     	b.hs	0x101527aec <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1388>
101526e54:     	ldr	x8, [x27, #0x3f8]
101526e58:     	mov	w9, #0x1f0              ; =496
101526e5c:     	madd	x28, x20, x9, x8
101526e60:     	ldp	x9, x8, [x28]
101526e64:     	eor	x9, x9, #0x2
101526e68:     	orr	x8, x9, x8
101526e6c:     	ldr	x19, [sp, #0x40]
101526e70:     	cbnz	x8, 0x101526ecc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x768>
101526e74:     	str	wzr, [x19]
101526e78:     	mov	w8, #0xc                ; =12
101526e7c:     	adrp	x9, 0x107750000 <_anon.99dc88c6b0d3d7e47e3fc43c7734dd3a.287+0xa0>
101526e80:     	add	x9, x9, #0xad5
101526e84:     	stp	x8, x9, [x19, #0x8]
101526e88:     	mov	w8, #0x23               ; =35
101526e8c:     	str	x8, [x19, #0x18]
101526e90:     	b	0x101526ad0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
101526e94:     	ldur	q0, [x26, #0x15]
101526e98:     	ldr	x10, [sp, #0x40]
101526e9c:     	stur	q0, [x10, #0x15]
101526ea0:     	ldur	q0, [x26, #0x25]
101526ea4:     	stur	q0, [x10, #0x25]
101526ea8:     	ldur	q0, [x26, #0x35]
101526eac:     	stur	q0, [x10, #0x35]
101526eb0:     	ldr	q0, [sp, #0x440]
101526eb4:     	str	q0, [x10, #0x40]
101526eb8:     	ldur	q0, [x26, #0x5]
101526ebc:     	stur	q0, [x10, #0x5]
101526ec0:     	str	w9, [x10]
101526ec4:     	strb	w8, [x10, #0x4]
101526ec8:     	b	0x101526ad0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
101526ecc:     	add	x24, sp, #0x400
101526ed0:     	add	x8, sp, #0x400
101526ed4:     	mov	x0, x21
101526ed8:     	mov	w1, #0x0                ; =0
101526edc:     	bl	0x1015491f8 <__RNvMs_NtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
101526ee0:     	ldr	w8, [sp, #0x400]
101526ee4:     	tbz	w8, #0x0, 0x101526f18 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x7b4>
101526ee8:     	ldur	q0, [x24, #0x18]
101526eec:     	ldur	q1, [x24, #0x28]
101526ef0:     	ldur	q2, [x24, #0x38]
101526ef4:     	stp	q1, q2, [sp, #0x310]
101526ef8:     	ldur	q3, [x24, #0x48]
101526efc:     	str	q3, [sp, #0x330]
101526f00:     	ldur	q4, [x24, #0x8]
101526f04:     	stp	q4, q0, [sp, #0x2f0]
101526f08:     	stp	q1, q2, [x19, #0x20]
101526f0c:     	str	q3, [x19, #0x40]
101526f10:     	stp	q4, q0, [x19]
101526f14:     	b	0x101526ad0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
101526f18:     	ldr	x10, [sp, #0x30]
101526f1c:     	ldr	x8, [sp, #0x18]
101526f20:     	add	x8, x10, x8
101526f24:     	ldur	q0, [x24, #0x48]
101526f28:     	ldur	q1, [x24, #0x58]
101526f2c:     	stp	q0, q1, [sp, #0x330]
101526f30:     	ldur	x9, [x24, #0x68]
101526f34:     	str	x9, [sp, #0x350]
101526f38:     	ldur	q2, [x24, #0x8]
101526f3c:     	str	q2, [sp, #0x2f0]
101526f40:     	ldur	q3, [x24, #0x38]
101526f44:     	ldur	q4, [x24, #0x18]
101526f48:     	ldur	q5, [x24, #0x28]
101526f4c:     	stp	q2, q4, [sp, #0x90]
101526f50:     	stp	q5, q3, [sp, #0xb0]
101526f54:     	str	x9, [sp, #0xf0]
101526f58:     	stp	q0, q1, [sp, #0xd0]
101526f5c:     	str	x10, [sp, #0x400]
101526f60:     	str	x8, [sp, #0x408]
101526f64:     	add	x0, sp, #0x400
101526f68:     	add	x1, x27, #0x490
101526f6c:     	bl	0x101521d64 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_>
101526f70:     	ldr	x25, [x21, #0x490]
101526f74:     	ldr	x2, [x25, #0xd8]
101526f78:     	cmp	x22, x2
101526f7c:     	add	x26, sp, #0x400
101526f80:     	tbz	w0, #0x0, 0x1015270b8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x954>
101526f84:     	b.hi	0x101527a24 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12c0>
101526f88:     	ldr	x1, [x25, #0xd0]
101526f8c:     	ldp	q0, q1, [x21, #0x80]
101526f90:     	str	q0, [sp, #0x480]
101526f94:     	str	q1, [sp, #0x490]
101526f98:     	ldr	x8, [x21, #0xa0]
101526f9c:     	str	x8, [sp, #0x4a0]
101526fa0:     	ldp	q0, q1, [x21, #0x40]
101526fa4:     	str	q0, [sp, #0x440]
101526fa8:     	str	q1, [sp, #0x450]
101526fac:     	ldp	q1, q0, [x21, #0x60]
101526fb0:     	str	q0, [sp, #0x470]
101526fb4:     	str	q1, [sp, #0x460]
101526fb8:     	ldp	q0, q1, [x21]
101526fbc:     	str	q0, [sp, #0x400]
101526fc0:     	str	q1, [sp, #0x410]
101526fc4:     	ldp	q1, q0, [x21, #0x20]
101526fc8:     	add	x8, x25, #0x3b8
101526fcc:     	str	q0, [sp, #0x430]
101526fd0:     	str	q1, [sp, #0x420]
101526fd4:     	add	x9, sp, #0x90
101526fd8:     	stp	x8, x9, [sp, #0x8]
101526fdc:     	add	x9, sp, #0x400
101526fe0:     	str	x9, [sp]
101526fe4:     	add	x8, sp, #0xf8
101526fe8:     	add	x5, x25, #0x3c0
101526fec:     	mov	x0, x28
101526ff0:     	mov	x2, x22
101526ff4:     	mov	x3, x23
101526ff8:     	mov	x4, x22
101526ffc:     	mov	x6, #0x0                ; =0
101527000:     	bl	0x1014f38d8 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_>
101527004:     	b	0x101527128 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x9c4>
101527008:     	ldr	x10, [sp, #0x40]
10152700c:     	str	wzr, [x10]
101527010:     	mov	w8, #0xc                ; =12
101527014:     	strb	w8, [x10, #0x8]
101527018:     	adrp	x8, 0x107752000 <_anon.45e389ad4f82eaa9758c115126120daa.142+0x1162>
10152701c:     	add	x8, x8, #0xaa0
101527020:     	b	0x101526e28 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6c4>
101527024:     	ldr	x10, [sp, #0x40]
101527028:     	str	wzr, [x10]
10152702c:     	mov	w8, #0xc                ; =12
101527030:     	adrp	x9, 0x107750000 <_anon.99dc88c6b0d3d7e47e3fc43c7734dd3a.287+0xa0>
101527034:     	add	x9, x9, #0xb1f
101527038:     	stp	x8, x9, [x10, #0x8]
10152703c:     	mov	w8, #0x20               ; =32
101527040:     	str	x8, [x10, #0x18]
101527044:     	b	0x101526ad0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
101527048:     	ldp	q0, q1, [sp, #0x50]
10152704c:     	add	x9, sp, #0x400
101527050:     	stur	q0, [x9, #0x4]
101527054:     	stur	q1, [x9, #0x14]
101527058:     	ldr	q0, [sp, #0x70]
10152705c:     	stur	q0, [x9, #0x24]
101527060:     	ldr	x8, [sp, #0x80]
101527064:     	stur	x8, [x9, #0x34]
101527068:     	ldr	q0, [sp, #0x400]
10152706c:     	ldr	q1, [sp, #0x410]
101527070:     	ldr	x10, [sp, #0x40]
101527074:     	stur	q0, [x10, #0x4]
101527078:     	mov	w8, #0x2                ; =2
10152707c:     	str	w8, [x10]
101527080:     	stur	q1, [x10, #0x14]
101527084:     	ldr	q0, [sp, #0x420]
101527088:     	stur	q0, [x10, #0x24]
10152708c:     	ldur	q0, [x9, #0x2c]
101527090:     	str	q0, [x10, #0x30]
101527094:     	b	0x101526ad0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
101527098:     	ldr	x10, [sp, #0x40]
10152709c:     	str	wzr, [x10]
1015270a0:     	mov	w8, #0xc                ; =12
1015270a4:     	strb	w8, [x10, #0x8]
1015270a8:     	adrp	x8, 0x107752000 <_anon.45e389ad4f82eaa9758c115126120daa.142+0x1162>
1015270ac:     	add	x8, x8, #0xacb
1015270b0:     	mov	w9, #0x2a               ; =42
1015270b4:     	b	0x101526e2c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6c8>
1015270b8:     	b.hi	0x101527a38 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12d4>
1015270bc:     	ldr	x1, [x25, #0xd0]
1015270c0:     	ldp	q0, q1, [x21, #0x80]
1015270c4:     	str	q0, [sp, #0x480]
1015270c8:     	str	q1, [sp, #0x490]
1015270cc:     	ldr	x8, [x21, #0xa0]
1015270d0:     	str	x8, [sp, #0x4a0]
1015270d4:     	ldp	q0, q1, [x21, #0x40]
1015270d8:     	str	q0, [sp, #0x440]
1015270dc:     	str	q1, [sp, #0x450]
1015270e0:     	ldp	q1, q0, [x21, #0x60]
1015270e4:     	str	q0, [sp, #0x470]
1015270e8:     	str	q1, [sp, #0x460]
1015270ec:     	ldp	q0, q1, [x21]
1015270f0:     	str	q0, [sp, #0x400]
1015270f4:     	str	q1, [sp, #0x410]
1015270f8:     	ldp	q1, q0, [x21, #0x20]
1015270fc:     	str	q0, [sp, #0x430]
101527100:     	str	q1, [sp, #0x420]
101527104:     	add	x8, sp, #0xf8
101527108:     	add	x5, sp, #0x400
10152710c:     	add	x6, x25, #0x3b8
101527110:     	add	x7, sp, #0x90
101527114:     	mov	x0, x28
101527118:     	mov	x2, x22
10152711c:     	mov	x3, x23
101527120:     	mov	x4, x22
101527124:     	bl	0x1027fd950 <__RNvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared13buffer_framesNtB6_25NativePreparedLibraryCall24admit_buffer_frame_words>
101527128:     	ldrb	w8, [sp, #0xf8]
10152712c:     	cmp	w8, #0x2e
101527130:     	b.ne	0x1015271d0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xa6c>
101527134:     	ldr	x2, [x25, #0xd8]
101527138:     	cmp	x22, x2
10152713c:     	b.hi	0x101527a4c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e8>
101527140:     	ldr	x6, [x25, #0xd0]
101527144:     	ldp	x4, x8, [sp, #0x30]
101527148:     	ldr	w3, [x8, #0x4]
10152714c:     	add	x8, x25, #0x2f8
101527150:     	stp	x22, x8, [sp, #0x8]
101527154:     	add	x0, sp, #0x400
101527158:     	add	x1, x25, #0x3c0
10152715c:     	add	x2, x27, #0x490
101527160:     	str	x23, [sp]
101527164:     	mov	x5, x22
101527168:     	mov	x7, x22
10152716c:     	bl	0x101525788 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames4pack>
101527170:     	ldr	x2, [x25, #0xd8]
101527174:     	cmp	x22, x2
101527178:     	b.hi	0x101527a78 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1314>
10152717c:     	ldr	x0, [x25, #0xd0]
101527180:     	str	xzr, [sp, #0x2f0]
101527184:     	add	x2, sp, #0x2f0
101527188:     	mov	x1, x22
10152718c:     	bl	0x1014eff44 <__RNvXNtNtCsgDHHaSskbIF_4core5slice10specializeSINtNtB6_6option6OptionNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEINtB2_8SpecFillBI_E9spec_fillCs29QkOtpKx6e_8mech_gpu>
101527190:     	ldr	w8, [sp, #0x400]
101527194:     	cmp	w8, #0x6
101527198:     	b.eq	0x101526cec <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x588>
10152719c:     	ldur	q0, [x26, #0x14]
1015271a0:     	ldr	x9, [sp, #0x40]
1015271a4:     	stur	q0, [x9, #0x14]
1015271a8:     	ldur	q0, [x26, #0x24]
1015271ac:     	stur	q0, [x9, #0x24]
1015271b0:     	ldur	q0, [x26, #0x34]
1015271b4:     	stur	q0, [x9, #0x34]
1015271b8:     	ldr	q0, [sp, #0x440]
1015271bc:     	str	q0, [x9, #0x40]
1015271c0:     	ldur	q0, [x26, #0x4]
1015271c4:     	stur	q0, [x9, #0x4]
1015271c8:     	str	w8, [x9]
1015271cc:     	b	0x101526ad0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
1015271d0:     	ldr	x2, [x25, #0xd8]
1015271d4:     	cmp	x22, x2
1015271d8:     	b.hi	0x101527a60 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12fc>
1015271dc:     	ldr	x0, [x25, #0xd0]
1015271e0:     	str	xzr, [sp, #0x400]
1015271e4:     	add	x2, sp, #0x400
1015271e8:     	mov	x1, x22
1015271ec:     	bl	0x1014eff44 <__RNvXNtNtCsgDHHaSskbIF_4core5slice10specializeSINtNtB6_6option6OptionNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEINtB2_8SpecFillBI_E9spec_fillCs29QkOtpKx6e_8mech_gpu>
1015271f0:     	ldr	x1, [x27, #0x378]
1015271f4:     	cmp	x20, x1
1015271f8:     	b.hs	0x101527afc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1398>
1015271fc:     	ldr	x8, [x27, #0x370]
101527200:     	mov	w9, #0x170              ; =368
101527204:     	madd	x8, x20, x9, x8
101527208:     	ldr	w9, [x8, #0x158]
10152720c:     	add	x10, sp, #0xf8
101527210:     	add	x8, x8, #0x148
101527214:     	ldr	q0, [x8]
101527218:     	ldp	q1, q2, [x10]
10152721c:     	ldr	x11, [sp, #0x40]
101527220:     	stur	q1, [x11, #0x18]
101527224:     	stur	q2, [x11, #0x28]
101527228:     	ldr	q1, [x10, #0x20]
10152722c:     	stur	q1, [x11, #0x38]
101527230:     	ldr	x8, [sp, #0x128]
101527234:     	str	x8, [x11, #0x48]
101527238:     	mov	w8, #0x3                ; =3
10152723c:     	str	w8, [x11]
101527240:     	stur	q0, [x11, #0x4]
101527244:     	str	w9, [x11, #0x14]
101527248:     	b	0x101526ad0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
10152724c:     	ldr	x25, [x21, #0x490]
101527250:     	ldr	x1, [x25, #0x3c0]
101527254:     	add	x0, sp, #0x400
101527258:     	add	x2, x27, #0x490
10152725c:     	add	x5, x25, #0x2f8
101527260:     	mov	x3, x22
101527264:     	mov	x4, x23
101527268:     	bl	0x101526144 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames7project>
10152726c:     	ldr	w8, [sp, #0x400]
101527270:     	cmp	w8, #0x6
101527274:     	b.ne	0x10152736c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xc08>
101527278:     	add	x8, sp, #0x400
10152727c:     	ldur	q0, [x8, #0x38]
101527280:     	ldur	q1, [x8, #0x28]
101527284:     	ldur	q2, [x8, #0x18]
101527288:     	ldur	q3, [x8, #0x8]
10152728c:     	stp	q3, q2, [sp, #0x230]
101527290:     	stp	q1, q0, [sp, #0x250]
101527294:     	ldp	x9, x8, [x26]
101527298:     	mov	w10, #0x1               ; =1
10152729c:     	cmp	x10, x9
1015272a0:     	ngcs	xzr, x8
1015272a4:     	b.lo	0x101527754 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xff0>
1015272a8:     	ldr	x8, [x26, #0x128]
1015272ac:     	cmp	x8, #0x2
1015272b0:     	b.lo	0x101527b1c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13b8>
1015272b4:     	ldr	x8, [x26, #0x120]
1015272b8:     	ldr	w1, [x8, #0x4]
1015272bc:     	mov	w22, #0x1               ; =1
1015272c0:     	add	x8, sp, #0x400
1015272c4:     	add	x0, x25, #0xf0
1015272c8:     	add	x2, x25, #0x2f8
1015272cc:     	bl	0x10154244c <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
1015272d0:     	add	x8, sp, #0x400
1015272d4:     	ldur	q0, [x8, #0x8]
1015272d8:     	ldur	q1, [x8, #0x18]
1015272dc:     	stp	q0, q1, [sp, #0x2b0]
1015272e0:     	ldur	q0, [x8, #0x28]
1015272e4:     	str	q0, [sp, #0x2d0]
1015272e8:     	ldr	x8, [sp, #0x400]
1015272ec:     	ldr	x9, [sp, #0x438]
1015272f0:     	str	x9, [sp, #0x2e0]
1015272f4:     	cbz	x8, 0x10152741c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xcb8>
1015272f8:     	ldp	q0, q1, [sp, #0x2b0]
1015272fc:     	add	x9, sp, #0x230
101527300:     	stur	q0, [x9, #0x48]
101527304:     	stur	q1, [x9, #0x58]
101527308:     	ldr	q0, [sp, #0x2d0]
10152730c:     	add	x26, sp, #0x230
101527310:     	stur	q0, [x9, #0x68]
101527314:     	ldr	x9, [sp, #0x2e0]
101527318:     	str	x9, [sp, #0x2a8]
10152731c:     	str	x8, [sp, #0x270]
101527320:     	ldr	x1, [x27, #0x400]
101527324:     	cmp	x20, x1
101527328:     	b.hs	0x101527b64 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1400>
10152732c:     	ldr	x8, [x27, #0x3f8]
101527330:     	mov	w9, #0x1f0              ; =496
101527334:     	madd	x22, x20, x9, x8
101527338:     	ldp	x9, x8, [x22]
10152733c:     	eor	x9, x9, #0x2
101527340:     	orr	x8, x9, x8
101527344:     	cbnz	x8, 0x10152746c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xd08>
101527348:     	ldr	x10, [sp, #0x40]
10152734c:     	str	wzr, [x10]
101527350:     	mov	w8, #0xc                ; =12
101527354:     	adrp	x9, 0x107750000 <_anon.99dc88c6b0d3d7e47e3fc43c7734dd3a.287+0xa0>
101527358:     	add	x9, x9, #0xb62
10152735c:     	stp	x8, x9, [x10, #0x8]
101527360:     	mov	w8, #0x2a               ; =42
101527364:     	str	x8, [x10, #0x18]
101527368:     	b	0x1015278f4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1190>
10152736c:     	add	x10, sp, #0x400
101527370:     	ldur	q0, [x10, #0x14]
101527374:     	ldur	q1, [x10, #0x24]
101527378:     	ldur	q2, [x10, #0x34]
10152737c:     	stp	q1, q2, [sp, #0x310]
101527380:     	ldr	w9, [sp, #0x444]
101527384:     	str	w9, [sp, #0x330]
101527388:     	ldur	q3, [x10, #0x4]
10152738c:     	stp	q3, q0, [sp, #0x2f0]
101527390:     	ldr	x10, [sp, #0x448]
101527394:     	ldr	x11, [sp, #0x40]
101527398:     	stur	q0, [x11, #0x14]
10152739c:     	stur	q1, [x11, #0x24]
1015273a0:     	stur	q2, [x11, #0x34]
1015273a4:     	str	w9, [x11, #0x44]
1015273a8:     	stur	q3, [x11, #0x4]
1015273ac:     	str	w8, [x11]
1015273b0:     	str	x10, [x11, #0x48]
1015273b4:     	b	0x101526ad0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
1015273b8:     	ldr	x25, [x21, #0x490]
1015273bc:     	add	x0, sp, #0x400
1015273c0:     	add	x1, x25, #0x3c0
1015273c4:     	add	x2, x27, #0x490
1015273c8:     	add	x6, x25, #0x2f8
1015273cc:     	mov	x3, x22
1015273d0:     	mov	x4, x23
1015273d4:     	mov	x5, x24
1015273d8:     	bl	0x1015247f8 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames17project_composite>
1015273dc:     	ldr	w8, [sp, #0x400]
1015273e0:     	cmp	w8, #0x6
1015273e4:     	b.ne	0x1015273f4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xc90>
1015273e8:     	mov	x22, #0x0               ; =0
1015273ec:     	add	x26, sp, #0x400
1015273f0:     	b	0x101526cf0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x58c>
1015273f4:     	ldr	q0, [sp, #0x420]
1015273f8:     	ldr	q1, [sp, #0x430]
1015273fc:     	ldr	x8, [sp, #0x40]
101527400:     	stp	q0, q1, [x8, #0x20]
101527404:     	ldr	q0, [sp, #0x440]
101527408:     	str	q0, [x8, #0x40]
10152740c:     	ldr	q0, [sp, #0x410]
101527410:     	ldr	q1, [sp, #0x400]
101527414:     	stp	q1, q0, [x8]
101527418:     	b	0x101526ad0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
10152741c:     	ldp	q0, q1, [sp, #0x2b0]
101527420:     	add	x9, sp, #0x400
101527424:     	stur	q0, [x9, #0x4]
101527428:     	stur	q1, [x9, #0x14]
10152742c:     	ldr	q0, [sp, #0x2d0]
101527430:     	stur	q0, [x9, #0x24]
101527434:     	ldr	x8, [sp, #0x2e0]
101527438:     	stur	x8, [x9, #0x34]
10152743c:     	ldr	q0, [sp, #0x400]
101527440:     	ldr	q1, [sp, #0x410]
101527444:     	ldr	x10, [sp, #0x40]
101527448:     	stur	q0, [x10, #0x4]
10152744c:     	mov	w8, #0x2                ; =2
101527450:     	str	w8, [x10]
101527454:     	stur	q1, [x10, #0x14]
101527458:     	ldr	q0, [sp, #0x420]
10152745c:     	stur	q0, [x10, #0x24]
101527460:     	ldur	q0, [x9, #0x2c]
101527464:     	str	q0, [x10, #0x30]
101527468:     	b	0x101527900 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x119c>
10152746c:     	add	x24, sp, #0x400
101527470:     	add	x8, sp, #0x400
101527474:     	mov	x0, x21
101527478:     	mov	w1, #0x0                ; =0
10152747c:     	bl	0x1015491f8 <__RNvMs_NtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
101527480:     	ldr	x8, [sp, #0x400]
101527484:     	cmp	x8, #0x1
101527488:     	b.ne	0x101527534 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xdd0>
10152748c:     	ldur	q0, [x24, #0x18]
101527490:     	ldur	q1, [x24, #0x28]
101527494:     	ldur	q2, [x24, #0x38]
101527498:     	stp	q1, q2, [sp, #0x310]
10152749c:     	ldur	q3, [x24, #0x48]
1015274a0:     	str	q3, [sp, #0x330]
1015274a4:     	ldur	q4, [x24, #0x8]
1015274a8:     	stp	q4, q0, [sp, #0x2f0]
1015274ac:     	ldr	x8, [sp, #0x40]
1015274b0:     	stp	q1, q2, [x8, #0x20]
1015274b4:     	str	q3, [x8, #0x40]
1015274b8:     	stp	q4, q0, [x8]
1015274bc:     	b	0x1015278f4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1190>
1015274c0:     	ldp	q0, q1, [sp, #0x150]
1015274c4:     	add	x9, sp, #0x400
1015274c8:     	stur	q0, [x9, #0x4]
1015274cc:     	stur	q1, [x9, #0x14]
1015274d0:     	ldr	q0, [sp, #0x170]
1015274d4:     	stur	q0, [x9, #0x24]
1015274d8:     	ldr	x8, [sp, #0x180]
1015274dc:     	b	0x101527064 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x900>
1015274e0:     	add	x24, sp, #0x400
1015274e4:     	add	x8, sp, #0x400
1015274e8:     	mov	x0, x21
1015274ec:     	mov	w1, #0x0                ; =0
1015274f0:     	bl	0x1015491f8 <__RNvMs_NtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
1015274f4:     	ldr	x8, [sp, #0x400]
1015274f8:     	cmp	x8, #0x1
1015274fc:     	b.ne	0x1015275e0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xe7c>
101527500:     	ldur	q0, [x24, #0x18]
101527504:     	ldur	q1, [x24, #0x28]
101527508:     	ldur	q2, [x24, #0x38]
10152750c:     	stp	q1, q2, [sp, #0x310]
101527510:     	ldur	q3, [x24, #0x48]
101527514:     	str	q3, [sp, #0x330]
101527518:     	ldur	q4, [x24, #0x8]
10152751c:     	stp	q4, q0, [sp, #0x2f0]
101527520:     	ldr	x8, [sp, #0x40]
101527524:     	stp	q1, q2, [x8, #0x20]
101527528:     	str	q3, [x8, #0x40]
10152752c:     	stp	q4, q0, [x8]
101527530:     	b	0x101527968 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1204>
101527534:     	ldur	q0, [x24, #0x48]
101527538:     	ldur	q1, [x24, #0x58]
10152753c:     	stp	q0, q1, [sp, #0x330]
101527540:     	ldur	x8, [x24, #0x68]
101527544:     	str	x8, [sp, #0x350]
101527548:     	ldur	q2, [x24, #0x8]
10152754c:     	ldur	q3, [x24, #0x18]
101527550:     	stp	q2, q3, [sp, #0x2f0]
101527554:     	ldur	q4, [x24, #0x38]
101527558:     	ldur	q5, [x24, #0x28]
10152755c:     	stp	q2, q3, [sp, #0x360]
101527560:     	stp	q5, q4, [sp, #0x380]
101527564:     	str	x8, [sp, #0x3c0]
101527568:     	stp	q0, q1, [sp, #0x3a0]
10152756c:     	ldr	x8, [sp, #0x230]
101527570:     	cbz	x8, 0x1015276c8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xf64>
101527574:     	ldp	q0, q1, [x21, #0x80]
101527578:     	str	q0, [sp, #0x480]
10152757c:     	str	q1, [sp, #0x490]
101527580:     	ldr	x8, [x21, #0xa0]
101527584:     	str	x8, [sp, #0x4a0]
101527588:     	ldp	q0, q1, [x21, #0x40]
10152758c:     	str	q0, [sp, #0x440]
101527590:     	str	q1, [sp, #0x450]
101527594:     	ldp	q1, q0, [x21, #0x60]
101527598:     	str	q0, [sp, #0x470]
10152759c:     	str	q1, [sp, #0x460]
1015275a0:     	ldp	q0, q1, [x21]
1015275a4:     	str	q0, [sp, #0x400]
1015275a8:     	str	q1, [sp, #0x410]
1015275ac:     	ldp	q1, q0, [x21, #0x20]
1015275b0:     	str	q0, [sp, #0x430]
1015275b4:     	str	q1, [sp, #0x420]
1015275b8:     	add	x8, sp, #0x3c8
1015275bc:     	add	x1, sp, #0x270
1015275c0:     	add	x3, sp, #0x230
1015275c4:     	add	x4, sp, #0x400
1015275c8:     	add	x5, x25, #0x3b8
1015275cc:     	add	x6, sp, #0x360
1015275d0:     	mov	x0, x22
1015275d4:     	mov	x2, x23
1015275d8:     	bl	0x1027fdcf4 <__RNvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared13buffer_framesNtB6_25NativePreparedLibraryCall25admit_buffer_record_field>
1015275dc:     	b	0x10152773c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xfd8>
1015275e0:     	ldur	q0, [x24, #0x48]
1015275e4:     	ldur	q1, [x24, #0x58]
1015275e8:     	stp	q0, q1, [sp, #0x330]
1015275ec:     	ldur	x8, [x24, #0x68]
1015275f0:     	str	x8, [sp, #0x350]
1015275f4:     	ldur	q2, [x24, #0x8]
1015275f8:     	ldur	q3, [x24, #0x18]
1015275fc:     	stp	q2, q3, [sp, #0x2f0]
101527600:     	ldur	q4, [x24, #0x38]
101527604:     	ldur	q5, [x24, #0x28]
101527608:     	stp	q2, q3, [sp, #0x190]
10152760c:     	stp	q5, q4, [sp, #0x1b0]
101527610:     	str	x8, [sp, #0x1f0]
101527614:     	stp	q0, q1, [sp, #0x1d0]
101527618:     	ldr	x8, [sp, #0x38]
10152761c:     	ldr	x7, [x8, #0x10]
101527620:     	ldp	q0, q1, [x21, #0x80]
101527624:     	str	q0, [sp, #0x480]
101527628:     	str	q1, [sp, #0x490]
10152762c:     	ldr	x8, [x21, #0xa0]
101527630:     	str	x8, [sp, #0x4a0]
101527634:     	ldp	q0, q1, [x21, #0x40]
101527638:     	str	q0, [sp, #0x440]
10152763c:     	str	q1, [sp, #0x450]
101527640:     	ldp	q1, q0, [x21, #0x60]
101527644:     	str	q0, [sp, #0x470]
101527648:     	str	q1, [sp, #0x460]
10152764c:     	ldp	q0, q1, [x21]
101527650:     	str	q0, [sp, #0x400]
101527654:     	str	q1, [sp, #0x410]
101527658:     	ldp	q1, q0, [x21, #0x20]
10152765c:     	add	x8, x25, #0x3b8
101527660:     	str	q0, [sp, #0x430]
101527664:     	str	q1, [sp, #0x420]
101527668:     	add	x9, sp, #0x190
10152766c:     	stp	x8, x9, [sp, #0x8]
101527670:     	add	x9, sp, #0x400
101527674:     	adrp	x1, 0x107752000 <_anon.45e389ad4f82eaa9758c115126120daa.142+0x1162>
101527678:     	add	x1, x1, #0xb70
10152767c:     	str	x9, [sp]
101527680:     	add	x8, sp, #0x1f8
101527684:     	add	x5, x25, #0x3c0
101527688:     	add	x6, sp, #0x270
10152768c:     	adrp	x3, 0x107755000 <_anon.45e389ad4f82eaa9758c115126120daa.908+0x91>
101527690:     	add	x3, x3, #0xf90
101527694:     	mov	x0, x23
101527698:     	mov	w2, #0x2                ; =2
10152769c:     	mov	w4, #0x2                ; =2
1015276a0:     	bl	0x1014f3b24 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_>
1015276a4:     	ldrb	w8, [sp, #0x1f8]
1015276a8:     	cmp	w8, #0x2e
1015276ac:     	b.ne	0x10152792c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x11c8>
1015276b0:     	add	x0, sp, #0x270
1015276b4:     	bl	0x10151e1a8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015276b8:     	ldr	x8, [sp, #0x38]
1015276bc:     	ldr	x23, [x8, #0x10]
1015276c0:     	ldr	w24, [x8, #0x8]
1015276c4:     	b	0x1015273bc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xc58>
1015276c8:     	ldr	w3, [sp, #0x248]
1015276cc:     	ldur	q0, [x26, #0x8]
1015276d0:     	str	q0, [sp, #0x2f0]
1015276d4:     	ldp	q0, q1, [x21, #0x80]
1015276d8:     	str	q0, [sp, #0x480]
1015276dc:     	str	q1, [sp, #0x490]
1015276e0:     	ldr	x8, [x21, #0xa0]
1015276e4:     	str	x8, [sp, #0x4a0]
1015276e8:     	ldp	q0, q1, [x21, #0x40]
1015276ec:     	str	q0, [sp, #0x440]
1015276f0:     	str	q1, [sp, #0x450]
1015276f4:     	ldp	q1, q0, [x21, #0x60]
1015276f8:     	str	q0, [sp, #0x470]
1015276fc:     	str	q1, [sp, #0x460]
101527700:     	ldp	q0, q1, [x21]
101527704:     	str	q0, [sp, #0x400]
101527708:     	str	q1, [sp, #0x410]
10152770c:     	ldp	q1, q0, [x21, #0x20]
101527710:     	str	q0, [sp, #0x430]
101527714:     	str	q1, [sp, #0x420]
101527718:     	add	x8, sp, #0x3c8
10152771c:     	add	x1, sp, #0x270
101527720:     	add	x4, sp, #0x2f0
101527724:     	add	x5, sp, #0x400
101527728:     	add	x6, x25, #0x3b8
10152772c:     	add	x7, sp, #0x360
101527730:     	mov	x0, x22
101527734:     	mov	x2, x23
101527738:     	bl	0x1027fd9ac <__RNvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared13buffer_framesNtB6_25NativePreparedLibraryCall24admit_buffer_record_word>
10152773c:     	ldrb	w8, [sp, #0x3c8]
101527740:     	cmp	w8, #0x2e
101527744:     	b.ne	0x1015278b8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1154>
101527748:     	mov	w22, #0x1               ; =1
10152774c:     	add	x0, sp, #0x270
101527750:     	bl	0x10151e1a8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
101527754:     	ldr	x8, [x27, #0x358]
101527758:     	ldr	x9, [sp, #0x38]
10152775c:     	ldr	w1, [x9, #0x8]
101527760:     	cmp	x8, x1
101527764:     	b.ls	0x101527b10 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13ac>
101527768:     	ldr	x8, [x27, #0x350]
10152776c:     	mov	w9, #0x140              ; =320
101527770:     	umaddl	x9, w1, w9, x8
101527774:     	ldr	x8, [sp, #0x230]
101527778:     	cbz	x8, 0x10152785c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x10f8>
10152777c:     	ldp	q0, q1, [sp, #0x230]
101527780:     	str	q0, [sp, #0x400]
101527784:     	str	q1, [sp, #0x410]
101527788:     	ldp	q0, q1, [sp, #0x250]
10152778c:     	str	q0, [sp, #0x420]
101527790:     	str	q1, [sp, #0x430]
101527794:     	ldr	x8, [x27, #0x450]
101527798:     	cmp	x8, x1
10152779c:     	b.ls	0x101527b3c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13d8>
1015277a0:     	ldr	x8, [x27, #0x448]
1015277a4:     	mov	w10, #0x24              ; =36
1015277a8:     	umaddl	x8, w1, w10, x8
1015277ac:     	ldr	w10, [sp, #0x438]
1015277b0:     	ldr	w11, [x8, #0x20]
1015277b4:     	cmp	w10, w11
1015277b8:     	b.ne	0x10152782c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x10c8>
1015277bc:     	ldp	q0, q1, [sp, #0x240]
1015277c0:     	stp	q0, q1, [sp, #0x2f0]
1015277c4:     	ldr	x10, [sp, #0x2f0]
1015277c8:     	ldr	x11, [sp, #0x2f8]
1015277cc:     	ldp	x12, x13, [x8]
1015277d0:     	ldr	x14, [sp, #0x300]
1015277d4:     	ldr	x15, [sp, #0x308]
1015277d8:     	ldp	x16, x8, [x8, #0x10]
1015277dc:     	cmp	x10, x12
1015277e0:     	ccmp	x11, x13, #0x0, eq
1015277e4:     	ccmp	x14, x16, #0x0, eq
1015277e8:     	ccmp	x15, x8, #0x0, eq
1015277ec:     	b.ne	0x10152782c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x10c8>
1015277f0:     	ldrb	w8, [x9, #0x124]
1015277f4:     	cmp	w8, #0x7
1015277f8:     	b.ne	0x10152782c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x10c8>
1015277fc:     	add	x8, sp, #0x2f0
101527800:     	add	x0, x25, #0xf0
101527804:     	add	x2, sp, #0x400
101527808:     	add	x3, x25, #0x2f8
10152780c:     	bl	0x101543f54 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena3put>
101527810:     	ldrb	w8, [sp, #0x2f0]
101527814:     	cmp	w8, #0x14
101527818:     	b.ne	0x101527974 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1210>
10152781c:     	mov	w22, #0x0               ; =0
101527820:     	add	x0, sp, #0x400
101527824:     	bl	0x10151e1a8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
101527828:     	b	0x1015273e8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xc84>
10152782c:     	ldr	x10, [sp, #0x40]
101527830:     	str	wzr, [x10]
101527834:     	mov	w8, #0xc                ; =12
101527838:     	strb	w8, [x10, #0x8]
10152783c:     	adrp	x8, 0x107752000 <_anon.45e389ad4f82eaa9758c115126120daa.142+0x1162>
101527840:     	add	x8, x8, #0xc19
101527844:     	mov	w9, #0x2a               ; =42
101527848:     	stp	x8, x9, [x10, #0x10]
10152784c:     	mov	w22, #0x0               ; =0
101527850:     	add	x0, sp, #0x400
101527854:     	bl	0x10151e1a8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
101527858:     	b	0x101526ad0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
10152785c:     	ldr	w8, [sp, #0x248]
101527860:     	ldr	w10, [x9, #0x130]
101527864:     	cmp	w8, w10
101527868:     	b.ne	0x101527a04 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12a0>
10152786c:     	ldrb	w8, [sp, #0x239]
101527870:     	ldr	x21, [sp, #0x240]
101527874:     	ldrb	w10, [sp, #0x238]
101527878:     	ldrb	w9, [x9, #0x124]
10152787c:     	cmp	w10, #0x2
101527880:     	b.le	0x1015278a0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x113c>
101527884:     	cmp	w10, #0x4
101527888:     	b.gt	0x101527914 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x11b0>
10152788c:     	cmp	w10, #0x3
101527890:     	b.ne	0x1015279d4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1270>
101527894:     	cmp	w9, #0x3
101527898:     	b.eq	0x1015279f8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1294>
10152789c:     	b	0x101527a04 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12a0>
1015278a0:     	cbz	w10, 0x1015279bc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1258>
1015278a4:     	cmp	w10, #0x1
1015278a8:     	b.ne	0x1015279c8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1264>
1015278ac:     	cmp	w9, #0x1
1015278b0:     	b.eq	0x1015279f8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1294>
1015278b4:     	b	0x101527a04 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12a0>
1015278b8:     	ldr	x1, [x27, #0x370]
1015278bc:     	ldr	x2, [x27, #0x378]
1015278c0:     	add	x0, sp, #0x400
1015278c4:     	add	x4, sp, #0x3c8
1015278c8:     	mov	x3, x20
1015278cc:     	bl	0x101522540 <__RNCNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions8_0Be_>
1015278d0:     	ldr	q0, [sp, #0x420]
1015278d4:     	ldr	q1, [sp, #0x430]
1015278d8:     	ldr	x8, [sp, #0x40]
1015278dc:     	stp	q0, q1, [x8, #0x20]
1015278e0:     	ldr	q0, [sp, #0x440]
1015278e4:     	str	q0, [x8, #0x40]
1015278e8:     	ldr	q0, [sp, #0x410]
1015278ec:     	ldr	q1, [sp, #0x400]
1015278f0:     	stp	q1, q0, [x8]
1015278f4:     	mov	w22, #0x1               ; =1
1015278f8:     	add	x0, sp, #0x270
1015278fc:     	bl	0x10151e1a8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
101527900:     	ldr	x8, [sp, #0x230]
101527904:     	cbz	x8, 0x101526ad0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
101527908:     	add	x0, sp, #0x230
10152790c:     	bl	0x10151e1a8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
101527910:     	b	0x101526ad0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
101527914:     	cmp	w10, #0x5
101527918:     	b.ne	0x1015279ec <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1288>
10152791c:     	cmp	w9, #0x5
101527920:     	b.ne	0x101527a04 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12a0>
101527924:     	ldrh	w21, [sp, #0x23a]
101527928:     	b	0x1015279f8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1294>
10152792c:     	ldr	x1, [x27, #0x370]
101527930:     	ldr	x2, [x27, #0x378]
101527934:     	add	x0, sp, #0x400
101527938:     	add	x4, sp, #0x1f8
10152793c:     	mov	x3, x20
101527940:     	bl	0x1015224ac <__RNCNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions6_0Be_>
101527944:     	ldr	q0, [sp, #0x420]
101527948:     	ldr	q1, [sp, #0x430]
10152794c:     	ldr	x8, [sp, #0x40]
101527950:     	stp	q0, q1, [x8, #0x20]
101527954:     	ldr	q0, [sp, #0x440]
101527958:     	str	q0, [x8, #0x40]
10152795c:     	ldr	q0, [sp, #0x410]
101527960:     	ldr	q1, [sp, #0x400]
101527964:     	stp	q1, q0, [x8]
101527968:     	add	x0, sp, #0x270
10152796c:     	bl	0x10151e1a8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
101527970:     	b	0x101526ad0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x36c>
101527974:     	add	x10, sp, #0x230
101527978:     	ldur	w9, [x10, #0xc1]
10152797c:     	ldr	x11, [sp, #0x40]
101527980:     	stur	w9, [x11, #0x9]
101527984:     	ldr	w9, [sp, #0x2f4]
101527988:     	str	w9, [x11, #0xc]
10152798c:     	ldr	q0, [sp, #0x310]
101527990:     	stur	q0, [x11, #0x28]
101527994:     	ldr	x9, [sp, #0x320]
101527998:     	str	x9, [x11, #0x38]
10152799c:     	ldr	d0, [sp, #0x308]
1015279a0:     	ldur	q1, [x10, #0xc8]
1015279a4:     	mov	w9, #0x2                ; =2
1015279a8:     	str	w9, [x11]
1015279ac:     	strb	w8, [x11, #0x8]
1015279b0:     	str	q1, [x11, #0x10]
1015279b4:     	str	d0, [x11, #0x20]
1015279b8:     	b	0x10152784c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x10e8>
1015279bc:     	cbnz	w9, 0x101527a04 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12a0>
1015279c0:     	and	x21, x8, #0x1
1015279c4:     	b	0x1015279f8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1294>
1015279c8:     	cmp	w9, #0x2
1015279cc:     	b.eq	0x1015279f8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1294>
1015279d0:     	b	0x101527a04 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12a0>
1015279d4:     	cmp	w9, #0x4
1015279d8:     	b.ne	0x101527a04 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12a0>
1015279dc:     	mov	w22, #0x1               ; =1
1015279e0:     	mov	x21, x8
1015279e4:     	add	x26, sp, #0x400
1015279e8:     	b	0x101526cf0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x58c>
1015279ec:     	cmp	w9, #0x6
1015279f0:     	b.ne	0x101527a04 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12a0>
1015279f4:     	ldr	w21, [sp, #0x23c]
1015279f8:     	mov	w22, #0x1               ; =1
1015279fc:     	add	x26, sp, #0x400
101527a00:     	b	0x101526cf0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x58c>
101527a04:     	ldr	x10, [sp, #0x40]
101527a08:     	str	wzr, [x10]
101527a0c:     	mov	w8, #0xc                ; =12
101527a10:     	strb	w8, [x10, #0x8]
101527a14:     	adrp	x8, 0x107752000 <_anon.45e389ad4f82eaa9758c115126120daa.142+0x1162>
101527a18:     	add	x8, x8, #0xbf0
101527a1c:     	mov	w9, #0x29               ; =41
101527a20:     	b	0x101526e2c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6c8>
101527a24:     	adrp	x3, 0x10810c000 <_anon.45e389ad4f82eaa9758c115126120daa.251+0x50>
101527a28:     	add	x3, x3, #0x4f8
101527a2c:     	mov	x0, #0x0                ; =0
101527a30:     	mov	x1, x22
101527a34:     	bl	0x103c06308 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
101527a38:     	adrp	x3, 0x10810c000 <_anon.45e389ad4f82eaa9758c115126120daa.251+0x50>
101527a3c:     	add	x3, x3, #0x480
101527a40:     	mov	x0, #0x0                ; =0
101527a44:     	mov	x1, x22
101527a48:     	bl	0x103c06308 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
101527a4c:     	adrp	x3, 0x10810c000 <_anon.45e389ad4f82eaa9758c115126120daa.251+0x50>
101527a50:     	add	x3, x3, #0x4e0
101527a54:     	mov	x0, #0x0                ; =0
101527a58:     	mov	x1, x22
101527a5c:     	bl	0x103c06308 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
101527a60:     	adrp	x3, 0x10810c000 <_anon.45e389ad4f82eaa9758c115126120daa.251+0x50>
101527a64:     	add	x3, x3, #0x4b0
101527a68:     	mov	x0, #0x0                ; =0
101527a6c:     	mov	x1, x22
101527a70:     	bl	0x103c06308 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
101527a74:     	b	0x101527b88 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1424>
101527a78:     	adrp	x3, 0x10810c000 <_anon.45e389ad4f82eaa9758c115126120daa.251+0x50>
101527a7c:     	add	x3, x3, #0x4c8
101527a80:     	mov	x0, #0x0                ; =0
101527a84:     	mov	x1, x22
101527a88:     	bl	0x103c06308 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
101527a8c:     	b	0x101527b88 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1424>
101527a90:     	adrp	x2, 0x10810c000 <_anon.45e389ad4f82eaa9758c115126120daa.251+0x50>
101527a94:     	add	x2, x2, #0x510
101527a98:     	mov	x0, x1
101527a9c:     	mov	x1, x8
101527aa0:     	bl	0x103c06154 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101527aa4:     	adrp	x2, 0x10810c000 <_anon.45e389ad4f82eaa9758c115126120daa.251+0x50>
101527aa8:     	add	x2, x2, #0x450
101527aac:     	mov	x0, x20
101527ab0:     	bl	0x103c06154 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101527ab4:     	adrp	x2, 0x10810c000 <_anon.45e389ad4f82eaa9758c115126120daa.251+0x50>
101527ab8:     	add	x2, x2, #0x528
101527abc:     	mov	x0, x25
101527ac0:     	mov	x1, x22
101527ac4:     	bl	0x103c06154 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101527ac8:     	adrp	x2, 0x10810c000 <_anon.45e389ad4f82eaa9758c115126120daa.251+0x50>
101527acc:     	add	x2, x2, #0x540
101527ad0:     	mov	x0, x25
101527ad4:     	mov	x1, x22
101527ad8:     	bl	0x103c06154 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101527adc:     	adrp	x2, 0x10810c000 <_anon.45e389ad4f82eaa9758c115126120daa.251+0x50>
101527ae0:     	add	x2, x2, #0x570
101527ae4:     	mov	x0, x20
101527ae8:     	bl	0x103c06154 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101527aec:     	adrp	x2, 0x10810c000 <_anon.45e389ad4f82eaa9758c115126120daa.251+0x50>
101527af0:     	add	x2, x2, #0x468
101527af4:     	mov	x0, x20
101527af8:     	bl	0x103c06154 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101527afc:     	adrp	x2, 0x10810c000 <_anon.45e389ad4f82eaa9758c115126120daa.251+0x50>
101527b00:     	add	x2, x2, #0x498
101527b04:     	mov	x0, x20
101527b08:     	bl	0x103c06154 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101527b0c:     	b	0x101527b88 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1424>
101527b10:     	adrp	x2, 0x10810c000 <_anon.45e389ad4f82eaa9758c115126120daa.251+0x50>
101527b14:     	add	x2, x2, #0x5e8
101527b18:     	b	0x101527b28 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13c4>
101527b1c:     	adrp	x2, 0x10810c000 <_anon.45e389ad4f82eaa9758c115126120daa.251+0x50>
101527b20:     	add	x2, x2, #0x5b8
101527b24:     	mov	w1, #0x1                ; =1
101527b28:     	mov	w22, #0x1               ; =1
101527b2c:     	mov	x0, x1
101527b30:     	mov	x1, x8
101527b34:     	bl	0x103c06154 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101527b38:     	b	0x101527b88 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1424>
101527b3c:     	adrp	x2, 0x10810c000 <_anon.45e389ad4f82eaa9758c115126120daa.251+0x50>
101527b40:     	add	x2, x2, #0x600
101527b44:     	mov	x0, x1
101527b48:     	mov	x1, x8
101527b4c:     	bl	0x103c06154 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101527b50:     	b	0x101527b88 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1424>
101527b54:     	adrp	x2, 0x10810c000 <_anon.45e389ad4f82eaa9758c115126120daa.251+0x50>
101527b58:     	add	x2, x2, #0x588
101527b5c:     	mov	w0, #0x1                ; =1
101527b60:     	bl	0x103c06154 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101527b64:     	adrp	x2, 0x10810c000 <_anon.45e389ad4f82eaa9758c115126120daa.251+0x50>
101527b68:     	add	x2, x2, #0x5d0
101527b6c:     	mov	x0, x20
101527b70:     	bl	0x103c06154 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101527b74:     	b	0x101527b88 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1424>
101527b78:     	adrp	x2, 0x10810c000 <_anon.45e389ad4f82eaa9758c115126120daa.251+0x50>
101527b7c:     	add	x2, x2, #0x5a0
101527b80:     	mov	x0, x20
101527b84:     	bl	0x103c06154 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101527b88:     	brk	#0x1
101527b8c:     	mov	x19, x0
101527b90:     	add	x0, sp, #0x400
101527b94:     	bl	0x10151e1a8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
101527b98:     	b	0x101527c38 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14d4>
101527b9c:     	mov	x19, x0
101527ba0:     	add	x0, sp, #0x270
101527ba4:     	bl	0x10151e1a8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
101527ba8:     	b	0x101527c38 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14d4>
101527bac:     	mov	x19, x0
101527bb0:     	add	x0, sp, #0x270
101527bb4:     	bl	0x10151e1a8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
101527bb8:     	mov	w22, #0x1               ; =1
101527bbc:     	b	0x101527bc4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1460>
101527bc0:     	mov	x19, x0
101527bc4:     	cbz	w22, 0x101527c38 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14d4>
101527bc8:     	ldr	x8, [sp, #0x230]
101527bcc:     	cbz	x8, 0x101527c38 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14d4>
101527bd0:     	add	x0, sp, #0x230
101527bd4:     	bl	0x10151e1a8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
101527bd8:     	b	0x101527c38 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14d4>
101527bdc:     	add	x8, x28, x26
101527be0:     	ldp	q0, q1, [sp, #0x2f0]
101527be4:     	ldp	q2, q3, [sp, #0x310]
101527be8:     	stp	q2, q3, [x8, #0x20]
101527bec:     	stp	q0, q1, [x8]
101527bf0:     	bl	0x103c07520 <dyld_stub_binder+0x103c07520>
101527bf4:     	mov	x19, x0
101527bf8:     	tbnz	w28, #0x0, 0x101527c38 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14d4>
101527bfc:     	add	x0, sp, #0x2f0
101527c00:     	bl	0x10151e1a8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
101527c04:     	b	0x101527c38 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14d4>
101527c08:     	bl	0x103c0613c <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
101527c0c:     	mov	x19, x0
101527c10:     	ldr	w8, [sp, #0x400]
101527c14:     	cmp	w8, #0x6
101527c18:     	b.eq	0x101527c38 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14d4>
101527c1c:     	add	x0, sp, #0x400
101527c20:     	bl	0x10151eaa8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
101527c24:     	mov	x0, x19
101527c28:     	bl	0x103c07520 <dyld_stub_binder+0x103c07520>
101527c2c:     	mov	x19, x0
101527c30:     	add	x0, sp, #0xf8
101527c34:     	bl	0x10151ed78 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs29QkOtpKx6e_8mech_gpu>
101527c38:     	mov	x0, x19
101527c3c:     	bl	0x103c07520 <dyld_stub_binder+0x103c07520>
