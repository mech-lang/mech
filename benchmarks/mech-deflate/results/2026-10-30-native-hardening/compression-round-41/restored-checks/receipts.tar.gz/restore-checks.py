from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'restored';p.mkdir(exist_ok=False)
b=json.loads(Path('/private/tmp/mech-scalar-child-round39-20261030/unit/build.json').read_text());cmd=b['command'].copy();cmd[-1]=str(p/'gpu-unit-tests')
def run(label,cmd,expect=0,env=None):
 at=time.monotonic();q=subprocess.run(cmd,cwd=w,env={**os.environ,**(env or {})},capture_output=True,text=True);(p/(label+'.stdout')).write_text(q.stdout);(p/(label+'.stderr')).write_text(q.stderr);(p/(label+'.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'environment':env or {},'expected_exit':expect,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()},indent=2)+'\n');print(label,q.returncode,flush=True)
 if q.returncode!=expect:print(q.stdout[-3000:]+q.stderr[-5000:],flush=True)
 assert q.returncode==expect
 return q
run('build',cmd,env=b['environment'])
unit=str(p/'gpu-unit-tests')
q=run('baseline-failure-classification',[unit,'complete_unchanged_knucleotide_body_uses_the_owned_emitted_map','emitted_scanner_uses_no_matrix_and_preserves_owner_over_activation_and_errors','native_structural_map_states_execute_all_seven_counting_widths','worker_abi_keeps_the_frozen_scalar_prefix_and_disjoint_helper_lanes','--nocapture','--test-threads=1'],expect=101)
assert '3 passed; 1 failed;' in q.stdout and 'module stats is not available' in q.stderr
q=run('format',['cargo','+nightly-2026-03-03','fmt','--all','--','--check'])
run('diff',['git','diff','--check'])
run('exact-source-restoration',['git','diff','--exit-code','0d31783d7d7cbb4d0ee411710f77fd1c317d7126','HEAD','--','hosts/gpu','.github/workflows/ci-full.yml'])
files=[f for f in p.iterdir() if f.is_file() and f.name!='gpu-unit-tests']
subprocess.run(['python3',str(r/'archive.py'),'restored-checks',*map(str,files),str(r/'restore-checks.py')],cwd=w,check=True)
