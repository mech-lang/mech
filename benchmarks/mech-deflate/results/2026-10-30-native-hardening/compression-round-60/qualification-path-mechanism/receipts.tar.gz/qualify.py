"""Execute unchanged component selection with exact current inventories."""
from pathlib import Path
import json,os,re,subprocess,sys,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/mech-cached-schema-key-round59-20261031')
phase=sys.argv[1] if len(sys.argv)>1 else 'after';assert phase in ['after','parent'];p=r/('qualification' if phase=='after' else 'qualification-parent');p.mkdir(exist_ok=True)
libs=json.loads(((r if phase=='after' else old)/'final-libraries.json').read_text());base=json.loads((old/'qualification/component-build.json').read_text());production=json.loads(((r if phase=='after' else old)/'final-release.json').read_text())['source_head']
def run(label,cmd,env=None,count=None,inventory=False,required=()):
 at=time.monotonic()
 with (p/(label+'.stdout')).open('w') as out,(p/(label+'.stderr')).open('w') as err:q=subprocess.run(cmd,cwd=w,env={**os.environ,**(env or {})},stdout=out,stderr=err)
 stdout=(p/(label+'.stdout')).read_text();receipt={'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'environment':env or {},'compiler_source':production,'test_source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'scope':'Exact frozen dependency graph and GPU variant as primary; original goldens and allowances unchanged. Exact selected count checked before execution.'}
 if count is not None:
  receipt['expected_tests']=count
  if inventory:receipt['listed_tests']=len(re.findall(r': test$',stdout,re.M));observed=receipt['listed_tests']
  else:
   m=re.search(r'test result: ok. (\d+) passed; 0 failed;',stdout);receipt['executed_tests']=int(m[1]) if m else None;observed=receipt['executed_tests']
 (p/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 subprocess.run(['python3',str(r/'archive.py'),p.name+'-'+label,*map(str,[p/(label+'.json'),p/(label+'.stdout'),p/(label+'.stderr'),r/'qualify.py'])],cwd=w,check=True)
 if q.returncode:print((p/(label+'.stderr')).read_text()[-4000:]+stdout[-5000:],flush=True)
 q.check_returncode()
 if count is not None:assert observed==count,(label,receipt)
 for name in required:assert re.search(r'(?:^|::)'+re.escape(name)+r': test$',stdout,re.M),name
 print(label,'COMPLETE',receipt.get('listed_tests',receipt.get('executed_tests')),flush=True)
cmd=base['command'].copy()
for i,a in enumerate(cmd):
 if i and cmd[i-1]=='--extern':
  key=a.split('=')[0]
  if key in libs:cmd[i]=key+'='+libs[key]['path']
cmd[1:1]=['-L','dependency='+str(r/'variants/after/dependency'),'-L','dependency='+str(Path(libs['mech_gpu']['path']).parent)]
cmd[-1]=str(p/'tests');run('component-build',cmd,base['environment'])
run('path-mechanism-inventory',[str(p/'tests'),'optimal_path_qualification::path_scan_emits_native_pieces_around_its_nested_scalar_child','--list'],base['environment'],1,True)
run('path-mechanism',[str(p/'tests'),'optimal_path_qualification::path_scan_emits_native_pieces_around_its_nested_scalar_child','--nocapture','--test-threads=1'],base['environment'],1)
new_cases=('numeric_static_vector_and_rectangular_reads_keep_bounds_aliases_and_retry','numeric_static_vector_writes_preserve_current_shapes_and_first_change_aliases')
for label,name,count in [('components','existing',236),('composition','connected',8)]:
 d=json.loads(Path('/private/tmp/mech-buffer-ownership-round38-20261030/final-components/'+name+'.json').read_text());cmd=d['command'].copy();cmd[0]=str(p/'tests')
 inventory=[a for a in cmd if a!='--nocapture' and not a.startswith('--test-threads=')]+['--list']
 run(label+'-inventory',inventory,base['environment'],count,True,new_cases if label=='components' else ())
 run(label,cmd,base['environment'],count)
