"""Build the current GPU unit harness only; retain exact frozen R59 dependencies."""
from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/mech-cached-schema-key-round59-20261031')
phase=sys.argv[1] if len(sys.argv)>1 else 'after';assert phase=='after';p=r/'units-after';p.mkdir()
b=json.loads((old/'units-after/build.json').read_text());libs=json.loads((r/'final-libraries.json').read_text());cmd=b['command'].copy();cmd[-1]=str(p/'gpu-unit-tests')
for i,a in enumerate(cmd):
 if i and cmd[i-1]=='--extern':
  key=a.split('=')[0]
  if key in libs:cmd[i]=key+'='+libs[key]['path']
cmd[1:1]=['-L','dependency='+str(r/'variants/after/dependency')]
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip()
assert source==json.loads((r/'final-release.json').read_text())['source_head'] or subprocess.check_output(['git','diff',json.loads((r/'final-release.json').read_text())['source_head'],'HEAD','--','hosts/gpu/src'],cwd=w,text=True)==''
def run(label,command,expected=None):
 at=time.monotonic();q=subprocess.run(command,cwd=w,env={**os.environ,**b['environment']},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 row={'command':command,'environment':b['environment'],'exit':q.returncode,'seconds':time.monotonic()-at,'compiler_source':source,'scope':'Current GPU tests; exact retained opt1 warnings-as-errors flags and frozen R59 dependency graph.'}
 if label.endswith('inventory'):row['listed_tests']=len(re.findall(r': test$',q.stdout,re.M))
 m=re.search(r'test result: (?:ok|FAILED). (\d+) passed; (\d+) failed;',q.stdout)
 if m:row.update(executed_tests=int(m[1])+int(m[2]),passed_tests=int(m[1]),failed_tests=int(m[2]))
 (p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 files=[p/(label+'.'+x) for x in ['json','stdout','stderr']]+[r/'units.py']
 snapshot=r/'numeric-words-source.rs';snapshot.write_bytes((w/'hosts/gpu/src/native_artifact/program/codegen/numeric_words.rs').read_bytes());files.append(snapshot)
 subprocess.run(['python3',str(r/'archive.py'),'unit-after-'+label,*map(str,files)],cwd=w,check=True)
 print(label,q.returncode,row.get('listed_tests',row.get('executed_tests')),flush=True)
 if q.returncode:print(q.stdout[-4000:]+q.stderr[-5000:],flush=True)
 q.check_returncode()
 if expected is not None:assert row.get('listed_tests',row.get('executed_tests'))==expected,(label,row)
run('build',cmd)
selection='native_artifact::program::codegen::numeric_words::tests::unit_dimension_addresses_emit_no_division_and_keep_general_geometry'
run('vector-address-inventory',[str(p/'gpu-unit-tests'),selection,'--exact','--list'],1)
run('vector-address',[str(p/'gpu-unit-tests'),selection,'--exact','--nocapture','--test-threads=1'],1)
