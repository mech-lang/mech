from pathlib import Path
import json,os,re,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/mech-cached-schema-key-round59-20261031');p=r/'parent-cases';p.mkdir()
b=json.loads((old/'qualification/component-build.json').read_text());cmd=b['command'].copy();cmd[-1]=str(p/'tests');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
for label,command in [('build',cmd),('cases',[str(p/'tests'),'numeric_static_vector_','--nocapture','--test-threads=1'])]:
 at=time.monotonic();q=subprocess.run(command,cwd=w,env={**os.environ,**b['environment']},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 row={'command':command,'environment':b['environment'],'source_head':head,'exit':q.returncode,'seconds':time.monotonic()-at,'scope':'New semantic regression cases against unchanged R59 optimized compiler libraries.'}
 if label=='cases':
  m=re.search(r'test result: (?:ok|FAILED). (\d+) passed; (\d+) failed;',q.stdout)
  if m:row.update(passed=int(m[1]),failed=int(m[2]))
 (p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 subprocess.run(['python3',str(r/'archive.py'),'parent-'+label,*[str(p/(label+'.'+x)) for x in ['json','stdout','stderr']],str(r/'parent-cases.py')],cwd=w,check=True)
 print(label,q.returncode,row.get('passed'),flush=True)
 if q.returncode:print(q.stdout[-6000:]+q.stderr[-6000:],flush=True)
 q.check_returncode()
 if label=='cases':assert row['passed']==2 and row['failed']==0
