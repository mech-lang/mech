# R60 harness pin audit

Audited as preparation; no compressor, compiler, test or benchmark was executed by this audit.

The one incorrect worker normalization change was a rewritten safety comment. It changed the normalized worker-source hash despite preserving executable source. The original R59 comment was restored in linked-build.py. The worker still compares normalized source hashes after substituting only identity symbol and image path; timer, input, output reuse and logic therefore remain identical. The inherited comment's “unchanged image” means the matched image used by that variant, not equality with R59.

No measurement helper demands baseline/candidate Object equality. run-primary.py checks each worker and each Object/image/metadata hash against its own variant binding. sites-after.py checks the candidate's own linked binding and libraries. Its probe-object pin refers to the unchanged allocation diagnostic C object, not the generated compressor Object.

The artifact_sha256 equality in scalar-controls.py and frame-allocation.py hashes canonical bytecode, as shown by hosts/gpu/examples/native_frame_transport.rs:124,215. That equality is required and unaffected by changing code generation.

R59 analyze.py did require complete baseline/candidate Object/image/metadata pin equality. R60 analyze.py removes that inappropriate gate and reports individual pin equality as evidence. It preserves typed IR equality and strengthens library identity to require every non-GPU library hash to match, while preserving all features/profiles.

Source/MBC pins, allocator, work60260219686, comparison47612, input8/output10, outputcapacity13, cleanup0/0, primary4pairs, counters, full census and serial profiles remain unchanged. Steady-state heap expectations are8173 requests,98228396 requested bytes,162 reallocations on both variants. The first invocation's import warmup remains separately recorded and is not mistaken for steady-state.

Qualification requires observed exact inventories before execution:327 runtime,1 numeric_words codegen,236 selected components including the two named new vector cases,8 connected,1 path,33 selected CI and132 Python workflow tests. Existing knucleotide selection exclusion remains explicit.

Replay requires baseline/binding.json and baseline/metadata.json to be included in an analysis-inputs archive, along with implementation.json, allocation-target.json, binary-audit.json and the scripts. Those baseline files were copied into scratch so replay does not depend on a live baseline symlink.
