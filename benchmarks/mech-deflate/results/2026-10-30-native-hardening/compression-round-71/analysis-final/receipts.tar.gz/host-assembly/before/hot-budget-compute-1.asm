
/private/tmp/mech-checked-compute-round71-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001023698a4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work>:
1023698a4:     	sub	sp, sp, #0x1e0
1023698a8:     	stp	x28, x27, [sp, #0x180]
1023698ac:     	stp	x26, x25, [sp, #0x190]
1023698b0:     	stp	x24, x23, [sp, #0x1a0]
1023698b4:     	stp	x22, x21, [sp, #0x1b0]
1023698b8:     	stp	x20, x19, [sp, #0x1c0]
1023698bc:     	stp	x29, x30, [sp, #0x1d0]
1023698c0:     	add	x29, sp, #0x1d0
1023698c4:     	ldr	x9, [x0, #0xd0]
1023698c8:     	adds	x19, x9, x1
1023698cc:     	b.hs	0x102369950 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
1023698d0:     	ldr	x1, [x0, #0xc8]
1023698d4:     	ldr	x27, [x0, #0xf8]
1023698d8:     	ldr	x25, [x0, #0x108]
1023698dc:     	ldp	x21, x23, [x0, #0x118]
1023698e0:     	ldr	x9, [x0]
1023698e4:     	cmp	x9, #0x1
1023698e8:     	b.ne	0x102369958 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xb4>
1023698ec:     	cmp	x23, #0x10, lsl #12     ; =0x10000
1023698f0:     	b.hi	0x102369950 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
1023698f4:     	ldr	x9, [x0, #0xe8]
1023698f8:     	mov	w10, #0x1000000         ; =16777216
1023698fc:     	cmp	x9, x10
102369900:     	b.hi	0x102369950 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102369904:     	mov	w9, #0x1000000          ; =16777216
102369908:     	cmp	x19, x9
10236990c:     	b.hi	0x102369950 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102369910:     	mov	w9, #0x1000000          ; =16777216
102369914:     	cmp	x27, x9
102369918:     	b.hi	0x102369950 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10236991c:     	mov	w9, #0x1000000          ; =16777216
102369920:     	cmp	x25, x9
102369924:     	b.hi	0x102369950 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102369928:     	cmp	x21, #0x10, lsl #12     ; =0x10000
10236992c:     	b.hi	0x102369950 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102369930:     	cmp	x1, #0x10, lsl #12      ; =0x10000
102369934:     	b.hi	0x102369950 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102369938:     	ldr	x9, [x0, #0x8]
10236993c:     	cmp	x19, x9
102369940:     	b.hi	0x102369950 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102369944:     	ldr	x9, [x0, #0x10]
102369948:     	cmp	x1, x9
10236994c:     	b.ls	0x102369a78 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1d4>
102369950:     	mov	w9, #0x2                ; =2
102369954:     	b	0x102369a80 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1dc>
102369958:     	ldr	x26, [x0, #0x110]
10236995c:     	ldr	x24, [x0, #0x128]
102369960:     	ldr	x28, [x0, #0x18]
102369964:     	cmp	x28, #0x2
102369968:     	b.ne	0x1023699e0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x13c>
10236996c:     	mov	x22, x8
102369970:     	ldur	q0, [x0, #0xd8]
102369974:     	ldur	q1, [x0, #0xe8]
102369978:     	mov	x20, x0
10236997c:     	ldur	q2, [x0, #0xf8]
102369980:     	stp	x1, x19, [sp, #0xe0]
102369984:     	stp	q0, q1, [sp, #0xf0]
102369988:     	str	q2, [sp, #0x110]
10236998c:     	stp	x25, x26, [sp, #0x120]
102369990:     	stp	x21, x23, [sp, #0x130]
102369994:     	str	x24, [sp, #0x140]
102369998:     	sub	x0, x29, #0x88
10236999c:     	mov	x2, x19
1023699a0:     	bl	0x1023781f8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget20observe_control_work>
1023699a4:     	ldurb	w8, [x29, #-0x88]
1023699a8:     	cmp	w8, #0x8
1023699ac:     	b.ne	0x102369a50 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1ac>
1023699b0:     	add	x0, sp, #0xb0
1023699b4:     	add	x1, sp, #0xe0
1023699b8:     	bl	0x102365f24 <__RNvMs4_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_18KernelCostEstimate21check_planning_limits>
1023699bc:     	mov	x8, x22
1023699c0:     	ldrb	w9, [sp, #0xb0]
1023699c4:     	cmp	w9, #0x8
1023699c8:     	b.eq	0x102369a74 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1d0>
1023699cc:     	ldp	q0, q1, [sp, #0xb0]
1023699d0:     	stp	q0, q1, [x8]
1023699d4:     	ldr	x9, [sp, #0xd0]
1023699d8:     	str	x9, [x8, #0x20]
1023699dc:     	b	0x102369a84 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1e0>
1023699e0:     	ldr	x14, [x0, #0xe0]
1023699e4:     	ldr	x10, [x0, #0x20]
1023699e8:     	ldp	x11, x9, [x0, #0x38]
1023699ec:     	stp	x9, x10, [sp, #0xa0]
1023699f0:     	ldp	x9, x10, [x0, #0x48]
1023699f4:     	stp	x9, x11, [sp, #0x90]
1023699f8:     	ldp	x9, x11, [x0, #0x58]
1023699fc:     	str	x9, [sp, #0x88]
102369a00:     	ldp	x9, x6, [x0, #0x68]
102369a04:     	stp	x0, x9, [sp, #0x78]
102369a08:     	ldp	x12, x4, [x0, #0x78]
102369a0c:     	ldp	x7, x2, [x0, #0x88]
102369a10:     	ldp	x5, x15, [x0, #0x98]
102369a14:     	ldp	w3, w13, [x0, #0xb8]
102369a18:     	ldr	x22, [x0, #0xc0]
102369a1c:     	adrp	x0, 0x108073000 <__mi_heap_main+0xb28>
102369a20:     	add	x0, x0, #0x550
102369a24:     	ldr	x9, [x0]
102369a28:     	blr	x9
102369a2c:     	mov	x20, x0
102369a30:     	ldrb	w9, [x0, #0x48]
102369a34:     	cmp	w9, #0x1
102369a38:     	b.eq	0x102369b00 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x25c>
102369a3c:     	cmp	w9, #0x2
102369a40:     	b.ne	0x102369aa4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x200>
102369a44:     	adrp	x0, 0x108035000 <_anon.686517066f445f70c1782692b9896900.7+0x55f00>
102369a48:     	add	x0, x0, #0xc40
102369a4c:     	bl	0x103a05590 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
102369a50:     	sub	x8, x29, #0x88
102369a54:     	ldp	q0, q1, [x8]
102369a58:     	stp	q0, q1, [sp, #0xb0]
102369a5c:     	ldur	x8, [x29, #-0x68]
102369a60:     	str	x8, [sp, #0xd0]
102369a64:     	mov	x8, x22
102369a68:     	ldrb	w9, [sp, #0xb0]
102369a6c:     	cmp	w9, #0x8
102369a70:     	b.ne	0x1023699cc <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x128>
102369a74:     	mov	x0, x20
102369a78:     	str	x19, [x0, #0xd0]
102369a7c:     	mov	w9, #0x8                ; =8
102369a80:     	strb	w9, [x8]
102369a84:     	ldp	x29, x30, [sp, #0x1d0]
102369a88:     	ldp	x20, x19, [sp, #0x1c0]
102369a8c:     	ldp	x22, x21, [sp, #0x1b0]
102369a90:     	ldp	x24, x23, [sp, #0x1a0]
102369a94:     	ldp	x26, x25, [sp, #0x190]
102369a98:     	ldp	x28, x27, [sp, #0x180]
102369a9c:     	add	sp, sp, #0x1e0
102369aa0:     	ret
102369aa4:     	adrp	x9, 0x10277d000 <__RINvNtNtNtCskIfnrfrMWVM_9mech_core11type_system10conversion10population4walkNtNtNtB8_8function8resident19ResidentKernelErrorNCNvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident14set_conversion5stats11draft_nodes0EB28_+0x5dc>
102369aa8:     	add	x9, x9, #0x6bc
102369aac:     	mov	x0, x20
102369ab0:     	stp	x4, x1, [sp, #0x50]
102369ab4:     	mov	x1, x9
102369ab8:     	stp	x6, x8, [sp, #0x8]
102369abc:     	stp	x13, x5, [sp, #0x20]
102369ac0:     	stp	x2, x14, [sp, #0x40]
102369ac4:     	stp	x15, x7, [sp, #0x30]
102369ac8:     	str	w3, [sp, #0x1c]
102369acc:     	stp	x12, x11, [sp, #0x60]
102369ad0:     	str	x10, [sp, #0x70]
102369ad4:     	bl	0x102e7282c <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
102369ad8:     	ldp	x11, x10, [sp, #0x68]
102369adc:     	ldp	x1, x12, [sp, #0x58]
102369ae0:     	ldp	x7, x2, [sp, #0x38]
102369ae4:     	ldp	x6, x8, [sp, #0x8]
102369ae8:     	ldp	x5, x15, [sp, #0x28]
102369aec:     	ldp	x14, x4, [sp, #0x48]
102369af0:     	ldr	w3, [sp, #0x1c]
102369af4:     	ldr	x13, [sp, #0x20]
102369af8:     	mov	w9, #0x1                ; =1
102369afc:     	strb	w9, [x20, #0x48]
102369b00:     	str	x10, [sp, #0x70]
102369b04:     	ldr	x9, [x20]
102369b08:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
102369b0c:     	cmp	x9, x10
102369b10:     	b.hs	0x102369d04 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x460>
102369b14:     	add	x10, x9, #0x1
102369b18:     	str	x10, [x20]
102369b1c:     	ldr	x10, [x20, #0x8]
102369b20:     	cbz	x10, 0x102369ba8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x304>
102369b24:     	stp	x12, x11, [sp, #0x60]
102369b28:     	ldr	x11, [x10, #0x10]
102369b2c:     	mov	x12, #0x7fffffffffffffff ; =9223372036854775807
102369b30:     	cmp	x11, x12
102369b34:     	b.hs	0x102369d10 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x46c>
102369b38:     	ldr	x10, [x10, #0x58]
102369b3c:     	str	x9, [x20]
102369b40:     	cmp	x10, x22
102369b44:     	b.ne	0x102369bac <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x308>
102369b48:     	stp	x7, x2, [sp, #0x38]
102369b4c:     	mov	x20, x6
102369b50:     	stp	x5, x15, [sp, #0x28]
102369b54:     	stp	x14, x4, [sp, #0x48]
102369b58:     	str	w3, [sp, #0x1c]
102369b5c:     	str	x13, [sp, #0x20]
102369b60:     	mov	x22, x8
102369b64:     	add	x0, sp, #0xe0
102369b68:     	str	x1, [sp, #0x58]
102369b6c:     	mov	x2, x19
102369b70:     	bl	0x1023781f8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget20observe_control_work>
102369b74:     	ldrb	w8, [sp, #0xe0]
102369b78:     	cmp	w8, #0x8
102369b7c:     	b.ne	0x102369bb4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x310>
102369b80:     	cmp	x28, #0x1
102369b84:     	mov	x8, x22
102369b88:     	mov	x11, x20
102369b8c:     	ldr	x10, [sp, #0xa8]
102369b90:     	b.ne	0x102369bc8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x324>
102369b94:     	cmp	x23, x10
102369b98:     	b.ls	0x102369bc8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x324>
102369b9c:     	mov	w9, #0x0                ; =0
102369ba0:     	mov	x11, x10
102369ba4:     	b	0x102369ce8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x444>
102369ba8:     	str	x9, [x20]
102369bac:     	strb	wzr, [x8]
102369bb0:     	b	0x102369a84 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1e0>
102369bb4:     	ldp	q0, q1, [sp, #0xe0]
102369bb8:     	stp	q0, q1, [x22]
102369bbc:     	ldr	x8, [sp, #0x100]
102369bc0:     	str	x8, [x22, #0x20]
102369bc4:     	b	0x102369a84 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1e0>
102369bc8:     	ldp	x9, x10, [sp, #0x98]
102369bcc:     	cmp	x9, #0x1
102369bd0:     	b.ne	0x102369bec <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x348>
102369bd4:     	cmp	x27, x10
102369bd8:     	b.ls	0x102369bec <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x348>
102369bdc:     	mov	w9, #0x2                ; =2
102369be0:     	mov	x23, x27
102369be4:     	mov	x11, x10
102369be8:     	b	0x102369ce8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x444>
102369bec:     	ldr	x9, [sp, #0x90]
102369bf0:     	cmp	x9, #0x1
102369bf4:     	ldr	x10, [sp, #0x70]
102369bf8:     	b.ne	0x102369c14 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x370>
102369bfc:     	cmp	x25, x10
102369c00:     	b.ls	0x102369c14 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x370>
102369c04:     	mov	w9, #0x3                ; =3
102369c08:     	mov	x23, x25
102369c0c:     	mov	x11, x10
102369c10:     	b	0x102369ce8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x444>
102369c14:     	ldr	x9, [sp, #0x88]
102369c18:     	cmp	x9, #0x1
102369c1c:     	ldr	x10, [sp, #0x68]
102369c20:     	b.ne	0x102369c3c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x398>
102369c24:     	cmp	x21, x10
102369c28:     	b.ls	0x102369c3c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x398>
102369c2c:     	mov	w9, #0x4                ; =4
102369c30:     	mov	x23, x21
102369c34:     	mov	x11, x10
102369c38:     	b	0x102369ce8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x444>
102369c3c:     	ldr	x9, [sp, #0x80]
102369c40:     	cmp	x9, #0x1
102369c44:     	ldr	x20, [sp, #0x58]
102369c48:     	b.ne	0x102369c60 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3bc>
102369c4c:     	cmp	x20, x11
102369c50:     	b.ls	0x102369c60 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3bc>
102369c54:     	mov	w9, #0x5                ; =5
102369c58:     	mov	x23, x20
102369c5c:     	b	0x102369ce8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x444>
102369c60:     	ldr	x9, [sp, #0x60]
102369c64:     	cmp	x9, #0x1
102369c68:     	ldr	x11, [sp, #0x50]
102369c6c:     	b.ne	0x102369c84 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3e0>
102369c70:     	cmp	x19, x11
102369c74:     	b.ls	0x102369c84 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3e0>
102369c78:     	mov	w9, #0x6                ; =6
102369c7c:     	mov	x23, x19
102369c80:     	b	0x102369ce8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x444>
102369c84:     	ldp	x9, x11, [sp, #0x38]
102369c88:     	cmp	x9, #0x1
102369c8c:     	ldr	x23, [sp, #0x48]
102369c90:     	b.ne	0x102369ca4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x400>
102369c94:     	cmp	x23, x11
102369c98:     	b.ls	0x102369ca4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x400>
102369c9c:     	mov	w9, #0x7                ; =7
102369ca0:     	b	0x102369ce8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x444>
102369ca4:     	ldp	x9, x11, [sp, #0x28]
102369ca8:     	cmp	x9, #0x1
102369cac:     	b.ne	0x102369cc4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x420>
102369cb0:     	cmp	x26, x11
102369cb4:     	b.ls	0x102369cc4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x420>
102369cb8:     	mov	w9, #0x8                ; =8
102369cbc:     	mov	x23, x26
102369cc0:     	b	0x102369ce8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x444>
102369cc4:     	ldr	w9, [sp, #0x1c]
102369cc8:     	cmp	w9, #0x1
102369ccc:     	ldr	x0, [sp, #0x78]
102369cd0:     	ldr	x11, [sp, #0x20]
102369cd4:     	b.ne	0x102369a78 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1d4>
102369cd8:     	cmp	w11, w24
102369cdc:     	b.hs	0x102369a78 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1d4>
102369ce0:     	mov	w23, w24
102369ce4:     	mov	w9, #0xa                ; =10
102369ce8:     	mov	w10, #0x6               ; =6
102369cec:     	strb	w10, [x8]
102369cf0:     	strb	w9, [x8, #0x1]
102369cf4:     	mov	w9, #0x1                ; =1
102369cf8:     	strb	w9, [x8, #0x2]
102369cfc:     	stp	x23, x11, [x8, #0x8]
102369d00:     	b	0x102369a84 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1e0>
102369d04:     	adrp	x0, 0x108037000 <_anon.2bf03b07bb14881f9e7a07d073725bdc.306+0x1a8>
102369d08:     	add	x0, x0, #0x260
102369d0c:     	bl	0x103a05c44 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102369d10:     	adrp	x0, 0x108037000 <_anon.2bf03b07bb14881f9e7a07d073725bdc.306+0x1a8>
102369d14:     	add	x0, x0, #0x278
102369d18:     	bl	0x103a05c44 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102369d1c:     	brk	#0x1
102369d20:     	ldr	x8, [x20]
102369d24:     	sub	x8, x8, #0x1
102369d28:     	str	x8, [x20]
102369d2c:     	bl	0x103a0710c <dyld_stub_binder+0x103a0710c>
