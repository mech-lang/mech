
/private/tmp/mech-checked-compute-round71-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102920544 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>:
102920544:     	sub	sp, sp, #0x90
102920548:     	stp	x20, x19, [sp, #0x70]
10292054c:     	stp	x29, x30, [sp, #0x80]
102920550:     	add	x29, sp, #0x80
102920554:     	mov	x19, x8
102920558:     	ldr	x20, [x0]
10292055c:     	ldr	x8, [x20, #0x10]
102920560:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
102920564:     	cmp	x8, x9
102920568:     	b.hs	0x1029205d4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x90>
10292056c:     	add	x9, x8, #0x1
102920570:     	str	x9, [x20, #0x10]
102920574:     	ldr	x9, [x20, #0x38]
102920578:     	adds	x4, x9, x1
10292057c:     	b.hs	0x1029205e0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x9c>
102920580:     	str	x8, [x20, #0x10]
102920584:     	cmp	x4, x2
102920588:     	b.ls	0x1029205a4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x60>
10292058c:     	mov	w8, #0x606              ; =1542
102920590:     	strh	w8, [x19]
102920594:     	mov	w8, #0x1                ; =1
102920598:     	strb	w8, [x19, #0x2]
10292059c:     	stp	x4, x2, [x19, #0x8]
1029205a0:     	b	0x102920754 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x210>
1029205a4:     	adrp	x0, 0x108067000 <__mi_heap_main+0xb28>
1029205a8:     	add	x0, x0, #0x568
1029205ac:     	ldr	x8, [x0]
1029205b0:     	blr	x8
1029205b4:     	ldrb	w8, [x0, #0x48]
1029205b8:     	cmp	w8, #0x1
1029205bc:     	b.eq	0x102920628 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xe4>
1029205c0:     	cmp	w8, #0x2
1029205c4:     	b.ne	0x102920600 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xbc>
1029205c8:     	adrp	x0, 0x108043000 <_anon.8adce7851be193ad1ab4b832a11ead76.36+0x8>
1029205cc:     	add	x0, x0, #0x478
1029205d0:     	bl	0x1039f9dc0 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
1029205d4:     	adrp	x0, 0x108045000 <_anon.8adce7851be193ad1ab4b832a11ead76.537+0x38>
1029205d8:     	add	x0, x0, #0x28
1029205dc:     	bl	0x1039fa474 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
1029205e0:     	mov	w9, #0x606              ; =1542
1029205e4:     	strh	w9, [x19]
1029205e8:     	mov	w9, #0x1                ; =1
1029205ec:     	strb	w9, [x19, #0x2]
1029205f0:     	mov	x9, #-0x1               ; =-1
1029205f4:     	stp	x9, x2, [x19, #0x8]
1029205f8:     	str	x8, [x20, #0x10]
1029205fc:     	b	0x102920754 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x210>
102920600:     	adrp	x8, 0x102915000 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTmjENvYB15_NtNtBa_3cmp10PartialOrd2ltECs1qJAwyMG1lC_11mech_engine+0x4ec>
102920604:     	add	x8, x8, #0xf68
102920608:     	stp	x1, x0, [sp, #0x10]
10292060c:     	mov	x1, x8
102920610:     	str	x4, [sp, #0x8]
102920614:     	bl	0x102e66618 <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
102920618:     	ldp	x1, x0, [sp, #0x10]
10292061c:     	ldr	x4, [sp, #0x8]
102920620:     	mov	w8, #0x1                ; =1
102920624:     	strb	w8, [x0, #0x48]
102920628:     	ldr	x8, [x0, #0x20]
10292062c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
102920630:     	cmp	x8, x9
102920634:     	b.hs	0x102920764 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x220>
102920638:     	ldr	x8, [x0, #0x28]
10292063c:     	cmp	x8, #0x0
102920640:     	ccmp	x8, x20, #0x4, ne
102920644:     	b.ne	0x1029206b0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x16c>
102920648:     	ldr	x8, [x20, #0x10]
10292064c:     	cbnz	x8, 0x102920778 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x234>
102920650:     	mov	x8, #-0x1               ; =-1
102920654:     	str	x8, [x20, #0x10]
102920658:     	ldr	w8, [x0, #0x30]
10292065c:     	ldp	x9, x10, [x0, #0x38]
102920660:     	ldp	x11, x12, [x20, #0x60]
102920664:     	cmp	x9, x11
102920668:     	csel	x9, x9, x11, lo
10292066c:     	cmp	x10, x12
102920670:     	csel	x10, x10, x12, lo
102920674:     	tst	w8, #0x1
102920678:     	csel	x9, x9, x11, ne
10292067c:     	csel	x12, x10, x12, ne
102920680:     	ldr	x8, [x20, #0x48]
102920684:     	adds	x10, x8, x4
102920688:     	b.hs	0x102920770 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x22c>
10292068c:     	ldr	x5, [x20, #0x40]
102920690:     	ldr	x8, [x20, #0x50]
102920694:     	adds	x13, x8, x5
102920698:     	b.hs	0x102920770 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x22c>
10292069c:     	cmp	x10, x9
1029206a0:     	b.ls	0x1029206b8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x174>
1029206a4:     	mov	w8, #0x6                ; =6
1029206a8:     	mov	w11, #0x6               ; =6
1029206ac:     	b	0x1029206d0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x18c>
1029206b0:     	mov	w8, #0x0                ; =0
1029206b4:     	b	0x10292073c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1f8>
1029206b8:     	cmp	x13, x12
1029206bc:     	b.ls	0x1029206fc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1b8>
1029206c0:     	mov	w11, #0x5               ; =5
1029206c4:     	mov	w8, #0x6                ; =6
1029206c8:     	mov	x10, x13
1029206cc:     	mov	x9, x12
1029206d0:     	sturb	w11, [x29, #-0x37]
1029206d4:     	mov	w11, #0x1               ; =1
1029206d8:     	sturb	w11, [x29, #-0x36]
1029206dc:     	stp	x10, x9, [x29, #-0x30]
1029206e0:     	str	xzr, [x20, #0x10]
1029206e4:     	ldur	x9, [x29, #-0x18]
1029206e8:     	stur	x9, [sp, #0x3f]
1029206ec:     	ldur	q0, [x29, #-0x37]
1029206f0:     	ldur	q1, [x29, #-0x27]
1029206f4:     	stp	q0, q1, [sp, #0x20]
1029206f8:     	b	0x10292073c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1f8>
1029206fc:     	sub	x0, x29, #0x38
102920700:     	mov	x2, x1
102920704:     	add	x1, x20, #0x18
102920708:     	mov	x3, #0x0                ; =0
10292070c:     	bl	0x1029345c8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget27commit_control_account_work>
102920710:     	ldr	x8, [x20, #0x10]
102920714:     	add	x9, x8, #0x1
102920718:     	ldurb	w8, [x29, #-0x38]
10292071c:     	str	x9, [x20, #0x10]
102920720:     	ldur	q0, [x29, #-0x37]
102920724:     	ldur	q1, [x29, #-0x27]
102920728:     	stp	q0, q1, [sp, #0x20]
10292072c:     	ldur	x9, [x29, #-0x18]
102920730:     	stur	x9, [sp, #0x3f]
102920734:     	cmp	w8, #0x9
102920738:     	b.eq	0x1029205c8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x84>
10292073c:     	strb	w8, [x19]
102920740:     	ldp	q0, q1, [sp, #0x20]
102920744:     	stur	q0, [x19, #0x1]
102920748:     	stur	q1, [x19, #0x11]
10292074c:     	ldur	x8, [sp, #0x3f]
102920750:     	str	x8, [x19, #0x20]
102920754:     	ldp	x29, x30, [sp, #0x80]
102920758:     	ldp	x20, x19, [sp, #0x70]
10292075c:     	add	sp, sp, #0x90
102920760:     	ret
102920764:     	adrp	x0, 0x108045000 <_anon.8adce7851be193ad1ab4b832a11ead76.537+0x38>
102920768:     	add	x0, x0, #0x10
10292076c:     	bl	0x1039fa474 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102920770:     	mov	w8, #0x2                ; =2
102920774:     	b	0x1029206d0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x18c>
102920778:     	adrp	x0, 0x108044000 <_anon.8adce7851be193ad1ab4b832a11ead76.258+0x38>
10292077c:     	add	x0, x0, #0x538
102920780:     	bl	0x1039fa444 <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
102920784:     	ldr	x8, [x20, #0x10]
102920788:     	add	x8, x8, #0x1
10292078c:     	str	x8, [x20, #0x10]
102920790:     	bl	0x1039fb93c <dyld_stub_binder+0x1039fb93c>
