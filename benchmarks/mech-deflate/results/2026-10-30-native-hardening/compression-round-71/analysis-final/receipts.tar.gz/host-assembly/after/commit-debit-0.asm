
/private/tmp/mech-checked-compute-round71-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001029345c8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget27commit_control_account_work>:
1029345c8:     	sub	sp, sp, #0x90
1029345cc:     	stp	x26, x25, [sp, #0x40]
1029345d0:     	stp	x24, x23, [sp, #0x50]
1029345d4:     	stp	x22, x21, [sp, #0x60]
1029345d8:     	stp	x20, x19, [sp, #0x70]
1029345dc:     	stp	x29, x30, [sp, #0x80]
1029345e0:     	add	x29, sp, #0x80
1029345e4:     	mov	x21, x5
1029345e8:     	mov	x22, x4
1029345ec:     	mov	x23, x1
1029345f0:     	mov	x19, x0
1029345f4:     	ldr	x8, [x1, #0x58]
1029345f8:     	cbz	x8, 0x102934660 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget27commit_control_account_work+0x98>
1029345fc:     	mov	x25, x3
102934600:     	mov	x26, x2
102934604:     	add	x0, x8, #0x10
102934608:     	bl	0x102946f88 <__RNvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workers11lock_escrow>
10293460c:     	mov	x20, x0
102934610:     	mov	x24, x1
102934614:     	add	x0, sp, #0x18
102934618:     	add	x1, x20, #0x10
10293461c:     	mov	x2, x26
102934620:     	mov	x3, x25
102934624:     	bl	0x1029210d4 <__RNvMs0_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workers7creditsNtB7_6Escrow11direct_next>
102934628:     	ldrb	w25, [sp, #0x18]
10293462c:     	cmp	w25, #0x8
102934630:     	b.ne	0x102934670 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget27commit_control_account_work+0xa8>
102934634:     	add	x8, x20, #0x478
102934638:     	ldur	q0, [sp, #0x20]
10293463c:     	str	q0, [x8]
102934640:     	tbnz	w24, #0x0, 0x102934658 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget27commit_control_account_work+0x90>
102934644:     	adrp	x8, 0x108067000 <__mi_heap_main+0xb28>
102934648:     	add	x8, x8, #0xc28
10293464c:     	ldr	x8, [x8]
102934650:     	tst	x8, #0x7fffffffffffffff
102934654:     	b.ne	0x1029346e8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget27commit_control_account_work+0x120>
102934658:     	ldr	x0, [x20]
10293465c:     	bl	0x102e56688 <__RNvMNtNtNtNtNtCsgirOGyZpP7g_3std3sys3pal4unix4sync5mutexNtB2_5Mutex6unlock>
102934660:     	stp	x22, x21, [x23, #0x20]
102934664:     	mov	w8, #0x8                ; =8
102934668:     	strb	w8, [x19]
10293466c:     	b	0x1029346cc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget27commit_control_account_work+0x104>
102934670:     	ldur	w8, [sp, #0x19]
102934674:     	str	w8, [sp, #0x10]
102934678:     	ldr	w8, [sp, #0x1c]
10293467c:     	stur	w8, [sp, #0x13]
102934680:     	ldp	x21, x22, [sp, #0x20]
102934684:     	ldur	q0, [sp, #0x30]
102934688:     	str	q0, [sp]
10293468c:     	tbnz	w24, #0x0, 0x1029346a4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget27commit_control_account_work+0xdc>
102934690:     	adrp	x8, 0x108067000 <__mi_heap_main+0xb28>
102934694:     	add	x8, x8, #0xc28
102934698:     	ldr	x8, [x8]
10293469c:     	tst	x8, #0x7fffffffffffffff
1029346a0:     	b.ne	0x1029346fc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget27commit_control_account_work+0x134>
1029346a4:     	ldr	x0, [x20]
1029346a8:     	bl	0x102e56688 <__RNvMNtNtNtNtNtCsgirOGyZpP7g_3std3sys3pal4unix4sync5mutexNtB2_5Mutex6unlock>
1029346ac:     	strb	w25, [x19]
1029346b0:     	ldr	w8, [sp, #0x10]
1029346b4:     	stur	w8, [x19, #0x1]
1029346b8:     	ldur	w8, [sp, #0x13]
1029346bc:     	str	w8, [x19, #0x4]
1029346c0:     	stp	x21, x22, [x19, #0x8]
1029346c4:     	ldr	q0, [sp]
1029346c8:     	stur	q0, [x19, #0x18]
1029346cc:     	ldp	x29, x30, [sp, #0x80]
1029346d0:     	ldp	x20, x19, [sp, #0x70]
1029346d4:     	ldp	x22, x21, [sp, #0x60]
1029346d8:     	ldp	x24, x23, [sp, #0x50]
1029346dc:     	ldp	x26, x25, [sp, #0x40]
1029346e0:     	add	sp, sp, #0x90
1029346e4:     	ret
1029346e8:     	bl	0x1039f9f2c <__RNvNtNtCsgirOGyZpP7g_3std9panicking11panic_count17is_zero_slow_path>
1029346ec:     	tbnz	w0, #0x0, 0x102934658 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget27commit_control_account_work+0x90>
1029346f0:     	mov	w8, #0x1                ; =1
1029346f4:     	strb	w8, [x20, #0x8]
1029346f8:     	b	0x102934658 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget27commit_control_account_work+0x90>
1029346fc:     	bl	0x1039f9f2c <__RNvNtNtCsgirOGyZpP7g_3std9panicking11panic_count17is_zero_slow_path>
102934700:     	tbnz	w0, #0x0, 0x1029346a4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget27commit_control_account_work+0xdc>
102934704:     	mov	w8, #0x1                ; =1
102934708:     	strb	w8, [x20, #0x8]
10293470c:     	b	0x1029346a4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget27commit_control_account_work+0xdc>
102934710:     	mov	x19, x0
102934714:     	and	w1, w24, #0x1
102934718:     	mov	x0, x20
10293471c:     	bl	0x1028f7974 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtNtCsgirOGyZpP7g_3std4sync6poison5mutex10MutexGuardINtNtB4_6option6OptionINtNtCsgKscDXrlV49_5alloc4sync3ArcNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn14TurnMemoryPlanEEEEB2B_>
102934720:     	mov	x0, x19
102934724:     	bl	0x1039fb93c <dyld_stub_binder+0x1039fb93c>
102934728:     	bl	0x1039fa558 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
