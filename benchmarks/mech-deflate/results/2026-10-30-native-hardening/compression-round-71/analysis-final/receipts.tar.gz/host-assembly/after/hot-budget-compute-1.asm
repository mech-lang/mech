
/private/tmp/mech-checked-compute-round71-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102926ba0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work>:
102926ba0:     	stp	x28, x27, [sp, #-0x60]!
102926ba4:     	stp	x26, x25, [sp, #0x10]
102926ba8:     	stp	x24, x23, [sp, #0x20]
102926bac:     	stp	x22, x21, [sp, #0x30]
102926bb0:     	stp	x20, x19, [sp, #0x40]
102926bb4:     	stp	x29, x30, [sp, #0x50]
102926bb8:     	add	x29, sp, #0x50
102926bbc:     	sub	sp, sp, #0x1a0
102926bc0:     	ldr	x9, [x0, #0xd0]
102926bc4:     	adds	x13, x9, x1
102926bc8:     	b.hs	0x102926c4c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102926bcc:     	ldr	x21, [x0, #0xc8]
102926bd0:     	ldr	x26, [x0, #0xe8]
102926bd4:     	ldr	x28, [x0, #0xf8]
102926bd8:     	ldr	x25, [x0, #0x108]
102926bdc:     	ldp	x22, x23, [x0, #0x118]
102926be0:     	ldr	x9, [x0]
102926be4:     	cmp	x9, #0x1
102926be8:     	b.ne	0x102926c54 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xb4>
102926bec:     	cmp	x23, #0x10, lsl #12     ; =0x10000
102926bf0:     	b.hi	0x102926c4c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102926bf4:     	mov	w9, #0x1000000          ; =16777216
102926bf8:     	cmp	x26, x9
102926bfc:     	b.hi	0x102926c4c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102926c00:     	mov	w9, #0x1000000          ; =16777216
102926c04:     	cmp	x13, x9
102926c08:     	b.hi	0x102926c4c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102926c0c:     	mov	w9, #0x1000000          ; =16777216
102926c10:     	cmp	x28, x9
102926c14:     	b.hi	0x102926c4c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102926c18:     	mov	w9, #0x1000000          ; =16777216
102926c1c:     	cmp	x25, x9
102926c20:     	b.hi	0x102926c4c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102926c24:     	cmp	x22, #0x10, lsl #12     ; =0x10000
102926c28:     	b.hi	0x102926c4c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102926c2c:     	cmp	x21, #0x10, lsl #12     ; =0x10000
102926c30:     	b.hi	0x102926c4c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102926c34:     	ldr	x9, [x0, #0x8]
102926c38:     	cmp	x13, x9
102926c3c:     	b.hi	0x102926c4c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102926c40:     	ldr	x9, [x0, #0x10]
102926c44:     	cmp	x21, x9
102926c48:     	b.ls	0x102926d8c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1ec>
102926c4c:     	mov	w9, #0x2                ; =2
102926c50:     	b	0x102926d94 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f4>
102926c54:     	ldp	x24, x2, [x0, #0xd8]
102926c58:     	ldr	x20, [x0, #0xf0]
102926c5c:     	ldr	x9, [x0, #0x100]
102926c60:     	ldr	x1, [x0, #0x110]
102926c64:     	ldr	x15, [x0, #0x128]
102926c68:     	ldr	x27, [x0, #0x18]
102926c6c:     	cmp	x27, #0x2
102926c70:     	b.ne	0x102926ce4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x144>
102926c74:     	mov	x19, x0
102926c78:     	mov	x27, x8
102926c7c:     	stp	x21, x13, [x29, #-0xf0]
102926c80:     	mov	x21, x13
102926c84:     	stp	x24, x2, [x29, #-0xe0]
102926c88:     	stp	x26, x20, [x29, #-0xd0]
102926c8c:     	stp	x28, x9, [x29, #-0xc0]
102926c90:     	stp	x25, x1, [x29, #-0xb0]
102926c94:     	stp	x22, x23, [x29, #-0xa0]
102926c98:     	stur	x15, [x29, #-0x90]
102926c9c:     	sub	x8, x29, #0x88
102926ca0:     	sub	x0, x29, #0xf0
102926ca4:     	bl	0x102933eac <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget20observe_control_work>
102926ca8:     	ldurb	w8, [x29, #-0x88]
102926cac:     	cmp	w8, #0x8
102926cb0:     	b.ne	0x102926d60 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1c0>
102926cb4:     	add	x0, sp, #0xd0
102926cb8:     	sub	x1, x29, #0xf0
102926cbc:     	bl	0x102922460 <__RNvMs4_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_18KernelCostEstimate21check_planning_limits>
102926cc0:     	mov	x8, x27
102926cc4:     	ldrb	w9, [sp, #0xd0]
102926cc8:     	cmp	w9, #0x8
102926ccc:     	b.eq	0x102926d84 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1e4>
102926cd0:     	ldp	q0, q1, [sp, #0xd0]
102926cd4:     	stp	q0, q1, [x8]
102926cd8:     	ldr	x9, [sp, #0xf0]
102926cdc:     	str	x9, [x8, #0x20]
102926ce0:     	b	0x102926d98 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
102926ce4:     	str	x9, [sp, #0xc0]
102926ce8:     	ldr	x10, [x0, #0x20]
102926cec:     	ldp	x11, x9, [x0, #0x38]
102926cf0:     	stp	x9, x10, [sp, #0xb0]
102926cf4:     	ldp	x10, x9, [x0, #0x48]
102926cf8:     	stp	x9, x11, [sp, #0xa0]
102926cfc:     	ldr	x9, [x0, #0x58]
102926d00:     	stp	x9, x10, [sp, #0x90]
102926d04:     	ldp	x10, x9, [x0, #0x60]
102926d08:     	str	x9, [sp, #0x88]
102926d0c:     	ldp	x11, x9, [x0, #0x70]
102926d10:     	stp	x0, x9, [sp, #0x78]
102926d14:     	ldp	x6, x12, [x0, #0x80]
102926d18:     	ldp	x4, x7, [x0, #0x90]
102926d1c:     	ldr	x3, [x0, #0xa0]
102926d20:     	ldp	w5, w14, [x0, #0xb8]
102926d24:     	ldr	x9, [x0, #0xc0]
102926d28:     	str	x9, [sp, #0xc8]
102926d2c:     	adrp	x0, 0x108067000 <__mi_heap_main+0xb28>
102926d30:     	add	x0, x0, #0x568
102926d34:     	ldr	x9, [x0]
102926d38:     	blr	x9
102926d3c:     	mov	x19, x0
102926d40:     	ldrb	w9, [x0, #0x48]
102926d44:     	cmp	w9, #0x1
102926d48:     	b.eq	0x102926e14 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x274>
102926d4c:     	cmp	w9, #0x2
102926d50:     	b.ne	0x102926db8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x218>
102926d54:     	adrp	x0, 0x108043000 <_anon.8adce7851be193ad1ab4b832a11ead76.36+0x8>
102926d58:     	add	x0, x0, #0x478
102926d5c:     	bl	0x1039f9dc0 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
102926d60:     	sub	x8, x29, #0x88
102926d64:     	ldp	q0, q1, [x8]
102926d68:     	stp	q0, q1, [sp, #0xd0]
102926d6c:     	ldur	x8, [x29, #-0x68]
102926d70:     	str	x8, [sp, #0xf0]
102926d74:     	mov	x8, x27
102926d78:     	ldrb	w9, [sp, #0xd0]
102926d7c:     	cmp	w9, #0x8
102926d80:     	b.ne	0x102926cd0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x130>
102926d84:     	mov	x0, x19
102926d88:     	mov	x13, x21
102926d8c:     	str	x13, [x0, #0xd0]
102926d90:     	mov	w9, #0x8                ; =8
102926d94:     	strb	w9, [x8]
102926d98:     	add	sp, sp, #0x1a0
102926d9c:     	ldp	x29, x30, [sp, #0x50]
102926da0:     	ldp	x20, x19, [sp, #0x40]
102926da4:     	ldp	x22, x21, [sp, #0x30]
102926da8:     	ldp	x24, x23, [sp, #0x20]
102926dac:     	ldp	x26, x25, [sp, #0x10]
102926db0:     	ldp	x28, x27, [sp], #0x60
102926db4:     	ret
102926db8:     	stp	x1, x15, [sp, #0x10]
102926dbc:     	adrp	x1, 0x102915000 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTmjENvYB15_NtNtBa_3cmp10PartialOrd2ltECs1qJAwyMG1lC_11mech_engine+0x4ec>
102926dc0:     	add	x1, x1, #0xf68
102926dc4:     	mov	x0, x19
102926dc8:     	str	x8, [sp, #0x20]
102926dcc:     	stp	x6, x13, [sp, #0x50]
102926dd0:     	stp	x14, x7, [sp, #0x30]
102926dd4:     	str	x2, [sp, #0x8]
102926dd8:     	stp	x3, x4, [sp, #0x40]
102926ddc:     	str	w5, [sp, #0x2c]
102926de0:     	stp	x12, x11, [sp, #0x60]
102926de4:     	str	x10, [sp, #0x70]
102926de8:     	bl	0x102e66618 <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
102926dec:     	ldp	x11, x10, [sp, #0x68]
102926df0:     	ldp	x13, x12, [sp, #0x58]
102926df4:     	ldp	x7, x3, [sp, #0x38]
102926df8:     	ldp	x4, x6, [sp, #0x48]
102926dfc:     	ldr	w5, [sp, #0x2c]
102926e00:     	ldp	x2, x1, [sp, #0x8]
102926e04:     	ldp	x15, x8, [sp, #0x18]
102926e08:     	ldr	x14, [sp, #0x30]
102926e0c:     	mov	w9, #0x1                ; =1
102926e10:     	strb	w9, [x19, #0x48]
102926e14:     	str	x10, [sp, #0x70]
102926e18:     	ldr	x9, [x19]
102926e1c:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
102926e20:     	cmp	x9, x10
102926e24:     	b.hs	0x102927034 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x494>
102926e28:     	add	x10, x9, #0x1
102926e2c:     	str	x10, [x19]
102926e30:     	ldr	x10, [x19, #0x8]
102926e34:     	cbz	x10, 0x102926edc <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x33c>
102926e38:     	stp	x12, x11, [sp, #0x60]
102926e3c:     	ldr	x11, [x10, #0x10]
102926e40:     	mov	x12, #0x7fffffffffffffff ; =9223372036854775807
102926e44:     	cmp	x11, x12
102926e48:     	b.hs	0x102927040 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x4a0>
102926e4c:     	ldr	x10, [x10, #0x58]
102926e50:     	str	x9, [x19]
102926e54:     	ldr	x9, [sp, #0xc8]
102926e58:     	cmp	x10, x9
102926e5c:     	b.ne	0x102926ee0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x340>
102926e60:     	stp	x7, x3, [sp, #0x38]
102926e64:     	stp	x4, x6, [sp, #0x48]
102926e68:     	str	w5, [sp, #0x2c]
102926e6c:     	str	x14, [sp, #0x30]
102926e70:     	mov	x19, x8
102926e74:     	stp	x21, x13, [x29, #-0xf0]
102926e78:     	str	x13, [sp, #0x58]
102926e7c:     	stp	x24, x2, [x29, #-0xe0]
102926e80:     	mov	x24, x2
102926e84:     	stp	x26, x20, [x29, #-0xd0]
102926e88:     	ldr	x8, [sp, #0xc0]
102926e8c:     	stp	x28, x8, [x29, #-0xc0]
102926e90:     	stp	x25, x1, [x29, #-0xb0]
102926e94:     	mov	x26, x1
102926e98:     	stp	x22, x23, [x29, #-0xa0]
102926e9c:     	mov	x20, x15
102926ea0:     	stur	x15, [x29, #-0x90]
102926ea4:     	sub	x8, x29, #0x88
102926ea8:     	sub	x0, x29, #0xf0
102926eac:     	bl	0x102933eac <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget20observe_control_work>
102926eb0:     	ldurb	w8, [x29, #-0x88]
102926eb4:     	cmp	w8, #0x8
102926eb8:     	b.ne	0x102926ee8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x348>
102926ebc:     	cmp	x27, #0x1
102926ec0:     	mov	x8, x19
102926ec4:     	ldr	x11, [sp, #0xb8]
102926ec8:     	b.ne	0x102926f00 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x360>
102926ecc:     	cmp	x23, x11
102926ed0:     	b.ls	0x102926f00 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x360>
102926ed4:     	mov	w9, #0x0                ; =0
102926ed8:     	b	0x102927018 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102926edc:     	str	x9, [x19]
102926ee0:     	strb	wzr, [x8]
102926ee4:     	b	0x102926d98 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
102926ee8:     	sub	x8, x29, #0x88
102926eec:     	ldp	q0, q1, [x8]
102926ef0:     	stp	q0, q1, [x19]
102926ef4:     	ldur	x8, [x29, #-0x68]
102926ef8:     	str	x8, [x19, #0x20]
102926efc:     	b	0x102926d98 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
102926f00:     	ldp	x9, x11, [sp, #0xa8]
102926f04:     	cmp	x9, #0x1
102926f08:     	b.ne	0x102926f20 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x380>
102926f0c:     	cmp	x28, x11
102926f10:     	b.ls	0x102926f20 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x380>
102926f14:     	mov	w9, #0x2                ; =2
102926f18:     	mov	x23, x28
102926f1c:     	b	0x102927018 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102926f20:     	ldp	x9, x11, [sp, #0x98]
102926f24:     	cmp	x9, #0x1
102926f28:     	b.ne	0x102926f40 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3a0>
102926f2c:     	cmp	x25, x11
102926f30:     	b.ls	0x102926f40 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3a0>
102926f34:     	mov	w9, #0x3                ; =3
102926f38:     	mov	x23, x25
102926f3c:     	b	0x102927018 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102926f40:     	ldr	x9, [sp, #0x90]
102926f44:     	cmp	x9, #0x1
102926f48:     	ldr	x11, [sp, #0x70]
102926f4c:     	b.ne	0x102926f64 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3c4>
102926f50:     	cmp	x22, x11
102926f54:     	b.ls	0x102926f64 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3c4>
102926f58:     	mov	w9, #0x4                ; =4
102926f5c:     	mov	x23, x22
102926f60:     	b	0x102927018 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102926f64:     	ldr	x9, [sp, #0x88]
102926f68:     	cmp	x9, #0x1
102926f6c:     	ldr	x11, [sp, #0x68]
102926f70:     	b.ne	0x102926f88 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3e8>
102926f74:     	cmp	x21, x11
102926f78:     	b.ls	0x102926f88 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3e8>
102926f7c:     	mov	w9, #0x5                ; =5
102926f80:     	mov	x23, x21
102926f84:     	b	0x102927018 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102926f88:     	ldr	x9, [sp, #0x80]
102926f8c:     	cmp	x9, #0x1
102926f90:     	ldp	x11, x13, [sp, #0x50]
102926f94:     	b.ne	0x102926fac <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x40c>
102926f98:     	cmp	x13, x11
102926f9c:     	b.ls	0x102926fac <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x40c>
102926fa0:     	mov	w9, #0x6                ; =6
102926fa4:     	mov	x23, x13
102926fa8:     	b	0x102927018 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102926fac:     	ldr	x9, [sp, #0x60]
102926fb0:     	cmp	x9, #0x1
102926fb4:     	ldr	x11, [sp, #0x48]
102926fb8:     	b.ne	0x102926fd0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x430>
102926fbc:     	cmp	x24, x11
102926fc0:     	b.ls	0x102926fd0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x430>
102926fc4:     	mov	w9, #0x7                ; =7
102926fc8:     	mov	x23, x24
102926fcc:     	b	0x102927018 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102926fd0:     	ldp	x9, x11, [sp, #0x38]
102926fd4:     	cmp	x9, #0x1
102926fd8:     	b.ne	0x102926ff4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x454>
102926fdc:     	mov	x24, x26
102926fe0:     	cmp	x26, x11
102926fe4:     	b.ls	0x102926ff4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x454>
102926fe8:     	mov	w9, #0x8                ; =8
102926fec:     	mov	x23, x24
102926ff0:     	b	0x102927018 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102926ff4:     	ldr	w9, [sp, #0x2c]
102926ff8:     	cmp	w9, #0x1
102926ffc:     	ldr	x0, [sp, #0x78]
102927000:     	ldr	x11, [sp, #0x30]
102927004:     	b.ne	0x102926d8c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1ec>
102927008:     	cmp	w11, w20
10292700c:     	b.hs	0x102926d8c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1ec>
102927010:     	mov	w23, w20
102927014:     	mov	w9, #0xa                ; =10
102927018:     	mov	w10, #0x6               ; =6
10292701c:     	strb	w10, [x8]
102927020:     	strb	w9, [x8, #0x1]
102927024:     	mov	w9, #0x1                ; =1
102927028:     	strb	w9, [x8, #0x2]
10292702c:     	stp	x23, x11, [x8, #0x8]
102927030:     	b	0x102926d98 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
102927034:     	adrp	x0, 0x108044000 <_anon.8adce7851be193ad1ab4b832a11ead76.258+0x38>
102927038:     	add	x0, x0, #0x9b8
10292703c:     	bl	0x1039fa474 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102927040:     	adrp	x0, 0x108044000 <_anon.8adce7851be193ad1ab4b832a11ead76.258+0x38>
102927044:     	add	x0, x0, #0x9d0
102927048:     	bl	0x1039fa474 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
10292704c:     	brk	#0x1
102927050:     	ldr	x8, [x19]
102927054:     	sub	x8, x8, #0x1
102927058:     	str	x8, [x19]
10292705c:     	bl	0x1039fb93c <dyld_stub_binder+0x1039fb93c>
