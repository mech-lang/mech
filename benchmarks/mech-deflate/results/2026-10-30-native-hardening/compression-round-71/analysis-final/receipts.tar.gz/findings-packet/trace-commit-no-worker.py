"""Trace the actual R71 no-worker helper path, without executable sampling."""
from pathlib import Path
import json,re,sys
r=Path(sys.argv[1]);d=json.loads((r/'host-assembly/after/audit.json').read_text());x=next(x for x in d['regions'] if x['needle']=='commit-debit');by={i['address']:i for i in x['instructions']};at=x['start'];visited=[]
while True:
 row=by[at];visited.append(row)
 if row['opcode']=='ret':break
 if row['opcode']=='cbz':
  assert row['operands'].startswith('x8, ');at=int(re.search(r'0x[0-9a-f]+',row['operands']).group(),16)
 elif row['opcode']=='b':at=int(re.search(r'0x[0-9a-f]+',row['operands']).group(),16)
 else:at+=4
 assert len(visited)<100
assert visited[0]['opcode']=='sub' and visited[0]['operands']=='sp, sp, #0x90'
f={'worker_sha256':d['worker_sha256'],'symbol':x['symbol'],'assumptions':['The account has no shared worker, as in the complete single-thread compression witness.','Follow the first cbz (worker pointer absent), then unconditional local branch and return.'],'own_hot_path_static_instructions':len(visited),'stack_frame_bytes':144,'instructions':visited,'scope':'Path-conditioned static assembly only, not a hardware per-function counter. The GPU boundary independently records 39030 successful compute-debit attempts; generic callers may also enter this shared helper. Do not attribute the whole 1319185.5-instruction regression by multiplying static counts or samples.'}
(r/'findings-packet/commit-no-worker-path.json').write_text(json.dumps(f,indent=2)+'\n');print(len(visited))
