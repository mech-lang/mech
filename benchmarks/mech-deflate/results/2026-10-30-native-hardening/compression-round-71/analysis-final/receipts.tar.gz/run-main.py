"""Fresh paired timing immediately after focused semantics; remaining checks follow."""
from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent
for phase in ['parent','after']:
 for name,count in [('new-compute',4),('full-planner',22)]:
  d=json.loads((r/('engine-'+phase)/(name+'.json')).read_text());assert d['exit']==0 and d['executed_tests']==count
assert (r/'engine-parent/budget-inventory.stdout').read_text()==(r/'engine-after/budget-inventory.stdout').read_text()
for name,args in [('linked-build.py',['after']),('run-primary.py',[]),('counters.py',[]),('sites.py',['before']),('sites.py',['after']),('profile-isolated.py',[]),('profile-reference.py',[]),('units.py',[]),('qualify-all.py',[]),('type-architecture.py',[]),('non-native.py',[]),('instruction-windows.py',[]),('host-assembly.py',[])]:
 print('START',name,flush=True);subprocess.run(['python3',str(r/name),*args],check=True);print('DONE',name,flush=True)
(r/'DIAGNOSTIC_RUN_ALLOWED').write_text('All primary/control timing and compiler builds complete.\n')
subprocess.run(['python3',str(r/'diagnostic-counts.py')],check=True)
