"""Separate complete-call instructions into linked entry+callbacks and outside work.
Run after all primary/control timing. Two counter reads per complete entry, never
per source loop. A diagnostic trampoline calls the exact pinned entry unchanged.
"""
from pathlib import Path
import hashlib,json,re,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'instruction-windows';p.mkdir()
source='''#include "USAGE_SOURCE"
static struct bench_usage entry_start;
static uint64_t entry_instructions, entry_cycles, entry_calls;
static unsigned entry_depth;
void bench_scope_reset(void) { entry_instructions=entry_cycles=entry_calls=entry_depth=0; }
int bench_scope_begin(void) { if(entry_depth) return -1; entry_depth=1; return bench_read_usage(&entry_start); }
int bench_scope_end(void) { struct bench_usage after; if(entry_depth!=1) return -2; int code=bench_read_usage(&after); if(code) return code; entry_instructions+=after.instructions-entry_start.instructions; entry_cycles+=after.cycles-entry_start.cycles; entry_calls++; entry_depth=0; return 0; }
void bench_scope_read(uint64_t *instructions,uint64_t *cycles,uint64_t *calls) { *instructions=entry_instructions;*cycles=entry_cycles;*calls=entry_calls; }
'''.replace('USAGE_SOURCE',str(r/'counters/usage.c'))
(p/'scope.c').write_text(source)
module='''unsafe extern "C" { fn bench_scope_reset(); fn bench_scope_begin()->i32; fn bench_scope_end()->i32; fn bench_scope_read(i:*mut u64,c:*mut u64,n:*mut u64); }
pub fn reset(){unsafe{bench_scope_reset()}}
pub fn begin(){assert_eq!(unsafe{bench_scope_begin()},0)}
pub fn end(){assert_eq!(unsafe{bench_scope_end()},0)}
pub fn read()->(u64,u64,u64){let(mut i,mut c,mut n)=(0,0,0);unsafe{bench_scope_read(&mut i,&mut c,&mut n)};(i,c,n)}
pub fn calibration(){let mut values=Vec::new();for _ in 0..101{reset();begin();end();values.push(read());}values.sort();eprintln!("ENTRY_SCOPE_CALIBRATION {}",serde_json::json!({"observations":101,"median_instructions":values[50].0,"median_cycles":values[50].1,"entry_calls":values[50].2,"scope":"Empty begin/end; raw results are retained, not subtracted from primary or window counters."}));}
'''
(p/'entry_probe.rs').write_text(module)
def run(label,command):
 at=time.monotonic();q=subprocess.run(command,cwd=w,capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 row={'command':command,'exit':q.returncode,'seconds':time.monotonic()-at,'scope':'Diagnostic only, excluded from all primary/control timing. Unchanged same-build linked entry behind a counter trampoline.'};(p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 if q.returncode:print(q.stdout[-2000:]+q.stderr[-5000:],flush=True)
 q.check_returncode();return q
run('scope-build',['clang','-O3','-c',str(p/'scope.c'),'-o',str(p/'scope.o')])
for label in ['before','after']:
 base=json.loads((r/'counters'/label/'cpu-build.json').read_text());s=(r/'counters'/label/'cpu.rs').read_text();binding=json.loads((r/'linked-primary'/label/'binding.json').read_text())
 for name,pin in binding['pins'].items():assert hashlib.sha256((r/'linked-primary'/label/name).read_bytes()).hexdigest()==pin['sha256']
 needle='&LINKED_IDENTITY,linked_entry';assert s.count(needle)==1;s=s.replace(needle,'&LINKED_IDENTITY,diagnostic_entry')
 wrapper='''#[path = "MODULE"] mod entry_probe;
unsafe extern "C" fn diagnostic_entry(frame:*mut std::ffi::c_void)->u64 {
 entry_probe::begin();
 // SAFETY: The exact pinned build-owned entry and frame ABI are unchanged;
 // only nonallocating diagnostic counter reads surround this synchronous call.
 let result=unsafe {linked_entry(frame)};
 entry_probe::end();result
}
'''.replace('MODULE',str(p/'entry_probe.rs'))
 s=wrapper+s;s=s.replace('fn main() {','fn main() { entry_probe::calibration();',1)
 needle='eprintln!("MEASURING {sample}");let cpu_before';assert s.count(needle)==1;s=s.replace(needle,'entry_probe::reset();'+needle)
 needle='let cpu_after=cpu_usage::read();';assert s.count(needle)==1;s=s.replace(needle,needle+'let (entry_instructions,entry_cycles,entry_calls)=entry_probe::read();')
 needle='serde_json::json!({"instructions":cpu_after.instructions-cpu_before.instructions';assert s.count(needle)==1
 s=s.replace(needle,'serde_json::json!({"entry_instructions":entry_instructions,"entry_cycles":entry_cycles,"entry_calls":entry_calls,"outside_entry_instructions":(cpu_after.instructions-cpu_before.instructions).checked_sub(entry_instructions).unwrap(),"outside_entry_cycles":(cpu_after.cycles-cpu_before.cycles).checked_sub(entry_cycles).unwrap(),"instructions":cpu_after.instructions-cpu_before.instructions')
 (p/(label+'.rs')).write_text(s);cmd=base['command'].copy();cmd[-3]=str(p/(label+'.rs'));cmd[-1]=str(p/('worker-'+label));cmd=[a.replace('link-arg='+str(r/'counters/usage.o'),'link-arg='+str(p/'scope.o')) for a in cmd]
 run(label+'-build',cmd);q=run(label,[cmd[-1],'/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc','32'])
 rows=[json.loads(x) for x in q.stdout.splitlines() if x.startswith('{')];selected=[x for x in rows if not x['warmup'] and not x['profile']];assert len(selected)==32
 assert all(x['exact_reference'] and x['independent_inflation'] and x['capacity']==13 and x['work']==60260219686 and x['entry_calls']>0 and x['entry_instructions']+x['outside_entry_instructions']==x['instructions'] for x in selected)
 assert q.stderr.endswith('CLEANUP bytes=0 nodes=0\n')
 (p/(label+'-binding.json')).write_text(json.dumps({'compiler_source':binding['compiler_source'],'libraries':binding['libraries'],'artifact_pins':binding['pins'],'worker_sha256':hashlib.sha256(Path(cmd[-1]).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(s.encode()).hexdigest(),'observations':32,'scope':'Diagnostic entry trampoline adds two whole-entry reads, never per-loop instrumentation. All values/permissions/work/output remain the same. Entry includes its host callbacks; outside combines setup and cleanup.'},indent=2)+'\n')
 subprocess.run(['python3',str(r/'archive.py'),'instruction-windows-'+label,*map(str,[x for x in p.iterdir() if x.is_file() and x.suffix not in {'.o'} and not x.name.startswith('worker-')]),str(r/'instruction-windows.py')],check=True)
 Path(cmd[-1]).unlink();print('INSTRUCTION_WINDOWS',label,32,flush=True)
