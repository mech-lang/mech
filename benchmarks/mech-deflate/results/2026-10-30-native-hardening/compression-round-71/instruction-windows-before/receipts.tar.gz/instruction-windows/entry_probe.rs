unsafe extern "C" { fn bench_scope_reset(); fn bench_scope_begin()->i32; fn bench_scope_end()->i32; fn bench_scope_read(i:*mut u64,c:*mut u64,n:*mut u64); }
pub fn reset(){unsafe{bench_scope_reset()}}
pub fn begin(){assert_eq!(unsafe{bench_scope_begin()},0)}
pub fn end(){assert_eq!(unsafe{bench_scope_end()},0)}
pub fn read()->(u64,u64,u64){let(mut i,mut c,mut n)=(0,0,0);unsafe{bench_scope_read(&mut i,&mut c,&mut n)};(i,c,n)}
pub fn calibration(){let mut values=Vec::new();for _ in 0..101{reset();begin();end();values.push(read());}values.sort();eprintln!("ENTRY_SCOPE_CALIBRATION {}",serde_json::json!({"observations":101,"median_instructions":values[50].0,"median_cycles":values[50].1,"entry_calls":values[50].2,"scope":"Empty begin/end; raw results are retained, not subtracted from primary or window counters."}));}
