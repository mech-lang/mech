
/private/tmp/mech-numeric-composition-round33-20261030/confirmed-workers/after:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001014f7df8 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>:
1014f7df8: d10203ff    	sub	sp, sp, #0x80
1014f7dfc: a9045ff8    	stp	x24, x23, [sp, #0x40]
1014f7e00: a90557f6    	stp	x22, x21, [sp, #0x50]
1014f7e04: a9064ff4    	stp	x20, x19, [sp, #0x60]
1014f7e08: a9077bfd    	stp	x29, x30, [sp, #0x70]
1014f7e0c: 9101c3fd    	add	x29, sp, #0x70
1014f7e10: aa0203f4    	mov	x20, x2
1014f7e14: aa0103f5    	mov	x21, x1
1014f7e18: aa0003e9    	mov	x9, x0
1014f7e1c: aa0803f3    	mov	x19, x8
1014f7e20: f8418c08    	ldr	x8, [x0, #0x18]!
1014f7e24: b40002a8    	cbz	x8, 0x1014f7e78 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x80>
1014f7e28: f9400922    	ldr	x2, [x9, #0x10]
1014f7e2c: 910023e8    	add	x8, sp, #0x8
1014f7e30: aa0303e1    	mov	x1, x3
1014f7e34: 943894f1    	bl	0x10231d1f8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>
1014f7e38: 394023e8    	ldrb	w8, [sp, #0x8]
1014f7e3c: 7100211f    	cmp	w8, #0x8
1014f7e40: 540006e0    	b.eq	0x1014f7f1c <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x124>
1014f7e44: 394027eb    	ldrb	w11, [sp, #0x9]
1014f7e48: a94127ea    	ldp	x10, x9, [sp, #0x10]
1014f7e4c: 7100191f    	cmp	w8, #0x6
1014f7e50: 7a460960    	ccmp	w11, #0x6, #0x0, eq
1014f7e54: 540003a0    	b.eq	0x1014f7ec8 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xd0>
1014f7e58: 79401fec    	ldrh	w12, [sp, #0xe]
1014f7e5c: b840a3ed    	ldur	w13, [sp, #0xa]
1014f7e60: aa0c81ac    	orr	x12, x13, x12, lsl #32
1014f7e64: d360fd2d    	lsr	x13, x9, #32
1014f7e68: 3cc203e0    	ldur	q0, [sp, #0x20]
1014f7e6c: 3d800fe0    	str	q0, [sp, #0x30]
1014f7e70: 528000ee    	mov	w14, #0x7               ; =7
1014f7e74: 1400001c    	b	0x1014f7ee4 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xec>
1014f7e78: aa0303f6    	mov	x22, x3
1014f7e7c: aa0903f7    	mov	x23, x9
1014f7e80: 943892e5    	bl	0x10231ca14 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope>
1014f7e84: 360000c0    	tbz	w0, #0x0, 0x1014f7e9c <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xa4>
1014f7e88: 528000e8    	mov	w8, #0x7                ; =7
1014f7e8c: 39000268    	strb	w8, [x19]
1014f7e90: f900067f    	str	xzr, [x19, #0x8]
1014f7e94: b9001e7f    	str	wzr, [x19, #0x1c]
1014f7e98: 1400001e    	b	0x1014f7f10 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x118>
1014f7e9c: a940a2ea    	ldp	x10, x8, [x23, #0x8]
1014f7ea0: ab16014a    	adds	x10, x10, x22
1014f7ea4: 540004c2    	b.hs	0x1014f7f3c <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x144>
1014f7ea8: eb08015f    	cmp	x10, x8
1014f7eac: 54000369    	b.ls	0x1014f7f18 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x120>
1014f7eb0: 528000c9    	mov	w9, #0x6                ; =6
1014f7eb4: 39000269    	strb	w9, [x19]
1014f7eb8: f900066a    	str	x10, [x19, #0x8]
1014f7ebc: f9000a68    	str	x8, [x19, #0x10]
1014f7ec0: 29035275    	stp	w21, w20, [x19, #0x18]
1014f7ec4: 14000018    	b	0x1014f7f24 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x12c>
1014f7ec8: 12001d48    	and	w8, w10, #0xff
1014f7ecc: d348fd4b    	lsr	x11, x10, #8
1014f7ed0: d350fd4c    	lsr	x12, x10, #16
1014f7ed4: 528000ce    	mov	w14, #0x6               ; =6
1014f7ed8: aa0903ea    	mov	x10, x9
1014f7edc: aa1503e9    	mov	x9, x21
1014f7ee0: aa1403ed    	mov	x13, x20
1014f7ee4: 3900026e    	strb	w14, [x19]
1014f7ee8: d3781d6b    	ubfiz	x11, x11, #8, #8
1014f7eec: aa0c416b    	orr	x11, x11, x12, lsl #16
1014f7ef0: 2a0803e8    	mov	w8, w8
1014f7ef4: aa080168    	orr	x8, x11, x8
1014f7ef8: a900aa68    	stp	x8, x10, [x19, #0x8]
1014f7efc: 2a0903e8    	mov	w8, w9
1014f7f00: aa0d8108    	orr	x8, x8, x13, lsl #32
1014f7f04: f9000e68    	str	x8, [x19, #0x18]
1014f7f08: 3dc00fe0    	ldr	q0, [sp, #0x30]
1014f7f0c: 3d800a60    	str	q0, [x19, #0x20]
1014f7f10: 29065275    	stp	w21, w20, [x19, #0x30]
1014f7f14: 14000004    	b	0x1014f7f24 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x12c>
1014f7f18: f90006ea    	str	x10, [x23, #0x8]
1014f7f1c: 528001c8    	mov	w8, #0xe                ; =14
1014f7f20: 39000268    	strb	w8, [x19]
1014f7f24: a9477bfd    	ldp	x29, x30, [sp, #0x70]
1014f7f28: a9464ff4    	ldp	x20, x19, [sp, #0x60]
1014f7f2c: a94557f6    	ldp	x22, x21, [sp, #0x50]
1014f7f30: a9445ff8    	ldp	x24, x23, [sp, #0x40]
1014f7f34: 910203ff    	add	sp, sp, #0x80
1014f7f38: d65f03c0    	ret
1014f7f3c: 528000c9    	mov	w9, #0x6                ; =6
1014f7f40: 39000269    	strb	w9, [x19]
1014f7f44: 92800009    	mov	x9, #-0x1               ; =-1
1014f7f48: f9000669    	str	x9, [x19, #0x8]
1014f7f4c: 17ffffdc    	b	0x1014f7ebc <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xc4>
