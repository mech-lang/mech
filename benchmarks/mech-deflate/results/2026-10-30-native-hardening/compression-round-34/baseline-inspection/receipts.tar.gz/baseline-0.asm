
/private/tmp/mech-numeric-composition-round33-20261030/confirmed-workers/after:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001014cbdcc <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire>:
1014cbdcc: d10303ff    	sub	sp, sp, #0xc0
1014cbdd0: a9085ff8    	stp	x24, x23, [sp, #0x80]
1014cbdd4: a90957f6    	stp	x22, x21, [sp, #0x90]
1014cbdd8: a90a4ff4    	stp	x20, x19, [sp, #0xa0]
1014cbddc: a90b7bfd    	stp	x29, x30, [sp, #0xb0]
1014cbde0: 9102c3fd    	add	x29, sp, #0xb0
1014cbde4: aa0803f3    	mov	x19, x8
1014cbde8: 2a0203e8    	mov	w8, w2
1014cbdec: f9400429    	ldr	x9, [x1, #0x8]
1014cbdf0: eb08013f    	cmp	x9, x8
1014cbdf4: 54000449    	b.ls	0x1014cbe7c <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0xb0>
1014cbdf8: f9400029    	ldr	x9, [x1]
1014cbdfc: 8b081528    	add	x8, x9, x8, lsl #5
1014cbe00: f9400109    	ldr	x9, [x8]
1014cbe04: f100053f    	cmp	x9, #0x1
1014cbe08: 540003a1    	b.ne	0x1014cbe7c <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0xb0>
1014cbe0c: f9400c22    	ldr	x2, [x1, #0x18]
1014cbe10: a940d115    	ldp	x21, x20, [x8, #0x8]
1014cbe14: eb15029f    	cmp	x20, x21
1014cbe18: fa422282    	ccmp	x20, x2, #0x2, hs
1014cbe1c: 54000bc8    	b.hi	0x1014cbf94 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x1c8>
1014cbe20: aa0003f6    	mov	x22, x0
1014cbe24: f9400837    	ldr	x23, [x1, #0x10]
1014cbe28: f9400d09    	ldr	x9, [x8, #0x18]
1014cbe2c: 910103e8    	add	x8, sp, #0x40
1014cbe30: aa0303e0    	mov	x0, x3
1014cbe34: 52800001    	mov	w1, #0x0                ; =0
1014cbe38: aa0903e3    	mov	x3, x9
1014cbe3c: 9400afef    	bl	0x1014f7df8 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
1014cbe40: 394103e8    	ldrb	w8, [sp, #0x40]
1014cbe44: 7100391f    	cmp	w8, #0xe
1014cbe48: 540006a1    	b.ne	0x1014cbf1c <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x150>
1014cbe4c: f94002d6    	ldr	x22, [x22]
1014cbe50: b40008d6    	cbz	x22, 0x1014cbf68 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x19c>
1014cbe54: eb1402bf    	cmp	x21, x20
1014cbe58: 540005c0    	b.eq	0x1014cbf10 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x144>
1014cbe5c: 8b1506a8    	add	x8, x21, x21, lsl #1
1014cbe60: d37df108    	lsl	x8, x8, #3
1014cbe64: 8b170109    	add	x9, x8, x23
1014cbe68: 91002135    	add	x21, x9, #0x8
1014cbe6c: 52800309    	mov	w9, #0x18               ; =24
1014cbe70: cb0803e8    	neg	x8, x8
1014cbe74: 9b092297    	madd	x23, x20, x9, x8
1014cbe78: 1400000e    	b	0x1014cbeb0 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0xe4>
1014cbe7c: 3900127f    	strb	wzr, [x19, #0x4]
1014cbe80: 528000c8    	mov	w8, #0x6                ; =6
1014cbe84: b9000268    	str	w8, [x19]
1014cbe88: a94b7bfd    	ldp	x29, x30, [sp, #0xb0]
1014cbe8c: a94a4ff4    	ldp	x20, x19, [sp, #0xa0]
1014cbe90: a94957f6    	ldp	x22, x21, [sp, #0x90]
1014cbe94: a9485ff8    	ldp	x24, x23, [sp, #0x80]
1014cbe98: 910303ff    	add	sp, sp, #0xc0
1014cbe9c: d65f03c0    	ret
1014cbea0: f900029f    	str	xzr, [x20]
1014cbea4: 910062b5    	add	x21, x21, #0x18
1014cbea8: f10062f7    	subs	x23, x23, #0x18
1014cbeac: 54000320    	b.eq	0x1014cbf10 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x144>
1014cbeb0: b85f82a8    	ldur	w8, [x21, #-0x8]
1014cbeb4: 36000188    	tbz	w8, #0x0, 0x1014cbee4 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x118>
1014cbeb8: f9407ac1    	ldr	x1, [x22, #0xf0]
1014cbebc: f94002a0    	ldr	x0, [x21]
1014cbec0: eb01001f    	cmp	x0, x1
1014cbec4: 54000722    	b.hs	0x1014cbfa8 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x1dc>
1014cbec8: f94076c8    	ldr	x8, [x22, #0xe8]
1014cbecc: 8b001914    	add	x20, x8, x0, lsl #6
1014cbed0: f9400288    	ldr	x8, [x20]
1014cbed4: b4fffe68    	cbz	x8, 0x1014cbea0 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0xd4>
1014cbed8: aa1403e0    	mov	x0, x20
1014cbedc: 97ffd6fe    	bl	0x1014c1ad4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1014cbee0: 17fffff0    	b	0x1014cbea0 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0xd4>
1014cbee4: f9408ec2    	ldr	x2, [x22, #0x118]
1014cbee8: a8c186a0    	ldp	x0, x1, [x21], #0x18
1014cbeec: eb000028    	subs	x8, x1, x0
1014cbef0: fa422022    	ccmp	x1, x2, #0x2, hs
1014cbef4: 540004a8    	b.hi	0x1014cbf88 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x1bc>
1014cbef8: f9408ac9    	ldr	x9, [x22, #0x110]
1014cbefc: 8b000d20    	add	x0, x9, x0, lsl #3
1014cbf00: d37df101    	lsl	x1, x8, #3
1014cbf04: 9464aea8    	bl	0x102df79a4 <dyld_stub_binder+0x102df79a4>
1014cbf08: f10062f7    	subs	x23, x23, #0x18
1014cbf0c: 54fffd21    	b.ne	0x1014cbeb0 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0xe4>
1014cbf10: 52800028    	mov	w8, #0x1                ; =1
1014cbf14: 39001268    	strb	w8, [x19, #0x4]
1014cbf18: 17ffffda    	b	0x1014cbe80 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0xb4>
1014cbf1c: ad4207e0    	ldp	q0, q1, [sp, #0x40]
1014cbf20: ad0007e0    	stp	q0, q1, [sp]
1014cbf24: 3dc01be2    	ldr	q2, [sp, #0x60]
1014cbf28: 3d800be2    	str	q2, [sp, #0x20]
1014cbf2c: f9403be8    	ldr	x8, [sp, #0x70]
1014cbf30: f9001be8    	str	x8, [sp, #0x30]
1014cbf34: 3c8443e0    	stur	q0, [sp, #0x44]
1014cbf38: 3c8543e1    	stur	q1, [sp, #0x54]
1014cbf3c: 3c8643e2    	stur	q2, [sp, #0x64]
1014cbf40: f80743e8    	stur	x8, [sp, #0x74]
1014cbf44: b900027f    	str	wzr, [x19]
1014cbf48: ad4207e0    	ldp	q0, q1, [sp, #0x40]
1014cbf4c: 3c804260    	stur	q0, [x19, #0x4]
1014cbf50: 3c814261    	stur	q1, [x19, #0x14]
1014cbf54: 3dc01be0    	ldr	q0, [sp, #0x60]
1014cbf58: 3c824260    	stur	q0, [x19, #0x24]
1014cbf5c: 3cc6c3e0    	ldur	q0, [sp, #0x6c]
1014cbf60: 3d800e60    	str	q0, [x19, #0x30]
1014cbf64: 17ffffc9    	b	0x1014cbe88 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0xbc>
1014cbf68: b900027f    	str	wzr, [x19]
1014cbf6c: 52800188    	mov	w8, #0xc                ; =12
1014cbf70: d000db29    	adrp	x9, 0x103031000 <_anon.f5f719cab6f7ec7bbb8f0c87272c1a0b.174+0x67>
1014cbf74: 9105b129    	add	x9, x9, #0x16c
1014cbf78: a900a668    	stp	x8, x9, [x19, #0x8]
1014cbf7c: 52800368    	mov	w8, #0x1b               ; =27
1014cbf80: f9000e68    	str	x8, [x19, #0x18]
1014cbf84: 17ffffc1    	b	0x1014cbe88 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0xbc>
1014cbf88: f0012803    	adrp	x3, 0x1039ce000 <_anon.f5f719cab6f7ec7bbb8f0c87272c1a0b.173+0x140>
1014cbf8c: 9101c063    	add	x3, x3, #0x70
1014cbf90: 9464a9d5    	bl	0x102df66e4 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1014cbf94: d0012803    	adrp	x3, 0x1039cd000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x1a8>
1014cbf98: 913b6063    	add	x3, x3, #0xed8
1014cbf9c: aa1503e0    	mov	x0, x21
1014cbfa0: aa1403e1    	mov	x1, x20
1014cbfa4: 9464a9d0    	bl	0x102df66e4 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1014cbfa8: f0012802    	adrp	x2, 0x1039ce000 <_anon.f5f719cab6f7ec7bbb8f0c87272c1a0b.173+0x140>
1014cbfac: 91022042    	add	x2, x2, #0x88
1014cbfb0: 9464a960    	bl	0x102df6530 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014cbfb4: f900029f    	str	xzr, [x20]
1014cbfb8: 9464ae51    	bl	0x102df78fc <dyld_stub_binder+0x102df78fc>
