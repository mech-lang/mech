
/private/tmp/mech-numeric-composition-round33-20261030/confirmed-workers/after:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010231d1f8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>:
10231d1f8: d10203ff    	sub	sp, sp, #0x80
10231d1fc: a9064ff4    	stp	x20, x19, [sp, #0x60]
10231d200: a9077bfd    	stp	x29, x30, [sp, #0x70]
10231d204: 9101c3fd    	add	x29, sp, #0x70
10231d208: f9400013    	ldr	x19, [x0]
10231d20c: f9400a69    	ldr	x9, [x19, #0x10]
10231d210: 92f0000a    	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10231d214: eb0a013f    	cmp	x9, x10
10231d218: 54000362    	b.hs	0x10231d284 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x8c>
10231d21c: 9100052a    	add	x10, x9, #0x1
10231d220: f9000a6a    	str	x10, [x19, #0x10]
10231d224: f9401e6a    	ldr	x10, [x19, #0x38]
10231d228: ab01014a    	adds	x10, x10, x1
10231d22c: 54000322    	b.hs	0x10231d290 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x98>
10231d230: f9000a69    	str	x9, [x19, #0x10]
10231d234: eb02015f    	cmp	x10, x2
10231d238: 540000e9    	b.ls	0x10231d254 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x5c>
10231d23c: 5280c0c9    	mov	w9, #0x606              ; =1542
10231d240: 79000109    	strh	w9, [x8]
10231d244: 52800029    	mov	w9, #0x1                ; =1
10231d248: 39000909    	strb	w9, [x8, #0x2]
10231d24c: a900890a    	stp	x10, x2, [x8, #0x8]
10231d250: 1400004d    	b	0x10231d384 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x18c>
10231d254: d000c080    	adrp	x0, 0x103b2f000 <__mi_heap_main+0xb28>
10231d258: 9115a000    	add	x0, x0, #0x568
10231d25c: f9400009    	ldr	x9, [x0]
10231d260: d63f0120    	blr	x9
10231d264: 39412009    	ldrb	w9, [x0, #0x48]
10231d268: 7100053f    	cmp	w9, #0x1
10231d26c: 54000360    	b.eq	0x10231d2d8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xe0>
10231d270: 7100093f    	cmp	w9, #0x2
10231d274: 540001e1    	b.ne	0x10231d2b0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xb8>
10231d278: f000bec0    	adrp	x0, 0x103af8000 <_anon.686517066f445f70c1782692b9896900.7+0x565a0>
10231d27c: 9116e000    	add	x0, x0, #0x5b8
10231d280: 942b62c0    	bl	0x102df5d80 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
10231d284: 9000bee0    	adrp	x0, 0x103af9000 <_anon.b04a84545da479ddfbeac64712713f7a.156+0x230>
10231d288: 912ec000    	add	x0, x0, #0xbb0
10231d28c: 942b646a    	bl	0x102df6434 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
10231d290: 5280c0ca    	mov	w10, #0x606             ; =1542
10231d294: 7900010a    	strh	w10, [x8]
10231d298: 5280002a    	mov	w10, #0x1               ; =1
10231d29c: 3900090a    	strb	w10, [x8, #0x2]
10231d2a0: 9280000a    	mov	x10, #-0x1              ; =-1
10231d2a4: a900890a    	stp	x10, x2, [x8, #0x8]
10231d2a8: f9000a69    	str	x9, [x19, #0x10]
10231d2ac: 14000036    	b	0x10231d384 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x18c>
10231d2b0: d0003129    	adrp	x9, 0x102943000 <__RINvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7numeric17nested_assignment4bindKy5_EB8_+0xb14>
10231d2b4: 9122b129    	add	x9, x9, #0x8ac
10231d2b8: a90003e1    	stp	x1, x0, [sp]
10231d2bc: aa0903e1    	mov	x1, x9
10231d2c0: aa0803f4    	mov	x20, x8
10231d2c4: 942a1f26    	bl	0x102da4f5c <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
10231d2c8: a94003e1    	ldp	x1, x0, [sp]
10231d2cc: aa1403e8    	mov	x8, x20
10231d2d0: 52800029    	mov	w9, #0x1                ; =1
10231d2d4: 39012009    	strb	w9, [x0, #0x48]
10231d2d8: f9401009    	ldr	x9, [x0, #0x20]
10231d2dc: 92f0000a    	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10231d2e0: eb0a013f    	cmp	x9, x10
10231d2e4: 54000582    	b.hs	0x10231d394 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x19c>
10231d2e8: f9401409    	ldr	x9, [x0, #0x28]
10231d2ec: f100013f    	cmp	x9, #0x0
10231d2f0: fa531124    	ccmp	x9, x19, #0x4, ne
10231d2f4: 540003a1    	b.ne	0x10231d368 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x170>
10231d2f8: aa0803f4    	mov	x20, x8
10231d2fc: f9400a68    	ldr	x8, [x19, #0x10]
10231d300: b5000508    	cbnz	x8, 0x10231d3a0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1a8>
10231d304: aa0103e2    	mov	x2, x1
10231d308: 92800008    	mov	x8, #-0x1               ; =-1
10231d30c: f9000a68    	str	x8, [x19, #0x10]
10231d310: 3dc00c00    	ldr	q0, [x0, #0x30]
10231d314: 3d8007e0    	str	q0, [sp, #0x10]
10231d318: f9402008    	ldr	x8, [x0, #0x40]
10231d31c: f90013e8    	str	x8, [sp, #0x20]
10231d320: 9100e3e0    	add	x0, sp, #0x38
10231d324: 91006261    	add	x1, x19, #0x18
10231d328: 910043e4    	add	x4, sp, #0x10
10231d32c: d2800003    	mov	x3, #0x0                ; =0
10231d330: 940061db    	bl	0x102335a9c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits>
10231d334: f9400a68    	ldr	x8, [x19, #0x10]
10231d338: 91000508    	add	x8, x8, #0x1
10231d33c: f9000a68    	str	x8, [x19, #0x10]
10231d340: 3940e3e9    	ldrb	w9, [sp, #0x38]
10231d344: 3cc393e0    	ldur	q0, [sp, #0x39]
10231d348: 3cc493e1    	ldur	q1, [sp, #0x49]
10231d34c: ad0087e0    	stp	q0, q1, [sp, #0x10]
10231d350: f9402fe8    	ldr	x8, [sp, #0x58]
10231d354: f802f3e8    	stur	x8, [sp, #0x2f]
10231d358: 7100253f    	cmp	w9, #0x9
10231d35c: aa1403e8    	mov	x8, x20
10231d360: 54000061    	b.ne	0x10231d36c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x174>
10231d364: 17ffffc5    	b	0x10231d278 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x80>
10231d368: 52800009    	mov	w9, #0x0                ; =0
10231d36c: 39000109    	strb	w9, [x8]
10231d370: ad4087e0    	ldp	q0, q1, [sp, #0x10]
10231d374: 3c801100    	stur	q0, [x8, #0x1]
10231d378: 3c811101    	stur	q1, [x8, #0x11]
10231d37c: f842f3e9    	ldur	x9, [sp, #0x2f]
10231d380: f9001109    	str	x9, [x8, #0x20]
10231d384: a9477bfd    	ldp	x29, x30, [sp, #0x70]
10231d388: a9464ff4    	ldp	x20, x19, [sp, #0x60]
10231d38c: 910203ff    	add	sp, sp, #0x80
10231d390: d65f03c0    	ret
10231d394: 9000bee0    	adrp	x0, 0x103af9000 <_anon.b04a84545da479ddfbeac64712713f7a.156+0x230>
10231d398: 912da000    	add	x0, x0, #0xb68
10231d39c: 942b6426    	bl	0x102df6434 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
10231d3a0: 9000bee0    	adrp	x0, 0x103af9000 <_anon.b04a84545da479ddfbeac64712713f7a.156+0x230>
10231d3a4: 912e0000    	add	x0, x0, #0xb80
10231d3a8: 942b6417    	bl	0x102df6404 <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
10231d3ac: f9400a68    	ldr	x8, [x19, #0x10]
10231d3b0: 91000508    	add	x8, x8, #0x1
10231d3b4: f9000a68    	str	x8, [x19, #0x10]
10231d3b8: 942b6951    	bl	0x102df78fc <dyld_stub_binder+0x102df78fc>
