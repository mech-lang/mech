
/private/tmp/mech-deflate-profiling-20261028/roc-profile:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010001e298 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast>:
10001e298: 6db82beb    	stp	d11, d10, [sp, #-0x80]!
10001e29c: 6d0123e9    	stp	d9, d8, [sp, #0x10]
10001e2a0: a9026ffc    	stp	x28, x27, [sp, #0x20]
10001e2a4: a90367fa    	stp	x26, x25, [sp, #0x30]
10001e2a8: a9045ff8    	stp	x24, x23, [sp, #0x40]
10001e2ac: a90557f6    	stp	x22, x21, [sp, #0x50]
10001e2b0: a9064ff4    	stp	x20, x19, [sp, #0x60]
10001e2b4: a9077bfd    	stp	x29, x30, [sp, #0x70]
10001e2b8: d14007ff    	sub	sp, sp, #0x1, lsl #12   ; =0x1000
10001e2bc: f90003ff    	str	xzr, [sp]
10001e2c0: d13783ff    	sub	sp, sp, #0xde0
10001e2c4: f90003ff    	str	xzr, [sp]
10001e2c8: f9011fe0    	str	x0, [sp, #0x238]
10001e2cc: a940302b    	ldp	x11, x12, [x1]
10001e2d0: a940647a    	ldp	x26, x25, [x3]
10001e2d4: f940087b    	ldr	x27, [x3, #0x10]
10001e2d8: 12001c48    	and	w8, w2, #0xff
10001e2dc: f9019feb    	str	x11, [sp, #0x338]
10001e2e0: f901a3ec    	str	x12, [sp, #0x340]
10001e2e4: 3400e7e8    	cbz	w8, 0x10001ffe0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1d48>
10001e2e8: d37e1448    	ubfiz	x8, x2, #2, #6
10001e2ec: 528006e9    	mov	w9, #0x37               ; =55
10001e2f0: cb080128    	sub	x8, x9, x8
10001e2f4: eb0c011f    	cmp	x8, x12
10001e2f8: 5400e742    	b.hs	0x10001ffe0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1d48>
10001e2fc: 914007f5    	add	x21, sp, #0x1, lsl #12  ; =0x1000
10001e300: 9122e2b5    	add	x21, x21, #0x8b8
10001e304: f9400828    	ldr	x8, [x1, #0x10]
10001e308: f9013fe8    	str	x8, [sp, #0x278]
10001e30c: 12001c48    	and	w8, w2, #0xff
10001e310: 7100051f    	cmp	w8, #0x1
10001e314: 5400e921    	b.ne	0x100020038 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1da0>
10001e318: f1040588    	subs	x8, x12, #0x101
10001e31c: 9a8833e8    	csel	x8, xzr, x8, lo
10001e320: f901afe8    	str	x8, [sp, #0x358]
10001e324: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10001e328: 91240000    	add	x0, x0, #0x900
10001e32c: aa0c03f3    	mov	x19, x12
10001e330: 97ffee87    	bl	0x100019d4c <_roc__pf8d88d29f38eeb441b6a5ad4fe5ffba5.fast>
10001e334: 528270e8    	mov	w8, #0x1387             ; =4999
10001e338: 8b080268    	add	x8, x19, x8
10001e33c: d28b2969    	mov	x9, #0x594b             ; =22859
10001e340: f2a710c9    	movk	x9, #0x3886, lsl #16
10001e344: f2d8bac9    	movk	x9, #0xc5d6, lsl #32
10001e348: f2e68da9    	movk	x9, #0x346d, lsl #48
10001e34c: 9bc97d08    	umulh	x8, x8, x9
10001e350: d34afd08    	lsr	x8, x8, #10
10001e354: f100051f    	cmp	x8, #0x1
10001e358: 9a9f8508    	csinc	x8, x8, xzr, hi
10001e35c: 8b080908    	add	x8, x8, x8, lsl #2
10001e360: 8b130103    	add	x3, x8, x19
10001e364: 3600005b    	tbz	w27, #0x0, 0x10001e36c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xd4>
10001e368: 14003757    	b	0x10002c0c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xde2c>
10001e36c: d341ff68    	lsr	x8, x27, #1
10001e370: cb190108    	sub	x8, x8, x25
10001e374: eb03011f    	cmp	x8, x3
10001e378: 5406ea63    	b.lo	0x10002c0c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xde2c>
10001e37c: f9014bfb    	str	x27, [sp, #0x290]
10001e380: 52800508    	mov	w8, #0x28               ; =40
10001e384: 72a00048    	movk	w8, #0x2, lsl #16
10001e388: 91002100    	add	x0, x8, #0x8
10001e38c: 52800101    	mov	w1, #0x8                ; =8
10001e390: 97ff913c    	bl	0x100002880 <_roc_alloc>
10001e394: aa0003f7    	mov	x23, x0
10001e398: 78008eff    	strh	wzr, [x23, #0x8]!
10001e39c: 52800028    	mov	w8, #0x1                ; =1
10001e3a0: f9000008    	str	x8, [x0]
10001e3a4: f94002e9    	ldr	x9, [x23]
10001e3a8: aa0003e8    	mov	x8, x0
10001e3ac: f800ad09    	str	x9, [x8, #0xa]!
10001e3b0: f800c009    	stur	x9, [x0, #0xc]
10001e3b4: f800e009    	stur	x9, [x0, #0xe]
10001e3b8: f9000809    	str	x9, [x0, #0x10]
10001e3bc: 928002a9    	mov	x9, #-0x16              ; =-22
10001e3c0: f940010a    	ldr	x10, [x8]
10001e3c4: f8028d0a    	str	x10, [x8, #0x28]!
10001e3c8: a93e290a    	stp	x10, x10, [x8, #-0x20]
10001e3cc: a93f290a    	stp	x10, x10, [x8, #-0x10]
10001e3d0: 9100a129    	add	x9, x9, #0x28
10001e3d4: d345fd2a    	lsr	x10, x9, #5
10001e3d8: f13ffd5f    	cmp	x10, #0xfff
10001e3dc: 54ffff23    	b.lo	0x10001e3c0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x128>
10001e3e0: 52800508    	mov	w8, #0x28               ; =40
10001e3e4: 72a00028    	movk	w8, #0x1, lsl #16
10001e3e8: d1006100    	sub	x0, x8, #0x18
10001e3ec: 52800101    	mov	w1, #0x8                ; =8
10001e3f0: 97ff9124    	bl	0x100002880 <_roc_alloc>
10001e3f4: f9015bff    	str	xzr, [sp, #0x2b0]
10001e3f8: f90157ff    	str	xzr, [sp, #0x2a8]
10001e3fc: d280001b    	mov	x27, #0x0               ; =0
10001e400: d2800014    	mov	x20, #0x0               ; =0
10001e404: d2800013    	mov	x19, #0x0               ; =0
10001e408: 3cc602a0    	ldur	q0, [x21, #0x60]
10001e40c: 3d85a3e0    	str	q0, [sp, #0x1680]
10001e410: 5280002b    	mov	w11, #0x1               ; =1
10001e414: f94c97e8    	ldr	x8, [sp, #0x1928]
10001e418: f94c8be9    	ldr	x9, [sp, #0x1910]
10001e41c: f90b4be8    	str	x8, [sp, #0x1690]
10001e420: 3dc643e0    	ldr	q0, [sp, #0x1900]
10001e424: 3d85abe0    	str	q0, [sp, #0x16a0]
10001e428: f90b5be9    	str	x9, [sp, #0x16b0]
10001e42c: 3cc902a0    	ldur	q0, [x21, #0x90]
10001e430: 3d85b3e0    	str	q0, [sp, #0x16c0]
10001e434: f941a3ea    	ldr	x10, [sp, #0x340]
10001e438: d1000d4c    	sub	x12, x10, #0x3
10001e43c: d1001548    	sub	x8, x10, #0x5
10001e440: f9018be8    	str	x8, [sp, #0x310]
10001e444: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
10001e448: 91222108    	add	x8, x8, #0x888
10001e44c: 91006108    	add	x8, x8, #0x18
10001e450: f9010fe8    	str	x8, [sp, #0x218]
10001e454: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
10001e458: 91216108    	add	x8, x8, #0x858
10001e45c: 91006108    	add	x8, x8, #0x18
10001e460: f90103e8    	str	x8, [sp, #0x200]
10001e464: f9419fe8    	ldr	x8, [sp, #0x338]
10001e468: 91000508    	add	x8, x8, #0x1
10001e46c: f9015fe8    	str	x8, [sp, #0x2b8]
10001e470: f94cafe8    	ldr	x8, [sp, #0x1958]
10001e474: f94ca3e9    	ldr	x9, [sp, #0x1940]
10001e478: 5288004d    	mov	w13, #0x4002            ; =16386
10001e47c: f90187ed    	str	x13, [sp, #0x308]
10001e480: 5280204d    	mov	w13, #0x102             ; =258
10001e484: f90b6be8    	str	x8, [sp, #0x16d0]
10001e488: 52800408    	mov	w8, #0x20               ; =32
10001e48c: f901b7e8    	str	x8, [sp, #0x368]
10001e490: f90b7be9    	str	x9, [sp, #0x16f0]
10001e494: 3dc64fe0    	ldr	q0, [sp, #0x1930]
10001e498: 3d85bbe0    	str	q0, [sp, #0x16e0]
10001e49c: d503201f    	nop
10001e4a0: 9c0a8580    	ldr	q0, 0x100033550 <dyld_stub_binder+0x100033550>
10001e4a4: 3d809be0    	str	q0, [sp, #0x260]
10001e4a8: d503201f    	nop
10001e4ac: 9c0a85a0    	ldr	q0, 0x100033560 <dyld_stub_binder+0x100033560>
10001e4b0: 3d8097e0    	str	q0, [sp, #0x250]
10001e4b4: d503201f    	nop
10001e4b8: 9c0a85c1    	ldr	q1, 0x100033570 <dyld_stub_binder+0x100033570>
10001e4bc: d503201f    	nop
10001e4c0: 9c0a8600    	ldr	q0, 0x100033580 <dyld_stub_binder+0x100033580>
10001e4c4: 3d8093e0    	str	q0, [sp, #0x240]
10001e4c8: d503201f    	nop
10001e4cc: 9c0a8620    	ldr	q0, 0x100033590 <dyld_stub_binder+0x100033590>
10001e4d0: 3d808be0    	str	q0, [sp, #0x220]
10001e4d4: d503201f    	nop
10001e4d8: 9c0a8642    	ldr	q2, 0x1000335a0 <dyld_stub_binder+0x1000335a0>
10001e4dc: f800840b    	str	x11, [x0], #0x8
10001e4e0: f901abe0    	str	x0, [sp, #0x350]
10001e4e4: 52800515    	mov	w21, #0x28              ; =40
10001e4e8: 72a00055    	movk	w21, #0x2, lsl #16
10001e4ec: f90197ec    	str	x12, [sp, #0x328]
10001e4f0: ad1607e2    	stp	q2, q1, [sp, #0x2c0]
10001e4f4: 14000019    	b	0x10001e558 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2c0>
10001e4f8: 52800036    	mov	w22, #0x1               ; =1
10001e4fc: f941a3ea    	ldr	x10, [sp, #0x340]
10001e500: f941b3f5    	ldr	x21, [sp, #0x360]
10001e504: f94183ed    	ldr	x13, [sp, #0x300]
10001e508: 914007e9    	add	x9, sp, #0x1, lsl #12   ; =0x1000
10001e50c: 911be129    	add	x9, x9, #0x6f8
10001e510: 3ccd0120    	ldur	q0, [x9, #0xd0]
10001e514: 3d85a3e0    	str	q0, [sp, #0x1680]
10001e518: f84e0128    	ldur	x8, [x9, #0xe0]
10001e51c: f90b4be8    	str	x8, [sp, #0x1690]
10001e520: 3ccb8120    	ldur	q0, [x9, #0xb8]
10001e524: 3d85abe0    	str	q0, [sp, #0x16a0]
10001e528: f84c8128    	ldur	x8, [x9, #0xc8]
10001e52c: f90b5be8    	str	x8, [sp, #0x16b0]
10001e530: 3dc04120    	ldr	q0, [x9, #0x100]
10001e534: 3d85b3e0    	str	q0, [sp, #0x16c0]
10001e538: f9408928    	ldr	x8, [x9, #0x110]
10001e53c: f90b6be8    	str	x8, [sp, #0x16d0]
10001e540: f84f8128    	ldur	x8, [x9, #0xf8]
10001e544: f90b7be8    	str	x8, [sp, #0x16f0]
10001e548: 3cce8120    	ldur	q0, [x9, #0xe8]
10001e54c: 3d85bbe0    	str	q0, [sp, #0x16e0]
10001e550: eb0a027f    	cmp	x19, x10
10001e554: 540407c0    	b.eq	0x10002664c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x83b4>
10001e558: eb130148    	subs	x8, x10, x19
10001e55c: 54060d03    	b.lo	0x10002a6fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc464>
10001e560: aa0a03f8    	mov	x24, x10
10001e564: 528270e9    	mov	w9, #0x1387             ; =4999
10001e568: 72a00029    	movk	w9, #0x1, lsl #16
10001e56c: eb09011f    	cmp	x8, x9
10001e570: 54000083    	b.lo	0x10001e580 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2e8>
10001e574: 529fffe8    	mov	w8, #0xffff             ; =65535
10001e578: ab080278    	adds	x24, x19, x8
10001e57c: 54060b62    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10001e580: f90173f3    	str	x19, [sp, #0x2e0]
10001e584: aa0d03f3    	mov	x19, x13
10001e588: 52810680    	mov	w0, #0x834              ; =2100
10001e58c: 52800101    	mov	w1, #0x8                ; =8
10001e590: 97ff90bc    	bl	0x100002880 <_roc_alloc>
10001e594: aa0003f6    	mov	x22, x0
10001e598: b8008edf    	str	wzr, [x22, #0x8]!
10001e59c: 52800028    	mov	w8, #0x1                ; =1
10001e5a0: f9000008    	str	x8, [x0]
10001e5a4: f94002c9    	ldr	x9, [x22]
10001e5a8: aa0003e8    	mov	x8, x0
10001e5ac: f800cd09    	str	x9, [x8, #0xc]!
10001e5b0: f90153e0    	str	x0, [sp, #0x2a0]
10001e5b4: f9000809    	str	x9, [x0, #0x10]
10001e5b8: 92800269    	mov	x9, #-0x14              ; =-20
10001e5bc: f940010a    	ldr	x10, [x8]
10001e5c0: f8028d0a    	str	x10, [x8, #0x28]!
10001e5c4: a93e290a    	stp	x10, x10, [x8, #-0x20]
10001e5c8: a93f290a    	stp	x10, x10, [x8, #-0x10]
10001e5cc: 9100a129    	add	x9, x9, #0x28
10001e5d0: f11f913f    	cmp	x9, #0x7e4
10001e5d4: 54ffff43    	b.lo	0x10001e5bc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x324>
10001e5d8: 52808d00    	mov	w0, #0x468              ; =1128
10001e5dc: 52800101    	mov	w1, #0x8                ; =8
10001e5e0: 97ff90a8    	bl	0x100002880 <_roc_alloc>
10001e5e4: aa0003e9    	mov	x9, x0
10001e5e8: b8008d3f    	str	wzr, [x9, #0x8]!
10001e5ec: 52800028    	mov	w8, #0x1                ; =1
10001e5f0: f9000008    	str	x8, [x0]
10001e5f4: 91047008    	add	x8, x0, #0x11c
10001e5f8: f901a7e9    	str	x9, [sp, #0x348]
10001e5fc: f9400129    	ldr	x9, [x9]
10001e600: f800c009    	stur	x9, [x0, #0xc]
10001e604: f9000809    	str	x9, [x0, #0x10]
10001e608: f840c009    	ldur	x9, [x0, #0xc]
10001e60c: f8014009    	stur	x9, [x0, #0x14]
10001e610: 4e080d20    	dup.2d	v0, x9
10001e614: 3c82c000    	stur	q0, [x0, #0x2c]
10001e618: 3c81c000    	stur	q0, [x0, #0x1c]
10001e61c: 3c84c000    	stur	q0, [x0, #0x4c]
10001e620: 3c83c000    	stur	q0, [x0, #0x3c]
10001e624: 3c86c000    	stur	q0, [x0, #0x6c]
10001e628: 3c85c000    	stur	q0, [x0, #0x5c]
10001e62c: 3c88c000    	stur	q0, [x0, #0x8c]
10001e630: 3c87c000    	stur	q0, [x0, #0x7c]
10001e634: 3c8ac000    	stur	q0, [x0, #0xac]
10001e638: 3c89c000    	stur	q0, [x0, #0x9c]
10001e63c: 3c8cc000    	stur	q0, [x0, #0xcc]
10001e640: 3c8bc000    	stur	q0, [x0, #0xbc]
10001e644: 3c8ec000    	stur	q0, [x0, #0xec]
10001e648: 3c8dc000    	stur	q0, [x0, #0xdc]
10001e64c: 3c8fcc00    	str	q0, [x0, #0xfc]!
10001e650: 3d800400    	str	q0, [x0, #0x10]
10001e654: ad000100    	stp	q0, q0, [x8]
10001e658: ad010100    	stp	q0, q0, [x8, #0x20]
10001e65c: ad020100    	stp	q0, q0, [x8, #0x40]
10001e660: ad030100    	stp	q0, q0, [x8, #0x60]
10001e664: ad040100    	stp	q0, q0, [x8, #0x80]
10001e668: ad050100    	stp	q0, q0, [x8, #0xa0]
10001e66c: ad060100    	stp	q0, q0, [x8, #0xc0]
10001e670: ad070100    	stp	q0, q0, [x8, #0xe0]
10001e674: ad080100    	stp	q0, q0, [x8, #0x100]
10001e678: ad090100    	stp	q0, q0, [x8, #0x120]
10001e67c: ad0a0100    	stp	q0, q0, [x8, #0x140]
10001e680: ad0b0100    	stp	q0, q0, [x8, #0x160]
10001e684: ad0c0100    	stp	q0, q0, [x8, #0x180]
10001e688: ad0d0100    	stp	q0, q0, [x8, #0x1a0]
10001e68c: ad0e0100    	stp	q0, q0, [x8, #0x1c0]
10001e690: ad0f0100    	stp	q0, q0, [x8, #0x1e0]
10001e694: ad100100    	stp	q0, q0, [x8, #0x200]
10001e698: ad110100    	stp	q0, q0, [x8, #0x220]
10001e69c: ad120100    	stp	q0, q0, [x8, #0x240]
10001e6a0: ad130100    	stp	q0, q0, [x8, #0x260]
10001e6a4: ad140100    	stp	q0, q0, [x8, #0x280]
10001e6a8: ad150100    	stp	q0, q0, [x8, #0x2a0]
10001e6ac: ad160100    	stp	q0, q0, [x8, #0x2c0]
10001e6b0: ad170100    	stp	q0, q0, [x8, #0x2e0]
10001e6b4: ad180100    	stp	q0, q0, [x8, #0x300]
10001e6b8: f9019109    	str	x9, [x8, #0x320]
10001e6bc: f9019509    	str	x9, [x8, #0x328]
10001e6c0: f94187e8    	ldr	x8, [sp, #0x308]
10001e6c4: f90143fa    	str	x26, [sp, #0x280]
10001e6c8: 37000248    	tbnz	w8, #0x0, 0x10001e710 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x478>
10001e6cc: f9419fe2    	ldr	x2, [sp, #0x338]
10001e6d0: f941a3e3    	ldr	x3, [sp, #0x340]
10001e6d4: 5294f7a4    	mov	w4, #0xa7bd             ; =42941
10001e6d8: 72a3c6a4    	movk	w4, #0x1e35, lsl #16
10001e6dc: f94197e5    	ldr	x5, [sp, #0x328]
10001e6e0: 4f04a404    	movi.8h	v4, #0x80, lsl #8
10001e6e4: aa1303e6    	mov	x6, x19
10001e6e8: aa1503fe    	mov	x30, x21
10001e6ec: b4000508    	cbz	x8, 0x10001e78c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4f4>
10001e6f0: d341fd08    	lsr	x8, x8, #1
10001e6f4: f941abe9    	ldr	x9, [sp, #0x350]
10001e6f8: f85f8129    	ldur	x9, [x9, #-0x8]
10001e6fc: f100053f    	cmp	x9, #0x1
10001e700: 9a9f0108    	csel	x8, x8, xzr, eq
10001e704: f900fbe8    	str	x8, [sp, #0x1f0]
10001e708: f9019be8    	str	x8, [sp, #0x330]
10001e70c: 14000023    	b	0x10001e798 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x500>
10001e710: f27ff900    	ands	x0, x8, #0xfffffffffffffffe
10001e714: f9419fe2    	ldr	x2, [sp, #0x338]
10001e718: f941a3e3    	ldr	x3, [sp, #0x340]
10001e71c: 5294f7a4    	mov	w4, #0xa7bd             ; =42941
10001e720: 72a3c6a4    	movk	w4, #0x1e35, lsl #16
10001e724: f94197e5    	ldr	x5, [sp, #0x328]
10001e728: 4f04a404    	movi.8h	v4, #0x80, lsl #8
10001e72c: aa1303e6    	mov	x6, x19
10001e730: aa1503fe    	mov	x30, x21
10001e734: 54000220    	b.eq	0x10001e778 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4e0>
10001e738: f85f8c08    	ldr	x8, [x0, #-0x8]!
10001e73c: b40001e8    	cbz	x8, 0x10001e778 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4e0>
10001e740: 92800008    	mov	x8, #-0x1               ; =-1
10001e744: f8280008    	ldadd	x8, x8, [x0]
10001e748: f100051f    	cmp	x8, #0x1
10001e74c: 54000161    	b.ne	0x10001e778 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4e0>
10001e750: 52800101    	mov	w1, #0x8                ; =8
10001e754: 97ff9067    	bl	0x1000028f0 <_roc_dealloc>
10001e758: aa1503fe    	mov	x30, x21
10001e75c: aa1303e6    	mov	x6, x19
10001e760: 4f04a404    	movi.8h	v4, #0x80, lsl #8
10001e764: f94197e5    	ldr	x5, [sp, #0x328]
10001e768: 5294f7a4    	mov	w4, #0xa7bd             ; =42941
10001e76c: 72a3c6a4    	movk	w4, #0x1e35, lsl #16
10001e770: f941a3e3    	ldr	x3, [sp, #0x340]
10001e774: f9419fe2    	ldr	x2, [sp, #0x338]
10001e778: f900fbff    	str	xzr, [sp, #0x1f0]
10001e77c: f9019bff    	str	xzr, [sp, #0x330]
10001e780: f90187ff    	str	xzr, [sp, #0x308]
10001e784: f901abff    	str	xzr, [sp, #0x350]
10001e788: 14000004    	b	0x10001e798 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x500>
10001e78c: f900fbff    	str	xzr, [sp, #0x1f0]
10001e790: f9019bff    	str	xzr, [sp, #0x330]
10001e794: f90187ff    	str	xzr, [sp, #0x308]
10001e798: d2800001    	mov	x1, #0x0                ; =0
10001e79c: f94173fa    	ldr	x26, [sp, #0x2e0]
10001e7a0: f901b3fa    	str	x26, [sp, #0x360]
10001e7a4: f9017ff9    	str	x25, [sp, #0x2f8]
10001e7a8: f9018ff6    	str	x22, [sp, #0x318]
10001e7ac: f90193f8    	str	x24, [sp, #0x320]
10001e7b0: 1400000a    	b	0x10001e7d8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x540>
10001e7b4: 39400148    	ldrb	w8, [x10]
10001e7b8: b8687ac9    	ldr	w9, [x22, x8, lsl #2]
10001e7bc: 11000529    	add	w9, w9, #0x1
10001e7c0: b8287ac9    	str	w9, [x22, x8, lsl #2]
10001e7c4: eb18027f    	cmp	x19, x24
10001e7c8: 54009502    	b.hs	0x10001fa68 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x17d0>
10001e7cc: aa1303fa    	mov	x26, x19
10001e7d0: f140083f    	cmp	x1, #0x2, lsl #12       ; =0x2000
10001e7d4: 540094a2    	b.hs	0x10001fa68 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x17d0>
10001e7d8: cb1a0068    	sub	x8, x3, x26
10001e7dc: f104051f    	cmp	x8, #0x101
10001e7e0: 54000108    	b.hi	0x10001e800 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x568>
10001e7e4: f100111f    	cmp	x8, #0x4
10001e7e8: 54008f09    	b.ls	0x10001f9c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1730>
10001e7ec: f941b7e9    	ldr	x9, [sp, #0x368]
10001e7f0: eb08013f    	cmp	x9, x8
10001e7f4: 9a883129    	csel	x9, x9, x8, lo
10001e7f8: f901b7e9    	str	x9, [sp, #0x368]
10001e7fc: cb1a0066    	sub	x6, x3, x26
10001e800: cb140348    	sub	x8, x26, x20
10001e804: f140211f    	cmp	x8, #0x8, lsl #12       ; =0x8000
10001e808: 54000a61    	b.ne	0x10001e954 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6bc>
10001e80c: 3700027e    	tbnz	w30, #0x0, 0x10001e858 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5c0>
10001e810: b400009e    	cbz	x30, 0x10001e820 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x588>
10001e814: f85f82e8    	ldur	x8, [x23, #-0x8]
10001e818: f100051f    	cmp	x8, #0x1
10001e81c: 540001e1    	b.ne	0x10001e858 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5c0>
10001e820: d2800008    	mov	x8, #0x0                ; =0
10001e824: 8b0802e9    	add	x9, x23, x8
10001e828: ad400520    	ldp	q0, q1, [x9]
10001e82c: ad410d22    	ldp	q2, q3, [x9, #0x20]
10001e830: 6e642c00    	uqsub.8h	v0, v0, v4
10001e834: 6e642c21    	uqsub.8h	v1, v1, v4
10001e838: 6e642c42    	uqsub.8h	v2, v2, v4
10001e83c: 6e642c63    	uqsub.8h	v3, v3, v4
10001e840: ad000520    	stp	q0, q1, [x9]
10001e844: ad010d22    	stp	q2, q3, [x9, #0x20]
10001e848: 91010108    	add	x8, x8, #0x40
10001e84c: f140811f    	cmp	x8, #0x20, lsl #12      ; =0x20000
10001e850: 54fffea1    	b.ne	0x10001e824 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x58c>
10001e854: 1400003f    	b	0x10001e950 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6b8>
10001e858: aa1903f6    	mov	x22, x25
10001e85c: aa1e03f9    	mov	x25, x30
10001e860: aa0103f8    	mov	x24, x1
10001e864: aa0603fc    	mov	x28, x6
10001e868: f90eebff    	str	xzr, [sp, #0x1dd0]
10001e86c: f90ee7ff    	str	xzr, [sp, #0x1dc8]
10001e870: f90eefff    	str	xzr, [sp, #0x1dd8]
10001e874: 912683e0    	add	x0, sp, #0x9a0
10001e878: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
10001e87c: 91372021    	add	x1, x1, #0xdc8
10001e880: 52a00022    	mov	w2, #0x10000            ; =65536
10001e884: 52800043    	mov	w3, #0x2                ; =2
10001e888: 52800024    	mov	w4, #0x1                ; =1
10001e88c: 94004c6f    	bl	0x100031a48 <_list.RocList.reallocate>
10001e890: 4f04a404    	movi.8h	v4, #0x80, lsl #8
10001e894: d2800008    	mov	x8, #0x0                ; =0
10001e898: f944d3f3    	ldr	x19, [sp, #0x9a0]
10001e89c: f944dbf5    	ldr	x21, [sp, #0x9b0]
10001e8a0: cb170269    	sub	x9, x19, x23
10001e8a4: f101013f    	cmp	x9, #0x40
10001e8a8: 540001e3    	b.lo	0x10001e8e4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x64c>
10001e8ac: 910082e8    	add	x8, x23, #0x20
10001e8b0: 91008269    	add	x9, x19, #0x20
10001e8b4: 529ffc0a    	mov	w10, #0xffe0            ; =65504
10001e8b8: ad7f0500    	ldp	q0, q1, [x8, #-0x20]
10001e8bc: acc20d02    	ldp	q2, q3, [x8], #0x40
10001e8c0: 6e642c00    	uqsub.8h	v0, v0, v4
10001e8c4: 6e642c21    	uqsub.8h	v1, v1, v4
10001e8c8: 6e642c42    	uqsub.8h	v2, v2, v4
10001e8cc: 6e642c63    	uqsub.8h	v3, v3, v4
10001e8d0: ad3f0520    	stp	q0, q1, [x9, #-0x20]
10001e8d4: ac820d22    	stp	q2, q3, [x9], #0x40
10001e8d8: f100814a    	subs	x10, x10, #0x20
10001e8dc: 54fffee1    	b.ne	0x10001e8b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x620>
10001e8e0: 529ffc08    	mov	w8, #0xffe0             ; =65504
10001e8e4: b100051f    	cmn	x8, #0x1
10001e8e8: 5405f000    	b.eq	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10001e8ec: 78e87ae9    	ldrsh	w9, [x23, x8, lsl #1]
10001e8f0: 5211012a    	eor	w10, w9, #0x8000
10001e8f4: 0a493d49    	and	w9, w10, w9, lsr #15
10001e8f8: 78287a69    	strh	w9, [x19, x8, lsl #1]
10001e8fc: 91000508    	add	x8, x8, #0x1
10001e900: f140411f    	cmp	x8, #0x10, lsl #12      ; =0x10000
10001e904: 54ffff01    	b.ne	0x10001e8e4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x64c>
10001e908: f904d3f7    	str	x23, [sp, #0x9a0]
10001e90c: f904d7e8    	str	x8, [sp, #0x9a8]
10001e910: f904dbf9    	str	x25, [sp, #0x9b0]
10001e914: 912683e0    	add	x0, sp, #0x9a0
10001e918: 9400462a    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10001e91c: 4f04a404    	movi.8h	v4, #0x80, lsl #8
10001e920: aa1303f7    	mov	x23, x19
10001e924: aa1503fe    	mov	x30, x21
10001e928: f9419fe2    	ldr	x2, [sp, #0x338]
10001e92c: f941a3e3    	ldr	x3, [sp, #0x340]
10001e930: 5294f7a4    	mov	w4, #0xa7bd             ; =42941
10001e934: 72a3c6a4    	movk	w4, #0x1e35, lsl #16
10001e938: f94197e5    	ldr	x5, [sp, #0x328]
10001e93c: aa1c03e6    	mov	x6, x28
10001e940: aa1803e1    	mov	x1, x24
10001e944: aa1603f9    	mov	x25, x22
10001e948: f9418ff6    	ldr	x22, [sp, #0x318]
10001e94c: f94193f8    	ldr	x24, [sp, #0x320]
10001e950: 91402294    	add	x20, x20, #0x8, lsl #12 ; =0x8000
10001e954: 9140229c    	add	x28, x20, #0x8, lsl #12 ; =0x8000
10001e958: eb1c031f    	cmp	x24, x28
10001e95c: 9a9c3308    	csel	x8, x24, x28, lo
10001e960: f941afe9    	ldr	x9, [sp, #0x358]
10001e964: eb09011f    	cmp	x8, x9
10001e968: 9a89310a    	csel	x10, x8, x9, lo
10001e96c: 91001148    	add	x8, x10, #0x4
10001e970: eb03011f    	cmp	x8, x3
10001e974: 5406f988    	b.hi	0x10002c8a4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe60c>
10001e978: eb0a035f    	cmp	x26, x10
10001e97c: 54000862    	b.hs	0x10001ea88 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x7f0>
10001e980: d2800008    	mov	x8, #0x0                ; =0
10001e984: d280000c    	mov	x12, #0x0               ; =0
10001e988: 5280000f    	mov	w15, #0x0               ; =0
10001e98c: 52800009    	mov	w9, #0x0                ; =0
10001e990: d140228b    	sub	x11, x20, #0x8, lsl #12 ; =0x8000
10001e994: aa1a03f3    	mov	x19, x26
10001e998: aa1b03f5    	mov	x21, x27
10001e99c: 1400000b    	b	0x10001e9c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x730>
10001e9a0: aa1003e8    	mov	x8, x16
10001e9a4: aa0e03ec    	mov	x12, x14
10001e9a8: 5280000f    	mov	w15, #0x0               ; =0
10001e9ac: 3873684e    	ldrb	w14, [x2, x19]
10001e9b0: b86e7ad0    	ldr	w16, [x22, x14, lsl #2]
10001e9b4: 11000610    	add	w16, w16, #0x1
10001e9b8: b82e7ad0    	str	w16, [x22, x14, lsl #2]
10001e9bc: aa0d03f3    	mov	x19, x13
10001e9c0: eb0a027f    	cmp	x19, x10
10001e9c4: 540009c2    	b.hs	0x10001eafc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x864>
10001e9c8: aa1503fb    	mov	x27, x21
10001e9cc: 370009cf    	tbnz	w15, #0x0, 0x10001eb04 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x86c>
10001e9d0: b873684f    	ldr	w15, [x2, x19]
10001e9d4: 9100066d    	add	x13, x19, #0x1
10001e9d8: b86d684e    	ldr	w14, [x2, x13]
10001e9dc: 1b047dce    	mul	w14, w14, w4
10001e9e0: 53117dd5    	lsr	w21, w14, #17
10001e9e4: d37e7eae    	ubfiz	x14, x21, #2, #32
10001e9e8: f8ae6af0    	prfm	pstl1keep, [x23, x14]
10001e9ec: 8b1b0ae0    	add	x0, x23, x27, lsl #2
10001e9f0: 7940000e    	ldrh	w14, [x0]
10001e9f4: 79400410    	ldrh	w16, [x0, #0x2]
10001e9f8: cb140271    	sub	x17, x19, x20
10001e9fc: eb0e023f    	cmp	x17, x14
10001ea00: 52110227    	eor	w7, w17, #0x8000
10001ea04: 79000007    	strh	w7, [x0]
10001ea08: 7900040e    	strh	w14, [x0, #0x2]
10001ea0c: 54fffce2    	b.hs	0x10001e9a8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x710>
10001ea10: 8b0e0168    	add	x8, x11, x14
10001ea14: eb05011f    	cmp	x8, x5
10001ea18: 540001a2    	b.hs	0x10001ea4c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x7b4>
10001ea1c: b8686848    	ldr	w8, [x2, x8]
10001ea20: 6b0f011f    	cmp	w8, w15
10001ea24: 540001a0    	b.eq	0x10001ea58 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x7c0>
10001ea28: eb10023f    	cmp	x17, x16
10001ea2c: 54fffba2    	b.hs	0x10001e9a0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x708>
10001ea30: 8b100168    	add	x8, x11, x16
10001ea34: eb05011f    	cmp	x8, x5
10001ea38: 540001a2    	b.hs	0x10001ea6c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x7d4>
10001ea3c: b8686848    	ldr	w8, [x2, x8]
10001ea40: 6b0f011f    	cmp	w8, w15
10001ea44: 54fffae1    	b.ne	0x10001e9a0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x708>
10001ea48: 1400000c    	b	0x10001ea78 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x7e0>
10001ea4c: 52800008    	mov	w8, #0x0                ; =0
10001ea50: 6b0f011f    	cmp	w8, w15
10001ea54: 54fffea1    	b.ne	0x10001ea28 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x790>
10001ea58: 5280002f    	mov	w15, #0x1               ; =1
10001ea5c: aa1003e8    	mov	x8, x16
10001ea60: aa0e03ec    	mov	x12, x14
10001ea64: 52800029    	mov	w9, #0x1                ; =1
10001ea68: 17ffffd6    	b	0x10001e9c0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x728>
10001ea6c: 52800008    	mov	w8, #0x0                ; =0
10001ea70: 6b0f011f    	cmp	w8, w15
10001ea74: 54fff961    	b.ne	0x10001e9a0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x708>
10001ea78: 5280002f    	mov	w15, #0x1               ; =1
10001ea7c: aa1003e8    	mov	x8, x16
10001ea80: aa0e03ec    	mov	x12, x14
10001ea84: 17ffffcf    	b	0x10001e9c0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x728>
10001ea88: aa1b03f5    	mov	x21, x27
10001ea8c: ab060348    	adds	x8, x26, x6
10001ea90: 5405e2c2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10001ea94: eb03011f    	cmp	x8, x3
10001ea98: 540707a8    	b.hi	0x10002cb8c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe8f4>
10001ea9c: f10010df    	cmp	x6, #0x4
10001eaa0: 54070769    	b.ls	0x10002cb8c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe8f4>
10001eaa4: cb140348    	sub	x8, x26, x20
10001eaa8: f140211f    	cmp	x8, #0x8, lsl #12       ; =0x8000
10001eaac: 54001861    	b.ne	0x10001edb8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb20>
10001eab0: 37000a9e    	tbnz	w30, #0x0, 0x10001ec00 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x968>
10001eab4: b400009e    	cbz	x30, 0x10001eac4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x82c>
10001eab8: f85f82e8    	ldur	x8, [x23, #-0x8]
10001eabc: f100051f    	cmp	x8, #0x1
10001eac0: 54000a01    	b.ne	0x10001ec00 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x968>
10001eac4: d2800008    	mov	x8, #0x0                ; =0
10001eac8: 8b0802e9    	add	x9, x23, x8
10001eacc: ad400520    	ldp	q0, q1, [x9]
10001ead0: ad410d22    	ldp	q2, q3, [x9, #0x20]
10001ead4: 6e642c00    	uqsub.8h	v0, v0, v4
10001ead8: 6e642c21    	uqsub.8h	v1, v1, v4
10001eadc: 6e642c42    	uqsub.8h	v2, v2, v4
10001eae0: 6e642c63    	uqsub.8h	v3, v3, v4
10001eae4: ad000520    	stp	q0, q1, [x9]
10001eae8: ad010d22    	stp	q2, q3, [x9, #0x20]
10001eaec: 91010108    	add	x8, x8, #0x40
10001eaf0: f140811f    	cmp	x8, #0x20, lsl #12      ; =0x20000
10001eaf4: 54fffea1    	b.ne	0x10001eac8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x830>
10001eaf8: 140000af    	b	0x10001edb4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb1c>
10001eafc: 34000bcf    	cbz	w15, 0x10001ec74 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9dc>
10001eb00: aa1503fb    	mov	x27, x21
10001eb04: aa1303fa    	mov	x26, x19
10001eb08: eb05027f    	cmp	x19, x5
10001eb0c: 928fffe0    	mov	x0, #-0x8000            ; =-32768
10001eb10: f941a7e7    	ldr	x7, [sp, #0x348]
10001eb14: 540003c2    	b.hs	0x10001eb8c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8f4>
10001eb18: b87a684d    	ldr	w13, [x2, x26]
10001eb1c: ab06034a    	adds	x10, x26, x6
10001eb20: 1a9f37ee    	cset	w14, hs
10001eb24: 370003c9    	tbnz	w9, #0x0, 0x10001eb9c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x904>
10001eb28: 3600004e    	tbz	w14, #0x0, 0x10001eb30 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x898>
10001eb2c: 14002eef    	b	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10001eb30: eb03015f    	cmp	x10, x3
10001eb34: 5406eaa8    	b.hi	0x10002c888 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe5f0>
10001eb38: 8b080169    	add	x9, x11, x8
10001eb3c: eb09034a    	subs	x10, x26, x9
10001eb40: 5406ea49    	b.ls	0x10002c888 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe5f0>
10001eb44: f10090df    	cmp	x6, #0x24
10001eb48: 54000a22    	b.hs	0x10001ec8c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9f4>
10001eb4c: 52800089    	mov	w9, #0x4                ; =4
10001eb50: b27d012d    	orr	x13, x9, #0x8
10001eb54: 8b1a004b    	add	x11, x2, x26
10001eb58: 8b08028c    	add	x12, x20, x8
10001eb5c: 8b0c004c    	add	x12, x2, x12
10001eb60: eb0601bf    	cmp	x13, x6
10001eb64: 54001c08    	b.hi	0x10001eee4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc4c>
10001eb68: f869696d    	ldr	x13, [x11, x9]
10001eb6c: 8b09018e    	add	x14, x12, x9
10001eb70: f86069ce    	ldr	x14, [x14, x0]
10001eb74: eb0d01df    	cmp	x14, x13
10001eb78: 54001f41    	b.ne	0x10001ef60 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xcc8>
10001eb7c: b100412d    	adds	x13, x9, #0x10
10001eb80: 91002129    	add	x9, x9, #0x8
10001eb84: 54fffee3    	b.lo	0x10001eb60 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8c8>
10001eb88: 14002ed8    	b	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10001eb8c: 5280000d    	mov	w13, #0x0               ; =0
10001eb90: ab06034a    	adds	x10, x26, x6
10001eb94: 1a9f37ee    	cset	w14, hs
10001eb98: 3607fc89    	tbz	w9, #0x0, 0x10001eb28 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x890>
10001eb9c: 3600004e    	tbz	w14, #0x0, 0x10001eba4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x90c>
10001eba0: 14002ed2    	b	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10001eba4: eb03015f    	cmp	x10, x3
10001eba8: 5406e708    	b.hi	0x10002c888 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe5f0>
10001ebac: 8b0c0169    	add	x9, x11, x12
10001ebb0: eb09034a    	subs	x10, x26, x9
10001ebb4: 5406e6a9    	b.ls	0x10002c888 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe5f0>
10001ebb8: f10090df    	cmp	x6, #0x24
10001ebbc: 54000902    	b.hs	0x10001ecdc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa44>
10001ebc0: 52800089    	mov	w9, #0x4                ; =4
10001ebc4: b27d0130    	orr	x16, x9, #0x8
10001ebc8: 8b1a004e    	add	x14, x2, x26
10001ebcc: 8b0c028f    	add	x15, x20, x12
10001ebd0: 8b0f004f    	add	x15, x2, x15
10001ebd4: eb06021f    	cmp	x16, x6
10001ebd8: 54001a28    	b.hi	0x10001ef1c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc84>
10001ebdc: f86969d0    	ldr	x16, [x14, x9]
10001ebe0: 8b0901f1    	add	x17, x15, x9
10001ebe4: f8606a31    	ldr	x17, [x17, x0]
10001ebe8: eb10023f    	cmp	x17, x16
10001ebec: 54001c41    	b.ne	0x10001ef74 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xcdc>
10001ebf0: b1004130    	adds	x16, x9, #0x10
10001ebf4: 91002129    	add	x9, x9, #0x8
10001ebf8: 54fffee3    	b.lo	0x10001ebd4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x93c>
10001ebfc: 14002ebb    	b	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10001ec00: aa1903f6    	mov	x22, x25
10001ec04: aa1e03f9    	mov	x25, x30
10001ec08: aa0103f8    	mov	x24, x1
10001ec0c: aa0603fb    	mov	x27, x6
10001ec10: f90eebff    	str	xzr, [sp, #0x1dd0]
10001ec14: f90ee7ff    	str	xzr, [sp, #0x1dc8]
10001ec18: f90eefff    	str	xzr, [sp, #0x1dd8]
10001ec1c: 912683e0    	add	x0, sp, #0x9a0
10001ec20: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
10001ec24: 91372021    	add	x1, x1, #0xdc8
10001ec28: 52a00022    	mov	w2, #0x10000            ; =65536
10001ec2c: 52800043    	mov	w3, #0x2                ; =2
10001ec30: 52800024    	mov	w4, #0x1                ; =1
10001ec34: 94004b85    	bl	0x100031a48 <_list.RocList.reallocate>
10001ec38: f944d3f3    	ldr	x19, [sp, #0x9a0]
10001ec3c: f944dbf4    	ldr	x20, [sp, #0x9b0]
10001ec40: cb170268    	sub	x8, x19, x23
10001ec44: f101011f    	cmp	x8, #0x40
10001ec48: 54000722    	b.hs	0x10001ed2c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa94>
10001ec4c: d2800008    	mov	x8, #0x0                ; =0
10001ec50: aa1903eb    	mov	x11, x25
10001ec54: 78e86ae9    	ldrsh	w9, [x23, x8]
10001ec58: 5211012a    	eor	w10, w9, #0x8000
10001ec5c: 0a493d49    	and	w9, w10, w9, lsr #15
10001ec60: 78286a69    	strh	w9, [x19, x8]
10001ec64: 91000908    	add	x8, x8, #0x2
10001ec68: f140811f    	cmp	x8, #0x20, lsl #12      ; =0x20000
10001ec6c: 54ffff41    	b.ne	0x10001ec54 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9bc>
10001ec70: 1400003e    	b	0x10001ed68 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xad0>
10001ec74: eb1a027f    	cmp	x19, x26
10001ec78: 54fff0a0    	b.eq	0x10001ea8c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x7f4>
10001ec7c: aa1503fb    	mov	x27, x21
10001ec80: eb18027f    	cmp	x19, x24
10001ec84: 54ffda43    	b.lo	0x10001e7cc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x534>
10001ec88: 14000378    	b	0x10001fa68 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x17d0>
10001ec8c: 8b1a004c    	add	x12, x2, x26
10001ec90: 8b09004d    	add	x13, x2, x9
10001ec94: f8404189    	ldur	x9, [x12, #0x4]
10001ec98: f84041ab    	ldur	x11, [x13, #0x4]
10001ec9c: eb09017f    	cmp	x11, x9
10001eca0: 540017a1    	b.ne	0x10001ef94 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xcfc>
10001eca4: f840c189    	ldur	x9, [x12, #0xc]
10001eca8: f840c1ab    	ldur	x11, [x13, #0xc]
10001ecac: eb09017f    	cmp	x11, x9
10001ecb0: 54001e81    	b.ne	0x10001f080 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xde8>
10001ecb4: f8414189    	ldur	x9, [x12, #0x14]
10001ecb8: f84141ab    	ldur	x11, [x13, #0x14]
10001ecbc: eb09017f    	cmp	x11, x9
10001ecc0: 540021e1    	b.ne	0x10001f0fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe64>
10001ecc4: f841c189    	ldur	x9, [x12, #0x1c]
10001ecc8: f841c1ab    	ldur	x11, [x13, #0x1c]
10001eccc: eb09017f    	cmp	x11, x9
10001ecd0: 54002581    	b.ne	0x10001f180 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xee8>
10001ecd4: 52800489    	mov	w9, #0x24               ; =36
10001ecd8: 17ffff9e    	b	0x10001eb50 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8b8>
10001ecdc: 8b1a004f    	add	x15, x2, x26
10001ece0: 8b090050    	add	x16, x2, x9
10001ece4: f84041e9    	ldur	x9, [x15, #0x4]
10001ece8: f840420e    	ldur	x14, [x16, #0x4]
10001ecec: eb0901df    	cmp	x14, x9
10001ecf0: 54001561    	b.ne	0x10001ef9c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xd04>
10001ecf4: f840c1e9    	ldur	x9, [x15, #0xc]
10001ecf8: f840c20e    	ldur	x14, [x16, #0xc]
10001ecfc: eb0901df    	cmp	x14, x9
10001ed00: 54001c41    	b.ne	0x10001f088 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xdf0>
10001ed04: f84141e9    	ldur	x9, [x15, #0x14]
10001ed08: f841420e    	ldur	x14, [x16, #0x14]
10001ed0c: eb0901df    	cmp	x14, x9
10001ed10: 54001fa1    	b.ne	0x10001f104 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe6c>
10001ed14: f841c1e9    	ldur	x9, [x15, #0x1c]
10001ed18: f841c20e    	ldur	x14, [x16, #0x1c]
10001ed1c: eb0901df    	cmp	x14, x9
10001ed20: 540023c1    	b.ne	0x10001f198 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf00>
10001ed24: 52800489    	mov	w9, #0x24               ; =36
10001ed28: 17ffffa7    	b	0x10001ebc4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x92c>
10001ed2c: 910082e8    	add	x8, x23, #0x20
10001ed30: 91008269    	add	x9, x19, #0x20
10001ed34: 52a0002a    	mov	w10, #0x10000           ; =65536
10001ed38: 4f04a404    	movi.8h	v4, #0x80, lsl #8
10001ed3c: aa1903eb    	mov	x11, x25
10001ed40: ad7f0500    	ldp	q0, q1, [x8, #-0x20]
10001ed44: acc20d02    	ldp	q2, q3, [x8], #0x40
10001ed48: 6e642c00    	uqsub.8h	v0, v0, v4
10001ed4c: 6e642c21    	uqsub.8h	v1, v1, v4
10001ed50: 6e642c42    	uqsub.8h	v2, v2, v4
10001ed54: 6e642c63    	uqsub.8h	v3, v3, v4
10001ed58: ad3f0520    	stp	q0, q1, [x9, #-0x20]
10001ed5c: ac820d22    	stp	q2, q3, [x9], #0x40
10001ed60: f100814a    	subs	x10, x10, #0x20
10001ed64: 54fffee1    	b.ne	0x10001ed40 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaa8>
10001ed68: f904d3f7    	str	x23, [sp, #0x9a0]
10001ed6c: 52a00028    	mov	w8, #0x10000            ; =65536
10001ed70: f904d7e8    	str	x8, [sp, #0x9a8]
10001ed74: f904dbeb    	str	x11, [sp, #0x9b0]
10001ed78: 912683e0    	add	x0, sp, #0x9a0
10001ed7c: 94004511    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10001ed80: 4f04a404    	movi.8h	v4, #0x80, lsl #8
10001ed84: aa1403fe    	mov	x30, x20
10001ed88: aa1303f7    	mov	x23, x19
10001ed8c: f9419fe2    	ldr	x2, [sp, #0x338]
10001ed90: f941a3e3    	ldr	x3, [sp, #0x340]
10001ed94: 5294f7a4    	mov	w4, #0xa7bd             ; =42941
10001ed98: 72a3c6a4    	movk	w4, #0x1e35, lsl #16
10001ed9c: f94197e5    	ldr	x5, [sp, #0x328]
10001eda0: aa1b03e6    	mov	x6, x27
10001eda4: aa1803e1    	mov	x1, x24
10001eda8: aa1603f9    	mov	x25, x22
10001edac: f9418ff6    	ldr	x22, [sp, #0x318]
10001edb0: f94193f8    	ldr	x24, [sp, #0x320]
10001edb4: aa1c03f4    	mov	x20, x28
10001edb8: 91000753    	add	x19, x26, #0x1
10001edbc: b8736848    	ldr	w8, [x2, x19]
10001edc0: 1b047d08    	mul	w8, w8, w4
10001edc4: 53117d1b    	lsr	w27, w8, #17
10001edc8: 8b1a004a    	add	x10, x2, x26
10001edcc: d37ef6a8    	lsl	x8, x21, #2
10001edd0: 78686aef    	ldrh	w15, [x23, x8]
10001edd4: b940014c    	ldr	w12, [x10]
10001edd8: cb14034d    	sub	x13, x26, x20
10001eddc: eb0f01bf    	cmp	x13, x15
10001ede0: 521101a9    	eor	w9, w13, #0x8000
10001ede4: 78286ae9    	strh	w9, [x23, x8]
10001ede8: 54ffce62    	b.hs	0x10001e7b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x51c>
10001edec: d140228e    	sub	x14, x20, #0x8, lsl #12 ; =0x8000
10001edf0: 8b150ae8    	add	x8, x23, x21, lsl #2
10001edf4: 7940050b    	ldrh	w11, [x8, #0x2]
10001edf8: 7900050f    	strh	w15, [x8, #0x2]
10001edfc: 8b0f01c8    	add	x8, x14, x15
10001ee00: eb05011f    	cmp	x8, x5
10001ee04: 540001a2    	b.hs	0x10001ee38 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xba0>
10001ee08: b8686849    	ldr	w9, [x2, x8]
10001ee0c: 6b0c013f    	cmp	w9, w12
10001ee10: 540001a0    	b.eq	0x10001ee44 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xbac>
10001ee14: eb0b01bf    	cmp	x13, x11
10001ee18: 54ffcce2    	b.hs	0x10001e7b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x51c>
10001ee1c: 8b0b01c8    	add	x8, x14, x11
10001ee20: eb05011f    	cmp	x8, x5
10001ee24: 54000ee2    	b.hs	0x10001f000 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xd68>
10001ee28: b8686849    	ldr	w9, [x2, x8]
10001ee2c: 6b0c013f    	cmp	w9, w12
10001ee30: 54000ee0    	b.eq	0x10001f00c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xd74>
10001ee34: 17fffe60    	b	0x10001e7b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x51c>
10001ee38: 52800009    	mov	w9, #0x0                ; =0
10001ee3c: 6b0c013f    	cmp	w9, w12
10001ee40: 54fffea1    	b.ne	0x10001ee14 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb7c>
10001ee44: eb1a011f    	cmp	x8, x26
10001ee48: f941a7e7    	ldr	x7, [sp, #0x348]
10001ee4c: 5406d1e2    	b.hs	0x10002c888 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe5f0>
10001ee50: f10090df    	cmp	x6, #0x24
10001ee54: 928ffff3    	mov	x19, #-0x8000           ; =-32768
10001ee58: 54000202    	b.hs	0x10001ee98 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc00>
10001ee5c: 52800089    	mov	w9, #0x4                ; =4
10001ee60: b27d0131    	orr	x17, x9, #0x8
10001ee64: 8b0f0290    	add	x16, x20, x15
10001ee68: 8b100050    	add	x16, x2, x16
10001ee6c: eb06023f    	cmp	x17, x6
10001ee70: 540009a8    	b.hi	0x10001efa4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xd0c>
10001ee74: f8696951    	ldr	x17, [x10, x9]
10001ee78: 8b090200    	add	x0, x16, x9
10001ee7c: f8736800    	ldr	x0, [x0, x19]
10001ee80: eb11001f    	cmp	x0, x17
10001ee84: 54000b01    	b.ne	0x10001efe4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xd4c>
10001ee88: b1004131    	adds	x17, x9, #0x10
10001ee8c: 91002129    	add	x9, x9, #0x8
10001ee90: 54fffee3    	b.lo	0x10001ee6c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xbd4>
10001ee94: 14002e15    	b	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10001ee98: 8b080051    	add	x17, x2, x8
10001ee9c: f8404149    	ldur	x9, [x10, #0x4]
10001eea0: f8404230    	ldur	x16, [x17, #0x4]
10001eea4: eb09021f    	cmp	x16, x9
10001eea8: 54000dc1    	b.ne	0x10001f060 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xdc8>
10001eeac: f840c149    	ldur	x9, [x10, #0xc]
10001eeb0: f840c230    	ldur	x16, [x17, #0xc]
10001eeb4: eb09021f    	cmp	x16, x9
10001eeb8: 54000ec1    	b.ne	0x10001f090 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xdf8>
10001eebc: f8414149    	ldur	x9, [x10, #0x14]
10001eec0: f8414230    	ldur	x16, [x17, #0x14]
10001eec4: eb09021f    	cmp	x16, x9
10001eec8: 54001481    	b.ne	0x10001f158 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xec0>
10001eecc: f841c149    	ldur	x9, [x10, #0x1c]
10001eed0: f841c230    	ldur	x16, [x17, #0x1c]
10001eed4: eb09021f    	cmp	x16, x9
10001eed8: 540022e1    	b.ne	0x10001f334 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x109c>
10001eedc: 52800489    	mov	w9, #0x24               ; =36
10001eee0: 17ffffe0    	b	0x10001ee60 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xbc8>
10001eee4: eb06013f    	cmp	x9, x6
10001eee8: 54003362    	b.hs	0x10001f554 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12bc>
10001eeec: 8b080288    	add	x8, x20, x8
10001eef0: 8b080048    	add	x8, x2, x8
10001eef4: 3869696c    	ldrb	w12, [x11, x9]
10001eef8: 8b09010d    	add	x13, x8, x9
10001eefc: 386069ad    	ldrb	w13, [x13, x0]
10001ef00: 6b0d019f    	cmp	w12, w13
10001ef04: 54003281    	b.ne	0x10001f554 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12bc>
10001ef08: 91000529    	add	x9, x9, #0x1
10001ef0c: eb0900df    	cmp	x6, x9
10001ef10: 54ffff21    	b.ne	0x10001eef4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc5c>
10001ef14: aa0603e9    	mov	x9, x6
10001ef18: 1400018f    	b	0x10001f554 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12bc>
10001ef1c: eb06013f    	cmp	x9, x6
10001ef20: 54000322    	b.hs	0x10001ef84 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xcec>
10001ef24: 8b0c028c    	add	x12, x20, x12
10001ef28: 8b0c004c    	add	x12, x2, x12
10001ef2c: 386969cf    	ldrb	w15, [x14, x9]
10001ef30: 8b090190    	add	x16, x12, x9
10001ef34: 38606a10    	ldrb	w16, [x16, x0]
10001ef38: 6b1001ff    	cmp	w15, w16
10001ef3c: 54000241    	b.ne	0x10001ef84 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xcec>
10001ef40: 91000529    	add	x9, x9, #0x1
10001ef44: eb0900df    	cmp	x6, x9
10001ef48: 54ffff21    	b.ne	0x10001ef2c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc94>
10001ef4c: aa0603e9    	mov	x9, x6
10001ef50: cb14034c    	sub	x12, x26, x20
10001ef54: eb08019f    	cmp	x12, x8
10001ef58: 54001303    	b.lo	0x10001f1b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf20>
10001ef5c: 1400017e    	b	0x10001f554 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12bc>
10001ef60: ca0d01c8    	eor	x8, x14, x13
10001ef64: dac00108    	rbit	x8, x8
10001ef68: dac01108    	clz	x8, x8
10001ef6c: 8b480d29    	add	x9, x9, x8, lsr #3
10001ef70: 14000179    	b	0x10001f554 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12bc>
10001ef74: ca10022c    	eor	x12, x17, x16
10001ef78: dac0018c    	rbit	x12, x12
10001ef7c: dac0118c    	clz	x12, x12
10001ef80: 8b4c0d29    	add	x9, x9, x12, lsr #3
10001ef84: cb14034c    	sub	x12, x26, x20
10001ef88: eb08019f    	cmp	x12, x8
10001ef8c: 54001163    	b.lo	0x10001f1b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf20>
10001ef90: 14000171    	b	0x10001f554 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12bc>
10001ef94: 52800088    	mov	w8, #0x4                ; =4
10001ef98: 1400007b    	b	0x10001f184 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeec>
10001ef9c: 5280008c    	mov	w12, #0x4               ; =4
10001efa0: 1400007f    	b	0x10001f19c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf04>
10001efa4: eb06013f    	cmp	x9, x6
10001efa8: 54000262    	b.hs	0x10001eff4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xd5c>
10001efac: 8b0f028f    	add	x15, x20, x15
10001efb0: 8b0f004f    	add	x15, x2, x15
10001efb4: 38696950    	ldrb	w16, [x10, x9]
10001efb8: 8b0901f1    	add	x17, x15, x9
10001efbc: 38736a31    	ldrb	w17, [x17, x19]
10001efc0: 6b11021f    	cmp	w16, w17
10001efc4: 54000181    	b.ne	0x10001eff4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xd5c>
10001efc8: 91000529    	add	x9, x9, #0x1
10001efcc: eb0900df    	cmp	x6, x9
10001efd0: 54ffff21    	b.ne	0x10001efb4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xd1c>
10001efd4: aa0603e9    	mov	x9, x6
10001efd8: eb0b01bf    	cmp	x13, x11
10001efdc: 54001ba3    	b.lo	0x10001f350 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x10b8>
10001efe0: 1400015c    	b	0x10001f550 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12b8>
10001efe4: ca11000f    	eor	x15, x0, x17
10001efe8: dac001ef    	rbit	x15, x15
10001efec: dac011ef    	clz	x15, x15
10001eff0: 8b4f0d29    	add	x9, x9, x15, lsr #3
10001eff4: eb0b01bf    	cmp	x13, x11
10001eff8: 54001ac3    	b.lo	0x10001f350 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x10b8>
10001effc: 14000155    	b	0x10001f550 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12b8>
10001f000: 52800009    	mov	w9, #0x0                ; =0
10001f004: 6b0c013f    	cmp	w9, w12
10001f008: 54ffbd61    	b.ne	0x10001e7b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x51c>
10001f00c: eb1a011f    	cmp	x8, x26
10001f010: 5406c3c2    	b.hs	0x10002c888 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe5f0>
10001f014: f10090df    	cmp	x6, #0x24
10001f018: 928fffef    	mov	x15, #-0x8000           ; =-32768
10001f01c: f941a7e7    	ldr	x7, [sp, #0x348]
10001f020: 54000482    	b.hs	0x10001f0b0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe18>
10001f024: 52800089    	mov	w9, #0x4                ; =4
10001f028: b27d012d    	orr	x13, x9, #0x8
10001f02c: 8b0b028c    	add	x12, x20, x11
10001f030: 8b0c004c    	add	x12, x2, x12
10001f034: eb0601bf    	cmp	x13, x6
10001f038: 540006a8    	b.hi	0x10001f10c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe74>
10001f03c: f869694d    	ldr	x13, [x10, x9]
10001f040: 8b09018e    	add	x14, x12, x9
10001f044: f86f69ce    	ldr	x14, [x14, x15]
10001f048: eb0d01df    	cmp	x14, x13
10001f04c: 540007c1    	b.ne	0x10001f144 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeac>
10001f050: b100412d    	adds	x13, x9, #0x10
10001f054: 91002129    	add	x9, x9, #0x8
10001f058: 54fffee3    	b.lo	0x10001f034 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xd9c>
10001f05c: 14002da3    	b	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10001f060: 5280008f    	mov	w15, #0x4               ; =4
10001f064: ca090209    	eor	x9, x16, x9
10001f068: dac00129    	rbit	x9, x9
10001f06c: dac01129    	clz	x9, x9
10001f070: 8b490de9    	add	x9, x15, x9, lsr #3
10001f074: eb0b01bf    	cmp	x13, x11
10001f078: 540016c3    	b.lo	0x10001f350 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x10b8>
10001f07c: 14000135    	b	0x10001f550 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12b8>
10001f080: 52800188    	mov	w8, #0xc                ; =12
10001f084: 14000040    	b	0x10001f184 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeec>
10001f088: 5280018c    	mov	w12, #0xc               ; =12
10001f08c: 14000044    	b	0x10001f19c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf04>
10001f090: 5280018f    	mov	w15, #0xc               ; =12
10001f094: ca090209    	eor	x9, x16, x9
10001f098: dac00129    	rbit	x9, x9
10001f09c: dac01129    	clz	x9, x9
10001f0a0: 8b490de9    	add	x9, x15, x9, lsr #3
10001f0a4: eb0b01bf    	cmp	x13, x11
10001f0a8: 54001543    	b.lo	0x10001f350 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x10b8>
10001f0ac: 14000129    	b	0x10001f550 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12b8>
10001f0b0: 8b08004d    	add	x13, x2, x8
10001f0b4: f8404149    	ldur	x9, [x10, #0x4]
10001f0b8: f84041ac    	ldur	x12, [x13, #0x4]
10001f0bc: eb09019f    	cmp	x12, x9
10001f0c0: 540005c1    	b.ne	0x10001f178 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xee0>
10001f0c4: f840c149    	ldur	x9, [x10, #0xc]
10001f0c8: f840c1ac    	ldur	x12, [x13, #0xc]
10001f0cc: eb09019f    	cmp	x12, x9
10001f0d0: 54001f61    	b.ne	0x10001f4bc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1224>
10001f0d4: f8414149    	ldur	x9, [x10, #0x14]
10001f0d8: f84141ac    	ldur	x12, [x13, #0x14]
10001f0dc: eb09019f    	cmp	x12, x9
10001f0e0: 54001fa1    	b.ne	0x10001f4d4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x123c>
10001f0e4: f841c149    	ldur	x9, [x10, #0x1c]
10001f0e8: f841c1ac    	ldur	x12, [x13, #0x1c]
10001f0ec: eb09019f    	cmp	x12, x9
10001f0f0: 54001fe1    	b.ne	0x10001f4ec <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1254>
10001f0f4: 52800489    	mov	w9, #0x24               ; =36
10001f0f8: 17ffffcc    	b	0x10001f028 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xd90>
10001f0fc: 52800288    	mov	w8, #0x14               ; =20
10001f100: 14000021    	b	0x10001f184 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeec>
10001f104: 5280028c    	mov	w12, #0x14              ; =20
10001f108: 14000025    	b	0x10001f19c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf04>
10001f10c: eb06013f    	cmp	x9, x6
10001f110: 54002202    	b.hs	0x10001f550 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12b8>
10001f114: 8b0b028b    	add	x11, x20, x11
10001f118: 8b0b004b    	add	x11, x2, x11
10001f11c: 3869694c    	ldrb	w12, [x10, x9]
10001f120: 8b09016d    	add	x13, x11, x9
10001f124: 386f69ad    	ldrb	w13, [x13, x15]
10001f128: 6b0d019f    	cmp	w12, w13
10001f12c: 54002121    	b.ne	0x10001f550 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12b8>
10001f130: 91000529    	add	x9, x9, #0x1
10001f134: eb0900df    	cmp	x6, x9
10001f138: 54ffff21    	b.ne	0x10001f11c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe84>
10001f13c: aa0603e9    	mov	x9, x6
10001f140: 14000104    	b	0x10001f550 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12b8>
10001f144: ca0d01ca    	eor	x10, x14, x13
10001f148: dac0014a    	rbit	x10, x10
10001f14c: dac0114a    	clz	x10, x10
10001f150: 8b4a0d29    	add	x9, x9, x10, lsr #3
10001f154: 140000ff    	b	0x10001f550 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12b8>
10001f158: 5280028f    	mov	w15, #0x14              ; =20
10001f15c: ca090209    	eor	x9, x16, x9
10001f160: dac00129    	rbit	x9, x9
10001f164: dac01129    	clz	x9, x9
10001f168: 8b490de9    	add	x9, x15, x9, lsr #3
10001f16c: eb0b01bf    	cmp	x13, x11
10001f170: 54000f03    	b.lo	0x10001f350 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x10b8>
10001f174: 140000f7    	b	0x10001f550 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12b8>
10001f178: 5280008a    	mov	w10, #0x4               ; =4
10001f17c: 140000dd    	b	0x10001f4f0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1258>
10001f180: 52800388    	mov	w8, #0x1c               ; =28
10001f184: ca090169    	eor	x9, x11, x9
10001f188: dac00129    	rbit	x9, x9
10001f18c: dac01129    	clz	x9, x9
10001f190: 8b490d09    	add	x9, x8, x9, lsr #3
10001f194: 140000f0    	b	0x10001f554 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12bc>
10001f198: 5280038c    	mov	w12, #0x1c              ; =28
10001f19c: ca0901c9    	eor	x9, x14, x9
10001f1a0: dac00129    	rbit	x9, x9
10001f1a4: dac01129    	clz	x9, x9
10001f1a8: 8b490d89    	add	x9, x12, x9, lsr #3
10001f1ac: cb14034c    	sub	x12, x26, x20
10001f1b0: eb08019f    	cmp	x12, x8
10001f1b4: 54001d02    	b.hs	0x10001f554 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12bc>
10001f1b8: f941b7ec    	ldr	x12, [sp, #0x368]
10001f1bc: eb0c013f    	cmp	x9, x12
10001f1c0: 54001ca2    	b.hs	0x10001f554 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12bc>
10001f1c4: 8b08016c    	add	x12, x11, x8
10001f1c8: eb05019f    	cmp	x12, x5
10001f1cc: 540000a2    	b.hs	0x10001f1e0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf48>
10001f1d0: b86c684b    	ldr	w11, [x2, x12]
10001f1d4: 6b0d017f    	cmp	w11, w13
10001f1d8: 540000a0    	b.eq	0x10001f1ec <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf54>
10001f1dc: 140000de    	b	0x10001f554 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12bc>
10001f1e0: 5280000b    	mov	w11, #0x0               ; =0
10001f1e4: 6b0d017f    	cmp	w11, w13
10001f1e8: 54001b61    	b.ne	0x10001f554 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12bc>
10001f1ec: 8b09018b    	add	x11, x12, x9
10001f1f0: d1000d6b    	sub	x11, x11, #0x3
10001f1f4: eb05017f    	cmp	x11, x5
10001f1f8: 54000142    	b.hs	0x10001f220 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf88>
10001f1fc: b86b684b    	ldr	w11, [x2, x11]
10001f200: 8b09034d    	add	x13, x26, x9
10001f204: d1000dad    	sub	x13, x13, #0x3
10001f208: eb0501bf    	cmp	x13, x5
10001f20c: 54000143    	b.lo	0x10001f234 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf9c>
10001f210: 5280000d    	mov	w13, #0x0               ; =0
10001f214: 6b0d017f    	cmp	w11, w13
10001f218: 54000140    	b.eq	0x10001f240 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xfa8>
10001f21c: 140000ce    	b	0x10001f554 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12bc>
10001f220: 5280000b    	mov	w11, #0x0               ; =0
10001f224: 8b09034d    	add	x13, x26, x9
10001f228: d1000dad    	sub	x13, x13, #0x3
10001f22c: eb0501bf    	cmp	x13, x5
10001f230: 54ffff02    	b.hs	0x10001f210 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf78>
10001f234: b86d684d    	ldr	w13, [x2, x13]
10001f238: 6b0d017f    	cmp	w11, w13
10001f23c: 540018c1    	b.ne	0x10001f554 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12bc>
10001f240: eb0c034b    	subs	x11, x26, x12
10001f244: 5406b229    	b.ls	0x10002c888 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe5f0>
10001f248: f10090df    	cmp	x6, #0x24
10001f24c: 54000222    	b.hs	0x10001f290 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xff8>
10001f250: 5280008c    	mov	w12, #0x4               ; =4
10001f254: b27d018f    	orr	x15, x12, #0x8
10001f258: 8b1a004d    	add	x13, x2, x26
10001f25c: 8b08028e    	add	x14, x20, x8
10001f260: 8b0e004e    	add	x14, x2, x14
10001f264: eb0601ff    	cmp	x15, x6
10001f268: 540003c8    	b.hi	0x10001f2e0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1048>
10001f26c: f86c69af    	ldr	x15, [x13, x12]
10001f270: 8b0c01d0    	add	x16, x14, x12
10001f274: f8606a10    	ldr	x16, [x16, x0]
10001f278: eb0f021f    	cmp	x16, x15
10001f27c: 540004e1    	b.ne	0x10001f318 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1080>
10001f280: b100418f    	adds	x15, x12, #0x10
10001f284: 9100218c    	add	x12, x12, #0x8
10001f288: 54fffee3    	b.lo	0x10001f264 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xfcc>
10001f28c: 14002d17    	b	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10001f290: 8b1a004e    	add	x14, x2, x26
10001f294: 8b0c004f    	add	x15, x2, x12
10001f298: f84041cc    	ldur	x12, [x14, #0x4]
10001f29c: f84041ed    	ldur	x13, [x15, #0x4]
10001f2a0: eb0c01bf    	cmp	x13, x12
10001f2a4: 54000441    	b.ne	0x10001f32c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1094>
10001f2a8: f840c1cc    	ldur	x12, [x14, #0xc]
10001f2ac: f840c1ed    	ldur	x13, [x15, #0xc]
10001f2b0: eb0c01bf    	cmp	x13, x12
10001f2b4: 540010c1    	b.ne	0x10001f4cc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1234>
10001f2b8: f84141cc    	ldur	x12, [x14, #0x14]
10001f2bc: f84141ed    	ldur	x13, [x15, #0x14]
10001f2c0: eb0c01bf    	cmp	x13, x12
10001f2c4: 54001101    	b.ne	0x10001f4e4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x124c>
10001f2c8: f841c1cc    	ldur	x12, [x14, #0x1c]
10001f2cc: f841c1ed    	ldur	x13, [x15, #0x1c]
10001f2d0: eb0c01bf    	cmp	x13, x12
10001f2d4: 540011c1    	b.ne	0x10001f50c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1274>
10001f2d8: 5280048c    	mov	w12, #0x24              ; =36
10001f2dc: 17ffffde    	b	0x10001f254 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xfbc>
10001f2e0: eb06019f    	cmp	x12, x6
10001f2e4: 540011e2    	b.hs	0x10001f520 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1288>
10001f2e8: 8b080288    	add	x8, x20, x8
10001f2ec: 8b080048    	add	x8, x2, x8
10001f2f0: 386c69ae    	ldrb	w14, [x13, x12]
10001f2f4: 8b0c010f    	add	x15, x8, x12
10001f2f8: 386069ef    	ldrb	w15, [x15, x0]
10001f2fc: 6b0f01df    	cmp	w14, w15
10001f300: 54001101    	b.ne	0x10001f520 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1288>
10001f304: 9100058c    	add	x12, x12, #0x1
10001f308: eb0c00df    	cmp	x6, x12
10001f30c: 54ffff21    	b.ne	0x10001f2f0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1058>
10001f310: aa0603ec    	mov	x12, x6
10001f314: 14000083    	b	0x10001f520 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1288>
10001f318: ca0f0208    	eor	x8, x16, x15
10001f31c: dac00108    	rbit	x8, x8
10001f320: dac01108    	clz	x8, x8
10001f324: 8b480d8c    	add	x12, x12, x8, lsr #3
10001f328: 1400007e    	b	0x10001f520 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1288>
10001f32c: 52800088    	mov	w8, #0x4                ; =4
10001f330: 14000078    	b	0x10001f510 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1278>
10001f334: 5280038f    	mov	w15, #0x1c              ; =28
10001f338: ca090209    	eor	x9, x16, x9
10001f33c: dac00129    	rbit	x9, x9
10001f340: dac01129    	clz	x9, x9
10001f344: 8b490de9    	add	x9, x15, x9, lsr #3
10001f348: eb0b01bf    	cmp	x13, x11
10001f34c: 54001022    	b.hs	0x10001f550 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12b8>
10001f350: f941b7ed    	ldr	x13, [sp, #0x368]
10001f354: eb0d013f    	cmp	x9, x13
10001f358: 54000fc2    	b.hs	0x10001f550 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12b8>
10001f35c: 8b0b01cd    	add	x13, x14, x11
10001f360: eb0501bf    	cmp	x13, x5
10001f364: 540000a2    	b.hs	0x10001f378 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x10e0>
10001f368: b86d684e    	ldr	w14, [x2, x13]
10001f36c: 6b0c01df    	cmp	w14, w12
10001f370: 540000a0    	b.eq	0x10001f384 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x10ec>
10001f374: 14000077    	b	0x10001f550 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12b8>
10001f378: 5280000e    	mov	w14, #0x0               ; =0
10001f37c: 6b0c01df    	cmp	w14, w12
10001f380: 54000e81    	b.ne	0x10001f550 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12b8>
10001f384: 8b0901ac    	add	x12, x13, x9
10001f388: d1000d8c    	sub	x12, x12, #0x3
10001f38c: eb05019f    	cmp	x12, x5
10001f390: 54000142    	b.hs	0x10001f3b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1120>
10001f394: b86c684c    	ldr	w12, [x2, x12]
10001f398: 8b09034e    	add	x14, x26, x9
10001f39c: d1000dce    	sub	x14, x14, #0x3
10001f3a0: eb0501df    	cmp	x14, x5
10001f3a4: 54000143    	b.lo	0x10001f3cc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1134>
10001f3a8: 5280000e    	mov	w14, #0x0               ; =0
10001f3ac: 6b0e019f    	cmp	w12, w14
10001f3b0: 54000140    	b.eq	0x10001f3d8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1140>
10001f3b4: 14000067    	b	0x10001f550 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12b8>
10001f3b8: 5280000c    	mov	w12, #0x0               ; =0
10001f3bc: 8b09034e    	add	x14, x26, x9
10001f3c0: d1000dce    	sub	x14, x14, #0x3
10001f3c4: eb0501df    	cmp	x14, x5
10001f3c8: 54ffff02    	b.hs	0x10001f3a8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1110>
10001f3cc: b86e684e    	ldr	w14, [x2, x14]
10001f3d0: 6b0e019f    	cmp	w12, w14
10001f3d4: 54000be1    	b.ne	0x10001f550 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12b8>
10001f3d8: eb1a01bf    	cmp	x13, x26
10001f3dc: 5406a562    	b.hs	0x10002c888 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe5f0>
10001f3e0: f10090df    	cmp	x6, #0x24
10001f3e4: 54000202    	b.hs	0x10001f424 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x118c>
10001f3e8: 5280008c    	mov	w12, #0x4               ; =4
10001f3ec: b27d018f    	orr	x15, x12, #0x8
10001f3f0: 8b0b028e    	add	x14, x20, x11
10001f3f4: 8b0e004e    	add	x14, x2, x14
10001f3f8: eb0601ff    	cmp	x15, x6
10001f3fc: 540003a8    	b.hi	0x10001f470 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x11d8>
10001f400: f86c694f    	ldr	x15, [x10, x12]
10001f404: 8b0c01d0    	add	x16, x14, x12
10001f408: f8736a10    	ldr	x16, [x16, x19]
10001f40c: eb0f021f    	cmp	x16, x15
10001f410: 540004c1    	b.ne	0x10001f4a8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1210>
10001f414: b100418f    	adds	x15, x12, #0x10
10001f418: 9100218c    	add	x12, x12, #0x8
10001f41c: 54fffee3    	b.lo	0x10001f3f8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1160>
10001f420: 14002cb2    	b	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10001f424: 8b0d004f    	add	x15, x2, x13
10001f428: f840414c    	ldur	x12, [x10, #0x4]
10001f42c: f84041ee    	ldur	x14, [x15, #0x4]
10001f430: eb0c01df    	cmp	x14, x12
10001f434: 54000481    	b.ne	0x10001f4c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x122c>
10001f438: f840c14c    	ldur	x12, [x10, #0xc]
10001f43c: f840c1ee    	ldur	x14, [x15, #0xc]
10001f440: eb0c01df    	cmp	x14, x12
10001f444: 540004c1    	b.ne	0x10001f4dc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1244>
10001f448: f841414c    	ldur	x12, [x10, #0x14]
10001f44c: f84141ee    	ldur	x14, [x15, #0x14]
10001f450: eb0c01df    	cmp	x14, x12
10001f454: 54000581    	b.ne	0x10001f504 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x126c>
10001f458: f841c14c    	ldur	x12, [x10, #0x1c]
10001f45c: f841c1ee    	ldur	x14, [x15, #0x1c]
10001f460: eb0c01df    	cmp	x14, x12
10001f464: 54000661    	b.ne	0x10001f530 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1298>
10001f468: 5280048c    	mov	w12, #0x24              ; =36
10001f46c: 17ffffe0    	b	0x10001f3ec <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1154>
10001f470: eb06019f    	cmp	x12, x6
10001f474: 54000682    	b.hs	0x10001f544 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12ac>
10001f478: 8b0b028b    	add	x11, x20, x11
10001f47c: 8b0b004b    	add	x11, x2, x11
10001f480: 386c694e    	ldrb	w14, [x10, x12]
10001f484: 8b0c016f    	add	x15, x11, x12
10001f488: 387369ef    	ldrb	w15, [x15, x19]
10001f48c: 6b0f01df    	cmp	w14, w15
10001f490: 540005a1    	b.ne	0x10001f544 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12ac>
10001f494: 9100058c    	add	x12, x12, #0x1
10001f498: eb0c00df    	cmp	x6, x12
10001f49c: 54ffff21    	b.ne	0x10001f480 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x11e8>
10001f4a0: aa0603ec    	mov	x12, x6
10001f4a4: 14000028    	b	0x10001f544 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12ac>
10001f4a8: ca0f020a    	eor	x10, x16, x15
10001f4ac: dac0014a    	rbit	x10, x10
10001f4b0: dac0114a    	clz	x10, x10
10001f4b4: 8b4a0d8c    	add	x12, x12, x10, lsr #3
10001f4b8: 14000023    	b	0x10001f544 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12ac>
10001f4bc: 5280018a    	mov	w10, #0xc               ; =12
10001f4c0: 1400000c    	b	0x10001f4f0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1258>
10001f4c4: 5280008a    	mov	w10, #0x4               ; =4
10001f4c8: 1400001b    	b	0x10001f534 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x129c>
10001f4cc: 52800188    	mov	w8, #0xc                ; =12
10001f4d0: 14000010    	b	0x10001f510 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1278>
10001f4d4: 5280028a    	mov	w10, #0x14              ; =20
10001f4d8: 14000006    	b	0x10001f4f0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1258>
10001f4dc: 5280018a    	mov	w10, #0xc               ; =12
10001f4e0: 14000015    	b	0x10001f534 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x129c>
10001f4e4: 52800288    	mov	w8, #0x14               ; =20
10001f4e8: 1400000a    	b	0x10001f510 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1278>
10001f4ec: 5280038a    	mov	w10, #0x1c              ; =28
10001f4f0: ca090189    	eor	x9, x12, x9
10001f4f4: dac00129    	rbit	x9, x9
10001f4f8: dac01129    	clz	x9, x9
10001f4fc: 8b490d49    	add	x9, x10, x9, lsr #3
10001f500: 14000014    	b	0x10001f550 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12b8>
10001f504: 5280028a    	mov	w10, #0x14              ; =20
10001f508: 1400000b    	b	0x10001f534 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x129c>
10001f50c: 52800388    	mov	w8, #0x1c               ; =28
10001f510: ca0c01ac    	eor	x12, x13, x12
10001f514: dac0018c    	rbit	x12, x12
10001f518: dac0118c    	clz	x12, x12
10001f51c: 8b4c0d0c    	add	x12, x8, x12, lsr #3
10001f520: eb09019f    	cmp	x12, x9
10001f524: 9a898189    	csel	x9, x12, x9, hi
10001f528: 9a8a816a    	csel	x10, x11, x10, hi
10001f52c: 1400000a    	b	0x10001f554 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12bc>
10001f530: 5280038a    	mov	w10, #0x1c              ; =28
10001f534: ca0c01cb    	eor	x11, x14, x12
10001f538: dac0016b    	rbit	x11, x11
10001f53c: dac0116b    	clz	x11, x11
10001f540: 8b4b0d4c    	add	x12, x10, x11, lsr #3
10001f544: eb09019f    	cmp	x12, x9
10001f548: 9a898189    	csel	x9, x12, x9, hi
10001f54c: 9a8881a8    	csel	x8, x13, x8, hi
10001f550: cb08034a    	sub	x10, x26, x8
10001f554: f104093f    	cmp	x9, #0x102
10001f558: 54001c28    	b.hi	0x10001f8dc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1644>
10001f55c: 100d6368    	adr	x8, 0x10003a1c8 <_roc__d59_1>
10001f560: d503201f    	nop
10001f564: 8b090108    	add	x8, x8, x9
10001f568: 39402108    	ldrb	w8, [x8, #0x8]
10001f56c: d37ef508    	lsl	x8, x8, #2
10001f570: 91101108    	add	x8, x8, #0x404
10001f574: 5280200b    	mov	w11, #0x100             ; =256
10001f578: 4b0a016b    	sub	w11, w11, w10
10001f57c: 531d7d6b    	lsr	w11, w11, #29
10001f580: d100054c    	sub	x12, x10, #0x1
10001f584: 9acb258c    	lsr	x12, x12, x11
10001f588: f103fd9f    	cmp	x12, #0xff
10001f58c: 54001ac8    	b.hi	0x10001f8e4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x164c>
10001f590: 100d57cd    	adr	x13, 0x10003a088 <_roc__d57_1>
10001f594: d503201f    	nop
10001f598: 8b0c01ac    	add	x12, x13, x12
10001f59c: 3940218c    	ldrb	w12, [x12, #0x8]
10001f5a0: 8b0b058b    	add	x11, x12, x11, lsl #1
10001f5a4: b8686acc    	ldr	w12, [x22, x8]
10001f5a8: 1100058c    	add	w12, w12, #0x1
10001f5ac: b8286acc    	str	w12, [x22, x8]
10001f5b0: b86b78e8    	ldr	w8, [x7, x11, lsl #2]
10001f5b4: 11000508    	add	w8, w8, #0x1
10001f5b8: b82b78e8    	str	w8, [x7, x11, lsl #2]
10001f5bc: f9419be8    	ldr	x8, [sp, #0x330]
10001f5c0: eb01011f    	cmp	x8, x1
10001f5c4: 54001940    	b.eq	0x10001f8ec <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1654>
10001f5c8: f941b3e8    	ldr	x8, [sp, #0x360]
10001f5cc: cb080348    	sub	x8, x26, x8
10001f5d0: aa095d08    	orr	x8, x8, x9, lsl #23
10001f5d4: d3603d4c    	ubfiz	x12, x10, #32, #16
10001f5d8: aa0bc18b    	orr	x11, x12, x11, lsl #48
10001f5dc: b3407d0b    	bfxil	x11, x8, #0, #32
10001f5e0: f941abe8    	ldr	x8, [sp, #0x350]
10001f5e4: f821790b    	str	x11, [x8, x1, lsl #3]
10001f5e8: 91000421    	add	x1, x1, #0x1
10001f5ec: 8b1a0133    	add	x19, x9, x26
10001f5f0: cb130288    	sub	x8, x20, x19
10001f5f4: b140211f    	cmn	x8, #0x8, lsl #12       ; =0x8000
10001f5f8: 54000383    	b.lo	0x10001f668 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x13d0>
10001f5fc: 91001668    	add	x8, x19, #0x5
10001f600: eb03011f    	cmp	x8, x3
10001f604: 54000328    	b.hi	0x10001f668 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x13d0>
10001f608: f9418be8    	ldr	x8, [sp, #0x310]
10001f60c: eb08027f    	cmp	x19, x8
10001f610: 9a883268    	csel	x8, x19, x8, lo
10001f614: f100055f    	cmp	x10, #0x1
10001f618: 54000421    	b.ne	0x10001f69c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1404>
10001f61c: f100213f    	cmp	x9, #0x8
10001f620: 540003e3    	b.lo	0x10001f69c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1404>
10001f624: d1000e69    	sub	x9, x19, #0x3
10001f628: 4b14026a    	sub	w10, w19, w20
10001f62c: 528fff8b    	mov	w11, #0x7ffc            ; =32764
10001f630: 0b0b014b    	add	w11, w10, w11
10001f634: 8b1b0aec    	add	x12, x23, x27, lsl #2
10001f638: 7900018b    	strh	w11, [x12]
10001f63c: 528fff6b    	mov	w11, #0x7ffb            ; =32763
10001f640: 0b0b014a    	add	w10, w10, w11
10001f644: 7900058a    	strh	w10, [x12, #0x2]
10001f648: eb05013f    	cmp	x9, x5
10001f64c: 54000662    	b.hs	0x10001f718 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1480>
10001f650: b869684a    	ldr	w10, [x2, x9]
10001f654: 1b047d4a    	mul	w10, w10, w4
10001f658: 53117d5b    	lsr	w27, w10, #17
10001f65c: eb090108    	subs	x8, x8, x9
10001f660: 54000628    	b.hi	0x10001f724 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x148c>
10001f664: 1400003e    	b	0x10001f75c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x14c4>
10001f668: 9100074a    	add	x10, x26, #0x1
10001f66c: d1000535    	sub	x21, x9, #0x1
10001f670: ab150159    	adds	x25, x10, x21
10001f674: 540583a2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10001f678: b1001728    	adds	x8, x25, #0x5
10001f67c: 54058362    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10001f680: eb03011f    	cmp	x8, x3
10001f684: 54000149    	b.ls	0x10001f6ac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1414>
10001f688: f901b3f3    	str	x19, [sp, #0x360]
10001f68c: f9417ff9    	ldr	x25, [sp, #0x2f8]
10001f690: eb18027f    	cmp	x19, x24
10001f694: 54ff89c3    	b.lo	0x10001e7cc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x534>
10001f698: 140000f4    	b	0x10001fa68 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x17d0>
10001f69c: 91000749    	add	x9, x26, #0x1
10001f6a0: eb090108    	subs	x8, x8, x9
10001f6a4: 54000408    	b.hi	0x10001f724 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x148c>
10001f6a8: 1400002d    	b	0x10001f75c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x14c4>
10001f6ac: cb14015c    	sub	x28, x10, x20
10001f6b0: 8b150388    	add	x8, x28, x21
10001f6b4: d1000508    	sub	x8, x8, #0x1
10001f6b8: f140211f    	cmp	x8, #0x8, lsl #12       ; =0x8000
10001f6bc: 540005cb    	b.lt	0x10001f774 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x14dc>
10001f6c0: 3700063e    	tbnz	w30, #0x0, 0x10001f784 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x14ec>
10001f6c4: b400009e    	cbz	x30, 0x10001f6d4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x143c>
10001f6c8: f85f82e8    	ldur	x8, [x23, #-0x8]
10001f6cc: f100051f    	cmp	x8, #0x1
10001f6d0: 540005a1    	b.ne	0x10001f784 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x14ec>
10001f6d4: d2800008    	mov	x8, #0x0                ; =0
10001f6d8: 8b0802e9    	add	x9, x23, x8
10001f6dc: ad400520    	ldp	q0, q1, [x9]
10001f6e0: ad410d22    	ldp	q2, q3, [x9, #0x20]
10001f6e4: 6e642c00    	uqsub.8h	v0, v0, v4
10001f6e8: 6e642c21    	uqsub.8h	v1, v1, v4
10001f6ec: 6e642c42    	uqsub.8h	v2, v2, v4
10001f6f0: 6e642c63    	uqsub.8h	v3, v3, v4
10001f6f4: ad000520    	stp	q0, q1, [x9]
10001f6f8: ad010d22    	stp	q2, q3, [x9, #0x20]
10001f6fc: 91010108    	add	x8, x8, #0x40
10001f700: f140811f    	cmp	x8, #0x20, lsl #12      ; =0x20000
10001f704: 54fffea1    	b.ne	0x10001f6d8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1440>
10001f708: 91402294    	add	x20, x20, #0x8, lsl #12 ; =0x8000
10001f70c: eb19015f    	cmp	x10, x25
10001f710: 54fffbc2    	b.hs	0x10001f688 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x13f0>
10001f714: 1400005c    	b	0x10001f884 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x15ec>
10001f718: d280001b    	mov	x27, #0x0               ; =0
10001f71c: eb090108    	subs	x8, x8, x9
10001f720: 540001e9    	b.ls	0x10001f75c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x14c4>
10001f724: cb14012a    	sub	x10, x9, x20
10001f728: 9140214a    	add	x10, x10, #0x8, lsl #12 ; =0x8000
10001f72c: f9415feb    	ldr	x11, [sp, #0x2b8]
10001f730: 8b090169    	add	x9, x11, x9
10001f734: 8b1b0aeb    	add	x11, x23, x27, lsl #2
10001f738: 7940016c    	ldrh	w12, [x11]
10001f73c: 7900056c    	strh	w12, [x11, #0x2]
10001f740: 7900016a    	strh	w10, [x11]
10001f744: 9100054a    	add	x10, x10, #0x1
10001f748: b840152b    	ldr	w11, [x9], #0x1
10001f74c: 1b047d6b    	mul	w11, w11, w4
10001f750: 53117d7b    	lsr	w27, w11, #17
10001f754: f1000508    	subs	x8, x8, #0x1
10001f758: 54fffee1    	b.ne	0x10001f734 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x149c>
10001f75c: d37ef768    	lsl	x8, x27, #2
10001f760: f8a86af0    	prfm	pstl1keep, [x23, x8]
10001f764: f901b3f3    	str	x19, [sp, #0x360]
10001f768: eb18027f    	cmp	x19, x24
10001f76c: 54ff8303    	b.lo	0x10001e7cc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x534>
10001f770: 140000be    	b	0x10001fa68 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x17d0>
10001f774: 9140239c    	add	x28, x28, #0x8, lsl #12 ; =0x8000
10001f778: eb19015f    	cmp	x10, x25
10001f77c: 54000843    	b.lo	0x10001f884 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x15ec>
10001f780: 17ffffc2    	b	0x10001f688 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x13f0>
10001f784: f9014fe1    	str	x1, [sp, #0x298]
10001f788: f90183e6    	str	x6, [sp, #0x300]
10001f78c: f901b3fe    	str	x30, [sp, #0x360]
10001f790: f90eebff    	str	xzr, [sp, #0x1dd0]
10001f794: f90ee7ff    	str	xzr, [sp, #0x1dc8]
10001f798: f90eefff    	str	xzr, [sp, #0x1dd8]
10001f79c: 912683e0    	add	x0, sp, #0x9a0
10001f7a0: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
10001f7a4: 91372021    	add	x1, x1, #0xdc8
10001f7a8: 52a00022    	mov	w2, #0x10000            ; =65536
10001f7ac: 52800043    	mov	w3, #0x2                ; =2
10001f7b0: 52800024    	mov	w4, #0x1                ; =1
10001f7b4: 940048a5    	bl	0x100031a48 <_list.RocList.reallocate>
10001f7b8: f944d3f8    	ldr	x24, [sp, #0x9a0]
10001f7bc: f944dbe8    	ldr	x8, [sp, #0x9b0]
10001f7c0: f90147e8    	str	x8, [sp, #0x288]
10001f7c4: cb170308    	sub	x8, x24, x23
10001f7c8: f101011f    	cmp	x8, #0x40
10001f7cc: 54000142    	b.hs	0x10001f7f4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x155c>
10001f7d0: d2800008    	mov	x8, #0x0                ; =0
10001f7d4: 78e86ae9    	ldrsh	w9, [x23, x8]
10001f7d8: 5211012a    	eor	w10, w9, #0x8000
10001f7dc: 0a493d49    	and	w9, w10, w9, lsr #15
10001f7e0: 78286b09    	strh	w9, [x24, x8]
10001f7e4: 91000908    	add	x8, x8, #0x2
10001f7e8: f140811f    	cmp	x8, #0x20, lsl #12      ; =0x20000
10001f7ec: 54ffff41    	b.ne	0x10001f7d4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x153c>
10001f7f0: 1400000f    	b	0x10001f82c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1594>
10001f7f4: 910082e8    	add	x8, x23, #0x20
10001f7f8: 91008309    	add	x9, x24, #0x20
10001f7fc: 52a0002a    	mov	w10, #0x10000           ; =65536
10001f800: 4f04a404    	movi.8h	v4, #0x80, lsl #8
10001f804: ad7f0500    	ldp	q0, q1, [x8, #-0x20]
10001f808: acc20d02    	ldp	q2, q3, [x8], #0x40
10001f80c: 6e642c00    	uqsub.8h	v0, v0, v4
10001f810: 6e642c21    	uqsub.8h	v1, v1, v4
10001f814: 6e642c42    	uqsub.8h	v2, v2, v4
10001f818: 6e642c63    	uqsub.8h	v3, v3, v4
10001f81c: ad3f0520    	stp	q0, q1, [x9, #-0x20]
10001f820: ac820d22    	stp	q2, q3, [x9], #0x40
10001f824: f100814a    	subs	x10, x10, #0x20
10001f828: 54fffee1    	b.ne	0x10001f804 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x156c>
10001f82c: f904d3f7    	str	x23, [sp, #0x9a0]
10001f830: 52a00028    	mov	w8, #0x10000            ; =65536
10001f834: f904d7e8    	str	x8, [sp, #0x9a8]
10001f838: f941b3e8    	ldr	x8, [sp, #0x360]
10001f83c: f904dbe8    	str	x8, [sp, #0x9b0]
10001f840: 912683e0    	add	x0, sp, #0x9a0
10001f844: 9400425f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10001f848: 4f04a404    	movi.8h	v4, #0x80, lsl #8
10001f84c: f94147fe    	ldr	x30, [sp, #0x288]
10001f850: aa1803f7    	mov	x23, x24
10001f854: f9419fe2    	ldr	x2, [sp, #0x338]
10001f858: f941a3e3    	ldr	x3, [sp, #0x340]
10001f85c: 5294f7a4    	mov	w4, #0xa7bd             ; =42941
10001f860: 72a3c6a4    	movk	w4, #0x1e35, lsl #16
10001f864: f94197e5    	ldr	x5, [sp, #0x328]
10001f868: f94183e6    	ldr	x6, [sp, #0x300]
10001f86c: f9414fe1    	ldr	x1, [sp, #0x298]
10001f870: f94193f8    	ldr	x24, [sp, #0x320]
10001f874: 9100074a    	add	x10, x26, #0x1
10001f878: 91402294    	add	x20, x20, #0x8, lsl #12 ; =0x8000
10001f87c: eb19015f    	cmp	x10, x25
10001f880: 54fff042    	b.hs	0x10001f688 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x13f0>
10001f884: 91000b48    	add	x8, x26, #0x2
10001f888: f9417ff9    	ldr	x25, [sp, #0x2f8]
10001f88c: 14000008    	b	0x10001f8ac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1614>
10001f890: b8686849    	ldr	w9, [x2, x8]
10001f894: 1b047d29    	mul	w9, w9, w4
10001f898: 53117d3b    	lsr	w27, w9, #17
10001f89c: 9100079c    	add	x28, x28, #0x1
10001f8a0: 91000508    	add	x8, x8, #0x1
10001f8a4: f10006b5    	subs	x21, x21, #0x1
10001f8a8: 54fff5e0    	b.eq	0x10001f764 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x14cc>
10001f8ac: 8b1b0ae9    	add	x9, x23, x27, lsl #2
10001f8b0: 7940012a    	ldrh	w10, [x9]
10001f8b4: 7900052a    	strh	w10, [x9, #0x2]
10001f8b8: 7900013c    	strh	w28, [x9]
10001f8bc: eb05011f    	cmp	x8, x5
10001f8c0: 54fffe83    	b.lo	0x10001f890 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x15f8>
10001f8c4: d280001b    	mov	x27, #0x0               ; =0
10001f8c8: 9100079c    	add	x28, x28, #0x1
10001f8cc: 91000508    	add	x8, x8, #0x1
10001f8d0: f10006b5    	subs	x21, x21, #0x1
10001f8d4: 54fffec1    	b.ne	0x10001f8ac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1614>
10001f8d8: 17ffffa3    	b	0x10001f764 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x14cc>
10001f8dc: 52808088    	mov	w8, #0x404              ; =1028
10001f8e0: 17ffff25    	b	0x10001f574 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x12dc>
10001f8e4: d280000c    	mov	x12, #0x0               ; =0
10001f8e8: 17ffff2e    	b	0x10001f5a0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1308>
10001f8ec: f940fbe8    	ldr	x8, [sp, #0x1f0]
10001f8f0: f9419bec    	ldr	x12, [sp, #0x330]
10001f8f4: eb0c011f    	cmp	x8, x12
10001f8f8: 540002a0    	b.eq	0x10001f94c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x16b4>
10001f8fc: aa1e03f8    	mov	x24, x30
10001f900: aa0603ec    	mov	x12, x6
10001f904: f941abe0    	ldr	x0, [sp, #0x350]
10001f908: f9419bed    	ldr	x13, [sp, #0x330]
10001f90c: aa0d03e1    	mov	x1, x13
10001f910: f94187e2    	ldr	x2, [sp, #0x308]
10001f914: 940042c7    	bl	0x100030430 <_roc_cold_shim.roc_builtins_list_slack_unique>
10001f918: aa0d03e1    	mov	x1, x13
10001f91c: 8b0d0008    	add	x8, x0, x13
10001f920: f9019be8    	str	x8, [sp, #0x330]
10001f924: f9419fe2    	ldr	x2, [sp, #0x338]
10001f928: f941a3e3    	ldr	x3, [sp, #0x340]
10001f92c: 5294f7a4    	mov	w4, #0xa7bd             ; =42941
10001f930: 72a3c6a4    	movk	w4, #0x1e35, lsl #16
10001f934: f94197e5    	ldr	x5, [sp, #0x328]
10001f938: 4f04a404    	movi.8h	v4, #0x80, lsl #8
10001f93c: aa0c03e6    	mov	x6, x12
10001f940: aa1803fe    	mov	x30, x24
10001f944: f94193f8    	ldr	x24, [sp, #0x320]
10001f948: 17ffff20    	b	0x10001f5c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1330>
10001f94c: aa0603ec    	mov	x12, x6
10001f950: aa1e03f8    	mov	x24, x30
10001f954: f94187e8    	ldr	x8, [sp, #0x308]
10001f958: 37000228    	tbnz	w8, #0x0, 0x10001f99c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1704>
10001f95c: f94187e8    	ldr	x8, [sp, #0x308]
10001f960: d341fd08    	lsr	x8, x8, #1
10001f964: f940fbed    	ldr	x13, [sp, #0x1f0]
10001f968: eb0d011f    	cmp	x8, x13
10001f96c: 54000180    	b.eq	0x10001f99c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1704>
10001f970: f941abe0    	ldr	x0, [sp, #0x350]
10001f974: f940fbed    	ldr	x13, [sp, #0x1f0]
10001f978: aa0d03e1    	mov	x1, x13
10001f97c: f94187e2    	ldr	x2, [sp, #0x308]
10001f980: 940042ac    	bl	0x100030430 <_roc_cold_shim.roc_builtins_list_slack_unique>
10001f984: f9019bed    	str	x13, [sp, #0x330]
10001f988: 8b0d0008    	add	x8, x0, x13
10001f98c: f900fbe8    	str	x8, [sp, #0x1f0]
10001f990: f9417ff9    	ldr	x25, [sp, #0x2f8]
10001f994: f9418ff6    	ldr	x22, [sp, #0x318]
10001f998: 17ffffdb    	b	0x10001f904 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x166c>
10001f99c: f941abe0    	ldr	x0, [sp, #0x350]
10001f9a0: f940fbe1    	ldr	x1, [sp, #0x1f0]
10001f9a4: f94187e2    	ldr	x2, [sp, #0x308]
10001f9a8: 52800023    	mov	w3, #0x1                ; =1
10001f9ac: 52800104    	mov	w4, #0x8                ; =8
10001f9b0: 52800025    	mov	w5, #0x1                ; =1
10001f9b4: 94004249    	bl	0x1000302d8 <_roc_cold_shim.roc_builtins_list_reserve_for_append>
10001f9b8: f901abe0    	str	x0, [sp, #0x350]
10001f9bc: f900fbe1    	str	x1, [sp, #0x1f0]
10001f9c0: f90187e2    	str	x2, [sp, #0x308]
10001f9c4: 17ffffeb    	b	0x10001f970 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x16d8>
10001f9c8: b40027e8    	cbz	x8, 0x10001fec4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1c2c>
10001f9cc: eb1a007f    	cmp	x3, x26
10001f9d0: 54002a29    	b.ls	0x10001ff14 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1c7c>
10001f9d4: 387a6849    	ldrb	w9, [x2, x26]
10001f9d8: d37ef529    	lsl	x9, x9, #2
10001f9dc: b8696aca    	ldr	w10, [x22, x9]
10001f9e0: 1100054a    	add	w10, w10, #0x1
10001f9e4: b8296aca    	str	w10, [x22, x9]
10001f9e8: f100051f    	cmp	x8, #0x1
10001f9ec: 540003a0    	b.eq	0x10001fa60 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x17c8>
10001f9f0: 91000749    	add	x9, x26, #0x1
10001f9f4: eb03013f    	cmp	x9, x3
10001f9f8: 540029c2    	b.hs	0x10001ff30 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1c98>
10001f9fc: 38696849    	ldrb	w9, [x2, x9]
10001fa00: d37ef529    	lsl	x9, x9, #2
10001fa04: b8696aca    	ldr	w10, [x22, x9]
10001fa08: 1100054a    	add	w10, w10, #0x1
10001fa0c: b8296aca    	str	w10, [x22, x9]
10001fa10: f100091f    	cmp	x8, #0x2
10001fa14: 54000260    	b.eq	0x10001fa60 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x17c8>
10001fa18: 91000b49    	add	x9, x26, #0x2
10001fa1c: eb03013f    	cmp	x9, x3
10001fa20: 54002962    	b.hs	0x10001ff4c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1cb4>
10001fa24: 38696849    	ldrb	w9, [x2, x9]
10001fa28: d37ef529    	lsl	x9, x9, #2
10001fa2c: b8696aca    	ldr	w10, [x22, x9]
10001fa30: 1100054a    	add	w10, w10, #0x1
10001fa34: b8296aca    	str	w10, [x22, x9]
10001fa38: f1000d1f    	cmp	x8, #0x3
10001fa3c: 54000120    	b.eq	0x10001fa60 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x17c8>
10001fa40: 91000f49    	add	x9, x26, #0x3
10001fa44: eb03013f    	cmp	x9, x3
10001fa48: 54002902    	b.hs	0x10001ff68 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1cd0>
10001fa4c: 38696849    	ldrb	w9, [x2, x9]
10001fa50: d37ef529    	lsl	x9, x9, #2
10001fa54: b8696aca    	ldr	w10, [x22, x9]
10001fa58: 1100054a    	add	w10, w10, #0x1
10001fa5c: b8296aca    	str	w10, [x22, x9]
10001fa60: aa0303f3    	mov	x19, x3
10001fa64: aa0803e6    	mov	x6, x8
10001fa68: f9419be8    	ldr	x8, [sp, #0x330]
10001fa6c: eb01011f    	cmp	x8, x1
10001fa70: 54002340    	b.eq	0x10001fed8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1c40>
10001fa74: 914007fa    	add	x26, sp, #0x1, lsl #12  ; =0x1000
10001fa78: 9136035a    	add	x26, x26, #0xd80
10001fa7c: f941b3e8    	ldr	x8, [sp, #0x360]
10001fa80: cb080268    	sub	x8, x19, x8
10001fa84: 2a0803e8    	mov	w8, w8
10001fa88: f941abe9    	ldr	x9, [sp, #0x350]
10001fa8c: f8217928    	str	x8, [x9, x1, lsl #3]
10001fa90: f94153e9    	ldr	x9, [sp, #0x2a0]
10001fa94: b9440928    	ldr	w8, [x9, #0x408]
10001fa98: 31000508    	adds	w8, w8, #0x1
10001fa9c: 54056262    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10001faa0: f90183e6    	str	x6, [sp, #0x300]
10001faa4: f901b3fe    	str	x30, [sp, #0x360]
10001faa8: 9100042a    	add	x10, x1, #0x1
10001faac: f9019bea    	str	x10, [sp, #0x330]
10001fab0: b9040928    	str	w8, [x9, #0x408]
10001fab4: 52802a00    	mov	w0, #0x150              ; =336
10001fab8: 52800101    	mov	w1, #0x8                ; =8
10001fabc: 97ff8b71    	bl	0x100002880 <_roc_alloc>
10001fac0: 52800035    	mov	w21, #0x1               ; =1
10001fac4: f9000015    	str	x21, [x0]
10001fac8: 6f00e400    	movi.2d	v0, #0000000000000000
10001facc: 3c818000    	stur	q0, [x0, #0x18]
10001fad0: 3c828000    	stur	q0, [x0, #0x28]
10001fad4: 3c838000    	stur	q0, [x0, #0x38]
10001fad8: 3c848000    	stur	q0, [x0, #0x48]
10001fadc: 3c858000    	stur	q0, [x0, #0x58]
10001fae0: 3c868000    	stur	q0, [x0, #0x68]
10001fae4: 3c878000    	stur	q0, [x0, #0x78]
10001fae8: 3c888000    	stur	q0, [x0, #0x88]
10001faec: 3c898000    	stur	q0, [x0, #0x98]
10001faf0: 3c8a8000    	stur	q0, [x0, #0xa8]
10001faf4: 3c8b8000    	stur	q0, [x0, #0xb8]
10001faf8: 3c8c8000    	stur	q0, [x0, #0xc8]
10001fafc: 3c8d8000    	stur	q0, [x0, #0xd8]
10001fb00: 3c8e8000    	stur	q0, [x0, #0xe8]
10001fb04: 3c8f8000    	stur	q0, [x0, #0xf8]
10001fb08: 3904a01f    	strb	wzr, [x0, #0x128]
10001fb0c: 3c808c00    	str	q0, [x0, #0x8]!
10001fb10: ad080000    	stp	q0, q0, [x0, #0x100]
10001fb14: f90ee7e0    	str	x0, [sp, #0x1dc8]
10001fb18: 3dc09be0    	ldr	q0, [sp, #0x260]
10001fb1c: 3c850340    	stur	q0, [x26, #0x50]
10001fb20: 52809600    	mov	w0, #0x4b0              ; =1200
10001fb24: 52800101    	mov	w1, #0x8                ; =8
10001fb28: 97ff8b56    	bl	0x100002880 <_roc_alloc>
10001fb2c: aa0003e8    	mov	x8, x0
10001fb30: b8008d1f    	str	wzr, [x8, #0x8]!
10001fb34: f9000015    	str	x21, [x0]
10001fb38: f940010a    	ldr	x10, [x8]
10001fb3c: aa0003e9    	mov	x9, x0
10001fb40: f800cd2a    	str	x10, [x9, #0xc]!
10001fb44: f900080a    	str	x10, [x0, #0x10]
10001fb48: 9280026a    	mov	x10, #-0x14             ; =-20
10001fb4c: f940012b    	ldr	x11, [x9]
10001fb50: f8028d2b    	str	x11, [x9, #0x28]!
10001fb54: a93e2d2b    	stp	x11, x11, [x9, #-0x20]
10001fb58: a93f2d2b    	stp	x11, x11, [x9, #-0x10]
10001fb5c: 9100a14a    	add	x10, x10, #0x28
10001fb60: f111815f    	cmp	x10, #0x460
10001fb64: 54ffff43    	b.lo	0x10001fb4c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x18b4>
10001fb68: f904d3e8    	str	x8, [sp, #0x9a0]
10001fb6c: 912683fc    	add	x28, sp, #0x9a0
10001fb70: 3dc097e0    	ldr	q0, [sp, #0x250]
10001fb74: 3c808380    	stur	q0, [x28, #0x8]
10001fb78: f90c5ff6    	str	x22, [sp, #0x18b8]
10001fb7c: 914007f8    	add	x24, sp, #0x1, lsl #12  ; =0x1000
10001fb80: 9122e318    	add	x24, x24, #0x8b8
10001fb84: 3dc0b7e0    	ldr	q0, [sp, #0x2d0]
10001fb88: 3c808300    	stur	q0, [x24, #0x8]
10001fb8c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10001fb90: 91222000    	add	x0, x0, #0x888
10001fb94: 914007e3    	add	x3, sp, #0x1, lsl #12   ; =0x1000
10001fb98: 9122e063    	add	x3, x3, #0x8b8
10001fb9c: 914007e4    	add	x4, sp, #0x1, lsl #12   ; =0x1000
10001fba0: 91372084    	add	x4, x4, #0xdc8
10001fba4: 912683e5    	add	x5, sp, #0x9a0
10001fba8: 52802401    	mov	w1, #0x120              ; =288
10001fbac: 528001c2    	mov	w2, #0xe                ; =14
10001fbb0: 94003ae6    	bl	0x10002e748 <_roc__p1a804bfda1f5e4235a696be5d06bcb43.fast>
10001fbb4: 52800a00    	mov	w0, #0x50               ; =80
10001fbb8: 52800101    	mov	w1, #0x8                ; =8
10001fbbc: 97ff8b31    	bl	0x100002880 <_roc_alloc>
10001fbc0: 52800035    	mov	w21, #0x1               ; =1
10001fbc4: f9000015    	str	x21, [x0]
10001fbc8: 6f00e400    	movi.2d	v0, #0000000000000000
10001fbcc: 3c818000    	stur	q0, [x0, #0x18]
10001fbd0: 3900a01f    	strb	wzr, [x0, #0x28]
10001fbd4: 3c808c00    	str	q0, [x0, #0x8]!
10001fbd8: f90ee7e0    	str	x0, [sp, #0x1dc8]
10001fbdc: 3dc093e0    	ldr	q0, [sp, #0x240]
10001fbe0: 3c850340    	stur	q0, [x26, #0x50]
10001fbe4: 52801600    	mov	w0, #0xb0               ; =176
10001fbe8: 52800101    	mov	w1, #0x8                ; =8
10001fbec: 97ff8b25    	bl	0x100002880 <_roc_alloc>
10001fbf0: f9000015    	str	x21, [x0]
10001fbf4: aa0003e8    	mov	x8, x0
10001fbf8: b8008d1f    	str	wzr, [x8, #0x8]!
10001fbfc: f9400109    	ldr	x9, [x8]
10001fc00: f800c009    	stur	x9, [x0, #0xc]
10001fc04: f9000809    	str	x9, [x0, #0x10]
10001fc08: f840c009    	ldur	x9, [x0, #0xc]
10001fc0c: f8014009    	stur	x9, [x0, #0x14]
10001fc10: 4e080d20    	dup.2d	v0, x9
10001fc14: 3c82c000    	stur	q0, [x0, #0x2c]
10001fc18: 3c81c000    	stur	q0, [x0, #0x1c]
10001fc1c: 3c84c000    	stur	q0, [x0, #0x4c]
10001fc20: 3c83c000    	stur	q0, [x0, #0x3c]
10001fc24: 3c86c000    	stur	q0, [x0, #0x6c]
10001fc28: 3c85c000    	stur	q0, [x0, #0x5c]
10001fc2c: f807c009    	stur	x9, [x0, #0x7c]
10001fc30: f8084009    	stur	x9, [x0, #0x84]
10001fc34: f904d3e8    	str	x8, [sp, #0x9a0]
10001fc38: 3dc08be0    	ldr	q0, [sp, #0x220]
10001fc3c: 3c808380    	stur	q0, [x28, #0x8]
10001fc40: f941a7f5    	ldr	x21, [sp, #0x348]
10001fc44: f90c5ff5    	str	x21, [sp, #0x18b8]
10001fc48: 3dc0b3e0    	ldr	q0, [sp, #0x2c0]
10001fc4c: 3c808300    	stur	q0, [x24, #0x8]
10001fc50: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10001fc54: 91216000    	add	x0, x0, #0x858
10001fc58: 914007e3    	add	x3, sp, #0x1, lsl #12   ; =0x1000
10001fc5c: 9122e063    	add	x3, x3, #0x8b8
10001fc60: 914007e4    	add	x4, sp, #0x1, lsl #12   ; =0x1000
10001fc64: 91372084    	add	x4, x4, #0xdc8
10001fc68: 912683e5    	add	x5, sp, #0x9a0
10001fc6c: 52800401    	mov	w1, #0x20               ; =32
10001fc70: 528001e2    	mov	w2, #0xf                ; =15
10001fc74: 94003ab5    	bl	0x10002e748 <_roc__p1a804bfda1f5e4235a696be5d06bcb43.fast>
10001fc78: f94173e5    	ldr	x5, [sp, #0x2e0]
10001fc7c: eb050266    	subs	x6, x19, x5
10001fc80: 540553e3    	b.lo	0x10002a6fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc464>
10001fc84: f941a3ea    	ldr	x10, [sp, #0x340]
10001fc88: eb0a027f    	cmp	x19, x10
10001fc8c: 1a9f17e8    	cset	w8, eq
10001fc90: f904d7ff    	str	xzr, [sp, #0x9a8]
10001fc94: f904d3ff    	str	xzr, [sp, #0x9a0]
10001fc98: f904dbff    	str	xzr, [sp, #0x9b0]
10001fc9c: f94143e9    	ldr	x9, [sp, #0x280]
10001fca0: f90c0be9    	str	x9, [sp, #0x1810]
10001fca4: f90c0ff9    	str	x25, [sp, #0x1818]
10001fca8: f9414be9    	ldr	x9, [sp, #0x290]
10001fcac: f90c13e9    	str	x9, [sp, #0x1820]
10001fcb0: f9419fe9    	ldr	x9, [sp, #0x338]
10001fcb4: f90c17e9    	str	x9, [sp, #0x1828]
10001fcb8: f90c1bea    	str	x10, [sp, #0x1830]
10001fcbc: f9413fe9    	ldr	x9, [sp, #0x278]
10001fcc0: f90c1fe9    	str	x9, [sp, #0x1838]
10001fcc4: f941abe9    	ldr	x9, [sp, #0x350]
10001fcc8: f90c23e9    	str	x9, [sp, #0x1840]
10001fccc: f9419be9    	ldr	x9, [sp, #0x330]
10001fcd0: f90c27e9    	str	x9, [sp, #0x1848]
10001fcd4: f94187e9    	ldr	x9, [sp, #0x308]
10001fcd8: f90c2be9    	str	x9, [sp, #0x1850]
10001fcdc: f90c5ff6    	str	x22, [sp, #0x18b8]
10001fce0: ad5607e0    	ldp	q0, q1, [sp, #0x2c0]
10001fce4: 3c808301    	stur	q1, [x24, #0x8]
10001fce8: f90ee7f5    	str	x21, [sp, #0x1dc8]
10001fcec: 3c850340    	stur	q0, [x26, #0x50]
10001fcf0: a905a3ff    	stp	xzr, x8, [sp, #0x58]
10001fcf4: 912683e8    	add	x8, sp, #0x9a0
10001fcf8: f9002be8    	str	x8, [sp, #0x50]
10001fcfc: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
10001fd00: 911b8108    	add	x8, x8, #0x6e0
10001fd04: f90027e8    	str	x8, [sp, #0x48]
10001fd08: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
10001fd0c: 911b0108    	add	x8, x8, #0x6c0
10001fd10: f90023e8    	str	x8, [sp, #0x40]
10001fd14: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
10001fd18: 911a8108    	add	x8, x8, #0x6a0
10001fd1c: f9001fe8    	str	x8, [sp, #0x38]
10001fd20: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
10001fd24: 911a0108    	add	x8, x8, #0x680
10001fd28: f9001be8    	str	x8, [sp, #0x30]
10001fd2c: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
10001fd30: 91216108    	add	x8, x8, #0x858
10001fd34: f90017e8    	str	x8, [sp, #0x28]
10001fd38: f94103e9    	ldr	x9, [sp, #0x200]
10001fd3c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10001fd40: 911be000    	add	x0, x0, #0x6f8
10001fd44: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
10001fd48: 91204021    	add	x1, x1, #0x810
10001fd4c: 914007e4    	add	x4, sp, #0x1, lsl #12   ; =0x1000
10001fd50: 9120a084    	add	x4, x4, #0x828
10001fd54: 914007e7    	add	x7, sp, #0x1, lsl #12   ; =0x1000
10001fd58: 912100e7    	add	x7, x7, #0x840
10001fd5c: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
10001fd60: 91222108    	add	x8, x8, #0x888
10001fd64: a901a7e8    	stp	x8, x9, [sp, #0x18]
10001fd68: f9410fe9    	ldr	x9, [sp, #0x218]
10001fd6c: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
10001fd70: 91372108    	add	x8, x8, #0xdc8
10001fd74: a900a7e8    	stp	x8, x9, [sp, #0x8]
10001fd78: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
10001fd7c: 9122e108    	add	x8, x8, #0x8b8
10001fd80: f90003e8    	str	x8, [sp]
10001fd84: f94157e2    	ldr	x2, [sp, #0x2a8]
10001fd88: f9415be3    	ldr	x3, [sp, #0x2b0]
10001fd8c: 97ffd7e2    	bl	0x100015d14 <_roc__p81003bf97431a8821d5be871f2471565.fast>
10001fd90: f90ec3f5    	str	x21, [sp, #0x1d80]
10001fd94: 3dc0b3e0    	ldr	q0, [sp, #0x2c0]
10001fd98: 3c808340    	stur	q0, [x26, #0x8]
10001fd9c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10001fda0: 91360000    	add	x0, x0, #0xd80
10001fda4: 94004107    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10001fda8: f90ec3f6    	str	x22, [sp, #0x1d80]
10001fdac: 3dc0b7e0    	ldr	q0, [sp, #0x2d0]
10001fdb0: 3c808340    	stur	q0, [x26, #0x8]
10001fdb4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10001fdb8: 91360000    	add	x0, x0, #0xd80
10001fdbc: 94004101    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10001fdc0: f94bd3fc    	ldr	x28, [sp, #0x17a0]
10001fdc4: f94bd7e8    	ldr	x8, [sp, #0x17a8]
10001fdc8: f90187e8    	str	x8, [sp, #0x308]
10001fdcc: f94bc3fa    	ldr	x26, [sp, #0x1780]
10001fdd0: f94bc7f9    	ldr	x25, [sp, #0x1788]
10001fdd4: f94bcfe8    	ldr	x8, [sp, #0x1798]
10001fdd8: f901abe8    	str	x8, [sp, #0x350]
10001fddc: f94bcbf6    	ldr	x22, [sp, #0x1790]
10001fde0: f94b7fe8    	ldr	x8, [sp, #0x16f8]
10001fde4: f90157e8    	str	x8, [sp, #0x2a8]
10001fde8: f94b83e8    	ldr	x8, [sp, #0x1700]
10001fdec: f9015be8    	str	x8, [sp, #0x2b0]
10001fdf0: 914007f8    	add	x24, sp, #0x1, lsl #12  ; =0x1000
10001fdf4: 911be318    	add	x24, x24, #0x6f8
10001fdf8: 3cc10300    	ldur	q0, [x24, #0x10]
10001fdfc: 3d8763e0    	str	q0, [sp, #0x1d80]
10001fe00: f8420308    	ldur	x8, [x24, #0x20]
10001fe04: f90ecbe8    	str	x8, [sp, #0x1d90]
10001fe08: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10001fe0c: 91360000    	add	x0, x0, #0xd80
10001fe10: 940040ec    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10001fe14: 3cc28300    	ldur	q0, [x24, #0x28]
10001fe18: 3d8763e0    	str	q0, [sp, #0x1d80]
10001fe1c: f8438308    	ldur	x8, [x24, #0x38]
10001fe20: f90ecbe8    	str	x8, [sp, #0x1d90]
10001fe24: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10001fe28: 91360000    	add	x0, x0, #0xd80
10001fe2c: 940040e5    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10001fe30: 3cc40300    	ldur	q0, [x24, #0x40]
10001fe34: 3d8763e0    	str	q0, [sp, #0x1d80]
10001fe38: f8450308    	ldur	x8, [x24, #0x50]
10001fe3c: f90ecbe8    	str	x8, [sp, #0x1d90]
10001fe40: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10001fe44: 91360000    	add	x0, x0, #0xd80
10001fe48: 940040de    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10001fe4c: 3cc58300    	ldur	q0, [x24, #0x58]
10001fe50: 3d8763e0    	str	q0, [sp, #0x1d80]
10001fe54: f8468308    	ldur	x8, [x24, #0x68]
10001fe58: f90ecbe8    	str	x8, [sp, #0x1d90]
10001fe5c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10001fe60: 91360000    	add	x0, x0, #0xd80
10001fe64: 940040d7    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10001fe68: 3cc70300    	ldur	q0, [x24, #0x70]
10001fe6c: 3d8763e0    	str	q0, [sp, #0x1d80]
10001fe70: f8480308    	ldur	x8, [x24, #0x80]
10001fe74: f90ecbe8    	str	x8, [sp, #0x1d90]
10001fe78: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10001fe7c: 91360000    	add	x0, x0, #0xd80
10001fe80: 940040d0    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10001fe84: f9014bf6    	str	x22, [sp, #0x290]
10001fe88: 37073396    	tbnz	w22, #0x0, 0x10001e4f8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x260>
10001fe8c: f941b3f5    	ldr	x21, [sp, #0x360]
10001fe90: f94183ed    	ldr	x13, [sp, #0x300]
10001fe94: b4000096    	cbz	x22, 0x10001fea4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1c0c>
10001fe98: f85f8348    	ldur	x8, [x26, #-0x8]
10001fe9c: f100051f    	cmp	x8, #0x1
10001fea0: 540000c1    	b.ne	0x10001feb8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1c20>
10001fea4: f9414be8    	ldr	x8, [sp, #0x290]
10001fea8: d341fd08    	lsr	x8, x8, #1
10001feac: eb19011f    	cmp	x8, x25
10001feb0: 1a9f17f6    	cset	w22, eq
10001feb4: 14000002    	b	0x10001febc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1c24>
10001feb8: 52800036    	mov	w22, #0x1               ; =1
10001febc: f941a3ea    	ldr	x10, [sp, #0x340]
10001fec0: 17fff992    	b	0x10001e508 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x270>
10001fec4: d2800006    	mov	x6, #0x0                ; =0
10001fec8: aa1a03f3    	mov	x19, x26
10001fecc: f9419be8    	ldr	x8, [sp, #0x330]
10001fed0: eb01011f    	cmp	x8, x1
10001fed4: 54ffdd01    	b.ne	0x10001fa74 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x17dc>
10001fed8: f940fbe8    	ldr	x8, [sp, #0x1f0]
10001fedc: eb01011f    	cmp	x8, x1
10001fee0: 914007fa    	add	x26, sp, #0x1, lsl #12  ; =0x1000
10001fee4: 9136035a    	add	x26, x26, #0xd80
10001fee8: 54000440    	b.eq	0x10001ff70 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1cd8>
10001feec: aa1e03eb    	mov	x11, x30
10001fef0: aa0603ea    	mov	x10, x6
10001fef4: f941abe0    	ldr	x0, [sp, #0x350]
10001fef8: f94187e2    	ldr	x2, [sp, #0x308]
10001fefc: aa0103e9    	mov	x9, x1
10001ff00: 9400414c    	bl	0x100030430 <_roc_cold_shim.roc_builtins_list_slack_unique>
10001ff04: aa0903e1    	mov	x1, x9
10001ff08: aa0a03e6    	mov	x6, x10
10001ff0c: aa0b03fe    	mov	x30, x11
10001ff10: 17fffedb    	b	0x10001fa7c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x17e4>
10001ff14: d2800009    	mov	x9, #0x0                ; =0
10001ff18: b8696aca    	ldr	w10, [x22, x9]
10001ff1c: 1100054a    	add	w10, w10, #0x1
10001ff20: b8296aca    	str	w10, [x22, x9]
10001ff24: f100051f    	cmp	x8, #0x1
10001ff28: 54ffd641    	b.ne	0x10001f9f0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1758>
10001ff2c: 17fffecd    	b	0x10001fa60 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x17c8>
10001ff30: d2800009    	mov	x9, #0x0                ; =0
10001ff34: b8696aca    	ldr	w10, [x22, x9]
10001ff38: 1100054a    	add	w10, w10, #0x1
10001ff3c: b8296aca    	str	w10, [x22, x9]
10001ff40: f100091f    	cmp	x8, #0x2
10001ff44: 54ffd6a1    	b.ne	0x10001fa18 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1780>
10001ff48: 17fffec6    	b	0x10001fa60 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x17c8>
10001ff4c: d2800009    	mov	x9, #0x0                ; =0
10001ff50: b8696aca    	ldr	w10, [x22, x9]
10001ff54: 1100054a    	add	w10, w10, #0x1
10001ff58: b8296aca    	str	w10, [x22, x9]
10001ff5c: f1000d1f    	cmp	x8, #0x3
10001ff60: 54ffd701    	b.ne	0x10001fa40 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x17a8>
10001ff64: 17fffebf    	b	0x10001fa60 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x17c8>
10001ff68: d2800009    	mov	x9, #0x0                ; =0
10001ff6c: 17fffeba    	b	0x10001fa54 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x17bc>
10001ff70: aa0603ea    	mov	x10, x6
10001ff74: aa1e03e9    	mov	x9, x30
10001ff78: f94187e8    	ldr	x8, [sp, #0x308]
10001ff7c: 37000208    	tbnz	w8, #0x0, 0x10001ffbc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1d24>
10001ff80: f94187e8    	ldr	x8, [sp, #0x308]
10001ff84: d341fd08    	lsr	x8, x8, #1
10001ff88: eb01011f    	cmp	x8, x1
10001ff8c: 54000180    	b.eq	0x10001ffbc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1d24>
10001ff90: f941abe0    	ldr	x0, [sp, #0x350]
10001ff94: aa0103eb    	mov	x11, x1
10001ff98: f94187e2    	ldr	x2, [sp, #0x308]
10001ff9c: 94004125    	bl	0x100030430 <_roc_cold_shim.roc_builtins_list_slack_unique>
10001ffa0: aa0b03e1    	mov	x1, x11
10001ffa4: f9417ff9    	ldr	x25, [sp, #0x2f8]
10001ffa8: 914007fa    	add	x26, sp, #0x1, lsl #12  ; =0x1000
10001ffac: 9136035a    	add	x26, x26, #0xd80
10001ffb0: aa0903eb    	mov	x11, x9
10001ffb4: f9418ff6    	ldr	x22, [sp, #0x318]
10001ffb8: 17ffffcf    	b	0x10001fef4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1c5c>
10001ffbc: f941abe0    	ldr	x0, [sp, #0x350]
10001ffc0: f94187e2    	ldr	x2, [sp, #0x308]
10001ffc4: 52800023    	mov	w3, #0x1                ; =1
10001ffc8: 52800104    	mov	w4, #0x8                ; =8
10001ffcc: 52800025    	mov	w5, #0x1                ; =1
10001ffd0: 940040c2    	bl	0x1000302d8 <_roc_cold_shim.roc_builtins_list_reserve_for_append>
10001ffd4: f901abe0    	str	x0, [sp, #0x350]
10001ffd8: f90187e2    	str	x2, [sp, #0x308]
10001ffdc: 17ffffed    	b	0x10001ff90 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1cf8>
10001ffe0: b20183e8    	mov	x8, #-0x7fff7fff7fff8000 ; =-9223231297218904064
10001ffe4: f2900028    	movk	x8, #0x8001
10001ffe8: 9bc87d88    	umulh	x8, x12, x8
10001ffec: d34ffd08    	lsr	x8, x8, #15
10001fff0: 8b080908    	add	x8, x8, x8, lsl #2
10001fff4: 8b080188    	add	x8, x12, x8
10001fff8: 91001503    	add	x3, x8, #0x5
10001fffc: 3600005b    	tbz	w27, #0x0, 0x100020004 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1d6c>
100020000: 14002c4e    	b	0x10002b138 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xcea0>
100020004: d341ff68    	lsr	x8, x27, #1
100020008: cb190108    	sub	x8, x8, x25
10002000c: eb03011f    	cmp	x8, x3
100020010: 54058943    	b.lo	0x10002b138 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xcea0>
100020014: b4058a6c    	cbz	x12, 0x10002b160 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xcec8>
100020018: 370002db    	tbnz	w27, #0x0, 0x100020070 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1dd8>
10002001c: b400009b    	cbz	x27, 0x10002002c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1d94>
100020020: f85f8348    	ldur	x8, [x26, #-0x8]
100020024: f100051f    	cmp	x8, #0x1
100020028: 54000241    	b.ne	0x100020070 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1dd8>
10002002c: d341ff68    	lsr	x8, x27, #1
100020030: cb190108    	sub	x8, x8, x25
100020034: 14000010    	b	0x100020074 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1ddc>
100020038: 7100291f    	cmp	w8, #0xa
10002003c: 54001863    	b.lo	0x100020348 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x20b0>
100020040: f90143fa    	str	x26, [sp, #0x280]
100020044: 12001c48    	and	w8, w2, #0xff
100020048: 7100291f    	cmp	w8, #0xa
10002004c: 54013921    	b.ne	0x100022770 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x44d8>
100020050: f90093ff    	str	xzr, [sp, #0x120]
100020054: 5280097a    	mov	w26, #0x4b              ; =75
100020058: 5280040a    	mov	w10, #0x20              ; =32
10002005c: 52800468    	mov	w8, #0x23               ; =35
100020060: f90197e8    	str	x8, [sp, #0x328]
100020064: 52800048    	mov	w8, #0x2                ; =2
100020068: f9007fe8    	str	x8, [sp, #0xf8]
10002006c: 140009d3    	b	0x1000227b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4520>
100020070: d2800008    	mov	x8, #0x0                ; =0
100020074: d2800015    	mov	x21, #0x0               ; =0
100020078: 8b190109    	add	x9, x8, x25
10002007c: 529ffff7    	mov	w23, #0xffff            ; =65535
100020080: eb150188    	subs	x8, x12, x21
100020084: 540533c3    	b.lo	0x10002a6fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc464>
100020088: eb17011f    	cmp	x8, x23
10002008c: 9a973113    	csel	x19, x8, x23, lo
100020090: f140411f    	cmp	x8, #0x10, lsl #12      ; =0x10000
100020094: 1a9f27ea    	cset	w10, lo
100020098: eb09033f    	cmp	x25, x9
10002009c: 54000ac0    	b.eq	0x1000201f4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1f5c>
1000200a0: 38396b4a    	strb	w10, [x26, x25]
1000200a4: 91000721    	add	x1, x25, #0x1
1000200a8: cb010128    	sub	x8, x9, x1
1000200ac: f1001d1f    	cmp	x8, #0x7
1000200b0: 54000c49    	b.ls	0x100020238 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1fa0>
1000200b4: f8216b53    	str	x19, [x26, x1]
1000200b8: 91000f2a    	add	x10, x25, #0x3
1000200bc: aa3303e8    	mvn	x8, x19
1000200c0: cb0a0129    	sub	x9, x9, x10
1000200c4: f1001d3f    	cmp	x9, #0x7
1000200c8: 54000dc9    	b.ls	0x100020280 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1fe8>
1000200cc: f82a6b48    	str	x8, [x26, x10]
1000200d0: 91000959    	add	x25, x10, #0x2
1000200d4: eb0c02bf    	cmp	x21, x12
1000200d8: 9a8c32b4    	csel	x20, x21, x12, lo
1000200dc: cb140188    	sub	x8, x12, x20
1000200e0: eb08027f    	cmp	x19, x8
1000200e4: 9a883276    	csel	x22, x19, x8, lo
1000200e8: b4000676    	cbz	x22, 0x1000201b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1f1c>
1000200ec: d341ff69    	lsr	x9, x27, #1
1000200f0: f240037f    	tst	x27, #0x1
1000200f4: 9a990128    	csel	x8, x9, x25, eq
1000200f8: cb190108    	sub	x8, x8, x25
1000200fc: eb0802df    	cmp	x22, x8
100020100: 54000249    	b.ls	0x100020148 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1eb0>
100020104: ab160328    	adds	x8, x25, x22
100020108: da9f3102    	csinv	x2, x8, xzr, lo
10002010c: f90ee7fa    	str	x26, [sp, #0x1dc8]
100020110: f90eebf9    	str	x25, [sp, #0x1dd0]
100020114: f90eeffb    	str	x27, [sp, #0x1dd8]
100020118: aa1903e8    	mov	x8, x25
10002011c: 3700009b    	tbnz	w27, #0x0, 0x10002012c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1e94>
100020120: aa0903e8    	mov	x8, x9
100020124: eb09005f    	cmp	x2, x9
100020128: 54000229    	b.ls	0x10002016c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1ed4>
10002012c: b4000128    	cbz	x8, 0x100020150 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1eb8>
100020130: f13ffd1f    	cmp	x8, #0xfff
100020134: 54000069    	b.ls	0x100020140 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1ea8>
100020138: f140811f    	cmp	x8, #0x20, lsl #12      ; =0x20000
10002013c: 540000e9    	b.ls	0x100020158 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1ec0>
100020140: d37ff908    	lsl	x8, x8, #1
100020144: 14000008    	b	0x100020164 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1ecc>
100020148: aa1a03f8    	mov	x24, x26
10002014c: 14000011    	b	0x100020190 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1ef8>
100020150: 52800808    	mov	w8, #0x40               ; =64
100020154: 14000004    	b	0x100020164 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1ecc>
100020158: 8b080508    	add	x8, x8, x8, lsl #1
10002015c: 91000508    	add	x8, x8, #0x1
100020160: d341fd08    	lsr	x8, x8, #1
100020164: eb08005f    	cmp	x2, x8
100020168: 9a888042    	csel	x2, x2, x8, hi
10002016c: 912683e0    	add	x0, sp, #0x9a0
100020170: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
100020174: 91372021    	add	x1, x1, #0xdc8
100020178: 52800023    	mov	w3, #0x1                ; =1
10002017c: 52800024    	mov	w4, #0x1                ; =1
100020180: 94004632    	bl	0x100031a48 <_list.RocList.reallocate>
100020184: f944d3f8    	ldr	x24, [sp, #0x9a0]
100020188: f944dbfb    	ldr	x27, [sp, #0x9b0]
10002018c: f9419feb    	ldr	x11, [sp, #0x338]
100020190: eb1a017f    	cmp	x11, x26
100020194: 9a8b0308    	csel	x8, x24, x11, eq
100020198: 8b190300    	add	x0, x24, x25
10002019c: 8b140101    	add	x1, x8, x20
1000201a0: aa1603e2    	mov	x2, x22
1000201a4: 940048c1    	bl	0x1000324a8 <dyld_stub_binder+0x1000324a8>
1000201a8: f9419feb    	ldr	x11, [sp, #0x338]
1000201ac: 8b160339    	add	x25, x25, x22
1000201b0: aa1803fa    	mov	x26, x24
1000201b4: 3700011b    	tbnz	w27, #0x0, 0x1000201d4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1f3c>
1000201b8: b400009b    	cbz	x27, 0x1000201c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1f30>
1000201bc: f85f8348    	ldur	x8, [x26, #-0x8]
1000201c0: f100051f    	cmp	x8, #0x1
1000201c4: 54000081    	b.ne	0x1000201d4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1f3c>
1000201c8: d341ff68    	lsr	x8, x27, #1
1000201cc: cb190108    	sub	x8, x8, x25
1000201d0: 14000002    	b	0x1000201d8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1f40>
1000201d4: d2800008    	mov	x8, #0x0                ; =0
1000201d8: f941a3ec    	ldr	x12, [sp, #0x340]
1000201dc: ab1302b5    	adds	x21, x21, x19
1000201e0: 54052842    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000201e4: 8b190109    	add	x9, x8, x25
1000201e8: eb0c02bf    	cmp	x21, x12
1000201ec: 54fff4a1    	b.ne	0x100020080 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1de8>
1000201f0: 14002bea    	b	0x10002b198 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xcf00>
1000201f4: 370006fb    	tbnz	w27, #0x0, 0x1000202d0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2038>
1000201f8: d341ff68    	lsr	x8, x27, #1
1000201fc: eb09011f    	cmp	x8, x9
100020200: 54000680    	b.eq	0x1000202d0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2038>
100020204: aa1a03e0    	mov	x0, x26
100020208: aa0903e1    	mov	x1, x9
10002020c: aa1b03e2    	mov	x2, x27
100020210: 94004088    	bl	0x100030430 <_roc_cold_shim.roc_builtins_list_slack_unique>
100020214: aa0903f9    	mov	x25, x9
100020218: 8b090009    	add	x9, x0, x9
10002021c: f9419feb    	ldr	x11, [sp, #0x338]
100020220: f941a3ec    	ldr	x12, [sp, #0x340]
100020224: 38396b4a    	strb	w10, [x26, x25]
100020228: 91000721    	add	x1, x25, #0x1
10002022c: cb010128    	sub	x8, x9, x1
100020230: f1001d1f    	cmp	x8, #0x7
100020234: 54fff408    	b.hi	0x1000200b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1e1c>
100020238: 3700063b    	tbnz	w27, #0x0, 0x1000202fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2064>
10002023c: 91002728    	add	x8, x25, #0x9
100020240: d341ff69    	lsr	x9, x27, #1
100020244: eb08013f    	cmp	x9, x8
100020248: 540005a3    	b.lo	0x1000202fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2064>
10002024c: f8216b53    	str	x19, [x26, x1]
100020250: 91000f2a    	add	x10, x25, #0x3
100020254: aa1a03e0    	mov	x0, x26
100020258: aa0a03e1    	mov	x1, x10
10002025c: aa1b03e2    	mov	x2, x27
100020260: 94004074    	bl	0x100030430 <_roc_cold_shim.roc_builtins_list_slack_unique>
100020264: 8b0a0009    	add	x9, x0, x10
100020268: f9419feb    	ldr	x11, [sp, #0x338]
10002026c: f941a3ec    	ldr	x12, [sp, #0x340]
100020270: aa3303e8    	mvn	x8, x19
100020274: cb0a0129    	sub	x9, x9, x10
100020278: f1001d3f    	cmp	x9, #0x7
10002027c: 54fff288    	b.hi	0x1000200cc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1e34>
100020280: 3700051b    	tbnz	w27, #0x0, 0x100020320 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2088>
100020284: 91002149    	add	x9, x10, #0x8
100020288: d341ff6b    	lsr	x11, x27, #1
10002028c: eb09017f    	cmp	x11, x9
100020290: 54000483    	b.lo	0x100020320 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2088>
100020294: f82a6b48    	str	x8, [x26, x10]
100020298: 91000959    	add	x25, x10, #0x2
10002029c: aa1a03e0    	mov	x0, x26
1000202a0: aa1903e1    	mov	x1, x25
1000202a4: aa1b03e2    	mov	x2, x27
1000202a8: 94004062    	bl	0x100030430 <_roc_cold_shim.roc_builtins_list_slack_unique>
1000202ac: f9419feb    	ldr	x11, [sp, #0x338]
1000202b0: f941a3ec    	ldr	x12, [sp, #0x340]
1000202b4: eb0c02bf    	cmp	x21, x12
1000202b8: 9a8c32b4    	csel	x20, x21, x12, lo
1000202bc: cb140188    	sub	x8, x12, x20
1000202c0: eb08027f    	cmp	x19, x8
1000202c4: 9a883276    	csel	x22, x19, x8, lo
1000202c8: b5fff136    	cbnz	x22, 0x1000200ec <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1e54>
1000202cc: 17ffffba    	b	0x1000201b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1f1c>
1000202d0: aa1a03e0    	mov	x0, x26
1000202d4: aa0903e1    	mov	x1, x9
1000202d8: aa1b03e2    	mov	x2, x27
1000202dc: 52800023    	mov	w3, #0x1                ; =1
1000202e0: 52800024    	mov	w4, #0x1                ; =1
1000202e4: 52800025    	mov	w5, #0x1                ; =1
1000202e8: 94003ffc    	bl	0x1000302d8 <_roc_cold_shim.roc_builtins_list_reserve_for_append>
1000202ec: aa0003fa    	mov	x26, x0
1000202f0: aa0103e9    	mov	x9, x1
1000202f4: aa0203fb    	mov	x27, x2
1000202f8: 17ffffc3    	b	0x100020204 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1f6c>
1000202fc: aa1a03e0    	mov	x0, x26
100020300: aa1b03e2    	mov	x2, x27
100020304: aa1303e3    	mov	x3, x19
100020308: 52800044    	mov	w4, #0x2                ; =2
10002030c: 94004053    	bl	0x100030458 <_roc_cold_shim.roc_builtins_list_append_le_bytes>
100020310: aa0003fa    	mov	x26, x0
100020314: aa0103ea    	mov	x10, x1
100020318: aa0203fb    	mov	x27, x2
10002031c: 17ffffce    	b	0x100020254 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1fbc>
100020320: aa3303e3    	mvn	x3, x19
100020324: aa1a03e0    	mov	x0, x26
100020328: aa0a03e1    	mov	x1, x10
10002032c: aa1b03e2    	mov	x2, x27
100020330: 52800044    	mov	w4, #0x2                ; =2
100020334: 94004049    	bl	0x100030458 <_roc_cold_shim.roc_builtins_list_append_le_bytes>
100020338: aa0003fa    	mov	x26, x0
10002033c: aa0103f9    	mov	x25, x1
100020340: aa0203fb    	mov	x27, x2
100020344: 17ffffd6    	b	0x10002029c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2004>
100020348: f9014bfb    	str	x27, [sp, #0x290]
10002034c: 12001c48    	and	w8, w2, #0xff
100020350: d28b2974    	mov	x20, #0x594b            ; =22859
100020354: f2a710d4    	movk	x20, #0x3886, lsl #16
100020358: f2d8bad4    	movk	x20, #0xc5d6, lsl #32
10002035c: f2e68db4    	movk	x20, #0x346d, lsl #48
100020360: f000009b    	adrp	x27, 0x100033000 <dyld_stub_binder+0x100033000>
100020364: f0000093    	adrp	x19, 0x100033000 <dyld_stub_binder+0x100033000>
100020368: f000009c    	adrp	x28, 0x100033000 <dyld_stub_binder+0x100033000>
10002036c: f0000097    	adrp	x23, 0x100033000 <dyld_stub_binder+0x100033000>
100020370: 71000d1f    	cmp	w8, #0x3
100020374: 54031502    	b.hs	0x100026614 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x837c>
100020378: f900a7e2    	str	x2, [sp, #0x148]
10002037c: 52800028    	mov	w8, #0x1                ; =1
100020380: f90113e8    	str	x8, [sp, #0x220]
100020384: 52800148    	mov	w8, #0xa                ; =10
100020388: f901a7e8    	str	x8, [sp, #0x348]
10002038c: 528000c8    	mov	w8, #0x6                ; =6
100020390: f90193e8    	str	x8, [sp, #0x320]
100020394: f1040588    	subs	x8, x12, #0x101
100020398: 9a8833e8    	csel	x8, xzr, x8, lo
10002039c: f90147e8    	str	x8, [sp, #0x288]
1000203a0: 912ac3e0    	add	x0, sp, #0xab0
1000203a4: 97ffe66a    	bl	0x100019d4c <_roc__pf8d88d29f38eeb441b6a5ad4fe5ffba5.fast>
1000203a8: f941a3e9    	ldr	x9, [sp, #0x340]
1000203ac: 528270e8    	mov	w8, #0x1387             ; =4999
1000203b0: 8b080128    	add	x8, x9, x8
1000203b4: 9bd47d08    	umulh	x8, x8, x20
1000203b8: d34afd08    	lsr	x8, x8, #10
1000203bc: f100051f    	cmp	x8, #0x1
1000203c0: 9a9f8508    	csinc	x8, x8, xzr, hi
1000203c4: 8b080908    	add	x8, x8, x8, lsl #2
1000203c8: 8b090103    	add	x3, x8, x9
1000203cc: f9414be2    	ldr	x2, [sp, #0x290]
1000203d0: 36000042    	tbz	w2, #0x0, 0x1000203d8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2140>
1000203d4: 140030bf    	b	0x10002c6d0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe438>
1000203d8: d341fc48    	lsr	x8, x2, #1
1000203dc: cb190108    	sub	x8, x8, x25
1000203e0: eb03011f    	cmp	x8, x3
1000203e4: 54061763    	b.lo	0x10002c6d0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe438>
1000203e8: 912ac3f4    	add	x20, sp, #0xab0
1000203ec: 52800509    	mov	w9, #0x28               ; =40
1000203f0: 72a00029    	movk	w9, #0x1, lsl #16
1000203f4: 52800508    	mov	w8, #0x28               ; =40
1000203f8: 72a00028    	movk	w8, #0x1, lsl #16
1000203fc: f90163e8    	str	x8, [sp, #0x2c0]
100020400: 91002120    	add	x0, x9, #0x8
100020404: 52800101    	mov	w1, #0x8                ; =8
100020408: 97ff891e    	bl	0x100002880 <_roc_alloc>
10002040c: aa0003e9    	mov	x9, x0
100020410: 78008d3f    	strh	wzr, [x9, #0x8]!
100020414: 52800028    	mov	w8, #0x1                ; =1
100020418: f9000008    	str	x8, [x0]
10002041c: f9018fe9    	str	x9, [sp, #0x318]
100020420: f9400129    	ldr	x9, [x9]
100020424: aa0003e8    	mov	x8, x0
100020428: f800ad09    	str	x9, [x8, #0xa]!
10002042c: f800c009    	stur	x9, [x0, #0xc]
100020430: f800e009    	stur	x9, [x0, #0xe]
100020434: f9000809    	str	x9, [x0, #0x10]
100020438: 928002a9    	mov	x9, #-0x16              ; =-22
10002043c: f940010a    	ldr	x10, [x8]
100020440: f8028d0a    	str	x10, [x8, #0x28]!
100020444: a93e290a    	stp	x10, x10, [x8, #-0x20]
100020448: a93f290a    	stp	x10, x10, [x8, #-0x10]
10002044c: 9100a129    	add	x9, x9, #0x28
100020450: d345fd2a    	lsr	x10, x9, #5
100020454: f11ffd5f    	cmp	x10, #0x7ff
100020458: 54ffff23    	b.lo	0x10002043c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x21a4>
10002045c: 52800509    	mov	w9, #0x28               ; =40
100020460: 72a00049    	movk	w9, #0x2, lsl #16
100020464: 52800508    	mov	w8, #0x28               ; =40
100020468: 72a00048    	movk	w8, #0x2, lsl #16
10002046c: f9015fe8    	str	x8, [sp, #0x2b8]
100020470: 91002120    	add	x0, x9, #0x8
100020474: 52800101    	mov	w1, #0x8                ; =8
100020478: 97ff8902    	bl	0x100002880 <_roc_alloc>
10002047c: aa0003eb    	mov	x11, x0
100020480: 78008d7f    	strh	wzr, [x11, #0x8]!
100020484: 52800028    	mov	w8, #0x1                ; =1
100020488: f9000008    	str	x8, [x0]
10002048c: f9400169    	ldr	x9, [x11]
100020490: aa0003e8    	mov	x8, x0
100020494: f800ad09    	str	x9, [x8, #0xa]!
100020498: f800c009    	stur	x9, [x0, #0xc]
10002049c: f800e009    	stur	x9, [x0, #0xe]
1000204a0: f9000809    	str	x9, [x0, #0x10]
1000204a4: 928002a9    	mov	x9, #-0x16              ; =-22
1000204a8: f940010a    	ldr	x10, [x8]
1000204ac: f8028d0a    	str	x10, [x8, #0x28]!
1000204b0: a93e290a    	stp	x10, x10, [x8, #-0x20]
1000204b4: a93f290a    	stp	x10, x10, [x8, #-0x10]
1000204b8: 9100a129    	add	x9, x9, #0x28
1000204bc: d345fd2a    	lsr	x10, x9, #5
1000204c0: f13ffd5f    	cmp	x10, #0xfff
1000204c4: 54ffff23    	b.lo	0x1000204a8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2210>
1000204c8: f9018beb    	str	x11, [sp, #0x310]
1000204cc: f90143fa    	str	x26, [sp, #0x280]
1000204d0: f9017ff9    	str	x25, [sp, #0x2f8]
1000204d4: 52800508    	mov	w8, #0x28               ; =40
1000204d8: 72a00028    	movk	w8, #0x1, lsl #16
1000204dc: 91002100    	add	x0, x8, #0x8
1000204e0: 52800101    	mov	w1, #0x8                ; =8
1000204e4: 97ff88e7    	bl	0x100002880 <_roc_alloc>
1000204e8: aa0003f6    	mov	x22, x0
1000204ec: 78008edf    	strh	wzr, [x22, #0x8]!
1000204f0: 52800028    	mov	w8, #0x1                ; =1
1000204f4: f9000008    	str	x8, [x0]
1000204f8: f94002c9    	ldr	x9, [x22]
1000204fc: aa0003e8    	mov	x8, x0
100020500: f800ad09    	str	x9, [x8, #0xa]!
100020504: f800c009    	stur	x9, [x0, #0xc]
100020508: f800e009    	stur	x9, [x0, #0xe]
10002050c: f9000809    	str	x9, [x0, #0x10]
100020510: 928002a9    	mov	x9, #-0x16              ; =-22
100020514: f940010a    	ldr	x10, [x8]
100020518: f8028d0a    	str	x10, [x8, #0x28]!
10002051c: a93e290a    	stp	x10, x10, [x8, #-0x20]
100020520: a93f290a    	stp	x10, x10, [x8, #-0x10]
100020524: 9100a129    	add	x9, x9, #0x28
100020528: d345fd2a    	lsr	x10, x9, #5
10002052c: f11ffd5f    	cmp	x10, #0x7ff
100020530: 54ffff23    	b.lo	0x100020514 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x227c>
100020534: 52835200    	mov	w0, #0x1a90             ; =6800
100020538: 72a000c0    	movk	w0, #0x6, lsl #16
10002053c: 52800101    	mov	w1, #0x8                ; =8
100020540: 97ff88d0    	bl	0x100002880 <_roc_alloc>
100020544: a91b7fff    	stp	xzr, xzr, [sp, #0x1b0]
100020548: d280001a    	mov	x26, #0x0               ; =0
10002054c: d280000d    	mov	x13, #0x0               ; =0
100020550: d280000e    	mov	x14, #0x0               ; =0
100020554: d280000c    	mov	x12, #0x0               ; =0
100020558: 52800028    	mov	w8, #0x1                ; =1
10002055c: f8008408    	str	x8, [x0], #0x8
100020560: f90133e0    	str	x0, [sp, #0x260]
100020564: 5290d455    	mov	w21, #0x86a2            ; =34466
100020568: 72a00035    	movk	w21, #0x1, lsl #16
10002056c: 3cc18280    	ldur	q0, [x20, #0x18]
100020570: 3d81e7e0    	str	q0, [sp, #0x790]
100020574: f9456fe8    	ldr	x8, [sp, #0xad8]
100020578: f94563e9    	ldr	x9, [sp, #0xac0]
10002057c: f903d3e8    	str	x8, [sp, #0x7a0]
100020580: f903e3e9    	str	x9, [sp, #0x7c0]
100020584: 3cc48280    	ldur	q0, [x20, #0x48]
100020588: f94587e8    	ldr	x8, [sp, #0xb08]
10002058c: f9457be9    	ldr	x9, [sp, #0xaf0]
100020590: f941a3eb    	ldr	x11, [sp, #0x340]
100020594: d1000d6a    	sub	x10, x11, #0x3
100020598: f901b7ea    	str	x10, [sp, #0x368]
10002059c: d100156a    	sub	x10, x11, #0x5
1000205a0: f900ebea    	str	x10, [sp, #0x1d0]
1000205a4: 912563ea    	add	x10, sp, #0x958
1000205a8: 9100614a    	add	x10, x10, #0x18
1000205ac: f900bbea    	str	x10, [sp, #0x170]
1000205b0: 9124a3ea    	add	x10, sp, #0x928
1000205b4: 9100614a    	add	x10, x10, #0x18
1000205b8: f900b7ea    	str	x10, [sp, #0x168]
1000205bc: f9419fea    	ldr	x10, [sp, #0x338]
1000205c0: 9100054a    	add	x10, x10, #0x1
1000205c4: f900cbea    	str	x10, [sp, #0x190]
1000205c8: f903f3e8    	str	x8, [sp, #0x7e0]
1000205cc: 5290000a    	mov	w10, #0x8000            ; =32768
1000205d0: 52a00038    	mov	w24, #0x10000           ; =65536
1000205d4: f90403e9    	str	x9, [sp, #0x800]
1000205d8: 52802048    	mov	w8, #0x102              ; =258
1000205dc: f901b3e8    	str	x8, [sp, #0x360]
1000205e0: 0f04a408    	movi.4h	v8, #0x80, lsl #8
1000205e4: 3dc18361    	ldr	q1, [x27, #0x600]
1000205e8: 3d8063e1    	str	q1, [sp, #0x180]
1000205ec: 3dc18662    	ldr	q2, [x19, #0x610]
1000205f0: 3dc16b83    	ldr	q3, [x28, #0x5a0]
1000205f4: d503201f    	nop
1000205f8: 5c0986c9    	ldr	d9, 0x1000336d0 <dyld_stub_binder+0x1000336d0>
1000205fc: d503201f    	nop
100020600: 9c098101    	ldr	q1, 0x100033620 <dyld_stub_binder+0x100033620>
100020604: 3d804fe1    	str	q1, [sp, #0x130]
100020608: 3dc17ee1    	ldr	q1, [x23, #0x5f0]
10002060c: 3d8057e1    	str	q1, [sp, #0x150]
100020610: 2f04a40a    	mvni.4h	v10, #0x80, lsl #8
100020614: 3dc2afe1    	ldr	q1, [sp, #0xab0]
100020618: 0f00848b    	movi.4h	v11, #0x4
10002061c: 3d81efe1    	str	q1, [sp, #0x7b0]
100020620: 4f0084e1    	movi.8h	v1, #0x7
100020624: 6ef8f824    	fneg.8h	v4, v1
100020628: 3d81f7e0    	str	q0, [sp, #0x7d0]
10002062c: 4f0085e0    	movi.8h	v0, #0xf
100020630: 6ef8f805    	fneg.8h	v5, v0
100020634: 3dc2bbe0    	ldr	q0, [sp, #0xae0]
100020638: 4f0086e1    	movi.8h	v1, #0x17
10002063c: 6ef8f821    	fneg.8h	v1, v1
100020640: 3d81ffe0    	str	q0, [sp, #0x7f0]
100020644: 52800508    	mov	w8, #0x28               ; =40
100020648: 72a00028    	movk	w8, #0x1, lsl #16
10002064c: f9015be8    	str	x8, [sp, #0x2b0]
100020650: 52900017    	mov	w23, #0x8000            ; =32768
100020654: f9414bfb    	ldr	x27, [sp, #0x290]
100020658: ad0f8be3    	stp	q3, q2, [sp, #0x1f0]
10002065c: ad0893e5    	stp	q5, q4, [sp, #0x110]
100020660: 3d8043e1    	str	q1, [sp, #0x100]
100020664: eb1a0168    	subs	x8, x11, x26
100020668: 540504a3    	b.lo	0x10002a6fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc464>
10002066c: aa1a03f3    	mov	x19, x26
100020670: f90187eb    	str	x11, [sp, #0x308]
100020674: 5294ed09    	mov	w9, #0xa768             ; =42856
100020678: 72a00089    	movk	w9, #0x4, lsl #16
10002067c: eb09011f    	cmp	x8, x9
100020680: aa1503f4    	mov	x20, x21
100020684: 5280003c    	mov	w28, #0x1               ; =1
100020688: 540000c3    	b.lo	0x1000206a0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2408>
10002068c: 52927c08    	mov	w8, #0x93e0             ; =37856
100020690: 72a00088    	movk	w8, #0x4, lsl #16
100020694: ab080268    	adds	x8, x19, x8
100020698: f90187e8    	str	x8, [sp, #0x308]
10002069c: 54050262    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000206a0: f9014fee    	str	x14, [sp, #0x298]
1000206a4: f90153ed    	str	x13, [sp, #0x2a0]
1000206a8: f90183ec    	str	x12, [sp, #0x300]
1000206ac: aa0a03fa    	mov	x26, x10
1000206b0: 52800b00    	mov	w0, #0x58               ; =88
1000206b4: 52800101    	mov	w1, #0x8                ; =8
1000206b8: 97ff8872    	bl	0x100002880 <_roc_alloc>
1000206bc: aa0003e8    	mov	x8, x0
1000206c0: b8008d1f    	str	wzr, [x8, #0x8]!
1000206c4: f900001c    	str	x28, [x0]
1000206c8: f900f7e8    	str	x8, [sp, #0x1e8]
1000206cc: f9400108    	ldr	x8, [x8]
1000206d0: f800c008    	stur	x8, [x0, #0xc]
1000206d4: f9000808    	str	x8, [x0, #0x10]
1000206d8: f840c008    	ldur	x8, [x0, #0xc]
1000206dc: f8014008    	stur	x8, [x0, #0x14]
1000206e0: 4e080d00    	dup.2d	v0, x8
1000206e4: 3c82c000    	stur	q0, [x0, #0x2c]
1000206e8: f900d7e0    	str	x0, [sp, #0x1a8]
1000206ec: 3c81c000    	stur	q0, [x0, #0x1c]
1000206f0: 52810b80    	mov	w0, #0x85c              ; =2140
1000206f4: 52800101    	mov	w1, #0x8                ; =8
1000206f8: 97ff8862    	bl	0x100002880 <_roc_alloc>
1000206fc: aa0003f5    	mov	x21, x0
100020700: b8008ebf    	str	wzr, [x21, #0x8]!
100020704: f900001c    	str	x28, [x0]
100020708: f94002a9    	ldr	x9, [x21]
10002070c: aa0003e8    	mov	x8, x0
100020710: f800cd09    	str	x9, [x8, #0xc]!
100020714: f9010fe0    	str	x0, [sp, #0x218]
100020718: f9000809    	str	x9, [x0, #0x10]
10002071c: 92800269    	mov	x9, #-0x14              ; =-20
100020720: f940010a    	ldr	x10, [x8]
100020724: f8028d0a    	str	x10, [x8, #0x28]!
100020728: a93e290a    	stp	x10, x10, [x8, #-0x20]
10002072c: a93f290a    	stp	x10, x10, [x8, #-0x10]
100020730: 9100a129    	add	x9, x9, #0x28
100020734: f120313f    	cmp	x9, #0x80c
100020738: 54ffff43    	b.lo	0x100020720 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2488>
10002073c: 52808d00    	mov	w0, #0x468              ; =1128
100020740: 52800101    	mov	w1, #0x8                ; =8
100020744: 97ff884f    	bl	0x100002880 <_roc_alloc>
100020748: aa0003e9    	mov	x9, x0
10002074c: b8008d3f    	str	wzr, [x9, #0x8]!
100020750: f900001c    	str	x28, [x0]
100020754: 91047008    	add	x8, x0, #0x11c
100020758: f9012be9    	str	x9, [sp, #0x250]
10002075c: f9400129    	ldr	x9, [x9]
100020760: f800c009    	stur	x9, [x0, #0xc]
100020764: f9000809    	str	x9, [x0, #0x10]
100020768: f840c009    	ldur	x9, [x0, #0xc]
10002076c: f8014009    	stur	x9, [x0, #0x14]
100020770: 4e080d20    	dup.2d	v0, x9
100020774: 3c82c000    	stur	q0, [x0, #0x2c]
100020778: 3c81c000    	stur	q0, [x0, #0x1c]
10002077c: 3c84c000    	stur	q0, [x0, #0x4c]
100020780: 3c83c000    	stur	q0, [x0, #0x3c]
100020784: 3c86c000    	stur	q0, [x0, #0x6c]
100020788: 3c85c000    	stur	q0, [x0, #0x5c]
10002078c: 3c88c000    	stur	q0, [x0, #0x8c]
100020790: 3c87c000    	stur	q0, [x0, #0x7c]
100020794: 3c8ac000    	stur	q0, [x0, #0xac]
100020798: 3c89c000    	stur	q0, [x0, #0x9c]
10002079c: 3c8cc000    	stur	q0, [x0, #0xcc]
1000207a0: 3c8bc000    	stur	q0, [x0, #0xbc]
1000207a4: 3c8ec000    	stur	q0, [x0, #0xec]
1000207a8: 3c8dc000    	stur	q0, [x0, #0xdc]
1000207ac: 3c8fcc00    	str	q0, [x0, #0xfc]!
1000207b0: 3d800400    	str	q0, [x0, #0x10]
1000207b4: ad000100    	stp	q0, q0, [x8]
1000207b8: ad010100    	stp	q0, q0, [x8, #0x20]
1000207bc: ad020100    	stp	q0, q0, [x8, #0x40]
1000207c0: ad030100    	stp	q0, q0, [x8, #0x60]
1000207c4: ad040100    	stp	q0, q0, [x8, #0x80]
1000207c8: ad050100    	stp	q0, q0, [x8, #0xa0]
1000207cc: ad060100    	stp	q0, q0, [x8, #0xc0]
1000207d0: ad070100    	stp	q0, q0, [x8, #0xe0]
1000207d4: ad080100    	stp	q0, q0, [x8, #0x100]
1000207d8: ad090100    	stp	q0, q0, [x8, #0x120]
1000207dc: ad0a0100    	stp	q0, q0, [x8, #0x140]
1000207e0: ad0b0100    	stp	q0, q0, [x8, #0x160]
1000207e4: ad0c0100    	stp	q0, q0, [x8, #0x180]
1000207e8: ad0d0100    	stp	q0, q0, [x8, #0x1a0]
1000207ec: ad0e0100    	stp	q0, q0, [x8, #0x1c0]
1000207f0: ad0f0100    	stp	q0, q0, [x8, #0x1e0]
1000207f4: ad100100    	stp	q0, q0, [x8, #0x200]
1000207f8: ad110100    	stp	q0, q0, [x8, #0x220]
1000207fc: ad120100    	stp	q0, q0, [x8, #0x240]
100020800: ad130100    	stp	q0, q0, [x8, #0x260]
100020804: ad140100    	stp	q0, q0, [x8, #0x280]
100020808: ad150100    	stp	q0, q0, [x8, #0x2a0]
10002080c: ad160100    	stp	q0, q0, [x8, #0x2c0]
100020810: ad170100    	stp	q0, q0, [x8, #0x2e0]
100020814: ad180100    	stp	q0, q0, [x8, #0x300]
100020818: f9019109    	str	x9, [x8, #0x320]
10002081c: f9019509    	str	x9, [x8, #0x328]
100020820: 37000254    	tbnz	w20, #0x0, 0x100020868 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x25d0>
100020824: aa1803f1    	mov	x17, x24
100020828: aa1a03e1    	mov	x1, x26
10002082c: f94183e4    	ldr	x4, [sp, #0x300]
100020830: f941b3ea    	ldr	x10, [sp, #0x360]
100020834: f94153fe    	ldr	x30, [sp, #0x2a0]
100020838: f9414fe5    	ldr	x5, [sp, #0x298]
10002083c: f9418fec    	ldr	x12, [sp, #0x318]
100020840: b4000494    	cbz	x20, 0x1000208d0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2638>
100020844: d341fe88    	lsr	x8, x20, #1
100020848: f94133e9    	ldr	x9, [sp, #0x260]
10002084c: f85f8129    	ldur	x9, [x9, #-0x8]
100020850: f100053f    	cmp	x9, #0x1
100020854: 9a9f0108    	csel	x8, x8, xzr, eq
100020858: f90123e8    	str	x8, [sp, #0x240]
10002085c: f140203f    	cmp	x1, #0x8, lsl #12       ; =0x8000
100020860: 540003e2    	b.hs	0x1000208dc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2644>
100020864: 140035ef    	b	0x10002e020 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xfd88>
100020868: f27ffa80    	ands	x0, x20, #0xfffffffffffffffe
10002086c: aa1803f1    	mov	x17, x24
100020870: aa1a03e1    	mov	x1, x26
100020874: f94183e4    	ldr	x4, [sp, #0x300]
100020878: f941b3ea    	ldr	x10, [sp, #0x360]
10002087c: f94153fe    	ldr	x30, [sp, #0x2a0]
100020880: f9414fe5    	ldr	x5, [sp, #0x298]
100020884: f9418fec    	ldr	x12, [sp, #0x318]
100020888: 54000200    	b.eq	0x1000208c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2630>
10002088c: f85f8c08    	ldr	x8, [x0, #-0x8]!
100020890: b40001c8    	cbz	x8, 0x1000208c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2630>
100020894: 92800008    	mov	x8, #-0x1               ; =-1
100020898: f8280008    	ldadd	x8, x8, [x0]
10002089c: f100051f    	cmp	x8, #0x1
1000208a0: 54000141    	b.ne	0x1000208c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2630>
1000208a4: 52800101    	mov	w1, #0x8                ; =8
1000208a8: 97ff8812    	bl	0x1000028f0 <_roc_dealloc>
1000208ac: f9418fec    	ldr	x12, [sp, #0x318]
1000208b0: f9414fe5    	ldr	x5, [sp, #0x298]
1000208b4: f94153fe    	ldr	x30, [sp, #0x2a0]
1000208b8: f941b3ea    	ldr	x10, [sp, #0x360]
1000208bc: f94183e4    	ldr	x4, [sp, #0x300]
1000208c0: aa1a03e1    	mov	x1, x26
1000208c4: aa1803f1    	mov	x17, x24
1000208c8: f90133ff    	str	xzr, [sp, #0x260]
1000208cc: d2800014    	mov	x20, #0x0               ; =0
1000208d0: f90123ff    	str	xzr, [sp, #0x240]
1000208d4: f140203f    	cmp	x1, #0x8, lsl #12       ; =0x8000
1000208d8: 5406ba43    	b.lo	0x10002e020 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xfd88>
1000208dc: f140423f    	cmp	x17, #0x10, lsl #12     ; =0x10000
1000208e0: 5406ba03    	b.lo	0x10002e020 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xfd88>
1000208e4: d34ffee8    	lsr	x8, x23, #15
1000208e8: b406b9c8    	cbz	x8, 0x10002e020 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xfd88>
1000208ec: f9019bf3    	str	x19, [sp, #0x330]
1000208f0: f94187e8    	ldr	x8, [sp, #0x308]
1000208f4: eb130113    	subs	x19, x8, x19
1000208f8: 5404f023    	b.lo	0x10002a6fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc464>
1000208fc: f108027f    	cmp	x19, #0x200
100020900: 54000142    	b.hs	0x100020928 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2690>
100020904: 52800063    	mov	w3, #0x3                ; =3
100020908: f9419fe7    	ldr	x7, [sp, #0x338]
10002090c: f941a3fc    	ldr	x28, [sp, #0x340]
100020910: f9418bf8    	ldr	x24, [sp, #0x310]
100020914: f9419bfa    	ldr	x26, [sp, #0x330]
100020918: f9014bfb    	str	x27, [sp, #0x290]
10002091c: f900e3f4    	str	x20, [sp, #0x1c0]
100020920: b5000d94    	cbnz	x20, 0x100020ad0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2838>
100020924: 1400006f    	b	0x100020ae0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2848>
100020928: 52802600    	mov	w0, #0x130              ; =304
10002092c: 52800101    	mov	w1, #0x8                ; =8
100020930: 97ff87d4    	bl	0x100002880 <_roc_alloc>
100020934: d2800008    	mov	x8, #0x0                ; =0
100020938: f900001c    	str	x28, [x0]
10002093c: 6f00e400    	movi.2d	v0, #0000000000000000
100020940: 3c818000    	stur	q0, [x0, #0x18]
100020944: 3c828000    	stur	q0, [x0, #0x28]
100020948: 3c838000    	stur	q0, [x0, #0x38]
10002094c: 3c848000    	stur	q0, [x0, #0x48]
100020950: 3c858000    	stur	q0, [x0, #0x58]
100020954: 3c868000    	stur	q0, [x0, #0x68]
100020958: 3c878000    	stur	q0, [x0, #0x78]
10002095c: 3c888000    	stur	q0, [x0, #0x88]
100020960: 3c898000    	stur	q0, [x0, #0x98]
100020964: 3c8a8000    	stur	q0, [x0, #0xa8]
100020968: 3c8b8000    	stur	q0, [x0, #0xb8]
10002096c: 3c8c8000    	stur	q0, [x0, #0xc8]
100020970: 3c8d8000    	stur	q0, [x0, #0xd8]
100020974: 3c8e8000    	stur	q0, [x0, #0xe8]
100020978: 3c8f8000    	stur	q0, [x0, #0xf8]
10002097c: 3904201f    	strb	wzr, [x0, #0x108]
100020980: f140067f    	cmp	x19, #0x1, lsl #12      ; =0x1000
100020984: 52820009    	mov	w9, #0x1000             ; =4096
100020988: 9a893269    	csel	x9, x19, x9, lo
10002098c: 3c808c00    	str	q0, [x0, #0x8]!
100020990: f9419feb    	ldr	x11, [sp, #0x338]
100020994: f941a3ec    	ldr	x12, [sp, #0x340]
100020998: f9419bed    	ldr	x13, [sp, #0x330]
10002099c: ab0801aa    	adds	x10, x13, x8
1000209a0: 5404ea42    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000209a4: eb0c015f    	cmp	x10, x12
1000209a8: 540000e2    	b.hs	0x1000209c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x272c>
1000209ac: 386a696a    	ldrb	w10, [x11, x10]
1000209b0: 382a681c    	strb	w28, [x0, x10]
1000209b4: 91000508    	add	x8, x8, #0x1
1000209b8: eb08013f    	cmp	x9, x8
1000209bc: 54ffff01    	b.ne	0x10002099c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2704>
1000209c0: 14000006    	b	0x1000209d8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2740>
1000209c4: d280000a    	mov	x10, #0x0               ; =0
1000209c8: 382a681c    	strb	w28, [x0, x10]
1000209cc: 91000508    	add	x8, x8, #0x1
1000209d0: eb08013f    	cmp	x9, x8
1000209d4: 54fffe41    	b.ne	0x10002099c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2704>
1000209d8: d2800008    	mov	x8, #0x0                ; =0
1000209dc: d2800013    	mov	x19, #0x0               ; =0
1000209e0: 38686809    	ldrb	w9, [x0, x8]
1000209e4: ab090273    	adds	x19, x19, x9
1000209e8: 5404e802    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000209ec: 91000508    	add	x8, x8, #0x1
1000209f0: f104011f    	cmp	x8, #0x100
1000209f4: 54ffff61    	b.ne	0x1000209e0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2748>
1000209f8: f904d3e0    	str	x0, [sp, #0x9a0]
1000209fc: 912683e8    	add	x8, sp, #0x9a0
100020a00: 3dc057e0    	ldr	q0, [sp, #0x150]
100020a04: 3c808100    	stur	q0, [x8, #0x8]
100020a08: 912683e0    	add	x0, sp, #0x9a0
100020a0c: 94003ded    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100020a10: f1013e7f    	cmp	x19, #0x4f
100020a14: 54000229    	b.ls	0x100020a58 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x27c0>
100020a18: 52800063    	mov	w3, #0x3                ; =3
100020a1c: f9419fe7    	ldr	x7, [sp, #0x338]
100020a20: f941a3fc    	ldr	x28, [sp, #0x340]
100020a24: aa1803f1    	mov	x17, x24
100020a28: aa1a03e1    	mov	x1, x26
100020a2c: f9418bf8    	ldr	x24, [sp, #0x310]
100020a30: f94183e4    	ldr	x4, [sp, #0x300]
100020a34: f941b3ea    	ldr	x10, [sp, #0x360]
100020a38: f94153fe    	ldr	x30, [sp, #0x2a0]
100020a3c: f9414fe5    	ldr	x5, [sp, #0x298]
100020a40: f9418fec    	ldr	x12, [sp, #0x318]
100020a44: f9419bfa    	ldr	x26, [sp, #0x330]
100020a48: f9014bfb    	str	x27, [sp, #0x290]
100020a4c: f900e3f4    	str	x20, [sp, #0x1c0]
100020a50: b5000414    	cbnz	x20, 0x100020ad0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2838>
100020a54: 14000023    	b	0x100020ae0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2848>
100020a58: 100cc5c8    	adr	x8, 0x10003a310 <_roc__d61_1>
100020a5c: d503201f    	nop
100020a60: 8b130108    	add	x8, x8, x19
100020a64: 39402103    	ldrb	w3, [x8, #0x8]
100020a68: f94113e8    	ldr	x8, [sp, #0x220]
100020a6c: aa1803f1    	mov	x17, x24
100020a70: aa1a03e1    	mov	x1, x26
100020a74: f94183e4    	ldr	x4, [sp, #0x300]
100020a78: f941b3ea    	ldr	x10, [sp, #0x360]
100020a7c: f94153fe    	ldr	x30, [sp, #0x2a0]
100020a80: f9414fe5    	ldr	x5, [sp, #0x298]
100020a84: f9418fec    	ldr	x12, [sp, #0x318]
100020a88: 34fff408    	cbz	w8, 0x100020908 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2670>
100020a8c: f940a7e8    	ldr	x8, [sp, #0x148]
100020a90: 12001d08    	and	w8, w8, #0xff
100020a94: 7100091f    	cmp	w8, #0x2
100020a98: f9419fe7    	ldr	x7, [sp, #0x338]
100020a9c: f941a3fc    	ldr	x28, [sp, #0x340]
100020aa0: f9418bf8    	ldr	x24, [sp, #0x310]
100020aa4: f9419bfa    	ldr	x26, [sp, #0x330]
100020aa8: 54000088    	b.hi	0x100020ab8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2820>
100020aac: f100147f    	cmp	x3, #0x5
100020ab0: 528000a8    	mov	w8, #0x5                ; =5
100020ab4: 14000003    	b	0x100020ac0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2828>
100020ab8: f1001c7f    	cmp	x3, #0x7
100020abc: 528000e8    	mov	w8, #0x7                ; =7
100020ac0: 9a883063    	csel	x3, x3, x8, lo
100020ac4: f9014bfb    	str	x27, [sp, #0x290]
100020ac8: f900e3f4    	str	x20, [sp, #0x1c0]
100020acc: b40000b4    	cbz	x20, 0x100020ae0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2848>
100020ad0: f94133e8    	ldr	x8, [sp, #0x260]
100020ad4: f85f8108    	ldur	x8, [x8, #-0x8]
100020ad8: f100051f    	cmp	x8, #0x1
100020adc: 54000081    	b.ne	0x100020aec <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2854>
100020ae0: d341fe88    	lsr	x8, x20, #1
100020ae4: f900b3e8    	str	x8, [sp, #0x160]
100020ae8: 14000002    	b	0x100020af0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2858>
100020aec: f900b3ff    	str	xzr, [sp, #0x160]
100020af0: f900f3ff    	str	xzr, [sp, #0x1e0]
100020af4: 5280001b    	mov	w27, #0x0               ; =0
100020af8: f90173ff    	str	xzr, [sp, #0x2e0]
100020afc: d1000468    	sub	x8, x3, #0x1
100020b00: f901afe8    	str	x8, [sp, #0x358]
100020b04: f90197f5    	str	x21, [sp, #0x328]
100020b08: f901abe3    	str	x3, [sp, #0x350]
100020b0c: d2800019    	mov	x25, #0x0               ; =0
100020b10: cb1a0388    	sub	x8, x28, x26
100020b14: f941a7eb    	ldr	x11, [sp, #0x348]
100020b18: eb08017f    	cmp	x11, x8
100020b1c: 9a883169    	csel	x9, x11, x8, lo
100020b20: f104091f    	cmp	x8, #0x102
100020b24: 9a8a310a    	csel	x10, x8, x10, lo
100020b28: 9a8b312b    	csel	x11, x9, x11, lo
100020b2c: f901a7eb    	str	x11, [sp, #0x348]
100020b30: cb040348    	sub	x8, x26, x4
100020b34: f140211f    	cmp	x8, #0x8, lsl #12       ; =0x8000
100020b38: f901b3ea    	str	x10, [sp, #0x360]
100020b3c: 54002e81    	b.ne	0x10002110c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2e74>
100020b40: f94163e8    	ldr	x8, [sp, #0x2c0]
100020b44: f9018bf8    	str	x24, [sp, #0x310]
100020b48: f90183e4    	str	x4, [sp, #0x300]
100020b4c: f90153fe    	str	x30, [sp, #0x2a0]
100020b50: f9014fe5    	str	x5, [sp, #0x298]
100020b54: 37000168    	tbnz	w8, #0x0, 0x100020b80 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x28e8>
100020b58: f94163e8    	ldr	x8, [sp, #0x2c0]
100020b5c: b4000088    	cbz	x8, 0x100020b6c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x28d4>
100020b60: f85f8188    	ldur	x8, [x12, #-0x8]
100020b64: f100051f    	cmp	x8, #0x1
100020b68: 540000c1    	b.ne	0x100020b80 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x28e8>
100020b6c: b4000d61    	cbz	x1, 0x100020d18 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2a80>
100020b70: f100103f    	cmp	x1, #0x4
100020b74: 540005c2    	b.hs	0x100020c2c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2994>
100020b78: d2800008    	mov	x8, #0x0                ; =0
100020b7c: 14000060    	b	0x100020cfc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2a64>
100020b80: aa0c03f5    	mov	x21, x12
100020b84: aa1103f8    	mov	x24, x17
100020b88: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100020b8c: 91372000    	add	x0, x0, #0xdc8
100020b90: 52800042    	mov	w2, #0x2                ; =2
100020b94: aa0103f4    	mov	x20, x1
100020b98: 94004394    	bl	0x1000319e8 <_dev_wrappers.roc_builtins_list_with_capacity>
100020b9c: aa1403ec    	mov	x12, x20
100020ba0: f94ee7f3    	ldr	x19, [sp, #0x1dc8]
100020ba4: f94eebf4    	ldr	x20, [sp, #0x1dd0]
100020ba8: f94eeffc    	ldr	x28, [sp, #0x1dd8]
100020bac: b400024c    	cbz	x12, 0x100020bf4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x295c>
100020bb0: f100819f    	cmp	x12, #0x20
100020bb4: 540000c3    	b.lo	0x100020bcc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2934>
100020bb8: d37ffa88    	lsl	x8, x20, #1
100020bbc: 8b080269    	add	x9, x19, x8
100020bc0: cb150128    	sub	x8, x9, x21
100020bc4: f101011f    	cmp	x8, #0x40
100020bc8: 540003c2    	b.hs	0x100020c40 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x29a8>
100020bcc: d2800008    	mov	x8, #0x0                ; =0
100020bd0: cb080189    	sub	x9, x12, x8
100020bd4: 8b0806a8    	add	x8, x21, x8, lsl #1
100020bd8: 78c0250a    	ldrsh	w10, [x8], #0x2
100020bdc: 5211014b    	eor	w11, w10, #0x8000
100020be0: 0a4a3d6a    	and	w10, w11, w10, lsr #15
100020be4: 78347a6a    	strh	w10, [x19, x20, lsl #1]
100020be8: 91000694    	add	x20, x20, #0x1
100020bec: f1000529    	subs	x9, x9, #0x1
100020bf0: 54ffff41    	b.ne	0x100020bd8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2940>
100020bf4: f904d3f5    	str	x21, [sp, #0x9a0]
100020bf8: f904d7ec    	str	x12, [sp, #0x9a8]
100020bfc: f94163e8    	ldr	x8, [sp, #0x2c0]
100020c00: f904dbe8    	str	x8, [sp, #0x9b0]
100020c04: 912683e0    	add	x0, sp, #0x9a0
100020c08: 94003d6e    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100020c0c: f90163fc    	str	x28, [sp, #0x2c0]
100020c10: aa1803f1    	mov	x17, x24
100020c14: f9418bf8    	ldr	x24, [sp, #0x310]
100020c18: f94197f5    	ldr	x21, [sp, #0x328]
100020c1c: f9415fe8    	ldr	x8, [sp, #0x2b8]
100020c20: f9016bf4    	str	x20, [sp, #0x2d0]
100020c24: 37000968    	tbnz	w8, #0x0, 0x100020d50 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2ab8>
100020c28: 14000040    	b	0x100020d28 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2a90>
100020c2c: f100803f    	cmp	x1, #0x20
100020c30: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100020c34: 540002c2    	b.hs	0x100020c8c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x29f4>
100020c38: d2800008    	mov	x8, #0x0                ; =0
100020c3c: 14000025    	b	0x100020cd0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2a38>
100020c40: 927be988    	and	x8, x12, #0xffffffffffffffe0
100020c44: 8b080294    	add	x20, x20, x8
100020c48: 91008129    	add	x9, x9, #0x20
100020c4c: 910082aa    	add	x10, x21, #0x20
100020c50: 927be98b    	and	x11, x12, #0xffffffffffffffe0
100020c54: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100020c58: ad7f0540    	ldp	q0, q1, [x10, #-0x20]
100020c5c: acc20d42    	ldp	q2, q3, [x10], #0x40
100020c60: 6e642c00    	uqsub.8h	v0, v0, v4
100020c64: 6e642c21    	uqsub.8h	v1, v1, v4
100020c68: 6e642c42    	uqsub.8h	v2, v2, v4
100020c6c: 6e642c63    	uqsub.8h	v3, v3, v4
100020c70: ad3f0520    	stp	q0, q1, [x9, #-0x20]
100020c74: ac820d22    	stp	q2, q3, [x9], #0x40
100020c78: f100816b    	subs	x11, x11, #0x20
100020c7c: 54fffee1    	b.ne	0x100020c58 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x29c0>
100020c80: eb08019f    	cmp	x12, x8
100020c84: 54fffb80    	b.eq	0x100020bf4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x295c>
100020c88: 17ffffd2    	b	0x100020bd0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2938>
100020c8c: 927e0829    	and	x9, x1, #0x1c
100020c90: 927be828    	and	x8, x1, #0xffffffffffffffe0
100020c94: 9100818a    	add	x10, x12, #0x20
100020c98: 927be82b    	and	x11, x1, #0xffffffffffffffe0
100020c9c: ad7f0540    	ldp	q0, q1, [x10, #-0x20]
100020ca0: ad400d42    	ldp	q2, q3, [x10]
100020ca4: 6e642c00    	uqsub.8h	v0, v0, v4
100020ca8: 6e642c21    	uqsub.8h	v1, v1, v4
100020cac: 6e642c42    	uqsub.8h	v2, v2, v4
100020cb0: 6e642c63    	uqsub.8h	v3, v3, v4
100020cb4: ad3f0540    	stp	q0, q1, [x10, #-0x20]
100020cb8: ac820d42    	stp	q2, q3, [x10], #0x40
100020cbc: f100816b    	subs	x11, x11, #0x20
100020cc0: 54fffee1    	b.ne	0x100020c9c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2a04>
100020cc4: eb08003f    	cmp	x1, x8
100020cc8: 54000280    	b.eq	0x100020d18 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2a80>
100020ccc: b4000189    	cbz	x9, 0x100020cfc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2a64>
100020cd0: aa0803ea    	mov	x10, x8
100020cd4: 927ef428    	and	x8, x1, #0xfffffffffffffffc
100020cd8: cb080149    	sub	x9, x10, x8
100020cdc: 8b0a058a    	add	x10, x12, x10, lsl #1
100020ce0: fd400140    	ldr	d0, [x10]
100020ce4: 2e682c00    	uqsub.4h	v0, v0, v8
100020ce8: fc008540    	str	d0, [x10], #0x8
100020cec: b1001129    	adds	x9, x9, #0x4
100020cf0: 54ffff81    	b.ne	0x100020ce0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2a48>
100020cf4: eb08003f    	cmp	x1, x8
100020cf8: 54000100    	b.eq	0x100020d18 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2a80>
100020cfc: 78e87989    	ldrsh	w9, [x12, x8, lsl #1]
100020d00: 5211012a    	eor	w10, w9, #0x8000
100020d04: 0a493d49    	and	w9, w10, w9, lsr #15
100020d08: 78287989    	strh	w9, [x12, x8, lsl #1]
100020d0c: 91000508    	add	x8, x8, #0x1
100020d10: eb08003f    	cmp	x1, x8
100020d14: 54ffff41    	b.ne	0x100020cfc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2a64>
100020d18: aa0c03f3    	mov	x19, x12
100020d1c: f9415fe8    	ldr	x8, [sp, #0x2b8]
100020d20: f9016be1    	str	x1, [sp, #0x2d0]
100020d24: 37000168    	tbnz	w8, #0x0, 0x100020d50 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2ab8>
100020d28: f9415fe8    	ldr	x8, [sp, #0x2b8]
100020d2c: b4000088    	cbz	x8, 0x100020d3c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2aa4>
100020d30: f85f8308    	ldur	x8, [x24, #-0x8]
100020d34: f100051f    	cmp	x8, #0x1
100020d38: 540000c1    	b.ne	0x100020d50 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2ab8>
100020d3c: b4000cf1    	cbz	x17, 0x100020ed8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2c40>
100020d40: f100123f    	cmp	x17, #0x4
100020d44: 54000562    	b.hs	0x100020df0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2b58>
100020d48: d2800008    	mov	x8, #0x0                ; =0
100020d4c: 1400005d    	b	0x100020ec0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2c28>
100020d50: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100020d54: 91372000    	add	x0, x0, #0xdc8
100020d58: aa1103e1    	mov	x1, x17
100020d5c: 52800042    	mov	w2, #0x2                ; =2
100020d60: aa1103f4    	mov	x20, x17
100020d64: 94004321    	bl	0x1000319e8 <_dev_wrappers.roc_builtins_list_with_capacity>
100020d68: aa1403ec    	mov	x12, x20
100020d6c: f94ee7f8    	ldr	x24, [sp, #0x1dc8]
100020d70: f94eebf4    	ldr	x20, [sp, #0x1dd0]
100020d74: f94eeffc    	ldr	x28, [sp, #0x1dd8]
100020d78: b400028c    	cbz	x12, 0x100020dc8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2b30>
100020d7c: f100819f    	cmp	x12, #0x20
100020d80: 540000e3    	b.lo	0x100020d9c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2b04>
100020d84: d37ffa88    	lsl	x8, x20, #1
100020d88: 8b080309    	add	x9, x24, x8
100020d8c: f9418bea    	ldr	x10, [sp, #0x310]
100020d90: cb0a0128    	sub	x8, x9, x10
100020d94: f101011f    	cmp	x8, #0x40
100020d98: 54000362    	b.hs	0x100020e04 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2b6c>
100020d9c: d2800008    	mov	x8, #0x0                ; =0
100020da0: cb080189    	sub	x9, x12, x8
100020da4: f9418bea    	ldr	x10, [sp, #0x310]
100020da8: 8b080548    	add	x8, x10, x8, lsl #1
100020dac: 78c0250a    	ldrsh	w10, [x8], #0x2
100020db0: 5211014b    	eor	w11, w10, #0x8000
100020db4: 0a4a3d6a    	and	w10, w11, w10, lsr #15
100020db8: 78347b0a    	strh	w10, [x24, x20, lsl #1]
100020dbc: 91000694    	add	x20, x20, #0x1
100020dc0: f1000529    	subs	x9, x9, #0x1
100020dc4: 54ffff41    	b.ne	0x100020dac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2b14>
100020dc8: f9418be8    	ldr	x8, [sp, #0x310]
100020dcc: f904d3e8    	str	x8, [sp, #0x9a0]
100020dd0: f904d7ec    	str	x12, [sp, #0x9a8]
100020dd4: f9415fe8    	ldr	x8, [sp, #0x2b8]
100020dd8: f904dbe8    	str	x8, [sp, #0x9b0]
100020ddc: 912683e0    	add	x0, sp, #0x9a0
100020de0: 94003cf8    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100020de4: aa1403f1    	mov	x17, x20
100020de8: f9015ffc    	str	x28, [sp, #0x2b8]
100020dec: 1400003b    	b	0x100020ed8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2c40>
100020df0: f100823f    	cmp	x17, #0x20
100020df4: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100020df8: 540002c2    	b.hs	0x100020e50 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2bb8>
100020dfc: d2800008    	mov	x8, #0x0                ; =0
100020e00: 14000025    	b	0x100020e94 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2bfc>
100020e04: 927be988    	and	x8, x12, #0xffffffffffffffe0
100020e08: 8b080294    	add	x20, x20, x8
100020e0c: 91008129    	add	x9, x9, #0x20
100020e10: 9100814a    	add	x10, x10, #0x20
100020e14: 927be98b    	and	x11, x12, #0xffffffffffffffe0
100020e18: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100020e1c: ad7f0540    	ldp	q0, q1, [x10, #-0x20]
100020e20: acc20d42    	ldp	q2, q3, [x10], #0x40
100020e24: 6e642c00    	uqsub.8h	v0, v0, v4
100020e28: 6e642c21    	uqsub.8h	v1, v1, v4
100020e2c: 6e642c42    	uqsub.8h	v2, v2, v4
100020e30: 6e642c63    	uqsub.8h	v3, v3, v4
100020e34: ad3f0520    	stp	q0, q1, [x9, #-0x20]
100020e38: ac820d22    	stp	q2, q3, [x9], #0x40
100020e3c: f100816b    	subs	x11, x11, #0x20
100020e40: 54fffee1    	b.ne	0x100020e1c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2b84>
100020e44: eb08019f    	cmp	x12, x8
100020e48: 54fffc00    	b.eq	0x100020dc8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2b30>
100020e4c: 17ffffd5    	b	0x100020da0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2b08>
100020e50: 927e0a29    	and	x9, x17, #0x1c
100020e54: 927bea28    	and	x8, x17, #0xffffffffffffffe0
100020e58: 9100830a    	add	x10, x24, #0x20
100020e5c: 927bea2b    	and	x11, x17, #0xffffffffffffffe0
100020e60: ad7f0540    	ldp	q0, q1, [x10, #-0x20]
100020e64: ad400d42    	ldp	q2, q3, [x10]
100020e68: 6e642c00    	uqsub.8h	v0, v0, v4
100020e6c: 6e642c21    	uqsub.8h	v1, v1, v4
100020e70: 6e642c42    	uqsub.8h	v2, v2, v4
100020e74: 6e642c63    	uqsub.8h	v3, v3, v4
100020e78: ad3f0540    	stp	q0, q1, [x10, #-0x20]
100020e7c: ac820d42    	stp	q2, q3, [x10], #0x40
100020e80: f100816b    	subs	x11, x11, #0x20
100020e84: 54fffee1    	b.ne	0x100020e60 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2bc8>
100020e88: eb08023f    	cmp	x17, x8
100020e8c: 54000260    	b.eq	0x100020ed8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2c40>
100020e90: b4000189    	cbz	x9, 0x100020ec0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2c28>
100020e94: aa0803ea    	mov	x10, x8
100020e98: 927ef628    	and	x8, x17, #0xfffffffffffffffc
100020e9c: cb080149    	sub	x9, x10, x8
100020ea0: 8b0a070a    	add	x10, x24, x10, lsl #1
100020ea4: fd400140    	ldr	d0, [x10]
100020ea8: 2e682c00    	uqsub.4h	v0, v0, v8
100020eac: fc008540    	str	d0, [x10], #0x8
100020eb0: b1001129    	adds	x9, x9, #0x4
100020eb4: 54ffff81    	b.ne	0x100020ea4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2c0c>
100020eb8: eb08023f    	cmp	x17, x8
100020ebc: 540000e0    	b.eq	0x100020ed8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2c40>
100020ec0: 78e87b09    	ldrsh	w9, [x24, x8, lsl #1]
100020ec4: 5211012a    	eor	w10, w9, #0x8000
100020ec8: 0a493d49    	and	w9, w10, w9, lsr #15
100020ecc: 78287b09    	strh	w9, [x24, x8, lsl #1]
100020ed0: 91000508    	add	x8, x8, #0x1
100020ed4: 17fffff9    	b	0x100020eb8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2c20>
100020ed8: f9415be8    	ldr	x8, [sp, #0x2b0]
100020edc: 37000248    	tbnz	w8, #0x0, 0x100020f24 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2c8c>
100020ee0: f9415be8    	ldr	x8, [sp, #0x2b0]
100020ee4: b4000088    	cbz	x8, 0x100020ef4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2c5c>
100020ee8: f85f82c8    	ldur	x8, [x22, #-0x8]
100020eec: f100051f    	cmp	x8, #0x1
100020ef0: 540001a1    	b.ne	0x100020f24 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2c8c>
100020ef4: b40007b7    	cbz	x23, 0x100020fe8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2d50>
100020ef8: f10012ff    	cmp	x23, #0x4
100020efc: f9419fe7    	ldr	x7, [sp, #0x338]
100020f00: f941a3fc    	ldr	x28, [sp, #0x340]
100020f04: f9416be1    	ldr	x1, [sp, #0x2d0]
100020f08: f94183e4    	ldr	x4, [sp, #0x300]
100020f0c: f94153fe    	ldr	x30, [sp, #0x2a0]
100020f10: f9414fe5    	ldr	x5, [sp, #0x298]
100020f14: f941abe3    	ldr	x3, [sp, #0x350]
100020f18: 54000702    	b.hs	0x100020ff8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2d60>
100020f1c: d2800008    	mov	x8, #0x0                ; =0
100020f20: 14000069    	b	0x1000210c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2e2c>
100020f24: f9018ff1    	str	x17, [sp, #0x318]
100020f28: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100020f2c: 91372000    	add	x0, x0, #0xdc8
100020f30: aa1703e1    	mov	x1, x23
100020f34: 52800042    	mov	w2, #0x2                ; =2
100020f38: 940042ac    	bl	0x1000319e8 <_dev_wrappers.roc_builtins_list_with_capacity>
100020f3c: f94ee7f4    	ldr	x20, [sp, #0x1dc8]
100020f40: f94eebfc    	ldr	x28, [sp, #0x1dd0]
100020f44: f94eefec    	ldr	x12, [sp, #0x1dd8]
100020f48: f9018bec    	str	x12, [sp, #0x310]
100020f4c: b4000257    	cbz	x23, 0x100020f94 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2cfc>
100020f50: f10082ff    	cmp	x23, #0x20
100020f54: 540000c3    	b.lo	0x100020f6c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2cd4>
100020f58: d37ffb88    	lsl	x8, x28, #1
100020f5c: 8b080289    	add	x9, x20, x8
100020f60: cb160128    	sub	x8, x9, x22
100020f64: f101011f    	cmp	x8, #0x40
100020f68: 54000522    	b.hs	0x10002100c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2d74>
100020f6c: d2800008    	mov	x8, #0x0                ; =0
100020f70: cb0802e9    	sub	x9, x23, x8
100020f74: 8b0806c8    	add	x8, x22, x8, lsl #1
100020f78: 78c0250a    	ldrsh	w10, [x8], #0x2
100020f7c: 5211014b    	eor	w11, w10, #0x8000
100020f80: 0a4a3d6a    	and	w10, w11, w10, lsr #15
100020f84: 783c7a8a    	strh	w10, [x20, x28, lsl #1]
100020f88: 9100079c    	add	x28, x28, #0x1
100020f8c: f1000529    	subs	x9, x9, #0x1
100020f90: 54ffff41    	b.ne	0x100020f78 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2ce0>
100020f94: f904d3f6    	str	x22, [sp, #0x9a0]
100020f98: f904d7f7    	str	x23, [sp, #0x9a8]
100020f9c: f9415be8    	ldr	x8, [sp, #0x2b0]
100020fa0: f904dbe8    	str	x8, [sp, #0x9b0]
100020fa4: 912683e0    	add	x0, sp, #0x9a0
100020fa8: 94003c86    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100020fac: aa1c03f7    	mov	x23, x28
100020fb0: f9418be8    	ldr	x8, [sp, #0x310]
100020fb4: f9015be8    	str	x8, [sp, #0x2b0]
100020fb8: f9419fe7    	ldr	x7, [sp, #0x338]
100020fbc: f941a3fc    	ldr	x28, [sp, #0x340]
100020fc0: f9418ff1    	ldr	x17, [sp, #0x318]
100020fc4: f9416be1    	ldr	x1, [sp, #0x2d0]
100020fc8: f94183e4    	ldr	x4, [sp, #0x300]
100020fcc: f94153fe    	ldr	x30, [sp, #0x2a0]
100020fd0: f9414fe5    	ldr	x5, [sp, #0x298]
100020fd4: f941abe3    	ldr	x3, [sp, #0x350]
100020fd8: f140203f    	cmp	x1, #0x8, lsl #12       ; =0x8000
100020fdc: f941b3ea    	ldr	x10, [sp, #0x360]
100020fe0: 54000882    	b.hs	0x1000210f0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2e58>
100020fe4: 14002f83    	b	0x10002cdf0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeb58>
100020fe8: aa1603f4    	mov	x20, x22
100020fec: f9419fe7    	ldr	x7, [sp, #0x338]
100020ff0: f941a3fc    	ldr	x28, [sp, #0x340]
100020ff4: 17fffff4    	b	0x100020fc4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2d2c>
100020ff8: f10082ff    	cmp	x23, #0x20
100020ffc: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100021000: 540002c2    	b.hs	0x100021058 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2dc0>
100021004: d2800008    	mov	x8, #0x0                ; =0
100021008: 14000025    	b	0x10002109c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2e04>
10002100c: 927beae8    	and	x8, x23, #0xffffffffffffffe0
100021010: 8b08039c    	add	x28, x28, x8
100021014: 91008129    	add	x9, x9, #0x20
100021018: 910082ca    	add	x10, x22, #0x20
10002101c: 927beaeb    	and	x11, x23, #0xffffffffffffffe0
100021020: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100021024: ad7f0540    	ldp	q0, q1, [x10, #-0x20]
100021028: acc20d42    	ldp	q2, q3, [x10], #0x40
10002102c: 6e642c00    	uqsub.8h	v0, v0, v4
100021030: 6e642c21    	uqsub.8h	v1, v1, v4
100021034: 6e642c42    	uqsub.8h	v2, v2, v4
100021038: 6e642c63    	uqsub.8h	v3, v3, v4
10002103c: ad3f0520    	stp	q0, q1, [x9, #-0x20]
100021040: ac820d22    	stp	q2, q3, [x9], #0x40
100021044: f100816b    	subs	x11, x11, #0x20
100021048: 54fffee1    	b.ne	0x100021024 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2d8c>
10002104c: eb0802ff    	cmp	x23, x8
100021050: 54fffa20    	b.eq	0x100020f94 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2cfc>
100021054: 17ffffc7    	b	0x100020f70 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2cd8>
100021058: 927e0ae9    	and	x9, x23, #0x1c
10002105c: 927beae8    	and	x8, x23, #0xffffffffffffffe0
100021060: 910082ca    	add	x10, x22, #0x20
100021064: 927beaeb    	and	x11, x23, #0xffffffffffffffe0
100021068: ad7f0540    	ldp	q0, q1, [x10, #-0x20]
10002106c: ad400d42    	ldp	q2, q3, [x10]
100021070: 6e642c00    	uqsub.8h	v0, v0, v4
100021074: 6e642c21    	uqsub.8h	v1, v1, v4
100021078: 6e642c42    	uqsub.8h	v2, v2, v4
10002107c: 6e642c63    	uqsub.8h	v3, v3, v4
100021080: ad3f0540    	stp	q0, q1, [x10, #-0x20]
100021084: ac820d42    	stp	q2, q3, [x10], #0x40
100021088: f100816b    	subs	x11, x11, #0x20
10002108c: 54fffee1    	b.ne	0x100021068 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2dd0>
100021090: eb0802ff    	cmp	x23, x8
100021094: 54000260    	b.eq	0x1000210e0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2e48>
100021098: b4000169    	cbz	x9, 0x1000210c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2e2c>
10002109c: aa0803ea    	mov	x10, x8
1000210a0: 927ef6e8    	and	x8, x23, #0xfffffffffffffffc
1000210a4: cb080149    	sub	x9, x10, x8
1000210a8: 8b0a06ca    	add	x10, x22, x10, lsl #1
1000210ac: fd400140    	ldr	d0, [x10]
1000210b0: 2e682c00    	uqsub.4h	v0, v0, v8
1000210b4: fc008540    	str	d0, [x10], #0x8
1000210b8: b1001129    	adds	x9, x9, #0x4
1000210bc: 54ffff81    	b.ne	0x1000210ac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2e14>
1000210c0: 14000006    	b	0x1000210d8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2e40>
1000210c4: 78e87ac9    	ldrsh	w9, [x22, x8, lsl #1]
1000210c8: 5211012a    	eor	w10, w9, #0x8000
1000210cc: 0a493d49    	and	w9, w10, w9, lsr #15
1000210d0: 78287ac9    	strh	w9, [x22, x8, lsl #1]
1000210d4: 91000508    	add	x8, x8, #0x1
1000210d8: eb0802ff    	cmp	x23, x8
1000210dc: 54ffff41    	b.ne	0x1000210c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2e2c>
1000210e0: aa1603f4    	mov	x20, x22
1000210e4: f140203f    	cmp	x1, #0x8, lsl #12       ; =0x8000
1000210e8: f941b3ea    	ldr	x10, [sp, #0x360]
1000210ec: 5405e823    	b.lo	0x10002cdf0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeb58>
1000210f0: f140423f    	cmp	x17, #0x10, lsl #12     ; =0x10000
1000210f4: 5405e7e3    	b.lo	0x10002cdf0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeb58>
1000210f8: d34ffee8    	lsr	x8, x23, #15
1000210fc: b405e7a8    	cbz	x8, 0x10002cdf0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeb58>
100021100: 91402084    	add	x4, x4, #0x8, lsl #12   ; =0x8000
100021104: aa1303ec    	mov	x12, x19
100021108: aa1403f6    	mov	x22, x20
10002110c: 91402088    	add	x8, x4, #0x8, lsl #12   ; =0x8000
100021110: f94187e9    	ldr	x9, [sp, #0x308]
100021114: eb08013f    	cmp	x9, x8
100021118: 9a883128    	csel	x8, x9, x8, lo
10002111c: f94147e9    	ldr	x9, [sp, #0x288]
100021120: eb09011f    	cmp	x8, x9
100021124: 9a893108    	csel	x8, x8, x9, lo
100021128: d1402089    	sub	x9, x4, #0x8, lsl #12   ; =0x8000
10002112c: f941a7eb    	ldr	x11, [sp, #0x348]
100021130: eb0a017f    	cmp	x11, x10
100021134: 1a9f97eb    	cset	w11, hi
100021138: b9031beb    	str	w11, [sp, #0x318]
10002113c: 8b1a00eb    	add	x11, x7, x26
100021140: 8b0400ed    	add	x13, x7, x4
100021144: f90157ed    	str	x13, [sp, #0x2a8]
100021148: f100155f    	cmp	x10, #0x5
10002114c: 540000c2    	b.hs	0x100021164 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2ecc>
100021150: d280000e    	mov	x14, #0x0               ; =0
100021154: d100046d    	sub	x13, x3, #0x1
100021158: eb0301bf    	cmp	x13, x3
10002115c: 54002382    	b.hs	0x1000215cc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3334>
100021160: 1400011f    	b	0x1000215dc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3344>
100021164: ab0a034d    	adds	x13, x26, x10
100021168: 5404ac02    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10002116c: eb1c01bf    	cmp	x13, x28
100021170: 5405abe8    	b.hi	0x10002c6ec <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe454>
100021174: 924038ad    	and	x13, x5, #0x7fff
100021178: eb0101bf    	cmp	x13, x1
10002117c: 5402ae82    	b.hs	0x10002674c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x84b4>
100021180: cb04034e    	sub	x14, x26, x4
100021184: 92403fcf    	and	x15, x30, #0xffff
100021188: eb1101ff    	cmp	x15, x17
10002118c: 5402bb22    	b.hs	0x1000268f0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8658>
100021190: aa1103f3    	mov	x19, x17
100021194: 786d7980    	ldrh	w0, [x12, x13, lsl #1]
100021198: 786f7b11    	ldrh	w17, [x24, x15, lsl #1]
10002119c: 521141d0    	eor	w16, w14, #0xffff8000
1000211a0: 782d7990    	strh	w16, [x12, x13, lsl #1]
1000211a4: 782f7b10    	strh	w16, [x24, x15, lsl #1]
1000211a8: 924039cd    	and	x13, x14, #0x7fff
1000211ac: eb1701bf    	cmp	x13, x23
1000211b0: 5402c722    	b.hs	0x100026a94 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x87fc>
1000211b4: 782d7ad1    	strh	w17, [x22, x13, lsl #1]
1000211b8: 8b1a00ef    	add	x15, x7, x26
1000211bc: b84011ed    	ldur	w13, [x15, #0x1]
1000211c0: 12005db0    	and	w16, w13, #0xffffff
1000211c4: 5294f7a2    	mov	w2, #0xa7bd             ; =42941
1000211c8: 72a3c6a2    	movk	w2, #0x1e35, lsl #16
1000211cc: 1b027e10    	mul	w16, w16, w2
1000211d0: 53117e05    	lsr	w5, w16, #17
1000211d4: 1b027dad    	mul	w13, w13, w2
1000211d8: 53107dbe    	lsr	w30, w13, #16
1000211dc: d37f7cad    	ubfiz	x13, x5, #1, #32
1000211e0: f8ad6990    	prfm	pstl1keep, [x12, x13]
1000211e4: d37f7fcd    	ubfiz	x13, x30, #1, #32
1000211e8: aa1803f4    	mov	x20, x24
1000211ec: f8ad6b10    	prfm	pstl1keep, [x24, x13]
1000211f0: b94001f0    	ldr	w16, [x15]
1000211f4: f941afed    	ldr	x13, [sp, #0x358]
1000211f8: f1000dbf    	cmp	x13, #0x3
1000211fc: 54000188    	b.hi	0x10002122c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2f94>
100021200: d100046d    	sub	x13, x3, #0x1
100021204: aa1a03f8    	mov	x24, x26
100021208: eb0001df    	cmp	x14, x0
10002120c: 54001d42    	b.hs	0x1000215b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x331c>
100021210: f941afed    	ldr	x13, [sp, #0x358]
100021214: f1000dbf    	cmp	x13, #0x3
100021218: 54001781    	b.ne	0x100021508 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3270>
10002121c: aa1a03e2    	mov	x2, x26
100021220: eb1101df    	cmp	x14, x17
100021224: 54001923    	b.lo	0x100021548 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x32b0>
100021228: 140000e2    	b	0x1000215b0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3318>
10002122c: d100046d    	sub	x13, x3, #0x1
100021230: aa1a03f8    	mov	x24, x26
100021234: eb1101df    	cmp	x14, x17
100021238: 54001be2    	b.hs	0x1000215b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x331c>
10002123c: f94193e0    	ldr	x0, [sp, #0x320]
100021240: aa1a03f8    	mov	x24, x26
100021244: f941abed    	ldr	x13, [sp, #0x350]
100021248: d10005ad    	sub	x13, x13, #0x1
10002124c: f941afe2    	ldr	x2, [sp, #0x358]
100021250: f941a7e3    	ldr	x3, [sp, #0x348]
100021254: eb03005f    	cmp	x2, x3
100021258: 54001ae2    	b.hs	0x1000215b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x331c>
10002125c: b9431bea    	ldr	w10, [sp, #0x318]
100021260: 3600004a    	tbz	w10, #0x0, 0x100021268 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2fd0>
100021264: 14002de6    	b	0x10002c9fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe764>
100021268: aa1803e2    	mov	x2, x24
10002126c: aa0d03e3    	mov	x3, x13
100021270: f1000c6d    	subs	x13, x3, #0x3
100021274: 5405bc43    	b.lo	0x10002c9fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe764>
100021278: f941a7ea    	ldr	x10, [sp, #0x348]
10002127c: eb0a007f    	cmp	x3, x10
100021280: 5405bbe2    	b.hs	0x10002c9fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe764>
100021284: aa0c03f5    	mov	x21, x12
100021288: aa0503ec    	mov	x12, x5
10002128c: 8b0301ea    	add	x10, x15, x3
100021290: b85fd14a    	ldur	w10, [x10, #-0x3]
100021294: d1000405    	sub	x5, x0, #0x1
100021298: aa0503e0    	mov	x0, x5
10002129c: 8b110138    	add	x24, x9, x17
1000212a0: 8b1801a5    	add	x5, x13, x24
1000212a4: f941b7e6    	ldr	x6, [sp, #0x368]
1000212a8: eb0600bf    	cmp	x5, x6
1000212ac: 540000a2    	b.hs	0x1000212c0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3028>
1000212b0: b86568e5    	ldr	w5, [x7, x5]
1000212b4: 6b0a00bf    	cmp	w5, w10
1000212b8: 540000a0    	b.eq	0x1000212cc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3034>
1000212bc: 1400000e    	b	0x1000212f4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x305c>
1000212c0: 52800005    	mov	w5, #0x0                ; =0
1000212c4: 6b0a00bf    	cmp	w5, w10
1000212c8: 54000161    	b.ne	0x1000212f4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x305c>
1000212cc: f941b7e5    	ldr	x5, [sp, #0x368]
1000212d0: eb05031f    	cmp	x24, x5
1000212d4: 540000a2    	b.hs	0x1000212e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3050>
1000212d8: b87868e5    	ldr	w5, [x7, x24]
1000212dc: 6b1000bf    	cmp	w5, w16
1000212e0: 540000a1    	b.ne	0x1000212f4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x305c>
1000212e4: 14000011    	b	0x100021328 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3090>
1000212e8: 52800005    	mov	w5, #0x0                ; =0
1000212ec: 6b1000bf    	cmp	w5, w16
1000212f0: 540001c0    	b.eq	0x100021328 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3090>
1000212f4: 92403a31    	and	x17, x17, #0x7fff
1000212f8: eb17023f    	cmp	x17, x23
1000212fc: 540000e2    	b.hs	0x100021318 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3080>
100021300: 78717ad1    	ldrh	w17, [x22, x17, lsl #1]
100021304: eb1101df    	cmp	x14, x17
100021308: 54000f22    	b.hs	0x1000214ec <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3254>
10002130c: d1000405    	sub	x5, x0, #0x1
100021310: b5fffc40    	cbnz	x0, 0x100021298 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3000>
100021314: 14000076    	b	0x1000214ec <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3254>
100021318: d2800011    	mov	x17, #0x0               ; =0
10002131c: eb1101df    	cmp	x14, x17
100021320: 54ffff63    	b.lo	0x10002130c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3074>
100021324: 14000072    	b	0x1000214ec <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3254>
100021328: eb1a031f    	cmp	x24, x26
10002132c: 5405aae2    	b.hs	0x10002c888 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe5f0>
100021330: f941b3ea    	ldr	x10, [sp, #0x360]
100021334: f100915f    	cmp	x10, #0x24
100021338: 54000282    	b.hs	0x100021388 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x30f0>
10002133c: f90183e4    	str	x4, [sp, #0x300]
100021340: f9016be1    	str	x1, [sp, #0x2d0]
100021344: 5280008d    	mov	w13, #0x4               ; =4
100021348: b27d01a5    	orr	x5, x13, #0x8
10002134c: f94157ea    	ldr	x10, [sp, #0x2a8]
100021350: 8b110144    	add	x4, x10, x17
100021354: f941b3e6    	ldr	x6, [sp, #0x360]
100021358: eb0600bf    	cmp	x5, x6
10002135c: 54000408    	b.hi	0x1000213dc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3144>
100021360: f86d6965    	ldr	x5, [x11, x13]
100021364: 8b0d0086    	add	x6, x4, x13
100021368: 928fffea    	mov	x10, #-0x8000           ; =-32768
10002136c: f86a68c6    	ldr	x6, [x6, x10]
100021370: eb0500df    	cmp	x6, x5
100021374: 54000561    	b.ne	0x100021420 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3188>
100021378: b10041a5    	adds	x5, x13, #0x10
10002137c: 910021ad    	add	x13, x13, #0x8
100021380: 54fffea3    	b.lo	0x100021354 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x30bc>
100021384: 140024d9    	b	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100021388: 8b1800e5    	add	x5, x7, x24
10002138c: f84041ed    	ldur	x13, [x15, #0x4]
100021390: f84040aa    	ldur	x10, [x5, #0x4]
100021394: eb0d015f    	cmp	x10, x13
100021398: 540005e1    	b.ne	0x100021454 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x31bc>
10002139c: f840c1ed    	ldur	x13, [x15, #0xc]
1000213a0: f840c0aa    	ldur	x10, [x5, #0xc]
1000213a4: eb0d015f    	cmp	x10, x13
1000213a8: 540005a1    	b.ne	0x10002145c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x31c4>
1000213ac: f84141ed    	ldur	x13, [x15, #0x14]
1000213b0: f84140aa    	ldur	x10, [x5, #0x14]
1000213b4: eb0d015f    	cmp	x10, x13
1000213b8: 54000561    	b.ne	0x100021464 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x31cc>
1000213bc: f841c1ed    	ldur	x13, [x15, #0x1c]
1000213c0: f841c0aa    	ldur	x10, [x5, #0x1c]
1000213c4: eb0d015f    	cmp	x10, x13
1000213c8: 54000521    	b.ne	0x10002146c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x31d4>
1000213cc: f90183e4    	str	x4, [sp, #0x300]
1000213d0: f9016be1    	str	x1, [sp, #0x2d0]
1000213d4: 5280048d    	mov	w13, #0x24              ; =36
1000213d8: 17ffffdc    	b	0x100021348 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x30b0>
1000213dc: f941b3e4    	ldr	x4, [sp, #0x360]
1000213e0: eb0401bf    	cmp	x13, x4
1000213e4: 54000262    	b.hs	0x100021430 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3198>
1000213e8: f94157ea    	ldr	x10, [sp, #0x2a8]
1000213ec: 8b110144    	add	x4, x10, x17
1000213f0: 386d6965    	ldrb	w5, [x11, x13]
1000213f4: 8b0d0086    	add	x6, x4, x13
1000213f8: 928fffea    	mov	x10, #-0x8000           ; =-32768
1000213fc: 386a68c6    	ldrb	w6, [x6, x10]
100021400: 6b0600bf    	cmp	w5, w6
100021404: 54000161    	b.ne	0x100021430 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3198>
100021408: 910005ad    	add	x13, x13, #0x1
10002140c: f941b3e5    	ldr	x5, [sp, #0x360]
100021410: eb0d00bf    	cmp	x5, x13
100021414: 54fffee1    	b.ne	0x1000213f0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3158>
100021418: f941b3ed    	ldr	x13, [sp, #0x360]
10002141c: 14000005    	b	0x100021430 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3198>
100021420: ca0500c4    	eor	x4, x6, x5
100021424: dac00084    	rbit	x4, x4
100021428: dac01084    	clz	x4, x4
10002142c: 8b440dad    	add	x13, x13, x4, lsr #3
100021430: f9416be1    	ldr	x1, [sp, #0x2d0]
100021434: f94183e4    	ldr	x4, [sp, #0x300]
100021438: eb0301bf    	cmp	x13, x3
10002143c: f941b3ea    	ldr	x10, [sp, #0x360]
100021440: aa0c03e5    	mov	x5, x12
100021444: aa1503ec    	mov	x12, x21
100021448: f94197f5    	ldr	x21, [sp, #0x328]
10002144c: 54000268    	b.hi	0x100021498 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3200>
100021450: 14000017    	b	0x1000214ac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3214>
100021454: 52800085    	mov	w5, #0x4                ; =4
100021458: 14000006    	b	0x100021470 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x31d8>
10002145c: 52800185    	mov	w5, #0xc                ; =12
100021460: 14000004    	b	0x100021470 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x31d8>
100021464: 52800285    	mov	w5, #0x14               ; =20
100021468: 14000002    	b	0x100021470 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x31d8>
10002146c: 52800385    	mov	w5, #0x1c               ; =28
100021470: ca0d014d    	eor	x13, x10, x13
100021474: dac001ad    	rbit	x13, x13
100021478: dac011ad    	clz	x13, x13
10002147c: 8b4d0cad    	add	x13, x5, x13, lsr #3
100021480: eb0301bf    	cmp	x13, x3
100021484: f941b3ea    	ldr	x10, [sp, #0x360]
100021488: aa0c03e5    	mov	x5, x12
10002148c: aa1503ec    	mov	x12, x21
100021490: f94197f5    	ldr	x21, [sp, #0x328]
100021494: 540000c9    	b.ls	0x1000214ac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3214>
100021498: 8b110122    	add	x2, x9, x17
10002149c: aa0d03e3    	mov	x3, x13
1000214a0: f941a7e6    	ldr	x6, [sp, #0x348]
1000214a4: eb0601bf    	cmp	x13, x6
1000214a8: 54000862    	b.hs	0x1000215b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x331c>
1000214ac: 92403a2d    	and	x13, x17, #0x7fff
1000214b0: eb0d02ff    	cmp	x23, x13
1000214b4: 54000109    	b.ls	0x1000214d4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x323c>
1000214b8: 786d7ad1    	ldrh	w17, [x22, x13, lsl #1]
1000214bc: eb1101df    	cmp	x14, x17
1000214c0: 54000102    	b.hs	0x1000214e0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3248>
1000214c4: aa0303ed    	mov	x13, x3
1000214c8: aa0203f8    	mov	x24, x2
1000214cc: b5ffed20    	cbnz	x0, 0x100021270 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2fd8>
1000214d0: 14000039    	b	0x1000215b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x331c>
1000214d4: d2800011    	mov	x17, #0x0               ; =0
1000214d8: eb1101df    	cmp	x14, x17
1000214dc: 54ffff43    	b.lo	0x1000214c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x322c>
1000214e0: aa0303ed    	mov	x13, x3
1000214e4: aa0203f8    	mov	x24, x2
1000214e8: 14000033    	b	0x1000215b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x331c>
1000214ec: aa0303ed    	mov	x13, x3
1000214f0: aa0203f8    	mov	x24, x2
1000214f4: f941b3ea    	ldr	x10, [sp, #0x360]
1000214f8: aa0c03e5    	mov	x5, x12
1000214fc: aa1503ec    	mov	x12, x21
100021500: f94197f5    	ldr	x21, [sp, #0x328]
100021504: 1400002c    	b	0x1000215b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x331c>
100021508: 8b000120    	add	x0, x9, x0
10002150c: f941b7ed    	ldr	x13, [sp, #0x368]
100021510: eb0d001f    	cmp	x0, x13
100021514: 54000082    	b.hs	0x100021524 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x328c>
100021518: b86068ed    	ldr	w13, [x7, x0]
10002151c: 12005dad    	and	w13, w13, #0xffffff
100021520: 14000002    	b	0x100021528 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3290>
100021524: 5280000d    	mov	w13, #0x0               ; =0
100021528: 12005e02    	and	w2, w16, #0xffffff
10002152c: 6b0201bf    	cmp	w13, w2
100021530: 5280006d    	mov	w13, #0x3               ; =3
100021534: f941afe2    	ldr	x2, [sp, #0x358]
100021538: 9a8201ad    	csel	x13, x13, x2, eq
10002153c: 9a9a0002    	csel	x2, x0, x26, eq
100021540: eb1101df    	cmp	x14, x17
100021544: 54000362    	b.hs	0x1000215b0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3318>
100021548: f94193e0    	ldr	x0, [sp, #0x320]
10002154c: d1000403    	sub	x3, x0, #0x1
100021550: aa0303e0    	mov	x0, x3
100021554: 8b110138    	add	x24, x9, x17
100021558: f941b7e3    	ldr	x3, [sp, #0x368]
10002155c: eb03031f    	cmp	x24, x3
100021560: 540000a2    	b.hs	0x100021574 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x32dc>
100021564: b87868e3    	ldr	w3, [x7, x24]
100021568: 6b10007f    	cmp	w3, w16
10002156c: 540000a1    	b.ne	0x100021580 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x32e8>
100021570: 1400003a    	b	0x100021658 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x33c0>
100021574: 52800003    	mov	w3, #0x0                ; =0
100021578: 6b10007f    	cmp	w3, w16
10002157c: 540006e0    	b.eq	0x100021658 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x33c0>
100021580: 92403a31    	and	x17, x17, #0x7fff
100021584: eb17023f    	cmp	x17, x23
100021588: 540000e2    	b.hs	0x1000215a4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x330c>
10002158c: 78717ad1    	ldrh	w17, [x22, x17, lsl #1]
100021590: eb1101df    	cmp	x14, x17
100021594: 540000e2    	b.hs	0x1000215b0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3318>
100021598: d1000403    	sub	x3, x0, #0x1
10002159c: b5fffda0    	cbnz	x0, 0x100021550 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x32b8>
1000215a0: 14000004    	b	0x1000215b0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3318>
1000215a4: d2800011    	mov	x17, #0x0               ; =0
1000215a8: eb1101df    	cmp	x14, x17
1000215ac: 54ffff63    	b.lo	0x100021598 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3300>
1000215b0: aa0203f8    	mov	x24, x2
1000215b4: cb18034e    	sub	x14, x26, x24
1000215b8: aa1403f8    	mov	x24, x20
1000215bc: f941abe3    	ldr	x3, [sp, #0x350]
1000215c0: aa1303f1    	mov	x17, x19
1000215c4: eb0301bf    	cmp	x13, x3
1000215c8: 540000a3    	b.lo	0x1000215dc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3344>
1000215cc: f1000dbf    	cmp	x13, #0x3
1000215d0: 54001228    	b.hi	0x100021814 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x357c>
1000215d4: f14005df    	cmp	x14, #0x1, lsl #12      ; =0x1000
1000215d8: 540011e9    	b.ls	0x100021814 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x357c>
1000215dc: eb1c035f    	cmp	x26, x28
1000215e0: 540010a2    	b.hs	0x1000217f4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x355c>
1000215e4: 387a68ef    	ldrb	w15, [x7, x26]
1000215e8: b86f7ab0    	ldr	w16, [x21, x15, lsl #2]
1000215ec: 11000610    	add	w16, w16, #0x1
1000215f0: b82f7ab0    	str	w16, [x21, x15, lsl #2]
1000215f4: d3461df0    	ubfx	x16, x15, #6, #2
1000215f8: 924001ef    	and	x15, x15, #0x1
1000215fc: aa1005ef    	orr	x15, x15, x16, lsl #1
100021600: 8b0f0aaf    	add	x15, x21, x15, lsl #2
100021604: b94805f0    	ldr	w16, [x15, #0x804]
100021608: 11000610    	add	w16, w16, #0x1
10002160c: b90805f0    	str	w16, [x15, #0x804]
100021610: 91000739    	add	x25, x25, #0x1
100021614: 1100077b    	add	w27, w27, #0x1
100021618: 9100075a    	add	x26, x26, #0x1
10002161c: eb08035f    	cmp	x26, x8
100021620: 54000f62    	b.hs	0x10002180c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3574>
100021624: cb1a038f    	sub	x15, x28, x26
100021628: 9100056b    	add	x11, x11, #0x1
10002162c: d343fdef    	lsr	x15, x15, #3
100021630: f109c5ff    	cmp	x15, #0x271
100021634: 54ffd8a3    	b.lo	0x100021148 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2eb0>
100021638: f108033f    	cmp	x25, #0x200
10002163c: 54ffd863    	b.lo	0x100021148 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2eb0>
100021640: f9419bef    	ldr	x15, [sp, #0x330]
100021644: cb0f034f    	sub	x15, x26, x15
100021648: d343fdef    	lsr	x15, x15, #3
10002164c: f109c1ff    	cmp	x15, #0x270
100021650: 54ffd7c9    	b.ls	0x100021148 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2eb0>
100021654: 1400006e    	b	0x10002180c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3574>
100021658: eb1a031f    	cmp	x24, x26
10002165c: 54059162    	b.hs	0x10002c888 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe5f0>
100021660: f100915f    	cmp	x10, #0x24
100021664: 54000262    	b.hs	0x1000216b0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3418>
100021668: aa0c03f5    	mov	x21, x12
10002166c: 5280008d    	mov	w13, #0x4               ; =4
100021670: b27d01a3    	orr	x3, x13, #0x8
100021674: f94157ec    	ldr	x12, [sp, #0x2a8]
100021678: 8b110182    	add	x2, x12, x17
10002167c: eb0a007f    	cmp	x3, x10
100021680: 54000408    	b.hi	0x100021700 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3468>
100021684: f86d6963    	ldr	x3, [x11, x13]
100021688: 8b0d004a    	add	x10, x2, x13
10002168c: 928fffec    	mov	x12, #-0x8000           ; =-32768
100021690: f86c694a    	ldr	x10, [x10, x12]
100021694: eb03015f    	cmp	x10, x3
100021698: 540005e1    	b.ne	0x100021754 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x34bc>
10002169c: b10041a3    	adds	x3, x13, #0x10
1000216a0: 910021ad    	add	x13, x13, #0x8
1000216a4: f941b3ea    	ldr	x10, [sp, #0x360]
1000216a8: 54fffea3    	b.lo	0x10002167c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x33e4>
1000216ac: 1400240f    	b	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000216b0: 8b1800e3    	add	x3, x7, x24
1000216b4: f84041ed    	ldur	x13, [x15, #0x4]
1000216b8: f8404062    	ldur	x2, [x3, #0x4]
1000216bc: eb0d005f    	cmp	x2, x13
1000216c0: 54000601    	b.ne	0x100021780 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x34e8>
1000216c4: f840c1ed    	ldur	x13, [x15, #0xc]
1000216c8: f840c062    	ldur	x2, [x3, #0xc]
1000216cc: eb0d005f    	cmp	x2, x13
1000216d0: 540005c1    	b.ne	0x100021788 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x34f0>
1000216d4: f84141ed    	ldur	x13, [x15, #0x14]
1000216d8: f8414062    	ldur	x2, [x3, #0x14]
1000216dc: eb0d005f    	cmp	x2, x13
1000216e0: 54000661    	b.ne	0x1000217ac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3514>
1000216e4: f841c1ed    	ldur	x13, [x15, #0x1c]
1000216e8: f841c062    	ldur	x2, [x3, #0x1c]
1000216ec: eb0d005f    	cmp	x2, x13
1000216f0: 54000621    	b.ne	0x1000217b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x351c>
1000216f4: aa0c03f5    	mov	x21, x12
1000216f8: 5280048d    	mov	w13, #0x24              ; =36
1000216fc: 17ffffdd    	b	0x100021670 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x33d8>
100021700: eb0a01bf    	cmp	x13, x10
100021704: 54000482    	b.hs	0x100021794 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x34fc>
100021708: f94157ea    	ldr	x10, [sp, #0x2a8]
10002170c: 8b110142    	add	x2, x10, x17
100021710: 386d6963    	ldrb	w3, [x11, x13]
100021714: 8b0d004a    	add	x10, x2, x13
100021718: 928fffec    	mov	x12, #-0x8000           ; =-32768
10002171c: 386c694a    	ldrb	w10, [x10, x12]
100021720: 6b0a007f    	cmp	w3, w10
100021724: 54000361    	b.ne	0x100021790 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x34f8>
100021728: 910005ad    	add	x13, x13, #0x1
10002172c: f941b3ea    	ldr	x10, [sp, #0x360]
100021730: eb0d015f    	cmp	x10, x13
100021734: 54fffee1    	b.ne	0x100021710 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3478>
100021738: aa0a03ed    	mov	x13, x10
10002173c: aa1503ec    	mov	x12, x21
100021740: f94197f5    	ldr	x21, [sp, #0x328]
100021744: f941a7e2    	ldr	x2, [sp, #0x348]
100021748: eb02015f    	cmp	x10, x2
10002174c: 54fff342    	b.hs	0x1000215b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x331c>
100021750: 14000021    	b	0x1000217d4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x353c>
100021754: ca030142    	eor	x2, x10, x3
100021758: dac00042    	rbit	x2, x2
10002175c: dac01042    	clz	x2, x2
100021760: 8b420dad    	add	x13, x13, x2, lsr #3
100021764: f941b3ea    	ldr	x10, [sp, #0x360]
100021768: aa1503ec    	mov	x12, x21
10002176c: f94197f5    	ldr	x21, [sp, #0x328]
100021770: f941a7e2    	ldr	x2, [sp, #0x348]
100021774: eb0201bf    	cmp	x13, x2
100021778: 54fff1e2    	b.hs	0x1000215b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x331c>
10002177c: 14000016    	b	0x1000217d4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x353c>
100021780: 52800083    	mov	w3, #0x4                ; =4
100021784: 1400000d    	b	0x1000217b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3520>
100021788: 52800183    	mov	w3, #0xc                ; =12
10002178c: 1400000b    	b	0x1000217b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3520>
100021790: f941b3ea    	ldr	x10, [sp, #0x360]
100021794: aa1503ec    	mov	x12, x21
100021798: f94197f5    	ldr	x21, [sp, #0x328]
10002179c: f941a7e2    	ldr	x2, [sp, #0x348]
1000217a0: eb0201bf    	cmp	x13, x2
1000217a4: 54fff082    	b.hs	0x1000215b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x331c>
1000217a8: 1400000b    	b	0x1000217d4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x353c>
1000217ac: 52800283    	mov	w3, #0x14               ; =20
1000217b0: 14000002    	b	0x1000217b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3520>
1000217b4: 52800383    	mov	w3, #0x1c               ; =28
1000217b8: ca0d004d    	eor	x13, x2, x13
1000217bc: dac001ad    	rbit	x13, x13
1000217c0: dac011ad    	clz	x13, x13
1000217c4: 8b4d0c6d    	add	x13, x3, x13, lsr #3
1000217c8: f941a7e2    	ldr	x2, [sp, #0x348]
1000217cc: eb0201bf    	cmp	x13, x2
1000217d0: 54ffef22    	b.hs	0x1000215b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x331c>
1000217d4: 92403a31    	and	x17, x17, #0x7fff
1000217d8: eb1102ff    	cmp	x23, x17
1000217dc: 54000109    	b.ls	0x1000217fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3564>
1000217e0: 78717ad1    	ldrh	w17, [x22, x17, lsl #1]
1000217e4: eb1101df    	cmp	x14, x17
1000217e8: 54ffee62    	b.hs	0x1000215b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x331c>
1000217ec: b5ffd380    	cbnz	x0, 0x10002125c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2fc4>
1000217f0: 17ffff71    	b	0x1000215b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x331c>
1000217f4: d280000f    	mov	x15, #0x0               ; =0
1000217f8: 17ffff7c    	b	0x1000215e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3350>
1000217fc: d2800011    	mov	x17, #0x0               ; =0
100021800: eb1101df    	cmp	x14, x17
100021804: 54ffff43    	b.lo	0x1000217ec <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3554>
100021808: 17ffff6b    	b	0x1000215b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x331c>
10002180c: eb0301bf    	cmp	x13, x3
100021810: 540015a3    	b.lo	0x100021ac4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x382c>
100021814: f1000dbf    	cmp	x13, #0x3
100021818: 54000068    	b.hi	0x100021824 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x358c>
10002181c: f14005df    	cmp	x14, #0x1, lsl #12      ; =0x1000
100021820: 54001528    	b.hi	0x100021ac4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x382c>
100021824: f10409bf    	cmp	x13, #0x102
100021828: 54002508    	b.hi	0x100021cc8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3a30>
10002182c: 100c4ce8    	adr	x8, 0x10003a1c8 <_roc__d59_1>
100021830: d503201f    	nop
100021834: 8b0d0108    	add	x8, x8, x13
100021838: 39402108    	ldrb	w8, [x8, #0x8]
10002183c: d37ef508    	lsl	x8, x8, #2
100021840: 91101108    	add	x8, x8, #0x404
100021844: 52802009    	mov	w9, #0x100              ; =256
100021848: 4b0e0129    	sub	w9, w9, w14
10002184c: 531d7d29    	lsr	w9, w9, #29
100021850: d10005ca    	sub	x10, x14, #0x1
100021854: 9ac9254a    	lsr	x10, x10, x9
100021858: f103fd5f    	cmp	x10, #0xff
10002185c: 540023a8    	b.hi	0x100021cd0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3a38>
100021860: 100c414b    	adr	x11, 0x10003a088 <_roc__d57_1>
100021864: d503201f    	nop
100021868: 8b0a016a    	add	x10, x11, x10
10002186c: 3940214a    	ldrb	w10, [x10, #0x8]
100021870: b8686aab    	ldr	w11, [x21, x8]
100021874: 8b090549    	add	x9, x10, x9, lsl #1
100021878: 1100056a    	add	w10, w11, #0x1
10002187c: b8286aaa    	str	w10, [x21, x8]
100021880: f9412bea    	ldr	x10, [sp, #0x250]
100021884: b8697948    	ldr	w8, [x10, x9, lsl #2]
100021888: 11000508    	add	w8, w8, #0x1
10002188c: b8297948    	str	w8, [x10, x9, lsl #2]
100021890: f10021bf    	cmp	x13, #0x8
100021894: 52810488    	mov	w8, #0x824              ; =2084
100021898: 5281050a    	mov	w10, #0x828             ; =2088
10002189c: 9a888148    	csel	x8, x10, x8, hi
1000218a0: b8686aaa    	ldr	w10, [x21, x8]
1000218a4: 1100054a    	add	w10, w10, #0x1
1000218a8: b8286aaa    	str	w10, [x21, x8]
1000218ac: f94173e8    	ldr	x8, [sp, #0x2e0]
1000218b0: f94123ea    	ldr	x10, [sp, #0x240]
1000218b4: eb08015f    	cmp	x10, x8
1000218b8: f9018bf8    	str	x24, [sp, #0x310]
1000218bc: 540020e0    	b.eq	0x100021cd8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3a40>
1000218c0: 2a0d5f68    	orr	w8, w27, w13, lsl #23
1000218c4: d3603dca    	ubfiz	x10, x14, #32, #16
1000218c8: aa09c149    	orr	x9, x10, x9, lsl #48
1000218cc: aa080128    	orr	x8, x9, x8
1000218d0: f94133e9    	ldr	x9, [sp, #0x260]
1000218d4: f94173ea    	ldr	x10, [sp, #0x2e0]
1000218d8: f82a7928    	str	x8, [x9, x10, lsl #3]
1000218dc: 9100054a    	add	x10, x10, #0x1
1000218e0: f90173ea    	str	x10, [sp, #0x2e0]
1000218e4: 8b0d0353    	add	x19, x26, x13
1000218e8: 91001668    	add	x8, x19, #0x5
1000218ec: eb1c011f    	cmp	x8, x28
1000218f0: 54000508    	b.hi	0x100021990 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x36f8>
1000218f4: cb040268    	sub	x8, x19, x4
1000218f8: f140211f    	cmp	x8, #0x8, lsl #12       ; =0x8000
1000218fc: 540004a8    	b.hi	0x100021990 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x36f8>
100021900: f140203f    	cmp	x1, #0x8, lsl #12       ; =0x8000
100021904: 54000463    	b.lo	0x100021990 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x36f8>
100021908: f140423f    	cmp	x17, #0x10, lsl #12     ; =0x10000
10002190c: 54000423    	b.lo	0x100021990 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x36f8>
100021910: f14022ff    	cmp	x23, #0x8, lsl #12      ; =0x8000
100021914: 540003e3    	b.lo	0x100021990 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x36f8>
100021918: d34ffca8    	lsr	x8, x5, #15
10002191c: b50003a8    	cbnz	x8, 0x100021990 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x36f8>
100021920: f14043df    	cmp	x30, #0x10, lsl #12     ; =0x10000
100021924: 54000362    	b.hs	0x100021990 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x36f8>
100021928: f940ebe8    	ldr	x8, [sp, #0x1d0]
10002192c: eb08027f    	cmp	x19, x8
100021930: 9a883268    	csel	x8, x19, x8, lo
100021934: 91000749    	add	x9, x26, #0x1
100021938: cb04012b    	sub	x11, x9, x4
10002193c: f10005df    	cmp	x14, #0x1
100021940: 54000ea1    	b.ne	0x100021b14 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x387c>
100021944: f10021bf    	cmp	x13, #0x8
100021948: 54000e63    	b.lo	0x100021b14 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x387c>
10002194c: aa0c03f5    	mov	x21, x12
100021950: d1000d09    	sub	x9, x8, #0x3
100021954: cb04012a    	sub	x10, x9, x4
100021958: f140215f    	cmp	x10, #0x8, lsl #12      ; =0x8000
10002195c: 540651a8    	b.hi	0x10002e390 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x100f8>
100021960: aa0403e0    	mov	x0, x4
100021964: 9240396c    	and	x12, x11, #0x7fff
100021968: eb0a019f    	cmp	x12, x10
10002196c: 528fffe2    	mov	w2, #0x7fff             ; =32767
100021970: 54001422    	b.hs	0x100021bf4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x395c>
100021974: 8b0c000b    	add	x11, x0, x12
100021978: cb0b010b    	sub	x11, x8, x11
10002197c: d1000d6b    	sub	x11, x11, #0x3
100021980: f100117f    	cmp	x11, #0x4
100021984: 54000d02    	b.hs	0x100021b24 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x388c>
100021988: aa0c03ee    	mov	x14, x12
10002198c: 14000095    	b	0x100021be0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3948>
100021990: 91000748    	add	x8, x26, #0x1
100021994: d10005a9    	sub	x9, x13, #0x1
100021998: f90c17ec    	str	x12, [sp, #0x1828]
10002199c: f90c1be1    	str	x1, [sp, #0x1830]
1000219a0: f94163ea    	ldr	x10, [sp, #0x2c0]
1000219a4: f90c1fea    	str	x10, [sp, #0x1838]
1000219a8: f9418bea    	ldr	x10, [sp, #0x310]
1000219ac: f90c23ea    	str	x10, [sp, #0x1840]
1000219b0: f90c27f1    	str	x17, [sp, #0x1848]
1000219b4: f9415fea    	ldr	x10, [sp, #0x2b8]
1000219b8: f90c2bea    	str	x10, [sp, #0x1850]
1000219bc: f90c5ff6    	str	x22, [sp, #0x18b8]
1000219c0: f90c63f7    	str	x23, [sp, #0x18c0]
1000219c4: f9415bea    	ldr	x10, [sp, #0x2b0]
1000219c8: f90c67ea    	str	x10, [sp, #0x18c8]
1000219cc: f90ee7e7    	str	x7, [sp, #0x1dc8]
1000219d0: f90eebfc    	str	x28, [sp, #0x1dd0]
1000219d4: f9413fea    	ldr	x10, [sp, #0x278]
1000219d8: f90eefea    	str	x10, [sp, #0x1dd8]
1000219dc: a900a7fc    	stp	x28, x9, [sp, #0x8]
1000219e0: 912683e0    	add	x0, sp, #0x9a0
1000219e4: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
1000219e8: 9120a021    	add	x1, x1, #0x828
1000219ec: 914007e2    	add	x2, sp, #0x1, lsl #12   ; =0x1000
1000219f0: 91210042    	add	x2, x2, #0x840
1000219f4: 914007e3    	add	x3, sp, #0x1, lsl #12   ; =0x1000
1000219f8: 9122e063    	add	x3, x3, #0x8b8
1000219fc: 914007e7    	add	x7, sp, #0x1, lsl #12   ; =0x1000
100021a00: 913720e7    	add	x7, x7, #0xdc8
100021a04: f90003e8    	str	x8, [sp]
100021a08: aa1e03e6    	mov	x6, x30
100021a0c: 940036c3    	bl	0x10002f518 <_roc__p493fc421faab5de2c54ac596394a8587.fast>
100021a10: f944d3e4    	ldr	x4, [sp, #0x9a0]
100021a14: f944d7e5    	ldr	x5, [sp, #0x9a8]
100021a18: f944dbfe    	ldr	x30, [sp, #0x9b0]
100021a1c: f944dff6    	ldr	x22, [sp, #0x9b8]
100021a20: f944e3f7    	ldr	x23, [sp, #0x9c0]
100021a24: f944e7e8    	ldr	x8, [sp, #0x9c8]
100021a28: f9015be8    	str	x8, [sp, #0x2b0]
100021a2c: f944ebec    	ldr	x12, [sp, #0x9d0]
100021a30: f944efe1    	ldr	x1, [sp, #0x9d8]
100021a34: f944f3e8    	ldr	x8, [sp, #0x9e0]
100021a38: f90163e8    	str	x8, [sp, #0x2c0]
100021a3c: f944f7e8    	ldr	x8, [sp, #0x9e8]
100021a40: f9018be8    	str	x8, [sp, #0x310]
100021a44: f944fbf1    	ldr	x17, [sp, #0x9f0]
100021a48: f944ffe8    	ldr	x8, [sp, #0x9f8]
100021a4c: f9015fe8    	str	x8, [sp, #0x2b8]
100021a50: 396803e8    	ldrb	w8, [sp, #0xa00]
100021a54: 7100051f    	cmp	w8, #0x1
100021a58: 54000200    	b.eq	0x100021a98 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3800>
100021a5c: 912683e0    	add	x0, sp, #0x9a0
100021a60: aa1103fa    	mov	x26, x17
100021a64: aa0103fb    	mov	x27, x1
100021a68: aa0403fc    	mov	x28, x4
100021a6c: aa1e03f8    	mov	x24, x30
100021a70: aa0503f4    	mov	x20, x5
100021a74: aa0c03f5    	mov	x21, x12
100021a78: 94003b5b    	bl	0x1000307e4 <_roc_llvm_rc_decref_38_single_thread>
100021a7c: aa1503ec    	mov	x12, x21
100021a80: f94197f5    	ldr	x21, [sp, #0x328]
100021a84: aa1403e5    	mov	x5, x20
100021a88: aa1803fe    	mov	x30, x24
100021a8c: aa1c03e4    	mov	x4, x28
100021a90: aa1b03e1    	mov	x1, x27
100021a94: aa1a03f1    	mov	x17, x26
100021a98: f9419fe7    	ldr	x7, [sp, #0x338]
100021a9c: f941a3fc    	ldr	x28, [sp, #0x340]
100021aa0: f941abe3    	ldr	x3, [sp, #0x350]
100021aa4: 5280001b    	mov	w27, #0x0               ; =0
100021aa8: 91000739    	add	x25, x25, #0x1
100021aac: d37ff8a8    	lsl	x8, x5, #1
100021ab0: f8a86990    	prfm	pstl1keep, [x12, x8]
100021ab4: d37ffbc8    	lsl	x8, x30, #1
100021ab8: f9418bf8    	ldr	x24, [sp, #0x310]
100021abc: f8a86b10    	prfm	pstl1keep, [x24, x8]
100021ac0: aa1303fa    	mov	x26, x19
100021ac4: f94187e8    	ldr	x8, [sp, #0x308]
100021ac8: eb08035f    	cmp	x26, x8
100021acc: 54003802    	b.hs	0x1000221cc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3f34>
100021ad0: f94173e8    	ldr	x8, [sp, #0x2e0]
100021ad4: d344fd08    	lsr	x8, x8, #4
100021ad8: f130d11f    	cmp	x8, #0xc34
100021adc: 54003788    	b.hi	0x1000221cc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3f34>
100021ae0: f108033f    	cmp	x25, #0x200
100021ae4: f941b3ea    	ldr	x10, [sp, #0x360]
100021ae8: 54ff8143    	b.lo	0x100020b10 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2878>
100021aec: f9419be8    	ldr	x8, [sp, #0x330]
100021af0: cb080348    	sub	x8, x26, x8
100021af4: d343fd09    	lsr	x9, x8, #3
100021af8: f109c53f    	cmp	x9, #0x271
100021afc: 54ff80a3    	b.lo	0x100020b10 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2878>
100021b00: cb1a0389    	sub	x9, x28, x26
100021b04: d343fd29    	lsr	x9, x9, #3
100021b08: f109c53f    	cmp	x9, #0x271
100021b0c: 54ff8023    	b.lo	0x100020b10 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2878>
100021b10: 140000aa    	b	0x100021db8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3b20>
100021b14: cb04012a    	sub	x10, x9, x4
100021b18: eb08013f    	cmp	x9, x8
100021b1c: 54fffc42    	b.hs	0x100021aa4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x380c>
100021b20: 1400004d    	b	0x100021c54 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x39bc>
100021b24: f100817f    	cmp	x11, #0x20
100021b28: 54000082    	b.hs	0x100021b38 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x38a0>
100021b2c: d280000d    	mov	x13, #0x0               ; =0
100021b30: aa0c03ef    	mov	x15, x12
100021b34: 1400001d    	b	0x100021ba8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3910>
100021b38: aa0103e4    	mov	x4, x1
100021b3c: aa1103e1    	mov	x1, x17
100021b40: 927e096e    	and	x14, x11, #0x1c
100021b44: 927be96d    	and	x13, x11, #0xffffffffffffffe0
100021b48: 8b0d018f    	add	x15, x12, x13
100021b4c: 4e020d80    	dup.8h	v0, w12
100021b50: ad4907e6    	ldp	q6, q1, [sp, #0x120]
100021b54: 4e618400    	add.8h	v0, v0, v1
100021b58: 8b0c06d0    	add	x16, x22, x12, lsl #1
100021b5c: 91008210    	add	x16, x16, #0x20
100021b60: 927be971    	and	x17, x11, #0xffffffffffffffe0
100021b64: 6f04a405    	mvni.8h	v5, #0x80, lsl #8
100021b68: ad481ff0    	ldp	q16, q7, [sp, #0x100]
100021b6c: 4f018411    	movi.8h	v17, #0x20
100021b70: 4e658401    	add.8h	v1, v0, v5
100021b74: 4e668402    	add.8h	v2, v0, v6
100021b78: 4e678403    	add.8h	v3, v0, v7
100021b7c: 4e708404    	add.8h	v4, v0, v16
100021b80: ad3f0a01    	stp	q1, q2, [x16, #-0x20]
100021b84: ac821203    	stp	q3, q4, [x16], #0x40
100021b88: 4e718400    	add.8h	v0, v0, v17
100021b8c: f1008231    	subs	x17, x17, #0x20
100021b90: 54ffff01    	b.ne	0x100021b70 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x38d8>
100021b94: eb0d017f    	cmp	x11, x13
100021b98: aa0103f1    	mov	x17, x1
100021b9c: aa0403e1    	mov	x1, x4
100021ba0: 540002a0    	b.eq	0x100021bf4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x395c>
100021ba4: b40008ee    	cbz	x14, 0x100021cc0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3a28>
100021ba8: 927ef570    	and	x16, x11, #0xfffffffffffffffc
100021bac: 8b10018e    	add	x14, x12, x16
100021bb0: 0e020de0    	dup.4h	v0, w15
100021bb4: 0e698400    	add.4h	v0, v0, v9
100021bb8: cb1001af    	sub	x15, x13, x16
100021bbc: 8b0c01ac    	add	x12, x13, x12
100021bc0: 8b0c06cc    	add	x12, x22, x12, lsl #1
100021bc4: 0e6a8401    	add.4h	v1, v0, v10
100021bc8: fc008581    	str	d1, [x12], #0x8
100021bcc: 0e6b8400    	add.4h	v0, v0, v11
100021bd0: b10011ef    	adds	x15, x15, #0x4
100021bd4: 54ffff81    	b.ne	0x100021bc4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x392c>
100021bd8: eb10017f    	cmp	x11, x16
100021bdc: 540000c0    	b.eq	0x100021bf4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x395c>
100021be0: 0b0201cb    	add	w11, w14, w2
100021be4: 782e7acb    	strh	w11, [x22, x14, lsl #1]
100021be8: 910005ce    	add	x14, x14, #0x1
100021bec: eb0a01df    	cmp	x14, x10
100021bf0: 54ffff83    	b.lo	0x100021be0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3948>
100021bf4: 0b02014b    	add	w11, w10, w2
100021bf8: 78257aab    	strh	w11, [x21, x5, lsl #1]
100021bfc: f9418bec    	ldr	x12, [sp, #0x310]
100021c00: 783e798b    	strh	w11, [x12, x30, lsl #1]
100021c04: f941b7eb    	ldr	x11, [sp, #0x368]
100021c08: eb0b013f    	cmp	x9, x11
100021c0c: 54000062    	b.hs	0x100021c18 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3980>
100021c10: b86968eb    	ldr	w11, [x7, x9]
100021c14: 14000002    	b	0x100021c1c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3984>
100021c18: 5280000b    	mov	w11, #0x0               ; =0
100021c1c: 12005d6c    	and	w12, w11, #0xffffff
100021c20: 5294f7ad    	mov	w13, #0xa7bd            ; =42941
100021c24: 72a3c6ad    	movk	w13, #0x1e35, lsl #16
100021c28: 1b0d7d8c    	mul	w12, w12, w13
100021c2c: 53117d85    	lsr	w5, w12, #17
100021c30: 5294f7ac    	mov	w12, #0xa7bd            ; =42941
100021c34: 72a3c6ac    	movk	w12, #0x1e35, lsl #16
100021c38: 1b0c7d6b    	mul	w11, w11, w12
100021c3c: 53107d7e    	lsr	w30, w11, #16
100021c40: aa0003e4    	mov	x4, x0
100021c44: aa1503ec    	mov	x12, x21
100021c48: f94197f5    	ldr	x21, [sp, #0x328]
100021c4c: eb08013f    	cmp	x9, x8
100021c50: 54fff2a2    	b.hs	0x100021aa4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x380c>
100021c54: 9140214b    	add	x11, x10, #0x8, lsl #12 ; =0x8000
100021c58: d37ff94a    	lsl	x10, x10, #1
100021c5c: 9140414a    	add	x10, x10, #0x10, lsl #12 ; =0x10000
100021c60: cb090108    	sub	x8, x8, x9
100021c64: aa0c03f0    	mov	x16, x12
100021c68: f940cbec    	ldr	x12, [sp, #0x190]
100021c6c: 8b090189    	add	x9, x12, x9
100021c70: f9418bee    	ldr	x14, [sp, #0x310]
100021c74: 5294f7af    	mov	w15, #0xa7bd            ; =42941
100021c78: 72a3c6af    	movk	w15, #0x1e35, lsl #16
100021c7c: 787e79cc    	ldrh	w12, [x14, x30, lsl #1]
100021c80: 78257a0b    	strh	w11, [x16, x5, lsl #1]
100021c84: 927f394d    	and	x13, x10, #0xfffe
100021c88: 782d6acc    	strh	w12, [x22, x13]
100021c8c: 783e79cb    	strh	w11, [x14, x30, lsl #1]
100021c90: 9100056b    	add	x11, x11, #0x1
100021c94: b840152c    	ldr	w12, [x9], #0x1
100021c98: 12005d8d    	and	w13, w12, #0xffffff
100021c9c: 1b0f7dad    	mul	w13, w13, w15
100021ca0: 53117da5    	lsr	w5, w13, #17
100021ca4: 1b0f7d8c    	mul	w12, w12, w15
100021ca8: 53107d9e    	lsr	w30, w12, #16
100021cac: 9100094a    	add	x10, x10, #0x2
100021cb0: f1000508    	subs	x8, x8, #0x1
100021cb4: 54fffe41    	b.ne	0x100021c7c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x39e4>
100021cb8: aa1003ec    	mov	x12, x16
100021cbc: 17ffff7a    	b	0x100021aa4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x380c>
100021cc0: 8b0d018e    	add	x14, x12, x13
100021cc4: 17ffffc7    	b	0x100021be0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3948>
100021cc8: 52808088    	mov	w8, #0x404              ; =1028
100021ccc: 17fffede    	b	0x100021844 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x35ac>
100021cd0: d280000a    	mov	x10, #0x0               ; =0
100021cd4: 17fffee7    	b	0x100021870 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x35d8>
100021cd8: aa0c03f5    	mov	x21, x12
100021cdc: f90183e4    	str	x4, [sp, #0x300]
100021ce0: f94123e8    	ldr	x8, [sp, #0x240]
100021ce4: f940b3ea    	ldr	x10, [sp, #0x160]
100021ce8: aa0503ef    	mov	x15, x5
100021cec: aa1e03f4    	mov	x20, x30
100021cf0: aa0103ec    	mov	x12, x1
100021cf4: aa1103eb    	mov	x11, x17
100021cf8: eb08015f    	cmp	x10, x8
100021cfc: 54000280    	b.eq	0x100021d4c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3ab4>
100021d00: f94133e0    	ldr	x0, [sp, #0x260]
100021d04: f94123f8    	ldr	x24, [sp, #0x240]
100021d08: aa1803e1    	mov	x1, x24
100021d0c: f940e3e2    	ldr	x2, [sp, #0x1c0]
100021d10: 940039c8    	bl	0x100030430 <_roc_cold_shim.roc_builtins_list_slack_unique>
100021d14: f90173f8    	str	x24, [sp, #0x2e0]
100021d18: 8b180008    	add	x8, x0, x24
100021d1c: f90123e8    	str	x8, [sp, #0x240]
100021d20: f9419fe7    	ldr	x7, [sp, #0x338]
100021d24: f941a3fc    	ldr	x28, [sp, #0x340]
100021d28: aa0b03f1    	mov	x17, x11
100021d2c: aa0c03e1    	mov	x1, x12
100021d30: f94183e4    	ldr	x4, [sp, #0x300]
100021d34: aa1403fe    	mov	x30, x20
100021d38: aa0f03e5    	mov	x5, x15
100021d3c: aa1503ec    	mov	x12, x21
100021d40: f94197f5    	ldr	x21, [sp, #0x328]
100021d44: f941abe3    	ldr	x3, [sp, #0x350]
100021d48: 17fffede    	b	0x1000218c0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3628>
100021d4c: f940e3e8    	ldr	x8, [sp, #0x1c0]
100021d50: 370001e8    	tbnz	w8, #0x0, 0x100021d8c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3af4>
100021d54: f940e3e8    	ldr	x8, [sp, #0x1c0]
100021d58: d341fd08    	lsr	x8, x8, #1
100021d5c: f940b3f0    	ldr	x16, [sp, #0x160]
100021d60: eb10011f    	cmp	x8, x16
100021d64: 54000140    	b.eq	0x100021d8c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3af4>
100021d68: f94133e0    	ldr	x0, [sp, #0x260]
100021d6c: f940b3fc    	ldr	x28, [sp, #0x160]
100021d70: aa1c03e1    	mov	x1, x28
100021d74: f940e3e2    	ldr	x2, [sp, #0x1c0]
100021d78: 940039ae    	bl	0x100030430 <_roc_cold_shim.roc_builtins_list_slack_unique>
100021d7c: f90123fc    	str	x28, [sp, #0x240]
100021d80: 8b1c0008    	add	x8, x0, x28
100021d84: f900b3e8    	str	x8, [sp, #0x160]
100021d88: 17ffffde    	b	0x100021d00 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3a68>
100021d8c: f94133e0    	ldr	x0, [sp, #0x260]
100021d90: f940b3e1    	ldr	x1, [sp, #0x160]
100021d94: f940e3e2    	ldr	x2, [sp, #0x1c0]
100021d98: 52800023    	mov	w3, #0x1                ; =1
100021d9c: 52800104    	mov	w4, #0x8                ; =8
100021da0: 52800025    	mov	w5, #0x1                ; =1
100021da4: 9400394d    	bl	0x1000302d8 <_roc_cold_shim.roc_builtins_list_reserve_for_append>
100021da8: f90133e0    	str	x0, [sp, #0x260]
100021dac: f900b3e1    	str	x1, [sp, #0x160]
100021db0: f900e3e2    	str	x2, [sp, #0x1c0]
100021db4: 17ffffed    	b	0x100021d68 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3ad0>
100021db8: a95e27ea    	ldp	x10, x9, [sp, #0x1e0]
100021dbc: b9400129    	ldr	w9, [x9]
100021dc0: b40017ea    	cbz	x10, 0x1000220bc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3e24>
100021dc4: aa0103e2    	mov	x2, x1
100021dc8: aa1103e1    	mov	x1, x17
100021dcc: 9bd97d2a    	umulh	x10, x9, x25
100021dd0: eb0a03ff    	cmp	xzr, x10
100021dd4: 5280190f    	mov	w15, #0xc8              ; =200
100021dd8: f940d7f1    	ldr	x17, [sp, #0x1a8]
100021ddc: f940f3e0    	ldr	x0, [sp, #0x1e0]
100021de0: 54024101    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100021de4: f9410fea    	ldr	x10, [sp, #0x218]
100021de8: b9480d4a    	ldr	w10, [x10, #0x80c]
100021dec: 9bc07d4b    	umulh	x11, x10, x0
100021df0: eb0b03ff    	cmp	xzr, x11
100021df4: 54024061    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100021df8: aa0c03f0    	mov	x16, x12
100021dfc: 9b197d2b    	mul	x11, x9, x25
100021e00: 9b007d4c    	mul	x12, x10, x0
100021e04: eb0b018b    	subs	x11, x12, x11
100021e08: da8b856b    	cneg	x11, x11, ls
100021e0c: b9400e2c    	ldr	w12, [x17, #0xc]
100021e10: 9bd97d8d    	umulh	x13, x12, x25
100021e14: eb0d03ff    	cmp	xzr, x13
100021e18: 54023f41    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100021e1c: f9410fed    	ldr	x13, [sp, #0x218]
100021e20: b94811ad    	ldr	w13, [x13, #0x810]
100021e24: 9bc07dae    	umulh	x14, x13, x0
100021e28: eb0e03ff    	cmp	xzr, x14
100021e2c: 54023ea1    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100021e30: 9b197d8c    	mul	x12, x12, x25
100021e34: 9b007dad    	mul	x13, x13, x0
100021e38: eb0c01ac    	subs	x12, x13, x12
100021e3c: da8c858c    	cneg	x12, x12, ls
100021e40: ab0c016b    	adds	x11, x11, x12
100021e44: 54044522    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100021e48: b940122c    	ldr	w12, [x17, #0x10]
100021e4c: 9bd97d8d    	umulh	x13, x12, x25
100021e50: eb0d03ff    	cmp	xzr, x13
100021e54: 54023d61    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100021e58: f9410fed    	ldr	x13, [sp, #0x218]
100021e5c: b94815ad    	ldr	w13, [x13, #0x814]
100021e60: 9bc07dae    	umulh	x14, x13, x0
100021e64: eb0e03ff    	cmp	xzr, x14
100021e68: 54023cc1    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100021e6c: 9b197d8c    	mul	x12, x12, x25
100021e70: 9b007dad    	mul	x13, x13, x0
100021e74: eb0c01ac    	subs	x12, x13, x12
100021e78: da8c858c    	cneg	x12, x12, ls
100021e7c: ab0c016b    	adds	x11, x11, x12
100021e80: 54044342    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100021e84: b940162c    	ldr	w12, [x17, #0x14]
100021e88: 9bd97d8d    	umulh	x13, x12, x25
100021e8c: eb0d03ff    	cmp	xzr, x13
100021e90: 54023b81    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100021e94: f9410fed    	ldr	x13, [sp, #0x218]
100021e98: b94819ad    	ldr	w13, [x13, #0x818]
100021e9c: 9bc07dae    	umulh	x14, x13, x0
100021ea0: eb0e03ff    	cmp	xzr, x14
100021ea4: 54023ae1    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100021ea8: 9b197d8c    	mul	x12, x12, x25
100021eac: 9b007dad    	mul	x13, x13, x0
100021eb0: eb0c01ac    	subs	x12, x13, x12
100021eb4: da8c858c    	cneg	x12, x12, ls
100021eb8: ab0c016b    	adds	x11, x11, x12
100021ebc: 54044162    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100021ec0: b9401a2c    	ldr	w12, [x17, #0x18]
100021ec4: 9bd97d8d    	umulh	x13, x12, x25
100021ec8: eb0d03ff    	cmp	xzr, x13
100021ecc: 540239a1    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100021ed0: f9410fed    	ldr	x13, [sp, #0x218]
100021ed4: b9481dad    	ldr	w13, [x13, #0x81c]
100021ed8: 9bc07dae    	umulh	x14, x13, x0
100021edc: eb0e03ff    	cmp	xzr, x14
100021ee0: 54023901    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100021ee4: 9b197d8c    	mul	x12, x12, x25
100021ee8: 9b007dad    	mul	x13, x13, x0
100021eec: eb0c01ac    	subs	x12, x13, x12
100021ef0: da8c858c    	cneg	x12, x12, ls
100021ef4: ab0c016b    	adds	x11, x11, x12
100021ef8: 54043f82    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100021efc: b9401e2c    	ldr	w12, [x17, #0x1c]
100021f00: 9bd97d8d    	umulh	x13, x12, x25
100021f04: eb0d03ff    	cmp	xzr, x13
100021f08: 540237c1    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100021f0c: f9410fed    	ldr	x13, [sp, #0x218]
100021f10: b94821ad    	ldr	w13, [x13, #0x820]
100021f14: 9bc07dae    	umulh	x14, x13, x0
100021f18: eb0e03ff    	cmp	xzr, x14
100021f1c: 54023721    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100021f20: 9b197d8c    	mul	x12, x12, x25
100021f24: 9b007dad    	mul	x13, x13, x0
100021f28: eb0c01ac    	subs	x12, x13, x12
100021f2c: da8c858c    	cneg	x12, x12, ls
100021f30: ab0c016b    	adds	x11, x11, x12
100021f34: 54043da2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100021f38: b940222c    	ldr	w12, [x17, #0x20]
100021f3c: 9bd97d8d    	umulh	x13, x12, x25
100021f40: eb0d03ff    	cmp	xzr, x13
100021f44: 540235e1    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100021f48: f9410fed    	ldr	x13, [sp, #0x218]
100021f4c: b94825ad    	ldr	w13, [x13, #0x824]
100021f50: 9bc07dae    	umulh	x14, x13, x0
100021f54: eb0e03ff    	cmp	xzr, x14
100021f58: 54023541    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100021f5c: 9b197d8c    	mul	x12, x12, x25
100021f60: 9b007dad    	mul	x13, x13, x0
100021f64: eb0c01ac    	subs	x12, x13, x12
100021f68: da8c858c    	cneg	x12, x12, ls
100021f6c: ab0c016b    	adds	x11, x11, x12
100021f70: 54043bc2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100021f74: b940262c    	ldr	w12, [x17, #0x24]
100021f78: 9bd97d8d    	umulh	x13, x12, x25
100021f7c: eb0d03ff    	cmp	xzr, x13
100021f80: 54023401    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100021f84: f9410fed    	ldr	x13, [sp, #0x218]
100021f88: b94829ad    	ldr	w13, [x13, #0x828]
100021f8c: 9bc07dae    	umulh	x14, x13, x0
100021f90: eb0e03ff    	cmp	xzr, x14
100021f94: 54023361    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100021f98: 9b197d8c    	mul	x12, x12, x25
100021f9c: 9b007dad    	mul	x13, x13, x0
100021fa0: eb0c01ac    	subs	x12, x13, x12
100021fa4: da8c858c    	cneg	x12, x12, ls
100021fa8: ab0c016b    	adds	x11, x11, x12
100021fac: 540439e2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100021fb0: b9402a2c    	ldr	w12, [x17, #0x28]
100021fb4: 9bd97d8d    	umulh	x13, x12, x25
100021fb8: eb0d03ff    	cmp	xzr, x13
100021fbc: 54023221    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100021fc0: f9410fed    	ldr	x13, [sp, #0x218]
100021fc4: b9482dad    	ldr	w13, [x13, #0x82c]
100021fc8: 9bc07dae    	umulh	x14, x13, x0
100021fcc: eb0e03ff    	cmp	xzr, x14
100021fd0: 54023181    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100021fd4: 9b197d8c    	mul	x12, x12, x25
100021fd8: 9b007dad    	mul	x13, x13, x0
100021fdc: eb0c01ac    	subs	x12, x13, x12
100021fe0: da8c858c    	cneg	x12, x12, ls
100021fe4: ab0c016b    	adds	x11, x11, x12
100021fe8: 54043802    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100021fec: b9402e2c    	ldr	w12, [x17, #0x2c]
100021ff0: 9bd97d8d    	umulh	x13, x12, x25
100021ff4: eb0d03ff    	cmp	xzr, x13
100021ff8: 54023041    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100021ffc: f9410fed    	ldr	x13, [sp, #0x218]
100022000: b94831ad    	ldr	w13, [x13, #0x830]
100022004: 9bc07dae    	umulh	x14, x13, x0
100022008: eb0e03ff    	cmp	xzr, x14
10002200c: 54022fa1    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100022010: 9b197d8c    	mul	x12, x12, x25
100022014: 9b007dad    	mul	x13, x13, x0
100022018: eb0c01ac    	subs	x12, x13, x12
10002201c: da8c858c    	cneg	x12, x12, ls
100022020: ab0c016b    	adds	x11, x11, x12
100022024: 54043622    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100022028: ab19000d    	adds	x13, x0, x25
10002202c: 540435e2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100022030: 9bcf7f2c    	umulh	x12, x25, x15
100022034: eb0c03ff    	cmp	xzr, x12
100022038: 54022e41    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
10002203c: 9b0f7f2c    	mul	x12, x25, x15
100022040: d349fd8c    	lsr	x12, x12, #9
100022044: 9bc07d8e    	umulh	x14, x12, x0
100022048: eb0e03ff    	cmp	xzr, x14
10002204c: 54022da1    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100022050: aa0103f1    	mov	x17, x1
100022054: aa0203e1    	mov	x1, x2
100022058: 9b007d8c    	mul	x12, x12, x0
10002205c: d344fd0e    	lsr	x14, x8, #4
100022060: f109c1df    	cmp	x14, #0x270
100022064: 54000168    	b.hi	0x100022090 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3df8>
100022068: d34dfdae    	lsr	x14, x13, #13
10002206c: b500012e    	cbnz	x14, 0x100022090 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3df8>
100022070: 5284000e    	mov	w14, #0x2000            ; =8192
100022074: cb0d01cd    	sub	x13, x14, x13
100022078: 9bcd7d8e    	umulh	x14, x12, x13
10002207c: eb0e03ff    	cmp	xzr, x14
100022080: 54022c01    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100022084: 9b0d7d8d    	mul	x13, x12, x13
100022088: ab4d358c    	adds	x12, x12, x13, lsr #13
10002208c: 540432e2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100022090: d34cfd08    	lsr	x8, x8, #12
100022094: 9bc07d0d    	umulh	x13, x8, x0
100022098: eb0d03ff    	cmp	xzr, x13
10002209c: 54022b21    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
1000220a0: 9b007d08    	mul	x8, x8, x0
1000220a4: ab080168    	adds	x8, x11, x8
1000220a8: 54043202    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000220ac: eb0c011f    	cmp	x8, x12
1000220b0: aa1003ec    	mov	x12, x16
1000220b4: 54000083    	b.lo	0x1000220c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3e2c>
1000220b8: 14000045    	b	0x1000221cc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3f34>
1000220bc: f9410fe8    	ldr	x8, [sp, #0x218]
1000220c0: b9480d0a    	ldr	w10, [x8, #0x80c]
1000220c4: 2b0a0128    	adds	w8, w9, w10
1000220c8: f9410fea    	ldr	x10, [sp, #0x218]
1000220cc: f940d7eb    	ldr	x11, [sp, #0x1a8]
1000220d0: 540430c2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000220d4: b9000968    	str	w8, [x11, #0x8]
1000220d8: b9080d5f    	str	wzr, [x10, #0x80c]
1000220dc: b9400d68    	ldr	w8, [x11, #0xc]
1000220e0: b9481149    	ldr	w9, [x10, #0x810]
1000220e4: 2b090108    	adds	w8, w8, w9
1000220e8: 54043002    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000220ec: b9000d68    	str	w8, [x11, #0xc]
1000220f0: b908115f    	str	wzr, [x10, #0x810]
1000220f4: b9401168    	ldr	w8, [x11, #0x10]
1000220f8: b9481549    	ldr	w9, [x10, #0x814]
1000220fc: 2b090108    	adds	w8, w8, w9
100022100: 54042f42    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100022104: b9001168    	str	w8, [x11, #0x10]
100022108: b908155f    	str	wzr, [x10, #0x814]
10002210c: b9401568    	ldr	w8, [x11, #0x14]
100022110: b9481949    	ldr	w9, [x10, #0x818]
100022114: 2b090108    	adds	w8, w8, w9
100022118: 54042e82    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10002211c: b9001568    	str	w8, [x11, #0x14]
100022120: b908195f    	str	wzr, [x10, #0x818]
100022124: b9401968    	ldr	w8, [x11, #0x18]
100022128: b9481d49    	ldr	w9, [x10, #0x81c]
10002212c: 2b090108    	adds	w8, w8, w9
100022130: 54042dc2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100022134: b9001968    	str	w8, [x11, #0x18]
100022138: b9081d5f    	str	wzr, [x10, #0x81c]
10002213c: b9401d68    	ldr	w8, [x11, #0x1c]
100022140: b9482149    	ldr	w9, [x10, #0x820]
100022144: 2b090108    	adds	w8, w8, w9
100022148: 54042d02    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10002214c: b9001d68    	str	w8, [x11, #0x1c]
100022150: b908215f    	str	wzr, [x10, #0x820]
100022154: b9402168    	ldr	w8, [x11, #0x20]
100022158: b9482549    	ldr	w9, [x10, #0x824]
10002215c: 2b090108    	adds	w8, w8, w9
100022160: 54042c42    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100022164: b9002168    	str	w8, [x11, #0x20]
100022168: b908255f    	str	wzr, [x10, #0x824]
10002216c: b9402568    	ldr	w8, [x11, #0x24]
100022170: b9482949    	ldr	w9, [x10, #0x828]
100022174: 2b090108    	adds	w8, w8, w9
100022178: 54042b82    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10002217c: b9002568    	str	w8, [x11, #0x24]
100022180: b908295f    	str	wzr, [x10, #0x828]
100022184: b9402968    	ldr	w8, [x11, #0x28]
100022188: b9482d49    	ldr	w9, [x10, #0x82c]
10002218c: 2b090108    	adds	w8, w8, w9
100022190: 54042ac2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100022194: b9002968    	str	w8, [x11, #0x28]
100022198: b9082d5f    	str	wzr, [x10, #0x82c]
10002219c: b9402d68    	ldr	w8, [x11, #0x2c]
1000221a0: b9483149    	ldr	w9, [x10, #0x830]
1000221a4: 2b090108    	adds	w8, w8, w9
1000221a8: 54042a02    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000221ac: b9002d68    	str	w8, [x11, #0x2c]
1000221b0: b908315f    	str	wzr, [x10, #0x830]
1000221b4: f940f3e8    	ldr	x8, [sp, #0x1e0]
1000221b8: ab190108    	adds	x8, x8, x25
1000221bc: f900f3e8    	str	x8, [sp, #0x1e0]
1000221c0: 54042942    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000221c4: f941b3ea    	ldr	x10, [sp, #0x360]
1000221c8: 17fffa51    	b	0x100020b0c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2874>
1000221cc: f9018fec    	str	x12, [sp, #0x318]
1000221d0: f9014fe5    	str	x5, [sp, #0x298]
1000221d4: f90153fe    	str	x30, [sp, #0x2a0]
1000221d8: f90183e4    	str	x4, [sp, #0x300]
1000221dc: f9018bf8    	str	x24, [sp, #0x310]
1000221e0: aa0103fc    	mov	x28, x1
1000221e4: aa1103f8    	mov	x24, x17
1000221e8: f940f7e8    	ldr	x8, [sp, #0x1e8]
1000221ec: f90ec3e8    	str	x8, [sp, #0x1d80]
1000221f0: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000221f4: 91360108    	add	x8, x8, #0xd80
1000221f8: 3dc063e0    	ldr	q0, [sp, #0x180]
1000221fc: 3c808100    	stur	q0, [x8, #0x8]
100022200: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100022204: 91360000    	add	x0, x0, #0xd80
100022208: 940037ee    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002220c: f94173e8    	ldr	x8, [sp, #0x2e0]
100022210: f94123e9    	ldr	x9, [sp, #0x240]
100022214: eb08013f    	cmp	x9, x8
100022218: 540026a0    	b.eq	0x1000226ec <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4454>
10002221c: 2a1b03e8    	mov	w8, w27
100022220: f94133e9    	ldr	x9, [sp, #0x260]
100022224: f94173ea    	ldr	x10, [sp, #0x2e0]
100022228: f82a7928    	str	x8, [x9, x10, lsl #3]
10002222c: f9410fe9    	ldr	x9, [sp, #0x218]
100022230: b9440928    	ldr	w8, [x9, #0x408]
100022234: 31000508    	adds	w8, w8, #0x1
100022238: 54042582    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10002223c: b9040928    	str	w8, [x9, #0x408]
100022240: f90eebff    	str	xzr, [sp, #0x1dd0]
100022244: f90ee7ff    	str	xzr, [sp, #0x1dc8]
100022248: f90eefff    	str	xzr, [sp, #0x1dd8]
10002224c: 912683e0    	add	x0, sp, #0x9a0
100022250: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
100022254: 91372021    	add	x1, x1, #0xdc8
100022258: 52802902    	mov	w2, #0x148              ; =328
10002225c: 52800023    	mov	w3, #0x1                ; =1
100022260: 52800024    	mov	w4, #0x1                ; =1
100022264: 94003df9    	bl	0x100031a48 <_list.RocList.reallocate>
100022268: f944d3e8    	ldr	x8, [sp, #0x9a0]
10002226c: f944dbe9    	ldr	x9, [sp, #0x9b0]
100022270: 3900011f    	strb	wzr, [x8]
100022274: f904d3e8    	str	x8, [sp, #0x9a0]
100022278: 52800034    	mov	w20, #0x1               ; =1
10002227c: f904d7f4    	str	x20, [sp, #0x9a8]
100022280: f904dbe9    	str	x9, [sp, #0x9b0]
100022284: 3dc26be0    	ldr	q0, [sp, #0x9a0]
100022288: f9000be9    	str	x9, [sp, #0x10]
10002228c: 3d8003e0    	str	q0, [sp]
100022290: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100022294: 9122e000    	add	x0, x0, #0x8b8
100022298: d2800001    	mov	x1, #0x0                ; =0
10002229c: 528023e2    	mov	w2, #0x11f              ; =287
1000222a0: 52800023    	mov	w3, #0x1                ; =1
1000222a4: 94003fb8    	bl	0x100032184 <_list.listAppendRangeWithinUnsafe>
1000222a8: f90eebff    	str	xzr, [sp, #0x1dd0]
1000222ac: f90ee7ff    	str	xzr, [sp, #0x1dc8]
1000222b0: f90eefff    	str	xzr, [sp, #0x1dd8]
1000222b4: 912683e0    	add	x0, sp, #0x9a0
1000222b8: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
1000222bc: 91372021    	add	x1, x1, #0xdc8
1000222c0: 52802542    	mov	w2, #0x12a              ; =298
1000222c4: 52800083    	mov	w3, #0x4                ; =4
1000222c8: 52800024    	mov	w4, #0x1                ; =1
1000222cc: 94003ddf    	bl	0x100031a48 <_list.RocList.reallocate>
1000222d0: f944d3e8    	ldr	x8, [sp, #0x9a0]
1000222d4: f944dbe9    	ldr	x9, [sp, #0x9b0]
1000222d8: b900011f    	str	wzr, [x8]
1000222dc: f904d3e8    	str	x8, [sp, #0x9a0]
1000222e0: f904d7f4    	str	x20, [sp, #0x9a8]
1000222e4: f904dbe9    	str	x9, [sp, #0x9b0]
1000222e8: 3dc26be0    	ldr	q0, [sp, #0x9a0]
1000222ec: f9000be9    	str	x9, [sp, #0x10]
1000222f0: 3d8003e0    	str	q0, [sp]
1000222f4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000222f8: 91372000    	add	x0, x0, #0xdc8
1000222fc: d2800001    	mov	x1, #0x0                ; =0
100022300: 528023e2    	mov	w2, #0x11f              ; =287
100022304: 52800083    	mov	w3, #0x4                ; =4
100022308: 94003f9f    	bl	0x100032184 <_list.listAppendRangeWithinUnsafe>
10002230c: f904d3f5    	str	x21, [sp, #0x9a0]
100022310: 912683f3    	add	x19, sp, #0x9a0
100022314: 3dc083e0    	ldr	q0, [sp, #0x200]
100022318: 3c808260    	stur	q0, [x19, #0x8]
10002231c: 912563e0    	add	x0, sp, #0x958
100022320: 912683e3    	add	x3, sp, #0x9a0
100022324: 914007e4    	add	x4, sp, #0x1, lsl #12   ; =0x1000
100022328: 9122e084    	add	x4, x4, #0x8b8
10002232c: 914007e5    	add	x5, sp, #0x1, lsl #12   ; =0x1000
100022330: 913720a5    	add	x5, x5, #0xdc8
100022334: 52802401    	mov	w1, #0x120              ; =288
100022338: 528001c2    	mov	w2, #0xe                ; =14
10002233c: 94003103    	bl	0x10002e748 <_roc__p1a804bfda1f5e4235a696be5d06bcb43.fast>
100022340: f90eebff    	str	xzr, [sp, #0x1dd0]
100022344: f90ee7ff    	str	xzr, [sp, #0x1dc8]
100022348: f90eefff    	str	xzr, [sp, #0x1dd8]
10002234c: 912683e0    	add	x0, sp, #0x9a0
100022350: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
100022354: 91372021    	add	x1, x1, #0xdc8
100022358: 52800902    	mov	w2, #0x48               ; =72
10002235c: 52800023    	mov	w3, #0x1                ; =1
100022360: 52800024    	mov	w4, #0x1                ; =1
100022364: 94003db9    	bl	0x100031a48 <_list.RocList.reallocate>
100022368: f944d3e8    	ldr	x8, [sp, #0x9a0]
10002236c: f944dbe9    	ldr	x9, [sp, #0x9b0]
100022370: 3900011f    	strb	wzr, [x8]
100022374: f904d3e8    	str	x8, [sp, #0x9a0]
100022378: f904d7f4    	str	x20, [sp, #0x9a8]
10002237c: f904dbe9    	str	x9, [sp, #0x9b0]
100022380: 3dc26be0    	ldr	q0, [sp, #0x9a0]
100022384: f9000be9    	str	x9, [sp, #0x10]
100022388: 3d8003e0    	str	q0, [sp]
10002238c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100022390: 9122e000    	add	x0, x0, #0x8b8
100022394: d2800001    	mov	x1, #0x0                ; =0
100022398: 528003e2    	mov	w2, #0x1f               ; =31
10002239c: 52800023    	mov	w3, #0x1                ; =1
1000223a0: 94003f79    	bl	0x100032184 <_list.listAppendRangeWithinUnsafe>
1000223a4: f90eebff    	str	xzr, [sp, #0x1dd0]
1000223a8: f90ee7ff    	str	xzr, [sp, #0x1dc8]
1000223ac: f90eefff    	str	xzr, [sp, #0x1dd8]
1000223b0: 912683e0    	add	x0, sp, #0x9a0
1000223b4: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
1000223b8: 91372021    	add	x1, x1, #0xdc8
1000223bc: 52800542    	mov	w2, #0x2a               ; =42
1000223c0: 52800083    	mov	w3, #0x4                ; =4
1000223c4: 52800024    	mov	w4, #0x1                ; =1
1000223c8: 94003da0    	bl	0x100031a48 <_list.RocList.reallocate>
1000223cc: f944d3e8    	ldr	x8, [sp, #0x9a0]
1000223d0: f944dbe9    	ldr	x9, [sp, #0x9b0]
1000223d4: b900011f    	str	wzr, [x8]
1000223d8: f904d3e8    	str	x8, [sp, #0x9a0]
1000223dc: f904d7f4    	str	x20, [sp, #0x9a8]
1000223e0: f904dbe9    	str	x9, [sp, #0x9b0]
1000223e4: 3dc26be0    	ldr	q0, [sp, #0x9a0]
1000223e8: f9000be9    	str	x9, [sp, #0x10]
1000223ec: 3d8003e0    	str	q0, [sp]
1000223f0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000223f4: 91372000    	add	x0, x0, #0xdc8
1000223f8: d2800001    	mov	x1, #0x0                ; =0
1000223fc: 528003e2    	mov	w2, #0x1f               ; =31
100022400: 52800083    	mov	w3, #0x4                ; =4
100022404: 94003f60    	bl	0x100032184 <_list.listAppendRangeWithinUnsafe>
100022408: f9412bf4    	ldr	x20, [sp, #0x250]
10002240c: f904d3f4    	str	x20, [sp, #0x9a0]
100022410: 3dc07fe0    	ldr	q0, [sp, #0x1f0]
100022414: 3c808260    	stur	q0, [x19, #0x8]
100022418: 9124a3e0    	add	x0, sp, #0x928
10002241c: 912683e3    	add	x3, sp, #0x9a0
100022420: 914007e4    	add	x4, sp, #0x1, lsl #12   ; =0x1000
100022424: 9122e084    	add	x4, x4, #0x8b8
100022428: 914007e5    	add	x5, sp, #0x1, lsl #12   ; =0x1000
10002242c: 913720a5    	add	x5, x5, #0xdc8
100022430: 52800401    	mov	w1, #0x20               ; =32
100022434: 528001e2    	mov	w2, #0xf                ; =15
100022438: 940030c4    	bl	0x10002e748 <_roc__p1a804bfda1f5e4235a696be5d06bcb43.fast>
10002243c: f9419be5    	ldr	x5, [sp, #0x330]
100022440: eb050346    	subs	x6, x26, x5
100022444: f9414bea    	ldr	x10, [sp, #0x290]
100022448: 540415a3    	b.lo	0x10002a6fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc464>
10002244c: f94173e8    	ldr	x8, [sp, #0x2e0]
100022450: 91000508    	add	x8, x8, #0x1
100022454: f941a3ec    	ldr	x12, [sp, #0x340]
100022458: eb1a019f    	cmp	x12, x26
10002245c: 1a9f17e9    	cset	w9, eq
100022460: f904d7ff    	str	xzr, [sp, #0x9a8]
100022464: f904d3ff    	str	xzr, [sp, #0x9a0]
100022468: f904dbff    	str	xzr, [sp, #0x9b0]
10002246c: f94143eb    	ldr	x11, [sp, #0x280]
100022470: f90c0beb    	str	x11, [sp, #0x1810]
100022474: f9417feb    	ldr	x11, [sp, #0x2f8]
100022478: f90c0feb    	str	x11, [sp, #0x1818]
10002247c: f90c13ea    	str	x10, [sp, #0x1820]
100022480: f9419fea    	ldr	x10, [sp, #0x338]
100022484: f90c17ea    	str	x10, [sp, #0x1828]
100022488: f90c1bec    	str	x12, [sp, #0x1830]
10002248c: f9413fea    	ldr	x10, [sp, #0x278]
100022490: f90c1fea    	str	x10, [sp, #0x1838]
100022494: f94133ea    	ldr	x10, [sp, #0x260]
100022498: f90c23ea    	str	x10, [sp, #0x1840]
10002249c: f90c27e8    	str	x8, [sp, #0x1848]
1000224a0: f940e3e8    	ldr	x8, [sp, #0x1c0]
1000224a4: f90c2be8    	str	x8, [sp, #0x1850]
1000224a8: f90c5ff5    	str	x21, [sp, #0x18b8]
1000224ac: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000224b0: 9122e108    	add	x8, x8, #0x8b8
1000224b4: ad4f87e0    	ldp	q0, q1, [sp, #0x1f0]
1000224b8: 3c808101    	stur	q1, [x8, #0x8]
1000224bc: f90ee7f4    	str	x20, [sp, #0x1dc8]
1000224c0: 914007f3    	add	x19, sp, #0x1, lsl #12  ; =0x1000
1000224c4: 91360273    	add	x19, x19, #0xd80
1000224c8: 3c850260    	stur	q0, [x19, #0x50]
1000224cc: a905a7ff    	stp	xzr, x9, [sp, #0x58]
1000224d0: 912683e8    	add	x8, sp, #0x9a0
1000224d4: f9002be8    	str	x8, [sp, #0x50]
1000224d8: 911fc3e8    	add	x8, sp, #0x7f0
1000224dc: f90027e8    	str	x8, [sp, #0x48]
1000224e0: 911f43e8    	add	x8, sp, #0x7d0
1000224e4: f90023e8    	str	x8, [sp, #0x40]
1000224e8: 911ec3e8    	add	x8, sp, #0x7b0
1000224ec: f9001fe8    	str	x8, [sp, #0x38]
1000224f0: 911e43e8    	add	x8, sp, #0x790
1000224f4: f9001be8    	str	x8, [sp, #0x30]
1000224f8: 9124a3e8    	add	x8, sp, #0x928
1000224fc: f90017e8    	str	x8, [sp, #0x28]
100022500: f940b7e9    	ldr	x9, [sp, #0x168]
100022504: 912043e0    	add	x0, sp, #0x810
100022508: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
10002250c: 91204021    	add	x1, x1, #0x810
100022510: 914007e4    	add	x4, sp, #0x1, lsl #12   ; =0x1000
100022514: 9120a084    	add	x4, x4, #0x828
100022518: 914007e7    	add	x7, sp, #0x1, lsl #12   ; =0x1000
10002251c: 912100e7    	add	x7, x7, #0x840
100022520: 912563e8    	add	x8, sp, #0x958
100022524: a901a7e8    	stp	x8, x9, [sp, #0x18]
100022528: f940bbe9    	ldr	x9, [sp, #0x170]
10002252c: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
100022530: 91372108    	add	x8, x8, #0xdc8
100022534: a900a7e8    	stp	x8, x9, [sp, #0x8]
100022538: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
10002253c: 9122e108    	add	x8, x8, #0x8b8
100022540: f90003e8    	str	x8, [sp]
100022544: a95b0fe2    	ldp	x2, x3, [sp, #0x1b0]
100022548: 97ffcdf3    	bl	0x100015d14 <_roc__p81003bf97431a8821d5be871f2471565.fast>
10002254c: f90ec3f4    	str	x20, [sp, #0x1d80]
100022550: 3dc07fe0    	ldr	q0, [sp, #0x1f0]
100022554: 3c808260    	stur	q0, [x19, #0x8]
100022558: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002255c: 91360000    	add	x0, x0, #0xd80
100022560: 94003718    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100022564: f90ec3f5    	str	x21, [sp, #0x1d80]
100022568: 3dc083e0    	ldr	q0, [sp, #0x200]
10002256c: 3c808260    	stur	q0, [x19, #0x8]
100022570: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100022574: 91360000    	add	x0, x0, #0xd80
100022578: 94003712    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002257c: f9445ff3    	ldr	x19, [sp, #0x8b8]
100022580: f94463f5    	ldr	x21, [sp, #0x8c0]
100022584: f9444fe8    	ldr	x8, [sp, #0x898]
100022588: f90143e8    	str	x8, [sp, #0x280]
10002258c: f94453e8    	ldr	x8, [sp, #0x8a0]
100022590: f9017fe8    	str	x8, [sp, #0x2f8]
100022594: f9445be8    	ldr	x8, [sp, #0x8b0]
100022598: f90133e8    	str	x8, [sp, #0x260]
10002259c: f94457fb    	ldr	x27, [sp, #0x8a8]
1000225a0: f9440be9    	ldr	x9, [sp, #0x810]
1000225a4: f9440fe8    	ldr	x8, [sp, #0x818]
1000225a8: a91b23e9    	stp	x9, x8, [sp, #0x1b0]
1000225ac: 912043f4    	add	x20, sp, #0x810
1000225b0: 3cc10280    	ldur	q0, [x20, #0x10]
1000225b4: 3d8763e0    	str	q0, [sp, #0x1d80]
1000225b8: f8420288    	ldur	x8, [x20, #0x20]
1000225bc: f90ecbe8    	str	x8, [sp, #0x1d90]
1000225c0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000225c4: 91360000    	add	x0, x0, #0xd80
1000225c8: 940036fe    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000225cc: 3cc28280    	ldur	q0, [x20, #0x28]
1000225d0: 3d8763e0    	str	q0, [sp, #0x1d80]
1000225d4: f8438288    	ldur	x8, [x20, #0x38]
1000225d8: f90ecbe8    	str	x8, [sp, #0x1d90]
1000225dc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000225e0: 91360000    	add	x0, x0, #0xd80
1000225e4: 940036f7    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000225e8: 3cc40280    	ldur	q0, [x20, #0x40]
1000225ec: 3d8763e0    	str	q0, [sp, #0x1d80]
1000225f0: f8450288    	ldur	x8, [x20, #0x50]
1000225f4: f90ecbe8    	str	x8, [sp, #0x1d90]
1000225f8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000225fc: 91360000    	add	x0, x0, #0xd80
100022600: 940036f0    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100022604: 3cc58280    	ldur	q0, [x20, #0x58]
100022608: 3d8763e0    	str	q0, [sp, #0x1d80]
10002260c: f8468288    	ldur	x8, [x20, #0x68]
100022610: f90ecbe8    	str	x8, [sp, #0x1d90]
100022614: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100022618: 91360000    	add	x0, x0, #0xd80
10002261c: 940036e9    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100022620: 3cc70280    	ldur	q0, [x20, #0x70]
100022624: 3d8763e0    	str	q0, [sp, #0x1d80]
100022628: f8480288    	ldur	x8, [x20, #0x80]
10002262c: f90ecbe8    	str	x8, [sp, #0x1d90]
100022630: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100022634: 91360000    	add	x0, x0, #0xd80
100022638: 940036e2    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002263c: 370001fb    	tbnz	w27, #0x0, 0x100022678 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x43e0>
100022640: aa1c03ea    	mov	x10, x28
100022644: f94183ec    	ldr	x12, [sp, #0x300]
100022648: f94153ed    	ldr	x13, [sp, #0x2a0]
10002264c: f9414fee    	ldr	x14, [sp, #0x298]
100022650: b40000bb    	cbz	x27, 0x100022664 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x43cc>
100022654: f94143e8    	ldr	x8, [sp, #0x280]
100022658: f85f8108    	ldur	x8, [x8, #-0x8]
10002265c: f100051f    	cmp	x8, #0x1
100022660: 540001a1    	b.ne	0x100022694 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x43fc>
100022664: d341ff68    	lsr	x8, x27, #1
100022668: f9417fe9    	ldr	x9, [sp, #0x2f8]
10002266c: eb09011f    	cmp	x8, x9
100022670: 1a9f17f4    	cset	w20, eq
100022674: 14000009    	b	0x100022698 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4400>
100022678: 52800034    	mov	w20, #0x1               ; =1
10002267c: f941a3eb    	ldr	x11, [sp, #0x340]
100022680: aa1c03ea    	mov	x10, x28
100022684: f94183ec    	ldr	x12, [sp, #0x300]
100022688: f94153ed    	ldr	x13, [sp, #0x2a0]
10002268c: f9414fee    	ldr	x14, [sp, #0x298]
100022690: 14000003    	b	0x10002269c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4404>
100022694: 52800034    	mov	w20, #0x1               ; =1
100022698: f941a3eb    	ldr	x11, [sp, #0x340]
10002269c: 912043e9    	add	x9, sp, #0x810
1000226a0: 3ccd0120    	ldur	q0, [x9, #0xd0]
1000226a4: 3d81e7e0    	str	q0, [sp, #0x790]
1000226a8: f84e0128    	ldur	x8, [x9, #0xe0]
1000226ac: f903d3e8    	str	x8, [sp, #0x7a0]
1000226b0: 3ccb8120    	ldur	q0, [x9, #0xb8]
1000226b4: 3d81efe0    	str	q0, [sp, #0x7b0]
1000226b8: f84c8128    	ldur	x8, [x9, #0xc8]
1000226bc: f903e3e8    	str	x8, [sp, #0x7c0]
1000226c0: 3dc04120    	ldr	q0, [x9, #0x100]
1000226c4: 3d81f7e0    	str	q0, [sp, #0x7d0]
1000226c8: f9408928    	ldr	x8, [x9, #0x110]
1000226cc: f903f3e8    	str	x8, [sp, #0x7e0]
1000226d0: f84f8128    	ldur	x8, [x9, #0xf8]
1000226d4: f90403e8    	str	x8, [sp, #0x800]
1000226d8: 3cce8120    	ldur	q0, [x9, #0xe8]
1000226dc: 3d81ffe0    	str	q0, [sp, #0x7f0]
1000226e0: eb1a017f    	cmp	x11, x26
1000226e4: 54fefc01    	b.ne	0x100020664 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x23cc>
1000226e8: 1400200a    	b	0x10002a710 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc478>
1000226ec: f94173e8    	ldr	x8, [sp, #0x2e0]
1000226f0: f940b3e9    	ldr	x9, [sp, #0x160]
1000226f4: eb08013f    	cmp	x9, x8
1000226f8: 540000e0    	b.eq	0x100022714 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x447c>
1000226fc: f94133e0    	ldr	x0, [sp, #0x260]
100022700: f94173e1    	ldr	x1, [sp, #0x2e0]
100022704: f940e3e2    	ldr	x2, [sp, #0x1c0]
100022708: 9400374a    	bl	0x100030430 <_roc_cold_shim.roc_builtins_list_slack_unique>
10002270c: f94197f5    	ldr	x21, [sp, #0x328]
100022710: 17fffec3    	b	0x10002221c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x3f84>
100022714: f940e3e8    	ldr	x8, [sp, #0x1c0]
100022718: 37000168    	tbnz	w8, #0x0, 0x100022744 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x44ac>
10002271c: f940e3e8    	ldr	x8, [sp, #0x1c0]
100022720: d341fd08    	lsr	x8, x8, #1
100022724: f94173e9    	ldr	x9, [sp, #0x2e0]
100022728: eb09011f    	cmp	x8, x9
10002272c: 540000c0    	b.eq	0x100022744 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x44ac>
100022730: f94133e0    	ldr	x0, [sp, #0x260]
100022734: f94173e1    	ldr	x1, [sp, #0x2e0]
100022738: f940e3e2    	ldr	x2, [sp, #0x1c0]
10002273c: 9400373d    	bl	0x100030430 <_roc_cold_shim.roc_builtins_list_slack_unique>
100022740: 17ffffef    	b	0x1000226fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4464>
100022744: f94133e0    	ldr	x0, [sp, #0x260]
100022748: f94173e1    	ldr	x1, [sp, #0x2e0]
10002274c: f940e3e2    	ldr	x2, [sp, #0x1c0]
100022750: 52800023    	mov	w3, #0x1                ; =1
100022754: 52800104    	mov	w4, #0x8                ; =8
100022758: 52800025    	mov	w5, #0x1                ; =1
10002275c: 940036df    	bl	0x1000302d8 <_roc_cold_shim.roc_builtins_list_reserve_for_append>
100022760: f90133e0    	str	x0, [sp, #0x260]
100022764: f90173e1    	str	x1, [sp, #0x2e0]
100022768: f900e3e2    	str	x2, [sp, #0x1c0]
10002276c: 17fffff1    	b	0x100022730 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4498>
100022770: 71002d1f    	cmp	w8, #0xb
100022774: 5284e208    	mov	w8, #0x2710             ; =10000
100022778: 52807d09    	mov	w9, #0x3e8              ; =1000
10002277c: 9a880128    	csel	x8, x9, x8, eq
100022780: f90093e8    	str	x8, [sp, #0x120]
100022784: 52800148    	mov	w8, #0xa                ; =10
100022788: 52800089    	mov	w9, #0x4                ; =4
10002278c: 9a880128    	csel	x8, x9, x8, eq
100022790: f9007fe8    	str	x8, [sp, #0xf8]
100022794: 52802588    	mov	w8, #0x12c              ; =300
100022798: 52800c89    	mov	w9, #0x64               ; =100
10002279c: 9a880128    	csel	x8, x9, x8, eq
1000227a0: f90197e8    	str	x8, [sp, #0x328]
1000227a4: 52800208    	mov	w8, #0x10               ; =16
1000227a8: 9a9f050a    	csinc	x10, x8, xzr, eq
1000227ac: 52802048    	mov	w8, #0x102              ; =258
1000227b0: 528012c9    	mov	w9, #0x96               ; =150
1000227b4: 9a88013a    	csel	x26, x9, x8, eq
1000227b8: f9016bea    	str	x10, [sp, #0x2d0]
1000227bc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000227c0: 91188000    	add	x0, x0, #0x620
1000227c4: 97ffdd62    	bl	0x100019d4c <_roc__pf8d88d29f38eeb441b6a5ad4fe5ffba5.fast>
1000227c8: 528270e8    	mov	w8, #0x1387             ; =4999
1000227cc: f941a3ea    	ldr	x10, [sp, #0x340]
1000227d0: 8b080148    	add	x8, x10, x8
1000227d4: d28b2969    	mov	x9, #0x594b             ; =22859
1000227d8: f2a710c9    	movk	x9, #0x3886, lsl #16
1000227dc: f2d8bac9    	movk	x9, #0xc5d6, lsl #32
1000227e0: f2e68da9    	movk	x9, #0x346d, lsl #48
1000227e4: 9bc97d08    	umulh	x8, x8, x9
1000227e8: d34afd08    	lsr	x8, x8, #10
1000227ec: f100051f    	cmp	x8, #0x1
1000227f0: 9a9f8508    	csinc	x8, x8, xzr, hi
1000227f4: 8b080908    	add	x8, x8, x8, lsl #2
1000227f8: 8b0a0103    	add	x3, x8, x10
1000227fc: 3600005b    	tbz	w27, #0x0, 0x100022804 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x456c>
100022800: 140027ac    	b	0x10002c6b0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe418>
100022804: d341ff68    	lsr	x8, x27, #1
100022808: cb190108    	sub	x8, x8, x25
10002280c: eb03011f    	cmp	x8, x3
100022810: 5404f503    	b.lo	0x10002c6b0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe418>
100022814: f9017ff9    	str	x25, [sp, #0x2f8]
100022818: 914007f7    	add	x23, sp, #0x1, lsl #12  ; =0x1000
10002281c: 911882f7    	add	x23, x23, #0x620
100022820: 52800509    	mov	w9, #0x28               ; =40
100022824: 72a00109    	movk	w9, #0x8, lsl #16
100022828: 52800508    	mov	w8, #0x28               ; =40
10002282c: 72a00108    	movk	w8, #0x8, lsl #16
100022830: f901b3e8    	str	x8, [sp, #0x360]
100022834: 91002120    	add	x0, x9, #0x8
100022838: 52800101    	mov	w1, #0x8                ; =8
10002283c: 97ff8011    	bl	0x100002880 <_roc_alloc>
100022840: aa0003e8    	mov	x8, x0
100022844: 78008d1f    	strh	wzr, [x8, #0x8]!
100022848: f90113e8    	str	x8, [sp, #0x220]
10002284c: f9400109    	ldr	x9, [x8]
100022850: aa0003e8    	mov	x8, x0
100022854: f800ad09    	str	x9, [x8, #0xa]!
100022858: 5280002a    	mov	w10, #0x1               ; =1
10002285c: f900000a    	str	x10, [x0]
100022860: f800c009    	stur	x9, [x0, #0xc]
100022864: f800e009    	stur	x9, [x0, #0xe]
100022868: f9000809    	str	x9, [x0, #0x10]
10002286c: 928002a9    	mov	x9, #-0x16              ; =-22
100022870: 321b37ea    	mov	w10, #0x7ffe0           ; =524256
100022874: f940010b    	ldr	x11, [x8]
100022878: f8028d0b    	str	x11, [x8, #0x28]!
10002287c: a93e2d0b    	stp	x11, x11, [x8, #-0x20]
100022880: a93f2d0b    	stp	x11, x11, [x8, #-0x10]
100022884: 9100a129    	add	x9, x9, #0x28
100022888: eb0a013f    	cmp	x9, x10
10002288c: 54ffff43    	b.lo	0x100022874 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x45dc>
100022890: f9014bfb    	str	x27, [sp, #0x290]
100022894: 5292ac93    	mov	w19, #0x9564            ; =38244
100022898: 72a00b73    	movk	w19, #0x5b, lsl #16
10002289c: 91014260    	add	x0, x19, #0x50
1000228a0: 52800101    	mov	w1, #0x8                ; =8
1000228a4: 97ff7ff7    	bl	0x100002880 <_roc_alloc>
1000228a8: aa0003e9    	mov	x9, x0
1000228ac: b8008d3f    	str	wzr, [x9, #0x8]!
1000228b0: 52800028    	mov	w8, #0x1                ; =1
1000228b4: f9000008    	str	x8, [x0]
1000228b8: f901afe9    	str	x9, [sp, #0x358]
1000228bc: f9400129    	ldr	x9, [x9]
1000228c0: aa0003e8    	mov	x8, x0
1000228c4: f800cd09    	str	x9, [x8, #0xc]!
1000228c8: f9000809    	str	x9, [x0, #0x10]
1000228cc: 92800269    	mov	x9, #-0x14              ; =-20
1000228d0: f940010a    	ldr	x10, [x8]
1000228d4: f8028d0a    	str	x10, [x8, #0x28]!
1000228d8: a93e290a    	stp	x10, x10, [x8, #-0x20]
1000228dc: a93f290a    	stp	x10, x10, [x8, #-0x10]
1000228e0: 9100a129    	add	x9, x9, #0x28
1000228e4: eb13013f    	cmp	x9, x19
1000228e8: 54ffff43    	b.lo	0x1000228d0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4638>
1000228ec: 52886a00    	mov	w0, #0x4350             ; =17232
1000228f0: 72a004a0    	movk	w0, #0x25, lsl #16
1000228f4: 52800101    	mov	w1, #0x8                ; =8
1000228f8: 97ff7fe2    	bl	0x100002880 <_roc_alloc>
1000228fc: 52800033    	mov	w19, #0x1               ; =1
100022900: f8008413    	str	x19, [x0], #0x8
100022904: f900ebe0    	str	x0, [sp, #0x1d0]
100022908: 52808780    	mov	w0, #0x43c              ; =1084
10002290c: 52800101    	mov	w1, #0x8                ; =8
100022910: 97ff7fdc    	bl	0x100002880 <_roc_alloc>
100022914: aa0003e9    	mov	x9, x0
100022918: b8008d3f    	str	wzr, [x9, #0x8]!
10002291c: f9000013    	str	x19, [x0]
100022920: 91047008    	add	x8, x0, #0x11c
100022924: f9015fe9    	str	x9, [sp, #0x2b8]
100022928: f9400129    	ldr	x9, [x9]
10002292c: f800c009    	stur	x9, [x0, #0xc]
100022930: f9000809    	str	x9, [x0, #0x10]
100022934: f840c009    	ldur	x9, [x0, #0xc]
100022938: f8014009    	stur	x9, [x0, #0x14]
10002293c: 4e080d20    	dup.2d	v0, x9
100022940: 3c82c000    	stur	q0, [x0, #0x2c]
100022944: 3c81c000    	stur	q0, [x0, #0x1c]
100022948: 3c84c000    	stur	q0, [x0, #0x4c]
10002294c: 3c83c000    	stur	q0, [x0, #0x3c]
100022950: 3c86c000    	stur	q0, [x0, #0x6c]
100022954: 3c85c000    	stur	q0, [x0, #0x5c]
100022958: 3c88c000    	stur	q0, [x0, #0x8c]
10002295c: 3c87c000    	stur	q0, [x0, #0x7c]
100022960: 3c8ac000    	stur	q0, [x0, #0xac]
100022964: 3c89c000    	stur	q0, [x0, #0x9c]
100022968: 3c8cc000    	stur	q0, [x0, #0xcc]
10002296c: 3c8bc000    	stur	q0, [x0, #0xbc]
100022970: 3c8ec000    	stur	q0, [x0, #0xec]
100022974: 3c8dc000    	stur	q0, [x0, #0xdc]
100022978: 3c8fcc00    	str	q0, [x0, #0xfc]!
10002297c: 3d800400    	str	q0, [x0, #0x10]
100022980: ad000100    	stp	q0, q0, [x8]
100022984: ad010100    	stp	q0, q0, [x8, #0x20]
100022988: ad020100    	stp	q0, q0, [x8, #0x40]
10002298c: ad030100    	stp	q0, q0, [x8, #0x60]
100022990: ad040100    	stp	q0, q0, [x8, #0x80]
100022994: ad050100    	stp	q0, q0, [x8, #0xa0]
100022998: ad060100    	stp	q0, q0, [x8, #0xc0]
10002299c: ad070100    	stp	q0, q0, [x8, #0xe0]
1000229a0: ad080100    	stp	q0, q0, [x8, #0x100]
1000229a4: ad090100    	stp	q0, q0, [x8, #0x120]
1000229a8: ad0a0100    	stp	q0, q0, [x8, #0x140]
1000229ac: ad0b0100    	stp	q0, q0, [x8, #0x160]
1000229b0: ad0c0100    	stp	q0, q0, [x8, #0x180]
1000229b4: ad0d0100    	stp	q0, q0, [x8, #0x1a0]
1000229b8: ad0e0100    	stp	q0, q0, [x8, #0x1c0]
1000229bc: ad0f0100    	stp	q0, q0, [x8, #0x1e0]
1000229c0: ad100100    	stp	q0, q0, [x8, #0x200]
1000229c4: ad110100    	stp	q0, q0, [x8, #0x220]
1000229c8: ad120100    	stp	q0, q0, [x8, #0x240]
1000229cc: ad130100    	stp	q0, q0, [x8, #0x260]
1000229d0: ad140100    	stp	q0, q0, [x8, #0x280]
1000229d4: ad150100    	stp	q0, q0, [x8, #0x2a0]
1000229d8: ad160100    	stp	q0, q0, [x8, #0x2c0]
1000229dc: ad170100    	stp	q0, q0, [x8, #0x2e0]
1000229e0: f9018109    	str	x9, [x8, #0x300]
1000229e4: 52808780    	mov	w0, #0x43c              ; =1084
1000229e8: 52800101    	mov	w1, #0x8                ; =8
1000229ec: 97ff7fa5    	bl	0x100002880 <_roc_alloc>
1000229f0: aa0003e9    	mov	x9, x0
1000229f4: b8008d3f    	str	wzr, [x9, #0x8]!
1000229f8: f9000013    	str	x19, [x0]
1000229fc: 91047008    	add	x8, x0, #0x11c
100022a00: f9018fe9    	str	x9, [sp, #0x318]
100022a04: f9400129    	ldr	x9, [x9]
100022a08: f800c009    	stur	x9, [x0, #0xc]
100022a0c: f9000809    	str	x9, [x0, #0x10]
100022a10: f840c009    	ldur	x9, [x0, #0xc]
100022a14: f8014009    	stur	x9, [x0, #0x14]
100022a18: 4e080d20    	dup.2d	v0, x9
100022a1c: 3c82c000    	stur	q0, [x0, #0x2c]
100022a20: 3c81c000    	stur	q0, [x0, #0x1c]
100022a24: 3c84c000    	stur	q0, [x0, #0x4c]
100022a28: 3c83c000    	stur	q0, [x0, #0x3c]
100022a2c: 3c86c000    	stur	q0, [x0, #0x6c]
100022a30: 3c85c000    	stur	q0, [x0, #0x5c]
100022a34: 3c88c000    	stur	q0, [x0, #0x8c]
100022a38: 3c87c000    	stur	q0, [x0, #0x7c]
100022a3c: 3c8ac000    	stur	q0, [x0, #0xac]
100022a40: 3c89c000    	stur	q0, [x0, #0x9c]
100022a44: 3c8cc000    	stur	q0, [x0, #0xcc]
100022a48: 3c8bc000    	stur	q0, [x0, #0xbc]
100022a4c: 3c8ec000    	stur	q0, [x0, #0xec]
100022a50: 3c8dc000    	stur	q0, [x0, #0xdc]
100022a54: 3c8fcc00    	str	q0, [x0, #0xfc]!
100022a58: 3d800400    	str	q0, [x0, #0x10]
100022a5c: ad000100    	stp	q0, q0, [x8]
100022a60: ad010100    	stp	q0, q0, [x8, #0x20]
100022a64: ad020100    	stp	q0, q0, [x8, #0x40]
100022a68: ad030100    	stp	q0, q0, [x8, #0x60]
100022a6c: ad040100    	stp	q0, q0, [x8, #0x80]
100022a70: ad050100    	stp	q0, q0, [x8, #0xa0]
100022a74: ad060100    	stp	q0, q0, [x8, #0xc0]
100022a78: ad070100    	stp	q0, q0, [x8, #0xe0]
100022a7c: ad080100    	stp	q0, q0, [x8, #0x100]
100022a80: ad090100    	stp	q0, q0, [x8, #0x120]
100022a84: ad0a0100    	stp	q0, q0, [x8, #0x140]
100022a88: ad0b0100    	stp	q0, q0, [x8, #0x160]
100022a8c: ad0c0100    	stp	q0, q0, [x8, #0x180]
100022a90: ad0d0100    	stp	q0, q0, [x8, #0x1a0]
100022a94: ad0e0100    	stp	q0, q0, [x8, #0x1c0]
100022a98: ad0f0100    	stp	q0, q0, [x8, #0x1e0]
100022a9c: ad100100    	stp	q0, q0, [x8, #0x200]
100022aa0: ad110100    	stp	q0, q0, [x8, #0x220]
100022aa4: ad120100    	stp	q0, q0, [x8, #0x240]
100022aa8: ad130100    	stp	q0, q0, [x8, #0x260]
100022aac: ad140100    	stp	q0, q0, [x8, #0x280]
100022ab0: ad150100    	stp	q0, q0, [x8, #0x2a0]
100022ab4: ad160100    	stp	q0, q0, [x8, #0x2c0]
100022ab8: ad170100    	stp	q0, q0, [x8, #0x2e0]
100022abc: f9018109    	str	x9, [x8, #0x300]
100022ac0: 52800b00    	mov	w0, #0x58               ; =88
100022ac4: 52800101    	mov	w1, #0x8                ; =8
100022ac8: 97ff7f6e    	bl	0x100002880 <_roc_alloc>
100022acc: aa0003e8    	mov	x8, x0
100022ad0: b8008d1f    	str	wzr, [x8, #0x8]!
100022ad4: f9000013    	str	x19, [x0]
100022ad8: f90193e8    	str	x8, [sp, #0x320]
100022adc: f9400108    	ldr	x8, [x8]
100022ae0: f800c008    	stur	x8, [x0, #0xc]
100022ae4: f9000808    	str	x8, [x0, #0x10]
100022ae8: f840c008    	ldur	x8, [x0, #0xc]
100022aec: f8014008    	stur	x8, [x0, #0x14]
100022af0: 4e080d00    	dup.2d	v0, x8
100022af4: 3c82c000    	stur	q0, [x0, #0x2c]
100022af8: 3c81c000    	stur	q0, [x0, #0x1c]
100022afc: 52800b00    	mov	w0, #0x58               ; =88
100022b00: 52800101    	mov	w1, #0x8                ; =8
100022b04: 97ff7f5f    	bl	0x100002880 <_roc_alloc>
100022b08: aa0003f5    	mov	x21, x0
100022b0c: b8008ebf    	str	wzr, [x21, #0x8]!
100022b10: 52800028    	mov	w8, #0x1                ; =1
100022b14: f9004fe8    	str	x8, [sp, #0x98]
100022b18: f9000013    	str	x19, [x0]
100022b1c: f94002a8    	ldr	x8, [x21]
100022b20: f800c008    	stur	x8, [x0, #0xc]
100022b24: f9000808    	str	x8, [x0, #0x10]
100022b28: f840c008    	ldur	x8, [x0, #0xc]
100022b2c: f8014008    	stur	x8, [x0, #0x14]
100022b30: 4e080d00    	dup.2d	v0, x8
100022b34: 3c82c000    	stur	q0, [x0, #0x2c]
100022b38: 3c81c000    	stur	q0, [x0, #0x1c]
100022b3c: 52800200    	mov	w0, #0x10               ; =16
100022b40: 52800101    	mov	w1, #0x8                ; =8
100022b44: 97ff7f4f    	bl	0x100002880 <_roc_alloc>
100022b48: d280000d    	mov	x13, #0x0               ; =0
100022b4c: d280000c    	mov	x12, #0x0               ; =0
100022b50: d280000e    	mov	x14, #0x0               ; =0
100022b54: f900a7ff    	str	xzr, [sp, #0x148]
100022b58: f9009bff    	str	xzr, [sp, #0x130]
100022b5c: d2800013    	mov	x19, #0x0               ; =0
100022b60: f9019bff    	str	xzr, [sp, #0x330]
100022b64: d280001b    	mov	x27, #0x0               ; =0
100022b68: d2800001    	mov	x1, #0x0                ; =0
100022b6c: d2800010    	mov	x16, #0x0               ; =0
100022b70: f901abff    	str	xzr, [sp, #0x350]
100022b74: f90103ff    	str	xzr, [sp, #0x200]
100022b78: d503201f    	nop
100022b7c: 9c0855a0    	ldr	q0, 0x100033630 <dyld_stub_binder+0x100033630>
100022b80: 3c808400    	str	q0, [x0], #0x8
100022b84: f900d7e0    	str	x0, [sp, #0x1a8]
100022b88: 100b3ec8    	adr	x8, 0x100039360 <_.roc.static_data.31>
100022b8c: d503201f    	nop
100022b90: 3dc00102    	ldr	q2, [x8]
100022b94: 3d82c7e2    	str	q2, [sp, #0xb10]
100022b98: f9400908    	ldr	x8, [x8, #0x10]
100022b9c: f90593e8    	str	x8, [sp, #0xb20]
100022ba0: 100b3ec9    	adr	x9, 0x100039378 <_.roc.static_data.29>
100022ba4: d503201f    	nop
100022ba8: 3dc00120    	ldr	q0, [x9]
100022bac: f9400929    	ldr	x9, [x9, #0x10]
100022bb0: 5290000a    	mov	w10, #0x8000            ; =32768
100022bb4: f941a3fe    	ldr	x30, [sp, #0x340]
100022bb8: f14023df    	cmp	x30, #0x8, lsl #12      ; =0x8000
100022bbc: 9a8a33d1    	csel	x17, x30, x10, lo
100022bc0: f905a3e9    	str	x9, [sp, #0xb40]
100022bc4: f905c3e8    	str	x8, [sp, #0xb80]
100022bc8: f905d3e9    	str	x9, [sp, #0xba0]
100022bcc: 3cc182e1    	ldur	q1, [x23, #0x18]
100022bd0: f94b27e8    	ldr	x8, [sp, #0x1648]
100022bd4: f94b1be9    	ldr	x9, [sp, #0x1630]
100022bd8: d1000fca    	sub	x10, x30, #0x3
100022bdc: f901a7ea    	str	x10, [sp, #0x348]
100022be0: f905f3e8    	str	x8, [sp, #0xbe0]
100022be4: 100b3fa8    	adr	x8, 0x1000393d8 <_.roc.static_data.5>
100022be8: d503201f    	nop
100022bec: f90603e9    	str	x9, [sp, #0xc00]
100022bf0: 914007e9    	add	x9, sp, #0x1, lsl #12   ; =0x1000
100022bf4: 9112e129    	add	x9, x9, #0x4b8
100022bf8: 9100612a    	add	x10, x9, #0x18
100022bfc: f90133ea    	str	x10, [sp, #0x260]
100022c00: f94b3fea    	ldr	x10, [sp, #0x1678]
100022c04: f94b33eb    	ldr	x11, [sp, #0x1660]
100022c08: f90613ea    	str	x10, [sp, #0xc20]
100022c0c: 9100c129    	add	x9, x9, #0x30
100022c10: f9012be9    	str	x9, [sp, #0x250]
100022c14: 3cc482e3    	ldur	q3, [x23, #0x48]
100022c18: 1026d849    	adr	x9, 0x100070720 <_roc__d25_1>
100022c1c: d503201f    	nop
100022c20: 9100212a    	add	x10, x9, #0x8
100022c24: 100b51a9    	adr	x9, 0x100039658 <_roc__d19_1>
100022c28: d503201f    	nop
100022c2c: 91002129    	add	x9, x9, #0x8
100022c30: f90057e9    	str	x9, [sp, #0xa8]
100022c34: 3d82dfe2    	str	q2, [sp, #0xb70]
100022c38: f90623eb    	str	x11, [sp, #0xc40]
100022c3c: d503201f    	nop
100022c40: 9c085082    	ldr	q2, 0x100033650 <dyld_stub_binder+0x100033650>
100022c44: 3d8047e2    	str	q2, [sp, #0x110]
100022c48: d503201f    	nop
100022c4c: 9c0850a2    	ldr	q2, 0x100033660 <dyld_stub_binder+0x100033660>
100022c50: 3d8043e2    	str	q2, [sp, #0x100]
100022c54: d503201f    	nop
100022c58: 9c084f42    	ldr	q2, 0x100033640 <dyld_stub_binder+0x100033640>
100022c5c: 3d80bbe2    	str	q2, [sp, #0x2e0]
100022c60: d503201f    	nop
100022c64: 9c084ce2    	ldr	q2, 0x100033600 <dyld_stub_binder+0x100033600>
100022c68: 3d8033e2    	str	q2, [sp, #0xc0]
100022c6c: d503201f    	nop
100022c70: 9c084282    	ldr	q2, 0x1000334c0 <dyld_stub_binder+0x1000334c0>
100022c74: 3d802fe2    	str	q2, [sp, #0xb0]
100022c78: d503201f    	nop
100022c7c: 9c084ba2    	ldr	q2, 0x1000335f0 <dyld_stub_binder+0x1000335f0>
100022c80: 3d8057e2    	str	q2, [sp, #0x150]
100022c84: 100b58e9    	adr	x9, 0x1000397a0 <_roc__d21_1>
100022c88: d503201f    	nop
100022c8c: 91002129    	add	x9, x9, #0x8
100022c90: f90053e9    	str	x9, [sp, #0xa0]
100022c94: 3d82cfe0    	str	q0, [sp, #0xb30]
100022c98: 3d82e7e0    	str	q0, [sp, #0xb90]
100022c9c: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100022ca0: 3d82f7e1    	str	q1, [sp, #0xbd0]
100022ca4: 3dc58be0    	ldr	q0, [sp, #0x1620]
100022ca8: 3d82ffe0    	str	q0, [sp, #0xbf0]
100022cac: 3d8307e3    	str	q3, [sp, #0xc10]
100022cb0: 3dc597e0    	ldr	q0, [sp, #0x1650]
100022cb4: 3d830fe0    	str	q0, [sp, #0xc30]
100022cb8: 3dc00100    	ldr	q0, [x8]
100022cbc: 3d82d7e0    	str	q0, [sp, #0xb50]
100022cc0: f9400908    	ldr	x8, [x8, #0x10]
100022cc4: f905b3e8    	str	x8, [sp, #0xb60]
100022cc8: 3d803be0    	str	q0, [sp, #0xe0]
100022ccc: 3d82efe0    	str	q0, [sp, #0xbb0]
100022cd0: f9006fe8    	str	x8, [sp, #0xd8]
100022cd4: f905e3e8    	str	x8, [sp, #0xbc0]
100022cd8: f9419ff7    	ldr	x23, [sp, #0x338]
100022cdc: 91000ae8    	add	x8, x23, #0x2
100022ce0: f90153e8    	str	x8, [sp, #0x2a0]
100022ce4: 910006e8    	add	x8, x23, #0x1
100022ce8: f9014fe8    	str	x8, [sp, #0x298]
100022cec: 52800288    	mov	w8, #0x14               ; =20
100022cf0: 5280015c    	mov	w28, #0xa               ; =10
100022cf4: 52800518    	mov	w24, #0x28              ; =40
100022cf8: 52802069    	mov	w9, #0x103              ; =259
100022cfc: f90163e9    	str	x9, [sp, #0x2c0]
100022d00: 52804349    	mov	w9, #0x21a              ; =538
100022d04: f900dfe9    	str	x9, [sp, #0x1b8]
100022d08: 528a1a49    	mov	w9, #0x50d2             ; =20690
100022d0c: 72a00129    	movk	w9, #0x9, lsl #16
100022d10: f900fbe9    	str	x9, [sp, #0x1f0]
100022d14: 52802049    	mov	w9, #0x102              ; =258
100022d18: f901b7e9    	str	x9, [sp, #0x368]
100022d1c: 52800149    	mov	w9, #0xa                ; =10
100022d20: 5280004b    	mov	w11, #0x2               ; =2
100022d24: f900dbeb    	str	x11, [sp, #0x1b0]
100022d28: 5280002b    	mov	w11, #0x1               ; =1
100022d2c: f900cbeb    	str	x11, [sp, #0x190]
100022d30: a916abe8    	stp	x8, x10, [sp, #0x168]
100022d34: f900c3e9    	str	x9, [sp, #0x180]
100022d38: f90123f5    	str	x21, [sp, #0x240]
100022d3c: f90147fc    	str	x28, [sp, #0x288]
100022d40: f900b3f8    	str	x24, [sp, #0x160]
100022d44: f900e3ec    	str	x12, [sp, #0x1c0]
100022d48: f90183ed    	str	x13, [sp, #0x300]
100022d4c: eb0d03c8    	subs	x8, x30, x13
100022d50: 5403cd63    	b.lo	0x10002a6fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc464>
100022d54: f90187fe    	str	x30, [sp, #0x308]
100022d58: 5294ed09    	mov	w9, #0xa768             ; =42856
100022d5c: 72a00089    	movk	w9, #0x4, lsl #16
100022d60: eb09011f    	cmp	x8, x9
100022d64: f94193f9    	ldr	x25, [sp, #0x320]
100022d68: f9419bfc    	ldr	x28, [sp, #0x330]
100022d6c: f941b7f5    	ldr	x21, [sp, #0x368]
100022d70: f94113e7    	ldr	x7, [sp, #0x220]
100022d74: 540000e3    	b.lo	0x100022d90 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4af8>
100022d78: 52927c08    	mov	w8, #0x93e0             ; =37856
100022d7c: 72a00088    	movk	w8, #0x4, lsl #16
100022d80: f94183e9    	ldr	x9, [sp, #0x300]
100022d84: ab080128    	adds	x8, x9, x8
100022d88: f90187e8    	str	x8, [sp, #0x308]
100022d8c: 5403cae2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100022d90: f10005df    	cmp	x14, #0x1
100022d94: f90193f9    	str	x25, [sp, #0x320]
100022d98: 54000081    	b.ne	0x100022da8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4b10>
100022d9c: 52802068    	mov	w8, #0x103              ; =259
100022da0: f90157e8    	str	x8, [sp, #0x2a8]
100022da4: 14000059    	b	0x100022f08 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4c70>
100022da8: f94183e8    	ldr	x8, [sp, #0x300]
100022dac: f94187e9    	ldr	x9, [sp, #0x308]
100022db0: eb080134    	subs	x20, x9, x8
100022db4: 5403ca43    	b.lo	0x10002a6fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc464>
100022db8: f108029f    	cmp	x20, #0x200
100022dbc: 54000082    	b.hs	0x100022dcc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4b34>
100022dc0: 52800068    	mov	w8, #0x3                ; =3
100022dc4: f90157e8    	str	x8, [sp, #0x2a8]
100022dc8: 14000050    	b	0x100022f08 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4c70>
100022dcc: aa1003f9    	mov	x25, x16
100022dd0: aa0103f8    	mov	x24, x1
100022dd4: aa1103f6    	mov	x22, x17
100022dd8: 52802600    	mov	w0, #0x130              ; =304
100022ddc: 52800101    	mov	w1, #0x8                ; =8
100022de0: 97ff7ea8    	bl	0x100002880 <_roc_alloc>
100022de4: f941a3ec    	ldr	x12, [sp, #0x340]
100022de8: f9419feb    	ldr	x11, [sp, #0x338]
100022dec: d2800008    	mov	x8, #0x0                ; =0
100022df0: 5280002d    	mov	w13, #0x1               ; =1
100022df4: f900000d    	str	x13, [x0]
100022df8: 6f00e400    	movi.2d	v0, #0000000000000000
100022dfc: 3c818000    	stur	q0, [x0, #0x18]
100022e00: 3c828000    	stur	q0, [x0, #0x28]
100022e04: 3c838000    	stur	q0, [x0, #0x38]
100022e08: 3c848000    	stur	q0, [x0, #0x48]
100022e0c: 3c858000    	stur	q0, [x0, #0x58]
100022e10: 3c868000    	stur	q0, [x0, #0x68]
100022e14: 3c878000    	stur	q0, [x0, #0x78]
100022e18: 3c888000    	stur	q0, [x0, #0x88]
100022e1c: 3c898000    	stur	q0, [x0, #0x98]
100022e20: 3c8a8000    	stur	q0, [x0, #0xa8]
100022e24: 3c8b8000    	stur	q0, [x0, #0xb8]
100022e28: 3c8c8000    	stur	q0, [x0, #0xc8]
100022e2c: 3c8d8000    	stur	q0, [x0, #0xd8]
100022e30: 3c8e8000    	stur	q0, [x0, #0xe8]
100022e34: 3c8f8000    	stur	q0, [x0, #0xf8]
100022e38: 3904201f    	strb	wzr, [x0, #0x108]
100022e3c: f140069f    	cmp	x20, #0x1, lsl #12      ; =0x1000
100022e40: 52820009    	mov	w9, #0x1000             ; =4096
100022e44: 9a893289    	csel	x9, x20, x9, lo
100022e48: 3c808c00    	str	q0, [x0, #0x8]!
100022e4c: f94183ee    	ldr	x14, [sp, #0x300]
100022e50: ab0801ca    	adds	x10, x14, x8
100022e54: 5403c4a2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100022e58: eb0c015f    	cmp	x10, x12
100022e5c: 540000e2    	b.hs	0x100022e78 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4be0>
100022e60: 386a696a    	ldrb	w10, [x11, x10]
100022e64: 382a680d    	strb	w13, [x0, x10]
100022e68: 91000508    	add	x8, x8, #0x1
100022e6c: eb08013f    	cmp	x9, x8
100022e70: 54ffff01    	b.ne	0x100022e50 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4bb8>
100022e74: 14000006    	b	0x100022e8c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4bf4>
100022e78: d280000a    	mov	x10, #0x0               ; =0
100022e7c: 382a680d    	strb	w13, [x0, x10]
100022e80: 91000508    	add	x8, x8, #0x1
100022e84: eb08013f    	cmp	x9, x8
100022e88: 54fffe41    	b.ne	0x100022e50 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4bb8>
100022e8c: d2800008    	mov	x8, #0x0                ; =0
100022e90: d2800014    	mov	x20, #0x0               ; =0
100022e94: 38686809    	ldrb	w9, [x0, x8]
100022e98: ab090294    	adds	x20, x20, x9
100022e9c: 5403c262    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100022ea0: 91000508    	add	x8, x8, #0x1
100022ea4: f104011f    	cmp	x8, #0x100
100022ea8: 54ffff61    	b.ne	0x100022e94 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4bfc>
100022eac: f904d3e0    	str	x0, [sp, #0x9a0]
100022eb0: 912683e8    	add	x8, sp, #0x9a0
100022eb4: 3dc057e0    	ldr	q0, [sp, #0x150]
100022eb8: 3c808100    	stur	q0, [x8, #0x8]
100022ebc: 912683e0    	add	x0, sp, #0x9a0
100022ec0: 940034c0    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100022ec4: f1013e9f    	cmp	x20, #0x4f
100022ec8: 54000069    	b.ls	0x100022ed4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4c3c>
100022ecc: 52800068    	mov	w8, #0x3                ; =3
100022ed0: 14000005    	b	0x100022ee4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4c4c>
100022ed4: 100ba1e8    	adr	x8, 0x10003a310 <_roc__d61_1>
100022ed8: d503201f    	nop
100022edc: 8b140108    	add	x8, x8, x20
100022ee0: 39402108    	ldrb	w8, [x8, #0x8]
100022ee4: f90157e8    	str	x8, [sp, #0x2a8]
100022ee8: f9419ff7    	ldr	x23, [sp, #0x338]
100022eec: f941a3fe    	ldr	x30, [sp, #0x340]
100022ef0: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100022ef4: aa1603f1    	mov	x17, x22
100022ef8: aa1803e1    	mov	x1, x24
100022efc: f94113e7    	ldr	x7, [sp, #0x220]
100022f00: aa1903f0    	mov	x16, x25
100022f04: f94193f9    	ldr	x25, [sp, #0x320]
100022f08: b901e3ff    	str	wzr, [sp, #0x1e0]
100022f0c: f900f7ff    	str	xzr, [sp, #0x1e8]
100022f10: f9010fff    	str	xzr, [sp, #0x218]
100022f14: f9018bf3    	str	x19, [sp, #0x310]
100022f18: cb1303d4    	sub	x20, x30, x19
100022f1c: eb11027f    	cmp	x19, x17
100022f20: 54000ba1    	b.ne	0x100023094 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4dfc>
100022f24: f941b3e8    	ldr	x8, [sp, #0x360]
100022f28: 37000288    	tbnz	w8, #0x0, 0x100022f78 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4ce0>
100022f2c: f941b3e8    	ldr	x8, [sp, #0x360]
100022f30: b4000088    	cbz	x8, 0x100022f40 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4ca8>
100022f34: f85f80e8    	ldur	x8, [x7, #-0x8]
100022f38: f100051f    	cmp	x8, #0x1
100022f3c: 540001e1    	b.ne	0x100022f78 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4ce0>
100022f40: d2800008    	mov	x8, #0x0                ; =0
100022f44: 8b0800e9    	add	x9, x7, x8
100022f48: ad400520    	ldp	q0, q1, [x9]
100022f4c: ad410d22    	ldp	q2, q3, [x9, #0x20]
100022f50: 6e642c00    	uqsub.8h	v0, v0, v4
100022f54: 6e642c21    	uqsub.8h	v1, v1, v4
100022f58: 6e642c42    	uqsub.8h	v2, v2, v4
100022f5c: 6e642c63    	uqsub.8h	v3, v3, v4
100022f60: ad000520    	stp	q0, q1, [x9]
100022f64: ad010d22    	stp	q2, q3, [x9, #0x20]
100022f68: 91010108    	add	x8, x8, #0x40
100022f6c: f142011f    	cmp	x8, #0x80, lsl #12      ; =0x80000
100022f70: 54fffea1    	b.ne	0x100022f44 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4cac>
100022f74: 14000043    	b	0x100023080 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4de8>
100022f78: f9015bf0    	str	x16, [sp, #0x2b0]
100022f7c: aa1303f9    	mov	x25, x19
100022f80: aa1a03f3    	mov	x19, x26
100022f84: aa1b03fa    	mov	x26, x27
100022f88: aa0103fb    	mov	x27, x1
100022f8c: aa1503f8    	mov	x24, x21
100022f90: f90eebff    	str	xzr, [sp, #0x1dd0]
100022f94: f90ee7ff    	str	xzr, [sp, #0x1dc8]
100022f98: f90eefff    	str	xzr, [sp, #0x1dd8]
100022f9c: 912683e0    	add	x0, sp, #0x9a0
100022fa0: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
100022fa4: 91372021    	add	x1, x1, #0xdc8
100022fa8: 52a00082    	mov	w2, #0x40000            ; =262144
100022fac: 52800043    	mov	w3, #0x2                ; =2
100022fb0: 52800024    	mov	w4, #0x1                ; =1
100022fb4: aa0703f5    	mov	x21, x7
100022fb8: 94003aa4    	bl	0x100031a48 <_list.RocList.reallocate>
100022fbc: aa1503eb    	mov	x11, x21
100022fc0: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100022fc4: d2800008    	mov	x8, #0x0                ; =0
100022fc8: f944d3f5    	ldr	x21, [sp, #0x9a0]
100022fcc: f944dbf6    	ldr	x22, [sp, #0x9b0]
100022fd0: cb0b02a9    	sub	x9, x21, x11
100022fd4: f101013f    	cmp	x9, #0x40
100022fd8: 540001e3    	b.lo	0x100023014 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4d7c>
100022fdc: 91008168    	add	x8, x11, #0x20
100022fe0: 910082a9    	add	x9, x21, #0x20
100022fe4: 321b33ea    	mov	w10, #0x3ffe0           ; =262112
100022fe8: ad7f0500    	ldp	q0, q1, [x8, #-0x20]
100022fec: acc20d02    	ldp	q2, q3, [x8], #0x40
100022ff0: 6e642c00    	uqsub.8h	v0, v0, v4
100022ff4: 6e642c21    	uqsub.8h	v1, v1, v4
100022ff8: 6e642c42    	uqsub.8h	v2, v2, v4
100022ffc: 6e642c63    	uqsub.8h	v3, v3, v4
100023000: ad3f0520    	stp	q0, q1, [x9, #-0x20]
100023004: ac820d22    	stp	q2, q3, [x9], #0x40
100023008: f100814a    	subs	x10, x10, #0x20
10002300c: 54fffee1    	b.ne	0x100022fe8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4d50>
100023010: 321b33e8    	mov	w8, #0x3ffe0            ; =262112
100023014: b100051f    	cmn	x8, #0x1
100023018: 5403b680    	b.eq	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10002301c: 78e87969    	ldrsh	w9, [x11, x8, lsl #1]
100023020: 5211012a    	eor	w10, w9, #0x8000
100023024: 0a493d49    	and	w9, w10, w9, lsr #15
100023028: 78287aa9    	strh	w9, [x21, x8, lsl #1]
10002302c: 91000508    	add	x8, x8, #0x1
100023030: f141011f    	cmp	x8, #0x40, lsl #12      ; =0x40000
100023034: 54ffff01    	b.ne	0x100023014 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4d7c>
100023038: f904d3eb    	str	x11, [sp, #0x9a0]
10002303c: f904d7e8    	str	x8, [sp, #0x9a8]
100023040: f941b3e8    	ldr	x8, [sp, #0x360]
100023044: f904dbe8    	str	x8, [sp, #0x9b0]
100023048: 912683e0    	add	x0, sp, #0x9a0
10002304c: 9400345d    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100023050: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100023054: aa1503e7    	mov	x7, x21
100023058: f901b3f6    	str	x22, [sp, #0x360]
10002305c: f9419ff7    	ldr	x23, [sp, #0x338]
100023060: f941a3fe    	ldr	x30, [sp, #0x340]
100023064: aa1803f5    	mov	x21, x24
100023068: aa1b03e1    	mov	x1, x27
10002306c: aa1a03fb    	mov	x27, x26
100023070: aa1303fa    	mov	x26, x19
100023074: aa1903f3    	mov	x19, x25
100023078: f9415bf0    	ldr	x16, [sp, #0x2b0]
10002307c: f94193f9    	ldr	x25, [sp, #0x320]
100023080: f140229f    	cmp	x20, #0x8, lsl #12      ; =0x8000
100023084: 52900008    	mov	w8, #0x8000             ; =32768
100023088: 9a883288    	csel	x8, x20, x8, lo
10002308c: 8b130111    	add	x17, x8, x19
100023090: f901abf3    	str	x19, [sp, #0x350]
100023094: eb14035f    	cmp	x26, x20
100023098: 9a943348    	csel	x8, x26, x20, lo
10002309c: f1040a9f    	cmp	x20, #0x102
1000230a0: 9a953295    	csel	x21, x20, x21, lo
1000230a4: 9a9a311a    	csel	x26, x8, x26, lo
1000230a8: f10016bf    	cmp	x21, #0x5
1000230ac: 54000163    	b.lo	0x1000230d8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4e40>
1000230b0: ab150268    	adds	x8, x19, x21
1000230b4: 5403b1a2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000230b8: eb1e011f    	cmp	x8, x30
1000230bc: 54054308    	b.hi	0x10002d91c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf684>
1000230c0: 91000668    	add	x8, x19, #0x1
1000230c4: f941a7e9    	ldr	x9, [sp, #0x348]
1000230c8: eb09011f    	cmp	x8, x9
1000230cc: 54000122    	b.hs	0x1000230f0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4e58>
1000230d0: b8686ae8    	ldr	w8, [x23, x8]
1000230d4: 14000008    	b	0x1000230f4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4e5c>
1000230d8: d280000b    	mov	x11, #0x0               ; =0
1000230dc: aa1b03e8    	mov	x8, x27
1000230e0: f9418be9    	ldr	x9, [sp, #0x310]
1000230e4: eb09027f    	cmp	x19, x9
1000230e8: 54001fc2    	b.hs	0x1000234e0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5248>
1000230ec: 1400011b    	b	0x100023558 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x52c0>
1000230f0: 52800008    	mov	w8, #0x0                ; =0
1000230f4: 12005d09    	and	w9, w8, #0xffffff
1000230f8: 5294f7ab    	mov	w11, #0xa7bd            ; =42941
1000230fc: 72a3c6ab    	movk	w11, #0x1e35, lsl #16
100023100: 1b0b7d29    	mul	w9, w9, w11
100023104: 53107d2a    	lsr	w10, w9, #16
100023108: 1b0b7d08    	mul	w8, w8, w11
10002310c: 53107d09    	lsr	w9, w8, #16
100023110: 8b2a48e8    	add	x8, x7, w10, uxtw #2
100023114: 52a0008f    	mov	w15, #0x40000           ; =262144
100023118: f8af6910    	prfm	pstl1keep, [x8, x15]
10002311c: 8b2944e8    	add	x8, x7, w9, uxtw #1
100023120: 52a0004b    	mov	w11, #0x20000           ; =131072
100023124: f8ab6910    	prfm	pstl1keep, [x8, x11]
100023128: d37e3e08    	ubfiz	x8, x16, #2, #16
10002312c: 8b0800e8    	add	x8, x7, x8
100023130: 786f690e    	ldrh	w14, [x8, x15]
100023134: 52800050    	mov	w16, #0x2               ; =2
100023138: 72a00090    	movk	w16, #0x4, lsl #16
10002313c: 7870690d    	ldrh	w13, [x8, x16]
100023140: f941abeb    	ldr	x11, [sp, #0x350]
100023144: cb0b026b    	sub	x11, x19, x11
100023148: eb0e017f    	cmp	x11, x14
10002314c: 5211416c    	eor	w12, w11, #0xffff8000
100023150: 782f690c    	strh	w12, [x8, x15]
100023154: 7830690e    	strh	w14, [x8, x16]
100023158: aa1b03e8    	mov	x8, x27
10002315c: 540006e2    	b.hs	0x100023238 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4fa0>
100023160: f941a7e8    	ldr	x8, [sp, #0x348]
100023164: eb08027f    	cmp	x19, x8
100023168: 540001a2    	b.hs	0x10002319c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4f04>
10002316c: b8736ae8    	ldr	w8, [x23, x19]
100023170: 12005d0f    	and	w15, w8, #0xffffff
100023174: f941abe8    	ldr	x8, [sp, #0x350]
100023178: d1402110    	sub	x16, x8, #0x8, lsl #12  ; =0x8000
10002317c: 8b0e020e    	add	x14, x16, x14
100023180: f941a7e8    	ldr	x8, [sp, #0x348]
100023184: eb0801df    	cmp	x14, x8
100023188: 54000183    	b.lo	0x1000231b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4f20>
10002318c: 52800008    	mov	w8, #0x0                ; =0
100023190: 6b0801ff    	cmp	w15, w8
100023194: 54000301    	b.ne	0x1000231f4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4f5c>
100023198: 1400000c    	b	0x1000231c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4f30>
10002319c: 5280000f    	mov	w15, #0x0               ; =0
1000231a0: f941abe8    	ldr	x8, [sp, #0x350]
1000231a4: d1402110    	sub	x16, x8, #0x8, lsl #12  ; =0x8000
1000231a8: 8b0e020e    	add	x14, x16, x14
1000231ac: f941a7e8    	ldr	x8, [sp, #0x348]
1000231b0: eb0801df    	cmp	x14, x8
1000231b4: 54fffec2    	b.hs	0x10002318c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4ef4>
1000231b8: b86e6ae8    	ldr	w8, [x23, x14]
1000231bc: 12005d08    	and	w8, w8, #0xffffff
1000231c0: 6b0801ff    	cmp	w15, w8
1000231c4: 54000181    	b.ne	0x1000231f4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4f5c>
1000231c8: 529cac28    	mov	w8, #0xe561             ; =58721
1000231cc: 72a002c8    	movk	w8, #0x16, lsl #16
1000231d0: eb08037f    	cmp	x27, x8
1000231d4: 5403e322    	b.hs	0x10002ae38 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xcba0>
1000231d8: 4b0e0268    	sub	w8, w19, w14
1000231dc: 5280006d    	mov	w13, #0x3               ; =3
1000231e0: 2a0841a8    	orr	w8, w13, w8, lsl #16
1000231e4: f941afed    	ldr	x13, [sp, #0x358]
1000231e8: b83b79a8    	str	w8, [x13, x27, lsl #2]
1000231ec: 91000768    	add	x8, x27, #0x1
1000231f0: 14000012    	b	0x100023238 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4fa0>
1000231f4: aa1b03e8    	mov	x8, x27
1000231f8: eb0d017f    	cmp	x11, x13
1000231fc: 540001e2    	b.hs	0x100023238 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4fa0>
100023200: 8b0d020e    	add	x14, x16, x13
100023204: f941a7e8    	ldr	x8, [sp, #0x348]
100023208: eb0801df    	cmp	x14, x8
10002320c: 540000e2    	b.hs	0x100023228 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4f90>
100023210: b86e6ae8    	ldr	w8, [x23, x14]
100023214: 12005d0d    	and	w13, w8, #0xffffff
100023218: aa1b03e8    	mov	x8, x27
10002321c: 6b0d01ff    	cmp	w15, w13
100023220: 54fffd40    	b.eq	0x1000231c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4f30>
100023224: 14000005    	b	0x100023238 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4fa0>
100023228: 5280000d    	mov	w13, #0x0               ; =0
10002322c: aa1b03e8    	mov	x8, x27
100023230: 6b0d01ff    	cmp	w15, w13
100023234: 54fffca0    	b.eq	0x1000231c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4f30>
100023238: aa1103f6    	mov	x22, x17
10002323c: d37f3c2d    	ubfiz	x13, x1, #1, #16
100023240: 8b0d00ed    	add	x13, x7, x13
100023244: 52a0004e    	mov	w14, #0x20000           ; =131072
100023248: 786e69b0    	ldrh	w16, [x13, x14]
10002324c: 782e69ac    	strh	w12, [x13, x14]
100023250: d37f396c    	ubfiz	x12, x11, #1, #15
100023254: 5280002d    	mov	w13, #0x1               ; =1
100023258: b37f396d    	bfi	x13, x11, #1, #15
10002325c: eb10017f    	cmp	x11, x16
100023260: 54001262    	b.hs	0x1000234ac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5214>
100023264: d2800000    	mov	x0, #0x0                ; =0
100023268: d2800011    	mov	x17, #0x0               ; =0
10002326c: d2800003    	mov	x3, #0x0                ; =0
100023270: 8b1302ee    	add	x14, x23, x19
100023274: f94197ef    	ldr	x15, [sp, #0x328]
100023278: 52800061    	mov	w1, #0x3                ; =3
10002327c: 1400000f    	b	0x1000232b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5020>
100023280: 782d78f0    	strh	w16, [x7, x13, lsl #1]
100023284: aa1103e4    	mov	x4, x17
100023288: aa0203ed    	mov	x13, x2
10002328c: aa0303e0    	mov	x0, x3
100023290: 786278f0    	ldrh	w16, [x7, x2, lsl #1]
100023294: d10005ef    	sub	x15, x15, #0x1
100023298: eb10017f    	cmp	x11, x16
10002329c: fa4039e4    	ccmp	x15, #0x0, #0x4, lo
1000232a0: 54001060    	b.eq	0x1000234ac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5214>
1000232a4: eb03023f    	cmp	x17, x3
1000232a8: 9a833223    	csel	x3, x17, x3, lo
1000232ac: aa0403f1    	mov	x17, x4
1000232b0: eb15007f    	cmp	x3, x21
1000232b4: 54000d82    	b.hs	0x100023464 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x51cc>
1000232b8: 4b100162    	sub	w2, w11, w16
1000232bc: 92403842    	and	x2, x2, #0x7fff
1000232c0: eb020262    	subs	x2, x19, x2
1000232c4: 9a8233e2    	csel	x2, xzr, x2, lo
1000232c8: 8b0202e5    	add	x5, x23, x2
1000232cc: 386368a4    	ldrb	w4, [x5, x3]
1000232d0: 386369c6    	ldrb	w6, [x14, x3]
1000232d4: 6b06009f    	cmp	w4, w6
1000232d8: 54000901    	b.ne	0x1000233f8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5160>
1000232dc: eb02027f    	cmp	x19, x2
1000232e0: 5404ad49    	b.ls	0x10002c888 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe5f0>
1000232e4: 91000464    	add	x4, x3, #0x1
1000232e8: 91008463    	add	x3, x3, #0x21
1000232ec: eb15007f    	cmp	x3, x21
1000232f0: 54000288    	b.hi	0x100023340 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x50a8>
1000232f4: aa0703f8    	mov	x24, x7
1000232f8: 91002086    	add	x6, x4, #0x8
1000232fc: eb0300df    	cmp	x6, x3
100023300: 540001e8    	b.hi	0x10002333c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x50a4>
100023304: f86469c7    	ldr	x7, [x14, x4]
100023308: f86468b4    	ldr	x20, [x5, x4]
10002330c: aa0603e4    	mov	x4, x6
100023310: eb07029f    	cmp	x20, x7
100023314: 54ffff20    	b.eq	0x1000232f8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5060>
100023318: ca070283    	eor	x3, x20, x7
10002331c: dac00063    	rbit	x3, x3
100023320: dac01063    	clz	x3, x3
100023324: 8b430cc3    	add	x3, x6, x3, lsr #3
100023328: d1002064    	sub	x4, x3, #0x8
10002332c: aa1803e7    	mov	x7, x24
100023330: eb01009f    	cmp	x4, x1
100023334: 54000368    	b.hi	0x1000233a0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5108>
100023338: 1400002f    	b	0x1000233f4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x515c>
10002333c: aa1803e7    	mov	x7, x24
100023340: b1002083    	adds	x3, x4, #0x8
100023344: 54039d22    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100023348: eb15007f    	cmp	x3, x21
10002334c: 54000128    	b.hi	0x100023370 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x50d8>
100023350: f86469c3    	ldr	x3, [x14, x4]
100023354: f86468a6    	ldr	x6, [x5, x4]
100023358: eb0300df    	cmp	x6, x3
10002335c: 54000401    	b.ne	0x1000233dc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5144>
100023360: b1004083    	adds	x3, x4, #0x10
100023364: 91002084    	add	x4, x4, #0x8
100023368: 54ffff03    	b.lo	0x100023348 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x50b0>
10002336c: 14001cdf    	b	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100023370: eb15009f    	cmp	x4, x21
100023374: 54000122    	b.hs	0x100023398 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5100>
100023378: 386469c3    	ldrb	w3, [x14, x4]
10002337c: 386468a6    	ldrb	w6, [x5, x4]
100023380: 6b06007f    	cmp	w3, w6
100023384: 540000a1    	b.ne	0x100023398 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5100>
100023388: 91000484    	add	x4, x4, #0x1
10002338c: eb0402bf    	cmp	x21, x4
100023390: 54ffff41    	b.ne	0x100023378 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x50e0>
100023394: aa1503e4    	mov	x4, x21
100023398: eb01009f    	cmp	x4, x1
10002339c: 540002c9    	b.ls	0x1000233f4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x515c>
1000233a0: 529cac21    	mov	w1, #0xe561             ; =58721
1000233a4: 72a002c1    	movk	w1, #0x16, lsl #16
1000233a8: eb01011f    	cmp	x8, x1
1000233ac: 5403d462    	b.hs	0x10002ae38 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xcba0>
1000233b0: 4b020261    	sub	w1, w19, w2
1000233b4: aa0403e3    	mov	x3, x4
1000233b8: 33103c23    	bfi	w3, w1, #16, #16
1000233bc: f941afe1    	ldr	x1, [sp, #0x358]
1000233c0: b8287823    	str	w3, [x1, x8, lsl #2]
1000233c4: 91000508    	add	x8, x8, #0x1
1000233c8: eb1a009f    	cmp	x4, x26
1000233cc: 54006482    	b.hs	0x10002405c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5dc4>
1000233d0: aa0403e3    	mov	x3, x4
1000233d4: aa0403e1    	mov	x1, x4
1000233d8: 14000008    	b	0x1000233f8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5160>
1000233dc: ca0300c3    	eor	x3, x6, x3
1000233e0: dac00063    	rbit	x3, x3
1000233e4: dac01063    	clz	x3, x3
1000233e8: 8b430c84    	add	x4, x4, x3, lsr #3
1000233ec: eb01009f    	cmp	x4, x1
1000233f0: 54fffd88    	b.hi	0x1000233a0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5108>
1000233f4: aa0403e3    	mov	x3, x4
1000233f8: 8b020062    	add	x2, x3, x2
1000233fc: eb1e005f    	cmp	x2, x30
100023400: 54000262    	b.hs	0x10002344c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x51b4>
100023404: 38626ae4    	ldrb	w4, [x23, x2]
100023408: d37f3a02    	ubfiz	x2, x16, #1, #15
10002340c: 8b130065    	add	x5, x3, x19
100023410: eb1e00bf    	cmp	x5, x30
100023414: 54fff362    	b.hs	0x100023280 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4fe8>
100023418: 38656ae5    	ldrb	w5, [x23, x5]
10002341c: 6b05009f    	cmp	w4, w5
100023420: 54fff302    	b.hs	0x100023280 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4fe8>
100023424: 782c78f0    	strh	w16, [x7, x12, lsl #1]
100023428: b240004c    	orr	x12, x2, #0x1
10002342c: aa0003f1    	mov	x17, x0
100023430: aa0303e4    	mov	x4, x3
100023434: 786c78f0    	ldrh	w16, [x7, x12, lsl #1]
100023438: d10005ef    	sub	x15, x15, #0x1
10002343c: eb10017f    	cmp	x11, x16
100023440: fa4039e4    	ccmp	x15, #0x0, #0x4, lo
100023444: 54fff301    	b.ne	0x1000232a4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x500c>
100023448: 14000019    	b	0x1000234ac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5214>
10002344c: 52800004    	mov	w4, #0x0                ; =0
100023450: d37f3a02    	ubfiz	x2, x16, #1, #15
100023454: 8b130065    	add	x5, x3, x19
100023458: eb1e00bf    	cmp	x5, x30
10002345c: 54fffde3    	b.lo	0x100023418 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5180>
100023460: 17ffff88    	b	0x100023280 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4fe8>
100023464: d280000b    	mov	x11, #0x0               ; =0
100023468: eb1b011f    	cmp	x8, x27
10002346c: 540002e9    	b.ls	0x1000234c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5230>
100023470: 529cac2c    	mov	w12, #0xe561            ; =58721
100023474: 72a002cc    	movk	w12, #0x16, lsl #16
100023478: 9100058c    	add	x12, x12, #0x1
10002347c: eb0c011f    	cmp	x8, x12
100023480: aa1603f1    	mov	x17, x22
100023484: 54000082    	b.hs	0x100023494 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x51fc>
100023488: f941afeb    	ldr	x11, [sp, #0x358]
10002348c: 8b08096b    	add	x11, x11, x8, lsl #2
100023490: 785fc16b    	ldurh	w11, [x11, #-0x4]
100023494: aa0a03f0    	mov	x16, x10
100023498: aa0903e1    	mov	x1, x9
10002349c: f9418be9    	ldr	x9, [sp, #0x310]
1000234a0: eb09027f    	cmp	x19, x9
1000234a4: 540005a3    	b.lo	0x100023558 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x52c0>
1000234a8: 1400000e    	b	0x1000234e0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5248>
1000234ac: 5280000b    	mov	w11, #0x0               ; =0
1000234b0: 5280000e    	mov	w14, #0x0               ; =0
1000234b4: 782c78eb    	strh	w11, [x7, x12, lsl #1]
1000234b8: 782d78ee    	strh	w14, [x7, x13, lsl #1]
1000234bc: d280000b    	mov	x11, #0x0               ; =0
1000234c0: eb1b011f    	cmp	x8, x27
1000234c4: 54fffd68    	b.hi	0x100023470 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x51d8>
1000234c8: aa0a03f0    	mov	x16, x10
1000234cc: aa0903e1    	mov	x1, x9
1000234d0: aa1603f1    	mov	x17, x22
1000234d4: f9418be9    	ldr	x9, [sp, #0x310]
1000234d8: eb09027f    	cmp	x19, x9
1000234dc: 540003e3    	b.lo	0x100023558 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x52c0>
1000234e0: f94157e9    	ldr	x9, [sp, #0x2a8]
1000234e4: eb09017f    	cmp	x11, x9
1000234e8: 54000142    	b.hs	0x100023510 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5278>
1000234ec: eb1303df    	cmp	x30, x19
1000234f0: 54005e09    	b.ls	0x1000240b0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5e18>
1000234f4: 38736ae9    	ldrb	w9, [x23, x19]
1000234f8: d3461d2a    	ubfx	x10, x9, #6, #2
1000234fc: 92400129    	and	x9, x9, #0x1
100023500: aa0a0529    	orr	x9, x9, x10, lsl #1
100023504: aa1903ea    	mov	x10, x25
100023508: 5280002c    	mov	w12, #0x1               ; =1
10002350c: 1400000d    	b	0x100023540 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x52a8>
100023510: f100217f    	cmp	x11, #0x8
100023514: 52800409    	mov	w9, #0x20               ; =32
100023518: 5280048a    	mov	w10, #0x24              ; =36
10002351c: 9a898149    	csel	x9, x10, x9, hi
100023520: b8696b2a    	ldr	w10, [x25, x9]
100023524: 1100054a    	add	w10, w10, #0x1
100023528: b8296b2a    	str	w10, [x25, x9]
10002352c: aa0b03e9    	mov	x9, x11
100023530: f9418fea    	ldr	x10, [sp, #0x318]
100023534: aa0b03ec    	mov	x12, x11
100023538: f1040d7f    	cmp	x11, #0x103
10002353c: 54046042    	b.hs	0x10002c144 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xdeac>
100023540: b869794d    	ldr	w13, [x10, x9, lsl #2]
100023544: 110005ad    	add	w13, w13, #0x1
100023548: b829794d    	str	w13, [x10, x9, lsl #2]
10002354c: 8b130189    	add	x9, x12, x19
100023550: f9018be9    	str	x9, [sp, #0x310]
100023554: 9100079c    	add	x28, x28, #0x1
100023558: eb1303df    	cmp	x30, x19
10002355c: 540059e9    	b.ls	0x100024098 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5e00>
100023560: 38736ae9    	ldrb	w9, [x23, x19]
100023564: 53103d29    	lsl	w9, w9, #16
100023568: 529cac2a    	mov	w10, #0xe561            ; =58721
10002356c: 72a002ca    	movk	w10, #0x16, lsl #16
100023570: eb0a011f    	cmp	x8, x10
100023574: 5403c8c2    	b.hs	0x10002ae8c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xcbf4>
100023578: f901b7f5    	str	x21, [sp, #0x368]
10002357c: f9019bfc    	str	x28, [sp, #0x330]
100023580: 4b1b010a    	sub	w10, w8, w27
100023584: 12003d4a    	and	w10, w10, #0xffff
100023588: 2a0a0129    	orr	w9, w9, w10
10002358c: f941afea    	ldr	x10, [sp, #0x358]
100023590: b8287949    	str	w9, [x10, x8, lsl #2]
100023594: 91000669    	add	x9, x19, #0x1
100023598: 9100051b    	add	x27, x8, #0x1
10002359c: f1000d7f    	cmp	x11, #0x3
1000235a0: 54002743    	b.lo	0x100023a88 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x57f0>
1000235a4: eb1a017f    	cmp	x11, x26
1000235a8: 54002703    	b.lo	0x100023a88 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x57f0>
1000235ac: d1000575    	sub	x21, x11, #0x1
1000235b0: b40026d5    	cbz	x21, 0x100023a88 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x57f0>
1000235b4: f94153e8    	ldr	x8, [sp, #0x2a0]
1000235b8: 8b130118    	add	x24, x8, x19
1000235bc: f9414fe8    	ldr	x8, [sp, #0x298]
1000235c0: 8b13011c    	add	x28, x8, x19
1000235c4: aa0903f3    	mov	x19, x9
1000235c8: cb1303d4    	sub	x20, x30, x19
1000235cc: eb11027f    	cmp	x19, x17
1000235d0: 54000ac1    	b.ne	0x100023728 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5490>
1000235d4: f941b3e8    	ldr	x8, [sp, #0x360]
1000235d8: 37000288    	tbnz	w8, #0x0, 0x100023628 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5390>
1000235dc: f941b3e8    	ldr	x8, [sp, #0x360]
1000235e0: b4000088    	cbz	x8, 0x1000235f0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5358>
1000235e4: f85f80e8    	ldur	x8, [x7, #-0x8]
1000235e8: f100051f    	cmp	x8, #0x1
1000235ec: 540001e1    	b.ne	0x100023628 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5390>
1000235f0: d2800008    	mov	x8, #0x0                ; =0
1000235f4: 8b0800e9    	add	x9, x7, x8
1000235f8: ad400520    	ldp	q0, q1, [x9]
1000235fc: ad410d22    	ldp	q2, q3, [x9, #0x20]
100023600: 6e642c00    	uqsub.8h	v0, v0, v4
100023604: 6e642c21    	uqsub.8h	v1, v1, v4
100023608: 6e642c42    	uqsub.8h	v2, v2, v4
10002360c: 6e642c63    	uqsub.8h	v3, v3, v4
100023610: ad000520    	stp	q0, q1, [x9]
100023614: ad010d22    	stp	q2, q3, [x9, #0x20]
100023618: 91010108    	add	x8, x8, #0x40
10002361c: f142011f    	cmp	x8, #0x80, lsl #12      ; =0x80000
100023620: 54fffea1    	b.ne	0x1000235f4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x535c>
100023624: 1400003c    	b	0x100023714 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x547c>
100023628: aa1003f9    	mov	x25, x16
10002362c: f901abfb    	str	x27, [sp, #0x350]
100023630: aa0103fb    	mov	x27, x1
100023634: f90eebff    	str	xzr, [sp, #0x1dd0]
100023638: f90ee7ff    	str	xzr, [sp, #0x1dc8]
10002363c: f90eefff    	str	xzr, [sp, #0x1dd8]
100023640: 912683e0    	add	x0, sp, #0x9a0
100023644: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
100023648: 91372021    	add	x1, x1, #0xdc8
10002364c: 52a00082    	mov	w2, #0x40000            ; =262144
100023650: 52800043    	mov	w3, #0x2                ; =2
100023654: 52800024    	mov	w4, #0x1                ; =1
100023658: aa0703f6    	mov	x22, x7
10002365c: 940038fb    	bl	0x100031a48 <_list.RocList.reallocate>
100023660: aa1603eb    	mov	x11, x22
100023664: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100023668: d2800008    	mov	x8, #0x0                ; =0
10002366c: f944d3f6    	ldr	x22, [sp, #0x9a0]
100023670: f944dbf7    	ldr	x23, [sp, #0x9b0]
100023674: cb0b02c9    	sub	x9, x22, x11
100023678: f101013f    	cmp	x9, #0x40
10002367c: 540001e3    	b.lo	0x1000236b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5420>
100023680: 91008168    	add	x8, x11, #0x20
100023684: 910082c9    	add	x9, x22, #0x20
100023688: 321b33ea    	mov	w10, #0x3ffe0           ; =262112
10002368c: ad7f0500    	ldp	q0, q1, [x8, #-0x20]
100023690: acc20d02    	ldp	q2, q3, [x8], #0x40
100023694: 6e642c00    	uqsub.8h	v0, v0, v4
100023698: 6e642c21    	uqsub.8h	v1, v1, v4
10002369c: 6e642c42    	uqsub.8h	v2, v2, v4
1000236a0: 6e642c63    	uqsub.8h	v3, v3, v4
1000236a4: ad3f0520    	stp	q0, q1, [x9, #-0x20]
1000236a8: ac820d22    	stp	q2, q3, [x9], #0x40
1000236ac: f100814a    	subs	x10, x10, #0x20
1000236b0: 54fffee1    	b.ne	0x10002368c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x53f4>
1000236b4: 321b33e8    	mov	w8, #0x3ffe0            ; =262112
1000236b8: b100051f    	cmn	x8, #0x1
1000236bc: 54038160    	b.eq	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000236c0: 78e87969    	ldrsh	w9, [x11, x8, lsl #1]
1000236c4: 5211012a    	eor	w10, w9, #0x8000
1000236c8: 0a493d49    	and	w9, w10, w9, lsr #15
1000236cc: 78287ac9    	strh	w9, [x22, x8, lsl #1]
1000236d0: 91000508    	add	x8, x8, #0x1
1000236d4: f141011f    	cmp	x8, #0x40, lsl #12      ; =0x40000
1000236d8: 54ffff01    	b.ne	0x1000236b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5420>
1000236dc: f904d3eb    	str	x11, [sp, #0x9a0]
1000236e0: f904d7e8    	str	x8, [sp, #0x9a8]
1000236e4: f941b3e8    	ldr	x8, [sp, #0x360]
1000236e8: f904dbe8    	str	x8, [sp, #0x9b0]
1000236ec: 912683e0    	add	x0, sp, #0x9a0
1000236f0: 940032b4    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000236f4: 4f04a404    	movi.8h	v4, #0x80, lsl #8
1000236f8: aa1603e7    	mov	x7, x22
1000236fc: f901b3f7    	str	x23, [sp, #0x360]
100023700: f9419ff7    	ldr	x23, [sp, #0x338]
100023704: f941a3fe    	ldr	x30, [sp, #0x340]
100023708: aa1b03e1    	mov	x1, x27
10002370c: f941abfb    	ldr	x27, [sp, #0x350]
100023710: aa1903f0    	mov	x16, x25
100023714: f140229f    	cmp	x20, #0x8, lsl #12      ; =0x8000
100023718: 52900008    	mov	w8, #0x8000             ; =32768
10002371c: 9a883288    	csel	x8, x20, x8, lo
100023720: 8b130111    	add	x17, x8, x19
100023724: f901abf3    	str	x19, [sp, #0x350]
100023728: eb14035f    	cmp	x26, x20
10002372c: 9a943348    	csel	x8, x26, x20, lo
100023730: f1040a9f    	cmp	x20, #0x102
100023734: f941b7e9    	ldr	x9, [sp, #0x368]
100023738: 9a893289    	csel	x9, x20, x9, lo
10002373c: 9a9a311a    	csel	x26, x8, x26, lo
100023740: f901b7e9    	str	x9, [sp, #0x368]
100023744: f100153f    	cmp	x9, #0x5
100023748: 54001723    	b.lo	0x100023a2c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5794>
10002374c: ab1a0268    	adds	x8, x19, x26
100023750: 54037cc2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100023754: eb1e011f    	cmp	x8, x30
100023758: 5404b2c8    	b.hi	0x10002cdb0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeb18>
10002375c: 91000668    	add	x8, x19, #0x1
100023760: f941a7e9    	ldr	x9, [sp, #0x348]
100023764: aa1103f6    	mov	x22, x17
100023768: eb09011f    	cmp	x8, x9
10002376c: 54000062    	b.hs	0x100023778 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x54e0>
100023770: b8686ae9    	ldr	w9, [x23, x8]
100023774: 14000002    	b	0x10002377c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x54e4>
100023778: 52800009    	mov	w9, #0x0                ; =0
10002377c: 12005d28    	and	w8, w9, #0xffffff
100023780: 5294f7aa    	mov	w10, #0xa7bd            ; =42941
100023784: 72a3c6aa    	movk	w10, #0x1e35, lsl #16
100023788: 1b0a7d08    	mul	w8, w8, w10
10002378c: 53107d08    	lsr	w8, w8, #16
100023790: 1b0a7d29    	mul	w9, w9, w10
100023794: 53107d29    	lsr	w9, w9, #16
100023798: 8b2848ea    	add	x10, x7, w8, uxtw #2
10002379c: 52a0008e    	mov	w14, #0x40000           ; =262144
1000237a0: f8ae6950    	prfm	pstl1keep, [x10, x14]
1000237a4: 8b2944ea    	add	x10, x7, w9, uxtw #1
1000237a8: 52a0004f    	mov	w15, #0x20000           ; =131072
1000237ac: f8af6950    	prfm	pstl1keep, [x10, x15]
1000237b0: d37e3e0a    	ubfiz	x10, x16, #2, #16
1000237b4: 8b0a00ea    	add	x10, x7, x10
1000237b8: 786e694b    	ldrh	w11, [x10, x14]
1000237bc: 5280004c    	mov	w12, #0x2               ; =2
1000237c0: 72a0008c    	movk	w12, #0x4, lsl #16
1000237c4: 782c694b    	strh	w11, [x10, x12]
1000237c8: d37f3c2b    	ubfiz	x11, x1, #1, #16
1000237cc: 8b0b00eb    	add	x11, x7, x11
1000237d0: 786f6971    	ldrh	w17, [x11, x15]
1000237d4: f941abec    	ldr	x12, [sp, #0x350]
1000237d8: cb0c026c    	sub	x12, x19, x12
1000237dc: eb11019f    	cmp	x12, x17
1000237e0: 5211418d    	eor	w13, w12, #0xffff8000
1000237e4: 782e694d    	strh	w13, [x10, x14]
1000237e8: 782f696d    	strh	w13, [x11, x15]
1000237ec: d37f398a    	ubfiz	x10, x12, #1, #15
1000237f0: 5280002b    	mov	w11, #0x1               ; =1
1000237f4: b37f398b    	bfi	x11, x12, #1, #15
1000237f8: 54001022    	b.hs	0x1000239fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5764>
1000237fc: b400113a    	cbz	x26, 0x100023a20 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5788>
100023800: d2800000    	mov	x0, #0x0                ; =0
100023804: d2800010    	mov	x16, #0x0               ; =0
100023808: d2800003    	mov	x3, #0x0                ; =0
10002380c: 8b1302ed    	add	x13, x23, x19
100023810: f941abee    	ldr	x14, [sp, #0x350]
100023814: 4b0e026e    	sub	w14, w19, w14
100023818: f94197ef    	ldr	x15, [sp, #0x328]
10002381c: aa0703f9    	mov	x25, x7
100023820: 1400000f    	b	0x10002385c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x55c4>
100023824: 782b78f1    	strh	w17, [x7, x11, lsl #1]
100023828: aa1003e2    	mov	x2, x16
10002382c: aa0103eb    	mov	x11, x1
100023830: aa0303e0    	mov	x0, x3
100023834: 786178f1    	ldrh	w17, [x7, x1, lsl #1]
100023838: d10005ef    	sub	x15, x15, #0x1
10002383c: eb11019f    	cmp	x12, x17
100023840: fa4039e4    	ccmp	x15, #0x0, #0x4, lo
100023844: 54000dc0    	b.eq	0x1000239fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5764>
100023848: eb03021f    	cmp	x16, x3
10002384c: 9a833203    	csel	x3, x16, x3, lo
100023850: aa0203f0    	mov	x16, x2
100023854: eb1a007f    	cmp	x3, x26
100023858: 54000e42    	b.hs	0x100023a20 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5788>
10002385c: 92403e21    	and	x1, x17, #0xffff
100023860: 4b110182    	sub	w2, w12, w17
100023864: 92403842    	and	x2, x2, #0x7fff
100023868: eb020262    	subs	x2, x19, x2
10002386c: 9a8233e2    	csel	x2, xzr, x2, lo
100023870: 8b0202e4    	add	x4, x23, x2
100023874: 38636884    	ldrb	w4, [x4, x3]
100023878: 386369a5    	ldrb	w5, [x13, x3]
10002387c: 6b05009f    	cmp	w4, w5
100023880: 54000881    	b.ne	0x100023990 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x56f8>
100023884: eb13005f    	cmp	x2, x19
100023888: 54048002    	b.hs	0x10002c888 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe5f0>
10002388c: 91000464    	add	x4, x3, #0x1
100023890: 91008463    	add	x3, x3, #0x21
100023894: eb1a007f    	cmp	x3, x26
100023898: 54000249    	b.ls	0x1000238e0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5648>
10002389c: b1002086    	adds	x6, x4, #0x8
1000238a0: 54037242    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000238a4: 4b1101c3    	sub	w3, w14, w17
1000238a8: 92403865    	and	x5, x3, #0x7fff
1000238ac: eb05027f    	cmp	x19, x5
1000238b0: 9a853265    	csel	x5, x19, x5, lo
1000238b4: cb050385    	sub	x5, x28, x5
1000238b8: eb1a00df    	cmp	x6, x26
1000238bc: 540003c8    	b.hi	0x100023934 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x569c>
1000238c0: f8646b86    	ldr	x6, [x28, x4]
1000238c4: f86468a7    	ldr	x7, [x5, x4]
1000238c8: eb0600ff    	cmp	x7, x6
1000238cc: 54000521    	b.ne	0x100023970 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x56d8>
1000238d0: b1004086    	adds	x6, x4, #0x10
1000238d4: 91002084    	add	x4, x4, #0x8
1000238d8: 54ffff03    	b.lo	0x1000238b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5620>
1000238dc: 14001b83    	b	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000238e0: 4b1101c5    	sub	w5, w14, w17
1000238e4: 924038a5    	and	x5, x5, #0x7fff
1000238e8: eb05027f    	cmp	x19, x5
1000238ec: 9a853265    	csel	x5, x19, x5, lo
1000238f0: cb050306    	sub	x6, x24, x5
1000238f4: 91002085    	add	x5, x4, #0x8
1000238f8: eb0300bf    	cmp	x5, x3
1000238fc: 54fffd08    	b.hi	0x10002389c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5604>
100023900: 8b040307    	add	x7, x24, x4
100023904: f85ff0e7    	ldur	x7, [x7, #-0x1]
100023908: 8b0400c4    	add	x4, x6, x4
10002390c: f85ff094    	ldur	x20, [x4, #-0x1]
100023910: aa0503e4    	mov	x4, x5
100023914: eb07029f    	cmp	x20, x7
100023918: 54fffee0    	b.eq	0x1000238f4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x565c>
10002391c: ca070283    	eor	x3, x20, x7
100023920: dac00063    	rbit	x3, x3
100023924: dac01063    	clz	x3, x3
100023928: 8b430ca3    	add	x3, x5, x3, lsr #3
10002392c: d1002064    	sub	x4, x3, #0x8
100023930: 14000014    	b	0x100023980 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x56e8>
100023934: eb1a009f    	cmp	x4, x26
100023938: 54000242    	b.hs	0x100023980 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x56e8>
10002393c: 92403863    	and	x3, x3, #0x7fff
100023940: eb03027f    	cmp	x19, x3
100023944: 9a833263    	csel	x3, x19, x3, lo
100023948: cb030383    	sub	x3, x28, x3
10002394c: aa1903e7    	mov	x7, x25
100023950: 38646b85    	ldrb	w5, [x28, x4]
100023954: 38646866    	ldrb	w6, [x3, x4]
100023958: 6b0600bf    	cmp	w5, w6
10002395c: 54000141    	b.ne	0x100023984 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x56ec>
100023960: 91000484    	add	x4, x4, #0x1
100023964: eb04035f    	cmp	x26, x4
100023968: 54ffff41    	b.ne	0x100023950 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x56b8>
10002396c: 14000027    	b	0x100023a08 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5770>
100023970: ca0600e3    	eor	x3, x7, x6
100023974: dac00063    	rbit	x3, x3
100023978: dac01063    	clz	x3, x3
10002397c: 8b430c84    	add	x4, x4, x3, lsr #3
100023980: aa1903e7    	mov	x7, x25
100023984: aa0403e3    	mov	x3, x4
100023988: eb1a009f    	cmp	x4, x26
10002398c: 540003e2    	b.hs	0x100023a08 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5770>
100023990: 8b020062    	add	x2, x3, x2
100023994: eb1e005f    	cmp	x2, x30
100023998: 54000262    	b.hs	0x1000239e4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x574c>
10002399c: 38626ae2    	ldrb	w2, [x23, x2]
1000239a0: d37f3821    	ubfiz	x1, x1, #1, #15
1000239a4: 8b130064    	add	x4, x3, x19
1000239a8: eb1e009f    	cmp	x4, x30
1000239ac: 54fff3c2    	b.hs	0x100023824 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x558c>
1000239b0: 38646ae4    	ldrb	w4, [x23, x4]
1000239b4: 6b04005f    	cmp	w2, w4
1000239b8: 54fff362    	b.hs	0x100023824 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x558c>
1000239bc: 782a78f1    	strh	w17, [x7, x10, lsl #1]
1000239c0: b240002a    	orr	x10, x1, #0x1
1000239c4: aa0003f0    	mov	x16, x0
1000239c8: aa0303e2    	mov	x2, x3
1000239cc: 786a78f1    	ldrh	w17, [x7, x10, lsl #1]
1000239d0: d10005ef    	sub	x15, x15, #0x1
1000239d4: eb11019f    	cmp	x12, x17
1000239d8: fa4039e4    	ccmp	x15, #0x0, #0x4, lo
1000239dc: 54fff361    	b.ne	0x100023848 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x55b0>
1000239e0: 14000007    	b	0x1000239fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5764>
1000239e4: 52800002    	mov	w2, #0x0                ; =0
1000239e8: d37f3821    	ubfiz	x1, x1, #1, #15
1000239ec: 8b130064    	add	x4, x3, x19
1000239f0: eb1e009f    	cmp	x4, x30
1000239f4: 54fffde3    	b.lo	0x1000239b0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5718>
1000239f8: 17ffff8b    	b	0x100023824 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x558c>
1000239fc: 5280000c    	mov	w12, #0x0               ; =0
100023a00: 5280000d    	mov	w13, #0x0               ; =0
100023a04: 14000005    	b	0x100023a18 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5780>
100023a08: d37e382c    	ubfiz	x12, x1, #2, #15
100023a0c: 8b0c00ec    	add	x12, x7, x12
100023a10: 7940058d    	ldrh	w13, [x12, #0x2]
100023a14: 7940018c    	ldrh	w12, [x12]
100023a18: 782a78ec    	strh	w12, [x7, x10, lsl #1]
100023a1c: 782b78ed    	strh	w13, [x7, x11, lsl #1]
100023a20: aa0803f0    	mov	x16, x8
100023a24: aa0903e1    	mov	x1, x9
100023a28: aa1603f1    	mov	x17, x22
100023a2c: eb1303df    	cmp	x30, x19
100023a30: 54000209    	b.ls	0x100023a70 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x57d8>
100023a34: 38736ae8    	ldrb	w8, [x23, x19]
100023a38: 53103d08    	lsl	w8, w8, #16
100023a3c: 529cac29    	mov	w9, #0xe561             ; =58721
100023a40: 72a002c9    	movk	w9, #0x16, lsl #16
100023a44: eb09037f    	cmp	x27, x9
100023a48: 54036ea0    	b.eq	0x10002a81c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc584>
100023a4c: f941afe9    	ldr	x9, [sp, #0x358]
100023a50: b83b7928    	str	w8, [x9, x27, lsl #2]
100023a54: 91000673    	add	x19, x19, #0x1
100023a58: 9100077b    	add	x27, x27, #0x1
100023a5c: 91000718    	add	x24, x24, #0x1
100023a60: 9100079c    	add	x28, x28, #0x1
100023a64: f10006b5    	subs	x21, x21, #0x1
100023a68: 54ffdb01    	b.ne	0x1000235c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5330>
100023a6c: 14000008    	b	0x100023a8c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x57f4>
100023a70: 52800008    	mov	w8, #0x0                ; =0
100023a74: 529cac29    	mov	w9, #0xe561             ; =58721
100023a78: 72a002c9    	movk	w9, #0x16, lsl #16
100023a7c: eb09037f    	cmp	x27, x9
100023a80: 54fffe61    	b.ne	0x100023a4c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x57b4>
100023a84: 14001b66    	b	0x10002a81c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc584>
100023a88: aa0903f3    	mov	x19, x9
100023a8c: 529cac28    	mov	w8, #0xe561             ; =58721
100023a90: 72a002c8    	movk	w8, #0x16, lsl #16
100023a94: d1080508    	sub	x8, x8, #0x201
100023a98: f94187e9    	ldr	x9, [sp, #0x308]
100023a9c: eb09027f    	cmp	x19, x9
100023aa0: fa483362    	ccmp	x27, x8, #0x2, lo
100023aa4: 1a9f27f6    	cset	w22, lo
100023aa8: 710006df    	cmp	w22, #0x1
100023aac: f94193f9    	ldr	x25, [sp, #0x320]
100023ab0: f9419bfc    	ldr	x28, [sp, #0x330]
100023ab4: f941b7f5    	ldr	x21, [sp, #0x368]
100023ab8: 540034e1    	b.ne	0x100024154 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5ebc>
100023abc: f108039f    	cmp	x28, #0x200
100023ac0: 54ffa2c3    	b.lo	0x100022f18 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4c80>
100023ac4: f94183e8    	ldr	x8, [sp, #0x300]
100023ac8: cb080268    	sub	x8, x19, x8
100023acc: d343fd09    	lsr	x9, x8, #3
100023ad0: f109c53f    	cmp	x9, #0x271
100023ad4: 54ffa223    	b.lo	0x100022f18 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4c80>
100023ad8: cb1303c9    	sub	x9, x30, x19
100023adc: d343fd29    	lsr	x9, x9, #3
100023ae0: f109c53f    	cmp	x9, #0x271
100023ae4: 54ffa1a3    	b.lo	0x100022f18 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4c80>
100023ae8: f9410fe9    	ldr	x9, [sp, #0x218]
100023aec: b4001d69    	cbz	x9, 0x100023e98 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5c00>
100023af0: f94147e9    	ldr	x9, [sp, #0x288]
100023af4: b4002e29    	cbz	x9, 0x1000240b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5e20>
100023af8: f94123e9    	ldr	x9, [sp, #0x240]
100023afc: b940012a    	ldr	w10, [x9]
100023b00: 9b1c7d49    	mul	x9, x10, x28
100023b04: 9bdc7d4a    	umulh	x10, x10, x28
100023b08: eb0a03ff    	cmp	xzr, x10
100023b0c: 1a9f07ea    	cset	w10, ne
100023b10: 3701578a    	tbnz	w10, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100023b14: b940032a    	ldr	w10, [x25]
100023b18: f9410fec    	ldr	x12, [sp, #0x218]
100023b1c: 9bcc7d4b    	umulh	x11, x10, x12
100023b20: eb0b03ff    	cmp	xzr, x11
100023b24: 540156e1    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100023b28: 9b0c7d4a    	mul	x10, x10, x12
100023b2c: eb090149    	subs	x9, x10, x9
100023b30: da898529    	cneg	x9, x9, ls
100023b34: f94147ea    	ldr	x10, [sp, #0x288]
100023b38: f100095f    	cmp	x10, #0x2
100023b3c: 54002c43    	b.lo	0x1000240c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5e2c>
100023b40: f94123ea    	ldr	x10, [sp, #0x240]
100023b44: b940054b    	ldr	w11, [x10, #0x4]
100023b48: 9b1c7d6a    	mul	x10, x11, x28
100023b4c: 9bdc7d6b    	umulh	x11, x11, x28
100023b50: eb0b03ff    	cmp	xzr, x11
100023b54: 1a9f07eb    	cset	w11, ne
100023b58: 3701554b    	tbnz	w11, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100023b5c: b940072b    	ldr	w11, [x25, #0x4]
100023b60: f9410fed    	ldr	x13, [sp, #0x218]
100023b64: 9bcd7d6c    	umulh	x12, x11, x13
100023b68: eb0c03ff    	cmp	xzr, x12
100023b6c: 540154a1    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100023b70: 9b0d7d6b    	mul	x11, x11, x13
100023b74: eb0a016a    	subs	x10, x11, x10
100023b78: da8a854a    	cneg	x10, x10, ls
100023b7c: ab0a0129    	adds	x9, x9, x10
100023b80: 54035b42    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100023b84: f94147ea    	ldr	x10, [sp, #0x288]
100023b88: f1000d5f    	cmp	x10, #0x3
100023b8c: 54002a43    	b.lo	0x1000240d4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5e3c>
100023b90: f94123ea    	ldr	x10, [sp, #0x240]
100023b94: b940094b    	ldr	w11, [x10, #0x8]
100023b98: 9b1c7d6a    	mul	x10, x11, x28
100023b9c: 9bdc7d6b    	umulh	x11, x11, x28
100023ba0: eb0b03ff    	cmp	xzr, x11
100023ba4: 1a9f07eb    	cset	w11, ne
100023ba8: 370152cb    	tbnz	w11, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100023bac: b9400b2b    	ldr	w11, [x25, #0x8]
100023bb0: f9410fed    	ldr	x13, [sp, #0x218]
100023bb4: 9bcd7d6c    	umulh	x12, x11, x13
100023bb8: eb0c03ff    	cmp	xzr, x12
100023bbc: 54015221    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100023bc0: 9b0d7d6b    	mul	x11, x11, x13
100023bc4: eb0a016a    	subs	x10, x11, x10
100023bc8: da8a854a    	cneg	x10, x10, ls
100023bcc: ab0a0129    	adds	x9, x9, x10
100023bd0: 540358c2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100023bd4: f94147ea    	ldr	x10, [sp, #0x288]
100023bd8: f100115f    	cmp	x10, #0x4
100023bdc: 54002843    	b.lo	0x1000240e4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5e4c>
100023be0: f94123ea    	ldr	x10, [sp, #0x240]
100023be4: b9400d4b    	ldr	w11, [x10, #0xc]
100023be8: 9b1c7d6a    	mul	x10, x11, x28
100023bec: 9bdc7d6b    	umulh	x11, x11, x28
100023bf0: eb0b03ff    	cmp	xzr, x11
100023bf4: 1a9f07eb    	cset	w11, ne
100023bf8: 3701504b    	tbnz	w11, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100023bfc: b9400f2b    	ldr	w11, [x25, #0xc]
100023c00: f9410fed    	ldr	x13, [sp, #0x218]
100023c04: 9bcd7d6c    	umulh	x12, x11, x13
100023c08: eb0c03ff    	cmp	xzr, x12
100023c0c: 54014fa1    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100023c10: 9b0d7d6b    	mul	x11, x11, x13
100023c14: eb0a016a    	subs	x10, x11, x10
100023c18: da8a854a    	cneg	x10, x10, ls
100023c1c: ab0a0129    	adds	x9, x9, x10
100023c20: 54035642    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100023c24: f94147ea    	ldr	x10, [sp, #0x288]
100023c28: f100155f    	cmp	x10, #0x5
100023c2c: 54002643    	b.lo	0x1000240f4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5e5c>
100023c30: f94123ea    	ldr	x10, [sp, #0x240]
100023c34: b940114b    	ldr	w11, [x10, #0x10]
100023c38: 9b1c7d6a    	mul	x10, x11, x28
100023c3c: 9bdc7d6b    	umulh	x11, x11, x28
100023c40: eb0b03ff    	cmp	xzr, x11
100023c44: 1a9f07eb    	cset	w11, ne
100023c48: 37014dcb    	tbnz	w11, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100023c4c: b940132b    	ldr	w11, [x25, #0x10]
100023c50: f9410fed    	ldr	x13, [sp, #0x218]
100023c54: 9bcd7d6c    	umulh	x12, x11, x13
100023c58: eb0c03ff    	cmp	xzr, x12
100023c5c: 54014d21    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100023c60: 9b0d7d6b    	mul	x11, x11, x13
100023c64: eb0a016a    	subs	x10, x11, x10
100023c68: da8a854a    	cneg	x10, x10, ls
100023c6c: ab0a0129    	adds	x9, x9, x10
100023c70: 540353c2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100023c74: f94147ea    	ldr	x10, [sp, #0x288]
100023c78: f100195f    	cmp	x10, #0x6
100023c7c: 54002443    	b.lo	0x100024104 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5e6c>
100023c80: f94123ea    	ldr	x10, [sp, #0x240]
100023c84: b940154b    	ldr	w11, [x10, #0x14]
100023c88: 9b1c7d6a    	mul	x10, x11, x28
100023c8c: 9bdc7d6b    	umulh	x11, x11, x28
100023c90: eb0b03ff    	cmp	xzr, x11
100023c94: 1a9f07eb    	cset	w11, ne
100023c98: 37014b4b    	tbnz	w11, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100023c9c: b940172b    	ldr	w11, [x25, #0x14]
100023ca0: f9410fed    	ldr	x13, [sp, #0x218]
100023ca4: 9bcd7d6c    	umulh	x12, x11, x13
100023ca8: eb0c03ff    	cmp	xzr, x12
100023cac: 54014aa1    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100023cb0: 9b0d7d6b    	mul	x11, x11, x13
100023cb4: eb0a016a    	subs	x10, x11, x10
100023cb8: da8a854a    	cneg	x10, x10, ls
100023cbc: ab0a0129    	adds	x9, x9, x10
100023cc0: 54035142    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100023cc4: f94147ea    	ldr	x10, [sp, #0x288]
100023cc8: f1001d5f    	cmp	x10, #0x7
100023ccc: 54002243    	b.lo	0x100024114 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5e7c>
100023cd0: f94123ea    	ldr	x10, [sp, #0x240]
100023cd4: b940194b    	ldr	w11, [x10, #0x18]
100023cd8: 9b1c7d6a    	mul	x10, x11, x28
100023cdc: 9bdc7d6b    	umulh	x11, x11, x28
100023ce0: eb0b03ff    	cmp	xzr, x11
100023ce4: 1a9f07eb    	cset	w11, ne
100023ce8: 370148cb    	tbnz	w11, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100023cec: b9401b2b    	ldr	w11, [x25, #0x18]
100023cf0: f9410fed    	ldr	x13, [sp, #0x218]
100023cf4: 9bcd7d6c    	umulh	x12, x11, x13
100023cf8: eb0c03ff    	cmp	xzr, x12
100023cfc: 54014821    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100023d00: 9b0d7d6b    	mul	x11, x11, x13
100023d04: eb0a016a    	subs	x10, x11, x10
100023d08: da8a854a    	cneg	x10, x10, ls
100023d0c: ab0a0129    	adds	x9, x9, x10
100023d10: 54034ec2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100023d14: f94147ea    	ldr	x10, [sp, #0x288]
100023d18: f100215f    	cmp	x10, #0x8
100023d1c: 54002043    	b.lo	0x100024124 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5e8c>
100023d20: f94123ea    	ldr	x10, [sp, #0x240]
100023d24: b9401d4b    	ldr	w11, [x10, #0x1c]
100023d28: 9b1c7d6a    	mul	x10, x11, x28
100023d2c: 9bdc7d6b    	umulh	x11, x11, x28
100023d30: eb0b03ff    	cmp	xzr, x11
100023d34: 1a9f07eb    	cset	w11, ne
100023d38: 3701464b    	tbnz	w11, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100023d3c: b9401f2b    	ldr	w11, [x25, #0x1c]
100023d40: f9410fed    	ldr	x13, [sp, #0x218]
100023d44: 9bcd7d6c    	umulh	x12, x11, x13
100023d48: eb0c03ff    	cmp	xzr, x12
100023d4c: 540145a1    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100023d50: 9b0d7d6b    	mul	x11, x11, x13
100023d54: eb0a016a    	subs	x10, x11, x10
100023d58: da8a854a    	cneg	x10, x10, ls
100023d5c: ab0a0129    	adds	x9, x9, x10
100023d60: 54034c42    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100023d64: f94147ea    	ldr	x10, [sp, #0x288]
100023d68: f100255f    	cmp	x10, #0x9
100023d6c: 54001e43    	b.lo	0x100024134 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5e9c>
100023d70: f94123ea    	ldr	x10, [sp, #0x240]
100023d74: b940214b    	ldr	w11, [x10, #0x20]
100023d78: 9b1c7d6a    	mul	x10, x11, x28
100023d7c: 9bdc7d6b    	umulh	x11, x11, x28
100023d80: eb0b03ff    	cmp	xzr, x11
100023d84: 1a9f07eb    	cset	w11, ne
100023d88: 370143cb    	tbnz	w11, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100023d8c: b940232b    	ldr	w11, [x25, #0x20]
100023d90: f9410fed    	ldr	x13, [sp, #0x218]
100023d94: 9bcd7d6c    	umulh	x12, x11, x13
100023d98: eb0c03ff    	cmp	xzr, x12
100023d9c: 54014321    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100023da0: 9b0d7d6b    	mul	x11, x11, x13
100023da4: eb0a016a    	subs	x10, x11, x10
100023da8: da8a854a    	cneg	x10, x10, ls
100023dac: ab0a0129    	adds	x9, x9, x10
100023db0: 540349c2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100023db4: f94147ea    	ldr	x10, [sp, #0x288]
100023db8: f100295f    	cmp	x10, #0xa
100023dbc: 54001c43    	b.lo	0x100024144 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5eac>
100023dc0: f94123ea    	ldr	x10, [sp, #0x240]
100023dc4: b940254b    	ldr	w11, [x10, #0x24]
100023dc8: 9b1c7d6a    	mul	x10, x11, x28
100023dcc: 9bdc7d6b    	umulh	x11, x11, x28
100023dd0: eb0b03ff    	cmp	xzr, x11
100023dd4: 1a9f07eb    	cset	w11, ne
100023dd8: 3701414b    	tbnz	w11, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100023ddc: b940272b    	ldr	w11, [x25, #0x24]
100023de0: f9410fed    	ldr	x13, [sp, #0x218]
100023de4: 9bcd7d6c    	umulh	x12, x11, x13
100023de8: eb0c03ff    	cmp	xzr, x12
100023dec: 540140a1    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100023df0: 9b0d7d6b    	mul	x11, x11, x13
100023df4: eb0a016a    	subs	x10, x11, x10
100023df8: da8a854a    	cneg	x10, x10, ls
100023dfc: ab0a0129    	adds	x9, x9, x10
100023e00: 54034742    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100023e04: f9410fea    	ldr	x10, [sp, #0x218]
100023e08: ab1c014b    	adds	x11, x10, x28
100023e0c: 5280190c    	mov	w12, #0xc8              ; =200
100023e10: 540346c2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100023e14: 9bcc7f8a    	umulh	x10, x28, x12
100023e18: eb0a03ff    	cmp	xzr, x10
100023e1c: 54013f21    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100023e20: 9b0c7f8a    	mul	x10, x28, x12
100023e24: d349fd4a    	lsr	x10, x10, #9
100023e28: f9410fed    	ldr	x13, [sp, #0x218]
100023e2c: 9bcd7d4c    	umulh	x12, x10, x13
100023e30: eb0c03ff    	cmp	xzr, x12
100023e34: 54013e61    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100023e38: 9b0d7d4a    	mul	x10, x10, x13
100023e3c: d344fd0c    	lsr	x12, x8, #4
100023e40: f109c19f    	cmp	x12, #0x270
100023e44: 54000168    	b.hi	0x100023e70 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5bd8>
100023e48: d34dfd6c    	lsr	x12, x11, #13
100023e4c: b500012c    	cbnz	x12, 0x100023e70 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5bd8>
100023e50: 5284000c    	mov	w12, #0x2000            ; =8192
100023e54: cb0b018b    	sub	x11, x12, x11
100023e58: 9bcb7d4c    	umulh	x12, x10, x11
100023e5c: eb0c03ff    	cmp	xzr, x12
100023e60: 54013d01    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100023e64: 9b0b7d4b    	mul	x11, x10, x11
100023e68: ab4b354a    	adds	x10, x10, x11, lsr #13
100023e6c: 540343e2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100023e70: d34cfd08    	lsr	x8, x8, #12
100023e74: f9410fec    	ldr	x12, [sp, #0x218]
100023e78: 9bcc7d0b    	umulh	x11, x8, x12
100023e7c: eb0b03ff    	cmp	xzr, x11
100023e80: 54013c01    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100023e84: 9b0c7d08    	mul	x8, x8, x12
100023e88: ab080128    	adds	x8, x9, x8
100023e8c: 540342e2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100023e90: eb0a011f    	cmp	x8, x10
100023e94: 54001602    	b.hs	0x100024154 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5ebc>
100023e98: f94147e8    	ldr	x8, [sp, #0x288]
100023e9c: b4047328    	cbz	x8, 0x10002cd00 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xea68>
100023ea0: f94123ea    	ldr	x10, [sp, #0x240]
100023ea4: b9400148    	ldr	w8, [x10]
100023ea8: b9400329    	ldr	w9, [x25]
100023eac: 2b090108    	adds	w8, w8, w9
100023eb0: 540341c2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100023eb4: b9000148    	str	w8, [x10]
100023eb8: b900033f    	str	wzr, [x25]
100023ebc: f94147e8    	ldr	x8, [sp, #0x288]
100023ec0: f100051f    	cmp	x8, #0x1
100023ec4: 54047420    	b.eq	0x10002cd48 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeab0>
100023ec8: b9400548    	ldr	w8, [x10, #0x4]
100023ecc: b9400729    	ldr	w9, [x25, #0x4]
100023ed0: 2b090108    	adds	w8, w8, w9
100023ed4: 540340a2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100023ed8: b9000548    	str	w8, [x10, #0x4]
100023edc: b900073f    	str	wzr, [x25, #0x4]
100023ee0: f94147e8    	ldr	x8, [sp, #0x288]
100023ee4: f1000d1f    	cmp	x8, #0x3
100023ee8: 54047103    	b.lo	0x10002cd08 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xea70>
100023eec: b9400948    	ldr	w8, [x10, #0x8]
100023ef0: b9400b29    	ldr	w9, [x25, #0x8]
100023ef4: 2b090108    	adds	w8, w8, w9
100023ef8: 54033f82    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100023efc: b9000948    	str	w8, [x10, #0x8]
100023f00: b9000b3f    	str	wzr, [x25, #0x8]
100023f04: f94147e8    	ldr	x8, [sp, #0x288]
100023f08: f100111f    	cmp	x8, #0x4
100023f0c: 540470e3    	b.lo	0x10002cd28 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xea90>
100023f10: b9400d48    	ldr	w8, [x10, #0xc]
100023f14: b9400f29    	ldr	w9, [x25, #0xc]
100023f18: 2b090108    	adds	w8, w8, w9
100023f1c: 54033e62    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100023f20: b9000d48    	str	w8, [x10, #0xc]
100023f24: b9000f3f    	str	wzr, [x25, #0xc]
100023f28: f94147e8    	ldr	x8, [sp, #0x288]
100023f2c: f100151f    	cmp	x8, #0x5
100023f30: 54046f03    	b.lo	0x10002cd10 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xea78>
100023f34: b9401148    	ldr	w8, [x10, #0x10]
100023f38: b9401329    	ldr	w9, [x25, #0x10]
100023f3c: 2b090108    	adds	w8, w8, w9
100023f40: 54033d42    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100023f44: b9001148    	str	w8, [x10, #0x10]
100023f48: b900133f    	str	wzr, [x25, #0x10]
100023f4c: f94147e8    	ldr	x8, [sp, #0x288]
100023f50: f100191f    	cmp	x8, #0x6
100023f54: 54046ee3    	b.lo	0x10002cd30 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xea98>
100023f58: b9401548    	ldr	w8, [x10, #0x14]
100023f5c: b9401729    	ldr	w9, [x25, #0x14]
100023f60: 2b090108    	adds	w8, w8, w9
100023f64: 54033c22    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100023f68: b9001548    	str	w8, [x10, #0x14]
100023f6c: b900173f    	str	wzr, [x25, #0x14]
100023f70: f94147e8    	ldr	x8, [sp, #0x288]
100023f74: f1001d1f    	cmp	x8, #0x7
100023f78: 54046d03    	b.lo	0x10002cd18 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xea80>
100023f7c: b9401948    	ldr	w8, [x10, #0x18]
100023f80: b9401b29    	ldr	w9, [x25, #0x18]
100023f84: 2b090108    	adds	w8, w8, w9
100023f88: 54033b02    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100023f8c: b9001948    	str	w8, [x10, #0x18]
100023f90: b9001b3f    	str	wzr, [x25, #0x18]
100023f94: f94147e8    	ldr	x8, [sp, #0x288]
100023f98: f100211f    	cmp	x8, #0x8
100023f9c: 54046ce3    	b.lo	0x10002cd38 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeaa0>
100023fa0: b9401d48    	ldr	w8, [x10, #0x1c]
100023fa4: b9401f29    	ldr	w9, [x25, #0x1c]
100023fa8: 2b090108    	adds	w8, w8, w9
100023fac: 540339e2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100023fb0: b9001d48    	str	w8, [x10, #0x1c]
100023fb4: b9001f3f    	str	wzr, [x25, #0x1c]
100023fb8: f94147e8    	ldr	x8, [sp, #0x288]
100023fbc: f100251f    	cmp	x8, #0x9
100023fc0: 54046b03    	b.lo	0x10002cd20 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xea88>
100023fc4: b9402148    	ldr	w8, [x10, #0x20]
100023fc8: b9402329    	ldr	w9, [x25, #0x20]
100023fcc: 2b090108    	adds	w8, w8, w9
100023fd0: 540338c2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100023fd4: b9002148    	str	w8, [x10, #0x20]
100023fd8: b900233f    	str	wzr, [x25, #0x20]
100023fdc: f94147e8    	ldr	x8, [sp, #0x288]
100023fe0: f100291f    	cmp	x8, #0xa
100023fe4: 54046ae3    	b.lo	0x10002cd40 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeaa8>
100023fe8: b9402548    	ldr	w8, [x10, #0x24]
100023fec: b9402729    	ldr	w9, [x25, #0x24]
100023ff0: 2b090108    	adds	w8, w8, w9
100023ff4: 540337a2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100023ff8: b9002548    	str	w8, [x10, #0x24]
100023ffc: b900273f    	str	wzr, [x25, #0x24]
100024000: f9410fe8    	ldr	x8, [sp, #0x218]
100024004: ab1c0108    	adds	x8, x8, x28
100024008: f9010fe8    	str	x8, [sp, #0x218]
10002400c: 540336e2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100024010: d2800008    	mov	x8, #0x0                ; =0
100024014: 14000004    	b	0x100024024 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5d8c>
100024018: 91000508    	add	x8, x8, #0x1
10002401c: f1040d1f    	cmp	x8, #0x103
100024020: 54000320    	b.eq	0x100024084 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5dec>
100024024: f9418fe9    	ldr	x9, [sp, #0x318]
100024028: b8687929    	ldr	w9, [x9, x8, lsl #2]
10002402c: 34ffff69    	cbz	w9, 0x100024018 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5d80>
100024030: f94163ea    	ldr	x10, [sp, #0x2c0]
100024034: eb0a011f    	cmp	x8, x10
100024038: 5403db02    	b.hs	0x10002bb98 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xd900>
10002403c: f9415feb    	ldr	x11, [sp, #0x2b8]
100024040: b868796a    	ldr	w10, [x11, x8, lsl #2]
100024044: 2b090149    	adds	w9, w10, w9
100024048: 54033502    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10002404c: b8287969    	str	w9, [x11, x8, lsl #2]
100024050: f9418fe9    	ldr	x9, [sp, #0x318]
100024054: b828793f    	str	wzr, [x9, x8, lsl #2]
100024058: 17fffff0    	b	0x100024018 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5d80>
10002405c: d37e3a0b    	ubfiz	x11, x16, #2, #15
100024060: 8b0b00eb    	add	x11, x7, x11
100024064: 7940056e    	ldrh	w14, [x11, #0x2]
100024068: 7940016b    	ldrh	w11, [x11]
10002406c: 782c78eb    	strh	w11, [x7, x12, lsl #1]
100024070: 782d78ee    	strh	w14, [x7, x13, lsl #1]
100024074: d280000b    	mov	x11, #0x0               ; =0
100024078: eb1b011f    	cmp	x8, x27
10002407c: 54ff9fa8    	b.hi	0x100023470 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x51d8>
100024080: 17fffd12    	b	0x1000234c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5230>
100024084: d280001c    	mov	x28, #0x0               ; =0
100024088: 52800028    	mov	w8, #0x1                ; =1
10002408c: b901e3e8    	str	w8, [sp, #0x1e0]
100024090: f900f7f3    	str	x19, [sp, #0x1e8]
100024094: 17fffba1    	b	0x100022f18 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4c80>
100024098: 52800009    	mov	w9, #0x0                ; =0
10002409c: 529cac2a    	mov	w10, #0xe561            ; =58721
1000240a0: 72a002ca    	movk	w10, #0x16, lsl #16
1000240a4: eb0a011f    	cmp	x8, x10
1000240a8: 54ffa683    	b.lo	0x100023578 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x52e0>
1000240ac: 14001b78    	b	0x10002ae8c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xcbf4>
1000240b0: d2800009    	mov	x9, #0x0                ; =0
1000240b4: 17fffd11    	b	0x1000234f8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5260>
1000240b8: 5280000a    	mov	w10, #0x0               ; =0
1000240bc: 3607d2ca    	tbz	w10, #0x0, 0x100023b14 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x587c>
1000240c0: 14000950    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
1000240c4: d280000a    	mov	x10, #0x0               ; =0
1000240c8: 5280000b    	mov	w11, #0x0               ; =0
1000240cc: 3607d48b    	tbz	w11, #0x0, 0x100023b5c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x58c4>
1000240d0: 1400094c    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
1000240d4: d280000a    	mov	x10, #0x0               ; =0
1000240d8: 5280000b    	mov	w11, #0x0               ; =0
1000240dc: 3607d68b    	tbz	w11, #0x0, 0x100023bac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5914>
1000240e0: 14000948    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
1000240e4: d280000a    	mov	x10, #0x0               ; =0
1000240e8: 5280000b    	mov	w11, #0x0               ; =0
1000240ec: 3607d88b    	tbz	w11, #0x0, 0x100023bfc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5964>
1000240f0: 14000944    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
1000240f4: d280000a    	mov	x10, #0x0               ; =0
1000240f8: 5280000b    	mov	w11, #0x0               ; =0
1000240fc: 3607da8b    	tbz	w11, #0x0, 0x100023c4c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x59b4>
100024100: 14000940    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100024104: d280000a    	mov	x10, #0x0               ; =0
100024108: 5280000b    	mov	w11, #0x0               ; =0
10002410c: 3607dc8b    	tbz	w11, #0x0, 0x100023c9c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5a04>
100024110: 1400093c    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100024114: d280000a    	mov	x10, #0x0               ; =0
100024118: 5280000b    	mov	w11, #0x0               ; =0
10002411c: 3607de8b    	tbz	w11, #0x0, 0x100023cec <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5a54>
100024120: 14000938    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100024124: d280000a    	mov	x10, #0x0               ; =0
100024128: 5280000b    	mov	w11, #0x0               ; =0
10002412c: 3607e08b    	tbz	w11, #0x0, 0x100023d3c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5aa4>
100024130: 14000934    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100024134: d280000a    	mov	x10, #0x0               ; =0
100024138: 5280000b    	mov	w11, #0x0               ; =0
10002413c: 3607e28b    	tbz	w11, #0x0, 0x100023d8c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5af4>
100024140: 14000930    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100024144: d280000a    	mov	x10, #0x0               ; =0
100024148: 5280000b    	mov	w11, #0x0               ; =0
10002414c: 3607e48b    	tbz	w11, #0x0, 0x100023ddc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5b44>
100024150: 1400092c    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100024154: b941e3e8    	ldr	w8, [sp, #0x1e0]
100024158: 0a0802c8    	and	w8, w22, w8
10002415c: 7100051f    	cmp	w8, #0x1
100024160: 54000341    	b.ne	0x1000241c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5f30>
100024164: f940f7ec    	ldr	x12, [sp, #0x1e8]
100024168: eb0c0268    	subs	x8, x19, x12
10002416c: 54032c83    	b.lo	0x10002a6fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc464>
100024170: aa1b03f9    	mov	x25, x27
100024174: b40011a8    	cbz	x8, 0x1000243a8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6110>
100024178: cb130188    	sub	x8, x12, x19
10002417c: aa1b03f9    	mov	x25, x27
100024180: f1000729    	subs	x9, x25, #0x1
100024184: 54032bc3    	b.lo	0x10002a6fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc464>
100024188: 529cac2a    	mov	w10, #0xe561            ; =58721
10002418c: 72a002ca    	movk	w10, #0x16, lsl #16
100024190: eb0a013f    	cmp	x9, x10
100024194: 54000122    	b.hs	0x1000241b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5f20>
100024198: d37ef52a    	lsl	x10, x9, #2
10002419c: f941afeb    	ldr	x11, [sp, #0x358]
1000241a0: 786a696a    	ldrh	w10, [x11, x10]
1000241a4: eb0a0139    	subs	x25, x9, x10
1000241a8: 54032aa3    	b.lo	0x10002a6fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc464>
1000241ac: b1000508    	adds	x8, x8, #0x1
1000241b0: 54fffe83    	b.lo	0x100024180 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5ee8>
1000241b4: 1400007d    	b	0x1000243a8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6110>
1000241b8: d280000a    	mov	x10, #0x0               ; =0
1000241bc: eb0a0139    	subs	x25, x9, x10
1000241c0: 54ffff62    	b.hs	0x1000241ac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5f14>
1000241c4: 1400194e    	b	0x10002a6fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc464>
1000241c8: d2800008    	mov	x8, #0x0                ; =0
1000241cc: 14000004    	b	0x1000241dc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5f44>
1000241d0: 91000508    	add	x8, x8, #0x1
1000241d4: f1040d1f    	cmp	x8, #0x103
1000241d8: 540001e0    	b.eq	0x100024214 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5f7c>
1000241dc: f9418fe9    	ldr	x9, [sp, #0x318]
1000241e0: b8687929    	ldr	w9, [x9, x8, lsl #2]
1000241e4: 34ffff69    	cbz	w9, 0x1000241d0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5f38>
1000241e8: f94163ea    	ldr	x10, [sp, #0x2c0]
1000241ec: eb0a011f    	cmp	x8, x10
1000241f0: 5403cd42    	b.hs	0x10002bb98 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xd900>
1000241f4: f9415feb    	ldr	x11, [sp, #0x2b8]
1000241f8: b868796a    	ldr	w10, [x11, x8, lsl #2]
1000241fc: 2b090149    	adds	w9, w10, w9
100024200: 54032742    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100024204: b8287969    	str	w9, [x11, x8, lsl #2]
100024208: f9418fe9    	ldr	x9, [sp, #0x318]
10002420c: b828793f    	str	wzr, [x9, x8, lsl #2]
100024210: 17fffff0    	b	0x1000241d0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x5f38>
100024214: f94147e8    	ldr	x8, [sp, #0x288]
100024218: b4045748    	cbz	x8, 0x10002cd00 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xea68>
10002421c: f94123ea    	ldr	x10, [sp, #0x240]
100024220: b9400148    	ldr	w8, [x10]
100024224: b9400329    	ldr	w9, [x25]
100024228: 2b090108    	adds	w8, w8, w9
10002422c: 540325e2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100024230: b9000148    	str	w8, [x10]
100024234: b900033f    	str	wzr, [x25]
100024238: f94147e8    	ldr	x8, [sp, #0x288]
10002423c: f100051f    	cmp	x8, #0x1
100024240: 54045840    	b.eq	0x10002cd48 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeab0>
100024244: b9400548    	ldr	w8, [x10, #0x4]
100024248: b9400729    	ldr	w9, [x25, #0x4]
10002424c: 2b090108    	adds	w8, w8, w9
100024250: 540324c2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100024254: b9000548    	str	w8, [x10, #0x4]
100024258: b900073f    	str	wzr, [x25, #0x4]
10002425c: f94147e8    	ldr	x8, [sp, #0x288]
100024260: f1000d1f    	cmp	x8, #0x3
100024264: 54045523    	b.lo	0x10002cd08 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xea70>
100024268: b9400948    	ldr	w8, [x10, #0x8]
10002426c: b9400b29    	ldr	w9, [x25, #0x8]
100024270: 2b090108    	adds	w8, w8, w9
100024274: 540323a2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100024278: b9000948    	str	w8, [x10, #0x8]
10002427c: b9000b3f    	str	wzr, [x25, #0x8]
100024280: f94147e8    	ldr	x8, [sp, #0x288]
100024284: f1000d1f    	cmp	x8, #0x3
100024288: 540455e0    	b.eq	0x10002cd44 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeaac>
10002428c: b9400d48    	ldr	w8, [x10, #0xc]
100024290: b9400f29    	ldr	w9, [x25, #0xc]
100024294: 2b090108    	adds	w8, w8, w9
100024298: 54032282    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10002429c: b9000d48    	str	w8, [x10, #0xc]
1000242a0: b9000f3f    	str	wzr, [x25, #0xc]
1000242a4: f94147e8    	ldr	x8, [sp, #0x288]
1000242a8: f100151f    	cmp	x8, #0x5
1000242ac: 54045323    	b.lo	0x10002cd10 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xea78>
1000242b0: b9401148    	ldr	w8, [x10, #0x10]
1000242b4: b9401329    	ldr	w9, [x25, #0x10]
1000242b8: 2b090108    	adds	w8, w8, w9
1000242bc: 54032162    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000242c0: b9001148    	str	w8, [x10, #0x10]
1000242c4: b900133f    	str	wzr, [x25, #0x10]
1000242c8: f94147e8    	ldr	x8, [sp, #0x288]
1000242cc: f100151f    	cmp	x8, #0x5
1000242d0: 540453a0    	b.eq	0x10002cd44 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeaac>
1000242d4: b9401548    	ldr	w8, [x10, #0x14]
1000242d8: b9401729    	ldr	w9, [x25, #0x14]
1000242dc: 2b090108    	adds	w8, w8, w9
1000242e0: 54032042    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000242e4: b9001548    	str	w8, [x10, #0x14]
1000242e8: b900173f    	str	wzr, [x25, #0x14]
1000242ec: f94147e8    	ldr	x8, [sp, #0x288]
1000242f0: f1001d1f    	cmp	x8, #0x7
1000242f4: 54045123    	b.lo	0x10002cd18 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xea80>
1000242f8: b9401948    	ldr	w8, [x10, #0x18]
1000242fc: b9401b29    	ldr	w9, [x25, #0x18]
100024300: 2b090108    	adds	w8, w8, w9
100024304: 54031f22    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100024308: b9001948    	str	w8, [x10, #0x18]
10002430c: b9001b3f    	str	wzr, [x25, #0x18]
100024310: f94147e8    	ldr	x8, [sp, #0x288]
100024314: f1001d1f    	cmp	x8, #0x7
100024318: 54045160    	b.eq	0x10002cd44 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeaac>
10002431c: b9401d48    	ldr	w8, [x10, #0x1c]
100024320: b9401f29    	ldr	w9, [x25, #0x1c]
100024324: 2b090108    	adds	w8, w8, w9
100024328: 54031e02    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10002432c: b9001d48    	str	w8, [x10, #0x1c]
100024330: b9001f3f    	str	wzr, [x25, #0x1c]
100024334: f94147e8    	ldr	x8, [sp, #0x288]
100024338: f100251f    	cmp	x8, #0x9
10002433c: 54044f23    	b.lo	0x10002cd20 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xea88>
100024340: b9402148    	ldr	w8, [x10, #0x20]
100024344: b9402329    	ldr	w9, [x25, #0x20]
100024348: 2b090108    	adds	w8, w8, w9
10002434c: 54031ce2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100024350: b9002148    	str	w8, [x10, #0x20]
100024354: b900233f    	str	wzr, [x25, #0x20]
100024358: f94147e8    	ldr	x8, [sp, #0x288]
10002435c: f100251f    	cmp	x8, #0x9
100024360: 54044f20    	b.eq	0x10002cd44 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeaac>
100024364: b9402548    	ldr	w8, [x10, #0x24]
100024368: b9402729    	ldr	w9, [x25, #0x24]
10002436c: 2b090108    	adds	w8, w8, w9
100024370: 54031bc2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100024374: b9002548    	str	w8, [x10, #0x24]
100024378: b900273f    	str	wzr, [x25, #0x24]
10002437c: f9410fe8    	ldr	x8, [sp, #0x218]
100024380: ab1c0108    	adds	x8, x8, x28
100024384: f9010fe8    	str	x8, [sp, #0x218]
100024388: 54031b02    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10002438c: d2800015    	mov	x21, #0x0               ; =0
100024390: eb1303df    	cmp	x30, x19
100024394: 1a9f17f8    	cset	w24, eq
100024398: aa1303ec    	mov	x12, x19
10002439c: aa1b03f9    	mov	x25, x27
1000243a0: d280001b    	mov	x27, #0x0               ; =0
1000243a4: 14000005    	b	0x1000243b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6120>
1000243a8: eb19037b    	subs	x27, x27, x25
1000243ac: 54031a83    	b.lo	0x10002a6fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc464>
1000243b0: aa1c03f5    	mov	x21, x28
1000243b4: d2800018    	mov	x24, #0x0               ; =0
1000243b8: f9015bf0    	str	x16, [sp, #0x2b0]
1000243bc: f90113e7    	str	x7, [sp, #0x220]
1000243c0: a908c7e1    	stp	x1, x17, [sp, #0x88]
1000243c4: f94183e2    	ldr	x2, [sp, #0x300]
1000243c8: f900f7ec    	str	x12, [sp, #0x1e8]
1000243cc: eb02019c    	subs	x28, x12, x2
1000243d0: 54031963    	b.lo	0x10002a6fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc464>
1000243d4: f904d3f7    	str	x23, [sp, #0x9a0]
1000243d8: f904d7fe    	str	x30, [sp, #0x9a8]
1000243dc: f9413fe8    	ldr	x8, [sp, #0x278]
1000243e0: f904dbe8    	str	x8, [sp, #0x9b0]
1000243e4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000243e8: 91152000    	add	x0, x0, #0x548
1000243ec: 912683e1    	add	x1, sp, #0x9a0
1000243f0: aa1c03e3    	mov	x3, x28
1000243f4: 97ffdd25    	bl	0x10001b888 <_roc__p7f95ed46022205c5413858b3de8531cb.fast>
1000243f8: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000243fc: 91152108    	add	x8, x8, #0x548
100024400: 91012100    	add	x0, x8, #0x48
100024404: 9101e101    	add	x1, x8, #0x78
100024408: 914007e2    	add	x2, sp, #0x1, lsl #12   ; =0x1000
10002440c: 91152042    	add	x2, x2, #0x548
100024410: 91006103    	add	x3, x8, #0x18
100024414: 97ffd9e5    	bl	0x10001aba8 <_roc__p9d8198fedbd801212718a09deebc5774.fast>
100024418: aa0003f7    	mov	x23, x0
10002441c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100024420: 91152000    	add	x0, x0, #0x548
100024424: 940030d6    	bl	0x10003077c <_roc_llvm_rc_decref_56_single_thread>
100024428: f94093e8    	ldr	x8, [sp, #0x120]
10002442c: eb08039f    	cmp	x28, x8
100024430: 540000a9    	b.ls	0x100024444 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x61ac>
100024434: 92800008    	mov	x8, #-0x1               ; =-1
100024438: f90157e8    	str	x8, [sp, #0x2a8]
10002443c: 52800034    	mov	w20, #0x1               ; =1
100024440: 14000083    	b	0x10002464c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x63b4>
100024444: f90eebff    	str	xzr, [sp, #0x1dd0]
100024448: f90ee7ff    	str	xzr, [sp, #0x1dc8]
10002444c: f90eefff    	str	xzr, [sp, #0x1dd8]
100024450: 912683e0    	add	x0, sp, #0x9a0
100024454: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
100024458: 91372021    	add	x1, x1, #0xdc8
10002445c: 52802142    	mov	w2, #0x10a              ; =266
100024460: 52800083    	mov	w3, #0x4                ; =4
100024464: 52800024    	mov	w4, #0x1                ; =1
100024468: 94003578    	bl	0x100031a48 <_list.RocList.reallocate>
10002446c: f944d3e8    	ldr	x8, [sp, #0x9a0]
100024470: f944dbe9    	ldr	x9, [sp, #0x9b0]
100024474: b900011f    	str	wzr, [x8]
100024478: f904d3e8    	str	x8, [sp, #0x9a0]
10002447c: 52800034    	mov	w20, #0x1               ; =1
100024480: f904d7f4    	str	x20, [sp, #0x9a8]
100024484: f904dbe9    	str	x9, [sp, #0x9b0]
100024488: 3dc26be0    	ldr	q0, [sp, #0x9a0]
10002448c: f9000be9    	str	x9, [sp, #0x10]
100024490: 3d8003e0    	str	q0, [sp]
100024494: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100024498: 91210000    	add	x0, x0, #0x840
10002449c: d2800001    	mov	x1, #0x0                ; =0
1000244a0: 52801fe2    	mov	w2, #0xff               ; =255
1000244a4: 52800083    	mov	w3, #0x4                ; =4
1000244a8: 94003737    	bl	0x100032184 <_list.listAppendRangeWithinUnsafe>
1000244ac: f90eebff    	str	xzr, [sp, #0x1dd0]
1000244b0: f90ee7ff    	str	xzr, [sp, #0x1dc8]
1000244b4: f90eefff    	str	xzr, [sp, #0x1dd8]
1000244b8: 912683e0    	add	x0, sp, #0x9a0
1000244bc: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
1000244c0: 91372021    	add	x1, x1, #0xdc8
1000244c4: 528021a2    	mov	w2, #0x10d              ; =269
1000244c8: 52800083    	mov	w3, #0x4                ; =4
1000244cc: 52800024    	mov	w4, #0x1                ; =1
1000244d0: 9400355e    	bl	0x100031a48 <_list.RocList.reallocate>
1000244d4: f944d3e8    	ldr	x8, [sp, #0x9a0]
1000244d8: f944dbe9    	ldr	x9, [sp, #0x9b0]
1000244dc: b900011f    	str	wzr, [x8]
1000244e0: f904d3e8    	str	x8, [sp, #0x9a0]
1000244e4: f904d7f4    	str	x20, [sp, #0x9a8]
1000244e8: f904dbe9    	str	x9, [sp, #0x9b0]
1000244ec: 3dc26be0    	ldr	q0, [sp, #0x9a0]
1000244f0: f9000be9    	str	x9, [sp, #0x10]
1000244f4: 3d8003e0    	str	q0, [sp]
1000244f8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000244fc: 9122e000    	add	x0, x0, #0x8b8
100024500: d2800001    	mov	x1, #0x0                ; =0
100024504: 52802042    	mov	w2, #0x102              ; =258
100024508: 52800083    	mov	w3, #0x4                ; =4
10002450c: 9400371e    	bl	0x100032184 <_list.listAppendRangeWithinUnsafe>
100024510: f90eebff    	str	xzr, [sp, #0x1dd0]
100024514: f90ee7ff    	str	xzr, [sp, #0x1dc8]
100024518: f90eefff    	str	xzr, [sp, #0x1dd8]
10002451c: 912683e0    	add	x0, sp, #0x9a0
100024520: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
100024524: 91372021    	add	x1, x1, #0xdc8
100024528: 52800542    	mov	w2, #0x2a               ; =42
10002452c: 52800083    	mov	w3, #0x4                ; =4
100024530: 52800024    	mov	w4, #0x1                ; =1
100024534: 94003545    	bl	0x100031a48 <_list.RocList.reallocate>
100024538: f944d3e8    	ldr	x8, [sp, #0x9a0]
10002453c: f944dbe9    	ldr	x9, [sp, #0x9b0]
100024540: b900011f    	str	wzr, [x8]
100024544: f904d3e8    	str	x8, [sp, #0x9a0]
100024548: f904d7f4    	str	x20, [sp, #0x9a8]
10002454c: f904dbe9    	str	x9, [sp, #0x9b0]
100024550: 3dc26be0    	ldr	q0, [sp, #0x9a0]
100024554: f9000be9    	str	x9, [sp, #0x10]
100024558: 3d8003e0    	str	q0, [sp]
10002455c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100024560: 91372000    	add	x0, x0, #0xdc8
100024564: d2800001    	mov	x1, #0x0                ; =0
100024568: 528003e2    	mov	w2, #0x1f               ; =31
10002456c: 52800083    	mov	w3, #0x4                ; =4
100024570: 94003705    	bl	0x100032184 <_list.listAppendRangeWithinUnsafe>
100024574: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100024578: 91140000    	add	x0, x0, #0x500
10002457c: 912f43e1    	add	x1, sp, #0xbd0
100024580: 913043e2    	add	x2, sp, #0xc10
100024584: 914007e3    	add	x3, sp, #0x1, lsl #12   ; =0x1000
100024588: 91210063    	add	x3, x3, #0x840
10002458c: 914007e4    	add	x4, sp, #0x1, lsl #12   ; =0x1000
100024590: 9122e084    	add	x4, x4, #0x8b8
100024594: 914007e5    	add	x5, sp, #0x1, lsl #12   ; =0x1000
100024598: 913720a5    	add	x5, x5, #0xdc8
10002459c: 94002df8    	bl	0x10002fd7c <_roc__p5577dd3f98103e165031983d14e7560c.fast>
1000245a0: f941afe8    	ldr	x8, [sp, #0x358]
1000245a4: f90ee7e8    	str	x8, [sp, #0x1dc8]
1000245a8: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000245ac: 91360108    	add	x8, x8, #0xd80
1000245b0: 3dc0bbe0    	ldr	q0, [sp, #0x2e0]
1000245b4: 3c850100    	stur	q0, [x8, #0x50]
1000245b8: f940ebe8    	ldr	x8, [sp, #0x1d0]
1000245bc: f904d3e8    	str	x8, [sp, #0x9a0]
1000245c0: f94103e8    	ldr	x8, [sp, #0x200]
1000245c4: f904d7e8    	str	x8, [sp, #0x9a8]
1000245c8: f940fbe8    	ldr	x8, [sp, #0x1f0]
1000245cc: f904dbe8    	str	x8, [sp, #0x9b0]
1000245d0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000245d4: 9122e000    	add	x0, x0, #0x8b8
1000245d8: 914007e2    	add	x2, sp, #0x1, lsl #12   ; =0x1000
1000245dc: 91372042    	add	x2, x2, #0xdc8
1000245e0: 912683e4    	add	x4, sp, #0x9a0
1000245e4: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000245e8: 91140108    	add	x8, x8, #0x500
1000245ec: 91006105    	add	x5, x8, #0x18
1000245f0: 914007e6    	add	x6, sp, #0x1, lsl #12   ; =0x1000
1000245f4: 911400c6    	add	x6, x6, #0x500
1000245f8: 9100c107    	add	x7, x8, #0x30
1000245fc: aa1c03e1    	mov	x1, x28
100024600: aa1903e3    	mov	x3, x25
100024604: 97ffd6c7    	bl	0x10001a120 <_roc__p251d42c9b11261f4b6c38feff48bfd2d.fast>
100024608: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002460c: 91140000    	add	x0, x0, #0x500
100024610: 9400306b    	bl	0x1000307bc <_roc_llvm_rc_decref_55_single_thread>
100024614: f94c63e9    	ldr	x9, [sp, #0x18c0]
100024618: f94c5fe8    	ldr	x8, [sp, #0x18b8]
10002461c: f900ebe8    	str	x8, [sp, #0x1d0]
100024620: f90103e9    	str	x9, [sp, #0x200]
100024624: b40000c9    	cbz	x9, 0x10002463c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x63a4>
100024628: 8b090d08    	add	x8, x8, x9, lsl #3
10002462c: f85f8108    	ldur	x8, [x8, #-0x8]
100024630: 53047d08    	lsr	w8, w8, #4
100024634: 91001d08    	add	x8, x8, #0x7
100024638: 14000002    	b	0x100024640 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x63a8>
10002463c: 528000e8    	mov	w8, #0x7                ; =7
100024640: f90157e8    	str	x8, [sp, #0x2a8]
100024644: f94c67e8    	ldr	x8, [sp, #0x18c8]
100024648: f900fbe8    	str	x8, [sp, #0x1f0]
10002464c: 52808600    	mov	w0, #0x430              ; =1072
100024650: 52800101    	mov	w1, #0x8                ; =8
100024654: 97ff788b    	bl	0x100002880 <_roc_alloc>
100024658: aa0003e8    	mov	x8, x0
10002465c: b8008d1f    	str	wzr, [x8, #0x8]!
100024660: f9000014    	str	x20, [x0]
100024664: 91047009    	add	x9, x0, #0x11c
100024668: f940010a    	ldr	x10, [x8]
10002466c: f800c00a    	stur	x10, [x0, #0xc]
100024670: f900080a    	str	x10, [x0, #0x10]
100024674: f840c00a    	ldur	x10, [x0, #0xc]
100024678: f801400a    	stur	x10, [x0, #0x14]
10002467c: 4e080d40    	dup.2d	v0, x10
100024680: 3c82c000    	stur	q0, [x0, #0x2c]
100024684: 3c81c000    	stur	q0, [x0, #0x1c]
100024688: 3c84c000    	stur	q0, [x0, #0x4c]
10002468c: 3c83c000    	stur	q0, [x0, #0x3c]
100024690: 3c86c000    	stur	q0, [x0, #0x6c]
100024694: 3c85c000    	stur	q0, [x0, #0x5c]
100024698: 3c88c000    	stur	q0, [x0, #0x8c]
10002469c: 3c87c000    	stur	q0, [x0, #0x7c]
1000246a0: 3c8ac000    	stur	q0, [x0, #0xac]
1000246a4: 3c89c000    	stur	q0, [x0, #0x9c]
1000246a8: 3c8cc000    	stur	q0, [x0, #0xcc]
1000246ac: 3c8bc000    	stur	q0, [x0, #0xbc]
1000246b0: 3c8ec000    	stur	q0, [x0, #0xec]
1000246b4: 3c8dc000    	stur	q0, [x0, #0xdc]
1000246b8: 3c8fcc00    	str	q0, [x0, #0xfc]!
1000246bc: 3d800400    	str	q0, [x0, #0x10]
1000246c0: ad000120    	stp	q0, q0, [x9]
1000246c4: ad010120    	stp	q0, q0, [x9, #0x20]
1000246c8: ad020120    	stp	q0, q0, [x9, #0x40]
1000246cc: ad030120    	stp	q0, q0, [x9, #0x60]
1000246d0: ad040120    	stp	q0, q0, [x9, #0x80]
1000246d4: ad050120    	stp	q0, q0, [x9, #0xa0]
1000246d8: ad060120    	stp	q0, q0, [x9, #0xc0]
1000246dc: ad070120    	stp	q0, q0, [x9, #0xe0]
1000246e0: ad080120    	stp	q0, q0, [x9, #0x100]
1000246e4: ad090120    	stp	q0, q0, [x9, #0x120]
1000246e8: ad0a0120    	stp	q0, q0, [x9, #0x140]
1000246ec: ad0b0120    	stp	q0, q0, [x9, #0x160]
1000246f0: ad0c0120    	stp	q0, q0, [x9, #0x180]
1000246f4: ad0d0120    	stp	q0, q0, [x9, #0x1a0]
1000246f8: ad0e0120    	stp	q0, q0, [x9, #0x1c0]
1000246fc: ad0f0120    	stp	q0, q0, [x9, #0x1e0]
100024700: ad100120    	stp	q0, q0, [x9, #0x200]
100024704: ad110120    	stp	q0, q0, [x9, #0x220]
100024708: ad120120    	stp	q0, q0, [x9, #0x240]
10002470c: ad130120    	stp	q0, q0, [x9, #0x260]
100024710: ad140120    	stp	q0, q0, [x9, #0x280]
100024714: ad150120    	stp	q0, q0, [x9, #0x2a0]
100024718: ad160120    	stp	q0, q0, [x9, #0x2c0]
10002471c: ad170120    	stp	q0, q0, [x9, #0x2e0]
100024720: f901812a    	str	x10, [x9, #0x300]
100024724: f9419fec    	ldr	x12, [sp, #0x338]
100024728: f941a3ed    	ldr	x13, [sp, #0x340]
10002472c: f94183ee    	ldr	x14, [sp, #0x300]
100024730: b40002bc    	cbz	x28, 0x100024784 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x64ec>
100024734: d2800009    	mov	x9, #0x0                ; =0
100024738: ab0901ca    	adds	x10, x14, x9
10002473c: 5402fd62    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100024740: eb0d015f    	cmp	x10, x13
100024744: 54000162    	b.hs	0x100024770 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x64d8>
100024748: 386a698a    	ldrb	w10, [x12, x10]
10002474c: d37ef54a    	lsl	x10, x10, #2
100024750: b86a690b    	ldr	w11, [x8, x10]
100024754: 3100056b    	adds	w11, w11, #0x1
100024758: 5402fc82    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10002475c: b82a690b    	str	w11, [x8, x10]
100024760: 91000529    	add	x9, x9, #0x1
100024764: eb09039f    	cmp	x28, x9
100024768: 54fffe81    	b.ne	0x100024738 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x64a0>
10002476c: 14000006    	b	0x100024784 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x64ec>
100024770: d280000a    	mov	x10, #0x0               ; =0
100024774: b86a690b    	ldr	w11, [x8, x10]
100024778: 3100056b    	adds	w11, w11, #0x1
10002477c: 54ffff03    	b.lo	0x10002475c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x64c4>
100024780: 140017da    	b	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100024784: d2800009    	mov	x9, #0x0                ; =0
100024788: d2800014    	mov	x20, #0x0               ; =0
10002478c: d34bff8a    	lsr	x10, x28, #11
100024790: 14000004    	b	0x1000247a0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6508>
100024794: 91001129    	add	x9, x9, #0x4
100024798: f110013f    	cmp	x9, #0x400
10002479c: 540000e0    	b.eq	0x1000247b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6520>
1000247a0: b869690b    	ldr	w11, [x8, x9]
1000247a4: eb0b015f    	cmp	x10, x11
1000247a8: 54ffff62    	b.hs	0x100024794 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x64fc>
1000247ac: b1000694    	adds	x20, x20, #0x1
1000247b0: 54ffff23    	b.lo	0x100024794 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x64fc>
1000247b4: 140017cd    	b	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000247b8: f9003ff8    	str	x24, [sp, #0x78]
1000247bc: f90187f9    	str	x25, [sp, #0x308]
1000247c0: f90ec3e8    	str	x8, [sp, #0x1d80]
1000247c4: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000247c8: 91360108    	add	x8, x8, #0xd80
1000247cc: 3dc047e0    	ldr	q0, [sp, #0x110]
1000247d0: 3c808100    	stur	q0, [x8, #0x8]
1000247d4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000247d8: 91360000    	add	x0, x0, #0xd80
1000247dc: 94002e79    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000247e0: f100069f    	cmp	x20, #0x1
1000247e4: 9a9f8698    	csinc	x24, x20, xzr, hi
1000247e8: f1013e9f    	cmp	x20, #0x4f
1000247ec: f9019bf5    	str	x21, [sp, #0x330]
1000247f0: f90043f7    	str	x23, [sp, #0x80]
1000247f4: 54000069    	b.ls	0x100024800 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6568>
1000247f8: 52800068    	mov	w8, #0x3                ; =3
1000247fc: 14000005    	b	0x100024810 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6578>
100024800: 100ad888    	adr	x8, 0x10003a310 <_roc__d61_1>
100024804: d503201f    	nop
100024808: 8b180108    	add	x8, x8, x24
10002480c: 39402108    	ldrb	w8, [x8, #0x8]
100024810: f9415fea    	ldr	x10, [sp, #0x2b8]
100024814: f94163eb    	ldr	x11, [sp, #0x2c0]
100024818: d2800017    	mov	x23, #0x0               ; =0
10002481c: f9018bfc    	str	x28, [sp, #0x310]
100024820: eb0b011f    	cmp	x8, x11
100024824: 54000162    	b.hs	0x100024850 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x65b8>
100024828: b8687949    	ldr	w9, [x10, x8, lsl #2]
10002482c: ab0902f7    	adds	x23, x23, x9
100024830: 5402f5c6    	b.vs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100024834: 9b087d29    	mul	x9, x9, x8
100024838: eb09039c    	subs	x28, x28, x9
10002483c: 5402f606    	b.vs	0x10002a6fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc464>
100024840: 91000508    	add	x8, x8, #0x1
100024844: f1040d1f    	cmp	x8, #0x103
100024848: 54fffec1    	b.ne	0x100024820 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6588>
10002484c: 14000005    	b	0x100024860 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x65c8>
100024850: d2800009    	mov	x9, #0x0                ; =0
100024854: ab0902f7    	adds	x23, x23, x9
100024858: 54fffee7    	b.vc	0x100024834 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x659c>
10002485c: 140017a3    	b	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100024860: f90ec3ea    	str	x10, [sp, #0x1d80]
100024864: f90ec7eb    	str	x11, [sp, #0x1d88]
100024868: f940dfe8    	ldr	x8, [sp, #0x1b8]
10002486c: f90ecbe8    	str	x8, [sp, #0x1d90]
100024870: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100024874: 91360000    	add	x0, x0, #0xd80
100024878: 94002e52    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002487c: 8abcff88    	bic	x8, x28, x28, asr #63
100024880: eb0802ff    	cmp	x23, x8
100024884: 540000cd    	b.le	0x10002489c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6604>
100024888: 100a8308    	adr	x8, 0x1000398e8 <_roc__d23_1>
10002488c: d503201f    	nop
100024890: 91002108    	add	x8, x8, #0x8
100024894: 52800057    	mov	w23, #0x2               ; =2
100024898: 1400000b    	b	0x1000248c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x662c>
10002489c: d2fc0009    	mov	x9, #-0x2000000000000000 ; =-2305843009213693952
1000248a0: 8b0902e9    	add	x9, x23, x9
1000248a4: d37efd29    	lsr	x9, x9, #62
1000248a8: f1000d3f    	cmp	x9, #0x3
1000248ac: 5400eaa3    	b.lo	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
1000248b0: d37ef6e9    	lsl	x9, x23, #2
1000248b4: eb08013f    	cmp	x9, x8
1000248b8: a94a23e9    	ldp	x9, x8, [sp, #0xa0]
1000248bc: 9a88c128    	csel	x8, x9, x8, gt
1000248c0: 1a9fd7f7    	cset	w23, gt
1000248c4: f104069f    	cmp	x20, #0x101
1000248c8: 5400dea2    	b.hs	0x10002649c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8204>
1000248cc: 38786915    	ldrb	w21, [x8, x24]
1000248d0: f90ec3e8    	str	x8, [sp, #0x1d80]
1000248d4: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000248d8: 91360108    	add	x8, x8, #0xd80
1000248dc: 3dc043e0    	ldr	q0, [sp, #0x100]
1000248e0: 3c808100    	stur	q0, [x8, #0x8]
1000248e4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000248e8: 91360000    	add	x0, x0, #0xd80
1000248ec: 94002e35    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000248f0: 100a6908    	adr	x8, 0x100039610 <_roc__d17_1>
1000248f4: d503201f    	nop
1000248f8: 8b170108    	add	x8, x8, x23
1000248fc: 39402118    	ldrb	w24, [x8, #0x8]
100024900: f94147ec    	ldr	x12, [sp, #0x288]
100024904: f94183e8    	ldr	x8, [sp, #0x300]
100024908: f940c3ed    	ldr	x13, [sp, #0x180]
10002490c: f940bbee    	ldr	x14, [sp, #0x170]
100024910: f940e3ef    	ldr	x15, [sp, #0x1c0]
100024914: b90077f6    	str	w22, [sp, #0x74]
100024918: b4001f28    	cbz	x8, 0x100024cfc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6a64>
10002491c: f9410ff7    	ldr	x23, [sp, #0x218]
100024920: b400dd2d    	cbz	x13, 0x1000264c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x822c>
100024924: b94001c9    	ldr	w9, [x14]
100024928: 9b177d28    	mul	x8, x9, x23
10002492c: 9bd77d29    	umulh	x9, x9, x23
100024930: eb0903ff    	cmp	xzr, x9
100024934: 1a9f07e9    	cset	w9, ne
100024938: 3700e649    	tbnz	w9, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
10002493c: b400dccc    	cbz	x12, 0x1000264d4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x823c>
100024940: f94123e9    	ldr	x9, [sp, #0x240]
100024944: b940012a    	ldr	w10, [x9]
100024948: 9b0f7d49    	mul	x9, x10, x15
10002494c: 9bcf7d4a    	umulh	x10, x10, x15
100024950: eb0a03ff    	cmp	xzr, x10
100024954: 1a9f07ea    	cset	w10, ne
100024958: 3700e54a    	tbnz	w10, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
10002495c: eb090108    	subs	x8, x8, x9
100024960: da888508    	cneg	x8, x8, ls
100024964: f10009bf    	cmp	x13, #0x2
100024968: 5400dbe3    	b.lo	0x1000264e4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x824c>
10002496c: b94005ca    	ldr	w10, [x14, #0x4]
100024970: 9b177d49    	mul	x9, x10, x23
100024974: 9bd77d4a    	umulh	x10, x10, x23
100024978: eb0a03ff    	cmp	xzr, x10
10002497c: 1a9f07ea    	cset	w10, ne
100024980: 3700e40a    	tbnz	w10, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100024984: f100099f    	cmp	x12, #0x2
100024988: 5400db63    	b.lo	0x1000264f4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x825c>
10002498c: f94123ea    	ldr	x10, [sp, #0x240]
100024990: b940054b    	ldr	w11, [x10, #0x4]
100024994: 9b0f7d6a    	mul	x10, x11, x15
100024998: 9bcf7d6b    	umulh	x11, x11, x15
10002499c: eb0b03ff    	cmp	xzr, x11
1000249a0: 1a9f07eb    	cset	w11, ne
1000249a4: 3700e2eb    	tbnz	w11, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
1000249a8: eb0a0129    	subs	x9, x9, x10
1000249ac: da898529    	cneg	x9, x9, ls
1000249b0: ab090108    	adds	x8, x8, x9
1000249b4: 5402e9a2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000249b8: f1000dbf    	cmp	x13, #0x3
1000249bc: 5400da43    	b.lo	0x100026504 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x826c>
1000249c0: b94009ca    	ldr	w10, [x14, #0x8]
1000249c4: 9b177d49    	mul	x9, x10, x23
1000249c8: 9bd77d4a    	umulh	x10, x10, x23
1000249cc: eb0a03ff    	cmp	xzr, x10
1000249d0: 1a9f07ea    	cset	w10, ne
1000249d4: 3700e16a    	tbnz	w10, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
1000249d8: f1000d9f    	cmp	x12, #0x3
1000249dc: 5400d9c3    	b.lo	0x100026514 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x827c>
1000249e0: f94123ea    	ldr	x10, [sp, #0x240]
1000249e4: b940094b    	ldr	w11, [x10, #0x8]
1000249e8: 9b0f7d6a    	mul	x10, x11, x15
1000249ec: 9bcf7d6b    	umulh	x11, x11, x15
1000249f0: eb0b03ff    	cmp	xzr, x11
1000249f4: 1a9f07eb    	cset	w11, ne
1000249f8: 3700e04b    	tbnz	w11, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
1000249fc: eb0a0129    	subs	x9, x9, x10
100024a00: da898529    	cneg	x9, x9, ls
100024a04: ab090108    	adds	x8, x8, x9
100024a08: 5402e702    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100024a0c: f10011bf    	cmp	x13, #0x4
100024a10: 5400d8a3    	b.lo	0x100026524 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x828c>
100024a14: b9400dca    	ldr	w10, [x14, #0xc]
100024a18: 9b177d49    	mul	x9, x10, x23
100024a1c: 9bd77d4a    	umulh	x10, x10, x23
100024a20: eb0a03ff    	cmp	xzr, x10
100024a24: 1a9f07ea    	cset	w10, ne
100024a28: 3700deca    	tbnz	w10, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100024a2c: f100119f    	cmp	x12, #0x4
100024a30: 5400d823    	b.lo	0x100026534 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x829c>
100024a34: f94123ea    	ldr	x10, [sp, #0x240]
100024a38: b9400d4b    	ldr	w11, [x10, #0xc]
100024a3c: 9b0f7d6a    	mul	x10, x11, x15
100024a40: 9bcf7d6b    	umulh	x11, x11, x15
100024a44: eb0b03ff    	cmp	xzr, x11
100024a48: 1a9f07eb    	cset	w11, ne
100024a4c: 3700ddab    	tbnz	w11, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100024a50: eb0a0129    	subs	x9, x9, x10
100024a54: da898529    	cneg	x9, x9, ls
100024a58: ab090108    	adds	x8, x8, x9
100024a5c: 5402e462    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100024a60: f10015bf    	cmp	x13, #0x5
100024a64: 5400d703    	b.lo	0x100026544 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x82ac>
100024a68: b94011ca    	ldr	w10, [x14, #0x10]
100024a6c: 9b177d49    	mul	x9, x10, x23
100024a70: 9bd77d4a    	umulh	x10, x10, x23
100024a74: eb0a03ff    	cmp	xzr, x10
100024a78: 1a9f07ea    	cset	w10, ne
100024a7c: 3700dc2a    	tbnz	w10, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100024a80: f100159f    	cmp	x12, #0x5
100024a84: 5400d683    	b.lo	0x100026554 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x82bc>
100024a88: f94123ea    	ldr	x10, [sp, #0x240]
100024a8c: b940114b    	ldr	w11, [x10, #0x10]
100024a90: 9b0f7d6a    	mul	x10, x11, x15
100024a94: 9bcf7d6b    	umulh	x11, x11, x15
100024a98: eb0b03ff    	cmp	xzr, x11
100024a9c: 1a9f07eb    	cset	w11, ne
100024aa0: 3700db0b    	tbnz	w11, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100024aa4: eb0a0129    	subs	x9, x9, x10
100024aa8: da898529    	cneg	x9, x9, ls
100024aac: ab090108    	adds	x8, x8, x9
100024ab0: 5402e1c2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100024ab4: f10019bf    	cmp	x13, #0x6
100024ab8: 5400d563    	b.lo	0x100026564 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x82cc>
100024abc: b94015ca    	ldr	w10, [x14, #0x14]
100024ac0: 9b177d49    	mul	x9, x10, x23
100024ac4: 9bd77d4a    	umulh	x10, x10, x23
100024ac8: eb0a03ff    	cmp	xzr, x10
100024acc: 1a9f07ea    	cset	w10, ne
100024ad0: 3700d98a    	tbnz	w10, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100024ad4: f100199f    	cmp	x12, #0x6
100024ad8: 5400d4e3    	b.lo	0x100026574 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x82dc>
100024adc: f94123ea    	ldr	x10, [sp, #0x240]
100024ae0: b940154b    	ldr	w11, [x10, #0x14]
100024ae4: 9b0f7d6a    	mul	x10, x11, x15
100024ae8: 9bcf7d6b    	umulh	x11, x11, x15
100024aec: eb0b03ff    	cmp	xzr, x11
100024af0: 1a9f07eb    	cset	w11, ne
100024af4: 3700d86b    	tbnz	w11, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100024af8: eb0a0129    	subs	x9, x9, x10
100024afc: da898529    	cneg	x9, x9, ls
100024b00: ab090108    	adds	x8, x8, x9
100024b04: 5402df22    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100024b08: f1001dbf    	cmp	x13, #0x7
100024b0c: 5400d3c3    	b.lo	0x100026584 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x82ec>
100024b10: b94019ca    	ldr	w10, [x14, #0x18]
100024b14: 9b177d49    	mul	x9, x10, x23
100024b18: 9bd77d4a    	umulh	x10, x10, x23
100024b1c: eb0a03ff    	cmp	xzr, x10
100024b20: 1a9f07ea    	cset	w10, ne
100024b24: 3700d6ea    	tbnz	w10, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100024b28: f1001d9f    	cmp	x12, #0x7
100024b2c: 5400d343    	b.lo	0x100026594 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x82fc>
100024b30: f94123ea    	ldr	x10, [sp, #0x240]
100024b34: b940194b    	ldr	w11, [x10, #0x18]
100024b38: 9b0f7d6a    	mul	x10, x11, x15
100024b3c: 9bcf7d6b    	umulh	x11, x11, x15
100024b40: eb0b03ff    	cmp	xzr, x11
100024b44: 1a9f07eb    	cset	w11, ne
100024b48: 3700d5cb    	tbnz	w11, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100024b4c: eb0a0129    	subs	x9, x9, x10
100024b50: da898529    	cneg	x9, x9, ls
100024b54: ab090108    	adds	x8, x8, x9
100024b58: 5402dc82    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100024b5c: f10021bf    	cmp	x13, #0x8
100024b60: 5400d223    	b.lo	0x1000265a4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x830c>
100024b64: b9401dca    	ldr	w10, [x14, #0x1c]
100024b68: 9b177d49    	mul	x9, x10, x23
100024b6c: 9bd77d4a    	umulh	x10, x10, x23
100024b70: eb0a03ff    	cmp	xzr, x10
100024b74: 1a9f07ea    	cset	w10, ne
100024b78: 3700d44a    	tbnz	w10, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100024b7c: f100219f    	cmp	x12, #0x8
100024b80: 5400d1a3    	b.lo	0x1000265b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x831c>
100024b84: f94123ea    	ldr	x10, [sp, #0x240]
100024b88: b9401d4b    	ldr	w11, [x10, #0x1c]
100024b8c: 9b0f7d6a    	mul	x10, x11, x15
100024b90: 9bcf7d6b    	umulh	x11, x11, x15
100024b94: eb0b03ff    	cmp	xzr, x11
100024b98: 1a9f07eb    	cset	w11, ne
100024b9c: 3700d32b    	tbnz	w11, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100024ba0: eb0a0129    	subs	x9, x9, x10
100024ba4: da898529    	cneg	x9, x9, ls
100024ba8: ab090108    	adds	x8, x8, x9
100024bac: 5402d9e2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100024bb0: f10025bf    	cmp	x13, #0x9
100024bb4: 5400d083    	b.lo	0x1000265c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x832c>
100024bb8: b94021ca    	ldr	w10, [x14, #0x20]
100024bbc: 9b177d49    	mul	x9, x10, x23
100024bc0: 9bd77d4a    	umulh	x10, x10, x23
100024bc4: eb0a03ff    	cmp	xzr, x10
100024bc8: 1a9f07ea    	cset	w10, ne
100024bcc: 3700d1aa    	tbnz	w10, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100024bd0: f100259f    	cmp	x12, #0x9
100024bd4: 5400d003    	b.lo	0x1000265d4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x833c>
100024bd8: f94123ea    	ldr	x10, [sp, #0x240]
100024bdc: b940214b    	ldr	w11, [x10, #0x20]
100024be0: 9b0f7d6a    	mul	x10, x11, x15
100024be4: 9bcf7d6b    	umulh	x11, x11, x15
100024be8: eb0b03ff    	cmp	xzr, x11
100024bec: 1a9f07eb    	cset	w11, ne
100024bf0: 3700d08b    	tbnz	w11, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100024bf4: eb0a0129    	subs	x9, x9, x10
100024bf8: da898529    	cneg	x9, x9, ls
100024bfc: ab090108    	adds	x8, x8, x9
100024c00: 5402d742    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100024c04: f10029bf    	cmp	x13, #0xa
100024c08: 5400cee3    	b.lo	0x1000265e4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x834c>
100024c0c: b94025ca    	ldr	w10, [x14, #0x24]
100024c10: 9b177d49    	mul	x9, x10, x23
100024c14: 9bd77d4a    	umulh	x10, x10, x23
100024c18: eb0a03ff    	cmp	xzr, x10
100024c1c: 1a9f07ea    	cset	w10, ne
100024c20: 3700cf0a    	tbnz	w10, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100024c24: f100299f    	cmp	x12, #0xa
100024c28: 5400ce63    	b.lo	0x1000265f4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x835c>
100024c2c: f94123ea    	ldr	x10, [sp, #0x240]
100024c30: b940254b    	ldr	w11, [x10, #0x24]
100024c34: 9b0f7d6a    	mul	x10, x11, x15
100024c38: 9bcf7d6b    	umulh	x11, x11, x15
100024c3c: eb0b03ff    	cmp	xzr, x11
100024c40: 1a9f07eb    	cset	w11, ne
100024c44: 3700cdeb    	tbnz	w11, #0x0, 0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100024c48: eb0a0129    	subs	x9, x9, x10
100024c4c: da898529    	cneg	x9, x9, ls
100024c50: ab090114    	adds	x20, x8, x9
100024c54: 5402d4a2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100024c58: f90ec3ee    	str	x14, [sp, #0x1d80]
100024c5c: f90ec7ed    	str	x13, [sp, #0x1d88]
100024c60: f940b7e8    	ldr	x8, [sp, #0x168]
100024c64: f90ecbe8    	str	x8, [sp, #0x1d90]
100024c68: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100024c6c: 91360000    	add	x0, x0, #0xd80
100024c70: 94002d54    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100024c74: f940e3e9    	ldr	x9, [sp, #0x1c0]
100024c78: 9bd77d28    	umulh	x8, x9, x23
100024c7c: eb0803ff    	cmp	xzr, x8
100024c80: 5400cc01    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100024c84: 9b177d28    	mul	x8, x9, x23
100024c88: 5280190a    	mov	w10, #0xc8              ; =200
100024c8c: 9bca7d09    	umulh	x9, x8, x10
100024c90: eb0903ff    	cmp	xzr, x9
100024c94: 5400cb61    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100024c98: 9b0a7d08    	mul	x8, x8, x10
100024c9c: d349fd08    	lsr	x8, x8, #9
100024ca0: 8b080509    	add	x9, x8, x8, lsl #1
100024ca4: eb09029f    	cmp	x20, x9
100024ca8: 54000609    	b.ls	0x100024d68 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6ad0>
100024cac: 912683e0    	add	x0, sp, #0x9a0
100024cb0: 912c43e3    	add	x3, sp, #0xb10
100024cb4: 912cc3e4    	add	x4, sp, #0xb30
100024cb8: 912d43e5    	add	x5, sp, #0xb50
100024cbc: aa1503e1    	mov	x1, x21
100024cc0: aa1803e2    	mov	x2, x24
100024cc4: 97ffdd11    	bl	0x10001c108 <_roc__pbc0b899c3413ab96a977414bc5843477.fast>
100024cc8: 3dc26be0    	ldr	q0, [sp, #0x9a0]
100024ccc: 3d86ebe0    	str	q0, [sp, #0x1ba0]
100024cd0: f944dbe8    	ldr	x8, [sp, #0x9b0]
100024cd4: f90ddbe8    	str	x8, [sp, #0x1bb0]
100024cd8: 912683e9    	add	x9, sp, #0x9a0
100024cdc: 3cc18120    	ldur	q0, [x9, #0x18]
100024ce0: 3d86f3e0    	str	q0, [sp, #0x1bc0]
100024ce4: f8428128    	ldur	x8, [x9, #0x28]
100024ce8: f90debe8    	str	x8, [sp, #0x1bd0]
100024cec: 3cc30120    	ldur	q0, [x9, #0x30]
100024cf0: 3d86fbe0    	str	q0, [sp, #0x1be0]
100024cf4: f8440128    	ldur	x8, [x9, #0x40]
100024cf8: 14000082    	b	0x100024f00 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6c68>
100024cfc: f90ec3ee    	str	x14, [sp, #0x1d80]
100024d00: f90ec7ed    	str	x13, [sp, #0x1d88]
100024d04: f940b7e8    	ldr	x8, [sp, #0x168]
100024d08: f90ecbe8    	str	x8, [sp, #0x1d90]
100024d0c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100024d10: 91360000    	add	x0, x0, #0xd80
100024d14: 94002d2b    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100024d18: 912683e0    	add	x0, sp, #0x9a0
100024d1c: 912c43e3    	add	x3, sp, #0xb10
100024d20: 912cc3e4    	add	x4, sp, #0xb30
100024d24: 912d43e5    	add	x5, sp, #0xb50
100024d28: aa1503e1    	mov	x1, x21
100024d2c: aa1803e2    	mov	x2, x24
100024d30: 97ffdcf6    	bl	0x10001c108 <_roc__pbc0b899c3413ab96a977414bc5843477.fast>
100024d34: 3dc26be0    	ldr	q0, [sp, #0x9a0]
100024d38: 3d865be0    	str	q0, [sp, #0x1960]
100024d3c: f944dbe8    	ldr	x8, [sp, #0x9b0]
100024d40: f90cbbe8    	str	x8, [sp, #0x1970]
100024d44: 912683e9    	add	x9, sp, #0x9a0
100024d48: 3cc18120    	ldur	q0, [x9, #0x18]
100024d4c: 3d8663e0    	str	q0, [sp, #0x1980]
100024d50: f8428128    	ldur	x8, [x9, #0x28]
100024d54: f90ccbe8    	str	x8, [sp, #0x1990]
100024d58: 3cc30120    	ldur	q0, [x9, #0x30]
100024d5c: 3d866be0    	str	q0, [sp, #0x19a0]
100024d60: f8440128    	ldur	x8, [x9, #0x40]
100024d64: 14000073    	b	0x100024f30 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6c98>
100024d68: 8b080d0a    	add	x10, x8, x8, lsl #3
100024d6c: eb14095f    	cmp	x10, x20, lsl #2
100024d70: 540002c2    	b.hs	0x100024dc8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6b30>
100024d74: 912683e0    	add	x0, sp, #0x9a0
100024d78: 912c43e4    	add	x4, sp, #0xb10
100024d7c: 912cc3e5    	add	x5, sp, #0xb30
100024d80: 912d43e6    	add	x6, sp, #0xb50
100024d84: aa1503e1    	mov	x1, x21
100024d88: aa1803e2    	mov	x2, x24
100024d8c: 52800063    	mov	w3, #0x3                ; =3
100024d90: 97ffdb57    	bl	0x10001baec <_roc__p7e55fe2bbd64ef5a07766497de391d37.fast>
100024d94: 3dc26be0    	ldr	q0, [sp, #0x9a0]
100024d98: 3d8673e0    	str	q0, [sp, #0x19c0]
100024d9c: f944dbe8    	ldr	x8, [sp, #0x9b0]
100024da0: f90cebe8    	str	x8, [sp, #0x19d0]
100024da4: 912683e9    	add	x9, sp, #0x9a0
100024da8: 3cc18120    	ldur	q0, [x9, #0x18]
100024dac: 3d867be0    	str	q0, [sp, #0x19e0]
100024db0: f8428128    	ldur	x8, [x9, #0x28]
100024db4: f90cfbe8    	str	x8, [sp, #0x19f0]
100024db8: 3cc30120    	ldur	q0, [x9, #0x30]
100024dbc: 3d8683e0    	str	q0, [sp, #0x1a00]
100024dc0: f8440128    	ldur	x8, [x9, #0x40]
100024dc4: 14000043    	b	0x100024ed0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6c38>
100024dc8: d37ffa8a    	lsl	x10, x20, #1
100024dcc: 912683e0    	add	x0, sp, #0x9a0
100024dd0: 912c43e4    	add	x4, sp, #0xb10
100024dd4: 912cc3e5    	add	x5, sp, #0xb30
100024dd8: 912d43e6    	add	x6, sp, #0xb50
100024ddc: aa1503e1    	mov	x1, x21
100024de0: aa1803e2    	mov	x2, x24
100024de4: eb09015f    	cmp	x10, x9
100024de8: 54000209    	b.ls	0x100024e28 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6b90>
100024dec: 52800043    	mov	w3, #0x2                ; =2
100024df0: 97ffdb3f    	bl	0x10001baec <_roc__p7e55fe2bbd64ef5a07766497de391d37.fast>
100024df4: 3dc26be0    	ldr	q0, [sp, #0x9a0]
100024df8: 3d8703e0    	str	q0, [sp, #0x1c00]
100024dfc: f944dbe8    	ldr	x8, [sp, #0x9b0]
100024e00: f90e0be8    	str	x8, [sp, #0x1c10]
100024e04: 912683e9    	add	x9, sp, #0x9a0
100024e08: 3cc18120    	ldur	q0, [x9, #0x18]
100024e0c: 3d870be0    	str	q0, [sp, #0x1c20]
100024e10: f8428128    	ldur	x8, [x9, #0x28]
100024e14: f90e1be8    	str	x8, [sp, #0x1c30]
100024e18: 3cc30120    	ldur	q0, [x9, #0x30]
100024e1c: 3d8713e0    	str	q0, [sp, #0x1c40]
100024e20: f8440128    	ldur	x8, [x9, #0x40]
100024e24: 1400001f    	b	0x100024ea0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6c08>
100024e28: eb08015f    	cmp	x10, x8
100024e2c: 54000069    	b.ls	0x100024e38 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6ba0>
100024e30: 52800023    	mov	w3, #0x1                ; =1
100024e34: 14000002    	b	0x100024e3c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6ba4>
100024e38: d2800003    	mov	x3, #0x0                ; =0
100024e3c: 97ffdb2c    	bl	0x10001baec <_roc__p7e55fe2bbd64ef5a07766497de391d37.fast>
100024e40: 3dc26be0    	ldr	q0, [sp, #0x9a0]
100024e44: 3d868be0    	str	q0, [sp, #0x1a20]
100024e48: f944dbe8    	ldr	x8, [sp, #0x9b0]
100024e4c: f90d1be8    	str	x8, [sp, #0x1a30]
100024e50: 912683e9    	add	x9, sp, #0x9a0
100024e54: 3cc18120    	ldur	q0, [x9, #0x18]
100024e58: 3d8693e0    	str	q0, [sp, #0x1a40]
100024e5c: f8428128    	ldur	x8, [x9, #0x28]
100024e60: f90d2be8    	str	x8, [sp, #0x1a50]
100024e64: 3cc30120    	ldur	q0, [x9, #0x30]
100024e68: 3d869be0    	str	q0, [sp, #0x1a60]
100024e6c: f8440128    	ldur	x8, [x9, #0x40]
100024e70: f90d3be8    	str	x8, [sp, #0x1a70]
100024e74: 3dc68be0    	ldr	q0, [sp, #0x1a20]
100024e78: 3d8703e0    	str	q0, [sp, #0x1c00]
100024e7c: f94d1be8    	ldr	x8, [sp, #0x1a30]
100024e80: f90e0be8    	str	x8, [sp, #0x1c10]
100024e84: 3dc693e0    	ldr	q0, [sp, #0x1a40]
100024e88: 3d870be0    	str	q0, [sp, #0x1c20]
100024e8c: f94d2be8    	ldr	x8, [sp, #0x1a50]
100024e90: f90e1be8    	str	x8, [sp, #0x1c30]
100024e94: 3dc69be0    	ldr	q0, [sp, #0x1a60]
100024e98: 3d8713e0    	str	q0, [sp, #0x1c40]
100024e9c: f94d3be8    	ldr	x8, [sp, #0x1a70]
100024ea0: f90e2be8    	str	x8, [sp, #0x1c50]
100024ea4: 3dc703e0    	ldr	q0, [sp, #0x1c00]
100024ea8: 3d8673e0    	str	q0, [sp, #0x19c0]
100024eac: f94e0be8    	ldr	x8, [sp, #0x1c10]
100024eb0: f90cebe8    	str	x8, [sp, #0x19d0]
100024eb4: 3dc70be0    	ldr	q0, [sp, #0x1c20]
100024eb8: 3d867be0    	str	q0, [sp, #0x19e0]
100024ebc: f94e1be8    	ldr	x8, [sp, #0x1c30]
100024ec0: f90cfbe8    	str	x8, [sp, #0x19f0]
100024ec4: 3dc713e0    	ldr	q0, [sp, #0x1c40]
100024ec8: 3d8683e0    	str	q0, [sp, #0x1a00]
100024ecc: f94e2be8    	ldr	x8, [sp, #0x1c50]
100024ed0: f90d0be8    	str	x8, [sp, #0x1a10]
100024ed4: 3dc673e0    	ldr	q0, [sp, #0x19c0]
100024ed8: 3d86ebe0    	str	q0, [sp, #0x1ba0]
100024edc: f94cebe8    	ldr	x8, [sp, #0x19d0]
100024ee0: f90ddbe8    	str	x8, [sp, #0x1bb0]
100024ee4: 3dc67be0    	ldr	q0, [sp, #0x19e0]
100024ee8: 3d86f3e0    	str	q0, [sp, #0x1bc0]
100024eec: f94cfbe8    	ldr	x8, [sp, #0x19f0]
100024ef0: f90debe8    	str	x8, [sp, #0x1bd0]
100024ef4: 3dc683e0    	ldr	q0, [sp, #0x1a00]
100024ef8: 3d86fbe0    	str	q0, [sp, #0x1be0]
100024efc: f94d0be8    	ldr	x8, [sp, #0x1a10]
100024f00: f90dfbe8    	str	x8, [sp, #0x1bf0]
100024f04: 3dc6ebe0    	ldr	q0, [sp, #0x1ba0]
100024f08: 3d865be0    	str	q0, [sp, #0x1960]
100024f0c: f94ddbe8    	ldr	x8, [sp, #0x1bb0]
100024f10: f90cbbe8    	str	x8, [sp, #0x1970]
100024f14: 3dc6f3e0    	ldr	q0, [sp, #0x1bc0]
100024f18: 3d8663e0    	str	q0, [sp, #0x1980]
100024f1c: f94debe8    	ldr	x8, [sp, #0x1bd0]
100024f20: f90ccbe8    	str	x8, [sp, #0x1990]
100024f24: 3dc6fbe0    	ldr	q0, [sp, #0x1be0]
100024f28: 3d866be0    	str	q0, [sp, #0x19a0]
100024f2c: f94dfbe8    	ldr	x8, [sp, #0x1bf0]
100024f30: f90cdbe8    	str	x8, [sp, #0x19b0]
100024f34: 3dc2dfe0    	ldr	q0, [sp, #0xb70]
100024f38: 3d84a7e0    	str	q0, [sp, #0x1290]
100024f3c: f945c3e8    	ldr	x8, [sp, #0xb80]
100024f40: f90953e8    	str	x8, [sp, #0x12a0]
100024f44: 3dc2e7e0    	ldr	q0, [sp, #0xb90]
100024f48: 3d84afe0    	str	q0, [sp, #0x12b0]
100024f4c: f945d3e8    	ldr	x8, [sp, #0xba0]
100024f50: f90963e8    	str	x8, [sp, #0x12c0]
100024f54: 3dc2efe0    	ldr	q0, [sp, #0xbb0]
100024f58: 3d84b7e0    	str	q0, [sp, #0x12d0]
100024f5c: f945e3e8    	ldr	x8, [sp, #0xbc0]
100024f60: f90973e8    	str	x8, [sp, #0x12e0]
100024f64: f94ccbe8    	ldr	x8, [sp, #0x1990]
100024f68: f90983e8    	str	x8, [sp, #0x1300]
100024f6c: 3dc663e0    	ldr	q0, [sp, #0x1980]
100024f70: 3d84bfe0    	str	q0, [sp, #0x12f0]
100024f74: 3dc65be0    	ldr	q0, [sp, #0x1960]
100024f78: f94cbbe8    	ldr	x8, [sp, #0x1970]
100024f7c: f90993e8    	str	x8, [sp, #0x1320]
100024f80: 3d84c7e0    	str	q0, [sp, #0x1310]
100024f84: f94cdbe8    	ldr	x8, [sp, #0x19b0]
100024f88: f909a3e8    	str	x8, [sp, #0x1340]
100024f8c: 3dc66be0    	ldr	q0, [sp, #0x19a0]
100024f90: 3d84cfe0    	str	q0, [sp, #0x1330]
100024f94: 100a20a9    	adr	x9, 0x1000393a8 <_.roc.static_data.9>
100024f98: d503201f    	nop
100024f9c: f9400928    	ldr	x8, [x9, #0x10]
100024fa0: f908f3e8    	str	x8, [sp, #0x11e0]
100024fa4: 3dc00120    	ldr	q0, [x9]
100024fa8: 3d8477e0    	str	q0, [sp, #0x11d0]
100024fac: f9406feb    	ldr	x11, [sp, #0xd8]
100024fb0: f90903eb    	str	x11, [sp, #0x1200]
100024fb4: 3dc03be2    	ldr	q2, [sp, #0xe0]
100024fb8: 3d847fe2    	str	q2, [sp, #0x11f0]
100024fbc: 100a1eaa    	adr	x10, 0x100039390 <_.roc.static_data.11>
100024fc0: d503201f    	nop
100024fc4: f9400949    	ldr	x9, [x10, #0x10]
100024fc8: f90913e9    	str	x9, [sp, #0x1220]
100024fcc: 3dc00141    	ldr	q1, [x10]
100024fd0: 3d8487e1    	str	q1, [sp, #0x1210]
100024fd4: f90923e8    	str	x8, [sp, #0x1240]
100024fd8: 3d848fe0    	str	q0, [sp, #0x1230]
100024fdc: 100a1f28    	adr	x8, 0x1000393c0 <_.roc.static_data.7>
100024fe0: d503201f    	nop
100024fe4: 3dc00100    	ldr	q0, [x8]
100024fe8: f9400908    	ldr	x8, [x8, #0x10]
100024fec: f90933e8    	str	x8, [sp, #0x1260]
100024ff0: 3d8497e0    	str	q0, [sp, #0x1250]
100024ff4: f90943eb    	str	x11, [sp, #0x1280]
100024ff8: 92800019    	mov	x25, #-0x1              ; =-1
100024ffc: f9407ff7    	ldr	x23, [sp, #0xf8]
100025000: 3d849fe2    	str	q2, [sp, #0x1270]
100025004: f940ebfc    	ldr	x28, [sp, #0x1d0]
100025008: 914007f5    	add	x21, sp, #0x1, lsl #12  ; =0x1000
10002500c: 911042b5    	add	x21, x21, #0x410
100025010: f94103f6    	ldr	x22, [sp, #0x200]
100025014: f940fbf4    	ldr	x20, [sp, #0x1f0]
100025018: 1400005c    	b	0x100025188 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6ef0>
10002501c: 52800028    	mov	w8, #0x1                ; =1
100025020: 914007ea    	add	x10, sp, #0x1, lsl #12  ; =0x1000
100025024: 910cc14a    	add	x10, x10, #0x330
100025028: 914007e9    	add	x9, sp, #0x1, lsl #12   ; =0x1000
10002502c: 910c4129    	add	x9, x9, #0x310
100025030: 914007ec    	add	x12, sp, #0x1, lsl #12  ; =0x1000
100025034: 910bc18c    	add	x12, x12, #0x2f0
100025038: 914007eb    	add	x11, sp, #0x1, lsl #12  ; =0x1000
10002503c: 910b416b    	add	x11, x11, #0x2d0
100025040: 914007ed    	add	x13, sp, #0x1, lsl #12  ; =0x1000
100025044: 910ac1ad    	add	x13, x13, #0x2b0
100025048: 914007ee    	add	x14, sp, #0x1, lsl #12  ; =0x1000
10002504c: 910a41ce    	add	x14, x14, #0x290
100025050: 3dc001c0    	ldr	q0, [x14]
100025054: 3d84d7e0    	str	q0, [sp, #0x1350]
100025058: f94009ce    	ldr	x14, [x14, #0x10]
10002505c: f909b3ee    	str	x14, [sp, #0x1360]
100025060: 3dc001a0    	ldr	q0, [x13]
100025064: 3d84dfe0    	str	q0, [sp, #0x1370]
100025068: f94009ad    	ldr	x13, [x13, #0x10]
10002506c: f909c3ed    	str	x13, [sp, #0x1380]
100025070: 3dc00160    	ldr	q0, [x11]
100025074: 3d84e7e0    	str	q0, [sp, #0x1390]
100025078: f940096b    	ldr	x11, [x11, #0x10]
10002507c: f909d3eb    	str	x11, [sp, #0x13a0]
100025080: f940098b    	ldr	x11, [x12, #0x10]
100025084: f909e3eb    	str	x11, [sp, #0x13c0]
100025088: 3dc00180    	ldr	q0, [x12]
10002508c: 3d84efe0    	str	q0, [sp, #0x13b0]
100025090: 3dc00120    	ldr	q0, [x9]
100025094: f9400929    	ldr	x9, [x9, #0x10]
100025098: f909f3e9    	str	x9, [sp, #0x13e0]
10002509c: 3d84f7e0    	str	q0, [sp, #0x13d0]
1000250a0: 3dc00140    	ldr	q0, [x10]
1000250a4: 3d84ffe0    	str	q0, [sp, #0x13f0]
1000250a8: f9400949    	ldr	x9, [x10, #0x10]
1000250ac: f90a03e9    	str	x9, [sp, #0x1400]
1000250b0: f94a53fc    	ldr	x28, [sp, #0x14a0]
1000250b4: f94a57f6    	ldr	x22, [sp, #0x14a8]
1000250b8: f94a5bf4    	ldr	x20, [sp, #0x14b0]
1000250bc: 3dc507e0    	ldr	q0, [sp, #0x1410]
1000250c0: 3d8477e0    	str	q0, [sp, #0x11d0]
1000250c4: f94a13e9    	ldr	x9, [sp, #0x1420]
1000250c8: f908f3e9    	str	x9, [sp, #0x11e0]
1000250cc: 914007f5    	add	x21, sp, #0x1, lsl #12  ; =0x1000
1000250d0: 911042b5    	add	x21, x21, #0x410
1000250d4: f84282a9    	ldur	x9, [x21, #0x28]
1000250d8: f90903e9    	str	x9, [sp, #0x1200]
1000250dc: 3cc182a0    	ldur	q0, [x21, #0x18]
1000250e0: 3d847fe0    	str	q0, [sp, #0x11f0]
1000250e4: 3cc482a0    	ldur	q0, [x21, #0x48]
1000250e8: f84582a9    	ldur	x9, [x21, #0x58]
1000250ec: f90913e9    	str	x9, [sp, #0x1220]
1000250f0: 3d8487e0    	str	q0, [sp, #0x1210]
1000250f4: f84402a9    	ldur	x9, [x21, #0x40]
1000250f8: f90923e9    	str	x9, [sp, #0x1240]
1000250fc: 3cc302a0    	ldur	q0, [x21, #0x30]
100025100: 3d848fe0    	str	q0, [sp, #0x1230]
100025104: f84882a9    	ldur	x9, [x21, #0x88]
100025108: f90933e9    	str	x9, [sp, #0x1260]
10002510c: 3cc782a0    	ldur	q0, [x21, #0x78]
100025110: 3d8497e0    	str	q0, [sp, #0x1250]
100025114: f84702a9    	ldur	x9, [x21, #0x70]
100025118: f90943e9    	str	x9, [sp, #0x1280]
10002511c: 3cc602a0    	ldur	q0, [x21, #0x60]
100025120: 3d849fe0    	str	q0, [sp, #0x1270]
100025124: f949b3e9    	ldr	x9, [sp, #0x1360]
100025128: f90953e9    	str	x9, [sp, #0x12a0]
10002512c: 3dc4d7e0    	ldr	q0, [sp, #0x1350]
100025130: 3d84a7e0    	str	q0, [sp, #0x1290]
100025134: 3dc4dfe0    	ldr	q0, [sp, #0x1370]
100025138: f949c3e9    	ldr	x9, [sp, #0x1380]
10002513c: f90963e9    	str	x9, [sp, #0x12c0]
100025140: 3d84afe0    	str	q0, [sp, #0x12b0]
100025144: 3dc4e7e0    	ldr	q0, [sp, #0x1390]
100025148: f949d3e9    	ldr	x9, [sp, #0x13a0]
10002514c: f90973e9    	str	x9, [sp, #0x12e0]
100025150: 3d84b7e0    	str	q0, [sp, #0x12d0]
100025154: 3dc4efe0    	ldr	q0, [sp, #0x13b0]
100025158: f949e3e9    	ldr	x9, [sp, #0x13c0]
10002515c: f90983e9    	str	x9, [sp, #0x1300]
100025160: 3d84bfe0    	str	q0, [sp, #0x12f0]
100025164: 3dc4f7e0    	ldr	q0, [sp, #0x13d0]
100025168: f949f3e9    	ldr	x9, [sp, #0x13e0]
10002516c: f90993e9    	str	x9, [sp, #0x1320]
100025170: 3d84c7e0    	str	q0, [sp, #0x1310]
100025174: 3dc4ffe0    	ldr	q0, [sp, #0x13f0]
100025178: f94a03e9    	ldr	x9, [sp, #0x1400]
10002517c: f909a3e9    	str	x9, [sp, #0x1340]
100025180: 3d84cfe0    	str	q0, [sp, #0x1330]
100025184: 37001688    	tbnz	w8, #0x0, 0x100025454 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x71bc>
100025188: 3dc49fe0    	ldr	q0, [sp, #0x1270]
10002518c: 3d8763e0    	str	q0, [sp, #0x1d80]
100025190: f94943e8    	ldr	x8, [sp, #0x1280]
100025194: f90ecbe8    	str	x8, [sp, #0x1d90]
100025198: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002519c: 91360000    	add	x0, x0, #0xd80
1000251a0: 94002c08    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000251a4: 3dc497e0    	ldr	q0, [sp, #0x1250]
1000251a8: 3d8763e0    	str	q0, [sp, #0x1d80]
1000251ac: f94933e8    	ldr	x8, [sp, #0x1260]
1000251b0: f90ecbe8    	str	x8, [sp, #0x1d90]
1000251b4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000251b8: 91360000    	add	x0, x0, #0xd80
1000251bc: 94002c01    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000251c0: 3dc48fe0    	ldr	q0, [sp, #0x1230]
1000251c4: 3d8763e0    	str	q0, [sp, #0x1d80]
1000251c8: f94923e8    	ldr	x8, [sp, #0x1240]
1000251cc: f90ecbe8    	str	x8, [sp, #0x1d90]
1000251d0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000251d4: 91360000    	add	x0, x0, #0xd80
1000251d8: 94002bfa    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000251dc: 3dc487e0    	ldr	q0, [sp, #0x1210]
1000251e0: 3d8763e0    	str	q0, [sp, #0x1d80]
1000251e4: f94913e8    	ldr	x8, [sp, #0x1220]
1000251e8: f90ecbe8    	str	x8, [sp, #0x1d90]
1000251ec: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000251f0: 91360000    	add	x0, x0, #0xd80
1000251f4: 94002bf3    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000251f8: 3dc47fe0    	ldr	q0, [sp, #0x11f0]
1000251fc: 3d8763e0    	str	q0, [sp, #0x1d80]
100025200: f94903e8    	ldr	x8, [sp, #0x1200]
100025204: f90ecbe8    	str	x8, [sp, #0x1d90]
100025208: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002520c: 91360000    	add	x0, x0, #0xd80
100025210: 94002bec    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100025214: 3dc477e0    	ldr	q0, [sp, #0x11d0]
100025218: 3d8763e0    	str	q0, [sp, #0x1d80]
10002521c: f948f3e8    	ldr	x8, [sp, #0x11e0]
100025220: f90ecbe8    	str	x8, [sp, #0x1d90]
100025224: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100025228: 91360000    	add	x0, x0, #0xd80
10002522c: 94002be5    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100025230: f941afe8    	ldr	x8, [sp, #0x358]
100025234: f90ee7e8    	str	x8, [sp, #0x1dc8]
100025238: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
10002523c: 91360108    	add	x8, x8, #0xd80
100025240: 3dc0bbe0    	ldr	q0, [sp, #0x2e0]
100025244: 3c850100    	stur	q0, [x8, #0x50]
100025248: f904d3fc    	str	x28, [sp, #0x9a0]
10002524c: f904d7f6    	str	x22, [sp, #0x9a8]
100025250: f904dbf4    	str	x20, [sp, #0x9b0]
100025254: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100025258: 91128000    	add	x0, x0, #0x4a0
10002525c: 914007e2    	add	x2, sp, #0x1, lsl #12   ; =0x1000
100025260: 91372042    	add	x2, x2, #0xdc8
100025264: 912683e4    	add	x4, sp, #0x9a0
100025268: 914007e5    	add	x5, sp, #0x1, lsl #12   ; =0x1000
10002526c: 910bc0a5    	add	x5, x5, #0x2f0
100025270: 914007e6    	add	x6, sp, #0x1, lsl #12   ; =0x1000
100025274: 910c40c6    	add	x6, x6, #0x310
100025278: 914007e7    	add	x7, sp, #0x1, lsl #12   ; =0x1000
10002527c: 910cc0e7    	add	x7, x7, #0x330
100025280: f9418bf4    	ldr	x20, [sp, #0x310]
100025284: aa1403e1    	mov	x1, x20
100025288: f94187e3    	ldr	x3, [sp, #0x308]
10002528c: 97ffd3a5    	bl	0x10001a120 <_roc__p251d42c9b11261f4b6c38feff48bfd2d.fast>
100025290: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100025294: 91104000    	add	x0, x0, #0x410
100025298: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
10002529c: 91128021    	add	x1, x1, #0x4a0
1000252a0: aa1403e2    	mov	x2, x20
1000252a4: 97ffd851    	bl	0x10001b3e8 <_roc__pe21b3db7436f4bcdc21a284b2c2e5c88.fast>
1000252a8: 910122a0    	add	x0, x21, #0x48
1000252ac: 9101e2a1    	add	x1, x21, #0x78
1000252b0: 914007e2    	add	x2, sp, #0x1, lsl #12   ; =0x1000
1000252b4: 91104042    	add	x2, x2, #0x410
1000252b8: 910062a3    	add	x3, x21, #0x18
1000252bc: 97ffd63b    	bl	0x10001aba8 <_roc__p9d8198fedbd801212718a09deebc5774.fast>
1000252c0: f9416be8    	ldr	x8, [sp, #0x2d0]
1000252c4: ab080008    	adds	x8, x0, x8
1000252c8: 914007f5    	add	x21, sp, #0x1, lsl #12  ; =0x1000
1000252cc: 911042b5    	add	x21, x21, #0x410
1000252d0: 5402a0c2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000252d4: aa0003f8    	mov	x24, x0
1000252d8: eb19011f    	cmp	x8, x25
1000252dc: 54ffea08    	b.hi	0x10002501c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6d84>
1000252e0: 3dc4b7e0    	ldr	q0, [sp, #0x12d0]
1000252e4: 3d8763e0    	str	q0, [sp, #0x1d80]
1000252e8: f94973e8    	ldr	x8, [sp, #0x12e0]
1000252ec: f90ecbe8    	str	x8, [sp, #0x1d90]
1000252f0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000252f4: 91360000    	add	x0, x0, #0xd80
1000252f8: 94002bb2    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000252fc: 3dc4afe0    	ldr	q0, [sp, #0x12b0]
100025300: 3d8763e0    	str	q0, [sp, #0x1d80]
100025304: f94963e8    	ldr	x8, [sp, #0x12c0]
100025308: f90ecbe8    	str	x8, [sp, #0x1d90]
10002530c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100025310: 91360000    	add	x0, x0, #0xd80
100025314: 94002bab    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100025318: 3dc4a7e0    	ldr	q0, [sp, #0x1290]
10002531c: 3d8763e0    	str	q0, [sp, #0x1d80]
100025320: f94953e8    	ldr	x8, [sp, #0x12a0]
100025324: f90ecbe8    	str	x8, [sp, #0x1d90]
100025328: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002532c: 91360000    	add	x0, x0, #0xd80
100025330: 94002ba4    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100025334: 3dc4bfe0    	ldr	q0, [sp, #0x12f0]
100025338: 3d8763e0    	str	q0, [sp, #0x1d80]
10002533c: f94983e8    	ldr	x8, [sp, #0x1300]
100025340: f90ecbe8    	str	x8, [sp, #0x1d90]
100025344: f94ec3e9    	ldr	x9, [sp, #0x1d80]
100025348: 927ff90a    	and	x10, x8, #0xfffffffffffffffe
10002534c: f240011f    	tst	x8, #0x1
100025350: 9a8a0128    	csel	x8, x9, x10, eq
100025354: b40000e8    	cbz	x8, 0x100025370 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x70d8>
100025358: f27df108    	ands	x8, x8, #0xfffffffffffffff8
10002535c: 540000a0    	b.eq	0x100025370 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x70d8>
100025360: f85f8109    	ldur	x9, [x8, #-0x8]
100025364: b4000069    	cbz	x9, 0x100025370 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x70d8>
100025368: 91000529    	add	x9, x9, #0x1
10002536c: f81f8109    	stur	x9, [x8, #-0x8]
100025370: 3dc4c7e0    	ldr	q0, [sp, #0x1310]
100025374: 3d8763e0    	str	q0, [sp, #0x1d80]
100025378: f94993e8    	ldr	x8, [sp, #0x1320]
10002537c: f90ecbe8    	str	x8, [sp, #0x1d90]
100025380: f94ec3e9    	ldr	x9, [sp, #0x1d80]
100025384: 927ff90a    	and	x10, x8, #0xfffffffffffffffe
100025388: f240011f    	tst	x8, #0x1
10002538c: 9a8a0128    	csel	x8, x9, x10, eq
100025390: b40000e8    	cbz	x8, 0x1000253ac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x7114>
100025394: f27df108    	ands	x8, x8, #0xfffffffffffffff8
100025398: 540000a0    	b.eq	0x1000253ac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x7114>
10002539c: f85f8109    	ldur	x9, [x8, #-0x8]
1000253a0: b4000069    	cbz	x9, 0x1000253ac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x7114>
1000253a4: 91000529    	add	x9, x9, #0x1
1000253a8: f81f8109    	stur	x9, [x8, #-0x8]
1000253ac: 3dc4cfe0    	ldr	q0, [sp, #0x1330]
1000253b0: 3d8763e0    	str	q0, [sp, #0x1d80]
1000253b4: f949a3e8    	ldr	x8, [sp, #0x1340]
1000253b8: f90ecbe8    	str	x8, [sp, #0x1d90]
1000253bc: f94ec3e9    	ldr	x9, [sp, #0x1d80]
1000253c0: 927ff90a    	and	x10, x8, #0xfffffffffffffffe
1000253c4: f240011f    	tst	x8, #0x1
1000253c8: 9a8a0128    	csel	x8, x9, x10, eq
1000253cc: b40000e8    	cbz	x8, 0x1000253e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x7150>
1000253d0: f27df108    	ands	x8, x8, #0xfffffffffffffff8
1000253d4: 540000a0    	b.eq	0x1000253e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x7150>
1000253d8: f85f8109    	ldur	x9, [x8, #-0x8]
1000253dc: b4000069    	cbz	x9, 0x1000253e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x7150>
1000253e0: 91000529    	add	x9, x9, #0x1
1000253e4: f81f8109    	stur	x9, [x8, #-0x8]
1000253e8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000253ec: 9112e000    	add	x0, x0, #0x4b8
1000253f0: 910122a1    	add	x1, x21, #0x48
1000253f4: 9101e2a2    	add	x2, x21, #0x78
1000253f8: 914007e3    	add	x3, sp, #0x1, lsl #12   ; =0x1000
1000253fc: 910bc063    	add	x3, x3, #0x2f0
100025400: 914007e4    	add	x4, sp, #0x1, lsl #12   ; =0x1000
100025404: 910c4084    	add	x4, x4, #0x310
100025408: 914007e5    	add	x5, sp, #0x1, lsl #12   ; =0x1000
10002540c: 910cc0a5    	add	x5, x5, #0x330
100025410: 97ffd498    	bl	0x10001a670 <_roc__p499ff7eb2f98e9031bc9d0002db086b6.fast>
100025414: f10006f7    	subs	x23, x23, #0x1
100025418: 54029723    	b.lo	0x10002a6fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc464>
10002541c: f10002ff    	cmp	x23, #0x0
100025420: 1a9f17e8    	cset	w8, eq
100025424: 914007e9    	add	x9, sp, #0x1, lsl #12   ; =0x1000
100025428: 9112e129    	add	x9, x9, #0x4b8
10002542c: 914007eb    	add	x11, sp, #0x1, lsl #12  ; =0x1000
100025430: 910cc16b    	add	x11, x11, #0x330
100025434: 914007ed    	add	x13, sp, #0x1, lsl #12  ; =0x1000
100025438: 910c41ad    	add	x13, x13, #0x310
10002543c: 914007ee    	add	x14, sp, #0x1, lsl #12  ; =0x1000
100025440: 910bc1ce    	add	x14, x14, #0x2f0
100025444: f94133ec    	ldr	x12, [sp, #0x260]
100025448: f9412bea    	ldr	x10, [sp, #0x250]
10002544c: aa1803f9    	mov	x25, x24
100025450: 17ffff00    	b	0x100025050 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6db8>
100025454: f900fbf4    	str	x20, [sp, #0x1f0]
100025458: f90103f6    	str	x22, [sp, #0x200]
10002545c: 3dc4d7e0    	ldr	q0, [sp, #0x1350]
100025460: 3d8317e0    	str	q0, [sp, #0xc50]
100025464: f949b3e8    	ldr	x8, [sp, #0x1360]
100025468: f90633e8    	str	x8, [sp, #0xc60]
10002546c: 3dc4dfe0    	ldr	q0, [sp, #0x1370]
100025470: 3d831fe0    	str	q0, [sp, #0xc70]
100025474: f949c3e8    	ldr	x8, [sp, #0x1380]
100025478: f90643e8    	str	x8, [sp, #0xc80]
10002547c: 3dc4e7e0    	ldr	q0, [sp, #0x1390]
100025480: f949d3e8    	ldr	x8, [sp, #0x13a0]
100025484: f90653e8    	str	x8, [sp, #0xca0]
100025488: f94043f5    	ldr	x21, [sp, #0x80]
10002548c: f94157f6    	ldr	x22, [sp, #0x2a8]
100025490: eb1602bf    	cmp	x21, x22
100025494: 9a9632a8    	csel	x8, x21, x22, lo
100025498: 3d8327e0    	str	q0, [sp, #0xc90]
10002549c: eb19011f    	cmp	x8, x25
1000254a0: 54001142    	b.hs	0x1000256c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x7430>
1000254a4: 914007f4    	add	x20, sp, #0x1, lsl #12  ; =0x1000
1000254a8: 91104294    	add	x20, x20, #0x410
1000254ac: 3cc60280    	ldur	q0, [x20, #0x60]
1000254b0: 3d8763e0    	str	q0, [sp, #0x1d80]
1000254b4: f8470288    	ldur	x8, [x20, #0x70]
1000254b8: f90ecbe8    	str	x8, [sp, #0x1d90]
1000254bc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000254c0: 91360000    	add	x0, x0, #0xd80
1000254c4: 94002b3f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000254c8: 3cc78280    	ldur	q0, [x20, #0x78]
1000254cc: 3d8763e0    	str	q0, [sp, #0x1d80]
1000254d0: f8488288    	ldur	x8, [x20, #0x88]
1000254d4: f90ecbe8    	str	x8, [sp, #0x1d90]
1000254d8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000254dc: 91360000    	add	x0, x0, #0xd80
1000254e0: 94002b38    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000254e4: 3cc30280    	ldur	q0, [x20, #0x30]
1000254e8: 3d8763e0    	str	q0, [sp, #0x1d80]
1000254ec: f8440288    	ldur	x8, [x20, #0x40]
1000254f0: f90ecbe8    	str	x8, [sp, #0x1d90]
1000254f4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000254f8: 91360000    	add	x0, x0, #0xd80
1000254fc: 94002b31    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100025500: 3cc48280    	ldur	q0, [x20, #0x48]
100025504: 3d8763e0    	str	q0, [sp, #0x1d80]
100025508: f8458288    	ldur	x8, [x20, #0x58]
10002550c: f90ecbe8    	str	x8, [sp, #0x1d90]
100025510: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100025514: 91360000    	add	x0, x0, #0xd80
100025518: 94002b2a    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002551c: 3cc18280    	ldur	q0, [x20, #0x18]
100025520: 3d8763e0    	str	q0, [sp, #0x1d80]
100025524: f8428288    	ldur	x8, [x20, #0x28]
100025528: f90ecbe8    	str	x8, [sp, #0x1d90]
10002552c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100025530: 91360000    	add	x0, x0, #0xd80
100025534: 94002b23    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100025538: 3dc507e0    	ldr	q0, [sp, #0x1410]
10002553c: 3d8763e0    	str	q0, [sp, #0x1d80]
100025540: f94a13e8    	ldr	x8, [sp, #0x1420]
100025544: f90ecbe8    	str	x8, [sp, #0x1d90]
100025548: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002554c: 91360000    	add	x0, x0, #0xd80
100025550: 94002b1c    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100025554: eb1602bf    	cmp	x21, x22
100025558: 540014c2    	b.hs	0x1000257f0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x7558>
10002555c: f9419fe8    	ldr	x8, [sp, #0x338]
100025560: f904d3e8    	str	x8, [sp, #0x9a0]
100025564: f941a3e8    	ldr	x8, [sp, #0x340]
100025568: f904d7e8    	str	x8, [sp, #0x9a8]
10002556c: f9413fe8    	ldr	x8, [sp, #0x278]
100025570: f904dbe8    	str	x8, [sp, #0x9b0]
100025574: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100025578: 9104a000    	add	x0, x0, #0x128
10002557c: 912683e1    	add	x1, sp, #0x9a0
100025580: f94183e2    	ldr	x2, [sp, #0x300]
100025584: f9418bf6    	ldr	x22, [sp, #0x310]
100025588: aa1603e3    	mov	x3, x22
10002558c: 97ffd8bf    	bl	0x10001b888 <_roc__p7f95ed46022205c5413858b3de8531cb.fast>
100025590: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100025594: 91038000    	add	x0, x0, #0xe0
100025598: 914007f5    	add	x21, sp, #0x1, lsl #12  ; =0x1000
10002559c: 9104a2b5    	add	x21, x21, #0x128
1000255a0: 910122a1    	add	x1, x21, #0x48
1000255a4: 9101e2a2    	add	x2, x21, #0x78
1000255a8: 914007e3    	add	x3, sp, #0x1, lsl #12   ; =0x1000
1000255ac: 910ec063    	add	x3, x3, #0x3b0
1000255b0: 914007e4    	add	x4, sp, #0x1, lsl #12   ; =0x1000
1000255b4: 910f4084    	add	x4, x4, #0x3d0
1000255b8: 914007e5    	add	x5, sp, #0x1, lsl #12   ; =0x1000
1000255bc: 910fc0a5    	add	x5, x5, #0x3f0
1000255c0: 97ffd42c    	bl	0x10001a670 <_roc__p499ff7eb2f98e9031bc9d0002db086b6.fast>
1000255c4: f94193f4    	ldr	x20, [sp, #0x320]
1000255c8: 52800037    	mov	w23, #0x1               ; =1
1000255cc: f940cbe4    	ldr	x4, [sp, #0x190]
1000255d0: f94187f9    	ldr	x25, [sp, #0x308]
1000255d4: f9403ff8    	ldr	x24, [sp, #0x78]
1000255d8: b403cd64    	cbz	x4, 0x10002cf84 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xecec>
1000255dc: d280000c    	mov	x12, #0x0               ; =0
1000255e0: f940d7e2    	ldr	x2, [sp, #0x1a8]
1000255e4: 29007c56    	stp	w22, wzr, [x2]
1000255e8: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000255ec: 91038108    	add	x8, x8, #0xe0
1000255f0: 3cc48100    	ldur	q0, [x8, #0x48]
1000255f4: 3d83b7e0    	str	q0, [sp, #0xed0]
1000255f8: f9489fe8    	ldr	x8, [sp, #0x1138]
1000255fc: f90773e8    	str	x8, [sp, #0xee0]
100025600: 3cc182a0    	ldur	q0, [x21, #0x18]
100025604: 3d83bfe0    	str	q0, [sp, #0xef0]
100025608: f84282a8    	ldur	x8, [x21, #0x28]
10002560c: f90783e8    	str	x8, [sp, #0xf00]
100025610: 3cc482a0    	ldur	q0, [x21, #0x48]
100025614: 3d83c7e0    	str	q0, [sp, #0xf10]
100025618: f84582a8    	ldur	x8, [x21, #0x58]
10002561c: f90793e8    	str	x8, [sp, #0xf20]
100025620: f84402a8    	ldur	x8, [x21, #0x40]
100025624: f907a3e8    	str	x8, [sp, #0xf40]
100025628: 3cc302a0    	ldur	q0, [x21, #0x30]
10002562c: 3d83cfe0    	str	q0, [sp, #0xf30]
100025630: f84882a8    	ldur	x8, [x21, #0x88]
100025634: f907b3e8    	str	x8, [sp, #0xf60]
100025638: 3cc782a0    	ldur	q0, [x21, #0x78]
10002563c: 3d83d7e0    	str	q0, [sp, #0xf50]
100025640: f84702a8    	ldur	x8, [x21, #0x70]
100025644: f907c3e8    	str	x8, [sp, #0xf80]
100025648: 3cc602a0    	ldur	q0, [x21, #0x60]
10002564c: 3d83dfe0    	str	q0, [sp, #0xf70]
100025650: 914007ee    	add	x14, sp, #0x1, lsl #12  ; =0x1000
100025654: 910381ce    	add	x14, x14, #0xe0
100025658: f84281c8    	ldur	x8, [x14, #0x28]
10002565c: f907d3e8    	str	x8, [sp, #0xfa0]
100025660: 3cc181c0    	ldur	q0, [x14, #0x18]
100025664: 3d83e7e0    	str	q0, [sp, #0xf90]
100025668: f9487be8    	ldr	x8, [sp, #0x10f0]
10002566c: f907e3e8    	str	x8, [sp, #0xfc0]
100025670: 3dc43be0    	ldr	q0, [sp, #0x10e0]
100025674: 913f43e8    	add	x8, sp, #0xfd0
100025678: 3d83efe0    	str	q0, [sp, #0xfb0]
10002567c: 913ec3e9    	add	x9, sp, #0xfb0
100025680: 913e43ea    	add	x10, sp, #0xf90
100025684: 3cc301c0    	ldur	q0, [x14, #0x30]
100025688: 913dc3eb    	add	x11, sp, #0xf70
10002568c: 913d43ed    	add	x13, sp, #0xf50
100025690: f84401d0    	ldur	x16, [x14, #0x40]
100025694: 913cc3ee    	add	x14, sp, #0xf30
100025698: 913c43ef    	add	x15, sp, #0xf10
10002569c: f907f3f0    	str	x16, [sp, #0xfe0]
1000256a0: 913bc3f0    	add	x16, sp, #0xef0
1000256a4: 913b43f1    	add	x17, sp, #0xed0
1000256a8: 52800020    	mov	w0, #0x1                ; =1
1000256ac: f90157e0    	str	x0, [sp, #0x2a8]
1000256b0: 3d83f7e0    	str	q0, [sp, #0xfd0]
1000256b4: f9419fe0    	ldr	x0, [sp, #0x338]
1000256b8: f941a3e1    	ldr	x1, [sp, #0x340]
1000256bc: f94103e3    	ldr	x3, [sp, #0x200]
1000256c0: f940fbe5    	ldr	x5, [sp, #0x1f0]
1000256c4: 1400018d    	b	0x100025cf8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x7a60>
1000256c8: f9416be8    	ldr	x8, [sp, #0x2d0]
1000256cc: ab080328    	adds	x8, x25, x8
1000256d0: 540280c2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000256d4: eb08031f    	cmp	x24, x8
1000256d8: 52800037    	mov	w23, #0x1               ; =1
1000256dc: 54001582    	b.hs	0x10002598c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x76f4>
1000256e0: f90157ff    	str	xzr, [sp, #0x2a8]
1000256e4: 3dc507e0    	ldr	q0, [sp, #0x1410]
1000256e8: 3d871be0    	str	q0, [sp, #0x1c60]
1000256ec: f94a13e8    	ldr	x8, [sp, #0x1420]
1000256f0: f90e3be8    	str	x8, [sp, #0x1c70]
1000256f4: 914007e9    	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000256f8: 91104129    	add	x9, x9, #0x410
1000256fc: 3cc18120    	ldur	q0, [x9, #0x18]
100025700: 3d8723e0    	str	q0, [sp, #0x1c80]
100025704: f8428128    	ldur	x8, [x9, #0x28]
100025708: f90e4be8    	str	x8, [sp, #0x1c90]
10002570c: 3cc48120    	ldur	q0, [x9, #0x48]
100025710: 3d872be0    	str	q0, [sp, #0x1ca0]
100025714: f8458128    	ldur	x8, [x9, #0x58]
100025718: f90e5be8    	str	x8, [sp, #0x1cb0]
10002571c: f8440128    	ldur	x8, [x9, #0x40]
100025720: f90e6be8    	str	x8, [sp, #0x1cd0]
100025724: 3cc30120    	ldur	q0, [x9, #0x30]
100025728: 3d8733e0    	str	q0, [sp, #0x1cc0]
10002572c: 3cc78120    	ldur	q0, [x9, #0x78]
100025730: f8488128    	ldur	x8, [x9, #0x88]
100025734: f90e7be8    	str	x8, [sp, #0x1cf0]
100025738: 3d873be0    	str	q0, [sp, #0x1ce0]
10002573c: f8470128    	ldur	x8, [x9, #0x70]
100025740: f90e8be8    	str	x8, [sp, #0x1d10]
100025744: 3cc60120    	ldur	q0, [x9, #0x60]
100025748: 3d8743e0    	str	q0, [sp, #0x1d00]
10002574c: f949e3e8    	ldr	x8, [sp, #0x13c0]
100025750: f90e9be8    	str	x8, [sp, #0x1d30]
100025754: 3dc4efe0    	ldr	q0, [sp, #0x13b0]
100025758: 3d874be0    	str	q0, [sp, #0x1d20]
10002575c: f949f3e8    	ldr	x8, [sp, #0x13e0]
100025760: f90eabe8    	str	x8, [sp, #0x1d50]
100025764: 3dc4f7e0    	ldr	q0, [sp, #0x13d0]
100025768: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
10002576c: 91358108    	add	x8, x8, #0xd60
100025770: 3d8753e0    	str	q0, [sp, #0x1d40]
100025774: 914007e9    	add	x9, sp, #0x1, lsl #12   ; =0x1000
100025778: 91350129    	add	x9, x9, #0xd40
10002577c: 914007ea    	add	x10, sp, #0x1, lsl #12  ; =0x1000
100025780: 9134814a    	add	x10, x10, #0xd20
100025784: f94a03ec    	ldr	x12, [sp, #0x1400]
100025788: 914007eb    	add	x11, sp, #0x1, lsl #12  ; =0x1000
10002578c: 9134016b    	add	x11, x11, #0xd00
100025790: 914007ed    	add	x13, sp, #0x1, lsl #12  ; =0x1000
100025794: 913381ad    	add	x13, x13, #0xce0
100025798: f90ebbec    	str	x12, [sp, #0x1d70]
10002579c: 914007ee    	add	x14, sp, #0x1, lsl #12  ; =0x1000
1000257a0: 913301ce    	add	x14, x14, #0xcc0
1000257a4: 914007ef    	add	x15, sp, #0x1, lsl #12  ; =0x1000
1000257a8: 913281ef    	add	x15, x15, #0xca0
1000257ac: 3dc4ffe0    	ldr	q0, [sp, #0x13f0]
1000257b0: 914007f0    	add	x16, sp, #0x1, lsl #12  ; =0x1000
1000257b4: 91320210    	add	x16, x16, #0xc80
1000257b8: 914007f1    	add	x17, sp, #0x1, lsl #12  ; =0x1000
1000257bc: 91318231    	add	x17, x17, #0xc60
1000257c0: 5280002c    	mov	w12, #0x1               ; =1
1000257c4: 3d875be0    	str	q0, [sp, #0x1d60]
1000257c8: f9419fe0    	ldr	x0, [sp, #0x338]
1000257cc: f941a3e1    	ldr	x1, [sp, #0x340]
1000257d0: f94193f4    	ldr	x20, [sp, #0x320]
1000257d4: f940d7e2    	ldr	x2, [sp, #0x1a8]
1000257d8: f94103e3    	ldr	x3, [sp, #0x200]
1000257dc: f940cbe4    	ldr	x4, [sp, #0x190]
1000257e0: f940fbe5    	ldr	x5, [sp, #0x1f0]
1000257e4: f94187f9    	ldr	x25, [sp, #0x308]
1000257e8: f9418bf6    	ldr	x22, [sp, #0x310]
1000257ec: 14000066    	b	0x100025984 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x76ec>
1000257f0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000257f4: 91002000    	add	x0, x0, #0x8
1000257f8: 912f43e1    	add	x1, sp, #0xbd0
1000257fc: 913043e2    	add	x2, sp, #0xc10
100025800: 914007e3    	add	x3, sp, #0x1, lsl #12   ; =0x1000
100025804: 910ec063    	add	x3, x3, #0x3b0
100025808: 914007e4    	add	x4, sp, #0x1, lsl #12   ; =0x1000
10002580c: 910f4084    	add	x4, x4, #0x3d0
100025810: 914007e5    	add	x5, sp, #0x1, lsl #12   ; =0x1000
100025814: 910fc0a5    	add	x5, x5, #0x3f0
100025818: 97ffd396    	bl	0x10001a670 <_roc__p499ff7eb2f98e9031bc9d0002db086b6.fast>
10002581c: f941afe8    	ldr	x8, [sp, #0x358]
100025820: f90ee7e8    	str	x8, [sp, #0x1dc8]
100025824: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
100025828: 91360108    	add	x8, x8, #0xd80
10002582c: 3dc0bbe0    	ldr	q0, [sp, #0x2e0]
100025830: 3c850100    	stur	q0, [x8, #0x50]
100025834: f904d3fc    	str	x28, [sp, #0x9a0]
100025838: f94103e8    	ldr	x8, [sp, #0x200]
10002583c: f904d7e8    	str	x8, [sp, #0x9a8]
100025840: f940fbe8    	ldr	x8, [sp, #0x1f0]
100025844: f904dbe8    	str	x8, [sp, #0x9b0]
100025848: 913fc3e0    	add	x0, sp, #0xff0
10002584c: 914007e2    	add	x2, sp, #0x1, lsl #12   ; =0x1000
100025850: 91372042    	add	x2, x2, #0xdc8
100025854: 912683e4    	add	x4, sp, #0x9a0
100025858: 914007f4    	add	x20, sp, #0x1, lsl #12  ; =0x1000
10002585c: 91002294    	add	x20, x20, #0x8
100025860: 91006285    	add	x5, x20, #0x18
100025864: 914007e6    	add	x6, sp, #0x1, lsl #12   ; =0x1000
100025868: 910020c6    	add	x6, x6, #0x8
10002586c: 9100c287    	add	x7, x20, #0x30
100025870: f9418bf6    	ldr	x22, [sp, #0x310]
100025874: aa1603e1    	mov	x1, x22
100025878: f94187f9    	ldr	x25, [sp, #0x308]
10002587c: aa1903e3    	mov	x3, x25
100025880: 97ffd228    	bl	0x10001a120 <_roc__p251d42c9b11261f4b6c38feff48bfd2d.fast>
100025884: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100025888: 91014000    	add	x0, x0, #0x50
10002588c: 913fc3e1    	add	x1, sp, #0xff0
100025890: aa1603e2    	mov	x2, x22
100025894: 97ffd6d5    	bl	0x10001b3e8 <_roc__pe21b3db7436f4bcdc21a284b2c2e5c88.fast>
100025898: f90157ff    	str	xzr, [sp, #0x2a8]
10002589c: 3dc417e0    	ldr	q0, [sp, #0x1050]
1000258a0: 3d83b7e0    	str	q0, [sp, #0xed0]
1000258a4: f94833e8    	ldr	x8, [sp, #0x1060]
1000258a8: f90773e8    	str	x8, [sp, #0xee0]
1000258ac: 914007e9    	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000258b0: 91014129    	add	x9, x9, #0x50
1000258b4: 3cc18120    	ldur	q0, [x9, #0x18]
1000258b8: 3d83bfe0    	str	q0, [sp, #0xef0]
1000258bc: f8428128    	ldur	x8, [x9, #0x28]
1000258c0: f90783e8    	str	x8, [sp, #0xf00]
1000258c4: 3cc48120    	ldur	q0, [x9, #0x48]
1000258c8: 3d83c7e0    	str	q0, [sp, #0xf10]
1000258cc: f8458128    	ldur	x8, [x9, #0x58]
1000258d0: f90793e8    	str	x8, [sp, #0xf20]
1000258d4: f8440128    	ldur	x8, [x9, #0x40]
1000258d8: f907a3e8    	str	x8, [sp, #0xf40]
1000258dc: 3cc30120    	ldur	q0, [x9, #0x30]
1000258e0: 3d83cfe0    	str	q0, [sp, #0xf30]
1000258e4: 3cc78120    	ldur	q0, [x9, #0x78]
1000258e8: f8488128    	ldur	x8, [x9, #0x88]
1000258ec: f907b3e8    	str	x8, [sp, #0xf60]
1000258f0: 3d83d7e0    	str	q0, [sp, #0xf50]
1000258f4: f8470128    	ldur	x8, [x9, #0x70]
1000258f8: f907c3e8    	str	x8, [sp, #0xf80]
1000258fc: 3cc60120    	ldur	q0, [x9, #0x60]
100025900: 3d83dfe0    	str	q0, [sp, #0xf70]
100025904: f8428288    	ldur	x8, [x20, #0x28]
100025908: f907d3e8    	str	x8, [sp, #0xfa0]
10002590c: 3cc18280    	ldur	q0, [x20, #0x18]
100025910: 3d83e7e0    	str	q0, [sp, #0xf90]
100025914: f9480fe8    	ldr	x8, [sp, #0x1018]
100025918: f907e3e8    	str	x8, [sp, #0xfc0]
10002591c: 9137e3e8    	add	x8, sp, #0xdf8
100025920: 3dc08500    	ldr	q0, [x8, #0x210]
100025924: 3d83efe0    	str	q0, [sp, #0xfb0]
100025928: f8440288    	ldur	x8, [x20, #0x40]
10002592c: f907f3e8    	str	x8, [sp, #0xfe0]
100025930: 913f43e8    	add	x8, sp, #0xfd0
100025934: 3cc30280    	ldur	q0, [x20, #0x30]
100025938: 913ec3e9    	add	x9, sp, #0xfb0
10002593c: 913e43ea    	add	x10, sp, #0xf90
100025940: 3d83f7e0    	str	q0, [sp, #0xfd0]
100025944: 913dc3eb    	add	x11, sp, #0xf70
100025948: 913d43ed    	add	x13, sp, #0xf50
10002594c: 913cc3ee    	add	x14, sp, #0xf30
100025950: 913c43ef    	add	x15, sp, #0xf10
100025954: f947fbfc    	ldr	x28, [sp, #0xff0]
100025958: f947ffe3    	ldr	x3, [sp, #0xff8]
10002595c: 913bc3f0    	add	x16, sp, #0xef0
100025960: 913b43f1    	add	x17, sp, #0xed0
100025964: 5280002c    	mov	w12, #0x1               ; =1
100025968: f94803e5    	ldr	x5, [sp, #0x1000]
10002596c: f9419fe0    	ldr	x0, [sp, #0x338]
100025970: f941a3e1    	ldr	x1, [sp, #0x340]
100025974: f94193f4    	ldr	x20, [sp, #0x320]
100025978: 52800037    	mov	w23, #0x1               ; =1
10002597c: f940d7e2    	ldr	x2, [sp, #0x1a8]
100025980: f940cbe4    	ldr	x4, [sp, #0x190]
100025984: f9403ff8    	ldr	x24, [sp, #0x78]
100025988: 140000dc    	b	0x100025cf8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x7a60>
10002598c: 3dc4ffe0    	ldr	q0, [sp, #0x13f0]
100025990: 3d8763e0    	str	q0, [sp, #0x1d80]
100025994: f94a03e8    	ldr	x8, [sp, #0x1400]
100025998: f90ecbe8    	str	x8, [sp, #0x1d90]
10002599c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000259a0: 91360000    	add	x0, x0, #0xd80
1000259a4: 94002a07    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000259a8: 3dc4f7e0    	ldr	q0, [sp, #0x13d0]
1000259ac: 3d8763e0    	str	q0, [sp, #0x1d80]
1000259b0: f949f3e8    	ldr	x8, [sp, #0x13e0]
1000259b4: f90ecbe8    	str	x8, [sp, #0x1d90]
1000259b8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000259bc: 91360000    	add	x0, x0, #0xd80
1000259c0: 94002a00    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000259c4: 3dc4efe0    	ldr	q0, [sp, #0x13b0]
1000259c8: 3d8763e0    	str	q0, [sp, #0x1d80]
1000259cc: f949e3e8    	ldr	x8, [sp, #0x13c0]
1000259d0: f90ecbe8    	str	x8, [sp, #0x1d90]
1000259d4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000259d8: 91360000    	add	x0, x0, #0xd80
1000259dc: 940029f9    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000259e0: 914007f4    	add	x20, sp, #0x1, lsl #12  ; =0x1000
1000259e4: 91104294    	add	x20, x20, #0x410
1000259e8: 3cc60280    	ldur	q0, [x20, #0x60]
1000259ec: 3d8763e0    	str	q0, [sp, #0x1d80]
1000259f0: f8470288    	ldur	x8, [x20, #0x70]
1000259f4: f90ecbe8    	str	x8, [sp, #0x1d90]
1000259f8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000259fc: 91360000    	add	x0, x0, #0xd80
100025a00: 940029f0    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100025a04: 3cc78280    	ldur	q0, [x20, #0x78]
100025a08: 3d8763e0    	str	q0, [sp, #0x1d80]
100025a0c: f8488288    	ldur	x8, [x20, #0x88]
100025a10: f90ecbe8    	str	x8, [sp, #0x1d90]
100025a14: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100025a18: 91360000    	add	x0, x0, #0xd80
100025a1c: 940029e9    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100025a20: 3cc30280    	ldur	q0, [x20, #0x30]
100025a24: 3d8763e0    	str	q0, [sp, #0x1d80]
100025a28: f8440288    	ldur	x8, [x20, #0x40]
100025a2c: f90ecbe8    	str	x8, [sp, #0x1d90]
100025a30: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100025a34: 91360000    	add	x0, x0, #0xd80
100025a38: 940029e2    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100025a3c: 3cc48280    	ldur	q0, [x20, #0x48]
100025a40: 3d8763e0    	str	q0, [sp, #0x1d80]
100025a44: f8458288    	ldur	x8, [x20, #0x58]
100025a48: f90ecbe8    	str	x8, [sp, #0x1d90]
100025a4c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100025a50: 91360000    	add	x0, x0, #0xd80
100025a54: 940029db    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100025a58: 3cc18280    	ldur	q0, [x20, #0x18]
100025a5c: 3d8763e0    	str	q0, [sp, #0x1d80]
100025a60: f8428288    	ldur	x8, [x20, #0x28]
100025a64: f90ecbe8    	str	x8, [sp, #0x1d90]
100025a68: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100025a6c: 91360000    	add	x0, x0, #0xd80
100025a70: 940029d4    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100025a74: 3dc507e0    	ldr	q0, [sp, #0x1410]
100025a78: 3d8763e0    	str	q0, [sp, #0x1d80]
100025a7c: f94a13e8    	ldr	x8, [sp, #0x1420]
100025a80: f90ecbe8    	str	x8, [sp, #0x1d90]
100025a84: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100025a88: 91360000    	add	x0, x0, #0xd80
100025a8c: 940029cd    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100025a90: f941afe8    	ldr	x8, [sp, #0x358]
100025a94: f90ee7e8    	str	x8, [sp, #0x1dc8]
100025a98: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
100025a9c: 91360108    	add	x8, x8, #0xd80
100025aa0: 3dc0bbe0    	ldr	q0, [sp, #0x2e0]
100025aa4: 3c850100    	stur	q0, [x8, #0x50]
100025aa8: f904d3fc    	str	x28, [sp, #0x9a0]
100025aac: f94103e8    	ldr	x8, [sp, #0x200]
100025ab0: f904d7e8    	str	x8, [sp, #0x9a8]
100025ab4: f940fbe8    	ldr	x8, [sp, #0x1f0]
100025ab8: f904dbe8    	str	x8, [sp, #0x9b0]
100025abc: 913783e0    	add	x0, sp, #0xde0
100025ac0: 914007e2    	add	x2, sp, #0x1, lsl #12   ; =0x1000
100025ac4: 91372042    	add	x2, x2, #0xdc8
100025ac8: 912683e4    	add	x4, sp, #0x9a0
100025acc: 914007e5    	add	x5, sp, #0x1, lsl #12   ; =0x1000
100025ad0: 910d40a5    	add	x5, x5, #0x350
100025ad4: 914007e6    	add	x6, sp, #0x1, lsl #12   ; =0x1000
100025ad8: 910dc0c6    	add	x6, x6, #0x370
100025adc: 914007e7    	add	x7, sp, #0x1, lsl #12   ; =0x1000
100025ae0: 910e40e7    	add	x7, x7, #0x390
100025ae4: f9418bf4    	ldr	x20, [sp, #0x310]
100025ae8: aa1403e1    	mov	x1, x20
100025aec: f94187f9    	ldr	x25, [sp, #0x308]
100025af0: aa1903e3    	mov	x3, x25
100025af4: 97ffd18b    	bl	0x10001a120 <_roc__p251d42c9b11261f4b6c38feff48bfd2d.fast>
100025af8: 913903e0    	add	x0, sp, #0xe40
100025afc: 913783e1    	add	x1, sp, #0xde0
100025b00: aa1403e2    	mov	x2, x20
100025b04: 97ffd639    	bl	0x10001b3e8 <_roc__pe21b3db7436f4bcdc21a284b2c2e5c88.fast>
100025b08: 3dc4d7e0    	ldr	q0, [sp, #0x1350]
100025b0c: 3d8763e0    	str	q0, [sp, #0x1d80]
100025b10: f949b3e8    	ldr	x8, [sp, #0x1360]
100025b14: f90ecbe8    	str	x8, [sp, #0x1d90]
100025b18: f94ec3e9    	ldr	x9, [sp, #0x1d80]
100025b1c: 927ff90a    	and	x10, x8, #0xfffffffffffffffe
100025b20: f240011f    	tst	x8, #0x1
100025b24: 9a8a0128    	csel	x8, x9, x10, eq
100025b28: f94193f4    	ldr	x20, [sp, #0x320]
100025b2c: f9403ff8    	ldr	x24, [sp, #0x78]
100025b30: b40000e8    	cbz	x8, 0x100025b4c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x78b4>
100025b34: f27df108    	ands	x8, x8, #0xfffffffffffffff8
100025b38: 540000a0    	b.eq	0x100025b4c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x78b4>
100025b3c: f85f8109    	ldur	x9, [x8, #-0x8]
100025b40: b4000069    	cbz	x9, 0x100025b4c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x78b4>
100025b44: 91000529    	add	x9, x9, #0x1
100025b48: f81f8109    	stur	x9, [x8, #-0x8]
100025b4c: 3dc4dfe0    	ldr	q0, [sp, #0x1370]
100025b50: 3d8763e0    	str	q0, [sp, #0x1d80]
100025b54: f949c3e8    	ldr	x8, [sp, #0x1380]
100025b58: f90ecbe8    	str	x8, [sp, #0x1d90]
100025b5c: f94ec3e9    	ldr	x9, [sp, #0x1d80]
100025b60: 927ff90a    	and	x10, x8, #0xfffffffffffffffe
100025b64: f240011f    	tst	x8, #0x1
100025b68: 9a8a0128    	csel	x8, x9, x10, eq
100025b6c: b40000e8    	cbz	x8, 0x100025b88 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x78f0>
100025b70: f27df108    	ands	x8, x8, #0xfffffffffffffff8
100025b74: 540000a0    	b.eq	0x100025b88 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x78f0>
100025b78: f85f8109    	ldur	x9, [x8, #-0x8]
100025b7c: b4000069    	cbz	x9, 0x100025b88 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x78f0>
100025b80: 91000529    	add	x9, x9, #0x1
100025b84: f81f8109    	stur	x9, [x8, #-0x8]
100025b88: 3dc4e7e0    	ldr	q0, [sp, #0x1390]
100025b8c: 3d8763e0    	str	q0, [sp, #0x1d80]
100025b90: f949d3e8    	ldr	x8, [sp, #0x13a0]
100025b94: f90ecbe8    	str	x8, [sp, #0x1d90]
100025b98: f94ec3e9    	ldr	x9, [sp, #0x1d80]
100025b9c: 927ff90a    	and	x10, x8, #0xfffffffffffffffe
100025ba0: f240011f    	tst	x8, #0x1
100025ba4: 9a8a0128    	csel	x8, x9, x10, eq
100025ba8: b40000e8    	cbz	x8, 0x100025bc4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x792c>
100025bac: f27df108    	ands	x8, x8, #0xfffffffffffffff8
100025bb0: 540000a0    	b.eq	0x100025bc4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x792c>
100025bb4: f85f8109    	ldur	x9, [x8, #-0x8]
100025bb8: b4000069    	cbz	x9, 0x100025bc4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x792c>
100025bbc: 91000529    	add	x9, x9, #0x1
100025bc0: f81f8109    	stur	x9, [x8, #-0x8]
100025bc4: 9137e3e0    	add	x0, sp, #0xdf8
100025bc8: 913903f5    	add	x21, sp, #0xe40
100025bcc: 910122a1    	add	x1, x21, #0x48
100025bd0: 9101e2a2    	add	x2, x21, #0x78
100025bd4: 914007e3    	add	x3, sp, #0x1, lsl #12   ; =0x1000
100025bd8: 910d4063    	add	x3, x3, #0x350
100025bdc: 914007e4    	add	x4, sp, #0x1, lsl #12   ; =0x1000
100025be0: 910dc084    	add	x4, x4, #0x370
100025be4: 914007e5    	add	x5, sp, #0x1, lsl #12   ; =0x1000
100025be8: 910e40a5    	add	x5, x5, #0x390
100025bec: 97ffd2a1    	bl	0x10001a670 <_roc__p499ff7eb2f98e9031bc9d0002db086b6.fast>
100025bf0: f90157ff    	str	xzr, [sp, #0x2a8]
100025bf4: 3dc393e0    	ldr	q0, [sp, #0xe40]
100025bf8: 3d871be0    	str	q0, [sp, #0x1c60]
100025bfc: f9472be8    	ldr	x8, [sp, #0xe50]
100025c00: f90e3be8    	str	x8, [sp, #0x1c70]
100025c04: 3cc182a0    	ldur	q0, [x21, #0x18]
100025c08: 3d8723e0    	str	q0, [sp, #0x1c80]
100025c0c: f84282a8    	ldur	x8, [x21, #0x28]
100025c10: f90e4be8    	str	x8, [sp, #0x1c90]
100025c14: 3cc482a0    	ldur	q0, [x21, #0x48]
100025c18: 3d872be0    	str	q0, [sp, #0x1ca0]
100025c1c: f84582a8    	ldur	x8, [x21, #0x58]
100025c20: f90e5be8    	str	x8, [sp, #0x1cb0]
100025c24: f84402a8    	ldur	x8, [x21, #0x40]
100025c28: f90e6be8    	str	x8, [sp, #0x1cd0]
100025c2c: 3cc302a0    	ldur	q0, [x21, #0x30]
100025c30: 3d8733e0    	str	q0, [sp, #0x1cc0]
100025c34: 3cc782a0    	ldur	q0, [x21, #0x78]
100025c38: f84882a8    	ldur	x8, [x21, #0x88]
100025c3c: f90e7be8    	str	x8, [sp, #0x1cf0]
100025c40: 3d873be0    	str	q0, [sp, #0x1ce0]
100025c44: f84702a8    	ldur	x8, [x21, #0x70]
100025c48: f90e8be8    	str	x8, [sp, #0x1d10]
100025c4c: 3cc602a0    	ldur	q0, [x21, #0x60]
100025c50: 3d8743e0    	str	q0, [sp, #0x1d00]
100025c54: 9137e3e9    	add	x9, sp, #0xdf8
100025c58: f8428128    	ldur	x8, [x9, #0x28]
100025c5c: f90e9be8    	str	x8, [sp, #0x1d30]
100025c60: 3cc18120    	ldur	q0, [x9, #0x18]
100025c64: 3d874be0    	str	q0, [sp, #0x1d20]
100025c68: f94707e8    	ldr	x8, [sp, #0xe08]
100025c6c: f90eabe8    	str	x8, [sp, #0x1d50]
100025c70: 9137e3e8    	add	x8, sp, #0xdf8
100025c74: 3dc00100    	ldr	q0, [x8]
100025c78: 3d8753e0    	str	q0, [sp, #0x1d40]
100025c7c: f8440128    	ldur	x8, [x9, #0x40]
100025c80: f90ebbe8    	str	x8, [sp, #0x1d70]
100025c84: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
100025c88: 91358108    	add	x8, x8, #0xd60
100025c8c: 3cc30120    	ldur	q0, [x9, #0x30]
100025c90: 914007e9    	add	x9, sp, #0x1, lsl #12   ; =0x1000
100025c94: 91350129    	add	x9, x9, #0xd40
100025c98: 914007ea    	add	x10, sp, #0x1, lsl #12  ; =0x1000
100025c9c: 9134814a    	add	x10, x10, #0xd20
100025ca0: 3d875be0    	str	q0, [sp, #0x1d60]
100025ca4: 914007eb    	add	x11, sp, #0x1, lsl #12  ; =0x1000
100025ca8: 9134016b    	add	x11, x11, #0xd00
100025cac: 914007ed    	add	x13, sp, #0x1, lsl #12  ; =0x1000
100025cb0: 913381ad    	add	x13, x13, #0xce0
100025cb4: 914007ee    	add	x14, sp, #0x1, lsl #12  ; =0x1000
100025cb8: 913301ce    	add	x14, x14, #0xcc0
100025cbc: 914007ef    	add	x15, sp, #0x1, lsl #12  ; =0x1000
100025cc0: 913281ef    	add	x15, x15, #0xca0
100025cc4: f946f3fc    	ldr	x28, [sp, #0xde0]
100025cc8: f946f7e3    	ldr	x3, [sp, #0xde8]
100025ccc: 914007f0    	add	x16, sp, #0x1, lsl #12  ; =0x1000
100025cd0: 91320210    	add	x16, x16, #0xc80
100025cd4: 914007f1    	add	x17, sp, #0x1, lsl #12  ; =0x1000
100025cd8: 91318231    	add	x17, x17, #0xc60
100025cdc: 5280002c    	mov	w12, #0x1               ; =1
100025ce0: f946fbe5    	ldr	x5, [sp, #0xdf0]
100025ce4: f9419fe0    	ldr	x0, [sp, #0x338]
100025ce8: f941a3e1    	ldr	x1, [sp, #0x340]
100025cec: f940d7e2    	ldr	x2, [sp, #0x1a8]
100025cf0: f940cbe4    	ldr	x4, [sp, #0x190]
100025cf4: f9418bf6    	ldr	x22, [sp, #0x310]
100025cf8: 3dc00220    	ldr	q0, [x17]
100025cfc: 3d86a3e0    	str	q0, [sp, #0x1a80]
100025d00: f9400a31    	ldr	x17, [x17, #0x10]
100025d04: f90d4bf1    	str	x17, [sp, #0x1a90]
100025d08: 3dc00200    	ldr	q0, [x16]
100025d0c: 3d86abe0    	str	q0, [sp, #0x1aa0]
100025d10: f9400a10    	ldr	x16, [x16, #0x10]
100025d14: f90d5bf0    	str	x16, [sp, #0x1ab0]
100025d18: 3dc001e0    	ldr	q0, [x15]
100025d1c: 3d86b3e0    	str	q0, [sp, #0x1ac0]
100025d20: f94009ef    	ldr	x15, [x15, #0x10]
100025d24: f90d6bef    	str	x15, [sp, #0x1ad0]
100025d28: f94009cf    	ldr	x15, [x14, #0x10]
100025d2c: f90d7bef    	str	x15, [sp, #0x1af0]
100025d30: 3dc001c0    	ldr	q0, [x14]
100025d34: 3d86bbe0    	str	q0, [sp, #0x1ae0]
100025d38: 3dc001a0    	ldr	q0, [x13]
100025d3c: f94009ad    	ldr	x13, [x13, #0x10]
100025d40: f90d8bed    	str	x13, [sp, #0x1b10]
100025d44: 3d86c3e0    	str	q0, [sp, #0x1b00]
100025d48: 3dc00160    	ldr	q0, [x11]
100025d4c: 3d86cbe0    	str	q0, [sp, #0x1b20]
100025d50: f940096b    	ldr	x11, [x11, #0x10]
100025d54: f90d9beb    	str	x11, [sp, #0x1b30]
100025d58: 3dc00140    	ldr	q0, [x10]
100025d5c: 3d86d3e0    	str	q0, [sp, #0x1b40]
100025d60: f940094a    	ldr	x10, [x10, #0x10]
100025d64: f90dabea    	str	x10, [sp, #0x1b50]
100025d68: 3dc00120    	ldr	q0, [x9]
100025d6c: 3d86dbe0    	str	q0, [sp, #0x1b60]
100025d70: f9400929    	ldr	x9, [x9, #0x10]
100025d74: f90dbbe9    	str	x9, [sp, #0x1b70]
100025d78: f9400909    	ldr	x9, [x8, #0x10]
100025d7c: f90dcbe9    	str	x9, [sp, #0x1b90]
100025d80: 3dc00100    	ldr	q0, [x8]
100025d84: 3d86e3e0    	str	q0, [sp, #0x1b80]
100025d88: f90ee7e2    	str	x2, [sp, #0x1dc8]
100025d8c: f90eebe4    	str	x4, [sp, #0x1dd0]
100025d90: f940dbe8    	ldr	x8, [sp, #0x1b0]
100025d94: f90eefe8    	str	x8, [sp, #0x1dd8]
100025d98: f904d3fc    	str	x28, [sp, #0x9a0]
100025d9c: f904d7e3    	str	x3, [sp, #0x9a8]
100025da0: f904dbe5    	str	x5, [sp, #0x9b0]
100025da4: f94143e8    	ldr	x8, [sp, #0x280]
100025da8: f90c23e8    	str	x8, [sp, #0x1840]
100025dac: f9417fe8    	ldr	x8, [sp, #0x2f8]
100025db0: f90c27e8    	str	x8, [sp, #0x1848]
100025db4: f9414be8    	ldr	x8, [sp, #0x290]
100025db8: f90c2be8    	str	x8, [sp, #0x1850]
100025dbc: f90c5fe0    	str	x0, [sp, #0x18b8]
100025dc0: f90c63e1    	str	x1, [sp, #0x18c0]
100025dc4: f9413fe8    	ldr	x8, [sp, #0x278]
100025dc8: f90c67e8    	str	x8, [sp, #0x18c8]
100025dcc: a905e3ec    	stp	x12, x24, [sp, #0x58]
100025dd0: 912683e8    	add	x8, sp, #0x9a0
100025dd4: f9002be8    	str	x8, [sp, #0x50]
100025dd8: 9130c3e8    	add	x8, sp, #0xc30
100025ddc: f90027e8    	str	x8, [sp, #0x48]
100025de0: 913043e8    	add	x8, sp, #0xc10
100025de4: f90023e8    	str	x8, [sp, #0x40]
100025de8: 912fc3e8    	add	x8, sp, #0xbf0
100025dec: f9001fe8    	str	x8, [sp, #0x38]
100025df0: 912f43e8    	add	x8, sp, #0xbd0
100025df4: f9001be8    	str	x8, [sp, #0x30]
100025df8: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
100025dfc: 912c8108    	add	x8, x8, #0xb20
100025e00: f90017e8    	str	x8, [sp, #0x28]
100025e04: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
100025e08: 912c0108    	add	x8, x8, #0xb00
100025e0c: f90013e8    	str	x8, [sp, #0x20]
100025e10: 9132c3e0    	add	x0, sp, #0xcb0
100025e14: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
100025e18: 91210021    	add	x1, x1, #0x840
100025e1c: 914007e4    	add	x4, sp, #0x1, lsl #12   ; =0x1000
100025e20: 9122e084    	add	x4, x4, #0x8b8
100025e24: 914007e7    	add	x7, sp, #0x1, lsl #12   ; =0x1000
100025e28: 913720e7    	add	x7, x7, #0xdc8
100025e2c: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
100025e30: 912b8108    	add	x8, x8, #0xae0
100025e34: f9000fe8    	str	x8, [sp, #0x18]
100025e38: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
100025e3c: 912b0108    	add	x8, x8, #0xac0
100025e40: f9000be8    	str	x8, [sp, #0x10]
100025e44: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
100025e48: 912a8108    	add	x8, x8, #0xaa0
100025e4c: f90007e8    	str	x8, [sp, #0x8]
100025e50: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
100025e54: 912a0108    	add	x8, x8, #0xa80
100025e58: f90003e8    	str	x8, [sp]
100025e5c: f9409be2    	ldr	x2, [sp, #0x130]
100025e60: f940a7e3    	ldr	x3, [sp, #0x148]
100025e64: f94183e5    	ldr	x5, [sp, #0x300]
100025e68: aa1603e6    	mov	x6, x22
100025e6c: 97ffbfaa    	bl	0x100015d14 <_roc__p81003bf97431a8821d5be871f2471565.fast>
100025e70: 3dc6a3e0    	ldr	q0, [sp, #0x1a80]
100025e74: 3d8763e0    	str	q0, [sp, #0x1d80]
100025e78: f94d4be8    	ldr	x8, [sp, #0x1a90]
100025e7c: f90ecbe8    	str	x8, [sp, #0x1d90]
100025e80: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100025e84: 91360000    	add	x0, x0, #0xd80
100025e88: 940028ce    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100025e8c: 3dc6abe0    	ldr	q0, [sp, #0x1aa0]
100025e90: 3d8763e0    	str	q0, [sp, #0x1d80]
100025e94: f94d5be8    	ldr	x8, [sp, #0x1ab0]
100025e98: f90ecbe8    	str	x8, [sp, #0x1d90]
100025e9c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100025ea0: 91360000    	add	x0, x0, #0xd80
100025ea4: 940028c7    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100025ea8: b941e3e8    	ldr	w8, [sp, #0x1e0]
100025eac: b94077e9    	ldr	w9, [sp, #0x74]
100025eb0: 0a080128    	and	w8, w9, w8
100025eb4: 7100051f    	cmp	w8, #0x1
100025eb8: 54000361    	b.ne	0x100025f24 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x7c8c>
100025ebc: b40017db    	cbz	x27, 0x1000261b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x7f1c>
100025ec0: d2800008    	mov	x8, #0x0                ; =0
100025ec4: ab080329    	adds	x9, x25, x8
100025ec8: 54024102    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100025ecc: 529cac2a    	mov	w10, #0xe561            ; =58721
100025ed0: 72a002ca    	movk	w10, #0x16, lsl #16
100025ed4: eb0a013f    	cmp	x9, x10
100025ed8: 540001a2    	b.hs	0x100025f0c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x7c74>
100025edc: f941afea    	ldr	x10, [sp, #0x358]
100025ee0: b8697949    	ldr	w9, [x10, x9, lsl #2]
100025ee4: 529cac2a    	mov	w10, #0xe561            ; =58721
100025ee8: 72a002ca    	movk	w10, #0x16, lsl #16
100025eec: eb08015f    	cmp	x10, x8
100025ef0: 54032800    	b.eq	0x10002c3f0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe158>
100025ef4: f941afea    	ldr	x10, [sp, #0x358]
100025ef8: b8287949    	str	w9, [x10, x8, lsl #2]
100025efc: 91000508    	add	x8, x8, #0x1
100025f00: eb08037f    	cmp	x27, x8
100025f04: 54fffe01    	b.ne	0x100025ec4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x7c2c>
100025f08: 140000ab    	b	0x1000261b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x7f1c>
100025f0c: 52800009    	mov	w9, #0x0                ; =0
100025f10: 529cac2a    	mov	w10, #0xe561            ; =58721
100025f14: 72a002ca    	movk	w10, #0x16, lsl #16
100025f18: eb08015f    	cmp	x10, x8
100025f1c: 54fffec1    	b.ne	0x100025ef4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x7c5c>
100025f20: 14001934    	b	0x10002c3f0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe158>
100025f24: f90ec3f4    	str	x20, [sp, #0x1d80]
100025f28: 914007f4    	add	x20, sp, #0x1, lsl #12  ; =0x1000
100025f2c: 91360294    	add	x20, x20, #0xd80
100025f30: 3dc033e0    	ldr	q0, [sp, #0xc0]
100025f34: 3c808280    	stur	q0, [x20, #0x8]
100025f38: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100025f3c: 91360000    	add	x0, x0, #0xd80
100025f40: 940028a0    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100025f44: f9418fe8    	ldr	x8, [sp, #0x318]
100025f48: f90ec3e8    	str	x8, [sp, #0x1d80]
100025f4c: 3dc02fe0    	ldr	q0, [sp, #0xb0]
100025f50: 3c808280    	stur	q0, [x20, #0x8]
100025f54: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100025f58: 91360000    	add	x0, x0, #0xd80
100025f5c: 94002899    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100025f60: 52800b00    	mov	w0, #0x58               ; =88
100025f64: 52800101    	mov	w1, #0x8                ; =8
100025f68: 97ff7246    	bl	0x100002880 <_roc_alloc>
100025f6c: aa0003e8    	mov	x8, x0
100025f70: b8008d1f    	str	wzr, [x8, #0x8]!
100025f74: f9000017    	str	x23, [x0]
100025f78: f90193e8    	str	x8, [sp, #0x320]
100025f7c: f9400108    	ldr	x8, [x8]
100025f80: f800c008    	stur	x8, [x0, #0xc]
100025f84: f9000808    	str	x8, [x0, #0x10]
100025f88: f840c008    	ldur	x8, [x0, #0xc]
100025f8c: f8014008    	stur	x8, [x0, #0x14]
100025f90: 4e080d00    	dup.2d	v0, x8
100025f94: 3c82c000    	stur	q0, [x0, #0x2c]
100025f98: 3c81c000    	stur	q0, [x0, #0x1c]
100025f9c: 52800b00    	mov	w0, #0x58               ; =88
100025fa0: 52800101    	mov	w1, #0x8                ; =8
100025fa4: 97ff7237    	bl	0x100002880 <_roc_alloc>
100025fa8: aa0003f5    	mov	x21, x0
100025fac: b8008ebf    	str	wzr, [x21, #0x8]!
100025fb0: f9000017    	str	x23, [x0]
100025fb4: f94002a8    	ldr	x8, [x21]
100025fb8: f800c008    	stur	x8, [x0, #0xc]
100025fbc: f9000808    	str	x8, [x0, #0x10]
100025fc0: f840c008    	ldur	x8, [x0, #0xc]
100025fc4: f8014008    	stur	x8, [x0, #0x14]
100025fc8: 4e080d00    	dup.2d	v0, x8
100025fcc: 3c82c000    	stur	q0, [x0, #0x2c]
100025fd0: 3c81c000    	stur	q0, [x0, #0x1c]
100025fd4: 52808780    	mov	w0, #0x43c              ; =1084
100025fd8: 52800101    	mov	w1, #0x8                ; =8
100025fdc: 97ff7229    	bl	0x100002880 <_roc_alloc>
100025fe0: aa0003e9    	mov	x9, x0
100025fe4: b8008d3f    	str	wzr, [x9, #0x8]!
100025fe8: f9000017    	str	x23, [x0]
100025fec: 91047008    	add	x8, x0, #0x11c
100025ff0: f9018fe9    	str	x9, [sp, #0x318]
100025ff4: f9400129    	ldr	x9, [x9]
100025ff8: f800c009    	stur	x9, [x0, #0xc]
100025ffc: f9000809    	str	x9, [x0, #0x10]
100026000: f840c009    	ldur	x9, [x0, #0xc]
100026004: f8014009    	stur	x9, [x0, #0x14]
100026008: 4e080d20    	dup.2d	v0, x9
10002600c: 3c82c000    	stur	q0, [x0, #0x2c]
100026010: 3c81c000    	stur	q0, [x0, #0x1c]
100026014: 3c84c000    	stur	q0, [x0, #0x4c]
100026018: 3c83c000    	stur	q0, [x0, #0x3c]
10002601c: 3c86c000    	stur	q0, [x0, #0x6c]
100026020: 3c85c000    	stur	q0, [x0, #0x5c]
100026024: 3c88c000    	stur	q0, [x0, #0x8c]
100026028: 3c87c000    	stur	q0, [x0, #0x7c]
10002602c: 3c8ac000    	stur	q0, [x0, #0xac]
100026030: 3c89c000    	stur	q0, [x0, #0x9c]
100026034: 3c8cc000    	stur	q0, [x0, #0xcc]
100026038: 3c8bc000    	stur	q0, [x0, #0xbc]
10002603c: 3c8ec000    	stur	q0, [x0, #0xec]
100026040: 3c8dc000    	stur	q0, [x0, #0xdc]
100026044: 3c8fcc00    	str	q0, [x0, #0xfc]!
100026048: 3d800400    	str	q0, [x0, #0x10]
10002604c: ad000100    	stp	q0, q0, [x8]
100026050: ad010100    	stp	q0, q0, [x8, #0x20]
100026054: ad020100    	stp	q0, q0, [x8, #0x40]
100026058: ad030100    	stp	q0, q0, [x8, #0x60]
10002605c: ad040100    	stp	q0, q0, [x8, #0x80]
100026060: ad050100    	stp	q0, q0, [x8, #0xa0]
100026064: ad060100    	stp	q0, q0, [x8, #0xc0]
100026068: ad070100    	stp	q0, q0, [x8, #0xe0]
10002606c: ad080100    	stp	q0, q0, [x8, #0x100]
100026070: ad090100    	stp	q0, q0, [x8, #0x120]
100026074: ad0a0100    	stp	q0, q0, [x8, #0x140]
100026078: ad0b0100    	stp	q0, q0, [x8, #0x160]
10002607c: ad0c0100    	stp	q0, q0, [x8, #0x180]
100026080: ad0d0100    	stp	q0, q0, [x8, #0x1a0]
100026084: ad0e0100    	stp	q0, q0, [x8, #0x1c0]
100026088: ad0f0100    	stp	q0, q0, [x8, #0x1e0]
10002608c: ad100100    	stp	q0, q0, [x8, #0x200]
100026090: ad110100    	stp	q0, q0, [x8, #0x220]
100026094: ad120100    	stp	q0, q0, [x8, #0x240]
100026098: ad130100    	stp	q0, q0, [x8, #0x260]
10002609c: ad140100    	stp	q0, q0, [x8, #0x280]
1000260a0: ad150100    	stp	q0, q0, [x8, #0x2a0]
1000260a4: ad160100    	stp	q0, q0, [x8, #0x2c0]
1000260a8: ad170100    	stp	q0, q0, [x8, #0x2e0]
1000260ac: f9018109    	str	x9, [x8, #0x300]
1000260b0: 52808780    	mov	w0, #0x43c              ; =1084
1000260b4: 52800101    	mov	w1, #0x8                ; =8
1000260b8: 97ff71f2    	bl	0x100002880 <_roc_alloc>
1000260bc: d280001b    	mov	x27, #0x0               ; =0
1000260c0: f9019bff    	str	xzr, [sp, #0x330]
1000260c4: aa0003e8    	mov	x8, x0
1000260c8: b8008d1f    	str	wzr, [x8, #0x8]!
1000260cc: f9000017    	str	x23, [x0]
1000260d0: f9015fe8    	str	x8, [sp, #0x2b8]
1000260d4: f9400109    	ldr	x9, [x8]
1000260d8: 91047008    	add	x8, x0, #0x11c
1000260dc: f800c009    	stur	x9, [x0, #0xc]
1000260e0: f9000809    	str	x9, [x0, #0x10]
1000260e4: f840c009    	ldur	x9, [x0, #0xc]
1000260e8: 4e080d20    	dup.2d	v0, x9
1000260ec: f8014009    	stur	x9, [x0, #0x14]
1000260f0: 3c82c000    	stur	q0, [x0, #0x2c]
1000260f4: 3c81c000    	stur	q0, [x0, #0x1c]
1000260f8: 3c84c000    	stur	q0, [x0, #0x4c]
1000260fc: 3c83c000    	stur	q0, [x0, #0x3c]
100026100: 3c86c000    	stur	q0, [x0, #0x6c]
100026104: 3c85c000    	stur	q0, [x0, #0x5c]
100026108: 3c88c000    	stur	q0, [x0, #0x8c]
10002610c: 3c87c000    	stur	q0, [x0, #0x7c]
100026110: 3c8ac000    	stur	q0, [x0, #0xac]
100026114: 3c89c000    	stur	q0, [x0, #0x9c]
100026118: 3c8cc000    	stur	q0, [x0, #0xcc]
10002611c: 3c8bc000    	stur	q0, [x0, #0xbc]
100026120: 3c8ec000    	stur	q0, [x0, #0xec]
100026124: 3c8dc000    	stur	q0, [x0, #0xdc]
100026128: 3c8fcc00    	str	q0, [x0, #0xfc]!
10002612c: 3d800400    	str	q0, [x0, #0x10]
100026130: ad000100    	stp	q0, q0, [x8]
100026134: ad010100    	stp	q0, q0, [x8, #0x20]
100026138: ad020100    	stp	q0, q0, [x8, #0x40]
10002613c: ad030100    	stp	q0, q0, [x8, #0x60]
100026140: ad040100    	stp	q0, q0, [x8, #0x80]
100026144: ad050100    	stp	q0, q0, [x8, #0xa0]
100026148: ad060100    	stp	q0, q0, [x8, #0xc0]
10002614c: ad070100    	stp	q0, q0, [x8, #0xe0]
100026150: ad080100    	stp	q0, q0, [x8, #0x100]
100026154: ad090100    	stp	q0, q0, [x8, #0x120]
100026158: ad0a0100    	stp	q0, q0, [x8, #0x140]
10002615c: ad0b0100    	stp	q0, q0, [x8, #0x160]
100026160: ad0c0100    	stp	q0, q0, [x8, #0x180]
100026164: ad0d0100    	stp	q0, q0, [x8, #0x1a0]
100026168: ad0e0100    	stp	q0, q0, [x8, #0x1c0]
10002616c: ad0f0100    	stp	q0, q0, [x8, #0x1e0]
100026170: ad100100    	stp	q0, q0, [x8, #0x200]
100026174: ad110100    	stp	q0, q0, [x8, #0x220]
100026178: ad120100    	stp	q0, q0, [x8, #0x240]
10002617c: ad130100    	stp	q0, q0, [x8, #0x260]
100026180: ad140100    	stp	q0, q0, [x8, #0x280]
100026184: ad150100    	stp	q0, q0, [x8, #0x2a0]
100026188: ad160100    	stp	q0, q0, [x8, #0x2c0]
10002618c: f9018109    	str	x9, [x8, #0x300]
100026190: 5280015c    	mov	w28, #0xa               ; =10
100026194: 52800518    	mov	w24, #0x28              ; =40
100026198: 52802069    	mov	w9, #0x103              ; =259
10002619c: f90163e9    	str	x9, [sp, #0x2c0]
1000261a0: 52804349    	mov	w9, #0x21a              ; =538
1000261a4: f900dfe9    	str	x9, [sp, #0x1b8]
1000261a8: ad170100    	stp	q0, q0, [x8, #0x2e0]
1000261ac: aa1303f6    	mov	x22, x19
1000261b0: 1400003d    	b	0x1000262a4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x800c>
1000261b4: f90eebff    	str	xzr, [sp, #0x1dd0]
1000261b8: f90ee7ff    	str	xzr, [sp, #0x1dc8]
1000261bc: f90eefff    	str	xzr, [sp, #0x1dd8]
1000261c0: 912683e0    	add	x0, sp, #0x9a0
1000261c4: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
1000261c8: 91372021    	add	x1, x1, #0xdc8
1000261cc: 52800282    	mov	w2, #0x14               ; =20
1000261d0: 52800083    	mov	w3, #0x4                ; =4
1000261d4: 52800024    	mov	w4, #0x1                ; =1
1000261d8: 94002e1c    	bl	0x100031a48 <_list.RocList.reallocate>
1000261dc: f944d3e8    	ldr	x8, [sp, #0x9a0]
1000261e0: f944dbe9    	ldr	x9, [sp, #0x9b0]
1000261e4: b900011f    	str	wzr, [x8]
1000261e8: f90ee7e8    	str	x8, [sp, #0x1dc8]
1000261ec: f90eebf7    	str	x23, [sp, #0x1dd0]
1000261f0: f90eefe9    	str	x9, [sp, #0x1dd8]
1000261f4: 914007f4    	add	x20, sp, #0x1, lsl #12  ; =0x1000
1000261f8: 91360294    	add	x20, x20, #0xd80
1000261fc: 3cc48280    	ldur	q0, [x20, #0x48]
100026200: f9000be9    	str	x9, [sp, #0x10]
100026204: 3d8003e0    	str	q0, [sp]
100026208: 912683e0    	add	x0, sp, #0x9a0
10002620c: d2800001    	mov	x1, #0x0                ; =0
100026210: 52800122    	mov	w2, #0x9                ; =9
100026214: 52800083    	mov	w3, #0x4                ; =4
100026218: 94002fdb    	bl	0x100032184 <_list.listAppendRangeWithinUnsafe>
10002621c: f944d3f5    	ldr	x21, [sp, #0x9a0]
100026220: f944d7fc    	ldr	x28, [sp, #0x9a8]
100026224: f944dbf8    	ldr	x24, [sp, #0x9b0]
100026228: f90eebff    	str	xzr, [sp, #0x1dd0]
10002622c: f90ee7ff    	str	xzr, [sp, #0x1dc8]
100026230: f90eefff    	str	xzr, [sp, #0x1dd8]
100026234: 912683e0    	add	x0, sp, #0x9a0
100026238: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
10002623c: 91372021    	add	x1, x1, #0xdc8
100026240: 528021a2    	mov	w2, #0x10d              ; =269
100026244: 52800083    	mov	w3, #0x4                ; =4
100026248: 52800024    	mov	w4, #0x1                ; =1
10002624c: 94002dff    	bl	0x100031a48 <_list.RocList.reallocate>
100026250: f944d3e8    	ldr	x8, [sp, #0x9a0]
100026254: f944dbe9    	ldr	x9, [sp, #0x9b0]
100026258: b900011f    	str	wzr, [x8]
10002625c: f90ee7e8    	str	x8, [sp, #0x1dc8]
100026260: f90eebf7    	str	x23, [sp, #0x1dd0]
100026264: f90eefe9    	str	x9, [sp, #0x1dd8]
100026268: 3cc48280    	ldur	q0, [x20, #0x48]
10002626c: f9000be9    	str	x9, [sp, #0x10]
100026270: 3d8003e0    	str	q0, [sp]
100026274: 912683e0    	add	x0, sp, #0x9a0
100026278: d2800001    	mov	x1, #0x0                ; =0
10002627c: 52802042    	mov	w2, #0x102              ; =258
100026280: 52800083    	mov	w3, #0x4                ; =4
100026284: 94002fc0    	bl	0x100032184 <_list.listAppendRangeWithinUnsafe>
100026288: f944d3e8    	ldr	x8, [sp, #0x9a0]
10002628c: f9015fe8    	str	x8, [sp, #0x2b8]
100026290: f944d7e8    	ldr	x8, [sp, #0x9a8]
100026294: f90163e8    	str	x8, [sp, #0x2c0]
100026298: f940f7f6    	ldr	x22, [sp, #0x1e8]
10002629c: f944dbe8    	ldr	x8, [sp, #0x9b0]
1000262a0: f900dfe8    	str	x8, [sp, #0x1b8]
1000262a4: f94663e8    	ldr	x8, [sp, #0xcc0]
1000262a8: f900ebe8    	str	x8, [sp, #0x1d0]
1000262ac: f94667e8    	ldr	x8, [sp, #0xcc8]
1000262b0: f90103e8    	str	x8, [sp, #0x200]
1000262b4: 3dc6d3e0    	ldr	q0, [sp, #0x1b40]
1000262b8: 3d82c7e0    	str	q0, [sp, #0xb10]
1000262bc: f94dabe8    	ldr	x8, [sp, #0x1b50]
1000262c0: f90593e8    	str	x8, [sp, #0xb20]
1000262c4: 3dc6dbe0    	ldr	q0, [sp, #0x1b60]
1000262c8: 3d82cfe0    	str	q0, [sp, #0xb30]
1000262cc: f94dbbe8    	ldr	x8, [sp, #0x1b70]
1000262d0: f905a3e8    	str	x8, [sp, #0xb40]
1000262d4: 3dc6e3e0    	ldr	q0, [sp, #0x1b80]
1000262d8: 3d82d7e0    	str	q0, [sp, #0xb50]
1000262dc: f94dcbe8    	ldr	x8, [sp, #0x1b90]
1000262e0: f905b3e8    	str	x8, [sp, #0xb60]
1000262e4: 3dc317e0    	ldr	q0, [sp, #0xc50]
1000262e8: f94633e8    	ldr	x8, [sp, #0xc60]
1000262ec: f905c3e8    	str	x8, [sp, #0xb80]
1000262f0: 3d82dfe0    	str	q0, [sp, #0xb70]
1000262f4: f94643e8    	ldr	x8, [sp, #0xc80]
1000262f8: f905d3e8    	str	x8, [sp, #0xba0]
1000262fc: 3dc31fe0    	ldr	q0, [sp, #0xc70]
100026300: 3d82e7e0    	str	q0, [sp, #0xb90]
100026304: f94653e8    	ldr	x8, [sp, #0xca0]
100026308: f905e3e8    	str	x8, [sp, #0xbc0]
10002630c: 3dc327e0    	ldr	q0, [sp, #0xc90]
100026310: 3d82efe0    	str	q0, [sp, #0xbb0]
100026314: f946abe9    	ldr	x9, [sp, #0xd50]
100026318: f946afe8    	ldr	x8, [sp, #0xd58]
10002631c: f900cbe8    	str	x8, [sp, #0x190]
100026320: f946b3e8    	ldr	x8, [sp, #0xd60]
100026324: a91aa3e9    	stp	x9, x8, [sp, #0x1a8]
100026328: f9466be8    	ldr	x8, [sp, #0xcd0]
10002632c: f900fbe8    	str	x8, [sp, #0x1f0]
100026330: f9469fe8    	ldr	x8, [sp, #0xd38]
100026334: f90143e8    	str	x8, [sp, #0x280]
100026338: f946a3e8    	ldr	x8, [sp, #0xd40]
10002633c: f9017fe8    	str	x8, [sp, #0x2f8]
100026340: f946a7f4    	ldr	x20, [sp, #0xd48]
100026344: f9465be8    	ldr	x8, [sp, #0xcb0]
100026348: f9009be8    	str	x8, [sp, #0x130]
10002634c: f9465fe8    	ldr	x8, [sp, #0xcb8]
100026350: f900a7e8    	str	x8, [sp, #0x148]
100026354: 9132c3f7    	add	x23, sp, #0xcb0
100026358: 3cc282e0    	ldur	q0, [x23, #0x28]
10002635c: f84382e8    	ldur	x8, [x23, #0x38]
100026360: f90ecbe8    	str	x8, [sp, #0x1d90]
100026364: 3d8763e0    	str	q0, [sp, #0x1d80]
100026368: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002636c: 91360000    	add	x0, x0, #0xd80
100026370: 94002794    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026374: 3cc402e0    	ldur	q0, [x23, #0x40]
100026378: 3d8763e0    	str	q0, [sp, #0x1d80]
10002637c: f84502e8    	ldur	x8, [x23, #0x50]
100026380: f90ecbe8    	str	x8, [sp, #0x1d90]
100026384: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100026388: 91360000    	add	x0, x0, #0xd80
10002638c: 9400278d    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026390: 3cc582e0    	ldur	q0, [x23, #0x58]
100026394: 3d8763e0    	str	q0, [sp, #0x1d80]
100026398: f84682e8    	ldur	x8, [x23, #0x68]
10002639c: f90ecbe8    	str	x8, [sp, #0x1d90]
1000263a0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000263a4: 91360000    	add	x0, x0, #0xd80
1000263a8: 94002786    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000263ac: 3cc702e0    	ldur	q0, [x23, #0x70]
1000263b0: 3d8763e0    	str	q0, [sp, #0x1d80]
1000263b4: f84802e8    	ldur	x8, [x23, #0x80]
1000263b8: f90ecbe8    	str	x8, [sp, #0x1d90]
1000263bc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000263c0: 91360000    	add	x0, x0, #0xd80
1000263c4: 9400277f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000263c8: f9014bf4    	str	x20, [sp, #0x290]
1000263cc: 37000254    	tbnz	w20, #0x0, 0x100026414 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x817c>
1000263d0: f9419ff7    	ldr	x23, [sp, #0x338]
1000263d4: f941a3fe    	ldr	x30, [sp, #0x340]
1000263d8: 4f04a404    	movi.8h	v4, #0x80, lsl #8
1000263dc: a948c7e1    	ldp	x1, x17, [sp, #0x88]
1000263e0: f9415bf0    	ldr	x16, [sp, #0x2b0]
1000263e4: f94157ee    	ldr	x14, [sp, #0x2a8]
1000263e8: b40000b4    	cbz	x20, 0x1000263fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8164>
1000263ec: f94143e8    	ldr	x8, [sp, #0x280]
1000263f0: f85f8108    	ldur	x8, [x8, #-0x8]
1000263f4: f100051f    	cmp	x8, #0x1
1000263f8: 540001e1    	b.ne	0x100026434 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x819c>
1000263fc: f9414be8    	ldr	x8, [sp, #0x290]
100026400: d341fd08    	lsr	x8, x8, #1
100026404: f9417fe9    	ldr	x9, [sp, #0x2f8]
100026408: eb09011f    	cmp	x8, x9
10002640c: 1a9f17f4    	cset	w20, eq
100026410: 1400000a    	b	0x100026438 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x81a0>
100026414: 52800034    	mov	w20, #0x1               ; =1
100026418: f9419ff7    	ldr	x23, [sp, #0x338]
10002641c: f941a3fe    	ldr	x30, [sp, #0x340]
100026420: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100026424: a948c7e1    	ldp	x1, x17, [sp, #0x88]
100026428: f9415bf0    	ldr	x16, [sp, #0x2b0]
10002642c: f94157ee    	ldr	x14, [sp, #0x2a8]
100026430: 14000002    	b	0x100026438 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x81a0>
100026434: 52800034    	mov	w20, #0x1               ; =1
100026438: 9132c3e9    	add	x9, sp, #0xcb0
10002643c: 3ccd0120    	ldur	q0, [x9, #0xd0]
100026440: 3d82f7e0    	str	q0, [sp, #0xbd0]
100026444: f84e0128    	ldur	x8, [x9, #0xe0]
100026448: f905f3e8    	str	x8, [sp, #0xbe0]
10002644c: 3ccb8120    	ldur	q0, [x9, #0xb8]
100026450: 3d82ffe0    	str	q0, [sp, #0xbf0]
100026454: f84c8128    	ldur	x8, [x9, #0xc8]
100026458: f90603e8    	str	x8, [sp, #0xc00]
10002645c: 3dc04120    	ldr	q0, [x9, #0x100]
100026460: 3d8307e0    	str	q0, [sp, #0xc10]
100026464: f9408928    	ldr	x8, [x9, #0x110]
100026468: f90613e8    	str	x8, [sp, #0xc20]
10002646c: f84f8128    	ldur	x8, [x9, #0xf8]
100026470: f90623e8    	str	x8, [sp, #0xc40]
100026474: 3cce8120    	ldur	q0, [x9, #0xe8]
100026478: 3d830fe0    	str	q0, [sp, #0xc30]
10002647c: eb1303df    	cmp	x30, x19
100026480: f94123ea    	ldr	x10, [sp, #0x240]
100026484: f940b3e8    	ldr	x8, [sp, #0x160]
100026488: f94147e9    	ldr	x9, [sp, #0x288]
10002648c: f9410fec    	ldr	x12, [sp, #0x218]
100026490: aa1603ed    	mov	x13, x22
100026494: 54fe44e1    	b.ne	0x100022d30 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4a98>
100026498: 140011d2    	b	0x10002abe0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc948>
10002649c: f90ec3e8    	str	x8, [sp, #0x1d80]
1000264a0: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000264a4: 91360108    	add	x8, x8, #0xd80
1000264a8: 3dc043e0    	ldr	q0, [sp, #0x100]
1000264ac: 3c808100    	stur	q0, [x8, #0x8]
1000264b0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000264b4: 91360000    	add	x0, x0, #0xd80
1000264b8: 94002742    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000264bc: d2800015    	mov	x21, #0x0               ; =0
1000264c0: 17fff90c    	b	0x1000248f0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6658>
1000264c4: d2800008    	mov	x8, #0x0                ; =0
1000264c8: 52800009    	mov	w9, #0x0                ; =0
1000264cc: 36072389    	tbz	w9, #0x0, 0x10002493c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x66a4>
1000264d0: 1400004c    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
1000264d4: d2800009    	mov	x9, #0x0                ; =0
1000264d8: 5280000a    	mov	w10, #0x0               ; =0
1000264dc: 3607240a    	tbz	w10, #0x0, 0x10002495c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x66c4>
1000264e0: 14000048    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
1000264e4: d2800009    	mov	x9, #0x0                ; =0
1000264e8: 5280000a    	mov	w10, #0x0               ; =0
1000264ec: 360724ca    	tbz	w10, #0x0, 0x100024984 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x66ec>
1000264f0: 14000044    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
1000264f4: d280000a    	mov	x10, #0x0               ; =0
1000264f8: 5280000b    	mov	w11, #0x0               ; =0
1000264fc: 3607256b    	tbz	w11, #0x0, 0x1000249a8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6710>
100026500: 14000040    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100026504: d2800009    	mov	x9, #0x0                ; =0
100026508: 5280000a    	mov	w10, #0x0               ; =0
10002650c: 3607266a    	tbz	w10, #0x0, 0x1000249d8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6740>
100026510: 1400003c    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100026514: d280000a    	mov	x10, #0x0               ; =0
100026518: 5280000b    	mov	w11, #0x0               ; =0
10002651c: 3607270b    	tbz	w11, #0x0, 0x1000249fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6764>
100026520: 14000038    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100026524: d2800009    	mov	x9, #0x0                ; =0
100026528: 5280000a    	mov	w10, #0x0               ; =0
10002652c: 3607280a    	tbz	w10, #0x0, 0x100024a2c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6794>
100026530: 14000034    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100026534: d280000a    	mov	x10, #0x0               ; =0
100026538: 5280000b    	mov	w11, #0x0               ; =0
10002653c: 360728ab    	tbz	w11, #0x0, 0x100024a50 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x67b8>
100026540: 14000030    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100026544: d2800009    	mov	x9, #0x0                ; =0
100026548: 5280000a    	mov	w10, #0x0               ; =0
10002654c: 360729aa    	tbz	w10, #0x0, 0x100024a80 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x67e8>
100026550: 1400002c    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100026554: d280000a    	mov	x10, #0x0               ; =0
100026558: 5280000b    	mov	w11, #0x0               ; =0
10002655c: 36072a4b    	tbz	w11, #0x0, 0x100024aa4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x680c>
100026560: 14000028    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100026564: d2800009    	mov	x9, #0x0                ; =0
100026568: 5280000a    	mov	w10, #0x0               ; =0
10002656c: 36072b4a    	tbz	w10, #0x0, 0x100024ad4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x683c>
100026570: 14000024    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100026574: d280000a    	mov	x10, #0x0               ; =0
100026578: 5280000b    	mov	w11, #0x0               ; =0
10002657c: 36072beb    	tbz	w11, #0x0, 0x100024af8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6860>
100026580: 14000020    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100026584: d2800009    	mov	x9, #0x0                ; =0
100026588: 5280000a    	mov	w10, #0x0               ; =0
10002658c: 36072cea    	tbz	w10, #0x0, 0x100024b28 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6890>
100026590: 1400001c    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100026594: d280000a    	mov	x10, #0x0               ; =0
100026598: 5280000b    	mov	w11, #0x0               ; =0
10002659c: 36072d8b    	tbz	w11, #0x0, 0x100024b4c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x68b4>
1000265a0: 14000018    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
1000265a4: d2800009    	mov	x9, #0x0                ; =0
1000265a8: 5280000a    	mov	w10, #0x0               ; =0
1000265ac: 36072e8a    	tbz	w10, #0x0, 0x100024b7c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x68e4>
1000265b0: 14000014    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
1000265b4: d280000a    	mov	x10, #0x0               ; =0
1000265b8: 5280000b    	mov	w11, #0x0               ; =0
1000265bc: 36072f2b    	tbz	w11, #0x0, 0x100024ba0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6908>
1000265c0: 14000010    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
1000265c4: d2800009    	mov	x9, #0x0                ; =0
1000265c8: 5280000a    	mov	w10, #0x0               ; =0
1000265cc: 3607302a    	tbz	w10, #0x0, 0x100024bd0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x6938>
1000265d0: 1400000c    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
1000265d4: d280000a    	mov	x10, #0x0               ; =0
1000265d8: 5280000b    	mov	w11, #0x0               ; =0
1000265dc: 360730cb    	tbz	w11, #0x0, 0x100024bf4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x695c>
1000265e0: 14000008    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
1000265e4: d2800009    	mov	x9, #0x0                ; =0
1000265e8: 5280000a    	mov	w10, #0x0               ; =0
1000265ec: 360731ca    	tbz	w10, #0x0, 0x100024c24 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x698c>
1000265f0: 14000004    	b	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
1000265f4: d280000a    	mov	x10, #0x0               ; =0
1000265f8: 5280000b    	mov	w11, #0x0               ; =0
1000265fc: 3607326b    	tbz	w11, #0x0, 0x100024c48 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x69b0>
100026600: 10068c00    	adr	x0, 0x100033780 <_.roc.bytes.2>
100026604: d503201f    	nop
100026608: 52800421    	mov	w1, #0x21               ; =33
10002660c: 97ff711d    	bl	0x100002a80 <_roc_crashed>
100026610: d4200020    	brk	#0x1
100026614: 52800029    	mov	w9, #0x1                ; =1
100026618: f90113e9    	str	x9, [sp, #0x220]
10002661c: 7100111f    	cmp	w8, #0x4
100026620: 5400080c    	b.gt	0x100026720 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8488>
100026624: 71000d1f    	cmp	w8, #0x3
100026628: 54003240    	b.eq	0x100026c70 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x89d8>
10002662c: 7100111f    	cmp	w8, #0x4
100026630: 54002fe1    	b.ne	0x100026c2c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8994>
100026634: f900a7e2    	str	x2, [sp, #0x148]
100026638: f90113ff    	str	xzr, [sp, #0x220]
10002663c: 528003c8    	mov	w8, #0x1e               ; =30
100026640: f901a7e8    	str	x8, [sp, #0x348]
100026644: 52800208    	mov	w8, #0x10               ; =16
100026648: 17ffe752    	b	0x100020390 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x20f8>
10002664c: 914007f3    	add	x19, sp, #0x1, lsl #12  ; =0x1000
100026650: 911be273    	add	x19, x19, #0x6f8
100026654: 3cce8260    	ldur	q0, [x19, #0xe8]
100026658: 3d8763e0    	str	q0, [sp, #0x1d80]
10002665c: f84f8268    	ldur	x8, [x19, #0xf8]
100026660: f90ecbe8    	str	x8, [sp, #0x1d90]
100026664: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100026668: 91360000    	add	x0, x0, #0xd80
10002666c: 940026d5    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026670: 3dc04260    	ldr	q0, [x19, #0x100]
100026674: 3d8763e0    	str	q0, [sp, #0x1d80]
100026678: f9408a68    	ldr	x8, [x19, #0x110]
10002667c: f90ecbe8    	str	x8, [sp, #0x1d90]
100026680: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100026684: 91360000    	add	x0, x0, #0xd80
100026688: 940026ce    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002668c: 3ccb8260    	ldur	q0, [x19, #0xb8]
100026690: 3d8763e0    	str	q0, [sp, #0x1d80]
100026694: f84c8268    	ldur	x8, [x19, #0xc8]
100026698: f90ecbe8    	str	x8, [sp, #0x1d90]
10002669c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000266a0: 91360000    	add	x0, x0, #0xd80
1000266a4: 940026c7    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000266a8: 3ccd0260    	ldur	q0, [x19, #0xd0]
1000266ac: 3d8763e0    	str	q0, [sp, #0x1d80]
1000266b0: f84e0268    	ldur	x8, [x19, #0xe0]
1000266b4: f90ecbe8    	str	x8, [sp, #0x1d90]
1000266b8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000266bc: 91360000    	add	x0, x0, #0xd80
1000266c0: 940026c0    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000266c4: 52a00028    	mov	w8, #0x10000            ; =65536
1000266c8: f90ec3f7    	str	x23, [sp, #0x1d80]
1000266cc: f90ec7e8    	str	x8, [sp, #0x1d88]
1000266d0: f90ecbf5    	str	x21, [sp, #0x1d90]
1000266d4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000266d8: 91360000    	add	x0, x0, #0xd80
1000266dc: 940026b9    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000266e0: f941abe8    	ldr	x8, [sp, #0x350]
1000266e4: f90ec3e8    	str	x8, [sp, #0x1d80]
1000266e8: f90ec7fc    	str	x28, [sp, #0x1d88]
1000266ec: f94187e8    	ldr	x8, [sp, #0x308]
1000266f0: f90ecbe8    	str	x8, [sp, #0x1d90]
1000266f4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000266f8: 91360000    	add	x0, x0, #0xd80
1000266fc: 940026b1    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026700: f9414bfb    	ldr	x27, [sp, #0x290]
100026704: f9415be8    	ldr	x8, [sp, #0x2b0]
100026708: b4025488    	cbz	x8, 0x10002b198 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xcf00>
10002670c: 35032df6    	cbnz	w22, 0x10002ccc8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xea30>
100026710: f94157e8    	ldr	x8, [sp, #0x2a8]
100026714: 38396b48    	strb	w8, [x26, x25]
100026718: 91000739    	add	x25, x25, #0x1
10002671c: 1400129f    	b	0x10002b198 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xcf00>
100026720: 7100151f    	cmp	w8, #0x5
100026724: 54002b00    	b.eq	0x100026c84 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x89ec>
100026728: 7100191f    	cmp	w8, #0x6
10002672c: 54002801    	b.ne	0x100026c2c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8994>
100026730: 52800828    	mov	w8, #0x41               ; =65
100026734: f9015be8    	str	x8, [sp, #0x2b0]
100026738: 52800468    	mov	w8, #0x23               ; =35
10002673c: f90133e8    	str	x8, [sp, #0x260]
100026740: 52800028    	mov	w8, #0x1                ; =1
100026744: f90113e8    	str	x8, [sp, #0x220]
100026748: 14000153    	b	0x100026c94 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x89fc>
10002674c: 52804168    	mov	w8, #0x20b              ; =523
100026750: f90ec3f5    	str	x21, [sp, #0x1d80]
100026754: f90ec7e8    	str	x8, [sp, #0x1d88]
100026758: 52808548    	mov	w8, #0x42a              ; =1066
10002675c: f90ecbe8    	str	x8, [sp, #0x1d90]
100026760: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100026764: 91360000    	add	x0, x0, #0xd80
100026768: aa1103f3    	mov	x19, x17
10002676c: aa0103f4    	mov	x20, x1
100026770: aa0c03f5    	mov	x21, x12
100026774: 94002693    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026778: f90ec3f6    	str	x22, [sp, #0x1d80]
10002677c: f90ec7f7    	str	x23, [sp, #0x1d88]
100026780: f9415be8    	ldr	x8, [sp, #0x2b0]
100026784: f90ecbe8    	str	x8, [sp, #0x1d90]
100026788: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002678c: 91360000    	add	x0, x0, #0xd80
100026790: 9400268c    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026794: f90ec3f8    	str	x24, [sp, #0x1d80]
100026798: f90ec7f3    	str	x19, [sp, #0x1d88]
10002679c: f9415fe8    	ldr	x8, [sp, #0x2b8]
1000267a0: f90ecbe8    	str	x8, [sp, #0x1d90]
1000267a4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000267a8: 91360000    	add	x0, x0, #0xd80
1000267ac: 94002685    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000267b0: f90ec3f5    	str	x21, [sp, #0x1d80]
1000267b4: f90ec7f4    	str	x20, [sp, #0x1d88]
1000267b8: f94163e8    	ldr	x8, [sp, #0x2c0]
1000267bc: f90ecbe8    	str	x8, [sp, #0x1d90]
1000267c0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000267c4: 91360000    	add	x0, x0, #0xd80
1000267c8: 9400267e    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000267cc: 52800148    	mov	w8, #0xa                ; =10
1000267d0: f940f7e9    	ldr	x9, [sp, #0x1e8]
1000267d4: f90ec3e9    	str	x9, [sp, #0x1d80]
1000267d8: f90ec7e8    	str	x8, [sp, #0x1d88]
1000267dc: 52800508    	mov	w8, #0x28               ; =40
1000267e0: f90ecbe8    	str	x8, [sp, #0x1d90]
1000267e4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000267e8: 91360000    	add	x0, x0, #0xd80
1000267ec: 94002675    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000267f0: f94133e8    	ldr	x8, [sp, #0x260]
1000267f4: f90ec3e8    	str	x8, [sp, #0x1d80]
1000267f8: f94173e8    	ldr	x8, [sp, #0x2e0]
1000267fc: f90ec7e8    	str	x8, [sp, #0x1d88]
100026800: f940e3e8    	ldr	x8, [sp, #0x1c0]
100026804: f90ecbe8    	str	x8, [sp, #0x1d90]
100026808: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002680c: 91360000    	add	x0, x0, #0xd80
100026810: 9400266c    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026814: 528021c8    	mov	w8, #0x10e              ; =270
100026818: f9412be9    	ldr	x9, [sp, #0x250]
10002681c: f90ec3e9    	str	x9, [sp, #0x1d80]
100026820: f90ec7e8    	str	x8, [sp, #0x1d88]
100026824: 52804608    	mov	w8, #0x230              ; =560
100026828: f90ecbe8    	str	x8, [sp, #0x1d90]
10002682c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100026830: 91360000    	add	x0, x0, #0xd80
100026834: 94002663    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026838: 3dc1ffe0    	ldr	q0, [sp, #0x7f0]
10002683c: 3d8763e0    	str	q0, [sp, #0x1d80]
100026840: f94403e8    	ldr	x8, [sp, #0x800]
100026844: f90ecbe8    	str	x8, [sp, #0x1d90]
100026848: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002684c: 91360000    	add	x0, x0, #0xd80
100026850: 9400265c    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026854: 3dc1f7e0    	ldr	q0, [sp, #0x7d0]
100026858: 3d8763e0    	str	q0, [sp, #0x1d80]
10002685c: f943f3e8    	ldr	x8, [sp, #0x7e0]
100026860: f90ecbe8    	str	x8, [sp, #0x1d90]
100026864: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100026868: 91360000    	add	x0, x0, #0xd80
10002686c: 94002655    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026870: 3dc1efe0    	ldr	q0, [sp, #0x7b0]
100026874: 3d8763e0    	str	q0, [sp, #0x1d80]
100026878: f943e3e8    	ldr	x8, [sp, #0x7c0]
10002687c: f90ecbe8    	str	x8, [sp, #0x1d90]
100026880: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100026884: 91360000    	add	x0, x0, #0xd80
100026888: 9400264e    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002688c: 3dc1e7e0    	ldr	q0, [sp, #0x790]
100026890: 3d8763e0    	str	q0, [sp, #0x1d80]
100026894: f943d3e8    	ldr	x8, [sp, #0x7a0]
100026898: f90ecbe8    	str	x8, [sp, #0x1d90]
10002689c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000268a0: 91360000    	add	x0, x0, #0xd80
1000268a4: 94002647    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000268a8: f94143e8    	ldr	x8, [sp, #0x280]
1000268ac: f90ec3e8    	str	x8, [sp, #0x1d80]
1000268b0: f9417fe8    	ldr	x8, [sp, #0x2f8]
1000268b4: f90ec7e8    	str	x8, [sp, #0x1d88]
1000268b8: f9414be8    	ldr	x8, [sp, #0x290]
1000268bc: f90ecbe8    	str	x8, [sp, #0x1d90]
1000268c0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000268c4: 91360000    	add	x0, x0, #0xd80
1000268c8: 9400263e    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000268cc: 1006ac20    	adr	x0, 0x100033e50 <_.roc.bytes.37>
1000268d0: d503201f    	nop
1000268d4: 52800681    	mov	w1, #0x34               ; =52
1000268d8: 9400275d    	bl	0x10003064c <_roc_cold_shim.roc_builtins_str_from_literal>
1000268dc: f9052be0    	str	x0, [sp, #0xa50]
1000268e0: f9052fe1    	str	x1, [sp, #0xa58]
1000268e4: f90533e2    	str	x2, [sp, #0xa60]
1000268e8: 912943e0    	add	x0, sp, #0xa50
1000268ec: 94002776    	bl	0x1000306c4 <_roc_cold_shim.roc_builtins_crash_str>
1000268f0: 521101c8    	eor	w8, w14, #0x8000
1000268f4: 782d7988    	strh	w8, [x12, x13, lsl #1]
1000268f8: f90ec3ec    	str	x12, [sp, #0x1d80]
1000268fc: f90ec7e1    	str	x1, [sp, #0x1d88]
100026900: f94163e8    	ldr	x8, [sp, #0x2c0]
100026904: f90ecbe8    	str	x8, [sp, #0x1d90]
100026908: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002690c: 91360000    	add	x0, x0, #0xd80
100026910: aa1103f3    	mov	x19, x17
100026914: 9400262b    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026918: 52804168    	mov	w8, #0x20b              ; =523
10002691c: f90ec3f5    	str	x21, [sp, #0x1d80]
100026920: f90ec7e8    	str	x8, [sp, #0x1d88]
100026924: 52808548    	mov	w8, #0x42a              ; =1066
100026928: f90ecbe8    	str	x8, [sp, #0x1d90]
10002692c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100026930: 91360000    	add	x0, x0, #0xd80
100026934: 94002623    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026938: f90ec3f6    	str	x22, [sp, #0x1d80]
10002693c: f90ec7f7    	str	x23, [sp, #0x1d88]
100026940: f9415be8    	ldr	x8, [sp, #0x2b0]
100026944: f90ecbe8    	str	x8, [sp, #0x1d90]
100026948: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002694c: 91360000    	add	x0, x0, #0xd80
100026950: 9400261c    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026954: f90ec3f8    	str	x24, [sp, #0x1d80]
100026958: f90ec7f3    	str	x19, [sp, #0x1d88]
10002695c: f9415fe8    	ldr	x8, [sp, #0x2b8]
100026960: f90ecbe8    	str	x8, [sp, #0x1d90]
100026964: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100026968: 91360000    	add	x0, x0, #0xd80
10002696c: 94002615    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026970: 52800148    	mov	w8, #0xa                ; =10
100026974: f940f7e9    	ldr	x9, [sp, #0x1e8]
100026978: f90ec3e9    	str	x9, [sp, #0x1d80]
10002697c: f90ec7e8    	str	x8, [sp, #0x1d88]
100026980: 52800508    	mov	w8, #0x28               ; =40
100026984: f90ecbe8    	str	x8, [sp, #0x1d90]
100026988: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002698c: 91360000    	add	x0, x0, #0xd80
100026990: 9400260c    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026994: f94133e8    	ldr	x8, [sp, #0x260]
100026998: f90ec3e8    	str	x8, [sp, #0x1d80]
10002699c: f94173e8    	ldr	x8, [sp, #0x2e0]
1000269a0: f90ec7e8    	str	x8, [sp, #0x1d88]
1000269a4: f940e3e8    	ldr	x8, [sp, #0x1c0]
1000269a8: f90ecbe8    	str	x8, [sp, #0x1d90]
1000269ac: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000269b0: 91360000    	add	x0, x0, #0xd80
1000269b4: 94002603    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000269b8: 528021c8    	mov	w8, #0x10e              ; =270
1000269bc: f9412be9    	ldr	x9, [sp, #0x250]
1000269c0: f90ec3e9    	str	x9, [sp, #0x1d80]
1000269c4: f90ec7e8    	str	x8, [sp, #0x1d88]
1000269c8: 52804608    	mov	w8, #0x230              ; =560
1000269cc: f90ecbe8    	str	x8, [sp, #0x1d90]
1000269d0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000269d4: 91360000    	add	x0, x0, #0xd80
1000269d8: 940025fa    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000269dc: 3dc1ffe0    	ldr	q0, [sp, #0x7f0]
1000269e0: 3d8763e0    	str	q0, [sp, #0x1d80]
1000269e4: f94403e8    	ldr	x8, [sp, #0x800]
1000269e8: f90ecbe8    	str	x8, [sp, #0x1d90]
1000269ec: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000269f0: 91360000    	add	x0, x0, #0xd80
1000269f4: 940025f3    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000269f8: 3dc1f7e0    	ldr	q0, [sp, #0x7d0]
1000269fc: 3d8763e0    	str	q0, [sp, #0x1d80]
100026a00: f943f3e8    	ldr	x8, [sp, #0x7e0]
100026a04: f90ecbe8    	str	x8, [sp, #0x1d90]
100026a08: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100026a0c: 91360000    	add	x0, x0, #0xd80
100026a10: 940025ec    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026a14: 3dc1efe0    	ldr	q0, [sp, #0x7b0]
100026a18: 3d8763e0    	str	q0, [sp, #0x1d80]
100026a1c: f943e3e8    	ldr	x8, [sp, #0x7c0]
100026a20: f90ecbe8    	str	x8, [sp, #0x1d90]
100026a24: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100026a28: 91360000    	add	x0, x0, #0xd80
100026a2c: 940025e5    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026a30: 3dc1e7e0    	ldr	q0, [sp, #0x790]
100026a34: 3d8763e0    	str	q0, [sp, #0x1d80]
100026a38: f943d3e8    	ldr	x8, [sp, #0x7a0]
100026a3c: f90ecbe8    	str	x8, [sp, #0x1d90]
100026a40: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100026a44: 91360000    	add	x0, x0, #0xd80
100026a48: 940025de    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026a4c: f94143e8    	ldr	x8, [sp, #0x280]
100026a50: f90ec3e8    	str	x8, [sp, #0x1d80]
100026a54: f9417fe8    	ldr	x8, [sp, #0x2f8]
100026a58: f90ec7e8    	str	x8, [sp, #0x1d88]
100026a5c: f9414be8    	ldr	x8, [sp, #0x290]
100026a60: f90ecbe8    	str	x8, [sp, #0x1d90]
100026a64: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100026a68: 91360000    	add	x0, x0, #0xd80
100026a6c: 940025d5    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026a70: 10069f00    	adr	x0, 0x100033e50 <_.roc.bytes.37>
100026a74: d503201f    	nop
100026a78: 52800681    	mov	w1, #0x34               ; =52
100026a7c: 940026f4    	bl	0x10003064c <_roc_cold_shim.roc_builtins_str_from_literal>
100026a80: f9051fe0    	str	x0, [sp, #0xa38]
100026a84: f90523e1    	str	x1, [sp, #0xa40]
100026a88: f90527e2    	str	x2, [sp, #0xa48]
100026a8c: 9128e3e0    	add	x0, sp, #0xa38
100026a90: 9400270d    	bl	0x1000306c4 <_roc_cold_shim.roc_builtins_crash_str>
100026a94: f90ec3ec    	str	x12, [sp, #0x1d80]
100026a98: f90ec7e1    	str	x1, [sp, #0x1d88]
100026a9c: f94163e8    	ldr	x8, [sp, #0x2c0]
100026aa0: f90ecbe8    	str	x8, [sp, #0x1d90]
100026aa4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100026aa8: 91360000    	add	x0, x0, #0xd80
100026aac: 940025c5    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026ab0: f90ec3f8    	str	x24, [sp, #0x1d80]
100026ab4: f90ec7f3    	str	x19, [sp, #0x1d88]
100026ab8: f9415fe8    	ldr	x8, [sp, #0x2b8]
100026abc: f90ecbe8    	str	x8, [sp, #0x1d90]
100026ac0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100026ac4: 91360000    	add	x0, x0, #0xd80
100026ac8: 940025be    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026acc: 52804168    	mov	w8, #0x20b              ; =523
100026ad0: f90ec3f5    	str	x21, [sp, #0x1d80]
100026ad4: f90ec7e8    	str	x8, [sp, #0x1d88]
100026ad8: 52808548    	mov	w8, #0x42a              ; =1066
100026adc: f90ecbe8    	str	x8, [sp, #0x1d90]
100026ae0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100026ae4: 91360000    	add	x0, x0, #0xd80
100026ae8: 940025b6    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026aec: f90ec3f6    	str	x22, [sp, #0x1d80]
100026af0: f90ec7f7    	str	x23, [sp, #0x1d88]
100026af4: f9415be8    	ldr	x8, [sp, #0x2b0]
100026af8: f90ecbe8    	str	x8, [sp, #0x1d90]
100026afc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100026b00: 91360000    	add	x0, x0, #0xd80
100026b04: 940025af    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026b08: 52800148    	mov	w8, #0xa                ; =10
100026b0c: f940f7e9    	ldr	x9, [sp, #0x1e8]
100026b10: f90ec3e9    	str	x9, [sp, #0x1d80]
100026b14: f90ec7e8    	str	x8, [sp, #0x1d88]
100026b18: 52800508    	mov	w8, #0x28               ; =40
100026b1c: f90ecbe8    	str	x8, [sp, #0x1d90]
100026b20: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100026b24: 91360000    	add	x0, x0, #0xd80
100026b28: 940025a6    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026b2c: f94133e8    	ldr	x8, [sp, #0x260]
100026b30: f90ec3e8    	str	x8, [sp, #0x1d80]
100026b34: f94173e8    	ldr	x8, [sp, #0x2e0]
100026b38: f90ec7e8    	str	x8, [sp, #0x1d88]
100026b3c: f940e3e8    	ldr	x8, [sp, #0x1c0]
100026b40: f90ecbe8    	str	x8, [sp, #0x1d90]
100026b44: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100026b48: 91360000    	add	x0, x0, #0xd80
100026b4c: 9400259d    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026b50: 528021c8    	mov	w8, #0x10e              ; =270
100026b54: f9412be9    	ldr	x9, [sp, #0x250]
100026b58: f90ec3e9    	str	x9, [sp, #0x1d80]
100026b5c: f90ec7e8    	str	x8, [sp, #0x1d88]
100026b60: 52804608    	mov	w8, #0x230              ; =560
100026b64: f90ecbe8    	str	x8, [sp, #0x1d90]
100026b68: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100026b6c: 91360000    	add	x0, x0, #0xd80
100026b70: 94002594    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026b74: 3dc1ffe0    	ldr	q0, [sp, #0x7f0]
100026b78: 3d8763e0    	str	q0, [sp, #0x1d80]
100026b7c: f94403e8    	ldr	x8, [sp, #0x800]
100026b80: f90ecbe8    	str	x8, [sp, #0x1d90]
100026b84: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100026b88: 91360000    	add	x0, x0, #0xd80
100026b8c: 9400258d    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026b90: 3dc1f7e0    	ldr	q0, [sp, #0x7d0]
100026b94: 3d8763e0    	str	q0, [sp, #0x1d80]
100026b98: f943f3e8    	ldr	x8, [sp, #0x7e0]
100026b9c: f90ecbe8    	str	x8, [sp, #0x1d90]
100026ba0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100026ba4: 91360000    	add	x0, x0, #0xd80
100026ba8: 94002586    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026bac: 3dc1efe0    	ldr	q0, [sp, #0x7b0]
100026bb0: 3d8763e0    	str	q0, [sp, #0x1d80]
100026bb4: f943e3e8    	ldr	x8, [sp, #0x7c0]
100026bb8: f90ecbe8    	str	x8, [sp, #0x1d90]
100026bbc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100026bc0: 91360000    	add	x0, x0, #0xd80
100026bc4: 9400257f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026bc8: 3dc1e7e0    	ldr	q0, [sp, #0x790]
100026bcc: 3d8763e0    	str	q0, [sp, #0x1d80]
100026bd0: f943d3e8    	ldr	x8, [sp, #0x7a0]
100026bd4: f90ecbe8    	str	x8, [sp, #0x1d90]
100026bd8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100026bdc: 91360000    	add	x0, x0, #0xd80
100026be0: 94002578    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026be4: f94143e8    	ldr	x8, [sp, #0x280]
100026be8: f90ec3e8    	str	x8, [sp, #0x1d80]
100026bec: f9417fe8    	ldr	x8, [sp, #0x2f8]
100026bf0: f90ec7e8    	str	x8, [sp, #0x1d88]
100026bf4: f9414be8    	ldr	x8, [sp, #0x290]
100026bf8: f90ecbe8    	str	x8, [sp, #0x1d90]
100026bfc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
100026c00: 91360000    	add	x0, x0, #0xd80
100026c04: 9400256f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100026c08: 10069240    	adr	x0, 0x100033e50 <_.roc.bytes.37>
100026c0c: d503201f    	nop
100026c10: 52800681    	mov	w1, #0x34               ; =52
100026c14: 9400268e    	bl	0x10003064c <_roc_cold_shim.roc_builtins_str_from_literal>
100026c18: f90513e0    	str	x0, [sp, #0xa20]
100026c1c: f90517e1    	str	x1, [sp, #0xa28]
100026c20: f9051be2    	str	x2, [sp, #0xa30]
100026c24: 912883e0    	add	x0, sp, #0xa20
100026c28: 940026a7    	bl	0x1000306c4 <_roc_cold_shim.roc_builtins_crash_str>
100026c2c: 12001c48    	and	w8, w2, #0xff
100026c30: 7100211f    	cmp	w8, #0x8
100026c34: 52804b09    	mov	w9, #0x258              ; =600
100026c38: 5280258a    	mov	w10, #0x12c             ; =300
100026c3c: 9a890149    	csel	x9, x10, x9, eq
100026c40: 71001d1f    	cmp	w8, #0x7
100026c44: 52800028    	mov	w8, #0x1                ; =1
100026c48: 9a880508    	cinc	x8, x8, ne
100026c4c: f90113e8    	str	x8, [sp, #0x220]
100026c50: 52800c88    	mov	w8, #0x64               ; =100
100026c54: 9a890108    	csel	x8, x8, x9, eq
100026c58: f90133e8    	str	x8, [sp, #0x260]
100026c5c: 52802048    	mov	w8, #0x102              ; =258
100026c60: 52801049    	mov	w9, #0x82               ; =130
100026c64: 9a880128    	csel	x8, x9, x8, eq
100026c68: f9015be8    	str	x8, [sp, #0x2b0]
100026c6c: 1400000a    	b	0x100026c94 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x89fc>
100026c70: f900a7e2    	str	x2, [sp, #0x148]
100026c74: 528001c8    	mov	w8, #0xe                ; =14
100026c78: f901a7e8    	str	x8, [sp, #0x348]
100026c7c: 52800188    	mov	w8, #0xc                ; =12
100026c80: 17ffe5c4    	b	0x100020390 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x20f8>
100026c84: 528003c8    	mov	w8, #0x1e               ; =30
100026c88: f9015be8    	str	x8, [sp, #0x2b0]
100026c8c: 52800208    	mov	w8, #0x10               ; =16
100026c90: f90133e8    	str	x8, [sp, #0x260]
100026c94: 911cc3e0    	add	x0, sp, #0x730
100026c98: 97ffcc2d    	bl	0x100019d4c <_roc__pf8d88d29f38eeb441b6a5ad4fe5ffba5.fast>
100026c9c: 528270e8    	mov	w8, #0x1387             ; =4999
100026ca0: f941a3e9    	ldr	x9, [sp, #0x340]
100026ca4: 8b080128    	add	x8, x9, x8
100026ca8: 9bd47d08    	umulh	x8, x8, x20
100026cac: d34afd08    	lsr	x8, x8, #10
100026cb0: f100051f    	cmp	x8, #0x1
100026cb4: 9a9f8508    	csinc	x8, x8, xzr, hi
100026cb8: 8b080908    	add	x8, x8, x8, lsl #2
100026cbc: 8b090103    	add	x3, x8, x9
100026cc0: f9414be2    	ldr	x2, [sp, #0x290]
100026cc4: 3702e8e2    	tbnz	w2, #0x0, 0x10002c9e0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe748>
100026cc8: d341fc48    	lsr	x8, x2, #1
100026ccc: cb190108    	sub	x8, x8, x25
100026cd0: eb03011f    	cmp	x8, x3
100026cd4: 5402e863    	b.lo	0x10002c9e0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe748>
100026cd8: f9017ff9    	str	x25, [sp, #0x2f8]
100026cdc: 911cc3f4    	add	x20, sp, #0x730
100026ce0: 52800509    	mov	w9, #0x28               ; =40
100026ce4: 72a00029    	movk	w9, #0x1, lsl #16
100026ce8: 52800508    	mov	w8, #0x28               ; =40
100026cec: 72a00028    	movk	w8, #0x1, lsl #16
100026cf0: f901a7e8    	str	x8, [sp, #0x348]
100026cf4: 91002120    	add	x0, x9, #0x8
100026cf8: 52800101    	mov	w1, #0x8                ; =8
100026cfc: 97ff6ee1    	bl	0x100002880 <_roc_alloc>
100026d00: aa0003f5    	mov	x21, x0
100026d04: 78008ebf    	strh	wzr, [x21, #0x8]!
100026d08: 52800028    	mov	w8, #0x1                ; =1
100026d0c: f9000008    	str	x8, [x0]
100026d10: f94002a9    	ldr	x9, [x21]
100026d14: aa0003e8    	mov	x8, x0
100026d18: f800ad09    	str	x9, [x8, #0xa]!
100026d1c: f800c009    	stur	x9, [x0, #0xc]
100026d20: f800e009    	stur	x9, [x0, #0xe]
100026d24: f9000809    	str	x9, [x0, #0x10]
100026d28: 928002a9    	mov	x9, #-0x16              ; =-22
100026d2c: f940010a    	ldr	x10, [x8]
100026d30: f8028d0a    	str	x10, [x8, #0x28]!
100026d34: a93e290a    	stp	x10, x10, [x8, #-0x20]
100026d38: a93f290a    	stp	x10, x10, [x8, #-0x10]
100026d3c: 9100a129    	add	x9, x9, #0x28
100026d40: d345fd2a    	lsr	x10, x9, #5
100026d44: f11ffd5f    	cmp	x10, #0x7ff
100026d48: 54ffff23    	b.lo	0x100026d2c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8a94>
100026d4c: 52800509    	mov	w9, #0x28               ; =40
100026d50: 72a00049    	movk	w9, #0x2, lsl #16
100026d54: 52800508    	mov	w8, #0x28               ; =40
100026d58: 72a00048    	movk	w8, #0x2, lsl #16
100026d5c: f901abe8    	str	x8, [sp, #0x350]
100026d60: 91002120    	add	x0, x9, #0x8
100026d64: 52800101    	mov	w1, #0x8                ; =8
100026d68: 97ff6ec6    	bl	0x100002880 <_roc_alloc>
100026d6c: aa0003f9    	mov	x25, x0
100026d70: 78008f3f    	strh	wzr, [x25, #0x8]!
100026d74: 52800028    	mov	w8, #0x1                ; =1
100026d78: f9000008    	str	x8, [x0]
100026d7c: f9400329    	ldr	x9, [x25]
100026d80: aa0003e8    	mov	x8, x0
100026d84: f800ad09    	str	x9, [x8, #0xa]!
100026d88: f800c009    	stur	x9, [x0, #0xc]
100026d8c: f800e009    	stur	x9, [x0, #0xe]
100026d90: f9000809    	str	x9, [x0, #0x10]
100026d94: 928002a9    	mov	x9, #-0x16              ; =-22
100026d98: f940010a    	ldr	x10, [x8]
100026d9c: f8028d0a    	str	x10, [x8, #0x28]!
100026da0: a93e290a    	stp	x10, x10, [x8, #-0x20]
100026da4: a93f290a    	stp	x10, x10, [x8, #-0x10]
100026da8: 9100a129    	add	x9, x9, #0x28
100026dac: d345fd2a    	lsr	x10, x9, #5
100026db0: f13ffd5f    	cmp	x10, #0xfff
100026db4: 54ffff23    	b.lo	0x100026d98 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8b00>
100026db8: f90143fa    	str	x26, [sp, #0x280]
100026dbc: 52800508    	mov	w8, #0x28               ; =40
100026dc0: 72a00028    	movk	w8, #0x1, lsl #16
100026dc4: 91002100    	add	x0, x8, #0x8
100026dc8: 52800101    	mov	w1, #0x8                ; =8
100026dcc: 97ff6ead    	bl	0x100002880 <_roc_alloc>
100026dd0: aa0003f8    	mov	x24, x0
100026dd4: 78008f1f    	strh	wzr, [x24, #0x8]!
100026dd8: 52800028    	mov	w8, #0x1                ; =1
100026ddc: f9000008    	str	x8, [x0]
100026de0: f9400309    	ldr	x9, [x24]
100026de4: aa0003e8    	mov	x8, x0
100026de8: f800ad09    	str	x9, [x8, #0xa]!
100026dec: f800c009    	stur	x9, [x0, #0xc]
100026df0: f800e009    	stur	x9, [x0, #0xe]
100026df4: f9000809    	str	x9, [x0, #0x10]
100026df8: 928002a9    	mov	x9, #-0x16              ; =-22
100026dfc: f940010a    	ldr	x10, [x8]
100026e00: f8028d0a    	str	x10, [x8, #0x28]!
100026e04: a93e290a    	stp	x10, x10, [x8, #-0x20]
100026e08: a93f290a    	stp	x10, x10, [x8, #-0x10]
100026e0c: 9100a129    	add	x9, x9, #0x28
100026e10: d345fd2a    	lsr	x10, x9, #5
100026e14: f11ffd5f    	cmp	x10, #0x7ff
100026e18: 54ffff23    	b.lo	0x100026dfc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8b64>
100026e1c: 52835200    	mov	w0, #0x1a90             ; =6800
100026e20: 72a000c0    	movk	w0, #0x6, lsl #16
100026e24: 52800101    	mov	w1, #0x8                ; =8
100026e28: 97ff6e96    	bl	0x100002880 <_roc_alloc>
100026e2c: a91affff    	stp	xzr, xzr, [sp, #0x1a8]
100026e30: d2800011    	mov	x17, #0x0               ; =0
100026e34: f90183ff    	str	xzr, [sp, #0x300]
100026e38: f9018bff    	str	xzr, [sp, #0x310]
100026e3c: d280000d    	mov	x13, #0x0               ; =0
100026e40: 5280002c    	mov	w12, #0x1               ; =1
100026e44: 5294ed0e    	mov	w14, #0xa768            ; =42856
100026e48: 72a0008e    	movk	w14, #0x4, lsl #16
100026e4c: 3cc18280    	ldur	q0, [x20, #0x18]
100026e50: 5290d448    	mov	w8, #0x86a2             ; =34466
100026e54: 72a00028    	movk	w8, #0x1, lsl #16
100026e58: f90103e8    	str	x8, [sp, #0x200]
100026e5c: 3d80dfe0    	str	q0, [sp, #0x370]
100026e60: f943afe8    	ldr	x8, [sp, #0x758]
100026e64: f943a3e9    	ldr	x9, [sp, #0x740]
100026e68: f901c3e8    	str	x8, [sp, #0x380]
100026e6c: 3dc1cfe0    	ldr	q0, [sp, #0x730]
100026e70: 3d80e7e0    	str	q0, [sp, #0x390]
100026e74: f901d3e9    	str	x9, [sp, #0x3a0]
100026e78: f941a3ea    	ldr	x10, [sp, #0x340]
100026e7c: d1000d4f    	sub	x15, x10, #0x3
100026e80: f94133e8    	ldr	x8, [sp, #0x260]
100026e84: d341fd09    	lsr	x9, x8, #1
100026e88: f9010fe9    	str	x9, [sp, #0x218]
100026e8c: d342fd08    	lsr	x8, x8, #2
100026e90: f900f7e8    	str	x8, [sp, #0x1e8]
100026e94: 3cc48280    	ldur	q0, [x20, #0x48]
100026e98: d1001548    	sub	x8, x10, #0x5
100026e9c: f900c3e8    	str	x8, [sp, #0x180]
100026ea0: 9114e3e8    	add	x8, sp, #0x538
100026ea4: 91006109    	add	x9, x8, #0x18
100026ea8: 911423e8    	add	x8, sp, #0x508
100026eac: 91006108    	add	x8, x8, #0x18
100026eb0: a91627e8    	stp	x8, x9, [sp, #0x160]
100026eb4: f9419fe8    	ldr	x8, [sp, #0x338]
100026eb8: 91000508    	add	x8, x8, #0x1
100026ebc: f9009be8    	str	x8, [sp, #0x130]
100026ec0: f943c7e8    	ldr	x8, [sp, #0x788]
100026ec4: f943bbe9    	ldr	x9, [sp, #0x770]
100026ec8: 52a0002b    	mov	w11, #0x10000           ; =65536
100026ecc: 5290001a    	mov	w26, #0x8000            ; =32768
100026ed0: f901e3e8    	str	x8, [sp, #0x3c0]
100026ed4: 52802048    	mov	w8, #0x102              ; =258
100026ed8: f9018fe8    	str	x8, [sp, #0x318]
100026edc: 5284e210    	mov	w16, #0x2710            ; =10000
100026ee0: f901f3e9    	str	x9, [sp, #0x3e0]
100026ee4: 0f04a408    	movi.4h	v8, #0x80, lsl #8
100026ee8: 3dc18361    	ldr	q1, [x27, #0x600]
100026eec: 3d805fe1    	str	q1, [sp, #0x170]
100026ef0: 3dc18661    	ldr	q1, [x19, #0x610]
100026ef4: 3dc16b82    	ldr	q2, [x28, #0x5a0]
100026ef8: 3dc17ee3    	ldr	q3, [x23, #0x5f0]
100026efc: 3d8067e3    	str	q3, [sp, #0x190]
100026f00: f800840c    	str	x12, [x0], #0x8
100026f04: f90147e0    	str	x0, [sp, #0x288]
100026f08: 3d80efe0    	str	q0, [sp, #0x3b0]
100026f0c: 3dc1dbe0    	ldr	q0, [sp, #0x760]
100026f10: 3d80f7e0    	str	q0, [sp, #0x3d0]
100026f14: 52800508    	mov	w8, #0x28               ; =40
100026f18: 72a00028    	movk	w8, #0x1, lsl #16
100026f1c: f901afe8    	str	x8, [sp, #0x358]
100026f20: 5290001c    	mov	w28, #0x8000            ; =32768
100026f24: f9414bfb    	ldr	x27, [sp, #0x290]
100026f28: f9415bf7    	ldr	x23, [sp, #0x2b0]
100026f2c: f90173ef    	str	x15, [sp, #0x2e0]
100026f30: ad0e07e2    	stp	q2, q1, [sp, #0x1c0]
100026f34: eb110148    	subs	x8, x10, x17
100026f38: 5401be23    	b.lo	0x10002a6fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc464>
100026f3c: aa1103ec    	mov	x12, x17
100026f40: f90153ea    	str	x10, [sp, #0x2a0]
100026f44: eb0e011f    	cmp	x8, x14
100026f48: 540000c3    	b.lo	0x100026f60 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8cc8>
100026f4c: 52927c09    	mov	w9, #0x93e0             ; =37856
100026f50: 72a00089    	movk	w9, #0x4, lsl #16
100026f54: ab090189    	adds	x9, x12, x9
100026f58: f90153e9    	str	x9, [sp, #0x2a0]
100026f5c: 5401bc62    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100026f60: f901b3ed    	str	x13, [sp, #0x360]
100026f64: f9015bf7    	str	x23, [sp, #0x2b0]
100026f68: eb10011f    	cmp	x8, x16
100026f6c: 9a903108    	csel	x8, x8, x16, lo
100026f70: f90157ec    	str	x12, [sp, #0x2a8]
100026f74: ab080188    	adds	x8, x12, x8
100026f78: f90163e8    	str	x8, [sp, #0x2c0]
100026f7c: 5401bb62    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100026f80: aa0b03f7    	mov	x23, x11
100026f84: 52800b00    	mov	w0, #0x58               ; =88
100026f88: 52800101    	mov	w1, #0x8                ; =8
100026f8c: 97ff6e3d    	bl	0x100002880 <_roc_alloc>
100026f90: aa0003e8    	mov	x8, x0
100026f94: b8008d1f    	str	wzr, [x8, #0x8]!
100026f98: 52800036    	mov	w22, #0x1               ; =1
100026f9c: f9000016    	str	x22, [x0]
100026fa0: f900dfe8    	str	x8, [sp, #0x1b8]
100026fa4: f9400108    	ldr	x8, [x8]
100026fa8: f800c008    	stur	x8, [x0, #0xc]
100026fac: f9000808    	str	x8, [x0, #0x10]
100026fb0: f840c008    	ldur	x8, [x0, #0xc]
100026fb4: f8014008    	stur	x8, [x0, #0x14]
100026fb8: 4e080d00    	dup.2d	v0, x8
100026fbc: 3c82c000    	stur	q0, [x0, #0x2c]
100026fc0: f9014fe0    	str	x0, [sp, #0x298]
100026fc4: 3c81c000    	stur	q0, [x0, #0x1c]
100026fc8: 52810b80    	mov	w0, #0x85c              ; =2140
100026fcc: 52800101    	mov	w1, #0x8                ; =8
100026fd0: 97ff6e2c    	bl	0x100002880 <_roc_alloc>
100026fd4: aa0003f3    	mov	x19, x0
100026fd8: b8008e7f    	str	wzr, [x19, #0x8]!
100026fdc: 52800034    	mov	w20, #0x1               ; =1
100026fe0: f9000016    	str	x22, [x0]
100026fe4: f9400269    	ldr	x9, [x19]
100026fe8: aa0003e8    	mov	x8, x0
100026fec: f800cd09    	str	x9, [x8, #0xc]!
100026ff0: f900f3e0    	str	x0, [sp, #0x1e0]
100026ff4: f9000809    	str	x9, [x0, #0x10]
100026ff8: 92800269    	mov	x9, #-0x14              ; =-20
100026ffc: f940010a    	ldr	x10, [x8]
100027000: f8028d0a    	str	x10, [x8, #0x28]!
100027004: a93e290a    	stp	x10, x10, [x8, #-0x20]
100027008: a93f290a    	stp	x10, x10, [x8, #-0x10]
10002700c: 9100a129    	add	x9, x9, #0x28
100027010: f120313f    	cmp	x9, #0x80c
100027014: 54ffff43    	b.lo	0x100026ffc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8d64>
100027018: 52808d00    	mov	w0, #0x468              ; =1128
10002701c: 52800101    	mov	w1, #0x8                ; =8
100027020: 97ff6e18    	bl	0x100002880 <_roc_alloc>
100027024: aa0003ea    	mov	x10, x0
100027028: b8008d5f    	str	wzr, [x10, #0x8]!
10002702c: f9000014    	str	x20, [x0]
100027030: 91047008    	add	x8, x0, #0x11c
100027034: f9400149    	ldr	x9, [x10]
100027038: f800c009    	stur	x9, [x0, #0xc]
10002703c: f9000809    	str	x9, [x0, #0x10]
100027040: f840c009    	ldur	x9, [x0, #0xc]
100027044: f8014009    	stur	x9, [x0, #0x14]
100027048: 4e080d20    	dup.2d	v0, x9
10002704c: 3c82c000    	stur	q0, [x0, #0x2c]
100027050: 3c81c000    	stur	q0, [x0, #0x1c]
100027054: 3c84c000    	stur	q0, [x0, #0x4c]
100027058: 3c83c000    	stur	q0, [x0, #0x3c]
10002705c: 3c86c000    	stur	q0, [x0, #0x6c]
100027060: 3c85c000    	stur	q0, [x0, #0x5c]
100027064: 3c88c000    	stur	q0, [x0, #0x8c]
100027068: 3c87c000    	stur	q0, [x0, #0x7c]
10002706c: 3c8ac000    	stur	q0, [x0, #0xac]
100027070: 3c89c000    	stur	q0, [x0, #0x9c]
100027074: 3c8cc000    	stur	q0, [x0, #0xcc]
100027078: 3c8bc000    	stur	q0, [x0, #0xbc]
10002707c: 3c8ec000    	stur	q0, [x0, #0xec]
100027080: 3c8dc000    	stur	q0, [x0, #0xdc]
100027084: 3c8fcc00    	str	q0, [x0, #0xfc]!
100027088: 3d800400    	str	q0, [x0, #0x10]
10002708c: ad000100    	stp	q0, q0, [x8]
100027090: ad010100    	stp	q0, q0, [x8, #0x20]
100027094: ad020100    	stp	q0, q0, [x8, #0x40]
100027098: ad030100    	stp	q0, q0, [x8, #0x60]
10002709c: ad040100    	stp	q0, q0, [x8, #0x80]
1000270a0: ad050100    	stp	q0, q0, [x8, #0xa0]
1000270a4: ad060100    	stp	q0, q0, [x8, #0xc0]
1000270a8: ad070100    	stp	q0, q0, [x8, #0xe0]
1000270ac: ad080100    	stp	q0, q0, [x8, #0x100]
1000270b0: ad090100    	stp	q0, q0, [x8, #0x120]
1000270b4: ad0a0100    	stp	q0, q0, [x8, #0x140]
1000270b8: ad0b0100    	stp	q0, q0, [x8, #0x160]
1000270bc: ad0c0100    	stp	q0, q0, [x8, #0x180]
1000270c0: ad0d0100    	stp	q0, q0, [x8, #0x1a0]
1000270c4: ad0e0100    	stp	q0, q0, [x8, #0x1c0]
1000270c8: ad0f0100    	stp	q0, q0, [x8, #0x1e0]
1000270cc: ad100100    	stp	q0, q0, [x8, #0x200]
1000270d0: ad110100    	stp	q0, q0, [x8, #0x220]
1000270d4: ad120100    	stp	q0, q0, [x8, #0x240]
1000270d8: ad130100    	stp	q0, q0, [x8, #0x260]
1000270dc: ad140100    	stp	q0, q0, [x8, #0x280]
1000270e0: ad150100    	stp	q0, q0, [x8, #0x2a0]
1000270e4: ad160100    	stp	q0, q0, [x8, #0x2c0]
1000270e8: ad170100    	stp	q0, q0, [x8, #0x2e0]
1000270ec: ad180100    	stp	q0, q0, [x8, #0x300]
1000270f0: f9019109    	str	x9, [x8, #0x320]
1000270f4: f9019509    	str	x9, [x8, #0x328]
1000270f8: f94103e8    	ldr	x8, [sp, #0x200]
1000270fc: f9012bea    	str	x10, [sp, #0x250]
100027100: 370001c8    	tbnz	w8, #0x0, 0x100027138 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8ea0>
100027104: aa1703e6    	mov	x6, x23
100027108: f941b3e4    	ldr	x4, [sp, #0x360]
10002710c: f94173fe    	ldr	x30, [sp, #0x2e0]
100027110: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100027114: b40003a8    	cbz	x8, 0x100027188 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8ef0>
100027118: d341fd08    	lsr	x8, x8, #1
10002711c: f94147e9    	ldr	x9, [sp, #0x288]
100027120: f85f8129    	ldur	x9, [x9, #-0x8]
100027124: f100053f    	cmp	x9, #0x1
100027128: f94103f6    	ldr	x22, [sp, #0x200]
10002712c: 9a9f0108    	csel	x8, x8, xzr, eq
100027130: f90123e8    	str	x8, [sp, #0x240]
100027134: 14000017    	b	0x100027190 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8ef8>
100027138: f27ff900    	ands	x0, x8, #0xfffffffffffffffe
10002713c: aa1703e6    	mov	x6, x23
100027140: f941b3e4    	ldr	x4, [sp, #0x360]
100027144: f94173fe    	ldr	x30, [sp, #0x2e0]
100027148: 4f04a404    	movi.8h	v4, #0x80, lsl #8
10002714c: 540001c0    	b.eq	0x100027184 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8eec>
100027150: f85f8c08    	ldr	x8, [x0, #-0x8]!
100027154: b4000188    	cbz	x8, 0x100027184 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8eec>
100027158: 92800008    	mov	x8, #-0x1               ; =-1
10002715c: f8280008    	ldadd	x8, x8, [x0]
100027160: f100051f    	cmp	x8, #0x1
100027164: 54000101    	b.ne	0x100027184 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8eec>
100027168: 52800101    	mov	w1, #0x8                ; =8
10002716c: 97ff6de1    	bl	0x1000028f0 <_roc_dealloc>
100027170: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100027174: f94173fe    	ldr	x30, [sp, #0x2e0]
100027178: f941b3e4    	ldr	x4, [sp, #0x360]
10002717c: f9412bea    	ldr	x10, [sp, #0x250]
100027180: aa1703e6    	mov	x6, x23
100027184: f90147ff    	str	xzr, [sp, #0x288]
100027188: d2800016    	mov	x22, #0x0               ; =0
10002718c: f90123ff    	str	xzr, [sp, #0x240]
100027190: f140239f    	cmp	x28, #0x8, lsl #12      ; =0x8000
100027194: 54039ce3    	b.lo	0x10002e530 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x10298>
100027198: f14040df    	cmp	x6, #0x10, lsl #12      ; =0x10000
10002719c: 54039ca3    	b.lo	0x10002e530 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x10298>
1000271a0: d34fff48    	lsr	x8, x26, #15
1000271a4: b4039c68    	cbz	x8, 0x10002e530 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x10298>
1000271a8: f94157e8    	ldr	x8, [sp, #0x2a8]
1000271ac: f94153e9    	ldr	x9, [sp, #0x2a0]
1000271b0: eb080134    	subs	x20, x9, x8
1000271b4: 5401aa43    	b.lo	0x10002a6fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc464>
1000271b8: f108029f    	cmp	x20, #0x200
1000271bc: 540001e2    	b.hs	0x1000271f8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8f60>
1000271c0: 52800068    	mov	w8, #0x3                ; =3
1000271c4: f9016be8    	str	x8, [sp, #0x2d0]
1000271c8: f9419fe7    	ldr	x7, [sp, #0x338]
1000271cc: f941a3e3    	ldr	x3, [sp, #0x340]
1000271d0: f9415bf7    	ldr	x23, [sp, #0x2b0]
1000271d4: f9418ff4    	ldr	x20, [sp, #0x318]
1000271d8: f90103f6    	str	x22, [sp, #0x200]
1000271dc: b4000ab6    	cbz	x22, 0x100027330 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9098>
1000271e0: d341fec8    	lsr	x8, x22, #1
1000271e4: f94147e9    	ldr	x9, [sp, #0x288]
1000271e8: f85f8129    	ldur	x9, [x9, #-0x8]
1000271ec: f100053f    	cmp	x9, #0x1
1000271f0: 9a9f0108    	csel	x8, x8, xzr, eq
1000271f4: 14000050    	b	0x100027334 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x909c>
1000271f8: 52802600    	mov	w0, #0x130              ; =304
1000271fc: 52800101    	mov	w1, #0x8                ; =8
100027200: 97ff6da0    	bl	0x100002880 <_roc_alloc>
100027204: d2800008    	mov	x8, #0x0                ; =0
100027208: 5280002d    	mov	w13, #0x1               ; =1
10002720c: f900000d    	str	x13, [x0]
100027210: 6f00e400    	movi.2d	v0, #0000000000000000
100027214: 3c818000    	stur	q0, [x0, #0x18]
100027218: 3c828000    	stur	q0, [x0, #0x28]
10002721c: 3c838000    	stur	q0, [x0, #0x38]
100027220: 3c848000    	stur	q0, [x0, #0x48]
100027224: 3c858000    	stur	q0, [x0, #0x58]
100027228: 3c868000    	stur	q0, [x0, #0x68]
10002722c: 3c878000    	stur	q0, [x0, #0x78]
100027230: 3c888000    	stur	q0, [x0, #0x88]
100027234: 3c898000    	stur	q0, [x0, #0x98]
100027238: 3c8a8000    	stur	q0, [x0, #0xa8]
10002723c: 3c8b8000    	stur	q0, [x0, #0xb8]
100027240: 3c8c8000    	stur	q0, [x0, #0xc8]
100027244: 3c8d8000    	stur	q0, [x0, #0xd8]
100027248: 3c8e8000    	stur	q0, [x0, #0xe8]
10002724c: 3c8f8000    	stur	q0, [x0, #0xf8]
100027250: 3904201f    	strb	wzr, [x0, #0x108]
100027254: f140069f    	cmp	x20, #0x1, lsl #12      ; =0x1000
100027258: 52820009    	mov	w9, #0x1000             ; =4096
10002725c: 9a893289    	csel	x9, x20, x9, lo
100027260: 3c808c00    	str	q0, [x0, #0x8]!
100027264: f9419feb    	ldr	x11, [sp, #0x338]
100027268: f941a3ec    	ldr	x12, [sp, #0x340]
10002726c: f94157ee    	ldr	x14, [sp, #0x2a8]
100027270: ab0801ca    	adds	x10, x14, x8
100027274: 5401a3a2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100027278: eb0c015f    	cmp	x10, x12
10002727c: 540000e2    	b.hs	0x100027298 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9000>
100027280: 386a696a    	ldrb	w10, [x11, x10]
100027284: 382a680d    	strb	w13, [x0, x10]
100027288: 91000508    	add	x8, x8, #0x1
10002728c: eb08013f    	cmp	x9, x8
100027290: 54ffff01    	b.ne	0x100027270 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8fd8>
100027294: 14000006    	b	0x1000272ac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9014>
100027298: d280000a    	mov	x10, #0x0               ; =0
10002729c: 382a680d    	strb	w13, [x0, x10]
1000272a0: 91000508    	add	x8, x8, #0x1
1000272a4: eb08013f    	cmp	x9, x8
1000272a8: 54fffe41    	b.ne	0x100027270 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8fd8>
1000272ac: d2800008    	mov	x8, #0x0                ; =0
1000272b0: d2800014    	mov	x20, #0x0               ; =0
1000272b4: 38686809    	ldrb	w9, [x0, x8]
1000272b8: ab090294    	adds	x20, x20, x9
1000272bc: 5401a162    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000272c0: 91000508    	add	x8, x8, #0x1
1000272c4: f104011f    	cmp	x8, #0x100
1000272c8: 54ffff61    	b.ne	0x1000272b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x901c>
1000272cc: f904d3e0    	str	x0, [sp, #0x9a0]
1000272d0: 912683e8    	add	x8, sp, #0x9a0
1000272d4: 3dc067e0    	ldr	q0, [sp, #0x190]
1000272d8: 3c808100    	stur	q0, [x8, #0x8]
1000272dc: 912683e0    	add	x0, sp, #0x9a0
1000272e0: 940023b8    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000272e4: f1013e9f    	cmp	x20, #0x4f
1000272e8: 54000069    	b.ls	0x1000272f4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x905c>
1000272ec: 52800068    	mov	w8, #0x3                ; =3
1000272f0: 14000005    	b	0x100027304 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x906c>
1000272f4: 100980e8    	adr	x8, 0x10003a310 <_roc__d61_1>
1000272f8: d503201f    	nop
1000272fc: 8b140108    	add	x8, x8, x20
100027300: 39402108    	ldrb	w8, [x8, #0x8]
100027304: f9016be8    	str	x8, [sp, #0x2d0]
100027308: f9419fe7    	ldr	x7, [sp, #0x338]
10002730c: f941a3e3    	ldr	x3, [sp, #0x340]
100027310: aa1703e6    	mov	x6, x23
100027314: f941b3e4    	ldr	x4, [sp, #0x360]
100027318: f94173fe    	ldr	x30, [sp, #0x2e0]
10002731c: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100027320: f9415bf7    	ldr	x23, [sp, #0x2b0]
100027324: f9418ff4    	ldr	x20, [sp, #0x318]
100027328: f90103f6    	str	x22, [sp, #0x200]
10002732c: b5fff5b6    	cbnz	x22, 0x1000271e0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8f48>
100027330: d2800008    	mov	x8, #0x0                ; =0
100027334: f900fbff    	str	xzr, [sp, #0x1f0]
100027338: b90323ff    	str	wzr, [sp, #0x320]
10002733c: f9015fff    	str	xzr, [sp, #0x2b8]
100027340: a914a3e8    	stp	x8, x8, [sp, #0x148]
100027344: f94157e5    	ldr	x5, [sp, #0x2a8]
100027348: f9014bfb    	str	x27, [sp, #0x290]
10002734c: 5294f7b6    	mov	w22, #0xa7bd            ; =42941
100027350: 72a3c6b6    	movk	w22, #0x1e35, lsl #16
100027354: f90197ff    	str	xzr, [sp, #0x328]
100027358: f94163e8    	ldr	x8, [sp, #0x2c0]
10002735c: eb0800bf    	cmp	x5, x8
100027360: 540004e3    	b.lo	0x1000273fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9164>
100027364: d2800008    	mov	x8, #0x0                ; =0
100027368: d280000a    	mov	x10, #0x0               ; =0
10002736c: b8686a69    	ldr	w9, [x19, x8]
100027370: ab09014a    	adds	x10, x10, x9
100027374: 54019ba2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100027378: 91001108    	add	x8, x8, #0x4
10002737c: f110011f    	cmp	x8, #0x400
100027380: 54ffff61    	b.ne	0x10002736c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x90d4>
100027384: d2800009    	mov	x9, #0x0                ; =0
100027388: d2800008    	mov	x8, #0x0                ; =0
10002738c: d34afd4a    	lsr	x10, x10, #10
100027390: 14000004    	b	0x1000273a0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9108>
100027394: 91001129    	add	x9, x9, #0x4
100027398: f110013f    	cmp	x9, #0x400
10002739c: 540000e0    	b.eq	0x1000273b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9120>
1000273a0: b8696a6b    	ldr	w11, [x19, x9]
1000273a4: eb0b015f    	cmp	x10, x11
1000273a8: 54ffff62    	b.hs	0x100027394 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x90fc>
1000273ac: b1000508    	adds	x8, x8, #0x1
1000273b0: 54ffff23    	b.lo	0x100027394 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x90fc>
1000273b4: 14000ccd    	b	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000273b8: f1013d1f    	cmp	x8, #0x4f
1000273bc: 54000069    	b.ls	0x1000273c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9130>
1000273c0: 52800068    	mov	w8, #0x3                ; =3
1000273c4: 14000005    	b	0x1000273d8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9140>
1000273c8: 10097a49    	adr	x9, 0x10003a310 <_roc__d61_1>
1000273cc: d503201f    	nop
1000273d0: 8b080128    	add	x8, x9, x8
1000273d4: 39402108    	ldrb	w8, [x8, #0x8]
1000273d8: f9016be8    	str	x8, [sp, #0x2d0]
1000273dc: f94163ea    	ldr	x10, [sp, #0x2c0]
1000273e0: cb0a0068    	sub	x8, x3, x10
1000273e4: f94157e9    	ldr	x9, [sp, #0x2a8]
1000273e8: cb0900a9    	sub	x9, x5, x9
1000273ec: eb09011f    	cmp	x8, x9
1000273f0: 9a893108    	csel	x8, x8, x9, lo
1000273f4: 8b0a010a    	add	x10, x8, x10
1000273f8: f90163ea    	str	x10, [sp, #0x2c0]
1000273fc: cb050068    	sub	x8, x3, x5
100027400: eb0802ff    	cmp	x23, x8
100027404: 9a8832e9    	csel	x9, x23, x8, lo
100027408: f104091f    	cmp	x8, #0x102
10002740c: 9a943114    	csel	x20, x8, x20, lo
100027410: 9a973137    	csel	x23, x9, x23, lo
100027414: cb0400a8    	sub	x8, x5, x4
100027418: f140211f    	cmp	x8, #0x8, lsl #12       ; =0x8000
10002741c: 54002f81    	b.ne	0x100027a0c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9774>
100027420: f901b7e6    	str	x6, [sp, #0x368]
100027424: f941afe8    	ldr	x8, [sp, #0x358]
100027428: f901b3e4    	str	x4, [sp, #0x360]
10002742c: f9018ff4    	str	x20, [sp, #0x318]
100027430: f9019be5    	str	x5, [sp, #0x330]
100027434: 37000168    	tbnz	w8, #0x0, 0x100027460 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x91c8>
100027438: f941afe8    	ldr	x8, [sp, #0x358]
10002743c: b4000088    	cbz	x8, 0x10002744c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x91b4>
100027440: f85f82a8    	ldur	x8, [x21, #-0x8]
100027444: f100051f    	cmp	x8, #0x1
100027448: 540000c1    	b.ne	0x100027460 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x91c8>
10002744c: b4000ddc    	cbz	x28, 0x100027604 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x936c>
100027450: f100139f    	cmp	x28, #0x4
100027454: 540008a2    	b.hs	0x100027568 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x92d0>
100027458: d2800008    	mov	x8, #0x0                ; =0
10002745c: 14000063    	b	0x1000275e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9350>
100027460: b40005fc    	cbz	x28, 0x10002751c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9284>
100027464: f90eebff    	str	xzr, [sp, #0x1dd0]
100027468: f90ee7ff    	str	xzr, [sp, #0x1dc8]
10002746c: f90eefff    	str	xzr, [sp, #0x1dd8]
100027470: 912683e0    	add	x0, sp, #0x9a0
100027474: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
100027478: 91372021    	add	x1, x1, #0xdc8
10002747c: aa1c03e2    	mov	x2, x28
100027480: 52800043    	mov	w3, #0x2                ; =2
100027484: 52800024    	mov	w4, #0x1                ; =1
100027488: 94002970    	bl	0x100031a48 <_list.RocList.reallocate>
10002748c: d2800008    	mov	x8, #0x0                ; =0
100027490: f944d3f6    	ldr	x22, [sp, #0x9a0]
100027494: f944dbf4    	ldr	x20, [sp, #0x9b0]
100027498: f100879f    	cmp	x28, #0x21
10002749c: 540002c3    	b.lo	0x1000274f4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x925c>
1000274a0: cb1502c9    	sub	x9, x22, x21
1000274a4: f100fd3f    	cmp	x9, #0x3f
1000274a8: 4f04a404    	movi.8h	v4, #0x80, lsl #8
1000274ac: 54000249    	b.ls	0x1000274f4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x925c>
1000274b0: f2401388    	ands	x8, x28, #0x1f
1000274b4: 52800409    	mov	w9, #0x20               ; =32
1000274b8: 9a880128    	csel	x8, x9, x8, eq
1000274bc: cb080388    	sub	x8, x28, x8
1000274c0: 910082a9    	add	x9, x21, #0x20
1000274c4: 910082ca    	add	x10, x22, #0x20
1000274c8: aa0803eb    	mov	x11, x8
1000274cc: ad7f0520    	ldp	q0, q1, [x9, #-0x20]
1000274d0: acc20d22    	ldp	q2, q3, [x9], #0x40
1000274d4: 6e642c00    	uqsub.8h	v0, v0, v4
1000274d8: 6e642c21    	uqsub.8h	v1, v1, v4
1000274dc: 6e642c42    	uqsub.8h	v2, v2, v4
1000274e0: 6e642c63    	uqsub.8h	v3, v3, v4
1000274e4: ad3f0540    	stp	q0, q1, [x10, #-0x20]
1000274e8: ac820d42    	stp	q2, q3, [x10], #0x40
1000274ec: f100816b    	subs	x11, x11, #0x20
1000274f0: 54fffee1    	b.ne	0x1000274cc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9234>
1000274f4: b100051f    	cmn	x8, #0x1
1000274f8: 54018f80    	b.eq	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000274fc: 78e87aa9    	ldrsh	w9, [x21, x8, lsl #1]
100027500: 5211012a    	eor	w10, w9, #0x8000
100027504: 0a493d49    	and	w9, w10, w9, lsr #15
100027508: 78287ac9    	strh	w9, [x22, x8, lsl #1]
10002750c: 91000508    	add	x8, x8, #0x1
100027510: eb08039f    	cmp	x28, x8
100027514: 54ffff01    	b.ne	0x1000274f4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x925c>
100027518: 14000003    	b	0x100027524 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x928c>
10002751c: d2800016    	mov	x22, #0x0               ; =0
100027520: d2800014    	mov	x20, #0x0               ; =0
100027524: f904d3f5    	str	x21, [sp, #0x9a0]
100027528: f904d7fc    	str	x28, [sp, #0x9a8]
10002752c: f941afe8    	ldr	x8, [sp, #0x358]
100027530: f904dbe8    	str	x8, [sp, #0x9b0]
100027534: 912683e0    	add	x0, sp, #0x9a0
100027538: 94002322    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002753c: f901aff4    	str	x20, [sp, #0x358]
100027540: f9419fe7    	ldr	x7, [sp, #0x338]
100027544: f941a3e3    	ldr	x3, [sp, #0x340]
100027548: f941b7e6    	ldr	x6, [sp, #0x368]
10002754c: f941b3e4    	ldr	x4, [sp, #0x360]
100027550: f94173fe    	ldr	x30, [sp, #0x2e0]
100027554: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100027558: f9419be5    	ldr	x5, [sp, #0x330]
10002755c: f941abe8    	ldr	x8, [sp, #0x350]
100027560: 370006c8    	tbnz	w8, #0x0, 0x100027638 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x93a0>
100027564: 1400002b    	b	0x100027610 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9378>
100027568: f100839f    	cmp	x28, #0x20
10002756c: 54000062    	b.hs	0x100027578 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x92e0>
100027570: d2800008    	mov	x8, #0x0                ; =0
100027574: 14000012    	b	0x1000275bc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9324>
100027578: 927e0b89    	and	x9, x28, #0x1c
10002757c: 927beb88    	and	x8, x28, #0xffffffffffffffe0
100027580: 910082aa    	add	x10, x21, #0x20
100027584: 927beb8b    	and	x11, x28, #0xffffffffffffffe0
100027588: ad7f0540    	ldp	q0, q1, [x10, #-0x20]
10002758c: ad400d42    	ldp	q2, q3, [x10]
100027590: 6e642c00    	uqsub.8h	v0, v0, v4
100027594: 6e642c21    	uqsub.8h	v1, v1, v4
100027598: 6e642c42    	uqsub.8h	v2, v2, v4
10002759c: 6e642c63    	uqsub.8h	v3, v3, v4
1000275a0: ad3f0540    	stp	q0, q1, [x10, #-0x20]
1000275a4: ac820d42    	stp	q2, q3, [x10], #0x40
1000275a8: f100816b    	subs	x11, x11, #0x20
1000275ac: 54fffee1    	b.ne	0x100027588 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x92f0>
1000275b0: eb08039f    	cmp	x28, x8
1000275b4: 54000280    	b.eq	0x100027604 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x936c>
1000275b8: b4000189    	cbz	x9, 0x1000275e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9350>
1000275bc: aa0803ea    	mov	x10, x8
1000275c0: 927ef788    	and	x8, x28, #0xfffffffffffffffc
1000275c4: cb080149    	sub	x9, x10, x8
1000275c8: 8b0a06aa    	add	x10, x21, x10, lsl #1
1000275cc: fd400140    	ldr	d0, [x10]
1000275d0: 2e682c00    	uqsub.4h	v0, v0, v8
1000275d4: fc008540    	str	d0, [x10], #0x8
1000275d8: b1001129    	adds	x9, x9, #0x4
1000275dc: 54ffff81    	b.ne	0x1000275cc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9334>
1000275e0: eb08039f    	cmp	x28, x8
1000275e4: 54000100    	b.eq	0x100027604 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x936c>
1000275e8: 78e87aa9    	ldrsh	w9, [x21, x8, lsl #1]
1000275ec: 5211012a    	eor	w10, w9, #0x8000
1000275f0: 0a493d49    	and	w9, w10, w9, lsr #15
1000275f4: 78287aa9    	strh	w9, [x21, x8, lsl #1]
1000275f8: 91000508    	add	x8, x8, #0x1
1000275fc: eb08039f    	cmp	x28, x8
100027600: 54ffff41    	b.ne	0x1000275e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9350>
100027604: aa1503f6    	mov	x22, x21
100027608: f941abe8    	ldr	x8, [sp, #0x350]
10002760c: 37000168    	tbnz	w8, #0x0, 0x100027638 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x93a0>
100027610: f941abe8    	ldr	x8, [sp, #0x350]
100027614: b4000088    	cbz	x8, 0x100027624 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x938c>
100027618: f85f8328    	ldur	x8, [x25, #-0x8]
10002761c: f100051f    	cmp	x8, #0x1
100027620: 540000c1    	b.ne	0x100027638 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x93a0>
100027624: b40008e6    	cbz	x6, 0x100027740 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x94a8>
100027628: f10010df    	cmp	x6, #0x4
10002762c: 54000942    	b.hs	0x100027754 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x94bc>
100027630: d2800008    	mov	x8, #0x0                ; =0
100027634: 14000068    	b	0x1000277d4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x953c>
100027638: b4000606    	cbz	x6, 0x1000276f8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9460>
10002763c: f90eebff    	str	xzr, [sp, #0x1dd0]
100027640: f90ee7ff    	str	xzr, [sp, #0x1dc8]
100027644: f90eefff    	str	xzr, [sp, #0x1dd8]
100027648: 912683e0    	add	x0, sp, #0x9a0
10002764c: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
100027650: 91372021    	add	x1, x1, #0xdc8
100027654: aa0603e2    	mov	x2, x6
100027658: 52800043    	mov	w3, #0x2                ; =2
10002765c: 52800024    	mov	w4, #0x1                ; =1
100027660: 940028fa    	bl	0x100031a48 <_list.RocList.reallocate>
100027664: f941b7e6    	ldr	x6, [sp, #0x368]
100027668: d2800008    	mov	x8, #0x0                ; =0
10002766c: f944d3f5    	ldr	x21, [sp, #0x9a0]
100027670: f944dbf4    	ldr	x20, [sp, #0x9b0]
100027674: f10084df    	cmp	x6, #0x21
100027678: 540002c3    	b.lo	0x1000276d0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9438>
10002767c: cb1902a9    	sub	x9, x21, x25
100027680: f100fd3f    	cmp	x9, #0x3f
100027684: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100027688: 54000249    	b.ls	0x1000276d0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9438>
10002768c: f24010c8    	ands	x8, x6, #0x1f
100027690: 52800409    	mov	w9, #0x20               ; =32
100027694: 9a880128    	csel	x8, x9, x8, eq
100027698: cb0800c8    	sub	x8, x6, x8
10002769c: 91008329    	add	x9, x25, #0x20
1000276a0: 910082aa    	add	x10, x21, #0x20
1000276a4: aa0803eb    	mov	x11, x8
1000276a8: ad7f0520    	ldp	q0, q1, [x9, #-0x20]
1000276ac: acc20d22    	ldp	q2, q3, [x9], #0x40
1000276b0: 6e642c00    	uqsub.8h	v0, v0, v4
1000276b4: 6e642c21    	uqsub.8h	v1, v1, v4
1000276b8: 6e642c42    	uqsub.8h	v2, v2, v4
1000276bc: 6e642c63    	uqsub.8h	v3, v3, v4
1000276c0: ad3f0540    	stp	q0, q1, [x10, #-0x20]
1000276c4: ac820d42    	stp	q2, q3, [x10], #0x40
1000276c8: f100816b    	subs	x11, x11, #0x20
1000276cc: 54fffee1    	b.ne	0x1000276a8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9410>
1000276d0: b100051f    	cmn	x8, #0x1
1000276d4: 540180a0    	b.eq	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000276d8: 78e87b29    	ldrsh	w9, [x25, x8, lsl #1]
1000276dc: 5211012a    	eor	w10, w9, #0x8000
1000276e0: 0a493d49    	and	w9, w10, w9, lsr #15
1000276e4: 78287aa9    	strh	w9, [x21, x8, lsl #1]
1000276e8: 91000508    	add	x8, x8, #0x1
1000276ec: eb0800df    	cmp	x6, x8
1000276f0: 54ffff01    	b.ne	0x1000276d0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9438>
1000276f4: 14000003    	b	0x100027700 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9468>
1000276f8: d2800015    	mov	x21, #0x0               ; =0
1000276fc: d2800014    	mov	x20, #0x0               ; =0
100027700: f904d3f9    	str	x25, [sp, #0x9a0]
100027704: f904d7e6    	str	x6, [sp, #0x9a8]
100027708: f941abe8    	ldr	x8, [sp, #0x350]
10002770c: f904dbe8    	str	x8, [sp, #0x9b0]
100027710: 912683e0    	add	x0, sp, #0x9a0
100027714: 940022ab    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100027718: f901abf4    	str	x20, [sp, #0x350]
10002771c: f9419fe7    	ldr	x7, [sp, #0x338]
100027720: f941a3e3    	ldr	x3, [sp, #0x340]
100027724: f941b3e4    	ldr	x4, [sp, #0x360]
100027728: f94173fe    	ldr	x30, [sp, #0x2e0]
10002772c: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100027730: f9419be5    	ldr	x5, [sp, #0x330]
100027734: f941a7e8    	ldr	x8, [sp, #0x348]
100027738: 37000788    	tbnz	w8, #0x0, 0x100027828 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9590>
10002773c: 14000030    	b	0x1000277fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9564>
100027740: f901b7ff    	str	xzr, [sp, #0x368]
100027744: aa1903f5    	mov	x21, x25
100027748: f941a7e8    	ldr	x8, [sp, #0x348]
10002774c: 370006e8    	tbnz	w8, #0x0, 0x100027828 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9590>
100027750: 1400002b    	b	0x1000277fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9564>
100027754: f10080df    	cmp	x6, #0x20
100027758: 54000062    	b.hs	0x100027764 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x94cc>
10002775c: d2800008    	mov	x8, #0x0                ; =0
100027760: 14000012    	b	0x1000277a8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9510>
100027764: 927e08c9    	and	x9, x6, #0x1c
100027768: 927be8c8    	and	x8, x6, #0xffffffffffffffe0
10002776c: 9100832a    	add	x10, x25, #0x20
100027770: 927be8cb    	and	x11, x6, #0xffffffffffffffe0
100027774: ad7f0540    	ldp	q0, q1, [x10, #-0x20]
100027778: ad400d42    	ldp	q2, q3, [x10]
10002777c: 6e642c00    	uqsub.8h	v0, v0, v4
100027780: 6e642c21    	uqsub.8h	v1, v1, v4
100027784: 6e642c42    	uqsub.8h	v2, v2, v4
100027788: 6e642c63    	uqsub.8h	v3, v3, v4
10002778c: ad3f0540    	stp	q0, q1, [x10, #-0x20]
100027790: ac820d42    	stp	q2, q3, [x10], #0x40
100027794: f100816b    	subs	x11, x11, #0x20
100027798: 54fffee1    	b.ne	0x100027774 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x94dc>
10002779c: eb0800df    	cmp	x6, x8
1000277a0: 54000280    	b.eq	0x1000277f0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9558>
1000277a4: b4000189    	cbz	x9, 0x1000277d4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x953c>
1000277a8: aa0803ea    	mov	x10, x8
1000277ac: 927ef4c8    	and	x8, x6, #0xfffffffffffffffc
1000277b0: cb080149    	sub	x9, x10, x8
1000277b4: 8b0a072a    	add	x10, x25, x10, lsl #1
1000277b8: fd400140    	ldr	d0, [x10]
1000277bc: 2e682c00    	uqsub.4h	v0, v0, v8
1000277c0: fc008540    	str	d0, [x10], #0x8
1000277c4: b1001129    	adds	x9, x9, #0x4
1000277c8: 54ffff81    	b.ne	0x1000277b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9520>
1000277cc: eb0800df    	cmp	x6, x8
1000277d0: 54000100    	b.eq	0x1000277f0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9558>
1000277d4: 78e87b29    	ldrsh	w9, [x25, x8, lsl #1]
1000277d8: 5211012a    	eor	w10, w9, #0x8000
1000277dc: 0a493d49    	and	w9, w10, w9, lsr #15
1000277e0: 78287b29    	strh	w9, [x25, x8, lsl #1]
1000277e4: 91000508    	add	x8, x8, #0x1
1000277e8: eb0800df    	cmp	x6, x8
1000277ec: 54ffff41    	b.ne	0x1000277d4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x953c>
1000277f0: aa1903f5    	mov	x21, x25
1000277f4: f941a7e8    	ldr	x8, [sp, #0x348]
1000277f8: 37000188    	tbnz	w8, #0x0, 0x100027828 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9590>
1000277fc: f941a7e8    	ldr	x8, [sp, #0x348]
100027800: b4000088    	cbz	x8, 0x100027810 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9578>
100027804: f85f8308    	ldur	x8, [x24, #-0x8]
100027808: f100051f    	cmp	x8, #0x1
10002780c: 540000e1    	b.ne	0x100027828 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9590>
100027810: f941b7e6    	ldr	x6, [sp, #0x368]
100027814: b4000e1a    	cbz	x26, 0x1000279d4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x973c>
100027818: f100135f    	cmp	x26, #0x4
10002781c: 540008e2    	b.hs	0x100027938 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x96a0>
100027820: d2800008    	mov	x8, #0x0                ; =0
100027824: 14000065    	b	0x1000279b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9720>
100027828: aa1703fb    	mov	x27, x23
10002782c: b40005fa    	cbz	x26, 0x1000278e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9650>
100027830: f90eebff    	str	xzr, [sp, #0x1dd0]
100027834: f90ee7ff    	str	xzr, [sp, #0x1dc8]
100027838: f90eefff    	str	xzr, [sp, #0x1dd8]
10002783c: 912683e0    	add	x0, sp, #0x9a0
100027840: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
100027844: 91372021    	add	x1, x1, #0xdc8
100027848: aa1a03e2    	mov	x2, x26
10002784c: 52800043    	mov	w3, #0x2                ; =2
100027850: 52800024    	mov	w4, #0x1                ; =1
100027854: 9400287d    	bl	0x100031a48 <_list.RocList.reallocate>
100027858: d2800008    	mov	x8, #0x0                ; =0
10002785c: f944d3f4    	ldr	x20, [sp, #0x9a0]
100027860: f944dbf7    	ldr	x23, [sp, #0x9b0]
100027864: f100875f    	cmp	x26, #0x21
100027868: 540002c3    	b.lo	0x1000278c0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9628>
10002786c: cb180289    	sub	x9, x20, x24
100027870: f100fd3f    	cmp	x9, #0x3f
100027874: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100027878: 54000249    	b.ls	0x1000278c0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9628>
10002787c: f2401348    	ands	x8, x26, #0x1f
100027880: 52800409    	mov	w9, #0x20               ; =32
100027884: 9a880128    	csel	x8, x9, x8, eq
100027888: cb080348    	sub	x8, x26, x8
10002788c: 91008309    	add	x9, x24, #0x20
100027890: 9100828a    	add	x10, x20, #0x20
100027894: aa0803eb    	mov	x11, x8
100027898: ad7f0520    	ldp	q0, q1, [x9, #-0x20]
10002789c: acc20d22    	ldp	q2, q3, [x9], #0x40
1000278a0: 6e642c00    	uqsub.8h	v0, v0, v4
1000278a4: 6e642c21    	uqsub.8h	v1, v1, v4
1000278a8: 6e642c42    	uqsub.8h	v2, v2, v4
1000278ac: 6e642c63    	uqsub.8h	v3, v3, v4
1000278b0: ad3f0540    	stp	q0, q1, [x10, #-0x20]
1000278b4: ac820d42    	stp	q2, q3, [x10], #0x40
1000278b8: f100816b    	subs	x11, x11, #0x20
1000278bc: 54fffee1    	b.ne	0x100027898 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9600>
1000278c0: b100051f    	cmn	x8, #0x1
1000278c4: 54017120    	b.eq	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000278c8: 78e87b09    	ldrsh	w9, [x24, x8, lsl #1]
1000278cc: 5211012a    	eor	w10, w9, #0x8000
1000278d0: 0a493d49    	and	w9, w10, w9, lsr #15
1000278d4: 78287a89    	strh	w9, [x20, x8, lsl #1]
1000278d8: 91000508    	add	x8, x8, #0x1
1000278dc: eb08035f    	cmp	x26, x8
1000278e0: 54ffff01    	b.ne	0x1000278c0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9628>
1000278e4: 14000003    	b	0x1000278f0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9658>
1000278e8: d2800014    	mov	x20, #0x0               ; =0
1000278ec: d2800017    	mov	x23, #0x0               ; =0
1000278f0: f904d3f8    	str	x24, [sp, #0x9a0]
1000278f4: f904d7fa    	str	x26, [sp, #0x9a8]
1000278f8: f941a7e8    	ldr	x8, [sp, #0x348]
1000278fc: f904dbe8    	str	x8, [sp, #0x9b0]
100027900: 912683e0    	add	x0, sp, #0x9a0
100027904: 9400222f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100027908: f901a7f7    	str	x23, [sp, #0x348]
10002790c: f9419fe7    	ldr	x7, [sp, #0x338]
100027910: f941a3e3    	ldr	x3, [sp, #0x340]
100027914: f941b7e6    	ldr	x6, [sp, #0x368]
100027918: aa1b03f7    	mov	x23, x27
10002791c: f941b3e4    	ldr	x4, [sp, #0x360]
100027920: f94173fe    	ldr	x30, [sp, #0x2e0]
100027924: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100027928: f9419be5    	ldr	x5, [sp, #0x330]
10002792c: f140239f    	cmp	x28, #0x8, lsl #12      ; =0x8000
100027930: 54000582    	b.hs	0x1000279e0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9748>
100027934: 14001795    	b	0x10002d788 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf4f0>
100027938: f100835f    	cmp	x26, #0x20
10002793c: 54000062    	b.hs	0x100027948 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x96b0>
100027940: d2800008    	mov	x8, #0x0                ; =0
100027944: 14000012    	b	0x10002798c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x96f4>
100027948: 927e0b49    	and	x9, x26, #0x1c
10002794c: 927beb48    	and	x8, x26, #0xffffffffffffffe0
100027950: 9100830a    	add	x10, x24, #0x20
100027954: 927beb4b    	and	x11, x26, #0xffffffffffffffe0
100027958: ad7f0540    	ldp	q0, q1, [x10, #-0x20]
10002795c: ad400d42    	ldp	q2, q3, [x10]
100027960: 6e642c00    	uqsub.8h	v0, v0, v4
100027964: 6e642c21    	uqsub.8h	v1, v1, v4
100027968: 6e642c42    	uqsub.8h	v2, v2, v4
10002796c: 6e642c63    	uqsub.8h	v3, v3, v4
100027970: ad3f0540    	stp	q0, q1, [x10, #-0x20]
100027974: ac820d42    	stp	q2, q3, [x10], #0x40
100027978: f100816b    	subs	x11, x11, #0x20
10002797c: 54fffee1    	b.ne	0x100027958 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x96c0>
100027980: eb08035f    	cmp	x26, x8
100027984: 54000280    	b.eq	0x1000279d4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x973c>
100027988: b4000189    	cbz	x9, 0x1000279b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9720>
10002798c: aa0803ea    	mov	x10, x8
100027990: 927ef748    	and	x8, x26, #0xfffffffffffffffc
100027994: cb080149    	sub	x9, x10, x8
100027998: 8b0a070a    	add	x10, x24, x10, lsl #1
10002799c: fd400140    	ldr	d0, [x10]
1000279a0: 2e682c00    	uqsub.4h	v0, v0, v8
1000279a4: fc008540    	str	d0, [x10], #0x8
1000279a8: b1001129    	adds	x9, x9, #0x4
1000279ac: 54ffff81    	b.ne	0x10002799c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9704>
1000279b0: eb08035f    	cmp	x26, x8
1000279b4: 54000100    	b.eq	0x1000279d4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x973c>
1000279b8: 78e87b09    	ldrsh	w9, [x24, x8, lsl #1]
1000279bc: 5211012a    	eor	w10, w9, #0x8000
1000279c0: 0a493d49    	and	w9, w10, w9, lsr #15
1000279c4: 78287b09    	strh	w9, [x24, x8, lsl #1]
1000279c8: 91000508    	add	x8, x8, #0x1
1000279cc: eb08035f    	cmp	x26, x8
1000279d0: 54ffff41    	b.ne	0x1000279b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9720>
1000279d4: aa1803f4    	mov	x20, x24
1000279d8: f140239f    	cmp	x28, #0x8, lsl #12      ; =0x8000
1000279dc: 5402ed63    	b.lo	0x10002d788 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf4f0>
1000279e0: f14040df    	cmp	x6, #0x10, lsl #12      ; =0x10000
1000279e4: 5402ed23    	b.lo	0x10002d788 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf4f0>
1000279e8: d34fff48    	lsr	x8, x26, #15
1000279ec: b402ece8    	cbz	x8, 0x10002d788 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf4f0>
1000279f0: 91402084    	add	x4, x4, #0x8, lsl #12   ; =0x8000
1000279f4: aa1403f8    	mov	x24, x20
1000279f8: aa1503f9    	mov	x25, x21
1000279fc: aa1603f5    	mov	x21, x22
100027a00: 5294f7b6    	mov	w22, #0xa7bd            ; =42941
100027a04: 72a3c6b6    	movk	w22, #0x1e35, lsl #16
100027a08: f9418ff4    	ldr	x20, [sp, #0x318]
100027a0c: f9416be8    	ldr	x8, [sp, #0x2d0]
100027a10: d100051b    	sub	x27, x8, #0x1
100027a14: f100169f    	cmp	x20, #0x5
100027a18: 540000c2    	b.hs	0x100027a30 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9798>
100027a1c: f9019bff    	str	xzr, [sp, #0x330]
100027a20: f9416be8    	ldr	x8, [sp, #0x2d0]
100027a24: eb08037f    	cmp	x27, x8
100027a28: 54001e82    	b.hs	0x100027df8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9b60>
100027a2c: 140000f8    	b	0x100027e0c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9b74>
100027a30: ab1400a8    	adds	x8, x5, x20
100027a34: 540165a2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100027a38: eb03011f    	cmp	x8, x3
100027a3c: 5402ddc8    	b.hi	0x10002d5f4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf35c>
100027a40: f9418be8    	ldr	x8, [sp, #0x310]
100027a44: 92403909    	and	x9, x8, #0x7fff
100027a48: eb1c013f    	cmp	x9, x28
100027a4c: 5401e382    	b.hs	0x10002b6bc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xd424>
100027a50: cb0400a8    	sub	x8, x5, x4
100027a54: f94183ea    	ldr	x10, [sp, #0x300]
100027a58: 92403d4a    	and	x10, x10, #0xffff
100027a5c: eb06015f    	cmp	x10, x6
100027a60: 5401efc2    	b.hs	0x10002b858 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xd5c0>
100027a64: 78697aac    	ldrh	w12, [x21, x9, lsl #1]
100027a68: 786a7b2b    	ldrh	w11, [x25, x10, lsl #1]
100027a6c: 5211410d    	eor	w13, w8, #0xffff8000
100027a70: 78297aad    	strh	w13, [x21, x9, lsl #1]
100027a74: 782a7b2d    	strh	w13, [x25, x10, lsl #1]
100027a78: 92403909    	and	x9, x8, #0x7fff
100027a7c: eb1a013f    	cmp	x9, x26
100027a80: 5401fbe2    	b.hs	0x10002b9fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xd764>
100027a84: 78297b0b    	strh	w11, [x24, x9, lsl #1]
100027a88: 8b0500e9    	add	x9, x7, x5
100027a8c: b840112a    	ldur	w10, [x9, #0x1]
100027a90: 12005d4d    	and	w13, w10, #0xffffff
100027a94: 1b167dad    	mul	w13, w13, w22
100027a98: 53117dae    	lsr	w14, w13, #17
100027a9c: 1b167d4a    	mul	w10, w10, w22
100027aa0: 53107d4d    	lsr	w13, w10, #16
100027aa4: f9018bee    	str	x14, [sp, #0x310]
100027aa8: d37f7dca    	ubfiz	x10, x14, #1, #32
100027aac: f8aa6ab0    	prfm	pstl1keep, [x21, x10]
100027ab0: f90183ed    	str	x13, [sp, #0x300]
100027ab4: d37f7daa    	ubfiz	x10, x13, #1, #32
100027ab8: f8aa6b30    	prfm	pstl1keep, [x25, x10]
100027abc: b940012a    	ldr	w10, [x9]
100027ac0: f1000f7f    	cmp	x27, #0x3
100027ac4: 54000148    	b.hi	0x100027aec <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9854>
100027ac8: aa0503ed    	mov	x13, x5
100027acc: eb0c011f    	cmp	x8, x12
100027ad0: 540018a2    	b.hs	0x100027de4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9b4c>
100027ad4: f1000f7f    	cmp	x27, #0x3
100027ad8: 54001321    	b.ne	0x100027d3c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9aa4>
100027adc: aa0503ee    	mov	x14, x5
100027ae0: eb0b011f    	cmp	x8, x11
100027ae4: 540014e3    	b.lo	0x100027d80 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9ae8>
100027ae8: 140000be    	b	0x100027de0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9b48>
100027aec: eb0b011f    	cmp	x8, x11
100027af0: 54001342    	b.hs	0x100027d58 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9ac0>
100027af4: f94133ec    	ldr	x12, [sp, #0x260]
100027af8: aa0503ed    	mov	x13, x5
100027afc: eb17037f    	cmp	x27, x23
100027b00: 54001722    	b.hs	0x100027de4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9b4c>
100027b04: eb1402ff    	cmp	x23, x20
100027b08: 540319e8    	b.hi	0x10002de44 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xfbac>
100027b0c: d140208f    	sub	x15, x4, #0x8, lsl #12  ; =0x8000
100027b10: aa0d03ee    	mov	x14, x13
100027b14: aa1b03f1    	mov	x17, x27
100027b18: f1000e20    	subs	x0, x17, #0x3
100027b1c: 54031943    	b.lo	0x10002de44 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xfbac>
100027b20: eb17023f    	cmp	x17, x23
100027b24: 54031902    	b.hs	0x10002de44 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xfbac>
100027b28: 8b11012d    	add	x13, x9, x17
100027b2c: b85fd1a1    	ldur	w1, [x13, #-0x3]
100027b30: d100058d    	sub	x13, x12, #0x1
100027b34: aa0d03ec    	mov	x12, x13
100027b38: 8b0b01ed    	add	x13, x15, x11
100027b3c: 8b0d0002    	add	x2, x0, x13
100027b40: eb1e005f    	cmp	x2, x30
100027b44: 540000a2    	b.hs	0x100027b58 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x98c0>
100027b48: b86268e2    	ldr	w2, [x7, x2]
100027b4c: 6b01005f    	cmp	w2, w1
100027b50: 540000a0    	b.eq	0x100027b64 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x98cc>
100027b54: 1400000d    	b	0x100027b88 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x98f0>
100027b58: 52800002    	mov	w2, #0x0                ; =0
100027b5c: 6b01005f    	cmp	w2, w1
100027b60: 54000141    	b.ne	0x100027b88 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x98f0>
100027b64: eb1e01bf    	cmp	x13, x30
100027b68: 540000a2    	b.hs	0x100027b7c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x98e4>
100027b6c: b86d68e2    	ldr	w2, [x7, x13]
100027b70: 6b0a005f    	cmp	w2, w10
100027b74: 540000a1    	b.ne	0x100027b88 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x98f0>
100027b78: 14000011    	b	0x100027bbc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9924>
100027b7c: 52800002    	mov	w2, #0x0                ; =0
100027b80: 6b0a005f    	cmp	w2, w10
100027b84: 540001c0    	b.eq	0x100027bbc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9924>
100027b88: 9240396b    	and	x11, x11, #0x7fff
100027b8c: eb1a017f    	cmp	x11, x26
100027b90: 540000e2    	b.hs	0x100027bac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9914>
100027b94: 786b7b0b    	ldrh	w11, [x24, x11, lsl #1]
100027b98: eb0b011f    	cmp	x8, x11
100027b9c: 54000ca2    	b.hs	0x100027d30 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9a98>
100027ba0: d100058d    	sub	x13, x12, #0x1
100027ba4: b5fffc8c    	cbnz	x12, 0x100027b34 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x989c>
100027ba8: 14000062    	b	0x100027d30 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9a98>
100027bac: d280000b    	mov	x11, #0x0               ; =0
100027bb0: eb0b011f    	cmp	x8, x11
100027bb4: 54ffff63    	b.lo	0x100027ba0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9908>
100027bb8: 1400005e    	b	0x100027d30 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9a98>
100027bbc: eb0501bf    	cmp	x13, x5
100027bc0: 54026642    	b.hs	0x10002c888 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe5f0>
100027bc4: f100929f    	cmp	x20, #0x24
100027bc8: 54000222    	b.hs	0x100027c0c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9974>
100027bcc: 8b0400f0    	add	x16, x7, x4
100027bd0: 5280009b    	mov	w27, #0x4               ; =4
100027bd4: b27d0361    	orr	x1, x27, #0x8
100027bd8: 8b0b0200    	add	x0, x16, x11
100027bdc: eb14003f    	cmp	x1, x20
100027be0: 540003e8    	b.hi	0x100027c5c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x99c4>
100027be4: f87b6921    	ldr	x1, [x9, x27]
100027be8: 8b1b0002    	add	x2, x0, x27
100027bec: 928fffe3    	mov	x3, #-0x8000            ; =-32768
100027bf0: f8636842    	ldr	x2, [x2, x3]
100027bf4: eb01005f    	cmp	x2, x1
100027bf8: 54000501    	b.ne	0x100027c98 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9a00>
100027bfc: b1004361    	adds	x1, x27, #0x10
100027c00: 9100237b    	add	x27, x27, #0x8
100027c04: 54fffec3    	b.lo	0x100027bdc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9944>
100027c08: 14000ab8    	b	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100027c0c: 8b0d00e2    	add	x2, x7, x13
100027c10: f8404120    	ldur	x0, [x9, #0x4]
100027c14: f8404041    	ldur	x1, [x2, #0x4]
100027c18: eb00003f    	cmp	x1, x0
100027c1c: 540004a1    	b.ne	0x100027cb0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9a18>
100027c20: f840c120    	ldur	x0, [x9, #0xc]
100027c24: f840c041    	ldur	x1, [x2, #0xc]
100027c28: eb00003f    	cmp	x1, x0
100027c2c: 540004a1    	b.ne	0x100027cc0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9a28>
100027c30: f8414120    	ldur	x0, [x9, #0x14]
100027c34: f8414041    	ldur	x1, [x2, #0x14]
100027c38: eb00003f    	cmp	x1, x0
100027c3c: 54000461    	b.ne	0x100027cc8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9a30>
100027c40: f841c120    	ldur	x0, [x9, #0x1c]
100027c44: f841c041    	ldur	x1, [x2, #0x1c]
100027c48: eb00003f    	cmp	x1, x0
100027c4c: 54000421    	b.ne	0x100027cd0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9a38>
100027c50: 8b0400f0    	add	x16, x7, x4
100027c54: 5280049b    	mov	w27, #0x24              ; =36
100027c58: 17ffffdf    	b	0x100027bd4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x993c>
100027c5c: eb14037f    	cmp	x27, x20
100027c60: 540002c2    	b.hs	0x100027cb8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9a20>
100027c64: 8b0b0200    	add	x0, x16, x11
100027c68: 387b6921    	ldrb	w1, [x9, x27]
100027c6c: 8b1b0002    	add	x2, x0, x27
100027c70: 928fffe3    	mov	x3, #-0x8000            ; =-32768
100027c74: 38636842    	ldrb	w2, [x2, x3]
100027c78: 6b02003f    	cmp	w1, w2
100027c7c: 540001e1    	b.ne	0x100027cb8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9a20>
100027c80: 9100077b    	add	x27, x27, #0x1
100027c84: eb1b029f    	cmp	x20, x27
100027c88: 54ffff01    	b.ne	0x100027c68 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x99d0>
100027c8c: aa1403fb    	mov	x27, x20
100027c90: f941a3e3    	ldr	x3, [sp, #0x340]
100027c94: 14000014    	b	0x100027ce4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9a4c>
100027c98: ca010040    	eor	x0, x2, x1
100027c9c: dac00000    	rbit	x0, x0
100027ca0: dac01000    	clz	x0, x0
100027ca4: 8b400f7b    	add	x27, x27, x0, lsr #3
100027ca8: f941a3e3    	ldr	x3, [sp, #0x340]
100027cac: 1400000e    	b	0x100027ce4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9a4c>
100027cb0: 52800082    	mov	w2, #0x4                ; =4
100027cb4: 14000008    	b	0x100027cd4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9a3c>
100027cb8: f941a3e3    	ldr	x3, [sp, #0x340]
100027cbc: 1400000a    	b	0x100027ce4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9a4c>
100027cc0: 52800182    	mov	w2, #0xc                ; =12
100027cc4: 14000004    	b	0x100027cd4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9a3c>
100027cc8: 52800282    	mov	w2, #0x14               ; =20
100027ccc: 14000002    	b	0x100027cd4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9a3c>
100027cd0: 52800382    	mov	w2, #0x1c               ; =28
100027cd4: ca000020    	eor	x0, x1, x0
100027cd8: dac00000    	rbit	x0, x0
100027cdc: dac01000    	clz	x0, x0
100027ce0: 8b400c5b    	add	x27, x2, x0, lsr #3
100027ce4: eb11037f    	cmp	x27, x17
100027ce8: 540000a9    	b.ls	0x100027cfc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9a64>
100027cec: 8b0b01ee    	add	x14, x15, x11
100027cf0: aa1b03f1    	mov	x17, x27
100027cf4: eb17037f    	cmp	x27, x23
100027cf8: 54000762    	b.hs	0x100027de4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9b4c>
100027cfc: 9240396b    	and	x11, x11, #0x7fff
100027d00: eb0b035f    	cmp	x26, x11
100027d04: 54000109    	b.ls	0x100027d24 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9a8c>
100027d08: 786b7b0b    	ldrh	w11, [x24, x11, lsl #1]
100027d0c: eb0b011f    	cmp	x8, x11
100027d10: 54000102    	b.hs	0x100027d30 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9a98>
100027d14: aa1103fb    	mov	x27, x17
100027d18: aa0e03ed    	mov	x13, x14
100027d1c: b5ffefec    	cbnz	x12, 0x100027b18 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9880>
100027d20: 14000031    	b	0x100027de4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9b4c>
100027d24: d280000b    	mov	x11, #0x0               ; =0
100027d28: eb0b011f    	cmp	x8, x11
100027d2c: 54ffff43    	b.lo	0x100027d14 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9a7c>
100027d30: aa1103fb    	mov	x27, x17
100027d34: aa0e03ed    	mov	x13, x14
100027d38: 1400002b    	b	0x100027de4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9b4c>
100027d3c: 8b0c008c    	add	x12, x4, x12
100027d40: d140218c    	sub	x12, x12, #0x8, lsl #12 ; =0x8000
100027d44: eb1e019f    	cmp	x12, x30
100027d48: 540000c2    	b.hs	0x100027d60 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9ac8>
100027d4c: b86c68ed    	ldr	w13, [x7, x12]
100027d50: 12005dad    	and	w13, w13, #0xffffff
100027d54: 14000004    	b	0x100027d64 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9acc>
100027d58: aa0503ed    	mov	x13, x5
100027d5c: 14000022    	b	0x100027de4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9b4c>
100027d60: 5280000d    	mov	w13, #0x0               ; =0
100027d64: 12005d4e    	and	w14, w10, #0xffffff
100027d68: 6b0e01bf    	cmp	w13, w14
100027d6c: 5280006d    	mov	w13, #0x3               ; =3
100027d70: 9a9b01bb    	csel	x27, x13, x27, eq
100027d74: 9a85018e    	csel	x14, x12, x5, eq
100027d78: eb0b011f    	cmp	x8, x11
100027d7c: 54000322    	b.hs	0x100027de0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9b48>
100027d80: d140208f    	sub	x15, x4, #0x8, lsl #12  ; =0x8000
100027d84: f94133ec    	ldr	x12, [sp, #0x260]
100027d88: d100058d    	sub	x13, x12, #0x1
100027d8c: aa0d03ec    	mov	x12, x13
100027d90: 8b0b01ed    	add	x13, x15, x11
100027d94: eb1e01bf    	cmp	x13, x30
100027d98: 54000062    	b.hs	0x100027da4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9b0c>
100027d9c: b86d68f0    	ldr	w16, [x7, x13]
100027da0: 14000002    	b	0x100027da8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9b10>
100027da4: 52800010    	mov	w16, #0x0               ; =0
100027da8: 6b0a021f    	cmp	w16, w10
100027dac: 5400e460    	b.eq	0x100029a38 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb7a0>
100027db0: 9240396b    	and	x11, x11, #0x7fff
100027db4: eb1a017f    	cmp	x11, x26
100027db8: 540000e2    	b.hs	0x100027dd4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9b3c>
100027dbc: 786b7b0b    	ldrh	w11, [x24, x11, lsl #1]
100027dc0: eb0b011f    	cmp	x8, x11
100027dc4: 540000e2    	b.hs	0x100027de0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9b48>
100027dc8: d100058d    	sub	x13, x12, #0x1
100027dcc: b5fffe0c    	cbnz	x12, 0x100027d8c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9af4>
100027dd0: 14000004    	b	0x100027de0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9b48>
100027dd4: d280000b    	mov	x11, #0x0               ; =0
100027dd8: eb0b011f    	cmp	x8, x11
100027ddc: 54ffff63    	b.lo	0x100027dc8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9b30>
100027de0: aa0e03ed    	mov	x13, x14
100027de4: cb0d00a8    	sub	x8, x5, x13
100027de8: f9019be8    	str	x8, [sp, #0x330]
100027dec: f9416be8    	ldr	x8, [sp, #0x2d0]
100027df0: eb08037f    	cmp	x27, x8
100027df4: 540000c3    	b.lo	0x100027e0c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9b74>
100027df8: f1000f7f    	cmp	x27, #0x3
100027dfc: 540005a1    	b.ne	0x100027eb0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9c18>
100027e00: f9419be8    	ldr	x8, [sp, #0x330]
100027e04: f140091f    	cmp	x8, #0x2, lsl #12       ; =0x2000
100027e08: 54000549    	b.ls	0x100027eb0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9c18>
100027e0c: eb05007f    	cmp	x3, x5
100027e10: 5400ec49    	b.ls	0x100029b98 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb900>
100027e14: 386568e8    	ldrb	w8, [x7, x5]
100027e18: f9414bf1    	ldr	x17, [sp, #0x290]
100027e1c: f9414ffb    	ldr	x27, [sp, #0x298]
100027e20: b8687a69    	ldr	w9, [x19, x8, lsl #2]
100027e24: 11000529    	add	w9, w9, #0x1
100027e28: b8287a69    	str	w9, [x19, x8, lsl #2]
100027e2c: d3461d09    	ubfx	x9, x8, #6, #2
100027e30: 92400108    	and	x8, x8, #0x1
100027e34: aa090508    	orr	x8, x8, x9, lsl #1
100027e38: 8b080a68    	add	x8, x19, x8, lsl #2
100027e3c: b9480509    	ldr	w9, [x8, #0x804]
100027e40: 11000529    	add	w9, w9, #0x1
100027e44: b9080509    	str	w9, [x8, #0x804]
100027e48: b94323e8    	ldr	w8, [sp, #0x320]
100027e4c: 11000508    	add	w8, w8, #0x1
100027e50: b90323e8    	str	w8, [sp, #0x320]
100027e54: 910004a5    	add	x5, x5, #0x1
100027e58: f94153e8    	ldr	x8, [sp, #0x2a0]
100027e5c: eb0800bf    	cmp	x5, x8
100027e60: 54011542    	b.hs	0x10002a108 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xbe70>
100027e64: f9415fe8    	ldr	x8, [sp, #0x2b8]
100027e68: d344fd08    	lsr	x8, x8, #4
100027e6c: f130d11f    	cmp	x8, #0xc34
100027e70: 540114c8    	b.hi	0x10002a108 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xbe70>
100027e74: f94197e8    	ldr	x8, [sp, #0x328]
100027e78: 91000508    	add	x8, x8, #0x1
100027e7c: f90197e8    	str	x8, [sp, #0x328]
100027e80: f108011f    	cmp	x8, #0x200
100027e84: 54ffa6a3    	b.lo	0x100027358 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x90c0>
100027e88: f94157e8    	ldr	x8, [sp, #0x2a8]
100027e8c: cb0800a8    	sub	x8, x5, x8
100027e90: d343fd09    	lsr	x9, x8, #3
100027e94: f109c53f    	cmp	x9, #0x271
100027e98: 54ffa603    	b.lo	0x100027358 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x90c0>
100027e9c: cb050069    	sub	x9, x3, x5
100027ea0: d343fd29    	lsr	x9, x9, #3
100027ea4: f109c53f    	cmp	x9, #0x271
100027ea8: 54ffa583    	b.lo	0x100027358 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x90c0>
100027eac: 14000782    	b	0x100029cb4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xba1c>
100027eb0: 910004a1    	add	x1, x5, #0x1
100027eb4: eb17037f    	cmp	x27, x23
100027eb8: 5400c342    	b.hs	0x100029720 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb488>
100027ebc: cb010068    	sub	x8, x3, x1
100027ec0: eb0802ff    	cmp	x23, x8
100027ec4: 9a8832e9    	csel	x9, x23, x8, lo
100027ec8: f104091f    	cmp	x8, #0x102
100027ecc: 9a943114    	csel	x20, x8, x20, lo
100027ed0: 9a973137    	csel	x23, x9, x23, lo
100027ed4: cb040028    	sub	x8, x1, x4
100027ed8: f140211f    	cmp	x8, #0x8, lsl #12       ; =0x8000
100027edc: f90187e1    	str	x1, [sp, #0x308]
100027ee0: 54002f61    	b.ne	0x1000284cc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa234>
100027ee4: f901b7e6    	str	x6, [sp, #0x368]
100027ee8: f941afe8    	ldr	x8, [sp, #0x358]
100027eec: f901b3e4    	str	x4, [sp, #0x360]
100027ef0: f9018ff4    	str	x20, [sp, #0x318]
100027ef4: 37000168    	tbnz	w8, #0x0, 0x100027f20 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9c88>
100027ef8: f941afe8    	ldr	x8, [sp, #0x358]
100027efc: b4000088    	cbz	x8, 0x100027f0c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9c74>
100027f00: f85f82a8    	ldur	x8, [x21, #-0x8]
100027f04: f100051f    	cmp	x8, #0x1
100027f08: 540000c1    	b.ne	0x100027f20 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9c88>
100027f0c: b4000ddc    	cbz	x28, 0x1000280c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9e2c>
100027f10: f100139f    	cmp	x28, #0x4
100027f14: 540008a2    	b.hs	0x100028028 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9d90>
100027f18: d2800008    	mov	x8, #0x0                ; =0
100027f1c: 14000063    	b	0x1000280a8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9e10>
100027f20: b40005fc    	cbz	x28, 0x100027fdc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9d44>
100027f24: f90eebff    	str	xzr, [sp, #0x1dd0]
100027f28: f90ee7ff    	str	xzr, [sp, #0x1dc8]
100027f2c: f90eefff    	str	xzr, [sp, #0x1dd8]
100027f30: 912683e0    	add	x0, sp, #0x9a0
100027f34: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
100027f38: 91372021    	add	x1, x1, #0xdc8
100027f3c: aa1c03e2    	mov	x2, x28
100027f40: 52800043    	mov	w3, #0x2                ; =2
100027f44: 52800024    	mov	w4, #0x1                ; =1
100027f48: 940026c0    	bl	0x100031a48 <_list.RocList.reallocate>
100027f4c: d2800008    	mov	x8, #0x0                ; =0
100027f50: f944d3f6    	ldr	x22, [sp, #0x9a0]
100027f54: f944dbf4    	ldr	x20, [sp, #0x9b0]
100027f58: f100879f    	cmp	x28, #0x21
100027f5c: 540002c3    	b.lo	0x100027fb4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9d1c>
100027f60: cb1502c9    	sub	x9, x22, x21
100027f64: f100fd3f    	cmp	x9, #0x3f
100027f68: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100027f6c: 54000249    	b.ls	0x100027fb4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9d1c>
100027f70: f2401388    	ands	x8, x28, #0x1f
100027f74: 52800409    	mov	w9, #0x20               ; =32
100027f78: 9a880128    	csel	x8, x9, x8, eq
100027f7c: cb080388    	sub	x8, x28, x8
100027f80: 910082a9    	add	x9, x21, #0x20
100027f84: 910082ca    	add	x10, x22, #0x20
100027f88: aa0803eb    	mov	x11, x8
100027f8c: ad7f0520    	ldp	q0, q1, [x9, #-0x20]
100027f90: acc20d22    	ldp	q2, q3, [x9], #0x40
100027f94: 6e642c00    	uqsub.8h	v0, v0, v4
100027f98: 6e642c21    	uqsub.8h	v1, v1, v4
100027f9c: 6e642c42    	uqsub.8h	v2, v2, v4
100027fa0: 6e642c63    	uqsub.8h	v3, v3, v4
100027fa4: ad3f0540    	stp	q0, q1, [x10, #-0x20]
100027fa8: ac820d42    	stp	q2, q3, [x10], #0x40
100027fac: f100816b    	subs	x11, x11, #0x20
100027fb0: 54fffee1    	b.ne	0x100027f8c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9cf4>
100027fb4: b100051f    	cmn	x8, #0x1
100027fb8: 54013980    	b.eq	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100027fbc: 78e87aa9    	ldrsh	w9, [x21, x8, lsl #1]
100027fc0: 5211012a    	eor	w10, w9, #0x8000
100027fc4: 0a493d49    	and	w9, w10, w9, lsr #15
100027fc8: 78287ac9    	strh	w9, [x22, x8, lsl #1]
100027fcc: 91000508    	add	x8, x8, #0x1
100027fd0: eb08039f    	cmp	x28, x8
100027fd4: 54ffff01    	b.ne	0x100027fb4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9d1c>
100027fd8: 14000003    	b	0x100027fe4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9d4c>
100027fdc: d2800016    	mov	x22, #0x0               ; =0
100027fe0: d2800014    	mov	x20, #0x0               ; =0
100027fe4: f904d3f5    	str	x21, [sp, #0x9a0]
100027fe8: f904d7fc    	str	x28, [sp, #0x9a8]
100027fec: f941afe8    	ldr	x8, [sp, #0x358]
100027ff0: f904dbe8    	str	x8, [sp, #0x9b0]
100027ff4: 912683e0    	add	x0, sp, #0x9a0
100027ff8: 94002072    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100027ffc: f901aff4    	str	x20, [sp, #0x358]
100028000: f9419fe7    	ldr	x7, [sp, #0x338]
100028004: f941a3e3    	ldr	x3, [sp, #0x340]
100028008: f941b7e6    	ldr	x6, [sp, #0x368]
10002800c: f941b3e4    	ldr	x4, [sp, #0x360]
100028010: f94173fe    	ldr	x30, [sp, #0x2e0]
100028014: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100028018: f94187e1    	ldr	x1, [sp, #0x308]
10002801c: f941abe8    	ldr	x8, [sp, #0x350]
100028020: 370006c8    	tbnz	w8, #0x0, 0x1000280f8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9e60>
100028024: 1400002b    	b	0x1000280d0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9e38>
100028028: f100839f    	cmp	x28, #0x20
10002802c: 54000062    	b.hs	0x100028038 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9da0>
100028030: d2800008    	mov	x8, #0x0                ; =0
100028034: 14000012    	b	0x10002807c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9de4>
100028038: 927e0b89    	and	x9, x28, #0x1c
10002803c: 927beb88    	and	x8, x28, #0xffffffffffffffe0
100028040: 910082aa    	add	x10, x21, #0x20
100028044: 927beb8b    	and	x11, x28, #0xffffffffffffffe0
100028048: ad7f0540    	ldp	q0, q1, [x10, #-0x20]
10002804c: ad400d42    	ldp	q2, q3, [x10]
100028050: 6e642c00    	uqsub.8h	v0, v0, v4
100028054: 6e642c21    	uqsub.8h	v1, v1, v4
100028058: 6e642c42    	uqsub.8h	v2, v2, v4
10002805c: 6e642c63    	uqsub.8h	v3, v3, v4
100028060: ad3f0540    	stp	q0, q1, [x10, #-0x20]
100028064: ac820d42    	stp	q2, q3, [x10], #0x40
100028068: f100816b    	subs	x11, x11, #0x20
10002806c: 54fffee1    	b.ne	0x100028048 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9db0>
100028070: eb08039f    	cmp	x28, x8
100028074: 54000280    	b.eq	0x1000280c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9e2c>
100028078: b4000189    	cbz	x9, 0x1000280a8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9e10>
10002807c: aa0803ea    	mov	x10, x8
100028080: 927ef788    	and	x8, x28, #0xfffffffffffffffc
100028084: cb080149    	sub	x9, x10, x8
100028088: 8b0a06aa    	add	x10, x21, x10, lsl #1
10002808c: fd400140    	ldr	d0, [x10]
100028090: 2e682c00    	uqsub.4h	v0, v0, v8
100028094: fc008540    	str	d0, [x10], #0x8
100028098: b1001129    	adds	x9, x9, #0x4
10002809c: 54ffff81    	b.ne	0x10002808c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9df4>
1000280a0: eb08039f    	cmp	x28, x8
1000280a4: 54000100    	b.eq	0x1000280c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9e2c>
1000280a8: 78e87aa9    	ldrsh	w9, [x21, x8, lsl #1]
1000280ac: 5211012a    	eor	w10, w9, #0x8000
1000280b0: 0a493d49    	and	w9, w10, w9, lsr #15
1000280b4: 78287aa9    	strh	w9, [x21, x8, lsl #1]
1000280b8: 91000508    	add	x8, x8, #0x1
1000280bc: eb08039f    	cmp	x28, x8
1000280c0: 54ffff41    	b.ne	0x1000280a8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9e10>
1000280c4: aa1503f6    	mov	x22, x21
1000280c8: f941abe8    	ldr	x8, [sp, #0x350]
1000280cc: 37000168    	tbnz	w8, #0x0, 0x1000280f8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9e60>
1000280d0: f941abe8    	ldr	x8, [sp, #0x350]
1000280d4: b4000088    	cbz	x8, 0x1000280e4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9e4c>
1000280d8: f85f8328    	ldur	x8, [x25, #-0x8]
1000280dc: f100051f    	cmp	x8, #0x1
1000280e0: 540000c1    	b.ne	0x1000280f8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9e60>
1000280e4: b40008e6    	cbz	x6, 0x100028200 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9f68>
1000280e8: f10010df    	cmp	x6, #0x4
1000280ec: 54000942    	b.hs	0x100028214 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9f7c>
1000280f0: d2800008    	mov	x8, #0x0                ; =0
1000280f4: 14000068    	b	0x100028294 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9ffc>
1000280f8: b4000606    	cbz	x6, 0x1000281b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9f20>
1000280fc: f90eebff    	str	xzr, [sp, #0x1dd0]
100028100: f90ee7ff    	str	xzr, [sp, #0x1dc8]
100028104: f90eefff    	str	xzr, [sp, #0x1dd8]
100028108: 912683e0    	add	x0, sp, #0x9a0
10002810c: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
100028110: 91372021    	add	x1, x1, #0xdc8
100028114: aa0603e2    	mov	x2, x6
100028118: 52800043    	mov	w3, #0x2                ; =2
10002811c: 52800024    	mov	w4, #0x1                ; =1
100028120: 9400264a    	bl	0x100031a48 <_list.RocList.reallocate>
100028124: f941b7e6    	ldr	x6, [sp, #0x368]
100028128: d2800008    	mov	x8, #0x0                ; =0
10002812c: f944d3f5    	ldr	x21, [sp, #0x9a0]
100028130: f944dbf4    	ldr	x20, [sp, #0x9b0]
100028134: f10084df    	cmp	x6, #0x21
100028138: 540002c3    	b.lo	0x100028190 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9ef8>
10002813c: cb1902a9    	sub	x9, x21, x25
100028140: f100fd3f    	cmp	x9, #0x3f
100028144: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100028148: 54000249    	b.ls	0x100028190 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9ef8>
10002814c: f24010c8    	ands	x8, x6, #0x1f
100028150: 52800409    	mov	w9, #0x20               ; =32
100028154: 9a880128    	csel	x8, x9, x8, eq
100028158: cb0800c8    	sub	x8, x6, x8
10002815c: 91008329    	add	x9, x25, #0x20
100028160: 910082aa    	add	x10, x21, #0x20
100028164: aa0803eb    	mov	x11, x8
100028168: ad7f0520    	ldp	q0, q1, [x9, #-0x20]
10002816c: acc20d22    	ldp	q2, q3, [x9], #0x40
100028170: 6e642c00    	uqsub.8h	v0, v0, v4
100028174: 6e642c21    	uqsub.8h	v1, v1, v4
100028178: 6e642c42    	uqsub.8h	v2, v2, v4
10002817c: 6e642c63    	uqsub.8h	v3, v3, v4
100028180: ad3f0540    	stp	q0, q1, [x10, #-0x20]
100028184: ac820d42    	stp	q2, q3, [x10], #0x40
100028188: f100816b    	subs	x11, x11, #0x20
10002818c: 54fffee1    	b.ne	0x100028168 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9ed0>
100028190: b100051f    	cmn	x8, #0x1
100028194: 54012aa0    	b.eq	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100028198: 78e87b29    	ldrsh	w9, [x25, x8, lsl #1]
10002819c: 5211012a    	eor	w10, w9, #0x8000
1000281a0: 0a493d49    	and	w9, w10, w9, lsr #15
1000281a4: 78287aa9    	strh	w9, [x21, x8, lsl #1]
1000281a8: 91000508    	add	x8, x8, #0x1
1000281ac: eb0800df    	cmp	x6, x8
1000281b0: 54ffff01    	b.ne	0x100028190 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9ef8>
1000281b4: 14000003    	b	0x1000281c0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9f28>
1000281b8: d2800015    	mov	x21, #0x0               ; =0
1000281bc: d2800014    	mov	x20, #0x0               ; =0
1000281c0: f904d3f9    	str	x25, [sp, #0x9a0]
1000281c4: f904d7e6    	str	x6, [sp, #0x9a8]
1000281c8: f941abe8    	ldr	x8, [sp, #0x350]
1000281cc: f904dbe8    	str	x8, [sp, #0x9b0]
1000281d0: 912683e0    	add	x0, sp, #0x9a0
1000281d4: 94001ffb    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000281d8: f901abf4    	str	x20, [sp, #0x350]
1000281dc: f9419fe7    	ldr	x7, [sp, #0x338]
1000281e0: f941a3e3    	ldr	x3, [sp, #0x340]
1000281e4: f941b3e4    	ldr	x4, [sp, #0x360]
1000281e8: f94173fe    	ldr	x30, [sp, #0x2e0]
1000281ec: 4f04a404    	movi.8h	v4, #0x80, lsl #8
1000281f0: f94187e1    	ldr	x1, [sp, #0x308]
1000281f4: f941a7e8    	ldr	x8, [sp, #0x348]
1000281f8: 37000788    	tbnz	w8, #0x0, 0x1000282e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa050>
1000281fc: 14000030    	b	0x1000282bc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa024>
100028200: f901b7ff    	str	xzr, [sp, #0x368]
100028204: aa1903f5    	mov	x21, x25
100028208: f941a7e8    	ldr	x8, [sp, #0x348]
10002820c: 370006e8    	tbnz	w8, #0x0, 0x1000282e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa050>
100028210: 1400002b    	b	0x1000282bc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa024>
100028214: f10080df    	cmp	x6, #0x20
100028218: 54000062    	b.hs	0x100028224 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9f8c>
10002821c: d2800008    	mov	x8, #0x0                ; =0
100028220: 14000012    	b	0x100028268 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9fd0>
100028224: 927e08c9    	and	x9, x6, #0x1c
100028228: 927be8c8    	and	x8, x6, #0xffffffffffffffe0
10002822c: 9100832a    	add	x10, x25, #0x20
100028230: 927be8cb    	and	x11, x6, #0xffffffffffffffe0
100028234: ad7f0540    	ldp	q0, q1, [x10, #-0x20]
100028238: ad400d42    	ldp	q2, q3, [x10]
10002823c: 6e642c00    	uqsub.8h	v0, v0, v4
100028240: 6e642c21    	uqsub.8h	v1, v1, v4
100028244: 6e642c42    	uqsub.8h	v2, v2, v4
100028248: 6e642c63    	uqsub.8h	v3, v3, v4
10002824c: ad3f0540    	stp	q0, q1, [x10, #-0x20]
100028250: ac820d42    	stp	q2, q3, [x10], #0x40
100028254: f100816b    	subs	x11, x11, #0x20
100028258: 54fffee1    	b.ne	0x100028234 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9f9c>
10002825c: eb0800df    	cmp	x6, x8
100028260: 54000280    	b.eq	0x1000282b0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa018>
100028264: b4000189    	cbz	x9, 0x100028294 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9ffc>
100028268: aa0803ea    	mov	x10, x8
10002826c: 927ef4c8    	and	x8, x6, #0xfffffffffffffffc
100028270: cb080149    	sub	x9, x10, x8
100028274: 8b0a072a    	add	x10, x25, x10, lsl #1
100028278: fd400140    	ldr	d0, [x10]
10002827c: 2e682c00    	uqsub.4h	v0, v0, v8
100028280: fc008540    	str	d0, [x10], #0x8
100028284: b1001129    	adds	x9, x9, #0x4
100028288: 54ffff81    	b.ne	0x100028278 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9fe0>
10002828c: eb0800df    	cmp	x6, x8
100028290: 54000100    	b.eq	0x1000282b0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa018>
100028294: 78e87b29    	ldrsh	w9, [x25, x8, lsl #1]
100028298: 5211012a    	eor	w10, w9, #0x8000
10002829c: 0a493d49    	and	w9, w10, w9, lsr #15
1000282a0: 78287b29    	strh	w9, [x25, x8, lsl #1]
1000282a4: 91000508    	add	x8, x8, #0x1
1000282a8: eb0800df    	cmp	x6, x8
1000282ac: 54ffff41    	b.ne	0x100028294 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9ffc>
1000282b0: aa1903f5    	mov	x21, x25
1000282b4: f941a7e8    	ldr	x8, [sp, #0x348]
1000282b8: 37000188    	tbnz	w8, #0x0, 0x1000282e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa050>
1000282bc: f941a7e8    	ldr	x8, [sp, #0x348]
1000282c0: b4000088    	cbz	x8, 0x1000282d0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa038>
1000282c4: f85f8308    	ldur	x8, [x24, #-0x8]
1000282c8: f100051f    	cmp	x8, #0x1
1000282cc: 540000e1    	b.ne	0x1000282e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa050>
1000282d0: f941b7e6    	ldr	x6, [sp, #0x368]
1000282d4: b4000e1a    	cbz	x26, 0x100028494 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa1fc>
1000282d8: f100135f    	cmp	x26, #0x4
1000282dc: 540008e2    	b.hs	0x1000283f8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa160>
1000282e0: d2800008    	mov	x8, #0x0                ; =0
1000282e4: 14000065    	b	0x100028478 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa1e0>
1000282e8: f9015bf7    	str	x23, [sp, #0x2b0]
1000282ec: b40005fa    	cbz	x26, 0x1000283a8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa110>
1000282f0: f90eebff    	str	xzr, [sp, #0x1dd0]
1000282f4: f90ee7ff    	str	xzr, [sp, #0x1dc8]
1000282f8: f90eefff    	str	xzr, [sp, #0x1dd8]
1000282fc: 912683e0    	add	x0, sp, #0x9a0
100028300: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
100028304: 91372021    	add	x1, x1, #0xdc8
100028308: aa1a03e2    	mov	x2, x26
10002830c: 52800043    	mov	w3, #0x2                ; =2
100028310: 52800024    	mov	w4, #0x1                ; =1
100028314: 940025cd    	bl	0x100031a48 <_list.RocList.reallocate>
100028318: d2800008    	mov	x8, #0x0                ; =0
10002831c: f944d3f4    	ldr	x20, [sp, #0x9a0]
100028320: f944dbf7    	ldr	x23, [sp, #0x9b0]
100028324: f100875f    	cmp	x26, #0x21
100028328: 540002c3    	b.lo	0x100028380 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa0e8>
10002832c: cb180289    	sub	x9, x20, x24
100028330: f100fd3f    	cmp	x9, #0x3f
100028334: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100028338: 54000249    	b.ls	0x100028380 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa0e8>
10002833c: f2401348    	ands	x8, x26, #0x1f
100028340: 52800409    	mov	w9, #0x20               ; =32
100028344: 9a880128    	csel	x8, x9, x8, eq
100028348: cb080348    	sub	x8, x26, x8
10002834c: 91008309    	add	x9, x24, #0x20
100028350: 9100828a    	add	x10, x20, #0x20
100028354: aa0803eb    	mov	x11, x8
100028358: ad7f0520    	ldp	q0, q1, [x9, #-0x20]
10002835c: acc20d22    	ldp	q2, q3, [x9], #0x40
100028360: 6e642c00    	uqsub.8h	v0, v0, v4
100028364: 6e642c21    	uqsub.8h	v1, v1, v4
100028368: 6e642c42    	uqsub.8h	v2, v2, v4
10002836c: 6e642c63    	uqsub.8h	v3, v3, v4
100028370: ad3f0540    	stp	q0, q1, [x10, #-0x20]
100028374: ac820d42    	stp	q2, q3, [x10], #0x40
100028378: f100816b    	subs	x11, x11, #0x20
10002837c: 54fffee1    	b.ne	0x100028358 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa0c0>
100028380: b100051f    	cmn	x8, #0x1
100028384: 54011b20    	b.eq	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100028388: 78e87b09    	ldrsh	w9, [x24, x8, lsl #1]
10002838c: 5211012a    	eor	w10, w9, #0x8000
100028390: 0a493d49    	and	w9, w10, w9, lsr #15
100028394: 78287a89    	strh	w9, [x20, x8, lsl #1]
100028398: 91000508    	add	x8, x8, #0x1
10002839c: eb08035f    	cmp	x26, x8
1000283a0: 54ffff01    	b.ne	0x100028380 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa0e8>
1000283a4: 14000003    	b	0x1000283b0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa118>
1000283a8: d2800014    	mov	x20, #0x0               ; =0
1000283ac: d2800017    	mov	x23, #0x0               ; =0
1000283b0: f904d3f8    	str	x24, [sp, #0x9a0]
1000283b4: f904d7fa    	str	x26, [sp, #0x9a8]
1000283b8: f941a7e8    	ldr	x8, [sp, #0x348]
1000283bc: f904dbe8    	str	x8, [sp, #0x9b0]
1000283c0: 912683e0    	add	x0, sp, #0x9a0
1000283c4: 94001f7f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
1000283c8: f901a7f7    	str	x23, [sp, #0x348]
1000283cc: f9419fe7    	ldr	x7, [sp, #0x338]
1000283d0: f941a3e3    	ldr	x3, [sp, #0x340]
1000283d4: f941b7e6    	ldr	x6, [sp, #0x368]
1000283d8: f9415bf7    	ldr	x23, [sp, #0x2b0]
1000283dc: f941b3e4    	ldr	x4, [sp, #0x360]
1000283e0: f94173fe    	ldr	x30, [sp, #0x2e0]
1000283e4: 4f04a404    	movi.8h	v4, #0x80, lsl #8
1000283e8: f94187e1    	ldr	x1, [sp, #0x308]
1000283ec: f140239f    	cmp	x28, #0x8, lsl #12      ; =0x8000
1000283f0: 54000582    	b.hs	0x1000284a0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa208>
1000283f4: 1400141b    	b	0x10002d460 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf1c8>
1000283f8: f100835f    	cmp	x26, #0x20
1000283fc: 54000062    	b.hs	0x100028408 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa170>
100028400: d2800008    	mov	x8, #0x0                ; =0
100028404: 14000012    	b	0x10002844c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa1b4>
100028408: 927e0b49    	and	x9, x26, #0x1c
10002840c: 927beb48    	and	x8, x26, #0xffffffffffffffe0
100028410: 9100830a    	add	x10, x24, #0x20
100028414: 927beb4b    	and	x11, x26, #0xffffffffffffffe0
100028418: ad7f0540    	ldp	q0, q1, [x10, #-0x20]
10002841c: ad400d42    	ldp	q2, q3, [x10]
100028420: 6e642c00    	uqsub.8h	v0, v0, v4
100028424: 6e642c21    	uqsub.8h	v1, v1, v4
100028428: 6e642c42    	uqsub.8h	v2, v2, v4
10002842c: 6e642c63    	uqsub.8h	v3, v3, v4
100028430: ad3f0540    	stp	q0, q1, [x10, #-0x20]
100028434: ac820d42    	stp	q2, q3, [x10], #0x40
100028438: f100816b    	subs	x11, x11, #0x20
10002843c: 54fffee1    	b.ne	0x100028418 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa180>
100028440: eb08035f    	cmp	x26, x8
100028444: 54000280    	b.eq	0x100028494 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa1fc>
100028448: b4000189    	cbz	x9, 0x100028478 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa1e0>
10002844c: aa0803ea    	mov	x10, x8
100028450: 927ef748    	and	x8, x26, #0xfffffffffffffffc
100028454: cb080149    	sub	x9, x10, x8
100028458: 8b0a070a    	add	x10, x24, x10, lsl #1
10002845c: fd400140    	ldr	d0, [x10]
100028460: 2e682c00    	uqsub.4h	v0, v0, v8
100028464: fc008540    	str	d0, [x10], #0x8
100028468: b1001129    	adds	x9, x9, #0x4
10002846c: 54ffff81    	b.ne	0x10002845c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa1c4>
100028470: eb08035f    	cmp	x26, x8
100028474: 54000100    	b.eq	0x100028494 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa1fc>
100028478: 78e87b09    	ldrsh	w9, [x24, x8, lsl #1]
10002847c: 5211012a    	eor	w10, w9, #0x8000
100028480: 0a493d49    	and	w9, w10, w9, lsr #15
100028484: 78287b09    	strh	w9, [x24, x8, lsl #1]
100028488: 91000508    	add	x8, x8, #0x1
10002848c: eb08035f    	cmp	x26, x8
100028490: 54ffff41    	b.ne	0x100028478 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa1e0>
100028494: aa1803f4    	mov	x20, x24
100028498: f140239f    	cmp	x28, #0x8, lsl #12      ; =0x8000
10002849c: 54027e23    	b.lo	0x10002d460 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf1c8>
1000284a0: f14040df    	cmp	x6, #0x10, lsl #12      ; =0x10000
1000284a4: 54027de3    	b.lo	0x10002d460 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf1c8>
1000284a8: d34fff48    	lsr	x8, x26, #15
1000284ac: b4027da8    	cbz	x8, 0x10002d460 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf1c8>
1000284b0: 91402084    	add	x4, x4, #0x8, lsl #12   ; =0x8000
1000284b4: aa1503f9    	mov	x25, x21
1000284b8: aa1603f5    	mov	x21, x22
1000284bc: aa1403f8    	mov	x24, x20
1000284c0: 5294f7b6    	mov	w22, #0xa7bd            ; =42941
1000284c4: 72a3c6b6    	movk	w22, #0x1e35, lsl #16
1000284c8: f9418ff4    	ldr	x20, [sp, #0x318]
1000284cc: d1000760    	sub	x0, x27, #0x1
1000284d0: f100169f    	cmp	x20, #0x5
1000284d4: 540000e2    	b.hs	0x1000284f0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa258>
1000284d8: d2800008    	mov	x8, #0x0                ; =0
1000284dc: d100076c    	sub	x12, x27, #0x1
1000284e0: 91000425    	add	x5, x1, #0x1
1000284e4: eb1b0189    	subs	x9, x12, x27
1000284e8: 54001fa2    	b.hs	0x1000288dc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa644>
1000284ec: 1400010c    	b	0x10002891c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa684>
1000284f0: ab140028    	adds	x8, x1, x20
1000284f4: 54010fa2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000284f8: eb03011f    	cmp	x8, x3
1000284fc: 54026e88    	b.hi	0x10002d2cc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf034>
100028500: f9418be8    	ldr	x8, [sp, #0x310]
100028504: 92403909    	and	x9, x8, #0x7fff
100028508: eb1c013f    	cmp	x9, x28
10002850c: 540166a2    	b.hs	0x10002b1e0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xcf48>
100028510: cb040028    	sub	x8, x1, x4
100028514: f94183ea    	ldr	x10, [sp, #0x300]
100028518: 92403d4a    	and	x10, x10, #0xffff
10002851c: eb06015f    	cmp	x10, x6
100028520: 540172e2    	b.hs	0x10002b37c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xd0e4>
100028524: 78697aad    	ldrh	w13, [x21, x9, lsl #1]
100028528: 786a7b2b    	ldrh	w11, [x25, x10, lsl #1]
10002852c: 5211410c    	eor	w12, w8, #0xffff8000
100028530: 78297aac    	strh	w12, [x21, x9, lsl #1]
100028534: 782a7b2c    	strh	w12, [x25, x10, lsl #1]
100028538: 92403909    	and	x9, x8, #0x7fff
10002853c: eb1a013f    	cmp	x9, x26
100028540: 54017f02    	b.hs	0x10002b520 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xd288>
100028544: 78297b0b    	strh	w11, [x24, x9, lsl #1]
100028548: 8b0100e9    	add	x9, x7, x1
10002854c: b840112a    	ldur	w10, [x9, #0x1]
100028550: 12005d4c    	and	w12, w10, #0xffffff
100028554: 1b167d8c    	mul	w12, w12, w22
100028558: 53117d8e    	lsr	w14, w12, #17
10002855c: 1b167d4a    	mul	w10, w10, w22
100028560: 53107d4c    	lsr	w12, w10, #16
100028564: f9018bee    	str	x14, [sp, #0x310]
100028568: d37f7dca    	ubfiz	x10, x14, #1, #32
10002856c: f8aa6ab0    	prfm	pstl1keep, [x21, x10]
100028570: f90183ec    	str	x12, [sp, #0x300]
100028574: d37f7d8a    	ubfiz	x10, x12, #1, #32
100028578: f8aa6b30    	prfm	pstl1keep, [x25, x10]
10002857c: b940012a    	ldr	w10, [x9]
100028580: d100076f    	sub	x15, x27, #0x1
100028584: d100076c    	sub	x12, x27, #0x1
100028588: aa0103ee    	mov	x14, x1
10002858c: f1000c1f    	cmp	x0, #0x3
100028590: 54000168    	b.hi	0x1000285bc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa324>
100028594: eb0d011f    	cmp	x8, x13
100028598: 54001982    	b.hs	0x1000288c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa630>
10002859c: d100076f    	sub	x15, x27, #0x1
1000285a0: f1000dff    	cmp	x15, #0x3
1000285a4: 54001421    	b.ne	0x100028828 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa590>
1000285a8: 5280006c    	mov	w12, #0x3               ; =3
1000285ac: aa0103ef    	mov	x15, x1
1000285b0: eb0b011f    	cmp	x8, x11
1000285b4: 54001583    	b.lo	0x100028864 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa5cc>
1000285b8: 140000c3    	b	0x1000288c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa62c>
1000285bc: eb0b011f    	cmp	x8, x11
1000285c0: 54001842    	b.hs	0x1000288c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa630>
1000285c4: f9410fed    	ldr	x13, [sp, #0x218]
1000285c8: aa0103ee    	mov	x14, x1
1000285cc: d100076c    	sub	x12, x27, #0x1
1000285d0: eb1701ff    	cmp	x15, x23
1000285d4: 540017a2    	b.hs	0x1000288c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa630>
1000285d8: eb1402ff    	cmp	x23, x20
1000285dc: 5402b6a8    	b.hi	0x10002dcb0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xfa18>
1000285e0: d1402090    	sub	x16, x4, #0x8, lsl #12  ; =0x8000
1000285e4: aa0e03ef    	mov	x15, x14
1000285e8: aa0c03e0    	mov	x0, x12
1000285ec: f1000c0c    	subs	x12, x0, #0x3
1000285f0: 5402b603    	b.lo	0x10002dcb0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xfa18>
1000285f4: eb17001f    	cmp	x0, x23
1000285f8: 5402b5c2    	b.hs	0x10002dcb0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xfa18>
1000285fc: 8b00012e    	add	x14, x9, x0
100028600: b85fd1c1    	ldur	w1, [x14, #-0x3]
100028604: d10005ae    	sub	x14, x13, #0x1
100028608: aa0e03ed    	mov	x13, x14
10002860c: 8b0b020e    	add	x14, x16, x11
100028610: 8b0e0182    	add	x2, x12, x14
100028614: eb1e005f    	cmp	x2, x30
100028618: 540000a2    	b.hs	0x10002862c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa394>
10002861c: b86268e2    	ldr	w2, [x7, x2]
100028620: 6b01005f    	cmp	w2, w1
100028624: 540000a0    	b.eq	0x100028638 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa3a0>
100028628: 1400000d    	b	0x10002865c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa3c4>
10002862c: 52800002    	mov	w2, #0x0                ; =0
100028630: 6b01005f    	cmp	w2, w1
100028634: 54000141    	b.ne	0x10002865c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa3c4>
100028638: eb1e01df    	cmp	x14, x30
10002863c: 540000a2    	b.hs	0x100028650 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa3b8>
100028640: b86e68e2    	ldr	w2, [x7, x14]
100028644: 6b0a005f    	cmp	w2, w10
100028648: 540000a1    	b.ne	0x10002865c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa3c4>
10002864c: 14000011    	b	0x100028690 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa3f8>
100028650: 52800002    	mov	w2, #0x0                ; =0
100028654: 6b0a005f    	cmp	w2, w10
100028658: 540001c0    	b.eq	0x100028690 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa3f8>
10002865c: 9240396b    	and	x11, x11, #0x7fff
100028660: eb1a017f    	cmp	x11, x26
100028664: 540000e2    	b.hs	0x100028680 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa3e8>
100028668: 786b7b0b    	ldrh	w11, [x24, x11, lsl #1]
10002866c: eb0b011f    	cmp	x8, x11
100028670: 54000d42    	b.hs	0x100028818 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa580>
100028674: d10005ae    	sub	x14, x13, #0x1
100028678: b5fffc8d    	cbnz	x13, 0x100028608 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa370>
10002867c: 14000067    	b	0x100028818 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa580>
100028680: d280000b    	mov	x11, #0x0               ; =0
100028684: eb0b011f    	cmp	x8, x11
100028688: 54ffff63    	b.lo	0x100028674 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa3dc>
10002868c: 14000063    	b	0x100028818 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa580>
100028690: f94187ec    	ldr	x12, [sp, #0x308]
100028694: eb0c01df    	cmp	x14, x12
100028698: 54020f82    	b.hs	0x10002c888 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe5f0>
10002869c: f100929f    	cmp	x20, #0x24
1000286a0: 54000222    	b.hs	0x1000286e4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa44c>
1000286a4: 8b0400f1    	add	x17, x7, x4
1000286a8: 5280008c    	mov	w12, #0x4               ; =4
1000286ac: b27d0182    	orr	x2, x12, #0x8
1000286b0: 8b0b0221    	add	x1, x17, x11
1000286b4: eb14005f    	cmp	x2, x20
1000286b8: 540003e8    	b.hi	0x100028734 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa49c>
1000286bc: f86c6922    	ldr	x2, [x9, x12]
1000286c0: 8b0c0023    	add	x3, x1, x12
1000286c4: 928fffe5    	mov	x5, #-0x8000            ; =-32768
1000286c8: f8656863    	ldr	x3, [x3, x5]
1000286cc: eb02007f    	cmp	x3, x2
1000286d0: 54000501    	b.ne	0x100028770 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa4d8>
1000286d4: b1004182    	adds	x2, x12, #0x10
1000286d8: 9100218c    	add	x12, x12, #0x8
1000286dc: 54fffec3    	b.lo	0x1000286b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa41c>
1000286e0: 14000802    	b	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000286e4: 8b0e00e2    	add	x2, x7, x14
1000286e8: f840412c    	ldur	x12, [x9, #0x4]
1000286ec: f8404041    	ldur	x1, [x2, #0x4]
1000286f0: eb0c003f    	cmp	x1, x12
1000286f4: 540004a1    	b.ne	0x100028788 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa4f0>
1000286f8: f840c12c    	ldur	x12, [x9, #0xc]
1000286fc: f840c041    	ldur	x1, [x2, #0xc]
100028700: eb0c003f    	cmp	x1, x12
100028704: 540004a1    	b.ne	0x100028798 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa500>
100028708: f841412c    	ldur	x12, [x9, #0x14]
10002870c: f8414041    	ldur	x1, [x2, #0x14]
100028710: eb0c003f    	cmp	x1, x12
100028714: 54000461    	b.ne	0x1000287a0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa508>
100028718: f841c12c    	ldur	x12, [x9, #0x1c]
10002871c: f841c041    	ldur	x1, [x2, #0x1c]
100028720: eb0c003f    	cmp	x1, x12
100028724: 54000421    	b.ne	0x1000287a8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa510>
100028728: 8b0400f1    	add	x17, x7, x4
10002872c: 5280048c    	mov	w12, #0x24              ; =36
100028730: 17ffffdf    	b	0x1000286ac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa414>
100028734: eb14019f    	cmp	x12, x20
100028738: 540002c2    	b.hs	0x100028790 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa4f8>
10002873c: 8b0b0221    	add	x1, x17, x11
100028740: 386c6922    	ldrb	w2, [x9, x12]
100028744: 8b0c0023    	add	x3, x1, x12
100028748: 928fffe5    	mov	x5, #-0x8000            ; =-32768
10002874c: 38656863    	ldrb	w3, [x3, x5]
100028750: 6b03005f    	cmp	w2, w3
100028754: 540001e1    	b.ne	0x100028790 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa4f8>
100028758: 9100058c    	add	x12, x12, #0x1
10002875c: eb0c029f    	cmp	x20, x12
100028760: 54ffff01    	b.ne	0x100028740 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa4a8>
100028764: aa1403ec    	mov	x12, x20
100028768: f941a3e3    	ldr	x3, [sp, #0x340]
10002876c: 14000014    	b	0x1000287bc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa524>
100028770: ca020061    	eor	x1, x3, x2
100028774: dac00021    	rbit	x1, x1
100028778: dac01021    	clz	x1, x1
10002877c: 8b410d8c    	add	x12, x12, x1, lsr #3
100028780: f941a3e3    	ldr	x3, [sp, #0x340]
100028784: 1400000e    	b	0x1000287bc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa524>
100028788: 52800082    	mov	w2, #0x4                ; =4
10002878c: 14000008    	b	0x1000287ac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa514>
100028790: f941a3e3    	ldr	x3, [sp, #0x340]
100028794: 1400000a    	b	0x1000287bc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa524>
100028798: 52800182    	mov	w2, #0xc                ; =12
10002879c: 14000004    	b	0x1000287ac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa514>
1000287a0: 52800282    	mov	w2, #0x14               ; =20
1000287a4: 14000002    	b	0x1000287ac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa514>
1000287a8: 52800382    	mov	w2, #0x1c               ; =28
1000287ac: ca0c002c    	eor	x12, x1, x12
1000287b0: dac0018c    	rbit	x12, x12
1000287b4: dac0118c    	clz	x12, x12
1000287b8: 8b4c0c4c    	add	x12, x2, x12, lsr #3
1000287bc: f94187e1    	ldr	x1, [sp, #0x308]
1000287c0: eb00019f    	cmp	x12, x0
1000287c4: 540000a9    	b.ls	0x1000287d8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa540>
1000287c8: 8b0b020f    	add	x15, x16, x11
1000287cc: aa0c03e0    	mov	x0, x12
1000287d0: eb17019f    	cmp	x12, x23
1000287d4: 540007a2    	b.hs	0x1000288c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa630>
1000287d8: 9240396b    	and	x11, x11, #0x7fff
1000287dc: eb0b035f    	cmp	x26, x11
1000287e0: 54000109    	b.ls	0x100028800 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa568>
1000287e4: 786b7b0b    	ldrh	w11, [x24, x11, lsl #1]
1000287e8: eb0b011f    	cmp	x8, x11
1000287ec: 54000102    	b.hs	0x10002880c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa574>
1000287f0: aa0003ec    	mov	x12, x0
1000287f4: aa0f03ee    	mov	x14, x15
1000287f8: b5ffefad    	cbnz	x13, 0x1000285ec <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa354>
1000287fc: 14000033    	b	0x1000288c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa630>
100028800: d280000b    	mov	x11, #0x0               ; =0
100028804: eb0b011f    	cmp	x8, x11
100028808: 54ffff43    	b.lo	0x1000287f0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa558>
10002880c: aa0003ec    	mov	x12, x0
100028810: aa0f03ee    	mov	x14, x15
100028814: 1400002d    	b	0x1000288c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa630>
100028818: aa0003ec    	mov	x12, x0
10002881c: aa0f03ee    	mov	x14, x15
100028820: f94187e1    	ldr	x1, [sp, #0x308]
100028824: 14000029    	b	0x1000288c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa630>
100028828: 8b0d008c    	add	x12, x4, x13
10002882c: d140218d    	sub	x13, x12, #0x8, lsl #12 ; =0x8000
100028830: eb1e01bf    	cmp	x13, x30
100028834: 54000082    	b.hs	0x100028844 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa5ac>
100028838: b86d68ec    	ldr	w12, [x7, x13]
10002883c: 12005d8c    	and	w12, w12, #0xffffff
100028840: 14000002    	b	0x100028848 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa5b0>
100028844: 5280000c    	mov	w12, #0x0               ; =0
100028848: 12005d4e    	and	w14, w10, #0xffffff
10002884c: 6b0e019f    	cmp	w12, w14
100028850: 5280006c    	mov	w12, #0x3               ; =3
100028854: 9a8f018c    	csel	x12, x12, x15, eq
100028858: 9a8101af    	csel	x15, x13, x1, eq
10002885c: eb0b011f    	cmp	x8, x11
100028860: 54000322    	b.hs	0x1000288c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa62c>
100028864: d1402090    	sub	x16, x4, #0x8, lsl #12  ; =0x8000
100028868: f9410fed    	ldr	x13, [sp, #0x218]
10002886c: d10005ae    	sub	x14, x13, #0x1
100028870: aa0e03ed    	mov	x13, x14
100028874: 8b0b020e    	add	x14, x16, x11
100028878: eb1e01df    	cmp	x14, x30
10002887c: 54000062    	b.hs	0x100028888 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa5f0>
100028880: b86e68f1    	ldr	w17, [x7, x14]
100028884: 14000002    	b	0x10002888c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa5f4>
100028888: 52800011    	mov	w17, #0x0               ; =0
10002888c: 6b0a023f    	cmp	w17, w10
100028890: 540011a0    	b.eq	0x100028ac4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa82c>
100028894: 9240396b    	and	x11, x11, #0x7fff
100028898: eb1a017f    	cmp	x11, x26
10002889c: 540000e2    	b.hs	0x1000288b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa620>
1000288a0: 786b7b0b    	ldrh	w11, [x24, x11, lsl #1]
1000288a4: eb0b011f    	cmp	x8, x11
1000288a8: 540000e2    	b.hs	0x1000288c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa62c>
1000288ac: d10005ae    	sub	x14, x13, #0x1
1000288b0: b5fffe0d    	cbnz	x13, 0x100028870 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa5d8>
1000288b4: 14000004    	b	0x1000288c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa62c>
1000288b8: d280000b    	mov	x11, #0x0               ; =0
1000288bc: eb0b011f    	cmp	x8, x11
1000288c0: 54ffff63    	b.lo	0x1000288ac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa614>
1000288c4: aa0f03ee    	mov	x14, x15
1000288c8: cb0e0028    	sub	x8, x1, x14
1000288cc: d1000760    	sub	x0, x27, #0x1
1000288d0: 91000425    	add	x5, x1, #0x1
1000288d4: eb1b0189    	subs	x9, x12, x27
1000288d8: 54000223    	b.lo	0x10002891c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa684>
1000288dc: d37ef529    	lsl	x9, x9, #2
1000288e0: f9419bea    	ldr	x10, [sp, #0x330]
1000288e4: 5ac0114a    	clz	w10, w10
1000288e8: 5ac0110b    	clz	w11, w8
1000288ec: cb0a0129    	sub	x9, x9, x10
1000288f0: 8b0b0129    	add	x9, x9, x11
1000288f4: f1000d3f    	cmp	x9, #0x3
1000288f8: 5400012b    	b.lt	0x10002891c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa684>
1000288fc: d1000421    	sub	x1, x1, #0x1
100028900: 52800029    	mov	w9, #0x1                ; =1
100028904: 5280002a    	mov	w10, #0x1               ; =1
100028908: eb03003f    	cmp	x1, x3
10002890c: 54006f22    	b.hs	0x1000296f0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb458>
100028910: f94197ee    	ldr	x14, [sp, #0x328]
100028914: b94323ef    	ldr	w15, [sp, #0x320]
100028918: 140002ce    	b	0x100029450 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb1b8>
10002891c: f94113e8    	ldr	x8, [sp, #0x220]
100028920: f100091f    	cmp	x8, #0x2
100028924: 54008b23    	b.lo	0x100029a88 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb7f0>
100028928: cb050068    	sub	x8, x3, x5
10002892c: eb0802ff    	cmp	x23, x8
100028930: 9a8832e9    	csel	x9, x23, x8, lo
100028934: f104091f    	cmp	x8, #0x102
100028938: 9a943114    	csel	x20, x8, x20, lo
10002893c: 9a973137    	csel	x23, x9, x23, lo
100028940: cb0400a8    	sub	x8, x5, x4
100028944: f140211f    	cmp	x8, #0x8, lsl #12       ; =0x8000
100028948: 54003501    	b.ne	0x100028fe8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xad50>
10002894c: f901b7e6    	str	x6, [sp, #0x368]
100028950: f941afe8    	ldr	x8, [sp, #0x358]
100028954: f901b3e4    	str	x4, [sp, #0x360]
100028958: f9018ff4    	str	x20, [sp, #0x318]
10002895c: 37000168    	tbnz	w8, #0x0, 0x100028988 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa6f0>
100028960: f941afe8    	ldr	x8, [sp, #0x358]
100028964: b4000088    	cbz	x8, 0x100028974 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa6dc>
100028968: f85f82a8    	ldur	x8, [x21, #-0x8]
10002896c: f100051f    	cmp	x8, #0x1
100028970: 540000c1    	b.ne	0x100028988 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa6f0>
100028974: b400117c    	cbz	x28, 0x100028ba0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa908>
100028978: f100139f    	cmp	x28, #0x4
10002897c: 540009c2    	b.hs	0x100028ab4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa81c>
100028980: d2800008    	mov	x8, #0x0                ; =0
100028984: 14000080    	b	0x100028b84 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa8ec>
100028988: b40006bc    	cbz	x28, 0x100028a5c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa7c4>
10002898c: f90eebff    	str	xzr, [sp, #0x1dd0]
100028990: f90ee7ff    	str	xzr, [sp, #0x1dc8]
100028994: f90eefff    	str	xzr, [sp, #0x1dd8]
100028998: 912683e0    	add	x0, sp, #0x9a0
10002899c: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
1000289a0: 91372021    	add	x1, x1, #0xdc8
1000289a4: aa1c03e2    	mov	x2, x28
1000289a8: 52800043    	mov	w3, #0x2                ; =2
1000289ac: 52800024    	mov	w4, #0x1                ; =1
1000289b0: 94002426    	bl	0x100031a48 <_list.RocList.reallocate>
1000289b4: d2800008    	mov	x8, #0x0                ; =0
1000289b8: f944d3f6    	ldr	x22, [sp, #0x9a0]
1000289bc: f944dbf4    	ldr	x20, [sp, #0x9b0]
1000289c0: d1000789    	sub	x9, x28, #0x1
1000289c4: eb09039f    	cmp	x28, x9
1000289c8: 9a893389    	csel	x9, x28, x9, lo
1000289cc: 91000529    	add	x9, x9, #0x1
1000289d0: f100853f    	cmp	x9, #0x21
1000289d4: 540002c3    	b.lo	0x100028a2c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa794>
1000289d8: cb1502ca    	sub	x10, x22, x21
1000289dc: f100fd5f    	cmp	x10, #0x3f
1000289e0: 4f04a404    	movi.8h	v4, #0x80, lsl #8
1000289e4: 54000249    	b.ls	0x100028a2c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa794>
1000289e8: f2401128    	ands	x8, x9, #0x1f
1000289ec: 5280040a    	mov	w10, #0x20              ; =32
1000289f0: 9a880148    	csel	x8, x10, x8, eq
1000289f4: cb080128    	sub	x8, x9, x8
1000289f8: 910082a9    	add	x9, x21, #0x20
1000289fc: 910082ca    	add	x10, x22, #0x20
100028a00: aa0803eb    	mov	x11, x8
100028a04: ad7f0520    	ldp	q0, q1, [x9, #-0x20]
100028a08: acc20d22    	ldp	q2, q3, [x9], #0x40
100028a0c: 6e642c00    	uqsub.8h	v0, v0, v4
100028a10: 6e642c21    	uqsub.8h	v1, v1, v4
100028a14: 6e642c42    	uqsub.8h	v2, v2, v4
100028a18: 6e642c63    	uqsub.8h	v3, v3, v4
100028a1c: ad3f0540    	stp	q0, q1, [x10, #-0x20]
100028a20: ac820d42    	stp	q2, q3, [x10], #0x40
100028a24: f100816b    	subs	x11, x11, #0x20
100028a28: 54fffee1    	b.ne	0x100028a04 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa76c>
100028a2c: b1000509    	adds	x9, x8, #0x1
100028a30: 5400e5c2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100028a34: eb08039f    	cmp	x28, x8
100028a38: 5400e620    	b.eq	0x10002a6fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc464>
100028a3c: 78e87aaa    	ldrsh	w10, [x21, x8, lsl #1]
100028a40: 5211014b    	eor	w11, w10, #0x8000
100028a44: 0a4a3d6a    	and	w10, w11, w10, lsr #15
100028a48: 78287aca    	strh	w10, [x22, x8, lsl #1]
100028a4c: aa0903e8    	mov	x8, x9
100028a50: eb09039f    	cmp	x28, x9
100028a54: 54fffec1    	b.ne	0x100028a2c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa794>
100028a58: 14000003    	b	0x100028a64 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa7cc>
100028a5c: d2800016    	mov	x22, #0x0               ; =0
100028a60: d2800014    	mov	x20, #0x0               ; =0
100028a64: f904d3f5    	str	x21, [sp, #0x9a0]
100028a68: f904d7fc    	str	x28, [sp, #0x9a8]
100028a6c: f941afe8    	ldr	x8, [sp, #0x358]
100028a70: f904dbe8    	str	x8, [sp, #0x9b0]
100028a74: 912683e0    	add	x0, sp, #0x9a0
100028a78: 94001dd2    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100028a7c: f901aff4    	str	x20, [sp, #0x358]
100028a80: f9419fe7    	ldr	x7, [sp, #0x338]
100028a84: f941a3e3    	ldr	x3, [sp, #0x340]
100028a88: f941b7e6    	ldr	x6, [sp, #0x368]
100028a8c: f941b3e4    	ldr	x4, [sp, #0x360]
100028a90: f94173fe    	ldr	x30, [sp, #0x2e0]
100028a94: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100028a98: f94187e1    	ldr	x1, [sp, #0x308]
100028a9c: 91000425    	add	x5, x1, #0x1
100028aa0: d1000760    	sub	x0, x27, #0x1
100028aa4: f941abe8    	ldr	x8, [sp, #0x350]
100028aa8: f9015bf7    	str	x23, [sp, #0x2b0]
100028aac: 37000968    	tbnz	w8, #0x0, 0x100028bd8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa940>
100028ab0: 14000040    	b	0x100028bb0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa918>
100028ab4: f100839f    	cmp	x28, #0x20
100028ab8: 540002e2    	b.hs	0x100028b14 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa87c>
100028abc: d2800008    	mov	x8, #0x0                ; =0
100028ac0: 14000026    	b	0x100028b58 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa8c0>
100028ac4: eb0101df    	cmp	x14, x1
100028ac8: 5401ee02    	b.hs	0x10002c888 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe5f0>
100028acc: f100929f    	cmp	x20, #0x24
100028ad0: 54005122    	b.hs	0x1000294f4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb25c>
100028ad4: 5280008c    	mov	w12, #0x4               ; =4
100028ad8: b27d0190    	orr	x16, x12, #0x8
100028adc: 8b0400ef    	add	x15, x7, x4
100028ae0: 8b0b01ef    	add	x15, x15, x11
100028ae4: eb14021f    	cmp	x16, x20
100028ae8: 54005528    	b.hi	0x10002958c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb2f4>
100028aec: f86c6930    	ldr	x16, [x9, x12]
100028af0: 8b0c01f1    	add	x17, x15, x12
100028af4: 928fffe0    	mov	x0, #-0x8000            ; =-32768
100028af8: f8606a31    	ldr	x17, [x17, x0]
100028afc: eb10023f    	cmp	x17, x16
100028b00: 54005641    	b.ne	0x1000295c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb330>
100028b04: b1004190    	adds	x16, x12, #0x10
100028b08: 9100218c    	add	x12, x12, #0x8
100028b0c: 54fffec3    	b.lo	0x100028ae4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa84c>
100028b10: 140006f6    	b	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100028b14: 927e0b89    	and	x9, x28, #0x1c
100028b18: 927beb88    	and	x8, x28, #0xffffffffffffffe0
100028b1c: 910082aa    	add	x10, x21, #0x20
100028b20: 927beb8b    	and	x11, x28, #0xffffffffffffffe0
100028b24: ad7f0540    	ldp	q0, q1, [x10, #-0x20]
100028b28: ad400d42    	ldp	q2, q3, [x10]
100028b2c: 6e642c00    	uqsub.8h	v0, v0, v4
100028b30: 6e642c21    	uqsub.8h	v1, v1, v4
100028b34: 6e642c42    	uqsub.8h	v2, v2, v4
100028b38: 6e642c63    	uqsub.8h	v3, v3, v4
100028b3c: ad3f0540    	stp	q0, q1, [x10, #-0x20]
100028b40: ac820d42    	stp	q2, q3, [x10], #0x40
100028b44: f100816b    	subs	x11, x11, #0x20
100028b48: 54fffee1    	b.ne	0x100028b24 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa88c>
100028b4c: eb08039f    	cmp	x28, x8
100028b50: 54000280    	b.eq	0x100028ba0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa908>
100028b54: b4000189    	cbz	x9, 0x100028b84 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa8ec>
100028b58: aa0803ea    	mov	x10, x8
100028b5c: 927ef788    	and	x8, x28, #0xfffffffffffffffc
100028b60: cb080149    	sub	x9, x10, x8
100028b64: 8b0a06aa    	add	x10, x21, x10, lsl #1
100028b68: fd400140    	ldr	d0, [x10]
100028b6c: 2e682c00    	uqsub.4h	v0, v0, v8
100028b70: fc008540    	str	d0, [x10], #0x8
100028b74: b1001129    	adds	x9, x9, #0x4
100028b78: 54ffff81    	b.ne	0x100028b68 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa8d0>
100028b7c: eb08039f    	cmp	x28, x8
100028b80: 54000100    	b.eq	0x100028ba0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa908>
100028b84: 78e87aa9    	ldrsh	w9, [x21, x8, lsl #1]
100028b88: 5211012a    	eor	w10, w9, #0x8000
100028b8c: 0a493d49    	and	w9, w10, w9, lsr #15
100028b90: 78287aa9    	strh	w9, [x21, x8, lsl #1]
100028b94: 91000508    	add	x8, x8, #0x1
100028b98: eb08039f    	cmp	x28, x8
100028b9c: 54ffff41    	b.ne	0x100028b84 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa8ec>
100028ba0: aa1503f6    	mov	x22, x21
100028ba4: f941abe8    	ldr	x8, [sp, #0x350]
100028ba8: f9015bf7    	str	x23, [sp, #0x2b0]
100028bac: 37000168    	tbnz	w8, #0x0, 0x100028bd8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa940>
100028bb0: f941abe8    	ldr	x8, [sp, #0x350]
100028bb4: b4000088    	cbz	x8, 0x100028bc4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa92c>
100028bb8: f85f8328    	ldur	x8, [x25, #-0x8]
100028bbc: f100051f    	cmp	x8, #0x1
100028bc0: 540000c1    	b.ne	0x100028bd8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa940>
100028bc4: b40009e6    	cbz	x6, 0x100028d00 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaa68>
100028bc8: f10010df    	cmp	x6, #0x4
100028bcc: 54000a42    	b.hs	0x100028d14 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaa7c>
100028bd0: d2800008    	mov	x8, #0x0                ; =0
100028bd4: 14000070    	b	0x100028d94 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaafc>
100028bd8: b40006c6    	cbz	x6, 0x100028cb0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaa18>
100028bdc: f90eebff    	str	xzr, [sp, #0x1dd0]
100028be0: f90ee7ff    	str	xzr, [sp, #0x1dc8]
100028be4: f90eefff    	str	xzr, [sp, #0x1dd8]
100028be8: 912683e0    	add	x0, sp, #0x9a0
100028bec: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
100028bf0: 91372021    	add	x1, x1, #0xdc8
100028bf4: aa0603e2    	mov	x2, x6
100028bf8: 52800043    	mov	w3, #0x2                ; =2
100028bfc: 52800024    	mov	w4, #0x1                ; =1
100028c00: 94002392    	bl	0x100031a48 <_list.RocList.reallocate>
100028c04: f941b7e6    	ldr	x6, [sp, #0x368]
100028c08: d2800008    	mov	x8, #0x0                ; =0
100028c0c: f944d3f7    	ldr	x23, [sp, #0x9a0]
100028c10: f944dbf4    	ldr	x20, [sp, #0x9b0]
100028c14: d10004c9    	sub	x9, x6, #0x1
100028c18: eb0900df    	cmp	x6, x9
100028c1c: 9a8930c9    	csel	x9, x6, x9, lo
100028c20: 91000529    	add	x9, x9, #0x1
100028c24: f100853f    	cmp	x9, #0x21
100028c28: 540002c3    	b.lo	0x100028c80 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa9e8>
100028c2c: cb1902ea    	sub	x10, x23, x25
100028c30: f100fd5f    	cmp	x10, #0x3f
100028c34: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100028c38: 54000249    	b.ls	0x100028c80 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa9e8>
100028c3c: f2401128    	ands	x8, x9, #0x1f
100028c40: 5280040a    	mov	w10, #0x20              ; =32
100028c44: 9a880148    	csel	x8, x10, x8, eq
100028c48: cb080128    	sub	x8, x9, x8
100028c4c: 91008329    	add	x9, x25, #0x20
100028c50: 910082ea    	add	x10, x23, #0x20
100028c54: aa0803eb    	mov	x11, x8
100028c58: ad7f0520    	ldp	q0, q1, [x9, #-0x20]
100028c5c: acc20d22    	ldp	q2, q3, [x9], #0x40
100028c60: 6e642c00    	uqsub.8h	v0, v0, v4
100028c64: 6e642c21    	uqsub.8h	v1, v1, v4
100028c68: 6e642c42    	uqsub.8h	v2, v2, v4
100028c6c: 6e642c63    	uqsub.8h	v3, v3, v4
100028c70: ad3f0540    	stp	q0, q1, [x10, #-0x20]
100028c74: ac820d42    	stp	q2, q3, [x10], #0x40
100028c78: f100816b    	subs	x11, x11, #0x20
100028c7c: 54fffee1    	b.ne	0x100028c58 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa9c0>
100028c80: b1000509    	adds	x9, x8, #0x1
100028c84: 5400d322    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100028c88: eb0800df    	cmp	x6, x8
100028c8c: 5400d380    	b.eq	0x10002a6fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc464>
100028c90: 78e87b2a    	ldrsh	w10, [x25, x8, lsl #1]
100028c94: 5211014b    	eor	w11, w10, #0x8000
100028c98: 0a4a3d6a    	and	w10, w11, w10, lsr #15
100028c9c: 78287aea    	strh	w10, [x23, x8, lsl #1]
100028ca0: aa0903e8    	mov	x8, x9
100028ca4: eb0900df    	cmp	x6, x9
100028ca8: 54fffec1    	b.ne	0x100028c80 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa9e8>
100028cac: 14000003    	b	0x100028cb8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaa20>
100028cb0: d2800017    	mov	x23, #0x0               ; =0
100028cb4: d2800014    	mov	x20, #0x0               ; =0
100028cb8: f904d3f9    	str	x25, [sp, #0x9a0]
100028cbc: f904d7e6    	str	x6, [sp, #0x9a8]
100028cc0: f941abe8    	ldr	x8, [sp, #0x350]
100028cc4: f904dbe8    	str	x8, [sp, #0x9b0]
100028cc8: 912683e0    	add	x0, sp, #0x9a0
100028ccc: 94001d3d    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100028cd0: f901abf4    	str	x20, [sp, #0x350]
100028cd4: f9419fe7    	ldr	x7, [sp, #0x338]
100028cd8: f941a3e3    	ldr	x3, [sp, #0x340]
100028cdc: f941b3e4    	ldr	x4, [sp, #0x360]
100028ce0: f94173fe    	ldr	x30, [sp, #0x2e0]
100028ce4: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100028ce8: f94187e1    	ldr	x1, [sp, #0x308]
100028cec: 91000425    	add	x5, x1, #0x1
100028cf0: d1000760    	sub	x0, x27, #0x1
100028cf4: f941a7e8    	ldr	x8, [sp, #0x348]
100028cf8: 37000788    	tbnz	w8, #0x0, 0x100028de8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xab50>
100028cfc: 14000030    	b	0x100028dbc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xab24>
100028d00: f901b7ff    	str	xzr, [sp, #0x368]
100028d04: aa1903f7    	mov	x23, x25
100028d08: f941a7e8    	ldr	x8, [sp, #0x348]
100028d0c: 370006e8    	tbnz	w8, #0x0, 0x100028de8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xab50>
100028d10: 1400002b    	b	0x100028dbc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xab24>
100028d14: f10080df    	cmp	x6, #0x20
100028d18: 54000062    	b.hs	0x100028d24 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaa8c>
100028d1c: d2800008    	mov	x8, #0x0                ; =0
100028d20: 14000012    	b	0x100028d68 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaad0>
100028d24: 927e08c9    	and	x9, x6, #0x1c
100028d28: 927be8c8    	and	x8, x6, #0xffffffffffffffe0
100028d2c: 9100832a    	add	x10, x25, #0x20
100028d30: 927be8cb    	and	x11, x6, #0xffffffffffffffe0
100028d34: ad7f0540    	ldp	q0, q1, [x10, #-0x20]
100028d38: ad400d42    	ldp	q2, q3, [x10]
100028d3c: 6e642c00    	uqsub.8h	v0, v0, v4
100028d40: 6e642c21    	uqsub.8h	v1, v1, v4
100028d44: 6e642c42    	uqsub.8h	v2, v2, v4
100028d48: 6e642c63    	uqsub.8h	v3, v3, v4
100028d4c: ad3f0540    	stp	q0, q1, [x10, #-0x20]
100028d50: ac820d42    	stp	q2, q3, [x10], #0x40
100028d54: f100816b    	subs	x11, x11, #0x20
100028d58: 54fffee1    	b.ne	0x100028d34 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaa9c>
100028d5c: eb0800df    	cmp	x6, x8
100028d60: 54000280    	b.eq	0x100028db0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xab18>
100028d64: b4000189    	cbz	x9, 0x100028d94 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaafc>
100028d68: aa0803ea    	mov	x10, x8
100028d6c: 927ef4c8    	and	x8, x6, #0xfffffffffffffffc
100028d70: cb080149    	sub	x9, x10, x8
100028d74: 8b0a072a    	add	x10, x25, x10, lsl #1
100028d78: fd400140    	ldr	d0, [x10]
100028d7c: 2e682c00    	uqsub.4h	v0, v0, v8
100028d80: fc008540    	str	d0, [x10], #0x8
100028d84: b1001129    	adds	x9, x9, #0x4
100028d88: 54ffff81    	b.ne	0x100028d78 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaae0>
100028d8c: eb0800df    	cmp	x6, x8
100028d90: 54000100    	b.eq	0x100028db0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xab18>
100028d94: 78e87b29    	ldrsh	w9, [x25, x8, lsl #1]
100028d98: 5211012a    	eor	w10, w9, #0x8000
100028d9c: 0a493d49    	and	w9, w10, w9, lsr #15
100028da0: 78287b29    	strh	w9, [x25, x8, lsl #1]
100028da4: 91000508    	add	x8, x8, #0x1
100028da8: eb0800df    	cmp	x6, x8
100028dac: 54ffff41    	b.ne	0x100028d94 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaafc>
100028db0: aa1903f7    	mov	x23, x25
100028db4: f941a7e8    	ldr	x8, [sp, #0x348]
100028db8: 37000188    	tbnz	w8, #0x0, 0x100028de8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xab50>
100028dbc: f941a7e8    	ldr	x8, [sp, #0x348]
100028dc0: b4000088    	cbz	x8, 0x100028dd0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xab38>
100028dc4: f85f8308    	ldur	x8, [x24, #-0x8]
100028dc8: f100051f    	cmp	x8, #0x1
100028dcc: 540000e1    	b.ne	0x100028de8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xab50>
100028dd0: f941b7e6    	ldr	x6, [sp, #0x368]
100028dd4: b4000eda    	cbz	x26, 0x100028fac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xad14>
100028dd8: f100135f    	cmp	x26, #0x4
100028ddc: 540009a2    	b.hs	0x100028f10 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xac78>
100028de0: d2800008    	mov	x8, #0x0                ; =0
100028de4: 1400006b    	b	0x100028f90 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xacf8>
100028de8: b40006ba    	cbz	x26, 0x100028ebc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xac24>
100028dec: f90eebff    	str	xzr, [sp, #0x1dd0]
100028df0: f90ee7ff    	str	xzr, [sp, #0x1dc8]
100028df4: f90eefff    	str	xzr, [sp, #0x1dd8]
100028df8: 912683e0    	add	x0, sp, #0x9a0
100028dfc: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
100028e00: 91372021    	add	x1, x1, #0xdc8
100028e04: aa1a03e2    	mov	x2, x26
100028e08: 52800043    	mov	w3, #0x2                ; =2
100028e0c: 52800024    	mov	w4, #0x1                ; =1
100028e10: 9400230e    	bl	0x100031a48 <_list.RocList.reallocate>
100028e14: d2800008    	mov	x8, #0x0                ; =0
100028e18: f944d3f4    	ldr	x20, [sp, #0x9a0]
100028e1c: f944dbf5    	ldr	x21, [sp, #0x9b0]
100028e20: d1000749    	sub	x9, x26, #0x1
100028e24: eb09035f    	cmp	x26, x9
100028e28: 9a893349    	csel	x9, x26, x9, lo
100028e2c: 91000529    	add	x9, x9, #0x1
100028e30: f100853f    	cmp	x9, #0x21
100028e34: 540002c3    	b.lo	0x100028e8c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xabf4>
100028e38: cb18028a    	sub	x10, x20, x24
100028e3c: f100fd5f    	cmp	x10, #0x3f
100028e40: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100028e44: 54000249    	b.ls	0x100028e8c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xabf4>
100028e48: f2401128    	ands	x8, x9, #0x1f
100028e4c: 5280040a    	mov	w10, #0x20              ; =32
100028e50: 9a880148    	csel	x8, x10, x8, eq
100028e54: cb080128    	sub	x8, x9, x8
100028e58: 91008309    	add	x9, x24, #0x20
100028e5c: 9100828a    	add	x10, x20, #0x20
100028e60: aa0803eb    	mov	x11, x8
100028e64: ad7f0520    	ldp	q0, q1, [x9, #-0x20]
100028e68: acc20d22    	ldp	q2, q3, [x9], #0x40
100028e6c: 6e642c00    	uqsub.8h	v0, v0, v4
100028e70: 6e642c21    	uqsub.8h	v1, v1, v4
100028e74: 6e642c42    	uqsub.8h	v2, v2, v4
100028e78: 6e642c63    	uqsub.8h	v3, v3, v4
100028e7c: ad3f0540    	stp	q0, q1, [x10, #-0x20]
100028e80: ac820d42    	stp	q2, q3, [x10], #0x40
100028e84: f100816b    	subs	x11, x11, #0x20
100028e88: 54fffee1    	b.ne	0x100028e64 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xabcc>
100028e8c: b1000509    	adds	x9, x8, #0x1
100028e90: 5400c2c2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100028e94: eb08035f    	cmp	x26, x8
100028e98: 5400c320    	b.eq	0x10002a6fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc464>
100028e9c: 78e87b0a    	ldrsh	w10, [x24, x8, lsl #1]
100028ea0: 5211014b    	eor	w11, w10, #0x8000
100028ea4: 0a4a3d6a    	and	w10, w11, w10, lsr #15
100028ea8: 78287a8a    	strh	w10, [x20, x8, lsl #1]
100028eac: aa0903e8    	mov	x8, x9
100028eb0: eb09035f    	cmp	x26, x9
100028eb4: 54fffec1    	b.ne	0x100028e8c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xabf4>
100028eb8: 14000003    	b	0x100028ec4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xac2c>
100028ebc: d2800014    	mov	x20, #0x0               ; =0
100028ec0: d2800015    	mov	x21, #0x0               ; =0
100028ec4: f904d3f8    	str	x24, [sp, #0x9a0]
100028ec8: f904d7fa    	str	x26, [sp, #0x9a8]
100028ecc: f941a7e8    	ldr	x8, [sp, #0x348]
100028ed0: f904dbe8    	str	x8, [sp, #0x9b0]
100028ed4: 912683e0    	add	x0, sp, #0x9a0
100028ed8: 94001cba    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
100028edc: f901a7f5    	str	x21, [sp, #0x348]
100028ee0: f9419fe7    	ldr	x7, [sp, #0x338]
100028ee4: f941a3e3    	ldr	x3, [sp, #0x340]
100028ee8: f941b7e6    	ldr	x6, [sp, #0x368]
100028eec: f941b3e4    	ldr	x4, [sp, #0x360]
100028ef0: f94173fe    	ldr	x30, [sp, #0x2e0]
100028ef4: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100028ef8: f94187e1    	ldr	x1, [sp, #0x308]
100028efc: 91000425    	add	x5, x1, #0x1
100028f00: d1000760    	sub	x0, x27, #0x1
100028f04: f140239f    	cmp	x28, #0x8, lsl #12      ; =0x8000
100028f08: 54000582    	b.hs	0x100028fb8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xad20>
100028f0c: 14001304    	b	0x10002db1c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf884>
100028f10: f100835f    	cmp	x26, #0x20
100028f14: 54000062    	b.hs	0x100028f20 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xac88>
100028f18: d2800008    	mov	x8, #0x0                ; =0
100028f1c: 14000012    	b	0x100028f64 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaccc>
100028f20: 927e0b49    	and	x9, x26, #0x1c
100028f24: 927beb48    	and	x8, x26, #0xffffffffffffffe0
100028f28: 9100830a    	add	x10, x24, #0x20
100028f2c: 927beb4b    	and	x11, x26, #0xffffffffffffffe0
100028f30: ad7f0540    	ldp	q0, q1, [x10, #-0x20]
100028f34: ad400d42    	ldp	q2, q3, [x10]
100028f38: 6e642c00    	uqsub.8h	v0, v0, v4
100028f3c: 6e642c21    	uqsub.8h	v1, v1, v4
100028f40: 6e642c42    	uqsub.8h	v2, v2, v4
100028f44: 6e642c63    	uqsub.8h	v3, v3, v4
100028f48: ad3f0540    	stp	q0, q1, [x10, #-0x20]
100028f4c: ac820d42    	stp	q2, q3, [x10], #0x40
100028f50: f100816b    	subs	x11, x11, #0x20
100028f54: 54fffee1    	b.ne	0x100028f30 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xac98>
100028f58: eb08035f    	cmp	x26, x8
100028f5c: 54000280    	b.eq	0x100028fac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xad14>
100028f60: b4000189    	cbz	x9, 0x100028f90 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xacf8>
100028f64: aa0803ea    	mov	x10, x8
100028f68: 927ef748    	and	x8, x26, #0xfffffffffffffffc
100028f6c: cb080149    	sub	x9, x10, x8
100028f70: 8b0a070a    	add	x10, x24, x10, lsl #1
100028f74: fd400140    	ldr	d0, [x10]
100028f78: 2e682c00    	uqsub.4h	v0, v0, v8
100028f7c: fc008540    	str	d0, [x10], #0x8
100028f80: b1001129    	adds	x9, x9, #0x4
100028f84: 54ffff81    	b.ne	0x100028f74 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xacdc>
100028f88: eb08035f    	cmp	x26, x8
100028f8c: 54000100    	b.eq	0x100028fac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xad14>
100028f90: 78e87b09    	ldrsh	w9, [x24, x8, lsl #1]
100028f94: 5211012a    	eor	w10, w9, #0x8000
100028f98: 0a493d49    	and	w9, w10, w9, lsr #15
100028f9c: 78287b09    	strh	w9, [x24, x8, lsl #1]
100028fa0: 91000508    	add	x8, x8, #0x1
100028fa4: eb08035f    	cmp	x26, x8
100028fa8: 54ffff41    	b.ne	0x100028f90 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xacf8>
100028fac: aa1803f4    	mov	x20, x24
100028fb0: f140239f    	cmp	x28, #0x8, lsl #12      ; =0x8000
100028fb4: 54025b43    	b.lo	0x10002db1c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf884>
100028fb8: f14040df    	cmp	x6, #0x10, lsl #12      ; =0x10000
100028fbc: 54025b03    	b.lo	0x10002db1c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf884>
100028fc0: d34fff48    	lsr	x8, x26, #15
100028fc4: b4025ac8    	cbz	x8, 0x10002db1c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf884>
100028fc8: 91402084    	add	x4, x4, #0x8, lsl #12   ; =0x8000
100028fcc: aa1603f5    	mov	x21, x22
100028fd0: aa1703f9    	mov	x25, x23
100028fd4: aa1403f8    	mov	x24, x20
100028fd8: f9415bf7    	ldr	x23, [sp, #0x2b0]
100028fdc: 5294f7b6    	mov	w22, #0xa7bd            ; =42941
100028fe0: 72a3c6b6    	movk	w22, #0x1e35, lsl #16
100028fe4: f9418ff4    	ldr	x20, [sp, #0x318]
100028fe8: f100169f    	cmp	x20, #0x5
100028fec: 54000062    	b.hs	0x100028ff8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xad60>
100028ff0: d2800008    	mov	x8, #0x0                ; =0
100028ff4: 140000f5    	b	0x1000293c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb130>
100028ff8: ab1400a8    	adds	x8, x5, x20
100028ffc: 5400b762    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100029000: eb03011f    	cmp	x8, x3
100029004: 54024c28    	b.hi	0x10002d988 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf6f0>
100029008: f9418be8    	ldr	x8, [sp, #0x310]
10002900c: 92403909    	and	x9, x8, #0x7fff
100029010: eb1c013f    	cmp	x9, x28
100029014: 54015ea2    	b.hs	0x10002bbe8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xd950>
100029018: cb0400a8    	sub	x8, x5, x4
10002901c: f94183ea    	ldr	x10, [sp, #0x300]
100029020: 92403d4a    	and	x10, x10, #0xffff
100029024: eb06015f    	cmp	x10, x6
100029028: 54016ae2    	b.hs	0x10002bd84 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xdaec>
10002902c: 78697aac    	ldrh	w12, [x21, x9, lsl #1]
100029030: 786a7b2b    	ldrh	w11, [x25, x10, lsl #1]
100029034: 5211410d    	eor	w13, w8, #0xffff8000
100029038: 78297aad    	strh	w13, [x21, x9, lsl #1]
10002903c: 782a7b2d    	strh	w13, [x25, x10, lsl #1]
100029040: 92403909    	and	x9, x8, #0x7fff
100029044: eb1a013f    	cmp	x9, x26
100029048: 54017702    	b.hs	0x10002bf28 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xdc90>
10002904c: 78297b0b    	strh	w11, [x24, x9, lsl #1]
100029050: 8b0100e9    	add	x9, x7, x1
100029054: b8402129    	ldur	w9, [x9, #0x2]
100029058: 12005d2a    	and	w10, w9, #0xffffff
10002905c: 1b167d4a    	mul	w10, w10, w22
100029060: 53117d4d    	lsr	w13, w10, #17
100029064: 1b167d29    	mul	w9, w9, w22
100029068: 53107d2a    	lsr	w10, w9, #16
10002906c: f9018bed    	str	x13, [sp, #0x310]
100029070: d37f7da9    	ubfiz	x9, x13, #1, #32
100029074: f8a96ab0    	prfm	pstl1keep, [x21, x9]
100029078: f90183ea    	str	x10, [sp, #0x300]
10002907c: d37f7d49    	ubfiz	x9, x10, #1, #32
100029080: f8a96b30    	prfm	pstl1keep, [x25, x9]
100029084: 8b0500e9    	add	x9, x7, x5
100029088: b940012a    	ldr	w10, [x9]
10002908c: f1000c1f    	cmp	x0, #0x3
100029090: 54000128    	b.hi	0x1000290b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xae1c>
100029094: eb0c011f    	cmp	x8, x12
100029098: 540013a2    	b.hs	0x10002930c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb074>
10002909c: f1000c1f    	cmp	x0, #0x3
1000290a0: 54001421    	b.ne	0x100029324 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb08c>
1000290a4: 9100042e    	add	x14, x1, #0x1
1000290a8: eb0b011f    	cmp	x8, x11
1000290ac: 540015a3    	b.lo	0x100029360 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb0c8>
1000290b0: 140000c4    	b	0x1000293c0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb128>
1000290b4: eb0b011f    	cmp	x8, x11
1000290b8: 540012a2    	b.hs	0x10002930c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb074>
1000290bc: f940f7ec    	ldr	x12, [sp, #0x1e8]
1000290c0: 9100042d    	add	x13, x1, #0x1
1000290c4: eb17001f    	cmp	x0, x23
1000290c8: 540017e2    	b.hs	0x1000293c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb12c>
1000290cc: eb1402ff    	cmp	x23, x20
1000290d0: 54028728    	b.hi	0x10002e1b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xff1c>
1000290d4: d140208f    	sub	x15, x4, #0x8, lsl #12  ; =0x8000
1000290d8: aa0d03ee    	mov	x14, x13
1000290dc: aa0003f1    	mov	x17, x0
1000290e0: f1000e20    	subs	x0, x17, #0x3
1000290e4: 54028683    	b.lo	0x10002e1b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xff1c>
1000290e8: eb17023f    	cmp	x17, x23
1000290ec: 54028642    	b.hs	0x10002e1b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xff1c>
1000290f0: 8b11012d    	add	x13, x9, x17
1000290f4: b85fd1a1    	ldur	w1, [x13, #-0x3]
1000290f8: d100058d    	sub	x13, x12, #0x1
1000290fc: aa0d03ec    	mov	x12, x13
100029100: 8b0b01ed    	add	x13, x15, x11
100029104: 8b0d0002    	add	x2, x0, x13
100029108: eb1e005f    	cmp	x2, x30
10002910c: 540000a2    	b.hs	0x100029120 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xae88>
100029110: b86268e2    	ldr	w2, [x7, x2]
100029114: 6b01005f    	cmp	w2, w1
100029118: 540000a0    	b.eq	0x10002912c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xae94>
10002911c: 1400000b    	b	0x100029148 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaeb0>
100029120: 52800002    	mov	w2, #0x0                ; =0
100029124: 6b01005f    	cmp	w2, w1
100029128: 54000101    	b.ne	0x100029148 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaeb0>
10002912c: eb1e01bf    	cmp	x13, x30
100029130: 54000062    	b.hs	0x10002913c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaea4>
100029134: b86d68e2    	ldr	w2, [x7, x13]
100029138: 14000002    	b	0x100029140 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaea8>
10002913c: 52800002    	mov	w2, #0x0                ; =0
100029140: 6b0a005f    	cmp	w2, w10
100029144: 540001c0    	b.eq	0x10002917c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaee4>
100029148: 9240396b    	and	x11, x11, #0x7fff
10002914c: eb1a017f    	cmp	x11, x26
100029150: 540000e2    	b.hs	0x10002916c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaed4>
100029154: 786b7b0b    	ldrh	w11, [x24, x11, lsl #1]
100029158: eb0b011f    	cmp	x8, x11
10002915c: 54000dc2    	b.hs	0x100029314 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb07c>
100029160: d100058d    	sub	x13, x12, #0x1
100029164: b5fffccc    	cbnz	x12, 0x1000290fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xae64>
100029168: 1400006b    	b	0x100029314 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb07c>
10002916c: d280000b    	mov	x11, #0x0               ; =0
100029170: eb0b011f    	cmp	x8, x11
100029174: 54ffff63    	b.lo	0x100029160 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaec8>
100029178: 14000067    	b	0x100029314 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb07c>
10002917c: eb0501bf    	cmp	x13, x5
100029180: 5401b842    	b.hs	0x10002c888 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe5f0>
100029184: f100929f    	cmp	x20, #0x24
100029188: 54000262    	b.hs	0x1000291d4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaf3c>
10002918c: 52800090    	mov	w16, #0x4               ; =4
100029190: aa1003e2    	mov	x2, x16
100029194: b27d0201    	orr	x1, x16, #0x8
100029198: 8b0400f0    	add	x16, x7, x4
10002919c: 8b0b0200    	add	x0, x16, x11
1000291a0: eb14003f    	cmp	x1, x20
1000291a4: 540003e8    	b.hi	0x100029220 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaf88>
1000291a8: aa0203f0    	mov	x16, x2
1000291ac: f8626921    	ldr	x1, [x9, x2]
1000291b0: 8b020002    	add	x2, x0, x2
1000291b4: 928fffe3    	mov	x3, #-0x8000            ; =-32768
1000291b8: f8636842    	ldr	x2, [x2, x3]
1000291bc: eb01005f    	cmp	x2, x1
1000291c0: 54000521    	b.ne	0x100029264 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xafcc>
1000291c4: b1004201    	adds	x1, x16, #0x10
1000291c8: 91002202    	add	x2, x16, #0x8
1000291cc: 54fffea3    	b.lo	0x1000291a0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaf08>
1000291d0: 14000546    	b	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000291d4: 8b0d00e2    	add	x2, x7, x13
1000291d8: f8404120    	ldur	x0, [x9, #0x4]
1000291dc: f8404041    	ldur	x1, [x2, #0x4]
1000291e0: eb00003f    	cmp	x1, x0
1000291e4: 540004c1    	b.ne	0x10002927c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xafe4>
1000291e8: f840c120    	ldur	x0, [x9, #0xc]
1000291ec: f840c041    	ldur	x1, [x2, #0xc]
1000291f0: eb00003f    	cmp	x1, x0
1000291f4: 540004c1    	b.ne	0x10002928c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaff4>
1000291f8: f8414120    	ldur	x0, [x9, #0x14]
1000291fc: f8414041    	ldur	x1, [x2, #0x14]
100029200: eb00003f    	cmp	x1, x0
100029204: 54000481    	b.ne	0x100029294 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaffc>
100029208: f841c120    	ldur	x0, [x9, #0x1c]
10002920c: f841c041    	ldur	x1, [x2, #0x1c]
100029210: eb00003f    	cmp	x1, x0
100029214: 54000441    	b.ne	0x10002929c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb004>
100029218: 52800490    	mov	w16, #0x24              ; =36
10002921c: 17ffffdd    	b	0x100029190 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaef8>
100029220: aa0203e0    	mov	x0, x2
100029224: eb14005f    	cmp	x2, x20
100029228: 540002e2    	b.hs	0x100029284 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xafec>
10002922c: 8b0400f0    	add	x16, x7, x4
100029230: 8b0b0210    	add	x16, x16, x11
100029234: 38606921    	ldrb	w1, [x9, x0]
100029238: 8b000202    	add	x2, x16, x0
10002923c: 928fffe3    	mov	x3, #-0x8000            ; =-32768
100029240: 38636842    	ldrb	w2, [x2, x3]
100029244: 6b02003f    	cmp	w1, w2
100029248: 540001e1    	b.ne	0x100029284 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xafec>
10002924c: 91000400    	add	x0, x0, #0x1
100029250: eb00029f    	cmp	x20, x0
100029254: 54ffff01    	b.ne	0x100029234 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xaf9c>
100029258: aa1403e0    	mov	x0, x20
10002925c: f941a3e3    	ldr	x3, [sp, #0x340]
100029260: 14000014    	b	0x1000292b0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb018>
100029264: ca010040    	eor	x0, x2, x1
100029268: dac00000    	rbit	x0, x0
10002926c: dac01000    	clz	x0, x0
100029270: 8b400e00    	add	x0, x16, x0, lsr #3
100029274: f941a3e3    	ldr	x3, [sp, #0x340]
100029278: 1400000e    	b	0x1000292b0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb018>
10002927c: 52800082    	mov	w2, #0x4                ; =4
100029280: 14000008    	b	0x1000292a0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb008>
100029284: f941a3e3    	ldr	x3, [sp, #0x340]
100029288: 1400000a    	b	0x1000292b0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb018>
10002928c: 52800182    	mov	w2, #0xc                ; =12
100029290: 14000004    	b	0x1000292a0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb008>
100029294: 52800282    	mov	w2, #0x14               ; =20
100029298: 14000002    	b	0x1000292a0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb008>
10002929c: 52800382    	mov	w2, #0x1c               ; =28
1000292a0: ca000020    	eor	x0, x1, x0
1000292a4: dac00000    	rbit	x0, x0
1000292a8: dac01000    	clz	x0, x0
1000292ac: 8b400c40    	add	x0, x2, x0, lsr #3
1000292b0: eb11001f    	cmp	x0, x17
1000292b4: f94187e1    	ldr	x1, [sp, #0x308]
1000292b8: 540000a9    	b.ls	0x1000292cc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb034>
1000292bc: 8b0b01ee    	add	x14, x15, x11
1000292c0: aa0003f1    	mov	x17, x0
1000292c4: eb17001f    	cmp	x0, x23
1000292c8: 540007e2    	b.hs	0x1000293c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb12c>
1000292cc: 9240396b    	and	x11, x11, #0x7fff
1000292d0: eb0b035f    	cmp	x26, x11
1000292d4: 54000109    	b.ls	0x1000292f4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb05c>
1000292d8: 786b7b0b    	ldrh	w11, [x24, x11, lsl #1]
1000292dc: eb0b011f    	cmp	x8, x11
1000292e0: 54000102    	b.hs	0x100029300 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb068>
1000292e4: aa1103e0    	mov	x0, x17
1000292e8: aa0e03ed    	mov	x13, x14
1000292ec: b5ffefac    	cbnz	x12, 0x1000290e0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xae48>
1000292f0: 14000035    	b	0x1000293c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb12c>
1000292f4: d280000b    	mov	x11, #0x0               ; =0
1000292f8: eb0b011f    	cmp	x8, x11
1000292fc: 54ffff43    	b.lo	0x1000292e4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb04c>
100029300: aa1103e0    	mov	x0, x17
100029304: aa0e03ed    	mov	x13, x14
100029308: 1400002f    	b	0x1000293c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb12c>
10002930c: 9100042d    	add	x13, x1, #0x1
100029310: 1400002d    	b	0x1000293c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb12c>
100029314: aa1103e0    	mov	x0, x17
100029318: aa0e03ed    	mov	x13, x14
10002931c: f94187e1    	ldr	x1, [sp, #0x308]
100029320: 14000029    	b	0x1000293c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb12c>
100029324: 8b0c008c    	add	x12, x4, x12
100029328: d140218c    	sub	x12, x12, #0x8, lsl #12 ; =0x8000
10002932c: eb1e019f    	cmp	x12, x30
100029330: 54000082    	b.hs	0x100029340 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb0a8>
100029334: b86c68ed    	ldr	w13, [x7, x12]
100029338: 12005dad    	and	w13, w13, #0xffffff
10002933c: 14000002    	b	0x100029344 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb0ac>
100029340: 5280000d    	mov	w13, #0x0               ; =0
100029344: 12005d4e    	and	w14, w10, #0xffffff
100029348: 6b0e01bf    	cmp	w13, w14
10002934c: 5280006d    	mov	w13, #0x3               ; =3
100029350: 9a8001a0    	csel	x0, x13, x0, eq
100029354: 9a85018e    	csel	x14, x12, x5, eq
100029358: eb0b011f    	cmp	x8, x11
10002935c: 54000322    	b.hs	0x1000293c0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb128>
100029360: d140208f    	sub	x15, x4, #0x8, lsl #12  ; =0x8000
100029364: f940f7ec    	ldr	x12, [sp, #0x1e8]
100029368: d100058d    	sub	x13, x12, #0x1
10002936c: aa0d03ec    	mov	x12, x13
100029370: 8b0b01ed    	add	x13, x15, x11
100029374: eb1e01bf    	cmp	x13, x30
100029378: 54000062    	b.hs	0x100029384 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb0ec>
10002937c: b86d68f0    	ldr	w16, [x7, x13]
100029380: 14000002    	b	0x100029388 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb0f0>
100029384: 52800010    	mov	w16, #0x0               ; =0
100029388: 6b0a021f    	cmp	w16, w10
10002938c: 540008c0    	b.eq	0x1000294a4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb20c>
100029390: 9240396b    	and	x11, x11, #0x7fff
100029394: eb1a017f    	cmp	x11, x26
100029398: 540000e2    	b.hs	0x1000293b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb11c>
10002939c: 786b7b0b    	ldrh	w11, [x24, x11, lsl #1]
1000293a0: eb0b011f    	cmp	x8, x11
1000293a4: 540000e2    	b.hs	0x1000293c0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb128>
1000293a8: d100058d    	sub	x13, x12, #0x1
1000293ac: b5fffe0c    	cbnz	x12, 0x10002936c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb0d4>
1000293b0: 14000004    	b	0x1000293c0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb128>
1000293b4: d280000b    	mov	x11, #0x0               ; =0
1000293b8: eb0b011f    	cmp	x8, x11
1000293bc: 54ffff63    	b.lo	0x1000293a8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb110>
1000293c0: aa0e03ed    	mov	x13, x14
1000293c4: cb0d00a8    	sub	x8, x5, x13
1000293c8: 91000825    	add	x5, x1, #0x2
1000293cc: eb1b0009    	subs	x9, x0, x27
1000293d0: 54003243    	b.lo	0x100029a18 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb780>
1000293d4: d37ef529    	lsl	x9, x9, #2
1000293d8: f9419bea    	ldr	x10, [sp, #0x330]
1000293dc: 5ac0114a    	clz	w10, w10
1000293e0: 5ac0110b    	clz	w11, w8
1000293e4: cb0a0129    	sub	x9, x9, x10
1000293e8: 8b0b0129    	add	x9, x9, x11
1000293ec: f1001d3f    	cmp	x9, #0x7
1000293f0: 5400314b    	b.lt	0x100029a18 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb780>
1000293f4: d1000429    	sub	x9, x1, #0x1
1000293f8: eb03013f    	cmp	x9, x3
1000293fc: 540016c2    	b.hs	0x1000296d4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb43c>
100029400: 386968e9    	ldrb	w9, [x7, x9]
100029404: f94197ee    	ldr	x14, [sp, #0x328]
100029408: b94323ef    	ldr	w15, [sp, #0x320]
10002940c: b8697a6a    	ldr	w10, [x19, x9, lsl #2]
100029410: 1100054a    	add	w10, w10, #0x1
100029414: b8297a6a    	str	w10, [x19, x9, lsl #2]
100029418: d3461d2a    	ubfx	x10, x9, #6, #2
10002941c: 92400129    	and	x9, x9, #0x1
100029420: aa0a0529    	orr	x9, x9, x10, lsl #1
100029424: 8b090a69    	add	x9, x19, x9, lsl #2
100029428: b948052a    	ldr	w10, [x9, #0x804]
10002942c: 1100054a    	add	w10, w10, #0x1
100029430: b908052a    	str	w10, [x9, #0x804]
100029434: 52800049    	mov	w9, #0x2                ; =2
100029438: 5280004a    	mov	w10, #0x2               ; =2
10002943c: eb01007f    	cmp	x3, x1
100029440: 540014e9    	b.ls	0x1000296dc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb444>
100029444: aa0003ec    	mov	x12, x0
100029448: 5280004b    	mov	w11, #0x2               ; =2
10002944c: f90113eb    	str	x11, [sp, #0x220]
100029450: 386168eb    	ldrb	w11, [x7, x1]
100029454: b86b7a6d    	ldr	w13, [x19, x11, lsl #2]
100029458: 110005ad    	add	w13, w13, #0x1
10002945c: b82b7a6d    	str	w13, [x19, x11, lsl #2]
100029460: d3461d6d    	ubfx	x13, x11, #6, #2
100029464: 9240016b    	and	x11, x11, #0x1
100029468: aa0d056b    	orr	x11, x11, x13, lsl #1
10002946c: 8b0b0a6b    	add	x11, x19, x11, lsl #2
100029470: b948056d    	ldr	w13, [x11, #0x804]
100029474: 110005ad    	add	w13, w13, #0x1
100029478: 8b0901ce    	add	x14, x14, x9
10002947c: f90197ee    	str	x14, [sp, #0x328]
100029480: 0b0a01ef    	add	w15, w15, w10
100029484: b90323ef    	str	w15, [sp, #0x320]
100029488: b908056d    	str	w13, [x11, #0x804]
10002948c: f9019be8    	str	x8, [sp, #0x330]
100029490: aa0c03fb    	mov	x27, x12
100029494: aa0503e1    	mov	x1, x5
100029498: eb17019f    	cmp	x12, x23
10002949c: 54ff5103    	b.lo	0x100027ebc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9c24>
1000294a0: 140000a0    	b	0x100029720 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb488>
1000294a4: eb0501bf    	cmp	x13, x5
1000294a8: 54019f02    	b.hs	0x10002c888 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe5f0>
1000294ac: f100929f    	cmp	x20, #0x24
1000294b0: 54000482    	b.hs	0x100029540 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb2a8>
1000294b4: 52800080    	mov	w0, #0x4                ; =4
1000294b8: b27d000f    	orr	x15, x0, #0x8
1000294bc: 8b0400ee    	add	x14, x7, x4
1000294c0: 8b0b01ce    	add	x14, x14, x11
1000294c4: eb1401ff    	cmp	x15, x20
1000294c8: 540008e8    	b.hi	0x1000295e4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb34c>
1000294cc: f860692f    	ldr	x15, [x9, x0]
1000294d0: 8b0001d0    	add	x16, x14, x0
1000294d4: 928ffff1    	mov	x17, #-0x8000           ; =-32768
1000294d8: f8716a10    	ldr	x16, [x16, x17]
1000294dc: eb0f021f    	cmp	x16, x15
1000294e0: 54000a01    	b.ne	0x100029620 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb388>
1000294e4: b100400f    	adds	x15, x0, #0x10
1000294e8: 91002000    	add	x0, x0, #0x8
1000294ec: 54fffec3    	b.lo	0x1000294c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb22c>
1000294f0: 1400047e    	b	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
1000294f4: 8b0e00f0    	add	x16, x7, x14
1000294f8: f840412c    	ldur	x12, [x9, #0x4]
1000294fc: f840420f    	ldur	x15, [x16, #0x4]
100029500: eb0c01ff    	cmp	x15, x12
100029504: 540006c1    	b.ne	0x1000295dc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb344>
100029508: f840c12c    	ldur	x12, [x9, #0xc]
10002950c: f840c20f    	ldur	x15, [x16, #0xc]
100029510: eb0c01ff    	cmp	x15, x12
100029514: 54000941    	b.ne	0x10002963c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb3a4>
100029518: f841412c    	ldur	x12, [x9, #0x14]
10002951c: f841420f    	ldur	x15, [x16, #0x14]
100029520: eb0c01ff    	cmp	x15, x12
100029524: 54000941    	b.ne	0x10002964c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb3b4>
100029528: f841c12c    	ldur	x12, [x9, #0x1c]
10002952c: f841c20f    	ldur	x15, [x16, #0x1c]
100029530: eb0c01ff    	cmp	x15, x12
100029534: 54000941    	b.ne	0x10002965c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb3c4>
100029538: 5280048c    	mov	w12, #0x24              ; =36
10002953c: 17fffd67    	b	0x100028ad8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa840>
100029540: 8b0d00f0    	add	x16, x7, x13
100029544: f840412e    	ldur	x14, [x9, #0x4]
100029548: f840420f    	ldur	x15, [x16, #0x4]
10002954c: eb0e01ff    	cmp	x15, x14
100029550: 54000721    	b.ne	0x100029634 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb39c>
100029554: f840c12e    	ldur	x14, [x9, #0xc]
100029558: f840c20f    	ldur	x15, [x16, #0xc]
10002955c: eb0e01ff    	cmp	x15, x14
100029560: 54000721    	b.ne	0x100029644 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb3ac>
100029564: f841412e    	ldur	x14, [x9, #0x14]
100029568: f841420f    	ldur	x15, [x16, #0x14]
10002956c: eb0e01ff    	cmp	x15, x14
100029570: 54000721    	b.ne	0x100029654 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb3bc>
100029574: f841c12e    	ldur	x14, [x9, #0x1c]
100029578: f841c20f    	ldur	x15, [x16, #0x1c]
10002957c: eb0e01ff    	cmp	x15, x14
100029580: 540008c1    	b.ne	0x100029698 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb400>
100029584: 52800480    	mov	w0, #0x24               ; =36
100029588: 17ffffcc    	b	0x1000294b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb220>
10002958c: eb14019f    	cmp	x12, x20
100029590: 54000702    	b.hs	0x100029670 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb3d8>
100029594: 8b0400ef    	add	x15, x7, x4
100029598: 8b0b01ef    	add	x15, x15, x11
10002959c: 386c6930    	ldrb	w16, [x9, x12]
1000295a0: 8b0c01f1    	add	x17, x15, x12
1000295a4: 928fffe0    	mov	x0, #-0x8000            ; =-32768
1000295a8: 38606a31    	ldrb	w17, [x17, x0]
1000295ac: 6b11021f    	cmp	w16, w17
1000295b0: 54000601    	b.ne	0x100029670 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb3d8>
1000295b4: 9100058c    	add	x12, x12, #0x1
1000295b8: eb0c029f    	cmp	x20, x12
1000295bc: 54ffff01    	b.ne	0x10002959c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb304>
1000295c0: aa1403ec    	mov	x12, x20
1000295c4: 1400002b    	b	0x100029670 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb3d8>
1000295c8: ca10022f    	eor	x15, x17, x16
1000295cc: dac001ef    	rbit	x15, x15
1000295d0: dac011ef    	clz	x15, x15
1000295d4: 8b4f0d8c    	add	x12, x12, x15, lsr #3
1000295d8: 14000026    	b	0x100029670 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb3d8>
1000295dc: 52800090    	mov	w16, #0x4               ; =4
1000295e0: 14000020    	b	0x100029660 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb3c8>
1000295e4: eb14001f    	cmp	x0, x20
1000295e8: 54000622    	b.hs	0x1000296ac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb414>
1000295ec: 8b0400ee    	add	x14, x7, x4
1000295f0: 8b0b01ce    	add	x14, x14, x11
1000295f4: 3860692f    	ldrb	w15, [x9, x0]
1000295f8: 8b0001d0    	add	x16, x14, x0
1000295fc: 928ffff1    	mov	x17, #-0x8000           ; =-32768
100029600: 38716a10    	ldrb	w16, [x16, x17]
100029604: 6b1001ff    	cmp	w15, w16
100029608: 54000521    	b.ne	0x1000296ac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb414>
10002960c: 91000400    	add	x0, x0, #0x1
100029610: eb00029f    	cmp	x20, x0
100029614: 54ffff01    	b.ne	0x1000295f4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb35c>
100029618: aa1403e0    	mov	x0, x20
10002961c: 14000024    	b	0x1000296ac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb414>
100029620: ca0f020e    	eor	x14, x16, x15
100029624: dac001ce    	rbit	x14, x14
100029628: dac011ce    	clz	x14, x14
10002962c: 8b4e0c00    	add	x0, x0, x14, lsr #3
100029630: 1400001f    	b	0x1000296ac <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb414>
100029634: 52800090    	mov	w16, #0x4               ; =4
100029638: 14000019    	b	0x10002969c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb404>
10002963c: 52800190    	mov	w16, #0xc               ; =12
100029640: 14000008    	b	0x100029660 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb3c8>
100029644: 52800190    	mov	w16, #0xc               ; =12
100029648: 14000015    	b	0x10002969c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb404>
10002964c: 52800290    	mov	w16, #0x14              ; =20
100029650: 14000004    	b	0x100029660 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb3c8>
100029654: 52800290    	mov	w16, #0x14              ; =20
100029658: 14000011    	b	0x10002969c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb404>
10002965c: 52800390    	mov	w16, #0x1c              ; =28
100029660: ca0c01ec    	eor	x12, x15, x12
100029664: dac0018c    	rbit	x12, x12
100029668: dac0118c    	clz	x12, x12
10002966c: 8b4c0e0c    	add	x12, x16, x12, lsr #3
100029670: eb17019f    	cmp	x12, x23
100029674: 54ff92a2    	b.hs	0x1000288c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa630>
100029678: 9240396b    	and	x11, x11, #0x7fff
10002967c: eb0b035f    	cmp	x26, x11
100029680: 54000409    	b.ls	0x100029700 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb468>
100029684: 786b7b0b    	ldrh	w11, [x24, x11, lsl #1]
100029688: eb0b011f    	cmp	x8, x11
10002968c: 54ff91e2    	b.hs	0x1000288c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa630>
100029690: b5ff7a4d    	cbnz	x13, 0x1000285d8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa340>
100029694: 17fffc8d    	b	0x1000288c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa630>
100029698: 52800390    	mov	w16, #0x1c              ; =28
10002969c: ca0e01ee    	eor	x14, x15, x14
1000296a0: dac001ce    	rbit	x14, x14
1000296a4: dac011ce    	clz	x14, x14
1000296a8: 8b4e0e00    	add	x0, x16, x14, lsr #3
1000296ac: eb17001f    	cmp	x0, x23
1000296b0: 54ffe8a2    	b.hs	0x1000293c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb12c>
1000296b4: 9240396b    	and	x11, x11, #0x7fff
1000296b8: eb0b035f    	cmp	x26, x11
1000296bc: 540002a9    	b.ls	0x100029710 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb478>
1000296c0: 786b7b0b    	ldrh	w11, [x24, x11, lsl #1]
1000296c4: eb0b011f    	cmp	x8, x11
1000296c8: 54ffe7e2    	b.hs	0x1000293c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb12c>
1000296cc: b5ffd00c    	cbnz	x12, 0x1000290cc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xae34>
1000296d0: 17ffff3d    	b	0x1000293c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb12c>
1000296d4: d2800009    	mov	x9, #0x0                ; =0
1000296d8: 17ffff4b    	b	0x100029404 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb16c>
1000296dc: d280000b    	mov	x11, #0x0               ; =0
1000296e0: aa0003ec    	mov	x12, x0
1000296e4: 5280004d    	mov	w13, #0x2               ; =2
1000296e8: f90113ed    	str	x13, [sp, #0x220]
1000296ec: 17ffff5a    	b	0x100029454 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb1bc>
1000296f0: d280000b    	mov	x11, #0x0               ; =0
1000296f4: f94197ee    	ldr	x14, [sp, #0x328]
1000296f8: b94323ef    	ldr	w15, [sp, #0x320]
1000296fc: 17ffff56    	b	0x100029454 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb1bc>
100029700: d280000b    	mov	x11, #0x0               ; =0
100029704: eb0b011f    	cmp	x8, x11
100029708: 54fffc43    	b.lo	0x100029690 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb3f8>
10002970c: 17fffc6f    	b	0x1000288c8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xa630>
100029710: d280000b    	mov	x11, #0x0               ; =0
100029714: eb0b011f    	cmp	x8, x11
100029718: 54fffda3    	b.lo	0x1000296cc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb434>
10002971c: 17ffff2a    	b	0x1000293c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb12c>
100029720: d1000769    	sub	x9, x27, #0x1
100029724: aa0103e5    	mov	x5, x1
100029728: f1040b7f    	cmp	x27, #0x102
10002972c: 54001828    	b.hi	0x100029a30 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb798>
100029730: 100854c8    	adr	x8, 0x10003a1c8 <_roc__d59_1>
100029734: d503201f    	nop
100029738: 8b1b0108    	add	x8, x8, x27
10002973c: 39402108    	ldrb	w8, [x8, #0x8]
100029740: d37ef508    	lsl	x8, x8, #2
100029744: 91101108    	add	x8, x8, #0x404
100029748: 5280200a    	mov	w10, #0x100             ; =256
10002974c: f9419beb    	ldr	x11, [sp, #0x330]
100029750: 4b0b014a    	sub	w10, w10, w11
100029754: 531d7d4a    	lsr	w10, w10, #29
100029758: d100056b    	sub	x11, x11, #0x1
10002975c: 9aca256b    	lsr	x11, x11, x10
100029760: f103fd7f    	cmp	x11, #0xff
100029764: 540021e8    	b.hi	0x100029ba0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb908>
100029768: 1008490c    	adr	x12, 0x10003a088 <_roc__d57_1>
10002976c: d503201f    	nop
100029770: 8b0b018b    	add	x11, x12, x11
100029774: 3940216b    	ldrb	w11, [x11, #0x8]
100029778: aa0503ef    	mov	x15, x5
10002977c: b8686a6c    	ldr	w12, [x19, x8]
100029780: 8b0a056a    	add	x10, x11, x10, lsl #1
100029784: 1100058b    	add	w11, w12, #0x1
100029788: b8286a6b    	str	w11, [x19, x8]
10002978c: f9412beb    	ldr	x11, [sp, #0x250]
100029790: b86a7968    	ldr	w8, [x11, x10, lsl #2]
100029794: 11000508    	add	w8, w8, #0x1
100029798: b82a7968    	str	w8, [x11, x10, lsl #2]
10002979c: f100237f    	cmp	x27, #0x8
1000297a0: 52810488    	mov	w8, #0x824              ; =2084
1000297a4: 5281050b    	mov	w11, #0x828             ; =2088
1000297a8: 9a888168    	csel	x8, x11, x8, hi
1000297ac: b8686a6b    	ldr	w11, [x19, x8]
1000297b0: 1100056b    	add	w11, w11, #0x1
1000297b4: b8286a6b    	str	w11, [x19, x8]
1000297b8: f9415fe8    	ldr	x8, [sp, #0x2b8]
1000297bc: f94123eb    	ldr	x11, [sp, #0x240]
1000297c0: eb08017f    	cmp	x11, x8
1000297c4: f9018ff4    	str	x20, [sp, #0x318]
1000297c8: 54001f00    	b.eq	0x100029ba8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb910>
1000297cc: b94323e8    	ldr	w8, [sp, #0x320]
1000297d0: 2a1b5d08    	orr	w8, w8, w27, lsl #23
1000297d4: f9419beb    	ldr	x11, [sp, #0x330]
1000297d8: d3603d6b    	ubfiz	x11, x11, #32, #16
1000297dc: aa0ac16a    	orr	x10, x11, x10, lsl #48
1000297e0: aa080148    	orr	x8, x10, x8
1000297e4: f94147ea    	ldr	x10, [sp, #0x288]
1000297e8: f9415feb    	ldr	x11, [sp, #0x2b8]
1000297ec: f82b7948    	str	x8, [x10, x11, lsl #3]
1000297f0: 9100056b    	add	x11, x11, #0x1
1000297f4: f9015feb    	str	x11, [sp, #0x2b8]
1000297f8: f9418be5    	ldr	x5, [sp, #0x310]
1000297fc: b4001029    	cbz	x9, 0x100029a00 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb768>
100029800: 8b0f0134    	add	x20, x9, x15
100029804: 91001688    	add	x8, x20, #0x5
100029808: eb03011f    	cmp	x8, x3
10002980c: f9414bf1    	ldr	x17, [sp, #0x290]
100029810: f9414ffb    	ldr	x27, [sp, #0x298]
100029814: 54000568    	b.hi	0x1000298c0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb628>
100029818: cb040288    	sub	x8, x20, x4
10002981c: f140211f    	cmp	x8, #0x8, lsl #12       ; =0x8000
100029820: 54000508    	b.hi	0x1000298c0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb628>
100029824: f140239f    	cmp	x28, #0x8, lsl #12      ; =0x8000
100029828: 540004c3    	b.lo	0x1000298c0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb628>
10002982c: f14040df    	cmp	x6, #0x10, lsl #12      ; =0x10000
100029830: 54000483    	b.lo	0x1000298c0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb628>
100029834: f140235f    	cmp	x26, #0x8, lsl #12      ; =0x8000
100029838: 54000443    	b.lo	0x1000298c0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb628>
10002983c: d34ffca8    	lsr	x8, x5, #15
100029840: b5000408    	cbnz	x8, 0x1000298c0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb628>
100029844: f94183e8    	ldr	x8, [sp, #0x300]
100029848: f140411f    	cmp	x8, #0x10, lsl #12      ; =0x10000
10002984c: 540003a2    	b.hs	0x1000298c0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb628>
100029850: f940c3e8    	ldr	x8, [sp, #0x180]
100029854: eb08029f    	cmp	x20, x8
100029858: 9a883288    	csel	x8, x20, x8, lo
10002985c: eb0f0108    	subs	x8, x8, x15
100029860: 54001209    	b.ls	0x100029aa0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb808>
100029864: cb0401e9    	sub	x9, x15, x4
100029868: 91402129    	add	x9, x9, #0x8, lsl #12   ; =0x8000
10002986c: d37ff92a    	lsl	x10, x9, #1
100029870: f9409beb    	ldr	x11, [sp, #0x130]
100029874: 8b0f016b    	add	x11, x11, x15
100029878: f94183ee    	ldr	x14, [sp, #0x300]
10002987c: 786e7b2c    	ldrh	w12, [x25, x14, lsl #1]
100029880: 78257aa9    	strh	w9, [x21, x5, lsl #1]
100029884: 927f394d    	and	x13, x10, #0xfffe
100029888: 782d6b0c    	strh	w12, [x24, x13]
10002988c: 782e7b29    	strh	w9, [x25, x14, lsl #1]
100029890: 91000529    	add	x9, x9, #0x1
100029894: b840156c    	ldr	w12, [x11], #0x1
100029898: 12005d8d    	and	w13, w12, #0xffffff
10002989c: 1b167dad    	mul	w13, w13, w22
1000298a0: 53117da5    	lsr	w5, w13, #17
1000298a4: 1b167d8c    	mul	w12, w12, w22
1000298a8: 53107d8e    	lsr	w14, w12, #16
1000298ac: 9100094a    	add	x10, x10, #0x2
1000298b0: f1000508    	subs	x8, x8, #0x1
1000298b4: 54fffe41    	b.ne	0x10002987c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb5e4>
1000298b8: aa0e03e9    	mov	x9, x14
1000298bc: 14000047    	b	0x1000299d8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb740>
1000298c0: f90c17f5    	str	x21, [sp, #0x1828]
1000298c4: f90c1bfc    	str	x28, [sp, #0x1830]
1000298c8: f941afe8    	ldr	x8, [sp, #0x358]
1000298cc: f90c1fe8    	str	x8, [sp, #0x1838]
1000298d0: f90c23f9    	str	x25, [sp, #0x1840]
1000298d4: f90c27e6    	str	x6, [sp, #0x1848]
1000298d8: f941abe8    	ldr	x8, [sp, #0x350]
1000298dc: f90c2be8    	str	x8, [sp, #0x1850]
1000298e0: f90c5ff8    	str	x24, [sp, #0x18b8]
1000298e4: f90c63fa    	str	x26, [sp, #0x18c0]
1000298e8: f941a7e8    	ldr	x8, [sp, #0x348]
1000298ec: f90c67e8    	str	x8, [sp, #0x18c8]
1000298f0: f90ee7e7    	str	x7, [sp, #0x1dc8]
1000298f4: f90eebe3    	str	x3, [sp, #0x1dd0]
1000298f8: f9413fe8    	ldr	x8, [sp, #0x278]
1000298fc: f90eefe8    	str	x8, [sp, #0x1dd8]
100029900: 912683e0    	add	x0, sp, #0x9a0
100029904: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
100029908: 9120a021    	add	x1, x1, #0x828
10002990c: 914007e2    	add	x2, sp, #0x1, lsl #12   ; =0x1000
100029910: 91210042    	add	x2, x2, #0x840
100029914: aa0303e8    	mov	x8, x3
100029918: 914007e3    	add	x3, sp, #0x1, lsl #12   ; =0x1000
10002991c: 9122e063    	add	x3, x3, #0x8b8
100029920: 914007e7    	add	x7, sp, #0x1, lsl #12   ; =0x1000
100029924: 913720e7    	add	x7, x7, #0xdc8
100029928: a900a7e8    	stp	x8, x9, [sp, #0x8]
10002992c: f90003ef    	str	x15, [sp]
100029930: f94183e6    	ldr	x6, [sp, #0x300]
100029934: 940016f9    	bl	0x10002f518 <_roc__p493fc421faab5de2c54ac596394a8587.fast>
100029938: f944d3e4    	ldr	x4, [sp, #0x9a0]
10002993c: f944d7e5    	ldr	x5, [sp, #0x9a8]
100029940: f944dbe9    	ldr	x9, [sp, #0x9b0]
100029944: f944dff8    	ldr	x24, [sp, #0x9b8]
100029948: f944e3fa    	ldr	x26, [sp, #0x9c0]
10002994c: f944e7e8    	ldr	x8, [sp, #0x9c8]
100029950: f901a7e8    	str	x8, [sp, #0x348]
100029954: f944ebf5    	ldr	x21, [sp, #0x9d0]
100029958: f944effc    	ldr	x28, [sp, #0x9d8]
10002995c: f944f3e8    	ldr	x8, [sp, #0x9e0]
100029960: f901afe8    	str	x8, [sp, #0x358]
100029964: f944f7f9    	ldr	x25, [sp, #0x9e8]
100029968: f944fbe6    	ldr	x6, [sp, #0x9f0]
10002996c: f944ffe8    	ldr	x8, [sp, #0x9f8]
100029970: f901abe8    	str	x8, [sp, #0x350]
100029974: 396803e8    	ldrb	w8, [sp, #0xa00]
100029978: 7100051f    	cmp	w8, #0x1
10002997c: 54000240    	b.eq	0x1000299c4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb72c>
100029980: 912683e0    	add	x0, sp, #0x9a0
100029984: aa1703fb    	mov	x27, x23
100029988: aa0603f7    	mov	x23, x6
10002998c: aa0403f6    	mov	x22, x4
100029990: f9018be5    	str	x5, [sp, #0x310]
100029994: f901b7f4    	str	x20, [sp, #0x368]
100029998: aa0903f4    	mov	x20, x9
10002999c: 94001b92    	bl	0x1000307e4 <_roc_llvm_rc_decref_38_single_thread>
1000299a0: aa1403e9    	mov	x9, x20
1000299a4: f941b7f4    	ldr	x20, [sp, #0x368]
1000299a8: f9418be5    	ldr	x5, [sp, #0x310]
1000299ac: aa1603e4    	mov	x4, x22
1000299b0: 5294f7b6    	mov	w22, #0xa7bd            ; =42941
1000299b4: 72a3c6b6    	movk	w22, #0x1e35, lsl #16
1000299b8: aa1703e6    	mov	x6, x23
1000299bc: aa1b03f7    	mov	x23, x27
1000299c0: f9414ffb    	ldr	x27, [sp, #0x298]
1000299c4: f9419fe7    	ldr	x7, [sp, #0x338]
1000299c8: f941a3e3    	ldr	x3, [sp, #0x340]
1000299cc: f94173fe    	ldr	x30, [sp, #0x2e0]
1000299d0: 4f04a404    	movi.8h	v4, #0x80, lsl #8
1000299d4: f9414bf1    	ldr	x17, [sp, #0x290]
1000299d8: b90323ff    	str	wzr, [sp, #0x320]
1000299dc: f9018be5    	str	x5, [sp, #0x310]
1000299e0: d37ff8a8    	lsl	x8, x5, #1
1000299e4: f8a86ab0    	prfm	pstl1keep, [x21, x8]
1000299e8: f90183e9    	str	x9, [sp, #0x300]
1000299ec: d37ff928    	lsl	x8, x9, #1
1000299f0: f8a86b30    	prfm	pstl1keep, [x25, x8]
1000299f4: aa1403e5    	mov	x5, x20
1000299f8: f9418ff4    	ldr	x20, [sp, #0x318]
1000299fc: 17fff917    	b	0x100027e58 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9bc0>
100029a00: b90323ff    	str	wzr, [sp, #0x320]
100029a04: f9414bf1    	ldr	x17, [sp, #0x290]
100029a08: f9418ff4    	ldr	x20, [sp, #0x318]
100029a0c: f9414ffb    	ldr	x27, [sp, #0x298]
100029a10: aa0f03e5    	mov	x5, x15
100029a14: 17fff911    	b	0x100027e58 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9bc0>
100029a18: f1000f68    	subs	x8, x27, #0x3
100029a1c: 9a8833e9    	csel	x9, xzr, x8, lo
100029a20: 52800048    	mov	w8, #0x2                ; =2
100029a24: f90113e8    	str	x8, [sp, #0x220]
100029a28: f1040b7f    	cmp	x27, #0x102
100029a2c: 54ffe829    	b.ls	0x100029730 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb498>
100029a30: 52808088    	mov	w8, #0x404              ; =1028
100029a34: 17ffff45    	b	0x100029748 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb4b0>
100029a38: eb0501bf    	cmp	x13, x5
100029a3c: 54017262    	b.hs	0x10002c888 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe5f0>
100029a40: f100929f    	cmp	x20, #0x24
100029a44: 54000322    	b.hs	0x100029aa8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb810>
100029a48: 5280009b    	mov	w27, #0x4               ; =4
100029a4c: b27d036f    	orr	x15, x27, #0x8
100029a50: 8b0400ee    	add	x14, x7, x4
100029a54: 8b0b01ce    	add	x14, x14, x11
100029a58: eb1401ff    	cmp	x15, x20
100029a5c: 540004c8    	b.hi	0x100029af4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb85c>
100029a60: f87b692f    	ldr	x15, [x9, x27]
100029a64: 8b1b01d0    	add	x16, x14, x27
100029a68: 928ffff1    	mov	x17, #-0x8000           ; =-32768
100029a6c: f8716a10    	ldr	x16, [x16, x17]
100029a70: eb0f021f    	cmp	x16, x15
100029a74: 540005e1    	b.ne	0x100029b30 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb898>
100029a78: b100436f    	adds	x15, x27, #0x10
100029a7c: 9100237b    	add	x27, x27, #0x8
100029a80: 54fffec3    	b.lo	0x100029a58 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb7c0>
100029a84: 14000319    	b	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100029a88: d1000b69    	sub	x9, x27, #0x2
100029a8c: 52800028    	mov	w8, #0x1                ; =1
100029a90: f90113e8    	str	x8, [sp, #0x220]
100029a94: f1040b7f    	cmp	x27, #0x102
100029a98: 54ffe4c9    	b.ls	0x100029730 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb498>
100029a9c: 17ffffe5    	b	0x100029a30 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb798>
100029aa0: f94183e9    	ldr	x9, [sp, #0x300]
100029aa4: 17ffffcd    	b	0x1000299d8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb740>
100029aa8: 8b0d00f0    	add	x16, x7, x13
100029aac: f840412e    	ldur	x14, [x9, #0x4]
100029ab0: f840420f    	ldur	x15, [x16, #0x4]
100029ab4: eb0e01ff    	cmp	x15, x14
100029ab8: 54000461    	b.ne	0x100029b44 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb8ac>
100029abc: f840c12e    	ldur	x14, [x9, #0xc]
100029ac0: f840c20f    	ldur	x15, [x16, #0xc]
100029ac4: eb0e01ff    	cmp	x15, x14
100029ac8: 54000421    	b.ne	0x100029b4c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb8b4>
100029acc: f841412e    	ldur	x14, [x9, #0x14]
100029ad0: f841420f    	ldur	x15, [x16, #0x14]
100029ad4: eb0e01ff    	cmp	x15, x14
100029ad8: 540003e1    	b.ne	0x100029b54 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb8bc>
100029adc: f841c12e    	ldur	x14, [x9, #0x1c]
100029ae0: f841c20f    	ldur	x15, [x16, #0x1c]
100029ae4: eb0e01ff    	cmp	x15, x14
100029ae8: 540003a1    	b.ne	0x100029b5c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb8c4>
100029aec: 5280049b    	mov	w27, #0x24              ; =36
100029af0: 17ffffd7    	b	0x100029a4c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb7b4>
100029af4: eb14037f    	cmp	x27, x20
100029af8: 540003c2    	b.hs	0x100029b70 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb8d8>
100029afc: 8b0400ee    	add	x14, x7, x4
100029b00: 8b0b01ce    	add	x14, x14, x11
100029b04: 387b692f    	ldrb	w15, [x9, x27]
100029b08: 8b1b01d0    	add	x16, x14, x27
100029b0c: 928ffff1    	mov	x17, #-0x8000           ; =-32768
100029b10: 38716a10    	ldrb	w16, [x16, x17]
100029b14: 6b1001ff    	cmp	w15, w16
100029b18: 540002c1    	b.ne	0x100029b70 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb8d8>
100029b1c: 9100077b    	add	x27, x27, #0x1
100029b20: eb1b029f    	cmp	x20, x27
100029b24: 54ffff01    	b.ne	0x100029b04 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb86c>
100029b28: aa1403fb    	mov	x27, x20
100029b2c: 14000011    	b	0x100029b70 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb8d8>
100029b30: ca0f020e    	eor	x14, x16, x15
100029b34: dac001ce    	rbit	x14, x14
100029b38: dac011ce    	clz	x14, x14
100029b3c: 8b4e0f7b    	add	x27, x27, x14, lsr #3
100029b40: 1400000c    	b	0x100029b70 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb8d8>
100029b44: 52800090    	mov	w16, #0x4               ; =4
100029b48: 14000006    	b	0x100029b60 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb8c8>
100029b4c: 52800190    	mov	w16, #0xc               ; =12
100029b50: 14000004    	b	0x100029b60 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb8c8>
100029b54: 52800290    	mov	w16, #0x14              ; =20
100029b58: 14000002    	b	0x100029b60 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb8c8>
100029b5c: 52800390    	mov	w16, #0x1c              ; =28
100029b60: ca0e01ee    	eor	x14, x15, x14
100029b64: dac001ce    	rbit	x14, x14
100029b68: dac011ce    	clz	x14, x14
100029b6c: 8b4e0e1b    	add	x27, x16, x14, lsr #3
100029b70: eb17037f    	cmp	x27, x23
100029b74: 54ff1382    	b.hs	0x100027de4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9b4c>
100029b78: 9240396b    	and	x11, x11, #0x7fff
100029b7c: eb0b035f    	cmp	x26, x11
100029b80: 54000469    	b.ls	0x100029c0c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb974>
100029b84: 786b7b0b    	ldrh	w11, [x24, x11, lsl #1]
100029b88: eb0b011f    	cmp	x8, x11
100029b8c: 54ff12c2    	b.hs	0x100027de4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9b4c>
100029b90: b5fefbac    	cbnz	x12, 0x100027b04 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x986c>
100029b94: 17fff894    	b	0x100027de4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9b4c>
100029b98: d2800008    	mov	x8, #0x0                ; =0
100029b9c: 17fff89f    	b	0x100027e18 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9b80>
100029ba0: d280000b    	mov	x11, #0x0               ; =0
100029ba4: 17fffef5    	b	0x100029778 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb4e0>
100029ba8: aa0403ed    	mov	x13, x4
100029bac: aa1703ec    	mov	x12, x23
100029bb0: aa0603eb    	mov	x11, x6
100029bb4: f94123e8    	ldr	x8, [sp, #0x240]
100029bb8: f940abee    	ldr	x14, [sp, #0x150]
100029bbc: eb0801df    	cmp	x14, x8
100029bc0: 540002e0    	b.eq	0x100029c1c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb984>
100029bc4: f94147e0    	ldr	x0, [sp, #0x288]
100029bc8: f94123ee    	ldr	x14, [sp, #0x240]
100029bcc: aa0e03e1    	mov	x1, x14
100029bd0: f94103e2    	ldr	x2, [sp, #0x200]
100029bd4: 94001a17    	bl	0x100030430 <_roc_cold_shim.roc_builtins_list_slack_unique>
100029bd8: f9015fee    	str	x14, [sp, #0x2b8]
100029bdc: 8b0e0008    	add	x8, x0, x14
100029be0: f90123e8    	str	x8, [sp, #0x240]
100029be4: f9419fe7    	ldr	x7, [sp, #0x338]
100029be8: f941a3e3    	ldr	x3, [sp, #0x340]
100029bec: aa0b03e6    	mov	x6, x11
100029bf0: aa0c03f7    	mov	x23, x12
100029bf4: aa0d03e4    	mov	x4, x13
100029bf8: 5294f7b6    	mov	w22, #0xa7bd            ; =42941
100029bfc: 72a3c6b6    	movk	w22, #0x1e35, lsl #16
100029c00: f94173fe    	ldr	x30, [sp, #0x2e0]
100029c04: 4f04a404    	movi.8h	v4, #0x80, lsl #8
100029c08: 17fffef1    	b	0x1000297cc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb534>
100029c0c: d280000b    	mov	x11, #0x0               ; =0
100029c10: eb0b011f    	cmp	x8, x11
100029c14: 54fffbe3    	b.lo	0x100029b90 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb8f8>
100029c18: 17fff873    	b	0x100027de4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x9b4c>
100029c1c: a954bbe8    	ldp	x8, x14, [sp, #0x148]
100029c20: eb0e011f    	cmp	x8, x14
100029c24: 54000140    	b.eq	0x100029c4c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb9b4>
100029c28: f94147e0    	ldr	x0, [sp, #0x288]
100029c2c: f940abee    	ldr	x14, [sp, #0x150]
100029c30: aa0e03e1    	mov	x1, x14
100029c34: f94103e2    	ldr	x2, [sp, #0x200]
100029c38: 940019fe    	bl	0x100030430 <_roc_cold_shim.roc_builtins_list_slack_unique>
100029c3c: f90123ee    	str	x14, [sp, #0x240]
100029c40: 8b0e0008    	add	x8, x0, x14
100029c44: f900abe8    	str	x8, [sp, #0x150]
100029c48: 17ffffdf    	b	0x100029bc4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb92c>
100029c4c: f94103e8    	ldr	x8, [sp, #0x200]
100029c50: 370001c8    	tbnz	w8, #0x0, 0x100029c88 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb9f0>
100029c54: f94103e8    	ldr	x8, [sp, #0x200]
100029c58: d341fd08    	lsr	x8, x8, #1
100029c5c: f940a7ee    	ldr	x14, [sp, #0x148]
100029c60: eb0e011f    	cmp	x8, x14
100029c64: 54000120    	b.eq	0x100029c88 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb9f0>
100029c68: f94147e0    	ldr	x0, [sp, #0x288]
100029c6c: f940a7ee    	ldr	x14, [sp, #0x148]
100029c70: aa0e03e1    	mov	x1, x14
100029c74: f94103e2    	ldr	x2, [sp, #0x200]
100029c78: 940019ee    	bl	0x100030430 <_roc_cold_shim.roc_builtins_list_slack_unique>
100029c7c: 8b0e0008    	add	x8, x0, x14
100029c80: a914bbe8    	stp	x8, x14, [sp, #0x148]
100029c84: 17ffffe9    	b	0x100029c28 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb990>
100029c88: f94147e0    	ldr	x0, [sp, #0x288]
100029c8c: f940a7e1    	ldr	x1, [sp, #0x148]
100029c90: f94103e2    	ldr	x2, [sp, #0x200]
100029c94: 52800023    	mov	w3, #0x1                ; =1
100029c98: 52800104    	mov	w4, #0x8                ; =8
100029c9c: 52800025    	mov	w5, #0x1                ; =1
100029ca0: 9400198e    	bl	0x1000302d8 <_roc_cold_shim.roc_builtins_list_reserve_for_append>
100029ca4: f90147e0    	str	x0, [sp, #0x288]
100029ca8: f900a7e1    	str	x1, [sp, #0x148]
100029cac: f90103e2    	str	x2, [sp, #0x200]
100029cb0: 17ffffee    	b	0x100029c68 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xb9d0>
100029cb4: f940dfe9    	ldr	x9, [sp, #0x1b8]
100029cb8: b9400129    	ldr	w9, [x9]
100029cbc: f940fbea    	ldr	x10, [sp, #0x1f0]
100029cc0: b40019ea    	cbz	x10, 0x100029ffc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xbd64>
100029cc4: f94197ea    	ldr	x10, [sp, #0x328]
100029cc8: 9bca7d2a    	umulh	x10, x9, x10
100029ccc: eb0a03ff    	cmp	xzr, x10
100029cd0: 54fe4981    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100029cd4: f940f3ea    	ldr	x10, [sp, #0x1e0]
100029cd8: b9480d4a    	ldr	w10, [x10, #0x80c]
100029cdc: f940fbec    	ldr	x12, [sp, #0x1f0]
100029ce0: 9bcc7d4b    	umulh	x11, x10, x12
100029ce4: eb0b03ff    	cmp	xzr, x11
100029ce8: 54fe48c1    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100029cec: f94197ed    	ldr	x13, [sp, #0x328]
100029cf0: 9b0d7d2b    	mul	x11, x9, x13
100029cf4: 9b0c7d4c    	mul	x12, x10, x12
100029cf8: eb0b018b    	subs	x11, x12, x11
100029cfc: da8b856b    	cneg	x11, x11, ls
100029d00: b9400f6c    	ldr	w12, [x27, #0xc]
100029d04: 9bcd7d8d    	umulh	x13, x12, x13
100029d08: eb0d03ff    	cmp	xzr, x13
100029d0c: 54fe47a1    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100029d10: f940f3ed    	ldr	x13, [sp, #0x1e0]
100029d14: b94811ad    	ldr	w13, [x13, #0x810]
100029d18: f940fbef    	ldr	x15, [sp, #0x1f0]
100029d1c: 9bcf7dae    	umulh	x14, x13, x15
100029d20: eb0e03ff    	cmp	xzr, x14
100029d24: 54fe46e1    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100029d28: f94197ee    	ldr	x14, [sp, #0x328]
100029d2c: 9b0e7d8c    	mul	x12, x12, x14
100029d30: 9b0f7dad    	mul	x13, x13, x15
100029d34: eb0c01ac    	subs	x12, x13, x12
100029d38: da8c858c    	cneg	x12, x12, ls
100029d3c: ab0c016b    	adds	x11, x11, x12
100029d40: 54004d42    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100029d44: b940136c    	ldr	w12, [x27, #0x10]
100029d48: 9bce7d8d    	umulh	x13, x12, x14
100029d4c: eb0d03ff    	cmp	xzr, x13
100029d50: 54fe4581    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100029d54: f940f3ed    	ldr	x13, [sp, #0x1e0]
100029d58: b94815ad    	ldr	w13, [x13, #0x814]
100029d5c: f940fbef    	ldr	x15, [sp, #0x1f0]
100029d60: 9bcf7dae    	umulh	x14, x13, x15
100029d64: eb0e03ff    	cmp	xzr, x14
100029d68: 54fe44c1    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100029d6c: f94197ee    	ldr	x14, [sp, #0x328]
100029d70: 9b0e7d8c    	mul	x12, x12, x14
100029d74: 9b0f7dad    	mul	x13, x13, x15
100029d78: eb0c01ac    	subs	x12, x13, x12
100029d7c: da8c858c    	cneg	x12, x12, ls
100029d80: ab0c016b    	adds	x11, x11, x12
100029d84: 54004b22    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100029d88: b940176c    	ldr	w12, [x27, #0x14]
100029d8c: 9bce7d8d    	umulh	x13, x12, x14
100029d90: eb0d03ff    	cmp	xzr, x13
100029d94: 54fe4361    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100029d98: f940f3ed    	ldr	x13, [sp, #0x1e0]
100029d9c: b94819ad    	ldr	w13, [x13, #0x818]
100029da0: f940fbef    	ldr	x15, [sp, #0x1f0]
100029da4: 9bcf7dae    	umulh	x14, x13, x15
100029da8: eb0e03ff    	cmp	xzr, x14
100029dac: 54fe42a1    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100029db0: f94197ee    	ldr	x14, [sp, #0x328]
100029db4: 9b0e7d8c    	mul	x12, x12, x14
100029db8: 9b0f7dad    	mul	x13, x13, x15
100029dbc: eb0c01ac    	subs	x12, x13, x12
100029dc0: da8c858c    	cneg	x12, x12, ls
100029dc4: ab0c016b    	adds	x11, x11, x12
100029dc8: 54004902    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100029dcc: b9401b6c    	ldr	w12, [x27, #0x18]
100029dd0: 9bce7d8d    	umulh	x13, x12, x14
100029dd4: eb0d03ff    	cmp	xzr, x13
100029dd8: 54fe4141    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100029ddc: f940f3ed    	ldr	x13, [sp, #0x1e0]
100029de0: b9481dad    	ldr	w13, [x13, #0x81c]
100029de4: f940fbef    	ldr	x15, [sp, #0x1f0]
100029de8: 9bcf7dae    	umulh	x14, x13, x15
100029dec: eb0e03ff    	cmp	xzr, x14
100029df0: 54fe4081    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100029df4: f94197ee    	ldr	x14, [sp, #0x328]
100029df8: 9b0e7d8c    	mul	x12, x12, x14
100029dfc: 9b0f7dad    	mul	x13, x13, x15
100029e00: eb0c01ac    	subs	x12, x13, x12
100029e04: da8c858c    	cneg	x12, x12, ls
100029e08: ab0c016b    	adds	x11, x11, x12
100029e0c: 540046e2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100029e10: b9401f6c    	ldr	w12, [x27, #0x1c]
100029e14: 9bce7d8d    	umulh	x13, x12, x14
100029e18: eb0d03ff    	cmp	xzr, x13
100029e1c: 54fe3f21    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100029e20: f940f3ed    	ldr	x13, [sp, #0x1e0]
100029e24: b94821ad    	ldr	w13, [x13, #0x820]
100029e28: f940fbef    	ldr	x15, [sp, #0x1f0]
100029e2c: 9bcf7dae    	umulh	x14, x13, x15
100029e30: eb0e03ff    	cmp	xzr, x14
100029e34: 54fe3e61    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100029e38: f94197ee    	ldr	x14, [sp, #0x328]
100029e3c: 9b0e7d8c    	mul	x12, x12, x14
100029e40: 9b0f7dad    	mul	x13, x13, x15
100029e44: eb0c01ac    	subs	x12, x13, x12
100029e48: da8c858c    	cneg	x12, x12, ls
100029e4c: ab0c016b    	adds	x11, x11, x12
100029e50: 540044c2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100029e54: b940236c    	ldr	w12, [x27, #0x20]
100029e58: 9bce7d8d    	umulh	x13, x12, x14
100029e5c: eb0d03ff    	cmp	xzr, x13
100029e60: 54fe3d01    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100029e64: f940f3ed    	ldr	x13, [sp, #0x1e0]
100029e68: b94825ad    	ldr	w13, [x13, #0x824]
100029e6c: f940fbef    	ldr	x15, [sp, #0x1f0]
100029e70: 9bcf7dae    	umulh	x14, x13, x15
100029e74: eb0e03ff    	cmp	xzr, x14
100029e78: 54fe3c41    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100029e7c: f94197ee    	ldr	x14, [sp, #0x328]
100029e80: 9b0e7d8c    	mul	x12, x12, x14
100029e84: 9b0f7dad    	mul	x13, x13, x15
100029e88: eb0c01ac    	subs	x12, x13, x12
100029e8c: da8c858c    	cneg	x12, x12, ls
100029e90: ab0c016b    	adds	x11, x11, x12
100029e94: 540042a2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100029e98: b940276c    	ldr	w12, [x27, #0x24]
100029e9c: 9bce7d8d    	umulh	x13, x12, x14
100029ea0: eb0d03ff    	cmp	xzr, x13
100029ea4: 54fe3ae1    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100029ea8: f940f3ed    	ldr	x13, [sp, #0x1e0]
100029eac: b94829ad    	ldr	w13, [x13, #0x828]
100029eb0: f940fbef    	ldr	x15, [sp, #0x1f0]
100029eb4: 9bcf7dae    	umulh	x14, x13, x15
100029eb8: eb0e03ff    	cmp	xzr, x14
100029ebc: 54fe3a21    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100029ec0: f94197ee    	ldr	x14, [sp, #0x328]
100029ec4: 9b0e7d8c    	mul	x12, x12, x14
100029ec8: 9b0f7dad    	mul	x13, x13, x15
100029ecc: eb0c01ac    	subs	x12, x13, x12
100029ed0: da8c858c    	cneg	x12, x12, ls
100029ed4: ab0c016b    	adds	x11, x11, x12
100029ed8: 54004082    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100029edc: b9402b6c    	ldr	w12, [x27, #0x28]
100029ee0: 9bce7d8d    	umulh	x13, x12, x14
100029ee4: eb0d03ff    	cmp	xzr, x13
100029ee8: 54fe38c1    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100029eec: f940f3ed    	ldr	x13, [sp, #0x1e0]
100029ef0: b9482dad    	ldr	w13, [x13, #0x82c]
100029ef4: f940fbef    	ldr	x15, [sp, #0x1f0]
100029ef8: 9bcf7dae    	umulh	x14, x13, x15
100029efc: eb0e03ff    	cmp	xzr, x14
100029f00: 54fe3801    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100029f04: f94197ee    	ldr	x14, [sp, #0x328]
100029f08: 9b0e7d8c    	mul	x12, x12, x14
100029f0c: 9b0f7dad    	mul	x13, x13, x15
100029f10: eb0c01ac    	subs	x12, x13, x12
100029f14: da8c858c    	cneg	x12, x12, ls
100029f18: ab0c016b    	adds	x11, x11, x12
100029f1c: 54003e62    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100029f20: b9402f6c    	ldr	w12, [x27, #0x2c]
100029f24: 9bce7d8d    	umulh	x13, x12, x14
100029f28: eb0d03ff    	cmp	xzr, x13
100029f2c: 54fe36a1    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100029f30: f940f3ed    	ldr	x13, [sp, #0x1e0]
100029f34: b94831ad    	ldr	w13, [x13, #0x830]
100029f38: f940fbef    	ldr	x15, [sp, #0x1f0]
100029f3c: 9bcf7dae    	umulh	x14, x13, x15
100029f40: eb0e03ff    	cmp	xzr, x14
100029f44: 54fe35e1    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100029f48: f94197f0    	ldr	x16, [sp, #0x328]
100029f4c: 9b107d8c    	mul	x12, x12, x16
100029f50: 9b0f7dad    	mul	x13, x13, x15
100029f54: eb0c01ac    	subs	x12, x13, x12
100029f58: da8c858c    	cneg	x12, x12, ls
100029f5c: ab0c016b    	adds	x11, x11, x12
100029f60: 54003c42    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100029f64: f940fbec    	ldr	x12, [sp, #0x1f0]
100029f68: ab10018d    	adds	x13, x12, x16
100029f6c: 54003be2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100029f70: 5280190e    	mov	w14, #0xc8              ; =200
100029f74: 9bce7e0c    	umulh	x12, x16, x14
100029f78: eb0c03ff    	cmp	xzr, x12
100029f7c: 54fe3421    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100029f80: 9b0e7e0c    	mul	x12, x16, x14
100029f84: d349fd8c    	lsr	x12, x12, #9
100029f88: f940fbef    	ldr	x15, [sp, #0x1f0]
100029f8c: 9bcf7d8e    	umulh	x14, x12, x15
100029f90: eb0e03ff    	cmp	xzr, x14
100029f94: 54fe3361    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100029f98: 9b0f7d8c    	mul	x12, x12, x15
100029f9c: d344fd0e    	lsr	x14, x8, #4
100029fa0: f109c1df    	cmp	x14, #0x270
100029fa4: 54000168    	b.hi	0x100029fd0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xbd38>
100029fa8: d34dfdae    	lsr	x14, x13, #13
100029fac: b500012e    	cbnz	x14, 0x100029fd0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xbd38>
100029fb0: 5284000e    	mov	w14, #0x2000            ; =8192
100029fb4: cb0d01cd    	sub	x13, x14, x13
100029fb8: 9bcd7d8e    	umulh	x14, x12, x13
100029fbc: eb0e03ff    	cmp	xzr, x14
100029fc0: 54fe3201    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100029fc4: 9b0d7d8d    	mul	x13, x12, x13
100029fc8: ab4d358c    	adds	x12, x12, x13, lsr #13
100029fcc: 540038e2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100029fd0: d34cfd08    	lsr	x8, x8, #12
100029fd4: f940fbee    	ldr	x14, [sp, #0x1f0]
100029fd8: 9bce7d0d    	umulh	x13, x8, x14
100029fdc: eb0d03ff    	cmp	xzr, x13
100029fe0: 54fe3101    	b.ne	0x100026600 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8368>
100029fe4: 9b0e7d08    	mul	x8, x8, x14
100029fe8: ab080168    	adds	x8, x11, x8
100029fec: 540037e2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
100029ff0: eb0c011f    	cmp	x8, x12
100029ff4: 54000083    	b.lo	0x10002a004 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xbd6c>
100029ff8: 14000044    	b	0x10002a108 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xbe70>
100029ffc: f940f3e8    	ldr	x8, [sp, #0x1e0]
10002a000: b9480d0a    	ldr	w10, [x8, #0x80c]
10002a004: 2b0a0128    	adds	w8, w9, w10
10002a008: f940f3ea    	ldr	x10, [sp, #0x1e0]
10002a00c: 540036e2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10002a010: b9000b68    	str	w8, [x27, #0x8]
10002a014: b9080d5f    	str	wzr, [x10, #0x80c]
10002a018: b9400f68    	ldr	w8, [x27, #0xc]
10002a01c: b9481149    	ldr	w9, [x10, #0x810]
10002a020: 2b090108    	adds	w8, w8, w9
10002a024: 54003622    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10002a028: b9000f68    	str	w8, [x27, #0xc]
10002a02c: b908115f    	str	wzr, [x10, #0x810]
10002a030: b9401368    	ldr	w8, [x27, #0x10]
10002a034: b9481549    	ldr	w9, [x10, #0x814]
10002a038: 2b090108    	adds	w8, w8, w9
10002a03c: 54003562    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10002a040: b9001368    	str	w8, [x27, #0x10]
10002a044: b908155f    	str	wzr, [x10, #0x814]
10002a048: b9401768    	ldr	w8, [x27, #0x14]
10002a04c: b9481949    	ldr	w9, [x10, #0x818]
10002a050: 2b090108    	adds	w8, w8, w9
10002a054: 540034a2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10002a058: b9001768    	str	w8, [x27, #0x14]
10002a05c: b908195f    	str	wzr, [x10, #0x818]
10002a060: b9401b68    	ldr	w8, [x27, #0x18]
10002a064: b9481d49    	ldr	w9, [x10, #0x81c]
10002a068: 2b090108    	adds	w8, w8, w9
10002a06c: 540033e2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10002a070: b9001b68    	str	w8, [x27, #0x18]
10002a074: b9081d5f    	str	wzr, [x10, #0x81c]
10002a078: b9401f68    	ldr	w8, [x27, #0x1c]
10002a07c: b9482149    	ldr	w9, [x10, #0x820]
10002a080: 2b090108    	adds	w8, w8, w9
10002a084: 54003322    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10002a088: b9001f68    	str	w8, [x27, #0x1c]
10002a08c: b908215f    	str	wzr, [x10, #0x820]
10002a090: b9402368    	ldr	w8, [x27, #0x20]
10002a094: b9482549    	ldr	w9, [x10, #0x824]
10002a098: 2b090108    	adds	w8, w8, w9
10002a09c: 54003262    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10002a0a0: b9002368    	str	w8, [x27, #0x20]
10002a0a4: b908255f    	str	wzr, [x10, #0x824]
10002a0a8: b9402768    	ldr	w8, [x27, #0x24]
10002a0ac: b9482949    	ldr	w9, [x10, #0x828]
10002a0b0: 2b090108    	adds	w8, w8, w9
10002a0b4: 540031a2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10002a0b8: b9002768    	str	w8, [x27, #0x24]
10002a0bc: b908295f    	str	wzr, [x10, #0x828]
10002a0c0: b9402b68    	ldr	w8, [x27, #0x28]
10002a0c4: b9482d49    	ldr	w9, [x10, #0x82c]
10002a0c8: 2b090108    	adds	w8, w8, w9
10002a0cc: 540030e2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10002a0d0: b9002b68    	str	w8, [x27, #0x28]
10002a0d4: b9082d5f    	str	wzr, [x10, #0x82c]
10002a0d8: b9402f68    	ldr	w8, [x27, #0x2c]
10002a0dc: b9483149    	ldr	w9, [x10, #0x830]
10002a0e0: 2b090108    	adds	w8, w8, w9
10002a0e4: 54003022    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10002a0e8: b9002f68    	str	w8, [x27, #0x2c]
10002a0ec: b908315f    	str	wzr, [x10, #0x830]
10002a0f0: f940fbe8    	ldr	x8, [sp, #0x1f0]
10002a0f4: f94197e9    	ldr	x9, [sp, #0x328]
10002a0f8: ab090108    	adds	x8, x8, x9
10002a0fc: 54002f62    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10002a100: f900fbe8    	str	x8, [sp, #0x1f0]
10002a104: 17fff494    	b	0x100027354 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x90bc>
10002a108: aa1103f6    	mov	x22, x17
10002a10c: f9019be5    	str	x5, [sp, #0x330]
10002a110: f901b3e4    	str	x4, [sp, #0x360]
10002a114: f901b7e6    	str	x6, [sp, #0x368]
10002a118: f940dfe8    	ldr	x8, [sp, #0x1b8]
10002a11c: f90ec3e8    	str	x8, [sp, #0x1d80]
10002a120: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
10002a124: 91360108    	add	x8, x8, #0xd80
10002a128: 3dc05fe0    	ldr	q0, [sp, #0x170]
10002a12c: 3c808100    	stur	q0, [x8, #0x8]
10002a130: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a134: 91360000    	add	x0, x0, #0xd80
10002a138: 94001822    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a13c: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002a140: f94123e9    	ldr	x9, [sp, #0x240]
10002a144: eb08013f    	cmp	x9, x8
10002a148: f9018ff4    	str	x20, [sp, #0x318]
10002a14c: 54002760    	b.eq	0x10002a638 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc3a0>
10002a150: f940f3eb    	ldr	x11, [sp, #0x1e0]
10002a154: b94323e8    	ldr	w8, [sp, #0x320]
10002a158: 2a0803e8    	mov	w8, w8
10002a15c: f94147e9    	ldr	x9, [sp, #0x288]
10002a160: f9415fea    	ldr	x10, [sp, #0x2b8]
10002a164: f82a7928    	str	x8, [x9, x10, lsl #3]
10002a168: b9440968    	ldr	w8, [x11, #0x408]
10002a16c: 31000508    	adds	w8, w8, #0x1
10002a170: 54002bc2    	b.hs	0x10002a6e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc450>
10002a174: b9040968    	str	w8, [x11, #0x408]
10002a178: f90eebff    	str	xzr, [sp, #0x1dd0]
10002a17c: f90ee7ff    	str	xzr, [sp, #0x1dc8]
10002a180: f90eefff    	str	xzr, [sp, #0x1dd8]
10002a184: 912683e0    	add	x0, sp, #0x9a0
10002a188: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
10002a18c: 91372021    	add	x1, x1, #0xdc8
10002a190: 52802902    	mov	w2, #0x148              ; =328
10002a194: 52800023    	mov	w3, #0x1                ; =1
10002a198: 52800024    	mov	w4, #0x1                ; =1
10002a19c: 94001e2b    	bl	0x100031a48 <_list.RocList.reallocate>
10002a1a0: f944d3e8    	ldr	x8, [sp, #0x9a0]
10002a1a4: f944dbe9    	ldr	x9, [sp, #0x9b0]
10002a1a8: 3900011f    	strb	wzr, [x8]
10002a1ac: f904d3e8    	str	x8, [sp, #0x9a0]
10002a1b0: 5280003b    	mov	w27, #0x1               ; =1
10002a1b4: f904d7fb    	str	x27, [sp, #0x9a8]
10002a1b8: f904dbe9    	str	x9, [sp, #0x9b0]
10002a1bc: 3dc26be0    	ldr	q0, [sp, #0x9a0]
10002a1c0: f9000be9    	str	x9, [sp, #0x10]
10002a1c4: 3d8003e0    	str	q0, [sp]
10002a1c8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a1cc: 9122e000    	add	x0, x0, #0x8b8
10002a1d0: d2800001    	mov	x1, #0x0                ; =0
10002a1d4: 528023e2    	mov	w2, #0x11f              ; =287
10002a1d8: 52800023    	mov	w3, #0x1                ; =1
10002a1dc: 94001fea    	bl	0x100032184 <_list.listAppendRangeWithinUnsafe>
10002a1e0: f90eebff    	str	xzr, [sp, #0x1dd0]
10002a1e4: f90ee7ff    	str	xzr, [sp, #0x1dc8]
10002a1e8: f90eefff    	str	xzr, [sp, #0x1dd8]
10002a1ec: 912683e0    	add	x0, sp, #0x9a0
10002a1f0: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
10002a1f4: 91372021    	add	x1, x1, #0xdc8
10002a1f8: 52802542    	mov	w2, #0x12a              ; =298
10002a1fc: 52800083    	mov	w3, #0x4                ; =4
10002a200: 52800024    	mov	w4, #0x1                ; =1
10002a204: 94001e11    	bl	0x100031a48 <_list.RocList.reallocate>
10002a208: f944d3e8    	ldr	x8, [sp, #0x9a0]
10002a20c: f944dbe9    	ldr	x9, [sp, #0x9b0]
10002a210: b900011f    	str	wzr, [x8]
10002a214: f904d3e8    	str	x8, [sp, #0x9a0]
10002a218: f904d7fb    	str	x27, [sp, #0x9a8]
10002a21c: f904dbe9    	str	x9, [sp, #0x9b0]
10002a220: 3dc26be0    	ldr	q0, [sp, #0x9a0]
10002a224: f9000be9    	str	x9, [sp, #0x10]
10002a228: 3d8003e0    	str	q0, [sp]
10002a22c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a230: 91372000    	add	x0, x0, #0xdc8
10002a234: d2800001    	mov	x1, #0x0                ; =0
10002a238: 528023e2    	mov	w2, #0x11f              ; =287
10002a23c: 52800083    	mov	w3, #0x4                ; =4
10002a240: 94001fd1    	bl	0x100032184 <_list.listAppendRangeWithinUnsafe>
10002a244: f904d3f3    	str	x19, [sp, #0x9a0]
10002a248: 912683f4    	add	x20, sp, #0x9a0
10002a24c: 3dc077e0    	ldr	q0, [sp, #0x1d0]
10002a250: 3c808280    	stur	q0, [x20, #0x8]
10002a254: 9114e3e0    	add	x0, sp, #0x538
10002a258: 912683e3    	add	x3, sp, #0x9a0
10002a25c: 914007e4    	add	x4, sp, #0x1, lsl #12   ; =0x1000
10002a260: 9122e084    	add	x4, x4, #0x8b8
10002a264: 914007e5    	add	x5, sp, #0x1, lsl #12   ; =0x1000
10002a268: 913720a5    	add	x5, x5, #0xdc8
10002a26c: 52802401    	mov	w1, #0x120              ; =288
10002a270: 528001c2    	mov	w2, #0xe                ; =14
10002a274: 94001135    	bl	0x10002e748 <_roc__p1a804bfda1f5e4235a696be5d06bcb43.fast>
10002a278: f90eebff    	str	xzr, [sp, #0x1dd0]
10002a27c: f90ee7ff    	str	xzr, [sp, #0x1dc8]
10002a280: f90eefff    	str	xzr, [sp, #0x1dd8]
10002a284: 912683e0    	add	x0, sp, #0x9a0
10002a288: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
10002a28c: 91372021    	add	x1, x1, #0xdc8
10002a290: 52800902    	mov	w2, #0x48               ; =72
10002a294: 52800023    	mov	w3, #0x1                ; =1
10002a298: 52800024    	mov	w4, #0x1                ; =1
10002a29c: 94001deb    	bl	0x100031a48 <_list.RocList.reallocate>
10002a2a0: f944d3e8    	ldr	x8, [sp, #0x9a0]
10002a2a4: f944dbe9    	ldr	x9, [sp, #0x9b0]
10002a2a8: 3900011f    	strb	wzr, [x8]
10002a2ac: f904d3e8    	str	x8, [sp, #0x9a0]
10002a2b0: f904d7fb    	str	x27, [sp, #0x9a8]
10002a2b4: f904dbe9    	str	x9, [sp, #0x9b0]
10002a2b8: 3dc26be0    	ldr	q0, [sp, #0x9a0]
10002a2bc: f9000be9    	str	x9, [sp, #0x10]
10002a2c0: 3d8003e0    	str	q0, [sp]
10002a2c4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a2c8: 9122e000    	add	x0, x0, #0x8b8
10002a2cc: d2800001    	mov	x1, #0x0                ; =0
10002a2d0: 528003e2    	mov	w2, #0x1f               ; =31
10002a2d4: 52800023    	mov	w3, #0x1                ; =1
10002a2d8: 94001fab    	bl	0x100032184 <_list.listAppendRangeWithinUnsafe>
10002a2dc: f90eebff    	str	xzr, [sp, #0x1dd0]
10002a2e0: f90ee7ff    	str	xzr, [sp, #0x1dc8]
10002a2e4: f90eefff    	str	xzr, [sp, #0x1dd8]
10002a2e8: 912683e0    	add	x0, sp, #0x9a0
10002a2ec: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
10002a2f0: 91372021    	add	x1, x1, #0xdc8
10002a2f4: 52800542    	mov	w2, #0x2a               ; =42
10002a2f8: 52800083    	mov	w3, #0x4                ; =4
10002a2fc: 52800024    	mov	w4, #0x1                ; =1
10002a300: 94001dd2    	bl	0x100031a48 <_list.RocList.reallocate>
10002a304: f944d3e8    	ldr	x8, [sp, #0x9a0]
10002a308: f944dbe9    	ldr	x9, [sp, #0x9b0]
10002a30c: b900011f    	str	wzr, [x8]
10002a310: f904d3e8    	str	x8, [sp, #0x9a0]
10002a314: f904d7fb    	str	x27, [sp, #0x9a8]
10002a318: f904dbe9    	str	x9, [sp, #0x9b0]
10002a31c: 3dc26be0    	ldr	q0, [sp, #0x9a0]
10002a320: f9000be9    	str	x9, [sp, #0x10]
10002a324: 3d8003e0    	str	q0, [sp]
10002a328: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a32c: 91372000    	add	x0, x0, #0xdc8
10002a330: d2800001    	mov	x1, #0x0                ; =0
10002a334: 528003e2    	mov	w2, #0x1f               ; =31
10002a338: 52800083    	mov	w3, #0x4                ; =4
10002a33c: 94001f92    	bl	0x100032184 <_list.listAppendRangeWithinUnsafe>
10002a340: f9412bfb    	ldr	x27, [sp, #0x250]
10002a344: f904d3fb    	str	x27, [sp, #0x9a0]
10002a348: 3dc073e0    	ldr	q0, [sp, #0x1c0]
10002a34c: 3c808280    	stur	q0, [x20, #0x8]
10002a350: 911423e0    	add	x0, sp, #0x508
10002a354: 912683e3    	add	x3, sp, #0x9a0
10002a358: 914007e4    	add	x4, sp, #0x1, lsl #12   ; =0x1000
10002a35c: 9122e084    	add	x4, x4, #0x8b8
10002a360: 914007e5    	add	x5, sp, #0x1, lsl #12   ; =0x1000
10002a364: 913720a5    	add	x5, x5, #0xdc8
10002a368: 52800401    	mov	w1, #0x20               ; =32
10002a36c: 528001e2    	mov	w2, #0xf                ; =15
10002a370: 940010f6    	bl	0x10002e748 <_roc__p1a804bfda1f5e4235a696be5d06bcb43.fast>
10002a374: f94157e5    	ldr	x5, [sp, #0x2a8]
10002a378: f9419be9    	ldr	x9, [sp, #0x330]
10002a37c: eb050126    	subs	x6, x9, x5
10002a380: 54001be3    	b.lo	0x10002a6fc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc464>
10002a384: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002a388: 91000508    	add	x8, x8, #0x1
10002a38c: f941a3eb    	ldr	x11, [sp, #0x340]
10002a390: eb09017f    	cmp	x11, x9
10002a394: 1a9f17e9    	cset	w9, eq
10002a398: f904d7ff    	str	xzr, [sp, #0x9a8]
10002a39c: f904d3ff    	str	xzr, [sp, #0x9a0]
10002a3a0: f904dbff    	str	xzr, [sp, #0x9b0]
10002a3a4: f94143ea    	ldr	x10, [sp, #0x280]
10002a3a8: f90c0bea    	str	x10, [sp, #0x1810]
10002a3ac: f9417fea    	ldr	x10, [sp, #0x2f8]
10002a3b0: f90c0fea    	str	x10, [sp, #0x1818]
10002a3b4: f90c13f6    	str	x22, [sp, #0x1820]
10002a3b8: f9419fea    	ldr	x10, [sp, #0x338]
10002a3bc: f90c17ea    	str	x10, [sp, #0x1828]
10002a3c0: f90c1beb    	str	x11, [sp, #0x1830]
10002a3c4: f9413fea    	ldr	x10, [sp, #0x278]
10002a3c8: f90c1fea    	str	x10, [sp, #0x1838]
10002a3cc: f94147ea    	ldr	x10, [sp, #0x288]
10002a3d0: f90c23ea    	str	x10, [sp, #0x1840]
10002a3d4: f90c27e8    	str	x8, [sp, #0x1848]
10002a3d8: f94103e8    	ldr	x8, [sp, #0x200]
10002a3dc: f90c2be8    	str	x8, [sp, #0x1850]
10002a3e0: f90c5ff3    	str	x19, [sp, #0x18b8]
10002a3e4: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
10002a3e8: 9122e108    	add	x8, x8, #0x8b8
10002a3ec: ad4e07e0    	ldp	q0, q1, [sp, #0x1c0]
10002a3f0: 3c808101    	stur	q1, [x8, #0x8]
10002a3f4: f90ee7fb    	str	x27, [sp, #0x1dc8]
10002a3f8: 914007f4    	add	x20, sp, #0x1, lsl #12  ; =0x1000
10002a3fc: 91360294    	add	x20, x20, #0xd80
10002a400: 3c850280    	stur	q0, [x20, #0x50]
10002a404: a905a7ff    	stp	xzr, x9, [sp, #0x58]
10002a408: 912683e8    	add	x8, sp, #0x9a0
10002a40c: f9002be8    	str	x8, [sp, #0x50]
10002a410: 910f43e8    	add	x8, sp, #0x3d0
10002a414: f90027e8    	str	x8, [sp, #0x48]
10002a418: 910ec3e8    	add	x8, sp, #0x3b0
10002a41c: f90023e8    	str	x8, [sp, #0x40]
10002a420: 910e43e8    	add	x8, sp, #0x390
10002a424: f9001fe8    	str	x8, [sp, #0x38]
10002a428: 910dc3e8    	add	x8, sp, #0x370
10002a42c: f9001be8    	str	x8, [sp, #0x30]
10002a430: 911423e8    	add	x8, sp, #0x508
10002a434: f90017e8    	str	x8, [sp, #0x28]
10002a438: f940b3e9    	ldr	x9, [sp, #0x160]
10002a43c: 910fc3e0    	add	x0, sp, #0x3f0
10002a440: 914007e1    	add	x1, sp, #0x1, lsl #12   ; =0x1000
10002a444: 91204021    	add	x1, x1, #0x810
10002a448: 914007e4    	add	x4, sp, #0x1, lsl #12   ; =0x1000
10002a44c: 9120a084    	add	x4, x4, #0x828
10002a450: 914007e7    	add	x7, sp, #0x1, lsl #12   ; =0x1000
10002a454: 912100e7    	add	x7, x7, #0x840
10002a458: 9114e3e8    	add	x8, sp, #0x538
10002a45c: a901a7e8    	stp	x8, x9, [sp, #0x18]
10002a460: f940b7e9    	ldr	x9, [sp, #0x168]
10002a464: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
10002a468: 91372108    	add	x8, x8, #0xdc8
10002a46c: a900a7e8    	stp	x8, x9, [sp, #0x8]
10002a470: 914007e8    	add	x8, sp, #0x1, lsl #12   ; =0x1000
10002a474: 9122e108    	add	x8, x8, #0x8b8
10002a478: f90003e8    	str	x8, [sp]
10002a47c: a95a8fe2    	ldp	x2, x3, [sp, #0x1a8]
10002a480: 97ffae25    	bl	0x100015d14 <_roc__p81003bf97431a8821d5be871f2471565.fast>
10002a484: f90ec3fb    	str	x27, [sp, #0x1d80]
10002a488: 3dc073e0    	ldr	q0, [sp, #0x1c0]
10002a48c: 3c808280    	stur	q0, [x20, #0x8]
10002a490: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a494: 91360000    	add	x0, x0, #0xd80
10002a498: 9400174a    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a49c: f90ec3f3    	str	x19, [sp, #0x1d80]
10002a4a0: 3dc077e0    	ldr	q0, [sp, #0x1d0]
10002a4a4: 3c808280    	stur	q0, [x20, #0x8]
10002a4a8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a4ac: 91360000    	add	x0, x0, #0xd80
10002a4b0: 94001744    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a4b4: f9424ff3    	ldr	x19, [sp, #0x498]
10002a4b8: f94253e8    	ldr	x8, [sp, #0x4a0]
10002a4bc: f90103e8    	str	x8, [sp, #0x200]
10002a4c0: f9423fe8    	ldr	x8, [sp, #0x478]
10002a4c4: f90143e8    	str	x8, [sp, #0x280]
10002a4c8: f94243e8    	ldr	x8, [sp, #0x480]
10002a4cc: f9017fe8    	str	x8, [sp, #0x2f8]
10002a4d0: f9424be8    	ldr	x8, [sp, #0x490]
10002a4d4: f90147e8    	str	x8, [sp, #0x288]
10002a4d8: f94247fb    	ldr	x27, [sp, #0x488]
10002a4dc: f941fbe8    	ldr	x8, [sp, #0x3f0]
10002a4e0: f900d7e8    	str	x8, [sp, #0x1a8]
10002a4e4: f941fff4    	ldr	x20, [sp, #0x3f8]
10002a4e8: 910fc3f6    	add	x22, sp, #0x3f0
10002a4ec: 3cc102c0    	ldur	q0, [x22, #0x10]
10002a4f0: 3d8763e0    	str	q0, [sp, #0x1d80]
10002a4f4: f84202c8    	ldur	x8, [x22, #0x20]
10002a4f8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a4fc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a500: 91360000    	add	x0, x0, #0xd80
10002a504: 9400172f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a508: 3cc282c0    	ldur	q0, [x22, #0x28]
10002a50c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002a510: f84382c8    	ldur	x8, [x22, #0x38]
10002a514: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a518: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a51c: 91360000    	add	x0, x0, #0xd80
10002a520: 94001728    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a524: 3cc402c0    	ldur	q0, [x22, #0x40]
10002a528: 3d8763e0    	str	q0, [sp, #0x1d80]
10002a52c: f84502c8    	ldur	x8, [x22, #0x50]
10002a530: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a534: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a538: 91360000    	add	x0, x0, #0xd80
10002a53c: 94001721    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a540: 3cc582c0    	ldur	q0, [x22, #0x58]
10002a544: 3d8763e0    	str	q0, [sp, #0x1d80]
10002a548: f84682c8    	ldur	x8, [x22, #0x68]
10002a54c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a550: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a554: 91360000    	add	x0, x0, #0xd80
10002a558: 9400171a    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a55c: 3cc702c0    	ldur	q0, [x22, #0x70]
10002a560: 3d8763e0    	str	q0, [sp, #0x1d80]
10002a564: f84802c8    	ldur	x8, [x22, #0x80]
10002a568: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a56c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a570: 91360000    	add	x0, x0, #0xd80
10002a574: 94001713    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a578: f900dbf4    	str	x20, [sp, #0x1b0]
10002a57c: 3700021b    	tbnz	w27, #0x0, 0x10002a5bc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc324>
10002a580: f941b7eb    	ldr	x11, [sp, #0x368]
10002a584: f941b3ed    	ldr	x13, [sp, #0x360]
10002a588: 5294ed0e    	mov	w14, #0xa768            ; =42856
10002a58c: 72a0008e    	movk	w14, #0x4, lsl #16
10002a590: 5284e210    	mov	w16, #0x2710            ; =10000
10002a594: b40000bb    	cbz	x27, 0x10002a5a8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc310>
10002a598: f94143e8    	ldr	x8, [sp, #0x280]
10002a59c: f85f8108    	ldur	x8, [x8, #-0x8]
10002a5a0: f100051f    	cmp	x8, #0x1
10002a5a4: 540001c1    	b.ne	0x10002a5dc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc344>
10002a5a8: d341ff68    	lsr	x8, x27, #1
10002a5ac: f9417fe9    	ldr	x9, [sp, #0x2f8]
10002a5b0: eb09011f    	cmp	x8, x9
10002a5b4: 1a9f17f4    	cset	w20, eq
10002a5b8: 1400000a    	b	0x10002a5e0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc348>
10002a5bc: 52800034    	mov	w20, #0x1               ; =1
10002a5c0: f941a3ea    	ldr	x10, [sp, #0x340]
10002a5c4: f941b7eb    	ldr	x11, [sp, #0x368]
10002a5c8: f941b3ed    	ldr	x13, [sp, #0x360]
10002a5cc: 5294ed0e    	mov	w14, #0xa768            ; =42856
10002a5d0: 72a0008e    	movk	w14, #0x4, lsl #16
10002a5d4: 5284e210    	mov	w16, #0x2710            ; =10000
10002a5d8: 14000003    	b	0x10002a5e4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc34c>
10002a5dc: 52800034    	mov	w20, #0x1               ; =1
10002a5e0: f941a3ea    	ldr	x10, [sp, #0x340]
10002a5e4: f9419bf1    	ldr	x17, [sp, #0x330]
10002a5e8: 910fc3e9    	add	x9, sp, #0x3f0
10002a5ec: 3ccd0120    	ldur	q0, [x9, #0xd0]
10002a5f0: 3d80dfe0    	str	q0, [sp, #0x370]
10002a5f4: f84e0128    	ldur	x8, [x9, #0xe0]
10002a5f8: f901c3e8    	str	x8, [sp, #0x380]
10002a5fc: 3ccb8120    	ldur	q0, [x9, #0xb8]
10002a600: 3d80e7e0    	str	q0, [sp, #0x390]
10002a604: f84c8128    	ldur	x8, [x9, #0xc8]
10002a608: f901d3e8    	str	x8, [sp, #0x3a0]
10002a60c: 3dc04120    	ldr	q0, [x9, #0x100]
10002a610: 3d80efe0    	str	q0, [sp, #0x3b0]
10002a614: f9408928    	ldr	x8, [x9, #0x110]
10002a618: f901e3e8    	str	x8, [sp, #0x3c0]
10002a61c: f84f8128    	ldur	x8, [x9, #0xf8]
10002a620: f901f3e8    	str	x8, [sp, #0x3e0]
10002a624: 3cce8120    	ldur	q0, [x9, #0xe8]
10002a628: 3d80f7e0    	str	q0, [sp, #0x3d0]
10002a62c: eb11015f    	cmp	x10, x17
10002a630: 54fe4821    	b.ne	0x100026f34 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8c9c>
10002a634: 14000129    	b	0x10002aad8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc840>
10002a638: aa1703e9    	mov	x9, x23
10002a63c: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002a640: f940abea    	ldr	x10, [sp, #0x150]
10002a644: eb08015f    	cmp	x10, x8
10002a648: 54000100    	b.eq	0x10002a668 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc3d0>
10002a64c: f94147e0    	ldr	x0, [sp, #0x288]
10002a650: f9415fe1    	ldr	x1, [sp, #0x2b8]
10002a654: f94103e2    	ldr	x2, [sp, #0x200]
10002a658: 94001776    	bl	0x100030430 <_roc_cold_shim.roc_builtins_list_slack_unique>
10002a65c: f9414bf6    	ldr	x22, [sp, #0x290]
10002a660: aa0903f7    	mov	x23, x9
10002a664: 17fffebb    	b	0x10002a150 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xbeb8>
10002a668: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002a66c: f940a7ea    	ldr	x10, [sp, #0x148]
10002a670: eb08015f    	cmp	x10, x8
10002a674: 540000c0    	b.eq	0x10002a68c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc3f4>
10002a678: f94147e0    	ldr	x0, [sp, #0x288]
10002a67c: f9415fe1    	ldr	x1, [sp, #0x2b8]
10002a680: f94103e2    	ldr	x2, [sp, #0x200]
10002a684: 9400176b    	bl	0x100030430 <_roc_cold_shim.roc_builtins_list_slack_unique>
10002a688: 17fffff1    	b	0x10002a64c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc3b4>
10002a68c: f94103e8    	ldr	x8, [sp, #0x200]
10002a690: 37000168    	tbnz	w8, #0x0, 0x10002a6bc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc424>
10002a694: f94103e8    	ldr	x8, [sp, #0x200]
10002a698: d341fd08    	lsr	x8, x8, #1
10002a69c: f9415fea    	ldr	x10, [sp, #0x2b8]
10002a6a0: eb0a011f    	cmp	x8, x10
10002a6a4: 540000c0    	b.eq	0x10002a6bc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc424>
10002a6a8: f94147e0    	ldr	x0, [sp, #0x288]
10002a6ac: f9415fe1    	ldr	x1, [sp, #0x2b8]
10002a6b0: f94103e2    	ldr	x2, [sp, #0x200]
10002a6b4: 9400175f    	bl	0x100030430 <_roc_cold_shim.roc_builtins_list_slack_unique>
10002a6b8: 17fffff0    	b	0x10002a678 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc3e0>
10002a6bc: f94147e0    	ldr	x0, [sp, #0x288]
10002a6c0: f9415fe1    	ldr	x1, [sp, #0x2b8]
10002a6c4: f94103e2    	ldr	x2, [sp, #0x200]
10002a6c8: 52800023    	mov	w3, #0x1                ; =1
10002a6cc: 52800104    	mov	w4, #0x8                ; =8
10002a6d0: 52800025    	mov	w5, #0x1                ; =1
10002a6d4: 94001701    	bl	0x1000302d8 <_roc_cold_shim.roc_builtins_list_reserve_for_append>
10002a6d8: f90147e0    	str	x0, [sp, #0x288]
10002a6dc: f9015fe1    	str	x1, [sp, #0x2b8]
10002a6e0: f90103e2    	str	x2, [sp, #0x200]
10002a6e4: 17fffff1    	b	0x10002a6a8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc410>
10002a6e8: 10048740    	adr	x0, 0x1000337d0 <_.roc.bytes.4>
10002a6ec: d503201f    	nop
10002a6f0: 52800361    	mov	w1, #0x1b               ; =27
10002a6f4: 97ff60e3    	bl	0x100002a80 <_roc_crashed>
10002a6f8: d4200020    	brk	#0x1
10002a6fc: 100485a0    	adr	x0, 0x1000337b0 <_.roc.bytes.3>
10002a700: d503201f    	nop
10002a704: 528003c1    	mov	w1, #0x1e               ; =30
10002a708: 97ff60de    	bl	0x100002a80 <_roc_crashed>
10002a70c: d4200020    	brk	#0x1
10002a710: 912043fa    	add	x26, sp, #0x810
10002a714: 3cce8340    	ldur	q0, [x26, #0xe8]
10002a718: 3d8763e0    	str	q0, [sp, #0x1d80]
10002a71c: f84f8348    	ldur	x8, [x26, #0xf8]
10002a720: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a724: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a728: 91360000    	add	x0, x0, #0xd80
10002a72c: aa0a03f9    	mov	x25, x10
10002a730: 940016a4    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a734: 3dc04340    	ldr	q0, [x26, #0x100]
10002a738: 3d8763e0    	str	q0, [sp, #0x1d80]
10002a73c: f9408b48    	ldr	x8, [x26, #0x110]
10002a740: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a744: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a748: 91360000    	add	x0, x0, #0xd80
10002a74c: 9400169d    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a750: 3ccb8340    	ldur	q0, [x26, #0xb8]
10002a754: 3d8763e0    	str	q0, [sp, #0x1d80]
10002a758: f84c8348    	ldur	x8, [x26, #0xc8]
10002a75c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a760: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a764: 91360000    	add	x0, x0, #0xd80
10002a768: 94001696    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a76c: 3ccd0340    	ldur	q0, [x26, #0xd0]
10002a770: 3d8763e0    	str	q0, [sp, #0x1d80]
10002a774: f84e0348    	ldur	x8, [x26, #0xe0]
10002a778: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a77c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a780: 91360000    	add	x0, x0, #0xd80
10002a784: 9400168f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a788: f90ec3f6    	str	x22, [sp, #0x1d80]
10002a78c: f90ec7f7    	str	x23, [sp, #0x1d88]
10002a790: f9415be8    	ldr	x8, [sp, #0x2b0]
10002a794: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a798: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a79c: 91360000    	add	x0, x0, #0xd80
10002a7a0: 94001688    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a7a4: f9418be8    	ldr	x8, [sp, #0x310]
10002a7a8: f90ec3e8    	str	x8, [sp, #0x1d80]
10002a7ac: f90ec7f8    	str	x24, [sp, #0x1d88]
10002a7b0: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002a7b4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a7b8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a7bc: 91360000    	add	x0, x0, #0xd80
10002a7c0: 94001680    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a7c4: f9418fe8    	ldr	x8, [sp, #0x318]
10002a7c8: f90ec3e8    	str	x8, [sp, #0x1d80]
10002a7cc: f90ec7f9    	str	x25, [sp, #0x1d88]
10002a7d0: f94163e8    	ldr	x8, [sp, #0x2c0]
10002a7d4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a7d8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a7dc: 91360000    	add	x0, x0, #0xd80
10002a7e0: 94001678    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a7e4: f94133e8    	ldr	x8, [sp, #0x260]
10002a7e8: f90ec3e8    	str	x8, [sp, #0x1d80]
10002a7ec: f90ec7f3    	str	x19, [sp, #0x1d88]
10002a7f0: f90ecbf5    	str	x21, [sp, #0x1d90]
10002a7f4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a7f8: 91360000    	add	x0, x0, #0xd80
10002a7fc: 94001671    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a800: f940dfe8    	ldr	x8, [sp, #0x1b8]
10002a804: b4001648    	cbz	x8, 0x10002aacc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc834>
10002a808: f9417ff9    	ldr	x25, [sp, #0x2f8]
10002a80c: f94143fa    	ldr	x26, [sp, #0x280]
10002a810: 350153f4    	cbnz	w20, 0x10002d28c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeff4>
10002a814: f940dbe8    	ldr	x8, [sp, #0x1b0]
10002a818: 17ffefbf    	b	0x100026714 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x847c>
10002a81c: 52802068    	mov	w8, #0x103              ; =259
10002a820: f9418fe9    	ldr	x9, [sp, #0x318]
10002a824: f90ec3e9    	str	x9, [sp, #0x1d80]
10002a828: f90ec7e8    	str	x8, [sp, #0x1d88]
10002a82c: 52804348    	mov	w8, #0x21a              ; =538
10002a830: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a834: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a838: 91360000    	add	x0, x0, #0xd80
10002a83c: aa0703f3    	mov	x19, x7
10002a840: 94001660    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a844: 52800148    	mov	w8, #0xa                ; =10
10002a848: f94193e9    	ldr	x9, [sp, #0x320]
10002a84c: f90ec3e9    	str	x9, [sp, #0x1d80]
10002a850: f90ec7e8    	str	x8, [sp, #0x1d88]
10002a854: 52800508    	mov	w8, #0x28               ; =40
10002a858: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a85c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a860: 91360000    	add	x0, x0, #0xd80
10002a864: 94001657    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a868: 52a00088    	mov	w8, #0x40000            ; =262144
10002a86c: f90ec3f3    	str	x19, [sp, #0x1d80]
10002a870: f90ec7e8    	str	x8, [sp, #0x1d88]
10002a874: f941b3e8    	ldr	x8, [sp, #0x360]
10002a878: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a87c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a880: 91360000    	add	x0, x0, #0xd80
10002a884: 9400164f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a888: f941afe8    	ldr	x8, [sp, #0x358]
10002a88c: f90ec3e8    	str	x8, [sp, #0x1d80]
10002a890: 529cac28    	mov	w8, #0xe561             ; =58721
10002a894: 72a002c8    	movk	w8, #0x16, lsl #16
10002a898: f90ec7e8    	str	x8, [sp, #0x1d88]
10002a89c: 52995ac8    	mov	w8, #0xcad6             ; =51926
10002a8a0: 72a005a8    	movk	w8, #0x2d, lsl #16
10002a8a4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a8a8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a8ac: 91360000    	add	x0, x0, #0xd80
10002a8b0: 94001644    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a8b4: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002a8b8: f90ec3e8    	str	x8, [sp, #0x1d80]
10002a8bc: f94163e8    	ldr	x8, [sp, #0x2c0]
10002a8c0: f90ec7e8    	str	x8, [sp, #0x1d88]
10002a8c4: f940dfe8    	ldr	x8, [sp, #0x1b8]
10002a8c8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a8cc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a8d0: 91360000    	add	x0, x0, #0xd80
10002a8d4: 9400163b    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a8d8: f94123e8    	ldr	x8, [sp, #0x240]
10002a8dc: f90ec3e8    	str	x8, [sp, #0x1d80]
10002a8e0: f94147e8    	ldr	x8, [sp, #0x288]
10002a8e4: f90ec7e8    	str	x8, [sp, #0x1d88]
10002a8e8: f940b3e8    	ldr	x8, [sp, #0x160]
10002a8ec: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a8f0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a8f4: 91360000    	add	x0, x0, #0xd80
10002a8f8: 94001632    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a8fc: f940bbe8    	ldr	x8, [sp, #0x170]
10002a900: f90ec3e8    	str	x8, [sp, #0x1d80]
10002a904: f940c3e8    	ldr	x8, [sp, #0x180]
10002a908: f90ec7e8    	str	x8, [sp, #0x1d88]
10002a90c: f940b7e8    	ldr	x8, [sp, #0x168]
10002a910: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a914: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a918: 91360000    	add	x0, x0, #0xd80
10002a91c: 94001629    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a920: 3dc30fe0    	ldr	q0, [sp, #0xc30]
10002a924: 3d8763e0    	str	q0, [sp, #0x1d80]
10002a928: f94623e8    	ldr	x8, [sp, #0xc40]
10002a92c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a930: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a934: 91360000    	add	x0, x0, #0xd80
10002a938: 94001622    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a93c: 3dc307e0    	ldr	q0, [sp, #0xc10]
10002a940: 3d8763e0    	str	q0, [sp, #0x1d80]
10002a944: f94613e8    	ldr	x8, [sp, #0xc20]
10002a948: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a94c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a950: 91360000    	add	x0, x0, #0xd80
10002a954: 9400161b    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a958: 3dc2ffe0    	ldr	q0, [sp, #0xbf0]
10002a95c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002a960: f94603e8    	ldr	x8, [sp, #0xc00]
10002a964: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a968: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a96c: 91360000    	add	x0, x0, #0xd80
10002a970: 94001614    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a974: 3dc2f7e0    	ldr	q0, [sp, #0xbd0]
10002a978: 3d8763e0    	str	q0, [sp, #0x1d80]
10002a97c: f945f3e8    	ldr	x8, [sp, #0xbe0]
10002a980: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a984: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a988: 91360000    	add	x0, x0, #0xd80
10002a98c: 9400160d    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a990: f94143e8    	ldr	x8, [sp, #0x280]
10002a994: f90ec3e8    	str	x8, [sp, #0x1d80]
10002a998: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002a99c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002a9a0: f9414be8    	ldr	x8, [sp, #0x290]
10002a9a4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a9a8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a9ac: 91360000    	add	x0, x0, #0xd80
10002a9b0: 94001604    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a9b4: f940d7e8    	ldr	x8, [sp, #0x1a8]
10002a9b8: f90ec3e8    	str	x8, [sp, #0x1d80]
10002a9bc: f940cbe8    	ldr	x8, [sp, #0x190]
10002a9c0: f90ec7e8    	str	x8, [sp, #0x1d88]
10002a9c4: f940dbe8    	ldr	x8, [sp, #0x1b0]
10002a9c8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a9cc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a9d0: 91360000    	add	x0, x0, #0xd80
10002a9d4: 940015fb    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a9d8: 3dc2efe0    	ldr	q0, [sp, #0xbb0]
10002a9dc: 3d8763e0    	str	q0, [sp, #0x1d80]
10002a9e0: f945e3e8    	ldr	x8, [sp, #0xbc0]
10002a9e4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002a9e8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002a9ec: 91360000    	add	x0, x0, #0xd80
10002a9f0: 940015f4    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002a9f4: 3dc2e7e0    	ldr	q0, [sp, #0xb90]
10002a9f8: 3d8763e0    	str	q0, [sp, #0x1d80]
10002a9fc: f945d3e8    	ldr	x8, [sp, #0xba0]
10002aa00: f90ecbe8    	str	x8, [sp, #0x1d90]
10002aa04: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002aa08: 91360000    	add	x0, x0, #0xd80
10002aa0c: 940015ed    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002aa10: 3dc2dfe0    	ldr	q0, [sp, #0xb70]
10002aa14: 3d8763e0    	str	q0, [sp, #0x1d80]
10002aa18: f945c3e8    	ldr	x8, [sp, #0xb80]
10002aa1c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002aa20: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002aa24: 91360000    	add	x0, x0, #0xd80
10002aa28: 940015e6    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002aa2c: 3dc2d7e0    	ldr	q0, [sp, #0xb50]
10002aa30: 3d8763e0    	str	q0, [sp, #0x1d80]
10002aa34: f945b3e8    	ldr	x8, [sp, #0xb60]
10002aa38: f90ecbe8    	str	x8, [sp, #0x1d90]
10002aa3c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002aa40: 91360000    	add	x0, x0, #0xd80
10002aa44: 940015df    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002aa48: 3dc2cfe0    	ldr	q0, [sp, #0xb30]
10002aa4c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002aa50: f945a3e8    	ldr	x8, [sp, #0xb40]
10002aa54: f90ecbe8    	str	x8, [sp, #0x1d90]
10002aa58: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002aa5c: 91360000    	add	x0, x0, #0xd80
10002aa60: 940015d8    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002aa64: 3dc2c7e0    	ldr	q0, [sp, #0xb10]
10002aa68: 3d8763e0    	str	q0, [sp, #0x1d80]
10002aa6c: f94593e8    	ldr	x8, [sp, #0xb20]
10002aa70: f90ecbe8    	str	x8, [sp, #0x1d90]
10002aa74: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002aa78: 91360000    	add	x0, x0, #0xd80
10002aa7c: 940015d1    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002aa80: f940ebe8    	ldr	x8, [sp, #0x1d0]
10002aa84: f90ec3e8    	str	x8, [sp, #0x1d80]
10002aa88: f94103e8    	ldr	x8, [sp, #0x200]
10002aa8c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002aa90: f940fbe8    	ldr	x8, [sp, #0x1f0]
10002aa94: f90ecbe8    	str	x8, [sp, #0x1d90]
10002aa98: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002aa9c: 91360000    	add	x0, x0, #0xd80
10002aaa0: 940015c8    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002aaa4: 10049560    	adr	x0, 0x100033d50 <_.roc.bytes.32>
10002aaa8: d503201f    	nop
10002aaac: 52800721    	mov	w1, #0x39               ; =57
10002aab0: 940016e7    	bl	0x10003064c <_roc_cold_shim.roc_builtins_str_from_literal>
10002aab4: f90aefe0    	str	x0, [sp, #0x15d8]
10002aab8: f90af3e1    	str	x1, [sp, #0x15e0]
10002aabc: f90af7e2    	str	x2, [sp, #0x15e8]
10002aac0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002aac4: 91176000    	add	x0, x0, #0x5d8
10002aac8: 940016ff    	bl	0x1000306c4 <_roc_cold_shim.roc_builtins_crash_str>
10002aacc: f9417ff9    	ldr	x25, [sp, #0x2f8]
10002aad0: f94143fa    	ldr	x26, [sp, #0x280]
10002aad4: 140001b1    	b	0x10002b198 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xcf00>
10002aad8: 910fc3f6    	add	x22, sp, #0x3f0
10002aadc: 3cce82c0    	ldur	q0, [x22, #0xe8]
10002aae0: 3d8763e0    	str	q0, [sp, #0x1d80]
10002aae4: f84f82c8    	ldur	x8, [x22, #0xf8]
10002aae8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002aaec: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002aaf0: 91360000    	add	x0, x0, #0xd80
10002aaf4: aa0b03f7    	mov	x23, x11
10002aaf8: 940015b2    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002aafc: 3dc042c0    	ldr	q0, [x22, #0x100]
10002ab00: 3d8763e0    	str	q0, [sp, #0x1d80]
10002ab04: f9408ac8    	ldr	x8, [x22, #0x110]
10002ab08: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ab0c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ab10: 91360000    	add	x0, x0, #0xd80
10002ab14: 940015ab    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ab18: 3ccb82c0    	ldur	q0, [x22, #0xb8]
10002ab1c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002ab20: f84c82c8    	ldur	x8, [x22, #0xc8]
10002ab24: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ab28: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ab2c: 91360000    	add	x0, x0, #0xd80
10002ab30: 940015a4    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ab34: 3ccd02c0    	ldur	q0, [x22, #0xd0]
10002ab38: 3d8763e0    	str	q0, [sp, #0x1d80]
10002ab3c: f84e02c8    	ldur	x8, [x22, #0xe0]
10002ab40: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ab44: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ab48: 91360000    	add	x0, x0, #0xd80
10002ab4c: 9400159d    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ab50: f90ec3f8    	str	x24, [sp, #0x1d80]
10002ab54: f90ec7fa    	str	x26, [sp, #0x1d88]
10002ab58: f941a7e8    	ldr	x8, [sp, #0x348]
10002ab5c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ab60: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ab64: 91360000    	add	x0, x0, #0xd80
10002ab68: 94001596    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ab6c: f90ec3f9    	str	x25, [sp, #0x1d80]
10002ab70: f90ec7f7    	str	x23, [sp, #0x1d88]
10002ab74: f941abe8    	ldr	x8, [sp, #0x350]
10002ab78: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ab7c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ab80: 91360000    	add	x0, x0, #0xd80
10002ab84: 9400158f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ab88: f90ec3f5    	str	x21, [sp, #0x1d80]
10002ab8c: f90ec7fc    	str	x28, [sp, #0x1d88]
10002ab90: f941afe8    	ldr	x8, [sp, #0x358]
10002ab94: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ab98: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ab9c: 91360000    	add	x0, x0, #0xd80
10002aba0: 94001588    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002aba4: f94147e8    	ldr	x8, [sp, #0x288]
10002aba8: f90ec3e8    	str	x8, [sp, #0x1d80]
10002abac: f90ec7f3    	str	x19, [sp, #0x1d88]
10002abb0: f94103e8    	ldr	x8, [sp, #0x200]
10002abb4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002abb8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002abbc: 91360000    	add	x0, x0, #0xd80
10002abc0: 94001580    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002abc4: f940dbe8    	ldr	x8, [sp, #0x1b0]
10002abc8: b4003068    	cbz	x8, 0x10002b1d4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xcf3c>
10002abcc: f94143fa    	ldr	x26, [sp, #0x280]
10002abd0: f9417ff9    	ldr	x25, [sp, #0x2f8]
10002abd4: 3501a034    	cbnz	w20, 0x10002dfd8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xfd40>
10002abd8: f940d7e8    	ldr	x8, [sp, #0x1a8]
10002abdc: 17ffeece    	b	0x100026714 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x847c>
10002abe0: f90ec3ea    	str	x10, [sp, #0x1d80]
10002abe4: f90ec7e9    	str	x9, [sp, #0x1d88]
10002abe8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002abec: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002abf0: 91360000    	add	x0, x0, #0xd80
10002abf4: 94001573    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002abf8: 9132c3f3    	add	x19, sp, #0xcb0
10002abfc: 3cce8260    	ldur	q0, [x19, #0xe8]
10002ac00: 3d8763e0    	str	q0, [sp, #0x1d80]
10002ac04: f84f8268    	ldur	x8, [x19, #0xf8]
10002ac08: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ac0c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ac10: 91360000    	add	x0, x0, #0xd80
10002ac14: 9400156b    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ac18: 3dc04260    	ldr	q0, [x19, #0x100]
10002ac1c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002ac20: f9408a68    	ldr	x8, [x19, #0x110]
10002ac24: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ac28: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ac2c: 91360000    	add	x0, x0, #0xd80
10002ac30: 94001564    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ac34: 3ccb8260    	ldur	q0, [x19, #0xb8]
10002ac38: 3d8763e0    	str	q0, [sp, #0x1d80]
10002ac3c: f84c8268    	ldur	x8, [x19, #0xc8]
10002ac40: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ac44: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ac48: 91360000    	add	x0, x0, #0xd80
10002ac4c: 9400155d    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ac50: 3ccd0260    	ldur	q0, [x19, #0xd0]
10002ac54: 3d8763e0    	str	q0, [sp, #0x1d80]
10002ac58: f84e0268    	ldur	x8, [x19, #0xe0]
10002ac5c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ac60: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ac64: 91360000    	add	x0, x0, #0xd80
10002ac68: 94001556    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ac6c: f940d7e8    	ldr	x8, [sp, #0x1a8]
10002ac70: f90ec3e8    	str	x8, [sp, #0x1d80]
10002ac74: f940cbe8    	ldr	x8, [sp, #0x190]
10002ac78: f90ec7e8    	str	x8, [sp, #0x1d88]
10002ac7c: f940dbe8    	ldr	x8, [sp, #0x1b0]
10002ac80: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ac84: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ac88: 91360000    	add	x0, x0, #0xd80
10002ac8c: 9400154d    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ac90: 3dc327e0    	ldr	q0, [sp, #0xc90]
10002ac94: 3d8763e0    	str	q0, [sp, #0x1d80]
10002ac98: f94653e8    	ldr	x8, [sp, #0xca0]
10002ac9c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002aca0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002aca4: 91360000    	add	x0, x0, #0xd80
10002aca8: 94001546    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002acac: 3dc31fe0    	ldr	q0, [sp, #0xc70]
10002acb0: 3d8763e0    	str	q0, [sp, #0x1d80]
10002acb4: f94643e8    	ldr	x8, [sp, #0xc80]
10002acb8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002acbc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002acc0: 91360000    	add	x0, x0, #0xd80
10002acc4: 9400153f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002acc8: 3dc317e0    	ldr	q0, [sp, #0xc50]
10002accc: 3d8763e0    	str	q0, [sp, #0x1d80]
10002acd0: f94633e8    	ldr	x8, [sp, #0xc60]
10002acd4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002acd8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002acdc: 91360000    	add	x0, x0, #0xd80
10002ace0: 94001538    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ace4: 3dc6e3e0    	ldr	q0, [sp, #0x1b80]
10002ace8: 3d8763e0    	str	q0, [sp, #0x1d80]
10002acec: f94dcbe8    	ldr	x8, [sp, #0x1b90]
10002acf0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002acf4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002acf8: 91360000    	add	x0, x0, #0xd80
10002acfc: 94001531    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ad00: 3dc6dbe0    	ldr	q0, [sp, #0x1b60]
10002ad04: 3d8763e0    	str	q0, [sp, #0x1d80]
10002ad08: f94dbbe8    	ldr	x8, [sp, #0x1b70]
10002ad0c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ad10: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ad14: 91360000    	add	x0, x0, #0xd80
10002ad18: 9400152a    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ad1c: 3dc6d3e0    	ldr	q0, [sp, #0x1b40]
10002ad20: 3d8763e0    	str	q0, [sp, #0x1d80]
10002ad24: f94dabe8    	ldr	x8, [sp, #0x1b50]
10002ad28: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ad2c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ad30: 91360000    	add	x0, x0, #0xd80
10002ad34: 94001523    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ad38: f940ebe8    	ldr	x8, [sp, #0x1d0]
10002ad3c: f90ec3e8    	str	x8, [sp, #0x1d80]
10002ad40: f94103e8    	ldr	x8, [sp, #0x200]
10002ad44: f90ec7e8    	str	x8, [sp, #0x1d88]
10002ad48: f940fbe8    	ldr	x8, [sp, #0x1f0]
10002ad4c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ad50: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ad54: 91360000    	add	x0, x0, #0xd80
10002ad58: 9400151a    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ad5c: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002ad60: f90ec3e8    	str	x8, [sp, #0x1d80]
10002ad64: f94163e8    	ldr	x8, [sp, #0x2c0]
10002ad68: f90ec7e8    	str	x8, [sp, #0x1d88]
10002ad6c: f940dfe8    	ldr	x8, [sp, #0x1b8]
10002ad70: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ad74: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ad78: 91360000    	add	x0, x0, #0xd80
10002ad7c: 94001511    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ad80: f90ec3f5    	str	x21, [sp, #0x1d80]
10002ad84: f90ec7fc    	str	x28, [sp, #0x1d88]
10002ad88: f90ecbf8    	str	x24, [sp, #0x1d90]
10002ad8c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ad90: 91360000    	add	x0, x0, #0xd80
10002ad94: 9400150b    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ad98: f9418fe8    	ldr	x8, [sp, #0x318]
10002ad9c: f90ec3e8    	str	x8, [sp, #0x1d80]
10002ada0: 914007f3    	add	x19, sp, #0x1, lsl #12  ; =0x1000
10002ada4: 91360273    	add	x19, x19, #0xd80
10002ada8: 3dc02fe0    	ldr	q0, [sp, #0xb0]
10002adac: 3c808260    	stur	q0, [x19, #0x8]
10002adb0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002adb4: 91360000    	add	x0, x0, #0xd80
10002adb8: 94001502    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002adbc: f94193e8    	ldr	x8, [sp, #0x320]
10002adc0: f90ec3e8    	str	x8, [sp, #0x1d80]
10002adc4: 3dc033e0    	ldr	q0, [sp, #0xc0]
10002adc8: 3c808260    	stur	q0, [x19, #0x8]
10002adcc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002add0: 91360000    	add	x0, x0, #0xd80
10002add4: 940014fb    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002add8: f941afe8    	ldr	x8, [sp, #0x358]
10002addc: f90ec3e8    	str	x8, [sp, #0x1d80]
10002ade0: 3dc0bbe0    	ldr	q0, [sp, #0x2e0]
10002ade4: 3c808260    	stur	q0, [x19, #0x8]
10002ade8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002adec: 91360000    	add	x0, x0, #0xd80
10002adf0: 940014f4    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002adf4: 52a00088    	mov	w8, #0x40000            ; =262144
10002adf8: f94113e9    	ldr	x9, [sp, #0x220]
10002adfc: f90ec3e9    	str	x9, [sp, #0x1d80]
10002ae00: f90ec7e8    	str	x8, [sp, #0x1d88]
10002ae04: f941b3e8    	ldr	x8, [sp, #0x360]
10002ae08: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ae0c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ae10: 91360000    	add	x0, x0, #0xd80
10002ae14: 940014eb    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ae18: f940a7e8    	ldr	x8, [sp, #0x148]
10002ae1c: b4001da8    	cbz	x8, 0x10002b1d0 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xcf38>
10002ae20: f9414bfb    	ldr	x27, [sp, #0x290]
10002ae24: f94143fa    	ldr	x26, [sp, #0x280]
10002ae28: f9417ff9    	ldr	x25, [sp, #0x2f8]
10002ae2c: 3501a8f4    	cbnz	w20, 0x10002e348 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x100b0>
10002ae30: f9409be8    	ldr	x8, [sp, #0x130]
10002ae34: 17ffee38    	b	0x100026714 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x847c>
10002ae38: 52a00088    	mov	w8, #0x40000            ; =262144
10002ae3c: f904d3e7    	str	x7, [sp, #0x9a0]
10002ae40: f904d7e8    	str	x8, [sp, #0x9a8]
10002ae44: f941b3e8    	ldr	x8, [sp, #0x360]
10002ae48: f904dbe8    	str	x8, [sp, #0x9b0]
10002ae4c: 912683e0    	add	x0, sp, #0x9a0
10002ae50: 940014dc    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ae54: f941afe8    	ldr	x8, [sp, #0x358]
10002ae58: f904d3e8    	str	x8, [sp, #0x9a0]
10002ae5c: 529cac28    	mov	w8, #0xe561             ; =58721
10002ae60: 72a002c8    	movk	w8, #0x16, lsl #16
10002ae64: f904d7e8    	str	x8, [sp, #0x9a8]
10002ae68: 52995ac8    	mov	w8, #0xcad6             ; =51926
10002ae6c: 72a005a8    	movk	w8, #0x2d, lsl #16
10002ae70: f904dbe8    	str	x8, [sp, #0x9b0]
10002ae74: 912683e0    	add	x0, sp, #0x9a0
10002ae78: 940014d2    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ae7c: 1004a9a0    	adr	x0, 0x1000343b0 <_.roc.bytes.69>
10002ae80: d503201f    	nop
10002ae84: 52800741    	mov	w1, #0x3a               ; =58
10002ae88: 140007c3    	b	0x10002cd94 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeafc>
10002ae8c: 52802068    	mov	w8, #0x103              ; =259
10002ae90: f9418fe9    	ldr	x9, [sp, #0x318]
10002ae94: f90ec3e9    	str	x9, [sp, #0x1d80]
10002ae98: f90ec7e8    	str	x8, [sp, #0x1d88]
10002ae9c: 52804348    	mov	w8, #0x21a              ; =538
10002aea0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002aea4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002aea8: 91360000    	add	x0, x0, #0xd80
10002aeac: aa0703f3    	mov	x19, x7
10002aeb0: 940014c4    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002aeb4: 52800148    	mov	w8, #0xa                ; =10
10002aeb8: f90ec3f9    	str	x25, [sp, #0x1d80]
10002aebc: f90ec7e8    	str	x8, [sp, #0x1d88]
10002aec0: 52800508    	mov	w8, #0x28               ; =40
10002aec4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002aec8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002aecc: 91360000    	add	x0, x0, #0xd80
10002aed0: 940014bc    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002aed4: f941afe8    	ldr	x8, [sp, #0x358]
10002aed8: f90ec3e8    	str	x8, [sp, #0x1d80]
10002aedc: 529cac28    	mov	w8, #0xe561             ; =58721
10002aee0: 72a002c8    	movk	w8, #0x16, lsl #16
10002aee4: f90ec7e8    	str	x8, [sp, #0x1d88]
10002aee8: 52995ac8    	mov	w8, #0xcad6             ; =51926
10002aeec: 72a005a8    	movk	w8, #0x2d, lsl #16
10002aef0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002aef4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002aef8: 91360000    	add	x0, x0, #0xd80
10002aefc: 940014b1    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002af00: 52a00088    	mov	w8, #0x40000            ; =262144
10002af04: f90ec3f3    	str	x19, [sp, #0x1d80]
10002af08: f90ec7e8    	str	x8, [sp, #0x1d88]
10002af0c: f941b3e8    	ldr	x8, [sp, #0x360]
10002af10: f90ecbe8    	str	x8, [sp, #0x1d90]
10002af14: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002af18: 91360000    	add	x0, x0, #0xd80
10002af1c: 940014a9    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002af20: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002af24: f90ec3e8    	str	x8, [sp, #0x1d80]
10002af28: f94163e8    	ldr	x8, [sp, #0x2c0]
10002af2c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002af30: f940dfe8    	ldr	x8, [sp, #0x1b8]
10002af34: f90ecbe8    	str	x8, [sp, #0x1d90]
10002af38: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002af3c: 91360000    	add	x0, x0, #0xd80
10002af40: 940014a0    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002af44: f94123e8    	ldr	x8, [sp, #0x240]
10002af48: f90ec3e8    	str	x8, [sp, #0x1d80]
10002af4c: f94147e8    	ldr	x8, [sp, #0x288]
10002af50: f90ec7e8    	str	x8, [sp, #0x1d88]
10002af54: f940b3e8    	ldr	x8, [sp, #0x160]
10002af58: f90ecbe8    	str	x8, [sp, #0x1d90]
10002af5c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002af60: 91360000    	add	x0, x0, #0xd80
10002af64: 94001497    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002af68: f940bbe8    	ldr	x8, [sp, #0x170]
10002af6c: f90ec3e8    	str	x8, [sp, #0x1d80]
10002af70: f940c3e8    	ldr	x8, [sp, #0x180]
10002af74: f90ec7e8    	str	x8, [sp, #0x1d88]
10002af78: f940b7e8    	ldr	x8, [sp, #0x168]
10002af7c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002af80: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002af84: 91360000    	add	x0, x0, #0xd80
10002af88: 9400148e    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002af8c: 3dc30fe0    	ldr	q0, [sp, #0xc30]
10002af90: 3d8763e0    	str	q0, [sp, #0x1d80]
10002af94: f94623e8    	ldr	x8, [sp, #0xc40]
10002af98: f90ecbe8    	str	x8, [sp, #0x1d90]
10002af9c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002afa0: 91360000    	add	x0, x0, #0xd80
10002afa4: 94001487    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002afa8: 3dc307e0    	ldr	q0, [sp, #0xc10]
10002afac: 3d8763e0    	str	q0, [sp, #0x1d80]
10002afb0: f94613e8    	ldr	x8, [sp, #0xc20]
10002afb4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002afb8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002afbc: 91360000    	add	x0, x0, #0xd80
10002afc0: 94001480    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002afc4: 3dc2ffe0    	ldr	q0, [sp, #0xbf0]
10002afc8: 3d8763e0    	str	q0, [sp, #0x1d80]
10002afcc: f94603e8    	ldr	x8, [sp, #0xc00]
10002afd0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002afd4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002afd8: 91360000    	add	x0, x0, #0xd80
10002afdc: 94001479    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002afe0: 3dc2f7e0    	ldr	q0, [sp, #0xbd0]
10002afe4: 3d8763e0    	str	q0, [sp, #0x1d80]
10002afe8: f945f3e8    	ldr	x8, [sp, #0xbe0]
10002afec: f90ecbe8    	str	x8, [sp, #0x1d90]
10002aff0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002aff4: 91360000    	add	x0, x0, #0xd80
10002aff8: 94001472    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002affc: f94143e8    	ldr	x8, [sp, #0x280]
10002b000: f90ec3e8    	str	x8, [sp, #0x1d80]
10002b004: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002b008: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b00c: f9414be8    	ldr	x8, [sp, #0x290]
10002b010: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b014: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b018: 91360000    	add	x0, x0, #0xd80
10002b01c: 94001469    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b020: f940d7e8    	ldr	x8, [sp, #0x1a8]
10002b024: f90ec3e8    	str	x8, [sp, #0x1d80]
10002b028: f940cbe8    	ldr	x8, [sp, #0x190]
10002b02c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b030: f940dbe8    	ldr	x8, [sp, #0x1b0]
10002b034: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b038: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b03c: 91360000    	add	x0, x0, #0xd80
10002b040: 94001460    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b044: 3dc2efe0    	ldr	q0, [sp, #0xbb0]
10002b048: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b04c: f945e3e8    	ldr	x8, [sp, #0xbc0]
10002b050: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b054: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b058: 91360000    	add	x0, x0, #0xd80
10002b05c: 94001459    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b060: 3dc2e7e0    	ldr	q0, [sp, #0xb90]
10002b064: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b068: f945d3e8    	ldr	x8, [sp, #0xba0]
10002b06c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b070: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b074: 91360000    	add	x0, x0, #0xd80
10002b078: 94001452    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b07c: 3dc2dfe0    	ldr	q0, [sp, #0xb70]
10002b080: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b084: f945c3e8    	ldr	x8, [sp, #0xb80]
10002b088: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b08c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b090: 91360000    	add	x0, x0, #0xd80
10002b094: 9400144b    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b098: 3dc2d7e0    	ldr	q0, [sp, #0xb50]
10002b09c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b0a0: f945b3e8    	ldr	x8, [sp, #0xb60]
10002b0a4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b0a8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b0ac: 91360000    	add	x0, x0, #0xd80
10002b0b0: 94001444    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b0b4: 3dc2cfe0    	ldr	q0, [sp, #0xb30]
10002b0b8: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b0bc: f945a3e8    	ldr	x8, [sp, #0xb40]
10002b0c0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b0c4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b0c8: 91360000    	add	x0, x0, #0xd80
10002b0cc: 9400143d    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b0d0: 3dc2c7e0    	ldr	q0, [sp, #0xb10]
10002b0d4: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b0d8: f94593e8    	ldr	x8, [sp, #0xb20]
10002b0dc: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b0e0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b0e4: 91360000    	add	x0, x0, #0xd80
10002b0e8: 94001436    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b0ec: f940ebe8    	ldr	x8, [sp, #0x1d0]
10002b0f0: f90ec3e8    	str	x8, [sp, #0x1d80]
10002b0f4: f94103e8    	ldr	x8, [sp, #0x200]
10002b0f8: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b0fc: f940fbe8    	ldr	x8, [sp, #0x1f0]
10002b100: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b104: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b108: 91360000    	add	x0, x0, #0xd80
10002b10c: 9400142d    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b110: 10046200    	adr	x0, 0x100033d50 <_.roc.bytes.32>
10002b114: d503201f    	nop
10002b118: 52800721    	mov	w1, #0x39               ; =57
10002b11c: 9400154c    	bl	0x10003064c <_roc_cold_shim.roc_builtins_str_from_literal>
10002b120: f90afbe0    	str	x0, [sp, #0x15f0]
10002b124: f90affe1    	str	x1, [sp, #0x15f8]
10002b128: f90b03e2    	str	x2, [sp, #0x1600]
10002b12c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b130: 9117c000    	add	x0, x0, #0x5f0
10002b134: 94001564    	bl	0x1000306c4 <_roc_cold_shim.roc_builtins_crash_str>
10002b138: aa1a03e0    	mov	x0, x26
10002b13c: aa1903e1    	mov	x1, x25
10002b140: aa1b03e2    	mov	x2, x27
10002b144: 9400156c    	bl	0x1000306f4 <_roc_cold_shim.roc_builtins_list_reserve>
10002b148: f941a3ec    	ldr	x12, [sp, #0x340]
10002b14c: f9419feb    	ldr	x11, [sp, #0x338]
10002b150: aa0003fa    	mov	x26, x0
10002b154: aa0103f9    	mov	x25, x1
10002b158: aa0203fb    	mov	x27, x2
10002b15c: b5fa75ec    	cbnz	x12, 0x100020018 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1d80>
10002b160: 37007c3b    	tbnz	w27, #0x0, 0x10002c0e4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xde4c>
10002b164: d341ff68    	lsr	x8, x27, #1
10002b168: eb19011f    	cmp	x8, x25
10002b16c: 54007bc0    	b.eq	0x10002c0e4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xde4c>
10002b170: 52800029    	mov	w9, #0x1                ; =1
10002b174: 38396b49    	strb	w9, [x26, x25]
10002b178: 91000721    	add	x1, x25, #0x1
10002b17c: 37007d3b    	tbnz	w27, #0x0, 0x10002c120 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xde88>
10002b180: 91002729    	add	x9, x25, #0x9
10002b184: eb09011f    	cmp	x8, x9
10002b188: 54007cc3    	b.lo	0x10002c120 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xde88>
10002b18c: 52bfffe8    	mov	w8, #-0x10000           ; =-65536
10002b190: f8216b48    	str	x8, [x26, x1]
10002b194: 91001739    	add	x25, x25, #0x5
10002b198: f9411fe8    	ldr	x8, [sp, #0x238]
10002b19c: a900651a    	stp	x26, x25, [x8]
10002b1a0: f900091b    	str	x27, [x8, #0x10]
10002b1a4: 914007ff    	add	sp, sp, #0x1, lsl #12   ; =0x1000
10002b1a8: 913783ff    	add	sp, sp, #0xde0
10002b1ac: a9477bfd    	ldp	x29, x30, [sp, #0x70]
10002b1b0: a9464ff4    	ldp	x20, x19, [sp, #0x60]
10002b1b4: a94557f6    	ldp	x22, x21, [sp, #0x50]
10002b1b8: a9445ff8    	ldp	x24, x23, [sp, #0x40]
10002b1bc: a94367fa    	ldp	x26, x25, [sp, #0x30]
10002b1c0: a9426ffc    	ldp	x28, x27, [sp, #0x20]
10002b1c4: 6d4123e9    	ldp	d9, d8, [sp, #0x10]
10002b1c8: 6cc82beb    	ldp	d11, d10, [sp], #0x80
10002b1cc: d65f03c0    	ret
10002b1d0: f9414bfb    	ldr	x27, [sp, #0x290]
10002b1d4: f94143fa    	ldr	x26, [sp, #0x280]
10002b1d8: f9417ff9    	ldr	x25, [sp, #0x2f8]
10002b1dc: 17ffffef    	b	0x10002b198 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xcf00>
10002b1e0: f90ec3f8    	str	x24, [sp, #0x1d80]
10002b1e4: f90ec7fa    	str	x26, [sp, #0x1d88]
10002b1e8: f941a7e8    	ldr	x8, [sp, #0x348]
10002b1ec: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b1f0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b1f4: 91360000    	add	x0, x0, #0xd80
10002b1f8: aa0603f4    	mov	x20, x6
10002b1fc: 940013f1    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b200: f90ec3f9    	str	x25, [sp, #0x1d80]
10002b204: f90ec7f4    	str	x20, [sp, #0x1d88]
10002b208: f941abe8    	ldr	x8, [sp, #0x350]
10002b20c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b210: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b214: 91360000    	add	x0, x0, #0xd80
10002b218: 940013ea    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b21c: f90ec3f5    	str	x21, [sp, #0x1d80]
10002b220: f90ec7fc    	str	x28, [sp, #0x1d88]
10002b224: f941afe8    	ldr	x8, [sp, #0x358]
10002b228: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b22c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b230: 91360000    	add	x0, x0, #0xd80
10002b234: 940013e3    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b238: f94147e8    	ldr	x8, [sp, #0x288]
10002b23c: f90ec3e8    	str	x8, [sp, #0x1d80]
10002b240: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002b244: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b248: f94103e8    	ldr	x8, [sp, #0x200]
10002b24c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b250: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b254: 91360000    	add	x0, x0, #0xd80
10002b258: 940013da    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b25c: 528021c8    	mov	w8, #0x10e              ; =270
10002b260: f9412be9    	ldr	x9, [sp, #0x250]
10002b264: f90ec3e9    	str	x9, [sp, #0x1d80]
10002b268: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b26c: 52804608    	mov	w8, #0x230              ; =560
10002b270: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b274: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b278: 91360000    	add	x0, x0, #0xd80
10002b27c: 940013d1    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b280: 52804168    	mov	w8, #0x20b              ; =523
10002b284: f90ec3f3    	str	x19, [sp, #0x1d80]
10002b288: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b28c: 52808548    	mov	w8, #0x42a              ; =1066
10002b290: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b294: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b298: 91360000    	add	x0, x0, #0xd80
10002b29c: 940013c9    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b2a0: 52800148    	mov	w8, #0xa                ; =10
10002b2a4: f940dfe9    	ldr	x9, [sp, #0x1b8]
10002b2a8: f90ec3e9    	str	x9, [sp, #0x1d80]
10002b2ac: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b2b0: 52800508    	mov	w8, #0x28               ; =40
10002b2b4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b2b8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b2bc: 91360000    	add	x0, x0, #0xd80
10002b2c0: 940013c0    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b2c4: 3dc0f7e0    	ldr	q0, [sp, #0x3d0]
10002b2c8: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b2cc: f941f3e8    	ldr	x8, [sp, #0x3e0]
10002b2d0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b2d4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b2d8: 91360000    	add	x0, x0, #0xd80
10002b2dc: 940013b9    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b2e0: 3dc0efe0    	ldr	q0, [sp, #0x3b0]
10002b2e4: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b2e8: f941e3e8    	ldr	x8, [sp, #0x3c0]
10002b2ec: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b2f0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b2f4: 91360000    	add	x0, x0, #0xd80
10002b2f8: 940013b2    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b2fc: 3dc0e7e0    	ldr	q0, [sp, #0x390]
10002b300: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b304: f941d3e8    	ldr	x8, [sp, #0x3a0]
10002b308: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b30c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b310: 91360000    	add	x0, x0, #0xd80
10002b314: 940013ab    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b318: 3dc0dfe0    	ldr	q0, [sp, #0x370]
10002b31c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b320: f941c3e8    	ldr	x8, [sp, #0x380]
10002b324: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b328: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b32c: 91360000    	add	x0, x0, #0xd80
10002b330: 940013a4    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b334: f94143e8    	ldr	x8, [sp, #0x280]
10002b338: f90ec3e8    	str	x8, [sp, #0x1d80]
10002b33c: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002b340: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b344: f9414be8    	ldr	x8, [sp, #0x290]
10002b348: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b34c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b350: 91360000    	add	x0, x0, #0xd80
10002b354: 9400139b    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b358: 100461c0    	adr	x0, 0x100033f90 <_.roc.bytes.46>
10002b35c: d503201f    	nop
10002b360: 528005a1    	mov	w1, #0x2d               ; =45
10002b364: 940014ba    	bl	0x10003064c <_roc_cold_shim.roc_builtins_str_from_literal>
10002b368: f90323e0    	str	x0, [sp, #0x640]
10002b36c: f90327e1    	str	x1, [sp, #0x648]
10002b370: f9032be2    	str	x2, [sp, #0x650]
10002b374: 911903e0    	add	x0, sp, #0x640
10002b378: 940014d3    	bl	0x1000306c4 <_roc_cold_shim.roc_builtins_crash_str>
10002b37c: 52110108    	eor	w8, w8, #0x8000
10002b380: 78297aa8    	strh	w8, [x21, x9, lsl #1]
10002b384: f90ec3f5    	str	x21, [sp, #0x1d80]
10002b388: f90ec7fc    	str	x28, [sp, #0x1d88]
10002b38c: f941afe8    	ldr	x8, [sp, #0x358]
10002b390: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b394: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b398: 91360000    	add	x0, x0, #0xd80
10002b39c: aa0603f4    	mov	x20, x6
10002b3a0: 94001388    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b3a4: f90ec3f8    	str	x24, [sp, #0x1d80]
10002b3a8: f90ec7fa    	str	x26, [sp, #0x1d88]
10002b3ac: f941a7e8    	ldr	x8, [sp, #0x348]
10002b3b0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b3b4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b3b8: 91360000    	add	x0, x0, #0xd80
10002b3bc: 94001381    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b3c0: f90ec3f9    	str	x25, [sp, #0x1d80]
10002b3c4: f90ec7f4    	str	x20, [sp, #0x1d88]
10002b3c8: f941abe8    	ldr	x8, [sp, #0x350]
10002b3cc: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b3d0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b3d4: 91360000    	add	x0, x0, #0xd80
10002b3d8: 9400137a    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b3dc: f94147e8    	ldr	x8, [sp, #0x288]
10002b3e0: f90ec3e8    	str	x8, [sp, #0x1d80]
10002b3e4: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002b3e8: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b3ec: f94103e8    	ldr	x8, [sp, #0x200]
10002b3f0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b3f4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b3f8: 91360000    	add	x0, x0, #0xd80
10002b3fc: 94001371    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b400: 528021c8    	mov	w8, #0x10e              ; =270
10002b404: f9412be9    	ldr	x9, [sp, #0x250]
10002b408: f90ec3e9    	str	x9, [sp, #0x1d80]
10002b40c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b410: 52804608    	mov	w8, #0x230              ; =560
10002b414: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b418: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b41c: 91360000    	add	x0, x0, #0xd80
10002b420: 94001368    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b424: 52804168    	mov	w8, #0x20b              ; =523
10002b428: f90ec3f3    	str	x19, [sp, #0x1d80]
10002b42c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b430: 52808548    	mov	w8, #0x42a              ; =1066
10002b434: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b438: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b43c: 91360000    	add	x0, x0, #0xd80
10002b440: 94001360    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b444: 52800148    	mov	w8, #0xa                ; =10
10002b448: f940dfe9    	ldr	x9, [sp, #0x1b8]
10002b44c: f90ec3e9    	str	x9, [sp, #0x1d80]
10002b450: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b454: 52800508    	mov	w8, #0x28               ; =40
10002b458: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b45c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b460: 91360000    	add	x0, x0, #0xd80
10002b464: 94001357    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b468: 3dc0f7e0    	ldr	q0, [sp, #0x3d0]
10002b46c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b470: f941f3e8    	ldr	x8, [sp, #0x3e0]
10002b474: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b478: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b47c: 91360000    	add	x0, x0, #0xd80
10002b480: 94001350    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b484: 3dc0efe0    	ldr	q0, [sp, #0x3b0]
10002b488: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b48c: f941e3e8    	ldr	x8, [sp, #0x3c0]
10002b490: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b494: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b498: 91360000    	add	x0, x0, #0xd80
10002b49c: 94001349    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b4a0: 3dc0e7e0    	ldr	q0, [sp, #0x390]
10002b4a4: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b4a8: f941d3e8    	ldr	x8, [sp, #0x3a0]
10002b4ac: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b4b0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b4b4: 91360000    	add	x0, x0, #0xd80
10002b4b8: 94001342    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b4bc: 3dc0dfe0    	ldr	q0, [sp, #0x370]
10002b4c0: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b4c4: f941c3e8    	ldr	x8, [sp, #0x380]
10002b4c8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b4cc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b4d0: 91360000    	add	x0, x0, #0xd80
10002b4d4: 9400133b    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b4d8: f94143e8    	ldr	x8, [sp, #0x280]
10002b4dc: f90ec3e8    	str	x8, [sp, #0x1d80]
10002b4e0: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002b4e4: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b4e8: f9414be8    	ldr	x8, [sp, #0x290]
10002b4ec: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b4f0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b4f4: 91360000    	add	x0, x0, #0xd80
10002b4f8: 94001332    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b4fc: 100454a0    	adr	x0, 0x100033f90 <_.roc.bytes.46>
10002b500: d503201f    	nop
10002b504: 528005a1    	mov	w1, #0x2d               ; =45
10002b508: 94001451    	bl	0x10003064c <_roc_cold_shim.roc_builtins_str_from_literal>
10002b50c: f90317e0    	str	x0, [sp, #0x628]
10002b510: f9031be1    	str	x1, [sp, #0x630]
10002b514: f9031fe2    	str	x2, [sp, #0x638]
10002b518: 9118a3e0    	add	x0, sp, #0x628
10002b51c: 9400146a    	bl	0x1000306c4 <_roc_cold_shim.roc_builtins_crash_str>
10002b520: f90ec3f5    	str	x21, [sp, #0x1d80]
10002b524: f90ec7fc    	str	x28, [sp, #0x1d88]
10002b528: f941afe8    	ldr	x8, [sp, #0x358]
10002b52c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b530: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b534: 91360000    	add	x0, x0, #0xd80
10002b538: aa0603f4    	mov	x20, x6
10002b53c: 94001321    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b540: f90ec3f9    	str	x25, [sp, #0x1d80]
10002b544: f90ec7f4    	str	x20, [sp, #0x1d88]
10002b548: f941abe8    	ldr	x8, [sp, #0x350]
10002b54c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b550: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b554: 91360000    	add	x0, x0, #0xd80
10002b558: 9400131a    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b55c: f90ec3f8    	str	x24, [sp, #0x1d80]
10002b560: f90ec7fa    	str	x26, [sp, #0x1d88]
10002b564: f941a7e8    	ldr	x8, [sp, #0x348]
10002b568: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b56c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b570: 91360000    	add	x0, x0, #0xd80
10002b574: 94001313    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b578: f94147e8    	ldr	x8, [sp, #0x288]
10002b57c: f90ec3e8    	str	x8, [sp, #0x1d80]
10002b580: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002b584: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b588: f94103e8    	ldr	x8, [sp, #0x200]
10002b58c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b590: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b594: 91360000    	add	x0, x0, #0xd80
10002b598: 9400130a    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b59c: 528021c8    	mov	w8, #0x10e              ; =270
10002b5a0: f9412be9    	ldr	x9, [sp, #0x250]
10002b5a4: f90ec3e9    	str	x9, [sp, #0x1d80]
10002b5a8: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b5ac: 52804608    	mov	w8, #0x230              ; =560
10002b5b0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b5b4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b5b8: 91360000    	add	x0, x0, #0xd80
10002b5bc: 94001301    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b5c0: 52804168    	mov	w8, #0x20b              ; =523
10002b5c4: f90ec3f3    	str	x19, [sp, #0x1d80]
10002b5c8: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b5cc: 52808548    	mov	w8, #0x42a              ; =1066
10002b5d0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b5d4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b5d8: 91360000    	add	x0, x0, #0xd80
10002b5dc: 940012f9    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b5e0: 52800148    	mov	w8, #0xa                ; =10
10002b5e4: f940dfe9    	ldr	x9, [sp, #0x1b8]
10002b5e8: f90ec3e9    	str	x9, [sp, #0x1d80]
10002b5ec: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b5f0: 52800508    	mov	w8, #0x28               ; =40
10002b5f4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b5f8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b5fc: 91360000    	add	x0, x0, #0xd80
10002b600: 940012f0    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b604: 3dc0f7e0    	ldr	q0, [sp, #0x3d0]
10002b608: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b60c: f941f3e8    	ldr	x8, [sp, #0x3e0]
10002b610: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b614: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b618: 91360000    	add	x0, x0, #0xd80
10002b61c: 940012e9    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b620: 3dc0efe0    	ldr	q0, [sp, #0x3b0]
10002b624: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b628: f941e3e8    	ldr	x8, [sp, #0x3c0]
10002b62c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b630: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b634: 91360000    	add	x0, x0, #0xd80
10002b638: 940012e2    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b63c: 3dc0e7e0    	ldr	q0, [sp, #0x390]
10002b640: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b644: f941d3e8    	ldr	x8, [sp, #0x3a0]
10002b648: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b64c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b650: 91360000    	add	x0, x0, #0xd80
10002b654: 940012db    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b658: 3dc0dfe0    	ldr	q0, [sp, #0x370]
10002b65c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b660: f941c3e8    	ldr	x8, [sp, #0x380]
10002b664: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b668: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b66c: 91360000    	add	x0, x0, #0xd80
10002b670: 940012d4    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b674: f94143e8    	ldr	x8, [sp, #0x280]
10002b678: f90ec3e8    	str	x8, [sp, #0x1d80]
10002b67c: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002b680: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b684: f9414be8    	ldr	x8, [sp, #0x290]
10002b688: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b68c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b690: 91360000    	add	x0, x0, #0xd80
10002b694: 940012cb    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b698: 100447c0    	adr	x0, 0x100033f90 <_.roc.bytes.46>
10002b69c: d503201f    	nop
10002b6a0: 528005a1    	mov	w1, #0x2d               ; =45
10002b6a4: 940013ea    	bl	0x10003064c <_roc_cold_shim.roc_builtins_str_from_literal>
10002b6a8: f9030be0    	str	x0, [sp, #0x610]
10002b6ac: f9030fe1    	str	x1, [sp, #0x618]
10002b6b0: f90313e2    	str	x2, [sp, #0x620]
10002b6b4: 911843e0    	add	x0, sp, #0x610
10002b6b8: 94001403    	bl	0x1000306c4 <_roc_cold_shim.roc_builtins_crash_str>
10002b6bc: f90ec3f8    	str	x24, [sp, #0x1d80]
10002b6c0: f90ec7fa    	str	x26, [sp, #0x1d88]
10002b6c4: f941a7e8    	ldr	x8, [sp, #0x348]
10002b6c8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b6cc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b6d0: 91360000    	add	x0, x0, #0xd80
10002b6d4: aa0603f4    	mov	x20, x6
10002b6d8: 940012ba    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b6dc: f90ec3f9    	str	x25, [sp, #0x1d80]
10002b6e0: f90ec7f4    	str	x20, [sp, #0x1d88]
10002b6e4: f941abe8    	ldr	x8, [sp, #0x350]
10002b6e8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b6ec: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b6f0: 91360000    	add	x0, x0, #0xd80
10002b6f4: 940012b3    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b6f8: f90ec3f5    	str	x21, [sp, #0x1d80]
10002b6fc: f90ec7fc    	str	x28, [sp, #0x1d88]
10002b700: f941afe8    	ldr	x8, [sp, #0x358]
10002b704: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b708: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b70c: 91360000    	add	x0, x0, #0xd80
10002b710: 940012ac    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b714: 52800148    	mov	w8, #0xa                ; =10
10002b718: f940dfe9    	ldr	x9, [sp, #0x1b8]
10002b71c: f90ec3e9    	str	x9, [sp, #0x1d80]
10002b720: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b724: 52800508    	mov	w8, #0x28               ; =40
10002b728: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b72c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b730: 91360000    	add	x0, x0, #0xd80
10002b734: 940012a3    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b738: f94147e8    	ldr	x8, [sp, #0x288]
10002b73c: f90ec3e8    	str	x8, [sp, #0x1d80]
10002b740: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002b744: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b748: f94103e8    	ldr	x8, [sp, #0x200]
10002b74c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b750: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b754: 91360000    	add	x0, x0, #0xd80
10002b758: 9400129a    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b75c: 528021c8    	mov	w8, #0x10e              ; =270
10002b760: f9412be9    	ldr	x9, [sp, #0x250]
10002b764: f90ec3e9    	str	x9, [sp, #0x1d80]
10002b768: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b76c: 52804608    	mov	w8, #0x230              ; =560
10002b770: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b774: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b778: 91360000    	add	x0, x0, #0xd80
10002b77c: 94001291    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b780: 52804168    	mov	w8, #0x20b              ; =523
10002b784: f90ec3f3    	str	x19, [sp, #0x1d80]
10002b788: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b78c: 52808548    	mov	w8, #0x42a              ; =1066
10002b790: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b794: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b798: 91360000    	add	x0, x0, #0xd80
10002b79c: 94001289    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b7a0: 3dc0f7e0    	ldr	q0, [sp, #0x3d0]
10002b7a4: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b7a8: f941f3e8    	ldr	x8, [sp, #0x3e0]
10002b7ac: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b7b0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b7b4: 91360000    	add	x0, x0, #0xd80
10002b7b8: 94001282    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b7bc: 3dc0efe0    	ldr	q0, [sp, #0x3b0]
10002b7c0: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b7c4: f941e3e8    	ldr	x8, [sp, #0x3c0]
10002b7c8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b7cc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b7d0: 91360000    	add	x0, x0, #0xd80
10002b7d4: 9400127b    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b7d8: 3dc0e7e0    	ldr	q0, [sp, #0x390]
10002b7dc: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b7e0: f941d3e8    	ldr	x8, [sp, #0x3a0]
10002b7e4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b7e8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b7ec: 91360000    	add	x0, x0, #0xd80
10002b7f0: 94001274    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b7f4: 3dc0dfe0    	ldr	q0, [sp, #0x370]
10002b7f8: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b7fc: f941c3e8    	ldr	x8, [sp, #0x380]
10002b800: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b804: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b808: 91360000    	add	x0, x0, #0xd80
10002b80c: 9400126d    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b810: f94143e8    	ldr	x8, [sp, #0x280]
10002b814: f90ec3e8    	str	x8, [sp, #0x1d80]
10002b818: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002b81c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b820: f9414be8    	ldr	x8, [sp, #0x290]
10002b824: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b828: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b82c: 91360000    	add	x0, x0, #0xd80
10002b830: 94001264    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b834: 10043ae0    	adr	x0, 0x100033f90 <_.roc.bytes.46>
10002b838: d503201f    	nop
10002b83c: 528005a1    	mov	w1, #0x2d               ; =45
10002b840: 94001383    	bl	0x10003064c <_roc_cold_shim.roc_builtins_str_from_literal>
10002b844: f9036be0    	str	x0, [sp, #0x6d0]
10002b848: f9036fe1    	str	x1, [sp, #0x6d8]
10002b84c: f90373e2    	str	x2, [sp, #0x6e0]
10002b850: 911b43e0    	add	x0, sp, #0x6d0
10002b854: 9400139c    	bl	0x1000306c4 <_roc_cold_shim.roc_builtins_crash_str>
10002b858: 52110108    	eor	w8, w8, #0x8000
10002b85c: 78297aa8    	strh	w8, [x21, x9, lsl #1]
10002b860: f90ec3f5    	str	x21, [sp, #0x1d80]
10002b864: f90ec7fc    	str	x28, [sp, #0x1d88]
10002b868: f941afe8    	ldr	x8, [sp, #0x358]
10002b86c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b870: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b874: 91360000    	add	x0, x0, #0xd80
10002b878: aa0603f4    	mov	x20, x6
10002b87c: 94001251    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b880: f90ec3f8    	str	x24, [sp, #0x1d80]
10002b884: f90ec7fa    	str	x26, [sp, #0x1d88]
10002b888: f941a7e8    	ldr	x8, [sp, #0x348]
10002b88c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b890: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b894: 91360000    	add	x0, x0, #0xd80
10002b898: 9400124a    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b89c: f90ec3f9    	str	x25, [sp, #0x1d80]
10002b8a0: f90ec7f4    	str	x20, [sp, #0x1d88]
10002b8a4: f941abe8    	ldr	x8, [sp, #0x350]
10002b8a8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b8ac: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b8b0: 91360000    	add	x0, x0, #0xd80
10002b8b4: 94001243    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b8b8: 52800148    	mov	w8, #0xa                ; =10
10002b8bc: f940dfe9    	ldr	x9, [sp, #0x1b8]
10002b8c0: f90ec3e9    	str	x9, [sp, #0x1d80]
10002b8c4: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b8c8: 52800508    	mov	w8, #0x28               ; =40
10002b8cc: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b8d0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b8d4: 91360000    	add	x0, x0, #0xd80
10002b8d8: 9400123a    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b8dc: f94147e8    	ldr	x8, [sp, #0x288]
10002b8e0: f90ec3e8    	str	x8, [sp, #0x1d80]
10002b8e4: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002b8e8: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b8ec: f94103e8    	ldr	x8, [sp, #0x200]
10002b8f0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b8f4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b8f8: 91360000    	add	x0, x0, #0xd80
10002b8fc: 94001231    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b900: 528021c8    	mov	w8, #0x10e              ; =270
10002b904: f9412be9    	ldr	x9, [sp, #0x250]
10002b908: f90ec3e9    	str	x9, [sp, #0x1d80]
10002b90c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b910: 52804608    	mov	w8, #0x230              ; =560
10002b914: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b918: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b91c: 91360000    	add	x0, x0, #0xd80
10002b920: 94001228    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b924: 52804168    	mov	w8, #0x20b              ; =523
10002b928: f90ec3f3    	str	x19, [sp, #0x1d80]
10002b92c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b930: 52808548    	mov	w8, #0x42a              ; =1066
10002b934: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b938: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b93c: 91360000    	add	x0, x0, #0xd80
10002b940: 94001220    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b944: 3dc0f7e0    	ldr	q0, [sp, #0x3d0]
10002b948: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b94c: f941f3e8    	ldr	x8, [sp, #0x3e0]
10002b950: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b954: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b958: 91360000    	add	x0, x0, #0xd80
10002b95c: 94001219    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b960: 3dc0efe0    	ldr	q0, [sp, #0x3b0]
10002b964: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b968: f941e3e8    	ldr	x8, [sp, #0x3c0]
10002b96c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b970: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b974: 91360000    	add	x0, x0, #0xd80
10002b978: 94001212    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b97c: 3dc0e7e0    	ldr	q0, [sp, #0x390]
10002b980: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b984: f941d3e8    	ldr	x8, [sp, #0x3a0]
10002b988: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b98c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b990: 91360000    	add	x0, x0, #0xd80
10002b994: 9400120b    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b998: 3dc0dfe0    	ldr	q0, [sp, #0x370]
10002b99c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002b9a0: f941c3e8    	ldr	x8, [sp, #0x380]
10002b9a4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b9a8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b9ac: 91360000    	add	x0, x0, #0xd80
10002b9b0: 94001204    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b9b4: f94143e8    	ldr	x8, [sp, #0x280]
10002b9b8: f90ec3e8    	str	x8, [sp, #0x1d80]
10002b9bc: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002b9c0: f90ec7e8    	str	x8, [sp, #0x1d88]
10002b9c4: f9414be8    	ldr	x8, [sp, #0x290]
10002b9c8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002b9cc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002b9d0: 91360000    	add	x0, x0, #0xd80
10002b9d4: 940011fb    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002b9d8: 10042dc0    	adr	x0, 0x100033f90 <_.roc.bytes.46>
10002b9dc: d503201f    	nop
10002b9e0: 528005a1    	mov	w1, #0x2d               ; =45
10002b9e4: 9400131a    	bl	0x10003064c <_roc_cold_shim.roc_builtins_str_from_literal>
10002b9e8: f9035fe0    	str	x0, [sp, #0x6b8]
10002b9ec: f90363e1    	str	x1, [sp, #0x6c0]
10002b9f0: f90367e2    	str	x2, [sp, #0x6c8]
10002b9f4: 911ae3e0    	add	x0, sp, #0x6b8
10002b9f8: 94001333    	bl	0x1000306c4 <_roc_cold_shim.roc_builtins_crash_str>
10002b9fc: f90ec3f5    	str	x21, [sp, #0x1d80]
10002ba00: f90ec7fc    	str	x28, [sp, #0x1d88]
10002ba04: f941afe8    	ldr	x8, [sp, #0x358]
10002ba08: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ba0c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ba10: 91360000    	add	x0, x0, #0xd80
10002ba14: aa0603f4    	mov	x20, x6
10002ba18: 940011ea    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ba1c: f90ec3f9    	str	x25, [sp, #0x1d80]
10002ba20: f90ec7f4    	str	x20, [sp, #0x1d88]
10002ba24: f941abe8    	ldr	x8, [sp, #0x350]
10002ba28: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ba2c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ba30: 91360000    	add	x0, x0, #0xd80
10002ba34: 940011e3    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ba38: f90ec3f8    	str	x24, [sp, #0x1d80]
10002ba3c: f90ec7fa    	str	x26, [sp, #0x1d88]
10002ba40: f941a7e8    	ldr	x8, [sp, #0x348]
10002ba44: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ba48: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ba4c: 91360000    	add	x0, x0, #0xd80
10002ba50: 940011dc    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ba54: 52800148    	mov	w8, #0xa                ; =10
10002ba58: f940dfe9    	ldr	x9, [sp, #0x1b8]
10002ba5c: f90ec3e9    	str	x9, [sp, #0x1d80]
10002ba60: f90ec7e8    	str	x8, [sp, #0x1d88]
10002ba64: 52800508    	mov	w8, #0x28               ; =40
10002ba68: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ba6c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ba70: 91360000    	add	x0, x0, #0xd80
10002ba74: 940011d3    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ba78: f94147e8    	ldr	x8, [sp, #0x288]
10002ba7c: f90ec3e8    	str	x8, [sp, #0x1d80]
10002ba80: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002ba84: f90ec7e8    	str	x8, [sp, #0x1d88]
10002ba88: f94103e8    	ldr	x8, [sp, #0x200]
10002ba8c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ba90: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ba94: 91360000    	add	x0, x0, #0xd80
10002ba98: 940011ca    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ba9c: 528021c8    	mov	w8, #0x10e              ; =270
10002baa0: f9412be9    	ldr	x9, [sp, #0x250]
10002baa4: f90ec3e9    	str	x9, [sp, #0x1d80]
10002baa8: f90ec7e8    	str	x8, [sp, #0x1d88]
10002baac: 52804608    	mov	w8, #0x230              ; =560
10002bab0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bab4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bab8: 91360000    	add	x0, x0, #0xd80
10002babc: 940011c1    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bac0: 52804168    	mov	w8, #0x20b              ; =523
10002bac4: f90ec3f3    	str	x19, [sp, #0x1d80]
10002bac8: f90ec7e8    	str	x8, [sp, #0x1d88]
10002bacc: 52808548    	mov	w8, #0x42a              ; =1066
10002bad0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bad4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bad8: 91360000    	add	x0, x0, #0xd80
10002badc: 940011b9    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bae0: 3dc0f7e0    	ldr	q0, [sp, #0x3d0]
10002bae4: 3d8763e0    	str	q0, [sp, #0x1d80]
10002bae8: f941f3e8    	ldr	x8, [sp, #0x3e0]
10002baec: f90ecbe8    	str	x8, [sp, #0x1d90]
10002baf0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002baf4: 91360000    	add	x0, x0, #0xd80
10002baf8: 940011b2    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bafc: 3dc0efe0    	ldr	q0, [sp, #0x3b0]
10002bb00: 3d8763e0    	str	q0, [sp, #0x1d80]
10002bb04: f941e3e8    	ldr	x8, [sp, #0x3c0]
10002bb08: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bb0c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bb10: 91360000    	add	x0, x0, #0xd80
10002bb14: 940011ab    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bb18: 3dc0e7e0    	ldr	q0, [sp, #0x390]
10002bb1c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002bb20: f941d3e8    	ldr	x8, [sp, #0x3a0]
10002bb24: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bb28: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bb2c: 91360000    	add	x0, x0, #0xd80
10002bb30: 940011a4    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bb34: 3dc0dfe0    	ldr	q0, [sp, #0x370]
10002bb38: 3d8763e0    	str	q0, [sp, #0x1d80]
10002bb3c: f941c3e8    	ldr	x8, [sp, #0x380]
10002bb40: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bb44: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bb48: 91360000    	add	x0, x0, #0xd80
10002bb4c: 9400119d    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bb50: f94143e8    	ldr	x8, [sp, #0x280]
10002bb54: f90ec3e8    	str	x8, [sp, #0x1d80]
10002bb58: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002bb5c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002bb60: f9414be8    	ldr	x8, [sp, #0x290]
10002bb64: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bb68: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bb6c: 91360000    	add	x0, x0, #0xd80
10002bb70: 94001194    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bb74: 100420e0    	adr	x0, 0x100033f90 <_.roc.bytes.46>
10002bb78: d503201f    	nop
10002bb7c: 528005a1    	mov	w1, #0x2d               ; =45
10002bb80: 940012b3    	bl	0x10003064c <_roc_cold_shim.roc_builtins_str_from_literal>
10002bb84: f90353e0    	str	x0, [sp, #0x6a0]
10002bb88: f90357e1    	str	x1, [sp, #0x6a8]
10002bb8c: f9035be2    	str	x2, [sp, #0x6b0]
10002bb90: 911a83e0    	add	x0, sp, #0x6a0
10002bb94: 940012cc    	bl	0x1000306c4 <_roc_cold_shim.roc_builtins_crash_str>
10002bb98: 52802068    	mov	w8, #0x103              ; =259
10002bb9c: f9418fe9    	ldr	x9, [sp, #0x318]
10002bba0: f904d3e9    	str	x9, [sp, #0x9a0]
10002bba4: f904d7e8    	str	x8, [sp, #0x9a8]
10002bba8: 52804348    	mov	w8, #0x21a              ; =538
10002bbac: f904dbe8    	str	x8, [sp, #0x9b0]
10002bbb0: 912683e0    	add	x0, sp, #0x9a0
10002bbb4: 94001183    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bbb8: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002bbbc: f904d3e8    	str	x8, [sp, #0x9a0]
10002bbc0: f94163e8    	ldr	x8, [sp, #0x2c0]
10002bbc4: f904d7e8    	str	x8, [sp, #0x9a8]
10002bbc8: f940dfe8    	ldr	x8, [sp, #0x1b8]
10002bbcc: f904dbe8    	str	x8, [sp, #0x9b0]
10002bbd0: 912683e0    	add	x0, sp, #0x9a0
10002bbd4: 9400117b    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bbd8: 10043ac0    	adr	x0, 0x100034330 <_.roc.bytes.65>
10002bbdc: d503201f    	nop
10002bbe0: 52800801    	mov	w1, #0x40               ; =64
10002bbe4: 1400046c    	b	0x10002cd94 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeafc>
10002bbe8: f90ec3f8    	str	x24, [sp, #0x1d80]
10002bbec: f90ec7fa    	str	x26, [sp, #0x1d88]
10002bbf0: f941a7e8    	ldr	x8, [sp, #0x348]
10002bbf4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bbf8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bbfc: 91360000    	add	x0, x0, #0xd80
10002bc00: aa0603f4    	mov	x20, x6
10002bc04: 9400116f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bc08: f90ec3f9    	str	x25, [sp, #0x1d80]
10002bc0c: f90ec7f4    	str	x20, [sp, #0x1d88]
10002bc10: f941abe8    	ldr	x8, [sp, #0x350]
10002bc14: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bc18: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bc1c: 91360000    	add	x0, x0, #0xd80
10002bc20: 94001168    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bc24: f90ec3f5    	str	x21, [sp, #0x1d80]
10002bc28: f90ec7fc    	str	x28, [sp, #0x1d88]
10002bc2c: f941afe8    	ldr	x8, [sp, #0x358]
10002bc30: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bc34: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bc38: 91360000    	add	x0, x0, #0xd80
10002bc3c: 94001161    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bc40: f94147e8    	ldr	x8, [sp, #0x288]
10002bc44: f90ec3e8    	str	x8, [sp, #0x1d80]
10002bc48: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002bc4c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002bc50: f94103e8    	ldr	x8, [sp, #0x200]
10002bc54: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bc58: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bc5c: 91360000    	add	x0, x0, #0xd80
10002bc60: 94001158    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bc64: 528021c8    	mov	w8, #0x10e              ; =270
10002bc68: f9412be9    	ldr	x9, [sp, #0x250]
10002bc6c: f90ec3e9    	str	x9, [sp, #0x1d80]
10002bc70: f90ec7e8    	str	x8, [sp, #0x1d88]
10002bc74: 52804608    	mov	w8, #0x230              ; =560
10002bc78: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bc7c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bc80: 91360000    	add	x0, x0, #0xd80
10002bc84: 9400114f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bc88: 52804168    	mov	w8, #0x20b              ; =523
10002bc8c: f90ec3f3    	str	x19, [sp, #0x1d80]
10002bc90: f90ec7e8    	str	x8, [sp, #0x1d88]
10002bc94: 52808548    	mov	w8, #0x42a              ; =1066
10002bc98: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bc9c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bca0: 91360000    	add	x0, x0, #0xd80
10002bca4: 94001147    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bca8: 52800148    	mov	w8, #0xa                ; =10
10002bcac: f940dfe9    	ldr	x9, [sp, #0x1b8]
10002bcb0: f90ec3e9    	str	x9, [sp, #0x1d80]
10002bcb4: f90ec7e8    	str	x8, [sp, #0x1d88]
10002bcb8: 52800508    	mov	w8, #0x28               ; =40
10002bcbc: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bcc0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bcc4: 91360000    	add	x0, x0, #0xd80
10002bcc8: 9400113e    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bccc: 3dc0f7e0    	ldr	q0, [sp, #0x3d0]
10002bcd0: 3d8763e0    	str	q0, [sp, #0x1d80]
10002bcd4: f941f3e8    	ldr	x8, [sp, #0x3e0]
10002bcd8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bcdc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bce0: 91360000    	add	x0, x0, #0xd80
10002bce4: 94001137    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bce8: 3dc0efe0    	ldr	q0, [sp, #0x3b0]
10002bcec: 3d8763e0    	str	q0, [sp, #0x1d80]
10002bcf0: f941e3e8    	ldr	x8, [sp, #0x3c0]
10002bcf4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bcf8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bcfc: 91360000    	add	x0, x0, #0xd80
10002bd00: 94001130    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bd04: 3dc0e7e0    	ldr	q0, [sp, #0x390]
10002bd08: 3d8763e0    	str	q0, [sp, #0x1d80]
10002bd0c: f941d3e8    	ldr	x8, [sp, #0x3a0]
10002bd10: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bd14: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bd18: 91360000    	add	x0, x0, #0xd80
10002bd1c: 94001129    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bd20: 3dc0dfe0    	ldr	q0, [sp, #0x370]
10002bd24: 3d8763e0    	str	q0, [sp, #0x1d80]
10002bd28: f941c3e8    	ldr	x8, [sp, #0x380]
10002bd2c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bd30: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bd34: 91360000    	add	x0, x0, #0xd80
10002bd38: 94001122    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bd3c: f94143e8    	ldr	x8, [sp, #0x280]
10002bd40: f90ec3e8    	str	x8, [sp, #0x1d80]
10002bd44: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002bd48: f90ec7e8    	str	x8, [sp, #0x1d88]
10002bd4c: f9414be8    	ldr	x8, [sp, #0x290]
10002bd50: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bd54: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bd58: 91360000    	add	x0, x0, #0xd80
10002bd5c: 94001119    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bd60: 10041180    	adr	x0, 0x100033f90 <_.roc.bytes.46>
10002bd64: d503201f    	nop
10002bd68: 528005a1    	mov	w1, #0x2d               ; =45
10002bd6c: 94001238    	bl	0x10003064c <_roc_cold_shim.roc_builtins_str_from_literal>
10002bd70: f902dbe0    	str	x0, [sp, #0x5b0]
10002bd74: f902dfe1    	str	x1, [sp, #0x5b8]
10002bd78: f902e3e2    	str	x2, [sp, #0x5c0]
10002bd7c: 9116c3e0    	add	x0, sp, #0x5b0
10002bd80: 94001251    	bl	0x1000306c4 <_roc_cold_shim.roc_builtins_crash_str>
10002bd84: 52110108    	eor	w8, w8, #0x8000
10002bd88: 78297aa8    	strh	w8, [x21, x9, lsl #1]
10002bd8c: f90ec3f5    	str	x21, [sp, #0x1d80]
10002bd90: f90ec7fc    	str	x28, [sp, #0x1d88]
10002bd94: f941afe8    	ldr	x8, [sp, #0x358]
10002bd98: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bd9c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bda0: 91360000    	add	x0, x0, #0xd80
10002bda4: aa0603f4    	mov	x20, x6
10002bda8: 94001106    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bdac: f90ec3f8    	str	x24, [sp, #0x1d80]
10002bdb0: f90ec7fa    	str	x26, [sp, #0x1d88]
10002bdb4: f941a7e8    	ldr	x8, [sp, #0x348]
10002bdb8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bdbc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bdc0: 91360000    	add	x0, x0, #0xd80
10002bdc4: 940010ff    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bdc8: f90ec3f9    	str	x25, [sp, #0x1d80]
10002bdcc: f90ec7f4    	str	x20, [sp, #0x1d88]
10002bdd0: f941abe8    	ldr	x8, [sp, #0x350]
10002bdd4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bdd8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bddc: 91360000    	add	x0, x0, #0xd80
10002bde0: 940010f8    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bde4: f94147e8    	ldr	x8, [sp, #0x288]
10002bde8: f90ec3e8    	str	x8, [sp, #0x1d80]
10002bdec: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002bdf0: f90ec7e8    	str	x8, [sp, #0x1d88]
10002bdf4: f94103e8    	ldr	x8, [sp, #0x200]
10002bdf8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bdfc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002be00: 91360000    	add	x0, x0, #0xd80
10002be04: 940010ef    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002be08: 528021c8    	mov	w8, #0x10e              ; =270
10002be0c: f9412be9    	ldr	x9, [sp, #0x250]
10002be10: f90ec3e9    	str	x9, [sp, #0x1d80]
10002be14: f90ec7e8    	str	x8, [sp, #0x1d88]
10002be18: 52804608    	mov	w8, #0x230              ; =560
10002be1c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002be20: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002be24: 91360000    	add	x0, x0, #0xd80
10002be28: 940010e6    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002be2c: 52804168    	mov	w8, #0x20b              ; =523
10002be30: f90ec3f3    	str	x19, [sp, #0x1d80]
10002be34: f90ec7e8    	str	x8, [sp, #0x1d88]
10002be38: 52808548    	mov	w8, #0x42a              ; =1066
10002be3c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002be40: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002be44: 91360000    	add	x0, x0, #0xd80
10002be48: 940010de    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002be4c: 52800148    	mov	w8, #0xa                ; =10
10002be50: f940dfe9    	ldr	x9, [sp, #0x1b8]
10002be54: f90ec3e9    	str	x9, [sp, #0x1d80]
10002be58: f90ec7e8    	str	x8, [sp, #0x1d88]
10002be5c: 52800508    	mov	w8, #0x28               ; =40
10002be60: f90ecbe8    	str	x8, [sp, #0x1d90]
10002be64: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002be68: 91360000    	add	x0, x0, #0xd80
10002be6c: 940010d5    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002be70: 3dc0f7e0    	ldr	q0, [sp, #0x3d0]
10002be74: 3d8763e0    	str	q0, [sp, #0x1d80]
10002be78: f941f3e8    	ldr	x8, [sp, #0x3e0]
10002be7c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002be80: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002be84: 91360000    	add	x0, x0, #0xd80
10002be88: 940010ce    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002be8c: 3dc0efe0    	ldr	q0, [sp, #0x3b0]
10002be90: 3d8763e0    	str	q0, [sp, #0x1d80]
10002be94: f941e3e8    	ldr	x8, [sp, #0x3c0]
10002be98: f90ecbe8    	str	x8, [sp, #0x1d90]
10002be9c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bea0: 91360000    	add	x0, x0, #0xd80
10002bea4: 940010c7    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bea8: 3dc0e7e0    	ldr	q0, [sp, #0x390]
10002beac: 3d8763e0    	str	q0, [sp, #0x1d80]
10002beb0: f941d3e8    	ldr	x8, [sp, #0x3a0]
10002beb4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002beb8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bebc: 91360000    	add	x0, x0, #0xd80
10002bec0: 940010c0    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bec4: 3dc0dfe0    	ldr	q0, [sp, #0x370]
10002bec8: 3d8763e0    	str	q0, [sp, #0x1d80]
10002becc: f941c3e8    	ldr	x8, [sp, #0x380]
10002bed0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bed4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bed8: 91360000    	add	x0, x0, #0xd80
10002bedc: 940010b9    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bee0: f94143e8    	ldr	x8, [sp, #0x280]
10002bee4: f90ec3e8    	str	x8, [sp, #0x1d80]
10002bee8: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002beec: f90ec7e8    	str	x8, [sp, #0x1d88]
10002bef0: f9414be8    	ldr	x8, [sp, #0x290]
10002bef4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bef8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002befc: 91360000    	add	x0, x0, #0xd80
10002bf00: 940010b0    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bf04: 10040460    	adr	x0, 0x100033f90 <_.roc.bytes.46>
10002bf08: d503201f    	nop
10002bf0c: 528005a1    	mov	w1, #0x2d               ; =45
10002bf10: 940011cf    	bl	0x10003064c <_roc_cold_shim.roc_builtins_str_from_literal>
10002bf14: f902cfe0    	str	x0, [sp, #0x598]
10002bf18: f902d3e1    	str	x1, [sp, #0x5a0]
10002bf1c: f902d7e2    	str	x2, [sp, #0x5a8]
10002bf20: 911663e0    	add	x0, sp, #0x598
10002bf24: 940011e8    	bl	0x1000306c4 <_roc_cold_shim.roc_builtins_crash_str>
10002bf28: f90ec3f5    	str	x21, [sp, #0x1d80]
10002bf2c: f90ec7fc    	str	x28, [sp, #0x1d88]
10002bf30: f941afe8    	ldr	x8, [sp, #0x358]
10002bf34: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bf38: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bf3c: 91360000    	add	x0, x0, #0xd80
10002bf40: aa0603f4    	mov	x20, x6
10002bf44: 9400109f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bf48: f90ec3f9    	str	x25, [sp, #0x1d80]
10002bf4c: f90ec7f4    	str	x20, [sp, #0x1d88]
10002bf50: f941abe8    	ldr	x8, [sp, #0x350]
10002bf54: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bf58: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bf5c: 91360000    	add	x0, x0, #0xd80
10002bf60: 94001098    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bf64: f90ec3f8    	str	x24, [sp, #0x1d80]
10002bf68: f90ec7fa    	str	x26, [sp, #0x1d88]
10002bf6c: f941a7e8    	ldr	x8, [sp, #0x348]
10002bf70: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bf74: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bf78: 91360000    	add	x0, x0, #0xd80
10002bf7c: 94001091    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bf80: f94147e8    	ldr	x8, [sp, #0x288]
10002bf84: f90ec3e8    	str	x8, [sp, #0x1d80]
10002bf88: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002bf8c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002bf90: f94103e8    	ldr	x8, [sp, #0x200]
10002bf94: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bf98: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bf9c: 91360000    	add	x0, x0, #0xd80
10002bfa0: 94001088    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bfa4: 528021c8    	mov	w8, #0x10e              ; =270
10002bfa8: f9412be9    	ldr	x9, [sp, #0x250]
10002bfac: f90ec3e9    	str	x9, [sp, #0x1d80]
10002bfb0: f90ec7e8    	str	x8, [sp, #0x1d88]
10002bfb4: 52804608    	mov	w8, #0x230              ; =560
10002bfb8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bfbc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bfc0: 91360000    	add	x0, x0, #0xd80
10002bfc4: 9400107f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bfc8: 52804168    	mov	w8, #0x20b              ; =523
10002bfcc: f90ec3f3    	str	x19, [sp, #0x1d80]
10002bfd0: f90ec7e8    	str	x8, [sp, #0x1d88]
10002bfd4: 52808548    	mov	w8, #0x42a              ; =1066
10002bfd8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002bfdc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002bfe0: 91360000    	add	x0, x0, #0xd80
10002bfe4: 94001077    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002bfe8: 52800148    	mov	w8, #0xa                ; =10
10002bfec: f940dfe9    	ldr	x9, [sp, #0x1b8]
10002bff0: f90ec3e9    	str	x9, [sp, #0x1d80]
10002bff4: f90ec7e8    	str	x8, [sp, #0x1d88]
10002bff8: 52800508    	mov	w8, #0x28               ; =40
10002bffc: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c000: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c004: 91360000    	add	x0, x0, #0xd80
10002c008: 9400106e    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c00c: 3dc0f7e0    	ldr	q0, [sp, #0x3d0]
10002c010: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c014: f941f3e8    	ldr	x8, [sp, #0x3e0]
10002c018: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c01c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c020: 91360000    	add	x0, x0, #0xd80
10002c024: 94001067    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c028: 3dc0efe0    	ldr	q0, [sp, #0x3b0]
10002c02c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c030: f941e3e8    	ldr	x8, [sp, #0x3c0]
10002c034: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c038: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c03c: 91360000    	add	x0, x0, #0xd80
10002c040: 94001060    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c044: 3dc0e7e0    	ldr	q0, [sp, #0x390]
10002c048: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c04c: f941d3e8    	ldr	x8, [sp, #0x3a0]
10002c050: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c054: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c058: 91360000    	add	x0, x0, #0xd80
10002c05c: 94001059    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c060: 3dc0dfe0    	ldr	q0, [sp, #0x370]
10002c064: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c068: f941c3e8    	ldr	x8, [sp, #0x380]
10002c06c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c070: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c074: 91360000    	add	x0, x0, #0xd80
10002c078: 94001052    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c07c: f94143e8    	ldr	x8, [sp, #0x280]
10002c080: f90ec3e8    	str	x8, [sp, #0x1d80]
10002c084: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002c088: f90ec7e8    	str	x8, [sp, #0x1d88]
10002c08c: f9414be8    	ldr	x8, [sp, #0x290]
10002c090: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c094: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c098: 91360000    	add	x0, x0, #0xd80
10002c09c: 94001049    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c0a0: 1003f780    	adr	x0, 0x100033f90 <_.roc.bytes.46>
10002c0a4: d503201f    	nop
10002c0a8: 528005a1    	mov	w1, #0x2d               ; =45
10002c0ac: 94001168    	bl	0x10003064c <_roc_cold_shim.roc_builtins_str_from_literal>
10002c0b0: f902c3e0    	str	x0, [sp, #0x580]
10002c0b4: f902c7e1    	str	x1, [sp, #0x588]
10002c0b8: f902cbe2    	str	x2, [sp, #0x590]
10002c0bc: 911603e0    	add	x0, sp, #0x580
10002c0c0: 94001181    	bl	0x1000306c4 <_roc_cold_shim.roc_builtins_crash_str>
10002c0c4: aa1a03e0    	mov	x0, x26
10002c0c8: aa1903e1    	mov	x1, x25
10002c0cc: aa1b03e2    	mov	x2, x27
10002c0d0: 94001189    	bl	0x1000306f4 <_roc_cold_shim.roc_builtins_list_reserve>
10002c0d4: aa0003fa    	mov	x26, x0
10002c0d8: aa0103f9    	mov	x25, x1
10002c0dc: aa0203fb    	mov	x27, x2
10002c0e0: 17ffc8a7    	b	0x10001e37c <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xe4>
10002c0e4: aa1a03e0    	mov	x0, x26
10002c0e8: aa1903e1    	mov	x1, x25
10002c0ec: aa1b03e2    	mov	x2, x27
10002c0f0: 52800023    	mov	w3, #0x1                ; =1
10002c0f4: 52800024    	mov	w4, #0x1                ; =1
10002c0f8: 52800025    	mov	w5, #0x1                ; =1
10002c0fc: 94001077    	bl	0x1000302d8 <_roc_cold_shim.roc_builtins_list_reserve_for_append>
10002c100: aa0003fa    	mov	x26, x0
10002c104: aa0103f9    	mov	x25, x1
10002c108: aa0203fb    	mov	x27, x2
10002c10c: d341fc48    	lsr	x8, x2, #1
10002c110: 52800029    	mov	w9, #0x1                ; =1
10002c114: 38216809    	strb	w9, [x0, x1]
10002c118: 91000421    	add	x1, x1, #0x1
10002c11c: 3607833b    	tbz	w27, #0x0, 0x10002b180 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xcee8>
10002c120: aa1a03e0    	mov	x0, x26
10002c124: aa1b03e2    	mov	x2, x27
10002c128: 52bfffe3    	mov	w3, #-0x10000           ; =-65536
10002c12c: 52800084    	mov	w4, #0x4                ; =4
10002c130: 940010ca    	bl	0x100030458 <_roc_cold_shim.roc_builtins_list_append_le_bytes>
10002c134: aa0003fa    	mov	x26, x0
10002c138: aa0103f9    	mov	x25, x1
10002c13c: aa0203fb    	mov	x27, x2
10002c140: 17fffc16    	b	0x10002b198 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xcf00>
10002c144: 52800148    	mov	w8, #0xa                ; =10
10002c148: f90ec3f9    	str	x25, [sp, #0x1d80]
10002c14c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002c150: 52800508    	mov	w8, #0x28               ; =40
10002c154: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c158: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c15c: 91360000    	add	x0, x0, #0xd80
10002c160: aa0703f3    	mov	x19, x7
10002c164: 94001017    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c168: f941afe8    	ldr	x8, [sp, #0x358]
10002c16c: f90ec3e8    	str	x8, [sp, #0x1d80]
10002c170: 529cac28    	mov	w8, #0xe561             ; =58721
10002c174: 72a002c8    	movk	w8, #0x16, lsl #16
10002c178: f90ec7e8    	str	x8, [sp, #0x1d88]
10002c17c: 52995ac8    	mov	w8, #0xcad6             ; =51926
10002c180: 72a005a8    	movk	w8, #0x2d, lsl #16
10002c184: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c188: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c18c: 91360000    	add	x0, x0, #0xd80
10002c190: 9400100c    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c194: 52a00088    	mov	w8, #0x40000            ; =262144
10002c198: f90ec3f3    	str	x19, [sp, #0x1d80]
10002c19c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002c1a0: f941b3e8    	ldr	x8, [sp, #0x360]
10002c1a4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c1a8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c1ac: 91360000    	add	x0, x0, #0xd80
10002c1b0: 94001004    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c1b4: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002c1b8: f90ec3e8    	str	x8, [sp, #0x1d80]
10002c1bc: f94163e8    	ldr	x8, [sp, #0x2c0]
10002c1c0: f90ec7e8    	str	x8, [sp, #0x1d88]
10002c1c4: f940dfe8    	ldr	x8, [sp, #0x1b8]
10002c1c8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c1cc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c1d0: 91360000    	add	x0, x0, #0xd80
10002c1d4: 94000ffb    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c1d8: f94123e8    	ldr	x8, [sp, #0x240]
10002c1dc: f90ec3e8    	str	x8, [sp, #0x1d80]
10002c1e0: f94147e8    	ldr	x8, [sp, #0x288]
10002c1e4: f90ec7e8    	str	x8, [sp, #0x1d88]
10002c1e8: f940b3e8    	ldr	x8, [sp, #0x160]
10002c1ec: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c1f0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c1f4: 91360000    	add	x0, x0, #0xd80
10002c1f8: 94000ff2    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c1fc: 52802068    	mov	w8, #0x103              ; =259
10002c200: f9418fe9    	ldr	x9, [sp, #0x318]
10002c204: f90ec3e9    	str	x9, [sp, #0x1d80]
10002c208: f90ec7e8    	str	x8, [sp, #0x1d88]
10002c20c: 52804348    	mov	w8, #0x21a              ; =538
10002c210: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c214: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c218: 91360000    	add	x0, x0, #0xd80
10002c21c: 94000fe9    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c220: f940bbe8    	ldr	x8, [sp, #0x170]
10002c224: f90ec3e8    	str	x8, [sp, #0x1d80]
10002c228: f940c3e8    	ldr	x8, [sp, #0x180]
10002c22c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002c230: f940b7e8    	ldr	x8, [sp, #0x168]
10002c234: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c238: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c23c: 91360000    	add	x0, x0, #0xd80
10002c240: 94000fe0    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c244: 3dc30fe0    	ldr	q0, [sp, #0xc30]
10002c248: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c24c: f94623e8    	ldr	x8, [sp, #0xc40]
10002c250: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c254: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c258: 91360000    	add	x0, x0, #0xd80
10002c25c: 94000fd9    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c260: 3dc307e0    	ldr	q0, [sp, #0xc10]
10002c264: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c268: f94613e8    	ldr	x8, [sp, #0xc20]
10002c26c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c270: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c274: 91360000    	add	x0, x0, #0xd80
10002c278: 94000fd2    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c27c: 3dc2ffe0    	ldr	q0, [sp, #0xbf0]
10002c280: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c284: f94603e8    	ldr	x8, [sp, #0xc00]
10002c288: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c28c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c290: 91360000    	add	x0, x0, #0xd80
10002c294: 94000fcb    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c298: 3dc2f7e0    	ldr	q0, [sp, #0xbd0]
10002c29c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c2a0: f945f3e8    	ldr	x8, [sp, #0xbe0]
10002c2a4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c2a8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c2ac: 91360000    	add	x0, x0, #0xd80
10002c2b0: 94000fc4    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c2b4: f94143e8    	ldr	x8, [sp, #0x280]
10002c2b8: f90ec3e8    	str	x8, [sp, #0x1d80]
10002c2bc: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002c2c0: f90ec7e8    	str	x8, [sp, #0x1d88]
10002c2c4: f9414be8    	ldr	x8, [sp, #0x290]
10002c2c8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c2cc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c2d0: 91360000    	add	x0, x0, #0xd80
10002c2d4: 94000fbb    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c2d8: f940d7e8    	ldr	x8, [sp, #0x1a8]
10002c2dc: f90ec3e8    	str	x8, [sp, #0x1d80]
10002c2e0: f940cbe8    	ldr	x8, [sp, #0x190]
10002c2e4: f90ec7e8    	str	x8, [sp, #0x1d88]
10002c2e8: f940dbe8    	ldr	x8, [sp, #0x1b0]
10002c2ec: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c2f0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c2f4: 91360000    	add	x0, x0, #0xd80
10002c2f8: 94000fb2    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c2fc: 3dc2efe0    	ldr	q0, [sp, #0xbb0]
10002c300: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c304: f945e3e8    	ldr	x8, [sp, #0xbc0]
10002c308: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c30c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c310: 91360000    	add	x0, x0, #0xd80
10002c314: 94000fab    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c318: 3dc2e7e0    	ldr	q0, [sp, #0xb90]
10002c31c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c320: f945d3e8    	ldr	x8, [sp, #0xba0]
10002c324: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c328: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c32c: 91360000    	add	x0, x0, #0xd80
10002c330: 94000fa4    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c334: 3dc2dfe0    	ldr	q0, [sp, #0xb70]
10002c338: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c33c: f945c3e8    	ldr	x8, [sp, #0xb80]
10002c340: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c344: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c348: 91360000    	add	x0, x0, #0xd80
10002c34c: 94000f9d    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c350: 3dc2d7e0    	ldr	q0, [sp, #0xb50]
10002c354: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c358: f945b3e8    	ldr	x8, [sp, #0xb60]
10002c35c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c360: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c364: 91360000    	add	x0, x0, #0xd80
10002c368: 94000f96    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c36c: 3dc2cfe0    	ldr	q0, [sp, #0xb30]
10002c370: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c374: f945a3e8    	ldr	x8, [sp, #0xb40]
10002c378: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c37c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c380: 91360000    	add	x0, x0, #0xd80
10002c384: 94000f8f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c388: 3dc2c7e0    	ldr	q0, [sp, #0xb10]
10002c38c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c390: f94593e8    	ldr	x8, [sp, #0xb20]
10002c394: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c398: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c39c: 91360000    	add	x0, x0, #0xd80
10002c3a0: 94000f88    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c3a4: f940ebe8    	ldr	x8, [sp, #0x1d0]
10002c3a8: f90ec3e8    	str	x8, [sp, #0x1d80]
10002c3ac: f94103e8    	ldr	x8, [sp, #0x200]
10002c3b0: f90ec7e8    	str	x8, [sp, #0x1d88]
10002c3b4: f940fbe8    	ldr	x8, [sp, #0x1f0]
10002c3b8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c3bc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c3c0: 91360000    	add	x0, x0, #0xd80
10002c3c4: 94000f7f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c3c8: 1003c9c0    	adr	x0, 0x100033d00 <_.roc.bytes.31>
10002c3cc: d503201f    	nop
10002c3d0: 52800821    	mov	w1, #0x41               ; =65
10002c3d4: 9400109e    	bl	0x10003064c <_roc_cold_shim.roc_builtins_str_from_literal>
10002c3d8: f90b07e0    	str	x0, [sp, #0x1608]
10002c3dc: f90b0be1    	str	x1, [sp, #0x1610]
10002c3e0: f90b0fe2    	str	x2, [sp, #0x1618]
10002c3e4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c3e8: 91182000    	add	x0, x0, #0x608
10002c3ec: 940010b6    	bl	0x1000306c4 <_roc_cold_shim.roc_builtins_crash_str>
10002c3f0: 3dc6e3e0    	ldr	q0, [sp, #0x1b80]
10002c3f4: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c3f8: f94dcbe8    	ldr	x8, [sp, #0x1b90]
10002c3fc: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c400: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c404: 91360000    	add	x0, x0, #0xd80
10002c408: 94000f6e    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c40c: 3dc6dbe0    	ldr	q0, [sp, #0x1b60]
10002c410: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c414: f94dbbe8    	ldr	x8, [sp, #0x1b70]
10002c418: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c41c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c420: 91360000    	add	x0, x0, #0xd80
10002c424: 94000f67    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c428: 3dc6d3e0    	ldr	q0, [sp, #0x1b40]
10002c42c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c430: f94dabe8    	ldr	x8, [sp, #0x1b50]
10002c434: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c438: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c43c: 91360000    	add	x0, x0, #0xd80
10002c440: 94000f60    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c444: f941afe8    	ldr	x8, [sp, #0x358]
10002c448: f90ec3e8    	str	x8, [sp, #0x1d80]
10002c44c: 529cac28    	mov	w8, #0xe561             ; =58721
10002c450: 72a002c8    	movk	w8, #0x16, lsl #16
10002c454: f90ec7e8    	str	x8, [sp, #0x1d88]
10002c458: 52995ac8    	mov	w8, #0xcad6             ; =51926
10002c45c: 72a005a8    	movk	w8, #0x2d, lsl #16
10002c460: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c464: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c468: 91360000    	add	x0, x0, #0xd80
10002c46c: 94000f55    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c470: 9132c3f3    	add	x19, sp, #0xcb0
10002c474: 3cc10260    	ldur	q0, [x19, #0x10]
10002c478: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c47c: f8420268    	ldur	x8, [x19, #0x20]
10002c480: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c484: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c488: 91360000    	add	x0, x0, #0xd80
10002c48c: 94000f4d    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c490: 3cc28260    	ldur	q0, [x19, #0x28]
10002c494: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c498: f8438268    	ldur	x8, [x19, #0x38]
10002c49c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c4a0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c4a4: 91360000    	add	x0, x0, #0xd80
10002c4a8: 94000f46    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c4ac: 3cc40260    	ldur	q0, [x19, #0x40]
10002c4b0: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c4b4: f8450268    	ldur	x8, [x19, #0x50]
10002c4b8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c4bc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c4c0: 91360000    	add	x0, x0, #0xd80
10002c4c4: 94000f3f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c4c8: 3cc58260    	ldur	q0, [x19, #0x58]
10002c4cc: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c4d0: f8468268    	ldur	x8, [x19, #0x68]
10002c4d4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c4d8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c4dc: 91360000    	add	x0, x0, #0xd80
10002c4e0: 94000f38    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c4e4: 3cc70260    	ldur	q0, [x19, #0x70]
10002c4e8: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c4ec: f8480268    	ldur	x8, [x19, #0x80]
10002c4f0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c4f4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c4f8: 91360000    	add	x0, x0, #0xd80
10002c4fc: 94000f31    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c500: 3cc88260    	ldur	q0, [x19, #0x88]
10002c504: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c508: f8498268    	ldur	x8, [x19, #0x98]
10002c50c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c510: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c514: 91360000    	add	x0, x0, #0xd80
10002c518: 94000f2a    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c51c: 3cca0260    	ldur	q0, [x19, #0xa0]
10002c520: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c524: f84b0268    	ldur	x8, [x19, #0xb0]
10002c528: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c52c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c530: 91360000    	add	x0, x0, #0xd80
10002c534: 94000f23    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c538: 9132c3f3    	add	x19, sp, #0xcb0
10002c53c: 3ccb8260    	ldur	q0, [x19, #0xb8]
10002c540: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c544: f946bfe8    	ldr	x8, [sp, #0xd78]
10002c548: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c54c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c550: 91360000    	add	x0, x0, #0xd80
10002c554: 94000f1b    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c558: 3dc363e0    	ldr	q0, [sp, #0xd80]
10002c55c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c560: f946cbe8    	ldr	x8, [sp, #0xd90]
10002c564: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c568: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c56c: 91360000    	add	x0, x0, #0xd80
10002c570: 94000f14    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c574: 3cce8260    	ldur	q0, [x19, #0xe8]
10002c578: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c57c: f946d7e8    	ldr	x8, [sp, #0xda8]
10002c580: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c584: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c588: 91360000    	add	x0, x0, #0xd80
10002c58c: 94000f0d    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c590: 3dc36fe0    	ldr	q0, [sp, #0xdb0]
10002c594: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c598: f946e3e8    	ldr	x8, [sp, #0xdc0]
10002c59c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c5a0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c5a4: 91360000    	add	x0, x0, #0xd80
10002c5a8: 94000f06    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c5ac: 3dc327e0    	ldr	q0, [sp, #0xc90]
10002c5b0: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c5b4: f94653e8    	ldr	x8, [sp, #0xca0]
10002c5b8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c5bc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c5c0: 91360000    	add	x0, x0, #0xd80
10002c5c4: 94000eff    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c5c8: 3dc31fe0    	ldr	q0, [sp, #0xc70]
10002c5cc: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c5d0: f94643e8    	ldr	x8, [sp, #0xc80]
10002c5d4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c5d8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c5dc: 91360000    	add	x0, x0, #0xd80
10002c5e0: 94000ef8    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c5e4: 3dc317e0    	ldr	q0, [sp, #0xc50]
10002c5e8: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c5ec: f94633e8    	ldr	x8, [sp, #0xc60]
10002c5f0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c5f4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c5f8: 91360000    	add	x0, x0, #0xd80
10002c5fc: 94000ef1    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c600: f94123e8    	ldr	x8, [sp, #0x240]
10002c604: f90ec3e8    	str	x8, [sp, #0x1d80]
10002c608: f94147e8    	ldr	x8, [sp, #0x288]
10002c60c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002c610: f940b3e8    	ldr	x8, [sp, #0x160]
10002c614: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c618: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c61c: 91360000    	add	x0, x0, #0xd80
10002c620: 94000ee8    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c624: 52800148    	mov	w8, #0xa                ; =10
10002c628: f90ec3f4    	str	x20, [sp, #0x1d80]
10002c62c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002c630: 52800508    	mov	w8, #0x28               ; =40
10002c634: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c638: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c63c: 91360000    	add	x0, x0, #0xd80
10002c640: 94000ee0    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c644: 52802068    	mov	w8, #0x103              ; =259
10002c648: f9418fe9    	ldr	x9, [sp, #0x318]
10002c64c: f90ec3e9    	str	x9, [sp, #0x1d80]
10002c650: f90ec7e8    	str	x8, [sp, #0x1d88]
10002c654: 52804348    	mov	w8, #0x21a              ; =538
10002c658: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c65c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c660: 91360000    	add	x0, x0, #0xd80
10002c664: 94000ed7    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c668: 52a00088    	mov	w8, #0x40000            ; =262144
10002c66c: f94113e9    	ldr	x9, [sp, #0x220]
10002c670: f90ec3e9    	str	x9, [sp, #0x1d80]
10002c674: f90ec7e8    	str	x8, [sp, #0x1d88]
10002c678: f941b3e8    	ldr	x8, [sp, #0x360]
10002c67c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c680: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c684: 91360000    	add	x0, x0, #0xd80
10002c688: 94000ece    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c68c: 1003b620    	adr	x0, 0x100033d50 <_.roc.bytes.32>
10002c690: d503201f    	nop
10002c694: 52800721    	mov	w1, #0x39               ; =57
10002c698: 94000fed    	bl	0x10003064c <_roc_cold_shim.roc_builtins_str_from_literal>
10002c69c: f906e7e0    	str	x0, [sp, #0xdc8]
10002c6a0: f906ebe1    	str	x1, [sp, #0xdd0]
10002c6a4: f906efe2    	str	x2, [sp, #0xdd8]
10002c6a8: 913723e0    	add	x0, sp, #0xdc8
10002c6ac: 94001006    	bl	0x1000306c4 <_roc_cold_shim.roc_builtins_crash_str>
10002c6b0: f94143e0    	ldr	x0, [sp, #0x280]
10002c6b4: aa1903e1    	mov	x1, x25
10002c6b8: aa1b03e2    	mov	x2, x27
10002c6bc: 9400100e    	bl	0x1000306f4 <_roc_cold_shim.roc_builtins_list_reserve>
10002c6c0: f90143e0    	str	x0, [sp, #0x280]
10002c6c4: f9017fe1    	str	x1, [sp, #0x2f8]
10002c6c8: aa0203fb    	mov	x27, x2
10002c6cc: 17ffd853    	b	0x100022818 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x4580>
10002c6d0: aa1a03e0    	mov	x0, x26
10002c6d4: aa1903e1    	mov	x1, x25
10002c6d8: 94001007    	bl	0x1000306f4 <_roc_cold_shim.roc_builtins_list_reserve>
10002c6dc: aa0003fa    	mov	x26, x0
10002c6e0: aa0103f9    	mov	x25, x1
10002c6e4: f9014be2    	str	x2, [sp, #0x290]
10002c6e8: 17ffcf40    	b	0x1000203e8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x2150>
10002c6ec: 52804168    	mov	w8, #0x20b              ; =523
10002c6f0: f90ec3f5    	str	x21, [sp, #0x1d80]
10002c6f4: f90ec7e8    	str	x8, [sp, #0x1d88]
10002c6f8: 52808548    	mov	w8, #0x42a              ; =1066
10002c6fc: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c700: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c704: 91360000    	add	x0, x0, #0xd80
10002c708: aa1103f3    	mov	x19, x17
10002c70c: aa0103f4    	mov	x20, x1
10002c710: aa0c03f5    	mov	x21, x12
10002c714: 94000eab    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c718: f90ec3f6    	str	x22, [sp, #0x1d80]
10002c71c: f90ec7f7    	str	x23, [sp, #0x1d88]
10002c720: f9415be8    	ldr	x8, [sp, #0x2b0]
10002c724: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c728: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c72c: 91360000    	add	x0, x0, #0xd80
10002c730: 94000ea4    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c734: f90ec3f8    	str	x24, [sp, #0x1d80]
10002c738: f90ec7f3    	str	x19, [sp, #0x1d88]
10002c73c: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002c740: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c744: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c748: 91360000    	add	x0, x0, #0xd80
10002c74c: 94000e9d    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c750: f90ec3f5    	str	x21, [sp, #0x1d80]
10002c754: f90ec7f4    	str	x20, [sp, #0x1d88]
10002c758: f94163e8    	ldr	x8, [sp, #0x2c0]
10002c75c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c760: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c764: 91360000    	add	x0, x0, #0xd80
10002c768: 94000e96    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c76c: 52800148    	mov	w8, #0xa                ; =10
10002c770: f940f7e9    	ldr	x9, [sp, #0x1e8]
10002c774: f90ec3e9    	str	x9, [sp, #0x1d80]
10002c778: f90ec7e8    	str	x8, [sp, #0x1d88]
10002c77c: 52800508    	mov	w8, #0x28               ; =40
10002c780: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c784: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c788: 91360000    	add	x0, x0, #0xd80
10002c78c: 94000e8d    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c790: f94133e8    	ldr	x8, [sp, #0x260]
10002c794: f90ec3e8    	str	x8, [sp, #0x1d80]
10002c798: f94173e8    	ldr	x8, [sp, #0x2e0]
10002c79c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002c7a0: f940e3e8    	ldr	x8, [sp, #0x1c0]
10002c7a4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c7a8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c7ac: 91360000    	add	x0, x0, #0xd80
10002c7b0: 94000e84    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c7b4: 528021c8    	mov	w8, #0x10e              ; =270
10002c7b8: f9412be9    	ldr	x9, [sp, #0x250]
10002c7bc: f90ec3e9    	str	x9, [sp, #0x1d80]
10002c7c0: f90ec7e8    	str	x8, [sp, #0x1d88]
10002c7c4: 52804608    	mov	w8, #0x230              ; =560
10002c7c8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c7cc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c7d0: 91360000    	add	x0, x0, #0xd80
10002c7d4: 94000e7b    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c7d8: 3dc1ffe0    	ldr	q0, [sp, #0x7f0]
10002c7dc: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c7e0: f94403e8    	ldr	x8, [sp, #0x800]
10002c7e4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c7e8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c7ec: 91360000    	add	x0, x0, #0xd80
10002c7f0: 94000e74    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c7f4: 3dc1f7e0    	ldr	q0, [sp, #0x7d0]
10002c7f8: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c7fc: f943f3e8    	ldr	x8, [sp, #0x7e0]
10002c800: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c804: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c808: 91360000    	add	x0, x0, #0xd80
10002c80c: 94000e6d    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c810: 3dc1efe0    	ldr	q0, [sp, #0x7b0]
10002c814: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c818: f943e3e8    	ldr	x8, [sp, #0x7c0]
10002c81c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c820: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c824: 91360000    	add	x0, x0, #0xd80
10002c828: 94000e66    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c82c: 3dc1e7e0    	ldr	q0, [sp, #0x790]
10002c830: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c834: f943d3e8    	ldr	x8, [sp, #0x7a0]
10002c838: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c83c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c840: 91360000    	add	x0, x0, #0xd80
10002c844: 94000e5f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c848: f94143e8    	ldr	x8, [sp, #0x280]
10002c84c: f90ec3e8    	str	x8, [sp, #0x1d80]
10002c850: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002c854: f90ec7e8    	str	x8, [sp, #0x1d88]
10002c858: f9414be8    	ldr	x8, [sp, #0x290]
10002c85c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c860: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c864: 91360000    	add	x0, x0, #0xd80
10002c868: 94000e56    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c86c: 1003ad21    	adr	x1, 0x100033e10 <_.roc.bytes.36>
10002c870: d503201f    	nop
10002c874: 9129a3e0    	add	x0, sp, #0xa68
10002c878: 528007a2    	mov	w2, #0x3d               ; =61
10002c87c: 940016ca    	bl	0x1000323a4 <_dev_wrappers.roc_builtins_str_from_literal>
10002c880: 9129a3e0    	add	x0, sp, #0xa68
10002c884: 9400144f    	bl	0x1000319c0 <_dev_wrappers.roc_builtins_crash_str>
10002c888: 10037b41    	adr	x1, 0x1000337f0 <_.roc.bytes.5>
10002c88c: d503201f    	nop
10002c890: 912683e0    	add	x0, sp, #0x9a0
10002c894: 528006a2    	mov	w2, #0x35               ; =53
10002c898: 940016c3    	bl	0x1000323a4 <_dev_wrappers.roc_builtins_str_from_literal>
10002c89c: 912683e0    	add	x0, sp, #0x9a0
10002c8a0: 94001448    	bl	0x1000319c0 <_dev_wrappers.roc_builtins_crash_str>
10002c8a4: 52804028    	mov	w8, #0x201              ; =513
10002c8a8: f90ec3f6    	str	x22, [sp, #0x1d80]
10002c8ac: f90ec7e8    	str	x8, [sp, #0x1d88]
10002c8b0: 528082c8    	mov	w8, #0x416              ; =1046
10002c8b4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c8b8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c8bc: 91360000    	add	x0, x0, #0xd80
10002c8c0: aa0103f3    	mov	x19, x1
10002c8c4: aa1e03f4    	mov	x20, x30
10002c8c8: 94000e3e    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c8cc: 52a00028    	mov	w8, #0x10000            ; =65536
10002c8d0: f90ec3f7    	str	x23, [sp, #0x1d80]
10002c8d4: f90ec7e8    	str	x8, [sp, #0x1d88]
10002c8d8: f90ecbf4    	str	x20, [sp, #0x1d90]
10002c8dc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c8e0: 91360000    	add	x0, x0, #0xd80
10002c8e4: 94000e37    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c8e8: f941abe8    	ldr	x8, [sp, #0x350]
10002c8ec: f90ec3e8    	str	x8, [sp, #0x1d80]
10002c8f0: f90ec7f3    	str	x19, [sp, #0x1d88]
10002c8f4: f94187e8    	ldr	x8, [sp, #0x308]
10002c8f8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c8fc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c900: 91360000    	add	x0, x0, #0xd80
10002c904: 94000e2f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c908: 528021c8    	mov	w8, #0x10e              ; =270
10002c90c: f941a7e9    	ldr	x9, [sp, #0x348]
10002c910: f90ec3e9    	str	x9, [sp, #0x1d80]
10002c914: f90ec7e8    	str	x8, [sp, #0x1d88]
10002c918: 52804608    	mov	w8, #0x230              ; =560
10002c91c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c920: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c924: 91360000    	add	x0, x0, #0xd80
10002c928: 94000e26    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c92c: 3dc5bbe0    	ldr	q0, [sp, #0x16e0]
10002c930: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c934: f94b7be8    	ldr	x8, [sp, #0x16f0]
10002c938: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c93c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c940: 91360000    	add	x0, x0, #0xd80
10002c944: 94000e1f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c948: 3dc5b3e0    	ldr	q0, [sp, #0x16c0]
10002c94c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c950: f94b6be8    	ldr	x8, [sp, #0x16d0]
10002c954: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c958: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c95c: 91360000    	add	x0, x0, #0xd80
10002c960: 94000e18    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c964: 3dc5abe0    	ldr	q0, [sp, #0x16a0]
10002c968: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c96c: f94b5be8    	ldr	x8, [sp, #0x16b0]
10002c970: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c974: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c978: 91360000    	add	x0, x0, #0xd80
10002c97c: 94000e11    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c980: 3dc5a3e0    	ldr	q0, [sp, #0x1680]
10002c984: 3d8763e0    	str	q0, [sp, #0x1d80]
10002c988: f94b4be8    	ldr	x8, [sp, #0x1690]
10002c98c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c990: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c994: 91360000    	add	x0, x0, #0xd80
10002c998: 94000e0a    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c99c: f94143e8    	ldr	x8, [sp, #0x280]
10002c9a0: f90ec3e8    	str	x8, [sp, #0x1d80]
10002c9a4: f90ec7f9    	str	x25, [sp, #0x1d88]
10002c9a8: f9414be8    	ldr	x8, [sp, #0x290]
10002c9ac: f90ecbe8    	str	x8, [sp, #0x1d90]
10002c9b0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c9b4: 91360000    	add	x0, x0, #0xd80
10002c9b8: 94000e02    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002c9bc: 100395a1    	adr	x1, 0x100033c70 <_.roc.bytes.25>
10002c9c0: d503201f    	nop
10002c9c4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c9c8: 9123a000    	add	x0, x0, #0x8e8
10002c9cc: 52800842    	mov	w2, #0x42               ; =66
10002c9d0: 94001675    	bl	0x1000323a4 <_dev_wrappers.roc_builtins_str_from_literal>
10002c9d4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002c9d8: 9123a000    	add	x0, x0, #0x8e8
10002c9dc: 940013f9    	bl	0x1000319c0 <_dev_wrappers.roc_builtins_crash_str>
10002c9e0: aa1a03e0    	mov	x0, x26
10002c9e4: aa1903e1    	mov	x1, x25
10002c9e8: 94000f43    	bl	0x1000306f4 <_roc_cold_shim.roc_builtins_list_reserve>
10002c9ec: aa0003fa    	mov	x26, x0
10002c9f0: aa0103f9    	mov	x25, x1
10002c9f4: f9014be2    	str	x2, [sp, #0x290]
10002c9f8: 17ffe8b8    	b	0x100026cd8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8a40>
10002c9fc: f90ec3ec    	str	x12, [sp, #0x1d80]
10002ca00: f90ec7e1    	str	x1, [sp, #0x1d88]
10002ca04: f94163e8    	ldr	x8, [sp, #0x2c0]
10002ca08: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ca0c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ca10: 91360000    	add	x0, x0, #0xd80
10002ca14: 94000deb    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ca18: f90ec3f4    	str	x20, [sp, #0x1d80]
10002ca1c: f90ec7f3    	str	x19, [sp, #0x1d88]
10002ca20: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002ca24: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ca28: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ca2c: 91360000    	add	x0, x0, #0xd80
10002ca30: 94000de4    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ca34: f90ec3f6    	str	x22, [sp, #0x1d80]
10002ca38: f90ec7f7    	str	x23, [sp, #0x1d88]
10002ca3c: f9415be8    	ldr	x8, [sp, #0x2b0]
10002ca40: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ca44: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ca48: 91360000    	add	x0, x0, #0xd80
10002ca4c: 94000ddd    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ca50: 52804168    	mov	w8, #0x20b              ; =523
10002ca54: f90ec3f5    	str	x21, [sp, #0x1d80]
10002ca58: f90ec7e8    	str	x8, [sp, #0x1d88]
10002ca5c: 52808548    	mov	w8, #0x42a              ; =1066
10002ca60: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ca64: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ca68: 91360000    	add	x0, x0, #0xd80
10002ca6c: 94000dd5    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ca70: 52800148    	mov	w8, #0xa                ; =10
10002ca74: f940f7e9    	ldr	x9, [sp, #0x1e8]
10002ca78: f90ec3e9    	str	x9, [sp, #0x1d80]
10002ca7c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002ca80: 52800508    	mov	w8, #0x28               ; =40
10002ca84: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ca88: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ca8c: 91360000    	add	x0, x0, #0xd80
10002ca90: 94000dcc    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ca94: f94133e8    	ldr	x8, [sp, #0x260]
10002ca98: f90ec3e8    	str	x8, [sp, #0x1d80]
10002ca9c: f94173e8    	ldr	x8, [sp, #0x2e0]
10002caa0: f90ec7e8    	str	x8, [sp, #0x1d88]
10002caa4: f940e3e8    	ldr	x8, [sp, #0x1c0]
10002caa8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002caac: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cab0: 91360000    	add	x0, x0, #0xd80
10002cab4: 94000dc3    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cab8: 528021c8    	mov	w8, #0x10e              ; =270
10002cabc: f9412be9    	ldr	x9, [sp, #0x250]
10002cac0: f90ec3e9    	str	x9, [sp, #0x1d80]
10002cac4: f90ec7e8    	str	x8, [sp, #0x1d88]
10002cac8: 52804608    	mov	w8, #0x230              ; =560
10002cacc: f90ecbe8    	str	x8, [sp, #0x1d90]
10002cad0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cad4: 91360000    	add	x0, x0, #0xd80
10002cad8: 94000dba    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cadc: 3dc1ffe0    	ldr	q0, [sp, #0x7f0]
10002cae0: 3d8763e0    	str	q0, [sp, #0x1d80]
10002cae4: f94403e8    	ldr	x8, [sp, #0x800]
10002cae8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002caec: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002caf0: 91360000    	add	x0, x0, #0xd80
10002caf4: 94000db3    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002caf8: 3dc1f7e0    	ldr	q0, [sp, #0x7d0]
10002cafc: 3d8763e0    	str	q0, [sp, #0x1d80]
10002cb00: f943f3e8    	ldr	x8, [sp, #0x7e0]
10002cb04: f90ecbe8    	str	x8, [sp, #0x1d90]
10002cb08: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cb0c: 91360000    	add	x0, x0, #0xd80
10002cb10: 94000dac    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cb14: 3dc1efe0    	ldr	q0, [sp, #0x7b0]
10002cb18: 3d8763e0    	str	q0, [sp, #0x1d80]
10002cb1c: f943e3e8    	ldr	x8, [sp, #0x7c0]
10002cb20: f90ecbe8    	str	x8, [sp, #0x1d90]
10002cb24: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cb28: 91360000    	add	x0, x0, #0xd80
10002cb2c: 94000da5    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cb30: 3dc1e7e0    	ldr	q0, [sp, #0x790]
10002cb34: 3d8763e0    	str	q0, [sp, #0x1d80]
10002cb38: f943d3e8    	ldr	x8, [sp, #0x7a0]
10002cb3c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002cb40: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cb44: 91360000    	add	x0, x0, #0xd80
10002cb48: 94000d9e    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cb4c: f94143e8    	ldr	x8, [sp, #0x280]
10002cb50: f90ec3e8    	str	x8, [sp, #0x1d80]
10002cb54: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002cb58: f90ec7e8    	str	x8, [sp, #0x1d88]
10002cb5c: f9414be8    	ldr	x8, [sp, #0x290]
10002cb60: f90ecbe8    	str	x8, [sp, #0x1d90]
10002cb64: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cb68: 91360000    	add	x0, x0, #0xd80
10002cb6c: 94000d95    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cb70: 10039901    	adr	x1, 0x100033e90 <_.roc.bytes.38>
10002cb74: d503201f    	nop
10002cb78: 912823e0    	add	x0, sp, #0xa08
10002cb7c: 52800642    	mov	w2, #0x32               ; =50
10002cb80: 94001609    	bl	0x1000323a4 <_dev_wrappers.roc_builtins_str_from_literal>
10002cb84: 912823e0    	add	x0, sp, #0xa08
10002cb88: 9400138e    	bl	0x1000319c0 <_dev_wrappers.roc_builtins_crash_str>
10002cb8c: 52804028    	mov	w8, #0x201              ; =513
10002cb90: f90ec3f6    	str	x22, [sp, #0x1d80]
10002cb94: f90ec7e8    	str	x8, [sp, #0x1d88]
10002cb98: 528082c8    	mov	w8, #0x416              ; =1046
10002cb9c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002cba0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cba4: 91360000    	add	x0, x0, #0xd80
10002cba8: aa0103f3    	mov	x19, x1
10002cbac: aa1e03f4    	mov	x20, x30
10002cbb0: 94000d84    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cbb4: 52a00028    	mov	w8, #0x10000            ; =65536
10002cbb8: f90ec3f7    	str	x23, [sp, #0x1d80]
10002cbbc: f90ec7e8    	str	x8, [sp, #0x1d88]
10002cbc0: f90ecbf4    	str	x20, [sp, #0x1d90]
10002cbc4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cbc8: 91360000    	add	x0, x0, #0xd80
10002cbcc: 94000d7d    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cbd0: f941abe8    	ldr	x8, [sp, #0x350]
10002cbd4: f90ec3e8    	str	x8, [sp, #0x1d80]
10002cbd8: f90ec7f3    	str	x19, [sp, #0x1d88]
10002cbdc: f94187e8    	ldr	x8, [sp, #0x308]
10002cbe0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002cbe4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cbe8: 91360000    	add	x0, x0, #0xd80
10002cbec: 94000d75    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cbf0: 528021c8    	mov	w8, #0x10e              ; =270
10002cbf4: f941a7e9    	ldr	x9, [sp, #0x348]
10002cbf8: f90ec3e9    	str	x9, [sp, #0x1d80]
10002cbfc: f90ec7e8    	str	x8, [sp, #0x1d88]
10002cc00: 52804608    	mov	w8, #0x230              ; =560
10002cc04: f90ecbe8    	str	x8, [sp, #0x1d90]
10002cc08: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cc0c: 91360000    	add	x0, x0, #0xd80
10002cc10: 94000d6c    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cc14: 3dc5bbe0    	ldr	q0, [sp, #0x16e0]
10002cc18: 3d8763e0    	str	q0, [sp, #0x1d80]
10002cc1c: f94b7be8    	ldr	x8, [sp, #0x16f0]
10002cc20: f90ecbe8    	str	x8, [sp, #0x1d90]
10002cc24: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cc28: 91360000    	add	x0, x0, #0xd80
10002cc2c: 94000d65    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cc30: 3dc5b3e0    	ldr	q0, [sp, #0x16c0]
10002cc34: 3d8763e0    	str	q0, [sp, #0x1d80]
10002cc38: f94b6be8    	ldr	x8, [sp, #0x16d0]
10002cc3c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002cc40: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cc44: 91360000    	add	x0, x0, #0xd80
10002cc48: 94000d5e    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cc4c: 3dc5abe0    	ldr	q0, [sp, #0x16a0]
10002cc50: 3d8763e0    	str	q0, [sp, #0x1d80]
10002cc54: f94b5be8    	ldr	x8, [sp, #0x16b0]
10002cc58: f90ecbe8    	str	x8, [sp, #0x1d90]
10002cc5c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cc60: 91360000    	add	x0, x0, #0xd80
10002cc64: 94000d57    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cc68: 3dc5a3e0    	ldr	q0, [sp, #0x1680]
10002cc6c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002cc70: f94b4be8    	ldr	x8, [sp, #0x1690]
10002cc74: f90ecbe8    	str	x8, [sp, #0x1d90]
10002cc78: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cc7c: 91360000    	add	x0, x0, #0xd80
10002cc80: 94000d50    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cc84: f94143e8    	ldr	x8, [sp, #0x280]
10002cc88: f90ec3e8    	str	x8, [sp, #0x1d80]
10002cc8c: f90ec7f9    	str	x25, [sp, #0x1d88]
10002cc90: f9414be8    	ldr	x8, [sp, #0x290]
10002cc94: f90ecbe8    	str	x8, [sp, #0x1d90]
10002cc98: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cc9c: 91360000    	add	x0, x0, #0xd80
10002cca0: 94000d48    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cca4: 100380e1    	adr	x1, 0x100033cc0 <_.roc.bytes.26>
10002cca8: d503201f    	nop
10002ccac: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ccb0: 91234000    	add	x0, x0, #0x8d0
10002ccb4: 52800762    	mov	w2, #0x3b               ; =59
10002ccb8: 940015bb    	bl	0x1000323a4 <_dev_wrappers.roc_builtins_str_from_literal>
10002ccbc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ccc0: 91234000    	add	x0, x0, #0x8d0
10002ccc4: 9400133f    	bl	0x1000319c0 <_dev_wrappers.roc_builtins_crash_str>
10002ccc8: aa1b03e2    	mov	x2, x27
10002cccc: 3700cf7b    	tbnz	w27, #0x0, 0x10002e6b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x10420>
10002ccd0: d341fc48    	lsr	x8, x2, #1
10002ccd4: eb19011f    	cmp	x8, x25
10002ccd8: 5400cf00    	b.eq	0x10002e6b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x10420>
10002ccdc: b4000088    	cbz	x8, 0x10002ccec <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xea54>
10002cce0: f85f8348    	ldur	x8, [x26, #-0x8]
10002cce4: f100051f    	cmp	x8, #0x1
10002cce8: 5400ce81    	b.ne	0x10002e6b8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x10420>
10002ccec: aa1a03e0    	mov	x0, x26
10002ccf0: aa1903e1    	mov	x1, x25
10002ccf4: aa0203fb    	mov	x27, x2
10002ccf8: 94000dce    	bl	0x100030430 <_roc_cold_shim.roc_builtins_list_slack_unique>
10002ccfc: 17ffe685    	b	0x100026710 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x8478>
10002cd00: f9004fff    	str	xzr, [sp, #0x98]
10002cd04: 14000011    	b	0x10002cd48 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeab0>
10002cd08: 52800048    	mov	w8, #0x2                ; =2
10002cd0c: 1400000e    	b	0x10002cd44 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeaac>
10002cd10: 52800088    	mov	w8, #0x4                ; =4
10002cd14: 1400000c    	b	0x10002cd44 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeaac>
10002cd18: 528000c8    	mov	w8, #0x6                ; =6
10002cd1c: 1400000a    	b	0x10002cd44 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeaac>
10002cd20: 52800108    	mov	w8, #0x8                ; =8
10002cd24: 14000008    	b	0x10002cd44 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeaac>
10002cd28: 52800068    	mov	w8, #0x3                ; =3
10002cd2c: 14000006    	b	0x10002cd44 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeaac>
10002cd30: 528000a8    	mov	w8, #0x5                ; =5
10002cd34: 14000004    	b	0x10002cd44 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeaac>
10002cd38: 528000e8    	mov	w8, #0x7                ; =7
10002cd3c: 14000002    	b	0x10002cd44 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xeaac>
10002cd40: 52800128    	mov	w8, #0x9                ; =9
10002cd44: f9004fe8    	str	x8, [sp, #0x98]
10002cd48: 52800148    	mov	w8, #0xa                ; =10
10002cd4c: f94193e9    	ldr	x9, [sp, #0x320]
10002cd50: f904d3e9    	str	x9, [sp, #0x9a0]
10002cd54: f904d7e8    	str	x8, [sp, #0x9a8]
10002cd58: 52800508    	mov	w8, #0x28               ; =40
10002cd5c: f904dbe8    	str	x8, [sp, #0x9b0]
10002cd60: 912683e0    	add	x0, sp, #0x9a0
10002cd64: 94000d17    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cd68: f94123e8    	ldr	x8, [sp, #0x240]
10002cd6c: f904d3e8    	str	x8, [sp, #0x9a0]
10002cd70: f9404fe8    	ldr	x8, [sp, #0x98]
10002cd74: f904d7e8    	str	x8, [sp, #0x9a8]
10002cd78: f940b3e8    	ldr	x8, [sp, #0x160]
10002cd7c: f904dbe8    	str	x8, [sp, #0x9b0]
10002cd80: 912683e0    	add	x0, sp, #0x9a0
10002cd84: 94000d0f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cd88: 1003a940    	adr	x0, 0x1000342b0 <_.roc.bytes.62>
10002cd8c: d503201f    	nop
10002cd90: 52800821    	mov	w1, #0x41               ; =65
10002cd94: 94000e2e    	bl	0x10003064c <_roc_cold_shim.roc_builtins_str_from_literal>
10002cd98: f90ee7e0    	str	x0, [sp, #0x1dc8]
10002cd9c: f90eebe1    	str	x1, [sp, #0x1dd0]
10002cda0: f90eefe2    	str	x2, [sp, #0x1dd8]
10002cda4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cda8: 91372000    	add	x0, x0, #0xdc8
10002cdac: 94000e46    	bl	0x1000306c4 <_roc_cold_shim.roc_builtins_crash_str>
10002cdb0: 52a00088    	mov	w8, #0x40000            ; =262144
10002cdb4: f904d3e7    	str	x7, [sp, #0x9a0]
10002cdb8: f904d7e8    	str	x8, [sp, #0x9a8]
10002cdbc: f941b3e8    	ldr	x8, [sp, #0x360]
10002cdc0: f904dbe8    	str	x8, [sp, #0x9b0]
10002cdc4: 912683e0    	add	x0, sp, #0x9a0
10002cdc8: 94000cfe    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cdcc: 1003b121    	adr	x1, 0x1000343f0 <_.roc.bytes.71>
10002cdd0: d503201f    	nop
10002cdd4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cdd8: 91372000    	add	x0, x0, #0xdc8
10002cddc: 52800702    	mov	w2, #0x38               ; =56
10002cde0: 94001571    	bl	0x1000323a4 <_dev_wrappers.roc_builtins_str_from_literal>
10002cde4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cde8: 91372000    	add	x0, x0, #0xdc8
10002cdec: 940012f5    	bl	0x1000319c0 <_dev_wrappers.roc_builtins_crash_str>
10002cdf0: f90ec3f3    	str	x19, [sp, #0x1d80]
10002cdf4: f90ec7e1    	str	x1, [sp, #0x1d88]
10002cdf8: f94163e8    	ldr	x8, [sp, #0x2c0]
10002cdfc: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ce00: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ce04: 91360000    	add	x0, x0, #0xd80
10002ce08: aa1103f3    	mov	x19, x17
10002ce0c: 94000ced    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ce10: f90ec3f8    	str	x24, [sp, #0x1d80]
10002ce14: f90ec7f3    	str	x19, [sp, #0x1d88]
10002ce18: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002ce1c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ce20: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ce24: 91360000    	add	x0, x0, #0xd80
10002ce28: 94000ce6    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ce2c: f90ec3f4    	str	x20, [sp, #0x1d80]
10002ce30: f90ec7f7    	str	x23, [sp, #0x1d88]
10002ce34: f9415be8    	ldr	x8, [sp, #0x2b0]
10002ce38: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ce3c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ce40: 91360000    	add	x0, x0, #0xd80
10002ce44: 94000cdf    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ce48: 52800148    	mov	w8, #0xa                ; =10
10002ce4c: f940f7e9    	ldr	x9, [sp, #0x1e8]
10002ce50: f90ec3e9    	str	x9, [sp, #0x1d80]
10002ce54: f90ec7e8    	str	x8, [sp, #0x1d88]
10002ce58: 52800508    	mov	w8, #0x28               ; =40
10002ce5c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ce60: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ce64: 91360000    	add	x0, x0, #0xd80
10002ce68: 94000cd6    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ce6c: f94133e8    	ldr	x8, [sp, #0x260]
10002ce70: f90ec3e8    	str	x8, [sp, #0x1d80]
10002ce74: f94173e8    	ldr	x8, [sp, #0x2e0]
10002ce78: f90ec7e8    	str	x8, [sp, #0x1d88]
10002ce7c: f940e3e8    	ldr	x8, [sp, #0x1c0]
10002ce80: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ce84: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ce88: 91360000    	add	x0, x0, #0xd80
10002ce8c: 94000ccd    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ce90: 528021c8    	mov	w8, #0x10e              ; =270
10002ce94: f9412be9    	ldr	x9, [sp, #0x250]
10002ce98: f90ec3e9    	str	x9, [sp, #0x1d80]
10002ce9c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002cea0: 52804608    	mov	w8, #0x230              ; =560
10002cea4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002cea8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ceac: 91360000    	add	x0, x0, #0xd80
10002ceb0: 94000cc4    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ceb4: 52804168    	mov	w8, #0x20b              ; =523
10002ceb8: f90ec3f5    	str	x21, [sp, #0x1d80]
10002cebc: f90ec7e8    	str	x8, [sp, #0x1d88]
10002cec0: 52808548    	mov	w8, #0x42a              ; =1066
10002cec4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002cec8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cecc: 91360000    	add	x0, x0, #0xd80
10002ced0: 94000cbc    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ced4: 3dc1ffe0    	ldr	q0, [sp, #0x7f0]
10002ced8: 3d8763e0    	str	q0, [sp, #0x1d80]
10002cedc: f94403e8    	ldr	x8, [sp, #0x800]
10002cee0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002cee4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cee8: 91360000    	add	x0, x0, #0xd80
10002ceec: 94000cb5    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cef0: 3dc1f7e0    	ldr	q0, [sp, #0x7d0]
10002cef4: 3d8763e0    	str	q0, [sp, #0x1d80]
10002cef8: f943f3e8    	ldr	x8, [sp, #0x7e0]
10002cefc: f90ecbe8    	str	x8, [sp, #0x1d90]
10002cf00: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cf04: 91360000    	add	x0, x0, #0xd80
10002cf08: 94000cae    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cf0c: 3dc1efe0    	ldr	q0, [sp, #0x7b0]
10002cf10: 3d8763e0    	str	q0, [sp, #0x1d80]
10002cf14: f943e3e8    	ldr	x8, [sp, #0x7c0]
10002cf18: f90ecbe8    	str	x8, [sp, #0x1d90]
10002cf1c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cf20: 91360000    	add	x0, x0, #0xd80
10002cf24: 94000ca7    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cf28: 3dc1e7e0    	ldr	q0, [sp, #0x790]
10002cf2c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002cf30: f943d3e8    	ldr	x8, [sp, #0x7a0]
10002cf34: f90ecbe8    	str	x8, [sp, #0x1d90]
10002cf38: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cf3c: 91360000    	add	x0, x0, #0xd80
10002cf40: 94000ca0    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cf44: f94143e8    	ldr	x8, [sp, #0x280]
10002cf48: f90ec3e8    	str	x8, [sp, #0x1d80]
10002cf4c: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002cf50: f90ec7e8    	str	x8, [sp, #0x1d88]
10002cf54: f9414be8    	ldr	x8, [sp, #0x290]
10002cf58: f90ecbe8    	str	x8, [sp, #0x1d90]
10002cf5c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cf60: 91360000    	add	x0, x0, #0xd80
10002cf64: 94000c97    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cf68: 10037341    	adr	x1, 0x100033dd0 <_.roc.bytes.35>
10002cf6c: d503201f    	nop
10002cf70: 912a03e0    	add	x0, sp, #0xa80
10002cf74: 52800722    	mov	w2, #0x39               ; =57
10002cf78: 9400150b    	bl	0x1000323a4 <_dev_wrappers.roc_builtins_str_from_literal>
10002cf7c: 912a03e0    	add	x0, sp, #0xa80
10002cf80: 94001290    	bl	0x1000319c0 <_dev_wrappers.roc_builtins_crash_str>
10002cf84: 914007f3    	add	x19, sp, #0x1, lsl #12  ; =0x1000
10002cf88: 91038273    	add	x19, x19, #0xe0
10002cf8c: 3cc48260    	ldur	q0, [x19, #0x48]
10002cf90: 3d8763e0    	str	q0, [sp, #0x1d80]
10002cf94: f9489fe8    	ldr	x8, [sp, #0x1138]
10002cf98: f90ecbe8    	str	x8, [sp, #0x1d90]
10002cf9c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cfa0: 91360000    	add	x0, x0, #0xd80
10002cfa4: 94000c87    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cfa8: 3cc60260    	ldur	q0, [x19, #0x60]
10002cfac: 3d8763e0    	str	q0, [sp, #0x1d80]
10002cfb0: f948abe8    	ldr	x8, [sp, #0x1150]
10002cfb4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002cfb8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cfbc: 91360000    	add	x0, x0, #0xd80
10002cfc0: 94000c80    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cfc4: 3cc78260    	ldur	q0, [x19, #0x78]
10002cfc8: 3d8763e0    	str	q0, [sp, #0x1d80]
10002cfcc: f948b7e8    	ldr	x8, [sp, #0x1168]
10002cfd0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002cfd4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cfd8: 91360000    	add	x0, x0, #0xd80
10002cfdc: 94000c79    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cfe0: 3cc90260    	ldur	q0, [x19, #0x90]
10002cfe4: 3d8763e0    	str	q0, [sp, #0x1d80]
10002cfe8: f948c3e8    	ldr	x8, [sp, #0x1180]
10002cfec: f90ecbe8    	str	x8, [sp, #0x1d90]
10002cff0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002cff4: 91360000    	add	x0, x0, #0xd80
10002cff8: 94000c72    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002cffc: 3cca8260    	ldur	q0, [x19, #0xa8]
10002d000: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d004: f948cfe8    	ldr	x8, [sp, #0x1198]
10002d008: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d00c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d010: 91360000    	add	x0, x0, #0xd80
10002d014: 94000c6b    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d018: 3ccc0260    	ldur	q0, [x19, #0xc0]
10002d01c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d020: f948dbe8    	ldr	x8, [sp, #0x11b0]
10002d024: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d028: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d02c: 91360000    	add	x0, x0, #0xd80
10002d030: 94000c64    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d034: 3dc43be0    	ldr	q0, [sp, #0x10e0]
10002d038: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d03c: f9487be8    	ldr	x8, [sp, #0x10f0]
10002d040: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d044: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d048: 91360000    	add	x0, x0, #0xd80
10002d04c: 94000c5d    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d050: 3cc18260    	ldur	q0, [x19, #0x18]
10002d054: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d058: f94887e8    	ldr	x8, [sp, #0x1108]
10002d05c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d060: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d064: 91360000    	add	x0, x0, #0xd80
10002d068: 94000c56    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d06c: 3dc447e0    	ldr	q0, [sp, #0x1110]
10002d070: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d074: f94893e8    	ldr	x8, [sp, #0x1120]
10002d078: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d07c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d080: 91360000    	add	x0, x0, #0xd80
10002d084: 94000c4f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d088: 3dc4e7e0    	ldr	q0, [sp, #0x1390]
10002d08c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d090: f949d3e8    	ldr	x8, [sp, #0x13a0]
10002d094: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d098: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d09c: 91360000    	add	x0, x0, #0xd80
10002d0a0: 94000c48    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d0a4: 3dc4dfe0    	ldr	q0, [sp, #0x1370]
10002d0a8: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d0ac: f949c3e8    	ldr	x8, [sp, #0x1380]
10002d0b0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d0b4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d0b8: 91360000    	add	x0, x0, #0xd80
10002d0bc: 94000c41    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d0c0: 3dc4d7e0    	ldr	q0, [sp, #0x1350]
10002d0c4: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d0c8: f949b3e8    	ldr	x8, [sp, #0x1360]
10002d0cc: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d0d0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d0d4: 91360000    	add	x0, x0, #0xd80
10002d0d8: 94000c3a    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d0dc: f90ec3fc    	str	x28, [sp, #0x1d80]
10002d0e0: f94103e8    	ldr	x8, [sp, #0x200]
10002d0e4: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d0e8: f940fbe8    	ldr	x8, [sp, #0x1f0]
10002d0ec: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d0f0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d0f4: 91360000    	add	x0, x0, #0xd80
10002d0f8: 94000c32    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d0fc: f94123e8    	ldr	x8, [sp, #0x240]
10002d100: f90ec3e8    	str	x8, [sp, #0x1d80]
10002d104: f94147e8    	ldr	x8, [sp, #0x288]
10002d108: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d10c: f940b3e8    	ldr	x8, [sp, #0x160]
10002d110: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d114: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d118: 91360000    	add	x0, x0, #0xd80
10002d11c: 94000c29    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d120: 52800148    	mov	w8, #0xa                ; =10
10002d124: f90ec3f4    	str	x20, [sp, #0x1d80]
10002d128: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d12c: 52800508    	mov	w8, #0x28               ; =40
10002d130: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d134: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d138: 91360000    	add	x0, x0, #0xd80
10002d13c: 94000c21    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d140: 52802068    	mov	w8, #0x103              ; =259
10002d144: f9418fe9    	ldr	x9, [sp, #0x318]
10002d148: f90ec3e9    	str	x9, [sp, #0x1d80]
10002d14c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d150: 52804348    	mov	w8, #0x21a              ; =538
10002d154: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d158: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d15c: 91360000    	add	x0, x0, #0xd80
10002d160: 94000c18    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d164: f941afe8    	ldr	x8, [sp, #0x358]
10002d168: f90ec3e8    	str	x8, [sp, #0x1d80]
10002d16c: 529cac28    	mov	w8, #0xe561             ; =58721
10002d170: 72a002c8    	movk	w8, #0x16, lsl #16
10002d174: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d178: 52995ac8    	mov	w8, #0xcad6             ; =51926
10002d17c: 72a005a8    	movk	w8, #0x2d, lsl #16
10002d180: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d184: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d188: 91360000    	add	x0, x0, #0xd80
10002d18c: 94000c0d    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d190: 52a00088    	mov	w8, #0x40000            ; =262144
10002d194: f94113e9    	ldr	x9, [sp, #0x220]
10002d198: f90ec3e9    	str	x9, [sp, #0x1d80]
10002d19c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d1a0: f941b3e8    	ldr	x8, [sp, #0x360]
10002d1a4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d1a8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d1ac: 91360000    	add	x0, x0, #0xd80
10002d1b0: 94000c04    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d1b4: 3dc30fe0    	ldr	q0, [sp, #0xc30]
10002d1b8: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d1bc: f94623e8    	ldr	x8, [sp, #0xc40]
10002d1c0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d1c4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d1c8: 91360000    	add	x0, x0, #0xd80
10002d1cc: 94000bfd    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d1d0: 3dc307e0    	ldr	q0, [sp, #0xc10]
10002d1d4: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d1d8: f94613e8    	ldr	x8, [sp, #0xc20]
10002d1dc: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d1e0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d1e4: 91360000    	add	x0, x0, #0xd80
10002d1e8: 94000bf6    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d1ec: 3dc2ffe0    	ldr	q0, [sp, #0xbf0]
10002d1f0: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d1f4: f94603e8    	ldr	x8, [sp, #0xc00]
10002d1f8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d1fc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d200: 91360000    	add	x0, x0, #0xd80
10002d204: 94000bef    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d208: 3dc2f7e0    	ldr	q0, [sp, #0xbd0]
10002d20c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d210: f945f3e8    	ldr	x8, [sp, #0xbe0]
10002d214: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d218: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d21c: 91360000    	add	x0, x0, #0xd80
10002d220: 94000be8    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d224: f94143e8    	ldr	x8, [sp, #0x280]
10002d228: f90ec3e8    	str	x8, [sp, #0x1d80]
10002d22c: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002d230: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d234: f9414be8    	ldr	x8, [sp, #0x290]
10002d238: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d23c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d240: 91360000    	add	x0, x0, #0xd80
10002d244: 94000bdf    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d248: a95aa3e9    	ldp	x9, x8, [sp, #0x1a8]
10002d24c: f90ec3e9    	str	x9, [sp, #0x1d80]
10002d250: f90ec7ff    	str	xzr, [sp, #0x1d88]
10002d254: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d258: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d25c: 91360000    	add	x0, x0, #0xd80
10002d260: 94000bd8    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d264: 10035960    	adr	x0, 0x100033d90 <_.roc.bytes.33>
10002d268: d503201f    	nop
10002d26c: 52800641    	mov	w1, #0x32               ; =50
10002d270: 94000cf7    	bl	0x10003064c <_roc_cold_shim.roc_builtins_str_from_literal>
10002d274: f908dfe0    	str	x0, [sp, #0x11b8]
10002d278: f908e3e1    	str	x1, [sp, #0x11c0]
10002d27c: f908e7e2    	str	x2, [sp, #0x11c8]
10002d280: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d284: 9106e000    	add	x0, x0, #0x1b8
10002d288: 94000d0f    	bl	0x1000306c4 <_roc_cold_shim.roc_builtins_crash_str>
10002d28c: aa1b03e2    	mov	x2, x27
10002d290: 3700a27b    	tbnz	w27, #0x0, 0x10002e6dc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x10444>
10002d294: d341fc48    	lsr	x8, x2, #1
10002d298: f9417fe9    	ldr	x9, [sp, #0x2f8]
10002d29c: eb09011f    	cmp	x8, x9
10002d2a0: 5400a1e0    	b.eq	0x10002e6dc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x10444>
10002d2a4: b4000088    	cbz	x8, 0x10002d2b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf01c>
10002d2a8: f85f8348    	ldur	x8, [x26, #-0x8]
10002d2ac: f100051f    	cmp	x8, #0x1
10002d2b0: 5400a161    	b.ne	0x10002e6dc <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x10444>
10002d2b4: aa1a03e0    	mov	x0, x26
10002d2b8: f9417ff9    	ldr	x25, [sp, #0x2f8]
10002d2bc: aa1903e1    	mov	x1, x25
10002d2c0: aa0203fb    	mov	x27, x2
10002d2c4: 94000c5b    	bl	0x100030430 <_roc_cold_shim.roc_builtins_list_slack_unique>
10002d2c8: 17fff553    	b	0x10002a814 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc57c>
10002d2cc: f90ec3f8    	str	x24, [sp, #0x1d80]
10002d2d0: f90ec7fa    	str	x26, [sp, #0x1d88]
10002d2d4: f941a7e8    	ldr	x8, [sp, #0x348]
10002d2d8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d2dc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d2e0: 91360000    	add	x0, x0, #0xd80
10002d2e4: aa0603f4    	mov	x20, x6
10002d2e8: 94000bb6    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d2ec: f90ec3f9    	str	x25, [sp, #0x1d80]
10002d2f0: f90ec7f4    	str	x20, [sp, #0x1d88]
10002d2f4: f941abe8    	ldr	x8, [sp, #0x350]
10002d2f8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d2fc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d300: 91360000    	add	x0, x0, #0xd80
10002d304: 94000baf    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d308: f90ec3f5    	str	x21, [sp, #0x1d80]
10002d30c: f90ec7fc    	str	x28, [sp, #0x1d88]
10002d310: f941afe8    	ldr	x8, [sp, #0x358]
10002d314: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d318: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d31c: 91360000    	add	x0, x0, #0xd80
10002d320: 94000ba8    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d324: f94147e8    	ldr	x8, [sp, #0x288]
10002d328: f90ec3e8    	str	x8, [sp, #0x1d80]
10002d32c: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002d330: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d334: f94103e8    	ldr	x8, [sp, #0x200]
10002d338: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d33c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d340: 91360000    	add	x0, x0, #0xd80
10002d344: 94000b9f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d348: 528021c8    	mov	w8, #0x10e              ; =270
10002d34c: f9412be9    	ldr	x9, [sp, #0x250]
10002d350: f90ec3e9    	str	x9, [sp, #0x1d80]
10002d354: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d358: 52804608    	mov	w8, #0x230              ; =560
10002d35c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d360: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d364: 91360000    	add	x0, x0, #0xd80
10002d368: 94000b96    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d36c: 52804168    	mov	w8, #0x20b              ; =523
10002d370: f90ec3f3    	str	x19, [sp, #0x1d80]
10002d374: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d378: 52808548    	mov	w8, #0x42a              ; =1066
10002d37c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d380: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d384: 91360000    	add	x0, x0, #0xd80
10002d388: 94000b8e    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d38c: 52800148    	mov	w8, #0xa                ; =10
10002d390: f940dfe9    	ldr	x9, [sp, #0x1b8]
10002d394: f90ec3e9    	str	x9, [sp, #0x1d80]
10002d398: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d39c: 52800508    	mov	w8, #0x28               ; =40
10002d3a0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d3a4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d3a8: 91360000    	add	x0, x0, #0xd80
10002d3ac: 94000b85    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d3b0: 3dc0f7e0    	ldr	q0, [sp, #0x3d0]
10002d3b4: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d3b8: f941f3e8    	ldr	x8, [sp, #0x3e0]
10002d3bc: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d3c0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d3c4: 91360000    	add	x0, x0, #0xd80
10002d3c8: 94000b7e    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d3cc: 3dc0efe0    	ldr	q0, [sp, #0x3b0]
10002d3d0: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d3d4: f941e3e8    	ldr	x8, [sp, #0x3c0]
10002d3d8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d3dc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d3e0: 91360000    	add	x0, x0, #0xd80
10002d3e4: 94000b77    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d3e8: 3dc0e7e0    	ldr	q0, [sp, #0x390]
10002d3ec: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d3f0: f941d3e8    	ldr	x8, [sp, #0x3a0]
10002d3f4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d3f8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d3fc: 91360000    	add	x0, x0, #0xd80
10002d400: 94000b70    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d404: 3dc0dfe0    	ldr	q0, [sp, #0x370]
10002d408: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d40c: f941c3e8    	ldr	x8, [sp, #0x380]
10002d410: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d414: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d418: 91360000    	add	x0, x0, #0xd80
10002d41c: 94000b69    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d420: f94143e8    	ldr	x8, [sp, #0x280]
10002d424: f90ec3e8    	str	x8, [sp, #0x1d80]
10002d428: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002d42c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d430: f9414be8    	ldr	x8, [sp, #0x290]
10002d434: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d438: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d43c: 91360000    	add	x0, x0, #0xd80
10002d440: 94000b60    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d444: 10035861    	adr	x1, 0x100033f50 <_.roc.bytes.45>
10002d448: d503201f    	nop
10002d44c: 911963e0    	add	x0, sp, #0x658
10002d450: 528006c2    	mov	w2, #0x36               ; =54
10002d454: 940013d4    	bl	0x1000323a4 <_dev_wrappers.roc_builtins_str_from_literal>
10002d458: 911963e0    	add	x0, sp, #0x658
10002d45c: 94001159    	bl	0x1000319c0 <_dev_wrappers.roc_builtins_crash_str>
10002d460: f90ec3f6    	str	x22, [sp, #0x1d80]
10002d464: f90ec7fc    	str	x28, [sp, #0x1d88]
10002d468: f941afe8    	ldr	x8, [sp, #0x358]
10002d46c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d470: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d474: 91360000    	add	x0, x0, #0xd80
10002d478: aa0603f6    	mov	x22, x6
10002d47c: 94000b51    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d480: f90ec3f5    	str	x21, [sp, #0x1d80]
10002d484: f90ec7f6    	str	x22, [sp, #0x1d88]
10002d488: f941abe8    	ldr	x8, [sp, #0x350]
10002d48c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d490: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d494: 91360000    	add	x0, x0, #0xd80
10002d498: 94000b4a    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d49c: f90ec3f4    	str	x20, [sp, #0x1d80]
10002d4a0: f90ec7fa    	str	x26, [sp, #0x1d88]
10002d4a4: f941a7e8    	ldr	x8, [sp, #0x348]
10002d4a8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d4ac: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d4b0: 91360000    	add	x0, x0, #0xd80
10002d4b4: 94000b43    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d4b8: f94147e8    	ldr	x8, [sp, #0x288]
10002d4bc: f90ec3e8    	str	x8, [sp, #0x1d80]
10002d4c0: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002d4c4: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d4c8: f94103e8    	ldr	x8, [sp, #0x200]
10002d4cc: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d4d0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d4d4: 91360000    	add	x0, x0, #0xd80
10002d4d8: 94000b3a    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d4dc: 528021c8    	mov	w8, #0x10e              ; =270
10002d4e0: f9412be9    	ldr	x9, [sp, #0x250]
10002d4e4: f90ec3e9    	str	x9, [sp, #0x1d80]
10002d4e8: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d4ec: 52804608    	mov	w8, #0x230              ; =560
10002d4f0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d4f4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d4f8: 91360000    	add	x0, x0, #0xd80
10002d4fc: 94000b31    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d500: 52804168    	mov	w8, #0x20b              ; =523
10002d504: f90ec3f3    	str	x19, [sp, #0x1d80]
10002d508: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d50c: 52808548    	mov	w8, #0x42a              ; =1066
10002d510: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d514: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d518: 91360000    	add	x0, x0, #0xd80
10002d51c: 94000b29    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d520: 52800148    	mov	w8, #0xa                ; =10
10002d524: f940dfe9    	ldr	x9, [sp, #0x1b8]
10002d528: f90ec3e9    	str	x9, [sp, #0x1d80]
10002d52c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d530: 52800508    	mov	w8, #0x28               ; =40
10002d534: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d538: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d53c: 91360000    	add	x0, x0, #0xd80
10002d540: 94000b20    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d544: 3dc0f7e0    	ldr	q0, [sp, #0x3d0]
10002d548: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d54c: f941f3e8    	ldr	x8, [sp, #0x3e0]
10002d550: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d554: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d558: 91360000    	add	x0, x0, #0xd80
10002d55c: 94000b19    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d560: 3dc0efe0    	ldr	q0, [sp, #0x3b0]
10002d564: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d568: f941e3e8    	ldr	x8, [sp, #0x3c0]
10002d56c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d570: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d574: 91360000    	add	x0, x0, #0xd80
10002d578: 94000b12    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d57c: 3dc0e7e0    	ldr	q0, [sp, #0x390]
10002d580: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d584: f941d3e8    	ldr	x8, [sp, #0x3a0]
10002d588: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d58c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d590: 91360000    	add	x0, x0, #0xd80
10002d594: 94000b0b    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d598: 3dc0dfe0    	ldr	q0, [sp, #0x370]
10002d59c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d5a0: f941c3e8    	ldr	x8, [sp, #0x380]
10002d5a4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d5a8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d5ac: 91360000    	add	x0, x0, #0xd80
10002d5b0: 94000b04    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d5b4: f94143e8    	ldr	x8, [sp, #0x280]
10002d5b8: f90ec3e8    	str	x8, [sp, #0x1d80]
10002d5bc: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002d5c0: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d5c4: f9414be8    	ldr	x8, [sp, #0x290]
10002d5c8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d5cc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d5d0: 91360000    	add	x0, x0, #0xd80
10002d5d4: 94000afb    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d5d8: 100349c1    	adr	x1, 0x100033f10 <_.roc.bytes.44>
10002d5dc: d503201f    	nop
10002d5e0: 9119c3e0    	add	x0, sp, #0x670
10002d5e4: 52800642    	mov	w2, #0x32               ; =50
10002d5e8: 9400136f    	bl	0x1000323a4 <_dev_wrappers.roc_builtins_str_from_literal>
10002d5ec: 9119c3e0    	add	x0, sp, #0x670
10002d5f0: 940010f4    	bl	0x1000319c0 <_dev_wrappers.roc_builtins_crash_str>
10002d5f4: f90ec3f8    	str	x24, [sp, #0x1d80]
10002d5f8: f90ec7fa    	str	x26, [sp, #0x1d88]
10002d5fc: f941a7e8    	ldr	x8, [sp, #0x348]
10002d600: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d604: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d608: 91360000    	add	x0, x0, #0xd80
10002d60c: aa0603f4    	mov	x20, x6
10002d610: 94000aec    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d614: f90ec3f9    	str	x25, [sp, #0x1d80]
10002d618: f90ec7f4    	str	x20, [sp, #0x1d88]
10002d61c: f941abe8    	ldr	x8, [sp, #0x350]
10002d620: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d624: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d628: 91360000    	add	x0, x0, #0xd80
10002d62c: 94000ae5    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d630: f90ec3f5    	str	x21, [sp, #0x1d80]
10002d634: f90ec7fc    	str	x28, [sp, #0x1d88]
10002d638: f941afe8    	ldr	x8, [sp, #0x358]
10002d63c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d640: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d644: 91360000    	add	x0, x0, #0xd80
10002d648: 94000ade    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d64c: 52800148    	mov	w8, #0xa                ; =10
10002d650: f940dfe9    	ldr	x9, [sp, #0x1b8]
10002d654: f90ec3e9    	str	x9, [sp, #0x1d80]
10002d658: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d65c: 52800508    	mov	w8, #0x28               ; =40
10002d660: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d664: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d668: 91360000    	add	x0, x0, #0xd80
10002d66c: 94000ad5    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d670: f94147e8    	ldr	x8, [sp, #0x288]
10002d674: f90ec3e8    	str	x8, [sp, #0x1d80]
10002d678: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002d67c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d680: f94103e8    	ldr	x8, [sp, #0x200]
10002d684: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d688: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d68c: 91360000    	add	x0, x0, #0xd80
10002d690: 94000acc    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d694: 528021c8    	mov	w8, #0x10e              ; =270
10002d698: f9412be9    	ldr	x9, [sp, #0x250]
10002d69c: f90ec3e9    	str	x9, [sp, #0x1d80]
10002d6a0: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d6a4: 52804608    	mov	w8, #0x230              ; =560
10002d6a8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d6ac: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d6b0: 91360000    	add	x0, x0, #0xd80
10002d6b4: 94000ac3    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d6b8: 52804168    	mov	w8, #0x20b              ; =523
10002d6bc: f90ec3f3    	str	x19, [sp, #0x1d80]
10002d6c0: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d6c4: 52808548    	mov	w8, #0x42a              ; =1066
10002d6c8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d6cc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d6d0: 91360000    	add	x0, x0, #0xd80
10002d6d4: 94000abb    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d6d8: 3dc0f7e0    	ldr	q0, [sp, #0x3d0]
10002d6dc: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d6e0: f941f3e8    	ldr	x8, [sp, #0x3e0]
10002d6e4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d6e8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d6ec: 91360000    	add	x0, x0, #0xd80
10002d6f0: 94000ab4    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d6f4: 3dc0efe0    	ldr	q0, [sp, #0x3b0]
10002d6f8: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d6fc: f941e3e8    	ldr	x8, [sp, #0x3c0]
10002d700: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d704: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d708: 91360000    	add	x0, x0, #0xd80
10002d70c: 94000aad    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d710: 3dc0e7e0    	ldr	q0, [sp, #0x390]
10002d714: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d718: f941d3e8    	ldr	x8, [sp, #0x3a0]
10002d71c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d720: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d724: 91360000    	add	x0, x0, #0xd80
10002d728: 94000aa6    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d72c: 3dc0dfe0    	ldr	q0, [sp, #0x370]
10002d730: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d734: f941c3e8    	ldr	x8, [sp, #0x380]
10002d738: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d73c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d740: 91360000    	add	x0, x0, #0xd80
10002d744: 94000a9f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d748: f94143e8    	ldr	x8, [sp, #0x280]
10002d74c: f90ec3e8    	str	x8, [sp, #0x1d80]
10002d750: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002d754: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d758: f9414be8    	ldr	x8, [sp, #0x290]
10002d75c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d760: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d764: 91360000    	add	x0, x0, #0xd80
10002d768: 94000a96    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d76c: 10033f21    	adr	x1, 0x100033f50 <_.roc.bytes.45>
10002d770: d503201f    	nop
10002d774: 911ba3e0    	add	x0, sp, #0x6e8
10002d778: 528006c2    	mov	w2, #0x36               ; =54
10002d77c: 9400130a    	bl	0x1000323a4 <_dev_wrappers.roc_builtins_str_from_literal>
10002d780: 911ba3e0    	add	x0, sp, #0x6e8
10002d784: 9400108f    	bl	0x1000319c0 <_dev_wrappers.roc_builtins_crash_str>
10002d788: f90ec3f6    	str	x22, [sp, #0x1d80]
10002d78c: f90ec7fc    	str	x28, [sp, #0x1d88]
10002d790: f941afe8    	ldr	x8, [sp, #0x358]
10002d794: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d798: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d79c: 91360000    	add	x0, x0, #0xd80
10002d7a0: aa0603f6    	mov	x22, x6
10002d7a4: 94000a87    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d7a8: f90ec3f5    	str	x21, [sp, #0x1d80]
10002d7ac: f90ec7f6    	str	x22, [sp, #0x1d88]
10002d7b0: f941abe8    	ldr	x8, [sp, #0x350]
10002d7b4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d7b8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d7bc: 91360000    	add	x0, x0, #0xd80
10002d7c0: 94000a80    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d7c4: f90ec3f4    	str	x20, [sp, #0x1d80]
10002d7c8: f90ec7fa    	str	x26, [sp, #0x1d88]
10002d7cc: f941a7e8    	ldr	x8, [sp, #0x348]
10002d7d0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d7d4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d7d8: 91360000    	add	x0, x0, #0xd80
10002d7dc: 94000a79    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d7e0: 52800148    	mov	w8, #0xa                ; =10
10002d7e4: f940dfe9    	ldr	x9, [sp, #0x1b8]
10002d7e8: f90ec3e9    	str	x9, [sp, #0x1d80]
10002d7ec: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d7f0: 52800508    	mov	w8, #0x28               ; =40
10002d7f4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d7f8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d7fc: 91360000    	add	x0, x0, #0xd80
10002d800: 94000a70    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d804: f94147e8    	ldr	x8, [sp, #0x288]
10002d808: f90ec3e8    	str	x8, [sp, #0x1d80]
10002d80c: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002d810: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d814: f94103e8    	ldr	x8, [sp, #0x200]
10002d818: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d81c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d820: 91360000    	add	x0, x0, #0xd80
10002d824: 94000a67    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d828: 528021c8    	mov	w8, #0x10e              ; =270
10002d82c: f9412be9    	ldr	x9, [sp, #0x250]
10002d830: f90ec3e9    	str	x9, [sp, #0x1d80]
10002d834: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d838: 52804608    	mov	w8, #0x230              ; =560
10002d83c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d840: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d844: 91360000    	add	x0, x0, #0xd80
10002d848: 94000a5e    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d84c: 52804168    	mov	w8, #0x20b              ; =523
10002d850: f90ec3f3    	str	x19, [sp, #0x1d80]
10002d854: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d858: 52808548    	mov	w8, #0x42a              ; =1066
10002d85c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d860: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d864: 91360000    	add	x0, x0, #0xd80
10002d868: 94000a56    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d86c: 3dc0f7e0    	ldr	q0, [sp, #0x3d0]
10002d870: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d874: f941f3e8    	ldr	x8, [sp, #0x3e0]
10002d878: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d87c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d880: 91360000    	add	x0, x0, #0xd80
10002d884: 94000a4f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d888: 3dc0efe0    	ldr	q0, [sp, #0x3b0]
10002d88c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d890: f941e3e8    	ldr	x8, [sp, #0x3c0]
10002d894: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d898: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d89c: 91360000    	add	x0, x0, #0xd80
10002d8a0: 94000a48    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d8a4: 3dc0e7e0    	ldr	q0, [sp, #0x390]
10002d8a8: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d8ac: f941d3e8    	ldr	x8, [sp, #0x3a0]
10002d8b0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d8b4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d8b8: 91360000    	add	x0, x0, #0xd80
10002d8bc: 94000a41    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d8c0: 3dc0dfe0    	ldr	q0, [sp, #0x370]
10002d8c4: 3d8763e0    	str	q0, [sp, #0x1d80]
10002d8c8: f941c3e8    	ldr	x8, [sp, #0x380]
10002d8cc: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d8d0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d8d4: 91360000    	add	x0, x0, #0xd80
10002d8d8: 94000a3a    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d8dc: f94143e8    	ldr	x8, [sp, #0x280]
10002d8e0: f90ec3e8    	str	x8, [sp, #0x1d80]
10002d8e4: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002d8e8: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d8ec: f9414be8    	ldr	x8, [sp, #0x290]
10002d8f0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d8f4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d8f8: 91360000    	add	x0, x0, #0xd80
10002d8fc: 94000a31    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d900: 10033081    	adr	x1, 0x100033f10 <_.roc.bytes.44>
10002d904: d503201f    	nop
10002d908: 911c03e0    	add	x0, sp, #0x700
10002d90c: 52800642    	mov	w2, #0x32               ; =50
10002d910: 940012a5    	bl	0x1000323a4 <_dev_wrappers.roc_builtins_str_from_literal>
10002d914: 911c03e0    	add	x0, sp, #0x700
10002d918: 9400102a    	bl	0x1000319c0 <_dev_wrappers.roc_builtins_crash_str>
10002d91c: f941afe8    	ldr	x8, [sp, #0x358]
10002d920: f904d3e8    	str	x8, [sp, #0x9a0]
10002d924: 529cac28    	mov	w8, #0xe561             ; =58721
10002d928: 72a002c8    	movk	w8, #0x16, lsl #16
10002d92c: f904d7e8    	str	x8, [sp, #0x9a8]
10002d930: 52995ac8    	mov	w8, #0xcad6             ; =51926
10002d934: 72a005a8    	movk	w8, #0x2d, lsl #16
10002d938: f904dbe8    	str	x8, [sp, #0x9b0]
10002d93c: 912683e0    	add	x0, sp, #0x9a0
10002d940: aa0703f3    	mov	x19, x7
10002d944: 94000a1f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d948: 52a00088    	mov	w8, #0x40000            ; =262144
10002d94c: f904d3f3    	str	x19, [sp, #0x9a0]
10002d950: f904d7e8    	str	x8, [sp, #0x9a8]
10002d954: f941b3e8    	ldr	x8, [sp, #0x360]
10002d958: f904dbe8    	str	x8, [sp, #0x9b0]
10002d95c: 912683e0    	add	x0, sp, #0x9a0
10002d960: 94000a18    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d964: 10035061    	adr	x1, 0x100034370 <_.roc.bytes.68>
10002d968: d503201f    	nop
10002d96c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d970: 91372000    	add	x0, x0, #0xdc8
10002d974: 52800742    	mov	w2, #0x3a               ; =58
10002d978: 9400128b    	bl	0x1000323a4 <_dev_wrappers.roc_builtins_str_from_literal>
10002d97c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d980: 91372000    	add	x0, x0, #0xdc8
10002d984: 9400100f    	bl	0x1000319c0 <_dev_wrappers.roc_builtins_crash_str>
10002d988: f90ec3f8    	str	x24, [sp, #0x1d80]
10002d98c: f90ec7fa    	str	x26, [sp, #0x1d88]
10002d990: f941a7e8    	ldr	x8, [sp, #0x348]
10002d994: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d998: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d99c: 91360000    	add	x0, x0, #0xd80
10002d9a0: aa0603f4    	mov	x20, x6
10002d9a4: 94000a07    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d9a8: f90ec3f9    	str	x25, [sp, #0x1d80]
10002d9ac: f90ec7f4    	str	x20, [sp, #0x1d88]
10002d9b0: f941abe8    	ldr	x8, [sp, #0x350]
10002d9b4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d9b8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d9bc: 91360000    	add	x0, x0, #0xd80
10002d9c0: 94000a00    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d9c4: f90ec3f5    	str	x21, [sp, #0x1d80]
10002d9c8: f90ec7fc    	str	x28, [sp, #0x1d88]
10002d9cc: f941afe8    	ldr	x8, [sp, #0x358]
10002d9d0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d9d4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d9d8: 91360000    	add	x0, x0, #0xd80
10002d9dc: 940009f9    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002d9e0: f94147e8    	ldr	x8, [sp, #0x288]
10002d9e4: f90ec3e8    	str	x8, [sp, #0x1d80]
10002d9e8: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002d9ec: f90ec7e8    	str	x8, [sp, #0x1d88]
10002d9f0: f94103e8    	ldr	x8, [sp, #0x200]
10002d9f4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002d9f8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002d9fc: 91360000    	add	x0, x0, #0xd80
10002da00: 940009f0    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002da04: 528021c8    	mov	w8, #0x10e              ; =270
10002da08: f9412be9    	ldr	x9, [sp, #0x250]
10002da0c: f90ec3e9    	str	x9, [sp, #0x1d80]
10002da10: f90ec7e8    	str	x8, [sp, #0x1d88]
10002da14: 52804608    	mov	w8, #0x230              ; =560
10002da18: f90ecbe8    	str	x8, [sp, #0x1d90]
10002da1c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002da20: 91360000    	add	x0, x0, #0xd80
10002da24: 940009e7    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002da28: 52804168    	mov	w8, #0x20b              ; =523
10002da2c: f90ec3f3    	str	x19, [sp, #0x1d80]
10002da30: f90ec7e8    	str	x8, [sp, #0x1d88]
10002da34: 52808548    	mov	w8, #0x42a              ; =1066
10002da38: f90ecbe8    	str	x8, [sp, #0x1d90]
10002da3c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002da40: 91360000    	add	x0, x0, #0xd80
10002da44: 940009df    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002da48: 52800148    	mov	w8, #0xa                ; =10
10002da4c: f940dfe9    	ldr	x9, [sp, #0x1b8]
10002da50: f90ec3e9    	str	x9, [sp, #0x1d80]
10002da54: f90ec7e8    	str	x8, [sp, #0x1d88]
10002da58: 52800508    	mov	w8, #0x28               ; =40
10002da5c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002da60: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002da64: 91360000    	add	x0, x0, #0xd80
10002da68: 940009d6    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002da6c: 3dc0f7e0    	ldr	q0, [sp, #0x3d0]
10002da70: 3d8763e0    	str	q0, [sp, #0x1d80]
10002da74: f941f3e8    	ldr	x8, [sp, #0x3e0]
10002da78: f90ecbe8    	str	x8, [sp, #0x1d90]
10002da7c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002da80: 91360000    	add	x0, x0, #0xd80
10002da84: 940009cf    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002da88: 3dc0efe0    	ldr	q0, [sp, #0x3b0]
10002da8c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002da90: f941e3e8    	ldr	x8, [sp, #0x3c0]
10002da94: f90ecbe8    	str	x8, [sp, #0x1d90]
10002da98: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002da9c: 91360000    	add	x0, x0, #0xd80
10002daa0: 940009c8    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002daa4: 3dc0e7e0    	ldr	q0, [sp, #0x390]
10002daa8: 3d8763e0    	str	q0, [sp, #0x1d80]
10002daac: f941d3e8    	ldr	x8, [sp, #0x3a0]
10002dab0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002dab4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002dab8: 91360000    	add	x0, x0, #0xd80
10002dabc: 940009c1    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002dac0: 3dc0dfe0    	ldr	q0, [sp, #0x370]
10002dac4: 3d8763e0    	str	q0, [sp, #0x1d80]
10002dac8: f941c3e8    	ldr	x8, [sp, #0x380]
10002dacc: f90ecbe8    	str	x8, [sp, #0x1d90]
10002dad0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002dad4: 91360000    	add	x0, x0, #0xd80
10002dad8: 940009ba    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002dadc: f94143e8    	ldr	x8, [sp, #0x280]
10002dae0: f90ec3e8    	str	x8, [sp, #0x1d80]
10002dae4: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002dae8: f90ec7e8    	str	x8, [sp, #0x1d88]
10002daec: f9414be8    	ldr	x8, [sp, #0x290]
10002daf0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002daf4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002daf8: 91360000    	add	x0, x0, #0xd80
10002dafc: 940009b1    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002db00: 10032281    	adr	x1, 0x100033f50 <_.roc.bytes.45>
10002db04: d503201f    	nop
10002db08: 911723e0    	add	x0, sp, #0x5c8
10002db0c: 528006c2    	mov	w2, #0x36               ; =54
10002db10: 94001225    	bl	0x1000323a4 <_dev_wrappers.roc_builtins_str_from_literal>
10002db14: 911723e0    	add	x0, sp, #0x5c8
10002db18: 94000faa    	bl	0x1000319c0 <_dev_wrappers.roc_builtins_crash_str>
10002db1c: f90ec3f6    	str	x22, [sp, #0x1d80]
10002db20: f90ec7fc    	str	x28, [sp, #0x1d88]
10002db24: f941afe8    	ldr	x8, [sp, #0x358]
10002db28: f90ecbe8    	str	x8, [sp, #0x1d90]
10002db2c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002db30: 91360000    	add	x0, x0, #0xd80
10002db34: aa0603f5    	mov	x21, x6
10002db38: 940009a2    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002db3c: f90ec3f7    	str	x23, [sp, #0x1d80]
10002db40: f90ec7f5    	str	x21, [sp, #0x1d88]
10002db44: f941abe8    	ldr	x8, [sp, #0x350]
10002db48: f90ecbe8    	str	x8, [sp, #0x1d90]
10002db4c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002db50: 91360000    	add	x0, x0, #0xd80
10002db54: 9400099b    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002db58: f90ec3f4    	str	x20, [sp, #0x1d80]
10002db5c: f90ec7fa    	str	x26, [sp, #0x1d88]
10002db60: f941a7e8    	ldr	x8, [sp, #0x348]
10002db64: f90ecbe8    	str	x8, [sp, #0x1d90]
10002db68: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002db6c: 91360000    	add	x0, x0, #0xd80
10002db70: 94000994    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002db74: f94147e8    	ldr	x8, [sp, #0x288]
10002db78: f90ec3e8    	str	x8, [sp, #0x1d80]
10002db7c: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002db80: f90ec7e8    	str	x8, [sp, #0x1d88]
10002db84: f94103e8    	ldr	x8, [sp, #0x200]
10002db88: f90ecbe8    	str	x8, [sp, #0x1d90]
10002db8c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002db90: 91360000    	add	x0, x0, #0xd80
10002db94: 9400098b    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002db98: 528021c8    	mov	w8, #0x10e              ; =270
10002db9c: f9412be9    	ldr	x9, [sp, #0x250]
10002dba0: f90ec3e9    	str	x9, [sp, #0x1d80]
10002dba4: f90ec7e8    	str	x8, [sp, #0x1d88]
10002dba8: 52804608    	mov	w8, #0x230              ; =560
10002dbac: f90ecbe8    	str	x8, [sp, #0x1d90]
10002dbb0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002dbb4: 91360000    	add	x0, x0, #0xd80
10002dbb8: 94000982    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002dbbc: 52804168    	mov	w8, #0x20b              ; =523
10002dbc0: f90ec3f3    	str	x19, [sp, #0x1d80]
10002dbc4: f90ec7e8    	str	x8, [sp, #0x1d88]
10002dbc8: 52808548    	mov	w8, #0x42a              ; =1066
10002dbcc: f90ecbe8    	str	x8, [sp, #0x1d90]
10002dbd0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002dbd4: 91360000    	add	x0, x0, #0xd80
10002dbd8: 9400097a    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002dbdc: 52800148    	mov	w8, #0xa                ; =10
10002dbe0: f940dfe9    	ldr	x9, [sp, #0x1b8]
10002dbe4: f90ec3e9    	str	x9, [sp, #0x1d80]
10002dbe8: f90ec7e8    	str	x8, [sp, #0x1d88]
10002dbec: 52800508    	mov	w8, #0x28               ; =40
10002dbf0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002dbf4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002dbf8: 91360000    	add	x0, x0, #0xd80
10002dbfc: 94000971    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002dc00: 3dc0f7e0    	ldr	q0, [sp, #0x3d0]
10002dc04: 3d8763e0    	str	q0, [sp, #0x1d80]
10002dc08: f941f3e8    	ldr	x8, [sp, #0x3e0]
10002dc0c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002dc10: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002dc14: 91360000    	add	x0, x0, #0xd80
10002dc18: 9400096a    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002dc1c: 3dc0efe0    	ldr	q0, [sp, #0x3b0]
10002dc20: 3d8763e0    	str	q0, [sp, #0x1d80]
10002dc24: f941e3e8    	ldr	x8, [sp, #0x3c0]
10002dc28: f90ecbe8    	str	x8, [sp, #0x1d90]
10002dc2c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002dc30: 91360000    	add	x0, x0, #0xd80
10002dc34: 94000963    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002dc38: 3dc0e7e0    	ldr	q0, [sp, #0x390]
10002dc3c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002dc40: f941d3e8    	ldr	x8, [sp, #0x3a0]
10002dc44: f90ecbe8    	str	x8, [sp, #0x1d90]
10002dc48: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002dc4c: 91360000    	add	x0, x0, #0xd80
10002dc50: 9400095c    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002dc54: 3dc0dfe0    	ldr	q0, [sp, #0x370]
10002dc58: 3d8763e0    	str	q0, [sp, #0x1d80]
10002dc5c: f941c3e8    	ldr	x8, [sp, #0x380]
10002dc60: f90ecbe8    	str	x8, [sp, #0x1d90]
10002dc64: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002dc68: 91360000    	add	x0, x0, #0xd80
10002dc6c: 94000955    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002dc70: f94143e8    	ldr	x8, [sp, #0x280]
10002dc74: f90ec3e8    	str	x8, [sp, #0x1d80]
10002dc78: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002dc7c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002dc80: f9414be8    	ldr	x8, [sp, #0x290]
10002dc84: f90ecbe8    	str	x8, [sp, #0x1d90]
10002dc88: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002dc8c: 91360000    	add	x0, x0, #0xd80
10002dc90: 9400094c    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002dc94: 100313e1    	adr	x1, 0x100033f10 <_.roc.bytes.44>
10002dc98: d503201f    	nop
10002dc9c: 911783e0    	add	x0, sp, #0x5e0
10002dca0: 52800642    	mov	w2, #0x32               ; =50
10002dca4: 940011c0    	bl	0x1000323a4 <_dev_wrappers.roc_builtins_str_from_literal>
10002dca8: 911783e0    	add	x0, sp, #0x5e0
10002dcac: 94000f45    	bl	0x1000319c0 <_dev_wrappers.roc_builtins_crash_str>
10002dcb0: f90ec3f5    	str	x21, [sp, #0x1d80]
10002dcb4: f90ec7fc    	str	x28, [sp, #0x1d88]
10002dcb8: f941afe8    	ldr	x8, [sp, #0x358]
10002dcbc: f90ecbe8    	str	x8, [sp, #0x1d90]
10002dcc0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002dcc4: 91360000    	add	x0, x0, #0xd80
10002dcc8: aa0603f4    	mov	x20, x6
10002dccc: 9400093d    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002dcd0: f90ec3f9    	str	x25, [sp, #0x1d80]
10002dcd4: f90ec7f4    	str	x20, [sp, #0x1d88]
10002dcd8: f941abe8    	ldr	x8, [sp, #0x350]
10002dcdc: f90ecbe8    	str	x8, [sp, #0x1d90]
10002dce0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002dce4: 91360000    	add	x0, x0, #0xd80
10002dce8: 94000936    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002dcec: f90ec3f8    	str	x24, [sp, #0x1d80]
10002dcf0: f90ec7fa    	str	x26, [sp, #0x1d88]
10002dcf4: f941a7e8    	ldr	x8, [sp, #0x348]
10002dcf8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002dcfc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002dd00: 91360000    	add	x0, x0, #0xd80
10002dd04: 9400092f    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002dd08: f94147e8    	ldr	x8, [sp, #0x288]
10002dd0c: f90ec3e8    	str	x8, [sp, #0x1d80]
10002dd10: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002dd14: f90ec7e8    	str	x8, [sp, #0x1d88]
10002dd18: f94103e8    	ldr	x8, [sp, #0x200]
10002dd1c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002dd20: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002dd24: 91360000    	add	x0, x0, #0xd80
10002dd28: 94000926    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002dd2c: 528021c8    	mov	w8, #0x10e              ; =270
10002dd30: f9412be9    	ldr	x9, [sp, #0x250]
10002dd34: f90ec3e9    	str	x9, [sp, #0x1d80]
10002dd38: f90ec7e8    	str	x8, [sp, #0x1d88]
10002dd3c: 52804608    	mov	w8, #0x230              ; =560
10002dd40: f90ecbe8    	str	x8, [sp, #0x1d90]
10002dd44: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002dd48: 91360000    	add	x0, x0, #0xd80
10002dd4c: 9400091d    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002dd50: 52804168    	mov	w8, #0x20b              ; =523
10002dd54: f90ec3f3    	str	x19, [sp, #0x1d80]
10002dd58: f90ec7e8    	str	x8, [sp, #0x1d88]
10002dd5c: 52808548    	mov	w8, #0x42a              ; =1066
10002dd60: f90ecbe8    	str	x8, [sp, #0x1d90]
10002dd64: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002dd68: 91360000    	add	x0, x0, #0xd80
10002dd6c: 94000915    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002dd70: 52800148    	mov	w8, #0xa                ; =10
10002dd74: f940dfe9    	ldr	x9, [sp, #0x1b8]
10002dd78: f90ec3e9    	str	x9, [sp, #0x1d80]
10002dd7c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002dd80: 52800508    	mov	w8, #0x28               ; =40
10002dd84: f90ecbe8    	str	x8, [sp, #0x1d90]
10002dd88: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002dd8c: 91360000    	add	x0, x0, #0xd80
10002dd90: 9400090c    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002dd94: 3dc0f7e0    	ldr	q0, [sp, #0x3d0]
10002dd98: 3d8763e0    	str	q0, [sp, #0x1d80]
10002dd9c: f941f3e8    	ldr	x8, [sp, #0x3e0]
10002dda0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002dda4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002dda8: 91360000    	add	x0, x0, #0xd80
10002ddac: 94000905    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ddb0: 3dc0efe0    	ldr	q0, [sp, #0x3b0]
10002ddb4: 3d8763e0    	str	q0, [sp, #0x1d80]
10002ddb8: f941e3e8    	ldr	x8, [sp, #0x3c0]
10002ddbc: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ddc0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ddc4: 91360000    	add	x0, x0, #0xd80
10002ddc8: 940008fe    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002ddcc: 3dc0e7e0    	ldr	q0, [sp, #0x390]
10002ddd0: 3d8763e0    	str	q0, [sp, #0x1d80]
10002ddd4: f941d3e8    	ldr	x8, [sp, #0x3a0]
10002ddd8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002dddc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002dde0: 91360000    	add	x0, x0, #0xd80
10002dde4: 940008f7    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002dde8: 3dc0dfe0    	ldr	q0, [sp, #0x370]
10002ddec: 3d8763e0    	str	q0, [sp, #0x1d80]
10002ddf0: f941c3e8    	ldr	x8, [sp, #0x380]
10002ddf4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ddf8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002ddfc: 91360000    	add	x0, x0, #0xd80
10002de00: 940008f0    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002de04: f94143e8    	ldr	x8, [sp, #0x280]
10002de08: f90ec3e8    	str	x8, [sp, #0x1d80]
10002de0c: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002de10: f90ec7e8    	str	x8, [sp, #0x1d88]
10002de14: f9414be8    	ldr	x8, [sp, #0x290]
10002de18: f90ecbe8    	str	x8, [sp, #0x1d90]
10002de1c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002de20: 91360000    	add	x0, x0, #0xd80
10002de24: 940008e7    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002de28: 10030341    	adr	x1, 0x100033e90 <_.roc.bytes.38>
10002de2c: d503201f    	nop
10002de30: 9117e3e0    	add	x0, sp, #0x5f8
10002de34: 52800642    	mov	w2, #0x32               ; =50
10002de38: 9400115b    	bl	0x1000323a4 <_dev_wrappers.roc_builtins_str_from_literal>
10002de3c: 9117e3e0    	add	x0, sp, #0x5f8
10002de40: 94000ee0    	bl	0x1000319c0 <_dev_wrappers.roc_builtins_crash_str>
10002de44: f90ec3f5    	str	x21, [sp, #0x1d80]
10002de48: f90ec7fc    	str	x28, [sp, #0x1d88]
10002de4c: f941afe8    	ldr	x8, [sp, #0x358]
10002de50: f90ecbe8    	str	x8, [sp, #0x1d90]
10002de54: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002de58: 91360000    	add	x0, x0, #0xd80
10002de5c: aa0603f4    	mov	x20, x6
10002de60: 940008d8    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002de64: f90ec3f9    	str	x25, [sp, #0x1d80]
10002de68: f90ec7f4    	str	x20, [sp, #0x1d88]
10002de6c: f941abe8    	ldr	x8, [sp, #0x350]
10002de70: f90ecbe8    	str	x8, [sp, #0x1d90]
10002de74: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002de78: 91360000    	add	x0, x0, #0xd80
10002de7c: 940008d1    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002de80: f90ec3f8    	str	x24, [sp, #0x1d80]
10002de84: f90ec7fa    	str	x26, [sp, #0x1d88]
10002de88: f941a7e8    	ldr	x8, [sp, #0x348]
10002de8c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002de90: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002de94: 91360000    	add	x0, x0, #0xd80
10002de98: 940008ca    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002de9c: 52800148    	mov	w8, #0xa                ; =10
10002dea0: f940dfe9    	ldr	x9, [sp, #0x1b8]
10002dea4: f90ec3e9    	str	x9, [sp, #0x1d80]
10002dea8: f90ec7e8    	str	x8, [sp, #0x1d88]
10002deac: 52800508    	mov	w8, #0x28               ; =40
10002deb0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002deb4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002deb8: 91360000    	add	x0, x0, #0xd80
10002debc: 940008c1    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002dec0: f94147e8    	ldr	x8, [sp, #0x288]
10002dec4: f90ec3e8    	str	x8, [sp, #0x1d80]
10002dec8: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002decc: f90ec7e8    	str	x8, [sp, #0x1d88]
10002ded0: f94103e8    	ldr	x8, [sp, #0x200]
10002ded4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002ded8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002dedc: 91360000    	add	x0, x0, #0xd80
10002dee0: 940008b8    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002dee4: 528021c8    	mov	w8, #0x10e              ; =270
10002dee8: f9412be9    	ldr	x9, [sp, #0x250]
10002deec: f90ec3e9    	str	x9, [sp, #0x1d80]
10002def0: f90ec7e8    	str	x8, [sp, #0x1d88]
10002def4: 52804608    	mov	w8, #0x230              ; =560
10002def8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002defc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002df00: 91360000    	add	x0, x0, #0xd80
10002df04: 940008af    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002df08: 52804168    	mov	w8, #0x20b              ; =523
10002df0c: f90ec3f3    	str	x19, [sp, #0x1d80]
10002df10: f90ec7e8    	str	x8, [sp, #0x1d88]
10002df14: 52808548    	mov	w8, #0x42a              ; =1066
10002df18: f90ecbe8    	str	x8, [sp, #0x1d90]
10002df1c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002df20: 91360000    	add	x0, x0, #0xd80
10002df24: 940008a7    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002df28: 3dc0f7e0    	ldr	q0, [sp, #0x3d0]
10002df2c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002df30: f941f3e8    	ldr	x8, [sp, #0x3e0]
10002df34: f90ecbe8    	str	x8, [sp, #0x1d90]
10002df38: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002df3c: 91360000    	add	x0, x0, #0xd80
10002df40: 940008a0    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002df44: 3dc0efe0    	ldr	q0, [sp, #0x3b0]
10002df48: 3d8763e0    	str	q0, [sp, #0x1d80]
10002df4c: f941e3e8    	ldr	x8, [sp, #0x3c0]
10002df50: f90ecbe8    	str	x8, [sp, #0x1d90]
10002df54: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002df58: 91360000    	add	x0, x0, #0xd80
10002df5c: 94000899    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002df60: 3dc0e7e0    	ldr	q0, [sp, #0x390]
10002df64: 3d8763e0    	str	q0, [sp, #0x1d80]
10002df68: f941d3e8    	ldr	x8, [sp, #0x3a0]
10002df6c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002df70: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002df74: 91360000    	add	x0, x0, #0xd80
10002df78: 94000892    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002df7c: 3dc0dfe0    	ldr	q0, [sp, #0x370]
10002df80: 3d8763e0    	str	q0, [sp, #0x1d80]
10002df84: f941c3e8    	ldr	x8, [sp, #0x380]
10002df88: f90ecbe8    	str	x8, [sp, #0x1d90]
10002df8c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002df90: 91360000    	add	x0, x0, #0xd80
10002df94: 9400088b    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002df98: f94143e8    	ldr	x8, [sp, #0x280]
10002df9c: f90ec3e8    	str	x8, [sp, #0x1d80]
10002dfa0: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002dfa4: f90ec7e8    	str	x8, [sp, #0x1d88]
10002dfa8: f9414be8    	ldr	x8, [sp, #0x290]
10002dfac: f90ecbe8    	str	x8, [sp, #0x1d90]
10002dfb0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002dfb4: 91360000    	add	x0, x0, #0xd80
10002dfb8: 94000882    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002dfbc: 1002f6a1    	adr	x1, 0x100033e90 <_.roc.bytes.38>
10002dfc0: d503201f    	nop
10002dfc4: 911a23e0    	add	x0, sp, #0x688
10002dfc8: 52800642    	mov	w2, #0x32               ; =50
10002dfcc: 940010f6    	bl	0x1000323a4 <_dev_wrappers.roc_builtins_str_from_literal>
10002dfd0: 911a23e0    	add	x0, sp, #0x688
10002dfd4: 94000e7b    	bl	0x1000319c0 <_dev_wrappers.roc_builtins_crash_str>
10002dfd8: aa1b03e2    	mov	x2, x27
10002dfdc: 3700393b    	tbnz	w27, #0x0, 0x10002e700 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x10468>
10002dfe0: d341fc48    	lsr	x8, x2, #1
10002dfe4: f9417fe9    	ldr	x9, [sp, #0x2f8]
10002dfe8: eb09011f    	cmp	x8, x9
10002dfec: 540038a0    	b.eq	0x10002e700 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x10468>
10002dff0: b40000a8    	cbz	x8, 0x10002e004 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xfd6c>
10002dff4: f94143e8    	ldr	x8, [sp, #0x280]
10002dff8: f85f8108    	ldur	x8, [x8, #-0x8]
10002dffc: f100051f    	cmp	x8, #0x1
10002e000: 54003801    	b.ne	0x10002e700 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x10468>
10002e004: f94143fa    	ldr	x26, [sp, #0x280]
10002e008: aa1a03e0    	mov	x0, x26
10002e00c: f9417ff9    	ldr	x25, [sp, #0x2f8]
10002e010: aa1903e1    	mov	x1, x25
10002e014: aa0203fb    	mov	x27, x2
10002e018: 94000906    	bl	0x100030430 <_roc_cold_shim.roc_builtins_list_slack_unique>
10002e01c: 17fff2ef    	b	0x10002abd8 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xc940>
10002e020: 52804168    	mov	w8, #0x20b              ; =523
10002e024: f90ec3f5    	str	x21, [sp, #0x1d80]
10002e028: f90ec7e8    	str	x8, [sp, #0x1d88]
10002e02c: 52808548    	mov	w8, #0x42a              ; =1066
10002e030: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e034: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e038: 91360000    	add	x0, x0, #0xd80
10002e03c: aa1103f3    	mov	x19, x17
10002e040: aa0103f5    	mov	x21, x1
10002e044: aa0c03f8    	mov	x24, x12
10002e048: 9400085e    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e04c: 528021c8    	mov	w8, #0x10e              ; =270
10002e050: f9412be9    	ldr	x9, [sp, #0x250]
10002e054: f90ec3e9    	str	x9, [sp, #0x1d80]
10002e058: f90ec7e8    	str	x8, [sp, #0x1d88]
10002e05c: 52804608    	mov	w8, #0x230              ; =560
10002e060: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e064: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e068: 91360000    	add	x0, x0, #0xd80
10002e06c: 94000855    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e070: f94133e8    	ldr	x8, [sp, #0x260]
10002e074: f90ec3e8    	str	x8, [sp, #0x1d80]
10002e078: f90ec7ff    	str	xzr, [sp, #0x1d88]
10002e07c: f90ecbf4    	str	x20, [sp, #0x1d90]
10002e080: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e084: 91360000    	add	x0, x0, #0xd80
10002e088: 9400084e    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e08c: 52800148    	mov	w8, #0xa                ; =10
10002e090: f940f7e9    	ldr	x9, [sp, #0x1e8]
10002e094: f90ec3e9    	str	x9, [sp, #0x1d80]
10002e098: f90ec7e8    	str	x8, [sp, #0x1d88]
10002e09c: 52800508    	mov	w8, #0x28               ; =40
10002e0a0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e0a4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e0a8: 91360000    	add	x0, x0, #0xd80
10002e0ac: 94000845    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e0b0: 3dc1ffe0    	ldr	q0, [sp, #0x7f0]
10002e0b4: 3d8763e0    	str	q0, [sp, #0x1d80]
10002e0b8: f94403e8    	ldr	x8, [sp, #0x800]
10002e0bc: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e0c0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e0c4: 91360000    	add	x0, x0, #0xd80
10002e0c8: 9400083e    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e0cc: 3dc1f7e0    	ldr	q0, [sp, #0x7d0]
10002e0d0: 3d8763e0    	str	q0, [sp, #0x1d80]
10002e0d4: f943f3e8    	ldr	x8, [sp, #0x7e0]
10002e0d8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e0dc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e0e0: 91360000    	add	x0, x0, #0xd80
10002e0e4: 94000837    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e0e8: 3dc1efe0    	ldr	q0, [sp, #0x7b0]
10002e0ec: 3d8763e0    	str	q0, [sp, #0x1d80]
10002e0f0: f943e3e8    	ldr	x8, [sp, #0x7c0]
10002e0f4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e0f8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e0fc: 91360000    	add	x0, x0, #0xd80
10002e100: 94000830    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e104: 3dc1e7e0    	ldr	q0, [sp, #0x790]
10002e108: 3d8763e0    	str	q0, [sp, #0x1d80]
10002e10c: f943d3e8    	ldr	x8, [sp, #0x7a0]
10002e110: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e114: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e118: 91360000    	add	x0, x0, #0xd80
10002e11c: 94000829    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e120: f94143e8    	ldr	x8, [sp, #0x280]
10002e124: f90ec3e8    	str	x8, [sp, #0x1d80]
10002e128: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002e12c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002e130: f90ecbfb    	str	x27, [sp, #0x1d90]
10002e134: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e138: 91360000    	add	x0, x0, #0xd80
10002e13c: 94000821    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e140: f90ec3f6    	str	x22, [sp, #0x1d80]
10002e144: f90ec7f7    	str	x23, [sp, #0x1d88]
10002e148: f9415be8    	ldr	x8, [sp, #0x2b0]
10002e14c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e150: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e154: 91360000    	add	x0, x0, #0xd80
10002e158: 9400081a    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e15c: f9418be8    	ldr	x8, [sp, #0x310]
10002e160: f90ec3e8    	str	x8, [sp, #0x1d80]
10002e164: f90ec7f3    	str	x19, [sp, #0x1d88]
10002e168: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002e16c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e170: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e174: 91360000    	add	x0, x0, #0xd80
10002e178: 94000812    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e17c: f90ec3f8    	str	x24, [sp, #0x1d80]
10002e180: f90ec7f5    	str	x21, [sp, #0x1d88]
10002e184: f94163e8    	ldr	x8, [sp, #0x2c0]
10002e188: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e18c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e190: 91360000    	add	x0, x0, #0xd80
10002e194: 9400080b    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e198: 1002e1c1    	adr	x1, 0x100033dd0 <_.roc.bytes.35>
10002e19c: d503201f    	nop
10002e1a0: 912a63e0    	add	x0, sp, #0xa98
10002e1a4: 52800722    	mov	w2, #0x39               ; =57
10002e1a8: 9400107f    	bl	0x1000323a4 <_dev_wrappers.roc_builtins_str_from_literal>
10002e1ac: 912a63e0    	add	x0, sp, #0xa98
10002e1b0: 94000e04    	bl	0x1000319c0 <_dev_wrappers.roc_builtins_crash_str>
10002e1b4: f90ec3f5    	str	x21, [sp, #0x1d80]
10002e1b8: f90ec7fc    	str	x28, [sp, #0x1d88]
10002e1bc: f941afe8    	ldr	x8, [sp, #0x358]
10002e1c0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e1c4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e1c8: 91360000    	add	x0, x0, #0xd80
10002e1cc: aa0603f4    	mov	x20, x6
10002e1d0: 940007fc    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e1d4: f90ec3f9    	str	x25, [sp, #0x1d80]
10002e1d8: f90ec7f4    	str	x20, [sp, #0x1d88]
10002e1dc: f941abe8    	ldr	x8, [sp, #0x350]
10002e1e0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e1e4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e1e8: 91360000    	add	x0, x0, #0xd80
10002e1ec: 940007f5    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e1f0: f90ec3f8    	str	x24, [sp, #0x1d80]
10002e1f4: f90ec7fa    	str	x26, [sp, #0x1d88]
10002e1f8: f941a7e8    	ldr	x8, [sp, #0x348]
10002e1fc: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e200: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e204: 91360000    	add	x0, x0, #0xd80
10002e208: 940007ee    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e20c: f94147e8    	ldr	x8, [sp, #0x288]
10002e210: f90ec3e8    	str	x8, [sp, #0x1d80]
10002e214: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002e218: f90ec7e8    	str	x8, [sp, #0x1d88]
10002e21c: f94103e8    	ldr	x8, [sp, #0x200]
10002e220: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e224: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e228: 91360000    	add	x0, x0, #0xd80
10002e22c: 940007e5    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e230: 528021c8    	mov	w8, #0x10e              ; =270
10002e234: f9412be9    	ldr	x9, [sp, #0x250]
10002e238: f90ec3e9    	str	x9, [sp, #0x1d80]
10002e23c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002e240: 52804608    	mov	w8, #0x230              ; =560
10002e244: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e248: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e24c: 91360000    	add	x0, x0, #0xd80
10002e250: 940007dc    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e254: 52804168    	mov	w8, #0x20b              ; =523
10002e258: f90ec3f3    	str	x19, [sp, #0x1d80]
10002e25c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002e260: 52808548    	mov	w8, #0x42a              ; =1066
10002e264: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e268: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e26c: 91360000    	add	x0, x0, #0xd80
10002e270: 940007d4    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e274: 52800148    	mov	w8, #0xa                ; =10
10002e278: f940dfe9    	ldr	x9, [sp, #0x1b8]
10002e27c: f90ec3e9    	str	x9, [sp, #0x1d80]
10002e280: f90ec7e8    	str	x8, [sp, #0x1d88]
10002e284: 52800508    	mov	w8, #0x28               ; =40
10002e288: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e28c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e290: 91360000    	add	x0, x0, #0xd80
10002e294: 940007cb    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e298: 3dc0f7e0    	ldr	q0, [sp, #0x3d0]
10002e29c: 3d8763e0    	str	q0, [sp, #0x1d80]
10002e2a0: f941f3e8    	ldr	x8, [sp, #0x3e0]
10002e2a4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e2a8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e2ac: 91360000    	add	x0, x0, #0xd80
10002e2b0: 940007c4    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e2b4: 3dc0efe0    	ldr	q0, [sp, #0x3b0]
10002e2b8: 3d8763e0    	str	q0, [sp, #0x1d80]
10002e2bc: f941e3e8    	ldr	x8, [sp, #0x3c0]
10002e2c0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e2c4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e2c8: 91360000    	add	x0, x0, #0xd80
10002e2cc: 940007bd    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e2d0: 3dc0e7e0    	ldr	q0, [sp, #0x390]
10002e2d4: 3d8763e0    	str	q0, [sp, #0x1d80]
10002e2d8: f941d3e8    	ldr	x8, [sp, #0x3a0]
10002e2dc: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e2e0: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e2e4: 91360000    	add	x0, x0, #0xd80
10002e2e8: 940007b6    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e2ec: 3dc0dfe0    	ldr	q0, [sp, #0x370]
10002e2f0: 3d8763e0    	str	q0, [sp, #0x1d80]
10002e2f4: f941c3e8    	ldr	x8, [sp, #0x380]
10002e2f8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e2fc: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e300: 91360000    	add	x0, x0, #0xd80
10002e304: 940007af    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e308: f94143e8    	ldr	x8, [sp, #0x280]
10002e30c: f90ec3e8    	str	x8, [sp, #0x1d80]
10002e310: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002e314: f90ec7e8    	str	x8, [sp, #0x1d88]
10002e318: f9414be8    	ldr	x8, [sp, #0x290]
10002e31c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e320: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e324: 91360000    	add	x0, x0, #0xd80
10002e328: 940007a6    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e32c: 1002db21    	adr	x1, 0x100033e90 <_.roc.bytes.38>
10002e330: d503201f    	nop
10002e334: 9115a3e0    	add	x0, sp, #0x568
10002e338: 52800642    	mov	w2, #0x32               ; =50
10002e33c: 9400101a    	bl	0x1000323a4 <_dev_wrappers.roc_builtins_str_from_literal>
10002e340: 9115a3e0    	add	x0, sp, #0x568
10002e344: 94000d9f    	bl	0x1000319c0 <_dev_wrappers.roc_builtins_crash_str>
10002e348: aa1b03e2    	mov	x2, x27
10002e34c: 37001edb    	tbnz	w27, #0x0, 0x10002e724 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1048c>
10002e350: d341fc48    	lsr	x8, x2, #1
10002e354: f9417fe9    	ldr	x9, [sp, #0x2f8]
10002e358: eb09011f    	cmp	x8, x9
10002e35c: 54001e40    	b.eq	0x10002e724 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1048c>
10002e360: b40000a8    	cbz	x8, 0x10002e374 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x100dc>
10002e364: f94143e8    	ldr	x8, [sp, #0x280]
10002e368: f85f8108    	ldur	x8, [x8, #-0x8]
10002e36c: f100051f    	cmp	x8, #0x1
10002e370: 54001da1    	b.ne	0x10002e724 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x1048c>
10002e374: f94143fa    	ldr	x26, [sp, #0x280]
10002e378: aa1a03e0    	mov	x0, x26
10002e37c: f9417ff9    	ldr	x25, [sp, #0x2f8]
10002e380: aa1903e1    	mov	x1, x25
10002e384: aa0203fb    	mov	x27, x2
10002e388: 9400082a    	bl	0x100030430 <_roc_cold_shim.roc_builtins_list_slack_unique>
10002e38c: 17fff2a9    	b	0x10002ae30 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xcb98>
10002e390: 52804168    	mov	w8, #0x20b              ; =523
10002e394: f94197e9    	ldr	x9, [sp, #0x328]
10002e398: f90ec3e9    	str	x9, [sp, #0x1d80]
10002e39c: f90ec7e8    	str	x8, [sp, #0x1d88]
10002e3a0: 52808548    	mov	w8, #0x42a              ; =1066
10002e3a4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e3a8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e3ac: 91360000    	add	x0, x0, #0xd80
10002e3b0: aa1103f3    	mov	x19, x17
10002e3b4: aa0103f4    	mov	x20, x1
10002e3b8: 94000782    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e3bc: 528021c8    	mov	w8, #0x10e              ; =270
10002e3c0: f9412be9    	ldr	x9, [sp, #0x250]
10002e3c4: f90ec3e9    	str	x9, [sp, #0x1d80]
10002e3c8: f90ec7e8    	str	x8, [sp, #0x1d88]
10002e3cc: 52804608    	mov	w8, #0x230              ; =560
10002e3d0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e3d4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e3d8: 91360000    	add	x0, x0, #0xd80
10002e3dc: 94000779    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e3e0: f94133e8    	ldr	x8, [sp, #0x260]
10002e3e4: f90ec3e8    	str	x8, [sp, #0x1d80]
10002e3e8: f94173e8    	ldr	x8, [sp, #0x2e0]
10002e3ec: f90ec7e8    	str	x8, [sp, #0x1d88]
10002e3f0: f940e3e8    	ldr	x8, [sp, #0x1c0]
10002e3f4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e3f8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e3fc: 91360000    	add	x0, x0, #0xd80
10002e400: 94000770    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e404: f90ec3f6    	str	x22, [sp, #0x1d80]
10002e408: f90ec7f7    	str	x23, [sp, #0x1d88]
10002e40c: f9415be8    	ldr	x8, [sp, #0x2b0]
10002e410: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e414: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e418: 91360000    	add	x0, x0, #0xd80
10002e41c: 94000769    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e420: f9418be8    	ldr	x8, [sp, #0x310]
10002e424: f90ec3e8    	str	x8, [sp, #0x1d80]
10002e428: f90ec7f3    	str	x19, [sp, #0x1d88]
10002e42c: f9415fe8    	ldr	x8, [sp, #0x2b8]
10002e430: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e434: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e438: 91360000    	add	x0, x0, #0xd80
10002e43c: 94000761    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e440: f90ec3f5    	str	x21, [sp, #0x1d80]
10002e444: f90ec7f4    	str	x20, [sp, #0x1d88]
10002e448: f94163e8    	ldr	x8, [sp, #0x2c0]
10002e44c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e450: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e454: 91360000    	add	x0, x0, #0xd80
10002e458: 9400075a    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e45c: 52800148    	mov	w8, #0xa                ; =10
10002e460: f940f7e9    	ldr	x9, [sp, #0x1e8]
10002e464: f90ec3e9    	str	x9, [sp, #0x1d80]
10002e468: f90ec7e8    	str	x8, [sp, #0x1d88]
10002e46c: 52800508    	mov	w8, #0x28               ; =40
10002e470: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e474: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e478: 91360000    	add	x0, x0, #0xd80
10002e47c: 94000751    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e480: 3dc1ffe0    	ldr	q0, [sp, #0x7f0]
10002e484: 3d8763e0    	str	q0, [sp, #0x1d80]
10002e488: f94403e8    	ldr	x8, [sp, #0x800]
10002e48c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e490: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e494: 91360000    	add	x0, x0, #0xd80
10002e498: 9400074a    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e49c: 3dc1f7e0    	ldr	q0, [sp, #0x7d0]
10002e4a0: 3d8763e0    	str	q0, [sp, #0x1d80]
10002e4a4: f943f3e8    	ldr	x8, [sp, #0x7e0]
10002e4a8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e4ac: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e4b0: 91360000    	add	x0, x0, #0xd80
10002e4b4: 94000743    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e4b8: 3dc1efe0    	ldr	q0, [sp, #0x7b0]
10002e4bc: 3d8763e0    	str	q0, [sp, #0x1d80]
10002e4c0: f943e3e8    	ldr	x8, [sp, #0x7c0]
10002e4c4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e4c8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e4cc: 91360000    	add	x0, x0, #0xd80
10002e4d0: 9400073c    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e4d4: 3dc1e7e0    	ldr	q0, [sp, #0x790]
10002e4d8: 3d8763e0    	str	q0, [sp, #0x1d80]
10002e4dc: f943d3e8    	ldr	x8, [sp, #0x7a0]
10002e4e0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e4e4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e4e8: 91360000    	add	x0, x0, #0xd80
10002e4ec: 94000735    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e4f0: f94143e8    	ldr	x8, [sp, #0x280]
10002e4f4: f90ec3e8    	str	x8, [sp, #0x1d80]
10002e4f8: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002e4fc: f90ec7e8    	str	x8, [sp, #0x1d88]
10002e500: f9414be8    	ldr	x8, [sp, #0x290]
10002e504: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e508: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e50c: 91360000    	add	x0, x0, #0xd80
10002e510: 9400072c    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e514: 1002cde1    	adr	x1, 0x100033ed0 <_.roc.bytes.42>
10002e518: d503201f    	nop
10002e51c: 912623e0    	add	x0, sp, #0x988
10002e520: 52800662    	mov	w2, #0x33               ; =51
10002e524: 94000fa0    	bl	0x1000323a4 <_dev_wrappers.roc_builtins_str_from_literal>
10002e528: 912623e0    	add	x0, sp, #0x988
10002e52c: 94000d25    	bl	0x1000319c0 <_dev_wrappers.roc_builtins_crash_str>
10002e530: 52804168    	mov	w8, #0x20b              ; =523
10002e534: f90ec3f3    	str	x19, [sp, #0x1d80]
10002e538: f90ec7e8    	str	x8, [sp, #0x1d88]
10002e53c: 52808548    	mov	w8, #0x42a              ; =1066
10002e540: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e544: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e548: 91360000    	add	x0, x0, #0xd80
10002e54c: aa0603f3    	mov	x19, x6
10002e550: aa0a03f4    	mov	x20, x10
10002e554: 9400071b    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e558: 528021c8    	mov	w8, #0x10e              ; =270
10002e55c: f90ec3f4    	str	x20, [sp, #0x1d80]
10002e560: f90ec7e8    	str	x8, [sp, #0x1d88]
10002e564: 52804608    	mov	w8, #0x230              ; =560
10002e568: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e56c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e570: 91360000    	add	x0, x0, #0xd80
10002e574: 94000713    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e578: f94147e8    	ldr	x8, [sp, #0x288]
10002e57c: f90ec3e8    	str	x8, [sp, #0x1d80]
10002e580: f90ec7ff    	str	xzr, [sp, #0x1d88]
10002e584: f90ecbf6    	str	x22, [sp, #0x1d90]
10002e588: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e58c: 91360000    	add	x0, x0, #0xd80
10002e590: 9400070c    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e594: 52800148    	mov	w8, #0xa                ; =10
10002e598: f940dfe9    	ldr	x9, [sp, #0x1b8]
10002e59c: f90ec3e9    	str	x9, [sp, #0x1d80]
10002e5a0: f90ec7e8    	str	x8, [sp, #0x1d88]
10002e5a4: 52800508    	mov	w8, #0x28               ; =40
10002e5a8: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e5ac: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e5b0: 91360000    	add	x0, x0, #0xd80
10002e5b4: 94000703    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e5b8: 3dc0f7e0    	ldr	q0, [sp, #0x3d0]
10002e5bc: 3d8763e0    	str	q0, [sp, #0x1d80]
10002e5c0: f941f3e8    	ldr	x8, [sp, #0x3e0]
10002e5c4: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e5c8: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e5cc: 91360000    	add	x0, x0, #0xd80
10002e5d0: 940006fc    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e5d4: 3dc0efe0    	ldr	q0, [sp, #0x3b0]
10002e5d8: 3d8763e0    	str	q0, [sp, #0x1d80]
10002e5dc: f941e3e8    	ldr	x8, [sp, #0x3c0]
10002e5e0: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e5e4: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e5e8: 91360000    	add	x0, x0, #0xd80
10002e5ec: 940006f5    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e5f0: 3dc0e7e0    	ldr	q0, [sp, #0x390]
10002e5f4: 3d8763e0    	str	q0, [sp, #0x1d80]
10002e5f8: f941d3e8    	ldr	x8, [sp, #0x3a0]
10002e5fc: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e600: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e604: 91360000    	add	x0, x0, #0xd80
10002e608: 940006ee    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e60c: 3dc0dfe0    	ldr	q0, [sp, #0x370]
10002e610: 3d8763e0    	str	q0, [sp, #0x1d80]
10002e614: f941c3e8    	ldr	x8, [sp, #0x380]
10002e618: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e61c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e620: 91360000    	add	x0, x0, #0xd80
10002e624: 940006e7    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e628: f94143e8    	ldr	x8, [sp, #0x280]
10002e62c: f90ec3e8    	str	x8, [sp, #0x1d80]
10002e630: f9417fe8    	ldr	x8, [sp, #0x2f8]
10002e634: f90ec7e8    	str	x8, [sp, #0x1d88]
10002e638: f90ecbfb    	str	x27, [sp, #0x1d90]
10002e63c: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e640: 91360000    	add	x0, x0, #0xd80
10002e644: 940006df    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e648: f90ec3f8    	str	x24, [sp, #0x1d80]
10002e64c: f90ec7fa    	str	x26, [sp, #0x1d88]
10002e650: f941a7e8    	ldr	x8, [sp, #0x348]
10002e654: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e658: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e65c: 91360000    	add	x0, x0, #0xd80
10002e660: 940006d8    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e664: f90ec3f9    	str	x25, [sp, #0x1d80]
10002e668: f90ec7f3    	str	x19, [sp, #0x1d88]
10002e66c: f941abe8    	ldr	x8, [sp, #0x350]
10002e670: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e674: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e678: 91360000    	add	x0, x0, #0xd80
10002e67c: 940006d1    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e680: f90ec3f5    	str	x21, [sp, #0x1d80]
10002e684: f90ec7fc    	str	x28, [sp, #0x1d88]
10002e688: f941afe8    	ldr	x8, [sp, #0x358]
10002e68c: f90ecbe8    	str	x8, [sp, #0x1d90]
10002e690: 914007e0    	add	x0, sp, #0x1, lsl #12   ; =0x1000
10002e694: 91360000    	add	x0, x0, #0xd80
10002e698: 940006ca    	bl	0x1000301c0 <_roc_llvm_rc_decref_25_single_thread>
10002e69c: 1002c3a1    	adr	x1, 0x100033f10 <_.roc.bytes.44>
10002e6a0: d503201f    	nop
10002e6a4: 911c63e0    	add	x0, sp, #0x718
10002e6a8: 52800642    	mov	w2, #0x32               ; =50
10002e6ac: 94000f3e    	bl	0x1000323a4 <_dev_wrappers.roc_builtins_str_from_literal>
10002e6b0: 911c63e0    	add	x0, sp, #0x718
10002e6b4: 94000cc3    	bl	0x1000319c0 <_dev_wrappers.roc_builtins_crash_str>
10002e6b8: aa1a03e0    	mov	x0, x26
10002e6bc: aa1903e1    	mov	x1, x25
10002e6c0: 52800023    	mov	w3, #0x1                ; =1
10002e6c4: 52800024    	mov	w4, #0x1                ; =1
10002e6c8: 52800005    	mov	w5, #0x0                ; =0
10002e6cc: 94000703    	bl	0x1000302d8 <_roc_cold_shim.roc_builtins_list_reserve_for_append>
10002e6d0: aa0003fa    	mov	x26, x0
10002e6d4: aa0103f9    	mov	x25, x1
10002e6d8: 17fff985    	b	0x10002ccec <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xea54>
10002e6dc: aa1a03e0    	mov	x0, x26
10002e6e0: f9417fe1    	ldr	x1, [sp, #0x2f8]
10002e6e4: 52800023    	mov	w3, #0x1                ; =1
10002e6e8: 52800024    	mov	w4, #0x1                ; =1
10002e6ec: 52800005    	mov	w5, #0x0                ; =0
10002e6f0: 940006fa    	bl	0x1000302d8 <_roc_cold_shim.roc_builtins_list_reserve_for_append>
10002e6f4: aa0003fa    	mov	x26, x0
10002e6f8: f9017fe1    	str	x1, [sp, #0x2f8]
10002e6fc: 17fffaee    	b	0x10002d2b4 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xf01c>
10002e700: f94143e0    	ldr	x0, [sp, #0x280]
10002e704: f9417fe1    	ldr	x1, [sp, #0x2f8]
10002e708: 52800023    	mov	w3, #0x1                ; =1
10002e70c: 52800024    	mov	w4, #0x1                ; =1
10002e710: 52800005    	mov	w5, #0x0                ; =0
10002e714: 940006f1    	bl	0x1000302d8 <_roc_cold_shim.roc_builtins_list_reserve_for_append>
10002e718: f90143e0    	str	x0, [sp, #0x280]
10002e71c: f9017fe1    	str	x1, [sp, #0x2f8]
10002e720: 17fffe39    	b	0x10002e004 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0xfd6c>
10002e724: f94143e0    	ldr	x0, [sp, #0x280]
10002e728: f9417fe1    	ldr	x1, [sp, #0x2f8]
10002e72c: 52800023    	mov	w3, #0x1                ; =1
10002e730: 52800024    	mov	w4, #0x1                ; =1
10002e734: 52800005    	mov	w5, #0x0                ; =0
10002e738: 940006e8    	bl	0x1000302d8 <_roc_cold_shim.roc_builtins_list_reserve_for_append>
10002e73c: f90143e0    	str	x0, [sp, #0x280]
10002e740: f9017fe1    	str	x1, [sp, #0x2f8]
10002e744: 17ffff0c    	b	0x10002e374 <_roc__p5794f552e2e0fcba87a322629fdca7c0.fast+0x100dc>
