
/private/tmp/mech-work-charge-inline-round34-20261030/workers/after:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001015ab3b4 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire>:
1015ab3b4: d10243ff    	sub	sp, sp, #0x90
1015ab3b8: a90467fa    	stp	x26, x25, [sp, #0x40]
1015ab3bc: a9055ff8    	stp	x24, x23, [sp, #0x50]
1015ab3c0: a90657f6    	stp	x22, x21, [sp, #0x60]
1015ab3c4: a9074ff4    	stp	x20, x19, [sp, #0x70]
1015ab3c8: a9087bfd    	stp	x29, x30, [sp, #0x80]
1015ab3cc: 910203fd    	add	x29, sp, #0x80
1015ab3d0: aa0003f3    	mov	x19, x0
1015ab3d4: 2a0303e8    	mov	w8, w3
1015ab3d8: f9400449    	ldr	x9, [x2, #0x8]
1015ab3dc: eb08013f    	cmp	x9, x8
1015ab3e0: 54000409    	b.ls	0x1015ab460 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0xac>
1015ab3e4: f9400049    	ldr	x9, [x2]
1015ab3e8: 8b081529    	add	x9, x9, x8, lsl #5
1015ab3ec: f9400128    	ldr	x8, [x9]
1015ab3f0: f100051f    	cmp	x8, #0x1
1015ab3f4: 54000361    	b.ne	0x1015ab460 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0xac>
1015ab3f8: f9400c48    	ldr	x8, [x2, #0x18]
1015ab3fc: a940d536    	ldp	x22, x21, [x9, #0x8]
1015ab400: eb1602bf    	cmp	x21, x22
1015ab404: fa4822a2    	ccmp	x21, x8, #0x2, hs
1015ab408: 54000ec8    	b.hi	0x1015ab5e0 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x22c>
1015ab40c: aa0103f4    	mov	x20, x1
1015ab410: f9400858    	ldr	x24, [x2, #0x10]
1015ab414: f9400d37    	ldr	x23, [x9, #0x18]
1015ab418: aa0403e0    	mov	x0, x4
1015ab41c: f8418c08    	ldr	x8, [x0, #0x18]!
1015ab420: b4000348    	cbz	x8, 0x1015ab488 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0xd4>
1015ab424: f9400882    	ldr	x2, [x4, #0x10]
1015ab428: 910063e8    	add	x8, sp, #0x18
1015ab42c: aa1703e1    	mov	x1, x23
1015ab430: 9435bd3b    	bl	0x10231a91c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>
1015ab434: 394063e8    	ldrb	w8, [sp, #0x18]
1015ab438: 7100211f    	cmp	w8, #0x8
1015ab43c: 54000680    	b.eq	0x1015ab50c <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x158>
1015ab440: a941a3ed    	ldp	x13, x8, [sp, #0x18]
1015ab444: f94017e9    	ldr	x9, [sp, #0x28]
1015ab448: 92403daa    	and	x10, x13, #0xffff
1015ab44c: f118195f    	cmp	x10, #0x606
1015ab450: 540003e1    	b.ne	0x1015ab4cc <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x118>
1015ab454: 5280000b    	mov	w11, #0x0               ; =0
1015ab458: 528000cc    	mov	w12, #0x6               ; =6
1015ab45c: 14000023    	b	0x1015ab4e8 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x134>
1015ab460: 3900127f    	strb	wzr, [x19, #0x4]
1015ab464: 528000c8    	mov	w8, #0x6                ; =6
1015ab468: b9000268    	str	w8, [x19]
1015ab46c: a9487bfd    	ldp	x29, x30, [sp, #0x80]
1015ab470: a9474ff4    	ldp	x20, x19, [sp, #0x70]
1015ab474: a94657f6    	ldp	x22, x21, [sp, #0x60]
1015ab478: a9455ff8    	ldp	x24, x23, [sp, #0x50]
1015ab47c: a94467fa    	ldp	x26, x25, [sp, #0x40]
1015ab480: 910243ff    	add	sp, sp, #0x90
1015ab484: d65f03c0    	ret
1015ab488: aa0403f9    	mov	x25, x4
1015ab48c: 9435bb2b    	bl	0x10231a138 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope>
1015ab490: 360000c0    	tbz	w0, #0x0, 0x1015ab4a8 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0xf4>
1015ab494: d2800008    	mov	x8, #0x0                ; =0
1015ab498: 5280000b    	mov	w11, #0x0               ; =0
1015ab49c: 5280000a    	mov	w10, #0x0               ; =0
1015ab4a0: 528000ec    	mov	w12, #0x7               ; =7
1015ab4a4: 14000011    	b	0x1015ab4e8 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x134>
1015ab4a8: a940a728    	ldp	x8, x9, [x25, #0x8]
1015ab4ac: ab170108    	adds	x8, x8, x23
1015ab4b0: 54000a42    	b.hs	0x1015ab5f8 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x244>
1015ab4b4: eb09011f    	cmp	x8, x9
1015ab4b8: 54000289    	b.ls	0x1015ab508 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x154>
1015ab4bc: 5280000b    	mov	w11, #0x0               ; =0
1015ab4c0: 5280000a    	mov	w10, #0x0               ; =0
1015ab4c4: 528000cc    	mov	w12, #0x6               ; =6
1015ab4c8: 14000008    	b	0x1015ab4e8 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x134>
1015ab4cc: d360fd2a    	lsr	x10, x9, #32
1015ab4d0: 3cc303e0    	ldur	q0, [sp, #0x30]
1015ab4d4: 3d8003e0    	str	q0, [sp]
1015ab4d8: 528000ec    	mov	w12, #0x7               ; =7
1015ab4dc: aa0903eb    	mov	x11, x9
1015ab4e0: aa0803e9    	mov	x9, x8
1015ab4e4: aa0d03e8    	mov	x8, x13
1015ab4e8: b900027f    	str	wzr, [x19]
1015ab4ec: 3900226c    	strb	w12, [x19, #0x8]
1015ab4f0: a9012668    	stp	x8, x9, [x19, #0x10]
1015ab4f4: 29042a6b    	stp	w11, w10, [x19, #0x20]
1015ab4f8: 3dc003e0    	ldr	q0, [sp]
1015ab4fc: 3c828260    	stur	q0, [x19, #0x28]
1015ab500: b9003a7f    	str	wzr, [x19, #0x38]
1015ab504: 17ffffda    	b	0x1015ab46c <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0xb8>
1015ab508: f9000728    	str	x8, [x25, #0x8]
1015ab50c: b4000554    	cbz	x20, 0x1015ab5b4 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x200>
1015ab510: eb1502df    	cmp	x22, x21
1015ab514: 540004a0    	b.eq	0x1015ab5a8 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x1f4>
1015ab518: 8b1606c8    	add	x8, x22, x22, lsl #1
1015ab51c: d37df108    	lsl	x8, x8, #3
1015ab520: 8b180109    	add	x9, x8, x24
1015ab524: 91002136    	add	x22, x9, #0x8
1015ab528: 52800309    	mov	w9, #0x18               ; =24
1015ab52c: cb0803e8    	neg	x8, x8
1015ab530: 9b0922b7    	madd	x23, x21, x9, x8
1015ab534: 14000005    	b	0x1015ab548 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x194>
1015ab538: f90002bf    	str	xzr, [x21]
1015ab53c: 910062d6    	add	x22, x22, #0x18
1015ab540: f10062f7    	subs	x23, x23, #0x18
1015ab544: 54000320    	b.eq	0x1015ab5a8 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x1f4>
1015ab548: b85f82c8    	ldur	w8, [x22, #-0x8]
1015ab54c: 36000188    	tbz	w8, #0x0, 0x1015ab57c <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x1c8>
1015ab550: f9407a81    	ldr	x1, [x20, #0xf0]
1015ab554: f94002c0    	ldr	x0, [x22]
1015ab558: eb01001f    	cmp	x0, x1
1015ab55c: 54000582    	b.hs	0x1015ab60c <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x258>
1015ab560: f9407688    	ldr	x8, [x20, #0xe8]
1015ab564: 8b001915    	add	x21, x8, x0, lsl #6
1015ab568: f94002a8    	ldr	x8, [x21]
1015ab56c: b4fffe68    	cbz	x8, 0x1015ab538 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x184>
1015ab570: aa1503e0    	mov	x0, x21
1015ab574: 97ffe304    	bl	0x1015a4184 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015ab578: 17fffff0    	b	0x1015ab538 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x184>
1015ab57c: f9408e82    	ldr	x2, [x20, #0x118]
1015ab580: a8c186c0    	ldp	x0, x1, [x22], #0x18
1015ab584: eb000028    	subs	x8, x1, x0
1015ab588: fa422022    	ccmp	x1, x2, #0x2, hs
1015ab58c: 54000248    	b.hi	0x1015ab5d4 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x220>
1015ab590: f9408a89    	ldr	x9, [x20, #0x110]
1015ab594: 8b000d20    	add	x0, x9, x0, lsl #3
1015ab598: d37df101    	lsl	x1, x8, #3
1015ab59c: 946126e5    	bl	0x102df5130 <dyld_stub_binder+0x102df5130>
1015ab5a0: f10062f7    	subs	x23, x23, #0x18
1015ab5a4: 54fffd21    	b.ne	0x1015ab548 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x194>
1015ab5a8: 52800028    	mov	w8, #0x1                ; =1
1015ab5ac: 39001268    	strb	w8, [x19, #0x4]
1015ab5b0: 17ffffad    	b	0x1015ab464 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0xb0>
1015ab5b4: b900027f    	str	wzr, [x19]
1015ab5b8: 52800188    	mov	w8, #0xc                ; =12
1015ab5bc: f000d469    	adrp	x9, 0x10303a000 <_anon.14153027747eb97b5e1b8a22004538d2.98+0x11b0>
1015ab5c0: 910fa929    	add	x9, x9, #0x3ea
1015ab5c4: a900a668    	stp	x8, x9, [x19, #0x8]
1015ab5c8: 52800368    	mov	w8, #0x1b               ; =27
1015ab5cc: f9000e68    	str	x8, [x19, #0x18]
1015ab5d0: 17ffffa7    	b	0x1015ab46c <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0xb8>
1015ab5d4: b0012123    	adrp	x3, 0x1039d0000 <_anon.14153027747eb97b5e1b8a22004538d2.207+0xc0>
1015ab5d8: 910a4063    	add	x3, x3, #0x290
1015ab5dc: 94612225    	bl	0x102df3e70 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015ab5e0: b0012123    	adrp	x3, 0x1039d0000 <_anon.14153027747eb97b5e1b8a22004538d2.207+0xc0>
1015ab5e4: 9103e063    	add	x3, x3, #0xf8
1015ab5e8: aa1603e0    	mov	x0, x22
1015ab5ec: aa1503e1    	mov	x1, x21
1015ab5f0: aa0803e2    	mov	x2, x8
1015ab5f4: 9461221f    	bl	0x102df3e70 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015ab5f8: 5280000b    	mov	w11, #0x0               ; =0
1015ab5fc: 5280000a    	mov	w10, #0x0               ; =0
1015ab600: 92800008    	mov	x8, #-0x1               ; =-1
1015ab604: 528000cc    	mov	w12, #0x6               ; =6
1015ab608: 17ffffb8    	b	0x1015ab4e8 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x134>
1015ab60c: b0012122    	adrp	x2, 0x1039d0000 <_anon.14153027747eb97b5e1b8a22004538d2.207+0xc0>
1015ab610: 910aa042    	add	x2, x2, #0x2a8
1015ab614: 946121aa    	bl	0x102df3cbc <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015ab618: f90002bf    	str	xzr, [x21]
1015ab61c: 9461269b    	bl	0x102df5088 <dyld_stub_binder+0x102df5088>
