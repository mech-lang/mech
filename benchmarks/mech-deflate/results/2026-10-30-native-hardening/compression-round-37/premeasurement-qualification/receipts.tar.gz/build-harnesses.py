from pathlib import Path
import hashlib,json,shutil,subprocess,time
w=Path('/private/tmp/mech-deflate-linear-stack');r=Path(__file__).resolve().parent;old=Path('/private/tmp/mech-retirement-round36-20261030')
p=r/'primary';p.mkdir(exist_ok=True);t=r/'workers';t.mkdir(exist_ok=True)
libs=json.loads((r/'libraries.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
shutil.copy2(old/'workers/session.rs',t/'session.rs');shutil.copy2(old/'workers/after',t/'before')
b=json.loads((old/'workers/after-build.json').read_text());assert digest(t/'session.rs')==b['source_sha256'];assert digest(t/'before')==b['binary_sha256'];b['copied_from']=str(old/'workers/after');(t/'before-build.json').write_text(json.dumps(b,indent=2)+'\n')
(t/'source-adaptation.json').write_text(json.dumps({'source_sha256':digest(t/'session.rs'),'unchanged_from':str(old/'workers/session.rs'),'timing_boundary':'Original evaluate_into-only line; readiness, clear/rebind, aliases/bytes/inflation/capacity and cleanup unchanged'},indent=2)+'\n')
for name,receipt,src,out in [('worker',old/'workers/after-build.json',t/'session.rs',t/'after'),('current',old/'primary/current-build.json',Path('/private/tmp/mech-timing-round.rs'),p/'current')]:
 d=json.loads(receipt.read_text());cmd=d['command'].copy()
 for i,a in enumerate(cmd):
  if i and cmd[i-1]=='--extern':
   key=a.split('=')[0];cmd[i]=key+'='+libs[key]['path']
 cmd[-3]=str(src);cmd[-1]=str(out);started=time.monotonic()
 q=subprocess.run(cmd,cwd=w,capture_output=True,text=True);stem=t/'after-build' if name=='worker' else p/'current-build'
 stem.with_suffix('.stdout').write_text(q.stdout);stem.with_suffix('.stderr').write_text(q.stderr)
 meta={'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-started,'head':head,'source_sha256':digest(src),'libraries':libs}
 if q.returncode==0:meta['binary_sha256']=digest(out)
 stem.with_suffix('.json').write_text(json.dumps(meta,indent=2)+'\n');q.check_returncode();print('BUILT',name,meta['binary_sha256'],flush=True)
shutil.copy2(old/'primary/frame-after',p/'frame-before');shutil.copy2('/private/tmp/mech-live-control-target/release/native_frame_transport',p/'frame-after')
for label,origin,rev in [('before',str(old/'primary/frame-after'),'9047e634e5964ad23ae19449bc425c2a3cf325b2'),('after','/private/tmp/mech-live-control-target/release/native_frame_transport','3a54f1a1d64db9eee01db97763a3f95a138db93a')]:
 (p/('frame-'+label+'.json')).write_text(json.dumps({'path':origin,'sha256':digest(p/('frame-'+label)),'compiler_source':rev},indent=2)+'\n')
