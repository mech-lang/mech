from pathlib import Path
import json,subprocess,os,time,hashlib,shutil
w=Path('/private/tmp/mech-deflate-linear-stack');r=Path(__file__).resolve().parent;old=Path('/private/tmp/mech-retirement-round36-20261030');b=json.loads((old/'final-release.json').read_text());b['libraries']=json.loads((old/'libraries.json').read_text());cmd=b['command'];env=b['environment'];head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip()
start=time.monotonic()
with (r/'final-release.log').open('w') as out,(r/'final-release.stderr').open('w') as err:p=subprocess.run(cmd,cwd=w,env={**os.environ,**env},stdout=out,stderr=err)
meta={'command':cmd,'environment':env,'head':head,'exit':p.returncode,'seconds':time.monotonic()-start};(r/'final-release.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta,indent=2),flush=True);p.check_returncode();rows=[json.loads(line) for line in (r/'final-release.log').read_text().splitlines() if line.startswith('{')];assert rows[-1]=={'reason':'build-finished','success':True}
libs={};(r/'final-library').mkdir()
for row in rows:
 if row.get('reason')=='compiler-artifact' and row['target']['name'] in b['libraries']:
  name=row['target']['name'];files=[Path(x) for x in row['filenames'] if x.endswith('.rlib')];assert len(files)==1;target=r/'final-library'/files[0].name;shutil.copy2(files[0],target);libs[name]={'path':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'features':row['features'],'profile':row['profile']};before=b['libraries'][name];assert libs[name]['features']==before['features'] and libs[name]['profile']==before['profile'],name
  if name!='mech_gpu':assert libs[name]['sha256']==before['sha256'],name
assert len(libs)==8;(r/'libraries.json').write_text(json.dumps(libs,indent=2)+'\n');print('FROZEN',libs['mech_gpu']['sha256'],flush=True)
