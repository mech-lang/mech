
/private/tmp/mech-action-retirement-round37-20261030/workers/before:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001015c2b74 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper>:
1015c2b74: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
1015c2b78: a90167fa    	stp	x26, x25, [sp, #0x10]
1015c2b7c: a9025ff8    	stp	x24, x23, [sp, #0x20]
1015c2b80: a90357f6    	stp	x22, x21, [sp, #0x30]
1015c2b84: a9044ff4    	stp	x20, x19, [sp, #0x40]
1015c2b88: a9057bfd    	stp	x29, x30, [sp, #0x50]
1015c2b8c: 910143fd    	add	x29, sp, #0x50
1015c2b90: d12443ff    	sub	sp, sp, #0x910
1015c2b94: f90003ff    	str	xzr, [sp]
1015c2b98: 91007449    	add	x9, x2, #0x1d
1015c2b9c: f1007d3f    	cmp	x9, #0x1f
1015c2ba0: 54000528    	b.hi	0x1015c2c44 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd0>
1015c2ba4: 5280003b    	mov	w27, #0x1               ; =1
1015c2ba8: b000d3aa    	adrp	x10, 0x103037000 <_anon.496f237bd13ceadd644cb7ae086b3546.176+0x13b>
1015c2bac: 9130b14a    	add	x10, x10, #0xc2c
1015c2bb0: 100000ab    	adr	x11, 0x1015c2bc4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x50>
1015c2bb4: 3869694c    	ldrb	w12, [x10, x9]
1015c2bb8: 8b0c096b    	add	x11, x11, x12, lsl #2
1015c2bbc: aa0203fc    	mov	x28, x2
1015c2bc0: d61f0160    	br	x11
1015c2bc4: 528003fc    	mov	w28, #0x1f              ; =31
1015c2bc8: 1400003a    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2bcc: 5280021c    	mov	w28, #0x10              ; =16
1015c2bd0: 14000038    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2bd4: 528001bc    	mov	w28, #0xd               ; =13
1015c2bd8: 14000036    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2bdc: 528002bc    	mov	w28, #0x15              ; =21
1015c2be0: 14000034    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2be4: 5280013c    	mov	w28, #0x9               ; =9
1015c2be8: 14000032    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2bec: 5280017c    	mov	w28, #0xb               ; =11
1015c2bf0: 14000030    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2bf4: 5280031c    	mov	w28, #0x18              ; =24
1015c2bf8: 1400002e    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2bfc: 528000dc    	mov	w28, #0x6               ; =6
1015c2c00: 1400002c    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2c04: 5280019c    	mov	w28, #0xc               ; =12
1015c2c08: 1400002a    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2c0c: 528002dc    	mov	w28, #0x16              ; =22
1015c2c10: 14000028    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2c14: 528001fc    	mov	w28, #0xf               ; =15
1015c2c18: 14000026    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2c1c: 528000bc    	mov	w28, #0x5               ; =5
1015c2c20: 14000024    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2c24: 528003bc    	mov	w28, #0x1d              ; =29
1015c2c28: 14000022    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2c2c: 528002fc    	mov	w28, #0x17              ; =23
1015c2c30: 14000020    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2c34: 5280015c    	mov	w28, #0xa               ; =10
1015c2c38: 1400001e    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2c3c: 5280039c    	mov	w28, #0x1c              ; =28
1015c2c40: 1400001c    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2c44: 5280001b    	mov	w27, #0x0               ; =0
1015c2c48: d1000c56    	sub	x22, x2, #0x3
1015c2c4c: 5280007c    	mov	w28, #0x3               ; =3
1015c2c50: 14000018    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2c54: 5280037c    	mov	w28, #0x1b              ; =27
1015c2c58: 14000016    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2c5c: 5280029c    	mov	w28, #0x14              ; =20
1015c2c60: 14000014    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2c64: 5280027c    	mov	w28, #0x13              ; =19
1015c2c68: 14000012    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2c6c: 5280009c    	mov	w28, #0x4               ; =4
1015c2c70: 14000010    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2c74: 528003dc    	mov	w28, #0x1e              ; =30
1015c2c78: 1400000e    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2c7c: 5280033c    	mov	w28, #0x19              ; =25
1015c2c80: 1400000c    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2c84: 5280035c    	mov	w28, #0x1a              ; =26
1015c2c88: 1400000a    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2c8c: 5280023c    	mov	w28, #0x11              ; =17
1015c2c90: 14000008    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2c94: 5280025c    	mov	w28, #0x12              ; =18
1015c2c98: 14000006    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2c9c: 528001dc    	mov	w28, #0xe               ; =14
1015c2ca0: 14000004    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2ca4: 528000fc    	mov	w28, #0x7               ; =7
1015c2ca8: 14000002    	b	0x1015c2cb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c>
1015c2cac: 5280011c    	mov	w28, #0x8               ; =8
1015c2cb0: f9411c09    	ldr	x9, [x0, #0x238]
1015c2cb4: f1000d3f    	cmp	x9, #0x3
1015c2cb8: 54000160    	b.eq	0x1015c2ce4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x170>
1015c2cbc: b9426809    	ldr	w9, [x0, #0x268]
1015c2cc0: 34000129    	cbz	w9, 0x1015c2ce4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x170>
1015c2cc4: b900011f    	str	wzr, [x8]
1015c2cc8: 52800189    	mov	w9, #0xc                ; =12
1015c2ccc: 39002109    	strb	w9, [x8, #0x8]
1015c2cd0: b000d3c9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c2cd4: 9122f929    	add	x9, x9, #0x8be
1015c2cd8: 528004aa    	mov	w10, #0x25              ; =37
1015c2cdc: a9012909    	stp	x9, x10, [x8, #0x10]
1015c2ce0: 14000090    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c2ce4: f1002f9f    	cmp	x28, #0xb
1015c2ce8: 54000680    	b.eq	0x1015c2db8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x244>
1015c2cec: 911a83fa    	add	x26, sp, #0x6a0
1015c2cf0: 911043f8    	add	x24, sp, #0x410
1015c2cf4: f100779f    	cmp	x28, #0x1d
1015c2cf8: 540002a0    	b.eq	0x1015c2d4c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1d8>
1015c2cfc: f1007f9f    	cmp	x28, #0x1f
1015c2d00: 54000741    	b.ne	0x1015c2de8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x274>
1015c2d04: a9407074    	ldp	x20, x28, [x3]
1015c2d08: f940086a    	ldr	x10, [x3, #0x10]
1015c2d0c: a94c2c0c    	ldp	x12, x11, [x0, #0xc0]
1015c2d10: a94d4c1b    	ldp	x27, x19, [x0, #0xd0]
1015c2d14: a94e6416    	ldp	x22, x25, [x0, #0xe0]
1015c2d18: b940f009    	ldr	w9, [x0, #0xf0]
1015c2d1c: 5280004d    	mov	w13, #0x2               ; =2
1015c2d20: f900600d    	str	x13, [x0, #0xc0]
1015c2d24: b4000a2c    	cbz	x12, 0x1015c2e68 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f4>
1015c2d28: f100099f    	cmp	x12, #0x2
1015c2d2c: 54000ac1    	b.ne	0x1015c2e84 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x310>
1015c2d30: b900011f    	str	wzr, [x8]
1015c2d34: 52800189    	mov	w9, #0xc                ; =12
1015c2d38: b000d3aa    	adrp	x10, 0x103037000 <_anon.496f237bd13ceadd644cb7ae086b3546.176+0x13b>
1015c2d3c: 913c494a    	add	x10, x10, #0xf12
1015c2d40: a900a909    	stp	x9, x10, [x8, #0x8]
1015c2d44: 52800409    	mov	w9, #0x20               ; =32
1015c2d48: 14000075    	b	0x1015c2f1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a8>
1015c2d4c: f9424c17    	ldr	x23, [x0, #0x498]
1015c2d50: f9413ae9    	ldr	x9, [x23, #0x270]
1015c2d54: eb09003f    	cmp	x1, x9
1015c2d58: 540006c2    	b.hs	0x1015c2e30 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2bc>
1015c2d5c: f94136e9    	ldr	x9, [x23, #0x268]
1015c2d60: 8b011129    	add	x9, x9, x1, lsl #4
1015c2d64: b940012a    	ldr	w10, [x9]
1015c2d68: 3600064a    	tbz	w10, #0x0, 0x1015c2e30 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2bc>
1015c2d6c: f9400533    	ldr	x19, [x9, #0x8]
1015c2d70: f9412ee9    	ldr	x9, [x23, #0x258]
1015c2d74: eb09027f    	cmp	x19, x9
1015c2d78: 54012c82    	b.hs	0x1015c5308 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2794>
1015c2d7c: f9412ae9    	ldr	x9, [x23, #0x250]
1015c2d80: 52802a0a    	mov	w10, #0x150             ; =336
1015c2d84: 9b0a267c    	madd	x28, x19, x10, x9
1015c2d88: aa1c03f5    	mov	x21, x28
1015c2d8c: f8420ea9    	ldr	x9, [x21, #0x20]!
1015c2d90: d2f0000a    	mov	x10, #-0x8000000000000000 ; =-9223372036854775808
1015c2d94: eb0a013f    	cmp	x9, x10
1015c2d98: 54000f61    	b.ne	0x1015c2f84 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x410>
1015c2d9c: b900011f    	str	wzr, [x8]
1015c2da0: 52800189    	mov	w9, #0xc                ; =12
1015c2da4: b000d3aa    	adrp	x10, 0x103037000 <_anon.496f237bd13ceadd644cb7ae086b3546.176+0x13b>
1015c2da8: 913bbd4a    	add	x10, x10, #0xeef
1015c2dac: a900a909    	stp	x9, x10, [x8, #0x8]
1015c2db0: 52800469    	mov	w9, #0x23               ; =35
1015c2db4: 1400005a    	b	0x1015c2f1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a8>
1015c2db8: aa0003e9    	mov	x9, x0
1015c2dbc: aa0803e0    	mov	x0, x8
1015c2dc0: aa0103e2    	mov	x2, x1
1015c2dc4: aa0903e1    	mov	x1, x9
1015c2dc8: 912443ff    	add	sp, sp, #0x910
1015c2dcc: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1015c2dd0: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1015c2dd4: a94357f6    	ldp	x22, x21, [sp, #0x30]
1015c2dd8: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1015c2ddc: a94167fa    	ldp	x26, x25, [sp, #0x10]
1015c2de0: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1015c2de4: 17ffca70    	b	0x1015b57a4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation15end_closed_tail>
1015c2de8: f9406009    	ldr	x9, [x0, #0xc0]
1015c2dec: f100093f    	cmp	x9, #0x2
1015c2df0: 540002e1    	b.ne	0x1015c2e4c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d8>
1015c2df4: 910cc3f9    	add	x25, sp, #0x330
1015c2df8: f100579f    	cmp	x28, #0x15
1015c2dfc: 54000a2c    	b.gt	0x1015c2f40 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3cc>
1015c2e00: d1003389    	sub	x9, x28, #0xc
1015c2e04: f100113f    	cmp	x9, #0x4
1015c2e08: 54001fa2    	b.hs	0x1015c31fc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x688>
1015c2e0c: d360fc29    	lsr	x9, x1, #32
1015c2e10: b4000da9    	cbz	x9, 0x1015c2fc4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x450>
1015c2e14: b900011f    	str	wzr, [x8]
1015c2e18: 52800189    	mov	w9, #0xc                ; =12
1015c2e1c: 39002109    	strb	w9, [x8, #0x8]
1015c2e20: f000d3a9    	adrp	x9, 0x103039000 <_anon.19b44b453da724831023c27de6e0b6f2.100+0xf48>
1015c2e24: 910da529    	add	x9, x9, #0x369
1015c2e28: 528002aa    	mov	w10, #0x15              ; =21
1015c2e2c: 17ffffac    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c2e30: b900011f    	str	wzr, [x8]
1015c2e34: 52800189    	mov	w9, #0xc                ; =12
1015c2e38: b000d3aa    	adrp	x10, 0x103037000 <_anon.496f237bd13ceadd644cb7ae086b3546.176+0x13b>
1015c2e3c: 9137ed4a    	add	x10, x10, #0xdfb
1015c2e40: a900a909    	stp	x9, x10, [x8, #0x8]
1015c2e44: 528005a9    	mov	w9, #0x2d               ; =45
1015c2e48: 14000035    	b	0x1015c2f1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a8>
1015c2e4c: b900011f    	str	wzr, [x8]
1015c2e50: 52800189    	mov	w9, #0xc                ; =12
1015c2e54: 39002109    	strb	w9, [x8, #0x8]
1015c2e58: b000d3c9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c2e5c: 9116fd29    	add	x9, x9, #0x5bf
1015c2e60: 528006aa    	mov	w10, #0x35              ; =53
1015c2e64: 17ffff9e    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c2e68: b900011f    	str	wzr, [x8]
1015c2e6c: 52800189    	mov	w9, #0xc                ; =12
1015c2e70: 39002109    	strb	w9, [x8, #0x8]
1015c2e74: 9000d3c9    	adrp	x9, 0x10303a000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x3b8>
1015c2e78: 91081529    	add	x9, x9, #0x205
1015c2e7c: 528004ea    	mov	w10, #0x27              ; =39
1015c2e80: 17ffff97    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c2e84: f9424c15    	ldr	x21, [x0, #0x498]
1015c2e88: f940beac    	ldr	x12, [x21, #0x178]
1015c2e8c: eb0c017f    	cmp	x11, x12
1015c2e90: 540003a2    	b.hs	0x1015c2f04 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x390>
1015c2e94: f940baac    	ldr	x12, [x21, #0x170]
1015c2e98: 8b0b118c    	add	x12, x12, x11, lsl #4
1015c2e9c: f940018b    	ldr	x11, [x12]
1015c2ea0: f940b2ad    	ldr	x13, [x21, #0x160]
1015c2ea4: eb0d017f    	cmp	x11, x13
1015c2ea8: 540002e2    	b.hs	0x1015c2f04 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x390>
1015c2eac: f940058c    	ldr	x12, [x12, #0x8]
1015c2eb0: f940aead    	ldr	x13, [x21, #0x158]
1015c2eb4: 5280090e    	mov	w14, #0x48              ; =72
1015c2eb8: 9b0e356b    	madd	x11, x11, x14, x13
1015c2ebc: f940156d    	ldr	x13, [x11, #0x28]
1015c2ec0: eb0d019f    	cmp	x12, x13
1015c2ec4: 54000202    	b.hs	0x1015c2f04 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x390>
1015c2ec8: f940116d    	ldr	x13, [x11, #0x20]
1015c2ecc: 5280220e    	mov	w14, #0x110             ; =272
1015c2ed0: 9b0e3597    	madd	x23, x12, x14, x13
1015c2ed4: aa1703f8    	mov	x24, x23
1015c2ed8: f8430f0d    	ldr	x13, [x24, #0x30]!
1015c2edc: d2f0000c    	mov	x12, #-0x8000000000000000 ; =-9223372036854775808
1015c2ee0: eb0c01bf    	cmp	x13, x12
1015c2ee4: 54002c81    	b.ne	0x1015c3474 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x900>
1015c2ee8: b900011f    	str	wzr, [x8]
1015c2eec: 52800189    	mov	w9, #0xc                ; =12
1015c2ef0: b000d3aa    	adrp	x10, 0x103037000 <_anon.496f237bd13ceadd644cb7ae086b3546.176+0x13b>
1015c2ef4: 913cc94a    	add	x10, x10, #0xf32
1015c2ef8: a900a909    	stp	x9, x10, [x8, #0x8]
1015c2efc: 528003e9    	mov	w9, #0x1f               ; =31
1015c2f00: 14000007    	b	0x1015c2f1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a8>
1015c2f04: b900011f    	str	wzr, [x8]
1015c2f08: 52800189    	mov	w9, #0xc                ; =12
1015c2f0c: d000d3aa    	adrp	x10, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c2f10: 91023d4a    	add	x10, x10, #0x8f
1015c2f14: a900a909    	stp	x9, x10, [x8, #0x8]
1015c2f18: 52800529    	mov	w9, #0x29               ; =41
1015c2f1c: f9000d09    	str	x9, [x8, #0x18]
1015c2f20: 912443ff    	add	sp, sp, #0x910
1015c2f24: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1015c2f28: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1015c2f2c: a94357f6    	ldp	x22, x21, [sp, #0x30]
1015c2f30: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1015c2f34: a94167fa    	ldp	x26, x25, [sp, #0x10]
1015c2f38: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1015c2f3c: d65f03c0    	ret
1015c2f40: d1005f89    	sub	x9, x28, #0x17
1015c2f44: f100113f    	cmp	x9, #0x4
1015c2f48: 54001762    	b.hs	0x1015c3234 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6c0>
1015c2f4c: b1005c5f    	cmn	x2, #0x17
1015c2f50: 5400076c    	b.gt	0x1015c303c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4c8>
1015c2f54: b100605f    	cmn	x2, #0x18
1015c2f58: 54001fc0    	b.eq	0x1015c3350 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7dc>
1015c2f5c: b1005c5f    	cmn	x2, #0x17
1015c2f60: 54001ea1    	b.ne	0x1015c3334 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7c0>
1015c2f64: f9407c09    	ldr	x9, [x0, #0xf8]
1015c2f68: f100093f    	cmp	x9, #0x2
1015c2f6c: 54002ac1    	b.ne	0x1015c34c4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x950>
1015c2f70: b900011f    	str	wzr, [x8]
1015c2f74: 52800189    	mov	w9, #0xc                ; =12
1015c2f78: b000d3ca    	adrp	x10, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c2f7c: 9130314a    	add	x10, x10, #0xc0c
1015c2f80: 14000145    	b	0x1015c3494 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x920>
1015c2f84: a945ab89    	ldp	x9, x10, [x28, #0x58]
1015c2f88: d100613b    	sub	x27, x9, #0x18
1015c2f8c: d37be949    	lsl	x9, x10, #5
1015c2f90: b40012a9    	cbz	x9, 0x1015c31e4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x670>
1015c2f94: f9400f6a    	ldr	x10, [x27, #0x18]
1015c2f98: 9100837b    	add	x27, x27, #0x20
1015c2f9c: d1008129    	sub	x9, x9, #0x20
1015c2fa0: eb01015f    	cmp	x10, x1
1015c2fa4: 54ffff61    	b.ne	0x1015c2f90 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41c>
1015c2fa8: b9400369    	ldr	w9, [x27]
1015c2fac: 7100153f    	cmp	w9, #0x5
1015c2fb0: 54002780    	b.eq	0x1015c34a0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x92c>
1015c2fb4: 7100193f    	cmp	w9, #0x6
1015c2fb8: 54001161    	b.ne	0x1015c31e4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x670>
1015c2fbc: 52800118    	mov	w24, #0x8               ; =8
1015c2fc0: 14000139    	b	0x1015c34a4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x930>
1015c2fc4: f9425c09    	ldr	x9, [x0, #0x4b8]
1015c2fc8: d37bfd2a    	lsr	x10, x9, #59
1015c2fcc: b50093ea    	cbnz	x10, 0x1015c4248 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x16d4>
1015c2fd0: 9280040a    	mov	x10, #-0x21             ; =-33
1015c2fd4: f2e0ffea    	movk	x10, #0x7ff, lsl #48
1015c2fd8: eb0a013f    	cmp	x9, x10
1015c2fdc: 54009368    	b.hi	0x1015c4248 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x16d4>
1015c2fe0: aa0203f9    	mov	x25, x2
1015c2fe4: aa0303f5    	mov	x21, x3
1015c2fe8: aa0103f4    	mov	x20, x1
1015c2fec: aa0803f7    	mov	x23, x8
1015c2ff0: aa0003f3    	mov	x19, x0
1015c2ff4: f942481b    	ldr	x27, [x0, #0x490]
1015c2ff8: d37be928    	lsl	x8, x9, #5
1015c2ffc: 927ae508    	and	x8, x8, #0xffffffffffffffc0
1015c3000: 91100116    	add	x22, x8, #0x400
1015c3004: f9418b68    	ldr	x8, [x27, #0x310]
1015c3008: b4001fe8    	cbz	x8, 0x1015c3404 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x890>
1015c300c: f9418762    	ldr	x2, [x27, #0x308]
1015c3010: 911a83e8    	add	x8, sp, #0x6a0
1015c3014: 910c4360    	add	x0, x27, #0x310
1015c3018: aa1603e1    	mov	x1, x22
1015c301c: 94355c65    	bl	0x10231a1b0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>
1015c3020: 395a83e8    	ldrb	w8, [sp, #0x6a0]
1015c3024: 7100211f    	cmp	w8, #0x8
1015c3028: 54001fe1    	b.ne	0x1015c3424 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8b0>
1015c302c: aa1303e0    	mov	x0, x19
1015c3030: aa1403e1    	mov	x1, x20
1015c3034: aa1903ea    	mov	x10, x25
1015c3038: 14000260    	b	0x1015c39b8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe44>
1015c303c: b100585f    	cmn	x2, #0x16
1015c3040: 540019c0    	b.eq	0x1015c3378 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x804>
1015c3044: b100545f    	cmn	x2, #0x15
1015c3048: 54001761    	b.ne	0x1015c3334 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7c0>
1015c304c: f9424c09    	ldr	x9, [x0, #0x498]
1015c3050: f903f3e9    	str	x9, [sp, #0x7e0]
1015c3054: f940087b    	ldr	x27, [x3, #0x10]
1015c3058: f942c52a    	ldr	x10, [x9, #0x588]
1015c305c: eb0a037f    	cmp	x27, x10
1015c3060: 540027e2    	b.hs	0x1015c355c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9e8>
1015c3064: f942c129    	ldr	x9, [x9, #0x580]
1015c3068: 52800b0a    	mov	w10, #0x58              ; =88
1015c306c: 9b0a2774    	madd	x20, x27, x10, x9
1015c3070: b9403e89    	ldr	w9, [x20, #0x3c]
1015c3074: eb09003f    	cmp	x1, x9
1015c3078: 54002da1    	b.ne	0x1015c362c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xab8>
1015c307c: f942481c    	ldr	x28, [x0, #0x490]
1015c3080: b942f389    	ldr	w9, [x28, #0x2f0]
1015c3084: 7100053f    	cmp	w9, #0x1
1015c3088: 54002d21    	b.ne	0x1015c362c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xab8>
1015c308c: b942f789    	ldr	w9, [x28, #0x2f4]
1015c3090: 6b01013f    	cmp	w9, w1
1015c3094: 54002cc1    	b.ne	0x1015c362c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xab8>
1015c3098: b942eb89    	ldr	w9, [x28, #0x2e8]
1015c309c: 7100053f    	cmp	w9, #0x1
1015c30a0: 54002c61    	b.ne	0x1015c362c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xab8>
1015c30a4: b9403689    	ldr	w9, [x20, #0x34]
1015c30a8: b942ef8a    	ldr	w10, [x28, #0x2ec]
1015c30ac: 6b09015f    	cmp	w10, w9
1015c30b0: 54002be1    	b.ne	0x1015c362c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xab8>
1015c30b4: 3951838a    	ldrb	w10, [x28, #0x460]
1015c30b8: 7100055f    	cmp	w10, #0x1
1015c30bc: 54002b81    	b.ne	0x1015c362c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xab8>
1015c30c0: aa0803f8    	mov	x24, x8
1015c30c4: f9407c08    	ldr	x8, [x0, #0xf8]
1015c30c8: f100091f    	cmp	x8, #0x2
1015c30cc: 54007aa1    	b.ne	0x1015c4020 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14ac>
1015c30d0: aa0003f3    	mov	x19, x0
1015c30d4: 39542008    	ldrb	w8, [x0, #0x508]
1015c30d8: 37007a48    	tbnz	w8, #0x0, 0x1015c4020 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14ac>
1015c30dc: d37ff920    	lsl	x0, x9, #1
1015c30e0: f9425e61    	ldr	x1, [x19, #0x4b8]
1015c30e4: eb01001f    	cmp	x0, x1
1015c30e8: 5401db82    	b.hs	0x1015c6c58 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x40e4>
1015c30ec: f9425a69    	ldr	x9, [x19, #0x4b0]
1015c30f0: f8607937    	ldr	x23, [x9, x0, lsl #3]
1015c30f4: f941e268    	ldr	x8, [x19, #0x3c0]
1015c30f8: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
1015c30fc: eb09011f    	cmp	x8, x9
1015c3100: 54008ee1    	b.ne	0x1015c42dc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1768>
1015c3104: aa0303f6    	mov	x22, x3
1015c3108: 945f6f87    	bl	0x102d9ef24 <__RNvNtNtCsgirOGyZpP7g_3std6thread9functions21available_parallelism>
1015c310c: f100041f    	cmp	x0, #0x1
1015c3110: 54000081    	b.ne	0x1015c3120 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5ac>
1015c3114: aa0103e0    	mov	x0, x1
1015c3118: 97ff882e    	bl	0x1015a51d0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultINtNtNtB4_3num7nonzero7NonZerojENtNtNtCsgirOGyZpP7g_3std2io5error5ErrorEECs29QkOtpKx6e_8mech_gpu>
1015c311c: 52800021    	mov	w1, #0x1                ; =1
1015c3120: 52800408    	mov	w8, #0x20               ; =32
1015c3124: f100803f    	cmp	x1, #0x20
1015c3128: 9a883035    	csel	x21, x1, x8, lo
1015c312c: d10006e8    	sub	x8, x23, #0x1
1015c3130: eb15011f    	cmp	x8, x21
1015c3134: 54007762    	b.hs	0x1015c4020 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14ac>
1015c3138: f9401688    	ldr	x8, [x20, #0x28]
1015c313c: f90027e8    	str	x8, [sp, #0x48]
1015c3140: eb15011f    	cmp	x8, x21
1015c3144: 540076e8    	b.hi	0x1015c4020 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14ac>
1015c3148: f9401288    	ldr	x8, [x20, #0x20]
1015c314c: f90023e8    	str	x8, [sp, #0x40]
1015c3150: 911a83e8    	add	x8, sp, #0x6a0
1015c3154: 910ee380    	add	x0, x28, #0x3b8
1015c3158: 94355a40    	bl	0x102319a58 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
1015c315c: f94353e8    	ldr	x8, [sp, #0x6a0]
1015c3160: f100051f    	cmp	x8, #0x1
1015c3164: 540075e1    	b.ne	0x1015c4020 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14ac>
1015c3168: f94357e8    	ldr	x8, [sp, #0x6a8]
1015c316c: b40075a8    	cbz	x8, 0x1015c4020 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14ac>
1015c3170: f94002c8    	ldr	x8, [x22]
1015c3174: f9001fe8    	str	x8, [sp, #0x38]
1015c3178: b400bc48    	cbz	x8, 0x1015c4900 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1d8c>
1015c317c: f94006c8    	ldr	x8, [x22, #0x8]
1015c3180: b400bc08    	cbz	x8, 0x1015c4900 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1d8c>
1015c3184: aa0803f6    	mov	x22, x8
1015c3188: f9401d08    	ldr	x8, [x8, #0x38]
1015c318c: eb13011f    	cmp	x8, x19
1015c3190: 540001c1    	b.ne	0x1015c31c8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x654>
1015c3194: f94002c8    	ldr	x8, [x22]
1015c3198: f100951f    	cmp	x8, #0x25
1015c319c: 54000161    	b.ne	0x1015c31c8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x654>
1015c31a0: f9400ac8    	ldr	x8, [x22, #0x10]
1015c31a4: f943f3e9    	ldr	x9, [sp, #0x7e0]
1015c31a8: f941ad29    	ldr	x9, [x9, #0x358]
1015c31ac: eb09011f    	cmp	x8, x9
1015c31b0: 540000c3    	b.lo	0x1015c31c8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x654>
1015c31b4: f94016c8    	ldr	x8, [x22, #0x28]
1015c31b8: b4000088    	cbz	x8, 0x1015c31c8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x654>
1015c31bc: f9403ac8    	ldr	x8, [x22, #0x70]
1015c31c0: f100111f    	cmp	x8, #0x4
1015c31c4: 54012201    	b.ne	0x1015c5604 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2a90>
1015c31c8: b900031f    	str	wzr, [x24]
1015c31cc: 52800188    	mov	w8, #0xc                ; =12
1015c31d0: 39002308    	strb	w8, [x24, #0x8]
1015c31d4: 9000d3c8    	adrp	x8, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c31d8: 912a7908    	add	x8, x8, #0xa9e
1015c31dc: 52800509    	mov	w9, #0x28               ; =40
1015c31e0: 1400048b    	b	0x1015c440c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1898>
1015c31e4: b900011f    	str	wzr, [x8]
1015c31e8: 52800189    	mov	w9, #0xc                ; =12
1015c31ec: 39002109    	strb	w9, [x8, #0x8]
1015c31f0: f000d3a9    	adrp	x9, 0x10303a000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x3b8>
1015c31f4: 9102c129    	add	x9, x9, #0xb0
1015c31f8: 14000104    	b	0x1015c3608 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa94>
1015c31fc: aa0203f3    	mov	x19, x2
1015c3200: aa0303f5    	mov	x21, x3
1015c3204: f100539f    	cmp	x28, #0x14
1015c3208: 54000501    	b.ne	0x1015c32a8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x734>
1015c320c: f9424809    	ldr	x9, [x0, #0x490]
1015c3210: f9424c0a    	ldr	x10, [x0, #0x498]
1015c3214: aa0003f7    	mov	x23, x0
1015c3218: aa0903e0    	mov	x0, x9
1015c321c: aa0103f4    	mov	x20, x1
1015c3220: aa0a03e1    	mov	x1, x10
1015c3224: aa1403e2    	mov	x2, x20
1015c3228: aa0803f8    	mov	x24, x8
1015c322c: 94004ae8    	bl	0x1015d5dcc <__RNvMs_NtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation20retained_native_call>
1015c3230: 1400000e    	b	0x1015c3268 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6f4>
1015c3234: aa0203f3    	mov	x19, x2
1015c3238: aa0303f5    	mov	x21, x3
1015c323c: f1005b9f    	cmp	x28, #0x16
1015c3240: 54000341    	b.ne	0x1015c32a8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x734>
1015c3244: f9424809    	ldr	x9, [x0, #0x490]
1015c3248: f9424c0a    	ldr	x10, [x0, #0x498]
1015c324c: aa0003f7    	mov	x23, x0
1015c3250: aa0903e0    	mov	x0, x9
1015c3254: aa0103f4    	mov	x20, x1
1015c3258: aa0a03e1    	mov	x1, x10
1015c325c: aa1403e2    	mov	x2, x20
1015c3260: aa0803f8    	mov	x24, x8
1015c3264: 97ffec60    	bl	0x1015be3e4 <__RNvMNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtB8_10invocation10Invocation20retained_native_span>
1015c3268: aa1403e1    	mov	x1, x20
1015c326c: aa1803e8    	mov	x8, x24
1015c3270: aa0003e9    	mov	x9, x0
1015c3274: aa1703e0    	mov	x0, x23
1015c3278: 36000189    	tbz	w9, #0x0, 0x1015c32a8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x734>
1015c327c: aa0803f4    	mov	x20, x8
1015c3280: 911a83e8    	add	x8, sp, #0x6a0
1015c3284: aa0003f7    	mov	x23, x0
1015c3288: aa0103f8    	mov	x24, x1
1015c328c: 97fffaac    	bl	0x1015c1d3c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit>
1015c3290: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c3294: 7100191f    	cmp	w8, #0x6
1015c3298: 54000dc1    	b.ne	0x1015c3450 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8dc>
1015c329c: aa1403e8    	mov	x8, x20
1015c32a0: aa1703e0    	mov	x0, x23
1015c32a4: aa1803e1    	mov	x1, x24
1015c32a8: f9424809    	ldr	x9, [x0, #0x490]
1015c32ac: b942f12a    	ldr	w10, [x9, #0x2f0]
1015c32b0: 3600034a    	tbz	w10, #0x0, 0x1015c3318 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7a4>
1015c32b4: b942f52a    	ldr	w10, [x9, #0x2f4]
1015c32b8: eb0a003f    	cmp	x1, x10
1015c32bc: 540002e1    	b.ne	0x1015c3318 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7a4>
1015c32c0: aa1503e3    	mov	x3, x21
1015c32c4: f9424c14    	ldr	x20, [x0, #0x498]
1015c32c8: aa0103f5    	mov	x21, x1
1015c32cc: aa0003f7    	mov	x23, x0
1015c32d0: f1006b9f    	cmp	x28, #0x1a
1015c32d4: 54002a2c    	b.gt	0x1015c3818 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xca4>
1015c32d8: d1004f8a    	sub	x10, x28, #0x13
1015c32dc: f100115f    	cmp	x10, #0x4
1015c32e0: 540040e2    	b.hs	0x1015c3afc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf88>
1015c32e4: aa0803e0    	mov	x0, x8
1015c32e8: aa1703e1    	mov	x1, x23
1015c32ec: aa1503e2    	mov	x2, x21
1015c32f0: aa0303e4    	mov	x4, x3
1015c32f4: aa1303e3    	mov	x3, x19
1015c32f8: 912443ff    	add	sp, sp, #0x910
1015c32fc: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1015c3300: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1015c3304: a94357f6    	ldp	x22, x21, [sp, #0x30]
1015c3308: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1015c330c: a94167fa    	ldp	x26, x25, [sp, #0x10]
1015c3310: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1015c3314: 14004413    	b	0x1015d4360 <__RNvMs_NtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation19retained_map_helper>
1015c3318: b900011f    	str	wzr, [x8]
1015c331c: 52800189    	mov	w9, #0xc                ; =12
1015c3320: 39002109    	strb	w9, [x8, #0x8]
1015c3324: 9000d3c9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c3328: 91226d29    	add	x9, x9, #0x89b
1015c332c: 5280046a    	mov	w10, #0x23              ; =35
1015c3330: 17fffe6b    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c3334: b900011f    	str	wzr, [x8]
1015c3338: 52800189    	mov	w9, #0xc                ; =12
1015c333c: 39002109    	strb	w9, [x8, #0x8]
1015c3340: 9000d3c9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c3344: 91335929    	add	x9, x9, #0xcd6
1015c3348: 5280040a    	mov	w10, #0x20              ; =32
1015c334c: 17fffe64    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c3350: f9407c09    	ldr	x9, [x0, #0xf8]
1015c3354: f100093f    	cmp	x9, #0x2
1015c3358: 54001101    	b.ne	0x1015c3578 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa04>
1015c335c: b900011f    	str	wzr, [x8]
1015c3360: 52800189    	mov	w9, #0xc                ; =12
1015c3364: d000d3aa    	adrp	x10, 0x103039000 <_anon.19b44b453da724831023c27de6e0b6f2.100+0xf48>
1015c3368: 9103b54a    	add	x10, x10, #0xed
1015c336c: a900a909    	stp	x9, x10, [x8, #0x8]
1015c3370: 528004c9    	mov	w9, #0x26               ; =38
1015c3374: 17fffeea    	b	0x1015c2f1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a8>
1015c3378: f940006d    	ldr	x13, [x3]
1015c337c: f9424c19    	ldr	x25, [x0, #0x498]
1015c3380: f942c729    	ldr	x9, [x25, #0x588]
1015c3384: eb0901bf    	cmp	x13, x9
1015c3388: 54001442    	b.hs	0x1015c3610 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa9c>
1015c338c: a940a46a    	ldp	x10, x9, [x3, #0x8]
1015c3390: aa090149    	orr	x9, x10, x9
1015c3394: b50015a9    	cbnz	x9, 0x1015c3648 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xad4>
1015c3398: f942c329    	ldr	x9, [x25, #0x580]
1015c339c: 52800b0a    	mov	w10, #0x58              ; =88
1015c33a0: 9b0a25b6    	madd	x22, x13, x10, x9
1015c33a4: b94046c9    	ldr	w9, [x22, #0x44]
1015c33a8: eb09003f    	cmp	x1, x9
1015c33ac: 540014e1    	b.ne	0x1015c3648 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xad4>
1015c33b0: f9424813    	ldr	x19, [x0, #0x490]
1015c33b4: b942f269    	ldr	w9, [x19, #0x2f0]
1015c33b8: 7100053f    	cmp	w9, #0x1
1015c33bc: 54001461    	b.ne	0x1015c3648 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xad4>
1015c33c0: b942f669    	ldr	w9, [x19, #0x2f4]
1015c33c4: 6b01013f    	cmp	w9, w1
1015c33c8: 54001401    	b.ne	0x1015c3648 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xad4>
1015c33cc: 39518269    	ldrb	w9, [x19, #0x460]
1015c33d0: 7100053f    	cmp	w9, #0x1
1015c33d4: 540013a1    	b.ne	0x1015c3648 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xad4>
1015c33d8: aa0803f4    	mov	x20, x8
1015c33dc: f941e008    	ldr	x8, [x0, #0x3c0]
1015c33e0: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
1015c33e4: eb09011f    	cmp	x8, x9
1015c33e8: 54005b41    	b.ne	0x1015c3f50 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13dc>
1015c33ec: d000d1c8    	adrp	x8, 0x102ffd000 <_anon.70399bd8ea3438f11774e3396e76a872.10+0x30c2>
1015c33f0: 3dc15d00    	ldr	q0, [x8, #0x570]
1015c33f4: 3c808280    	stur	q0, [x20, #0x8]
1015c33f8: 528000c8    	mov	w8, #0x6                ; =6
1015c33fc: b9000288    	str	w8, [x20]
1015c3400: 17fffec8    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c3404: 94355972    	bl	0x1023199cc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope>
1015c3408: 360012e0    	tbz	w0, #0x0, 0x1015c3664 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xaf0>
1015c340c: 5280000b    	mov	w11, #0x0               ; =0
1015c3410: 5280000a    	mov	w10, #0x0               ; =0
1015c3414: d2800008    	mov	x8, #0x0                ; =0
1015c3418: 528000ed    	mov	w13, #0x7               ; =7
1015c341c: aa1703ec    	mov	x12, x23
1015c3420: 140000ef    	b	0x1015c37dc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc68>
1015c3424: f94353e8    	ldr	x8, [sp, #0x6a0]
1015c3428: f94357ee    	ldr	x14, [sp, #0x6a8]
1015c342c: f9435be9    	ldr	x9, [sp, #0x6b0]
1015c3430: 92403d0a    	and	x10, x8, #0xffff
1015c3434: f118195f    	cmp	x10, #0x606
1015c3438: aa1703ec    	mov	x12, x23
1015c343c: 54001c41    	b.ne	0x1015c37c4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc50>
1015c3440: 5280000a    	mov	w10, #0x0               ; =0
1015c3444: 528000cd    	mov	w13, #0x6               ; =6
1015c3448: aa0e03e8    	mov	x8, x14
1015c344c: 140000e4    	b	0x1015c37dc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc68>
1015c3450: 3dc1b3e0    	ldr	q0, [sp, #0x6c0]
1015c3454: 3dc1b7e1    	ldr	q1, [sp, #0x6d0]
1015c3458: ad010680    	stp	q0, q1, [x20, #0x20]
1015c345c: 3dc1bbe0    	ldr	q0, [sp, #0x6e0]
1015c3460: 3d801280    	str	q0, [x20, #0x40]
1015c3464: 3dc1afe0    	ldr	q0, [sp, #0x6b0]
1015c3468: 3dc1abe1    	ldr	q1, [sp, #0x6a0]
1015c346c: ad000281    	stp	q1, q0, [x20]
1015c3470: 17fffeac    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c3474: aa1703ee    	mov	x14, x23
1015c3478: f84b0dcd    	ldr	x13, [x14, #0xb0]!
1015c347c: eb0c01bf    	cmp	x13, x12
1015c3480: 54001ee1    	b.ne	0x1015c385c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xce8>
1015c3484: b900011f    	str	wzr, [x8]
1015c3488: 52800189    	mov	w9, #0xc                ; =12
1015c348c: 9000d3aa    	adrp	x10, 0x103037000 <_anon.496f237bd13ceadd644cb7ae086b3546.176+0x13b>
1015c3490: 913d454a    	add	x10, x10, #0xf51
1015c3494: a900a909    	stp	x9, x10, [x8, #0x8]
1015c3498: 52800429    	mov	w9, #0x21               ; =33
1015c349c: 17fffea0    	b	0x1015c2f1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a8>
1015c34a0: 52800218    	mov	w24, #0x10              ; =16
1015c34a4: f9400869    	ldr	x9, [x3, #0x10]
1015c34a8: b4000f49    	cbz	x9, 0x1015c3690 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xb1c>
1015c34ac: b900011f    	str	wzr, [x8]
1015c34b0: 52800189    	mov	w9, #0xc                ; =12
1015c34b4: 39002109    	strb	w9, [x8, #0x8]
1015c34b8: f000d3a9    	adrp	x9, 0x10303a000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x3b8>
1015c34bc: 91020929    	add	x9, x9, #0x82
1015c34c0: 14000052    	b	0x1015c3608 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa94>
1015c34c4: f9424c17    	ldr	x23, [x0, #0x498]
1015c34c8: f942c6eb    	ldr	x11, [x23, #0x588]
1015c34cc: f940e00a    	ldr	x10, [x0, #0x1c0]
1015c34d0: eb0b015f    	cmp	x10, x11
1015c34d4: 540024e2    	b.hs	0x1015c3970 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xdfc>
1015c34d8: f9424815    	ldr	x21, [x0, #0x490]
1015c34dc: b942f2ab    	ldr	w11, [x21, #0x2f0]
1015c34e0: 7100057f    	cmp	w11, #0x1
1015c34e4: 54003401    	b.ne	0x1015c3b64 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xff0>
1015c34e8: f940046b    	ldr	x11, [x3, #0x8]
1015c34ec: eb0a017f    	cmp	x11, x10
1015c34f0: 54008241    	b.ne	0x1015c4538 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x19c4>
1015c34f4: f940086b    	ldr	x11, [x3, #0x10]
1015c34f8: b500820b    	cbnz	x11, 0x1015c4538 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x19c4>
1015c34fc: b50081e9    	cbnz	x9, 0x1015c4538 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x19c4>
1015c3500: f942c2e9    	ldr	x9, [x23, #0x580]
1015c3504: 52800b0b    	mov	w11, #0x58              ; =88
1015c3508: 9b0b2558    	madd	x24, x10, x11, x9
1015c350c: b9404b1a    	ldr	w26, [x24, #0x48]
1015c3510: eb1a003f    	cmp	x1, x26
1015c3514: 54008121    	b.ne	0x1015c4538 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x19c4>
1015c3518: b942eaa9    	ldr	w9, [x21, #0x2e8]
1015c351c: 360080e9    	tbz	w9, #0x0, 0x1015c4538 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x19c4>
1015c3520: b9403709    	ldr	w9, [x24, #0x34]
1015c3524: b942eeaa    	ldr	w10, [x21, #0x2ec]
1015c3528: 6b09015f    	cmp	w10, w9
1015c352c: 54008061    	b.ne	0x1015c4538 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x19c4>
1015c3530: f9400f09    	ldr	x9, [x24, #0x18]
1015c3534: b4008029    	cbz	x9, 0x1015c4538 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x19c4>
1015c3538: aa0303f9    	mov	x25, x3
1015c353c: aa0003f4    	mov	x20, x0
1015c3540: aa0803f6    	mov	x22, x8
1015c3544: b942f6b3    	ldr	w19, [x21, #0x2f4]
1015c3548: f9400b08    	ldr	x8, [x24, #0x10]
1015c354c: f100053f    	cmp	x9, #0x1
1015c3550: 54006141    	b.ne	0x1015c4178 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1604>
1015c3554: d280000a    	mov	x10, #0x0               ; =0
1015c3558: 14000311    	b	0x1015c419c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1628>
1015c355c: b900011f    	str	wzr, [x8]
1015c3560: 52800189    	mov	w9, #0xc                ; =12
1015c3564: b000d3aa    	adrp	x10, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c3568: 9139d94a    	add	x10, x10, #0xe76
1015c356c: a900a909    	stp	x9, x10, [x8, #0x8]
1015c3570: 52800449    	mov	w9, #0x22               ; =34
1015c3574: 17fffe6a    	b	0x1015c2f1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a8>
1015c3578: f9424c0b    	ldr	x11, [x0, #0x498]
1015c357c: f942c56c    	ldr	x12, [x11, #0x588]
1015c3580: f940e00a    	ldr	x10, [x0, #0x1c0]
1015c3584: eb0c015f    	cmp	x10, x12
1015c3588: 54002022    	b.hs	0x1015c398c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe18>
1015c358c: f942c16b    	ldr	x11, [x11, #0x580]
1015c3590: 52800b0c    	mov	w12, #0x58              ; =88
1015c3594: 9b0c2d4b    	madd	x11, x10, x12, x11
1015c3598: b940396b    	ldr	w11, [x11, #0x38]
1015c359c: eb0b003f    	cmp	x1, x11
1015c35a0: 540002a1    	b.ne	0x1015c35f4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa80>
1015c35a4: 9107200b    	add	x11, x0, #0x1c8
1015c35a8: 3dc00160    	ldr	q0, [x11]
1015c35ac: 3c808340    	stur	q0, [x26, #0x8]
1015c35b0: a940306b    	ldp	x11, x12, [x3]
1015c35b4: f940086d    	ldr	x13, [x3, #0x10]
1015c35b8: f94357ee    	ldr	x14, [sp, #0x6a8]
1015c35bc: f9435bef    	ldr	x15, [sp, #0x6b0]
1015c35c0: eb0a017f    	cmp	x11, x10
1015c35c4: fa4e0180    	ccmp	x12, x14, #0x0, eq
1015c35c8: fa4f01a0    	ccmp	x13, x15, #0x0, eq
1015c35cc: 1a9f07ea    	cset	w10, ne
1015c35d0: b5000129    	cbnz	x9, 0x1015c35f4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa80>
1015c35d4: 3500010a    	cbnz	w10, 0x1015c35f4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa80>
1015c35d8: f9424809    	ldr	x9, [x0, #0x490]
1015c35dc: b942f12a    	ldr	w10, [x9, #0x2f0]
1015c35e0: 350000aa    	cbnz	w10, 0x1015c35f4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa80>
1015c35e4: b942e92a    	ldr	w10, [x9, #0x2e8]
1015c35e8: 3500006a    	cbnz	w10, 0x1015c35f4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa80>
1015c35ec: 394ce12a    	ldrb	w10, [x9, #0x338]
1015c35f0: 360056aa    	tbz	w10, #0x0, 0x1015c40c4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1550>
1015c35f4: b900011f    	str	wzr, [x8]
1015c35f8: 52800189    	mov	w9, #0xc                ; =12
1015c35fc: 39002109    	strb	w9, [x8, #0x8]
1015c3600: 9000d3c9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c3604: 9132a129    	add	x9, x9, #0xca8
1015c3608: 528005ca    	mov	w10, #0x2e              ; =46
1015c360c: 17fffdb4    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c3610: b900011f    	str	wzr, [x8]
1015c3614: 52800189    	mov	w9, #0xc                ; =12
1015c3618: 9000d3ca    	adrp	x10, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c361c: 912bf14a    	add	x10, x10, #0xafc
1015c3620: a900a909    	stp	x9, x10, [x8, #0x8]
1015c3624: 52800289    	mov	w9, #0x14               ; =20
1015c3628: 17fffe3d    	b	0x1015c2f1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a8>
1015c362c: b900011f    	str	wzr, [x8]
1015c3630: 52800189    	mov	w9, #0xc                ; =12
1015c3634: 39002109    	strb	w9, [x8, #0x8]
1015c3638: 9000d3c9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c363c: 912b1929    	add	x9, x9, #0xac6
1015c3640: 528006ca    	mov	w10, #0x36              ; =54
1015c3644: 17fffda6    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c3648: b900011f    	str	wzr, [x8]
1015c364c: 52800189    	mov	w9, #0xc                ; =12
1015c3650: 39002109    	strb	w9, [x8, #0x8]
1015c3654: 9000d3c9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c3658: 912f9929    	add	x9, x9, #0xbe6
1015c365c: 528004ca    	mov	w10, #0x26              ; =38
1015c3660: 17fffd9f    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c3664: f9418368    	ldr	x8, [x27, #0x300]
1015c3668: f9418769    	ldr	x9, [x27, #0x308]
1015c366c: ab160108    	adds	x8, x8, x22
1015c3670: 54008562    	b.hs	0x1015c471c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ba8>
1015c3674: eb09011f    	cmp	x8, x9
1015c3678: 54001989    	b.ls	0x1015c39a8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe34>
1015c367c: aa1703ec    	mov	x12, x23
1015c3680: 5280000b    	mov	w11, #0x0               ; =0
1015c3684: 5280000a    	mov	w10, #0x0               ; =0
1015c3688: 528000cd    	mov	w13, #0x6               ; =6
1015c368c: 14000054    	b	0x1015c37dc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc68>
1015c3690: f9424809    	ldr	x9, [x0, #0x490]
1015c3694: f941e129    	ldr	x9, [x9, #0x3c0]
1015c3698: b4000b29    	cbz	x9, 0x1015c37fc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc88>
1015c369c: f940212a    	ldr	x10, [x9, #0x40]
1015c36a0: f100095f    	cmp	x10, #0x2
1015c36a4: 54000ac0    	b.eq	0x1015c37fc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc88>
1015c36a8: f9406d2a    	ldr	x10, [x9, #0xd8]
1015c36ac: eb13015f    	cmp	x10, x19
1015c36b0: 54000a61    	b.ne	0x1015c37fc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc88>
1015c36b4: f8786b6a    	ldr	x10, [x27, x24]
1015c36b8: f9403d2b    	ldr	x11, [x9, #0x78]
1015c36bc: eb0b015f    	cmp	x10, x11
1015c36c0: 540009e2    	b.hs	0x1015c37fc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc88>
1015c36c4: f9403929    	ldr	x9, [x9, #0x70]
1015c36c8: 5280210b    	mov	w11, #0x108             ; =264
1015c36cc: 9b0b7d4a    	mul	x10, x10, x11
1015c36d0: f86a6929    	ldr	x9, [x9, x10]
1015c36d4: b5ffeec9    	cbnz	x9, 0x1015c34ac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x938>
1015c36d8: 911043f9    	add	x25, sp, #0x410
1015c36dc: aa0803f6    	mov	x22, x8
1015c36e0: f9426808    	ldr	x8, [x0, #0x4d0]
1015c36e4: b4003e48    	cbz	x8, 0x1015c3eac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1338>
1015c36e8: f940578a    	ldr	x10, [x28, #0xa8]
1015c36ec: 91000949    	add	x9, x10, #0x2
1015c36f0: f9426c0b    	ldr	x11, [x0, #0x4d8]
1015c36f4: eb0b013f    	cmp	x9, x11
1015c36f8: 54003da2    	b.hs	0x1015c3eac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1338>
1015c36fc: f90023e0    	str	x0, [sp, #0x40]
1015c3700: 91000d4a    	add	x10, x10, #0x3
1015c3704: eb0b015f    	cmp	x10, x11
1015c3708: 54003d22    	b.hs	0x1015c3eac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1338>
1015c370c: aa0103f4    	mov	x20, x1
1015c3710: f8697909    	ldr	x9, [x8, x9, lsl #3]
1015c3714: f9001fe9    	str	x9, [sp, #0x38]
1015c3718: f86a7908    	ldr	x8, [x8, x10, lsl #3]
1015c371c: f90027e8    	str	x8, [sp, #0x48]
1015c3720: 3dc00060    	ldr	q0, [x3]
1015c3724: 3d8107e0    	str	q0, [sp, #0x410]
1015c3728: 528000a8    	mov	w8, #0x5                ; =5
1015c372c: f90213e8    	str	x8, [sp, #0x420]
1015c3730: 911a83e0    	add	x0, sp, #0x6a0
1015c3734: 911043e3    	add	x3, sp, #0x410
1015c3738: f94023e1    	ldr	x1, [sp, #0x40]
1015c373c: aa1403e2    	mov	x2, x20
1015c3740: 97ffc819    	bl	0x1015b57a4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation15end_closed_tail>
1015c3744: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c3748: 7100191f    	cmp	w8, #0x6
1015c374c: 54006381    	b.ne	0x1015c43bc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1848>
1015c3750: f941bee1    	ldr	x1, [x23, #0x378]
1015c3754: eb01029f    	cmp	x20, x1
1015c3758: 5401af62    	b.hs	0x1015c6d44 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41d0>
1015c375c: f941bae8    	ldr	x8, [x23, #0x370]
1015c3760: 52802e09    	mov	w9, #0x170              ; =368
1015c3764: 9b092288    	madd	x8, x20, x9, x8
1015c3768: a9402508    	ldp	x8, x9, [x8]
1015c376c: f100091f    	cmp	x8, #0x2
1015c3770: fa1f013f    	sbcs	xzr, x9, xzr
1015c3774: 54006c02    	b.hs	0x1015c44f4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1980>
1015c3778: f94202e1    	ldr	x1, [x23, #0x400]
1015c377c: eb01029f    	cmp	x20, x1
1015c3780: 5401bf22    	b.hs	0x1015c6f64 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x43f0>
1015c3784: f941fee8    	ldr	x8, [x23, #0x3f8]
1015c3788: 52803e09    	mov	w9, #0x1f0              ; =496
1015c378c: 9b092289    	madd	x9, x20, x9, x8
1015c3790: f9001be9    	str	x9, [sp, #0x30]
1015c3794: a9402129    	ldp	x9, x8, [x9]
1015c3798: d27f0129    	eor	x9, x9, #0x2
1015c379c: aa080128    	orr	x8, x9, x8
1015c37a0: b5006da8    	cbnz	x8, 0x1015c4554 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x19e0>
1015c37a4: b90002df    	str	wzr, [x22]
1015c37a8: 52800188    	mov	w8, #0xc                ; =12
1015c37ac: 9000d3a9    	adrp	x9, 0x103037000 <_anon.496f237bd13ceadd644cb7ae086b3546.176+0x13b>
1015c37b0: 9138a129    	add	x9, x9, #0xe28
1015c37b4: a900a6c8    	stp	x8, x9, [x22, #0x8]
1015c37b8: 52800468    	mov	w8, #0x23               ; =35
1015c37bc: f9000ec8    	str	x8, [x22, #0x18]
1015c37c0: 17fffdd8    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c37c4: aa0903ea    	mov	x10, x9
1015c37c8: d360fd2b    	lsr	x11, x9, #32
1015c37cc: 3cc18340    	ldur	q0, [x26, #0x18]
1015c37d0: 3c9903a0    	stur	q0, [x29, #-0x70]
1015c37d4: 528000ed    	mov	w13, #0x7               ; =7
1015c37d8: aa0e03e9    	mov	x9, x14
1015c37dc: b900019f    	str	wzr, [x12]
1015c37e0: 3900218d    	strb	w13, [x12, #0x8]
1015c37e4: a9012588    	stp	x8, x9, [x12, #0x10]
1015c37e8: 29042d8a    	stp	w10, w11, [x12, #0x20]
1015c37ec: 3cd903a0    	ldur	q0, [x29, #-0x70]
1015c37f0: 3c828180    	stur	q0, [x12, #0x28]
1015c37f4: b900399f    	str	wzr, [x12, #0x38]
1015c37f8: 17fffdca    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c37fc: b900011f    	str	wzr, [x8]
1015c3800: 52800189    	mov	w9, #0xc                ; =12
1015c3804: d000d3aa    	adrp	x10, 0x103039000 <_anon.19b44b453da724831023c27de6e0b6f2.100+0xf48>
1015c3808: 911d0d4a    	add	x10, x10, #0x743
1015c380c: a900a909    	stp	x9, x10, [x8, #0x8]
1015c3810: 52800569    	mov	w9, #0x2b               ; =43
1015c3814: 17fffdc2    	b	0x1015c2f1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a8>
1015c3818: d1006f8a    	sub	x10, x28, #0x1b
1015c381c: f100095f    	cmp	x10, #0x2
1015c3820: 54001882    	b.hs	0x1015c3b30 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfbc>
1015c3824: a9409865    	ldp	x5, x6, [x3, #0x8]
1015c3828: f9400064    	ldr	x4, [x3]
1015c382c: aa0803e0    	mov	x0, x8
1015c3830: aa1703e1    	mov	x1, x23
1015c3834: aa1503e2    	mov	x2, x21
1015c3838: aa1303e3    	mov	x3, x19
1015c383c: 912443ff    	add	sp, sp, #0x910
1015c3840: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1015c3844: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1015c3848: a94357f6    	ldp	x22, x21, [sp, #0x30]
1015c384c: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1015c3850: a94167fa    	ldp	x26, x25, [sp, #0x10]
1015c3854: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1015c3858: 17fff451    	b	0x1015c099c <__RNvMNtNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime4maps5owner6frozen16frozen_map_callsNtNtBa_10invocation10Invocation17frozen_map_helper>
1015c385c: b50007ca    	cbnz	x10, 0x1015c3954 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xde0>
1015c3860: f942480c    	ldr	x12, [x0, #0x490]
1015c3864: b942f18a    	ldr	w10, [x12, #0x2f0]
1015c3868: 7100055f    	cmp	w10, #0x1
1015c386c: 54000741    	b.ne	0x1015c3954 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xde0>
1015c3870: b942f58a    	ldr	w10, [x12, #0x2f4]
1015c3874: 6b09015f    	cmp	w10, w9
1015c3878: 540006e1    	b.ne	0x1015c3954 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xde0>
1015c387c: b942e989    	ldr	w9, [x12, #0x2e8]
1015c3880: 7100053f    	cmp	w9, #0x1
1015c3884: 54000681    	b.ne	0x1015c3954 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xde0>
1015c3888: b9403169    	ldr	w9, [x11, #0x30]
1015c388c: b942ed8a    	ldr	w10, [x12, #0x2ec]
1015c3890: 6b09015f    	cmp	w10, w9
1015c3894: 54000601    	b.ne	0x1015c3954 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xde0>
1015c3898: a90333e1    	stp	x1, x12, [sp, #0x30]
1015c389c: f90017ee    	str	x14, [sp, #0x28]
1015c38a0: a90423e0    	stp	x0, x8, [sp, #0x40]
1015c38a4: 52800028    	mov	w8, #0x1                ; =1
1015c38a8: aa090508    	orr	x8, x8, x9, lsl #1
1015c38ac: f9425c01    	ldr	x1, [x0, #0x4b8]
1015c38b0: eb01011f    	cmp	x8, x1
1015c38b4: 54019642    	b.hs	0x1015c6b7c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4008>
1015c38b8: f94023e9    	ldr	x9, [sp, #0x40]
1015c38bc: f9425929    	ldr	x9, [x9, #0x4b0]
1015c38c0: f8687928    	ldr	x8, [x9, x8, lsl #3]
1015c38c4: f100051f    	cmp	x8, #0x1
1015c38c8: f94027e8    	ldr	x8, [sp, #0x48]
1015c38cc: f9401fe9    	ldr	x9, [sp, #0x38]
1015c38d0: 54000421    	b.ne	0x1015c3954 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xde0>
1015c38d4: 910ee120    	add	x0, x9, #0x3b8
1015c38d8: 94355b48    	bl	0x10231a5f8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget4used>
1015c38dc: f9401fe9    	ldr	x9, [sp, #0x38]
1015c38e0: f94027e8    	ldr	x8, [sp, #0x48]
1015c38e4: eb1b001f    	cmp	x0, x27
1015c38e8: 54000361    	b.ne	0x1015c3954 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xde0>
1015c38ec: eb13003f    	cmp	x1, x19
1015c38f0: 54000321    	b.ne	0x1015c3954 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xde0>
1015c38f4: 911a83e8    	add	x8, sp, #0x6a0
1015c38f8: 910ee120    	add	x0, x9, #0x3b8
1015c38fc: 94355857    	bl	0x102319a58 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
1015c3900: f94027e8    	ldr	x8, [sp, #0x48]
1015c3904: f94353e9    	ldr	x9, [sp, #0x6a0]
1015c3908: f100053f    	cmp	x9, #0x1
1015c390c: 54000241    	b.ne	0x1015c3954 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xde0>
1015c3910: f94357e9    	ldr	x9, [sp, #0x6a8]
1015c3914: eb16013f    	cmp	x9, x22
1015c3918: 540001e1    	b.ne	0x1015c3954 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xde0>
1015c391c: f9435be9    	ldr	x9, [sp, #0x6b0]
1015c3920: eb19013f    	cmp	x9, x25
1015c3924: 54000181    	b.ne	0x1015c3954 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xde0>
1015c3928: b4007254    	cbz	x20, 0x1015c4770 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1bfc>
1015c392c: f1000a9f    	cmp	x20, #0x2
1015c3930: 54007020    	b.eq	0x1015c4734 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1bc0>
1015c3934: f1000e9f    	cmp	x20, #0x3
1015c3938: 540070c1    	b.ne	0x1015c4750 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1bdc>
1015c393c: b50070bc    	cbnz	x28, 0x1015c4750 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1bdc>
1015c3940: a9408ae1    	ldp	x1, x2, [x23, #0x8]
1015c3944: f9401be0    	ldr	x0, [sp, #0x30]
1015c3948: 940053be    	bl	0x1015d8840 <__RNvXsC_NtNtCsgDHHaSskbIF_4core5slice3cmpmNtB5_13SliceContains14slice_contains>
1015c394c: 37006fe0    	tbnz	w0, #0x0, 0x1015c4748 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1bd4>
1015c3950: 14000380    	b	0x1015c4750 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1bdc>
1015c3954: b900011f    	str	wzr, [x8]
1015c3958: 52800189    	mov	w9, #0xc                ; =12
1015c395c: 39002109    	strb	w9, [x8, #0x8]
1015c3960: f000d3a9    	adrp	x9, 0x10303a000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x3b8>
1015c3964: 91071d29    	add	x9, x9, #0x1c7
1015c3968: 528007ca    	mov	w10, #0x3e              ; =62
1015c396c: 17fffcdc    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c3970: b900011f    	str	wzr, [x8]
1015c3974: 52800189    	mov	w9, #0xc                ; =12
1015c3978: 9000d3ca    	adrp	x10, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c397c: 9130b54a    	add	x10, x10, #0xc2d
1015c3980: a900a909    	stp	x9, x10, [x8, #0x8]
1015c3984: 52800269    	mov	w9, #0x13               ; =19
1015c3988: 17fffd65    	b	0x1015c2f1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a8>
1015c398c: b900011f    	str	wzr, [x8]
1015c3990: 52800189    	mov	w9, #0xc                ; =12
1015c3994: d000d3aa    	adrp	x10, 0x103039000 <_anon.19b44b453da724831023c27de6e0b6f2.100+0xf48>
1015c3998: 91044d4a    	add	x10, x10, #0x113
1015c399c: a900a909    	stp	x9, x10, [x8, #0x8]
1015c39a0: 52800329    	mov	w9, #0x19               ; =25
1015c39a4: 17fffd5e    	b	0x1015c2f1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a8>
1015c39a8: aa1303e0    	mov	x0, x19
1015c39ac: aa1403e1    	mov	x1, x20
1015c39b0: aa1903ea    	mov	x10, x25
1015c39b4: f9018368    	str	x8, [x27, #0x300]
1015c39b8: 911a83e8    	add	x8, sp, #0x6a0
1015c39bc: b100355f    	cmn	x10, #0xd
1015c39c0: 54000101    	b.ne	0x1015c39e0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe6c>
1015c39c4: 9400252a    	bl	0x1015cce6c <__RNvMs1_NtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation6prefixNtB7_10Invocation17check_prefix_exit>
1015c39c8: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c39cc: 7100191f    	cmp	w8, #0x6
1015c39d0: 54000221    	b.ne	0x1015c3a14 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xea0>
1015c39d4: aa1703e8    	mov	x8, x23
1015c39d8: aa1903e9    	mov	x9, x25
1015c39dc: 14000017    	b	0x1015c3a38 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xec4>
1015c39e0: 9400257c    	bl	0x1015ccfd0 <__RNvMs1_NtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation6prefixNtB7_10Invocation19check_prefix_header>
1015c39e4: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c39e8: 7100191f    	cmp	w8, #0x6
1015c39ec: 54000141    	b.ne	0x1015c3a14 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xea0>
1015c39f0: aa1903e9    	mov	x9, x25
1015c39f4: b1002b3f    	cmn	x25, #0xa
1015c39f8: aa1703e8    	mov	x8, x23
1015c39fc: 540001e1    	b.ne	0x1015c3a38 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xec4>
1015c3a00: aa1303e1    	mov	x1, x19
1015c3a04: f940566a    	ldr	x10, [x19, #0xa8]
1015c3a08: aa1503e3    	mov	x3, x21
1015c3a0c: b50006aa    	cbnz	x10, 0x1015c3ae0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf6c>
1015c3a10: 14000013    	b	0x1015c3a5c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xee8>
1015c3a14: 3dc1b3e0    	ldr	q0, [sp, #0x6c0]
1015c3a18: 3dc1b7e1    	ldr	q1, [sp, #0x6d0]
1015c3a1c: ad0106e0    	stp	q0, q1, [x23, #0x20]
1015c3a20: 3dc1bbe0    	ldr	q0, [sp, #0x6e0]
1015c3a24: 3d8012e0    	str	q0, [x23, #0x40]
1015c3a28: 3dc1afe0    	ldr	q0, [sp, #0x6b0]
1015c3a2c: 3dc1abe1    	ldr	q1, [sp, #0x6a0]
1015c3a30: ad0002e1    	stp	q1, q0, [x23]
1015c3a34: 17fffd3b    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c3a38: aa1503e3    	mov	x3, x21
1015c3a3c: a9402eaa    	ldp	x10, x11, [x21]
1015c3a40: f9400aac    	ldr	x12, [x21, #0x10]
1015c3a44: aa0b014a    	orr	x10, x10, x11
1015c3a48: aa1303e1    	mov	x1, x19
1015c3a4c: f940566b    	ldr	x11, [x19, #0xa8]
1015c3a50: aa0b018b    	orr	x11, x12, x11
1015c3a54: aa0b014a    	orr	x10, x10, x11
1015c3a58: b500044a    	cbnz	x10, 0x1015c3ae0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf6c>
1015c3a5c: f941482a    	ldr	x10, [x1, #0x290]
1015c3a60: f100195f    	cmp	x10, #0x6
1015c3a64: 540003e1    	b.ne	0x1015c3ae0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf6c>
1015c3a68: f9424c2a    	ldr	x10, [x1, #0x498]
1015c3a6c: f940014b    	ldr	x11, [x10]
1015c3a70: f100097f    	cmp	x11, #0x2
1015c3a74: 54007da0    	b.eq	0x1015c4a28 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1eb4>
1015c3a78: 9108e039    	add	x25, x1, #0x238
1015c3a7c: f940032b    	ldr	x11, [x25]
1015c3a80: f1000d7f    	cmp	x11, #0x3
1015c3a84: 54007d80    	b.eq	0x1015c4a34 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ec0>
1015c3a88: f9409d56    	ldr	x22, [x10, #0x138]
1015c3a8c: b942802b    	ldr	w11, [x1, #0x280]
1015c3a90: b100313f    	cmn	x9, #0xc
1015c3a94: 54000c4c    	b.gt	0x1015c3c1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x10a8>
1015c3a98: b100353f    	cmn	x9, #0xd
1015c3a9c: 54001540    	b.eq	0x1015c3d44 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x11d0>
1015c3aa0: b100313f    	cmn	x9, #0xc
1015c3aa4: 54001421    	b.ne	0x1015c3d28 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x11b4>
1015c3aa8: aa1403e9    	mov	x9, x20
1015c3aac: 6b09017f    	cmp	w11, w9
1015c3ab0: 540000a1    	b.ne	0x1015c3ac4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf50>
1015c3ab4: 394a202b    	ldrb	w11, [x1, #0x288]
1015c3ab8: 3600006b    	tbz	w11, #0x0, 0x1015c3ac4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf50>
1015c3abc: 394a242b    	ldrb	w11, [x1, #0x289]
1015c3ac0: 3600216b    	tbz	w11, #0x0, 0x1015c3eec <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1378>
1015c3ac4: b900011f    	str	wzr, [x8]
1015c3ac8: 52800189    	mov	w9, #0xc                ; =12
1015c3acc: 39002109    	strb	w9, [x8, #0x8]
1015c3ad0: 9000d3c9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c3ad4: 913f6129    	add	x9, x9, #0xfd8
1015c3ad8: 5280052a    	mov	w10, #0x29              ; =41
1015c3adc: 17fffc80    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c3ae0: b900011f    	str	wzr, [x8]
1015c3ae4: 52800189    	mov	w9, #0xc                ; =12
1015c3ae8: 39002109    	strb	w9, [x8, #0x8]
1015c3aec: b000d3c9    	adrp	x9, 0x10303c000 <_anon.19b44b453da724831023c27de6e0b6f2.686+0xd1d>
1015c3af0: 91007529    	add	x9, x9, #0x1d
1015c3af4: 5280048a    	mov	w10, #0x24              ; =36
1015c3af8: 17fffc79    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c3afc: f1002b9f    	cmp	x28, #0xa
1015c3b00: 54000401    	b.ne	0x1015c3b80 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x100c>
1015c3b04: aa0803e0    	mov	x0, x8
1015c3b08: aa1703e1    	mov	x1, x23
1015c3b0c: aa1503e2    	mov	x2, x21
1015c3b10: 912443ff    	add	sp, sp, #0x910
1015c3b14: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1015c3b18: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1015c3b1c: a94357f6    	ldp	x22, x21, [sp, #0x30]
1015c3b20: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1015c3b24: a94167fa    	ldp	x26, x25, [sp, #0x10]
1015c3b28: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1015c3b2c: 17ffc8af    	b	0x1015b5de8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation17begin_closed_tail>
1015c3b30: f1007b9f    	cmp	x28, #0x1e
1015c3b34: 54000261    	b.ne	0x1015c3b80 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x100c>
1015c3b38: aa0803e0    	mov	x0, x8
1015c3b3c: aa1703e1    	mov	x1, x23
1015c3b40: aa1503e2    	mov	x2, x21
1015c3b44: 912443ff    	add	sp, sp, #0x910
1015c3b48: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1015c3b4c: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1015c3b50: a94357f6    	ldp	x22, x21, [sp, #0x30]
1015c3b54: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1015c3b58: a94167fa    	ldp	x26, x25, [sp, #0x10]
1015c3b5c: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1015c3b60: 17ffbbfa    	b	0x1015b2b48 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16numeric_segmentsNtB4_10Invocation21begin_numeric_segment>
1015c3b64: b900011f    	str	wzr, [x8]
1015c3b68: 52800189    	mov	w9, #0xc                ; =12
1015c3b6c: 39002109    	strb	w9, [x8, #0x8]
1015c3b70: 9000d3c9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c3b74: 91310129    	add	x9, x9, #0xc40
1015c3b78: 5280030a    	mov	w10, #0x18              ; =24
1015c3b7c: 17fffc58    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c3b80: aa0303f3    	mov	x19, x3
1015c3b84: f90027e8    	str	x8, [sp, #0x48]
1015c3b88: aa0903e0    	mov	x0, x9
1015c3b8c: aa1403e1    	mov	x1, x20
1015c3b90: aa1503e2    	mov	x2, x21
1015c3b94: 97fff417    	bl	0x1015c0bf0 <__RNvMNtNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime4maps5owner6frozen16frozen_map_callsNtNtBa_10invocation10Invocation20frozen_native_action>
1015c3b98: 37000320    	tbnz	w0, #0x0, 0x1015c3bfc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1088>
1015c3b9c: aa1703e8    	mov	x8, x23
1015c3ba0: f9424af7    	ldr	x23, [x23, #0x490]
1015c3ba4: f90023e8    	str	x8, [sp, #0x40]
1015c3ba8: f9424d18    	ldr	x24, [x8, #0x498]
1015c3bac: aa1703e0    	mov	x0, x23
1015c3bb0: aa1803e1    	mov	x1, x24
1015c3bb4: aa1503e2    	mov	x2, x21
1015c3bb8: 940048b9    	bl	0x1015d5e9c <__RNvMs_NtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation22retained_native_action>
1015c3bbc: 37000200    	tbnz	w0, #0x0, 0x1015c3bfc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1088>
1015c3bc0: aa1703e0    	mov	x0, x23
1015c3bc4: aa1803e1    	mov	x1, x24
1015c3bc8: aa1503e2    	mov	x2, x21
1015c3bcc: 94004880    	bl	0x1015d5dcc <__RNvMs_NtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation20retained_native_call>
1015c3bd0: 37000160    	tbnz	w0, #0x0, 0x1015c3bfc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1088>
1015c3bd4: aa1703e0    	mov	x0, x23
1015c3bd8: aa1803e1    	mov	x1, x24
1015c3bdc: aa1503e2    	mov	x2, x21
1015c3be0: 94004895    	bl	0x1015d5e34 <__RNvMs_NtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation20retained_native_exit>
1015c3be4: 370000c0    	tbnz	w0, #0x0, 0x1015c3bfc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1088>
1015c3be8: aa1703e0    	mov	x0, x23
1015c3bec: aa1803e1    	mov	x1, x24
1015c3bf0: aa1503e2    	mov	x2, x21
1015c3bf4: 97ffe9fc    	bl	0x1015be3e4 <__RNvMNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtB8_10invocation10Invocation20retained_native_span>
1015c3bf8: 36002a00    	tbz	w0, #0x0, 0x1015c4138 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x15c4>
1015c3bfc: f94027e8    	ldr	x8, [sp, #0x48]
1015c3c00: b900011f    	str	wzr, [x8]
1015c3c04: 52800189    	mov	w9, #0xc                ; =12
1015c3c08: 39002109    	strb	w9, [x8, #0x8]
1015c3c0c: 9000d3c9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c3c10: 9121c129    	add	x9, x9, #0x870
1015c3c14: 5280056a    	mov	w10, #0x2b              ; =43
1015c3c18: 17fffc31    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c3c1c: b1002d3f    	cmn	x9, #0xb
1015c3c20: 54000e80    	b.eq	0x1015c3df0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x127c>
1015c3c24: b100293f    	cmn	x9, #0xa
1015c3c28: 54000801    	b.ne	0x1015c3d28 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x11b4>
1015c3c2c: 394a1035    	ldrb	w21, [x1, #0x284]
1015c3c30: f9413c22    	ldr	x2, [x1, #0x278]
1015c3c34: aa0103e8    	mov	x8, x1
1015c3c38: 911a83e0    	add	x0, sp, #0x6a0
1015c3c3c: aa0303e1    	mov	x1, x3
1015c3c40: 91094103    	add	x3, x8, #0x250
1015c3c44: 9400389f    	bl	0x1015d1ec0 <__RNvMs_NtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation6prefixNtB4_9Retention7checked>
1015c3c48: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c3c4c: 7100191f    	cmp	w8, #0x6
1015c3c50: 54001121    	b.ne	0x1015c3e74 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1300>
1015c3c54: f9435fe8    	ldr	x8, [sp, #0x6b8]
1015c3c58: 3cc08340    	ldur	q0, [x26, #0x8]
1015c3c5c: 3d818fe0    	str	q0, [sp, #0x630]
1015c3c60: f90323e8    	str	x8, [sp, #0x640]
1015c3c64: 37001355    	tbnz	w21, #0x0, 0x1015c3ecc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1358>
1015c3c68: aa1303e8    	mov	x8, x19
1015c3c6c: f9406269    	ldr	x9, [x19, #0xc0]
1015c3c70: f100093f    	cmp	x9, #0x2
1015c3c74: 540012c1    	b.ne	0x1015c3ecc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1358>
1015c3c78: f9411109    	ldr	x9, [x8, #0x220]
1015c3c7c: f100093f    	cmp	x9, #0x2
1015c3c80: 54001260    	b.eq	0x1015c3ecc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1358>
1015c3c84: f940ed09    	ldr	x9, [x8, #0x1d8]
1015c3c88: eb16013f    	cmp	x9, x22
1015c3c8c: 54001201    	b.ne	0x1015c3ecc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1358>
1015c3c90: f9426d15    	ldr	x21, [x8, #0x4d8]
1015c3c94: 92800808    	mov	x8, #-0x41              ; =-65
1015c3c98: f2e1ffe8    	movk	x8, #0xfff, lsl #48
1015c3c9c: eb0802bf    	cmp	x21, x8
1015c3ca0: 5400a648    	b.hi	0x1015c5168 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x25f4>
1015c3ca4: f9424a68    	ldr	x8, [x19, #0x490]
1015c3ca8: d37ceea9    	lsl	x9, x21, #4
1015c3cac: 911a83e0    	add	x0, sp, #0x6a0
1015c3cb0: 910be101    	add	x1, x8, #0x2f8
1015c3cb4: 91100124    	add	x4, x9, #0x400
1015c3cb8: 52800002    	mov	w2, #0x0                ; =0
1015c3cbc: 97ff9f5b    	bl	0x1015aba28 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
1015c3cc0: 395a83e8    	ldrb	w8, [sp, #0x6a0]
1015c3cc4: 7100391f    	cmp	w8, #0xe
1015c3cc8: 54001d21    	b.ne	0x1015c406c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14f8>
1015c3ccc: b40000b5    	cbz	x21, 0x1015c3ce0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x116c>
1015c3cd0: f9426a60    	ldr	x0, [x19, #0x4d0]
1015c3cd4: b4003a00    	cbz	x0, 0x1015c4414 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18a0>
1015c3cd8: d37df2a1    	lsl	x1, x21, #3
1015c3cdc: 9460c35e    	bl	0x102df4a54 <dyld_stub_binder+0x102df4a54>
1015c3ce0: 91076260    	add	x0, x19, #0x1d8
1015c3ce4: 97ff9437    	bl	0x1015a8dc0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8borrowed5StateEBS_>
1015c3ce8: 52800048    	mov	w8, #0x2                ; =2
1015c3cec: f9011268    	str	x8, [x19, #0x220]
1015c3cf0: f9411e68    	ldr	x8, [x19, #0x238]
1015c3cf4: f1000d1f    	cmp	x8, #0x3
1015c3cf8: 54010c00    	b.eq	0x1015c5e78 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3304>
1015c3cfc: 3dc18fe0    	ldr	q0, [sp, #0x630]
1015c3d00: 3d800320    	str	q0, [x25]
1015c3d04: f94323e8    	ldr	x8, [sp, #0x640]
1015c3d08: f9000b28    	str	x8, [x25, #0x10]
1015c3d0c: f9400328    	ldr	x8, [x25]
1015c3d10: f1000d1f    	cmp	x8, #0x3
1015c3d14: 54010b80    	b.eq	0x1015c5e84 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3310>
1015c3d18: 52800028    	mov	w8, #0x1                ; =1
1015c3d1c: b9026a68    	str	w8, [x19, #0x268]
1015c3d20: b9026e74    	str	w20, [x19, #0x26c]
1015c3d24: 14000031    	b	0x1015c3de8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1274>
1015c3d28: b900011f    	str	wzr, [x8]
1015c3d2c: 52800189    	mov	w9, #0xc                ; =12
1015c3d30: 39002109    	strb	w9, [x8, #0x8]
1015c3d34: b000d3c9    	adrp	x9, 0x10303c000 <_anon.19b44b453da724831023c27de6e0b6f2.686+0xd1d>
1015c3d38: 91000529    	add	x9, x9, #0x1
1015c3d3c: 5280038a    	mov	w10, #0x1c              ; =28
1015c3d40: 17fffbe7    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c3d44: b9427029    	ldr	w9, [x1, #0x270]
1015c3d48: 350007c9    	cbnz	w9, 0x1015c3e40 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x12cc>
1015c3d4c: f9406029    	ldr	x9, [x1, #0xc0]
1015c3d50: f100093f    	cmp	x9, #0x2
1015c3d54: 54000761    	b.ne	0x1015c3e40 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x12cc>
1015c3d58: f9411029    	ldr	x9, [x1, #0x220]
1015c3d5c: f100093f    	cmp	x9, #0x2
1015c3d60: 54000700    	b.eq	0x1015c3e40 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x12cc>
1015c3d64: f940ec29    	ldr	x9, [x1, #0x1d8]
1015c3d68: eb16013f    	cmp	x9, x22
1015c3d6c: 540006a1    	b.ne	0x1015c3e40 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x12cc>
1015c3d70: f9426c35    	ldr	x21, [x1, #0x4d8]
1015c3d74: 92800808    	mov	x8, #-0x41              ; =-65
1015c3d78: f2e1ffe8    	movk	x8, #0xfff, lsl #48
1015c3d7c: eb0802bf    	cmp	x21, x8
1015c3d80: 54009f48    	b.hi	0x1015c5168 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x25f4>
1015c3d84: f9424a68    	ldr	x8, [x19, #0x490]
1015c3d88: d37ceea9    	lsl	x9, x21, #4
1015c3d8c: 911a83e0    	add	x0, sp, #0x6a0
1015c3d90: 910be101    	add	x1, x8, #0x2f8
1015c3d94: 91100124    	add	x4, x9, #0x400
1015c3d98: 52800002    	mov	w2, #0x0                ; =0
1015c3d9c: 97ff9f23    	bl	0x1015aba28 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
1015c3da0: 395a83e8    	ldrb	w8, [sp, #0x6a0]
1015c3da4: 7100391f    	cmp	w8, #0xe
1015c3da8: 54001621    	b.ne	0x1015c406c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14f8>
1015c3dac: b40000b5    	cbz	x21, 0x1015c3dc0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x124c>
1015c3db0: f9426a60    	ldr	x0, [x19, #0x4d0]
1015c3db4: b4003300    	cbz	x0, 0x1015c4414 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18a0>
1015c3db8: d37df2a1    	lsl	x1, x21, #3
1015c3dbc: 9460c326    	bl	0x102df4a54 <dyld_stub_binder+0x102df4a54>
1015c3dc0: 91076260    	add	x0, x19, #0x1d8
1015c3dc4: 97ff93ff    	bl	0x1015a8dc0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8borrowed5StateEBS_>
1015c3dc8: 52800048    	mov	w8, #0x2                ; =2
1015c3dcc: f9011268    	str	x8, [x19, #0x220]
1015c3dd0: f9411e68    	ldr	x8, [x19, #0x238]
1015c3dd4: f1000d1f    	cmp	x8, #0x3
1015c3dd8: 5400e520    	b.eq	0x1015c5a7c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f08>
1015c3ddc: 52800028    	mov	w8, #0x1                ; =1
1015c3de0: b9027268    	str	w8, [x19, #0x270]
1015c3de4: b9027674    	str	w20, [x19, #0x274]
1015c3de8: f90006ff    	str	xzr, [x23, #0x8]
1015c3dec: 14000056    	b	0x1015c3f44 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13d0>
1015c3df0: 6b14017f    	cmp	w11, w20
1015c3df4: 54000341    	b.ne	0x1015c3e5c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x12e8>
1015c3df8: 394a2029    	ldrb	w9, [x1, #0x288]
1015c3dfc: 37000309    	tbnz	w9, #0x0, 0x1015c3e5c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x12e8>
1015c3e00: 394a2429    	ldrb	w9, [x1, #0x289]
1015c3e04: 370002c9    	tbnz	w9, #0x0, 0x1015c3e5c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x12e8>
1015c3e08: 911a83e0    	add	x0, sp, #0x6a0
1015c3e0c: aa1403e2    	mov	x2, x20
1015c3e10: aa1603e4    	mov	x4, x22
1015c3e14: 97ffd230    	bl	0x1015b86d4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation23prepare_borrowed_region>
1015c3e18: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c3e1c: 7100191f    	cmp	w8, #0x6
1015c3e20: 540010c1    	b.ne	0x1015c4038 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14c4>
1015c3e24: f9400328    	ldr	x8, [x25]
1015c3e28: f1000d1f    	cmp	x8, #0x3
1015c3e2c: 5400c2a0    	b.eq	0x1015c5680 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b0c>
1015c3e30: 3cc08340    	ldur	q0, [x26, #0x8]
1015c3e34: 52800028    	mov	w8, #0x1                ; =1
1015c3e38: 390a2268    	strb	w8, [x19, #0x288]
1015c3e3c: 14000041    	b	0x1015c3f40 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13cc>
1015c3e40: b900011f    	str	wzr, [x8]
1015c3e44: 52800189    	mov	w9, #0xc                ; =12
1015c3e48: 39002109    	strb	w9, [x8, #0x8]
1015c3e4c: 9000d3c9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c3e50: 913d2529    	add	x9, x9, #0xf49
1015c3e54: 528005ea    	mov	w10, #0x2f              ; =47
1015c3e58: 17fffba1    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c3e5c: b900011f    	str	wzr, [x8]
1015c3e60: 52800189    	mov	w9, #0xc                ; =12
1015c3e64: 39002109    	strb	w9, [x8, #0x8]
1015c3e68: 9000d3c9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c3e6c: 913ea929    	add	x9, x9, #0xfaa
1015c3e70: 17fffde6    	b	0x1015c3608 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa94>
1015c3e74: 3dc1afe0    	ldr	q0, [sp, #0x6b0]
1015c3e78: 3dc1b3e1    	ldr	q1, [sp, #0x6c0]
1015c3e7c: 3c80c300    	stur	q0, [x24, #0xc]
1015c3e80: 3cc04340    	ldur	q0, [x26, #0x4]
1015c3e84: 3d8107e0    	str	q0, [sp, #0x410]
1015c3e88: 3dc1b7e0    	ldr	q0, [sp, #0x6d0]
1015c3e8c: 3dc1bbe2    	ldr	q2, [sp, #0x6e0]
1015c3e90: ad018ae0    	stp	q0, q2, [x23, #0x30]
1015c3e94: 3dc107e0    	ldr	q0, [sp, #0x410]
1015c3e98: 3c8042e0    	stur	q0, [x23, #0x4]
1015c3e9c: 3cc0c300    	ldur	q0, [x24, #0xc]
1015c3ea0: ad0086e0    	stp	q0, q1, [x23, #0x10]
1015c3ea4: b90002e8    	str	w8, [x23]
1015c3ea8: 17fffc1e    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c3eac: b90002df    	str	wzr, [x22]
1015c3eb0: 52800188    	mov	w8, #0xc                ; =12
1015c3eb4: 9000d3a9    	adrp	x9, 0x103037000 <_anon.496f237bd13ceadd644cb7ae086b3546.176+0x13b>
1015c3eb8: 913fb529    	add	x9, x9, #0xfed
1015c3ebc: a900a6c8    	stp	x8, x9, [x22, #0x8]
1015c3ec0: 52800608    	mov	w8, #0x30               ; =48
1015c3ec4: f9000ec8    	str	x8, [x22, #0x18]
1015c3ec8: 17fffc16    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c3ecc: b90002ff    	str	wzr, [x23]
1015c3ed0: 52800188    	mov	w8, #0xc                ; =12
1015c3ed4: 390022e8    	strb	w8, [x23, #0x8]
1015c3ed8: 9000d3c8    	adrp	x8, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c3edc: 913de108    	add	x8, x8, #0xf78
1015c3ee0: 52800649    	mov	w9, #0x32               ; =50
1015c3ee4: a90126e8    	stp	x8, x9, [x23, #0x10]
1015c3ee8: 17fffc0e    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c3eec: f9413941    	ldr	x1, [x10, #0x270]
1015c3ef0: eb01013f    	cmp	x9, x1
1015c3ef4: 540165a2    	b.hs	0x1015c6ba8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4034>
1015c3ef8: f9413548    	ldr	x8, [x10, #0x268]
1015c3efc: 8b141108    	add	x8, x8, x20, lsl #4
1015c3f00: b9400109    	ldr	w9, [x8]
1015c3f04: 360010a9    	tbz	w9, #0x0, 0x1015c4118 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x15a4>
1015c3f08: f9400503    	ldr	x3, [x8, #0x8]
1015c3f0c: 911a83e0    	add	x0, sp, #0x6a0
1015c3f10: aa1303e1    	mov	x1, x19
1015c3f14: aa1503e2    	mov	x2, x21
1015c3f18: 97ffc7c8    	bl	0x1015b5e38 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation19begin_closed_region>
1015c3f1c: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c3f20: 7100191f    	cmp	w8, #0x6
1015c3f24: 540008a1    	b.ne	0x1015c4038 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14c4>
1015c3f28: f9400328    	ldr	x8, [x25]
1015c3f2c: f1000d1f    	cmp	x8, #0x3
1015c3f30: 5400dc00    	b.eq	0x1015c5ab0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f3c>
1015c3f34: 3cc08340    	ldur	q0, [x26, #0x8]
1015c3f38: 52800028    	mov	w8, #0x1                ; =1
1015c3f3c: 390a2668    	strb	w8, [x19, #0x289]
1015c3f40: 3c8082e0    	stur	q0, [x23, #0x8]
1015c3f44: 528000c8    	mov	w8, #0x6                ; =6
1015c3f48: b90002e8    	str	w8, [x23]
1015c3f4c: 17fffbf5    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c3f50: aa0003f5    	mov	x21, x0
1015c3f54: f941ec09    	ldr	x9, [x0, #0x3d8]
1015c3f58: b4001869    	cbz	x9, 0x1015c4264 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x16f0>
1015c3f5c: f941eaaa    	ldr	x10, [x21, #0x3d0]
1015c3f60: eb08015f    	cmp	x10, x8
1015c3f64: 9a8833ec    	csel	x12, xzr, x8, lo
1015c3f68: cb0c014c    	sub	x12, x10, x12
1015c3f6c: f941e6ab    	ldr	x11, [x21, #0x3c8]
1015c3f70: 52800b0e    	mov	w14, #0x58              ; =88
1015c3f74: 9b0e2d8c    	madd	x12, x12, x14, x11
1015c3f78: f940218e    	ldr	x14, [x12, #0x40]
1015c3f7c: eb0d01df    	cmp	x14, x13
1015c3f80: 54000bc1    	b.ne	0x1015c40f8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1584>
1015c3f84: b942ea6d    	ldr	w13, [x19, #0x2e8]
1015c3f88: 710005bf    	cmp	w13, #0x1
1015c3f8c: 54000b61    	b.ne	0x1015c40f8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1584>
1015c3f90: b94036cd    	ldr	w13, [x22, #0x34]
1015c3f94: b942ee6e    	ldr	w14, [x19, #0x2ec]
1015c3f98: 6b0d01df    	cmp	w14, w13
1015c3f9c: 54000ae1    	b.ne	0x1015c40f8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1584>
1015c3fa0: d37ff9a0    	lsl	x0, x13, #1
1015c3fa4: f9425ea1    	ldr	x1, [x21, #0x4b8]
1015c3fa8: eb01001f    	cmp	x0, x1
1015c3fac: 54019742    	b.hs	0x1015c7294 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4720>
1015c3fb0: f940298d    	ldr	x13, [x12, #0x50]
1015c3fb4: f9425aae    	ldr	x14, [x21, #0x4b0]
1015c3fb8: f86079ce    	ldr	x14, [x14, x0, lsl #3]
1015c3fbc: eb0e01ad    	subs	x13, x13, x14
1015c3fc0: 540009c3    	b.lo	0x1015c40f8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1584>
1015c3fc4: f940258e    	ldr	x14, [x12, #0x48]
1015c3fc8: eb0e01bf    	cmp	x13, x14
1015c3fcc: 54000961    	b.ne	0x1015c40f8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1584>
1015c3fd0: f941feb7    	ldr	x23, [x21, #0x3f8]
1015c3fd4: f941f6ad    	ldr	x13, [x21, #0x3e8]
1015c3fd8: eb1701bf    	cmp	x13, x23
1015c3fdc: 54000140    	b.eq	0x1015c4004 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1490>
1015c3fe0: 910321b8    	add	x24, x13, #0xc8
1015c3fe4: f901f6b8    	str	x24, [x21, #0x3e8]
1015c3fe8: f94001a1    	ldr	x1, [x13]
1015c3fec: 294145a0    	ldp	w0, w17, [x13, #0x8]
1015c3ff0: 394041b0    	ldrb	w16, [x13, #0x10]
1015c3ff4: a941b9af    	ldp	x15, x14, [x13, #0x18]
1015c3ff8: b4007641    	cbz	x1, 0x1015c4ec0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x234c>
1015c3ffc: f100083f    	cmp	x1, #0x2
1015c4000: 54007e01    	b.ne	0x1015c4fc0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x244c>
1015c4004: b900029f    	str	wzr, [x20]
1015c4008: 52800188    	mov	w8, #0xc                ; =12
1015c400c: 39002288    	strb	w8, [x20, #0x8]
1015c4010: f000d3a8    	adrp	x8, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c4014: 912cb508    	add	x8, x8, #0xb2d
1015c4018: 528002c9    	mov	w9, #0x16               ; =22
1015c401c: 1400003d    	b	0x1015c4110 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x159c>
1015c4020: b000d1c8    	adrp	x8, 0x102ffd000 <_anon.70399bd8ea3438f11774e3396e76a872.10+0x30c2>
1015c4024: 3dc15d00    	ldr	q0, [x8, #0x570]
1015c4028: 3c808300    	stur	q0, [x24, #0x8]
1015c402c: 528000c8    	mov	w8, #0x6                ; =6
1015c4030: b9000308    	str	w8, [x24]
1015c4034: 17fffbbb    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c4038: b946a7e9    	ldr	w9, [sp, #0x6a4]
1015c403c: 3cc18340    	ldur	q0, [x26, #0x18]
1015c4040: 3c8182e0    	stur	q0, [x23, #0x18]
1015c4044: 3cc28340    	ldur	q0, [x26, #0x28]
1015c4048: 3c8282e0    	stur	q0, [x23, #0x28]
1015c404c: 3cc38340    	ldur	q0, [x26, #0x38]
1015c4050: 3c8382e0    	stur	q0, [x23, #0x38]
1015c4054: f94377ea    	ldr	x10, [sp, #0x6e8]
1015c4058: f90026ea    	str	x10, [x23, #0x48]
1015c405c: 3cc08340    	ldur	q0, [x26, #0x8]
1015c4060: 290026e8    	stp	w8, w9, [x23]
1015c4064: 3c8082e0    	stur	q0, [x23, #0x8]
1015c4068: 17fffbae    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c406c: 3dc1abe0    	ldr	q0, [sp, #0x6a0]
1015c4070: 3dc1afe1    	ldr	q1, [sp, #0x6b0]
1015c4074: 3d8107e0    	str	q0, [sp, #0x410]
1015c4078: 3d810be1    	str	q1, [sp, #0x420]
1015c407c: 3dc1b3e2    	ldr	q2, [sp, #0x6c0]
1015c4080: 3d810fe2    	str	q2, [sp, #0x430]
1015c4084: f9436be8    	ldr	x8, [sp, #0x6d0]
1015c4088: f90223e8    	str	x8, [sp, #0x440]
1015c408c: 3c804340    	stur	q0, [x26, #0x4]
1015c4090: 3c814341    	stur	q1, [x26, #0x14]
1015c4094: 3c824342    	stur	q2, [x26, #0x24]
1015c4098: f8034348    	stur	x8, [x26, #0x34]
1015c409c: b90002ff    	str	wzr, [x23]
1015c40a0: 3dc1abe0    	ldr	q0, [sp, #0x6a0]
1015c40a4: 3dc1afe1    	ldr	q1, [sp, #0x6b0]
1015c40a8: 3c8042e0    	stur	q0, [x23, #0x4]
1015c40ac: 3c8142e1    	stur	q1, [x23, #0x14]
1015c40b0: 3dc1b3e0    	ldr	q0, [sp, #0x6c0]
1015c40b4: 3c8242e0    	stur	q0, [x23, #0x24]
1015c40b8: 3cc2c340    	ldur	q0, [x26, #0x2c]
1015c40bc: 3d800ee0    	str	q0, [x23, #0x30]
1015c40c0: 17fffb98    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c40c4: aa0803f3    	mov	x19, x8
1015c40c8: 911a83e0    	add	x0, sp, #0x6a0
1015c40cc: 910be121    	add	x1, x9, #0x2f8
1015c40d0: 52800002    	mov	w2, #0x0                ; =0
1015c40d4: 52802004    	mov	w4, #0x100              ; =256
1015c40d8: 97ff9e54    	bl	0x1015aba28 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
1015c40dc: 395a83e8    	ldrb	w8, [sp, #0x6a0]
1015c40e0: 7100391f    	cmp	w8, #0xe
1015c40e4: 54000d01    	b.ne	0x1015c4284 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1710>
1015c40e8: f900067f    	str	xzr, [x19, #0x8]
1015c40ec: 528000c8    	mov	w8, #0x6                ; =6
1015c40f0: b9000268    	str	w8, [x19]
1015c40f4: 17fffb8b    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c40f8: b900029f    	str	wzr, [x20]
1015c40fc: 52800188    	mov	w8, #0xc                ; =12
1015c4100: 39002288    	strb	w8, [x20, #0x8]
1015c4104: f000d3a8    	adrp	x8, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c4108: 912ecd08    	add	x8, x8, #0xbb3
1015c410c: 52800669    	mov	w9, #0x33               ; =51
1015c4110: a9012688    	stp	x8, x9, [x20, #0x10]
1015c4114: 17fffb83    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c4118: b90002ff    	str	wzr, [x23]
1015c411c: 52800188    	mov	w8, #0xc                ; =12
1015c4120: b000d3a9    	adrp	x9, 0x103039000 <_anon.19b44b453da724831023c27de6e0b6f2.100+0xf48>
1015c4124: 910df929    	add	x9, x9, #0x37e
1015c4128: a900a6e8    	stp	x8, x9, [x23, #0x8]
1015c412c: 528004c8    	mov	w8, #0x26               ; =38
1015c4130: f9000ee8    	str	x8, [x23, #0x18]
1015c4134: 17fffb7b    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c4138: 911043f7    	add	x23, sp, #0x410
1015c413c: f100279f    	cmp	x28, #0x9
1015c4140: 54001ae0    	b.eq	0x1015c449c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1928>
1015c4144: f100239f    	cmp	x28, #0x8
1015c4148: 54001c01    	b.ne	0x1015c44c8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1954>
1015c414c: a94403e1    	ldp	x1, x0, [sp, #0x40]
1015c4150: aa1503e2    	mov	x2, x21
1015c4154: aa1303e3    	mov	x3, x19
1015c4158: 912443ff    	add	sp, sp, #0x910
1015c415c: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1015c4160: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1015c4164: a94357f6    	ldp	x22, x21, [sp, #0x30]
1015c4168: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1015c416c: a94167fa    	ldp	x26, x25, [sp, #0x10]
1015c4170: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1015c4174: 17ffd5bb    	b	0x1015b9860 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation24prepare_borrowed_strings>
1015c4178: d280000a    	mov	x10, #0x0               ; =0
1015c417c: d341fd2b    	lsr	x11, x9, #1
1015c4180: 8b0a016c    	add	x12, x11, x10
1015c4184: b86c790d    	ldr	w13, [x8, x12, lsl #2]
1015c4188: 6b1301bf    	cmp	w13, w19
1015c418c: 9a8c814a    	csel	x10, x10, x12, hi
1015c4190: cb0b0129    	sub	x9, x9, x11
1015c4194: f100053f    	cmp	x9, #0x1
1015c4198: 54ffff28    	b.hi	0x1015c417c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1608>
1015c419c: b86a7908    	ldr	w8, [x8, x10, lsl #2]
1015c41a0: 6b13011f    	cmp	w8, w19
1015c41a4: aa1603e8    	mov	x8, x22
1015c41a8: 54001c81    	b.ne	0x1015c4538 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x19c4>
1015c41ac: f941bee1    	ldr	x1, [x23, #0x378]
1015c41b0: eb13003f    	cmp	x1, x19
1015c41b4: 54015ae9    	b.ls	0x1015c6d10 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x419c>
1015c41b8: f941bae8    	ldr	x8, [x23, #0x370]
1015c41bc: 52802e09    	mov	w9, #0x170              ; =368
1015c41c0: 9ba92268    	umaddl	x8, w19, w9, x8
1015c41c4: 91057109    	add	x9, x8, #0x15c
1015c41c8: b9416d08    	ldr	w8, [x8, #0x16c]
1015c41cc: b906b3e8    	str	w8, [sp, #0x6b0]
1015c41d0: 3dc00120    	ldr	q0, [x9]
1015c41d4: 3d81abe0    	str	q0, [sp, #0x6a0]
1015c41d8: 911043e8    	add	x8, sp, #0x410
1015c41dc: 911a83e0    	add	x0, sp, #0x6a0
1015c41e0: 9441fe22    	bl	0x102643a68 <__RNvMs1_NtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact16fusion_semantics5factsNtB5_18NativeProgramFacts18control_successors>
1015c41e4: b94413e8    	ldr	w8, [sp, #0x410]
1015c41e8: 7100051f    	cmp	w8, #0x1
1015c41ec: 54000081    	b.ne	0x1015c41fc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1688>
1015c41f0: b94417e8    	ldr	w8, [sp, #0x414]
1015c41f4: 6b1a011f    	cmp	w8, w26
1015c41f8: 540000e0    	b.eq	0x1015c4214 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x16a0>
1015c41fc: b9441be8    	ldr	w8, [sp, #0x418]
1015c4200: 7100051f    	cmp	w8, #0x1
1015c4204: 54001981    	b.ne	0x1015c4534 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x19c0>
1015c4208: b9441fe8    	ldr	w8, [sp, #0x41c]
1015c420c: 6b1a011f    	cmp	w8, w26
1015c4210: 54001921    	b.ne	0x1015c4534 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x19c0>
1015c4214: aa1403e0    	mov	x0, x20
1015c4218: aa1303e1    	mov	x1, x19
1015c421c: 97fff3e3    	bl	0x1015c11a8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation15action_required>
1015c4220: 34001080    	cbz	w0, 0x1015c4430 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18bc>
1015c4224: 395182a8    	ldrb	w8, [x21, #0x460]
1015c4228: 7100051f    	cmp	w8, #0x1
1015c422c: aa1603e8    	mov	x8, x22
1015c4230: 54001841    	b.ne	0x1015c4538 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x19c4>
1015c4234: aa1403e9    	mov	x9, x20
1015c4238: f940628a    	ldr	x10, [x20, #0xc0]
1015c423c: f100095f    	cmp	x10, #0x2
1015c4240: 54001020    	b.eq	0x1015c4444 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d0>
1015c4244: 140000bd    	b	0x1015c4538 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x19c4>
1015c4248: b900011f    	str	wzr, [x8]
1015c424c: 52800189    	mov	w9, #0xc                ; =12
1015c4250: 9000d3aa    	adrp	x10, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c4254: 9102e14a    	add	x10, x10, #0xb8
1015c4258: a900a909    	stp	x9, x10, [x8, #0x8]
1015c425c: 52800349    	mov	w9, #0x1a               ; =26
1015c4260: 17fffb2f    	b	0x1015c2f1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a8>
1015c4264: b900029f    	str	wzr, [x20]
1015c4268: 52800188    	mov	w8, #0xc                ; =12
1015c426c: f000d3a9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c4270: 912c4129    	add	x9, x9, #0xb10
1015c4274: a900a688    	stp	x8, x9, [x20, #0x8]
1015c4278: 528003a8    	mov	w8, #0x1d               ; =29
1015c427c: f9000e88    	str	x8, [x20, #0x18]
1015c4280: 17fffb28    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c4284: 3dc1abe0    	ldr	q0, [sp, #0x6a0]
1015c4288: 3dc1afe1    	ldr	q1, [sp, #0x6b0]
1015c428c: 3d8107e0    	str	q0, [sp, #0x410]
1015c4290: 3d810be1    	str	q1, [sp, #0x420]
1015c4294: 3dc1b3e2    	ldr	q2, [sp, #0x6c0]
1015c4298: 3d810fe2    	str	q2, [sp, #0x430]
1015c429c: f9436be8    	ldr	x8, [sp, #0x6d0]
1015c42a0: f90223e8    	str	x8, [sp, #0x440]
1015c42a4: 3c804340    	stur	q0, [x26, #0x4]
1015c42a8: 3c814341    	stur	q1, [x26, #0x14]
1015c42ac: 3c824342    	stur	q2, [x26, #0x24]
1015c42b0: f8034348    	stur	x8, [x26, #0x34]
1015c42b4: b900027f    	str	wzr, [x19]
1015c42b8: 3dc1abe0    	ldr	q0, [sp, #0x6a0]
1015c42bc: 3dc1afe1    	ldr	q1, [sp, #0x6b0]
1015c42c0: 3c804260    	stur	q0, [x19, #0x4]
1015c42c4: 3c814261    	stur	q1, [x19, #0x14]
1015c42c8: 3dc1b3e0    	ldr	q0, [sp, #0x6c0]
1015c42cc: 3c824260    	stur	q0, [x19, #0x24]
1015c42d0: 3cc2c340    	ldur	q0, [x26, #0x2c]
1015c42d4: 3d800e60    	str	q0, [x19, #0x30]
1015c42d8: 17fffb12    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c42dc: f941ee69    	ldr	x9, [x19, #0x3d8]
1015c42e0: b40011a9    	cbz	x9, 0x1015c4514 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x19a0>
1015c42e4: f941ea69    	ldr	x9, [x19, #0x3d0]
1015c42e8: eb08013f    	cmp	x9, x8
1015c42ec: 9a8833e8    	csel	x8, xzr, x8, lo
1015c42f0: cb080128    	sub	x8, x9, x8
1015c42f4: f941e669    	ldr	x9, [x19, #0x3c8]
1015c42f8: 52800b0a    	mov	w10, #0x58              ; =88
1015c42fc: 9b0a2513    	madd	x19, x8, x10, x9
1015c4300: f9402268    	ldr	x8, [x19, #0x40]
1015c4304: eb1b011f    	cmp	x8, x27
1015c4308: 54000761    	b.ne	0x1015c43f4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1880>
1015c430c: f9402668    	ldr	x8, [x19, #0x48]
1015c4310: b5000728    	cbnz	x8, 0x1015c43f4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1880>
1015c4314: f9402a68    	ldr	x8, [x19, #0x50]
1015c4318: eb17011f    	cmp	x8, x23
1015c431c: 540006c1    	b.ne	0x1015c43f4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1880>
1015c4320: b9405281    	ldr	w1, [x20, #0x50]
1015c4324: 911a83e8    	add	x8, sp, #0x6a0
1015c4328: 9103c380    	add	x0, x28, #0xf0
1015c432c: 910be382    	add	x2, x28, #0x2f8
1015c4330: 94001a76    	bl	0x1015cad08 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
1015c4334: 3cc08340    	ldur	q0, [x26, #0x8]
1015c4338: 3cc18341    	ldur	q1, [x26, #0x18]
1015c433c: 3d814be0    	str	q0, [sp, #0x520]
1015c4340: 3d814fe1    	str	q1, [sp, #0x530]
1015c4344: 3cc28340    	ldur	q0, [x26, #0x28]
1015c4348: 3d8153e0    	str	q0, [sp, #0x540]
1015c434c: f94353e8    	ldr	x8, [sp, #0x6a0]
1015c4350: f9436fe9    	ldr	x9, [sp, #0x6d8]
1015c4354: f902abe9    	str	x9, [sp, #0x550]
1015c4358: b4003f88    	cbz	x8, 0x1015c4b48 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1fd4>
1015c435c: 3dc14be0    	ldr	q0, [sp, #0x520]
1015c4360: 3dc14fe1    	ldr	q1, [sp, #0x530]
1015c4364: 911043e9    	add	x9, sp, #0x410
1015c4368: 3c808120    	stur	q0, [x9, #0x8]
1015c436c: f942abea    	ldr	x10, [sp, #0x550]
1015c4370: 3dc153e0    	ldr	q0, [sp, #0x540]
1015c4374: 3c828120    	stur	q0, [x9, #0x28]
1015c4378: 3c818121    	stur	q1, [x9, #0x18]
1015c437c: f90227ea    	str	x10, [sp, #0x448]
1015c4380: f9020be8    	str	x8, [sp, #0x410]
1015c4384: f9420fe8    	ldr	x8, [sp, #0x418]
1015c4388: f9400669    	ldr	x9, [x19, #0x8]
1015c438c: f9400908    	ldr	x8, [x8, #0x10]
1015c4390: f9400929    	ldr	x9, [x9, #0x10]
1015c4394: eb09011f    	cmp	x8, x9
1015c4398: 54004980    	b.eq	0x1015c4cc8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2154>
1015c439c: 52800008    	mov	w8, #0x0                ; =0
1015c43a0: 52800189    	mov	w9, #0xc                ; =12
1015c43a4: 39002309    	strb	w9, [x24, #0x8]
1015c43a8: 528004e9    	mov	w9, #0x27               ; =39
1015c43ac: f9000f09    	str	x9, [x24, #0x18]
1015c43b0: f000d3a9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c43b4: 9124f529    	add	x9, x9, #0x93d
1015c43b8: 14000248    	b	0x1015c4cd8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2164>
1015c43bc: b946a7e9    	ldr	w9, [sp, #0x6a4]
1015c43c0: 9118c3ea    	add	x10, sp, #0x630
1015c43c4: 3cc88140    	ldur	q0, [x10, #0x88]
1015c43c8: 3c8182c0    	stur	q0, [x22, #0x18]
1015c43cc: 3cc98140    	ldur	q0, [x10, #0x98]
1015c43d0: 3c8282c0    	stur	q0, [x22, #0x28]
1015c43d4: 3cca8140    	ldur	q0, [x10, #0xa8]
1015c43d8: 3c8382c0    	stur	q0, [x22, #0x38]
1015c43dc: f94377eb    	ldr	x11, [sp, #0x6e8]
1015c43e0: f90026cb    	str	x11, [x22, #0x48]
1015c43e4: 3cc78140    	ldur	q0, [x10, #0x78]
1015c43e8: 290026c8    	stp	w8, w9, [x22]
1015c43ec: 3c8082c0    	stur	q0, [x22, #0x8]
1015c43f0: 17fffacc    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c43f4: b900031f    	str	wzr, [x24]
1015c43f8: 52800188    	mov	w8, #0xc                ; =12
1015c43fc: 39002308    	strb	w8, [x24, #0x8]
1015c4400: f000d3a8    	adrp	x8, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c4404: 91259108    	add	x8, x8, #0x964
1015c4408: 528006c9    	mov	w9, #0x36               ; =54
1015c440c: a9012708    	stp	x8, x9, [x24, #0x10]
1015c4410: 17fffac4    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c4414: b90002ff    	str	wzr, [x23]
1015c4418: 52800188    	mov	w8, #0xc                ; =12
1015c441c: 390022e8    	strb	w8, [x23, #0x8]
1015c4420: d000d3a8    	adrp	x8, 0x10303a000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x3b8>
1015c4424: 910bb908    	add	x8, x8, #0x2ee
1015c4428: 52800529    	mov	w9, #0x29               ; =41
1015c442c: 17fffeae    	b	0x1015c3ee4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1370>
1015c4430: aa1403e9    	mov	x9, x20
1015c4434: f9406288    	ldr	x8, [x20, #0xc0]
1015c4438: f100091f    	cmp	x8, #0x2
1015c443c: aa1603e8    	mov	x8, x22
1015c4440: 540007c1    	b.ne	0x1015c4538 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x19c4>
1015c4444: f9411129    	ldr	x9, [x9, #0x220]
1015c4448: f100093f    	cmp	x9, #0x2
1015c444c: 54000761    	b.ne	0x1015c4538 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x19c4>
1015c4450: f941aee8    	ldr	x8, [x23, #0x358]
1015c4454: b9404f01    	ldr	w1, [x24, #0x4c]
1015c4458: eb01011f    	cmp	x8, x1
1015c445c: 54017009    	b.ls	0x1015c725c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46e8>
1015c4460: f941aae8    	ldr	x8, [x23, #0x350]
1015c4464: 52802809    	mov	w9, #0x140              ; =320
1015c4468: 9ba92028    	umaddl	x8, w1, w9, x8
1015c446c: 39449109    	ldrb	w9, [x8, #0x124]
1015c4470: f9400328    	ldr	x8, [x25]
1015c4474: 71001d3f    	cmp	w9, #0x7
1015c4478: 540011e1    	b.ne	0x1015c46b4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b40>
1015c447c: b4002508    	cbz	x8, 0x1015c491c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1da8>
1015c4480: b90002df    	str	wzr, [x22]
1015c4484: 52800188    	mov	w8, #0xc                ; =12
1015c4488: 390022c8    	strb	w8, [x22, #0x8]
1015c448c: f000d3a8    	adrp	x8, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c4490: 91316108    	add	x8, x8, #0xc58
1015c4494: 52800509    	mov	w9, #0x28               ; =40
1015c4498: 1400001d    	b	0x1015c450c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1998>
1015c449c: a94403e1    	ldp	x1, x0, [sp, #0x40]
1015c44a0: aa1503e2    	mov	x2, x21
1015c44a4: aa1303e3    	mov	x3, x19
1015c44a8: 912443ff    	add	sp, sp, #0x910
1015c44ac: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1015c44b0: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1015c44b4: a94357f6    	ldp	x22, x21, [sp, #0x30]
1015c44b8: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1015c44bc: a94167fa    	ldp	x26, x25, [sp, #0x10]
1015c44c0: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1015c44c4: 17ffcba2    	b	0x1015b734c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation23borrowed_string_failure>
1015c44c8: f94023e0    	ldr	x0, [sp, #0x40]
1015c44cc: aa1503e1    	mov	x1, x21
1015c44d0: 97ffcb6f    	bl	0x1015b728c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation15borrowed_action>
1015c44d4: b4000bc0    	cbz	x0, 0x1015c464c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ad8>
1015c44d8: f94027e8    	ldr	x8, [sp, #0x48]
1015c44dc: b900011f    	str	wzr, [x8]
1015c44e0: 52800189    	mov	w9, #0xc                ; =12
1015c44e4: 39002109    	strb	w9, [x8, #0x8]
1015c44e8: f000d3a9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c44ec: 9117d129    	add	x9, x9, #0x5f4
1015c44f0: 17fffc46    	b	0x1015c3608 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa94>
1015c44f4: b90002df    	str	wzr, [x22]
1015c44f8: 52800188    	mov	w8, #0xc                ; =12
1015c44fc: 390022c8    	strb	w8, [x22, #0x8]
1015c4500: d000d3a8    	adrp	x8, 0x10303a000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x3b8>
1015c4504: 91017d08    	add	x8, x8, #0x5f
1015c4508: 52800469    	mov	w9, #0x23               ; =35
1015c450c: a90126c8    	stp	x8, x9, [x22, #0x10]
1015c4510: 17fffa84    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c4514: b900031f    	str	wzr, [x24]
1015c4518: 52800188    	mov	w8, #0xc                ; =12
1015c451c: 9000d3a9    	adrp	x9, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c4520: 9135c129    	add	x9, x9, #0xd70
1015c4524: a900a708    	stp	x8, x9, [x24, #0x8]
1015c4528: 52800288    	mov	w8, #0x14               ; =20
1015c452c: f9000f08    	str	x8, [x24, #0x18]
1015c4530: 17fffa7c    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c4534: aa1603e8    	mov	x8, x22
1015c4538: b900011f    	str	wzr, [x8]
1015c453c: 52800189    	mov	w9, #0xc                ; =12
1015c4540: 39002109    	strb	w9, [x8, #0x8]
1015c4544: f000d3a9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c4548: 91320129    	add	x9, x9, #0xc80
1015c454c: 5280050a    	mov	w10, #0x28              ; =40
1015c4550: 17fff9e3    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c4554: f94023e8    	ldr	x8, [sp, #0x40]
1015c4558: f9424908    	ldr	x8, [x8, #0x490]
1015c455c: 911a83e0    	add	x0, sp, #0x6a0
1015c4560: 910be101    	add	x1, x8, #0x2f8
1015c4564: 52800002    	mov	w2, #0x0                ; =0
1015c4568: 52800804    	mov	w4, #0x40               ; =64
1015c456c: 97ff9d2f    	bl	0x1015aba28 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
1015c4570: 395a83e8    	ldrb	w8, [sp, #0x6a0]
1015c4574: 7100391f    	cmp	w8, #0xe
1015c4578: 540013a1    	b.ne	0x1015c47ec <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c78>
1015c457c: f8786b60    	ldr	x0, [x27, x24]
1015c4580: f9401b88    	ldr	x8, [x28, #0x30]
1015c4584: f90017e8    	str	x8, [sp, #0x28]
1015c4588: eb08001f    	cmp	x0, x8
1015c458c: 54017d02    	b.hs	0x1015c752c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x49b8>
1015c4590: f940178a    	ldr	x10, [x28, #0x28]
1015c4594: b940d383    	ldr	w3, [x28, #0xd0]
1015c4598: f94023e8    	ldr	x8, [sp, #0x40]
1015c459c: f9424908    	ldr	x8, [x8, #0x490]
1015c45a0: 52800309    	mov	w9, #0x18               ; =24
1015c45a4: 9b097c09    	mul	x9, x0, x9
1015c45a8: f90013ea    	str	x10, [sp, #0x20]
1015c45ac: f8696944    	ldr	x4, [x10, x9]
1015c45b0: f941e101    	ldr	x1, [x8, #0x3c0]
1015c45b4: 911a83e0    	add	x0, sp, #0x6a0
1015c45b8: 911202e2    	add	x2, x23, #0x480
1015c45bc: 97ffa2f3    	bl	0x1015ad188 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames18take_managed_owner>
1015c45c0: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c45c4: 7100191f    	cmp	w8, #0x6
1015c45c8: 54001741    	b.ne	0x1015c48b0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1d3c>
1015c45cc: 9118c3e8    	add	x8, sp, #0x630
1015c45d0: 3cc98100    	ldur	q0, [x8, #0x98]
1015c45d4: 3c824320    	stur	q0, [x25, #0x24]
1015c45d8: 3cca8101    	ldur	q1, [x8, #0xa8]
1015c45dc: 3cc88102    	ldur	q2, [x8, #0x88]
1015c45e0: 3cc78103    	ldur	q3, [x8, #0x78]
1015c45e4: ad118be3    	stp	q3, q2, [sp, #0x230]
1015c45e8: ad1287e0    	stp	q0, q1, [sp, #0x250]
1015c45ec: 911a83f9    	add	x25, sp, #0x6a0
1015c45f0: 911a83e8    	add	x8, sp, #0x6a0
1015c45f4: f94023e0    	ldr	x0, [sp, #0x40]
1015c45f8: 52800001    	mov	w1, #0x0                ; =0
1015c45fc: 94003531    	bl	0x1015d1ac0 <__RNvMs_NtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
1015c4600: f94353e8    	ldr	x8, [sp, #0x6a0]
1015c4604: f100051f    	cmp	x8, #0x1
1015c4608: 540021c1    	b.ne	0x1015c4a40 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ecc>
1015c460c: 3cc18320    	ldur	q0, [x25, #0x18]
1015c4610: 3cc28321    	ldur	q1, [x25, #0x28]
1015c4614: 3cc38322    	ldur	q2, [x25, #0x38]
1015c4618: 3d810fe1    	str	q1, [sp, #0x430]
1015c461c: 3d8113e2    	str	q2, [sp, #0x440]
1015c4620: 3cc48323    	ldur	q3, [x25, #0x48]
1015c4624: 3d8117e3    	str	q3, [sp, #0x450]
1015c4628: 3cc08324    	ldur	q4, [x25, #0x8]
1015c462c: 3d810be0    	str	q0, [sp, #0x420]
1015c4630: 3d8107e4    	str	q4, [sp, #0x410]
1015c4634: ad010ac1    	stp	q1, q2, [x22, #0x20]
1015c4638: 3d8012c3    	str	q3, [x22, #0x40]
1015c463c: ad0002c4    	stp	q4, q0, [x22]
1015c4640: 9108c3e0    	add	x0, sp, #0x230
1015c4644: 97ff8a7f    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c4648: 17fffa36    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c464c: f942a288    	ldr	x8, [x20, #0x540]
1015c4650: eb0802bf    	cmp	x21, x8
1015c4654: 540000e2    	b.hs	0x1015c4670 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1afc>
1015c4658: f9429e88    	ldr	x8, [x20, #0x538]
1015c465c: 52800509    	mov	w9, #0x28               ; =40
1015c4660: 9b097ea9    	mul	x9, x21, x9
1015c4664: b8696908    	ldr	w8, [x8, x9]
1015c4668: 7100151f    	cmp	w8, #0x5
1015c466c: 540017e1    	b.ne	0x1015c4968 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1df4>
1015c4670: f1001b9f    	cmp	x28, #0x6
1015c4674: 54000fac    	b.gt	0x1015c4868 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1cf4>
1015c4678: f100139f    	cmp	x28, #0x4
1015c467c: 540028c0    	b.eq	0x1015c4b94 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2020>
1015c4680: f100179f    	cmp	x28, #0x5
1015c4684: 54002ca0    	b.eq	0x1015c4c18 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x20a4>
1015c4688: f1001b9f    	cmp	x28, #0x6
1015c468c: 54002b01    	b.ne	0x1015c4bec <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2078>
1015c4690: 3dc00260    	ldr	q0, [x19]
1015c4694: 3d81abe0    	str	q0, [sp, #0x6a0]
1015c4698: f9400a68    	ldr	x8, [x19, #0x10]
1015c469c: f9035be8    	str	x8, [sp, #0x6b0]
1015c46a0: 911a83e3    	add	x3, sp, #0x6a0
1015c46a4: a94403e1    	ldp	x1, x0, [sp, #0x40]
1015c46a8: aa1503e2    	mov	x2, x21
1015c46ac: 97ffdccb    	bl	0x1015bb9d8 <__RNvMNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation6window10string_mapNtB6_10Invocation25prepare_string_map_region>
1015c46b0: 17fffa1c    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c46b4: d2800009    	mov	x9, #0x0                ; =0
1015c46b8: f9419aaa    	ldr	x10, [x21, #0x330]
1015c46bc: f941e6ab    	ldr	x11, [x21, #0x3c8]
1015c46c0: f9421aac    	ldr	x12, [x21, #0x430]
1015c46c4: ad5e86a0    	ldp	q0, q1, [x21, #0x3d0]
1015c46c8: ad5f8ea2    	ldp	q2, q3, [x21, #0x3f0]
1015c46cc: 3dc106a4    	ldr	q4, [x21, #0x410]
1015c46d0: 3dc10aa5    	ldr	q5, [x21, #0x420]
1015c46d4: 5280002d    	mov	w13, #0x1               ; =1
1015c46d8: a90fa68d    	stp	x13, x9, [x20, #0xf8]
1015c46dc: f9008688    	str	x8, [x20, #0x108]
1015c46e0: ad571fe6    	ldp	q6, q7, [sp, #0x2e0]
1015c46e4: ad089e86    	stp	q6, q7, [x20, #0x110]
1015c46e8: 3dc0c3e6    	ldr	q6, [sp, #0x300]
1015c46ec: 3d804e86    	str	q6, [x20, #0x130]
1015c46f0: a9142e8a    	stp	x10, x11, [x20, #0x140]
1015c46f4: ad0a8680    	stp	q0, q1, [x20, #0x150]
1015c46f8: ad0b8e82    	stp	q2, q3, [x20, #0x170]
1015c46fc: ad0c9684    	stp	q4, q5, [x20, #0x190]
1015c4700: f900da8c    	str	x12, [x20, #0x1b0]
1015c4704: b901ba93    	str	w19, [x20, #0x1b8]
1015c4708: 4e080da0    	dup.2d	v0, x13
1015c470c: 3c8082c0    	stur	q0, [x22, #0x8]
1015c4710: 528000c8    	mov	w8, #0x6                ; =6
1015c4714: b90002c8    	str	w8, [x22]
1015c4718: 17fffa02    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c471c: 5280000b    	mov	w11, #0x0               ; =0
1015c4720: 5280000a    	mov	w10, #0x0               ; =0
1015c4724: 528000cd    	mov	w13, #0x6               ; =6
1015c4728: 92800008    	mov	x8, #-0x1               ; =-1
1015c472c: aa1703ec    	mov	x12, x23
1015c4730: 17fffc2b    	b	0x1015c37dc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc68>
1015c4734: b50000fc    	cbnz	x28, 0x1015c4750 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1bdc>
1015c4738: a9408ae1    	ldp	x1, x2, [x23, #0x8]
1015c473c: f9401be0    	ldr	x0, [sp, #0x30]
1015c4740: 94005040    	bl	0x1015d8840 <__RNvXsC_NtNtCsgDHHaSskbIF_4core5slice3cmpmNtB5_13SliceContains14slice_contains>
1015c4744: 36000060    	tbz	w0, #0x0, 0x1015c4750 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1bdc>
1015c4748: d2800008    	mov	x8, #0x0                ; =0
1015c474c: 14000018    	b	0x1015c47ac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c38>
1015c4750: f94027e8    	ldr	x8, [sp, #0x48]
1015c4754: b900011f    	str	wzr, [x8]
1015c4758: 52800189    	mov	w9, #0xc                ; =12
1015c475c: 39002109    	strb	w9, [x8, #0x8]
1015c4760: d000d3a9    	adrp	x9, 0x10303a000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x3b8>
1015c4764: 91063d29    	add	x9, x9, #0x18f
1015c4768: 5280070a    	mov	w10, #0x38              ; =56
1015c476c: 17fff95c    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c4770: f94052e9    	ldr	x9, [x23, #0xa0]
1015c4774: b40006a9    	cbz	x9, 0x1015c4848 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1cd4>
1015c4778: f9404ee8    	ldr	x8, [x23, #0x98]
1015c477c: d37be929    	lsl	x9, x9, #5
1015c4780: 14000004    	b	0x1015c4790 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c1c>
1015c4784: 91008108    	add	x8, x8, #0x20
1015c4788: f1008129    	subs	x9, x9, #0x20
1015c478c: 540005e0    	b.eq	0x1015c4848 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1cd4>
1015c4790: b940190b    	ldr	w11, [x8, #0x18]
1015c4794: f9401bea    	ldr	x10, [sp, #0x30]
1015c4798: eb0b015f    	cmp	x10, x11
1015c479c: 54ffff41    	b.ne	0x1015c4784 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c10>
1015c47a0: b9401d0a    	ldr	w10, [x8, #0x1c]
1015c47a4: eb0a039f    	cmp	x28, x10
1015c47a8: 54fffee1    	b.ne	0x1015c4784 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c10>
1015c47ac: f9031be8    	str	x8, [sp, #0x630]
1015c47b0: f9401fe9    	ldr	x9, [sp, #0x38]
1015c47b4: a94d2528    	ldp	x8, x9, [x9, #0xd0]
1015c47b8: d37ae529    	lsl	x9, x9, #6
1015c47bc: b4000e69    	cbz	x9, 0x1015c4988 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1e14>
1015c47c0: f844050a    	ldr	x10, [x8], #0x40
1015c47c4: d1010129    	sub	x9, x9, #0x40
1015c47c8: b4ffffaa    	cbz	x10, 0x1015c47bc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c48>
1015c47cc: f94027e8    	ldr	x8, [sp, #0x48]
1015c47d0: b900011f    	str	wzr, [x8]
1015c47d4: 52800189    	mov	w9, #0xc                ; =12
1015c47d8: 39002109    	strb	w9, [x8, #0x8]
1015c47dc: d000d3a9    	adrp	x9, 0x10303a000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x3b8>
1015c47e0: 91057529    	add	x9, x9, #0x15d
1015c47e4: 5280064a    	mov	w10, #0x32              ; =50
1015c47e8: 17fff93d    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c47ec: 3dc1abe0    	ldr	q0, [sp, #0x6a0]
1015c47f0: 3dc1afe1    	ldr	q1, [sp, #0x6b0]
1015c47f4: 3d8107e0    	str	q0, [sp, #0x410]
1015c47f8: 3d810be1    	str	q1, [sp, #0x420]
1015c47fc: 3dc1b3e2    	ldr	q2, [sp, #0x6c0]
1015c4800: 3d810fe2    	str	q2, [sp, #0x430]
1015c4804: f9436be8    	ldr	x8, [sp, #0x6d0]
1015c4808: f90223e8    	str	x8, [sp, #0x440]
1015c480c: 9118c3e9    	add	x9, sp, #0x630
1015c4810: 3c874120    	stur	q0, [x9, #0x74]
1015c4814: 3c884121    	stur	q1, [x9, #0x84]
1015c4818: 3c894122    	stur	q2, [x9, #0x94]
1015c481c: f80a4128    	stur	x8, [x9, #0xa4]
1015c4820: b90002df    	str	wzr, [x22]
1015c4824: 3dc1abe0    	ldr	q0, [sp, #0x6a0]
1015c4828: 3dc1afe1    	ldr	q1, [sp, #0x6b0]
1015c482c: 3c8042c0    	stur	q0, [x22, #0x4]
1015c4830: 3c8142c1    	stur	q1, [x22, #0x14]
1015c4834: 3dc1b3e0    	ldr	q0, [sp, #0x6c0]
1015c4838: 3c8242c0    	stur	q0, [x22, #0x24]
1015c483c: 3cc9c120    	ldur	q0, [x9, #0x9c]
1015c4840: 3d800ec0    	str	q0, [x22, #0x30]
1015c4844: 17fff9b7    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c4848: f94027e8    	ldr	x8, [sp, #0x48]
1015c484c: b900011f    	str	wzr, [x8]
1015c4850: 52800189    	mov	w9, #0xc                ; =12
1015c4854: f000d38a    	adrp	x10, 0x103037000 <_anon.496f237bd13ceadd644cb7ae086b3546.176+0x13b>
1015c4858: 913dc94a    	add	x10, x10, #0xf72
1015c485c: a900a909    	stp	x9, x10, [x8, #0x8]
1015c4860: 52800629    	mov	w9, #0x31               ; =49
1015c4864: 17fff9ae    	b	0x1015c2f1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a8>
1015c4868: f1001f9f    	cmp	x28, #0x7
1015c486c: 54001aa0    	b.eq	0x1015c4bc0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x204c>
1015c4870: f100439f    	cmp	x28, #0x10
1015c4874: 54001e80    	b.eq	0x1015c4c44 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x20d0>
1015c4878: f100479f    	cmp	x28, #0x11
1015c487c: 54001b81    	b.ne	0x1015c4bec <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2078>
1015c4880: a9409664    	ldp	x4, x5, [x19, #0x8]
1015c4884: f9400263    	ldr	x3, [x19]
1015c4888: a94403e1    	ldp	x1, x0, [sp, #0x40]
1015c488c: aa1503e2    	mov	x2, x21
1015c4890: 912443ff    	add	sp, sp, #0x910
1015c4894: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1015c4898: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1015c489c: a94357f6    	ldp	x22, x21, [sp, #0x30]
1015c48a0: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1015c48a4: a94167fa    	ldp	x26, x25, [sp, #0x10]
1015c48a8: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1015c48ac: 14003c98    	b	0x1015d3b0c <__RNvMs_NtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation5joins6mappedNtB8_10Invocation21finish_join_map_chunk>
1015c48b0: 9118c3e9    	add	x9, sp, #0x630
1015c48b4: 3cc84120    	ldur	q0, [x9, #0x84]
1015c48b8: 3cc94121    	ldur	q1, [x9, #0x94]
1015c48bc: 3cca4122    	ldur	q2, [x9, #0xa4]
1015c48c0: 3d810fe1    	str	q1, [sp, #0x430]
1015c48c4: 3d8113e2    	str	q2, [sp, #0x440]
1015c48c8: b946e7ea    	ldr	w10, [sp, #0x6e4]
1015c48cc: b90453ea    	str	w10, [sp, #0x450]
1015c48d0: 3cc74123    	ldur	q3, [x9, #0x74]
1015c48d4: 3d810be0    	str	q0, [sp, #0x420]
1015c48d8: 3d8107e3    	str	q3, [sp, #0x410]
1015c48dc: f94377e9    	ldr	x9, [sp, #0x6e8]
1015c48e0: 3c8142c0    	stur	q0, [x22, #0x14]
1015c48e4: 3c8242c1    	stur	q1, [x22, #0x24]
1015c48e8: 3c8342c2    	stur	q2, [x22, #0x34]
1015c48ec: b90046ca    	str	w10, [x22, #0x44]
1015c48f0: 3c8042c3    	stur	q3, [x22, #0x4]
1015c48f4: b90002c8    	str	w8, [x22]
1015c48f8: f90026c9    	str	x9, [x22, #0x48]
1015c48fc: 17fff989    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c4900: b900031f    	str	wzr, [x24]
1015c4904: 52800188    	mov	w8, #0xc                ; =12
1015c4908: 39002308    	strb	w8, [x24, #0x8]
1015c490c: f000d3a8    	adrp	x8, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c4910: 91266908    	add	x8, x8, #0x99a
1015c4914: 52800489    	mov	w9, #0x24               ; =36
1015c4918: 17fffebd    	b	0x1015c440c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1898>
1015c491c: 911a83e8    	add	x8, sp, #0x6a0
1015c4920: 9103c2a0    	add	x0, x21, #0xf0
1015c4924: 910be2a2    	add	x2, x21, #0x2f8
1015c4928: 940018f8    	bl	0x1015cad08 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
1015c492c: f94353e9    	ldr	x9, [sp, #0x6a0]
1015c4930: f94357e8    	ldr	x8, [sp, #0x6a8]
1015c4934: 3dc1afe0    	ldr	q0, [sp, #0x6b0]
1015c4938: 3dc1b3e1    	ldr	q1, [sp, #0x6c0]
1015c493c: 3d8107e0    	str	q0, [sp, #0x410]
1015c4940: 3d810be1    	str	q1, [sp, #0x420]
1015c4944: 3dc1b7e0    	ldr	q0, [sp, #0x6d0]
1015c4948: 3d810fe0    	str	q0, [sp, #0x430]
1015c494c: b4001929    	cbz	x9, 0x1015c4c70 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x20fc>
1015c4950: 3dc107e0    	ldr	q0, [sp, #0x410]
1015c4954: 3dc10be1    	ldr	q1, [sp, #0x420]
1015c4958: ad1707e0    	stp	q0, q1, [sp, #0x2e0]
1015c495c: 3dc10fe0    	ldr	q0, [sp, #0x430]
1015c4960: 3d80c3e0    	str	q0, [sp, #0x300]
1015c4964: 17ffff55    	b	0x1015c46b8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b44>
1015c4968: f94027e8    	ldr	x8, [sp, #0x48]
1015c496c: b900011f    	str	wzr, [x8]
1015c4970: 52800189    	mov	w9, #0xc                ; =12
1015c4974: 39002109    	strb	w9, [x8, #0x8]
1015c4978: f000d3a9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c497c: 91213129    	add	x9, x9, #0x84c
1015c4980: 5280048a    	mov	w10, #0x24              ; =36
1015c4984: 17fff8d6    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c4988: 9118c3e8    	add	x8, sp, #0x630
1015c498c: f9020be8    	str	x8, [sp, #0x410]
1015c4990: f9020ff8    	str	x24, [sp, #0x418]
1015c4994: f94023f3    	ldr	x19, [sp, #0x40]
1015c4998: f90213f3    	str	x19, [sp, #0x420]
1015c499c: f94017e8    	ldr	x8, [sp, #0x28]
1015c49a0: f90217e8    	str	x8, [sp, #0x428]
1015c49a4: f9021bf5    	str	x21, [sp, #0x430]
1015c49a8: 911a83e0    	add	x0, sp, #0x6a0
1015c49ac: 911043e1    	add	x1, sp, #0x410
1015c49b0: 97ff983f    	bl	0x1015aaaac <__RNCNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16numeric_segmentsNtB6_10Invocation19end_numeric_segments4_0Be_>
1015c49b4: f9424a68    	ldr	x8, [x19, #0x490]
1015c49b8: f9406d02    	ldr	x2, [x8, #0xd8]
1015c49bc: f94022e1    	ldr	x1, [x23, #0x40]
1015c49c0: eb02003f    	cmp	x1, x2
1015c49c4: 5400e668    	b.hi	0x1015c6690 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3b1c>
1015c49c8: f9406900    	ldr	x0, [x8, #0xd0]
1015c49cc: f9020bff    	str	xzr, [sp, #0x410]
1015c49d0: 911043e2    	add	x2, sp, #0x410
1015c49d4: 97fd9c2e    	bl	0x10152ba8c <__RNvXNtNtCsgDHHaSskbIF_4core5slice10specializeSINtNtB6_6option6OptionNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEINtB2_8SpecFillBI_E9spec_fillCs29QkOtpKx6e_8mech_gpu>
1015c49d8: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c49dc: 7100191f    	cmp	w8, #0x6
1015c49e0: 540015a1    	b.ne	0x1015c4c94 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2120>
1015c49e4: f94023e9    	ldr	x9, [sp, #0x40]
1015c49e8: f9424928    	ldr	x8, [x9, #0x490]
1015c49ec: b903411f    	str	wzr, [x8, #0x340]
1015c49f0: f942492a    	ldr	x10, [x9, #0x490]
1015c49f4: 52800028    	mov	w8, #0x1                ; =1
1015c49f8: b902f148    	str	w8, [x10, #0x2f0]
1015c49fc: f9401be8    	ldr	x8, [sp, #0x30]
1015c4a00: b902f548    	str	w8, [x10, #0x2f4]
1015c4a04: f9424928    	ldr	x8, [x9, #0x490]
1015c4a08: f1000a9f    	cmp	x20, #0x2
1015c4a0c: 1a9f07e9    	cset	w9, ne
1015c4a10: 39118109    	strb	w9, [x8, #0x460]
1015c4a14: f94027e8    	ldr	x8, [sp, #0x48]
1015c4a18: f900051f    	str	xzr, [x8, #0x8]
1015c4a1c: 528000c9    	mov	w9, #0x6                ; =6
1015c4a20: b9000109    	str	w9, [x8]
1015c4a24: 17fff93f    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c4a28: d0012060    	adrp	x0, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c4a2c: 91134000    	add	x0, x0, #0x4d0
1015c4a30: 9460bac5    	bl	0x102df3544 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1015c4a34: d0012060    	adrp	x0, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c4a38: 9113a000    	add	x0, x0, #0x4e8
1015c4a3c: 9460bac2    	bl	0x102df3544 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1015c4a40: 3cc48320    	ldur	q0, [x25, #0x48]
1015c4a44: 3cc58321    	ldur	q1, [x25, #0x58]
1015c4a48: 3d8117e0    	str	q0, [sp, #0x450]
1015c4a4c: 3d811be1    	str	q1, [sp, #0x460]
1015c4a50: f8468328    	ldur	x8, [x25, #0x68]
1015c4a54: f9023be8    	str	x8, [sp, #0x470]
1015c4a58: 3cc08322    	ldur	q2, [x25, #0x8]
1015c4a5c: 3cc18323    	ldur	q3, [x25, #0x18]
1015c4a60: 3d8107e2    	str	q2, [sp, #0x410]
1015c4a64: 3d810be3    	str	q3, [sp, #0x420]
1015c4a68: 3cc38324    	ldur	q4, [x25, #0x38]
1015c4a6c: 3cc28325    	ldur	q5, [x25, #0x28]
1015c4a70: ad138fe2    	stp	q2, q3, [sp, #0x270]
1015c4a74: ad1493e5    	stp	q5, q4, [sp, #0x290]
1015c4a78: f9016be8    	str	x8, [sp, #0x2d0]
1015c4a7c: ad1587e0    	stp	q0, q1, [sp, #0x2b0]
1015c4a80: b9400368    	ldr	w8, [x27]
1015c4a84: 7100191f    	cmp	w8, #0x6
1015c4a88: 54001321    	b.ne	0x1015c4cec <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2178>
1015c4a8c: ad5187e0    	ldp	q0, q1, [sp, #0x230]
1015c4a90: 3d8107e0    	str	q0, [sp, #0x410]
1015c4a94: 3d810be1    	str	q1, [sp, #0x420]
1015c4a98: ad5287e0    	ldp	q0, q1, [sp, #0x250]
1015c4a9c: 3d810fe0    	str	q0, [sp, #0x430]
1015c4aa0: 3d8113e1    	str	q1, [sp, #0x440]
1015c4aa4: f94023e8    	ldr	x8, [sp, #0x40]
1015c4aa8: ad440500    	ldp	q0, q1, [x8, #0x80]
1015c4aac: 3d81cbe0    	str	q0, [sp, #0x720]
1015c4ab0: 3d81cfe1    	str	q1, [sp, #0x730]
1015c4ab4: f9405109    	ldr	x9, [x8, #0xa0]
1015c4ab8: f903a3e9    	str	x9, [sp, #0x740]
1015c4abc: ad420500    	ldp	q0, q1, [x8, #0x40]
1015c4ac0: 3d81bbe0    	str	q0, [sp, #0x6e0]
1015c4ac4: 3d81bfe1    	str	q1, [sp, #0x6f0]
1015c4ac8: ad430101    	ldp	q1, q0, [x8, #0x60]
1015c4acc: 3d81c7e0    	str	q0, [sp, #0x710]
1015c4ad0: 3d81c3e1    	str	q1, [sp, #0x700]
1015c4ad4: ad400500    	ldp	q0, q1, [x8]
1015c4ad8: 3d81abe0    	str	q0, [sp, #0x6a0]
1015c4adc: 3d81afe1    	str	q1, [sp, #0x6b0]
1015c4ae0: ad410101    	ldp	q1, q0, [x8, #0x20]
1015c4ae4: 3d81b7e0    	str	q0, [sp, #0x6d0]
1015c4ae8: 3d81b3e1    	str	q1, [sp, #0x6c0]
1015c4aec: f9424909    	ldr	x9, [x8, #0x490]
1015c4af0: 52800039    	mov	w25, #0x1               ; =1
1015c4af4: 9118c3e8    	add	x8, sp, #0x630
1015c4af8: 911043e1    	add	x1, sp, #0x410
1015c4afc: 911a83e4    	add	x4, sp, #0x6a0
1015c4b00: 910ee125    	add	x5, x9, #0x3b8
1015c4b04: 9109c3e6    	add	x6, sp, #0x270
1015c4b08: f9401be0    	ldr	x0, [sp, #0x30]
1015c4b0c: f94027e2    	ldr	x2, [sp, #0x48]
1015c4b10: 52800023    	mov	w3, #0x1                ; =1
1015c4b14: 944ef651    	bl	0x102982458 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall15unsigned_buffer>
1015c4b18: f9431be8    	ldr	x8, [sp, #0x630]
1015c4b1c: b4002e28    	cbz	x8, 0x1015c50e0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x256c>
1015c4b20: 3dc18fe0    	ldr	q0, [sp, #0x630]
1015c4b24: 3dc193e1    	ldr	q1, [sp, #0x640]
1015c4b28: ad1707e0    	stp	q0, q1, [sp, #0x2e0]
1015c4b2c: 3dc197e2    	ldr	q2, [sp, #0x650]
1015c4b30: 3dc19be3    	ldr	q3, [sp, #0x660]
1015c4b34: ad180fe2    	stp	q2, q3, [sp, #0x300]
1015c4b38: 390c83f9    	strb	w25, [sp, #0x320]
1015c4b3c: ad1987e0    	stp	q0, q1, [sp, #0x330]
1015c4b40: ad1a8fe2    	stp	q2, q3, [sp, #0x350]
1015c4b44: 14000094    	b	0x1015c4d94 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2220>
1015c4b48: 3dc14be0    	ldr	q0, [sp, #0x520]
1015c4b4c: 3dc14fe1    	ldr	q1, [sp, #0x530]
1015c4b50: 3c804340    	stur	q0, [x26, #0x4]
1015c4b54: 3c814341    	stur	q1, [x26, #0x14]
1015c4b58: 3dc153e0    	ldr	q0, [sp, #0x540]
1015c4b5c: 3c824340    	stur	q0, [x26, #0x24]
1015c4b60: f942abe8    	ldr	x8, [sp, #0x550]
1015c4b64: f8034348    	stur	x8, [x26, #0x34]
1015c4b68: 3dc1abe0    	ldr	q0, [sp, #0x6a0]
1015c4b6c: 3dc1afe1    	ldr	q1, [sp, #0x6b0]
1015c4b70: 3c804300    	stur	q0, [x24, #0x4]
1015c4b74: 52800048    	mov	w8, #0x2                ; =2
1015c4b78: b9000308    	str	w8, [x24]
1015c4b7c: 3c814301    	stur	q1, [x24, #0x14]
1015c4b80: 3dc1b3e0    	ldr	q0, [sp, #0x6c0]
1015c4b84: 3c824300    	stur	q0, [x24, #0x24]
1015c4b88: 3cc2c340    	ldur	q0, [x26, #0x2c]
1015c4b8c: 3d800f00    	str	q0, [x24, #0x30]
1015c4b90: 17fff8e4    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c4b94: a94403e1    	ldp	x1, x0, [sp, #0x40]
1015c4b98: aa1503e2    	mov	x2, x21
1015c4b9c: aa1303e3    	mov	x3, x19
1015c4ba0: 912443ff    	add	sp, sp, #0x910
1015c4ba4: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1015c4ba8: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1015c4bac: a94357f6    	ldp	x22, x21, [sp, #0x30]
1015c4bb0: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1015c4bb4: a94167fa    	ldp	x26, x25, [sp, #0x10]
1015c4bb8: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1015c4bbc: 17ffc7ad    	b	0x1015b6a70 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation6windowNtB4_10Invocation21prepare_window_region>
1015c4bc0: a94403e1    	ldp	x1, x0, [sp, #0x40]
1015c4bc4: aa1503e2    	mov	x2, x21
1015c4bc8: aa1303e3    	mov	x3, x19
1015c4bcc: 912443ff    	add	sp, sp, #0x910
1015c4bd0: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1015c4bd4: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1015c4bd8: a94357f6    	ldp	x22, x21, [sp, #0x30]
1015c4bdc: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1015c4be0: a94167fa    	ldp	x26, x25, [sp, #0x10]
1015c4be4: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1015c4be8: 17ffda92    	b	0x1015bb630 <__RNvMNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation6window10string_mapNtB6_10Invocation24finish_string_map_region>
1015c4bec: f94023e8    	ldr	x8, [sp, #0x40]
1015c4bf0: f9405508    	ldr	x8, [x8, #0xa8]
1015c4bf4: b4002168    	cbz	x8, 0x1015c5020 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x24ac>
1015c4bf8: f94027e8    	ldr	x8, [sp, #0x48]
1015c4bfc: b900011f    	str	wzr, [x8]
1015c4c00: 52800189    	mov	w9, #0xc                ; =12
1015c4c04: 39002109    	strb	w9, [x8, #0x8]
1015c4c08: f000d3a9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c4c0c: 91188929    	add	x9, x9, #0x622
1015c4c10: 528005aa    	mov	w10, #0x2d              ; =45
1015c4c14: 17fff832    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c4c18: a94403e1    	ldp	x1, x0, [sp, #0x40]
1015c4c1c: aa1503e2    	mov	x2, x21
1015c4c20: aa1303e3    	mov	x3, x19
1015c4c24: 912443ff    	add	sp, sp, #0x910
1015c4c28: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1015c4c2c: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1015c4c30: a94357f6    	ldp	x22, x21, [sp, #0x30]
1015c4c34: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1015c4c38: a94167fa    	ldp	x26, x25, [sp, #0x10]
1015c4c3c: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1015c4c40: 17ffc60d    	b	0x1015b6474 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation6windowNtB4_10Invocation20finish_window_region>
1015c4c44: a94403e1    	ldp	x1, x0, [sp, #0x40]
1015c4c48: aa1503e2    	mov	x2, x21
1015c4c4c: aa1303e3    	mov	x3, x19
1015c4c50: 912443ff    	add	sp, sp, #0x910
1015c4c54: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1015c4c58: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1015c4c5c: a94357f6    	ldp	x22, x21, [sp, #0x30]
1015c4c60: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1015c4c64: a94167fa    	ldp	x26, x25, [sp, #0x10]
1015c4c68: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1015c4c6c: 14003c80    	b	0x1015d3e6c <__RNvMs_NtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation5joins6mappedNtB8_10Invocation22prepare_join_map_chunk>
1015c4c70: 3dc107e0    	ldr	q0, [sp, #0x410]
1015c4c74: 3dc10be1    	ldr	q1, [sp, #0x420]
1015c4c78: ad0086c0    	stp	q0, q1, [x22, #0x10]
1015c4c7c: 3dc10fe0    	ldr	q0, [sp, #0x430]
1015c4c80: 3d800ec0    	str	q0, [x22, #0x30]
1015c4c84: 52800049    	mov	w9, #0x2                ; =2
1015c4c88: b90002c9    	str	w9, [x22]
1015c4c8c: f90006c8    	str	x8, [x22, #0x8]
1015c4c90: 17fff8a4    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c4c94: 3cc14340    	ldur	q0, [x26, #0x14]
1015c4c98: f94027e9    	ldr	x9, [sp, #0x48]
1015c4c9c: 3c814120    	stur	q0, [x9, #0x14]
1015c4ca0: 3cc24340    	ldur	q0, [x26, #0x24]
1015c4ca4: 3c824120    	stur	q0, [x9, #0x24]
1015c4ca8: 3cc34340    	ldur	q0, [x26, #0x34]
1015c4cac: 3c834120    	stur	q0, [x9, #0x34]
1015c4cb0: 3dc1bbe0    	ldr	q0, [sp, #0x6e0]
1015c4cb4: 3d801120    	str	q0, [x9, #0x40]
1015c4cb8: 3cc04340    	ldur	q0, [x26, #0x4]
1015c4cbc: 3c804120    	stur	q0, [x9, #0x4]
1015c4cc0: b9000128    	str	w8, [x9]
1015c4cc4: 17fff897    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c4cc8: 52800028    	mov	w8, #0x1                ; =1
1015c4ccc: f9000708    	str	x8, [x24, #0x8]
1015c4cd0: 528000c8    	mov	w8, #0x6                ; =6
1015c4cd4: 52800049    	mov	w9, #0x2                ; =2
1015c4cd8: f9000b09    	str	x9, [x24, #0x10]
1015c4cdc: b9000308    	str	w8, [x24]
1015c4ce0: 911043e0    	add	x0, sp, #0x410
1015c4ce4: 97ff88d7    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c4ce8: 17fff88e    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c4cec: ad5187e0    	ldp	q0, q1, [sp, #0x230]
1015c4cf0: 3d8107e0    	str	q0, [sp, #0x410]
1015c4cf4: 3d810be1    	str	q1, [sp, #0x420]
1015c4cf8: ad5287e0    	ldp	q0, q1, [sp, #0x250]
1015c4cfc: 3d810fe0    	str	q0, [sp, #0x430]
1015c4d00: 3d8113e1    	str	q1, [sp, #0x440]
1015c4d04: f94023e8    	ldr	x8, [sp, #0x40]
1015c4d08: ad440500    	ldp	q0, q1, [x8, #0x80]
1015c4d0c: 3d81cbe0    	str	q0, [sp, #0x720]
1015c4d10: 3d81cfe1    	str	q1, [sp, #0x730]
1015c4d14: f9405109    	ldr	x9, [x8, #0xa0]
1015c4d18: f903a3e9    	str	x9, [sp, #0x740]
1015c4d1c: ad420500    	ldp	q0, q1, [x8, #0x40]
1015c4d20: 3d81bbe0    	str	q0, [sp, #0x6e0]
1015c4d24: 3d81bfe1    	str	q1, [sp, #0x6f0]
1015c4d28: ad430101    	ldp	q1, q0, [x8, #0x60]
1015c4d2c: 3d81c7e0    	str	q0, [sp, #0x710]
1015c4d30: 3d81c3e1    	str	q1, [sp, #0x700]
1015c4d34: ad400500    	ldp	q0, q1, [x8]
1015c4d38: 3d81abe0    	str	q0, [sp, #0x6a0]
1015c4d3c: 3d81afe1    	str	q1, [sp, #0x6b0]
1015c4d40: ad410101    	ldp	q1, q0, [x8, #0x20]
1015c4d44: 3d81b7e0    	str	q0, [sp, #0x6d0]
1015c4d48: 3d81b3e1    	str	q1, [sp, #0x6c0]
1015c4d4c: f9424909    	ldr	x9, [x8, #0x490]
1015c4d50: 910b83e8    	add	x8, sp, #0x2e0
1015c4d54: 911043e1    	add	x1, sp, #0x410
1015c4d58: 911a83e5    	add	x5, sp, #0x6a0
1015c4d5c: 910ee126    	add	x6, x9, #0x3b8
1015c4d60: 9109c3e7    	add	x7, sp, #0x270
1015c4d64: a9430be0    	ldp	x0, x2, [sp, #0x30]
1015c4d68: f94027e3    	ldr	x3, [sp, #0x48]
1015c4d6c: 52800024    	mov	w4, #0x1                ; =1
1015c4d70: 944ef4c9    	bl	0x102982094 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall23unsigned_matrix_replace>
1015c4d74: 394c83e8    	ldrb	w8, [sp, #0x320]
1015c4d78: 7100091f    	cmp	w8, #0x2
1015c4d7c: 54001c20    	b.eq	0x1015c5100 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x258c>
1015c4d80: ad5707e0    	ldp	q0, q1, [sp, #0x2e0]
1015c4d84: ad1987e0    	stp	q0, q1, [sp, #0x330]
1015c4d88: ad5807e0    	ldp	q0, q1, [sp, #0x300]
1015c4d8c: ad1a87e0    	stp	q0, q1, [sp, #0x350]
1015c4d90: 36002c68    	tbz	w8, #0x0, 0x1015c531c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x27a8>
1015c4d94: f94023e8    	ldr	x8, [sp, #0x40]
1015c4d98: f9424909    	ldr	x9, [x8, #0x490]
1015c4d9c: 912003e8    	add	x8, sp, #0x800
1015c4da0: 910ee120    	add	x0, x9, #0x3b8
1015c4da4: 943552e4    	bl	0x102319934 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget13memory_budget>
1015c4da8: f942eae8    	ldr	x8, [x23, #0x5d0]
1015c4dac: b140051f    	cmn	x8, #0x1, lsl #12       ; =0x1000
1015c4db0: 5400ea22    	b.hs	0x1015c6af4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3f80>
1015c4db4: 91400517    	add	x23, x8, #0x1, lsl #12  ; =0x1000
1015c4db8: d37cfee8    	lsr	x8, x23, #60
1015c4dbc: b500eac8    	cbnz	x8, 0x1015c6b14 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3fa0>
1015c4dc0: f94023e8    	ldr	x8, [sp, #0x40]
1015c4dc4: f9424908    	ldr	x8, [x8, #0x490]
1015c4dc8: d37ceee4    	lsl	x4, x23, #4
1015c4dcc: 52800039    	mov	w25, #0x1               ; =1
1015c4dd0: 911a83e0    	add	x0, sp, #0x6a0
1015c4dd4: 910be101    	add	x1, x8, #0x2f8
1015c4dd8: 52800002    	mov	w2, #0x0                ; =0
1015c4ddc: 97ff9b13    	bl	0x1015aba28 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
1015c4de0: 395a83e8    	ldrb	w8, [sp, #0x6a0]
1015c4de4: 7100391f    	cmp	w8, #0xe
1015c4de8: 54001501    	b.ne	0x1015c5088 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2514>
1015c4dec: 911a83e8    	add	x8, sp, #0x6a0
1015c4df0: 912003e0    	add	x0, sp, #0x800
1015c4df4: aa1703e1    	mov	x1, x23
1015c4df8: 945c886f    	bl	0x102ce6fb4 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
1015c4dfc: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c4e00: 7100691f    	cmp	w8, #0x1a
1015c4e04: 540029c1    	b.ne	0x1015c533c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x27c8>
1015c4e08: 9118c3e8    	add	x8, sp, #0x630
1015c4e0c: 3cc88100    	ldur	q0, [x8, #0x88]
1015c4e10: 3cc78101    	ldur	q1, [x8, #0x78]
1015c4e14: 3d820be1    	str	q1, [sp, #0x820]
1015c4e18: 3d820fe0    	str	q0, [sp, #0x830]
1015c4e1c: f9419be8    	ldr	x8, [sp, #0x330]
1015c4e20: 91004100    	add	x0, x8, #0x10
1015c4e24: 97fd3e96    	bl	0x10151487c <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSyENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs29QkOtpKx6e_8mech_gpu>
1015c4e28: aa0003f7    	mov	x23, x0
1015c4e2c: aa0103f9    	mov	x25, x1
1015c4e30: ad5987e0    	ldp	q0, q1, [sp, #0x330]
1015c4e34: 3d818fe0    	str	q0, [sp, #0x630]
1015c4e38: 3d8193e1    	str	q1, [sp, #0x640]
1015c4e3c: ad5a87e0    	ldp	q0, q1, [sp, #0x350]
1015c4e40: 3d8197e0    	str	q0, [sp, #0x650]
1015c4e44: 3d819be1    	str	q1, [sp, #0x660]
1015c4e48: 911a83e8    	add	x8, sp, #0x6a0
1015c4e4c: 9118c3e0    	add	x0, sp, #0x630
1015c4e50: 912003e1    	add	x1, sp, #0x800
1015c4e54: 945cadd2    	bl	0x102cf059c <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrixNtB6_5Value30try_into_owned_unsigned_matrix>
1015c4e58: f94353e8    	ldr	x8, [sp, #0x6a0]
1015c4e5c: 9118c3e9    	add	x9, sp, #0x630
1015c4e60: 3cc78120    	ldur	q0, [x9, #0x78]
1015c4e64: 3cc88121    	ldur	q1, [x9, #0x88]
1015c4e68: ad1f07e0    	stp	q0, q1, [sp, #0x3e0]
1015c4e6c: 3cc98120    	ldur	q0, [x9, #0x98]
1015c4e70: 3d8103e0    	str	q0, [sp, #0x400]
1015c4e74: f100151f    	cmp	x8, #0x5
1015c4e78: 54003281    	b.ne	0x1015c54c8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2954>
1015c4e7c: ad5f07e0    	ldp	q0, q1, [sp, #0x3e0]
1015c4e80: 911ea3e8    	add	x8, sp, #0x7a8
1015c4e84: 3c807100    	stur	q0, [x8, #0x7]
1015c4e88: 3c817101    	stur	q1, [x8, #0x17]
1015c4e8c: 3dc103e0    	ldr	q0, [sp, #0x400]
1015c4e90: 3c827100    	stur	q0, [x8, #0x27]
1015c4e94: ad400500    	ldp	q0, q1, [x8]
1015c4e98: 3c8092c0    	stur	q0, [x22, #0x9]
1015c4e9c: b90002df    	str	wzr, [x22]
1015c4ea0: 528001a9    	mov	w9, #0xd                ; =13
1015c4ea4: 390022c9    	strb	w9, [x22, #0x8]
1015c4ea8: 3c8192c1    	stur	q1, [x22, #0x19]
1015c4eac: 3dc00900    	ldr	q0, [x8, #0x20]
1015c4eb0: 3c8292c0    	stur	q0, [x22, #0x29]
1015c4eb4: f842f108    	ldur	x8, [x8, #0x2f]
1015c4eb8: f9001ec8    	str	x8, [x22, #0x38]
1015c4ebc: 140003de    	b	0x1015c5e34 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x32c0>
1015c4ec0: b84111a1    	ldur	w1, [x13, #0x11]
1015c4ec4: b8009341    	stur	w1, [x26, #0x9]
1015c4ec8: b84141a1    	ldur	w1, [x13, #0x14]
1015c4ecc: b906afe1    	str	w1, [sp, #0x6ac]
1015c4ed0: b906a3e0    	str	w0, [sp, #0x6a0]
1015c4ed4: b906a7f1    	str	w17, [sp, #0x6a4]
1015c4ed8: 391aa3f0    	strb	w16, [sp, #0x6a8]
1015c4edc: f9035bef    	str	x15, [sp, #0x6b0]
1015c4ee0: f9035fee    	str	x14, [sp, #0x6b8]
1015c4ee4: 3cc281a0    	ldur	q0, [x13, #0x28]
1015c4ee8: 3cc381a1    	ldur	q1, [x13, #0x38]
1015c4eec: 3d81b7e1    	str	q1, [sp, #0x6d0]
1015c4ef0: 3d81b3e0    	str	q0, [sp, #0x6c0]
1015c4ef4: 3cc481a0    	ldur	q0, [x13, #0x48]
1015c4ef8: 3cc581a1    	ldur	q1, [x13, #0x58]
1015c4efc: 3cc681a2    	ldur	q2, [x13, #0x68]
1015c4f00: 3cc781a3    	ldur	q3, [x13, #0x78]
1015c4f04: 3cc881a4    	ldur	q4, [x13, #0x88]
1015c4f08: 3cc981a5    	ldur	q5, [x13, #0x98]
1015c4f0c: 3cca81a6    	ldur	q6, [x13, #0xa8]
1015c4f10: 3ccb81a7    	ldur	q7, [x13, #0xb8]
1015c4f14: 3d81d7e7    	str	q7, [sp, #0x750]
1015c4f18: 3d81d3e6    	str	q6, [sp, #0x740]
1015c4f1c: 3d81cfe5    	str	q5, [sp, #0x730]
1015c4f20: 3d81cbe4    	str	q4, [sp, #0x720]
1015c4f24: 3d81c7e3    	str	q3, [sp, #0x710]
1015c4f28: 3d81c3e2    	str	q2, [sp, #0x700]
1015c4f2c: 3d81bbe0    	str	q0, [sp, #0x6e0]
1015c4f30: 3d81bfe1    	str	q1, [sp, #0x6f0]
1015c4f34: f940258d    	ldr	x13, [x12, #0x48]
1015c4f38: b10005bf    	cmn	x13, #0x1
1015c4f3c: 5400dce0    	b.eq	0x1015c6ad8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3f64>
1015c4f40: 910005ad    	add	x13, x13, #0x1
1015c4f44: f900258d    	str	x13, [x12, #0x48]
1015c4f48: f940298c    	ldr	x12, [x12, #0x50]
1015c4f4c: eb0c01bf    	cmp	x13, x12
1015c4f50: 540008a1    	b.ne	0x1015c5064 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x24f0>
1015c4f54: 9100054c    	add	x12, x10, #0x1
1015c4f58: eb08019f    	cmp	x12, x8
1015c4f5c: 9a8833e8    	csel	x8, xzr, x8, lo
1015c4f60: cb080188    	sub	x8, x12, x8
1015c4f64: f901eaa8    	str	x8, [x21, #0x3d0]
1015c4f68: d100053a    	sub	x26, x9, #0x1
1015c4f6c: f901eeba    	str	x26, [x21, #0x3d8]
1015c4f70: 52800b08    	mov	w8, #0x58               ; =88
1015c4f74: 9b082d48    	madd	x8, x10, x8, x11
1015c4f78: ad400101    	ldp	q1, q0, [x8]
1015c4f7c: 3d8107e1    	str	q1, [sp, #0x410]
1015c4f80: 3d810be0    	str	q0, [sp, #0x420]
1015c4f84: ad418101    	ldp	q1, q0, [x8, #0x30]
1015c4f88: f9402909    	ldr	x9, [x8, #0x50]
1015c4f8c: 3dc00902    	ldr	q2, [x8, #0x20]
1015c4f90: f90233e9    	str	x9, [sp, #0x460]
1015c4f94: 3d8117e0    	str	q0, [sp, #0x450]
1015c4f98: 3d810fe2    	str	q2, [sp, #0x430]
1015c4f9c: 3d8113e1    	str	q1, [sp, #0x440]
1015c4fa0: f9420be8    	ldr	x8, [sp, #0x410]
1015c4fa4: b4000088    	cbz	x8, 0x1015c4fb4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2440>
1015c4fa8: 5280003c    	mov	w28, #0x1               ; =1
1015c4fac: 911043e0    	add	x0, sp, #0x410
1015c4fb0: 97ff8824    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c4fb4: f100035f    	cmp	x26, #0x0
1015c4fb8: 1a9f17fa    	cset	w26, eq
1015c4fbc: 1400002b    	b	0x1015c5068 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x24f4>
1015c4fc0: b84111a8    	ldur	w8, [x13, #0x11]
1015c4fc4: b90273e8    	str	w8, [sp, #0x270]
1015c4fc8: b84141a8    	ldur	w8, [x13, #0x14]
1015c4fcc: 9108c3e9    	add	x9, sp, #0x230
1015c4fd0: b8043128    	stur	w8, [x9, #0x43]
1015c4fd4: 3cc281a0    	ldur	q0, [x13, #0x28]
1015c4fd8: 3cc381a1    	ldur	q1, [x13, #0x38]
1015c4fdc: 3d8173e0    	str	q0, [sp, #0x5c0]
1015c4fe0: 3d8177e1    	str	q1, [sp, #0x5d0]
1015c4fe4: 3cc481a0    	ldur	q0, [x13, #0x48]
1015c4fe8: 3d80dfe0    	str	q0, [sp, #0x370]
1015c4fec: 29004680    	stp	w0, w17, [x20]
1015c4ff0: 39002290    	strb	w16, [x20, #0x8]
1015c4ff4: 2a0803e8    	mov	w8, w8
1015c4ff8: b9000e88    	str	w8, [x20, #0xc]
1015c4ffc: b94273e8    	ldr	w8, [sp, #0x270]
1015c5000: b8009288    	stur	w8, [x20, #0x9]
1015c5004: a9013a8f    	stp	x15, x14, [x20, #0x10]
1015c5008: 3dc177e0    	ldr	q0, [sp, #0x5d0]
1015c500c: 3dc173e1    	ldr	q1, [sp, #0x5c0]
1015c5010: ad010281    	stp	q1, q0, [x20, #0x20]
1015c5014: 3dc0dfe0    	ldr	q0, [sp, #0x370]
1015c5018: 3d801280    	str	q0, [x20, #0x40]
1015c501c: 17fff7c1    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c5020: f94023e8    	ldr	x8, [sp, #0x40]
1015c5024: f9424908    	ldr	x8, [x8, #0x490]
1015c5028: f100079f    	cmp	x28, #0x1
1015c502c: 5400148c    	b.gt	0x1015c52bc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2748>
1015c5030: b4001bbc    	cbz	x28, 0x1015c53a4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2830>
1015c5034: f100079f    	cmp	x28, #0x1
1015c5038: 54001f21    	b.ne	0x1015c541c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x28a8>
1015c503c: 39518108    	ldrb	w8, [x8, #0x460]
1015c5040: 36003268    	tbz	w8, #0x0, 0x1015c568c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b18>
1015c5044: f94027e8    	ldr	x8, [sp, #0x48]
1015c5048: b900011f    	str	wzr, [x8]
1015c504c: 52800189    	mov	w9, #0xc                ; =12
1015c5050: 39002109    	strb	w9, [x8, #0x8]
1015c5054: d000d3a9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c5058: 911af129    	add	x9, x9, #0x6bc
1015c505c: 528002ca    	mov	w10, #0x16              ; =22
1015c5060: 17fff71f    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c5064: 5280001a    	mov	w26, #0x0               ; =0
1015c5068: f9400ec9    	ldr	x9, [x22, #0x18]
1015c506c: b4001109    	cbz	x9, 0x1015c528c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2718>
1015c5070: b9475be0    	ldr	w0, [sp, #0x758]
1015c5074: f9400ac8    	ldr	x8, [x22, #0x10]
1015c5078: f100053f    	cmp	x9, #0x1
1015c507c: 54000861    	b.ne	0x1015c5188 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2614>
1015c5080: d280000a    	mov	x10, #0x0               ; =0
1015c5084: 1400004a    	b	0x1015c51ac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2638>
1015c5088: 3dc1abe0    	ldr	q0, [sp, #0x6a0]
1015c508c: 3dc1afe1    	ldr	q1, [sp, #0x6b0]
1015c5090: 3d8107e0    	str	q0, [sp, #0x410]
1015c5094: 3d810be1    	str	q1, [sp, #0x420]
1015c5098: 3dc1b3e2    	ldr	q2, [sp, #0x6c0]
1015c509c: 3d810fe2    	str	q2, [sp, #0x430]
1015c50a0: f9436be8    	ldr	x8, [sp, #0x6d0]
1015c50a4: f90223e8    	str	x8, [sp, #0x440]
1015c50a8: 3c804340    	stur	q0, [x26, #0x4]
1015c50ac: 3c814341    	stur	q1, [x26, #0x14]
1015c50b0: 3c824342    	stur	q2, [x26, #0x24]
1015c50b4: f8034348    	stur	x8, [x26, #0x34]
1015c50b8: b90002df    	str	wzr, [x22]
1015c50bc: 3dc1abe0    	ldr	q0, [sp, #0x6a0]
1015c50c0: 3dc1afe1    	ldr	q1, [sp, #0x6b0]
1015c50c4: 3c8042c0    	stur	q0, [x22, #0x4]
1015c50c8: 3c8142c1    	stur	q1, [x22, #0x14]
1015c50cc: 3dc1b3e0    	ldr	q0, [sp, #0x6c0]
1015c50d0: 3c8242c0    	stur	q0, [x22, #0x24]
1015c50d4: 3cc2c340    	ldur	q0, [x26, #0x2c]
1015c50d8: 3d800ec0    	str	q0, [x22, #0x30]
1015c50dc: 140000a7    	b	0x1015c5378 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2804>
1015c50e0: 9118c3e8    	add	x8, sp, #0x630
1015c50e4: 3cc08100    	ldur	q0, [x8, #0x8]
1015c50e8: 3cc18101    	ldur	q1, [x8, #0x18]
1015c50ec: ad1707e0    	stp	q0, q1, [sp, #0x2e0]
1015c50f0: 3cc28100    	ldur	q0, [x8, #0x28]
1015c50f4: 3d80c3e0    	str	q0, [sp, #0x300]
1015c50f8: f94337e8    	ldr	x8, [sp, #0x668]
1015c50fc: f9018be8    	str	x8, [sp, #0x310]
1015c5100: f941bae1    	ldr	x1, [x23, #0x370]
1015c5104: f941bee2    	ldr	x2, [x23, #0x378]
1015c5108: 911a83e0    	add	x0, sp, #0x6a0
1015c510c: 910b83e4    	add	x4, sp, #0x2e0
1015c5110: aa1403e3    	mov	x3, x20
1015c5114: 97ff9641    	bl	0x1015aaa18 <__RNCNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation14numeric_writesNtB6_10Invocation21prepare_numeric_writes2_0Be_>
1015c5118: 9118c3e8    	add	x8, sp, #0x630
1015c511c: 3cc84100    	ldur	q0, [x8, #0x84]
1015c5120: 3c8142c0    	stur	q0, [x22, #0x14]
1015c5124: 3cc94100    	ldur	q0, [x8, #0x94]
1015c5128: 3c8242c0    	stur	q0, [x22, #0x24]
1015c512c: 3cca4100    	ldur	q0, [x8, #0xa4]
1015c5130: 3c8342c0    	stur	q0, [x22, #0x34]
1015c5134: b946a3e9    	ldr	w9, [sp, #0x6a0]
1015c5138: b946e7ea    	ldr	w10, [sp, #0x6e4]
1015c513c: b90046ca    	str	w10, [x22, #0x44]
1015c5140: 3cc74100    	ldur	q0, [x8, #0x74]
1015c5144: 3c8042c0    	stur	q0, [x22, #0x4]
1015c5148: 395ba3ea    	ldrb	w10, [sp, #0x6e8]
1015c514c: b84b9108    	ldur	w8, [x8, #0xb9]
1015c5150: b80492c8    	stur	w8, [x22, #0x49]
1015c5154: b946efe8    	ldr	w8, [sp, #0x6ec]
1015c5158: b9004ec8    	str	w8, [x22, #0x4c]
1015c515c: b90002c9    	str	w9, [x22]
1015c5160: 390122ca    	strb	w10, [x22, #0x48]
1015c5164: 17fff76f    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c5168: b90002ff    	str	wzr, [x23]
1015c516c: 52800188    	mov	w8, #0xc                ; =12
1015c5170: f000d389    	adrp	x9, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c5174: 9102e129    	add	x9, x9, #0xb8
1015c5178: a900a6e8    	stp	x8, x9, [x23, #0x8]
1015c517c: 52800348    	mov	w8, #0x1a               ; =26
1015c5180: f9000ee8    	str	x8, [x23, #0x18]
1015c5184: 17fff767    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c5188: d280000a    	mov	x10, #0x0               ; =0
1015c518c: d341fd2b    	lsr	x11, x9, #1
1015c5190: 8b0a016c    	add	x12, x11, x10
1015c5194: b86c790d    	ldr	w13, [x8, x12, lsl #2]
1015c5198: 6b0001bf    	cmp	w13, w0
1015c519c: 9a8c814a    	csel	x10, x10, x12, hi
1015c51a0: cb0b0129    	sub	x9, x9, x11
1015c51a4: f100053f    	cmp	x9, #0x1
1015c51a8: 54ffff28    	b.hi	0x1015c518c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2618>
1015c51ac: b86a7908    	ldr	w8, [x8, x10, lsl #2]
1015c51b0: 6b00011f    	cmp	w8, w0
1015c51b4: 540006c1    	b.ne	0x1015c528c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2718>
1015c51b8: f941bf21    	ldr	x1, [x25, #0x378]
1015c51bc: eb00003f    	cmp	x1, x0
1015c51c0: 54015f29    	b.ls	0x1015c7da4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5230>
1015c51c4: f941bb28    	ldr	x8, [x25, #0x370]
1015c51c8: 52802e09    	mov	w9, #0x170              ; =368
1015c51cc: 9ba92008    	umaddl	x8, w0, w9, x8
1015c51d0: 91057109    	add	x9, x8, #0x15c
1015c51d4: b9416d08    	ldr	w8, [x8, #0x16c]
1015c51d8: b90423e8    	str	w8, [sp, #0x420]
1015c51dc: 3dc00120    	ldr	q0, [x9]
1015c51e0: 3d8107e0    	str	q0, [sp, #0x410]
1015c51e4: 5280003c    	mov	w28, #0x1               ; =1
1015c51e8: 9118c3e8    	add	x8, sp, #0x630
1015c51ec: 911043e0    	add	x0, sp, #0x410
1015c51f0: 9441fa1e    	bl	0x102643a68 <__RNvMs1_NtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact16fusion_semantics5factsNtB5_18NativeProgramFacts18control_successors>
1015c51f4: b9404ac8    	ldr	w8, [x22, #0x48]
1015c51f8: b94633e9    	ldr	w9, [sp, #0x630]
1015c51fc: 7100053f    	cmp	w9, #0x1
1015c5200: 54000081    	b.ne	0x1015c5210 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x269c>
1015c5204: b94637e9    	ldr	w9, [sp, #0x634]
1015c5208: 6b08013f    	cmp	w9, w8
1015c520c: 540000e0    	b.eq	0x1015c5228 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x26b4>
1015c5210: b9463be9    	ldr	w9, [sp, #0x638]
1015c5214: 7100053f    	cmp	w9, #0x1
1015c5218: 540003a1    	b.ne	0x1015c528c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2718>
1015c521c: b9463fe9    	ldr	w9, [sp, #0x63c]
1015c5220: 6b08013f    	cmp	w9, w8
1015c5224: 54000341    	b.ne	0x1015c528c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2718>
1015c5228: f94353fb    	ldr	x27, [sp, #0x6a0]
1015c522c: f100037f    	cmp	x27, #0x0
1015c5230: 1a9f17f9    	cset	w25, eq
1015c5234: b400183b    	cbz	x27, 0x1015c5538 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x29c4>
1015c5238: 3dc1abe0    	ldr	q0, [sp, #0x6a0]
1015c523c: 3dc1afe1    	ldr	q1, [sp, #0x6b0]
1015c5240: 3d8107e0    	str	q0, [sp, #0x410]
1015c5244: 3d810be1    	str	q1, [sp, #0x420]
1015c5248: 3dc1b3e0    	ldr	q0, [sp, #0x6c0]
1015c524c: 3dc1b7e1    	ldr	q1, [sp, #0x6d0]
1015c5250: 3d810fe0    	str	q0, [sp, #0x430]
1015c5254: 3d8113e1    	str	q1, [sp, #0x440]
1015c5258: b9404ec1    	ldr	w1, [x22, #0x4c]
1015c525c: 9118c3e8    	add	x8, sp, #0x630
1015c5260: 9103c260    	add	x0, x19, #0xf0
1015c5264: 911043e2    	add	x2, sp, #0x410
1015c5268: 910be263    	add	x3, x19, #0x2f8
1015c526c: 94001d6a    	bl	0x1015cc814 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena3put>
1015c5270: 3958c3e8    	ldrb	w8, [sp, #0x630]
1015c5274: 7100511f    	cmp	w8, #0x14
1015c5278: 540019e1    	b.ne	0x1015c55b4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2a40>
1015c527c: 5280001c    	mov	w28, #0x0               ; =0
1015c5280: 911043e0    	add	x0, sp, #0x410
1015c5284: 97ff876f    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c5288: 140000b2    	b	0x1015c5550 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x29dc>
1015c528c: b900029f    	str	wzr, [x20]
1015c5290: 52800189    	mov	w9, #0xc                ; =12
1015c5294: 39002289    	strb	w9, [x20, #0x8]
1015c5298: d000d3a8    	adrp	x8, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c529c: 912d0d08    	add	x8, x8, #0xb43
1015c52a0: 528005a9    	mov	w9, #0x2d               ; =45
1015c52a4: a9012688    	stp	x8, x9, [x20, #0x10]
1015c52a8: f94353e8    	ldr	x8, [sp, #0x6a0]
1015c52ac: b4fee3a8    	cbz	x8, 0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c52b0: 911a83e0    	add	x0, sp, #0x6a0
1015c52b4: 97ff8763    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c52b8: 17fff71a    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c52bc: f1000b9f    	cmp	x28, #0x2
1015c52c0: 54000860    	b.eq	0x1015c53cc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2858>
1015c52c4: f1004b9f    	cmp	x28, #0x12
1015c52c8: 54000aa1    	b.ne	0x1015c541c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x28a8>
1015c52cc: 39518108    	ldrb	w8, [x8, #0x460]
1015c52d0: 370000c8    	tbnz	w8, #0x0, 0x1015c52e8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2774>
1015c52d4: a9402668    	ldp	x8, x9, [x19]
1015c52d8: f9400a6a    	ldr	x10, [x19, #0x10]
1015c52dc: aa090108    	orr	x8, x8, x9
1015c52e0: aa0a0108    	orr	x8, x8, x10
1015c52e4: b4005e68    	cbz	x8, 0x1015c5eb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x333c>
1015c52e8: f94027e8    	ldr	x8, [sp, #0x48]
1015c52ec: b900011f    	str	wzr, [x8]
1015c52f0: 52800189    	mov	w9, #0xc                ; =12
1015c52f4: 39002109    	strb	w9, [x8, #0x8]
1015c52f8: d000d3a9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c52fc: 91207d29    	add	x9, x9, #0x81f
1015c5300: 528005aa    	mov	w10, #0x2d              ; =45
1015c5304: 17fff676    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c5308: 90012062    	adrp	x2, 0x1039d1000 <_anon.19b44b453da724831023c27de6e0b6f2.288+0x250>
1015c530c: 910d0042    	add	x2, x2, #0x340
1015c5310: aa1303e0    	mov	x0, x19
1015c5314: aa0903e1    	mov	x1, x9
1015c5318: 9460b8b2    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c531c: b90002df    	str	wzr, [x22]
1015c5320: 52800188    	mov	w8, #0xc                ; =12
1015c5324: 390022c8    	strb	w8, [x22, #0x8]
1015c5328: b000d3a8    	adrp	x8, 0x10303a000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x3b8>
1015c532c: 91002908    	add	x8, x8, #0xa
1015c5330: 528005a9    	mov	w9, #0x2d               ; =45
1015c5334: a90126c8    	stp	x8, x9, [x22, #0x10]
1015c5338: 14000018    	b	0x1015c5398 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2824>
1015c533c: 3cc04340    	ldur	q0, [x26, #0x4]
1015c5340: 3cc14341    	ldur	q1, [x26, #0x14]
1015c5344: 3d8107e0    	str	q0, [sp, #0x410]
1015c5348: 3d810be1    	str	q1, [sp, #0x420]
1015c534c: b946c7e9    	ldr	w9, [sp, #0x6c4]
1015c5350: b90433e9    	str	w9, [sp, #0x430]
1015c5354: f94367ea    	ldr	x10, [sp, #0x6c8]
1015c5358: 3c8142c0    	stur	q0, [x22, #0x14]
1015c535c: 3c8242c1    	stur	q1, [x22, #0x24]
1015c5360: b90036c9    	str	w9, [x22, #0x34]
1015c5364: b90002df    	str	wzr, [x22]
1015c5368: 528001a9    	mov	w9, #0xd                ; =13
1015c536c: 390022c9    	strb	w9, [x22, #0x8]
1015c5370: b90012c8    	str	w8, [x22, #0x10]
1015c5374: f9001eca    	str	x10, [x22, #0x38]
1015c5378: f94403e8    	ldr	x8, [sp, #0x800]
1015c537c: 92800009    	mov	x9, #-0x1               ; =-1
1015c5380: f8690108    	ldaddl	x9, x8, [x8]
1015c5384: f100051f    	cmp	x8, #0x1
1015c5388: 54000081    	b.ne	0x1015c5398 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2824>
1015c538c: d50339bf    	dmb	ishld
1015c5390: 912003e0    	add	x0, sp, #0x800
1015c5394: 945cb315    	bl	0x102cf1fe8 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015c5398: 910cc3e0    	add	x0, sp, #0x330
1015c539c: 97ff8729    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c53a0: 17fff6e0    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c53a4: 39518108    	ldrb	w8, [x8, #0x460]
1015c53a8: 360020a8    	tbz	w8, #0x0, 0x1015c57bc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2c48>
1015c53ac: f94027e8    	ldr	x8, [sp, #0x48]
1015c53b0: b900011f    	str	wzr, [x8]
1015c53b4: 52800189    	mov	w9, #0xc                ; =12
1015c53b8: 39002109    	strb	w9, [x8, #0x8]
1015c53bc: d000d3a9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c53c0: 911cf929    	add	x9, x9, #0x73e
1015c53c4: 5280030a    	mov	w10, #0x18              ; =24
1015c53c8: 17fff645    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c53cc: 39518109    	ldrb	w9, [x8, #0x460]
1015c53d0: 370029e9    	tbnz	w9, #0x0, 0x1015c590c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d98>
1015c53d4: f9400a69    	ldr	x9, [x19, #0x10]
1015c53d8: b50029a9    	cbnz	x9, 0x1015c590c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d98>
1015c53dc: f940f109    	ldr	x9, [x8, #0x1e0]
1015c53e0: fd40f500    	ldr	d0, [x8, #0x1e8]
1015c53e4: 3947c10a    	ldrb	w10, [x8, #0x1f0]
1015c53e8: a95fb10b    	ldp	x11, x12, [x8, #0x1f8]
1015c53ec: d2f0000d    	mov	x13, #-0x8000000000000000 ; =-9223372036854775808
1015c53f0: f900f10d    	str	x13, [x8, #0x1e0]
1015c53f4: eb0d013f    	cmp	x9, x13
1015c53f8: 54003621    	b.ne	0x1015c5abc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f48>
1015c53fc: f94027e8    	ldr	x8, [sp, #0x48]
1015c5400: b900011f    	str	wzr, [x8]
1015c5404: 52800189    	mov	w9, #0xc                ; =12
1015c5408: 39002109    	strb	w9, [x8, #0x8]
1015c540c: f000d389    	adrp	x9, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c5410: 9134dd29    	add	x9, x9, #0xd37
1015c5414: 528003ea    	mov	w10, #0x1f              ; =31
1015c5418: 17fff631    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c541c: f9422d08    	ldr	x8, [x8, #0x458]
1015c5420: 91000d00    	add	x0, x8, #0x3
1015c5424: 97ff99d0    	bl	0x1015abb64 <__RNvMNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program8protocolNtB2_12GlobalHelper6decode>
1015c5428: eb0102df    	cmp	x22, x1
1015c542c: 1a9f1768    	csinc	w8, w27, wzr, ne
1015c5430: eb00039f    	cmp	x28, x0
1015c5434: 54000b01    	b.ne	0x1015c5594 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2a20>
1015c5438: 36000ae8    	tbz	w8, #0x0, 0x1015c5594 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2a20>
1015c543c: f94023e0    	ldr	x0, [sp, #0x40]
1015c5440: aa1503e1    	mov	x1, x21
1015c5444: 97ffef59    	bl	0x1015c11a8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation15action_required>
1015c5448: 340000c0    	cbz	w0, 0x1015c5460 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x28ec>
1015c544c: f94023e8    	ldr	x8, [sp, #0x40]
1015c5450: f9424908    	ldr	x8, [x8, #0x490]
1015c5454: 39518108    	ldrb	w8, [x8, #0x460]
1015c5458: 7100051f    	cmp	w8, #0x1
1015c545c: 540009c1    	b.ne	0x1015c5594 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2a20>
1015c5460: f941be81    	ldr	x1, [x20, #0x378]
1015c5464: eb0102bf    	cmp	x21, x1
1015c5468: 54014fa2    	b.hs	0x1015c7e5c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x52e8>
1015c546c: f941ba88    	ldr	x8, [x20, #0x370]
1015c5470: 52802e09    	mov	w9, #0x170              ; =368
1015c5474: 9b0922a8    	madd	x8, x21, x9, x8
1015c5478: d000d3a1    	adrp	x1, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c547c: 91194021    	add	x1, x1, #0x650
1015c5480: 91057100    	add	x0, x8, #0x15c
1015c5484: 94004da3    	bl	0x1015d8b10 <__RNvXsg_NtNtCs1qJAwyMG1lC_11mech_engine15native_artifact9iterationNtB5_25NativeIterationTerminatorNtNtCsgDHHaSskbIF_4core3cmp9PartialEq2eq>
1015c5488: 36000860    	tbz	w0, #0x0, 0x1015c5594 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2a20>
1015c548c: f94023e8    	ldr	x8, [sp, #0x40]
1015c5490: f9424909    	ldr	x9, [x8, #0x490]
1015c5494: f9422d28    	ldr	x8, [x9, #0x458]
1015c5498: f941d68a    	ldr	x10, [x20, #0x3a8]
1015c549c: f9419681    	ldr	x1, [x20, #0x328]
1015c54a0: 8b0a002b    	add	x11, x1, x10
1015c54a4: eb0b011f    	cmp	x8, x11
1015c54a8: 54005ae2    	b.hs	0x1015c6004 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3490>
1015c54ac: eb0a0100    	subs	x0, x8, x10
1015c54b0: 54007962    	b.hs	0x1015c63dc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3868>
1015c54b4: f941d28a    	ldr	x10, [x20, #0x3a0]
1015c54b8: 5280320b    	mov	w11, #0x190             ; =400
1015c54bc: 9b0b2908    	madd	x8, x8, x11, x10
1015c54c0: 9106210a    	add	x10, x8, #0x188
1015c54c4: 140003cc    	b	0x1015c63f4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3880>
1015c54c8: 9118c3e9    	add	x9, sp, #0x630
1015c54cc: 3cca8120    	ldur	q0, [x9, #0xa8]
1015c54d0: 911043ea    	add	x10, sp, #0x410
1015c54d4: 3c838140    	stur	q0, [x10, #0x38]
1015c54d8: 3ccb8120    	ldur	q0, [x9, #0xb8]
1015c54dc: 3c848140    	stur	q0, [x10, #0x48]
1015c54e0: 3ccc8120    	ldur	q0, [x9, #0xc8]
1015c54e4: 3c858140    	stur	q0, [x10, #0x58]
1015c54e8: ad5f07e0    	ldp	q0, q1, [sp, #0x3e0]
1015c54ec: 3c808140    	stur	q0, [x10, #0x8]
1015c54f0: f94387e9    	ldr	x9, [sp, #0x708]
1015c54f4: 3c818141    	stur	q1, [x10, #0x18]
1015c54f8: 3dc103e0    	ldr	q0, [sp, #0x400]
1015c54fc: 3c828140    	stur	q0, [x10, #0x28]
1015c5500: f9023fe9    	str	x9, [sp, #0x478]
1015c5504: f9020be8    	str	x8, [sp, #0x410]
1015c5508: f100111f    	cmp	x8, #0x4
1015c550c: 54002101    	b.ne	0x1015c592c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2db8>
1015c5510: 911043e0    	add	x0, sp, #0x410
1015c5514: 97ff899d    	bl	0x1015a7b88 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrix31UnsignedMatrixOwnershipTransferECs29QkOtpKx6e_8mech_gpu>
1015c5518: b90002df    	str	wzr, [x22]
1015c551c: 52800188    	mov	w8, #0xc                ; =12
1015c5520: 390022c8    	strb	w8, [x22, #0x8]
1015c5524: b000d3a8    	adrp	x8, 0x10303a000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x3b8>
1015c5528: 9100dd08    	add	x8, x8, #0x37
1015c552c: 52800509    	mov	w9, #0x28               ; =40
1015c5530: a90126c8    	stp	x8, x9, [x22, #0x10]
1015c5534: 14000240    	b	0x1015c5e34 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x32c0>
1015c5538: f9426aa8    	ldr	x8, [x21, #0x4d0]
1015c553c: b4002a68    	cbz	x8, 0x1015c5a88 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f14>
1015c5540: f9426ea9    	ldr	x9, [x21, #0x4d8]
1015c5544: b4002a29    	cbz	x9, 0x1015c5a88 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f14>
1015c5548: f94357e9    	ldr	x9, [sp, #0x6a8]
1015c554c: f9000109    	str	x9, [x8]
1015c5550: b9475be8    	ldr	w8, [sp, #0x758]
1015c5554: 52800029    	mov	w9, #0x1                ; =1
1015c5558: b902f269    	str	w9, [x19, #0x2f0]
1015c555c: b902f668    	str	w8, [x19, #0x2f4]
1015c5560: 39118269    	strb	w9, [x19, #0x460]
1015c5564: 36004a1a    	tbz	w26, #0x0, 0x1015c5ea4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3330>
1015c5568: eb1802ff    	cmp	x23, x24
1015c556c: 54004920    	b.eq	0x1015c5e90 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x331c>
1015c5570: b900029f    	str	wzr, [x20]
1015c5574: 52800188    	mov	w8, #0xc                ; =12
1015c5578: 39002288    	strb	w8, [x20, #0x8]
1015c557c: d000d3a8    	adrp	x8, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c5580: 912dc108    	add	x8, x8, #0xb70
1015c5584: 528004a9    	mov	w9, #0x25               ; =37
1015c5588: a9012688    	stp	x8, x9, [x20, #0x10]
1015c558c: b4ffe8fb    	cbz	x27, 0x1015c52a8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2734>
1015c5590: 17fff664    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c5594: f94027e8    	ldr	x8, [sp, #0x48]
1015c5598: b900011f    	str	wzr, [x8]
1015c559c: 52800189    	mov	w9, #0xc                ; =12
1015c55a0: 39002109    	strb	w9, [x8, #0x8]
1015c55a4: d000d3a9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c55a8: 9119d929    	add	x9, x9, #0x676
1015c55ac: 5280056a    	mov	w10, #0x2b              ; =43
1015c55b0: 17fff5cb    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c55b4: 9118c3e9    	add	x9, sp, #0x630
1015c55b8: b840112a    	ldur	w10, [x9, #0x1]
1015c55bc: b800928a    	stur	w10, [x20, #0x9]
1015c55c0: b94637ea    	ldr	w10, [sp, #0x634]
1015c55c4: b9000e8a    	str	w10, [x20, #0xc]
1015c55c8: 3dc197e0    	ldr	q0, [sp, #0x650]
1015c55cc: 3c828280    	stur	q0, [x20, #0x28]
1015c55d0: f94333ea    	ldr	x10, [sp, #0x660]
1015c55d4: f9001e8a    	str	x10, [x20, #0x38]
1015c55d8: fd4327e0    	ldr	d0, [sp, #0x648]
1015c55dc: 3cc08121    	ldur	q1, [x9, #0x8]
1015c55e0: 52800049    	mov	w9, #0x2                ; =2
1015c55e4: b9000289    	str	w9, [x20]
1015c55e8: 39002288    	strb	w8, [x20, #0x8]
1015c55ec: 3d800681    	str	q1, [x20, #0x10]
1015c55f0: fd001280    	str	d0, [x20, #0x20]
1015c55f4: 5280001c    	mov	w28, #0x0               ; =0
1015c55f8: 911043e0    	add	x0, sp, #0x410
1015c55fc: 97ff8691    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c5600: 17fff648    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c5604: 911a83e8    	add	x8, sp, #0x6a0
1015c5608: 910ee380    	add	x0, x28, #0x3b8
1015c560c: 943550ca    	bl	0x102319934 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget13memory_budget>
1015c5610: f9401268    	ldr	x8, [x19, #0x20]
1015c5614: f100051f    	cmp	x8, #0x1
1015c5618: 54002461    	b.ne	0x1015c5aa4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f30>
1015c561c: b9404268    	ldr	w8, [x19, #0x40]
1015c5620: 36004ba8    	tbz	w8, #0x0, 0x1015c5f94 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3420>
1015c5624: f9401661    	ldr	x1, [x19, #0x28]
1015c5628: f9402662    	ldr	x2, [x19, #0x48]
1015c562c: 911fa3e8    	add	x8, sp, #0x7e8
1015c5630: 911a83e0    	add	x0, sp, #0x6a0
1015c5634: 945c8605    	bl	0x102ce6e48 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget11with_limits>
1015c5638: f94353e8    	ldr	x8, [sp, #0x6a0]
1015c563c: 92800009    	mov	x9, #-0x1               ; =-1
1015c5640: f8690108    	ldaddl	x9, x8, [x8]
1015c5644: f100051f    	cmp	x8, #0x1
1015c5648: 54000081    	b.ne	0x1015c5658 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2ae4>
1015c564c: d50339bf    	dmb	ishld
1015c5650: 911a83e0    	add	x0, sp, #0x6a0
1015c5654: 945cb265    	bl	0x102cf1fe8 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015c5658: f943f3e8    	ldr	x8, [sp, #0x7e0]
1015c565c: f9435509    	ldr	x9, [x8, #0x6a8]
1015c5660: f144013f    	cmp	x9, #0x100, lsl #12     ; =0x100000
1015c5664: 540053c9    	b.ls	0x1015c60dc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3568>
1015c5668: 9000d1c8    	adrp	x8, 0x102ffd000 <_anon.70399bd8ea3438f11774e3396e76a872.10+0x30c2>
1015c566c: 3dc15d00    	ldr	q0, [x8, #0x570]
1015c5670: 3c808300    	stur	q0, [x24, #0x8]
1015c5674: 528000c8    	mov	w8, #0x6                ; =6
1015c5678: b9000308    	str	w8, [x24]
1015c567c: 14000583    	b	0x1015c6c88 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4114>
1015c5680: b0012060    	adrp	x0, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c5684: 91152000    	add	x0, x0, #0x548
1015c5688: 9460b7af    	bl	0x102df3544 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1015c568c: 911a83e0    	add	x0, sp, #0x6a0
1015c5690: f94023e1    	ldr	x1, [sp, #0x40]
1015c5694: aa1503e2    	mov	x2, x21
1015c5698: 97ffedb3    	bl	0x1015c0d64 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation10needs_move>
1015c569c: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c56a0: 360028c8    	tbz	w8, #0x0, 0x1015c5bb8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3044>
1015c56a4: b946a7f6    	ldr	w22, [sp, #0x6a4]
1015c56a8: b946abf7    	ldr	w23, [sp, #0x6a8]
1015c56ac: 911a83e0    	add	x0, sp, #0x6a0
1015c56b0: f94023e1    	ldr	x1, [sp, #0x40]
1015c56b4: aa1503e2    	mov	x2, x21
1015c56b8: 52800023    	mov	w3, #0x1                ; =1
1015c56bc: 52800104    	mov	w4, #0x8                ; =8
1015c56c0: d2800005    	mov	x5, #0x0                ; =0
1015c56c4: 97ffa637    	bl	0x1015aefa0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action>
1015c56c8: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c56cc: 7100191f    	cmp	w8, #0x6
1015c56d0: 54004361    	b.ne	0x1015c5f3c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x33c8>
1015c56d4: f94357e8    	ldr	x8, [sp, #0x6a8]
1015c56d8: f100091f    	cmp	x8, #0x2
1015c56dc: 540002c1    	b.ne	0x1015c5734 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2bc0>
1015c56e0: 911a83e0    	add	x0, sp, #0x6a0
1015c56e4: f94023e1    	ldr	x1, [sp, #0x40]
1015c56e8: aa1603e2    	mov	x2, x22
1015c56ec: aa1703e3    	mov	x3, x23
1015c56f0: 9400325d    	bl	0x1015d2064 <__RNvMs_NtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation5joins6mappedNtB8_10Invocation15move_joined_map>
1015c56f4: b946a3e9    	ldr	w9, [sp, #0x6a0]
1015c56f8: 395a93e8    	ldrb	w8, [sp, #0x6a4]
1015c56fc: 7100193f    	cmp	w9, #0x6
1015c5700: 54007621    	b.ne	0x1015c65c4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a50>
1015c5704: 37000548    	tbnz	w8, #0x0, 0x1015c57ac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2c38>
1015c5708: f94023e8    	ldr	x8, [sp, #0x40]
1015c570c: f9424908    	ldr	x8, [x8, #0x490]
1015c5710: 911a83e0    	add	x0, sp, #0x6a0
1015c5714: 9103c101    	add	x1, x8, #0xf0
1015c5718: 910be104    	add	x4, x8, #0x2f8
1015c571c: aa1603e2    	mov	x2, x22
1015c5720: aa1703e3    	mov	x3, x23
1015c5724: 94001817    	bl	0x1015cb780 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena15copy_current_to>
1015c5728: 395a83e8    	ldrb	w8, [sp, #0x6a0]
1015c572c: 7100511f    	cmp	w8, #0x14
1015c5730: 54009641    	b.ne	0x1015c69f8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e84>
1015c5734: f941be81    	ldr	x1, [x20, #0x378]
1015c5738: eb0102bf    	cmp	x21, x1
1015c573c: 54014322    	b.hs	0x1015c7fa0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x542c>
1015c5740: f941ba88    	ldr	x8, [x20, #0x370]
1015c5744: 52802e09    	mov	w9, #0x170              ; =368
1015c5748: 9b0922a8    	madd	x8, x21, x9, x8
1015c574c: a940250a    	ldp	x10, x9, [x8]
1015c5750: 5280022b    	mov	w11, #0x11              ; =17
1015c5754: ca0b014a    	eor	x10, x10, x11
1015c5758: aa090149    	orr	x9, x10, x9
1015c575c: b5000289    	cbnz	x9, 0x1015c57ac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2c38>
1015c5760: f941c681    	ldr	x1, [x20, #0x388]
1015c5764: b9401102    	ldr	w2, [x8, #0x10]
1015c5768: eb02003f    	cmp	x1, x2
1015c576c: 540145a9    	b.ls	0x1015c8020 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x54ac>
1015c5770: f941c288    	ldr	x8, [x20, #0x380]
1015c5774: 52803009    	mov	w9, #0x180              ; =384
1015c5778: 9ba92048    	umaddl	x8, w2, w9, x8
1015c577c: a9402508    	ldp	x8, x9, [x8]
1015c5780: 528000aa    	mov	w10, #0x5               ; =5
1015c5784: ca0a0108    	eor	x8, x8, x10
1015c5788: aa090108    	orr	x8, x8, x9
1015c578c: b5000108    	cbnz	x8, 0x1015c57ac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2c38>
1015c5790: 911a83e0    	add	x0, sp, #0x6a0
1015c5794: f94023e1    	ldr	x1, [sp, #0x40]
1015c5798: 52800023    	mov	w3, #0x1                ; =1
1015c579c: 97ffef00    	bl	0x1015c139c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals>
1015c57a0: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c57a4: 7100191f    	cmp	w8, #0x6
1015c57a8: 54009141    	b.ne	0x1015c69d0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e5c>
1015c57ac: f94023e8    	ldr	x8, [sp, #0x40]
1015c57b0: f9424908    	ldr	x8, [x8, #0x490]
1015c57b4: 52800029    	mov	w9, #0x1                ; =1
1015c57b8: 17fffc96    	b	0x1015c4a10 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1e9c>
1015c57bc: f941be81    	ldr	x1, [x20, #0x378]
1015c57c0: eb0102bf    	cmp	x21, x1
1015c57c4: 540133a2    	b.hs	0x1015c7e38 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x52c4>
1015c57c8: f941ba88    	ldr	x8, [x20, #0x370]
1015c57cc: 52802e09    	mov	w9, #0x170              ; =368
1015c57d0: 9b0922bb    	madd	x27, x21, x9, x8
1015c57d4: a9402369    	ldp	x9, x8, [x27]
1015c57d8: f100093f    	cmp	x9, #0x2
1015c57dc: fa1f011f    	sbcs	xzr, x8, xzr
1015c57e0: 54001fc2    	b.hs	0x1015c5bd8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3064>
1015c57e4: f9400269    	ldr	x9, [x19]
1015c57e8: f94023e8    	ldr	x8, [sp, #0x40]
1015c57ec: f9426918    	ldr	x24, [x8, #0x4d0]
1015c57f0: eb18013f    	cmp	x9, x24
1015c57f4: 54003c01    	b.ne	0x1015c5f74 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3400>
1015c57f8: f9400677    	ldr	x23, [x19, #0x8]
1015c57fc: f9409768    	ldr	x8, [x27, #0x128]
1015c5800: eb0802ff    	cmp	x23, x8
1015c5804: 54003b81    	b.ne	0x1015c5f74 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3400>
1015c5808: f9400a69    	ldr	x9, [x19, #0x10]
1015c580c: b5003b49    	cbnz	x9, 0x1015c5f74 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3400>
1015c5810: f94023e9    	ldr	x9, [sp, #0x40]
1015c5814: f9426d29    	ldr	x9, [x9, #0x4d8]
1015c5818: eb09011f    	cmp	x8, x9
1015c581c: 54003ac8    	b.hi	0x1015c5f74 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3400>
1015c5820: f9409373    	ldr	x19, [x27, #0x120]
1015c5824: 911a83e0    	add	x0, sp, #0x6a0
1015c5828: f94023e1    	ldr	x1, [sp, #0x40]
1015c582c: aa1503e2    	mov	x2, x21
1015c5830: aa1803e3    	mov	x3, x24
1015c5834: aa1703e4    	mov	x4, x23
1015c5838: 97ffab11    	bl	0x1015b047c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation14selected_callsNtB4_10Invocation21prepared_library_call>
1015c583c: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c5840: 7100191f    	cmp	w8, #0x6
1015c5844: 540037c1    	b.ne	0x1015c5f3c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x33c8>
1015c5848: f94357e8    	ldr	x8, [sp, #0x6a8]
1015c584c: f100091f    	cmp	x8, #0x2
1015c5850: 540052c1    	b.ne	0x1015c62a8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3734>
1015c5854: 911a83e0    	add	x0, sp, #0x6a0
1015c5858: f94023e1    	ldr	x1, [sp, #0x40]
1015c585c: aa1503e2    	mov	x2, x21
1015c5860: aa1803e3    	mov	x3, x24
1015c5864: aa1703e4    	mov	x4, x23
1015c5868: 97ffd1c7    	bl	0x1015b9f84 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime5lines10line_callsNtNtB6_10invocation10Invocation16line_matrix_call>
1015c586c: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c5870: 7100191f    	cmp	w8, #0x6
1015c5874: 54003641    	b.ne	0x1015c5f3c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x33c8>
1015c5878: f94357e8    	ldr	x8, [sp, #0x6a8]
1015c587c: f100091f    	cmp	x8, #0x2
1015c5880: 54005141    	b.ne	0x1015c62a8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3734>
1015c5884: 911a83e0    	add	x0, sp, #0x6a0
1015c5888: f94023e1    	ldr	x1, [sp, #0x40]
1015c588c: aa1503e2    	mov	x2, x21
1015c5890: aa1803e3    	mov	x3, x24
1015c5894: aa1703e4    	mov	x4, x23
1015c5898: 97ffe316    	bl	0x1015be4f0 <__RNvMNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime7session7capture14captured_callsNtNtB8_10invocation10Invocation26captured_line_element_call>
1015c589c: b946a3e9    	ldr	w9, [sp, #0x6a0]
1015c58a0: 395a93e8    	ldrb	w8, [sp, #0x6a4]
1015c58a4: 7100193f    	cmp	w9, #0x6
1015c58a8: 540068e1    	b.ne	0x1015c65c4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a50>
1015c58ac: 3707f808    	tbnz	w8, #0x0, 0x1015c57ac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2c38>
1015c58b0: 911a83e0    	add	x0, sp, #0x6a0
1015c58b4: f94023e1    	ldr	x1, [sp, #0x40]
1015c58b8: aa1503e2    	mov	x2, x21
1015c58bc: aa1803e3    	mov	x3, x24
1015c58c0: aa1703e4    	mov	x4, x23
1015c58c4: 9400281b    	bl	0x1015cf930 <__RNvMs_NtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation18selected_join_call>
1015c58c8: b946a3e9    	ldr	w9, [sp, #0x6a0]
1015c58cc: 395a93e8    	ldrb	w8, [sp, #0x6a4]
1015c58d0: 7100193f    	cmp	w9, #0x6
1015c58d4: 54006781    	b.ne	0x1015c65c4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a50>
1015c58d8: 3600ba88    	tbz	w8, #0x0, 0x1015c7028 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x44b4>
1015c58dc: f94023e8    	ldr	x8, [sp, #0x40]
1015c58e0: f9424909    	ldr	x9, [x8, #0x490]
1015c58e4: 5280002a    	mov	w10, #0x1               ; =1
1015c58e8: 3911812a    	strb	w10, [x9, #0x460]
1015c58ec: f9414908    	ldr	x8, [x8, #0x290]
1015c58f0: f100111f    	cmp	x8, #0x4
1015c58f4: 1a9f17e8    	cset	w8, eq
1015c58f8: f94027e9    	ldr	x9, [sp, #0x48]
1015c58fc: a900a928    	stp	x8, x10, [x9, #0x8]
1015c5900: 528000c8    	mov	w8, #0x6                ; =6
1015c5904: b9000128    	str	w8, [x9]
1015c5908: 17fff586    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c590c: f94027e8    	ldr	x8, [sp, #0x48]
1015c5910: b900011f    	str	wzr, [x8]
1015c5914: 52800189    	mov	w9, #0xc                ; =12
1015c5918: 39002109    	strb	w9, [x8, #0x8]
1015c591c: d000d3a9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c5920: 911a8529    	add	x9, x9, #0x6a1
1015c5924: 5280036a    	mov	w10, #0x1b              ; =27
1015c5928: 17fff4ed    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c592c: 3dc117e0    	ldr	q0, [sp, #0x450]
1015c5930: 3dc11be1    	ldr	q1, [sp, #0x460]
1015c5934: ad1d87e0    	stp	q0, q1, [sp, #0x3b0]
1015c5938: 3dc11fe0    	ldr	q0, [sp, #0x470]
1015c593c: 3d80f7e0    	str	q0, [sp, #0x3d0]
1015c5940: 3dc107e0    	ldr	q0, [sp, #0x410]
1015c5944: 3dc10be1    	ldr	q1, [sp, #0x420]
1015c5948: ad1b87e0    	stp	q0, q1, [sp, #0x370]
1015c594c: 3dc113e0    	ldr	q0, [sp, #0x440]
1015c5950: 3dc10fe1    	ldr	q1, [sp, #0x430]
1015c5954: ad1c83e1    	stp	q1, q0, [sp, #0x390]
1015c5958: f8786b60    	ldr	x0, [x27, x24]
1015c595c: f94017e8    	ldr	x8, [sp, #0x28]
1015c5960: eb08001f    	cmp	x0, x8
1015c5964: 54012722    	b.hs	0x1015c7e48 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x52d4>
1015c5968: 52800308    	mov	w8, #0x18               ; =24
1015c596c: f94013e9    	ldr	x9, [sp, #0x20]
1015c5970: 9b082408    	madd	x8, x0, x8, x9
1015c5974: 39404908    	ldrb	w8, [x8, #0x12]
1015c5978: 36001408    	tbz	w8, #0x0, 0x1015c5bf8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3084>
1015c597c: f94023e8    	ldr	x8, [sp, #0x40]
1015c5980: f9424908    	ldr	x8, [x8, #0x490]
1015c5984: f941e108    	ldr	x8, [x8, #0x3c0]
1015c5988: b4002448    	cbz	x8, 0x1015c5e10 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x329c>
1015c598c: f9402109    	ldr	x9, [x8, #0x40]
1015c5990: f100093f    	cmp	x9, #0x2
1015c5994: 540023e0    	b.eq	0x1015c5e10 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x329c>
1015c5998: f9406d09    	ldr	x9, [x8, #0xd8]
1015c599c: eb13013f    	cmp	x9, x19
1015c59a0: 54002381    	b.ne	0x1015c5e10 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x329c>
1015c59a4: f9404109    	ldr	x9, [x8, #0x80]
1015c59a8: d2f0000a    	mov	x10, #-0x8000000000000000 ; =-9223372036854775808
1015c59ac: eb0a013f    	cmp	x9, x10
1015c59b0: 54002300    	b.eq	0x1015c5e10 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x329c>
1015c59b4: f9404909    	ldr	x9, [x8, #0x90]
1015c59b8: eb09001f    	cmp	x0, x9
1015c59bc: 540022a2    	b.hs	0x1015c5e10 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x329c>
1015c59c0: f9404508    	ldr	x8, [x8, #0x88]
1015c59c4: 52800e09    	mov	w9, #0x70               ; =112
1015c59c8: 9b092008    	madd	x8, x0, x9, x8
1015c59cc: f940010b    	ldr	x11, [x8]
1015c59d0: fd400500    	ldr	d0, [x8, #0x8]
1015c59d4: 3940410c    	ldrb	w12, [x8, #0x10]
1015c59d8: a941a909    	ldp	x9, x10, [x8, #0x18]
1015c59dc: f900011f    	str	xzr, [x8]
1015c59e0: b4008aab    	cbz	x11, 0x1015c6b34 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3fc0>
1015c59e4: 3cc58101    	ldur	q1, [x8, #0x58]
1015c59e8: 911483ed    	add	x13, sp, #0x520
1015c59ec: 3c8f81a1    	stur	q1, [x13, #0xf8]
1015c59f0: f940350e    	ldr	x14, [x8, #0x68]
1015c59f4: f90317ee    	str	x14, [sp, #0x628]
1015c59f8: f902e3eb    	str	x11, [sp, #0x5c0]
1015c59fc: fd02e7e0    	str	d0, [sp, #0x5c8]
1015c5a00: 391743ec    	strb	w12, [sp, #0x5d0]
1015c5a04: b841110b    	ldur	w11, [x8, #0x11]
1015c5a08: b80b11ab    	stur	w11, [x13, #0xb1]
1015c5a0c: b940150b    	ldr	w11, [x8, #0x14]
1015c5a10: b905d7eb    	str	w11, [sp, #0x5d4]
1015c5a14: f902efe9    	str	x9, [sp, #0x5d8]
1015c5a18: f902f3ea    	str	x10, [sp, #0x5e0]
1015c5a1c: 3cc28100    	ldur	q0, [x8, #0x28]
1015c5a20: 3c8c81a0    	stur	q0, [x13, #0xc8]
1015c5a24: 3cc38100    	ldur	q0, [x8, #0x38]
1015c5a28: 3c8d81a0    	stur	q0, [x13, #0xd8]
1015c5a2c: 3cc48100    	ldur	q0, [x8, #0x48]
1015c5a30: 3c8e81a0    	stur	q0, [x13, #0xe8]
1015c5a34: ad5d87e0    	ldp	q0, q1, [sp, #0x3b0]
1015c5a38: 3d819fe0    	str	q0, [sp, #0x670]
1015c5a3c: 3d81a3e1    	str	q1, [sp, #0x680]
1015c5a40: 3dc0f7e0    	ldr	q0, [sp, #0x3d0]
1015c5a44: 3d81a7e0    	str	q0, [sp, #0x690]
1015c5a48: ad5b87e0    	ldp	q0, q1, [sp, #0x370]
1015c5a4c: 3d818fe0    	str	q0, [sp, #0x630]
1015c5a50: 3d8193e1    	str	q1, [sp, #0x640]
1015c5a54: ad5c83e1    	ldp	q1, q0, [sp, #0x390]
1015c5a58: 3d819be0    	str	q0, [sp, #0x660]
1015c5a5c: 3d8197e1    	str	q1, [sp, #0x650]
1015c5a60: 911a83e8    	add	x8, sp, #0x6a0
1015c5a64: 9118c3e0    	add	x0, sp, #0x630
1015c5a68: 911703e3    	add	x3, sp, #0x5c0
1015c5a6c: aa1703e1    	mov	x1, x23
1015c5a70: aa1903e2    	mov	x2, x25
1015c5a74: 945e1592    	bl	0x102d4b0bc <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrixNtB2_27OwnedSnapshotUnsignedMatrix20into_private_appends>
1015c5a78: 14000070    	b	0x1015c5c38 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30c4>
1015c5a7c: b0012060    	adrp	x0, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c5a80: 91140000    	add	x0, x0, #0x500
1015c5a84: 9460b6b0    	bl	0x102df3544 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1015c5a88: b900029f    	str	wzr, [x20]
1015c5a8c: 52800189    	mov	w9, #0xc                ; =12
1015c5a90: 39002289    	strb	w9, [x20, #0x8]
1015c5a94: b000d3a8    	adrp	x8, 0x10303a000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x3b8>
1015c5a98: 910bb908    	add	x8, x8, #0x2ee
1015c5a9c: 52800529    	mov	w9, #0x29               ; =41
1015c5aa0: 17fffe01    	b	0x1015c52a4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2730>
1015c5aa4: f000d388    	adrp	x8, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c5aa8: 91361108    	add	x8, x8, #0xd84
1015c5aac: 1400013c    	b	0x1015c5f9c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3428>
1015c5ab0: b0012060    	adrp	x0, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c5ab4: 9115e000    	add	x0, x0, #0x578
1015c5ab8: 9460b6a3    	bl	0x102df3544 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1015c5abc: 9108e10d    	add	x13, x8, #0x238
1015c5ac0: 9108210e    	add	x14, x8, #0x208
1015c5ac4: ad4009c1    	ldp	q1, q2, [x14]
1015c5ac8: 911043ef    	add	x15, sp, #0x410
1015c5acc: 3c8281e1    	stur	q1, [x15, #0x28]
1015c5ad0: 3c8381e2    	stur	q2, [x15, #0x38]
1015c5ad4: 3dc009c1    	ldr	q1, [x14, #0x20]
1015c5ad8: 3c8481e1    	stur	q1, [x15, #0x48]
1015c5adc: ad4489a1    	ldp	q1, q2, [x13, #0x90]
1015c5ae0: 3c8f81e2    	stur	q2, [x15, #0xf8]
1015c5ae4: 3dc021a2    	ldr	q2, [x13, #0x80]
1015c5ae8: 3c8e81e1    	stur	q1, [x15, #0xe8]
1015c5aec: 3c8d81e2    	stur	q2, [x15, #0xd8]
1015c5af0: ad4305a2    	ldp	q2, q1, [x13, #0x60]
1015c5af4: 3c8c81e1    	stur	q1, [x15, #0xc8]
1015c5af8: 3c8b81e2    	stur	q2, [x15, #0xb8]
1015c5afc: ad4205a2    	ldp	q2, q1, [x13, #0x40]
1015c5b00: 3c8a81e1    	stur	q1, [x15, #0xa8]
1015c5b04: 3c8981e2    	stur	q2, [x15, #0x98]
1015c5b08: ad4105a2    	ldp	q2, q1, [x13, #0x20]
1015c5b0c: 3c8881e1    	stur	q1, [x15, #0x88]
1015c5b10: ad400da1    	ldp	q1, q3, [x13]
1015c5b14: 3c8581e1    	stur	q1, [x15, #0x58]
1015c5b18: 3c8681e3    	stur	q3, [x15, #0x68]
1015c5b1c: 9107c50d    	add	x13, x8, #0x1f1
1015c5b20: b941f508    	ldr	w8, [x8, #0x1f4]
1015c5b24: b90427e8    	str	w8, [sp, #0x424]
1015c5b28: b94001a8    	ldr	w8, [x13]
1015c5b2c: b80111e8    	stur	w8, [x15, #0x11]
1015c5b30: 3c8781e2    	stur	q2, [x15, #0x78]
1015c5b34: f9020be9    	str	x9, [sp, #0x410]
1015c5b38: fd020fe0    	str	d0, [sp, #0x418]
1015c5b3c: 391083ea    	strb	w10, [sp, #0x420]
1015c5b40: f90217eb    	str	x11, [sp, #0x428]
1015c5b44: f9021bec    	str	x12, [sp, #0x430]
1015c5b48: f941be81    	ldr	x1, [x20, #0x378]
1015c5b4c: eb0102bf    	cmp	x21, x1
1015c5b50: 54011b82    	b.hs	0x1015c7ec0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x534c>
1015c5b54: f941ba88    	ldr	x8, [x20, #0x370]
1015c5b58: 52802e09    	mov	w9, #0x170              ; =368
1015c5b5c: 9b0922a8    	madd	x8, x21, x9, x8
1015c5b60: b9415d16    	ldr	w22, [x8, #0x15c]
1015c5b64: 71001edf    	cmp	w22, #0x7
1015c5b68: 54002361    	b.ne	0x1015c5fd4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3460>
1015c5b6c: b9416114    	ldr	w20, [x8, #0x160]
1015c5b70: f94023e8    	ldr	x8, [sp, #0x40]
1015c5b74: f902e3e8    	str	x8, [sp, #0x5c0]
1015c5b78: a9401263    	ldp	x3, x4, [x19]
1015c5b7c: 911a83e8    	add	x8, sp, #0x6a0
1015c5b80: 911043e0    	add	x0, sp, #0x410
1015c5b84: 911703e1    	add	x1, sp, #0x5c0
1015c5b88: aa1503e2    	mov	x2, x21
1015c5b8c: 97fe5513    	bl	0x10155afd8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime11collections13uniform_wordsNtB4_5State18fill_uniform_words>
1015c5b90: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c5b94: 7100191f    	cmp	w8, #0x6
1015c5b98: 54003981    	b.ne	0x1015c62c8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3754>
1015c5b9c: 395a93e8    	ldrb	w8, [sp, #0x6a4]
1015c5ba0: 52800029    	mov	w9, #0x1                ; =1
1015c5ba4: f9031fe9    	str	x9, [sp, #0x638]
1015c5ba8: f90323e8    	str	x8, [sp, #0x640]
1015c5bac: 528000c8    	mov	w8, #0x6                ; =6
1015c5bb0: b90633e8    	str	w8, [sp, #0x630]
1015c5bb4: 140001cf    	b	0x1015c62f0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x377c>
1015c5bb8: f94027e8    	ldr	x8, [sp, #0x48]
1015c5bbc: b900011f    	str	wzr, [x8]
1015c5bc0: 52800189    	mov	w9, #0xc                ; =12
1015c5bc4: b9000909    	str	w9, [x8, #0x8]
1015c5bc8: f000d389    	adrp	x9, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c5bcc: 91345929    	add	x9, x9, #0xd16
1015c5bd0: 5280042a    	mov	w10, #0x21              ; =33
1015c5bd4: 17fff442    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c5bd8: f94027e8    	ldr	x8, [sp, #0x48]
1015c5bdc: b900011f    	str	wzr, [x8]
1015c5be0: 52800189    	mov	w9, #0xc                ; =12
1015c5be4: 39002109    	strb	w9, [x8, #0x8]
1015c5be8: d000d3a9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c5bec: 911c6929    	add	x9, x9, #0x71a
1015c5bf0: 5280048a    	mov	w10, #0x24              ; =36
1015c5bf4: 17fff43a    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c5bf8: ad5d87e0    	ldp	q0, q1, [sp, #0x3b0]
1015c5bfc: 3d819fe0    	str	q0, [sp, #0x670]
1015c5c00: 3d81a3e1    	str	q1, [sp, #0x680]
1015c5c04: 3dc0f7e0    	ldr	q0, [sp, #0x3d0]
1015c5c08: 3d81a7e0    	str	q0, [sp, #0x690]
1015c5c0c: ad5b87e0    	ldp	q0, q1, [sp, #0x370]
1015c5c10: 3d818fe0    	str	q0, [sp, #0x630]
1015c5c14: 3d8193e1    	str	q1, [sp, #0x640]
1015c5c18: ad5c83e1    	ldp	q1, q0, [sp, #0x390]
1015c5c1c: 3d819be0    	str	q0, [sp, #0x660]
1015c5c20: 3d8197e1    	str	q1, [sp, #0x650]
1015c5c24: 911a83e8    	add	x8, sp, #0x6a0
1015c5c28: 9118c3e0    	add	x0, sp, #0x630
1015c5c2c: aa1703e1    	mov	x1, x23
1015c5c30: aa1903e2    	mov	x2, x25
1015c5c34: 945e153a    	bl	0x102d4b11c <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrixNtB2_27OwnedSnapshotUnsignedMatrix20into_private_updates>
1015c5c38: f94353e8    	ldr	x8, [sp, #0x6a0]
1015c5c3c: b4001f48    	cbz	x8, 0x1015c6024 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x34b0>
1015c5c40: b946abe9    	ldr	w9, [sp, #0x6a8]
1015c5c44: 9118c3ea    	add	x10, sp, #0x630
1015c5c48: 3cc8c140    	ldur	q0, [x10, #0x8c]
1015c5c4c: 3cc9c141    	ldur	q1, [x10, #0x9c]
1015c5c50: 3ccac142    	ldur	q2, [x10, #0xac]
1015c5c54: 3d8167e1    	str	q1, [sp, #0x590]
1015c5c58: 3d816be2    	str	q2, [sp, #0x5a0]
1015c5c5c: 3ccb8141    	ldur	q1, [x10, #0xb8]
1015c5c60: 911483eb    	add	x11, sp, #0x520
1015c5c64: 3c88c161    	stur	q1, [x11, #0x8c]
1015c5c68: 3cc7c141    	ldur	q1, [x10, #0x7c]
1015c5c6c: 3d8163e0    	str	q0, [sp, #0x580]
1015c5c70: 3d815fe1    	str	q1, [sp, #0x570]
1015c5c74: 3ccc8340    	ldur	q0, [x26, #0xc8]
1015c5c78: 911043ea    	add	x10, sp, #0x410
1015c5c7c: 3c8c8140    	stur	q0, [x10, #0xc8]
1015c5c80: 3ccd8340    	ldur	q0, [x26, #0xd8]
1015c5c84: 3c8d8140    	stur	q0, [x10, #0xd8]
1015c5c88: 3cce8340    	ldur	q0, [x26, #0xe8]
1015c5c8c: 3c8e8140    	stur	q0, [x10, #0xe8]
1015c5c90: 3ccf8340    	ldur	q0, [x26, #0xf8]
1015c5c94: 3c8f8140    	stur	q0, [x10, #0xf8]
1015c5c98: 3cc88340    	ldur	q0, [x26, #0x88]
1015c5c9c: 3c888140    	stur	q0, [x10, #0x88]
1015c5ca0: 3cc98340    	ldur	q0, [x26, #0x98]
1015c5ca4: 3c898140    	stur	q0, [x10, #0x98]
1015c5ca8: 3cca8340    	ldur	q0, [x26, #0xa8]
1015c5cac: 3c8a8140    	stur	q0, [x10, #0xa8]
1015c5cb0: 3ccb8340    	ldur	q0, [x26, #0xb8]
1015c5cb4: 3c8b8140    	stur	q0, [x10, #0xb8]
1015c5cb8: 3cc58340    	ldur	q0, [x26, #0x58]
1015c5cbc: 3c858140    	stur	q0, [x10, #0x58]
1015c5cc0: 3cc68340    	ldur	q0, [x26, #0x68]
1015c5cc4: 3c868140    	stur	q0, [x10, #0x68]
1015c5cc8: 3cc78340    	ldur	q0, [x26, #0x78]
1015c5ccc: 3c878140    	stur	q0, [x10, #0x78]
1015c5cd0: 3cc8c160    	ldur	q0, [x11, #0x8c]
1015c5cd4: 3c83c160    	stur	q0, [x11, #0x3c]
1015c5cd8: 3dc16be0    	ldr	q0, [sp, #0x5a0]
1015c5cdc: 3dc167e1    	ldr	q1, [sp, #0x590]
1015c5ce0: 3d8157e0    	str	q0, [sp, #0x550]
1015c5ce4: 3d8153e1    	str	q1, [sp, #0x540]
1015c5ce8: 3dc163e0    	ldr	q0, [sp, #0x580]
1015c5cec: 3dc15fe2    	ldr	q2, [sp, #0x570]
1015c5cf0: 3d814fe0    	str	q0, [sp, #0x530]
1015c5cf4: 3d814be2    	str	q2, [sp, #0x520]
1015c5cf8: 3c81c140    	stur	q0, [x10, #0x1c]
1015c5cfc: 3c82c141    	stur	q1, [x10, #0x2c]
1015c5d00: 3c80c142    	stur	q2, [x10, #0xc]
1015c5d04: 3dc157e0    	ldr	q0, [sp, #0x550]
1015c5d08: 3c83c140    	stur	q0, [x10, #0x3c]
1015c5d0c: 3cc3c160    	ldur	q0, [x11, #0x3c]
1015c5d10: 3c848140    	stur	q0, [x10, #0x48]
1015c5d14: f9020be8    	str	x8, [sp, #0x410]
1015c5d18: b9041be9    	str	w9, [sp, #0x418]
1015c5d1c: f8786b61    	ldr	x1, [x27, x24]
1015c5d20: aa1503e0    	mov	x0, x21
1015c5d24: 97fe3926    	bl	0x1015541bc <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7prepare16readonly_numericNtB2_5Proof8capacity>
1015c5d28: f100041f    	cmp	x0, #0x1
1015c5d2c: 540021a1    	b.ne	0x1015c6160 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35ec>
1015c5d30: aa0103f5    	mov	x21, x1
1015c5d34: 911a83e8    	add	x8, sp, #0x6a0
1015c5d38: 911043e0    	add	x0, sp, #0x410
1015c5d3c: 945c89f8    	bl	0x102ce851c <__RNvMs0_NtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix7appendsNtB7_21PrivateUnsignedMatrix20reserved_native_view>
1015c5d40: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c5d44: 360041c8    	tbz	w8, #0x0, 0x1015c657c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a08>
1015c5d48: f94023e8    	ldr	x8, [sp, #0x40]
1015c5d4c: f942690a    	ldr	x10, [x8, #0x4d0]
1015c5d50: b400424a    	cbz	x10, 0x1015c6598 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a24>
1015c5d54: f8786b68    	ldr	x8, [x27, x24]
1015c5d58: f9405389    	ldr	x9, [x28, #0xa0]
1015c5d5c: 8b080928    	add	x8, x9, x8, lsl #2
1015c5d60: 91000d0b    	add	x11, x8, #0x3
1015c5d64: f94023e8    	ldr	x8, [sp, #0x40]
1015c5d68: f9426d08    	ldr	x8, [x8, #0x4d8]
1015c5d6c: eb08017f    	cmp	x11, x8
1015c5d70: 54004142    	b.hs	0x1015c6598 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a24>
1015c5d74: f94357f7    	ldr	x23, [sp, #0x6a8]
1015c5d78: f9435be9    	ldr	x9, [sp, #0x6b0]
1015c5d7c: f9435fe8    	ldr	x8, [sp, #0x6b8]
1015c5d80: f82b7949    	str	x9, [x10, x11, lsl #3]
1015c5d84: f94023ea    	ldr	x10, [sp, #0x40]
1015c5d88: f942694a    	ldr	x10, [x10, #0x4d0]
1015c5d8c: b400406a    	cbz	x10, 0x1015c6598 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a24>
1015c5d90: f8786b6b    	ldr	x11, [x27, x24]
1015c5d94: f940538c    	ldr	x12, [x28, #0xa0]
1015c5d98: 8b0b098b    	add	x11, x12, x11, lsl #2
1015c5d9c: 9100116b    	add	x11, x11, #0x4
1015c5da0: f94023ec    	ldr	x12, [sp, #0x40]
1015c5da4: f9426d8c    	ldr	x12, [x12, #0x4d8]
1015c5da8: eb0c017f    	cmp	x11, x12
1015c5dac: 54003f62    	b.hs	0x1015c6598 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a24>
1015c5db0: 5280002c    	mov	w12, #0x1               ; =1
1015c5db4: f82b794c    	str	x12, [x10, x11, lsl #3]
1015c5db8: f94023ea    	ldr	x10, [sp, #0x40]
1015c5dbc: f942694a    	ldr	x10, [x10, #0x4d0]
1015c5dc0: b4003eca    	cbz	x10, 0x1015c6598 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a24>
1015c5dc4: f8786b6b    	ldr	x11, [x27, x24]
1015c5dc8: f940538c    	ldr	x12, [x28, #0xa0]
1015c5dcc: 8b0b098b    	add	x11, x12, x11, lsl #2
1015c5dd0: 9100156b    	add	x11, x11, #0x5
1015c5dd4: f94023ec    	ldr	x12, [sp, #0x40]
1015c5dd8: f9426d8c    	ldr	x12, [x12, #0x4d8]
1015c5ddc: eb0c017f    	cmp	x11, x12
1015c5de0: 54003dc2    	b.hs	0x1015c6598 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a24>
1015c5de4: f82b7949    	str	x9, [x10, x11, lsl #3]
1015c5de8: f94023e9    	ldr	x9, [sp, #0x40]
1015c5dec: f9426929    	ldr	x9, [x9, #0x4d0]
1015c5df0: b4003d49    	cbz	x9, 0x1015c6598 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a24>
1015c5df4: 91000aaa    	add	x10, x21, #0x2
1015c5df8: f94023eb    	ldr	x11, [sp, #0x40]
1015c5dfc: f9426d6b    	ldr	x11, [x11, #0x4d8]
1015c5e00: eb0b015f    	cmp	x10, x11
1015c5e04: 54003ca2    	b.hs	0x1015c6598 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a24>
1015c5e08: f82a7928    	str	x8, [x9, x10, lsl #3]
1015c5e0c: 140000d9    	b	0x1015c6170 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35fc>
1015c5e10: b90002df    	str	wzr, [x22]
1015c5e14: 52800189    	mov	w9, #0xc                ; =12
1015c5e18: f90006c9    	str	x9, [x22, #0x8]
1015c5e1c: 9000d3a8    	adrp	x8, 0x103039000 <_anon.19b44b453da724831023c27de6e0b6f2.100+0xf48>
1015c5e20: 91256908    	add	x8, x8, #0x95a
1015c5e24: 52800609    	mov	w9, #0x30               ; =48
1015c5e28: a90126c8    	stp	x8, x9, [x22, #0x10]
1015c5e2c: 910dc3e0    	add	x0, sp, #0x370
1015c5e30: 97ff870d    	bl	0x1015a7a64 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrix27OwnedSnapshotUnsignedMatrixECs29QkOtpKx6e_8mech_gpu>
1015c5e34: b40000b9    	cbz	x25, 0x1015c5e48 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x32d4>
1015c5e38: d37df321    	lsl	x1, x25, #3
1015c5e3c: aa1703e0    	mov	x0, x23
1015c5e40: 52800102    	mov	w2, #0x8                ; =8
1015c5e44: 97a90dbe    	bl	0x10000953c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1015c5e48: 52800019    	mov	w25, #0x0               ; =0
1015c5e4c: 912083e0    	add	x0, sp, #0x820
1015c5e50: 97ff83f2    	bl	0x1015a6e18 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs29QkOtpKx6e_8mech_gpu>
1015c5e54: f94403e8    	ldr	x8, [sp, #0x800]
1015c5e58: 92800009    	mov	x9, #-0x1               ; =-1
1015c5e5c: f8690108    	ldaddl	x9, x8, [x8]
1015c5e60: f100051f    	cmp	x8, #0x1
1015c5e64: 54fe85e1    	b.ne	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c5e68: d50339bf    	dmb	ishld
1015c5e6c: 912003e0    	add	x0, sp, #0x800
1015c5e70: 945cb05e    	bl	0x102cf1fe8 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015c5e74: 17fff42b    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c5e78: b0012060    	adrp	x0, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c5e7c: 91146000    	add	x0, x0, #0x518
1015c5e80: 9460b5b1    	bl	0x102df3544 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1015c5e84: b0012060    	adrp	x0, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c5e88: 9114c000    	add	x0, x0, #0x530
1015c5e8c: 9460b5ae    	bl	0x102df3544 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1015c5e90: 910f02b3    	add	x19, x21, #0x3c0
1015c5e94: aa1303e0    	mov	x0, x19
1015c5e98: 97ff7bcf    	bl	0x1015a4dd4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel5BatchEEB1e_>
1015c5e9c: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1015c5ea0: f9000268    	str	x8, [x19]
1015c5ea4: 52800028    	mov	w8, #0x1                ; =1
1015c5ea8: 4e080d00    	dup.2d	v0, x8
1015c5eac: 17fff552    	b	0x1015c33f4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x880>
1015c5eb0: 911a83e0    	add	x0, sp, #0x6a0
1015c5eb4: f94023e1    	ldr	x1, [sp, #0x40]
1015c5eb8: aa1503e2    	mov	x2, x21
1015c5ebc: 52800243    	mov	w3, #0x12               ; =18
1015c5ec0: 52800104    	mov	w4, #0x8                ; =8
1015c5ec4: d2800005    	mov	x5, #0x0                ; =0
1015c5ec8: 97ffa436    	bl	0x1015aefa0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action>
1015c5ecc: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c5ed0: 7100191f    	cmp	w8, #0x6
1015c5ed4: 54000341    	b.ne	0x1015c5f3c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x33c8>
1015c5ed8: f94357e8    	ldr	x8, [sp, #0x6a8]
1015c5edc: f100091f    	cmp	x8, #0x2
1015c5ee0: 54001e41    	b.ne	0x1015c62a8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3734>
1015c5ee4: f941be81    	ldr	x1, [x20, #0x378]
1015c5ee8: eb0102bf    	cmp	x21, x1
1015c5eec: 540107a2    	b.hs	0x1015c7fe0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x546c>
1015c5ef0: f941ba88    	ldr	x8, [x20, #0x370]
1015c5ef4: 52802e09    	mov	w9, #0x170              ; =368
1015c5ef8: 9b0922b3    	madd	x19, x21, x9, x8
1015c5efc: a9402269    	ldp	x9, x8, [x19]
1015c5f00: d2400529    	eor	x9, x9, #0x3
1015c5f04: aa080128    	orr	x8, x9, x8
1015c5f08: b50038c8    	cbnz	x8, 0x1015c6620 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3aac>
1015c5f0c: f9401277    	ldr	x23, [x19, #0x20]
1015c5f10: b27fe7e8    	mov	x8, #0x7fffffffffffffe  ; =576460752303423486
1015c5f14: eb0802ff    	cmp	x23, x8
1015c5f18: 540047e3    	b.lo	0x1015c6814 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ca0>
1015c5f1c: f94027e8    	ldr	x8, [sp, #0x48]
1015c5f20: b900011f    	str	wzr, [x8]
1015c5f24: 52800189    	mov	w9, #0xc                ; =12
1015c5f28: f000d38a    	adrp	x10, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c5f2c: 9132214a    	add	x10, x10, #0xc88
1015c5f30: a900a909    	stp	x9, x10, [x8, #0x8]
1015c5f34: 52800489    	mov	w9, #0x24               ; =36
1015c5f38: 17fff3f9    	b	0x1015c2f1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a8>
1015c5f3c: b946a7e9    	ldr	w9, [sp, #0x6a4]
1015c5f40: 3cc18340    	ldur	q0, [x26, #0x18]
1015c5f44: f94027ea    	ldr	x10, [sp, #0x48]
1015c5f48: 3c818140    	stur	q0, [x10, #0x18]
1015c5f4c: 3cc28340    	ldur	q0, [x26, #0x28]
1015c5f50: 3c828140    	stur	q0, [x10, #0x28]
1015c5f54: 3cc38340    	ldur	q0, [x26, #0x38]
1015c5f58: 3c838140    	stur	q0, [x10, #0x38]
1015c5f5c: f94377eb    	ldr	x11, [sp, #0x6e8]
1015c5f60: f900254b    	str	x11, [x10, #0x48]
1015c5f64: 3cc08340    	ldur	q0, [x26, #0x8]
1015c5f68: 29002548    	stp	w8, w9, [x10]
1015c5f6c: 3c808140    	stur	q0, [x10, #0x8]
1015c5f70: 17fff3ec    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c5f74: f94027e8    	ldr	x8, [sp, #0x48]
1015c5f78: b900011f    	str	wzr, [x8]
1015c5f7c: 52800189    	mov	w9, #0xc                ; =12
1015c5f80: 39002109    	strb	w9, [x8, #0x8]
1015c5f84: d000d3a9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c5f88: 911bd929    	add	x9, x9, #0x6f6
1015c5f8c: 5280048a    	mov	w10, #0x24              ; =36
1015c5f90: 17fff353    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c5f94: f000d388    	adrp	x8, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c5f98: 91368908    	add	x8, x8, #0xda2
1015c5f9c: b900031f    	str	wzr, [x24]
1015c5fa0: 52800189    	mov	w9, #0xc                ; =12
1015c5fa4: a900a309    	stp	x9, x8, [x24, #0x8]
1015c5fa8: 528003c8    	mov	w8, #0x1e               ; =30
1015c5fac: f9000f08    	str	x8, [x24, #0x18]
1015c5fb0: f94353e8    	ldr	x8, [sp, #0x6a0]
1015c5fb4: 92800009    	mov	x9, #-0x1               ; =-1
1015c5fb8: f8690108    	ldaddl	x9, x8, [x8]
1015c5fbc: f100051f    	cmp	x8, #0x1
1015c5fc0: 54fe7b01    	b.ne	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c5fc4: d50339bf    	dmb	ishld
1015c5fc8: 911a83e0    	add	x0, sp, #0x6a0
1015c5fcc: 945cb007    	bl	0x102cf1fe8 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015c5fd0: 17fff3d4    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c5fd4: f94023e8    	ldr	x8, [sp, #0x40]
1015c5fd8: f902e3e8    	str	x8, [sp, #0x5c0]
1015c5fdc: 3dc00260    	ldr	q0, [x19]
1015c5fe0: 3d81abe0    	str	q0, [sp, #0x6a0]
1015c5fe4: 9118c3e8    	add	x8, sp, #0x630
1015c5fe8: 911043e0    	add	x0, sp, #0x410
1015c5fec: 911703e1    	add	x1, sp, #0x5c0
1015c5ff0: 911a83e3    	add	x3, sp, #0x6a0
1015c5ff4: aa1503e2    	mov	x2, x21
1015c5ff8: 97fe3fe7    	bl	0x101555f94 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime11collectionsNtB2_5State6helper>
1015c5ffc: d2800014    	mov	x20, #0x0               ; =0
1015c6000: 140000bd    	b	0x1015c62f4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3780>
1015c6004: f94027e8    	ldr	x8, [sp, #0x48]
1015c6008: b900011f    	str	wzr, [x8]
1015c600c: 52800189    	mov	w9, #0xc                ; =12
1015c6010: 39002109    	strb	w9, [x8, #0x8]
1015c6014: b000d3a9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c6018: 91199129    	add	x9, x9, #0x664
1015c601c: 5280024a    	mov	w10, #0x12              ; =18
1015c6020: 17fff32f    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c6024: 911a83e8    	add	x8, sp, #0x6a0
1015c6028: 3cc08100    	ldur	q0, [x8, #0x8]
1015c602c: 9118c3e9    	add	x9, sp, #0x630
1015c6030: 3c804120    	stur	q0, [x9, #0x4]
1015c6034: 3cc18100    	ldur	q0, [x8, #0x18]
1015c6038: 3c814120    	stur	q0, [x9, #0x14]
1015c603c: 3cc28100    	ldur	q0, [x8, #0x28]
1015c6040: 3c824120    	stur	q0, [x9, #0x24]
1015c6044: 3cc38100    	ldur	q0, [x8, #0x38]
1015c6048: 3c834120    	stur	q0, [x9, #0x34]
1015c604c: f8448108    	ldur	x8, [x8, #0x48]
1015c6050: f8044128    	stur	x8, [x9, #0x44]
1015c6054: 3dc197e0    	ldr	q0, [sp, #0x650]
1015c6058: 3dc19be1    	ldr	q1, [sp, #0x660]
1015c605c: 3d8167e0    	str	q0, [sp, #0x590]
1015c6060: 3d816be1    	str	q1, [sp, #0x5a0]
1015c6064: 3cc3c120    	ldur	q0, [x9, #0x3c]
1015c6068: 911483e8    	add	x8, sp, #0x520
1015c606c: 3c88c100    	stur	q0, [x8, #0x8c]
1015c6070: 3dc193e0    	ldr	q0, [sp, #0x640]
1015c6074: 3dc18fe1    	ldr	q1, [sp, #0x630]
1015c6078: 3d8163e0    	str	q0, [sp, #0x580]
1015c607c: 3d815fe1    	str	q1, [sp, #0x570]
1015c6080: 3dc15fe0    	ldr	q0, [sp, #0x570]
1015c6084: 3dc163e1    	ldr	q1, [sp, #0x580]
1015c6088: 3cc8c102    	ldur	q2, [x8, #0x8c]
1015c608c: 3c83c102    	stur	q2, [x8, #0x3c]
1015c6090: 3dc167e2    	ldr	q2, [sp, #0x590]
1015c6094: 3dc16be3    	ldr	q3, [sp, #0x5a0]
1015c6098: 3d8157e3    	str	q3, [sp, #0x550]
1015c609c: 3d8153e2    	str	q2, [sp, #0x540]
1015c60a0: 3d814be0    	str	q0, [sp, #0x520]
1015c60a4: 3d814fe1    	str	q1, [sp, #0x530]
1015c60a8: 3dc14fe0    	ldr	q0, [sp, #0x530]
1015c60ac: 3dc14be1    	ldr	q1, [sp, #0x520]
1015c60b0: 3c8142c0    	stur	q0, [x22, #0x14]
1015c60b4: 3dc153e0    	ldr	q0, [sp, #0x540]
1015c60b8: 3dc157e2    	ldr	q2, [sp, #0x550]
1015c60bc: 3c8242c0    	stur	q0, [x22, #0x24]
1015c60c0: 3c8342c2    	stur	q2, [x22, #0x34]
1015c60c4: 3cc3c100    	ldur	q0, [x8, #0x3c]
1015c60c8: 3d8012c0    	str	q0, [x22, #0x40]
1015c60cc: 3c8042c1    	stur	q1, [x22, #0x4]
1015c60d0: 528000a8    	mov	w8, #0x5                ; =5
1015c60d4: b90002c8    	str	w8, [x22]
1015c60d8: 17ffff5c    	b	0x1015c5e48 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x32d4>
1015c60dc: f9001bff    	str	xzr, [sp, #0x30]
1015c60e0: a94427ef    	ldp	x15, x9, [sp, #0x40]
1015c60e4: d37ef52b    	lsl	x11, x9, #2
1015c60e8: 8b0b01e9    	add	x9, x15, x11
1015c60ec: f90013e9    	str	x9, [sp, #0x20]
1015c60f0: f942c50c    	ldr	x12, [x8, #0x588]
1015c60f4: f942c10d    	ldr	x13, [x8, #0x580]
1015c60f8: 52800188    	mov	w8, #0xc                ; =12
1015c60fc: 52800529    	mov	w9, #0x29               ; =41
1015c6100: 52800b0e    	mov	w14, #0x58              ; =88
1015c6104: d000d38a    	adrp	x10, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c6108: 9137014a    	add	x10, x10, #0xdc0
1015c610c: f9401bf0    	ldr	x16, [sp, #0x30]
1015c6110: b4001feb    	cbz	x11, 0x1015c650c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3998>
1015c6114: b84045f1    	ldr	w17, [x15], #0x4
1015c6118: eb11019f    	cmp	x12, x17
1015c611c: 540001a9    	b.ls	0x1015c6150 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35dc>
1015c6120: 9bae3631    	umaddl	x17, w17, w14, x13
1015c6124: f9400631    	ldr	x17, [x17, #0x8]
1015c6128: d100116b    	sub	x11, x11, #0x4
1015c612c: f9401be0    	ldr	x0, [sp, #0x30]
1015c6130: ab000220    	adds	x0, x17, x0
1015c6134: f9001be0    	str	x0, [sp, #0x30]
1015c6138: 54fffea3    	b.lo	0x1015c610c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3598>
1015c613c: 9278de08    	and	x8, x16, #0xffffffffffffff00
1015c6140: b27e0508    	orr	x8, x8, #0xc
1015c6144: d000d38a    	adrp	x10, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c6148: 9137a54a    	add	x10, x10, #0xde9
1015c614c: 528003e9    	mov	w9, #0x1f               ; =31
1015c6150: b900031f    	str	wzr, [x24]
1015c6154: a900ab08    	stp	x8, x10, [x24, #0x8]
1015c6158: f9000f09    	str	x9, [x24, #0x18]
1015c615c: 140002cb    	b	0x1015c6c88 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4114>
1015c6160: 911a83e8    	add	x8, sp, #0x6a0
1015c6164: 911043e0    	add	x0, sp, #0x410
1015c6168: 945c7f50    	bl	0x102ce5ea8 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix12elements_mut>
1015c616c: f94357f7    	ldr	x23, [sp, #0x6a8]
1015c6170: 911a83e0    	add	x0, sp, #0x6a0
1015c6174: 911043e1    	add	x1, sp, #0x410
1015c6178: 52802102    	mov	w2, #0x108              ; =264
1015c617c: 9460ba87    	bl	0x102df4b98 <dyld_stub_binder+0x102df4b98>
1015c6180: f94023e8    	ldr	x8, [sp, #0x40]
1015c6184: f9424908    	ldr	x8, [x8, #0x490]
1015c6188: f941e108    	ldr	x8, [x8, #0x3c0]
1015c618c: b40007a8    	cbz	x8, 0x1015c6280 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x370c>
1015c6190: f9402109    	ldr	x9, [x8, #0x40]
1015c6194: f100093f    	cmp	x9, #0x2
1015c6198: 54000740    	b.eq	0x1015c6280 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x370c>
1015c619c: f9406d09    	ldr	x9, [x8, #0xd8]
1015c61a0: eb13013f    	cmp	x9, x19
1015c61a4: 540006e1    	b.ne	0x1015c6280 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x370c>
1015c61a8: f8786b69    	ldr	x9, [x27, x24]
1015c61ac: f9403d0a    	ldr	x10, [x8, #0x78]
1015c61b0: eb0a013f    	cmp	x9, x10
1015c61b4: 54000662    	b.hs	0x1015c6280 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x370c>
1015c61b8: f9403908    	ldr	x8, [x8, #0x70]
1015c61bc: 5280210a    	mov	w10, #0x108             ; =264
1015c61c0: 9b0a2135    	madd	x21, x9, x10, x8
1015c61c4: aa1503e0    	mov	x0, x21
1015c61c8: 97ff7ae5    	bl	0x1015a4d5c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixEECs29QkOtpKx6e_8mech_gpu>
1015c61cc: 911a83e1    	add	x1, sp, #0x6a0
1015c61d0: aa1503e0    	mov	x0, x21
1015c61d4: 52802102    	mov	w2, #0x108              ; =264
1015c61d8: 9460ba70    	bl	0x102df4b98 <dyld_stub_binder+0x102df4b98>
1015c61dc: f94023e8    	ldr	x8, [sp, #0x40]
1015c61e0: f9426908    	ldr	x8, [x8, #0x4d0]
1015c61e4: b40046a8    	cbz	x8, 0x1015c6ab8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3f44>
1015c61e8: f8786b69    	ldr	x9, [x27, x24]
1015c61ec: f940538a    	ldr	x10, [x28, #0xa0]
1015c61f0: 8b090949    	add	x9, x10, x9, lsl #2
1015c61f4: 91000929    	add	x9, x9, #0x2
1015c61f8: f94023ea    	ldr	x10, [sp, #0x40]
1015c61fc: f9426d4a    	ldr	x10, [x10, #0x4d8]
1015c6200: eb0a013f    	cmp	x9, x10
1015c6204: 540045a2    	b.hs	0x1015c6ab8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3f44>
1015c6208: f8297917    	str	x23, [x8, x9, lsl #3]
1015c620c: f94023e8    	ldr	x8, [sp, #0x40]
1015c6210: f9426908    	ldr	x8, [x8, #0x4d0]
1015c6214: b4004528    	cbz	x8, 0x1015c6ab8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3f44>
1015c6218: f8786b69    	ldr	x9, [x27, x24]
1015c621c: f9401b8a    	ldr	x10, [x28, #0x30]
1015c6220: f940538b    	ldr	x11, [x28, #0xa0]
1015c6224: 8b0a0929    	add	x9, x9, x10, lsl #2
1015c6228: 8b0b0129    	add	x9, x9, x11
1015c622c: 91000929    	add	x9, x9, #0x2
1015c6230: f94023ea    	ldr	x10, [sp, #0x40]
1015c6234: f9426d4a    	ldr	x10, [x10, #0x4d8]
1015c6238: eb0a013f    	cmp	x9, x10
1015c623c: 540043e2    	b.hs	0x1015c6ab8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3f44>
1015c6240: 5280002a    	mov	w10, #0x1               ; =1
1015c6244: f829790a    	str	x10, [x8, x9, lsl #3]
1015c6248: 911a83e0    	add	x0, sp, #0x6a0
1015c624c: f94023e1    	ldr	x1, [sp, #0x40]
1015c6250: aa1303e2    	mov	x2, x19
1015c6254: aa1403e3    	mov	x3, x20
1015c6258: 97ffc039    	bl	0x1015b633c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation26resume_numeric_after_write>
1015c625c: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c6260: 7100191f    	cmp	w8, #0x6
1015c6264: 540055e1    	b.ne	0x1015c6d20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41ac>
1015c6268: f90006df    	str	xzr, [x22, #0x8]
1015c626c: b90002c8    	str	w8, [x22]
1015c6270: 52800019    	mov	w25, #0x0               ; =0
1015c6274: 912083e0    	add	x0, sp, #0x820
1015c6278: 97ff82e8    	bl	0x1015a6e18 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs29QkOtpKx6e_8mech_gpu>
1015c627c: 17fffef6    	b	0x1015c5e54 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x32e0>
1015c6280: b90002df    	str	wzr, [x22]
1015c6284: 52800188    	mov	w8, #0xc                ; =12
1015c6288: f000d389    	adrp	x9, 0x103039000 <_anon.19b44b453da724831023c27de6e0b6f2.100+0xf48>
1015c628c: 911d0d29    	add	x9, x9, #0x743
1015c6290: a900a6c8    	stp	x8, x9, [x22, #0x8]
1015c6294: 52800568    	mov	w8, #0x2b               ; =43
1015c6298: f9000ec8    	str	x8, [x22, #0x18]
1015c629c: 911a83e0    	add	x0, sp, #0x6a0
1015c62a0: 97ff7aaf    	bl	0x1015a4d5c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixEECs29QkOtpKx6e_8mech_gpu>
1015c62a4: 17fffee9    	b	0x1015c5e48 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x32d4>
1015c62a8: 3cc08340    	ldur	q0, [x26, #0x8]
1015c62ac: f94023e8    	ldr	x8, [sp, #0x40]
1015c62b0: f9424908    	ldr	x8, [x8, #0x490]
1015c62b4: 52800029    	mov	w9, #0x1                ; =1
1015c62b8: 39118109    	strb	w9, [x8, #0x460]
1015c62bc: f94027e8    	ldr	x8, [sp, #0x48]
1015c62c0: 3c808100    	stur	q0, [x8, #0x8]
1015c62c4: 17fff9d6    	b	0x1015c4a1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ea8>
1015c62c8: 3dc1b3e0    	ldr	q0, [sp, #0x6c0]
1015c62cc: 3dc1b7e1    	ldr	q1, [sp, #0x6d0]
1015c62d0: 3d8197e0    	str	q0, [sp, #0x650]
1015c62d4: 3d819be1    	str	q1, [sp, #0x660]
1015c62d8: 3dc1bbe0    	ldr	q0, [sp, #0x6e0]
1015c62dc: 3d819fe0    	str	q0, [sp, #0x670]
1015c62e0: 3dc1afe0    	ldr	q0, [sp, #0x6b0]
1015c62e4: 3dc1abe1    	ldr	q1, [sp, #0x6a0]
1015c62e8: 3d8193e0    	str	q0, [sp, #0x640]
1015c62ec: 3d818fe1    	str	q1, [sp, #0x630]
1015c62f0: d37ffa94    	lsl	x20, x20, #1
1015c62f4: 911a83e0    	add	x0, sp, #0x6a0
1015c62f8: 911043e1    	add	x1, sp, #0x410
1015c62fc: 52802102    	mov	w2, #0x108              ; =264
1015c6300: 9460ba26    	bl	0x102df4b98 <dyld_stub_binder+0x102df4b98>
1015c6304: f94023e8    	ldr	x8, [sp, #0x40]
1015c6308: f9424908    	ldr	x8, [x8, #0x490]
1015c630c: f940f109    	ldr	x9, [x8, #0x1e0]
1015c6310: d2f0000a    	mov	x10, #-0x8000000000000000 ; =-9223372036854775808
1015c6314: eb0a013f    	cmp	x9, x10
1015c6318: 540000a0    	b.eq	0x1015c632c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x37b8>
1015c631c: 91078100    	add	x0, x8, #0x1e0
1015c6320: 97ff86ae    	bl	0x1015a7dd8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime11collections5StateEBQ_>
1015c6324: f94023e8    	ldr	x8, [sp, #0x40]
1015c6328: f9424908    	ldr	x8, [x8, #0x490]
1015c632c: 91078100    	add	x0, x8, #0x1e0
1015c6330: 911a83e1    	add	x1, sp, #0x6a0
1015c6334: 52802102    	mov	w2, #0x108              ; =264
1015c6338: 9460ba18    	bl	0x102df4b98 <dyld_stub_binder+0x102df4b98>
1015c633c: b94633ea    	ldr	w10, [sp, #0x630]
1015c6340: f9431fe9    	ldr	x9, [sp, #0x638]
1015c6344: f94323e8    	ldr	x8, [sp, #0x640]
1015c6348: 7100195f    	cmp	w10, #0x6
1015c634c: 540002c1    	b.ne	0x1015c63a4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3830>
1015c6350: 71001edf    	cmp	w22, #0x7
1015c6354: 54000161    	b.ne	0x1015c6380 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x380c>
1015c6358: 36000149    	tbz	w9, #0x0, 0x1015c6380 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x380c>
1015c635c: f100051f    	cmp	x8, #0x1
1015c6360: 54000101    	b.ne	0x1015c6380 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x380c>
1015c6364: f94023ea    	ldr	x10, [sp, #0x40]
1015c6368: f9425d41    	ldr	x1, [x10, #0x4b8]
1015c636c: eb01029f    	cmp	x20, x1
1015c6370: 5400e202    	b.hs	0x1015c7fb0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x543c>
1015c6374: f94023ea    	ldr	x10, [sp, #0x40]
1015c6378: f942594a    	ldr	x10, [x10, #0x4b0]
1015c637c: f834795f    	str	xzr, [x10, x20, lsl #3]
1015c6380: f94023ea    	ldr	x10, [sp, #0x40]
1015c6384: f942494a    	ldr	x10, [x10, #0x490]
1015c6388: 5280002b    	mov	w11, #0x1               ; =1
1015c638c: 3911814b    	strb	w11, [x10, #0x460]
1015c6390: f94027ea    	ldr	x10, [sp, #0x48]
1015c6394: a900a149    	stp	x9, x8, [x10, #0x8]
1015c6398: 528000c8    	mov	w8, #0x6                ; =6
1015c639c: b9000148    	str	w8, [x10]
1015c63a0: 17fff2e0    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c63a4: b94637eb    	ldr	w11, [sp, #0x634]
1015c63a8: 9118c3ec    	add	x12, sp, #0x630
1015c63ac: 3cc18180    	ldur	q0, [x12, #0x18]
1015c63b0: f94027ed    	ldr	x13, [sp, #0x48]
1015c63b4: 3c8181a0    	stur	q0, [x13, #0x18]
1015c63b8: 3cc28180    	ldur	q0, [x12, #0x28]
1015c63bc: 3c8281a0    	stur	q0, [x13, #0x28]
1015c63c0: 3cc38180    	ldur	q0, [x12, #0x38]
1015c63c4: 3c8381a0    	stur	q0, [x13, #0x38]
1015c63c8: f9433fec    	ldr	x12, [sp, #0x678]
1015c63cc: f90025ac    	str	x12, [x13, #0x48]
1015c63d0: 29002daa    	stp	w10, w11, [x13]
1015c63d4: a900a1a9    	stp	x9, x8, [x13, #0x8]
1015c63d8: 17fff2d2    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c63dc: eb01001f    	cmp	x0, x1
1015c63e0: 5400e082    	b.hs	0x1015c7ff0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x547c>
1015c63e4: f9419288    	ldr	x8, [x20, #0x320]
1015c63e8: 5280380a    	mov	w10, #0x1c0             ; =448
1015c63ec: 9b0a2008    	madd	x8, x0, x10, x8
1015c63f0: 9106e10a    	add	x10, x8, #0x1b8
1015c63f4: b9400141    	ldr	w1, [x10]
1015c63f8: 39449108    	ldrb	w8, [x8, #0x124]
1015c63fc: 71001d1f    	cmp	w8, #0x7
1015c6400: 54000301    	b.ne	0x1015c6460 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x38ec>
1015c6404: 911a83e8    	add	x8, sp, #0x6a0
1015c6408: 9103c120    	add	x0, x9, #0xf0
1015c640c: 910be122    	add	x2, x9, #0x2f8
1015c6410: 9400123e    	bl	0x1015cad08 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
1015c6414: 3cc08340    	ldur	q0, [x26, #0x8]
1015c6418: 3cc18341    	ldur	q1, [x26, #0x18]
1015c641c: ad0f87e0    	stp	q0, q1, [sp, #0x1f0]
1015c6420: 3cc28340    	ldur	q0, [x26, #0x28]
1015c6424: 3d8087e0    	str	q0, [sp, #0x210]
1015c6428: f94353e8    	ldr	x8, [sp, #0x6a0]
1015c642c: f9436fe9    	ldr	x9, [sp, #0x6d8]
1015c6430: f90113e9    	str	x9, [sp, #0x220]
1015c6434: b4001ae8    	cbz	x8, 0x1015c6790 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c1c>
1015c6438: ad4f87e0    	ldp	q0, q1, [sp, #0x1f0]
1015c643c: 9118c3e9    	add	x9, sp, #0x630
1015c6440: 3c808120    	stur	q0, [x9, #0x8]
1015c6444: 3c818121    	stur	q1, [x9, #0x18]
1015c6448: 3dc087e0    	ldr	q0, [sp, #0x210]
1015c644c: 3c828120    	stur	q0, [x9, #0x28]
1015c6450: f94113e9    	ldr	x9, [sp, #0x220]
1015c6454: f90337e9    	str	x9, [sp, #0x668]
1015c6458: f9031be8    	str	x8, [sp, #0x630]
1015c645c: 14000011    	b	0x1015c64a0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x392c>
1015c6460: f9400262    	ldr	x2, [x19]
1015c6464: 911a83e8    	add	x8, sp, #0x6a0
1015c6468: f94023e0    	ldr	x0, [sp, #0x40]
1015c646c: 94000a58    	bl	0x1015c8dcc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6scalar>
1015c6470: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c6474: 7100191f    	cmp	w8, #0x6
1015c6478: 54000e41    	b.ne	0x1015c6640 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3acc>
1015c647c: 3cc28340    	ldur	q0, [x26, #0x28]
1015c6480: 3c8242e0    	stur	q0, [x23, #0x24]
1015c6484: 3cc38341    	ldur	q1, [x26, #0x38]
1015c6488: 3cc18342    	ldur	q2, [x26, #0x18]
1015c648c: 3cc08343    	ldur	q3, [x26, #0x8]
1015c6490: 3d818fe3    	str	q3, [sp, #0x630]
1015c6494: 3d8193e2    	str	q2, [sp, #0x640]
1015c6498: 3d8197e0    	str	q0, [sp, #0x650]
1015c649c: 3d819be1    	str	q1, [sp, #0x660]
1015c64a0: f941ae8a    	ldr	x10, [x20, #0x358]
1015c64a4: f94023e8    	ldr	x8, [sp, #0x40]
1015c64a8: f9424909    	ldr	x9, [x8, #0x490]
1015c64ac: f9422d28    	ldr	x8, [x9, #0x458]
1015c64b0: 8b0a0101    	add	x1, x8, x10
1015c64b4: eb0a003f    	cmp	x1, x10
1015c64b8: 54000a23    	b.lo	0x1015c65fc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a88>
1015c64bc: d360fc28    	lsr	x8, x1, #32
1015c64c0: b50009e8    	cbnz	x8, 0x1015c65fc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a88>
1015c64c4: 911a83e8    	add	x8, sp, #0x6a0
1015c64c8: 9103c120    	add	x0, x9, #0xf0
1015c64cc: 9118c3e2    	add	x2, sp, #0x630
1015c64d0: 910be123    	add	x3, x9, #0x2f8
1015c64d4: 940018d0    	bl	0x1015cc814 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena3put>
1015c64d8: 395a83e8    	ldrb	w8, [sp, #0x6a0]
1015c64dc: 7100511f    	cmp	w8, #0x14
1015c64e0: 54001741    	b.ne	0x1015c67c8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c54>
1015c64e4: f94023e8    	ldr	x8, [sp, #0x40]
1015c64e8: f9424908    	ldr	x8, [x8, #0x490]
1015c64ec: f9422d09    	ldr	x9, [x8, #0x458]
1015c64f0: 91000529    	add	x9, x9, #0x1
1015c64f4: f9022d09    	str	x9, [x8, #0x458]
1015c64f8: f94027e8    	ldr	x8, [sp, #0x48]
1015c64fc: f900051f    	str	xzr, [x8, #0x8]
1015c6500: 528000c9    	mov	w9, #0x6                ; =6
1015c6504: b9000109    	str	w9, [x8]
1015c6508: 140000c0    	b	0x1015c6808 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c94>
1015c650c: 52800908    	mov	w8, #0x48               ; =72
1015c6510: d2800909    	mov	x9, #0x48               ; =72
1015c6514: 9b0826a8    	madd	x8, x21, x8, x9
1015c6518: f9401be9    	ldr	x9, [sp, #0x30]
1015c651c: 9bc87d29    	umulh	x9, x9, x8
1015c6520: eb0903ff    	cmp	xzr, x9
1015c6524: 5400a4e1    	b.ne	0x1015c79c0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4e4c>
1015c6528: f9401be9    	ldr	x9, [sp, #0x30]
1015c652c: 9b087d28    	mul	x8, x9, x8
1015c6530: 5280b009    	mov	w9, #0x580              ; =1408
1015c6534: d280800a    	mov	x10, #0x400             ; =1024
1015c6538: 9b092aa9    	madd	x9, x21, x9, x10
1015c653c: ab090108    	adds	x8, x8, x9
1015c6540: f90017e8    	str	x8, [sp, #0x28]
1015c6544: 5400a482    	b.hs	0x1015c79d4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4e60>
1015c6548: 92804008    	mov	x8, #-0x201             ; =-513
1015c654c: f2e3ffe8    	movk	x8, #0x1fff, lsl #48
1015c6550: f94017e9    	ldr	x9, [sp, #0x28]
1015c6554: eb08013f    	cmp	x9, x8
1015c6558: 54000a69    	b.ls	0x1015c66a4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3b30>
1015c655c: b900031f    	str	wzr, [x24]
1015c6560: 52800188    	mov	w8, #0xc                ; =12
1015c6564: d000d389    	adrp	x9, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c6568: 91388929    	add	x9, x9, #0xe22
1015c656c: a900a708    	stp	x8, x9, [x24, #0x8]
1015c6570: 528002e8    	mov	w8, #0x17               ; =23
1015c6574: f9000f08    	str	x8, [x24, #0x18]
1015c6578: 140001c4    	b	0x1015c6c88 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4114>
1015c657c: b90002df    	str	wzr, [x22]
1015c6580: 52800189    	mov	w9, #0xc                ; =12
1015c6584: b000d38a    	adrp	x10, 0x103037000 <_anon.496f237bd13ceadd644cb7ae086b3546.176+0x13b>
1015c6588: 913b1d4a    	add	x10, x10, #0xec7
1015c658c: a900aac9    	stp	x9, x10, [x22, #0x8]
1015c6590: 52800508    	mov	w8, #0x28               ; =40
1015c6594: 14000008    	b	0x1015c65b4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a40>
1015c6598: b90002df    	str	wzr, [x22]
1015c659c: 52800189    	mov	w9, #0xc                ; =12
1015c65a0: 390022c9    	strb	w9, [x22, #0x8]
1015c65a4: 9000d3a9    	adrp	x9, 0x10303a000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x3b8>
1015c65a8: 910bb929    	add	x9, x9, #0x2ee
1015c65ac: f9000ac9    	str	x9, [x22, #0x10]
1015c65b0: 52800528    	mov	w8, #0x29               ; =41
1015c65b4: f9000ec8    	str	x8, [x22, #0x18]
1015c65b8: 911043e0    	add	x0, sp, #0x410
1015c65bc: 97ff8579    	bl	0x1015a7ba0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixECs29QkOtpKx6e_8mech_gpu>
1015c65c0: 17fffe22    	b	0x1015c5e48 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x32d4>
1015c65c4: 3cc15340    	ldur	q0, [x26, #0x15]
1015c65c8: f94027ea    	ldr	x10, [sp, #0x48]
1015c65cc: 3c815140    	stur	q0, [x10, #0x15]
1015c65d0: 3cc25340    	ldur	q0, [x26, #0x25]
1015c65d4: 3c825140    	stur	q0, [x10, #0x25]
1015c65d8: 3cc35340    	ldur	q0, [x26, #0x35]
1015c65dc: 3c835140    	stur	q0, [x10, #0x35]
1015c65e0: 3dc1bbe0    	ldr	q0, [sp, #0x6e0]
1015c65e4: 3d801140    	str	q0, [x10, #0x40]
1015c65e8: 3cc05340    	ldur	q0, [x26, #0x5]
1015c65ec: 3c805140    	stur	q0, [x10, #0x5]
1015c65f0: b9000149    	str	w9, [x10]
1015c65f4: 39001148    	strb	w8, [x10, #0x4]
1015c65f8: 17fff24a    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c65fc: f94027e8    	ldr	x8, [sp, #0x48]
1015c6600: b900011f    	str	wzr, [x8]
1015c6604: 52800189    	mov	w9, #0xc                ; =12
1015c6608: 39002109    	strb	w9, [x8, #0x8]
1015c660c: d000d389    	adrp	x9, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c6610: 91355929    	add	x9, x9, #0xd56
1015c6614: 5280034a    	mov	w10, #0x1a              ; =26
1015c6618: a9012909    	stp	x9, x10, [x8, #0x10]
1015c661c: 1400007b    	b	0x1015c6808 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c94>
1015c6620: f94027e8    	ldr	x8, [sp, #0x48]
1015c6624: b900011f    	str	wzr, [x8]
1015c6628: 52800189    	mov	w9, #0xc                ; =12
1015c662c: 39002109    	strb	w9, [x8, #0x8]
1015c6630: b000d3a9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c6634: 911fb529    	add	x9, x9, #0x7ed
1015c6638: 5280064a    	mov	w10, #0x32              ; =50
1015c663c: 17fff1a8    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c6640: 3cc14340    	ldur	q0, [x26, #0x14]
1015c6644: 3cc24341    	ldur	q1, [x26, #0x24]
1015c6648: 3cc34342    	ldur	q2, [x26, #0x34]
1015c664c: 3d810fe1    	str	q1, [sp, #0x430]
1015c6650: 3d8113e2    	str	q2, [sp, #0x440]
1015c6654: b946e7e9    	ldr	w9, [sp, #0x6e4]
1015c6658: b90453e9    	str	w9, [sp, #0x450]
1015c665c: 3cc04343    	ldur	q3, [x26, #0x4]
1015c6660: 3d810be0    	str	q0, [sp, #0x420]
1015c6664: 3d8107e3    	str	q3, [sp, #0x410]
1015c6668: f94377ea    	ldr	x10, [sp, #0x6e8]
1015c666c: f94027eb    	ldr	x11, [sp, #0x48]
1015c6670: 3c814160    	stur	q0, [x11, #0x14]
1015c6674: 3c824161    	stur	q1, [x11, #0x24]
1015c6678: 3c834162    	stur	q2, [x11, #0x34]
1015c667c: b9004569    	str	w9, [x11, #0x44]
1015c6680: 3c804163    	stur	q3, [x11, #0x4]
1015c6684: b9000168    	str	w8, [x11]
1015c6688: f900256a    	str	x10, [x11, #0x48]
1015c668c: 17fff225    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c6690: f0012043    	adrp	x3, 0x1039d1000 <_anon.19b44b453da724831023c27de6e0b6f2.288+0x250>
1015c6694: 910fa063    	add	x3, x3, #0x3e8
1015c6698: d2800000    	mov	x0, #0x0                ; =0
1015c669c: 9460b43e    	bl	0x102df3794 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015c66a0: 1400075c    	b	0x1015c8410 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x589c>
1015c66a4: f9424a69    	ldr	x9, [x19, #0x490]
1015c66a8: f94017e8    	ldr	x8, [sp, #0x28]
1015c66ac: d37df108    	lsl	x8, x8, #3
1015c66b0: 911a83e0    	add	x0, sp, #0x6a0
1015c66b4: aa0903fc    	mov	x28, x9
1015c66b8: 910be121    	add	x1, x9, #0x2f8
1015c66bc: 91400504    	add	x4, x8, #0x1, lsl #12   ; =0x1000
1015c66c0: 52800002    	mov	w2, #0x0                ; =0
1015c66c4: 97ff94d9    	bl	0x1015aba28 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
1015c66c8: 395a83e8    	ldrb	w8, [sp, #0x6a0]
1015c66cc: 7100391f    	cmp	w8, #0xe
1015c66d0: 54001541    	b.ne	0x1015c6978 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e04>
1015c66d4: 911a83e8    	add	x8, sp, #0x6a0
1015c66d8: 911fa3e0    	add	x0, sp, #0x7e8
1015c66dc: f94017e1    	ldr	x1, [sp, #0x28]
1015c66e0: 945c8235    	bl	0x102ce6fb4 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
1015c66e4: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c66e8: 7100691f    	cmp	w8, #0x1a
1015c66ec: 54001d61    	b.ne	0x1015c6a98 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3f24>
1015c66f0: 3cc08340    	ldur	q0, [x26, #0x8]
1015c66f4: 3cc18341    	ldur	q1, [x26, #0x18]
1015c66f8: 3d8203e0    	str	q0, [sp, #0x800]
1015c66fc: 3d8207e1    	str	q1, [sp, #0x810]
1015c6700: 911a83e8    	add	x8, sp, #0x6a0
1015c6704: aa1503e0    	mov	x0, x21
1015c6708: f94027e1    	ldr	x1, [sp, #0x48]
1015c670c: f9401be2    	ldr	x2, [sp, #0x30]
1015c6710: 9400ac72    	bl	0x1015f18d8 <__RNvNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel15scheduler_nodes>
1015c6714: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c6718: 7100191f    	cmp	w8, #0x6
1015c671c: 540021a1    	b.ne	0x1015c6b50 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3fdc>
1015c6720: f94357e1    	ldr	x1, [sp, #0x6a8]
1015c6724: 911043e8    	add	x8, sp, #0x410
1015c6728: 911fa3e0    	add	x0, sp, #0x7e8
1015c672c: 945c81d7    	bl	0x102ce6e88 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget13reserve_nodes>
1015c6730: b94413e8    	ldr	w8, [sp, #0x410]
1015c6734: 7100691f    	cmp	w8, #0x1a
1015c6738: 54002961    	b.ne	0x1015c6c64 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x40f0>
1015c673c: 911043e8    	add	x8, sp, #0x410
1015c6740: 3cc08100    	ldur	q0, [x8, #0x8]
1015c6744: 3cc18101    	ldur	q1, [x8, #0x18]
1015c6748: 3d820be0    	str	q0, [sp, #0x820]
1015c674c: 3d820fe1    	str	q1, [sp, #0x830]
1015c6750: f94027e8    	ldr	x8, [sp, #0x48]
1015c6754: b5006ca8    	cbnz	x8, 0x1015c74e8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4974>
1015c6758: 52800108    	mov	w8, #0x8                ; =8
1015c675c: f90427ff    	str	xzr, [sp, #0x848]
1015c6760: f9042be8    	str	x8, [sp, #0x850]
1015c6764: f9042fff    	str	xzr, [sp, #0x858]
1015c6768: f000d1a8    	adrp	x8, 0x102ffd000 <_anon.70399bd8ea3438f11774e3396e76a872.10+0x30c2>
1015c676c: 3dc15d00    	ldr	q0, [x8, #0x570]
1015c6770: 3c808300    	stur	q0, [x24, #0x8]
1015c6774: 528000c8    	mov	w8, #0x6                ; =6
1015c6778: b9000308    	str	w8, [x24]
1015c677c: 912123e0    	add	x0, sp, #0x848
1015c6780: 97ff7d1b    	bl	0x1015a5bec <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionEEB1p_>
1015c6784: 912083e0    	add	x0, sp, #0x820
1015c6788: 97ff8186    	bl	0x1015a6da0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs29QkOtpKx6e_8mech_gpu>
1015c678c: 1400013d    	b	0x1015c6c80 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x410c>
1015c6790: ad4f87e0    	ldp	q0, q1, [sp, #0x1f0]
1015c6794: 3c804340    	stur	q0, [x26, #0x4]
1015c6798: 3c814341    	stur	q1, [x26, #0x14]
1015c679c: 3dc087e0    	ldr	q0, [sp, #0x210]
1015c67a0: 3c824340    	stur	q0, [x26, #0x24]
1015c67a4: f94113e8    	ldr	x8, [sp, #0x220]
1015c67a8: f8034348    	stur	x8, [x26, #0x34]
1015c67ac: 3dc1abe0    	ldr	q0, [sp, #0x6a0]
1015c67b0: 3dc1afe1    	ldr	q1, [sp, #0x6b0]
1015c67b4: f94027e8    	ldr	x8, [sp, #0x48]
1015c67b8: 3c804100    	stur	q0, [x8, #0x4]
1015c67bc: 52800049    	mov	w9, #0x2                ; =2
1015c67c0: b9000109    	str	w9, [x8]
1015c67c4: 140000af    	b	0x1015c6a80 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3f0c>
1015c67c8: b8401349    	ldur	w9, [x26, #0x1]
1015c67cc: f94027ea    	ldr	x10, [sp, #0x48]
1015c67d0: b8009149    	stur	w9, [x10, #0x9]
1015c67d4: b946a7e9    	ldr	w9, [sp, #0x6a4]
1015c67d8: b9000d49    	str	w9, [x10, #0xc]
1015c67dc: 3dc1b3e0    	ldr	q0, [sp, #0x6c0]
1015c67e0: 3c828140    	stur	q0, [x10, #0x28]
1015c67e4: f9436be9    	ldr	x9, [sp, #0x6d0]
1015c67e8: f9001d49    	str	x9, [x10, #0x38]
1015c67ec: fd435fe0    	ldr	d0, [sp, #0x6b8]
1015c67f0: 3cc08341    	ldur	q1, [x26, #0x8]
1015c67f4: 52800049    	mov	w9, #0x2                ; =2
1015c67f8: b9000149    	str	w9, [x10]
1015c67fc: 39002148    	strb	w8, [x10, #0x8]
1015c6800: 3d800541    	str	q1, [x10, #0x10]
1015c6804: fd001140    	str	d0, [x10, #0x20]
1015c6808: 9118c3e0    	add	x0, sp, #0x630
1015c680c: 97ff820d    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c6810: 17fff1c4    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c6814: f9400e78    	ldr	x24, [x19, #0x18]
1015c6818: d37beae9    	lsl	x9, x23, #5
1015c681c: f94023e8    	ldr	x8, [sp, #0x40]
1015c6820: f9424908    	ldr	x8, [x8, #0x490]
1015c6824: b9415a63    	ldr	w3, [x19, #0x158]
1015c6828: 911a83e0    	add	x0, sp, #0x6a0
1015c682c: 910be101    	add	x1, x8, #0x2f8
1015c6830: 91010124    	add	x4, x9, #0x40
1015c6834: 52800022    	mov	w2, #0x1                ; =1
1015c6838: 97ff947c    	bl	0x1015aba28 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
1015c683c: 395a83e8    	ldrb	w8, [sp, #0x6a0]
1015c6840: 7100391f    	cmp	w8, #0xe
1015c6844: 54000fc1    	b.ne	0x1015c6a3c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ec8>
1015c6848: f94023e8    	ldr	x8, [sp, #0x40]
1015c684c: f9424909    	ldr	x9, [x8, #0x490]
1015c6850: b9402a61    	ldr	w1, [x19, #0x28]
1015c6854: 911a83e8    	add	x8, sp, #0x6a0
1015c6858: 9103c120    	add	x0, x9, #0xf0
1015c685c: 910be122    	add	x2, x9, #0x2f8
1015c6860: 9400112a    	bl	0x1015cad08 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
1015c6864: 3cc08340    	ldur	q0, [x26, #0x8]
1015c6868: 3cc18341    	ldur	q1, [x26, #0x18]
1015c686c: ad0287e0    	stp	q0, q1, [sp, #0x50]
1015c6870: 3cc28340    	ldur	q0, [x26, #0x28]
1015c6874: 3d801fe0    	str	q0, [sp, #0x70]
1015c6878: f94353e8    	ldr	x8, [sp, #0x6a0]
1015c687c: f9436fe9    	ldr	x9, [sp, #0x6d8]
1015c6880: f90043e9    	str	x9, [sp, #0x80]
1015c6884: b4001848    	cbz	x8, 0x1015c6b8c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4018>
1015c6888: ad4287e0    	ldp	q0, q1, [sp, #0x50]
1015c688c: 3c848320    	stur	q0, [x25, #0x48]
1015c6890: 3c858321    	stur	q1, [x25, #0x58]
1015c6894: 3dc01fe0    	ldr	q0, [sp, #0x70]
1015c6898: 3c868320    	stur	q0, [x25, #0x68]
1015c689c: f94043e9    	ldr	x9, [sp, #0x80]
1015c68a0: f901d7e9    	str	x9, [sp, #0x3a8]
1015c68a4: f901bbe8    	str	x8, [sp, #0x370]
1015c68a8: b9401268    	ldr	w8, [x19, #0x10]
1015c68ac: 7100091f    	cmp	w8, #0x2
1015c68b0: 54001841    	b.ne	0x1015c6bb8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4044>
1015c68b4: f941be81    	ldr	x1, [x20, #0x378]
1015c68b8: eb0102bf    	cmp	x21, x1
1015c68bc: 5400d422    	b.hs	0x1015c8340 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x57cc>
1015c68c0: f941ba88    	ldr	x8, [x20, #0x370]
1015c68c4: 52802e09    	mov	w9, #0x170              ; =368
1015c68c8: 9b0922a8    	madd	x8, x21, x9, x8
1015c68cc: a940250a    	ldp	x10, x9, [x8]
1015c68d0: d240054a    	eor	x10, x10, #0x3
1015c68d4: aa090149    	orr	x9, x10, x9
1015c68d8: b500a809    	cbnz	x9, 0x1015c7dd8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5264>
1015c68dc: f94023e9    	ldr	x9, [sp, #0x40]
1015c68e0: f9424929    	ldr	x9, [x9, #0x490]
1015c68e4: b9402d16    	ldr	w22, [x8, #0x2c]
1015c68e8: 911a83e8    	add	x8, sp, #0x6a0
1015c68ec: 9103c120    	add	x0, x9, #0xf0
1015c68f0: 910be122    	add	x2, x9, #0x2f8
1015c68f4: aa1603e1    	mov	x1, x22
1015c68f8: 94001531    	bl	0x1015cbdbc <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena22current_retained_bytes>
1015c68fc: 395a83e8    	ldrb	w8, [sp, #0x6a0]
1015c6900: 7100511f    	cmp	w8, #0x14
1015c6904: 54001ea1    	b.ne	0x1015c6cd8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4164>
1015c6908: f94357e8    	ldr	x8, [sp, #0x6a8]
1015c690c: b4002a88    	cbz	x8, 0x1015c6e5c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x42e8>
1015c6910: f94023e8    	ldr	x8, [sp, #0x40]
1015c6914: f9424909    	ldr	x9, [x8, #0x490]
1015c6918: 911a83e8    	add	x8, sp, #0x6a0
1015c691c: 9103c120    	add	x0, x9, #0xf0
1015c6920: 910be122    	add	x2, x9, #0x2f8
1015c6924: aa1603e1    	mov	x1, x22
1015c6928: 940010f8    	bl	0x1015cad08 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
1015c692c: 3cc08340    	ldur	q0, [x26, #0x8]
1015c6930: 3cc18341    	ldur	q1, [x26, #0x18]
1015c6934: ad0487e0    	stp	q0, q1, [sp, #0x90]
1015c6938: 3cc28340    	ldur	q0, [x26, #0x28]
1015c693c: 3d802fe0    	str	q0, [sp, #0xb0]
1015c6940: f94353e8    	ldr	x8, [sp, #0x6a0]
1015c6944: f9436fe9    	ldr	x9, [sp, #0x6d8]
1015c6948: f90063e9    	str	x9, [sp, #0xc0]
1015c694c: b4004628    	cbz	x8, 0x1015c7210 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x469c>
1015c6950: ad4487e0    	ldp	q0, q1, [sp, #0x90]
1015c6954: 911483e9    	add	x9, sp, #0x520
1015c6958: 3c8a8120    	stur	q0, [x9, #0xa8]
1015c695c: 3c8b8121    	stur	q1, [x9, #0xb8]
1015c6960: 3dc02fe0    	ldr	q0, [sp, #0xb0]
1015c6964: 3c8c8120    	stur	q0, [x9, #0xc8]
1015c6968: f94063e9    	ldr	x9, [sp, #0xc0]
1015c696c: f902ffe9    	str	x9, [sp, #0x5f8]
1015c6970: 911703e4    	add	x4, sp, #0x5c0
1015c6974: 1400013b    	b	0x1015c6e60 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x42ec>
1015c6978: 3dc1abe0    	ldr	q0, [sp, #0x6a0]
1015c697c: 3dc1afe1    	ldr	q1, [sp, #0x6b0]
1015c6980: 3d8107e0    	str	q0, [sp, #0x410]
1015c6984: 3d810be1    	str	q1, [sp, #0x420]
1015c6988: 3dc1b3e2    	ldr	q2, [sp, #0x6c0]
1015c698c: 3d810fe2    	str	q2, [sp, #0x430]
1015c6990: f9436be8    	ldr	x8, [sp, #0x6d0]
1015c6994: f90223e8    	str	x8, [sp, #0x440]
1015c6998: 3c804340    	stur	q0, [x26, #0x4]
1015c699c: 3c814341    	stur	q1, [x26, #0x14]
1015c69a0: 3c824342    	stur	q2, [x26, #0x24]
1015c69a4: f8034348    	stur	x8, [x26, #0x34]
1015c69a8: b900031f    	str	wzr, [x24]
1015c69ac: 3dc1abe0    	ldr	q0, [sp, #0x6a0]
1015c69b0: 3dc1afe1    	ldr	q1, [sp, #0x6b0]
1015c69b4: 3c804300    	stur	q0, [x24, #0x4]
1015c69b8: 3c814301    	stur	q1, [x24, #0x14]
1015c69bc: 3dc1b3e0    	ldr	q0, [sp, #0x6c0]
1015c69c0: 3c824300    	stur	q0, [x24, #0x24]
1015c69c4: 3cc2c340    	ldur	q0, [x26, #0x2c]
1015c69c8: 3d800f00    	str	q0, [x24, #0x30]
1015c69cc: 140000af    	b	0x1015c6c88 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4114>
1015c69d0: 3dc1b3e0    	ldr	q0, [sp, #0x6c0]
1015c69d4: 3dc1b7e1    	ldr	q1, [sp, #0x6d0]
1015c69d8: f94027e8    	ldr	x8, [sp, #0x48]
1015c69dc: ad010500    	stp	q0, q1, [x8, #0x20]
1015c69e0: 3dc1bbe0    	ldr	q0, [sp, #0x6e0]
1015c69e4: 3d801100    	str	q0, [x8, #0x40]
1015c69e8: 3dc1afe0    	ldr	q0, [sp, #0x6b0]
1015c69ec: 3dc1abe1    	ldr	q1, [sp, #0x6a0]
1015c69f0: ad000101    	stp	q1, q0, [x8]
1015c69f4: 17fff14b    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c69f8: b8401349    	ldur	w9, [x26, #0x1]
1015c69fc: f94027ea    	ldr	x10, [sp, #0x48]
1015c6a00: b8009149    	stur	w9, [x10, #0x9]
1015c6a04: b946a7e9    	ldr	w9, [sp, #0x6a4]
1015c6a08: b9000d49    	str	w9, [x10, #0xc]
1015c6a0c: 3dc1b3e0    	ldr	q0, [sp, #0x6c0]
1015c6a10: 3c828140    	stur	q0, [x10, #0x28]
1015c6a14: f9436be9    	ldr	x9, [sp, #0x6d0]
1015c6a18: f9001d49    	str	x9, [x10, #0x38]
1015c6a1c: fd435fe0    	ldr	d0, [sp, #0x6b8]
1015c6a20: 3cc08341    	ldur	q1, [x26, #0x8]
1015c6a24: 52800049    	mov	w9, #0x2                ; =2
1015c6a28: b9000149    	str	w9, [x10]
1015c6a2c: 39002148    	strb	w8, [x10, #0x8]
1015c6a30: 3d800541    	str	q1, [x10, #0x10]
1015c6a34: fd001140    	str	d0, [x10, #0x20]
1015c6a38: 17fff13a    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c6a3c: 3dc1abe0    	ldr	q0, [sp, #0x6a0]
1015c6a40: 3dc1afe1    	ldr	q1, [sp, #0x6b0]
1015c6a44: 3d8107e0    	str	q0, [sp, #0x410]
1015c6a48: 3d810be1    	str	q1, [sp, #0x420]
1015c6a4c: 3dc1b3e2    	ldr	q2, [sp, #0x6c0]
1015c6a50: 3d810fe2    	str	q2, [sp, #0x430]
1015c6a54: f9436be8    	ldr	x8, [sp, #0x6d0]
1015c6a58: f90223e8    	str	x8, [sp, #0x440]
1015c6a5c: 3c804340    	stur	q0, [x26, #0x4]
1015c6a60: 3c814341    	stur	q1, [x26, #0x14]
1015c6a64: 3c824342    	stur	q2, [x26, #0x24]
1015c6a68: f8034348    	stur	x8, [x26, #0x34]
1015c6a6c: f94027e8    	ldr	x8, [sp, #0x48]
1015c6a70: b900011f    	str	wzr, [x8]
1015c6a74: 3dc1abe0    	ldr	q0, [sp, #0x6a0]
1015c6a78: 3dc1afe1    	ldr	q1, [sp, #0x6b0]
1015c6a7c: 3c804100    	stur	q0, [x8, #0x4]
1015c6a80: 3c814101    	stur	q1, [x8, #0x14]
1015c6a84: 3dc1b3e0    	ldr	q0, [sp, #0x6c0]
1015c6a88: 3c824100    	stur	q0, [x8, #0x24]
1015c6a8c: 3cc2c340    	ldur	q0, [x26, #0x2c]
1015c6a90: 3d800d00    	str	q0, [x8, #0x30]
1015c6a94: 17fff123    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c6a98: f000d1a8    	adrp	x8, 0x102ffd000 <_anon.70399bd8ea3438f11774e3396e76a872.10+0x30c2>
1015c6a9c: 3dc15d00    	ldr	q0, [x8, #0x570]
1015c6aa0: 3c808300    	stur	q0, [x24, #0x8]
1015c6aa4: 528000c8    	mov	w8, #0x6                ; =6
1015c6aa8: b9000308    	str	w8, [x24]
1015c6aac: 911a83e0    	add	x0, sp, #0x6a0
1015c6ab0: 97ff7a2c    	bl	0x1015a5360 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationNtNtB16_5error18MemoryRuntimeErrorEECs29QkOtpKx6e_8mech_gpu>
1015c6ab4: 14000075    	b	0x1015c6c88 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4114>
1015c6ab8: b90002df    	str	wzr, [x22]
1015c6abc: 52800188    	mov	w8, #0xc                ; =12
1015c6ac0: 390022c8    	strb	w8, [x22, #0x8]
1015c6ac4: 9000d3a8    	adrp	x8, 0x10303a000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x3b8>
1015c6ac8: 910bb908    	add	x8, x8, #0x2ee
1015c6acc: 52800529    	mov	w9, #0x29               ; =41
1015c6ad0: a90126c8    	stp	x8, x9, [x22, #0x10]
1015c6ad4: 17fffcdd    	b	0x1015c5e48 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x32d4>
1015c6ad8: b900029f    	str	wzr, [x20]
1015c6adc: 52800189    	mov	w9, #0xc                ; =12
1015c6ae0: f9000689    	str	x9, [x20, #0x8]
1015c6ae4: b000d3a8    	adrp	x8, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c6ae8: 912e5508    	add	x8, x8, #0xb95
1015c6aec: 528003c9    	mov	w9, #0x1e               ; =30
1015c6af0: 17fff9ed    	b	0x1015c52a4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2730>
1015c6af4: b90002df    	str	wzr, [x22]
1015c6af8: 52800188    	mov	w8, #0xc                ; =12
1015c6afc: b000d389    	adrp	x9, 0x103037000 <_anon.496f237bd13ceadd644cb7ae086b3546.176+0x13b>
1015c6b00: 91392d29    	add	x9, x9, #0xe4b
1015c6b04: a900a6c8    	stp	x8, x9, [x22, #0x8]
1015c6b08: 52800548    	mov	w8, #0x2a               ; =42
1015c6b0c: f9000ec8    	str	x8, [x22, #0x18]
1015c6b10: 17fffa1a    	b	0x1015c5378 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2804>
1015c6b14: b90002df    	str	wzr, [x22]
1015c6b18: 52800188    	mov	w8, #0xc                ; =12
1015c6b1c: b000d389    	adrp	x9, 0x103037000 <_anon.496f237bd13ceadd644cb7ae086b3546.176+0x13b>
1015c6b20: 9139d529    	add	x9, x9, #0xe75
1015c6b24: a900a6c8    	stp	x8, x9, [x22, #0x8]
1015c6b28: 528004c8    	mov	w8, #0x26               ; =38
1015c6b2c: f9000ec8    	str	x8, [x22, #0x18]
1015c6b30: 17fffa12    	b	0x1015c5378 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2804>
1015c6b34: b90002df    	str	wzr, [x22]
1015c6b38: 52800189    	mov	w9, #0xc                ; =12
1015c6b3c: 390022c9    	strb	w9, [x22, #0x8]
1015c6b40: b000d388    	adrp	x8, 0x103037000 <_anon.496f237bd13ceadd644cb7ae086b3546.176+0x13b>
1015c6b44: 913a6d08    	add	x8, x8, #0xe9b
1015c6b48: 52800589    	mov	w9, #0x2c               ; =44
1015c6b4c: 17fffcb7    	b	0x1015c5e28 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x32b4>
1015c6b50: b946a7e9    	ldr	w9, [sp, #0x6a4]
1015c6b54: f94357ea    	ldr	x10, [sp, #0x6a8]
1015c6b58: 3dc1afe0    	ldr	q0, [sp, #0x6b0]
1015c6b5c: 3dc1b3e1    	ldr	q1, [sp, #0x6c0]
1015c6b60: ad008700    	stp	q0, q1, [x24, #0x10]
1015c6b64: 3dc1b7e0    	ldr	q0, [sp, #0x6d0]
1015c6b68: 3dc1bbe1    	ldr	q1, [sp, #0x6e0]
1015c6b6c: ad018700    	stp	q0, q1, [x24, #0x30]
1015c6b70: 29002708    	stp	w8, w9, [x24]
1015c6b74: f900070a    	str	x10, [x24, #0x8]
1015c6b78: 14000042    	b	0x1015c6c80 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x410c>
1015c6b7c: f0012042    	adrp	x2, 0x1039d1000 <_anon.19b44b453da724831023c27de6e0b6f2.288+0x250>
1015c6b80: 910f4042    	add	x2, x2, #0x3d0
1015c6b84: aa0803e0    	mov	x0, x8
1015c6b88: 9460b296    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c6b8c: ad4287e0    	ldp	q0, q1, [sp, #0x50]
1015c6b90: 3c804340    	stur	q0, [x26, #0x4]
1015c6b94: 3c814341    	stur	q1, [x26, #0x14]
1015c6b98: 3dc01fe0    	ldr	q0, [sp, #0x70]
1015c6b9c: 3c824340    	stur	q0, [x26, #0x24]
1015c6ba0: f94043e8    	ldr	x8, [sp, #0x80]
1015c6ba4: 17ffff01    	b	0x1015c67a8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c34>
1015c6ba8: 90012062    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c6bac: 91158042    	add	x2, x2, #0x560
1015c6bb0: aa1403e0    	mov	x0, x20
1015c6bb4: 9460b28b    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c6bb8: f941bfe9    	ldr	x9, [sp, #0x378]
1015c6bbc: f9400929    	ldr	x9, [x9, #0x10]
1015c6bc0: 91004136    	add	x22, x9, #0x10
1015c6bc4: b4000757    	cbz	x23, 0x1015c6cac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4138>
1015c6bc8: d37df2e9    	lsl	x9, x23, #3
1015c6bcc: 9100130a    	add	x10, x24, #0x4
1015c6bd0: 5280060b    	mov	w11, #0x30              ; =48
1015c6bd4: 14000004    	b	0x1015c6be4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4070>
1015c6bd8: 9100214a    	add	x10, x10, #0x8
1015c6bdc: f1002129    	subs	x9, x9, #0x8
1015c6be0: 54000660    	b.eq	0x1015c6cac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4138>
1015c6be4: b85fc14d    	ldur	w13, [x10, #-0x4]
1015c6be8: 394002cc    	ldrb	w12, [x22]
1015c6bec: 3600014d    	tbz	w13, #0x0, 0x1015c6c14 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x40a0>
1015c6bf0: 71005d9f    	cmp	w12, #0x17
1015c6bf4: 54000b01    	b.ne	0x1015c6d54 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41e0>
1015c6bf8: f9400acd    	ldr	x13, [x22, #0x10]
1015c6bfc: b940014c    	ldr	w12, [x10]
1015c6c00: eb0c01bf    	cmp	x13, x12
1015c6c04: 54003369    	b.ls	0x1015c7270 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46fc>
1015c6c08: f94006cd    	ldr	x13, [x22, #0x8]
1015c6c0c: 9bab3596    	umaddl	x22, w12, w11, x13
1015c6c10: 17fffff2    	b	0x1015c6bd8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4064>
1015c6c14: 7100559f    	cmp	w12, #0x15
1015c6c18: 540009e1    	b.ne	0x1015c6d54 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41e0>
1015c6c1c: b94012cc    	ldr	w12, [x22, #0x10]
1015c6c20: b940014d    	ldr	w13, [x10]
1015c6c24: 6b0d019f    	cmp	w12, w13
1015c6c28: 54000961    	b.ne	0x1015c6d54 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41e0>
1015c6c2c: f94006d6    	ldr	x22, [x22, #0x8]
1015c6c30: b5fffd56    	cbnz	x22, 0x1015c6bd8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4064>
1015c6c34: f94027e8    	ldr	x8, [sp, #0x48]
1015c6c38: b900011f    	str	wzr, [x8]
1015c6c3c: 52800189    	mov	w9, #0xc                ; =12
1015c6c40: d000d38a    	adrp	x10, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c6c44: 9132b14a    	add	x10, x10, #0xcac
1015c6c48: a900a909    	stp	x9, x10, [x8, #0x8]
1015c6c4c: 528003c9    	mov	w9, #0x1e               ; =30
1015c6c50: f9000d09    	str	x9, [x8, #0x18]
1015c6c54: 14000379    	b	0x1015c7a38 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4ec4>
1015c6c58: 90012062    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c6c5c: 91074042    	add	x2, x2, #0x1d0
1015c6c60: 9460b260    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c6c64: f000d1a8    	adrp	x8, 0x102ffd000 <_anon.70399bd8ea3438f11774e3396e76a872.10+0x30c2>
1015c6c68: 3dc15d00    	ldr	q0, [x8, #0x570]
1015c6c6c: 3c808300    	stur	q0, [x24, #0x8]
1015c6c70: 528000c8    	mov	w8, #0x6                ; =6
1015c6c74: b9000308    	str	w8, [x24]
1015c6c78: 911043e0    	add	x0, sp, #0x410
1015c6c7c: 97ff7983    	bl	0x1015a5288 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationNtNtB16_5error18MemoryRuntimeErrorEECs29QkOtpKx6e_8mech_gpu>
1015c6c80: 912003e0    	add	x0, sp, #0x800
1015c6c84: 97ff8065    	bl	0x1015a6e18 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs29QkOtpKx6e_8mech_gpu>
1015c6c88: f943f7e8    	ldr	x8, [sp, #0x7e8]
1015c6c8c: 92800009    	mov	x9, #-0x1               ; =-1
1015c6c90: f8690108    	ldaddl	x9, x8, [x8]
1015c6c94: f100051f    	cmp	x8, #0x1
1015c6c98: 54fe1441    	b.ne	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c6c9c: d50339bf    	dmb	ishld
1015c6ca0: 911fa3e0    	add	x0, sp, #0x7e8
1015c6ca4: 945cacd1    	bl	0x102cf1fe8 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015c6ca8: 17fff09e    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c6cac: 7100051f    	cmp	w8, #0x1
1015c6cb0: 5400062c    	b.gt	0x1015c6d74 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4200>
1015c6cb4: 350018e8    	cbnz	w8, 0x1015c6fd0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x445c>
1015c6cb8: 394002c8    	ldrb	w8, [x22]
1015c6cbc: 7100551f    	cmp	w8, #0x15
1015c6cc0: 54001a21    	b.ne	0x1015c7004 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4490>
1015c6cc4: b94012c8    	ldr	w8, [x22, #0x10]
1015c6cc8: b9401669    	ldr	w9, [x19, #0x14]
1015c6ccc: 6b09011f    	cmp	w8, w9
1015c6cd0: 1a9f17f3    	cset	w19, eq
1015c6cd4: 140000c3    	b	0x1015c6fe0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x446c>
1015c6cd8: b8401349    	ldur	w9, [x26, #0x1]
1015c6cdc: f94027ea    	ldr	x10, [sp, #0x48]
1015c6ce0: b8009149    	stur	w9, [x10, #0x9]
1015c6ce4: b946a7e9    	ldr	w9, [sp, #0x6a4]
1015c6ce8: b9000d49    	str	w9, [x10, #0xc]
1015c6cec: 3cc18340    	ldur	q0, [x26, #0x18]
1015c6cf0: 3cc28341    	ldur	q1, [x26, #0x28]
1015c6cf4: ad010540    	stp	q0, q1, [x10, #0x20]
1015c6cf8: 3cc08341    	ldur	q1, [x26, #0x8]
1015c6cfc: 52800049    	mov	w9, #0x2                ; =2
1015c6d00: b9000149    	str	w9, [x10]
1015c6d04: 39002148    	strb	w8, [x10, #0x8]
1015c6d08: 3d800541    	str	q1, [x10, #0x10]
1015c6d0c: 1400034b    	b	0x1015c7a38 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4ec4>
1015c6d10: 90012062    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c6d14: 9109e042    	add	x2, x2, #0x278
1015c6d18: aa1303e0    	mov	x0, x19
1015c6d1c: 9460b231    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c6d20: 3dc1b3e0    	ldr	q0, [sp, #0x6c0]
1015c6d24: 3dc1b7e1    	ldr	q1, [sp, #0x6d0]
1015c6d28: ad0106c0    	stp	q0, q1, [x22, #0x20]
1015c6d2c: 3dc1bbe0    	ldr	q0, [sp, #0x6e0]
1015c6d30: 3d8012c0    	str	q0, [x22, #0x40]
1015c6d34: 3dc1afe0    	ldr	q0, [sp, #0x6b0]
1015c6d38: 3dc1abe1    	ldr	q1, [sp, #0x6a0]
1015c6d3c: ad0002c1    	stp	q1, q0, [x22]
1015c6d40: 17fffc42    	b	0x1015c5e48 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x32d4>
1015c6d44: f0012042    	adrp	x2, 0x1039d1000 <_anon.19b44b453da724831023c27de6e0b6f2.288+0x250>
1015c6d48: 910d6042    	add	x2, x2, #0x358
1015c6d4c: aa1403e0    	mov	x0, x20
1015c6d50: 9460b224    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c6d54: f94027e8    	ldr	x8, [sp, #0x48]
1015c6d58: b900011f    	str	wzr, [x8]
1015c6d5c: 52800189    	mov	w9, #0xc                ; =12
1015c6d60: 39002109    	strb	w9, [x8, #0x8]
1015c6d64: b000d3a9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c6d68: 911d5929    	add	x9, x9, #0x756
1015c6d6c: 5280078a    	mov	w10, #0x3c              ; =60
1015c6d70: 140000ac    	b	0x1015c7020 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x44ac>
1015c6d74: 7100091f    	cmp	w8, #0x2
1015c6d78: 54001460    	b.eq	0x1015c7004 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4490>
1015c6d7c: 394002c8    	ldrb	w8, [x22]
1015c6d80: 7100451f    	cmp	w8, #0x11
1015c6d84: 54001401    	b.ne	0x1015c7004 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4490>
1015c6d88: f94023e8    	ldr	x8, [sp, #0x40]
1015c6d8c: f9424909    	ldr	x9, [x8, #0x490]
1015c6d90: b9401661    	ldr	w1, [x19, #0x14]
1015c6d94: 911a83e8    	add	x8, sp, #0x6a0
1015c6d98: 9103c120    	add	x0, x9, #0xf0
1015c6d9c: 910be122    	add	x2, x9, #0x2f8
1015c6da0: 94000fda    	bl	0x1015cad08 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
1015c6da4: 3cc08340    	ldur	q0, [x26, #0x8]
1015c6da8: 3cc18341    	ldur	q1, [x26, #0x18]
1015c6dac: ad0887e0    	stp	q0, q1, [sp, #0x110]
1015c6db0: 3cc28340    	ldur	q0, [x26, #0x28]
1015c6db4: 3d804fe0    	str	q0, [sp, #0x130]
1015c6db8: f94353e8    	ldr	x8, [sp, #0x6a0]
1015c6dbc: f9436fe9    	ldr	x9, [sp, #0x6d8]
1015c6dc0: f900a3e9    	str	x9, [sp, #0x140]
1015c6dc4: b4003d08    	cbz	x8, 0x1015c7564 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x49f0>
1015c6dc8: ad4887e0    	ldp	q0, q1, [sp, #0x110]
1015c6dcc: 911043e9    	add	x9, sp, #0x410
1015c6dd0: 3c808120    	stur	q0, [x9, #0x8]
1015c6dd4: f940a3ea    	ldr	x10, [sp, #0x140]
1015c6dd8: 3dc04fe0    	ldr	q0, [sp, #0x130]
1015c6ddc: 3c828120    	stur	q0, [x9, #0x28]
1015c6de0: 3c818121    	stur	q1, [x9, #0x18]
1015c6de4: f90227ea    	str	x10, [sp, #0x448]
1015c6de8: f9020be8    	str	x8, [sp, #0x410]
1015c6dec: f9420fe8    	ldr	x8, [sp, #0x418]
1015c6df0: f9400913    	ldr	x19, [x8, #0x10]
1015c6df4: 39404268    	ldrb	w8, [x19, #0x10]
1015c6df8: 7100451f    	cmp	w8, #0x11
1015c6dfc: 54003c21    	b.ne	0x1015c7580 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a0c>
1015c6e00: a940dad7    	ldp	x23, x22, [x22, #0x8]
1015c6e04: f9401268    	ldr	x8, [x19, #0x20]
1015c6e08: eb16011f    	cmp	x8, x22
1015c6e0c: 9a968101    	csel	x1, x8, x22, hi
1015c6e10: f94023e8    	ldr	x8, [sp, #0x40]
1015c6e14: f9424909    	ldr	x9, [x8, #0x490]
1015c6e18: 910523e8    	add	x8, sp, #0x148
1015c6e1c: 910ee120    	add	x0, x9, #0x3b8
1015c6e20: aa0103e2    	mov	x2, x1
1015c6e24: 94354e01    	bl	0x10231a628 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge>
1015c6e28: 394523e8    	ldrb	w8, [sp, #0x148]
1015c6e2c: 7100211f    	cmp	w8, #0x8
1015c6e30: 54005e21    	b.ne	0x1015c79f4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4e80>
1015c6e34: f9401268    	ldr	x8, [x19, #0x20]
1015c6e38: eb0802df    	cmp	x22, x8
1015c6e3c: 540063a1    	b.ne	0x1015c7ab0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4f3c>
1015c6e40: f9400e61    	ldr	x1, [x19, #0x18]
1015c6e44: aa1703e0    	mov	x0, x23
1015c6e48: aa1603e2    	mov	x2, x22
1015c6e4c: 9460b750    	bl	0x102df4b8c <dyld_stub_binder+0x102df4b8c>
1015c6e50: 7100001f    	cmp	w0, #0x0
1015c6e54: 1a9f17f3    	cset	w19, eq
1015c6e58: 14000317    	b	0x1015c7ab4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4f40>
1015c6e5c: d2800004    	mov	x4, #0x0                ; =0
1015c6e60: f902e3e8    	str	x8, [sp, #0x5c0]
1015c6e64: f94023e8    	ldr	x8, [sp, #0x40]
1015c6e68: ad440500    	ldp	q0, q1, [x8, #0x80]
1015c6e6c: 3d81cbe0    	str	q0, [sp, #0x720]
1015c6e70: 3d81cfe1    	str	q1, [sp, #0x730]
1015c6e74: f9405109    	ldr	x9, [x8, #0xa0]
1015c6e78: f903a3e9    	str	x9, [sp, #0x740]
1015c6e7c: ad420500    	ldp	q0, q1, [x8, #0x40]
1015c6e80: 3d81bbe0    	str	q0, [sp, #0x6e0]
1015c6e84: 3d81bfe1    	str	q1, [sp, #0x6f0]
1015c6e88: ad430101    	ldp	q1, q0, [x8, #0x60]
1015c6e8c: 3d81c7e0    	str	q0, [sp, #0x710]
1015c6e90: 3d81c3e1    	str	q1, [sp, #0x700]
1015c6e94: ad400500    	ldp	q0, q1, [x8]
1015c6e98: 3d81abe0    	str	q0, [sp, #0x6a0]
1015c6e9c: 3d81afe1    	str	q1, [sp, #0x6b0]
1015c6ea0: ad410101    	ldp	q1, q0, [x8, #0x20]
1015c6ea4: 3d81b7e0    	str	q0, [sp, #0x6d0]
1015c6ea8: 3d81b3e1    	str	q1, [sp, #0x6c0]
1015c6eac: f9424909    	ldr	x9, [x8, #0x490]
1015c6eb0: 910343e8    	add	x8, sp, #0xd0
1015c6eb4: 910be280    	add	x0, x20, #0x2f8
1015c6eb8: 910fc282    	add	x2, x20, #0x3f0
1015c6ebc: 910dc3e3    	add	x3, sp, #0x370
1015c6ec0: 911a83e5    	add	x5, sp, #0x6a0
1015c6ec4: 910ee126    	add	x6, x9, #0x3b8
1015c6ec8: aa1503e1    	mov	x1, x21
1015c6ecc: 944f5865    	bl	0x10299d060 <__RNvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general28native_structural_projection31native_project_structural_value>
1015c6ed0: f9406be8    	ldr	x8, [sp, #0xd0]
1015c6ed4: b4000508    	cbz	x8, 0x1015c6f74 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4400>
1015c6ed8: ad4687e0    	ldp	q0, q1, [sp, #0xd0]
1015c6edc: 3d818fe0    	str	q0, [sp, #0x630]
1015c6ee0: 3d8193e1    	str	q1, [sp, #0x640]
1015c6ee4: ad4787e0    	ldp	q0, q1, [sp, #0xf0]
1015c6ee8: 3d8197e0    	str	q0, [sp, #0x650]
1015c6eec: 3d819be1    	str	q1, [sp, #0x660]
1015c6ef0: f94023e8    	ldr	x8, [sp, #0x40]
1015c6ef4: f9424909    	ldr	x9, [x8, #0x490]
1015c6ef8: 911a83e8    	add	x8, sp, #0x6a0
1015c6efc: 9103c120    	add	x0, x9, #0xf0
1015c6f00: 9118c3e2    	add	x2, sp, #0x630
1015c6f04: 910be123    	add	x3, x9, #0x2f8
1015c6f08: aa1603e1    	mov	x1, x22
1015c6f0c: 94001642    	bl	0x1015cc814 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena3put>
1015c6f10: 395a83e8    	ldrb	w8, [sp, #0x6a0]
1015c6f14: 7100511f    	cmp	w8, #0x14
1015c6f18: 540014e1    	b.ne	0x1015c71b4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4640>
1015c6f1c: f94023e8    	ldr	x8, [sp, #0x40]
1015c6f20: f9424908    	ldr	x8, [x8, #0x490]
1015c6f24: 52800029    	mov	w9, #0x1                ; =1
1015c6f28: 39118109    	strb	w9, [x8, #0x460]
1015c6f2c: f941ae81    	ldr	x1, [x20, #0x358]
1015c6f30: eb16003f    	cmp	x1, x22
1015c6f34: 5400a109    	b.ls	0x1015c8354 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x57e0>
1015c6f38: f941aa88    	ldr	x8, [x20, #0x350]
1015c6f3c: 52802809    	mov	w9, #0x140              ; =320
1015c6f40: 9ba922c8    	umaddl	x8, w22, w9, x8
1015c6f44: 39449102    	ldrb	w2, [x8, #0x124]
1015c6f48: 71001c5f    	cmp	w2, #0x7
1015c6f4c: 54001ca1    	b.ne	0x1015c72e0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x476c>
1015c6f50: f94027e8    	ldr	x8, [sp, #0x48]
1015c6f54: f900051f    	str	xzr, [x8, #0x8]
1015c6f58: 528000c9    	mov	w9, #0x6                ; =6
1015c6f5c: b9000109    	str	w9, [x8]
1015c6f60: 140000a5    	b	0x1015c71f4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4680>
1015c6f64: f0012042    	adrp	x2, 0x1039d1000 <_anon.19b44b453da724831023c27de6e0b6f2.288+0x250>
1015c6f68: 910dc042    	add	x2, x2, #0x370
1015c6f6c: aa1403e0    	mov	x0, x20
1015c6f70: 9460b19c    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c6f74: 910343e8    	add	x8, sp, #0xd0
1015c6f78: f941ba81    	ldr	x1, [x20, #0x370]
1015c6f7c: f941be82    	ldr	x2, [x20, #0x378]
1015c6f80: 911a83e0    	add	x0, sp, #0x6a0
1015c6f84: 91002104    	add	x4, x8, #0x8
1015c6f88: aa1503e3    	mov	x3, x21
1015c6f8c: 97ff91da    	bl	0x1015ab6f4 <__RNCNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB7_10Invocation6helpers5_0Bf_>
1015c6f90: 3cc14340    	ldur	q0, [x26, #0x14]
1015c6f94: f94027e8    	ldr	x8, [sp, #0x48]
1015c6f98: 3c814100    	stur	q0, [x8, #0x14]
1015c6f9c: 3cc24340    	ldur	q0, [x26, #0x24]
1015c6fa0: 3c824100    	stur	q0, [x8, #0x24]
1015c6fa4: 3cc34340    	ldur	q0, [x26, #0x34]
1015c6fa8: 3c834100    	stur	q0, [x8, #0x34]
1015c6fac: b946a3e9    	ldr	w9, [sp, #0x6a0]
1015c6fb0: b946e7ea    	ldr	w10, [sp, #0x6e4]
1015c6fb4: b900450a    	str	w10, [x8, #0x44]
1015c6fb8: 3cc04340    	ldur	q0, [x26, #0x4]
1015c6fbc: 3c804100    	stur	q0, [x8, #0x4]
1015c6fc0: f94377ea    	ldr	x10, [sp, #0x6e8]
1015c6fc4: b9000109    	str	w9, [x8]
1015c6fc8: f900250a    	str	x10, [x8, #0x48]
1015c6fcc: 1400008c    	b	0x1015c71fc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4688>
1015c6fd0: 394002c8    	ldrb	w8, [x22]
1015c6fd4: 7100111f    	cmp	w8, #0x4
1015c6fd8: 54000161    	b.ne	0x1015c7004 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4490>
1015c6fdc: f94006d3    	ldr	x19, [x22, #0x8]
1015c6fe0: f94023e8    	ldr	x8, [sp, #0x40]
1015c6fe4: f9424908    	ldr	x8, [x8, #0x490]
1015c6fe8: 52800029    	mov	w9, #0x1                ; =1
1015c6fec: 39118109    	strb	w9, [x8, #0x460]
1015c6ff0: f94027e8    	ldr	x8, [sp, #0x48]
1015c6ff4: a900cd09    	stp	x9, x19, [x8, #0x8]
1015c6ff8: 528000c9    	mov	w9, #0x6                ; =6
1015c6ffc: b9000109    	str	w9, [x8]
1015c7000: 1400028e    	b	0x1015c7a38 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4ec4>
1015c7004: f94027e8    	ldr	x8, [sp, #0x48]
1015c7008: b900011f    	str	wzr, [x8]
1015c700c: 52800189    	mov	w9, #0xc                ; =12
1015c7010: 39002109    	strb	w9, [x8, #0x8]
1015c7014: 9000d3a9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c7018: 911ee529    	add	x9, x9, #0x7b9
1015c701c: 5280068a    	mov	w10, #0x34              ; =52
1015c7020: a9012909    	stp	x9, x10, [x8, #0x10]
1015c7024: 14000285    	b	0x1015c7a38 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4ec4>
1015c7028: b40013d7    	cbz	x23, 0x1015c72a0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x472c>
1015c702c: a9037fff    	stp	xzr, xzr, [sp, #0x30]
1015c7030: d37ef6e8    	lsl	x8, x23, #2
1015c7034: f90017e8    	str	x8, [sp, #0x28]
1015c7038: 1400000f    	b	0x1015c7074 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4500>
1015c703c: 3dc1abe0    	ldr	q0, [sp, #0x6a0]
1015c7040: 3dc1afe1    	ldr	q1, [sp, #0x6b0]
1015c7044: 3dc1b3e2    	ldr	q2, [sp, #0x6c0]
1015c7048: 3dc1b7e3    	ldr	q3, [sp, #0x6d0]
1015c704c: ad010f82    	stp	q2, q3, [x28, #0x20]
1015c7050: ad000780    	stp	q0, q1, [x28]
1015c7054: a94323ea    	ldp	x10, x8, [sp, #0x30]
1015c7058: 91010149    	add	x9, x10, #0x40
1015c705c: 91000508    	add	x8, x8, #0x1
1015c7060: a90323e9    	stp	x9, x8, [sp, #0x30]
1015c7064: f94017e8    	ldr	x8, [sp, #0x28]
1015c7068: f1001108    	subs	x8, x8, #0x4
1015c706c: f90017e8    	str	x8, [sp, #0x28]
1015c7070: 54001180    	b.eq	0x1015c72a0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x472c>
1015c7074: f9401fe8    	ldr	x8, [sp, #0x38]
1015c7078: b8687a61    	ldr	w1, [x19, x8, lsl #2]
1015c707c: f941ae88    	ldr	x8, [x20, #0x358]
1015c7080: eb01011f    	cmp	x8, x1
1015c7084: 54009729    	b.ls	0x1015c8368 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x57f4>
1015c7088: f941aa88    	ldr	x8, [x20, #0x350]
1015c708c: 52802809    	mov	w9, #0x140              ; =320
1015c7090: 9ba92028    	umaddl	x8, w1, w9, x8
1015c7094: 39449108    	ldrb	w8, [x8, #0x124]
1015c7098: 71001d1f    	cmp	w8, #0x7
1015c709c: 540003a1    	b.ne	0x1015c7110 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x459c>
1015c70a0: f9401fe8    	ldr	x8, [sp, #0x38]
1015c70a4: eb17011f    	cmp	x8, x23
1015c70a8: 540096a2    	b.hs	0x1015c837c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5808>
1015c70ac: f9401fe8    	ldr	x8, [sp, #0x38]
1015c70b0: f8687b08    	ldr	x8, [x24, x8, lsl #3]
1015c70b4: b5004448    	cbnz	x8, 0x1015c793c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4dc8>
1015c70b8: f94023e8    	ldr	x8, [sp, #0x40]
1015c70bc: f9424909    	ldr	x9, [x8, #0x490]
1015c70c0: 911a83e8    	add	x8, sp, #0x6a0
1015c70c4: 9103c120    	add	x0, x9, #0xf0
1015c70c8: 910be122    	add	x2, x9, #0x2f8
1015c70cc: 94000f0f    	bl	0x1015cad08 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
1015c70d0: f94353f6    	ldr	x22, [sp, #0x6a0]
1015c70d4: 911a83e8    	add	x8, sp, #0x6a0
1015c70d8: 3cc08100    	ldur	q0, [x8, #0x8]
1015c70dc: 3cc18101    	ldur	q1, [x8, #0x18]
1015c70e0: ad0b87e0    	stp	q0, q1, [sp, #0x170]
1015c70e4: 3cc28100    	ldur	q0, [x8, #0x28]
1015c70e8: 3d8067e0    	str	q0, [sp, #0x190]
1015c70ec: f8438108    	ldur	x8, [x8, #0x38]
1015c70f0: f900d3e8    	str	x8, [sp, #0x1a0]
1015c70f4: b4004596    	cbz	x22, 0x1015c79a4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4e30>
1015c70f8: ad4b87e0    	ldp	q0, q1, [sp, #0x170]
1015c70fc: ad0d87e0    	stp	q0, q1, [sp, #0x1b0]
1015c7100: 3dc067e0    	ldr	q0, [sp, #0x190]
1015c7104: 3d8077e0    	str	q0, [sp, #0x1d0]
1015c7108: f940d3e8    	ldr	x8, [sp, #0x1a0]
1015c710c: 14000013    	b	0x1015c7158 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x45e4>
1015c7110: f9401fe8    	ldr	x8, [sp, #0x38]
1015c7114: eb17011f    	cmp	x8, x23
1015c7118: 540093c2    	b.hs	0x1015c8390 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x581c>
1015c711c: a94383e8    	ldp	x8, x0, [sp, #0x38]
1015c7120: f8687b02    	ldr	x2, [x24, x8, lsl #3]
1015c7124: 911a83e8    	add	x8, sp, #0x6a0
1015c7128: 94000729    	bl	0x1015c8dcc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6scalar>
1015c712c: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c7130: 7100191f    	cmp	w8, #0x6
1015c7134: 54004141    	b.ne	0x1015c795c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4de8>
1015c7138: f94357f6    	ldr	x22, [sp, #0x6a8]
1015c713c: 911a83e9    	add	x9, sp, #0x6a0
1015c7140: ad410121    	ldp	q1, q0, [x9, #0x20]
1015c7144: 3d810fe0    	str	q0, [sp, #0x430]
1015c7148: f8440128    	ldur	x8, [x9, #0x40]
1015c714c: 3cc10122    	ldur	q2, [x9, #0x10]
1015c7150: ad0d87e2    	stp	q2, q1, [sp, #0x1b0]
1015c7154: 3d8077e0    	str	q0, [sp, #0x1d0]
1015c7158: f900f3e8    	str	x8, [sp, #0x1e0]
1015c715c: f90353f6    	str	x22, [sp, #0x6a0]
1015c7160: ad4d87e0    	ldp	q0, q1, [sp, #0x1b0]
1015c7164: 911a83e9    	add	x9, sp, #0x6a0
1015c7168: 3c808120    	stur	q0, [x9, #0x8]
1015c716c: 3c818121    	stur	q1, [x9, #0x18]
1015c7170: 3dc077e0    	ldr	q0, [sp, #0x1d0]
1015c7174: 3c828120    	stur	q0, [x9, #0x28]
1015c7178: f8038128    	stur	x8, [x9, #0x38]
1015c717c: a943a3e9    	ldp	x9, x8, [sp, #0x38]
1015c7180: f9424908    	ldr	x8, [x8, #0x490]
1015c7184: f9406d01    	ldr	x1, [x8, #0xd8]
1015c7188: eb01013f    	cmp	x9, x1
1015c718c: 540090c2    	b.hs	0x1015c83a4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5830>
1015c7190: f9406916    	ldr	x22, [x8, #0xd0]
1015c7194: f9401be8    	ldr	x8, [sp, #0x30]
1015c7198: 8b0802dc    	add	x28, x22, x8
1015c719c: f9400388    	ldr	x8, [x28]
1015c71a0: b4fff4e8    	cbz	x8, 0x1015c703c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x44c8>
1015c71a4: f9401be8    	ldr	x8, [sp, #0x30]
1015c71a8: 8b0802c0    	add	x0, x22, x8
1015c71ac: 97ff7fa5    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c71b0: 17ffffa3    	b	0x1015c703c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x44c8>
1015c71b4: b8401349    	ldur	w9, [x26, #0x1]
1015c71b8: f94027ea    	ldr	x10, [sp, #0x48]
1015c71bc: b8009149    	stur	w9, [x10, #0x9]
1015c71c0: b946a7e9    	ldr	w9, [sp, #0x6a4]
1015c71c4: b9000d49    	str	w9, [x10, #0xc]
1015c71c8: 3dc1b3e0    	ldr	q0, [sp, #0x6c0]
1015c71cc: 3c828140    	stur	q0, [x10, #0x28]
1015c71d0: f9436be9    	ldr	x9, [sp, #0x6d0]
1015c71d4: f9001d49    	str	x9, [x10, #0x38]
1015c71d8: fd435fe0    	ldr	d0, [sp, #0x6b8]
1015c71dc: 3cc08341    	ldur	q1, [x26, #0x8]
1015c71e0: 52800049    	mov	w9, #0x2                ; =2
1015c71e4: b9000149    	str	w9, [x10]
1015c71e8: 39002148    	strb	w8, [x10, #0x8]
1015c71ec: 3d800541    	str	q1, [x10, #0x10]
1015c71f0: fd001140    	str	d0, [x10, #0x20]
1015c71f4: 9118c3e0    	add	x0, sp, #0x630
1015c71f8: 97ff7f92    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c71fc: f942e3e8    	ldr	x8, [sp, #0x5c0]
1015c7200: b40041c8    	cbz	x8, 0x1015c7a38 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4ec4>
1015c7204: 911703e0    	add	x0, sp, #0x5c0
1015c7208: 97ff7f8e    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c720c: 1400020b    	b	0x1015c7a38 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4ec4>
1015c7210: ad4487e0    	ldp	q0, q1, [sp, #0x90]
1015c7214: 3c804340    	stur	q0, [x26, #0x4]
1015c7218: 3c814341    	stur	q1, [x26, #0x14]
1015c721c: 3dc02fe0    	ldr	q0, [sp, #0xb0]
1015c7220: 3c824340    	stur	q0, [x26, #0x24]
1015c7224: f94063e8    	ldr	x8, [sp, #0xc0]
1015c7228: f8034348    	stur	x8, [x26, #0x34]
1015c722c: 3dc1abe0    	ldr	q0, [sp, #0x6a0]
1015c7230: 3dc1afe1    	ldr	q1, [sp, #0x6b0]
1015c7234: f94027e8    	ldr	x8, [sp, #0x48]
1015c7238: 3c804100    	stur	q0, [x8, #0x4]
1015c723c: 52800049    	mov	w9, #0x2                ; =2
1015c7240: b9000109    	str	w9, [x8]
1015c7244: 3c814101    	stur	q1, [x8, #0x14]
1015c7248: 3dc1b3e0    	ldr	q0, [sp, #0x6c0]
1015c724c: 3c824100    	stur	q0, [x8, #0x24]
1015c7250: 3cc2c340    	ldur	q0, [x26, #0x2c]
1015c7254: 3d800d00    	str	q0, [x8, #0x30]
1015c7258: 140001f8    	b	0x1015c7a38 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4ec4>
1015c725c: f0012042    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c7260: 910a4042    	add	x2, x2, #0x290
1015c7264: aa0103e0    	mov	x0, x1
1015c7268: aa0803e1    	mov	x1, x8
1015c726c: 9460b0dd    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c7270: f94027e8    	ldr	x8, [sp, #0x48]
1015c7274: b900011f    	str	wzr, [x8]
1015c7278: 52800189    	mov	w9, #0xc                ; =12
1015c727c: b000d38a    	adrp	x10, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c7280: 9133294a    	add	x10, x10, #0xcca
1015c7284: a900a909    	stp	x9, x10, [x8, #0x8]
1015c7288: 528002c9    	mov	w9, #0x16               ; =22
1015c728c: f9000d09    	str	x9, [x8, #0x18]
1015c7290: 140001ea    	b	0x1015c7a38 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4ec4>
1015c7294: f0012042    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c7298: 91092042    	add	x2, x2, #0x248
1015c729c: 9460b0d1    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c72a0: f9420281    	ldr	x1, [x20, #0x400]
1015c72a4: eb0102bf    	cmp	x21, x1
1015c72a8: 54008882    	b.hs	0x1015c83b8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5844>
1015c72ac: f941fe88    	ldr	x8, [x20, #0x3f8]
1015c72b0: 52803e09    	mov	w9, #0x1f0              ; =496
1015c72b4: 9b0922a2    	madd	x2, x21, x9, x8
1015c72b8: a9402049    	ldp	x9, x8, [x2]
1015c72bc: d27f0129    	eor	x9, x9, #0x2
1015c72c0: aa080128    	orr	x8, x9, x8
1015c72c4: b50003a8    	cbnz	x8, 0x1015c7338 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47c4>
1015c72c8: f94027e8    	ldr	x8, [sp, #0x48]
1015c72cc: b900011f    	str	wzr, [x8]
1015c72d0: 52800189    	mov	w9, #0xc                ; =12
1015c72d4: b000d38a    	adrp	x10, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c72d8: 9133814a    	add	x10, x10, #0xce0
1015c72dc: 17ffee99    	b	0x1015c2d40 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1cc>
1015c72e0: f9431fe1    	ldr	x1, [sp, #0x638]
1015c72e4: 911a83e0    	add	x0, sp, #0x6a0
1015c72e8: 94003b17    	bl	0x1015d5f44 <__RNvNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime4bits>
1015c72ec: fd4353e0    	ldr	d0, [sp, #0x6a0]
1015c72f0: b946a3e9    	ldr	w9, [sp, #0x6a0]
1015c72f4: f94357e8    	ldr	x8, [sp, #0x6a8]
1015c72f8: 3dc1afe1    	ldr	q1, [sp, #0x6b0]
1015c72fc: 3dc1b3e2    	ldr	q2, [sp, #0x6c0]
1015c7300: 3d8107e1    	str	q1, [sp, #0x410]
1015c7304: 3d810be2    	str	q2, [sp, #0x420]
1015c7308: 3dc1b7e1    	ldr	q1, [sp, #0x6d0]
1015c730c: 3dc1bbe2    	ldr	q2, [sp, #0x6e0]
1015c7310: 3d810fe1    	str	q1, [sp, #0x430]
1015c7314: 3d8113e2    	str	q2, [sp, #0x440]
1015c7318: 7100193f    	cmp	w9, #0x6
1015c731c: 54001101    	b.ne	0x1015c753c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x49c8>
1015c7320: 52800029    	mov	w9, #0x1                ; =1
1015c7324: f94027ea    	ldr	x10, [sp, #0x48]
1015c7328: a900a149    	stp	x9, x8, [x10, #0x8]
1015c732c: 528000c8    	mov	w8, #0x6                ; =6
1015c7330: b9000148    	str	w8, [x10]
1015c7334: 17ffffb0    	b	0x1015c71f4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4680>
1015c7338: f902e3ff    	str	xzr, [sp, #0x5c0]
1015c733c: f94023e8    	ldr	x8, [sp, #0x40]
1015c7340: f9424909    	ldr	x9, [x8, #0x490]
1015c7344: f9406d28    	ldr	x8, [x9, #0xd8]
1015c7348: eb0802ff    	cmp	x23, x8
1015c734c: 540061c8    	b.hi	0x1015c7f84 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5410>
1015c7350: f9406923    	ldr	x3, [x9, #0xd0]
1015c7354: f94023e8    	ldr	x8, [sp, #0x40]
1015c7358: ad440500    	ldp	q0, q1, [x8, #0x80]
1015c735c: 3d81cbe0    	str	q0, [sp, #0x720]
1015c7360: 3d81cfe1    	str	q1, [sp, #0x730]
1015c7364: f940510a    	ldr	x10, [x8, #0xa0]
1015c7368: f903a3ea    	str	x10, [sp, #0x740]
1015c736c: ad420500    	ldp	q0, q1, [x8, #0x40]
1015c7370: 3d81bbe0    	str	q0, [sp, #0x6e0]
1015c7374: 3d81bfe1    	str	q1, [sp, #0x6f0]
1015c7378: ad430101    	ldp	q1, q0, [x8, #0x60]
1015c737c: 3d81c7e0    	str	q0, [sp, #0x710]
1015c7380: 3d81c3e1    	str	q1, [sp, #0x700]
1015c7384: ad400500    	ldp	q0, q1, [x8]
1015c7388: 3d81abe0    	str	q0, [sp, #0x6a0]
1015c738c: 3d81afe1    	str	q1, [sp, #0x6b0]
1015c7390: ad410101    	ldp	q1, q0, [x8, #0x20]
1015c7394: 3d81b7e0    	str	q0, [sp, #0x6d0]
1015c7398: 3d81b3e1    	str	q1, [sp, #0x6c0]
1015c739c: 910dc3e8    	add	x8, sp, #0x370
1015c73a0: 910d2120    	add	x0, x9, #0x348
1015c73a4: 911703e5    	add	x5, sp, #0x5c0
1015c73a8: 911a83e6    	add	x6, sp, #0x6a0
1015c73ac: 910ee127    	add	x7, x9, #0x3b8
1015c73b0: aa1503e1    	mov	x1, x21
1015c73b4: aa1703e4    	mov	x4, x23
1015c73b8: 97fd18ad    	bl	0x10150d66c <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime7sessionNtB2_13CallCacheLane6invoke>
1015c73bc: f94023e8    	ldr	x8, [sp, #0x40]
1015c73c0: f9424908    	ldr	x8, [x8, #0x490]
1015c73c4: f9406d02    	ldr	x2, [x8, #0xd8]
1015c73c8: eb0202ff    	cmp	x23, x2
1015c73cc: 540061e8    	b.hi	0x1015c8008 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5494>
1015c73d0: f9406900    	ldr	x0, [x8, #0xd0]
1015c73d4: f90353ff    	str	xzr, [sp, #0x6a0]
1015c73d8: 911a83e2    	add	x2, sp, #0x6a0
1015c73dc: aa1703e1    	mov	x1, x23
1015c73e0: 97fd91ab    	bl	0x10152ba8c <__RNvXNtNtCsgDHHaSskbIF_4core5slice10specializeSINtNtB6_6option6OptionNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEINtB2_8SpecFillBI_E9spec_fillCs29QkOtpKx6e_8mech_gpu>
1015c73e4: 394dc3e8    	ldrb	w8, [sp, #0x370]
1015c73e8: 7100b91f    	cmp	w8, #0x2e
1015c73ec: 54000dc1    	b.ne	0x1015c75a4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a30>
1015c73f0: f942e3e8    	ldr	x8, [sp, #0x5c0]
1015c73f4: b4003288    	cbz	x8, 0x1015c7a44 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4ed0>
1015c73f8: f942e7f5    	ldr	x21, [sp, #0x5c8]
1015c73fc: f942ebe9    	ldr	x9, [sp, #0x5d0]
1015c7400: 911483ea    	add	x10, sp, #0x520
1015c7404: 3ccb8140    	ldur	q0, [x10, #0xb8]
1015c7408: 9118c3eb    	add	x11, sp, #0x630
1015c740c: 3c818160    	stur	q0, [x11, #0x18]
1015c7410: 3ccc8140    	ldur	q0, [x10, #0xc8]
1015c7414: 3c828160    	stur	q0, [x11, #0x28]
1015c7418: f942ffea    	ldr	x10, [sp, #0x5f8]
1015c741c: f9031be8    	str	x8, [sp, #0x630]
1015c7420: f9031ff5    	str	x21, [sp, #0x638]
1015c7424: f90337ea    	str	x10, [sp, #0x668]
1015c7428: f90323e9    	str	x9, [sp, #0x640]
1015c742c: f94023e8    	ldr	x8, [sp, #0x40]
1015c7430: f9424909    	ldr	x9, [x8, #0x490]
1015c7434: b9413376    	ldr	w22, [x27, #0x130]
1015c7438: 911a83e8    	add	x8, sp, #0x6a0
1015c743c: 9103c120    	add	x0, x9, #0xf0
1015c7440: 9118c3e2    	add	x2, sp, #0x630
1015c7444: 910be123    	add	x3, x9, #0x2f8
1015c7448: aa1603e1    	mov	x1, x22
1015c744c: 940014f2    	bl	0x1015cc814 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena3put>
1015c7450: 395a83e8    	ldrb	w8, [sp, #0x6a0]
1015c7454: 7100511f    	cmp	w8, #0x14
1015c7458: 54003061    	b.ne	0x1015c7a64 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4ef0>
1015c745c: f94023e8    	ldr	x8, [sp, #0x40]
1015c7460: f9424908    	ldr	x8, [x8, #0x490]
1015c7464: 52800029    	mov	w9, #0x1                ; =1
1015c7468: 39118109    	strb	w9, [x8, #0x460]
1015c746c: f941ae81    	ldr	x1, [x20, #0x358]
1015c7470: eb16003f    	cmp	x1, x22
1015c7474: 54007aa9    	b.ls	0x1015c83c8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5854>
1015c7478: f941aa88    	ldr	x8, [x20, #0x350]
1015c747c: 52802809    	mov	w9, #0x140              ; =320
1015c7480: 9ba922c8    	umaddl	x8, w22, w9, x8
1015c7484: 39449102    	ldrb	w2, [x8, #0x124]
1015c7488: 71001c5f    	cmp	w2, #0x7
1015c748c: 54ff8360    	b.eq	0x1015c64f8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3984>
1015c7490: 911a83e0    	add	x0, sp, #0x6a0
1015c7494: aa1503e1    	mov	x1, x21
1015c7498: 94003aab    	bl	0x1015d5f44 <__RNvNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime4bits>
1015c749c: fd4353e0    	ldr	d0, [sp, #0x6a0]
1015c74a0: b946a3e9    	ldr	w9, [sp, #0x6a0]
1015c74a4: f94357e8    	ldr	x8, [sp, #0x6a8]
1015c74a8: 3dc1afe1    	ldr	q1, [sp, #0x6b0]
1015c74ac: 3dc1b3e2    	ldr	q2, [sp, #0x6c0]
1015c74b0: 3d8107e1    	str	q1, [sp, #0x410]
1015c74b4: 3d810be2    	str	q2, [sp, #0x420]
1015c74b8: 3dc1b7e1    	ldr	q1, [sp, #0x6d0]
1015c74bc: 3dc1bbe2    	ldr	q2, [sp, #0x6e0]
1015c74c0: 3d810fe1    	str	q1, [sp, #0x430]
1015c74c4: 3d8113e2    	str	q2, [sp, #0x440]
1015c74c8: 7100193f    	cmp	w9, #0x6
1015c74cc: 54004581    	b.ne	0x1015c7d7c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5208>
1015c74d0: 52800029    	mov	w9, #0x1                ; =1
1015c74d4: f94027ea    	ldr	x10, [sp, #0x48]
1015c74d8: a900a149    	stp	x9, x8, [x10, #0x8]
1015c74dc: 528000c8    	mov	w8, #0x6                ; =6
1015c74e0: b9000148    	str	w8, [x10]
1015c74e4: 17fffcc9    	b	0x1015c6808 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c94>
1015c74e8: 911a83e0    	add	x0, sp, #0x6a0
1015c74ec: d2800001    	mov	x1, #0x0                ; =0
1015c74f0: 52800102    	mov	w2, #0x8                ; =8
1015c74f4: f94027e3    	ldr	x3, [sp, #0x48]
1015c74f8: 52800104    	mov	w4, #0x8                ; =8
1015c74fc: 52800d05    	mov	w5, #0x68               ; =104
1015c7500: 94601d58    	bl	0x102dcea60 <__RNvMs4_NtCsgKscDXrlV49_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs29QkOtpKx6e_8mech_gpu>
1015c7504: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c7508: 360009a8    	tbz	w8, #0x0, 0x1015c763c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4ac8>
1015c750c: 9000d3a8    	adrp	x8, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c7510: 9126f908    	add	x8, x8, #0x9be
1015c7514: 52800189    	mov	w9, #0xc                ; =12
1015c7518: a900a309    	stp	x9, x8, [x24, #0x8]
1015c751c: 52800348    	mov	w8, #0x1a               ; =26
1015c7520: f9000f08    	str	x8, [x24, #0x18]
1015c7524: b900031f    	str	wzr, [x24]
1015c7528: 17fffc97    	b	0x1015c6784 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c10>
1015c752c: d0012042    	adrp	x2, 0x1039d1000 <_anon.19b44b453da724831023c27de6e0b6f2.288+0x250>
1015c7530: 910e2042    	add	x2, x2, #0x388
1015c7534: f94017e1    	ldr	x1, [sp, #0x28]
1015c7538: 9460b02a    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c753c: 3dc107e1    	ldr	q1, [sp, #0x410]
1015c7540: 3dc10be2    	ldr	q2, [sp, #0x420]
1015c7544: f94027e9    	ldr	x9, [sp, #0x48]
1015c7548: ad008921    	stp	q1, q2, [x9, #0x10]
1015c754c: 3dc10fe1    	ldr	q1, [sp, #0x430]
1015c7550: 3dc113e2    	ldr	q2, [sp, #0x440]
1015c7554: ad018921    	stp	q1, q2, [x9, #0x30]
1015c7558: fd000120    	str	d0, [x9]
1015c755c: f9000528    	str	x8, [x9, #0x8]
1015c7560: 17ffff25    	b	0x1015c71f4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4680>
1015c7564: ad4887e0    	ldp	q0, q1, [sp, #0x110]
1015c7568: 3c804340    	stur	q0, [x26, #0x4]
1015c756c: 3c814341    	stur	q1, [x26, #0x14]
1015c7570: 3dc04fe0    	ldr	q0, [sp, #0x130]
1015c7574: 3c824340    	stur	q0, [x26, #0x24]
1015c7578: f940a3e8    	ldr	x8, [sp, #0x140]
1015c757c: 17ffff2b    	b	0x1015c7228 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46b4>
1015c7580: f94027e8    	ldr	x8, [sp, #0x48]
1015c7584: b900011f    	str	wzr, [x8]
1015c7588: 52800189    	mov	w9, #0xc                ; =12
1015c758c: 39002109    	strb	w9, [x8, #0x8]
1015c7590: 9000d3a9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c7594: 911e4929    	add	x9, x9, #0x792
1015c7598: 528004ea    	mov	w10, #0x27              ; =39
1015c759c: a9012909    	stp	x9, x10, [x8, #0x10]
1015c75a0: 14000124    	b	0x1015c7a30 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4ebc>
1015c75a4: 394dc7e9    	ldrb	w9, [sp, #0x371]
1015c75a8: 3cc42320    	ldur	q0, [x25, #0x42]
1015c75ac: 911043ea    	add	x10, sp, #0x410
1015c75b0: 3c802140    	stur	q0, [x10, #0x2]
1015c75b4: 3cc52320    	ldur	q0, [x25, #0x52]
1015c75b8: 3c812140    	stur	q0, [x10, #0x12]
1015c75bc: 3cc62320    	ldur	q0, [x25, #0x62]
1015c75c0: 3c822140    	stur	q0, [x10, #0x22]
1015c75c4: f941d3ea    	ldr	x10, [sp, #0x3a0]
1015c75c8: f90223ea    	str	x10, [sp, #0x440]
1015c75cc: 391043e8    	strb	w8, [sp, #0x410]
1015c75d0: 391047e9    	strb	w9, [sp, #0x411]
1015c75d4: f941ba81    	ldr	x1, [x20, #0x370]
1015c75d8: f941be82    	ldr	x2, [x20, #0x378]
1015c75dc: 911a83e0    	add	x0, sp, #0x6a0
1015c75e0: 911043e4    	add	x4, sp, #0x410
1015c75e4: aa1503e3    	mov	x3, x21
1015c75e8: 97ff908b    	bl	0x1015ab814 <__RNCNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB7_10Invocation6helpersc_0Bf_>
1015c75ec: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c75f0: 395a93e9    	ldrb	w9, [sp, #0x6a4]
1015c75f4: 3cc15340    	ldur	q0, [x26, #0x15]
1015c75f8: f94027ea    	ldr	x10, [sp, #0x48]
1015c75fc: 3c815140    	stur	q0, [x10, #0x15]
1015c7600: 3cc25340    	ldur	q0, [x26, #0x25]
1015c7604: 3c825140    	stur	q0, [x10, #0x25]
1015c7608: 3cc35340    	ldur	q0, [x26, #0x35]
1015c760c: 3c835140    	stur	q0, [x10, #0x35]
1015c7610: 3dc1bbe0    	ldr	q0, [sp, #0x6e0]
1015c7614: 3d801140    	str	q0, [x10, #0x40]
1015c7618: 3cc05340    	ldur	q0, [x26, #0x5]
1015c761c: 3c805140    	stur	q0, [x10, #0x5]
1015c7620: b9000148    	str	w8, [x10]
1015c7624: 39001149    	strb	w9, [x10, #0x4]
1015c7628: f942e3e8    	ldr	x8, [sp, #0x5c0]
1015c762c: b4fdc7a8    	cbz	x8, 0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c7630: 911703e0    	add	x0, sp, #0x5c0
1015c7634: 97ff7e83    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c7638: 17ffee3a    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c763c: f90003ff    	str	xzr, [sp]
1015c7640: f9000fff    	str	xzr, [sp, #0x18]
1015c7644: f94357e8    	ldr	x8, [sp, #0x6a8]
1015c7648: f94027e9    	ldr	x9, [sp, #0x48]
1015c764c: f90427e9    	str	x9, [sp, #0x848]
1015c7650: f9042be8    	str	x8, [sp, #0x850]
1015c7654: f9042fff    	str	xzr, [sp, #0x858]
1015c7658: f94023e8    	ldr	x8, [sp, #0x40]
1015c765c: b8404509    	ldr	w9, [x8], #0x4
1015c7660: f90023e8    	str	x8, [sp, #0x40]
1015c7664: f943f3e8    	ldr	x8, [sp, #0x7e0]
1015c7668: f942c501    	ldr	x1, [x8, #0x588]
1015c766c: f9001be9    	str	x9, [sp, #0x30]
1015c7670: eb09003f    	cmp	x1, x9
1015c7674: 54006b49    	b.ls	0x1015c83dc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5868>
1015c7678: f942c108    	ldr	x8, [x8, #0x580]
1015c767c: 52800b09    	mov	w9, #0x58               ; =88
1015c7680: f9401bea    	ldr	x10, [sp, #0x30]
1015c7684: 9ba92148    	umaddl	x8, w10, w9, x8
1015c7688: f90017e8    	str	x8, [sp, #0x28]
1015c768c: b9405101    	ldr	w1, [x8, #0x50]
1015c7690: 911a83e8    	add	x8, sp, #0x6a0
1015c7694: 9103c380    	add	x0, x28, #0xf0
1015c7698: 910be382    	add	x2, x28, #0x2f8
1015c769c: 94000d9b    	bl	0x1015cad08 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
1015c76a0: f94353e8    	ldr	x8, [sp, #0x6a0]
1015c76a4: 911a83e9    	add	x9, sp, #0x6a0
1015c76a8: 3cc08120    	ldur	q0, [x9, #0x8]
1015c76ac: 3cc18121    	ldur	q1, [x9, #0x18]
1015c76b0: 3d815fe0    	str	q0, [sp, #0x570]
1015c76b4: 3d8163e1    	str	q1, [sp, #0x580]
1015c76b8: 3cc28120    	ldur	q0, [x9, #0x28]
1015c76bc: 3d8167e0    	str	q0, [sp, #0x590]
1015c76c0: f8438129    	ldur	x9, [x9, #0x38]
1015c76c4: f902d3e9    	str	x9, [sp, #0x5a0]
1015c76c8: b4001fc8    	cbz	x8, 0x1015c7ac0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4f4c>
1015c76cc: f942d3e9    	ldr	x9, [sp, #0x5a0]
1015c76d0: 9118c3ea    	add	x10, sp, #0x630
1015c76d4: f8038149    	stur	x9, [x10, #0x38]
1015c76d8: 3dc167e0    	ldr	q0, [sp, #0x590]
1015c76dc: 3c828140    	stur	q0, [x10, #0x28]
1015c76e0: 3dc163e0    	ldr	q0, [sp, #0x580]
1015c76e4: 3dc15fe1    	ldr	q1, [sp, #0x570]
1015c76e8: 3c818140    	stur	q0, [x10, #0x18]
1015c76ec: 3c808141    	stur	q1, [x10, #0x8]
1015c76f0: f9031be8    	str	x8, [sp, #0x630]
1015c76f4: f9431fe8    	ldr	x8, [sp, #0x638]
1015c76f8: f9400908    	ldr	x8, [x8, #0x10]
1015c76fc: 39404108    	ldrb	w8, [x8, #0x10]
1015c7700: 321f0108    	orr	w8, w8, #0x2
1015c7704: 71006d1f    	cmp	w8, #0x1b
1015c7708: 54003261    	b.ne	0x1015c7d54 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x51e0>
1015c770c: 911a83e8    	add	x8, sp, #0x6a0
1015c7710: 9118c3e0    	add	x0, sp, #0x630
1015c7714: 97feac7b    	bl	0x101572900 <__RNvNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime11collections12source_count>
1015c7718: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c771c: 7100191f    	cmp	w8, #0x6
1015c7720: 54001f61    	b.ne	0x1015c7b0c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4f98>
1015c7724: f94357e8    	ldr	x8, [sp, #0x6a8]
1015c7728: f90027e8    	str	x8, [sp, #0x48]
1015c772c: f9401be8    	ldr	x8, [sp, #0x30]
1015c7730: eb08037f    	cmp	x27, x8
1015c7734: 54000081    	b.ne	0x1015c7744 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4bd0>
1015c7738: f94027e8    	ldr	x8, [sp, #0x48]
1015c773c: eb17011f    	cmp	x8, x23
1015c7740: 54001fc1    	b.ne	0x1015c7b38 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4fc4>
1015c7744: f9400fe8    	ldr	x8, [sp, #0x18]
1015c7748: f94027e9    	ldr	x9, [sp, #0x48]
1015c774c: ab080128    	adds	x8, x9, x8
1015c7750: f9000fe8    	str	x8, [sp, #0x18]
1015c7754: 54003e62    	b.hs	0x1015c7f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x53ac>
1015c7758: f94027e8    	ldr	x8, [sp, #0x48]
1015c775c: b4001fc8    	cbz	x8, 0x1015c7b54 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4fe0>
1015c7760: f9400fe8    	ldr	x8, [sp, #0x18]
1015c7764: eb15011f    	cmp	x8, x21
1015c7768: 54001f68    	b.hi	0x1015c7b54 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4fe0>
1015c776c: f94017e8    	ldr	x8, [sp, #0x28]
1015c7770: f9400508    	ldr	x8, [x8, #0x8]
1015c7774: f90007e8    	str	x8, [sp, #0x8]
1015c7778: b5000408    	cbnz	x8, 0x1015c77f8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4c84>
1015c777c: f90003ff    	str	xzr, [sp]
1015c7780: f94007e8    	ldr	x8, [sp, #0x8]
1015c7784: f902e3e8    	str	x8, [sp, #0x5c0]
1015c7788: 52800108    	mov	w8, #0x8                ; =8
1015c778c: f902e7e8    	str	x8, [sp, #0x5c8]
1015c7790: f902ebff    	str	xzr, [sp, #0x5d0]
1015c7794: 3dc18fe0    	ldr	q0, [sp, #0x630]
1015c7798: 3dc193e1    	ldr	q1, [sp, #0x640]
1015c779c: 911a83e8    	add	x8, sp, #0x6a0
1015c77a0: 3c818100    	stur	q0, [x8, #0x18]
1015c77a4: 3c828101    	stur	q1, [x8, #0x28]
1015c77a8: 3dc197e0    	ldr	q0, [sp, #0x650]
1015c77ac: 3dc19be1    	ldr	q1, [sp, #0x660]
1015c77b0: 3c838100    	stur	q0, [x8, #0x38]
1015c77b4: 3c848101    	stur	q1, [x8, #0x48]
1015c77b8: 3dc173e0    	ldr	q0, [sp, #0x5c0]
1015c77bc: 3d81abe0    	str	q0, [sp, #0x6a0]
1015c77c0: f942ebe8    	ldr	x8, [sp, #0x5d0]
1015c77c4: f9035be8    	str	x8, [sp, #0x6b0]
1015c77c8: f9401be8    	ldr	x8, [sp, #0x30]
1015c77cc: f9037fe8    	str	x8, [sp, #0x6f8]
1015c77d0: f94027e8    	ldr	x8, [sp, #0x48]
1015c77d4: f90383e8    	str	x8, [sp, #0x700]
1015c77d8: 912123e0    	add	x0, sp, #0x848
1015c77dc: 911a83e1    	add	x1, sp, #0x6a0
1015c77e0: 9400175b    	bl	0x1015cd54c <__RNvMsF_NtCsgKscDXrlV49_5alloc3vecINtB5_3VecNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionE8push_mutBR_>
1015c77e4: f94023e8    	ldr	x8, [sp, #0x40]
1015c77e8: f94013e9    	ldr	x9, [sp, #0x20]
1015c77ec: eb09011f    	cmp	x8, x9
1015c77f0: 54fff341    	b.ne	0x1015c7658 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4ae4>
1015c77f4: 140000de    	b	0x1015c7b6c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4ff8>
1015c77f8: f94017e8    	ldr	x8, [sp, #0x28]
1015c77fc: f9400108    	ldr	x8, [x8]
1015c7800: f9000be8    	str	x8, [sp, #0x10]
1015c7804: 911a83e0    	add	x0, sp, #0x6a0
1015c7808: d2800001    	mov	x1, #0x0                ; =0
1015c780c: 52800102    	mov	w2, #0x8                ; =8
1015c7810: f94007e3    	ldr	x3, [sp, #0x8]
1015c7814: 52800104    	mov	w4, #0x8                ; =8
1015c7818: 52800905    	mov	w5, #0x48               ; =72
1015c781c: 94601c91    	bl	0x102dcea60 <__RNvMs4_NtCsgKscDXrlV49_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs29QkOtpKx6e_8mech_gpu>
1015c7820: f94353e8    	ldr	x8, [sp, #0x6a0]
1015c7824: f100051f    	cmp	x8, #0x1
1015c7828: 54003220    	b.eq	0x1015c7e6c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x52f8>
1015c782c: f94357e8    	ldr	x8, [sp, #0x6a8]
1015c7830: f94007ea    	ldr	x10, [sp, #0x8]
1015c7834: 9278d949    	and	x9, x10, #0x7fffffffffffff00
1015c7838: f902e3ea    	str	x10, [sp, #0x5c0]
1015c783c: f902e7e8    	str	x8, [sp, #0x5c8]
1015c7840: f902ebff    	str	xzr, [sp, #0x5d0]
1015c7844: d37ef548    	lsl	x8, x10, #2
1015c7848: a90023e9    	stp	x9, x8, [sp]
1015c784c: 1400000e    	b	0x1015c7884 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4d10>
1015c7850: f94016c8    	ldr	x8, [x22, #0x28]
1015c7854: f94017e9    	ldr	x9, [sp, #0x28]
1015c7858: f8697908    	ldr	x8, [x8, x9, lsl #3]
1015c785c: f90357e8    	str	x8, [sp, #0x6a8]
1015c7860: b906a7e9    	str	w9, [sp, #0x6a4]
1015c7864: b906a3ff    	str	wzr, [sp, #0x6a0]
1015c7868: 911703e0    	add	x0, sp, #0x5c0
1015c786c: 911a83e1    	add	x1, sp, #0x6a0
1015c7870: 9400175c    	bl	0x1015cd5e0 <__RNvMsF_NtCsgKscDXrlV49_5alloc3vecINtB5_3VecNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureE8push_mutBR_>
1015c7874: f94007e8    	ldr	x8, [sp, #0x8]
1015c7878: f1001108    	subs	x8, x8, #0x4
1015c787c: f90007e8    	str	x8, [sp, #0x8]
1015c7880: 54fff8a0    	b.eq	0x1015c7794 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4c20>
1015c7884: f9400be8    	ldr	x8, [sp, #0x10]
1015c7888: b8404509    	ldr	w9, [x8], #0x4
1015c788c: f9000be8    	str	x8, [sp, #0x10]
1015c7890: f943f3e8    	ldr	x8, [sp, #0x7e0]
1015c7894: f941ad01    	ldr	x1, [x8, #0x358]
1015c7898: f90017e9    	str	x9, [sp, #0x28]
1015c789c: eb09003f    	cmp	x1, x9
1015c78a0: 54005a89    	b.ls	0x1015c83f0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x587c>
1015c78a4: f941a908    	ldr	x8, [x8, #0x350]
1015c78a8: 52802809    	mov	w9, #0x140              ; =320
1015c78ac: f94017ea    	ldr	x10, [sp, #0x28]
1015c78b0: 9ba92148    	umaddl	x8, w10, w9, x8
1015c78b4: 39449108    	ldrb	w8, [x8, #0x124]
1015c78b8: 71001d1f    	cmp	w8, #0x7
1015c78bc: 54fffca1    	b.ne	0x1015c7850 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4cdc>
1015c78c0: 911043e8    	add	x8, sp, #0x410
1015c78c4: 9103c380    	add	x0, x28, #0xf0
1015c78c8: 910be382    	add	x2, x28, #0x2f8
1015c78cc: f94017e1    	ldr	x1, [sp, #0x28]
1015c78d0: 94000d0e    	bl	0x1015cad08 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
1015c78d4: f9420be8    	ldr	x8, [sp, #0x410]
1015c78d8: 911043e9    	add	x9, sp, #0x410
1015c78dc: 3cc08120    	ldur	q0, [x9, #0x8]
1015c78e0: 3cc18121    	ldur	q1, [x9, #0x18]
1015c78e4: ad1387e0    	stp	q0, q1, [sp, #0x270]
1015c78e8: 3cc28120    	ldur	q0, [x9, #0x28]
1015c78ec: 3d80a7e0    	str	q0, [sp, #0x290]
1015c78f0: f8438129    	ldur	x9, [x9, #0x38]
1015c78f4: f90153e9    	str	x9, [sp, #0x2a0]
1015c78f8: b4002048    	cbz	x8, 0x1015c7d00 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x518c>
1015c78fc: ad5387e0    	ldp	q0, q1, [sp, #0x270]
1015c7900: 911a83ea    	add	x10, sp, #0x6a0
1015c7904: ad008540    	stp	q0, q1, [x10, #0x10]
1015c7908: 3dc0a7e0    	ldr	q0, [sp, #0x290]
1015c790c: 3c830140    	stur	q0, [x10, #0x30]
1015c7910: f94153e9    	ldr	x9, [sp, #0x2a0]
1015c7914: f8040149    	stur	x9, [x10, #0x40]
1015c7918: f90357e8    	str	x8, [sp, #0x6a8]
1015c791c: f94017e8    	ldr	x8, [sp, #0x28]
1015c7920: b906a7e8    	str	w8, [sp, #0x6a4]
1015c7924: 52800028    	mov	w8, #0x1                ; =1
1015c7928: b906a3e8    	str	w8, [sp, #0x6a0]
1015c792c: 911703e0    	add	x0, sp, #0x5c0
1015c7930: 911a83e1    	add	x1, sp, #0x6a0
1015c7934: 9400172b    	bl	0x1015cd5e0 <__RNvMsF_NtCsgKscDXrlV49_5alloc3vecINtB5_3VecNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureE8push_mutBR_>
1015c7938: 17ffffcf    	b	0x1015c7874 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4d00>
1015c793c: f94027e8    	ldr	x8, [sp, #0x48]
1015c7940: b900011f    	str	wzr, [x8]
1015c7944: 52800189    	mov	w9, #0xc                ; =12
1015c7948: 39002109    	strb	w9, [x8, #0x8]
1015c794c: 9000d3a9    	adrp	x9, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c7950: 911b4929    	add	x9, x9, #0x6d2
1015c7954: 5280048a    	mov	w10, #0x24              ; =36
1015c7958: 17ffece1    	b	0x1015c2cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168>
1015c795c: b946a7e9    	ldr	w9, [sp, #0x6a4]
1015c7960: 911a83ea    	add	x10, sp, #0x6a0
1015c7964: ad408540    	ldp	q0, q1, [x10, #0x10]
1015c7968: 3d8107e0    	str	q0, [sp, #0x410]
1015c796c: 3d810be1    	str	q1, [sp, #0x420]
1015c7970: 3cc30142    	ldur	q2, [x10, #0x30]
1015c7974: 3d810fe2    	str	q2, [sp, #0x430]
1015c7978: f844014a    	ldur	x10, [x10, #0x40]
1015c797c: f90223ea    	str	x10, [sp, #0x440]
1015c7980: f94357eb    	ldr	x11, [sp, #0x6a8]
1015c7984: f94377ec    	ldr	x12, [sp, #0x6e8]
1015c7988: f94027ed    	ldr	x13, [sp, #0x48]
1015c798c: ad0085a0    	stp	q0, q1, [x13, #0x10]
1015c7990: 3d800da2    	str	q2, [x13, #0x30]
1015c7994: 290025a8    	stp	w8, w9, [x13]
1015c7998: f90005ab    	str	x11, [x13, #0x8]
1015c799c: a90431aa    	stp	x10, x12, [x13, #0x40]
1015c79a0: 17ffed60    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c79a4: ad4b87e0    	ldp	q0, q1, [sp, #0x170]
1015c79a8: 3c804340    	stur	q0, [x26, #0x4]
1015c79ac: 3c814341    	stur	q1, [x26, #0x14]
1015c79b0: 3dc067e0    	ldr	q0, [sp, #0x190]
1015c79b4: 3c824340    	stur	q0, [x26, #0x24]
1015c79b8: f940d3e8    	ldr	x8, [sp, #0x1a0]
1015c79bc: 17fffb7b    	b	0x1015c67a8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c34>
1015c79c0: b900031f    	str	wzr, [x24]
1015c79c4: 52800188    	mov	w8, #0xc                ; =12
1015c79c8: b000d389    	adrp	x9, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c79cc: 9102e129    	add	x9, x9, #0xb8
1015c79d0: 14000005    	b	0x1015c79e4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4e70>
1015c79d4: b900031f    	str	wzr, [x24]
1015c79d8: 52800188    	mov	w8, #0xc                ; =12
1015c79dc: b000d389    	adrp	x9, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c79e0: 91382129    	add	x9, x9, #0xe08
1015c79e4: a900a708    	stp	x8, x9, [x24, #0x8]
1015c79e8: 52800348    	mov	w8, #0x1a               ; =26
1015c79ec: f9000f08    	str	x8, [x24, #0x18]
1015c79f0: 17fffca6    	b	0x1015c6c88 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4114>
1015c79f4: f941ba81    	ldr	x1, [x20, #0x370]
1015c79f8: f941be82    	ldr	x2, [x20, #0x378]
1015c79fc: 911a83e0    	add	x0, sp, #0x6a0
1015c7a00: 910523e4    	add	x4, sp, #0x148
1015c7a04: aa1503e3    	mov	x3, x21
1015c7a08: 97ff8f60    	bl	0x1015ab788 <__RNCNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB7_10Invocation6helpersa_0Bf_>
1015c7a0c: 3dc1b3e0    	ldr	q0, [sp, #0x6c0]
1015c7a10: 3dc1b7e1    	ldr	q1, [sp, #0x6d0]
1015c7a14: f94027e8    	ldr	x8, [sp, #0x48]
1015c7a18: ad010500    	stp	q0, q1, [x8, #0x20]
1015c7a1c: 3dc1bbe0    	ldr	q0, [sp, #0x6e0]
1015c7a20: 3d801100    	str	q0, [x8, #0x40]
1015c7a24: 3dc1afe0    	ldr	q0, [sp, #0x6b0]
1015c7a28: 3dc1abe1    	ldr	q1, [sp, #0x6a0]
1015c7a2c: ad000101    	stp	q1, q0, [x8]
1015c7a30: 911043e0    	add	x0, sp, #0x410
1015c7a34: 97ff7d83    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c7a38: 910dc3e0    	add	x0, sp, #0x370
1015c7a3c: 97ff7d81    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c7a40: 17ffed38    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c7a44: f94027e8    	ldr	x8, [sp, #0x48]
1015c7a48: b900011f    	str	wzr, [x8]
1015c7a4c: 52800189    	mov	w9, #0xc                ; =12
1015c7a50: b000d38a    	adrp	x10, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c7a54: 9134014a    	add	x10, x10, #0xd00
1015c7a58: a900a909    	stp	x9, x10, [x8, #0x8]
1015c7a5c: 528002c9    	mov	w9, #0x16               ; =22
1015c7a60: 17ffed2f    	b	0x1015c2f1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a8>
1015c7a64: b8401349    	ldur	w9, [x26, #0x1]
1015c7a68: f94027ea    	ldr	x10, [sp, #0x48]
1015c7a6c: b8009149    	stur	w9, [x10, #0x9]
1015c7a70: b946a7e9    	ldr	w9, [sp, #0x6a4]
1015c7a74: b9000d49    	str	w9, [x10, #0xc]
1015c7a78: 3dc1b3e0    	ldr	q0, [sp, #0x6c0]
1015c7a7c: 3c828140    	stur	q0, [x10, #0x28]
1015c7a80: f9436be9    	ldr	x9, [sp, #0x6d0]
1015c7a84: f9001d49    	str	x9, [x10, #0x38]
1015c7a88: fd435fe0    	ldr	d0, [sp, #0x6b8]
1015c7a8c: 3cc08341    	ldur	q1, [x26, #0x8]
1015c7a90: 52800049    	mov	w9, #0x2                ; =2
1015c7a94: b9000149    	str	w9, [x10]
1015c7a98: 39002148    	strb	w8, [x10, #0x8]
1015c7a9c: 3d800541    	str	q1, [x10, #0x10]
1015c7aa0: fd001140    	str	d0, [x10, #0x20]
1015c7aa4: 9118c3e0    	add	x0, sp, #0x630
1015c7aa8: 97ff7d66    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c7aac: 17ffed1d    	b	0x1015c2f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac>
1015c7ab0: d2800013    	mov	x19, #0x0               ; =0
1015c7ab4: 911043e0    	add	x0, sp, #0x410
1015c7ab8: 97ff7d62    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c7abc: 17fffd49    	b	0x1015c6fe0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x446c>
1015c7ac0: 3dc15fe0    	ldr	q0, [sp, #0x570]
1015c7ac4: 3dc163e1    	ldr	q1, [sp, #0x580]
1015c7ac8: 3c804340    	stur	q0, [x26, #0x4]
1015c7acc: 3c814341    	stur	q1, [x26, #0x14]
1015c7ad0: 3dc167e0    	ldr	q0, [sp, #0x590]
1015c7ad4: 3c824340    	stur	q0, [x26, #0x24]
1015c7ad8: f942d3e8    	ldr	x8, [sp, #0x5a0]
1015c7adc: f8034348    	stur	x8, [x26, #0x34]
1015c7ae0: 3dc1abe0    	ldr	q0, [sp, #0x6a0]
1015c7ae4: 3dc1afe1    	ldr	q1, [sp, #0x6b0]
1015c7ae8: 3c804300    	stur	q0, [x24, #0x4]
1015c7aec: 52800048    	mov	w8, #0x2                ; =2
1015c7af0: b9000308    	str	w8, [x24]
1015c7af4: 3c814301    	stur	q1, [x24, #0x14]
1015c7af8: 3dc1b3e0    	ldr	q0, [sp, #0x6c0]
1015c7afc: 3c824300    	stur	q0, [x24, #0x24]
1015c7b00: 3cc2c340    	ldur	q0, [x26, #0x2c]
1015c7b04: 3d800f00    	str	q0, [x24, #0x30]
1015c7b08: 17fffb1d    	b	0x1015c677c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c08>
1015c7b0c: b946a7e9    	ldr	w9, [sp, #0x6a4]
1015c7b10: f94357ea    	ldr	x10, [sp, #0x6a8]
1015c7b14: 3dc1afe0    	ldr	q0, [sp, #0x6b0]
1015c7b18: 3dc1b3e1    	ldr	q1, [sp, #0x6c0]
1015c7b1c: ad008700    	stp	q0, q1, [x24, #0x10]
1015c7b20: 3dc1b7e0    	ldr	q0, [sp, #0x6d0]
1015c7b24: 3dc1bbe1    	ldr	q1, [sp, #0x6e0]
1015c7b28: ad018700    	stp	q0, q1, [x24, #0x30]
1015c7b2c: 29002708    	stp	w8, w9, [x24]
1015c7b30: f900070a    	str	x10, [x24, #0x8]
1015c7b34: 1400008f    	b	0x1015c7d70 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x51fc>
1015c7b38: b900031f    	str	wzr, [x24]
1015c7b3c: 52800188    	mov	w8, #0xc                ; =12
1015c7b40: 39002308    	strb	w8, [x24, #0x8]
1015c7b44: 9000d3a8    	adrp	x8, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c7b48: 9127cd08    	add	x8, x8, #0x9f3
1015c7b4c: 52800489    	mov	w9, #0x24               ; =36
1015c7b50: 14000087    	b	0x1015c7d6c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x51f8>
1015c7b54: d000d1a8    	adrp	x8, 0x102ffd000 <_anon.70399bd8ea3438f11774e3396e76a872.10+0x30c2>
1015c7b58: 3dc15d00    	ldr	q0, [x8, #0x570]
1015c7b5c: 3c808300    	stur	q0, [x24, #0x8]
1015c7b60: 528000c8    	mov	w8, #0x6                ; =6
1015c7b64: b9000308    	str	w8, [x24]
1015c7b68: 14000082    	b	0x1015c7d70 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x51fc>
1015c7b6c: f9400fe8    	ldr	x8, [sp, #0x18]
1015c7b70: f100091f    	cmp	x8, #0x2
1015c7b74: 54ff5fa3    	b.lo	0x1015c6768 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3bf4>
1015c7b78: f9400fe8    	ldr	x8, [sp, #0x18]
1015c7b7c: f81003a8    	stur	x8, [x29, #-0x100]
1015c7b80: 8b081508    	add	x8, x8, x8, lsl #5
1015c7b84: d370bd01    	lsl	x1, x8, #16
1015c7b88: 911a83e8    	add	x8, sp, #0x6a0
1015c7b8c: 911fa3e0    	add	x0, sp, #0x7e8
1015c7b90: 945c7d09    	bl	0x102ce6fb4 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
1015c7b94: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c7b98: 7100691f    	cmp	w8, #0x1a
1015c7b9c: 540010e1    	b.ne	0x1015c7db8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5244>
1015c7ba0: 3cc08340    	ldur	q0, [x26, #0x8]
1015c7ba4: 3cc18341    	ldur	q1, [x26, #0x18]
1015c7ba8: ad1f07e0    	stp	q0, q1, [sp, #0x3e0]
1015c7bac: f9442ff5    	ldr	x21, [sp, #0x858]
1015c7bb0: b5001c95    	cbnz	x21, 0x1015c7f40 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x53cc>
1015c7bb4: d2800008    	mov	x8, #0x0                ; =0
1015c7bb8: 52800109    	mov	w9, #0x8                ; =8
1015c7bbc: a930a7b5    	stp	x21, x9, [x29, #-0xf8]
1015c7bc0: f81183bf    	stur	xzr, [x29, #-0xe8]
1015c7bc4: f9442be1    	ldr	x1, [sp, #0x850]
1015c7bc8: 52800d09    	mov	w9, #0x68               ; =104
1015c7bcc: 9b090502    	madd	x2, x8, x9, x1
1015c7bd0: 52800037    	mov	w23, #0x1               ; =1
1015c7bd4: d103e3a0    	sub	x0, x29, #0xf8
1015c7bd8: 5280003b    	mov	w27, #0x1               ; =1
1015c7bdc: 97fb4074    	bl	0x101497dac <__RINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB6_3VecjE14extend_trustedINtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB17_5slice4iter4IterNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionENCNvMs0_B2f_NtB2h_10Invocation12run_parallels9_0EEB2p_>
1015c7be0: a9710fa2    	ldp	x2, x3, [x29, #-0xf0]
1015c7be4: 911a83e0    	add	x0, sp, #0x6a0
1015c7be8: aa1303e1    	mov	x1, x19
1015c7bec: 97ffd0d8    	bl	0x1015bbf4c <__RNvMNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel9admissionNtB6_10Invocation18parallel_admission>
1015c7bf0: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c7bf4: 7100191f    	cmp	w8, #0x6
1015c7bf8: 54000fe1    	b.ne	0x1015c7df4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5280>
1015c7bfc: f94357e8    	ldr	x8, [sp, #0x6a8]
1015c7c00: 3dc1afe0    	ldr	q0, [sp, #0x6b0]
1015c7c04: 3c9203a0    	stur	q0, [x29, #-0xe0]
1015c7c08: f94363e9    	ldr	x9, [sp, #0x6c0]
1015c7c0c: f81303a9    	stur	x9, [x29, #-0xd0]
1015c7c10: b4001408    	cbz	x8, 0x1015c7e90 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x531c>
1015c7c14: 3cd203a0    	ldur	q0, [x29, #-0xe0]
1015c7c18: 911ea3e9    	add	x9, sp, #0x7a8
1015c7c1c: 3c808120    	stur	q0, [x9, #0x8]
1015c7c20: f85303a9    	ldur	x9, [x29, #-0xd0]
1015c7c24: f903d7e8    	str	x8, [sp, #0x7a8]
1015c7c28: f903e3e9    	str	x9, [sp, #0x7c0]
1015c7c2c: f943f3e0    	ldr	x0, [sp, #0x7e0]
1015c7c30: 911a83e8    	add	x8, sp, #0x6a0
1015c7c34: 911fa3e1    	add	x1, sp, #0x7e8
1015c7c38: f9400fe2    	ldr	x2, [sp, #0x18]
1015c7c3c: 9400a75f    	bl	0x1015f19b8 <__RNvNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel17worker_setup_fits>
1015c7c40: b946a3e9    	ldr	w9, [sp, #0x6a0]
1015c7c44: 395a93e8    	ldrb	w8, [sp, #0x6a4]
1015c7c48: 7100193f    	cmp	w9, #0x6
1015c7c4c: 54001441    	b.ne	0x1015c7ed4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5360>
1015c7c50: 360015c8    	tbz	w8, #0x0, 0x1015c7f08 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5394>
1015c7c54: f943f3e8    	ldr	x8, [sp, #0x7e0]
1015c7c58: f941cd01    	ldr	x1, [x8, #0x398]
1015c7c5c: b9403280    	ldr	w0, [x20, #0x30]
1015c7c60: eb00003f    	cmp	x1, x0
1015c7c64: 54003d09    	b.ls	0x1015c8404 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5890>
1015c7c68: f941c908    	ldr	x8, [x8, #0x390]
1015c7c6c: 5280a809    	mov	w9, #0x540              ; =1344
1015c7c70: 9ba92008    	umaddl	x8, w0, w9, x8
1015c7c74: b9452109    	ldr	w9, [x8, #0x520]
1015c7c78: 3dc14500    	ldr	q0, [x8, #0x510]
1015c7c7c: 3c9403a0    	stur	q0, [x29, #-0xc0]
1015c7c80: b81503a9    	stur	w9, [x29, #-0xb0]
1015c7c84: 911a83e8    	add	x8, sp, #0x6a0
1015c7c88: 910ee380    	add	x0, x28, #0x3b8
1015c7c8c: 94354773    	bl	0x102319a58 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
1015c7c90: f94353e8    	ldr	x8, [sp, #0x6a0]
1015c7c94: f100051f    	cmp	x8, #0x1
1015c7c98: 54001941    	b.ne	0x1015c7fc0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x544c>
1015c7c9c: f94357e1    	ldr	x1, [sp, #0x6a8]
1015c7ca0: f9435be2    	ldr	x2, [sp, #0x6b0]
1015c7ca4: 911a83f4    	add	x20, sp, #0x6a0
1015c7ca8: 911a83e8    	add	x8, sp, #0x6a0
1015c7cac: 910ee380    	add	x0, x28, #0x3b8
1015c7cb0: 911fa3e3    	add	x3, sp, #0x7e8
1015c7cb4: 9435518c    	bl	0x10231c2e4 <__RNvMs3_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workersNtB7_23NativeLibraryWorkBudget32reserve_worker_group_with_memory>
1015c7cb8: 395b63e8    	ldrb	w8, [sp, #0x6d8]
1015c7cbc: 7100091f    	cmp	w8, #0x2
1015c7cc0: 54001ba1    	b.ne	0x1015c8034 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x54c0>
1015c7cc4: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c7cc8: 7100691f    	cmp	w8, #0x1a
1015c7ccc: 540028c1    	b.ne	0x1015c81e4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5670>
1015c7cd0: b85403a9    	ldur	w9, [x29, #-0xc0]
1015c7cd4: 385443a8    	ldurb	w8, [x29, #-0xbc]
1015c7cd8: 911ea3ea    	add	x10, sp, #0x7a8
1015c7cdc: b84fd14a    	ldur	w10, [x10, #0xfd]
1015c7ce0: b905c3ea    	str	w10, [sp, #0x5c0]
1015c7ce4: b85483ab    	ldur	w11, [x29, #-0xb8]
1015c7ce8: 911483ea    	add	x10, sp, #0x520
1015c7cec: b80a314b    	stur	w11, [x10, #0xa3]
1015c7cf0: 5280008a    	mov	w10, #0x4               ; =4
1015c7cf4: d10303ab    	sub	x11, x29, #0xc0
1015c7cf8: fc40c160    	ldur	d0, [x11, #0xc]
1015c7cfc: 1400013d    	b	0x1015c81f0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x567c>
1015c7d00: ad5387e0    	ldp	q0, q1, [sp, #0x270]
1015c7d04: 911043e8    	add	x8, sp, #0x410
1015c7d08: 3c804100    	stur	q0, [x8, #0x4]
1015c7d0c: 3c814101    	stur	q1, [x8, #0x14]
1015c7d10: 3dc0a7e0    	ldr	q0, [sp, #0x290]
1015c7d14: 3c824100    	stur	q0, [x8, #0x24]
1015c7d18: f94153e9    	ldr	x9, [sp, #0x2a0]
1015c7d1c: f8034109    	stur	x9, [x8, #0x34]
1015c7d20: 3dc107e0    	ldr	q0, [sp, #0x410]
1015c7d24: 3dc10be1    	ldr	q1, [sp, #0x420]
1015c7d28: 3c804300    	stur	q0, [x24, #0x4]
1015c7d2c: 52800049    	mov	w9, #0x2                ; =2
1015c7d30: b9000309    	str	w9, [x24]
1015c7d34: 3c814301    	stur	q1, [x24, #0x14]
1015c7d38: 3dc10fe0    	ldr	q0, [sp, #0x430]
1015c7d3c: 3c824300    	stur	q0, [x24, #0x24]
1015c7d40: 3cc2c100    	ldur	q0, [x8, #0x2c]
1015c7d44: 3d800f00    	str	q0, [x24, #0x30]
1015c7d48: 911703e0    	add	x0, sp, #0x5c0
1015c7d4c: 97ff77e1    	bl	0x1015a5cd0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
1015c7d50: 14000008    	b	0x1015c7d70 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x51fc>
1015c7d54: b900031f    	str	wzr, [x24]
1015c7d58: 52800188    	mov	w8, #0xc                ; =12
1015c7d5c: 39002308    	strb	w8, [x24, #0x8]
1015c7d60: 9000d3a8    	adrp	x8, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c7d64: 91285d08    	add	x8, x8, #0xa17
1015c7d68: 52800609    	mov	w9, #0x30               ; =48
1015c7d6c: a9012708    	stp	x8, x9, [x24, #0x10]
1015c7d70: 9118c3e0    	add	x0, sp, #0x630
1015c7d74: 97ff7cb3    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c7d78: 17fffa81    	b	0x1015c677c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c08>
1015c7d7c: 3dc107e1    	ldr	q1, [sp, #0x410]
1015c7d80: 3dc10be2    	ldr	q2, [sp, #0x420]
1015c7d84: f94027e9    	ldr	x9, [sp, #0x48]
1015c7d88: ad008921    	stp	q1, q2, [x9, #0x10]
1015c7d8c: 3dc10fe1    	ldr	q1, [sp, #0x430]
1015c7d90: 3dc113e2    	ldr	q2, [sp, #0x440]
1015c7d94: ad018921    	stp	q1, q2, [x9, #0x30]
1015c7d98: fd000120    	str	d0, [x9]
1015c7d9c: f9000528    	str	x8, [x9, #0x8]
1015c7da0: 17fffa9a    	b	0x1015c6808 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c94>
1015c7da4: 5280003c    	mov	w28, #0x1               ; =1
1015c7da8: f0012042    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c7dac: 91098042    	add	x2, x2, #0x260
1015c7db0: 9460ae0c    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c7db4: 14000197    	b	0x1015c8410 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x589c>
1015c7db8: d000d1a8    	adrp	x8, 0x102ffd000 <_anon.70399bd8ea3438f11774e3396e76a872.10+0x30c2>
1015c7dbc: 3dc15d00    	ldr	q0, [x8, #0x570]
1015c7dc0: 3c808300    	stur	q0, [x24, #0x8]
1015c7dc4: 528000c8    	mov	w8, #0x6                ; =6
1015c7dc8: b9000308    	str	w8, [x24]
1015c7dcc: 911a83e0    	add	x0, sp, #0x6a0
1015c7dd0: 97ff7564    	bl	0x1015a5360 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationNtNtB16_5error18MemoryRuntimeErrorEECs29QkOtpKx6e_8mech_gpu>
1015c7dd4: 17fffa6a    	b	0x1015c677c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c08>
1015c7dd8: 9000d380    	adrp	x0, 0x103037000 <_anon.496f237bd13ceadd644cb7ae086b3546.176+0x13b>
1015c7ddc: 91346000    	add	x0, x0, #0xd18
1015c7de0: f0012042    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c7de4: 91068042    	add	x2, x2, #0x1a0
1015c7de8: 52800501    	mov	w1, #0x28               ; =40
1015c7dec: 9460ae54    	bl	0x102df373c <__RNvNtCsgDHHaSskbIF_4core9panicking5panic>
1015c7df0: 14000188    	b	0x1015c8410 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x589c>
1015c7df4: b946a7e9    	ldr	w9, [sp, #0x6a4]
1015c7df8: f94357ea    	ldr	x10, [sp, #0x6a8]
1015c7dfc: 3dc1afe0    	ldr	q0, [sp, #0x6b0]
1015c7e00: 3c9203a0    	stur	q0, [x29, #-0xe0]
1015c7e04: 3cc28341    	ldur	q1, [x26, #0x28]
1015c7e08: 3c828301    	stur	q1, [x24, #0x28]
1015c7e0c: 3cc38341    	ldur	q1, [x26, #0x38]
1015c7e10: f94363eb    	ldr	x11, [sp, #0x6c0]
1015c7e14: f94377ec    	ldr	x12, [sp, #0x6e8]
1015c7e18: f81303ab    	stur	x11, [x29, #-0xd0]
1015c7e1c: 3c838301    	stur	q1, [x24, #0x38]
1015c7e20: f900270c    	str	x12, [x24, #0x48]
1015c7e24: 3d800700    	str	q0, [x24, #0x10]
1015c7e28: f900130b    	str	x11, [x24, #0x20]
1015c7e2c: 29002708    	stp	w8, w9, [x24]
1015c7e30: f900070a    	str	x10, [x24, #0x8]
1015c7e34: 1400001c    	b	0x1015c7ea4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5330>
1015c7e38: f0012042    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c7e3c: 91020042    	add	x2, x2, #0x80
1015c7e40: aa1503e0    	mov	x0, x21
1015c7e44: 9460ade7    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c7e48: d0012042    	adrp	x2, 0x1039d1000 <_anon.19b44b453da724831023c27de6e0b6f2.288+0x250>
1015c7e4c: 910e8042    	add	x2, x2, #0x3a0
1015c7e50: f94017e1    	ldr	x1, [sp, #0x28]
1015c7e54: 9460ade3    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c7e58: 1400016e    	b	0x1015c8410 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x589c>
1015c7e5c: d0012042    	adrp	x2, 0x1039d1000 <_anon.19b44b453da724831023c27de6e0b6f2.288+0x250>
1015c7e60: 913fc042    	add	x2, x2, #0xff0
1015c7e64: aa1503e0    	mov	x0, x21
1015c7e68: 9460adde    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c7e6c: 9000d3a8    	adrp	x8, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c7e70: 91276108    	add	x8, x8, #0x9d8
1015c7e74: f94003e9    	ldr	x9, [sp]
1015c7e78: b27e0529    	orr	x9, x9, #0xc
1015c7e7c: a900a309    	stp	x9, x8, [x24, #0x8]
1015c7e80: 52800368    	mov	w8, #0x1b               ; =27
1015c7e84: f9000f08    	str	x8, [x24, #0x18]
1015c7e88: b900031f    	str	wzr, [x24]
1015c7e8c: 17ffffb9    	b	0x1015c7d70 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x51fc>
1015c7e90: d000d1a8    	adrp	x8, 0x102ffd000 <_anon.70399bd8ea3438f11774e3396e76a872.10+0x30c2>
1015c7e94: 3dc15d00    	ldr	q0, [x8, #0x570]
1015c7e98: 3c808300    	stur	q0, [x24, #0x8]
1015c7e9c: 528000c8    	mov	w8, #0x6                ; =6
1015c7ea0: b9000308    	str	w8, [x24]
1015c7ea4: f85083a8    	ldur	x8, [x29, #-0xf8]
1015c7ea8: b4001f68    	cbz	x8, 0x1015c8294 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5720>
1015c7eac: f85103a0    	ldur	x0, [x29, #-0xf0]
1015c7eb0: d37df101    	lsl	x1, x8, #3
1015c7eb4: 52800102    	mov	w2, #0x8                ; =8
1015c7eb8: 97a905a1    	bl	0x10000953c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1015c7ebc: 140000f6    	b	0x1015c8294 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5720>
1015c7ec0: f0012042    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c7ec4: 91008042    	add	x2, x2, #0x20
1015c7ec8: aa1503e0    	mov	x0, x21
1015c7ecc: 9460adc5    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c7ed0: 14000150    	b	0x1015c8410 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x589c>
1015c7ed4: 3cc15340    	ldur	q0, [x26, #0x15]
1015c7ed8: 3c815300    	stur	q0, [x24, #0x15]
1015c7edc: 3cc25340    	ldur	q0, [x26, #0x25]
1015c7ee0: 3c825300    	stur	q0, [x24, #0x25]
1015c7ee4: 3cc35340    	ldur	q0, [x26, #0x35]
1015c7ee8: 3c835300    	stur	q0, [x24, #0x35]
1015c7eec: 3dc1bbe0    	ldr	q0, [sp, #0x6e0]
1015c7ef0: 3d801300    	str	q0, [x24, #0x40]
1015c7ef4: 3cc05340    	ldur	q0, [x26, #0x5]
1015c7ef8: 3c805300    	stur	q0, [x24, #0x5]
1015c7efc: b9000309    	str	w9, [x24]
1015c7f00: 39001308    	strb	w8, [x24, #0x4]
1015c7f04: 140000da    	b	0x1015c826c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x56f8>
1015c7f08: d000d1a8    	adrp	x8, 0x102ffd000 <_anon.70399bd8ea3438f11774e3396e76a872.10+0x30c2>
1015c7f0c: 3dc15d00    	ldr	q0, [x8, #0x570]
1015c7f10: 3c808300    	stur	q0, [x24, #0x8]
1015c7f14: 528000c8    	mov	w8, #0x6                ; =6
1015c7f18: b9000308    	str	w8, [x24]
1015c7f1c: 140000d4    	b	0x1015c826c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x56f8>
1015c7f20: b900031f    	str	wzr, [x24]
1015c7f24: 52800188    	mov	w8, #0xc                ; =12
1015c7f28: b000d389    	adrp	x9, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c7f2c: 9138e529    	add	x9, x9, #0xe39
1015c7f30: a900a708    	stp	x8, x9, [x24, #0x8]
1015c7f34: 52800388    	mov	w8, #0x1c               ; =28
1015c7f38: f9000f08    	str	x8, [x24, #0x18]
1015c7f3c: 17ffff8d    	b	0x1015c7d70 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x51fc>
1015c7f40: 911a83e0    	add	x0, sp, #0x6a0
1015c7f44: d2800001    	mov	x1, #0x0                ; =0
1015c7f48: 52800102    	mov	w2, #0x8                ; =8
1015c7f4c: aa1503e3    	mov	x3, x21
1015c7f50: 52800104    	mov	w4, #0x8                ; =8
1015c7f54: 52800105    	mov	w5, #0x8                ; =8
1015c7f58: 94601ac2    	bl	0x102dcea60 <__RNvMs4_NtCsgKscDXrlV49_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs29QkOtpKx6e_8mech_gpu>
1015c7f5c: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c7f60: 360004e8    	tbz	w8, #0x0, 0x1015c7ffc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5488>
1015c7f64: 9000d3a8    	adrp	x8, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c7f68: 91291d08    	add	x8, x8, #0xa47
1015c7f6c: 52800189    	mov	w9, #0xc                ; =12
1015c7f70: a900a309    	stp	x9, x8, [x24, #0x8]
1015c7f74: 528004e8    	mov	w8, #0x27               ; =39
1015c7f78: f9000f08    	str	x8, [x24, #0x18]
1015c7f7c: b900031f    	str	wzr, [x24]
1015c7f80: 140000c5    	b	0x1015c8294 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5720>
1015c7f84: f0012043    	adrp	x3, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c7f88: 91038063    	add	x3, x3, #0xe0
1015c7f8c: d2800000    	mov	x0, #0x0                ; =0
1015c7f90: aa1703e1    	mov	x1, x23
1015c7f94: aa0803e2    	mov	x2, x8
1015c7f98: 9460adff    	bl	0x102df3794 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015c7f9c: 1400011d    	b	0x1015c8410 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x589c>
1015c7fa0: f0012042    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c7fa4: 91014042    	add	x2, x2, #0x50
1015c7fa8: aa1503e0    	mov	x0, x21
1015c7fac: 9460ad8d    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c7fb0: f0012042    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c7fb4: 9100e042    	add	x2, x2, #0x38
1015c7fb8: aa1403e0    	mov	x0, x20
1015c7fbc: 9460ad89    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c7fc0: b900031f    	str	wzr, [x24]
1015c7fc4: b000d388    	adrp	x8, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c7fc8: 913a6108    	add	x8, x8, #0xe98
1015c7fcc: 52800189    	mov	w9, #0xc                ; =12
1015c7fd0: a900a309    	stp	x9, x8, [x24, #0x8]
1015c7fd4: 528004e8    	mov	w8, #0x27               ; =39
1015c7fd8: f9000f08    	str	x8, [x24, #0x18]
1015c7fdc: 140000a4    	b	0x1015c826c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x56f8>
1015c7fe0: f0012042    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c7fe4: 91056042    	add	x2, x2, #0x158
1015c7fe8: aa1503e0    	mov	x0, x21
1015c7fec: 9460ad7d    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c7ff0: f0012042    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c7ff4: 91002042    	add	x2, x2, #0x8
1015c7ff8: 9460ad7a    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c7ffc: f94357e9    	ldr	x9, [sp, #0x6a8]
1015c8000: f9442fe8    	ldr	x8, [sp, #0x858]
1015c8004: 17fffeee    	b	0x1015c7bbc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5048>
1015c8008: d0012043    	adrp	x3, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c800c: 9102c063    	add	x3, x3, #0xb0
1015c8010: d2800000    	mov	x0, #0x0                ; =0
1015c8014: aa1703e1    	mov	x1, x23
1015c8018: 9460addf    	bl	0x102df3794 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015c801c: 140000fd    	b	0x1015c8410 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x589c>
1015c8020: d0012048    	adrp	x8, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c8024: 9101a108    	add	x8, x8, #0x68
1015c8028: aa0203e0    	mov	x0, x2
1015c802c: aa0803e2    	mov	x2, x8
1015c8030: 9460ad6c    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c8034: 395a83e8    	ldrb	w8, [sp, #0x6a0]
1015c8038: b946a7e9    	ldr	w9, [sp, #0x6a4]
1015c803c: b8003329    	stur	w9, [x25, #0x3]
1015c8040: b8401349    	ldur	w9, [x26, #0x1]
1015c8044: b90333e9    	str	w9, [sp, #0x330]
1015c8048: 3dc1afe0    	ldr	q0, [sp, #0x6b0]
1015c804c: 3dc1b3e1    	ldr	q1, [sp, #0x6c0]
1015c8050: 3d8107e0    	str	q0, [sp, #0x410]
1015c8054: 3d810be1    	str	q1, [sp, #0x420]
1015c8058: f9436bea    	ldr	x10, [sp, #0x6d0]
1015c805c: f9436fe9    	ldr	x9, [sp, #0x6d8]
1015c8060: d10283ab    	sub	x11, x29, #0xa0
1015c8064: f9021bea    	str	x10, [sp, #0x430]
1015c8068: fd4357e0    	ldr	d0, [sp, #0x6a8]
1015c806c: b840332a    	ldur	w10, [x25, #0x3]
1015c8070: 9108c3ec    	add	x12, sp, #0x230
1015c8074: b800318a    	stur	w10, [x12, #0x3]
1015c8078: b94333ea    	ldr	w10, [sp, #0x330]
1015c807c: b90233ea    	str	w10, [sp, #0x230]
1015c8080: 3dc107e1    	ldr	q1, [sp, #0x410]
1015c8084: 3dc10be2    	ldr	q2, [sp, #0x420]
1015c8088: f9421bea    	ldr	x10, [sp, #0x430]
1015c808c: f9032bea    	str	x10, [sp, #0x650]
1015c8090: 3d8193e2    	str	q2, [sp, #0x640]
1015c8094: 3d818fe1    	str	q1, [sp, #0x630]
1015c8098: b94233ea    	ldr	w10, [sp, #0x230]
1015c809c: b840318c    	ldur	w12, [x12, #0x3]
1015c80a0: b90377ec    	str	w12, [sp, #0x374]
1015c80a4: b804132a    	stur	w10, [x25, #0x41]
1015c80a8: 3dc18fe1    	ldr	q1, [sp, #0x630]
1015c80ac: 3dc193e2    	ldr	q2, [sp, #0x640]
1015c80b0: f9432bea    	ldr	x10, [sp, #0x650]
1015c80b4: ad1c0be1    	stp	q1, q2, [sp, #0x380]
1015c80b8: 390dc3e8    	strb	w8, [sp, #0x370]
1015c80bc: fd01bfe0    	str	d0, [sp, #0x378]
1015c80c0: f901d3ea    	str	x10, [sp, #0x3a0]
1015c80c4: f901d7e9    	str	x9, [sp, #0x3a8]
1015c80c8: 3dc13a60    	ldr	q0, [x19, #0x4e0]
1015c80cc: 3c8a8340    	stur	q0, [x26, #0xa8]
1015c80d0: f9427a69    	ldr	x9, [x19, #0x4f0]
1015c80d4: ad440660    	ldp	q0, q1, [x19, #0x80]
1015c80d8: 3d81cbe0    	str	q0, [sp, #0x720]
1015c80dc: 3d81cfe1    	str	q1, [sp, #0x730]
1015c80e0: f940526a    	ldr	x10, [x19, #0xa0]
1015c80e4: f903afe9    	str	x9, [sp, #0x758]
1015c80e8: f903a3ea    	str	x10, [sp, #0x740]
1015c80ec: ad420660    	ldp	q0, q1, [x19, #0x40]
1015c80f0: 3d81bbe0    	str	q0, [sp, #0x6e0]
1015c80f4: 3d81bfe1    	str	q1, [sp, #0x6f0]
1015c80f8: ad430261    	ldp	q1, q0, [x19, #0x60]
1015c80fc: 3d81c7e0    	str	q0, [sp, #0x710]
1015c8100: 3d81c3e1    	str	q1, [sp, #0x700]
1015c8104: ad400660    	ldp	q0, q1, [x19]
1015c8108: 3d81abe0    	str	q0, [sp, #0x6a0]
1015c810c: 3d81afe1    	str	q1, [sp, #0x6b0]
1015c8110: ad410261    	ldp	q1, q0, [x19, #0x20]
1015c8114: 3d81b7e0    	str	q0, [sp, #0x6d0]
1015c8118: 3d81b3e1    	str	q1, [sp, #0x6c0]
1015c811c: f9401fe8    	ldr	x8, [sp, #0x38]
1015c8120: a935ffa8    	stp	x8, xzr, [x29, #-0xa8]
1015c8124: f81683bf    	stur	xzr, [x29, #-0x98]
1015c8128: d10403a8    	sub	x8, x29, #0x100
1015c812c: 912123e9    	add	x9, sp, #0x848
1015c8130: f9020be8    	str	x8, [sp, #0x410]
1015c8134: f9020fe9    	str	x9, [sp, #0x418]
1015c8138: 910dc3e8    	add	x8, sp, #0x370
1015c813c: 911fa3e9    	add	x9, sp, #0x7e8
1015c8140: f90213e8    	str	x8, [sp, #0x420]
1015c8144: f90217e9    	str	x9, [sp, #0x428]
1015c8148: d10303a8    	sub	x8, x29, #0xc0
1015c814c: f9021feb    	str	x11, [sp, #0x438]
1015c8150: 911f83e9    	add	x9, sp, #0x7e0
1015c8154: f9021be8    	str	x8, [sp, #0x430]
1015c8158: f90223e9    	str	x9, [sp, #0x440]
1015c815c: d102a3a8    	sub	x8, x29, #0xa8
1015c8160: 911a83e9    	add	x9, sp, #0x6a0
1015c8164: f90227e8    	str	x8, [sp, #0x448]
1015c8168: f9022be9    	str	x9, [sp, #0x450]
1015c816c: d0012041    	adrp	x1, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c8170: 9108c021    	add	x1, x1, #0x230
1015c8174: 911703e8    	add	x8, sp, #0x5c0
1015c8178: 911043e0    	add	x0, sp, #0x410
1015c817c: 940060a9    	bl	0x1015e0420 <__RINvNtNtCsgirOGyZpP7g_3std6thread6scoped5scopeNCNvMs0_NtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallelNtBS_10Invocation12run_parallelsc_0INtNtCsgDHHaSskbIF_4core6result6ResultINtNtCsgKscDXrlV49_5alloc3vec3VecIB2P_NtBQ_7ReceiptNtBU_27NativeProgramExecutionErrorEEB4f_EEB10_>
1015c8180: ad5b87e0    	ldp	q0, q1, [sp, #0x370]
1015c8184: 3d8107e0    	str	q0, [sp, #0x410]
1015c8188: 3d810be1    	str	q1, [sp, #0x420]
1015c818c: ad5c87e0    	ldp	q0, q1, [sp, #0x390]
1015c8190: 3d810fe0    	str	q0, [sp, #0x430]
1015c8194: 3d8113e1    	str	q1, [sp, #0x440]
1015c8198: 9118c3e8    	add	x8, sp, #0x630
1015c819c: 911043e0    	add	x0, sp, #0x410
1015c81a0: 94355638    	bl	0x10231da80 <__RNvMs4_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workersNtB5_15NativeWorkGroup29finish_with_credit_statistics>
1015c81a4: b94633e8    	ldr	w8, [sp, #0x630]
1015c81a8: 360007c8    	tbz	w8, #0x0, 0x1015c82a0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x572c>
1015c81ac: f94327e8    	ldr	x8, [sp, #0x648]
1015c81b0: 3dc197e0    	ldr	q0, [sp, #0x650]
1015c81b4: 3d800f00    	str	q0, [x24, #0x30]
1015c81b8: b85403ab    	ldur	w11, [x29, #-0xc0]
1015c81bc: 9118c3e9    	add	x9, sp, #0x630
1015c81c0: 3cc08120    	ldur	q0, [x9, #0x8]
1015c81c4: 52800089    	mov	w9, #0x4                ; =4
1015c81c8: 29002f09    	stp	w9, w11, [x24]
1015c81cc: d10303a9    	sub	x9, x29, #0xc0
1015c81d0: 3cc04121    	ldur	q1, [x9, #0x4]
1015c81d4: 3c808301    	stur	q1, [x24, #0x8]
1015c81d8: 3c818300    	stur	q0, [x24, #0x18]
1015c81dc: 52800509    	mov	w9, #0x28               ; =40
1015c81e0: 140000a0    	b	0x1015c8460 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58ec>
1015c81e4: 5280000a    	mov	w10, #0x0               ; =0
1015c81e8: fd4353e0    	ldr	d0, [sp, #0x6a0]
1015c81ec: 528001a8    	mov	w8, #0xd                ; =13
1015c81f0: 911483eb    	add	x11, sp, #0x520
1015c81f4: b84a316b    	ldur	w11, [x11, #0xa3]
1015c81f8: b800332b    	stur	w11, [x25, #0x3]
1015c81fc: b945c3eb    	ldr	w11, [sp, #0x5c0]
1015c8200: b90333eb    	str	w11, [sp, #0x330]
1015c8204: 3cc08281    	ldur	q1, [x20, #0x8]
1015c8208: 3cc18282    	ldur	q2, [x20, #0x18]
1015c820c: 3d8107e1    	str	q1, [sp, #0x410]
1015c8210: 3d810be2    	str	q2, [sp, #0x420]
1015c8214: f842828b    	ldur	x11, [x20, #0x28]
1015c8218: f9021beb    	str	x11, [sp, #0x430]
1015c821c: b840332c    	ldur	w12, [x25, #0x3]
1015c8220: 9108c3ed    	add	x13, sp, #0x230
1015c8224: b80031ac    	stur	w12, [x13, #0x3]
1015c8228: b94333ec    	ldr	w12, [sp, #0x330]
1015c822c: b90233ec    	str	w12, [sp, #0x230]
1015c8230: f9032beb    	str	x11, [sp, #0x650]
1015c8234: 3d8193e2    	str	q2, [sp, #0x640]
1015c8238: 3d818fe1    	str	q1, [sp, #0x630]
1015c823c: b800930c    	stur	w12, [x24, #0x9]
1015c8240: b84031ab    	ldur	w11, [x13, #0x3]
1015c8244: b9000f0b    	str	w11, [x24, #0xc]
1015c8248: 3dc18fe1    	ldr	q1, [sp, #0x630]
1015c824c: 3dc193e2    	ldr	q2, [sp, #0x640]
1015c8250: 3c818301    	stur	q1, [x24, #0x18]
1015c8254: 3c828302    	stur	q2, [x24, #0x28]
1015c8258: f9432beb    	ldr	x11, [sp, #0x650]
1015c825c: f9001f0b    	str	x11, [x24, #0x38]
1015c8260: 2900270a    	stp	w10, w9, [x24]
1015c8264: 39002308    	strb	w8, [x24, #0x8]
1015c8268: fd000b00    	str	d0, [x24, #0x10]
1015c826c: 5280003b    	mov	w27, #0x1               ; =1
1015c8270: 911ea3e0    	add	x0, sp, #0x7a8
1015c8274: 97ff7acb    	bl	0x1015a6da0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs29QkOtpKx6e_8mech_gpu>
1015c8278: f85083a8    	ldur	x8, [x29, #-0xf8]
1015c827c: b40000a8    	cbz	x8, 0x1015c8290 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x571c>
1015c8280: f85103a0    	ldur	x0, [x29, #-0xf0]
1015c8284: d37df101    	lsl	x1, x8, #3
1015c8288: 52800102    	mov	w2, #0x8                ; =8
1015c828c: 97a904ac    	bl	0x10000953c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1015c8290: 36072777    	tbz	w23, #0x0, 0x1015c677c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c08>
1015c8294: 910f83e0    	add	x0, sp, #0x3e0
1015c8298: 97ff7ae0    	bl	0x1015a6e18 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs29QkOtpKx6e_8mech_gpu>
1015c829c: 17fff938    	b	0x1015c677c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c08>
1015c82a0: f94327e8    	ldr	x8, [sp, #0x648]
1015c82a4: f9420f89    	ldr	x9, [x28, #0x418]
1015c82a8: ab080129    	adds	x9, x9, x8
1015c82ac: 54000b42    	b.hs	0x1015c8414 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58a0>
1015c82b0: f9432bea    	ldr	x10, [sp, #0x650]
1015c82b4: f9432fe8    	ldr	x8, [sp, #0x658]
1015c82b8: f9020f89    	str	x9, [x28, #0x418]
1015c82bc: f9421389    	ldr	x9, [x28, #0x420]
1015c82c0: ab0a0129    	adds	x9, x9, x10
1015c82c4: 54000b22    	b.hs	0x1015c8428 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58b4>
1015c82c8: f9021389    	str	x9, [x28, #0x420]
1015c82cc: f9421789    	ldr	x9, [x28, #0x428]
1015c82d0: ab080128    	adds	x8, x9, x8
1015c82d4: 54000b82    	b.hs	0x1015c8444 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58d0>
1015c82d8: f9021788    	str	x8, [x28, #0x428]
1015c82dc: ad5f07e0    	ldp	q0, q1, [sp, #0x3e0]
1015c82e0: 3d8107e0    	str	q0, [sp, #0x410]
1015c82e4: 3d810be1    	str	q1, [sp, #0x420]
1015c82e8: 52800017    	mov	w23, #0x0               ; =0
1015c82ec: 911043e0    	add	x0, sp, #0x410
1015c82f0: 97ff7aca    	bl	0x1015a6e18 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs29QkOtpKx6e_8mech_gpu>
1015c82f4: b945c3e8    	ldr	w8, [sp, #0x5c0]
1015c82f8: 7100191f    	cmp	w8, #0x6
1015c82fc: 54000ba1    	b.ne	0x1015c8470 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58fc>
1015c8300: d2800009    	mov	x9, #0x0                ; =0
1015c8304: 911483e8    	add	x8, sp, #0x520
1015c8308: 3cca8100    	ldur	q0, [x8, #0xa8]
1015c830c: 3c9703a0    	stur	q0, [x29, #-0x90]
1015c8310: f942efe8    	ldr	x8, [sp, #0x5d8]
1015c8314: f81803a8    	stur	x8, [x29, #-0x80]
1015c8318: f85783b5    	ldur	x21, [x29, #-0x88]
1015c831c: 5280190a    	mov	w10, #0xc8              ; =200
1015c8320: 9b0a7d0a    	mul	x10, x8, x10
1015c8324: 8b0a02b6    	add	x22, x21, x10
1015c8328: eb09015f    	cmp	x10, x9
1015c832c: 54000ba0    	b.eq	0x1015c84a0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x592c>
1015c8330: f8696aab    	ldr	x11, [x21, x9]
1015c8334: 91032129    	add	x9, x9, #0xc8
1015c8338: b4ffff8b    	cbz	x11, 0x1015c8328 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x57b4>
1015c833c: 1400006d    	b	0x1015c84f0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x597c>
1015c8340: d0012042    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c8344: 9105c042    	add	x2, x2, #0x170
1015c8348: aa1503e0    	mov	x0, x21
1015c834c: 9460aca5    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c8350: 14000030    	b	0x1015c8410 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x589c>
1015c8354: d0012042    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c8358: 91062042    	add	x2, x2, #0x188
1015c835c: aa1603e0    	mov	x0, x22
1015c8360: 9460aca0    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c8364: 1400002b    	b	0x1015c8410 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x589c>
1015c8368: d0012042    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c836c: 9103e042    	add	x2, x2, #0xf8
1015c8370: aa0103e0    	mov	x0, x1
1015c8374: aa0803e1    	mov	x1, x8
1015c8378: 9460ac9a    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c837c: d0012042    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c8380: 91044042    	add	x2, x2, #0x110
1015c8384: f9401fe0    	ldr	x0, [sp, #0x38]
1015c8388: aa1703e1    	mov	x1, x23
1015c838c: 9460ac95    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c8390: d0012042    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c8394: 9104a042    	add	x2, x2, #0x128
1015c8398: f9401fe0    	ldr	x0, [sp, #0x38]
1015c839c: aa1703e1    	mov	x1, x23
1015c83a0: 9460ac90    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c83a4: d0012042    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c83a8: 91050042    	add	x2, x2, #0x140
1015c83ac: f9401fe0    	ldr	x0, [sp, #0x38]
1015c83b0: 9460ac8c    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c83b4: 14000017    	b	0x1015c8410 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x589c>
1015c83b8: d0012042    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c83bc: 91026042    	add	x2, x2, #0x98
1015c83c0: aa1503e0    	mov	x0, x21
1015c83c4: 9460ac87    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c83c8: d0012042    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c83cc: 91032042    	add	x2, x2, #0xc8
1015c83d0: aa1603e0    	mov	x0, x22
1015c83d4: 9460ac83    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c83d8: 1400000e    	b	0x1015c8410 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x589c>
1015c83dc: d0012042    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c83e0: 9107a042    	add	x2, x2, #0x1e8
1015c83e4: f9401be0    	ldr	x0, [sp, #0x30]
1015c83e8: 9460ac7e    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c83ec: 14000009    	b	0x1015c8410 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x589c>
1015c83f0: d0012042    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c83f4: 91080042    	add	x2, x2, #0x200
1015c83f8: f94017e0    	ldr	x0, [sp, #0x28]
1015c83fc: 9460ac79    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c8400: 14000004    	b	0x1015c8410 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x589c>
1015c8404: d0012042    	adrp	x2, 0x1039d2000 <_anon.19b44b453da724831023c27de6e0b6f2.687+0x178>
1015c8408: 91086042    	add	x2, x2, #0x218
1015c840c: 9460ac75    	bl	0x102df35e0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c8410: d4200020    	brk	#0x1
1015c8414: b900031f    	str	wzr, [x24]
1015c8418: 52800189    	mov	w9, #0xc                ; =12
1015c841c: 9000d38a    	adrp	x10, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c8420: 913afd4a    	add	x10, x10, #0xebf
1015c8424: 14000005    	b	0x1015c8438 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58c4>
1015c8428: b900031f    	str	wzr, [x24]
1015c842c: 52800189    	mov	w9, #0xc                ; =12
1015c8430: 9000d38a    	adrp	x10, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c8434: 913ba14a    	add	x10, x10, #0xee8
1015c8438: a900ab09    	stp	x9, x10, [x24, #0x8]
1015c843c: 52800528    	mov	w8, #0x29               ; =41
1015c8440: 14000007    	b	0x1015c845c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58e8>
1015c8444: b900031f    	str	wzr, [x24]
1015c8448: 52800189    	mov	w9, #0xc                ; =12
1015c844c: 9000d38a    	adrp	x10, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c8450: 913c454a    	add	x10, x10, #0xf11
1015c8454: a900ab09    	stp	x9, x10, [x24, #0x8]
1015c8458: 52800568    	mov	w8, #0x2b               ; =43
1015c845c: 52800309    	mov	w9, #0x18               ; =24
1015c8460: f8296b08    	str	x8, [x24, x9]
1015c8464: 911703e0    	add	x0, sp, #0x5c0
1015c8468: 97ff7318    	bl	0x1015a50c8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultINtNtCsgKscDXrlV49_5alloc3vec3VecIBH_NtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1J_27NativeProgramExecutionErrorEEB3c_EEB1P_>
1015c846c: 17ffff80    	b	0x1015c826c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x56f8>
1015c8470: 3dc17fe0    	ldr	q0, [sp, #0x5f0]
1015c8474: 3dc183e1    	ldr	q1, [sp, #0x600]
1015c8478: ad018700    	stp	q0, q1, [x24, #0x30]
1015c847c: 911483e9    	add	x9, sp, #0x520
1015c8480: 3cca4120    	ldur	q0, [x9, #0xa4]
1015c8484: 3c804300    	stur	q0, [x24, #0x4]
1015c8488: 3dc17be0    	ldr	q0, [sp, #0x5e0]
1015c848c: 3dc177e1    	ldr	q1, [sp, #0x5d0]
1015c8490: ad008301    	stp	q1, q0, [x24, #0x10]
1015c8494: b9000308    	str	w8, [x24]
1015c8498: 52800017    	mov	w23, #0x0               ; =0
1015c849c: 17ffff74    	b	0x1015c826c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x56f8>
1015c84a0: f9422389    	ldr	x9, [x28, #0x440]
1015c84a4: b100053f    	cmn	x9, #0x1
1015c84a8: 54001060    	b.eq	0x1015c86b4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5b40>
1015c84ac: 91000529    	add	x9, x9, #0x1
1015c84b0: f9022389    	str	x9, [x28, #0x440]
1015c84b4: f9421f89    	ldr	x9, [x28, #0x438]
1015c84b8: f9442fea    	ldr	x10, [sp, #0x858]
1015c84bc: ab090149    	adds	x9, x10, x9
1015c84c0: 54000fa2    	b.hs	0x1015c86b4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5b40>
1015c84c4: f9021f89    	str	x9, [x28, #0x438]
1015c84c8: f9422789    	ldr	x9, [x28, #0x448]
1015c84cc: f9400fea    	ldr	x10, [sp, #0x18]
1015c84d0: ab0a0129    	adds	x9, x9, x10
1015c84d4: 54000f82    	b.hs	0x1015c86c4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5b50>
1015c84d8: f9022789    	str	x9, [x28, #0x448]
1015c84dc: f9422b89    	ldr	x9, [x28, #0x450]
1015c84e0: f85683aa    	ldur	x10, [x29, #-0x98]
1015c84e4: eb09015f    	cmp	x10, x9
1015c84e8: 9a898149    	csel	x9, x10, x9, hi
1015c84ec: f9022b89    	str	x9, [x28, #0x450]
1015c84f0: 52801909    	mov	w9, #0xc8               ; =200
1015c84f4: 9b097d0a    	mul	x10, x8, x9
1015c84f8: 910182ab    	add	x11, x21, #0x60
1015c84fc: 9000d388    	adrp	x8, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c8500: 913d6508    	add	x8, x8, #0xf59
1015c8504: 528002e9    	mov	w9, #0x17               ; =23
1015c8508: 9000d38c    	adrp	x12, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c850c: 913dc18c    	add	x12, x12, #0xf70
1015c8510: 9000d38d    	adrp	x13, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c8514: 913e21ad    	add	x13, x13, #0xf88
1015c8518: 9000d38e    	adrp	x14, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c851c: 913e81ce    	add	x14, x14, #0xfa0
1015c8520: 9000d38f    	adrp	x15, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c8524: 913efdef    	add	x15, x15, #0xfbf
1015c8528: 9000d390    	adrp	x16, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c852c: 913f9610    	add	x16, x16, #0xfe5
1015c8530: b000d391    	adrp	x17, 0x103039000 <_anon.19b44b453da724831023c27de6e0b6f2.100+0xf48>
1015c8534: 91001231    	add	x17, x17, #0x4
1015c8538: b000d381    	adrp	x1, 0x103039000 <_anon.19b44b453da724831023c27de6e0b6f2.100+0xf48>
1015c853c: 91008021    	add	x1, x1, #0x20
1015c8540: b000d382    	adrp	x2, 0x103039000 <_anon.19b44b453da724831023c27de6e0b6f2.100+0xf48>
1015c8544: 91011042    	add	x2, x2, #0x44
1015c8548: b000d383    	adrp	x3, 0x103039000 <_anon.19b44b453da724831023c27de6e0b6f2.100+0xf48>
1015c854c: 9101a063    	add	x3, x3, #0x68
1015c8550: b000d384    	adrp	x4, 0x103039000 <_anon.19b44b453da724831023c27de6e0b6f2.100+0xf48>
1015c8554: 91021c84    	add	x4, x4, #0x87
1015c8558: b000d380    	adrp	x0, 0x103039000 <_anon.19b44b453da724831023c27de6e0b6f2.100+0xf48>
1015c855c: 91029000    	add	x0, x0, #0xa4
1015c8560: b000d385    	adrp	x5, 0x103039000 <_anon.19b44b453da724831023c27de6e0b6f2.100+0xf48>
1015c8564: 910330a5    	add	x5, x5, #0xcc
1015c8568: 14000003    	b	0x1015c8574 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5a00>
1015c856c: d103214a    	sub	x10, x10, #0xc8
1015c8570: 9103216b    	add	x11, x11, #0xc8
1015c8574: b4000b0a    	cbz	x10, 0x1015c86d4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5b60>
1015c8578: f85a0166    	ldur	x6, [x11, #-0x60]
1015c857c: f10004df    	cmp	x6, #0x1
1015c8580: 54ffff60    	b.eq	0x1015c856c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x59f8>
1015c8584: f9419b86    	ldr	x6, [x28, #0x330]
1015c8588: f85e8167    	ldur	x7, [x11, #-0x18]
1015c858c: ab0600e6    	adds	x6, x7, x6
1015c8590: 54001ca2    	b.hs	0x1015c8924 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5db0>
1015c8594: f9019b86    	str	x6, [x28, #0x330]
1015c8598: f941e786    	ldr	x6, [x28, #0x3c8]
1015c859c: f85f0167    	ldur	x7, [x11, #-0x10]
1015c85a0: ab0600e6    	adds	x6, x7, x6
1015c85a4: 540017a2    	b.hs	0x1015c8898 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5d24>
1015c85a8: f901e786    	str	x6, [x28, #0x3c8]
1015c85ac: f941eb86    	ldr	x6, [x28, #0x3d0]
1015c85b0: f85f8167    	ldur	x7, [x11, #-0x8]
1015c85b4: ab0600e6    	adds	x6, x7, x6
1015c85b8: 54001762    	b.hs	0x1015c88a4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5d30>
1015c85bc: f901eb86    	str	x6, [x28, #0x3d0]
1015c85c0: f941ef86    	ldr	x6, [x28, #0x3d8]
1015c85c4: f9400167    	ldr	x7, [x11]
1015c85c8: ab0600e6    	adds	x6, x7, x6
1015c85cc: 54001722    	b.hs	0x1015c88b0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5d3c>
1015c85d0: f901ef86    	str	x6, [x28, #0x3d8]
1015c85d4: f941f386    	ldr	x6, [x28, #0x3e0]
1015c85d8: f9400567    	ldr	x7, [x11, #0x8]
1015c85dc: ab0600e6    	adds	x6, x7, x6
1015c85e0: 540016e2    	b.hs	0x1015c88bc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5d48>
1015c85e4: f901f386    	str	x6, [x28, #0x3e0]
1015c85e8: f941f786    	ldr	x6, [x28, #0x3e8]
1015c85ec: f9400967    	ldr	x7, [x11, #0x10]
1015c85f0: ab0600e6    	adds	x6, x7, x6
1015c85f4: 540016a2    	b.hs	0x1015c88c8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5d54>
1015c85f8: f901f786    	str	x6, [x28, #0x3e8]
1015c85fc: f941fb86    	ldr	x6, [x28, #0x3f0]
1015c8600: f9400d67    	ldr	x7, [x11, #0x18]
1015c8604: ab0600e6    	adds	x6, x7, x6
1015c8608: 54001662    	b.hs	0x1015c88d4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5d60>
1015c860c: f901fb86    	str	x6, [x28, #0x3f0]
1015c8610: f941ff86    	ldr	x6, [x28, #0x3f8]
1015c8614: f9401167    	ldr	x7, [x11, #0x20]
1015c8618: ab0600e6    	adds	x6, x7, x6
1015c861c: 54001622    	b.hs	0x1015c88e0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5d6c>
1015c8620: f901ff86    	str	x6, [x28, #0x3f8]
1015c8624: f9420386    	ldr	x6, [x28, #0x400]
1015c8628: f9401567    	ldr	x7, [x11, #0x28]
1015c862c: ab0600e6    	adds	x6, x7, x6
1015c8630: 540015e2    	b.hs	0x1015c88ec <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5d78>
1015c8634: f9020386    	str	x6, [x28, #0x400]
1015c8638: f9420786    	ldr	x6, [x28, #0x408]
1015c863c: f9401967    	ldr	x7, [x11, #0x30]
1015c8640: ab0600e6    	adds	x6, x7, x6
1015c8644: 540015a2    	b.hs	0x1015c88f8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5d84>
1015c8648: f9020786    	str	x6, [x28, #0x408]
1015c864c: f9420b86    	ldr	x6, [x28, #0x410]
1015c8650: f9401d67    	ldr	x7, [x11, #0x38]
1015c8654: ab0600e6    	adds	x6, x7, x6
1015c8658: 54001562    	b.hs	0x1015c8904 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5d90>
1015c865c: f9020b86    	str	x6, [x28, #0x410]
1015c8660: f9420f86    	ldr	x6, [x28, #0x418]
1015c8664: f9402167    	ldr	x7, [x11, #0x40]
1015c8668: ab0600e6    	adds	x6, x7, x6
1015c866c: 54001522    	b.hs	0x1015c8910 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5d9c>
1015c8670: f9020f86    	str	x6, [x28, #0x418]
1015c8674: f9421386    	ldr	x6, [x28, #0x420]
1015c8678: f9402567    	ldr	x7, [x11, #0x48]
1015c867c: ab0600e6    	adds	x6, x7, x6
1015c8680: 54001482    	b.hs	0x1015c8910 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5d9c>
1015c8684: f9021386    	str	x6, [x28, #0x420]
1015c8688: f9421786    	ldr	x6, [x28, #0x428]
1015c868c: f9402967    	ldr	x7, [x11, #0x50]
1015c8690: ab0600e6    	adds	x6, x7, x6
1015c8694: 540013e2    	b.hs	0x1015c8910 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5d9c>
1015c8698: f9021786    	str	x6, [x28, #0x428]
1015c869c: f9421b86    	ldr	x6, [x28, #0x430]
1015c86a0: f9402d67    	ldr	x7, [x11, #0x58]
1015c86a4: ab0600e6    	adds	x6, x7, x6
1015c86a8: 540013a2    	b.hs	0x1015c891c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5da8>
1015c86ac: f9021b86    	str	x6, [x28, #0x430]
1015c86b0: 17ffffaf    	b	0x1015c856c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x59f8>
1015c86b4: 9000d388    	adrp	x8, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c86b8: 913cf108    	add	x8, x8, #0xf3c
1015c86bc: 528003a9    	mov	w9, #0x1d               ; =29
1015c86c0: 14000099    	b	0x1015c8924 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5db0>
1015c86c4: 9000d388    	adrp	x8, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c86c8: 9138e508    	add	x8, x8, #0xe39
1015c86cc: 52800389    	mov	w9, #0x1c               ; =28
1015c86d0: 14000095    	b	0x1015c8924 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5db0>
1015c86d4: f90127ff    	str	xzr, [sp, #0x248]
1015c86d8: f90123ff    	str	xzr, [sp, #0x240]
1015c86dc: 52800108    	mov	w8, #0x8                ; =8
1015c86e0: f9011bff    	str	xzr, [sp, #0x230]
1015c86e4: f9011fe8    	str	x8, [sp, #0x238]
1015c86e8: f9442fe1    	ldr	x1, [sp, #0x858]
1015c86ec: 9108c3e0    	add	x0, sp, #0x230
1015c86f0: 940012ba    	bl	0x1015cd1d8 <__RNvMs3_NtNtCsgKscDXrlV49_5alloc11collections9vec_dequeINtB5_8VecDequeNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionE17try_reserve_exactB1h_>
1015c86f4: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
1015c86f8: eb08001f    	cmp	x0, x8
1015c86fc: 540011e1    	b.ne	0x1015c8938 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5dc4>
1015c8700: f9411be8    	ldr	x8, [sp, #0x230]
1015c8704: f9442fe9    	ldr	x9, [sp, #0x858]
1015c8708: eb09011f    	cmp	x8, x9
1015c870c: 540011e1    	b.ne	0x1015c8948 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5dd4>
1015c8710: f9442be9    	ldr	x9, [sp, #0x850]
1015c8714: f94427ea    	ldr	x10, [sp, #0x848]
1015c8718: 52800d0b    	mov	w11, #0x68              ; =104
1015c871c: 9b0b2514    	madd	x20, x8, x11, x9
1015c8720: f9019be9    	str	x9, [sp, #0x330]
1015c8724: f9019fe9    	str	x9, [sp, #0x338]
1015c8728: f901a3ea    	str	x10, [sp, #0x340]
1015c872c: f901a7f4    	str	x20, [sp, #0x348]
1015c8730: b40005a8    	cbz	x8, 0x1015c87e4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5c70>
1015c8734: 911043f9    	add	x25, sp, #0x410
1015c8738: 9101a137    	add	x23, x9, #0x68
1015c873c: d2f0001a    	mov	x26, #-0x8000000000000000 ; =-9223372036854775808
1015c8740: aa1703fb    	mov	x27, x23
1015c8744: f8598f68    	ldr	x8, [x27, #-0x68]!
1015c8748: eb1a011f    	cmp	x8, x26
1015c874c: 540004a0    	b.eq	0x1015c87e0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5c6c>
1015c8750: f9020be8    	str	x8, [sp, #0x410]
1015c8754: 3cc58360    	ldur	q0, [x27, #0x58]
1015c8758: 3c858320    	stur	q0, [x25, #0x58]
1015c875c: 3cc28360    	ldur	q0, [x27, #0x28]
1015c8760: 3c828320    	stur	q0, [x25, #0x28]
1015c8764: 3cc38360    	ldur	q0, [x27, #0x38]
1015c8768: 3c838320    	stur	q0, [x25, #0x38]
1015c876c: 3cc48360    	ldur	q0, [x27, #0x48]
1015c8770: 3c848320    	stur	q0, [x25, #0x48]
1015c8774: 3cc08360    	ldur	q0, [x27, #0x8]
1015c8778: 3c808320    	stur	q0, [x25, #0x8]
1015c877c: 3cc18360    	ldur	q0, [x27, #0x18]
1015c8780: 3c818320    	stur	q0, [x25, #0x18]
1015c8784: f94237e8    	ldr	x8, [sp, #0x468]
1015c8788: f9423be9    	ldr	x9, [sp, #0x470]
1015c878c: 3cc18360    	ldur	q0, [x27, #0x18]
1015c8790: 3d818fe0    	str	q0, [sp, #0x630]
1015c8794: 3cc28360    	ldur	q0, [x27, #0x28]
1015c8798: 3d8193e0    	str	q0, [sp, #0x640]
1015c879c: 3cc38360    	ldur	q0, [x27, #0x38]
1015c87a0: 3d8197e0    	str	q0, [sp, #0x650]
1015c87a4: 3cc48360    	ldur	q0, [x27, #0x48]
1015c87a8: 3d819be0    	str	q0, [sp, #0x660]
1015c87ac: f9033be8    	str	x8, [sp, #0x670]
1015c87b0: f9033fff    	str	xzr, [sp, #0x678]
1015c87b4: f90343e9    	str	x9, [sp, #0x680]
1015c87b8: 9108c3e0    	add	x0, sp, #0x230
1015c87bc: 9118c3e1    	add	x1, sp, #0x630
1015c87c0: 9400125f    	bl	0x1015cd13c <__RNvMs3_NtNtCsgKscDXrlV49_5alloc11collections9vec_dequeINtB5_8VecDequeNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionE13push_back_mutB1h_>
1015c87c4: 911043e0    	add	x0, sp, #0x410
1015c87c8: 97ff7542    	bl	0x1015a5cd0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
1015c87cc: 91034377    	add	x23, x27, #0xd0
1015c87d0: 9101a368    	add	x8, x27, #0x68
1015c87d4: eb14011f    	cmp	x8, x20
1015c87d8: 54fffb41    	b.ne	0x1015c8740 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5bcc>
1015c87dc: aa1403f7    	mov	x23, x20
1015c87e0: f9019ff7    	str	x23, [sp, #0x338]
1015c87e4: 910cc3e0    	add	x0, sp, #0x330
1015c87e8: 94004c98    	bl	0x1015dba48 <__RNvXse_NtNtCsgKscDXrlV49_5alloc3vec9into_iterINtB5_8IntoIterNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropB18_>
1015c87ec: ad5187e0    	ldp	q0, q1, [sp, #0x230]
1015c87f0: 3d8107e0    	str	q0, [sp, #0x410]
1015c87f4: 3d810be1    	str	q1, [sp, #0x420]
1015c87f8: f85703b9    	ldur	x25, [x29, #-0x90]
1015c87fc: 3dc203e0    	ldr	q0, [sp, #0x800]
1015c8800: 3dc207e1    	ldr	q1, [sp, #0x810]
1015c8804: 3d818fe0    	str	q0, [sp, #0x630]
1015c8808: 3d8193e1    	str	q1, [sp, #0x640]
1015c880c: 3dc20be0    	ldr	q0, [sp, #0x820]
1015c8810: 3dc20fe1    	ldr	q1, [sp, #0x830]
1015c8814: ad1987e0    	stp	q0, q1, [sp, #0x330]
1015c8818: 910f0260    	add	x0, x19, #0x3c0
1015c881c: 97ff716e    	bl	0x1015a4dd4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel5BatchEEB1e_>
1015c8820: 3dc107e0    	ldr	q0, [sp, #0x410]
1015c8824: 3dc10be1    	ldr	q1, [sp, #0x420]
1015c8828: ad1e0660    	stp	q0, q1, [x19, #0x3c0]
1015c882c: 3dc18fe0    	ldr	q0, [sp, #0x630]
1015c8830: 3dc193e1    	ldr	q1, [sp, #0x640]
1015c8834: 3d810260    	str	q0, [x19, #0x400]
1015c8838: 3d810661    	str	q1, [x19, #0x410]
1015c883c: ad5987e0    	ldp	q0, q1, [sp, #0x330]
1015c8840: 3d810a60    	str	q0, [x19, #0x420]
1015c8844: f901f275    	str	x21, [x19, #0x3e0]
1015c8848: f901f675    	str	x21, [x19, #0x3e8]
1015c884c: f901fa79    	str	x25, [x19, #0x3f0]
1015c8850: f901fe76    	str	x22, [x19, #0x3f8]
1015c8854: 3d810e61    	str	q1, [x19, #0x430]
1015c8858: 52800028    	mov	w8, #0x1                ; =1
1015c885c: 4e080d00    	dup.2d	v0, x8
1015c8860: 3c808300    	stur	q0, [x24, #0x8]
1015c8864: 528000c8    	mov	w8, #0x6                ; =6
1015c8868: b9000308    	str	w8, [x24]
1015c886c: 52800017    	mov	w23, #0x0               ; =0
1015c8870: 5280001b    	mov	w27, #0x0               ; =0
1015c8874: 911ea3e0    	add	x0, sp, #0x7a8
1015c8878: 97ff794a    	bl	0x1015a6da0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs29QkOtpKx6e_8mech_gpu>
1015c887c: f85083a8    	ldur	x8, [x29, #-0xf8]
1015c8880: b4ff2048    	cbz	x8, 0x1015c6c88 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4114>
1015c8884: f85103a0    	ldur	x0, [x29, #-0xf0]
1015c8888: d37df101    	lsl	x1, x8, #3
1015c888c: 52800102    	mov	w2, #0x8                ; =8
1015c8890: 97a9032b    	bl	0x10000953c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1015c8894: 17fff8fd    	b	0x1015c6c88 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4114>
1015c8898: aa0c03e8    	mov	x8, x12
1015c889c: 52800309    	mov	w9, #0x18               ; =24
1015c88a0: 14000021    	b	0x1015c8924 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5db0>
1015c88a4: aa0d03e8    	mov	x8, x13
1015c88a8: 52800309    	mov	w9, #0x18               ; =24
1015c88ac: 1400001e    	b	0x1015c8924 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5db0>
1015c88b0: aa0e03e8    	mov	x8, x14
1015c88b4: 528003e9    	mov	w9, #0x1f               ; =31
1015c88b8: 1400001b    	b	0x1015c8924 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5db0>
1015c88bc: aa0f03e8    	mov	x8, x15
1015c88c0: 528004c9    	mov	w9, #0x26               ; =38
1015c88c4: 14000018    	b	0x1015c8924 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5db0>
1015c88c8: aa1003e8    	mov	x8, x16
1015c88cc: 528003e9    	mov	w9, #0x1f               ; =31
1015c88d0: 14000015    	b	0x1015c8924 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5db0>
1015c88d4: aa1103e8    	mov	x8, x17
1015c88d8: 52800389    	mov	w9, #0x1c               ; =28
1015c88dc: 14000012    	b	0x1015c8924 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5db0>
1015c88e0: aa0103e8    	mov	x8, x1
1015c88e4: 52800489    	mov	w9, #0x24               ; =36
1015c88e8: 1400000f    	b	0x1015c8924 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5db0>
1015c88ec: aa0203e8    	mov	x8, x2
1015c88f0: 52800489    	mov	w9, #0x24               ; =36
1015c88f4: 1400000c    	b	0x1015c8924 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5db0>
1015c88f8: aa0303e8    	mov	x8, x3
1015c88fc: 528003e9    	mov	w9, #0x1f               ; =31
1015c8900: 14000009    	b	0x1015c8924 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5db0>
1015c8904: aa0403e8    	mov	x8, x4
1015c8908: 528003a9    	mov	w9, #0x1d               ; =29
1015c890c: 14000006    	b	0x1015c8924 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5db0>
1015c8910: aa0003e8    	mov	x8, x0
1015c8914: 52800509    	mov	w9, #0x28               ; =40
1015c8918: 14000003    	b	0x1015c8924 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5db0>
1015c891c: aa0503e8    	mov	x8, x5
1015c8920: 52800429    	mov	w9, #0x21               ; =33
1015c8924: b900031f    	str	wzr, [x24]
1015c8928: 5280018a    	mov	w10, #0xc               ; =12
1015c892c: a900a30a    	stp	x10, x8, [x24, #0x8]
1015c8930: f9000f09    	str	x9, [x24, #0x18]
1015c8934: 1400000e    	b	0x1015c896c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5df8>
1015c8938: 9000d388    	adrp	x8, 0x103038000 <_anon.d3f3f9f98235ad8ac536c1fcef834f4e.118+0x625>
1015c893c: 91395508    	add	x8, x8, #0xe55
1015c8940: 52800429    	mov	w9, #0x21               ; =33
1015c8944: 14000004    	b	0x1015c8954 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5de0>
1015c8948: f000d388    	adrp	x8, 0x10303b000 <_anon.19b44b453da724831023c27de6e0b6f2.383+0x13b8>
1015c894c: 9129b908    	add	x8, x8, #0xa6e
1015c8950: 52800609    	mov	w9, #0x30               ; =48
1015c8954: b900031f    	str	wzr, [x24]
1015c8958: 5280018a    	mov	w10, #0xc               ; =12
1015c895c: 3900230a    	strb	w10, [x24, #0x8]
1015c8960: a9012708    	stp	x8, x9, [x24, #0x10]
1015c8964: 9108c3e0    	add	x0, sp, #0x230
1015c8968: 97ff76fc    	bl	0x1015a6558 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCsgKscDXrlV49_5alloc11collections9vec_deque8VecDequeNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionEEB1P_>
1015c896c: d10243a0    	sub	x0, x29, #0x90
1015c8970: 97ff7439    	bl	0x1015a5a54 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecINtNtB4_6result6ResultNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1F_27NativeProgramExecutionErrorEEEB1L_>
1015c8974: 52800017    	mov	w23, #0x0               ; =0
1015c8978: 17fffe3d    	b	0x1015c826c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x56f8>
1015c897c: aa0003f4    	mov	x20, x0
1015c8980: 52800017    	mov	w23, #0x0               ; =0
1015c8984: 14000047    	b	0x1015c8aa0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5f2c>
1015c8988: aa0003f4    	mov	x20, x0
1015c898c: 5280003b    	mov	w27, #0x1               ; =1
1015c8990: 14000025    	b	0x1015c8a24 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5eb0>
1015c8994: aa0003f4    	mov	x20, x0
1015c8998: aa1b03f8    	mov	x24, x27
1015c899c: 14000045    	b	0x1015c8ab0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5f3c>
1015c89a0: aa0003f4    	mov	x20, x0
1015c89a4: 52800017    	mov	w23, #0x0               ; =0
1015c89a8: 5280001b    	mov	w27, #0x0               ; =0
1015c89ac: 52800018    	mov	w24, #0x0               ; =0
1015c89b0: 3dc107e0    	ldr	q0, [sp, #0x410]
1015c89b4: 3dc10be1    	ldr	q1, [sp, #0x420]
1015c89b8: ad1e0660    	stp	q0, q1, [x19, #0x3c0]
1015c89bc: 3dc18fe0    	ldr	q0, [sp, #0x630]
1015c89c0: 3dc193e1    	ldr	q1, [sp, #0x640]
1015c89c4: 3d810260    	str	q0, [x19, #0x400]
1015c89c8: 3d810661    	str	q1, [x19, #0x410]
1015c89cc: ad5987e0    	ldp	q0, q1, [sp, #0x330]
1015c89d0: 3d810a60    	str	q0, [x19, #0x420]
1015c89d4: f901f275    	str	x21, [x19, #0x3e0]
1015c89d8: f901f675    	str	x21, [x19, #0x3e8]
1015c89dc: f901fa79    	str	x25, [x19, #0x3f0]
1015c89e0: f901fe76    	str	x22, [x19, #0x3f8]
1015c89e4: 3d810e61    	str	q1, [x19, #0x430]
1015c89e8: 14000030    	b	0x1015c8aa8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5f34>
1015c89ec: aa0003f4    	mov	x20, x0
1015c89f0: 1400000a    	b	0x1015c8a18 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5ea4>
1015c89f4: aa0003f4    	mov	x20, x0
1015c89f8: f9019ff7    	str	x23, [sp, #0x338]
1015c89fc: 14000005    	b	0x1015c8a10 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5e9c>
1015c8a00: aa0003f4    	mov	x20, x0
1015c8a04: f9019ff7    	str	x23, [sp, #0x338]
1015c8a08: 911043e0    	add	x0, sp, #0x410
1015c8a0c: 97ff74b1    	bl	0x1015a5cd0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
1015c8a10: 910cc3e0    	add	x0, sp, #0x330
1015c8a14: 94004c0d    	bl	0x1015dba48 <__RNvXse_NtNtCsgKscDXrlV49_5alloc3vec9into_iterINtB5_8IntoIterNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropB18_>
1015c8a18: 9108c3e0    	add	x0, sp, #0x230
1015c8a1c: 97ff76cf    	bl	0x1015a6558 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCsgKscDXrlV49_5alloc11collections9vec_deque8VecDequeNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionEEB1P_>
1015c8a20: 5280001b    	mov	w27, #0x0               ; =0
1015c8a24: d10243a0    	sub	x0, x29, #0x90
1015c8a28: 97ff740b    	bl	0x1015a5a54 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecINtNtB4_6result6ResultNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1F_27NativeProgramExecutionErrorEEEB1L_>
1015c8a2c: 52800017    	mov	w23, #0x0               ; =0
1015c8a30: 1400001d    	b	0x1015c8aa4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5f30>
1015c8a34: aa0003f4    	mov	x20, x0
1015c8a38: 14000019    	b	0x1015c8a9c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5f28>
1015c8a3c: aa0003f4    	mov	x20, x0
1015c8a40: 14000017    	b	0x1015c8a9c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5f28>
1015c8a44: 1400002b    	b	0x1015c8af0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5f7c>
1015c8a48: 14000033    	b	0x1015c8b14 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5fa0>
1015c8a4c: aa0003f4    	mov	x20, x0
1015c8a50: 9118c3e0    	add	x0, sp, #0x630
1015c8a54: 97ff797b    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c8a58: 140000d7    	b	0x1015c8db4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6240>
1015c8a5c: aa0003f4    	mov	x20, x0
1015c8a60: b4001ab6    	cbz	x22, 0x1015c8db4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6240>
1015c8a64: 911a83e0    	add	x0, sp, #0x6a0
1015c8a68: 97ff7976    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c8a6c: 140000d2    	b	0x1015c8db4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6240>
1015c8a70: aa0003f4    	mov	x20, x0
1015c8a74: 9118c3e0    	add	x0, sp, #0x630
1015c8a78: 97ff7972    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c8a7c: 1400002e    	b	0x1015c8b34 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5fc0>
1015c8a80: aa0003f4    	mov	x20, x0
1015c8a84: 911703e0    	add	x0, sp, #0x5c0
1015c8a88: 97ff7190    	bl	0x1015a50c8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultINtNtCsgKscDXrlV49_5alloc3vec3VecIBH_NtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1J_27NativeProgramExecutionErrorEEB3c_EEB1P_>
1015c8a8c: 14000005    	b	0x1015c8aa0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5f2c>
1015c8a90: aa0003f4    	mov	x20, x0
1015c8a94: 910dc3e0    	add	x0, sp, #0x370
1015c8a98: 97ff7b6b    	bl	0x1015a7844 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workers15NativeWorkGroupECs29QkOtpKx6e_8mech_gpu>
1015c8a9c: 52800037    	mov	w23, #0x1               ; =1
1015c8aa0: 5280003b    	mov	w27, #0x1               ; =1
1015c8aa4: 52800038    	mov	w24, #0x1               ; =1
1015c8aa8: 911ea3e0    	add	x0, sp, #0x7a8
1015c8aac: 97ff78bd    	bl	0x1015a6da0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs29QkOtpKx6e_8mech_gpu>
1015c8ab0: f85083a8    	ldur	x8, [x29, #-0xf8]
1015c8ab4: b40000a8    	cbz	x8, 0x1015c8ac8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5f54>
1015c8ab8: f85103a0    	ldur	x0, [x29, #-0xf0]
1015c8abc: d37df101    	lsl	x1, x8, #3
1015c8ac0: 52800102    	mov	w2, #0x8                ; =8
1015c8ac4: 97a9029e    	bl	0x10000953c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1015c8ac8: 36000077    	tbz	w23, #0x0, 0x1015c8ad4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5f60>
1015c8acc: 910f83e0    	add	x0, sp, #0x3e0
1015c8ad0: 97ff78d2    	bl	0x1015a6e18 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs29QkOtpKx6e_8mech_gpu>
1015c8ad4: 3700025b    	tbnz	w27, #0x0, 0x1015c8b1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5fa8>
1015c8ad8: 14000013    	b	0x1015c8b24 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5fb0>
1015c8adc: 1400000a    	b	0x1015c8b04 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5f90>
1015c8ae0: aa0003f4    	mov	x20, x0
1015c8ae4: 911043e0    	add	x0, sp, #0x410
1015c8ae8: 97ff7956    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c8aec: 14000076    	b	0x1015c8cc4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6150>
1015c8af0: aa0003f4    	mov	x20, x0
1015c8af4: 911703e0    	add	x0, sp, #0x5c0
1015c8af8: 97ff7476    	bl	0x1015a5cd0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
1015c8afc: 14000003    	b	0x1015c8b08 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5f94>
1015c8b00: 14000005    	b	0x1015c8b14 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5fa0>
1015c8b04: aa0003f4    	mov	x20, x0
1015c8b08: 9118c3e0    	add	x0, sp, #0x630
1015c8b0c: 97ff794d    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c8b10: 14000002    	b	0x1015c8b18 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5fa4>
1015c8b14: aa0003f4    	mov	x20, x0
1015c8b18: 52800038    	mov	w24, #0x1               ; =1
1015c8b1c: 912123e0    	add	x0, sp, #0x848
1015c8b20: 97ff7433    	bl	0x1015a5bec <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionEEB1p_>
1015c8b24: 37000278    	tbnz	w24, #0x0, 0x1015c8b70 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5ffc>
1015c8b28: 14000032    	b	0x1015c8bf0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x607c>
1015c8b2c: 14000029    	b	0x1015c8bd0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x605c>
1015c8b30: aa0003f4    	mov	x20, x0
1015c8b34: f942e3e8    	ldr	x8, [sp, #0x5c0]
1015c8b38: b4000c68    	cbz	x8, 0x1015c8cc4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6150>
1015c8b3c: 911703e0    	add	x0, sp, #0x5c0
1015c8b40: 97ff7940    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c8b44: 14000060    	b	0x1015c8cc4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6150>
1015c8b48: f9401be8    	ldr	x8, [sp, #0x30]
1015c8b4c: 8b0802c8    	add	x8, x22, x8
1015c8b50: 3dc1abe0    	ldr	q0, [sp, #0x6a0]
1015c8b54: 3dc1afe1    	ldr	q1, [sp, #0x6b0]
1015c8b58: 3dc1b3e2    	ldr	q2, [sp, #0x6c0]
1015c8b5c: 3dc1b7e3    	ldr	q3, [sp, #0x6d0]
1015c8b60: ad010d02    	stp	q2, q3, [x8, #0x20]
1015c8b64: ad000500    	stp	q0, q1, [x8]
1015c8b68: 9460af91    	bl	0x102df49ac <dyld_stub_binder+0x102df49ac>
1015c8b6c: aa0003f4    	mov	x20, x0
1015c8b70: 912083e0    	add	x0, sp, #0x820
1015c8b74: 97ff788b    	bl	0x1015a6da0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs29QkOtpKx6e_8mech_gpu>
1015c8b78: 14000008    	b	0x1015c8b98 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6024>
1015c8b7c: aa0003f4    	mov	x20, x0
1015c8b80: 911a83e1    	add	x1, sp, #0x6a0
1015c8b84: aa1503e0    	mov	x0, x21
1015c8b88: 52802102    	mov	w2, #0x108              ; =264
1015c8b8c: 9460b003    	bl	0x102df4b98 <dyld_stub_binder+0x102df4b98>
1015c8b90: 1400005e    	b	0x1015c8d08 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6194>
1015c8b94: aa0003f4    	mov	x20, x0
1015c8b98: 912003e0    	add	x0, sp, #0x800
1015c8b9c: 97ff789f    	bl	0x1015a6e18 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs29QkOtpKx6e_8mech_gpu>
1015c8ba0: 14000014    	b	0x1015c8bf0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x607c>
1015c8ba4: aa0003f4    	mov	x20, x0
1015c8ba8: 9118c3e0    	add	x0, sp, #0x630
1015c8bac: 97ff7925    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c8bb0: 14000081    	b	0x1015c8db4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6240>
1015c8bb4: aa0003f4    	mov	x20, x0
1015c8bb8: 394dc3e8    	ldrb	w8, [sp, #0x370]
1015c8bbc: 7100b91f    	cmp	w8, #0x2e
1015c8bc0: 540000a0    	b.eq	0x1015c8bd4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6060>
1015c8bc4: 910dc3e0    	add	x0, sp, #0x370
1015c8bc8: 97ff7c12    	bl	0x1015a7c10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs29QkOtpKx6e_8mech_gpu>
1015c8bcc: 14000002    	b	0x1015c8bd4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6060>
1015c8bd0: aa0003f4    	mov	x20, x0
1015c8bd4: f942e3e8    	ldr	x8, [sp, #0x5c0]
1015c8bd8: b4000ee8    	cbz	x8, 0x1015c8db4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6240>
1015c8bdc: 911703e0    	add	x0, sp, #0x5c0
1015c8be0: 97ff7918    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c8be4: 14000074    	b	0x1015c8db4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6240>
1015c8be8: 1400002c    	b	0x1015c8c98 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6124>
1015c8bec: aa0003f4    	mov	x20, x0
1015c8bf0: f943f7e8    	ldr	x8, [sp, #0x7e8]
1015c8bf4: 92800009    	mov	x9, #-0x1               ; =-1
1015c8bf8: f8690108    	ldaddl	x9, x8, [x8]
1015c8bfc: f100051f    	cmp	x8, #0x1
1015c8c00: 54000da1    	b.ne	0x1015c8db4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6240>
1015c8c04: d50339bf    	dmb	ishld
1015c8c08: 911fa3e0    	add	x0, sp, #0x7e8
1015c8c0c: 945ca4f7    	bl	0x102cf1fe8 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015c8c10: 14000069    	b	0x1015c8db4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6240>
1015c8c14: aa0003f4    	mov	x20, x0
1015c8c18: f94023e8    	ldr	x8, [sp, #0x40]
1015c8c1c: f9424908    	ldr	x8, [x8, #0x490]
1015c8c20: 91078100    	add	x0, x8, #0x1e0
1015c8c24: 911a83e1    	add	x1, sp, #0x6a0
1015c8c28: 52802102    	mov	w2, #0x108              ; =264
1015c8c2c: 9460afdb    	bl	0x102df4b98 <dyld_stub_binder+0x102df4b98>
1015c8c30: b94633e8    	ldr	w8, [sp, #0x630]
1015c8c34: 7100191f    	cmp	w8, #0x6
1015c8c38: 54000be0    	b.eq	0x1015c8db4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6240>
1015c8c3c: 9118c3e0    	add	x0, sp, #0x630
1015c8c40: 97ff7b40    	bl	0x1015a7940 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
1015c8c44: aa1403e0    	mov	x0, x20
1015c8c48: 9460af59    	bl	0x102df49ac <dyld_stub_binder+0x102df49ac>
1015c8c4c: aa0003f4    	mov	x20, x0
1015c8c50: f94353e8    	ldr	x8, [sp, #0x6a0]
1015c8c54: 92800009    	mov	x9, #-0x1               ; =-1
1015c8c58: f8690108    	ldaddl	x9, x8, [x8]
1015c8c5c: f100051f    	cmp	x8, #0x1
1015c8c60: 54000aa1    	b.ne	0x1015c8db4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6240>
1015c8c64: d50339bf    	dmb	ishld
1015c8c68: 911a83e0    	add	x0, sp, #0x6a0
1015c8c6c: 945ca4df    	bl	0x102cf1fe8 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015c8c70: 14000051    	b	0x1015c8db4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6240>
1015c8c74: 9460aa55    	bl	0x102df35c8 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1015c8c78: aa0003f4    	mov	x20, x0
1015c8c7c: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1015c8c80: f9000268    	str	x8, [x19]
1015c8c84: 14000027    	b	0x1015c8d20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x61ac>
1015c8c88: aa0003f4    	mov	x20, x0
1015c8c8c: 911043e0    	add	x0, sp, #0x410
1015c8c90: 97ff7bc4    	bl	0x1015a7ba0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixECs29QkOtpKx6e_8mech_gpu>
1015c8c94: 1400001d    	b	0x1015c8d08 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6194>
1015c8c98: aa0003f4    	mov	x20, x0
1015c8c9c: 1400001b    	b	0x1015c8d08 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6194>
1015c8ca0: aa0003f4    	mov	x20, x0
1015c8ca4: 910dc3e0    	add	x0, sp, #0x370
1015c8ca8: 97ff7b6f    	bl	0x1015a7a64 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrix27OwnedSnapshotUnsignedMatrixECs29QkOtpKx6e_8mech_gpu>
1015c8cac: 14000012    	b	0x1015c8cf4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6180>
1015c8cb0: aa0003f4    	mov	x20, x0
1015c8cb4: 911043e0    	add	x0, sp, #0x410
1015c8cb8: 97ff7c48    	bl	0x1015a7dd8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime11collections5StateEBQ_>
1015c8cbc: 1400003e    	b	0x1015c8db4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6240>
1015c8cc0: aa0003f4    	mov	x20, x0
1015c8cc4: 910dc3e0    	add	x0, sp, #0x370
1015c8cc8: 97ff78de    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c8ccc: 1400003a    	b	0x1015c8db4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6240>
1015c8cd0: 9460aa3e    	bl	0x102df35c8 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1015c8cd4: aa0003f4    	mov	x20, x0
1015c8cd8: 911043e0    	add	x0, sp, #0x410
1015c8cdc: 97ff78d9    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c8ce0: 14000035    	b	0x1015c8db4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6240>
1015c8ce4: aa0003f4    	mov	x20, x0
1015c8ce8: 52800039    	mov	w25, #0x1               ; =1
1015c8cec: 14000008    	b	0x1015c8d0c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6198>
1015c8cf0: aa0003f4    	mov	x20, x0
1015c8cf4: b40000d9    	cbz	x25, 0x1015c8d0c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6198>
1015c8cf8: d37df321    	lsl	x1, x25, #3
1015c8cfc: aa1703e0    	mov	x0, x23
1015c8d00: 52800102    	mov	w2, #0x8                ; =8
1015c8d04: 97a9020e    	bl	0x10000953c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1015c8d08: 52800019    	mov	w25, #0x0               ; =0
1015c8d0c: 912083e0    	add	x0, sp, #0x820
1015c8d10: 97ff7842    	bl	0x1015a6e18 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs29QkOtpKx6e_8mech_gpu>
1015c8d14: 1400000d    	b	0x1015c8d48 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x61d4>
1015c8d18: aa0003f4    	mov	x20, x0
1015c8d1c: aa1c03f9    	mov	x25, x28
1015c8d20: 340004b9    	cbz	w25, 0x1015c8db4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6240>
1015c8d24: f94353e8    	ldr	x8, [sp, #0x6a0]
1015c8d28: b4000468    	cbz	x8, 0x1015c8db4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6240>
1015c8d2c: 911a83e0    	add	x0, sp, #0x6a0
1015c8d30: 97ff78c4    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c8d34: 14000020    	b	0x1015c8db4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6240>
1015c8d38: 9460aa24    	bl	0x102df35c8 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1015c8d3c: aa0003f4    	mov	x20, x0
1015c8d40: 1400000b    	b	0x1015c8d6c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x61f8>
1015c8d44: aa0003f4    	mov	x20, x0
1015c8d48: f94403e8    	ldr	x8, [sp, #0x800]
1015c8d4c: 92800009    	mov	x9, #-0x1               ; =-1
1015c8d50: f8690108    	ldaddl	x9, x8, [x8]
1015c8d54: f100051f    	cmp	x8, #0x1
1015c8d58: 54000081    	b.ne	0x1015c8d68 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x61f4>
1015c8d5c: d50339bf    	dmb	ishld
1015c8d60: 912003e0    	add	x0, sp, #0x800
1015c8d64: 945ca4a1    	bl	0x102cf1fe8 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015c8d68: 36000279    	tbz	w25, #0x0, 0x1015c8db4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6240>
1015c8d6c: 910cc3e0    	add	x0, sp, #0x330
1015c8d70: 97ff78b4    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c8d74: 14000010    	b	0x1015c8db4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6240>
1015c8d78: aa0003f4    	mov	x20, x0
1015c8d7c: 9108c3e0    	add	x0, sp, #0x230
1015c8d80: 97ff78b0    	bl	0x1015a7040 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015c8d84: 1400000c    	b	0x1015c8db4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6240>
1015c8d88: 9460aa10    	bl	0x102df35c8 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1015c8d8c: 52800048    	mov	w8, #0x2                ; =2
1015c8d90: f9011268    	str	x8, [x19, #0x220]
1015c8d94: 9460af06    	bl	0x102df49ac <dyld_stub_binder+0x102df49ac>
1015c8d98: 52800048    	mov	w8, #0x2                ; =2
1015c8d9c: f9011268    	str	x8, [x19, #0x220]
1015c8da0: 9460af03    	bl	0x102df49ac <dyld_stub_binder+0x102df49ac>
1015c8da4: aa0003f4    	mov	x20, x0
1015c8da8: b946a3e8    	ldr	w8, [sp, #0x6a0]
1015c8dac: 7100191f    	cmp	w8, #0x6
1015c8db0: 54000061    	b.ne	0x1015c8dbc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6248>
1015c8db4: aa1403e0    	mov	x0, x20
1015c8db8: 9460aefd    	bl	0x102df49ac <dyld_stub_binder+0x102df49ac>
1015c8dbc: 911a83e0    	add	x0, sp, #0x6a0
1015c8dc0: 97ff7ae0    	bl	0x1015a7940 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
1015c8dc4: aa1403e0    	mov	x0, x20
1015c8dc8: 9460aef9    	bl	0x102df49ac <dyld_stub_binder+0x102df49ac>
