
/private/tmp/mech-action-retirement-round37-20261030/workers/after:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010152d63c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation17collection_helper>:
10152d63c: a9bc5ff8    	stp	x24, x23, [sp, #-0x40]!
10152d640: a90157f6    	stp	x22, x21, [sp, #0x10]
10152d644: a9024ff4    	stp	x20, x19, [sp, #0x20]
10152d648: a9037bfd    	stp	x29, x30, [sp, #0x30]
10152d64c: 9100c3fd    	add	x29, sp, #0x30
10152d650: d109c3ff    	sub	sp, sp, #0x270
10152d654: aa0003f3    	mov	x19, x0
10152d658: f9424c28    	ldr	x8, [x1, #0x498]
10152d65c: f942482d    	ldr	x13, [x1, #0x490]
10152d660: f940f1a9    	ldr	x9, [x13, #0x1e0]
10152d664: fd40f5a0    	ldr	d0, [x13, #0x1e8]
10152d668: 3947c1aa    	ldrb	w10, [x13, #0x1f0]
10152d66c: a95fb1ab    	ldp	x11, x12, [x13, #0x1f8]
10152d670: d2f0000e    	mov	x14, #-0x8000000000000000 ; =-9223372036854775808
10152d674: f900f1ae    	str	x14, [x13, #0x1e0]
10152d678: eb0e013f    	cmp	x9, x14
10152d67c: 54000121    	b.ne	0x10152d6a0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation17collection_helper+0x64>
10152d680: b900027f    	str	wzr, [x19]
10152d684: 52800188    	mov	w8, #0xc                ; =12
10152d688: 39002268    	strb	w8, [x19, #0x8]
10152d68c: b000d828    	adrp	x8, 0x103032000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.241+0x21>
10152d690: 913a6908    	add	x8, x8, #0xe9a
10152d694: 528003e9    	mov	w9, #0x1f               ; =31
10152d698: a9012668    	stp	x8, x9, [x19, #0x10]
10152d69c: 14000081    	b	0x10152d8a0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation17collection_helper+0x264>
10152d6a0: aa0103f4    	mov	x20, x1
10152d6a4: 910023ee    	add	x14, sp, #0x8
10152d6a8: 9108e1af    	add	x15, x13, #0x238
10152d6ac: 910821b0    	add	x16, x13, #0x208
10152d6b0: ad400a01    	ldp	q1, q2, [x16]
10152d6b4: ad018be1    	stp	q1, q2, [sp, #0x30]
10152d6b8: 3dc00a04    	ldr	q4, [x16, #0x20]
10152d6bc: ad4489e1    	ldp	q1, q2, [x15, #0x90]
10152d6c0: 3c8f81c2    	stur	q2, [x14, #0xf8]
10152d6c4: 3dc021e2    	ldr	q2, [x15, #0x80]
10152d6c8: 3c8e81c1    	stur	q1, [x14, #0xe8]
10152d6cc: 3c8d81c2    	stur	q2, [x14, #0xd8]
10152d6d0: ad4305e2    	ldp	q2, q1, [x15, #0x60]
10152d6d4: 3c8c81c1    	stur	q1, [x14, #0xc8]
10152d6d8: 3c8b81c2    	stur	q2, [x14, #0xb8]
10152d6dc: ad4205e2    	ldp	q2, q1, [x15, #0x40]
10152d6e0: 3c8a81c1    	stur	q1, [x14, #0xa8]
10152d6e4: 3c8981c2    	stur	q2, [x14, #0x98]
10152d6e8: ad4105e2    	ldp	q2, q1, [x15, #0x20]
10152d6ec: 3c8881c1    	stur	q1, [x14, #0x88]
10152d6f0: ad400de1    	ldp	q1, q3, [x15]
10152d6f4: ad0287e4    	stp	q4, q1, [sp, #0x50]
10152d6f8: ad038be3    	stp	q3, q2, [sp, #0x70]
10152d6fc: 9107c5ae    	add	x14, x13, #0x1f1
10152d700: b941f5ad    	ldr	w13, [x13, #0x1f4]
10152d704: b9001fed    	str	w13, [sp, #0x1c]
10152d708: b94001cd    	ldr	w13, [x14]
10152d70c: b80193ed    	stur	w13, [sp, #0x19]
10152d710: f90007e9    	str	x9, [sp, #0x8]
10152d714: fd000be0    	str	d0, [sp, #0x10]
10152d718: 390063ea    	strb	w10, [sp, #0x18]
10152d71c: a90233eb    	stp	x11, x12, [sp, #0x20]
10152d720: f941bd01    	ldr	x1, [x8, #0x378]
10152d724: eb01005f    	cmp	x2, x1
10152d728: 54000c82    	b.hs	0x10152d8b8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation17collection_helper+0x27c>
10152d72c: 910443f6    	add	x22, sp, #0x110
10152d730: f941b908    	ldr	x8, [x8, #0x370]
10152d734: 52802e09    	mov	w9, #0x170              ; =368
10152d738: 9b092048    	madd	x8, x2, x9, x8
10152d73c: b9415d17    	ldr	w23, [x8, #0x15c]
10152d740: 71001eff    	cmp	w23, #0x7
10152d744: 54000201    	b.ne	0x10152d784 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation17collection_helper+0x148>
10152d748: b9416115    	ldr	w21, [x8, #0x160]
10152d74c: f900b3f4    	str	x20, [sp, #0x160]
10152d750: 9105a3e8    	add	x8, sp, #0x168
10152d754: 910023e0    	add	x0, sp, #0x8
10152d758: 910583e1    	add	x1, sp, #0x160
10152d75c: 9401d1b6    	bl	0x1015a1e34 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime11collections13uniform_wordsNtB4_5State18fill_uniform_words>
10152d760: b9416be8    	ldr	w8, [sp, #0x168]
10152d764: 7100191f    	cmp	w8, #0x6
10152d768: 54000201    	b.ne	0x10152d7a8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation17collection_helper+0x16c>
10152d76c: 3945b3e8    	ldrb	w8, [sp, #0x16c]
10152d770: 52800029    	mov	w9, #0x1                ; =1
10152d774: a911a3e9    	stp	x9, x8, [sp, #0x118]
10152d778: 528000c8    	mov	w8, #0x6                ; =6
10152d77c: b90113e8    	str	w8, [sp, #0x110]
10152d780: 14000017    	b	0x10152d7dc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation17collection_helper+0x1a0>
10152d784: a9160ff4    	stp	x20, x3, [sp, #0x160]
10152d788: f900bbe4    	str	x4, [sp, #0x170]
10152d78c: 910443e8    	add	x8, sp, #0x110
10152d790: 910023e0    	add	x0, sp, #0x8
10152d794: 910583e1    	add	x1, sp, #0x160
10152d798: 9105a3e3    	add	x3, sp, #0x168
10152d79c: 9401bd95    	bl	0x10159cdf0 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime11collectionsNtB2_5State6helper>
10152d7a0: d2800015    	mov	x21, #0x0               ; =0
10152d7a4: 1400000f    	b	0x10152d7e0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation17collection_helper+0x1a4>
10152d7a8: 910227e8    	add	x8, sp, #0x89
10152d7ac: 3ccff100    	ldur	q0, [x8, #0xff]
10152d7b0: 910267e8    	add	x8, sp, #0x99
10152d7b4: 3ccff101    	ldur	q1, [x8, #0xff]
10152d7b8: ad0106c0    	stp	q0, q1, [x22, #0x20]
10152d7bc: 9102a7e8    	add	x8, sp, #0xa9
10152d7c0: 3ccff100    	ldur	q0, [x8, #0xff]
10152d7c4: 3d8012c0    	str	q0, [x22, #0x40]
10152d7c8: 9101e7e8    	add	x8, sp, #0x79
10152d7cc: 3ccff100    	ldur	q0, [x8, #0xff]
10152d7d0: 9101a7e8    	add	x8, sp, #0x69
10152d7d4: 3ccff101    	ldur	q1, [x8, #0xff]
10152d7d8: ad0002c1    	stp	q1, q0, [x22]
10152d7dc: d37ffab5    	lsl	x21, x21, #1
10152d7e0: 9105a3e0    	add	x0, sp, #0x168
10152d7e4: 910023e1    	add	x1, sp, #0x8
10152d7e8: 52802102    	mov	w2, #0x108              ; =264
10152d7ec: 94631ffe    	bl	0x102df57e4 <dyld_stub_binder+0x102df57e4>
10152d7f0: f9424a88    	ldr	x8, [x20, #0x490]
10152d7f4: f940f109    	ldr	x9, [x8, #0x1e0]
10152d7f8: d2f0000a    	mov	x10, #-0x8000000000000000 ; =-9223372036854775808
10152d7fc: eb0a013f    	cmp	x9, x10
10152d800: 54000080    	b.eq	0x10152d810 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation17collection_helper+0x1d4>
10152d804: 91078100    	add	x0, x8, #0x1e0
10152d808: 97ffd4c3    	bl	0x101522b14 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime11collections5StateEBQ_>
10152d80c: f9424a88    	ldr	x8, [x20, #0x490]
10152d810: 91078100    	add	x0, x8, #0x1e0
10152d814: 9105a3e1    	add	x1, sp, #0x168
10152d818: 52802102    	mov	w2, #0x108              ; =264
10152d81c: 94631ff2    	bl	0x102df57e4 <dyld_stub_binder+0x102df57e4>
10152d820: b94113ea    	ldr	w10, [sp, #0x110]
10152d824: a951a3e9    	ldp	x9, x8, [sp, #0x118]
10152d828: 7100195f    	cmp	w10, #0x6
10152d82c: 54000241    	b.ne	0x10152d874 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation17collection_helper+0x238>
10152d830: 71001eff    	cmp	w23, #0x7
10152d834: 54000121    	b.ne	0x10152d858 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation17collection_helper+0x21c>
10152d838: 36000109    	tbz	w9, #0x0, 0x10152d858 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation17collection_helper+0x21c>
10152d83c: f100051f    	cmp	x8, #0x1
10152d840: 540000c1    	b.ne	0x10152d858 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation17collection_helper+0x21c>
10152d844: f9425e81    	ldr	x1, [x20, #0x4b8]
10152d848: eb0102bf    	cmp	x21, x1
10152d84c: 54000422    	b.hs	0x10152d8d0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation17collection_helper+0x294>
10152d850: f9425a8a    	ldr	x10, [x20, #0x4b0]
10152d854: f835795f    	str	xzr, [x10, x21, lsl #3]
10152d858: f9424a8a    	ldr	x10, [x20, #0x490]
10152d85c: 5280002b    	mov	w11, #0x1               ; =1
10152d860: 3911814b    	strb	w11, [x10, #0x460]
10152d864: a900a269    	stp	x9, x8, [x19, #0x8]
10152d868: 528000c8    	mov	w8, #0x6                ; =6
10152d86c: b9000268    	str	w8, [x19]
10152d870: 1400000c    	b	0x10152d8a0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation17collection_helper+0x264>
10152d874: b94117eb    	ldr	w11, [sp, #0x114]
10152d878: 3cc182c0    	ldur	q0, [x22, #0x18]
10152d87c: 3c818260    	stur	q0, [x19, #0x18]
10152d880: 3cc282c0    	ldur	q0, [x22, #0x28]
10152d884: 3c828260    	stur	q0, [x19, #0x28]
10152d888: 3cc382c0    	ldur	q0, [x22, #0x38]
10152d88c: 3c838260    	stur	q0, [x19, #0x38]
10152d890: f940afec    	ldr	x12, [sp, #0x158]
10152d894: f900266c    	str	x12, [x19, #0x48]
10152d898: 29002e6a    	stp	w10, w11, [x19]
10152d89c: a900a269    	stp	x9, x8, [x19, #0x8]
10152d8a0: 9109c3ff    	add	sp, sp, #0x270
10152d8a4: a9437bfd    	ldp	x29, x30, [sp, #0x30]
10152d8a8: a9424ff4    	ldp	x20, x19, [sp, #0x20]
10152d8ac: a94157f6    	ldp	x22, x21, [sp, #0x10]
10152d8b0: a8c45ff8    	ldp	x24, x23, [sp], #0x40
10152d8b4: d65f03c0    	ret
10152d8b8: f00124e8    	adrp	x8, 0x1039cc000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.291+0x310>
10152d8bc: 913c4108    	add	x8, x8, #0xf10
10152d8c0: aa0203e0    	mov	x0, x2
10152d8c4: aa0803e2    	mov	x2, x8
10152d8c8: 94631a59    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152d8cc: d4200020    	brk	#0x1
10152d8d0: f00124e2    	adrp	x2, 0x1039cc000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.291+0x310>
10152d8d4: 913ca042    	add	x2, x2, #0xf28
10152d8d8: aa1503e0    	mov	x0, x21
10152d8dc: 94631a54    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152d8e0: aa0003f3    	mov	x19, x0
10152d8e4: f9424a88    	ldr	x8, [x20, #0x490]
10152d8e8: 91078100    	add	x0, x8, #0x1e0
10152d8ec: 9105a3e1    	add	x1, sp, #0x168
10152d8f0: 52802102    	mov	w2, #0x108              ; =264
10152d8f4: 94631fbc    	bl	0x102df57e4 <dyld_stub_binder+0x102df57e4>
10152d8f8: b94113e8    	ldr	w8, [sp, #0x110]
10152d8fc: 7100191f    	cmp	w8, #0x6
10152d900: 54000100    	b.eq	0x10152d920 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation17collection_helper+0x2e4>
10152d904: 910443e0    	add	x0, sp, #0x110
10152d908: 97ffd35d    	bl	0x10152267c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
10152d90c: aa1303e0    	mov	x0, x19
10152d910: 94631f3a    	bl	0x102df55f8 <dyld_stub_binder+0x102df55f8>
10152d914: aa0003f3    	mov	x19, x0
10152d918: 910023e0    	add	x0, sp, #0x8
10152d91c: 97ffd47e    	bl	0x101522b14 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime11collections5StateEBQ_>
10152d920: aa1303e0    	mov	x0, x19
10152d924: 94631f35    	bl	0x102df55f8 <dyld_stub_binder+0x102df55f8>
10152d928: 94631a3b    	bl	0x102df4214 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
