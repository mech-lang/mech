
/private/tmp/mech-action-retirement-round37-20261030/workers/after:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010153ee5c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper>:
10153ee5c: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
10153ee60: a90167fa    	stp	x26, x25, [sp, #0x10]
10153ee64: a9025ff8    	stp	x24, x23, [sp, #0x20]
10153ee68: a90357f6    	stp	x22, x21, [sp, #0x30]
10153ee6c: a9044ff4    	stp	x20, x19, [sp, #0x40]
10153ee70: a9057bfd    	stp	x29, x30, [sp, #0x50]
10153ee74: 910143fd    	add	x29, sp, #0x50
10153ee78: d11d03ff    	sub	sp, sp, #0x740
10153ee7c: f90003ff    	str	xzr, [sp]
10153ee80: 91007449    	add	x9, x2, #0x1d
10153ee84: f1007d3f    	cmp	x9, #0x1f
10153ee88: 54000168    	b.hi	0x10153eeb4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58>
10153ee8c: 12a2000a    	mov	w10, #-0x10000001       ; =-268435457
10153ee90: 1ac9254a    	lsr	w10, w10, w9
10153ee94: 3600010a    	tbz	w10, #0x0, 0x10153eeb4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58>
10153ee98: d000d7ca    	adrp	x10, 0x103038000 <_anon.369b439a638cb010e9292f03e79ebf78.885+0xd66>
10153ee9c: 9100014a    	add	x10, x10, #0x0
10153eea0: f8697956    	ldr	x22, [x10, x9, lsl #3]
10153eea4: f9411c09    	ldr	x9, [x0, #0x238]
10153eea8: f1000d3f    	cmp	x9, #0x3
10153eeac: 540000e1    	b.ne	0x10153eec8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6c>
10153eeb0: 14000010    	b	0x10153eef0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x94>
10153eeb4: d1000c55    	sub	x21, x2, #0x3
10153eeb8: 52800076    	mov	w22, #0x3               ; =3
10153eebc: f9411c09    	ldr	x9, [x0, #0x238]
10153eec0: f1000d3f    	cmp	x9, #0x3
10153eec4: 54000160    	b.eq	0x10153eef0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x94>
10153eec8: b9426809    	ldr	w9, [x0, #0x268]
10153eecc: 34000129    	cbz	w9, 0x10153eef0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x94>
10153eed0: b900011f    	str	wzr, [x8]
10153eed4: 52800189    	mov	w9, #0xc                ; =12
10153eed8: 39002109    	strb	w9, [x8, #0x8]
10153eedc: 9000d7c9    	adrp	x9, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
10153eee0: 91204929    	add	x9, x9, #0x812
10153eee4: 528004aa    	mov	w10, #0x25              ; =37
10153eee8: a9012909    	stp	x9, x10, [x8, #0x10]
10153eeec: 14000091    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10153eef0: f1002edf    	cmp	x22, #0xb
10153eef4: 540006c0    	b.eq	0x10153efcc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x170>
10153eef8: 911343fb    	add	x27, sp, #0x4d0
10153eefc: 911183f8    	add	x24, sp, #0x460
10153ef00: 910d43f9    	add	x25, sp, #0x350
10153ef04: 910903fa    	add	x26, sp, #0x240
10153ef08: f10076df    	cmp	x22, #0x1d
10153ef0c: 540002a0    	b.eq	0x10153ef60 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x104>
10153ef10: f1007edf    	cmp	x22, #0x1f
10153ef14: 54000741    	b.ne	0x10153effc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a0>
10153ef18: a9407074    	ldp	x20, x28, [x3]
10153ef1c: f940086a    	ldr	x10, [x3, #0x10]
10153ef20: a94c2c0c    	ldp	x12, x11, [x0, #0xc0]
10153ef24: a94d4c1a    	ldp	x26, x19, [x0, #0xd0]
10153ef28: a94e6416    	ldp	x22, x25, [x0, #0xe0]
10153ef2c: b940f009    	ldr	w9, [x0, #0xf0]
10153ef30: 5280004d    	mov	w13, #0x2               ; =2
10153ef34: f900600d    	str	x13, [x0, #0xc0]
10153ef38: b4000a0c    	cbz	x12, 0x10153f078 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x21c>
10153ef3c: f100099f    	cmp	x12, #0x2
10153ef40: 54000aa1    	b.ne	0x10153f094 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x238>
10153ef44: b900011f    	str	wzr, [x8]
10153ef48: 52800189    	mov	w9, #0xc                ; =12
10153ef4c: 9000d7aa    	adrp	x10, 0x103032000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.241+0x21>
10153ef50: 913bbd4a    	add	x10, x10, #0xeef
10153ef54: a900a909    	stp	x9, x10, [x8, #0x8]
10153ef58: 52800409    	mov	w9, #0x20               ; =32
10153ef5c: 14000074    	b	0x10153f12c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
10153ef60: f9424c17    	ldr	x23, [x0, #0x498]
10153ef64: f9413ae9    	ldr	x9, [x23, #0x270]
10153ef68: eb09003f    	cmp	x1, x9
10153ef6c: 540006a2    	b.hs	0x10153f040 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1e4>
10153ef70: f94136e9    	ldr	x9, [x23, #0x268]
10153ef74: 8b011129    	add	x9, x9, x1, lsl #4
10153ef78: b940012a    	ldr	w10, [x9]
10153ef7c: 3600062a    	tbz	w10, #0x0, 0x10153f040 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1e4>
10153ef80: f9400529    	ldr	x9, [x9, #0x8]
10153ef84: f9412eea    	ldr	x10, [x23, #0x258]
10153ef88: eb0a013f    	cmp	x9, x10
10153ef8c: 54012982    	b.hs	0x1015414bc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2660>
10153ef90: f9412aea    	ldr	x10, [x23, #0x250]
10153ef94: 52802a0b    	mov	w11, #0x150             ; =336
10153ef98: 9b0b293c    	madd	x28, x9, x11, x10
10153ef9c: aa1c03f3    	mov	x19, x28
10153efa0: f8420e6a    	ldr	x10, [x19, #0x20]!
10153efa4: d2f0000b    	mov	x11, #-0x8000000000000000 ; =-9223372036854775808
10153efa8: eb0b015f    	cmp	x10, x11
10153efac: 54000f41    	b.ne	0x10153f194 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x338>
10153efb0: b900011f    	str	wzr, [x8]
10153efb4: 52800189    	mov	w9, #0xc                ; =12
10153efb8: 9000d7aa    	adrp	x10, 0x103032000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.241+0x21>
10153efbc: 9139dd4a    	add	x10, x10, #0xe77
10153efc0: a900a909    	stp	x9, x10, [x8, #0x8]
10153efc4: 52800469    	mov	w9, #0x23               ; =35
10153efc8: 14000059    	b	0x10153f12c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
10153efcc: aa0003e9    	mov	x9, x0
10153efd0: aa0803e0    	mov	x0, x8
10153efd4: aa0103e2    	mov	x2, x1
10153efd8: aa0903e1    	mov	x1, x9
10153efdc: 911d03ff    	add	sp, sp, #0x740
10153efe0: a9457bfd    	ldp	x29, x30, [sp, #0x50]
10153efe4: a9444ff4    	ldp	x20, x19, [sp, #0x40]
10153efe8: a94357f6    	ldp	x22, x21, [sp, #0x30]
10153efec: a9425ff8    	ldp	x24, x23, [sp, #0x20]
10153eff0: a94167fa    	ldp	x26, x25, [sp, #0x10]
10153eff4: a8c66ffc    	ldp	x28, x27, [sp], #0x60
10153eff8: 17ffca89    	b	0x101531a1c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation15end_closed_tail>
10153effc: f9406009    	ldr	x9, [x0, #0xc0]
10153f000: f100093f    	cmp	x9, #0x2
10153f004: 540002c1    	b.ne	0x10153f05c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x200>
10153f008: f10056df    	cmp	x22, #0x15
10153f00c: 54000a2c    	b.gt	0x10153f150 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f4>
10153f010: d10032c9    	sub	x9, x22, #0xc
10153f014: f100113f    	cmp	x9, #0x4
10153f018: 54002022    	b.hs	0x10153f41c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5c0>
10153f01c: d360fc29    	lsr	x9, x1, #32
10153f020: b4000da9    	cbz	x9, 0x10153f1d4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x378>
10153f024: b900011f    	str	wzr, [x8]
10153f028: 52800189    	mov	w9, #0xc                ; =12
10153f02c: 39002109    	strb	w9, [x8, #0x8]
10153f030: b000d7a9    	adrp	x9, 0x103034000 <_anon.369b439a638cb010e9292f03e79ebf78.107+0xf6b>
10153f034: 9109fd29    	add	x9, x9, #0x27f
10153f038: 528002aa    	mov	w10, #0x15              ; =21
10153f03c: 17ffffab    	b	0x10153eee8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10153f040: b900011f    	str	wzr, [x8]
10153f044: 52800189    	mov	w9, #0xc                ; =12
10153f048: f000d78a    	adrp	x10, 0x103032000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.241+0x21>
10153f04c: 91360d4a    	add	x10, x10, #0xd83
10153f050: a900a909    	stp	x9, x10, [x8, #0x8]
10153f054: 528005a9    	mov	w9, #0x2d               ; =45
10153f058: 14000035    	b	0x10153f12c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
10153f05c: b900011f    	str	wzr, [x8]
10153f060: 52800189    	mov	w9, #0xc                ; =12
10153f064: 39002109    	strb	w9, [x8, #0x8]
10153f068: f000d7a9    	adrp	x9, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
10153f06c: 91194929    	add	x9, x9, #0x652
10153f070: 528006aa    	mov	w10, #0x35              ; =53
10153f074: 17ffff9d    	b	0x10153eee8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10153f078: b900011f    	str	wzr, [x8]
10153f07c: 52800189    	mov	w9, #0xc                ; =12
10153f080: 39002109    	strb	w9, [x8, #0x8]
10153f084: d000d7a9    	adrp	x9, 0x103035000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x4a0>
10153f088: 910ae529    	add	x9, x9, #0x2b9
10153f08c: 528004ea    	mov	w10, #0x27              ; =39
10153f090: 17ffff96    	b	0x10153eee8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10153f094: f9424c15    	ldr	x21, [x0, #0x498]
10153f098: f940beac    	ldr	x12, [x21, #0x178]
10153f09c: eb0c017f    	cmp	x11, x12
10153f0a0: 540003a2    	b.hs	0x10153f114 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b8>
10153f0a4: f940baac    	ldr	x12, [x21, #0x170]
10153f0a8: 8b0b118c    	add	x12, x12, x11, lsl #4
10153f0ac: f940018b    	ldr	x11, [x12]
10153f0b0: f940b2ad    	ldr	x13, [x21, #0x160]
10153f0b4: eb0d017f    	cmp	x11, x13
10153f0b8: 540002e2    	b.hs	0x10153f114 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b8>
10153f0bc: f940058c    	ldr	x12, [x12, #0x8]
10153f0c0: f940aead    	ldr	x13, [x21, #0x158]
10153f0c4: 5280090e    	mov	w14, #0x48              ; =72
10153f0c8: 9b0e356b    	madd	x11, x11, x14, x13
10153f0cc: f940156d    	ldr	x13, [x11, #0x28]
10153f0d0: eb0d019f    	cmp	x12, x13
10153f0d4: 54000202    	b.hs	0x10153f114 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b8>
10153f0d8: f940116d    	ldr	x13, [x11, #0x20]
10153f0dc: 5280220e    	mov	w14, #0x110             ; =272
10153f0e0: 9b0e3597    	madd	x23, x12, x14, x13
10153f0e4: aa1703f8    	mov	x24, x23
10153f0e8: f8430f0d    	ldr	x13, [x24, #0x30]!
10153f0ec: d2f0000c    	mov	x12, #-0x8000000000000000 ; =-9223372036854775808
10153f0f0: eb0c01bf    	cmp	x13, x12
10153f0f4: 54002cc1    	b.ne	0x10153f68c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x830>
10153f0f8: b900011f    	str	wzr, [x8]
10153f0fc: 52800189    	mov	w9, #0xc                ; =12
10153f100: f000d78a    	adrp	x10, 0x103032000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.241+0x21>
10153f104: 913c3d4a    	add	x10, x10, #0xf0f
10153f108: a900a909    	stp	x9, x10, [x8, #0x8]
10153f10c: 528003e9    	mov	w9, #0x1f               ; =31
10153f110: 14000007    	b	0x10153f12c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
10153f114: b900011f    	str	wzr, [x8]
10153f118: 52800189    	mov	w9, #0xc                ; =12
10153f11c: 9000d7aa    	adrp	x10, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
10153f120: 9101b14a    	add	x10, x10, #0x6c
10153f124: a900a909    	stp	x9, x10, [x8, #0x8]
10153f128: 52800529    	mov	w9, #0x29               ; =41
10153f12c: f9000d09    	str	x9, [x8, #0x18]
10153f130: 911d03ff    	add	sp, sp, #0x740
10153f134: a9457bfd    	ldp	x29, x30, [sp, #0x50]
10153f138: a9444ff4    	ldp	x20, x19, [sp, #0x40]
10153f13c: a94357f6    	ldp	x22, x21, [sp, #0x30]
10153f140: a9425ff8    	ldp	x24, x23, [sp, #0x20]
10153f144: a94167fa    	ldp	x26, x25, [sp, #0x10]
10153f148: a8c66ffc    	ldp	x28, x27, [sp], #0x60
10153f14c: d65f03c0    	ret
10153f150: d1005ec9    	sub	x9, x22, #0x17
10153f154: f100113f    	cmp	x9, #0x4
10153f158: 540017e2    	b.hs	0x10153f454 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5f8>
10153f15c: b1005c5f    	cmn	x2, #0x17
10153f160: 5400076c    	b.gt	0x10153f24c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3f0>
10153f164: b100605f    	cmn	x2, #0x18
10153f168: 54002040    	b.eq	0x10153f570 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x714>
10153f16c: b1005c5f    	cmn	x2, #0x17
10153f170: 54001f21    	b.ne	0x10153f554 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6f8>
10153f174: f9407c09    	ldr	x9, [x0, #0xf8]
10153f178: f100093f    	cmp	x9, #0x2
10153f17c: 54002b01    	b.ne	0x10153f6dc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x880>
10153f180: b900011f    	str	wzr, [x8]
10153f184: 52800189    	mov	w9, #0xc                ; =12
10153f188: f000d7aa    	adrp	x10, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
10153f18c: 912d814a    	add	x10, x10, #0xb60
10153f190: 14000147    	b	0x10153f6ac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x850>
10153f194: a945af8a    	ldp	x10, x11, [x28, #0x58]
10153f198: d1006156    	sub	x22, x10, #0x18
10153f19c: d37be96a    	lsl	x10, x11, #5
10153f1a0: b400132a    	cbz	x10, 0x10153f404 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5a8>
10153f1a4: f9400ecb    	ldr	x11, [x22, #0x18]
10153f1a8: 910082d6    	add	x22, x22, #0x20
10153f1ac: d100814a    	sub	x10, x10, #0x20
10153f1b0: eb01017f    	cmp	x11, x1
10153f1b4: 54ffff61    	b.ne	0x10153f1a0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x344>
10153f1b8: b94002ca    	ldr	w10, [x22]
10153f1bc: 7100155f    	cmp	w10, #0x5
10153f1c0: 540027c0    	b.eq	0x10153f6b8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x85c>
10153f1c4: 7100195f    	cmp	w10, #0x6
10153f1c8: 540011e1    	b.ne	0x10153f404 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5a8>
10153f1cc: 52800115    	mov	w21, #0x8               ; =8
10153f1d0: 1400013b    	b	0x10153f6bc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x860>
10153f1d4: f9425c09    	ldr	x9, [x0, #0x4b8]
10153f1d8: d37bfd2a    	lsr	x10, x9, #59
10153f1dc: b50093ea    	cbnz	x10, 0x101540458 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x15fc>
10153f1e0: 9280040a    	mov	x10, #-0x21             ; =-33
10153f1e4: f2e0ffea    	movk	x10, #0x7ff, lsl #48
10153f1e8: eb0a013f    	cmp	x9, x10
10153f1ec: 54009368    	b.hi	0x101540458 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x15fc>
10153f1f0: aa0203f8    	mov	x24, x2
10153f1f4: aa0303f5    	mov	x21, x3
10153f1f8: aa0103f3    	mov	x19, x1
10153f1fc: aa0803f7    	mov	x23, x8
10153f200: aa0003f4    	mov	x20, x0
10153f204: f9424819    	ldr	x25, [x0, #0x490]
10153f208: d37be928    	lsl	x8, x9, #5
10153f20c: 927ae508    	and	x8, x8, #0xffffffffffffffc0
10153f210: 91100116    	add	x22, x8, #0x400
10153f214: f9418b28    	ldr	x8, [x25, #0x310]
10153f218: b4002028    	cbz	x8, 0x10153f61c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7c0>
10153f21c: f9418722    	ldr	x2, [x25, #0x308]
10153f220: 911343e8    	add	x8, sp, #0x4d0
10153f224: 910c4320    	add	x0, x25, #0x310
10153f228: aa1603e1    	mov	x1, x22
10153f22c: 94376ef4    	bl	0x10231adfc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>
10153f230: 395343e8    	ldrb	w8, [sp, #0x4d0]
10153f234: 7100211f    	cmp	w8, #0x8
10153f238: 54002021    	b.ne	0x10153f63c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7e0>
10153f23c: aa1403e0    	mov	x0, x20
10153f240: aa1303e1    	mov	x1, x19
10153f244: aa1803ea    	mov	x10, x24
10153f248: 14000264    	b	0x10153fbd8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd7c>
10153f24c: b100585f    	cmn	x2, #0x16
10153f250: 54001a40    	b.eq	0x10153f598 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x73c>
10153f254: b100545f    	cmn	x2, #0x15
10153f258: 540017e1    	b.ne	0x10153f554 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6f8>
10153f25c: f9424c09    	ldr	x9, [x0, #0x498]
10153f260: f9030be9    	str	x9, [sp, #0x610]
10153f264: f940087c    	ldr	x28, [x3, #0x10]
10153f268: f942c52a    	ldr	x10, [x9, #0x588]
10153f26c: eb0a039f    	cmp	x28, x10
10153f270: 54002822    	b.hs	0x10153f774 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x918>
10153f274: f942c129    	ldr	x9, [x9, #0x580]
10153f278: 52800b0a    	mov	w10, #0x58              ; =88
10153f27c: 9b0a2796    	madd	x22, x28, x10, x9
10153f280: b9403ec9    	ldr	w9, [x22, #0x3c]
10153f284: eb09003f    	cmp	x1, x9
10153f288: 54002de1    	b.ne	0x10153f844 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9e8>
10153f28c: f9424815    	ldr	x21, [x0, #0x490]
10153f290: b942f2a9    	ldr	w9, [x21, #0x2f0]
10153f294: 7100053f    	cmp	w9, #0x1
10153f298: 54002d61    	b.ne	0x10153f844 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9e8>
10153f29c: b942f6a9    	ldr	w9, [x21, #0x2f4]
10153f2a0: 6b01013f    	cmp	w9, w1
10153f2a4: 54002d01    	b.ne	0x10153f844 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9e8>
10153f2a8: b942eaa9    	ldr	w9, [x21, #0x2e8]
10153f2ac: 7100053f    	cmp	w9, #0x1
10153f2b0: 54002ca1    	b.ne	0x10153f844 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9e8>
10153f2b4: b94036c9    	ldr	w9, [x22, #0x34]
10153f2b8: b942eeaa    	ldr	w10, [x21, #0x2ec]
10153f2bc: 6b09015f    	cmp	w10, w9
10153f2c0: 54002c21    	b.ne	0x10153f844 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9e8>
10153f2c4: 395182aa    	ldrb	w10, [x21, #0x460]
10153f2c8: 7100055f    	cmp	w10, #0x1
10153f2cc: 54002bc1    	b.ne	0x10153f844 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9e8>
10153f2d0: a90503e8    	stp	x8, x0, [sp, #0x50]
10153f2d4: f9407c08    	ldr	x8, [x0, #0xf8]
10153f2d8: f100091f    	cmp	x8, #0x2
10153f2dc: 54007ae1    	b.ne	0x101540238 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13dc>
10153f2e0: f9402fe8    	ldr	x8, [sp, #0x58]
10153f2e4: 39542108    	ldrb	w8, [x8, #0x508]
10153f2e8: 37007a88    	tbnz	w8, #0x0, 0x101540238 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13dc>
10153f2ec: d37ff920    	lsl	x0, x9, #1
10153f2f0: f9402fe8    	ldr	x8, [sp, #0x58]
10153f2f4: f9425d01    	ldr	x1, [x8, #0x4b8]
10153f2f8: eb01001f    	cmp	x0, x1
10153f2fc: 54019582    	b.hs	0x1015425ac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3750>
10153f300: f9402fe8    	ldr	x8, [sp, #0x58]
10153f304: f9425909    	ldr	x9, [x8, #0x4b0]
10153f308: f8607933    	ldr	x19, [x9, x0, lsl #3]
10153f30c: f941e108    	ldr	x8, [x8, #0x3c0]
10153f310: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10153f314: eb09011f    	cmp	x8, x9
10153f318: 54008e81    	b.ne	0x1015404e8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x168c>
10153f31c: aa0303f7    	mov	x23, x3
10153f320: 94618214    	bl	0x102d9fb70 <__RNvNtNtCsgirOGyZpP7g_3std6thread9functions21available_parallelism>
10153f324: f100041f    	cmp	x0, #0x1
10153f328: 54000081    	b.ne	0x10153f338 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4dc>
10153f32c: aa0103e0    	mov	x0, x1
10153f330: 97ff82f7    	bl	0x10151ff0c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultINtNtNtB4_3num7nonzero7NonZerojENtNtNtCsgirOGyZpP7g_3std2io5error5ErrorEECs29QkOtpKx6e_8mech_gpu>
10153f334: 52800021    	mov	w1, #0x1                ; =1
10153f338: 52800408    	mov	w8, #0x20               ; =32
10153f33c: f100803f    	cmp	x1, #0x20
10153f340: 9a883034    	csel	x20, x1, x8, lo
10153f344: d1000668    	sub	x8, x19, #0x1
10153f348: eb14011f    	cmp	x8, x20
10153f34c: 54007762    	b.hs	0x101540238 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13dc>
10153f350: f94016c8    	ldr	x8, [x22, #0x28]
10153f354: f90027e8    	str	x8, [sp, #0x48]
10153f358: eb14011f    	cmp	x8, x20
10153f35c: 540076e8    	b.hi	0x101540238 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13dc>
10153f360: f94012c8    	ldr	x8, [x22, #0x20]
10153f364: f90023e8    	str	x8, [sp, #0x40]
10153f368: 911343e8    	add	x8, sp, #0x4d0
10153f36c: 910ee2a0    	add	x0, x21, #0x3b8
10153f370: 94376ccd    	bl	0x10231a6a4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
10153f374: f9426be8    	ldr	x8, [sp, #0x4d0]
10153f378: f100051f    	cmp	x8, #0x1
10153f37c: 540075e1    	b.ne	0x101540238 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13dc>
10153f380: f9426fe8    	ldr	x8, [sp, #0x4d8]
10153f384: b40075a8    	cbz	x8, 0x101540238 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13dc>
10153f388: f94002e8    	ldr	x8, [x23]
10153f38c: f9001fe8    	str	x8, [sp, #0x38]
10153f390: b400bae8    	cbz	x8, 0x101540aec <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c90>
10153f394: f94006e8    	ldr	x8, [x23, #0x8]
10153f398: b400baa8    	cbz	x8, 0x101540aec <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c90>
10153f39c: aa0803f7    	mov	x23, x8
10153f3a0: f9401d09    	ldr	x9, [x8, #0x38]
10153f3a4: f9402fe8    	ldr	x8, [sp, #0x58]
10153f3a8: eb08013f    	cmp	x9, x8
10153f3ac: 540001c1    	b.ne	0x10153f3e4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x588>
10153f3b0: f94002e8    	ldr	x8, [x23]
10153f3b4: f100951f    	cmp	x8, #0x25
10153f3b8: 54000161    	b.ne	0x10153f3e4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x588>
10153f3bc: f9400ae8    	ldr	x8, [x23, #0x10]
10153f3c0: f9430be9    	ldr	x9, [sp, #0x610]
10153f3c4: f941ad29    	ldr	x9, [x9, #0x358]
10153f3c8: eb09011f    	cmp	x8, x9
10153f3cc: 540000c3    	b.lo	0x10153f3e4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x588>
10153f3d0: f94016e8    	ldr	x8, [x23, #0x28]
10153f3d4: b4000088    	cbz	x8, 0x10153f3e4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x588>
10153f3d8: f9403ae8    	ldr	x8, [x23, #0x70]
10153f3dc: f100111f    	cmp	x8, #0x4
10153f3e0: 540119a1    	b.ne	0x101541714 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x28b8>
10153f3e4: f9402be8    	ldr	x8, [sp, #0x50]
10153f3e8: b900011f    	str	wzr, [x8]
10153f3ec: 52800189    	mov	w9, #0xc                ; =12
10153f3f0: 39002109    	strb	w9, [x8, #0x8]
10153f3f4: f000d7a9    	adrp	x9, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
10153f3f8: 9127c929    	add	x9, x9, #0x9f2
10153f3fc: 5280050a    	mov	w10, #0x28              ; =40
10153f400: 17fffeba    	b	0x10153eee8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10153f404: b900011f    	str	wzr, [x8]
10153f408: 52800189    	mov	w9, #0xc                ; =12
10153f40c: 39002109    	strb	w9, [x8, #0x8]
10153f410: b000d7a9    	adrp	x9, 0x103034000 <_anon.369b439a638cb010e9292f03e79ebf78.107+0xf6b>
10153f414: 913f2129    	add	x9, x9, #0xfc8
10153f418: 14000102    	b	0x10153f820 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9c4>
10153f41c: aa0203f3    	mov	x19, x2
10153f420: aa0303f7    	mov	x23, x3
10153f424: f10052df    	cmp	x22, #0x14
10153f428: 54000501    	b.ne	0x10153f4c8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x66c>
10153f42c: f9424809    	ldr	x9, [x0, #0x490]
10153f430: f9424c0a    	ldr	x10, [x0, #0x498]
10153f434: aa0003f8    	mov	x24, x0
10153f438: aa0903e0    	mov	x0, x9
10153f43c: aa0103f4    	mov	x20, x1
10153f440: aa0a03e1    	mov	x1, x10
10153f444: aa1403e2    	mov	x2, x20
10153f448: aa0803f9    	mov	x25, x8
10153f44c: 940045a4    	bl	0x101550adc <__RNvMs_NtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation20retained_native_call>
10153f450: 1400000e    	b	0x10153f488 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x62c>
10153f454: aa0203f3    	mov	x19, x2
10153f458: aa0303f7    	mov	x23, x3
10153f45c: f1005adf    	cmp	x22, #0x16
10153f460: 54000341    	b.ne	0x10153f4c8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x66c>
10153f464: f9424809    	ldr	x9, [x0, #0x490]
10153f468: f9424c0a    	ldr	x10, [x0, #0x498]
10153f46c: aa0003f8    	mov	x24, x0
10153f470: aa0903e0    	mov	x0, x9
10153f474: aa0103f4    	mov	x20, x1
10153f478: aa0a03e1    	mov	x1, x10
10153f47c: aa1403e2    	mov	x2, x20
10153f480: aa0803f9    	mov	x25, x8
10153f484: 97ffec93    	bl	0x10153a6d0 <__RNvMNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtB8_10invocation10Invocation20retained_native_span>
10153f488: aa1403e1    	mov	x1, x20
10153f48c: aa1903e8    	mov	x8, x25
10153f490: aa0003e9    	mov	x9, x0
10153f494: aa1803e0    	mov	x0, x24
10153f498: 36000189    	tbz	w9, #0x0, 0x10153f4c8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x66c>
10153f49c: aa0803f4    	mov	x20, x8
10153f4a0: 911343e8    	add	x8, sp, #0x4d0
10153f4a4: aa0003f8    	mov	x24, x0
10153f4a8: aa0103f9    	mov	x25, x1
10153f4ac: 97fffade    	bl	0x10153e024 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit>
10153f4b0: b944d3e8    	ldr	w8, [sp, #0x4d0]
10153f4b4: 7100191f    	cmp	w8, #0x6
10153f4b8: 54000d81    	b.ne	0x10153f668 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x80c>
10153f4bc: aa1403e8    	mov	x8, x20
10153f4c0: aa1803e0    	mov	x0, x24
10153f4c4: aa1903e1    	mov	x1, x25
10153f4c8: f9424809    	ldr	x9, [x0, #0x490]
10153f4cc: b942f12a    	ldr	w10, [x9, #0x2f0]
10153f4d0: 3600034a    	tbz	w10, #0x0, 0x10153f538 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6dc>
10153f4d4: b942f52a    	ldr	w10, [x9, #0x2f4]
10153f4d8: eb0a003f    	cmp	x1, x10
10153f4dc: 540002e1    	b.ne	0x10153f538 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6dc>
10153f4e0: aa1703e3    	mov	x3, x23
10153f4e4: f9424c17    	ldr	x23, [x0, #0x498]
10153f4e8: aa0103f4    	mov	x20, x1
10153f4ec: aa0003f9    	mov	x25, x0
10153f4f0: f1006adf    	cmp	x22, #0x1a
10153f4f4: 54002a2c    	b.gt	0x10153fa38 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xbdc>
10153f4f8: d1004eca    	sub	x10, x22, #0x13
10153f4fc: f100115f    	cmp	x10, #0x4
10153f500: 540040e2    	b.hs	0x10153fd1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xec0>
10153f504: aa0803e0    	mov	x0, x8
10153f508: aa1903e1    	mov	x1, x25
10153f50c: aa1403e2    	mov	x2, x20
10153f510: aa0303e4    	mov	x4, x3
10153f514: aa1303e3    	mov	x3, x19
10153f518: 911d03ff    	add	sp, sp, #0x740
10153f51c: a9457bfd    	ldp	x29, x30, [sp, #0x50]
10153f520: a9444ff4    	ldp	x20, x19, [sp, #0x40]
10153f524: a94357f6    	ldp	x22, x21, [sp, #0x30]
10153f528: a9425ff8    	ldp	x24, x23, [sp, #0x20]
10153f52c: a94167fa    	ldp	x26, x25, [sp, #0x10]
10153f530: a8c66ffc    	ldp	x28, x27, [sp], #0x60
10153f534: 14003ed1    	b	0x10154f078 <__RNvMs_NtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation19retained_map_helper>
10153f538: b900011f    	str	wzr, [x8]
10153f53c: 52800189    	mov	w9, #0xc                ; =12
10153f540: 39002109    	strb	w9, [x8, #0x8]
10153f544: f000d7a9    	adrp	x9, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
10153f548: 911fbd29    	add	x9, x9, #0x7ef
10153f54c: 5280046a    	mov	w10, #0x23              ; =35
10153f550: 17fffe66    	b	0x10153eee8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10153f554: b900011f    	str	wzr, [x8]
10153f558: 52800189    	mov	w9, #0xc                ; =12
10153f55c: 39002109    	strb	w9, [x8, #0x8]
10153f560: f000d7a9    	adrp	x9, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
10153f564: 9130a929    	add	x9, x9, #0xc2a
10153f568: 5280040a    	mov	w10, #0x20              ; =32
10153f56c: 17fffe5f    	b	0x10153eee8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10153f570: f9407c09    	ldr	x9, [x0, #0xf8]
10153f574: f100093f    	cmp	x9, #0x2
10153f578: 540010c1    	b.ne	0x10153f790 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x934>
10153f57c: b900011f    	str	wzr, [x8]
10153f580: 52800189    	mov	w9, #0xc                ; =12
10153f584: b000d7aa    	adrp	x10, 0x103034000 <_anon.369b439a638cb010e9292f03e79ebf78.107+0xf6b>
10153f588: 91000d4a    	add	x10, x10, #0x3
10153f58c: a900a909    	stp	x9, x10, [x8, #0x8]
10153f590: 528004c9    	mov	w9, #0x26               ; =38
10153f594: 17fffee6    	b	0x10153f12c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
10153f598: f940006d    	ldr	x13, [x3]
10153f59c: f9424c1a    	ldr	x26, [x0, #0x498]
10153f5a0: f942c749    	ldr	x9, [x26, #0x588]
10153f5a4: eb0901bf    	cmp	x13, x9
10153f5a8: 54001402    	b.hs	0x10153f828 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9cc>
10153f5ac: a940a46a    	ldp	x10, x9, [x3, #0x8]
10153f5b0: aa090149    	orr	x9, x10, x9
10153f5b4: b5001569    	cbnz	x9, 0x10153f860 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa04>
10153f5b8: f942c349    	ldr	x9, [x26, #0x580]
10153f5bc: 52800b0a    	mov	w10, #0x58              ; =88
10153f5c0: 9b0a25b6    	madd	x22, x13, x10, x9
10153f5c4: b94046c9    	ldr	w9, [x22, #0x44]
10153f5c8: eb09003f    	cmp	x1, x9
10153f5cc: 540014a1    	b.ne	0x10153f860 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa04>
10153f5d0: f9424814    	ldr	x20, [x0, #0x490]
10153f5d4: b942f289    	ldr	w9, [x20, #0x2f0]
10153f5d8: 7100053f    	cmp	w9, #0x1
10153f5dc: 54001421    	b.ne	0x10153f860 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa04>
10153f5e0: b942f689    	ldr	w9, [x20, #0x2f4]
10153f5e4: 6b01013f    	cmp	w9, w1
10153f5e8: 540013c1    	b.ne	0x10153f860 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa04>
10153f5ec: 39518289    	ldrb	w9, [x20, #0x460]
10153f5f0: 7100053f    	cmp	w9, #0x1
10153f5f4: 54001361    	b.ne	0x10153f860 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa04>
10153f5f8: aa0803f3    	mov	x19, x8
10153f5fc: f941e008    	ldr	x8, [x0, #0x3c0]
10153f600: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10153f604: eb09011f    	cmp	x8, x9
10153f608: 54005b01    	b.ne	0x101540168 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x130c>
10153f60c: f000d5e8    	adrp	x8, 0x102ffe000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x1d3>
10153f610: 3dc04d00    	ldr	q0, [x8, #0x130]
10153f614: 3c808260    	stur	q0, [x19, #0x8]
10153f618: 1400033a    	b	0x101540300 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14a4>
10153f61c: 94376bff    	bl	0x10231a618 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope>
10153f620: 360012e0    	tbz	w0, #0x0, 0x10153f87c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa20>
10153f624: 5280000b    	mov	w11, #0x0               ; =0
10153f628: 5280000a    	mov	w10, #0x0               ; =0
10153f62c: d2800008    	mov	x8, #0x0                ; =0
10153f630: 528000ed    	mov	w13, #0x7               ; =7
10153f634: aa1703ec    	mov	x12, x23
10153f638: 140000f1    	b	0x10153f9fc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xba0>
10153f63c: f9426be8    	ldr	x8, [sp, #0x4d0]
10153f640: f9426fee    	ldr	x14, [sp, #0x4d8]
10153f644: f94273e9    	ldr	x9, [sp, #0x4e0]
10153f648: 92403d0a    	and	x10, x8, #0xffff
10153f64c: f118195f    	cmp	x10, #0x606
10153f650: aa1703ec    	mov	x12, x23
10153f654: 54001c81    	b.ne	0x10153f9e4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xb88>
10153f658: 5280000a    	mov	w10, #0x0               ; =0
10153f65c: 528000cd    	mov	w13, #0x6               ; =6
10153f660: aa0e03e8    	mov	x8, x14
10153f664: 140000e6    	b	0x10153f9fc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xba0>
10153f668: 3dc13fe0    	ldr	q0, [sp, #0x4f0]
10153f66c: 3dc143e1    	ldr	q1, [sp, #0x500]
10153f670: ad010680    	stp	q0, q1, [x20, #0x20]
10153f674: 3dc147e0    	ldr	q0, [sp, #0x510]
10153f678: 3d801280    	str	q0, [x20, #0x40]
10153f67c: 3dc13be0    	ldr	q0, [sp, #0x4e0]
10153f680: 3dc137e1    	ldr	q1, [sp, #0x4d0]
10153f684: ad000281    	stp	q1, q0, [x20]
10153f688: 17fffeaa    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10153f68c: aa1703ee    	mov	x14, x23
10153f690: f84b0dcd    	ldr	x13, [x14, #0xb0]!
10153f694: eb0c01bf    	cmp	x13, x12
10153f698: 54001f21    	b.ne	0x10153fa7c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc20>
10153f69c: b900011f    	str	wzr, [x8]
10153f6a0: 52800189    	mov	w9, #0xc                ; =12
10153f6a4: f000d78a    	adrp	x10, 0x103032000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.241+0x21>
10153f6a8: 913cb94a    	add	x10, x10, #0xf2e
10153f6ac: a900a909    	stp	x9, x10, [x8, #0x8]
10153f6b0: 52800429    	mov	w9, #0x21               ; =33
10153f6b4: 17fffe9e    	b	0x10153f12c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
10153f6b8: 52800215    	mov	w21, #0x10              ; =16
10153f6bc: f940086a    	ldr	x10, [x3, #0x10]
10153f6c0: b4000f4a    	cbz	x10, 0x10153f8a8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa4c>
10153f6c4: b900011f    	str	wzr, [x8]
10153f6c8: 52800189    	mov	w9, #0xc                ; =12
10153f6cc: 39002109    	strb	w9, [x8, #0x8]
10153f6d0: b000d7a9    	adrp	x9, 0x103034000 <_anon.369b439a638cb010e9292f03e79ebf78.107+0xf6b>
10153f6d4: 913e6929    	add	x9, x9, #0xf9a
10153f6d8: 14000052    	b	0x10153f820 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9c4>
10153f6dc: f9424c17    	ldr	x23, [x0, #0x498]
10153f6e0: f942c6eb    	ldr	x11, [x23, #0x588]
10153f6e4: f940e00a    	ldr	x10, [x0, #0x1c0]
10153f6e8: eb0b015f    	cmp	x10, x11
10153f6ec: 54002522    	b.hs	0x10153fb90 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd34>
10153f6f0: f9424815    	ldr	x21, [x0, #0x490]
10153f6f4: b942f2ab    	ldr	w11, [x21, #0x2f0]
10153f6f8: 7100057f    	cmp	w11, #0x1
10153f6fc: 54003441    	b.ne	0x10153fd84 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf28>
10153f700: f940046b    	ldr	x11, [x3, #0x8]
10153f704: eb0a017f    	cmp	x11, x10
10153f708: 540081c1    	b.ne	0x101540740 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18e4>
10153f70c: f940086b    	ldr	x11, [x3, #0x10]
10153f710: b500818b    	cbnz	x11, 0x101540740 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18e4>
10153f714: b5008169    	cbnz	x9, 0x101540740 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18e4>
10153f718: f942c2e9    	ldr	x9, [x23, #0x580]
10153f71c: 52800b0b    	mov	w11, #0x58              ; =88
10153f720: 9b0b2558    	madd	x24, x10, x11, x9
10153f724: b9404b1a    	ldr	w26, [x24, #0x48]
10153f728: eb1a003f    	cmp	x1, x26
10153f72c: 540080a1    	b.ne	0x101540740 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18e4>
10153f730: b942eaa9    	ldr	w9, [x21, #0x2e8]
10153f734: 36008069    	tbz	w9, #0x0, 0x101540740 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18e4>
10153f738: b9403709    	ldr	w9, [x24, #0x34]
10153f73c: b942eeaa    	ldr	w10, [x21, #0x2ec]
10153f740: 6b09015f    	cmp	w10, w9
10153f744: 54007fe1    	b.ne	0x101540740 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18e4>
10153f748: f9400f09    	ldr	x9, [x24, #0x18]
10153f74c: b4007fa9    	cbz	x9, 0x101540740 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18e4>
10153f750: aa0303f9    	mov	x25, x3
10153f754: aa0003f4    	mov	x20, x0
10153f758: aa0803f6    	mov	x22, x8
10153f75c: b942f6b3    	ldr	w19, [x21, #0x2f4]
10153f760: f9400b08    	ldr	x8, [x24, #0x10]
10153f764: f100053f    	cmp	x9, #0x1
10153f768: 54006101    	b.ne	0x101540388 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x152c>
10153f76c: d280000a    	mov	x10, #0x0               ; =0
10153f770: 1400030f    	b	0x1015403ac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1550>
10153f774: b900011f    	str	wzr, [x8]
10153f778: 52800189    	mov	w9, #0xc                ; =12
10153f77c: 9000d7aa    	adrp	x10, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
10153f780: 9136314a    	add	x10, x10, #0xd8c
10153f784: a900a909    	stp	x9, x10, [x8, #0x8]
10153f788: 52800449    	mov	w9, #0x22               ; =34
10153f78c: 17fffe68    	b	0x10153f12c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
10153f790: f9424c0b    	ldr	x11, [x0, #0x498]
10153f794: f942c56c    	ldr	x12, [x11, #0x588]
10153f798: f940e00a    	ldr	x10, [x0, #0x1c0]
10153f79c: eb0c015f    	cmp	x10, x12
10153f7a0: 54002062    	b.hs	0x10153fbac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd50>
10153f7a4: f942c16b    	ldr	x11, [x11, #0x580]
10153f7a8: 52800b0c    	mov	w12, #0x58              ; =88
10153f7ac: 9b0c2d4b    	madd	x11, x10, x12, x11
10153f7b0: b940396b    	ldr	w11, [x11, #0x38]
10153f7b4: eb0b003f    	cmp	x1, x11
10153f7b8: 540002a1    	b.ne	0x10153f80c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9b0>
10153f7bc: 9107200b    	add	x11, x0, #0x1c8
10153f7c0: 3dc00160    	ldr	q0, [x11]
10153f7c4: 3c808360    	stur	q0, [x27, #0x8]
10153f7c8: a940306b    	ldp	x11, x12, [x3]
10153f7cc: f940086d    	ldr	x13, [x3, #0x10]
10153f7d0: f9426fee    	ldr	x14, [sp, #0x4d8]
10153f7d4: f94273ef    	ldr	x15, [sp, #0x4e0]
10153f7d8: eb0a017f    	cmp	x11, x10
10153f7dc: fa4e0180    	ccmp	x12, x14, #0x0, eq
10153f7e0: fa4f01a0    	ccmp	x13, x15, #0x0, eq
10153f7e4: 1a9f07ea    	cset	w10, ne
10153f7e8: b5000129    	cbnz	x9, 0x10153f80c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9b0>
10153f7ec: 3500010a    	cbnz	w10, 0x10153f80c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9b0>
10153f7f0: f9424809    	ldr	x9, [x0, #0x490]
10153f7f4: b942f12a    	ldr	w10, [x9, #0x2f0]
10153f7f8: 350000aa    	cbnz	w10, 0x10153f80c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9b0>
10153f7fc: b942e92a    	ldr	w10, [x9, #0x2e8]
10153f800: 3500006a    	cbnz	w10, 0x10153f80c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9b0>
10153f804: 394ce12a    	ldrb	w10, [x9, #0x338]
10153f808: 360056aa    	tbz	w10, #0x0, 0x1015402dc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1480>
10153f80c: b900011f    	str	wzr, [x8]
10153f810: 52800189    	mov	w9, #0xc                ; =12
10153f814: 39002109    	strb	w9, [x8, #0x8]
10153f818: f000d7a9    	adrp	x9, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
10153f81c: 912ff129    	add	x9, x9, #0xbfc
10153f820: 528005ca    	mov	w10, #0x2e              ; =46
10153f824: 17fffdb1    	b	0x10153eee8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10153f828: b900011f    	str	wzr, [x8]
10153f82c: 52800189    	mov	w9, #0xc                ; =12
10153f830: f000d7aa    	adrp	x10, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
10153f834: 9129414a    	add	x10, x10, #0xa50
10153f838: a900a909    	stp	x9, x10, [x8, #0x8]
10153f83c: 52800289    	mov	w9, #0x14               ; =20
10153f840: 17fffe3b    	b	0x10153f12c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
10153f844: b900011f    	str	wzr, [x8]
10153f848: 52800189    	mov	w9, #0xc                ; =12
10153f84c: 39002109    	strb	w9, [x8, #0x8]
10153f850: f000d7a9    	adrp	x9, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
10153f854: 91286929    	add	x9, x9, #0xa1a
10153f858: 528006ca    	mov	w10, #0x36              ; =54
10153f85c: 17fffda3    	b	0x10153eee8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10153f860: b900011f    	str	wzr, [x8]
10153f864: 52800189    	mov	w9, #0xc                ; =12
10153f868: 39002109    	strb	w9, [x8, #0x8]
10153f86c: f000d7a9    	adrp	x9, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
10153f870: 912ce929    	add	x9, x9, #0xb3a
10153f874: 528004ca    	mov	w10, #0x26              ; =38
10153f878: 17fffd9c    	b	0x10153eee8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10153f87c: f9418328    	ldr	x8, [x25, #0x300]
10153f880: f9418729    	ldr	x9, [x25, #0x308]
10153f884: ab160108    	adds	x8, x8, x22
10153f888: 54008482    	b.hs	0x101540918 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1abc>
10153f88c: eb09011f    	cmp	x8, x9
10153f890: 540019c9    	b.ls	0x10153fbc8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd6c>
10153f894: aa1703ec    	mov	x12, x23
10153f898: 5280000b    	mov	w11, #0x0               ; =0
10153f89c: 5280000a    	mov	w10, #0x0               ; =0
10153f8a0: 528000cd    	mov	w13, #0x6               ; =6
10153f8a4: 14000056    	b	0x10153f9fc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xba0>
10153f8a8: f942480a    	ldr	x10, [x0, #0x490]
10153f8ac: f941e14a    	ldr	x10, [x10, #0x3c0]
10153f8b0: b4000b6a    	cbz	x10, 0x10153fa1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xbc0>
10153f8b4: f940214b    	ldr	x11, [x10, #0x40]
10153f8b8: f100097f    	cmp	x11, #0x2
10153f8bc: 54000b00    	b.eq	0x10153fa1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xbc0>
10153f8c0: f9406d4b    	ldr	x11, [x10, #0xd8]
10153f8c4: eb09017f    	cmp	x11, x9
10153f8c8: 54000aa1    	b.ne	0x10153fa1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xbc0>
10153f8cc: f8756acb    	ldr	x11, [x22, x21]
10153f8d0: f9403d4c    	ldr	x12, [x10, #0x78]
10153f8d4: eb0c017f    	cmp	x11, x12
10153f8d8: 54000a22    	b.hs	0x10153fa1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xbc0>
10153f8dc: f940394a    	ldr	x10, [x10, #0x70]
10153f8e0: 5280210c    	mov	w12, #0x108             ; =264
10153f8e4: 9b0c7d6b    	mul	x11, x11, x12
10153f8e8: f86b694a    	ldr	x10, [x10, x11]
10153f8ec: b5ffeeca    	cbnz	x10, 0x10153f6c4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x868>
10153f8f0: a904a7e1    	stp	x1, x9, [sp, #0x48]
10153f8f4: aa0803f4    	mov	x20, x8
10153f8f8: f9426808    	ldr	x8, [x0, #0x4d0]
10153f8fc: b4003e48    	cbz	x8, 0x1015400c4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1268>
10153f900: f940578a    	ldr	x10, [x28, #0xa8]
10153f904: 91000949    	add	x9, x10, #0x2
10153f908: f9426c0b    	ldr	x11, [x0, #0x4d8]
10153f90c: eb0b013f    	cmp	x9, x11
10153f910: 54003da2    	b.hs	0x1015400c4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1268>
10153f914: f9002fe0    	str	x0, [sp, #0x58]
10153f918: 91000d4a    	add	x10, x10, #0x3
10153f91c: eb0b015f    	cmp	x10, x11
10153f920: 54003d22    	b.hs	0x1015400c4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1268>
10153f924: f8697909    	ldr	x9, [x8, x9, lsl #3]
10153f928: f86a7908    	ldr	x8, [x8, x10, lsl #3]
10153f92c: a903a3e9    	stp	x9, x8, [sp, #0x38]
10153f930: 3dc00060    	ldr	q0, [x3]
10153f934: 3d8093e0    	str	q0, [sp, #0x240]
10153f938: 528000a8    	mov	w8, #0x5                ; =5
10153f93c: f9012be8    	str	x8, [sp, #0x250]
10153f940: 911343e0    	add	x0, sp, #0x4d0
10153f944: 910903e3    	add	x3, sp, #0x240
10153f948: f9402fe1    	ldr	x1, [sp, #0x58]
10153f94c: f94027e2    	ldr	x2, [sp, #0x48]
10153f950: 97ffc833    	bl	0x101531a1c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation15end_closed_tail>
10153f954: b944d3e8    	ldr	w8, [sp, #0x4d0]
10153f958: 7100191f    	cmp	w8, #0x6
10153f95c: 54006361    	b.ne	0x1015405c8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x176c>
10153f960: f941bee1    	ldr	x1, [x23, #0x378]
10153f964: f94027e8    	ldr	x8, [sp, #0x48]
10153f968: eb01011f    	cmp	x8, x1
10153f96c: 54016662    	b.hs	0x101542638 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x37dc>
10153f970: f941bae9    	ldr	x9, [x23, #0x370]
10153f974: 52802e0a    	mov	w10, #0x170             ; =368
10153f978: f94027e8    	ldr	x8, [sp, #0x48]
10153f97c: 9b0a2508    	madd	x8, x8, x10, x9
10153f980: a9402508    	ldp	x8, x9, [x8]
10153f984: f100091f    	cmp	x8, #0x2
10153f988: fa1f013f    	sbcs	xzr, x9, xzr
10153f98c: 54006bc2    	b.hs	0x101540704 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18a8>
10153f990: f94202e1    	ldr	x1, [x23, #0x400]
10153f994: f94027e8    	ldr	x8, [sp, #0x48]
10153f998: eb01011f    	cmp	x8, x1
10153f99c: 54016562    	b.hs	0x101542648 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x37ec>
10153f9a0: f941fee9    	ldr	x9, [x23, #0x3f8]
10153f9a4: 52803e0a    	mov	w10, #0x1f0             ; =496
10153f9a8: f94027e8    	ldr	x8, [sp, #0x48]
10153f9ac: 9b0a2509    	madd	x9, x8, x10, x9
10153f9b0: f9001be9    	str	x9, [sp, #0x30]
10153f9b4: a9402129    	ldp	x9, x8, [x9]
10153f9b8: d27f0129    	eor	x9, x9, #0x2
10153f9bc: aa080128    	orr	x8, x9, x8
10153f9c0: b5006ce8    	cbnz	x8, 0x10154075c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1900>
10153f9c4: b900029f    	str	wzr, [x20]
10153f9c8: 52800188    	mov	w8, #0xc                ; =12
10153f9cc: f000d789    	adrp	x9, 0x103032000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.241+0x21>
10153f9d0: 9136c129    	add	x9, x9, #0xdb0
10153f9d4: a900a688    	stp	x8, x9, [x20, #0x8]
10153f9d8: 52800468    	mov	w8, #0x23               ; =35
10153f9dc: f9000e88    	str	x8, [x20, #0x18]
10153f9e0: 17fffdd4    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10153f9e4: aa0903ea    	mov	x10, x9
10153f9e8: d360fd2b    	lsr	x11, x9, #32
10153f9ec: 3cc18360    	ldur	q0, [x27, #0x18]
10153f9f0: 3c9903a0    	stur	q0, [x29, #-0x70]
10153f9f4: 528000ed    	mov	w13, #0x7               ; =7
10153f9f8: aa0e03e9    	mov	x9, x14
10153f9fc: b900019f    	str	wzr, [x12]
10153fa00: 3900218d    	strb	w13, [x12, #0x8]
10153fa04: a9012588    	stp	x8, x9, [x12, #0x10]
10153fa08: 29042d8a    	stp	w10, w11, [x12, #0x20]
10153fa0c: 3cd903a0    	ldur	q0, [x29, #-0x70]
10153fa10: 3c828180    	stur	q0, [x12, #0x28]
10153fa14: b900399f    	str	wzr, [x12, #0x38]
10153fa18: 17fffdc6    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10153fa1c: b900011f    	str	wzr, [x8]
10153fa20: 52800189    	mov	w9, #0xc                ; =12
10153fa24: b000d7aa    	adrp	x10, 0x103034000 <_anon.369b439a638cb010e9292f03e79ebf78.107+0xf6b>
10153fa28: 9119654a    	add	x10, x10, #0x659
10153fa2c: a900a909    	stp	x9, x10, [x8, #0x8]
10153fa30: 52800569    	mov	w9, #0x2b               ; =43
10153fa34: 17fffdbe    	b	0x10153f12c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
10153fa38: d1006eca    	sub	x10, x22, #0x1b
10153fa3c: f100095f    	cmp	x10, #0x2
10153fa40: 54001882    	b.hs	0x10153fd50 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xef4>
10153fa44: a9409865    	ldp	x5, x6, [x3, #0x8]
10153fa48: f9400064    	ldr	x4, [x3]
10153fa4c: aa0803e0    	mov	x0, x8
10153fa50: aa1903e1    	mov	x1, x25
10153fa54: aa1403e2    	mov	x2, x20
10153fa58: aa1303e3    	mov	x3, x19
10153fa5c: 911d03ff    	add	sp, sp, #0x740
10153fa60: a9457bfd    	ldp	x29, x30, [sp, #0x50]
10153fa64: a9444ff4    	ldp	x20, x19, [sp, #0x40]
10153fa68: a94357f6    	ldp	x22, x21, [sp, #0x30]
10153fa6c: a9425ff8    	ldp	x24, x23, [sp, #0x20]
10153fa70: a94167fa    	ldp	x26, x25, [sp, #0x10]
10153fa74: a8c66ffc    	ldp	x28, x27, [sp], #0x60
10153fa78: 17fff483    	b	0x10153cc84 <__RNvMNtNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime4maps5owner6frozen16frozen_map_callsNtNtBa_10invocation10Invocation17frozen_map_helper>
10153fa7c: b50007ca    	cbnz	x10, 0x10153fb74 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd18>
10153fa80: f942480c    	ldr	x12, [x0, #0x490]
10153fa84: b942f18a    	ldr	w10, [x12, #0x2f0]
10153fa88: 7100055f    	cmp	w10, #0x1
10153fa8c: 54000741    	b.ne	0x10153fb74 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd18>
10153fa90: b942f58a    	ldr	w10, [x12, #0x2f4]
10153fa94: 6b09015f    	cmp	w10, w9
10153fa98: 540006e1    	b.ne	0x10153fb74 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd18>
10153fa9c: b942e989    	ldr	w9, [x12, #0x2e8]
10153faa0: 7100053f    	cmp	w9, #0x1
10153faa4: 54000681    	b.ne	0x10153fb74 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd18>
10153faa8: b9403169    	ldr	w9, [x11, #0x30]
10153faac: b942ed8a    	ldr	w10, [x12, #0x2ec]
10153fab0: 6b09015f    	cmp	w10, w9
10153fab4: 54000601    	b.ne	0x10153fb74 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd18>
10153fab8: a903b3ee    	stp	x14, x12, [sp, #0x38]
10153fabc: a904a3e1    	stp	x1, x8, [sp, #0x48]
10153fac0: 52800028    	mov	w8, #0x1                ; =1
10153fac4: aa090508    	orr	x8, x8, x9, lsl #1
10153fac8: f9002fe0    	str	x0, [sp, #0x58]
10153facc: f9425c01    	ldr	x1, [x0, #0x4b8]
10153fad0: eb01011f    	cmp	x8, x1
10153fad4: 540155c2    	b.hs	0x10154258c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3730>
10153fad8: f9402fe9    	ldr	x9, [sp, #0x58]
10153fadc: f9425929    	ldr	x9, [x9, #0x4b0]
10153fae0: f8687928    	ldr	x8, [x9, x8, lsl #3]
10153fae4: f100051f    	cmp	x8, #0x1
10153fae8: f9402be8    	ldr	x8, [sp, #0x50]
10153faec: f94023e9    	ldr	x9, [sp, #0x40]
10153faf0: 54000421    	b.ne	0x10153fb74 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd18>
10153faf4: 910ee120    	add	x0, x9, #0x3b8
10153faf8: 94376dd3    	bl	0x10231b244 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget4used>
10153fafc: f94023e9    	ldr	x9, [sp, #0x40]
10153fb00: f9402be8    	ldr	x8, [sp, #0x50]
10153fb04: eb1a001f    	cmp	x0, x26
10153fb08: 54000361    	b.ne	0x10153fb74 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd18>
10153fb0c: eb13003f    	cmp	x1, x19
10153fb10: 54000321    	b.ne	0x10153fb74 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd18>
10153fb14: 911343e8    	add	x8, sp, #0x4d0
10153fb18: 910ee120    	add	x0, x9, #0x3b8
10153fb1c: 94376ae2    	bl	0x10231a6a4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
10153fb20: f9402be8    	ldr	x8, [sp, #0x50]
10153fb24: f9426be9    	ldr	x9, [sp, #0x4d0]
10153fb28: f100053f    	cmp	x9, #0x1
10153fb2c: 54000241    	b.ne	0x10153fb74 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd18>
10153fb30: f9426fe9    	ldr	x9, [sp, #0x4d8]
10153fb34: eb16013f    	cmp	x9, x22
10153fb38: 540001e1    	b.ne	0x10153fb74 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd18>
10153fb3c: f94273e9    	ldr	x9, [sp, #0x4e0]
10153fb40: eb19013f    	cmp	x9, x25
10153fb44: 54000181    	b.ne	0x10153fb74 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd18>
10153fb48: b4007134    	cbz	x20, 0x10154096c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b10>
10153fb4c: f1000a9f    	cmp	x20, #0x2
10153fb50: 54006f00    	b.eq	0x101540930 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ad4>
10153fb54: f1000e9f    	cmp	x20, #0x3
10153fb58: 54006fa1    	b.ne	0x10154094c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1af0>
10153fb5c: b5006f9c    	cbnz	x28, 0x10154094c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1af0>
10153fb60: a9408ae1    	ldp	x1, x2, [x23, #0x8]
10153fb64: f94027e0    	ldr	x0, [sp, #0x48]
10153fb68: 94004e2d    	bl	0x10155341c <__RNvXsC_NtNtCsgDHHaSskbIF_4core5slice3cmpmNtB5_13SliceContains14slice_contains>
10153fb6c: 37006ec0    	tbnz	w0, #0x0, 0x101540944 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ae8>
10153fb70: 14000377    	b	0x10154094c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1af0>
10153fb74: b900011f    	str	wzr, [x8]
10153fb78: 52800189    	mov	w9, #0xc                ; =12
10153fb7c: 39002109    	strb	w9, [x8, #0x8]
10153fb80: d000d7a9    	adrp	x9, 0x103035000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x4a0>
10153fb84: 9109ed29    	add	x9, x9, #0x27b
10153fb88: 528007ca    	mov	w10, #0x3e              ; =62
10153fb8c: 17fffcd7    	b	0x10153eee8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10153fb90: b900011f    	str	wzr, [x8]
10153fb94: 52800189    	mov	w9, #0xc                ; =12
10153fb98: f000d7aa    	adrp	x10, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
10153fb9c: 912e054a    	add	x10, x10, #0xb81
10153fba0: a900a909    	stp	x9, x10, [x8, #0x8]
10153fba4: 52800269    	mov	w9, #0x13               ; =19
10153fba8: 17fffd61    	b	0x10153f12c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
10153fbac: b900011f    	str	wzr, [x8]
10153fbb0: 52800189    	mov	w9, #0xc                ; =12
10153fbb4: b000d7aa    	adrp	x10, 0x103034000 <_anon.369b439a638cb010e9292f03e79ebf78.107+0xf6b>
10153fbb8: 9100a54a    	add	x10, x10, #0x29
10153fbbc: a900a909    	stp	x9, x10, [x8, #0x8]
10153fbc0: 52800329    	mov	w9, #0x19               ; =25
10153fbc4: 17fffd5a    	b	0x10153f12c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
10153fbc8: aa1403e0    	mov	x0, x20
10153fbcc: aa1303e1    	mov	x1, x19
10153fbd0: aa1803ea    	mov	x10, x24
10153fbd4: f9018328    	str	x8, [x25, #0x300]
10153fbd8: 911343e8    	add	x8, sp, #0x4d0
10153fbdc: b100355f    	cmn	x10, #0xd
10153fbe0: 54000101    	b.ne	0x10153fc00 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xda4>
10153fbe4: 94001fe9    	bl	0x101547b88 <__RNvMs1_NtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation6prefixNtB7_10Invocation17check_prefix_exit>
10153fbe8: b944d3e8    	ldr	w8, [sp, #0x4d0]
10153fbec: 7100191f    	cmp	w8, #0x6
10153fbf0: 54000221    	b.ne	0x10153fc34 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xdd8>
10153fbf4: aa1703e8    	mov	x8, x23
10153fbf8: aa1803e9    	mov	x9, x24
10153fbfc: 14000017    	b	0x10153fc58 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xdfc>
10153fc00: 9400203b    	bl	0x101547cec <__RNvMs1_NtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation6prefixNtB7_10Invocation19check_prefix_header>
10153fc04: b944d3e8    	ldr	w8, [sp, #0x4d0]
10153fc08: 7100191f    	cmp	w8, #0x6
10153fc0c: 54000141    	b.ne	0x10153fc34 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xdd8>
10153fc10: aa1803e9    	mov	x9, x24
10153fc14: b1002b1f    	cmn	x24, #0xa
10153fc18: aa1703e8    	mov	x8, x23
10153fc1c: 540001e1    	b.ne	0x10153fc58 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xdfc>
10153fc20: aa1403e1    	mov	x1, x20
10153fc24: f940568a    	ldr	x10, [x20, #0xa8]
10153fc28: aa1503e3    	mov	x3, x21
10153fc2c: b50006aa    	cbnz	x10, 0x10153fd00 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xea4>
10153fc30: 14000013    	b	0x10153fc7c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe20>
10153fc34: 3dc13fe0    	ldr	q0, [sp, #0x4f0]
10153fc38: 3dc143e1    	ldr	q1, [sp, #0x500]
10153fc3c: ad0106e0    	stp	q0, q1, [x23, #0x20]
10153fc40: 3dc147e0    	ldr	q0, [sp, #0x510]
10153fc44: 3d8012e0    	str	q0, [x23, #0x40]
10153fc48: 3dc13be0    	ldr	q0, [sp, #0x4e0]
10153fc4c: 3dc137e1    	ldr	q1, [sp, #0x4d0]
10153fc50: ad0002e1    	stp	q1, q0, [x23]
10153fc54: 17fffd37    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10153fc58: aa1503e3    	mov	x3, x21
10153fc5c: a9402eaa    	ldp	x10, x11, [x21]
10153fc60: f9400aac    	ldr	x12, [x21, #0x10]
10153fc64: aa0b014a    	orr	x10, x10, x11
10153fc68: aa1403e1    	mov	x1, x20
10153fc6c: f940568b    	ldr	x11, [x20, #0xa8]
10153fc70: aa0b018b    	orr	x11, x12, x11
10153fc74: aa0b014a    	orr	x10, x10, x11
10153fc78: b500044a    	cbnz	x10, 0x10153fd00 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xea4>
10153fc7c: f941482a    	ldr	x10, [x1, #0x290]
10153fc80: f100195f    	cmp	x10, #0x6
10153fc84: 540003e1    	b.ne	0x10153fd00 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xea4>
10153fc88: f9424c2a    	ldr	x10, [x1, #0x498]
10153fc8c: f940014b    	ldr	x11, [x10]
10153fc90: f100097f    	cmp	x11, #0x2
10153fc94: 54007b80    	b.eq	0x101540c04 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1da8>
10153fc98: 9108e038    	add	x24, x1, #0x238
10153fc9c: f940030b    	ldr	x11, [x24]
10153fca0: f1000d7f    	cmp	x11, #0x3
10153fca4: 54007b60    	b.eq	0x101540c10 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1db4>
10153fca8: f9409d56    	ldr	x22, [x10, #0x138]
10153fcac: b942802b    	ldr	w11, [x1, #0x280]
10153fcb0: b100313f    	cmn	x9, #0xc
10153fcb4: 54000c4c    	b.gt	0x10153fe3c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfe0>
10153fcb8: b100353f    	cmn	x9, #0xd
10153fcbc: 54001520    	b.eq	0x10153ff60 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1104>
10153fcc0: b100313f    	cmn	x9, #0xc
10153fcc4: 54001401    	b.ne	0x10153ff44 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x10e8>
10153fcc8: aa1303e9    	mov	x9, x19
10153fccc: 6b09017f    	cmp	w11, w9
10153fcd0: 540000a1    	b.ne	0x10153fce4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe88>
10153fcd4: 394a202b    	ldrb	w11, [x1, #0x288]
10153fcd8: 3600006b    	tbz	w11, #0x0, 0x10153fce4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe88>
10153fcdc: 394a242b    	ldrb	w11, [x1, #0x289]
10153fce0: 3600212b    	tbz	w11, #0x0, 0x101540104 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x12a8>
10153fce4: b900011f    	str	wzr, [x8]
10153fce8: 52800189    	mov	w9, #0xc                ; =12
10153fcec: 39002109    	strb	w9, [x8, #0x8]
10153fcf0: f000d7a9    	adrp	x9, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
10153fcf4: 913cb129    	add	x9, x9, #0xf2c
10153fcf8: 5280052a    	mov	w10, #0x29              ; =41
10153fcfc: 17fffc7b    	b	0x10153eee8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10153fd00: b900011f    	str	wzr, [x8]
10153fd04: 52800189    	mov	w9, #0xc                ; =12
10153fd08: 39002109    	strb	w9, [x8, #0x8]
10153fd0c: f000d7a9    	adrp	x9, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
10153fd10: 913dc529    	add	x9, x9, #0xf71
10153fd14: 5280048a    	mov	w10, #0x24              ; =36
10153fd18: 17fffc74    	b	0x10153eee8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10153fd1c: f1002adf    	cmp	x22, #0xa
10153fd20: 54000401    	b.ne	0x10153fda0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf44>
10153fd24: aa0803e0    	mov	x0, x8
10153fd28: aa1903e1    	mov	x1, x25
10153fd2c: aa1403e2    	mov	x2, x20
10153fd30: 911d03ff    	add	sp, sp, #0x740
10153fd34: a9457bfd    	ldp	x29, x30, [sp, #0x50]
10153fd38: a9444ff4    	ldp	x20, x19, [sp, #0x40]
10153fd3c: a94357f6    	ldp	x22, x21, [sp, #0x30]
10153fd40: a9425ff8    	ldp	x24, x23, [sp, #0x20]
10153fd44: a94167fa    	ldp	x26, x25, [sp, #0x10]
10153fd48: a8c66ffc    	ldp	x28, x27, [sp], #0x60
10153fd4c: 17ffc8c5    	b	0x101532060 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation17begin_closed_tail>
10153fd50: f1007adf    	cmp	x22, #0x1e
10153fd54: 54000261    	b.ne	0x10153fda0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf44>
10153fd58: aa0803e0    	mov	x0, x8
10153fd5c: aa1903e1    	mov	x1, x25
10153fd60: aa1403e2    	mov	x2, x20
10153fd64: 911d03ff    	add	sp, sp, #0x740
10153fd68: a9457bfd    	ldp	x29, x30, [sp, #0x50]
10153fd6c: a9444ff4    	ldp	x20, x19, [sp, #0x40]
10153fd70: a94357f6    	ldp	x22, x21, [sp, #0x30]
10153fd74: a9425ff8    	ldp	x24, x23, [sp, #0x20]
10153fd78: a94167fa    	ldp	x26, x25, [sp, #0x10]
10153fd7c: a8c66ffc    	ldp	x28, x27, [sp], #0x60
10153fd80: 17ffbc12    	b	0x10152edc8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16numeric_segmentsNtB4_10Invocation21begin_numeric_segment>
10153fd84: b900011f    	str	wzr, [x8]
10153fd88: 52800189    	mov	w9, #0xc                ; =12
10153fd8c: 39002109    	strb	w9, [x8, #0x8]
10153fd90: f000d7a9    	adrp	x9, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
10153fd94: 912e5129    	add	x9, x9, #0xb94
10153fd98: 5280030a    	mov	w10, #0x18              ; =24
10153fd9c: 17fffc53    	b	0x10153eee8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10153fda0: aa0303f8    	mov	x24, x3
10153fda4: aa0803f3    	mov	x19, x8
10153fda8: aa0903e0    	mov	x0, x9
10153fdac: aa1703e1    	mov	x1, x23
10153fdb0: aa1403e2    	mov	x2, x20
10153fdb4: 97fff449    	bl	0x10153ced8 <__RNvMNtNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime4maps5owner6frozen16frozen_map_callsNtNtBa_10invocation10Invocation20frozen_native_action>
10153fdb8: 37000320    	tbnz	w0, #0x0, 0x10153fe1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfc0>
10153fdbc: aa1903e8    	mov	x8, x25
10153fdc0: f9424b39    	ldr	x25, [x25, #0x490]
10153fdc4: f9002fe8    	str	x8, [sp, #0x58]
10153fdc8: f9424d1a    	ldr	x26, [x8, #0x498]
10153fdcc: aa1903e0    	mov	x0, x25
10153fdd0: aa1a03e1    	mov	x1, x26
10153fdd4: aa1403e2    	mov	x2, x20
10153fdd8: 94004375    	bl	0x101550bac <__RNvMs_NtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation22retained_native_action>
10153fddc: 37000200    	tbnz	w0, #0x0, 0x10153fe1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfc0>
10153fde0: aa1903e0    	mov	x0, x25
10153fde4: aa1a03e1    	mov	x1, x26
10153fde8: aa1403e2    	mov	x2, x20
10153fdec: 9400433c    	bl	0x101550adc <__RNvMs_NtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation20retained_native_call>
10153fdf0: 37000160    	tbnz	w0, #0x0, 0x10153fe1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfc0>
10153fdf4: aa1903e0    	mov	x0, x25
10153fdf8: aa1a03e1    	mov	x1, x26
10153fdfc: aa1403e2    	mov	x2, x20
10153fe00: 94004351    	bl	0x101550b44 <__RNvMs_NtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation20retained_native_exit>
10153fe04: 370000c0    	tbnz	w0, #0x0, 0x10153fe1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfc0>
10153fe08: aa1903e0    	mov	x0, x25
10153fe0c: aa1a03e1    	mov	x1, x26
10153fe10: aa1403e2    	mov	x2, x20
10153fe14: 97ffea2f    	bl	0x10153a6d0 <__RNvMNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtB8_10invocation10Invocation20retained_native_span>
10153fe18: 36002980    	tbz	w0, #0x0, 0x101540348 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14ec>
10153fe1c: b900027f    	str	wzr, [x19]
10153fe20: 52800188    	mov	w8, #0xc                ; =12
10153fe24: 39002268    	strb	w8, [x19, #0x8]
10153fe28: f000d7a8    	adrp	x8, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
10153fe2c: 911f1108    	add	x8, x8, #0x7c4
10153fe30: 52800569    	mov	w9, #0x2b               ; =43
10153fe34: a9012668    	stp	x8, x9, [x19, #0x10]
10153fe38: 17fffcbe    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10153fe3c: b1002d3f    	cmn	x9, #0xb
10153fe40: 54000e40    	b.eq	0x101540008 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x11ac>
10153fe44: b100293f    	cmn	x9, #0xa
10153fe48: 540007e1    	b.ne	0x10153ff44 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x10e8>
10153fe4c: 394a1035    	ldrb	w21, [x1, #0x284]
10153fe50: f9413c22    	ldr	x2, [x1, #0x278]
10153fe54: aa0103e8    	mov	x8, x1
10153fe58: 911343e0    	add	x0, sp, #0x4d0
10153fe5c: aa0303e1    	mov	x1, x3
10153fe60: 91094103    	add	x3, x8, #0x250
10153fe64: 9400335d    	bl	0x10154cbd8 <__RNvMs_NtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation6prefixNtB4_9Retention7checked>
10153fe68: b944d3e8    	ldr	w8, [sp, #0x4d0]
10153fe6c: 7100191f    	cmp	w8, #0x6
10153fe70: 540010e1    	b.ne	0x10154008c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1230>
10153fe74: f94277e8    	ldr	x8, [sp, #0x4e8]
10153fe78: 3cc08360    	ldur	q0, [x27, #0x8]
10153fe7c: 3d811be0    	str	q0, [sp, #0x460]
10153fe80: f9023be8    	str	x8, [sp, #0x470]
10153fe84: 37001315    	tbnz	w21, #0x0, 0x1015400e4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1288>
10153fe88: aa1403e8    	mov	x8, x20
10153fe8c: f9406289    	ldr	x9, [x20, #0xc0]
10153fe90: f100093f    	cmp	x9, #0x2
10153fe94: 54001281    	b.ne	0x1015400e4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1288>
10153fe98: f9411109    	ldr	x9, [x8, #0x220]
10153fe9c: f100093f    	cmp	x9, #0x2
10153fea0: 54001220    	b.eq	0x1015400e4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1288>
10153fea4: f940ed09    	ldr	x9, [x8, #0x1d8]
10153fea8: eb16013f    	cmp	x9, x22
10153feac: 540011c1    	b.ne	0x1015400e4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1288>
10153feb0: f9426d15    	ldr	x21, [x8, #0x4d8]
10153feb4: 92800808    	mov	x8, #-0x41              ; =-65
10153feb8: f2e1ffe8    	movk	x8, #0xfff, lsl #48
10153febc: eb0802bf    	cmp	x21, x8
10153fec0: 5400a308    	b.hi	0x101541320 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x24c4>
10153fec4: f9424a88    	ldr	x8, [x20, #0x490]
10153fec8: d37ceea9    	lsl	x9, x21, #4
10153fecc: 911343e0    	add	x0, sp, #0x4d0
10153fed0: 910be101    	add	x1, x8, #0x2f8
10153fed4: 91100122    	add	x2, x9, #0x400
10153fed8: 97ff99fe    	bl	0x1015266d0 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
10153fedc: 395343e8    	ldrb	w8, [sp, #0x4d0]
10153fee0: 7100391f    	cmp	w8, #0xe
10153fee4: 54001d21    	b.ne	0x101540288 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x142c>
10153fee8: b40000b5    	cbz	x21, 0x10153fefc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x10a0>
10153feec: f9426a80    	ldr	x0, [x20, #0x4d0]
10153fef0: b4003960    	cbz	x0, 0x10154061c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17c0>
10153fef4: d37df2a1    	lsl	x1, x21, #3
10153fef8: 9462d5ea    	bl	0x102df56a0 <dyld_stub_binder+0x102df56a0>
10153fefc: 91076280    	add	x0, x20, #0x1d8
10153ff00: 97ff8eff    	bl	0x101523afc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8borrowed5StateEBS_>
10153ff04: 52800048    	mov	w8, #0x2                ; =2
10153ff08: f9011288    	str	x8, [x20, #0x220]
10153ff0c: f9411e88    	ldr	x8, [x20, #0x238]
10153ff10: f1000d1f    	cmp	x8, #0x3
10153ff14: 5400fa00    	b.eq	0x101541e54 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2ff8>
10153ff18: 3dc11be0    	ldr	q0, [sp, #0x460]
10153ff1c: 3d800300    	str	q0, [x24]
10153ff20: f9423be8    	ldr	x8, [sp, #0x470]
10153ff24: f9000b08    	str	x8, [x24, #0x10]
10153ff28: f9400308    	ldr	x8, [x24]
10153ff2c: f1000d1f    	cmp	x8, #0x3
10153ff30: 5400f980    	b.eq	0x101541e60 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3004>
10153ff34: 52800028    	mov	w8, #0x1                ; =1
10153ff38: b9026a88    	str	w8, [x20, #0x268]
10153ff3c: b9026e93    	str	w19, [x20, #0x26c]
10153ff40: 14000030    	b	0x101540000 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x11a4>
10153ff44: b900011f    	str	wzr, [x8]
10153ff48: 52800189    	mov	w9, #0xc                ; =12
10153ff4c: 39002109    	strb	w9, [x8, #0x8]
10153ff50: f000d7a9    	adrp	x9, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
10153ff54: 913d5529    	add	x9, x9, #0xf55
10153ff58: 5280038a    	mov	w10, #0x1c              ; =28
10153ff5c: 17fffbe3    	b	0x10153eee8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10153ff60: b9427029    	ldr	w9, [x1, #0x270]
10153ff64: 350007a9    	cbnz	w9, 0x101540058 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x11fc>
10153ff68: f9406029    	ldr	x9, [x1, #0xc0]
10153ff6c: f100093f    	cmp	x9, #0x2
10153ff70: 54000741    	b.ne	0x101540058 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x11fc>
10153ff74: f9411029    	ldr	x9, [x1, #0x220]
10153ff78: f100093f    	cmp	x9, #0x2
10153ff7c: 540006e0    	b.eq	0x101540058 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x11fc>
10153ff80: f940ec29    	ldr	x9, [x1, #0x1d8]
10153ff84: eb16013f    	cmp	x9, x22
10153ff88: 54000681    	b.ne	0x101540058 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x11fc>
10153ff8c: f9426c35    	ldr	x21, [x1, #0x4d8]
10153ff90: 92800808    	mov	x8, #-0x41              ; =-65
10153ff94: f2e1ffe8    	movk	x8, #0xfff, lsl #48
10153ff98: eb0802bf    	cmp	x21, x8
10153ff9c: 54009c28    	b.hi	0x101541320 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x24c4>
10153ffa0: f9424a88    	ldr	x8, [x20, #0x490]
10153ffa4: d37ceea9    	lsl	x9, x21, #4
10153ffa8: 911343e0    	add	x0, sp, #0x4d0
10153ffac: 910be101    	add	x1, x8, #0x2f8
10153ffb0: 91100122    	add	x2, x9, #0x400
10153ffb4: 97ff99c7    	bl	0x1015266d0 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
10153ffb8: 395343e8    	ldrb	w8, [sp, #0x4d0]
10153ffbc: 7100391f    	cmp	w8, #0xe
10153ffc0: 54001641    	b.ne	0x101540288 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x142c>
10153ffc4: b40000b5    	cbz	x21, 0x10153ffd8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x117c>
10153ffc8: f9426a80    	ldr	x0, [x20, #0x4d0]
10153ffcc: b4003280    	cbz	x0, 0x10154061c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17c0>
10153ffd0: d37df2a1    	lsl	x1, x21, #3
10153ffd4: 9462d5b3    	bl	0x102df56a0 <dyld_stub_binder+0x102df56a0>
10153ffd8: 91076280    	add	x0, x20, #0x1d8
10153ffdc: 97ff8ec8    	bl	0x101523afc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8borrowed5StateEBS_>
10153ffe0: 52800048    	mov	w8, #0x2                ; =2
10153ffe4: f9011288    	str	x8, [x20, #0x220]
10153ffe8: f9411e88    	ldr	x8, [x20, #0x238]
10153ffec: f1000d1f    	cmp	x8, #0x3
10153fff0: 5400dca0    	b.eq	0x101541b84 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d28>
10153fff4: 52800028    	mov	w8, #0x1                ; =1
10153fff8: b9027288    	str	w8, [x20, #0x270]
10153fffc: b9027693    	str	w19, [x20, #0x274]
101540000: f90006ff    	str	xzr, [x23, #0x8]
101540004: 14000056    	b	0x10154015c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1300>
101540008: 6b13017f    	cmp	w11, w19
10154000c: 54000341    	b.ne	0x101540074 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1218>
101540010: 394a2029    	ldrb	w9, [x1, #0x288]
101540014: 37000309    	tbnz	w9, #0x0, 0x101540074 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1218>
101540018: 394a2429    	ldrb	w9, [x1, #0x289]
10154001c: 370002c9    	tbnz	w9, #0x0, 0x101540074 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1218>
101540020: 911343e0    	add	x0, sp, #0x4d0
101540024: aa1303e2    	mov	x2, x19
101540028: aa1603e4    	mov	x4, x22
10154002c: 97ffd269    	bl	0x1015349d0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation23prepare_borrowed_region>
101540030: b944d3e8    	ldr	w8, [sp, #0x4d0]
101540034: 7100191f    	cmp	w8, #0x6
101540038: 540010e1    	b.ne	0x101540254 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13f8>
10154003c: f9400308    	ldr	x8, [x24]
101540040: f1000d1f    	cmp	x8, #0x3
101540044: 5400bae0    	b.eq	0x1015417a0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2944>
101540048: 3cc08360    	ldur	q0, [x27, #0x8]
10154004c: 52800028    	mov	w8, #0x1                ; =1
101540050: 390a2288    	strb	w8, [x20, #0x288]
101540054: 14000041    	b	0x101540158 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x12fc>
101540058: b900011f    	str	wzr, [x8]
10154005c: 52800189    	mov	w9, #0xc                ; =12
101540060: 39002109    	strb	w9, [x8, #0x8]
101540064: d000d7a9    	adrp	x9, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
101540068: 913a7529    	add	x9, x9, #0xe9d
10154006c: 528005ea    	mov	w10, #0x2f              ; =47
101540070: 17fffb9e    	b	0x10153eee8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101540074: b900011f    	str	wzr, [x8]
101540078: 52800189    	mov	w9, #0xc                ; =12
10154007c: 39002109    	strb	w9, [x8, #0x8]
101540080: d000d7a9    	adrp	x9, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
101540084: 913bf929    	add	x9, x9, #0xefe
101540088: 17fffde6    	b	0x10153f820 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9c4>
10154008c: 3dc13be0    	ldr	q0, [sp, #0x4e0]
101540090: 3dc13fe1    	ldr	q1, [sp, #0x4f0]
101540094: 3c80c340    	stur	q0, [x26, #0xc]
101540098: 3cc04360    	ldur	q0, [x27, #0x4]
10154009c: 3d8093e0    	str	q0, [sp, #0x240]
1015400a0: 3dc143e0    	ldr	q0, [sp, #0x500]
1015400a4: 3dc147e2    	ldr	q2, [sp, #0x510]
1015400a8: ad018ae0    	stp	q0, q2, [x23, #0x30]
1015400ac: 3dc093e0    	ldr	q0, [sp, #0x240]
1015400b0: 3c8042e0    	stur	q0, [x23, #0x4]
1015400b4: 3cc0c340    	ldur	q0, [x26, #0xc]
1015400b8: ad0086e0    	stp	q0, q1, [x23, #0x10]
1015400bc: b90002e8    	str	w8, [x23]
1015400c0: 17fffc1c    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015400c4: b900029f    	str	wzr, [x20]
1015400c8: 52800188    	mov	w8, #0xc                ; =12
1015400cc: d000d789    	adrp	x9, 0x103032000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.241+0x21>
1015400d0: 913f2929    	add	x9, x9, #0xfca
1015400d4: a900a688    	stp	x8, x9, [x20, #0x8]
1015400d8: 52800608    	mov	w8, #0x30               ; =48
1015400dc: f9000e88    	str	x8, [x20, #0x18]
1015400e0: 17fffc14    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015400e4: b90002ff    	str	wzr, [x23]
1015400e8: 52800188    	mov	w8, #0xc                ; =12
1015400ec: 390022e8    	strb	w8, [x23, #0x8]
1015400f0: d000d7a8    	adrp	x8, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
1015400f4: 913b3108    	add	x8, x8, #0xecc
1015400f8: 52800649    	mov	w9, #0x32               ; =50
1015400fc: a90126e8    	stp	x8, x9, [x23, #0x10]
101540100: 17fffc0c    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101540104: f9413941    	ldr	x1, [x10, #0x270]
101540108: eb01013f    	cmp	x9, x1
10154010c: 54012482    	b.hs	0x10154259c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3740>
101540110: f9413548    	ldr	x8, [x10, #0x268]
101540114: 8b131108    	add	x8, x8, x19, lsl #4
101540118: b9400109    	ldr	w9, [x8]
10154011c: 36001069    	tbz	w9, #0x0, 0x101540328 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14cc>
101540120: f9400503    	ldr	x3, [x8, #0x8]
101540124: 911343e0    	add	x0, sp, #0x4d0
101540128: aa1403e1    	mov	x1, x20
10154012c: aa1503e2    	mov	x2, x21
101540130: 97ffc7e0    	bl	0x1015320b0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation19begin_closed_region>
101540134: b944d3e8    	ldr	w8, [sp, #0x4d0]
101540138: 7100191f    	cmp	w8, #0x6
10154013c: 540008c1    	b.ne	0x101540254 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13f8>
101540140: f9400308    	ldr	x8, [x24]
101540144: f1000d1f    	cmp	x8, #0x3
101540148: 5400d380    	b.eq	0x101541bb8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d5c>
10154014c: 3cc08360    	ldur	q0, [x27, #0x8]
101540150: 52800028    	mov	w8, #0x1                ; =1
101540154: 390a2688    	strb	w8, [x20, #0x289]
101540158: 3c8082e0    	stur	q0, [x23, #0x8]
10154015c: 528000c8    	mov	w8, #0x6                ; =6
101540160: b90002e8    	str	w8, [x23]
101540164: 17fffbf3    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101540168: aa0003f5    	mov	x21, x0
10154016c: f941ec09    	ldr	x9, [x0, #0x3d8]
101540170: b4001829    	cbz	x9, 0x101540474 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1618>
101540174: f941eaaa    	ldr	x10, [x21, #0x3d0]
101540178: eb08015f    	cmp	x10, x8
10154017c: 9a8833ec    	csel	x12, xzr, x8, lo
101540180: cb0c014c    	sub	x12, x10, x12
101540184: f941e6ab    	ldr	x11, [x21, #0x3c8]
101540188: 52800b0e    	mov	w14, #0x58              ; =88
10154018c: 9b0e2d8c    	madd	x12, x12, x14, x11
101540190: f940218e    	ldr	x14, [x12, #0x40]
101540194: eb0d01df    	cmp	x14, x13
101540198: 54000ba1    	b.ne	0x10154030c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14b0>
10154019c: b942ea8d    	ldr	w13, [x20, #0x2e8]
1015401a0: 710005bf    	cmp	w13, #0x1
1015401a4: 54000b41    	b.ne	0x10154030c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14b0>
1015401a8: b94036cd    	ldr	w13, [x22, #0x34]
1015401ac: b942ee8e    	ldr	w14, [x20, #0x2ec]
1015401b0: 6b0d01df    	cmp	w14, w13
1015401b4: 54000ac1    	b.ne	0x10154030c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14b0>
1015401b8: d37ff9a0    	lsl	x0, x13, #1
1015401bc: f9425ea1    	ldr	x1, [x21, #0x4b8]
1015401c0: eb01001f    	cmp	x0, x1
1015401c4: 54012742    	b.hs	0x1015426ac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3850>
1015401c8: f940298d    	ldr	x13, [x12, #0x50]
1015401cc: f9425aae    	ldr	x14, [x21, #0x4b0]
1015401d0: f86079ce    	ldr	x14, [x14, x0, lsl #3]
1015401d4: eb0e01ad    	subs	x13, x13, x14
1015401d8: 540009a3    	b.lo	0x10154030c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14b0>
1015401dc: f940258e    	ldr	x14, [x12, #0x48]
1015401e0: eb0e01bf    	cmp	x13, x14
1015401e4: 54000941    	b.ne	0x10154030c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14b0>
1015401e8: f941feb7    	ldr	x23, [x21, #0x3f8]
1015401ec: f941f6ad    	ldr	x13, [x21, #0x3e8]
1015401f0: eb1701bf    	cmp	x13, x23
1015401f4: 54000140    	b.eq	0x10154021c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c0>
1015401f8: 910321b9    	add	x25, x13, #0xc8
1015401fc: f901f6b9    	str	x25, [x21, #0x3e8]
101540200: f94001a1    	ldr	x1, [x13]
101540204: 294145a0    	ldp	w0, w17, [x13, #0x8]
101540208: 394041b0    	ldrb	w16, [x13, #0x10]
10154020c: a941b9af    	ldp	x15, x14, [x13, #0x18]
101540210: b4007441    	cbz	x1, 0x101541098 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x223c>
101540214: f100083f    	cmp	x1, #0x2
101540218: 54007be1    	b.ne	0x101541194 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2338>
10154021c: b900027f    	str	wzr, [x19]
101540220: 52800188    	mov	w8, #0xc                ; =12
101540224: 39002268    	strb	w8, [x19, #0x8]
101540228: d000d7a8    	adrp	x8, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
10154022c: 912a0508    	add	x8, x8, #0xa81
101540230: 528002c9    	mov	w9, #0x16               ; =22
101540234: 17ffff00    	b	0x10153fe34 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfd8>
101540238: d000d5e8    	adrp	x8, 0x102ffe000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x1d3>
10154023c: 3dc04d00    	ldr	q0, [x8, #0x130]
101540240: f9402be8    	ldr	x8, [sp, #0x50]
101540244: 3c808100    	stur	q0, [x8, #0x8]
101540248: 528000c9    	mov	w9, #0x6                ; =6
10154024c: b9000109    	str	w9, [x8]
101540250: 17fffbb8    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101540254: b944d7e9    	ldr	w9, [sp, #0x4d4]
101540258: 3cc18360    	ldur	q0, [x27, #0x18]
10154025c: 3c8182e0    	stur	q0, [x23, #0x18]
101540260: 3cc28360    	ldur	q0, [x27, #0x28]
101540264: 3c8282e0    	stur	q0, [x23, #0x28]
101540268: 3cc38360    	ldur	q0, [x27, #0x38]
10154026c: 3c8382e0    	stur	q0, [x23, #0x38]
101540270: f9428fea    	ldr	x10, [sp, #0x518]
101540274: f90026ea    	str	x10, [x23, #0x48]
101540278: 3cc08360    	ldur	q0, [x27, #0x8]
10154027c: 290026e8    	stp	w8, w9, [x23]
101540280: 3c8082e0    	stur	q0, [x23, #0x8]
101540284: 17fffbab    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101540288: 3dc137e0    	ldr	q0, [sp, #0x4d0]
10154028c: 3dc13be1    	ldr	q1, [sp, #0x4e0]
101540290: ad1207e0    	stp	q0, q1, [sp, #0x240]
101540294: 3dc13fe2    	ldr	q2, [sp, #0x4f0]
101540298: 3d809be2    	str	q2, [sp, #0x260]
10154029c: f94283e8    	ldr	x8, [sp, #0x500]
1015402a0: f9013be8    	str	x8, [sp, #0x270]
1015402a4: 3c804360    	stur	q0, [x27, #0x4]
1015402a8: 3c814361    	stur	q1, [x27, #0x14]
1015402ac: 3c824362    	stur	q2, [x27, #0x24]
1015402b0: f8034368    	stur	x8, [x27, #0x34]
1015402b4: b90002ff    	str	wzr, [x23]
1015402b8: 3dc137e0    	ldr	q0, [sp, #0x4d0]
1015402bc: 3dc13be1    	ldr	q1, [sp, #0x4e0]
1015402c0: 3c8042e0    	stur	q0, [x23, #0x4]
1015402c4: 3c8142e1    	stur	q1, [x23, #0x14]
1015402c8: 3dc13fe0    	ldr	q0, [sp, #0x4f0]
1015402cc: 3c8242e0    	stur	q0, [x23, #0x24]
1015402d0: 3cc2c360    	ldur	q0, [x27, #0x2c]
1015402d4: 3d800ee0    	str	q0, [x23, #0x30]
1015402d8: 17fffb96    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015402dc: aa0803f3    	mov	x19, x8
1015402e0: 911343e0    	add	x0, sp, #0x4d0
1015402e4: 910be121    	add	x1, x9, #0x2f8
1015402e8: 52802002    	mov	w2, #0x100              ; =256
1015402ec: 97ff98f9    	bl	0x1015266d0 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
1015402f0: 395343e8    	ldrb	w8, [sp, #0x4d0]
1015402f4: 7100391f    	cmp	w8, #0xe
1015402f8: 54000ce1    	b.ne	0x101540494 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1638>
1015402fc: f900067f    	str	xzr, [x19, #0x8]
101540300: 528000c8    	mov	w8, #0x6                ; =6
101540304: b9000268    	str	w8, [x19]
101540308: 17fffb8a    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154030c: b900027f    	str	wzr, [x19]
101540310: 52800188    	mov	w8, #0xc                ; =12
101540314: 39002268    	strb	w8, [x19, #0x8]
101540318: d000d7a8    	adrp	x8, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
10154031c: 912c1d08    	add	x8, x8, #0xb07
101540320: 52800669    	mov	w9, #0x33               ; =51
101540324: 17fffec4    	b	0x10153fe34 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfd8>
101540328: b90002ff    	str	wzr, [x23]
10154032c: 52800188    	mov	w8, #0xc                ; =12
101540330: 9000d7a9    	adrp	x9, 0x103034000 <_anon.369b439a638cb010e9292f03e79ebf78.107+0xf6b>
101540334: 910a5129    	add	x9, x9, #0x294
101540338: a900a6e8    	stp	x8, x9, [x23, #0x8]
10154033c: 528004c8    	mov	w8, #0x26               ; =38
101540340: f9000ee8    	str	x8, [x23, #0x18]
101540344: 17fffb7b    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101540348: f10026df    	cmp	x22, #0x9
10154034c: 54001ae0    	b.eq	0x1015406a8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x184c>
101540350: f10022df    	cmp	x22, #0x8
101540354: 54001c21    	b.ne	0x1015406d8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x187c>
101540358: aa1303e0    	mov	x0, x19
10154035c: f9402fe1    	ldr	x1, [sp, #0x58]
101540360: aa1403e2    	mov	x2, x20
101540364: aa1803e3    	mov	x3, x24
101540368: 911d03ff    	add	sp, sp, #0x740
10154036c: a9457bfd    	ldp	x29, x30, [sp, #0x50]
101540370: a9444ff4    	ldp	x20, x19, [sp, #0x40]
101540374: a94357f6    	ldp	x22, x21, [sp, #0x30]
101540378: a9425ff8    	ldp	x24, x23, [sp, #0x20]
10154037c: a94167fa    	ldp	x26, x25, [sp, #0x10]
101540380: a8c66ffc    	ldp	x28, x27, [sp], #0x60
101540384: 17ffd5f6    	b	0x101535b5c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation24prepare_borrowed_strings>
101540388: d280000a    	mov	x10, #0x0               ; =0
10154038c: d341fd2b    	lsr	x11, x9, #1
101540390: 8b0a016c    	add	x12, x11, x10
101540394: b86c790d    	ldr	w13, [x8, x12, lsl #2]
101540398: 6b1301bf    	cmp	w13, w19
10154039c: 9a8c814a    	csel	x10, x10, x12, hi
1015403a0: cb0b0129    	sub	x9, x9, x11
1015403a4: f100053f    	cmp	x9, #0x1
1015403a8: 54ffff28    	b.hi	0x10154038c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1530>
1015403ac: b86a7908    	ldr	w8, [x8, x10, lsl #2]
1015403b0: 6b13011f    	cmp	w8, w19
1015403b4: aa1603e8    	mov	x8, x22
1015403b8: 54001c41    	b.ne	0x101540740 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18e4>
1015403bc: f941bee1    	ldr	x1, [x23, #0x378]
1015403c0: eb13003f    	cmp	x1, x19
1015403c4: 54011209    	b.ls	0x101542604 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x37a8>
1015403c8: f941bae8    	ldr	x8, [x23, #0x370]
1015403cc: 52802e09    	mov	w9, #0x170              ; =368
1015403d0: 9ba92268    	umaddl	x8, w19, w9, x8
1015403d4: 91057109    	add	x9, x8, #0x15c
1015403d8: b9416d08    	ldr	w8, [x8, #0x16c]
1015403dc: b904e3e8    	str	w8, [sp, #0x4e0]
1015403e0: 3dc00120    	ldr	q0, [x9]
1015403e4: 3d8137e0    	str	q0, [sp, #0x4d0]
1015403e8: 910903e8    	add	x8, sp, #0x240
1015403ec: 911343e0    	add	x0, sp, #0x4d0
1015403f0: 944410b1    	bl	0x1026446b4 <__RNvMs1_NtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact16fusion_semantics5factsNtB5_18NativeProgramFacts18control_successors>
1015403f4: b94243e8    	ldr	w8, [sp, #0x240]
1015403f8: 7100051f    	cmp	w8, #0x1
1015403fc: 54000081    	b.ne	0x10154040c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x15b0>
101540400: b94247e8    	ldr	w8, [sp, #0x244]
101540404: 6b1a011f    	cmp	w8, w26
101540408: 540000e0    	b.eq	0x101540424 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x15c8>
10154040c: b9424be8    	ldr	w8, [sp, #0x248]
101540410: 7100051f    	cmp	w8, #0x1
101540414: 54001941    	b.ne	0x10154073c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18e0>
101540418: b9424fe8    	ldr	w8, [sp, #0x24c]
10154041c: 6b1a011f    	cmp	w8, w26
101540420: 540018e1    	b.ne	0x10154073c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18e0>
101540424: aa1403e0    	mov	x0, x20
101540428: aa1303e1    	mov	x1, x19
10154042c: 97fff419    	bl	0x10153d490 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation15action_required>
101540430: 34001040    	cbz	w0, 0x101540638 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17dc>
101540434: 395182a8    	ldrb	w8, [x21, #0x460]
101540438: 7100051f    	cmp	w8, #0x1
10154043c: aa1603e8    	mov	x8, x22
101540440: 54001801    	b.ne	0x101540740 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18e4>
101540444: aa1403e9    	mov	x9, x20
101540448: f940628a    	ldr	x10, [x20, #0xc0]
10154044c: f100095f    	cmp	x10, #0x2
101540450: 54000fe0    	b.eq	0x10154064c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17f0>
101540454: 140000bb    	b	0x101540740 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18e4>
101540458: b900011f    	str	wzr, [x8]
10154045c: 52800189    	mov	w9, #0xc                ; =12
101540460: f000d78a    	adrp	x10, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101540464: 9102554a    	add	x10, x10, #0x95
101540468: a900a909    	stp	x9, x10, [x8, #0x8]
10154046c: 52800349    	mov	w9, #0x1a               ; =26
101540470: 17fffb2f    	b	0x10153f12c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101540474: b900027f    	str	wzr, [x19]
101540478: 52800188    	mov	w8, #0xc                ; =12
10154047c: d000d7a9    	adrp	x9, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
101540480: 91299129    	add	x9, x9, #0xa64
101540484: a900a668    	stp	x8, x9, [x19, #0x8]
101540488: 528003a8    	mov	w8, #0x1d               ; =29
10154048c: f9000e68    	str	x8, [x19, #0x18]
101540490: 17fffb28    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101540494: 3dc137e0    	ldr	q0, [sp, #0x4d0]
101540498: 3dc13be1    	ldr	q1, [sp, #0x4e0]
10154049c: ad1207e0    	stp	q0, q1, [sp, #0x240]
1015404a0: 3dc13fe2    	ldr	q2, [sp, #0x4f0]
1015404a4: 3d809be2    	str	q2, [sp, #0x260]
1015404a8: f94283e8    	ldr	x8, [sp, #0x500]
1015404ac: f9013be8    	str	x8, [sp, #0x270]
1015404b0: 3c804360    	stur	q0, [x27, #0x4]
1015404b4: 3c814361    	stur	q1, [x27, #0x14]
1015404b8: 3c824362    	stur	q2, [x27, #0x24]
1015404bc: f8034368    	stur	x8, [x27, #0x34]
1015404c0: b900027f    	str	wzr, [x19]
1015404c4: 3dc137e0    	ldr	q0, [sp, #0x4d0]
1015404c8: 3dc13be1    	ldr	q1, [sp, #0x4e0]
1015404cc: 3c804260    	stur	q0, [x19, #0x4]
1015404d0: 3c814261    	stur	q1, [x19, #0x14]
1015404d4: 3dc13fe0    	ldr	q0, [sp, #0x4f0]
1015404d8: 3c824260    	stur	q0, [x19, #0x24]
1015404dc: 3cc2c360    	ldur	q0, [x27, #0x2c]
1015404e0: 3d800e60    	str	q0, [x19, #0x30]
1015404e4: 17fffb13    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015404e8: f9402fe9    	ldr	x9, [sp, #0x58]
1015404ec: f941ed29    	ldr	x9, [x9, #0x3d8]
1015404f0: b40011a9    	cbz	x9, 0x101540724 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18c8>
1015404f4: f9402fe9    	ldr	x9, [sp, #0x58]
1015404f8: f941e92a    	ldr	x10, [x9, #0x3d0]
1015404fc: eb08015f    	cmp	x10, x8
101540500: 9a8833e8    	csel	x8, xzr, x8, lo
101540504: cb080148    	sub	x8, x10, x8
101540508: f941e529    	ldr	x9, [x9, #0x3c8]
10154050c: 52800b0a    	mov	w10, #0x58              ; =88
101540510: 9b0a2514    	madd	x20, x8, x10, x9
101540514: f9402288    	ldr	x8, [x20, #0x40]
101540518: eb1c011f    	cmp	x8, x28
10154051c: 54000701    	b.ne	0x1015405fc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17a0>
101540520: f9402688    	ldr	x8, [x20, #0x48]
101540524: b50006c8    	cbnz	x8, 0x1015405fc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17a0>
101540528: f9402a88    	ldr	x8, [x20, #0x50]
10154052c: eb13011f    	cmp	x8, x19
101540530: 54000661    	b.ne	0x1015405fc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17a0>
101540534: b94052c1    	ldr	w1, [x22, #0x50]
101540538: 911343e8    	add	x8, sp, #0x4d0
10154053c: 9103c2a0    	add	x0, x21, #0xf0
101540540: 910be2a2    	add	x2, x21, #0x2f8
101540544: 9400153a    	bl	0x101545a2c <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
101540548: 3cc08360    	ldur	q0, [x27, #0x8]
10154054c: 3cc18361    	ldur	q1, [x27, #0x18]
101540550: ad1a87e0    	stp	q0, q1, [sp, #0x350]
101540554: 3cc28360    	ldur	q0, [x27, #0x28]
101540558: 3d80dfe0    	str	q0, [sp, #0x370]
10154055c: f9426be8    	ldr	x8, [sp, #0x4d0]
101540560: f94287e9    	ldr	x9, [sp, #0x508]
101540564: f901c3e9    	str	x9, [sp, #0x380]
101540568: b4003d88    	cbz	x8, 0x101540d18 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ebc>
10154056c: ad5a87e0    	ldp	q0, q1, [sp, #0x350]
101540570: 3c808340    	stur	q0, [x26, #0x8]
101540574: f941c3e9    	ldr	x9, [sp, #0x380]
101540578: 3dc0dfe0    	ldr	q0, [sp, #0x370]
10154057c: 3c828340    	stur	q0, [x26, #0x28]
101540580: 3c818341    	stur	q1, [x26, #0x18]
101540584: f9013fe9    	str	x9, [sp, #0x278]
101540588: f90123e8    	str	x8, [sp, #0x240]
10154058c: f94127e8    	ldr	x8, [sp, #0x248]
101540590: f9400689    	ldr	x9, [x20, #0x8]
101540594: f9400908    	ldr	x8, [x8, #0x10]
101540598: f9400929    	ldr	x9, [x9, #0x10]
10154059c: eb09011f    	cmp	x8, x9
1015405a0: 54004800    	b.eq	0x101540ea0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2044>
1015405a4: 52800008    	mov	w8, #0x0                ; =0
1015405a8: 52800189    	mov	w9, #0xc                ; =12
1015405ac: f9402bea    	ldr	x10, [sp, #0x50]
1015405b0: 39002149    	strb	w9, [x10, #0x8]
1015405b4: 528004e9    	mov	w9, #0x27               ; =39
1015405b8: f9000d49    	str	x9, [x10, #0x18]
1015405bc: d000d7a9    	adrp	x9, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
1015405c0: 91224529    	add	x9, x9, #0x891
1015405c4: 1400023c    	b	0x101540eb4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2058>
1015405c8: b944d7e9    	ldr	w9, [sp, #0x4d4]
1015405cc: 3cc88300    	ldur	q0, [x24, #0x88]
1015405d0: 3c818280    	stur	q0, [x20, #0x18]
1015405d4: 3cc98300    	ldur	q0, [x24, #0x98]
1015405d8: 3c828280    	stur	q0, [x20, #0x28]
1015405dc: 3cca8300    	ldur	q0, [x24, #0xa8]
1015405e0: 3c838280    	stur	q0, [x20, #0x38]
1015405e4: f9428fea    	ldr	x10, [sp, #0x518]
1015405e8: f900268a    	str	x10, [x20, #0x48]
1015405ec: 3cc78300    	ldur	q0, [x24, #0x78]
1015405f0: 29002688    	stp	w8, w9, [x20]
1015405f4: 3c808280    	stur	q0, [x20, #0x8]
1015405f8: 17ffface    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015405fc: f9402be8    	ldr	x8, [sp, #0x50]
101540600: b900011f    	str	wzr, [x8]
101540604: 52800189    	mov	w9, #0xc                ; =12
101540608: 39002109    	strb	w9, [x8, #0x8]
10154060c: d000d7a9    	adrp	x9, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
101540610: 9122e129    	add	x9, x9, #0x8b8
101540614: 528006ca    	mov	w10, #0x36              ; =54
101540618: 17fffa34    	b	0x10153eee8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10154061c: b90002ff    	str	wzr, [x23]
101540620: 52800188    	mov	w8, #0xc                ; =12
101540624: 390022e8    	strb	w8, [x23, #0x8]
101540628: b000d7a8    	adrp	x8, 0x103035000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x4a0>
10154062c: 910e9908    	add	x8, x8, #0x3a6
101540630: 52800529    	mov	w9, #0x29               ; =41
101540634: 17fffeb2    	b	0x1015400fc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x12a0>
101540638: aa1403e9    	mov	x9, x20
10154063c: f9406288    	ldr	x8, [x20, #0xc0]
101540640: f100091f    	cmp	x8, #0x2
101540644: aa1603e8    	mov	x8, x22
101540648: 540007c1    	b.ne	0x101540740 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18e4>
10154064c: f9411129    	ldr	x9, [x9, #0x220]
101540650: f100093f    	cmp	x9, #0x2
101540654: 54000761    	b.ne	0x101540740 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18e4>
101540658: f941aee8    	ldr	x8, [x23, #0x358]
10154065c: b9404f01    	ldr	w1, [x24, #0x4c]
101540660: eb01011f    	cmp	x8, x1
101540664: 540101a9    	b.ls	0x101542698 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x383c>
101540668: f941aae8    	ldr	x8, [x23, #0x350]
10154066c: 52802809    	mov	w9, #0x140              ; =320
101540670: 9ba92028    	umaddl	x8, w1, w9, x8
101540674: 39449109    	ldrb	w9, [x8, #0x124]
101540678: f9400328    	ldr	x8, [x25]
10154067c: 71001d3f    	cmp	w9, #0x7
101540680: 54001181    	b.ne	0x1015408b0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a54>
101540684: b4002448    	cbz	x8, 0x101540b0c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1cb0>
101540688: b90002df    	str	wzr, [x22]
10154068c: 52800188    	mov	w8, #0xc                ; =12
101540690: 390022c8    	strb	w8, [x22, #0x8]
101540694: d000d7a8    	adrp	x8, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
101540698: 912eb108    	add	x8, x8, #0xbac
10154069c: 52800509    	mov	w9, #0x28               ; =40
1015406a0: a90126c8    	stp	x8, x9, [x22, #0x10]
1015406a4: 17fffaa3    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015406a8: aa1303e0    	mov	x0, x19
1015406ac: f9402fe1    	ldr	x1, [sp, #0x58]
1015406b0: aa1403e2    	mov	x2, x20
1015406b4: aa1803e3    	mov	x3, x24
1015406b8: 911d03ff    	add	sp, sp, #0x740
1015406bc: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1015406c0: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1015406c4: a94357f6    	ldp	x22, x21, [sp, #0x30]
1015406c8: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1015406cc: a94167fa    	ldp	x26, x25, [sp, #0x10]
1015406d0: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1015406d4: 17ffcbbb    	b	0x1015335c0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation23borrowed_string_failure>
1015406d8: f9402fe0    	ldr	x0, [sp, #0x58]
1015406dc: aa1403e1    	mov	x1, x20
1015406e0: 97ffcb88    	bl	0x101533500 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation15borrowed_action>
1015406e4: b4000b00    	cbz	x0, 0x101540844 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x19e8>
1015406e8: b900027f    	str	wzr, [x19]
1015406ec: 52800188    	mov	w8, #0xc                ; =12
1015406f0: 39002268    	strb	w8, [x19, #0x8]
1015406f4: d000d7a8    	adrp	x8, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
1015406f8: 911a1d08    	add	x8, x8, #0x687
1015406fc: 528005c9    	mov	w9, #0x2e               ; =46
101540700: 17fffdcd    	b	0x10153fe34 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfd8>
101540704: b900029f    	str	wzr, [x20]
101540708: 52800188    	mov	w8, #0xc                ; =12
10154070c: 39002288    	strb	w8, [x20, #0x8]
101540710: 9000d7a8    	adrp	x8, 0x103034000 <_anon.369b439a638cb010e9292f03e79ebf78.107+0xf6b>
101540714: 913ddd08    	add	x8, x8, #0xf77
101540718: 52800469    	mov	w9, #0x23               ; =35
10154071c: a9012688    	stp	x8, x9, [x20, #0x10]
101540720: 17fffa84    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101540724: f9402be8    	ldr	x8, [sp, #0x50]
101540728: b900011f    	str	wzr, [x8]
10154072c: 52800189    	mov	w9, #0xc                ; =12
101540730: f000d78a    	adrp	x10, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101540734: 9132194a    	add	x10, x10, #0xc86
101540738: 17fffc40    	b	0x10153f838 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9dc>
10154073c: aa1603e8    	mov	x8, x22
101540740: b900011f    	str	wzr, [x8]
101540744: 52800189    	mov	w9, #0xc                ; =12
101540748: 39002109    	strb	w9, [x8, #0x8]
10154074c: d000d7a9    	adrp	x9, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
101540750: 912f5129    	add	x9, x9, #0xbd4
101540754: 5280050a    	mov	w10, #0x28              ; =40
101540758: 17fff9e4    	b	0x10153eee8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10154075c: f9402fe8    	ldr	x8, [sp, #0x58]
101540760: f9424908    	ldr	x8, [x8, #0x490]
101540764: 911343e0    	add	x0, sp, #0x4d0
101540768: 910be101    	add	x1, x8, #0x2f8
10154076c: 52800802    	mov	w2, #0x40               ; =64
101540770: 97ff97d8    	bl	0x1015266d0 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
101540774: 395343e8    	ldrb	w8, [sp, #0x4d0]
101540778: 7100391f    	cmp	w8, #0xe
10154077c: 54001361    	b.ne	0x1015409e8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b8c>
101540780: f8756ac0    	ldr	x0, [x22, x21]
101540784: f9401b88    	ldr	x8, [x28, #0x30]
101540788: f90017e8    	str	x8, [sp, #0x28]
10154078c: eb08001f    	cmp	x0, x8
101540790: 5400fb82    	b.hs	0x101542700 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x38a4>
101540794: f940178a    	ldr	x10, [x28, #0x28]
101540798: b940d383    	ldr	w3, [x28, #0xd0]
10154079c: f9402fe8    	ldr	x8, [sp, #0x58]
1015407a0: f9424908    	ldr	x8, [x8, #0x490]
1015407a4: 52800309    	mov	w9, #0x18               ; =24
1015407a8: 9b097c09    	mul	x9, x0, x9
1015407ac: f90013ea    	str	x10, [sp, #0x20]
1015407b0: f8696944    	ldr	x4, [x10, x9]
1015407b4: f941e101    	ldr	x1, [x8, #0x3c0]
1015407b8: 911343e0    	add	x0, sp, #0x4d0
1015407bc: 911202e2    	add	x2, x23, #0x480
1015407c0: 97ff9d8a    	bl	0x101527de8 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames18take_managed_owner>
1015407c4: b944d3e8    	ldr	w8, [sp, #0x4d0]
1015407c8: 7100191f    	cmp	w8, #0x6
1015407cc: 540016e1    	b.ne	0x101540aa8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c4c>
1015407d0: 3cc98300    	ldur	q0, [x24, #0x98]
1015407d4: 3c824340    	stur	q0, [x26, #0x24]
1015407d8: 3cca8301    	ldur	q1, [x24, #0xa8]
1015407dc: 3cc88302    	ldur	q2, [x24, #0x88]
1015407e0: 3cc78303    	ldur	q3, [x24, #0x78]
1015407e4: ad030be3    	stp	q3, q2, [sp, #0x60]
1015407e8: ad0407e0    	stp	q0, q1, [sp, #0x80]
1015407ec: 911343e8    	add	x8, sp, #0x4d0
1015407f0: f9402fe0    	ldr	x0, [sp, #0x58]
1015407f4: 52800001    	mov	w1, #0x0                ; =0
1015407f8: 94002ff8    	bl	0x10154c7d8 <__RNvMs_NtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
1015407fc: f9426be8    	ldr	x8, [sp, #0x4d0]
101540800: f100051f    	cmp	x8, #0x1
101540804: 540020c1    	b.ne	0x101540c1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1dc0>
101540808: 911343e8    	add	x8, sp, #0x4d0
10154080c: 3cc18100    	ldur	q0, [x8, #0x18]
101540810: 3cc28101    	ldur	q1, [x8, #0x28]
101540814: 3cc38102    	ldur	q2, [x8, #0x38]
101540818: ad130be1    	stp	q1, q2, [sp, #0x260]
10154081c: 3cc48103    	ldur	q3, [x8, #0x48]
101540820: 3d80a3e3    	str	q3, [sp, #0x280]
101540824: 3cc08104    	ldur	q4, [x8, #0x8]
101540828: ad1203e4    	stp	q4, q0, [sp, #0x240]
10154082c: ad010a81    	stp	q1, q2, [x20, #0x20]
101540830: 3d801283    	str	q3, [x20, #0x40]
101540834: ad000284    	stp	q4, q0, [x20]
101540838: 910183e0    	add	x0, sp, #0x60
10154083c: 97ff8550    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
101540840: 17fffa3c    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101540844: f942a2e8    	ldr	x8, [x23, #0x540]
101540848: eb08029f    	cmp	x20, x8
10154084c: 540000e2    	b.hs	0x101540868 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a0c>
101540850: f9429ee8    	ldr	x8, [x23, #0x538]
101540854: 52800509    	mov	w9, #0x28               ; =40
101540858: 9b097e89    	mul	x9, x20, x9
10154085c: b8696908    	ldr	w8, [x8, x9]
101540860: 7100151f    	cmp	w8, #0x5
101540864: 54001761    	b.ne	0x101540b50 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1cf4>
101540868: f1001adf    	cmp	x22, #0x6
10154086c: 54000f8c    	b.gt	0x101540a5c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c00>
101540870: f10012df    	cmp	x22, #0x4
101540874: 54002780    	b.eq	0x101540d64 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f08>
101540878: f10016df    	cmp	x22, #0x5
10154087c: 54002b80    	b.eq	0x101540dec <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f90>
101540880: f1001adf    	cmp	x22, #0x6
101540884: 54002a01    	b.ne	0x101540dc4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f68>
101540888: 3dc00300    	ldr	q0, [x24]
10154088c: 3d8137e0    	str	q0, [sp, #0x4d0]
101540890: f9400b08    	ldr	x8, [x24, #0x10]
101540894: f90273e8    	str	x8, [sp, #0x4e0]
101540898: 911343e3    	add	x3, sp, #0x4d0
10154089c: aa1303e0    	mov	x0, x19
1015408a0: f9402fe1    	ldr	x1, [sp, #0x58]
1015408a4: aa1403e2    	mov	x2, x20
1015408a8: 97ffdd0b    	bl	0x101537cd4 <__RNvMNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation6window10string_mapNtB6_10Invocation25prepare_string_map_region>
1015408ac: 17fffa21    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015408b0: d2800009    	mov	x9, #0x0                ; =0
1015408b4: f9419aaa    	ldr	x10, [x21, #0x330]
1015408b8: f941e6ab    	ldr	x11, [x21, #0x3c8]
1015408bc: f9421aac    	ldr	x12, [x21, #0x430]
1015408c0: ad5e86a0    	ldp	q0, q1, [x21, #0x3d0]
1015408c4: ad5f8ea2    	ldp	q2, q3, [x21, #0x3f0]
1015408c8: 3dc106a4    	ldr	q4, [x21, #0x410]
1015408cc: 3dc10aa5    	ldr	q5, [x21, #0x420]
1015408d0: 5280002d    	mov	w13, #0x1               ; =1
1015408d4: a90fa68d    	stp	x13, x9, [x20, #0xf8]
1015408d8: f9008688    	str	x8, [x20, #0x108]
1015408dc: ad489fe6    	ldp	q6, q7, [sp, #0x110]
1015408e0: ad089e86    	stp	q6, q7, [x20, #0x110]
1015408e4: 3dc04fe6    	ldr	q6, [sp, #0x130]
1015408e8: 3d804e86    	str	q6, [x20, #0x130]
1015408ec: a9142e8a    	stp	x10, x11, [x20, #0x140]
1015408f0: ad0a8680    	stp	q0, q1, [x20, #0x150]
1015408f4: ad0b8e82    	stp	q2, q3, [x20, #0x170]
1015408f8: ad0c9684    	stp	q4, q5, [x20, #0x190]
1015408fc: f900da8c    	str	x12, [x20, #0x1b0]
101540900: b901ba93    	str	w19, [x20, #0x1b8]
101540904: 4e080da0    	dup.2d	v0, x13
101540908: 3c8082c0    	stur	q0, [x22, #0x8]
10154090c: 528000c8    	mov	w8, #0x6                ; =6
101540910: b90002c8    	str	w8, [x22]
101540914: 17fffa07    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101540918: 5280000b    	mov	w11, #0x0               ; =0
10154091c: 5280000a    	mov	w10, #0x0               ; =0
101540920: 528000cd    	mov	w13, #0x6               ; =6
101540924: 92800008    	mov	x8, #-0x1               ; =-1
101540928: aa1703ec    	mov	x12, x23
10154092c: 17fffc34    	b	0x10153f9fc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xba0>
101540930: b50000fc    	cbnz	x28, 0x10154094c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1af0>
101540934: a9408ae1    	ldp	x1, x2, [x23, #0x8]
101540938: f94027e0    	ldr	x0, [sp, #0x48]
10154093c: 94004ab8    	bl	0x10155341c <__RNvXsC_NtNtCsgDHHaSskbIF_4core5slice3cmpmNtB5_13SliceContains14slice_contains>
101540940: 36000060    	tbz	w0, #0x0, 0x10154094c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1af0>
101540944: d2800008    	mov	x8, #0x0                ; =0
101540948: 14000018    	b	0x1015409a8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b4c>
10154094c: f9402be8    	ldr	x8, [sp, #0x50]
101540950: b900011f    	str	wzr, [x8]
101540954: 52800189    	mov	w9, #0xc                ; =12
101540958: 39002109    	strb	w9, [x8, #0x8]
10154095c: b000d7a9    	adrp	x9, 0x103035000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x4a0>
101540960: 91090d29    	add	x9, x9, #0x243
101540964: 5280070a    	mov	w10, #0x38              ; =56
101540968: 17fff960    	b	0x10153eee8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10154096c: f94052e9    	ldr	x9, [x23, #0xa0]
101540970: b4000669    	cbz	x9, 0x101540a3c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1be0>
101540974: f9404ee8    	ldr	x8, [x23, #0x98]
101540978: d37be929    	lsl	x9, x9, #5
10154097c: 14000004    	b	0x10154098c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b30>
101540980: 91008108    	add	x8, x8, #0x20
101540984: f1008129    	subs	x9, x9, #0x20
101540988: 540005a0    	b.eq	0x101540a3c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1be0>
10154098c: b940190b    	ldr	w11, [x8, #0x18]
101540990: f94027ea    	ldr	x10, [sp, #0x48]
101540994: eb0b015f    	cmp	x10, x11
101540998: 54ffff41    	b.ne	0x101540980 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b24>
10154099c: b9401d0a    	ldr	w10, [x8, #0x1c]
1015409a0: eb0a039f    	cmp	x28, x10
1015409a4: 54fffee1    	b.ne	0x101540980 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b24>
1015409a8: f90233e8    	str	x8, [sp, #0x460]
1015409ac: f94023e9    	ldr	x9, [sp, #0x40]
1015409b0: a94d2528    	ldp	x8, x9, [x9, #0xd0]
1015409b4: d37ae529    	lsl	x9, x9, #6
1015409b8: b4000da9    	cbz	x9, 0x101540b6c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1d10>
1015409bc: f844050a    	ldr	x10, [x8], #0x40
1015409c0: d1010129    	sub	x9, x9, #0x40
1015409c4: b4ffffaa    	cbz	x10, 0x1015409b8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b5c>
1015409c8: f9402be8    	ldr	x8, [sp, #0x50]
1015409cc: b900011f    	str	wzr, [x8]
1015409d0: 52800189    	mov	w9, #0xc                ; =12
1015409d4: 39002109    	strb	w9, [x8, #0x8]
1015409d8: b000d7a9    	adrp	x9, 0x103035000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x4a0>
1015409dc: 91084529    	add	x9, x9, #0x211
1015409e0: 5280064a    	mov	w10, #0x32              ; =50
1015409e4: 17fff941    	b	0x10153eee8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015409e8: 3dc137e0    	ldr	q0, [sp, #0x4d0]
1015409ec: 3dc13be1    	ldr	q1, [sp, #0x4e0]
1015409f0: ad1207e0    	stp	q0, q1, [sp, #0x240]
1015409f4: 3dc13fe2    	ldr	q2, [sp, #0x4f0]
1015409f8: 3d809be2    	str	q2, [sp, #0x260]
1015409fc: f94283e8    	ldr	x8, [sp, #0x500]
101540a00: f9013be8    	str	x8, [sp, #0x270]
101540a04: 3c874300    	stur	q0, [x24, #0x74]
101540a08: 3c884301    	stur	q1, [x24, #0x84]
101540a0c: 3c894302    	stur	q2, [x24, #0x94]
101540a10: f80a4308    	stur	x8, [x24, #0xa4]
101540a14: b900029f    	str	wzr, [x20]
101540a18: 3dc137e0    	ldr	q0, [sp, #0x4d0]
101540a1c: 3dc13be1    	ldr	q1, [sp, #0x4e0]
101540a20: 3c804280    	stur	q0, [x20, #0x4]
101540a24: 3c814281    	stur	q1, [x20, #0x14]
101540a28: 3dc13fe0    	ldr	q0, [sp, #0x4f0]
101540a2c: 3c824280    	stur	q0, [x20, #0x24]
101540a30: 3cc9c300    	ldur	q0, [x24, #0x9c]
101540a34: 3d800e80    	str	q0, [x20, #0x30]
101540a38: 17fff9be    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101540a3c: f9402be8    	ldr	x8, [sp, #0x50]
101540a40: b900011f    	str	wzr, [x8]
101540a44: 52800189    	mov	w9, #0xc                ; =12
101540a48: d000d78a    	adrp	x10, 0x103032000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.241+0x21>
101540a4c: 913d3d4a    	add	x10, x10, #0xf4f
101540a50: a900a909    	stp	x9, x10, [x8, #0x8]
101540a54: 52800629    	mov	w9, #0x31               ; =49
101540a58: 17fff9b5    	b	0x10153f12c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101540a5c: f1001edf    	cmp	x22, #0x7
101540a60: 540019a0    	b.eq	0x101540d94 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f38>
101540a64: f10042df    	cmp	x22, #0x10
101540a68: 54001da0    	b.eq	0x101540e1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1fc0>
101540a6c: f10046df    	cmp	x22, #0x11
101540a70: 54001aa1    	b.ne	0x101540dc4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f68>
101540a74: a9409704    	ldp	x4, x5, [x24, #0x8]
101540a78: f9400303    	ldr	x3, [x24]
101540a7c: aa1303e0    	mov	x0, x19
101540a80: f9402fe1    	ldr	x1, [sp, #0x58]
101540a84: aa1403e2    	mov	x2, x20
101540a88: 911d03ff    	add	sp, sp, #0x740
101540a8c: a9457bfd    	ldp	x29, x30, [sp, #0x50]
101540a90: a9444ff4    	ldp	x20, x19, [sp, #0x40]
101540a94: a94357f6    	ldp	x22, x21, [sp, #0x30]
101540a98: a9425ff8    	ldp	x24, x23, [sp, #0x20]
101540a9c: a94167fa    	ldp	x26, x25, [sp, #0x10]
101540aa0: a8c66ffc    	ldp	x28, x27, [sp], #0x60
101540aa4: 14003760    	b	0x10154e824 <__RNvMs_NtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation5joins6mappedNtB8_10Invocation21finish_join_map_chunk>
101540aa8: 3cc84300    	ldur	q0, [x24, #0x84]
101540aac: 3cc94301    	ldur	q1, [x24, #0x94]
101540ab0: 3cca4302    	ldur	q2, [x24, #0xa4]
101540ab4: ad130be1    	stp	q1, q2, [sp, #0x260]
101540ab8: b94517e9    	ldr	w9, [sp, #0x514]
101540abc: b90283e9    	str	w9, [sp, #0x280]
101540ac0: 3cc74303    	ldur	q3, [x24, #0x74]
101540ac4: ad1203e3    	stp	q3, q0, [sp, #0x240]
101540ac8: f9428fea    	ldr	x10, [sp, #0x518]
101540acc: 3c814280    	stur	q0, [x20, #0x14]
101540ad0: 3c824281    	stur	q1, [x20, #0x24]
101540ad4: 3c834282    	stur	q2, [x20, #0x34]
101540ad8: b9004689    	str	w9, [x20, #0x44]
101540adc: 3c804283    	stur	q3, [x20, #0x4]
101540ae0: b9000288    	str	w8, [x20]
101540ae4: f900268a    	str	x10, [x20, #0x48]
101540ae8: 17fff992    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101540aec: f9402be8    	ldr	x8, [sp, #0x50]
101540af0: b900011f    	str	wzr, [x8]
101540af4: 52800189    	mov	w9, #0xc                ; =12
101540af8: 39002109    	strb	w9, [x8, #0x8]
101540afc: d000d7a9    	adrp	x9, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
101540b00: 9123b929    	add	x9, x9, #0x8ee
101540b04: 5280048a    	mov	w10, #0x24              ; =36
101540b08: 17fff8f8    	b	0x10153eee8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101540b0c: 911343e8    	add	x8, sp, #0x4d0
101540b10: 9103c2a0    	add	x0, x21, #0xf0
101540b14: 910be2a2    	add	x2, x21, #0x2f8
101540b18: 940013c5    	bl	0x101545a2c <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
101540b1c: f9426be9    	ldr	x9, [sp, #0x4d0]
101540b20: f9426fe8    	ldr	x8, [sp, #0x4d8]
101540b24: 3dc13be0    	ldr	q0, [sp, #0x4e0]
101540b28: 3dc13fe1    	ldr	q1, [sp, #0x4f0]
101540b2c: ad1207e0    	stp	q0, q1, [sp, #0x240]
101540b30: 3dc143e0    	ldr	q0, [sp, #0x500]
101540b34: 3d809be0    	str	q0, [sp, #0x260]
101540b38: b40018a9    	cbz	x9, 0x101540e4c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ff0>
101540b3c: ad5207e0    	ldp	q0, q1, [sp, #0x240]
101540b40: ad0887e0    	stp	q0, q1, [sp, #0x110]
101540b44: 3dc09be0    	ldr	q0, [sp, #0x260]
101540b48: 3d804fe0    	str	q0, [sp, #0x130]
101540b4c: 17ffff5a    	b	0x1015408b4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a58>
101540b50: b900027f    	str	wzr, [x19]
101540b54: 52800188    	mov	w8, #0xc                ; =12
101540b58: 39002268    	strb	w8, [x19, #0x8]
101540b5c: d000d7a8    	adrp	x8, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
101540b60: 911e8108    	add	x8, x8, #0x7a0
101540b64: 52800489    	mov	w9, #0x24               ; =36
101540b68: 17fffcb3    	b	0x10153fe34 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfd8>
101540b6c: 911183e8    	add	x8, sp, #0x460
101540b70: f90123e8    	str	x8, [sp, #0x240]
101540b74: f90127f8    	str	x24, [sp, #0x248]
101540b78: f9402ff3    	ldr	x19, [sp, #0x58]
101540b7c: f9012bf3    	str	x19, [sp, #0x250]
101540b80: f9401fe8    	ldr	x8, [sp, #0x38]
101540b84: f9012fe8    	str	x8, [sp, #0x258]
101540b88: f90133f5    	str	x21, [sp, #0x260]
101540b8c: 911343e0    	add	x0, sp, #0x4d0
101540b90: 910903e1    	add	x1, sp, #0x240
101540b94: 97ff935d    	bl	0x101525908 <__RNCNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16numeric_segmentsNtB6_10Invocation19end_numeric_segments4_0Be_>
101540b98: f9424a68    	ldr	x8, [x19, #0x490]
101540b9c: f9406d02    	ldr	x2, [x8, #0xd8]
101540ba0: f94022e1    	ldr	x1, [x23, #0x40]
101540ba4: eb02003f    	cmp	x1, x2
101540ba8: 5400b9e8    	b.hi	0x1015422e4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3488>
101540bac: f9406900    	ldr	x0, [x8, #0xd0]
101540bb0: f90123ff    	str	xzr, [sp, #0x240]
101540bb4: 910903e2    	add	x2, sp, #0x240
101540bb8: 94013fae    	bl	0x101590a70 <__RNvXNtNtCsgDHHaSskbIF_4core5slice10specializeSINtNtB6_6option6OptionNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEINtB2_8SpecFillBI_E9spec_fillCs29QkOtpKx6e_8mech_gpu>
101540bbc: b944d3e8    	ldr	w8, [sp, #0x4d0]
101540bc0: 7100191f    	cmp	w8, #0x6
101540bc4: 54001541    	b.ne	0x101540e6c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2010>
101540bc8: f9402fe9    	ldr	x9, [sp, #0x58]
101540bcc: f9424928    	ldr	x8, [x9, #0x490]
101540bd0: b903411f    	str	wzr, [x8, #0x340]
101540bd4: f942492a    	ldr	x10, [x9, #0x490]
101540bd8: 52800028    	mov	w8, #0x1                ; =1
101540bdc: b902f148    	str	w8, [x10, #0x2f0]
101540be0: f94027e8    	ldr	x8, [sp, #0x48]
101540be4: b902f548    	str	w8, [x10, #0x2f4]
101540be8: f9424928    	ldr	x8, [x9, #0x490]
101540bec: f1000a9f    	cmp	x20, #0x2
101540bf0: 1a9f07e9    	cset	w9, ne
101540bf4: 39118109    	strb	w9, [x8, #0x460]
101540bf8: f9402be8    	ldr	x8, [sp, #0x50]
101540bfc: f900051f    	str	xzr, [x8, #0x8]
101540c00: 17fffd92    	b	0x101540248 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13ec>
101540c04: b0012460    	adrp	x0, 0x1039cd000 <_anon.369b439a638cb010e9292f03e79ebf78.285+0x710>
101540c08: 913e6000    	add	x0, x0, #0xf98
101540c0c: 9462cd61    	bl	0x102df4190 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
101540c10: b0012460    	adrp	x0, 0x1039cd000 <_anon.369b439a638cb010e9292f03e79ebf78.285+0x710>
101540c14: 913ec000    	add	x0, x0, #0xfb0
101540c18: 9462cd5e    	bl	0x102df4190 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
101540c1c: 911343e9    	add	x9, sp, #0x4d0
101540c20: 3cc48120    	ldur	q0, [x9, #0x48]
101540c24: 3cc58121    	ldur	q1, [x9, #0x58]
101540c28: ad1407e0    	stp	q0, q1, [sp, #0x280]
101540c2c: f8468128    	ldur	x8, [x9, #0x68]
101540c30: f90153e8    	str	x8, [sp, #0x2a0]
101540c34: 3cc08122    	ldur	q2, [x9, #0x8]
101540c38: 3cc18123    	ldur	q3, [x9, #0x18]
101540c3c: ad120fe2    	stp	q2, q3, [sp, #0x240]
101540c40: 3cc38124    	ldur	q4, [x9, #0x38]
101540c44: 3cc28125    	ldur	q5, [x9, #0x28]
101540c48: ad050fe2    	stp	q2, q3, [sp, #0xa0]
101540c4c: ad0613e5    	stp	q5, q4, [sp, #0xc0]
101540c50: f90083e8    	str	x8, [sp, #0x100]
101540c54: ad0707e0    	stp	q0, q1, [sp, #0xe0]
101540c58: b94002c8    	ldr	w8, [x22]
101540c5c: 7100191f    	cmp	w8, #0x6
101540c60: 54001361    	b.ne	0x101540ecc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2070>
101540c64: ad4307e0    	ldp	q0, q1, [sp, #0x60]
101540c68: ad1207e0    	stp	q0, q1, [sp, #0x240]
101540c6c: ad4407e0    	ldp	q0, q1, [sp, #0x80]
101540c70: ad1307e0    	stp	q0, q1, [sp, #0x260]
101540c74: f9402fe8    	ldr	x8, [sp, #0x58]
101540c78: ad440500    	ldp	q0, q1, [x8, #0x80]
101540c7c: 3d8157e0    	str	q0, [sp, #0x550]
101540c80: 3d815be1    	str	q1, [sp, #0x560]
101540c84: f9405109    	ldr	x9, [x8, #0xa0]
101540c88: f902bbe9    	str	x9, [sp, #0x570]
101540c8c: ad420500    	ldp	q0, q1, [x8, #0x40]
101540c90: 3d8147e0    	str	q0, [sp, #0x510]
101540c94: 3d814be1    	str	q1, [sp, #0x520]
101540c98: ad430101    	ldp	q1, q0, [x8, #0x60]
101540c9c: 3d8153e0    	str	q0, [sp, #0x540]
101540ca0: 3d814fe1    	str	q1, [sp, #0x530]
101540ca4: ad400500    	ldp	q0, q1, [x8]
101540ca8: 3d8137e0    	str	q0, [sp, #0x4d0]
101540cac: 3d813be1    	str	q1, [sp, #0x4e0]
101540cb0: ad410101    	ldp	q1, q0, [x8, #0x20]
101540cb4: 3d8143e0    	str	q0, [sp, #0x500]
101540cb8: 3d813fe1    	str	q1, [sp, #0x4f0]
101540cbc: f9424909    	ldr	x9, [x8, #0x490]
101540cc0: 911183e8    	add	x8, sp, #0x460
101540cc4: 910903e1    	add	x1, sp, #0x240
101540cc8: 911343e4    	add	x4, sp, #0x4d0
101540ccc: 910ee125    	add	x5, x9, #0x3b8
101540cd0: 910283e6    	add	x6, sp, #0xa0
101540cd4: f9401be0    	ldr	x0, [sp, #0x30]
101540cd8: f94023e2    	ldr	x2, [sp, #0x40]
101540cdc: 52800023    	mov	w3, #0x1                ; =1
101540ce0: 945108f1    	bl	0x1029830a4 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall15unsigned_buffer>
101540ce4: f94233e8    	ldr	x8, [sp, #0x460]
101540ce8: b4002dc8    	cbz	x8, 0x1015412a0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2444>
101540cec: 3dc11be0    	ldr	q0, [sp, #0x460]
101540cf0: 3dc11fe1    	ldr	q1, [sp, #0x470]
101540cf4: ad0887e0    	stp	q0, q1, [sp, #0x110]
101540cf8: 3dc123e2    	ldr	q2, [sp, #0x480]
101540cfc: 3dc127e3    	ldr	q3, [sp, #0x490]
101540d00: ad098fe2    	stp	q2, q3, [sp, #0x130]
101540d04: 52800028    	mov	w8, #0x1                ; =1
101540d08: 390543e8    	strb	w8, [sp, #0x150]
101540d0c: ad0b07e0    	stp	q0, q1, [sp, #0x160]
101540d10: ad0c0fe2    	stp	q2, q3, [sp, #0x180]
101540d14: 14000096    	b	0x101540f6c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2110>
101540d18: ad5a87e0    	ldp	q0, q1, [sp, #0x350]
101540d1c: 3c804360    	stur	q0, [x27, #0x4]
101540d20: 3c814361    	stur	q1, [x27, #0x14]
101540d24: 3dc0dfe0    	ldr	q0, [sp, #0x370]
101540d28: 3c824360    	stur	q0, [x27, #0x24]
101540d2c: f941c3e8    	ldr	x8, [sp, #0x380]
101540d30: f8034368    	stur	x8, [x27, #0x34]
101540d34: 3dc137e0    	ldr	q0, [sp, #0x4d0]
101540d38: 3dc13be1    	ldr	q1, [sp, #0x4e0]
101540d3c: f9402be8    	ldr	x8, [sp, #0x50]
101540d40: 3c804100    	stur	q0, [x8, #0x4]
101540d44: 52800049    	mov	w9, #0x2                ; =2
101540d48: b9000109    	str	w9, [x8]
101540d4c: 3c814101    	stur	q1, [x8, #0x14]
101540d50: 3dc13fe0    	ldr	q0, [sp, #0x4f0]
101540d54: 3c824100    	stur	q0, [x8, #0x24]
101540d58: 3cc2c360    	ldur	q0, [x27, #0x2c]
101540d5c: 3d800d00    	str	q0, [x8, #0x30]
101540d60: 17fff8f4    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101540d64: aa1303e0    	mov	x0, x19
101540d68: f9402fe1    	ldr	x1, [sp, #0x58]
101540d6c: aa1403e2    	mov	x2, x20
101540d70: aa1803e3    	mov	x3, x24
101540d74: 911d03ff    	add	sp, sp, #0x740
101540d78: a9457bfd    	ldp	x29, x30, [sp, #0x50]
101540d7c: a9444ff4    	ldp	x20, x19, [sp, #0x40]
101540d80: a94357f6    	ldp	x22, x21, [sp, #0x30]
101540d84: a9425ff8    	ldp	x24, x23, [sp, #0x20]
101540d88: a94167fa    	ldp	x26, x25, [sp, #0x10]
101540d8c: a8c66ffc    	ldp	x28, x27, [sp], #0x60
101540d90: 17ffc7d5    	b	0x101532ce4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation6windowNtB4_10Invocation21prepare_window_region>
101540d94: aa1303e0    	mov	x0, x19
101540d98: f9402fe1    	ldr	x1, [sp, #0x58]
101540d9c: aa1403e2    	mov	x2, x20
101540da0: aa1803e3    	mov	x3, x24
101540da4: 911d03ff    	add	sp, sp, #0x740
101540da8: a9457bfd    	ldp	x29, x30, [sp, #0x50]
101540dac: a9444ff4    	ldp	x20, x19, [sp, #0x40]
101540db0: a94357f6    	ldp	x22, x21, [sp, #0x30]
101540db4: a9425ff8    	ldp	x24, x23, [sp, #0x20]
101540db8: a94167fa    	ldp	x26, x25, [sp, #0x10]
101540dbc: a8c66ffc    	ldp	x28, x27, [sp], #0x60
101540dc0: 17ffdadb    	b	0x10153792c <__RNvMNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation6window10string_mapNtB6_10Invocation24finish_string_map_region>
101540dc4: f9402fe8    	ldr	x8, [sp, #0x58]
101540dc8: f9405508    	ldr	x8, [x8, #0xa8]
101540dcc: b40020e8    	cbz	x8, 0x1015411e8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x238c>
101540dd0: b900027f    	str	wzr, [x19]
101540dd4: 52800188    	mov	w8, #0xc                ; =12
101540dd8: 39002268    	strb	w8, [x19, #0x8]
101540ddc: d000d7a8    	adrp	x8, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
101540de0: 911ad508    	add	x8, x8, #0x6b5
101540de4: 528005a9    	mov	w9, #0x2d               ; =45
101540de8: 17fffc13    	b	0x10153fe34 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfd8>
101540dec: aa1303e0    	mov	x0, x19
101540df0: f9402fe1    	ldr	x1, [sp, #0x58]
101540df4: aa1403e2    	mov	x2, x20
101540df8: aa1803e3    	mov	x3, x24
101540dfc: 911d03ff    	add	sp, sp, #0x740
101540e00: a9457bfd    	ldp	x29, x30, [sp, #0x50]
101540e04: a9444ff4    	ldp	x20, x19, [sp, #0x40]
101540e08: a94357f6    	ldp	x22, x21, [sp, #0x30]
101540e0c: a9425ff8    	ldp	x24, x23, [sp, #0x20]
101540e10: a94167fa    	ldp	x26, x25, [sp, #0x10]
101540e14: a8c66ffc    	ldp	x28, x27, [sp], #0x60
101540e18: 17ffc634    	b	0x1015326e8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation6windowNtB4_10Invocation20finish_window_region>
101540e1c: aa1303e0    	mov	x0, x19
101540e20: f9402fe1    	ldr	x1, [sp, #0x58]
101540e24: aa1403e2    	mov	x2, x20
101540e28: aa1803e3    	mov	x3, x24
101540e2c: 911d03ff    	add	sp, sp, #0x740
101540e30: a9457bfd    	ldp	x29, x30, [sp, #0x50]
101540e34: a9444ff4    	ldp	x20, x19, [sp, #0x40]
101540e38: a94357f6    	ldp	x22, x21, [sp, #0x30]
101540e3c: a9425ff8    	ldp	x24, x23, [sp, #0x20]
101540e40: a94167fa    	ldp	x26, x25, [sp, #0x10]
101540e44: a8c66ffc    	ldp	x28, x27, [sp], #0x60
101540e48: 1400374f    	b	0x10154eb84 <__RNvMs_NtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation5joins6mappedNtB8_10Invocation22prepare_join_map_chunk>
101540e4c: ad5207e0    	ldp	q0, q1, [sp, #0x240]
101540e50: ad0086c0    	stp	q0, q1, [x22, #0x10]
101540e54: 3dc09be0    	ldr	q0, [sp, #0x260]
101540e58: 3d800ec0    	str	q0, [x22, #0x30]
101540e5c: 52800049    	mov	w9, #0x2                ; =2
101540e60: b90002c9    	str	w9, [x22]
101540e64: f90006c8    	str	x8, [x22, #0x8]
101540e68: 17fff8b2    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101540e6c: 3cc14360    	ldur	q0, [x27, #0x14]
101540e70: f9402be9    	ldr	x9, [sp, #0x50]
101540e74: 3c814120    	stur	q0, [x9, #0x14]
101540e78: 3cc24360    	ldur	q0, [x27, #0x24]
101540e7c: 3c824120    	stur	q0, [x9, #0x24]
101540e80: 3cc34360    	ldur	q0, [x27, #0x34]
101540e84: 3c834120    	stur	q0, [x9, #0x34]
101540e88: 3dc147e0    	ldr	q0, [sp, #0x510]
101540e8c: 3d801120    	str	q0, [x9, #0x40]
101540e90: 3cc04360    	ldur	q0, [x27, #0x4]
101540e94: 3c804120    	stur	q0, [x9, #0x4]
101540e98: b9000128    	str	w8, [x9]
101540e9c: 17fff8a5    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101540ea0: 52800029    	mov	w9, #0x1                ; =1
101540ea4: f9402be8    	ldr	x8, [sp, #0x50]
101540ea8: f9000509    	str	x9, [x8, #0x8]
101540eac: 528000c8    	mov	w8, #0x6                ; =6
101540eb0: 52800049    	mov	w9, #0x2                ; =2
101540eb4: f9402bea    	ldr	x10, [sp, #0x50]
101540eb8: f9000949    	str	x9, [x10, #0x10]
101540ebc: b9000148    	str	w8, [x10]
101540ec0: 910903e0    	add	x0, sp, #0x240
101540ec4: 97ff83ae    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
101540ec8: 17fff89a    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101540ecc: ad4307e0    	ldp	q0, q1, [sp, #0x60]
101540ed0: ad1207e0    	stp	q0, q1, [sp, #0x240]
101540ed4: ad4407e0    	ldp	q0, q1, [sp, #0x80]
101540ed8: ad1307e0    	stp	q0, q1, [sp, #0x260]
101540edc: f9402fe8    	ldr	x8, [sp, #0x58]
101540ee0: ad440500    	ldp	q0, q1, [x8, #0x80]
101540ee4: 3d8157e0    	str	q0, [sp, #0x550]
101540ee8: 3d815be1    	str	q1, [sp, #0x560]
101540eec: f9405109    	ldr	x9, [x8, #0xa0]
101540ef0: f902bbe9    	str	x9, [sp, #0x570]
101540ef4: ad420500    	ldp	q0, q1, [x8, #0x40]
101540ef8: 3d8147e0    	str	q0, [sp, #0x510]
101540efc: 3d814be1    	str	q1, [sp, #0x520]
101540f00: ad430101    	ldp	q1, q0, [x8, #0x60]
101540f04: 3d8153e0    	str	q0, [sp, #0x540]
101540f08: 3d814fe1    	str	q1, [sp, #0x530]
101540f0c: ad400500    	ldp	q0, q1, [x8]
101540f10: 3d8137e0    	str	q0, [sp, #0x4d0]
101540f14: 3d813be1    	str	q1, [sp, #0x4e0]
101540f18: ad410101    	ldp	q1, q0, [x8, #0x20]
101540f1c: 3d8143e0    	str	q0, [sp, #0x500]
101540f20: 3d813fe1    	str	q1, [sp, #0x4f0]
101540f24: f9424909    	ldr	x9, [x8, #0x490]
101540f28: 910443e8    	add	x8, sp, #0x110
101540f2c: 910903e1    	add	x1, sp, #0x240
101540f30: 911343e5    	add	x5, sp, #0x4d0
101540f34: 910ee126    	add	x6, x9, #0x3b8
101540f38: 910283e7    	add	x7, sp, #0xa0
101540f3c: a9430be0    	ldp	x0, x2, [sp, #0x30]
101540f40: f94023e3    	ldr	x3, [sp, #0x40]
101540f44: 52800024    	mov	w4, #0x1                ; =1
101540f48: 94510766    	bl	0x102982ce0 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall23unsigned_matrix_replace>
101540f4c: 394543e8    	ldrb	w8, [sp, #0x150]
101540f50: 7100091f    	cmp	w8, #0x2
101540f54: 54001b40    	b.eq	0x1015412bc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2460>
101540f58: ad4887e0    	ldp	q0, q1, [sp, #0x110]
101540f5c: ad0b07e0    	stp	q0, q1, [sp, #0x160]
101540f60: ad4987e0    	ldp	q0, q1, [sp, #0x130]
101540f64: ad0c07e0    	stp	q0, q1, [sp, #0x180]
101540f68: 36002b48    	tbz	w8, #0x0, 0x1015414d0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2674>
101540f6c: f9402fe8    	ldr	x8, [sp, #0x58]
101540f70: f9424909    	ldr	x9, [x8, #0x490]
101540f74: 9118c3e8    	add	x8, sp, #0x630
101540f78: 910ee120    	add	x0, x9, #0x3b8
101540f7c: 94376581    	bl	0x10231a580 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget13memory_budget>
101540f80: f942eae8    	ldr	x8, [x23, #0x5d0]
101540f84: b140051f    	cmn	x8, #0x1, lsl #12       ; =0x1000
101540f88: 5400abc2    	b.hs	0x101542500 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x36a4>
101540f8c: 91400517    	add	x23, x8, #0x1, lsl #12  ; =0x1000
101540f90: d37cfee8    	lsr	x8, x23, #60
101540f94: b500ac68    	cbnz	x8, 0x101542520 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x36c4>
101540f98: f9402fe8    	ldr	x8, [sp, #0x58]
101540f9c: f9424908    	ldr	x8, [x8, #0x490]
101540fa0: d37ceee2    	lsl	x2, x23, #4
101540fa4: 52800029    	mov	w9, #0x1                ; =1
101540fa8: b90043e9    	str	w9, [sp, #0x40]
101540fac: 911343e0    	add	x0, sp, #0x4d0
101540fb0: 910be101    	add	x1, x8, #0x2f8
101540fb4: 97ff95c7    	bl	0x1015266d0 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
101540fb8: 395343e8    	ldrb	w8, [sp, #0x4d0]
101540fbc: 7100391f    	cmp	w8, #0xe
101540fc0: 54001461    	b.ne	0x10154124c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x23f0>
101540fc4: 52800028    	mov	w8, #0x1                ; =1
101540fc8: b90043e8    	str	w8, [sp, #0x40]
101540fcc: 911343e8    	add	x8, sp, #0x4d0
101540fd0: 9118c3e0    	add	x0, sp, #0x630
101540fd4: aa1703e1    	mov	x1, x23
101540fd8: 945e9b0a    	bl	0x102ce7c00 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
101540fdc: b944d3e8    	ldr	w8, [sp, #0x4d0]
101540fe0: 7100691f    	cmp	w8, #0x1a
101540fe4: 54002861    	b.ne	0x1015414f0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2694>
101540fe8: 3cc88300    	ldur	q0, [x24, #0x88]
101540fec: 3cc78301    	ldur	q1, [x24, #0x78]
101540ff0: 3d8197e1    	str	q1, [sp, #0x650]
101540ff4: 3d819be0    	str	q0, [sp, #0x660]
101540ff8: f940b3e8    	ldr	x8, [sp, #0x160]
101540ffc: 91004100    	add	x0, x8, #0x10
101541000: 97ff4e1f    	bl	0x10151487c <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSyENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs29QkOtpKx6e_8mech_gpu>
101541004: f90023e0    	str	x0, [sp, #0x40]
101541008: aa0103f7    	mov	x23, x1
10154100c: ad4b07e0    	ldp	q0, q1, [sp, #0x160]
101541010: 3d811be0    	str	q0, [sp, #0x460]
101541014: 3d811fe1    	str	q1, [sp, #0x470]
101541018: ad4c07e0    	ldp	q0, q1, [sp, #0x180]
10154101c: 3d8123e0    	str	q0, [sp, #0x480]
101541020: 3d8127e1    	str	q1, [sp, #0x490]
101541024: 911343e8    	add	x8, sp, #0x4d0
101541028: 911183e0    	add	x0, sp, #0x460
10154102c: 9118c3e1    	add	x1, sp, #0x630
101541030: 945ec06e    	bl	0x102cf11e8 <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrixNtB6_5Value30try_into_owned_unsigned_matrix>
101541034: f9426be8    	ldr	x8, [sp, #0x4d0]
101541038: 3cc78300    	ldur	q0, [x24, #0x78]
10154103c: 3cc88301    	ldur	q1, [x24, #0x88]
101541040: ad1087e0    	stp	q0, q1, [sp, #0x210]
101541044: 3cc98300    	ldur	q0, [x24, #0x98]
101541048: 3d808fe0    	str	q0, [sp, #0x230]
10154104c: f100151f    	cmp	x8, #0x5
101541050: 54002d81    	b.ne	0x101541600 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x27a4>
101541054: ad5087e0    	ldp	q0, q1, [sp, #0x210]
101541058: 911763e8    	add	x8, sp, #0x5d8
10154105c: 3c807100    	stur	q0, [x8, #0x7]
101541060: 3c817101    	stur	q1, [x8, #0x17]
101541064: 3dc08fe0    	ldr	q0, [sp, #0x230]
101541068: 3c827100    	stur	q0, [x8, #0x27]
10154106c: ad400500    	ldp	q0, q1, [x8]
101541070: 3c809280    	stur	q0, [x20, #0x9]
101541074: b900029f    	str	wzr, [x20]
101541078: 528001a9    	mov	w9, #0xd                ; =13
10154107c: 39002289    	strb	w9, [x20, #0x8]
101541080: 3c819281    	stur	q1, [x20, #0x19]
101541084: 3dc00900    	ldr	q0, [x8, #0x20]
101541088: 3c829280    	stur	q0, [x20, #0x29]
10154108c: f842f108    	ldur	x8, [x8, #0x2f]
101541090: f9001e88    	str	x8, [x20, #0x38]
101541094: 1400035f    	b	0x101541e10 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fb4>
101541098: b84111a1    	ldur	w1, [x13, #0x11]
10154109c: b8009361    	stur	w1, [x27, #0x9]
1015410a0: b84141a1    	ldur	w1, [x13, #0x14]
1015410a4: b904dfe1    	str	w1, [sp, #0x4dc]
1015410a8: b904d3e0    	str	w0, [sp, #0x4d0]
1015410ac: b904d7f1    	str	w17, [sp, #0x4d4]
1015410b0: 391363f0    	strb	w16, [sp, #0x4d8]
1015410b4: f90273ef    	str	x15, [sp, #0x4e0]
1015410b8: f90277ee    	str	x14, [sp, #0x4e8]
1015410bc: 3cc281a0    	ldur	q0, [x13, #0x28]
1015410c0: 3cc381a1    	ldur	q1, [x13, #0x38]
1015410c4: 3d8143e1    	str	q1, [sp, #0x500]
1015410c8: 3d813fe0    	str	q0, [sp, #0x4f0]
1015410cc: 3cc481a0    	ldur	q0, [x13, #0x48]
1015410d0: 3cc581a1    	ldur	q1, [x13, #0x58]
1015410d4: 3cc681a2    	ldur	q2, [x13, #0x68]
1015410d8: 3cc781a3    	ldur	q3, [x13, #0x78]
1015410dc: 3cc881a4    	ldur	q4, [x13, #0x88]
1015410e0: 3cc981a5    	ldur	q5, [x13, #0x98]
1015410e4: 3cca81a6    	ldur	q6, [x13, #0xa8]
1015410e8: 3ccb81a7    	ldur	q7, [x13, #0xb8]
1015410ec: 3d8163e7    	str	q7, [sp, #0x580]
1015410f0: 3d815fe6    	str	q6, [sp, #0x570]
1015410f4: 3d815be5    	str	q5, [sp, #0x560]
1015410f8: 3d8157e4    	str	q4, [sp, #0x550]
1015410fc: 3d8153e3    	str	q3, [sp, #0x540]
101541100: 3d814fe2    	str	q2, [sp, #0x530]
101541104: 3d8147e0    	str	q0, [sp, #0x510]
101541108: 3d814be1    	str	q1, [sp, #0x520]
10154110c: f940258d    	ldr	x13, [x12, #0x48]
101541110: b10005bf    	cmn	x13, #0x1
101541114: 54009e80    	b.eq	0x1015424e4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3688>
101541118: 910005ad    	add	x13, x13, #0x1
10154111c: f900258d    	str	x13, [x12, #0x48]
101541120: f940298c    	ldr	x12, [x12, #0x50]
101541124: eb0c01bf    	cmp	x13, x12
101541128: 54000801    	b.ne	0x101541228 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x23cc>
10154112c: 9100054c    	add	x12, x10, #0x1
101541130: eb08019f    	cmp	x12, x8
101541134: 9a8833e8    	csel	x8, xzr, x8, lo
101541138: cb080188    	sub	x8, x12, x8
10154113c: f901eaa8    	str	x8, [x21, #0x3d0]
101541140: d100053c    	sub	x28, x9, #0x1
101541144: f901eebc    	str	x28, [x21, #0x3d8]
101541148: 52800b08    	mov	w8, #0x58               ; =88
10154114c: 9b082d48    	madd	x8, x10, x8, x11
101541150: ad400101    	ldp	q1, q0, [x8]
101541154: ad1203e1    	stp	q1, q0, [sp, #0x240]
101541158: ad418101    	ldp	q1, q0, [x8, #0x30]
10154115c: f9402909    	ldr	x9, [x8, #0x50]
101541160: 3dc00902    	ldr	q2, [x8, #0x20]
101541164: f9014be9    	str	x9, [sp, #0x290]
101541168: ad1383e1    	stp	q1, q0, [sp, #0x270]
10154116c: 3d809be2    	str	q2, [sp, #0x260]
101541170: f94123e8    	ldr	x8, [sp, #0x240]
101541174: b4000088    	cbz	x8, 0x101541184 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2328>
101541178: 5280003b    	mov	w27, #0x1               ; =1
10154117c: 910903e0    	add	x0, sp, #0x240
101541180: 97ff82ff    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
101541184: f100039f    	cmp	x28, #0x0
101541188: 1a9f17e8    	cset	w8, eq
10154118c: b9005be8    	str	w8, [sp, #0x58]
101541190: 14000027    	b	0x10154122c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x23d0>
101541194: b84111a8    	ldur	w8, [x13, #0x11]
101541198: b900a3e8    	str	w8, [sp, #0xa0]
10154119c: b84141a8    	ldur	w8, [x13, #0x14]
1015411a0: b80a33e8    	stur	w8, [sp, #0xa3]
1015411a4: 3cc281a0    	ldur	q0, [x13, #0x28]
1015411a8: 3cc381a1    	ldur	q1, [x13, #0x38]
1015411ac: ad1f87e0    	stp	q0, q1, [sp, #0x3f0]
1015411b0: 3cc481a0    	ldur	q0, [x13, #0x48]
1015411b4: 3d806be0    	str	q0, [sp, #0x1a0]
1015411b8: 29004660    	stp	w0, w17, [x19]
1015411bc: 39002270    	strb	w16, [x19, #0x8]
1015411c0: 2a0803e8    	mov	w8, w8
1015411c4: b9000e68    	str	w8, [x19, #0xc]
1015411c8: b940a3e8    	ldr	w8, [sp, #0xa0]
1015411cc: b8009268    	stur	w8, [x19, #0x9]
1015411d0: a9013a6f    	stp	x15, x14, [x19, #0x10]
1015411d4: ad5f83e1    	ldp	q1, q0, [sp, #0x3f0]
1015411d8: ad010261    	stp	q1, q0, [x19, #0x20]
1015411dc: 3dc06be0    	ldr	q0, [sp, #0x1a0]
1015411e0: 3d801260    	str	q0, [x19, #0x40]
1015411e4: 17fff7d3    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015411e8: f10006df    	cmp	x22, #0x1
1015411ec: 5400140c    	b.gt	0x10154146c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2610>
1015411f0: b4001b36    	cbz	x22, 0x101541554 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x26f8>
1015411f4: f10006df    	cmp	x22, #0x1
1015411f8: 54001e81    	b.ne	0x1015415c8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x276c>
1015411fc: f9402fe8    	ldr	x8, [sp, #0x58]
101541200: f9424908    	ldr	x8, [x8, #0x490]
101541204: 39518108    	ldrb	w8, [x8, #0x460]
101541208: 36002d28    	tbz	w8, #0x0, 0x1015417ac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2950>
10154120c: b900027f    	str	wzr, [x19]
101541210: 52800188    	mov	w8, #0xc                ; =12
101541214: 39002268    	strb	w8, [x19, #0x8]
101541218: b000d7a8    	adrp	x8, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
10154121c: 911bf508    	add	x8, x8, #0x6fd
101541220: 528002c9    	mov	w9, #0x16               ; =22
101541224: 17fffb04    	b	0x10153fe34 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfd8>
101541228: b9005bff    	str	wzr, [sp, #0x58]
10154122c: f9400ec9    	ldr	x9, [x22, #0x18]
101541230: b4001069    	cbz	x9, 0x10154143c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x25e0>
101541234: b9458be0    	ldr	w0, [sp, #0x588]
101541238: f9400ac8    	ldr	x8, [x22, #0x10]
10154123c: f100053f    	cmp	x9, #0x1
101541240: 54000801    	b.ne	0x101541340 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x24e4>
101541244: d280000a    	mov	x10, #0x0               ; =0
101541248: 14000047    	b	0x101541364 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2508>
10154124c: 3dc137e0    	ldr	q0, [sp, #0x4d0]
101541250: 3dc13be1    	ldr	q1, [sp, #0x4e0]
101541254: ad1207e0    	stp	q0, q1, [sp, #0x240]
101541258: 3dc13fe2    	ldr	q2, [sp, #0x4f0]
10154125c: 3d809be2    	str	q2, [sp, #0x260]
101541260: f94283e8    	ldr	x8, [sp, #0x500]
101541264: f9013be8    	str	x8, [sp, #0x270]
101541268: 3c804360    	stur	q0, [x27, #0x4]
10154126c: 3c814361    	stur	q1, [x27, #0x14]
101541270: 3c824362    	stur	q2, [x27, #0x24]
101541274: f8034368    	stur	x8, [x27, #0x34]
101541278: b900029f    	str	wzr, [x20]
10154127c: 3dc137e0    	ldr	q0, [sp, #0x4d0]
101541280: 3dc13be1    	ldr	q1, [sp, #0x4e0]
101541284: 3c804280    	stur	q0, [x20, #0x4]
101541288: 3c814281    	stur	q1, [x20, #0x14]
10154128c: 3dc13fe0    	ldr	q0, [sp, #0x4f0]
101541290: 3c824280    	stur	q0, [x20, #0x24]
101541294: 3cc2c360    	ldur	q0, [x27, #0x2c]
101541298: 3d800e80    	str	q0, [x20, #0x30]
10154129c: 140000a3    	b	0x101541528 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x26cc>
1015412a0: 3cc08300    	ldur	q0, [x24, #0x8]
1015412a4: 3cc18301    	ldur	q1, [x24, #0x18]
1015412a8: ad0887e0    	stp	q0, q1, [sp, #0x110]
1015412ac: 3cc28300    	ldur	q0, [x24, #0x28]
1015412b0: 3d804fe0    	str	q0, [sp, #0x130]
1015412b4: f9424fe8    	ldr	x8, [sp, #0x498]
1015412b8: f900a3e8    	str	x8, [sp, #0x140]
1015412bc: f941bae1    	ldr	x1, [x23, #0x370]
1015412c0: f941bee2    	ldr	x2, [x23, #0x378]
1015412c4: 911343e0    	add	x0, sp, #0x4d0
1015412c8: 910443e4    	add	x4, sp, #0x110
1015412cc: f94027e3    	ldr	x3, [sp, #0x48]
1015412d0: 97ff9121    	bl	0x101525754 <__RNCNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation14numeric_writesNtB6_10Invocation21prepare_numeric_writes2_0Be_>
1015412d4: 3cc84300    	ldur	q0, [x24, #0x84]
1015412d8: 3c814280    	stur	q0, [x20, #0x14]
1015412dc: 3cc94300    	ldur	q0, [x24, #0x94]
1015412e0: 3c824280    	stur	q0, [x20, #0x24]
1015412e4: 3cca4300    	ldur	q0, [x24, #0xa4]
1015412e8: 3c834280    	stur	q0, [x20, #0x34]
1015412ec: b944d3e8    	ldr	w8, [sp, #0x4d0]
1015412f0: b94517e9    	ldr	w9, [sp, #0x514]
1015412f4: b9004689    	str	w9, [x20, #0x44]
1015412f8: 3cc74300    	ldur	q0, [x24, #0x74]
1015412fc: 3c804280    	stur	q0, [x20, #0x4]
101541300: 395463e9    	ldrb	w9, [sp, #0x518]
101541304: b84b930a    	ldur	w10, [x24, #0xb9]
101541308: b804928a    	stur	w10, [x20, #0x49]
10154130c: b9451fea    	ldr	w10, [sp, #0x51c]
101541310: b9004e8a    	str	w10, [x20, #0x4c]
101541314: b9000288    	str	w8, [x20]
101541318: 39012289    	strb	w9, [x20, #0x48]
10154131c: 17fff785    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541320: b90002ff    	str	wzr, [x23]
101541324: 52800188    	mov	w8, #0xc                ; =12
101541328: d000d789    	adrp	x9, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
10154132c: 91025529    	add	x9, x9, #0x95
101541330: a900a6e8    	stp	x8, x9, [x23, #0x8]
101541334: 52800348    	mov	w8, #0x1a               ; =26
101541338: f9000ee8    	str	x8, [x23, #0x18]
10154133c: 17fff77d    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541340: d280000a    	mov	x10, #0x0               ; =0
101541344: d341fd2b    	lsr	x11, x9, #1
101541348: 8b0a016c    	add	x12, x11, x10
10154134c: b86c790d    	ldr	w13, [x8, x12, lsl #2]
101541350: 6b0001bf    	cmp	w13, w0
101541354: 9a8c814a    	csel	x10, x10, x12, hi
101541358: cb0b0129    	sub	x9, x9, x11
10154135c: f100053f    	cmp	x9, #0x1
101541360: 54ffff28    	b.hi	0x101541344 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x24e8>
101541364: b86a7908    	ldr	w8, [x8, x10, lsl #2]
101541368: 6b00011f    	cmp	w8, w0
10154136c: 54000681    	b.ne	0x10154143c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x25e0>
101541370: f941bf41    	ldr	x1, [x26, #0x378]
101541374: eb00003f    	cmp	x1, x0
101541378: 5400cc89    	b.ls	0x101542d08 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3eac>
10154137c: f941bb48    	ldr	x8, [x26, #0x370]
101541380: 52802e09    	mov	w9, #0x170              ; =368
101541384: 9ba92008    	umaddl	x8, w0, w9, x8
101541388: 91057109    	add	x9, x8, #0x15c
10154138c: b9416d08    	ldr	w8, [x8, #0x16c]
101541390: b90253e8    	str	w8, [sp, #0x250]
101541394: 3dc00120    	ldr	q0, [x9]
101541398: 3d8093e0    	str	q0, [sp, #0x240]
10154139c: 5280003b    	mov	w27, #0x1               ; =1
1015413a0: 911183e8    	add	x8, sp, #0x460
1015413a4: 910903e0    	add	x0, sp, #0x240
1015413a8: 94440cc3    	bl	0x1026446b4 <__RNvMs1_NtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact16fusion_semantics5factsNtB5_18NativeProgramFacts18control_successors>
1015413ac: b9404ac8    	ldr	w8, [x22, #0x48]
1015413b0: b94463e9    	ldr	w9, [sp, #0x460]
1015413b4: 7100053f    	cmp	w9, #0x1
1015413b8: 54000081    	b.ne	0x1015413c8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x256c>
1015413bc: b94467e9    	ldr	w9, [sp, #0x464]
1015413c0: 6b08013f    	cmp	w9, w8
1015413c4: 540000e0    	b.eq	0x1015413e0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2584>
1015413c8: b9446be9    	ldr	w9, [sp, #0x468]
1015413cc: 7100053f    	cmp	w9, #0x1
1015413d0: 54000361    	b.ne	0x10154143c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x25e0>
1015413d4: b9446fe9    	ldr	w9, [sp, #0x46c]
1015413d8: 6b08013f    	cmp	w9, w8
1015413dc: 54000301    	b.ne	0x10154143c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x25e0>
1015413e0: f9426bfc    	ldr	x28, [sp, #0x4d0]
1015413e4: f100039f    	cmp	x28, #0x0
1015413e8: 1a9f17fa    	cset	w26, eq
1015413ec: b40013fc    	cbz	x28, 0x101541668 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x280c>
1015413f0: 3dc137e0    	ldr	q0, [sp, #0x4d0]
1015413f4: 3dc13be1    	ldr	q1, [sp, #0x4e0]
1015413f8: ad1207e0    	stp	q0, q1, [sp, #0x240]
1015413fc: 3dc13fe0    	ldr	q0, [sp, #0x4f0]
101541400: 3dc143e1    	ldr	q1, [sp, #0x500]
101541404: ad1307e0    	stp	q0, q1, [sp, #0x260]
101541408: b9404ec1    	ldr	w1, [x22, #0x4c]
10154140c: 911183e8    	add	x8, sp, #0x460
101541410: 9103c280    	add	x0, x20, #0xf0
101541414: 910903e2    	add	x2, sp, #0x240
101541418: 910be283    	add	x3, x20, #0x2f8
10154141c: 94001846    	bl	0x101547534 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena3put>
101541420: 395183e8    	ldrb	w8, [sp, #0x460]
101541424: 7100511f    	cmp	w8, #0x14
101541428: 54001501    	b.ne	0x1015416c8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x286c>
10154142c: 5280001b    	mov	w27, #0x0               ; =0
101541430: 910903e0    	add	x0, sp, #0x240
101541434: 97ff8252    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
101541438: 14000092    	b	0x101541680 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2824>
10154143c: b900027f    	str	wzr, [x19]
101541440: 52800189    	mov	w9, #0xc                ; =12
101541444: 39002269    	strb	w9, [x19, #0x8]
101541448: b000d7a8    	adrp	x8, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
10154144c: 912a5d08    	add	x8, x8, #0xa97
101541450: 528005a9    	mov	w9, #0x2d               ; =45
101541454: a9012668    	stp	x8, x9, [x19, #0x10]
101541458: f9426be8    	ldr	x8, [sp, #0x4d0]
10154145c: b4fee6a8    	cbz	x8, 0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541460: 911343e0    	add	x0, sp, #0x4d0
101541464: 97ff8246    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
101541468: 17fff732    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154146c: f1000adf    	cmp	x22, #0x2
101541470: 54000880    	b.eq	0x101541580 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2724>
101541474: f1004adf    	cmp	x22, #0x12
101541478: 54000a81    	b.ne	0x1015415c8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x276c>
10154147c: f9402fe8    	ldr	x8, [sp, #0x58]
101541480: f9424908    	ldr	x8, [x8, #0x490]
101541484: 39518108    	ldrb	w8, [x8, #0x460]
101541488: 370000c8    	tbnz	w8, #0x0, 0x1015414a0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2644>
10154148c: a9402708    	ldp	x8, x9, [x24]
101541490: f9400b0a    	ldr	x10, [x24, #0x10]
101541494: aa090108    	orr	x8, x8, x9
101541498: aa0a0108    	orr	x8, x8, x10
10154149c: b4004f88    	cbz	x8, 0x101541e8c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3030>
1015414a0: b900027f    	str	wzr, [x19]
1015414a4: 52800188    	mov	w8, #0xc                ; =12
1015414a8: 39002268    	strb	w8, [x19, #0x8]
1015414ac: b000d7a8    	adrp	x8, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
1015414b0: 911dcd08    	add	x8, x8, #0x773
1015414b4: 528005a9    	mov	w9, #0x2d               ; =45
1015414b8: 17fffa5f    	b	0x10153fe34 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfd8>
1015414bc: f0012442    	adrp	x2, 0x1039cc000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.291+0x310>
1015414c0: 913a0042    	add	x2, x2, #0xe80
1015414c4: aa0903e0    	mov	x0, x9
1015414c8: aa0a03e1    	mov	x1, x10
1015414cc: 9462cb58    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015414d0: b900029f    	str	wzr, [x20]
1015414d4: 52800188    	mov	w8, #0xc                ; =12
1015414d8: 39002288    	strb	w8, [x20, #0x8]
1015414dc: f000d788    	adrp	x8, 0x103034000 <_anon.369b439a638cb010e9292f03e79ebf78.107+0xf6b>
1015414e0: 913c8908    	add	x8, x8, #0xf22
1015414e4: 528005a9    	mov	w9, #0x2d               ; =45
1015414e8: a9012688    	stp	x8, x9, [x20, #0x10]
1015414ec: 14000017    	b	0x101541548 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x26ec>
1015414f0: 3cc04360    	ldur	q0, [x27, #0x4]
1015414f4: 3cc14361    	ldur	q1, [x27, #0x14]
1015414f8: ad1207e0    	stp	q0, q1, [sp, #0x240]
1015414fc: b944f7e9    	ldr	w9, [sp, #0x4f4]
101541500: b90263e9    	str	w9, [sp, #0x260]
101541504: f9427fea    	ldr	x10, [sp, #0x4f8]
101541508: 3c814280    	stur	q0, [x20, #0x14]
10154150c: 3c824281    	stur	q1, [x20, #0x24]
101541510: b9003689    	str	w9, [x20, #0x34]
101541514: b900029f    	str	wzr, [x20]
101541518: 528001a9    	mov	w9, #0xd                ; =13
10154151c: 39002289    	strb	w9, [x20, #0x8]
101541520: b9001288    	str	w8, [x20, #0x10]
101541524: f9001e8a    	str	x10, [x20, #0x38]
101541528: f9431be8    	ldr	x8, [sp, #0x630]
10154152c: 92800009    	mov	x9, #-0x1               ; =-1
101541530: f8690108    	ldaddl	x9, x8, [x8]
101541534: f100051f    	cmp	x8, #0x1
101541538: 54000081    	b.ne	0x101541548 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x26ec>
10154153c: d50339bf    	dmb	ishld
101541540: 9118c3e0    	add	x0, sp, #0x630
101541544: 945ec5bc    	bl	0x102cf2c34 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101541548: 910583e0    	add	x0, sp, #0x160
10154154c: 97ff820c    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
101541550: 17fff6f8    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541554: f9402fe8    	ldr	x8, [sp, #0x58]
101541558: f9424908    	ldr	x8, [x8, #0x490]
10154155c: 39518108    	ldrb	w8, [x8, #0x460]
101541560: 36001c08    	tbz	w8, #0x0, 0x1015418e0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2a84>
101541564: b900027f    	str	wzr, [x19]
101541568: 52800188    	mov	w8, #0xc                ; =12
10154156c: 39002268    	strb	w8, [x19, #0x8]
101541570: b000d7a8    	adrp	x8, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
101541574: 911d6d08    	add	x8, x8, #0x75b
101541578: 52800309    	mov	w9, #0x18               ; =24
10154157c: 17fffa2e    	b	0x10153fe34 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfd8>
101541580: f9402fe8    	ldr	x8, [sp, #0x58]
101541584: f9424908    	ldr	x8, [x8, #0x490]
101541588: 39518108    	ldrb	w8, [x8, #0x460]
10154158c: 370024c8    	tbnz	w8, #0x0, 0x101541a24 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2bc8>
101541590: f9400b08    	ldr	x8, [x24, #0x10]
101541594: b5002488    	cbnz	x8, 0x101541a24 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2bc8>
101541598: a9401303    	ldp	x3, x4, [x24]
10154159c: aa1303e0    	mov	x0, x19
1015415a0: f9402fe1    	ldr	x1, [sp, #0x58]
1015415a4: aa1403e2    	mov	x2, x20
1015415a8: 911d03ff    	add	sp, sp, #0x740
1015415ac: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1015415b0: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1015415b4: a94357f6    	ldp	x22, x21, [sp, #0x30]
1015415b8: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1015415bc: a94167fa    	ldp	x26, x25, [sp, #0x10]
1015415c0: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1015415c4: 17ffb01e    	b	0x10152d63c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation17collection_helper>
1015415c8: f9400305    	ldr	x5, [x24]
1015415cc: aa1303e0    	mov	x0, x19
1015415d0: f9402fe1    	ldr	x1, [sp, #0x58]
1015415d4: aa1403e2    	mov	x2, x20
1015415d8: aa1603e3    	mov	x3, x22
1015415dc: aa1503e4    	mov	x4, x21
1015415e0: 911d03ff    	add	sp, sp, #0x740
1015415e4: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1015415e8: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1015415ec: a94357f6    	ldp	x22, x21, [sp, #0x30]
1015415f0: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1015415f4: a94167fa    	ldp	x26, x25, [sp, #0x10]
1015415f8: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1015415fc: 17ffb0cc    	b	0x10152d92c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper>
101541600: 3cca8300    	ldur	q0, [x24, #0xa8]
101541604: 3c838340    	stur	q0, [x26, #0x38]
101541608: 3ccb8300    	ldur	q0, [x24, #0xb8]
10154160c: 3c848340    	stur	q0, [x26, #0x48]
101541610: 3ccc8300    	ldur	q0, [x24, #0xc8]
101541614: 3c858340    	stur	q0, [x26, #0x58]
101541618: ad5087e0    	ldp	q0, q1, [sp, #0x210]
10154161c: 3c808340    	stur	q0, [x26, #0x8]
101541620: f9429fe9    	ldr	x9, [sp, #0x538]
101541624: 3c818341    	stur	q1, [x26, #0x18]
101541628: 3dc08fe0    	ldr	q0, [sp, #0x230]
10154162c: 3c828340    	stur	q0, [x26, #0x28]
101541630: f90157e9    	str	x9, [sp, #0x2a8]
101541634: f90123e8    	str	x8, [sp, #0x240]
101541638: f100111f    	cmp	x8, #0x4
10154163c: 54002021    	b.ne	0x101541a40 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2be4>
101541640: 910903e0    	add	x0, sp, #0x240
101541644: 97ff84a0    	bl	0x1015228c4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrix31UnsignedMatrixOwnershipTransferECs29QkOtpKx6e_8mech_gpu>
101541648: b900029f    	str	wzr, [x20]
10154164c: 52800188    	mov	w8, #0xc                ; =12
101541650: 39002288    	strb	w8, [x20, #0x8]
101541654: f000d788    	adrp	x8, 0x103034000 <_anon.369b439a638cb010e9292f03e79ebf78.107+0xf6b>
101541658: 913d3d08    	add	x8, x8, #0xf4f
10154165c: 52800509    	mov	w9, #0x28               ; =40
101541660: a9012688    	stp	x8, x9, [x20, #0x10]
101541664: 140001eb    	b	0x101541e10 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fb4>
101541668: f9426aa8    	ldr	x8, [x21, #0x4d0]
10154166c: b4002928    	cbz	x8, 0x101541b90 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d34>
101541670: f9426ea9    	ldr	x9, [x21, #0x4d8]
101541674: b40028e9    	cbz	x9, 0x101541b90 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d34>
101541678: f9426fe9    	ldr	x9, [sp, #0x4d8]
10154167c: f9000109    	str	x9, [x8]
101541680: b9458be8    	ldr	w8, [sp, #0x588]
101541684: 52800029    	mov	w9, #0x1                ; =1
101541688: b902f289    	str	w9, [x20, #0x2f0]
10154168c: b902f688    	str	w8, [x20, #0x2f4]
101541690: 39118289    	strb	w9, [x20, #0x460]
101541694: b9405be8    	ldr	w8, [sp, #0x58]
101541698: 36003f48    	tbz	w8, #0x0, 0x101541e80 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3024>
10154169c: eb1902ff    	cmp	x23, x25
1015416a0: 54003e60    	b.eq	0x101541e6c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3010>
1015416a4: b900027f    	str	wzr, [x19]
1015416a8: 52800188    	mov	w8, #0xc                ; =12
1015416ac: 39002268    	strb	w8, [x19, #0x8]
1015416b0: b000d7a8    	adrp	x8, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
1015416b4: 912b1108    	add	x8, x8, #0xac4
1015416b8: 528004a9    	mov	w9, #0x25               ; =37
1015416bc: a9012668    	stp	x8, x9, [x19, #0x10]
1015416c0: b4ffecdc    	cbz	x28, 0x101541458 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x25fc>
1015416c4: 17fff69b    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015416c8: b8401309    	ldur	w9, [x24, #0x1]
1015416cc: b8009269    	stur	w9, [x19, #0x9]
1015416d0: b94467e9    	ldr	w9, [sp, #0x464]
1015416d4: b9000e69    	str	w9, [x19, #0xc]
1015416d8: 3dc123e0    	ldr	q0, [sp, #0x480]
1015416dc: 3c828260    	stur	q0, [x19, #0x28]
1015416e0: f9424be9    	ldr	x9, [sp, #0x490]
1015416e4: f9001e69    	str	x9, [x19, #0x38]
1015416e8: fd423fe0    	ldr	d0, [sp, #0x478]
1015416ec: 3cc08301    	ldur	q1, [x24, #0x8]
1015416f0: 52800049    	mov	w9, #0x2                ; =2
1015416f4: b9000269    	str	w9, [x19]
1015416f8: 39002268    	strb	w8, [x19, #0x8]
1015416fc: 3d800661    	str	q1, [x19, #0x10]
101541700: fd001260    	str	d0, [x19, #0x20]
101541704: 5280001b    	mov	w27, #0x0               ; =0
101541708: 910903e0    	add	x0, sp, #0x240
10154170c: 97ff819c    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
101541710: 17fff688    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541714: 911343e8    	add	x8, sp, #0x4d0
101541718: 910ee2a0    	add	x0, x21, #0x3b8
10154171c: 94376399    	bl	0x10231a580 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget13memory_budget>
101541720: f9402fe8    	ldr	x8, [sp, #0x58]
101541724: f9401108    	ldr	x8, [x8, #0x20]
101541728: f100051f    	cmp	x8, #0x1
10154172c: 54002401    	b.ne	0x101541bac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d50>
101541730: f9402fe8    	ldr	x8, [sp, #0x58]
101541734: b9404108    	ldr	w8, [x8, #0x40]
101541738: 36004008    	tbz	w8, #0x0, 0x101541f38 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30dc>
10154173c: f9402fe8    	ldr	x8, [sp, #0x58]
101541740: f9401501    	ldr	x1, [x8, #0x28]
101541744: f9402502    	ldr	x2, [x8, #0x48]
101541748: 911863e8    	add	x8, sp, #0x618
10154174c: 911343e0    	add	x0, sp, #0x4d0
101541750: 945e98d1    	bl	0x102ce7a94 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget11with_limits>
101541754: f9426be8    	ldr	x8, [sp, #0x4d0]
101541758: 92800009    	mov	x9, #-0x1               ; =-1
10154175c: f8690108    	ldaddl	x9, x8, [x8]
101541760: f100051f    	cmp	x8, #0x1
101541764: 54000081    	b.ne	0x101541774 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2918>
101541768: d50339bf    	dmb	ishld
10154176c: 911343e0    	add	x0, sp, #0x4d0
101541770: 945ec531    	bl	0x102cf2c34 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101541774: f9430be8    	ldr	x8, [sp, #0x610]
101541778: f9435509    	ldr	x9, [x8, #0x6a8]
10154177c: f144013f    	cmp	x9, #0x100, lsl #12     ; =0x100000
101541780: 54004469    	b.ls	0x10154200c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31b0>
101541784: b000d5e8    	adrp	x8, 0x102ffe000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x1d3>
101541788: 3dc04d00    	ldr	q0, [x8, #0x130]
10154178c: f9402be8    	ldr	x8, [sp, #0x50]
101541790: 3c808100    	stur	q0, [x8, #0x8]
101541794: 528000c9    	mov	w9, #0x6                ; =6
101541798: b9000109    	str	w9, [x8]
10154179c: 14000391    	b	0x1015425e0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3784>
1015417a0: b0012460    	adrp	x0, 0x1039ce000 <_anon.369b439a638cb010e9292f03e79ebf78.685+0x608>
1015417a4: 91004000    	add	x0, x0, #0x10
1015417a8: 9462ca7a    	bl	0x102df4190 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1015417ac: 911343e0    	add	x0, sp, #0x4d0
1015417b0: f9402fe1    	ldr	x1, [sp, #0x58]
1015417b4: aa1403e2    	mov	x2, x20
1015417b8: 97ffee25    	bl	0x10153d04c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation10needs_move>
1015417bc: b944d3e8    	ldr	w8, [sp, #0x4d0]
1015417c0: 36002028    	tbz	w8, #0x0, 0x101541bc4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d68>
1015417c4: b944d7f5    	ldr	w21, [sp, #0x4d4]
1015417c8: b944dbf6    	ldr	w22, [sp, #0x4d8]
1015417cc: 911343e0    	add	x0, sp, #0x4d0
1015417d0: f9402fe1    	ldr	x1, [sp, #0x58]
1015417d4: aa1403e2    	mov	x2, x20
1015417d8: 52800023    	mov	w3, #0x1                ; =1
1015417dc: 52800104    	mov	w4, #0x8                ; =8
1015417e0: d2800005    	mov	x5, #0x0                ; =0
1015417e4: 97ffa107    	bl	0x101529c00 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action>
1015417e8: b944d3e8    	ldr	w8, [sp, #0x4d0]
1015417ec: 7100191f    	cmp	w8, #0x6
1015417f0: 540037e1    	b.ne	0x101541eec <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3090>
1015417f4: f9426fe8    	ldr	x8, [sp, #0x4d8]
1015417f8: f100091f    	cmp	x8, #0x2
1015417fc: 540002c1    	b.ne	0x101541854 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x29f8>
101541800: 911343e0    	add	x0, sp, #0x4d0
101541804: f9402fe1    	ldr	x1, [sp, #0x58]
101541808: aa1503e2    	mov	x2, x21
10154180c: aa1603e3    	mov	x3, x22
101541810: 94002d5b    	bl	0x10154cd7c <__RNvMs_NtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation5joins6mappedNtB8_10Invocation15move_joined_map>
101541814: b944d3e9    	ldr	w9, [sp, #0x4d0]
101541818: 395353e8    	ldrb	w8, [sp, #0x4d4]
10154181c: 7100193f    	cmp	w9, #0x6
101541820: 54005481    	b.ne	0x1015422b0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3454>
101541824: 37000548    	tbnz	w8, #0x0, 0x1015418cc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2a70>
101541828: f9402fe8    	ldr	x8, [sp, #0x58]
10154182c: f9424908    	ldr	x8, [x8, #0x490]
101541830: 911343e0    	add	x0, sp, #0x4d0
101541834: 9103c101    	add	x1, x8, #0xf0
101541838: 910be104    	add	x4, x8, #0x2f8
10154183c: aa1503e2    	mov	x2, x21
101541840: aa1603e3    	mov	x3, x22
101541844: 94001318    	bl	0x1015464a4 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena15copy_current_to>
101541848: 395343e8    	ldrb	w8, [sp, #0x4d0]
10154184c: 7100511f    	cmp	w8, #0x14
101541850: 54006081    	b.ne	0x101542460 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3604>
101541854: f941bee1    	ldr	x1, [x23, #0x378]
101541858: eb01029f    	cmp	x20, x1
10154185c: 5400b362    	b.hs	0x101542ec8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x406c>
101541860: f941bae8    	ldr	x8, [x23, #0x370]
101541864: 52802e09    	mov	w9, #0x170              ; =368
101541868: 9b092288    	madd	x8, x20, x9, x8
10154186c: a940250a    	ldp	x10, x9, [x8]
101541870: 5280022b    	mov	w11, #0x11              ; =17
101541874: ca0b014a    	eor	x10, x10, x11
101541878: aa090149    	orr	x9, x10, x9
10154187c: b5000289    	cbnz	x9, 0x1015418cc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2a70>
101541880: f941c6e1    	ldr	x1, [x23, #0x388]
101541884: b9401102    	ldr	w2, [x8, #0x10]
101541888: eb02003f    	cmp	x1, x2
10154188c: 5400b3e9    	b.ls	0x101542f08 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x40ac>
101541890: f941c2e8    	ldr	x8, [x23, #0x380]
101541894: 52803009    	mov	w9, #0x180              ; =384
101541898: 9ba92048    	umaddl	x8, w2, w9, x8
10154189c: a9402508    	ldp	x8, x9, [x8]
1015418a0: 528000aa    	mov	w10, #0x5               ; =5
1015418a4: ca0a0108    	eor	x8, x8, x10
1015418a8: aa090108    	orr	x8, x8, x9
1015418ac: b5000108    	cbnz	x8, 0x1015418cc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2a70>
1015418b0: 911343e0    	add	x0, sp, #0x4d0
1015418b4: f9402fe1    	ldr	x1, [sp, #0x58]
1015418b8: 52800023    	mov	w3, #0x1                ; =1
1015418bc: 97ffef72    	bl	0x10153d684 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals>
1015418c0: b944d3e8    	ldr	w8, [sp, #0x4d0]
1015418c4: 7100191f    	cmp	w8, #0x6
1015418c8: 54005ba1    	b.ne	0x10154243c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35e0>
1015418cc: f9402fe8    	ldr	x8, [sp, #0x58]
1015418d0: f9424908    	ldr	x8, [x8, #0x490]
1015418d4: 52800029    	mov	w9, #0x1                ; =1
1015418d8: 39118109    	strb	w9, [x8, #0x460]
1015418dc: 17fffa88    	b	0x1015402fc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14a0>
1015418e0: f941bee1    	ldr	x1, [x23, #0x378]
1015418e4: eb01029f    	cmp	x20, x1
1015418e8: 5400a502    	b.hs	0x101542d88 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3f2c>
1015418ec: f941bae8    	ldr	x8, [x23, #0x370]
1015418f0: 52802e09    	mov	w9, #0x170              ; =368
1015418f4: 9b092299    	madd	x25, x20, x9, x8
1015418f8: a9402329    	ldp	x9, x8, [x25]
1015418fc: f100093f    	cmp	x9, #0x2
101541900: fa1f011f    	sbcs	xzr, x8, xzr
101541904: 540016e2    	b.hs	0x101541be0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d84>
101541908: f9400309    	ldr	x9, [x24]
10154190c: f9402fe8    	ldr	x8, [sp, #0x58]
101541910: f9426915    	ldr	x21, [x8, #0x4d0]
101541914: eb15013f    	cmp	x9, x21
101541918: 54003041    	b.ne	0x101541f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30c4>
10154191c: f9400716    	ldr	x22, [x24, #0x8]
101541920: f9409728    	ldr	x8, [x25, #0x128]
101541924: eb0802df    	cmp	x22, x8
101541928: 54002fc1    	b.ne	0x101541f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30c4>
10154192c: f9400b09    	ldr	x9, [x24, #0x10]
101541930: b5002f89    	cbnz	x9, 0x101541f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30c4>
101541934: f9402fe9    	ldr	x9, [sp, #0x58]
101541938: f9426d29    	ldr	x9, [x9, #0x4d8]
10154193c: eb09011f    	cmp	x8, x9
101541940: 54002f08    	b.hi	0x101541f20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30c4>
101541944: f9409337    	ldr	x23, [x25, #0x120]
101541948: 911343e0    	add	x0, sp, #0x4d0
10154194c: f9402fe1    	ldr	x1, [sp, #0x58]
101541950: aa1403e2    	mov	x2, x20
101541954: aa1503e3    	mov	x3, x21
101541958: aa1603e4    	mov	x4, x22
10154195c: 97ffa5e0    	bl	0x10152b0dc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation14selected_callsNtB4_10Invocation21prepared_library_call>
101541960: b944d3e8    	ldr	w8, [sp, #0x4d0]
101541964: 7100191f    	cmp	w8, #0x6
101541968: 54002c21    	b.ne	0x101541eec <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3090>
10154196c: f9426fe8    	ldr	x8, [sp, #0x4d8]
101541970: f100091f    	cmp	x8, #0x2
101541974: 54004341    	b.ne	0x1015421dc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3380>
101541978: 911343e0    	add	x0, sp, #0x4d0
10154197c: f9402fe1    	ldr	x1, [sp, #0x58]
101541980: aa1403e2    	mov	x2, x20
101541984: aa1503e3    	mov	x3, x21
101541988: aa1603e4    	mov	x4, x22
10154198c: 97ffd23d    	bl	0x101536280 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime5lines10line_callsNtNtB6_10invocation10Invocation16line_matrix_call>
101541990: b944d3e8    	ldr	w8, [sp, #0x4d0]
101541994: 7100191f    	cmp	w8, #0x6
101541998: 54002aa1    	b.ne	0x101541eec <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3090>
10154199c: f9426fe8    	ldr	x8, [sp, #0x4d8]
1015419a0: f100091f    	cmp	x8, #0x2
1015419a4: 540041c1    	b.ne	0x1015421dc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3380>
1015419a8: 911343e0    	add	x0, sp, #0x4d0
1015419ac: f9402fe1    	ldr	x1, [sp, #0x58]
1015419b0: aa1403e2    	mov	x2, x20
1015419b4: aa1503e3    	mov	x3, x21
1015419b8: aa1603e4    	mov	x4, x22
1015419bc: 97ffe388    	bl	0x10153a7dc <__RNvMNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime7session7capture14captured_callsNtNtB8_10invocation10Invocation26captured_line_element_call>
1015419c0: b944d3e9    	ldr	w9, [sp, #0x4d0]
1015419c4: 395353e8    	ldrb	w8, [sp, #0x4d4]
1015419c8: 7100193f    	cmp	w9, #0x6
1015419cc: 54004721    	b.ne	0x1015422b0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3454>
1015419d0: 3707f7e8    	tbnz	w8, #0x0, 0x1015418cc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2a70>
1015419d4: 911343e0    	add	x0, sp, #0x4d0
1015419d8: f9402fe1    	ldr	x1, [sp, #0x58]
1015419dc: aa1403e2    	mov	x2, x20
1015419e0: aa1503e3    	mov	x3, x21
1015419e4: aa1603e4    	mov	x4, x22
1015419e8: 94002319    	bl	0x10154a64c <__RNvMs_NtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation18selected_join_call>
1015419ec: b944d3e9    	ldr	w9, [sp, #0x4d0]
1015419f0: 395353e8    	ldrb	w8, [sp, #0x4d4]
1015419f4: 7100193f    	cmp	w9, #0x6
1015419f8: 540045c1    	b.ne	0x1015422b0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3454>
1015419fc: 360062e8    	tbz	w8, #0x0, 0x101542658 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x37fc>
101541a00: f9402fe8    	ldr	x8, [sp, #0x58]
101541a04: f9424909    	ldr	x9, [x8, #0x490]
101541a08: 5280002a    	mov	w10, #0x1               ; =1
101541a0c: 3911812a    	strb	w10, [x9, #0x460]
101541a10: f9414908    	ldr	x8, [x8, #0x290]
101541a14: f100111f    	cmp	x8, #0x4
101541a18: 1a9f17e8    	cset	w8, eq
101541a1c: a900aa68    	stp	x8, x10, [x19, #0x8]
101541a20: 17fffa38    	b	0x101540300 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14a4>
101541a24: b900027f    	str	wzr, [x19]
101541a28: 52800188    	mov	w8, #0xc                ; =12
101541a2c: 39002268    	strb	w8, [x19, #0x8]
101541a30: b000d7a8    	adrp	x8, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
101541a34: 911b8908    	add	x8, x8, #0x6e2
101541a38: 52800369    	mov	w9, #0x1b               ; =27
101541a3c: 17fff8fe    	b	0x10153fe34 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfd8>
101541a40: ad5407e0    	ldp	q0, q1, [sp, #0x280]
101541a44: ad0f07e0    	stp	q0, q1, [sp, #0x1e0]
101541a48: 3dc0abe0    	ldr	q0, [sp, #0x2a0]
101541a4c: 3d8083e0    	str	q0, [sp, #0x200]
101541a50: ad5207e0    	ldp	q0, q1, [sp, #0x240]
101541a54: ad0d07e0    	stp	q0, q1, [sp, #0x1a0]
101541a58: ad5303e1    	ldp	q1, q0, [sp, #0x260]
101541a5c: ad0e03e1    	stp	q1, q0, [sp, #0x1c0]
101541a60: f8756ac0    	ldr	x0, [x22, x21]
101541a64: f94017e8    	ldr	x8, [sp, #0x28]
101541a68: eb08001f    	cmp	x0, x8
101541a6c: 54009962    	b.hs	0x101542d98 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3f3c>
101541a70: 52800308    	mov	w8, #0x18               ; =24
101541a74: f94013e9    	ldr	x9, [sp, #0x20]
101541a78: 9b082408    	madd	x8, x0, x8, x9
101541a7c: 39404908    	ldrb	w8, [x8, #0x12]
101541a80: 36000bc8    	tbz	w8, #0x0, 0x101541bf8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d9c>
101541a84: f9402fe8    	ldr	x8, [sp, #0x58]
101541a88: f9424908    	ldr	x8, [x8, #0x490]
101541a8c: f941e108    	ldr	x8, [x8, #0x3c0]
101541a90: b4001ae8    	cbz	x8, 0x101541dec <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f90>
101541a94: f9402109    	ldr	x9, [x8, #0x40]
101541a98: f100093f    	cmp	x9, #0x2
101541a9c: 54001a80    	b.eq	0x101541dec <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f90>
101541aa0: f9406d0a    	ldr	x10, [x8, #0xd8]
101541aa4: f9402be9    	ldr	x9, [sp, #0x50]
101541aa8: eb09015f    	cmp	x10, x9
101541aac: 54001a01    	b.ne	0x101541dec <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f90>
101541ab0: f9404109    	ldr	x9, [x8, #0x80]
101541ab4: d2f0000a    	mov	x10, #-0x8000000000000000 ; =-9223372036854775808
101541ab8: eb0a013f    	cmp	x9, x10
101541abc: 54001980    	b.eq	0x101541dec <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f90>
101541ac0: f9404909    	ldr	x9, [x8, #0x90]
101541ac4: eb09001f    	cmp	x0, x9
101541ac8: 54001922    	b.hs	0x101541dec <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f90>
101541acc: f9404508    	ldr	x8, [x8, #0x88]
101541ad0: 52800e09    	mov	w9, #0x70               ; =112
101541ad4: 9b092008    	madd	x8, x0, x9, x8
101541ad8: f940010b    	ldr	x11, [x8]
101541adc: fd400500    	ldr	d0, [x8, #0x8]
101541ae0: 3940410c    	ldrb	w12, [x8, #0x10]
101541ae4: a941a909    	ldp	x9, x10, [x8, #0x18]
101541ae8: f900011f    	str	xzr, [x8]
101541aec: b40052ab    	cbz	x11, 0x101542540 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x36e4>
101541af0: 3cc58101    	ldur	q1, [x8, #0x58]
101541af4: 3c8f8321    	stur	q1, [x25, #0xf8]
101541af8: f940350d    	ldr	x13, [x8, #0x68]
101541afc: f9022fed    	str	x13, [sp, #0x458]
101541b00: f901fbeb    	str	x11, [sp, #0x3f0]
101541b04: fd01ffe0    	str	d0, [sp, #0x3f8]
101541b08: 391003ec    	strb	w12, [sp, #0x400]
101541b0c: b841110b    	ldur	w11, [x8, #0x11]
101541b10: b80b132b    	stur	w11, [x25, #0xb1]
101541b14: b940150b    	ldr	w11, [x8, #0x14]
101541b18: b90407eb    	str	w11, [sp, #0x404]
101541b1c: f90207e9    	str	x9, [sp, #0x408]
101541b20: f9020bea    	str	x10, [sp, #0x410]
101541b24: 3cc28100    	ldur	q0, [x8, #0x28]
101541b28: 3c8c8320    	stur	q0, [x25, #0xc8]
101541b2c: 3cc38100    	ldur	q0, [x8, #0x38]
101541b30: 3c8d8320    	stur	q0, [x25, #0xd8]
101541b34: 3cc48100    	ldur	q0, [x8, #0x48]
101541b38: 3c8e8320    	stur	q0, [x25, #0xe8]
101541b3c: ad4f07e0    	ldp	q0, q1, [sp, #0x1e0]
101541b40: 3d812be0    	str	q0, [sp, #0x4a0]
101541b44: 3d812fe1    	str	q1, [sp, #0x4b0]
101541b48: 3dc083e0    	ldr	q0, [sp, #0x200]
101541b4c: 3d8133e0    	str	q0, [sp, #0x4c0]
101541b50: ad4d07e0    	ldp	q0, q1, [sp, #0x1a0]
101541b54: 3d811be0    	str	q0, [sp, #0x460]
101541b58: 3d811fe1    	str	q1, [sp, #0x470]
101541b5c: ad4e03e1    	ldp	q1, q0, [sp, #0x1c0]
101541b60: 3d8127e0    	str	q0, [sp, #0x490]
101541b64: 3d8123e1    	str	q1, [sp, #0x480]
101541b68: 911343e8    	add	x8, sp, #0x4d0
101541b6c: 911183e0    	add	x0, sp, #0x460
101541b70: 910fc3e3    	add	x3, sp, #0x3f0
101541b74: f94023e1    	ldr	x1, [sp, #0x40]
101541b78: aa1703e2    	mov	x2, x23
101541b7c: 94602863    	bl	0x102d4bd08 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrixNtB2_27OwnedSnapshotUnsignedMatrix20into_private_appends>
101541b80: 1400002e    	b	0x101541c38 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2ddc>
101541b84: 90012460    	adrp	x0, 0x1039cd000 <_anon.369b439a638cb010e9292f03e79ebf78.285+0x710>
101541b88: 913f2000    	add	x0, x0, #0xfc8
101541b8c: 9462c981    	bl	0x102df4190 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
101541b90: b900027f    	str	wzr, [x19]
101541b94: 52800189    	mov	w9, #0xc                ; =12
101541b98: 39002269    	strb	w9, [x19, #0x8]
101541b9c: 9000d7a8    	adrp	x8, 0x103035000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x4a0>
101541ba0: 910e9908    	add	x8, x8, #0x3a6
101541ba4: 52800529    	mov	w9, #0x29               ; =41
101541ba8: 17fffe2b    	b	0x101541454 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x25f8>
101541bac: d000d788    	adrp	x8, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101541bb0: 91326908    	add	x8, x8, #0xc9a
101541bb4: 140000e3    	b	0x101541f40 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30e4>
101541bb8: b0012460    	adrp	x0, 0x1039ce000 <_anon.369b439a638cb010e9292f03e79ebf78.685+0x608>
101541bbc: 91010000    	add	x0, x0, #0x40
101541bc0: 9462c974    	bl	0x102df4190 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
101541bc4: b900027f    	str	wzr, [x19]
101541bc8: 52800188    	mov	w8, #0xc                ; =12
101541bcc: b9000a68    	str	w8, [x19, #0x8]
101541bd0: d000d788    	adrp	x8, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101541bd4: 91319508    	add	x8, x8, #0xc65
101541bd8: 52800429    	mov	w9, #0x21               ; =33
101541bdc: 17fff896    	b	0x10153fe34 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfd8>
101541be0: b900027f    	str	wzr, [x19]
101541be4: 52800188    	mov	w8, #0xc                ; =12
101541be8: 39002268    	strb	w8, [x19, #0x8]
101541bec: b000d7a8    	adrp	x8, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
101541bf0: 911cdd08    	add	x8, x8, #0x737
101541bf4: 17fffbdc    	b	0x101540b64 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1d08>
101541bf8: ad4f07e0    	ldp	q0, q1, [sp, #0x1e0]
101541bfc: 3d812be0    	str	q0, [sp, #0x4a0]
101541c00: 3d812fe1    	str	q1, [sp, #0x4b0]
101541c04: 3dc083e0    	ldr	q0, [sp, #0x200]
101541c08: 3d8133e0    	str	q0, [sp, #0x4c0]
101541c0c: ad4d07e0    	ldp	q0, q1, [sp, #0x1a0]
101541c10: 3d811be0    	str	q0, [sp, #0x460]
101541c14: 3d811fe1    	str	q1, [sp, #0x470]
101541c18: ad4e03e1    	ldp	q1, q0, [sp, #0x1c0]
101541c1c: 3d8127e0    	str	q0, [sp, #0x490]
101541c20: 3d8123e1    	str	q1, [sp, #0x480]
101541c24: 911343e8    	add	x8, sp, #0x4d0
101541c28: 911183e0    	add	x0, sp, #0x460
101541c2c: f94023e1    	ldr	x1, [sp, #0x40]
101541c30: aa1703e2    	mov	x2, x23
101541c34: 9460284d    	bl	0x102d4bd68 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrixNtB2_27OwnedSnapshotUnsignedMatrix20into_private_updates>
101541c38: f9426be8    	ldr	x8, [sp, #0x4d0]
101541c3c: b4001a08    	cbz	x8, 0x101541f7c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3120>
101541c40: b944dbe9    	ldr	w9, [sp, #0x4d8]
101541c44: 3cc8c300    	ldur	q0, [x24, #0x8c]
101541c48: 3cc9c301    	ldur	q1, [x24, #0x9c]
101541c4c: 3ccac302    	ldur	q2, [x24, #0xac]
101541c50: ad1e0be1    	stp	q1, q2, [sp, #0x3c0]
101541c54: 3ccb8301    	ldur	q1, [x24, #0xb8]
101541c58: 3c88c321    	stur	q1, [x25, #0x8c]
101541c5c: 3cc7c301    	ldur	q1, [x24, #0x7c]
101541c60: ad1d03e1    	stp	q1, q0, [sp, #0x3a0]
101541c64: 3ccc8360    	ldur	q0, [x27, #0xc8]
101541c68: 3c8c8340    	stur	q0, [x26, #0xc8]
101541c6c: 3ccd8360    	ldur	q0, [x27, #0xd8]
101541c70: 3c8d8340    	stur	q0, [x26, #0xd8]
101541c74: 3cce8360    	ldur	q0, [x27, #0xe8]
101541c78: 3c8e8340    	stur	q0, [x26, #0xe8]
101541c7c: 3ccf8360    	ldur	q0, [x27, #0xf8]
101541c80: 3c8f8340    	stur	q0, [x26, #0xf8]
101541c84: 3cc88360    	ldur	q0, [x27, #0x88]
101541c88: 3c888340    	stur	q0, [x26, #0x88]
101541c8c: 3cc98360    	ldur	q0, [x27, #0x98]
101541c90: 3c898340    	stur	q0, [x26, #0x98]
101541c94: 3cca8360    	ldur	q0, [x27, #0xa8]
101541c98: 3c8a8340    	stur	q0, [x26, #0xa8]
101541c9c: 3ccb8360    	ldur	q0, [x27, #0xb8]
101541ca0: 3c8b8340    	stur	q0, [x26, #0xb8]
101541ca4: 3cc58360    	ldur	q0, [x27, #0x58]
101541ca8: 3c858340    	stur	q0, [x26, #0x58]
101541cac: 3cc68360    	ldur	q0, [x27, #0x68]
101541cb0: 3c868340    	stur	q0, [x26, #0x68]
101541cb4: 3cc78360    	ldur	q0, [x27, #0x78]
101541cb8: 3c878340    	stur	q0, [x26, #0x78]
101541cbc: 3cc8c320    	ldur	q0, [x25, #0x8c]
101541cc0: 3c83c320    	stur	q0, [x25, #0x3c]
101541cc4: ad5e03e1    	ldp	q1, q0, [sp, #0x3c0]
101541cc8: ad1b83e1    	stp	q1, q0, [sp, #0x370]
101541ccc: ad5d03e2    	ldp	q2, q0, [sp, #0x3a0]
101541cd0: ad1a83e2    	stp	q2, q0, [sp, #0x350]
101541cd4: 3c81c340    	stur	q0, [x26, #0x1c]
101541cd8: 3c82c341    	stur	q1, [x26, #0x2c]
101541cdc: 3c80c342    	stur	q2, [x26, #0xc]
101541ce0: 3dc0e3e0    	ldr	q0, [sp, #0x380]
101541ce4: 3c83c340    	stur	q0, [x26, #0x3c]
101541ce8: 3cc3c320    	ldur	q0, [x25, #0x3c]
101541cec: 3c848340    	stur	q0, [x26, #0x48]
101541cf0: f90123e8    	str	x8, [sp, #0x240]
101541cf4: b9024be9    	str	w9, [sp, #0x248]
101541cf8: f8756ac1    	ldr	x1, [x22, x21]
101541cfc: aa1303e0    	mov	x0, x19
101541d00: 940164c6    	bl	0x10159b018 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7prepare16readonly_numericNtB2_5Proof8capacity>
101541d04: f100041f    	cmp	x0, #0x1
101541d08: 54001c61    	b.ne	0x101542094 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3238>
101541d0c: aa0103f3    	mov	x19, x1
101541d10: 911343e8    	add	x8, sp, #0x4d0
101541d14: 910903e0    	add	x0, sp, #0x240
101541d18: 945e9d14    	bl	0x102ce9168 <__RNvMs0_NtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix7appendsNtB7_21PrivateUnsignedMatrix20reserved_native_view>
101541d1c: b944d3e8    	ldr	w8, [sp, #0x4d0]
101541d20: 36002a48    	tbz	w8, #0x0, 0x101542268 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x340c>
101541d24: f9402fe8    	ldr	x8, [sp, #0x58]
101541d28: f942690a    	ldr	x10, [x8, #0x4d0]
101541d2c: b4002aca    	cbz	x10, 0x101542284 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3428>
101541d30: f8756ac8    	ldr	x8, [x22, x21]
101541d34: f9405389    	ldr	x9, [x28, #0xa0]
101541d38: 8b080928    	add	x8, x9, x8, lsl #2
101541d3c: 91000d0b    	add	x11, x8, #0x3
101541d40: f9402fe8    	ldr	x8, [sp, #0x58]
101541d44: f9426d08    	ldr	x8, [x8, #0x4d8]
101541d48: eb08017f    	cmp	x11, x8
101541d4c: 540029c2    	b.hs	0x101542284 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3428>
101541d50: f9426ff8    	ldr	x24, [sp, #0x4d8]
101541d54: f94273e9    	ldr	x9, [sp, #0x4e0]
101541d58: f94277e8    	ldr	x8, [sp, #0x4e8]
101541d5c: f82b7949    	str	x9, [x10, x11, lsl #3]
101541d60: f9402fea    	ldr	x10, [sp, #0x58]
101541d64: f942694a    	ldr	x10, [x10, #0x4d0]
101541d68: b40028ea    	cbz	x10, 0x101542284 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3428>
101541d6c: f8756acb    	ldr	x11, [x22, x21]
101541d70: f940538c    	ldr	x12, [x28, #0xa0]
101541d74: 8b0b098b    	add	x11, x12, x11, lsl #2
101541d78: 9100116b    	add	x11, x11, #0x4
101541d7c: f9402fec    	ldr	x12, [sp, #0x58]
101541d80: f9426d8c    	ldr	x12, [x12, #0x4d8]
101541d84: eb0c017f    	cmp	x11, x12
101541d88: 540027e2    	b.hs	0x101542284 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3428>
101541d8c: 5280002c    	mov	w12, #0x1               ; =1
101541d90: f82b794c    	str	x12, [x10, x11, lsl #3]
101541d94: f9402fea    	ldr	x10, [sp, #0x58]
101541d98: f942694a    	ldr	x10, [x10, #0x4d0]
101541d9c: b400274a    	cbz	x10, 0x101542284 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3428>
101541da0: f8756acb    	ldr	x11, [x22, x21]
101541da4: f940538c    	ldr	x12, [x28, #0xa0]
101541da8: 8b0b098b    	add	x11, x12, x11, lsl #2
101541dac: 9100156b    	add	x11, x11, #0x5
101541db0: f9402fec    	ldr	x12, [sp, #0x58]
101541db4: f9426d8c    	ldr	x12, [x12, #0x4d8]
101541db8: eb0c017f    	cmp	x11, x12
101541dbc: 54002642    	b.hs	0x101542284 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3428>
101541dc0: f82b7949    	str	x9, [x10, x11, lsl #3]
101541dc4: f9402fe9    	ldr	x9, [sp, #0x58]
101541dc8: f9426929    	ldr	x9, [x9, #0x4d0]
101541dcc: b40025c9    	cbz	x9, 0x101542284 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3428>
101541dd0: 91000a6a    	add	x10, x19, #0x2
101541dd4: f9402feb    	ldr	x11, [sp, #0x58]
101541dd8: f9426d6b    	ldr	x11, [x11, #0x4d8]
101541ddc: eb0b015f    	cmp	x10, x11
101541de0: 54002522    	b.hs	0x101542284 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3428>
101541de4: f82a7928    	str	x8, [x9, x10, lsl #3]
101541de8: 140000af    	b	0x1015420a4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3248>
101541dec: b900029f    	str	wzr, [x20]
101541df0: 52800189    	mov	w9, #0xc                ; =12
101541df4: f9000689    	str	x9, [x20, #0x8]
101541df8: f000d788    	adrp	x8, 0x103034000 <_anon.369b439a638cb010e9292f03e79ebf78.107+0xf6b>
101541dfc: 9121c108    	add	x8, x8, #0x870
101541e00: 52800609    	mov	w9, #0x30               ; =48
101541e04: a9012688    	stp	x8, x9, [x20, #0x10]
101541e08: 910683e0    	add	x0, sp, #0x1a0
101541e0c: 97ff8265    	bl	0x1015227a0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrix27OwnedSnapshotUnsignedMatrixECs29QkOtpKx6e_8mech_gpu>
101541e10: b40000b7    	cbz	x23, 0x101541e24 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fc8>
101541e14: d37df2e1    	lsl	x1, x23, #3
101541e18: f94023e0    	ldr	x0, [sp, #0x40]
101541e1c: 52800102    	mov	w2, #0x8                ; =8
101541e20: 97ab1dc7    	bl	0x10000953c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
101541e24: b90043ff    	str	wzr, [sp, #0x40]
101541e28: 911943e0    	add	x0, sp, #0x650
101541e2c: 97ff7f4a    	bl	0x101521b54 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs29QkOtpKx6e_8mech_gpu>
101541e30: f9431be8    	ldr	x8, [sp, #0x630]
101541e34: 92800009    	mov	x9, #-0x1               ; =-1
101541e38: f8690108    	ldaddl	x9, x8, [x8]
101541e3c: f100051f    	cmp	x8, #0x1
101541e40: 54fe9781    	b.ne	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541e44: d50339bf    	dmb	ishld
101541e48: 9118c3e0    	add	x0, sp, #0x630
101541e4c: 945ec37a    	bl	0x102cf2c34 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101541e50: 17fff4b8    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541e54: 90012460    	adrp	x0, 0x1039cd000 <_anon.369b439a638cb010e9292f03e79ebf78.285+0x710>
101541e58: 913f8000    	add	x0, x0, #0xfe0
101541e5c: 9462c8cd    	bl	0x102df4190 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
101541e60: 90012460    	adrp	x0, 0x1039cd000 <_anon.369b439a638cb010e9292f03e79ebf78.285+0x710>
101541e64: 913fe000    	add	x0, x0, #0xff8
101541e68: 9462c8ca    	bl	0x102df4190 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
101541e6c: 910f02b4    	add	x20, x21, #0x3c0
101541e70: aa1403e0    	mov	x0, x20
101541e74: 97ff7727    	bl	0x10151fb10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel5BatchEEB1e_>
101541e78: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101541e7c: f9000288    	str	x8, [x20]
101541e80: 52800028    	mov	w8, #0x1                ; =1
101541e84: 4e080d00    	dup.2d	v0, x8
101541e88: 17fff5e3    	b	0x10153f614 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7b8>
101541e8c: 911343e0    	add	x0, sp, #0x4d0
101541e90: f9402fe1    	ldr	x1, [sp, #0x58]
101541e94: aa1403e2    	mov	x2, x20
101541e98: 52800243    	mov	w3, #0x12               ; =18
101541e9c: 52800104    	mov	w4, #0x8                ; =8
101541ea0: d2800005    	mov	x5, #0x0                ; =0
101541ea4: 97ff9f57    	bl	0x101529c00 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action>
101541ea8: b944d3e8    	ldr	w8, [sp, #0x4d0]
101541eac: 7100191f    	cmp	w8, #0x6
101541eb0: 540001e1    	b.ne	0x101541eec <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3090>
101541eb4: f9426fe8    	ldr	x8, [sp, #0x4d8]
101541eb8: f100091f    	cmp	x8, #0x2
101541ebc: 54001901    	b.ne	0x1015421dc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3380>
101541ec0: aa1303e0    	mov	x0, x19
101541ec4: f9402fe1    	ldr	x1, [sp, #0x58]
101541ec8: aa1403e2    	mov	x2, x20
101541ecc: 911d03ff    	add	sp, sp, #0x740
101541ed0: a9457bfd    	ldp	x29, x30, [sp, #0x50]
101541ed4: a9444ff4    	ldp	x20, x19, [sp, #0x40]
101541ed8: a94357f6    	ldp	x22, x21, [sp, #0x30]
101541edc: a9425ff8    	ldp	x24, x23, [sp, #0x20]
101541ee0: a94167fa    	ldp	x26, x25, [sp, #0x10]
101541ee4: a8c66ffc    	ldp	x28, x27, [sp], #0x60
101541ee8: 17ffb13a    	b	0x10152e3d0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation>
101541eec: b944d7e9    	ldr	w9, [sp, #0x4d4]
101541ef0: 3cc18360    	ldur	q0, [x27, #0x18]
101541ef4: 3c818260    	stur	q0, [x19, #0x18]
101541ef8: 3cc28360    	ldur	q0, [x27, #0x28]
101541efc: 3c828260    	stur	q0, [x19, #0x28]
101541f00: 3cc38360    	ldur	q0, [x27, #0x38]
101541f04: 3c838260    	stur	q0, [x19, #0x38]
101541f08: f9428fea    	ldr	x10, [sp, #0x518]
101541f0c: f900266a    	str	x10, [x19, #0x48]
101541f10: 3cc08360    	ldur	q0, [x27, #0x8]
101541f14: 29002668    	stp	w8, w9, [x19]
101541f18: 3c808260    	stur	q0, [x19, #0x8]
101541f1c: 17fff485    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541f20: b900027f    	str	wzr, [x19]
101541f24: 52800188    	mov	w8, #0xc                ; =12
101541f28: 39002268    	strb	w8, [x19, #0x8]
101541f2c: b000d7a8    	adrp	x8, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
101541f30: 911c4d08    	add	x8, x8, #0x713
101541f34: 17fffb0c    	b	0x101540b64 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1d08>
101541f38: d000d788    	adrp	x8, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101541f3c: 9132e108    	add	x8, x8, #0xcb8
101541f40: f9402be9    	ldr	x9, [sp, #0x50]
101541f44: b900013f    	str	wzr, [x9]
101541f48: 5280018a    	mov	w10, #0xc               ; =12
101541f4c: a900a12a    	stp	x10, x8, [x9, #0x8]
101541f50: 528003c8    	mov	w8, #0x1e               ; =30
101541f54: f9000d28    	str	x8, [x9, #0x18]
101541f58: f9426be8    	ldr	x8, [sp, #0x4d0]
101541f5c: 92800009    	mov	x9, #-0x1               ; =-1
101541f60: f8690108    	ldaddl	x9, x8, [x8]
101541f64: f100051f    	cmp	x8, #0x1
101541f68: 54fe8e41    	b.ne	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541f6c: d50339bf    	dmb	ishld
101541f70: 911343e0    	add	x0, sp, #0x4d0
101541f74: 945ec330    	bl	0x102cf2c34 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101541f78: 17fff46e    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541f7c: 911343e8    	add	x8, sp, #0x4d0
101541f80: 3cc08100    	ldur	q0, [x8, #0x8]
101541f84: 3c804300    	stur	q0, [x24, #0x4]
101541f88: 3cc18100    	ldur	q0, [x8, #0x18]
101541f8c: 3c814300    	stur	q0, [x24, #0x14]
101541f90: 3cc28100    	ldur	q0, [x8, #0x28]
101541f94: 3c824300    	stur	q0, [x24, #0x24]
101541f98: 3cc38100    	ldur	q0, [x8, #0x38]
101541f9c: 3c834300    	stur	q0, [x24, #0x34]
101541fa0: f8448108    	ldur	x8, [x8, #0x48]
101541fa4: f8044308    	stur	x8, [x24, #0x44]
101541fa8: 3dc123e0    	ldr	q0, [sp, #0x480]
101541fac: 3dc127e1    	ldr	q1, [sp, #0x490]
101541fb0: ad1e07e0    	stp	q0, q1, [sp, #0x3c0]
101541fb4: 3cc3c300    	ldur	q0, [x24, #0x3c]
101541fb8: 3c88c320    	stur	q0, [x25, #0x8c]
101541fbc: 3dc11fe0    	ldr	q0, [sp, #0x470]
101541fc0: 3dc11be1    	ldr	q1, [sp, #0x460]
101541fc4: ad1d03e1    	stp	q1, q0, [sp, #0x3a0]
101541fc8: ad5d07e0    	ldp	q0, q1, [sp, #0x3a0]
101541fcc: 3cc8c322    	ldur	q2, [x25, #0x8c]
101541fd0: 3c83c322    	stur	q2, [x25, #0x3c]
101541fd4: ad5e0fe2    	ldp	q2, q3, [sp, #0x3c0]
101541fd8: ad1b8fe2    	stp	q2, q3, [sp, #0x370]
101541fdc: ad1a87e0    	stp	q0, q1, [sp, #0x350]
101541fe0: ad5a83e1    	ldp	q1, q0, [sp, #0x350]
101541fe4: 3c814280    	stur	q0, [x20, #0x14]
101541fe8: ad5b8be0    	ldp	q0, q2, [sp, #0x370]
101541fec: 3c824280    	stur	q0, [x20, #0x24]
101541ff0: 3c834282    	stur	q2, [x20, #0x34]
101541ff4: 3cc3c320    	ldur	q0, [x25, #0x3c]
101541ff8: 3d801280    	str	q0, [x20, #0x40]
101541ffc: 3c804281    	stur	q1, [x20, #0x4]
101542000: 528000a8    	mov	w8, #0x5                ; =5
101542004: b9000288    	str	w8, [x20]
101542008: 17ffff87    	b	0x101541e24 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fc8>
10154200c: f9001bff    	str	xzr, [sp, #0x30]
101542010: a94427ef    	ldp	x15, x9, [sp, #0x40]
101542014: d37ef52b    	lsl	x11, x9, #2
101542018: 8b0b01e9    	add	x9, x15, x11
10154201c: f90013e9    	str	x9, [sp, #0x20]
101542020: f942c50c    	ldr	x12, [x8, #0x588]
101542024: f942c10d    	ldr	x13, [x8, #0x580]
101542028: 52800188    	mov	w8, #0xc                ; =12
10154202c: 52800529    	mov	w9, #0x29               ; =41
101542030: 52800b0e    	mov	w14, #0x58              ; =88
101542034: b000d78a    	adrp	x10, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101542038: 9133594a    	add	x10, x10, #0xcd6
10154203c: f9401bf0    	ldr	x16, [sp, #0x30]
101542040: b4000dab    	cbz	x11, 0x1015421f4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3398>
101542044: b84045f1    	ldr	w17, [x15], #0x4
101542048: eb11019f    	cmp	x12, x17
10154204c: 540001a9    	b.ls	0x101542080 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3224>
101542050: 9bae3631    	umaddl	x17, w17, w14, x13
101542054: f9400631    	ldr	x17, [x17, #0x8]
101542058: d100116b    	sub	x11, x11, #0x4
10154205c: f9401be0    	ldr	x0, [sp, #0x30]
101542060: ab000220    	adds	x0, x17, x0
101542064: f9001be0    	str	x0, [sp, #0x30]
101542068: 54fffea3    	b.lo	0x10154203c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31e0>
10154206c: 9278de08    	and	x8, x16, #0xffffffffffffff00
101542070: b27e0508    	orr	x8, x8, #0xc
101542074: b000d78a    	adrp	x10, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101542078: 9133fd4a    	add	x10, x10, #0xcff
10154207c: 528003e9    	mov	w9, #0x1f               ; =31
101542080: f9402beb    	ldr	x11, [sp, #0x50]
101542084: b900017f    	str	wzr, [x11]
101542088: a900a968    	stp	x8, x10, [x11, #0x8]
10154208c: f9000d69    	str	x9, [x11, #0x18]
101542090: 14000154    	b	0x1015425e0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3784>
101542094: 911343e8    	add	x8, sp, #0x4d0
101542098: 910903e0    	add	x0, sp, #0x240
10154209c: 945e9296    	bl	0x102ce6af4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix12elements_mut>
1015420a0: f9426ff8    	ldr	x24, [sp, #0x4d8]
1015420a4: 911343e0    	add	x0, sp, #0x4d0
1015420a8: 910903e1    	add	x1, sp, #0x240
1015420ac: 52802102    	mov	w2, #0x108              ; =264
1015420b0: 9462cdcd    	bl	0x102df57e4 <dyld_stub_binder+0x102df57e4>
1015420b4: f9402fe8    	ldr	x8, [sp, #0x58]
1015420b8: f9424908    	ldr	x8, [x8, #0x490]
1015420bc: f941e108    	ldr	x8, [x8, #0x3c0]
1015420c0: b40007a8    	cbz	x8, 0x1015421b4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3358>
1015420c4: f9402109    	ldr	x9, [x8, #0x40]
1015420c8: f100093f    	cmp	x9, #0x2
1015420cc: 54000740    	b.eq	0x1015421b4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3358>
1015420d0: f9406d0a    	ldr	x10, [x8, #0xd8]
1015420d4: f9402be9    	ldr	x9, [sp, #0x50]
1015420d8: eb09015f    	cmp	x10, x9
1015420dc: 540006c1    	b.ne	0x1015421b4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3358>
1015420e0: f8756ac9    	ldr	x9, [x22, x21]
1015420e4: f9403d0a    	ldr	x10, [x8, #0x78]
1015420e8: eb0a013f    	cmp	x9, x10
1015420ec: 54000642    	b.hs	0x1015421b4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3358>
1015420f0: f9403908    	ldr	x8, [x8, #0x70]
1015420f4: 5280210a    	mov	w10, #0x108             ; =264
1015420f8: 9b0a2137    	madd	x23, x9, x10, x8
1015420fc: aa1703e0    	mov	x0, x23
101542100: 97ff7666    	bl	0x10151fa98 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixEECs29QkOtpKx6e_8mech_gpu>
101542104: 911343e1    	add	x1, sp, #0x4d0
101542108: aa1703e0    	mov	x0, x23
10154210c: 52802102    	mov	w2, #0x108              ; =264
101542110: 9462cdb5    	bl	0x102df57e4 <dyld_stub_binder+0x102df57e4>
101542114: f9402fe8    	ldr	x8, [sp, #0x58]
101542118: f9426908    	ldr	x8, [x8, #0x4d0]
10154211c: b4001d48    	cbz	x8, 0x1015424c4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3668>
101542120: f8756ac9    	ldr	x9, [x22, x21]
101542124: f940538a    	ldr	x10, [x28, #0xa0]
101542128: 8b090949    	add	x9, x10, x9, lsl #2
10154212c: 91000929    	add	x9, x9, #0x2
101542130: f9402fea    	ldr	x10, [sp, #0x58]
101542134: f9426d4a    	ldr	x10, [x10, #0x4d8]
101542138: eb0a013f    	cmp	x9, x10
10154213c: 54001c42    	b.hs	0x1015424c4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3668>
101542140: f8297918    	str	x24, [x8, x9, lsl #3]
101542144: f9402fe8    	ldr	x8, [sp, #0x58]
101542148: f9426908    	ldr	x8, [x8, #0x4d0]
10154214c: b4001bc8    	cbz	x8, 0x1015424c4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3668>
101542150: f8756ac9    	ldr	x9, [x22, x21]
101542154: f9401b8a    	ldr	x10, [x28, #0x30]
101542158: f940538b    	ldr	x11, [x28, #0xa0]
10154215c: 8b0a0929    	add	x9, x9, x10, lsl #2
101542160: 8b0b0129    	add	x9, x9, x11
101542164: 91000929    	add	x9, x9, #0x2
101542168: f9402fea    	ldr	x10, [sp, #0x58]
10154216c: f9426d4a    	ldr	x10, [x10, #0x4d8]
101542170: eb0a013f    	cmp	x9, x10
101542174: 54001a82    	b.hs	0x1015424c4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3668>
101542178: 5280002a    	mov	w10, #0x1               ; =1
10154217c: f829790a    	str	x10, [x8, x9, lsl #3]
101542180: 911343e0    	add	x0, sp, #0x4d0
101542184: a94507e2    	ldp	x2, x1, [sp, #0x50]
101542188: f94027e3    	ldr	x3, [sp, #0x48]
10154218c: 97ffc109    	bl	0x1015325b0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation26resume_numeric_after_write>
101542190: b944d3e8    	ldr	w8, [sp, #0x4d0]
101542194: 7100191f    	cmp	w8, #0x6
101542198: 540023e1    	b.ne	0x101542614 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x37b8>
10154219c: f900069f    	str	xzr, [x20, #0x8]
1015421a0: b9000288    	str	w8, [x20]
1015421a4: b90043ff    	str	wzr, [sp, #0x40]
1015421a8: 911943e0    	add	x0, sp, #0x650
1015421ac: 97ff7e6a    	bl	0x101521b54 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs29QkOtpKx6e_8mech_gpu>
1015421b0: 17ffff20    	b	0x101541e30 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fd4>
1015421b4: b900029f    	str	wzr, [x20]
1015421b8: 52800188    	mov	w8, #0xc                ; =12
1015421bc: d000d789    	adrp	x9, 0x103034000 <_anon.369b439a638cb010e9292f03e79ebf78.107+0xf6b>
1015421c0: 91196529    	add	x9, x9, #0x659
1015421c4: a900a688    	stp	x8, x9, [x20, #0x8]
1015421c8: 52800568    	mov	w8, #0x2b               ; =43
1015421cc: f9000e88    	str	x8, [x20, #0x18]
1015421d0: 911343e0    	add	x0, sp, #0x4d0
1015421d4: 97ff7631    	bl	0x10151fa98 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixEECs29QkOtpKx6e_8mech_gpu>
1015421d8: 17ffff13    	b	0x101541e24 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fc8>
1015421dc: 3cc08360    	ldur	q0, [x27, #0x8]
1015421e0: f9402fe8    	ldr	x8, [sp, #0x58]
1015421e4: f9424908    	ldr	x8, [x8, #0x490]
1015421e8: 52800029    	mov	w9, #0x1                ; =1
1015421ec: 39118109    	strb	w9, [x8, #0x460]
1015421f0: 17fff509    	b	0x10153f614 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7b8>
1015421f4: 52800908    	mov	w8, #0x48               ; =72
1015421f8: d2800909    	mov	x9, #0x48               ; =72
1015421fc: 9b082688    	madd	x8, x20, x8, x9
101542200: f9401be9    	ldr	x9, [sp, #0x30]
101542204: 9bc87d29    	umulh	x9, x9, x8
101542208: eb0903ff    	cmp	xzr, x9
10154220c: 54003fe1    	b.ne	0x101542a08 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3bac>
101542210: f9401be9    	ldr	x9, [sp, #0x30]
101542214: 9b087d28    	mul	x8, x9, x8
101542218: 5280b009    	mov	w9, #0x580              ; =1408
10154221c: d280800a    	mov	x10, #0x400             ; =1024
101542220: 9b092a89    	madd	x9, x20, x9, x10
101542224: ab090108    	adds	x8, x8, x9
101542228: f90017e8    	str	x8, [sp, #0x28]
10154222c: 54003fa2    	b.hs	0x101542a20 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3bc4>
101542230: 92804008    	mov	x8, #-0x201             ; =-513
101542234: f2e3ffe8    	movk	x8, #0x1fff, lsl #48
101542238: f94017e9    	ldr	x9, [sp, #0x28]
10154223c: eb08013f    	cmp	x9, x8
101542240: 540005c9    	b.ls	0x1015422f8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x349c>
101542244: f9402be8    	ldr	x8, [sp, #0x50]
101542248: b900011f    	str	wzr, [x8]
10154224c: 52800189    	mov	w9, #0xc                ; =12
101542250: b000d78a    	adrp	x10, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101542254: 9134e14a    	add	x10, x10, #0xd38
101542258: a900a909    	stp	x9, x10, [x8, #0x8]
10154225c: 528002e9    	mov	w9, #0x17               ; =23
101542260: f9000d09    	str	x9, [x8, #0x18]
101542264: 140000df    	b	0x1015425e0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3784>
101542268: b900029f    	str	wzr, [x20]
10154226c: 52800189    	mov	w9, #0xc                ; =12
101542270: 9000d78a    	adrp	x10, 0x103032000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.241+0x21>
101542274: 91393d4a    	add	x10, x10, #0xe4f
101542278: a900aa89    	stp	x9, x10, [x20, #0x8]
10154227c: 52800508    	mov	w8, #0x28               ; =40
101542280: 14000008    	b	0x1015422a0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3444>
101542284: b900029f    	str	wzr, [x20]
101542288: 52800189    	mov	w9, #0xc                ; =12
10154228c: 39002289    	strb	w9, [x20, #0x8]
101542290: f000d789    	adrp	x9, 0x103035000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x4a0>
101542294: 910e9929    	add	x9, x9, #0x3a6
101542298: f9000a89    	str	x9, [x20, #0x10]
10154229c: 52800528    	mov	w8, #0x29               ; =41
1015422a0: f9000e88    	str	x8, [x20, #0x18]
1015422a4: 910903e0    	add	x0, sp, #0x240
1015422a8: 97ff818d    	bl	0x1015228dc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixECs29QkOtpKx6e_8mech_gpu>
1015422ac: 17fffede    	b	0x101541e24 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fc8>
1015422b0: 3cc15360    	ldur	q0, [x27, #0x15]
1015422b4: 3c815260    	stur	q0, [x19, #0x15]
1015422b8: 3cc25360    	ldur	q0, [x27, #0x25]
1015422bc: 3c825260    	stur	q0, [x19, #0x25]
1015422c0: 3cc35360    	ldur	q0, [x27, #0x35]
1015422c4: 3c835260    	stur	q0, [x19, #0x35]
1015422c8: 3dc147e0    	ldr	q0, [sp, #0x510]
1015422cc: 3d801260    	str	q0, [x19, #0x40]
1015422d0: 3cc05360    	ldur	q0, [x27, #0x5]
1015422d4: 3c805260    	stur	q0, [x19, #0x5]
1015422d8: b9000269    	str	w9, [x19]
1015422dc: 39001268    	strb	w8, [x19, #0x4]
1015422e0: 17fff394    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015422e4: f0012443    	adrp	x3, 0x1039cd000 <_anon.369b439a638cb010e9292f03e79ebf78.285+0x710>
1015422e8: 91024063    	add	x3, x3, #0x90
1015422ec: d2800000    	mov	x0, #0x0                ; =0
1015422f0: 9462c83c    	bl	0x102df43e0 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015422f4: 140003d4    	b	0x101543244 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x43e8>
1015422f8: f9402fe8    	ldr	x8, [sp, #0x58]
1015422fc: f9424909    	ldr	x9, [x8, #0x490]
101542300: f94017e8    	ldr	x8, [sp, #0x28]
101542304: d37df108    	lsl	x8, x8, #3
101542308: 911343e0    	add	x0, sp, #0x4d0
10154230c: aa0903f5    	mov	x21, x9
101542310: 910be121    	add	x1, x9, #0x2f8
101542314: 91400502    	add	x2, x8, #0x1, lsl #12   ; =0x1000
101542318: 97ff90ee    	bl	0x1015266d0 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
10154231c: 395343e8    	ldrb	w8, [sp, #0x4d0]
101542320: 7100391f    	cmp	w8, #0xe
101542324: 54000601    	b.ne	0x1015423e4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3588>
101542328: 911343e8    	add	x8, sp, #0x4d0
10154232c: 911863e0    	add	x0, sp, #0x618
101542330: f94017e1    	ldr	x1, [sp, #0x28]
101542334: 945e9633    	bl	0x102ce7c00 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
101542338: b944d3e8    	ldr	w8, [sp, #0x4d0]
10154233c: 7100691f    	cmp	w8, #0x1a
101542340: 54000b01    	b.ne	0x1015424a0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3644>
101542344: 3cc08360    	ldur	q0, [x27, #0x8]
101542348: 3cc18361    	ldur	q1, [x27, #0x18]
10154234c: 3d818fe0    	str	q0, [sp, #0x630]
101542350: 3d8193e1    	str	q1, [sp, #0x640]
101542354: 911343e8    	add	x8, sp, #0x4d0
101542358: aa1403e0    	mov	x0, x20
10154235c: f94027e1    	ldr	x1, [sp, #0x48]
101542360: f9401be2    	ldr	x2, [sp, #0x30]
101542364: 9402c070    	bl	0x1015f2524 <__RNvNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel15scheduler_nodes>
101542368: b944d3e8    	ldr	w8, [sp, #0x4d0]
10154236c: 7100191f    	cmp	w8, #0x6
101542370: 54000f61    	b.ne	0x10154255c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3700>
101542374: f9426fe1    	ldr	x1, [sp, #0x4d8]
101542378: 910903e8    	add	x8, sp, #0x240
10154237c: 911863e0    	add	x0, sp, #0x618
101542380: 945e95d5    	bl	0x102ce7ad4 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget13reserve_nodes>
101542384: b94243e8    	ldr	w8, [sp, #0x240]
101542388: 7100691f    	cmp	w8, #0x1a
10154238c: 54001161    	b.ne	0x1015425b8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x375c>
101542390: 3cc08340    	ldur	q0, [x26, #0x8]
101542394: 3cc18341    	ldur	q1, [x26, #0x18]
101542398: 3d8197e0    	str	q0, [sp, #0x650]
10154239c: 3d819be1    	str	q1, [sp, #0x660]
1015423a0: f94027e8    	ldr	x8, [sp, #0x48]
1015423a4: b50018a8    	cbnz	x8, 0x1015426b8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x385c>
1015423a8: 52800108    	mov	w8, #0x8                ; =8
1015423ac: f9033fff    	str	xzr, [sp, #0x678]
1015423b0: f90343e8    	str	x8, [sp, #0x680]
1015423b4: f90347ff    	str	xzr, [sp, #0x688]
1015423b8: 9000d5e8    	adrp	x8, 0x102ffe000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x1d3>
1015423bc: 3dc04d00    	ldr	q0, [x8, #0x130]
1015423c0: f9402be8    	ldr	x8, [sp, #0x50]
1015423c4: 3c808100    	stur	q0, [x8, #0x8]
1015423c8: 528000c9    	mov	w9, #0x6                ; =6
1015423cc: b9000109    	str	w9, [x8]
1015423d0: 9119e3e0    	add	x0, sp, #0x678
1015423d4: 97ff7955    	bl	0x101520928 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionEEB1p_>
1015423d8: 911943e0    	add	x0, sp, #0x650
1015423dc: 97ff7dc0    	bl	0x101521adc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs29QkOtpKx6e_8mech_gpu>
1015423e0: 1400007e    	b	0x1015425d8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x377c>
1015423e4: 3dc137e0    	ldr	q0, [sp, #0x4d0]
1015423e8: 3dc13be1    	ldr	q1, [sp, #0x4e0]
1015423ec: ad1207e0    	stp	q0, q1, [sp, #0x240]
1015423f0: 3dc13fe2    	ldr	q2, [sp, #0x4f0]
1015423f4: 3d809be2    	str	q2, [sp, #0x260]
1015423f8: f94283e8    	ldr	x8, [sp, #0x500]
1015423fc: f9013be8    	str	x8, [sp, #0x270]
101542400: 3c804360    	stur	q0, [x27, #0x4]
101542404: 3c814361    	stur	q1, [x27, #0x14]
101542408: 3c824362    	stur	q2, [x27, #0x24]
10154240c: f8034368    	stur	x8, [x27, #0x34]
101542410: f9402be8    	ldr	x8, [sp, #0x50]
101542414: b900011f    	str	wzr, [x8]
101542418: 3dc137e0    	ldr	q0, [sp, #0x4d0]
10154241c: 3dc13be1    	ldr	q1, [sp, #0x4e0]
101542420: 3c804100    	stur	q0, [x8, #0x4]
101542424: 3c814101    	stur	q1, [x8, #0x14]
101542428: 3dc13fe0    	ldr	q0, [sp, #0x4f0]
10154242c: 3c824100    	stur	q0, [x8, #0x24]
101542430: 3cc2c360    	ldur	q0, [x27, #0x2c]
101542434: 3d800d00    	str	q0, [x8, #0x30]
101542438: 1400006a    	b	0x1015425e0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3784>
10154243c: 3dc13fe0    	ldr	q0, [sp, #0x4f0]
101542440: 3dc143e1    	ldr	q1, [sp, #0x500]
101542444: ad010660    	stp	q0, q1, [x19, #0x20]
101542448: 3dc147e0    	ldr	q0, [sp, #0x510]
10154244c: 3d801260    	str	q0, [x19, #0x40]
101542450: 3dc13be0    	ldr	q0, [sp, #0x4e0]
101542454: 3dc137e1    	ldr	q1, [sp, #0x4d0]
101542458: ad000261    	stp	q1, q0, [x19]
10154245c: 17fff335    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101542460: b8401369    	ldur	w9, [x27, #0x1]
101542464: b8009269    	stur	w9, [x19, #0x9]
101542468: b944d7e9    	ldr	w9, [sp, #0x4d4]
10154246c: b9000e69    	str	w9, [x19, #0xc]
101542470: 3dc13fe0    	ldr	q0, [sp, #0x4f0]
101542474: 3c828260    	stur	q0, [x19, #0x28]
101542478: f94283e9    	ldr	x9, [sp, #0x500]
10154247c: f9001e69    	str	x9, [x19, #0x38]
101542480: fd4277e0    	ldr	d0, [sp, #0x4e8]
101542484: 3cc08361    	ldur	q1, [x27, #0x8]
101542488: 52800049    	mov	w9, #0x2                ; =2
10154248c: b9000269    	str	w9, [x19]
101542490: 39002268    	strb	w8, [x19, #0x8]
101542494: 3d800661    	str	q1, [x19, #0x10]
101542498: fd001260    	str	d0, [x19, #0x20]
10154249c: 17fff325    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015424a0: 9000d5e8    	adrp	x8, 0x102ffe000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x1d3>
1015424a4: 3dc04d00    	ldr	q0, [x8, #0x130]
1015424a8: f9402be8    	ldr	x8, [sp, #0x50]
1015424ac: 3c808100    	stur	q0, [x8, #0x8]
1015424b0: 528000c9    	mov	w9, #0x6                ; =6
1015424b4: b9000109    	str	w9, [x8]
1015424b8: 911343e0    	add	x0, sp, #0x4d0
1015424bc: 97ff76f8    	bl	0x10152009c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationNtNtB16_5error18MemoryRuntimeErrorEECs29QkOtpKx6e_8mech_gpu>
1015424c0: 14000048    	b	0x1015425e0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3784>
1015424c4: b900029f    	str	wzr, [x20]
1015424c8: 52800188    	mov	w8, #0xc                ; =12
1015424cc: 39002288    	strb	w8, [x20, #0x8]
1015424d0: f000d788    	adrp	x8, 0x103035000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x4a0>
1015424d4: 910e9908    	add	x8, x8, #0x3a6
1015424d8: 52800529    	mov	w9, #0x29               ; =41
1015424dc: a9012688    	stp	x8, x9, [x20, #0x10]
1015424e0: 17fffe51    	b	0x101541e24 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fc8>
1015424e4: b900027f    	str	wzr, [x19]
1015424e8: 52800189    	mov	w9, #0xc                ; =12
1015424ec: f9000669    	str	x9, [x19, #0x8]
1015424f0: 9000d7a8    	adrp	x8, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
1015424f4: 912ba508    	add	x8, x8, #0xae9
1015424f8: 528003c9    	mov	w9, #0x1e               ; =30
1015424fc: 17fffbd6    	b	0x101541454 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x25f8>
101542500: b900029f    	str	wzr, [x20]
101542504: 52800188    	mov	w8, #0xc                ; =12
101542508: 9000d789    	adrp	x9, 0x103032000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.241+0x21>
10154250c: 91374d29    	add	x9, x9, #0xdd3
101542510: a900a688    	stp	x8, x9, [x20, #0x8]
101542514: 52800548    	mov	w8, #0x2a               ; =42
101542518: f9000e88    	str	x8, [x20, #0x18]
10154251c: 17fffc03    	b	0x101541528 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x26cc>
101542520: b900029f    	str	wzr, [x20]
101542524: 52800188    	mov	w8, #0xc                ; =12
101542528: 9000d789    	adrp	x9, 0x103032000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.241+0x21>
10154252c: 9137f529    	add	x9, x9, #0xdfd
101542530: a900a688    	stp	x8, x9, [x20, #0x8]
101542534: 528004c8    	mov	w8, #0x26               ; =38
101542538: f9000e88    	str	x8, [x20, #0x18]
10154253c: 17fffbfb    	b	0x101541528 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x26cc>
101542540: b900029f    	str	wzr, [x20]
101542544: 52800189    	mov	w9, #0xc                ; =12
101542548: 39002289    	strb	w9, [x20, #0x8]
10154254c: 9000d788    	adrp	x8, 0x103032000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.241+0x21>
101542550: 91388d08    	add	x8, x8, #0xe23
101542554: 52800589    	mov	w9, #0x2c               ; =44
101542558: 17fffe2b    	b	0x101541e04 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fa8>
10154255c: b944d7e9    	ldr	w9, [sp, #0x4d4]
101542560: f9426fea    	ldr	x10, [sp, #0x4d8]
101542564: 3dc13be0    	ldr	q0, [sp, #0x4e0]
101542568: 3dc13fe1    	ldr	q1, [sp, #0x4f0]
10154256c: f9402beb    	ldr	x11, [sp, #0x50]
101542570: ad008560    	stp	q0, q1, [x11, #0x10]
101542574: 3dc143e0    	ldr	q0, [sp, #0x500]
101542578: 3dc147e1    	ldr	q1, [sp, #0x510]
10154257c: ad018560    	stp	q0, q1, [x11, #0x30]
101542580: 29002568    	stp	w8, w9, [x11]
101542584: f900056a    	str	x10, [x11, #0x8]
101542588: 14000014    	b	0x1015425d8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x377c>
10154258c: f0012442    	adrp	x2, 0x1039cd000 <_anon.369b439a638cb010e9292f03e79ebf78.285+0x710>
101542590: 9101e042    	add	x2, x2, #0x78
101542594: aa0803e0    	mov	x0, x8
101542598: 9462c725    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154259c: 90012462    	adrp	x2, 0x1039ce000 <_anon.369b439a638cb010e9292f03e79ebf78.685+0x608>
1015425a0: 9100a042    	add	x2, x2, #0x28
1015425a4: aa1303e0    	mov	x0, x19
1015425a8: 9462c721    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015425ac: f0012442    	adrp	x2, 0x1039cd000 <_anon.369b439a638cb010e9292f03e79ebf78.285+0x710>
1015425b0: 91326042    	add	x2, x2, #0xc98
1015425b4: 9462c71e    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015425b8: 9000d5e8    	adrp	x8, 0x102ffe000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x1d3>
1015425bc: 3dc04d00    	ldr	q0, [x8, #0x130]
1015425c0: f9402be8    	ldr	x8, [sp, #0x50]
1015425c4: 3c808100    	stur	q0, [x8, #0x8]
1015425c8: 528000c9    	mov	w9, #0x6                ; =6
1015425cc: b9000109    	str	w9, [x8]
1015425d0: 910903e0    	add	x0, sp, #0x240
1015425d4: 97ff767c    	bl	0x10151ffc4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationNtNtB16_5error18MemoryRuntimeErrorEECs29QkOtpKx6e_8mech_gpu>
1015425d8: 9118c3e0    	add	x0, sp, #0x630
1015425dc: 97ff7d5e    	bl	0x101521b54 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs29QkOtpKx6e_8mech_gpu>
1015425e0: f9430fe8    	ldr	x8, [sp, #0x618]
1015425e4: 92800009    	mov	x9, #-0x1               ; =-1
1015425e8: f8690108    	ldaddl	x9, x8, [x8]
1015425ec: f100051f    	cmp	x8, #0x1
1015425f0: 54fe5a01    	b.ne	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015425f4: d50339bf    	dmb	ishld
1015425f8: 911863e0    	add	x0, sp, #0x618
1015425fc: 945ec18e    	bl	0x102cf2c34 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101542600: 17fff2cc    	b	0x10153f130 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101542604: f0012442    	adrp	x2, 0x1039cd000 <_anon.369b439a638cb010e9292f03e79ebf78.285+0x710>
101542608: 91350042    	add	x2, x2, #0xd40
10154260c: aa1303e0    	mov	x0, x19
101542610: 9462c707    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101542614: 3dc13fe0    	ldr	q0, [sp, #0x4f0]
101542618: 3dc143e1    	ldr	q1, [sp, #0x500]
10154261c: ad010680    	stp	q0, q1, [x20, #0x20]
101542620: 3dc147e0    	ldr	q0, [sp, #0x510]
101542624: 3d801280    	str	q0, [x20, #0x40]
101542628: 3dc13be0    	ldr	q0, [sp, #0x4e0]
10154262c: 3dc137e1    	ldr	q1, [sp, #0x4d0]
101542630: ad000281    	stp	q1, q0, [x20]
101542634: 17fffdfc    	b	0x101541e24 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fc8>
101542638: d0012442    	adrp	x2, 0x1039cc000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.291+0x310>
10154263c: 913a6042    	add	x2, x2, #0xe98
101542640: f94027e0    	ldr	x0, [sp, #0x48]
101542644: 9462c6fa    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101542648: d0012442    	adrp	x2, 0x1039cc000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.291+0x310>
10154264c: 913ac042    	add	x2, x2, #0xeb0
101542650: f94027e0    	ldr	x0, [sp, #0x48]
101542654: 9462c6f6    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101542658: b9413325    	ldr	w5, [x25, #0x130]
10154265c: aa1303e0    	mov	x0, x19
101542660: f9402fe1    	ldr	x1, [sp, #0x58]
101542664: aa1403e2    	mov	x2, x20
101542668: aa1703e3    	mov	x3, x23
10154266c: aa1603e4    	mov	x4, x22
101542670: aa1503e6    	mov	x6, x21
101542674: aa1603e7    	mov	x7, x22
101542678: 911d03ff    	add	sp, sp, #0x740
10154267c: a9457bfd    	ldp	x29, x30, [sp, #0x50]
101542680: a9444ff4    	ldp	x20, x19, [sp, #0x40]
101542684: a94357f6    	ldp	x22, x21, [sp, #0x30]
101542688: a9425ff8    	ldp	x24, x23, [sp, #0x20]
10154268c: a94167fa    	ldp	x26, x25, [sp, #0x10]
101542690: a8c66ffc    	ldp	x28, x27, [sp], #0x60
101542694: 17ffad88    	b	0x10152dcb4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call>
101542698: f0012442    	adrp	x2, 0x1039cd000 <_anon.369b439a638cb010e9292f03e79ebf78.285+0x710>
10154269c: 91356042    	add	x2, x2, #0xd58
1015426a0: aa0103e0    	mov	x0, x1
1015426a4: aa0803e1    	mov	x1, x8
1015426a8: 9462c6e1    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015426ac: f0012442    	adrp	x2, 0x1039cd000 <_anon.369b439a638cb010e9292f03e79ebf78.285+0x710>
1015426b0: 91344042    	add	x2, x2, #0xd10
1015426b4: 9462c6de    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015426b8: 911343e0    	add	x0, sp, #0x4d0
1015426bc: d2800001    	mov	x1, #0x0                ; =0
1015426c0: 52800102    	mov	w2, #0x8                ; =8
1015426c4: f94027e3    	ldr	x3, [sp, #0x48]
1015426c8: 52800104    	mov	w4, #0x8                ; =8
1015426cc: 52800d05    	mov	w5, #0x68               ; =104
1015426d0: 946233d3    	bl	0x102dcf61c <__RNvMs4_NtCsgKscDXrlV49_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs29QkOtpKx6e_8mech_gpu>
1015426d4: b944d3e8    	ldr	w8, [sp, #0x4d0]
1015426d8: 360001c8    	tbz	w8, #0x0, 0x101542710 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x38b4>
1015426dc: 9000d7a8    	adrp	x8, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
1015426e0: 91244908    	add	x8, x8, #0x912
1015426e4: 52800189    	mov	w9, #0xc                ; =12
1015426e8: f9402bea    	ldr	x10, [sp, #0x50]
1015426ec: a900a149    	stp	x9, x8, [x10, #0x8]
1015426f0: 52800348    	mov	w8, #0x1a               ; =26
1015426f4: f9000d48    	str	x8, [x10, #0x18]
1015426f8: b900015f    	str	wzr, [x10]
1015426fc: 17ffff37    	b	0x1015423d8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x357c>
101542700: d0012442    	adrp	x2, 0x1039cc000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.291+0x310>
101542704: 913b2042    	add	x2, x2, #0xec8
101542708: f94017e1    	ldr	x1, [sp, #0x28]
10154270c: 9462c6c8    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101542710: f90003ff    	str	xzr, [sp]
101542714: f9000fff    	str	xzr, [sp, #0x18]
101542718: f9426fe8    	ldr	x8, [sp, #0x4d8]
10154271c: f94027e9    	ldr	x9, [sp, #0x48]
101542720: f9033fe9    	str	x9, [sp, #0x678]
101542724: f90343e8    	str	x8, [sp, #0x680]
101542728: f90347ff    	str	xzr, [sp, #0x688]
10154272c: f94023e8    	ldr	x8, [sp, #0x40]
101542730: b8404509    	ldr	w9, [x8], #0x4
101542734: f90023e8    	str	x8, [sp, #0x40]
101542738: f9430be8    	ldr	x8, [sp, #0x610]
10154273c: f942c501    	ldr	x1, [x8, #0x588]
101542740: f9001be9    	str	x9, [sp, #0x30]
101542744: eb09003f    	cmp	x1, x9
101542748: 54005649    	b.ls	0x101543210 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x43b4>
10154274c: f942c108    	ldr	x8, [x8, #0x580]
101542750: 52800b09    	mov	w9, #0x58               ; =88
101542754: f9401bea    	ldr	x10, [sp, #0x30]
101542758: 9ba92148    	umaddl	x8, w10, w9, x8
10154275c: f90017e8    	str	x8, [sp, #0x28]
101542760: b9405101    	ldr	w1, [x8, #0x50]
101542764: 911343e8    	add	x8, sp, #0x4d0
101542768: 9103c2a0    	add	x0, x21, #0xf0
10154276c: 910be2a2    	add	x2, x21, #0x2f8
101542770: 94000caf    	bl	0x101545a2c <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
101542774: f9426be8    	ldr	x8, [sp, #0x4d0]
101542778: 911343e9    	add	x9, sp, #0x4d0
10154277c: 3cc08120    	ldur	q0, [x9, #0x8]
101542780: 3cc18121    	ldur	q1, [x9, #0x18]
101542784: ad1d07e0    	stp	q0, q1, [sp, #0x3a0]
101542788: 3cc28120    	ldur	q0, [x9, #0x28]
10154278c: 3d80f3e0    	str	q0, [sp, #0x3c0]
101542790: f8438129    	ldur	x9, [x9, #0x38]
101542794: f901ebe9    	str	x9, [sp, #0x3d0]
101542798: b4001568    	cbz	x8, 0x101542a44 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3be8>
10154279c: f941ebe9    	ldr	x9, [sp, #0x3d0]
1015427a0: 911183ea    	add	x10, sp, #0x460
1015427a4: f8038149    	stur	x9, [x10, #0x38]
1015427a8: ad5d87e0    	ldp	q0, q1, [sp, #0x3b0]
1015427ac: 3c828141    	stur	q1, [x10, #0x28]
1015427b0: 3dc0ebe1    	ldr	q1, [sp, #0x3a0]
1015427b4: 3c818140    	stur	q0, [x10, #0x18]
1015427b8: 3c808141    	stur	q1, [x10, #0x8]
1015427bc: f90233e8    	str	x8, [sp, #0x460]
1015427c0: f94237e8    	ldr	x8, [sp, #0x468]
1015427c4: f9400908    	ldr	x8, [x8, #0x10]
1015427c8: 39404108    	ldrb	w8, [x8, #0x10]
1015427cc: 321f0108    	orr	w8, w8, #0x2
1015427d0: 71006d1f    	cmp	w8, #0x1b
1015427d4: 54002841    	b.ne	0x101542cdc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e80>
1015427d8: 911343e8    	add	x8, sp, #0x4d0
1015427dc: 911183e0    	add	x0, sp, #0x460
1015427e0: 9401dbdf    	bl	0x1015b975c <__RNvNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime11collections12source_count>
1015427e4: b944d3e8    	ldr	w8, [sp, #0x4d0]
1015427e8: 7100191f    	cmp	w8, #0x6
1015427ec: 54001521    	b.ne	0x101542a90 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c34>
1015427f0: f9426fe8    	ldr	x8, [sp, #0x4d8]
1015427f4: f90027e8    	str	x8, [sp, #0x48]
1015427f8: f9401be8    	ldr	x8, [sp, #0x30]
1015427fc: eb08039f    	cmp	x28, x8
101542800: 54000081    	b.ne	0x101542810 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x39b4>
101542804: f94027e8    	ldr	x8, [sp, #0x48]
101542808: eb13011f    	cmp	x8, x19
10154280c: 540015a1    	b.ne	0x101542ac0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c64>
101542810: f9400fe8    	ldr	x8, [sp, #0x18]
101542814: f94027e9    	ldr	x9, [sp, #0x48]
101542818: ab080128    	adds	x8, x9, x8
10154281c: f9000fe8    	str	x8, [sp, #0x18]
101542820: 540031e2    	b.hs	0x101542e5c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4000>
101542824: f94027e8    	ldr	x8, [sp, #0x48]
101542828: b40015c8    	cbz	x8, 0x101542ae0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c84>
10154282c: f9400fe8    	ldr	x8, [sp, #0x18]
101542830: eb14011f    	cmp	x8, x20
101542834: 54001568    	b.hi	0x101542ae0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c84>
101542838: f94017e8    	ldr	x8, [sp, #0x28]
10154283c: f9400508    	ldr	x8, [x8, #0x8]
101542840: f90007e8    	str	x8, [sp, #0x8]
101542844: b5000408    	cbnz	x8, 0x1015428c4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a68>
101542848: f90003ff    	str	xzr, [sp]
10154284c: f94007e8    	ldr	x8, [sp, #0x8]
101542850: f901fbe8    	str	x8, [sp, #0x3f0]
101542854: 52800108    	mov	w8, #0x8                ; =8
101542858: f901ffe8    	str	x8, [sp, #0x3f8]
10154285c: f90203ff    	str	xzr, [sp, #0x400]
101542860: 3dc11be0    	ldr	q0, [sp, #0x460]
101542864: 3dc11fe1    	ldr	q1, [sp, #0x470]
101542868: 911343e8    	add	x8, sp, #0x4d0
10154286c: 3c818100    	stur	q0, [x8, #0x18]
101542870: 3c828101    	stur	q1, [x8, #0x28]
101542874: 3dc123e0    	ldr	q0, [sp, #0x480]
101542878: 3dc127e1    	ldr	q1, [sp, #0x490]
10154287c: 3c838100    	stur	q0, [x8, #0x38]
101542880: 3c848101    	stur	q1, [x8, #0x48]
101542884: 3dc0ffe0    	ldr	q0, [sp, #0x3f0]
101542888: 3d8137e0    	str	q0, [sp, #0x4d0]
10154288c: f94203e8    	ldr	x8, [sp, #0x400]
101542890: f90273e8    	str	x8, [sp, #0x4e0]
101542894: f9401be8    	ldr	x8, [sp, #0x30]
101542898: f90297e8    	str	x8, [sp, #0x528]
10154289c: f94027e8    	ldr	x8, [sp, #0x48]
1015428a0: f9029be8    	str	x8, [sp, #0x530]
1015428a4: 9119e3e0    	add	x0, sp, #0x678
1015428a8: 911343e1    	add	x1, sp, #0x4d0
1015428ac: 9400166f    	bl	0x101548268 <__RNvMsF_NtCsgKscDXrlV49_5alloc3vecINtB5_3VecNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionE8push_mutBR_>
1015428b0: f94023e8    	ldr	x8, [sp, #0x40]
1015428b4: f94013e9    	ldr	x9, [sp, #0x20]
1015428b8: eb09011f    	cmp	x8, x9
1015428bc: 54fff381    	b.ne	0x10154272c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x38d0>
1015428c0: 1400008f    	b	0x101542afc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ca0>
1015428c4: f94017e8    	ldr	x8, [sp, #0x28]
1015428c8: f9400108    	ldr	x8, [x8]
1015428cc: f9000be8    	str	x8, [sp, #0x10]
1015428d0: 911343e0    	add	x0, sp, #0x4d0
1015428d4: d2800001    	mov	x1, #0x0                ; =0
1015428d8: 52800102    	mov	w2, #0x8                ; =8
1015428dc: f94007e3    	ldr	x3, [sp, #0x8]
1015428e0: 52800104    	mov	w4, #0x8                ; =8
1015428e4: 52800905    	mov	w5, #0x48               ; =72
1015428e8: 9462334d    	bl	0x102dcf61c <__RNvMs4_NtCsgKscDXrlV49_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs29QkOtpKx6e_8mech_gpu>
1015428ec: f9426be8    	ldr	x8, [sp, #0x4d0]
1015428f0: f100051f    	cmp	x8, #0x1
1015428f4: 540025c0    	b.eq	0x101542dac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3f50>
1015428f8: f9426fe8    	ldr	x8, [sp, #0x4d8]
1015428fc: f94007ea    	ldr	x10, [sp, #0x8]
101542900: 9278d949    	and	x9, x10, #0x7fffffffffffff00
101542904: f901fbea    	str	x10, [sp, #0x3f0]
101542908: f901ffe8    	str	x8, [sp, #0x3f8]
10154290c: f90203ff    	str	xzr, [sp, #0x400]
101542910: d37ef548    	lsl	x8, x10, #2
101542914: a90023e9    	stp	x9, x8, [sp]
101542918: 1400000e    	b	0x101542950 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3af4>
10154291c: f94016e8    	ldr	x8, [x23, #0x28]
101542920: f94017e9    	ldr	x9, [sp, #0x28]
101542924: f8697908    	ldr	x8, [x8, x9, lsl #3]
101542928: f9026fe8    	str	x8, [sp, #0x4d8]
10154292c: b904d7e9    	str	w9, [sp, #0x4d4]
101542930: b904d3ff    	str	wzr, [sp, #0x4d0]
101542934: 910fc3e0    	add	x0, sp, #0x3f0
101542938: 911343e1    	add	x1, sp, #0x4d0
10154293c: 94001670    	bl	0x1015482fc <__RNvMsF_NtCsgKscDXrlV49_5alloc3vecINtB5_3VecNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureE8push_mutBR_>
101542940: f94007e8    	ldr	x8, [sp, #0x8]
101542944: f1001108    	subs	x8, x8, #0x4
101542948: f90007e8    	str	x8, [sp, #0x8]
10154294c: 54fff8a0    	b.eq	0x101542860 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a04>
101542950: f9400be8    	ldr	x8, [sp, #0x10]
101542954: b8404509    	ldr	w9, [x8], #0x4
101542958: f9000be8    	str	x8, [sp, #0x10]
10154295c: f9430be8    	ldr	x8, [sp, #0x610]
101542960: f941ad01    	ldr	x1, [x8, #0x358]
101542964: f90017e9    	str	x9, [sp, #0x28]
101542968: eb09003f    	cmp	x1, x9
10154296c: 540045c9    	b.ls	0x101543224 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x43c8>
101542970: f941a908    	ldr	x8, [x8, #0x350]
101542974: 52802809    	mov	w9, #0x140              ; =320
101542978: f94017ea    	ldr	x10, [sp, #0x28]
10154297c: 9ba92148    	umaddl	x8, w10, w9, x8
101542980: 39449108    	ldrb	w8, [x8, #0x124]
101542984: 71001d1f    	cmp	w8, #0x7
101542988: 54fffca1    	b.ne	0x10154291c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac0>
10154298c: 910903e8    	add	x8, sp, #0x240
101542990: 9103c2a0    	add	x0, x21, #0xf0
101542994: 910be2a2    	add	x2, x21, #0x2f8
101542998: f94017e1    	ldr	x1, [sp, #0x28]
10154299c: 94000c24    	bl	0x101545a2c <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
1015429a0: f94123e8    	ldr	x8, [sp, #0x240]
1015429a4: 910903e9    	add	x9, sp, #0x240
1015429a8: 3cc08120    	ldur	q0, [x9, #0x8]
1015429ac: 3cc18121    	ldur	q1, [x9, #0x18]
1015429b0: ad0507e0    	stp	q0, q1, [sp, #0xa0]
1015429b4: 3cc28120    	ldur	q0, [x9, #0x28]
1015429b8: 3d8033e0    	str	q0, [sp, #0xc0]
1015429bc: f8438129    	ldur	x9, [x9, #0x38]
1015429c0: f9006be9    	str	x9, [sp, #0xd0]
1015429c4: b4001648    	cbz	x8, 0x101542c8c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e30>
1015429c8: ad4507e0    	ldp	q0, q1, [sp, #0xa0]
1015429cc: 911343ea    	add	x10, sp, #0x4d0
1015429d0: ad008540    	stp	q0, q1, [x10, #0x10]
1015429d4: 3dc033e0    	ldr	q0, [sp, #0xc0]
1015429d8: 3c830140    	stur	q0, [x10, #0x30]
1015429dc: f9406be9    	ldr	x9, [sp, #0xd0]
1015429e0: f8040149    	stur	x9, [x10, #0x40]
1015429e4: f9026fe8    	str	x8, [sp, #0x4d8]
1015429e8: f94017e8    	ldr	x8, [sp, #0x28]
1015429ec: b904d7e8    	str	w8, [sp, #0x4d4]
1015429f0: 52800028    	mov	w8, #0x1                ; =1
1015429f4: b904d3e8    	str	w8, [sp, #0x4d0]
1015429f8: 910fc3e0    	add	x0, sp, #0x3f0
1015429fc: 911343e1    	add	x1, sp, #0x4d0
101542a00: 9400163f    	bl	0x1015482fc <__RNvMsF_NtCsgKscDXrlV49_5alloc3vecINtB5_3VecNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureE8push_mutBR_>
101542a04: 17ffffcf    	b	0x101542940 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ae4>
101542a08: f9402be8    	ldr	x8, [sp, #0x50]
101542a0c: b900011f    	str	wzr, [x8]
101542a10: 52800189    	mov	w9, #0xc                ; =12
101542a14: b000d78a    	adrp	x10, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101542a18: 9102554a    	add	x10, x10, #0x95
101542a1c: 14000006    	b	0x101542a34 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3bd8>
101542a20: f9402be8    	ldr	x8, [sp, #0x50]
101542a24: b900011f    	str	wzr, [x8]
101542a28: 52800189    	mov	w9, #0xc                ; =12
101542a2c: b000d78a    	adrp	x10, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101542a30: 9134794a    	add	x10, x10, #0xd1e
101542a34: a900a909    	stp	x9, x10, [x8, #0x8]
101542a38: 52800349    	mov	w9, #0x1a               ; =26
101542a3c: f9000d09    	str	x9, [x8, #0x18]
101542a40: 17fffee8    	b	0x1015425e0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3784>
101542a44: ad5d07e0    	ldp	q0, q1, [sp, #0x3a0]
101542a48: 3c804360    	stur	q0, [x27, #0x4]
101542a4c: 3c814361    	stur	q1, [x27, #0x14]
101542a50: 3dc0f3e0    	ldr	q0, [sp, #0x3c0]
101542a54: 3c824360    	stur	q0, [x27, #0x24]
101542a58: f941ebe8    	ldr	x8, [sp, #0x3d0]
101542a5c: f8034368    	stur	x8, [x27, #0x34]
101542a60: 3dc137e0    	ldr	q0, [sp, #0x4d0]
101542a64: 3dc13be1    	ldr	q1, [sp, #0x4e0]
101542a68: f9402be8    	ldr	x8, [sp, #0x50]
101542a6c: 3c804100    	stur	q0, [x8, #0x4]
101542a70: 52800049    	mov	w9, #0x2                ; =2
101542a74: b9000109    	str	w9, [x8]
101542a78: 3c814101    	stur	q1, [x8, #0x14]
101542a7c: 3dc13fe0    	ldr	q0, [sp, #0x4f0]
101542a80: 3c824100    	stur	q0, [x8, #0x24]
101542a84: 3cc2c360    	ldur	q0, [x27, #0x2c]
101542a88: 3d800d00    	str	q0, [x8, #0x30]
101542a8c: 17fffe51    	b	0x1015423d0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3574>
101542a90: b944d7e9    	ldr	w9, [sp, #0x4d4]
101542a94: f9426fea    	ldr	x10, [sp, #0x4d8]
101542a98: 3dc13be0    	ldr	q0, [sp, #0x4e0]
101542a9c: 3dc13fe1    	ldr	q1, [sp, #0x4f0]
101542aa0: f9402beb    	ldr	x11, [sp, #0x50]
101542aa4: ad008560    	stp	q0, q1, [x11, #0x10]
101542aa8: 3dc143e0    	ldr	q0, [sp, #0x500]
101542aac: 3dc147e1    	ldr	q1, [sp, #0x510]
101542ab0: ad018560    	stp	q0, q1, [x11, #0x30]
101542ab4: 29002568    	stp	w8, w9, [x11]
101542ab8: f900056a    	str	x10, [x11, #0x8]
101542abc: 14000090    	b	0x101542cfc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ea0>
101542ac0: f9402be8    	ldr	x8, [sp, #0x50]
101542ac4: b900011f    	str	wzr, [x8]
101542ac8: 52800189    	mov	w9, #0xc                ; =12
101542acc: 39002109    	strb	w9, [x8, #0x8]
101542ad0: 9000d7a9    	adrp	x9, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
101542ad4: 91251d29    	add	x9, x9, #0x947
101542ad8: 5280048a    	mov	w10, #0x24              ; =36
101542adc: 14000087    	b	0x101542cf8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e9c>
101542ae0: 9000d5e8    	adrp	x8, 0x102ffe000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x1d3>
101542ae4: 3dc04d00    	ldr	q0, [x8, #0x130]
101542ae8: f9402be8    	ldr	x8, [sp, #0x50]
101542aec: 3c808100    	stur	q0, [x8, #0x8]
101542af0: 528000c9    	mov	w9, #0x6                ; =6
101542af4: b9000109    	str	w9, [x8]
101542af8: 14000081    	b	0x101542cfc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ea0>
101542afc: f9400fe8    	ldr	x8, [sp, #0x18]
101542b00: f100091f    	cmp	x8, #0x2
101542b04: 54ffc5a3    	b.lo	0x1015423b8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x355c>
101542b08: f9400fe8    	ldr	x8, [sp, #0x18]
101542b0c: f81003a8    	stur	x8, [x29, #-0x100]
101542b10: 8b081508    	add	x8, x8, x8, lsl #5
101542b14: d370bd01    	lsl	x1, x8, #16
101542b18: 911343e8    	add	x8, sp, #0x4d0
101542b1c: 911863e0    	add	x0, sp, #0x618
101542b20: 945e9438    	bl	0x102ce7c00 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
101542b24: b944d3e8    	ldr	w8, [sp, #0x4d0]
101542b28: 7100691f    	cmp	w8, #0x1a
101542b2c: 54000f81    	b.ne	0x101542d1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ec0>
101542b30: 3cc08360    	ldur	q0, [x27, #0x8]
101542b34: 3cc18361    	ldur	q1, [x27, #0x18]
101542b38: ad1087e0    	stp	q0, q1, [sp, #0x210]
101542b3c: f94347f4    	ldr	x20, [sp, #0x688]
101542b40: b5001a14    	cbnz	x20, 0x101542e80 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4024>
101542b44: d2800008    	mov	x8, #0x0                ; =0
101542b48: 52800109    	mov	w9, #0x8                ; =8
101542b4c: a930a7b4    	stp	x20, x9, [x29, #-0xf8]
101542b50: f81183bf    	stur	xzr, [x29, #-0xe8]
101542b54: f94343e1    	ldr	x1, [sp, #0x680]
101542b58: 52800d09    	mov	w9, #0x68               ; =104
101542b5c: 9b090502    	madd	x2, x8, x9, x1
101542b60: 5280003a    	mov	w26, #0x1               ; =1
101542b64: d103e3a0    	sub	x0, x29, #0xf8
101542b68: 5280003c    	mov	w28, #0x1               ; =1
101542b6c: 97fd5490    	bl	0x101497dac <__RINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB6_3VecjE14extend_trustedINtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB17_5slice4iter4IterNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionENCNvMs0_B2f_NtB2h_10Invocation12run_parallels9_0EEB2p_>
101542b70: a9710fa2    	ldp	x2, x3, [x29, #-0xf0]
101542b74: 911343e0    	add	x0, sp, #0x4d0
101542b78: f9402fe1    	ldr	x1, [sp, #0x58]
101542b7c: 97ffd5b3    	bl	0x101538248 <__RNvMNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel9admissionNtB6_10Invocation18parallel_admission>
101542b80: b944d3e8    	ldr	w8, [sp, #0x4d0]
101542b84: 7100191f    	cmp	w8, #0x6
101542b88: 54000dc1    	b.ne	0x101542d40 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ee4>
101542b8c: f9426fe8    	ldr	x8, [sp, #0x4d8]
101542b90: 3dc13be0    	ldr	q0, [sp, #0x4e0]
101542b94: 3c9203a0    	stur	q0, [x29, #-0xe0]
101542b98: f9427be9    	ldr	x9, [sp, #0x4f0]
101542b9c: f81303a9    	stur	x9, [x29, #-0xd0]
101542ba0: b40011a8    	cbz	x8, 0x101542dd4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3f78>
101542ba4: 3cd203a0    	ldur	q0, [x29, #-0xe0]
101542ba8: 911763e9    	add	x9, sp, #0x5d8
101542bac: 3c808120    	stur	q0, [x9, #0x8]
101542bb0: f85303a9    	ldur	x9, [x29, #-0xd0]
101542bb4: f902efe8    	str	x8, [sp, #0x5d8]
101542bb8: f902fbe9    	str	x9, [sp, #0x5f0]
101542bbc: f9430be0    	ldr	x0, [sp, #0x610]
101542bc0: 911343e8    	add	x8, sp, #0x4d0
101542bc4: 911863e1    	add	x1, sp, #0x618
101542bc8: f9400fe2    	ldr	x2, [sp, #0x18]
101542bcc: 9402be8e    	bl	0x1015f2604 <__RNvNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel17worker_setup_fits>
101542bd0: b944d3e9    	ldr	w9, [sp, #0x4d0]
101542bd4: 395353e8    	ldrb	w8, [sp, #0x4d4]
101542bd8: 7100193f    	cmp	w9, #0x6
101542bdc: 54001161    	b.ne	0x101542e08 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3fac>
101542be0: 36001308    	tbz	w8, #0x0, 0x101542e40 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3fe4>
101542be4: f9430be8    	ldr	x8, [sp, #0x610]
101542be8: f941cd01    	ldr	x1, [x8, #0x398]
101542bec: b94032c0    	ldr	w0, [x22, #0x30]
101542bf0: eb00003f    	cmp	x1, x0
101542bf4: 54003229    	b.ls	0x101543238 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x43dc>
101542bf8: f941c908    	ldr	x8, [x8, #0x390]
101542bfc: 5280a809    	mov	w9, #0x540              ; =1344
101542c00: 9ba92008    	umaddl	x8, w0, w9, x8
101542c04: b9452109    	ldr	w9, [x8, #0x520]
101542c08: 3dc14500    	ldr	q0, [x8, #0x510]
101542c0c: 3c9403a0    	stur	q0, [x29, #-0xc0]
101542c10: b81503a9    	stur	w9, [x29, #-0xb0]
101542c14: 911343e8    	add	x8, sp, #0x4d0
101542c18: 910ee2a0    	add	x0, x21, #0x3b8
101542c1c: 94375ea2    	bl	0x10231a6a4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
101542c20: f9426be8    	ldr	x8, [sp, #0x4d0]
101542c24: f100051f    	cmp	x8, #0x1
101542c28: 54001581    	b.ne	0x101542ed8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x407c>
101542c2c: f9426fe1    	ldr	x1, [sp, #0x4d8]
101542c30: f94273e2    	ldr	x2, [sp, #0x4e0]
101542c34: 911343f3    	add	x19, sp, #0x4d0
101542c38: 911343e8    	add	x8, sp, #0x4d0
101542c3c: 910ee2a0    	add	x0, x21, #0x3b8
101542c40: 911863e3    	add	x3, sp, #0x618
101542c44: 943768bb    	bl	0x10231cf30 <__RNvMs3_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workersNtB7_23NativeLibraryWorkBudget32reserve_worker_group_with_memory>
101542c48: 395423e8    	ldrb	w8, [sp, #0x508]
101542c4c: 7100091f    	cmp	w8, #0x2
101542c50: 54001661    	b.ne	0x101542f1c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x40c0>
101542c54: b944d3e8    	ldr	w8, [sp, #0x4d0]
101542c58: 7100691f    	cmp	w8, #0x1a
101542c5c: 54002301    	b.ne	0x1015430bc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4260>
101542c60: b85403a9    	ldur	w9, [x29, #-0xc0]
101542c64: 385443a8    	ldurb	w8, [x29, #-0xbc]
101542c68: 911763ea    	add	x10, sp, #0x5d8
101542c6c: b84fd14a    	ldur	w10, [x10, #0xfd]
101542c70: b903f3ea    	str	w10, [sp, #0x3f0]
101542c74: b85483aa    	ldur	w10, [x29, #-0xb8]
101542c78: b80a332a    	stur	w10, [x25, #0xa3]
101542c7c: 5280008a    	mov	w10, #0x4               ; =4
101542c80: d10303ab    	sub	x11, x29, #0xc0
101542c84: fc40c160    	ldur	d0, [x11, #0xc]
101542c88: 14000110    	b	0x1015430c8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x426c>
101542c8c: ad4507e0    	ldp	q0, q1, [sp, #0xa0]
101542c90: 3c804340    	stur	q0, [x26, #0x4]
101542c94: 3c814341    	stur	q1, [x26, #0x14]
101542c98: 3dc033e0    	ldr	q0, [sp, #0xc0]
101542c9c: 3c824340    	stur	q0, [x26, #0x24]
101542ca0: f9406be8    	ldr	x8, [sp, #0xd0]
101542ca4: f8034348    	stur	x8, [x26, #0x34]
101542ca8: ad5207e0    	ldp	q0, q1, [sp, #0x240]
101542cac: f9402be8    	ldr	x8, [sp, #0x50]
101542cb0: 3c804100    	stur	q0, [x8, #0x4]
101542cb4: 52800049    	mov	w9, #0x2                ; =2
101542cb8: b9000109    	str	w9, [x8]
101542cbc: 3c814101    	stur	q1, [x8, #0x14]
101542cc0: 3dc09be0    	ldr	q0, [sp, #0x260]
101542cc4: 3c824100    	stur	q0, [x8, #0x24]
101542cc8: 3cc2c340    	ldur	q0, [x26, #0x2c]
101542ccc: 3d800d00    	str	q0, [x8, #0x30]
101542cd0: 910fc3e0    	add	x0, sp, #0x3f0
101542cd4: 97ff774e    	bl	0x101520a0c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
101542cd8: 14000009    	b	0x101542cfc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ea0>
101542cdc: f9402be8    	ldr	x8, [sp, #0x50]
101542ce0: b900011f    	str	wzr, [x8]
101542ce4: 52800189    	mov	w9, #0xc                ; =12
101542ce8: 39002109    	strb	w9, [x8, #0x8]
101542cec: 9000d7a9    	adrp	x9, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
101542cf0: 9125ad29    	add	x9, x9, #0x96b
101542cf4: 5280060a    	mov	w10, #0x30              ; =48
101542cf8: a9012909    	stp	x9, x10, [x8, #0x10]
101542cfc: 911183e0    	add	x0, sp, #0x460
101542d00: 97ff7c1f    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
101542d04: 17fffdb3    	b	0x1015423d0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3574>
101542d08: 5280003b    	mov	w27, #0x1               ; =1
101542d0c: f0012442    	adrp	x2, 0x1039cd000 <_anon.369b439a638cb010e9292f03e79ebf78.285+0x710>
101542d10: 9134a042    	add	x2, x2, #0xd28
101542d14: 9462c546    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101542d18: 1400014b    	b	0x101543244 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x43e8>
101542d1c: 9000d5e8    	adrp	x8, 0x102ffe000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x1d3>
101542d20: 3dc04d00    	ldr	q0, [x8, #0x130]
101542d24: f9402be8    	ldr	x8, [sp, #0x50]
101542d28: 3c808100    	stur	q0, [x8, #0x8]
101542d2c: 528000c9    	mov	w9, #0x6                ; =6
101542d30: b9000109    	str	w9, [x8]
101542d34: 911343e0    	add	x0, sp, #0x4d0
101542d38: 97ff74d9    	bl	0x10152009c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationNtNtB16_5error18MemoryRuntimeErrorEECs29QkOtpKx6e_8mech_gpu>
101542d3c: 17fffda5    	b	0x1015423d0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3574>
101542d40: b944d7e9    	ldr	w9, [sp, #0x4d4]
101542d44: f9426fea    	ldr	x10, [sp, #0x4d8]
101542d48: 3dc13be0    	ldr	q0, [sp, #0x4e0]
101542d4c: 3c9203a0    	stur	q0, [x29, #-0xe0]
101542d50: 3cc28361    	ldur	q1, [x27, #0x28]
101542d54: f9402beb    	ldr	x11, [sp, #0x50]
101542d58: 3c828161    	stur	q1, [x11, #0x28]
101542d5c: 3cc38361    	ldur	q1, [x27, #0x38]
101542d60: f9427bec    	ldr	x12, [sp, #0x4f0]
101542d64: f9428fed    	ldr	x13, [sp, #0x518]
101542d68: f81303ac    	stur	x12, [x29, #-0xd0]
101542d6c: 3c838161    	stur	q1, [x11, #0x38]
101542d70: f900256d    	str	x13, [x11, #0x48]
101542d74: 3d800560    	str	q0, [x11, #0x10]
101542d78: f900116c    	str	x12, [x11, #0x20]
101542d7c: 29002568    	stp	w8, w9, [x11]
101542d80: f900056a    	str	x10, [x11, #0x8]
101542d84: 1400001a    	b	0x101542dec <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3f90>
101542d88: f0012442    	adrp	x2, 0x1039cd000 <_anon.369b439a638cb010e9292f03e79ebf78.285+0x710>
101542d8c: 9131a042    	add	x2, x2, #0xc68
101542d90: aa1403e0    	mov	x0, x20
101542d94: 9462c526    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101542d98: d0012442    	adrp	x2, 0x1039cc000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.291+0x310>
101542d9c: 913b8042    	add	x2, x2, #0xee0
101542da0: f94017e1    	ldr	x1, [sp, #0x28]
101542da4: 9462c522    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101542da8: 14000127    	b	0x101543244 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x43e8>
101542dac: 9000d7a8    	adrp	x8, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
101542db0: 9124b108    	add	x8, x8, #0x92c
101542db4: f94003e9    	ldr	x9, [sp]
101542db8: b27e0529    	orr	x9, x9, #0xc
101542dbc: f9402bea    	ldr	x10, [sp, #0x50]
101542dc0: a900a149    	stp	x9, x8, [x10, #0x8]
101542dc4: 52800368    	mov	w8, #0x1b               ; =27
101542dc8: f9000d48    	str	x8, [x10, #0x18]
101542dcc: b900015f    	str	wzr, [x10]
101542dd0: 17ffffcb    	b	0x101542cfc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ea0>
101542dd4: 9000d5e8    	adrp	x8, 0x102ffe000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x1d3>
101542dd8: 3dc04d00    	ldr	q0, [x8, #0x130]
101542ddc: f9402be8    	ldr	x8, [sp, #0x50]
101542de0: 3c808100    	stur	q0, [x8, #0x8]
101542de4: 528000c9    	mov	w9, #0x6                ; =6
101542de8: b9000109    	str	w9, [x8]
101542dec: f85083a8    	ldur	x8, [x29, #-0xf8]
101542df0: b4001be8    	cbz	x8, 0x10154316c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4310>
101542df4: f85103a0    	ldur	x0, [x29, #-0xf0]
101542df8: d37df101    	lsl	x1, x8, #3
101542dfc: 52800102    	mov	w2, #0x8                ; =8
101542e00: 97ab19cf    	bl	0x10000953c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
101542e04: 140000da    	b	0x10154316c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4310>
101542e08: 3cc15360    	ldur	q0, [x27, #0x15]
101542e0c: f9402bea    	ldr	x10, [sp, #0x50]
101542e10: 3c815140    	stur	q0, [x10, #0x15]
101542e14: 3cc25360    	ldur	q0, [x27, #0x25]
101542e18: 3c825140    	stur	q0, [x10, #0x25]
101542e1c: 3cc35360    	ldur	q0, [x27, #0x35]
101542e20: 3c835140    	stur	q0, [x10, #0x35]
101542e24: 3dc147e0    	ldr	q0, [sp, #0x510]
101542e28: 3d801140    	str	q0, [x10, #0x40]
101542e2c: 3cc05360    	ldur	q0, [x27, #0x5]
101542e30: 3c805140    	stur	q0, [x10, #0x5]
101542e34: b9000149    	str	w9, [x10]
101542e38: 39001148    	strb	w8, [x10, #0x4]
101542e3c: 140000c2    	b	0x101543144 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x42e8>
101542e40: 9000d5e8    	adrp	x8, 0x102ffe000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x1d3>
101542e44: 3dc04d00    	ldr	q0, [x8, #0x130]
101542e48: f9402be8    	ldr	x8, [sp, #0x50]
101542e4c: 3c808100    	stur	q0, [x8, #0x8]
101542e50: 528000c9    	mov	w9, #0x6                ; =6
101542e54: b9000109    	str	w9, [x8]
101542e58: 140000bb    	b	0x101543144 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x42e8>
101542e5c: f9402be8    	ldr	x8, [sp, #0x50]
101542e60: b900011f    	str	wzr, [x8]
101542e64: 52800189    	mov	w9, #0xc                ; =12
101542e68: b000d78a    	adrp	x10, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101542e6c: 91353d4a    	add	x10, x10, #0xd4f
101542e70: a900a909    	stp	x9, x10, [x8, #0x8]
101542e74: 52800389    	mov	w9, #0x1c               ; =28
101542e78: f9000d09    	str	x9, [x8, #0x18]
101542e7c: 17ffffa0    	b	0x101542cfc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ea0>
101542e80: 911343e0    	add	x0, sp, #0x4d0
101542e84: d2800001    	mov	x1, #0x0                ; =0
101542e88: 52800102    	mov	w2, #0x8                ; =8
101542e8c: aa1403e3    	mov	x3, x20
101542e90: 52800104    	mov	w4, #0x8                ; =8
101542e94: 52800105    	mov	w5, #0x8                ; =8
101542e98: 946231e1    	bl	0x102dcf61c <__RNvMs4_NtCsgKscDXrlV49_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs29QkOtpKx6e_8mech_gpu>
101542e9c: b944d3e8    	ldr	w8, [sp, #0x4d0]
101542ea0: 360002e8    	tbz	w8, #0x0, 0x101542efc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x40a0>
101542ea4: 9000d7a8    	adrp	x8, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
101542ea8: 91266d08    	add	x8, x8, #0x99b
101542eac: 52800189    	mov	w9, #0xc                ; =12
101542eb0: f9402bea    	ldr	x10, [sp, #0x50]
101542eb4: a900a149    	stp	x9, x8, [x10, #0x8]
101542eb8: 528004e8    	mov	w8, #0x27               ; =39
101542ebc: f9000d48    	str	x8, [x10, #0x18]
101542ec0: b900015f    	str	wzr, [x10]
101542ec4: 140000aa    	b	0x10154316c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4310>
101542ec8: f0012442    	adrp	x2, 0x1039cd000 <_anon.369b439a638cb010e9292f03e79ebf78.285+0x710>
101542ecc: 9130e042    	add	x2, x2, #0xc38
101542ed0: aa1403e0    	mov	x0, x20
101542ed4: 9462c4d6    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101542ed8: f9402be8    	ldr	x8, [sp, #0x50]
101542edc: b900011f    	str	wzr, [x8]
101542ee0: b000d789    	adrp	x9, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101542ee4: 9136b929    	add	x9, x9, #0xdae
101542ee8: 5280018a    	mov	w10, #0xc               ; =12
101542eec: a900a50a    	stp	x10, x9, [x8, #0x8]
101542ef0: 528004e9    	mov	w9, #0x27               ; =39
101542ef4: f9000d09    	str	x9, [x8, #0x18]
101542ef8: 14000093    	b	0x101543144 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x42e8>
101542efc: f9426fe9    	ldr	x9, [sp, #0x4d8]
101542f00: f94347e8    	ldr	x8, [sp, #0x688]
101542f04: 17ffff12    	b	0x101542b4c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3cf0>
101542f08: f0012448    	adrp	x8, 0x1039cd000 <_anon.369b439a638cb010e9292f03e79ebf78.285+0x710>
101542f0c: 91314108    	add	x8, x8, #0xc50
101542f10: aa0203e0    	mov	x0, x2
101542f14: aa0803e2    	mov	x2, x8
101542f18: 9462c4c5    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101542f1c: 395343e8    	ldrb	w8, [sp, #0x4d0]
101542f20: b944d7e9    	ldr	w9, [sp, #0x4d4]
101542f24: 910583ec    	add	x12, sp, #0x160
101542f28: b8003189    	stur	w9, [x12, #0x3]
101542f2c: b8401369    	ldur	w9, [x27, #0x1]
101542f30: b90163e9    	str	w9, [sp, #0x160]
101542f34: 3dc13be0    	ldr	q0, [sp, #0x4e0]
101542f38: 3dc13fe1    	ldr	q1, [sp, #0x4f0]
101542f3c: ad1207e0    	stp	q0, q1, [sp, #0x240]
101542f40: f94283ea    	ldr	x10, [sp, #0x500]
101542f44: f94287e9    	ldr	x9, [sp, #0x508]
101542f48: d10283ab    	sub	x11, x29, #0xa0
101542f4c: f90133ea    	str	x10, [sp, #0x260]
101542f50: fd426fe0    	ldr	d0, [sp, #0x4d8]
101542f54: b840318a    	ldur	w10, [x12, #0x3]
101542f58: b80633ea    	stur	w10, [sp, #0x63]
101542f5c: b94163ea    	ldr	w10, [sp, #0x160]
101542f60: b90063ea    	str	w10, [sp, #0x60]
101542f64: ad520be1    	ldp	q1, q2, [sp, #0x240]
101542f68: f94133ea    	ldr	x10, [sp, #0x260]
101542f6c: f90243ea    	str	x10, [sp, #0x480]
101542f70: 3d811fe2    	str	q2, [sp, #0x470]
101542f74: 3d811be1    	str	q1, [sp, #0x460]
101542f78: b84633ea    	ldur	w10, [sp, #0x63]
101542f7c: b901a7ea    	str	w10, [sp, #0x1a4]
101542f80: b94063ea    	ldr	w10, [sp, #0x60]
101542f84: b804118a    	stur	w10, [x12, #0x41]
101542f88: 3dc11be1    	ldr	q1, [sp, #0x460]
101542f8c: 3dc11fe2    	ldr	q2, [sp, #0x470]
101542f90: f94243ea    	ldr	x10, [sp, #0x480]
101542f94: ad0d8be1    	stp	q1, q2, [sp, #0x1b0]
101542f98: 390683e8    	strb	w8, [sp, #0x1a0]
101542f9c: fd00d7e0    	str	d0, [sp, #0x1a8]
101542fa0: a91d27ea    	stp	x10, x9, [sp, #0x1d0]
101542fa4: f9402fe8    	ldr	x8, [sp, #0x58]
101542fa8: 3dc13900    	ldr	q0, [x8, #0x4e0]
101542fac: 3c8a8360    	stur	q0, [x27, #0xa8]
101542fb0: f9427909    	ldr	x9, [x8, #0x4f0]
101542fb4: ad440500    	ldp	q0, q1, [x8, #0x80]
101542fb8: 3d8157e0    	str	q0, [sp, #0x550]
101542fbc: 3d815be1    	str	q1, [sp, #0x560]
101542fc0: f940510a    	ldr	x10, [x8, #0xa0]
101542fc4: f902c7e9    	str	x9, [sp, #0x588]
101542fc8: f902bbea    	str	x10, [sp, #0x570]
101542fcc: ad420500    	ldp	q0, q1, [x8, #0x40]
101542fd0: 3d8147e0    	str	q0, [sp, #0x510]
101542fd4: 3d814be1    	str	q1, [sp, #0x520]
101542fd8: ad430101    	ldp	q1, q0, [x8, #0x60]
101542fdc: 3d8153e0    	str	q0, [sp, #0x540]
101542fe0: 3d814fe1    	str	q1, [sp, #0x530]
101542fe4: ad400500    	ldp	q0, q1, [x8]
101542fe8: 3d8137e0    	str	q0, [sp, #0x4d0]
101542fec: 3d813be1    	str	q1, [sp, #0x4e0]
101542ff0: ad410101    	ldp	q1, q0, [x8, #0x20]
101542ff4: 3d8143e0    	str	q0, [sp, #0x500]
101542ff8: 3d813fe1    	str	q1, [sp, #0x4f0]
101542ffc: f9401fe8    	ldr	x8, [sp, #0x38]
101543000: a935ffa8    	stp	x8, xzr, [x29, #-0xa8]
101543004: f81683bf    	stur	xzr, [x29, #-0x98]
101543008: d10403a8    	sub	x8, x29, #0x100
10154300c: 9119e3e9    	add	x9, sp, #0x678
101543010: f90123e8    	str	x8, [sp, #0x240]
101543014: f90127e9    	str	x9, [sp, #0x248]
101543018: 910683e8    	add	x8, sp, #0x1a0
10154301c: 911863e9    	add	x9, sp, #0x618
101543020: f9012be8    	str	x8, [sp, #0x250]
101543024: f9012fe9    	str	x9, [sp, #0x258]
101543028: d10303a8    	sub	x8, x29, #0xc0
10154302c: f90137eb    	str	x11, [sp, #0x268]
101543030: 911843e9    	add	x9, sp, #0x610
101543034: f90133e8    	str	x8, [sp, #0x260]
101543038: f9013be9    	str	x9, [sp, #0x270]
10154303c: d102a3a8    	sub	x8, x29, #0xa8
101543040: 911343e9    	add	x9, sp, #0x4d0
101543044: f9013fe8    	str	x8, [sp, #0x278]
101543048: f90143e9    	str	x9, [sp, #0x280]
10154304c: d0012441    	adrp	x1, 0x1039cd000 <_anon.369b439a638cb010e9292f03e79ebf78.285+0x710>
101543050: 9133e021    	add	x1, x1, #0xcf8
101543054: 910fc3e8    	add	x8, sp, #0x3f0
101543058: 910903e0    	add	x0, sp, #0x240
10154305c: 94027804    	bl	0x1015e106c <__RINvNtNtCsgirOGyZpP7g_3std6thread6scoped5scopeNCNvMs0_NtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallelNtBS_10Invocation12run_parallelsc_0INtNtCsgDHHaSskbIF_4core6result6ResultINtNtCsgKscDXrlV49_5alloc3vec3VecIB2P_NtBQ_7ReceiptNtBU_27NativeProgramExecutionErrorEEB4f_EEB10_>
101543060: ad4d07e0    	ldp	q0, q1, [sp, #0x1a0]
101543064: ad1207e0    	stp	q0, q1, [sp, #0x240]
101543068: ad4e07e0    	ldp	q0, q1, [sp, #0x1c0]
10154306c: ad1307e0    	stp	q0, q1, [sp, #0x260]
101543070: 911183e8    	add	x8, sp, #0x460
101543074: 910903e0    	add	x0, sp, #0x240
101543078: 94376d95    	bl	0x10231e6cc <__RNvMs4_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workersNtB5_15NativeWorkGroup29finish_with_credit_statistics>
10154307c: b94463e8    	ldr	w8, [sp, #0x460]
101543080: 360007c8    	tbz	w8, #0x0, 0x101543178 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x431c>
101543084: f9423fe8    	ldr	x8, [sp, #0x478]
101543088: 3dc123e0    	ldr	q0, [sp, #0x480]
10154308c: f9402be9    	ldr	x9, [sp, #0x50]
101543090: 3d800d20    	str	q0, [x9, #0x30]
101543094: b85403aa    	ldur	w10, [x29, #-0xc0]
101543098: 3cc08300    	ldur	q0, [x24, #0x8]
10154309c: 5280008b    	mov	w11, #0x4               ; =4
1015430a0: 2900292b    	stp	w11, w10, [x9]
1015430a4: d10303aa    	sub	x10, x29, #0xc0
1015430a8: 3cc04141    	ldur	q1, [x10, #0x4]
1015430ac: 3c808121    	stur	q1, [x9, #0x8]
1015430b0: 3c818120    	stur	q0, [x9, #0x18]
1015430b4: 52800509    	mov	w9, #0x28               ; =40
1015430b8: 1400007a    	b	0x1015432a0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4444>
1015430bc: 5280000a    	mov	w10, #0x0               ; =0
1015430c0: fd426be0    	ldr	d0, [sp, #0x4d0]
1015430c4: 528001a8    	mov	w8, #0xd                ; =13
1015430c8: b84a332b    	ldur	w11, [x25, #0xa3]
1015430cc: 910583ec    	add	x12, sp, #0x160
1015430d0: b800318b    	stur	w11, [x12, #0x3]
1015430d4: b943f3eb    	ldr	w11, [sp, #0x3f0]
1015430d8: b90163eb    	str	w11, [sp, #0x160]
1015430dc: 3cc08261    	ldur	q1, [x19, #0x8]
1015430e0: 3cc18262    	ldur	q2, [x19, #0x18]
1015430e4: ad120be1    	stp	q1, q2, [sp, #0x240]
1015430e8: f842826b    	ldur	x11, [x19, #0x28]
1015430ec: f90133eb    	str	x11, [sp, #0x260]
1015430f0: b840318c    	ldur	w12, [x12, #0x3]
1015430f4: b80633ec    	stur	w12, [sp, #0x63]
1015430f8: b94163ec    	ldr	w12, [sp, #0x160]
1015430fc: b90063ec    	str	w12, [sp, #0x60]
101543100: f90243eb    	str	x11, [sp, #0x480]
101543104: 3d811fe2    	str	q2, [sp, #0x470]
101543108: 3d811be1    	str	q1, [sp, #0x460]
10154310c: 2a0c03eb    	mov	w11, w12
101543110: f9402bec    	ldr	x12, [sp, #0x50]
101543114: b800918b    	stur	w11, [x12, #0x9]
101543118: b84633eb    	ldur	w11, [sp, #0x63]
10154311c: b9000d8b    	str	w11, [x12, #0xc]
101543120: 3dc11be1    	ldr	q1, [sp, #0x460]
101543124: 3dc11fe2    	ldr	q2, [sp, #0x470]
101543128: 3c818181    	stur	q1, [x12, #0x18]
10154312c: 3c828182    	stur	q2, [x12, #0x28]
101543130: f94243eb    	ldr	x11, [sp, #0x480]
101543134: f9001d8b    	str	x11, [x12, #0x38]
101543138: 2900258a    	stp	w10, w9, [x12]
10154313c: 39002188    	strb	w8, [x12, #0x8]
101543140: fd000980    	str	d0, [x12, #0x10]
101543144: 5280003c    	mov	w28, #0x1               ; =1
101543148: 911763e0    	add	x0, sp, #0x5d8
10154314c: 97ff7a64    	bl	0x101521adc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs29QkOtpKx6e_8mech_gpu>
101543150: f85083a8    	ldur	x8, [x29, #-0xf8]
101543154: b40000a8    	cbz	x8, 0x101543168 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x430c>
101543158: f85103a0    	ldur	x0, [x29, #-0xf0]
10154315c: d37df101    	lsl	x1, x8, #3
101543160: 52800102    	mov	w2, #0x8                ; =8
101543164: 97ab18f6    	bl	0x10000953c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
101543168: 3607935a    	tbz	w26, #0x0, 0x1015423d0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3574>
10154316c: 910843e0    	add	x0, sp, #0x210
101543170: 97ff7a79    	bl	0x101521b54 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs29QkOtpKx6e_8mech_gpu>
101543174: 17fffc97    	b	0x1015423d0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3574>
101543178: f9423fe8    	ldr	x8, [sp, #0x478]
10154317c: f9420ea9    	ldr	x9, [x21, #0x418]
101543180: ab080129    	adds	x9, x9, x8
101543184: 54000622    	b.hs	0x101543248 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x43ec>
101543188: f94243ea    	ldr	x10, [sp, #0x480]
10154318c: f94247e8    	ldr	x8, [sp, #0x488]
101543190: f9020ea9    	str	x9, [x21, #0x418]
101543194: f94212a9    	ldr	x9, [x21, #0x420]
101543198: ab0a0129    	adds	x9, x9, x10
10154319c: 54000622    	b.hs	0x101543260 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4404>
1015431a0: f90212a9    	str	x9, [x21, #0x420]
1015431a4: f94216a9    	ldr	x9, [x21, #0x428]
1015431a8: ab080128    	adds	x8, x9, x8
1015431ac: 540006a2    	b.hs	0x101543280 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4424>
1015431b0: f90216a8    	str	x8, [x21, #0x428]
1015431b4: ad5087e0    	ldp	q0, q1, [sp, #0x210]
1015431b8: ad1207e0    	stp	q0, q1, [sp, #0x240]
1015431bc: 5280001a    	mov	w26, #0x0               ; =0
1015431c0: 910903e0    	add	x0, sp, #0x240
1015431c4: 97ff7a64    	bl	0x101521b54 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs29QkOtpKx6e_8mech_gpu>
1015431c8: b943f3e8    	ldr	w8, [sp, #0x3f0]
1015431cc: 7100191f    	cmp	w8, #0x6
1015431d0: 54000721    	b.ne	0x1015432b4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4458>
1015431d4: d2800009    	mov	x9, #0x0                ; =0
1015431d8: 3cca8320    	ldur	q0, [x25, #0xa8]
1015431dc: 3c9703a0    	stur	q0, [x29, #-0x90]
1015431e0: f94207e8    	ldr	x8, [sp, #0x408]
1015431e4: f81803a8    	stur	x8, [x29, #-0x80]
1015431e8: f85783b4    	ldur	x20, [x29, #-0x88]
1015431ec: 5280190a    	mov	w10, #0xc8              ; =200
1015431f0: 9b0a7d0a    	mul	x10, x8, x10
1015431f4: 8b0a029b    	add	x27, x20, x10
1015431f8: eb09015f    	cmp	x10, x9
1015431fc: 54000740    	b.eq	0x1015432e4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4488>
101543200: f8696a8b    	ldr	x11, [x20, x9]
101543204: 91032129    	add	x9, x9, #0xc8
101543208: b4ffff8b    	cbz	x11, 0x1015431f8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x439c>
10154320c: 1400004a    	b	0x101543334 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x44d8>
101543210: d0012442    	adrp	x2, 0x1039cd000 <_anon.369b439a638cb010e9292f03e79ebf78.285+0x710>
101543214: 9132c042    	add	x2, x2, #0xcb0
101543218: f9401be0    	ldr	x0, [sp, #0x30]
10154321c: 9462c404    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101543220: 14000009    	b	0x101543244 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x43e8>
101543224: d0012442    	adrp	x2, 0x1039cd000 <_anon.369b439a638cb010e9292f03e79ebf78.285+0x710>
101543228: 91332042    	add	x2, x2, #0xcc8
10154322c: f94017e0    	ldr	x0, [sp, #0x28]
101543230: 9462c3ff    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101543234: 14000004    	b	0x101543244 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x43e8>
101543238: d0012442    	adrp	x2, 0x1039cd000 <_anon.369b439a638cb010e9292f03e79ebf78.285+0x710>
10154323c: 91338042    	add	x2, x2, #0xce0
101543240: 9462c3fb    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101543244: d4200020    	brk	#0x1
101543248: f9402be8    	ldr	x8, [sp, #0x50]
10154324c: b900011f    	str	wzr, [x8]
101543250: 52800189    	mov	w9, #0xc                ; =12
101543254: 9000d78a    	adrp	x10, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101543258: 9137554a    	add	x10, x10, #0xdd5
10154325c: 14000006    	b	0x101543274 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4418>
101543260: f9402be8    	ldr	x8, [sp, #0x50]
101543264: b900011f    	str	wzr, [x8]
101543268: 52800189    	mov	w9, #0xc                ; =12
10154326c: 9000d78a    	adrp	x10, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101543270: 9137f94a    	add	x10, x10, #0xdfe
101543274: a900a909    	stp	x9, x10, [x8, #0x8]
101543278: 52800528    	mov	w8, #0x29               ; =41
10154327c: 14000008    	b	0x10154329c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4440>
101543280: f9402be8    	ldr	x8, [sp, #0x50]
101543284: b900011f    	str	wzr, [x8]
101543288: 52800189    	mov	w9, #0xc                ; =12
10154328c: 9000d78a    	adrp	x10, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101543290: 91389d4a    	add	x10, x10, #0xe27
101543294: a900a909    	stp	x9, x10, [x8, #0x8]
101543298: 52800568    	mov	w8, #0x2b               ; =43
10154329c: 52800309    	mov	w9, #0x18               ; =24
1015432a0: f9402bea    	ldr	x10, [sp, #0x50]
1015432a4: f8296948    	str	x8, [x10, x9]
1015432a8: 910fc3e0    	add	x0, sp, #0x3f0
1015432ac: 97ff72d6    	bl	0x10151fe04 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultINtNtCsgKscDXrlV49_5alloc3vec3VecIBH_NtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1J_27NativeProgramExecutionErrorEEB3c_EEB1P_>
1015432b0: 17ffffa5    	b	0x101543144 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x42e8>
1015432b4: 3dc10be0    	ldr	q0, [sp, #0x420]
1015432b8: 3dc10fe1    	ldr	q1, [sp, #0x430]
1015432bc: f9402be9    	ldr	x9, [sp, #0x50]
1015432c0: ad018520    	stp	q0, q1, [x9, #0x30]
1015432c4: 3cca4320    	ldur	q0, [x25, #0xa4]
1015432c8: 3c804120    	stur	q0, [x9, #0x4]
1015432cc: 3dc107e0    	ldr	q0, [sp, #0x410]
1015432d0: 3dc103e1    	ldr	q1, [sp, #0x400]
1015432d4: ad008121    	stp	q1, q0, [x9, #0x10]
1015432d8: b9000128    	str	w8, [x9]
1015432dc: 5280001a    	mov	w26, #0x0               ; =0
1015432e0: 17ffff99    	b	0x101543144 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x42e8>
1015432e4: f94222a9    	ldr	x9, [x21, #0x440]
1015432e8: b100053f    	cmn	x9, #0x1
1015432ec: 54001060    	b.eq	0x1015434f8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x469c>
1015432f0: 91000529    	add	x9, x9, #0x1
1015432f4: f90222a9    	str	x9, [x21, #0x440]
1015432f8: f9421ea9    	ldr	x9, [x21, #0x438]
1015432fc: f94347ea    	ldr	x10, [sp, #0x688]
101543300: ab090149    	adds	x9, x10, x9
101543304: 54000fa2    	b.hs	0x1015434f8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x469c>
101543308: f9021ea9    	str	x9, [x21, #0x438]
10154330c: f94226a9    	ldr	x9, [x21, #0x448]
101543310: f9400fea    	ldr	x10, [sp, #0x18]
101543314: ab0a0129    	adds	x9, x9, x10
101543318: 54000f82    	b.hs	0x101543508 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46ac>
10154331c: f90226a9    	str	x9, [x21, #0x448]
101543320: f9422aa9    	ldr	x9, [x21, #0x450]
101543324: f85683aa    	ldur	x10, [x29, #-0x98]
101543328: eb09015f    	cmp	x10, x9
10154332c: 9a898149    	csel	x9, x10, x9, hi
101543330: f9022aa9    	str	x9, [x21, #0x450]
101543334: 52801909    	mov	w9, #0xc8               ; =200
101543338: 9b097d0a    	mul	x10, x8, x9
10154333c: 9101828b    	add	x11, x20, #0x60
101543340: 9000d788    	adrp	x8, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101543344: 9139bd08    	add	x8, x8, #0xe6f
101543348: 528002e9    	mov	w9, #0x17               ; =23
10154334c: 9000d78c    	adrp	x12, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101543350: 913a198c    	add	x12, x12, #0xe86
101543354: 9000d78d    	adrp	x13, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101543358: 913a79ad    	add	x13, x13, #0xe9e
10154335c: 9000d78e    	adrp	x14, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101543360: 913ad9ce    	add	x14, x14, #0xeb6
101543364: 9000d78f    	adrp	x15, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101543368: 913b55ef    	add	x15, x15, #0xed5
10154336c: 9000d790    	adrp	x16, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101543370: 913bee10    	add	x16, x16, #0xefb
101543374: 9000d791    	adrp	x17, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101543378: 913c6a31    	add	x17, x17, #0xf1a
10154337c: 9000d781    	adrp	x1, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101543380: 913cd821    	add	x1, x1, #0xf36
101543384: 9000d782    	adrp	x2, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101543388: 913d6842    	add	x2, x2, #0xf5a
10154338c: 9000d783    	adrp	x3, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101543390: 913df863    	add	x3, x3, #0xf7e
101543394: 9000d784    	adrp	x4, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101543398: 913e7484    	add	x4, x4, #0xf9d
10154339c: 9000d780    	adrp	x0, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
1015433a0: 913ee800    	add	x0, x0, #0xfba
1015433a4: 9000d785    	adrp	x5, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
1015433a8: 913f88a5    	add	x5, x5, #0xfe2
1015433ac: 14000003    	b	0x1015433b8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x455c>
1015433b0: d103214a    	sub	x10, x10, #0xc8
1015433b4: 9103216b    	add	x11, x11, #0xc8
1015433b8: b4000b0a    	cbz	x10, 0x101543518 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46bc>
1015433bc: f85a0166    	ldur	x6, [x11, #-0x60]
1015433c0: f10004df    	cmp	x6, #0x1
1015433c4: 54ffff60    	b.eq	0x1015433b0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4554>
1015433c8: f9419aa6    	ldr	x6, [x21, #0x330]
1015433cc: f85e8167    	ldur	x7, [x11, #-0x18]
1015433d0: ab0600e6    	adds	x6, x7, x6
1015433d4: 54001c42    	b.hs	0x10154375c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4900>
1015433d8: f9019aa6    	str	x6, [x21, #0x330]
1015433dc: f941e6a6    	ldr	x6, [x21, #0x3c8]
1015433e0: f85f0167    	ldur	x7, [x11, #-0x10]
1015433e4: ab0600e6    	adds	x6, x7, x6
1015433e8: 54001742    	b.hs	0x1015436d0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4874>
1015433ec: f901e6a6    	str	x6, [x21, #0x3c8]
1015433f0: f941eaa6    	ldr	x6, [x21, #0x3d0]
1015433f4: f85f8167    	ldur	x7, [x11, #-0x8]
1015433f8: ab0600e6    	adds	x6, x7, x6
1015433fc: 54001702    	b.hs	0x1015436dc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4880>
101543400: f901eaa6    	str	x6, [x21, #0x3d0]
101543404: f941eea6    	ldr	x6, [x21, #0x3d8]
101543408: f9400167    	ldr	x7, [x11]
10154340c: ab0600e6    	adds	x6, x7, x6
101543410: 540016c2    	b.hs	0x1015436e8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x488c>
101543414: f901eea6    	str	x6, [x21, #0x3d8]
101543418: f941f2a6    	ldr	x6, [x21, #0x3e0]
10154341c: f9400567    	ldr	x7, [x11, #0x8]
101543420: ab0600e6    	adds	x6, x7, x6
101543424: 54001682    	b.hs	0x1015436f4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4898>
101543428: f901f2a6    	str	x6, [x21, #0x3e0]
10154342c: f941f6a6    	ldr	x6, [x21, #0x3e8]
101543430: f9400967    	ldr	x7, [x11, #0x10]
101543434: ab0600e6    	adds	x6, x7, x6
101543438: 54001642    	b.hs	0x101543700 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48a4>
10154343c: f901f6a6    	str	x6, [x21, #0x3e8]
101543440: f941faa6    	ldr	x6, [x21, #0x3f0]
101543444: f9400d67    	ldr	x7, [x11, #0x18]
101543448: ab0600e6    	adds	x6, x7, x6
10154344c: 54001602    	b.hs	0x10154370c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48b0>
101543450: f901faa6    	str	x6, [x21, #0x3f0]
101543454: f941fea6    	ldr	x6, [x21, #0x3f8]
101543458: f9401167    	ldr	x7, [x11, #0x20]
10154345c: ab0600e6    	adds	x6, x7, x6
101543460: 540015c2    	b.hs	0x101543718 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48bc>
101543464: f901fea6    	str	x6, [x21, #0x3f8]
101543468: f94202a6    	ldr	x6, [x21, #0x400]
10154346c: f9401567    	ldr	x7, [x11, #0x28]
101543470: ab0600e6    	adds	x6, x7, x6
101543474: 54001582    	b.hs	0x101543724 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48c8>
101543478: f90202a6    	str	x6, [x21, #0x400]
10154347c: f94206a6    	ldr	x6, [x21, #0x408]
101543480: f9401967    	ldr	x7, [x11, #0x30]
101543484: ab0600e6    	adds	x6, x7, x6
101543488: 54001542    	b.hs	0x101543730 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48d4>
10154348c: f90206a6    	str	x6, [x21, #0x408]
101543490: f9420aa6    	ldr	x6, [x21, #0x410]
101543494: f9401d67    	ldr	x7, [x11, #0x38]
101543498: ab0600e6    	adds	x6, x7, x6
10154349c: 54001502    	b.hs	0x10154373c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48e0>
1015434a0: f9020aa6    	str	x6, [x21, #0x410]
1015434a4: f9420ea6    	ldr	x6, [x21, #0x418]
1015434a8: f9402167    	ldr	x7, [x11, #0x40]
1015434ac: ab0600e6    	adds	x6, x7, x6
1015434b0: 540014c2    	b.hs	0x101543748 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48ec>
1015434b4: f9020ea6    	str	x6, [x21, #0x418]
1015434b8: f94212a6    	ldr	x6, [x21, #0x420]
1015434bc: f9402567    	ldr	x7, [x11, #0x48]
1015434c0: ab0600e6    	adds	x6, x7, x6
1015434c4: 54001422    	b.hs	0x101543748 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48ec>
1015434c8: f90212a6    	str	x6, [x21, #0x420]
1015434cc: f94216a6    	ldr	x6, [x21, #0x428]
1015434d0: f9402967    	ldr	x7, [x11, #0x50]
1015434d4: ab0600e6    	adds	x6, x7, x6
1015434d8: 54001382    	b.hs	0x101543748 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48ec>
1015434dc: f90216a6    	str	x6, [x21, #0x428]
1015434e0: f9421aa6    	ldr	x6, [x21, #0x430]
1015434e4: f9402d67    	ldr	x7, [x11, #0x58]
1015434e8: ab0600e6    	adds	x6, x7, x6
1015434ec: 54001342    	b.hs	0x101543754 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48f8>
1015434f0: f9021aa6    	str	x6, [x21, #0x430]
1015434f4: 17ffffaf    	b	0x1015433b0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4554>
1015434f8: 9000d788    	adrp	x8, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
1015434fc: 91394908    	add	x8, x8, #0xe52
101543500: 528003a9    	mov	w9, #0x1d               ; =29
101543504: 14000096    	b	0x10154375c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4900>
101543508: 9000d788    	adrp	x8, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
10154350c: 91353d08    	add	x8, x8, #0xd4f
101543510: 52800389    	mov	w9, #0x1c               ; =28
101543514: 14000092    	b	0x10154375c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4900>
101543518: a9077fff    	stp	xzr, xzr, [sp, #0x70]
10154351c: 52800108    	mov	w8, #0x8                ; =8
101543520: a90623ff    	stp	xzr, x8, [sp, #0x60]
101543524: f94347e1    	ldr	x1, [sp, #0x688]
101543528: 910183e0    	add	x0, sp, #0x60
10154352c: 94001272    	bl	0x101547ef4 <__RNvMs3_NtNtCsgKscDXrlV49_5alloc11collections9vec_dequeINtB5_8VecDequeNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionE17try_reserve_exactB1h_>
101543530: b24107e8    	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
101543534: eb08001f    	cmp	x0, x8
101543538: 540011e1    	b.ne	0x101543774 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4918>
10154353c: f94033e8    	ldr	x8, [sp, #0x60]
101543540: f94347e9    	ldr	x9, [sp, #0x688]
101543544: eb09011f    	cmp	x8, x9
101543548: 540011e1    	b.ne	0x101543784 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4928>
10154354c: f94343e9    	ldr	x9, [sp, #0x680]
101543550: f9433fea    	ldr	x10, [sp, #0x678]
101543554: 52800d0b    	mov	w11, #0x68              ; =104
101543558: 9b0b2513    	madd	x19, x8, x11, x9
10154355c: a91627e9    	stp	x9, x9, [sp, #0x160]
101543560: a9174fea    	stp	x10, x19, [sp, #0x170]
101543564: b40005a8    	cbz	x8, 0x101543618 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47bc>
101543568: 910903f7    	add	x23, sp, #0x240
10154356c: 9101a136    	add	x22, x9, #0x68
101543570: d2f00018    	mov	x24, #-0x8000000000000000 ; =-9223372036854775808
101543574: aa1603f9    	mov	x25, x22
101543578: f8598f28    	ldr	x8, [x25, #-0x68]!
10154357c: eb18011f    	cmp	x8, x24
101543580: 540004a0    	b.eq	0x101543614 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47b8>
101543584: f90123e8    	str	x8, [sp, #0x240]
101543588: 3cc58320    	ldur	q0, [x25, #0x58]
10154358c: 3c8582e0    	stur	q0, [x23, #0x58]
101543590: 3cc28320    	ldur	q0, [x25, #0x28]
101543594: 3c8282e0    	stur	q0, [x23, #0x28]
101543598: 3cc38320    	ldur	q0, [x25, #0x38]
10154359c: 3c8382e0    	stur	q0, [x23, #0x38]
1015435a0: 3cc48320    	ldur	q0, [x25, #0x48]
1015435a4: 3c8482e0    	stur	q0, [x23, #0x48]
1015435a8: 3cc08320    	ldur	q0, [x25, #0x8]
1015435ac: 3c8082e0    	stur	q0, [x23, #0x8]
1015435b0: 3cc18320    	ldur	q0, [x25, #0x18]
1015435b4: 3c8182e0    	stur	q0, [x23, #0x18]
1015435b8: f9414fe8    	ldr	x8, [sp, #0x298]
1015435bc: f94153e9    	ldr	x9, [sp, #0x2a0]
1015435c0: 3cc18320    	ldur	q0, [x25, #0x18]
1015435c4: 3d811be0    	str	q0, [sp, #0x460]
1015435c8: 3cc28320    	ldur	q0, [x25, #0x28]
1015435cc: 3d811fe0    	str	q0, [sp, #0x470]
1015435d0: 3cc38320    	ldur	q0, [x25, #0x38]
1015435d4: 3d8123e0    	str	q0, [sp, #0x480]
1015435d8: 3cc48320    	ldur	q0, [x25, #0x48]
1015435dc: 3d8127e0    	str	q0, [sp, #0x490]
1015435e0: f90253e8    	str	x8, [sp, #0x4a0]
1015435e4: f90257ff    	str	xzr, [sp, #0x4a8]
1015435e8: f9025be9    	str	x9, [sp, #0x4b0]
1015435ec: 910183e0    	add	x0, sp, #0x60
1015435f0: 911183e1    	add	x1, sp, #0x460
1015435f4: 94001219    	bl	0x101547e58 <__RNvMs3_NtNtCsgKscDXrlV49_5alloc11collections9vec_dequeINtB5_8VecDequeNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionE13push_back_mutB1h_>
1015435f8: 910903e0    	add	x0, sp, #0x240
1015435fc: 97ff7504    	bl	0x101520a0c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
101543600: 91034336    	add	x22, x25, #0xd0
101543604: 9101a328    	add	x8, x25, #0x68
101543608: eb13011f    	cmp	x8, x19
10154360c: 54fffb41    	b.ne	0x101543574 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4718>
101543610: aa1303f6    	mov	x22, x19
101543614: f900b7f6    	str	x22, [sp, #0x168]
101543618: 910583e0    	add	x0, sp, #0x160
10154361c: 9400fea0    	bl	0x10158309c <__RNvXse_NtNtCsgKscDXrlV49_5alloc3vec9into_iterINtB5_8IntoIterNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropB18_>
101543620: ad4307e0    	ldp	q0, q1, [sp, #0x60]
101543624: ad1207e0    	stp	q0, q1, [sp, #0x240]
101543628: f85703b7    	ldur	x23, [x29, #-0x90]
10154362c: 3dc18fe0    	ldr	q0, [sp, #0x630]
101543630: 3dc193e1    	ldr	q1, [sp, #0x640]
101543634: 3d811be0    	str	q0, [sp, #0x460]
101543638: 3d811fe1    	str	q1, [sp, #0x470]
10154363c: 3dc197e0    	ldr	q0, [sp, #0x650]
101543640: 3dc19be1    	ldr	q1, [sp, #0x660]
101543644: ad0b07e0    	stp	q0, q1, [sp, #0x160]
101543648: f9402fe8    	ldr	x8, [sp, #0x58]
10154364c: 910f0100    	add	x0, x8, #0x3c0
101543650: 97ff7130    	bl	0x10151fb10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel5BatchEEB1e_>
101543654: ad5207e0    	ldp	q0, q1, [sp, #0x240]
101543658: f9402fe8    	ldr	x8, [sp, #0x58]
10154365c: ad1e0500    	stp	q0, q1, [x8, #0x3c0]
101543660: 3dc11be0    	ldr	q0, [sp, #0x460]
101543664: 3dc11fe1    	ldr	q1, [sp, #0x470]
101543668: 3d810100    	str	q0, [x8, #0x400]
10154366c: 3d810501    	str	q1, [x8, #0x410]
101543670: ad4b07e0    	ldp	q0, q1, [sp, #0x160]
101543674: 3d810900    	str	q0, [x8, #0x420]
101543678: f901f114    	str	x20, [x8, #0x3e0]
10154367c: f901f514    	str	x20, [x8, #0x3e8]
101543680: f901f917    	str	x23, [x8, #0x3f0]
101543684: f901fd1b    	str	x27, [x8, #0x3f8]
101543688: 3d810d01    	str	q1, [x8, #0x430]
10154368c: 52800028    	mov	w8, #0x1                ; =1
101543690: 4e080d00    	dup.2d	v0, x8
101543694: f9402be8    	ldr	x8, [sp, #0x50]
101543698: 3c808100    	stur	q0, [x8, #0x8]
10154369c: 528000c9    	mov	w9, #0x6                ; =6
1015436a0: b9000109    	str	w9, [x8]
1015436a4: 5280001a    	mov	w26, #0x0               ; =0
1015436a8: 5280001c    	mov	w28, #0x0               ; =0
1015436ac: 911763e0    	add	x0, sp, #0x5d8
1015436b0: 97ff790b    	bl	0x101521adc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs29QkOtpKx6e_8mech_gpu>
1015436b4: f85083a8    	ldur	x8, [x29, #-0xf8]
1015436b8: b4ff7948    	cbz	x8, 0x1015425e0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3784>
1015436bc: f85103a0    	ldur	x0, [x29, #-0xf0]
1015436c0: d37df101    	lsl	x1, x8, #3
1015436c4: 52800102    	mov	w2, #0x8                ; =8
1015436c8: 97ab179d    	bl	0x10000953c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1015436cc: 17fffbc5    	b	0x1015425e0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3784>
1015436d0: aa0c03e8    	mov	x8, x12
1015436d4: 52800309    	mov	w9, #0x18               ; =24
1015436d8: 14000021    	b	0x10154375c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4900>
1015436dc: aa0d03e8    	mov	x8, x13
1015436e0: 52800309    	mov	w9, #0x18               ; =24
1015436e4: 1400001e    	b	0x10154375c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4900>
1015436e8: aa0e03e8    	mov	x8, x14
1015436ec: 528003e9    	mov	w9, #0x1f               ; =31
1015436f0: 1400001b    	b	0x10154375c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4900>
1015436f4: aa0f03e8    	mov	x8, x15
1015436f8: 528004c9    	mov	w9, #0x26               ; =38
1015436fc: 14000018    	b	0x10154375c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4900>
101543700: aa1003e8    	mov	x8, x16
101543704: 528003e9    	mov	w9, #0x1f               ; =31
101543708: 14000015    	b	0x10154375c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4900>
10154370c: aa1103e8    	mov	x8, x17
101543710: 52800389    	mov	w9, #0x1c               ; =28
101543714: 14000012    	b	0x10154375c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4900>
101543718: aa0103e8    	mov	x8, x1
10154371c: 52800489    	mov	w9, #0x24               ; =36
101543720: 1400000f    	b	0x10154375c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4900>
101543724: aa0203e8    	mov	x8, x2
101543728: 52800489    	mov	w9, #0x24               ; =36
10154372c: 1400000c    	b	0x10154375c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4900>
101543730: aa0303e8    	mov	x8, x3
101543734: 528003e9    	mov	w9, #0x1f               ; =31
101543738: 14000009    	b	0x10154375c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4900>
10154373c: aa0403e8    	mov	x8, x4
101543740: 528003a9    	mov	w9, #0x1d               ; =29
101543744: 14000006    	b	0x10154375c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4900>
101543748: aa0003e8    	mov	x8, x0
10154374c: 52800509    	mov	w9, #0x28               ; =40
101543750: 14000003    	b	0x10154375c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4900>
101543754: aa0503e8    	mov	x8, x5
101543758: 52800429    	mov	w9, #0x21               ; =33
10154375c: f9402bea    	ldr	x10, [sp, #0x50]
101543760: b900015f    	str	wzr, [x10]
101543764: 5280018b    	mov	w11, #0xc               ; =12
101543768: a900a14b    	stp	x11, x8, [x10, #0x8]
10154376c: f9000d49    	str	x9, [x10, #0x18]
101543770: 1400000f    	b	0x1015437ac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4950>
101543774: 9000d788    	adrp	x8, 0x103033000 <_anon.0233509ef4516ac916bf12a7ca216a9d.327+0x530>
101543778: 9135ad08    	add	x8, x8, #0xd6b
10154377c: 52800429    	mov	w9, #0x21               ; =33
101543780: 14000004    	b	0x101543790 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4934>
101543784: f000d788    	adrp	x8, 0x103036000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x14a0>
101543788: 91270908    	add	x8, x8, #0x9c2
10154378c: 52800609    	mov	w9, #0x30               ; =48
101543790: f9402bea    	ldr	x10, [sp, #0x50]
101543794: b900015f    	str	wzr, [x10]
101543798: 5280018b    	mov	w11, #0xc               ; =12
10154379c: 3900214b    	strb	w11, [x10, #0x8]
1015437a0: a9012548    	stp	x8, x9, [x10, #0x10]
1015437a4: 910183e0    	add	x0, sp, #0x60
1015437a8: 97ff76bb    	bl	0x101521294 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCsgKscDXrlV49_5alloc11collections9vec_deque8VecDequeNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionEEB1P_>
1015437ac: d10243a0    	sub	x0, x29, #0x90
1015437b0: 97ff73f8    	bl	0x101520790 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecINtNtB4_6result6ResultNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1F_27NativeProgramExecutionErrorEEEB1L_>
1015437b4: 5280001a    	mov	w26, #0x0               ; =0
1015437b8: 17fffe63    	b	0x101543144 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x42e8>
1015437bc: aa0003f3    	mov	x19, x0
1015437c0: 5280001a    	mov	w26, #0x0               ; =0
1015437c4: 1400003a    	b	0x1015438ac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a50>
1015437c8: aa0003f3    	mov	x19, x0
1015437cc: 5280003c    	mov	w28, #0x1               ; =1
1015437d0: 14000025    	b	0x101543864 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a08>
1015437d4: aa0003f3    	mov	x19, x0
1015437d8: aa1c03f6    	mov	x22, x28
1015437dc: 14000038    	b	0x1015438bc <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a60>
1015437e0: aa0003f3    	mov	x19, x0
1015437e4: 5280001a    	mov	w26, #0x0               ; =0
1015437e8: 5280001c    	mov	w28, #0x0               ; =0
1015437ec: 52800016    	mov	w22, #0x0               ; =0
1015437f0: ad5207e0    	ldp	q0, q1, [sp, #0x240]
1015437f4: f9402fe8    	ldr	x8, [sp, #0x58]
1015437f8: ad1e0500    	stp	q0, q1, [x8, #0x3c0]
1015437fc: 3dc11be0    	ldr	q0, [sp, #0x460]
101543800: 3dc11fe1    	ldr	q1, [sp, #0x470]
101543804: 3d810100    	str	q0, [x8, #0x400]
101543808: 3d810501    	str	q1, [x8, #0x410]
10154380c: ad4b07e0    	ldp	q0, q1, [sp, #0x160]
101543810: 3d810900    	str	q0, [x8, #0x420]
101543814: f901f114    	str	x20, [x8, #0x3e0]
101543818: f901f514    	str	x20, [x8, #0x3e8]
10154381c: f901f917    	str	x23, [x8, #0x3f0]
101543820: f901fd1b    	str	x27, [x8, #0x3f8]
101543824: 3d810d01    	str	q1, [x8, #0x430]
101543828: 14000023    	b	0x1015438b4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a58>
10154382c: aa0003f3    	mov	x19, x0
101543830: 1400000a    	b	0x101543858 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x49fc>
101543834: aa0003f3    	mov	x19, x0
101543838: f900b7f6    	str	x22, [sp, #0x168]
10154383c: 14000005    	b	0x101543850 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x49f4>
101543840: aa0003f3    	mov	x19, x0
101543844: f900b7f6    	str	x22, [sp, #0x168]
101543848: 910903e0    	add	x0, sp, #0x240
10154384c: 97ff7470    	bl	0x101520a0c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
101543850: 910583e0    	add	x0, sp, #0x160
101543854: 9400fe12    	bl	0x10158309c <__RNvXse_NtNtCsgKscDXrlV49_5alloc3vec9into_iterINtB5_8IntoIterNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropB18_>
101543858: 910183e0    	add	x0, sp, #0x60
10154385c: 97ff768e    	bl	0x101521294 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCsgKscDXrlV49_5alloc11collections9vec_deque8VecDequeNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionEEB1P_>
101543860: 5280001c    	mov	w28, #0x0               ; =0
101543864: d10243a0    	sub	x0, x29, #0x90
101543868: 97ff73ca    	bl	0x101520790 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecINtNtB4_6result6ResultNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1F_27NativeProgramExecutionErrorEEEB1L_>
10154386c: 5280001a    	mov	w26, #0x0               ; =0
101543870: 14000010    	b	0x1015438b0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a54>
101543874: aa0003f3    	mov	x19, x0
101543878: 1400000c    	b	0x1015438a8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a4c>
10154387c: aa0003f3    	mov	x19, x0
101543880: 1400000a    	b	0x1015438a8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a4c>
101543884: 1400001a    	b	0x1015438ec <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a90>
101543888: 14000022    	b	0x101543910 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4ab4>
10154388c: aa0003f3    	mov	x19, x0
101543890: 910fc3e0    	add	x0, sp, #0x3f0
101543894: 97ff715c    	bl	0x10151fe04 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultINtNtCsgKscDXrlV49_5alloc3vec3VecIBH_NtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1J_27NativeProgramExecutionErrorEEB3c_EEB1P_>
101543898: 14000005    	b	0x1015438ac <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a50>
10154389c: aa0003f3    	mov	x19, x0
1015438a0: 910683e0    	add	x0, sp, #0x1a0
1015438a4: 97ff7b37    	bl	0x101522580 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workers15NativeWorkGroupECs29QkOtpKx6e_8mech_gpu>
1015438a8: 5280003a    	mov	w26, #0x1               ; =1
1015438ac: 5280003c    	mov	w28, #0x1               ; =1
1015438b0: 52800036    	mov	w22, #0x1               ; =1
1015438b4: 911763e0    	add	x0, sp, #0x5d8
1015438b8: 97ff7889    	bl	0x101521adc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs29QkOtpKx6e_8mech_gpu>
1015438bc: f85083a8    	ldur	x8, [x29, #-0xf8]
1015438c0: b40000a8    	cbz	x8, 0x1015438d4 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a78>
1015438c4: f85103a0    	ldur	x0, [x29, #-0xf0]
1015438c8: d37df101    	lsl	x1, x8, #3
1015438cc: 52800102    	mov	w2, #0x8                ; =8
1015438d0: 97ab171b    	bl	0x10000953c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1015438d4: 3600007a    	tbz	w26, #0x0, 0x1015438e0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a84>
1015438d8: 910843e0    	add	x0, sp, #0x210
1015438dc: 97ff789e    	bl	0x101521b54 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs29QkOtpKx6e_8mech_gpu>
1015438e0: 370001dc    	tbnz	w28, #0x0, 0x101543918 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4abc>
1015438e4: 1400000f    	b	0x101543920 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4ac4>
1015438e8: 14000006    	b	0x101543900 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4aa4>
1015438ec: aa0003f3    	mov	x19, x0
1015438f0: 910fc3e0    	add	x0, sp, #0x3f0
1015438f4: 97ff7446    	bl	0x101520a0c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
1015438f8: 14000003    	b	0x101543904 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4aa8>
1015438fc: 14000005    	b	0x101543910 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4ab4>
101543900: aa0003f3    	mov	x19, x0
101543904: 911183e0    	add	x0, sp, #0x460
101543908: 97ff791d    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
10154390c: 14000002    	b	0x101543914 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4ab8>
101543910: aa0003f3    	mov	x19, x0
101543914: 52800036    	mov	w22, #0x1               ; =1
101543918: 9119e3e0    	add	x0, sp, #0x678
10154391c: 97ff7403    	bl	0x101520928 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionEEB1p_>
101543920: 37000076    	tbnz	w22, #0x0, 0x10154392c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4ad0>
101543924: 14000011    	b	0x101543968 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4b0c>
101543928: aa0003f3    	mov	x19, x0
10154392c: 911943e0    	add	x0, sp, #0x650
101543930: 97ff786b    	bl	0x101521adc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs29QkOtpKx6e_8mech_gpu>
101543934: 14000008    	b	0x101543954 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4af8>
101543938: aa0003f3    	mov	x19, x0
10154393c: 911343e1    	add	x1, sp, #0x4d0
101543940: aa1703e0    	mov	x0, x23
101543944: 52802102    	mov	w2, #0x108              ; =264
101543948: 9462c7a7    	bl	0x102df57e4 <dyld_stub_binder+0x102df57e4>
10154394c: 14000037    	b	0x101543a28 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4bcc>
101543950: aa0003f3    	mov	x19, x0
101543954: 9118c3e0    	add	x0, sp, #0x630
101543958: 97ff787f    	bl	0x101521b54 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs29QkOtpKx6e_8mech_gpu>
10154395c: 14000003    	b	0x101543968 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4b0c>
101543960: 1400001e    	b	0x1015439d8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4b7c>
101543964: aa0003f3    	mov	x19, x0
101543968: f9430fe8    	ldr	x8, [sp, #0x618]
10154396c: 92800009    	mov	x9, #-0x1               ; =-1
101543970: f8690108    	ldaddl	x9, x8, [x8]
101543974: f100051f    	cmp	x8, #0x1
101543978: 54000b01    	b.ne	0x101543ad8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4c7c>
10154397c: d50339bf    	dmb	ishld
101543980: 911863e0    	add	x0, sp, #0x618
101543984: 945ebcac    	bl	0x102cf2c34 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101543988: 14000054    	b	0x101543ad8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4c7c>
10154398c: aa0003f3    	mov	x19, x0
101543990: f9426be8    	ldr	x8, [sp, #0x4d0]
101543994: 92800009    	mov	x9, #-0x1               ; =-1
101543998: f8690108    	ldaddl	x9, x8, [x8]
10154399c: f100051f    	cmp	x8, #0x1
1015439a0: 540009c1    	b.ne	0x101543ad8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4c7c>
1015439a4: d50339bf    	dmb	ishld
1015439a8: 911343e0    	add	x0, sp, #0x4d0
1015439ac: 945ebca2    	bl	0x102cf2c34 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015439b0: 1400004a    	b	0x101543ad8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4c7c>
1015439b4: 9462c218    	bl	0x102df4214 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1015439b8: aa0003f3    	mov	x19, x0
1015439bc: d2f00008    	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1015439c0: f9000288    	str	x8, [x20]
1015439c4: 1400001f    	b	0x101543a40 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4be4>
1015439c8: aa0003f3    	mov	x19, x0
1015439cc: 910903e0    	add	x0, sp, #0x240
1015439d0: 97ff7bc3    	bl	0x1015228dc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixECs29QkOtpKx6e_8mech_gpu>
1015439d4: 14000015    	b	0x101543a28 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4bcc>
1015439d8: aa0003f3    	mov	x19, x0
1015439dc: 14000013    	b	0x101543a28 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4bcc>
1015439e0: aa0003f3    	mov	x19, x0
1015439e4: 910683e0    	add	x0, sp, #0x1a0
1015439e8: 97ff7b6e    	bl	0x1015227a0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrix27OwnedSnapshotUnsignedMatrixECs29QkOtpKx6e_8mech_gpu>
1015439ec: 1400000a    	b	0x101543a14 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4bb8>
1015439f0: aa0003f3    	mov	x19, x0
1015439f4: 910903e0    	add	x0, sp, #0x240
1015439f8: 97ff78e1    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1015439fc: 14000037    	b	0x101543ad8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4c7c>
101543a00: aa0003f3    	mov	x19, x0
101543a04: 52800028    	mov	w8, #0x1                ; =1
101543a08: b90043e8    	str	w8, [sp, #0x40]
101543a0c: 14000008    	b	0x101543a2c <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4bd0>
101543a10: aa0003f3    	mov	x19, x0
101543a14: b40000b7    	cbz	x23, 0x101543a28 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4bcc>
101543a18: d37df2e1    	lsl	x1, x23, #3
101543a1c: f94023e0    	ldr	x0, [sp, #0x40]
101543a20: 52800102    	mov	w2, #0x8                ; =8
101543a24: 97ab16c6    	bl	0x10000953c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
101543a28: b90043ff    	str	wzr, [sp, #0x40]
101543a2c: 911943e0    	add	x0, sp, #0x650
101543a30: 97ff7849    	bl	0x101521b54 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs29QkOtpKx6e_8mech_gpu>
101543a34: 1400000d    	b	0x101543a68 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4c0c>
101543a38: aa0003f3    	mov	x19, x0
101543a3c: aa1b03fa    	mov	x26, x27
101543a40: 340004da    	cbz	w26, 0x101543ad8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4c7c>
101543a44: f9426be8    	ldr	x8, [sp, #0x4d0]
101543a48: b4000488    	cbz	x8, 0x101543ad8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4c7c>
101543a4c: 911343e0    	add	x0, sp, #0x4d0
101543a50: 97ff78cb    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
101543a54: 14000021    	b	0x101543ad8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4c7c>
101543a58: 9462c1ef    	bl	0x102df4214 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
101543a5c: aa0003f3    	mov	x19, x0
101543a60: 1400000c    	b	0x101543a90 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4c34>
101543a64: aa0003f3    	mov	x19, x0
101543a68: f9431be8    	ldr	x8, [sp, #0x630]
101543a6c: 92800009    	mov	x9, #-0x1               ; =-1
101543a70: f8690108    	ldaddl	x9, x8, [x8]
101543a74: f100051f    	cmp	x8, #0x1
101543a78: 54000081    	b.ne	0x101543a88 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4c2c>
101543a7c: d50339bf    	dmb	ishld
101543a80: 9118c3e0    	add	x0, sp, #0x630
101543a84: 945ebc6c    	bl	0x102cf2c34 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101543a88: b94043e8    	ldr	w8, [sp, #0x40]
101543a8c: 36000268    	tbz	w8, #0x0, 0x101543ad8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4c7c>
101543a90: 910583e0    	add	x0, sp, #0x160
101543a94: 97ff78ba    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
101543a98: 14000010    	b	0x101543ad8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4c7c>
101543a9c: aa0003f3    	mov	x19, x0
101543aa0: 910183e0    	add	x0, sp, #0x60
101543aa4: 97ff78b6    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
101543aa8: 1400000c    	b	0x101543ad8 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4c7c>
101543aac: 9462c1da    	bl	0x102df4214 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
101543ab0: 52800048    	mov	w8, #0x2                ; =2
101543ab4: f9011288    	str	x8, [x20, #0x220]
101543ab8: 9462c6d0    	bl	0x102df55f8 <dyld_stub_binder+0x102df55f8>
101543abc: 52800048    	mov	w8, #0x2                ; =2
101543ac0: f9011288    	str	x8, [x20, #0x220]
101543ac4: 9462c6cd    	bl	0x102df55f8 <dyld_stub_binder+0x102df55f8>
101543ac8: aa0003f3    	mov	x19, x0
101543acc: b944d3e8    	ldr	w8, [sp, #0x4d0]
101543ad0: 7100191f    	cmp	w8, #0x6
101543ad4: 54000061    	b.ne	0x101543ae0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4c84>
101543ad8: aa1303e0    	mov	x0, x19
101543adc: 9462c6c7    	bl	0x102df55f8 <dyld_stub_binder+0x102df55f8>
101543ae0: 911343e0    	add	x0, sp, #0x4d0
101543ae4: 97ff7ae6    	bl	0x10152267c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
101543ae8: aa1303e0    	mov	x0, x19
101543aec: 9462c6c3    	bl	0x102df55f8 <dyld_stub_binder+0x102df55f8>
