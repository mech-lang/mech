
/private/tmp/mech-action-retirement-round37-20261030/workers/after:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010152e3d0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation>:
10152e3d0: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
10152e3d4: a90167fa    	stp	x26, x25, [sp, #0x10]
10152e3d8: a9025ff8    	stp	x24, x23, [sp, #0x20]
10152e3dc: a90357f6    	stp	x22, x21, [sp, #0x30]
10152e3e0: a9044ff4    	stp	x20, x19, [sp, #0x40]
10152e3e4: a9057bfd    	stp	x29, x30, [sp, #0x50]
10152e3e8: 910143fd    	add	x29, sp, #0x50
10152e3ec: d10c03ff    	sub	sp, sp, #0x300
10152e3f0: aa0103f5    	mov	x21, x1
10152e3f4: f9424c39    	ldr	x25, [x1, #0x498]
10152e3f8: f941bf21    	ldr	x1, [x25, #0x378]
10152e3fc: eb01005f    	cmp	x2, x1
10152e400: 54003f62    	b.hs	0x10152ebec <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x81c>
10152e404: aa0003f3    	mov	x19, x0
10152e408: f941bb28    	ldr	x8, [x25, #0x370]
10152e40c: 52802e09    	mov	w9, #0x170              ; =368
10152e410: 9b09205a    	madd	x26, x2, x9, x8
10152e414: a9402349    	ldp	x9, x8, [x26]
10152e418: d2400529    	eor	x9, x9, #0x3
10152e41c: aa080128    	orr	x8, x9, x8
10152e420: b5000408    	cbnz	x8, 0x10152e4a0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0xd0>
10152e424: f940135c    	ldr	x28, [x26, #0x20]
10152e428: 92800048    	mov	x8, #-0x3               ; =-3
10152e42c: f2e0ffe8    	movk	x8, #0x7ff, lsl #48
10152e430: eb08039f    	cmp	x28, x8
10152e434: 54003b08    	b.hi	0x10152eb94 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x7c4>
10152e438: f90007e2    	str	x2, [sp, #0x8]
10152e43c: 910683f7    	add	x23, sp, #0x1a0
10152e440: f9400f54    	ldr	x20, [x26, #0x18]
10152e444: d37beb88    	lsl	x8, x28, #5
10152e448: 91010116    	add	x22, x8, #0x40
10152e44c: f9424ab8    	ldr	x24, [x21, #0x490]
10152e450: b9415b5b    	ldr	w27, [x26, #0x158]
10152e454: f9418b08    	ldr	x8, [x24, #0x310]
10152e458: b4000348    	cbz	x8, 0x10152e4c0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0xf0>
10152e45c: f9418702    	ldr	x2, [x24, #0x308]
10152e460: 910683e8    	add	x8, sp, #0x1a0
10152e464: 910c4300    	add	x0, x24, #0x310
10152e468: aa1603e1    	mov	x1, x22
10152e46c: 9437b264    	bl	0x10231adfc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>
10152e470: 394683e8    	ldrb	w8, [sp, #0x1a0]
10152e474: 7100211f    	cmp	w8, #0x8
10152e478: 54000680    	b.eq	0x10152e548 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x178>
10152e47c: a95a23ed    	ldp	x13, x8, [sp, #0x1a0]
10152e480: f940dbe9    	ldr	x9, [sp, #0x1b0]
10152e484: 92403daa    	and	x10, x13, #0xffff
10152e488: f118195f    	cmp	x10, #0x606
10152e48c: 540003c1    	b.ne	0x10152e504 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x134>
10152e490: 528000cb    	mov	w11, #0x6               ; =6
10152e494: 5280002a    	mov	w10, #0x1               ; =1
10152e498: aa1b03ec    	mov	x12, x27
10152e49c: 14000021    	b	0x10152e520 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x150>
10152e4a0: b900027f    	str	wzr, [x19]
10152e4a4: 52800188    	mov	w8, #0xc                ; =12
10152e4a8: 39002268    	strb	w8, [x19, #0x8]
10152e4ac: f000d828    	adrp	x8, 0x103035000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x4a0>
10152e4b0: 91077d08    	add	x8, x8, #0x1df
10152e4b4: 52800649    	mov	w9, #0x32               ; =50
10152e4b8: a9012668    	stp	x8, x9, [x19, #0x10]
10152e4bc: 14000190    	b	0x10152eafc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x72c>
10152e4c0: 9437b056    	bl	0x10231a618 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope>
10152e4c4: 360000c0    	tbz	w0, #0x0, 0x10152e4dc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x10c>
10152e4c8: d2800008    	mov	x8, #0x0                ; =0
10152e4cc: 5280000c    	mov	w12, #0x0               ; =0
10152e4d0: 5280002a    	mov	w10, #0x1               ; =1
10152e4d4: 528000eb    	mov	w11, #0x7               ; =7
10152e4d8: 14000012    	b	0x10152e520 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x150>
10152e4dc: f9418308    	ldr	x8, [x24, #0x300]
10152e4e0: f9418709    	ldr	x9, [x24, #0x308]
10152e4e4: ab160108    	adds	x8, x8, x22
10152e4e8: 540036e2    	b.hs	0x10152ebc4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x7f4>
10152e4ec: eb09011f    	cmp	x8, x9
10152e4f0: 540002a9    	b.ls	0x10152e544 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x174>
10152e4f4: 5280002a    	mov	w10, #0x1               ; =1
10152e4f8: 528000cb    	mov	w11, #0x6               ; =6
10152e4fc: aa1b03ec    	mov	x12, x27
10152e500: 14000008    	b	0x10152e520 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x150>
10152e504: d360fd2c    	lsr	x12, x9, #32
10152e508: 3cc182e0    	ldur	q0, [x23, #0x18]
10152e50c: 3d8007e0    	str	q0, [sp, #0x10]
10152e510: 528000eb    	mov	w11, #0x7               ; =7
10152e514: aa0903ea    	mov	x10, x9
10152e518: aa0803e9    	mov	x9, x8
10152e51c: aa0d03e8    	mov	x8, x13
10152e520: b900027f    	str	wzr, [x19]
10152e524: 3900226b    	strb	w11, [x19, #0x8]
10152e528: a9012668    	stp	x8, x9, [x19, #0x10]
10152e52c: 2904326a    	stp	w10, w12, [x19, #0x20]
10152e530: 3dc007e0    	ldr	q0, [sp, #0x10]
10152e534: 3c828260    	stur	q0, [x19, #0x28]
10152e538: 52800028    	mov	w8, #0x1                ; =1
10152e53c: 29076e68    	stp	w8, w27, [x19, #0x38]
10152e540: 1400016f    	b	0x10152eafc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x72c>
10152e544: f9018308    	str	x8, [x24, #0x300]
10152e548: b9402b41    	ldr	w1, [x26, #0x28]
10152e54c: 910683e8    	add	x8, sp, #0x1a0
10152e550: 9103c300    	add	x0, x24, #0xf0
10152e554: 910be302    	add	x2, x24, #0x2f8
10152e558: 94005d35    	bl	0x101545a2c <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
10152e55c: 3cc082e0    	ldur	q0, [x23, #0x8]
10152e560: 3cc182e1    	ldur	q1, [x23, #0x18]
10152e564: ad0307e0    	stp	q0, q1, [sp, #0x60]
10152e568: 3cc282e0    	ldur	q0, [x23, #0x28]
10152e56c: 3d8023e0    	str	q0, [sp, #0x80]
10152e570: f940d3e8    	ldr	x8, [sp, #0x1a0]
10152e574: f940efe9    	ldr	x9, [sp, #0x1d8]
10152e578: f9004be9    	str	x9, [sp, #0x90]
10152e57c: b4000668    	cbz	x8, 0x10152e648 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x278>
10152e580: ad4307e0    	ldp	q0, q1, [sp, #0x60]
10152e584: 3c8283e0    	stur	q0, [sp, #0x28]
10152e588: 3c8383e1    	stur	q1, [sp, #0x38]
10152e58c: 3dc023e0    	ldr	q0, [sp, #0x80]
10152e590: 3c8483e0    	stur	q0, [sp, #0x48]
10152e594: f9404be9    	ldr	x9, [sp, #0x90]
10152e598: f9002fe9    	str	x9, [sp, #0x58]
10152e59c: f90013e8    	str	x8, [sp, #0x20]
10152e5a0: b9401348    	ldr	w8, [x26, #0x10]
10152e5a4: 7100091f    	cmp	w8, #0x2
10152e5a8: 54000721    	b.ne	0x10152e68c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x2bc>
10152e5ac: a9402349    	ldp	x9, x8, [x26]
10152e5b0: d2400529    	eor	x9, x9, #0x3
10152e5b4: aa080128    	orr	x8, x9, x8
10152e5b8: b50030c8    	cbnz	x8, 0x10152ebd0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x800>
10152e5bc: b9402f56    	ldr	w22, [x26, #0x2c]
10152e5c0: 910683e8    	add	x8, sp, #0x1a0
10152e5c4: 9103c300    	add	x0, x24, #0xf0
10152e5c8: 910be302    	add	x2, x24, #0x2f8
10152e5cc: aa1603e1    	mov	x1, x22
10152e5d0: 94006143    	bl	0x101546adc <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena22current_retained_bytes>
10152e5d4: 394683e8    	ldrb	w8, [sp, #0x1a0]
10152e5d8: 7100511f    	cmp	w8, #0x14
10152e5dc: 54000ba1    	b.ne	0x10152e750 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x380>
10152e5e0: f940d7e8    	ldr	x8, [sp, #0x1a8]
10152e5e4: b4001488    	cbz	x8, 0x10152e874 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x4a4>
10152e5e8: 910683e8    	add	x8, sp, #0x1a0
10152e5ec: 9103c300    	add	x0, x24, #0xf0
10152e5f0: 910be302    	add	x2, x24, #0x2f8
10152e5f4: aa1603e1    	mov	x1, x22
10152e5f8: 94005d0d    	bl	0x101545a2c <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
10152e5fc: 3cc082e0    	ldur	q0, [x23, #0x8]
10152e600: 3cc182e1    	ldur	q1, [x23, #0x18]
10152e604: ad0707e0    	stp	q0, q1, [sp, #0xe0]
10152e608: 3cc282e0    	ldur	q0, [x23, #0x28]
10152e60c: 3d8043e0    	str	q0, [sp, #0x100]
10152e610: f940d3e8    	ldr	x8, [sp, #0x1a0]
10152e614: f940efe9    	ldr	x9, [sp, #0x1d8]
10152e618: f9008be9    	str	x9, [sp, #0x110]
10152e61c: b4002008    	cbz	x8, 0x10152ea1c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x64c>
10152e620: 910283e9    	add	x9, sp, #0xa0
10152e624: ad4707e0    	ldp	q0, q1, [sp, #0xe0]
10152e628: 3c808120    	stur	q0, [x9, #0x8]
10152e62c: 3c818121    	stur	q1, [x9, #0x18]
10152e630: 3dc043e0    	ldr	q0, [sp, #0x100]
10152e634: 3c828120    	stur	q0, [x9, #0x28]
10152e638: f9408be9    	ldr	x9, [sp, #0x110]
10152e63c: f9006fe9    	str	x9, [sp, #0xd8]
10152e640: 910283e4    	add	x4, sp, #0xa0
10152e644: 1400008d    	b	0x10152e878 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x4a8>
10152e648: ad4307e0    	ldp	q0, q1, [sp, #0x60]
10152e64c: 3c8042e0    	stur	q0, [x23, #0x4]
10152e650: 3c8142e1    	stur	q1, [x23, #0x14]
10152e654: 3dc023e0    	ldr	q0, [sp, #0x80]
10152e658: 3c8242e0    	stur	q0, [x23, #0x24]
10152e65c: f9404be8    	ldr	x8, [sp, #0x90]
10152e660: f80342e8    	stur	x8, [x23, #0x34]
10152e664: ad4d07e0    	ldp	q0, q1, [sp, #0x1a0]
10152e668: 3c804260    	stur	q0, [x19, #0x4]
10152e66c: 52800048    	mov	w8, #0x2                ; =2
10152e670: b9000268    	str	w8, [x19]
10152e674: 3c814261    	stur	q1, [x19, #0x14]
10152e678: 3dc073e0    	ldr	q0, [sp, #0x1c0]
10152e67c: 3c824260    	stur	q0, [x19, #0x24]
10152e680: 3cc2c2e0    	ldur	q0, [x23, #0x2c]
10152e684: 3d800e60    	str	q0, [x19, #0x30]
10152e688: 1400011d    	b	0x10152eafc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x72c>
10152e68c: f94017e9    	ldr	x9, [sp, #0x28]
10152e690: f9400929    	ldr	x9, [x9, #0x10]
10152e694: 91004135    	add	x21, x9, #0x10
10152e698: b400047c    	cbz	x28, 0x10152e724 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x354>
10152e69c: d37df389    	lsl	x9, x28, #3
10152e6a0: 9100128a    	add	x10, x20, #0x4
10152e6a4: 5280060b    	mov	w11, #0x30              ; =48
10152e6a8: 14000006    	b	0x10152e6c0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x2f0>
10152e6ac: f94006ad    	ldr	x13, [x21, #0x8]
10152e6b0: 9bab3595    	umaddl	x21, w12, w11, x13
10152e6b4: 9100214a    	add	x10, x10, #0x8
10152e6b8: f1002129    	subs	x9, x9, #0x8
10152e6bc: 54000340    	b.eq	0x10152e724 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x354>
10152e6c0: b85fc14d    	ldur	w13, [x10, #-0x4]
10152e6c4: 394002ac    	ldrb	w12, [x21]
10152e6c8: 3600010d    	tbz	w13, #0x0, 0x10152e6e8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x318>
10152e6cc: 71005d9f    	cmp	w12, #0x17
10152e6d0: 540005a1    	b.ne	0x10152e784 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x3b4>
10152e6d4: f9400aad    	ldr	x13, [x21, #0x10]
10152e6d8: b940014c    	ldr	w12, [x10]
10152e6dc: eb0c01bf    	cmp	x13, x12
10152e6e0: 54fffe68    	b.hi	0x10152e6ac <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x2dc>
10152e6e4: 140000df    	b	0x10152ea60 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x690>
10152e6e8: 7100559f    	cmp	w12, #0x15
10152e6ec: 540004c1    	b.ne	0x10152e784 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x3b4>
10152e6f0: b94012ac    	ldr	w12, [x21, #0x10]
10152e6f4: b940014d    	ldr	w13, [x10]
10152e6f8: 6b0d019f    	cmp	w12, w13
10152e6fc: 54000441    	b.ne	0x10152e784 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x3b4>
10152e700: f94006b5    	ldr	x21, [x21, #0x8]
10152e704: b5fffd95    	cbnz	x21, 0x10152e6b4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x2e4>
10152e708: b900027f    	str	wzr, [x19]
10152e70c: 52800188    	mov	w8, #0xc                ; =12
10152e710: f000d829    	adrp	x9, 0x103035000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x4a0>
10152e714: 9103c129    	add	x9, x9, #0xf0
10152e718: a900a668    	stp	x8, x9, [x19, #0x8]
10152e71c: 528003c8    	mov	w8, #0x1e               ; =30
10152e720: 140000d6    	b	0x10152ea78 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x6a8>
10152e724: 7100051f    	cmp	w8, #0x1
10152e728: 540003cc    	b.gt	0x10152e7a0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x3d0>
10152e72c: 35001348    	cbnz	w8, 0x10152e994 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x5c4>
10152e730: 394002a8    	ldrb	w8, [x21]
10152e734: 7100551f    	cmp	w8, #0x15
10152e738: 54001421    	b.ne	0x10152e9bc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x5ec>
10152e73c: b94012a8    	ldr	w8, [x21, #0x10]
10152e740: b9401749    	ldr	w9, [x26, #0x14]
10152e744: 6b09011f    	cmp	w8, w9
10152e748: 1a9f17f4    	cset	w20, eq
10152e74c: 14000096    	b	0x10152e9a4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x5d4>
10152e750: b84012e9    	ldur	w9, [x23, #0x1]
10152e754: b8009269    	stur	w9, [x19, #0x9]
10152e758: b941a7e9    	ldr	w9, [sp, #0x1a4]
10152e75c: b9000e69    	str	w9, [x19, #0xc]
10152e760: 3cc182e0    	ldur	q0, [x23, #0x18]
10152e764: 3cc282e1    	ldur	q1, [x23, #0x28]
10152e768: ad010660    	stp	q0, q1, [x19, #0x20]
10152e76c: 3cc082e1    	ldur	q1, [x23, #0x8]
10152e770: 52800049    	mov	w9, #0x2                ; =2
10152e774: b9000269    	str	w9, [x19]
10152e778: 39002268    	strb	w8, [x19, #0x8]
10152e77c: 3d800661    	str	q1, [x19, #0x10]
10152e780: 140000dd    	b	0x10152eaf4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x724>
10152e784: b900027f    	str	wzr, [x19]
10152e788: 52800188    	mov	w8, #0xc                ; =12
10152e78c: 39002268    	strb	w8, [x19, #0x8]
10152e790: f000d828    	adrp	x8, 0x103035000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x4a0>
10152e794: 91049108    	add	x8, x8, #0x124
10152e798: 52800789    	mov	w9, #0x3c               ; =60
10152e79c: 1400008e    	b	0x10152e9d4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x604>
10152e7a0: 7100091f    	cmp	w8, #0x2
10152e7a4: 540010c0    	b.eq	0x10152e9bc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x5ec>
10152e7a8: 394002a8    	ldrb	w8, [x21]
10152e7ac: 7100451f    	cmp	w8, #0x11
10152e7b0: 54001061    	b.ne	0x10152e9bc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x5ec>
10152e7b4: b9401741    	ldr	w1, [x26, #0x14]
10152e7b8: 910683e8    	add	x8, sp, #0x1a0
10152e7bc: 9103c300    	add	x0, x24, #0xf0
10152e7c0: 910be302    	add	x2, x24, #0x2f8
10152e7c4: 94005c9a    	bl	0x101545a2c <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
10152e7c8: 3cc082e0    	ldur	q0, [x23, #0x8]
10152e7cc: 3cc182e1    	ldur	q1, [x23, #0x18]
10152e7d0: ad3a07a0    	stp	q0, q1, [x29, #-0xc0]
10152e7d4: 3cc282e0    	ldur	q0, [x23, #0x28]
10152e7d8: 3c9603a0    	stur	q0, [x29, #-0xa0]
10152e7dc: f940d3e8    	ldr	x8, [sp, #0x1a0]
10152e7e0: f940efe9    	ldr	x9, [sp, #0x1d8]
10152e7e4: f81703a9    	stur	x9, [x29, #-0x90]
10152e7e8: b40019a8    	cbz	x8, 0x10152eb1c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x74c>
10152e7ec: ad7a07a0    	ldp	q0, q1, [x29, #-0xc0]
10152e7f0: 3c8b82e0    	stur	q0, [x23, #0xb8]
10152e7f4: f85703a9    	ldur	x9, [x29, #-0x90]
10152e7f8: 3cd603a0    	ldur	q0, [x29, #-0xa0]
10152e7fc: 3c8d82e0    	stur	q0, [x23, #0xd8]
10152e800: 3c8c82e1    	stur	q1, [x23, #0xc8]
10152e804: f81383a9    	stur	x9, [x29, #-0xc8]
10152e808: f81003a8    	stur	x8, [x29, #-0x100]
10152e80c: f85083a8    	ldur	x8, [x29, #-0xf8]
10152e810: f9400914    	ldr	x20, [x8, #0x10]
10152e814: 39404288    	ldrb	w8, [x20, #0x10]
10152e818: 7100451f    	cmp	w8, #0x11
10152e81c: 540018e1    	b.ne	0x10152eb38 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x768>
10152e820: a940d6b6    	ldp	x22, x21, [x21, #0x8]
10152e824: f9401288    	ldr	x8, [x20, #0x20]
10152e828: eb15011f    	cmp	x8, x21
10152e82c: 9a958101    	csel	x1, x8, x21, hi
10152e830: d10223a8    	sub	x8, x29, #0x88
10152e834: 910ee300    	add	x0, x24, #0x3b8
10152e838: aa0103e2    	mov	x2, x1
10152e83c: 9437b28e    	bl	0x10231b274 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge>
10152e840: 385783a8    	ldurb	w8, [x29, #-0x88]
10152e844: 7100211f    	cmp	w8, #0x8
10152e848: 54001881    	b.ne	0x10152eb58 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x788>
10152e84c: f9401288    	ldr	x8, [x20, #0x20]
10152e850: eb0802bf    	cmp	x21, x8
10152e854: 54001b01    	b.ne	0x10152ebb4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x7e4>
10152e858: f9400e81    	ldr	x1, [x20, #0x18]
10152e85c: aa1603e0    	mov	x0, x22
10152e860: aa1503e2    	mov	x2, x21
10152e864: 94631bdd    	bl	0x102df57d8 <dyld_stub_binder+0x102df57d8>
10152e868: 7100001f    	cmp	w0, #0x0
10152e86c: 1a9f17f4    	cset	w20, eq
10152e870: 140000d2    	b	0x10152ebb8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x7e8>
10152e874: d2800004    	mov	x4, #0x0                ; =0
10152e878: f90053e8    	str	x8, [sp, #0xa0]
10152e87c: ad4406a0    	ldp	q0, q1, [x21, #0x80]
10152e880: ad1107e0    	stp	q0, q1, [sp, #0x220]
10152e884: f94052a8    	ldr	x8, [x21, #0xa0]
10152e888: f90123e8    	str	x8, [sp, #0x240]
10152e88c: ad4206a0    	ldp	q0, q1, [x21, #0x40]
10152e890: ad0f07e0    	stp	q0, q1, [sp, #0x1e0]
10152e894: ad4302a1    	ldp	q1, q0, [x21, #0x60]
10152e898: ad1003e1    	stp	q1, q0, [sp, #0x200]
10152e89c: ad4006a0    	ldp	q0, q1, [x21]
10152e8a0: ad0d07e0    	stp	q0, q1, [sp, #0x1a0]
10152e8a4: ad4102a1    	ldp	q1, q0, [x21, #0x20]
10152e8a8: ad0e03e1    	stp	q1, q0, [sp, #0x1c0]
10152e8ac: 910583e8    	add	x8, sp, #0x160
10152e8b0: 910be320    	add	x0, x25, #0x2f8
10152e8b4: 910fc322    	add	x2, x25, #0x3f0
10152e8b8: 910083e3    	add	x3, sp, #0x20
10152e8bc: 910683e5    	add	x5, sp, #0x1a0
10152e8c0: 910ee306    	add	x6, x24, #0x3b8
10152e8c4: f94007e1    	ldr	x1, [sp, #0x8]
10152e8c8: 9451bcf9    	bl	0x10299dcac <__RNvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general28native_structural_projection31native_project_structural_value>
10152e8cc: f940b3e8    	ldr	x8, [sp, #0x160]
10152e8d0: b4000368    	cbz	x8, 0x10152e93c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x56c>
10152e8d4: ad4b07e0    	ldp	q0, q1, [sp, #0x160]
10152e8d8: ad0907e0    	stp	q0, q1, [sp, #0x120]
10152e8dc: ad4c07e0    	ldp	q0, q1, [sp, #0x180]
10152e8e0: ad0a07e0    	stp	q0, q1, [sp, #0x140]
10152e8e4: 910683e8    	add	x8, sp, #0x1a0
10152e8e8: 9103c300    	add	x0, x24, #0xf0
10152e8ec: 910483e2    	add	x2, sp, #0x120
10152e8f0: 910be303    	add	x3, x24, #0x2f8
10152e8f4: aa1603e1    	mov	x1, x22
10152e8f8: 9400630f    	bl	0x101547534 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena3put>
10152e8fc: 394683e8    	ldrb	w8, [sp, #0x1a0]
10152e900: 7100511f    	cmp	w8, #0x14
10152e904: 540006c1    	b.ne	0x10152e9dc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x60c>
10152e908: 52800028    	mov	w8, #0x1                ; =1
10152e90c: 39118308    	strb	w8, [x24, #0x460]
10152e910: f941af21    	ldr	x1, [x25, #0x358]
10152e914: eb16003f    	cmp	x1, x22
10152e918: 54001749    	b.ls	0x10152ec00 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x830>
10152e91c: f941ab28    	ldr	x8, [x25, #0x350]
10152e920: 52802809    	mov	w9, #0x140              ; =320
10152e924: 9ba922c8    	umaddl	x8, w22, w9, x8
10152e928: 39449102    	ldrb	w2, [x8, #0x124]
10152e92c: 71001c5f    	cmp	w2, #0x7
10152e930: 54000a81    	b.ne	0x10152ea80 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x6b0>
10152e934: f900067f    	str	xzr, [x19, #0x8]
10152e938: 14000060    	b	0x10152eab8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x6e8>
10152e93c: 910583e8    	add	x8, sp, #0x160
10152e940: f941bb21    	ldr	x1, [x25, #0x370]
10152e944: f941bf22    	ldr	x2, [x25, #0x378]
10152e948: 910683e0    	add	x0, sp, #0x1a0
10152e94c: 91002104    	add	x4, x8, #0x8
10152e950: f94007e3    	ldr	x3, [sp, #0x8]
10152e954: 97ffdba5    	bl	0x1015257e8 <__RNCNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB6_10Invocation32canonical_structural_observations0_0Be_>
10152e958: 3cc142e0    	ldur	q0, [x23, #0x14]
10152e95c: 3c814260    	stur	q0, [x19, #0x14]
10152e960: 3cc242e0    	ldur	q0, [x23, #0x24]
10152e964: 3c824260    	stur	q0, [x19, #0x24]
10152e968: 3cc342e0    	ldur	q0, [x23, #0x34]
10152e96c: 3c834260    	stur	q0, [x19, #0x34]
10152e970: b941a3e8    	ldr	w8, [sp, #0x1a0]
10152e974: b941e7e9    	ldr	w9, [sp, #0x1e4]
10152e978: b9004669    	str	w9, [x19, #0x44]
10152e97c: 3cc042e0    	ldur	q0, [x23, #0x4]
10152e980: 3c804260    	stur	q0, [x19, #0x4]
10152e984: f940f7e9    	ldr	x9, [sp, #0x1e8]
10152e988: b9000268    	str	w8, [x19]
10152e98c: f9002669    	str	x9, [x19, #0x48]
10152e990: 14000055    	b	0x10152eae4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x714>
10152e994: 394002a8    	ldrb	w8, [x21]
10152e998: 7100111f    	cmp	w8, #0x4
10152e99c: 54000101    	b.ne	0x10152e9bc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x5ec>
10152e9a0: f94006b4    	ldr	x20, [x21, #0x8]
10152e9a4: 52800028    	mov	w8, #0x1                ; =1
10152e9a8: 39118308    	strb	w8, [x24, #0x460]
10152e9ac: a900d268    	stp	x8, x20, [x19, #0x8]
10152e9b0: 528000c8    	mov	w8, #0x6                ; =6
10152e9b4: b9000268    	str	w8, [x19]
10152e9b8: 1400004f    	b	0x10152eaf4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x724>
10152e9bc: b900027f    	str	wzr, [x19]
10152e9c0: 52800188    	mov	w8, #0xc                ; =12
10152e9c4: 39002268    	strb	w8, [x19, #0x8]
10152e9c8: f000d828    	adrp	x8, 0x103035000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x4a0>
10152e9cc: 91061d08    	add	x8, x8, #0x187
10152e9d0: 52800689    	mov	w9, #0x34               ; =52
10152e9d4: a9012668    	stp	x8, x9, [x19, #0x10]
10152e9d8: 14000047    	b	0x10152eaf4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x724>
10152e9dc: b84012e9    	ldur	w9, [x23, #0x1]
10152e9e0: b8009269    	stur	w9, [x19, #0x9]
10152e9e4: b941a7e9    	ldr	w9, [sp, #0x1a4]
10152e9e8: b9000e69    	str	w9, [x19, #0xc]
10152e9ec: 3dc073e0    	ldr	q0, [sp, #0x1c0]
10152e9f0: 3c828260    	stur	q0, [x19, #0x28]
10152e9f4: f940ebe9    	ldr	x9, [sp, #0x1d0]
10152e9f8: f9001e69    	str	x9, [x19, #0x38]
10152e9fc: fd40dfe0    	ldr	d0, [sp, #0x1b8]
10152ea00: 3cc082e1    	ldur	q1, [x23, #0x8]
10152ea04: 52800049    	mov	w9, #0x2                ; =2
10152ea08: b9000269    	str	w9, [x19]
10152ea0c: 39002268    	strb	w8, [x19, #0x8]
10152ea10: 3d800661    	str	q1, [x19, #0x10]
10152ea14: fd001260    	str	d0, [x19, #0x20]
10152ea18: 14000031    	b	0x10152eadc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x70c>
10152ea1c: ad4707e0    	ldp	q0, q1, [sp, #0xe0]
10152ea20: 3c8042e0    	stur	q0, [x23, #0x4]
10152ea24: 3c8142e1    	stur	q1, [x23, #0x14]
10152ea28: 3dc043e0    	ldr	q0, [sp, #0x100]
10152ea2c: 3c8242e0    	stur	q0, [x23, #0x24]
10152ea30: f9408be8    	ldr	x8, [sp, #0x110]
10152ea34: f80342e8    	stur	x8, [x23, #0x34]
10152ea38: ad4d07e0    	ldp	q0, q1, [sp, #0x1a0]
10152ea3c: 3c804260    	stur	q0, [x19, #0x4]
10152ea40: 52800048    	mov	w8, #0x2                ; =2
10152ea44: b9000268    	str	w8, [x19]
10152ea48: 3c814261    	stur	q1, [x19, #0x14]
10152ea4c: 3dc073e0    	ldr	q0, [sp, #0x1c0]
10152ea50: 3c824260    	stur	q0, [x19, #0x24]
10152ea54: 3cc2c2e0    	ldur	q0, [x23, #0x2c]
10152ea58: 3d800e60    	str	q0, [x19, #0x30]
10152ea5c: 14000026    	b	0x10152eaf4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x724>
10152ea60: b900027f    	str	wzr, [x19]
10152ea64: 52800188    	mov	w8, #0xc                ; =12
10152ea68: f000d829    	adrp	x9, 0x103035000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x4a0>
10152ea6c: 91043929    	add	x9, x9, #0x10e
10152ea70: a900a668    	stp	x8, x9, [x19, #0x8]
10152ea74: 528002c8    	mov	w8, #0x16               ; =22
10152ea78: f9000e68    	str	x8, [x19, #0x18]
10152ea7c: 1400001e    	b	0x10152eaf4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x724>
10152ea80: f94097e1    	ldr	x1, [sp, #0x128]
10152ea84: 910683e0    	add	x0, sp, #0x1a0
10152ea88: 94008873    	bl	0x101550c54 <__RNvNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime4bits>
10152ea8c: fd40d3e0    	ldr	d0, [sp, #0x1a0]
10152ea90: b941a3e9    	ldr	w9, [sp, #0x1a0]
10152ea94: f940d7e8    	ldr	x8, [sp, #0x1a8]
10152ea98: ad4d8be1    	ldp	q1, q2, [sp, #0x1b0]
10152ea9c: ad380ba1    	stp	q1, q2, [x29, #-0x100]
10152eaa0: ad4e8be1    	ldp	q1, q2, [sp, #0x1d0]
10152eaa4: ad390ba1    	stp	q1, q2, [x29, #-0xe0]
10152eaa8: 7100193f    	cmp	w9, #0x6
10152eaac: 540000c1    	b.ne	0x10152eac4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x6f4>
10152eab0: 52800029    	mov	w9, #0x1                ; =1
10152eab4: a900a269    	stp	x9, x8, [x19, #0x8]
10152eab8: 528000c8    	mov	w8, #0x6                ; =6
10152eabc: b9000268    	str	w8, [x19]
10152eac0: 14000007    	b	0x10152eadc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x70c>
10152eac4: ad780ba1    	ldp	q1, q2, [x29, #-0x100]
10152eac8: ad008a61    	stp	q1, q2, [x19, #0x10]
10152eacc: ad790ba1    	ldp	q1, q2, [x29, #-0xe0]
10152ead0: ad018a61    	stp	q1, q2, [x19, #0x30]
10152ead4: fd000260    	str	d0, [x19]
10152ead8: f9000668    	str	x8, [x19, #0x8]
10152eadc: 910483e0    	add	x0, sp, #0x120
10152eae0: 97ffcca7    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
10152eae4: f94053e8    	ldr	x8, [sp, #0xa0]
10152eae8: b4000068    	cbz	x8, 0x10152eaf4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x724>
10152eaec: 910283e0    	add	x0, sp, #0xa0
10152eaf0: 97ffcca3    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
10152eaf4: 910083e0    	add	x0, sp, #0x20
10152eaf8: 97ffcca1    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
10152eafc: 910c03ff    	add	sp, sp, #0x300
10152eb00: a9457bfd    	ldp	x29, x30, [sp, #0x50]
10152eb04: a9444ff4    	ldp	x20, x19, [sp, #0x40]
10152eb08: a94357f6    	ldp	x22, x21, [sp, #0x30]
10152eb0c: a9425ff8    	ldp	x24, x23, [sp, #0x20]
10152eb10: a94167fa    	ldp	x26, x25, [sp, #0x10]
10152eb14: a8c66ffc    	ldp	x28, x27, [sp], #0x60
10152eb18: d65f03c0    	ret
10152eb1c: ad7a07a0    	ldp	q0, q1, [x29, #-0xc0]
10152eb20: 3c8042e0    	stur	q0, [x23, #0x4]
10152eb24: 3c8142e1    	stur	q1, [x23, #0x14]
10152eb28: 3cd603a0    	ldur	q0, [x29, #-0xa0]
10152eb2c: 3c8242e0    	stur	q0, [x23, #0x24]
10152eb30: f85703a8    	ldur	x8, [x29, #-0x90]
10152eb34: 17ffffc0    	b	0x10152ea34 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x664>
10152eb38: b900027f    	str	wzr, [x19]
10152eb3c: 52800188    	mov	w8, #0xc                ; =12
10152eb40: 39002268    	strb	w8, [x19, #0x8]
10152eb44: f000d828    	adrp	x8, 0x103035000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x4a0>
10152eb48: 91058108    	add	x8, x8, #0x160
10152eb4c: 528004e9    	mov	w9, #0x27               ; =39
10152eb50: a9012668    	stp	x8, x9, [x19, #0x10]
10152eb54: 1400000d    	b	0x10152eb88 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x7b8>
10152eb58: f941bb21    	ldr	x1, [x25, #0x370]
10152eb5c: f941bf22    	ldr	x2, [x25, #0x378]
10152eb60: 910683e0    	add	x0, sp, #0x1a0
10152eb64: d10223a4    	sub	x4, x29, #0x88
10152eb68: f94007e3    	ldr	x3, [sp, #0x8]
10152eb6c: 97ffdb44    	bl	0x10152587c <__RNCNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB6_10Invocation32canonical_structural_observations5_0Be_>
10152eb70: ad4e07e0    	ldp	q0, q1, [sp, #0x1c0]
10152eb74: ad010660    	stp	q0, q1, [x19, #0x20]
10152eb78: 3dc07be0    	ldr	q0, [sp, #0x1e0]
10152eb7c: 3d801260    	str	q0, [x19, #0x40]
10152eb80: ad4d03e1    	ldp	q1, q0, [sp, #0x1a0]
10152eb84: ad000261    	stp	q1, q0, [x19]
10152eb88: d10403a0    	sub	x0, x29, #0x100
10152eb8c: 97ffcc7c    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
10152eb90: 17ffffd9    	b	0x10152eaf4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x724>
10152eb94: b900027f    	str	wzr, [x19]
10152eb98: 52800188    	mov	w8, #0xc                ; =12
10152eb9c: f000d829    	adrp	x9, 0x103035000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x4a0>
10152eba0: 9106ed29    	add	x9, x9, #0x1bb
10152eba4: a900a668    	stp	x8, x9, [x19, #0x8]
10152eba8: 52800488    	mov	w8, #0x24               ; =36
10152ebac: f9000e68    	str	x8, [x19, #0x18]
10152ebb0: 17ffffd3    	b	0x10152eafc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x72c>
10152ebb4: d2800014    	mov	x20, #0x0               ; =0
10152ebb8: d10403a0    	sub	x0, x29, #0x100
10152ebbc: 97ffcc70    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
10152ebc0: 17ffff79    	b	0x10152e9a4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x5d4>
10152ebc4: 5280002a    	mov	w10, #0x1               ; =1
10152ebc8: 92800008    	mov	x8, #-0x1               ; =-1
10152ebcc: 17fffe4b    	b	0x10152e4f8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x128>
10152ebd0: 9000d820    	adrp	x0, 0x103032000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.241+0x21>
10152ebd4: 91328000    	add	x0, x0, #0xca0
10152ebd8: f00124e2    	adrp	x2, 0x1039cd000 <_anon.369b439a638cb010e9292f03e79ebf78.285+0x710>
10152ebdc: 91018042    	add	x2, x2, #0x60
10152ebe0: 52800501    	mov	w1, #0x28               ; =40
10152ebe4: 946315e9    	bl	0x102df4388 <__RNvNtCsgDHHaSskbIF_4core9panicking5panic>
10152ebe8: 1400000a    	b	0x10152ec10 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x840>
10152ebec: f00124e8    	adrp	x8, 0x1039cd000 <_anon.369b439a638cb010e9292f03e79ebf78.285+0x710>
10152ebf0: 9100c108    	add	x8, x8, #0x30
10152ebf4: aa0203e0    	mov	x0, x2
10152ebf8: aa0803e2    	mov	x2, x8
10152ebfc: 9463158c    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152ec00: f00124e2    	adrp	x2, 0x1039cd000 <_anon.369b439a638cb010e9292f03e79ebf78.285+0x710>
10152ec04: 91012042    	add	x2, x2, #0x48
10152ec08: aa1603e0    	mov	x0, x22
10152ec0c: 94631588    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152ec10: d4200020    	brk	#0x1
10152ec14: aa0003f3    	mov	x19, x0
10152ec18: d10403a0    	sub	x0, x29, #0x100
10152ec1c: 97ffcc58    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
10152ec20: 1400000c    	b	0x10152ec50 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x880>
10152ec24: aa0003f3    	mov	x19, x0
10152ec28: 910483e0    	add	x0, sp, #0x120
10152ec2c: 97ffcc54    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
10152ec30: 14000002    	b	0x10152ec38 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x868>
10152ec34: aa0003f3    	mov	x19, x0
10152ec38: f94053e8    	ldr	x8, [sp, #0xa0]
10152ec3c: b40000a8    	cbz	x8, 0x10152ec50 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x880>
10152ec40: 910283e0    	add	x0, sp, #0xa0
10152ec44: 97ffcc4e    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
10152ec48: 14000002    	b	0x10152ec50 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation+0x880>
10152ec4c: aa0003f3    	mov	x19, x0
10152ec50: 910083e0    	add	x0, sp, #0x20
10152ec54: 97ffcc4a    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
10152ec58: aa1303e0    	mov	x0, x19
10152ec5c: 94631a67    	bl	0x102df55f8 <dyld_stub_binder+0x102df55f8>
10152ec60: 9463156d    	bl	0x102df4214 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
