
/private/tmp/mech-action-retirement-round37-20261030/workers/after:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010152d92c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper>:
10152d92c: d105c3ff    	sub	sp, sp, #0x170
10152d930: a9126ffc    	stp	x28, x27, [sp, #0x120]
10152d934: a9135ff8    	stp	x24, x23, [sp, #0x130]
10152d938: a91457f6    	stp	x22, x21, [sp, #0x140]
10152d93c: a9154ff4    	stp	x20, x19, [sp, #0x150]
10152d940: a9167bfd    	stp	x29, x30, [sp, #0x160]
10152d944: 910583fd    	add	x29, sp, #0x160
10152d948: aa0203f4    	mov	x20, x2
10152d94c: aa0003f3    	mov	x19, x0
10152d950: f9424835    	ldr	x21, [x1, #0x490]
10152d954: f9422ea8    	ldr	x8, [x21, #0x458]
10152d958: b100811f    	cmn	x8, #0x20
10152d95c: 54000103    	b.lo	0x10152d97c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x50>
10152d960: d000d849    	adrp	x9, 0x103037000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x24a0>
10152d964: 913b4129    	add	x9, x9, #0xed0
10152d968: 8b080d29    	add	x9, x9, x8, lsl #3
10152d96c: f9408129    	ldr	x9, [x9, #0x100]
10152d970: eb09007f    	cmp	x3, x9
10152d974: 540000a0    	b.eq	0x10152d988 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x5c>
10152d978: 14000044    	b	0x10152da88 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x15c>
10152d97c: 52800069    	mov	w9, #0x3                ; =3
10152d980: eb09007f    	cmp	x3, x9
10152d984: 54000821    	b.ne	0x10152da88 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x15c>
10152d988: f9424c36    	ldr	x22, [x1, #0x498]
10152d98c: f1000c7f    	cmp	x3, #0x3
10152d990: 54000061    	b.ne	0x10152d99c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x70>
10152d994: eb08009f    	cmp	x4, x8
10152d998: 54000781    	b.ne	0x10152da88 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x15c>
10152d99c: aa0103e0    	mov	x0, x1
10152d9a0: aa0103f7    	mov	x23, x1
10152d9a4: aa1403e1    	mov	x1, x20
10152d9a8: aa0503f8    	mov	x24, x5
10152d9ac: 94003eb9    	bl	0x10153d490 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation15action_required>
10152d9b0: aa1703e9    	mov	x9, x23
10152d9b4: aa1803e2    	mov	x2, x24
10152d9b8: 36000080    	tbz	w0, #0x0, 0x10152d9c8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x9c>
10152d9bc: 395182a8    	ldrb	w8, [x21, #0x460]
10152d9c0: 7100051f    	cmp	w8, #0x1
10152d9c4: 54000621    	b.ne	0x10152da88 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x15c>
10152d9c8: f941bec1    	ldr	x1, [x22, #0x378]
10152d9cc: eb01029f    	cmp	x20, x1
10152d9d0: 54001582    	b.hs	0x10152dc80 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x354>
10152d9d4: f941bac8    	ldr	x8, [x22, #0x370]
10152d9d8: 52802e0a    	mov	w10, #0x170             ; =368
10152d9dc: 9b0a2288    	madd	x8, x20, x10, x8
10152d9e0: b9415d08    	ldr	w8, [x8, #0x15c]
10152d9e4: 71000d1f    	cmp	w8, #0x3
10152d9e8: 54000501    	b.ne	0x10152da88 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x15c>
10152d9ec: f9422ea8    	ldr	x8, [x21, #0x458]
10152d9f0: f941d6ca    	ldr	x10, [x22, #0x3a8]
10152d9f4: f94196c1    	ldr	x1, [x22, #0x328]
10152d9f8: 8b0a002b    	add	x11, x1, x10
10152d9fc: eb0b011f    	cmp	x8, x11
10152da00: 54000602    	b.hs	0x10152dac0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x194>
10152da04: eb0a0100    	subs	x0, x8, x10
10152da08: 540006a2    	b.hs	0x10152dadc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x1b0>
10152da0c: f941d2ca    	ldr	x10, [x22, #0x3a0]
10152da10: 5280320b    	mov	w11, #0x190             ; =400
10152da14: 9b0b2908    	madd	x8, x8, x11, x10
10152da18: 9106210a    	add	x10, x8, #0x188
10152da1c: 910243f4    	add	x20, sp, #0x90
10152da20: b9400141    	ldr	w1, [x10]
10152da24: 39449108    	ldrb	w8, [x8, #0x124]
10152da28: 71001d1f    	cmp	w8, #0x7
10152da2c: 540006e1    	b.ne	0x10152db08 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x1dc>
10152da30: 910243e8    	add	x8, sp, #0x90
10152da34: 9103c2a0    	add	x0, x21, #0xf0
10152da38: 910be2a2    	add	x2, x21, #0x2f8
10152da3c: 94005ffc    	bl	0x101545a2c <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
10152da40: 3cc08280    	ldur	q0, [x20, #0x8]
10152da44: 3cc18281    	ldur	q1, [x20, #0x18]
10152da48: ad3c07a0    	stp	q0, q1, [x29, #-0x80]
10152da4c: 3cc28280    	ldur	q0, [x20, #0x28]
10152da50: 3c9a03a0    	stur	q0, [x29, #-0x60]
10152da54: f9404be8    	ldr	x8, [sp, #0x90]
10152da58: f94067e9    	ldr	x9, [sp, #0xc8]
10152da5c: f81b03a9    	stur	x9, [x29, #-0x50]
10152da60: b4000ca8    	cbz	x8, 0x10152dbf4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x2c8>
10152da64: ad7c07a0    	ldp	q0, q1, [x29, #-0x80]
10152da68: 3c8083e0    	stur	q0, [sp, #0x8]
10152da6c: 3c8183e1    	stur	q1, [sp, #0x18]
10152da70: 3cda03a0    	ldur	q0, [x29, #-0x60]
10152da74: 3c8283e0    	stur	q0, [sp, #0x28]
10152da78: f85b03a9    	ldur	x9, [x29, #-0x50]
10152da7c: f9001fe9    	str	x9, [sp, #0x38]
10152da80: f90003e8    	str	x8, [sp]
10152da84: 1400002e    	b	0x10152db3c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x210>
10152da88: b900027f    	str	wzr, [x19]
10152da8c: 52800188    	mov	w8, #0xc                ; =12
10152da90: 39002268    	strb	w8, [x19, #0x8]
10152da94: 9000d848    	adrp	x8, 0x103035000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x4a0>
10152da98: 91028508    	add	x8, x8, #0xa1
10152da9c: 52800569    	mov	w9, #0x2b               ; =43
10152daa0: a9012668    	stp	x8, x9, [x19, #0x10]
10152daa4: a9567bfd    	ldp	x29, x30, [sp, #0x160]
10152daa8: a9554ff4    	ldp	x20, x19, [sp, #0x150]
10152daac: a95457f6    	ldp	x22, x21, [sp, #0x140]
10152dab0: a9535ff8    	ldp	x24, x23, [sp, #0x130]
10152dab4: a9526ffc    	ldp	x28, x27, [sp, #0x120]
10152dab8: 9105c3ff    	add	sp, sp, #0x170
10152dabc: d65f03c0    	ret
10152dac0: b900027f    	str	wzr, [x19]
10152dac4: 52800188    	mov	w8, #0xc                ; =12
10152dac8: 39002268    	strb	w8, [x19, #0x8]
10152dacc: 9000d848    	adrp	x8, 0x103035000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x4a0>
10152dad0: 91023d08    	add	x8, x8, #0x8f
10152dad4: 52800249    	mov	w9, #0x12               ; =18
10152dad8: 17fffff2    	b	0x10152daa0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x174>
10152dadc: eb01001f    	cmp	x0, x1
10152dae0: 54000d82    	b.hs	0x10152dc90 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x364>
10152dae4: f94192c8    	ldr	x8, [x22, #0x320]
10152dae8: 5280380a    	mov	w10, #0x1c0             ; =448
10152daec: 9b0a2008    	madd	x8, x0, x10, x8
10152daf0: 9106e10a    	add	x10, x8, #0x1b8
10152daf4: 910243f4    	add	x20, sp, #0x90
10152daf8: b9400141    	ldr	w1, [x10]
10152dafc: 39449108    	ldrb	w8, [x8, #0x124]
10152db00: 71001d1f    	cmp	w8, #0x7
10152db04: 54fff960    	b.eq	0x10152da30 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x104>
10152db08: 910243e8    	add	x8, sp, #0x90
10152db0c: aa0903e0    	mov	x0, x9
10152db10: 940057f8    	bl	0x101543af0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6scalar>
10152db14: b94093e8    	ldr	w8, [sp, #0x90]
10152db18: 7100191f    	cmp	w8, #0x6
10152db1c: 540004a1    	b.ne	0x10152dbb0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x284>
10152db20: 3cc28280    	ldur	q0, [x20, #0x28]
10152db24: 3c8643e0    	stur	q0, [sp, #0x64]
10152db28: 3cc38281    	ldur	q1, [x20, #0x38]
10152db2c: 3cc18282    	ldur	q2, [x20, #0x18]
10152db30: 3cc08283    	ldur	q3, [x20, #0x8]
10152db34: ad000be3    	stp	q3, q2, [sp]
10152db38: ad0107e0    	stp	q0, q1, [sp, #0x20]
10152db3c: f941aec8    	ldr	x8, [x22, #0x358]
10152db40: f9422ea9    	ldr	x9, [x21, #0x458]
10152db44: ab080121    	adds	x1, x9, x8
10152db48: 54000242    	b.hs	0x10152db90 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x264>
10152db4c: d360fc28    	lsr	x8, x1, #32
10152db50: b5000208    	cbnz	x8, 0x10152db90 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x264>
10152db54: 910243e8    	add	x8, sp, #0x90
10152db58: 9103c2a0    	add	x0, x21, #0xf0
10152db5c: 910003e2    	mov	x2, sp
10152db60: 910be2a3    	add	x3, x21, #0x2f8
10152db64: 94006674    	bl	0x101547534 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena3put>
10152db68: 394243e8    	ldrb	w8, [sp, #0x90]
10152db6c: 7100511f    	cmp	w8, #0x14
10152db70: 54000641    	b.ne	0x10152dc38 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x30c>
10152db74: f9422ea8    	ldr	x8, [x21, #0x458]
10152db78: 91000508    	add	x8, x8, #0x1
10152db7c: f9022ea8    	str	x8, [x21, #0x458]
10152db80: f900067f    	str	xzr, [x19, #0x8]
10152db84: 528000c8    	mov	w8, #0x6                ; =6
10152db88: b9000268    	str	w8, [x19]
10152db8c: 1400003a    	b	0x10152dc74 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x348>
10152db90: b900027f    	str	wzr, [x19]
10152db94: 52800188    	mov	w8, #0xc                ; =12
10152db98: 39002268    	strb	w8, [x19, #0x8]
10152db9c: 9000d848    	adrp	x8, 0x103035000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x4a0>
10152dba0: 9101d508    	add	x8, x8, #0x75
10152dba4: 52800349    	mov	w9, #0x1a               ; =26
10152dba8: a9012668    	stp	x8, x9, [x19, #0x10]
10152dbac: 14000032    	b	0x10152dc74 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x348>
10152dbb0: 3cc14280    	ldur	q0, [x20, #0x14]
10152dbb4: 3cc24281    	ldur	q1, [x20, #0x24]
10152dbb8: 3cc34282    	ldur	q2, [x20, #0x34]
10152dbbc: ad030be1    	stp	q1, q2, [sp, #0x60]
10152dbc0: b940d7e9    	ldr	w9, [sp, #0xd4]
10152dbc4: b90083e9    	str	w9, [sp, #0x80]
10152dbc8: 3cc04283    	ldur	q3, [x20, #0x4]
10152dbcc: ad0203e3    	stp	q3, q0, [sp, #0x40]
10152dbd0: f9406fea    	ldr	x10, [sp, #0xd8]
10152dbd4: 3c814260    	stur	q0, [x19, #0x14]
10152dbd8: 3c824261    	stur	q1, [x19, #0x24]
10152dbdc: 3c834262    	stur	q2, [x19, #0x34]
10152dbe0: b9004669    	str	w9, [x19, #0x44]
10152dbe4: 3c804263    	stur	q3, [x19, #0x4]
10152dbe8: b9000268    	str	w8, [x19]
10152dbec: f900266a    	str	x10, [x19, #0x48]
10152dbf0: 17ffffad    	b	0x10152daa4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x178>
10152dbf4: ad7c07a0    	ldp	q0, q1, [x29, #-0x80]
10152dbf8: 3c804280    	stur	q0, [x20, #0x4]
10152dbfc: 3c814281    	stur	q1, [x20, #0x14]
10152dc00: 3cda03a0    	ldur	q0, [x29, #-0x60]
10152dc04: 3c824280    	stur	q0, [x20, #0x24]
10152dc08: f85b03a8    	ldur	x8, [x29, #-0x50]
10152dc0c: f8034288    	stur	x8, [x20, #0x34]
10152dc10: ad4487e0    	ldp	q0, q1, [sp, #0x90]
10152dc14: 3c804260    	stur	q0, [x19, #0x4]
10152dc18: 52800048    	mov	w8, #0x2                ; =2
10152dc1c: b9000268    	str	w8, [x19]
10152dc20: 3c814261    	stur	q1, [x19, #0x14]
10152dc24: 3dc02fe0    	ldr	q0, [sp, #0xb0]
10152dc28: 3c824260    	stur	q0, [x19, #0x24]
10152dc2c: 3cc2c280    	ldur	q0, [x20, #0x2c]
10152dc30: 3d800e60    	str	q0, [x19, #0x30]
10152dc34: 17ffff9c    	b	0x10152daa4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x178>
10152dc38: b8401289    	ldur	w9, [x20, #0x1]
10152dc3c: b8009269    	stur	w9, [x19, #0x9]
10152dc40: b94097e9    	ldr	w9, [sp, #0x94]
10152dc44: b9000e69    	str	w9, [x19, #0xc]
10152dc48: 3dc02fe0    	ldr	q0, [sp, #0xb0]
10152dc4c: 3c828260    	stur	q0, [x19, #0x28]
10152dc50: f94063e9    	ldr	x9, [sp, #0xc0]
10152dc54: f9001e69    	str	x9, [x19, #0x38]
10152dc58: fd4057e0    	ldr	d0, [sp, #0xa8]
10152dc5c: 3cc08281    	ldur	q1, [x20, #0x8]
10152dc60: 52800049    	mov	w9, #0x2                ; =2
10152dc64: b9000269    	str	w9, [x19]
10152dc68: 39002268    	strb	w8, [x19, #0x8]
10152dc6c: 3d800661    	str	q1, [x19, #0x10]
10152dc70: fd001260    	str	d0, [x19, #0x20]
10152dc74: 910003e0    	mov	x0, sp
10152dc78: 97ffd041    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
10152dc7c: 17ffff8a    	b	0x10152daa4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper+0x178>
10152dc80: f00124e2    	adrp	x2, 0x1039cc000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.291+0x310>
10152dc84: 913d0042    	add	x2, x2, #0xf40
10152dc88: aa1403e0    	mov	x0, x20
10152dc8c: 94631968    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152dc90: f00124e2    	adrp	x2, 0x1039cc000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.291+0x310>
10152dc94: 913d6042    	add	x2, x2, #0xf58
10152dc98: 94631965    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152dc9c: aa0003f3    	mov	x19, x0
10152dca0: 910003e0    	mov	x0, sp
10152dca4: 97ffd036    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
10152dca8: aa1303e0    	mov	x0, x19
10152dcac: 94631e53    	bl	0x102df55f8 <dyld_stub_binder+0x102df55f8>
10152dcb0: 94631959    	bl	0x102df4214 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
