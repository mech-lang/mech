
/private/tmp/mech-action-retirement-round37-20261030/workers/after:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010152dcb4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call>:
10152dcb4: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
10152dcb8: a90167fa    	stp	x26, x25, [sp, #0x10]
10152dcbc: a9025ff8    	stp	x24, x23, [sp, #0x20]
10152dcc0: a90357f6    	stp	x22, x21, [sp, #0x30]
10152dcc4: a9044ff4    	stp	x20, x19, [sp, #0x40]
10152dcc8: a9057bfd    	stp	x29, x30, [sp, #0x50]
10152dccc: 910143fd    	add	x29, sp, #0x50
10152dcd0: d109c3ff    	sub	sp, sp, #0x270
10152dcd4: a9021fe1    	stp	x1, x7, [sp, #0x20]
10152dcd8: b90007e5    	str	w5, [sp, #0x4]
10152dcdc: a90083e2    	stp	x2, x0, [sp, #0x8]
10152dce0: f9424c3c    	ldr	x28, [x1, #0x498]
10152dce4: f9000fe4    	str	x4, [sp, #0x18]
10152dce8: b4000ae4    	cbz	x4, 0x10152de44 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x190>
10152dcec: aa0603f9    	mov	x25, x6
10152dcf0: aa0303fa    	mov	x26, x3
10152dcf4: d2800015    	mov	x21, #0x0               ; =0
10152dcf8: d280001b    	mov	x27, #0x0               ; =0
10152dcfc: a941a3e9    	ldp	x9, x8, [sp, #0x18]
10152dd00: d37ef533    	lsl	x19, x9, #2
10152dd04: 9104c3f4    	add	x20, sp, #0x130
10152dd08: f9424916    	ldr	x22, [x8, #0x490]
10152dd0c: 14000009    	b	0x10152dd30 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x7c>
10152dd10: ad4987e0    	ldp	q0, q1, [sp, #0x130]
10152dd14: ad4a8fe2    	ldp	q2, q3, [sp, #0x150]
10152dd18: ad010ee2    	stp	q2, q3, [x23, #0x20]
10152dd1c: ad0006e0    	stp	q0, q1, [x23]
10152dd20: 910102b5    	add	x21, x21, #0x40
10152dd24: 9100077b    	add	x27, x27, #0x1
10152dd28: f1001273    	subs	x19, x19, #0x4
10152dd2c: 540008c0    	b.eq	0x10152de44 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x190>
10152dd30: b87b7b41    	ldr	w1, [x26, x27, lsl #2]
10152dd34: f941af88    	ldr	x8, [x28, #0x358]
10152dd38: eb01011f    	cmp	x8, x1
10152dd3c: 54002c49    	b.ls	0x10152e2c4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x610>
10152dd40: f941ab88    	ldr	x8, [x28, #0x350]
10152dd44: 52802809    	mov	w9, #0x140              ; =320
10152dd48: 9ba92028    	umaddl	x8, w1, w9, x8
10152dd4c: 39449108    	ldrb	w8, [x8, #0x124]
10152dd50: 71001d1f    	cmp	w8, #0x7
10152dd54: 54000321    	b.ne	0x10152ddb8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x104>
10152dd58: f94017e8    	ldr	x8, [sp, #0x28]
10152dd5c: eb08037f    	cmp	x27, x8
10152dd60: 54002c62    	b.hs	0x10152e2ec <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x638>
10152dd64: f87b7b28    	ldr	x8, [x25, x27, lsl #3]
10152dd68: b5001b08    	cbnz	x8, 0x10152e0c8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x414>
10152dd6c: 9104c3e8    	add	x8, sp, #0x130
10152dd70: 9103c2c0    	add	x0, x22, #0xf0
10152dd74: 910be2c2    	add	x2, x22, #0x2f8
10152dd78: 94005f2d    	bl	0x101545a2c <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
10152dd7c: f9409bf7    	ldr	x23, [sp, #0x130]
10152dd80: 3cc08280    	ldur	q0, [x20, #0x8]
10152dd84: 3cc18281    	ldur	q1, [x20, #0x18]
10152dd88: ad0187e0    	stp	q0, q1, [sp, #0x30]
10152dd8c: 3cc28280    	ldur	q0, [x20, #0x28]
10152dd90: 3d8017e0    	str	q0, [sp, #0x50]
10152dd94: f8438288    	ldur	x8, [x20, #0x38]
10152dd98: f90033e8    	str	x8, [sp, #0x60]
10152dd9c: b4001a97    	cbz	x23, 0x10152e0ec <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x438>
10152dda0: ad4187e0    	ldp	q0, q1, [sp, #0x30]
10152dda4: ad0387e0    	stp	q0, q1, [sp, #0x70]
10152dda8: 3dc017e0    	ldr	q0, [sp, #0x50]
10152ddac: 3d8027e0    	str	q0, [sp, #0x90]
10152ddb0: f94033e8    	ldr	x8, [sp, #0x60]
10152ddb4: 14000012    	b	0x10152ddfc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x148>
10152ddb8: f94017e8    	ldr	x8, [sp, #0x28]
10152ddbc: eb08037f    	cmp	x27, x8
10152ddc0: 54002a02    	b.hs	0x10152e300 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x64c>
10152ddc4: f87b7b22    	ldr	x2, [x25, x27, lsl #3]
10152ddc8: 9104c3e8    	add	x8, sp, #0x130
10152ddcc: f94013e0    	ldr	x0, [sp, #0x20]
10152ddd0: 94005748    	bl	0x101543af0 <__RNvMs0_NtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6scalar>
10152ddd4: b94133e8    	ldr	w8, [sp, #0x130]
10152ddd8: 7100191f    	cmp	w8, #0x6
10152dddc: 54001561    	b.ne	0x10152e088 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x3d4>
10152dde0: f9409ff7    	ldr	x23, [sp, #0x138]
10152dde4: ad410281    	ldp	q1, q0, [x20, #0x20]
10152dde8: 3d8037e0    	str	q0, [sp, #0xd0]
10152ddec: f8440288    	ldur	x8, [x20, #0x40]
10152ddf0: 3cc10282    	ldur	q2, [x20, #0x10]
10152ddf4: ad0387e2    	stp	q2, q1, [sp, #0x70]
10152ddf8: 3d8027e0    	str	q0, [sp, #0x90]
10152ddfc: f90053e8    	str	x8, [sp, #0xa0]
10152de00: f9009bf7    	str	x23, [sp, #0x130]
10152de04: ad4387e0    	ldp	q0, q1, [sp, #0x70]
10152de08: 3c808280    	stur	q0, [x20, #0x8]
10152de0c: 3c818281    	stur	q1, [x20, #0x18]
10152de10: 3dc027e0    	ldr	q0, [sp, #0x90]
10152de14: 3c828280    	stur	q0, [x20, #0x28]
10152de18: f8038288    	stur	x8, [x20, #0x38]
10152de1c: f9406ec1    	ldr	x1, [x22, #0xd8]
10152de20: eb01037f    	cmp	x27, x1
10152de24: 540025a2    	b.hs	0x10152e2d8 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x624>
10152de28: f9406ad8    	ldr	x24, [x22, #0xd0]
10152de2c: 8b150317    	add	x23, x24, x21
10152de30: f94002e8    	ldr	x8, [x23]
10152de34: b4fff6e8    	cbz	x8, 0x10152dd10 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x5c>
10152de38: 8b150300    	add	x0, x24, x21
10152de3c: 97ffcfd0    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
10152de40: 17ffffb4    	b	0x10152dd10 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x5c>
10152de44: f9420381    	ldr	x1, [x28, #0x400]
10152de48: f94007f5    	ldr	x21, [sp, #0x8]
10152de4c: eb0102bf    	cmp	x21, x1
10152de50: 54002622    	b.hs	0x10152e314 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x660>
10152de54: f941ff88    	ldr	x8, [x28, #0x3f8]
10152de58: 52803e09    	mov	w9, #0x1f0              ; =496
10152de5c: 9b0922a2    	madd	x2, x21, x9, x8
10152de60: a9402049    	ldp	x9, x8, [x2]
10152de64: d27f0129    	eor	x9, x9, #0x2
10152de68: aa080128    	orr	x8, x9, x8
10152de6c: a941a7f4    	ldp	x20, x9, [sp, #0x18]
10152de70: b5000148    	cbnz	x8, 0x10152de98 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x1e4>
10152de74: f9400bea    	ldr	x10, [sp, #0x10]
10152de78: b900015f    	str	wzr, [x10]
10152de7c: 52800188    	mov	w8, #0xc                ; =12
10152de80: b000d829    	adrp	x9, 0x103032000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.241+0x21>
10152de84: 913ae529    	add	x9, x9, #0xeb9
10152de88: a900a548    	stp	x8, x9, [x10, #0x8]
10152de8c: 52800408    	mov	w8, #0x20               ; =32
10152de90: f9000d48    	str	x8, [x10, #0x18]
10152de94: 140000c3    	b	0x10152e1a0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x4ec>
10152de98: f9005bff    	str	xzr, [sp, #0xb0]
10152de9c: f9424933    	ldr	x19, [x9, #0x490]
10152dea0: f9406e68    	ldr	x8, [x19, #0xd8]
10152dea4: eb08029f    	cmp	x20, x8
10152dea8: 54001f48    	b.hi	0x10152e290 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x5dc>
10152deac: f9406a63    	ldr	x3, [x19, #0xd0]
10152deb0: ad440520    	ldp	q0, q1, [x9, #0x80]
10152deb4: ad0d87e0    	stp	q0, q1, [sp, #0x1b0]
10152deb8: f9405128    	ldr	x8, [x9, #0xa0]
10152debc: f900ebe8    	str	x8, [sp, #0x1d0]
10152dec0: ad420520    	ldp	q0, q1, [x9, #0x40]
10152dec4: ad0b87e0    	stp	q0, q1, [sp, #0x170]
10152dec8: ad430121    	ldp	q1, q0, [x9, #0x60]
10152decc: ad0c83e1    	stp	q1, q0, [sp, #0x190]
10152ded0: ad400520    	ldp	q0, q1, [x9]
10152ded4: ad0987e0    	stp	q0, q1, [sp, #0x130]
10152ded8: ad410121    	ldp	q1, q0, [x9, #0x20]
10152dedc: ad0a83e1    	stp	q1, q0, [sp, #0x150]
10152dee0: 9103e3e8    	add	x8, sp, #0xf8
10152dee4: 910d2260    	add	x0, x19, #0x348
10152dee8: 9102c3e5    	add	x5, sp, #0xb0
10152deec: 9104c3e6    	add	x6, sp, #0x130
10152def0: 910ee267    	add	x7, x19, #0x3b8
10152def4: aa1503e1    	mov	x1, x21
10152def8: aa1403e4    	mov	x4, x20
10152defc: 97ff7ddc    	bl	0x10150d66c <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime7sessionNtB2_13CallCacheLane6invoke>
10152df00: f9406e62    	ldr	x2, [x19, #0xd8]
10152df04: eb02029f    	cmp	x20, x2
10152df08: 54001d28    	b.hi	0x10152e2ac <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x5f8>
10152df0c: f9406a60    	ldr	x0, [x19, #0xd0]
10152df10: f9009bff    	str	xzr, [sp, #0x130]
10152df14: 9104c3e2    	add	x2, sp, #0x130
10152df18: aa1403e1    	mov	x1, x20
10152df1c: 94018ad5    	bl	0x101590a70 <__RNvXNtNtCsgDHHaSskbIF_4core5slice10specializeSINtNtB6_6option6OptionNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEINtB2_8SpecFillBI_E9spec_fillCs29QkOtpKx6e_8mech_gpu>
10152df20: d103a3b4    	sub	x20, x29, #0xe8
10152df24: 3943e3e8    	ldrb	w8, [sp, #0xf8]
10152df28: 7100b91f    	cmp	w8, #0x2e
10152df2c: 54000501    	b.ne	0x10152dfcc <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x318>
10152df30: f9405be8    	ldr	x8, [sp, #0xb0]
10152df34: b4001028    	cbz	x8, 0x10152e138 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x484>
10152df38: a94ba7f5    	ldp	x21, x9, [sp, #0xb8]
10152df3c: 9102c3ea    	add	x10, sp, #0xb0
10152df40: 3cc18140    	ldur	q0, [x10, #0x18]
10152df44: 3c898140    	stur	q0, [x10, #0x98]
10152df48: 3cc28140    	ldur	q0, [x10, #0x28]
10152df4c: 3c8a8140    	stur	q0, [x10, #0xa8]
10152df50: f94077ea    	ldr	x10, [sp, #0xe8]
10152df54: a91357e8    	stp	x8, x21, [sp, #0x130]
10152df58: f900b7ea    	str	x10, [sp, #0x168]
10152df5c: f900a3e9    	str	x9, [sp, #0x140]
10152df60: d103a3a8    	sub	x8, x29, #0xe8
10152df64: 9103c260    	add	x0, x19, #0xf0
10152df68: 9104c3e2    	add	x2, sp, #0x130
10152df6c: 910be263    	add	x3, x19, #0x2f8
10152df70: b94007e1    	ldr	w1, [sp, #0x4]
10152df74: 94006570    	bl	0x101547534 <__RNvMs1_NtNtCs29QkOtpKx6e_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena3put>
10152df78: 385183a8    	ldurb	w8, [x29, #-0xe8]
10152df7c: 7100511f    	cmp	w8, #0x14
10152df80: 54000ec1    	b.ne	0x10152e158 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x4a4>
10152df84: 52800028    	mov	w8, #0x1                ; =1
10152df88: 39118268    	strb	w8, [x19, #0x460]
10152df8c: f941af81    	ldr	x1, [x28, #0x358]
10152df90: b94007e8    	ldr	w8, [sp, #0x4]
10152df94: 2a0803e0    	mov	w0, w8
10152df98: eb00003f    	cmp	x1, x0
10152df9c: 54001ce9    	b.ls	0x10152e338 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x684>
10152dfa0: f941ab88    	ldr	x8, [x28, #0x350]
10152dfa4: 52802809    	mov	w9, #0x140              ; =320
10152dfa8: 9ba92008    	umaddl	x8, w0, w9, x8
10152dfac: 3944910a    	ldrb	w10, [x8, #0x124]
10152dfb0: 71001d5f    	cmp	w10, #0x7
10152dfb4: 54001061    	b.ne	0x10152e1c0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x50c>
10152dfb8: f9400be9    	ldr	x9, [sp, #0x10]
10152dfbc: f900053f    	str	xzr, [x9, #0x8]
10152dfc0: 528000c8    	mov	w8, #0x6                ; =6
10152dfc4: b9000128    	str	w8, [x9]
10152dfc8: 14000074    	b	0x10152e198 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x4e4>
10152dfcc: 3943e7e9    	ldrb	w9, [sp, #0xf9]
10152dfd0: 9102c3ea    	add	x10, sp, #0xb0
10152dfd4: 3cc4a140    	ldur	q0, [x10, #0x4a]
10152dfd8: 3c882140    	stur	q0, [x10, #0x82]
10152dfdc: 3cc5a140    	ldur	q0, [x10, #0x5a]
10152dfe0: 3c892140    	stur	q0, [x10, #0x92]
10152dfe4: 3cc6a140    	ldur	q0, [x10, #0x6a]
10152dfe8: 3c8a2140    	stur	q0, [x10, #0xa2]
10152dfec: f94097ea    	ldr	x10, [sp, #0x128]
10152dff0: f900b3ea    	str	x10, [sp, #0x160]
10152dff4: 3904c3e8    	strb	w8, [sp, #0x130]
10152dff8: 3904c7e9    	strb	w9, [sp, #0x131]
10152dffc: f941bf81    	ldr	x1, [x28, #0x378]
10152e000: eb0102bf    	cmp	x21, x1
10152e004: 54001902    	b.hs	0x10152e324 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x670>
10152e008: f941bb88    	ldr	x8, [x28, #0x370]
10152e00c: 52802e09    	mov	w9, #0x170              ; =368
10152e010: 9b0922a8    	madd	x8, x21, x9, x8
10152e014: b9415909    	ldr	w9, [x8, #0x158]
10152e018: 9105250a    	add	x10, x8, #0x149
10152e01c: b8047289    	stur	w9, [x20, #0x47]
10152e020: 3dc00140    	ldr	q0, [x10]
10152e024: 3c9503a0    	stur	q0, [x29, #-0xb0]
10152e028: ad4987e0    	ldp	q0, q1, [sp, #0x130]
10152e02c: 3c84b280    	stur	q0, [x20, #0x4b]
10152e030: 3c85b281    	stur	q1, [x20, #0x5b]
10152e034: 3dc057e0    	ldr	q0, [sp, #0x150]
10152e038: 3c86b280    	stur	q0, [x20, #0x6b]
10152e03c: ad7a83a1    	ldp	q1, q0, [x29, #-0xb0]
10152e040: f9400bea    	ldr	x10, [sp, #0x10]
10152e044: 3c815140    	stur	q0, [x10, #0x15]
10152e048: ad7b8ba0    	ldp	q0, q2, [x29, #-0x90]
10152e04c: 3c825140    	stur	q0, [x10, #0x25]
10152e050: f940b3e9    	ldr	x9, [sp, #0x160]
10152e054: f807b289    	stur	x9, [x20, #0x7b]
10152e058: 3c835142    	stur	q2, [x10, #0x35]
10152e05c: 3cc73280    	ldur	q0, [x20, #0x73]
10152e060: 3d801140    	str	q0, [x10, #0x40]
10152e064: 39452108    	ldrb	w8, [x8, #0x148]
10152e068: 52800069    	mov	w9, #0x3                ; =3
10152e06c: b9000149    	str	w9, [x10]
10152e070: 39001148    	strb	w8, [x10, #0x4]
10152e074: 3c805141    	stur	q1, [x10, #0x5]
10152e078: f9405be8    	ldr	x8, [sp, #0xb0]
10152e07c: b4000928    	cbz	x8, 0x10152e1a0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x4ec>
10152e080: 9102c3e0    	add	x0, sp, #0xb0
10152e084: 14000046    	b	0x10152e19c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x4e8>
10152e088: b94137e9    	ldr	w9, [sp, #0x134]
10152e08c: ad408680    	ldp	q0, q1, [x20, #0x10]
10152e090: ad0587e0    	stp	q0, q1, [sp, #0xb0]
10152e094: 3cc30282    	ldur	q2, [x20, #0x30]
10152e098: 3d8037e2    	str	q2, [sp, #0xd0]
10152e09c: f844028a    	ldur	x10, [x20, #0x40]
10152e0a0: f90073ea    	str	x10, [sp, #0xe0]
10152e0a4: f9409feb    	ldr	x11, [sp, #0x138]
10152e0a8: f940bfec    	ldr	x12, [sp, #0x178]
10152e0ac: f9400bed    	ldr	x13, [sp, #0x10]
10152e0b0: ad0085a0    	stp	q0, q1, [x13, #0x10]
10152e0b4: 3d800da2    	str	q2, [x13, #0x30]
10152e0b8: 290025a8    	stp	w8, w9, [x13]
10152e0bc: f90005ab    	str	x11, [x13, #0x8]
10152e0c0: a90431aa    	stp	x10, x12, [x13, #0x40]
10152e0c4: 14000037    	b	0x10152e1a0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x4ec>
10152e0c8: f9400bea    	ldr	x10, [sp, #0x10]
10152e0cc: b900015f    	str	wzr, [x10]
10152e0d0: 52800188    	mov	w8, #0xc                ; =12
10152e0d4: 39002148    	strb	w8, [x10, #0x8]
10152e0d8: f000d828    	adrp	x8, 0x103035000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x4a0>
10152e0dc: 91033108    	add	x8, x8, #0xcc
10152e0e0: 52800489    	mov	w9, #0x24               ; =36
10152e0e4: a9012548    	stp	x8, x9, [x10, #0x10]
10152e0e8: 1400002e    	b	0x10152e1a0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x4ec>
10152e0ec: ad4187e0    	ldp	q0, q1, [sp, #0x30]
10152e0f0: 9102c3ea    	add	x10, sp, #0xb0
10152e0f4: 3c884140    	stur	q0, [x10, #0x84]
10152e0f8: 3c894141    	stur	q1, [x10, #0x94]
10152e0fc: 3dc017e0    	ldr	q0, [sp, #0x50]
10152e100: 3c8a4140    	stur	q0, [x10, #0xa4]
10152e104: f94033e8    	ldr	x8, [sp, #0x60]
10152e108: f80b4148    	stur	x8, [x10, #0xb4]
10152e10c: ad4987e0    	ldp	q0, q1, [sp, #0x130]
10152e110: f9400be9    	ldr	x9, [sp, #0x10]
10152e114: 3c804120    	stur	q0, [x9, #0x4]
10152e118: 52800048    	mov	w8, #0x2                ; =2
10152e11c: b9000128    	str	w8, [x9]
10152e120: 3c814121    	stur	q1, [x9, #0x14]
10152e124: 3dc057e0    	ldr	q0, [sp, #0x150]
10152e128: 3c824120    	stur	q0, [x9, #0x24]
10152e12c: 3ccac140    	ldur	q0, [x10, #0xac]
10152e130: 3d800d20    	str	q0, [x9, #0x30]
10152e134: 1400001b    	b	0x10152e1a0 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x4ec>
10152e138: f9400bea    	ldr	x10, [sp, #0x10]
10152e13c: b900015f    	str	wzr, [x10]
10152e140: 52800188    	mov	w8, #0xc                ; =12
10152e144: 9000d829    	adrp	x9, 0x103032000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.241+0x21>
10152e148: 913b6529    	add	x9, x9, #0xed9
10152e14c: a900a548    	stp	x8, x9, [x10, #0x8]
10152e150: 528002c8    	mov	w8, #0x16               ; =22
10152e154: 17ffff4f    	b	0x10152de90 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x1dc>
10152e158: b8401289    	ldur	w9, [x20, #0x1]
10152e15c: f9400bea    	ldr	x10, [sp, #0x10]
10152e160: b8009149    	stur	w9, [x10, #0x9]
10152e164: b851c3a9    	ldur	w9, [x29, #-0xe4]
10152e168: b9000d49    	str	w9, [x10, #0xc]
10152e16c: 3dc00a80    	ldr	q0, [x20, #0x20]
10152e170: 3c828140    	stur	q0, [x10, #0x28]
10152e174: f85483a9    	ldur	x9, [x29, #-0xb8]
10152e178: f9001d49    	str	x9, [x10, #0x38]
10152e17c: fc5303a0    	ldur	d0, [x29, #-0xd0]
10152e180: 3cc08281    	ldur	q1, [x20, #0x8]
10152e184: 52800049    	mov	w9, #0x2                ; =2
10152e188: b9000149    	str	w9, [x10]
10152e18c: 39002148    	strb	w8, [x10, #0x8]
10152e190: 3d800541    	str	q1, [x10, #0x10]
10152e194: fd001140    	str	d0, [x10, #0x20]
10152e198: 9104c3e0    	add	x0, sp, #0x130
10152e19c: 97ffcef8    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
10152e1a0: 9109c3ff    	add	sp, sp, #0x270
10152e1a4: a9457bfd    	ldp	x29, x30, [sp, #0x50]
10152e1a8: a9444ff4    	ldp	x20, x19, [sp, #0x40]
10152e1ac: a94357f6    	ldp	x22, x21, [sp, #0x30]
10152e1b0: a9425ff8    	ldp	x24, x23, [sp, #0x20]
10152e1b4: a94167fa    	ldp	x26, x25, [sp, #0x10]
10152e1b8: a8c66ffc    	ldp	x28, x27, [sp], #0x60
10152e1bc: d65f03c0    	ret
10152e1c0: f9400aa8    	ldr	x8, [x21, #0x10]
10152e1c4: 39404109    	ldrb	w9, [x8, #0x10]
10152e1c8: 7100095f    	cmp	w10, #0x2
10152e1cc: 5400010d    	b.le	0x10152e1ec <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x538>
10152e1d0: 7100115f    	cmp	w10, #0x4
10152e1d4: 5400018c    	b.gt	0x10152e204 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x550>
10152e1d8: 71000d5f    	cmp	w10, #0x3
10152e1dc: 540002e1    	b.ne	0x10152e238 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x584>
10152e1e0: 7100313f    	cmp	w9, #0xc
10152e1e4: 54000260    	b.eq	0x10152e230 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x57c>
10152e1e8: 14000021    	b	0x10152e26c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x5b8>
10152e1ec: 3400018a    	cbz	w10, 0x10152e21c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x568>
10152e1f0: 7100055f    	cmp	w10, #0x1
10152e1f4: 540001a1    	b.ne	0x10152e228 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x574>
10152e1f8: 7100113f    	cmp	w9, #0x4
10152e1fc: 54000381    	b.ne	0x10152e26c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x5b8>
10152e200: 1400000c    	b	0x10152e230 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x57c>
10152e204: 7100155f    	cmp	w10, #0x5
10152e208: 54000201    	b.ne	0x10152e248 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x594>
10152e20c: 7100093f    	cmp	w9, #0x2
10152e210: 540002e1    	b.ne	0x10152e26c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x5b8>
10152e214: 79402508    	ldrh	w8, [x8, #0x12]
10152e218: 1400000f    	b	0x10152e254 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x5a0>
10152e21c: 7100413f    	cmp	w9, #0x10
10152e220: 54000100    	b.eq	0x10152e240 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x58c>
10152e224: 14000012    	b	0x10152e26c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x5b8>
10152e228: 7100253f    	cmp	w9, #0x9
10152e22c: 54000201    	b.ne	0x10152e26c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x5b8>
10152e230: f9400d08    	ldr	x8, [x8, #0x18]
10152e234: 14000008    	b	0x10152e254 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x5a0>
10152e238: 7100053f    	cmp	w9, #0x1
10152e23c: 54000181    	b.ne	0x10152e26c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x5b8>
10152e240: 39404508    	ldrb	w8, [x8, #0x11]
10152e244: 14000004    	b	0x10152e254 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x5a0>
10152e248: 71000d3f    	cmp	w9, #0x3
10152e24c: 54000101    	b.ne	0x10152e26c <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x5b8>
10152e250: b9401508    	ldr	w8, [x8, #0x14]
10152e254: 52800029    	mov	w9, #0x1                ; =1
10152e258: f9400bea    	ldr	x10, [sp, #0x10]
10152e25c: a900a149    	stp	x9, x8, [x10, #0x8]
10152e260: 528000c8    	mov	w8, #0x6                ; =6
10152e264: b9000148    	str	w8, [x10]
10152e268: 17ffffcc    	b	0x10152e198 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x4e4>
10152e26c: b000d848    	adrp	x8, 0x103037000 <_anon.369b439a638cb010e9292f03e79ebf78.380+0x24a0>
10152e270: 91348108    	add	x8, x8, #0xd20
10152e274: 528004c9    	mov	w9, #0x26               ; =38
10152e278: f9400bea    	ldr	x10, [sp, #0x10]
10152e27c: a9012548    	stp	x8, x9, [x10, #0x10]
10152e280: b900015f    	str	wzr, [x10]
10152e284: 52800189    	mov	w9, #0xc                ; =12
10152e288: f9000549    	str	x9, [x10, #0x8]
10152e28c: 17ffffc3    	b	0x10152e198 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x4e4>
10152e290: d00124e3    	adrp	x3, 0x1039cc000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.291+0x310>
10152e294: 913ee063    	add	x3, x3, #0xfb8
10152e298: d2800000    	mov	x0, #0x0                ; =0
10152e29c: aa1403e1    	mov	x1, x20
10152e2a0: aa0803e2    	mov	x2, x8
10152e2a4: 9463184f    	bl	0x102df43e0 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
10152e2a8: 14000027    	b	0x10152e344 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x690>
10152e2ac: d00124e3    	adrp	x3, 0x1039cc000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.291+0x310>
10152e2b0: 913e2063    	add	x3, x3, #0xf88
10152e2b4: d2800000    	mov	x0, #0x0                ; =0
10152e2b8: aa1403e1    	mov	x1, x20
10152e2bc: 94631849    	bl	0x102df43e0 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
10152e2c0: 14000021    	b	0x10152e344 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x690>
10152e2c4: d00124e2    	adrp	x2, 0x1039cc000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.291+0x310>
10152e2c8: 913f4042    	add	x2, x2, #0xfd0
10152e2cc: aa0103e0    	mov	x0, x1
10152e2d0: aa0803e1    	mov	x1, x8
10152e2d4: 946317d6    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152e2d8: f00124e2    	adrp	x2, 0x1039cd000 <_anon.369b439a638cb010e9292f03e79ebf78.285+0x710>
10152e2dc: 91006042    	add	x2, x2, #0x18
10152e2e0: aa1b03e0    	mov	x0, x27
10152e2e4: 946317d2    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152e2e8: 14000017    	b	0x10152e344 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x690>
10152e2ec: d00124e2    	adrp	x2, 0x1039cc000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.291+0x310>
10152e2f0: 913fa042    	add	x2, x2, #0xfe8
10152e2f4: aa1b03e0    	mov	x0, x27
10152e2f8: f94017e1    	ldr	x1, [sp, #0x28]
10152e2fc: 946317cc    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152e300: f00124e2    	adrp	x2, 0x1039cd000 <_anon.369b439a638cb010e9292f03e79ebf78.285+0x710>
10152e304: 91000042    	add	x2, x2, #0x0
10152e308: aa1b03e0    	mov	x0, x27
10152e30c: f94017e1    	ldr	x1, [sp, #0x28]
10152e310: 946317c7    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152e314: d00124e2    	adrp	x2, 0x1039cc000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.291+0x310>
10152e318: 913dc042    	add	x2, x2, #0xf70
10152e31c: aa1503e0    	mov	x0, x21
10152e320: 946317c3    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152e324: d00124e2    	adrp	x2, 0x1039cc000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.291+0x310>
10152e328: 9117c042    	add	x2, x2, #0x5f0
10152e32c: aa1503e0    	mov	x0, x21
10152e330: 946317bf    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152e334: 14000004    	b	0x10152e344 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x690>
10152e338: d00124e2    	adrp	x2, 0x1039cc000 <_anon.112f7d08587023f1eaf0e0f49cd709a4.291+0x310>
10152e33c: 913e8042    	add	x2, x2, #0xfa0
10152e340: 946317bb    	bl	0x102df422c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152e344: d4200020    	brk	#0x1
10152e348: aa0003f3    	mov	x19, x0
10152e34c: 9104c3e0    	add	x0, sp, #0x130
10152e350: 97ffce8b    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
10152e354: 1400001c    	b	0x10152e3c4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x710>
10152e358: aa0003f3    	mov	x19, x0
10152e35c: 9104c3e0    	add	x0, sp, #0x130
10152e360: 97ffd17b    	bl	0x10152294c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs29QkOtpKx6e_8mech_gpu>
10152e364: 14000014    	b	0x10152e3b4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x700>
10152e368: 8b150308    	add	x8, x24, x21
10152e36c: ad4987e0    	ldp	q0, q1, [sp, #0x130]
10152e370: ad4a8fe2    	ldp	q2, q3, [sp, #0x150]
10152e374: ad010d02    	stp	q2, q3, [x8, #0x20]
10152e378: ad000500    	stp	q0, q1, [x8]
10152e37c: 94631c9f    	bl	0x102df55f8 <dyld_stub_binder+0x102df55f8>
10152e380: aa0003f3    	mov	x19, x0
10152e384: b4000217    	cbz	x23, 0x10152e3c4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x710>
10152e388: 9104c3e0    	add	x0, sp, #0x130
10152e38c: 97ffce7c    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
10152e390: 1400000d    	b	0x10152e3c4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x710>
10152e394: aa0003f3    	mov	x19, x0
10152e398: 3943e3e8    	ldrb	w8, [sp, #0xf8]
10152e39c: 7100b91f    	cmp	w8, #0x2e
10152e3a0: 540000a0    	b.eq	0x10152e3b4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x700>
10152e3a4: 9103e3e0    	add	x0, sp, #0xf8
10152e3a8: 97ffd169    	bl	0x10152294c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs29QkOtpKx6e_8mech_gpu>
10152e3ac: 14000002    	b	0x10152e3b4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x700>
10152e3b0: aa0003f3    	mov	x19, x0
10152e3b4: f9405be8    	ldr	x8, [sp, #0xb0]
10152e3b8: b4000068    	cbz	x8, 0x10152e3c4 <__RNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call+0x710>
10152e3bc: 9102c3e0    	add	x0, sp, #0xb0
10152e3c0: 97ffce6f    	bl	0x101521d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
10152e3c4: aa1303e0    	mov	x0, x19
10152e3c8: 94631c8c    	bl	0x102df55f8 <dyld_stub_binder+0x102df55f8>
10152e3cc: 94631792    	bl	0x102df4214 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
