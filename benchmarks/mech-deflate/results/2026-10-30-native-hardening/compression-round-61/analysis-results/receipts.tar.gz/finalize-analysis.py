"""Run only after all serialized build/measurement/qualification phases finish."""
from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent
assert (r/'binary-audit.json').exists(),'Wait for the independently pinned binary audit'
for name,args in [('profile_analysis.py',[str(r),str(r/'profile-numbers.json')]),('validation.py',[str(r),str(r/'validation.json')]),('analyze.py',[str(r),str(r/'analysis')]),('confirm.py',[str(r),str(r/'confirmation-scorecard.json')]),('render-report.py',[str(r/'analysis/scorecard.json'),str(r/'report.md')])]:
 print('ANALYZE',name,flush=True);subprocess.run(['python3',str(r/name),*args],check=True)
 if name=='validation.py':assert json.loads((r/'validation.json').read_text())['all_required_checks_pass'],'Refuse final publication while a required qualification check fails'
files=[r/name for name in ['analyze.py','validation.py','render-report.py','reconstruct.py','profile_analysis.py','finalize-analysis.py','implementation.json','allocation-target.json','decision.json','confirm.py','confirmation-scorecard.json','final-confirmation/purpose.json','final-confirmation/bindings','baseline','binary-audit.json','harness-audit.md','profile-numbers.json','validation.json','analysis','report.md','findings-packet','units-parent-initial','architecture-audit-fixed']]
subprocess.run(['python3',str(r/'archive.py'),'analysis-results',*map(str,files)],check=True)
print('READY: copy analysis/scorecard.{json,csv}, report.md, profile-numbers.json, validation.json, binary-audit.json, confirmation-scorecard.json, and analyze.py/validation.py/render-report.py/reconstruct.py/profile_analysis.py/confirm.py into the published R61 packet; run reconstruct.py against a new empty scratch directory before final publication.',flush=True)
