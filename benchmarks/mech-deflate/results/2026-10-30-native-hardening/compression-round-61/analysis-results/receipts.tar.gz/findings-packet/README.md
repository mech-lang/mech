# Proposal provenance

These proposal files were copied before R61 execution. proof.md records the original R56 source audit and historical line references; it is a rationale document, not an R61 benchmark receipt. R61 uses the exact R60 and R61 release sources in implementation.json and baseline/linked-primary bindings.

production.patch describes the single removed numeric_boundary spill. tests.patch is the initial proposal and contains the boxed-shape inference defect encountered during the first parent test build. That failed build remains in units-parent-initial. The corrected test actually compiled and executed is preserved in units-parent/numeric-first-change-source.rs and units-after/numeric-first-change-source.rs, with runtime helper snapshots beside them. Use those snapshots and their source revisions for final test provenance, rather than treating the initial patch as the final compiled source.

The semantic argument is explicit current-value transport through the helper argument lane, plus SSA retention of other live values. It does not depend on an earlier full spill by the caller. Normal bailout/exit spills and ready0/error handling remain unchanged.
