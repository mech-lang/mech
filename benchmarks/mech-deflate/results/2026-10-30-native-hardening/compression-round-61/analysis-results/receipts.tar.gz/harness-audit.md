# R61 prepared harness audit

Preparation uses copied R60 scripts and frozen R60 baseline bindings. At initial preparation no prepared script had been executed. Subsequent execution and qualification are recorded separately; this paragraph is not current run status. All paths are private scratch; no repository or Git mutation was made.

Parent-first acceptance is explicit: units.py parent requires numeric_boundary.rs to match the captured production file, and build-native.py requires its successful one-test receipt. Candidate units require that exact file minus the one redundant spill line. Tests are built from current GPU test source with unchanged frozen production dependencies, so the parent result is not a stale compiled test binary.

All primary workers, counters, complete censuses and profiles bind to their respective Object/image/library graph. Baseline/candidate Object equality is intentionally not required. Normalized worker source still compares after replacing only image path and identity symbol; the inherited worker comment was preserved verbatim, because changing it would spuriously alter the normalized hash.

Only GPU libraries may differ. All non-GPU hashes, feature lists and profiles must agree. Full compressor source, bytecode, mimalloc object, logical work60260219686, comparison47612, exact output, input aliases and output capacity13 clear/reuse remain fixed. No physical allocation change is predicted; the complete census must still reconcile 8173 requests/98228396 bytes/162 reallocations. CPU, heap, samples and elapsed are separate cohorts and never multiplied.

Qualification inventory targets are runtime328, first-change1, codegenvector1, components236, connected8, path1, CI34 and Python132. All inventories are checked before execution. Existing knucleotide exclusion remains explicit. Reproduction needs the copied baseline/binding.json and metadata.json, final implementation/validation/binary-audit JSON and scripts in the analysis archive; finalize-analysis.py includes these inputs.

R60 is explicitly an instruction improvement with an elapsed tradeoff. Its retained primary summary is labelled as historical baseline evidence. R61 reports every new primary pair and all adverse counter directions without substituting one cohort for another.

Reporting audit during R61 measurement: removed inherited R60 preflight references and predetermined retain/adverse-cycle prose. The R61 decision starts pending and pins round61 plus both build revisions. The semantic rationale is explicit argument-lane transport and SSA retention, not an earlier caller spill. Historical R60 primary observations live only in baseline/r60-primary-summary.json; the R61 analyzer reads fresh linked-primary observations exclusively. Initial failed parent-test compilation is preserved in units-parent-initial and included in validation as corrected history, not a current required-check failure.
