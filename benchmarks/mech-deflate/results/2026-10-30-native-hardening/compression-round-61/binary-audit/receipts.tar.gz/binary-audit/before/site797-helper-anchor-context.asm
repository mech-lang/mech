; These windows are anchored by mov x1,#797, the source-call argument.
; Inspect actual successful bounds edge and byte load before treating
; them as the precise native source797 load. No addresses are reused
; blindly across Objects. Overlapping windows are intentional.

; Anchor 0x202b4
   1ffb4:      	str	x13, [sp, x16, sxtx]
   1ffb8:      	cmp	x0, #0x0
   1ffbc:      	b.ne	0xf1644 <_mech_canonical_program_entry_v1+0xf1644>
   1ffc0:      	mov	w16, #0xa8d8            ; =43224
   1ffc4:      	movk	w16, #0x1, lsl #16
   1ffc8:      	ldr	x0, [sp, x16, sxtx]
   1ffcc:      	b	0x1ffdc <_mech_canonical_program_entry_v1+0x1ffdc>
   1ffd0:      	mov	w16, #0xa8d8            ; =43224
   1ffd4:      	movk	w16, #0x1, lsl #16
   1ffd8:      	ldr	x0, [sp, x16, sxtx]
   1ffdc:      	mov	w16, #0xa8d8            ; =43224
   1ffe0:      	movk	w16, #0x1, lsl #16
   1ffe4:      	ldr	x0, [sp, x16, sxtx]
   1ffe8:      	ldr	x0, [x0, #0x1af0]
   1ffec:      	mov	w16, #0xa8d8            ; =43224
   1fff0:      	movk	w16, #0x1, lsl #16
   1fff4:      	ldr	x3, [sp, x16, sxtx]
   1fff8:      	ldr	x1, [x3, #0xcf8]
   1fffc:      	cmp	x0, x1
   20000:      	b.eq	0x20084 <_mech_canonical_program_entry_v1+0x20084>
   20004:      	mov	x1, #0x320              ; =800
   20008:      	ldur	x0, [sp]
   2000c:      	str	x1, [x0, #0x48]
   20010:      	mov	w0, #0xd870             ; =55408
   20014:      	movk	w0, #0x2, lsl #16
   20018:      	mov	w16, #0xa8d8            ; =43224
   2001c:      	movk	w16, #0x1, lsl #16
   20020:      	ldr	x11, [sp, x16, sxtx]
   20024:      	ldr	x0, [x11, x0]
   20028:      	cmp	x0, #0x0
   2002c:      	b.ne	0x20064 <_mech_canonical_program_entry_v1+0x20064>
   20030:      	mov	w16, #0xa8c8            ; =43208
   20034:      	movk	w16, #0x1, lsl #16
   20038:      	ldr	x2, [sp, x16, sxtx]
   2003c:      	mov	w16, #0xa8d0            ; =43216
   20040:      	movk	w16, #0x1, lsl #16
   20044:      	ldr	x0, [sp, x16, sxtx]
   20048:      	blr	x2
   2004c:      	mov	x1, #0x2                ; =2
   20050:      	mov	w16, #0x3af0            ; =15088
   20054:      	movk	w16, #0x1, lsl #16
   20058:      	str	x1, [sp, x16, sxtx]
   2005c:      	cmp	x0, #0x0
   20060:      	b.ne	0xf1648 <_mech_canonical_program_entry_v1+0xf1648>
   20064:      	ldur	x0, [sp]
   20068:      	mov	w16, #0xa760            ; =42848
   2006c:      	movk	w16, #0x1, lsl #16
   20070:      	ldr	x1, [sp, x16, sxtx]
   20074:      	mov	w16, #0x3af0            ; =15088
   20078:      	movk	w16, #0x1, lsl #16
   2007c:      	str	x1, [sp, x16, sxtx]
   20080:      	b	0xd29bc0 <_mech_canonical_program_entry_v1+0xd29bc0>
   20084:      	mov	x0, #0x321              ; =801
   20088:      	ldur	x1, [sp]
   2008c:      	str	x0, [x1, #0x48]
   20090:      	mov	w0, #0xd870             ; =55408
   20094:      	movk	w0, #0x2, lsl #16
   20098:      	mov	w16, #0xa8d8            ; =43224
   2009c:      	movk	w16, #0x1, lsl #16
   200a0:      	ldr	x1, [sp, x16, sxtx]
   200a4:      	ldr	x0, [x1, x0]
   200a8:      	cmp	x0, #0x0
   200ac:      	b.ne	0x200e8 <_mech_canonical_program_entry_v1+0x200e8>
   200b0:      	mov	x1, #0x321              ; =801
   200b4:      	mov	w16, #0xa8c8            ; =43208
   200b8:      	movk	w16, #0x1, lsl #16
   200bc:      	ldr	x2, [sp, x16, sxtx]
   200c0:      	mov	w16, #0xa8d0            ; =43216
   200c4:      	movk	w16, #0x1, lsl #16
   200c8:      	ldr	x0, [sp, x16, sxtx]
   200cc:      	blr	x2
   200d0:      	mov	x1, #0x2                ; =2
   200d4:      	mov	w16, #0x3af0            ; =15088
   200d8:      	movk	w16, #0x1, lsl #16
   200dc:      	str	x1, [sp, x16, sxtx]
   200e0:      	cmp	x0, #0x0
   200e4:      	b.ne	0xf164c <_mech_canonical_program_entry_v1+0xf164c>
   200e8:      	mov	x4, #0x322              ; =802
   200ec:      	ldur	x0, [sp]
   200f0:      	str	x4, [x0, #0x48]
   200f4:      	mov	w4, #0xd870             ; =55408
   200f8:      	movk	w4, #0x2, lsl #16
   200fc:      	mov	w16, #0xa8d8            ; =43224
   20100:      	movk	w16, #0x1, lsl #16
   20104:      	ldr	x0, [sp, x16, sxtx]
   20108:      	ldr	x7, [x0, x4]
   2010c:      	cmp	x7, #0x0
   20110:      	b.ne	0x2015c <_mech_canonical_program_entry_v1+0x2015c>
   20114:      	mov	x1, #0x322              ; =802
   20118:      	mov	w16, #0xa8c8            ; =43208
   2011c:      	movk	w16, #0x1, lsl #16
   20120:      	ldr	x2, [sp, x16, sxtx]
   20124:      	mov	w16, #0xa8d0            ; =43216
   20128:      	movk	w16, #0x1, lsl #16
   2012c:      	ldr	x0, [sp, x16, sxtx]
   20130:      	blr	x2
   20134:      	mov	x3, #0x2                ; =2
   20138:      	mov	w16, #0x3af0            ; =15088
   2013c:      	movk	w16, #0x1, lsl #16
   20140:      	str	x3, [sp, x16, sxtx]
   20144:      	cmp	x0, #0x0
   20148:      	b.ne	0xf1650 <_mech_canonical_program_entry_v1+0xf1650>
   2014c:      	mov	w16, #0xa8d8            ; =43224
   20150:      	movk	w16, #0x1, lsl #16
   20154:      	ldr	x0, [sp, x16, sxtx]
   20158:      	b	0x20168 <_mech_canonical_program_entry_v1+0x20168>
   2015c:      	mov	w16, #0xa8d8            ; =43224
   20160:      	movk	w16, #0x1, lsl #16
   20164:      	ldr	x0, [sp, x16, sxtx]
   20168:      	mov	w16, #0xa8d8            ; =43224
   2016c:      	movk	w16, #0x1, lsl #16
   20170:      	ldr	x0, [sp, x16, sxtx]
   20174:      	ldr	x12, [x0, #0x218]
   20178:      	str	x12, [x0, #0x1af8]
   2017c:      	b	0x20528 <_mech_canonical_program_entry_v1+0x20528>
   20180:      	mov	x14, #0x31b             ; =795
   20184:      	ldur	x0, [sp]
   20188:      	str	x14, [x0, #0x48]
   2018c:      	mov	w14, #0xd870            ; =55408
   20190:      	movk	w14, #0x2, lsl #16
   20194:      	mov	w16, #0xa8d8            ; =43224
   20198:      	movk	w16, #0x1, lsl #16
   2019c:      	ldr	x0, [sp, x16, sxtx]
   201a0:      	ldr	x0, [x0, x14]
   201a4:      	cmp	x0, #0x0
   201a8:      	b.ne	0x201e4 <_mech_canonical_program_entry_v1+0x201e4>
   201ac:      	mov	x1, #0x31b              ; =795
   201b0:      	mov	w16, #0xa8c8            ; =43208
   201b4:      	movk	w16, #0x1, lsl #16
   201b8:      	ldr	x2, [sp, x16, sxtx]
   201bc:      	mov	w16, #0xa8d0            ; =43216
   201c0:      	movk	w16, #0x1, lsl #16
   201c4:      	ldr	x0, [sp, x16, sxtx]
   201c8:      	blr	x2
   201cc:      	mov	x1, #0x2                ; =2
   201d0:      	mov	w16, #0x3af0            ; =15088
   201d4:      	movk	w16, #0x1, lsl #16
   201d8:      	str	x1, [sp, x16, sxtx]
   201dc:      	cmp	x0, #0x0
   201e0:      	b.ne	0xf1654 <_mech_canonical_program_entry_v1+0xf1654>
   201e4:      	mov	x1, #0x31c              ; =796
   201e8:      	ldur	x0, [sp]
   201ec:      	str	x1, [x0, #0x48]
   201f0:      	mov	w0, #0xd870             ; =55408
   201f4:      	movk	w0, #0x2, lsl #16
   201f8:      	mov	w16, #0xa8d8            ; =43224
   201fc:      	movk	w16, #0x1, lsl #16
   20200:      	ldr	x2, [sp, x16, sxtx]
   20204:      	ldr	x0, [x2, x0]
   20208:      	cmp	x0, #0x0
   2020c:      	b.ne	0x20254 <_mech_canonical_program_entry_v1+0x20254>
   20210:      	mov	w16, #0xa8c8            ; =43208
   20214:      	movk	w16, #0x1, lsl #16
   20218:      	ldr	x2, [sp, x16, sxtx]
   2021c:      	mov	w16, #0xa8d0            ; =43216
   20220:      	movk	w16, #0x1, lsl #16
   20224:      	ldr	x0, [sp, x16, sxtx]
   20228:      	blr	x2
   2022c:      	mov	x1, #0x2                ; =2
   20230:      	mov	w16, #0x3af0            ; =15088
   20234:      	movk	w16, #0x1, lsl #16
   20238:      	str	x1, [sp, x16, sxtx]
   2023c:      	cmp	x0, #0x0
   20240:      	b.ne	0xf2990 <_mech_canonical_program_entry_v1+0xf2990>
   20244:      	mov	w16, #0xa8d8            ; =43224
   20248:      	movk	w16, #0x1, lsl #16
   2024c:      	ldr	x0, [sp, x16, sxtx]
   20250:      	b	0x20260 <_mech_canonical_program_entry_v1+0x20260>
   20254:      	mov	w16, #0xa8d8            ; =43224
   20258:      	movk	w16, #0x1, lsl #16
   2025c:      	ldr	x0, [sp, x16, sxtx]
   20260:      	mov	w16, #0xa8d8            ; =43224
   20264:      	movk	w16, #0x1, lsl #16
   20268:      	ldr	x0, [sp, x16, sxtx]
   2026c:      	ldr	x0, [x0, #0x1ac0]
   20270:      	mov	w16, #0xa8d8            ; =43224
   20274:      	movk	w16, #0x1, lsl #16
   20278:      	ldr	x1, [sp, x16, sxtx]
   2027c:      	ldr	x1, [x1, #0x278]
   20280:      	adds	x0, x0, x1
   20284:      	cset	x1, hs
   20288:      	mov	x2, #0x1                ; =1
   2028c:      	mov	w16, #0x3af0            ; =15088
   20290:      	movk	w16, #0x1, lsl #16
   20294:      	str	x2, [sp, x16, sxtx]
   20298:      	uxtb	w1, w1
   2029c:      	cmp	w1, #0x0
   202a0:      	b.ne	0xf2b38 <_mech_canonical_program_entry_v1+0xf2b38>
   202a4:      	mov	w16, #0xa8d8            ; =43224
   202a8:      	movk	w16, #0x1, lsl #16
   202ac:      	ldr	x1, [sp, x16, sxtx]
   202b0:      	str	x0, [x1, #0x1b00]
   202b4:      	mov	x1, #0x31d              ; =797
   202b8:      	ldur	x0, [sp]
   202bc:      	str	x1, [x0, #0x48]
   202c0:      	mov	x19, x1
   202c4:      	mov	w0, #0xd870             ; =55408
   202c8:      	movk	w0, #0x2, lsl #16
   202cc:      	mov	w16, #0xa8d8            ; =43224
   202d0:      	movk	w16, #0x1, lsl #16
   202d4:      	ldr	x1, [sp, x16, sxtx]
   202d8:      	ldr	x0, [x1, x0]
   202dc:      	cmp	x0, #0x0
   202e0:      	b.ne	0x2031c <_mech_canonical_program_entry_v1+0x2031c>
   202e4:      	mov	w16, #0xa8c8            ; =43208
   202e8:      	movk	w16, #0x1, lsl #16
   202ec:      	ldr	x14, [sp, x16, sxtx]
   202f0:      	mov	w16, #0xa8d0            ; =43216
   202f4:      	movk	w16, #0x1, lsl #16
   202f8:      	ldr	x0, [sp, x16, sxtx]
   202fc:      	mov	x1, x19
   20300:      	blr	x14
   20304:      	mov	x2, #0x2                ; =2
   20308:      	mov	w16, #0x3af0            ; =15088
   2030c:      	movk	w16, #0x1, lsl #16
   20310:      	str	x2, [sp, x16, sxtx]
   20314:      	cmp	x0, #0x0
   20318:      	b.ne	0xf2bf0 <_mech_canonical_program_entry_v1+0xf2bf0>
   2031c:      	mov	x0, #0x3                ; =3
   20320:      	mov	w16, #0x3af0            ; =15088
   20324:      	movk	w16, #0x1, lsl #16
   20328:      	str	x0, [sp, x16, sxtx]
   2032c:      	mov	w16, #0xa8a8            ; =43176
   20330:      	movk	w16, #0x1, lsl #16
   20334:      	ldr	x0, [sp, x16, sxtx]
   20338:      	cmp	x0, #0x2
   2033c:      	b.lo	0xf2bf4 <_mech_canonical_program_entry_v1+0xf2bf4>
   20340:      	mov	x5, #0x0                ; =0
   20344:      	mov	w16, #0xa8b0            ; =43184
   20348:      	movk	w16, #0x1, lsl #16
   2034c:      	ldr	x0, [sp, x16, sxtx]
   20350:      	str	x5, [x0]
   20354:      	mov	w16, #0xa8d8            ; =43224
   20358:      	movk	w16, #0x1, lsl #16
   2035c:      	ldr	x0, [sp, x16, sxtx]
   20360:      	ldr	x0, [x0, #0x1b00]
   20364:      	mov	w16, #0xa8b0            ; =43184
   20368:      	movk	w16, #0x1, lsl #16
   2036c:      	ldr	x1, [sp, x16, sxtx]
   20370:      	str	x0, [x1, #0x8]
   20374:      	mov	x0, #0x2                ; =2
   20378:      	mov	x1, x19
   2037c:      	mov	w16, #0xa8c0            ; =43200
   20380:      	movk	w16, #0x1, lsl #16
   20384:      	ldr	x7, [sp, x16, sxtx]
   20388:      	mov	w16, #0x3af0            ; =15088
   2038c:      	movk	w16, #0x1, lsl #16
   20390:      	str	x0, [sp, x16, sxtx]
   20394:      	mov	w16, #0xa8d0            ; =43216
   20398:      	movk	w16, #0x1, lsl #16
   2039c:      	ldr	x0, [sp, x16, sxtx]
   203a0:      	mov	w16, #0xa8b0            ; =43184
   203a4:      	movk	w16, #0x1, lsl #16
   203a8:      	ldr	x3, [sp, x16, sxtx]
   203ac:      	mov	w16, #0x3af0            ; =15088
   203b0:      	movk	w16, #0x1, lsl #16
   203b4:      	ldr	x4, [sp, x16, sxtx]
   203b8:      	mov	w16, #0xa8b8            ; =43192
   203bc:      	movk	w16, #0x1, lsl #16
   203c0:      	ldr	x6, [sp, x16, sxtx]
   203c4:      	mov	x2, x5
   203c8:      	blr	x7
   203cc:      	cmp	x0, #0x0
   203d0:      	b.ne	0xf2c3c <_mech_canonical_program_entry_v1+0xf2c3c>
   203d4:      	mov	w16, #0xa8b8            ; =43192
   203d8:      	movk	w16, #0x1, lsl #16
   203dc:      	ldr	x6, [sp, x16, sxtx]
   203e0:      	ldr	x0, [x6]
   203e4:      	mov	w16, #0xa8d8            ; =43224
   203e8:      	movk	w16, #0x1, lsl #16
   203ec:      	ldr	x11, [sp, x16, sxtx]
   203f0:      	str	x0, [x11, #0x1b08]
   203f4:      	mov	x0, #0x31e              ; =798
   203f8:      	ldur	x1, [sp]
   203fc:      	str	x0, [x1, #0x48]
   20400:      	mov	w0, #0xd870             ; =55408
   20404:      	movk	w0, #0x2, lsl #16
   20408:      	mov	w16, #0xa8d8            ; =43224
   2040c:      	movk	w16, #0x1, lsl #16
   20410:      	ldr	x1, [sp, x16, sxtx]
   20414:      	ldr	x0, [x1, x0]
   20418:      	cmp	x0, #0x0
   2041c:      	b.ne	0x20468 <_mech_canonical_program_entry_v1+0x20468>
   20420:      	mov	x1, #0x31e              ; =798
   20424:      	mov	w16, #0xa8c8            ; =43208
   20428:      	movk	w16, #0x1, lsl #16
   2042c:      	ldr	x2, [sp, x16, sxtx]
   20430:      	mov	w16, #0xa8d0            ; =43216
   20434:      	movk	w16, #0x1, lsl #16
   20438:      	ldr	x0, [sp, x16, sxtx]
   2043c:      	blr	x2
   20440:      	mov	x1, #0x2                ; =2
   20444:      	mov	w16, #0x3af0            ; =15088
   20448:      	movk	w16, #0x1, lsl #16
   2044c:      	str	x1, [sp, x16, sxtx]
   20450:      	cmp	x0, #0x0
   20454:      	b.ne	0xf2c40 <_mech_canonical_program_entry_v1+0xf2c40>
   20458:      	mov	w16, #0xa8d8            ; =43224
   2045c:      	movk	w16, #0x1, lsl #16
   20460:      	ldr	x0, [sp, x16, sxtx]
   20464:      	b	0x20474 <_mech_canonical_program_entry_v1+0x20474>
   20468:      	mov	w16, #0xa8d8            ; =43224
   2046c:      	movk	w16, #0x1, lsl #16
   20470:      	ldr	x0, [sp, x16, sxtx]
   20474:      	mov	w16, #0xa8d8            ; =43224
   20478:      	movk	w16, #0x1, lsl #16
   2047c:      	ldr	x0, [sp, x16, sxtx]
   20480:      	ldr	x0, [x0, #0x1b08]
   20484:      	mov	w16, #0xa8d8            ; =43224
   20488:      	movk	w16, #0x1, lsl #16
   2048c:      	ldr	x1, [sp, x16, sxtx]
   20490:      	str	x0, [x1, #0x1b10]
   20494:      	mov	x1, #0x31f              ; =799
   20498:      	ldur	x0, [sp]
   2049c:      	str	x1, [x0, #0x48]
   204a0:      	mov	w1, #0xd870             ; =55408
   204a4:      	movk	w1, #0x2, lsl #16
   204a8:      	mov	w16, #0xa8d8            ; =43224
   204ac:      	movk	w16, #0x1, lsl #16
   204b0:      	ldr	x0, [sp, x16, sxtx]
   204b4:      	ldr	x4, [x0, x1]
   204b8:      	cmp	x4, #0x0
   204bc:      	b.ne	0x20508 <_mech_canonical_program_entry_v1+0x20508>
   204c0:      	mov	x1, #0x31f              ; =799
   204c4:      	mov	w16, #0xa8c8            ; =43208
   204c8:      	movk	w16, #0x1, lsl #16
   204cc:      	ldr	x2, [sp, x16, sxtx]
   204d0:      	mov	w16, #0xa8d0            ; =43216
   204d4:      	movk	w16, #0x1, lsl #16
   204d8:      	ldr	x0, [sp, x16, sxtx]
   204dc:      	blr	x2
   204e0:      	mov	x1, #0x2                ; =2
   204e4:      	mov	w16, #0x3af0            ; =15088
   204e8:      	movk	w16, #0x1, lsl #16
   204ec:      	str	x1, [sp, x16, sxtx]
   204f0:      	cmp	x0, #0x0
   204f4:      	b.ne	0xf2d7c <_mech_canonical_program_entry_v1+0xf2d7c>
   204f8:      	mov	w16, #0xa8d8            ; =43224
   204fc:      	movk	w16, #0x1, lsl #16
   20500:      	ldr	x0, [sp, x16, sxtx]
   20504:      	b	0x20514 <_mech_canonical_program_entry_v1+0x20514>
   20508:      	mov	w16, #0xa8d8            ; =43224
   2050c:      	movk	w16, #0x1, lsl #16
   20510:      	ldr	x0, [sp, x16, sxtx]
   20514:      	mov	w16, #0xa8d8            ; =43224
   20518:      	movk	w16, #0x1, lsl #16
   2051c:      	ldr	x0, [sp, x16, sxtx]
   20520:      	ldr	x9, [x0, #0x1b10]
   20524:      	str	x9, [x0, #0x1af8]
   20528:      	mov	x11, #0x319             ; =793
   2052c:      	ldur	x0, [sp]
   20530:      	str	x11, [x0, #0x48]
   20534:      	mov	w11, #0xd870            ; =55408
   20538:      	movk	w11, #0x2, lsl #16
   2053c:      	mov	w16, #0xa8d8            ; =43224
   20540:      	movk	w16, #0x1, lsl #16
   20544:      	ldr	x0, [sp, x16, sxtx]
   20548:      	ldr	x14, [x0, x11]
   2054c:      	cmp	x14, #0x0
   20550:      	b.ne	0x2058c <_mech_canonical_program_entry_v1+0x2058c>
   20554:      	mov	x1, #0x319              ; =793
   20558:      	mov	w16, #0xa8c8            ; =43208
   2055c:      	movk	w16, #0x1, lsl #16
   20560:      	ldr	x2, [sp, x16, sxtx]
   20564:      	mov	w16, #0xa8d0            ; =43216
   20568:      	movk	w16, #0x1, lsl #16
   2056c:      	ldr	x0, [sp, x16, sxtx]
   20570:      	blr	x2
   20574:      	mov	x11, #0x2               ; =2
   20578:      	mov	w16, #0x3af0            ; =15088
   2057c:      	movk	w16, #0x1, lsl #16
   20580:      	str	x11, [sp, x16, sxtx]
   20584:      	cmp	x0, #0x0
   20588:      	b.ne	0xf2dd4 <_mech_canonical_program_entry_v1+0xf2dd4>
   2058c:      	mov	x1, #0x323              ; =803
   20590:      	ldur	x0, [sp]
   20594:      	str	x1, [x0, #0x48]
   20598:      	mov	w0, #0xd870             ; =55408
   2059c:      	movk	w0, #0x2, lsl #16
   205a0:      	mov	w16, #0xa8d8            ; =43224
   205a4:      	movk	w16, #0x1, lsl #16
   205a8:      	ldr	x14, [sp, x16, sxtx]
   205ac:      	ldr	x0, [x14, x0]
   205b0:      	cmp	x0, #0x0
   205b4:      	b.ne	0x205fc <_mech_canonical_program_entry_v1+0x205fc>

; Anchor 0x2198c
   2168c:      	str	x8, [sp, x16, sxtx]
   21690:      	cmp	x0, #0x0
   21694:      	b.ne	0xf3994 <_mech_canonical_program_entry_v1+0xf3994>
   21698:      	mov	w16, #0xa8d8            ; =43224
   2169c:      	movk	w16, #0x1, lsl #16
   216a0:      	ldr	x0, [sp, x16, sxtx]
   216a4:      	mov	w16, #0xa8d8            ; =43224
   216a8:      	movk	w16, #0x1, lsl #16
   216ac:      	ldr	x0, [sp, x16, sxtx]
   216b0:      	ldr	x1, [x0, #0x1b48]
   216b4:      	str	x1, [x0, #0x1b30]
   216b8:      	b	0x217b0 <_mech_canonical_program_entry_v1+0x217b0>
   216bc:      	mov	x3, #0x32f              ; =815
   216c0:      	ldur	x0, [sp]
   216c4:      	str	x3, [x0, #0x48]
   216c8:      	mov	w16, #0xa8b8            ; =43192
   216cc:      	movk	w16, #0x1, lsl #16
   216d0:      	ldr	x6, [sp, x16, sxtx]
   216d4:      	ldr	x4, [x6]
   216d8:      	cmp	x4, #0x0
   216dc:      	b.ne	0x21718 <_mech_canonical_program_entry_v1+0x21718>
   216e0:      	mov	x1, #0x32f              ; =815
   216e4:      	mov	w16, #0xa8c8            ; =43208
   216e8:      	movk	w16, #0x1, lsl #16
   216ec:      	ldr	x2, [sp, x16, sxtx]
   216f0:      	mov	w16, #0xa8d0            ; =43216
   216f4:      	movk	w16, #0x1, lsl #16
   216f8:      	ldr	x0, [sp, x16, sxtx]
   216fc:      	blr	x2
   21700:      	mov	x1, #0x2                ; =2
   21704:      	mov	w16, #0x3af0            ; =15088
   21708:      	movk	w16, #0x1, lsl #16
   2170c:      	str	x1, [sp, x16, sxtx]
   21710:      	cmp	x0, #0x0
   21714:      	b.ne	0xf3998 <_mech_canonical_program_entry_v1+0xf3998>
   21718:      	mov	x12, #0x330             ; =816
   2171c:      	ldur	x0, [sp]
   21720:      	str	x12, [x0, #0x48]
   21724:      	mov	w16, #0xa8b8            ; =43192
   21728:      	movk	w16, #0x1, lsl #16
   2172c:      	ldr	x6, [sp, x16, sxtx]
   21730:      	ldr	x13, [x6]
   21734:      	cmp	x13, #0x0
   21738:      	b.eq	0x2174c <_mech_canonical_program_entry_v1+0x2174c>
   2173c:      	mov	w16, #0xa8d8            ; =43224
   21740:      	movk	w16, #0x1, lsl #16
   21744:      	ldr	x0, [sp, x16, sxtx]
   21748:      	b	0x21790 <_mech_canonical_program_entry_v1+0x21790>
   2174c:      	mov	x1, #0x330              ; =816
   21750:      	mov	w16, #0xa8c8            ; =43208
   21754:      	movk	w16, #0x1, lsl #16
   21758:      	ldr	x2, [sp, x16, sxtx]
   2175c:      	mov	w16, #0xa8d0            ; =43216
   21760:      	movk	w16, #0x1, lsl #16
   21764:      	ldr	x0, [sp, x16, sxtx]
   21768:      	blr	x2
   2176c:      	mov	x1, #0x2                ; =2
   21770:      	mov	w16, #0x3af0            ; =15088
   21774:      	movk	w16, #0x1, lsl #16
   21778:      	str	x1, [sp, x16, sxtx]
   2177c:      	cmp	x0, #0x0
   21780:      	b.ne	0xf3a3c <_mech_canonical_program_entry_v1+0xf3a3c>
   21784:      	mov	w16, #0xa8d8            ; =43224
   21788:      	movk	w16, #0x1, lsl #16
   2178c:      	ldr	x0, [sp, x16, sxtx]
   21790:      	mov	w16, #0xa8d8            ; =43224
   21794:      	movk	w16, #0x1, lsl #16
   21798:      	ldr	x0, [sp, x16, sxtx]
   2179c:      	ldr	x0, [x0, #0x2a0]
   217a0:      	mov	w16, #0xa8d8            ; =43224
   217a4:      	movk	w16, #0x1, lsl #16
   217a8:      	ldr	x14, [sp, x16, sxtx]
   217ac:      	str	x0, [x14, #0x1b30]
   217b0:      	mov	x1, #0x32d              ; =813
   217b4:      	ldur	x0, [sp]
   217b8:      	str	x1, [x0, #0x48]
   217bc:      	mov	w16, #0xa8c8            ; =43208
   217c0:      	movk	w16, #0x1, lsl #16
   217c4:      	ldr	x2, [sp, x16, sxtx]
   217c8:      	mov	w16, #0xa8d0            ; =43216
   217cc:      	movk	w16, #0x1, lsl #16
   217d0:      	ldr	x0, [sp, x16, sxtx]
   217d4:      	blr	x2
   217d8:      	mov	x1, #0x2                ; =2
   217dc:      	mov	w16, #0x3af0            ; =15088
   217e0:      	movk	w16, #0x1, lsl #16
   217e4:      	str	x1, [sp, x16, sxtx]
   217e8:      	cmp	x0, #0x0
   217ec:      	b.ne	0xf3a84 <_mech_canonical_program_entry_v1+0xf3a84>
   217f0:      	mov	x0, #0x341              ; =833
   217f4:      	ldur	x1, [sp]
   217f8:      	str	x0, [x1, #0x48]
   217fc:      	mov	w16, #0xa8b8            ; =43192
   21800:      	movk	w16, #0x1, lsl #16
   21804:      	ldr	x6, [sp, x16, sxtx]
   21808:      	ldr	x0, [x6]
   2180c:      	cmp	x0, #0x0
   21810:      	b.eq	0x21824 <_mech_canonical_program_entry_v1+0x21824>
   21814:      	mov	w16, #0xa8d8            ; =43224
   21818:      	movk	w16, #0x1, lsl #16
   2181c:      	ldr	x0, [sp, x16, sxtx]
   21820:      	b	0x21868 <_mech_canonical_program_entry_v1+0x21868>
   21824:      	mov	x1, #0x341              ; =833
   21828:      	mov	w16, #0xa8c8            ; =43208
   2182c:      	movk	w16, #0x1, lsl #16
   21830:      	ldr	x2, [sp, x16, sxtx]
   21834:      	mov	w16, #0xa8d0            ; =43216
   21838:      	movk	w16, #0x1, lsl #16
   2183c:      	ldr	x0, [sp, x16, sxtx]
   21840:      	blr	x2
   21844:      	mov	x3, #0x2                ; =2
   21848:      	mov	w16, #0x3af0            ; =15088
   2184c:      	movk	w16, #0x1, lsl #16
   21850:      	str	x3, [sp, x16, sxtx]
   21854:      	cmp	x0, #0x0
   21858:      	b.ne	0xf3a88 <_mech_canonical_program_entry_v1+0xf3a88>
   2185c:      	mov	w16, #0xa8d8            ; =43224
   21860:      	movk	w16, #0x1, lsl #16
   21864:      	ldr	x0, [sp, x16, sxtx]
   21868:      	mov	w16, #0xa8d8            ; =43224
   2186c:      	movk	w16, #0x1, lsl #16
   21870:      	ldr	x0, [sp, x16, sxtx]
   21874:      	ldr	x0, [x0, #0x1b30]
   21878:      	mov	w16, #0xa8d8            ; =43224
   2187c:      	movk	w16, #0x1, lsl #16
   21880:      	ldr	x1, [sp, x16, sxtx]
   21884:      	str	x0, [x1, #0x1990]
   21888:      	b	0x21cd8 <_mech_canonical_program_entry_v1+0x21cd8>
   2188c:      	mov	w16, #0xa6d8            ; =42712
   21890:      	movk	w16, #0x1, lsl #16
   21894:      	str	x15, [sp, x16, sxtx]
   21898:      	mov	x14, #0x1               ; =1
   2189c:      	adds	x15, x12, x14
   218a0:      	cset	x14, hs
   218a4:      	uxtb	w14, w14
   218a8:      	cmp	w14, #0x0
   218ac:      	b.ne	0xf3a8c <_mech_canonical_program_entry_v1+0xf3a8c>
   218b0:      	cmp	x12, x0
   218b4:      	cset	x25, lo
   218b8:      	cmp	x12, x0
   218bc:      	b.lo	0x218d4 <_mech_canonical_program_entry_v1+0x218d4>
   218c0:      	cmp	x12, x0
   218c4:      	b.lo	0xf3b3c <_mech_canonical_program_entry_v1+0xf3b3c>
   218c8:      	mov	x13, #0x0               ; =0
   218cc:      	mov	x14, x7
   218d0:      	b	0x21ac8 <_mech_canonical_program_entry_v1+0x21ac8>
   218d4:      	mov	x14, #0x1               ; =1
   218d8:      	adds	x14, x12, x14
   218dc:      	cset	x26, hs
   218e0:      	uxtb	w26, w26
   218e4:      	cmp	w26, #0x0
   218e8:      	b.ne	0xf3b40 <_mech_canonical_program_entry_v1+0xf3b40>
   218ec:      	sub	x20, x14, #0x1
   218f0:      	cmp	x20, x0
   218f4:      	b.lo	0x21ab0 <_mech_canonical_program_entry_v1+0x21ab0>
   218f8:      	b	0x937b4c <_mech_canonical_program_entry_v1+0x937b4c>
   218fc:      	mov	x0, #0x0                ; =0
   21900:      	mov	w1, #0xd870             ; =55408
   21904:      	movk	w1, #0x2, lsl #16
   21908:      	mov	w16, #0xa8d8            ; =43224
   2190c:      	movk	w16, #0x1, lsl #16
   21910:      	ldr	x2, [sp, x16, sxtx]
   21914:      	str	x0, [x2, x1]
   21918:      	mov	x0, #0x3                ; =3
   2191c:      	mov	w16, #0x3af0            ; =15088
   21920:      	movk	w16, #0x1, lsl #16
   21924:      	str	x0, [sp, x16, sxtx]
   21928:      	mov	w16, #0xa8a8            ; =43176
   2192c:      	movk	w16, #0x1, lsl #16
   21930:      	ldr	x0, [sp, x16, sxtx]
   21934:      	cmp	x0, #0xc
   21938:      	b.lo	0xf3b44 <_mech_canonical_program_entry_v1+0xf3b44>
   2193c:      	mov	w0, #0xee78             ; =61048
   21940:      	movk	w0, #0x2, lsl #16
   21944:      	mov	w16, #0xa8d8            ; =43224
   21948:      	movk	w16, #0x1, lsl #16
   2194c:      	ldr	x8, [sp, x16, sxtx]
   21950:      	ldr	x0, [x8, x0]
   21954:      	mov	w16, #0xa8b0            ; =43184
   21958:      	movk	w16, #0x1, lsl #16
   2195c:      	ldr	x8, [sp, x16, sxtx]
   21960:      	str	x0, [x8, #0x10]
   21964:      	mov	w0, #0xee80             ; =61056
   21968:      	movk	w0, #0x2, lsl #16
   2196c:      	mov	w16, #0xa8d8            ; =43224
   21970:      	movk	w16, #0x1, lsl #16
   21974:      	ldr	x13, [sp, x16, sxtx]
   21978:      	ldr	x0, [x13, x0]
   2197c:      	mov	w16, #0xa8b0            ; =43184
   21980:      	movk	w16, #0x1, lsl #16
   21984:      	ldr	x13, [sp, x16, sxtx]
   21988:      	str	x0, [x13, #0x18]
   2198c:      	mov	x1, #0x31d              ; =797
   21990:      	mov	x2, #-0x9               ; =-9
   21994:      	mov	x0, #0x2                ; =2
   21998:      	mov	w16, #0xa8c0            ; =43200
   2199c:      	movk	w16, #0x1, lsl #16
   219a0:      	ldr	x7, [sp, x16, sxtx]
   219a4:      	mov	w16, #0x3af0            ; =15088
   219a8:      	movk	w16, #0x1, lsl #16
   219ac:      	str	x0, [sp, x16, sxtx]
   219b0:      	mov	w16, #0xa8d0            ; =43216
   219b4:      	movk	w16, #0x1, lsl #16
   219b8:      	ldr	x0, [sp, x16, sxtx]
   219bc:      	mov	w16, #0x3af0            ; =15088
   219c0:      	movk	w16, #0x1, lsl #16
   219c4:      	ldr	x5, [sp, x16, sxtx]
   219c8:      	mov	w16, #0xa8b8            ; =43192
   219cc:      	movk	w16, #0x1, lsl #16
   219d0:      	ldr	x6, [sp, x16, sxtx]
   219d4:      	blr	x7
   219d8:      	cmp	x0, #0x0
   219dc:      	b.ne	0xf3c10 <_mech_canonical_program_entry_v1+0xf3c10>
   219e0:      	mov	x0, #0x3                ; =3
   219e4:      	mov	w16, #0x3af0            ; =15088
   219e8:      	movk	w16, #0x1, lsl #16
   219ec:      	str	x0, [sp, x16, sxtx]
   219f0:      	mov	w16, #0xa8a8            ; =43176
   219f4:      	movk	w16, #0x1, lsl #16
   219f8:      	ldr	x0, [sp, x16, sxtx]
   219fc:      	cmp	x0, #0x2
   21a00:      	b.lo	0xf3c4c <_mech_canonical_program_entry_v1+0xf3c4c>
   21a04:      	mov	x5, #0x0                ; =0
   21a08:      	mov	w16, #0xa8b0            ; =43184
   21a0c:      	movk	w16, #0x1, lsl #16
   21a10:      	ldr	x0, [sp, x16, sxtx]
   21a14:      	str	x5, [x0]
   21a18:      	mov	w16, #0xa8d8            ; =43224
   21a1c:      	movk	w16, #0x1, lsl #16
   21a20:      	ldr	x0, [sp, x16, sxtx]
   21a24:      	ldr	x0, [x0, #0x1b00]
   21a28:      	mov	w16, #0xa8b0            ; =43184
   21a2c:      	movk	w16, #0x1, lsl #16
   21a30:      	ldr	x1, [sp, x16, sxtx]
   21a34:      	str	x0, [x1, #0x8]
   21a38:      	mov	x1, #0x31d              ; =797
   21a3c:      	mov	x0, #0x2                ; =2
   21a40:      	mov	w16, #0xa8c0            ; =43200
   21a44:      	movk	w16, #0x1, lsl #16
   21a48:      	ldr	x7, [sp, x16, sxtx]
   21a4c:      	mov	w16, #0x3af0            ; =15088
   21a50:      	movk	w16, #0x1, lsl #16
   21a54:      	str	x0, [sp, x16, sxtx]
   21a58:      	mov	w16, #0xa8d0            ; =43216
   21a5c:      	movk	w16, #0x1, lsl #16
   21a60:      	ldr	x0, [sp, x16, sxtx]
   21a64:      	mov	w16, #0xa8b0            ; =43184
   21a68:      	movk	w16, #0x1, lsl #16
   21a6c:      	ldr	x3, [sp, x16, sxtx]
   21a70:      	mov	w16, #0x3af0            ; =15088
   21a74:      	movk	w16, #0x1, lsl #16
   21a78:      	ldr	x4, [sp, x16, sxtx]
   21a7c:      	mov	w16, #0xa8b8            ; =43192
   21a80:      	movk	w16, #0x1, lsl #16
   21a84:      	ldr	x6, [sp, x16, sxtx]
   21a88:      	mov	x2, x5
   21a8c:      	blr	x7
   21a90:      	cmp	x0, #0x0
   21a94:      	b.ne	0xf3c50 <_mech_canonical_program_entry_v1+0xf3c50>
   21a98:      	mov	x0, #0x3                ; =3
   21a9c:      	mov	w16, #0x3af0            ; =15088
   21aa0:      	movk	w16, #0x1, lsl #16
   21aa4:      	str	x0, [sp, x16, sxtx]
   21aa8:      	ldur	x0, [sp]
   21aac:      	b	0xd29bc0 <_mech_canonical_program_entry_v1+0xd29bc0>
   21ab0:      	ldrb	w10, [x1, x20]
   21ab4:      	uxtb	w13, w10
   21ab8:      	mov	x20, x14
   21abc:      	mov	x14, x7
   21ac0:      	mov	x11, x13
   21ac4:      	mov	x10, x13
   21ac8:      	adds	x26, x14, x13
   21acc:      	cset	x27, hs
   21ad0:      	uxtb	w27, w27
   21ad4:      	cmp	w27, #0x0
   21ad8:      	b.ne	0xf3c54 <_mech_canonical_program_entry_v1+0xf3c54>
   21adc:      	mov	x5, #0x6d30             ; =27952
   21ae0:      	sub	x19, x19, x5
   21ae4:      	uxtb	w28, w28
   21ae8:      	uxtb	w25, w25
   21aec:      	mov	w16, #0xa6f0            ; =42736
   21af0:      	movk	w16, #0x1, lsl #16
   21af4:      	str	x3, [sp, x16, sxtx]
   21af8:      	mov	w16, #0xa6e8            ; =42728
   21afc:      	movk	w16, #0x1, lsl #16
   21b00:      	str	x4, [sp, x16, sxtx]
   21b04:      	str	x26, [sp, #0x340]
   21b08:      	str	x15, [sp, #0x338]
   21b0c:      	mov	x27, x15
   21b10:      	mov	x9, x26
   21b14:      	mov	x7, x26
   21b18:      	mov	x6, x15
   21b1c:      	mov	x5, x26
   21b20:      	mov	x26, x0
   21b24:      	mov	x3, x12
   21b28:      	mov	x12, x15
   21b2c:      	mov	w16, #0xa6e0            ; =42720
   21b30:      	movk	w16, #0x1, lsl #16
   21b34:      	ldr	x15, [sp, x16, sxtx]
   21b38:      	b	0x1ef2c <_mech_canonical_program_entry_v1+0x1ef2c>
   21b3c:      	str	x5, [sp, #0x328]
   21b40:      	ldr	x26, [sp, #0x2f8]
   21b44:      	ldr	x19, [sp, #0x300]
   21b48:      	ldr	x15, [sp, #0x308]
   21b4c:      	mov	w16, #0xa6f8            ; =42744
   21b50:      	movk	w16, #0x1, lsl #16
   21b54:      	ldr	x12, [sp, x16, sxtx]
   21b58:      	ldr	x10, [sp, #0x2e0]
   21b5c:      	ldr	x8, [sp, #0x310]
   21b60:      	ldr	x6, [sp, #0x2c8]
   21b64:      	ldr	x5, [sp, #0x2e8]
   21b68:      	ldr	x1, [sp, #0x2d0]
   21b6c:      	ldr	x0, [sp, #0x2f0]
   21b70:      	mov	x13, #0x1               ; =1
   21b74:      	adds	x13, x28, x13
   21b78:      	cset	x14, hs
   21b7c:      	uxtb	w14, w14
   21b80:      	cmp	w14, #0x0
   21b84:      	b.ne	0xf3d0c <_mech_canonical_program_entry_v1+0xf3d0c>
   21b88:      	mov	w16, #0xa710            ; =42768
   21b8c:      	movk	w16, #0x1, lsl #16
   21b90:      	ldr	x10, [sp, x16, sxtx]
   21b94:      	uxtb	w8, w12
   21b98:      	uxtb	w9, w9
   21b9c:      	str	x24, [sp, #0x318]
   21ba0:      	str	x13, [sp, #0x310]
   21ba4:      	str	x27, [sp, #0x300]
   21ba8:      	str	x13, [sp, #0x2f8]
   21bac:      	str	x23, [sp, #0x2f0]
   21bb0:      	str	x27, [sp, #0x2e8]
   21bb4:      	mov	x19, x27
   21bb8:      	mov	x15, x23
   21bbc:      	mov	x14, x28
   21bc0:      	mov	x28, x13
   21bc4:      	mov	x12, x13
   21bc8:      	mov	x13, x6
   21bcc:      	mov	x6, x10
   21bd0:      	mov	x10, x23
   21bd4:      	mov	x5, x1
   21bd8:      	ldr	x1, [sp, #0x320]
   21bdc:      	ldr	x0, [sp, #0x2d8]
   21be0:      	b	0x1ba38 <_mech_canonical_program_entry_v1+0x1ba38>
   21be4:      	mov	x0, #0x2b8              ; =696
   21be8:      	ldur	x1, [sp]
   21bec:      	str	x0, [x1, #0x48]
   21bf0:      	mov	w16, #0xa8b8            ; =43192
   21bf4:      	movk	w16, #0x1, lsl #16
   21bf8:      	ldr	x6, [sp, x16, sxtx]
   21bfc:      	ldr	x0, [x6]
   21c00:      	cmp	x0, #0x0
   21c04:      	b.ne	0x21c40 <_mech_canonical_program_entry_v1+0x21c40>
   21c08:      	mov	x1, #0x2b8              ; =696
   21c0c:      	mov	w16, #0xa8c8            ; =43208
   21c10:      	movk	w16, #0x1, lsl #16
   21c14:      	ldr	x2, [sp, x16, sxtx]
   21c18:      	mov	w16, #0xa8d0            ; =43216
   21c1c:      	movk	w16, #0x1, lsl #16
   21c20:      	ldr	x0, [sp, x16, sxtx]
   21c24:      	blr	x2
   21c28:      	mov	x1, #0x2                ; =2
   21c2c:      	mov	w16, #0x3af0            ; =15088
   21c30:      	movk	w16, #0x1, lsl #16
   21c34:      	str	x1, [sp, x16, sxtx]
   21c38:      	cmp	x0, #0x0
   21c3c:      	b.ne	0xf3d54 <_mech_canonical_program_entry_v1+0xf3d54>
   21c40:      	mov	x0, #0x2b9              ; =697
   21c44:      	ldur	x1, [sp]
   21c48:      	str	x0, [x1, #0x48]
   21c4c:      	mov	w16, #0xa8b8            ; =43192
   21c50:      	movk	w16, #0x1, lsl #16
   21c54:      	ldr	x6, [sp, x16, sxtx]
   21c58:      	ldr	x0, [x6]
   21c5c:      	cmp	x0, #0x0
   21c60:      	b.eq	0x21c74 <_mech_canonical_program_entry_v1+0x21c74>
   21c64:      	mov	w16, #0xa8d8            ; =43224
   21c68:      	movk	w16, #0x1, lsl #16
   21c6c:      	ldr	x0, [sp, x16, sxtx]
   21c70:      	b	0x21cb8 <_mech_canonical_program_entry_v1+0x21cb8>
   21c74:      	mov	x1, #0x2b9              ; =697
   21c78:      	mov	w16, #0xa8c8            ; =43208
   21c7c:      	movk	w16, #0x1, lsl #16
   21c80:      	ldr	x2, [sp, x16, sxtx]
   21c84:      	mov	w16, #0xa8d0            ; =43216
   21c88:      	movk	w16, #0x1, lsl #16
   21c8c:      	ldr	x0, [sp, x16, sxtx]

; Anchor 0x21a38
   21738:      	b.eq	0x2174c <_mech_canonical_program_entry_v1+0x2174c>
   2173c:      	mov	w16, #0xa8d8            ; =43224
   21740:      	movk	w16, #0x1, lsl #16
   21744:      	ldr	x0, [sp, x16, sxtx]
   21748:      	b	0x21790 <_mech_canonical_program_entry_v1+0x21790>
   2174c:      	mov	x1, #0x330              ; =816
   21750:      	mov	w16, #0xa8c8            ; =43208
   21754:      	movk	w16, #0x1, lsl #16
   21758:      	ldr	x2, [sp, x16, sxtx]
   2175c:      	mov	w16, #0xa8d0            ; =43216
   21760:      	movk	w16, #0x1, lsl #16
   21764:      	ldr	x0, [sp, x16, sxtx]
   21768:      	blr	x2
   2176c:      	mov	x1, #0x2                ; =2
   21770:      	mov	w16, #0x3af0            ; =15088
   21774:      	movk	w16, #0x1, lsl #16
   21778:      	str	x1, [sp, x16, sxtx]
   2177c:      	cmp	x0, #0x0
   21780:      	b.ne	0xf3a3c <_mech_canonical_program_entry_v1+0xf3a3c>
   21784:      	mov	w16, #0xa8d8            ; =43224
   21788:      	movk	w16, #0x1, lsl #16
   2178c:      	ldr	x0, [sp, x16, sxtx]
   21790:      	mov	w16, #0xa8d8            ; =43224
   21794:      	movk	w16, #0x1, lsl #16
   21798:      	ldr	x0, [sp, x16, sxtx]
   2179c:      	ldr	x0, [x0, #0x2a0]
   217a0:      	mov	w16, #0xa8d8            ; =43224
   217a4:      	movk	w16, #0x1, lsl #16
   217a8:      	ldr	x14, [sp, x16, sxtx]
   217ac:      	str	x0, [x14, #0x1b30]
   217b0:      	mov	x1, #0x32d              ; =813
   217b4:      	ldur	x0, [sp]
   217b8:      	str	x1, [x0, #0x48]
   217bc:      	mov	w16, #0xa8c8            ; =43208
   217c0:      	movk	w16, #0x1, lsl #16
   217c4:      	ldr	x2, [sp, x16, sxtx]
   217c8:      	mov	w16, #0xa8d0            ; =43216
   217cc:      	movk	w16, #0x1, lsl #16
   217d0:      	ldr	x0, [sp, x16, sxtx]
   217d4:      	blr	x2
   217d8:      	mov	x1, #0x2                ; =2
   217dc:      	mov	w16, #0x3af0            ; =15088
   217e0:      	movk	w16, #0x1, lsl #16
   217e4:      	str	x1, [sp, x16, sxtx]
   217e8:      	cmp	x0, #0x0
   217ec:      	b.ne	0xf3a84 <_mech_canonical_program_entry_v1+0xf3a84>
   217f0:      	mov	x0, #0x341              ; =833
   217f4:      	ldur	x1, [sp]
   217f8:      	str	x0, [x1, #0x48]
   217fc:      	mov	w16, #0xa8b8            ; =43192
   21800:      	movk	w16, #0x1, lsl #16
   21804:      	ldr	x6, [sp, x16, sxtx]
   21808:      	ldr	x0, [x6]
   2180c:      	cmp	x0, #0x0
   21810:      	b.eq	0x21824 <_mech_canonical_program_entry_v1+0x21824>
   21814:      	mov	w16, #0xa8d8            ; =43224
   21818:      	movk	w16, #0x1, lsl #16
   2181c:      	ldr	x0, [sp, x16, sxtx]
   21820:      	b	0x21868 <_mech_canonical_program_entry_v1+0x21868>
   21824:      	mov	x1, #0x341              ; =833
   21828:      	mov	w16, #0xa8c8            ; =43208
   2182c:      	movk	w16, #0x1, lsl #16
   21830:      	ldr	x2, [sp, x16, sxtx]
   21834:      	mov	w16, #0xa8d0            ; =43216
   21838:      	movk	w16, #0x1, lsl #16
   2183c:      	ldr	x0, [sp, x16, sxtx]
   21840:      	blr	x2
   21844:      	mov	x3, #0x2                ; =2
   21848:      	mov	w16, #0x3af0            ; =15088
   2184c:      	movk	w16, #0x1, lsl #16
   21850:      	str	x3, [sp, x16, sxtx]
   21854:      	cmp	x0, #0x0
   21858:      	b.ne	0xf3a88 <_mech_canonical_program_entry_v1+0xf3a88>
   2185c:      	mov	w16, #0xa8d8            ; =43224
   21860:      	movk	w16, #0x1, lsl #16
   21864:      	ldr	x0, [sp, x16, sxtx]
   21868:      	mov	w16, #0xa8d8            ; =43224
   2186c:      	movk	w16, #0x1, lsl #16
   21870:      	ldr	x0, [sp, x16, sxtx]
   21874:      	ldr	x0, [x0, #0x1b30]
   21878:      	mov	w16, #0xa8d8            ; =43224
   2187c:      	movk	w16, #0x1, lsl #16
   21880:      	ldr	x1, [sp, x16, sxtx]
   21884:      	str	x0, [x1, #0x1990]
   21888:      	b	0x21cd8 <_mech_canonical_program_entry_v1+0x21cd8>
   2188c:      	mov	w16, #0xa6d8            ; =42712
   21890:      	movk	w16, #0x1, lsl #16
   21894:      	str	x15, [sp, x16, sxtx]
   21898:      	mov	x14, #0x1               ; =1
   2189c:      	adds	x15, x12, x14
   218a0:      	cset	x14, hs
   218a4:      	uxtb	w14, w14
   218a8:      	cmp	w14, #0x0
   218ac:      	b.ne	0xf3a8c <_mech_canonical_program_entry_v1+0xf3a8c>
   218b0:      	cmp	x12, x0
   218b4:      	cset	x25, lo
   218b8:      	cmp	x12, x0
   218bc:      	b.lo	0x218d4 <_mech_canonical_program_entry_v1+0x218d4>
   218c0:      	cmp	x12, x0
   218c4:      	b.lo	0xf3b3c <_mech_canonical_program_entry_v1+0xf3b3c>
   218c8:      	mov	x13, #0x0               ; =0
   218cc:      	mov	x14, x7
   218d0:      	b	0x21ac8 <_mech_canonical_program_entry_v1+0x21ac8>
   218d4:      	mov	x14, #0x1               ; =1
   218d8:      	adds	x14, x12, x14
   218dc:      	cset	x26, hs
   218e0:      	uxtb	w26, w26
   218e4:      	cmp	w26, #0x0
   218e8:      	b.ne	0xf3b40 <_mech_canonical_program_entry_v1+0xf3b40>
   218ec:      	sub	x20, x14, #0x1
   218f0:      	cmp	x20, x0
   218f4:      	b.lo	0x21ab0 <_mech_canonical_program_entry_v1+0x21ab0>
   218f8:      	b	0x937b4c <_mech_canonical_program_entry_v1+0x937b4c>
   218fc:      	mov	x0, #0x0                ; =0
   21900:      	mov	w1, #0xd870             ; =55408
   21904:      	movk	w1, #0x2, lsl #16
   21908:      	mov	w16, #0xa8d8            ; =43224
   2190c:      	movk	w16, #0x1, lsl #16
   21910:      	ldr	x2, [sp, x16, sxtx]
   21914:      	str	x0, [x2, x1]
   21918:      	mov	x0, #0x3                ; =3
   2191c:      	mov	w16, #0x3af0            ; =15088
   21920:      	movk	w16, #0x1, lsl #16
   21924:      	str	x0, [sp, x16, sxtx]
   21928:      	mov	w16, #0xa8a8            ; =43176
   2192c:      	movk	w16, #0x1, lsl #16
   21930:      	ldr	x0, [sp, x16, sxtx]
   21934:      	cmp	x0, #0xc
   21938:      	b.lo	0xf3b44 <_mech_canonical_program_entry_v1+0xf3b44>
   2193c:      	mov	w0, #0xee78             ; =61048
   21940:      	movk	w0, #0x2, lsl #16
   21944:      	mov	w16, #0xa8d8            ; =43224
   21948:      	movk	w16, #0x1, lsl #16
   2194c:      	ldr	x8, [sp, x16, sxtx]
   21950:      	ldr	x0, [x8, x0]
   21954:      	mov	w16, #0xa8b0            ; =43184
   21958:      	movk	w16, #0x1, lsl #16
   2195c:      	ldr	x8, [sp, x16, sxtx]
   21960:      	str	x0, [x8, #0x10]
   21964:      	mov	w0, #0xee80             ; =61056
   21968:      	movk	w0, #0x2, lsl #16
   2196c:      	mov	w16, #0xa8d8            ; =43224
   21970:      	movk	w16, #0x1, lsl #16
   21974:      	ldr	x13, [sp, x16, sxtx]
   21978:      	ldr	x0, [x13, x0]
   2197c:      	mov	w16, #0xa8b0            ; =43184
   21980:      	movk	w16, #0x1, lsl #16
   21984:      	ldr	x13, [sp, x16, sxtx]
   21988:      	str	x0, [x13, #0x18]
   2198c:      	mov	x1, #0x31d              ; =797
   21990:      	mov	x2, #-0x9               ; =-9
   21994:      	mov	x0, #0x2                ; =2
   21998:      	mov	w16, #0xa8c0            ; =43200
   2199c:      	movk	w16, #0x1, lsl #16
   219a0:      	ldr	x7, [sp, x16, sxtx]
   219a4:      	mov	w16, #0x3af0            ; =15088
   219a8:      	movk	w16, #0x1, lsl #16
   219ac:      	str	x0, [sp, x16, sxtx]
   219b0:      	mov	w16, #0xa8d0            ; =43216
   219b4:      	movk	w16, #0x1, lsl #16
   219b8:      	ldr	x0, [sp, x16, sxtx]
   219bc:      	mov	w16, #0x3af0            ; =15088
   219c0:      	movk	w16, #0x1, lsl #16
   219c4:      	ldr	x5, [sp, x16, sxtx]
   219c8:      	mov	w16, #0xa8b8            ; =43192
   219cc:      	movk	w16, #0x1, lsl #16
   219d0:      	ldr	x6, [sp, x16, sxtx]
   219d4:      	blr	x7
   219d8:      	cmp	x0, #0x0
   219dc:      	b.ne	0xf3c10 <_mech_canonical_program_entry_v1+0xf3c10>
   219e0:      	mov	x0, #0x3                ; =3
   219e4:      	mov	w16, #0x3af0            ; =15088
   219e8:      	movk	w16, #0x1, lsl #16
   219ec:      	str	x0, [sp, x16, sxtx]
   219f0:      	mov	w16, #0xa8a8            ; =43176
   219f4:      	movk	w16, #0x1, lsl #16
   219f8:      	ldr	x0, [sp, x16, sxtx]
   219fc:      	cmp	x0, #0x2
   21a00:      	b.lo	0xf3c4c <_mech_canonical_program_entry_v1+0xf3c4c>
   21a04:      	mov	x5, #0x0                ; =0
   21a08:      	mov	w16, #0xa8b0            ; =43184
   21a0c:      	movk	w16, #0x1, lsl #16
   21a10:      	ldr	x0, [sp, x16, sxtx]
   21a14:      	str	x5, [x0]
   21a18:      	mov	w16, #0xa8d8            ; =43224
   21a1c:      	movk	w16, #0x1, lsl #16
   21a20:      	ldr	x0, [sp, x16, sxtx]
   21a24:      	ldr	x0, [x0, #0x1b00]
   21a28:      	mov	w16, #0xa8b0            ; =43184
   21a2c:      	movk	w16, #0x1, lsl #16
   21a30:      	ldr	x1, [sp, x16, sxtx]
   21a34:      	str	x0, [x1, #0x8]
   21a38:      	mov	x1, #0x31d              ; =797
   21a3c:      	mov	x0, #0x2                ; =2
   21a40:      	mov	w16, #0xa8c0            ; =43200
   21a44:      	movk	w16, #0x1, lsl #16
   21a48:      	ldr	x7, [sp, x16, sxtx]
   21a4c:      	mov	w16, #0x3af0            ; =15088
   21a50:      	movk	w16, #0x1, lsl #16
   21a54:      	str	x0, [sp, x16, sxtx]
   21a58:      	mov	w16, #0xa8d0            ; =43216
   21a5c:      	movk	w16, #0x1, lsl #16
   21a60:      	ldr	x0, [sp, x16, sxtx]
   21a64:      	mov	w16, #0xa8b0            ; =43184
   21a68:      	movk	w16, #0x1, lsl #16
   21a6c:      	ldr	x3, [sp, x16, sxtx]
   21a70:      	mov	w16, #0x3af0            ; =15088
   21a74:      	movk	w16, #0x1, lsl #16
   21a78:      	ldr	x4, [sp, x16, sxtx]
   21a7c:      	mov	w16, #0xa8b8            ; =43192
   21a80:      	movk	w16, #0x1, lsl #16
   21a84:      	ldr	x6, [sp, x16, sxtx]
   21a88:      	mov	x2, x5
   21a8c:      	blr	x7
   21a90:      	cmp	x0, #0x0
   21a94:      	b.ne	0xf3c50 <_mech_canonical_program_entry_v1+0xf3c50>
   21a98:      	mov	x0, #0x3                ; =3
   21a9c:      	mov	w16, #0x3af0            ; =15088
   21aa0:      	movk	w16, #0x1, lsl #16
   21aa4:      	str	x0, [sp, x16, sxtx]
   21aa8:      	ldur	x0, [sp]
   21aac:      	b	0xd29bc0 <_mech_canonical_program_entry_v1+0xd29bc0>
   21ab0:      	ldrb	w10, [x1, x20]
   21ab4:      	uxtb	w13, w10
   21ab8:      	mov	x20, x14
   21abc:      	mov	x14, x7
   21ac0:      	mov	x11, x13
   21ac4:      	mov	x10, x13
   21ac8:      	adds	x26, x14, x13
   21acc:      	cset	x27, hs
   21ad0:      	uxtb	w27, w27
   21ad4:      	cmp	w27, #0x0
   21ad8:      	b.ne	0xf3c54 <_mech_canonical_program_entry_v1+0xf3c54>
   21adc:      	mov	x5, #0x6d30             ; =27952
   21ae0:      	sub	x19, x19, x5
   21ae4:      	uxtb	w28, w28
   21ae8:      	uxtb	w25, w25
   21aec:      	mov	w16, #0xa6f0            ; =42736
   21af0:      	movk	w16, #0x1, lsl #16
   21af4:      	str	x3, [sp, x16, sxtx]
   21af8:      	mov	w16, #0xa6e8            ; =42728
   21afc:      	movk	w16, #0x1, lsl #16
   21b00:      	str	x4, [sp, x16, sxtx]
   21b04:      	str	x26, [sp, #0x340]
   21b08:      	str	x15, [sp, #0x338]
   21b0c:      	mov	x27, x15
   21b10:      	mov	x9, x26
   21b14:      	mov	x7, x26
   21b18:      	mov	x6, x15
   21b1c:      	mov	x5, x26
   21b20:      	mov	x26, x0
   21b24:      	mov	x3, x12
   21b28:      	mov	x12, x15
   21b2c:      	mov	w16, #0xa6e0            ; =42720
   21b30:      	movk	w16, #0x1, lsl #16
   21b34:      	ldr	x15, [sp, x16, sxtx]
   21b38:      	b	0x1ef2c <_mech_canonical_program_entry_v1+0x1ef2c>
   21b3c:      	str	x5, [sp, #0x328]
   21b40:      	ldr	x26, [sp, #0x2f8]
   21b44:      	ldr	x19, [sp, #0x300]
   21b48:      	ldr	x15, [sp, #0x308]
   21b4c:      	mov	w16, #0xa6f8            ; =42744
   21b50:      	movk	w16, #0x1, lsl #16
   21b54:      	ldr	x12, [sp, x16, sxtx]
   21b58:      	ldr	x10, [sp, #0x2e0]
   21b5c:      	ldr	x8, [sp, #0x310]
   21b60:      	ldr	x6, [sp, #0x2c8]
   21b64:      	ldr	x5, [sp, #0x2e8]
   21b68:      	ldr	x1, [sp, #0x2d0]
   21b6c:      	ldr	x0, [sp, #0x2f0]
   21b70:      	mov	x13, #0x1               ; =1
   21b74:      	adds	x13, x28, x13
   21b78:      	cset	x14, hs
   21b7c:      	uxtb	w14, w14
   21b80:      	cmp	w14, #0x0
   21b84:      	b.ne	0xf3d0c <_mech_canonical_program_entry_v1+0xf3d0c>
   21b88:      	mov	w16, #0xa710            ; =42768
   21b8c:      	movk	w16, #0x1, lsl #16
   21b90:      	ldr	x10, [sp, x16, sxtx]
   21b94:      	uxtb	w8, w12
   21b98:      	uxtb	w9, w9
   21b9c:      	str	x24, [sp, #0x318]
   21ba0:      	str	x13, [sp, #0x310]
   21ba4:      	str	x27, [sp, #0x300]
   21ba8:      	str	x13, [sp, #0x2f8]
   21bac:      	str	x23, [sp, #0x2f0]
   21bb0:      	str	x27, [sp, #0x2e8]
   21bb4:      	mov	x19, x27
   21bb8:      	mov	x15, x23
   21bbc:      	mov	x14, x28
   21bc0:      	mov	x28, x13
   21bc4:      	mov	x12, x13
   21bc8:      	mov	x13, x6
   21bcc:      	mov	x6, x10
   21bd0:      	mov	x10, x23
   21bd4:      	mov	x5, x1
   21bd8:      	ldr	x1, [sp, #0x320]
   21bdc:      	ldr	x0, [sp, #0x2d8]
   21be0:      	b	0x1ba38 <_mech_canonical_program_entry_v1+0x1ba38>
   21be4:      	mov	x0, #0x2b8              ; =696
   21be8:      	ldur	x1, [sp]
   21bec:      	str	x0, [x1, #0x48]
   21bf0:      	mov	w16, #0xa8b8            ; =43192
   21bf4:      	movk	w16, #0x1, lsl #16
   21bf8:      	ldr	x6, [sp, x16, sxtx]
   21bfc:      	ldr	x0, [x6]
   21c00:      	cmp	x0, #0x0
   21c04:      	b.ne	0x21c40 <_mech_canonical_program_entry_v1+0x21c40>
   21c08:      	mov	x1, #0x2b8              ; =696
   21c0c:      	mov	w16, #0xa8c8            ; =43208
   21c10:      	movk	w16, #0x1, lsl #16
   21c14:      	ldr	x2, [sp, x16, sxtx]
   21c18:      	mov	w16, #0xa8d0            ; =43216
   21c1c:      	movk	w16, #0x1, lsl #16
   21c20:      	ldr	x0, [sp, x16, sxtx]
   21c24:      	blr	x2
   21c28:      	mov	x1, #0x2                ; =2
   21c2c:      	mov	w16, #0x3af0            ; =15088
   21c30:      	movk	w16, #0x1, lsl #16
   21c34:      	str	x1, [sp, x16, sxtx]
   21c38:      	cmp	x0, #0x0
   21c3c:      	b.ne	0xf3d54 <_mech_canonical_program_entry_v1+0xf3d54>
   21c40:      	mov	x0, #0x2b9              ; =697
   21c44:      	ldur	x1, [sp]
   21c48:      	str	x0, [x1, #0x48]
   21c4c:      	mov	w16, #0xa8b8            ; =43192
   21c50:      	movk	w16, #0x1, lsl #16
   21c54:      	ldr	x6, [sp, x16, sxtx]
   21c58:      	ldr	x0, [x6]
   21c5c:      	cmp	x0, #0x0
   21c60:      	b.eq	0x21c74 <_mech_canonical_program_entry_v1+0x21c74>
   21c64:      	mov	w16, #0xa8d8            ; =43224
   21c68:      	movk	w16, #0x1, lsl #16
   21c6c:      	ldr	x0, [sp, x16, sxtx]
   21c70:      	b	0x21cb8 <_mech_canonical_program_entry_v1+0x21cb8>
   21c74:      	mov	x1, #0x2b9              ; =697
   21c78:      	mov	w16, #0xa8c8            ; =43208
   21c7c:      	movk	w16, #0x1, lsl #16
   21c80:      	ldr	x2, [sp, x16, sxtx]
   21c84:      	mov	w16, #0xa8d0            ; =43216
   21c88:      	movk	w16, #0x1, lsl #16
   21c8c:      	ldr	x0, [sp, x16, sxtx]
   21c90:      	blr	x2
   21c94:      	mov	x12, #0x2               ; =2
   21c98:      	mov	w16, #0x3af0            ; =15088
   21c9c:      	movk	w16, #0x1, lsl #16
   21ca0:      	str	x12, [sp, x16, sxtx]
   21ca4:      	cmp	x0, #0x0
   21ca8:      	b.ne	0xf3dd8 <_mech_canonical_program_entry_v1+0xf3dd8>
   21cac:      	mov	w16, #0xa8d8            ; =43224
   21cb0:      	movk	w16, #0x1, lsl #16
   21cb4:      	ldr	x0, [sp, x16, sxtx]
   21cb8:      	mov	w16, #0xa8d8            ; =43224
   21cbc:      	movk	w16, #0x1, lsl #16
   21cc0:      	ldr	x0, [sp, x16, sxtx]
   21cc4:      	ldr	x0, [x0, #0x2a0]
   21cc8:      	mov	w16, #0xa8d8            ; =43224
   21ccc:      	movk	w16, #0x1, lsl #16
   21cd0:      	ldr	x1, [sp, x16, sxtx]
   21cd4:      	str	x0, [x1, #0x1990]
   21cd8:      	mov	x1, #0x2b6              ; =694
   21cdc:      	ldur	x0, [sp]
   21ce0:      	str	x1, [x0, #0x48]
   21ce4:      	mov	w16, #0xa8c8            ; =43208
   21ce8:      	movk	w16, #0x1, lsl #16
   21cec:      	ldr	x13, [sp, x16, sxtx]
   21cf0:      	mov	w16, #0xa8d0            ; =43216
   21cf4:      	movk	w16, #0x1, lsl #16
   21cf8:      	ldr	x0, [sp, x16, sxtx]
   21cfc:      	blr	x13
   21d00:      	mov	x1, #0x2                ; =2
   21d04:      	mov	w16, #0x3af0            ; =15088
   21d08:      	movk	w16, #0x1, lsl #16
   21d0c:      	str	x1, [sp, x16, sxtx]
   21d10:      	cmp	x0, #0x0
   21d14:      	b.ne	0xf3e98 <_mech_canonical_program_entry_v1+0xf3e98>
   21d18:      	mov	x0, #0x342              ; =834
   21d1c:      	ldur	x1, [sp]
   21d20:      	str	x0, [x1, #0x48]
   21d24:      	mov	w16, #0xa8b8            ; =43192
   21d28:      	movk	w16, #0x1, lsl #16
   21d2c:      	ldr	x6, [sp, x16, sxtx]
   21d30:      	ldr	x0, [x6]
   21d34:      	cmp	x0, #0x0
   21d38:      	b.eq	0x21d4c <_mech_canonical_program_entry_v1+0x21d4c>

