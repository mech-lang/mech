from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/mech-scalar-child-round39-20261030');root=r/'linked-primary';root.mkdir()
base=json.loads((old/'primary/current-build.json').read_text());original=(old/'workers/session.rs').read_text();needle='let jit=JitProgramArtifact::compile_with_limits(&artifact,&catalog,mode.compilation()).unwrap();';assert original.count(needle)==1
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen=Path('/private/tmp/mech-frame-pack-move-round43-20261031/linked-primary/after');before=root/'before';before.mkdir()
for name in ['object.o','descriptor.json','metadata.json','worker','worker.rs','worker-build.json','binding.json']:os.link(frozen/name,before/name)
binding=json.loads((before/'binding.json').read_text());assert sha(before/'worker')==binding['worker_sha256']
for name,pin in binding['pins'].items():assert sha(before/name)==pin['sha256']
for lib in binding['libraries'].values():assert sha(Path(lib['path']))==lib['sha256']
normalized=[(before/'worker.rs').read_text().replace(json.loads((before/'metadata.json').read_text())['identity_symbol'],'<IDENTITY>').replace(str(frozen/'descriptor.json'),'<IMAGE>')]
subprocess.run(['python3',str(r/'archive.py'),'linked-build-before',*map(str,[f for f in before.iterdir() if f.is_file() and f.name not in ['object.o','descriptor.json','worker']]),str(r/'linked-build.py')],cwd=w,check=True)
artifact=Path('/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc');assert sha(artifact)=='a2a551911949f8c5fdc64273a43662c2a9c4953b853136c19d196692fdac45a7';assert sha(artifact.with_suffix('.mec'))=='331e659e92181d803b3d87218effe88f711c2e8ecad9f31838fc50991de1c5c9'
for label in ['after']:
 p=root/label;p.mkdir();libs=json.loads((r/'variants'/label/'libraries.json').read_text());revision='a0ad02497c96ea876799d1f844554cdc23d6c669' if label=='before' else json.loads((r/'final-release.json').read_text())['source_head']
 cmd_base=base['command'].copy()
 for i,a in enumerate(cmd_base):
  if i and cmd_base[i-1]=='--extern':key=a.split('=')[0];cmd_base[i]=key+'='+libs[key]['path']
 cmd_base[-3:-3]=['-L','dependency='+str(r/'frozen-compute'),'-L','dependency='+str(Path(libs['mech_gpu']['path']).parent),'-L','dependency='+str(Path(libs['mech_engine']['path']).parent)]
 def run(name,command):
  at=time.monotonic();q=subprocess.run(command,cwd=w,capture_output=True,text=True)
  for stream in ['stdout','stderr']:(p/(name+'.'+stream)).write_text(getattr(q,stream))
  (p/(name+'.json')).write_text(json.dumps({'command':command,'exit':q.returncode,'seconds':time.monotonic()-at,'compiler_source':revision,'libraries':libs,'auxiliary_dependencies':json.loads((r/'auxiliary-dependencies.json').read_text())},indent=2)+'\n');print(label,name,q.returncode,flush=True)
  if q.returncode:print(q.stderr[-4500:],flush=True)
  q.check_returncode()
 source=Path('/private/tmp/mech-retirement-round36-20261030/object/inspect.rs').read_text().replace('/private/tmp/mech-retirement-round36-20261030/object',str(p));(p/'inspect.rs').write_text(source)
 cmd=cmd_base.copy();cmd[-3]=str(p/'inspect.rs');cmd[-1]=str(p/'inspect');run('object-build',cmd);run('emit',[str(p/'inspect')])
 meta=json.loads((p/'metadata.json').read_text());identity=meta['identity_symbol'];entry=meta['entry_symbol']
 prefix='unsafe extern "C" {\n #[link_name="'+identity+'"] static LINKED_IDENTITY:[u8;mech_gpu::native_artifact::NATIVE_PROGRAM_LINK_IDENTITY_BYTES];\n #[link_name="'+entry+'"] fn linked_entry(frame:*mut std::ffi::c_void)->u64;\n}\n'
 replacement='// SAFETY: exact same-build Object, unchanged image, libraries and immutable identity are pinned before link; symbols live through every call.\n let jit=unsafe {mech_gpu::native_artifact::LinkedProgramArtifact::from_build_owned_image(include_bytes!("'+str(p/'descriptor.json')+'"),&catalog,&LINKED_IDENTITY,linked_entry)}.unwrap();'
 source=prefix+original.replace(needle,replacement).replace('"phase":"compiled"','"phase":"linked-compressor-image-restored"');(p/'worker.rs').write_text(source);normalized.append(source.replace(identity,'<IDENTITY>').replace(str(p/'descriptor.json'),'<IMAGE>'))
 cmd=cmd_base.copy();cmd[-3]=str(p/'worker.rs');cmd[-1]=str(p/'worker');cmd[-3:-3]=['-C','link-arg='+str(p/'object.o')];run('worker-build',cmd);run('smoke',[str(p/'worker'),str(artifact),'0'])
 rows=[json.loads(x) for x in (p/'smoke.stdout').read_text().splitlines() if x.startswith('{')];assert len(rows)==2 and all(x['exact_reference'] and x['independent_inflation'] and x['capacity']==13 and x['work']==60260219686 for x in rows);assert (p/'smoke.stderr').read_text().endswith('CLEANUP bytes=0 nodes=0\n')
 pins={name:{'sha256':sha(p/name),'bytes':(p/name).stat().st_size} for name in ['object.o','descriptor.json','metadata.json']}
 (p/'binding.json').write_text(json.dumps({'compiler_source':revision,'expected_work':60260219686,'pins':pins,'worker_sha256':sha(p/'worker'),'worker_source_sha256':sha(p/'worker.rs'),'original_worker_sha256':sha(old/'workers/session.rs'),'normalized_source_sha256':hashlib.sha256(normalized[-1].encode()).hexdigest(),'libraries':libs,'auxiliary_dependencies':json.loads((r/'auxiliary-dependencies.json').read_text()),'scope':'Both matched versions and later hardware/memory diagnostics use these same coherent optimized library graphs and same-build Object/images. Identical evaluate_into timer, tiny setup JIT helpers, source/bytecode, real buffers, pinned allocator, output reuse and check boundaries.'},indent=2)+'\n')
 files=[f for f in p.iterdir() if f.is_file() and f.name not in ['object.o','descriptor.json','worker','inspect']]
 subprocess.run(['python3',str(r/'archive.py'),'linked-build-'+label,*map(str,files),str(r/'linked-build.py')],cwd=w,check=True)
 (p/'inspect').unlink()
assert normalized[0]==normalized[1]
assert sha(root/'before/object.o')==sha(root/'after/object.o')
print('BOTH MATCHED EXECUTABLES READY',flush=True)
