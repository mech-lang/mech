from pathlib import Path
import os,json,subprocess,time,re,sys
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');phase=sys.argv[1];p=r/('units-'+phase);p.mkdir()
old=Path('/private/tmp/mech-frame-pack-move-round43-20261031');libs=json.loads((old/'final-libraries.json').read_text())
b=json.loads((old/'units-after/build.json').read_text());cmd=b['command'].copy()
for i,a in enumerate(cmd):
 if i and cmd[i-1]=='--extern':
  key=a.split('=')[0]
  if key in libs:cmd[i]=key+'='+libs[key]['path']
  if key=='mech_compute':cmd[i]=key+'='+str(old/'frozen-compute/libmech_compute-84cb0ef1d137eee3.rlib')
cmd[-3:-3]=['-L','dependency='+str(old/'frozen-compute'),'-L','dependency='+str(Path(libs['mech_engine']['path']).parent)];cmd[-1]=str(p/'gpu-unit-tests')
def run(label,command,expected_exit=0,count=None):
 at=time.monotonic();q=subprocess.run(command,cwd=w,env={**os.environ,**b['environment']},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 row={'command':command,'exit':q.returncode,'expected_exit':expected_exit,'seconds':time.monotonic()-at,'environment':b['environment'],'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()}
 if count is not None:row['executed_tests']=int(re.search(r'test result: (?:ok|FAILED). (\d+) passed; (\d+) failed;',q.stdout)[1])+int(re.search(r'test result: (?:ok|FAILED). (\d+) passed; (\d+) failed;',q.stdout)[2])
 (p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n');print(label,row['exit'],row.get('executed_tests'),flush=True)
 if q.returncode!=expected_exit:print(q.stdout[-2500:]+q.stderr[-6000:],flush=True)
 assert q.returncode==expected_exit,row
 if count is not None:assert row['executed_tests']==count,row
 if expected_exit:assert 'successful pack must consume disposable call inputs' in q.stdout+q.stderr
 subprocess.run(['python3',str(r/'archive.py'),'unit-'+phase+'-'+label,*map(str,[p/(label+'.json'),p/(label+'.stdout'),p/(label+'.stderr'),r/'unit-checks.py'])],cwd=w,check=True)
run('build',cmd)
run('borrow',[str(p/'gpu-unit-tests'),'current_read_tests::','--nocapture','--test-threads=1'],count=1)
if phase=='after':
 run('runtime',[str(p/'gpu-unit-tests'),'native_artifact::program::runtime::','--skip','complete_unchanged_knucleotide_body_uses_the_owned_emitted_map','--nocapture','--test-threads=1'],count=316)
 run('work-values',[str(p/'gpu-unit-tests'),'native_artifact::work::','native_artifact::memory::','native_artifact::values::','--nocapture','--test-threads=1'],count=32)
