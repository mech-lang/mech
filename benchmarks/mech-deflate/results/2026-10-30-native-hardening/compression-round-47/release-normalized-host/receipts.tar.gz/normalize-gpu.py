from pathlib import Path
import hashlib,json,os,subprocess,time,shutil
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/mech-frame-pack-move-round43-20261031');p=r/'variants/after';libs=json.loads((r/'final-libraries.json').read_text());cargo_release=json.loads((r/'final-release.json').read_text())
(r/'cargo-release.json').write_text(json.dumps(cargo_release,indent=2)+'\n');(r/'cargo-libraries.json').write_text(json.dumps(libs,indent=2)+'\n')
b=json.loads((old/'variants/after/build.json').read_text());cmd=b['command'].copy()
for i,a in enumerate(cmd):
 if i and cmd[i-1]=='--extern':
  key=a.split('=')[0]
  if key in libs:cmd[i]=key+'='+libs[key]['path']
  if key=='mech_compute':cmd[i]=key+'='+str(r/'frozen-compute/libmech_compute-84cb0ef1d137eee3.rlib')
 if a=='dependency='+str(old/'frozen-compute'):cmd[i]='dependency='+str(r/'frozen-compute')
 if a=='dependency=/private/tmp/mech-record-lookup-round42-20261030/final-library':cmd[i]='dependency='+str(r/'final-library')
cmd[-1]=str(p/'libmech_gpu.rlib');t=time.monotonic();q=subprocess.run(cmd,cwd=b['cwd'],env={**os.environ,**b['environment']},capture_output=True,text=True)
for stream in ['stdout','stderr']:(p/('build.'+stream)).write_text(getattr(q,stream))
receipt={'command':cmd,'environment':b['environment'],'cwd':b['cwd'],'source_head':cargo_release['source_head'],'exit':q.returncode,'seconds':time.monotonic()-t,'profile':'Exact retained host rustc flags/features, against freshly frozen matching Engine/Stdlib/Compute. Cargo selected-operation build recorded separately.'};(p/'build.json').write_text(json.dumps(receipt,indent=2)+'\n');print('MATCHED GPU BUILD',q.returncode,receipt['seconds'],flush=True)
if q.returncode:print(q.stderr[-6000:],flush=True)
q.check_returncode();libs['mech_gpu']={**libs['mech_gpu'],'path':str(p/'libmech_gpu.rlib'),'sha256':hashlib.sha256((p/'libmech_gpu.rlib').read_bytes()).hexdigest()}
(p/'libraries.json').write_text(json.dumps(libs,indent=2)+'\n');(r/'final-libraries.json').write_text(json.dumps(libs,indent=2)+'\n');(r/'final-release.json').write_text(json.dumps(receipt,indent=2)+'\n')
subprocess.run(['python3',str(r/'archive.py'),'release-normalized-host',str(p/'build.json'),str(p/'build.stdout'),str(p/'build.stderr'),str(r/'cargo-release.json'),str(r/'cargo-libraries.json'),str(r/'final-libraries.json'),str(r/'final-release.json'),str(r/'normalize-gpu.py')],cwd=w,check=True)
