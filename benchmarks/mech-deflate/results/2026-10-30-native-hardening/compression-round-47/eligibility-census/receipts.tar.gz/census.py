from pathlib import Path
import json,hashlib,shutil,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'census';p.mkdir();prior=Path('/private/tmp/mech-record-prefix-round46-20261031');base=json.loads((r/'linked-primary/after/worker-build.json').read_text());meta=json.loads((r/'linked-primary/after/metadata.json').read_text())
for name in ['allocation_profile.rs','allocation_profile.c','allocation_profile.h','usage.c','usage.h','usage.o','memory_profile.o']:shutil.copyfile(prior/'counters'/name,p/name)
s=(prior/'counters/after/memory.rs').read_text().replace(str(prior/'counters'),str(p)).replace(str(prior/'linked-primary/after/descriptor.json'),str(r/'linked-primary/after/descriptor.json'))
old_meta=json.loads((prior/'linked-primary/after/metadata.json').read_text());s=s.replace(old_meta['identity_symbol'],meta['identity_symbol'])
needle='use mech_core::';at=s.index(needle);s=s[:at]+'''// SAFETY: these counter-only symbols belong to this exact isolated Core build.
unsafe extern "C" {fn mech_snapshot_admission_census_reset();fn mech_snapshot_admission_census_get(index:u32)->u64;}
fn admission_counts()->[u64;7]{std::array::from_fn(|index|unsafe{mech_snapshot_admission_census_get(index as u32)})}
'''+s[at:]
needle='allocation_profile::begin();';assert s.count(needle)==1;s=s.replace(needle,'// SAFETY: isolated counter reset, no pointers or execution authority.\n  unsafe{mech_snapshot_admission_census_reset()};'+needle)
needle='"work":report.work';assert s.count(needle)==1;s=s.replace(needle,'"admission_counts":admission_counts(),"comparison_work":report.comparison_work,"work":report.work');(p/'worker.rs').write_text(s)
cmd=base['command'].copy();cmd[-3]=str(p/'worker.rs');cmd[-1]=str(p/'worker');cmd[-3:-3]=['-C','link-arg='+str(p/'usage.o'),'-C','link-arg='+str(p/'memory_profile.o')]
def run(label,command):
 t=time.monotonic();q=subprocess.run(command,cwd=w,capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 row={'command':command,'exit':q.returncode,'seconds':time.monotonic()-t,'libraries':base['libraries'],'compiler_source':base['compiler_source'],'scope':'Instrumented eligibility/allocation census, excluded from every primary performance claim.'};(p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 if q.returncode:print(q.stdout[-2500:]+q.stderr[-5000:],flush=True)
 q.check_returncode();return q
run('build',cmd);q=run('run',[str(p/'worker'),'/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc','8'])
rows=[json.loads(line) for line in q.stdout.splitlines() if line.startswith('{')];assert len(rows)==10;measured=rows[1:-1]
alloc=[json.loads(line.removeprefix('ALLOC_PROBE ')) for line in q.stderr.splitlines() if line.startswith('ALLOC_PROBE ')][1:-1];assert len(alloc)==8
for row,a in zip(measured,alloc):
 assert row['work']==60260219686 and row['comparison_work']==47612 and row['exact_reference'] and row['independent_inflation'] and row['capacity']==13
 assert a['allocation_requests']==13994 and a['requested_bytes']==98586843
 calls,same,hit,wrappers,exclusive,eligible,shared_data=row['admission_counts'];assert calls-same-hit==wrappers and 0<=shared_data<=eligible<=exclusive<=wrappers
assert all(row['admission_counts']==measured[0]['admission_counts'] for row in measured)
assert q.stderr.endswith('CLEANUP bytes=0 nodes=0\n')
result={'baseline_compiler':'b71c596bdd2f59fbb2893aa8847769f767660677','diagnostic_compiler':base['compiler_source'],'observations':8,'counter_names':['calls','same_account_hits','existing_import_hits','wrapper_paths','exclusive_roots','eligible_unadmitted_roots','eligible_with_shared_data'],'counts':measured[0]['admission_counts'],'allocation_requests':13994,'requested_bytes':98586843,'expected_wrapper_bytes_removed_per_eligible':112,'performance_claimed':False,'scope':'Exact Arc::get_mut and absent-ownership test at original wrapper-allocation point, after registration preparation. Shared data remains a separately observed fact, not permission to omit registry synchronization.'};(p/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
subprocess.run(['python3',str(r/'archive.py'),'eligibility-census',*map(str,[f for f in p.iterdir() if f.is_file() and f.name not in {'worker','memory_profile.o','usage.o'}]),str(r/'census.py')],cwd=w,check=True)
print('EXACT ELIGIBILITY CENSUS',json.dumps(result),flush=True)
