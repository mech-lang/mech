from pathlib import Path
import json,subprocess,os,time,hashlib,shutil
w=Path('/private/tmp/mech-deflate-linear-stack');r=Path(__file__).resolve().parent;old=Path('/private/tmp/mech-record-prefix-round46-20261031')
previous=json.loads((old/'final-libraries.json').read_text())
receipt=json.loads((r/'final-release.json').read_text());assert receipt['exit']==0
subprocess.run(['python3',str(r/'archive.py'),'release-command',str(r/'final-release.json'),str(r/'final-release.log'),str(r/'final-release.stderr'),str(r/'build-census.py'),str(r/'resume-build.py')],cwd=w,check=True)
rows=[json.loads(x) for x in (r/'final-release.log').read_text().splitlines() if x.startswith('{')];assert rows[-1]=={'reason':'build-finished','success':True}
libs={};d=r/'final-library';d.mkdir()
for row in rows:
 if row.get('reason')=='compiler-artifact' and row['target']['name'] in previous:
  name=row['target']['name'];files=[Path(x) for x in row['filenames'] if x.endswith('.rlib')];assert len(files)==1
  target=d/files[0].name;shutil.copy2(files[0],target)
  libs[name]={'path':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'features':row['features'],'profile':row['profile']}
  assert libs[name]['features']==previous[name]['features'] and libs[name]['profile']==previous[name]['profile'],name
  if name not in {'mech_gpu','mech_engine','mech_stdlib','mech_core','mech_syntax'}:assert libs[name]['sha256']==previous[name]['sha256'],name
assert len(libs)==8
common=r/'frozen-compute';common.mkdir();aux=[]
for f in Path('/private/tmp/mech-live-control-target/release/deps').glob('libmech_compute-84cb0ef1d137eee3.*'):
 if f.suffix not in {'.rmeta','.rlib'}:continue
 target=common/f.name;shutil.copy2(f,target);aux.append({'path':str(target),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
assert len(aux)==2
(r/'auxiliary-dependencies.json').write_text(json.dumps({'scope':'Freeze transitive Compute plus all eight direct release artifacts before any consumer/diagnostic build.','files':aux},indent=2)+'\n')
(r/'variants/after').mkdir();(r/'variants/after/libraries.json').write_text(json.dumps(libs,indent=2)+'\n');(r/'final-libraries.json').write_text(json.dumps(libs,indent=2)+'\n')
subprocess.run(['python3',str(r/'archive.py'),'release-library-pins',str(r/'auxiliary-dependencies.json'),str(r/'final-libraries.json'),str(r/'variants/before/libraries.json')],cwd=w,check=True)
print('FROZEN', {name:libs[name]['sha256'] for name in ['mech_engine','mech_stdlib','mech_gpu']},flush=True)
