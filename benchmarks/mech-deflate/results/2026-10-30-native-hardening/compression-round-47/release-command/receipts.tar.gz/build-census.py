from pathlib import Path
import json,subprocess,os,time,hashlib,shutil
w=Path('/private/tmp/mech-deflate-linear-stack');r=Path(__file__).resolve().parent;old=Path('/private/tmp/mech-record-prefix-round46-20261031')
previous=json.loads((old/'final-libraries.json').read_text());b=json.loads((old/'cargo-release.json').read_text());cmd=b['command'];env=b['environment'];head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip()
(r/'variants/before').mkdir(parents=True);(r/'variants/before/libraries.json').write_text(json.dumps(previous,indent=2)+'\n')
t=time.monotonic()
with (r/'final-release.log').open('w') as out,(r/'final-release.stderr').open('w') as err:q=subprocess.run(cmd,cwd=w,env={**os.environ,**env},stdout=out,stderr=err)
(r/'final-release.json').write_text(json.dumps({'command':cmd,'environment':env,'cwd':str(w),'source_head':head,'exit':q.returncode,'seconds':time.monotonic()-t,'profile':'Same selected-operation release consumer as baseline; opt3, warnings-as-errors, offline, locked, single build job.'},indent=2)+'\n');print('RELEASE',q.returncode,time.monotonic()-t,flush=True)
subprocess.run(['python3',str(r/'archive.py'),'release-command',str(r/'final-release.json'),str(r/'final-release.log'),str(r/'final-release.stderr'),str(r/'build-census.py')],cwd=w,check=True)
if q.returncode:print((r/'final-release.stderr').read_text()[-6000:],flush=True)
q.check_returncode();rows=[json.loads(x) for x in (r/'final-release.log').read_text().splitlines() if x.startswith('{')];assert rows[-1]=={'reason':'build-finished','success':True}
libs={};d=r/'final-library';d.mkdir()
for row in rows:
 if row.get('reason')=='compiler-artifact' and row['target']['name'] in previous:
  name=row['target']['name'];files=[Path(x) for x in row['filenames'] if x.endswith('.rlib')];assert len(files)==1
  target=d/files[0].name;shutil.copy2(files[0],target)
  libs[name]={'path':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'features':row['features'],'profile':row['profile']}
  assert libs[name]['features']==previous[name]['features'] and libs[name]['profile']==previous[name]['profile'],name
  if name not in {'mech_gpu','mech_engine','mech_stdlib','mech_core','mech_syntax'}:assert libs[name]['sha256']==previous[name]['sha256'],name
assert len(libs)==8
common=r/'frozen-compute';common.mkdir();aux=[]
for f in Path('/private/tmp/mech-live-control-target/release/deps').glob('libmech_compute-84cb0ef1d137eee3.*'):
 if f.suffix not in {'.rmeta','.rlib'}:continue
 target=common/f.name;shutil.copy2(f,target);aux.append({'path':str(target),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
assert len(aux)==2
(r/'auxiliary-dependencies.json').write_text(json.dumps({'scope':'Freeze transitive Compute plus all eight direct release artifacts before any consumer/diagnostic build.','files':aux},indent=2)+'\n')
(r/'variants/after').mkdir();(r/'variants/after/libraries.json').write_text(json.dumps(libs,indent=2)+'\n');(r/'final-libraries.json').write_text(json.dumps(libs,indent=2)+'\n')
subprocess.run(['python3',str(r/'archive.py'),'release-library-pins',str(r/'auxiliary-dependencies.json'),str(r/'final-libraries.json'),str(r/'variants/before/libraries.json')],cwd=w,check=True)
print('FROZEN', {name:libs[name]['sha256'] for name in ['mech_engine','mech_stdlib','mech_gpu']},flush=True)
