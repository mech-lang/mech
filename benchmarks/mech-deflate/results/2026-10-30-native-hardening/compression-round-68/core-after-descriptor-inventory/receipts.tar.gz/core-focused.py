"""Fresh Core unit qualification with exact parent or candidate descriptor semantics."""
from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');phase=sys.argv[1];assert phase in ['before','after'];p=r/('core-'+phase);p.mkdir()
c=json.loads((r/'configuration.json').read_text());assert c['initialized'];dep=Path(c['baseline_directory'])/'variants/after/dependency'
base=json.loads(Path('/private/tmp/mech-private-numeric-lifetime-round66-20261031/core-focused/build.json').read_text());cmd=base['command'].copy();checkout=p/'source';(checkout/'src').mkdir(parents=True);shutil.copytree(w/'src/core',checkout/'src/core',ignore=shutil.ignore_patterns('target','.git'));(checkout/'tests').symlink_to(w/'tests',target_is_directory=True)
if phase=='before':
 for relative in c['production_files']:(checkout/relative).write_bytes(subprocess.check_output(['git','show',c['baseline_checkpoint']+':'+relative],cwd=w))
source_files=c['production_files']+c['test_files'];pins={relative:hashlib.sha256((checkout/relative).read_bytes()).hexdigest() for relative in source_files}
for relative in source_files:(p/Path(relative).name).write_bytes((checkout/relative).read_bytes())
index=next(i for i,a in enumerate(cmd) if a.endswith('/src/core/src/lib.rs'));cmd[index]=str(checkout/'src/core/src/lib.rs');cmd[-1]=str(p/'core-unit-tests')
for i,a in enumerate(cmd):
 if i and cmd[i-1]=='--extern':
  name,path=a.split('=',1);target=dep/Path(path).name;assert target.exists(),target;cmd[i]=name+'='+str(target)
for i in range(len(cmd)-1,0,-1):
 if cmd[i].startswith('dependency=') and cmd[i-1]=='-L':del cmd[i-1:i+1]
cmd[1:1]=['-L','dependency='+str(dep)];env={**base['environment'],'CARGO_MANIFEST_DIR':str(w/'src/core')}
selections=[('build',cmd,None),('inventory',[cmd[-1],'--list'],369),('selected',[cmd[-1],'--nocapture','--test-threads=1'],369),('descriptor-inventory',[cmd[-1],'descriptor_semantics','--list'],2),('descriptor',[cmd[-1],'descriptor_semantics','--nocapture','--test-threads=1'],2)]
for label,command,count in selections:
 start=time.monotonic();q=subprocess.run(command,cwd=w,env={**os.environ,**env},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 row={'command':command,'environment':env,'exit':q.returncode,'seconds':time.monotonic()-start,'source_sha256':pins,'test_source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'baseline_checkpoint':c['baseline_checkpoint'],'scope':'Current Core tests in complete scratch source; before substitutes only exact published parent descriptor implementation. All external dependencies and retained warnings-as-errors Core test flags are unchanged. Actual executions, not an inventory-only claim.'}
 if count is not None:
  row['expected_tests']=count
  if label.endswith('inventory'):row['listed_tests']=len(re.findall(r': test$',q.stdout,re.M));observed=row['listed_tests']
  else:
   m=re.search(r'test result: (?:ok|FAILED). (\d+) passed; (\d+) failed;',q.stdout);row.update(passed_tests=int(m[1]) if m else None,failed_tests=int(m[2]) if m else None,executed_tests=int(m[1])+int(m[2]) if m else None);observed=row['executed_tests']
 (p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 subprocess.run(['python3',str(r/'archive.py'),'core-'+phase+'-'+label,*map(str,[p/(label+'.'+ext) for ext in ['json','stdout','stderr']]),*map(str,[p/Path(x).name for x in source_files]),str(r/'core-focused.py')],check=True)
 print(phase,label,q.returncode,row.get('executed_tests',row.get('listed_tests')),flush=True)
 if q.returncode:print(q.stdout[-4000:]+q.stderr[-6000:],flush=True)
 q.check_returncode()
 if count is not None:assert observed==count,row
