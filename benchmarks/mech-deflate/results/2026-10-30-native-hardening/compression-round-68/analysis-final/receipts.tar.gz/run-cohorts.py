from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent
for name,args in [('source-contracts.py',['focused']),('linked-build.py',['after']),('run-primary.py',[]),('counters.py',[]),('sites.py',['before']),('sites.py',['after']),('profile-isolated.py',[]),('profile-reference.py',[])]:
 print('START',name,flush=True);subprocess.run(['python3',str(r/name),*args],check=True);print('DONE',name,flush=True)
